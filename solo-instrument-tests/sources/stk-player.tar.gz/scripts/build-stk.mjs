#!/usr/bin/env node
// STK, the Synthesis ToolKit in C++ (P. R. Cook & G. P. Scavone; MIT-style licence), 5.0.1 at its pinned commit
// (research/orchestral-synthesis-candidates.json), its waveguides a comparison beside OpenWInD, Artifastring and NESS
// (research/ENGINE_COMPARISON_PLAN.md; the owner, 26 October 2026: "Can we add STK waveguides to our synthesis methods,
// again for comparison?"). Its source fetched into the synthesis home (stk-src) and its DSP classes alone -- the
// clarinet, the saxophone, the flute, the brass and the bowed string, and what they are made of -- compiled with
// native/stk-wasm/stk-player.cpp by Emscripten (EMSDK, else ~/emsdk) into one WebAssembly module (synthesis home's
// stk/: stk.mjs, stk.wasm, its licence, build.json), which the Mac's renders run in Node and the page in its Worker
// (scripts/build-studio.mjs copies it), so that both play a part on STK to the bit; registered as the stk backend in the
// synthesis home's backends.json, where there is one, for the Mac's renders (render.mjs).
//   node scripts/build-stk.mjs
import {spawn,spawnSync} from 'node:child_process';
import {homedir} from 'node:os';
import {copyFileSync,existsSync,mkdirSync,readFileSync,statSync,writeFileSync} from 'node:fs';
import {join} from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import {synthesisHome} from '../render/synthesis/synthesis-home.mjs';

const ROOT=fileURLToPath(new URL('../',import.meta.url));
const EMSDK=process.env.EMSDK||join(homedir(),'emsdk');
export const STK_REPOSITORY='https://github.com/thestk/stk.git';
export const STK_COMMIT='1cb2c81d04922b6337073ecb44d83bf2208690f5';
export const stkSource=()=>join(synthesisHome(),'stk-src');
export const stkHome=()=>join(synthesisHome(),'stk');
// Its objects kept where the owner sees scratch work, beside web-musebots.
const OBJECTS=join(ROOT,'..','claude-scratch','stk-build','objects');
// The models' sources and what they are made of (none reads a file: their sines and noise are computed).
export const STK_SOURCES=Object.freeze(['Stk','Clarinet','Saxofony','Flute','Brass','Bowed','Delay','DelayL','DelayA','OneZero','OnePole','PoleZero',
  'BiQuad','ADSR','Envelope','Noise','SineWave']);
export const STK_EXPORTS=Object.freeze(['stk_rate','stk_seed','stk_new','stk_free','stk_frequency','stk_start','stk_stop','stk_control','stk_ticks']);

const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const run=(command,args,options={})=>{const done=spawnSync(command,args,{encoding:'utf8',...options});
  if(done.error||done.status!==0)throw new Error(`${command} ${args.slice(0,3).join(' ')}: ${(done.error?.message??done.stderr??'').trim().slice(-400)}`);return done.stdout};

// Musebots' changes to STK (render/synthesis/patches/), applied to its source as fetched: the flute's output gain, left
// unset by its constructor (a flute begun by startBlowing silent), set as the clarinet's is; the brass's lip filter and
// bore correction, per-sample constants set at 22050 Hz, kept so at any rate (at 48 kHz it had held only a C5 at
// middle breath of the G4s and C5s it holds at 22050 Hz); and the brass's delay line long enough for its lowest pitch
// as its setFrequency asks it, on a harmonic (sized for one period, more than it holds).
export const STK_PATCHES=Object.freeze(['stk-5.0.1-musebots.patch']);

// Its source at the pinned commit, fetched once, its patches applied to it as fetched. -> its folder.
export function stkSourceAt(){
  const source=stkSource();
  if(!existsSync(join(source,'.git')))run('git',['clone','-q',STK_REPOSITORY,source]);
  run('git',['-C',source,'checkout','-q','-f',STK_COMMIT]);
  for(const patch of STK_PATCHES)run('git',['-C',source,'apply','--whitespace=nowarn',join(ROOT,'render/synthesis/patches',patch)]);
  return source;
}

// STK by Emscripten: each source compiled (two at a time, niced; one newer than its source and every header kept), then
// linked as an ES module. -> {path, wasm, bytes, sha256, commit, emscripten} or {reason}.
export async function buildStk({out=stkHome()}={}){
  const empp=join(EMSDK,'upstream/emscripten/em++'),emcc=join(EMSDK,'upstream/emscripten/emcc');
  if(!existsSync(empp))return {reason:`Emscripten is not installed (${EMSDK})`};
  let source;try{source=stkSourceAt()}catch(error){return {reason:`STK's source could not be fetched: ${error.message}`}}
  const include=join(source,'include'),player=join(ROOT,'native/stk-wasm/stk-player.cpp');
  const units=[...STK_SOURCES.map(name=>join(source,'src',`${name}.cpp`)),player];
  // (Its sources' times moved by the checkout: an object kept only where it is newer than its patch too.)
  const newestHeader=Math.max(...STK_SOURCES.map(name=>join(include,`${name}.h`)).filter(existsSync).map(f=>statSync(f).mtimeMs),
    ...STK_PATCHES.map(patch=>statSync(join(ROOT,'render/synthesis/patches',patch)).mtimeMs),statSync(fileURLToPath(import.meta.url)).mtimeMs);
  const flags=['-O3','-I',include,'-w'],env={...process.env,EM_CONFIG:join(EMSDK,'.emscripten')};
  mkdirSync(OBJECTS,{recursive:true});
  const compile=file=>new Promise(resolve=>{
    const object=join(OBJECTS,file.split('/').pop().replace(/\.cpp$/,'.o'));
    if(existsSync(object)&&statSync(object).mtimeMs>Math.max(statSync(file).mtimeMs,newestHeader))return resolve({object});
    const child=spawn('nice',['-n','10',empp,'-c',file,'-o',object,...flags],{env,stdio:['ignore','ignore','pipe']});let said='';
    child.stderr.on('data',chunk=>said+=chunk);child.once('exit',code=>resolve(code===0?{object}:{reason:`${file.split('/').pop()}: ${said.trim().slice(-400)}`}));
  });
  const objects=[];let next=0,failed=null;
  await Promise.all([0,1].map(async()=>{while(next<units.length&&!failed){const done=await compile(units[next++]);if(done.reason)failed=done.reason;else objects.push(done.object)}}));
  if(failed)return {reason:`STK did not compile for WebAssembly: ${failed}`};
  mkdirSync(out,{recursive:true});
  const path=join(out,'stk.mjs'),linked=spawnSync('nice',['-n','10',empp,...objects,'-o',path,'-O3','-sMODULARIZE=1','-sEXPORT_ES6=1','-sEXPORT_NAME=createStk',
    `-sEXPORTED_FUNCTIONS=${[...STK_EXPORTS,'malloc','free'].map(name=>`_${name}`).join(',')}`,'-sEXPORTED_RUNTIME_METHODS=HEAPF32',
    '-sALLOW_MEMORY_GROWTH=1','-sENVIRONMENT=web,worker,node'],{env,encoding:'utf8'});
  if(linked.status!==0)return {reason:`STK did not link for WebAssembly: ${(linked.stderr??'').trim().slice(-400)}`};
  copyFileSync(join(source,'LICENSE'),join(out,'LICENSE.txt'));
  const wasm=readFileSync(join(out,'stk.wasm')),emscripten=spawnSync(emcc,['--version'],{env,encoding:'utf8'}).stdout.split('\n')[0];
  const built={path,wasm:join(out,'stk.wasm'),bytes:wasm.length,sha256:sha(wasm),commit:STK_COMMIT,patches:STK_PATCHES,emscripten};
  writeFileSync(join(out,'build.json'),JSON.stringify({...built,builtAt:new Date().toISOString()},null,1)+'\n');
  // (The Mac's renders told where it is: render.mjs plays a part on the stk backend from its `module`.)
  const backends=join(synthesisHome(),'backends.json');
  if(out===stkHome()&&existsSync(backends)){const config=JSON.parse(readFileSync(backends,'utf8'));
    config.backends.stk={kind:'stk',module:path,build:{commit:STK_COMMIT,patches:STK_PATCHES.map(patch=>`render/synthesis/patches/${patch}`),sha256:built.sha256}};
    writeFileSync(backends,JSON.stringify(config,null,1)+'\n')}
  return built;
}

if(import.meta.url===pathToFileURL(process.argv[1]).href){
  const built=await buildStk();
  console.log(JSON.stringify(built,null,1));
  process.exit(built.reason?1:0);
}
