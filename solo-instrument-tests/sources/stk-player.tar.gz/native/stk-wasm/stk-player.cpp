// STK's waveguides (the Synthesis ToolKit in C++, P. R. Cook & G. P. Scavone, 5.0.1; MIT-style licence, its notice
// kept with the build) as a player the page and the Mac's renders both drive: a comparison beside OpenWInD,
// Artifastring and NESS (research/ENGINE_COMPARISON_PLAN.md; the owner, 26 October 2026). Its DSP classes alone, behind
// a C interface (research/orchestral-synthesis-candidates.json: "Wrap DSP-only classes in C ABI"), compiled to
// WebAssembly once (scripts/build-stk.mjs) and run by render/synthesis/src/stk.mjs in either place, so that the page
// and the Mac play a part on STK to the bit.
//
// Its models: 0 Clarinet, 1 Saxofony, 2 Flute, 3 Brass, 4 Bowed -- each STK's own, its controls STK's numbers (0 to
// 128) and its frequency any (Hz, a float: a microtone as any pitch). STK's noise draws from the C library's rand(),
// which Noise seeds from the clock as a player is made: stk_seed, called after, seeds it again, so that a part plays
// alike every time.
#include <cstdlib>
#ifdef __EMSCRIPTEN__
#include <emscripten/emscripten.h>
#else
#define EMSCRIPTEN_KEEPALIVE
#endif
#include "Stk.h"
#include "Clarinet.h"
#include "Saxofony.h"
#include "Flute.h"
#include "Brass.h"
#include "Bowed.h"

using namespace stk;

namespace {
enum Model { CLARINET = 0, SAXOFONY = 1, FLUTE = 2, BRASS = 3, BOWED = 4 };
struct Player { int model; Instrmnt *instrument; };
}

extern "C" {

// The rate every player made after it runs at (Hz).
EMSCRIPTEN_KEEPALIVE void stk_rate(double rate) { Stk::setSampleRate(rate); }

// rand()'s seed, for every player's noise.
EMSCRIPTEN_KEEPALIVE void stk_seed(unsigned int seed) { srand(seed); }

// A player of `model`, its delay lines long enough for `lowest` Hz; null for a model it has not.
EMSCRIPTEN_KEEPALIVE Player *stk_new(int model, double lowest) {
  Instrmnt *instrument = nullptr;
  switch (model) {
    case CLARINET: instrument = new Clarinet(lowest); break;
    case SAXOFONY: instrument = new Saxofony(lowest); break;
    case FLUTE: instrument = new Flute(lowest); break;
    case BRASS: instrument = new Brass(lowest); break;
    case BOWED: instrument = new Bowed(lowest); break;
    default: return nullptr;
  }
  return new Player{model, instrument};
}

EMSCRIPTEN_KEEPALIVE void stk_free(Player *player) {
  if (!player) return;
  delete player->instrument;
  delete player;
}

// Its pitch (Hz), at once: its delay lines' lengths (and a brass instrument's lips) set for it.
EMSCRIPTEN_KEEPALIVE void stk_frequency(Player *player, double hz) { player->instrument->setFrequency(hz); }

// Its breath or bow begun, toward `amplitude` (0 to 1) at `rate` (its envelope's step a sample).
EMSCRIPTEN_KEEPALIVE void stk_start(Player *player, double amplitude, double rate) {
  switch (player->model) {
    case CLARINET: static_cast<Clarinet *>(player->instrument)->startBlowing(amplitude, rate); break;
    case SAXOFONY: static_cast<Saxofony *>(player->instrument)->startBlowing(amplitude, rate); break;
    case FLUTE: static_cast<Flute *>(player->instrument)->startBlowing(amplitude, rate); break;
    case BRASS: static_cast<Brass *>(player->instrument)->startBlowing(amplitude, rate); break;
    case BOWED: static_cast<Bowed *>(player->instrument)->startBowing(amplitude, rate); break;
  }
}

// Its breath or bow let go at `rate`.
EMSCRIPTEN_KEEPALIVE void stk_stop(Player *player, double rate) {
  switch (player->model) {
    case CLARINET: static_cast<Clarinet *>(player->instrument)->stopBlowing(rate); break;
    case SAXOFONY: static_cast<Saxofony *>(player->instrument)->stopBlowing(rate); break;
    case FLUTE: static_cast<Flute *>(player->instrument)->stopBlowing(rate); break;
    case BRASS: static_cast<Brass *>(player->instrument)->stopBlowing(rate); break;
    case BOWED: static_cast<Bowed *>(player->instrument)->stopBowing(rate); break;
  }
}

// One of STK's control changes: its number and value (0 to 128), as the model's header lists them.
EMSCRIPTEN_KEEPALIVE void stk_control(Player *player, int number, double value) { player->instrument->controlChange(number, value); }

// Its next `count` samples into `out`.
EMSCRIPTEN_KEEPALIVE void stk_ticks(Player *player, float *out, int count) {
  for (int i = 0; i < count; i++) out[i] = static_cast<float>(player->instrument->tick());
}

}
