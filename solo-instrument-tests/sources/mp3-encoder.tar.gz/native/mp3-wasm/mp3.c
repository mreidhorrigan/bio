// The studio page's MP3 encoder (public/studio/engines/mp3.js; scripts/build-studio.mjs buildMp3Wasm): LAME 4.0, the
// Mac's own (Homebrew's, which its ffmpeg links), driven as ffmpeg's libmp3lame drives it for an étude's mix
// (scripts/master-render.mjs encodeMp3: `-codec:a libmp3lame -b:a 320k`) -- a constant bit rate, joint stereo for two
// channels, its output rate its input's, its bit reservoir on, its quality LAME's own -- from the mastered float
// channels. Where ffmpeg's muxer writes its Xing header, LAME writes its own Info frame (its encoder delay and padding,
// for gapless playback); its tags an ID3v2 title and comment, in UTF-16.
#include <emscripten.h>
#include <lame/lame.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
  lame_global_flags *gf;
  unsigned char *out;
  size_t length, capacity;
  int channels, ready;
} Encoder;

// (Room for `more` bytes past its end.)
static int room(Encoder *e, size_t more) {
  if (e->length + more <= e->capacity) return 1;
  size_t capacity = e->capacity ? e->capacity : 1 << 16;
  while (capacity < e->length + more) capacity *= 2;
  unsigned char *grown = realloc(e->out, capacity);
  if (!grown) return 0;
  e->out = grown;
  e->capacity = capacity;
  return 1;
}

// An encoder for `channels` (1 or 2) at `rate` Hz and `kbps`, its tags set by mp3_tag before the first mp3_encode.
EMSCRIPTEN_KEEPALIVE Encoder *mp3_open(int channels, int rate, int kbps) {
  Encoder *e = calloc(1, sizeof(Encoder));
  if (!e) return NULL;
  e->channels = channels;
  e->gf = lame_init();
  if (!e->gf) { free(e); return NULL; }
  lame_set_num_channels(e->gf, channels);
  lame_set_in_samplerate(e->gf, rate);
  lame_set_out_samplerate(e->gf, rate);
  lame_set_mode(e->gf, channels > 1 ? JOINT_STEREO : MONO);
  lame_set_VBR(e->gf, vbr_off);
  lame_set_brate(e->gf, kbps);
  lame_set_bWriteVbrTag(e->gf, 1);
  id3tag_init(e->gf);
  id3tag_v2_only(e->gf);
  return e;
}

// A text frame (`id` its four letters: TIT2 its title, TENC its encoder) or, `id` COMM, its comment; `text` UTF-16 with
// its byte-order mark, ended by a zero. -> 0, or LAME's error.
EMSCRIPTEN_KEEPALIVE int mp3_tag(Encoder *e, const char *id, const unsigned short *text) {
  if (!strcmp(id, "COMM")) {
    static const unsigned short none[] = {0xfeff, 0};
    return id3tag_set_comment_utf16(e->gf, "eng", none, text);
  }
  return id3tag_set_textinfo_utf16(e->gf, id, text);
}

// `frames` of its channels (floats, -1 to 1; `right` ignored for one channel). -> 0, or LAME's error (negative).
EMSCRIPTEN_KEEPALIVE int mp3_encode(Encoder *e, const float *left, const float *right, int frames) {
  // (Its parameters fixed at its first frames, its tags set by then.)
  if (!e->ready) {
    if (lame_init_params(e->gf) < 0) return -100;
    e->ready = 1;
  }
  size_t most = (size_t)(1.25 * frames) + 7200;
  if (!room(e, most)) return -101;
  int made = lame_encode_buffer_ieee_float(e->gf, left, e->channels > 1 ? right : left, frames, e->out + e->length, (int)most);
  if (made < 0) return made;
  e->length += (size_t)made;
  return 0;
}

// Its last frames flushed and its Info frame written where LAME left room for it, after the ID3v2 tag. -> its length.
EMSCRIPTEN_KEEPALIVE int mp3_finish(Encoder *e) {
  if (!room(e, 7200)) return -101;
  int made = lame_encode_flush(e->gf, e->out + e->length, 7200);
  if (made < 0) return made;
  e->length += (size_t)made;
  // (The tag's length from its header: ten bytes and its syncsafe size.)
  size_t at = 0;
  if (e->length >= 10 && !memcmp(e->out, "ID3", 3))
    at = 10 + ((size_t)(e->out[6] & 0x7f) << 21 | (size_t)(e->out[7] & 0x7f) << 14 | (size_t)(e->out[8] & 0x7f) << 7 | (size_t)(e->out[9] & 0x7f));
  unsigned char frame[2880];
  size_t size = lame_get_lametag_frame(e->gf, frame, sizeof frame);
  if (size > 0 && at + size <= e->length) memcpy(e->out + at, frame, size);
  return (int)e->length;
}

EMSCRIPTEN_KEEPALIVE unsigned char *mp3_bytes(Encoder *e) { return e->out; }
EMSCRIPTEN_KEEPALIVE const char *mp3_version(void) { return get_lame_version(); }

EMSCRIPTEN_KEEPALIVE void mp3_close(Encoder *e) {
  if (!e) return;
  lame_close(e->gf);
  free(e->out);
  free(e);
}
