// One of the voice's engine's threads, in a Worker of its own (vocalwind-wasi.js threadMain): the program's module made
// on its shared memory, then each thread it is handed run to its end.
import {threadMain} from './vocalwind-wasi.js';

self.onmessage=({data})=>threadMain(data,message=>self.postMessage(message));
