// NESS (MIT; its brass, with Musebots' slide) in WebAssembly, built by scripts/build-studio.mjs (ness.mjs, ness.wasm): one
// simulation a run, as the Mac runs its binary (render/synthesis/src/ness.mjs simulated) -- its instrument and score
// files written to a file system of its own, `-i instrument.m -s score.m -o out -r`, its raw output (out.f64, the bell's
// pressure as computed) read back. Each run a fresh instance of the compiled module: NESS keeps its settings in
// statics, and a run leaves them set. The same in a page's Worker and in Node.

// The engine from its module's factory (ness.mjs's default export) and its compiled WebAssembly. -> {run}
export function nessEngine(createNess,module){
  return {
    // `files` {instrumentFile, scoreFile} (text); `strings`: a bowed instrument's run, each string's output its own file
    // (out-string<n>-<n>.f64), read in order. -> {samples (Float64Array) | outputs ([Float64Array], each string's), log}
    async run({instrumentFile,scoreFile},{strings=false}={}){
      const log=[];
      const ness=await createNess({
        instantiateWasm(imports,receive){WebAssembly.instantiate(module,imports).then(instance=>receive(instance,module));return {}},
        print:line=>log.push(line),printErr:line=>log.push(line)});
      ness.FS.mkdir('/job');ness.FS.chdir('/job');
      ness.FS.writeFile('instrument.m',instrumentFile);ness.FS.writeFile('score.m',scoreFile);
      let code=0;
      try{code=ness.callMain(['-i','instrument.m','-s','score.m','-o','out','-r','-max_threads','1'])}
      catch(error){if(error?.name!=='ExitStatus')throw error;code=error.status}
      if(code)throw new Error(`NESS stopped (${code}): ${log.slice(-6).join(' | ')}`);
      const read=name=>{const bytes=ness.FS.readFile(name);return new Float64Array(bytes.buffer,bytes.byteOffset,bytes.byteLength/8).slice()};
      if(strings){
        const names=ness.FS.readdir('.').filter(name=>/^out-string\d+-\d+\.f64$/.test(name)).sort((a,b)=>Number(a.match(/-(\d+)\.f64$/)[1])-Number(b.match(/-(\d+)\.f64$/)[1]));
        return {outputs:names.map(read),log};
      }
      return {samples:read('out.f64'),log};
    },
  };
}
