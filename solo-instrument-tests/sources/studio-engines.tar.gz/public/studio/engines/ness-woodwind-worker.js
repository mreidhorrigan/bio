// A woodwind part played on NESS in WebAssembly (ness-run.js), in a Worker of its own, as the Mac plays it on NESS by its
// player's law (render/synthesis/workers/ness_woodwind.py, openwind_passages.py render_by_rules): each breath group's
// controls shaped by the page's own OpenWInD (openwind-stream.js spec, on the woodwind's saved body), written as NESS's
// score on the body as NESS plays it (its ness.json: scripts/build-studio.mjs), run, its tail doubled until it has died
// away, the groups summed at the stem's scale (render/synthesis/src/ness-woodwind.mjs nessWoodwindPart). Told {model,
// lines (its breath groups: winds-lines.mjs partLines), render, ness, nessWasm, openwind (their URLs), body (its folder's
// URL)}, it says {progress} as it goes and then {samples, rate, tailSeconds, undecayed?, diagnostics}, or {error}.
import {nessEngine} from './ness-run.js';
import {openwindEngine} from './openwind-stream.js';

const bytesOf=async url=>{const response=await fetch(url);if(!response.ok)throw new Error(`${url}: ${response.status}`);return new Uint8Array(await response.arrayBuffer())};

onmessage=async({data:{model,lines,render,ness,nessWasm,openwind,body}})=>{
  try{
    const files=['body.json','I.bin','D.bin','law.json','rules.json','ness.json'];
    const [{nessWoodwindPart},{default:createNess},nessModule,engine,...read]=await Promise.all([import(render),import(ness),
      bytesOf(nessWasm).then(b=>WebAssembly.compile(b)),bytesOf(openwind).then(openwindEngine),...files.map(name=>bytesOf(new URL(name,body).href))]);
    const [header,I,D,law,rules,nessBody]=read;
    const player=engine.open({header,I,D,law,rules}),played=JSON.parse(new TextDecoder().decode(nessBody));
    try{
      const {samples,groups}=await nessWoodwindPart(model,lines,{shape:(line,tail)=>player.spec(line,tail),simulator:nessEngine(createNess,nessModule),body:played,
        onProgress:fraction=>postMessage({progress:Math.min(.99,fraction)})});
      const out=Float32Array.from(samples),undecayed=groups.filter(g=>g.undecayed!=null);
      postMessage({samples:out,rate:played.rate,tailSeconds:Math.max(0,...groups.map(g=>g.tailSeconds)),
        ...(undecayed.length?{undecayed:Math.max(...undecayed.map(g=>g.undecayed))}:{}),diagnostics:{groups}},[out.buffer]);
    }finally{player.close()}
  }catch(error){postMessage({error:String(error?.message??error)})}
};
