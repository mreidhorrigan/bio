// A woodwind part played on OpenWInD's streaming player in WebAssembly (openwind-stream.js), in a Worker of its own:
// told {wasm (its module's URL), body (its saved body's folder URL), lines (its breath groups)}, it says {progress} as
// it plays and then {samples, late, tailSeconds, undecayed?}, or {error}.
import {openwindEngine,renderPart} from './openwind-stream.js';

const bytesOf=async url=>{const response=await fetch(url);if(!response.ok)throw new Error(`${url}: ${response.status}`);return new Uint8Array(await response.arrayBuffer())};

onmessage=async({data:{wasm,body,lines}})=>{
  try{
    const [engine,header,I,D,law,rules]=await Promise.all([bytesOf(wasm).then(openwindEngine),...['body.json','I.bin','D.bin','law.json','rules.json'].map(name=>bytesOf(new URL(name,body).href))]);
    const player=engine.open({header,I,D,law,rules});
    let last=0;
    const result=renderPart(player,lines,{onProgress:fraction=>{if(fraction-last>=.01||fraction===1){last=fraction;postMessage({progress:fraction})}}});
    player.close();
    postMessage({samples:result.samples,late:result.late,tailSeconds:result.tailSeconds,undecayed:result.undecayed??null},[result.samples.buffer]);
  }catch(error){postMessage({error:String(error?.message??error)})}
};
