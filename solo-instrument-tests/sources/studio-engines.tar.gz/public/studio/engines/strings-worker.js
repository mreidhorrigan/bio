// A bowed string's part played on its model in WebAssembly (strings-run.js), in a Worker of its own, as the Mac plays it
// (render/node/physical-strings.mjs renderParts): its chair its seat's, its seed the piece's and its seat's, its tries
// (render/synthesis/src/strings-parts.mjs stringsPart, at most STRINGS_ANTICIPATION.tries) each a run of the driver.
// Told {entry (its seat and its strokes, read from its notes' MIDI 2.0 by the page: engines.js), track, seed, render,
// strings (its module's URL), wasm}, it says {progress} as it goes and then {samples, rate, diagnostics}, or {error}.
import {stringsEngine} from './strings-run.js';

onmessage=async({data:{entry,track,seed,render,strings,wasm}})=>{
  try{
    const [{stringsPart,hash32,STRINGS_ANTICIPATION},{default:createStrings},module]=await Promise.all([import(render),import(strings),fetch(wasm).then(r=>r.arrayBuffer()).then(b=>WebAssembly.compile(b))]);
    const engine=stringsEngine(createStrings,module),capabilities=await engine.capabilities();
    const chair=Number(String(entry.seat??'').split('.')[1])||0;
    let runs=0;
    const drive=async(actions,options)=>{const out=await engine.drive(actions,options);postMessage({progress:Math.min(.99,++runs/STRINGS_ANTICIPATION.tries)});return out};
    const {kept,tries}=await stringsPart(entry,{chair,seed:hash32(`${seed}:${entry.seat??track}`),capabilities,drive});
    const samples=kept.samples.slice(),ms=e=>e==null?null:Math.round(e*1000);
    postMessage({samples,rate:kept.rate,diagnostics:{instrument:kept.compiled.instrument,type:kept.compiled.type,variant:kept.compiled.variant,strokes:entry.log.length,
      outputScale:kept.outputScale,warnings:kept.compiled.warnings,
      anticipation:{kept:tries.indexOf(kept)+1,tries:tries.map(t=>({leadsMs:t.leads.map(ms),heardMs:t.heard.map(ms)}))}}},[samples.buffer]);
  }catch(error){postMessage({error:String(error?.message??error)})}
};
