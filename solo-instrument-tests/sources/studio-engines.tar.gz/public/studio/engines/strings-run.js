// The bowed strings' render driver (native/strings-model/musebots-strings.cpp: Artifastring as Musebots patch it, through
// its body) in WebAssembly, built by scripts/build-studio.mjs (strings.mjs, strings.wasm): one player's actions a run, as
// the Mac runs its driver (render/node/physical-strings.mjs) -- `ACTIONS OUT.wav TYPE VARIANT SEED [SILENT]` on a file
// system of its own, its float WAV and its restarts read back. Each run a fresh instance of the compiled module, as each
// of the Mac's is a process of its own. The same in a page's Worker and in Node.
import {floatWav} from '../../shared/float-wav.js';

export function stringsEngine(createStrings,module){
  const instance=async log=>createStrings({
    instantiateWasm(imports,receive){WebAssembly.instantiate(module,imports).then(made=>receive(made,module));return {}},
    print:line=>log.push(line),printErr:line=>log.push(line)});
  const call=(strings,args)=>{try{return strings.callMain(args)}catch(error){if(error?.name!=='ExitStatus')throw error;return error.status}};
  return {
    // What the driver can do (its --capabilities).
    async capabilities(){const log=[],strings=await instance(log);call(strings,['--capabilities']);try{return JSON.parse(log.join('\n'))}catch{return {}}},
    // One player's actions (text). -> {samples (its own output), rate, broken, brokenAt, said, recovered}
    async drive(actions,{type,variant,seed,silent=null}){
      const log=[],strings=await instance(log);
      strings.FS.mkdir('/job');strings.FS.chdir('/job');strings.FS.writeFile('part.actions',actions);
      const code=call(strings,['part.actions','part.wav',String(type),String(variant),String(seed),...(silent!=null?[String(silent)]:[])]);
      if(code)throw new Error(`the strings' driver stopped (${code}): ${log.slice(-6).join(' | ')}`);
      const recovered=strings.FS.analyzePath('part.wav.recoveries').exists?new TextDecoder().decode(strings.FS.readFile('part.wav.recoveries')).trim().split('\n').map(Number).filter(Number.isFinite):[];
      return {...floatWav(strings.FS.readFile('part.wav')),said:log.join('\n'),recovered};
    },
    // Each string's force on the bridge (`forces`: four Float64Arrays at the driver's rate, lowest string first -- another
    // engine's strings, NESS's) heard through the instrument's body as its own strings' are (the driver's `--body`).
    // -> {samples, rate, broken, brokenAt}
    async body(forces,{type,variant}){
      const log=[],strings=await instance(log),frames=Math.max(...forces.map(f=>f.length)),rate=44100;
      const bytes=new Uint8Array(44+16*frames),view=new DataView(bytes.buffer),text=(at,word)=>[...word].forEach((c,k)=>bytes[at+k]=c.charCodeAt(0));
      text(0,'RIFF');view.setUint32(4,36+16*frames,true);text(8,'WAVEfmt ');view.setUint32(16,16,true);view.setUint16(20,3,true);view.setUint16(22,4,true);
      view.setUint32(24,rate,true);view.setUint32(28,16*rate,true);view.setUint16(32,16,true);view.setUint16(34,32,true);text(36,'data');view.setUint32(40,16*frames,true);
      forces.forEach((f,s)=>{for(let i=0;i<f.length;i++)view.setFloat32(44+16*i+4*s,f[i],true)});
      strings.FS.mkdir('/job');strings.FS.chdir('/job');strings.FS.writeFile('forces.wav',bytes);
      const code=call(strings,['--body','forces.wav','sound.wav',String(type),String(variant)]);
      if(code)throw new Error(`the strings' driver did not hear the forces through its body (${code}): ${log.slice(-6).join(' | ')}`);
      return floatWav(strings.FS.readFile('sound.wav'));
    },
  };
}
