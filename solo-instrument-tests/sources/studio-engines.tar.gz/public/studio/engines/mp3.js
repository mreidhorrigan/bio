// The studio page's MP3 encoder: LAME in WebAssembly (native/mp3-wasm/mp3.c, built by scripts/build-studio.mjs as
// mp3.mjs and mp3.wasm), driven as the Mac's ffmpeg drives LAME for an étude's mix (scripts/master-render.mjs
// encodeMp3). The same in a page's Worker (mp3-worker.js) and in Node.

// (Frames handed to LAME a call: a second at 48 kHz.)
const CHUNK=48000;

// The module made from its compiled bytes (`module` a WebAssembly.Module). -> {version, encode}
export async function mp3Encoder(createMp3,module){
  const lame=await createMp3({instantiateWasm(imports,receive){WebAssembly.instantiate(module,imports).then(made=>receive(made,module));return {}}});
  // (A string as UTF-16 with its byte-order mark, ended by a zero, in LAME's memory.)
  const utf16=text=>{const s=String(text),units=[0xfeff];for(let k=0;k<s.length;k++)units.push(s.charCodeAt(k));units.push(0);const at=lame._malloc(units.length*2);lame.HEAPU16.set(units,at/2);return at};
  const ascii=text=>{const bytes=[...String(text)].map(c=>c.charCodeAt(0)),at=lame._malloc(bytes.length+1);lame.HEAPU8.set([...bytes,0],at);return at};
  return {
    version:lame.UTF8ToString(lame._mp3_version()),
    // `channels` [Float32Array] (one or two) at `sampleRate`, `kbps` its constant bit rate, `tags` {title, comment,
    // encodedBy}. -> its bytes (Uint8Array)
    encode(channels,sampleRate,{kbps=320,tags={}}={}){
      const encoder=lame._mp3_open(channels.length,sampleRate,kbps);
      if(!encoder)throw new Error('LAME could not begin an encoder');
      const held=[];
      try{
        for(const [id,text] of [['TIT2',tags.title],['COMM',tags.comment],['TENC',tags.encodedBy]].filter(([,text])=>text)){
          const at=[ascii(id),utf16(text)];held.push(...at);
          if(lame._mp3_tag(encoder,...at)!==0)throw new Error(`LAME could not tag ${id}`);
        }
        const left=lame._malloc(CHUNK*4),right=lame._malloc(CHUNK*4);held.push(left,right);
        const frames=channels[0].length;
        for(let from=0;from<frames;from+=CHUNK){
          const n=Math.min(CHUNK,frames-from);
          lame.HEAPF32.set(channels[0].subarray(from,from+n),left/4);
          lame.HEAPF32.set((channels[1]??channels[0]).subarray(from,from+n),right/4);
          const said=lame._mp3_encode(encoder,left,right,n);
          if(said!==0)throw new Error(`LAME stopped encoding (${said})`);
        }
        const length=lame._mp3_finish(encoder);
        if(length<0)throw new Error(`LAME could not finish (${length})`);
        const at=lame._mp3_bytes(encoder);
        return lame.HEAPU8.slice(at,at+length);
      }finally{for(const at of held)lame._free(at);lame._mp3_close(encoder)}
    },
  };
}
