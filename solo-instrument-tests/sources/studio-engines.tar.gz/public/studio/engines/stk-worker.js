// A part played on STK's waveguides in WebAssembly (render/synthesis/src/stk.mjs), in a Worker of its own: the module the
// Mac's renders play it on (render.mjs, backend 'stk'; scripts/build-stk.mjs), played alike, its noise seeded by its
// notes, so that the page and the Mac play a part to the bit. Told {part (compilePhysicalEvents'), sampleRate, render (the
// page's render.js), stk (its module's URL), wasm}, it says {samples, tailSeconds, diagnostics}, or {error}.
onmessage=async({data:{part,sampleRate,render,stk,wasm}})=>{
  try{
    const [{stkEngine,stkPart},{default:createStk},module]=await Promise.all([import(render),import(stk),fetch(wasm).then(r=>r.arrayBuffer()).then(b=>WebAssembly.compile(b))]);
    const engine=stkEngine(await createStk({instantiateWasm(imports,receive){WebAssembly.instantiate(module,imports).then(instance=>receive(instance,module));return {}}}));
    const {samples,model,seed,tailSeconds}=stkPart(engine,part,{sampleRate}),own=samples.slice();
    postMessage({samples:own,tailSeconds,diagnostics:{model,seed,warnings:[]}},[own.buffer]);
  }catch(error){postMessage({error:String(error?.message??error)})}
};
