// The voice's engine in a page: VocalTractLab in Rust (native/vocaltract: VocalWind 4.0, VocalFork 3.0, 2.4), its own
// programs -- vtl-stream, the streaming player; vtl-blend, which makes a singer's body -- built for
// wasm32-wasip1-threads as they stand and run here as their command lines run them (the owner, 18 November 2026: "Add
// the Renaissance counterpoint making capacity to our studio / instrument-test website"; of the engine: "The most
// recent counterpoint renders have been with our VocalWind 4.0 development from VTL"). Nothing of the engine is
// written again for the page: a program is given its arguments, its environment and its files, and what it reads and
// writes is the host's below (WASI preview 1) -- its files held in memory, its standard input a line the page writes
// (a mailbox, read where the program waits), its standard output handed on as it is written, each thread it starts a
// Worker sharing its memory (wasi-threads). Three Workers' work, so that what asks the engine to sing only sends it
// messages (docs/SITE_LICENSING.md, "Where the line is drawn"): an overseer that never waits and passes them on
// (vocalwind-worker.js), the program's own, which waits on its input (vocalwind-program.js), and its threads'
// (vocalwind-thread.js). The same in a page's Workers and in Node's.
//   oversee(bytes, {args, env, files, back, threads, program, thread, tell}) -> {line(text), close(), end()}
//   programMain(given, say), threadMain(given, say)     the program's own Worker's work, and a thread's
import {memoryLimits} from './openwind-stream.js';

// WASI preview 1, by its names: what a call answers, a file's kind, what an opening asks, where a seek is from, the
// descriptors a program begins with (its folder the one after them), a subscription's and an event's layout.
const OK=0,BADF=8,EXIST=20,INVAL=28,NOENT=44,NOSYS=52,NOTDIR=54;
const CHARACTER_DEVICE=2,DIRECTORY=3,REGULAR_FILE=4;
const O_CREAT=1,O_DIRECTORY=2,O_EXCL=4,O_TRUNC=8,APPEND=1;
const SET=0,CURRENT=1;
const STDIN=0,STDOUT=1,STDERR=2,ROOT=3;
const IOVEC=8,FDSTAT=24,FILESTAT=64,FILETYPE_AT=16,SIZE_AT=32,NLINK_AT=24,RIGHTS_AT=8,INHERITING_AT=16,NAME_LENGTH_AT=4;
const SUBSCRIPTION=48,EVENT=32,TAG_AT=8,TIMEOUT_AT=24,ERROR_AT=8,TYPE_AT=10,CLOCK=0;
const EVERY_RIGHT=0xFFFFFFFFFFFFFFFFn,NS_PER_MS=1e6,RANDOM_AT_ONCE=65536,WORD=4;
// A mailbox: its header's words -- how many bytes wait, how many of them were taken, whether it is shut -- and its
// room, bytes (a phrase's line of pitch is its longest: tens of kilobytes).
const WAITING=0,TAKEN=1,SHUT=2,HEADER=3,ROOM=4<<20;
// Its threads' Workers: a slot each of a block they share -- its state, the thread's id, where it starts -- after the
// block's own word, the last id given; the most Workers a program is made.
const LAST_ID=0,HEAD=1,SLOT=3,STATE=0,ID=1,START=2,IDLE=0,ASKED=1,RUNNING=2,END=3,CLAIMED=4,MOST=24;

const decoder=new TextDecoder(),encoder=new TextEncoder();

// ---- a program's standard input, written by its overseer ----
const mailbox=()=>new SharedArrayBuffer(HEADER*WORD+ROOM);
// (A line written where the last was taken whole -- the program answers each before the next is asked.)
function post(buffer,text){
  const header=new Int32Array(buffer,0,HEADER),bytes=encoder.encode(text);
  if(bytes.length>ROOM)throw new Error(`a line of ${bytes.length} bytes is more than the engine's input holds (${ROOM})`);
  if(Atomics.load(header,WAITING))throw new Error('the engine has not taken its last line');
  new Uint8Array(buffer,HEADER*WORD,bytes.length).set(bytes);
  Atomics.store(header,TAKEN,0);Atomics.store(header,WAITING,bytes.length);Atomics.notify(header,WAITING);
}
function shut(buffer){const header=new Int32Array(buffer,0,HEADER);Atomics.store(header,SHUT,1);Atomics.notify(header,WAITING)}
// (Read where the program waits: up to `most` bytes of what waits, none once it is shut and empty.)
function reader(buffer){
  const header=new Int32Array(buffer,0,HEADER);
  return most=>{
    while(!Atomics.load(header,WAITING)){if(Atomics.load(header,SHUT))return new Uint8Array(0);Atomics.wait(header,WAITING,0)}
    const waiting=Atomics.load(header,WAITING),taken=Atomics.load(header,TAKEN),n=Math.min(most,waiting-taken);
    const out=new Uint8Array(buffer,HEADER*WORD+taken,n).slice();
    if(taken+n===waiting){Atomics.store(header,TAKEN,0);Atomics.store(header,WAITING,0)}else Atomics.store(header,TAKEN,taken+n);
    return out;
  };
}

// ---- its threads ----
// A thread handed to a Worker that waits for one (wasi-threads' thread-spawn), from whichever of its threads asks:
// -> its id, or -1 where every Worker is busy.
const spawner=control=>start=>{
  for(let at=HEAD;at<control.length;at+=SLOT){
    // (Claimed, then its thread written, then asked: a Worker never reads a thread half written.)
    if(Atomics.compareExchange(control,at+STATE,IDLE,CLAIMED)!==IDLE)continue;
    const id=Atomics.add(control,LAST_ID,1)+1;
    Atomics.store(control,at+ID,id);Atomics.store(control,at+START,start);Atomics.store(control,at+STATE,ASKED);Atomics.notify(control,at+STATE);
    return id;
  }
  return -1;
};
class Exit{constructor(code){this.code=code}}

// ---- what a program asks of its host ----
// `files`: Map path -> bytes, each path from the root; a folder is what a file lies under. `take`: its standard input
// (reader's), or none; `out(bytes)`: its standard output as written; `said(text)`: its standard error, a line at a time.
function host(memory,{args=[],env={},files=new Map,take=null,out=()=>{},said=()=>{}}={}){
  const view=()=>new DataView(memory.buffer),bytesAt=(at,n)=>new Uint8Array(memory.buffer,at,n);
  // (Text from its memory: copied out first, as a browser decodes no view of shared memory.)
  const textAt=(at,n)=>decoder.decode(bytesAt(at,n).slice());
  const open=new Map([[ROOT,{path:'/',folder:true}]]),made=new Set(['/']);let next=ROOT+1,line='';
  const normal=path=>{const parts=[];for(const part of path.split('/')){if(!part||part==='.')continue;if(part==='..')parts.pop();else parts.push(part)}return `/${parts.join('/')}`};
  const isFolder=path=>made.has(path)||[...files.keys()].some(name=>name.startsWith(path==='/'?'/':`${path}/`));
  const under=(fd,at,n)=>{const base=open.get(fd);if(!base?.folder)return null;const named=textAt(at,n);return normal(named.startsWith('/')?named:`${base.path}/${named}`)};
  // (A list of strings as a program is given its arguments and its environment: their count and their bytes, then each
  // one's place and its bytes, ended by a zero.)
  const strings=list=>{const encoded=list.map(text=>encoder.encode(`${text}\0`));
    return {sizes(count,size){view().setUint32(count,encoded.length,true);view().setUint32(size,encoded.reduce((n,b)=>n+b.length,0),true);return OK},
      get(places,buffer){let at=buffer;encoded.forEach((b,k)=>{view().setUint32(places+WORD*k,at,true);bytesAt(at,b.length).set(b);at+=b.length});return OK}}};
  const argv=strings(args),environ=strings(Object.entries(env).map(([key,value])=>`${key}=${value}`));
  const vectors=(iovs,n)=>Array.from({length:n},(_,k)=>({at:view().getUint32(iovs+IOVEC*k,true),length:view().getUint32(iovs+IOVEC*k+WORD,true)}));
  const stat=(at,kind,size)=>{bytesAt(at,FILESTAT).fill(0);view().setUint8(at+FILETYPE_AT,kind);view().setBigUint64(at+NLINK_AT,1n,true);view().setBigUint64(at+SIZE_AT,BigInt(size),true);return OK};
  const kindOf=fd=>fd<=STDERR?CHARACTER_DEVICE:open.get(fd)?.folder?DIRECTORY:REGULAR_FILE;
  return {
    args_sizes_get:argv.sizes,args_get:argv.get,environ_sizes_get:environ.sizes,environ_get:environ.get,
    clock_time_get(id,precision,at){view().setBigUint64(at,BigInt(Math.round((id===0?Date.now():performance.timeOrigin+performance.now())*NS_PER_MS)),true);return OK},
    random_get(at,length){for(let k=0;k<length;k+=RANDOM_AT_ONCE){const n=Math.min(RANDOM_AT_ONCE,length-k);bytesAt(at+k,n).set(crypto.getRandomValues(new Uint8Array(n)))}return OK},
    sched_yield:()=>OK,
    proc_exit(code){throw new Exit(code)},
    // (A wait for a time alone -- a thread's sleep: waited out here, where a Worker may wait.)
    poll_oneoff(subscriptions,events,n,count){
      let wait=0,clocks=0;
      for(let k=0;k<n;k++){const at=subscriptions+SUBSCRIPTION*k;if(view().getUint8(at+TAG_AT)!==CLOCK)continue;
        wait=Math.max(wait,Number(view().getBigUint64(at+TIMEOUT_AT,true))/NS_PER_MS);
        const event=events+EVENT*clocks++;bytesAt(event,EVENT).fill(0);view().setBigUint64(event,view().getBigUint64(at,true),true);view().setUint16(event+ERROR_AT,OK,true);view().setUint8(event+TYPE_AT,CLOCK)}
      if(!clocks)return NOSYS;
      if(wait>0)Atomics.wait(new Int32Array(new SharedArrayBuffer(WORD)),0,0,wait);
      view().setUint32(count,clocks,true);return OK;
    },
    fd_prestat_get(fd,at){if(fd!==ROOT)return BADF;view().setUint8(at,0);view().setUint32(at+NAME_LENGTH_AT,1,true);return OK},
    fd_prestat_dir_name(fd,at,length){if(fd!==ROOT)return BADF;bytesAt(at,Math.min(1,length)).set(encoder.encode('/'));return OK},
    fd_fdstat_get(fd,at){if(fd>STDERR&&!open.has(fd))return BADF;bytesAt(at,FDSTAT).fill(0);view().setUint8(at,kindOf(fd));
      view().setBigUint64(at+RIGHTS_AT,EVERY_RIGHT,true);view().setBigUint64(at+INHERITING_AT,EVERY_RIGHT,true);return OK},
    fd_fdstat_set_flags:()=>OK,
    fd_filestat_get(fd,at){if(fd<=STDERR)return stat(at,CHARACTER_DEVICE,0);const file=open.get(fd);if(!file)return BADF;return stat(at,kindOf(fd),file.folder?0:files.get(file.path)?.length??0)},
    path_filestat_get(fd,flags,path,length,at){const named=under(fd,path,length);if(named===null)return BADF;
      return files.has(named)?stat(at,REGULAR_FILE,files.get(named).length):isFolder(named)?stat(at,DIRECTORY,0):NOENT},
    path_create_directory(fd,path,length){const named=under(fd,path,length);if(named===null)return BADF;if(files.has(named))return EXIST;made.add(named);return OK},
    path_open(fd,lookup,path,length,asks,rights,inheriting,flags,at){
      const named=under(fd,path,length);if(named===null)return BADF;
      if(files.has(named)){
        if(asks&O_DIRECTORY)return NOTDIR;if(asks&O_CREAT&&asks&O_EXCL)return EXIST;
        if(asks&O_TRUNC)files.set(named,new Uint8Array(0));
        open.set(next,{path:named,at:0,append:Boolean(flags&APPEND)});
      }else if(isFolder(named)&&!(asks&O_CREAT))open.set(next,{path:named,folder:true});
      else if(asks&O_CREAT&&isFolder(normal(`${named}/..`))){files.set(named,new Uint8Array(0));open.set(next,{path:named,at:0,append:Boolean(flags&APPEND)})}
      else return NOENT;
      view().setUint32(at,next++,true);return OK;
    },
    fd_close(fd){return open.delete(fd)||fd<=STDERR?OK:BADF},
    fd_seek(fd,offset,whence,at){const file=open.get(fd);if(!file||file.folder)return BADF;
      const size=files.get(file.path).length,to=Number(offset)+(whence===SET?0:whence===CURRENT?file.at:size);
      if(to<0)return INVAL;file.at=to;view().setBigUint64(at,BigInt(to),true);return OK},
    fd_read(fd,iovs,n,read){
      let total=0;
      if(fd===STDIN){
        // (What waits is taken into its first room; no more is waited for once some is had.)
        for(const {at,length} of vectors(iovs,n)){if(!length)continue;const taken=take?take(length):new Uint8Array(0);bytesAt(at,taken.length).set(taken);total+=taken.length;break}
      }else{
        const file=open.get(fd);if(!file||file.folder)return BADF;
        const data=files.get(file.path);
        for(const {at,length} of vectors(iovs,n)){const k=Math.min(length,data.length-file.at);if(k<=0)break;bytesAt(at,k).set(data.subarray(file.at,file.at+k));file.at+=k;total+=k}
      }
      view().setUint32(read,total,true);return OK;
    },
    fd_write(fd,iovs,n,written){
      let total=0;
      for(const {at,length} of vectors(iovs,n)){
        if(!length)continue;
        if(fd===STDOUT)out(bytesAt(at,length).slice());
        else if(fd===STDERR){line+=textAt(at,length);for(let end;(end=line.indexOf('\n'))>=0;line=line.slice(end+1))said(line.slice(0,end))}
        else{
          const file=open.get(fd);if(!file||file.folder)return BADF;
          const data=files.get(file.path),from=file.append?data.length:file.at,grown=new Uint8Array(Math.max(data.length,from+length));
          grown.set(data);grown.set(bytesAt(at,length),from);files.set(file.path,grown);file.at=from+length;
        }
        total+=length;
      }
      view().setUint32(written,total,true);return OK;
    },
  };
}
// (Every call a program's module asks of its host: those above, and any other answered that the host has none, said
// once -- a module is not made without each of its imports.)
function asked(module,calls,said){
  const told=new Set;
  for(const {module:from,name,kind} of WebAssembly.Module.imports(module))if(from==='wasi_snapshot_preview1'&&kind==='function'&&!calls[name])
    calls[name]=()=>{if(!told.has(name)){told.add(name);said(`the engine asked its host for ${name}, which it has not`)}return NOSYS};
  return calls;
}

// A program overseen from a Worker that never waits (vocalwind-worker.js): its module compiled and its memory made
// here, a Worker made for each thread it may start (`thread()`, `threads` of them, each ready before it begins: a
// program that waits can make none), then its own Worker (`program()`), where it runs as its command line runs it and
// waits on its input. `tell(message, transfer)` hears what it does: {out} its standard output as written, {said} a
// line of its or a thread's standard error, {failed} a thread that stopped, {exit, files} its end with the files asked
// back of it (`back`: paths), {error}. -> {line(text): written to its standard input, close(): its input shut, end()}.
export async function oversee(bytes,{args=[],env={},files=[],back=[],threads=0,program,thread,tell}){
  const limits=memoryLimits(bytes);
  if(!limits?.shared)throw new Error('the voice\'s engine is built for threads, and this module shares no memory');
  if(typeof SharedArrayBuffer==='undefined')throw new Error('the voice\'s engine needs shared memory, which this page has not (it is not cross-origin isolated)');
  const module=await WebAssembly.compile(bytes),memory=new WebAssembly.Memory({initial:limits.initial,maximum:limits.maximum,shared:true});
  const count=Math.min(MOST,threads),control=new Int32Array(new SharedArrayBuffer(WORD*(HEAD+SLOT*count))),input=mailbox(),workers=[];
  const end=()=>{for(let at=HEAD;at<control.length;at+=SLOT){Atomics.store(control,at+STATE,END);Atomics.notify(control,at+STATE)}for(const worker of workers)worker.terminate?.()};
  // (A page's Worker, or Node's worker_threads one, a test's: what it sends, and that it failed.)
  const heard=(worker,told)=>{if(typeof worker.on==='function'){worker.on('message',told);worker.on('error',error=>told({error:error.message}))}
    else{worker.onmessage=event=>told(event.data);worker.onerror=event=>told({error:event.message??'its Worker failed'})}};
  try{
    for(let k=0;k<count;k++){
      const worker=thread();workers.push(worker);
      await new Promise((done,fail)=>{heard(worker,m=>{if(m==='ready')done();else if(m?.error)fail(new Error(m.error));else tell(m)});worker.postMessage({module,memory,control,at:HEAD+SLOT*k})});
    }
    const main=program();workers.push(main);
    heard(main,m=>{if(m?.out)tell({out:m.out},[m.out.buffer]);else{if(m&&('exit' in m||m.error))end();tell(m)}});
    main.postMessage({module,memory,control,input,args,env,files,back});
  }catch(error){end();throw error}
  return {line:text=>post(input,text),close:()=>shut(input),end};
}

// A program in its own Worker (vocalwind-program.js), run to its end as its command line runs it: its module made on
// the memory it is handed, its standard input the mailbox, its files held here. `say(message, transfer)`: {out} its
// standard output as written, {said} its standard error a line at a time, then {exit, files} or {error}.
export async function programMain({module,memory,control,input,args,env,files,back=[]},say){
  const held=new Map(files);
  try{
    const said=text=>say({said:text}),calls=asked(module,host(memory,{args,env,files:held,take:reader(input),out:bytes=>say({out:bytes},[bytes.buffer]),said}),said);
    const instance=await WebAssembly.instantiate(module,{env:{memory},wasi_snapshot_preview1:calls,wasi:{'thread-spawn':spawner(control)}});
    let exit=0;
    try{instance.exports._start()}catch(error){if(error instanceof Exit)exit=error.code;else throw error}
    say({exit,files:back.map(path=>[path,held.get(path)??null])});
  }catch(error){say({error:String(error?.message??error)})}
}

// One of a program's threads' Workers (vocalwind-thread.js): the module made on the program's memory, then each thread
// it is handed run to its end (wasi-threads' wasi_thread_start), and the next waited for on its slot. `say(message)`:
// 'ready' or {error} as it is made; {said} what a thread writes to its standard error; {failed} a thread that stopped.
export async function threadMain({module,memory,control,at},say){
  const said=text=>say({said:text});
  let instance;
  try{instance=await WebAssembly.instantiate(module,{env:{memory},wasi_snapshot_preview1:asked(module,host(memory,{said}),said),wasi:{'thread-spawn':spawner(control)}})}
  catch(error){say({error:error.message});return}
  say('ready');
  for(;;){
    // (Waited on while idle, or while a thread is being written to it.)
    const state=Atomics.load(control,at+STATE);
    if(state===END)break;
    if(state!==ASKED){Atomics.wait(control,at+STATE,state);continue}
    Atomics.store(control,at+STATE,RUNNING);
    try{instance.exports.wasi_thread_start(Atomics.load(control,at+ID),Atomics.load(control,at+START))}
    catch(error){if(!(error instanceof Exit))say({failed:`a thread of the voice's engine stopped: ${error.message}`})}
    Atomics.compareExchange(control,at+STATE,RUNNING,IDLE);
  }
}
