// One of the voice's engine's programs, in a Worker of its own (vocalwind-wasi.js programMain): made on the memory its
// overseer hands it and run to its end as its command line runs it, waiting on its standard input where it reads it.
import {programMain} from './vocalwind-wasi.js';

self.onmessage=({data})=>programMain(data,(message,transfer=[])=>self.postMessage(message,transfer));
