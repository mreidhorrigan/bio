// The mix encoded as MP3 in a Worker of its own (mp3.js), the page free meanwhile. Told {channels, sampleRate, kbps,
// tags, mp3 (its module's URL), wasm}, it says {bytes, version}, or {error}.
import {mp3Encoder} from './mp3.js';

onmessage=async({data:{channels,sampleRate,kbps,tags,mp3,wasm}})=>{
  try{
    const [{default:createMp3},module]=await Promise.all([import(mp3),fetch(wasm).then(r=>r.arrayBuffer()).then(b=>WebAssembly.compile(b))]);
    const encoder=await mp3Encoder(createMp3,module),bytes=encoder.encode(channels,sampleRate,{kbps,tags});
    postMessage({bytes,version:encoder.version},[bytes.buffer]);
  }catch(error){postMessage({error:String(error?.message??error)})}
};
