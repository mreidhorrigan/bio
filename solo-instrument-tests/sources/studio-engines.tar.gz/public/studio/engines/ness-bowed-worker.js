// A bowed string's part played on NESS in WebAssembly (ness-run.js), in a Worker of its own, as the Mac plays it
// (render/node/physical-strings.mjs renderParts, backend 'ness'): its player's strokes compiled and tried as on
// Artifastring (render/synthesis/src/strings-parts.mjs stringsPart), each try planned for NESS as the Mac's worker plans it
// (render/synthesis/src/ness-bowed.mjs, held to workers/ness_bowed.py), run, its strings' forces on the bridge heard
// through the instrument's body by the strings' driver in WebAssembly (strings-run.js body: its `--body`), and ended where
// it has rung down. Told {entry, track, seed, render, ness, nessWasm, strings, stringsWasm, tables (the strings' tables'
// URL: scripts/build-studio.mjs)}, it says {progress} as it goes and then {samples, rate, diagnostics}, or {error}.
import {nessEngine} from './ness-run.js';
import {stringsEngine} from './strings-run.js';

// (What NESS's player can do, as the strings' driver says it: physical-strings.mjs NESS_CAPABILITIES.)
const CAPABILITIES=Object.freeze({ringsDown:true,body:true,ramps:true});

onmessage=async({data:{entry,track,seed,render,ness,nessWasm,strings,stringsWasm,tables:tablesUrl}})=>{
  try{
    const compiled=url=>fetch(url).then(r=>r.arrayBuffer()).then(b=>WebAssembly.compile(b));
    const [bundle,{default:createNess},nessModule,{default:createStrings},stringsModule,tables]=await Promise.all([import(render),import(ness),compiled(nessWasm),
      import(strings),compiled(stringsWasm),fetch(tablesUrl).then(r=>r.json())]);
    const {stringsPart,hash32,STRINGS_ANTICIPATION,nessBowedPlan,nessBridgeForces,nessRungDown,NESS_SILENT}=bundle;
    const simulator=nessEngine(createNess,nessModule),body=stringsEngine(createStrings,stringsModule);
    const chair=Number(String(entry.seat??'').split('.')[1])||0;
    let runs=0;
    const drive=async(actions,{type,variant,silent=null})=>{
      const plan=nessBowedPlan(actions,type,variant,{tables,silent});
      const {outputs}=await simulator.run({instrumentFile:plan.instrumentFile,scoreFile:plan.scoreFile},{strings:true});
      if(outputs.length!==plan.strings.length)throw new Error(`NESS gave ${outputs.length} strings' outputs for ${plan.strings.length}`);
      const sound=await body.body(nessBridgeForces(outputs,plan),{type,variant});
      const samples=nessRungDown(sound.samples,plan.last,silent??NESS_SILENT);
      // (What NESS's string has not, said once a kind; a sound not rung down where asked, said as the driver says it.)
      const kinds=new Map;for(const [,,why] of plan.left)kinds.set(why,(kinds.get(why)??0)+1);
      let tail=0;for(let i=Math.max(0,samples.length-441);i<samples.length;i++)tail=Math.max(tail,Math.abs(samples[i]));
      postMessage({progress:Math.min(.99,++runs/STRINGS_ANTICIPATION.tries)});
      return {...sound,samples,said:silent!=null&&tail>=silent?`not rung down: its last 10 ms at ${tail.toPrecision(3)}, over ${silent.toPrecision(3)}`:'',recovered:[],
        warnings:[...kinds].map(([why,count])=>`NESS left out ${count} action${count===1?'':'s'}: ${why}`)};
    };
    const {kept,tries}=await stringsPart(entry,{chair,seed:hash32(`${seed}:${entry.seat??track}`),capabilities:CAPABILITIES,drive});
    const samples=kept.samples.slice(),ms=e=>e==null?null:Math.round(e*1000);
    postMessage({samples,rate:kept.rate,diagnostics:{instrument:kept.compiled.instrument,type:kept.compiled.type,variant:kept.compiled.variant,strokes:entry.log.length,
      outputScale:kept.outputScale,warnings:kept.compiled.warnings,
      anticipation:{kept:tries.indexOf(kept)+1,tries:tries.map(t=>({leadsMs:t.leads.map(ms),heardMs:t.heard.map(ms)}))}}},[samples.buffer]);
  }catch(error){postMessage({error:String(error?.message??error)})}
};
