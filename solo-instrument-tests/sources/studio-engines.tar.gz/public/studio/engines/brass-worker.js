// A brass part played on NESS in WebAssembly (ness-run.js), in a Worker of its own: its notes planned as the Mac plans
// them (render/synthesis/src/ness.mjs renderNessBrass: each note by its player's law -- its chart's fingering or slide
// position, its lips at its partial's lock, its breath by its dynamic -- each breath group played once), each run NESS in
// WebAssembly. Told {part (compilePhysicalEvents'), sampleRate, ness (its module's URL), wasm}, it says
// {progress} as it goes and then {samples, diagnostics}, or {error}.
import {nessEngine} from './ness-run.js';

onmessage=async({data:{part,sampleRate,render,ness,wasm}})=>{
  try{
    const [{renderNessBrass,NESS_CALIBRATIONS},{default:createNess},module]=await Promise.all([import(render),import(ness),fetch(wasm).then(r=>r.arrayBuffer()).then(b=>WebAssembly.compile(b))]);
    const engine=nessEngine(createNess,module),end=Math.max(...part.notes.map(n=>n.endSeconds));
    let runs=0;
    // (Each run's raw output as the Mac's process reads it: ness-process.mjs, a value not finite read as silence.)
    const simulate=async files=>{
      const {samples}=await engine.run(files),out=new Float32Array(samples.length);
      for(let i=0;i<samples.length;i++)out[i]=Number.isFinite(samples[i])?samples[i]:0;
      postMessage({progress:Math.min(.99,++runs/(2*part.notes.length+2))});
      return out;
    };
    // (Built from NESS's source with Musebots' slide and inward-lips patches, as the Mac's: scripts/build-ness.mjs.)
    const stem=await renderNessBrass(part,sampleRate,{kind:'ness',build:{capabilities:['slide','inward-lips']}},{calibrations:NESS_CALIBRATIONS,simulate});
    postMessage({samples:stem.samples,diagnostics:stem.diagnostics,end},[stem.samples.buffer]);
  }catch(error){postMessage({error:String(error?.message??error)})}
};
