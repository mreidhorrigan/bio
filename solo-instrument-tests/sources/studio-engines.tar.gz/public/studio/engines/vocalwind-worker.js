// The voice's engine overseen in a Worker (vocalwind-wasi.js oversee): one of its own programs -- vtl-stream, the
// streaming player; vtl-blend, which makes a singer's body -- fetched and run as its command line runs it, in a Worker
// of its own with its threads' beside it. What starts this Worker sends it the program and what it is given ({program
// (its module's address), args, env, files: [[path, bytes]], back: [paths], threads}), then each line of its standard
// input ({line}), and at last {close}; and hears {out} (its standard output as written), {said} (its standard error, a
// line at a time), {failed} (a thread that stopped), and {exit, files} or {error}. Nothing of the Musebots' own runs
// here: what asks the engine to sing speaks to it in its own command lines, from outside (docs/SITE_LICENSING.md,
// "Where the line is drawn").
import {oversee} from './vocalwind-wasi.js';

let overseen=null;
self.onmessage=({data})=>{
  if(data.line!==undefined){overseen?.then(program=>program?.line(data.line)).catch(error=>self.postMessage({error:String(error?.message??error)}));return}
  if(data.close){overseen?.then(program=>program?.close());return}
  overseen=(async()=>{
    const response=await fetch(data.program);
    if(!response.ok)throw new Error(`${data.program}: ${response.status}`);
    return oversee(new Uint8Array(await response.arrayBuffer()),{...data,
      program:()=>new Worker(new URL('./vocalwind-program.js',import.meta.url),{type:'module'}),
      thread:()=>new Worker(new URL('./vocalwind-thread.js',import.meta.url),{type:'module'}),
      tell:(message,transfer=[])=>self.postMessage(message,transfer)});
  })().catch(error=>{self.postMessage({error:String(error?.message??error)});return null});
};
