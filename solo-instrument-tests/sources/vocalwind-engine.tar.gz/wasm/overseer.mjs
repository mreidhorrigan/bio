// The voice's engine's overseer in one of Node's Workers, as public/studio/engines/vocalwind-worker.js is in a page's
// (wasm-voice.mjs): the same messages in and out, its program read from a file and its Workers Node's.
import {parentPort,Worker} from 'node:worker_threads';
import {readFileSync} from 'node:fs';
import {oversee} from '../../../public/studio/engines/vocalwind-wasi.js';

let overseen=null;
parentPort.on('message',data=>{
  if(data.line!==undefined){overseen?.then(program=>program?.line(data.line)).catch(error=>parentPort.postMessage({error:String(error?.message??error)}));return}
  if(data.close){overseen?.then(program=>program?.close());return}
  overseen=(async()=>oversee(new Uint8Array(readFileSync(data.program)),{...data,
    program:()=>new Worker(new URL('./program.mjs',import.meta.url)),thread:()=>new Worker(new URL('./thread.mjs',import.meta.url)),
    tell:(message,transfer=[])=>parentPort.postMessage(message,transfer)}))().catch(error=>{parentPort.postMessage({error:String(error?.message??error)});return null});
});
