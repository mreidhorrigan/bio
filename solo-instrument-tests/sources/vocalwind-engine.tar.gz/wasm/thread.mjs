// One of the voice's engine's threads in one of Node's Workers, as public/studio/engines/vocalwind-thread.js is in a
// page's.
import {parentPort} from 'node:worker_threads';
import {threadMain} from '../../../public/studio/engines/vocalwind-wasi.js';

parentPort.once('message',data=>threadMain(data,message=>parentPort.postMessage(message)));
