// One of the voice's engine's programs in one of Node's Workers, as public/studio/engines/vocalwind-program.js is in a
// page's.
import {parentPort} from 'node:worker_threads';
import {programMain} from '../../../public/studio/engines/vocalwind-wasi.js';

parentPort.once('message',data=>programMain(data,(message,transfer=[])=>parentPort.postMessage(message,transfer)));
