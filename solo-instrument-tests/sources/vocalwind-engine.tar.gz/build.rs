// The tract's constants from acoustics/tract.json, each group's into the modules it names (tract_constants); and where
// eSpeak NG's library is, for the `espeak` feature: ESPEAK_NG_PREFIX, else pkg-config's, else Homebrew's.
use std::process::Command;

// acoustics/tract.json's constants as Rust's: every object with a `rust` name and a `value`, its value written exactly as
// the file writes it (serde_json's arbitrary precision keeps the text), into OUT_DIR/tract-<module>.rs for each module its
// group names (`modules`), which that module include!s.
fn tract_constants() {
    println!("cargo:rerun-if-changed=acoustics/tract.json");
    let text = std::fs::read_to_string("acoustics/tract.json").expect("acoustics/tract.json");
    let tract: serde_json::Value = serde_json::from_str(&text).expect("acoustics/tract.json: JSON");
    let mut files: std::collections::BTreeMap<String, String> = Default::default();
    fn constants(path: &str, v: &serde_json::Value, out: &mut String) {
        let Some(map) = v.as_object() else { return };
        if let (Some(name), Some(value)) = (map.get("rust").and_then(|n| n.as_str()), map.get("value")) {
            let mut literal = value.as_number().unwrap_or_else(|| panic!("acoustics/tract.json {path}: its value a number")).to_string();
            if !literal.contains(['.', 'e', 'E']) {
                literal.push_str(".0");
            }
            let unit = map.get("unit").and_then(|u| u.as_str()).unwrap_or("");
            out.push_str(&format!("/// acoustics/tract.json, {path} ({unit})\npub const {name}: f64 = {literal};\n"));
            return;
        }
        for (k, child) in map {
            constants(&format!("{path}.{k}"), child, out);
        }
    }
    for (group, v) in tract.as_object().expect("acoustics/tract.json: an object") {
        let Some(modules) = v.get("modules").and_then(|m| m.as_array()) else { continue };
        let mut out = String::new();
        constants(group, v, &mut out);
        for m in modules {
            files.entry(m.as_str().expect("a module's name").to_string()).or_default().push_str(&out);
        }
    }
    let dir = std::env::var("OUT_DIR").expect("OUT_DIR");
    for (module, out) in files {
        std::fs::write(format!("{dir}/tract-{module}.rs"), out).expect("written");
    }
}

fn main() {
    tract_constants();
    println!("cargo:rerun-if-env-changed=ESPEAK_NG_PREFIX");
    if std::env::var_os("CARGO_FEATURE_ESPEAK").is_none() {
        return;
    }
    let out = |cmd: &str, args: &[&str]| Command::new(cmd).args(args).output().ok().filter(|o| o.status.success()).map(|o| String::from_utf8_lossy(&o.stdout).trim().to_string());
    let lib = std::env::var("ESPEAK_NG_PREFIX")
        .ok()
        .map(|p| format!("{p}/lib"))
        .or_else(|| out("pkg-config", &["--variable=libdir", "espeak-ng"]))
        .or_else(|| out("brew", &["--prefix", "espeak-ng"]).map(|p| format!("{p}/lib")));
    if let Some(lib) = lib {
        println!("cargo:rustc-link-search=native={lib}");
        println!("cargo:rustc-link-arg=-Wl,-rpath,{lib}");
    }
    println!("cargo:rustc-link-lib=dylib=espeak-ng");
}
