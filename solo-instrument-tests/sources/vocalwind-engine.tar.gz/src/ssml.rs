// SSML read aloud by the vocal tract (the owner, 11 November 2026: "If possible ..., add SSML support"). The document
// is given to eSpeak NG (src/espeak.rs) as it is, but for <sub> (its alias put in its place) and <mark>: eSpeak reads its
// words, its say-as, emphasis, breaks, rate and languages, and gives back each phone in IPA, the millisecond it begins
// and the character where its word begins. Each <prosody> and <phoneme> takes the phones whose words begin inside it, and
// a mark the time of the first word after it: eSpeak's own marks are lost beside a sentence's end or another mark, and
// its positions stop moving after a <sub>. Those phones become VocalTractLab's German SAMPA (the nearest of the speaker's own where
// a language has others, each substitution said), are cut into utterances at eSpeak's pauses, and each utterance made a
// gestural score by VocalTractLab's rules (src/segments.rs) and sung by the tract. What eSpeak does not give is taken
// from the SSML alone: F0 from <prosody pitch> and <prosody contour> (relative values on what encloses them) over the
// base pitch the caller gives, the contour given VocalTractLab as the targets whose approach passes nearest it
// (src/f0_targets.rs); loudness from <prosody volume>, the output's gain, as SSML defines it (in decibels of
// amplitude), moving over one frame; <phoneme> (ipa, or x-sampa in VocalTractLab's German SAMPA) in place of eSpeak's
// phones for its text. Where the caller asks, eSpeak NG's
// own intonation rides on the document's pitches: each vowel's F0 in eSpeak's own audio, in semitones from their mean,
// at the vowel's middle, a line between them (docs/VOCAL_TRACT.md, "Intonation": of the models compared on natural
// speech, the nearest it), eSpeak then given no <prosody pitch> or <prosody contour>, which are the reader's. Otherwise no
// intonation is added that the document does not ask for. <prosody range> and <prosody duration> are not read (each
// said where met).
use crate::espeak::{self, Event};
use crate::gestural::{f0_hz, f0_st, Gesture, GesturalScore, F0};
use crate::segments::{self, Segment};
use crate::yin::Yin;

/// The farthest VocalTractLab's rules reach before an utterance's first phone (a lateral's gesture, 65 ms): the silence
/// each utterance's score begins with (2.3's).
pub const RULES_REACH_S: f64 = 0.065;
pub use crate::phones::{phones_begun, phones_in, RULES_REACH_24_S};

/// What the caller decides: none is assumed.
#[derive(Clone, Debug)]
pub struct Settings {
    /// The voice's pitch (Hz): SSML's "default" and "medium", and what relative values move from.
    pub base_hz: f64,
    /// SSML's pitch levels x-low, low, medium, high, x-high, in semitones from the base.
    pub pitch_levels_st: [f64; 5],
    /// SSML's volume levels x-soft, soft, medium, loud, x-loud, in decibels ("silent" is no sound).
    pub volume_levels_db: [f64; 5],
    /// The F0 targets' time constant (s), as an F0 gesture's (VocalTractLab's range 0.005 to 0.04).
    pub f0_tau_s: f64,
    /// eSpeak NG's own intonation over the document's pitches (else the document's pitches alone).
    pub intonation: bool,
}

/// A <prosody> or <phoneme>: its characters in the text eSpeak is given (one-based, end excluded), and the time its
/// phones span (ms, eSpeak's time line).
#[derive(Clone, Debug)]
struct Span {
    kind: &'static str,
    attrs: Vec<(String, String)>,
    chars: (i32, i32),
    begin_ms: Option<f64>,
    end_ms: Option<f64>,
}

impl Span {
    fn attr(&self, k: &str) -> Option<&str> {
        self.attrs.iter().find(|(a, _)| a == k).map(|(_, v)| v.as_str())
    }
    fn contains(&self, ms: f64) -> bool {
        match (self.begin_ms, self.end_ms) {
            (Some(b), Some(e)) => ms >= b && ms < e,
            _ => false,
        }
    }
    fn holds(&self, pos: i32) -> bool {
        pos >= self.chars.0 && pos < self.chars.1
    }
}

/// One phone as spoken: its SAMPA name ("" a pause), its start and duration (s, on eSpeak's time line), its stress
/// (0 none, 1 primary, 2 secondary) and the IPA it came from.
#[derive(Clone, Debug)]
pub struct Phone {
    pub sampa: String,
    pub start_s: f64,
    pub duration_s: f64,
    pub stress: u8,
    pub ipa: String,
    /// Where its word begins in the text eSpeak was given (none for a pause).
    pub text: Option<i32>,
    /// What a speaker with no shape of it says it as, in its language: a phone learned from a corpus (src/phones.rs
    /// stand_in), else none.
    pub stand_in: Option<String>,
}

/// A document read: its phones, its utterances (index ranges into the phones), its marks (name, time on eSpeak's time
/// line), and what was substituted or left unread; its scores made from it for 2.3 (scores) or 2.4 (scores_v24).
pub struct Reading {
    pub phones: Vec<Phone>,
    pub utterances: Vec<(usize, usize)>,
    pub marks: Vec<(String, f64)>,
    pub warnings: Vec<String>,
    /// eSpeak NG's intonation where asked: each vowel's middle (ms, eSpeak's time line) and its F0 there, in semitones
    /// from the document's mean.
    pub intonation: Vec<(f64, f64)>,
    spans: Vec<Span>,
    volume_levels_db: [f64; 5],
}

impl Phone {
    /// The phone a speaker says (`has`: whether it has a shape of that name): its own, or its stand-in where the
    /// speaker has no shape of it.
    fn on(&self, has: impl Fn(&str) -> bool) -> String {
        match (&self.stand_in, crate::inventory::phone(&self.sampa).and_then(|p| p.vowel_shape())) {
            (Some(near), Some(shape)) if !has(shape) => near.clone(),
            _ => self.sampa.clone(),
        }
    }
}

fn unescape(s: &str) -> String {
    s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&")
}

fn escape(s: &str) -> String {
    s.replace('&', "&amp;").replace('<', "&lt;").replace('>', "&gt;")
}

/// A tag's name, its attributes, and whether it closes or is empty.
fn tag(raw: &str) -> (String, Vec<(String, String)>, bool, bool) {
    let inner = raw.trim_start_matches('<').trim_end_matches('>');
    let closing = inner.starts_with('/');
    let inner = inner.trim_start_matches('/');
    let empty = inner.trim_end().ends_with('/');
    let inner = inner.trim_end().trim_end_matches('/');
    let name_end = inner.find(|c: char| c.is_whitespace()).unwrap_or(inner.len());
    let name = inner[..name_end].to_string();
    let mut attrs = Vec::new();
    let mut rest = &inner[name_end..];
    while let Some(eq) = rest.find('=') {
        let key = rest[..eq].trim().to_string();
        let after = rest[eq + 1..].trim_start();
        let Some(q) = after.chars().next().filter(|c| *c == '"' || *c == '\'') else { break };
        let Some(close) = after[1..].find(q) else { break };
        attrs.push((key, unescape(&after[1..1 + close])));
        rest = &after[close + 2..];
    }
    (name, attrs, closing, empty)
}

/// A <phoneme ph> string as phones: IPA tokens by the longest that is a phone in the document's language (one token
/// may be several phones, its stress on the first), or x-sampa as VocalTractLab's SAMPA.
fn phoneme_phones(ph: &str, alphabet: &str, language: &str) -> Result<Vec<(String, u8)>, String> {
    let chars: Vec<char> = ph.chars().filter(|c| !c.is_whitespace() && *c != '.').collect();
    let mut out = Vec::new();
    let mut i = 0;
    let mut stress = 0u8;
    while i < chars.len() {
        let c = chars[i];
        if c == 'ˈ' || (alphabet == "x-sampa" && c == '"') {
            stress = 1;
            i += 1;
            continue;
        }
        if c == 'ˌ' || (alphabet == "x-sampa" && c == '%') {
            stress = 2;
            i += 1;
            continue;
        }
        let mut found = None;
        for len in (1..=4.min(chars.len() - i)).rev() {
            let tok: String = chars[i..i + len].iter().collect();
            let names: Option<Vec<String>> = if alphabet == "ipa" { phones_in(&tok, language).map(|(p, _)| p.iter().map(|s| s.to_string()).collect()) } else if segments::is_phoneme(&tok) { Some(vec![tok.clone()]) } else { None };
            if let Some(n) = names {
                found = Some((n, len));
                break;
            }
        }
        let Some((names, len)) = found else { return Err(format!("<phoneme ph=\"{ph}\">: no phone at \"{}\"", chars[i..].iter().collect::<String>())) };
        for (j, name) in names.into_iter().enumerate() {
            out.push((name, if j == 0 { stress } else { 0 }));
        }
        stress = 0;
        i += len;
    }
    Ok(out)
}

/// A pitch as SSML writes it, applied to `p` (semitones re 1 Hz).
fn pitch_value(v: &str, p: f64, s: &Settings) -> Result<f64, String> {
    let base = f0_st(s.base_hz);
    let level = |k: usize| base + s.pitch_levels_st[k];
    let v = v.trim();
    Ok(match v {
        "x-low" => level(0),
        "low" => level(1),
        "medium" => level(2),
        "high" => level(3),
        "x-high" => level(4),
        "default" => base,
        _ => {
            let relative = v.starts_with('+') || v.starts_with('-');
            let (num, unit) = v.split_at(v.find(|c: char| c.is_alphabetic() || c == '%').ok_or_else(|| format!("pitch \"{v}\": no unit"))?);
            let x: f64 = num.parse().map_err(|_| format!("pitch \"{v}\": not a number"))?;
            match (unit, relative) {
                ("Hz", false) => f0_st(x),
                ("Hz", true) => f0_st(f0_hz(p) + x),
                ("st", true) => p + x,
                ("%", true) => f0_st(f0_hz(p) * (1.0 + x / 100.0)),
                _ => return Err(format!("pitch \"{v}\": SSML has no such value")),
            }
        }
    })
}

/// A contour's points: (position 0..1, value).
fn contour_points(c: &str) -> Result<Vec<(f64, String)>, String> {
    let mut out = Vec::new();
    for part in c.split(')') {
        let part = part.trim().trim_start_matches('(');
        if part.is_empty() {
            continue;
        }
        let (pos, val) = part.split_once(',').ok_or_else(|| format!("contour \"{c}\": a point without a value"))?;
        let pos = pos.trim().trim_end_matches('%').parse::<f64>().map_err(|_| format!("contour \"{c}\": a position not a percentage"))? / 100.0;
        out.push((pos, val.trim().to_string()));
    }
    Ok(out)
}

impl Reading {
    /// The F0 (semitones re 1 Hz) at `ms` on eSpeak's time line: the base, then each enclosing <prosody>'s pitch or
    /// contour from the outermost in.
    fn pitch_at(&self, ms: f64, s: &Settings) -> Result<f64, String> {
        let mut p = f0_st(s.base_hz);
        for span in self.spans.iter().filter(|x| x.kind == "prosody" && x.contains(ms)) {
            if let Some(c) = span.attr("contour") {
                let pts = contour_points(c)?;
                if pts.is_empty() {
                    continue;
                }
                let (b, e) = (span.begin_ms.unwrap() as f64, span.end_ms.unwrap() as f64);
                let x = if e > b { (ms - b) / (e - b) } else { 0.0 };
                let vals: Vec<f64> = pts.iter().map(|(_, v)| pitch_value(v, p, s)).collect::<Result<_, _>>()?;
                p = if x <= pts[0].0 {
                    vals[0]
                } else if x >= pts[pts.len() - 1].0 {
                    vals[vals.len() - 1]
                } else {
                    let k = pts.windows(2).position(|w| x >= w[0].0 && x < w[1].0).unwrap();
                    let r = (x - pts[k].0) / (pts[k + 1].0 - pts[k].0);
                    vals[k] + (vals[k + 1] - vals[k]) * r
                };
            } else if let Some(v) = span.attr("pitch") {
                p = pitch_value(v, p, s)?;
            }
        }
        Ok(p + self.intonation_at(ms))
    }

    /// eSpeak NG's intonation at `ms` (semitones): a line between its vowels' middles, held before the first and after
    /// the last; nothing where none was asked.
    fn intonation_at(&self, ms: f64) -> f64 {
        let n = &self.intonation;
        match n.iter().position(|p| p.0 > ms) {
            None => n.last().map(|p| p.1).unwrap_or(0.0),
            Some(0) => n[0].1,
            Some(k) => n[k - 1].1 + (n[k].1 - n[k - 1].1) * (ms - n[k - 1].0) / (n[k].0 - n[k - 1].0),
        }
    }

    /// The output's gain (amplitude) at `ms` on eSpeak's time line, from each enclosing <prosody volume>.
    pub fn gain_at(&self, ms: f64) -> Result<f64, String> {
        let mut db = 0.0;
        for span in self.spans.iter().filter(|x| x.kind == "prosody" && x.contains(ms)) {
            let Some(v) = span.attr("volume") else { continue };
            let v = v.trim();
            let level = ["x-soft", "soft", "medium", "loud", "x-loud"].iter().position(|l| *l == v);
            db = match (v, level) {
                ("silent", _) => return Ok(0.0),
                ("default", _) => 0.0,
                (_, Some(k)) => self.volume_levels_db[k],
                _ => {
                    let x: f64 = v.trim_end_matches("dB").parse().map_err(|_| format!("volume \"{v}\": SSML has no such value"))?;
                    if v.ends_with("dB") && (v.starts_with('+') || v.starts_with('-')) {
                        db + x
                    } else {
                        return Err(format!("volume \"{v}\": SSML has no such value"));
                    }
                }
            };
        }
        Ok(10f64.powf(db / 20.0))
    }
}

/// Reads an SSML document: its phones and their times by eSpeak, its marks, its pitches and volumes; the scores are made
/// from it for either version (Reading::scores, scores_v24).
pub fn read(doc: &str, s: &Settings) -> Result<Reading, String> {
    // The document as eSpeak is given it, each span's and mark's character there counted as eSpeak counts.
    let mut out = String::new();
    let mut count: i32 = 0;
    let emit = |out: &mut String, count: &mut i32, x: &str| {
        out.push_str(x);
        *count += x.chars().count() as i32;
    };
    let mut spans: Vec<Span> = Vec::new();
    // (What each open element must close: a span's end, and a voice of eSpeak's given inside it for its language.)
    let mut stack: Vec<(Option<usize>, bool)> = Vec::new();
    let mut user_marks: Vec<(String, i32)> = Vec::new();
    let mut lang: Option<String> = None;
    let mut warnings = Vec::new();
    let mut i = 0;
    let mut in_sub = false;
    while i < doc.len() {
        if doc[i..].starts_with("<!--") {
            i = doc[i..].find("-->").map(|k| i + k + 3).ok_or("an unclosed comment")?;
            continue;
        }
        if !doc[i..].starts_with('<') {
            let next = doc[i..].find('<').map(|k| i + k).unwrap_or(doc.len());
            if !in_sub {
                emit(&mut out, &mut count, &doc[i..next]);
            }
            i = next;
            continue;
        }
        let end = doc[i..].find('>').map(|k| i + k + 1).ok_or("an unclosed tag")?;
        let raw = &doc[i..end];
        i = end;
        if raw.starts_with("<?") || raw.starts_with("<!") {
            emit(&mut out, &mut count, raw);
            continue;
        }
        let (name, attrs, closing, empty) = tag(raw);
        let local = name.rsplit(':').next().unwrap_or(&name).to_string();
        if closing {
            let (span, voice) = stack.pop().unwrap_or((None, false));
            if let Some(k) = span {
                spans[k].chars.1 = count + 1;
            }
            if local == "sub" {
                in_sub = false;
            }
            if voice {
                emit(&mut out, &mut count, "</voice>");
            }
            if local != "sub" && local != "mark" {
                emit(&mut out, &mut count, raw);
            }
            continue;
        }
        match local.as_str() {
            "speak" => lang = attrs.iter().find(|(k, _)| k == "xml:lang").map(|(_, v)| v.clone()),
            "mark" => {
                let name = attrs.iter().find(|(k, _)| k == "name").map(|(_, v)| v.clone()).unwrap_or_default();
                user_marks.push((name, count + 1));
                if !empty {
                    stack.push((None, false));
                }
                continue;
            }
            "sub" => {
                let alias = attrs.iter().find(|(k, _)| k == "alias").map(|(_, v)| v.clone()).ok_or("<sub> without alias")?;
                emit(&mut out, &mut count, &escape(&alias));
                if !empty {
                    in_sub = true;
                    stack.push((None, false));
                }
                continue;
            }
            // (Where eSpeak's intonation is asked for, the document's pitches are the reader's alone: eSpeak hears its
            // rate and volume, so its own intonation is its own. Otherwise it hears the whole tag, its timing -- which
            // its pitch moves by a few milliseconds -- as it was.)
            "prosody" => {
                if s.intonation {
                    let kept: String = attrs.iter().filter(|(k, _)| !matches!(k.as_str(), "pitch" | "contour" | "range")).map(|(k, v)| format!(" {k}=\"{}\"", escape(v).replace('"', "&quot;"))).collect();
                    emit(&mut out, &mut count, &format!("<{name}{kept}{}>", if empty { "/" } else { "" }));
                } else {
                    emit(&mut out, &mut count, raw);
                }
                if !empty {
                    for (k, _) in attrs.iter().filter(|(k, _)| k == "range" || k == "duration") {
                        warnings.push(format!("<prosody {k}> is not read"));
                    }
                    spans.push(Span { kind: "prosody", attrs, chars: (count + 1, i32::MAX), begin_ms: None, end_ms: None });
                    stack.push((Some(spans.len() - 1), false));
                }
                continue;
            }
            _ => {}
        }
        emit(&mut out, &mut count, raw);
        if empty {
            continue;
        }
        // (eSpeak keeps a <p>'s, <s>'s or <lang>'s language for what follows it; inside a voice of its own it does not.)
        let voice = matches!(local.as_str(), "p" | "s" | "lang") && attrs.iter().any(|(k, _)| k == "xml:lang");
        if voice {
            let l = attrs.iter().find(|(k, _)| k == "xml:lang").map(|(_, v)| v.clone()).unwrap_or_default();
            emit(&mut out, &mut count, &format!("<voice xml:lang=\"{}\">", escape(&l).replace('"', "&quot;")));
        }
        if local == "phoneme" {
            spans.push(Span { kind: "phoneme", attrs, chars: (count + 1, i32::MAX), begin_ms: None, end_ms: None });
            stack.push((Some(spans.len() - 1), voice));
        } else if voice {
            // (Its language's phones for what it holds.)
            spans.push(Span { kind: "lang", attrs, chars: (count + 1, i32::MAX), begin_ms: None, end_ms: None });
            stack.push((Some(spans.len() - 1), voice));
        } else {
            stack.push((None, voice));
        }
    }
    let lang = lang.ok_or("<speak> names no xml:lang: the language is the document's to say")?;
    let lower = lang.to_lowercase();
    let primary = lower.split(['-', '_']).next().unwrap_or("").to_string();
    let (events, audio, rate) = espeak::spoken(&out, &lower, s.intonation).or_else(|_| espeak::spoken(&out, &primary, s.intonation))?;
    let mut raw: Vec<(String, i32, i32)> = Vec::new();
    let mut last_ms = 0;
    for e in &events {
        match e {
            Event::Phone { ipa, ms, text } => {
                raw.push((ipa.clone(), *ms, *text));
                last_ms = last_ms.max(*ms);
            }
            Event::Mark { ms, .. } | Event::Word { ms, .. } | Event::Sentence { ms } | Event::End { ms } => last_ms = last_ms.max(*ms),
        }
    }
    // eSpeak NG's intonation: each vowel's F0 in eSpeak's own audio -- the median of its voiced 10 ms frames over the
    // vowel's middle half, by VocalTractLab's estimator, as the comparison measured it -- in semitones from their mean.
    let mut intonation: Vec<(f64, f64)> = Vec::new();
    if s.intonation {
        let samples: Vec<f64> = audio.iter().map(|&x| x as f64).collect();
        let f0 = Yin::new(rate as f64).f0(&samples);
        for (k, (ipa, ms, _)) in raw.iter().enumerate() {
            // (A phone with a vowel's letter is a nucleus, as the intonation models' comparison counted them.)
            if !crate::phones::has_vowel_letter(ipa) {
                continue;
            }
            let end = raw.get(k + 1).map(|r| r.1).unwrap_or(last_ms) as f64;
            let (a, b) = (*ms as f64 + 0.25 * (end - *ms as f64), *ms as f64 + 0.75 * (end - *ms as f64));
            let (lo, hi) = ((a / 10.0) as usize, ((b / 10.0).ceil() as usize + 1).min(f0.len()));
            let mut v: Vec<f64> = if lo < hi { f0[lo..hi].iter().cloned().filter(|&x| x > 0.0).collect() } else { Vec::new() };
            if v.len() >= 2 {
                v.sort_by(|x, y| x.partial_cmp(y).unwrap());
                intonation.push(((a + b) / 2.0, f0_st(v[v.len() / 2])));
            }
        }
        let mean = intonation.iter().map(|p| p.1).sum::<f64>() / intonation.len().max(1) as f64;
        for p in intonation.iter_mut() {
            p.1 -= mean;
        }
    }
    // A phone's language: the innermost <p>, <s> or <lang> with an xml:lang that holds it, else the document's.
    let language_at = |pos: i32| spans.iter().rev().find(|x| x.kind == "lang" && x.holds(pos)).and_then(|x| x.attr("xml:lang")).map(str::to_lowercase).unwrap_or_else(|| lower.clone());
    let mut phones: Vec<Phone> = Vec::new();
    for (k, (ipa, ms, text)) in raw.iter().enumerate() {
        let next = raw.get(k + 1).map(|(_, m, _)| *m).unwrap_or(last_ms);
        let duration_s = (next - ms) as f64 / 1000.0;
        let stress = if ipa.contains('ˈ') { 1 } else if ipa.contains('ˌ') { 2 } else { 0 };
        // (A phone the speaker makes as several shares its time among them equally: designed.)
        let mut stand_in: Option<String> = None;
        let sampa: Vec<&str> = if ipa.is_empty() {
            vec![""]
        } else {
            // (eSpeak's phone events hold 8 bytes: one that fills them may be cut short.)
            let language = language_at(*text);
            let cut = ipa.len() == 8 || ipa.ends_with('\u{FFFD}');
            match phones_in(ipa, &language).or_else(|| if cut { phones_begun(ipa, &language) } else { None }) {
                Some((x, substituted)) => {
                    if substituted {
                        warnings.push(format!("[{ipa}] sung as the speaker's /{}/", x.join(" ")));
                    }
                    // (A phone learned from a corpus: its language's nearest for a speaker with no shape of it.)
                    if let ([one], Some(near)) = (x.as_slice(), crate::phones::stand_in(ipa, &language).filter(|n| n.len() == 1)) {
                        if segments::is_vowel(one) {
                            stand_in = Some(near[0].to_string());
                        }
                    }
                    x
                }
                None => {
                    warnings.push(format!("[{ipa}] has no phone of the speaker's: a pause"));
                    vec![""]
                }
            }
        };
        let share = duration_s / sampa.len() as f64;
        for (j, x) in sampa.iter().enumerate() {
            let start_s = *ms as f64 / 1000.0 + j as f64 * share;
            phones.push(Phone { sampa: x.to_string(), start_s, duration_s: share, stress: if j == 0 { stress } else { 0 }, ipa: ipa.clone(), text: if ipa.is_empty() { None } else { Some(*text) }, stand_in: stand_in.clone() });
        }
    }
    // <phoneme>: its phones in place of eSpeak's for its text, taking their times one for one where they are as many,
    // else sharing the text's time equally (designed).
    for span in spans.iter().filter(|x| x.kind == "phoneme") {
        let ph = span.attr("ph").ok_or("<phoneme> without ph")?;
        let alphabet = span.attr("alphabet").unwrap_or("ipa");
        if alphabet != "ipa" && alphabet != "x-sampa" {
            return Err(format!("<phoneme alphabet=\"{alphabet}\">: only ipa, and x-sampa as VocalTractLab's German SAMPA"));
        }
        let new = phoneme_phones(ph, alphabet, &language_at(span.chars.0))?;
        let inside: Vec<usize> = (0..phones.len()).filter(|&k| phones[k].text.map(|t| span.holds(t)).unwrap_or(false)).collect();
        let (Some(&first), Some(&last)) = (inside.first(), inside.last()) else { continue };
        let start = phones[first].start_s;
        let total = phones[last].start_s + phones[last].duration_s - start;
        let text = phones[first].text;
        let made: Vec<Phone> = if new.len() == inside.len() {
            new.iter().zip(&inside).map(|((n, st), &k)| Phone { sampa: n.clone(), stress: *st, ipa: ph.to_string(), stand_in: None, ..phones[k].clone() }).collect()
        } else {
            let d = total / new.len() as f64;
            new.iter().enumerate().map(|(j, (n, st))| Phone { sampa: n.clone(), start_s: start + j as f64 * d, duration_s: d, stress: *st, ipa: ph.to_string(), text, stand_in: None }).collect()
        };
        phones.splice(first..=last, made);
    }
    // Each span's time: from its first phone's start to its last's end.
    for span in spans.iter_mut() {
        let inside: Vec<&Phone> = phones.iter().filter(|p| p.text.map(|t| span.holds(t)).unwrap_or(false)).collect();
        if let (Some(f), Some(l)) = (inside.first(), inside.last()) {
            span.begin_ms = Some(f.start_s * 1000.0);
            span.end_ms = Some((l.start_s + l.duration_s) * 1000.0);
        }
    }
    // A mark: the start of the first word after it, else the end of the last phone; on the output's time line.
    let end_s = phones.iter().filter(|p| p.text.is_some()).map(|p| p.start_s + p.duration_s).fold(0.0, f64::max);
    let marks = user_marks
        .iter()
        .map(|(n, c)| (n.clone(), phones.iter().find(|p| p.text.map(|t| t >= *c).unwrap_or(false)).map(|p| p.start_s).unwrap_or(end_s)))
        .collect();
    // Utterances: the phones between eSpeak's pauses.
    let mut utterances = Vec::new();
    let mut k = 0;
    while k < phones.len() {
        if phones[k].ipa.is_empty() {
            k += 1;
            continue;
        }
        let first = k;
        while k < phones.len() && !phones[k].ipa.is_empty() {
            k += 1;
        }
        utterances.push((first, k));
    }
    Ok(Reading { phones, utterances, marks, warnings, intonation, spans, volume_levels_db: s.volume_levels_db })
}

impl Reading {
    /// Each utterance's 2.3 score and where it begins on eSpeak's time line: its segments from RULES_REACH_S before its
    /// first phone, made by 2.3's rules (`vt`, the speaker's tract, its geometry used by their searches), its F0 from
    /// the document's pitches.
    pub fn scores(&self, s: &Settings, vt: &mut crate::tract::VocalTract) -> Result<Vec<(f64, GesturalScore)>, String> {
        let mut out = Vec::new();
        for &(first, end) in &self.utterances {
            let mut segs = vec![Segment { name: String::new(), duration_s: RULES_REACH_S, labels: Vec::new() }];
            for p in &self.phones[first..end] {
                segs.push(Segment { name: p.on(|x| vt.shape(x).is_some()), duration_s: p.duration_s, labels: vec![("stress".into(), p.stress.to_string())] });
            }
            let mut score = GesturalScore::new();
            score.from_segments(&segs, vt);
            let duration = score.duration_s();
            if duration <= 0.0 {
                continue;
            }
            let origin_ms = self.phones[first].start_s * 1000.0 - RULES_REACH_S * 1000.0;
            let slopes = (score.seq[F0].min_slope, score.seq[F0].max_slope);
            score.seq[F0].gestures = self.f0_tier(s, origin_ms, duration, self.spoken(first, end, origin_ms), slopes)?;
            out.push((origin_ms / 1000.0, score));
        }
        Ok(out)
    }

    /// The same for 2.4: its segments from RULES_REACH_24_S before its first phone (its rules' least pause), made by
    /// 2.4's rules, which end it with 100 ms of pause.
    pub fn scores_v24(&self, s: &Settings, vt: &mut crate::v24::tract::VocalTract) -> Result<Vec<(f64, crate::v24::gestural::GesturalScore)>, String> {
        let mut out = Vec::new();
        for &(first, end) in &self.utterances {
            let mut segs = vec![Segment { name: String::new(), duration_s: RULES_REACH_24_S, labels: Vec::new() }];
            for p in &self.phones[first..end] {
                segs.push(Segment { name: p.on(|x| vt.shape(x).is_some()), duration_s: p.duration_s, labels: vec![("stress".into(), p.stress.to_string())] });
            }
            let mut score = crate::v24::gestural::GesturalScore::new();
            score.from_segments(&segs, vt);
            let duration = score.duration_s();
            if duration <= 0.0 {
                continue;
            }
            let origin_ms = self.phones[first].start_s * 1000.0 - RULES_REACH_24_S * 1000.0;
            let slopes = (score.seq[F0].min_slope, score.seq[F0].max_slope);
            score.seq[F0].gestures = self.f0_tier(s, origin_ms, duration, self.spoken(first, end, origin_ms), slopes)?;
            out.push((origin_ms / 1000.0, score));
        }
        Ok(out)
    }

    /// Where an utterance's phones `first..end` are spoken on its score beginning at `origin_ms`: its first's start and
    /// its last's end, s from the score's start.
    fn spoken(&self, first: usize, end: usize, origin_ms: f64) -> (f64, f64) {
        let last = &self.phones[end - 1];
        ((self.phones[first].start_s * 1000.0 - origin_ms) / 1000.0, ((last.start_s + last.duration_s) * 1000.0 - origin_ms) / 1000.0)
    }

    /// An utterance's F0 tier, its score beginning at `origin_ms` on eSpeak's time line and lasting `duration`, its
    /// phones `spoken` (s from the score's start, its first's start to its last's end): breakpoints where a pitch begins,
    /// ends or turns (eSpeak's vowels' middles among them) and where the phones begin and end, the F0 a line between --
    /// the contour as heard, each of its pieces one target, those whose approach on the engine passes nearest it while it
    /// is spoken, their slopes in the tier's range `slopes` (f0_targets; the owner, 15 November 2026: "Targets fitted").
    fn f0_tier(&self, s: &Settings, origin_ms: f64, duration: f64, spoken: (f64, f64), slopes: (f64, f64)) -> Result<Vec<Gesture>, String> {
        let mut cuts: Vec<f64> = vec![0.0, duration];
        for t in [spoken.0, spoken.1] {
            if t > 0.0 && t < duration {
                cuts.push(t);
            }
        }
        for &(ms, _) in &self.intonation {
            let t = (ms - origin_ms) / 1000.0;
            if t > 0.0 && t < duration {
                cuts.push(t);
            }
        }
        for span in self.spans.iter().filter(|x| x.kind == "prosody") {
            let (Some(b), Some(e)) = (span.begin_ms, span.end_ms) else { continue };
            let mut at = vec![b as f64, e as f64];
            if let Some(c) = span.attr("contour") {
                for (pos, _) in contour_points(c)? {
                    at.push(b as f64 + pos * (e - b) as f64);
                }
            }
            for ms in at {
                let t = (ms - origin_ms) / 1000.0;
                if t > 0.0 && t < duration {
                    cuts.push(t);
                }
            }
        }
        cuts.sort_by(|a, b| a.partial_cmp(b).unwrap());
        cuts.dedup_by(|a, b| (*a - *b).abs() < 1e-9);
        const EDGE: f64 = 1e-9;
        let mut tier = Vec::new();
        for w in cuts.windows(2) {
            let (a, b) = (w[0], w[1]);
            let pa = self.pitch_at(origin_ms + (a + EDGE) * 1000.0, s)?;
            let pb = self.pitch_at(origin_ms + (b - EDGE) * 1000.0, s)?;
            tier.push(Gesture { duration_s: b - a, d_val: pa, slope: (pb - pa) / (b - a), s_val: String::new(), tau_s: s.f0_tau_s, neutral: false });
        }
        Ok(crate::f0_targets::fitted(&tier, slopes, spoken))
    }
}
