// The synthesizer (Synthesizer.cpp): frame by frame, the tube and the glottis's parameters interpolated sample by sample
// from the last frame's to this one's, the glottis's geometry made each sample and laid into the tube, the lungs' pressure
// set below the trachea, the glottis moved by the pressures about it, the tube stepped; the sound the derivative of the
// radiated flow, low-passed at 12 kHz (an 8-pole Chebyshev) and scaled into [-1, 1].
use crate::constants::{SAMPLING_RATE, SYNTHETIC_SPEECH_BANDWIDTH_HZ};
use crate::glottis::{GeometricGlottis, NUM_CONTROL_PARAMS, PRESSURE};
use crate::iir::IirFilter;
use crate::tds::TdsModel;
use crate::tract::{TractTube, VocalTract};
use crate::tube::{self, Tube};

const TDS_BUFFER_LENGTH: usize = 256;
const TDS_BUFFER_MASK: i32 = 255;

pub struct Synthesizer {
    pub glottis: GeometricGlottis,
    pub tds: TdsModel,
    prev_tube: Tube,
    tube: Tube,
    prev_glottis_params: [f64; NUM_CONTROL_PARAMS],
    output_flow: [f64; TDS_BUFFER_LENGTH],
    output_pressure: [f64; TDS_BUFFER_LENGTH],
    output_pressure_filter: IirFilter,
    initial_shapes_set: bool,
    // (The tube the tract's frames are laid into, kept from frame to frame as the C++'s static one.)
    tract_tube: Tube,
}

/// A frame's geometry laid into a tube as VocalTract::getTube lays it: the speaker's static cavities, the pharynx and
/// mouth's sections, the incisors, the tongue tip's sides and the velopharyngeal port.
pub fn tube_from_tract(t: &TractTube, tube: &mut Tube) {
    tube.init_piriform_fossa(t.fossa_length_cm, t.fossa_volume_cm3);
    tube.init_subglottal_cavity(t.subglottal_length_cm);
    tube.init_nasal_cavity(t.nasal_length_cm);
    tube.set_pharynx_mouth_geometry(&t.length_cm, &t.area_cm2, &t.articulator, t.incisor_pos_cm, t.tongue_tip_side_elevation);
    tube.set_velum_opening(t.velum_opening_cm2);
}

impl Synthesizer {
    pub fn new(glottis: GeometricGlottis, tds: TdsModel) -> Synthesizer {
        let mut output_pressure_filter = IirFilter::default();
        output_pressure_filter.create_chebyshev(SYNTHETIC_SPEECH_BANDWIDTH_HZ / SAMPLING_RATE as f64, false, 8);
        let mut s = Synthesizer {
            glottis,
            tds,
            prev_tube: Tube::new(),
            tube: Tube::new(),
            prev_glottis_params: [0.0; NUM_CONTROL_PARAMS],
            output_flow: [0.0; TDS_BUFFER_LENGTH],
            output_pressure: [0.0; TDS_BUFFER_LENGTH],
            output_pressure_filter,
            initial_shapes_set: false,
            tract_tube: Tube::new(),
        };
        s.reset();
        s
    }

    pub fn reset(&mut self) {
        self.glottis.reset_motion();
        self.tds.reset_motion();
        self.output_pressure_filter.reset_buffers(0.0);
        self.initial_shapes_set = false;
        self.output_flow = [0.0; TDS_BUFFER_LENGTH];
        self.output_pressure = [0.0; TDS_BUFFER_LENGTH];
    }

    /// `out.len()` samples from the last frame's articulation to this one's (Synthesizer::add with tract parameters):
    /// the vocal tract's geometry made for them and its tube synthesized.
    pub fn add_tract(&mut self, tract: &mut VocalTract, tract_params: &[f64], new_glottis: &[f64], out: &mut [f64]) {
        tract.calculate(tract_params);
        let geometry = tract.tube();
        self.add_geometry(&geometry, new_glottis, out);
    }

    /// The same from a frame's geometry made already (by this thread or another).
    pub fn add_geometry(&mut self, geometry: &TractTube, new_glottis: &[f64], out: &mut [f64]) {
        let mut tube = std::mem::take(&mut self.tract_tube);
        tube_from_tract(geometry, &mut tube);
        self.add_tube(new_glottis, &tube, out);
        self.tract_tube = tube;
    }

    /// `out.len()` samples from the last frame's tube and glottis to these; the first call after a reset only sets them.
    pub fn add_tube(&mut self, new_glottis: &[f64], new_tube: &Tube, out: &mut [f64]) {
        let n = self.glottis.control.len();
        if !self.initial_shapes_set {
            self.prev_tube.clone_from(new_tube);
            self.prev_glottis_params[..n].copy_from_slice(&new_glottis[..n]);
            self.initial_shapes_set = true;
            return;
        }
        let num_samples = out.len();
        if num_samples < 1 {
            return;
        }
        for (i, y) in out.iter_mut().enumerate() {
            let ratio = i as f64 / num_samples as f64;
            let ratio1 = 1.0 - ratio;
            self.tube.interpolate(&self.prev_tube, new_tube, ratio);
            for k in 0..n {
                self.glottis.control[k].x = ratio1 * self.prev_glottis_params[k] + ratio * new_glottis[k];
            }
            self.glottis.calc_geometry();
            let (length_cm, area_cm2) = self.glottis.tube_data();
            self.tube.set_glottis_geometry(&length_cm, &area_cm2);
            self.tube.set_aspiration_strength(self.glottis.aspiration_strength_db());
            let filtering = self.tds.sample_index() != 0;
            self.tds.set_tube(&self.tube, filtering);
            self.tds.set_flow_source(0.0, -1);
            self.tds.set_pressure_source(self.glottis.control[PRESSURE].x, tube::FIRST_TRACHEA_SECTION as i32);
            let pressure_dpa = [
                self.tds.section_pressure(tube::LAST_TRACHEA_SECTION),
                self.tds.section_pressure(tube::LOWER_GLOTTIS_SECTION),
                self.tds.section_pressure(tube::UPPER_GLOTTIS_SECTION),
                self.tds.section_pressure(tube::FIRST_PHARYNX_SECTION),
            ];
            self.glottis.inc_time(1.0 / SAMPLING_RATE as f64, &pressure_dpa);
            let (total_flow, _, _, _) = self.tds.proceed_time_step();
            let k = (self.tds.sample_index() & TDS_BUFFER_MASK) as usize;
            self.output_flow[k] = total_flow;
            self.output_pressure[k] = (self.output_flow[k] - self.output_flow[((k as i32 - 1) & TDS_BUFFER_MASK) as usize]) / self.tds.time_step;
            *y = self.output_pressure_filter.output_sample(self.output_pressure[k]) * 1e-7;
        }
        self.prev_tube.clone_from(new_tube);
        self.prev_glottis_params[..n].copy_from_slice(&new_glottis[..n]);
    }
}
