// NumPy's .npy files, as far as arrays of numbers need them (numpy.lib.format, versions 1 to 3): the header's type,
// order and shape, then the numbers, little-endian float64 or float32, in C order. The header is read as text and never
// evaluated; anything else -- pickled objects, Fortran order, other types -- is refused.

/// An array's shape and its numbers in C order.
#[derive(Clone, Debug, PartialEq)]
pub struct Array {
    pub shape: Vec<usize>,
    pub data: Vec<f64>,
}

impl Array {
    /// The rows of a two-dimensional array.
    pub fn rows(&self) -> Result<impl Iterator<Item = &[f64]>, String> {
        match self.shape[..] {
            [_, n] if n > 0 => Ok(self.data.chunks_exact(n)),
            _ => Err(format!("not a two-dimensional array: shape {:?}", self.shape)),
        }
    }
}

const MAGIC: &[u8] = b"\x93NUMPY";

/// The value after `'key':` in the header's dictionary, up to its comma or closing brace (a tuple whole).
fn field<'a>(header: &'a str, key: &str) -> Result<&'a str, String> {
    let at = header.find(&format!("'{key}':")).ok_or_else(|| format!("no '{key}' in the header {header}"))?;
    let rest = header[at + key.len() + 3..].trim_start();
    let end = if rest.starts_with('(') { rest.find(')').map(|e| e + 1) } else { rest.find([',', '}']) };
    Ok(rest[..end.ok_or_else(|| format!("'{key}' unterminated in {header}"))?].trim())
}

pub fn parse(bytes: &[u8]) -> Result<Array, String> {
    if bytes.len() < 10 || &bytes[..6] != MAGIC {
        return Err("not a .npy file".into());
    }
    let (len, start) = match bytes[6] {
        1 => (u16::from_le_bytes([bytes[8], bytes[9]]) as usize, 10),
        2 | 3 if bytes.len() >= 12 => (u32::from_le_bytes([bytes[8], bytes[9], bytes[10], bytes[11]]) as usize, 12),
        v => return Err(format!(".npy version {v} not read")),
    };
    let header = std::str::from_utf8(bytes.get(start..start + len).ok_or("the header runs past the file")?).map_err(|e| e.to_string())?;
    let width = match field(header, "descr")?.trim_matches(['\'', '"']) {
        "<f8" => 8,
        "<f4" => 4,
        d => return Err(format!("numbers of type {d} not read (only little-endian float64 and float32)")),
    };
    if field(header, "fortran_order")? != "False" {
        return Err("Fortran order not read".into());
    }
    let shape: Vec<usize> = field(header, "shape")?
        .trim_matches(['(', ')'])
        .split(',')
        .map(str::trim)
        .filter(|s| !s.is_empty())
        .map(|s| s.parse::<usize>().map_err(|e| format!("shape {s}: {e}")))
        .collect::<Result<_, _>>()?;
    let count: usize = shape.iter().product();
    let body = &bytes[start + len..];
    if body.len() != count * width {
        return Err(format!("{} bytes of numbers where shape {shape:?} wants {}", body.len(), count * width));
    }
    let data = if width == 8 {
        body.chunks_exact(8).map(|b| f64::from_le_bytes(b.try_into().unwrap())).collect()
    } else {
        body.chunks_exact(4).map(|b| f32::from_le_bytes(b.try_into().unwrap()) as f64).collect()
    };
    Ok(Array { shape, data })
}

pub fn read(path: &std::path::Path) -> Result<Array, String> {
    parse(&std::fs::read(path).map_err(|e| format!("{}: {e}", path.display()))?).map_err(|e| format!("{}: {e}", path.display()))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn file(header: &str, numbers: &[f64]) -> Vec<u8> {
        // (A header padded with spaces to a multiple of 64 bytes and ended by a newline, as numpy writes it.)
        let mut h = header.to_string();
        while (10 + h.len() + 1) % 64 != 0 {
            h.push(' ');
        }
        h.push('\n');
        let mut out = MAGIC.to_vec();
        out.extend([1, 0]);
        out.extend((h.len() as u16).to_le_bytes());
        out.extend(h.as_bytes());
        for x in numbers {
            out.extend(x.to_le_bytes());
        }
        out
    }

    #[test]
    fn reads_what_numpy_writes() {
        let a = parse(&file("{'descr': '<f8', 'fortran_order': False, 'shape': (2, 3), }", &[1.0, 2.0, 3.0, 4.0, 5.0, 6.5])).unwrap();
        assert_eq!(a.shape, vec![2, 3]);
        assert_eq!(a.rows().unwrap().nth(1).unwrap(), &[4.0, 5.0, 6.5]);
        let v = parse(&file("{'descr': '<f8', 'fortran_order': False, 'shape': (4,), }", &[1.0, 2.0, 3.0, 4.0])).unwrap();
        assert_eq!(v.shape, vec![4]);
    }

    #[test]
    fn refuses_what_it_cannot_read() {
        assert!(parse(&file("{'descr': '|O', 'fortran_order': False, 'shape': (1,), }", &[0.0])).is_err());
        assert!(parse(&file("{'descr': '<f8', 'fortran_order': True, 'shape': (1, 1), }", &[0.0])).is_err());
        assert!(parse(&file("{'descr': '<f8', 'fortran_order': False, 'shape': (2, 2), }", &[0.0])).is_err());
        assert!(parse(b"not numpy").is_err());
    }
}
