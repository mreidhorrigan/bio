// The voice played live (the owner, 11 November 2026: "Can you add the vocal tract to our studio page for me to test?"):
// its controls -- a vowel, or two blended, any of the speaker's shapes or one made from its vowel space (vowel_space.rs);
// a pitch, any real MIDI number; a lung pressure; a
// glottal shape; the articulators' time constant; vibrato; sounding or not -- and each of the tract's 19 parameters and
// the glottis's own (the owner: "I'm not seeing continuous parameters for Glottis ... could rather be given as the
// parameters (even if in addition to the presets)"): a shape sets them all, a parameter set holds until another shape
// is chosen. All approached frame by frame as VocalTractLab approaches a score's targets (`Approach`, a fifth-order
// critically damped system; the owner, 15 November 2026, of the dial's controls through the engine's own approach,
// among the designs awaiting their yes: "Actually - build this first, then hand off"): the tract and the glottis's shape
// at the articulators' time constant, the pressure at its rise and fall's, F0 at the larynx's measured one
// (`F0_TIME_CONSTANT_S`), the vibrato on it as set; each frame's geometry made `lookahead` frames ahead on worker threads
// (live.rs), its samples made as they are asked for. A control changed is heard from the next frame not yet asked for:
// `lookahead` frames (2.5 ms each) later. It
// begins at the speaker's neutral tract, its glottis's neutral values (its F0 and pressure among them) and VocalTractLab's
// own time constant (gestural.rs DEFAULT_TIME_CONSTANT_S), silent: nothing is written in here.
// VocalTractLab 2.3 (44.1 kHz, frames of 110 samples) or 2.4 (research/VOCAL_TRACT_REALTIME_PLAN.md, 3: 48 kHz, frames of
// 120, stepped 1 to 4 times its rate), the same controls driving either: 2.4's frames' part of each step made on a
// thread of its own (src/v24/pipeline.rs), its acoustics on the thread that asks for its samples. It reads itself as it
// plays (`Reading`; the owner, 12 November 2026: "the page tells the user what percent of real time it's running and on
// how many cores ... it will give an accurate reading of its own function, from which it can also choose a default until
// overridden by the user"; "the default should be whatever sounds without artefacts; then the user can adjust"): over
// each second of its sound, how fast its samples were made by the clock on the wall as they were asked for, and each of
// its threads' share of a core. 2.4's steps a sample are its player's to choose, held; or its own (`new24_adapting`),
// from that reading, nothing measured apart: the most whose making would take no more than 70% of real time -- its cost a
// step the same at every count (research/VOCAL_TRACT_REALTIME_PLAN.md, 4) -- more at the next silence, fewer where it
// takes more than 90%, at the next silence, or at once where it has fallen behind and its sound is breaking up (to change
// them starts the tube again from rest). 2.4's 12 kHz low-pass is on at 1 alone, as 2.4 has it.
// Or VocalWind (the owner, 15 November 2026: "Add VocalWind as an option to the webpage"): 2.4's speaker, its frames and
// geometry as 2.4's, its acoustics VocalFork 3.0's (src/v24/passive.rs: its loss law, its trachea and its cores as its
// switches ask, its steps a sample its physics'), held. A 2.4 voice, or VocalWind, also sings phrases (`sing`): each
// one's phones laid out by VocalTractLab 2.4's own rules into a gestural score (src/v24/segments.rs, as a reading's are),
// its F0 the line it is given, from its time on the voice's clock -- the seconds of sound it has given -- each frame of
// it taking the tract and glottis from the score in place of the controls, which go on from where it leaves them.
use crate::counters::{self, Thread};
use crate::gestural::{Gesture, DEFAULT_TIME_CONSTANT_S, F0, LUNG_PRESSURE};
use crate::glottis::{GeometricGlottis, FREQUENCY, PRESSURE};
use crate::live::GeometryPool;
use crate::segments::Segment;
use crate::synth::Synthesizer;
use crate::tds::TdsModel;
use crate::tract::{VocalTract, NUM_PARAMS};
use crate::v24;
use std::collections::VecDeque;
use std::time::Instant;

/// 2.3's rate and frame.
pub const RATE: f64 = 44100.0;
pub const FRAME: usize = 110;

/// What the player sets.
#[derive(Clone, Debug)]
pub struct Controls {
    /// A shape of the speaker's (a vowel, or any consonant's), and a second blended into it by `blend` (0 the first).
    pub vowel: String,
    pub vowel2: String,
    pub blend: f64,
    /// A tract parameter set by itself, holding over the shapes' (None: the shapes' value).
    pub tract: [Option<f64>; NUM_PARAMS],
    /// MIDI number, any real value.
    pub pitch: f64,
    pub pressure_dpa: f64,
    /// A glottal shape of the speaker's (modal, breathy, pressed, ...).
    pub glottis: String,
    /// A glottis parameter set by itself, holding over its shape's (F0 and pressure are `pitch` and `pressure_dpa`).
    pub glottis_values: Vec<Option<f64>>,
    /// The glottis's static parameters -- the speaker's larynx: its folds' rest thickness, length and f0, its chink's
    /// length, its jitter -- each set by itself (None: the speaker's own). A person's over a conversation; the model's to
    /// change (the owner, 13 November 2026: "the physiology of the speaking voice ... that a human speaking would not
    /// normally be able to change in the course of one conversation although our model can").
    pub statics: Vec<Option<f64>>,
    /// The articulators' and the glottis's time constant (s), and the pressure's rise and fall (s).
    pub tau_s: f64,
    pub ramp_s: f64,
    pub vibrato_hz: f64,
    pub vibrato_cents: f64,
    pub sounding: bool,
}

/// What is heard now: the pharynx's and mouth's sections (their areas, cm^2, and lengths, cm, glottis to lips), F0 and
/// lung pressure.
#[derive(Clone, Debug)]
pub struct Heard {
    pub areas: Vec<f64>,
    pub lengths: Vec<f64>,
    pub f0: f64,
    pub pressure: f64,
}

/// What it read of itself over a second of its sound (above).
#[derive(Clone, Debug)]
pub struct Reading {
    /// Its sound's seconds made a second of the wall's clock spent making them, as they were asked for: above 1 it keeps
    /// up. The Mac's load is in it, and the waits on its other threads.
    pub pace: f64,
    /// Its steps a sample then.
    pub steps: usize,
    /// Each of its threads: the one its samples are made on first ("acoustics"), then the others by their names.
    pub threads: Vec<Share>,
}

/// A thread's part of a reading.
#[derive(Clone, Debug)]
pub struct Share {
    pub name: String,
    /// Its time on a core over the wall's.
    pub core: f64,
    /// The share of its instructions retired on the performance cores.
    pub performance: f64,
}

/// A second of sound being read: its seconds made, the wall's seconds spent making them, when it began, and its threads'
/// counts then.
struct Window {
    sound: f64,
    busy: f64,
    began: Instant,
    threads: Vec<Thread>,
}

impl Window {
    fn new() -> Window {
        Window { sound: 0.0, busy: 0.0, began: Instant::now(), threads: counters::threads() }
    }
}

enum Engine {
    V23 { synth: Synthesizer, pool: GeometryPool<VocalTract>, queued: VecDeque<Vec<f64>> },
    V24 { synth: v24::synth::Synthesizer, pipeline: v24::pipeline::Pipeline, sent: u64, queued: VecDeque<(f64, f64)>, auto: Option<Adapt> },
}

/// 2.4's steps a sample its own to choose: what it was made from, to make it again, and the count its last reading asks
/// for -- at once, where it has fallen behind.
struct Adapt {
    tract: v24::tract::VocalTract,
    glottis: v24::glottis::Glottis2025,
    solver: v24::tds::Solver,
    workers: usize,
    lookahead: usize,
    wanted: usize,
    at_once: bool,
}

/// The most of real time a count of steps is taken up to, as its last reading foretells it; and the most that a count
/// kept may take, as read.
const KEEPS_UP: f64 = 0.7;
const BEHIND: f64 = 0.9;

/// The count of steps a sample (1 to 4) a reading asks for: having taken `taken` of real time at `n`, the most that would
/// take no more than KEEPS_UP; no fewer than `n` unless it took more than BEHIND.
pub fn wanted(taken: f64, n: usize) -> usize {
    let most = (1..=4).rev().find(|&m| taken * m as f64 / n as f64 <= KEEPS_UP).unwrap_or(1);
    if taken > BEHIND {
        most.min(n.saturating_sub(1)).max(1)
    } else {
        most.max(n)
    }
}

/// A phrase being sung: from `start` s on the voice's clock (its score's beginning, the rules' pause before its first
/// phone) for `length` s, its score's curves.
struct Phrase {
    start: f64,
    length: f64,
    curves: v24::gestural::Curves,
}

/// What a phrase's score is made with: the speaker's tract and glottis, as the voice plays them.
struct Scoring {
    tract: v24::tract::VocalTract,
    glottis: v24::glottis::Glottis2025,
}

pub struct LiveVoice {
    shapes: Vec<(String, [f64; NUM_PARAMS])>,
    /// Shapes made for it (vowels from its speaker's vowel space), apart from the speaker's: those its vowels name.
    made: Vec<(String, [f64; NUM_PARAMS])>,
    glottis_shapes: Vec<(String, Vec<f64>)>,
    neutral_tract: [f64; NUM_PARAMS],
    neutral_glottis: Vec<f64>,
    speaker_statics: Vec<f64>,
    engine: Engine,
    /// Its phrases (2.4's speakers alone), and what their scores are made with.
    scoring: Option<Scoring>,
    /// VocalWind's acoustics as asked (its passive core's switches) and its steps a sample: what `first_resonance` lays
    /// its network with (None but for VocalWind).
    passive: Option<(Vec<String>, usize)>,
    phrases: Vec<Phrase>,
    /// Where its engine's first sample falls on its clock (s): 0, or where its steps a sample were changed.
    origin_s: f64,
    /// Its clock: the seconds of sound it has given.
    pub clock_s: f64,
    lookahead: u64,
    /// The rate it plays at (Hz) and its frame (samples).
    pub rate: f64,
    pub frame: usize,
    pub controls: Controls,
    /// Where its controls have come to: the tract's parameters, the glottis's (F0 and the pressure kept apart, in their
    /// places unused), the lung pressure and the pitch (MIDI, its vibrato not in it).
    tract_now: [Approach; NUM_PARAMS],
    glottis_now: Vec<Approach>,
    pressure_now: Approach,
    pitch_now: Approach,
    vibrato_phase: f64,
    started: bool,
    buffer: VecDeque<f32>,
    /// The frame last heard.
    pub heard: Option<Heard>,
    /// What it last read of itself, and the second it is reading.
    pub reading: Option<Reading>,
    window: Window,
    /// The seconds of sound it has made; the times its model has gone unstable, and the last (s into its sound).
    sound_s: f64,
    pub unstable: (u32, f64),
    /// The most lung pressure a phrase has been sung at (dPa).
    sung_most_dpa: f64,
    /// The fold law its phrases' modal shape follows, where asked (design C: crate::fold_law; vtl-stream foldlaw=).
    fold_law: Option<crate::fold_law::FoldLaw>,
}

/// A model gone unstable on its way to NaN: a section's pressure beyond three times the most lung pressure it is given
/// (dPa: the page's most, or more where a control or a phrase asks it), caught there, inside the model, before its
/// sound; or its sound not finite. Never its sound's level: a voice at the loudest pressures VocalWind takes reaches full
/// scale itself (JD2's /a/ at C#4 from some 42,000 dPa, a singer's beyond fff there), and until 15 November 2026 was taken
/// for gone unstable and silenced, 205 times in its 1.2 s (examples/voice_range.rs).
const UNSTABLE_TIMES: f64 = 3.0;
const PAGE_MOST_DPA: f64 = 20000.0;

fn hz(midi: f64) -> f64 {
    440.0 * 2f64.powf((midi - 69.0) / 12.0)
}

/// The larynx's time constant: a fifth-order critically damped system fitted to Mandarin's tones and English's
/// intonation approaches its targets at 50.9 s^-1 (S. Prom-on, Y. Xu & B. Thipakorn 2009, JASA 125(1), 405-424,
/// doi:10.1121/1.3037222, Table I; docs/VOCAL_TRACT.md, "The F0 time constant").
pub const F0_TIME_CONSTANT_S: f64 = 0.0196;

/// A control approached as VocalTractLab approaches a gesture's target (v24::gestural `param_curve`): a fifth-order
/// critically damped system, its value and four derivatives carried from one target into the next, the derivatives
/// scaled down by the ratio of the time constants where the new is the slower. The dial's target is its control as it
/// stands each frame, held over the frame: the score a hand on the dial writes, a gesture a frame.
#[derive(Clone, Copy, Debug)]
struct Approach {
    /// Its value and its first four derivatives (a second, ...).
    f: [f64; 5],
    tau_s: f64,
}

impl Approach {
    fn at(value: f64) -> Approach {
        Approach { f: [value, 0.0, 0.0, 0.0, 0.0], tau_s: 0.0 }
    }

    /// Its value, held there: set by a phrase's score, which leaves it at rest.
    fn hold(&mut self, value: f64) {
        self.f = [value, 0.0, 0.0, 0.0, 0.0];
    }

    /// Its value `dt` s on, approaching `target` held over them with the time constant `tau_s` (none: at once).
    fn toward(&mut self, target: f64, tau_s: f64, dt: f64) -> f64 {
        if tau_s <= 0.0 {
            self.hold(target);
            self.tau_s = 0.0;
            return target;
        }
        if tau_s > self.tau_s {
            let ratio = self.tau_s / tau_s;
            let mut r = 1.0;
            for d in 1..5 {
                r *= ratio;
                self.f[d] *= r;
            }
        }
        self.tau_s = tau_s;
        let [f0, f1, f2, f3, f4] = self.f;
        let a = -1.0 / tau_s;
        let (a2, a3, a4) = (a * a, a * a * a, a * a * a * a);
        let c0 = f0 - target;
        let c1 = f1 - c0 * a;
        let c2 = (f2 - c0 * a2 - c1 * a * 2.0) / 2.0;
        let c3 = (f3 - c0 * a3 - c1 * a2 * 3.0 - c2 * a * 6.0) / 6.0;
        let c4 = (f4 - c0 * a4 - c1 * a3 * 4.0 - c2 * a2 * 12.0 - c3 * a * 24.0) / 24.0;
        let t = dt;
        let (t2, t3, t4) = (t * t, t * t * t, t * t * t * t);
        let e = (a * t).exp();
        self.f = [
            e * (c0 + c1 * t + c2 * t2 + c3 * t3 + c4 * t4) + target,
            e * ((c0 * a + c1) + (c1 * a + 2.0 * c2) * t + (c2 * a + 3.0 * c3) * t2 + (c3 * a + 4.0 * c4) * t3 + (c4 * a) * t4),
            e * ((c0 * a2 + 2.0 * c1 * a + 2.0 * c2) + (c1 * a2 + 4.0 * c2 * a + 6.0 * c3) * t + (c2 * a2 + 6.0 * c3 * a + 12.0 * c4) * t2 + (c3 * a2 + 8.0 * c4 * a) * t3 + (c4 * a2) * t4),
            e * ((c0 * a3 + 3.0 * c1 * a2 + 6.0 * c2 * a + 6.0 * c3) + (c1 * a3 + 6.0 * c2 * a2 + 18.0 * c3 * a + 24.0 * c4) * t + (c2 * a3 + 9.0 * c3 * a2 + 36.0 * c4 * a) * t2 + (c3 * a3 + 12.0 * c4 * a2) * t3 + (c4 * a3) * t4),
            e * ((c0 * a4 + 4.0 * c1 * a3 + 12.0 * c2 * a2 + 24.0 * c3 * a + 24.0 * c4) + (c1 * a4 + 8.0 * c2 * a3 + 36.0 * c3 * a2 + 96.0 * c4 * a) * t + (c2 * a4 + 12.0 * c3 * a3 + 72.0 * c4 * a2) * t2 + (c3 * a4 + 16.0 * c4 * a3) * t3 + (c4 * a4) * t4),
        ];
        self.f[0]
    }
}

/// A line's value at `t`: straight between its points, in order of time (a step two points at one time, the first its
/// value before, the second after), held beyond them.
fn line_at(line: &[(f64, f64)], t: f64) -> f64 {
    let (first, last) = (line[0], line[line.len() - 1]);
    if t <= first.0 {
        first.1
    } else if t >= last.0 {
        last.1
    } else {
        let k = line.partition_point(|p| p.0 <= t);
        let (a, b) = (line[k - 1], line[k]);
        if b.0 > a.0 { a.1 + (b.1 - a.1) * (t - a.0) / (b.0 - a.0) } else { b.1 }
    }
}

/// The rules' lung pressure tier (`rules`, 2.4's: none, and a pressure over each run of phones between pauses) with each
/// run sung on `line` (s from the phrase's first phone, which is `offset` s into the score; dPa): the run cut at the
/// line's points within it, each piece a gesture from the line's value after its start towards its value before its end,
/// approached with the run's own time constant; the rules' none between runs kept.
fn pressure_tier(rules: &[Gesture], line: &[(f64, f64)], offset: f64) -> Vec<Gesture> {
    const EDGE: f64 = 1e-9;
    let (mut tier, mut begin) = (Vec::new(), 0.0);
    for g in rules {
        let end = begin + g.duration_s;
        if g.d_val > 0.0 {
            let mut cuts: Vec<f64> = vec![begin, end];
            cuts.extend(line.iter().map(|p| p.0 + offset).filter(|t| *t > begin && *t < end));
            cuts.sort_by(|a, b| a.partial_cmp(b).unwrap());
            cuts.dedup_by(|a, b| (*a - *b).abs() < 1e-9);
            for w in cuts.windows(2) {
                let (a, b) = (w[0], w[1]);
                let (pa, pb) = (line_at(line, a + EDGE - offset), line_at(line, b - EDGE - offset));
                tier.push(Gesture { duration_s: b - a, d_val: pa, slope: (pb - pa) / (b - a), s_val: g.s_val.clone(), tau_s: g.tau_s, neutral: g.neutral });
            }
        } else {
            tier.push(g.clone());
        }
        begin = end;
    }
    tier
}

impl LiveVoice {
    /// VocalTractLab 2.3's.
    pub fn new(tract: VocalTract, glottis: GeometricGlottis, workers: usize, lookahead: usize) -> LiveVoice {
        let neutral_tract: [f64; NUM_PARAMS] = std::array::from_fn(|k| tract.param[k].neutral);
        let neutral_glottis: Vec<f64> = glottis.control.iter().map(|p| p.neutral).collect();
        let pool = GeometryPool::new(&tract, workers);
        let (shapes, glottis_shapes) = (tract.shapes.clone(), glottis.shapes.clone());
        let statics = glottis.statics.iter().map(|p| p.x).collect();
        let mut synth = Synthesizer::new(glottis, TdsModel::new());
        synth.reset();
        LiveVoice::with(shapes, glottis_shapes, neutral_tract, neutral_glottis, statics, Engine::V23 { synth, pool, queued: VecDeque::new() }, RATE, FRAME, lookahead)
    }

    /// VocalTractLab 2.4's, stepped `oversampling` times a sample, each step's system solved by `solver`, its geometry on
    /// `workers` threads and its frames' part on one more.
    pub fn new24(tract: v24::tract::VocalTract, glottis: v24::glottis::Glottis2025, oversampling: usize, solver: v24::tds::Solver, workers: usize, lookahead: usize) -> LiveVoice {
        let neutral_tract: [f64; NUM_PARAMS] = std::array::from_fn(|k| tract.param[k].neutral);
        let neutral_glottis: Vec<f64> = glottis.control.iter().map(|p| p.neutral).collect();
        let (shapes, glottis_shapes) = (tract.shapes.clone(), glottis.shapes.clone());
        let statics = glottis.statics.iter().map(|p| p.x).collect();
        let scoring = Scoring { tract: tract.clone(), glottis: glottis.clone() };
        let mut synth = v24::synth::Synthesizer::new(glottis, v24::tds::TdsModel::new());
        synth.tds.options.solver = solver;
        synth.set_oversampling(oversampling);
        let pipeline = v24::pipeline::Pipeline::new(&tract, &synth, workers, lookahead);
        let engine = Engine::V24 { synth, pipeline, sent: 0, queued: VecDeque::new(), auto: None };
        let mut voice = LiveVoice::with(shapes, glottis_shapes, neutral_tract, neutral_glottis, statics, engine, v24::constants::AUDIO_SAMPLING_RATE_HZ as f64, v24::synth::NUM_CHUNK_SAMPLES, lookahead);
        voice.scoring = Some(scoring);
        voice
    }

    /// VocalWind: 2.4's speaker, its acoustics VocalFork 3.0's as `switches` ask (PassiveModel::layout_switches and
    /// take_switches: losses=, trachea=, cores=, ...), stepped as many times a sample as its physics asks, or
    /// `oversampling` if more, as vtl-sing and vtl-say make it (acoustics=vocalwind, or vocalfork with 2.4's loss laws: PassiveModel::acoustics); its geometry on `workers` threads
    /// and its frames' part on one more.
    pub fn new_vocalwind(tract: v24::tract::VocalTract, glottis: v24::glottis::Glottis2025, switches: &[String], oversampling: usize, solver: v24::tds::Solver, workers: usize, lookahead: usize) -> LiveVoice {
        use v24::passive::PassiveModel;
        let mut voice = LiveVoice::new24(tract, glottis, 1, solver, workers, lookahead);
        let Some(scoring) = &voice.scoring else { unreachable!() };
        let Engine::V24 { synth, pipeline, .. } = &mut voice.engine else { unreachable!() };
        let mut options = synth.tds.options;
        PassiveModel::layout_switches(&mut options, switches);
        let (mut model, needed) = PassiveModel::for_speaker(&scoring.tract, &scoring.glottis, options);
        model.take_switches(switches);
        synth.use_vocalfork(model);
        synth.set_oversampling(needed.max(oversampling));
        *pipeline = v24::pipeline::Pipeline::new(&scoring.tract, synth, workers, lookahead);
        voice.passive = Some((switches.to_vec(), needed.max(oversampling)));
        voice
    }

    /// A vowel's first resonance as its acoustics put it, for the singer's layer (design H2: a woman's vowel opened toward
    /// the next more open one where her pitch passes it; voices/singing.json `openToPitch`): the phone `name`'s vowel
    /// shape on its tract, or that shape opened toward `toward`'s by its share (each parameter so far between them), held
    /// still with the glottis shut, on the passive core's network in frequency (src/v24/passive/frequency.rs) with its own
    /// switches -- its continuous response's lowest peak over 120 Hz on a 10-Hz grid, or the pole nearest `near` -- its
    /// pole by the secant method. VocalWind's alone. -> (Hz, its bandwidth Hz).
    pub fn first_resonance(&self, name: &str, toward: Option<(&str, f64)>, near: Option<f64>) -> Result<(f64, f64), String> {
        use v24::passive::frequency::{Complex, Stepping};
        let network = self.vowel_network(name, toward)?;
        let guess = match near {
            Some(hz) => Complex::resonance(hz, 60.0),
            None => {
                let size = |hz: f64| network.response(Complex::tone(hz), Stepping::Continuous).mouth.abs();
                let grid: Vec<f64> = (0..).map(|i| 120.0 + 10.0 * i as f64).take_while(|&f| f <= 2500.0).collect();
                let sizes: Vec<f64> = grid.iter().map(|&f| size(f)).collect();
                let peak = (1..grid.len() - 1).find(|&i| sizes[i] > sizes[i - 1] && sizes[i] >= sizes[i + 1]).ok_or("no resonance under 2.5 kHz")?;
                Complex::resonance(grid[peak], 60.0)
            }
        };
        network.resonance(guess, Stepping::Continuous).map(|pole| pole.frequency_and_bandwidth()).ok_or_else(|| "its first resonance not found".into())
    }

    /// A vowel's transfer on its own acoustics at each of `at`'s frequencies, Hz: the size of the lips' flow for a
    /// tone of unit flow put in above the glottis, on the same network `first_resonance` reads (its glottis shut, no
    /// noise) -- the vowel as it is, or opened toward another by a share. What a singer's close vowel is opened by
    /// is found on it (native/vocaltract/close-vowels.mjs: the first harmonics of a note at the pitches recorded
    /// singers sang).
    pub fn response_at(&self, name: &str, toward: Option<(&str, f64)>, at: &[f64]) -> Result<Vec<f64>, String> {
        use v24::passive::frequency::{Complex, Stepping};
        let network = self.vowel_network(name, toward)?;
        Ok(at.iter().map(|&hz| network.response(Complex::tone(hz), Stepping::Continuous).mouth.abs()).collect())
    }

    // (A vowel's passive network in frequency, as its own acoustics lay it: its shape, or its shape opened toward
    // another's by a share -- each parameter moved that share of the way -- its glottis shut, its noise silent.)
    fn vowel_network(&self, name: &str, toward: Option<(&str, f64)>) -> Result<v24::passive::frequency::Network, String> {
        use v24::passive::PassiveModel;
        let (Some(scoring), Some((switches, steps))) = (&self.scoring, &self.passive) else { return Err("a vowel's network in frequency: VocalWind's acoustics alone".into()) };
        let tract = &scoring.tract;
        let shape_of = |phone: &str| -> Result<[f64; NUM_PARAMS], String> {
            let shape = crate::segments::vowel_shape_on(phone, |x| tract.shape(x).is_some()).ok_or_else(|| format!("{phone}: no vowel"))?;
            tract.shape(shape).ok_or_else(|| format!("{phone}: no shape {shape} on its tract"))
        };
        let own = shape_of(name)?;
        let params = match toward {
            None => own,
            Some((other, share)) => {
                let b = shape_of(other)?;
                std::array::from_fn(|i| own[i] + share * (b[i] - own[i]))
            }
        };
        let mut t = tract.clone();
        t.calculate(&params);
        let mut tube = v24::tube::Tube::new();
        tube.set_from_tract(&t.tube());
        let mut options = v24::tds::TdsModel::new().options;
        options.generate_noise_sources = false;
        PassiveModel::layout_switches(&mut options, switches);
        let mut tds = v24::tds::TdsModel::new();
        tds.options = options;
        tds.set_tube(&tube, false);
        let mut k = v24::tds::TubeCoefficients::default();
        tds.tube_coefficients(&mut k);
        let mut model = PassiveModel::new(&tube, options);
        model.take_switches(switches);
        model.set_rate(v24::constants::AUDIO_SAMPLING_RATE_HZ as f64 * *steps as f64);
        let mut glottis = scoring.glottis.clone();
        glottis.calc_geometry();
        let (lengths, _) = glottis.tube_data();
        model.set_glottis_sections(&lengths, &[v24::tube::MIN_AREA_CM2; 2]);
        model.set_pressure_source(0.0, 0);
        Ok(model.network(&k))
    }

    /// The cores its acoustics are stepped on (VocalWind's crew's parts; 1 else).
    pub fn cores(&self) -> usize {
        match &self.engine {
            Engine::V23 { .. } => 1,
            Engine::V24 { synth, .. } => synth.cores(),
        }
    }

    /// Whether it sings phrases (2.4's speakers, and VocalWind).
    pub fn sings(&self) -> bool {
        self.scoring.is_some()
    }

    /// A phrase sung from `at` s on its clock, where its first phone begins: its phones, each its SAMPA name (VocalTractLab
    /// 2.4's; "" a pause), its length (s) and its stress, laid end to end from `at`; its F0's line, (s from `at`, Hz),
    /// straight between its points and held beyond them, approached with the time constant `f0_tau_s`; and its lung
    /// pressure's line (s from `at`, dPa), the same, over each run of its phones between pauses its rules give pressure to
    /// (`pressure_tier`; a line of one point a pressure held). Its score made by 2.4's rules from their least pause before
    /// it (ssml.rs RULES_REACH_24_S), as a reading's is (ssml.rs scores_v24). `flutter_percent`: its glottis's flutter
    /// over the phrase, 2.4's percent (None: its speaker's shapes' own, 25 in 2.4's speakers) -- Klatt's three sinusoids
    /// (v24::glottis: 12.7, 7.1 and 4.7 Hz, each half a percent of F0 at 25, 26 cents either way together) laid on the F0
    /// given, a speech synthesizer's device against a held vowel's sameness. A singer's line is its pitch whole, and on
    /// it they are heard as tones that are no harmonic's (the owner, 16 November 2026, of a Kyrie sung with little
    /// vibrato: "There's aliasing, I think"; "on some of the lower notes more than the higher notes"): a bass's D3 with
    /// them, all that is not a harmonic 22 dB under its harmonics and over them from 2 to 8 kHz, each partial there a
    /// cluster of side tones; without, 31 dB under. -> its score's (start, length) on the clock, and how much of its
    /// score had passed before it came (s: the voice already stepping beyond its start).
    pub fn sing(&mut self, at: f64, phones: &[(String, f64, u8)], f0: &[(f64, f64)], pressure: &[(f64, f64)], f0_tau_s: f64, flutter_percent: Option<f64>) -> Result<(f64, f64, f64), String> {
        self.sing_opened(at, phones, &[], f0, pressure, f0_tau_s, flutter_percent)
    }

    /// `sing`, its vowels opened where asked: `openings[j]`, for phone j, a more open vowel's phone and the share of the
    /// way to its shape the phone's vowel goes -- a woman's vowel opened toward the next more open one where her pitch
    /// passes its first resonance (design H2; voices/singing.json `openToPitch`) -- its vowel gesture, found by the
    /// phone's time, given a shape between its own and the more open one's, each parameter so far between them, so that
    /// its movements into and out of it stay its own. Phones none asks of, and any `openings` does not reach, as `sing`.
    pub fn sing_opened(&mut self, at: f64, phones: &[(String, f64, u8)], openings: &[Option<(String, f64)>], f0: &[(f64, f64)], pressure: &[(f64, f64)], f0_tau_s: f64, flutter_percent: Option<f64>) -> Result<(f64, f64, f64), String> {
        use crate::phones::RULES_REACH_24_S;
        let Some(scoring) = &self.scoring else { return Err("2.3's voice sings no phrase: 2.4's or VocalWind's does".into()) };
        if phones.is_empty() || f0.is_empty() || pressure.is_empty() {
            return Err("a phrase: its phones, its F0 and its lung pressure".into());
        }
        let mut segments = vec![Segment { name: String::new(), duration_s: RULES_REACH_24_S, labels: Vec::new() }];
        segments.extend(phones.iter().map(|(name, duration_s, stress)| Segment { name: name.clone(), duration_s: *duration_s, labels: vec![("stress".into(), stress.to_string())] }));
        let mut tract = scoring.tract.clone();
        let mut score = v24::gestural::GesturalScore::new();
        score.from_segments(&segments, &mut tract);
        // (Each opened phone's vowel: the vowel tier's gesture of its shape across the phone's middle, given the blend.)
        let mut begin = RULES_REACH_24_S;
        for (j, (name, duration_s, _)) in phones.iter().enumerate() {
            let middle = begin + 0.5 * duration_s;
            begin += duration_s;
            let Some(Some((toward, share))) = openings.get(j) else { continue };
            let shapes = |phone: &str| crate::segments::vowel_shape_on(phone, |x| tract.shape(x).is_some()).and_then(|s| tract.shape(s).map(|p| (s, p)));
            let (Some((own, a)), Some((other, b))) = (shapes(name), shapes(toward)) else { continue };
            let blended: [f64; NUM_PARAMS] = std::array::from_fn(|i| a[i] + share * (b[i] - a[i]));
            let named = format!("{own}>{other}@{share}");
            let mut t = 0.0;
            for g in score.seq[crate::gestural::VOWEL].gestures.iter_mut() {
                if t <= middle && middle < t + g.duration_s && g.s_val == own {
                    g.s_val = named.clone();
                    break;
                }
                t += g.duration_s;
            }
            if !tract.shapes.iter().any(|(n, _)| *n == named) {
                tract.shapes.push((named, blended));
            }
        }
        let length = score.duration_s();
        // (Its F0: a gesture between each two of its points, as a reading's line is made (ssml.rs f0_tier), on the score's
        // time line, which begins the rules' pause before `at`.)
        let st = |t: f64| -> f64 { crate::gestural::f0_st(line_at(f0, t)) };
        let mut cuts: Vec<f64> = vec![0.0, length];
        cuts.extend(f0.iter().map(|p| p.0 + RULES_REACH_24_S).filter(|t| *t > 0.0 && *t < length));
        cuts.sort_by(|a, b| a.partial_cmp(b).unwrap());
        cuts.dedup_by(|a, b| (*a - *b).abs() < 1e-9);
        const EDGE: f64 = 1e-9;
        score.seq[F0].gestures = cuts
            .windows(2)
            .map(|w| {
                let (a, b) = (w[0], w[1]);
                let (pa, pb) = (st(a + EDGE - RULES_REACH_24_S), st(b - EDGE - RULES_REACH_24_S));
                Gesture { duration_s: b - a, d_val: pa, slope: (pb - pa) / (b - a), s_val: String::new(), tau_s: f0_tau_s, neutral: false }
            })
            .collect();
        score.seq[LUNG_PRESSURE].gestures = pressure_tier(&score.seq[LUNG_PRESSURE].gestures, pressure, RULES_REACH_24_S);
        self.sung_most_dpa = pressure.iter().fold(self.sung_most_dpa, |most, p| most.max(p.1));
        let mut curves = score.curves(&tract, &scoring.glottis);
        if let Some(percent) = flutter_percent {
            curves.glottis[v24::glottis::FLUTTER].iter_mut().for_each(|x| *x = percent);
        }
        // (The fold law, where asked: the modal shape's controls at each moment's pitch and pressure, as far as the
        // glottis is in that shape.)
        if let (Some(law), Some(modal)) = (&self.fold_law, scoring.glottis.shape("modal")) {
            law.apply(&mut curves.glottis, &score.glottal_shape_weight("modal"), modal);
        }
        let start = at - RULES_REACH_24_S;
        let late = self.stepping_at().map_or(0.0, |s| (s - start).max(0.0));
        let k = self.phrases.partition_point(|p| p.start <= start);
        self.phrases.insert(k, Phrase { start, length, curves });
        Ok((start, length, late))
    }

    /// The time on its clock of the frame it steps next: where its sound reaches that frame's parameters, its engine's
    /// first frame setting where it begins and each after it reached at its own samples' end, as a score's frames are
    /// read (v24::gestural, frame i at i frames' time) (2.3's: none, its phrases being 2.4's).
    fn stepping_at(&self) -> Option<f64> {
        match &self.engine {
            Engine::V23 { .. } => None,
            Engine::V24 { sent, .. } => Some(self.origin_s + *sent as f64 * self.frame as f64 / self.rate),
        }
    }

    /// VocalTractLab 2.4's, beginning at `oversampling` steps a sample, then as many as its reading of itself allows
    /// (above).
    pub fn new24_adapting(tract: v24::tract::VocalTract, glottis: v24::glottis::Glottis2025, oversampling: usize, solver: v24::tds::Solver, workers: usize, lookahead: usize) -> LiveVoice {
        let (t, g) = (tract.clone(), glottis.clone());
        let mut voice = LiveVoice::new24(tract, glottis, oversampling, solver, workers, lookahead);
        if let Engine::V24 { auto, .. } = &mut voice.engine {
            *auto = Some(Adapt { tract: t, glottis: g, solver, workers, lookahead, wanted: oversampling, at_once: false });
        }
        voice
    }

    /// Its steps a sample (2.3's 1).
    pub fn oversampling(&self) -> usize {
        match &self.engine {
            Engine::V23 { .. } => 1,
            Engine::V24 { synth, .. } => synth.oversampling(),
        }
    }

    /// 2.4's and VocalWind's glottis as it is stepped (None for 2.3's): what it counts read and cleared
    /// (Glottis2025::open_steps).
    pub fn glottis24(&mut self) -> Option<&mut v24::glottis::Glottis2025> {
        match &mut self.engine {
            Engine::V23 { .. } => None,
            Engine::V24 { synth, .. } => Some(&mut synth.glottis),
        }
    }

    /// Where its steps a sample are its own to choose, those its last reading asks for (None: held as its player chose them).
    pub fn wanted(&self) -> Option<usize> {
        match &self.engine {
            Engine::V24 { auto: Some(a), .. } => Some(a.wanted),
            _ => None,
        }
    }

    #[allow(clippy::too_many_arguments)]
    fn with(shapes: Vec<(String, [f64; NUM_PARAMS])>, glottis_shapes: Vec<(String, Vec<f64>)>, neutral_tract: [f64; NUM_PARAMS], neutral_glottis: Vec<f64>, speaker_statics: Vec<f64>, engine: Engine, rate: f64, frame: usize, lookahead: usize) -> LiveVoice {
        let controls = Controls {
            vowel: String::new(),
            vowel2: String::new(),
            blend: 0.0,
            tract: [None; NUM_PARAMS],
            pitch: 69.0 + 12.0 * (neutral_glottis[FREQUENCY] / 440.0).log2(),
            pressure_dpa: neutral_glottis[PRESSURE],
            glottis: String::new(),
            glottis_values: vec![None; neutral_glottis.len()],
            statics: vec![None; speaker_statics.len()],
            tau_s: DEFAULT_TIME_CONSTANT_S,
            ramp_s: DEFAULT_TIME_CONSTANT_S,
            vibrato_hz: 0.0,
            vibrato_cents: 0.0,
            sounding: false,
        };
        LiveVoice {
            shapes,
            made: Vec::new(),
            glottis_shapes,
            neutral_tract,
            neutral_glottis: neutral_glottis.clone(),
            speaker_statics,
            engine,
            scoring: None,
            passive: None,
            phrases: Vec::new(),
            origin_s: 0.0,
            clock_s: 0.0,
            lookahead: lookahead.max(1) as u64,
            rate,
            frame,
            tract_now: neutral_tract.map(Approach::at),
            glottis_now: neutral_glottis.iter().map(|v| Approach::at(*v)).collect(),
            pressure_now: Approach::at(0.0),
            pitch_now: Approach::at(controls.pitch),
            controls,
            vibrato_phase: 0.0,
            started: false,
            buffer: VecDeque::new(),
            heard: None,
            reading: None,
            window: Window::new(),
            sound_s: 0.0,
            unstable: (0, 0.0),
            sung_most_dpa: 0.0,
            fold_law: None,
        }
    }

    pub fn shapes(&self) -> Vec<String> {
        self.shapes.iter().map(|(n, _)| n.clone()).collect()
    }

    /// A shape made for it, by a name apart from the speaker's shapes': kept while its vowels name it, found after the
    /// speaker's.
    pub fn make_shape(&mut self, name: &str, shape: [f64; NUM_PARAMS]) {
        let c = &self.controls;
        self.made.retain(|(n, _)| n != name && (*n == c.vowel || *n == c.vowel2));
        self.made.push((name.to_string(), shape));
    }

    /// Its phrases' modal shape given the fold law (design C), or its speaker's own again (None).
    pub fn set_fold_law(&mut self, law: Option<crate::fold_law::FoldLaw>) {
        self.fold_law = law;
    }

    pub fn glottis_shapes(&self) -> Vec<String> {
        self.glottis_shapes.iter().map(|(n, _)| n.clone()).collect()
    }

    /// The glottis's static parameters in force: each set by itself, else the speaker's.
    pub fn statics(&self) -> Vec<f64> {
        self.speaker_statics.iter().zip(&self.controls.statics).map(|(own, set)| set.unwrap_or(*own)).collect()
    }

    /// How softly its folds meet (cm; 0: 2.4's hard contact): Glottis2025::contact_cm, on 2.4's and VocalWind's glottis
    /// as it is stepped and as it is made again where its steps change. False for 2.3's, which has none.
    pub fn set_contact(&mut self, cm: f64) -> bool {
        match &mut self.engine {
            Engine::V23 { .. } => false,
            Engine::V24 { synth, auto, .. } => {
                synth.glottis.contact_cm = cm;
                if let Some(a) = auto {
                    a.glottis.contact_cm = cm;
                }
                true
            }
        }
    }

    /// A singer's open quotient by effort on its folds (None: 2.4's own): Glottis2025::sung, as `set_contact`.
    pub fn set_sung_folds(&mut self, law: Option<v24::glottis::SungFolds>) -> bool {
        match &mut self.engine {
            Engine::V23 { .. } => false,
            Engine::V24 { synth, auto, .. } => {
                synth.glottis.sung = law;
                if let Some(a) = auto {
                    a.glottis.sung = law;
                }
                true
            }
        }
    }

    /// The glottis's static parameter `j` set by itself (None: the speaker's own again), its glottis given it at once;
    /// false where it has none such.
    pub fn set_static(&mut self, j: usize, value: Option<f64>) -> bool {
        let Some(own) = self.speaker_statics.get(j).copied() else { return false };
        self.controls.statics[j] = value;
        let x = value.unwrap_or(own);
        match &mut self.engine {
            Engine::V23 { synth, .. } => synth.glottis.statics[j].x = x,
            Engine::V24 { synth, auto, .. } => {
                synth.glottis.statics[j].x = x;
                // (Kept where its steps change and it is made again.)
                if let Some(a) = auto {
                    a.glottis.statics[j].x = x;
                }
            }
        }
        true
    }

    /// The targets the controls give: the tract's 19 parameters and the glottis's.
    pub fn targets(&self) -> ([f64; NUM_PARAMS], Vec<f64>) {
        let c = &self.controls;
        let shape = |name: &str| self.shapes.iter().chain(&self.made).find(|(n, _)| n == name).map(|(_, v)| *v);
        let a = shape(&c.vowel).unwrap_or(self.neutral_tract);
        let b = shape(&c.vowel2).unwrap_or(a);
        let mut tract = [0.0; NUM_PARAMS];
        for j in 0..NUM_PARAMS {
            tract[j] = c.tract[j].unwrap_or(a[j] + c.blend * (b[j] - a[j]));
        }
        let shape = self.glottis_shapes.iter().find(|(n, _)| *n == c.glottis).map(|(_, v)| v.clone()).unwrap_or_else(|| self.neutral_glottis.clone());
        let glottis = shape.iter().enumerate().map(|(j, v)| c.glottis_values.get(j).copied().flatten().unwrap_or(*v)).collect();
        (tract, glottis)
    }

    /// The next frame's parameters: the tract's and the glottis's.
    fn step(&mut self) -> ([f64; NUM_PARAMS], Vec<f64>) {
        let dt = self.frame as f64 / self.rate;
        // (A phrase being sung: the frame its score's, the latest begun of those it falls in; the controls' approaches
        // left where it leaves them, at rest.)
        if let Some(at) = self.stepping_at() {
            self.phrases.retain(|p| at < p.start + p.length);
            if let Some(p) = self.phrases.iter().rev().find(|p| p.start <= at) {
                let (t, g) = v24::gestural::params_at(&p.curves, at - p.start);
                let tract: [f64; NUM_PARAMS] = std::array::from_fn(|j| t[j]);
                for (now, v) in self.tract_now.iter_mut().zip(&tract) {
                    now.hold(*v);
                }
                for (j, v) in g.iter().enumerate() {
                    if j != FREQUENCY && j != PRESSURE {
                        self.glottis_now[j].hold(*v);
                    }
                }
                self.pressure_now.hold(g[PRESSURE]);
                self.pitch_now.hold(69.0 + 12.0 * (g[FREQUENCY] / 440.0).log2());
                return (tract, g);
            }
        }
        let (target, glottis_target) = self.targets();
        let c = &self.controls;
        let mut tract = [0.0; NUM_PARAMS];
        for j in 0..NUM_PARAMS {
            tract[j] = self.tract_now[j].toward(target[j], c.tau_s, dt);
        }
        let mut g = vec![0.0; glottis_target.len()];
        for (j, v) in glottis_target.iter().enumerate() {
            if j != FREQUENCY && j != PRESSURE {
                g[j] = self.glottis_now[j].toward(*v, c.tau_s, dt);
            }
        }
        let want = if c.sounding { c.pressure_dpa } else { 0.0 };
        g[PRESSURE] = self.pressure_now.toward(want, c.ramp_s, dt);
        self.vibrato_phase = (self.vibrato_phase + 2.0 * std::f64::consts::PI * c.vibrato_hz * dt) % (2.0 * std::f64::consts::PI);
        g[FREQUENCY] = hz(self.pitch_now.toward(c.pitch, F0_TIME_CONSTANT_S, dt) + c.vibrato_cents / 100.0 * self.vibrato_phase.sin());
        (tract, g)
    }

    /// `n` samples, made as needed; read, each second of them.
    pub fn pull(&mut self, n: usize) -> Vec<f32> {
        let t0 = Instant::now();
        let made = self.make(n);
        self.window.busy += t0.elapsed().as_secs_f64();
        self.window.sound += n as f64 / self.rate;
        self.clock_s += n as f64 / self.rate;
        if self.window.sound >= 1.0 {
            self.read();
        }
        made
    }

    /// The second's reading (above); where its steps are its own, those it asks for.
    fn read(&mut self) {
        let (wall, me) = (self.window.began.elapsed().as_secs_f64(), counters::thread_id());
        let mut threads: Vec<Share> = counters::threads()
            .iter()
            .map(|t| {
                let before = self.window.threads.iter().find(|b| b.id == t.id).map(|b| b.counts).unwrap_or_default();
                let c = t.counts.since(&before);
                let name = if t.id == me { "acoustics".to_string() } else { t.name.clone() };
                Share { name, core: (c.levels[0].time_ns + c.levels[1].time_ns) as f64 * 1e-9 / wall.max(1e-9), performance: c.performance_share() }
            })
            .collect();
        threads.sort_by(|a, b| (a.name != "acoustics", &a.name).cmp(&(b.name != "acoustics", &b.name)));
        let pace = self.window.sound / self.window.busy.max(1e-9);
        let steps = self.oversampling();
        if let Engine::V24 { auto: Some(a), .. } = &mut self.engine {
            a.wanted = wanted(1.0 / pace, steps);
            a.at_once = pace < 1.0;
        }
        self.reading = Some(Reading { pace, steps, threads });
        self.window = Window::new();
    }

    /// Its steps a sample changed to those its reading asks for, at a silence, or at once where it has fallen behind: the
    /// synthesizer and its threads made again, the tube from rest.
    fn change(&mut self) {
        let silent = !self.controls.sounding && self.pressure_now.f[0] < 1.0;
        let Engine::V24 { synth, auto: Some(a), .. } = &self.engine else { return };
        if a.wanted == synth.oversampling() || !(silent || a.at_once) {
            return;
        }
        let Engine::V24 { auto, .. } = &mut self.engine else { return };
        let Some(mut a) = auto.take() else { return };
        a.at_once = false;
        let mut synth = v24::synth::Synthesizer::new(a.glottis.clone(), v24::tds::TdsModel::new());
        synth.tds.options.solver = a.solver;
        synth.set_oversampling(a.wanted);
        let pipeline = v24::pipeline::Pipeline::new(&a.tract, &synth, a.workers, a.lookahead);
        self.engine = Engine::V24 { synth, pipeline, sent: 0, queued: VecDeque::new(), auto: Some(a) };
        // (Its new engine's first sample where the sound made so far ends: nothing is held made at a change.)
        self.origin_s = self.sound_s;
        self.started = false;
        self.window = Window::new();
    }

    fn make(&mut self, n: usize) -> Vec<f32> {
        let frame = self.frame;
        let mut out = [0.0; 256];
        while self.buffer.len() < n {
            // Frames asked for `lookahead` ahead of the one heard.
            let ahead = match &self.engine {
                Engine::V23 { pool, .. } => pool.pending() < self.lookahead,
                Engine::V24 { queued, .. } => (queued.len() as u64) <= self.lookahead,
            };
            if ahead {
                let (t, g) = self.step();
                match &mut self.engine {
                    Engine::V23 { pool, queued, .. } => {
                        pool.submit(&t);
                        queued.push_back(g);
                    }
                    Engine::V24 { pipeline, sent, queued, .. } => {
                        pipeline.send(&t, &g, if *sent == 0 { 0 } else { frame });
                        *sent += 1;
                        queued.push_back((g[FREQUENCY], g[PRESSURE]));
                    }
                }
                continue;
            }
            // (The first frame only sets where the synthesis starts, as VocalTractLab's does.)
            let made = if self.started { frame } else { 0 };
            if self.started && self.buffer.is_empty() {
                self.change();
                if !self.started {
                    continue;
                }
            }
            match &mut self.engine {
                Engine::V23 { synth, pool, queued } => {
                    let tube = pool.next(true).expect("a frame's geometry");
                    let g = queued.pop_front().expect("a frame's glottis");
                    synth.add_geometry(&tube, &g, &mut out[..made]);
                    self.heard = Some(Heard { areas: tube.area_cm2.to_vec(), lengths: tube.length_cm.to_vec(), f0: g[FREQUENCY], pressure: g[PRESSURE] });
                }
                Engine::V24 { synth, pipeline, queued, .. } => {
                    let (f0, pressure) = queued.pop_front().expect("a frame's glottis");
                    if made > 0 {
                        synth.add_records(&mut out[..made], pipeline);
                    }
                    if let Some(t) = pipeline.heard() {
                        self.heard = Some(Heard { areas: t.area_cm2.to_vec(), lengths: t.length_cm.to_vec(), f0, pressure });
                    }
                }
            }
            // (The safety net (the owner, 13 November 2026: "Yes, provide the safety net"): a model gone unstable -- its
            // pressures far beyond its breath's, or its sound not finite -- started again from rest at once, the frame
            // silent, and said (`unstable`). The cases it was made for -- 2.4's glottis held wide open, or a fricative,
            // under a strong flow at 144 and 192 kHz -- are mended (v24::tds::Options::passive_bernoulli); it is kept for
            // whatever else.)
            let mut fresh = false;
            let bound_dpa = UNSTABLE_TIMES * PAGE_MOST_DPA.max(self.controls.pressure_dpa).max(self.sung_most_dpa);
            let pressures_bound = |p: &dyn Fn(usize) -> f64, n: usize| (0..n).all(|i| p(i).abs() <= bound_dpa);
            let inside = match &self.engine {
                Engine::V23 { synth, .. } => pressures_bound(&|i| synth.tds.section_pressure(i), crate::tube::NUM_SECTIONS),
                Engine::V24 { synth, .. } => pressures_bound(&|i| synth.tds.section_pressure(i), v24::tube::NUM_SECTIONS),
            };
            if !inside || out[..made].iter().any(|x| !x.is_finite()) {
                out[..made].iter_mut().for_each(|x| *x = 0.0);
                self.unstable = (self.unstable.0 + 1, self.sound_s);
                match &mut self.engine {
                    // (2.3's first frame after its reset only sets where it starts.)
                    Engine::V23 { synth, .. } => {
                        synth.reset();
                        fresh = true;
                    }
                    Engine::V24 { synth, .. } => synth.reset(),
                }
            }
            self.sound_s += made as f64 / self.rate;
            self.started = !fresh;
            self.buffer.extend(out[..made].iter().map(|x| *x as f32));
        }
        self.buffer.drain(..n).collect()
    }
}

#[cfg(test)]
mod tests {
    use super::{pressure_tier, wanted, Approach, Gesture, F0_TIME_CONSTANT_S};

    /// A fifth-order critically damped step from rest, from 0 toward 1: what VocalTractLab's `param_curve` makes of one
    /// target (its c0 -1, each c_k c_{k-1}/(k tau)).
    fn step_response(t: f64, tau_s: f64) -> f64 {
        let u = t / tau_s;
        1.0 - (-u).exp() * (1.0 + u + u * u / 2.0 + u * u * u / 6.0 + u * u * u * u / 24.0)
    }

    /// The dial's controls approached as a score's targets are: a step from rest the engine's step response, frame by
    /// frame; a target held over many frames the same as one gesture over them all; half made at the engine's own time
    /// to half (v24::gestural::time_to_step_response_value_s, to its twentieth of a time constant); none at once.
    #[test]
    fn the_dials_controls_approached_as_a_scores_targets() {
        let dt = 120.0 / 48000.0;
        let mut x = Approach::at(0.0);
        for i in 1..=200 {
            let v = x.toward(1.0, F0_TIME_CONSTANT_S, dt);
            assert!((v - step_response(i as f64 * dt, F0_TIME_CONSTANT_S)).abs() < 1e-12, "frame {i}: {v}");
        }
        // (Moved on by a new target in mid-course, frame by frame or in one gesture: the same.)
        let (mut a, mut b) = (Approach::at(0.0), Approach::at(0.0));
        for _ in 0..8 {
            a.toward(1.0, 0.01, dt);
            b.toward(1.0, 0.01, dt);
        }
        for _ in 0..40 {
            a.toward(0.3, 0.01, dt);
        }
        b.toward(0.3, 0.01, 40.0 * dt);
        // (Each derivative to a billionth of a unit step's own size at that order, 1/tau^d.)
        assert!((0..5).all(|d| (a.f[d] - b.f[d]).abs() <= 1e-9 * 0.01f64.powi(-(d as i32))), "{:?} {:?}", a.f, b.f);
        // (Half made where the engine's own reckoning says.)
        let half = crate::v24::gestural::time_to_step_response_value_s(0.5, F0_TIME_CONSTANT_S);
        assert!((step_response(half, F0_TIME_CONSTANT_S) - 0.5).abs() < 0.03 && (half - 0.0915).abs() < 0.001, "{half}");
        // (A slower target takes the derivatives down by the ratio of the time constants, as the engine's does.)
        let mut c = Approach::at(0.0);
        c.toward(1.0, 0.01, dt);
        let before = c.f;
        c.toward(1.0, 0.02, 0.0);
        assert!((c.f[1] - before[1] * 0.5).abs() < 1e-9 * before[1].abs() && (c.f[4] - before[4] / 16.0).abs() < 1e-9 * before[4].abs());
        // (None: at once.)
        assert_eq!(c.toward(5.0, 0.0, dt), 5.0);
        assert_eq!(c.f, [5.0, 0.0, 0.0, 0.0, 0.0]);
    }

    /// VocalWind's glottis takes the lung pressure it is given beyond 2.4's range (16,000 dPa in the speaker files): JD2
    /// on /a/ at C3 at 24,000 dPa louder than at 16,000; 2.4's own glottis holds both at 16,000, at one level once its
    /// breath has risen.
    #[test]
    fn vocalwind_takes_pressures_beyond_24s_range() {
        use crate::blend::{synthesis_home, voices_file, Voices};
        use crate::v24;
        let file = Voices::read(&voices_file()).unwrap().file(&synthesis_home(), "JD2").unwrap();
        if !std::path::Path::new(&file).exists() {
            eprintln!("skipped: JD2's speaker file is not on this machine ({file})");
            return;
        }
        let speaker = v24::speaker::Speaker::read(&file).unwrap();
        let sung = |vocalwind: bool, dpa: f64| -> Vec<f32> {
            let (t, g) = (speaker.tract.clone(), speaker.glottis.clone());
            let mut voice = if vocalwind { super::LiveVoice::new_vocalwind(t, g, &[], 1, v24::tds::Solver::Envelope, 1, 4) } else { super::LiveVoice::new24(t, g, 1, v24::tds::Solver::Envelope, 1, 4) };
            voice.controls.vowel = "a".into();
            voice.controls.glottis = "modal".into();
            voice.controls.pitch = 48.0;
            voice.controls.pressure_dpa = dpa;
            voice.controls.sounding = true;
            voice.pull(28800)
        };
        let level = |x: &[f32]| 10.0 * (x[19200..].iter().map(|v| (*v as f64).powi(2)).sum::<f64>() / 9600.0).log10();
        let (loud, louder) = (sung(true, 16000.0), sung(true, 24000.0));
        assert!(level(&louder) - level(&loud) > 3.0, "VocalWind: {:.2} dB at 16,000 dPa, {:.2} at 24,000", level(&loud), level(&louder));
        let (held, asked) = (sung(false, 16000.0), sung(false, 24000.0));
        assert!((level(&asked) - level(&held)).abs() < 0.05, "2.4: {:.3} dB at 16,000 dPa, {:.3} at 24,000", level(&held), level(&asked));
    }

    /// A voice at full scale is not a model gone unstable: JD2 on /a/ at C#4 at 50,000 dPa (a singer's beyond fff there)
    /// sounds through, never started again, its peaks beyond full scale (until 15 November 2026 the safety net took them
    /// for an unstable model and silenced the note but for its noise).
    #[test]
    fn a_voice_at_full_scale_sounds_through() {
        use crate::blend::{synthesis_home, voices_file, Voices};
        use crate::v24;
        let file = Voices::read(&voices_file()).unwrap().file(&synthesis_home(), "JD2").unwrap();
        if !std::path::Path::new(&file).exists() {
            eprintln!("skipped: JD2's speaker file is not on this machine ({file})");
            return;
        }
        let speaker = v24::speaker::Speaker::read(&file).unwrap();
        let mut voice = super::LiveVoice::new_vocalwind(speaker.tract, speaker.glottis, &[], 1, v24::tds::Solver::Envelope, 1, 4);
        voice.controls.vowel = "a".into();
        voice.controls.glottis = "modal".into();
        voice.controls.pitch = 61.0;
        voice.controls.pressure_dpa = 50000.0;
        voice.controls.sounding = true;
        let sung = voice.pull(28800);
        let peak = sung[14400..].iter().fold(0f32, |m, v| m.max(v.abs()));
        let level = 10.0 * (sung[14400..].iter().map(|v| (*v as f64).powi(2)).sum::<f64>() / 14400.0).log10();
        assert_eq!(voice.unstable.0, 0, "started again {} times, the last at {:.3} s", voice.unstable.0, voice.unstable.1);
        assert!(peak > 1.0 && level > -12.0, "its peak {peak:.2}, its level {level:.2} dBFS");
    }

    /// A phrase sung with its flutter asked has that flutter through its whole score; none asked, its speaker's own.
    #[test]
    fn a_sung_phrase_takes_the_flutter_it_is_asked() {
        use crate::blend::{synthesis_home, voices_file, Voices};
        use crate::v24;
        let file = Voices::read(&voices_file()).unwrap().file(&synthesis_home(), "JD2").unwrap();
        if !std::path::Path::new(&file).exists() {
            eprintln!("skipped: {file} is not there");
            return;
        }
        let flutter = |asked: Option<f64>| -> Vec<f64> {
            let speaker = v24::speaker::Speaker::read(&file).unwrap();
            let mut voice = super::LiveVoice::new24(speaker.tract, speaker.glottis, 1, v24::tds::Solver::Envelope, 1, 4);
            voice.sing(1.0, &[("a".to_string(), 0.5, 1)], &[(0.0, 147.0)], &[(0.0, 8000.0)], 0.0, asked).unwrap();
            voice.phrases[0].curves.glottis[v24::glottis::FLUTTER].clone()
        };
        let (own, none) = (flutter(None), flutter(Some(0.0)));
        assert!(none.iter().all(|x| *x == 0.0), "asked none");
        assert!(own.iter().any(|x| *x > 0.0), "its speaker's own");
        assert_eq!(own.len(), none.len());
    }

    /// A vowel opened toward a more open one (design H2, LiveVoice::sing_opened and first_resonance): asked no share, a
    /// held [i]'s tract curves are `sing`'s; asked half the way to [a], each held parameter half way between [i]'s and the
    /// opened one's; and on VocalWind's network the first resonance rises from [i]'s through the blend to [a]'s.
    #[test]
    fn a_vowel_opened_toward_a_more_open_one() {
        use crate::blend::{synthesis_home, voices_file, Voices};
        use crate::v24;
        let file = Voices::read(&voices_file()).unwrap().file(&synthesis_home(), "W02").unwrap();
        if !std::path::Path::new(&file).exists() {
            eprintln!("skipped: {file} is not there");
            return;
        }
        let held = |opening: Option<(String, f64)>| -> Vec<f64> {
            let speaker = v24::speaker::Speaker::read(&file).unwrap();
            let mut voice = super::LiveVoice::new24(speaker.tract, speaker.glottis, 1, v24::tds::Solver::Envelope, 1, 4);
            voice.sing_opened(1.0, &[("i".to_string(), 1.0, 1)], &[opening], &[(0.0, 587.0)], &[(0.0, 8000.0)], 0.0, Some(0.0)).unwrap();
            let c = &voice.phrases[0].curves.tract;
            // (each parameter where the vowel is held: three quarters of the way through the phrase)
            c.iter().map(|p| p[p.len() * 3 / 4]).collect()
        };
        let speaker = v24::speaker::Speaker::read(&file).unwrap();
        let mut plain = super::LiveVoice::new24(speaker.tract, speaker.glottis, 1, v24::tds::Solver::Envelope, 1, 4);
        plain.sing(1.0, &[("i".to_string(), 1.0, 1)], &[(0.0, 587.0)], &[(0.0, 8000.0)], 0.0, Some(0.0)).unwrap();
        let unopened: Vec<f64> = plain.phrases[0].curves.tract.iter().map(|p| p[p.len() * 3 / 4]).collect();
        assert_eq!(held(None), unopened, "no opening asked: sing's own");
        assert_eq!(held(Some(("a".to_string(), 0.0))), unopened, "a share of none: sing's own");
        let (half, whole) = (held(Some(("a".to_string(), 0.5))), held(Some(("a".to_string(), 1.0))));
        for (k, ((u, h), w)) in unopened.iter().zip(&half).zip(&whole).enumerate() {
            assert!((h - 0.5 * (u + w)).abs() <= 1e-6 * (1.0 + u.abs() + w.abs()), "parameter {k}: {h} not half way from {u} to {w}");
        }
        let speaker = v24::speaker::Speaker::read(&file).unwrap();
        let wind = super::LiveVoice::new_vocalwind(speaker.tract, speaker.glottis, &["acoustics=vocalwind".to_string()], 1, v24::tds::Solver::Envelope, 1, 4);
        let (i, _) = wind.first_resonance("i", None, None).unwrap();
        let (blend, _) = wind.first_resonance("i", Some(("a", 0.5)), Some(i)).unwrap();
        let (a, _) = wind.first_resonance("a", None, None).unwrap();
        assert!(i < blend && blend < a + 50.0 && i > 250.0 && a < 900.0, "[i] {i:.0} Hz, half way to [a] {blend:.0}, [a] {a:.0}");
    }

    /// VocalWind without its turbulence noise where noise=0 is asked: until 16 November 2026 the synthesizer's reset gave
    /// the passive core its own options back, the noise on whatever was asked. A held [s] sung with its noise and without.
    #[test]
    fn vocalwind_without_its_noise_where_asked() {
        use crate::blend::{synthesis_home, voices_file, Voices};
        use crate::v24;
        let file = Voices::read(&voices_file()).unwrap().file(&synthesis_home(), "JD2").unwrap();
        if !std::path::Path::new(&file).exists() {
            eprintln!("skipped: {file} is not there");
            return;
        }
        let rms = |switches: &[String]| -> f64 {
            let speaker = v24::speaker::Speaker::read(&file).unwrap();
            let mut voice = super::LiveVoice::new_vocalwind(speaker.tract, speaker.glottis, switches, 1, v24::tds::Solver::Envelope, 1, 4);
            voice.sing(0.5, &[("s".to_string(), 0.6, 1)], &[(0.0, 120.0)], &[(0.0, 8000.0)], 0.0, None).unwrap();
            let x = voice.pull(57600);
            let held = &x[33600..48000];
            (held.iter().map(|v| (*v as f64).powi(2)).sum::<f64>() / held.len() as f64).sqrt()
        };
        let (with, without) = (rms(&[]), rms(&["noise=0".to_string()]));
        assert!(with > 0.0 && without < 1e-2 * with, "an [s] with its noise {with:.3e}, without {without:.3e}");
    }

    /// VocalWind's glottis takes the pitch it is given beyond 2.4's range (40 to 600 Hz): W02 on /a/ at G5 sounds at G5,
    /// its fundamental there far over anything at 600 Hz; 2.4's own glottis holds it at 600 Hz.
    #[test]
    fn vocalwind_sings_above_24s_600_hz() {
        use crate::blend::{synthesis_home, voices_file, Voices};
        use crate::v24;
        let file = Voices::read(&voices_file()).unwrap().file(&synthesis_home(), "W02").unwrap();
        if !std::path::Path::new(&file).exists() {
            eprintln!("skipped: W02's speaker file is not on this machine ({file})");
            return;
        }
        let speaker = v24::speaker::Speaker::read(&file).unwrap();
        let sung = |vocalwind: bool| -> Vec<f32> {
            let (t, g) = (speaker.tract.clone(), speaker.glottis.clone());
            let mut voice = if vocalwind { super::LiveVoice::new_vocalwind(t, g, &[], 1, v24::tds::Solver::Envelope, 1, 4) } else { super::LiveVoice::new24(t, g, 1, v24::tds::Solver::Envelope, 1, 4) };
            voice.controls.vowel = "a".into();
            voice.controls.glottis = "modal".into();
            voice.controls.pitch = 79.0;
            voice.controls.pressure_dpa = 16000.0;
            voice.controls.sounding = true;
            voice.pull(28800)
        };
        // (A frequency's power in the last 0.3 s, Hann-windowed: the DFT at that one frequency.)
        let power = |x: &[f32], hz: f64| {
            let tail = &x[x.len() - 14400..];
            let n = tail.len() as f64;
            let (mut re, mut im) = (0.0, 0.0);
            for (i, v) in tail.iter().enumerate() {
                let w = 0.5 * (1.0 - (2.0 * std::f64::consts::PI * i as f64 / (n - 1.0)).cos()) * *v as f64;
                let phase = 2.0 * std::f64::consts::PI * hz * i as f64 / 48000.0;
                re += w * phase.cos();
                im -= w * phase.sin();
            }
            re * re + im * im
        };
        let g5 = 440.0 * 2f64.powf(10.0 / 12.0);
        let (wind, held) = (sung(true), sung(false));
        assert!(power(&wind, g5) > 100.0 * power(&wind, 600.0), "VocalWind: {:.3e} at G5, {:.3e} at 600 Hz", power(&wind, g5), power(&wind, 600.0));
        assert!(power(&held, 600.0) > 100.0 * power(&held, g5), "2.4: {:.3e} at 600 Hz, {:.3e} at G5", power(&held, 600.0), power(&held, g5));
    }

    /// The live voice's pitch moved on the dial: its F0 approached at the larynx's measured time constant, the vibrato on
    /// it as set; its pressure at the breath's rise and fall.
    #[test]
    fn the_dials_pitch_at_the_larynxs_pace() {
        use crate::blend::{synthesis_home, voices_file, Voices};
        use crate::v24;
        let file = Voices::read(&voices_file()).unwrap().file(&synthesis_home(), "JD2").unwrap();
        if !std::path::Path::new(&file).exists() {
            eprintln!("skipped: JD2's speaker file is not on this machine ({file})");
            return;
        }
        let speaker = v24::speaker::Speaker::read(&file).unwrap();
        let mut voice = super::LiveVoice::new24(speaker.tract, speaker.glottis, 1, v24::tds::Solver::Envelope, 1, 4);
        let dt = voice.frame as f64 / voice.rate;
        voice.controls.pitch = 60.0;
        voice.controls.pressure_dpa = 8000.0;
        voice.controls.ramp_s = 0.02;
        voice.controls.sounding = true;
        for _ in 0..400 {
            voice.step();
        }
        let midi = |hz: f64| 69.0 + 12.0 * (hz / 440.0).log2();
        voice.controls.pitch = 67.0;
        for i in 1..=80 {
            let (_, g) = voice.step();
            let want = 60.0 + 7.0 * step_response(i as f64 * dt, F0_TIME_CONSTANT_S);
            assert!((midi(g[super::FREQUENCY]) - want).abs() < 1e-9, "frame {i}: {} for {want}", midi(g[super::FREQUENCY]));
        }
        voice.controls.sounding = false;
        for i in 1..=40 {
            let (_, g) = voice.step();
            let want = 8000.0 * (1.0 - step_response(i as f64 * dt, 0.02));
            assert!((g[super::PRESSURE] - want).abs() < 1e-6, "frame {i}: {} for {want}", g[super::PRESSURE]);
        }
    }

    #[test]
    fn a_phrase_sung_on_its_pressure_line() {
        let g = |d: f64, v: f64| Gesture { duration_s: d, d_val: v, slope: 0.0, s_val: String::new(), tau_s: 0.01, neutral: false };
        // (The rules' tier: none for 0.1 s, a run of phones at 8000 dPa for 1 s, none after; the phrase's first phone 0.1 s
        // into the score.)
        let rules = [g(0.1, 0.0), g(1.0, 8000.0), g(0.3, 0.0)];
        let shown = |line: &[(f64, f64)]| pressure_tier(&rules, line, 0.1).iter().map(|g| (g.duration_s, g.d_val, g.slope, g.tau_s)).collect::<Vec<_>>();
        let near = |a: &[(f64, f64, f64, f64)], b: &[(f64, f64, f64, f64)]| {
            a.len() == b.len() && a.iter().zip(b).all(|(x, y)| (x.0 - y.0).abs() < 1e-6 && (x.1 - y.1).abs() < 1e-3 && (x.2 - y.2).abs() < 1e-3 && x.3 == y.3)
        };
        // A pressure held: the run at it, the rules' none kept.
        let held = shown(&[(0.0, 9000.0)]);
        assert!(near(&held, &[(0.1, 0.0, 0.0, 0.01), (1.0, 9000.0, 0.0, 0.01), (0.3, 0.0, 0.0, 0.01)]), "{held:?}");
        // A step at 0.4 s: the run cut there, each side at its own, approached with the run's time constant.
        let stepped = shown(&[(0.0, 6000.0), (0.4, 6000.0), (0.4, 12000.0)]);
        assert!(near(&stepped, &[(0.1, 0.0, 0.0, 0.01), (0.4, 6000.0, 0.0, 0.01), (0.6, 12000.0, 0.0, 0.01), (0.3, 0.0, 0.0, 0.01)]), "{stepped:?}");
        // A rise: one gesture, its slope the line's.
        let rising = shown(&[(0.0, 6000.0), (1.0, 10000.0)]);
        assert!(near(&rising, &[(0.1, 0.0, 0.0, 0.01), (1.0, 6000.0, 4000.0, 0.01), (0.3, 0.0, 0.0, 0.01)]), "{rising:?}");
    }

    #[test]
    fn the_steps_a_reading_asks_for() {
        // (As read on the M5: 2.4's order at 3 steps taking 64% of real time stays; at 2, 44%, takes 3.)
        assert_eq!(wanted(0.64, 3), 3);
        assert_eq!(wanted(0.44, 2), 3);
        assert_eq!(wanted(0.14, 1), 4);
        // (Above 70% and up to 90% held; above 90%, as many as would take 70%.)
        assert_eq!(wanted(0.85, 4), 4);
        assert_eq!(wanted(0.95, 4), 2);
        assert_eq!(wanted(0.95, 3), 2);
        assert_eq!(wanted(1.6, 2), 1);
        assert_eq!(wanted(1.6, 1), 1);
    }

    /// A vowel made for the voice from its speaker's vowel space (vtl-stream's `vowel=[ɨ]`, `place=`): its target, found
    /// after the speaker's own shapes, kept while its vowels name it.
    #[test]
    fn a_vowel_made_from_the_speakers_space() {
        use crate::blend::{synthesis_home, voices_file, Voices};
        use crate::v24;
        use crate::vowel_space::space;
        let file = Voices::read(&voices_file()).unwrap().file(&synthesis_home(), "JD2").unwrap();
        if !std::path::Path::new(&file).exists() {
            eprintln!("skipped: JD2's speaker file is not on this machine ({file})");
            return;
        }
        let speaker = v24::speaker::Speaker::read(&file).unwrap();
        let sounded = space().of_speaker(&mut speaker.tract.clone()).unwrap();
        let made = sounded.space.at(space().place("ɨ").unwrap());
        let mut voice = super::LiveVoice::new24(speaker.tract, speaker.glottis, 1, v24::tds::Solver::Envelope, 1, 4);
        assert!(!voice.shapes().contains(&"[ɨ]".to_string()));
        voice.make_shape("[ɨ]", made);
        voice.controls.vowel = "[ɨ]".into();
        assert_eq!(voice.targets().0, made);
        // (Another made for vowel2 keeps the first; a third, the first let go, drops it.)
        voice.make_shape("@3,1,0.5,0", sounded.space.at(crate::vowel_space::Place::new(3.0, 1.0, 0.5)));
        voice.controls.vowel2 = "@3,1,0.5,0".into();
        assert_eq!(voice.made.len(), 2);
        voice.controls.vowel = "i".into();
        voice.make_shape("[æ]", made);
        assert_eq!(voice.made.iter().map(|(n, _)| n.as_str()).collect::<Vec<_>>(), ["@3,1,0.5,0", "[æ]"]);
        assert_eq!(voice.targets().0, voice.shapes.iter().find(|(n, _)| n == "i").unwrap().1);
    }
}
