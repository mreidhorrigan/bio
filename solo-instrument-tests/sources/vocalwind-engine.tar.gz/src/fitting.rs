//! The voice's fits (research/VOCALWIND_FITS.md; the owner, 16 November 2026: "we likely need to systematize our
//! fitting, tuning, and optimization process for impedance and other audio targets, as we did for Openwind, to avoid
//! getting caught in guess-and-test loops"; "You are clear to build L and the fitting system"; "The system must be built
//! in Rust, per our design principles"). The winds' method (research/MODEL_REFACTOR_PLAN.md, "The method") for the
//! tract: every fit computed on the engine's own network in frequency (src/v24/passive/frequency.rs: the passive core
//! laid as it plays, its response as its step takes it) -- cases, each a geometry the engine lays under its measured
//! conditions; targets, each a measured resonance; free parameters, each a switch with its feasible range and source in
//! acoustics/tract.json (`free`); the hard tracts before the living (gates in order); one error, Fant's -- each
//! bandwidth's log ratio in dB -- the frequencies' in cents beside it; a bounded search; one scoreboard; and each fit's
//! result written with its data and date (acoustics/fitted.json), adopted by a switch the owner hears first.
//!
//! A case's resonances are found once, on the network as the case starts -- its transfer's peaks on a grid, each refined
//! to its pole and matched to the measured resonance nearest it -- and then followed from pole to pole as a parameter
//! moves (the secant method from the last), so that an evaluation costs a few responses a resonance.
use crate::v24;
use crate::v24::passive::frequency::{Complex, Network, Stepping};
use crate::v24::passive::PassiveModel;
use crate::v24::tube::{Articulator, Tube, FIRST_PHARYNX_SECTION, MIN_AREA_CM2, NUM_PHARYNX_MOUTH_SECTIONS};
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;
use std::f64::consts::PI;

/// A tract's section from the glottis toward the lips: [length, area, its wall's length], cm and cm^2.
pub type Section = [f64; 3];

/// A measured case: a tract's sections from the glottis to the lips and its resonances as measured ([Hz, bandwidth Hz]).
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Case {
    pub name: String,
    pub sections: Vec<Section>,
    pub measured: Vec<[f64; 2]>,
}

/// A set of cases measured alike: what they are, where from, under what conditions, and the switches that lay those
/// conditions on the engine (a printed tract's hard walls: tissue=rigid).
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Set {
    pub about: String,
    pub source: String,
    pub condition: String,
    pub switches: Vec<String>,
    pub cases: Vec<Case>,
}

/// acoustics/printed-tracts.json: the sets by name.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Printed {
    pub about: String,
    pub sets: BTreeMap<String, Set>,
}

/// The crate's acoustics folder.
pub fn acoustics(file: &str) -> String {
    format!("{}/acoustics/{file}", crate::home())
}

pub fn printed() -> Result<Printed, String> {
    let path = acoustics("printed-tracts.json");
    serde_json::from_str(&std::fs::read_to_string(&path).map_err(|e| format!("{path}: {e}"))?).map_err(|e| format!("{path}: {e}"))
}

/// The engine's pharynx and mouth -- `n` sections of equal length -- from any sections: each new section's volume and
/// wall surface those of the old within its span, so that the tract's length, volume and wall's surface are kept.
pub fn resample(sections: &[Section], n: usize) -> Vec<Section> {
    let total: f64 = sections.iter().map(|s| s[0]).sum();
    let step = total / n as f64;
    let (mut out, mut i, mut used) = (Vec::with_capacity(n), 0, 0.0);
    for _ in 0..n {
        let (mut need, mut volume, mut surface) = (step, 0.0, 0.0);
        while need > 1e-12 * total && i < sections.len() {
            let s = sections[i];
            let take = (s[0] - used).min(need);
            volume += take * s[1];
            surface += take * s[2];
            need -= take;
            used += take;
            if s[0] - used <= 1e-12 * total {
                i += 1;
                used = 0.0;
            }
        }
        out.push([step, volume / step, surface / step]);
    }
    out
}

/// A printed tract on the engine's tube: its sections as the pharynx and the mouth, each one's wall against its
/// equal-area circle's as its shape; the velum shut and the piriform fossa all but closed (a printed tract has neither
/// a nose nor a fossa: its volume a thousandth of a cubic centimetre).
pub fn tube_of(sections: &[Section]) -> Tube {
    let s = resample(sections, NUM_PHARYNX_MOUTH_SECTIONS);
    let total: f64 = s.iter().map(|x| x[0]).sum();
    let mut tube = Tube::new();
    tube.init_static_sections(v24::tube::DEFAULT_SUBGLOTTAL_CAVITY_LENGTH_CM, v24::tube::DEFAULT_NASAL_CAVITY_LENGTH_CM, v24::tube::DEFAULT_PIRIFORM_FOSSA_LENGTH_CM, 1e-3);
    let lengths: Vec<f64> = s.iter().map(|x| x[0]).collect();
    let areas: Vec<f64> = s.iter().map(|x| x[1]).collect();
    tube.set_pharynx_mouth_sections(&lengths, &areas, &[Articulator::Other; NUM_PHARYNX_MOUTH_SECTIONS]);
    for (i, x) in s.iter().enumerate() {
        tube.section[FIRST_PHARYNX_SECTION + i].shape = (x[2] / (2.0 * (PI * x[1].max(MIN_AREA_CM2)).sqrt())).max(1.0);
    }
    tube.set_aux_params(0.0, total - 1.0, 0.0);
    tube
}

/// The engine's network on a tube under `switches` (PassiveModel::layout_switches and take_switches), the glottis shut,
/// the noise silent, stepped as its physics asks.
pub fn network_of(tube: &Tube, switches: &[String]) -> Network {
    let mut options = v24::tds::TdsModel::new().options;
    options.generate_noise_sources = false;
    // (a printed tract has no piriform fossa: 2.4's own fossa shut)
    options.piriform_fossa = false;
    PassiveModel::layout_switches(&mut options, switches);
    let mut tds = v24::tds::TdsModel::new();
    tds.options = options;
    tds.set_tube(tube, false);
    let mut k = v24::tds::TubeCoefficients::default();
    tds.tube_coefficients(&mut k);
    let mut model = PassiveModel::new(tube, options);
    model.take_switches(switches);
    let glottis = [0.3, 0.3];
    let steps = model.steps_needed(&k, &glottis);
    model.set_rate(v24::constants::AUDIO_SAMPLING_RATE_HZ as f64 * steps as f64);
    model.set_glottis_sections(&glottis, &[MIN_AREA_CM2; 2]);
    model.set_pressure_source(0.0, 0);
    model.network(&k)
}

/// A network's resonances from `from` to `to` Hz: its continuous transfer's peaks on a grid of `grid` Hz, each refined to
/// its pole as the step takes it -> (Hz, bandwidth Hz), in order, each once.
pub fn resonances(network: &Network, from: f64, to: f64, grid: f64) -> Vec<(f64, f64)> {
    let hz: Vec<f64> = (0..).map(|i| from + grid * i as f64).take_while(|&f| f <= to).collect();
    let size: Vec<f64> = hz.iter().map(|&f| network.response(Complex::tone(f), Stepping::Continuous).mouth.abs()).collect();
    let mut found: Vec<(f64, f64)> = Vec::new();
    for i in 1..hz.len().saturating_sub(1) {
        if !(size[i] > size[i - 1] && size[i] >= size[i + 1]) {
            continue;
        }
        if let Some(pole) = network.resonance(Complex::resonance(hz[i], 60.0), Stepping::Stepped) {
            let (f, b) = pole.frequency_and_bandwidth();
            if b > 0.0 && f > from * 0.9 && !found.iter().any(|&(g, _)| (g / f - 1.0).abs() < 0.01) {
                found.push((f, b));
            }
        }
    }
    found.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap());
    found
}

/// A measured resonance and the engine's pole matched to it.
#[derive(Clone, Copy, Debug, Serialize)]
pub struct Matched {
    pub measured: [f64; 2],
    pub pole: Option<[f64; 2]>,
}

impl Matched {
    /// Fant's measure of a bandwidth's error: 20 log10 of the engine's over the measured, dB.
    pub fn bandwidth_db(&self) -> Option<f64> {
        self.pole.map(|p| 20.0 * (p[1] / self.measured[1]).log10())
    }
    pub fn cents(&self) -> Option<f64> {
        self.pole.map(|p| 1200.0 * (p[0] / self.measured[0]).log2())
    }
}

/// A case's measured resonances matched, each to the engine's pole nearest it in pitch among those found on its
/// network, no pole twice and none further than a quarter of an octave.
pub fn matched_first(case: &Case, switches: &[String]) -> Vec<Matched> {
    let most = case.measured.iter().map(|m| m[0]).fold(0.0, f64::max);
    let found = resonances(&network_of(&tube_of(&case.sections), switches), 80.0, (most * 1.15).min(7000.0), 10.0);
    let mut taken = vec![false; found.len()];
    case.measured
        .iter()
        .map(|&m| {
            let near = found.iter().enumerate().filter(|(j, (f, _))| !taken[*j] && (f / m[0]).log2().abs() < 0.25).min_by(|a, b| (a.1 .0 / m[0]).log2().abs().partial_cmp(&(b.1 .0 / m[0]).log2().abs()).unwrap());
            match near {
                Some((j, &(f, b))) => {
                    taken[j] = true;
                    Matched { measured: m, pole: Some([f, b]) }
                }
                None => Matched { measured: m, pole: None },
            }
        })
        .collect()
}

/// The same resonances followed to a network laid under other switches: each pole found again by the secant method from
/// where it was (the measured resonance's where none was matched).
pub fn followed(case: &Case, switches: &[String], before: &[Matched]) -> Vec<Matched> {
    let network = network_of(&tube_of(&case.sections), switches);
    before
        .iter()
        .map(|m| {
            let from = m.pole.unwrap_or(m.measured);
            let pole = network.resonance(Complex::resonance(from[0], from[1]), Stepping::Stepped).map(|p| p.frequency_and_bandwidth()).filter(|&(f, b)| b > 0.0 && (f / from[0]).log2().abs() < 0.15).map(|(f, b)| [f, b]);
            Matched { measured: m.measured, pole }
        })
        .collect()
}

/// A set's agreement with its measurements, as the scoreboard shows it.
#[derive(Clone, Debug, Serialize)]
pub struct Score {
    /// Resonances measured, and how many the engine matched.
    pub measured: usize,
    pub matched: usize,
    /// Fant's measure: the bandwidths' error, dB, its mean and its root mean square; the engine's bandwidth over the
    /// measured, its median by kilohertz band (0-1, 1-2, 2-3, 3-4, 4 and over).
    pub mean_db: f64,
    pub rms_db: f64,
    pub ratio_by_band: [Option<f64>; 5],
    /// The frequencies' error, cents: its median and its mean size.
    pub median_cents: f64,
    pub mean_abs_cents: f64,
}

fn median(mut x: Vec<f64>) -> Option<f64> {
    if x.is_empty() {
        return None;
    }
    x.sort_by(|a, b| a.partial_cmp(b).unwrap());
    Some(x[x.len() / 2])
}

pub fn score(all: &[Vec<Matched>]) -> Score {
    let flat: Vec<&Matched> = all.iter().flatten().collect();
    let db: Vec<f64> = flat.iter().filter_map(|m| m.bandwidth_db()).collect();
    let cents: Vec<f64> = flat.iter().filter_map(|m| m.cents()).collect();
    let band = |k: usize| median(flat.iter().filter(|m| m.pole.is_some() && ((m.measured[0] / 1000.0) as usize).min(4) == k).map(|m| m.pole.unwrap()[1] / m.measured[1]).collect());
    let n = db.len().max(1) as f64;
    Score {
        measured: flat.len(),
        matched: db.len(),
        mean_db: db.iter().sum::<f64>() / n,
        rms_db: (db.iter().map(|x| x * x).sum::<f64>() / n).sqrt(),
        ratio_by_band: [band(0), band(1), band(2), band(3), band(4)],
        median_cents: median(cents.clone()).unwrap_or(f64::NAN),
        mean_abs_cents: cents.iter().map(|c| c.abs()).sum::<f64>() / cents.len().max(1) as f64,
    }
}

/// A free parameter's feasible range and its source (acoustics/tract.json `free.<name>`).
pub fn feasible(name: &str) -> Result<(f64, f64, String), String> {
    let path = acoustics("tract.json");
    let tract: serde_json::Value = serde_json::from_str(&std::fs::read_to_string(&path).map_err(|e| format!("{path}: {e}"))?).map_err(|e| format!("{path}: {e}"))?;
    let p = &tract["free"][name];
    let range = p["range"].as_array().ok_or_else(|| format!("{path}: free.{name}: its range"))?;
    let (lo, hi) = (range[0].as_f64().unwrap_or(f64::NAN), range[1].as_f64().unwrap_or(f64::NAN));
    if !(lo < hi) {
        return Err(format!("{path}: free.{name}: a range [low, high]"));
    }
    Ok((lo, hi, p["source"].as_str().unwrap_or("").to_string()))
}

/// The least of a function over [lo, hi] by golden-section search to `tol` (the function smooth and with one least in
/// the range, as an error over one loss factor is): -> (x, f(x), how many evaluations).
pub fn golden(mut f: impl FnMut(f64) -> f64, lo: f64, hi: f64, tol: f64) -> (f64, f64, usize) {
    let g = (5f64.sqrt() - 1.0) / 2.0;
    let (mut a, mut b) = (lo, hi);
    let (mut c, mut d) = (b - g * (b - a), a + g * (b - a));
    let (mut fc, mut fd) = (f(c), f(d));
    let mut n = 2;
    while b - a > tol {
        if fc < fd {
            b = d;
            d = c;
            fd = fc;
            c = b - g * (b - a);
            fc = f(c);
        } else {
            a = c;
            c = d;
            fc = fd;
            d = a + g * (b - a);
            fd = f(d);
        }
        n += 1;
    }
    // (the ends too: a least at a bound is a finding)
    let (fa, fb) = (f(lo), f(hi));
    n += 2;
    let (x, fx) = if fc < fd { (c, fc) } else { (d, fd) };
    if fa <= fx && fa <= fb {
        (lo, fa, n)
    } else if fb <= fx {
        (hi, fb, n)
    } else {
        (x, fx, n)
    }
}

/// Fant's measure over a set's resonances as one number to bring down: their bandwidths' errors' mean square, dB^2 --
/// a resonance the engine cannot match counted at 12 dB, so that losing it is never a gain.
pub fn error(all: &[Vec<Matched>]) -> f64 {
    let flat: Vec<&Matched> = all.iter().flatten().collect();
    flat.iter().map(|m| m.bandwidth_db().unwrap_or(12.0).powi(2)).sum::<f64>() / flat.len().max(1) as f64
}

/// The living tracts' measurements (voices/measured-tracts.json): Fant 1972's formulas and Fujimura & Lindqvist's
/// first-bandwidth curves, by sex.
pub fn measured_tracts() -> Result<serde_json::Value, String> {
    let path = format!("{}/voices/measured-tracts.json", crate::home());
    serde_json::from_str(&std::fs::read_to_string(&path).map_err(|e| format!("{path}: {e}"))?).map_err(|e| format!("{path}: {e}"))
}

/// Fant's three bandwidths from a vowel's first three resonances (his Eqs. 56-58, their constants the registry's), for
/// a `sex` ("male" or "female"): what a living tract of that sex measures with the glottis shut, within 1 to 2 dB.
pub fn fant(f: [f64; 3], sex: &str, measured: &serde_json::Value) -> [f64; 3] {
    let x = &measured["fant_1972"]["formulas"];
    let c = |g: &str, k: &str| x[g][k].as_f64().unwrap_or(f64::NAN);
    let r = c("b1", "reference");
    let walls = x["walls"][sex].as_f64().unwrap_or(1.0);
    let f4 = x["F4a"][sex].as_f64().unwrap_or(f64::NAN);
    [
        c("b1", "walls") * walls * (r / f[0]).powi(2) + c("b1", "surfaces") * (f[0] / r).sqrt() + c("b1", "radiation") * (f[0] / r).powi(2),
        c("b2", "constant") + c("b2", "opening") * (f[0] / r).powi(2) + c("b2", "closeness") / (f[2] - f[1]),
        if f[2] < f4 { c("b3", "opening") * (f[0] / r).powi(2) + c("b3", "second") * (f[1] / r).powi(2) + c("b3", "fourth") * f[2] / (f4 - f[2]) } else { f64::NAN },
    ]
}

/// Fujimura & Lindqvist's average first bandwidth at a first resonance `f1` (their curve, straight between its points):
/// None outside it.
pub fn first_bandwidth_curve(f1: f64, sex: &str, measured: &serde_json::Value) -> Option<f64> {
    let curve = &measured["fujimura_lindqvist_1971"]["first"][sex];
    let (hz, b): (Vec<f64>, Vec<f64>) = (curve["hz"].as_array()?.iter().filter_map(|v| v.as_f64()).collect(), curve["bandwidth"].as_array()?.iter().filter_map(|v| v.as_f64()).collect());
    let i = hz.windows(2).position(|w| w[0] <= f1 && f1 <= w[1])?;
    Some(b[i] + (b[i + 1] - b[i]) * (f1 - hz[i]) / (hz[i + 1] - hz[i]))
}

/// A speaker's vowel as a living tract: its shape on its own tract, its piriform fossa and its nose as it has them, the
/// glottis shut, its walls as `switches` ask (tissue=) -> the network.
pub fn living_network(speaker: &v24::speaker::Speaker, shape: &str, switches: &[String]) -> Result<Network, String> {
    let params = speaker.tract.shape(shape).ok_or_else(|| format!("no shape {shape}"))?;
    let mut t = speaker.tract.clone();
    t.calculate(&params);
    let mut tube = Tube::new();
    tube.set_from_tract(&t.tube());
    let mut options = v24::tds::TdsModel::new().options;
    options.generate_noise_sources = false;
    PassiveModel::layout_switches(&mut options, switches);
    let mut tds = v24::tds::TdsModel::new();
    tds.options = options;
    tds.set_tube(&tube, false);
    let mut k = v24::tds::TubeCoefficients::default();
    tds.tube_coefficients(&mut k);
    let mut model = PassiveModel::new(&tube, options);
    model.take_switches(switches);
    let mut glottis = speaker.glottis.clone();
    glottis.calc_geometry();
    let (lengths, _) = glottis.tube_data();
    let steps = model.steps_needed(&k, &lengths);
    model.set_rate(v24::constants::AUDIO_SAMPLING_RATE_HZ as f64 * steps as f64);
    model.set_glottis_sections(&lengths, &[MIN_AREA_CM2; 2]);
    model.set_pressure_source(0.0, 0);
    Ok(model.network(&k))
}

/// The living tracts' scoreboard: each speaker's vowels (`shapes`), its walls its own (voices/speakers.json `walls`,
/// tissue=), their first three resonances' bandwidths over Fant's formulas at those resonances -- each a median over the
/// vowels, by sex -- and the first's over Fujimura & Lindqvist's curve. -> [(sex, [B1, B2, B3 over Fant's], B1 over the
/// curve, how many vowels)].
pub fn living_score(speakers: &[(String, String, String)], shapes: &[&str], switches: &[String]) -> Result<Vec<(String, [Option<f64>; 3], Option<f64>, usize)>, String> {
    let measured = measured_tracts()?;
    let mut by_sex: BTreeMap<String, (Vec<[f64; 3]>, Vec<f64>)> = BTreeMap::new();
    for (file, sex, walls) in speakers {
        let speaker = v24::speaker::Speaker::read(file)?;
        let with: Vec<String> = switches.iter().cloned().chain(std::iter::once(format!("tissue={walls}"))).collect();
        for shape in shapes {
            let network = living_network(&speaker, shape, &with)?;
            let found = resonances(&network, 150.0, 4500.0, 10.0);
            if found.len() < 3 {
                continue;
            }
            let f = [found[0].0, found[1].0, found[2].0];
            let want = fant(f, sex, &measured);
            let entry = by_sex.entry(sex.clone()).or_default();
            entry.0.push([found[0].1 / want[0], found[1].1 / want[1], found[2].1 / want[2]]);
            if let Some(b) = first_bandwidth_curve(f[0], sex, &measured) {
                entry.1.push(found[0].1 / b);
            }
        }
    }
    Ok(by_sex
        .into_iter()
        .map(|(sex, (ratios, curve))| {
            let n = ratios.len();
            let m = |k: usize| median(ratios.iter().map(|r| r[k]).filter(|x| x.is_finite()).collect());
            (sex, [m(0), m(1), m(2)], median(curve), n)
        })
        .collect())
}

/// A WAV file's samples (32-bit float or 16-bit PCM, its first channel) and its rate.
pub fn read_wav(path: &str) -> Result<(Vec<f64>, f64), String> {
    let b = std::fs::read(path).map_err(|e| format!("{path}: {e}"))?;
    if b.len() < 12 || &b[0..4] != b"RIFF" || &b[8..12] != b"WAVE" {
        return Err(format!("{path}: not a RIFF WAVE file"));
    }
    let (u16_at, u32_at) = (|i: usize| u16::from_le_bytes([b[i], b[i + 1]]), |i: usize| u32::from_le_bytes([b[i], b[i + 1], b[i + 2], b[i + 3]]));
    let (mut i, mut format, mut channels, mut rate, mut bits) = (12, 0, 1, 0.0, 0);
    while i + 8 <= b.len() {
        let (id, n) = (&b[i..i + 4], u32_at(i + 4) as usize);
        let body = i + 8;
        if id == b"fmt " {
            (format, channels, rate, bits) = (u16_at(body), u16_at(body + 2) as usize, u32_at(body + 4) as f64, u16_at(body + 14));
        } else if id == b"data" {
            let end = (body + n).min(b.len());
            let frame = channels * bits as usize / 8;
            let samples = match (format, bits) {
                (3, 32) => (body..end).step_by(frame).filter(|&j| j + 4 <= end).map(|j| f32::from_le_bytes([b[j], b[j + 1], b[j + 2], b[j + 3]]) as f64).collect(),
                (1, 16) => (body..end).step_by(frame).filter(|&j| j + 2 <= end).map(|j| i16::from_le_bytes([b[j], b[j + 1]]) as f64 / 32768.0).collect(),
                _ => return Err(format!("{path}: a WAV of format {format}, {bits} bits")),
            };
            return Ok((samples, rate));
        }
        i = body + n + (n & 1);
    }
    Err(format!("{path}: no data"))
}

/// A radix-2 FFT in place (its length a power of two).
fn fft(re: &mut [f64], im: &mut [f64]) {
    let n = re.len();
    let mut j = 0;
    for i in 1..n {
        let mut bit = n >> 1;
        while j & bit != 0 {
            j ^= bit;
            bit >>= 1;
        }
        j ^= bit;
        if i < j {
            re.swap(i, j);
            im.swap(i, j);
        }
    }
    let mut len = 2;
    while len <= n {
        let ang = -2.0 * PI / len as f64;
        let (wr, wi) = (ang.cos(), ang.sin());
        for start in (0..n).step_by(len) {
            let (mut cr, mut ci) = (1.0, 0.0);
            for k in 0..len / 2 {
                let (a, b) = (start + k, start + k + len / 2);
                let (xr, xi) = (re[b] * cr - im[b] * ci, re[b] * ci + im[b] * cr);
                re[b] = re[a] - xr;
                im[b] = im[a] - xi;
                re[a] += xr;
                im[a] += xi;
                let t = cr * wr - ci * wi;
                ci = cr * wi + ci * wr;
                cr = t;
            }
        }
        len <<= 1;
    }
}

/// A sung stem's long-term spectrum in third-octave bands, each band against the stem's overall level (dB): Welch's,
/// 4096 samples Hann, half overlapped, over the frames within 30 dB of the loudest, each band its bins' power summed --
/// the bands those `centres` (Hz).
pub fn third_octaves(samples: &[f64], rate: f64, centres: &[f64]) -> Vec<f64> {
    const N: usize = 4096;
    let hann: Vec<f64> = (0..N).map(|i| 0.5 - 0.5 * (2.0 * PI * i as f64 / N as f64).cos()).collect();
    let frames: Vec<(usize, f64)> = (0..).map(|k| k * N / 2).take_while(|at| at + N <= samples.len()).map(|at| (at, samples[at..at + N].iter().map(|x| x * x).sum())).collect();
    let loudest = frames.iter().map(|f| f.1).fold(0.0, f64::max);
    let mut power = vec![0.0; N / 2];
    for &(at, e) in &frames {
        if e < loudest * 1e-3 {
            continue;
        }
        let (mut re, mut im): (Vec<f64>, Vec<f64>) = ((0..N).map(|i| samples[at + i] * hann[i]).collect(), vec![0.0; N]);
        fft(&mut re, &mut im);
        for k in 0..N / 2 {
            power[k] += re[k] * re[k] + im[k] * im[k];
        }
    }
    let bands: Vec<f64> = centres
        .iter()
        .map(|&fc| {
            let (lo, hi) = (fc * 2f64.powf(-1.0 / 6.0) * N as f64 / rate, fc * 2f64.powf(1.0 / 6.0) * N as f64 / rate);
            10.0 * (1e-30 + (lo.ceil() as usize..(hi.ceil() as usize).min(N / 2)).map(|k| power[k]).sum::<f64>()).log10()
        })
        .collect();
    relative(&bands)
}

/// Levels (dB) each against their sum's.
pub fn relative(levels: &[f64]) -> Vec<f64> {
    let total = 10.0 * levels.iter().map(|l| 10f64.powf(l / 10.0)).sum::<f64>().log10();
    levels.iter().map(|l| l - total).collect()
}

/// Monson, Lotto & Story 2012's singers' third-octave levels (voices/measured-singing.json `monson2012`): the bands'
/// centres (Hz) and the women's or the men's singing levels, each against its own overall level.
pub fn monson(sex: &str) -> Result<(Vec<f64>, Vec<f64>), String> {
    let path = format!("{}/voices/measured-singing.json", crate::home());
    let v: serde_json::Value = serde_json::from_str(&std::fs::read_to_string(&path).map_err(|e| format!("{path}: {e}"))?).map_err(|e| format!("{path}: {e}"))?;
    let m = &v["monson2012"];
    let columns: Vec<&str> = m["columns"].as_array().ok_or("monson2012: its columns")?.iter().filter_map(|c| c.as_str()).collect();
    let k = columns.iter().position(|c| *c == format!("{sex}_singing")).ok_or_else(|| format!("monson2012: no {sex}_singing"))?;
    let rows = m["rows"].as_array().ok_or("monson2012: its rows")?;
    let centres = rows.iter().map(|r| r[0].as_f64().unwrap_or(0.0) * 1000.0).collect();
    let levels: Vec<f64> = rows.iter().map(|r| r[k].as_f64().unwrap_or(f64::NAN)).collect();
    Ok((centres, relative(&levels)))
}

/// The piecewise-linear area function of a printed tube (VocalTractLab's export: lines of position, area, wall's length
/// and articulator, cm) as sections: each span between two points its length, the mean of its ends' areas (its volume
/// kept) and walls; a step (two points at one position) none. The export's first block alone, the piecewise-linear
/// shape that was printed: the stepwise one after it is the same tract in VocalTractLab's forty sections.
pub fn sections_of_area_function(text: &str) -> Vec<Section> {
    let mut headers = 0;
    let points: Vec<[f64; 3]> = text
        .lines()
        .take_while(|l| {
            if l.starts_with("===") {
                headers += 1;
            }
            headers < 2
        })
        .filter_map(|l| {
            let w: Vec<f64> = l.split_whitespace().take(3).filter_map(|x| x.parse().ok()).collect();
            (w.len() == 3).then(|| [w[0], w[1], w[2]])
        })
        .collect();
    points.windows(2).filter(|p| p[1][0] - p[0][0] > 1e-9).map(|p| [p[1][0] - p[0][0], 0.5 * (p[0][1] + p[1][1]), 0.5 * (p[0][2] + p[1][2])]).collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Resampled to the engine's sections, a tract keeps its length, volume and wall's surface, and a tube already of
    /// equal sections is itself.
    #[test]
    fn resampling_keeps_the_tract() {
        let s: Vec<Section> = (0..91).map(|i| [0.2 + 0.001 * (i % 7) as f64, 0.5 + (i as f64 * 0.37).sin().abs() * 3.0, 3.0 + 0.01 * i as f64]).collect();
        let r = resample(&s, 50);
        let sum = |x: &[Section], f: fn(&Section) -> f64| x.iter().map(f).sum::<f64>();
        assert!((sum(&r, |x| x[0]) - sum(&s, |x| x[0])).abs() < 1e-9);
        assert!((sum(&r, |x| x[0] * x[1]) - sum(&s, |x| x[0] * x[1])).abs() < 1e-9);
        assert!((sum(&r, |x| x[0] * x[2]) - sum(&s, |x| x[0] * x[2])).abs() < 1e-9);
        let even: Vec<Section> = (0..50).map(|i| [0.33, 1.0 + i as f64 * 0.1, 4.0]).collect();
        for (a, b) in resample(&even, 50).iter().zip(&even) {
            assert!((a[1] - b[1]).abs() < 1e-9 && (a[0] - b[0]).abs() < 1e-12);
        }
    }

    /// The golden section finds a parabola's least, and a least at a bound is said to be there.
    #[test]
    fn the_golden_section_finds_the_least() {
        let (x, _, _) = golden(|x| (x - 1.37).powi(2), 1.0, 2.0, 1e-6);
        assert!((x - 1.37).abs() < 1e-5);
        let (x, _, _) = golden(|x| x, 1.0, 2.0, 1e-6);
        assert_eq!(x, 1.0);
    }

    /// A uniform tube closed at one end and radiating at the other resonates near its quarter wavelengths: 17 cm of 4
    /// cm^2, hard-walled, first at c / 4 L (an end correction lowering it a little) and the next at three times it.
    #[test]
    fn a_uniform_tube_resonates_at_its_quarter_wavelengths() {
        let sections: Vec<Section> = (0..50).map(|_| [0.34, 4.0, 2.0 * (PI * 4.0).sqrt()]).collect();
        let found = resonances(&network_of(&tube_of(&sections), &["tissue=rigid".to_string()]), 80.0, 2000.0, 10.0);
        let quarter = v24::constants::SOUND_VELOCITY_CGS / (4.0 * 17.0);
        assert!(found.len() >= 2, "{found:?}");
        assert!(found[0].0 < quarter && found[0].0 > 0.85 * quarter, "first {:.1} Hz against c/4L {quarter:.1}", found[0].0);
        assert!((found[1].0 / found[0].0 - 3.0).abs() < 0.12, "{found:?}");
    }
}
