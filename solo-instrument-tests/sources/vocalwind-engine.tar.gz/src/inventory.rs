// The phones VocalWind's segment rules make, each defined once (languages/phones.json): its name in the segment files,
// the IPA sounds it is, its kind, and what the rules make of it. The rules (src/segments.rs, 2.3's; src/v24/segments.rs,
// 2.4's) ask it for a phone's class, shapes and numbers instead of holding lists of their own, and the shared IPA table
// (src/phones.rs) is its sounds: a phone learned from one language is any language's that has its sound (the owner, 15
// November 2026). A phone may be defined `like` another, taking every field it does not give from it. Read once, checked
// as it is read; a file of the same name in $MUSEBOTS_VOCALWIND_LANGUAGES is read in place of the one built in.
use serde::Deserialize;
use std::collections::BTreeMap;
use std::sync::OnceLock;

#[derive(Clone, Copy, Debug, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "kebab-case")]
pub enum Kind {
    Vowel,
    Diphthong,
    /// An approximant made as a vowel is: a vowel gesture to its own shape.
    Glide,
    Consonant,
}

#[derive(Clone, Copy, Debug, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "kebab-case")]
pub enum Manner {
    Plosive,
    Fricative,
    Affricate,
    Nasal,
    Lateral,
    GlottalStop,
    GlottalFricative,
}

/// The articulator a consonant's closing or narrowing gesture is made with: its tier in the gestural score.
#[derive(Clone, Copy, Debug, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "kebab-case")]
pub enum Articulator {
    Lips,
    TongueTip,
    TongueBody,
    Glottis,
}

#[derive(Clone, Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Phone {
    /// The IPA sounds it is (marks languages/ipa.json drops left out).
    pub ipa: Vec<String>,
    pub kind: Kind,
    /// A vowel's shape (the speaker's, by name).
    #[serde(default)]
    pub shape: Option<String>,
    /// A diphthong's two shapes.
    #[serde(default)]
    pub shapes: Option<[String; 2]>,
    #[serde(default)]
    pub manner: Option<Manner>,
    #[serde(default)]
    pub articulator: Option<Articulator>,
    /// A consonant's voicing (vowels and diphthongs are voiced).
    #[serde(default)]
    pub voiced: Option<bool>,
    /// Made postalveolar in a cluster with a phone that makes it so.
    #[serde(default)]
    pub alveolar: bool,
    #[serde(default)]
    pub makes_postalveolar: bool,
    /// A plosive's or nasal's closing shape, and its postalveolar one.
    #[serde(default)]
    pub closure: Option<String>,
    #[serde(default)]
    pub closure_postalveolar: Option<String>,
    /// A fricative's or lateral's oral shape, and its postalveolar one.
    #[serde(default)]
    pub oral: Option<String>,
    #[serde(default)]
    pub oral_postalveolar: Option<String>,
    /// Its glottal shape.
    #[serde(default)]
    pub glottal: Option<String>,
    /// An affricate's plosive and fricative, and the plosive's share of its length.
    #[serde(default)]
    pub parts: Option<[String; 2]>,
    #[serde(default)]
    pub plosive_share: Option<f64>,
    /// Phones a plosive is released into at its segment's end.
    #[serde(default)]
    pub released_into: Vec<String>,
    /// A plosive's glottal gesture shortened before a lateral.
    #[serde(default)]
    pub lateral_release: bool,
    #[serde(default)]
    pub rules: PhoneRules,
    /// Where it was learned (a key of the inventory's `sources`).
    pub source: String,
}

/// A rule set's own numbers for a phone.
#[derive(Clone, Debug, Default, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct PhoneRules {
    #[serde(rename = "2.3", default)]
    pub v23: Option<Phone23>,
    #[serde(rename = "2.4", default)]
    pub v24: Option<Phone24>,
}

#[derive(Clone, Debug, Default, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Phone23 {
    #[serde(default)]
    pub vot_s: Option<f64>,
    #[serde(default)]
    pub vot_before_fricative_s: Option<f64>,
    #[serde(default)]
    pub lungs_fall_before_end_s: Option<f64>,
}

#[derive(Clone, Debug, Default, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Phone24 {
    /// The glottal shape where 2.4's is not the phone's.
    #[serde(default)]
    pub glottal: Option<String>,
    #[serde(default)]
    pub vot_s: Option<f64>,
    /// vot = a x^2 + b x, x the segment's length up to `vot_limit_s`.
    #[serde(default)]
    pub vot_regression: Option<[f64; 2]>,
    #[serde(default)]
    pub vot_limit_s: Option<f64>,
    #[serde(default)]
    pub onset_tau_s: Option<f64>,
    #[serde(default)]
    pub offset_tau_s: Option<f64>,
    #[serde(default)]
    pub short_release_before: Vec<String>,
    #[serde(default)]
    pub velic_target: Option<f64>,
    #[serde(default)]
    pub velic_extension_s: Option<f64>,
}

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Inventory {
    #[allow(dead_code)]
    about: String,
    pub sources: BTreeMap<String, String>,
    pub phones: BTreeMap<String, Phone>,
    /// Each IPA sound and the phone it is.
    #[serde(skip)]
    by_ipa: BTreeMap<String, String>,
}

impl Phone {
    /// The shape a vowel's or a glide's one gesture approaches.
    pub fn vowel_shape(&self) -> Option<&str> {
        match self.kind {
            Kind::Vowel | Kind::Glide => self.shape.as_deref(),
            _ => None,
        }
    }
}

/// A configuration file of languages/: the one in $MUSEBOTS_VOCALWIND_LANGUAGES where there is one, else the one built
/// in.
pub(crate) fn language_file(name: &str, built_in: &'static str) -> String {
    match std::env::var_os("MUSEBOTS_VOCALWIND_LANGUAGES") {
        Some(dir) => {
            let path = std::path::Path::new(&dir).join(name);
            if path.exists() {
                return std::fs::read_to_string(&path).unwrap_or_else(|e| panic!("{}: {e}", path.display()));
            }
            built_in.to_string()
        }
        None => built_in.to_string(),
    }
}

impl Inventory {
    /// The inventory from its JSON, each phone defined `like` another given that one's fields (but its IPA, its own),
    /// then checked.
    pub fn parse(text: &str) -> Result<Inventory, String> {
        let mut doc: serde_json::Value = serde_json::from_str(text).map_err(|e| format!("phones: {e}"))?;
        let phones = doc.get_mut("phones").and_then(|p| p.as_object_mut()).ok_or("phones: no `phones`")?;
        let raw = phones.clone();
        for (name, p) in phones.iter_mut() {
            let mut seen = vec![name.clone()];
            while let Some(base) = p.as_object_mut().and_then(|o| o.remove("like")) {
                let base = base.as_str().ok_or_else(|| format!("{name}: `like` names a phone"))?.to_string();
                if seen.contains(&base) {
                    return Err(format!("{name}: `like` goes round ({})", seen.join(", ")));
                }
                let from = raw.get(&base).and_then(|b| b.as_object()).ok_or_else(|| format!("{name}: like {base}: no such phone"))?;
                let o = p.as_object_mut().unwrap();
                for (k, v) in from {
                    if k != "ipa" && !o.contains_key(k) {
                        o.insert(k.clone(), v.clone());
                    }
                }
                seen.push(base);
            }
        }
        let mut inv: Inventory = serde_json::from_value(doc).map_err(|e| format!("phones: {e}"))?;
        inv.check()?;
        for (name, p) in &inv.phones {
            for s in &p.ipa {
                if let Some(other) = inv.by_ipa.insert(s.clone(), name.clone()) {
                    return Err(format!("phones: [{s}] is both {other} and {name}"));
                }
            }
        }
        Ok(inv)
    }

    /// Every phone has what its kind and manner need, and names only phones and sources there are.
    fn check(&self) -> Result<(), String> {
        let known = |n: &String| self.phones.contains_key(n);
        for (name, p) in &self.phones {
            let fail = |what: &str| Err(format!("phone {name}: {what}"));
            if !self.sources.contains_key(&p.source) {
                return fail(&format!("source {} is not among the sources", p.source));
            }
            match p.kind {
                Kind::Vowel | Kind::Glide if p.shape.is_none() => return fail("a vowel or glide with no shape"),
                Kind::Diphthong if p.shapes.is_none() => return fail("a diphthong with no shapes"),
                Kind::Consonant => {
                    let (Some(manner), Some(_), Some(_)) = (p.manner, p.articulator, p.voiced) else {
                        return fail("a consonant needs its manner, articulator and voicing");
                    };
                    let need = |field: &Option<String>, what: &str| if field.is_none() { fail(what) } else { Ok(()) };
                    match manner {
                        Manner::Plosive => {
                            need(&p.closure, "a plosive with no closure")?;
                            need(&p.glottal, "a plosive with no glottal shape")?;
                        }
                        Manner::Nasal => need(&p.closure, "a nasal with no closure")?,
                        Manner::Fricative => {
                            need(&p.oral, "a fricative with no oral shape")?;
                            need(&p.glottal, "a fricative with no glottal shape")?;
                        }
                        Manner::Lateral => need(&p.oral, "a lateral with no oral shape")?,
                        Manner::GlottalStop | Manner::GlottalFricative => need(&p.glottal, "a glottal consonant with no glottal shape")?,
                        Manner::Affricate => {
                            let Some(parts) = &p.parts else { return fail("an affricate with no parts") };
                            if !parts.iter().all(known) {
                                return fail("an affricate's parts are not phones");
                            }
                            if !p.plosive_share.is_some_and(|r| (0.0..=1.0).contains(&r)) {
                                return fail("an affricate's plosive share is not between 0 and 1");
                            }
                        }
                    }
                }
                _ => {}
            }
            let v24 = p.rules.v24.as_ref();
            for n in p.released_into.iter().chain(v24.map(|r| &r.short_release_before).into_iter().flatten()) {
                if !known(n) {
                    return fail(&format!("names {n}, not a phone"));
                }
            }
            if p.manner == Some(Manner::Plosive) {
                let Some(r) = v24 else { return fail("a plosive with no 2.4 numbers") };
                if r.vot_s.is_some() == r.vot_regression.is_some() || (r.vot_regression.is_some() && r.vot_limit_s.is_none()) {
                    return fail("2.4: a voice onset time or its regression (and its limit), one of them");
                }
                if r.onset_tau_s.is_none() || r.offset_tau_s.is_none() {
                    return fail("2.4: a plosive's time constants");
                }
                if !p.rules.v23.as_ref().is_some_and(|r| r.vot_s.is_some()) {
                    return fail("2.3: a plosive's voice onset time");
                }
            }
            if p.manner == Some(Manner::Nasal) {
                let Some(r) = v24 else { return fail("a nasal with no 2.4 numbers") };
                if r.velic_target.is_none() || r.velic_extension_s.is_none() || r.onset_tau_s.is_none() || r.offset_tau_s.is_none() {
                    return fail("2.4: a nasal's velic target, extension and time constants");
                }
            }
        }
        Ok(())
    }

    /// The IPA sounds and the phone each is (the table every language looks a sound up in after its own).
    pub fn ipa(&self) -> &BTreeMap<String, String> {
        &self.by_ipa
    }
}

pub fn inventory() -> &'static Inventory {
    static INVENTORY: OnceLock<Inventory> = OnceLock::new();
    INVENTORY.get_or_init(|| Inventory::parse(&language_file("phones.json", include_str!("../languages/phones.json"))).unwrap_or_else(|e| panic!("languages/phones.json: {e}")))
}

pub fn phone(name: &str) -> Option<&'static Phone> {
    inventory().phones.get(name)
}

pub fn manner(name: &str) -> Option<Manner> {
    phone(name).and_then(|p| p.manner)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_built_in_inventory_reads() {
        let inv = inventory();
        assert!(inv.phones.len() >= 76);
        assert_eq!(phone("tS").and_then(|p| p.parts.clone()), Some(["t".to_string(), "S".to_string()]));
        assert_eq!(inv.ipa().get("ʃ").map(String::as_str), Some("S"));
    }

    #[test]
    fn a_phone_like_another_takes_its_fields() {
        let text = r#"{"about": "", "sources": {"x": ""}, "phones": {
            "p": {"ipa": ["p"], "kind": "consonant", "manner": "plosive", "articulator": "lips", "voiced": false,
                  "closure": "ll-labial-closure", "glottal": "voiceless-plosive", "source": "x",
                  "rules": {"2.3": {"vot_s": 0.047}, "2.4": {"vot_s": 0.0, "onset_tau_s": 0.008, "offset_tau_s": 0.014}}},
            "p*": {"like": "p", "ipa": ["p͈"], "glottal": "tense-plosive"}}}"#;
        let inv = Inventory::parse(text).unwrap();
        let tense = &inv.phones["p*"];
        assert_eq!(tense.closure.as_deref(), Some("ll-labial-closure"));
        assert_eq!(tense.glottal.as_deref(), Some("tense-plosive"));
        assert_eq!(tense.ipa, vec!["p͈".to_string()]);
        assert!(Inventory::parse(&text.replace("\"like\": \"p\"", "\"like\": \"q\"")).is_err());
    }

    #[test]
    fn a_phone_missing_what_its_manner_needs_is_refused() {
        let text = r#"{"about": "", "sources": {"x": ""}, "phones": {
            "s": {"ipa": ["s"], "kind": "consonant", "manner": "fricative", "articulator": "tongue-tip", "voiced": false, "source": "x"}}}"#;
        assert!(Inventory::parse(text).unwrap_err().contains("no oral shape"));
    }
}
