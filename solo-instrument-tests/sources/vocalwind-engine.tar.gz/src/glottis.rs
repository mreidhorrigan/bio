// The geometric glottis (GeometricGlottis.cpp): a kinematic model of the vocal folds after Titze's four-parameter model,
// extended by Birkholz -- its folds' lower and upper edges swinging at F0 with a phase lag between them, their
// displacement integrated along the folds' length into the areas of the glottis's two tube sections. F0 drives its phase
// directly, so a note's pitch is the pitch it is given, at any frequency (with Klatt & Klatt's flutter, as set). Its
// parameters read from a speaker file (speaker.rs), each clamped to its range before it is used, as the C++ clamps it.
use crate::constants::{PI, SAMPLING_RATE};
use crate::iir::IirFilter;

pub const FREQUENCY: usize = 0;
pub const PRESSURE: usize = 1;
pub const LOWER_END_X: usize = 2;
pub const UPPER_END_X: usize = 3;
pub const CHINK_AREA: usize = 4;
pub const PHASE_LAG: usize = 5;
pub const RELATIVE_AMPLITUDE: usize = 6;
pub const DOUBLE_PULSING: usize = 7;
pub const PULSE_SKEWNESS: usize = 8;
pub const FLUTTER: usize = 9;
pub const ASPIRATION_STRENGTH: usize = 10;
pub const NUM_CONTROL_PARAMS: usize = 11;

pub const REST_THICKNESS: usize = 0;
pub const REST_LENGTH: usize = 1;
pub const REST_F0: usize = 2;
pub const CHINK_LENGTH: usize = 3;
pub const NUM_STATIC_PARAMS: usize = 4;

/// A parameter's name, range and neutral value, and its value now.
#[derive(Clone, Debug)]
pub struct Parameter {
    pub name: String,
    pub min: f64,
    pub max: f64,
    pub neutral: f64,
    pub x: f64,
}

fn param(name: &str, min: f64, max: f64, neutral: f64) -> Parameter {
    Parameter { name: name.into(), min, max, neutral, x: neutral }
}

/// What the folds' motion gives at an instant: the GeometricGlottis's derived parameters.
#[derive(Clone, Copy, Debug, Default)]
pub struct Derived {
    pub length: f64,
    pub thickness: f64,
    pub amplitude: f64,
    pub lower_cord_x: f64,
    pub upper_cord_x: f64,
    pub lower_area: f64,
    pub upper_area: f64,
    pub chink_width: f64,
}

#[derive(Clone)]
pub struct GeometricGlottis {
    pub control: Vec<Parameter>,
    pub statics: Vec<Parameter>,
    pub derived: Derived,
    /// Its named shapes ("modal", "breathy", ...): control values in the order of `control`.
    pub shapes: Vec<(String, Vec<f64>)>,
    /// VocalTractLab's bug in its area mended: its 32 intervals each a 32nd of the folds' length, not a 31st (their area
    /// 3.2% large). Off: VocalTractLab's own, to the bit.
    pub mended: bool,
    phase: f64,
    time_s: f64,
    supraglottal_pressure_dpa: f64,
    supraglottal_pressure_filter: IirFilter,
}

impl Default for GeometricGlottis {
    fn default() -> Self {
        GeometricGlottis::new()
    }
}

impl GeometricGlottis {
    pub fn new() -> GeometricGlottis {
        let control = vec![
            param("F0", 40.0, 600.0, 120.0),
            param("PR", 0.0, 20000.0, 8000.0),
            param("XB", -0.05, 0.3, 0.01),
            param("XT", -0.05, 0.3, 0.02),
            param("CA", -0.25, 0.25, 0.05),
            param("PL", 0.0, 3.1415, 1.22),
            param("RA", -1.0, 1.0, 1.0),
            param("DP", 0.0, 1.0, 0.05),
            param("PS", -0.5, 0.5, 0.0),
            param("FL", 0.0, 100.0, 25.0),
            param("AS", -40.0, 0.0, -10.0),
        ];
        let statics = vec![param("RT", 0.3, 1.0, 0.45), param("RL", 0.5, 2.0, 1.6), param("RF0", 50.0, 400.0, 120.0), param("CL", 0.1, 0.5, 0.4)];
        let shapes = vec![("default".to_string(), control.iter().map(|p| p.neutral).collect())];
        let mut g = GeometricGlottis {
            control,
            statics,
            derived: Derived::default(),
            shapes,
            phase: 0.0,
            time_s: 0.0,
            supraglottal_pressure_dpa: 0.0,
            supraglottal_pressure_filter: IirFilter::default(),
            mended: false,
        };
        g.reset_motion();
        g.calc_geometry();
        g
    }

    pub fn shape(&self, name: &str) -> Option<&[f64]> {
        self.shapes.iter().find(|(n, _)| n == name).map(|(_, v)| v.as_slice())
    }

    pub fn reset_motion(&mut self) {
        self.supraglottal_pressure_filter.create_chebyshev(25.0 / SAMPLING_RATE as f64, false, 4);
        self.supraglottal_pressure_filter.reset_buffers(0.0);
        self.time_s = 0.0;
        self.phase = 0.0;
        self.supraglottal_pressure_dpa = 0.0;
    }

    fn restrict(p: &mut [Parameter]) {
        for q in p.iter_mut() {
            if q.x < q.min {
                q.x = q.min;
            }
            if q.x > q.max {
                q.x = q.max;
            }
        }
    }

    pub fn calc_geometry(&mut self) {
        Self::restrict(&mut self.control);
        Self::restrict(&mut self.statics);
        let c = |i: usize| self.control[i].x;
        let s = |i: usize| self.statics[i].x;
        let length = s(REST_LENGTH) * (c(FREQUENCY) / s(REST_F0)).sqrt();
        let thickness = (s(REST_THICKNESS) * s(REST_LENGTH)) / length;
        let skewness = c(PULSE_SKEWNESS);
        // (The two edges' phases modulo two periods.)
        let mut orig = [self.phase, self.phase + 4.0 * PI - c(PHASE_LAG)];
        for p in orig.iter_mut() {
            let n = (*p / (4.0 * PI)) as i32;
            *p -= n as f64 * 4.0 * PI;
        }
        const EPSILON: f64 = 0.000000001;
        let alpha = [
            0.0,
            (1.0 + skewness) * PI / 2.0,
            PI + (1.0 - skewness) * PI / 2.0,
            2.0 * PI + (1.0 + skewness) * PI / 2.0,
            3.0 * PI + (1.0 - skewness) * PI / 2.0,
            4.0 * PI,
        ];
        let beta = [0.0, 0.5 * PI, 1.5 * PI, 2.5 * PI, 3.5 * PI, 4.0 * PI];
        let mut warped = orig;
        for k in 0..2 {
            for i in 0..5 {
                if orig[k] >= alpha[i] && orig[k] <= alpha[i + 1] {
                    let mut denominator = alpha[i + 1] - alpha[i];
                    if denominator.abs() < EPSILON {
                        denominator = EPSILON;
                    }
                    warped[k] = beta[i] + (beta[i + 1] - beta[i]) * (orig[k] - alpha[i]) / denominator;
                    break;
                }
            }
        }
        let mut trans_pressure = c(PRESSURE) - self.supraglottal_pressure_dpa;
        if trans_pressure < 0.0 {
            trans_pressure = 0.0;
        }
        let mut amplitude = 0.0011 * trans_pressure.sqrt();
        amplitude *= s(REST_LENGTH) / length;
        let mut rel_amp = c(RELATIVE_AMPLITUDE);
        if rel_amp < 0.0 {
            rel_amp = 0.0;
        }
        amplitude *= rel_amp;
        let double_pulsing = c(DOUBLE_PULSING);
        let mut displacement = [0.0; 2];
        for i in 0..2 {
            displacement[i] = if warped[i] <= 1.5 * PI || warped[i] >= 3.5 * PI {
                amplitude * warped[i].sin()
            } else {
                -amplitude + amplitude * (warped[i].sin() + 1.0) * (1.0 - 0.5 * double_pulsing)
            };
        }
        let mut chink_area = c(CHINK_AREA);
        if chink_area < 0.0 {
            chink_area = 0.0;
        }
        const NUM_SAMPLES: i32 = 32;
        let delta_length = length / if self.mended { NUM_SAMPLES } else { NUM_SAMPLES - 1 } as f64;
        let end_x = [c(LOWER_END_X), c(UPPER_END_X)];
        let mut area = [0.0; 2];
        for i in 0..2 {
            let mut prev_x = 0.0;
            area[i] = chink_area;
            for k in 1..=NUM_SAMPLES {
                let t = k as f64 / NUM_SAMPLES as f64;
                let mut x = end_x[i] * t + displacement[i] * (t * PI).sin();
                if x < 0.0 {
                    x = 0.0;
                }
                area[i] += delta_length * (prev_x + x);
                prev_x = x;
            }
        }
        let mut chink_length = s(CHINK_LENGTH);
        if chink_length < 0.000001 {
            chink_length = 0.000001;
        }
        self.derived = Derived {
            length,
            thickness,
            amplitude,
            lower_cord_x: displacement[0],
            upper_cord_x: displacement[1],
            lower_area: area[0],
            upper_area: area[1],
            chink_width: chink_area / chink_length,
        };
    }

    /// A step of `dt` s, given the pressures (dPa) below, in the two sections of and above the glottis.
    pub fn inc_time(&mut self, dt: f64, pressure_dpa: &[f64; 4]) {
        let mut supraglottal = self.supraglottal_pressure_filter.output_sample(pressure_dpa[3]);
        let mut f0 = self.control[FREQUENCY].x;
        if supraglottal > 40000.0 {
            supraglottal = 40000.0;
        }
        if supraglottal < -40000.0 {
            supraglottal = -40000.0;
        }
        self.supraglottal_pressure_dpa = supraglottal;
        let flutter_percent = self.control[FLUTTER].x;
        let t = self.time_s;
        f0 += (flutter_percent / 50.0) * (f0 / 100.0) * ((2.0 * PI * 12.7 * t).sin() + (2.0 * PI * 7.1 * t).sin() + (2.0 * PI * 4.7 * t).sin());
        self.phase += f0 * dt * 2.0 * PI;
        self.time_s += dt;
    }

    /// The glottis's two tube sections: their lengths and areas.
    pub fn tube_data(&self) -> ([f64; 2], [f64; 2]) {
        let h = self.derived.thickness * 0.5;
        ([h, h], [self.derived.lower_area, self.derived.upper_area])
    }

    pub fn aspiration_strength_db(&self) -> f64 {
        self.control[ASPIRATION_STRENGTH].x
    }
}
