// Text into timed phones by eSpeak NG (GPL-3.0-or-later; github.com/espeak-ng/espeak-ng), through its C library: SSML
// read by it (its rate, breaks, say-as, sub, emphasis, voices and languages), each phone reported as it would be spoken
// -- its IPA name, stress marks included, and the millisecond it begins -- with the document's marks, words and
// sentences; and, where asked, its own audio (spoken(): eSpeak's intonation read from it). One synthesis at a time
// (eSpeak's state is global).
use std::ffi::{c_char, c_int, c_uint, c_void, CStr, CString};
use std::sync::Mutex;

#[repr(C)]
#[derive(Clone, Copy)]
union EventId {
    number: c_int,
    name: *const c_char,
    string: [u8; 8],
}

#[repr(C)]
struct RawEvent {
    kind: c_int,
    unique_identifier: c_uint,
    text_position: c_int,
    length: c_int,
    audio_position: c_int,
    sample: c_int,
    user_data: *mut c_void,
    id: EventId,
}

type Callback = extern "C" fn(*mut i16, c_int, *mut RawEvent) -> c_int;

extern "C" {
    fn espeak_Initialize(output: c_int, buflength: c_int, path: *const c_char, options: c_int) -> c_int;
    fn espeak_SetSynthCallback(cb: Callback);
    fn espeak_SetVoiceByName(name: *const c_char) -> c_int;
    fn espeak_Synth(text: *const c_void, size: usize, position: c_uint, position_type: c_int, end_position: c_uint, flags: c_uint, unique_identifier: *mut c_uint, user_data: *mut c_void) -> c_int;
    fn espeak_Synchronize() -> c_int;
}

const AUDIO_OUTPUT_SYNCHRONOUS: c_int = 2;
const POS_CHARACTER: c_int = 1;
const INITIALIZE_PHONEME_EVENTS: c_int = 0x0001;
const INITIALIZE_PHONEME_IPA: c_int = 0x0002;
const CHARS_UTF8: c_uint = 1;
const SSML: c_uint = 0x10;
const EVENT_WORD: c_int = 1;
const EVENT_SENTENCE: c_int = 2;
const EVENT_MARK: c_int = 3;
const EVENT_END: c_int = 5;
const EVENT_PHONEME: c_int = 7;

/// What eSpeak reports, each at the millisecond it falls; a phone and a word with the character (one-based, of the text
/// as given, its tags counted) where its word begins.
#[derive(Clone, Debug, PartialEq)]
pub enum Event {
    /// A phone: its IPA name with any stress mark ("ˈaɪ"); empty for a pause (whose position is not its word's).
    Phone { ipa: String, ms: i32, text: i32 },
    Mark { name: String, ms: i32 },
    Word { ms: i32, text: i32, length: i32 },
    Sentence { ms: i32 },
    /// The end of a clause or sentence.
    End { ms: i32 },
}

static STATE: Mutex<Option<Vec<Event>>> = Mutex::new(None);
static AUDIO: Mutex<Option<Vec<i16>>> = Mutex::new(None);
static RATE: Mutex<i32> = Mutex::new(0);

extern "C" fn collect(wav: *mut i16, n: c_int, mut e: *mut RawEvent) -> c_int {
    if let Some(audio) = AUDIO.lock().unwrap_or_else(|p| p.into_inner()).as_mut() {
        if !wav.is_null() && n > 0 {
            // SAFETY: eSpeak passes n samples at wav, alive for the call.
            audio.extend_from_slice(unsafe { std::slice::from_raw_parts(wav, n as usize) });
        }
    }
    let mut guard = STATE.lock().unwrap_or_else(|p| p.into_inner());
    let Some(out) = guard.as_mut() else { return 0 };
    // SAFETY: eSpeak passes a list of events ended by one of type 0, alive for the call.
    unsafe {
        while !e.is_null() && (*e).kind != 0 {
            let ms = (*e).audio_position;
            match (*e).kind {
                EVENT_PHONEME => {
                    let s = (*e).id.string;
                    let len = s.iter().position(|&b| b == 0).unwrap_or(8);
                    out.push(Event::Phone { ipa: String::from_utf8_lossy(&s[..len]).into_owned(), ms, text: (*e).text_position });
                }
                EVENT_MARK => {
                    let name = if (*e).id.name.is_null() { String::new() } else { CStr::from_ptr((*e).id.name).to_string_lossy().into_owned() };
                    out.push(Event::Mark { name, ms });
                }
                EVENT_WORD => out.push(Event::Word { ms, text: (*e).text_position, length: (*e).length }),
                EVENT_SENTENCE => out.push(Event::Sentence { ms }),
                EVENT_END => out.push(Event::End { ms }),
                _ => {}
            }
            e = e.add(1);
        }
    }
    0
}

static ENGINE: Mutex<Option<String>> = Mutex::new(None);

/// The events of an SSML document spoken by the eSpeak voice `voice` ("de", "en-us", ...).
pub fn events(ssml: &str, voice: &str) -> Result<Vec<Event>, String> {
    spoken(ssml, voice, false).map(|(e, _, _)| e)
}

/// The events, and where `audio`, eSpeak's own samples and their rate.
pub fn spoken(ssml: &str, voice: &str, audio: bool) -> Result<(Vec<Event>, Vec<i16>, i32), String> {
    let mut engine = ENGINE.lock().unwrap_or_else(|p| p.into_inner());
    // SAFETY: eSpeak's calls, made under the lock, with strings kept alive across them.
    unsafe {
        if engine.is_none() {
            let rate = espeak_Initialize(AUDIO_OUTPUT_SYNCHRONOUS, 0, std::ptr::null(), INITIALIZE_PHONEME_EVENTS | INITIALIZE_PHONEME_IPA);
            if rate <= 0 {
                return Err("eSpeak NG did not start (its data not found?)".into());
            }
            *RATE.lock().unwrap_or_else(|p| p.into_inner()) = rate;
            espeak_SetSynthCallback(collect);
            *engine = Some(String::new());
        }
        if engine.as_deref() != Some(voice) {
            let name = CString::new(voice).map_err(|e| e.to_string())?;
            if espeak_SetVoiceByName(name.as_ptr()) != 0 {
                return Err(format!("eSpeak NG has no voice {voice}"));
            }
            *engine = Some(voice.to_string());
        }
        *STATE.lock().unwrap_or_else(|p| p.into_inner()) = Some(Vec::new());
        *AUDIO.lock().unwrap_or_else(|p| p.into_inner()) = if audio { Some(Vec::new()) } else { None };
        let text = CString::new(ssml).map_err(|e| e.to_string())?;
        let bytes = text.as_bytes_with_nul();
        let err = espeak_Synth(text.as_ptr() as *const c_void, bytes.len(), 0, POS_CHARACTER, 0, SSML | CHARS_UTF8, std::ptr::null_mut(), std::ptr::null_mut());
        espeak_Synchronize();
        let out = STATE.lock().unwrap_or_else(|p| p.into_inner()).take().unwrap_or_default();
        let samples = AUDIO.lock().unwrap_or_else(|p| p.into_inner()).take().unwrap_or_default();
        if err != 0 {
            return Err(format!("eSpeak NG refused the text (error {err})"));
        }
        Ok((out, samples, *RATE.lock().unwrap_or_else(|p| p.into_inner())))
    }
}
