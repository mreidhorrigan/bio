// VocalTractLab's physical constants (Constants.h: Flanagan 1965, CGS units) and its synthesis rate.
// (Air's, from acoustics/tract.json: STATIC_PRESSURE_CGS, AMBIENT_DENSITY_CGS, ADIABATIC_CONSTANT, SOUND_VELOCITY_CGS,
// AIR_VISCOSITY_CGS, SPECIFIC_HEAT_CGS, HEAT_CONDUCTION_CGS, CRITICAL_REYNOLDS_NUMBER.)
include!(concat!(env!("OUT_DIR"), "/tract-constants.rs"));

pub const SAMPLING_RATE: i32 = 44100;
pub const SYNTHETIC_SPEECH_BANDWIDTH_HZ: f64 = 12000.0;

pub const PI: f64 = std::f64::consts::PI;
