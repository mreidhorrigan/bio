// A speaker's anatomy from thirteen measures (VocalTractLab 2.4's AnatomyParams.cpp; the owner, 13 November 2026: "We
// also need to separate, in the interface, a section for the *physiology of the speaking voice* (things that define male
// vs female, et cetera ...)"; "add the changeability to the physiology parameters"): the lips' width, the mandible's
// height, the lower and upper molars', the palate's height and depth, the hard and the soft palate's lengths, the
// pharynx's and the larynx's lengths, the larynx's width, the vocal folds' length and the angle between mouth and
// pharynx (cm, degrees). Read from a tract (`of`, getFrom); made from an age and a sex (`from_age`, calcFromAge: its
// growth curves); and laid on a tract from its reference speaker's anatomy (`set_for`, setFor): the palate and jaw with
// their teeth (the molars a child lacks taken away), the velum, the pharynx and larynx scaled, the tongue's circles,
// the tongue root's prediction fitted again, each articulatory parameter's range, neutral value and every shape carried
// over (`adapt_articulation`), and the tract made again. As 2.4 has it, but where it reads and writes a fourth tongue
// side parameter, TS4, which 2.4's tract has not: one past each array (docs/VOCALTRACTLAB_FIXES.md); here the three
// there are.
use super::tract::*;
use crate::geometry::{p2, P2};

pub const LIP_WIDTH: usize = 0;
pub const MANDIBLE_HEIGHT: usize = 1;
pub const LOWER_MOLARS_HEIGHT: usize = 2;
pub const UPPER_MOLARS_HEIGHT: usize = 3;
pub const PALATE_HEIGHT: usize = 4;
pub const PALATE_DEPTH: usize = 5;
pub const HARD_PALATE_LENGTH: usize = 6;
pub const SOFT_PALATE_LENGTH: usize = 7;
pub const PHARYNX_LENGTH: usize = 8;
pub const LARYNX_LENGTH: usize = 9;
pub const LARYNX_WIDTH: usize = 10;
pub const VOCAL_FOLD_LENGTH: usize = 11;
pub const ORAL_PHARYNGEAL_ANGLE: usize = 12;
pub const NUM_ANATOMY_PARAMS: usize = 13;

/// A measure: its name, VocalTractLab's abbreviation, its unit and its range.
pub struct AnatomyParam {
    pub name: &'static str,
    pub abbr: &'static str,
    pub key: &'static str,
    pub unit: &'static str,
    pub min: f64,
    pub max: f64,
}

/// The thirteen, as 2.4 names and bounds them (`key` the one `set` takes).
pub const ANATOMY_PARAMS: [AnatomyParam; NUM_ANATOMY_PARAMS] = [
    AnatomyParam { name: "Lip width", abbr: "W0", key: "lip_width", unit: "cm", min: 0.5, max: 1.5 },
    AnatomyParam { name: "Mandible height", abbr: "H5", key: "mandible_height", unit: "cm", min: 0.9, max: 1.8 },
    AnatomyParam { name: "Lower molars height", abbr: "H4", key: "lower_molars_height", unit: "cm", min: 0.3, max: 0.7 },
    AnatomyParam { name: "Upper molars height", abbr: "H3", key: "upper_molars_height", unit: "cm", min: 0.3, max: 0.7 },
    AnatomyParam { name: "Palate height", abbr: "H2", key: "palate_height", unit: "cm", min: 0.8, max: 2.0 },
    AnatomyParam { name: "Palate depth", abbr: "D0", key: "palate_depth", unit: "cm", min: 2.6, max: 5.0 },
    AnatomyParam { name: "Hard palate length", abbr: "W1 minus incisor width", key: "hard_palate_length", unit: "cm", min: 2.2, max: 5.2 },
    AnatomyParam { name: "Soft palate length", abbr: "W2", key: "soft_palate_length", unit: "cm", min: 2.3, max: 3.1 },
    AnatomyParam { name: "Pharynx length", abbr: "H0", key: "pharynx_length", unit: "cm", min: 3.5, max: 8.0 },
    AnatomyParam { name: "Larynx length", abbr: "H1", key: "larynx_length", unit: "cm", min: 2.0, max: 4.0 },
    AnatomyParam { name: "Larynx width", abbr: "W4", key: "larynx_width", unit: "cm", min: 2.0, max: 3.5 },
    AnatomyParam { name: "Vocal fold length", abbr: "W3", key: "vocal_fold_length", unit: "cm", min: 0.5, max: 2.0 },
    AnatomyParam { name: "Oral-pharyngeal angle", abbr: "A0", key: "oral_pharyngeal_angle", unit: "deg", min: -105.0, max: -90.0 },
];

/// An anatomy asked for: its measures, and whether they are held in 2.4's ranges (`set_for`) or a chorister's, held
/// only by the pharynx's rule (`set_for_unheld`).
#[derive(Clone, Copy, Debug)]
pub struct Asked {
    pub x: [f64; NUM_ANATOMY_PARAMS],
    pub held: bool,
}

impl Asked {
    /// Laid on `tract` from `reference` (the speaker as read) -> the measures as laid.
    pub fn lay(&self, tract: &mut VocalTract, reference: &VocalTract) -> [f64; NUM_ANATOMY_PARAMS] {
        let mut x = self.x;
        if self.held {
            set_for(&x, tract, reference);
            restrict(&mut x);
        } else {
            set_for_unheld(&x, tract, reference);
            pharynx_below_front(&mut x);
        }
        x
    }
}

/// The anatomy a tool is asked for (`anatomy=`): "none" (or nothing) -- the speaker's own --, "age,MONTHS,male" or
/// "age,MONTHS,female", the thirteen measures, comma-separated, or "singer," and a chorister's thirteen (src/singers.rs,
/// laid unheld) -> the measures, or None for the speaker's own.
pub fn asked(text: &str) -> Result<Option<Asked>, String> {
    let parts: Vec<&str> = text.split(',').map(str::trim).collect();
    let measures = |values: &[&str]| -> Result<[f64; NUM_ANATOMY_PARAMS], String> {
        let mut x = [0.0; NUM_ANATOMY_PARAMS];
        for (v, t) in x.iter_mut().zip(values) {
            *v = t.parse().map_err(|_| format!("anatomy: {t}?"))?;
        }
        Ok(x)
    };
    match parts.as_slice() {
        [""] | ["none"] => Ok(None),
        ["age", months, sex] if *sex == "male" || *sex == "female" => Ok(Some(Asked { x: from_age(months.parse().map_err(|_| format!("anatomy: {months} months?"))?, *sex == "male"), held: true })),
        values if values.len() == NUM_ANATOMY_PARAMS => Ok(Some(Asked { x: measures(values)?, held: true })),
        ["singer", values @ ..] if values.len() == NUM_ANATOMY_PARAMS => Ok(Some(Asked { x: measures(values)?, held: false })),
        _ => Err(format!("anatomy={text}: none, age,MONTHS,male|female, the thirteen measures, or singer and a chorister's thirteen")),
    }
}

/// The measures held in their ranges, and the pharynx at least as long as the palate, molars and mandible are high
/// (restrictParams).
pub fn restrict(x: &mut [f64; NUM_ANATOMY_PARAMS]) {
    for (v, p) in x.iter_mut().zip(ANATOMY_PARAMS.iter()) {
        if *v < p.min {
            *v = p.min;
        }
        if *v > p.max {
            *v = p.max;
        }
    }
    pharynx_below_front(x);
}

/// The pharynx at least as long as the palate, molars and mandible are high (restrictParams' last rule).
pub fn pharynx_below_front(x: &mut [f64; NUM_ANATOMY_PARAMS]) {
    let d = x[PALATE_HEIGHT] + x[UPPER_MOLARS_HEIGHT] + x[LOWER_MOLARS_HEIGHT] + x[MANDIBLE_HEIGHT];
    if x[PHARYNX_LENGTH] < d {
        x[PHARYNX_LENGTH] = d;
    }
}

/// A tract's measures (getFrom).
pub fn of(tract: &VocalTract) -> [f64; NUM_ANATOMY_PARAMS] {
    let a = &tract.anatomy;
    let mut x = [0.0; NUM_ANATOMY_PARAMS];
    x[LIP_WIDTH] = a.lips_width_cm;
    x[MANDIBLE_HEIGHT] = a.jaw_height_cm[3];
    x[LOWER_MOLARS_HEIGHT] = a.lower_teeth_height_cm[3];
    x[UPPER_MOLARS_HEIGHT] = a.upper_teeth_height_cm[3];
    x[PALATE_HEIGHT] = a.palate_height_cm[3];
    x[PALATE_DEPTH] = -2.0 * a.palate_points[3].z;
    x[HARD_PALATE_LENGTH] = a.palate_points[8].x;
    x[SOFT_PALATE_LENGTH] = -a.pharynx_fulcrum.x;
    x[PHARYNX_LENGTH] = a.palate_height_cm[3] - 0.5 * (tract.param[HY].min + tract.param[HY].max);
    x[LARYNX_LENGTH] = -0.5 * (a.larynx_narrow_points[3].y + a.larynx_wide_points[3].y);
    // (The larynx's widest.)
    x[LARYNX_WIDTH] = a.larynx_wide_points[0].x;
    x[VOCAL_FOLD_LENGTH] = 0.5 * (a.larynx_narrow_points[3].x - a.larynx_narrow_points[4].x + a.larynx_wide_points[3].x - a.larynx_wide_points[4].x);
    x[ORAL_PHARYNGEAL_ANGLE] = a.pharynx_rotation_angle_deg;
    x
}

/// The measures of a child or adult of `age_month` (one year at least), male or female, from 2.4's growth curves of
/// cephalometric measures (calcFromAge; mm made cm).
pub fn from_age(age_month: i32, male: bool) -> [f64; NUM_ANATOMY_PARAMS] {
    let age_month = age_month.max(12);
    let t = age_month as f64 / 12.0;
    let sigmoids = |a: f64, b: f64, c: f64, d: f64, e: f64, f: f64| a / (1.0 + (b - c * c * t).exp()) + d / (1.0 + (e - f * f * t).exp());
    // (The angle of the Frankfort horizontal to the body of the jaw.)
    let angfhj = 26.856 + -0.170 * t;
    // (The posterior pharynx wall's angle to the perpendicular of the Frankfort horizontal.)
    let (a, b) = match (age_month < 30, male) {
        (true, true) => (4.88, 1.467),
        (true, false) => (13.037, 1.305),
        (false, true) => (-2.086, 0.545),
        (false, false) => (4.383, 0.203),
    };
    let angfhv = a + b * t;
    // (The palatal line's angle to the body of the jaw.)
    let angpj = 27.85 + -0.401 * t;
    // (The anterior to the posterior nasal spine.)
    let anspns = if male { sigmoids(49.152, -0.889, 0.512, 6.002, 10.395, 0.920) } else { sigmoids(44.414, -1.210, 0.699, 7.807, 5.218, 0.727) } / 10.0;
    // (The atlas's anterior tubercle to the pterygomaxillary fissure.)
    let atlptm = if male { 27.043 + 0.213 * t } else { 27.727 + 0.094 * t } / 10.0;
    // (The hyoid's lower border to the glottis, along the epiglottis.)
    let hyglott = if male { 8.351 + -4.020 * (-1.316 * t).exp() + 2.756 * (0.083 * t).exp() } else { 11.143 + 0.298 * t - (1.4 + -1.235 * t).exp() } / 10.0;
    // (The vocal cords' length.)
    let lenvc = if male { sigmoids(7.618, -0.311, 1.14, 11.05, 13.003, 0.939) } else { 5.997 + 0.39 * t - (0.804 + -2.435 * t).exp() } / 10.0;
    // (The soft tissue's thickness over the maxilla below the anterior nasal spine.)
    let lips = if male { 27.439 + -17.612 * (-0.030 * t).exp() } else { 22.07 + -13.41 * (-0.041 * t).exp() } / 10.0;
    // (The palate's height; its width between the molars.)
    let palhit = (17.813 + -8.859 * (-0.077 * t).exp()) / 10.0;
    let palwi = if male { 35.471 + -8.472 * (-0.098 * t).exp() } else { 32.709 + -7.378 * (-0.174 * t).exp() } / 10.0;
    // (The sella-nasion line to the hyoid's middle, and to the posterior nasal spine.)
    let snhy = if male { sigmoids(62.731, -0.526, 1.103, 82.559, 2.655, 0.423) } else { sigmoids(64.002, -0.621, 1.143, 38.254, 3.06, 0.597) } / 10.0;
    let snpns = if male { sigmoids(42.342, 0.169, 0.372, 6.91, 1.154, 1.748) } else { sigmoids(22.865, -0.507, 1.326, 21.141, 1.35, 0.519) } / 10.0;
    // (The mandibular symphysis's height.)
    let symph = sigmoids(23.411, -1.310, -0.626, 4.481, 23.061, 1.369) / 10.0;
    let thihy = (5.633 + 0.185 * t) / 10.0;
    let mut x = [0.0; NUM_ANATOMY_PARAMS];
    x[LIP_WIDTH] = lips - 0.5;
    // (Less the upper incisor's width.)
    x[HARD_PALATE_LENGTH] = anspns - 1.0;
    x[SOFT_PALATE_LENGTH] = atlptm - 0.2;
    // (The 8 degrees between the maxillary alveolar margin and the palatal line.)
    x[ORAL_PHARYNGEAL_ANGLE] = -(angfhv + angfhj - angpj + 90.0) + 8.0;
    if x[ORAL_PHARYNGEAL_ANGLE] > -90.0 {
        x[ORAL_PHARYNGEAL_ANGLE] = -90.0;
    }
    x[PHARYNX_LENGTH] = snhy - snpns - 0.5 * thihy - 0.2;
    x[LARYNX_LENGTH] = hyglott * (120.0 * std::f64::consts::PI / 180.0).sin() + thihy + 0.1;
    x[VOCAL_FOLD_LENGTH] = lenvc;
    x[LARYNX_WIDTH] = x[SOFT_PALATE_LENGTH];
    x[PALATE_HEIGHT] = palhit;
    // (The teeth's height, Goldstein 1980, p. 167.)
    let teeth = if age_month < 7 * 12 { 0.3 } else { 0.5 };
    x[UPPER_MOLARS_HEIGHT] = teeth;
    x[LOWER_MOLARS_HEIGHT] = teeth;
    x[MANDIBLE_HEIGHT] = symph * (70.0 * std::f64::consts::PI / 180.0).sin() - 1.0;
    x[PALATE_DEPTH] = palwi;
    x
}

// (A horizontal coordinate carried from `orig`'s measures to `x`'s: behind the palate's start by the soft palate's
// length, before it by the hard palate's -- transformX.)
fn transform_x(x: &[f64; NUM_ANATOMY_PARAMS], orig: &[f64; NUM_ANATOMY_PARAMS], ox: f64) -> f64 {
    if ox < 0.0 {
        ox * x[SOFT_PALATE_LENGTH] / orig[SOFT_PALATE_LENGTH]
    } else {
        ox * x[HARD_PALATE_LENGTH] / orig[HARD_PALATE_LENGTH]
    }
}

// (A height carried over, by the pharynx's length behind and the front's height before, as far along as `ox` lies --
// transformY with an x.)
fn transform_y_at(x: &[f64; NUM_ANATOMY_PARAMS], orig: &[f64; NUM_ANATOMY_PARAMS], ox: f64, oy: f64) -> f64 {
    let t = ((ox - (-orig[SOFT_PALATE_LENGTH])) / (orig[SOFT_PALATE_LENGTH] + orig[HARD_PALATE_LENGTH])).clamp(0.0, 1.0);
    let left = x[PALATE_HEIGHT] + (oy - orig[PALATE_HEIGHT]) * x[PHARYNX_LENGTH] / orig[PHARYNX_LENGTH];
    let front = x[PALATE_HEIGHT] + x[UPPER_MOLARS_HEIGHT] + x[LOWER_MOLARS_HEIGHT] + x[MANDIBLE_HEIGHT];
    let orig_front = orig[PALATE_HEIGHT] + orig[UPPER_MOLARS_HEIGHT] + orig[LOWER_MOLARS_HEIGHT] + orig[MANDIBLE_HEIGHT];
    let right = x[PALATE_HEIGHT] + (oy - orig[PALATE_HEIGHT]) * front / orig_front;
    (1.0 - t) * left + t * right
}

// (A height carried over by the pharynx's length -- transformY.)
fn transform_y(x: &[f64; NUM_ANATOMY_PARAMS], orig: &[f64; NUM_ANATOMY_PARAMS], oy: f64) -> f64 {
    x[PALATE_HEIGHT] + (oy - orig[PALATE_HEIGHT]) * x[PHARYNX_LENGTH] / orig[PHARYNX_LENGTH]
}

/// A shape's articulation on the reference speaker carried to the measures `x` (adaptArticulation).
pub fn adapt_articulation(x: &[f64; NUM_ANATOMY_PARAMS], reference: &VocalTract, old: &[f64]) -> [f64; NUM_PARAMS] {
    let orig = of(reference);
    let height = x[PHARYNX_LENGTH] / orig[PHARYNX_LENGTH];
    let width = (x[SOFT_PALATE_LENGTH] + x[HARD_PALATE_LENGTH]) / (orig[SOFT_PALATE_LENGTH] + orig[HARD_PALATE_LENGTH]);
    let mut n = [0.0; NUM_PARAMS];
    n[HX] = old[HX];
    n[HY] = transform_y_at(x, &orig, 0.0, old[HY]);
    n[JX] = old[JX] * width;
    n[JA] = old[JA];
    n[LP] = old[LP];
    n[LD] = old[LD] * height;
    n[VS] = old[VS];
    n[VO] = old[VO];
    for (cx, cy) in [(TCX, TCY), (TTX, TTY), (TBX, TBY), (TRX, TRY)] {
        n[cx] = transform_x(x, &orig, old[cx]);
        n[cy] = transform_y_at(x, &orig, old[cx], old[cy]);
    }
    // (The tongue's sides' heights with the tract's depth: TS1 to TS3 -- 2.4's loop runs to a TS4 it has not.)
    let depth = x[PALATE_DEPTH] / orig[PALATE_DEPTH];
    for k in [TS1, TS2, TS3] {
        n[k] = old[k] * depth;
    }
    n
}

/// The measures `x` (held in their ranges) laid on `tract` from its reference speaker's anatomy, `reference` -- the
/// speaker as read -- and the tract made again (setFor).
pub fn set_for(x: &[f64; NUM_ANATOMY_PARAMS], tract: &mut VocalTract, reference: &VocalTract) {
    let mut x = *x;
    restrict(&mut x);
    lay(&x, tract, reference);
}

/// The measures `x` laid as `set_for` lays them, none held in 2.4's ranges but the pharynx at least as long as the
/// front is high: a chorister's (src/singers.rs), drawn on a measured speaker who may lie outside those ranges (M01's
/// larynx 4.6 cm wide and 4.1 long, where 2.4 allows 3.5 and 4.0, held there by `set_for` whatever is asked), its reach
/// checked on the engine instead (examples/singer_reach.rs; research/VOCALWIND_CHOIR.md, "Singers drawn by voice
/// type").
pub fn set_for_unheld(x: &[f64; NUM_ANATOMY_PARAMS], tract: &mut VocalTract, reference: &VocalTract) {
    let mut x = *x;
    pharynx_below_front(&mut x);
    lay(&x, tract, reference);
}

// (The palate's height behind, where a palate `inner_palate_length` long ends along the reference's, its heights scaled
// by `height_scale`; the reference's first rib's where it ends behind them all.)
fn posterior_palate_height_at(o: &Anatomy, inner_palate_length: f64, height_scale: f64) -> f64 {
    let p = &o.palate_points;
    let mut posterior_palate_height = o.palate_height_cm[0];
    for i in 0..NUM_JAW_RIBS - 1 {
        let x0 = inner_palate_length - (p[8].x - p[i].x);
        let x1 = inner_palate_length - (p[8].x - p[i + 1].x);
        if x0 <= 0.0 && x1 >= 0.0 {
            let den = (x1 - x0).max(0.000001);
            let t = (0.0 - x0) / den;
            posterior_palate_height = (1.0 - t) * o.palate_height_cm[i] + t * o.palate_height_cm[i + 1];
        }
    }
    posterior_palate_height * height_scale
}

// (setFor's laying of measures already held. Where the tract is mended, two of 2.4's departures from the reference's
// own anatomy at its own measures are mended, so that a speaker laid at its own measures is itself: the lower teeth
// placed from the mandible's length, where 2.4 places them from the palate's and so moves a speaker's lower incisors to
// its upper (JD2's 1.5 mm forward); and the velum scaled by the palate's height behind over the reference's own there,
// where 2.4 scales it over its highest point and so lowers a velum that rises above the palate (M01's, 1 mm above
// it, scaled 6% down). docs/VOCALTRACTLAB_FIXES.md, 6.)
fn lay(x: &[f64; NUM_ANATOMY_PARAMS], tract: &mut VocalTract, reference: &VocalTract) {
    let orig_x = of(reference);
    let o = &reference.anatomy;
    let mended = tract.mended;
    let a = &mut tract.anatomy;
    a.lips_width_cm = x[LIP_WIDTH];
    // The palate and the mandible.
    let inner_dentition_length_t5 = o.palate_points[8].x - o.palate_points[3].x;
    let inner_palate_length = x[HARD_PALATE_LENGTH];
    let inner_jaw_length = x[HARD_PALATE_LENGTH] * o.jaw_points[8].x / o.palate_points[8].x;
    let upper_teeth_height_scale = x[UPPER_MOLARS_HEIGHT] / o.upper_teeth_height_cm[3];
    let lower_teeth_height_scale = x[LOWER_MOLARS_HEIGHT] / o.lower_teeth_height_cm[3];
    let mut posterior_palate_height = o.palate_height_cm[0];
    let model_depth_scale;
    if inner_palate_length < inner_dentition_length_t5 {
        // (Shorter than a child's milk teeth: 2.4's own "MUST BE REWORKED LATER".)
        let width_scale = inner_palate_length / (o.palate_points[8].x - o.palate_points[3].x);
        model_depth_scale = -x[PALATE_DEPTH] / (o.palate_points[3].z * 2.0);
        for i in 3..9 {
            a.palate_points[i].x = o.palate_points[0].x + width_scale * (o.palate_points[i].x - o.palate_points[3].x);
            a.palate_points[i].z = model_depth_scale * o.palate_points[i].z;
            a.palate_points[i].y = o.palate_points[i].y;
        }
        // (The first three ribs as the fourth, the molars gone.)
        for i in 0..3 {
            a.palate_points[i] = a.palate_points[3];
            a.palate_angle_deg[i] = a.palate_angle_deg[3];
            a.palate_height_cm[i] = a.palate_height_cm[3];
            a.upper_teeth_height_cm[i] = 0.0;
        }
    } else {
        // (Long enough for every milk tooth, and for one, two or three molars.)
        let p = &o.palate_points;
        let height_scale = x[PALATE_HEIGHT] / o.palate_height_cm[3];
        let missing = |len: f64, q: &[crate::geometry::P3]| if len < q[8].x - q[2].x { 3 } else if len < q[8].x - q[1].x { 2 } else if len < q[8].x - q[0].x { 1 } else { 0 };
        let missing_teeth: usize = missing(inner_palate_length, p);
        let inner_dentition_length = p[8].x - p[missing_teeth].x;
        let teeth_offset_x = inner_palate_length - inner_dentition_length;
        model_depth_scale = -x[PALATE_DEPTH] / (p[3].z * 2.0);
        // (The palate's height behind, where its new length ends along the old.)
        posterior_palate_height = posterior_palate_height_at(o, inner_palate_length, height_scale);
        for i in (0..9).rev() {
            if i >= missing_teeth {
                a.palate_points[i].x = teeth_offset_x + (p[i].x - p[missing_teeth].x);
                a.palate_points[i].z = model_depth_scale * p[i].z;
                a.palate_points[i].y = p[i].y;
                a.palate_angle_deg[i] = o.palate_angle_deg[i];
                a.palate_height_cm[i] = o.palate_height_cm[i] * height_scale;
                a.upper_teeth_height_cm[i] = o.upper_teeth_height_cm[i] * upper_teeth_height_scale;
            } else {
                // (A rib without its tooth at x = 0, as the first that has one; the velum moves it anyway.)
                a.palate_points[i] = a.palate_points[missing_teeth];
                a.palate_points[i].x = 0.000001;
                a.palate_angle_deg[i] = a.palate_angle_deg[missing_teeth];
                a.palate_height_cm[i] = posterior_palate_height;
                a.upper_teeth_height_cm[i] = 0.0;
            }
            a.upper_teeth_width_bottom_cm[i] = o.upper_teeth_width_bottom_cm[i] * model_depth_scale;
            a.upper_teeth_width_top_cm[i] = o.upper_teeth_width_top_cm[i] * model_depth_scale;
        }
        // (The mandible: the palate's depth scale, its own height scale; its teeth placed from the palate's length, as
        // 2.4 places them.)
        let p = &o.jaw_points;
        let height_scale = x[MANDIBLE_HEIGHT] / o.jaw_height_cm[3];
        let missing_teeth: usize = missing(inner_jaw_length, p);
        let inner_dentition_length = p[8].x - p[missing_teeth].x;
        let teeth_offset_x = if mended { inner_jaw_length } else { inner_palate_length } - inner_dentition_length;
        for i in (0..9).rev() {
            if i >= missing_teeth {
                a.jaw_points[i].x = teeth_offset_x + (p[i].x - p[missing_teeth].x);
                a.jaw_points[i].z = model_depth_scale * p[i].z;
                a.jaw_points[i].y = p[i].y;
                a.jaw_angle_deg[i] = o.jaw_angle_deg[i];
                a.jaw_height_cm[i] = o.jaw_height_cm[i] * height_scale;
                a.lower_teeth_height_cm[i] = o.lower_teeth_height_cm[i] * lower_teeth_height_scale;
            } else {
                a.jaw_points[i] = a.jaw_points[missing_teeth];
                a.jaw_points[i].x = 0.000001;
                a.jaw_angle_deg[i] = a.jaw_angle_deg[missing_teeth];
                a.jaw_height_cm[i] = a.jaw_height_cm[missing_teeth];
                a.lower_teeth_height_cm[i] = 0.0;
            }
            a.lower_teeth_width_bottom_cm[i] = o.lower_teeth_width_bottom_cm[i] * model_depth_scale;
            a.lower_teeth_width_top_cm[i] = o.lower_teeth_width_top_cm[i] * model_depth_scale;
        }
    }
    // The lower incisors' roots; the jaw's rest lowered as the teeth grow.
    a.tooth_root_length_cm = o.tooth_root_length_cm * (x[MANDIBLE_HEIGHT] / orig_x[MANDIBLE_HEIGHT]);
    let delta_upper = x[UPPER_MOLARS_HEIGHT] - o.upper_teeth_height_cm[3];
    let delta_lower = x[LOWER_MOLARS_HEIGHT] - o.lower_teeth_height_cm[3];
    a.jaw_fulcrum = o.jaw_fulcrum;
    a.jaw_rest_pos = o.jaw_rest_pos;
    a.jaw_rest_pos.y -= delta_upper + delta_lower;
    // The velum in its three states, and the center of rotation between mouth and pharynx: scaled upward from the low
    // state's lowest point.
    let lowest = o.velum_low_points[0].y;
    let highest = if mended { posterior_palate_height_at(o, orig_x[HARD_PALATE_LENGTH], 1.0) } else { o.velum_high_points[NUM_VELUM_RIBS - 2].y };
    let height_scale = (posterior_palate_height - lowest) / (highest - lowest);
    let width_scale = x[SOFT_PALATE_LENGTH] / (-o.pharynx_fulcrum.x);
    a.pharynx_fulcrum.x = o.pharynx_fulcrum.x * width_scale;
    a.pharynx_fulcrum.y = lowest + (o.pharynx_fulcrum.y - lowest) * height_scale;
    let scaled = |q: P2| p2(q.x * width_scale, lowest + (q.y - lowest) * height_scale);
    for i in 0..NUM_VELUM_RIBS - 1 {
        a.velum_low_points[i] = scaled(o.velum_low_points[i]);
        a.velum_mid_points[i] = scaled(o.velum_mid_points[i]);
        a.velum_high_points[i] = scaled(o.velum_high_points[i]);
    }
    // (2.4's bound on HY below: a ratio of depths and lengths, compared there with a height -- kept as it is.)
    let d = (x[PALATE_DEPTH] * x[SOFT_PALATE_LENGTH]) / (orig_x[PALATE_DEPTH] * orig_x[SOFT_PALATE_LENGTH]);
    // The tract's depth with the jaws'.
    a.uvula_depth_cm = o.uvula_depth_cm * model_depth_scale;
    a.epiglottis_depth_cm = o.epiglottis_depth_cm * model_depth_scale;
    a.pharynx_upper_depth_cm = o.pharynx_upper_depth_cm * model_depth_scale;
    a.pharynx_lower_depth_cm = o.pharynx_lower_depth_cm * model_depth_scale;
    a.larynx_upper_depth_cm = o.larynx_upper_depth_cm * model_depth_scale;
    a.larynx_lower_depth_cm = o.larynx_lower_depth_cm * model_depth_scale;
    // The larynx's shape: its length and width, its lower part by the vocal folds' length, never narrower there than
    // the reference's.
    let mean_height = -0.5 * (o.larynx_narrow_points[3].y + o.larynx_wide_points[3].y);
    let height_scale = x[LARYNX_LENGTH] / mean_height;
    let width_scale = x[LARYNX_WIDTH] / o.larynx_wide_points[0].x;
    for i in 0..8 {
        a.larynx_narrow_points[i] = p2(o.larynx_narrow_points[i].x * width_scale, o.larynx_narrow_points[i].y * height_scale);
        a.larynx_wide_points[i] = p2(o.larynx_wide_points[i].x * width_scale, o.larynx_wide_points[i].y * height_scale);
    }
    for (l, ol) in [(&mut a.larynx_narrow_points, &o.larynx_narrow_points), (&mut a.larynx_wide_points, &o.larynx_wide_points)] {
        let w = x[VOCAL_FOLD_LENGTH] / (ol[3].x - ol[4].x);
        l[3].x = l[4].x + x[VOCAL_FOLD_LENGTH];
        l[2].x = l[5].x + w * (ol[2].x - ol[5].x);
    }
    for (l, ol) in [(&mut a.larynx_narrow_points, &o.larynx_narrow_points), (&mut a.larynx_wide_points, &o.larynx_wide_points)] {
        let min_width = ol[2].x - ol[5].x;
        if l[2].x - l[5].x < min_width {
            l[5].x = l[2].x - min_width;
        }
    }
    a.pharynx_rotation_angle_deg = x[ORAL_PHARYNGEAL_ANGLE];
    // The epiglottis and uvula with the pharynx's length.
    let height_scale = x[PHARYNX_LENGTH] / orig_x[PHARYNX_LENGTH];
    a.uvula_width_cm = o.uvula_width_cm * height_scale;
    a.uvula_height_cm = o.uvula_height_cm * height_scale;
    a.uvula_depth_cm = o.uvula_depth_cm * model_depth_scale;
    a.epiglottis_width_cm = o.epiglottis_width_cm * height_scale;
    a.epiglottis_height_cm = o.epiglottis_height_cm * height_scale;
    a.epiglottis_depth_cm = o.epiglottis_depth_cm * model_depth_scale;
    // The tongue body's and tip's circles.
    let width_scale = (x[HARD_PALATE_LENGTH] + x[SOFT_PALATE_LENGTH]) / (orig_x[HARD_PALATE_LENGTH] + orig_x[SOFT_PALATE_LENGTH]);
    a.tongue_center_radius_x_cm = o.tongue_center_radius_x_cm * width_scale;
    a.tongue_center_radius_y_cm = o.tongue_center_radius_y_cm * height_scale;
    a.tongue_tip_radius_cm = o.tongue_tip_radius_cm * width_scale;
    // (The tongue root's prediction, for now the reference's; fitted below.)
    a.tongue_root_rule = o.tongue_root_rule;
    a.tongue_root_trx_slope = o.tongue_root_trx_slope;
    a.tongue_root_trx_intercept = o.tongue_root_trx_intercept;
    a.tongue_root_try_slope = o.tongue_root_try_slope;
    a.tongue_root_try_intercept = o.tongue_root_try_intercept;
    // The articulatory parameters' ranges.
    let (op, np) = (&reference.param, &mut tract.param);
    np[HY].min = transform_y(&x, &orig_x, op[HY].min);
    np[HY].max = transform_y(&x, &orig_x, op[HY].max);
    if np[HY].min > d {
        np[HY].min = d;
    }
    if np[HY].max > d {
        np[HY].max = d;
    }
    np[JX].min = op[JX].min * width_scale;
    np[JX].max = op[JX].max * width_scale;
    np[LD].min = op[LD].min * height_scale;
    np[LD].max = op[LD].max * height_scale;
    for (cx, cy) in [(TCX, TCY), (TTX, TTY), (TBX, TBY), (TRX, TRY)] {
        np[cx].min = transform_x(&x, &orig_x, op[cx].min);
        np[cx].max = transform_x(&x, &orig_x, op[cx].max);
        np[cy].min = transform_y(&x, &orig_x, op[cy].min);
        np[cy].max = transform_y(&x, &orig_x, op[cy].max);
    }
    let depth_scale = x[PALATE_DEPTH] / orig_x[PALATE_DEPTH];
    for k in [TS1, TS2, TS3] {
        np[k].min = op[k].min * depth_scale;
        np[k].max = op[k].max * depth_scale;
    }
    // The parameters' values, their neutral values, and every shape of the reference speaker's, carried over.
    let old: Vec<f64> = op.iter().map(|p| p.x).collect();
    let new = adapt_articulation(&x, reference, &old);
    let old: Vec<f64> = op.iter().map(|p| p.neutral).collect();
    let neutral = adapt_articulation(&x, reference, &old);
    for k in 0..NUM_PARAMS {
        tract.param[k].x = new[k];
        tract.param[k].neutral = neutral[k];
    }
    tract.shapes = reference.shapes.iter().map(|(name, v)| (name.clone(), adapt_articulation(&x, reference, v))).collect();
    // The tract made again on its new anatomy, its tongue root's prediction fitted to it, and made again.
    tract.init_reference_surfaces();
    tract.calculate_all();
    adjust_tongue_root_calculation(tract, reference);
    tract.calculate_all();
}

/// The tongue root's prediction (TRX and TRY from the hyoid and the tongue body) fitted to the new anatomy: two
/// shapes, /a/-like with the tongue body on the hyoid and /i/-like under the hard palate's middle, their tongue roots
/// predicted on the reference speaker and carried to the new one relative to the tongue body; the two lines solved
/// through them (adjustTongueRootCalculation). Every parameter at its range's middle meanwhile, then as it was.
fn adjust_tongue_root_calculation(target: &mut VocalTract, reference: &VocalTract) {
    let mut orig = reference.clone();
    let saved: Vec<f64> = target.param.iter().map(|p| p.x).collect();
    for p in orig.param.iter_mut() {
        p.x = 0.5 * (p.min + p.max);
    }
    for p in target.param.iter_mut() {
        p.x = 0.5 * (p.min + p.max);
    }
    orig.calculate_all();
    target.calculate_all();
    let hyoid = |vt: &VocalTract| {
        let v = vt.surface[LOWER_COVER].get(NUM_LARYNX_RIBS - 1, NUM_LOWER_COVER_POINTS - 1);
        p2(v.x, v.y)
    };
    let (oa, orig_h, new_h) = (&orig.anatomy, hyoid(&orig), hyoid(target));
    let na = &target.anatomy;
    let orig_tc1 = p2(orig_h.x, orig_h.y + oa.tongue_center_radius_y_cm);
    let new_tc1 = p2(new_h.x, new_h.y + na.tongue_center_radius_y_cm);
    let orig_tc2 = p2(oa.palate_points[3].x, oa.palate_height_cm[3] - oa.tongue_center_radius_y_cm);
    let new_tc2 = p2(na.palate_points[3].x, na.palate_height_cm[3] - na.tongue_center_radius_y_cm);
    let root = |tc: P2| {
        let distance = (orig_h - tc).magnitude();
        p2(oa.tongue_root_trx_slope * distance + oa.tongue_root_trx_intercept, oa.tongue_root_try_slope * tc.x + oa.tongue_root_try_intercept)
    };
    let (orig_tr1, orig_tr2) = (root(orig_tc1), root(orig_tc2));
    let carried = |otr: P2, otc: P2, ntc: P2| {
        let tx = (otr.x - otc.x) / oa.tongue_center_radius_x_cm;
        let ty = (otr.y - otc.y) / oa.tongue_center_radius_y_cm;
        p2(ntc.x + na.tongue_center_radius_x_cm * tx, ntc.y + na.tongue_center_radius_y_cm * ty)
    };
    let (new_tr1, new_tr2) = (carried(orig_tr1, orig_tc1, new_tc1), carried(orig_tr2, orig_tc2, new_tc2));
    let d1 = (new_h - new_tc1).magnitude();
    let d2 = (new_h - new_tc2).magnitude();
    let trx_slope = (new_tr2.x - new_tr1.x) / (d2 - d1);
    let trx_intercept = new_tr1.x - trx_slope * d1;
    let try_slope = (new_tr2.y - new_tr1.y) / (new_tc2.x - new_tc1.x);
    let try_intercept = new_tr1.y - try_slope * new_tc1.x;
    let rule = oa.tongue_root_rule;
    let na = &mut target.anatomy;
    na.tongue_root_trx_slope = trx_slope;
    na.tongue_root_trx_intercept = trx_intercept;
    na.tongue_root_try_slope = try_slope;
    na.tongue_root_try_intercept = try_intercept;
    na.tongue_root_rule = rule;
    for (p, x) in target.param.iter_mut().zip(saved) {
        p.x = x;
    }
    target.calculate_all();
}
