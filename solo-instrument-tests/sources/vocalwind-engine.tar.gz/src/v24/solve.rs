// The tube's system, solved each step for its branch currents (TdsModel::solveCholesky's part). The network's implicit
// discretization couples two currents exactly where they share a section, so its matrix is symmetric and sparse: each
// section's currents (the one in, one or two out) couple to one another, a tree of such cliques. The system is kept as
// its pattern's values alone, the lower triangle 2.4 reads (row the later current in its numbering, the diagonal), each
// written where calc_matrix writes its row (`System::at`); the upper triangle's writes, which 2.4 never reads, go to a
// slot nothing reads.
//
// EnvelopeCholesky is 2.4's factorization, the matrix negated, in its own numbering over each row's envelope: every
// product and every subtraction as it makes them, in their order, each sum held in a register between them; where a row
// below has nothing yet (outside its envelope: zero in the C++, never written) its products are passed over -- they
// change nothing. Its forward substitution is made for each row as soon as the row is factorized (the same operations
// in the same order, interleaved), so that the processor overlaps the two chains of dependence.

/// The system's matrix (its pattern's lower triangle) and right-hand side, as calc_matrix writes them.
#[derive(Clone)]
pub struct System {
    pub n: usize,
    /// Where row i's column j is kept: `values[slot[i * n + j]]`; ZERO for a pair never coupled (never written, read as
    /// zero), DEAD for the upper triangle (written, never read).
    slot: Vec<u32>,
    pub values: Vec<f64>,
    pub rhs: Vec<f64>,
    /// The coupled pairs (i, j), i >= j, in the order of `values`.
    pub pairs: Vec<(usize, usize)>,
}

impl System {
    /// A system coupling the currents in `pattern` (n x n, symmetric): its values all 1, as 2.4's init_model sets them.
    pub fn new(n: usize, pattern: &[bool]) -> System {
        let mut pairs = Vec::new();
        for i in 0..n {
            for j in 0..=i {
                if pattern[i * n + j] || i == j {
                    pairs.push((i, j));
                }
            }
        }
        let zero = pairs.len() as u32;
        let dead = zero + 1;
        let mut slot = vec![zero; n * n];
        for (k, &(i, j)) in pairs.iter().enumerate() {
            slot[i * n + j] = k as u32;
            slot[j * n + i] = if i == j { k as u32 } else { dead };
        }
        let mut values = vec![1.0; pairs.len() + 2];
        values[zero as usize] = 0.0;
        values[dead as usize] = 0.0;
        System { n, slot, values, rhs: vec![0.0; n], pairs }
    }

    /// Where row i's column j is written.
    #[inline(always)]
    pub fn at(&self, i: usize, j: usize) -> usize {
        self.slot[i * self.n + j] as usize
    }

    /// Row i's column j, to be written.
    #[inline(always)]
    pub fn entry(&mut self, i: usize, j: usize) -> &mut f64 {
        let at = self.slot[i * self.n + j] as usize;
        &mut self.values[at]
    }

    /// Row i's column j as 2.4's solve reads it: the lower triangle's (i >= j), zero where nothing couples them.
    pub fn get(&self, i: usize, j: usize) -> f64 {
        let (i, j) = if i >= j { (i, j) } else { (j, i) };
        self.values[self.at(i, j)]
    }

    /// The slot of a pair never coupled (always zero).
    pub fn zero_slot(&self) -> usize {
        self.pairs.len()
    }
}

/// One entry of the factor below the diagonal, row i's column k: its place in the factor, where its value starts (the
/// matrix's, negated), and the stretch of row i and row k whose products are taken from it (`len` from each start).
#[derive(Clone, Copy, Debug)]
struct Entry {
    at: u32,
    from: u32,
    a: u32,
    b: u32,
    len: u32,
}

/// 2.4's factorization (above).
#[derive(Clone)]
pub struct EnvelopeCholesky {
    n: usize,
    /// Row i's envelope, from column start[i] to its diagonal, kept from off[i] in `factor`.
    start: Vec<usize>,
    off: Vec<usize>,
    /// Each row's diagonal, where its value starts.
    diag_from: Vec<u32>,
    /// Column k's entries below its diagonal, entries[col[k]..col[k + 1]], their rows ascending.
    col: Vec<usize>,
    entries: Vec<Entry>,
    /// The rows of column k's entries, for the backward substitution.
    rows: Vec<u32>,
    factor: Vec<f64>,
    y: Vec<f64>,
    /// Pivots found below zero and made zero (as 2.4 makes them), since it was made.
    pub negative_pivots: u64,
}

impl EnvelopeCholesky {
    pub fn new(system: &System) -> EnvelopeCholesky {
        let n = system.n;
        let coupled = |i: usize, j: usize| system.at(i, j) != system.zero_slot();
        let start: Vec<usize> = (0..n).map(|i| (0..i).find(|&j| coupled(i, j)).unwrap_or(i)).collect();
        let mut off = vec![0; n + 1];
        for i in 0..n {
            off[i + 1] = off[i] + i - start[i] + 1;
        }
        let diag_from = (0..n).map(|i| system.at(i, i) as u32).collect();
        let (mut col, mut entries, mut rows) = (vec![0; n + 1], Vec::new(), Vec::new());
        for k in 0..n {
            col[k] = entries.len();
            for i in k + 1..n {
                if start[i] <= k {
                    let from = start[i].max(start[k]);
                    entries.push(Entry { at: (off[i] + k - start[i]) as u32, from: system.at(i, k) as u32, a: (off[i] + from - start[i]) as u32, b: (off[k] + from - start[k]) as u32, len: (k - from) as u32 });
                    rows.push(i as u32);
                }
            }
        }
        col[n] = entries.len();
        EnvelopeCholesky { n, factor: vec![0.0; off[n]], start, off, diag_from, col, entries, rows, y: vec![0.0; n], negative_pivots: 0 }
    }

    /// The factor's entries below the diagonal (its fill and the pattern's).
    pub fn len(&self) -> usize {
        self.off[self.n] - self.n
    }

    /// The system solved, its matrix negated as 2.4 negates it: `x` its currents.
    pub fn solve(&mut self, system: &System, x: &mut [f64]) {
        let n = self.n;
        let (values, rhs) = (&system.values, &system.rhs);
        let (f, y) = (&mut self.factor, &mut self.y);
        for k in 0..n {
            let (sk, ok) = (self.start[k], self.off[k]);
            let w = k - sk;
            // Its pivot.
            let mut d = -values[self.diag_from[k] as usize];
            for &v in &f[ok..ok + w] {
                d -= v * v;
            }
            // (2.4: a pivot under zero made zero.)
            if d < 0.0 {
                d = 0.0;
                self.negative_pivots += 1;
            }
            d = d.sqrt();
            f[ok + w] = d;
            // Its row of the forward substitution.
            let mut sum = -rhs[k];
            for (a, b) in f[ok..ok + w].iter().zip(&y[sk..k]) {
                sum -= a * b;
            }
            y[k] = sum / d;
            // Its column below.
            for e in &self.entries[self.col[k]..self.col[k + 1]] {
                let mut sum = -values[e.from as usize];
                let (a, b, len) = (e.a as usize, e.b as usize, e.len as usize);
                for (p, q) in f[a..a + len].iter().zip(&f[b..b + len]) {
                    sum -= p * q;
                }
                f[e.at as usize] = sum / d;
            }
        }
        for k in (0..n).rev() {
            let mut sum = y[k];
            for (e, &i) in self.entries[self.col[k]..self.col[k + 1]].iter().zip(&self.rows[self.col[k]..self.col[k + 1]]) {
                sum -= f[e.at as usize] * x[i as usize];
            }
            x[k] = sum / f[self.off[k + 1] - 1];
        }
    }
}

/// The tube's own order (research/VOCAL_TRACT_REALTIME_PLAN.md, 1): the same matrix, the same Cholesky, its currents
/// eliminated from the branches' ends inward -- the trachea from the lungs up, the fossae from their closed end, the
/// sinuses, the radiation, the nose from the nostrils, the mouth from the lips -- to meet near the pharynx. The coupling
/// is a tree of cliques, so an order that takes each current once its remaining neighbours are coupled to one another
/// fills in nothing: the factor keeps the matrix's pattern, each sum a few products where 2.4's run to 65, and the chains
/// of the three branches are independent until they meet. The order is the program's: for every current as the root,
/// the currents farthest from it first (so that the branches' chains interleave for the processor), kept where it fills
/// in nothing, the root whose longest chain of pivots is shortest chosen. In exact arithmetic its solution is 2.4's; in
/// floating point each rounds otherwise, so it is a new numerical method for the same equations, to be measured against
/// a solution more accurate than either (examples/v24_solve_accuracy.rs) before it is anyone's default.
#[derive(Clone)]
pub struct TreeCholesky {
    n: usize,
    /// The currents in the order eliminated, and each current's place in it.
    pub order: Vec<usize>,
    place: Vec<usize>,
    /// The longest chain of pivots each waiting on the last.
    pub height: usize,
    /// Each pivot's diagonal's slot.
    diag_from: Vec<u32>,
    /// Each pivot's row: its factor's entries to the left (row[row_ptr[t]..row_ptr[t + 1]]) and their columns.
    row_ptr: Vec<usize>,
    row: Vec<u32>,
    row_col: Vec<u32>,
    /// Each pivot's column below: its entries (below[below_ptr[t]..below_ptr[t + 1]], their rows ascending), each its
    /// products' pairs of factor entries (pairs[p0..p1]).
    below_ptr: Vec<usize>,
    below: Vec<TreeEntry>,
    below_row: Vec<u32>,
    pairs: Vec<(u32, u32)>,
    factor: Vec<f64>,
    diag: Vec<f64>,
    y: Vec<f64>,
    x: Vec<f64>,
    /// Pivots found below zero and made zero (as 2.4 makes them), since it was made.
    pub negative_pivots: u64,
}

#[derive(Clone, Copy, Debug)]
struct TreeEntry {
    at: u32,
    from: u32,
    p0: u32,
    p1: u32,
}

impl TreeCholesky {
    pub fn new(system: &System) -> TreeCholesky {
        let n = system.n;
        let mut coupled = vec![false; n * n];
        let mut neighbours = vec![Vec::new(); n];
        for &(i, j) in &system.pairs {
            if i != j {
                coupled[i * n + j] = true;
                coupled[j * n + i] = true;
                neighbours[i].push(j);
                neighbours[j].push(i);
            }
        }
        // For each root: its order, the farthest first; kept where every current's later neighbours are coupled to one
        // another (nothing filled in); the longest chain of pivots.
        let mut best: Option<(usize, Vec<usize>)> = None;
        for root in 0..n {
            let mut distance = vec![usize::MAX; n];
            distance[root] = 0;
            let mut queue = std::collections::VecDeque::from([root]);
            while let Some(v) = queue.pop_front() {
                for &w in &neighbours[v] {
                    if distance[w] == usize::MAX {
                        distance[w] = distance[v] + 1;
                        queue.push_back(w);
                    }
                }
            }
            if distance.contains(&usize::MAX) {
                continue;
            }
            let mut order: Vec<usize> = (0..n).collect();
            order.sort_by_key(|&v| (std::cmp::Reverse(distance[v]), v));
            let mut place = vec![0; n];
            for (t, &v) in order.iter().enumerate() {
                place[v] = t;
            }
            let mut chain = vec![0; n];
            let mut fills = false;
            for &v in &order {
                let later: Vec<usize> = neighbours[v].iter().copied().filter(|&w| place[w] > place[v]).collect();
                fills |= later.iter().any(|&a| later.iter().any(|&b| a != b && !coupled[a * n + b]));
                chain[v] = 1 + neighbours[v].iter().filter(|&&w| place[w] < place[v]).map(|&w| chain[w]).max().unwrap_or(0);
            }
            let height = chain.iter().copied().max().unwrap_or(0);
            if !fills && best.as_ref().map_or(true, |(h, _)| height < *h) {
                best = Some((height, order));
            }
        }
        let (height, order) = best.expect("an order of the tube's currents that fills in nothing");
        let mut place = vec![0; n];
        for (t, &v) in order.iter().enumerate() {
            place[v] = t;
        }
        // Each coupled pair's entry in the factor, row the later pivot.
        let mut entry = vec![u32::MAX; n * n];
        let mut count = 0u32;
        for t in 0..n {
            let mut left: Vec<usize> = neighbours[order[t]].iter().map(|&w| place[w]).filter(|&s| s < t).collect();
            left.sort();
            for s in left {
                entry[t * n + s] = count;
                count += 1;
            }
        }
        let lower = |a: usize, b: usize| system.at(a.max(b), a.min(b)) as u32;
        let (mut row_ptr, mut row, mut row_col) = (vec![0; n + 1], Vec::new(), Vec::new());
        let (mut below_ptr, mut below, mut below_row, mut pairs) = (vec![0; n + 1], Vec::new(), Vec::new(), Vec::new());
        let left_of = |t: usize| -> Vec<usize> { (0..t).filter(|&s| entry[t * n + s] != u32::MAX).collect() };
        for t in 0..n {
            row_ptr[t] = row.len();
            for s in left_of(t) {
                row.push(entry[t * n + s]);
                row_col.push(s as u32);
            }
            below_ptr[t] = below.len();
            for u in t + 1..n {
                if entry[u * n + t] != u32::MAX {
                    let p0 = pairs.len() as u32;
                    for s in left_of(t) {
                        if entry[u * n + s] != u32::MAX {
                            pairs.push((entry[u * n + s], entry[t * n + s]));
                        }
                    }
                    below.push(TreeEntry { at: entry[u * n + t], from: lower(order[u], order[t]), p0, p1: pairs.len() as u32 });
                    below_row.push(u as u32);
                }
            }
        }
        row_ptr[n] = row.len();
        below_ptr[n] = below.len();
        let diag_from = order.iter().map(|&v| system.at(v, v) as u32).collect();
        TreeCholesky { n, order, place, height, diag_from, row_ptr, row, row_col, below_ptr, below, below_row, pairs, factor: vec![0.0; count as usize], diag: vec![0.0; n], y: vec![0.0; n], x: vec![0.0; n], negative_pivots: 0 }
    }

    /// The factor's entries below the diagonal (the matrix's pattern's: nothing filled in).
    pub fn len(&self) -> usize {
        self.factor.len()
    }

    /// The products the factorization takes (its pivots' and its entries').
    pub fn updates(&self) -> usize {
        self.row.len() + self.pairs.len()
    }

    /// The system solved, its matrix negated as 2.4 negates it: `x` its currents, in 2.4's numbering.
    pub fn solve(&mut self, system: &System, x: &mut [f64]) {
        let (values, rhs) = (&system.values, &system.rhs);
        let (f, y) = (&mut self.factor, &mut self.y);
        for t in 0..self.n {
            let (r0, r1) = (self.row_ptr[t], self.row_ptr[t + 1]);
            let mut d = -values[self.diag_from[t] as usize];
            for &e in &self.row[r0..r1] {
                let v = f[e as usize];
                d -= v * v;
            }
            if d < 0.0 {
                d = 0.0;
                self.negative_pivots += 1;
            }
            d = d.sqrt();
            self.diag[t] = d;
            let mut sum = -rhs[self.order[t]];
            for (&e, &s) in self.row[r0..r1].iter().zip(&self.row_col[r0..r1]) {
                sum -= f[e as usize] * y[s as usize];
            }
            y[t] = sum / d;
            for e in &self.below[self.below_ptr[t]..self.below_ptr[t + 1]] {
                let mut sum = -values[e.from as usize];
                for &(a, b) in &self.pairs[e.p0 as usize..e.p1 as usize] {
                    sum -= f[a as usize] * f[b as usize];
                }
                f[e.at as usize] = sum / d;
            }
        }
        let xp = &mut self.x;
        for t in (0..self.n).rev() {
            let mut sum = y[t];
            let (b0, b1) = (self.below_ptr[t], self.below_ptr[t + 1]);
            for (e, &u) in self.below[b0..b1].iter().zip(&self.below_row[b0..b1]) {
                sum -= f[e.at as usize] * xp[u as usize];
            }
            xp[t] = sum / self.diag[t];
            x[self.order[t]] = xp[t];
        }
    }

    /// The system solved in double-double arithmetic (some 32 digits), the factorization in this order and its solution
    /// refined three times against the residual in double-double: a solution of the same system far more accurate than
    /// either order's in double precision -- the truth they are measured against (VOCAL_TRACT_REALTIME_PLAN, 1). For
    /// measurement only, some twenty times slower. `x` its currents rounded to double; the whole of them in `full`.
    pub fn solve_reference(&self, system: &System, x: &mut [f64], full: &mut [Dd]) -> u64 {
        let n = self.n;
        let lower = |a: usize, b: usize| Dd::from(system.get(a, b));
        let mut factor = vec![Dd::ZERO; self.factor.len()];
        let mut diag = vec![Dd::ZERO; n];
        let mut negative = 0;
        for t in 0..n {
            let (r0, r1) = (self.row_ptr[t], self.row_ptr[t + 1]);
            let mut d = -lower(self.order[t], self.order[t]);
            for &e in &self.row[r0..r1] {
                d = d - factor[e as usize] * factor[e as usize];
            }
            if d.hi < 0.0 {
                d = Dd::ZERO;
                negative += 1;
            }
            diag[t] = d.sqrt();
            for (e, &u) in self.below[self.below_ptr[t]..self.below_ptr[t + 1]].iter().zip(&self.below_row[self.below_ptr[t]..self.below_ptr[t + 1]]) {
                let mut sum = -lower(self.order[u as usize], self.order[t]);
                for &(a, b) in &self.pairs[e.p0 as usize..e.p1 as usize] {
                    sum = sum - factor[a as usize] * factor[b as usize];
                }
                factor[e.at as usize] = sum / diag[t];
            }
        }
        // (-A) z = -r by the factor, in this order's places.
        let solve = |r: &[Dd]| -> Vec<Dd> {
            let mut y = vec![Dd::ZERO; n];
            for t in 0..n {
                let mut sum = -r[self.order[t]];
                for (&e, &s) in self.row[self.row_ptr[t]..self.row_ptr[t + 1]].iter().zip(&self.row_col[self.row_ptr[t]..self.row_ptr[t + 1]]) {
                    sum = sum - factor[e as usize] * y[s as usize];
                }
                y[t] = sum / diag[t];
            }
            let mut z = vec![Dd::ZERO; n];
            for t in (0..n).rev() {
                let mut sum = y[t];
                let (b0, b1) = (self.below_ptr[t], self.below_ptr[t + 1]);
                for (e, &u) in self.below[b0..b1].iter().zip(&self.below_row[b0..b1]) {
                    sum = sum - factor[e.at as usize] * z[u as usize];
                }
                z[t] = sum / diag[t];
            }
            let mut out = vec![Dd::ZERO; n];
            for t in 0..n {
                out[self.order[t]] = z[t];
            }
            out
        };
        let b: Vec<Dd> = system.rhs.iter().map(|&v| Dd::from(v)).collect();
        let mut solution = solve(&b);
        for _ in 0..3 {
            let mut r = b.clone();
            for &(i, j) in &system.pairs {
                let a = Dd::from(system.get(i, j));
                r[i] = r[i] - a * solution[j];
                if i != j {
                    r[j] = r[j] - a * solution[i];
                }
            }
            let dz = solve(&r);
            for (s, d) in solution.iter_mut().zip(&dz) {
                *s = *s + *d;
            }
        }
        for i in 0..n {
            x[i] = solution[i].hi;
            full[i] = solution[i];
        }
        negative
    }

    /// Where current i is eliminated.
    pub fn place(&self, i: usize) -> usize {
        self.place[i]
    }
}

/// A double-double number: hi + lo, |lo| at most half an ulp of hi (Dekker 1971; Bailey's QD library's algorithms),
/// every product split by Veltkamp's constant rather than fused: some 32 significant digits.
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct Dd {
    pub hi: f64,
    pub lo: f64,
}

impl Dd {
    pub const ZERO: Dd = Dd { hi: 0.0, lo: 0.0 };

    fn two_sum(a: f64, b: f64) -> Dd {
        let s = a + b;
        let bb = s - a;
        Dd { hi: s, lo: (a - (s - bb)) + (b - bb) }
    }

    fn quick_two_sum(a: f64, b: f64) -> Dd {
        let s = a + b;
        Dd { hi: s, lo: b - (s - a) }
    }

    fn split(a: f64) -> (f64, f64) {
        let t = 134217729.0 * a;
        let hi = t - (t - a);
        (hi, a - hi)
    }

    fn two_prod(a: f64, b: f64) -> Dd {
        let p = a * b;
        let (ah, al) = Dd::split(a);
        let (bh, bl) = Dd::split(b);
        Dd { hi: p, lo: ((ah * bh - p) + ah * bl + al * bh) + al * bl }
    }

    pub fn sqrt(self) -> Dd {
        if self.hi <= 0.0 {
            return Dd::ZERO;
        }
        let x = 1.0 / self.hi.sqrt();
        let ax = self.hi * x;
        let r = self - Dd::two_prod(ax, ax);
        Dd::two_sum(ax, r.hi * x * 0.5)
    }

    pub fn to_f64(self) -> f64 {
        self.hi + self.lo
    }
}

impl From<f64> for Dd {
    fn from(v: f64) -> Dd {
        Dd { hi: v, lo: 0.0 }
    }
}

impl std::ops::Neg for Dd {
    type Output = Dd;
    fn neg(self) -> Dd {
        Dd { hi: -self.hi, lo: -self.lo }
    }
}

impl std::ops::Add for Dd {
    type Output = Dd;
    fn add(self, b: Dd) -> Dd {
        let s = Dd::two_sum(self.hi, b.hi);
        let t = Dd::two_sum(self.lo, b.lo);
        let u = Dd::quick_two_sum(s.hi, s.lo + t.hi);
        Dd::quick_two_sum(u.hi, u.lo + t.lo)
    }
}

impl std::ops::Sub for Dd {
    type Output = Dd;
    fn sub(self, b: Dd) -> Dd {
        self + -b
    }
}

impl std::ops::Mul for Dd {
    type Output = Dd;
    fn mul(self, b: Dd) -> Dd {
        let p = Dd::two_prod(self.hi, b.hi);
        Dd::quick_two_sum(p.hi, p.lo + (self.hi * b.lo + self.lo * b.hi))
    }
}

impl std::ops::Div for Dd {
    type Output = Dd;
    fn div(self, b: Dd) -> Dd {
        let q1 = self.hi / b.hi;
        let r = self - b * Dd::from(q1);
        let q2 = r.hi / b.hi;
        let r = r - b * Dd::from(q2);
        let q3 = r.hi / b.hi;
        let q = Dd::quick_two_sum(q1, q2);
        q + Dd::from(q3)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// A small tree of cliques: a path with a branch and a clique of three at its end.
    fn toy() -> System {
        let n = 7;
        let mut p = vec![false; n * n];
        for (a, b) in [(0, 1), (1, 2), (2, 3), (3, 4), (2, 5), (3, 5), (4, 6)] {
            p[a * n + b] = true;
            p[b * n + a] = true;
        }
        for i in 0..n {
            p[i * n + i] = true;
        }
        let mut s = System::new(n, &p);
        // (Negative definite, as the tube's is: its diagonal dominant.)
        for k in 0..s.pairs.len() {
            let (i, j) = s.pairs[k];
            s.values[k] = if i == j { -4.0 - i as f64 * 0.37 } else { 0.5 + 0.11 * (i + j) as f64 };
        }
        for i in 0..n {
            s.rhs[i] = (i as f64 * 0.7).sin();
        }
        s
    }

    #[test]
    fn the_orders_agree_with_the_reference_and_the_tree_fills_nothing() {
        let s = toy();
        let n = s.n;
        let (mut a, mut b, mut c) = (vec![0.0; n], vec![0.0; n], vec![0.0; n]);
        let mut full = vec![Dd::ZERO; n];
        EnvelopeCholesky::new(&s).solve(&s, &mut a);
        let mut tree = TreeCholesky::new(&s);
        tree.solve(&s, &mut b);
        tree.solve_reference(&s, &mut c, &mut full);
        assert_eq!(tree.len(), s.pairs.iter().filter(|(i, j)| i != j).count(), "the tree's order fills in nothing");
        for i in 0..n {
            assert!((a[i] - c[i]).abs() < 1e-14 * c[i].abs().max(1.0), "{i}: {} {}", a[i], c[i]);
            assert!((b[i] - c[i]).abs() < 1e-14 * c[i].abs().max(1.0), "{i}: {} {}", b[i], c[i]);
            // The residual of the reference, in double-double, far under double's.
            let mut r = Dd::from(s.rhs[i]);
            for j in 0..n {
                r = r - Dd::from(s.get(i, j)) * full[j];
            }
            assert!(r.to_f64().abs() < 1e-28, "{i}: residual {}", r.to_f64());
        }
    }

    #[test]
    fn double_double_carries_thirty_digits() {
        let third = Dd::from(1.0) / Dd::from(3.0);
        let back = third * Dd::from(3.0) - Dd::from(1.0);
        assert!(back.to_f64().abs() < 1e-31);
        let two = Dd::from(2.0).sqrt();
        assert!((two * two - Dd::from(2.0)).to_f64().abs() < 1e-31);
    }
}
