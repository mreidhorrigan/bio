// VocalTractLab 2.4 across cores (research/VOCAL_TRACT_REALTIME_PLAN.md, stage 2): what a step takes from its frames
// alone -- each frame's geometry (on the geometry pool's workers, src/live.rs), then each step's tube interpolated, its
// areas slowed near closure, its sections' coefficients and its constrictions' geometry, and its glottis's parameters
// (synth::Stepper) -- made ahead on a thread of its own, while the acoustics' thread takes each step's record and does
// what follows the last step. The front's thread owns the pool and the stepper: the acoustics' thread sends it frames
// (their parameters, in a bounded channel, nothing allocated) and takes records from a ring preallocated between the
// two (one writer, one reader; no lock). Its stepper is the synthesizer's own as it stands, so the records are the ones
// the synthesizer would make itself, and the sound is its sequential sound to the bit (examples/v24_bench.rs `pool`
// holds it to that). The front's thread parks when the ring is full and is woken when it has drained by half; the
// acoustics' thread, finding it empty, spins a little and then parks until a record comes.
use super::synth::{StepRecord, Stepper, Synthesizer, NUM_CHUNK_SAMPLES};
use super::tract::{TractTube, VocalTract, NUM_PARAMS};
use super::glottis::NUM_CONTROL_PARAMS;
use super::tube::Tube;
use crate::live::GeometryPool;
use std::cell::UnsafeCell;
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use std::sync::mpsc::{sync_channel, Receiver, SyncSender};
use std::sync::{Arc, Mutex};
use std::thread::{JoinHandle, Thread};

/// Records the ring holds: some 900 kB, within a cluster's shared cache.
const CAPACITY: usize = 128;

/// Where the acoustics take each step's record from.
pub trait Records {
    fn next(&mut self) -> &StepRecord;
}

struct Ring {
    slots: Box<[UnsafeCell<StepRecord>]>,
    /// Records written, and records the reader is done with.
    head: AtomicUsize,
    tail: AtomicUsize,
    closed: AtomicBool,
    writer_parked: AtomicBool,
    reader_parked: AtomicBool,
    reader: Mutex<Option<Thread>>,
}

// SAFETY: a slot is written by the one writer only while it lies outside [tail, head) and read by the one reader only
// while inside it; head is stored (Release) after the slot is written and loaded (Acquire) before it is read, tail
// stored after the reader is done with it and loaded before it is written again.
unsafe impl Sync for Ring {}

struct Frame {
    tract: [f64; NUM_PARAMS],
    glottis: [f64; NUM_CONTROL_PARAMS],
    samples: usize,
}

/// The front's thread and the ring.
pub struct Pipeline {
    frames: Option<SyncSender<Frame>>,
    /// Each frame's tube as the front's thread makes it (none kept where the reader has not taken the last 64).
    heard: Receiver<TractTube>,
    ring: Arc<Ring>,
    writer: Option<JoinHandle<()>>,
    /// Records taken, and whether the last is still held.
    taken: usize,
    holding: bool,
}

impl Pipeline {
    /// For `synth` as it stands (its stepper cloned: reset it first), its geometry on `workers` threads up to `lookahead`
    /// frames ahead.
    pub fn new(tract: &VocalTract, synth: &Synthesizer, workers: usize, lookahead: usize) -> Pipeline {
        let ring = Arc::new(Ring {
            slots: (0..CAPACITY).map(|_| UnsafeCell::new(StepRecord::default())).collect(),
            head: AtomicUsize::new(0),
            tail: AtomicUsize::new(0),
            closed: AtomicBool::new(false),
            writer_parked: AtomicBool::new(false),
            reader_parked: AtomicBool::new(false),
            reader: Mutex::new(None),
        });
        let (tx, rx) = sync_channel::<Frame>(lookahead.max(1) + 1);
        let (heard_tx, heard) = sync_channel::<TractTube>(64);
        let mut stepper = synth.stepper.clone();
        let over = synth.oversampling();
        let (tract, shared) = (tract.clone(), ring.clone());
        let writer = std::thread::Builder::new()
            .name("vocal-tract-front".into())
            .spawn(move || front(rx, heard_tx, &tract, &mut stepper, over, &shared, workers, lookahead))
            .expect("the front's thread");
        Pipeline { frames: Some(tx), heard, ring, writer: Some(writer), taken: 0, holding: false }
    }

    /// The tube of the latest frame the front's thread has made (up to `lookahead` frames ahead of what is heard), if
    /// it has made one since this was last asked.
    pub fn heard(&mut self) -> Option<TractTube> {
        let mut last = None;
        while let Ok(t) = self.heard.try_recv() {
            last = Some(t);
        }
        last
    }

    /// A frame to come: its tract's and glottis's parameters and the samples it fills (none for the first, which only
    /// sets where the synthesis starts). Waits only where `lookahead` frames are already waiting.
    pub fn send(&mut self, tract: &[f64], glottis: &[f64], samples: usize) {
        let mut f = Frame { tract: [0.0; NUM_PARAMS], glottis: [0.0; NUM_CONTROL_PARAMS], samples };
        f.tract.copy_from_slice(&tract[..NUM_PARAMS]);
        f.glottis.copy_from_slice(&glottis[..NUM_CONTROL_PARAMS]);
        self.frames.as_ref().expect("open").send(f).expect("the front's thread");
    }

    fn release(&mut self) {
        if self.holding {
            self.taken += 1;
            self.ring.tail.store(self.taken, Ordering::Release);
            self.holding = false;
            // (The writer woken once the ring has drained by half.)
            if self.ring.head.load(Ordering::Acquire) - self.taken <= CAPACITY / 2 && self.ring.writer_parked.swap(false, Ordering::AcqRel) {
                if let Some(w) = &self.writer {
                    w.thread().unpark();
                }
            }
        }
    }
}

impl Records for Pipeline {
    fn next(&mut self) -> &StepRecord {
        self.release();
        let mut spins = 0u32;
        while self.ring.head.load(Ordering::Acquire) == self.taken {
            if spins < 4000 {
                spins += 1;
                std::hint::spin_loop();
                continue;
            }
            *self.ring.reader.lock().unwrap() = Some(std::thread::current());
            self.ring.reader_parked.store(true, Ordering::SeqCst);
            if self.ring.head.load(Ordering::SeqCst) == self.taken {
                std::thread::park_timeout(std::time::Duration::from_millis(5));
            }
            self.ring.reader_parked.store(false, Ordering::SeqCst);
        }
        self.holding = true;
        // SAFETY: the slot lies inside [tail, head): written and published, not to be written again until released.
        unsafe { &*self.ring.slots[self.taken % CAPACITY].get() }
    }
}

impl Drop for Pipeline {
    fn drop(&mut self) {
        self.ring.closed.store(true, Ordering::SeqCst);
        self.frames = None;
        if let Some(w) = self.writer.take() {
            w.thread().unpark();
            let _ = w.join();
        }
    }
}

/// The front's thread: frames taken as they come, their geometry asked of the pool as far ahead as allowed, each frame's
/// steps made into the ring in order.
#[allow(clippy::too_many_arguments)]
fn front(rx: Receiver<Frame>, heard: SyncSender<TractTube>, tract: &VocalTract, stepper: &mut Stepper, over: usize, ring: &Ring, workers: usize, lookahead: usize) {
    let mut pool = GeometryPool::new(tract, workers);
    let mut waiting: std::collections::VecDeque<Frame> = std::collections::VecDeque::with_capacity(lookahead + 2);
    let mut head = 0usize;
    let mut tube = Tube::new();
    loop {
        // Every frame sent so far asked for, as far ahead as allowed; one waited for where none is waiting (and none
        // left when the sender is gone).
        while waiting.len() < lookahead.max(1) + 1 {
            let got = if waiting.is_empty() { rx.recv().ok() } else { rx.try_recv().ok() };
            let Some(f) = got else { break };
            pool.submit(&f.tract);
            waiting.push_back(f);
        }
        let Some(f) = waiting.pop_front() else { return };
        let geometry = pool.next(true).expect("a frame's geometry");
        tube.set_from_tract(&geometry);
        let _ = heard.try_send(geometry);
        if stepper.start(&tube, &f.glottis) || f.samples == 0 {
            continue;
        }
        let count = f.samples * over;
        for index in 0..count {
            // (Room in the ring, or parked until the reader has drained it by half.)
            while head - ring.tail.load(Ordering::Acquire) == CAPACITY {
                if ring.closed.load(Ordering::SeqCst) {
                    return;
                }
                ring.writer_parked.store(true, Ordering::SeqCst);
                if head - ring.tail.load(Ordering::SeqCst) == CAPACITY {
                    std::thread::park_timeout(std::time::Duration::from_millis(5));
                }
            }
            // SAFETY: the slot lies outside [tail, head): the reader is done with it.
            let slot = unsafe { &mut *ring.slots[head % CAPACITY].get() };
            stepper.step(index, count, &tube, &f.glottis, slot);
            head += 1;
            ring.head.store(head, Ordering::Release);
            if ring.reader_parked.load(Ordering::SeqCst) {
                if let Some(r) = ring.reader.lock().unwrap().as_ref() {
                    r.unpark();
                }
            }
        }
        stepper.finish(&tube, &f.glottis);
        if ring.closed.load(Ordering::SeqCst) {
            return;
        }
    }
}

/// A whole passage (each frame its tract's and glottis's parameters, 120 samples apart) synthesized across cores: its
/// geometry on `workers` threads up to `lookahead` frames ahead, its frames' part of each step on the front's thread, its
/// acoustics on this one. The sequential synthesis's sound (Synthesizer::add_tract a frame at a time), to the bit.
pub fn render(tract: &VocalTract, synth: &mut Synthesizer, frames: &[(Vec<f64>, Vec<f64>)], workers: usize, lookahead: usize) -> Vec<f64> {
    synth.reset();
    let mut pipeline = Pipeline::new(tract, synth, workers, lookahead);
    let mut out = vec![0.0; frames.len().saturating_sub(1) * NUM_CHUNK_SAMPLES];
    let mut sent = 0;
    for f in 0..frames.len() {
        while sent < frames.len() && sent <= f + lookahead {
            pipeline.send(&frames[sent].0, &frames[sent].1, if sent == 0 { 0 } else { NUM_CHUNK_SAMPLES });
            sent += 1;
        }
        if f > 0 {
            synth.add_records(&mut out[(f - 1) * NUM_CHUNK_SAMPLES..f * NUM_CHUNK_SAMPLES], &mut pipeline);
        }
    }
    out
}
