// VocalTractLab 2.4's gestural score (its GesturalScore.cpp): 2.3's (src/gestural.rs), its tiers and the fifth-order
// approach to their targets, with what 2.4 changed. Its tiers' ranges: a vowel's time constant 8 to 20 ms, the velic
// tier in cm^2 (to 1.5) from 5 ms, F0's slopes to 200 st/s, 10 ms the default time constant. A gesture put into a tier
// is held to the tier's ranges and a remnant under a millisecond joins its neighbour (putGesture, limitGestureParams).
// The tract's targets: a consonantal tier's neutral gesture after an active one is a release ("RET"), whose time
// constant takes over; the active consonants' shapes are averaged, then the tongue body's, the tip's and the lips' each
// given what it moves, in that order, its time constant all the tract's; the velic opening's own. A target slower than
// the one before it is entered with the curve's derivatives scaled down by the ratio of their time constants. The
// curves are 60 s at most. Synthesized as 2.3's are, read every 120 samples at 48 kHz (Synthesizer::
// synthesizeGesturalScore). Scores read from .ges files, the tiers a file leaves out the test score's, as 2.4's API
// reads them.
use crate::gestural::{context_dependent_consonant, f0_hz, f0_st, limit_vowel_subspace_coord, map_to_vowel_subspace, parse_tiers, tiers_xml, Gesture, GestureSequence, Target};
pub use crate::gestural::{F0, GLOTTAL_SHAPE, LIP, LUNG_PRESSURE, NUM_GESTURE_TYPES, TONGUE_BODY, TONGUE_TIP, VELIC, VOWEL};
use crate::v24::constants::AUDIO_SAMPLING_RATE_HZ;
use crate::v24::glottis::{Glottis2025, FREQUENCY, PRESSURE};
use crate::v24::tract::*;

pub const DEFAULT_TIME_CONSTANT_S: f64 = 0.010;
pub const VELIC_OPENING_TIME_CONSTANT_S: f64 = 0.012;
pub const VELIC_CLOSING_TIME_CONSTANT_S: f64 = 0.010;
pub const CURVE_SAMPLING_RATE: i32 = 400;
pub const MAX_CURVE_SAMPLES: usize = CURVE_SAMPLING_RATE as usize * 60;
pub const MIN_GESTURE_DURATION_S: f64 = 1.0 / 1000.0;
pub const MAX_GESTURE_DURATION_S: f64 = 3600000.0 / 1000.0;
/// The synthesizer's chunk: the curves are read every 120 samples (2.5 ms).
pub const NUM_CHUNK_SAMPLES: usize = 120;
const MAX_SLICES: usize = 1024;

/// The parameter curves at 400 Hz: the tract's 19 and the glottis's (F0 in Hz).
pub struct Curves {
    pub tract: Vec<Vec<f64>>,
    pub glottis: Vec<Vec<f64>>,
}

#[derive(Clone, Debug)]
pub struct GesturalScore {
    pub seq: Vec<GestureSequence>,
}

impl Default for GesturalScore {
    fn default() -> Self {
        GesturalScore::new()
    }
}

fn sequence(abbr: &'static str, unit: &'static str, min: f64, max: f64, min_slope: f64, max_slope: f64, min_tau: f64, max_tau: f64, nominal: bool) -> GestureSequence {
    GestureSequence { abbr, unit, min_value: min, max_value: max, min_slope, max_slope, min_tau_s: min_tau, max_tau_s: max_tau, nominal, gestures: Vec::new() }
}

fn gesture(duration_s: f64, d_val: f64, s_val: &str, tau_s: f64) -> Gesture {
    Gesture { duration_s, d_val, slope: 0.0, s_val: s_val.to_string(), tau_s, neutral: false }
}

/// A gesture held to its tier's ranges (GestureSequence::limitGestureParams).
pub fn limit(seq: &GestureSequence, g: &mut Gesture) {
    if g.duration_s < MIN_GESTURE_DURATION_S {
        g.duration_s = MIN_GESTURE_DURATION_S;
    }
    if g.duration_s > MAX_GESTURE_DURATION_S {
        g.duration_s = MAX_GESTURE_DURATION_S;
    }
    if g.d_val < seq.min_value {
        g.d_val = seq.min_value;
    }
    if g.d_val > seq.max_value {
        g.d_val = seq.max_value;
    }
    if g.slope < seq.min_slope {
        g.slope = seq.min_slope;
    }
    if g.slope > seq.max_slope {
        g.slope = seq.max_slope;
    }
    if g.tau_s < seq.min_tau_s {
        g.tau_s = seq.min_tau_s;
    }
    if g.tau_s > seq.max_tau_s {
        g.tau_s = seq.max_tau_s;
    }
}

/// Puts g at start_s, cutting or dropping what lies under it; its index (GestureSequence::putGesture).
pub fn put(seq: &mut GestureSequence, mut g: Gesture, start_s: f64) -> usize {
    limit(seq, &mut g);
    let end_s = start_s + g.duration_s;
    let mut index: i64 = 0;
    let (mut left, mut right): (i64, i64) = (-1, -1);
    let (mut left_start, mut right_start) = (0.0, 0.0);
    let mut pos = 0.0;
    for (i, x) in seq.gestures.iter().enumerate() {
        if start_s >= pos && start_s <= pos + x.duration_s {
            left = i as i64;
            left_start = pos;
        }
        if end_s >= pos && end_s <= pos + x.duration_s {
            right = i as i64;
            right_start = pos;
        }
        pos += x.duration_s;
    }
    let total = pos;
    if left == -1 && right == -1 {
        let empty = start_s - total;
        if empty > MIN_GESTURE_DURATION_S {
            seq.gestures.push(Gesture { duration_s: empty, d_val: 0.0, slope: 0.0, s_val: String::new(), neutral: true, tau_s: DEFAULT_TIME_CONSTANT_S });
        } else {
            g.duration_s += empty;
        }
        seq.gestures.push(g);
        index = seq.gestures.len() as i64 - 1;
    } else if left != -1 {
        let left = left as usize;
        let mut new: Vec<Gesture> = seq.gestures[..left].to_vec();
        let mut part = seq.gestures[left].clone();
        part.duration_s = start_s - left_start;
        if part.duration_s >= MIN_GESTURE_DURATION_S {
            new.push(part);
        } else {
            g.duration_s += part.duration_s;
        }
        new.push(g);
        index = new.len() as i64 - 1;
        if right != -1 {
            let right = right as usize;
            let mut part = seq.gestures[right].clone();
            part.duration_s = right_start + seq.gestures[right].duration_s - end_s;
            if part.duration_s < MIN_GESTURE_DURATION_S {
                new.last_mut().unwrap().duration_s += part.duration_s;
            } else {
                new.push(part);
            }
            new.extend_from_slice(&seq.gestures[right + 1..]);
        }
        seq.gestures = new;
    }
    if index >= seq.gestures.len() as i64 {
        index = seq.gestures.len() as i64 - 1;
    }
    index.max(0) as usize
}

impl GesturalScore {
    /// An empty score, its tiers' ranges as 2.4's.
    pub fn new() -> GesturalScore {
        GesturalScore {
            seq: vec![
                sequence("vowel-gestures", "", 0.0, 0.0, 0.0, 0.0, 0.008, 0.020, true),
                sequence("lip-gestures", "", 0.0, 0.0, 0.0, 0.0, 0.005, 0.04, true),
                sequence("tongue-tip-gestures", "", 0.0, 0.0, 0.0, 0.0, 0.005, 0.04, true),
                sequence("tongue-body-gestures", "", 0.0, 0.0, 0.0, 0.0, 0.005, 0.04, true),
                sequence("velic-gestures", "cm^2", -0.1, 1.5, 0.0, 0.0, 0.005, 0.04, false),
                sequence("glottal-shape-gestures", "", 0.0, 0.0, 0.0, 0.0, 0.01, 0.04, true),
                sequence("f0-gestures", "st", 48.0, 108.0, -200.0, 200.0, 0.005, 0.04, false),
                sequence("lung-pressure-gestures", "dPa", 0.0, 16000.0, 0.0, 0.0, 0.005, 0.04, false),
            ],
        }
    }

    /// The score 2.4 makes before it reads one (initTestScore): /a/ for 0.6 s, modal, F0 80, 83 and 78 st, 800 Pa.
    pub fn test() -> GesturalScore {
        let mut s = GesturalScore::new();
        s.seq[VOWEL].gestures.push(gesture(0.6, 0.0, "a", DEFAULT_TIME_CONSTANT_S));
        for (d, v) in [(0.01, 80.0), (0.3, 83.0), (0.3, 78.0)] {
            s.seq[F0].gestures.push(gesture(d, v, "", 0.03));
        }
        for (d, v) in [(0.01, 0.0), (0.5, 8000.0), (0.1, 0.0)] {
            s.seq[LUNG_PRESSURE].gestures.push(gesture(d, v, "", 0.005));
        }
        s.seq[GLOTTAL_SHAPE].gestures.push(gesture(0.6, 0.0, "modal", DEFAULT_TIME_CONSTANT_S));
        s
    }

    /// A .ges file's score, and whether every value was in its range; a tier it leaves out the test score's, as the
    /// API's new score keeps it.
    pub fn parse(text: &str) -> Result<(GesturalScore, bool), String> {
        let mut score = GesturalScore::test();
        let in_range = parse_tiers(text, &mut score.seq)?;
        Ok((score, in_range))
    }

    /// The score as a .ges file, as 2.4 writes one.
    pub fn to_xml(&self) -> String {
        tiers_xml(&self.seq)
    }

    pub fn duration_s(&self) -> f64 {
        let mut d = 0.0;
        for s in &self.seq {
            let x = s.duration_s();
            if x > d {
                d = x;
            }
        }
        d
    }

    /// The tract's targets (calcTractParamTargets).
    fn tract_targets(&self, vt: &VocalTract) -> Vec<Vec<Target>> {
        const N: usize = 5;
        let mut slices: Vec<[Gesture; N]> = Vec::new();
        let mut index = [0usize; N];
        let mut gesture_pos = [0.0; N];
        let mut pos = 0.0;
        // (The C++ reuses one gesture for a tier that has run out: its slope stays from the last one copied.)
        let mut g = Gesture::default();
        while (0..N).any(|i| index[i] < self.seq[i].gestures.len()) {
            let mut k: i64 = -1;
            let mut nearest = 1000000.0;
            for i in 0..N {
                if index[i] < self.seq[i].gestures.len() && gesture_pos[i] + self.seq[i].gestures[index[i]].duration_s < nearest {
                    nearest = gesture_pos[i] + self.seq[i].gestures[index[i]].duration_s;
                    k = i as i64;
                }
            }
            if k != -1 {
                let k = k as usize;
                if nearest > pos {
                    let slice_duration = nearest - pos;
                    let mut slice: [Gesture; N] = Default::default();
                    for i in 0..N {
                        if index[i] < self.seq[i].gestures.len() {
                            g = self.seq[i].gestures[index[i]].clone();
                            // A neutral gesture right after an active one: its release.
                            if i > 0 && g.neutral && index[i] > 0 && !self.seq[i].gestures[index[i] - 1].neutral {
                                g.s_val = "RET".to_string();
                            }
                        } else {
                            g.d_val = self.seq[i].min_value;
                            g.tau_s = self.seq[i].min_tau_s;
                            g.neutral = true;
                            g.s_val = String::new();
                        }
                        g.duration_s = slice_duration;
                        slice[i] = g.clone();
                    }
                    // (No more than 1023 slices: past them the last is written over, as the C++ does.)
                    if slices.len() < MAX_SLICES - 1 {
                        slices.push(slice);
                    } else {
                        *slices.last_mut().unwrap() = slice;
                    }
                }
                pos = nearest;
                gesture_pos[k] = nearest;
                index[k] += 1;
            }
        }
        let mut targets: Vec<Vec<Target>> = vec![Vec::new(); NUM_PARAMS];
        let schwa = vt.shape("@");
        for sl in &slices {
            let vowel_tau = sl[VOWEL].tau_s;
            let base = vt.shape(&sl[VOWEL].s_val).or(schwa);
            let mut value = [0.0; NUM_PARAMS];
            let mut tau = [vowel_tau; NUM_PARAMS];
            for k in 0..NUM_PARAMS {
                value[k] = match base {
                    Some(b) => b[k],
                    None => vt.param[k].neutral,
                };
            }
            let (mut at, mut bt, mut al, mut bl) = map_to_vowel_subspace(vt, &value);
            limit_vowel_subspace_coord(&mut at, &mut bt, &mut al, &mut bl);
            let mut active = 0;
            let mut param_sum = [0.0; NUM_PARAMS];
            let mut exists = [false; 3];
            let mut cp = [[0.0; NUM_PARAMS]; 3];
            for k in 0..3 {
                let c = &sl[LIP + k];
                if !c.neutral {
                    exists[k] = context_dependent_consonant(vt, &c.s_val, at, bt, al, bl, &mut cp[k]);
                    if exists[k] {
                        active += 1;
                        for m in 0..NUM_PARAMS {
                            param_sum[m] += cp[k][m];
                        }
                    }
                }
            }
            if active > 0 {
                for m in 0..NUM_PARAMS {
                    value[m] = param_sum[m] / active as f64;
                }
            }
            // The tongue body's consonant, then the tip's, then the lips': each what it moves, and its time constant
            // the whole tract's, where it is active or released.
            const MOVED: [&[usize]; 3] = [&[JX, JA, LP, LD], &[TBX, TBY, TTX, TTY, JX, JA, LP, LD, TS3], &[TCX, TCY, TBX, TBY, TTX, TTY, JX, JA, LP, LD, TS2, TS3]];
            for kind in [2, 1, 0] {
                if exists[kind] {
                    for &m in MOVED[kind] {
                        value[m] = cp[kind][m];
                    }
                }
                if exists[kind] || sl[LIP + kind].s_val == "RET" {
                    tau = [sl[LIP + kind].tau_s; NUM_PARAMS];
                }
            }
            if !sl[VELIC].neutral {
                value[VO] = sl[VELIC].d_val;
                tau[VO] = sl[VELIC].tau_s;
            } else if sl[VELIC].s_val == "RET" {
                tau[VO] = sl[VELIC].tau_s;
            }
            for k in 0..NUM_PARAMS {
                targets[k].push(Target { duration: sl[VOWEL].duration_s, value: value[k], tau_s: tau[k], slope: 0.0 });
            }
        }
        // Each articulator's own speed rising and falling.
        const EPSILON: f64 = 0.001;
        for (k, t) in targets.iter_mut().enumerate() {
            for i in 1..t.len() {
                let mut f = if t[i].value > t[i - 1].value { vt.anatomy.positive_velocity_factor[k] } else { vt.anatomy.negative_velocity_factor[k] };
                if f.abs() < EPSILON {
                    f = EPSILON;
                }
                t[i].tau_s /= f;
            }
        }
        targets
    }

    /// The tract's parameters at `pos_s` as calcCurves and getParams give them -- the curves computed only to the two
    /// samples about it, the same numbers; past the score's end the neutral values calcCurves leaves there. For the
    /// rules' searches (src/v24/segments.rs).
    pub(crate) fn tract_params_at(&self, vt: &VocalTract, pos_s: f64) -> [f64; NUM_PARAMS] {
        let mut final_index = ((self.duration_s() + 0.010) * CURVE_SAMPLING_RATE as f64) as usize;
        if final_index >= MAX_CURVE_SAMPLES {
            final_index = MAX_CURVE_SAMPLES - 1;
        }
        let period = 1.0 / CURVE_SAMPLING_RATE as f64;
        let mut index = (pos_s * CURVE_SAMPLING_RATE as f64) as i64;
        let mut s = (pos_s - index as f64 * period) / period;
        let mut s1 = 1.0 - s;
        if index < 0 {
            index = 0;
        }
        if index > MAX_CURVE_SAMPLES as i64 - 2 {
            index = MAX_CURVE_SAMPLES as i64 - 2;
            s = 0.0;
            s1 = 1.0;
        }
        let i = index as usize;
        let mut targets = self.tract_targets(vt);
        let mut out = [0.0; NUM_PARAMS];
        for (k, t) in targets.iter_mut().enumerate() {
            let mut curve = vec![vt.param[k].neutral; i + 2];
            param_curve(t, &mut curve, final_index.min(i + 1));
            out[k] = s1 * curve[i] + s * curve[i + 1];
        }
        out
    }

    /// The glottis's targets (calcGlottisParamTargets): its shapes' from the third parameter on, F0's and the lungs'.
    fn glottis_targets(&self, glottis: &Glottis2025) -> Vec<Vec<Target>> {
        const FIRST_SHAPE_PARAM: usize = 2;
        let n = glottis.control.len();
        let mut targets: Vec<Vec<Target>> = vec![Vec::new(); n];
        for g in &self.seq[GLOTTAL_SHAPE].gestures {
            let shape = glottis.shape(&g.s_val);
            for k in FIRST_SHAPE_PARAM..n {
                targets[k].push(Target { duration: g.duration_s, tau_s: g.tau_s, value: shape.map(|v| v[k]).unwrap_or(glottis.control[k].neutral), slope: 0.0 });
            }
        }
        for g in &self.seq[F0].gestures {
            targets[FREQUENCY].push(Target { duration: g.duration_s, tau_s: g.tau_s, value: g.d_val, slope: g.slope });
        }
        for g in &self.seq[LUNG_PRESSURE].gestures {
            targets[PRESSURE].push(Target { duration: g.duration_s, tau_s: g.tau_s, value: g.d_val, slope: g.slope });
        }
        targets
    }

    /// How far the glottis is in its shape `name` along the curves (0 to 1, at 400 Hz as they are): its shape gestures'
    /// targets 1 where they are that shape and 0 elsewhere, approached as its controls are (calcCurves) -- each control's
    /// share that is that shape's (the fold law, crate::fold_law: the modal shape's).
    pub fn glottal_shape_weight(&self, name: &str) -> Vec<f64> {
        let mut final_index = ((self.duration_s() + 0.010) * CURVE_SAMPLING_RATE as f64) as usize;
        if final_index >= MAX_CURVE_SAMPLES {
            final_index = MAX_CURVE_SAMPLES - 1;
        }
        let mut targets: Vec<Target> =
            self.seq[GLOTTAL_SHAPE].gestures.iter().map(|g| Target { duration: g.duration_s, tau_s: g.tau_s, value: if g.s_val == name { 1.0 } else { 0.0 }, slope: 0.0 }).collect();
        let mut curve = vec![0.0; MAX_CURVE_SAMPLES];
        param_curve(&mut targets, &mut curve, final_index);
        curve
    }

    /// The parameter curves at 400 Hz, 60 s long (calcCurves).
    pub fn curves(&self, vt: &VocalTract, glottis: &Glottis2025) -> Curves {
        let mut final_index = ((self.duration_s() + 0.010) * CURVE_SAMPLING_RATE as f64) as usize;
        if final_index >= MAX_CURVE_SAMPLES {
            final_index = MAX_CURVE_SAMPLES - 1;
        }
        let mut tract: Vec<Vec<f64>> = (0..NUM_PARAMS).map(|i| vec![vt.param[i].neutral; MAX_CURVE_SAMPLES]).collect();
        let mut curves: Vec<Vec<f64>> = glottis.control.iter().enumerate().map(|(i, p)| vec![if i == FREQUENCY { f0_st(p.neutral) } else { p.neutral }; MAX_CURVE_SAMPLES]).collect();
        let mut tt = self.tract_targets(vt);
        let mut gt = self.glottis_targets(glottis);
        for (t, c) in tt.iter_mut().zip(tract.iter_mut()) {
            param_curve(t, c, final_index);
        }
        for (t, c) in gt.iter_mut().zip(curves.iter_mut()) {
            param_curve(t, c, final_index);
        }
        for x in curves[FREQUENCY].iter_mut() {
            *x = f0_hz(*x);
        }
        Curves { tract, glottis: curves }
    }

    /// The frames 2.4 synthesizes the score from (Synthesizer::synthesizeGesturalScore): the curves read at 0 and then
    /// every 120 samples, one more chunk than the score's whole length holds.
    pub fn frames(&self, vt: &VocalTract, glottis: &Glottis2025) -> Vec<(Vec<f64>, Vec<f64>)> {
        let curves = self.curves(vt, glottis);
        let length_pt = (self.duration_s() * AUDIO_SAMPLING_RATE_HZ as f64) as i64;
        let chunks = (length_pt / NUM_CHUNK_SAMPLES as i64) as usize + 1;
        (0..=chunks).map(|i| params_at(&curves, i as f64 * NUM_CHUNK_SAMPLES as f64 / AUDIO_SAMPLING_RATE_HZ as f64)).collect()
    }
}

/// The curves read at pos_s, between their samples (GesturalScore::getParams).
pub fn params_at(c: &Curves, pos_s: f64) -> (Vec<f64>, Vec<f64>) {
    let period = 1.0 / CURVE_SAMPLING_RATE as f64;
    let mut index = (pos_s * CURVE_SAMPLING_RATE as f64) as i64;
    let n = c.tract[0].len() as i64;
    let mut s = (pos_s - index as f64 * period) / period;
    let mut s1 = 1.0 - s;
    if index < 0 {
        index = 0;
    }
    if index > MAX_CURVE_SAMPLES as i64 - 2 {
        index = MAX_CURVE_SAMPLES as i64 - 2;
        s = 0.0;
        s1 = 1.0;
    }
    if index >= n - 1 {
        index = n - 2;
        s = 1.0;
        s1 = 0.0;
    }
    let i = index as usize;
    (c.tract.iter().map(|v| s1 * v[i] + s * v[i + 1]).collect(), c.glottis.iter().map(|v| s1 * v[i] + s * v[i + 1]).collect())
}

/// The targets approached by a fifth-order critically damped system, solved analytically target by target and sampled
/// at 400 Hz (calcParamCurve): each target's start continuous in value and four derivatives with the last's end, those
/// derivatives scaled down by the ratio of the time constants where the new target is the slower. (f0_targets fits a
/// read contour's targets on it.)
pub(crate) fn param_curve(targets: &mut [Target], curve: &mut [f64], final_index: usize) {
    const EPSILON: f64 = 0.000000001;
    if targets.is_empty() {
        return;
    }
    let n = targets.len();
    let mut ti = 0;
    let mut target_pos = 0.0;
    if targets[0].tau_s.abs() < EPSILON {
        targets[0].tau_s = EPSILON;
    }
    let mut a = -1.0 / targets[0].tau_s;
    let mut a2 = a * a;
    let mut a3 = a2 * a;
    let mut a4 = a3 * a;
    let (mut c0, mut c1, mut c2, mut c3, mut c4) = (0.0, 0.0, 0.0, 0.0, 0.0);
    for i in 0..=final_index {
        let t_s = i as f64 / CURVE_SAMPLING_RATE as f64;
        while t_s > target_pos + targets[ti].duration && ti < n - 1 {
            let tg = targets[ti];
            let t = tg.duration;
            let t2 = t * t;
            let t3 = t2 * t;
            let t4 = t3 * t;
            let f0 = (a * t).exp() * ((c0) + (c1) * t + (c2) * t2 + (c3) * t3 + (c4) * t4) + (tg.value + tg.duration * tg.slope);
            let mut f1 = (a * t).exp() * ((c0 * a + c1) + (c1 * a + 2.0 * c2) * t + (c2 * a + 3.0 * c3) * t2 + (c3 * a + 4.0 * c4) * t3 + (c4 * a) * t4) + tg.slope;
            let mut f2 = (a * t).exp() * ((c0 * a2 + 2.0 * c1 * a + 2.0 * c2) + (c1 * a2 + 4.0 * c2 * a + 6.0 * c3) * t + (c2 * a2 + 6.0 * c3 * a + 12.0 * c4) * t2 + (c3 * a2 + 8.0 * c4 * a) * t3 + (c4 * a2) * t4);
            let mut f3 = (a * t).exp() * ((c0 * a3 + 3.0 * c1 * a2 + 6.0 * c2 * a + 6.0 * c3) + (c1 * a3 + 6.0 * c2 * a2 + 18.0 * c3 * a + 24.0 * c4) * t + (c2 * a3 + 9.0 * c3 * a2 + 36.0 * c4 * a) * t2 + (c3 * a3 + 12.0 * c4 * a2) * t3 + (c4 * a3) * t4);
            let mut f4 = (a * t).exp() * ((c0 * a4 + 4.0 * c1 * a3 + 12.0 * c2 * a2 + 24.0 * c3 * a + 24.0 * c4) + (c1 * a4 + 8.0 * c2 * a3 + 36.0 * c3 * a2 + 96.0 * c4 * a) * t + (c2 * a4 + 12.0 * c3 * a3 + 72.0 * c4 * a2) * t2 + (c3 * a4 + 16.0 * c4 * a3) * t3 + (c4 * a4) * t4);
            target_pos += tg.duration;
            ti += 1;
            if targets[ti].tau_s > targets[ti - 1].tau_s {
                let ratio1 = targets[ti - 1].tau_s / targets[ti].tau_s;
                let ratio2 = ratio1 * ratio1;
                let ratio3 = ratio2 * ratio1;
                let ratio4 = ratio3 * ratio1;
                f1 *= ratio1;
                f2 *= ratio2;
                f3 *= ratio3;
                f4 *= ratio4;
            }
            if targets[ti].tau_s.abs() < EPSILON {
                targets[ti].tau_s = EPSILON;
            }
            let tg = targets[ti];
            a = -1.0 / tg.tau_s;
            a2 = a * a;
            a3 = a2 * a;
            a4 = a3 * a;
            c0 = f0 - tg.value;
            c1 = f1 - c0 * a - tg.slope;
            c2 = (f2 - c0 * a2 - c1 * a * 2.0) / 2.0;
            c3 = (f3 - c0 * a3 - c1 * a2 * 3.0 - c2 * a * 6.0) / 6.0;
            c4 = (f4 - c0 * a4 - c1 * a3 * 4.0 - c2 * a2 * 12.0 - c3 * a * 24.0) / 24.0;
        }
        let tg = targets[ti];
        let t = t_s - target_pos;
        let t2 = t * t;
        let t3 = t2 * t;
        let t4 = t3 * t;
        curve[i] = (a * t).exp() * ((c0) + (c1) * t + (c2) * t2 + (c3) * t3 + (c4) * t4) + (tg.value + t * tg.slope);
    }
}

/// The time a step response (from 0 toward 1) takes to reach `norm`, in steps of a twentieth of its time constant, at
/// most twelve of them (getTimeToStepResponseValue_s).
pub fn time_to_step_response_value_s(norm: f64, tau_s: f64) -> f64 {
    const EPSILON: f64 = 0.000000001;
    let tau_s = if tau_s.abs() < EPSILON { EPSILON } else { tau_s };
    let a = -1.0 / tau_s;
    let a2 = a * a;
    let a3 = a2 * a;
    let a4 = a3 * a;
    let c0 = -1.0;
    let c1 = -c0 * a;
    let c2 = (-c0 * a2 - c1 * a * 2.0) / 2.0;
    let c3 = (-c0 * a3 - c1 * a2 * 3.0 - c2 * a * 6.0) / 6.0;
    let c4 = (-c0 * a4 - c1 * a3 * 4.0 - c2 * a2 * 12.0 - c3 * a * 24.0) / 24.0;
    let step = 0.05 * tau_s;
    let max_steps = (12.0 * tau_s / step) as i32;
    let mut t_s = 0.0;
    for i in 0..=max_steps {
        t_s = i as f64 * step;
        let t = t_s;
        let t2 = t * t;
        let t3 = t2 * t;
        let t4 = t3 * t;
        let x = (a * t).exp() * ((c0) + (c1) * t + (c2) * t2 + (c3) * t3 + (c4) * t4) + 1.0;
        if x >= norm {
            break;
        }
    }
    t_s
}
