// VocalTractLab 2.4's "Geometric glottis 2025" (GeometricGlottis2025.cpp; Glottis.cpp's reading of it): the folds'
// edges displaced at F0, the lower leading the upper by the phase lag; their amplitude from the transglottal pressure
// (none under 1000 dPa, growing to 2000, scaled by the rest length and the relative amplitude); each edge's motion a
// cosine held at closure by two exponential approaches whose timing the pulse shape skews; the areas integrated along the
// folds' length with the chink's; F0 with flutter (three sinusoids) and jitter (a random step of the phase each sample).
// Each expression in the C++'s order. Found: its jitter draws from the C library's rand() -- one global, unseeded state,
// and a different generator on each platform (Windows' is not macOS's), so that VocalTractLab sounds otherwise on each;
// the port draws macOS's (Park and Miller's minimal standard, from 1), its own state per glottis. Its areas are 3.2%
// large, as 2.3's are (32 intervals each a 31st of the folds' length); `mended` takes 32nds. Found too, stepping it
// faster than 2.4 does: the supraglottal pressure's 25 Hz filter, one recursion of a four-pole polynomial, loses its
// digits as the rate rises against its cutoff -- at 240 kHz a change of one part in 1e13 of the pressure moves its
// output by 1.6e-4, the folds' amplitude with it, and the voice's sound by some 4e-5 of its peak (2e-5 by 2.4's
// network at 192 kHz): a floor of rounding under every sung sound, which no two arithmetics share. Wherever the
// glottis is not 2.4's own bit for bit (mended, or stepped at another rate than 2.4's) the same filter is stepped in
// sections that keep their digits (crate::iir::ChebyshevSections).
use super::constants::{AUDIO_SAMPLING_RATE_HZ, PI};
use crate::glottis::Parameter;
use crate::iir::{ChebyshevSections, IirFilter};
use crate::xml::Node;

pub const FREQUENCY: usize = 0;
pub const PRESSURE: usize = 1;
pub const LOWER_END_X: usize = 2;
pub const UPPER_END_X: usize = 3;
pub const CHINK_AREA: usize = 4;
pub const PHASE_LAG: usize = 5;
pub const RELATIVE_AMPLITUDE: usize = 6;
pub const PULSE_SHAPE: usize = 7;
pub const FLUTTER: usize = 8;
pub const NUM_CONTROL_PARAMS: usize = 9;

pub const REST_THICKNESS: usize = 0;
pub const REST_LENGTH: usize = 1;
pub const REST_F0: usize = 2;
pub const CHINK_LENGTH: usize = 3;
pub const JITTER: usize = 4;
pub const NUM_STATIC_PARAMS: usize = 5;

/// A singer's open quotient by effort (Titze & Sundberg 1992, "Vocal intensity in speakers and singers", JASA 91(5),
/// 2936-2946, doi:10.1121/1.402929): Qo = k2 + (1 - k2) Pth / PL, their eq. (34), the threshold Pth = kpa[0] + kpa[1]
/// (F0 / f0_mean_hz)^2 kPa, their eq. (37) -- voices/measured-singing.json `threshold` and `openQuotient`.
/// `gap_cm`: the rest gap at the vocal processes its sung vowels are sung at (0: any) -- the law is a sung vowel's,
/// in force whole at that gap or under and not at all from three times it, so that a consonant's glottis, opened
/// wider by its own shape, keeps its own (the fold law's rule: a phrase's controls take it as far as its glottis is
/// in the modal shape).
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct SungFolds {
    pub k2: f64,
    pub kpa: [f64; 2],
    pub f0_mean_hz: f64,
    pub gap_cm: f64,
}

/// What the folds' motion gives at an instant (the derived parameters).
#[derive(Clone, Copy, Debug, Default)]
pub struct Derived {
    pub length: f64,
    pub thickness: f64,
    pub amplitude: f64,
    pub lower_cord_x: f64,
    pub upper_cord_x: f64,
    pub lower_area: f64,
    pub upper_area: f64,
    pub chink_width: f64,
}

fn param(name: &str, min: f64, max: f64, neutral: f64) -> Parameter {
    Parameter { name: name.into(), min, max, neutral, x: neutral }
}

/// The band-limited jitter's gain: jitter is the spread of the difference between consecutive periods, which follows
/// the difference between the phase's wander over consecutive cycles. Through a first-order low-pass cut at 1/T, white
/// noise's integral over a cycle keeps 1 - (1 - e^-2pi)/2pi of its variance, and two consecutive cycles' integrals share
/// a covariance of (1 - e^-2pi)^2/4pi of it, so that their difference keeps 2 (1 - (1 - e^-2pi)/2pi - (1 - e^-2pi)^2/4pi)
/// of the white's 2: the gain is the root of its inverse, 1.1457 (a simulation of the discrete process over 200,000
/// cycles: 1.1458 +- 0.0036).
const JITTER_GAIN: f64 = 1.145_667;

/// The folds' length in 32nds, along which their area is summed.
const NUM_SAMPLES: i32 = 32;

#[derive(Clone)]
pub struct Glottis2025 {
    pub control: Vec<Parameter>,
    pub statics: Vec<Parameter>,
    pub derived: Derived,
    /// Its named shapes: control values in the order of `control`.
    pub shapes: Vec<(String, Vec<f64>)>,
    /// Its area integrated in 32nds of the folds' length (2.4's bug mended).
    pub mended: bool,
    /// Its jitter a cycle-to-cycle variation (VocalFork 3.0; research/VOCAL_TRACT_PASSIVE_CORE.md): 2.4's random kicks
    /// to the phase, 2 pi b xi sqrt(dt) each step, white to the step's Nyquist frequency, taken through a first-order
    /// low-pass at the voice's own f0, their gain (JITTER_GAIN) keeping the phase's wander over a cycle -- and so the
    /// period-to-period jitter -- as it was. Off, 2.4's as it is (its parity checks); its draws the same either way.
    /// (The owner, 13 November 2026, of the design: "Yes, proceed.")
    pub jitter_band_limited: bool,
    /// The low-passed kicks' rate (rad/s).
    jitter_rate: f64,
    pub phase: f64,
    /// The rate it is stepped at (Hz), for its supraglottal pressure's 25 Hz filter: 2.4's 48 kHz or a multiple.
    pub rate_hz: f64,
    time_s: f64,
    supraglottal_pressure_dpa: f64,
    supraglottal_pressure_filter: IirFilter,
    /// The same filter in sections that keep their digits: the glottis's wherever it is not 2.4's own bit for bit.
    supraglottal_pressure_sections: ChebyshevSections,
    rand_state: u64,
    /// sin(t pi) at t = k/32 (k 0 to 32), as calcGeometry takes it at each, made once: the same numbers.
    sines: [f64; NUM_SAMPLES as usize + 1],
    /// How softly its folds meet (cm; 0: 2.4's own, each point of a fold's edge cut off at the midline the instant it
    /// touches). 2.4 sums the folds' gap along their length with every point's width held at nothing once it would
    /// cross the midline: a corner in the glottis's area at each point's contact and parting, 64 a cycle, which ring the
    /// tract's upper resonances -- measured 17 November 2026 on W02's /a/ at C5 beside TU Berlin's anechoic soprano
    /// (research/voice-listening/held-notes.mjs): her harmonics from 4 to 16 kHz 30 to 60 dB under the note, the
    /// engine's 15 to 35 with one partial to 12 (the owner, of the singers' "ooo": "what sounds to me like aliasing";
    /// "if you can trace the buzz, yes, do so"). Folds are tissue: their surfaces seal over a distance, not at a plane.
    /// Asked, a point's width w over the midline is taken as c ln(1 + exp(w / c)) -- w itself well apart, nothing well
    /// pressed, 0.69 c where it would just touch, as surfaces whose roughness is spread exponentially close
    /// (Greenwood & Williamson 1966, doi:10.1098/rspa.1966.0242) -- so that the area's corners are rounded over the
    /// time an edge takes to move c: a return phase that shortens as the folds move faster, with the pressure and with
    /// the pitch. VocalWind 4.0's fourth step (research/VOCAL_TRACT_REALTIME_PLAN.md, 6: "the glottis's contact
    /// soft"). Its value is the voice's configuration (voices/singing.json `contact`), fitted to measured singers'
    /// high band; what it counts as open (`open_steps`) is 2.4's, by the edges themselves.
    pub contact_cm: f64,
    /// The folds held apart as a singer's are at each effort (None: 2.4's own). 2.4's folds touch from where their
    /// swing reaches the gap at the vocal processes, so that the only way they stay apart longer is a wider gap
    /// behind -- a leak through the whole cycle, which damps the tube above the folds (a singer's formant with it:
    /// measured 17 November 2026, the bass's [u] 12 dB weaker at its third resonance for its modal shape's gap) and
    /// makes breath noise at every dynamic. A singer's folds stay apart longer when soft and close firmly when loud
    /// (Titze & Sundberg's open quotient, 0.8 at 1.5 times a tenor's threshold, 0.55 at 4), and at rest stand apart
    /// in a spindle, widest at their middle, where a soft voice's are seen not to meet (M. Södersten & P.-Å.
    /// Lindestad 1990, "Glottal closure and perceived breathiness during phonation in normally speaking subjects",
    /// J Speech Hear Res 33(3), 601-611, doi:10.1044/jshr.3303.601: its spindle-shaped closure). Asked, each edge's
    /// swing is taken about a spindle offset b sin(pi s) along the folds, b the least that keeps the two edges apart
    /// together for the open quotient the law gives at the lung pressure and the pitch -- the edges' own quotient
    /// longer than the flow's by their phase lag -- and none where 2.4's own gap already
    /// does (b >= 0: no fold pressed further than 2.4 presses it, a voiceless glottis as it was). Pressed as 2.4
    /// presses them, the folds then close along their length as before: the leak is the gap's alone.
    pub sung: Option<SungFolds>,
    /// The steps whose geometry it has made since this was last cleared, and of them those in which its folds were
    /// apart at the front, on both edges: their ratio its open quotient (the fold fit's, native/vocaltract/fold-fit.mjs).
    /// Its folds meet first and part last at the front, the first of the 32nds past the anterior commissure, where the
    /// displacement reaches its closing value a2 = -abduction/pi (calc_geometry: t2, t3); while either edge touches there
    /// the flow is held to what the vocal processes' gap and the chink let through, which inverse filtering reads as
    /// the closed phase (Titze & Sundberg 1992's Qo) and the electroglottograph as contact (Henrich et al. 2005's).
    /// Counting changes none of its numbers.
    pub open_steps: (u64, u64),
}

impl Default for Glottis2025 {
    fn default() -> Self {
        Glottis2025::new()
    }
}

impl Glottis2025 {
    pub fn new() -> Glottis2025 {
        let control = vec![
            param("f0", 40.0, 600.0, 120.0),
            param("Subglottal pressure", 0.0, 16000.0, 8000.0),
            param("Lower displacement", -0.05, 0.3, 0.02),
            param("Upper displacement", -0.05, 0.3, 0.02),
            param("Chink area", -0.25, 0.25, 0.03),
            param("Phase lag", 0.0, 3.1415, 1.22),
            param("Relative amplitude", -1.0, 1.0, 1.0),
            param("Pulse shape", -1.0, 1.0, 0.0),
            param("Flutter", 0.0, 100.0, 25.0),
        ];
        let statics = vec![param("Rest thickness", 0.2, 1.0, 0.45), param("Rest length", 0.5, 2.0, 1.6), param("Rest f0", 50.0, 400.0, 120.0), param("Chink length", 0.1, 0.5, 0.4), param("Jitter", 0.0, 100.0, 10.0)];
        let shapes = vec![("default".to_string(), control.iter().map(|p| p.neutral).collect())];
        let mut g = Glottis2025 {
            control,
            statics,
            derived: Derived::default(),
            shapes,
            mended: false,
            contact_cm: 0.0,
            sung: None,
            jitter_band_limited: false,
            jitter_rate: 0.0,
            phase: 0.0,
            rate_hz: AUDIO_SAMPLING_RATE_HZ as f64,
            time_s: 0.0,
            supraglottal_pressure_dpa: 0.0,
            supraglottal_pressure_filter: IirFilter::default(),
            supraglottal_pressure_sections: ChebyshevSections::default(),
            rand_state: 1,
            sines: std::array::from_fn(|k| (k as f64 / NUM_SAMPLES as f64 * PI).sin()),
            open_steps: (0, 0),
        };
        g.reset_motion();
        g.calc_geometry();
        g
    }

    /// A speaker file's "Geometric glottis 2025" (Glottis::readFromXml): its static parameters' values; its control
    /// parameters' names checked (their ranges and neutral values the model's own); its shapes by parameter index.
    pub fn from_xml(node: &Node) -> Result<Glottis2025, String> {
        let mut g = Glottis2025::new();
        if let Some(list) = node.child("static_params") {
            for p in &list.children {
                let index = p.num("index")? as usize;
                let name = p.attr("name").unwrap_or("");
                let q = g.statics.get_mut(index).ok_or_else(|| format!("static parameter {index} out of range"))?;
                if q.name != name {
                    return Err(format!("static parameter {index} is '{name}', not '{}'", q.name));
                }
                q.x = p.num("value")?;
            }
        }
        if let Some(list) = node.child("control_params") {
            for p in &list.children {
                let index = p.num("index")? as usize;
                let name = p.attr("name").unwrap_or("");
                let q = g.control.get(index).ok_or_else(|| format!("control parameter {index} out of range"))?;
                if q.name != name {
                    return Err(format!("control parameter {index} is '{name}', not '{}'", q.name));
                }
            }
        }
        if let Some(list) = node.child("shapes") {
            g.shapes.clear();
            for s in list.children_named("shape") {
                let name = s.attr("name").filter(|n| !n.is_empty()).ok_or("a glottis shape without a name")?;
                let mut values: Vec<f64> = g.control.iter().map(|p| p.neutral).collect();
                for c in s.children_named("control_param") {
                    let index = c.num("index")? as usize;
                    *values.get_mut(index).ok_or("a shape's parameter index out of range")? = c.num("value")?;
                }
                g.shapes.push((name.to_string(), values));
            }
        }
        g.reset_motion();
        g.calc_geometry();
        Ok(g)
    }

    pub fn shape(&self, name: &str) -> Option<&[f64]> {
        self.shapes.iter().find(|(n, _)| n == name).map(|(_, v)| v.as_slice())
    }

    pub fn reset_motion(&mut self) {
        self.supraglottal_pressure_filter.create_chebyshev(25.0 / self.rate_hz, false, 4);
        self.supraglottal_pressure_filter.reset_buffers(0.0);
        self.supraglottal_pressure_sections = ChebyshevSections::lowpass(25.0 / self.rate_hz, 4);
        self.time_s = 0.0;
        self.phase = 0.0;
        self.jitter_rate = 0.0;
        self.supraglottal_pressure_dpa = 0.0;
    }

    fn restrict(p: &mut [Parameter]) {
        for q in p.iter_mut() {
            if q.x < q.min {
                q.x = q.min;
            }
            if q.x > q.max {
                q.x = q.max;
            }
        }
    }

    pub fn calc_geometry(&mut self) {
        Self::restrict(&mut self.control);
        Self::restrict(&mut self.statics);
        let c = |k: usize| self.control[k].x;
        let s = |k: usize| self.statics[k].x;
        let length = s(REST_LENGTH) * (c(FREQUENCY) / s(REST_F0)).sqrt();
        let thickness = (s(REST_THICKNESS) * s(REST_LENGTH)) / length;
        let lag = c(PHASE_LAG);
        let mut edge = [self.phase, self.phase + 2.0 * PI - lag];
        for e in edge.iter_mut() {
            let n = (*e / (2.0 * PI)) as i64;
            *e -= n as f64 * 2.0 * PI;
        }
        let mut trans = c(PRESSURE) - self.supraglottal_pressure_dpa;
        if trans < 0.0 {
            trans = 0.0;
        }
        let mut amplitude = 0.0007 * (s(REST_LENGTH) / 1.6) * trans.sqrt();
        if trans < 1000.0 {
            amplitude = 0.0;
        } else if trans < 2000.0 {
            amplitude *= (trans - 1000.0) / 1000.0;
        }
        let mut rel_amp = c(RELATIVE_AMPLITUDE);
        if rel_amp < 0.0 {
            rel_amp = 0.0;
        }
        amplitude *= rel_amp;
        let pulse_shape = c(PULSE_SHAPE);
        // (A singer's open quotient, where asked: the edges' own, longer than the flow's by their lag -- measured on the
        // engine, M01's /u/ at B-flat3: its modal shape's edges apart 0.61 to 0.65 of a cycle, both together 0.45.)
        let edges_apart = match &self.sung {
            Some(law) if amplitude > 0.0 => {
                let threshold = (law.kpa[0] + law.kpa[1] * (c(FREQUENCY) / law.f0_mean_hz).powi(2)) * 1e4;
                let quotient = law.k2 + (1.0 - law.k2) * threshold / c(PRESSURE).max(threshold);
                Some((quotient + lag / (2.0 * PI)).min(1.0))
            }
            _ => None,
        };
        let mut displacement = [0.0; 2];
        for k in 0..2 {
            let t = edge[k] / (2.0 * PI);
            let a1 = amplitude;
            let mut abduction = if k == 0 { c(LOWER_END_X) } else { c(UPPER_END_X) };
            if abduction < 0.0 {
                abduction = 0.0;
            }
            // (the spindle's offset: the swing's level at which the edge first touches lowered by it, the edge's width
            // raised by it, so that pressed it lies as 2.4 presses it)
            let whole = self.sung.map_or(1.0, |law| if law.gap_cm > 0.0 { (1.0 - (abduction - law.gap_cm) / (2.0 * law.gap_cm)).clamp(0.0, 1.0) } else { 1.0 });
            let spindle = whole * edges_apart.map_or(0.0, |apart| (-abduction / PI - a1 * (PI * apart).cos()).max(0.0));
            let a2 = -abduction / PI - spindle;
            let a3 = a2 - 0.2 * amplitude;
            const EPSILON: f64 = 0.000001;
            let mut t2 = 0.5 - EPSILON;
            let mut t3 = 0.5 + EPSILON;
            if a2 > -a1 {
                t2 = (a2 / a1).acos() / (2.0 * PI);
                t3 = 1.0 - t2;
            }
            let mut t1 = t2;
            let mut t4 = t3;
            if pulse_shape < 0.0 {
                t1 = t2 + 0.10 * pulse_shape;
            } else {
                t4 = t3 + 0.10 * pulse_shape;
            }
            let val_t1 = a1 * (t1 * 2.0 * PI).cos();
            let grad_t1 = -a1 * 2.0 * PI * (2.0 * PI * t1).sin();
            let tau_t1 = -(val_t1 - a3) / grad_t1;
            let val_t4 = a1 * (t4 * 2.0 * PI).cos();
            let grad_t4 = -a1 * 2.0 * PI * (2.0 * PI * t4).sin();
            let tau_t4 = (val_t4 - a3) / grad_t4;
            let mut value = a1 * (t * 2.0 * PI).cos();
            if t >= t1 && t < t4 {
                let y = a3 + (val_t1 - a3) * (-(t - t1) / tau_t1).exp();
                if y > value {
                    value = y;
                }
                let y = a3 + (val_t4 - a3) * (-(t4 - t) / tau_t4).exp();
                if y > value {
                    value = y;
                }
            }
            displacement[k] = value + spindle;
        }
        let mut chink_area = c(CHINK_AREA);
        if chink_area < 0.0 {
            chink_area = 0.0;
        }
        let delta_length = length / if self.mended { NUM_SAMPLES } else { NUM_SAMPLES - 1 } as f64;
        let end_x = [c(LOWER_END_X), c(UPPER_END_X)];
        let mut area = [0.0; 2];
        let mut apart = true;
        for i in 0..2 {
            let mut prev_x = 0.0;
            area[i] = chink_area;
            for k in 1..=NUM_SAMPLES {
                let t = k as f64 / NUM_SAMPLES as f64;
                let mut x = end_x[i] * t + displacement[i] * self.sines[k as usize];
                if k == 1 && x <= 0.0 {
                    apart = false;
                }
                if self.contact_cm > 0.0 {
                    // (soft contact: within thirty of its lengths of touching; beyond, itself or nothing)
                    let u = x / self.contact_cm;
                    if u < 30.0 {
                        x = if u > -30.0 { self.contact_cm * u.exp().ln_1p() } else { 0.0 };
                    }
                } else if x < 0.0 {
                    x = 0.0;
                }
                area[i] += delta_length * (prev_x + x);
                prev_x = x;
            }
        }
        self.open_steps.0 += 1;
        if apart {
            self.open_steps.1 += 1;
        }
        let mut chink_length = s(CHINK_LENGTH);
        if chink_length < 0.000001 {
            chink_length = 0.000001;
        }
        self.derived = Derived { length, thickness, amplitude, lower_cord_x: displacement[0], upper_cord_x: displacement[1], lower_area: area[0], upper_area: area[1], chink_width: chink_area / chink_length };
    }

    /// macOS's rand(): Park and Miller's minimal standard generator, from 1.
    fn rand(&mut self) -> i64 {
        self.rand_state = (self.rand_state * 16807) % 2147483647;
        self.rand_state as i64
    }

    pub fn inc_time(&mut self, dt: f64, pressure_dpa: &[f64; 4]) {
        // (2.4's own recursion where the glottis is 2.4's bit for bit; else the same filter in its sections)
        let own = !self.mended && self.rate_hz == AUDIO_SAMPLING_RATE_HZ as f64;
        let mut supraglottal = if own { self.supraglottal_pressure_filter.output_sample(pressure_dpa[3]) } else { self.supraglottal_pressure_sections.output_sample(pressure_dpa[3]) };
        let mut f0 = self.control[FREQUENCY].x;
        if supraglottal > 40000.0 {
            supraglottal = 40000.0;
        }
        if supraglottal < -40000.0 {
            supraglottal = -40000.0;
        }
        self.supraglottal_pressure_dpa = supraglottal;
        let flutter_percent = self.control[FLUTTER].x;
        let t = self.time_s;
        f0 += (flutter_percent / 50.0) * (f0 / 100.0) * ((2.0 * PI * 12.7 * t).sin() + (2.0 * PI * 7.1 * t).sin() + (2.0 * PI * 4.7 * t).sin());
        self.phase += f0 * dt * 2.0 * PI;
        const MAX_B: f64 = 0.28;
        let b = MAX_B * self.statics[JITTER].x / 100.0;
        const RAND_MAX: i64 = 2147483647;
        let mut xi = if self.rand() >= RAND_MAX / 2 { 1.0 } else { -1.0 };
        if self.jitter_band_limited && f0 > 0.0 {
            // (the kicks as a rate, 2 pi b xi / sqrt(dt), low-passed at f0 and integrated: below f0 the walk 2.4's)
            let a = (-2.0 * PI * f0 * dt).exp();
            self.jitter_rate = a * self.jitter_rate + (1.0 - a) * JITTER_GAIN * 2.0 * PI * b * xi / dt.sqrt();
            self.phase += self.jitter_rate * dt;
        } else {
            xi *= dt.sqrt();
            self.phase += 2.0 * PI * b * xi;
        }
        self.time_s += dt;
    }

    /// The supraglottal pressure as its filter last gave it (dPa).
    pub fn supraglottal_pressure(&self) -> f64 {
        self.supraglottal_pressure_dpa
    }

    pub fn tube_data(&self) -> ([f64; 2], [f64; 2]) {
        let h = self.derived.thickness * 0.5;
        ([h, h], [self.derived.lower_area, self.derived.upper_area])
    }
}
