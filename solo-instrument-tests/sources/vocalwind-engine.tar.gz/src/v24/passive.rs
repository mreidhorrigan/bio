// VocalFork 3.0's acoustics (research/VOCAL_TRACT_PASSIVE_CORE.md): VocalTractLab 2.4's tube -- its trachea, pharynx
// and mouth, piriform fossa, nose and sinuses, each section as the step takes it -- on a scheme passive by
// construction, in place of 2.4's lumped network (v24::tds). The owner, 13 November 2026: "Yes, proceed, taking care
// that any difference in BEHAVIOUR from vocaltractlab is the result of SUPERIOR physical accuracy. We cannot deviate in
// ways that introduce inferior physical modeling."
//   Each section is one element of order 2 (or more, where a section of the nose or fossa is longer than
// MAX_ELEMENT_CM, or the trachea's is laid finer: Trachea): its pressure continuous at the Gauss-Lobatto nodes (each
// node a compliance, its share of the volume), its flow at its two Gauss nodes (each an inertance); the glottis's two
// sections one lumped edge; each sinus a neck into a cavity; each node a wall (a mass, a damper and a spring, 2.4's
// per unit area over the node's surface); the radiation at the lips and nostrils 2.4's piston, a resistance and an
// inductance in parallel. The lungs hold the trachea's first node. The lips'
// and nostrils' end nodes hold no air (their share of the last section's goes to its middle node): their pressure
// follows from Kirchhoff's law, so that the radiation's resistance couples the last element's flows and the radiation's
// inductance (radiate) -- the end's compliance against the radiation's mass, a mode of the discretization alone, near
// 420 kHz where the lips close, is not there to bound the step.
//   A step carries each node's content (compliance x pressure) and each edge's momentum (inertance x flow): the geometry
// is changed with both held; every edge's flow is stepped alone, its resistances centred in time (quadratic where
// Bernoulli's drop is, solved in closed form), from the pressures corrected to fourth order in time (the leapfrog's
// energy-consistent correction, every coupling in it); the contents from the flows and the volumes' growth. Its energy
// then changes only by the losses (never negative), the supplies (the lungs, the walls' motion, the noise, the pressure
// a jet recovers) and the geometry's work: EnergyAccount takes each, every step, where asked.
//   As 2.4: its noise (2.4's own sources, stepped from these flows: TdsModel::step_noise), its soft contacts and areas'
// limits (the stepper's, as for 2.4), its glottis's drops, its losses' laws and constants, its walls, its radiation.
// Otherwise, each for the physics: the resonances to 20 kHz (2.4's network up to 223 cents flat between 5 and 19 kHz);
// the glottis's flow following its area as the folds move (`glottal_velocity_held`); the walls at every node; the
// pressure a jet recovers past a widening, reached as the jet reattaches (`reattachment`, REATTACHMENT_STEP_HEIGHTS);
// the joins' drops on each section's own flow; a side branch reading the static pressure.
//   Kept as 2.4, each where 2.4's own model gives the physics nothing true to act on, until it does: the air the walls
// and folds displace (`displaced_volume`, `folds_displace`), the tract's flows held as its areas change
// (`tract_flow_held`), and a fixed share of the recovery (`borda_carnot`). 2.4's sections are a resampling of the area
// function along a centre line that moves with the articulators (sections.rs, cross_sections_to_tube_sections: the
// pharynx's and the mouth's each in equal lengths), so that a section's volume and momentum are no fixed body of air's;
// its kinematic glottis has hard corners; its stepped tube draws a diffuser as many small steps. Each, taken as the
// physics of a fixed tube, sounded as pops or clicks (research/VOCAL_TRACT_PASSIVE_CORE.md).
use super::constants::*;
use super::tds::{Options, Radiated, TdsModel, TubeCoefficients, MIN_AREA_CM2, NUM_BRANCH_CURRENTS};
use super::glottis::Glottis2025;
use super::tract::VocalTract;
use super::tube::{self, Tube, NUM_SECTIONS};
use std::f64::consts::PI;

/// The network as a still tube lays it, solved in frequency (PassiveModel::network).
pub mod frequency;
/// Its step on several cores, to the bit what one core gives (PassiveModel::cores).
pub mod parallel;

/// The longest element a static section (the nose's, the fossa's; the trachea's where `Trachea::Finer` asks it) is cut
/// into (cm): at order 2 and the fourth-order step, every resonance to 19 kHz within some 1.2 cents of a fine
/// reference (research/VOCAL_TRACT_PASSIVE_CORE.md). The pharynx's and mouth's sections, 0.23 to 0.6 cm in every shape
/// of 2.4's speakers, are an element each.
pub const MAX_ELEMENT_CM: f64 = 0.45;

/// How finely the trachea is laid out (the owner, 14 November 2026, of laying it one element to each of its sections:
/// "proceed ... with the trachea redesign, maintaining, with regard to the trachea, the ability to step up the accuracy
/// for offline rendering (or in case a future optimization method manages to make the optimization without the
/// accuracy loss for those high-frequency registers)"). Its sections are the speaker's centimetres, its area given once
/// in each: finer elements change nothing of its shape, only how near its waves come to the continuous tube's at the
/// top of the band -- its resonance at 5 kHz 0.4 cents flat laid by sections, 0.005 laid as finely as the other static
/// ducts, 59 in 2.4's own lumped sections; at 10 kHz 7.1, 0.08 and 239 (a uniform tube). Through a voicing glottis
/// (0.1 cm^2) the voice by sections within 0.054 dB of the finer layout below 4 kHz and 0.41 dB to 10 kHz, its
/// resonances to 5 kHz within 0.36 cents; through a wide one (1 cm^2), 0.2 dB below 5 kHz and up to 5.6 dB, mostly in
/// dips, between 8 and 10 (examples/vocalfork_trachea.rs; research/VOCAL_TRACT_REALTIME_PLAN.md, 6, "The trachea at
/// 2.4's resolution"). Options::fork_trachea; `trachea=` (layout_switches).
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Trachea {
    /// One element to each of its sections, 2.4's own resolution: the default, a still step some 23% the cheaper.
    Sections,
    /// Each section in elements no longer than this (cm): `trachea=fine` as every other static duct, MAX_ELEMENT_CM (as
    /// the trachea was laid before 14 November 2026), or finer still.
    Finer(f64),
}

/// A `trachea=` switch's value: sections, fine, or a length in centimetres.
fn trachea_switch(v: &str) -> Trachea {
    match v {
        "sections" => Trachea::Sections,
        "fine" => Trachea::Finer(MAX_ELEMENT_CM),
        cm => match cm.parse::<f64>() {
            Ok(cm) if cm.is_finite() && cm > 0.0 => Trachea::Finer(cm),
            _ => panic!("trachea={v}: sections, fine, or the longest element in centimetres"),
        },
    }
}

/// How far past a sudden widening the jet reattaches, in step heights (the widening's radius less the narrowing's): the
/// pressure it recovers is reached over that length at the jet's speed. Turbulent reattachment behind a step at 5 to 8
/// step heights (Eaton & Johnston 1981, "A review of research on subsonic turbulent flow reattachment", AIAA Journal
/// 19(9) 1093-1100); about 8 in an axisymmetric sudden expansion at Reynolds numbers of 10^4 (Experiments in Fluids
/// 2025, doi:10.1007/s00348-025-04018-9, its title and authors to be recorded); speech's jets are at some 10^4.
pub const REATTACHMENT_STEP_HEIGHTS: f64 = 8.0;

/// The glottis's sections' area at their widest, for the step's limit (cm^2): above what 2.4's glottis opens to (its
/// folds 0.3 cm apart over some 1.6 cm, its chink 0.25 cm^2, about 0.7).
pub const WIDEST_GLOTTIS_CM2: f64 = 1.0;


/// The step's limit, every mode's w dt, kept to this share of the corrected leapfrog's 2 sqrt 3 (steps_needed).
const STEP_MARGIN: f64 = 0.9;

// Zwikker and Kosten's boundary-layer losses in a duct, as OpenWInD takes them in time (`viscous_layer`, `thermal_layer`): its
// diffusive representation, a_0 + sum_i a_i w / (1 + w b_i) in the frequency w scaled by the duct's radius squared over
// the air's viscosity (the flow's term) or its thermal diffusivity (the pressure's), a_0 Poiseuille's 8. OpenWInD's
// DIFF_REPR_COEFS_8 (openwind/continuous/thermoviscous_models.py, its default); Thibault & Chabassier 2021,
// "Dissipative time-domain one-dimensional model for viscothermal acoustic propagation in wind instruments", JASA
// 150(2) 1165-1175, doi:10.1121/10.0005537.
const DIFFUSIVE_A0: f64 = 8.0;
const DIFFUSIVE_A: [f64; DIFFUSIVE_N] = [8.063381e-02, 1.864109e-01, 3.520992e-02, 1.533509e-02, 6.695831e-03, 2.932507e-03, 1.328246e-03, 9.403661e-04];
const DIFFUSIVE_B: [f64; DIFFUSIVE_N] = [5.883906e-03, 3.168418e-02, 1.112007e-03, 2.116664e-04, 4.045027e-05, 7.735956e-06, 1.444918e-06, 1.483825e-07];
const DIFFUSIVE_N: usize = 8;
/// A share's thermal branches: its storage c_0 and one for each term of the representation.
const THERMAL_N: usize = DIFFUSIVE_N + 1;

// Order 2. The pressure's nodes at -1, 0, 1 (Gauss-Lobatto, weights 1/3, 4/3, 1/3); the flow's at -1/sqrt 3 and
// 1/sqrt 3 (Gauss, weights 1, 1). D[k][m]: the pressure's m-th basis's derivative at the flow's k-th node (L0' = x - 1/2,
// L1' = -2x, L2' = x + 1/2), the element's coupling (w_k D[k][m], w_k = 1), its length cancelling.
const S3: f64 = 0.577_350_269_189_625_8;
const GL_W: [f64; 3] = [1.0 / 3.0, 4.0 / 3.0, 1.0 / 3.0];
const D: [[f64; 3]; 2] = [[-S3 - 0.5, 2.0 * S3, 0.5 - S3], [S3 - 0.5, -2.0 * S3, S3 + 0.5]];

const LUNGS: usize = 0;
const ATMOSPHERE: usize = usize::MAX;
const NONE: usize = usize::MAX;

#[derive(Clone, Copy, Debug)]
struct Element {
    section: usize,
    parts: usize,
    nodes: [usize; 3],
}

#[derive(Clone, Copy, Debug, PartialEq)]
enum Kind {
    Glottis,
    /// A sinus's neck (its section).
    Neck(usize),
    Wall,
    /// The radiation's inductance (0 the mouth, 1 the nostrils).
    Inductance(usize),
}

/// A lumped edge, from one node to another (or the atmosphere).
#[derive(Clone, Copy, Debug)]
struct Edge {
    kind: Kind,
    from: usize,
    to: usize,
}

/// The walls, the last of the lumped edges: the first's place among them, the first wall's node (wall i's is the
/// i-th after it, the acoustic nodes all before it), and each wall's acoustic node (its edge's `from`).
#[derive(Clone, Debug)]
struct Walls {
    first: usize,
    acoustic: usize,
    from: Vec<usize>,
}

/// One side of a section's join: its section and its flow edges (an element's two, or a neck's one).
#[derive(Clone, Copy, Debug)]
struct Side {
    section: usize,
    edge: usize,
    count: usize,
}

/// Where two sections meet within a duct, or a branch leaves one: the flow toward the narrower meets 2.4's Bernoulli
/// drop at once; toward the wider, the pressure 2.4 recovers (`recovery` of the drop: its 0.5, or the whole where the
/// upstream section branches) as the jet reattaches (`lagged`: the drop along the duct, dPa). At a branch (`branch`),
/// every term is the branch's own flow's, on its side: a side opening reads the main flow's static pressure, as a
/// pressure tap does, not its stagnation (2.4 gives the branch the main flow's dynamic pressure).
#[derive(Clone, Copy, Debug)]
struct Join {
    up: Side,
    down: Side,
    recovery: f64,
    lagged: f64,
    branch: bool,
}

/// The energy's account, summed since it began (erg): the energy now, what the losses took, what the lungs gave, what
/// the sources gave (the noise, the pressure jets recover, any 2.4 drop that would give), what the volumes' change gave
/// (the walls' and folds' motion, the noise's monopoles), the geometry's work; and the identity's worst residual, the
/// energy's peak.
#[derive(Clone, Debug, Default)]
pub struct EnergyAccount {
    pub energy: f64,
    pub losses: f64,
    pub lungs: f64,
    pub sources: f64,
    pub volumes: f64,
    pub geometry: f64,
    pub worst_residual: f64,
    pub peak: f64,
}

#[derive(Clone)]
pub struct PassiveModel {
    pub time_step: f64,
    pub rate_hz: f64,
    /// The air the walls' motion displaces, a volume source where they move (off). Real, but 2.4's sections slide along
    /// the tract as its centre line moves, so that a section's volume changes as much by its sliding as by its walls'
    /// moving; taken from them, its sources and sinks at neighbouring nodes sounded as pops at every contact of the tongue
    /// (research/VOCAL_TRACT_PASSIVE_CORE.md). On again with the area function in fixed coordinates.
    pub displaced_volume: bool,
    /// The pressure recovered past a sudden widening as momentum's balance gives it (off): the Borda-Carnot equation,
    /// rho v^2 r (1 - r) for the narrower area over the wider r, 2r/(1 + r) of Bernoulli's lossless recovery. Right for
    /// one sudden expansion; but 2.4's stepped tube draws a smooth diffuser as many small steps, each of which it would
    /// then recover nearly whole, more than a diffuser does -- the reading clicked at a closure with it. Off, 2.4's
    /// fixed fraction (a half in the tract, the whole at a branch), until a diffuser is taken as one.
    pub borda_carnot: bool,
    /// The air the folds' motion displaces (off). Real, but its rate is the glottal area's, and 2.4's kinematic glottis
    /// gives that area hard corners where its slices meet and starts at full swing: taken from it, the folds' air is
    /// broadband where real folds, meeting through yielding tissue and gathering their swing over cycles, are not -- an
    /// onset heard as a click, a high band brighter than measured voices'. On again with a glottis whose contact is
    /// soft (research/VOCAL_TRACT_PASSIVE_CORE.md).
    pub folds_displace: bool,
    /// The recovered pressure reached as the jet reattaches (on); off, at once and within the step, as 2.4 takes it.
    /// At once, the recovery is a negative resistance that answers any frequency: with the tube resolved, JD2's /a/ and
    /// /u/ and W02's /a/ then grow a mode near 48 kHz past the epilarynx's widening and run away, at every rate tried
    /// (5, 10, 20 steps a sample) -- a Strouhal number (f D / U) near 30, where the quasi-steady recovery has no ground
    /// (it asks St << 1; Howe 1979, "On the theory of unsteady high Reynolds number flow through a circular aperture",
    /// Proc. R. Soc. Lond. A 366 205-223, doi:10.1098/rspa.1979.0048: the flow's part in an aperture's response
    /// vanishes as St grows). 2.4's network carries no such mode there, which is why it stands.
    pub reattachment: bool,
    /// The air's velocity held as the glottis's area changes (on: Euler's equation, rho dv/dt = -dp/dx, walls moving
    /// across the flow changing v only through the pressure, so that the glottis's flow follows its area); off, its
    /// volume flow held, as 2.4 holds it (the area's rate of change dropped from the momentum equation).
    pub glottal_velocity_held: bool,
    /// The elements' volume flows held as their areas change (on), as 2.4 holds its currents: 2.4's tract sections are
    /// not fixed walls but a resampling of the area function along a centre line that moves with the tongue and lips,
    /// so that they slide along the tract, and an element's momentum is no fixed body of air's -- Euler's argument
    /// for holding the velocity, walls moving across the flow, holds at the glottis (glottal_velocity_held) and not
    /// here, where holding it sounded the frames' joins as clicks.
    pub tract_flow_held: bool,
    /// The ducts' boundary-layer losses as Zwikker and Kosten's law gives them, OpenWInD's diffusive representation of
    /// it on each element's radius (on, `fitted_law` off: VocalWind 4.0's first step, research/
    /// VOCAL_TRACT_REALTIME_PLAN.md, 6); on with `fitted_law`, the default, the branches carry 2.4's two laws with
    /// their frequency left in; off, 2.4's laws (losses=2.4: a section's resistance the larger of a DC and an AC law,
    /// the AC at 2250 Hz; no thermal loss). The viscous: OpenWInD's branches on every flow node, each a resistance and
    /// an inertance in parallel, beside Poiseuille's resistance, centred as the edges' own resistances are. The
    /// glottis and the sinuses' necks keep 2.4's laws. This switch the viscous half, `thermal_layer` the thermal;
    /// losses=zk both. Checked: the tract's
    /// transfer within 0.1 cents and 0.5% in bandwidth of Zwikker and Kosten's exact viscous law (examples/
    /// vocalfork_transfer.rs, research/vocal-tract-passive-core/losses.py).
    pub viscous_layer: bool,
    /// The boundary layer's thermal half (above, `viscous_layer`; losses=thermal alone): OpenWInD's branches at every
    /// node, one set for each element's share of the node (an end node two, each with its element's radius) -- the
    /// isothermal excess c_0 = (gamma - 1) V / rho c^2 of the share's air, charged through a conductance and eight
    /// conductance-compliance branches. Stepped by the implicit midpoint, in closed form (a share answers the pressure
    /// it sees with the flux y v + h: `lay`, `thermal_answers`, `thermal_step`), in the form proved passive in the
    /// fourth-order step (research/VOCALWIND_BOUNDARY_LAYER.md, F): the branches see the node's corrected pressure,
    /// its mean over the step, and the correction divides by the node's own implicit compliance, M_p + dt y / 2
    /// (`own`). The step's energy with them (`energy`) then falls by the losses exactly and is positive under the
    /// step's present limit; the scheme with the branches on the node's own pressure and M_p in the correction
    /// (OpenWInD's as published, in this step) can grow.
    pub thermal_layer: bool,
    /// The boundary layer's losses on each section's own circumference (on; circumference=0 its equal-area circle's,
    /// kept for comparisons): its wall against its equal-area
    /// circle's (the mean over the section of the tract's cross-sections': `TubeCoefficients::shape`), the two laws
    /// then on the section's hydraulic radius 2 A / P, its area kept for its inertance and compliance. A boundary
    /// layer's loss is the wall's, and a circle has the least wall for its area: Rucz, Esteve Fontestad, Angster &
    /// Miklós 2025 ("Wall losses in straight ducts with non-circular cross sections", Acta Acustica 9, 10,
    /// doi:10.1051/aacus/2024084), the scaling exact where the layer is thin and checked against 3D finite elements
    /// to 1%; where the layer fills the section the hydraulic radius gives a slit two thirds of its steady
    /// resistance, the equal-area circle a small part of it. 2.4's sections have 1.16 to 1.27 times a circle's wall
    /// at the median, up to 2.9 at the flattest. Held to measured tracts, the Dresden Vocal Tract Dataset's printed
    /// vowels: nearer their bandwidths than the circle in 29 of 30 at the first resonance (0.60 of them against 0.47;
    /// research/VOCALWIND_BOUNDARY_LAYER.md, "The Dresden check"), and on since (the owner, 13 November 2026, of "on,
    /// wherever the boundary layer is on": "ok, sounds fine"). It acts on the boundary layer's laws alone: with 2.4's
    /// losses nothing changes. The pharynx's and the mouth's sections have shapes; the trachea's, the nose's and the
    /// fossa's are circles still (2.4 has none for them). The yielding walls' surface stays the equal-area circle's,
    /// as 2.4's.
    pub own_circumference: bool,
    /// The ducts' losses by 2.4's two laws with their frequency left in (VocalWind 4.0's losses=fitted; the owner, 14
    /// November 2026, of the law between 2.4's and the smooth wall's: "this sounds correct"): the DC law the resistance
    /// at low frequencies, the AC law R_ac (A_ref / A) sqrt(f) at high ones -- as their authors fitted them to printed
    /// tubes' bandwidths (P. Birkholz & P. Häsner 2026, "Viscous and kinetic losses in transmission-line models of the
    /// vocal tract", IEEE Access 14, 133468-133479, doi:10.1109/ACCESS.2026.3728208), where 2.4 holds the AC law at
    /// 2250 Hz -- joined as a boundary layer joins Poiseuille's flow to its thin layer, and causal: OpenWInD's
    /// representation U r(j w tau) on the viscous branches (`viscous_layer`, on with it; no thermal loss), U a_0 the DC
    /// law and 2 U sqrt(tau) the AC law's K, K sqrt(j w) a resistance R_ac and as much reactance -- an added mass some
    /// 0.9 / sqrt(f) of the air's, 4% at 500 Hz (`fitted_scale`). On each section's area alone, as the laws were
    /// fitted: not its circumference. The glottis and the sinuses' necks keep 2.4's laws. Checked: the tract's
    /// transfer against the law's exact chain (research/vocal-tract-passive-core/losses.py `fitted_loss`;
    /// examples/vocalfork_transfer.rs). Held to measured tracts (research/VOCALWIND_BOUNDARY_LAYER.md): the Dresden
    /// dataset's printed vowels' first two resonances 0.91 and 1.14 of their bandwidths at the median (2.4's laws 2.05
    /// and 1.44, the smooth wall's 0.60 and 0.82), 22 and 14 cents under their frequencies (2.4's 11 and 6 over, the
    /// smooth wall's 11 and 6 under); living tracts' bandwidths, Fant's formulas for them at 2.4's speakers' vowels'
    /// own resonances, 0.85, 0.95 and 0.80 of the first three for men and 0.83, 0.93 and 0.74 for a woman (2.4's laws
    /// 1.16, 1.06 and 0.76; 1.16, 1.02 and 0.66). The default (the owner, 14 November 2026, of making it the default in
    /// place of 2.4's laws: "yes, seems good to me"); losses=2.4 gives 2.4's laws, kept for comparisons.
    pub fitted_law: bool,
    /// The radiation at the lips and the nostrils (`radiation=`): None, VocalTractLab 2.4's piston, as the tube's
    /// coefficients carry it (tds.rs `radiation`); or an opening's radiation in OpenWInD's Pade form, by its category's
    /// Taylor coefficients (delta, betaC: acoustics/radiation.json) -- VocalWind 4.0's step 2 (the owner, 16 November
    /// 2026: "yes, this seems fine to me").
    pub radiation_law: Option<(f64, f64)>,
    /// The walls' tissue (`tissue=`): their mass, damping and stiffness per unit area each VocalTractLab 2.4's
    /// (acoustics/tract.json, `walls`) times these -- (1, 1, 1), 2.4's own for every speaker, where none is asked; a
    /// woman's walls as Fant measured them, a blended body's weighed from its speakers', or walls held rigid for checks
    /// (`tissue_factors`; research/VOCALWIND_BOUNDARY_LAYER.md, "The living tract's losses": the owner, 16 November
    /// 2026, "Good; proceed").
    pub wall_tissue: (f64, f64, f64),
    /// The ducts' surfaces (`surfaces=`): the viscous boundary layer's impedance times this, its resistances and its
    /// masses alike, under either law (the fitted, or Zwikker and Kosten's; the thermal half, whose low-frequency limit
    /// is the air's own, untouched) -- 1, the law as it is, where none is asked; more where a real tract's surfaces lose
    /// more (Birkholz, Blandin & Kurbis 2023: printed tracts from MRI up to 67% wider than printed tubes; Fant 1972
    /// doubled a smooth wall's). Its feasible range in acoustics/tract.json (`free.surfaces`); what sets it, a fit
    /// (src/fitting.rs; research/VOCALWIND_FITS.md).
    pub surfaces: f64,
    /// The cores a synthesizer steps it over (`cores=`; 1, the default, the calling thread alone): from rest, its
    /// network cut into so many parts of about equal cost, each stepped on a thread of its own (parallel::Crew; the
    /// owner, 14 November 2026: "Ok, proceed with multicore ..."), its outputs to the bit what one core gives. Not
    /// with the thermal half of the boundary layer nor the energy's account, which step on one core.
    pub cores: usize,
    /// Where it is stepped over several cores, how long the main thread, waiting on the crew, leaves a stage of a part
    /// whose thread is awake untaken that it could take, before it steps it itself (`help=`, in spins: 1, the
    /// default, parallel::HELP; eager, none; N, N), as it does at once where the part's thread sleeps; help=0, never
    /// (the crew as it was first built, for comparisons). The same bytes whichever thread steps a part.
    pub help: Option<u32>,
    /// How its trachea is laid (Options::fork_trachea as it was built): the network's own, fixed with it.
    trachea: Trachea,
    /// The noise: 2.4's own sources, stepped from this model's flows; its options are this model's.
    pub noise: TdsModel,
    pub account: Option<Box<EnergyAccount>>,
    elements: Vec<Element>,
    edges: Vec<Edge>,
    joins: Vec<Join>,
    first_element: Vec<usize>,
    last_element: Vec<usize>,
    trachea_top: usize,
    pharynx_bottom: usize,
    glottis_edge: usize,
    /// The radiation at the mouth and the nostrils: its inductance's edge, the last element, its end node (holding no
    /// air), its resistance this step, the lips' dipole in it (2.4's source in its radiation), and its end's pressure.
    radiation: [usize; 2],
    radiating: [(usize, usize); 2],
    resistance: [f64; 2],
    end_source: [f64; 2],
    end_pressure: [f64; 2],
    /// The edges the radiation's ends solve together (each end's element's two and its inductance).
    in_block: Vec<bool>,
    neck: [usize; tube::NUM_SINUS_SECTIONS],
    cavity: [usize; tube::NUM_SINUS_SECTIONS],
    /// The walls' edges of the skin's nodes -- the pharynx's, mouth's and nose's -- in the nodes' order (2.4's radiation
    /// from the skin, summed in that order).
    skin_walls: Vec<usize>,
    walls: Walls,
    fe_edges: usize,
    // nodes
    mp: Vec<f64>,
    q: Vec<f64>,
    q_prev: Vec<f64>,
    p: Vec<f64>,
    pt: Vec<f64>,
    acc: Vec<f64>,
    vol: Vec<f64>,
    vol_prev: Vec<f64>,
    surf: Vec<f64>,
    f: Vec<f64>,
    f_prev: Vec<f64>,
    // edges
    mu: Vec<f64>,
    r: Vec<f64>,
    cpos: Vec<f64>,
    cneg: Vec<f64>,
    /// Each element's joins' Bernoulli terms, on its mean flow m (the flow through its section): a drop c |m| m, half on
    /// each of its two flow nodes, so that its own internal mode (the two nodes against each other, which 2.4's
    /// network has not) takes no part in them. c for m forward, and back.
    jpos: Vec<f64>,
    jneg: Vec<f64>,
    src: Vec<f64>,
    pi: Vec<f64>,
    u: Vec<f64>,
    um: Vec<f64>,
    used: Vec<f64>,
    force: Vec<f64>,
    tmp: Vec<f64>,
    glottis: ([f64; 2], [f64; 2]),
    glottis_volume: f64,
    lungs: f64,
    /// Steps at which an edge's net negative quadratic term outweighed its inertia (none but with `reattachment` off).
    pub overwhelmed: u64,
    /// The first edges that did, each with its flow, its net c and its beta then (for diagnosis).
    pub overwhelmed_at: Vec<(usize, f64, f64, f64)>,
    started: bool,
    flows: Vec<f64>,
    /// (Diagnosis: a volume flow into the pharynx's first node, cm^3/s, this step -- the tract's transfer measured from
    /// it, the glottis shut.)
    pub injected: f64,
    // The boundary layer's (viscous_layer, thermal_layer): each flow node's viscous branches, their resistances and
    // inertances and the momenta they carry (at the half step) and their flows as last stepped. Each element's
    // thermal share at each of its three nodes (3 e + m; none at the lungs' node nor at a radiating end, whose share
    // its element's middle node takes): its isothermal excess c_0 and its conductances' unit this step (g_0 = unit
    // a_0, g_i = unit a_i / b_i; c_i = c_0 a_i); what its midpoint step answers a pressure with (y, each branch's
    // gh_i, and h from what it holds); the charges its branches carry (c_0 P0, then each c_i P_i) now and a step
    // before. Each node's y (its shares' sum), its implicit compliance (`own`, M_p + dt y / 2), the flux its
    // branches last took and their answer h this step; the branches' loss last step (over dt), and the corrected
    // pressures kept from the step's start.
    vr: Vec<[f64; DIFFUSIVE_N]>,
    vl: Vec<[f64; DIFFUSIVE_N]>,
    vmom: Vec<[f64; DIFFUSIVE_N]>,
    vflow: Vec<[f64; DIFFUSIVE_N]>,
    /// What the centred step takes of each viscous branch, kept while its element stands (`laid`): r kappa (kappa =
    /// (l/dt) / (l/dt + r/2)), l/dt - r/2 and l/dt + r/2, each an edge's eight together; and each edge's sum of r kappa.
    vrk: Vec<[f64; DIFFUSIVE_N]>,
    vlow: Vec<[f64; DIFFUSIVE_N]>,
    vhigh: Vec<[f64; DIFFUSIVE_N]>,
    vpsi: Vec<f64>,
    tc0: Vec<f64>,
    tunit: Vec<f64>,
    ty: Vec<f64>,
    tgh: Vec<[f64; DIFFUSIVE_N]>,
    /// Each share's branches' compliances (c_0, then each c_0 a_i) and its conductances' sum Gh, kept likewise.
    tci: Vec<[f64; THERMAL_N]>,
    tsum: Vec<f64>,
    th: Vec<f64>,
    ts: Vec<[f64; THERMAL_N]>,
    ts_prev: Vec<[f64; THERMAL_N]>,
    own: Vec<f64>,
    node_y: Vec<f64>,
    node_h: Vec<f64>,
    node_flux: Vec<f64>,
    thermal_lost: f64,
    pt_start: Vec<f64>,
    /// What each element's coefficients were last laid from -- its section's area, its half length, its wall's shape,
    /// the step and the losses' switches, as bits -- and whether this step laid them again: an element whose section
    /// stands (the trachea's, the nose's and the fossa's always; the pharynx's and mouth's while the tract is still)
    /// keeps them, bit for bit what laying them again would give.
    laid: Vec<[u64; 5]>,
    fresh: Vec<bool>,
    /// Each element laid again since its held flows were last put back in its momenta (tract_flow_held): only there
    /// does putting them back change anything, every other's momenta, and its viscous branches', being the held flows'
    /// own bit for bit (each made at the step's end as its mass times its flow, the masses laid since unchanged).
    relaid: Vec<bool>,
    circ: Vec<f64>,
    /// Each element's area and half length as last laid, and each node's parts of its elements' air -- (element, its
    /// node m), in the elements' order -- that its volume and surface are summed from (`parts[parts_from[n]..parts_from[n
    /// + 1]]`); the nodes whose air is to be summed again this step, an element at them or their sinus laid again
    /// (`touched`, each marked in `dirty`); each node's wall's edge (NONE where it has none); and whether the nodes'
    /// thermal y may stand other than 0 (the thermal branches on when last laid).
    laid_a: Vec<f64>,
    laid_j: Vec<f64>,
    parts_from: Vec<usize>,
    parts: Vec<(usize, usize)>,
    touched: Vec<usize>,
    dirty: Vec<bool>,
    wall_edge: Vec<usize>,
    node_y_live: bool,
    /// Likewise what each node's compliance, each wall's edge, each join's coefficient and reattachment length and
    /// each sinus's neck and surface were last laid from (the node's volume, the wall's surface, the join's two areas,
    /// the sinus's volume, neck area and neck length, as bits), and what the joins and the sinuses keep.
    vol_laid: Vec<u64>,
    wall_laid: Vec<u64>,
    join_laid: Vec<[u64; 2]>,
    join_c: Vec<f64>,
    join_length: Vec<f64>,
    sinus_laid: [[u64; 3]; tube::NUM_SINUS_SECTIONS],
    sinus_surf: [f64; tube::NUM_SINUS_SECTIONS],
}

fn viscous_per_length(a: f64) -> f64 {
    // 2.4's section resistance per unit length (TdsModel's section_coefficients: the larger of its DC and AC laws)
    let dc = DC_R0 * (REF_AREA_CM2 / a).powf(DC_EXPONENT);
    let ac = AC_R0 * if AC_EXPONENT == 1.0 { REF_AREA_CM2 / a } else { (REF_AREA_CM2 / a).powf(AC_EXPONENT) } * AC_FREQUENCY_HZ.sqrt();
    dc.max(ac)
}

/// What an edge's viscous branches add to its drive from the momenta `mom` they hold (PassiveModel::viscous_terms):
/// sum_i r_i kappa_i v_i, v_i = mom_i / l_i. (Free of the model, each array its own, so that the compiler may take
/// the eight together.)
fn branches_drive(rk: &[f64; DIFFUSIVE_N], mom: &[f64; DIFFUSIVE_N], l: &[f64; DIFFUSIVE_N]) -> f64 {
    let mut drive = 0.0;
    for i in 0..DIFFUSIVE_N {
        drive += rk[i] * mom[i] / l[i];
    }
    drive
}

/// An edge's viscous branches stepped from its centred flow `um` (PassiveModel::viscous_step): each branch's momentum
/// and flow, and their losses over the step, over dt, where `LOSS` asks for them.
fn branches_step<const LOSS: bool>(
    um: f64,
    r: &[f64; DIFFUSIVE_N],
    l: &[f64; DIFFUSIVE_N],
    low: &[f64; DIFFUSIVE_N],
    high: &[f64; DIFFUSIVE_N],
    mom: &mut [f64; DIFFUSIVE_N],
    flow: &mut [f64; DIFFUSIVE_N],
) -> f64 {
    let mut loss = 0.0;
    for i in 0..DIFFUSIVE_N {
        let v0 = mom[i] / l[i];
        let v1 = (low[i] * v0 + r[i] * um) / high[i];
        if LOSS {
            let d = um - 0.5 * (v0 + v1);
            loss += r[i] * d * d;
        }
        mom[i] = l[i] * v1;
        flow[i] = v1;
    }
    loss
}

/// The fitted law's longest scale (`fitted_law`), s: the representation's reach at 20 kHz -- it follows Zwikker and
/// Kosten's term within 1% to a scaled frequency of 1e6, 7% at 3e6 (research/vocal-tract-passive-core/losses.py).
const FITTED_TAU_MOST: f64 = 1.0e6 / (2.0 * PI * 20000.0);

/// The fitted law's size U and scale tau on a section of area `a` (`fitted_law`): its loss per unit length U r(j w tau),
/// r OpenWInD's representation -- U a_0 2.4's DC law, 2 U sqrt(tau) the AC law's K, K sqrt(j w) its resistance
/// R_ac (A_ref / A) sqrt(f). tau at most FITTED_TAU_MOST: in a section wider than some 3 cm^2 the resistance below a
/// hertz then over the DC law's, unheard.
fn fitted_scale(a: f64) -> (f64, f64) {
    let dc = DC_R0 * (REF_AREA_CM2 / a).powf(DC_EXPONENT);
    let k = AC_R0 * if AC_EXPONENT == 1.0 { REF_AREA_CM2 / a } else { (REF_AREA_CM2 / a).powf(AC_EXPONENT) } / PI.sqrt();
    let tau = (4.0 * k / dc).powi(2).min(FITTED_TAU_MOST);
    (k / (2.0 * tau.sqrt()), tau)
}

/// A thermal share's midpoint step from its isothermal excess c_0 and its conductances' unit: each branch's gh_i, the
/// branches' compliances (c_0, then each c_0 a_i), the conductances' sum Gh and the share's y.
fn thermal_share(c0: f64, unit: f64, dt: f64) -> ([f64; DIFFUSIVE_N], [f64; THERMAL_N], f64, f64) {
    let (mut gh, mut ci) = ([0.0; DIFFUSIVE_N], [c0; THERMAL_N]);
    let mut sum = unit * DIFFUSIVE_A0;
    for i in 0..DIFFUSIVE_N {
        gh[i] = 1.0 / (DIFFUSIVE_B[i] / (unit * DIFFUSIVE_A[i]) + 0.5 * dt / (c0 * DIFFUSIVE_A[i]));
        ci[1 + i] = c0 * DIFFUSIVE_A[i];
        sum += gh[i];
    }
    (gh, ci, sum, 1.0 / (1.0 / sum + 0.5 * dt / c0))
}

/// 2.4's Bernoulli drop over a join for the flow from `up` into `down` (areas), as a coefficient of the flow squared:
/// the whole where it narrows, `widening` of it (negative: recovered) where it widens.
fn drop_term(up: f64, down: f64, widening: f64) -> f64 {
    let d = 1.0 / (down * down) - 1.0 / (up * up);
    if down < up {
        d
    } else {
        widening * d
    }
}

impl PassiveModel {
    /// The network for a tube laid out as `template` (its static sections' lengths: the trachea's, the nose's, the
    /// fossa's; the speaker's), at 48 kHz until set_rate.
    pub fn new(template: &Tube, options: Options) -> PassiveModel {
        // (each duct's elements laid from its first section's start, each section's end node kept)
        struct Laying<'a> {
            template: &'a Tube,
            trachea: Trachea,
            elements: Vec<Element>,
            n_nodes: usize,
            first_element: Vec<usize>,
            last_element: Vec<usize>,
            ends: Vec<usize>,
        }
        impl Laying<'_> {
            fn duct(&mut self, range: std::ops::RangeInclusive<usize>, start: usize) -> usize {
                let mut node = start;
                for i in range {
                    let moving = (tube::FIRST_PHARYNX_SECTION..=tube::LAST_MOUTH_SECTION).contains(&i);
                    let trachea = (tube::FIRST_TRACHEA_SECTION..=tube::LAST_TRACHEA_SECTION).contains(&i);
                    let longest = match self.trachea {
                        Trachea::Sections if trachea => f64::INFINITY,
                        Trachea::Finer(cm) if trachea => cm,
                        _ => MAX_ELEMENT_CM,
                    };
                    let parts = if moving { 1 } else { ((self.template.section[i].length_cm / longest) - 1e-9).ceil().max(1.0) as usize };
                    for _ in 0..parts {
                        let nodes = [node, self.n_nodes, self.n_nodes + 1];
                        self.n_nodes += 2;
                        if self.first_element[i] == NONE {
                            self.first_element[i] = self.elements.len();
                        }
                        self.last_element[i] = self.elements.len();
                        self.elements.push(Element { section: i, parts, nodes });
                        node = nodes[2];
                    }
                    self.ends[i] = node;
                }
                node
            }
        }
        if let Trachea::Finer(cm) = options.fork_trachea {
            assert!(cm.is_finite() && cm > 0.0, "the trachea's elements' length must be a positive number of centimetres, not {cm}");
        }
        let mut lay = Laying { template, trachea: options.fork_trachea, elements: Vec::new(), n_nodes: 1, first_element: vec![NONE; NUM_SECTIONS], last_element: vec![NONE; NUM_SECTIONS], ends: vec![NONE; NUM_SECTIONS] };
        let trachea_top = lay.duct(tube::FIRST_TRACHEA_SECTION..=tube::LAST_TRACHEA_SECTION, LUNGS);
        let pharynx_bottom = lay.n_nodes;
        lay.n_nodes += 1;
        let lips = lay.duct(tube::FIRST_PHARYNX_SECTION..=tube::LAST_MOUTH_SECTION, pharynx_bottom);
        let fossa_at = tube::FIRST_PHARYNX_SECTION + tube::FOSSA_COUPLING_SECTION;
        lay.duct(tube::FIRST_FOSSA_SECTION..=tube::LAST_FOSSA_SECTION, lay.ends[fossa_at]);
        let nostrils = lay.duct(tube::FIRST_NOSE_SECTION..=tube::LAST_NOSE_SECTION, lay.ends[tube::LAST_PHARYNX_SECTION]);
        let Laying { elements, mut n_nodes, first_element, last_element, ends, .. } = lay;
        let mut cavity = [0; tube::NUM_SINUS_SECTIONS];
        for c in cavity.iter_mut() {
            *c = n_nodes;
            n_nodes += 1;
        }
        // the skin: the pharynx's, mouth's and nose's nodes (2.4's radiation from them)
        let mut skin = vec![false; n_nodes];
        for el in &elements {
            let s = el.section;
            if (tube::FIRST_PHARYNX_SECTION..=tube::LAST_MOUTH_SECTION).contains(&s) || (tube::FIRST_NOSE_SECTION..=tube::LAST_NOSE_SECTION).contains(&s) {
                for &n in &el.nodes {
                    skin[n] = true;
                }
            }
        }
        let fe_edges = 2 * elements.len();
        let mut edges = vec![Edge { kind: Kind::Glottis, from: trachea_top, to: pharynx_bottom }];
        let mut neck = [0; tube::NUM_SINUS_SECTIONS];
        for n in 0..tube::NUM_SINUS_SECTIONS {
            neck[n] = fe_edges + edges.len();
            edges.push(Edge { kind: Kind::Neck(tube::FIRST_SINUS_SECTION + n), from: ends[tube::FIRST_NOSE_SECTION + tube::SINUS_COUPLING_SECTION[n]], to: cavity[n] });
        }
        let mut radiation = [0; 2];
        for (w, end) in [lips, nostrils].into_iter().enumerate() {
            radiation[w] = fe_edges + edges.len();
            edges.push(Edge { kind: Kind::Inductance(w), from: end, to: ATMOSPHERE });
        }
        let radiating = [(last_element[tube::LAST_MOUTH_SECTION], lips), (last_element[tube::LAST_NOSE_SECTION], nostrils)];
        // each node's wall, a node of its own (its spring) and an edge (its mass and damping)
        let mut wall_edge = vec![NONE; n_nodes];
        let (acoustic, first_wall) = (n_nodes, edges.len());
        if options.soft_walls {
            for node in 1..acoustic {
                if node == lips || node == nostrils {
                    continue;
                }
                wall_edge[node] = fe_edges + edges.len();
                edges.push(Edge { kind: Kind::Wall, from: node, to: n_nodes });
                n_nodes += 1;
            }
        }
        skin.resize(n_nodes, false);
        wall_edge.resize(n_nodes, NONE);
        let skin_walls = (0..n_nodes).filter(|&n| wall_edge[n] != NONE && skin[n]).map(|n| wall_edge[n]).collect();
        let walls = Walls { first: first_wall, acoustic, from: edges[first_wall..].iter().map(|e| e.from).collect() };
        // each node's parts of its elements' air, in the elements' order
        let mut parts_from = vec![0; n_nodes + 1];
        for el in &elements {
            for &n in &el.nodes {
                parts_from[n + 1] += 1;
            }
        }
        for n in 0..n_nodes {
            parts_from[n + 1] += parts_from[n];
        }
        let mut parts = vec![(0, 0); parts_from[n_nodes]];
        let mut next = parts_from.clone();
        for (e, el) in elements.iter().enumerate() {
            for (m, &n) in el.nodes.iter().enumerate() {
                parts[next[n]] = (e, m);
                next[n] += 1;
            }
        }
        // the joins: within each duct, and where the fossa, the nose and the sinuses branch
        let side = |i: usize, at_end: bool| -> Side { Side { section: i, edge: 2 * if at_end { last_element[i] } else { first_element[i] }, count: 2 } };
        let mut branching = vec![fossa_at, tube::LAST_PHARYNX_SECTION];
        branching.extend(tube::SINUS_COUPLING_SECTION.iter().map(|k| tube::FIRST_NOSE_SECTION + k));
        let recovery = |i: usize| if branching.contains(&i) { 1.0 } else { TRACT_RECOVERY_COEFF };
        let mut joins = Vec::new();
        for (a, b) in [
            (tube::FIRST_TRACHEA_SECTION, tube::LAST_TRACHEA_SECTION),
            (tube::FIRST_PHARYNX_SECTION, tube::LAST_MOUTH_SECTION),
            (tube::FIRST_NOSE_SECTION, tube::LAST_NOSE_SECTION),
            (tube::FIRST_FOSSA_SECTION, tube::LAST_FOSSA_SECTION),
        ] {
            for i in a..b {
                joins.push(Join { up: side(i, true), down: side(i + 1, false), recovery: recovery(i), lagged: 0.0, branch: false });
            }
        }
        joins.push(Join { up: side(fossa_at, true), down: side(tube::FIRST_FOSSA_SECTION, false), recovery: 1.0, lagged: 0.0, branch: true });
        joins.push(Join { up: side(tube::LAST_PHARYNX_SECTION, true), down: side(tube::FIRST_NOSE_SECTION, false), recovery: 1.0, lagged: 0.0, branch: true });
        for n in 0..tube::NUM_SINUS_SECTIONS {
            let k = tube::FIRST_NOSE_SECTION + tube::SINUS_COUPLING_SECTION[n];
            joins.push(Join { up: side(k, true), down: Side { section: tube::FIRST_SINUS_SECTION + n, edge: neck[n], count: 1 }, recovery: 1.0, lagged: 0.0, branch: true });
        }
        let n_edges = fe_edges + edges.len();
        let mut in_block = vec![false; n_edges];
        for (w, &(e, _)) in radiating.iter().enumerate() {
            in_block[2 * e] = true;
            in_block[2 * e + 1] = true;
            in_block[radiation[w]] = true;
        }
        let mut noise = TdsModel::new();
        noise.options = options;
        let (n_elements, n_joins) = (elements.len(), joins.len());
        let mut m = PassiveModel {
            time_step: 1.0 / AUDIO_SAMPLING_RATE_HZ as f64,
            rate_hz: AUDIO_SAMPLING_RATE_HZ as f64,
            displaced_volume: false,
            folds_displace: false,
            borda_carnot: false,
            reattachment: true,
            glottal_velocity_held: true,
            tract_flow_held: true,
            viscous_layer: true,
            thermal_layer: false,
            own_circumference: true,
            fitted_law: true,
            radiation_law: None,
            wall_tissue: (1.0, 1.0, 1.0),
            surfaces: 1.0,
            cores: 1,
            help: Some(parallel::HELP),
            trachea: options.fork_trachea,
            noise,
            account: None,
            elements,
            edges,
            joins,
            first_element,
            last_element,
            trachea_top,
            pharynx_bottom,
            glottis_edge: fe_edges,
            radiation,
            radiating,
            resistance: [0.0; 2],
            end_source: [0.0; 2],
            end_pressure: [0.0; 2],
            in_block,
            neck,
            cavity,
            skin_walls,
            walls,
            fe_edges,
            mp: vec![1.0; n_nodes],
            q: vec![0.0; n_nodes],
            q_prev: vec![0.0; n_nodes],
            p: vec![0.0; n_nodes],
            pt: vec![0.0; n_nodes],
            acc: vec![0.0; n_nodes],
            vol: vec![0.0; n_nodes],
            vol_prev: vec![0.0; n_nodes],
            surf: vec![0.0; n_nodes],
            f: vec![0.0; n_nodes],
            f_prev: vec![0.0; n_nodes],
            mu: vec![1.0; n_edges],
            r: vec![0.0; n_edges],
            cpos: vec![0.0; n_edges],
            cneg: vec![0.0; n_edges],
            jpos: vec![0.0; fe_edges / 2],
            jneg: vec![0.0; fe_edges / 2],
            src: vec![0.0; n_edges],
            pi: vec![0.0; n_edges],
            u: vec![0.0; n_edges],
            um: vec![0.0; n_edges],
            used: vec![0.0; n_edges],
            force: vec![0.0; n_edges],
            tmp: vec![0.0; n_edges],
            glottis: ([0.0; 2], [MIN_AREA_CM2; 2]),
            glottis_volume: 0.0,
            lungs: 0.0,
            overwhelmed: 0,
            overwhelmed_at: Vec::new(),
            started: false,
            flows: vec![0.0; NUM_BRANCH_CURRENTS],
            injected: 0.0,
            vr: vec![[0.0; DIFFUSIVE_N]; fe_edges],
            vl: vec![[1.0; DIFFUSIVE_N]; fe_edges],
            vmom: vec![[0.0; DIFFUSIVE_N]; fe_edges],
            vflow: vec![[0.0; DIFFUSIVE_N]; fe_edges],
            vrk: vec![[0.0; DIFFUSIVE_N]; fe_edges],
            vlow: vec![[0.0; DIFFUSIVE_N]; fe_edges],
            vhigh: vec![[0.0; DIFFUSIVE_N]; fe_edges],
            vpsi: vec![0.0; fe_edges],
            tc0: vec![0.0; 3 * n_elements],
            tunit: vec![0.0; 3 * n_elements],
            ty: vec![0.0; 3 * n_elements],
            tgh: vec![[0.0; DIFFUSIVE_N]; 3 * n_elements],
            tci: vec![[1.0; THERMAL_N]; 3 * n_elements],
            tsum: vec![1.0; 3 * n_elements],
            th: vec![0.0; 3 * n_elements],
            ts: vec![[0.0; THERMAL_N]; 3 * n_elements],
            ts_prev: vec![[0.0; THERMAL_N]; 3 * n_elements],
            own: vec![1.0; n_nodes],
            node_y: vec![0.0; n_nodes],
            node_h: vec![0.0; n_nodes],
            node_flux: vec![0.0; n_nodes],
            thermal_lost: 0.0,
            pt_start: vec![0.0; n_nodes],
            laid: vec![[u64::MAX; 5]; n_elements],
            fresh: vec![true; n_elements],
            relaid: vec![true; n_elements],
            circ: vec![0.0; n_elements],
            laid_a: vec![0.0; n_elements],
            laid_j: vec![0.0; n_elements],
            parts_from,
            parts,
            touched: Vec::with_capacity(n_nodes),
            dirty: vec![false; n_nodes],
            wall_edge,
            node_y_live: false,
            vol_laid: vec![u64::MAX; n_nodes],
            wall_laid: vec![u64::MAX; n_edges - fe_edges],
            join_laid: vec![[u64::MAX; 2]; n_joins],
            join_c: vec![0.0; n_joins],
            join_length: vec![0.0; n_joins],
            sinus_laid: [[u64::MAX; 3]; tube::NUM_SINUS_SECTIONS],
            sinus_surf: [0.0; tube::NUM_SINUS_SECTIONS],
        };
        m.set_rate(AUDIO_SAMPLING_RATE_HZ as f64);
        m
    }

    /// VocalFork for a speaker's tract (as its anatomy has it) and glottis: the network laid out on the tube of the
    /// tract's neutral shape (its static ducts' lengths, the speaker's; its trachea as `options` asks,
    /// layout_switches), and the steps a 48-kHz sample its physics asks over every shape of the speaker, the glottis at
    /// its widest (steps_needed).
    pub fn for_speaker(tract: &VocalTract, glottis: &Glottis2025, options: Options) -> (PassiveModel, usize) {
        let mut t = tract.clone();
        let tube_of = |t: &mut VocalTract, params: &[f64]| -> Tube {
            t.calculate(params);
            let mut tube = Tube::new();
            tube.set_from_tract(&t.tube());
            tube
        };
        let neutral: Vec<f64> = t.param.iter().map(|p| p.neutral).collect();
        let template = tube_of(&mut t, &neutral);
        let mut model = PassiveModel::new(&template, options);
        let mut g = glottis.clone();
        g.calc_geometry();
        let (lengths, _) = g.tube_data();
        let shapes: Vec<Vec<f64>> = tract.shapes.iter().map(|(_, v)| v.to_vec()).collect();
        let mut most = 1;
        for v in shapes.iter().chain(std::iter::once(&neutral)) {
            let tube = tube_of(&mut t, v);
            let mut tds = TdsModel::new();
            tds.options = options;
            tds.set_tube(&tube, false);
            let mut k = TubeCoefficients::default();
            tds.tube_coefficients(&mut k);
            most = most.max(model.steps_needed(&k, &lengths));
        }
        (model, most)
    }

    /// A widening's recovered fraction of Bernoulli's lossless recovery (borda_carnot; else 2.4's `fixed`).
    fn recovered(&self, fixed: f64, narrow: f64, wide: f64) -> f64 {
        if self.borda_carnot {
            let r = narrow / wide;
            2.0 * r / (1.0 + r)
        } else {
            fixed
        }
    }

    /// Which acoustics a renderer's key=value arguments ask (the owner, 16 November 2026, of VocalFork's and
    /// VocalWind's names used for one another: "I want to avoid confusion between the earlier VocalFork and later
    /// VocalWind"; the names' design approved that day): acoustics=vocalwind, the passive core with its fitted wall-loss
    /// law -- VocalWind 4.0's first step, what every score has been sung on -- or acoustics=vocalfork, the same core
    /// with VocalTractLab 2.4's own loss laws, VocalFork 3.0 as it was first built (as `acoustics=vocalwind losses=2.4`);
    /// a losses= given overrides either. -> the switches the core is to take (take_switches, layout_switches), losses=2.4
    /// first where VocalFork is asked and no losses= is; None where neither is asked (2.4's own network).
    pub fn acoustics(args: &[String]) -> Option<Vec<String>> {
        match args.iter().rev().find_map(|a| a.strip_prefix("acoustics="))? {
            "vocalwind" => Some(args.to_vec()),
            "vocalfork" => {
                let own = args.iter().any(|a| a.starts_with("losses="));
                Some((!own).then(|| "losses=2.4".to_string()).into_iter().chain(args.iter().cloned()).collect())
            }
            _ => None,
        }
    }

    /// The name of what `acoustics` gives: "VocalWind 4.0, step 1 of 4" for the fitted law, else "VocalFork 3.0" and
    /// its loss law.
    pub fn named(&self) -> String {
        if self.fitted_law {
            "VocalWind 4.0, step 1 of 4 (the passive core, its fitted wall-loss law)".into()
        } else {
            format!("VocalFork 3.0 (the passive core, {})", if self.viscous_layer || self.thermal_layer { "Zwikker and Kosten's losses" } else { "VocalTractLab 2.4's loss laws" })
        }
    }

    /// The switches that lay the network out, from a renderer's key=value arguments, into the options it is built with
    /// (before PassiveModel::new or for_speaker): trachea=sections|fine|<cm> (Trachea: one element to each of its
    /// sections, the default; as finely as the other static ducts, MAX_ELEMENT_CM; or in elements no longer than so
    /// many centimetres).
    pub fn layout_switches(options: &mut Options, args: &[String]) {
        for a in args {
            if let Some(("trachea", v)) = a.split_once('=') {
                options.fork_trachea = trachea_switch(v);
            }
        }
    }

    /// How its trachea is laid (Trachea): fixed as the network was built.
    pub fn trachea(&self) -> Trachea {
        self.trachea
    }

    /// Its physics' switches from a renderer's key=value arguments, where given: walls=0|1 (the walls' displaced air),
    /// folds=0|1 (the folds'), reattachment=0|1, borda=0|1 (Borda and Carnot's recovery, else 2.4's fixed fraction),
    /// velocity=0|1 (the glottis's velocity held, else its volume flow, as 2.4), tract=0|1 (the elements' volume flows
    /// held), noise=0|1 (2.4's turbulence noise), account=0|1 (the energy's account kept),
    /// losses=zk|viscous|thermal|fitted|2.4 (the ducts' boundary layer as Zwikker and Kosten's law gives it, either half
    /// of it, 2.4's laws with their frequency left in -- the default -- or 2.4's laws), circumference=1|0 (Zwikker and
    /// Kosten's law on each section's own circumference, as it stands, or on its equal-area circle's),
    /// radiation=piston|unflanged|2.4 (`radiation_category`), tissue=men|women|rigid|2.4|R (the walls' tissue by its
    /// name, or R its own resonance over 2.4's: `tissue_factors`), surfaces=S (the ducts' viscous loss law times S),
    /// cores=N (its
    /// step over so many cores, `cores`), help=1|eager|0|N (when the main thread steps a late part itself, `help`). A
    /// trachea= lays the network out (layout_switches, before it is built): here it must be the one it was laid with.
    pub fn take_switches(&mut self, args: &[String]) {
        for a in args {
            let (k, v) = match a.split_once('=') {
                Some(kv) => kv,
                None => continue,
            };
            let on = v == "1";
            match k {
                "trachea" => assert!(
                    trachea_switch(v) == self.trachea,
                    "trachea={v} lays the network out: give it to PassiveModel::layout_switches before the model is built (laid as {:?})",
                    self.trachea
                ),
                "walls" => self.displaced_volume = on,
                "folds" => self.folds_displace = on,
                "reattachment" => self.reattachment = on,
                "borda" => self.borda_carnot = on,
                "noise" => self.noise.options.generate_noise_sources = on,
                "tract" => self.tract_flow_held = on,
                "account" => self.account = if on { Some(Box::default()) } else { None },
                "velocity" => self.glottal_velocity_held = on,
                "losses" => {
                    self.viscous_layer = v == "zk" || v == "viscous" || v == "fitted";
                    self.thermal_layer = v == "zk" || v == "thermal";
                    self.fitted_law = v == "fitted";
                }
                "circumference" => self.own_circumference = on,
                "radiation" => self.radiation_law = radiation_category(v),
                "surfaces" => self.surfaces = v.parse().ok().filter(|s: &f64| *s > 0.0 && s.is_finite()).unwrap_or_else(|| panic!("surfaces={v}: a factor on the ducts' viscous loss, over 0")),
                "tissue" => {
                    self.wall_tissue = tissue_factors(v);
                    // (every wall laid again at its next step, its new tissue's)
                    self.wall_laid.iter_mut().for_each(|b| *b = u64::MAX);
                }
                "cores" => self.cores = v.parse().ok().filter(|&n: &usize| n >= 1).unwrap_or_else(|| panic!("cores={v}: a number of cores, 1 or more")),
                "help" => {
                    self.help = match v {
                        "1" => Some(parallel::HELP),
                        "eager" => Some(0),
                        "0" => None,
                        _ => Some(v.parse().ok().filter(|&n: &u32| n > 1).unwrap_or_else(|| panic!("help={v}: 1, eager, 0 or a number of spins"))),
                    }
                }
                _ => {}
            }
        }
    }

    /// Stepped at `rate_hz` from here on (its motion at rest).
    pub fn set_rate(&mut self, rate_hz: f64) {
        self.rate_hz = rate_hz;
        self.time_step = 1.0 / rate_hz;
        self.noise.set_rate(rate_hz);
        self.reset_motion();
    }

    /// Every content, flow, lag and source at rest; the noise's generator seeded again, as 2.4's.
    pub fn reset_motion(&mut self) {
        for v in [&mut self.q, &mut self.q_prev, &mut self.p, &mut self.pt, &mut self.f, &mut self.f_prev] {
            v.iter_mut().for_each(|x| *x = 0.0);
        }

        for v in [&mut self.pi, &mut self.u, &mut self.um, &mut self.used, &mut self.src] {
            v.iter_mut().for_each(|x| *x = 0.0);
        }
        self.joins.iter_mut().for_each(|j| j.lagged = 0.0);
        self.flows.iter_mut().for_each(|x| *x = 0.0);
        for v in [&mut self.vmom, &mut self.vflow] {
            v.iter_mut().for_each(|x| *x = [0.0; DIFFUSIVE_N]);
        }
        for v in [&mut self.ts, &mut self.ts_prev] {
            v.iter_mut().for_each(|x| *x = [0.0; THERMAL_N]);
        }
        self.node_flux.iter_mut().for_each(|x| *x = 0.0);
        self.thermal_lost = 0.0;
        self.noise.reset_motion();
        self.started = false;
        if let Some(a) = self.account.as_mut() {
            **a = EnergyAccount::default();
        }
    }

    /// The glottis's two sections as the glottis lays them each step (their lengths and areas, cm, cm^2).
    pub fn set_glottis_sections(&mut self, lengths_cm: &[f64; 2], areas_cm2: &[f64; 2]) {
        self.glottis = (*lengths_cm, [areas_cm2[0].max(MIN_AREA_CM2), areas_cm2[1].max(MIN_AREA_CM2)]);
        self.noise.set_glottis_sections(lengths_cm, areas_cm2);
    }

    /// For diagnosis: every edge's flow as last stepped, what it is, and its resistance against its inertance over the
    /// step (R dt / 2M: above 1, the centred step reverses it each step).
    pub fn edges_now(&self) -> Vec<(String, f64, f64)> {
        (0..self.u.len())
            .map(|e| {
                let what = if e < self.fe_edges {
                    format!("section {} flow node {}", self.elements[e / 2].section, e % 2)
                } else {
                    let edge = self.edges[e - self.fe_edges];
                    match edge.kind {
                        Kind::Wall => format!("wall of node {}", edge.from),
                        k => format!("{k:?}"),
                    }
                };
                let c = self.cpos[e].max(self.cneg[e]);
                (what, (self.r[e] + c * self.u[e].abs()) * self.time_step / (2.0 * self.mu[e]), self.u[e])
            })
            .collect()
    }

    /// The glottis's flow (cm^3/s) as last stepped.
    pub fn glottal_flow(&self) -> f64 {
        self.u[self.glottis_edge]
    }

    /// The lungs' pressure (dPa), held at the trachea's first node; 2.4's source at its first section, the only place
    /// it puts one.
    pub fn set_pressure_source(&mut self, pressure_dpa: f64, section: i32) {
        assert!(section == tube::FIRST_TRACHEA_SECTION as i32 || pressure_dpa == 0.0, "the lungs' pressure is held at the trachea's start");
        self.lungs = pressure_dpa;
    }

    /// A section's pressure (dPa): its elements' mean (the glottis's two sections, the nodes below and above them).
    pub fn section_pressure(&self, i: usize) -> f64 {
        if i == tube::LOWER_GLOTTIS_SECTION {
            return self.q[self.trachea_top] / self.mp[self.trachea_top];
        }
        if i == tube::UPPER_GLOTTIS_SECTION {
            return self.q[self.pharynx_bottom] / self.mp[self.pharynx_bottom];
        }
        if i >= tube::FIRST_SINUS_SECTION {
            let c = self.cavity[i - tube::FIRST_SINUS_SECTION];
            return self.q[c] / self.mp[c];
        }
        let (a, b) = (self.first_element[i], self.last_element[i]);
        let mut sum = 0.0;
        for e in a..=b {
            let n = self.elements[e].nodes;
            let pressure = |k: usize| {
                if k == LUNGS {
                    self.lungs
                } else if let Some(w) = self.radiating.iter().position(|&(_, end)| end == k) {
                    self.end_pressure[w]
                } else {
                    self.q[k] / self.mp[k]
                }
            };
            sum += (pressure(n[0]) + 4.0 * pressure(n[1]) + pressure(n[2])) / 6.0;
        }
        sum / (b - a + 1) as f64
    }

    /// The masses, resistances, volumes and sources of a step from its tube's coefficients and the glottis's sections;
    /// the noise stepped where `noise`.
    fn lay(&mut self, k: &TubeCoefficients, noise: Option<&TubeCoefficients>) {
        let dt = self.time_step;
        let rho = AMBIENT_DENSITY_CGS;
        let stiffness = rho * SOUND_VELOCITY_CGS * SOUND_VELOCITY_CGS;
        // (of the lumped edges only the glottis and the necks take quadratic terms: the rest stay 0)
        for e in std::iter::once(self.glottis_edge).chain(self.neck) {
            self.cpos[e] = 0.0;
            self.cneg[e] = 0.0;
        }
        self.jpos.iter_mut().for_each(|x| *x = 0.0);
        self.jneg.iter_mut().for_each(|x| *x = 0.0);
        self.src.iter_mut().for_each(|x| *x = 0.0);
        // (the laws asked, and the surfaces' factor: an element laid under others laid again)
        let laws = self.viscous_layer as u64 | (self.thermal_layer as u64) << 1 | (self.own_circumference as u64) << 2 | (self.fitted_law as u64) << 3 | (self.surfaces.to_bits() & !0xF);
        for (e, el) in self.elements.iter().enumerate() {
            let a = k.area[el.section].max(MIN_AREA_CM2);
            let j = k.length[el.section] / el.parts as f64 / 2.0;
            // (on the section's own circumference its laws' radius is the hydraulic one, the equal-area circle's over `wall`)
            let wall = if self.own_circumference { k.shape[el.section].max(1.0) } else { 1.0 };
            let key = [a.to_bits(), j.to_bits(), wall.to_bits(), dt.to_bits(), laws];
            self.fresh[e] = self.laid[e] != key;
            if !self.fresh[e] {
                continue;
            }
            // (its nodes' air to be summed again, below)
            for &n in &el.nodes {
                if !self.dirty[n] {
                    self.dirty[n] = true;
                    self.touched.push(n);
                }
            }
            self.circ[e] = 2.0 * (PI * a).sqrt();
            self.laid_a[e] = a;
            self.laid_j[e] = j;
            self.laid[e] = key;
            self.relaid[e] = true;
            for q in 0..2 {
                self.mu[2 * e + q] = j * rho / a;
            }
            if self.viscous_layer {
                // (Poiseuille's resistance, and OpenWInD's branches: per unit length pi mu a_i / (b_i S^2) and rho a_i / S;
                // on the section's own circumference the resistances by wall squared, the inertances the area's still.
                // The fitted law's (fitted_law) U a_0, U a_i / b_i and U a_i tau, on the area alone. And what the
                // centred step takes of each branch: viscous_terms, viscous_step.)
                let (unit, tau) = if self.fitted_law { fitted_scale(a) } else { (PI * AIR_VISCOSITY_CGS / (a * a) * wall * wall, 0.0) };
                // (the surfaces' factor: the viscous boundary layer's impedance times it, its resistances and its
                // masses alike, on either law)
                let unit = unit * self.surfaces;
                for q in 0..2 {
                    self.r[2 * e + q] = j * unit * DIFFUSIVE_A0;
                    let mut psi = 0.0;
                    for i in 0..DIFFUSIVE_N {
                        let l = if self.fitted_law { j * unit * DIFFUSIVE_A[i] * tau } else { j * rho * DIFFUSIVE_A[i] / a * self.surfaces };
                        let (r, l) = (j * unit * DIFFUSIVE_A[i] / DIFFUSIVE_B[i], l);
                        self.vr[2 * e + q][i] = r;
                        self.vl[2 * e + q][i] = l;
                        let kappa = (l / dt) / (l / dt + 0.5 * r);
                        self.vrk[2 * e + q][i] = r * kappa;
                        self.vlow[2 * e + q][i] = l / dt - 0.5 * r;
                        self.vhigh[2 * e + q][i] = l / dt + 0.5 * r;
                        psi += r * kappa;
                    }
                    self.vpsi[2 * e + q] = psi;
                }
            } else {
                let viscous = viscous_per_length(a);
                for q in 0..2 {
                    self.r[2 * e + q] = j * viscous;
                }
            }
        }
        if !self.noise.options.piriform_fossa {
            // (2.4's fossa shut: its first section's inlet a resistance as of the least area -- added to what was just
            // laid, so that element is marked to be laid again each step)
            let e = self.first_element[tube::FIRST_FOSSA_SECTION];
            let shut = 8.0 * AIR_VISCOSITY_CGS * k.length[tube::FIRST_FOSSA_SECTION] * PI / (MIN_AREA_CM2 * MIN_AREA_CM2);
            self.r[2 * e] += shut / 2.0;
            self.r[2 * e + 1] += shut / 2.0;
            self.laid[e] = [u64::MAX; 5];
        }
        for n in 0..tube::NUM_SINUS_SECTIONS {
            let s = tube::FIRST_SINUS_SECTION + n;
            let v = k.volume[s];
            let (a, l) = (k.area[s].max(MIN_AREA_CM2), k.length[s]);
            let key = [v.to_bits(), a.to_bits(), l.to_bits()];
            if self.sinus_laid[n] != key {
                self.sinus_laid[n] = key;
                self.sinus_surf[n] = 4.0 * PI * ((3.0 * v) / (4.0 * PI)).powf(2.0 / 3.0);
                self.mu[self.neck[n]] = rho * l / a;
                const EMPIRICAL_FACTOR: f64 = 15.0;
                self.r[self.neck[n]] = EMPIRICAL_FACTOR * (8.0 * AIR_VISCOSITY_CGS * PI * l) / (a * a);
                let c = self.cavity[n];
                if !self.dirty[c] {
                    self.dirty[c] = true;
                    self.touched.push(c);
                }
            }
        }
        // (a radiating end's air goes to its element's middle node: the two summed again together)
        for (e, end) in self.radiating {
            let mid = self.elements[e].nodes[1];
            if self.dirty[mid] != self.dirty[end] {
                let n = if self.dirty[mid] { end } else { mid };
                self.dirty[n] = true;
                self.touched.push(n);
            }
        }
        // Each node's air -- its volume and its surface -- summed again where an element at it or its sinus was laid
        // again, as every node's was summed each step: from 0 its elements' parts in their order (each its Gauss-Lobatto
        // weight of its element's length, of its area and of its circumference), then a cavity's sinus, then a radiating
        // end's taken to its element's middle node. Elsewhere it stands, bit for bit.
        for &n in &self.touched {
            let (mut vol, mut surf) = (0.0, 0.0);
            for &(e, m) in &self.parts[self.parts_from[n]..self.parts_from[n + 1]] {
                vol += GL_W[m] * self.laid_j[e] * self.laid_a[e];
                surf += GL_W[m] * self.laid_j[e] * self.circ[e];
            }
            self.vol[n] = vol;
            self.surf[n] = surf;
        }
        for n in 0..tube::NUM_SINUS_SECTIONS {
            let c = self.cavity[n];
            if self.dirty[c] {
                self.vol[c] += k.volume[tube::FIRST_SINUS_SECTION + n];
                self.surf[c] += self.sinus_surf[n];
            }
        }
        for (e, end) in self.radiating {
            let mid = self.elements[e].nodes[1];
            if self.dirty[mid] {
                self.vol[mid] += self.vol[end];
                self.surf[mid] += self.surf[end];
                self.vol[end] = 0.0;
                self.surf[end] = 0.0;
            }
        }
        // (a node whose volume stands keeps its compliance: an end's the 1 given it below, a wall's node -- no air's
        // volume -- its spring's, laid with its edge)
        for &n in &self.touched {
            if n == LUNGS {
                continue;
            }
            let bits = self.vol[n].to_bits();
            if self.vol_laid[n] != bits {
                self.vol_laid[n] = bits;
                self.mp[n] = self.vol[n] / stiffness;
            }
        }
        for &(_, end) in &self.radiating {
            self.mp[end] = 1.0;
        }
        // The thermal branches (thermal_layer): each element's share at each of its nodes -- its length's Gauss-Lobatto
        // weight, the radiating elements' ends' with their middle nodes, as their air -- its isothermal excess
        // c_0 = (gamma - 1) V / rho c^2 and its conductances' unit pi kappa (gamma - 1) l / (rho^2 c^2 C_p) (OpenWInD's:
        // g_0 = unit a_0, g_i = unit a_i / b_i, c_i = c_0 a_i). By the implicit midpoint each branch i answers the
        // pressure across it with gh_i = 1 / (1/g_i + dt/2c_i), and the share the pressure v it sees with the flux
        // y v + h, y = 1 / (1/Gh + dt/2c_0), Gh = g_0 + sum gh_i (h from what it holds: thermal_answers). A node's y
        // is its shares' sum, and M_p + dt y / 2 its implicit compliance, by which the correction divides (`own`, below).
        // On the section's own circumference (own_circumference) the conductances are its hydraulic radius's, the
        // unit by its wall against the circle's squared; c_0 the area's still.
        if self.thermal_layer || self.node_y_live {
            self.node_y.iter_mut().for_each(|x| *x = 0.0);
            self.node_y_live = self.thermal_layer;
        }
        if self.thermal_layer {
            let gamma1 = ADIABATIC_CONSTANT - 1.0;
            let diffusivity = HEAT_CONDUCTION_CGS / (rho * SPECIFIC_HEAT_CGS);
            for (e, el) in self.elements.iter().enumerate() {
                if self.fresh[e] {
                    let a = k.area[el.section].max(MIN_AREA_CM2);
                    let j = k.length[el.section] / el.parts as f64 / 2.0;
                    let wall = if self.own_circumference { k.shape[el.section].max(1.0) } else { 1.0 };
                    let radiating = self.radiating.iter().any(|&(r, _)| r == e);
                    for m in 0..3 {
                        let length = if el.nodes[m] == LUNGS || (radiating && m == 2) {
                            0.0
                        } else if radiating && m == 1 {
                            (GL_W[1] + GL_W[2]) * j
                        } else {
                            GL_W[m] * j
                        };
                        let share = 3 * e + m;
                        let (c0, unit) = (gamma1 * a * length / stiffness, PI * diffusivity * gamma1 * length / stiffness * wall * wall);
                        self.tc0[share] = c0;
                        self.tunit[share] = unit;
                        self.ty[share] = 0.0;
                        if length > 0.0 {
                            (self.tgh[share], self.tci[share], self.tsum[share], self.ty[share]) = thermal_share(c0, unit, dt);
                        }
                    }
                }
                for m in 0..3 {
                    if self.ty[3 * e + m] != 0.0 {
                        self.node_y[el.nodes[m]] += self.ty[3 * e + m];
                    }
                }
            }
        }
        // the walls of the nodes whose surface may have changed (and the implicit compliance of a wall's node laid with
        // it), and the radiation's inductances
        for &n in &self.touched {
            let e = self.wall_edge[n];
            if e == NONE {
                continue;
            }
            let (i, to) = (e - self.fe_edges, self.edges[e - self.fe_edges].to);
            let surface = self.surf[n].max(MIN_AREA_CM2);
            if self.wall_laid[i] != surface.to_bits() {
                self.wall_laid[i] = surface.to_bits();
                let (mass, damping, stiffness) = self.wall_tissue;
                self.mu[e] = WALL_MASS_PER_UNIT_AREA_CGS * mass / surface;
                self.r[e] = WALL_DAMPING_PER_UNIT_AREA_CGS * damping / surface;
                self.mp[to] = surface / (WALL_STIFFNESS_PER_UNIT_AREA_CGS * stiffness);
                self.own[to] = self.mp[to] + 0.5 * dt * self.node_y[to];
            }
        }
        for w in 0..2 {
            let e = self.radiation[w];
            // (2.4's piston as the coefficients carry it; else the category's Pade form at the opening's area.)
            let (resistance, inductance) = match self.radiation_law {
                None => k.radiation[w],
                Some((delta, beta_c)) => pade_radiation(k.area[if w == 0 { tube::LAST_MOUTH_SECTION } else { tube::LAST_NOSE_SECTION }], delta, beta_c),
            };
            self.mu[e] = inductance;
            self.r[e] = 0.0;
            self.resistance[w] = resistance;
        }
        // (every node's compliance now laid, the walls' springs too: each node's implicit compliance where its
        // compliance or its thermal branches may have changed -- with the thermal branches every node's)
        if self.thermal_layer {
            for ((own, &mp), &y) in self.own.iter_mut().zip(&self.mp).zip(&self.node_y) {
                *own = mp + 0.5 * dt * y;
            }
        } else {
            for &n in &self.touched {
                self.own[n] = self.mp[n] + 0.5 * dt * self.node_y[n];
            }
        }
        for &n in &self.touched {
            self.dirty[n] = false;
        }
        self.touched.clear();
        // The glottis: its two sections' inertance and 2.4's viscous law; its Bernoulli drops as 2.4 takes them over its
        // three joins (the trachea's last section into the lower, the lower into the upper, the upper into the
        // pharynx), the flow's way: the whole where it narrows, 2.4's recovery where it widens (its glottis's 0.2 past
        // the glottal sections, its tract's 0.5 into the trachea). Lumped, the drops and recoveries net to a positive
        // resistance whichever way the flow goes; where they do not, the rest is taken from the last flow, a supply.
        let ((l1, l2), (a1, a2)) = ((self.glottis.0[0], self.glottis.0[1]), (self.glottis.1[0], self.glottis.1[1]));
        let g = self.glottis_edge;
        self.mu[g] = rho * (l1 / a1 + l2 / a2);
        self.r[g] = l1 * viscous_per_length(a1) + l2 * viscous_per_length(a2);
        let below = k.area[tube::LAST_TRACHEA_SECTION].max(MIN_AREA_CM2);
        let above = k.area[tube::FIRST_PHARYNX_SECTION].max(MIN_AREA_CM2);
        let forward = 0.5 * rho * (drop_term(below, a1, TRACT_RECOVERY_COEFF) + drop_term(a1, a2, GLOTTIS_RECOVERY_COEFF) + drop_term(a2, above, GLOTTIS_RECOVERY_COEFF));
        let backward = 0.5 * rho * (drop_term(above, a2, GLOTTIS_RECOVERY_COEFF) + drop_term(a2, a1, GLOTTIS_RECOVERY_COEFF) + drop_term(a1, below, TRACT_RECOVERY_COEFF));
        let last = self.u[g];
        for (c, sign) in [(forward, 1.0), (backward, -1.0)] {
            if c >= 0.0 {
                if sign > 0.0 {
                    self.cpos[g] = c;
                } else {
                    self.cneg[g] = c;
                }
            } else if last * sign > 0.0 {
                self.src[g] += c * last.abs() * last;
            }
        }
        // The joins: toward the narrower, 2.4's drop at once on the narrower side's flow; toward the wider, its
        // recovery as the jet reattaches, on the wider side's.
        for (n, jn) in self.joins.iter().enumerate() {
            let (au, ad) = (k.area[jn.up.section].max(MIN_AREA_CM2), k.area[jn.down.section].max(MIN_AREA_CM2));
            // (its coefficient, and the length its jet reattaches over, kept while its two areas stand)
            let key = [au.to_bits(), ad.to_bits()];
            if self.join_laid[n] != key {
                self.join_laid[n] = key;
                self.join_c[n] = 0.5 * rho * (1.0 / (au.min(ad) * au.min(ad)) - 1.0 / (au.max(ad) * au.max(ad)));
                self.join_length[n] = REATTACHMENT_STEP_HEIGHTS * ((au.max(ad) / PI).sqrt() - (au.min(ad) / PI).sqrt());
            }
            let c = self.join_c[n];
            let (narrow, wide) = if jn.branch {
                (jn.down, jn.down)
            } else if ad < au {
                (jn.down, jn.up)
            } else {
                (jn.up, jn.down)
            };
            // (on an element's mean flow, the whole drop; on a neck, its own flow)
            let (pos, neg) = if narrow.count == 2 { (&mut self.jpos[narrow.edge / 2], &mut self.jneg[narrow.edge / 2]) } else { (&mut self.cpos[narrow.edge], &mut self.cneg[narrow.edge]) };
            if ad < au {
                *pos += c;
            } else {
                *neg += c;
            }
            if self.reattachment {
                for q in 0..wide.count {
                    self.src[wide.edge + q] += jn.lagged / wide.count as f64;
                }
            } else {
                // (2.4's recovery at once, taken as 2.4 takes it: within the step, a negative quadratic term on the
                // wider side's flow the way the flow widens)
                let fraction = self.recovered(jn.recovery, au.min(ad), au.max(ad));
                let (pos, neg) = if wide.count == 2 { (&mut self.jpos[wide.edge / 2], &mut self.jneg[wide.edge / 2]) } else { (&mut self.cpos[wide.edge], &mut self.cneg[wide.edge]) };
                if ad > au {
                    *pos -= fraction * c;
                } else {
                    *neg -= fraction * c;
                }
            }
        }
        // 2.4's noise, stepped from the last step's flows: each section's dipole a pressure across its inlet (on the
        // edges into it), its monopole a flow into it, the lips' dipole in every radiating edge (2.4 puts it in the
        // nostrils' too).
        self.f.iter_mut().for_each(|x| *x = 0.0);
        if let Some(n) = noise {
            self.noise.step_noise(n);
        }
        for i in tube::FIRST_PHARYNX_SECTION..=tube::LAST_NOSE_SECTION {
            let (monopole, dipole) = self.noise.noise_source(i);
            if dipole != 0.0 {
                if i == tube::FIRST_PHARYNX_SECTION {
                    self.src[g] -= dipole;
                } else {
                    let e = 2 * self.first_element[i];
                    self.src[e] -= dipole / 2.0;
                    self.src[e + 1] -= dipole / 2.0;
                }
            }
            if monopole != 0.0 {
                let (a, b) = (self.first_element[i], self.last_element[i]);
                let share = monopole / ((b - a + 1) as f64 * 2.0);
                for e in a..=b {
                    let n = self.elements[e].nodes;
                    for m in 0..3 {
                        self.f[n[m]] -= share * GL_W[m];
                    }
                }
            }
        }
        let (_, lips) = self.noise.noise_source(NUM_SECTIONS);
        self.end_source = [-lips; 2];
        // The volumes' growth: a sink where they grow (the walls' motion, and the folds', their sections' volume split
        // between the nodes below and above).
        let glottis_volume = l1 * a1 + l2 * a2;
        if self.started && self.displaced_volume {
            for ((f, &vol), &before) in self.f[1..].iter_mut().zip(&self.vol[1..]).zip(&self.vol_prev[1..]) {
                *f += (vol - before) / dt;
            }
            if self.folds_displace {
                let half = 0.5 * (glottis_volume - self.glottis_volume) / dt;
                self.f[self.trachea_top] += half;
                self.f[self.pharynx_bottom] += half;
            }
        }
        self.vol_prev.copy_from_slice(&self.vol);
        self.glottis_volume = glottis_volume;
        self.f[self.pharynx_bottom] -= self.injected;
    }

    /// An edge's viscous branches (viscous_layer) this step: their resistance, centred as the edge's own
    /// (sum_i r_i kappa_i, kappa_i = (l_i/dt) / (l_i/dt + r_i/2)), and what their last flows add to its drive.
    fn viscous_terms(&self, e: usize) -> (f64, f64) {
        (self.vpsi[e], branches_drive(&self.vrk[e], &self.vmom[e], &self.vl[e]))
    }

    /// An edge's viscous branches stepped from its centred flow `um` (l_i dv_i/dt = r_i (um - v_i), centred): the
    /// losses they took over the step, over dt (each r_i (um - mean v_i)^2), where `LOSS` asks for them (0 where not).
    fn viscous_step<const LOSS: bool>(&mut self, e: usize, um: f64) -> f64 {
        branches_step::<LOSS>(um, &self.vr[e], &self.vl[e], &self.vlow[e], &self.vhigh[e], &mut self.vmom[e], &mut self.vflow[e])
    }

    /// What the thermal branches answer this step from the charges they hold: each share's h (its flux for the pressure
    /// v it sees is y v + h, h = -y (P0 + sum_i gh_i P_i / Gh)) and each node's, its shares' sum.
    fn thermal_answers(&mut self) {
        self.node_h.iter_mut().for_each(|x| *x = 0.0);
        for (e, el) in self.elements.iter().enumerate() {
            for m in 0..3 {
                let share = 3 * e + m;
                let y = self.ty[share];
                if y == 0.0 {
                    continue;
                }
                let mut held = 0.0;
                for i in 0..DIFFUSIVE_N {
                    held += self.tgh[share][i] * self.ts[share][1 + i] / self.tci[share][1 + i];
                }
                self.th[share] = -y * (self.ts[share][0] / self.tci[share][0] + held / self.tsum[share]);
                self.node_h[el.nodes[m]] += self.th[share];
            }
        }
    }

    /// The thermal branches stepped by the implicit midpoint from the pressure each node's see, the mean of its
    /// corrected pressure at the step's start (`pt_start`) and end (`pt`): each share's flux q = y v + h charges its
    /// c_0, whose mean pressure P0m = P0 + dt q / 2c_0 leaves v - P0m across its conductance and its branches, each
    /// taking gh_i (v - P0m - P_i). Each node's flux (`node_flux`); the losses over the step, over dt
    /// (g_0 (v - P0m)^2 + sum q_i^2 / g_i), where `counted` (the account's: nothing else reads them, and an account
    /// begun on a model already stepping begins with this step's).
    fn thermal_step(&mut self, counted: bool) -> f64 {
        let dt = self.time_step;
        self.ts_prev.copy_from_slice(&self.ts);
        self.node_flux.iter_mut().for_each(|x| *x = 0.0);
        let mut lost = 0.0;
        for (e, el) in self.elements.iter().enumerate() {
            for m in 0..3 {
                let share = 3 * e + m;
                let (c0, unit, y) = (self.tc0[share], self.tunit[share], self.ty[share]);
                if y == 0.0 {
                    continue;
                }
                let node = el.nodes[m];
                let v = 0.5 * (self.pt_start[node] + self.pt[node]);
                let q = y * v + self.th[share];
                let across = v - (self.ts[share][0] / c0 + 0.5 * dt * q / c0);
                if counted {
                    lost += unit * DIFFUSIVE_A0 * across * across;
                }
                self.ts[share][0] += dt * q;
                for i in 0..DIFFUSIVE_N {
                    let qi = self.tgh[share][i] * (across - self.ts[share][1 + i] / self.tci[share][1 + i]);
                    if counted {
                        lost += qi * qi * DIFFUSIVE_B[i] / (unit * DIFFUSIVE_A[i]);
                    }
                    self.ts[share][1 + i] += dt * qi;
                }
                self.node_flux[node] += q;
            }
        }
        lost
    }

    /// The thermal branches' storage for the charges they carry, at the compliances now (sum of charge^2 / 2 compliance).
    fn thermal_stored(&self, charges: &[[f64; THERMAL_N]]) -> f64 {
        let mut stored = 0.0;
        for share in 0..charges.len() {
            if self.ty[share] == 0.0 {
                continue;
            }
            for j in 0..THERMAL_N {
                stored += 0.5 * charges[share][j] * charges[share][j] / self.tci[share][j];
            }
        }
        stored
    }

    /// An end's radiation, solved with the last element's two flows (its end node holding no air): with d the element's
    /// coupling to its end, the end's pressure is s + R (d.u - u_L) (Kirchhoff's law: what the element sends out, the
    /// resistance and the inductance take; s the lips' dipole, 2.4's source in its radiation), so that, centred,
    ///   (2M_k/dt + R_k) u_k + R d_k (d.u - u_L) = 2M_k u_k-/dt - f_k - d_k s - src_k     (the element's two)
    ///   2L/dt u_L - R (d.u - u_L) = 2L u_L-/dt                                           (the inductance)
    /// -- the resistance R [d; -1][d; -1]^T, symmetric and never negative: it only takes. The element's quadratic
    /// drops are taken on its last flow's size (positive, so taking too). The losses and the sources' work (a step's,
    /// over dt).
    fn radiate(&mut self, w: usize) -> (f64, f64) {
        let dt = self.time_step;
        let (e, _) = self.radiating[w];
        let viscous = self.viscous_layer;
        let idx = [2 * e, 2 * e + 1, self.radiation[w]];
        let (res, s) = (self.resistance[w], self.end_source[w]);
        let d = [D[0][2], D[1][2], -1.0];
        let mut a = [[0.0; 3]; 3];
        let mut b = [0.0; 3];
        let mut damping = [0.0; 3];
        let last_mean = 0.5 * (self.u[idx[0]] + self.u[idx[1]]);
        let joined = if last_mean >= 0.0 { self.jpos[e] } else { self.jneg[e] } * last_mean.abs();
        for i in 0..3 {
            let (m, u0) = (self.mu[idx[i]], self.u[idx[i]]);
            let mut psi = 0.0;
            if i < 2 {
                let c = if u0 >= 0.0 { self.cpos[idx[i]] } else { self.cneg[idx[i]] };
                damping[i] = self.r[idx[i]] + c * u0.abs();
                b[i] = 2.0 * m * u0 / dt - self.force[idx[i]] - d[i] * s - self.src[idx[i]];
                if viscous {
                    let (p, drive) = self.viscous_terms(idx[i]);
                    psi = p;
                    b[i] += drive;
                }
            } else {
                b[i] = 2.0 * m * u0 / dt;
            }
            for j in 0..3 {
                a[i][j] = res * d[i] * d[j];
                // (the joins' drop on the mean: c |m-| (u_0 + u_1) / 4 in each of the element's rows)
                if i < 2 && j < 2 {
                    a[i][j] += 0.25 * joined;
                }
            }
            a[i][i] += 2.0 * m / dt + damping[i] + psi;
        }
        // (Gaussian elimination; the matrix symmetric and positive definite)
        for col in 0..3 {
            for row in col + 1..3 {
                let f = a[row][col] / a[col][col];
                for k in col..3 {
                    a[row][k] -= f * a[col][k];
                }
                b[row] -= f * b[col];
            }
        }
        let mut um = [0.0; 3];
        for row in (0..3).rev() {
            let mut x = b[row];
            for k in row + 1..3 {
                x -= a[row][k] * um[k];
            }
            um[row] = x / a[row][row];
        }
        let through = d[0] * um[0] + d[1] * um[1] - um[2];
        self.end_pressure[w] = s + res * through;
        let mean = 0.5 * (um[0] + um[1]);
        let mut losses = res * through * through + joined * mean * mean;
        let mut sources = 0.0;
        for i in 0..3 {
            let u1 = 2.0 * um[i] - self.u[idx[i]];
            self.um[idx[i]] = um[i];
            self.u[idx[i]] = u1;
            self.pi[idx[i]] = self.mu[idx[i]] * u1;
            losses += damping[i] * um[i] * um[i];
            if i < 2 {
                sources -= (d[i] * s + self.src[idx[i]]) * um[i];
                if viscous {
                    losses += self.viscous_step::<true>(idx[i], um[i]);
                }
            }
        }
        (losses, sources)
    }

    /// B x: each edge's drive from the nodes' pressures `x` (an element's flow node, sum_m D[k][m] x_m; a lumped edge,
    /// its target's less its source's).
    fn apply_b(elements: &[Element], edges: &[Edge], walls: &Walls, fe: usize, x: &[f64], out: &mut [f64]) {
        let (flows, lumped) = out.split_at_mut(fe);
        for (out, el) in flows.chunks_exact_mut(2).zip(elements) {
            let [a, b, c] = el.nodes;
            let (xa, xb, xc) = (x[a], x[b], x[c]);
            for q in 0..2 {
                out[q] = D[q][0] * xa + D[q][1] * xb + D[q][2] * xc;
            }
        }
        let (lumped, wall_edges) = lumped.split_at_mut(walls.first);
        for (out, edge) in lumped.iter_mut().zip(edges) {
            *out = if edge.to == ATMOSPHERE { 0.0 } else { x[edge.to] } - x[edge.from];
        }
        // (a wall: its own node's less its acoustic node's)
        for ((out, &from), &own) in wall_edges.iter_mut().zip(&walls.from).zip(&x[walls.acoustic..]) {
            *out = own - x[from];
        }
    }

    /// B^T y: each node's net inflow from the edges' flows `y`.
    fn apply_bt(elements: &[Element], edges: &[Edge], walls: &Walls, fe: usize, y: &[f64], out: &mut [f64]) {
        let (out, wall_nodes) = out.split_at_mut(walls.acoustic);
        out.iter_mut().for_each(|x| *x = 0.0);
        for (e, el) in elements.iter().enumerate() {
            let (y0, y1) = (y[2 * e], y[2 * e + 1]);
            for m in 0..3 {
                out[el.nodes[m]] += D[0][m] * y0 + D[1][m] * y1;
            }
        }
        for (i, edge) in edges[..walls.first].iter().enumerate() {
            out[edge.from] -= y[fe + i];
            if edge.to != ATMOSPHERE {
                out[edge.to] += y[fe + i];
            }
        }
        // (the walls, last as their edges are: each takes its flow from its acoustic node, and is the whole inflow of
        // its own node, there added to 0 as every node's inflow is)
        for ((own, &from), &yw) in wall_nodes.iter_mut().zip(&walls.from).zip(&y[fe + walls.first..]) {
            out[from] -= yw;
            *own = 0.0 + yw;
        }
    }

    /// The pressures `x` corrected to fourth order in time: x - dt^2/12 D^-1 B^T M_u^-1 B x (the lungs' left out), D each
    /// node's implicit compliance (`own`: its M_p, with its thermal branches' dt y / 2 where it has them).
    fn correct(&mut self, from_q: bool) {
        let dt = self.time_step;
        let (q, mp) = (if from_q { &self.q } else { &self.q_prev }, &self.mp);
        for ((p, &q), &mp) in self.p.iter_mut().zip(q).zip(mp) {
            *p = q / mp;
        }
        self.p[LUNGS] = 0.0;
        for &(_, end) in &self.radiating {
            self.p[end] = 0.0;
        }
        Self::apply_b(&self.elements, &self.edges, &self.walls, self.fe_edges, &self.p, &mut self.tmp);
        for (t, &mu) in self.tmp.iter_mut().zip(&self.mu) {
            *t /= mu;
        }
        Self::apply_bt(&self.elements, &self.edges, &self.walls, self.fe_edges, &self.tmp, &mut self.acc);
        for (((pt, &p), &acc), &own) in self.pt.iter_mut().zip(&self.p).zip(&self.acc).zip(&self.own) {
            *pt = p - dt * dt / 12.0 * acc / own;
        }
        for &(_, end) in &self.radiating {
            self.pt[end] = 0.0;
        }
    }

    /// The energy E^(n-1/2) at the masses now: 1/2 U.M_u.U + 1/2 P^n.W.P^(n-1), W = D - dt^2/12 G (D each node's implicit
    /// compliance: M_p but where it has thermal branches); with the boundary layer, its viscous branches' kinetic
    /// energy, and its thermal branches' part (research/VOCALWIND_BOUNDARY_LAYER.md, E_F): their storage, the mean of
    /// now and a step before, less 1/2 Pt^n.(dt y / 2) Pt^(n-1) and dt/4 (Pt^n - Pt^(n-1)).q, Pt the corrected pressures
    /// and q the flux the branches last took.
    fn energy(&mut self) -> f64 {
        let dt = self.time_step;
        let mut kinetic: f64 = self.pi.iter().zip(&self.mu).map(|(p, m)| 0.5 * p * p / m).sum();
        if self.viscous_layer {
            for e in 0..self.fe_edges {
                kinetic += (0..DIFFUSIVE_N).map(|i| 0.5 * self.vmom[e][i] * self.vmom[e][i] / self.vl[e][i]).sum::<f64>();
            }
        }
        let mut potential = 0.0;
        if self.thermal_layer {
            kinetic += 0.5 * (self.thermal_stored(&self.ts) + self.thermal_stored(&self.ts_prev));
            // (the corrected pressures now, kept in `pt_start` while those of a step before are made)
            self.correct(true);
            self.pt_start.copy_from_slice(&self.pt);
        }
        self.correct(false);
        for n in 1..self.q.len() {
            potential += 0.5 * (self.q[n] / self.mp[n]) * self.own[n] * self.pt[n];
            if self.thermal_layer {
                let now = self.pt_start[n];
                potential -= 0.25 * dt * self.node_y[n] * now * self.pt[n] + 0.25 * dt * (now - self.pt[n]) * self.node_flux[n];
            }
        }
        kinetic + potential
    }

    /// One step from its tube's coefficients (the glottis's sections and the lungs' pressure set): the flows radiated.
    pub fn proceed_time_step_with(&mut self, k: &TubeCoefficients) -> Radiated {
        let dt = self.time_step;
        let monitor = self.account.is_some();
        let before = if monitor && self.started { self.energy() } else { 0.0 };
        self.lay(k, Some(k));
        if !self.glottal_velocity_held && self.started {
            let g = self.glottis_edge;
            self.pi[g] = self.mu[g] * self.used[g];
        }
        // (the elements' volume flows held, tract_flow_held, and their viscous branches' flows, as theirs: where an
        // element was laid again, its momenta's own elsewhere)
        if self.tract_flow_held && self.started {
            for el in 0..self.relaid.len() {
                if !self.relaid[el] {
                    continue;
                }
                self.relaid[el] = false;
                for e in [2 * el, 2 * el + 1] {
                    self.pi[e] = self.mu[e] * self.used[e];
                    if self.viscous_layer {
                        for i in 0..DIFFUSIVE_N {
                            self.vmom[e][i] = self.vl[e][i] * self.vflow[e][i];
                        }
                    }
                }
            }
        }
        let geometry = if monitor && self.started { self.energy() - before } else { 0.0 };
        let mut rest = 0.0;
        let e0 = if monitor { self.energy() } else { 0.0 };
        // the flows the momenta now hold, and the pressures corrected
        for ((u, &pi), &mu) in self.u.iter_mut().zip(&self.pi).zip(&self.mu) {
            *u = pi / mu;
        }
        let thermal = self.thermal_layer;
        if thermal && monitor && self.started {
            // (the corrected pressures a step before, at this step's coefficients: for the rest of the geometry's work)
            self.correct(false);
            self.pt_start.copy_from_slice(&self.pt);
        }
        self.correct(true);
        self.pt[LUNGS] = self.lungs;
        if monitor && self.started && !thermal {
            // (the rest of the geometry's work: the last contents were made with the flows of the geometry then, not
            // those the momenta hold now)
            for e in 0..self.u.len() {
                self.tmp[e] = self.used[e] - self.u[e];
            }
            Self::apply_bt(&self.elements, &self.edges, &self.walls, self.fe_edges, &self.tmp, &mut self.acc);
            rest = 0.5 * dt * (1..self.pt.len()).map(|n| self.pt[n] * self.acc[n]).sum::<f64>();
        }
        if monitor && self.started && thermal {
            // (The same with the thermal branches: the last step's half of the identity as this step's coefficients
            // make it, less what it was -- for each node 1/2 Pt.(D dP - (dt y / 2) dPt - dt (B^T U - F)), dP and dPt
            // the last step's changes of its pressure and its corrected pressure, U the flows the momenta now hold;
            // the branches' storage's change over the last step, half; dt/4 dPt.q, q the flux they took; and their
            // losses' half booked now. Nothing where the tube is still: research/VOCALWIND_BOUNDARY_LAYER.md, "A
            // moving tract".)
            Self::apply_bt(&self.elements, &self.edges, &self.walls, self.fe_edges, &self.u, &mut self.acc);
            rest = 0.5 * (self.thermal_stored(&self.ts) - self.thermal_stored(&self.ts_prev)) + 0.5 * dt * self.thermal_lost;
            for n in 1..self.pt.len() {
                let changed = self.pt[n] - self.pt_start[n];
                rest += 0.5 * self.pt[n] * (self.own[n] / self.mp[n] * (self.q[n] - self.q_prev[n]) - 0.5 * dt * self.node_y[n] * changed - dt * (self.acc[n] - self.f_prev[n]))
                    + 0.25 * dt * changed * self.node_flux[n];
            }
        }
        Self::apply_b(&self.elements, &self.edges, &self.walls, self.fe_edges, &self.pt, &mut self.force);
        // each edge alone: M (U+ - U-) / dt = -force - src - R um - c |um| um, um the centred flow
        let mut losses = 0.0;
        let mut sources = 0.0;
        // each element's two flows together: their mean m with its joins' drop c |m| m (half on each), their own
        // terms each alone -- node k: beta um_k + c |m| m / 2 = g_k, so 2 beta m + c |m| m = g_0 + g_1
        for el in 0..self.jpos.len() {
            let (e0, e1) = (2 * el, 2 * el + 1);
            if self.in_block[e0] {
                continue;
            }
            // (with the boundary layer, the viscous branches' centred resistance and drive, the same on both nodes)
            let ((psi, h0), (_, h1)) = if self.viscous_layer { (self.viscous_terms(e0), self.viscous_terms(e1)) } else { ((0.0, 0.0), (0.0, 0.0)) };
            let (m, beta) = (self.mu[e0], 2.0 * self.mu[e0] / dt + self.r[e0] + psi);
            let g0 = 2.0 * m * self.u[e0] / dt - self.force[e0] - self.src[e0] + h0;
            let g1 = 2.0 * m * self.u[e1] / dt - self.force[e1] - self.src[e1] + h1;
            let sum = g0 + g1;
            let c = if sum >= 0.0 { self.jpos[el] } else { self.jneg[el] };
            let disc = beta * beta + c * sum.abs();
            if disc < 0.0 {
                self.overwhelmed += 1;
                if !self.overwhelmed_at.iter().any(|x| x.0 == e0) && self.overwhelmed_at.len() < 12 {
                    self.overwhelmed_at.push((e0, 0.5 * (self.u[e0] + self.u[e1]), c, beta));
                }
            }
            let mean = sum / (beta + disc.max(0.0).sqrt());
            let half_drop = 0.5 * c * mean.abs() * mean;
            // the two against each other, delta = (um_0 - um_1) / 2: beta delta = (g_0 - g_1) / 2, the joins' drop on
            // the mean taking no part
            let delta = 0.5 * (g0 - g1) / beta;
            for (e, sign) in [(e0, 1.0), (e1, -1.0)] {
                let um = mean + sign * delta;
                let u1 = 2.0 * um - self.u[e];
                self.um[e] = um;
                self.pi[e] = m * u1;
                if self.viscous_layer {
                    if monitor {
                        losses += dt * self.viscous_step::<true>(e, um);
                    } else {
                        self.viscous_step::<false>(e, um);
                    }
                }
                if monitor {
                    losses += dt * self.r[e] * um * um;
                    sources -= dt * self.src[e] * um;
                }
                self.u[e] = u1;
            }
            if monitor {
                // (a drop that gives -- a recovery taken at once -- among the sources, not the losses)
                let work = dt * 2.0 * half_drop * mean;
                if work >= 0.0 {
                    losses += work;
                } else {
                    sources -= work;
                }
            }
        }
        for e in self.fe_edges..self.u.len() {
            if self.in_block[e] {
                continue;
            }
            let (m, u0) = (self.mu[e], self.u[e]);
            let g = 2.0 * m * u0 / dt - self.force[e] - self.src[e];
            let beta = 2.0 * m / dt + self.r[e];
            let c = if g >= 0.0 { self.cpos[e] } else { self.cneg[e] };
            // (a net negative c -- a recovery taken at once outweighing the drops -- has a step's solution only while
            // beta^2 >= 4|c||g|; past it the edge's inertia no longer holds it: counted)
            let disc = beta * beta + 4.0 * c * g.abs();
            if disc < 0.0 {
                self.overwhelmed += 1;
                if !self.overwhelmed_at.iter().any(|x| x.0 == e) && self.overwhelmed_at.len() < 12 {
                    self.overwhelmed_at.push((e, self.u[e], c, beta));
                }
            }
            let um = 2.0 * g / (beta + disc.max(0.0).sqrt());
            self.um[e] = um;
            let u1 = 2.0 * um - u0;
            self.pi[e] = m * u1;
            if monitor {
                losses += dt * (self.r[e] + c * um.abs()) * um * um;
                sources -= dt * self.src[e] * um;
            }
            self.u[e] = u1;
        }
        for w in 0..2 {
            let (l, s) = self.radiate(w);
            losses += dt * l;
            sources += dt * s;
        }
        let mut volumes = 0.0;
        // the contents: q += dt (B^T U - F); a node with thermal branches' with them, its implicit compliance D taking
        // D (P+ - P) = dt (B^T U - F - h - y Pt), Pt its corrected pressure and y Pt + h what its branches take of it
        Self::apply_bt(&self.elements, &self.edges, &self.walls, self.fe_edges, &self.u, &mut self.acc);
        std::mem::swap(&mut self.q, &mut self.q_prev);
        for &(_, end) in &self.radiating {
            self.acc[end] = 0.0;
            self.f[end] = 0.0;
        }
        if thermal {
            self.thermal_answers();
        }
        if thermal {
            for n in 1..self.q.len() {
                let inflow = self.acc[n] - self.f[n];
                self.q[n] = self.q_prev[n]
                    + if self.node_y[n] > 0.0 { self.mp[n] * dt * (inflow - self.node_h[n] - self.node_y[n] * self.pt[n]) / self.own[n] } else { dt * inflow };
            }
        } else {
            // (no node with thermal branches)
            for (((q, &q0), &acc), &f) in self.q[1..].iter_mut().zip(&self.q_prev[1..]).zip(&self.acc[1..]).zip(&self.f[1..]) {
                *q = q0 + dt * (acc - f);
            }
        }
        if monitor {
            for n in 1..self.q.len() {
                volumes -= 0.5 * dt * self.pt[n] * (self.f[n] + self.f_prev[n]);
            }
        }
        // the thermal branches, from the mean of the corrected pressures before the step and after it (corrected at
        // this step's coefficients: the next step's are its own); their losses half this step's, half the next's
        let mut thermal_lost = 0.0;
        if thermal {
            self.pt_start.copy_from_slice(&self.pt);
            self.correct(true);
            thermal_lost = self.thermal_step(monitor);
            losses += 0.5 * dt * (thermal_lost + self.thermal_lost);
        }
        self.thermal_lost = thermal_lost;
        if monitor {
            let lungs: f64 = self.elements.iter().enumerate().filter(|(_, el)| el.nodes[0] == LUNGS).map(|(e, _)| -dt * self.lungs * (D[0][0] * self.um[2 * e] + D[1][0] * self.um[2 * e + 1])).sum();
            let e1 = self.energy();
            let a = self.account.as_mut().unwrap();
            // (e0 is at this step's masses: the geometry's change of them already in it; `rest` its other part)
            let residual = e1 - e0 - rest + losses - lungs - sources - volumes;
            a.energy = e1;
            a.losses += losses;
            a.lungs += lungs;
            a.sources += sources;
            a.volumes += volumes;
            a.geometry += geometry + rest;
            a.peak = a.peak.max(e1.abs());
            a.worst_residual = a.worst_residual.max(residual.abs());
        }
        self.used.copy_from_slice(&self.u);
        // (the sinks laid again from 0 each step: this step's kept whole)
        std::mem::swap(&mut self.f_prev, &mut self.f);
        self.started = true;
        // the recovered pressures, toward what the joins' flows now ask, as the jet reattaches
        for (n, jn) in self.joins.iter_mut().enumerate() {
            // (the jet's flow: through the narrower section, whence it issues -- its element's mean, never its two
            // nodes' extrapolation, which its internal mode would swell; nor the wider side's, which the recovery
            // itself drives, so that a recovery taken from it would feed itself, without bound where a closing
            // constriction makes its coefficient enormous. At a branch, the branch's own flow.)
            let flow_at = |s: &Side| -> f64 {
                if s.count == 1 {
                    self.u[s.edge]
                } else {
                    0.5 * (self.u[s.edge] + self.u[s.edge + 1])
                }
            };
            let (au, ad) = (k.area[jn.up.section].max(MIN_AREA_CM2), k.area[jn.down.section].max(MIN_AREA_CM2));
            let flow = if jn.branch || ad < au { flow_at(&jn.down) } else { flow_at(&jn.up) };
            let (an, aw) = (au.min(ad), au.max(ad));
            // (its coefficient and its jet's length as this step's `lay` kept them)
            let c = self.join_c[n];
            let fraction = if self.borda_carnot { 2.0 * (an / aw) / (1.0 + an / aw) } else { jn.recovery };
            let target = if ad > au && flow > 0.0 {
                -fraction * c * flow * flow
            } else if au > ad && flow < 0.0 {
                fraction * c * flow * flow
            } else {
                0.0
            };
            let reach = if self.reattachment {
                let length = self.join_length[n];
                // (at the speed of the jet now, or -- where it has slowed or stopped -- of the jet whose recovery is
                // still held, its fluid passing the reattachment on: no jet, no recovery, once its last has passed)
                let held = if fraction * c > 0.0 { (jn.lagged.abs() / (fraction * c)).sqrt() } else { 0.0 };
                if length > 0.0 {
                    1.0 - (-dt * (flow.abs().max(held) / an) / length).exp()
                } else {
                    1.0
                }
            } else {
                1.0
            };
            jn.lagged += reach * (target - jn.lagged);
        }
        // the flows as 2.4's branch currents: into each section (its first element's mean), the glottis's, the
        // necks', and the radiation's (the resistance's and the inductance's at the mouth, then the nostrils)
        for i in 0..NUM_SECTIONS {
            self.flows[i] = if i == tube::LOWER_GLOTTIS_SECTION || i == tube::UPPER_GLOTTIS_SECTION || i == tube::FIRST_PHARYNX_SECTION {
                self.u[self.glottis_edge]
            } else if i >= tube::FIRST_SINUS_SECTION {
                self.u[self.neck[i - tube::FIRST_SINUS_SECTION]]
            } else {
                let e = 2 * self.first_element[i];
                0.5 * (self.u[e] + self.u[e + 1])
            };
        }
        let mut out = [0.0; 2];
        for w in 0..2 {
            let e = self.radiating[w].0;
            out[w] = D[0][2] * self.u[2 * e] + D[1][2] * self.u[2 * e + 1];
            self.flows[NUM_SECTIONS + 2 * w] = out[w] - self.u[self.radiation[w]];
            self.flows[NUM_SECTIONS + 2 * w + 1] = self.u[self.radiation[w]];
        }
        self.noise.take_flows(&self.flows);
        let (mouth, nostrils) = (out[0], out[1]);
        let mut skin = 0.0;
        if self.noise.options.radiation_from_skin {
            for &e in &self.skin_walls {
                skin += self.u[e];
            }
        }
        Radiated { mouth, nostrils, skin, total: mouth + nostrils + skin }
    }

    /// The network's highest frequency (rad/s) for the step's geometry `k` (power iteration on M_p^-1/2 B^T M_u^-1 B
    /// M_p^-1/2, the lungs' node held): every mode's w dt must stay under 2 sqrt 3.
    pub fn highest_frequency(&mut self, k: &TubeCoefficients) -> f64 {
        let started = self.started;
        self.started = false;
        self.lay(k, None);
        self.started = started;
        let n = self.mp.len();
        let mut x: Vec<f64> = (0..n).map(|i| if i == LUNGS { 0.0 } else { 1.0 + 0.37 * ((i * 7919) % 101) as f64 / 101.0 }).collect();
        let mut y = vec![0.0; n];
        let mut lambda = 0.0;
        for _ in 0..400 {
            let norm = x.iter().map(|v| v * v).sum::<f64>().sqrt();
            x.iter_mut().for_each(|v| *v /= norm);
            for i in 0..n {
                self.p[i] = if i == LUNGS { 0.0 } else { x[i] / self.mp[i].sqrt() };
            }
            Self::apply_b(&self.elements, &self.edges, &self.walls, self.fe_edges, &self.p, &mut self.tmp);
            for e in 0..self.tmp.len() {
                self.tmp[e] /= self.mu[e];
            }
            Self::apply_bt(&self.elements, &self.edges, &self.walls, self.fe_edges, &self.tmp, &mut y);
            for i in 0..n {
                y[i] = if i == LUNGS { 0.0 } else { y[i] / self.mp[i].sqrt() };
            }
            lambda = x.iter().zip(&y).map(|(a, b)| a * b).sum::<f64>();
            std::mem::swap(&mut x, &mut y);
        }
        self.acc.copy_from_slice(&x);
        self.p.iter_mut().for_each(|v| *v = 0.0);
        lambda.max(0.0).sqrt()
    }

    /// Where the network's highest mode lives (for diagnosis): the node it is largest at, that node's section (or
    /// what else it is), and the mode's frequency (Hz).
    pub fn highest_mode(&mut self, k: &TubeCoefficients, glottis_lengths_cm: &[f64; 2]) -> (usize, String, f64) {
        self.glottis = (*glottis_lengths_cm, [WIDEST_GLOTTIS_CM2; 2]);
        let w = self.highest_frequency(k);
        // (the power iteration's vector is left in p, scaled by M_p^-1/2: undo it)
        let n = self.mp.len();
        let mut best = (0, 0.0f64);
        for i in 1..n {
            let x = (self.acc[i]).abs();
            if x > best.1 {
                best = (i, x);
            }
        }
        let node = best.0;
        let what = if let Some(el) = self.elements.iter().find(|el| el.nodes.contains(&node)) {
            format!("section {} (element node {})", el.section, el.nodes.iter().position(|&x| x == node).unwrap())
        } else if let Some(c) = self.cavity.iter().position(|&x| x == node) {
            format!("sinus cavity {c}")
        } else {
            format!("a wall's spring (of node {})", self.edges.iter().find(|e| e.to == node).map_or(0, |e| e.from))
        };
        (node, what, w / (2.0 * PI))
    }

    /// The fewest steps a 48-kHz sample whose step keeps every mode of the network for `k` within the corrected leapfrog's
    /// limit (STEP_MARGIN of it), the glottis's sections of `glottis_lengths_cm` at their widest (WIDEST_GLOTTIS_CM2,
    /// where its inertance is least): the rate the physics asks for this tube. Its motion is left at rest.
    pub fn steps_needed(&mut self, k: &TubeCoefficients, glottis_lengths_cm: &[f64; 2]) -> usize {
        let limit = STEP_MARGIN * 2.0 * 3f64.sqrt();
        let mut found = 64;
        // (the highest frequency is the masses' and the compliances', which the rate leaves as they are: found at the
        // first rate, each rate's step held to it)
        let mut highest = None;
        for n in 1..64 {
            self.set_rate(AUDIO_SAMPLING_RATE_HZ as f64 * n as f64);
            self.glottis = (*glottis_lengths_cm, [WIDEST_GLOTTIS_CM2; 2]);
            let w = *highest.get_or_insert_with(|| self.highest_frequency(k));
            assert!(w.is_finite(), "the network's highest frequency is not finite");
            if w * self.time_step <= limit {
                found = n;
                break;
            }
        }
        self.reset_motion();
        found
    }
}

/// An opening's radiation in OpenWInD's Pade form (physical_radiation.py taylor_to_pade; acoustics/radiation.json): a
/// mass and a resistance in parallel, L = rho delta r / A and R = (rho c / A) delta^2 / betaC, r the equivalent radius of
/// `area` (cm^2) -> (R, L), as tds.rs `radiation` gives 2.4's piston's.
pub fn pade_radiation(area: f64, delta: f64, beta_c: f64) -> (f64, f64) {
    use super::constants::{AMBIENT_DENSITY_CGS, SOUND_VELOCITY_CGS};
    let a = area.max(MIN_AREA_CM2);
    let r = (a / PI).sqrt();
    ((AMBIENT_DENSITY_CGS * SOUND_VELOCITY_CGS / a) * delta * delta / beta_c, AMBIENT_DENSITY_CGS * delta * r / a)
}

/// A radiation category by its name in acoustics/radiation.json -> its (delta, betaC); `2.4` (or `piston24`) None, 2.4's
/// own piston as the coefficients carry it.
pub fn radiation_category(name: &str) -> Option<(f64, f64)> {
    if name == "2.4" {
        return None;
    }
    let table: serde_json::Value = serde_json::from_str(include_str!("../../acoustics/radiation.json")).expect("acoustics/radiation.json");
    let c = table["categories"].get(name).unwrap_or_else(|| panic!("radiation={name}: 2.4 or one of acoustics/radiation.json's categories"));
    Some((c["delta"].as_f64().expect("its delta"), c["betaC"].as_f64().expect("its betaC")))
}

/// The walls' tissue by its name in acoustics/tract.json (`walls.tissues`), or by a number, the walls' own resonance over
/// 2.4's -> the factors on 2.4's mass, damping and stiffness per unit area. A resonance r raised by lighter walls, the
/// mass and the damping each 1/r^2 of 2.4's, so that the walls' own resonance keeps its width (damping over mass), the
/// stiffness kept (Fant 1972's women: r 1.14); a rigid wall's mass its `massFactor` times 2.4's; `2.4` 2.4's own.
pub fn tissue_factors(name: &str) -> (f64, f64, f64) {
    let raised = |r: f64| {
        assert!(r > 0.0 && r.is_finite(), "tissue={name}: a resonance over 2.4's walls' must be positive");
        let s = 1.0 / (r * r);
        (s, s, 1.0)
    };
    if name == "2.4" {
        return (1.0, 1.0, 1.0);
    }
    if let Ok(r) = name.parse::<f64>() {
        return raised(r);
    }
    let table: serde_json::Value = serde_json::from_str(include_str!("../../acoustics/tract.json")).expect("acoustics/tract.json");
    let t = table["walls"]["tissues"].get(name).unwrap_or_else(|| panic!("tissue={name}: 2.4, a number or one of acoustics/tract.json's walls.tissues"));
    match t["massFactor"].as_f64() {
        Some(m) => (m, 1.0, 1.0),
        None => raised(t["wallResonance"].as_f64().unwrap_or_else(|| panic!("tissue={name}: its wallResonance or its massFactor"))),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// A share's closed form is the implicit midpoint's: for a pressure v seen over a step, the flux y v + h and the
    /// branches' new charges solve c_0 (P0+ - P0)/dt = q, c_i (P_i+ - P_i)/dt = g_i (v - P0m - P_im),
    /// q = g_0 (v - P0m) + sum_i g_i (v - P0m - P_im), m the means -- from a wide duct's share to a closure's, whose
    /// fastest branch relaxes 1e5 times in a step.
    /// The engine's names (PassiveModel::acoustics): vocalwind the passive core as it sings, vocalfork the same core with
    /// 2.4's loss laws unless a losses= is said, and neither 2.4's own network.
    /// The radiation's categories (acoustics/radiation.json, OpenWInD's Pade form): the planar piston's gives 2.4's own
    /// resistance and inertance at every opening, to rounding; the unflanged pipe's its smaller end correction and, below
    /// kr 1, half its resistance; radiation= reaches the model, and 2.4 asks for 2.4's own.
    #[test]
    fn the_radiations_categories() {
        let piston = radiation_category("piston").expect("piston");
        let unflanged = radiation_category("unflanged").expect("unflanged");
        for area in [0.15, 0.8, 2.5, 6.0] {
            let (r24, l24) = super::super::tds::radiation_at(area);
            let (r, l) = pade_radiation(area, piston.0, piston.1);
            assert!((r / r24 - 1.0).abs() < 1e-12 && (l / l24 - 1.0).abs() < 1e-12, "{area} cm2: {r} {l} against 2.4's {r24} {l24}");
            let (ru, lu) = pade_radiation(area, unflanged.0, unflanged.1);
            assert!((lu / l - 0.6133 / piston.0).abs() < 1e-12);
            // (Below kr 1 the resistance a mass and a resistance in parallel present is (omega L)^2 / R.)
            assert!(((lu * lu / ru) / (l * l / r) - 0.5).abs() < 1e-3, "{area}: {}", (lu * lu / ru) / (l * l / r));
        }
        assert_eq!(radiation_category("2.4"), None);
        let (sp, _) = crate::v24::speaker::Speaker::read(&crate::blend::Voices::read(&crate::blend::voices_file()).unwrap().file(&crate::blend::synthesis_home(), "JD2").unwrap())
            .map(|s| (s, ())).unwrap_or_else(|e| panic!("{e}"));
        let (mut model, _) = PassiveModel::for_speaker(&sp.tract, &sp.glottis, TdsModel::new().options);
        assert_eq!(model.radiation_law, None);
        model.take_switches(&["radiation=unflanged".to_string()]);
        assert_eq!(model.radiation_law, Some(unflanged));
    }

    /// The walls' tissues (acoustics/tract.json walls.tissues): men's 2.4's own, exactly; a woman's walls' resonance 1.14
    /// times 2.4's, their mass and damping 1/1.14^2 of it and their stiffness kept, by her name or her number alike;
    /// rigid walls 10^12 times as heavy; tissue= reaches the model and has every wall laid again.
    #[test]
    fn the_walls_tissues() {
        assert_eq!(tissue_factors("2.4"), (1.0, 1.0, 1.0));
        assert_eq!(tissue_factors("men"), (1.0, 1.0, 1.0));
        let s = 1.0 / (1.14 * 1.14);
        assert_eq!(tissue_factors("women"), (s, s, 1.0));
        assert_eq!(tissue_factors("1.14"), tissue_factors("women"));
        assert_eq!(tissue_factors("rigid"), (1e12, 1.0, 1.0));
        let mut model = PassiveModel::new(&Tube::new(), TdsModel::new().options);
        assert_eq!(model.wall_tissue, (1.0, 1.0, 1.0));
        model.wall_laid.iter_mut().for_each(|b| *b = 0);
        model.take_switches(&["tissue=women".to_string()]);
        assert_eq!(model.wall_tissue, (s, s, 1.0));
        assert!(model.wall_laid.iter().all(|&b| b == u64::MAX));
    }

    #[test]
    fn the_engines_names() {
        let asked = |v: &[&str]| PassiveModel::acoustics(&v.iter().map(|s| s.to_string()).collect::<Vec<_>>());
        let said = |v: &[&str]| Some(v.iter().map(|s| s.to_string()).collect::<Vec<_>>());
        assert_eq!(asked(&["acoustics=vocalwind", "cores=2"]), said(&["acoustics=vocalwind", "cores=2"]));
        assert_eq!(asked(&["acoustics=vocalfork", "cores=2"]), said(&["losses=2.4", "acoustics=vocalfork", "cores=2"]));
        assert_eq!(asked(&["acoustics=vocalfork", "losses=zk"]), said(&["acoustics=vocalfork", "losses=zk"]));
        assert_eq!(asked(&["version=2.4", "acoustics=2.4"]), None);
        assert_eq!(asked(&["version=2.4"]), None);
    }

    #[test]
    fn a_shares_closed_form_is_the_implicit_midpoints() {
        let template = Tube::new();
        let mut model = PassiveModel::new(&template, TdsModel::new().options);
        model.thermal_layer = true;
        model.set_rate(240_000.0);
        let dt = model.time_step;
        let stiffness = AMBIENT_DENSITY_CGS * SOUND_VELOCITY_CGS * SOUND_VELOCITY_CGS;
        let diffusivity = HEAT_CONDUCTION_CGS / (AMBIENT_DENSITY_CGS * SPECIFIC_HEAT_CGS);
        for (area, length) in [(4.0, 0.1), (0.05, 0.13), (MIN_AREA_CM2, 0.08)] {
            // (the share laid as `lay` lays one, on the model's first element's middle node)
            let (c0, unit) = ((ADIABATIC_CONSTANT - 1.0) * area * length / stiffness, PI * diffusivity * (ADIABATIC_CONSTANT - 1.0) * length / stiffness);
            let share = 1;
            let node = model.elements[0].nodes[1];
            model.tc0.iter_mut().for_each(|x| *x = 0.0);
            model.ty.iter_mut().for_each(|x| *x = 0.0);
            model.tc0[share] = c0;
            model.tunit[share] = unit;
            (model.tgh[share], model.tci[share], model.tsum[share], model.ty[share]) = thermal_share(c0, unit, dt);
            assert!(0.5 * dt * model.ty[share] < c0, "dt y / 2 under the share's c_0");
            // what it holds, and the pressure it sees
            let held: [f64; THERMAL_N] = std::array::from_fn(|j| (0.3 + 0.17 * j as f64) * if j % 2 == 0 { 1.0 } else { -1.0 });
            for j in 0..THERMAL_N {
                model.ts[share][j] = held[j] * if j == 0 { c0 } else { c0 * DIFFUSIVE_A[j - 1] };
            }
            let v = 0.77;
            model.pt_start[node] = v;
            model.pt[node] = v;
            model.thermal_answers();
            let before = model.ts[share];
            let lost = model.thermal_step(true);
            let q = model.node_flux[node];
            assert!((q - (model.ty[share] * v + model.th[share])).abs() <= 1e-12 * q.abs());
            // the midpoint's equations, each to rounding against its own terms
            let c = |j: usize| if j == 0 { c0 } else { c0 * DIFFUSIVE_A[j - 1] };
            let mean = |j: usize| 0.5 * (before[j] + model.ts[share][j]) / c(j);
            let (g0, across) = (unit * DIFFUSIVE_A0, v - mean(0));
            let mut flux = g0 * across;
            let mut loss = g0 * across * across;
            for i in 0..DIFFUSIVE_N {
                let g = unit * DIFFUSIVE_A[i] / DIFFUSIVE_B[i];
                let qi = g * (across - mean(1 + i));
                let stepped = (model.ts[share][1 + i] - before[1 + i]) / dt;
                assert!((stepped - qi).abs() <= 1e-9 * (stepped.abs() + g * (across.abs() + mean(1 + i).abs())), "branch {i} of area {area}: {stepped} against {qi}");
                flux += stepped;
                loss += stepped * stepped / g;
            }
            assert!((flux - q).abs() <= 1e-9 * q.abs(), "area {area}: the flux {q} against its branches' {flux}");
            assert!(((model.ts[share][0] - before[0]) / dt - q).abs() <= 1e-12 * q.abs());
            assert!((lost - loss).abs() <= 1e-9 * loss, "area {area}: the losses {lost} against {loss}");
        }
    }

    /// The fitted law's size and scale are 2.4's two laws: U a_0 its DC law, the resistance as the frequency goes to
    /// nought, and 2 U sqrt(tau) its AC law's K (K sqrt(j w), R_ac (A_ref / A) sqrt(f) in its real part), from a
    /// closure's area to a wide mouth's -- the scale held at the representation's reach in a section wider than some
    /// 3 cm^2, and the elements laid with them.
    #[test]
    fn the_fitted_laws_size_and_scale_are_24s_laws() {
        for area in [0.01, 0.15, 1.0, 2.9, 4.0, 12.0] {
            let (u, tau) = fitted_scale(area);
            let dc = DC_R0 * (REF_AREA_CM2 / area).powf(DC_EXPONENT);
            let k = AC_R0 * REF_AREA_CM2 / area / PI.sqrt();
            assert!((2.0 * u * tau.sqrt() / k - 1.0).abs() < 1e-12, "area {area}");
            if tau < FITTED_TAU_MOST {
                assert!((u * DIFFUSIVE_A0 / dc - 1.0).abs() < 1e-12, "area {area}");
            } else {
                assert!(area > 2.9 && u * DIFFUSIVE_A0 > dc, "area {area}");
            }
        }
        let template = Tube::new();
        let mut model = PassiveModel::new(&template, TdsModel::new().options);
        model.take_switches(&["losses=fitted".into()]);
        assert!(model.viscous_layer && model.fitted_law && !model.thermal_layer);
        let mut k = TubeCoefficients::default();
        let mut tds = TdsModel::new();
        tds.set_tube(&template, false);
        tds.tube_coefficients(&mut k);
        model.lay(&k, None);
        for (e, el) in model.elements.iter().enumerate() {
            let a = k.area[el.section].max(MIN_AREA_CM2);
            let j = k.length[el.section] / el.parts as f64 / 2.0;
            let (u, tau) = fitted_scale(a);
            // (2.4's shut fossa's inlet has its resistance added: `lay`)
            if model.laid[e] != [u64::MAX; 5] {
                assert!((model.r[2 * e] / (j * u * DIFFUSIVE_A0) - 1.0).abs() < 1e-12);
            }
            for i in 0..DIFFUSIVE_N {
                assert!((model.vr[2 * e][i] / (j * u * DIFFUSIVE_A[i] / DIFFUSIVE_B[i]) - 1.0).abs() < 1e-12);
                assert!((model.vl[2 * e][i] / (j * u * DIFFUSIVE_A[i] * tau) - 1.0).abs() < 1e-12);
            }
        }
    }
}
