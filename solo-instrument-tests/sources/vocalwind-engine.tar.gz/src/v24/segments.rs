// VocalTractLab 2.4's rules for making a gestural score of a segment sequence (GesturalScore::createFromSegmentSequence
// and createPitchGestures), 2.3's (src/segments.rs) as 2.4 rewrote them. The sequence made plain SAMPA (pauses joined,
// 100 ms of pause at each end, affricates split); lung pressure for each run of phones between pauses, rising before
// it by its first phone's kind and falling so that it reaches 200, 150 or 100 Pa as its last phone (voiced, a plosive,
// a fricative) ends; modal phonation and a schwa beneath; each vowel's gesture and each diphthong's two timed from its
// neighbours (Birkholz's regressions on the previous vowel and the consonants between); a fricative's oral and glottal
// gestures, /h/'s and the glottal stop's, the lateral's; then the plosives and nasals, their closing gestures and the
// nasals' velic openings placed by 2.4's searches -- each boundary moved 2.5 ms at a time, the score's curves and the
// tract's geometry computed at each, until the closure (the port's opening) begins and ends where the segment says,
// a release's time constant shortened until it opens on time. F0 from the segments' own f0_20%_Hz, f0_50%_Hz and
// f0_80%_Hz where any is given (a glottal stop a dip), else the tier as it was. Each expression in the C++'s order.
// The phones and their classes are languages/phones.json's (src/inventory.rs), each phone's own numbers its `rules`
// "2.4"; the rules' numbers languages/rules-2.4.json (src/rules.rs).
use super::gestural::{put, time_to_step_response_value_s, GesturalScore, CURVE_SAMPLING_RATE, DEFAULT_TIME_CONSTANT_S, VELIC_CLOSING_TIME_CONSTANT_S, VELIC_OPENING_TIME_CONSTANT_S};
use super::gestural::{F0, GLOTTAL_SHAPE, LIP, LUNG_PRESSURE, TONGUE_BODY, TONGUE_TIP, VELIC, VOWEL};
use super::tract::{VocalTract, VO};
use super::tube::{self, Articulator, Tube};
use crate::gestural::{f0_hz, f0_st, Gesture};
use crate::inventory::{manner, phone, Manner};
use crate::rules::rules24;
use crate::segments::{atof, is_alveolar, is_diphthong, is_fricative, is_lateral, is_plosive, is_voiced, is_voiceless_oral_plosive, is_vowel, makes_postalveolar, tier_of, vowel_shape_on, Segment};

fn gesture(duration_s: f64, d_val: f64, s_val: &str, tau_s: f64, neutral: bool) -> Gesture {
    Gesture { duration_s, d_val, slope: 0.0, s_val: s_val.to_string(), tau_s, neutral }
}

/// The plain sequence: names and durations, with SegmentSequence's times (sums in order; 0 for an index out of it).
struct Plain {
    name: Vec<String>,
    duration: Vec<f64>,
}

impl Plain {
    fn len(&self) -> usize {
        self.name.len()
    }
    fn begin(&self, i: i64) -> f64 {
        let mut t = 0.0;
        if i >= 0 && (i as usize) < self.len() {
            for k in 0..i as usize {
                t += self.duration[k];
            }
        }
        t
    }
    fn end(&self, i: i64) -> f64 {
        let mut t = 0.0;
        if i >= 0 && (i as usize) < self.len() {
            for k in 0..=i as usize {
                t += self.duration[k];
            }
        }
        t
    }
    fn total(&self) -> f64 {
        let mut t = 0.0;
        for d in &self.duration {
            t += d;
        }
        t
    }
    /// The name at i, None out of the sequence.
    fn get(&self, i: i64) -> Option<&str> {
        if i >= 0 && (i as usize) < self.len() {
            Some(self.name[i as usize].as_str())
        } else {
            None
        }
    }
}

impl GesturalScore {
    /// The score for a segment sequence, as 2.4 makes it (createFromSegmentSequence); its F0 tier the segments' where
    /// they give any F0, else as it was. The tract is the speaker's, its geometry computed by the searches.
    pub fn from_segments(&mut self, original: &[Segment], vt: &mut VocalTract) {
        if original.is_empty() {
            return;
        }
        for t in [VOWEL, LIP, TONGUE_TIP, TONGUE_BODY, VELIC, GLOTTAL_SHAPE, LUNG_PRESSURE] {
            self.seq[t].gestures.clear();
        }
        let r = rules24();
        self.pitch_gestures(original);
        // Plain SAMPA: anything else a pause, the affricates split into their plosive and fricative.
        let mut sq = Plain { name: Vec::new(), duration: Vec::new() };
        for seg in original {
            let (n, d) = (seg.name.as_str(), seg.duration_s);
            if let Some(ph) = phone(n) {
                if let (Some(Manner::Affricate), Some([a, b]), Some(ratio)) = (ph.manner, &ph.parts, ph.plosive_share) {
                    sq.name.push(a.clone());
                    sq.duration.push(ratio * d);
                    sq.name.push(b.clone());
                    sq.duration.push((1.0 - ratio) * d);
                } else {
                    sq.name.push(n.to_string());
                    sq.duration.push(d);
                }
            } else {
                sq.name.push(String::new());
                sq.duration.push(d);
            }
        }
        // Pauses in a row made one; 100 ms of pause at least at the start, and exactly at the end.
        let mut i = 0;
        while i + 1 < sq.len() {
            if sq.name[i].is_empty() && sq.name[i + 1].is_empty() {
                sq.duration[i] += sq.duration[i + 1];
                sq.name.remove(i + 1);
                sq.duration.remove(i + 1);
            } else {
                i += 1;
            }
        }
        let pause = r.start_end_pause_s;
        if !sq.name[0].is_empty() {
            sq.name.insert(0, String::new());
            sq.duration.insert(0, pause);
        } else if sq.duration[0] < pause {
            sq.duration[0] = pause;
        }
        let last = sq.len() - 1;
        if !sq.name[last].is_empty() {
            sq.name.push(String::new());
            sq.duration.push(pause);
        } else {
            sq.duration[last] = pause;
        }
        let n = sq.len();
        // /d t n l/ next to /S Z/ in a cluster (three phones either way) are made postalveolar.
        let mut post = vec![false; n];
        for i in 0..n {
            if makes_postalveolar(&sq.name[i]) {
                post[i] = true;
                for k in 1..=3 {
                    if i >= k && is_alveolar(&sq.name[i - k]) {
                        post[i - k] = true;
                    } else {
                        break;
                    }
                }
                for k in 1..=3 {
                    if i + k < n && is_alveolar(&sq.name[i + k]) {
                        post[i + k] = true;
                    } else {
                        break;
                    }
                }
            }
        }
        // Lung pressure: none throughout, then 800 Pa over each run of phones between pauses.
        let l = &r.lungs;
        self.seq[LUNG_PRESSURE].gestures.push(gesture(sq.total(), 0.0, "", l.offset_tau_s, false));
        let mut i = 0;
        while i < n {
            while i < n && sq.name[i].is_empty() {
                i += 1;
            }
            let first = i;
            while i < n && !sq.name[i].is_empty() {
                i += 1;
            }
            let last = i as i64 - 1;
            if first < n && last < n as i64 {
                let (first_name, last_name) = (sq.name[first].clone(), sq.name[last as usize].clone());
                let mut begin = sq.begin(first as i64);
                let mut end = sq.end(last);
                if manner(&first_name) == Some(Manner::GlottalFricative) {
                    begin -= l.lead_taus_glottal_fricative * l.onset_tau_s;
                } else if is_plosive(&first_name) && !is_voiced(&first_name) {
                    begin = 0.5 * (sq.begin(first as i64) + sq.end(first as i64)) - l.lead_taus_voiceless_plosive_from_middle * l.onset_tau_s;
                } else if is_fricative(&first_name) {
                    begin -= l.lead_taus_fricative * l.onset_tau_s;
                } else {
                    begin -= l.lead_taus_other * l.onset_tau_s;
                }
                let target = if is_fricative(&last_name) {
                    l.end_dpa_fricative
                } else if is_plosive(&last_name) {
                    l.end_dpa_plosive
                } else {
                    l.end_dpa_other
                };
                end -= time_to_step_response_value_s((l.pressure_dpa - target) / l.pressure_dpa, l.offset_tau_s);
                let duration = end - begin;
                if duration > r.min_gesture_s {
                    put(&mut self.seq[LUNG_PRESSURE], gesture(duration, l.pressure_dpa, "", l.onset_tau_s, false), begin);
                }
            }
        }
        // Modal phonation, neutral consonantal and velic tiers, and a schwa, throughout.
        self.seq[GLOTTAL_SHAPE].gestures.push(gesture(sq.total(), 0.0, &r.phonation, DEFAULT_TIME_CONSTANT_S, false));
        for t in [LIP, TONGUE_TIP, TONGUE_BODY, VELIC] {
            self.seq[t].gestures.push(gesture(sq.total(), 0.0, "", DEFAULT_TIME_CONSTANT_S, true));
        }
        self.seq[VOWEL].gestures.push(gesture(sq.total(), 0.0, &r.neutral_vowel, DEFAULT_TIME_CONSTANT_S, false));
        self.vowels(&sq, vt);
        self.fricatives_and_laterals(&sq, &post);
        self.plosives_and_nasals(&sq, &post, vt);
    }

    /// Each vowel's gesture, and each diphthong's two, timed from the previous vowel and what lies between.
    fn vowels(&mut self, sq: &Plain, vt: &VocalTract) {
        let (v, dp) = (&rules24().vowels, &rules24().diphthongs);
        let n = sq.len();
        let mut prev_vowel: i64 = -1;
        let mut prev_movement_end = 0.0;
        for i in 0..n {
            let name = sq.name[i].as_str();
            let (begin, end) = (sq.begin(i as i64), sq.end(i as i64));
            if name.is_empty() {
                prev_vowel = -1;
                continue;
            }
            if !is_vowel(name) && !is_diphthong(name) {
                continue;
            }
            let ph = phone(name);
            let diphthong: Option<[&str; 2]> = ph.and_then(|p| p.shapes.as_ref()).map(|[a, b]| [a.as_str(), b.as_str()]);
            // (A vowel's or glide's shape, or its nearest's where the speaker has no shape of it.)
            let vowel: Option<&str> = ph.and_then(|p| p.vowel_shape()).and_then(|_| vowel_shape_on(name, |x| vt.shape(x).is_some()));
            if let Some(shape) = vowel {
                let (mut t1, t2);
                if prev_vowel == -1 {
                    t1 = begin - v.lead_taus_first * DEFAULT_TIME_CONSTANT_S;
                    t2 = begin;
                } else if prev_vowel == i as i64 - 1 {
                    t1 = begin - v.around_taus_after_vowel * DEFAULT_TIME_CONSTANT_S;
                    t2 = begin + v.around_taus_after_vowel * DEFAULT_TIME_CONSTANT_S;
                } else {
                    let pb = sq.begin(prev_vowel);
                    let pe = sq.end(prev_vowel);
                    let pd = pe - pb;
                    let cd = begin - pe;
                    t1 = pe - v.onset_a_s + v.onset_b * cd - v.onset_c * pd;
                    let mut x2 = begin + v.target_d_s - v.target_e * cd;
                    if t1 < pe - v.onset_earliest_before_previous_end_s {
                        t1 = pe - v.onset_earliest_before_previous_end_s;
                    }
                    if t1 < pb + v.onset_after_fraction_of_previous * pd {
                        t1 = pb + v.onset_after_fraction_of_previous * pd;
                    }
                    if x2 > begin + v.target_latest_after_begin_s {
                        x2 = begin + v.target_latest_after_begin_s;
                    }
                    if x2 - t1 > v.longest_movement_s {
                        t1 = x2 - v.longest_movement_s;
                    }
                    t2 = x2;
                }
                if t1 < prev_movement_end {
                    t1 = prev_movement_end;
                }
                if t1 < 0.0 {
                    t1 = 0.0;
                }
                put(&mut self.seq[VOWEL], gesture(end - t1, 0.0, shape, v.tau_fraction_of_movement * (t2 - t1), false), t1);
                prev_movement_end = t2;
            } else if let Some([d0, d1]) = diphthong {
                let duration = end - begin;
                let middle = begin + 0.5 * duration;
                let transition = dp.transition_a_s + dp.transition_b * duration;
                let mut t2 = middle - 0.5 * transition;
                let mut t3 = middle + 0.5 * transition;
                let mut t1;
                if prev_vowel == -1 {
                    t1 = t2 - dp.lead_taus * DEFAULT_TIME_CONSTANT_S;
                    let alternative = begin + dp.first_alternative_after_begin_s - dp.lead_taus * DEFAULT_TIME_CONSTANT_S;
                    if alternative < t1 {
                        t1 = alternative;
                    }
                } else if prev_vowel == i as i64 - 1 {
                    t1 = t2 - dp.lead_taus * DEFAULT_TIME_CONSTANT_S;
                    let prev_middle = 0.5 * (sq.begin(prev_vowel) + sq.end(prev_vowel));
                    if t1 < prev_middle {
                        t1 = prev_middle;
                    }
                } else {
                    t1 = sq.end(prev_vowel) - dp.onset_before_previous_end_s;
                    if t2 - t1 > dp.longest_movement_s {
                        t1 = t2 - dp.longest_movement_s;
                    }
                }
                t1 = t1.max(0.0);
                t2 = t2.max(0.0);
                t3 = t3.max(0.0);
                if t1 < prev_movement_end {
                    t1 = prev_movement_end;
                }
                let mut tau = dp.tau_fraction_of_movement * (t2 - t1);
                if tau > DEFAULT_TIME_CONSTANT_S {
                    tau = DEFAULT_TIME_CONSTANT_S;
                }
                put(&mut self.seq[VOWEL], gesture(t2 - t1, 0.0, d0, tau, false), t1);
                put(&mut self.seq[VOWEL], gesture(end - t2, 0.0, d1, dp.tau_fraction_of_movement * (t3 - t2), false), t2);
                prev_movement_end = t3;
            }
            prev_vowel = i as i64;
        }
    }

    /// The fricatives' oral and glottal gestures, /h/'s and the glottal stop's, and the lateral's.
    fn fricatives_and_laterals(&mut self, sq: &Plain, post: &[bool]) {
        let r = rules24();
        let n = sq.len();
        for i in 1..n - 1 {
            let name = sq.name[i].as_str();
            let mut begin = sq.begin(i as i64);
            let mut end = sq.end(i as i64);
            if i == 1 {
                begin = 0.0;
            } else if i == n - 2 {
                end = sq.total();
            } else if sq.name[i - 1].is_empty() {
                begin = 0.5 * (sq.begin(i as i64 - 1) + sq.end(i as i64 - 1));
            } else if sq.name[i + 1].is_empty() {
                end = 0.5 * (sq.begin(i as i64 + 1) + sq.end(i as i64 + 1));
            }
            let next = sq.get(i as i64 + 1).unwrap_or("").to_string();
            let mut next_audible = next.clone();
            if next_audible.is_empty() {
                next_audible = sq.get(i as i64 + 2).unwrap_or("").to_string();
            }
            let ph = phone(name);
            // (/j/'s glottis modal.)
            let fricative: Option<(usize, &str, &str)> = ph.filter(|p| p.manner == Some(Manner::Fricative)).map(|p| (tier_of(p.articulator), p.oral.as_deref().unwrap_or(""), p.glottal.as_deref().unwrap_or("")));
            if let Some((tier, oral, glottal)) = fricative {
                let f = &r.fricatives;
                let tau = DEFAULT_TIME_CONSTANT_S;
                let transition = f.transition_taus * tau;
                let half = 0.5 * transition;
                let mut oral_begin = begin - half - f.oral_lead_s;
                let mut oral_end = end - half;
                oral_begin = oral_begin.max(0.0);
                oral_end = oral_end.max(0.0);
                let articulator = |s: &str| phone(s).and_then(|p| p.articulator);
                if is_plosive(&next) && articulator(name) != articulator(&next) {
                    oral_end += f.oral_held_before_plosive_elsewhere_s;
                }
                put(&mut self.seq[tier], gesture(oral_end - oral_begin, 0.0, oral, tau, false), oral_begin);
                put(&mut self.seq[tier], gesture(transition, 0.0, oral, tau, true), oral_end);
                let mut glottal_begin = begin - half;
                let mut glottal_end = end - half;
                if !is_voiced(name) && is_voiceless_oral_plosive(&next_audible) {
                    glottal_end += f.glottis_held_before_voiceless_plosive_s;
                }
                glottal_begin = glottal_begin.max(0.0);
                glottal_end = glottal_end.max(0.0);
                put(&mut self.seq[GLOTTAL_SHAPE], gesture(glottal_end - glottal_begin, 0.0, glottal, tau, false), glottal_begin);
            }
            let Some(ph) = ph else { continue };
            if matches!(ph.manner, Some(Manner::GlottalFricative | Manner::GlottalStop)) {
                let gb = (begin - r.glottal.lead_s).max(0.0);
                let ge = (end - r.glottal.lead_s).max(0.0);
                put(&mut self.seq[GLOTTAL_SHAPE], gesture(ge - gb, 0.0, ph.glottal.as_deref().unwrap_or(""), DEFAULT_TIME_CONSTANT_S, false), gb);
            }
            if ph.manner == Some(Manner::Lateral) {
                let (transition, tier) = (r.lateral.transition_s, tier_of(ph.articulator));
                let t1 = (begin - 0.5 * transition).max(0.0);
                let t2 = (end - 0.5 * transition).max(0.0);
                let t3 = (end + 0.5 * transition).max(0.0);
                let oral = match (&ph.oral_postalveolar, &ph.oral) {
                    (Some(o), _) if post[i] => o.as_str(),
                    (_, Some(o)) => o.as_str(),
                    _ => "",
                };
                put(&mut self.seq[tier], gesture(t2 - t1, 0.0, oral, r.lateral.tau_fraction_of_transition * transition, false), t1);
                put(&mut self.seq[tier], gesture(t3 - t2, 0.0, "", r.lateral.tau_fraction_of_transition * transition, true), t2);
            }
        }
    }

    /// The plosives and nasals: their closing gestures (and the nasals' velic openings) placed by the searches, the
    /// plosives' glottal gestures from their voice onset times (Birkholz's regressions on the segment's duration).
    fn plosives_and_nasals(&mut self, sq: &Plain, post: &[bool], vt: &mut VocalTract) {
        let r = rules24();
        let (pl, na) = (&r.plosives, &r.nasals);
        let n = sq.len();
        let mut prev_oral = String::new();
        for i in 1..n - 1 {
            let name = sq.name[i].as_str();
            let (begin, end) = (sq.begin(i as i64), sq.end(i as i64));
            let duration = end - begin;
            let (mut mod_begin, mut mod_end) = (begin, end);
            if i == 1 {
                mod_begin = 0.0;
            } else if i == n - 2 {
                mod_end = sq.total();
            } else if sq.name[i - 1].is_empty() {
                mod_begin = 0.5 * (sq.begin(i as i64 - 1) + sq.end(i as i64 - 1));
            } else if sq.name[i + 1].is_empty() {
                mod_end = 0.5 * (sq.begin(i as i64 + 1) + sq.end(i as i64 + 1));
            }
            let prev_name = sq.get(i as i64 - 1).unwrap_or("").to_string();
            let mut prev_audible = prev_name.clone();
            if prev_audible.is_empty() {
                prev_audible = sq.get(i as i64 - 2).unwrap_or("").to_string();
            }
            let next = sq.get(i as i64 + 1).unwrap_or("").to_string();
            let mut next_audible = next.clone();
            if next_audible.is_empty() {
                next_audible = sq.get(i as i64 + 2).unwrap_or("").to_string();
            }
            let (mut plosive, mut nasal) = (false, false);
            let mut oral = String::new();
            let mut glottal = "";
            let mut vot = 0.0;
            let mut tier = LIP;
            let (mut onset_tau, mut offset_tau) = (DEFAULT_TIME_CONSTANT_S, DEFAULT_TIME_CONSTANT_S);
            let (mut velic_target, mut velic_extension) = (0.0, 0.0);
            let mut short_release = false;
            let ph = phone(name);
            if let Some(ph) = ph.filter(|p| matches!(p.manner, Some(Manner::Plosive | Manner::Nasal))) {
                // (Each phone's numbers languages/phones.json's: a plosive's voice onset time Birkholz's regression on
                // its segment's duration, bounded, or as given; a nasal's velic opening and its extension.)
                let v = ph.rules.v24.as_ref().expect("a plosive's or nasal's 2.4 numbers");
                tier = tier_of(ph.articulator);
                oral = match (&ph.closure_postalveolar, &ph.closure) {
                    (Some(c), _) if post[i] => c.clone(),
                    (_, Some(c)) => c.clone(),
                    _ => String::new(),
                };
                onset_tau = v.onset_tau_s.unwrap_or(DEFAULT_TIME_CONSTANT_S);
                offset_tau = v.offset_tau_s.unwrap_or(DEFAULT_TIME_CONSTANT_S);
                if ph.manner == Some(Manner::Plosive) {
                    plosive = true;
                    glottal = v.glottal.as_deref().or(ph.glottal.as_deref()).unwrap_or("");
                    vot = match (v.vot_regression, v.vot_limit_s) {
                        (Some([a, b]), Some(limit)) => {
                            let x = duration.min(limit);
                            a * x * x + b * x
                        }
                        _ => v.vot_s.unwrap_or(0.0),
                    };
                    short_release = v.short_release_before.iter().any(|x| *x == next);
                } else {
                    nasal = true;
                    velic_target = v.velic_target.expect("a nasal's velic target");
                    velic_extension = v.velic_extension_s.expect("a nasal's velic extension");
                }
            }
            if plosive {
                if vot < 0.0 {
                    vot = 0.0;
                }
                // (Released into a fricative made at the same place: a short release.)
                if short_release {
                    vot = pl.short_release_vot_s;
                    offset_tau = pl.short_release_offset_tau_s;
                }
                let ph = ph.expect("a plosive's phone");
                let closure_begin = mod_begin.max(0.0);
                let mut closure_end = end - vot;
                if closure_end - closure_begin < pl.min_closure_s {
                    closure_end = closure_begin + pl.min_closure_s;
                }
                let glottal_begin = closure_begin - pl.glottis_lead_s;
                let mut glottal_end = mod_end - pl.glottis_end_before_end_s;
                if glottal_end - glottal_begin < pl.glottis_min_s {
                    glottal_end = glottal_begin + pl.glottis_min_s;
                }
                if is_voiced(name) {
                    glottal_end = end - pl.voiced_glottis_end_before_end_s;
                }
                if is_fricative(&next_audible) && is_voiced(&next_audible) {
                    glottal_end -= pl.glottis_shortened_before_voiced_fricative_s;
                }
                // (Released into a homorganic nasal or lateral.)
                if ph.released_into.iter().any(|x| *x == next) {
                    closure_end = end;
                    glottal_end = end - pl.released_glottis_end_before_end_s;
                }
                if is_lateral(&next) && ph.lateral_release {
                    glottal_end = end - pl.lateral_release_glottis_end_before_end_s;
                }
                if glottal_end < glottal_begin + pl.min_glottal_gesture_s {
                    glottal_end = glottal_begin + pl.min_glottal_gesture_s;
                }
                let connect = oral == prev_oral;
                self.add_closing_gesture(vt, tier, &oral, closure_begin, closure_end, onset_tau, offset_tau, connect);
                let glottal_begin = glottal_begin.max(0.0);
                let glottal_end = glottal_end.max(0.0);
                put(&mut self.seq[GLOTTAL_SHAPE], gesture(glottal_end - glottal_begin, 0.0, glottal, DEFAULT_TIME_CONSTANT_S, false), glottal_begin);
            } else if nasal {
                let closure_begin = mod_begin.max(0.0);
                let closure_end = mod_end;
                let mut velic_begin = mod_begin - velic_extension;
                let mut velic_end = mod_end + velic_extension;
                if is_plosive(&prev_audible) {
                    velic_begin = mod_begin - na.velic_lead_after_plosive_s;
                }
                if is_plosive(&next_audible) {
                    velic_end = mod_end;
                }
                if is_fricative(&prev_audible) {
                    velic_begin = mod_begin - na.velic_beside_fricative_s;
                }
                if is_fricative(&next_audible) {
                    velic_end = mod_end + na.velic_beside_fricative_s;
                }
                if is_lateral(&prev_audible) {
                    velic_begin = mod_begin - na.velic_beside_lateral_s;
                }
                if is_lateral(&next_audible) {
                    velic_end = mod_end + na.velic_beside_lateral_s;
                }
                let velic_begin = velic_begin.max(0.0);
                let connect = oral == prev_oral;
                self.add_closing_gesture(vt, tier, &oral, closure_begin, closure_end, onset_tau, offset_tau, connect);
                self.add_velic_opening_gesture(vt, velic_begin, velic_end, velic_target);
            }
            prev_oral = oral;
        }
    }

    /// The F0 tier from the segments' f0_20%_Hz, f0_50%_Hz and f0_80%_Hz (createPitchGestures): their nodes, those
    /// missing filled between the given (or held), a glottal stop's dip (its middle falling 100 st/s of its length, to
    /// 50 st at least, its edges no higher than their neighbours), each node a target reached by a line from the last.
    /// Left as it was where no segment gives an F0.
    fn pitch_gestures(&mut self, original: &[Segment]) {
        struct Node {
            name: String,
            percent: i32,
            time_s: f64,
            f0_hz: f64,
        }
        let p = &rules24().pitch;
        let min_f0_hz = p.least_f0_hz;
        let glottal_stop = |s: &str| manner(s) == Some(Manner::GlottalStop);
        let value = |seg: &Segment, key: &str| -> f64 { seg.label(key).map(atof).unwrap_or(0.0) };
        let mut nodes: Vec<Node> = Vec::new();
        let mut start = 0.0;
        for seg in original {
            let d = seg.duration_s;
            if glottal_stop(&seg.name) {
                for (percent, at) in [(0, start), (50, start + 0.5 * d), (100, start + d)] {
                    nodes.push(Node { name: seg.name.clone(), percent, time_s: at, f0_hz: 0.0 });
                }
            } else if !seg.name.is_empty() {
                for (percent, key, r) in [(20, "f0_20%_Hz", 0.2), (50, "f0_50%_Hz", 0.5), (80, "f0_80%_Hz", 0.8)] {
                    nodes.push(Node { name: seg.name.clone(), percent, time_s: start + r * d, f0_hz: value(seg, key) });
                }
            }
            start += d;
        }
        if !nodes.iter().any(|x| x.f0_hz >= min_f0_hz) {
            return;
        }
        self.seq[F0].gestures.clear();
        let count = nodes.len();
        for i in 0..count {
            if nodes[i].f0_hz < min_f0_hz {
                let mut left = i;
                while left > 0 && nodes[left].f0_hz < min_f0_hz {
                    left -= 1;
                }
                let mut right = i;
                while right < count - 1 && nodes[right].f0_hz < min_f0_hz {
                    right += 1;
                }
                let (lf, rf, lt, rt) = (nodes[left].f0_hz, nodes[right].f0_hz, nodes[left].time_s, nodes[right].time_s);
                nodes[i].f0_hz = if lf >= min_f0_hz && rf >= min_f0_hz {
                    let mut diff = rt - lt;
                    if diff < p.least_interval_s {
                        diff = p.least_interval_s;
                    }
                    lf + (rf - lf) * (nodes[i].time_s - lt) / diff
                } else if lf >= min_f0_hz {
                    lf
                } else if rf >= min_f0_hz {
                    rf
                } else {
                    min_f0_hz
                };
            }
        }
        for i in 1..count.saturating_sub(1) {
            if glottal_stop(&nodes[i].name) {
                if nodes[i].percent == 0 {
                    if nodes[i].f0_hz > nodes[i - 1].f0_hz {
                        nodes[i].f0_hz = nodes[i - 1].f0_hz;
                    }
                } else if nodes[i].percent == 100 {
                    if nodes[i].f0_hz > nodes[i + 1].f0_hz {
                        nodes[i].f0_hz = nodes[i + 1].f0_hz;
                    }
                } else if nodes[i].percent == 50 {
                    let length = nodes[i + 1].time_s - nodes[i - 1].time_s;
                    let mut st = f0_st(nodes[i].f0_hz) - length * p.glottal_stop_dip_st_per_s;
                    if st < p.glottal_stop_floor_st {
                        st = p.glottal_stop_floor_st;
                    }
                    nodes[i].f0_hz = f0_hz(st);
                }
            }
        }
        let epsilon = p.least_interval_s;
        let mut prev_st = 0.0;
        for i in 0..count {
            let st = f0_st(nodes[i].f0_hz);
            let mut g = gesture(0.0, 0.0, "", p.tau_s, false);
            if i == 0 {
                g.duration_s = nodes[i].time_s - p.first_node_lead_s;
                if g.duration_s < epsilon {
                    g.duration_s = epsilon;
                }
                g.d_val = st;
            } else {
                g.duration_s = nodes[i].time_s - nodes[i - 1].time_s;
                if g.duration_s < epsilon {
                    g.duration_s = epsilon;
                }
                g.d_val = prev_st;
                g.slope = (st - prev_st) / g.duration_s;
            }
            self.seq[F0].gestures.push(g);
            prev_st = st;
        }
    }

    /// A closing gesture placed so the tract is closed from `closure_begin` to `closure_end` (addClosingGesture): its
    /// start moved back 2.5 ms at a time until it closes by the closure's start (or joined to the same gesture before
    /// it), its end moved back while it stays closed through, or on until it closes at the closure's end; its release
    /// quickened 0.5 ms at a time (to 5 ms) until it opens by the closure's end.
    #[allow(clippy::too_many_arguments)]
    fn add_closing_gesture(&mut self, vt: &mut VocalTract, tier: usize, name: &str, closure_begin: f64, mut closure_end: f64, onset_tau: f64, mut offset_tau: f64, connect: bool) {
        const TIME_STEP_S: f64 = 1.0 / CURVE_SAMPLING_RATE as f64;
        let c = &rules24().closing;
        let max_d = c.longest_gesture_s;
        if closure_end < closure_begin + c.min_closure_s {
            closure_end = closure_begin + c.min_closure_s;
        }
        let mut gb = closure_begin - c.start_before_closure_s;
        let mut ge = closure_begin;
        if connect {
            let seq = &self.seq[tier];
            let mut prev: i64 = -1;
            let mut pos = 0.0;
            for (i, g) in seq.gestures.iter().enumerate() {
                pos += g.duration_s;
                if !g.neutral && pos < closure_begin {
                    prev = i as i64;
                }
            }
            if prev != -1 {
                let mut end = 0.0;
                for g in &seq.gestures[..=prev as usize] {
                    end += g.duration_s;
                }
                gb = end;
            }
        }
        let mut closed = false;
        let mut error = false;
        if gb <= 0.0 {
            gb = 0.0;
            closed = true;
        }
        while !connect && !closed && !error {
            gb -= TIME_STEP_S;
            closed = self.has_closure(vt, tier, name, gb, ge, onset_tau, offset_tau, closure_begin);
            if gb < c.earliest_start_s || ge - gb > max_d {
                if ge - gb > max_d {
                    gb = closure_begin - c.start_before_closure_s;
                }
                error = true;
            }
        }
        closed = self.has_closure(vt, tier, name, gb, ge, onset_tau, offset_tau, closure_end);
        if closed {
            let (mut onset, mut offset, mut too_short) = (true, true, false);
            while onset && offset && !too_short {
                ge -= TIME_STEP_S;
                onset = self.has_closure(vt, tier, name, gb, ge, onset_tau, offset_tau, closure_begin);
                offset = self.has_closure(vt, tier, name, gb, ge, onset_tau, offset_tau, closure_end);
                if ge - gb < c.shortest_gesture_s {
                    too_short = true;
                }
            }
            if !onset || too_short {
                ge += TIME_STEP_S;
            }
            while offset && offset_tau >= c.release_tau_least_s + c.release_tau_step_s {
                offset_tau -= c.release_tau_step_s;
                offset = self.has_closure(vt, tier, name, gb, ge, onset_tau, offset_tau, closure_end);
            }
        } else {
            error = false;
            while !closed && !error {
                ge += TIME_STEP_S;
                closed = self.has_closure(vt, tier, name, gb, ge, onset_tau, offset_tau, closure_end);
                if ge - gb > max_d {
                    ge = gb + c.shortest_gesture_s;
                    error = true;
                }
            }
        }
        self.put_closing_gesture(tier, name, gb, ge, onset_tau, offset_tau);
    }

    /// Whether the tract is closed at `at` by the articulator of `tier`, the closing gesture put as asked
    /// (hasVocalTactClosure): a section narrower than twice the tube's least area, at the lower lip, the tongue's last
    /// 2.2 cm or the tongue behind them.
    #[allow(clippy::too_many_arguments)]
    fn has_closure(&mut self, vt: &mut VocalTract, tier: usize, name: &str, gb: f64, ge: f64, onset_tau: f64, offset_tau: f64, at: f64) -> bool {
        let stored = self.seq[tier].gestures.clone();
        self.put_closing_gesture(tier, name, gb, ge, onset_tau, offset_tau);
        let params = self.tract_params_at(vt, at);
        vt.calculate(&params);
        let geometry = vt.tube();
        let mut t = Tube::new();
        t.set_from_tract(&geometry);
        let sections = &t.section[tube::FIRST_PHARYNX_SECTION..tube::FIRST_PHARYNX_SECTION + tube::NUM_PHARYNX_MOUTH_SECTIONS];
        let mut tip = 0.0;
        for ts in sections {
            if ts.articulator == Articulator::Tongue {
                tip = ts.pos_cm + ts.length_cm;
            }
        }
        let c = &rules24().closing;
        let tongue_tip_region_cm = c.tongue_tip_region_cm;
        let mut closed = false;
        for ts in sections {
            if ts.area_cm2 < c.closed_area_factor * tube::MIN_AREA_CM2 {
                let pos = ts.pos_cm + 0.5 * ts.length_cm;
                if tier == LIP && ts.articulator == Articulator::LowerLip {
                    closed = true;
                }
                if tier == TONGUE_TIP && ts.articulator == Articulator::Tongue && pos > tip - tongue_tip_region_cm {
                    closed = true;
                }
                if tier == TONGUE_BODY && ts.articulator == Articulator::Tongue && pos < tip - tongue_tip_region_cm {
                    closed = true;
                }
            }
        }
        self.seq[tier].gestures = stored;
        closed
    }

    /// A closing gesture and its return to neutral, the return ten of its time constants long or as long as the
    /// neutral gestures after it allow (putClosingGesture).
    fn put_closing_gesture(&mut self, tier: usize, name: &str, gb: f64, ge: f64, onset_tau: f64, offset_tau: f64) {
        let mut index = put(&mut self.seq[tier], gesture(ge - gb, 0.0, name, onset_tau, false), gb) + 1;
        let count = self.seq[tier].gestures.len();
        let mut neutral = 0.0;
        while index < count {
            let g = &self.seq[tier].gestures[index];
            if g.neutral {
                neutral += g.duration_s;
            } else {
                break;
            }
            index += 1;
        }
        let mut ret = rules24().closing.return_taus * offset_tau;
        if ret > neutral {
            ret = neutral;
        }
        put(&mut self.seq[tier], gesture(ret, 0.0, "", offset_tau, true), ge);
    }

    /// A velic gesture placed so the port is open (by 0.01 cm2) from `open_begin` to `open_end`
    /// (addVelicOpeningGesture): its start moved back 2.5 ms at a time until it is open by the opening's start, its end
    /// on from 10 ms after that until it is open at the opening's end; its return to closed after it.
    fn add_velic_opening_gesture(&mut self, vt: &VocalTract, open_begin: f64, mut open_end: f64, target: f64) {
        const TIME_STEP_S: f64 = 1.0 / CURVE_SAMPLING_RATE as f64;
        let v = &rules24().velic;
        let max_d = v.longest_gesture_s;
        if open_end < open_begin + v.min_opening_s {
            open_end = open_begin + v.min_opening_s;
        }
        let mut gb = open_begin;
        let mut ge = open_end + v.end_after_opening_s;
        if gb <= 0.0 {
            gb = 0.0;
        }
        if ge < gb + v.min_gesture_s {
            ge = gb + v.min_gesture_s;
        }
        let mut open = self.has_velic_opening(vt, gb, ge, target, open_begin);
        let mut error = false;
        while !open && !error {
            gb -= TIME_STEP_S;
            open = self.has_velic_opening(vt, gb, ge, target, open_begin);
            if gb < v.earliest_start_s || ge - gb > max_d {
                if ge - gb > max_d {
                    gb = open_begin - v.fallback_lead_s;
                }
                error = true;
            }
        }
        ge = gb + v.first_end_after_start_s;
        open = self.has_velic_opening(vt, gb, ge, target, open_end);
        error = false;
        while !open && !error {
            ge += TIME_STEP_S;
            open = self.has_velic_opening(vt, gb, ge, target, open_end);
            if ge - gb > max_d {
                ge = gb + v.first_end_after_start_s;
                error = true;
            }
        }
        put(&mut self.seq[VELIC], gesture(ge - gb, target, "", VELIC_OPENING_TIME_CONSTANT_S, false), gb);
        put(&mut self.seq[VELIC], gesture(rules24().velic.return_taus * VELIC_CLOSING_TIME_CONSTANT_S, 0.0, "", VELIC_CLOSING_TIME_CONSTANT_S, true), ge);
    }

    /// Whether the velic port is open by 0.01 cm2 at `at`, the opening gesture put as asked (hasVelicOpening).
    fn has_velic_opening(&mut self, vt: &VocalTract, gb: f64, ge: f64, target: f64, at: f64) -> bool {
        let stored = self.seq[VELIC].gestures.clone();
        put(&mut self.seq[VELIC], gesture(ge - gb, target, "", VELIC_OPENING_TIME_CONSTANT_S, false), gb);
        put(&mut self.seq[VELIC], gesture(rules24().velic.return_taus * VELIC_CLOSING_TIME_CONSTANT_S, 0.0, "", VELIC_CLOSING_TIME_CONSTANT_S, true), ge);
        let open = self.tract_params_at(vt, at)[VO] >= rules24().velic.open_cm2;
        self.seq[VELIC].gestures = stored;
        open
    }
}
