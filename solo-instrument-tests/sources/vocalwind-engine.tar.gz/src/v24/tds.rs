// VocalTractLab 2.4's tube in the time domain (TdsModel.cpp of 5 December 2025), as tds.rs is 2.3's: each section a
// lumped element -- its air's inertance and compliance; its losses by 2.4's law, a resistance per unit length from a DC
// and an AC term of its area (the larger), the sinuses' by Poiseuille's raised fifteenfold; its soft walls from their
// mass, damping and stiffness per unit area of its surface; the pressure recovered past a widening (a fifth at the
// glottis, half elsewhere); noise sources at the glottis, the velic port, up to two tongue constrictions and the lips;
// the radiation at the mouth and nostrils, and the walls' own flow, radiated from the skin -- discretized implicitly
// (theta 0.5) and solved each sample for its branch currents by a Cholesky factorization in an envelope. Where 2.4
// changed nothing of 2.3's, its code is 2.3's port's. Every expression in the C++'s order; its constriction log, never
// heard, and a filter object built per noise source per sample, are not made (its coefficients are computed, again
// only when its cutoff changes).
use super::constants::*;
use super::solve::{Dd, EnvelopeCholesky, System, TreeCholesky};
use super::tube::{self, Articulator, Tube, NUM_SECTIONS};
use crate::iir::{second_order_lowpass, IirFilter};
use crate::rng::{Mt19937, NormalDistribution};

pub const NUM_BRANCH_CURRENTS: usize = NUM_SECTIONS + 4;
const MAX_ENVELOPE_COLUMNS: usize = 66;
const MAX_ENVELOPE_ROWS: usize = 10;
const MAX_CONSTRICTIONS: usize = 8;
const NOISE_BUFFER_MASK: i32 = 7;
pub const THETA: f64 = 0.5;
pub const THETA1: f64 = 1.0 - THETA;
pub const MIN_AREA_CM2: f64 = 0.0001;
pub const NOISE_CUTOFF_FREQ: f64 = 500.0;
const MAX_CONSTRICTION_AREA: f64 = 1.0;
/// The lips' dipole's place among the noise sources (after every section's two).
const LIPS_SOURCE: usize = 2 * NUM_SECTIONS;
const MAX_DELTA_AREA: f64 = 0.2;
const N: usize = NUM_BRANCH_CURRENTS;

/// How the radiated sound is filtered (the synthesizer's; the model only says which).
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Radiation {
    Simple,
    PistonSphere,
    HeadTorso,
}

#[derive(Clone, Copy, Debug)]
pub struct Options {
    pub soft_walls: bool,
    /// Movements slowed near a closure (setTube's filtering).
    pub soft_contacts: bool,
    pub generate_noise_sources: bool,
    /// The walls' flow radiated from the skin.
    pub radiation_from_skin: bool,
    pub piriform_fossa: bool,
    pub inner_length_corrections: bool,
    /// The speed a constriction's noise is figured from held under sound's, where 2.4 takes its smoothed flow over its
    /// area as they are: a glottis closing within a few steps under a strong flow pairs the flow of before with the area
    /// of after -- speeds a hundred times sound's, noise as their cube, and the tract run away to NaN
    /// (docs/VOCAL_TRACT.md, "Found in reading"). The noise's law is a subsonic jet's; no jet of 2.4's examples comes
    /// near it, and they are its own sample for sample with it. On by default (the owner, 12 November 2026: "You can
    /// deploy this fix by default"); off, 2.4 as it is, as its parity checks run it.
    pub bound_noise_velocity: bool,
    /// The pressure recovered past a sudden widening at a junction with a side branch taken as Borda and Carnot's law has
    /// it -- 2r / (1 + r) of the Bernoulli pressure, r the narrower area over the wider: the whole where they meet, less
    /// the sharper the widening -- where 2.4 recovers the whole of it there whatever the flow does
    /// (TdsModel::prepareTimeStep: its widening's test, and its half, only where there is no branch). At the epilarynx's top,
    /// where the piriform fossa leaves it and it opens into the pharynx, the whole is a negative resistance growing with
    /// the flow, which under a strong one -- a glottis held wide open, 545 cm3/s through its 0.32 cm2 into the pharynx's
    /// 2.8 -- with that short section's mass and compliance grows a mode near 24 kHz to NaN at 96 kHz and above (48 kHz,
    /// 2.4's rate, bends it to about 15 kHz and damps it): examples/v24_open_glottis.rs; docs/VOCAL_TRACT.md, "Found in
    /// reading". There the law recovers about a fifth (r = 0.12): the mode is damped. Smooth in the areas, so that a
    /// widening turning into a narrowing steps nothing (2.4's half instead stepped the side branch's equation, where the
    /// upstream half's term also is: a click, prepare_time_step). Off by default: passive_bernoulli mends the mode
    /// it was made for, and every other the sweep found; with a smoothed recovery tried before it, it stepped the
    /// reading's "sehr" again (render audit).
    pub recover_at_branches: bool,
    /// Bernoulli's terms passive at the frequencies the tube's sections have their own modes. Each junction's pair, k (q_t -
    /// q_i) of the dynamic pressures q = rho u^2 / 2 a^2 of the section the flow enters and of the one it leaves, taken
    /// as its two parts: the lossless exchange, q_t - q_i, from each section's own q (its mean flow and its area
    /// together) low-passed at `bernoulli_cutoff_hz`, a source in each branch the junction feeds; and the jet's loss past
    /// a widening, (1 - k)(q_i - q_t), a resistance on the flow as it is, as 2.4 has it, its incremental resistance
    /// positive wherever it acts. Steady or slow, 2.4's pressures to the unit; above the cutoff only the loss acts at
    /// once, and it only takes energy. 2.4's pair, a negative resistance on the flow as it is wherever the flow widens,
    /// under a strong flow -- 16,000 dPa through a glottis held open or a fricative's narrowing -- drove the short
    /// sections' modes near 18-24 kHz to NaN at 144 and 192 kHz (68 of 16,272 cases; examples/v24_stability_sweep.rs;
    /// v24_open_glottis.rs: each from one junction's terms). A jet regains its pressure as it slows and mixes downstream,
    /// over several of its widths, which a 20 kHz swing does not give it time for; and the lumped tube models its band to
    /// about 10 kHz (its sections' error 40 cents at 10-11 kHz). Taken only faster than 48 kHz (`passive_bernoulli()`).
    /// On by default (the owner, 13 November 2026, of the model made passive: "Yes, proceed with A first, particularly
    /// where it works as a more general solution to the blowup problems"); off, 2.4 as it is, as its parity checks run
    /// it. docs/VOCALTRACTLAB_FIXES.md, 8.
    pub passive_bernoulli: bool,
    /// The cutoff (Hz) of the first-order low-pass each section's dynamic pressure is taken through for
    /// passive_bernoulli's exchange.
    pub bernoulli_cutoff_hz: f64,
    pub radiation: Radiation,
    /// How each step's system is solved: 2.4's order (the default, its parity checks), the tube's own, or the reference
    /// in double-double for measurement (src/v24/solve.rs).
    pub solver: Solver,
    /// How finely VocalFork lays the trachea out (v24::passive::Trachea: one element to each of its sections, the
    /// default, or finer), read as its network is laid (`trachea=`: PassiveModel::layout_switches). 2.4's own network
    /// takes no notice of it.
    pub fork_trachea: crate::v24::passive::Trachea,
}

/// The order a step's system is factorized in (research/VOCAL_TRACT_REALTIME_PLAN.md, 1).
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Solver {
    /// 2.4's, every operation as it makes them.
    Envelope,
    /// The tube's own, from the branches' ends inward: the same equations, rounded otherwise; not anyone's default until
    /// the owner has seen it measured.
    Tree,
    /// In double-double, refined: the truth the two are measured against. Some twenty times slower.
    Reference,
}

impl Default for Options {
    fn default() -> Self {
        Options { soft_walls: true, soft_contacts: true, generate_noise_sources: true, radiation_from_skin: true, piriform_fossa: true, inner_length_corrections: false, bound_noise_velocity: true, recover_at_branches: false, passive_bernoulli: true, bernoulli_cutoff_hz: 10000.0, radiation: Radiation::HeadTorso, solver: Solver::Envelope, fork_trachea: crate::v24::passive::Trachea::Sections }
    }
}

#[derive(Clone, Copy, Debug, Default)]
struct NoiseSource {
    is_first_order: bool,
    cutoff_freq: f64,
    target_amp_1khz: f64,
    current_amp_1khz: f64,
    input: [f64; 8],
    output: [f64; 8],
    sample: f64,
    /// Its buffers already zero (it has been off since): not zeroed again.
    silent: bool,
    /// The low-pass last designed, and what for (its order, and its cutoff over the rate, as bits): designed again only
    /// when either changes -- the same function of the same numbers.
    designed_for: Option<(bool, u64)>,
    coeffs: ([f64; 3], [f64; 3], usize),
}

impl NoiseSource {
    fn reset(&mut self) {
        *self = NoiseSource { cutoff_freq: 1.0, silent: true, ..NoiseSource::default() };
    }
}

#[derive(Clone, Copy, Debug)]
struct Constriction {
    first_section: i32,
    last_section: i32,
    narrowest_section: i32,
    obstacle_pos: f64,
    obstacle_section: i32,
    cutoff_freq: f64,
    gain: f64,
    articulator: Articulator,
}

impl Default for Constriction {
    fn default() -> Self {
        Constriction { first_section: -1, last_section: -1, narrowest_section: -1, obstacle_pos: 0.0, obstacle_section: -1, cutoff_freq: 0.0, gain: 0.0, articulator: Articulator::Other }
    }
}

#[derive(Clone, Copy, Debug, Default)]
struct BranchCurrent {
    source_section: i32,
    target_section: i32,
    magnitude: f64,
    magnitude_rate: f64,
    noise_magnitude: f64,
}

#[derive(Clone, Copy, Debug, Default)]
struct TubeSection {
    pos: f64,
    area: f64,
    length: f64,
    volume: f64,
    /// (its wall against its equal-area circle's: carried for the passive core, no part of this model's coefficients)
    shape: f64,
    articulator: Articulator,
    pressure: f64,
    pressure_rate: f64,
    current_in: i32,
    current_out: [i32; 2],
    wall_current: f64,
    wall_current_rate: f64,
    wall_current_rate2: f64,
    l: f64,
    c: f64,
    r: [f64; 2],
    s: f64,
    alpha: f64,
    beta: f64,
    d: f64,
    e: f64,
}

/// Where a constriction's noise is put: a section's dipole source, or the one past the lips.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum NoiseTarget {
    Dipole(usize),
    Lips,
}

/// A constriction as the tube alone places it (TdsModel::constrictions): its narrowest section, its noise's gain before
/// the taper by its area and its cutoff, and the sources it is put into with their shares (None: the whole of it).
#[derive(Clone, Copy, Debug)]
pub struct ConstrictionGeometry {
    pub narrowest: usize,
    pub gain: f64,
    pub cutoff: f64,
    pub targets: [(NoiseTarget, Option<f64>); 2],
    pub num_targets: usize,
}

impl Default for ConstrictionGeometry {
    fn default() -> Self {
        ConstrictionGeometry { narrowest: 0, gain: 0.0, cutoff: 0.0, targets: [(NoiseTarget::Lips, None); 2], num_targets: 0 }
    }
}

/// What a step takes from its tube alone (TdsModel::tube_coefficients), made where the tube is interpolated -- on the
/// acoustics' thread, or ahead on another (src/v24/pipeline.rs): every section's but the glottis's two.
#[derive(Clone, Debug)]
pub struct TubeCoefficients {
    pub area: [f64; NUM_SECTIONS],
    /// Each section's length and volume as the step takes them (the passive core's, src/v24/passive.rs; this model's own
    /// coefficients are made from them).
    pub length: [f64; NUM_SECTIONS],
    pub volume: [f64; NUM_SECTIONS],
    /// Each section's wall against its equal-area circle's (the passive core's boundary layer's, where it is asked
    /// to take it: PassiveModel::own_circumference); 1 where the tube has no shape for it.
    pub shape: [f64; NUM_SECTIONS],
    pub l: [f64; NUM_SECTIONS],
    pub r: [f64; NUM_SECTIONS],
    pub alpha: [f64; NUM_SECTIONS],
    pub e: [f64; NUM_SECTIONS],
    pub wall: [[f64; 3]; NUM_SECTIONS],
    pub fossa_length: f64,
    /// The radiation's resistance and inductance at the mouth and at the nostrils.
    pub radiation: [(f64, f64); 2],
    pub constriction: [ConstrictionGeometry; MAX_CONSTRICTIONS],
    pub num_constrictions: usize,
}

impl Default for TubeCoefficients {
    fn default() -> Self {
        TubeCoefficients {
            area: [0.0; NUM_SECTIONS],
            length: [0.0; NUM_SECTIONS],
            volume: [0.0; NUM_SECTIONS],
            shape: [1.0; NUM_SECTIONS],
            l: [0.0; NUM_SECTIONS],
            r: [0.0; NUM_SECTIONS],
            alpha: [0.0; NUM_SECTIONS],
            e: [0.0; NUM_SECTIONS],
            wall: [[0.0; 3]; NUM_SECTIONS],
            fossa_length: 0.0,
            radiation: [(0.0, 0.0); 2],
            constriction: [ConstrictionGeometry::default(); MAX_CONSTRICTIONS],
            num_constrictions: 0,
        }
    }
}

/// The acoustics' power balance above a cutoff, taken each step while it is asked (`TdsModel::monitor_power`): every
/// section's pressure and flows, and the drops Bernoulli's terms make on them, measured about their own low-pass at the
/// cutoff -- the fluctuations, whose energy a runaway is. The energy they store (each section's compliance's and
/// inertances'), and the work done on them (erg) since it began, by Bernoulli's terms at each section and by the tube's
/// viscous losses, positive where taken from them, negative where given to them: a term that gives, step on step, while
/// the stored energy grows, is the one feeding it. Measurement only: what the model computes is untouched. (The walls,
/// the radiation and the noise sources are not yet in it, nor the energy a moving tube's changing compliance and inertance
/// carry: the balance is not closed, docs/VOCALTRACTLAB_FIXES.md.)
#[derive(Clone, Debug)]
pub struct PowerMonitor {
    pub cutoff_hz: f64,
    /// Each section's pressure, flow in and flow out, and Bernoulli's drops on its flows in and out, low-passed.
    mean: Vec<[f64; 5]>,
    /// This step's Bernoulli resistance on each section's outflow, on its inflow, and its inflow's source, as
    /// prepare_time_step lays them; its resistances before them.
    bernoulli: Vec<[f64; 3]>,
    before: Vec<[f64; 3]>,
    /// The fluctuations' stored energy (erg) as of the last step.
    pub stored: f64,
    /// Work (erg) done on them since the monitor began: by Bernoulli's terms at each section, and by the viscous losses.
    pub bernoulli_absorbed: Vec<f64>,
    pub viscous_absorbed: f64,
}

/// One sample's radiated flows (cm^3/s): at the mouth, at the nostrils, from the skin, and their sum.
#[derive(Clone, Copy, Debug, Default)]
pub struct Radiated {
    pub mouth: f64,
    pub nostrils: f64,
    pub skin: f64,
    pub total: f64,
}

#[derive(Clone)]
pub struct TdsModel {
    pub options: Options,
    flow_source_amp: f64,
    flow_source_section: i32,
    pressure_source_amp: f64,
    pressure_source_section: i32,
    lips_dipole: NoiseSource,
    ts: Vec<TubeSection>,
    /// Each section's noise sources (TubeSection's monopole and dipole in the C++), apart from the sections, which every
    /// step walks through.
    monopole: Vec<NoiseSource>,
    dipole: Vec<NoiseSource>,
    /// The sources sounding after the last step, and those given a target this step, each by its place in the order
    /// 2.4 takes them (a section's monopole 2i, its dipole 2i + 1, the lips' last): only these are taken each step, in
    /// that order -- a source silent and given no target is left as it is, as taking it would leave it.
    awake: Vec<usize>,
    targeted: Vec<usize>,
    take: Vec<usize>,
    bc: Vec<BranchCurrent>,
    /// The system each step's currents are solved from, and its factorization (src/v24/solve.rs).
    system: System,
    cholesky: EnvelopeCholesky,
    tree: TreeCholesky,
    reference: Vec<Dd>,
    /// Every `record_every` steps (0: never), the step's system kept in `recorded`, for measurement (examples/
    /// v24_solve_accuracy.rs): taken by whoever reads it.
    pub record_every: usize,
    pub recorded: Vec<System>,
    pub time_step: f64,
    /// The rate it is stepped at (Hz): 2.4's 48 kHz, or a multiple of it (set_rate); every constant 2.4 ties to its
    /// 48 kHz -- the transglottal pressure's filter, the areas' change limit, the noise's rise and level -- follows it.
    pub rate_hz: f64,
    per_rate: PerRate,
    flow: Vec<f64>,
    /// Each section's dynamic pressure, rho u^2 / 2 a^2 of its mean flow and its area as last stepped, low-passed at
    /// `Options::bernoulli_cutoff_hz` (passive_bernoulli's exchange).
    dynamic: Vec<f64>,
    pub transglottal_pressure_filter: IirFilter,
    /// The power balance, while it is asked for (monitor_power).
    pub monitor: Option<Box<PowerMonitor>>,
    /// The coefficients made here when the tube is set here (`proceed_time_step`); each section's last, kept with the
    /// bits of its area, length and volume and remade only when one changes; how often each.
    own: Box<TubeCoefficients>,
    cache: Vec<([u64; 3], SectionCoefficients)>,
    cache_for: Option<(u64, bool)>,
    pub cache_hits: u64,
    pub cache_misses: u64,
    position: i32,
    teeth_position: f64,
    tongue_tip_side_elevation: f64,
    rng: Mt19937,
}

impl Default for TdsModel {
    fn default() -> Self {
        TdsModel::new()
    }
}

impl TdsModel {
    pub fn new() -> TdsModel {
        let mut m = TdsModel {
            options: Options::default(),
            flow_source_amp: 0.0,
            flow_source_section: -1,
            pressure_source_amp: 0.0,
            pressure_source_section: -1,
            lips_dipole: NoiseSource::default(),
            ts: vec![TubeSection::default(); NUM_SECTIONS],
            monopole: vec![NoiseSource::default(); NUM_SECTIONS],
            dipole: vec![NoiseSource::default(); NUM_SECTIONS],
            awake: Vec::with_capacity(LIPS_SOURCE + 1),
            targeted: Vec::with_capacity(LIPS_SOURCE + 1),
            take: Vec::with_capacity(2 * (LIPS_SOURCE + 1)),
            bc: vec![BranchCurrent::default(); N],
            system: System::new(1, &[false]),
            cholesky: EnvelopeCholesky::new(&System::new(1, &[false])),
            tree: TreeCholesky::new(&System::new(1, &[false])),
            reference: vec![Dd::ZERO; N],
            record_every: 0,
            recorded: Vec::new(),
            time_step: 0.0,
            rate_hz: AUDIO_SAMPLING_RATE_HZ as f64,
            per_rate: PerRate::default(),
            flow: vec![0.0; N],
            dynamic: vec![0.0; NUM_SECTIONS],
            monitor: None,
            transglottal_pressure_filter: IirFilter::default(),
            own: Box::default(),
            cache: vec![([u64::MAX; 3], SectionCoefficients::default()); NUM_SECTIONS],
            cache_for: None,
            cache_hits: 0,
            cache_misses: 0,
            position: 0,
            teeth_position: 0.0,
            tongue_tip_side_elevation: 0.0,
            rng: Mt19937::new(5489),
        };
        let t = Tube::new();
        m.set_tube(&t, false);
        m.init_model();
        m.reset_motion();
        m
    }

    fn init_model(&mut self) {
        self.time_step = 1.0 / self.rate_hz;
        self.flow_source_section = -1;
        self.pressure_source_section = -1;
        for i in 0..NUM_SECTIONS {
            self.bc[i].source_section = i as i32 - 1;
            self.bc[i].target_section = i as i32;
        }
        self.bc[tube::FIRST_TRACHEA_SECTION].source_section = -1;
        self.bc[tube::FIRST_NOSE_SECTION].source_section = tube::LAST_PHARYNX_SECTION as i32;
        self.bc[tube::FIRST_FOSSA_SECTION].source_section = (tube::FIRST_PHARYNX_SECTION + tube::FOSSA_COUPLING_SECTION) as i32;
        for i in 0..tube::NUM_SINUS_SECTIONS {
            self.bc[tube::FIRST_SINUS_SECTION + i].source_section = (tube::FIRST_NOSE_SECTION + tube::SINUS_COUPLING_SECTION[i]) as i32;
        }
        // (Two currents each out of the mouth and the nostrils, into free space: the radiation's resistance and inductance.)
        for (k, from) in [(0, tube::LAST_MOUTH_SECTION), (1, tube::LAST_MOUTH_SECTION), (2, tube::LAST_NOSE_SECTION), (3, tube::LAST_NOSE_SECTION)] {
            self.bc[NUM_SECTIONS + k].source_section = from as i32;
            self.bc[NUM_SECTIONS + k].target_section = -1;
        }
        for ts in self.ts.iter_mut() {
            ts.current_in = -1;
            ts.current_out = [-1, -1];
        }
        for i in 0..N {
            let b = self.bc[i];
            if b.source_section != -1 {
                let ts = &mut self.ts[b.source_section as usize];
                if ts.current_out[0] == -1 {
                    ts.current_out[0] = i as i32;
                } else {
                    ts.current_out[1] = i as i32;
                }
            }
            if b.target_section != -1 {
                self.ts[b.target_section as usize].current_in = i as i32;
            }
        }
        // The matrix's pattern: two currents coupled where they share a section.
        let mut pattern = vec![false; N * N];
        for i in 0..N {
            let b = self.bc[i];
            for sec in [b.source_section, b.target_section] {
                if sec != -1 {
                    let ts = &self.ts[sec as usize];
                    for c in [ts.current_in, ts.current_out[0], ts.current_out[1]] {
                        if c != -1 {
                            pattern[i * N + c as usize] = true;
                        }
                    }
                }
            }
        }
        // (The C++ keeps at most MAX_ENVELOPE_COLUMNS of a row's envelope and MAX_ENVELOPE_ROWS of a column's; 2.4's
        // tube reaches neither -- its longest row, the fossae's first, 65 columns; its fullest column 9 rows -- and each
        // is whole.)
        let first: Vec<usize> = (0..N).map(|i| (0..i).find(|&j| pattern[i * N + j]).unwrap_or(i)).collect();
        for i in 0..N {
            assert!(i - first[i] <= MAX_ENVELOPE_COLUMNS, "a row's envelope past the C++'s bound");
            assert!((i + 1..N).filter(|&r| first[r] <= i).count() <= MAX_ENVELOPE_ROWS, "a column's envelope past the C++'s bound");
        }
        self.system = System::new(N, &pattern);
        self.cholesky = EnvelopeCholesky::new(&self.system);
        self.tree = TreeCholesky::new(&self.system);
    }

    /// Every flow, pressure and source at rest, the noise's generator seeded again (with 10, as the C++).
    pub fn reset_motion(&mut self) {
        self.rng.seed(10);
        for ts in self.ts.iter_mut() {
            ts.pressure = 0.0;
            ts.pressure_rate = 0.0;
            ts.wall_current = 0.0;
            ts.wall_current_rate = 0.0;
            ts.wall_current_rate2 = 0.0;
            ts.l = 0.0;
            ts.c = 0.0;
            ts.r = [0.0, 0.0];
            ts.s = 0.0;
            ts.alpha = 0.0;
            ts.beta = 0.0;
            ts.d = 0.0;
            ts.e = 0.0;
        }
        self.monopole.iter_mut().chain(self.dipole.iter_mut()).for_each(NoiseSource::reset);
        self.lips_dipole.reset();
        self.awake.clear();
        self.targeted.clear();
        for b in self.bc.iter_mut() {
            b.magnitude = 0.0;
            b.magnitude_rate = 0.0;
            b.noise_magnitude = 0.0;
        }
        self.flow_source_amp = 0.0;
        self.pressure_source_amp = 0.0;
        self.position = 0;
        self.flow.iter_mut().for_each(|x| *x = 0.0);
        self.dynamic.iter_mut().for_each(|x| *x = 0.0);
        self.per_rate = PerRate::new(self.rate_hz, self.time_step);
        self.transglottal_pressure_filter.create_chebyshev(50.0 / self.rate_hz, false, 4);
        self.transglottal_pressure_filter.reset_buffers(0.0);
    }

    /// Stepped at `rate_hz` from here on (its motion reset): 2.4's 48 kHz, or a multiple of it to keep its glottis's
    /// flow from aliasing (docs/VOCAL_TRACT.md, "What the high band holds").
    pub fn set_rate(&mut self, rate_hz: f64) {
        self.rate_hz = rate_hz;
        self.time_step = 1.0 / rate_hz;
        self.reset_motion();
    }

    /// The system the last step solved (its matrix and right-hand side), for measurement.
    pub fn system(&self) -> &System {
        &self.system
    }

    pub fn sample_index(&self) -> i32 {
        self.position
    }

    /// The tube's sections taken; with `filtering` and soft contacts, a pharynx, mouth or nose section's area moves at
    /// most 400 cm^2/s, and near zero no faster than a quartic curve allows (its closing slower than its opening).
    pub fn set_tube(&mut self, tube: &Tube, filtering: bool) {
        const CLOSING_CURVE_FACTOR: f64 = 40e6;
        const OPENING_CURVE_FACTOR: f64 = 480e6;
        const MAX_AREA_CHANGE_RATE_CM2_S: f64 = 400.0;
        let constant_limit = MAX_AREA_CHANGE_RATE_CM2_S / self.rate_hz;
        for i in 0..NUM_SECTIONS {
            let source = &tube.section[i];
            let soft = self.options.soft_contacts
                && filtering
                && ((i >= tube::FIRST_PHARYNX_SECTION && i <= tube::LAST_MOUTH_SECTION) || (i >= tube::FIRST_NOSE_SECTION && i <= tube::LAST_NOSE_SECTION));
            let target = &mut self.ts[i];
            if soft {
                let old = target.area;
                let mut new = source.area_cm2;
                let mut delta = new - old;
                if delta > constant_limit {
                    delta = constant_limit;
                }
                if delta < -constant_limit {
                    delta = -constant_limit;
                }
                let curve = if new > old { OPENING_CURVE_FACTOR } else { CLOSING_CURVE_FACTOR };
                let t = (old / curve).sqrt().sqrt() + self.time_step;
                let limit = curve * t * t * t * t - old;
                if delta > limit {
                    delta = limit;
                }
                if delta < -limit {
                    delta = -limit;
                }
                new = old + delta;
                target.pos = source.pos_cm;
                target.area = new;
                target.length = source.length_cm;
                target.volume = source.length_cm * new;
            } else {
                target.pos = source.pos_cm;
                target.area = source.area_cm2;
                target.length = source.length_cm;
                target.volume = source.volume_cm3;
            }
            target.articulator = source.articulator;
            target.shape = source.shape;
        }
        let (_, teeth, tts) = tube.aux_params();
        self.teeth_position = teeth;
        self.tongue_tip_side_elevation = tts;
    }

    pub fn set_flow_source(&mut self, flow_cm3_s: f64, section: i32) {
        self.flow_source_section = section;
        self.flow_source_amp = flow_cm3_s;
    }

    pub fn set_pressure_source(&mut self, pressure_dpa: f64, section: i32) {
        self.pressure_source_section = section;
        self.pressure_source_amp = pressure_dpa;
    }

    /// The flow out of section i at the last step (cm^3/s), for measurement.
    pub fn section_flow_out(&self, i: usize) -> f64 {
        self.current_out(i)
    }

    pub fn section_pressure(&self, i: usize) -> f64 {
        if i >= NUM_SECTIONS {
            0.0
        } else {
            self.ts[i].pressure
        }
    }

    fn current_in(&self, i: usize) -> f64 {
        let mut flow = 0.0;
        if i < NUM_SECTIONS && self.ts[i].current_in != -1 {
            flow += self.bc[self.ts[i].current_in as usize].magnitude;
        }
        flow
    }

    /// Whether Bernoulli's terms are taken passively (Options::passive_bernoulli): where they are asked so and the
    /// acoustics are stepped faster than 2.4's 48 kHz -- there each section's own modes are resolved, which 2.4's terms
    /// could feed. At 48 kHz itself, 2.4's own form, its coarse step damping them (none of the sweep's runaways was
    /// there); the exchange, taken from the step before, would not be stable at that step.
    fn passive_bernoulli(&self) -> bool {
        self.options.passive_bernoulli && self.rate_hz > 1.5 * AUDIO_SAMPLING_RATE_HZ as f64
    }

    fn current_out(&self, i: usize) -> f64 {
        let mut flow = 0.0;
        if i < NUM_SECTIONS {
            let ts = &self.ts[i];
            if ts.current_out[0] != -1 {
                flow += self.bc[ts.current_out[0] as usize].magnitude;
            }
            if ts.current_out[1] != -1 {
                flow += self.bc[ts.current_out[1] as usize].magnitude;
            }
        }
        flow
    }

    /// The power balance taken from the next step on, about a low-pass at `cutoff_hz` (PowerMonitor); begun again if it was
    /// being taken.
    pub fn monitor_power(&mut self, cutoff_hz: f64) {
        self.monitor = Some(Box::new(PowerMonitor {
            cutoff_hz,
            mean: vec![[0.0; 5]; NUM_SECTIONS],
            bernoulli: vec![[0.0; 3]; NUM_SECTIONS],
            before: vec![[0.0; 3]; NUM_SECTIONS],
            stored: 0.0,
            bernoulli_absorbed: vec![0.0; NUM_SECTIONS],
            viscous_absorbed: 0.0,
        }));
    }

    /// The step's power balance (PowerMonitor), from its flows and pressures as solved and the Bernoulli terms and
    /// resistances it was solved with: each section's outflow (the whole, through its outlet's half: its resistance r[1])
    /// and inflow (through the inlet's half of the branch into it: r[0], and the source s), each drop along its flow.
    fn measure_power(&mut self) {
        let mut m = self.monitor.take().unwrap();
        let dt = self.time_step;
        let a = (-2.0 * PI * m.cutoff_hz * dt).exp();
        let compliance_per_volume = 1.0 / (AMBIENT_DENSITY_CGS * SOUND_VELOCITY_CGS * SOUND_VELOCITY_CGS);
        let mut stored = 0.0;
        for i in 0..NUM_SECTIONS {
            let ts = &self.ts[i];
            let (u_out, u_in) = (self.current_out(i), self.current_in(i));
            let b = m.bernoulli[i];
            let (drop_out, drop_in) = (b[0] * u_out, b[1] * u_in + b[2]);
            let now = [ts.pressure, u_in, u_out, drop_in, drop_out];
            let mean = &mut m.mean[i];
            let mut x = [0.0; 5];
            for k in 0..5 {
                mean[k] = (1.0 - a) * now[k] + a * mean[k];
                x[k] = now[k] - mean[k];
            }
            let [p, u_in, u_out, drop_in, drop_out] = x;
            stored += 0.5 * ts.volume * compliance_per_volume * p * p + 0.5 * ts.l * (u_in * u_in + u_out * u_out);
            m.bernoulli_absorbed[i] += dt * (drop_out * u_out + drop_in * u_in);
            m.viscous_absorbed += dt * ((ts.r[1] - b[0]) * u_out * u_out + (ts.r[0] - b[1]) * u_in * u_in);
        }
        m.stored = stored;
        self.monitor = Some(m);
    }

    /// For an acoustic model of another kind (src/v24/passive.rs), which takes its noise from this one: the flows of a
    /// step it made, branch current by branch current as this model's own would be, smoothed as the noise takes them
    /// (update_variables), the step counted.
    pub fn take_flows(&mut self, flows: &[f64]) {
        let c = self.per_rate.noise_filter_coeff;
        for (b, &u) in self.bc.iter_mut().zip(flows) {
            b.magnitude = u;
            b.noise_magnitude = (1.0 - c) * u + c * b.noise_magnitude;
        }
        self.position = self.position.wrapping_add(1);
    }

    /// Its noise sources stepped from the flows taken, as prepare_time_step steps them (calc_noise_sources), the tube's
    /// areas laid from `k` and the glottis's sections as set: then each section's monopole and dipole, and the lips'
    /// dipole, as they sound (noise_source).
    pub fn step_noise(&mut self, k: &TubeCoefficients) {
        for i in 0..NUM_SECTIONS {
            if i != tube::LOWER_GLOTTIS_SECTION && i != tube::UPPER_GLOTTIS_SECTION {
                self.ts[i].area = k.area[i];
            }
        }
        if self.options.generate_noise_sources {
            self.calc_noise_sources(k);
        }
    }

    /// A section's monopole (a flow, cm^3/s) and dipole (a pressure, dPa) as last stepped; the lips' dipole for
    /// `NUM_SECTIONS`.
    pub fn noise_source(&self, i: usize) -> (f64, f64) {
        if i == NUM_SECTIONS {
            (0.0, self.lips_dipole.sample)
        } else {
            (self.monopole[i].sample, self.dipole[i].sample)
        }
    }

    /// The glottis's two sections as the glottis lays them each step (Tube::set_glottis_sections, then set_tube's copy):
    /// for a step whose other sections' coefficients were made ahead (`proceed_time_step_with`).
    pub fn set_glottis_sections(&mut self, lengths_cm: &[f64; 2], areas_cm2: &[f64; 2]) {
        for k in 0..2 {
            let ts = &mut self.ts[tube::LOWER_GLOTTIS_SECTION + k];
            ts.length = lengths_cm[k];
            ts.area = areas_cm2[k];
            if ts.area < tube::MIN_AREA_CM2 {
                ts.area = tube::MIN_AREA_CM2;
            }
            ts.volume = ts.area * ts.length;
            ts.articulator = Articulator::VocalFolds;
        }
    }

    /// One sample: the network prepared, built, solved and advanced -> the flows radiated.
    pub fn proceed_time_step(&mut self) -> Radiated {
        let mut k = std::mem::take(&mut self.own);
        self.tube_coefficients(&mut k);
        let radiated = self.proceed_time_step_with(&k);
        self.own = k;
        radiated
    }

    /// One sample from its tube's coefficients made already (by `tube_coefficients`, here or on another thread), the
    /// glottis's two sections set (`set_glottis_sections`): its system prepared, built, solved and advanced.
    pub fn proceed_time_step_with(&mut self, k: &TubeCoefficients) -> Radiated {
        self.prepare_time_step(k);
        self.calc_matrix(&k.radiation);
        if self.record_every > 0 && (self.position as u32 as usize) % self.record_every == 0 {
            self.recorded.push(self.system.clone());
        }
        self.solve_cholesky();
        self.update_variables();
        if self.monitor.is_some() {
            self.measure_power();
        }
        let mut mouth = 0.0;
        let ts = &self.ts[tube::LAST_MOUTH_SECTION];
        if ts.current_out[0] != -1 {
            mouth += self.bc[ts.current_out[0] as usize].magnitude;
        }
        if ts.current_out[1] != -1 {
            mouth += self.bc[ts.current_out[1] as usize].magnitude;
        }
        let mut nostrils = 0.0;
        let ts = &self.ts[tube::LAST_NOSE_SECTION];
        if ts.current_out[0] != -1 {
            nostrils += self.bc[ts.current_out[0] as usize].magnitude;
        }
        if ts.current_out[1] != -1 {
            nostrils += self.bc[ts.current_out[1] as usize].magnitude;
        }
        let mut skin = 0.0;
        if self.options.radiation_from_skin {
            for i in 0..tube::NUM_PHARYNX_MOUTH_SECTIONS {
                skin += self.ts[tube::FIRST_PHARYNX_SECTION + i].wall_current;
            }
            for i in 0..tube::NUM_NOSE_SECTIONS {
                skin += self.ts[tube::FIRST_NOSE_SECTION + i].wall_current;
            }
        }
        self.position = self.position.wrapping_add(1);
        Radiated { mouth, nostrils, skin, total: mouth + nostrils + skin }
    }

    /// What a step takes from its tube alone, every section's but the glottis's two (which follow the glottis each step):
    /// its area held above its floor, its inertance, compliance, losses, walls' terms and `e`; the radiation's resistance
    /// and inductance; and its constrictions' geometry -- where they are, the gain and cutoff of their noise, the sources
    /// it is put into. A section whose area, length and volume are those of the last step, bit for bit, keeps its
    /// coefficients (the trachea, the fossae, the sinuses and the nose past the velic port's four, which never move, and
    /// the tube between frames that hold it still): the same function of the same numbers, made once.
    pub fn tube_coefficients(&mut self, k: &mut TubeCoefficients) {
        let (dt, soft_walls) = (self.time_step, self.options.soft_walls);
        if self.cache_for != Some((dt.to_bits(), soft_walls)) {
            self.cache.iter_mut().for_each(|c| c.0 = [u64::MAX; 3]);
            self.cache_for = Some((dt.to_bits(), soft_walls));
        }
        for i in 0..NUM_SECTIONS {
            if i == tube::LOWER_GLOTTIS_SECTION || i == tube::UPPER_GLOTTIS_SECTION {
                continue;
            }
            let ts = &mut self.ts[i];
            if ts.area < MIN_AREA_CM2 {
                ts.area = MIN_AREA_CM2;
            }
            let key = [ts.area.to_bits(), ts.length.to_bits(), ts.volume.to_bits()];
            let cached = &mut self.cache[i];
            if cached.0 != key {
                cached.1 = section_coefficients(i, ts.area, ts.length, ts.volume, dt, soft_walls);
                cached.0 = key;
                self.cache_misses += 1;
            } else {
                self.cache_hits += 1;
            }
            let c = &cached.1;
            k.area[i] = ts.area;
            k.length[i] = ts.length;
            k.volume[i] = ts.volume;
            k.shape[i] = ts.shape;
            k.l[i] = c.l;
            k.r[i] = c.r;
            k.alpha[i] = c.alpha;
            k.e[i] = c.e;
            k.wall[i] = c.wall;
        }
        k.fossa_length = self.ts[tube::FIRST_FOSSA_SECTION].length;
        k.radiation = [radiation(self.ts[tube::LAST_MOUTH_SECTION].area), radiation(self.ts[tube::LAST_NOSE_SECTION].area)];
        k.num_constrictions = 0;
        if self.options.generate_noise_sources {
            self.constrictions(k);
        }
    }

    fn prepare_time_step(&mut self, k: &TubeCoefficients) {
        let dt = self.time_step;
        let soft_walls = self.options.soft_walls;
        for i in 0..NUM_SECTIONS {
            let ts = &mut self.ts[i];
            if i == tube::LOWER_GLOTTIS_SECTION || i == tube::UPPER_GLOTTIS_SECTION {
                if ts.area < MIN_AREA_CM2 {
                    ts.area = MIN_AREA_CM2;
                }
                let c = section_coefficients(i, ts.area, ts.length, ts.volume, dt, soft_walls);
                ts.l = c.l;
                ts.r = [c.r, c.r];
                ts.alpha = c.alpha;
                ts.e = c.e;
                ts.beta = 0.0;
                continue;
            }
            ts.area = k.area[i];
            ts.l = k.l[i];
            ts.r = [k.r[i], k.r[i]];
            ts.alpha = k.alpha[i];
            ts.e = k.e[i];
            ts.beta = 0.0;
            if soft_walls {
                let w = &k.wall[i];
                ts.beta = ts.alpha * (ts.wall_current * w[0] + ts.wall_current_rate * w[1] + ts.wall_current_rate2 * w[2] * (THETA1 / THETA));
            }
        }
        // Bernoulli's terms at each junction, the pressure recovered past a widening a fifth at the glottis, half
        // elsewhere; passive_bernoulli's sources in each branch's own `s`, nothing else putting one there.
        let passive = self.passive_bernoulli();
        if passive {
            self.ts.iter_mut().for_each(|ts| ts.s = 0.0);
        }
        if let Some(m) = self.monitor.as_mut() {
            for (b, ts) in m.before.iter_mut().zip(&self.ts) {
                *b = [ts.r[1], ts.r[0], ts.s];
            }
        }
        for i in 0..NUM_SECTIONS {
            if (i < tube::LAST_MOUTH_SECTION) || (i >= tube::FIRST_NOSE_SECTION && i < tube::LAST_NOSE_SECTION) || (i >= tube::FIRST_FOSSA_SECTION && i < tube::LAST_FOSSA_SECTION) {
                let a1 = self.ts[i].area;
                let u1 = self.current_out(i);
                let a2 = self.ts[i + 1].area;
                let u2 = self.current_in(i + 1);
                let mut a3 = MIN_AREA_CM2;
                let mut u3 = 0.0;
                let mut branch: i32 = -1;
                if self.ts[i].current_out[1] != -1 {
                    branch = self.bc[self.ts[i].current_out[1] as usize].target_section;
                    a3 = self.ts[branch as usize].area;
                    u3 = self.current_in(branch as usize);
                }
                let mut k = 1.0;
                let widening = (a1 > a2 && u1 < 0.0) || (a1 < a2 && u1 > 0.0);
                if branch == -1 && widening {
                    k = if i == tube::LOWER_GLOTTIS_SECTION || i == tube::UPPER_GLOTTIS_SECTION { GLOTTIS_RECOVERY_COEFF } else { TRACT_RECOVERY_COEFF };
                }
                // (recover_at_branches: at a junction with a side branch, where 2.4 recovers the whole, a sudden widening
                // recovers as Borda and Carnot's law has it, 2r / (1 + r) of the Bernoulli pressure for the ratio r of the
                // narrower area to the wider: the whole where the two meet, and less the sharper the widening -- so that
                // nothing steps where the areas cross, the upstream half's term being in both branches' equations
                // (calc_matrix): 2.4's half there, switched on as the pharynx narrowed to the epilarynx's area in
                // "sehr", stepped the fossa's branch: a click, render/synthesis/tools/audit_renders.py.)
                if branch != -1 && self.options.recover_at_branches && widening {
                    let r = a1.min(a2) / a1.max(a2);
                    k = 2.0 * r / (1.0 + r);
                }
                if passive {
                    // (passive_bernoulli: 2.4's pair k (q_t - q_i) -- the dynamic pressures, rho u^2 / 2 a^2, of the
                    // section the flow enters and of the one it leaves -- as its two parts. The lossless exchange, q_t -
                    // q_i, which telescopes along the tube (each section's q in the branch into it and, less, in each out
                    // of it): from each section's own q low-passed, a source in each branch the junction feeds (`s`, as
                    // a resistance's drop is), so that a section's compression at its own frequencies -- its inflow less
                    // its outflow, against which q exchanges power -- is not pumped by q's own swing there. And the jet's
                    // loss past a widening, (1 - k)(q_i - q_t): a resistance on the flow as it is, as 2.4 has it, and
                    // positive where it is any -- the glottis's own drop, four fifths of it, among them.)
                    let q1 = self.dynamic[i];
                    self.ts[i + 1].s += self.dynamic[i + 1] - q1;
                    if branch != -1 {
                        self.ts[branch as usize].s += self.dynamic[branch as usize] - q1;
                    }
                    let loss = 1.0 - k;
                    if loss > 0.0 {
                        self.ts[i].r[1] += loss * 0.5 * u1 * AMBIENT_DENSITY_CGS / (a1 * a1);
                        self.ts[i + 1].r[0] -= loss * 0.5 * u2 * AMBIENT_DENSITY_CGS / (a2 * a2);
                        if branch != -1 {
                            self.ts[branch as usize].r[0] -= loss * 0.5 * u3 * AMBIENT_DENSITY_CGS / (a3 * a3);
                        }
                    }
                    continue;
                }
                self.ts[i].r[1] -= k * 0.5 * u1 * AMBIENT_DENSITY_CGS / (a1 * a1);
                self.ts[i + 1].r[0] += k * 0.5 * u2 * AMBIENT_DENSITY_CGS / (a2 * a2);
                if branch != -1 {
                    self.ts[branch as usize].r[0] += k * 0.5 * u3 * AMBIENT_DENSITY_CGS / (a3 * a3);
                }
            }
        }
        if let Some(m) = self.monitor.as_mut() {
            for ((b, before), ts) in m.bernoulli.iter_mut().zip(&m.before).zip(&self.ts) {
                *b = [ts.r[1] - before[0], ts.r[0] - before[1], ts.s - before[2]];
            }
        }
        if !self.options.piriform_fossa {
            self.ts[tube::FIRST_FOSSA_SECTION].r[0] = 8.0 * AIR_VISCOSITY_CGS * k.fossa_length * PI / (MIN_AREA_CM2 * MIN_AREA_CM2);
        }
        if self.options.generate_noise_sources {
            self.calc_noise_sources(k);
        }
        for i in 0..NUM_SECTIONS {
            let ts = &mut self.ts[i];
            let mut source_amp = self.monopole[i].sample;
            if i as i32 == self.flow_source_section {
                source_amp += self.flow_source_amp;
            }
            ts.d = ts.pressure + dt * THETA1 * ts.pressure_rate - ts.e * (ts.beta - source_amp);
        }
    }

    // A constriction grown from its narrowest section while its sections are within MAX_DELTA_AREA of it and of its
    // articulator, then trimmed by one at each end.
    fn grow(&self, c: &mut Constriction, max_area: f64, art: Articulator, first: usize, last: usize) {
        while self.ts[c.first_section as usize].area < max_area && self.ts[c.first_section as usize].articulator == art && c.first_section > first as i32 {
            c.first_section -= 1;
        }
        while self.ts[c.last_section as usize].area < max_area && self.ts[c.last_section as usize].articulator == art && c.last_section < last as i32 {
            c.last_section += 1;
        }
    }

    // The constrictions of the tube as it stands (calcNoiseSources' part that depends on the tube alone): the glottis,
    // always; the velic port, always; the tongue's narrowest place under 1 cm^2 and a second apart from it; the lips,
    // where narrower than a tongue constriction at the teeth. Each its narrowest section, its noise's gain (before the
    // taper by its area, which for the glottis's moves each step) and cutoff, and the sources at its obstacle its noise is
    // put into, with their shares.
    fn constrictions(&self, k: &mut TubeCoefficients) {
        const MAX_TEETH_DISTANCE: f64 = 2.5;
        let mut found = [Constriction::default(); MAX_CONSTRICTIONS];
        let mut count = 0;
        // The glottis, always.
        let mut c = Constriction { first_section: tube::LOWER_GLOTTIS_SECTION as i32, last_section: tube::UPPER_GLOTTIS_SECTION as i32, narrowest_section: tube::UPPER_GLOTTIS_SECTION as i32, obstacle_pos: 1.5, articulator: Articulator::VocalFolds, ..Constriction::default() };
        found[count] = c;
        count += 1;
        // The velic port, always (2.4: its noise as a closure there is released).
        c = Constriction { first_section: tube::FIRST_NOSE_SECTION as i32, last_section: tube::FIRST_NOSE_SECTION as i32, narrowest_section: tube::FIRST_NOSE_SECTION as i32, obstacle_pos: self.ts[tube::FIRST_NOSE_SECTION].pos + 1.5, articulator: Articulator::Other, ..Constriction::default() };
        found[count] = c;
        count += 1;
        // The tongue's narrowest place under 1 cm^2.
        let mut min_tongue_area_for_teeth = 1000000.0;
        let mut min_tongue_area = 1000000.0;
        let mut min_tongue_section: i32 = -1;
        for i in tube::FIRST_PHARYNX_SECTION..=tube::LAST_MOUTH_SECTION {
            if self.ts[i].articulator == Articulator::Tongue && self.ts[i].area < min_tongue_area {
                min_tongue_area = self.ts[i].area;
                min_tongue_section = i as i32;
            }
        }
        if min_tongue_area < MAX_CONSTRICTION_AREA {
            let mut c = Constriction { first_section: min_tongue_section, last_section: min_tongue_section, narrowest_section: min_tongue_section, articulator: Articulator::Tongue, ..Constriction::default() };
            self.grow(&mut c, min_tongue_area + MAX_DELTA_AREA, Articulator::Tongue, tube::FIRST_PHARYNX_SECTION, tube::LAST_MOUTH_SECTION);
            c.first_section += 1;
            c.last_section -= 1;
            let last = &self.ts[c.last_section as usize];
            let jet_pos = last.pos + last.length;
            if self.teeth_position - jet_pos < MAX_TEETH_DISTANCE {
                c.obstacle_pos = self.teeth_position;
                min_tongue_area_for_teeth = self.ts[c.narrowest_section as usize].area;
            } else {
                let next = &self.ts[c.last_section as usize + 1];
                c.obstacle_pos = next.pos + 0.5 * next.length;
            }
            found[count] = c;
            count += 1;
        }
        // A second tongue constriction, apart from the first.
        if count > 0 && found[count - 1].articulator == Articulator::Tongue {
            let prev = found[count - 1];
            min_tongue_area = 1000000.0;
            min_tongue_section = -1;
            for i in tube::FIRST_PHARYNX_SECTION..=tube::LAST_MOUTH_SECTION {
                if self.ts[i].articulator == Articulator::Tongue && self.ts[i].area < min_tongue_area && ((i as i32) < prev.first_section || (i as i32) > prev.last_section) {
                    min_tongue_area = self.ts[i].area;
                    min_tongue_section = i as i32;
                }
            }
            if min_tongue_area < MAX_CONSTRICTION_AREA {
                let mut c = Constriction { narrowest_section: min_tongue_section, first_section: min_tongue_section, last_section: min_tongue_section, articulator: Articulator::Tongue, ..Constriction::default() };
                self.grow(&mut c, min_tongue_area + MAX_DELTA_AREA, Articulator::Tongue, tube::FIRST_PHARYNX_SECTION, tube::LAST_MOUTH_SECTION);
                c.first_section += 1;
                c.last_section -= 1;
                if c.first_section > prev.last_section + 1 || c.last_section < prev.first_section - 1 {
                    let last = &self.ts[c.last_section as usize];
                    let jet_pos = last.pos + last.length;
                    if self.teeth_position - jet_pos < MAX_TEETH_DISTANCE {
                        c.obstacle_pos = self.teeth_position;
                        min_tongue_area_for_teeth = self.ts[c.narrowest_section as usize].area;
                    } else {
                        let next = &self.ts[c.last_section as usize + 1];
                        c.obstacle_pos = next.pos + 0.5 * next.length;
                    }
                    found[count] = c;
                    count += 1;
                }
            }
        }
        // The lips, where narrower than a tongue constriction at the teeth.
        let mut min_lip_area = 1000000.0;
        let mut min_lip_section: i32 = -1;
        for i in tube::FIRST_MOUTH_SECTION..=tube::LAST_MOUTH_SECTION {
            if self.ts[i].articulator == Articulator::LowerLip && self.ts[i].area < min_lip_area {
                min_lip_area = self.ts[i].area;
                min_lip_section = i as i32;
            }
        }
        if min_lip_area < MAX_CONSTRICTION_AREA && min_lip_area < min_tongue_area_for_teeth {
            let mut c = Constriction { first_section: min_lip_section, last_section: min_lip_section, narrowest_section: min_lip_section, articulator: Articulator::LowerLip, ..Constriction::default() };
            let max_area = min_lip_area + MAX_DELTA_AREA;
            self.grow(&mut c, max_area, Articulator::LowerLip, tube::FIRST_MOUTH_SECTION, tube::LAST_MOUTH_SECTION);
            c.first_section += 1;
            if self.ts[c.last_section as usize].area >= max_area {
                c.last_section -= 1;
            }
            let (f, l) = (&self.ts[c.first_section as usize], &self.ts[c.last_section as usize]);
            c.obstacle_pos = 0.5 * (f.pos + l.pos + l.length);
            found[count] = c;
            count += 1;
        }
        // Each constriction's gain and cutoff, and the sources at its obstacle.
        for (n, mut c) in found[..count].iter().copied().enumerate() {
            c.cutoff_freq = 1000.0;
            c.gain = 0.0;
            if c.articulator == Articulator::LowerLip {
                // (A labiodental fricative where the teeth are near closed; a bilabial plosive's burst where not.)
                let (gain_f, cutoff_f, gain_p, cutoff_p) = (0.7e-6, 8000.0, 0.2e-6, 500.0);
                let mut area_at_teeth = 1000000.0;
                for i in tube::FIRST_MOUTH_SECTION..=tube::LAST_MOUTH_SECTION {
                    if self.teeth_position >= self.ts[i].pos && self.teeth_position <= self.ts[i].pos + self.ts[i].length {
                        area_at_teeth = self.ts[i].area;
                    }
                }
                const CRITICAL_CONSTRICTION_AREA_CM2: f64 = 0.15;
                let mut d = (-(area_at_teeth - CRITICAL_CONSTRICTION_AREA_CM2) / 0.10).exp();
                if d > 1.0 {
                    d = 1.0;
                }
                c.gain = d * gain_f + (1.0 - d) * gain_p;
                c.cutoff_freq = d * cutoff_f + (1.0 - d) * cutoff_p;
            } else if c.articulator == Articulator::VocalFolds {
                c.gain = 0.2e-6;
                c.cutoff_freq = 1000.0;
            } else if c.first_section == tube::FIRST_NOSE_SECTION as i32 {
                c.gain = 0.3e-6;
                c.cutoff_freq = 500.0;
            } else if (c.obstacle_pos - self.teeth_position).abs() < 0.0001 {
                // (Against the teeth: a fricative's noise where the tongue's sides are raised, a plosive's where not,
                // weaker the farther the jet from the teeth.)
                let last = &self.ts[c.last_section as usize];
                let jet_pos = last.pos + last.length;
                let distance = (c.obstacle_pos - jet_pos).abs();
                const REF_DISTANCE_CM: f64 = 3.0;
                let gain_fricatives = 1.0e-6 * (-distance / REF_DISTANCE_CM).exp();
                let cutoff_fricatives = 6000.0 * (-distance / REF_DISTANCE_CM).exp();
                let gain_plosives = 0.6e-6 * (-distance / REF_DISTANCE_CM).exp();
                let cutoff_plosives = 1500.0 * (-distance / REF_DISTANCE_CM).exp();
                let mut d = self.tongue_tip_side_elevation;
                if d < 0.0 {
                    d = 0.0;
                }
                if d > 1.0 {
                    d = 1.0;
                }
                c.gain = d * gain_fricatives + (1.0 - d) * gain_plosives;
                c.cutoff_freq = d * cutoff_fricatives + (1.0 - d) * cutoff_plosives;
                if self.tongue_tip_side_elevation < 0.0 {
                    const REF_ELEVATION: f64 = -0.2;
                    let mut factor = (self.tongue_tip_side_elevation - REF_ELEVATION) / -REF_ELEVATION;
                    if factor < 0.0 {
                        factor = 0.0;
                    }
                    if factor > 1.0 {
                        factor = 1.0;
                    }
                    c.gain *= factor;
                }
            } else {
                c.gain = 0.5e-6;
                c.cutoff_freq = 1500.0;
            }
            if c.cutoff_freq > 10000.0 {
                c.cutoff_freq = 10000.0;
            }
            if c.cutoff_freq < 1.0 {
                c.cutoff_freq = 1.0;
            }
            let g = &mut k.constriction[n];
            *g = ConstrictionGeometry { narrowest: c.narrowest_section as usize, gain: c.gain, cutoff: c.cutoff_freq, targets: [(NoiseTarget::Lips, None); 2], num_targets: 0 };
            if c.first_section == tube::FIRST_NOSE_SECTION as i32 {
                g.targets[0] = (NoiseTarget::Dipole(tube::FIRST_NOSE_SECTION + 1), None);
                g.num_targets = 1;
            } else {
                let lm = &self.ts[tube::LAST_MOUTH_SECTION];
                if c.obstacle_pos >= lm.pos + lm.length {
                    c.obstacle_pos = lm.pos + 0.99 * lm.length;
                }
                c.obstacle_section = -1;
                let mut i = tube::FIRST_PHARYNX_SECTION;
                while i <= tube::LAST_MOUTH_SECTION && c.obstacle_section == -1 {
                    if self.ts[i].pos <= c.obstacle_pos && self.ts[i].pos + self.ts[i].length >= c.obstacle_pos {
                        c.obstacle_section = i as i32;
                    }
                    i += 1;
                }
                if c.obstacle_section != -1 {
                    let os = c.obstacle_section as usize;
                    let downstream_factor = (c.obstacle_pos - self.ts[os].pos) / self.ts[os].length;
                    let upstream_factor = 1.0 - downstream_factor;
                    g.targets[0] = (NoiseTarget::Dipole(os), Some(upstream_factor));
                    g.targets[1] = (if os < tube::LAST_MOUTH_SECTION { NoiseTarget::Dipole(os + 1) } else { NoiseTarget::Lips }, Some(downstream_factor));
                    g.num_targets = 2;
                }
            }
        }
        k.num_constrictions = count;
    }

    // Each constriction's flow and speed, its noise's amplitude by its gain (tapered by its area), and its noise put into
    // the sources at its obstacle (calcNoiseSources' part that follows the flows); then every source's next sample.
    fn calc_noise_sources(&mut self, k: &TubeCoefficients) {
        // (Every target zero but where one is given now: those given last step made zero.)
        for &id in &self.targeted {
            match id {
                LIPS_SOURCE => self.lips_dipole.target_amp_1khz = 0.0,
                _ if id % 2 == 1 => self.dipole[id / 2].target_amp_1khz = 0.0,
                _ => self.monopole[id / 2].target_amp_1khz = 0.0,
            }
        }
        self.targeted.clear();
        for g in &k.constriction[..k.num_constrictions] {
            let ts = &self.ts[g.narrowest];
            let mut area = ts.area;
            if area < MIN_AREA_CM2 {
                area = MIN_AREA_CM2;
            }
            let mut flow = 0.0;
            if ts.current_out[0] != -1 {
                flow += self.bc[ts.current_out[0] as usize].noise_magnitude;
            }
            if ts.current_out[1] != -1 {
                flow += self.bc[ts.current_out[1] as usize].noise_magnitude;
            }
            if flow < 0.0 {
                flow = 0.0;
            }
            let mut velocity = flow / area;
            if self.options.bound_noise_velocity && velocity > SOUND_VELOCITY_CGS {
                velocity = SOUND_VELOCITY_CGS;
            }
            let mut gain = g.gain;
            const TAPER_START_AREA: f64 = 0.5;
            if area >= TAPER_START_AREA {
                let d = (area - TAPER_START_AREA) / (MAX_CONSTRICTION_AREA - TAPER_START_AREA);
                gain *= 1.0 - d;
            }
            let full_amp = gain * velocity.abs() * velocity * velocity * area.sqrt();
            for &(target, share) in &g.targets[..g.num_targets] {
                let s = match target {
                    NoiseTarget::Dipole(i) => {
                        self.targeted.push(2 * i + 1);
                        &mut self.dipole[i]
                    }
                    NoiseTarget::Lips => {
                        self.targeted.push(LIPS_SOURCE);
                        &mut self.lips_dipole
                    }
                };
                s.target_amp_1khz = match share {
                    Some(f) => f * full_amp,
                    None => full_amp,
                };
                s.is_first_order = false;
                s.cutoff_freq = g.cutoff;
            }
        }
        const MIN_MONOPOLE_AMP: f64 = 0.001;
        const MIN_DIPOLE_AMP: f64 = 0.001;
        let (dt, position) = (self.time_step, self.position);
        // Each source sounding or given a target, in 2.4's order: the pharynx's to the nose's monopole and dipole by
        // section, then the lips'.
        let mut take = std::mem::take(&mut self.take);
        take.clear();
        for &id in self.awake.iter().chain(&self.targeted) {
            if (id == LIPS_SOURCE || (tube::FIRST_PHARYNX_SECTION..=tube::LAST_NOSE_SECTION).contains(&(id / 2))) && !take.contains(&id) {
                take.push(id);
            }
        }
        take.sort_unstable();
        self.awake.clear();
        for &id in &take {
            let s = match id {
                LIPS_SOURCE => &mut self.lips_dipole,
                _ if id % 2 == 1 => &mut self.dipole[id / 2],
                _ => &mut self.monopole[id / 2],
            };
            noise_sample(s, if id % 2 == 0 && id != LIPS_SOURCE { MIN_MONOPOLE_AMP } else { MIN_DIPOLE_AMP }, dt, &self.per_rate, position, &mut self.rng);
            if !s.silent {
                self.awake.push(id);
            }
        }
        self.take = take;
    }

    fn calc_matrix(&mut self, radiation: &[(f64, f64); 2]) {
        let dt = self.time_step;
        let (sections, currents, dipole) = (&self.ts, &self.bc, &self.dipole);
        let system = &mut self.system;
        let (lips_dipole, pressure_source_section, pressure_source_amp) = (self.lips_dipole.sample, self.pressure_source_section, self.pressure_source_amp);
        let inner_length_corrections = self.options.inner_length_corrections;
        for x in system.rhs.iter_mut() {
            *x = 0.0;
        }
        // (Row i's column j written where the system keeps it.)
        macro_rules! matrix {
            ($i:expr, $j:expr) => {
                *system.entry($i, $j)
            };
        }
        for i in 0..N {
            let bc = &currents[i];
            let source = if bc.source_section != -1 { Some(&sections[bc.source_section as usize]) } else { None };
            let target = if bc.target_section != -1 { Some(&sections[bc.target_section as usize]) } else { None };
            match (source, target) {
                (None, None) => return,
                (Some(s), None) => {
                    // Into free space: the radiation's resistance and inductance, two currents in parallel.
                    if s.current_out[0] == -1 || s.current_out[1] == -1 {
                        return;
                    }
                    let resistance_current = s.current_out[0] as usize;
                    let inductivity_current = s.current_out[1] as usize;
                    let ur = currents[resistance_current].magnitude;
                    let ul = currents[inductivity_current].magnitude;
                    let ur_rate = currents[resistance_current].magnitude_rate;
                    let ul_rate = currents[inductivity_current].magnitude_rate;
                    let la = s.l;
                    let ra = s.r[1];
                    let src = -lips_dipole;
                    let (r_rad, l_rad) = if bc.source_section == tube::LAST_MOUTH_SECTION as i32 { radiation[0] } else { radiation[1] };
                    let (f, g, h);
                    if i == resistance_current {
                        f = la / (dt * THETA) + ra + r_rad;
                        g = la / (dt * THETA) + ra;
                        h = -(la / (dt * THETA)) * (ur + ul) - (la * (THETA1 / THETA)) * (ur_rate + ul_rate) + src;
                    } else if i == inductivity_current {
                        let lab = la + l_rad;
                        f = la / (dt * THETA) + ra;
                        g = lab / (dt * THETA) + ra;
                        h = -(1.0 / (dt * THETA)) * (la * ur + lab * ul) - (THETA1 / THETA) * (la * ur_rate + lab * ul_rate) + src;
                    } else {
                        return;
                    }
                    if s.current_in != -1 {
                        matrix!(i, s.current_in as usize) = s.e;
                    }
                    matrix!(i, resistance_current) = -s.e - f;
                    matrix!(i, inductivity_current) = -s.e - g;
                    system.rhs[i] = h - s.d;
                }
                (source, Some(t)) => {
                    let lb = t.l;
                    let rb = t.r[0];
                    let (la, ra) = match source {
                        Some(s) => (s.l, s.r[1]),
                        None => (0.0, 0.0),
                    };
                    let mut lab = la + lb;
                    let rab = ra + rb;
                    let mut branching_off: i32 = -1;
                    if let Some(s) = source {
                        branching_off = if s.current_out[0] == i as i32 { s.current_out[1] } else { s.current_out[0] };
                    }
                    let mut src = t.s;
                    src -= dipole[bc.target_section as usize].sample;
                    if bc.target_section == pressure_source_section {
                        src -= pressure_source_amp;
                    }
                    if branching_off != -1 {
                        let s = source.unwrap();
                        let ub = bc.magnitude;
                        let ub_rate = bc.magnitude_rate;
                        let ud = currents[branching_off as usize].magnitude;
                        let ud_rate = currents[branching_off as usize].magnitude_rate;
                        let f = lab / (dt * THETA) + rab;
                        let g = la / (dt * THETA) + ra;
                        let h = -(1.0 / (dt * THETA)) * (lab * ub + la * ud) - (THETA1 / THETA) * (lab * ub_rate + la * ud_rate) + src;
                        matrix!(i, branching_off as usize) = -s.e - g;
                        if s.current_in != -1 {
                            matrix!(i, s.current_in as usize) = s.e;
                        }
                        matrix!(i, i) = -t.e - s.e - f;
                        if t.current_out[0] != -1 {
                            matrix!(i, t.current_out[0] as usize) = t.e;
                        }
                        if t.current_out[1] != -1 {
                            matrix!(i, t.current_out[1] as usize) = t.e;
                        }
                        system.rhs[i] = h + t.d - s.d;
                    } else {
                        let u = bc.magnitude;
                        let u_rate = bc.magnitude_rate;
                        if inner_length_corrections && bc.source_section >= tube::FIRST_PHARYNX_SECTION as i32 && bc.target_section <= tube::LAST_MOUTH_SECTION as i32 {
                            lab += junction_inductance(sections[bc.source_section as usize].area, sections[bc.target_section as usize].area);
                        }
                        let g = lab / (dt * THETA) + rab;
                        let h = -u_rate * lab * (THETA1 / THETA) - (lab * u) / (dt * THETA) + src;
                        if let Some(s) = source {
                            if s.current_in != -1 {
                                matrix!(i, s.current_in as usize) = s.e;
                            }
                        }
                        matrix!(i, i) = -t.e - g;
                        if let Some(s) = source {
                            matrix!(i, i) -= s.e;
                        }
                        if t.current_out[0] != -1 {
                            matrix!(i, t.current_out[0] as usize) = t.e;
                        }
                        if t.current_out[1] != -1 {
                            matrix!(i, t.current_out[1] as usize) = t.e;
                        }
                        system.rhs[i] = h + t.d;
                        if let Some(s) = source {
                            system.rhs[i] -= s.d;
                        }
                    }
                }
            }
        }
    }

    fn update_variables(&mut self) {
        let dt = self.time_step;
        let noise_filter_coeff = self.per_rate.noise_filter_coeff;
        let recovery_coeff = (-2.0 * PI * self.options.bernoulli_cutoff_hz * dt).exp();
        for i in 0..N {
            let b = &mut self.bc[i];
            let old = b.magnitude;
            b.magnitude = self.flow[i];
            b.magnitude_rate = (b.magnitude - old) / (dt * THETA) - (THETA1 / THETA) * b.magnitude_rate;
            b.noise_magnitude = (1.0 - noise_filter_coeff) * b.magnitude + noise_filter_coeff * b.noise_magnitude;
        }
        // (Each section's dynamic pressure, its mean flow and its area together, low-passed: passive_bernoulli's exchange.
        // A smoothed flow over the area as it is now would pair a closing glottis's flow of before with its area of
        // after.)
        if self.passive_bernoulli() {
            for i in 0..NUM_SECTIONS {
                let (a, u) = (self.ts[i].area, 0.5 * (self.current_out(i) + self.current_in(i)));
                let q = 0.5 * AMBIENT_DENSITY_CGS * u * u / (a * a);
                self.dynamic[i] = (1.0 - recovery_coeff) * q + recovery_coeff * self.dynamic[i];
            }
        }
        for i in 0..NUM_SECTIONS {
            let net_flow = self.current_in(i) - self.current_out(i);
            let ts = &mut self.ts[i];
            let old_pressure = ts.pressure;
            ts.pressure = ts.d + ts.e * net_flow;
            ts.pressure_rate = (ts.pressure - old_pressure) / (dt * THETA) - ts.pressure_rate * (THETA1 / THETA);
            let old_current = ts.wall_current;
            let old_current_rate = ts.wall_current_rate;
            ts.wall_current = ts.pressure_rate * ts.alpha + ts.beta;
            ts.wall_current_rate = (ts.wall_current - old_current) / (dt * THETA) - old_current_rate * (THETA1 / THETA);
            ts.wall_current_rate2 = (ts.wall_current_rate - old_current_rate) / (dt * THETA) - ts.wall_current_rate2 * (THETA1 / THETA);
        }
    }

    fn solve_cholesky(&mut self) {
        match self.options.solver {
            Solver::Envelope => self.cholesky.solve(&self.system, &mut self.flow),
            Solver::Tree => self.tree.solve(&self.system, &mut self.flow),
            Solver::Reference => {
                self.tree.negative_pivots += self.tree.solve_reference(&self.system, &mut self.flow, &mut self.reference);
            }
        }
    }

    /// Pivots found below zero and made zero, as 2.4 makes them, since the model was made: 2.4's order's, the tree's
    /// (and the reference's).
    pub fn negative_pivots(&self) -> (u64, u64) {
        (self.cholesky.negative_pivots, self.tree.negative_pivots)
    }
}

/// A section's coefficients from its area, length and volume (prepareTimeStep's, each expression as it writes it): its
/// inertance, its loss (the larger of its DC and AC losses times half its length, before the pressure recovered past a
/// widening is added), its walls' alpha and the factors beta multiplies their current, its rate and its second rate by
/// (the last the walls' mass, multiplied in its turn), and its `e` (dt theta over its compliance plus alpha). The
/// sinuses' by Poiseuille's raised fifteenfold; the glottis's two without walls.
#[derive(Clone, Copy, Debug, Default)]
pub struct SectionCoefficients {
    pub l: f64,
    pub r: f64,
    pub alpha: f64,
    pub e: f64,
    pub wall: [f64; 3],
}

fn section_coefficients(i: usize, area: f64, length: f64, volume: f64, dt: f64, soft_walls: bool) -> SectionCoefficients {
    let circ = 2.0 * (area * PI).sqrt();
    let sinus = (tube::FIRST_SINUS_SECTION..=tube::LAST_SINUS_SECTION).contains(&i);
    let (l, c, r);
    if sinus {
        l = AMBIENT_DENSITY_CGS * (length / area);
        c = volume / (AMBIENT_DENSITY_CGS * SOUND_VELOCITY_CGS * SOUND_VELOCITY_CGS);
        const EMPIRICAL_FACTOR: f64 = 15.0;
        r = EMPIRICAL_FACTOR * (8.0 * AIR_VISCOSITY_CGS * PI * length) / (area * area);
    } else {
        l = (AMBIENT_DENSITY_CGS * 0.5 * length) / area;
        c = volume / (AMBIENT_DENSITY_CGS * SOUND_VELOCITY_CGS * SOUND_VELOCITY_CGS);
        let dc = DC_R0 * (REF_AREA_CM2 / area).powf(DC_EXPONENT);
        // (2.4's AC exponent is 1: its power the number itself, as pow gives it.)
        let ac = AC_R0 * if AC_EXPONENT == 1.0 { REF_AREA_CM2 / area } else { (REF_AREA_CM2 / area).powf(AC_EXPONENT) } * AC_FREQUENCY_HZ.sqrt();
        r = if dc > ac { 0.5 * length * dc } else { 0.5 * length * ac };
    }
    let (mut alpha, mut wall) = (0.0, [0.0; 3]);
    if soft_walls && i != tube::LOWER_GLOTTIS_SECTION && i != tube::UPPER_GLOTTIS_SECTION {
        let mut surface = if sinus { 4.0 * PI * ((3.0 * volume) / (4.0 * PI)).powf(2.0 / 3.0) } else { circ * length };
        if surface < MIN_AREA_CM2 {
            surface = MIN_AREA_CM2;
        }
        let rw = WALL_DAMPING_PER_UNIT_AREA_CGS / surface;
        let lw = WALL_MASS_PER_UNIT_AREA_CGS / surface;
        let cw = surface / WALL_STIFFNESS_PER_UNIT_AREA_CGS;
        let current = lw / (dt * dt * THETA * THETA) + rw / (dt * THETA);
        alpha = 1.0 / (current + 1.0 / cw);
        wall = [current, lw * (THETA1 / THETA + 1.0) / (dt * THETA) + rw * (THETA1 / THETA), lw];
    }
    SectionCoefficients { l, r, alpha, e: dt * THETA / (c + alpha), wall }
}

/// The radiation's resistance and inductance at an opening of `area` (cm^2): a piston's (for its tests and the passive
/// core's radiation laws: acoustics/radiation.json's `piston`).
pub fn radiation_at(area: f64) -> (f64, f64) {
    radiation(area)
}

/// The radiation's resistance and inductance at an opening of `area` (cm^2): a piston's.
fn radiation(area: f64) -> (f64, f64) {
    ((128.0 * AMBIENT_DENSITY_CGS * SOUND_VELOCITY_CGS) / (9.0 * PI * PI * area), (8.0 * AMBIENT_DENSITY_CGS) / (3.0 * PI * (area * PI).sqrt()))
}

/// What follows from the rate alone, each as the step wrote it (made again when the rate is set): the flows' smoothing
/// for the noise (a 500 Hz first-order low-pass), a noise source's rise over 3 ms, and its draws' scale (the root of the
/// rate over 48 kHz).
#[derive(Clone, Copy, Debug, Default)]
struct PerRate {
    noise_filter_coeff: f64,
    noise_rise: f64,
    noise_scale: f64,
}

impl PerRate {
    fn new(rate: f64, dt: f64) -> PerRate {
        let time_constant_samples = 0.003 * rate;
        PerRate { noise_filter_coeff: (-2.0 * PI * NOISE_CUTOFF_FREQ * dt).exp(), noise_rise: (-1.0 / time_constant_samples).exp(), noise_scale: (rate / AUDIO_SAMPLING_RATE_HZ as f64).sqrt() }
    }
}

/// Sondhi's (1983) junction inductance between two sections, an inner length correction.
fn junction_inductance(a1: f64, a2: f64) -> f64 {
    let a1 = a1.max(MIN_AREA_CM2);
    let a2 = a2.max(MIN_AREA_CM2);
    let (a, b) = if a1 > a2 { ((a1 / PI).sqrt(), (a2 / PI).sqrt()) } else { ((a2 / PI).sqrt(), (a1 / PI).sqrt()) };
    let h = 1.0 - b / a;
    8.0 * AMBIENT_DENSITY_CGS * h / (3.0 * PI * PI * b)
}

/// A noise source's next sample: its amplitude rising toward its target over 3 ms (on its square root), falling at
/// once; off below its threshold; else a Gaussian draw (sd 1/sqrt 12, within +-1) through a second-order Butterworth
/// low-pass at its cutoff, its gain keeping the radiated noise's level whatever the cutoff, and (2.4) six tenths of it.
/// Stepped faster than 48 kHz, its draws are scaled by the root of the rate's ratio, so that its density in the band
/// heard stays 2.4's (white noise's spread over the wider band).
fn noise_sample(s: &mut NoiseSource, threshold: f64, dt: f64, per_rate: &PerRate, position: i32, rng: &mut Mt19937) {
    if s.target_amp_1khz > s.current_amp_1khz {
        let f = per_rate.noise_rise;
        let sqrt_target = s.target_amp_1khz.sqrt();
        let mut sqrt_current = s.current_amp_1khz.sqrt();
        sqrt_current = (1.0 - f) * sqrt_target + f * sqrt_current;
        s.current_amp_1khz = sqrt_current * sqrt_current;
    } else {
        s.current_amp_1khz = s.target_amp_1khz;
    }
    if s.current_amp_1khz < threshold {
        s.current_amp_1khz = 0.0;
        if !s.silent {
            s.input = [0.0; 8];
            s.output = [0.0; 8];
            s.sample = 0.0;
            s.silent = true;
        }
        return;
    }
    s.silent = false;
    let key = (s.is_first_order, (s.cutoff_freq * dt).to_bits());
    if s.designed_for != Some(key) {
        s.coeffs = if s.is_first_order {
            let x = (-2.0 * PI * (s.cutoff_freq * dt)).exp();
            ([1.0 - x, 0.0, 0.0], [1.0, x, 0.0], 1)
        } else {
            let (a0, a1, a2, b1, b2) = second_order_lowpass(s.cutoff_freq * dt, 1.0 / 2f64.sqrt());
            ([a0, a1, a2], [1.0, b1, b2], 2)
        };
        s.designed_for = Some(key);
    }
    let (a, b, order) = s.coeffs;
    let mut filter_gain = s.current_amp_1khz;
    if s.cutoff_freq < 1.0 {
        s.cutoff_freq = 1.0;
    }
    let factor = 1000.0 / s.cutoff_freq;
    filter_gain *= factor * factor.sqrt();
    filter_gain *= 0.6;
    let mut normal = NormalDistribution::new(1.0 / 12f64.sqrt());
    let mut input;
    loop {
        input = normal.sample(rng);
        if !(input < -1.0 || input > 1.0) {
            break;
        }
    }
    s.input[(position & NOISE_BUFFER_MASK) as usize] = input;
    let mut sum = a[0] * input;
    for k in 1..=order {
        let at = (position.wrapping_sub(k as i32) & NOISE_BUFFER_MASK) as usize;
        sum += a[k] * s.input[at];
        sum += b[k] * s.output[at];
    }
    s.output[(position & NOISE_BUFFER_MASK) as usize] = sum;
    s.sample = sum * filter_gain * per_rate.noise_scale;
}
