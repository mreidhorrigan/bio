// VocalTractLab 2.4 (the owner, 11 November 2026: "Without breaking 2.3 (which we'll preserve for various purposes as an
// alternative), you are free to proceed with the port of 2.4"): its release of 5 December 2025 (vocaltractlab.de,
// VTL2.4.zip, its API's source; GPL-3.0), ported beside 2.3 (the crate's root modules, which stay as they are) and held to
// it sample for sample as 2.3's are (reference/v24_*.c against the strict build in the synthesis home's
// vocaltractlab-2.4). What 2.4 changed is here: the tract's geometry (its tongue, center line and cross-sections, a tube of
// 50 sections where 2.3's has 40), the tube, the acoustics at 48 kHz with their new losses, noise and radiation, the
// "Geometric glottis 2025", the synthesizer and the gestural score; what it left as it was is shared with 2.3 (geometry,
// surfaces, splines -- with 2.4's two intersections added -- the filters, the XML).
//   tract, tongue, sections -- the vocal tract's geometry, as 2.4 makes it
//   tube                    -- the branched tube, as 2.4 lays it
//   constants, tds          -- 2.4's constants, and its tube's acoustics in the time domain at 48 kHz
//   solve                   -- the tube's system each step, solved for its currents
//   pipeline                -- the frames' part of each step made ahead on its own thread, the acoustics on another
//   glottis, synth, speaker -- the Geometric glottis 2025, the synthesizer's radiation, 2.4's speaker files
//   gestural                -- its gestural score: its tiers, their targets and curves
//   segments                -- its rules for making a score of phones and their F0
pub mod anatomy;
pub mod constants;
pub mod gestural;
pub mod glottis;
pub mod passive;
pub mod pipeline;
pub mod sections;
pub mod segments;
pub mod solve;
pub mod speaker;
pub mod synth;
pub mod tongue;
pub mod tds;
pub mod tract;
pub mod tube;
