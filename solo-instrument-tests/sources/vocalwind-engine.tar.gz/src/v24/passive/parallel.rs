//! VocalWind's step on several cores (research/VOCAL_TRACT_REALTIME_PLAN.md, 6, "The step spread over cores"; the owner,
//! 14 November 2026: "Ok, proceed with multicore and with the trachea redesign, ..."). Where 2.4 solves every pressure
//! of the tube together each step, VocalWind's scheme, OpenWInD's, is explicit: each flow from the pressures beside it,
//! each pressure from its own flows, the correction the same over B and B^T. So the network is cut into parts, each a
//! run of whole elements in their order -- the main thread's the trachea, the glottis and the pharynx's first; the
//! last's the fossa and the nose with its sinuses, with what of the mouth its cost leaves it -- of about equal cost
//! (`spans`), each stepped on a core of its own in a copy of the model of its own, as the winds' engine steps a bore
//! (native/openwind/src/parallel.rs).
//!
//! A node two parts' elements meet at (a shared node) each of them steps alike in its copy: its air summed from every
//! element at it, each part laying the other's elements there as far as their air (`HALO`); its inflow summed from
//! every element's flow at it in the elements' order, the other part's posted on its board -- twice a step, the
//! corrected pressure's terms (B^T M_u^-1 B p) and the new flows, each by the step's parity with the count of the steps
//! posted -- so that each node and edge does the arithmetic it does on one core, in the same order: the same bytes. A
//! part waits on the parts beside it alone, but for the noise: 2.4's sources step on the main thread, as on one core,
//! from every part's flows of the step before (each part's posted as soon as they are solved), and every part adds them
//! just before it solves its own -- its pressures corrected meanwhile.
//!
//! Each part's outputs -- the mouth's and the nostrils' flows, and its skin's, summed in the nodes' order part after
//! part, each a step behind the part before -- are read by the main thread some steps late, a call's last steps' once
//! its parts are done (`Crew::finish`). Not with the thermal half of the boundary layer, nor the energy's account: those
//! a synthesizer steps on one core. The main thread's model holds its own part's state alone while its crew lives
//! (`Crew::gather` for the rest); the step on one core (PassiveModel::proceed_time_step_with) is the reference each
//! phase here follows, held to it byte for byte (test/audio/vocaltract.test.mjs).
//!
//! A part's step goes in four stages -- laid, corrected, solved, finished -- cut where it reads what others post, each
//! begun once all it reads is posted, so that it runs through without a wait. Each stage is taken by whichever thread
//! comes to it first: its worker, or the main thread where it waits on the crew and the part's worker sleeps, or has
//! left it untaken HELP spins once it could -- as the winds' crew takes a part's step (the owner, 15 November 2026, of
//! its design: "yes, proceed with this design"; "The winds have been through heavy optimization already, so we should
//! take advantage of the discoveries there"). So a worker late to a call -- woken late, or taken off its core while
//! others' work fills the machine -- does not hold the steps back: the main thread steps its part for it. Whoever steps
//! it, a part is stepped in the same copy of the model (its `Seat`), in the same order: the same bytes.

use super::*;
use crate::v24::synth::StepRecord;
use std::cell::UnsafeCell;
use std::ops::Range;
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::Arc;
use std::thread::JoinHandle;
use std::time::{Duration, Instant};

/// A moving element's cost a step and a still one's, as a sung phrase spends them on a performance core (the pharynx's
/// and the mouth's laid again each step as the tract moves; the trachea's, the fossa's and the nose's kept): what a
/// part is charged for each, in samples of that phrase's profile (claude-scratch/vocalwind-proof/profile/multicore).
const MOVING_COST: f64 = 21.0;
const STILL_COST: f64 = 6.2;
/// The main thread's own work a step in those units, beside its part: the glottis and the noise (MAIN_COST), and the
/// step's tube where it makes it too (MAIN_COST_WITH_TUBE: Synthesizer::add_tube; add_records takes them made).
pub const MAIN_COST: f64 = 47.0;
pub const MAIN_COST_WITH_TUBE: f64 = 195.0;

/// Steps' records kept for the parts to read (the main thread writes the next while the slowest reads the last).
const RECORDS: usize = 4;
/// Steps of outputs kept (the skin's sums a step behind each part before).
const RING: usize = 8;
/// The most elements a part posts, and branch currents it gives the noise (all 2.4's but the trachea's and the
/// glottis's, at most).
const BOUNDARY: usize = 8;
const CURRENTS: usize = 128;
/// The sections that sound the noise: the pharynx's, the mouth's and the nose's.
const SOURCES: usize = tube::LAST_NOSE_SECTION - tube::FIRST_PHARYNX_SECTION + 1;
/// How long a worker spins for the next call before it sleeps (as the winds' crew's).
const IDLE: Duration = Duration::from_micros(250);
/// How long the main thread, waiting on the crew, leaves a stage of an awake worker's part untaken that it could take,
/// before it steps it itself (PassiveModel::help, the default): spins, some 0.3-1.3 us -- past the moment a worker on
/// its core takes a stage it can (a few of its loops), short of a stage (some 1 us on three cores). (The winds' crew
/// waits 4096 spins on any part, past their step's 1-3 us; the voice's, under other runs' load, sang its phrase twice
/// as fast and more with 256 as with 4096: claude-scratch/vocalwind-proof/crew-help/timing-2.4.txt.)
pub const HELP: u32 = 1 << 8;
/// A part's step's stages (`stage_at`): its elements laid and its pressures' terms at its shared nodes posted; the
/// other parts' read and its pressures corrected; the noise added and its flows solved and posted; the others' read
/// and its nodes stepped, its outputs posted.
const LAID: u64 = 1;
const CORRECTED: u64 = 2;
const SOLVED: u64 = 3;
const FINISHED: u64 = 4;
/// The key's mark of an element laid as far as its air alone (another part's, at a node shared: `part_lay`), never one
/// laid whole.
const HALO: u64 = 1 << 63;

/// What lies in a cache line of its own (Apple silicon's are 128 bytes).
#[repr(align(128))]
struct Line<X>(X);

/// A part's values for the parts beside it -- its elements' at its shared nodes, two each -- by the step's parity, with
/// the count of the steps posted.
struct Post {
    done: AtomicU64,
    values: UnsafeCell<[[f64; 2 * BOUNDARY]; 2]>,
}

/// The noise's sources a step: (section, monopole, dipole) where either is not 0, in order, and the lips' dipole.
#[derive(Clone, Copy)]
struct Sources {
    n: usize,
    terms: [(usize, f64, f64); SOURCES],
    lips: f64,
}

/// The main thread's sources by the step's parity, with the count.
struct Noise {
    done: AtomicU64,
    slots: UnsafeCell<[Sources; 2]>,
}

/// A part's branch currents for the noise (its `currents`), by parity, with the count.
struct Currents {
    done: AtomicU64,
    values: UnsafeCell<[[f64; CURRENTS]; 2]>,
}

/// A part's outputs, RING steps of them: the mouth's and the nostrils' flows where it radiates (and the last step
/// posted), and the skin's sum through its nodes (and the last step summed).
struct Outputs {
    done: AtomicU64,
    summed: AtomicU64,
    mouth: UnsafeCell<[f64; RING]>,
    nostrils: UnsafeCell<[f64; RING]>,
    skin: UnsafeCell<[f64; RING]>,
}

/// A worker's part's stages (`stage_at`): the last taken, by its worker or the main thread, and the last done; and
/// whether the main thread has found its worker off its core (`help`), until the worker takes a stage again.
struct Turn {
    taken: AtomicU64,
    staged: AtomicU64,
    late: AtomicBool,
}

struct Boards {
    x1: Line<Post>,
    x2: Line<Post>,
    currents: Line<Currents>,
    outputs: Line<Outputs>,
    asleep: Line<AtomicBool>,
    turn: Line<Turn>,
}

/// A worker's part's own: its copy of the model, and its skin's walls' flows kept (RING steps of them).
struct Seat {
    m: PassiveModel,
    kept: Vec<f64>,
}

struct Shared {
    /// The last step whose record is written (the main thread's): a worker may begin it.
    ready: Line<AtomicU64>,
    /// The call's last step: a part sums its skin's last steps once it has done it.
    last: Line<AtomicU64>,
    stop: AtomicBool,
    noise: Line<Noise>,
    boards: Vec<Boards>,
    records: Box<[UnsafeCell<StepRecord>]>,
    /// Each worker's part's seat (the parts after the main thread's), stepped by whichever thread has taken its stage,
    /// touched by the main thread between calls.
    seats: Box<[Line<UnsafeCell<Seat>>]>,
    /// The spins the main thread waits on a worker awake before it steps its part (PassiveModel::help; never, None),
    /// and the stages it has stepped so (the main thread's alone).
    help: Option<u32>,
    helped: Line<AtomicU64>,
}

// (Each place written by one thread only, at a step whose parity or slot none reads meanwhile -- none reads a step's but
// after the count that tells of it, and none is two steps behind the noise that every part waits for -- before that
// count; read only after it. A seat is stepped by the thread that has taken the stage alone, the counts ordering one
// stage's taker after the last's.)
unsafe impl Sync for Shared {}

/// A part: the run of elements one thread steps, and what it steps with them.
struct Span {
    part: usize,
    elements: Range<usize>,
    /// Its acoustic nodes but the lungs' (its elements', those shared too; its cavities), each with its walls' nodes.
    nodes: Vec<usize>,
    wall_nodes: Vec<usize>,
    /// Its nodes no other part's element meets (the lungs' too: their inflow scattered), and those shared (gathered).
    interior: Vec<usize>,
    cut: Vec<usize>,
    /// Whether an acoustic node is one it steps.
    held: Vec<bool>,
    /// Its walls (their places among the walls), its other lumped edges (the glottis, the necks, the radiation's
    /// inductances: edges' indices, in order), its radiating ends, and the joins any of its elements or necks is on.
    walls: Vec<usize>,
    lumped: Vec<usize>,
    radiating: Vec<usize>,
    joins: Vec<usize>,
    /// The other parts' elements at its shared nodes, and where each is posted: (element, part, place).
    halo: Vec<usize>,
    reads: Vec<(usize, usize, usize)>,
    beside: Vec<usize>,
    /// Its own elements at nodes shared, in order: what it posts.
    boundary: Vec<usize>,
    /// The branch currents it gives the noise, and its skin's walls' edges in the nodes' order (a shared node's given
    /// to the part whose element laid it).
    currents: Vec<usize>,
    skin: Vec<usize>,
    glottis: bool,
    sinuses: bool,
    cost: f64,
}

impl Span {
    /// Whether a join's side (an element's two flows, or a neck) is its own.
    fn owns(&self, s: &Side) -> bool {
        if s.count == 2 {
            self.elements.contains(&(s.edge / 2))
        } else {
            self.sinuses
        }
    }
}

/// The network cut into `parts` runs of whole elements of about equal cost, the main thread's charged `main_cost`
/// besides: a part begins past the pharynx's first element (the glottis with the trachea, on the main thread), within
/// the pharynx and the mouth, or at the fossa -- never within the fossa nor the nose (its sinuses' necks at its nodes).
fn spans(m: &PassiveModel, parts: usize, main_cost: f64) -> Vec<Span> {
    let n_el = m.elements.len();
    let first_pharynx = m.first_element[tube::FIRST_PHARYNX_SECTION];
    let first_fossa = m.first_element[tube::FIRST_FOSSA_SECTION];
    assert!(
        first_pharynx == m.last_element[tube::LAST_TRACHEA_SECTION] + 1 && first_fossa == m.last_element[tube::LAST_MOUTH_SECTION] + 1 && m.first_element[tube::FIRST_NOSE_SECTION] > first_fossa,
        "the ducts laid in their order"
    );
    let moving = |s: usize| (tube::FIRST_PHARYNX_SECTION..=tube::LAST_MOUTH_SECTION).contains(&s);
    let mut sum = vec![0.0; n_el + 1];
    for (e, el) in m.elements.iter().enumerate() {
        sum[e + 1] = sum[e] + if moving(el.section) { MOVING_COST } else { STILL_COST };
    }
    let cost = |a: usize, b: usize| sum[b] - sum[a];
    let at: Vec<usize> = (first_pharynx + 1..=first_fossa).collect();
    let parts = parts.clamp(1, at.len() + 1);
    // (the least largest part: best[k][i] over parts 0..=k, part k ending where at[i] begins the next)
    let mut best = vec![vec![f64::INFINITY; at.len()]; parts];
    let mut from = vec![vec![0usize; at.len()]; parts];
    for i in 0..at.len() {
        best[0][i] = cost(0, at[i]) + main_cost;
    }
    for k in 1..parts.saturating_sub(1) {
        for i in 0..at.len() {
            for j in 0..i {
                let c = best[k - 1][j].max(cost(at[j], at[i]));
                if c < best[k][i] {
                    best[k][i] = c;
                    from[k][i] = j;
                }
            }
        }
    }
    let mut bounds = vec![0];
    if parts > 1 {
        let (mut i, mut top) = (0, f64::INFINITY);
        for j in 0..at.len() {
            let c = best[parts - 2][j].max(cost(at[j], n_el));
            if c < top {
                top = c;
                i = j;
            }
        }
        let mut cuts = vec![at[i]];
        for k in (1..parts - 1).rev() {
            i = from[k][i];
            cuts.push(at[i]);
        }
        cuts.reverse();
        bounds.extend(cuts);
    }
    bounds.push(n_el);
    let mut owner = vec![0; n_el];
    for p in 0..parts {
        owner[bounds[p]..bounds[p + 1]].iter_mut().for_each(|o| *o = p);
    }
    let sinus_part = owner[m.first_element[tube::FIRST_NOSE_SECTION]];
    let acoustic = m.walls.acoustic;
    // each acoustic node's parts: its elements', a cavity its sinus's
    let mut holders: Vec<Vec<usize>> = vec![Vec::new(); acoustic];
    for (n, h) in holders.iter_mut().enumerate() {
        for &(e, _) in &m.parts[m.parts_from[n]..m.parts_from[n + 1]] {
            if !h.contains(&owner[e]) {
                h.push(owner[e]);
            }
        }
    }
    for &c in &m.cavity {
        holders[c] = vec![sinus_part];
    }
    let lumped_part = |i: usize| -> usize {
        match m.edges[i].kind {
            Kind::Glottis => owner[m.last_element[tube::LAST_TRACHEA_SECTION]],
            Kind::Neck(_) => sinus_part,
            Kind::Inductance(w) => owner[m.radiating[w].0],
            Kind::Wall => unreachable!("the walls are not among the lumped edges before them"),
        }
    };
    for (i, edge) in m.edges[..m.walls.first].iter().enumerate() {
        for n in [edge.from, edge.to] {
            assert!(n == ATMOSPHERE || holders[n] == [lumped_part(i)], "a lumped edge at a node two parts share");
        }
    }
    let side_part = |s: &Side| if s.count == 2 { owner[s.edge / 2] } else { sinus_part };
    // (the part whose element laid each node -- its middle or its end --, the pharynx's first node the glottis's)
    let mut laid_by = vec![NONE; acoustic];
    for (e, el) in m.elements.iter().enumerate() {
        laid_by[el.nodes[1]] = owner[e];
        laid_by[el.nodes[2]] = owner[e];
    }
    laid_by[m.pharynx_bottom] = owner[first_pharynx];
    let section_part = |i: usize| -> usize {
        if i == tube::LOWER_GLOTTIS_SECTION || i == tube::UPPER_GLOTTIS_SECTION || i == tube::FIRST_PHARYNX_SECTION {
            owner[first_pharynx]
        } else if i >= tube::FIRST_SINUS_SECTION {
            sinus_part
        } else {
            owner[m.first_element[i]]
        }
    };
    let wall_place = |e: usize| e - m.fe_edges - m.walls.first;
    let mut spans: Vec<Span> = (0..parts)
        .map(|p| {
            let held: Vec<bool> = (0..m.mp.len()).map(|n| n < acoustic && holders[n].contains(&p)).collect();
            let nodes: Vec<usize> = (1..acoustic).filter(|&n| held[n]).collect();
            let cut: Vec<usize> = nodes.iter().copied().filter(|&n| holders[n].len() > 1).collect();
            let interior = (0..acoustic).filter(|&n| held[n] && holders[n].len() == 1).collect();
            let walls: Vec<usize> = nodes.iter().filter(|&&n| m.wall_edge[n] != NONE).map(|&n| wall_place(m.wall_edge[n])).collect();
            let wall_nodes = walls.iter().map(|&i| acoustic + i).collect();
            let lumped = (0..m.walls.first).filter(|&i| lumped_part(i) == p).map(|i| m.fe_edges + i).collect();
            let radiating: Vec<usize> = (0..2).filter(|&w| owner[m.radiating[w].0] == p).collect();
            let joins = (0..m.joins.len()).filter(|&j| side_part(&m.joins[j].up) == p || side_part(&m.joins[j].down) == p).collect();
            let mut halo = Vec::new();
            for &c in &cut {
                for &(e, _) in &m.parts[m.parts_from[c]..m.parts_from[c + 1]] {
                    if owner[e] != p && !halo.contains(&e) {
                        halo.push(e);
                    }
                }
            }
            halo.sort_unstable();
            let boundary: Vec<usize> = (bounds[p]..bounds[p + 1]).filter(|&e| m.elements[e].nodes.iter().any(|&n| holders[n].len() > 1)).collect();
            assert!(boundary.len() <= BOUNDARY, "a part posting more elements than its board holds");
            let mut currents: Vec<usize> = (0..NUM_SECTIONS).filter(|&i| section_part(i) == p).collect();
            for &w in &radiating {
                currents.extend([NUM_SECTIONS + 2 * w, NUM_SECTIONS + 2 * w + 1]);
            }
            // (the main thread's own go to its noise unposted)
            assert!(p == 0 || currents.len() <= CURRENTS, "part {p} of {parts} (elements {:?} of {n_el}) gives {} currents: more than its board holds", bounds[p]..bounds[p + 1], currents.len());
            let skin = m.skin_walls.iter().copied().filter(|&e| laid_by[m.walls.from[wall_place(e)]] == p).collect();
            Span {
                part: p,
                elements: bounds[p]..bounds[p + 1],
                nodes,
                wall_nodes,
                interior,
                cut,
                held,
                walls,
                lumped,
                radiating,
                joins,
                halo,
                reads: Vec::new(),
                beside: Vec::new(),
                boundary,
                currents,
                skin,
                glottis: p == owner[first_pharynx],
                sinuses: p == sinus_part,
                cost: cost(bounds[p], bounds[p + 1]) + if p == 0 { main_cost } else { 0.0 },
            }
        })
        .collect();
    assert!(spans[0].glottis, "the glottis on the main thread");
    assert!(spans.iter().flat_map(|s| s.skin.iter().copied()).eq(m.skin_walls.iter().copied()), "the skin's walls part after part in the nodes' order");
    for p in 0..parts {
        let reads: Vec<(usize, usize, usize)> = spans[p]
            .halo
            .iter()
            .map(|&e| (e, owner[e], spans[owner[e]].boundary.iter().position(|&b| b == e).expect("a halo element posted")))
            .collect();
        let mut beside: Vec<usize> = reads.iter().map(|r| r.1).collect();
        beside.sort_unstable();
        beside.dedup();
        spans[p].reads = reads;
        spans[p].beside = beside;
    }
    spans
}

impl PassiveModel {
    /// `lay` for a part: its elements', glottis's, sinuses', ends' and joins' terms, and the air at its nodes -- a shared
    /// node's summed from every element at it, the other parts' laid as far as their air (`HALO`). Not the noise's
    /// (`part_noise`), added just before its flows are solved.
    fn part_lay(&mut self, span: &Span, k: &TubeCoefficients) {
        let dt = self.time_step;
        let rho = AMBIENT_DENSITY_CGS;
        let stiffness = rho * SOUND_VELOCITY_CGS * SOUND_VELOCITY_CGS;
        if span.glottis {
            self.cpos[self.glottis_edge] = 0.0;
            self.cneg[self.glottis_edge] = 0.0;
        }
        if span.sinuses {
            for e in self.neck {
                self.cpos[e] = 0.0;
                self.cneg[e] = 0.0;
            }
        }
        let own = span.elements.clone();
        self.jpos[own.clone()].iter_mut().for_each(|x| *x = 0.0);
        self.jneg[own.clone()].iter_mut().for_each(|x| *x = 0.0);
        self.src[2 * own.start..2 * own.end].iter_mut().for_each(|x| *x = 0.0);
        for &e in &span.lumped {
            self.src[e] = 0.0;
        }
        // (the laws asked, and the surfaces' factor: an element laid under others laid again)
        let laws = self.viscous_layer as u64 | (self.thermal_layer as u64) << 1 | (self.own_circumference as u64) << 2 | (self.fitted_law as u64) << 3 | (self.surfaces.to_bits() & !0xF);
        for e in own.clone() {
            let el = self.elements[e];
            let a = k.area[el.section].max(MIN_AREA_CM2);
            let j = k.length[el.section] / el.parts as f64 / 2.0;
            let wall = if self.own_circumference { k.shape[el.section].max(1.0) } else { 1.0 };
            let key = [a.to_bits(), j.to_bits(), wall.to_bits(), dt.to_bits(), laws];
            self.fresh[e] = self.laid[e] != key;
            if !self.fresh[e] {
                continue;
            }
            for &n in &el.nodes {
                if !self.dirty[n] {
                    self.dirty[n] = true;
                    self.touched.push(n);
                }
            }
            self.circ[e] = 2.0 * (PI * a).sqrt();
            self.laid_a[e] = a;
            self.laid_j[e] = j;
            self.laid[e] = key;
            self.relaid[e] = true;
            for q in 0..2 {
                self.mu[2 * e + q] = j * rho / a;
            }
            if self.viscous_layer {
                let (unit, tau) = if self.fitted_law { fitted_scale(a) } else { (PI * AIR_VISCOSITY_CGS / (a * a) * wall * wall, 0.0) };
                // (the surfaces' factor: the viscous boundary layer's impedance times it, its resistances and its
                // masses alike, on either law)
                let unit = unit * self.surfaces;
                for q in 0..2 {
                    self.r[2 * e + q] = j * unit * DIFFUSIVE_A0;
                    let mut psi = 0.0;
                    for i in 0..DIFFUSIVE_N {
                        let l = if self.fitted_law { j * unit * DIFFUSIVE_A[i] * tau } else { j * rho * DIFFUSIVE_A[i] / a * self.surfaces };
                        let (r, l) = (j * unit * DIFFUSIVE_A[i] / DIFFUSIVE_B[i], l);
                        self.vr[2 * e + q][i] = r;
                        self.vl[2 * e + q][i] = l;
                        let kappa = (l / dt) / (l / dt + 0.5 * r);
                        self.vrk[2 * e + q][i] = r * kappa;
                        self.vlow[2 * e + q][i] = l / dt - 0.5 * r;
                        self.vhigh[2 * e + q][i] = l / dt + 0.5 * r;
                        psi += r * kappa;
                    }
                    self.vpsi[2 * e + q] = psi;
                }
            } else {
                let viscous = viscous_per_length(a);
                for q in 0..2 {
                    self.r[2 * e + q] = j * viscous;
                }
            }
        }
        // (the other parts' elements at the nodes it shares: their air alone, under a key of their own)
        for &e in &span.halo {
            let el = self.elements[e];
            let a = k.area[el.section].max(MIN_AREA_CM2);
            let j = k.length[el.section] / el.parts as f64 / 2.0;
            let wall = if self.own_circumference { k.shape[el.section].max(1.0) } else { 1.0 };
            let key = [a.to_bits(), j.to_bits(), wall.to_bits(), dt.to_bits(), laws | HALO];
            if self.laid[e] == key {
                continue;
            }
            for &n in &el.nodes {
                if span.held[n] && !self.dirty[n] {
                    self.dirty[n] = true;
                    self.touched.push(n);
                }
            }
            self.circ[e] = 2.0 * (PI * a).sqrt();
            self.laid_a[e] = a;
            self.laid_j[e] = j;
            self.laid[e] = key;
        }
        if !self.noise.options.piriform_fossa {
            let e = self.first_element[tube::FIRST_FOSSA_SECTION];
            if own.contains(&e) {
                let shut = 8.0 * AIR_VISCOSITY_CGS * k.length[tube::FIRST_FOSSA_SECTION] * PI / (MIN_AREA_CM2 * MIN_AREA_CM2);
                self.r[2 * e] += shut / 2.0;
                self.r[2 * e + 1] += shut / 2.0;
                self.laid[e] = [u64::MAX; 5];
            }
        }
        if span.sinuses {
            for n in 0..tube::NUM_SINUS_SECTIONS {
                let s = tube::FIRST_SINUS_SECTION + n;
                let v = k.volume[s];
                let (a, l) = (k.area[s].max(MIN_AREA_CM2), k.length[s]);
                let key = [v.to_bits(), a.to_bits(), l.to_bits()];
                if self.sinus_laid[n] != key {
                    self.sinus_laid[n] = key;
                    self.sinus_surf[n] = 4.0 * PI * ((3.0 * v) / (4.0 * PI)).powf(2.0 / 3.0);
                    self.mu[self.neck[n]] = rho * l / a;
                    const EMPIRICAL_FACTOR: f64 = 15.0;
                    self.r[self.neck[n]] = EMPIRICAL_FACTOR * (8.0 * AIR_VISCOSITY_CGS * PI * l) / (a * a);
                    let c = self.cavity[n];
                    if !self.dirty[c] {
                        self.dirty[c] = true;
                        self.touched.push(c);
                    }
                }
            }
        }
        for &w in &span.radiating {
            let (e, end) = self.radiating[w];
            let mid = self.elements[e].nodes[1];
            if self.dirty[mid] != self.dirty[end] {
                let n = if self.dirty[mid] { end } else { mid };
                self.dirty[n] = true;
                self.touched.push(n);
            }
        }
        for &n in &self.touched {
            let (mut vol, mut surf) = (0.0, 0.0);
            for &(e, m) in &self.parts[self.parts_from[n]..self.parts_from[n + 1]] {
                vol += GL_W[m] * self.laid_j[e] * self.laid_a[e];
                surf += GL_W[m] * self.laid_j[e] * self.circ[e];
            }
            self.vol[n] = vol;
            self.surf[n] = surf;
        }
        if span.sinuses {
            for n in 0..tube::NUM_SINUS_SECTIONS {
                let c = self.cavity[n];
                if self.dirty[c] {
                    self.vol[c] += k.volume[tube::FIRST_SINUS_SECTION + n];
                    self.surf[c] += self.sinus_surf[n];
                }
            }
        }
        for &w in &span.radiating {
            let (e, end) = self.radiating[w];
            let mid = self.elements[e].nodes[1];
            if self.dirty[mid] {
                self.vol[mid] += self.vol[end];
                self.surf[mid] += self.surf[end];
                self.vol[end] = 0.0;
                self.surf[end] = 0.0;
            }
        }
        for &n in &self.touched {
            if n == LUNGS {
                continue;
            }
            let bits = self.vol[n].to_bits();
            if self.vol_laid[n] != bits {
                self.vol_laid[n] = bits;
                self.mp[n] = self.vol[n] / stiffness;
            }
        }
        for &w in &span.radiating {
            self.mp[self.radiating[w].1] = 1.0;
        }
        if self.node_y_live {
            self.node_y.iter_mut().for_each(|x| *x = 0.0);
            self.node_y_live = false;
        }
        for &n in &self.touched {
            let e = self.wall_edge[n];
            if e == NONE {
                continue;
            }
            let (i, to) = (e - self.fe_edges, self.edges[e - self.fe_edges].to);
            let surface = self.surf[n].max(MIN_AREA_CM2);
            if self.wall_laid[i] != surface.to_bits() {
                self.wall_laid[i] = surface.to_bits();
                let (mass, damping, stiffness) = self.wall_tissue;
                self.mu[e] = WALL_MASS_PER_UNIT_AREA_CGS * mass / surface;
                self.r[e] = WALL_DAMPING_PER_UNIT_AREA_CGS * damping / surface;
                self.mp[to] = surface / (WALL_STIFFNESS_PER_UNIT_AREA_CGS * stiffness);
                self.own[to] = self.mp[to] + 0.5 * dt * self.node_y[to];
            }
        }
        for &w in &span.radiating {
            let e = self.radiation[w];
            // (as on one core: 2.4's piston, or the category's Pade form at the opening's area)
            let (resistance, inductance) = match self.radiation_law {
                None => k.radiation[w],
                Some((delta, beta_c)) => pade_radiation(k.area[if w == 0 { tube::LAST_MOUTH_SECTION } else { tube::LAST_NOSE_SECTION }], delta, beta_c),
            };
            self.mu[e] = inductance;
            self.r[e] = 0.0;
            self.resistance[w] = resistance;
        }
        for &n in &self.touched {
            self.own[n] = self.mp[n] + 0.5 * dt * self.node_y[n];
        }
        for &n in &self.touched {
            self.dirty[n] = false;
        }
        self.touched.clear();
        if span.glottis {
            let ((l1, l2), (a1, a2)) = ((self.glottis.0[0], self.glottis.0[1]), (self.glottis.1[0], self.glottis.1[1]));
            let g = self.glottis_edge;
            self.mu[g] = rho * (l1 / a1 + l2 / a2);
            self.r[g] = l1 * viscous_per_length(a1) + l2 * viscous_per_length(a2);
            let below = k.area[tube::LAST_TRACHEA_SECTION].max(MIN_AREA_CM2);
            let above = k.area[tube::FIRST_PHARYNX_SECTION].max(MIN_AREA_CM2);
            let forward = 0.5 * rho * (drop_term(below, a1, TRACT_RECOVERY_COEFF) + drop_term(a1, a2, GLOTTIS_RECOVERY_COEFF) + drop_term(a2, above, GLOTTIS_RECOVERY_COEFF));
            let backward = 0.5 * rho * (drop_term(above, a2, GLOTTIS_RECOVERY_COEFF) + drop_term(a2, a1, GLOTTIS_RECOVERY_COEFF) + drop_term(a1, below, TRACT_RECOVERY_COEFF));
            let last = self.u[g];
            for (c, sign) in [(forward, 1.0), (backward, -1.0)] {
                if c >= 0.0 {
                    if sign > 0.0 {
                        self.cpos[g] = c;
                    } else {
                        self.cneg[g] = c;
                    }
                } else if last * sign > 0.0 {
                    self.src[g] += c * last.abs() * last;
                }
            }
        }
        for &n in &span.joins {
            let jn = self.joins[n];
            let (au, ad) = (k.area[jn.up.section].max(MIN_AREA_CM2), k.area[jn.down.section].max(MIN_AREA_CM2));
            let key = [au.to_bits(), ad.to_bits()];
            if self.join_laid[n] != key {
                self.join_laid[n] = key;
                self.join_c[n] = 0.5 * rho * (1.0 / (au.min(ad) * au.min(ad)) - 1.0 / (au.max(ad) * au.max(ad)));
                self.join_length[n] = REATTACHMENT_STEP_HEIGHTS * ((au.max(ad) / PI).sqrt() - (au.min(ad) / PI).sqrt());
            }
            let c = self.join_c[n];
            let (narrow, wide) = if jn.branch {
                (jn.down, jn.down)
            } else if ad < au {
                (jn.down, jn.up)
            } else {
                (jn.up, jn.down)
            };
            if span.owns(&narrow) {
                let (pos, neg) = if narrow.count == 2 { (&mut self.jpos[narrow.edge / 2], &mut self.jneg[narrow.edge / 2]) } else { (&mut self.cpos[narrow.edge], &mut self.cneg[narrow.edge]) };
                if ad < au {
                    *pos += c;
                } else {
                    *neg += c;
                }
            }
            if !span.owns(&wide) {
                continue;
            }
            if self.reattachment {
                for q in 0..wide.count {
                    self.src[wide.edge + q] += jn.lagged / wide.count as f64;
                }
            } else {
                let fraction = self.recovered(jn.recovery, au.min(ad), au.max(ad));
                let (pos, neg) = if wide.count == 2 { (&mut self.jpos[wide.edge / 2], &mut self.jneg[wide.edge / 2]) } else { (&mut self.cpos[wide.edge], &mut self.cneg[wide.edge]) };
                if ad > au {
                    *pos -= fraction * c;
                } else {
                    *neg -= fraction * c;
                }
            }
        }
    }

    /// The noise's sources (as the main thread stepped them: `terms`, `lips`) and the volumes' growth, into a part's
    /// sinks and its edges' sources: `lay`'s last part.
    fn part_noise(&mut self, span: &Span, terms: &[(usize, f64, f64)], lips: f64) {
        let dt = self.time_step;
        for &n in span.nodes.iter().chain(&span.wall_nodes) {
            self.f[n] = 0.0;
        }
        let g = self.glottis_edge;
        for &(i, monopole, dipole) in terms {
            if dipole != 0.0 {
                if i == tube::FIRST_PHARYNX_SECTION {
                    if span.glottis {
                        self.src[g] -= dipole;
                    }
                } else if span.elements.contains(&self.first_element[i]) {
                    let e = 2 * self.first_element[i];
                    self.src[e] -= dipole / 2.0;
                    self.src[e + 1] -= dipole / 2.0;
                }
            }
            if monopole != 0.0 {
                let (a, b) = (self.first_element[i], self.last_element[i]);
                let share = monopole / ((b - a + 1) as f64 * 2.0);
                for e in a..=b {
                    let n = self.elements[e].nodes;
                    for m in 0..3 {
                        if span.held[n[m]] {
                            self.f[n[m]] -= share * GL_W[m];
                        }
                    }
                }
            }
        }
        self.end_source = [-lips; 2];
        let ((l1, l2), (a1, a2)) = ((self.glottis.0[0], self.glottis.0[1]), (self.glottis.1[0], self.glottis.1[1]));
        let glottis_volume = l1 * a1 + l2 * a2;
        if self.started && self.displaced_volume {
            for &n in span.nodes.iter().chain(&span.wall_nodes) {
                self.f[n] += (self.vol[n] - self.vol_prev[n]) / dt;
            }
            if self.folds_displace && span.glottis {
                let half = 0.5 * (glottis_volume - self.glottis_volume) / dt;
                self.f[self.trachea_top] += half;
                self.f[self.pharynx_bottom] += half;
            }
        }
        for &n in span.nodes.iter().chain(&span.wall_nodes) {
            self.vol_prev[n] = self.vol[n];
        }
        if span.glottis {
            self.glottis_volume = glottis_volume;
            self.f[self.pharynx_bottom] -= self.injected;
        }
    }

    /// The flows held as the geometry changes (proceed_time_step_with's), for a part's edges.
    fn part_hold(&mut self, span: &Span) {
        if !self.glottal_velocity_held && self.started && span.glottis {
            let g = self.glottis_edge;
            self.pi[g] = self.mu[g] * self.used[g];
        }
        if self.tract_flow_held && self.started {
            for el in span.elements.clone() {
                if !self.relaid[el] {
                    continue;
                }
                self.relaid[el] = false;
                for e in [2 * el, 2 * el + 1] {
                    self.pi[e] = self.mu[e] * self.used[e];
                    if self.viscous_layer {
                        for i in 0..DIFFUSIVE_N {
                            self.vmom[e][i] = self.vl[e][i] * self.vflow[e][i];
                        }
                    }
                }
            }
        }
    }

    /// A part's flows from its momenta, its nodes' pressures, and its edges' drives from them over their masses
    /// (`correct`'s first half: M_u^-1 B p).
    fn part_tmp(&mut self, span: &Span) {
        let own = span.elements.clone();
        let wall_first = self.fe_edges + self.walls.first;
        for e in 2 * own.start..2 * own.end {
            self.u[e] = self.pi[e] / self.mu[e];
        }
        for &e in &span.lumped {
            self.u[e] = self.pi[e] / self.mu[e];
        }
        for &i in &span.walls {
            let e = wall_first + i;
            self.u[e] = self.pi[e] / self.mu[e];
        }
        for &n in span.nodes.iter().chain(&span.wall_nodes) {
            self.p[n] = self.q[n] / self.mp[n];
        }
        if span.glottis {
            self.p[LUNGS] = 0.0;
        }
        for &w in &span.radiating {
            self.p[self.radiating[w].1] = 0.0;
        }
        self.part_b(span, false);
    }

    /// B x over a part's edges (apply_b's): from the pressures into `tmp` over each edge's mass, or from the corrected
    /// pressures into `force`.
    fn part_b(&mut self, span: &Span, force: bool) {
        let fe = self.fe_edges;
        let (x, out) = if force { (&self.pt, &mut self.force) } else { (&self.p, &mut self.tmp) };
        let over = |e: usize, v: f64| if force { v } else { v / self.mu[e] };
        for e in span.elements.clone() {
            let [a, b, c] = self.elements[e].nodes;
            let (xa, xb, xc) = (x[a], x[b], x[c]);
            for q in 0..2 {
                out[2 * e + q] = over(2 * e + q, D[q][0] * xa + D[q][1] * xb + D[q][2] * xc);
            }
        }
        for &e in &span.lumped {
            let edge = self.edges[e - fe];
            out[e] = over(e, if edge.to == ATMOSPHERE { 0.0 } else { x[edge.to] } - x[edge.from]);
        }
        for &i in &span.walls {
            let e = fe + self.walls.first + i;
            out[e] = over(e, x[self.walls.acoustic + i] - x[self.walls.from[i]]);
        }
    }

    /// B^T y over a part's edges into its nodes' inflows (apply_bt's), but at the nodes it shares (`part_gather`): from
    /// the drives over the masses (`tmp`), or from the flows.
    fn part_scatter(&mut self, span: &Span, flows: bool) {
        let fe = self.fe_edges;
        let y = if flows { &self.u } else { &self.tmp };
        let acc = &mut self.acc;
        for &n in &span.interior {
            acc[n] = 0.0;
        }
        for e in span.elements.clone() {
            let (y0, y1) = (y[2 * e], y[2 * e + 1]);
            let nodes = self.elements[e].nodes;
            for m in 0..3 {
                acc[nodes[m]] += D[0][m] * y0 + D[1][m] * y1;
            }
        }
        for &e in &span.lumped {
            let edge = self.edges[e - fe];
            acc[edge.from] -= y[e];
            if edge.to != ATMOSPHERE {
                acc[edge.to] += y[e];
            }
        }
        for &i in &span.walls {
            let yw = y[fe + self.walls.first + i];
            acc[self.walls.from[i]] -= yw;
            acc[self.walls.acoustic + i] = 0.0 + yw;
        }
    }

    /// A shared node's inflow, every element's at it in their order (its `parts`, the other parts' values as posted),
    /// then its wall's: as apply_bt sums it.
    fn part_gather(&mut self, span: &Span, flows: bool) {
        let y = if flows { &self.u } else { &self.tmp };
        for &c in &span.cut {
            let mut v = 0.0;
            for &(e, m) in &self.parts[self.parts_from[c]..self.parts_from[c + 1]] {
                v += D[0][m] * y[2 * e] + D[1][m] * y[2 * e + 1];
            }
            let w = self.wall_edge[c];
            if w != NONE {
                v -= y[w];
            }
            self.acc[c] = v;
        }
    }

    /// A part's corrected pressures (`correct`'s second half), the lungs' held, and its edges' drives from them.
    fn part_force(&mut self, span: &Span) {
        let dt = self.time_step;
        for &n in span.nodes.iter().chain(&span.wall_nodes) {
            self.pt[n] = self.p[n] - dt * dt / 12.0 * self.acc[n] / self.own[n];
        }
        for &w in &span.radiating {
            self.pt[self.radiating[w].1] = 0.0;
        }
        if span.glottis {
            self.pt[LUNGS] = self.lungs;
        }
        self.part_b(span, true);
    }

    /// A part's flows solved (proceed_time_step_with's, without the account): its elements', its lumped edges' and
    /// walls', its radiating ends'.
    fn part_solve(&mut self, span: &Span) {
        let dt = self.time_step;
        for el in span.elements.clone() {
            let (e0, e1) = (2 * el, 2 * el + 1);
            if self.in_block[e0] {
                continue;
            }
            let ((psi, h0), (_, h1)) = if self.viscous_layer { (self.viscous_terms(e0), self.viscous_terms(e1)) } else { ((0.0, 0.0), (0.0, 0.0)) };
            let (m, beta) = (self.mu[e0], 2.0 * self.mu[e0] / dt + self.r[e0] + psi);
            let g0 = 2.0 * m * self.u[e0] / dt - self.force[e0] - self.src[e0] + h0;
            let g1 = 2.0 * m * self.u[e1] / dt - self.force[e1] - self.src[e1] + h1;
            let sum = g0 + g1;
            let c = if sum >= 0.0 { self.jpos[el] } else { self.jneg[el] };
            let disc = beta * beta + c * sum.abs();
            if disc < 0.0 {
                self.overwhelmed += 1;
                if !self.overwhelmed_at.iter().any(|x| x.0 == e0) && self.overwhelmed_at.len() < 12 {
                    self.overwhelmed_at.push((e0, 0.5 * (self.u[e0] + self.u[e1]), c, beta));
                }
            }
            let mean = sum / (beta + disc.max(0.0).sqrt());
            let delta = 0.5 * (g0 - g1) / beta;
            for (e, sign) in [(e0, 1.0), (e1, -1.0)] {
                let um = mean + sign * delta;
                let u1 = 2.0 * um - self.u[e];
                self.um[e] = um;
                self.pi[e] = m * u1;
                if self.viscous_layer {
                    self.viscous_step::<false>(e, um);
                }
                self.u[e] = u1;
            }
        }
        let wall_first = self.fe_edges + self.walls.first;
        for x in 0..span.lumped.len() + span.walls.len() {
            let e = if x < span.lumped.len() { span.lumped[x] } else { wall_first + span.walls[x - span.lumped.len()] };
            if self.in_block[e] {
                continue;
            }
            let (m, u0) = (self.mu[e], self.u[e]);
            let g = 2.0 * m * u0 / dt - self.force[e] - self.src[e];
            let beta = 2.0 * m / dt + self.r[e];
            let c = if g >= 0.0 { self.cpos[e] } else { self.cneg[e] };
            let disc = beta * beta + 4.0 * c * g.abs();
            if disc < 0.0 {
                self.overwhelmed += 1;
                if !self.overwhelmed_at.iter().any(|x| x.0 == e) && self.overwhelmed_at.len() < 12 {
                    self.overwhelmed_at.push((e, self.u[e], c, beta));
                }
            }
            let um = 2.0 * g / (beta + disc.max(0.0).sqrt());
            self.um[e] = um;
            let u1 = 2.0 * um - u0;
            self.pi[e] = m * u1;
            self.u[e] = u1;
        }
        for &w in &span.radiating {
            self.radiate(w);
        }
    }

    /// A part's branch currents as 2.4's (proceed_time_step_with's `flows`), into its `flows`.
    fn part_currents(&mut self, span: &Span) {
        for &i in &span.currents {
            self.flows[i] = if i < NUM_SECTIONS {
                if i == tube::LOWER_GLOTTIS_SECTION || i == tube::UPPER_GLOTTIS_SECTION || i == tube::FIRST_PHARYNX_SECTION {
                    self.u[self.glottis_edge]
                } else if i >= tube::FIRST_SINUS_SECTION {
                    self.u[self.neck[i - tube::FIRST_SINUS_SECTION]]
                } else {
                    let e = 2 * self.first_element[i];
                    0.5 * (self.u[e] + self.u[e + 1])
                }
            } else {
                let w = (i - NUM_SECTIONS) / 2;
                let e = self.radiating[w].0;
                let out = D[0][2] * self.u[2 * e] + D[1][2] * self.u[2 * e + 1];
                if (i - NUM_SECTIONS) % 2 == 0 {
                    out - self.u[self.radiation[w]]
                } else {
                    self.u[self.radiation[w]]
                }
            };
        }
    }

    /// A part's step ended: its nodes' contents from their inflows, its flows kept, its joins' recoveries.
    fn part_finish(&mut self, span: &Span, k: &TubeCoefficients) {
        let dt = self.time_step;
        std::mem::swap(&mut self.q, &mut self.q_prev);
        for &w in &span.radiating {
            let end = self.radiating[w].1;
            self.acc[end] = 0.0;
            self.f[end] = 0.0;
        }
        for &n in span.nodes.iter().chain(&span.wall_nodes) {
            self.q[n] = self.q_prev[n] + dt * (self.acc[n] - self.f[n]);
        }
        let own = span.elements.clone();
        let wall_first = self.fe_edges + self.walls.first;
        self.used[2 * own.start..2 * own.end].copy_from_slice(&self.u[2 * own.start..2 * own.end]);
        for &e in &span.lumped {
            self.used[e] = self.u[e];
        }
        for &i in &span.walls {
            self.used[wall_first + i] = self.u[wall_first + i];
        }
        std::mem::swap(&mut self.f_prev, &mut self.f);
        self.started = true;
        for &n in &span.joins {
            let jn = self.joins[n];
            let flow_at = |s: &Side| -> f64 {
                if s.count == 1 {
                    self.u[s.edge]
                } else {
                    0.5 * (self.u[s.edge] + self.u[s.edge + 1])
                }
            };
            let (au, ad) = (k.area[jn.up.section].max(MIN_AREA_CM2), k.area[jn.down.section].max(MIN_AREA_CM2));
            let flow = if jn.branch || ad < au { flow_at(&jn.down) } else { flow_at(&jn.up) };
            let (an, aw) = (au.min(ad), au.max(ad));
            let c = self.join_c[n];
            let fraction = if self.borda_carnot { 2.0 * (an / aw) / (1.0 + an / aw) } else { jn.recovery };
            let target = if ad > au && flow > 0.0 {
                -fraction * c * flow * flow
            } else if au > ad && flow < 0.0 {
                fraction * c * flow * flow
            } else {
                0.0
            };
            let reach = if self.reattachment {
                let length = self.join_length[n];
                let held = if fraction * c > 0.0 { (jn.lagged.abs() / (fraction * c)).sqrt() } else { 0.0 };
                if length > 0.0 {
                    1.0 - (-dt * (flow.abs().max(held) / an) / length).exp()
                } else {
                    1.0
                }
            } else {
                1.0
            };
            self.joins[n].lagged += reach * (target - jn.lagged);
        }
    }

    /// Whether it has stepped since it was made or its motion set at rest (a crew is made from a model at rest).
    pub fn has_stepped(&self) -> bool {
        self.started
    }
}

/// The stage `i` of step `s` (LAID ..= FINISHED) counted from the first's first, 1; the step and the stage of one.
#[inline]
fn stage_at(s: u64, i: u64) -> u64 {
    4 * (s - 1) + i
}

#[inline]
fn step_of(g: u64) -> u64 {
    g.div_ceil(4)
}

#[inline]
fn stage_of(g: u64) -> u64 {
    (g - 1) % 4 + 1
}

/// A worker's wait for the next step's record: spun, then slept once it has waited past IDLE (woken by the step that
/// ends it). False once the crew is let go.
fn wait_ready(shared: &Shared, asleep: &AtomicBool, want: u64) -> bool {
    let (mut spins, mut since) = (0u32, None::<Instant>);
    loop {
        if shared.ready.0.load(Ordering::Acquire) >= want {
            return true;
        }
        if shared.stop.load(Ordering::Acquire) {
            return false;
        }
        spins = spins.wrapping_add(1);
        if spins % 256 == 0 && since.get_or_insert_with(Instant::now).elapsed() > IDLE {
            // (said asleep before the count is read again, as the main thread counts before it reads who sleeps)
            asleep.store(true, Ordering::SeqCst);
            if shared.ready.0.load(Ordering::SeqCst) < want && !shared.stop.load(Ordering::SeqCst) {
                std::thread::park();
            }
            asleep.store(false, Ordering::SeqCst);
            since = None;
        }
        std::hint::spin_loop();
    }
}

/// A part's elements' values at its shared nodes posted for the step.
fn post(board: &Post, s: u64, boundary: &[usize], y: &[f64]) {
    // SAFETY: this parity's values are read by none until the count below tells of them (Shared).
    let slot = unsafe { &mut (*board.values.get())[(s & 1) as usize] };
    for (j, &e) in boundary.iter().enumerate() {
        slot[2 * j] = y[2 * e];
        slot[2 * j + 1] = y[2 * e + 1];
    }
    board.done.store(s, Ordering::Release);
}

/// The other parts' elements' values at a part's shared nodes, as they posted them for the step, into `y` (posted:
/// the stage's taker has seen them so, `takeable` or the main thread's `until`).
fn read(shared: &Shared, span: &Span, s: u64, flows: bool, y: &mut [f64]) {
    let post = |q: usize| if flows { &shared.boards[q].x2.0 } else { &shared.boards[q].x1.0 };
    for &(e, q, j) in &span.reads {
        debug_assert!(post(q).done.load(Ordering::Acquire) >= s, "a part's values read before they were posted");
        // SAFETY: posted, and not written again until this part has posted what follows from it.
        let slot = unsafe { &(*post(q).values.get())[(s & 1) as usize] };
        y[2 * e] = slot[2 * j];
        y[2 * e + 1] = slot[2 * j + 1];
    }
}

/// A part's step's first stage: its elements laid, its pressures' terms at its shared nodes posted, its own scattered.
fn laid(m: &mut PassiveModel, span: &Span, k: &TubeCoefficients, shared: &Shared, s: u64) {
    m.part_lay(span, k);
    m.part_hold(span);
    m.part_tmp(span);
    post(&shared.boards[span.part].x1.0, s, &span.boundary, &m.tmp);
    m.part_scatter(span, false);
}

/// Its second, once the parts beside it have posted theirs: their terms read, its pressures corrected.
fn corrected(m: &mut PassiveModel, span: &Span, shared: &Shared, s: u64) {
    read(shared, span, s, false, &mut m.tmp);
    m.part_gather(span, false);
    m.part_force(span);
}

/// Its third, once the step's noise is posted: the noise's sources added, its flows solved and posted, its currents
/// made (`m.flows`; a worker's posted on `currents`), its own flows scattered.
#[allow(clippy::too_many_arguments)]
fn solved(m: &mut PassiveModel, span: &Span, shared: &Shared, s: u64, sources: &[(usize, f64, f64)], lips: f64, currents: Option<&Currents>) {
    m.part_noise(span, sources, lips);
    m.part_solve(span);
    post(&shared.boards[span.part].x2.0, s, &span.boundary, &m.u);
    m.part_currents(span);
    if let Some(board) = currents {
        // SAFETY: as `post`'s.
        let slot = unsafe { &mut (*board.values.get())[(s & 1) as usize] };
        for (j, &i) in span.currents.iter().enumerate() {
            slot[j] = m.flows[i];
        }
        board.done.store(s, Ordering::Release);
    }
    m.part_scatter(span, true);
}

/// Its last, once the parts beside it have posted their flows: theirs read, its nodes stepped, its outputs posted.
fn finished(m: &mut PassiveModel, span: &Span, k: &TubeCoefficients, shared: &Shared, s: u64, kept: &mut [f64]) {
    read(shared, span, s, true, &mut m.u);
    m.part_gather(span, true);
    m.part_finish(span, k);
    outputs(m, span, shared, s, kept);
}

/// A part's outputs at the step posted, its skin's walls' flows kept (`kept`, RING steps of them), and its skin summed
/// on the part's before as many steps behind as it is parts from the first.
fn outputs(m: &PassiveModel, span: &Span, shared: &Shared, s: u64, kept: &mut [f64]) {
    let out = &shared.boards[span.part].outputs.0;
    let slot = (s as usize) % RING;
    for &w in &span.radiating {
        let e = m.radiating[w].0;
        let v = D[0][2] * m.u[2 * e] + D[1][2] * m.u[2 * e + 1];
        // SAFETY: as `post`'s, RING steps of them.
        unsafe {
            if w == 0 {
                (*out.mouth.get())[slot] = v;
            } else {
                (*out.nostrils.get())[slot] = v;
            }
        }
    }
    out.done.store(s, Ordering::Release);
    let n = span.skin.len();
    for (j, &e) in span.skin.iter().enumerate() {
        kept[slot * n + j] = m.u[e];
    }
    let lag = span.part as u64;
    if s > lag {
        sum_skin(m.noise.options.radiation_from_skin, span, shared, s - lag, kept);
    }
}

/// A part's skin summed at step `t` (once): the part's before's sum, then its walls' flows in the nodes' order -- the
/// skin's sum on one core, part after part.
fn sum_skin(on: bool, span: &Span, shared: &Shared, t: u64, kept: &[f64]) {
    let out = &shared.boards[span.part].outputs.0;
    if out.summed.load(Ordering::Relaxed) >= t {
        return;
    }
    let slot = (t as usize) % RING;
    let mut skin = if span.part == 0 {
        0.0
    } else {
        let before = &shared.boards[span.part - 1].outputs.0;
        debug_assert!(before.summed.load(Ordering::Acquire) >= t, "a part's skin summed before the part before's");
        // SAFETY: summed (the stage's taker has seen it so: `takeable`), and not written again for RING steps.
        unsafe { (*before.skin.get())[slot] }
    };
    if on {
        let n = span.skin.len();
        for &v in &kept[slot * n..(slot + 1) * n] {
            skin += v;
        }
    }
    // SAFETY: as `post`'s.
    unsafe {
        (*out.skin.get())[slot] = skin;
    }
    out.summed.store(t, Ordering::Release);
}

/// A crew let go should a part's stage panic, on its worker or where the main thread steps it, so that the threads
/// waiting on what it would have posted end in their turn -- a worker returning, the main thread unwinding (`until`) --
/// rather than spin for ever: the panic's own message said by its thread.
struct LetGo<'a>(&'a Shared);

impl Drop for LetGo<'_> {
    fn drop(&mut self) {
        if std::thread::panicking() {
            self.0.stop.store(true, Ordering::SeqCst);
        }
    }
}

/// Whether worker part `p`'s stage `g`, its stage before done, can be taken: all it reads posted -- for its first, the
/// step's record; its second, the terms of the parts beside it; its third, the step's noise; its last, their flows and
/// the part before's skin summed as far as its own sum reads it (to the call's last step, at that step).
fn takeable(shared: &Shared, spans: &[Span], p: usize, g: u64) -> bool {
    let (s, span, boards) = (step_of(g), &spans[p], &shared.boards);
    match stage_of(g) {
        LAID => shared.ready.0.load(Ordering::Acquire) >= s,
        CORRECTED => span.beside.iter().all(|&q| boards[q].x1.0.done.load(Ordering::Acquire) >= s),
        SOLVED => shared.noise.0.done.load(Ordering::Acquire) >= s,
        _ => {
            let summed = if s == shared.last.0.load(Ordering::Acquire) { s } else { s.saturating_sub(p as u64) };
            span.beside.iter().all(|&q| boards[q].x2.0.done.load(Ordering::Acquire) >= s)
                && boards[p - 1].outputs.0.summed.load(Ordering::Acquire) >= summed
        }
    }
}

/// Worker part `p`'s stage `g` in its seat, its skin's last steps summed at the call's last.
///
/// # Safety
/// Taken by the calling thread alone (`Turn::taken`), its stage before done (`Turn::staged`), and `takeable`.
unsafe fn stage(shared: &Shared, spans: &[Span], p: usize, g: u64) {
    let (span, s) = (&spans[p], step_of(g));
    let seat = &mut *shared.seats[p - 1].0.get();
    // (Written before `ready` told of it, and not again until every part is done with it: RECORDS.)
    let k = &(*shared.records[(s as usize) % RECORDS].get()).tube;
    match stage_of(g) {
        LAID => laid(&mut seat.m, span, k, shared, s),
        CORRECTED => corrected(&mut seat.m, span, shared, s),
        SOLVED => {
            // (Posted, and not written again until every part has solved its flows: Shared.)
            let sources = &(*shared.noise.0.slots.get())[(s & 1) as usize];
            solved(&mut seat.m, span, shared, s, &sources.terms[..sources.n], sources.lips, Some(&shared.boards[p].currents.0));
        }
        _ => {
            finished(&mut seat.m, span, k, shared, s, &mut seat.kept);
            if s == shared.last.0.load(Ordering::Acquire) {
                let from = shared.boards[p].outputs.0.summed.load(Ordering::Relaxed) + 1;
                for t in from..=s {
                    sum_skin(seat.m.noise.options.radiation_from_skin, span, shared, t, &seat.kept);
                }
            }
        }
    }
}

/// A worker's thread: its part's stages in turn, each taken as soon as it can be -- where the main thread has not taken
/// it first, which it then waits out --, and between calls the next step's record waited for (`wait_ready`).
fn worker(shared: &Shared, spans: &[Span], p: usize) {
    let _let_go = LetGo(shared);
    let (turn, asleep) = (&shared.boards[p].turn.0, &shared.boards[p].asleep.0);
    let mut spins = 0u32;
    loop {
        let g = turn.staged.load(Ordering::Acquire) + 1;
        if shared.ready.0.load(Ordering::Acquire) < step_of(g) {
            if !wait_ready(shared, asleep, step_of(g)) {
                return;
            }
        } else if turn.taken.load(Ordering::Relaxed) < g && takeable(shared, spans, p, g) && turn.taken.fetch_max(g, Ordering::AcqRel) < g {
            if turn.late.load(Ordering::Relaxed) {
                turn.late.store(false, Ordering::Relaxed);
            }
            // SAFETY: taken here alone, its stage before done, and takeable.
            unsafe { stage(shared, spans, p, g) };
            turn.staged.store(g, Ordering::Release);
        } else {
            // (the core yielded now and then, where the machine has more threads than cores)
            spins = spins.wrapping_add(1);
            if spins & 0xfff == 0 {
                if shared.stop.load(Ordering::Acquire) {
                    return;
                }
                std::thread::yield_now();
            } else {
                std::hint::spin_loop();
            }
        }
    }
}

/// A count the main thread waits for, to `want`: meanwhile, every 32 spins, what of each worker's part it can take to
/// stage `upto` stepped here where its worker sleeps or has left it untaken (`help`). Never yielding its core, as the
/// winds' crew's main thread never does: every part waits on it. Unwinds once its crew is let go (`LetGo`; no panic's
/// message: nothing went wrong in it), so that the crew's Drop can join its workers.
fn until(shared: &Shared, spans: &[Span], count: &AtomicU64, want: u64, upto: u64) {
    let mut spins = 0u32;
    // (each worker's part's next stage as this wait first saw it takeable and untaken, and the spin it saw it at)
    let mut seen = [(0u64, 0u32); RING];
    while count.load(Ordering::Acquire) < want {
        spins = spins.wrapping_add(1);
        if spins % 32 == 0 {
            if shared.stop.load(Ordering::Acquire) {
                std::panic::resume_unwind(Box::new("the crew let go"));
            }
            if let Some(after) = shared.help {
                help(shared, spans, upto, after, spins, &mut seen);
            }
        }
        std::hint::spin_loop();
    }
}

/// Each worker's part's stages to `upto`, each as it can be taken, stepped here -- each taken first -- where its
/// worker sleeps, or has left a stage untaken `after` spins of this wait (`seen`): a worker awake and on its core takes
/// a stage it can within a few of them, so that one which has not is off its core, and its part's stages are stepped
/// here as they can be until it takes one again (`Turn::late`).
fn help(shared: &Shared, spans: &[Span], upto: u64, after: u32, spins: u32, seen: &mut [(u64, u32)]) {
    for p in 1..spans.len() {
        let boards = &shared.boards[p];
        let turn = &boards.turn.0;
        let mut late = after == 0 || boards.asleep.0.load(Ordering::Relaxed) || turn.late.load(Ordering::Relaxed);
        loop {
            let g = turn.staged.load(Ordering::Acquire) + 1;
            if g > upto || turn.taken.load(Ordering::Relaxed) >= g || !takeable(shared, spans, p, g) {
                break;
            }
            if !late {
                if seen[p].0 != g {
                    seen[p] = (g, spins);
                    break;
                }
                if spins.wrapping_sub(seen[p].1) < after {
                    break;
                }
                late = true;
                turn.late.store(true, Ordering::Relaxed);
            }
            if turn.taken.fetch_max(g, Ordering::AcqRel) >= g {
                break;
            }
            let _let_go = LetGo(shared);
            // SAFETY: taken here alone, its stage before done, and takeable.
            unsafe { stage(shared, spans, p, g) };
            turn.staged.store(g, Ordering::Release);
            shared.helped.0.fetch_add(1, Ordering::Relaxed);
        }
    }
}

/// VocalWind's network stepped on several cores: the main thread's part (the trachea, the glottis, the pharynx's first)
/// stepped in the main thread's model, each other part on a thread of its own in a copy -- or by the main thread where
/// it waits on it and its thread is late (`help`) --, and the steps' totals as they come.
pub struct Crew {
    shared: Arc<Shared>,
    workers: Vec<JoinHandle<()>>,
    spans: Arc<Vec<Span>>,
    // (The steps stepped; the call's first; the last step whose flows the noise has taken; the call's totals; a step's
    // noise's sources; the main thread's part's skin's flows kept.)
    n: u64,
    first: u64,
    fed: u64,
    totals: Vec<f64>,
    sources: Vec<(usize, f64, f64)>,
    kept: Vec<f64>,
}

impl Crew {
    /// The model `main` -- at rest, and with neither the thermal layer nor the energy's account -- stepped in `parts`
    /// parts, the main thread's own work a step `main_cost` beside its part (MAIN_COST, MAIN_COST_WITH_TUBE). The
    /// calling thread, which steps the first part, is asked onto the performance cores with its workers: the parts are cut
    /// even for cores alike, and one part on an efficiency core paces them all (a loaded Mac moves a thread of default
    /// service there; measured 14 November 2026, research/VOCAL_TRACT_REALTIME_PLAN.md 6).
    pub fn new(main: &PassiveModel, parts: usize, main_cost: f64) -> Crew {
        assert!(!main.thermal_layer && main.account.is_none(), "the thermal layer and the energy's account step on one core");
        assert!(!main.started, "a crew is made from a model at rest");
        crate::counters::prefer_performance_cores();
        // (Fewer parts than RING: a step's outputs are read as many steps late as there are parts, and kept RING steps.)
        let spans = Arc::new(spans(main, parts.min(RING - 1), main_cost));
        let parts = spans.len();
        let boards = (0..parts)
            .map(|_| Boards {
                x1: Line(Post { done: AtomicU64::new(0), values: UnsafeCell::new([[0.0; 2 * BOUNDARY]; 2]) }),
                x2: Line(Post { done: AtomicU64::new(0), values: UnsafeCell::new([[0.0; 2 * BOUNDARY]; 2]) }),
                currents: Line(Currents { done: AtomicU64::new(0), values: UnsafeCell::new([[0.0; CURRENTS]; 2]) }),
                outputs: Line(Outputs {
                    done: AtomicU64::new(0),
                    summed: AtomicU64::new(0),
                    mouth: UnsafeCell::new([0.0; RING]),
                    nostrils: UnsafeCell::new([0.0; RING]),
                    skin: UnsafeCell::new([0.0; RING]),
                }),
                asleep: Line(AtomicBool::new(false)),
                turn: Line(Turn { taken: AtomicU64::new(0), staged: AtomicU64::new(0), late: AtomicBool::new(false) }),
            })
            .collect();
        let empty = Sources { n: 0, terms: [(0, 0.0, 0.0); SOURCES], lips: 0.0 };
        let shared = Arc::new(Shared {
            ready: Line(AtomicU64::new(0)),
            last: Line(AtomicU64::new(0)),
            stop: AtomicBool::new(false),
            noise: Line(Noise { done: AtomicU64::new(0), slots: UnsafeCell::new([empty; 2]) }),
            boards,
            records: (0..RECORDS).map(|_| UnsafeCell::new(StepRecord::default())).collect(),
            seats: (1..parts).map(|p| Line(UnsafeCell::new(Seat { m: main.clone(), kept: vec![0.0; RING * spans[p].skin.len()] }))).collect(),
            help: main.help,
            helped: Line(AtomicU64::new(0)),
        });
        let workers = (1..parts)
            .map(|p| {
                let (shared, spans) = (Arc::clone(&shared), Arc::clone(&spans));
                std::thread::Builder::new()
                    .name(format!("vocalwind part {p}"))
                    .spawn(move || {
                        crate::counters::prefer_performance_cores();
                        worker(&shared, &spans, p)
                    })
                    .expect("a thread for a part of the network")
            })
            .collect();
        let kept = vec![0.0; RING * spans[0].skin.len()];
        Crew { shared, workers, spans, n: 0, first: 1, fed: 0, totals: Vec::new(), sources: Vec::with_capacity(SOURCES), kept }
    }

    /// Its parts: each one's elements and its cost a step (the main thread's work counted in the first's).
    pub fn parts(&self) -> Vec<(Range<usize>, f64)> {
        self.spans.iter().map(|s| (s.elements.clone(), s.cost)).collect()
    }

    /// The stages of its workers' parts the main thread has stepped (`help`), and theirs all, since it was made.
    pub fn helped(&self) -> (u64, u64) {
        (self.shared.helped.0.load(Ordering::Relaxed), 4 * self.n * (self.spans.len() as u64 - 1))
    }

    /// A call of `steps` steps begins.
    pub fn begin(&mut self, steps: usize) {
        self.first = self.n + 1;
        self.totals.clear();
        self.totals.resize(steps, 0.0);
        self.shared.last.0.store(self.n + steps as u64, Ordering::Release);
    }

    /// The next step's record, to be made (Stepper::step) or copied in before `step`.
    pub fn record(&mut self) -> &mut StepRecord {
        // SAFETY: every part is done with the record this slot held (RECORDS steps back), and none reads it until
        // `step` tells of it.
        unsafe { &mut *self.shared.records[((self.n + 1) as usize) % RECORDS].get() }
    }

    /// One step from its record (`record`), the glottis's sections and the lungs' pressure set on the main thread's
    /// model `main`.
    pub fn step(&mut self, main: &mut PassiveModel) {
        let s = self.n + 1;
        let (shared, spans) = (&*self.shared, &self.spans[..]);
        shared.ready.0.store(s, Ordering::SeqCst);
        for (w, b) in shared.boards[1..].iter().enumerate() {
            if b.asleep.0.load(Ordering::SeqCst) {
                self.workers[w].thread().unpark();
            }
        }
        // SAFETY: written before `ready` told of it.
        let k = unsafe { &(*shared.records[(s as usize) % RECORDS].get()).tube };
        // the noise, as one core steps it: from every part's flows a step before, for every part to add before it
        // solves its own
        if self.fed + 1 < s {
            Self::take(shared, spans, main, s - 1);
            self.fed = s - 1;
        }
        main.noise.step_noise(k);
        self.sources.clear();
        for i in tube::FIRST_PHARYNX_SECTION..=tube::LAST_NOSE_SECTION {
            let (monopole, dipole) = main.noise.noise_source(i);
            if monopole != 0.0 || dipole != 0.0 {
                self.sources.push((i, monopole, dipole));
            }
        }
        let lips = main.noise.noise_source(NUM_SECTIONS).1;
        {
            let noise = &shared.noise.0;
            // SAFETY: every part has read this parity's sources of two steps back (it solved its flows since).
            let slot = unsafe { &mut (*noise.slots.get())[(s & 1) as usize] };
            slot.n = self.sources.len();
            slot.terms[..slot.n].copy_from_slice(&self.sources);
            slot.lips = lips;
            noise.done.store(s, Ordering::Release);
        }
        // its own part's stages, each once the parts beside it have posted what it reads
        let span = &spans[0];
        laid(main, span, k, shared, s);
        for &q in &span.beside {
            until(shared, spans, &shared.boards[q].x1.0.done, s, stage_at(s, LAID));
        }
        corrected(main, span, shared, s);
        solved(main, span, shared, s, &self.sources, lips, None);
        for &q in &span.beside {
            until(shared, spans, &shared.boards[q].x2.0.done, s, stage_at(s, SOLVED));
        }
        finished(main, span, k, shared, s, &mut self.kept);
        let parts = spans.len() as u64;
        if s > parts && s - parts >= self.first {
            // (the last part's skin summed to it at its step before this)
            self.totals[(s - parts - self.first) as usize] = Self::total(shared, spans, s - parts, stage_at(s - 1, FINISHED));
        }
        self.n = s;
    }

    /// The noise given every part's flows at step `t` (the main thread's own already in its `flows`).
    fn take(shared: &Shared, spans: &[Span], main: &mut PassiveModel, t: u64) {
        for p in 1..spans.len() {
            let board = &shared.boards[p].currents.0;
            until(shared, spans, &board.done, t, stage_at(t, SOLVED));
            // SAFETY: posted, and not written again until the noise this takes them for is posted.
            let slot = unsafe { &(*board.values.get())[(t & 1) as usize] };
            for (j, &i) in spans[p].currents.iter().enumerate() {
                main.flows[i] = slot[j];
            }
        }
        main.noise.take_flows(&main.flows);
    }

    /// Step `t`'s total radiated, as one core sums it: the mouth's, the nostrils', the skin's (the main thread helping
    /// its crew to stage `upto` while it waits on them).
    fn total(shared: &Shared, spans: &[Span], t: u64, upto: u64) -> f64 {
        let slot = (t as usize) % RING;
        let mut out = [0.0; 2];
        for (p, span) in spans.iter().enumerate() {
            let board = &shared.boards[p].outputs.0;
            for &w in &span.radiating {
                until(shared, spans, &board.done, t, upto);
                // SAFETY: posted, and not written again for RING steps.
                out[w] = unsafe { if w == 0 { (*board.mouth.get())[slot] } else { (*board.nostrils.get())[slot] } };
            }
        }
        let last = &shared.boards[spans.len() - 1].outputs.0;
        until(shared, spans, &last.summed, t, upto);
        // SAFETY: as above.
        let skin = unsafe { (*last.skin.get())[slot] };
        out[0] + out[1] + skin
    }

    /// The call's totals, a step's each, into `totals` once every part is done with them; the noise given the last
    /// step's flows.
    pub fn finish(&mut self, main: &mut PassiveModel, totals: &mut Vec<f64>) {
        let s = self.n;
        let (shared, spans) = (&*self.shared, &self.spans[..]);
        let from = self.first.max((s + 1).saturating_sub(spans.len() as u64));
        for t in from..=s {
            self.totals[(t - self.first) as usize] = Self::total(shared, spans, t, stage_at(s, FINISHED));
        }
        if self.fed < s {
            Self::take(shared, spans, main, s);
            self.fed = s;
        }
        std::mem::swap(&mut self.totals, totals);
    }

    /// The whole network's state as one core holds it, into the main thread's model (between calls): each worker's
    /// part's nodes' contents and pressures, its edges' flows and momenta, its joins' recoveries.
    pub fn gather(&self, main: &mut PassiveModel) {
        let (fe, wall_first) = (main.fe_edges, main.fe_edges + main.walls.first);
        for p in 1..self.spans.len() {
            let span = &self.spans[p];
            // SAFETY: between calls, every stage of its part done (its skin's last sums read in `finish`).
            let m = unsafe { &(*self.shared.seats[p - 1].0.get()).m };
            for &n in span.nodes.iter().chain(&span.wall_nodes) {
                main.q[n] = m.q[n];
                main.q_prev[n] = m.q_prev[n];
                main.p[n] = m.p[n];
                main.pt[n] = m.pt[n];
            }
            let own = span.elements.clone();
            for e in (2 * own.start..2 * own.end).chain(span.lumped.iter().copied()).chain(span.walls.iter().map(|&i| wall_first + i)) {
                main.u[e] = m.u[e];
                main.pi[e] = m.pi[e];
                main.used[e] = m.used[e];
                main.um[e] = m.um[e];
                if e < fe {
                    main.vmom[e] = m.vmom[e];
                    main.vflow[e] = m.vflow[e];
                }
            }
            for &j in &span.joins {
                main.joins[j].lagged = m.joins[j].lagged;
            }
        }
    }
}

impl Drop for Crew {
    fn drop(&mut self) {
        self.shared.stop.store(true, Ordering::SeqCst);
        for w in &self.workers {
            w.thread().unpark();
        }
        for w in self.workers.drain(..) {
            let _ = w.join();
        }
    }
}
