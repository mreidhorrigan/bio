// VocalWind's network in frequency (research/VOCALWIND_BOUNDARY_LAYER.md, "The network in frequency"): the engine's own
// network as `lay` lays it for a still tube -- its elements' masses and compliances, the ducts' loss branches, the walls,
// the sinuses, the glottis as its sections stand, the radiation -- answering a flow put into the pharynx's first node at
// a complex frequency s: with its time derivative as s (Stepping::Continuous), or as the step takes it at the model's own
// rate (Stepping::Stepped: the corrected leapfrog, the centred resistances and the thermal branches' implicit midpoint,
// in z = e^(s dt)), which is the stepped response itself, the step's error and all. The owner, 14 November 2026, of its
// design (the engine's own network solved at each frequency, its equations and not a second model's): "Yes, build the
// frequency-domain solver, then continue with the optimization." A small signal's, as a transfer function is: the jets'
// terms (Bernoulli's drops and recoveries), quadratic in the flow, take no part, nor the noise.
//   The flows come out edge by edge -- each edge's flow its drive over its impedance, the radiating ends' three edges
// together as `radiate` solves them -- leaving the nodes' pressures P:
//     (D sigma + (B^T Z^-1 B + Phi) C) P = (1 + z^-1)/2 Q,
// D each node's implicit compliance (`own`), C the step's correction (I - dt^2/12 D^-1 B^T M_u^-1 B, `correct`), Phi its
// thermal branches' answer and Q the flow put in. Continuous: D = M_p, C = I, (1 + z^-1)/2 = 1, sigma = s, every
// impedance and admittance at s. Stepped: sigma = sinh(s dt)/dt (the leapfrog's), every edge's impedance at
// s~ = (2/dt) tanh(s dt/2) (the centred step's, its branches' too), Phi = cosh^2(s dt/2) sum (Y(s~) - y) + (1 + z^-1)/2
// sum y over the node's thermal shares (y a share's instantaneous answer in its implicit midpoint), and the flows out
// 2/(1 + z^-1) times their centred values. The unknowns numbered in reverse Cuthill-McKee order, which bands them;
// solved by Gaussian elimination with partial pivoting within the band.
use super::{PassiveModel, ATMOSPHERE, D, DIFFUSIVE_A, DIFFUSIVE_A0, DIFFUSIVE_B, DIFFUSIVE_N, LUNGS, NONE};
use crate::v24::tds::TubeCoefficients;
use std::collections::BTreeMap;
use std::f64::consts::PI;
use std::ops::{Add, AddAssign, Div, Mul, Neg, Sub, SubAssign};

/// A complex number: a frequency (rad/s) or a response.
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct Complex {
    pub re: f64,
    pub im: f64,
}

impl Complex {
    pub const ZERO: Complex = Complex { re: 0.0, im: 0.0 };
    pub const ONE: Complex = Complex { re: 1.0, im: 0.0 };

    pub const fn new(re: f64, im: f64) -> Complex {
        Complex { re, im }
    }

    /// A steady tone's frequency, j 2 pi f (rad/s), of `hz`.
    pub fn tone(hz: f64) -> Complex {
        Complex::new(0.0, 2.0 * PI * hz)
    }

    /// The pole of a resonance at `hz`, `width_hz` wide: -pi b + j 2 pi f.
    pub fn resonance(hz: f64, width_hz: f64) -> Complex {
        Complex::new(-PI * width_hz, 2.0 * PI * hz)
    }

    /// A pole's frequency and bandwidth (Hz).
    pub fn frequency_and_bandwidth(self) -> (f64, f64) {
        (self.im / (2.0 * PI), -self.re / PI)
    }

    pub fn abs(self) -> f64 {
        self.re.hypot(self.im)
    }

    pub fn recip(self) -> Complex {
        let d = self.re * self.re + self.im * self.im;
        Complex::new(self.re / d, -self.im / d)
    }

    pub fn exp(self) -> Complex {
        let m = self.re.exp();
        Complex::new(m * self.im.cos(), m * self.im.sin())
    }

    fn sinh(self) -> Complex {
        Complex::new(self.re.sinh() * self.im.cos(), self.re.cosh() * self.im.sin())
    }

    fn cosh(self) -> Complex {
        Complex::new(self.re.cosh() * self.im.cos(), self.re.sinh() * self.im.sin())
    }

    fn tanh(self) -> Complex {
        let (a, b) = (2.0 * self.re, 2.0 * self.im);
        let d = a.cosh() + b.cos();
        Complex::new(a.sinh() / d, b.sin() / d)
    }
}

impl Add for Complex {
    type Output = Complex;
    fn add(self, o: Complex) -> Complex {
        Complex::new(self.re + o.re, self.im + o.im)
    }
}

impl Sub for Complex {
    type Output = Complex;
    fn sub(self, o: Complex) -> Complex {
        Complex::new(self.re - o.re, self.im - o.im)
    }
}

impl Mul for Complex {
    type Output = Complex;
    fn mul(self, o: Complex) -> Complex {
        Complex::new(self.re * o.re - self.im * o.im, self.re * o.im + self.im * o.re)
    }
}

impl Mul<f64> for Complex {
    type Output = Complex;
    fn mul(self, o: f64) -> Complex {
        Complex::new(self.re * o, self.im * o)
    }
}

impl Div for Complex {
    type Output = Complex;
    fn div(self, o: Complex) -> Complex {
        self * o.recip()
    }
}

impl Neg for Complex {
    type Output = Complex;
    fn neg(self) -> Complex {
        Complex::new(-self.re, -self.im)
    }
}

impl AddAssign for Complex {
    fn add_assign(&mut self, o: Complex) {
        *self = *self + o;
    }
}

impl SubAssign for Complex {
    fn sub_assign(&mut self, o: Complex) {
        *self = *self - o;
    }
}

/// A response with d/dt as s, or the step's own at the model's rate.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Stepping {
    Continuous,
    Stepped,
}

/// The network's answer to a unit flow put into the pharynx's first node (cm^3/s, the glottis shut as its sections
/// stand): the lips' and the nostrils' flows out (the volume velocity's transfer, as vocalfork_transfer records the
/// lips'), and that node's pressure (dPa: the impedance the glottis sees, dPa s/cm^3; stepped, for the flow put in
/// centred on the pressure's instant, where a step's flow is put in over the step: 2/(1 + z^-1) times the pressure the
/// step answers it with).
#[derive(Clone, Copy, Debug)]
pub struct Response {
    pub mouth: Complex,
    pub nostrils: Complex,
    pub inlet: Complex,
}

/// An edge as laid: the unknowns it joins with B's coefficients, its inertance and resistance, and its viscous branches
/// (each a resistance and an inertance in parallel: `viscous_layer`).
#[derive(Clone, Debug)]
struct Laid {
    at: Vec<(usize, f64)>,
    mu: f64,
    r: f64,
    branches: Vec<(f64, f64)>,
}

impl Laid {
    fn impedance(&self, s: Complex) -> Complex {
        let mut z = s * self.mu + Complex::new(self.r, 0.0);
        for &(r, l) in &self.branches {
            let ls = s * l;
            z += ls * r / (ls + Complex::new(r, 0.0));
        }
        z
    }
}

/// A radiating end's three edges, solved together (`radiate`): its element's two flows and the radiation's inductance,
/// the radiation's resistance R [d; -1][d; -1]^T across them.
#[derive(Clone, Debug)]
struct Radiating {
    flows: [Laid; 2],
    d: [f64; 2],
    resistance: f64,
    inductance: f64,
}

impl Radiating {
    /// Its three edges' matrix at s, inverted (the first two rows and columns are its element's flows').
    fn inverse(&self, s: Complex) -> [[Complex; 3]; 3] {
        let d = [self.d[0], self.d[1], -1.0];
        let mut a = [[Complex::ZERO; 3]; 3];
        for i in 0..3 {
            for j in 0..3 {
                a[i][j] = Complex::new(self.resistance * d[i] * d[j], 0.0);
            }
        }
        a[0][0] += self.flows[0].impedance(s);
        a[1][1] += self.flows[1].impedance(s);
        a[2][2] += s * self.inductance;
        // (by cofactors, the indices taken cyclically: their signs come with them)
        let cofactor = |i: usize, j: usize| {
            let (i1, i2, j1, j2) = ((i + 1) % 3, (i + 2) % 3, (j + 1) % 3, (j + 2) % 3);
            a[i1][j1] * a[i2][j2] - a[i1][j2] * a[i2][j1]
        };
        let det = a[0][0] * cofactor(0, 0) + a[0][1] * cofactor(0, 1) + a[0][2] * cofactor(0, 2);
        let mut inverse = [[Complex::ZERO; 3]; 3];
        for i in 0..3 {
            for j in 0..3 {
                inverse[i][j] = cofactor(j, i) / det;
            }
        }
        inverse
    }
}

/// A node's thermal share as laid (`thermal_layer`): its isothermal excess c_0, its conductances' unit and its implicit
/// midpoint's instantaneous answer y.
#[derive(Clone, Copy, Debug)]
struct Share {
    c0: f64,
    unit: f64,
    y: f64,
}

impl Share {
    /// Its admittance at s: c_0 in series with g_0 beside the branches g_i -- c_i in series (OpenWInD's, as `lay`
    /// lays them: g_0 = unit a_0, g_i = unit a_i / b_i, c_i = c_0 a_i).
    fn admittance(&self, s: Complex) -> Complex {
        let mut g = Complex::new(self.unit * DIFFUSIVE_A0, 0.0);
        for i in 0..DIFFUSIVE_N {
            let (gi, ci) = (self.unit * DIFFUSIVE_A[i] / DIFFUSIVE_B[i], self.c0 * DIFFUSIVE_A[i]);
            g += (Complex::new(1.0 / gi, 0.0) + (s * ci).recip()).recip();
        }
        ((s * self.c0).recip() + g.recip()).recip()
    }
}

/// The network a still tube lays, for its response in frequency (PassiveModel::network).
#[derive(Clone, Debug)]
pub struct Network {
    dt: f64,
    /// Each unknown's compliance and implicit compliance (`own`), and its thermal shares.
    mp: Vec<f64>,
    own: Vec<f64>,
    shares: Vec<Vec<Share>>,
    /// The edges but the radiating ends', and the radiating ends (the mouth's, the nostrils').
    edges: Vec<Laid>,
    ends: [Radiating; 2],
    /// The step's correction, row by row: (unknown, coefficient).
    correction: Vec<Vec<(usize, f64)>>,
    /// The bands: continuous, unknowns an edge apart share a row; stepped, two edges apart (through the correction).
    /// And the pharynx's first node's unknown.
    bands: [usize; 2],
    inlet: usize,
}

impl PassiveModel {
    /// The network the still tube `k` lays, with the glottis's sections as set, for its response in frequency
    /// (Network::response): laid as a step lays it, the model's motion left as it was.
    pub fn network(&mut self, k: &TubeCoefficients) -> Network {
        let (vol_prev, glottis_volume, started) = (self.vol_prev.clone(), self.glottis_volume, self.started);
        self.started = false;
        self.lay(k, None);
        (self.vol_prev, self.glottis_volume, self.started) = (vol_prev, glottis_volume, started);
        let dt = self.time_step;
        let n_nodes = self.mp.len();
        // (the lungs' node is held, the radiating ends hold no air: neither is an unknown)
        let mut free = vec![true; n_nodes];
        free[LUNGS] = false;
        for &(_, end) in &self.radiating {
            free[end] = false;
        }
        // each edge's nodes and B's coefficients (`apply_b`), the held left out
        let fe = self.fe_edges;
        let rows: Vec<Vec<(usize, f64)>> = (0..self.u.len())
            .map(|e| {
                let mut at = Vec::with_capacity(3);
                if e < fe {
                    let el = self.elements[e / 2];
                    for m in 0..3 {
                        at.push((el.nodes[m], D[e % 2][m]));
                    }
                } else {
                    let edge = self.edges[e - fe];
                    if edge.to != ATMOSPHERE {
                        at.push((edge.to, 1.0));
                    }
                    at.push((edge.from, -1.0));
                }
                at.retain(|&(node, _)| free[node]);
                at
            })
            .collect();
        // the unknowns, numbered in reverse Cuthill-McKee order on the graph of the nodes the edges join
        let nodes: Vec<usize> = (0..n_nodes).filter(|&v| free[v]).collect();
        let mut local = vec![NONE; n_nodes];
        for (i, &v) in nodes.iter().enumerate() {
            local[v] = i;
        }
        let mut graph = vec![Vec::new(); nodes.len()];
        for row in &rows {
            for &(a, _) in row {
                for &(b, _) in row {
                    if a != b {
                        graph[local[a]].push(local[b]);
                    }
                }
            }
        }
        for g in graph.iter_mut() {
            g.sort_unstable();
            g.dedup();
        }
        let mut unknown = vec![NONE; n_nodes];
        for (place, &i) in reverse_cuthill_mckee(&graph).iter().enumerate() {
            unknown[nodes[i]] = place;
        }
        let n = nodes.len();
        let renumber = |row: &[(usize, f64)]| -> Vec<(usize, f64)> { row.iter().map(|&(v, c)| (unknown[v], c)).collect() };
        // each unknown's compliances and thermal shares
        let (mut mp, mut own) = (vec![0.0; n], vec![0.0; n]);
        for &v in &nodes {
            mp[unknown[v]] = self.mp[v];
            own[unknown[v]] = self.own[v];
        }
        let mut shares = vec![Vec::new(); n];
        if self.thermal_layer {
            for (e, el) in self.elements.iter().enumerate() {
                for m in 0..3 {
                    let share = 3 * e + m;
                    if self.ty[share] != 0.0 {
                        shares[unknown[el.nodes[m]]].push(Share { c0: self.tc0[share], unit: self.tunit[share], y: self.ty[share] });
                    }
                }
            }
        }
        // the edges, the radiating ends' apart
        let laid = |e: usize| -> Laid {
            let branches = if self.viscous_layer && e < fe { (0..DIFFUSIVE_N).map(|i| (self.vr[e][i], self.vl[e][i])).collect() } else { Vec::new() };
            Laid { at: renumber(&rows[e]), mu: self.mu[e], r: self.r[e], branches }
        };
        let edges = (0..self.u.len()).filter(|&e| !self.in_block[e]).map(|e| laid(e)).collect();
        let ends = [0, 1].map(|w| {
            let (el, _) = self.radiating[w];
            Radiating { flows: [laid(2 * el), laid(2 * el + 1)], d: [D[0][2], D[1][2]], resistance: self.resistance[w], inductance: self.mu[self.radiation[w]] }
        });
        // the step's correction, every edge in it (`correct`)
        let mut c: Vec<BTreeMap<usize, f64>> = (0..n).map(|a| BTreeMap::from([(a, 1.0)])).collect();
        for (e, row) in rows.iter().enumerate() {
            for &(va, ca) in row {
                let a = unknown[va];
                for &(vb, cb) in row {
                    *c[a].entry(unknown[vb]).or_insert(0.0) -= dt * dt / 12.0 * ca * cb / (self.mu[e] * own[a]);
                }
            }
        }
        let correction: Vec<Vec<(usize, f64)>> = c.into_iter().map(|m| m.into_iter().collect()).collect();
        let mut bands = [0, 0];
        for row in &rows {
            for &(a, _) in row {
                for &(b, _) in row {
                    bands[0] = bands[0].max(unknown[a].abs_diff(unknown[b]));
                }
            }
        }
        for a in 0..n {
            for &(b, _) in &correction[a] {
                for &(far, _) in &correction[b] {
                    bands[1] = bands[1].max(a.abs_diff(far));
                }
            }
        }
        Network { dt, mp, own, shares, edges, ends, correction, bands, inlet: unknown[self.pharynx_bottom] }
    }
}

impl Network {
    /// Its unknowns (the nodes' pressures, the held left out) and the bands they are solved in, continuous and stepped.
    pub fn size(&self) -> (usize, [usize; 2]) {
        (self.mp.len(), self.bands)
    }

    /// Its response at the complex frequency `s` (rad/s; Complex::tone for a steady tone).
    pub fn response(&self, s: Complex, stepping: Stepping) -> Response {
        let n = self.mp.len();
        let stepped = stepping == Stepping::Stepped;
        // what each part sees of s: the edges (the centred step's frequency), the nodes (the leapfrog's), the flow put
        // in (its share at the step's start), and the thermal branches' weight
        let (edge_s, node_s, half, both) = if stepped {
            let x = s * self.dt;
            let c = (x * 0.5).cosh();
            ((x * 0.5).tanh() * (2.0 / self.dt), x.sinh() * (1.0 / self.dt), (Complex::ONE + (-x).exp()) * 0.5, c * c)
        } else {
            (s, s, Complex::ONE, Complex::ONE)
        };
        let mut k = Band::new(n, self.bands[stepped as usize]);
        // (a term of row a on node b's corrected pressure: through the correction's row b, where stepped)
        let corrected = |k: &mut Band, a: usize, b: usize, w: Complex| {
            if stepped {
                for &(c, v) in &self.correction[b] {
                    k.add(a, c, w * v);
                }
            } else {
                k.add(a, b, w);
            }
        };
        for edge in &self.edges {
            let y = edge.impedance(edge_s).recip();
            for &(a, ca) in &edge.at {
                for &(b, cb) in &edge.at {
                    corrected(&mut k, a, b, y * (ca * cb));
                }
            }
        }
        let inverses = [self.ends[0].inverse(edge_s), self.ends[1].inverse(edge_s)];
        for (end, inverse) in self.ends.iter().zip(&inverses) {
            for i in 0..2 {
                for j in 0..2 {
                    for &(a, ca) in &end.flows[i].at {
                        for &(b, cb) in &end.flows[j].at {
                            corrected(&mut k, a, b, inverse[i][j] * (ca * cb));
                        }
                    }
                }
            }
        }
        for a in 0..n {
            k.add(a, a, node_s * if stepped { self.own[a] } else { self.mp[a] });
            if !self.shares[a].is_empty() {
                let mut phi = Complex::ZERO;
                for share in &self.shares[a] {
                    phi += if stepped { both * (share.admittance(edge_s) - Complex::new(share.y, 0.0)) + half * share.y } else { share.admittance(s) };
                }
                corrected(&mut k, a, a, phi);
            }
        }
        let mut rhs = vec![Complex::ZERO; n];
        rhs[self.inlet] = half;
        let p = k.solve(rhs);
        // the ends' flows from their elements' drives (B Pt), their three edges together, the flows out from the centred
        let corrected_pressure = |a: usize| -> Complex {
            if stepped {
                self.correction[a].iter().fold(Complex::ZERO, |sum, &(c, v)| sum + p[c] * v)
            } else {
                p[a]
            }
        };
        let out = |w: usize| -> Complex {
            let (end, inverse) = (&self.ends[w], &inverses[w]);
            let drive: Vec<Complex> = end.flows.iter().map(|f| f.at.iter().fold(Complex::ZERO, |sum, &(a, ca)| sum + corrected_pressure(a) * ca)).collect();
            let centred = [0, 1].map(|i| -(inverse[i][0] * drive[0] + inverse[i][1] * drive[1]));
            (centred[0] * end.d[0] + centred[1] * end.d[1]) / half
        };
        Response { mouth: out(0), nostrils: out(1), inlet: p[self.inlet] / half }
    }

    /// A resonance of the lips' transfer near `guess` (a pole: Complex::resonance(f, b) for one at f Hz, b Hz wide), by
    /// the secant method on the transfer's reciprocal, analytic and nought at the pole. None where it does not settle in
    /// 40 steps.
    pub fn resonance(&self, guess: Complex, stepping: Stepping) -> Option<Complex> {
        let f = |s: Complex| self.response(s, stepping).mouth.recip();
        let (mut s0, mut s1) = (guess, guess + Complex::new(-1e-4, 1e-4) * guess.abs());
        let (mut f0, mut f1) = (f(s0), f(s1));
        for _ in 0..40 {
            let step = f1 * (s1 - s0) / (f1 - f0);
            let s2 = s1 - step;
            if !(s2.re.is_finite() && s2.im.is_finite()) {
                return None;
            }
            if step.abs() <= 1e-10 * s2.abs() {
                return Some(s2);
            }
            (s0, f0, s1) = (s1, f1, s2);
            f1 = f(s1);
        }
        None
    }
}

/// A banded matrix: each row's entries from `band` before its diagonal to twice `band` after it (room for partial
/// pivoting's fill).
struct Band {
    n: usize,
    band: usize,
    width: usize,
    a: Vec<Complex>,
}

impl Band {
    fn new(n: usize, band: usize) -> Band {
        let width = 3 * band + 1;
        Band { n, band, width, a: vec![Complex::ZERO; n * width] }
    }

    #[inline]
    fn at(&self, i: usize, j: usize) -> usize {
        i * self.width + j + self.band - i
    }

    fn add(&mut self, i: usize, j: usize, v: Complex) {
        let x = self.at(i, j);
        self.a[x] += v;
    }

    /// x with A x = b: Gaussian elimination with partial pivoting, each column's pivot from the band's rows below it,
    /// then back substitution.
    fn solve(mut self, mut b: Vec<Complex>) -> Vec<Complex> {
        let (n, band) = (self.n, self.band);
        for k in 0..n {
            let (last, end) = ((k + band).min(n - 1), (k + 2 * band).min(n - 1));
            let mut p = k;
            for i in k + 1..=last {
                if self.a[self.at(i, k)].abs() > self.a[self.at(p, k)].abs() {
                    p = i;
                }
            }
            if p != k {
                for c in k..=end {
                    let (x, y) = (self.at(k, c), self.at(p, c));
                    self.a.swap(x, y);
                }
                b.swap(k, p);
            }
            let pivot = self.a[self.at(k, k)];
            for i in k + 1..=last {
                let f = self.a[self.at(i, k)] / pivot;
                if f == Complex::ZERO {
                    continue;
                }
                for c in k + 1..=end {
                    let (v, x) = (self.a[self.at(k, c)], self.at(i, c));
                    self.a[x] -= f * v;
                }
                let bk = b[k];
                b[i] -= f * bk;
            }
        }
        for k in (0..n).rev() {
            let end = (k + 2 * band).min(n - 1);
            let mut v = b[k];
            for c in k + 1..=end {
                v -= self.a[self.at(k, c)] * b[c];
            }
            b[k] = v / self.a[self.at(k, k)];
        }
        b
    }
}

/// The reverse Cuthill-McKee order of a graph's vertices: each component breadth first from a far vertex of least
/// degree, neighbours by degree, the whole reversed -- which keeps neighbours near each other in it.
fn reverse_cuthill_mckee(graph: &[Vec<usize>]) -> Vec<usize> {
    let n = graph.len();
    let mut placed = vec![false; n];
    let mut order = Vec::with_capacity(n);
    while order.len() < n {
        // (a far vertex: of the last level reached from the least connected vertex left, the least connected)
        let first = (0..n).filter(|&v| !placed[v]).min_by_key(|&v| graph[v].len()).unwrap();
        let mut level = vec![usize::MAX; n];
        level[first] = 0;
        let mut reached = vec![first];
        let mut head = 0;
        while head < reached.len() {
            let v = reached[head];
            head += 1;
            for &u in &graph[v] {
                if !placed[u] && level[u] == usize::MAX {
                    level[u] = level[v] + 1;
                    reached.push(u);
                }
            }
        }
        let deepest = level[*reached.last().unwrap()];
        let start = reached.iter().copied().filter(|&v| level[v] == deepest).min_by_key(|&v| graph[v].len()).unwrap();
        let mut head = order.len();
        placed[start] = true;
        order.push(start);
        while head < order.len() {
            let v = order[head];
            head += 1;
            let mut next: Vec<usize> = graph[v].iter().copied().filter(|&u| !placed[u]).collect();
            next.sort_by_key(|&u| (graph[u].len(), u));
            for u in next {
                placed[u] = true;
                order.push(u);
            }
        }
    }
    order.reverse();
    order
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::v24::tds::{TdsModel, MIN_AREA_CM2};
    use crate::v24::tube::{self, Articulator, Tube, NUM_PHARYNX_MOUTH_SECTIONS};

    /// The stepped response is the step's own: a still tube -- a vowel's two tubes, narrow behind and wide in front,
    /// the velum open -- stepped from a small volume put into the pharynx's first node, the glottis shut as
    /// vocalfork_transfer shuts it; the lips' and the nostrils' flows' and that node's pressure's z-transforms taken
    /// where they are damped enough that their sums have ended, against Network::response, with each law of the ducts'
    /// losses (the fitted law, Zwikker and Kosten's with its thermal branches, 2.4's): within 1e-10 of the response's
    /// largest (2e-12 when written, 674 unknowns, 4800 steps). The volume a picolitre, so that the jets' terms,
    /// quadratic in the flow, are some 1e-12 of the response. And the continuous response is the limit the stepped one
    /// tends to as the step shrinks (halving it brought the lips' 4.2 times nearer at 1 kHz, the pressure 5 times).
    #[test]
    fn the_stepped_response_is_the_steps_own() {
        let mut template = Tube::new();
        let n = NUM_PHARYNX_MOUTH_SECTIONS;
        let areas: Vec<f64> = (0..n).map(|i| if i < n / 2 { 1.0 } else { 6.0 }).collect();
        template.set_pharynx_mouth_sections(&[16.0 / n as f64; NUM_PHARYNX_MOUTH_SECTIONS], &areas, &[Articulator::Other; NUM_PHARYNX_MOUTH_SECTIONS]);
        template.set_aux_params(0.3, 15.0, 0.0);
        let mut options = TdsModel::new().options;
        options.generate_noise_sources = false;
        let mut tds = TdsModel::new();
        tds.options = options;
        tds.set_tube(&template, false);
        let mut k = TubeCoefficients::default();
        tds.tube_coefficients(&mut k);
        let glottis = [0.3, 0.3];
        for losses in ["fitted", "zk", "2.4"] {
            let mut model = PassiveModel::new(&template, options);
            model.take_switches(&[format!("losses={losses}")]);
            let steps = model.steps_needed(&k, &glottis);
            let rate = 48000.0 * steps as f64;
            model.set_rate(rate);
            model.set_glottis_sections(&glottis, &[MIN_AREA_CM2; 2]);
            model.set_pressure_source(0.0, 0);
            let (volume, n) = (1e-12, (0.02 * rate) as usize);
            // (the lips' and the nostrils' flows after each step, and the node's pressure, a unit volume's)
            let out: Vec<[f64; 3]> = (0..n)
                .map(|s| {
                    model.injected = if s == 0 { volume * rate } else { 0.0 };
                    let radiated = model.proceed_time_step_with(&k);
                    [radiated.mouth / volume, radiated.nostrils / volume, model.section_pressure(tube::UPPER_GLOTTIS_SECTION) / volume]
                })
                .collect();
            let network = model.network(&k);
            // (damped so that e^-30 of the sums' start is left at their end)
            let damping = 30.0 / (n as f64 / rate);
            let (mut worst, mut largest) = ([0.0f64; 3], [0.0f64; 3]);
            for hz in [300.0, 900.0, 2100.0, 4000.0, 7500.0, 12000.0] {
                let s = Complex::new(damping, 2.0 * PI * hz);
                let back = (-(s * model.time_step)).exp();
                let (mut sums, mut power) = ([Complex::ZERO; 3], Complex::ONE);
                for x in &out {
                    for j in 0..3 {
                        sums[j] += power * x[j];
                    }
                    power = power * back;
                }
                // (the node's pressure as a step leaves it is the next step's, z times the step's own; the response's
                // pressure the step's own over (1 + z^-1)/2)
                let response = network.response(s, Stepping::Stepped);
                let half = (Complex::ONE + back) * 0.5;
                let own = [sums[0] * model.time_step, sums[1] * model.time_step, sums[2] * back * model.time_step];
                let solved = [response.mouth, response.nostrils, response.inlet * half];
                for j in 0..3 {
                    worst[j] = worst[j].max((own[j] - solved[j]).abs());
                    largest[j] = largest[j].max(solved[j].abs());
                }
            }
            for (j, what) in ["the lips' flow", "the nostrils' flow", "the pressure"].iter().enumerate() {
                assert!(worst[j] <= 1e-10 * largest[j], "losses={losses}: {what}'s stepped response {:.2e} from the step's own, of {:.2e}", worst[j], largest[j]);
            }
            // the continuous response the stepped one's limit
            let s = Complex::tone(1000.0);
            let continuous = network.response(s, Stepping::Continuous);
            let stepped = network.response(s, Stepping::Stepped);
            let coarse = [(stepped.mouth - continuous.mouth).abs(), (stepped.inlet - continuous.inlet).abs()];
            model.set_rate(2.0 * rate);
            let halved = model.network(&k).response(s, Stepping::Stepped);
            let fine = [(halved.mouth - continuous.mouth).abs(), (halved.inlet - continuous.inlet).abs()];
            for j in 0..2 {
                assert!(fine[j] < coarse[j] / 3.0, "losses={losses}: halving the step took the stepped response from {:.2e} to {:.2e} of the continuous", coarse[j], fine[j]);
            }
        }
    }
}
