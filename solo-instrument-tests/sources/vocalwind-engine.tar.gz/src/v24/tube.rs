// The vocal tract as a tube of short sections (Tube.cpp): the trachea, the glottis, the pharynx and mouth (the only part
// that moves in speech, with the glottis), the nose with its sinuses, and the piriform fossae; each section its length,
// area and the articulator that bounds it. One array in the C++'s order of `sections[]`. VocalTractLab 2.4's (Tube.cpp):
// its pharynx 18 sections and its mouth 32 (2.3's 16 and 24), its piriform fossae coupled at the fifth; no walls, no
// aspiration and no teeth of its own (2.3's had them): its geometry alone.

pub const NUM_TRACHEA_SECTIONS: usize = 23;
pub const NUM_GLOTTIS_SECTIONS: usize = 2;
pub const NUM_PHARYNX_SECTIONS: usize = 18;
pub const NUM_MOUTH_SECTIONS: usize = 32;
pub const NUM_PHARYNX_MOUTH_SECTIONS: usize = NUM_PHARYNX_SECTIONS + NUM_MOUTH_SECTIONS;
pub const NUM_NOSE_SECTIONS: usize = 19;
pub const NUM_SINUS_SECTIONS: usize = 4;
pub const NUM_FOSSA_SECTIONS: usize = 5;
pub const NUM_SECTIONS: usize = NUM_TRACHEA_SECTIONS + NUM_GLOTTIS_SECTIONS + NUM_PHARYNX_MOUTH_SECTIONS + NUM_NOSE_SECTIONS + NUM_SINUS_SECTIONS + NUM_FOSSA_SECTIONS;

pub const FIRST_TRACHEA_SECTION: usize = 0;
pub const FIRST_GLOTTIS_SECTION: usize = FIRST_TRACHEA_SECTION + NUM_TRACHEA_SECTIONS;
pub const LOWER_GLOTTIS_SECTION: usize = FIRST_GLOTTIS_SECTION;
pub const UPPER_GLOTTIS_SECTION: usize = FIRST_GLOTTIS_SECTION + 1;
pub const FIRST_PHARYNX_SECTION: usize = FIRST_GLOTTIS_SECTION + NUM_GLOTTIS_SECTIONS;
pub const FIRST_MOUTH_SECTION: usize = FIRST_PHARYNX_SECTION + NUM_PHARYNX_SECTIONS;
pub const FIRST_NOSE_SECTION: usize = FIRST_PHARYNX_SECTION + NUM_PHARYNX_MOUTH_SECTIONS;
pub const FIRST_FOSSA_SECTION: usize = FIRST_NOSE_SECTION + NUM_NOSE_SECTIONS;
pub const FIRST_SINUS_SECTION: usize = FIRST_FOSSA_SECTION + NUM_FOSSA_SECTIONS;
pub const LAST_TRACHEA_SECTION: usize = FIRST_TRACHEA_SECTION + NUM_TRACHEA_SECTIONS - 1;
pub const LAST_PHARYNX_SECTION: usize = FIRST_PHARYNX_SECTION + NUM_PHARYNX_SECTIONS - 1;
pub const LAST_MOUTH_SECTION: usize = FIRST_MOUTH_SECTION + NUM_MOUTH_SECTIONS - 1;
pub const LAST_NOSE_SECTION: usize = FIRST_NOSE_SECTION + NUM_NOSE_SECTIONS - 1;
pub const LAST_FOSSA_SECTION: usize = FIRST_FOSSA_SECTION + NUM_FOSSA_SECTIONS - 1;
pub const LAST_SINUS_SECTION: usize = FIRST_SINUS_SECTION + NUM_SINUS_SECTIONS - 1;
pub const FOSSA_COUPLING_SECTION: usize = 4;
pub const SINUS_COUPLING_SECTION: [usize; NUM_SINUS_SECTIONS] = [8, 9, 11, 12];

pub const MIN_AREA_CM2: f64 = 0.01e-2;
// (The static ducts' sizes, from acoustics/tract.json: DEFAULT_SUBGLOTTAL_CAVITY_LENGTH_CM,
// DEFAULT_NASAL_CAVITY_LENGTH_CM, DEFAULT_PIRIFORM_FOSSA_LENGTH_CM, DEFAULT_PIRIFORM_FOSSA_VOLUME_CM3.)
include!(concat!(env!("OUT_DIR"), "/tract-v24-tube.rs"));

/// The articulator bounding a section (its noise sources depend on it).
#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
#[repr(u8)]
pub enum Articulator {
    VocalFolds = 0,
    Tongue = 1,
    LowerIncisors = 2,
    LowerLip = 3,
    #[default]
    Other = 4,
}

impl Articulator {
    pub fn from_index(i: i32) -> Articulator {
        match i {
            0 => Articulator::VocalFolds,
            1 => Articulator::Tongue,
            2 => Articulator::LowerIncisors,
            3 => Articulator::LowerLip,
            _ => Articulator::Other,
        }
    }
}

/// A section: where it begins, its length, area and volume, and what bounds it. (2.4's tube is its geometry alone: its
/// walls are the acoustics' to make, from their properties per unit area.)
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct Section {
    pub pos_cm: f64,
    pub area_cm2: f64,
    pub length_cm: f64,
    pub volume_cm3: f64,
    pub articulator: Articulator,
    /// Its wall against its equal-area circle's (1: a circle; the pharynx's and mouth's from the tract's
    /// cross-sections, VocalTract::section_shapes). Not 2.4's: VocalWind's boundary layer's (src/v24/passive.rs).
    pub shape: f64,
}

#[derive(Clone, Debug)]
pub struct Tube {
    pub section: [Section; NUM_SECTIONS],
    pub incisor_pos_cm: f64,
    pub tongue_tip_side_elevation: f64,
    trachea_length_cm: f64,
    nose_length_cm: f64,
    piriform_fossa_length_cm: f64,
    piriform_fossa_volume_cm3: f64,
}

impl Default for Tube {
    fn default() -> Self {
        Tube::new()
    }
}

impl Tube {
    pub fn new() -> Tube {
        let mut t = Tube { section: [Section::default(); NUM_SECTIONS], incisor_pos_cm: 0.0, tongue_tip_side_elevation: 0.0, trachea_length_cm: 0.0, nose_length_cm: 0.0, piriform_fossa_length_cm: 0.0, piriform_fossa_volume_cm3: 0.0 };
        t.section.iter_mut().for_each(|s| s.shape = 1.0);
        t.init_static_sections(DEFAULT_SUBGLOTTAL_CAVITY_LENGTH_CM, DEFAULT_NASAL_CAVITY_LENGTH_CM, DEFAULT_PIRIFORM_FOSSA_LENGTH_CM, DEFAULT_PIRIFORM_FOSSA_VOLUME_CM3);
        t.reset_pharynx_mouth_sections();
        t.reset_aux_params();
        t.reset_glottis_sections(0.0);
        t
    }

    /// The trachea, the nose with its sinuses, and the piriform fossae: their shapes, scaled to the speaker's lengths.
    pub fn init_static_sections(&mut self, trachea_length_cm: f64, nose_length_cm: f64, fossa_length_cm: f64, fossa_volume_cm3: f64) {
        self.trachea_length_cm = trachea_length_cm;
        self.nose_length_cm = nose_length_cm;
        self.piriform_fossa_length_cm = fossa_length_cm;
        self.piriform_fossa_volume_cm3 = fossa_volume_cm3;
        let other = Articulator::Other;
        for i in 0..NUM_TRACHEA_SECTIONS {
            let ts = &mut self.section[FIRST_TRACHEA_SECTION + i];
            ts.pos_cm = 0.0;
            ts.area_cm2 = 2.5;
            ts.length_cm = trachea_length_cm / NUM_TRACHEA_SECTIONS as f64;
            ts.volume_cm3 = ts.area_cm2 * ts.length_cm;
            ts.articulator = other;
        }
        for (i, a) in [(0, 4.0), (1, 3.0)] {
            let ts = &mut self.section[FIRST_TRACHEA_SECTION + i];
            ts.area_cm2 = a;
            ts.length_cm = trachea_length_cm / NUM_TRACHEA_SECTIONS as f64;
            ts.volume_cm3 = ts.area_cm2 * ts.length_cm;
        }
        const NOSE_LENGTH_CM: [f64; NUM_NOSE_SECTIONS] = [0.57; NUM_NOSE_SECTIONS];
        const NOSE_AREA_CM2: [f64; NUM_NOSE_SECTIONS] = [1.30, 1.25, 1.30, 1.20, 1.60, 2.50, 3.60, 2.25, 2.50, 1.75, 2.50, 2.10, 1.50, 1.50, 0.75, 1.25, 1.60, 1.65, 1.40];
        const SINUS_VOLUME_CM3: [f64; NUM_SINUS_SECTIONS] = [11.3, 6.8, 33.0, 6.2];
        const NECK_LENGTH_CM: [f64; NUM_SINUS_SECTIONS] = [0.3, 0.3, 0.45, 1.0];
        const NECK_AREA_CM2: [f64; NUM_SINUS_SECTIONS] = [0.185, 0.185, 0.145, 0.11];
        let nose_factor = nose_length_cm / DEFAULT_NASAL_CAVITY_LENGTH_CM;
        for i in 0..NUM_NOSE_SECTIONS {
            let ts = &mut self.section[FIRST_NOSE_SECTION + i];
            ts.pos_cm = 0.0;
            ts.area_cm2 = NOSE_AREA_CM2[i];
            ts.length_cm = nose_factor * NOSE_LENGTH_CM[i];
            ts.volume_cm3 = ts.area_cm2 * ts.length_cm;
            ts.articulator = other;
        }
        for i in 0..NUM_SINUS_SECTIONS {
            let ts = &mut self.section[FIRST_SINUS_SECTION + i];
            ts.pos_cm = 0.0;
            ts.area_cm2 = NECK_AREA_CM2[i];
            ts.length_cm = NECK_LENGTH_CM[i];
            ts.volume_cm3 = SINUS_VOLUME_CM3[i];
            ts.articulator = other;
        }
        let max_area = 2.0 * fossa_volume_cm3 / fossa_length_cm;
        let length = fossa_length_cm / NUM_FOSSA_SECTIONS as f64;
        for i in 0..NUM_FOSSA_SECTIONS {
            let ts = &mut self.section[FIRST_FOSSA_SECTION + i];
            ts.pos_cm = 0.0;
            ts.area_cm2 = max_area * (1.0 - (i as f64 + 0.5) / NUM_FOSSA_SECTIONS as f64);
            ts.length_cm = length;
            ts.volume_cm3 = ts.area_cm2 * ts.length_cm;
            ts.articulator = other;
        }
        self.calc_positions();
    }

    /// A frame's geometry laid into the tube as 2.4's VocalTract::getTube lays it: the speaker's static cavities, the
    /// pharynx and mouth's sections, the velic port, the incisors and the tongue tip's sides.
    pub fn set_from_tract(&mut self, t: &crate::v24::tract::TractTube) {
        self.init_static_sections(t.subglottal_length_cm, t.nasal_length_cm, t.fossa_length_cm, t.fossa_volume_cm3);
        self.set_pharynx_mouth_sections(&t.length_cm, &t.area_cm2, &t.articulator);
        // (The laryngeal ventricle, where the anatomy is given one: its volume as area on the first section above the
        // folds, as a one-dimensional tract holds it and measured area functions show it. None: 2.4's larynx, to the
        // bit.)
        if t.ventricle_cm3 > 0.0 {
            let s = &mut self.section[FIRST_PHARYNX_SECTION];
            s.area_cm2 += t.ventricle_cm3 / s.length_cm;
            s.volume_cm3 = s.area_cm2 * s.length_cm;
        }
        for i in 0..NUM_PHARYNX_MOUTH_SECTIONS {
            self.section[FIRST_PHARYNX_SECTION + i].shape = t.shape[i];
        }
        self.set_aux_params(t.velum_opening_cm2, t.incisor_pos_cm, t.tongue_tip_side_elevation);
    }

    pub fn static_params(&self) -> (f64, f64, f64, f64) {
        (self.trachea_length_cm, self.nose_length_cm, self.piriform_fossa_length_cm, self.piriform_fossa_volume_cm3)
    }

    pub fn reset_pharynx_mouth_sections(&mut self) {
        let lengths = [16.0 / NUM_PHARYNX_MOUTH_SECTIONS as f64; NUM_PHARYNX_MOUTH_SECTIONS];
        let areas = [4.0; NUM_PHARYNX_MOUTH_SECTIONS];
        let articulators = [Articulator::Other; NUM_PHARYNX_MOUTH_SECTIONS];
        self.set_pharynx_mouth_sections(&lengths, &areas, &articulators);
    }

    pub fn set_pharynx_mouth_sections(&mut self, lengths_cm: &[f64], areas_cm2: &[f64], articulators: &[Articulator]) {
        for i in 0..NUM_PHARYNX_MOUTH_SECTIONS {
            let ts = &mut self.section[FIRST_PHARYNX_SECTION + i];
            ts.pos_cm = 0.0;
            ts.length_cm = lengths_cm[i];
            ts.area_cm2 = areas_cm2[i];
            if ts.area_cm2 < MIN_AREA_CM2 {
                ts.area_cm2 = MIN_AREA_CM2;
            }
            ts.volume_cm3 = ts.area_cm2 * ts.length_cm;
            ts.articulator = articulators[i];
        }
        self.calc_positions();
    }

    pub fn reset_glottis_sections(&mut self, area_cm2: f64) {
        self.set_glottis_sections(&[0.3, 0.3], &[area_cm2, area_cm2]);
    }

    pub fn set_glottis_sections(&mut self, lengths_cm: &[f64; 2], areas_cm2: &[f64; 2]) {
        for i in 0..NUM_GLOTTIS_SECTIONS {
            let ts = &mut self.section[FIRST_GLOTTIS_SECTION + i];
            ts.pos_cm = 0.0;
            ts.length_cm = lengths_cm[i];
            ts.area_cm2 = areas_cm2[i];
            if ts.area_cm2 < MIN_AREA_CM2 {
                ts.area_cm2 = MIN_AREA_CM2;
            }
            ts.volume_cm3 = ts.area_cm2 * ts.length_cm;
            ts.articulator = Articulator::VocalFolds;
        }
        self.calc_positions();
    }

    pub fn reset_aux_params(&mut self) {
        self.set_aux_params(0.0, 15.0, 0.0);
    }

    /// The velic port's area -- the first four nose sections opening from it toward the fifth's, by the square of their
    /// place -- the incisors' position and the tongue tip's sides.
    pub fn set_aux_params(&mut self, nasal_port_area_cm2: f64, incisor_pos_cm: f64, tongue_tip_side_elevation: f64) {
        const N: usize = 4;
        let target = self.section[FIRST_NOSE_SECTION + N].area_cm2;
        for i in 0..N {
            let ts = &mut self.section[FIRST_NOSE_SECTION + i];
            ts.area_cm2 = nasal_port_area_cm2 + ((i * i) as f64 * (target - nasal_port_area_cm2)) / (N * N) as f64;
            if ts.area_cm2 < MIN_AREA_CM2 {
                ts.area_cm2 = MIN_AREA_CM2;
            }
            ts.volume_cm3 = ts.area_cm2 * ts.length_cm;
        }
        self.incisor_pos_cm = incisor_pos_cm;
        self.tongue_tip_side_elevation = tongue_tip_side_elevation;
    }

    /// (the velic port's area as the tube holds it, the incisors, the tongue tip's sides)
    pub fn aux_params(&self) -> (f64, f64, f64) {
        (self.section[FIRST_NOSE_SECTION].area_cm2, self.incisor_pos_cm, self.tongue_tip_side_elevation)
    }

    /// Between two tubes, section by section; each section's articulator the nearer tube's.
    pub fn interpolate(&mut self, left: &Tube, right: &Tube, ratio: f64) {
        let ratio1 = 1.0 - ratio;
        for i in 0..NUM_SECTIONS {
            let (l, r) = (&left.section[i], &right.section[i]);
            let ts = &mut self.section[i];
            ts.pos_cm = ratio1 * l.pos_cm + ratio * r.pos_cm;
            ts.area_cm2 = ratio1 * l.area_cm2 + ratio * r.area_cm2;
            ts.length_cm = ratio1 * l.length_cm + ratio * r.length_cm;
            ts.volume_cm3 = ratio1 * l.volume_cm3 + ratio * r.volume_cm3;
            ts.shape = ratio1 * l.shape + ratio * r.shape;
            ts.articulator = if ratio < 0.5 { l.articulator } else { r.articulator };
        }
        self.incisor_pos_cm = ratio1 * left.incisor_pos_cm + ratio * right.incisor_pos_cm;
        self.tongue_tip_side_elevation = ratio1 * left.tongue_tip_side_elevation + ratio * right.tongue_tip_side_elevation;
    }

    /// Each section's position: the trachea and glottis backward from the glottis's top, the pharynx and mouth forward
    /// from it, the nose from the velum, the fossae from their coupling section, the sinuses after their coupling ones.
    pub fn calc_positions(&mut self) {
        let mut pos = 0.0;
        let s = &mut self.section;
        pos -= s[UPPER_GLOTTIS_SECTION].length_cm;
        s[UPPER_GLOTTIS_SECTION].pos_cm = pos;
        pos -= s[LOWER_GLOTTIS_SECTION].length_cm;
        s[LOWER_GLOTTIS_SECTION].pos_cm = pos;
        for i in (0..NUM_TRACHEA_SECTIONS).rev() {
            pos -= s[FIRST_TRACHEA_SECTION + i].length_cm;
            s[FIRST_TRACHEA_SECTION + i].pos_cm = pos;
        }
        let (mut fossa_pos, mut nose_pos) = (0.0, 0.0);
        pos = 0.0;
        for i in 0..NUM_PHARYNX_MOUTH_SECTIONS {
            s[FIRST_PHARYNX_SECTION + i].pos_cm = pos;
            pos += s[FIRST_PHARYNX_SECTION + i].length_cm;
            if i == FOSSA_COUPLING_SECTION {
                fossa_pos = pos;
            }
            if i == NUM_PHARYNX_SECTIONS - 1 {
                nose_pos = pos;
            }
        }
        pos = nose_pos;
        for i in 0..NUM_NOSE_SECTIONS {
            s[FIRST_NOSE_SECTION + i].pos_cm = pos;
            pos += s[FIRST_NOSE_SECTION + i].length_cm;
        }
        pos = fossa_pos;
        for i in 0..NUM_FOSSA_SECTIONS {
            s[FIRST_FOSSA_SECTION + i].pos_cm = pos;
            pos += s[FIRST_FOSSA_SECTION + i].length_cm;
        }
        for i in 0..NUM_SINUS_SECTIONS {
            let c = FIRST_NOSE_SECTION + SINUS_COUPLING_SECTION[i];
            s[FIRST_SINUS_SECTION + i].pos_cm = s[c].pos_cm + s[c].length_cm;
        }
    }
}
