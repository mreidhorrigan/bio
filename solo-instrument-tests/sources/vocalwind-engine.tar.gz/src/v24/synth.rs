// VocalTractLab 2.4's synthesizer (Synthesizer.cpp: addChunk, addSample), as synth.rs is 2.3's: a chunk's tube and
// glottis parameters interpolated each sample from the last chunk's; each sample the glottis's geometry laid into the
// tube's two glottal sections, the tube taken by the acoustics (its areas slowed near closure from the second sample on),
// the glottis advanced by the pressures about it, a step simulated, and the flow radiated -- the mouth's, the nostrils'
// and the skin's together -- filtered by the radiation characteristic (2.4's head and torso by default, or a piston in a
// sphere, or 2.3's difference), low-passed at 12 kHz (an eighth-order Chebyshev), and scaled into the signal.
// Stepped at a multiple of 48 kHz (set_oversampling; docs/VOCAL_TRACT.md, "What the high band holds"): the glottis, the
// tube and the acoustics take that many steps a sample, the tube and glottis interpolated at each, and the flow they
// radiate is brought back to 48 kHz through a linear-phase low-pass (a Kaiser-windowed sinc: flat to 20 kHz, 100 dB
// down from 24 kHz, where it would fold) before the radiation filter; the 12 kHz low-pass, 2.4's mask over its aliasing,
// is then left off. At 1, 2.4 as it is, sample for sample.
use super::constants::*;
use super::glottis::{Glottis2025, FREQUENCY, NUM_CONTROL_PARAMS, PRESSURE};
use super::passive::parallel::{Crew, MAIN_COST, MAIN_COST_WITH_TUBE};
use super::passive::PassiveModel;
use super::pipeline::Records;
use super::tds::{Radiation, TdsModel, TubeCoefficients};
use super::tract::{TractTube, VocalTract};
use super::tube::{Tube, FIRST_PHARYNX_SECTION, FIRST_TRACHEA_SECTION, LAST_TRACHEA_SECTION, LOWER_GLOTTIS_SECTION, UPPER_GLOTTIS_SECTION};
use crate::iir::IirFilter;

pub const NUM_CHUNK_SAMPLES: usize = 120;
const TDS_BUFFER_LENGTH: usize = 32768;
const TDS_BUFFER_MASK: i32 = 32767;
const FINE_BUFFER_LENGTH: usize = 4096;
const FINE_BUFFER_MASK: usize = FINE_BUFFER_LENGTH - 1;

/// The low-pass that brings n x 48 kHz back to 48 kHz: a sinc cut at 22 kHz, Kaiser-windowed (beta 10.06, 100 dB) over
/// 77 n + 1 taps -- its transition from 20 to 24 kHz -- its gain at DC 1.
fn decimator(n: usize) -> Vec<f64> {
    let len = 77 * n + 1;
    let fc = 22000.0 / (AUDIO_SAMPLING_RATE_HZ as f64 * n as f64);
    let beta = 10.06;
    let i0 = |x: f64| -> f64 {
        let (mut sum, mut term, mut k) = (1.0, 1.0, 1.0);
        while term > 1e-17 * sum {
            term *= (x / (2.0 * k)) * (x / (2.0 * k));
            sum += term;
            k += 1.0;
        }
        sum
    };
    let m = (len - 1) as f64 / 2.0;
    let mut h: Vec<f64> = (0..len)
        .map(|i| {
            let x = i as f64 - m;
            let sinc = if x == 0.0 { 2.0 * fc } else { (2.0 * PI * fc * x).sin() / (PI * x) };
            let r = x / m;
            sinc * i0(beta * (1.0 - r * r).max(0.0).sqrt()) / i0(beta)
        })
        .collect();
    let sum: f64 = h.iter().sum();
    h.iter_mut().for_each(|x| *x /= sum);
    h
}

/// What a step takes from the frames alone: its tube's coefficients, and its glottis's parameters interpolated.
#[derive(Clone, Debug, Default)]
pub struct StepRecord {
    pub tube: TubeCoefficients,
    pub glottis: [f64; NUM_CONTROL_PARAMS],
}

/// A step's part that depends on the frames alone (addChunk's interpolation and setTube): between the last frame and
/// the new one, the tube interpolated, its sections' positions laid, its areas slowed near closure from the second step
/// on, its coefficients made (TdsModel::tube_coefficients, on a model of its own that holds the areas' last values and
/// the sections' kept coefficients), and the glottis's parameters interpolated -- on the acoustics' thread, or ahead on
/// another (src/v24/pipeline.rs). Its glottis's two sections are the acoustics' own.
#[derive(Clone)]
pub struct Stepper {
    pub tds: TdsModel,
    prev_tube: Tube,
    tube: Tube,
    prev_glottis: [f64; NUM_CONTROL_PARAMS],
    started: bool,
    steps: u64,
}

impl Stepper {
    pub fn new(tds: &TdsModel) -> Stepper {
        Stepper { tds: tds.clone(), prev_tube: Tube::new(), tube: Tube::new(), prev_glottis: [0.0; NUM_CONTROL_PARAMS], started: false, steps: 0 }
    }

    /// As made (its tube's state and the steps counted from nothing), stepped at `rate_hz`.
    pub fn reset(&mut self, rate_hz: f64) {
        self.tds.set_rate(rate_hz);
        self.started = false;
        self.steps = 0;
    }

    /// The first frame, where the next begins from; false (and nothing kept) after it.
    pub fn start(&mut self, tube: &Tube, glottis: &[f64]) -> bool {
        if self.started {
            return false;
        }
        self.prev_tube = tube.clone();
        self.prev_glottis.copy_from_slice(&glottis[..NUM_CONTROL_PARAMS]);
        self.started = true;
        true
    }

    /// Step `index` of `count` between the last frame and `new_tube`, `new_glottis`, into `record`.
    pub fn step(&mut self, index: usize, count: usize, new_tube: &Tube, new_glottis: &[f64], record: &mut StepRecord) {
        let ratio = index as f64 / count as f64;
        let ratio1 = 1.0 - ratio;
        self.tube.interpolate(&self.prev_tube, new_tube, ratio);
        for k in 0..NUM_CONTROL_PARAMS {
            record.glottis[k] = ratio1 * self.prev_glottis[k] + ratio * new_glottis[k];
        }
        // (The positions laid as the glottis's sections are set each step: those of the trachea and glottis, which
        // follow the glottis's lengths, are not read past here.)
        self.tube.calc_positions();
        self.tds.set_tube(&self.tube, self.steps != 0);
        self.tds.tube_coefficients(&mut record.tube);
        self.steps += 1;
    }

    /// The frame done: the next begins from it.
    pub fn finish(&mut self, new_tube: &Tube, new_glottis: &[f64]) {
        self.prev_tube = new_tube.clone();
        self.prev_glottis.copy_from_slice(&new_glottis[..NUM_CONTROL_PARAMS]);
    }
}

pub struct Synthesizer {
    pub glottis: Glottis2025,
    pub tds: TdsModel,
    /// VocalFork 3.0's acoustics (src/v24/passive.rs), where set: each step taken there in place of 2.4's network, the
    /// same glottis, tube, noise and radiation filter about it.
    pub passive: Option<Box<PassiveModel>>,
    /// The frames' part of each step, made here (add_tube) or taken from records made elsewhere (add_records).
    pub stepper: Stepper,
    record: Box<StepRecord>,
    output_flow: Vec<f64>,
    output_pressure: Vec<f64>,
    output_pressure_filter: IirFilter,
    /// Steps a sample (1: 2.4's 48 kHz).
    oversampling: usize,
    /// The low-pass the flow is brought back to 48 kHz through (none at 1), and the flow at the stepped rate.
    decimator: Vec<f64>,
    fine_flow: Vec<f64>,
    fine_index: usize,
    /// The output samples made, the radiation's buffers' index.
    out_index: i32,
    /// The 12 kHz low-pass VocalTractLab ends with (on, as 2.4 has it): off, the simulation's whole band is heard --
    /// above about 11 kHz, where Birkholz found its lumped elements "start to generate very noisy spectra".
    pub lowpass: bool,
    /// VocalFork's step over several cores (PassiveModel::cores), made at a run's first step and let go at reset; and
    /// a call's steps' totals as it gives them back, some steps late.
    crew: Option<Crew>,
    totals: Vec<f64>,
}

impl Synthesizer {
    pub fn new(glottis: Glottis2025, tds: TdsModel) -> Synthesizer {
        let mut output_pressure_filter = IirFilter::default();
        output_pressure_filter.create_chebyshev(SYNTHETIC_SPEECH_BANDWIDTH_HZ / AUDIO_SAMPLING_RATE_HZ as f64, false, 8);
        assert_eq!(glottis.control.len(), NUM_CONTROL_PARAMS);
        let stepper = Stepper::new(&tds);
        let mut s = Synthesizer {
            glottis,
            tds,
            passive: None,
            stepper,
            record: Box::default(),
            output_flow: vec![0.0; TDS_BUFFER_LENGTH],
            output_pressure: vec![0.0; TDS_BUFFER_LENGTH],
            output_pressure_filter,
            oversampling: 1,
            decimator: Vec::new(),
            fine_flow: vec![0.0; FINE_BUFFER_LENGTH],
            fine_index: 0,
            out_index: 0,
            lowpass: true,
            crew: None,
            totals: Vec::new(),
        };
        s.reset();
        s
    }

    pub fn reset(&mut self) {
        self.crew = None;
        self.glottis.reset_motion();
        self.tds.reset_motion();
        if let Some(p) = self.passive.as_mut() {
            p.noise.options = self.tds.options;
            p.reset_motion();
        }
        self.stepper.tds.options = self.tds.options;
        self.stepper.reset(self.tds.rate_hz);
        self.output_pressure_filter.reset_buffers(0.0);
        self.output_flow.iter_mut().for_each(|x| *x = 0.0);
        self.output_pressure.iter_mut().for_each(|x| *x = 0.0);
        self.fine_flow.iter_mut().for_each(|x| *x = 0.0);
        self.fine_index = 0;
        self.out_index = 0;
    }

    /// VocalFork 3.0 from here on (reset): its acoustics in place of 2.4's network, and its glottis's jitter the
    /// cycle-to-cycle variation it is (Glottis2025::jitter_band_limited), not white phase noise. Its glottis takes
    /// whatever lung pressure it is given (the owner, 15 November 2026, of lifting the speaker files' 16,000 dPa for
    /// VocalWind: "Open it now"): 2.4's range, a slider's of its program, held every note asked louder at 16,000 dPa,
    /// where a singer's loud high notes are measured at twice that (public/shared/vocal/sung-pressure.js). 2.4's own
    /// glottis keeps it. And whatever pitch it is given: 2.4's range, 40 to 600 Hz, sang every note above D5 at 600 Hz,
    /// where trained women's ranges reach 1,320 Hz on the mean (Sulter, Schutte & Miller 1995, voices/
    /// measured-singing.json); above it the folds' length and thickness go on by 2.4's law (the length as the square root
    /// of f0 over the rest f0) past what it was made for (research/MODELING_GAPS.md, "The folds above 600 Hz").
    pub fn use_vocalfork(&mut self, model: PassiveModel) {
        // (The synthesizer's options the model's from here on -- its own as the model was built from them, with the
        // switches the model took: reset gives the model's noise the synthesizer's options, and until 16 November 2026
        // undid every noise=0 asked of vtl-sing, vtl-say and vtl-stream, their noise on whatever was asked.)
        self.tds.options = model.noise.options;
        self.passive = Some(Box::new(model));
        self.glottis.jitter_band_limited = true;
        self.glottis.control[PRESSURE].max = f64::INFINITY;
        self.glottis.control[FREQUENCY].max = f64::INFINITY;
        self.reset();
    }

    /// `n` steps a sample from here on (reset): the acoustics and the glottis at n x 48 kHz, the flow brought back to
    /// 48 kHz, the 12 kHz low-pass off where n > 1 (on, as 2.4 has it, at 1).
    pub fn set_oversampling(&mut self, n: usize) {
        let n = n.max(1);
        let rate = AUDIO_SAMPLING_RATE_HZ as f64 * n as f64;
        self.oversampling = n;
        self.tds.set_rate(rate);
        if let Some(p) = self.passive.as_mut() {
            p.set_rate(rate);
        }
        self.glottis.rate_hz = rate;
        self.decimator = if n == 1 { Vec::new() } else { decimator(n) };
        self.lowpass = n == 1;
        self.reset();
    }

    pub fn oversampling(&self) -> usize {
        self.oversampling
    }

    /// The cores VocalFork's step has gone over since the run began: its crew's parts (Crew::parts), 1 where it has none.
    pub fn cores(&self) -> usize {
        self.crew.as_ref().map_or(1, |c| c.parts().len())
    }

    /// Of its crew's workers' parts' stages since the run began, those the main thread stepped, its workers late
    /// (Crew::helped), and theirs all; none where it has no crew.
    pub fn helped(&self) -> (u64, u64) {
        self.crew.as_ref().map_or((0, 0), |c| c.helped())
    }

    /// The delay the bringing back to 48 kHz adds (samples at 48 kHz).
    pub fn latency_samples(&self) -> f64 {
        if self.decimator.is_empty() {
            0.0
        } else {
            (self.decimator.len() - 1) as f64 / 2.0 / self.oversampling as f64
        }
    }

    /// A chunk from the tract's parameters: its geometry made and laid into a tube (Synthesizer::addChunk).
    pub fn add_tract(&mut self, tract: &mut VocalTract, tract_params: &[f64], new_glottis: &[f64], out: &mut [f64]) {
        tract.calculate(tract_params);
        self.add_geometry(&tract.tube(), new_glottis, out);
    }

    pub fn add_geometry(&mut self, geometry: &TractTube, new_glottis: &[f64], out: &mut [f64]) {
        let mut t = Tube::new();
        t.set_from_tract(geometry);
        self.add_tube(new_glottis, &t, out);
    }

    /// A chunk of `out.len()` samples toward the new tube and glottis; the first call only sets where it starts.
    pub fn add_tube(&mut self, new_glottis: &[f64], new_tube: &Tube, out: &mut [f64]) {
        self.stepper.tds.options = self.tds.options;
        if self.stepper.start(new_tube, new_glottis) {
            return;
        }
        let num = out.len();
        if num < 1 {
            return;
        }
        let over = self.oversampling;
        if self.crewed(MAIN_COST_WITH_TUBE) {
            let (crew, p) = (self.crew.as_mut().unwrap(), self.passive.as_mut().unwrap());
            crew.begin(num * over);
            for s in 0..num * over {
                let record = crew.record();
                self.stepper.step(s, num * over, new_tube, new_glottis, record);
                Self::glottis_from(&mut self.glottis, p, record);
                crew.step(p);
            }
            crew.finish(p, &mut self.totals);
            self.sound(out);
            self.stepper.finish(new_tube, new_glottis);
            return;
        }
        for i in 0..num {
            let mut total = 0.0;
            for j in 0..over {
                self.stepper.step(i * over + j, num * over, new_tube, new_glottis, &mut self.record);
                total = match self.passive.as_mut() {
                    Some(p) => Self::step_passive(&mut self.glottis, p, &self.record),
                    None => Self::step(&mut self.glottis, &mut self.tds, &self.record),
                };
                self.fine(total);
            }
            out[i] = self.radiate(self.decimate(total));
        }
        self.stepper.finish(new_tube, new_glottis);
    }

    /// A chunk of `out.len()` samples from records made elsewhere, in order (each step's, its frames' part made by a
    /// Stepper as add_tube makes it: src/v24/pipeline.rs): the same samples, to the bit.
    pub fn add_records(&mut self, out: &mut [f64], records: &mut impl Records) {
        let over = self.oversampling;
        if !out.is_empty() && self.crewed(MAIN_COST) {
            let (crew, p) = (self.crew.as_mut().unwrap(), self.passive.as_mut().unwrap());
            crew.begin(out.len() * over);
            for _ in 0..out.len() * over {
                let record = crew.record();
                record.clone_from(records.next());
                Self::glottis_from(&mut self.glottis, p, record);
                crew.step(p);
            }
            crew.finish(p, &mut self.totals);
            self.sound(out);
            return;
        }
        for x in out.iter_mut() {
            let mut total = 0.0;
            for _ in 0..over {
                total = match self.passive.as_mut() {
                    Some(p) => Self::step_passive(&mut self.glottis, p, records.next()),
                    None => Self::step(&mut self.glottis, &mut self.tds, records.next()),
                };
                self.fine(total);
            }
            *x = self.radiate(self.decimate(total));
        }
    }

    /// One step of the glottis and the acoustics from its record: the flow they radiate (mouth, nostrils and skin).
    fn step(glottis: &mut Glottis2025, tds: &mut TdsModel, record: &StepRecord) -> f64 {
        for (k, p) in glottis.control.iter_mut().enumerate() {
            p.x = record.glottis[k];
        }
        glottis.calc_geometry();
        let (length, area) = glottis.tube_data();
        tds.set_glottis_sections(&length, &area);
        tds.set_flow_source(0.0, -1);
        tds.set_pressure_source(glottis.control[PRESSURE].x, FIRST_TRACHEA_SECTION as i32);
        let pressure = [
            tds.section_pressure(LAST_TRACHEA_SECTION),
            tds.section_pressure(LOWER_GLOTTIS_SECTION),
            tds.section_pressure(UPPER_GLOTTIS_SECTION),
            tds.section_pressure(FIRST_PHARYNX_SECTION),
        ];
        glottis.inc_time(tds.time_step, &pressure);
        tds.proceed_time_step_with(&record.tube).total
    }

    /// Whether VocalFork's step goes over several cores this call (its model's `cores`), its crew made where it has
    /// none -- from a model at rest (a run that began on one core keeps to it until reset), and neither with the thermal
    /// half of the boundary layer nor with the energy's account. `main_cost`: the main thread's own work a step beside
    /// its part of the network (parallel::MAIN_COST, MAIN_COST_WITH_TUBE).
    fn crewed(&mut self, main_cost: f64) -> bool {
        let Some(p) = self.passive.as_ref() else {
            return false;
        };
        if self.crew.is_none() {
            if p.cores < 2 || p.thermal_layer || p.account.is_some() || p.has_stepped() {
                return false;
            }
            let cores = p.cores.min(std::thread::available_parallelism().map_or(1, |n| n.get()));
            if cores < 2 {
                return false;
            }
            self.crew = Some(Crew::new(p, cores, main_cost));
        }
        true
    }

    /// A call's samples from its steps' totals as the crew gave them back (`totals`): as add_tube and add_records make
    /// them a step at a time.
    fn sound(&mut self, out: &mut [f64]) {
        let totals = std::mem::take(&mut self.totals);
        let over = self.oversampling;
        for (i, x) in out.iter_mut().enumerate() {
            for j in 0..over {
                self.fine(totals[i * over + j]);
            }
            *x = self.radiate(self.decimate(totals[i * over + over - 1]));
        }
        self.totals = totals;
    }

    /// One step of the glottis and VocalFork 3.0's acoustics, as `step` takes one of 2.4's.
    fn step_passive(glottis: &mut Glottis2025, passive: &mut PassiveModel, record: &StepRecord) -> f64 {
        Self::glottis_from(glottis, passive, record);
        passive.proceed_time_step_with(&record.tube).total
    }

    /// The glottis's step before VocalFork's acoustics take theirs: its sections and the lungs' pressure set in them,
    /// the glottis advanced by the pressures about it (the pharynx's first section's, the only one of the four it uses).
    fn glottis_from(glottis: &mut Glottis2025, passive: &mut PassiveModel, record: &StepRecord) {
        for (k, p) in glottis.control.iter_mut().enumerate() {
            p.x = record.glottis[k];
        }
        glottis.calc_geometry();
        let (length, area) = glottis.tube_data();
        passive.set_glottis_sections(&length, &area);
        passive.set_pressure_source(glottis.control[PRESSURE].x, FIRST_TRACHEA_SECTION as i32);
        let pressure = [
            passive.section_pressure(LAST_TRACHEA_SECTION),
            passive.section_pressure(LOWER_GLOTTIS_SECTION),
            passive.section_pressure(UPPER_GLOTTIS_SECTION),
            passive.section_pressure(FIRST_PHARYNX_SECTION),
        ];
        glottis.inc_time(passive.time_step, &pressure);
    }

    /// The flow at the stepped rate kept, where it is to be brought back to 48 kHz.
    fn fine(&mut self, total: f64) {
        if self.oversampling > 1 {
            self.fine_flow[self.fine_index & FINE_BUFFER_MASK] = total;
            self.fine_index += 1;
        }
    }

    /// The flow at 48 kHz: the last step's, or (stepped faster) the low-pass's output at it -- and so at every n-th: its
    /// taps symmetric.
    fn decimate(&self, total: f64) -> f64 {
        if self.oversampling == 1 {
            return total;
        }
        let last = self.fine_index - 1;
        self.decimator.iter().enumerate().map(|(k, h)| h * self.fine_flow[last.wrapping_sub(k) & FINE_BUFFER_MASK]).sum()
    }

    /// A sample at 48 kHz from the flow radiated: through the radiation filter, and 2.4's low-pass where it is on.
    fn radiate(&mut self, total: f64) -> f64 {
        let pos = self.out_index;
        self.out_index = self.out_index.wrapping_add(1);
        let k = (pos & TDS_BUFFER_MASK) as usize;
        self.output_flow[k] = total;
        let fir = |taps: &[f64], flow: &[f64]| -> f64 {
            let mut sum = 0.0;
            for (index, tap) in taps.iter().enumerate() {
                sum += tap * flow[(pos.wrapping_sub(index as i32) & TDS_BUFFER_MASK) as usize];
            }
            AUDIO_SAMPLING_RATE_HZ as f64 * sum
        };
        self.output_pressure[k] = match self.tds.options.radiation {
            Radiation::PistonSphere => fir(&PISTON_SPHERE_RADIATION_FILTER, &self.output_flow),
            Radiation::HeadTorso => fir(&HEAD_TORSO_RADIATION_FILTER, &self.output_flow),
            Radiation::Simple => (self.output_flow[k] - self.output_flow[((k as i32 - 1) & TDS_BUFFER_MASK) as usize]) / (1.0 / AUDIO_SAMPLING_RATE_HZ as f64),
        };
        if self.lowpass {
            self.output_pressure_filter.output_sample(self.output_pressure[k]) * 1e-7
        } else {
            self.output_pressure[k] * 1e-7
        }
    }
}
