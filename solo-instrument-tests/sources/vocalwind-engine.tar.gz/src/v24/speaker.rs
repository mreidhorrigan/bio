// A VocalTractLab 2.4 speaker file (JD2, M01, W02): its vocal tract (src/v24/tract.rs) and its selected glottis, the
// "Geometric glottis 2025" (src/v24/glottis.rs) -- the others it carries (2019's, the triangular) not ported.
use super::glottis::Glottis2025;
use super::tract::VocalTract;
use crate::xml::{self, Node};

pub struct Speaker {
    pub tract: VocalTract,
    pub glottis: Glottis2025,
    pub root: Node,
}

impl Speaker {
    pub fn parse(text: &str) -> Result<Speaker, String> {
        let root = xml::parse(text)?;
        if root.name != "speaker" {
            return Err(format!("<{}>: not a speaker file", root.name));
        }
        let tract = VocalTract::from_xml(root.child("vocal_tract_model").ok_or("no vocal tract")?)?;
        let models = root.child("glottis_models").ok_or("no glottis models")?;
        let selected = models.children.iter().find(|m| m.attr("selected").map(|s| s.trim() == "1").unwrap_or(false)).or_else(|| models.children.first()).ok_or("no glottis model")?;
        let kind = selected.attr("type").unwrap_or("");
        if kind != "Geometric glottis 2025" {
            return Err(format!("its selected glottis is the {kind}: only 2.4's Geometric glottis 2025 is ported"));
        }
        let glottis = Glottis2025::from_xml(selected)?;
        Ok(Speaker { tract, glottis, root })
    }

    pub fn read(path: &str) -> Result<Speaker, String> {
        Speaker::parse(&std::fs::read_to_string(path).map_err(|e| format!("{path}: {e}"))?)
    }
}
