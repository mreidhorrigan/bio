// The vowel space (languages/vowel-space.json; research/VOCALWIND_LANGUAGES.md, design 4; the owner, 15 November 2026):
// every IPA vowel at its place on the IPA chart -- its row, its column, its rounding, and its rhoticity (the owner, 15
// November 2026: "if this means the space needs extension or the addition of a dimension, extend it") -- and a
// speaker's shape at any place made from its own vowels at theirs. The tongue, jaw, hyoid and velum (the 17 parameters but the lips')
// interpolated over a triangulation of the anchors by row and column, the lips by row and rounding, as VocalTractLab's
// own subspace factors a vowel (P. Birkholz 2013, PLoS ONE 8(4) e60603, doi:10.1371/journal.pone.0060603, eqs. 3-7;
// src/gestural.rs map_to_vowel_subspace). No search: a place outside the anchors' hull is taken at the hull's nearest
// point, as the engine limits its own subspace's coordinates (limit_vowel_subspace_coord). R-colouring is a measured
// rhotic shape's displacement from the speaker's space where the shape's sound puts it (`anchors.rhotic`), added to a
// place by its rhoticity: [ɝ] [ɜ˞] is [ɜ] coloured, [ɑ˞] [ɑ]. A language's vowels may stand where measured speakers of
// it put them (languages/vowel-places.json, `Places`), spread apart by a clarity (the owner, 15 November 2026:
// "separation of sounds within a language (e.g., on the vowel chart) is important for intelligibility").
use crate::carry;
use crate::inventory::{self, language_file, Kind};
use crate::tract::{LD, LP, NUM_PARAMS, VO, VS};
use crate::v24::tract::VocalTract;
use serde_json::Value;
use std::collections::BTreeMap;
use std::sync::OnceLock;

/// A vowel's place on the chart: its row, close (0) to open; its column, front (0) to back (2); its rounding,
/// unrounded (0) to rounded (1); its rhoticity, none (0) to r-coloured (1).
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Place {
    pub row: f64,
    pub column: f64,
    pub rounding: f64,
    pub rhotic: f64,
}

impl Place {
    /// A place on the chart, not r-coloured.
    pub fn new(row: f64, column: f64, rounding: f64) -> Place {
        Place { row, column, rounding, rhotic: 0.0 }
    }
}

#[derive(Clone, Debug)]
enum Mark {
    Shift { row: f64, column: f64, rounding: f64, rhotic: f64 },
    /// Toward a place by a share of the way: the central column (`central`) or a vowel's row and column.
    Toward { to: Option<Place>, share: f64 },
}

/// The chart's trapezoid (vowel-space.json `chart`).
#[derive(Clone, Copy, Debug)]
struct Chart {
    open_row: f64,
    row_height: f64,
    back_x: f64,
    front_x_close: f64,
    front_x_open: f64,
}

impl Chart {
    /// Where a place is drawn: across from the front edge, down from the close row.
    fn xy(&self, p: Place) -> (f64, f64) {
        let front = self.front_x_close + (self.front_x_open - self.front_x_close) * p.row / self.open_row;
        (front + p.column / 2.0 * (self.back_x - front), p.row * self.row_height)
    }

    /// The place drawn at a point, with a rounding.
    fn place(&self, (x, y): (f64, f64), rounding: f64) -> Place {
        let row = y / self.row_height;
        let front = self.front_x_close + (self.front_x_open - self.front_x_close) * row / self.open_row;
        Place::new(row, 2.0 * (x - front) / (self.back_x - front), rounding)
    }
}

#[derive(Debug)]
pub struct Space {
    chart: Chart,
    vowels: BTreeMap<char, Place>,
    marks: BTreeMap<char, Mark>,
    precomposed: BTreeMap<char, String>,
    ignored: Vec<char>,
    /// The inventory's vowels from these sources are a speaker's anchors.
    sources: Vec<String>,
    /// A shape at another place than its phone's IPA's.
    moved: BTreeMap<String, Place>,
    /// Whether the anchors are placed by their sound (place_by_sound), and the corners that fix the map.
    by_sound: bool,
    corners: Vec<Place>,
    /// The shape r-colouring is measured from (`anchors.rhotic.shape`).
    rhotic: Option<String>,
    /// The even shares of a vertex's push tried, beyond a speaker's own vowels (`anchors.extension.steps`).
    extension_steps: usize,
    /// How a vowel made from a speaker's space is brought to sound where its map puts it (`heard`, Sounded::heard).
    hearing: Hearing,
}

/// How a made vowel is brought to sound at its place (vowel-space.json `heard`): within `cents` at F1 and F2, in at most
/// `steps` steps, each step's direction from moves of the reading `probe` long on the chart, a step halved at most
/// `halvings` times until it sounds nearer; where reading does not bring it there, its shape tuned in at most
/// `tune_steps` least-squares steps, each parameter's whole range moved weighing `cents_per_range`.
#[derive(Clone, Copy, Debug)]
struct Hearing {
    cents: f64,
    steps: usize,
    probe: f64,
    halvings: usize,
    tune_steps: usize,
    cents_per_range: f64,
}

/// The map from a speaker's vowels' sounds to the chart (Space::sound_map): each chart coordinate a x + b y + c of the
/// sound's (F2 - F1, F1 in Bark).
#[derive(Clone, Copy, Debug)]
pub struct SoundMap {
    chart: Chart,
    x: [f64; 3],
    y: [f64; 3],
}

impl SoundMap {
    /// Where a sound (its first two resonances, Hz) is on the chart, with a rounding.
    pub fn place(&self, (f1, f2): (f64, f64), rounding: f64) -> Place {
        let (x0, y0) = (bark(f2) - bark(f1), bark(f1));
        self.chart.place((self.x[0] * x0 + self.x[1] * y0 + self.x[2], self.y[0] * x0 + self.y[1] * y0 + self.y[2]), rounding)
    }

    /// The sound (its first two resonances, Hz) the map puts at a place: `place`'s inverse.
    pub fn sound(&self, p: Place) -> (f64, f64) {
        let (cx, cy) = self.chart.xy(p);
        let (u, v) = (cx - self.x[2], cy - self.y[2]);
        let d = self.x[0] * self.y[1] - self.x[1] * self.y[0];
        let (x0, y0) = ((u * self.y[1] - v * self.x[1]) / d, (v * self.x[0] - u * self.y[0]) / d);
        (hz(y0), hz(x0 + y0))
    }
}

/// Hertz in Bark (H. Traunmüller 1990, JASA 88(1) 97-100, doi:10.1121/1.399849, with his corrections at the ends).
pub fn bark(hz: f64) -> f64 {
    let z = 26.81 * hz / (1960.0 + hz) - 0.53;
    if z < 2.0 {
        z + 0.15 * (2.0 - z)
    } else if z > 20.1 {
        z + 0.22 * (z - 20.1)
    } else {
        z
    }
}

/// Bark in hertz: `bark`'s inverse, its corrections undone first.
pub fn hz(bark: f64) -> f64 {
    let z = if bark < 2.0 {
        (bark - 0.3) / 0.85
    } else if bark > 20.1 {
        (bark + 4.422) / 1.22
    } else {
        bark
    };
    1960.0 * (z + 0.53) / (26.28 - z)
}

fn fields<'a>(doc: &'a Value, key: &str) -> Result<impl Iterator<Item = (&'a String, &'a Value)>, String> {
    let o = doc.get(key).and_then(Value::as_object).ok_or_else(|| format!("vowel space: no `{key}`"))?;
    Ok(o.iter().filter(|(k, _)| *k != "about"))
}

fn one_char(s: &str, what: &str) -> Result<char, String> {
    let mut c = s.chars();
    match (c.next(), c.next()) {
        (Some(x), None) => Ok(x),
        _ => Err(format!("vowel space: {what} [{s}] is not one character")),
    }
}

fn place_of(v: &Value, what: &str) -> Result<Place, String> {
    let a: Vec<f64> = v.as_array().map(|a| a.iter().filter_map(Value::as_f64).collect()).unwrap_or_default();
    match a[..] {
        [row, column, rounding] => Ok(Place::new(row, column, rounding)),
        _ => Err(format!("vowel space: {what}: a place is [row, column, rounding]")),
    }
}

impl Space {
    pub fn parse(text: &str) -> Result<Space, String> {
        let doc: Value = serde_json::from_str(text).map_err(|e| format!("vowel space: {e}"))?;
        let num = |path: &[&str]| -> Result<f64, String> {
            let mut v = &doc;
            for k in path {
                v = v.get(k).ok_or_else(|| format!("vowel space: no `{}`", path.join(".")))?;
            }
            v.as_f64().ok_or_else(|| format!("vowel space: `{}` is not a number", path.join(".")))
        };
        let mut vowels = BTreeMap::new();
        for (k, v) in fields(&doc, "vowels")? {
            vowels.insert(one_char(k, "the vowel")?, place_of(v, k)?);
        }
        let mut marks = BTreeMap::new();
        for (k, v) in fields(&doc, "diacritics")? {
            let get = |f: &str| v.get(f).and_then(Value::as_f64).unwrap_or(0.0);
            let mark = match v.get("toward").and_then(Value::as_str) {
                Some("central") => Mark::Toward { to: None, share: get("share") },
                Some(letter) => {
                    let to = *vowels.get(&one_char(letter, "a diacritic's `toward`")?).ok_or_else(|| format!("vowel space: [{k}] toward [{letter}], no vowel"))?;
                    Mark::Toward { to: Some(to), share: get("share") }
                }
                None => Mark::Shift { row: get("row"), column: get("column"), rounding: get("rounding"), rhotic: get("rhotic") },
            };
            marks.insert(one_char(k, "the diacritic")?, mark);
        }
        let mut precomposed = BTreeMap::new();
        for (k, v) in fields(&doc, "precomposed")? {
            precomposed.insert(one_char(k, "the precomposed letter")?, v.as_str().ok_or("vowel space: a precomposed letter's parts")?.to_string());
        }
        let ignored = doc.pointer("/ignored/marks").and_then(Value::as_str).ok_or("vowel space: no `ignored.marks`")?.chars().collect();
        let anchors = doc.get("anchors").ok_or("vowel space: no `anchors`")?;
        let sources = anchors.get("sources").and_then(Value::as_array).ok_or("vowel space: no `anchors.sources`")?;
        let sources: Vec<String> = sources.iter().filter_map(|s| s.as_str().map(String::from)).collect();
        for s in &sources {
            if !inventory::inventory().sources.contains_key(s) {
                return Err(format!("vowel space: anchors' source {s} is not the inventory's"));
            }
        }
        let by_sound = match anchors.get("placed").and_then(Value::as_str) {
            Some("sound") => true,
            Some("symbol") => false,
            _ => return Err("vowel space: `anchors.placed` is \"sound\" or \"symbol\"".into()),
        };
        let corners = anchors.get("corners").and_then(Value::as_array).ok_or("vowel space: no `anchors.corners`")?;
        let mut moved = BTreeMap::new();
        for (k, v) in fields(anchors, "places")? {
            moved.insert(k.clone(), place_of(v, k)?);
        }
        let rhotic = match anchors.get("rhotic") {
            None => None,
            Some(r) => Some(r.get("shape").and_then(Value::as_str).ok_or("vowel space: `anchors.rhotic` names its `shape`")?.to_string()),
        };
        let extension_steps = anchors.pointer("/extension/steps").and_then(Value::as_u64).filter(|&n| n >= 1).ok_or("vowel space: `anchors.extension.steps` is a whole number, 1 or more")? as usize;
        let whole = |key: &str| doc.pointer(&format!("/heard/{key}")).and_then(Value::as_u64).map(|n| n as usize).ok_or_else(|| format!("vowel space: `heard.{key}` is a whole number"));
        let hearing = Hearing {
            cents: num(&["heard", "cents"])?,
            steps: whole("steps")?,
            probe: num(&["heard", "probe"])?,
            halvings: whole("halvings")?,
            tune_steps: whole("tune_steps")?,
            cents_per_range: num(&["heard", "cents_per_range"])?,
        };
        let chart = Chart {
            open_row: num(&["chart", "open_row"])?,
            row_height: num(&["chart", "row_height"])?,
            back_x: num(&["chart", "back_x"])?,
            front_x_close: num(&["chart", "front_x_close"])?,
            front_x_open: num(&["chart", "front_x_open"])?,
        };
        let mut space = Space {
            chart,
            vowels,
            marks,
            precomposed,
            ignored,
            sources,
            moved,
            by_sound,
            corners: Vec::new(),
            rhotic,
            extension_steps,
            hearing,
        };
        for c in corners {
            let letter = c.as_str().ok_or("vowel space: a corner is a vowel's letter")?;
            space.corners.push(space.place(letter)?);
        }
        if space.corners.len() != 3 {
            return Err("vowel space: three corners fix the map from sound to the chart".into());
        }
        Ok(space)
    }

    /// The place of one vowel written in IPA: its letter, displaced by its marks; marks that leave a vowel where it
    /// is passed over. An error where it holds no vowel letter, more than one, or a mark the space does not know.
    pub fn place(&self, ipa: &str) -> Result<Place, String> {
        self.place_with(ipa, |_| None).map(|(p, _)| self.bounded(p))
    }

    /// The place of a vowel written in IPA as a language says it at a clarity: its letter where measured speakers of
    /// the language put it, spread apart by the clarity (`Places`), else the chart's; its marks displacing it as they do.
    /// A measured letter's place may lie beyond the chart, as a clear speaker's vowels lie beyond another's: a
    /// speaker's space reaches as far as its own extends (`anchors.extension`).
    pub fn place_in(&self, ipa: &str, language: &str, clarity: f64) -> Result<Place, String> {
        let measured = places().language(language);
        let (p, by_measure) = self.place_with(ipa, |c| measured.and_then(|m| m.place(c, clarity)))?;
        Ok(match by_measure {
            true => Place { rounding: p.rounding.clamp(0.0, 1.0), rhotic: p.rhotic.clamp(0.0, 1.0), ..p },
            false => self.bounded(p),
        })
    }

    /// A vowel's place, and whether its letter's came from `letter`.
    fn place_with(&self, ipa: &str, letter: impl Fn(char) -> Option<Place>) -> Result<(Place, bool), String> {
        let mut chars = Vec::new();
        for c in ipa.chars() {
            match self.precomposed.get(&c) {
                Some(parts) => chars.extend(parts.chars()),
                None => chars.push(c),
            }
        }
        let (mut place, mut given): (Option<Place>, bool) = (None, false);
        for c in chars {
            if let Some(p) = self.vowels.get(&c) {
                if place.is_some() {
                    return Err(format!("[{ipa}]: more than one vowel"));
                }
                let from = letter(c);
                given = from.is_some();
                place = Some(from.unwrap_or(*p));
            } else if let Some(m) = self.marks.get(&c) {
                let p = place.as_mut().ok_or_else(|| format!("[{ipa}]: a mark before its vowel"))?;
                match m {
                    Mark::Shift { row, column, rounding, rhotic } => {
                        p.row += row;
                        p.column += column;
                        p.rounding += rounding;
                        p.rhotic += rhotic;
                    }
                    Mark::Toward { to: None, share } => p.column += share * (1.0 - p.column),
                    Mark::Toward { to: Some(to), share } => {
                        p.row += share * (to.row - p.row);
                        p.column += share * (to.column - p.column);
                    }
                }
            } else if !self.ignored.contains(&c) {
                return Err(format!("[{ipa}]: [{c}] (U+{:04X}) is neither a vowel nor a mark the vowel space knows", c as u32));
            }
        }
        Ok((place.ok_or_else(|| format!("[{ipa}]: no vowel"))?, given))
    }

    /// The IPA's vowel letters, each at its place.
    pub fn letters(&self) -> impl Iterator<Item = (char, Place)> + '_ {
        self.vowels.iter().map(|(c, p)| (*c, *p))
    }

    /// The chart's open row (its close row 0).
    pub fn open_row(&self) -> f64 {
        self.chart.open_row
    }

    /// A place kept on the chart: its row, column, rounding and rhoticity each within its range.
    pub fn bounded(&self, p: Place) -> Place {
        Place { row: p.row.clamp(0.0, self.chart.open_row), column: p.column.clamp(0.0, 2.0), rounding: p.rounding.clamp(0.0, 1.0), rhotic: p.rhotic.clamp(0.0, 1.0) }
    }

    /// Where a place is drawn on the chart: across from the front edge, down from the close row.
    pub fn chart(&self, p: Place) -> (f64, f64) {
        self.chart.xy(p)
    }

    /// A speaker's anchors: the inventory's vowels from the anchors' sources that the speaker has a shape of, each
    /// shape once, at its phone's IPA's place (or its own, `anchors.places`).
    pub fn anchors(&self, shape: impl Fn(&str) -> Option<[f64; NUM_PARAMS]>) -> Vec<Anchor> {
        let mut out: Vec<Anchor> = Vec::new();
        for p in inventory::inventory().phones.values() {
            if p.kind != Kind::Vowel || !self.sources.contains(&p.source) {
                continue;
            }
            let Some(name) = p.vowel_shape() else { continue };
            if out.iter().any(|a| a.name == name) {
                continue;
            }
            let Some(params) = shape(name) else { continue };
            let place = match self.moved.get(name) {
                Some(&at) => Ok(at),
                None => p.ipa.first().ok_or_else(|| format!("{name}: no IPA")).and_then(|ipa| self.place(ipa)),
            };
            let place = place.unwrap_or_else(|e| panic!("vowel space: anchor {name}: {e}"));
            out.push(Anchor { name: name.to_string(), place, params });
        }
        out
    }

    /// Whether the anchors are to be placed by their sound.
    pub fn by_sound(&self) -> bool {
        self.by_sound
    }

    /// The map from a speaker's vowels' sounds to the chart: each anchor's first two resonances (`sounds`, Hz, in the
    /// anchors' order) in Bark, F1 down and F2 - F1 across, as Ladefoged charts vowels, carried onto the chart by the one
    /// map (a turn, a stretch and a shift) that puts the corners -- the anchors at the corners' letters' places -- at
    /// those places.
    pub fn sound_map(&self, anchors: &[Anchor], sounds: &[(f64, f64)]) -> Result<SoundMap, String> {
        if sounds.len() != anchors.len() {
            return Err(format!("the vowel space: {} sounds for {} anchors", sounds.len(), anchors.len()));
        }
        let mut corners = Vec::new();
        for c in &self.corners {
            let k = anchors.iter().position(|a| a.place == *c).ok_or_else(|| format!("the vowel space: the speaker has no vowel at the corner {c:?}"))?;
            corners.push(sounds[k]);
        }
        self.corner_map(&corners)
    }

    /// The map that puts three sounds (each its first two resonances, Hz) at the corners' places, in their order.
    fn corner_map(&self, sounds: &[(f64, f64)]) -> Result<SoundMap, String> {
        let from: Vec<((f64, f64), (f64, f64))> = sounds.iter().zip(&self.corners).map(|(&(f1, f2), c)| ((bark(f2) - bark(f1), bark(f1)), self.chart.xy(*c))).collect();
        // (Each chart coordinate a x + b y + c of the sound's: three equations, one for each corner, by Cramer's rule.)
        let det3 = |m: [[f64; 3]; 3]| m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]) - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0]) + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);
        let rows: [[f64; 3]; 3] = [0, 1, 2].map(|k| [from[k].0 .0, from[k].0 .1, 1.0]);
        let d = det3(rows);
        if d.abs() < 1e-9 {
            return Err("the vowel space: the corners' sounds are in a line".into());
        }
        let solve = |out: [f64; 3]| -> [f64; 3] {
            [0, 1, 2].map(|j| {
                let mut m = rows;
                for k in 0..3 {
                    m[k][j] = out[k];
                }
                det3(m) / d
            })
        };
        Ok(SoundMap { chart: self.chart, x: solve([0, 1, 2].map(|k| from[k].1 .0)), y: solve([0, 1, 2].map(|k| from[k].1 .1)) })
    }

    /// The anchors placed by their sound (`anchors.placed` "sound") by the speaker's sound map, each keeping its
    /// rounding; a shape at a place of its own (`anchors.places`) stays. The map, for the speaker's other shapes.
    pub fn place_by_sound(&self, anchors: &mut [Anchor], sounds: &[(f64, f64)]) -> Result<SoundMap, String> {
        let map = self.sound_map(anchors, sounds)?;
        for (a, &sound) in anchors.iter_mut().zip(sounds) {
            if !self.moved.contains_key(&a.name) {
                a.place = map.place(sound, a.place.rounding);
            }
        }
        Ok(map)
    }

    /// The shape r-colouring is measured from, a speaker's own (`anchors.rhotic.shape`).
    pub fn rhotic_shape(&self) -> Option<&str> {
        self.rhotic.as_deref()
    }

    /// Where the rhotic shape is uncoloured: where its sound puts it (by the speaker's sound map, where the anchors are
    /// placed by their sound), else its IPA's place; its rounding its IPA's.
    pub fn rhotic_place(&self, map: Option<&SoundMap>, sound: (f64, f64)) -> Result<Place, String> {
        let name = self.rhotic.as_deref().ok_or("the vowel space has no rhotic shape")?;
        let ipa = inventory::phone(name).and_then(|p| p.ipa.first()).ok_or_else(|| format!("the vowel space: the rhotic shape {name} is no phone's"))?;
        let own = Place { rhotic: 0.0, ..self.place(ipa)? };
        Ok(match (self.by_sound, map) {
            (true, Some(m)) => m.place(sound, own.rounding),
            _ => own,
        })
    }

    /// A speaker's space from its anchors.
    pub fn speaker(&self, anchors: &[Anchor]) -> Result<SpeakerSpace, String> {
        SpeakerSpace::new(self, anchors)
    }

    /// A speaker's space from its own shapes, as its engine sounds them: its anchors (Space::anchors) placed by their
    /// sound where `anchors.placed` is "sound", its r-colouring measured from its rhotic shape where it has one.
    pub fn of_speaker(&self, tract: &mut VocalTract) -> Result<Sounded, String> {
        let mut anchors = self.anchors(|n| tract.shape(n));
        let corners = anchors.iter().filter(|a| self.corners.contains(&a.place)).map(|a| a.name.clone()).collect();
        let map = match self.by_sound {
            true => {
                let sounds = anchors.iter().map(|a| sound(tract, &a.params)).collect::<Result<Vec<_>, _>>()?;
                Some(self.place_by_sound(&mut anchors, &sounds)?)
            }
            false => None,
        };
        let mut space = self.speaker(&anchors)?;
        if let Some(m) = &map {
            self.extend(&mut space, &anchors, tract, m);
        }
        if let Some(r) = self.rhotic.as_deref().and_then(|n| tract.shape(n)) {
            let at = self.rhotic_place(map.as_ref(), sound(tract, &r)?)?;
            space.colour(r, at);
        }
        Ok(Sounded { space, map, corners })
    }

    /// The space beyond a speaker's own vowels (`anchors.extension`): each vertex of its hull pushed out from the hull's
    /// centre, its parameters with it -- the centre's shape (at the vertex's rounding) plus the push times the vertex's
    /// less the centre's, within the parameters' ranges -- by the most measured clarity's spread at most
    /// (`Places::most_spread`), and only as far as the pushed shape, sounded on the speaker's engine, lies beyond the
    /// vertex where its sound puts it (`map`), and as long as it stays a vowel: its least closable area no narrower than
    /// languages/carry.json's `least_area_share` of the narrowest of the speaker's own vowels (narrower, it would close
    /// the tract to a fricative's channel, or shut the lips, its resonances a stop's, which the map puts beyond anything).
    /// The shares of the push are tried the farthest first, the vertex itself where none does. No search: each share is
    /// tried once.
    fn extend(&self, sp: &mut SpeakerSpace, anchors: &[Anchor], tract: &mut VocalTract, map: &SoundMap) {
        let most = places().most_spread();
        let narrowest = anchors.iter().map(|a| least_area(tract, &a.params)).fold(f64::INFINITY, f64::min);
        let open = carry::settings().tune.least_area_share * narrowest;
        let n = sp.hull.len() as f64;
        let centre = (sp.hull.iter().map(|v| v.0).sum::<f64>() / n, sp.hull.iter().map(|v| v.1).sum::<f64>() / n);
        let (mut inner, mut outer) = (Vec::new(), Vec::new());
        for &v in &sp.hull {
            let near = |q: (f64, f64)| (q.0 - v.0).abs() < 1e-6 && (q.1 - v.1).abs() < 1e-6;
            let params = sp.points.iter().find(|p| near(p.0)).map(|p| p.1).expect("a hull vertex is one of the space's points");
            let rounds: Vec<f64> = anchors.iter().filter(|a| near(self.chart.xy(a.place))).map(|a| a.place.rounding).collect();
            let rounding = rounds.iter().sum::<f64>() / rounds.len().max(1) as f64;
            let from = sp.at(Place { rhotic: 0.0, ..self.chart.place(centre, rounding) });
            let (dx, dy) = (v.0 - centre.0, v.1 - centre.1);
            let mut pushed = (v, params);
            for k in (1..=self.extension_steps).rev() {
                let s = 1.0 + (most - 1.0) * k as f64 / self.extension_steps as f64;
                let shape: [f64; NUM_PARAMS] = std::array::from_fn(|j| (from[j] + s * (params[j] - from[j])).clamp(tract.param[j].min, tract.param[j].max));
                if least_area(tract, &shape) < open {
                    continue;
                }
                let Ok(heard) = sound(tract, &shape) else { continue };
                let at = self.chart.xy(map.place(heard, rounding));
                if (at.0 - v.0) * dx + (at.1 - v.1) * dy > 0.0 {
                    pushed = ((centre.0 + s * dx, centre.1 + s * dy), shape);
                    break;
                }
            }
            inner.push(params);
            outer.push(pushed);
        }
        sp.ring = Some(Ring { centre, vertices: sp.hull.clone(), inner, outer });
    }

    /// Places weighed (in proportion): their row and column as drawn on the chart, their rounding and rhoticity.
    pub fn mean_place(&self, places: &[(Place, f64)]) -> Option<Place> {
        let total: f64 = places.iter().map(|(_, w)| w).sum();
        if places.is_empty() || total <= 0.0 {
            return None;
        }
        let mean = |f: &dyn Fn(&Place) -> f64| places.iter().map(|(p, w)| f(p) * w).sum::<f64>() / total;
        let at = self.chart.place((mean(&|p| self.chart.xy(*p).0), mean(&|p| self.chart.xy(*p).1)), mean(&|p| p.rounding));
        Some(Place { rhotic: mean(&|p| p.rhotic), ..at })
    }
}

/// What a vowel asked for by its IPA is said with in a language (its BCP 47 tag, or none, ""): the speaker's own shape
/// of the language's own phone for it, where the speaker `has` that shape (its name), as the reader's phrases say it;
/// else its place in the language at the clarity, for the speaker's space to make its shape at. An error where the IPA
/// is not one vowel.
#[derive(Clone, Debug, PartialEq)]
pub enum Said {
    Own(String),
    At(Place),
}

pub fn said_with(ipa: &str, language: &str, clarity: f64, has: impl Fn(&str) -> bool) -> Result<Said, String> {
    let own = match crate::phones::phones_in(ipa, language) {
        Some((found, false)) if found.len() == 1 => inventory::phone(found[0]).filter(|p| p.kind == Kind::Vowel).and_then(|p| p.vowel_shape()).filter(|s| has(s)),
        _ => None,
    };
    match own {
        Some(shape) => Ok(Said::Own(shape.to_string())),
        None => space().place_in(ipa, language, clarity).map(Said::At),
    }
}

/// A speaker's vowels as its engine sounds them (Space::of_speaker): its space, the map from its vowels' sounds to the
/// chart (where the anchors are placed by their sound), and its shapes at the space's corners.
#[derive(Clone, Debug)]
pub struct Sounded {
    pub space: SpeakerSpace,
    pub map: Option<SoundMap>,
    pub corners: Vec<String>,
}

/// A vowel made from a speaker's space and brought to sound at its place (Sounded::heard): its shape, the place the
/// space was read at to make it, its first two resonances' distance (cents) from those the speaker's map puts at the
/// place as first read and as brought, the times it was sounded in reading the space, and the least-squares steps that
/// moved its shape's own parameters where reading the space did not bring it there (none where it did).
#[derive(Clone, Debug)]
pub struct Heard {
    pub shape: [f64; NUM_PARAMS],
    pub read: Place,
    pub before: [f64; 2],
    pub after: [f64; 2],
    pub soundings: usize,
    pub tuned: usize,
}

impl Sounded {
    /// The speaker's shape at a place, brought to sound there (SpeakerSpace::heard); where the space has no map (its
    /// anchors not placed by their sound), the shape read at the place.
    pub fn heard(&self, tract: &mut VocalTract, place: Place) -> Result<Heard, String> {
        match &self.map {
            Some(map) => self.space.heard(map, tract, place),
            None => Ok(Heard { shape: self.space.at(place), read: place, before: [0.0; 2], after: [0.0; 2], soundings: 0, tuned: 0 }),
        }
    }
}

/// A shape's least closable area on a speaker's engine (carry::least_closable_area), its parameters held within their
/// ranges.
fn least_area(tract: &mut VocalTract, shape: &[f64; NUM_PARAMS]) -> f64 {
    let v: [f64; NUM_PARAMS] = std::array::from_fn(|k| shape[k].clamp(tract.param[k].min, tract.param[k].max));
    tract.calculate(&v);
    carry::least_closable_area(&tract.tube())
}

/// A shape's first two resonances on a speaker's engine (carry::resonances_fine, below languages/carry.json's
/// `top_hz`: moving smoothly with the shape, as bringing a made vowel to its place steps by them), its parameters held
/// within their ranges.
pub fn sound(tract: &mut VocalTract, shape: &[f64; NUM_PARAMS]) -> Result<(f64, f64), String> {
    let v: [f64; NUM_PARAMS] = std::array::from_fn(|k| shape[k].clamp(tract.param[k].min, tract.param[k].max));
    tract.calculate(&v);
    match carry::resonances_fine(&tract.tube(), carry::settings().top_hz)[..] {
        [f1, f2, ..] => Ok((f1, f2)),
        _ => Err("the vowel space: a shape with fewer than two resonances".into()),
    }
}

/// A language's vowels where measured speakers put them: each one's place on the chart at clarity 0, and their centre
/// as drawn.
#[derive(Clone, Debug)]
pub struct LanguageVowels {
    pub source: String,
    places: BTreeMap<char, Place>,
    centre: (f64, f64),
    chart: Chart,
    /// The measured clear speech's mean increase in vowel space area, and the most clarity allowed.
    clear: f64,
    most: f64,
}

impl LanguageVowels {
    /// A vowel letter's place at a clarity: moved from the language's centre by the square root of one plus the clarity
    /// times clear speech's measured increase in area (clarity between 0 and the most measured); none where unmeasured.
    pub fn place(&self, letter: char, clarity: f64) -> Option<Place> {
        let p = *self.places.get(&letter)?;
        let spread = (1.0 + clarity.clamp(0.0, self.most) * self.clear).sqrt();
        let (x, y) = self.chart.xy(p);
        let (cx, cy) = self.centre;
        Some(self.chart.place((cx + spread * (x - cx), cy + spread * (y - cy)), p.rounding))
    }

    /// The letters measured.
    pub fn letters(&self) -> impl Iterator<Item = char> + '_ {
        self.places.keys().copied()
    }
}

/// Each language's vowels where measured speakers put them (languages/vowel-places.json).
#[derive(Debug)]
pub struct Places {
    languages: BTreeMap<String, LanguageVowels>,
    most: f64,
    /// How far the most clarity spreads a language's vowels from their centre.
    most_spread: f64,
}

impl Places {
    /// The measurements carried onto the space's chart: each group's vowels by the map that puts its corners' sounds at
    /// the space's corners (Space::sound_map's, from the group's own [i u ä]), a vowel's place its groups' mean as drawn,
    /// its rounding its letter's.
    pub fn parse(text: &str, space: &Space) -> Result<Places, String> {
        let doc: Value = serde_json::from_str(text).map_err(|e| format!("vowel places: {e}"))?;
        let clarity = doc.get("clarity").ok_or("vowel places: no `clarity`")?;
        let mean_increase = |name: &str| -> Result<f64, String> {
            let o = clarity.pointer(&format!("/area_increase/{name}")).and_then(Value::as_object).ok_or_else(|| format!("vowel places: no `clarity.area_increase.{name}`"))?;
            let v: Vec<f64> = o.values().filter_map(Value::as_f64).collect();
            if v.is_empty() || v.len() != o.len() {
                return Err(format!("vowel places: `clarity.area_increase.{name}` are numbers"));
            }
            Ok(v.iter().sum::<f64>() / v.len() as f64)
        };
        let clear = mean_increase("clear")?;
        let most_name = clarity.get("most").and_then(Value::as_str).ok_or("vowel places: no `clarity.most`")?;
        let most = mean_increase(most_name)? / clear;
        let mut languages = BTreeMap::new();
        for (tag, l) in fields(&doc, "languages")? {
            let source = l.get("source").and_then(Value::as_str).unwrap_or_default().to_string();
            let corners = l.get("corners").and_then(Value::as_object).ok_or_else(|| format!("vowel places: {tag}: no `corners`"))?;
            let mut drawn: BTreeMap<char, Vec<(f64, f64)>> = BTreeMap::new();
            for (group, vowels) in fields(l, "groups")? {
                let vowels = vowels.as_object().ok_or_else(|| format!("vowel places: {tag} {group}: its vowels"))?;
                let sound = |letter: &str| -> Result<(f64, f64), String> {
                    let a: Vec<f64> = vowels.get(letter).and_then(Value::as_array).map(|a| a.iter().filter_map(Value::as_f64).collect()).unwrap_or_default();
                    match a[..] {
                        [f1, f2] => Ok((f1, f2)),
                        _ => Err(format!("vowel places: {tag} {group} [{letter}]: [F1, F2] in Hz")),
                    }
                };
                // (The group's vowels at the space's corners, in the space's order.)
                let mut at_corners = Vec::new();
                for c in &space.corners {
                    let letter = corners.iter().find(|(k, _)| space.place(k).ok() == Some(*c)).and_then(|(_, v)| v.as_str()).ok_or_else(|| format!("vowel places: {tag}: no vowel named for the corner {c:?}"))?;
                    at_corners.push(sound(letter)?);
                }
                let map = space.corner_map(&at_corners).map_err(|e| format!("vowel places: {tag} {group}: {e}"))?;
                for letter in vowels.keys() {
                    let c = one_char(letter, "a measured vowel")?;
                    let own = *space.vowels.get(&c).ok_or_else(|| format!("vowel places: {tag} [{letter}] is no vowel of the space's"))?;
                    drawn.entry(c).or_default().push(space.chart.xy(map.place(sound(letter)?, own.rounding)));
                }
            }
            let mut places = BTreeMap::new();
            for (c, xy) in &drawn {
                let n = xy.len() as f64;
                let mean = (xy.iter().map(|p| p.0).sum::<f64>() / n, xy.iter().map(|p| p.1).sum::<f64>() / n);
                places.insert(*c, space.chart.place(mean, space.vowels[c].rounding));
            }
            let n = places.len() as f64;
            let xy: Vec<(f64, f64)> = places.values().map(|p| space.chart.xy(*p)).collect();
            let centre = (xy.iter().map(|p| p.0).sum::<f64>() / n, xy.iter().map(|p| p.1).sum::<f64>() / n);
            languages.insert(tag.clone(), LanguageVowels { source, places, centre, chart: space.chart, clear, most });
        }
        Ok(Places { languages, most, most_spread: (1.0 + most * clear).sqrt() })
    }

    /// A language's measured vowels: its full tag's, else its primary language's ("en-us", "en").
    pub fn language(&self, tag: &str) -> Option<&LanguageVowels> {
        self.languages.get(tag).or_else(|| self.languages.get(tag.split('-').next().unwrap_or(tag)))
    }

    /// The languages measured, by their tags.
    pub fn languages(&self) -> impl Iterator<Item = &str> {
        self.languages.keys().map(String::as_str)
    }

    /// How far the most clarity spreads a language's vowels from their centre (a factor of their distance).
    pub fn most_spread(&self) -> f64 {
        self.most_spread
    }

    /// The most clarity a language's vowels are spread by: the most measured increase over clear speech's.
    pub fn most_clarity(&self) -> f64 {
        self.most
    }
}

pub fn places() -> &'static Places {
    static PLACES: OnceLock<Places> = OnceLock::new();
    PLACES.get_or_init(|| Places::parse(&language_file("vowel-places.json", include_str!("../languages/vowel-places.json")), space()).unwrap_or_else(|e| panic!("languages/vowel-places.json: {e}")))
}

pub fn space() -> &'static Space {
    static SPACE: OnceLock<Space> = OnceLock::new();
    SPACE.get_or_init(|| Space::parse(&language_file("vowel-space.json", include_str!("../languages/vowel-space.json"))).unwrap_or_else(|e| panic!("languages/vowel-space.json: {e}")))
}

/// One of a speaker's own vowels, at its place.
#[derive(Clone, Debug)]
pub struct Anchor {
    pub name: String,
    pub place: Place,
    pub params: [f64; NUM_PARAMS],
}

fn is_lip(k: usize) -> bool {
    k == LP || k == LD
}

/// A speaker's vowels as a space: the tongue's parameters over the anchors' triangulation on the chart, the lips'
/// along the rows, unrounded and rounded.
#[derive(Clone, Debug)]
pub struct SpeakerSpace {
    chart: Chart,
    /// The anchors' places on the chart (those at one place as one, their mean), and the parameters there.
    points: Vec<((f64, f64), [f64; NUM_PARAMS])>,
    triangles: Vec<[usize; 3]>,
    /// The points' convex hull, anticlockwise.
    hull: Vec<(f64, f64)>,
    /// The lips (LP, LD) at each row an anchor is on, unrounded and rounded (their mean where several are).
    lips: [Vec<(f64, [f64; 2])>; 2],
    /// R-colouring: the rhotic shape less the space's shape where it is uncoloured.
    rhotic: Option<[f64; NUM_PARAMS]>,
    /// The space beyond the speaker's own vowels, where it is extended (Space::extend).
    ring: Option<Ring>,
    /// How a vowel made from it is brought to sound at its place (`heard`).
    hearing: Hearing,
}

/// The space beyond a speaker's own vowels: its hull's vertices, each pushed out from the hull's centre along its ray
/// (Space::extend), with the parameters at each.
#[derive(Clone, Debug)]
struct Ring {
    centre: (f64, f64),
    /// The hull's vertices, anticlockwise, and the parameters at each.
    vertices: Vec<(f64, f64)>,
    inner: Vec<[f64; NUM_PARAMS]>,
    /// Each vertex pushed (itself where it is not), and the parameters there.
    outer: Vec<((f64, f64), [f64; NUM_PARAMS])>,
}

impl Ring {
    /// The vertex whose ray, and the next's, a point lies between, seen from the centre.
    fn sector(&self, q: (f64, f64)) -> usize {
        let n = self.vertices.len();
        let between = |i: usize| cross(self.centre, self.vertices[i], q).min(-cross(self.centre, self.vertices[(i + 1) % n], q));
        (0..n).max_by(|&a, &b| between(a).total_cmp(&between(b))).unwrap_or(0)
    }

    /// A point within the pushed vertices' polygon (its sector's outer edge on the centre's side), or where its ray from
    /// the centre meets that edge: places beyond in different directions stay apart, as a nearest point would not keep
    /// them (two vowels spread past a vertex that could not be pushed would meet at it).
    fn within(&self, q: (f64, f64)) -> (f64, f64) {
        let n = self.outer.len();
        let i = self.sector(q);
        let (a, b) = (self.outer[i].0, self.outer[(i + 1) % n].0);
        let (from, to) = (cross(a, b, self.centre), cross(a, b, q));
        if to >= -1e-12 || from <= to {
            return q;
        }
        let t = from / (from - to);
        (self.centre.0 + t * (q.0 - self.centre.0), self.centre.1 + t * (q.1 - self.centre.1))
    }

    /// The parameters at a point beyond the hull and within the pushed polygon: in its sector, between the hull edge's
    /// two vertices and their pushed points (the triangle of the two it is most within); and the lips' push there, the
    /// pushed points' lips less their vertices', weighed alike.
    fn at(&self, q: (f64, f64)) -> ([f64; NUM_PARAMS], [f64; 2]) {
        let n = self.vertices.len();
        let i = self.sector(q);
        let j = (i + 1) % n;
        // (The corners as (point, the vertex they are, pushed or not).)
        let (vi, vj, oi, oj) = ((self.vertices[i], i, false), (self.vertices[j], j, false), (self.outer[i].0, i, true), (self.outer[j].0, j, true));
        let mut best: Option<(f64, [f64; 3], [((f64, f64), usize, bool); 3])> = None;
        for t in [[vi, vj, oj], [vi, oj, oi]] {
            let [a, b, c] = t.map(|c| c.0);
            let area = cross(a, b, c);
            if area.abs() < 1e-12 {
                continue;
            }
            let w = [cross(q, b, c) / area, cross(a, q, c) / area, cross(a, b, q) / area];
            let least = w.iter().cloned().fold(f64::MAX, f64::min);
            if best.as_ref().is_none_or(|b| least > b.0) {
                best = Some((least, w, t));
            }
        }
        // (No pushed point on either side: the hull's edge itself.)
        let (w, t) = match best {
            Some((_, w, t)) => (w, t),
            None => {
                let ab = (vj.0 .0 - vi.0 .0, vj.0 .1 - vi.0 .1);
                let f = (((q.0 - vi.0 .0) * ab.0 + (q.1 - vi.0 .1) * ab.1) / (ab.0 * ab.0 + ab.1 * ab.1)).clamp(0.0, 1.0);
                ([1.0 - f, f, 0.0], [vi, vj, vj])
            }
        };
        let (mut out, mut lips) = ([0.0; NUM_PARAMS], [0.0; 2]);
        for (w, &(_, k, pushed)) in w.iter().zip(&t) {
            let p = if pushed { &self.outer[k].1 } else { &self.inner[k] };
            for (o, x) in out.iter_mut().zip(p) {
                *o += w * x;
            }
            if pushed {
                lips[0] += w * (self.outer[k].1[LP] - self.inner[k][LP]);
                lips[1] += w * (self.outer[k].1[LD] - self.inner[k][LD]);
            }
        }
        (out, lips)
    }
}

/// Whether a point is within a convex polygon (anticlockwise), on its edges too.
fn inside(polygon: &[(f64, f64)], q: (f64, f64)) -> bool {
    let n = polygon.len();
    (0..n).all(|i| cross(polygon[i], polygon[(i + 1) % n], q) >= -1e-12)
}

fn mean_by<K: PartialEq + Copy, const N: usize>(items: impl Iterator<Item = (K, [f64; N])>) -> Vec<(K, [f64; N])> {
    let mut sums: Vec<(K, [f64; N], f64)> = Vec::new();
    for (k, v) in items {
        match sums.iter_mut().find(|(j, _, _)| *j == k) {
            Some((_, s, n)) => {
                s.iter_mut().zip(v).for_each(|(a, b)| *a += b);
                *n += 1.0;
            }
            None => sums.push((k, v, 1.0)),
        }
    }
    sums.into_iter().map(|(k, s, n)| (k, s.map(|x| x / n))).collect()
}

fn cross(o: (f64, f64), a: (f64, f64), b: (f64, f64)) -> f64 {
    (a.0 - o.0) * (b.1 - o.1) - (a.1 - o.1) * (b.0 - o.0)
}

/// Delaunay's triangulation (Bowyer and Watson's), each triangle anticlockwise.
fn delaunay(points: &[(f64, f64)]) -> Vec<[usize; 3]> {
    let n = points.len();
    let (mut lo, mut hi) = ((f64::MAX, f64::MAX), (f64::MIN, f64::MIN));
    for p in points {
        lo = (lo.0.min(p.0), lo.1.min(p.1));
        hi = (hi.0.max(p.0), hi.1.max(p.1));
    }
    let d = (hi.0 - lo.0).max(hi.1 - lo.1).max(1.0) * 1000.0;
    let mid = ((lo.0 + hi.0) / 2.0, (lo.1 + hi.1) / 2.0);
    let mut p = points.to_vec();
    p.extend([(mid.0 - 2.0 * d, mid.1 - d), (mid.0 + 2.0 * d, mid.1 - d), (mid.0, mid.1 + 2.0 * d)]);
    let anticlockwise = |t: [usize; 3], p: &[(f64, f64)]| if cross(p[t[0]], p[t[1]], p[t[2]]) < 0.0 { [t[0], t[2], t[1]] } else { t };
    let mut triangles = vec![anticlockwise([n, n + 1, n + 2], &p)];
    for i in 0..n {
        let q = p[i];
        let in_circle = |t: &[usize; 3]| {
            let [a, b, c] = t.map(|k| (p[k].0 - q.0, p[k].1 - q.1));
            let det = (a.0 * a.0 + a.1 * a.1) * (b.0 * c.1 - c.0 * b.1) - (b.0 * b.0 + b.1 * b.1) * (a.0 * c.1 - c.0 * a.1) + (c.0 * c.0 + c.1 * c.1) * (a.0 * b.1 - b.0 * a.1);
            det > 0.0
        };
        let (bad, good): (Vec<[usize; 3]>, Vec<[usize; 3]>) = triangles.into_iter().partition(in_circle);
        let edges: Vec<(usize, usize)> = bad.iter().flat_map(|t| [(t[0], t[1]), (t[1], t[2]), (t[2], t[0])]).collect();
        triangles = good;
        for &(a, b) in &edges {
            if edges.iter().filter(|&&(c, d)| (c == a && d == b) || (c == b && d == a)).count() == 1 {
                triangles.push(anticlockwise([a, b, i], &p));
            }
        }
    }
    triangles.retain(|t| t.iter().all(|&k| k < n) && cross(p[t[0]], p[t[1]], p[t[2]]) > 1e-12);
    triangles
}

/// The convex hull, anticlockwise, with no point on an edge between two others (Andrew's monotone chain).
fn hull(points: &[(f64, f64)]) -> Vec<(f64, f64)> {
    let mut p = points.to_vec();
    p.sort_by(|a, b| a.partial_cmp(b).unwrap());
    let mut h: Vec<(f64, f64)> = Vec::new();
    for pass in 0..2 {
        let start = h.len();
        let it: Box<dyn Iterator<Item = &(f64, f64)>> = if pass == 0 { Box::new(p.iter()) } else { Box::new(p.iter().rev()) };
        for &q in it {
            while h.len() >= start + 2 && cross(h[h.len() - 2], h[h.len() - 1], q) <= 1e-12 {
                h.pop();
            }
            h.push(q);
        }
        h.pop();
    }
    h
}

/// A point within the hull, or the hull's nearest point to it.
fn into_hull(hull: &[(f64, f64)], q: (f64, f64)) -> (f64, f64) {
    let n = hull.len();
    if (0..n).all(|i| cross(hull[i], hull[(i + 1) % n], q) >= -1e-12) {
        return q;
    }
    let mut best = (f64::MAX, q);
    for i in 0..n {
        let (a, b) = (hull[i], hull[(i + 1) % n]);
        let ab = (b.0 - a.0, b.1 - a.1);
        let t = (((q.0 - a.0) * ab.0 + (q.1 - a.1) * ab.1) / (ab.0 * ab.0 + ab.1 * ab.1)).clamp(0.0, 1.0);
        let at = (a.0 + t * ab.0, a.1 + t * ab.1);
        let d = (at.0 - q.0).powi(2) + (at.1 - q.1).powi(2);
        if d < best.0 {
            best = (d, at);
        }
    }
    best.1
}

/// Along the rows: the value at a row, linear between the rows on either side of it, the nearest row's beyond them.
fn along(rows: &[(f64, [f64; 2])], row: f64) -> [f64; 2] {
    let (first, last) = (rows[0], rows[rows.len() - 1]);
    if row <= first.0 {
        return first.1;
    }
    if row >= last.0 {
        return last.1;
    }
    let k = rows.iter().position(|r| r.0 >= row).unwrap();
    let (a, b) = (rows[k - 1], rows[k]);
    let f = (row - a.0) / (b.0 - a.0);
    [0, 1].map(|i| a.1[i] + f * (b.1[i] - a.1[i]))
}

impl SpeakerSpace {
    fn new(space: &Space, anchors: &[Anchor]) -> Result<SpeakerSpace, String> {
        let mut s = SpeakerSpace {
            chart: space.chart,
            points: Vec::new(),
            triangles: Vec::new(),
            hull: Vec::new(),
            lips: [Vec::new(), Vec::new()],
            rhotic: None,
            ring: None,
            hearing: space.hearing,
        };
        // (Places one within a millionth: on the chart's grid, the same place; each drawn where its first anchor is.)
        let key = |x: f64| (x * 1e6).round() as i64;
        let xy_key = |a: &Anchor| {
            let (x, y) = space.chart(a.place);
            (key(x), key(y))
        };
        let at = mean_by(anchors.iter().map(|a| (xy_key(a), a.params)));
        s.points = at.into_iter().map(|(k, v)| (space.chart(anchors.iter().find(|a| xy_key(a) == k).unwrap().place), v)).collect();
        let xy: Vec<(f64, f64)> = s.points.iter().map(|p| p.0).collect();
        s.hull = hull(&xy);
        if s.hull.len() < 3 {
            return Err(format!("the vowel space: {} anchors at {} places, not a plane's", anchors.len(), xy.len()));
        }
        s.triangles = delaunay(&xy);
        for (r, lips) in s.lips.iter_mut().enumerate() {
            let rounded = r == 1;
            let mut rows = mean_by(anchors.iter().filter(|a| (a.place.rounding >= 0.5) == rounded).map(|a| (key(a.place.row), [a.params[LP], a.params[LD]])));
            rows.sort_by_key(|r| r.0);
            *lips = rows.into_iter().map(|(k, v)| (k as f64 / 1e6, v)).collect();
            if lips.is_empty() {
                return Err(format!("the vowel space: no {} anchor", if rounded { "rounded" } else { "unrounded" }));
            }
        }
        Ok(s)
    }

    /// R-colouring measured: the speaker's rhotic shape, and its place uncoloured (Space::rhotic_place).
    pub fn colour(&mut self, shape: [f64; NUM_PARAMS], uncoloured: Place) {
        self.rhotic = None;
        let plain = self.at(Place { rhotic: 0.0, ..uncoloured });
        self.rhotic = Some(std::array::from_fn(|k| shape[k] - plain[k]));
    }

    /// Whether the speaker's r-colouring is measured: where it is not, a place's rhoticity is passed over.
    pub fn coloured(&self) -> bool {
        self.rhotic.is_some()
    }

    /// The speaker's shape at a place: the tongue's parameters from the triangle the place is in (the hull's nearest
    /// point where it is outside), the lips' along the rows, unrounded and rounded weighed by its rounding; its
    /// rhoticity's share of the r-colouring added. Where the space is extended (Space::extend), a place beyond the hull
    /// is made between the hull and its pushed vertices (`Ring::at`), the lips' push added to the rows' lips; the
    /// pushed polygon where its ray from the hull's centre meets it, where it is beyond that too.
    pub fn at(&self, place: Place) -> [f64; NUM_PARAMS] {
        let mut q = self.chart.xy(place);
        if let Some(ring) = &self.ring {
            q = ring.within(q);
            if !inside(&self.hull, q) {
                let (mut out, push) = ring.at(q);
                self.lips_and_colour(&mut out, place, push);
                return out;
            }
        }
        let q = into_hull(&self.hull, q);
        // (The triangle the place is most within: on an edge or a hair beyond it, either side's.)
        let mut best = (f64::MIN, [0.0; 3], [0usize; 3]);
        for t in &self.triangles {
            let [a, b, c] = t.map(|k| self.points[k].0);
            let area = cross(a, b, c);
            let w = [cross(q, b, c) / area, cross(a, q, c) / area, cross(a, b, q) / area];
            let least = w.iter().cloned().fold(f64::MAX, f64::min);
            if least > best.0 {
                best = (least, w, *t);
            }
        }
        let (_, w, t) = best;
        let mut out = [0.0; NUM_PARAMS];
        for (k, o) in out.iter_mut().enumerate() {
            if !is_lip(k) {
                *o = (0..3).map(|i| w[i] * self.points[t[i]].1[k]).sum();
            }
        }
        self.lips_and_colour(&mut out, place, [0.0; 2]);
        out
    }

    /// The lips along the rows at a place's row, unrounded and rounded weighed by its rounding, with a push added; its
    /// rhoticity's share of the r-colouring.
    fn lips_and_colour(&self, out: &mut [f64; NUM_PARAMS], place: Place, push: [f64; 2]) {
        let (u, r) = (along(&self.lips[0], place.row), along(&self.lips[1], place.row));
        let f = place.rounding.clamp(0.0, 1.0);
        out[LP] = u[0] + f * (r[0] - u[0]) + push[0];
        out[LD] = u[1] + f * (r[1] - u[1]) + push[1];
        if let Some(d) = &self.rhotic {
            let r = place.rhotic.clamp(0.0, 1.0);
            for (o, d) in out.iter_mut().zip(d) {
                *o += r * d;
            }
        }
    }

    /// The speaker's shape at a place, brought to sound there (the owner, 16 November 2026, of design 1: "Yes,
    /// proceed"): the space read at the place, the reading moved step by step until the shape made there sounds -- its
    /// first two resonances on the speaker's own engine -- where the speaker's map puts the place, within
    /// `heard.cents`. Each step Newton's, its direction from the sounds of two small moves of the reading
    /// (`heard.probe` across and down the chart, each toward where the space is made), taken whole or halved until it
    /// sounds nearer; none taken where no move sounds nearer, the reading as far as it came. The reading kept where the
    /// space is made (`reach`). Where no reading of the space sounds there (a sound its vowels do not make between
    /// them, or beyond them), the shape read is moved itself: its parameters but its lips' and velum's (the lips its
    /// rounding's) by the least squares that tune a carried shape (carry::tune: each parameter's move from the shape
    /// read weighs as a miss, `heard.cents_per_range` its whole range's, so that of the shapes that sound there it
    /// takes the nearest; a shape narrower than languages/carry.json's share of the speaker's narrowest vowel refused,
    /// as closing the tract), stopping once within `heard.cents`, kept where it sounds nearer. Brought there uncoloured, its
    /// rhoticity's r-colouring added after.
    pub fn heard(&self, map: &SoundMap, tract: &mut VocalTract, place: Place) -> Result<Heard, String> {
        let chart = self.chart;
        let plain = Place { rhotic: 0.0, ..place };
        let (t1, t2) = map.sound(plain);
        let mut soundings = 0;
        let mut off = |tract: &mut VocalTract, q: (f64, f64)| -> Result<[f64; 2], String> {
            soundings += 1;
            let (f1, f2) = sound(tract, &self.at(chart.place(q, plain.rounding)))?;
            Ok([1200.0 * (f1 / t1).log2(), 1200.0 * (f2 / t2).log2()])
        };
        let h = self.hearing;
        let size = |r: [f64; 2]| r[0].hypot(r[1]);
        let same = |a: (f64, f64), b: (f64, f64)| (a.0 - b.0).abs() < 1e-12 && (a.1 - b.1).abs() < 1e-12;
        let mut q = self.reach(chart.xy(plain));
        let mut r = off(tract, q)?;
        let before = r;
        for _ in 0..h.steps {
            if r[0].abs().max(r[1].abs()) <= h.cents {
                break;
            }
            let toward = |m: (f64, f64)| if same(self.reach((q.0 + m.0, q.1 + m.1)), (q.0 + m.0, q.1 + m.1)) { m } else { (-m.0, -m.1) };
            let (dx, dy) = (toward((h.probe, 0.0)).0, toward((0.0, h.probe)).1);
            let (across, down) = (off(tract, (q.0 + dx, q.1))?, off(tract, (q.0, q.1 + dy))?);
            let j = [[(across[0] - r[0]) / dx, (down[0] - r[0]) / dy], [(across[1] - r[1]) / dx, (down[1] - r[1]) / dy]];
            let det = j[0][0] * j[1][1] - j[0][1] * j[1][0];
            if det == 0.0 || !det.is_finite() {
                break;
            }
            let d = ((j[0][1] * r[1] - j[1][1] * r[0]) / det, (j[1][0] * r[0] - j[0][0] * r[1]) / det);
            let mut nearer = None;
            for k in 0..=h.halvings {
                let t = 0.5f64.powi(k as i32);
                let to = self.reach((q.0 + t * d.0, q.1 + t * d.1));
                if same(to, q) {
                    break;
                }
                let heard = off(tract, to)?;
                if size(heard) < size(r) {
                    nearer = Some((to, heard));
                    break;
                }
            }
            let Some((to, heard)) = nearer else { break };
            (q, r) = (to, heard);
        }
        let read = Place { rhotic: place.rhotic, ..chart.place(q, plain.rounding) };
        let mut shape = self.at(read);
        let mut tuned = 0;
        if r[0].abs().max(r[1].abs()) > h.cents {
            let start = self.at(Place { rhotic: 0.0, ..read });
            let t = carry::Tuning { formants: 2, steps: h.tune_steps, cents_per_range: h.cents_per_range, ..carry::settings().tune.clone() };
            let narrowest = self.points.iter().map(|p| least_area(tract, &p.1)).fold(f64::INFINITY, f64::min);
            if let Ok(d) = carry::tune(tract, &start, &[t1, t2], t.least_area_share * narrowest, &t, carry::settings().top_hz, &[LP, LD, VS, VO], Some(h.cents)) {
                if d.cents[0].hypot(d.cents[1]) < size(r) {
                    for k in 0..NUM_PARAMS {
                        shape[k] += d.params[k] - start[k];
                    }
                    (r, tuned) = ([d.cents[0], d.cents[1]], d.steps);
                }
            }
        }
        Ok(Heard { shape, read, before, after: r, soundings, tuned })
    }

    /// Where the space makes a point on the chart: the point, where it is within; else the point `at` makes it at
    /// (where the space is extended, the pushed polygon's edge on its ray from the hull's centre; else the hull's
    /// nearest point).
    fn reach(&self, q: (f64, f64)) -> (f64, f64) {
        match &self.ring {
            Some(ring) => ring.within(q),
            None => into_hull(&self.hull, q),
        }
    }

    /// How far each vertex of the hull was pushed (Space::extend): its place, its pushed point's (both unrounded), and
    /// the pushed point's distance from the hull's centre against its own (1 where not pushed); none where the space is
    /// not extended.
    pub fn pushes(&self) -> Vec<(Place, Place, f64)> {
        let Some(r) = &self.ring else { return Vec::new() };
        let d = |q: (f64, f64)| (q.0 - r.centre.0).hypot(q.1 - r.centre.1);
        r.vertices.iter().zip(&r.outer).map(|(&v, o)| (self.chart.place(v, 0.0), self.chart.place(o.0, 0.0), d(o.0) / d(v))).collect()
    }

    /// The triangles' area against the hull's: equal where the triangulation covers it.
    pub fn coverage(&self) -> (f64, f64) {
        let area = |p: &[(f64, f64)]| (0..p.len()).map(|i| p[i].0 * p[(i + 1) % p.len()].1 - p[(i + 1) % p.len()].0 * p[i].1).sum::<f64>() / 2.0;
        (self.triangles.iter().map(|t| area(&t.map(|k| self.points[k].0))).sum(), area(&self.hull))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn places_from_ipa() {
        let s = space();
        let p = |x: &str| s.place(x).unwrap();
        assert_eq!(p("i"), Place::new(0.0, 0.0, 0.0));
        assert_eq!(p("ɒː"), Place::new(6.0, 2.0, 1.0));
        assert_eq!(p("ˈɛ"), p("ɛ"));
        assert_eq!(p("e̞"), Place::new(2.5, 0.0, 0.0));
        assert_eq!(p("ɯ̟"), Place::new(0.0, 1.5, 0.0));
        assert_eq!(p("ä"), p("ä"));
        assert_eq!(p("ä"), Place::new(6.0, 1.0, 0.0));
        assert_eq!(p("o̽"), Place::new(2.5, 1.5, 1.0));
        assert_eq!(p("ɔ̜"), Place::new(4.0, 2.0, 0.5));
        // (The rhotic hook: r-coloured, its letter where it is; [ɚ] and [ɝ] written in one character, the same.)
        assert_eq!(p("ə˞"), Place { rhotic: 1.0, ..p("ə") });
        assert_eq!(p("ɚ"), p("ə˞"));
        assert_eq!(p("ɝ"), Place { rhotic: 1.0, ..p("ɜ") });
        assert_eq!(p("ɑ˞ː"), Place { rhotic: 1.0, ..p("ɑ") });
        assert_eq!(p("u̹"), p("u"));
        assert!(s.place("aɪ").is_err());
        assert!(s.place("k").is_err());
        assert!(s.place("̞e").is_err());
        // (The chart's corners: the close row twice the open row's width.)
        assert_eq!(s.chart(p("i")), (0.0, 0.0));
        assert_eq!(s.chart(p("u")), (4.0, 0.0));
        assert_eq!(s.chart(p("a")), (2.0, 3.0));
        assert_eq!(s.chart(p("ɑ")), (4.0, 3.0));
    }

    #[test]
    fn anchors_placed_by_their_sound() {
        let s = space();
        let mut anchors: Vec<Anchor> = ["i", "u", "ä", "e"].iter().map(|x| anchor(s, x, 0.0)).collect();
        // (The corners where the chart has them; [e] heard as near [i] as it is: its place near the close row.)
        let sounds = [(275.0, 2320.0), (290.0, 705.0), (645.0, 1135.0), (290.0, 2325.0)];
        let map = s.place_by_sound(&mut anchors, &sounds).unwrap();
        for (a, x) in anchors.iter().zip(["i", "u", "ä"]) {
            let (want, got) = (s.chart(s.place(x).unwrap()), s.chart(a.place));
            assert!((want.0 - got.0).abs() < 1e-9 && (want.1 - got.1).abs() < 1e-9, "{x}: {got:?}");
        }
        assert!(anchors[3].place.row < 0.3 && anchors[3].place.column.abs() < 0.2, "{:?}", anchors[3].place);
        // (The rhotic shape by its sound, its rounding its IPA's: [ɝ] between [i] and [u] and lower, unrounded.)
        let r = s.rhotic_place(Some(&map), (450.0, 1300.0)).unwrap();
        assert!(r.row > 1.0 && r.column > 0.5 && r.column < 1.8 && r.rounding == 0.0 && r.rhotic == 0.0, "{r:?}");
        assert!((bark(1000.0) - 8.527).abs() < 0.01);
        // (Bark back to hertz, beyond both ends' corrections too; the map back from a place to its sound.)
        for f in [80.0, 150.0, 500.0, 2500.0, 7000.0, 9000.0] {
            assert!((hz(bark(f)) / f - 1.0).abs() < 1e-12, "{f} Hz");
        }
        for (a, &(f1, f2)) in anchors.iter().zip(&sounds) {
            let (g1, g2) = map.sound(a.place);
            assert!((g1 / f1 - 1.0).abs() < 1e-9 && (g2 / f2 - 1.0).abs() < 1e-9, "{}: {g1} {g2}", a.name);
        }
    }

    /// A language's measured vowels: its corners at the space's corners, the rest where their measured sounds put them
    /// among them; a clarity moves each one from their centre, as far as its measured most.
    #[test]
    fn a_languages_vowels_where_its_speakers_put_them() {
        let (s, p) = (space(), places());
        let near = |a: Place, b: Place| {
            let (x, y) = (s.chart(a), s.chart(b));
            (x.0 - y.0).hypot(x.1 - y.1)
        };
        for (tag, open) in [("en", "ɑ"), ("la", "a")] {
            let l = p.language(tag).unwrap();
            for (letter, corner) in [("i", "i"), ("u", "u"), (open, "ä")] {
                let got = l.place(letter.chars().next().unwrap(), 0.0).unwrap();
                assert!(near(got, s.place(corner).unwrap()) < 1e-9, "{tag} [{letter}] {got:?}");
            }
            // (Each farther from the centre as the clarity grows, no farther than the most measured.)
            let centre = |q: Place| {
                let (x, y) = s.chart(q);
                (x - l.centre.0).hypot(y - l.centre.1)
            };
            for c in l.letters() {
                let (a, b, most, beyond) = (l.place(c, 0.0).unwrap(), l.place(c, 1.0).unwrap(), l.place(c, p.most_clarity()).unwrap(), l.place(c, 9.0).unwrap());
                assert!((centre(b) / centre(a) - (1.0 + l.clear).sqrt()).abs() < 1e-9 && centre(most) > centre(b) && near(most, beyond) < 1e-12, "{tag} [{c}]");
            }
        }
        let la = p.language("la").unwrap();
        let row = |c: char| la.place(c, 0.0).unwrap().row;
        assert!(row('i') < row('e') && row('e') < row('ɛ') && row('ɛ') < row('a') && row('u') < row('o') && row('o') < row('ɔ'));
        // (A language's letter in IPA with its marks, its measured place displaced; one it has not measured, the chart's.)
        assert!(near(s.place_in("iː", "en-us", 0.0).unwrap(), p.language("en").unwrap().place('i', 0.0).unwrap()) < 1e-9);
        assert_eq!(s.place_in("ə", "en", 1.0).unwrap(), s.place("ə").unwrap());
        assert_eq!(s.place_in("ɝ", "en", 0.0).unwrap().rhotic, 1.0);
        assert!(p.language("ko").is_none() && s.place_in("i", "ko", 1.0).unwrap() == s.place("i").unwrap());
        // (Lam, Tjaden & Wilding 2012's increases: clear 0.45 of the area, overenunciating 0.79.)
        assert!((la.clear - 0.4525).abs() < 1e-9 && (p.most_clarity() - 0.79 / 0.4525).abs() < 1e-9);
    }

    #[test]
    fn a_vowel_asked_by_its_ipa() {
        let s = space();
        // (The speaker's own shape of the language's own phone where it has it, as the reader says it; else the space at
        // its place in the language.)
        assert_eq!(said_with("æ", "en", 0.0, |n| n == "{"), Ok(Said::Own("{".into())));
        assert_eq!(said_with("æ", "en", 1.0, |_| false), Ok(Said::At(s.place_in("æ", "en", 1.0).unwrap())));
        assert_eq!(said_with("ˈiː", "", 0.0, |n| n == "i"), Ok(Said::Own("i".into())));
        // (A nearest is not its own: a speaker's /a/ is not its [ɑ] in English.)
        assert_eq!(said_with("ɨ", "en", 0.0, |_| true), Ok(Said::At(s.place("ɨ").unwrap())));
        assert!(said_with("aɪ", "en", 0.0, |_| true).is_err() && said_with("k", "", 0.0, |_| true).is_err());
        assert_eq!(s.bounded(Place { row: 9.0, column: -1.0, rounding: 2.0, rhotic: -1.0 }), Place::new(6.0, 0.0, 1.0));
    }

    fn anchor(s: &Space, ipa: &str, v: f64) -> Anchor {
        let mut params = [v; NUM_PARAMS];
        params[LP] = 10.0 + v;
        params[LD] = 20.0 + v;
        Anchor { name: ipa.into(), place: s.place(ipa).unwrap(), params }
    }

    #[test]
    fn a_speakers_space_is_its_anchors_between_them() {
        let s = space();
        let anchors: Vec<Anchor> = [("i", 0.0), ("e", 1.0), ("ɛ", 2.0), ("a", 3.0), ("u", 4.0), ("o", 5.0), ("ɔ", 6.0), ("y", 7.0), ("ə", 8.0)].iter().map(|&(x, v)| anchor(s, x, v)).collect();
        let sp = s.speaker(&anchors).unwrap();
        let (tri, hull) = sp.coverage();
        assert!((tri - hull).abs() < 1e-9, "triangles {tri}, hull {hull}");
        // (Each anchor its own, but the tongue at [i] and [y]'s place, their mean, and the lips of the rounded close
        // row, [y]'s and [u]'s.)
        for a in &anchors {
            let got = sp.at(a.place);
            let tongue = if matches!(a.name.as_str(), "i" | "y") { 3.5 } else { a.params[0] };
            let lips = if matches!(a.name.as_str(), "u" | "y") { [15.5, 25.5] } else { [a.params[LP], a.params[LD]] };
            assert!((got[0] - tongue).abs() < 1e-9, "{}: {}", a.name, got[0]);
            assert!((got[LP] - lips[0]).abs() < 1e-9 && (got[LD] - lips[1]).abs() < 1e-9, "{}: lips", a.name);
        }
        // ([ɯ]: [u]'s tongue, [i]'s lips; half rounded, halfway to [u]'s lips.)
        let m = sp.at(s.place("ɯ").unwrap());
        assert!((m[0] - 4.0).abs() < 1e-9 && (m[LP] - 10.0).abs() < 1e-9);
        let half = sp.at(s.place("ɯ̹").unwrap());
        assert!((half[LP] - (10.0 + 0.5 * (15.5 - 10.0))).abs() < 1e-9, "{}", half[LP]);
        // ([ɑ], beyond the hull: the hull's nearest point, between [ɔ] and [a].)
        let back = sp.at(s.place("ɑ").unwrap())[0];
        assert!(back > 3.0 && back < 6.0, "{back}");
        // (Uncoloured, rhoticity passed over; coloured, the rhotic shape at its own place, its displacement added
        // elsewhere by rhoticity.)
        let mut sp = sp;
        assert!(!sp.coloured());
        assert_eq!(sp.at(s.place("ɝ").unwrap()), sp.at(s.place("ɜ").unwrap()));
        let own = s.place("ə").unwrap();
        let mut shape = sp.at(own);
        shape[0] += 2.0;
        shape[LP] -= 1.0;
        sp.colour(shape, own);
        assert!(sp.coloured());
        assert!(sp.at(s.place("ə˞").unwrap()).iter().zip(&shape).all(|(a, b)| (a - b).abs() < 1e-9));
        let (plain, half) = (sp.at(s.place("ɑ").unwrap()), sp.at(Place { rhotic: 0.5, ..s.place("ɑ").unwrap() }));
        assert!((half[0] - plain[0] - 1.0).abs() < 1e-9 && (half[LP] - plain[LP] + 0.5).abs() < 1e-9);
    }

    #[test]
    fn a_speakers_space_extended_beyond_its_vowels() {
        let s = space();
        let anchors: Vec<Anchor> = [("i", 0.0), ("e", 1.0), ("ɛ", 2.0), ("a", 3.0), ("u", 4.0), ("o", 5.0), ("ɔ", 6.0), ("ə", 8.0)].iter().map(|&(x, v)| anchor(s, x, v)).collect();
        let plain = s.speaker(&anchors).unwrap();
        // (Each vertex pushed half again as far from the hull's centre, its parameters likewise from the centre's,
        // as Space::extend pushes them where the engine hears them beyond; [u] not pushed.)
        let mut sp = plain.clone();
        let n = sp.hull.len() as f64;
        let centre = (sp.hull.iter().map(|v| v.0).sum::<f64>() / n, sp.hull.iter().map(|v| v.1).sum::<f64>() / n);
        let from = plain.at(Place { rhotic: 0.0, ..s.chart.place(centre, 0.0) });
        let u = s.chart.xy(s.place("u").unwrap());
        let (mut inner, mut outer) = (Vec::new(), Vec::new());
        for &v in &sp.hull {
            let params = sp.points.iter().find(|p| p.0 == v).unwrap().1;
            let k = if v == u { 1.0 } else { 1.5 };
            inner.push(params);
            outer.push(((centre.0 + k * (v.0 - centre.0), centre.1 + k * (v.1 - centre.1)), std::array::from_fn(|j| from[j] + k * (params[j] - from[j]))));
        }
        sp.ring = Some(Ring { centre, vertices: sp.hull.clone(), inner, outer: outer.clone() });
        // (Within the hull, as it was.)
        for ipa in ["i", "e", "ɛ", "a", "u", "o", "ɔ", "ə", "ɨ", "ø", "ɐ"] {
            assert_eq!(sp.at(s.place(ipa).unwrap()), plain.at(s.place(ipa).unwrap()), "[{ipa}]");
        }
        // (At [i]'s pushed point, its pushed tongue; halfway out, halfway; beyond it on its ray, the same as at it; [u] at
        // its own.)
        let ring = sp.ring.as_ref().unwrap();
        let k = ring.vertices.iter().position(|&v| v == s.chart.xy(s.place("i").unwrap())).unwrap();
        let (v, (o, pushed)) = (ring.vertices[k], ring.outer[k]);
        let at = |q: (f64, f64)| sp.at(s.chart.place(q, 0.0));
        assert!((at(o)[0] - pushed[0]).abs() < 1e-9, "{} {}", at(o)[0], pushed[0]);
        let half = ((v.0 + o.0) / 2.0, (v.1 + o.1) / 2.0);
        assert!((at(half)[0] - (ring.inner[k][0] + pushed[0]) / 2.0).abs() < 1e-9);
        let far = (centre.0 + 2.0 * (o.0 - centre.0), centre.1 + 2.0 * (o.1 - centre.1));
        assert!((at(far)[0] - pushed[0]).abs() < 1e-9);
        assert_eq!(sp.at(s.place("u").unwrap()), plain.at(s.place("u").unwrap()));
        // (The lips pushed as the tongue is: the rows' lips at the place, plus the pushed point's lips less its vertex's.)
        let lips_pushed = pushed[LP] - ring.inner[k][LP];
        let rows = plain.at(s.chart.place(o, 0.0))[LP];
        assert!((at(o)[LP] - (rows + lips_pushed)).abs() < 1e-9);
    }
}
