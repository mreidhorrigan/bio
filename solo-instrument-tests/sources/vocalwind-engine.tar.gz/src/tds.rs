// The branched tube's acoustics in the time domain (TdsModel.cpp; Birkholz 2005, "3D-Artikulatorische Sprachsynthese"):
// each tube section a lumped element of an electrical network -- its air's inertance, compliance and viscous losses, its
// soft walls, the Bernoulli and turbulence losses where the flow narrows, noise sources where it is turbulent (at the
// glottis, the tongue, the teeth, the lips), and the radiation at the mouth and nostrils -- discretized implicitly
// (theta 0.505) and solved each sample for the 97 branch currents by a Cholesky factorization in an envelope. Every
// expression in the C++'s order; what it kept only to inspect (its constriction buffer, a 65536-entry record written each
// sample) is left out, never having reached its sound.
use crate::constants::*;
use crate::iir::{second_order_lowpass, IirFilter};
use crate::rng::{Mt19937, NormalDistribution};
use crate::tube::{self, Articulator, Tube, NUM_SECTIONS};

pub const NUM_BRANCH_CURRENTS: usize = NUM_SECTIONS + 4;
const MAX_ENVELOPE_COLUMNS: usize = 57;
const MAX_ENVELOPE_ROWS: usize = 10;
const MAX_CONSTRICTIONS: usize = 4;
const NOISE_BUFFER_MASK: i32 = 7;
// (For theta 0.505 the bandwidths are those of the frequency-domain model up to 5 kHz.)
pub const THETA: f64 = 0.505;
pub const THETA1: f64 = 1.0 - THETA;
pub const MIN_AREA_CM2: f64 = 0.01e-2;
pub const NOISE_CUTOFF_FREQ: f64 = 500.0;
const N: usize = NUM_BRANCH_CURRENTS;

#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Solver {
    Cholesky,
    Sor,
}

/// The acoustic options, VocalTractLab's defaults.
#[derive(Clone, Copy, Debug)]
pub struct Options {
    pub turbulence_losses: bool,
    pub soft_walls: bool,
    pub generate_noise_sources: bool,
    pub radiation_from_skin: bool,
    pub piriform_fossa: bool,
    pub inner_length_corrections: bool,
    pub transvelar_coupling: bool,
    pub solver: Solver,
}

impl Default for Options {
    fn default() -> Self {
        Options {
            turbulence_losses: true,
            soft_walls: true,
            generate_noise_sources: true,
            radiation_from_skin: true,
            piriform_fossa: true,
            inner_length_corrections: false,
            transvelar_coupling: false,
            solver: Solver::Cholesky,
        }
    }
}

#[derive(Clone, Copy, Debug, Default)]
struct NoiseSource {
    is_first_order: bool,
    cutoff_freq: f64,
    target_amp_1khz: f64,
    current_amp_1khz: f64,
    input: [f64; 8],
    output: [f64; 8],
    sample: f64,
}

impl NoiseSource {
    fn reset(&mut self) {
        *self = NoiseSource { cutoff_freq: 1.0, ..NoiseSource::default() };
    }
}

#[derive(Clone, Copy, Debug)]
struct Constriction {
    first_section: i32,
    last_section: i32,
    narrowest_section: i32,
    obstacle_pos: f64,
    obstacle_section: i32,
    area: f64,
    flow: f64,
    velocity: f64,
    cutoff_freq: f64,
    gain: f64,
    full_amp: f64,
    articulator: Articulator,
}

impl Default for Constriction {
    fn default() -> Self {
        Constriction {
            first_section: -1,
            last_section: -1,
            narrowest_section: -1,
            obstacle_pos: 0.0,
            obstacle_section: -1,
            area: 0.0,
            flow: 0.0,
            velocity: 0.0,
            cutoff_freq: 0.0,
            gain: 0.0,
            full_amp: 0.0,
            articulator: Articulator::Other,
        }
    }
}

#[derive(Clone, Copy, Debug, Default)]
struct BranchCurrent {
    source_section: i32,
    target_section: i32,
    magnitude: f64,
    magnitude_rate: f64,
    noise_magnitude: f64,
}

#[derive(Clone, Copy, Debug, Default)]
struct TubeSection {
    pos: f64,
    area: f64,
    length: f64,
    volume: f64,
    articulator: Articulator,
    monopole: NoiseSource,
    dipole: NoiseSource,
    pressure: f64,
    pressure_rate: f64,
    current_in: i32,
    current_out: [i32; 2],
    mw: f64,
    bw: f64,
    kw: f64,
    wall_current: f64,
    wall_current_rate: f64,
    wall_current_rate2: f64,
    l: f64,
    c: f64,
    r: [f64; 2],
    s: f64,
    alpha: f64,
    beta: f64,
    d: f64,
    e: f64,
}

pub struct TdsModel {
    pub options: Options,
    flow_source_amp: f64,
    flow_source_section: i32,
    pressure_source_amp: f64,
    pressure_source_section: i32,
    lips_dipole: NoiseSource,
    ts: [TubeSection; NUM_SECTIONS],
    bc: [BranchCurrent; N],
    // The envelope of the lower triangle (Cholesky) and the rows' non-zeros (Gauss-Seidel).
    env_rows: Vec<Vec<usize>>,
    env_cols: Vec<Vec<usize>>,
    sor_rows: Vec<Vec<usize>>,
    pub time_step: f64,
    aspiration_strength_db: f64,
    matrix: Vec<f64>,
    factor: Vec<f64>,
    solution: [f64; N],
    flow: [f64; N],
    pub sor_iterations: i32,
    glottal_tone_filter: IirFilter,
    transglottal_pressure_filter: IirFilter,
    transvelar_filter1: IirFilter,
    transvelar_filter2: IirFilter,
    constriction: [Constriction; MAX_CONSTRICTIONS],
    num_constrictions: usize,
    position: i32,
    teeth_position: f64,
    tongue_tip_side_elevation: f64,
    rng: Mt19937,
}

impl Default for TdsModel {
    fn default() -> Self {
        TdsModel::new()
    }
}

impl TdsModel {
    pub fn new() -> TdsModel {
        let mut m = TdsModel {
            options: Options::default(),
            flow_source_amp: 0.0,
            flow_source_section: -1,
            pressure_source_amp: 0.0,
            pressure_source_section: -1,
            lips_dipole: NoiseSource::default(),
            ts: [TubeSection::default(); NUM_SECTIONS],
            bc: [BranchCurrent::default(); N],
            env_rows: vec![Vec::new(); N],
            env_cols: vec![Vec::new(); N],
            sor_rows: vec![Vec::new(); N],
            time_step: 0.0,
            aspiration_strength_db: 0.0,
            matrix: vec![0.0; N * N],
            factor: vec![0.0; N * N],
            solution: [0.0; N],
            flow: [0.0; N],
            sor_iterations: 0,
            glottal_tone_filter: IirFilter::default(),
            transglottal_pressure_filter: IirFilter::default(),
            transvelar_filter1: IirFilter::default(),
            transvelar_filter2: IirFilter::default(),
            constriction: [Constriction::default(); MAX_CONSTRICTIONS],
            num_constrictions: 0,
            position: 0,
            teeth_position: 0.0,
            tongue_tip_side_elevation: 0.0,
            rng: Mt19937::new(5489),
        };
        let t = Tube::new();
        m.set_tube(&t, false);
        m.init_model();
        m.reset_motion();
        m
    }

    fn init_model(&mut self) {
        self.sor_iterations = 0;
        self.time_step = 1.0 / SAMPLING_RATE as f64;
        self.flow_source_section = -1;
        self.pressure_source_section = -1;
        for i in 0..NUM_SECTIONS {
            self.bc[i].source_section = i as i32 - 1;
            self.bc[i].target_section = i as i32;
        }
        self.bc[tube::FIRST_TRACHEA_SECTION].source_section = -1;
        self.bc[tube::FIRST_NOSE_SECTION].source_section = tube::LAST_PHARYNX_SECTION as i32;
        self.bc[tube::FIRST_FOSSA_SECTION].source_section = (tube::FIRST_PHARYNX_SECTION + tube::FOSSA_COUPLING_SECTION) as i32;
        for i in 0..tube::NUM_SINUS_SECTIONS {
            self.bc[tube::FIRST_SINUS_SECTION + i].source_section = (tube::FIRST_NOSE_SECTION + tube::SINUS_COUPLING_SECTION[i]) as i32;
        }
        // (Two currents each out of the mouth and the nostrils, into free space: the radiation's resistance and inductance.)
        for (k, from) in [(0, tube::LAST_MOUTH_SECTION), (1, tube::LAST_MOUTH_SECTION), (2, tube::LAST_NOSE_SECTION), (3, tube::LAST_NOSE_SECTION)] {
            self.bc[NUM_SECTIONS + k].source_section = from as i32;
            self.bc[NUM_SECTIONS + k].target_section = -1;
        }
        for ts in self.ts.iter_mut() {
            ts.current_in = -1;
            ts.current_out = [-1, -1];
        }
        for i in 0..N {
            let b = self.bc[i];
            if b.source_section != -1 {
                let ts = &mut self.ts[b.source_section as usize];
                if ts.current_out[0] == -1 {
                    ts.current_out[0] = i as i32;
                } else {
                    ts.current_out[1] = i as i32;
                }
            }
            if b.target_section != -1 {
                self.ts[b.target_section as usize].current_in = i as i32;
            }
        }
        // The matrix's pattern: each row's non-zeros, and its envelope below the diagonal.
        let mut pattern = vec![false; N * N];
        for i in 0..N {
            let b = self.bc[i];
            for sec in [b.source_section, b.target_section] {
                if sec != -1 {
                    let ts = &self.ts[sec as usize];
                    for c in [ts.current_in, ts.current_out[0], ts.current_out[1]] {
                        if c != -1 {
                            pattern[i * N + c as usize] = true;
                        }
                    }
                }
            }
        }
        let mut envelope = pattern.clone();
        for i in 0..N {
            let mut between = false;
            self.env_rows[i].clear();
            for j in 0..i {
                if envelope[i * N + j] || between {
                    between = true;
                    envelope[i * N + j] = true;
                    if self.env_rows[i].len() < MAX_ENVELOPE_COLUMNS {
                        self.env_rows[i].push(j);
                    }
                }
            }
        }
        for j in 0..N {
            self.env_cols[j].clear();
            for i in j + 1..N {
                if envelope[i * N + j] && self.env_cols[j].len() < MAX_ENVELOPE_ROWS {
                    self.env_cols[j].push(i);
                }
            }
        }
        for i in 0..N {
            self.sor_rows[i] = (0..N).filter(|&j| j != i && pattern[i * N + j]).collect();
        }
        self.matrix.iter_mut().for_each(|x| *x = 0.0);
        for (k, &p) in pattern.iter().enumerate() {
            if p {
                self.matrix[k] = 1.0;
            }
        }
        self.factor.iter_mut().for_each(|x| *x = 0.0);
    }

    /// Every flow, pressure and source at rest, the noise's generator seeded again (with 10, as the C++).
    pub fn reset_motion(&mut self) {
        self.rng.seed(10);
        for ts in self.ts.iter_mut() {
            ts.pressure = 0.0;
            ts.pressure_rate = 0.0;
            ts.wall_current = 0.0;
            ts.wall_current_rate = 0.0;
            ts.wall_current_rate2 = 0.0;
            ts.l = 0.0;
            ts.c = 0.0;
            ts.r = [0.0, 0.0];
            ts.s = 0.0;
            ts.alpha = 0.0;
            ts.beta = 0.0;
            ts.d = 0.0;
            ts.e = 0.0;
            ts.monopole.reset();
            ts.dipole.reset();
        }
        self.lips_dipole.reset();
        for b in self.bc.iter_mut() {
            b.magnitude = 0.0;
            b.magnitude_rate = 0.0;
            b.noise_magnitude = 0.0;
        }
        self.flow_source_amp = 0.0;
        self.pressure_source_amp = 0.0;
        self.position = 0;
        self.num_constrictions = 0;
        self.aspiration_strength_db = tube::DEFAULT_ASPIRATION_STRENGTH_DB;
        self.flow = [0.0; N];
        self.transglottal_pressure_filter.create_chebyshev(50.0 / SAMPLING_RATE as f64, false, 4);
        self.transglottal_pressure_filter.reset_buffers(0.0);
        // (Matched-z filters of Dang et al. 2016's velum, for 44100 Hz and CGS units; their precision is needed.)
        const A1: [f64; 5] = [5.027640021717718e-007, -7.995535578908732e-007, 2.967895557191014e-007, 0.0, 0.0];
        const B1: [f64; 5] = [0.0, 3.986308869708467, -5.959669638387298, 3.960408461107104, -0.987047716233603];
        const A2: [f64; 5] = [6.589309727087047e-004, -0.001972281980771, 0.001968000742164, -6.546497341015677e-004, 0.0];
        const B2: [f64; 5] = B1;
        self.transvelar_filter1.set_coefficients(&A1, &B1, 4);
        self.transvelar_filter2.set_coefficients(&A2, &B2, 4);
        self.transvelar_filter1.reset_buffers(0.0);
        self.transvelar_filter2.reset_buffers(0.0);
        self.glottal_tone_filter.set_coefficients(&A1, &B1, 4);
        self.glottal_tone_filter.reset_buffers(0.0);
    }

    pub fn sample_index(&self) -> i32 {
        self.position
    }

    pub fn set_tube(&mut self, tube: &Tube, filtering: bool) {
        for i in 0..NUM_SECTIONS {
            let source = &tube.section[i];
            let target = &mut self.ts[i];
            if filtering && (tube::FIRST_PHARYNX_SECTION..=tube::LAST_MOUTH_SECTION).contains(&i) {
                // (An oral closure or opening is slowed where the areas are small, or the front cavity rings: /udu/.)
                let old_area = target.area;
                let mut new_area = source.area_cm2;
                if new_area < old_area {
                    let old_value = old_area.sqrt().sqrt();
                    let mut new_value = new_area.sqrt().sqrt();
                    const THRESHOLD: f64 = -0.001;
                    if new_value - old_value < THRESHOLD {
                        new_value = old_value + THRESHOLD;
                        new_area = new_value * new_value * new_value * new_value;
                    }
                } else {
                    let old_value = old_area.sqrt().sqrt();
                    let mut new_value = new_area.sqrt().sqrt();
                    const THRESHOLD: f64 = 0.002;
                    if new_value - old_value > THRESHOLD {
                        new_value = old_value + THRESHOLD;
                        new_area = new_value * new_value * new_value * new_value;
                    }
                }
                target.pos = source.pos_cm;
                target.area = new_area;
                target.length = source.length_cm;
                target.volume = source.length_cm * new_area;
            } else {
                target.pos = source.pos_cm;
                target.area = source.area_cm2;
                target.length = source.length_cm;
                target.volume = source.volume_cm3;
            }
            target.mw = source.wall_mass_cgs;
            target.bw = source.wall_resistance_cgs;
            target.kw = source.wall_stiffness_cgs;
            // (A narrow section's wall is stiffer, up to a hundredfold when closed.)
            const CRITICAL_AREA_CM2: f64 = 1.0;
            if target.area < CRITICAL_AREA_CM2 {
                let mut a = target.area / CRITICAL_AREA_CM2;
                if a < 0.01 {
                    a = 0.01;
                }
                target.kw /= a;
            }
            target.articulator = source.articulator;
        }
        self.teeth_position = tube.teeth_position_cm;
        self.aspiration_strength_db = tube.aspiration_strength_db;
        self.tongue_tip_side_elevation = tube.tongue_tip_side_elevation;
    }

    pub fn set_flow_source(&mut self, flow_cm3_s: f64, section: i32) {
        self.flow_source_section = section;
        self.flow_source_amp = flow_cm3_s;
    }

    pub fn set_pressure_source(&mut self, pressure_dpa: f64, section: i32) {
        self.pressure_source_section = section;
        self.pressure_source_amp = pressure_dpa;
    }

    pub fn section_pressure(&self, i: usize) -> f64 {
        if i >= NUM_SECTIONS {
            return 0.0;
        }
        self.ts[i].pressure
    }

    #[inline]
    fn current_in(&self, i: usize) -> f64 {
        let ts = &self.ts[i];
        let mut f = 0.0;
        if ts.current_in != -1 {
            f += self.bc[ts.current_in as usize].magnitude;
        }
        f
    }

    #[inline]
    fn current_out(&self, i: usize) -> f64 {
        let ts = &self.ts[i];
        let mut f = 0.0;
        if ts.current_out[0] != -1 {
            f += self.bc[ts.current_out[0] as usize].magnitude;
        }
        if ts.current_out[1] != -1 {
            f += self.bc[ts.current_out[1] as usize].magnitude;
        }
        f
    }

    /// One sample: the radiated flow (mouth, nostrils and skin), and each of them.
    pub fn proceed_time_step(&mut self) -> (f64, f64, f64, f64) {
        self.prepare_time_step();
        self.calc_matrix();
        match self.options.solver {
            Solver::Cholesky => self.solve_cholesky(),
            Solver::Sor => self.solve_sor(),
        }
        self.update_variables();
        let mut mouth = 0.0;
        let ts = &self.ts[tube::LAST_MOUTH_SECTION];
        if ts.current_out[0] != -1 {
            mouth += self.bc[ts.current_out[0] as usize].magnitude;
        }
        if ts.current_out[1] != -1 {
            mouth += self.bc[ts.current_out[1] as usize].magnitude;
        }
        let mut nostril = 0.0;
        let ts = &self.ts[tube::LAST_NOSE_SECTION];
        if ts.current_out[0] != -1 {
            nostril += self.bc[ts.current_out[0] as usize].magnitude;
        }
        if ts.current_out[1] != -1 {
            nostril += self.bc[ts.current_out[1] as usize].magnitude;
        }
        let mut skin = 0.0;
        if self.options.radiation_from_skin {
            skin = self.glottal_tone_filter.output_sample(self.ts[tube::FIRST_PHARYNX_SECTION].pressure);
        }
        self.position = self.position.wrapping_add(1);
        (mouth + nostril + skin, mouth, nostril, skin)
    }

    fn prepare_time_step(&mut self) {
        let dt = self.time_step;
        for i in 0..NUM_SECTIONS {
            let ts = &mut self.ts[i];
            if ts.area < MIN_AREA_CM2 {
                ts.area = MIN_AREA_CM2;
            }
            ts.s = 0.0;
            let circ = 2.0 * (ts.area * PI).sqrt();
            let sinus = (tube::FIRST_SINUS_SECTION..=tube::LAST_SINUS_SECTION).contains(&i);
            if sinus {
                ts.l = AMBIENT_DENSITY_CGS * (ts.length / ts.area);
                ts.c = ts.volume / (AMBIENT_DENSITY_CGS * SOUND_VELOCITY_CGS * SOUND_VELOCITY_CGS);
                ts.r[0] = (8.0 * AIR_VISCOSITY_CGS * PI * ts.length) / (ts.area * ts.area);
                ts.r[1] = ts.r[0];
            } else {
                let mut a = (ts.area / PI).sqrt();
                let mut b = a;
                // (Below 6 mm of radius the section is an ellipse of that half-axis: a slit's viscous resistance.)
                const MIN_RADIUS_CM: f64 = 0.6;
                if a < MIN_RADIUS_CM {
                    a = MIN_RADIUS_CM;
                    b = ts.area / (PI * a);
                }
                ts.l = (AMBIENT_DENSITY_CGS * 0.5 * ts.length) / ts.area;
                ts.c = ts.volume / (AMBIENT_DENSITY_CGS * SOUND_VELOCITY_CGS * SOUND_VELOCITY_CGS);
                ts.r[0] = ((2.0 * AIR_VISCOSITY_CGS * ts.length) * (a * a + b * b)) / (PI * a * a * a * b * b * b);
                ts.r[1] = ts.r[0];
            }
            ts.alpha = 0.0;
            ts.beta = 0.0;
            if self.options.soft_walls && i != tube::LOWER_GLOTTIS_SECTION && i != tube::UPPER_GLOTTIS_SECTION {
                let mut surface = if sinus { 4.0 * PI * ((3.0 * ts.volume) / (4.0 * PI)).powf(2.0 / 3.0) } else { circ * ts.length };
                if surface < MIN_AREA_CM2 {
                    surface = MIN_AREA_CM2;
                }
                let rw = ts.bw / surface;
                let lw = ts.mw / surface;
                let cw = surface / ts.kw;
                ts.alpha = 1.0 / (lw / (dt * dt * THETA * THETA) + rw / (dt * THETA) + 1.0 / cw);
                ts.beta = ts.alpha
                    * (ts.wall_current * (lw / (dt * dt * THETA * THETA) + rw / (dt * THETA))
                        + ts.wall_current_rate * (lw * (THETA1 / THETA + 1.0) / (dt * THETA) + rw * (THETA1 / THETA))
                        + ts.wall_current_rate2 * lw * (THETA1 / THETA));
            }
        }
        // (Wide after narrow: the kinetic pressure lost; narrow after wide: Bernoulli.)
        if self.options.turbulence_losses {
            for i in 0..NUM_SECTIONS {
                if ((tube::FIRST_PHARYNX_SECTION + 1..=tube::LAST_MOUTH_SECTION).contains(&i)) || ((tube::FIRST_NOSE_SECTION + 1..=tube::LAST_NOSE_SECTION).contains(&i)) {
                    let prev = &self.ts[i - 1];
                    if prev.current_out[0] != -1 && prev.current_out[1] == -1 {
                        let u = self.current_out(i - 1);
                        if (self.ts[i].area < self.ts[i - 1].area && u > 0.0) || (self.ts[i].area > self.ts[i - 1].area && u < 0.0) {
                            let ts = &mut self.ts[i - 1];
                            ts.r[1] -= u * 0.5 * AMBIENT_DENSITY_CGS / (ts.area * ts.area);
                            let ts = &mut self.ts[i];
                            ts.r[0] += u * 0.5 * AMBIENT_DENSITY_CGS / (ts.area * ts.area);
                        }
                    }
                }
            }
        }
        if !self.options.piriform_fossa {
            let ts = &mut self.ts[tube::FIRST_FOSSA_SECTION];
            ts.r[0] = 8.0 * AIR_VISCOSITY_CGS * ts.length * PI / (MIN_AREA_CM2 * MIN_AREA_CM2);
        }
        // The glottis's nonlinear resistances: its entrance (1 is perfect Bernoulli flow) and between its sections.
        let k_ent = 1.0;
        let source_area = self.ts[tube::LAST_TRACHEA_SECTION].area;
        let target_area = self.ts[tube::LOWER_GLOTTIS_SECTION].area;
        let u = self.current_in(tube::LOWER_GLOTTIS_SECTION);
        if u > 0.0 {
            self.ts[tube::LOWER_GLOTTIS_SECTION].r[0] += k_ent * 0.5 * AMBIENT_DENSITY_CGS * u.abs() * (1.0 / (target_area * target_area) - 1.0 / (source_area * source_area));
        }
        let source_area = self.ts[tube::LOWER_GLOTTIS_SECTION].area;
        let target_area = self.ts[tube::UPPER_GLOTTIS_SECTION].area;
        let u = self.current_out(tube::LOWER_GLOTTIS_SECTION);
        if u > 0.0 && target_area < source_area {
            self.ts[tube::LOWER_GLOTTIS_SECTION].r[1] += u.abs() * 0.5 * AMBIENT_DENSITY_CGS * (1.0 / (target_area * target_area) - 1.0 / (source_area * source_area));
        }
        if self.options.generate_noise_sources {
            self.calc_noise_sources();
        }
        let mut transvelar_flow = 0.0;
        if self.options.transvelar_coupling {
            let p1 = self.ts[tube::FIRST_MOUTH_SECTION + 2].pressure;
            let p2 = self.ts[tube::FIRST_NOSE_SECTION + 2].pressure;
            transvelar_flow = self.transvelar_filter1.output_sample(p1) + self.transvelar_filter2.output_sample(p2);
        }
        for i in 0..NUM_SECTIONS {
            let ts = &mut self.ts[i];
            let mut source_amp = ts.monopole.sample;
            if i == tube::FIRST_NOSE_SECTION + 2 {
                source_amp += transvelar_flow;
            }
            if i as i32 == self.flow_source_section {
                source_amp += self.flow_source_amp;
            }
            let d = dt * THETA / (ts.c + ts.alpha);
            ts.e = d;
            ts.d = ts.pressure + dt * THETA1 * ts.pressure_rate - d * (ts.beta - source_amp);
        }
    }

    // Grows a constricted region from its narrowest section while it stays within MAX_DELTA_AREA and on `art`.
    fn grow(&self, c: &mut Constriction, max_area: f64, art: Articulator, first: usize, last: usize) {
        while self.ts[c.first_section as usize].area < max_area && self.ts[c.first_section as usize].articulator == art && c.first_section > first as i32 {
            c.first_section -= 1;
        }
        while self.ts[c.last_section as usize].area < max_area && self.ts[c.last_section as usize].articulator == art && c.last_section < last as i32 {
            c.last_section += 1;
        }
    }

    fn calc_noise_sources(&mut self) {
        const MAX_CONSTRICTION_AREA: f64 = 1.0;
        const MAX_DELTA_AREA: f64 = 0.2;
        const MAX_TEETH_DISTANCE: f64 = 2.0;
        for ts in self.ts.iter_mut() {
            ts.monopole.target_amp_1khz = 0.0;
            ts.dipole.target_amp_1khz = 0.0;
        }
        self.lips_dipole.target_amp_1khz = 0.0;
        // The source just above the glottis is always there.
        self.num_constrictions = 1;
        self.constriction[0] = Constriction {
            first_section: tube::LOWER_GLOTTIS_SECTION as i32,
            last_section: tube::UPPER_GLOTTIS_SECTION as i32,
            narrowest_section: tube::UPPER_GLOTTIS_SECTION as i32,
            obstacle_pos: 1.5,
            articulator: Articulator::VocalFolds,
            ..Constriction::default()
        };
        let (fp, lm, fm) = (tube::FIRST_PHARYNX_SECTION, tube::LAST_MOUTH_SECTION, tube::FIRST_MOUTH_SECTION);
        let mut min_tongue_area_for_teeth_source = 1000000.0;
        let mut min_tongue_area = 1000000.0;
        let mut min_tongue_section: i32 = -1;
        for i in fp..=lm {
            if self.ts[i].articulator == Articulator::Tongue && self.ts[i].area < min_tongue_area {
                min_tongue_area = self.ts[i].area;
                min_tongue_section = i as i32;
            }
        }
        if min_tongue_area < MAX_CONSTRICTION_AREA {
            let mut c = Constriction { first_section: min_tongue_section, last_section: min_tongue_section, narrowest_section: min_tongue_section, articulator: Articulator::Tongue, ..Constriction::default() };
            self.grow(&mut c, min_tongue_area + MAX_DELTA_AREA, Articulator::Tongue, fp, lm);
            c.first_section += 1;
            c.last_section -= 1;
            let last = &self.ts[c.last_section as usize];
            let jet_pos = last.pos + last.length;
            if self.teeth_position - jet_pos < MAX_TEETH_DISTANCE {
                c.obstacle_pos = self.teeth_position; // (/s, S/)
                min_tongue_area_for_teeth_source = self.ts[c.narrowest_section as usize].area;
            } else {
                let next = &self.ts[c.last_section as usize + 1]; // (/x, ch/)
                c.obstacle_pos = next.pos + 0.5 * next.length;
            }
            self.constriction[self.num_constrictions] = c;
            self.num_constrictions += 1;
        }
        // A second constriction of the tongue?
        if self.num_constrictions > 0 && self.constriction[self.num_constrictions - 1].articulator == Articulator::Tongue {
            let prev = self.constriction[self.num_constrictions - 1];
            min_tongue_area = 1000000.0;
            min_tongue_section = -1;
            for i in fp..=lm {
                if self.ts[i].articulator == Articulator::Tongue && self.ts[i].area < min_tongue_area && ((i as i32) < prev.first_section || (i as i32) > prev.last_section) {
                    min_tongue_area = self.ts[i].area;
                    min_tongue_section = i as i32;
                }
            }
            if min_tongue_area < MAX_CONSTRICTION_AREA {
                let mut c = Constriction { narrowest_section: min_tongue_section, first_section: min_tongue_section, last_section: min_tongue_section, articulator: Articulator::Tongue, ..Constriction::default() };
                self.grow(&mut c, min_tongue_area + MAX_DELTA_AREA, Articulator::Tongue, fp, lm);
                c.first_section += 1;
                c.last_section -= 1;
                if c.first_section > prev.last_section + 1 || c.last_section < prev.first_section - 1 {
                    let last = &self.ts[c.last_section as usize];
                    let jet_pos = last.pos + last.length;
                    if self.teeth_position - jet_pos < MAX_TEETH_DISTANCE {
                        c.obstacle_pos = self.teeth_position;
                        min_tongue_area_for_teeth_source = self.ts[c.narrowest_section as usize].area;
                    } else {
                        let next = &self.ts[c.last_section as usize + 1];
                        c.obstacle_pos = next.pos + 0.5 * next.length;
                    }
                    self.constriction[self.num_constrictions] = c;
                    self.num_constrictions += 1;
                }
            }
        }
        // The narrowest place at the lower lip.
        let mut min_lip_area = 1000000.0;
        let mut min_lip_section: i32 = -1;
        for i in fm..=lm {
            if self.ts[i].articulator == Articulator::LowerLip && self.ts[i].area < min_lip_area {
                min_lip_area = self.ts[i].area;
                min_lip_section = i as i32;
            }
        }
        if min_lip_area < MAX_CONSTRICTION_AREA && min_lip_area < min_tongue_area_for_teeth_source {
            let mut c = Constriction { first_section: min_lip_section, last_section: min_lip_section, narrowest_section: min_lip_section, articulator: Articulator::LowerLip, ..Constriction::default() };
            let max_area = min_lip_area + MAX_DELTA_AREA;
            self.grow(&mut c, max_area, Articulator::LowerLip, fm, lm);
            c.first_section += 1;
            if self.ts[c.last_section as usize].area >= max_area {
                c.last_section -= 1;
            }
            let (f, l) = (&self.ts[c.first_section as usize], &self.ts[c.last_section as usize]);
            c.obstacle_pos = 0.5 * (f.pos + l.pos + l.length);
            self.constriction[self.num_constrictions] = c;
            self.num_constrictions += 1;
        }
        // Each constriction's two dipole sources, either side of its obstacle.
        for k in 0..self.num_constrictions {
            let mut c = self.constriction[k];
            let ns = c.narrowest_section as usize;
            c.area = self.ts[ns].area;
            if c.area < MIN_AREA_CM2 {
                c.area = MIN_AREA_CM2;
            }
            c.flow = 0.0;
            let ts = &self.ts[ns];
            if ts.current_out[0] != -1 {
                c.flow += self.bc[ts.current_out[0] as usize].noise_magnitude;
            }
            if ts.current_out[1] != -1 {
                c.flow += self.bc[ts.current_out[1] as usize].noise_magnitude;
            }
            if c.flow < 0.0 {
                c.flow = 0.0;
            }
            c.velocity = c.flow / c.area;
            c.cutoff_freq = 1000.0;
            c.gain = 0.0;
            if c.articulator == Articulator::LowerLip {
                // (/f/ flat, Badin 1989; /p, b/'s burst low.)
                let (gain_f, cutoff_f, gain_p, cutoff_p) = (2.0e-6, 8000.0, 0.5e-6, 500.0);
                let mut area_at_teeth = 1000000.0;
                for i in fm..=lm {
                    if self.teeth_position >= self.ts[i].pos && self.teeth_position <= self.ts[i].pos + self.ts[i].length {
                        area_at_teeth = self.ts[i].area;
                    }
                }
                const CRITICAL_CONSTRICTION_AREA_CM2: f64 = 0.15;
                let mut d = (-(area_at_teeth - CRITICAL_CONSTRICTION_AREA_CM2) / 0.10).exp();
                if d > 1.0 {
                    d = 1.0;
                }
                c.gain = d * gain_f + (1.0 - d) * gain_p;
                c.cutoff_freq = d * cutoff_f + (1.0 - d) * cutoff_p;
            } else if c.articulator == Articulator::VocalFolds {
                c.gain = 1.0e-6 * 10f64.powf(self.aspiration_strength_db / 20.0);
                c.cutoff_freq = 10000.0;
            } else if (c.obstacle_pos - self.teeth_position).abs() < 0.0001 {
                // (/s, sh, c, d, t/: between fricatives and plosives by the tongue tip's sides.)
                let (gain_fric, cutoff_fric, gain_plos, cutoff_plos) = (1.0e-6, 5000.0, 0.8e-6, 1500.0);
                let mut d = self.tongue_tip_side_elevation;
                if d < 0.0 {
                    d = 0.0;
                }
                if d > 1.0 {
                    d = 1.0;
                }
                c.gain = d * gain_fric + (1.0 - d) * gain_plos;
                c.cutoff_freq = d * cutoff_fric + (1.0 - d) * cutoff_plos;
                if self.tongue_tip_side_elevation < 0.0 {
                    c.gain = 0.0; // (no source for laterals)
                }
            } else {
                c.gain = 0.4e-6; // (a wall source: /x, k/)
                c.cutoff_freq = 800.0;
            }
            const TAPER_START_AREA: f64 = 0.5;
            if c.area >= TAPER_START_AREA {
                let d = (c.area - TAPER_START_AREA) / (MAX_CONSTRICTION_AREA - TAPER_START_AREA);
                c.gain *= 1.0 - d;
            }
            if c.area < 0.15 {
                let d = c.area / 0.15;
                c.gain *= d;
            }
            c.full_amp = c.gain * c.velocity.abs() * c.velocity * c.velocity * c.area.sqrt(); // (Stevens)
            if c.cutoff_freq > 10000.0 {
                c.cutoff_freq = 10000.0;
            }
            if c.cutoff_freq < 1.0 {
                c.cutoff_freq = 1.0;
            }
            let last_mouth = &self.ts[lm];
            if c.obstacle_pos >= last_mouth.pos + last_mouth.length {
                c.obstacle_pos = last_mouth.pos + 0.99 * last_mouth.length;
            }
            c.obstacle_section = -1;
            for i in fp..=lm {
                if self.ts[i].pos <= c.obstacle_pos && self.ts[i].pos + self.ts[i].length >= c.obstacle_pos {
                    c.obstacle_section = i as i32;
                    break;
                }
            }
            if c.obstacle_section != -1 {
                let os = c.obstacle_section as usize;
                let downstream_factor = (c.obstacle_pos - self.ts[os].pos) / self.ts[os].length;
                let upstream_factor = 1.0 - downstream_factor;
                let up = &mut self.ts[os].dipole;
                up.target_amp_1khz = upstream_factor * c.full_amp;
                up.is_first_order = false;
                up.cutoff_freq = c.cutoff_freq;
                let down = if os < lm { &mut self.ts[os + 1].dipole } else { &mut self.lips_dipole };
                down.target_amp_1khz = downstream_factor * c.full_amp;
                down.is_first_order = false;
                down.cutoff_freq = c.cutoff_freq;
            }
            self.constriction[k] = c;
        }
        const MIN_MONOPOLE_AMP: f64 = 0.001;
        const MIN_DIPOLE_AMP: f64 = 0.001;
        let (dt, position) = (self.time_step, self.position);
        for i in fp..=lm {
            let ts = &mut self.ts[i];
            noise_sample(&mut ts.monopole, MIN_MONOPOLE_AMP, dt, position, &mut self.rng);
            noise_sample(&mut ts.dipole, MIN_DIPOLE_AMP, dt, position, &mut self.rng);
        }
        noise_sample(&mut self.lips_dipole, MIN_DIPOLE_AMP, dt, position, &mut self.rng);
    }

    fn calc_matrix(&mut self) {
        let dt = self.time_step;
        self.solution = [0.0; N];
        for i in 0..N {
            let b = self.bc[i];
            if b.target_section == -1 {
                // Into free space: the radiation's resistance and inductance in parallel.
                let src = &self.ts[b.source_section as usize];
                let resistance_current = src.current_out[0] as usize;
                let inductivity_current = src.current_out[1] as usize;
                let ur = self.bc[resistance_current].magnitude;
                let ul = self.bc[inductivity_current].magnitude;
                let ur_rate = self.bc[resistance_current].magnitude_rate;
                let ul_rate = self.bc[inductivity_current].magnitude_rate;
                let l_a = src.l;
                let r_a = src.r[1];
                let s = -self.lips_dipole.sample;
                let radiation_area = src.area;
                let (f, g, h);
                if i == resistance_current {
                    let r_rad = (128.0 * AMBIENT_DENSITY_CGS * SOUND_VELOCITY_CGS) / (9.0 * PI * PI * radiation_area);
                    f = l_a / (dt * THETA) + r_a + r_rad;
                    g = l_a / (dt * THETA) + r_a;
                    h = -(l_a / (dt * THETA)) * (ur + ul) - (l_a * (THETA1 / THETA)) * (ur_rate + ul_rate) + s;
                } else {
                    let l_rad = (8.0 * AMBIENT_DENSITY_CGS) / (3.0 * PI * (radiation_area * PI).sqrt());
                    let l_ab = l_a + l_rad;
                    f = l_a / (dt * THETA) + r_a;
                    g = l_ab / (dt * THETA) + r_a;
                    h = -(1.0 / (dt * THETA)) * (l_a * ur + l_ab * ul) - (THETA1 / THETA) * (l_a * ur_rate + l_ab * ul_rate) + s;
                }
                if src.current_in != -1 {
                    self.matrix[i * N + src.current_in as usize] = src.e;
                }
                self.matrix[i * N + resistance_current] = -src.e - f;
                self.matrix[i * N + inductivity_current] = -src.e - g;
                self.solution[i] = h - src.d;
            } else {
                let tgt = self.ts[b.target_section as usize];
                let src = if b.source_section != -1 { Some(self.ts[b.source_section as usize]) } else { None };
                let l_b = tgt.l;
                let r_b = tgt.r[0];
                let (l_a, r_a) = src.map(|s| (s.l, s.r[1])).unwrap_or((0.0, 0.0));
                let mut l_ab = l_a + l_b;
                let r_ab = r_a + r_b;
                let mut branching_off: i32 = -1;
                if let Some(s) = &src {
                    branching_off = if s.current_out[0] == i as i32 { s.current_out[1] } else { s.current_out[0] };
                }
                let mut s_amp = tgt.s;
                s_amp -= tgt.dipole.sample;
                if b.target_section == self.pressure_source_section {
                    s_amp -= self.pressure_source_amp;
                }
                if branching_off != -1 {
                    let src = src.unwrap();
                    let (ub, ub_rate) = (b.magnitude, b.magnitude_rate);
                    let ud = self.bc[branching_off as usize].magnitude;
                    let ud_rate = self.bc[branching_off as usize].magnitude_rate;
                    let f = l_ab / (dt * THETA) + r_ab;
                    let g = l_a / (dt * THETA) + r_a;
                    let h = -(1.0 / (dt * THETA)) * (l_ab * ub + l_a * ud) - (THETA1 / THETA) * (l_ab * ub_rate + l_a * ud_rate) + s_amp;
                    self.matrix[i * N + branching_off as usize] = -src.e - g;
                    if src.current_in != -1 {
                        self.matrix[i * N + src.current_in as usize] = src.e;
                    }
                    self.matrix[i * N + i] = -tgt.e - src.e - f;
                    if tgt.current_out[0] != -1 {
                        self.matrix[i * N + tgt.current_out[0] as usize] = tgt.e;
                    }
                    if tgt.current_out[1] != -1 {
                        self.matrix[i * N + tgt.current_out[1] as usize] = tgt.e;
                    }
                    self.solution[i] = h + tgt.d - src.d;
                } else {
                    let (u, u_rate) = (b.magnitude, b.magnitude_rate);
                    if self.options.inner_length_corrections && b.source_section >= tube::FIRST_PHARYNX_SECTION as i32 && b.target_section <= tube::LAST_MOUTH_SECTION as i32 {
                        l_ab += junction_inductance(self.ts[b.source_section as usize].area, self.ts[b.target_section as usize].area);
                    }
                    let g = l_ab / (dt * THETA) + r_ab;
                    let h = -u_rate * l_ab * (THETA1 / THETA) - (l_ab * u) / (dt * THETA) + s_amp;
                    if let Some(s) = &src {
                        if s.current_in != -1 {
                            self.matrix[i * N + s.current_in as usize] = s.e;
                        }
                    }
                    self.matrix[i * N + i] = -tgt.e - g;
                    if let Some(s) = &src {
                        self.matrix[i * N + i] -= s.e;
                    }
                    if tgt.current_out[0] != -1 {
                        self.matrix[i * N + tgt.current_out[0] as usize] = tgt.e;
                    }
                    if tgt.current_out[1] != -1 {
                        self.matrix[i * N + tgt.current_out[1] as usize] = tgt.e;
                    }
                    self.solution[i] = h + tgt.d;
                    if let Some(s) = &src {
                        self.solution[i] -= s.d;
                    }
                }
            }
        }
    }

    fn update_variables(&mut self) {
        let dt = self.time_step;
        let noise_filter_coeff = (-2.0 * PI * NOISE_CUTOFF_FREQ * dt).exp();
        for i in 0..N {
            let b = &mut self.bc[i];
            let old_current = b.magnitude;
            b.magnitude = self.flow[i];
            b.magnitude_rate = (b.magnitude - old_current) / (dt * THETA) - (THETA1 / THETA) * b.magnitude_rate;
            b.noise_magnitude = (1.0 - noise_filter_coeff) * b.magnitude + noise_filter_coeff * b.noise_magnitude;
        }
        for i in 0..NUM_SECTIONS {
            let net_flow = self.current_in(i) - self.current_out(i);
            let ts = &mut self.ts[i];
            let old_pressure = ts.pressure;
            ts.pressure = ts.d + ts.e * net_flow;
            ts.pressure_rate = (ts.pressure - old_pressure) / (dt * THETA) - ts.pressure_rate * (THETA1 / THETA);
            let old_current = ts.wall_current;
            let old_current_rate = ts.wall_current_rate;
            ts.wall_current = ts.pressure_rate * ts.alpha + ts.beta;
            ts.wall_current_rate = (ts.wall_current - old_current) / (dt * THETA) - old_current_rate * (THETA1 / THETA);
            ts.wall_current_rate2 = (ts.wall_current_rate - old_current_rate) / (dt * THETA) - ts.wall_current_rate2 * (THETA1 / THETA);
        }
    }

    fn solve_sor(&mut self) {
        const MAX_ITERATIONS: i32 = 100;
        const EPSILON: f64 = 0.1;
        const OMEGA: f64 = 1.25;
        let mut active = [true; N];
        for ts in self.ts.iter() {
            if ts.area <= 1.01 * MIN_AREA_CM2 {
                for c in [ts.current_in, ts.current_out[0], ts.current_out[1]] {
                    if c != -1 {
                        active[c as usize] = false;
                    }
                }
            }
        }
        self.flow = [0.0; N];
        let mut iteration = 0;
        loop {
            let mut residual = 0.0;
            for i in (0..N).rev() {
                if active[i] {
                    let mut sum = self.matrix[i * N + i] * self.flow[i];
                    for &j in self.sor_rows[i].iter().rev() {
                        sum += self.flow[j] * self.matrix[i * N + j];
                    }
                    let d = self.solution[i] - sum;
                    residual += d * d;
                    self.flow[i] += OMEGA * d / self.matrix[i * N + i];
                }
            }
            iteration += 1;
            if !(iteration < MAX_ITERATIONS && residual > EPSILON * EPSILON) {
                break;
            }
        }
        self.sor_iterations = iteration;
    }

    fn solve_cholesky(&mut self) {
        let (m, f) = (&self.matrix, &mut self.factor);
        for i in 0..N {
            f[i * N + i] = -m[i * N + i];
            for &j in &self.env_rows[i] {
                f[i * N + j] = -m[i * N + j];
            }
        }
        for x in self.solution.iter_mut() {
            *x = -*x;
        }
        for k in 0..N {
            for &j in &self.env_rows[k] {
                f[k * N + k] -= f[k * N + j] * f[k * N + j];
            }
            f[k * N + k] = f[k * N + k].sqrt();
            for &i in &self.env_cols[k] {
                for &j in &self.env_rows[k] {
                    f[i * N + k] -= f[i * N + j] * f[k * N + j];
                }
                f[i * N + k] /= f[k * N + k];
            }
        }
        for k in 0..N {
            for &j in &self.env_rows[k] {
                self.solution[k] -= f[k * N + j] * self.solution[j];
            }
            self.solution[k] /= f[k * N + k];
        }
        for k in (0..N).rev() {
            for &i in &self.env_cols[k] {
                self.solution[k] -= f[i * N + k] * self.flow[i];
            }
            self.flow[k] = self.solution[k] / f[k * N + k];
        }
    }
}

/// Sondhi's (1983) junction inductance between two sections, an inner length correction.
fn junction_inductance(a1: f64, a2: f64) -> f64 {
    let a1 = a1.max(MIN_AREA_CM2);
    let a2 = a2.max(MIN_AREA_CM2);
    let (a, b) = if a1 > a2 { ((a1 / PI).sqrt(), (a2 / PI).sqrt()) } else { ((a2 / PI).sqrt(), (a1 / PI).sqrt()) };
    let h = 1.0 - b / a;
    8.0 * AMBIENT_DENSITY_CGS * h / (3.0 * PI * PI * b)
}

/// A noise source's next sample: its amplitude rising toward its target over 3 ms (on its square root), falling at
/// once; off below its threshold; else a Gaussian draw (sd 1/sqrt 12, within +-1) through a critically damped second-
/// order low-pass at its cutoff, its gain keeping the radiated noise's level whatever the cutoff.
fn noise_sample(s: &mut NoiseSource, threshold: f64, dt: f64, position: i32, rng: &mut Mt19937) {
    if s.target_amp_1khz > s.current_amp_1khz {
        let time_constant_samples = 0.003 * SAMPLING_RATE as f64;
        let f = (-1.0 / time_constant_samples).exp();
        let sqrt_target = s.target_amp_1khz.sqrt();
        let mut sqrt_current = s.current_amp_1khz.sqrt();
        sqrt_current = (1.0 - f) * sqrt_target + f * sqrt_current;
        s.current_amp_1khz = sqrt_current * sqrt_current;
    } else {
        s.current_amp_1khz = s.target_amp_1khz;
    }
    if s.current_amp_1khz < threshold {
        s.current_amp_1khz = 0.0;
        s.input = [0.0; 8];
        s.output = [0.0; 8];
        s.sample = 0.0;
        return;
    }
    let (a, b, order): ([f64; 3], [f64; 3], usize) = if s.is_first_order {
        let x = (-2.0 * PI * (s.cutoff_freq * dt)).exp();
        ([1.0 - x, 0.0, 0.0], [1.0, x, 0.0], 1)
    } else {
        let (a0, a1, a2, b1, b2) = second_order_lowpass(s.cutoff_freq * dt, 1.0 / 2f64.sqrt());
        ([a0, a1, a2], [1.0, b1, b2], 2)
    };
    let mut filter_gain = s.current_amp_1khz;
    if s.cutoff_freq < 1.0 {
        s.cutoff_freq = 1.0;
    }
    let factor = 1000.0 / s.cutoff_freq;
    filter_gain *= factor * factor.sqrt();
    // (One distribution for the draw and its rejections, as the C++ makes it: a value outside +-1 is followed by the
    // pair's other value before a new pair is drawn.)
    let mut normal = NormalDistribution::new(1.0 / 12f64.sqrt());
    let mut input;
    loop {
        input = normal.sample(rng);
        if !(input < -1.0 || input > 1.0) {
            break;
        }
    }
    s.input[(position & NOISE_BUFFER_MASK) as usize] = input;
    let mut sum = a[0] * input;
    for k in 1..=order {
        let at = (position.wrapping_sub(k as i32) & NOISE_BUFFER_MASK) as usize;
        sum += a[k] * s.input[at];
        sum += b[k] * s.output[at];
    }
    s.output[(position & NOISE_BUFFER_MASK) as usize] = sum;
    s.sample = sum * filter_gain;
}
