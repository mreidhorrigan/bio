// The reader's F0 tier as targets fitted to its contour (the owner, 15 November 2026, of the read contour: "Targets
// fitted"; the languages session, whose reader it is, agreeing). The reader's contour -- eSpeak NG's vowels' measured
// F0 with lines between, over the document's pitches (ssml.rs) -- is the pitch as heard. Given to the engine as its
// targets, it was approached at the F0 time constant: delayed some five of them and narrowed wherever it moved faster
// (research/MODELING_GAPS.md, "A read contour smoothed twice"). Here each of its pieces, point to point, is one target
// (a value and a slope, at the tier's own time constant), and the targets are those that make the engine's own approach
// pass nearest the contour where the engine samples its curves, every 2.5 ms: v24::gestural param_curve, the fifth-order
// critically damped system as 2.4 plays it (2.3's the same at one time constant), while the utterance is spoken: the
// rules' pause after its phones, where a contour falls back to the document's pitch outside a <prosody>, and the tail
// the engine plays the last target on through keep the contour's own lines. The curve is linear in the targets,
// each column of the system the engine's own curve for one target's value or slope, so the targets are linear least
// squares: once an utterance, no search. A slope beyond the tier's range (2.4's 200 st/s, 2.3's 80) is held there and
// the rest solved again. A target the samples hardly decide (a piece within a sample of the next) keeps nearly its
// contour's own line: the squares weigh it a millionth, by what it moves the curve, toward that line.
use crate::gestural::{Gesture, Target};
use crate::speaker_fit::cholesky_solve;
use crate::v24::gestural::{param_curve, CURVE_SAMPLING_RATE};

/// How strongly each target is drawn to its contour's own line, as a share of what it moves the curve.
const TOWARD_CONTOUR: f64 = 1e-6;

/// The samples a tier's curve is played at over its length: every 2.5 ms from its start through its end.
pub fn samples(tier: &[Gesture]) -> usize {
    let length: f64 = tier.iter().map(|g| g.duration_s).sum();
    (length * CURVE_SAMPLING_RATE as f64) as usize + 1
}

/// The engine's curve for a tier (st) at its first `n` samples.
pub fn approach(tier: &[Gesture], n: usize) -> Vec<f64> {
    let mut curve = vec![0.0; n];
    if tier.is_empty() || n == 0 {
        return curve;
    }
    let mut targets: Vec<Target> = tier.iter().map(|g| Target { duration: g.duration_s, value: g.d_val, slope: g.slope, tau_s: g.tau_s }).collect();
    param_curve(&mut targets, &mut curve, n - 1);
    curve
}

/// The contour a tier of lines draws (each piece from its value at its start, at its slope) at its first `n` samples,
/// each sample on the piece the engine's walk gives it (one on a cut the earlier piece's), the last piece's line
/// continued beyond it.
pub fn contour(tier: &[Gesture], n: usize) -> Vec<f64> {
    let mut out = Vec::with_capacity(n);
    if tier.is_empty() {
        return vec![0.0; n];
    }
    let (mut k, mut start) = (0, 0.0);
    for i in 0..n {
        let t = i as f64 / CURVE_SAMPLING_RATE as f64;
        while k + 1 < tier.len() && t > start + tier[k].duration_s {
            start += tier[k].duration_s;
            k += 1;
        }
        out.push(tier[k].d_val + (t - start) * tier[k].slope);
    }
    out
}

/// The tier whose approach passes nearest the contour `lines` draws where it is `heard` (s from the tier's start: its
/// first phone's start to its last's end): the same pieces, lengths and time constants, each piece's value and slope
/// fitted, its slope within `slopes` (the tier's range, st/s). A piece wholly after the heard -- the rules' pause, and
/// the engine plays the last target on through the score's tail -- moves none of its samples and keeps its contour's
/// line, as the reader's lines did; one before it is fitted for what it leaves the first phone.
pub fn fitted(lines: &[Gesture], slopes: (f64, f64), heard: (f64, f64)) -> Vec<Gesture> {
    let m = 2 * lines.len();
    let n = samples(lines);
    if m == 0 {
        return lines.to_vec();
    }
    let z = contour(lines, n);
    let own: Vec<f64> = lines.iter().flat_map(|g| [g.d_val, g.slope]).collect();
    // (The samples weighed: those within the heard.)
    let rate = CURVE_SAMPLING_RATE as f64;
    let last = (heard.1 * rate).floor();
    let to = if last >= (n - 1) as f64 { n } else if last < 0.0 { 0 } else { last as usize + 1 };
    let from = ((heard.0 * rate).ceil().max(0.0) as usize).min(to);
    // Each target's value's and slope's column -- the engine's curve with that one 1 and the rest 0 -- and the first
    // sample weighed that it moves.
    let mut unit: Vec<Gesture> = lines.iter().map(|g| Gesture { d_val: 0.0, slope: 0.0, ..g.clone() }).collect();
    let mut columns = Vec::with_capacity(m);
    let mut first = Vec::with_capacity(m);
    for j in 0..m {
        set(&mut unit, j, 1.0);
        let mut c = approach(&unit, n);
        set(&mut unit, j, 0.0);
        c[..from].fill(0.0);
        c[to..].fill(0.0);
        first.push(c.iter().position(|x| *x != 0.0).unwrap_or(n));
        columns.push(c);
    }
    let dot = |j: usize, l: usize| -> f64 { (first[j].max(first[l])..n).map(|i| columns[j][i] * columns[l][i]).sum() };
    let gram: Vec<f64> = (0..m * m).map(|x| if x % m >= x / m { dot(x / m, x % m) } else { 0.0 }).collect();
    let gram = |j: usize, l: usize| gram[j.min(l) * m + j.max(l)];
    let toward: Vec<f64> = (0..m).map(|j| (first[j]..n).map(|i| columns[j][i] * z[i]).sum()).collect();
    // (A target that moves no sample keeps its contour's line.)
    let mut held: Vec<Option<f64>> = (0..m).map(|j| if gram(j, j) == 0.0 { Some(own[j]) } else { None }).collect();
    loop {
        let free: Vec<usize> = (0..m).filter(|&j| held[j].is_none()).collect();
        let k = free.len();
        let mut a = vec![0.0; k * k];
        let mut b = vec![0.0; k];
        for (p, &j) in free.iter().enumerate() {
            for (q, &l) in free.iter().enumerate() {
                a[p * k + q] = gram(j, l);
            }
            let weight = TOWARD_CONTOUR * gram(j, j);
            a[p * k + p] += weight;
            b[p] = toward[j] + weight * own[j] - (0..m).filter_map(|h| held[h].map(|v| v * gram(j, h))).sum::<f64>();
        }
        let x = if k == 0 { Vec::new() } else { cholesky_solve(&mut a, &b, k).expect("the targets' normal equations, drawn toward the contour, are positive definite") };
        let mut beyond = false;
        for (p, &j) in free.iter().enumerate() {
            if j % 2 == 1 && (x[p] < slopes.0 || x[p] > slopes.1) {
                held[j] = Some(x[p].clamp(slopes.0, slopes.1));
                beyond = true;
            }
        }
        if !beyond {
            let mut out = lines.to_vec();
            for j in 0..m {
                let v = held[j].unwrap_or_else(|| x[free.iter().position(|&f| f == j).unwrap()]);
                set(&mut out, j, v);
            }
            return out;
        }
    }
}

/// Target j's value (j even) or slope (j odd) of piece j / 2 set to v.
fn set(tier: &mut [Gesture], j: usize, v: f64) {
    if j % 2 == 0 {
        tier[j / 2].d_val = v;
    } else {
        tier[j / 2].slope = v;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const TAU: f64 = 0.0196;
    const SLOPES: (f64, f64) = (-200.0, 200.0);
    /// (Heard throughout.)
    const ALL: (f64, f64) = (0.0, f64::INFINITY);

    /// A tier of lines through (time s, st) points, at the measured time constant.
    fn lines(points: &[(f64, f64)]) -> Vec<Gesture> {
        points.windows(2).map(|w| Gesture { duration_s: w[1].0 - w[0].0, d_val: w[0].1, slope: (w[1].1 - w[0].1) / (w[1].0 - w[0].0), s_val: String::new(), tau_s: TAU, neutral: false }).collect()
    }

    fn rms(a: &[f64], b: &[f64]) -> f64 {
        (a.iter().zip(b).map(|(x, y)| (x - y) * (x - y)).sum::<f64>() / a.len() as f64).sqrt()
    }

    /// The sample at the curve's highest, in seconds, and its value.
    fn peak(c: &[f64]) -> (f64, f64) {
        let (i, v) = c.iter().enumerate().fold((0, f64::MIN), |m, (i, &v)| if v > m.1 { (i, v) } else { m });
        (i as f64 / CURVE_SAMPLING_RATE as f64, v)
    }

    #[test]
    fn a_line_the_engine_follows_is_its_own_target() {
        // (One line cut in four: the engine follows its first target exactly, and the next continue it.)
        let tier = lines(&[(0.0, 84.0), (0.13, 85.3), (0.2, 86.0), (0.41, 88.1), (0.6, 90.0)]);
        let fit = fitted(&tier, SLOPES, ALL);
        // (Each target within a hundredth of a cent and a hundredth of a semitone a second of its line, the rounding the
        // normal equations allow; the curve itself within a millionth of a semitone.)
        for (f, t) in fit.iter().zip(&tier) {
            assert!((f.d_val - t.d_val).abs() < 1e-4 && (f.slope - t.slope).abs() < 1e-2, "{f:?} for {t:?}");
        }
        let n = samples(&tier);
        assert!(rms(&approach(&fit, n), &contour(&tier, n)) < 1e-6);
    }

    #[test]
    fn an_accent_on_time_and_at_its_height() {
        // (A rise of 4 st over 120 ms to an accent and a fall of 6 over 200 ms, level between: the contour's own lines,
        // approached, peak late and low; the fitted targets' approach passes nearest the contour.)
        let tier = lines(&[(0.0, 84.0), (0.2, 84.0), (0.32, 88.0), (0.52, 82.0), (0.9, 82.0)]);
        let n = samples(&tier);
        let want = contour(&tier, n);
        let plain = approach(&tier, n);
        let fit = fitted(&tier, SLOPES, ALL);
        let got = approach(&fit, n);
        let (e_plain, e_fit) = (rms(&plain, &want), rms(&got, &want));
        let ((t_plain, p_plain), (t_fit, p_fit)) = (peak(&plain), peak(&got));
        println!("rms {e_plain:.3} -> {e_fit:.3} st; peak {t_plain:.4} s {p_plain:.2} st -> {t_fit:.4} s {p_fit:.2} st (the contour's 0.32, 88)");
        for g in &fit {
            println!("  {:.3} s: {:.2} st, {:.1} st/s", g.duration_s, g.d_val, g.slope);
        }
        assert!(e_fit < e_plain / 4.0, "rms {e_plain} -> {e_fit}");
        assert!((t_fit - 0.32).abs() < (t_plain - 0.32).abs() / 4.0, "peak at {t_plain} -> {t_fit}");
        assert!((p_fit - 88.0).abs() < (p_plain - 88.0).abs() / 2.0, "peak {p_plain} -> {p_fit}");
        assert!(fit.iter().all(|g| g.slope >= SLOPES.0 && g.slope <= SLOPES.1));
    }

    #[test]
    fn a_slope_beyond_the_tier_is_held_at_its_range() {
        // (A step of 7 st within 10 ms, as a <prosody pitch> begins: its pieces' fitted slopes would pass the tier's
        // range; those are held at it and the rest solved again, still nearer than the contour's own lines.)
        let tier = lines(&[(0.0, 80.0), (0.25, 80.0), (0.26, 87.0), (0.6, 87.0), (0.61, 80.0), (0.9, 80.0)]);
        let n = samples(&tier);
        let want = contour(&tier, n);
        let fit = fitted(&tier, SLOPES, ALL);
        assert!(fit.iter().all(|g| g.slope >= SLOPES.0 - 1e-12 && g.slope <= SLOPES.1 + 1e-12), "{fit:?}");
        assert!(fit.iter().any(|g| (g.slope.abs() - SLOPES.1).abs() < 1e-12), "none held: {fit:?}");
        let (e_plain, e_fit) = (rms(&approach(&tier, n), &want), rms(&approach(&fit, n), &want));
        let speed = |c: &[f64]| c.windows(2).map(|w| (w[1] - w[0]).abs() * CURVE_SAMPLING_RATE as f64).fold(0.0, f64::max);
        println!("rms {e_plain:.3} -> {e_fit:.3} st; fastest {:.0} -> {:.0} st/s", speed(&approach(&tier, n)), speed(&approach(&fit, n)));
        for g in &fit {
            println!("  {:.3} s: {:.2} st, {:.1} st/s", g.duration_s, g.d_val, g.slope);
        }
        assert!(e_fit < e_plain, "rms {e_plain} -> {e_fit}");
    }

    #[test]
    fn the_pause_after_the_phones_keeps_its_line() {
        // (The test document's "Sie sind süß." at +5 st: 65 ms of the rules before its first phone, at the document's
        // pitch outside the <prosody>; its phones; the rules' 50 ms pause after them, back at that pitch. Fitted
        // throughout, the pause drew the last vowel's held part down (2.3's 30 ms and its slopes to 80 st/s, and 2.4's)
        // and its target, decided by two samples, went to -177 st, played on through the tail; fitted where it is
        // spoken, the vowel holds its pitch and the pause keeps its line.)
        let level = 86.38;
        for (tau, slopes) in [(0.03, (-80.0, 80.0)), (TAU, SLOPES)] {
            let tier: Vec<Gesture> = [(0.065, 81.38), (0.778, level), (0.05, 81.38)].iter().map(|&(d, v)| Gesture { duration_s: d, d_val: v, slope: 0.0, s_val: String::new(), tau_s: tau, neutral: false }).collect();
            let n = samples(&tier);
            let worst = |fit: &[Gesture]| approach(fit, n)[240..337].iter().map(|c| c - level).fold(0.0f64, |m, x| if x.abs() > m.abs() { x } else { m });
            let (throughout, spoken) = (fitted(&tier, slopes, ALL), fitted(&tier, slopes, (0.065, 0.843)));
            println!("tau {tau}: the last vowel off its pitch by {:+.3} st fitted throughout, {:+.3} where spoken", worst(&throughout), worst(&spoken));
            assert!(worst(&throughout).abs() > 0.5 && worst(&spoken).abs() < 0.05, "{throughout:?} {spoken:?}");
            assert_eq!((spoken[2].d_val, spoken[2].slope), (81.38, 0.0));
        }
    }
}
