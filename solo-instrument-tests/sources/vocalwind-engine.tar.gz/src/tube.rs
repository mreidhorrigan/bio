// The vocal tract as a tube of short sections (Tube.cpp): the trachea, the glottis, the pharynx and mouth (the only part
// that moves in speech, with the glottis), the nose with its sinuses, and the piriform fossae; each section its length,
// area, wall and the articulator that bounds it. One array in the C++'s order of `section[]`.

pub const NUM_TRACHEA_SECTIONS: usize = 23;
pub const NUM_GLOTTIS_SECTIONS: usize = 2;
pub const NUM_PHARYNX_SECTIONS: usize = 16;
pub const NUM_MOUTH_SECTIONS: usize = 24;
pub const NUM_PHARYNX_MOUTH_SECTIONS: usize = NUM_PHARYNX_SECTIONS + NUM_MOUTH_SECTIONS;
pub const NUM_NOSE_SECTIONS: usize = 19;
pub const NUM_SINUS_SECTIONS: usize = 4;
pub const NUM_FOSSA_SECTIONS: usize = 5;
pub const NUM_SECTIONS: usize = NUM_TRACHEA_SECTIONS + NUM_GLOTTIS_SECTIONS + NUM_PHARYNX_MOUTH_SECTIONS + NUM_NOSE_SECTIONS + NUM_SINUS_SECTIONS + NUM_FOSSA_SECTIONS;

pub const FIRST_TRACHEA_SECTION: usize = 0;
pub const FIRST_GLOTTIS_SECTION: usize = FIRST_TRACHEA_SECTION + NUM_TRACHEA_SECTIONS;
pub const LOWER_GLOTTIS_SECTION: usize = FIRST_GLOTTIS_SECTION;
pub const UPPER_GLOTTIS_SECTION: usize = FIRST_GLOTTIS_SECTION + 1;
pub const FIRST_PHARYNX_SECTION: usize = FIRST_GLOTTIS_SECTION + NUM_GLOTTIS_SECTIONS;
pub const FIRST_MOUTH_SECTION: usize = FIRST_PHARYNX_SECTION + NUM_PHARYNX_SECTIONS;
pub const FIRST_NOSE_SECTION: usize = FIRST_PHARYNX_SECTION + NUM_PHARYNX_MOUTH_SECTIONS;
pub const FIRST_FOSSA_SECTION: usize = FIRST_NOSE_SECTION + NUM_NOSE_SECTIONS;
pub const FIRST_SINUS_SECTION: usize = FIRST_FOSSA_SECTION + NUM_FOSSA_SECTIONS;
pub const LAST_TRACHEA_SECTION: usize = FIRST_TRACHEA_SECTION + NUM_TRACHEA_SECTIONS - 1;
pub const LAST_PHARYNX_SECTION: usize = FIRST_PHARYNX_SECTION + NUM_PHARYNX_SECTIONS - 1;
pub const LAST_MOUTH_SECTION: usize = FIRST_MOUTH_SECTION + NUM_MOUTH_SECTIONS - 1;
pub const LAST_NOSE_SECTION: usize = FIRST_NOSE_SECTION + NUM_NOSE_SECTIONS - 1;
pub const LAST_FOSSA_SECTION: usize = FIRST_FOSSA_SECTION + NUM_FOSSA_SECTIONS - 1;
pub const LAST_SINUS_SECTION: usize = FIRST_SINUS_SECTION + NUM_SINUS_SECTIONS - 1;
pub const FOSSA_COUPLING_SECTION: usize = 3;
pub const SINUS_COUPLING_SECTION: [usize; NUM_SINUS_SECTIONS] = [8, 9, 11, 12];

// (A higher wall resistance than the literature's, as Birkholz chose it: lower, F1 rises too far.)
// (2.3's walls and the static ducts' sizes, from acoustics/tract.json: STANDARD_WALL_MASS_CGS,
// STANDARD_WALL_RESISTANCE_CGS, STANDARD_WALL_STIFFNESS_CGS; DEFAULT_SUBGLOTTAL_CAVITY_LENGTH_CM,
// DEFAULT_NASAL_CAVITY_LENGTH_CM, DEFAULT_PIRIFORM_FOSSA_LENGTH_CM, DEFAULT_PIRIFORM_FOSSA_VOLUME_CM3.)
include!(concat!(env!("OUT_DIR"), "/tract-tube.rs"));
pub const MIN_AREA_CM2: f64 = 0.01e-2;
pub const DEFAULT_ASPIRATION_STRENGTH_DB: f64 = -40.0;

/// The articulator bounding a section (its noise sources depend on it).
#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
#[repr(u8)]
pub enum Articulator {
    VocalFolds = 0,
    Tongue = 1,
    LowerIncisors = 2,
    LowerLip = 3,
    #[default]
    Other = 4,
}

impl Articulator {
    pub fn from_index(i: i32) -> Articulator {
        match i {
            0 => Articulator::VocalFolds,
            1 => Articulator::Tongue,
            2 => Articulator::LowerIncisors,
            3 => Articulator::LowerLip,
            _ => Articulator::Other,
        }
    }
}

#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct Section {
    pub pos_cm: f64,
    pub area_cm2: f64,
    pub length_cm: f64,
    pub volume_cm3: f64,
    pub wall_mass_cgs: f64,
    pub wall_stiffness_cgs: f64,
    pub wall_resistance_cgs: f64,
    pub articulator: Articulator,
}

#[derive(Clone, Debug)]
pub struct Tube {
    pub section: [Section; NUM_SECTIONS],
    pub teeth_position_cm: f64,
    pub aspiration_strength_db: f64,
    pub tongue_tip_side_elevation: f64,
    static_parts_initialized: bool,
    subglottal_cavity_length_cm: f64,
    nasal_cavity_length_cm: f64,
    piriform_fossa_length_cm: f64,
    piriform_fossa_volume_cm3: f64,
    raw_velum_opening_cm2: f64,
}

impl Default for Tube {
    fn default() -> Self {
        Tube::new()
    }
}

impl Tube {
    pub fn new() -> Tube {
        let mut t = Tube {
            section: [Section::default(); NUM_SECTIONS],
            teeth_position_cm: 0.0,
            aspiration_strength_db: 0.0,
            tongue_tip_side_elevation: 0.0,
            static_parts_initialized: false,
            subglottal_cavity_length_cm: 0.0,
            nasal_cavity_length_cm: 0.0,
            piriform_fossa_length_cm: 0.0,
            piriform_fossa_volume_cm3: 0.0,
            raw_velum_opening_cm2: 0.0,
        };
        t.init_subglottal_cavity(DEFAULT_SUBGLOTTAL_CAVITY_LENGTH_CM);
        t.init_nasal_cavity(DEFAULT_NASAL_CAVITY_LENGTH_CM);
        t.init_piriform_fossa(DEFAULT_PIRIFORM_FOSSA_LENGTH_CM, DEFAULT_PIRIFORM_FOSSA_VOLUME_CM3);
        t.static_parts_initialized = true;
        t.reset_dynamic_part();
        t.set_velum_opening(0.0);
        t.set_glottis_area(0.0);
        t.set_aspiration_strength(DEFAULT_ASPIRATION_STRENGTH_DB);
        t.teeth_position_cm = 15.0;
        t.tongue_tip_side_elevation = 0.0;
        t.calc_positions();
        t
    }

    pub fn init_subglottal_cavity(&mut self, length_cm: f64) {
        const EPSILON: f64 = 0.000000001;
        if (length_cm - self.subglottal_cavity_length_cm).abs() < EPSILON {
            return;
        }
        self.subglottal_cavity_length_cm = length_cm;
        for i in 0..NUM_TRACHEA_SECTIONS {
            let ts = &mut self.section[FIRST_TRACHEA_SECTION + i];
            ts.pos_cm = 0.0;
            ts.area_cm2 = 2.5;
            ts.length_cm = length_cm / NUM_TRACHEA_SECTIONS as f64;
            ts.volume_cm3 = ts.area_cm2 * ts.length_cm;
            ts.wall_mass_cgs = 0.25;
            ts.wall_resistance_cgs = 1000.0;
            ts.wall_stiffness_cgs = STANDARD_WALL_STIFFNESS_CGS;
            ts.articulator = Articulator::Other;
        }
        for (i, area) in [(0, 4.0), (1, 3.0)] {
            let ts = &mut self.section[FIRST_TRACHEA_SECTION + i];
            ts.area_cm2 = area;
            ts.length_cm = length_cm / NUM_TRACHEA_SECTIONS as f64;
            ts.volume_cm3 = ts.area_cm2 * ts.length_cm;
        }
    }

    pub fn init_nasal_cavity(&mut self, length_cm: f64) {
        const EPSILON: f64 = 0.000000001;
        if (length_cm - self.nasal_cavity_length_cm).abs() < EPSILON {
            return;
        }
        self.nasal_cavity_length_cm = length_cm;
        // (Dang & Honda 1994, subject 1, each section's centre.)
        const NOSE_LENGTH_CM: [f64; NUM_NOSE_SECTIONS] = [0.6; NUM_NOSE_SECTIONS];
        const NOSE_AREA_CM2: [f64; NUM_NOSE_SECTIONS] = [1.63, 2.07, 2.72, 3.59, 4.24, 3.26, 3.04, 3.04, 2.72, 2.5, 2.39, 2.39, 1.85, 0.76, 1.41, 1.74, 1.30, 1.74, 0.76];
        const SINUS_VOLUME_CM3: [f64; NUM_SINUS_SECTIONS] = [11.3, 6.8, 33.0, 6.2];
        const NECK_LENGTH_CM: [f64; NUM_SINUS_SECTIONS] = [0.3, 0.3, 0.45, 1.0];
        const NECK_AREA_CM2: [f64; NUM_SINUS_SECTIONS] = [0.185, 0.185, 0.145, 0.11];
        let length_factor = length_cm / DEFAULT_NASAL_CAVITY_LENGTH_CM;
        for i in 0..NUM_NOSE_SECTIONS {
            let initialized = self.static_parts_initialized;
            let ts = &mut self.section[FIRST_NOSE_SECTION + i];
            ts.pos_cm = 0.0;
            if !initialized {
                ts.area_cm2 = NOSE_AREA_CM2[i];
            }
            ts.length_cm = length_factor * NOSE_LENGTH_CM[i];
            ts.volume_cm3 = ts.area_cm2 * ts.length_cm;
            ts.wall_mass_cgs = STANDARD_WALL_MASS_CGS;
            ts.wall_resistance_cgs = STANDARD_WALL_RESISTANCE_CGS;
            ts.wall_stiffness_cgs = STANDARD_WALL_STIFFNESS_CGS;
            ts.articulator = Articulator::Other;
        }
        if !self.static_parts_initialized {
            for i in 0..NUM_SINUS_SECTIONS {
                let ts = &mut self.section[FIRST_SINUS_SECTION + i];
                ts.pos_cm = 0.0;
                ts.area_cm2 = NECK_AREA_CM2[i];
                ts.length_cm = NECK_LENGTH_CM[i];
                ts.volume_cm3 = SINUS_VOLUME_CM3[i];
                ts.wall_mass_cgs = 0.0;
                ts.wall_resistance_cgs = 6500.0;
                ts.wall_stiffness_cgs = STANDARD_WALL_STIFFNESS_CGS;
                ts.articulator = Articulator::Other;
            }
        }
    }

    pub fn init_piriform_fossa(&mut self, length_cm: f64, volume_cm3: f64) {
        const EPSILON: f64 = 0.000000001;
        if (length_cm - self.piriform_fossa_length_cm).abs() < EPSILON && (volume_cm3 - self.piriform_fossa_volume_cm3).abs() < EPSILON {
            return;
        }
        self.piriform_fossa_length_cm = length_cm;
        self.piriform_fossa_volume_cm3 = volume_cm3;
        let max_area_cm2 = 2.0 * volume_cm3 / length_cm;
        let section_length_cm = length_cm / NUM_FOSSA_SECTIONS as f64;
        for i in 0..NUM_FOSSA_SECTIONS {
            let ts = &mut self.section[FIRST_FOSSA_SECTION + i];
            ts.pos_cm = 0.0;
            ts.area_cm2 = max_area_cm2 * (1.0 - (i as f64 + 0.5) / NUM_FOSSA_SECTIONS as f64);
            ts.length_cm = section_length_cm;
            ts.volume_cm3 = ts.area_cm2 * ts.length_cm;
            ts.wall_mass_cgs = STANDARD_WALL_MASS_CGS;
            ts.wall_resistance_cgs = STANDARD_WALL_RESISTANCE_CGS;
            ts.wall_stiffness_cgs = STANDARD_WALL_STIFFNESS_CGS;
            ts.articulator = Articulator::Other;
        }
    }

    pub fn reset_dynamic_part(&mut self) {
        for i in 0..NUM_GLOTTIS_SECTIONS {
            let ts = &mut self.section[FIRST_GLOTTIS_SECTION + i];
            ts.pos_cm = 0.0;
            ts.area_cm2 = 0.1;
            ts.length_cm = 0.3;
            ts.volume_cm3 = ts.area_cm2 * ts.length_cm;
            ts.wall_mass_cgs = STANDARD_WALL_MASS_CGS;
            ts.wall_resistance_cgs = STANDARD_WALL_RESISTANCE_CGS;
            ts.wall_stiffness_cgs = STANDARD_WALL_STIFFNESS_CGS;
            ts.articulator = Articulator::VocalFolds;
        }
        for i in 0..NUM_PHARYNX_MOUTH_SECTIONS {
            let ts = &mut self.section[FIRST_PHARYNX_SECTION + i];
            ts.pos_cm = 0.0;
            ts.area_cm2 = 4.0;
            ts.length_cm = 16.0 / NUM_PHARYNX_MOUTH_SECTIONS as f64;
            ts.volume_cm3 = ts.area_cm2 * ts.length_cm;
            ts.wall_mass_cgs = STANDARD_WALL_MASS_CGS;
            ts.wall_resistance_cgs = STANDARD_WALL_RESISTANCE_CGS;
            ts.wall_stiffness_cgs = STANDARD_WALL_STIFFNESS_CGS;
            ts.articulator = Articulator::Other;
        }
    }

    pub fn set_pharynx_mouth_geometry(&mut self, length_cm: &[f64], area_cm2: &[f64], articulator: &[Articulator], incisor_pos_cm: f64, tongue_tip_side_elevation: f64) {
        let mut pos_cm = 0.0;
        for i in 0..NUM_PHARYNX_MOUTH_SECTIONS {
            let ts = &mut self.section[FIRST_PHARYNX_SECTION + i];
            ts.pos_cm = pos_cm;
            ts.length_cm = length_cm[i];
            ts.area_cm2 = area_cm2[i];
            if ts.area_cm2 < MIN_AREA_CM2 {
                ts.area_cm2 = MIN_AREA_CM2;
            }
            ts.volume_cm3 = ts.area_cm2 * ts.length_cm;
            ts.articulator = articulator[i];
            pos_cm += ts.length_cm;
        }
        self.teeth_position_cm = incisor_pos_cm;
        self.tongue_tip_side_elevation = tongue_tip_side_elevation;
        self.calc_positions();
    }

    pub fn set_glottis_geometry(&mut self, length_cm: &[f64; 2], area_cm2: &[f64; 2]) {
        let mut pos_cm = 0.0;
        for i in 0..NUM_GLOTTIS_SECTIONS {
            let ts = &mut self.section[FIRST_GLOTTIS_SECTION + i];
            ts.pos_cm = pos_cm;
            ts.length_cm = length_cm[i];
            ts.area_cm2 = area_cm2[i];
            if ts.area_cm2 < MIN_AREA_CM2 {
                ts.area_cm2 = MIN_AREA_CM2;
            }
            ts.volume_cm3 = ts.area_cm2 * ts.length_cm;
            ts.articulator = Articulator::VocalFolds;
            pos_cm += ts.length_cm;
        }
        self.calc_positions();
    }

    pub fn set_glottis_area(&mut self, area_cm2: f64) {
        self.set_glottis_geometry(&[0.3, 0.3], &[area_cm2, area_cm2]);
    }

    /// The first sections of the nose shaped for a velopharyngeal port of this area.
    pub fn set_velum_opening(&mut self, opening_area_cm2: f64) {
        self.raw_velum_opening_cm2 = opening_area_cm2;
        const N: usize = 4;
        let target_area_cm2 = self.section[FIRST_NOSE_SECTION + N].area_cm2;
        for i in 0..N {
            let ts = &mut self.section[FIRST_NOSE_SECTION + i];
            ts.area_cm2 = opening_area_cm2 + ((i * i) as f64 * (target_area_cm2 - opening_area_cm2)) / (N * N) as f64;
            if ts.area_cm2 < MIN_AREA_CM2 {
                ts.area_cm2 = MIN_AREA_CM2;
            }
            ts.volume_cm3 = ts.area_cm2 * ts.length_cm;
        }
    }

    pub fn set_aspiration_strength(&mut self, db: f64) {
        self.aspiration_strength_db = db;
    }

    pub fn velum_opening_cm2(&self) -> f64 {
        self.raw_velum_opening_cm2
    }

    /// (subglottal cavity length, nasal cavity length, fossa length, fossa volume)
    pub fn static_dimensions(&self) -> (f64, f64, f64, f64) {
        (self.subglottal_cavity_length_cm, self.nasal_cavity_length_cm, self.piriform_fossa_length_cm, self.piriform_fossa_volume_cm3)
    }

    /// This tube as (1 - ratio) of left and ratio of right.
    pub fn interpolate(&mut self, left: &Tube, right: &Tube, ratio: f64) {
        let mut length_cm = [0.0; NUM_PHARYNX_MOUTH_SECTIONS];
        let mut area_cm2 = [0.0; NUM_PHARYNX_MOUTH_SECTIONS];
        let mut articulator = [Articulator::Other; NUM_PHARYNX_MOUTH_SECTIONS];
        let ratio1 = 1.0 - ratio;
        for i in 0..NUM_PHARYNX_MOUTH_SECTIONS {
            let (l, r) = (&left.section[FIRST_PHARYNX_SECTION + i], &right.section[FIRST_PHARYNX_SECTION + i]);
            area_cm2[i] = ratio1 * l.area_cm2 + ratio * r.area_cm2;
            length_cm[i] = ratio1 * l.length_cm + ratio * r.length_cm;
            articulator[i] = if ratio < 0.5 { l.articulator } else { r.articulator };
        }
        let incisor_pos_cm = ratio1 * left.teeth_position_cm + ratio * right.teeth_position_cm;
        let tongue_tip_side_elevation = ratio1 * left.tongue_tip_side_elevation + ratio * right.tongue_tip_side_elevation;
        self.set_pharynx_mouth_geometry(&length_cm, &area_cm2, &articulator, incisor_pos_cm, tongue_tip_side_elevation);
        self.set_velum_opening(ratio1 * left.velum_opening_cm2() + ratio * right.velum_opening_cm2());
        self.aspiration_strength_db = ratio1 * left.aspiration_strength_db + ratio * right.aspiration_strength_db;
        let (ls, ln, lfl, lfv) = left.static_dimensions();
        let (rs, rn, rfl, rfv) = right.static_dimensions();
        self.init_subglottal_cavity(ratio1 * ls + ratio * rs);
        self.init_nasal_cavity(ratio1 * ln + ratio * rn);
        self.init_piriform_fossa(ratio1 * lfl + ratio * rfl, ratio1 * lfv + ratio * rfv);
    }

    pub fn calc_positions(&mut self) {
        let s = &mut self.section;
        let mut pos = 0.0;
        pos -= s[UPPER_GLOTTIS_SECTION].length_cm;
        s[UPPER_GLOTTIS_SECTION].pos_cm = pos;
        pos -= s[LOWER_GLOTTIS_SECTION].length_cm;
        s[LOWER_GLOTTIS_SECTION].pos_cm = pos;
        for i in (0..NUM_TRACHEA_SECTIONS).rev() {
            pos -= s[FIRST_TRACHEA_SECTION + i].length_cm;
            s[FIRST_TRACHEA_SECTION + i].pos_cm = pos;
        }
        let (mut fossa_pos, mut nose_pos) = (0.0, 0.0);
        pos = 0.0;
        for i in 0..NUM_PHARYNX_MOUTH_SECTIONS {
            s[FIRST_PHARYNX_SECTION + i].pos_cm = pos;
            pos += s[FIRST_PHARYNX_SECTION + i].length_cm;
            if i == FOSSA_COUPLING_SECTION {
                fossa_pos = pos;
            }
            if i == NUM_PHARYNX_SECTIONS - 1 {
                nose_pos = pos;
            }
        }
        pos = nose_pos;
        for i in 0..NUM_NOSE_SECTIONS {
            s[FIRST_NOSE_SECTION + i].pos_cm = pos;
            pos += s[FIRST_NOSE_SECTION + i].length_cm;
        }
        pos = fossa_pos;
        for i in 0..NUM_FOSSA_SECTIONS {
            s[FIRST_FOSSA_SECTION + i].pos_cm = pos;
            pos += s[FIRST_FOSSA_SECTION + i].length_cm;
        }
        for i in 0..NUM_SINUS_SECTIONS {
            let c = FIRST_NOSE_SECTION + SINUS_COUPLING_SECTION[i];
            s[FIRST_SINUS_SECTION + i].pos_cm = s[c].pos_cm + s[c].length_cm;
        }
    }
}
