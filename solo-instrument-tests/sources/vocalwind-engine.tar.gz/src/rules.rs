// The numbers of VocalTractLab's segment rules, 2.3's (languages/rules-2.3.json, src/segments.rs) and 2.4's
// (languages/rules-2.4.json, src/v24/segments.rs), as each writes them; the phones' own in languages/phones.json
// (src/inventory.rs). Read once; a file of the same name in $MUSEBOTS_VOCALWIND_LANGUAGES is read in place of the one
// built in. Every field is asked for: a file missing one, or naming one there is not, is refused.
use crate::inventory::language_file;
use serde::Deserialize;
use std::sync::OnceLock;

macro_rules! group {
    ($name:ident { $($field:ident),* $(,)? }) => {
        #[derive(Debug, Deserialize)]
        #[serde(deny_unknown_fields)]
        pub struct $name {
            #[serde(default)]
            #[allow(dead_code)]
            about: String,
            $(pub $field: f64,)*
        }
    };
}

group!(Lungs24 { pressure_dpa, onset_tau_s, offset_tau_s, lead_taus_glottal_fricative, lead_taus_voiceless_plosive_from_middle, lead_taus_fricative, lead_taus_other, end_dpa_fricative, end_dpa_plosive, end_dpa_other });
group!(Vowels24 { lead_taus_first, around_taus_after_vowel, onset_a_s, onset_b, onset_c, target_d_s, target_e, onset_earliest_before_previous_end_s, onset_after_fraction_of_previous, target_latest_after_begin_s, longest_movement_s, tau_fraction_of_movement });
group!(Diphthongs24 { transition_a_s, transition_b, lead_taus, first_alternative_after_begin_s, onset_before_previous_end_s, longest_movement_s, tau_fraction_of_movement });
group!(Fricatives24 { transition_taus, oral_lead_s, oral_held_before_plosive_elsewhere_s, glottis_held_before_voiceless_plosive_s });
group!(Glottal { lead_s });
group!(Lateral24 { transition_s, tau_fraction_of_transition });
group!(Plosives24 { short_release_vot_s, short_release_offset_tau_s, min_closure_s, glottis_lead_s, glottis_end_before_end_s, glottis_min_s, voiced_glottis_end_before_end_s, glottis_shortened_before_voiced_fricative_s, released_glottis_end_before_end_s, lateral_release_glottis_end_before_end_s, min_glottal_gesture_s });
group!(Nasals24 { velic_lead_after_plosive_s, velic_beside_fricative_s, velic_beside_lateral_s });
group!(Closing24 { min_closure_s, start_before_closure_s, earliest_start_s, longest_gesture_s, shortest_gesture_s, release_tau_step_s, release_tau_least_s, return_taus, closed_area_factor, tongue_tip_region_cm });
group!(Velic24 { min_opening_s, end_after_opening_s, min_gesture_s, longest_gesture_s, earliest_start_s, fallback_lead_s, first_end_after_start_s, open_cm2, return_taus });
group!(Pitch24 { least_f0_hz, glottal_stop_dip_st_per_s, glottal_stop_floor_st, tau_s, first_node_lead_s, least_interval_s });

/// VocalTractLab 2.4's rules' numbers (languages/rules-2.4.json).
#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Rules24 {
    #[allow(dead_code)]
    about: String,
    pub phonation: String,
    pub neutral_vowel: String,
    pub min_gesture_s: f64,
    pub start_end_pause_s: f64,
    pub lungs: Lungs24,
    pub vowels: Vowels24,
    pub diphthongs: Diphthongs24,
    pub fricatives: Fricatives24,
    pub glottal: Glottal,
    pub lateral: Lateral24,
    pub plosives: Plosives24,
    pub nasals: Nasals24,
    pub closing: Closing24,
    pub velic: Velic24,
    pub pitch: Pitch24,
}

group!(Lungs23 { lead_before_plosive_s, lead_s, fall_before_end_s, pressure_dpa, onset_tau_s, release_s });
group!(Vowels23 { end_before_end_s, diphthong_lag_after_s, diphthong_lag_most_s });
group!(Fricatives23 { early_s, oral_lead_s, oral_lead_voiced_s, oral_held_s, glottis_held_before_voiceless_plosive_s });
group!(Plosives23 { closure_least_share, closure_least_s, glottis_lead_s, glottis_end_before_end_s, glottis_shortened_before_voiced_fricative_s, released_glottis_end_before_end_s, lateral_release_glottis_end_before_end_s, final_voiceless_glottis_held_s });
group!(Nasals23 { velic_lead_s, velic_held_s, velic_lead_after_plosive_s, velic_beside_fricative_s, velic_lead_after_lateral_s, velic_held_before_lateral_s });
group!(Lateral23 { early_s, lead_s });
group!(Closing23 { min_closure_s, start_before_closure_s, earliest_start_s, longest_gesture_s, shortest_gesture_s, closed_area_factor, tongue_tip_region_cm });
group!(Velic23 { min_opening_s, start_before_opening_s, end_before_opening_end_s, min_gesture_s, longest_gesture_s, earliest_start_s, first_end_after_start_s, open });

/// VocalTractLab 2.3's rules' numbers (languages/rules-2.3.json).
#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Rules23 {
    #[allow(dead_code)]
    about: String,
    pub phonation: String,
    pub neutral_vowel: String,
    pub lungs: Lungs23,
    pub vowels: Vowels23,
    pub fricatives: Fricatives23,
    pub plosives: Plosives23,
    pub nasals: Nasals23,
    pub glottal: Glottal,
    pub lateral: Lateral23,
    pub closing: Closing23,
    pub velic: Velic23,
}

pub fn rules24() -> &'static Rules24 {
    static RULES: OnceLock<Rules24> = OnceLock::new();
    RULES.get_or_init(|| serde_json::from_str(&language_file("rules-2.4.json", include_str!("../languages/rules-2.4.json"))).unwrap_or_else(|e| panic!("languages/rules-2.4.json: {e}")))
}

pub fn rules23() -> &'static Rules23 {
    static RULES: OnceLock<Rules23> = OnceLock::new();
    RULES.get_or_init(|| serde_json::from_str(&language_file("rules-2.3.json", include_str!("../languages/rules-2.3.json"))).unwrap_or_else(|e| panic!("languages/rules-2.3.json: {e}")))
}

#[cfg(test)]
mod tests {
    #[test]
    fn both_rule_sets_read() {
        assert_eq!(super::rules24().closing.tongue_tip_region_cm, 2.2);
        assert_eq!(super::rules23().fricatives.early_s, 0.057);
    }
}
