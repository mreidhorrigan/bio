// VocalTractLab's recursive filters (IirFilter.cpp): y[n] = sum a[i] x[n-i] + sum b[i] y[n-i], its buffers 64 long, and
// the filters it makes -- one pole, a bilinear second order, a Chebyshev of 0.5% ripple (after Smith's "Scientist and
// Engineer's Guide to DSP", ch. 20) -- each expression in its order.
use crate::constants::PI;

pub const MAX_IIR_ORDER: usize = 32;
const MASK: i32 = 63;

#[derive(Clone)]
pub struct IirFilter {
    pub a: [f64; MAX_IIR_ORDER + 1],
    pub b: [f64; MAX_IIR_ORDER + 1],
    pub order: usize,
    pos: i32,
    input: [f64; 64],
    output: [f64; 64],
}

impl Default for IirFilter {
    fn default() -> Self {
        let mut f = IirFilter { a: [0.0; MAX_IIR_ORDER + 1], b: [0.0; MAX_IIR_ORDER + 1], order: 0, pos: 0, input: [0.0; 64], output: [0.0; 64] };
        f.reset_buffers(0.0);
        f.create_unity();
        f
    }
}

impl IirFilter {
    pub fn reset_buffers(&mut self, initial: f64) {
        self.input = [initial; 64];
        self.output = [initial; 64];
        self.pos = 0;
    }

    pub fn output_sample(&mut self, x: f64) -> f64 {
        let pos = self.pos;
        self.input[(pos & MASK) as usize] = x;
        let mut sum = self.a[0] * x;
        for i in 1..=self.order {
            let k = (pos.wrapping_sub(i as i32) & MASK) as usize;
            sum += self.a[i] * self.input[k];
            sum += self.b[i] * self.output[k];
        }
        self.output[(pos & MASK) as usize] = sum;
        self.pos = pos.wrapping_add(1);
        sum
    }

    fn clear_coefficients(&mut self) {
        self.order = 0;
        self.a = [0.0; MAX_IIR_ORDER + 1];
        self.b = [0.0; MAX_IIR_ORDER + 1];
        self.b[0] = 1.0;
    }

    /// This filter combined with `f`, in cascade or in parallel (combineWithFilter): false, and unchanged, where either's
    /// order is over half the most.
    pub fn combine_with(&mut self, f: &IirFilter, cascade: bool) -> bool {
        if self.order > MAX_IIR_ORDER / 2 || f.order > MAX_IIR_ORDER / 2 {
            return false;
        }
        let mut a2 = [0.0; MAX_IIR_ORDER + 1];
        let mut b2 = [0.0; MAX_IIR_ORDER + 1];
        let mut a3 = [0.0; MAX_IIR_ORDER + 1];
        let mut b3 = [0.0; MAX_IIR_ORDER + 1];
        for i in 0..=MAX_IIR_ORDER {
            a2[i] = f.a[i];
            b2[i] = f.b[i];
            self.b[i] = -self.b[i];
            b2[i] = -b2[i];
        }
        self.b[0] = 1.0;
        b2[0] = 1.0;
        for i in 0..=MAX_IIR_ORDER {
            for j in 0..=MAX_IIR_ORDER / 2 {
                if i >= j && i - j <= MAX_IIR_ORDER / 2 {
                    if cascade {
                        a3[i] += self.a[j] * a2[i - j];
                    } else {
                        a3[i] += self.a[j] * b2[i - j] + a2[j] * self.b[i - j];
                    }
                    b3[i] += self.b[j] * b2[i - j];
                }
            }
        }
        self.a = a3;
        self.b = b3;
        for i in 0..=MAX_IIR_ORDER {
            self.b[i] = -self.b[i];
        }
        self.b[0] = 0.0;
        self.order += f.order;
        true
    }

    pub fn create_unity(&mut self) {
        self.clear_coefficients();
        self.a[0] = 1.0;
        self.b[0] = 1.0;
        self.order = 0;
    }

    pub fn set_coefficients(&mut self, a: &[f64], b: &[f64], order: usize) {
        self.clear_coefficients();
        self.order = order.min(MAX_IIR_ORDER);
        for i in 0..=self.order {
            self.a[i] = a[i];
            self.b[i] = b[i];
        }
    }

    pub fn create_single_pole_lowpass(&mut self, ratio: f64) {
        self.clear_coefficients();
        let x = (-2.0 * PI * ratio).exp();
        self.order = 1;
        self.a[0] = 1.0 - x;
        self.b[1] = x;
    }

    pub fn create_second_order_lowpass(&mut self, ratio: f64, q: f64) {
        self.clear_coefficients();
        self.order = 2;
        let (a0, a1, a2, b1, b2) = second_order_lowpass(ratio, q);
        self.b[0] = 1.0;
        self.b[1] = b1;
        self.b[2] = b2;
        self.a[0] = a0;
        self.a[1] = a1;
        self.a[2] = a2;
    }

    pub fn create_chebyshev(&mut self, ratio: f64, highpass: bool, num_poles: usize) {
        let percent_ripple: f64 = 0.5;
        let mut num_poles = num_poles;
        if num_poles & 1 != 0 {
            num_poles += 1;
        }
        num_poles = num_poles.min(MAX_IIR_ORDER);
        self.order = num_poles;
        self.a = [0.0; MAX_IIR_ORDER + 1];
        self.b = [0.0; MAX_IIR_ORDER + 1];
        self.a[2] = 1.0;
        self.b[2] = 1.0;
        let np = num_poles as f64;
        for pol in 1..=num_poles / 2 {
            let (pol_real, pol_imag) = chebyshev_pole(pol, np, percent_ripple);
            let t = 2.0 * 0.5f64.tan();
            let w = 2.0 * PI * ratio;
            let m = pol_real * pol_real + pol_imag * pol_imag;
            let mut d = 4.0 - 4.0 * pol_real * t + m * t * t;
            let x0 = (t * t) / d;
            let x1 = (2.0 * t * t) / d;
            let x2 = (t * t) / d;
            let y1 = (8.0 - 2.0 * m * t * t) / d;
            let y2 = (-4.0 - 4.0 * pol_real * t - m * t * t) / d;
            let k = if highpass { -(0.5 * w + 0.5).cos() / (0.5 * w - 0.5).cos() } else { (0.5 - 0.5 * w).sin() / (0.5 + 0.5 * w).sin() };
            d = 1.0 + y1 * k - y2 * k * k;
            let a0 = (x0 - x1 * k + x2 * k * k) / d;
            let mut a1 = (-2.0 * x0 * k + x1 + x1 * k * k - 2.0 * x2 * k) / d;
            let a2 = (x0 * k * k - x1 * k + x2) / d;
            let mut b1 = (2.0 * k + y1 + y1 * k * k - 2.0 * y2 * k) / d;
            let b2 = (-(k * k) - y1 * k + y2) / d;
            if highpass {
                a1 = -a1;
                b1 = -b1;
            }
            let (ta, tb) = (self.a, self.b);
            for i in 2..=MAX_IIR_ORDER {
                self.a[i] = a0 * ta[i] + a1 * ta[i - 1] + a2 * ta[i - 2];
                self.b[i] = tb[i] - b1 * tb[i - 1] - b2 * tb[i - 2];
            }
        }
        self.b[2] = 0.0;
        for i in 0..=MAX_IIR_ORDER - 2 {
            self.a[i] = self.a[i + 2];
            self.b[i] = -self.b[i + 2];
        }
        let (mut sum_a, mut sum_b) = (0.0, 0.0);
        for i in 0..=MAX_IIR_ORDER - 2 {
            if !highpass || i & 1 == 0 {
                sum_a += self.a[i];
                sum_b += self.b[i];
            } else {
                sum_a -= self.a[i];
                sum_b -= self.b[i];
            }
        }
        let gain = sum_a / (1.0 - sum_b);
        for i in 0..=MAX_IIR_ORDER - 2 {
            self.a[i] /= gain;
        }
    }
}

/// The Chebyshev recipe's pole pair `pol` of `np` poles on the unit circle's left half, moved for its ripple (each
/// expression in `create_chebyshev`'s order, whose it is).
fn chebyshev_pole(pol: usize, np: f64, percent_ripple: f64) -> (f64, f64) {
    let mut pol_real = -(PI / (2.0 * np) + (PI * (pol - 1) as f64) / np).cos();
    let mut pol_imag = (PI / (2.0 * np) + (PI * (pol - 1) as f64) / np).sin();
    if percent_ripple != 0.0 {
        let temp = 100.0 / (100.0 - percent_ripple);
        let es = (temp * temp - 1.0).sqrt();
        let vx = (1.0 / np) * ((1.0 / es) + ((1.0 / (es * es)) + 1.0).sqrt()).ln();
        let mut kx = (1.0 / np) * ((1.0 / es) + ((1.0 / (es * es)) - 1.0).sqrt()).ln();
        kx = 0.5 * (kx.exp() + (-kx).exp());
        pol_real = pol_real * (0.5 * (vx.exp() - (-vx).exp())) / kx;
        pol_imag = pol_imag * (0.5 * (vx.exp() + (-vx).exp())) / kx;
    }
    (pol_real, pol_imag)
}

/// `create_chebyshev`'s low-pass as its second-order sections, each stepped as a state-variable section: the bilinear
/// transform of its pole pair, 1 / (1 + k x + x^2) with x = j tan(w / 2) / g, its two integrators trapezoidal (Simper's
/// form of it). The same filter -- the recipe's response and the sections' agree to 47 digits of 60 -- in an
/// arithmetic that keeps its digits where the cutoff stands far under the rate. The recipe's one recursion of the
/// whole polynomial does not: at 25 Hz of 240 kHz its coefficients' sum stands 8e-14 from 1, and a change of one part
/// in 1e13 of its input moves its output by 1.6e-4 (8e-7 at 48 kHz); the sections' by 1e-13.
#[derive(Clone, Default)]
pub struct ChebyshevSections {
    /// each section's coefficients (a1, g a1, g^2 a1; a1 = 1 / (1 + g (g + k))) and its two integrators' states
    sections: Vec<([f64; 3], [f64; 2])>,
}

impl ChebyshevSections {
    /// The low-pass of `num_poles` poles (an even number, as the recipe makes it) at `ratio` of the rate, at rest.
    pub fn lowpass(ratio: f64, num_poles: usize) -> ChebyshevSections {
        let percent_ripple: f64 = 0.5;
        let num_poles = (num_poles + (num_poles & 1)).min(MAX_IIR_ORDER);
        let np = num_poles as f64;
        let sections = (1..=num_poles / 2)
            .map(|pol| {
                let (pol_real, pol_imag) = chebyshev_pole(pol, np, percent_ripple);
                // (the pair's own frequency against the cutoff's, and its damping)
                let m = (pol_real * pol_real + pol_imag * pol_imag).sqrt();
                let (g, k) = (m * (PI * ratio).tan(), -2.0 * pol_real / m);
                let a1 = 1.0 / (1.0 + g * (g + k));
                ([a1, g * a1, g * g * a1], [0.0; 2])
            })
            .collect();
        ChebyshevSections { sections }
    }

    pub fn reset(&mut self) {
        for (_, state) in self.sections.iter_mut() {
            *state = [0.0; 2];
        }
    }

    pub fn output_sample(&mut self, x: f64) -> f64 {
        let mut y = x;
        for ([a1, a2, a3], [ic1, ic2]) in self.sections.iter_mut() {
            let v3 = y - *ic2;
            let v1 = *a1 * *ic1 + *a2 * v3;
            let v2 = *ic2 + *a2 * *ic1 + *a3 * v3;
            *ic1 = 2.0 * v1 - *ic1;
            *ic2 = 2.0 * v2 - *ic2;
            y = v2;
        }
        y
    }
}

/// createSecondOrderLowpass's coefficients (a0, a1, a2, b1, b2), without a filter's buffers: the noise sources make one
/// every sample.
#[inline]
pub fn second_order_lowpass(ratio: f64, q: f64) -> (f64, f64, f64, f64, f64) {
    let k = (PI * ratio).tan();
    let q = if q == 0.0 { 0.000001 } else { q };
    let denominator = k * k + k / q + 1.0;
    let b1 = -2.0 * (k * k - 1.0) / denominator;
    let b2 = -(k * k - k / q + 1.0) / denominator;
    let a0 = k * k / denominator;
    (a0, 2.0 * a0, a0, b1, b2)
}

#[cfg(test)]
mod tests {
    use super::*;

    /// A pressure like the pharynx's as the glottis's filter hears it: a ramp to a mean, a 110 Hz wave and partials.
    fn pressure(n: usize, rate: f64, scale: f64) -> Vec<f64> {
        (0..n)
            .map(|i| {
                let t = i as f64 / rate;
                scale * (300.0 * (1.0 - (-t / 0.012).exp()) + 900.0 * (2.0 * PI * 110.0 * t).sin() + 300.0 * (2.0 * PI * 220.0 * t + 1.0).sin() + 100.0 * (2.0 * PI * 990.0 * t).sin())
            })
            .collect()
    }

    /// The sections are the recipe's filter, and keep their digits where its one recursion loses them: at 48 kHz the
    /// two give the same output to the recursion's own rounding; at 240 kHz a change of one part in 1e13 of the input
    /// moves the recursion's output by more than a part in 1e6 and the sections' by less than one in 1e11; and the
    /// sections pass a constant whole and a wave at the cutoff at the recipe's own size there (half its power, over
    /// its ripple's 0.995).
    #[test]
    fn the_sections_are_the_recipes_filter_and_keep_their_digits() {
        let worst = |a: &[f64], b: &[f64]| a.iter().zip(b).fold(0.0f64, |m, (x, y)| m.max((x - y).abs())) / a.iter().fold(0.0f64, |m, x| m.max(x.abs()));
        let run = |rate: f64, scale: f64| -> (Vec<f64>, Vec<f64>) {
            let (mut recursion, mut sections) = (IirFilter::default(), ChebyshevSections::lowpass(25.0 / rate, 4));
            recursion.create_chebyshev(25.0 / rate, false, 4);
            recursion.reset_buffers(0.0);
            let x = pressure((0.4 * rate) as usize, rate, scale);
            (x.iter().map(|&v| recursion.output_sample(v)).collect(), x.iter().map(|&v| sections.output_sample(v)).collect())
        };
        let (recursion, sections) = run(48000.0, 1.0);
        assert!(worst(&sections, &recursion) < 1e-4, "the two forms at 48 kHz: {:.1e}", worst(&sections, &recursion));
        let ((recursion, sections), (recursion_more, sections_more)) = (run(240000.0, 1.0), run(240000.0, 1.0 + 1e-13));
        assert!(worst(&recursion, &recursion_more) > 1e-6, "the recursion at 240 kHz: {:.1e}", worst(&recursion, &recursion_more));
        assert!(worst(&sections, &sections_more) < 1e-11, "the sections at 240 kHz: {:.1e}", worst(&sections, &sections_more));
        let mut held = ChebyshevSections::lowpass(25.0 / 240000.0, 4);
        let settled = (0..240000).map(|_| held.output_sample(700.0)).last().unwrap();
        assert!((settled / 700.0 - 1.0).abs() < 1e-9, "a constant through the sections: {settled}");
        let mut waved = ChebyshevSections::lowpass(25.0 / 240000.0, 4);
        let wave: Vec<f64> = (0..480000).map(|i| waved.output_sample((2.0 * PI * 25.0 * i as f64 / 240000.0).sin())).collect();
        let size = wave[240000..].iter().fold(0.0f64, |m, x| m.max(x.abs()));
        assert!((size - std::f64::consts::FRAC_1_SQRT_2 / 0.995).abs() < 1e-3, "a wave at the cutoff through the sections: {size}");
    }
}
