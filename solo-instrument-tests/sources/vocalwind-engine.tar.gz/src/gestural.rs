// VocalTractLab's gestural score (GesturalScore.cpp; Birkholz 2007, "Control of an articulatory speech synthesizer based
// on dynamic approximation of spatial articulatory targets"): eight tiers of gestures -- vowels, lips, tongue tip, tongue
// body, velum, glottal shape, F0 (in semitones re 1 Hz) and lung pressure -- each a gesture's duration, target, slope
// and time constant. The tract's tiers are cut into slices at every boundary; in each slice the vowel's shape is the
// target, a consonant's shape (made for that vowel by its prototypes in the a-i-u context) taking over where one is
// active, each articulator's time constant scaled by its speed rising or falling; every parameter then approaches its
// targets as a fifth-order critically damped system, solved analytically and sampled at 400 Hz; and those curves read at
// each frame. Each expression in the C++'s order. Its scores read from .ges files; or written by sing.rs and ssml.rs.
use crate::glottis::{FREQUENCY, NUM_CONTROL_PARAMS, PRESSURE};
use crate::tract::*;
use crate::xml;

pub const REFERENCE_FREQUENCY: f64 = 1.0;
pub const DEFAULT_TIME_CONSTANT_S: f64 = 0.012;
pub const TARGET_VELIC_OPENING: f64 = 0.5;
pub const CURVE_SAMPLING_RATE: i32 = 400;
pub const MAX_CURVE_SAMPLES: usize = CURVE_SAMPLING_RATE as usize * 60;
pub const MIN_GESTURE_DURATION_S: f64 = 0.001;
pub const MAX_GESTURE_DURATION_S: f64 = 3600.0;
const MAX_SLICES: usize = 1024;

pub const VOWEL: usize = 0;
pub const LIP: usize = 1;
pub const TONGUE_TIP: usize = 2;
pub const TONGUE_BODY: usize = 3;
pub const VELIC: usize = 4;
pub const GLOTTAL_SHAPE: usize = 5;
pub const F0: usize = 6;
pub const LUNG_PRESSURE: usize = 7;
pub const NUM_GESTURE_TYPES: usize = 8;

#[derive(Clone, Debug, Default, PartialEq)]
pub struct Gesture {
    pub duration_s: f64,
    pub d_val: f64,
    pub slope: f64,
    pub s_val: String,
    pub tau_s: f64,
    pub neutral: bool,
}

#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct Target {
    pub duration: f64,
    pub value: f64,
    pub slope: f64,
    pub tau_s: f64,
}

#[derive(Clone, Debug, Default)]
pub struct GestureSequence {
    pub abbr: &'static str,
    pub unit: &'static str,
    pub min_value: f64,
    pub max_value: f64,
    pub min_slope: f64,
    pub max_slope: f64,
    pub min_tau_s: f64,
    pub max_tau_s: f64,
    pub nominal: bool,
    pub gestures: Vec<Gesture>,
}

impl GestureSequence {
    pub fn duration_s(&self) -> f64 {
        let mut d = 0.0;
        for g in &self.gestures {
            d += g.duration_s;
        }
        d
    }

    /// Puts g at start_s, cutting or dropping what lies under it (GestureSequence::putGesture).
    pub fn put(&mut self, mut g: Gesture, start_s: f64) {
        if g.duration_s < MIN_GESTURE_DURATION_S {
            g.duration_s = MIN_GESTURE_DURATION_S;
        }
        let end_s = start_s + g.duration_s;
        let (mut left, mut right): (i64, i64) = (-1, -1);
        let (mut left_start, mut right_start) = (0.0, 0.0);
        let mut pos = 0.0;
        for (i, x) in self.gestures.iter().enumerate() {
            if start_s >= pos && start_s <= pos + x.duration_s {
                left = i as i64;
                left_start = pos;
            }
            if end_s >= pos && end_s <= pos + x.duration_s {
                right = i as i64;
                right_start = pos;
            }
            pos += x.duration_s;
        }
        let total = pos;
        if left == -1 && right == -1 {
            let empty = start_s - total;
            if empty > MIN_GESTURE_DURATION_S {
                self.gestures.push(Gesture { duration_s: empty, d_val: 0.0, slope: 0.0, s_val: String::new(), neutral: true, tau_s: DEFAULT_TIME_CONSTANT_S });
            }
            self.gestures.push(g);
        } else if left != -1 {
            let (left, right) = (left as usize, right);
            let mut new: Vec<Gesture> = self.gestures[..left].to_vec();
            let mut part = self.gestures[left].clone();
            part.duration_s = start_s - left_start;
            if part.duration_s >= MIN_GESTURE_DURATION_S {
                new.push(part);
            } else {
                g.duration_s += part.duration_s;
            }
            new.push(g);
            if right != -1 {
                let right = right as usize;
                let mut part = self.gestures[right].clone();
                part.duration_s = right_start + self.gestures[right].duration_s - end_s;
                if part.duration_s < MIN_GESTURE_DURATION_S {
                    part.duration_s = MIN_GESTURE_DURATION_S;
                }
                new.push(part);
                new.extend_from_slice(&self.gestures[right + 1..]);
            }
            self.gestures = new;
        }
    }
}

/// The parameter curves at 400 Hz: the tract's 19 and the glottis's 11 (F0 in Hz).
pub struct Curves {
    pub tract: Vec<Vec<f64>>,
    pub glottis: Vec<Vec<f64>>,
}

#[derive(Clone, Debug)]
pub struct GesturalScore {
    pub seq: Vec<GestureSequence>,
}

impl Default for GesturalScore {
    fn default() -> Self {
        GesturalScore::new()
    }
}

fn sequence(abbr: &'static str, unit: &'static str, min: f64, max: f64, min_slope: f64, max_slope: f64, min_tau: f64, max_tau: f64, nominal: bool) -> GestureSequence {
    GestureSequence { abbr, unit, min_value: min, max_value: max, min_slope, max_slope, min_tau_s: min_tau, max_tau_s: max_tau, nominal, gestures: Vec::new() }
}

pub fn f0_st(hz: f64) -> f64 {
    let hz = if hz < 1.0 { 1.0 } else { hz };
    12.0 * (hz / REFERENCE_FREQUENCY).ln() / 2f64.ln()
}

pub fn f0_hz(st: f64) -> f64 {
    REFERENCE_FREQUENCY * 2f64.powf(st / 12.0)
}

impl GesturalScore {
    /// An empty score, its tiers' ranges as VocalTractLab's.
    pub fn new() -> GesturalScore {
        GesturalScore {
            seq: vec![
                sequence("vowel-gestures", "", 0.0, 0.0, 0.0, 0.0, 0.005, 0.04, true),
                sequence("lip-gestures", "", 0.0, 0.0, 0.0, 0.0, 0.005, 0.04, true),
                sequence("tongue-tip-gestures", "", 0.0, 0.0, 0.0, 0.0, 0.005, 0.04, true),
                sequence("tongue-body-gestures", "", 0.0, 0.0, 0.0, 0.0, 0.005, 0.04, true),
                sequence("velic-gestures", "", -0.1, 1.0, 0.0, 0.0, 0.01, 0.04, false),
                sequence("glottal-shape-gestures", "", 0.0, 0.0, 0.0, 0.0, 0.01, 0.04, true),
                sequence("f0-gestures", "st", 48.0, 108.0, -80.0, 80.0, 0.005, 0.04, false),
                sequence("lung-pressure-gestures", "dPa", 0.0, 16000.0, 0.0, 0.0, 0.005, 0.04, false),
            ],
        }
    }

    /// A .ges file's score, and whether every value was in its range (VocalTractLab refuses a score where not).
    pub fn parse(text: &str) -> Result<(GesturalScore, bool), String> {
        let mut score = GesturalScore::new();
        let in_range = parse_tiers(text, &mut score.seq)?;
        Ok((score, in_range))
    }

    /// The score as a .ges file, as VocalTractLab writes one.
    pub fn to_xml(&self) -> String {
        tiers_xml(&self.seq)
    }
}

/// A .ges file's tiers read into `tiers` (their ranges as the score's version has them), each value held to its range;
/// whether every one was in it (GesturalScore::loadGesturesXml, GestureSequence::readFromXml: 2.3's and 2.4's alike).
pub fn parse_tiers(text: &str, tiers: &mut [GestureSequence]) -> Result<bool, String> {
        let root = xml::parse(text)?;
        if root.name != "gestural_score" {
            return Err(format!("<{}>: not a gestural score", root.name));
        }
        let mut in_range = true;
        for node in root.children_named("gesture_sequence") {
            let kind = node.attr("type").unwrap_or("");
            let Some(seq) = tiers.iter_mut().find(|s| s.abbr == kind) else { continue };
            seq.gestures.clear();
            for gn in node.children_named("gesture") {
                let value = gn.attr("value").unwrap_or("");
                let mut g = Gesture::default();
                if seq.nominal {
                    g.s_val = value.to_string();
                } else {
                    g.d_val = value.trim().parse::<f64>().unwrap_or(0.0);
                    if g.d_val < seq.min_value {
                        g.d_val = seq.min_value;
                        in_range = false;
                    }
                    if g.d_val > seq.max_value {
                        g.d_val = seq.max_value;
                        in_range = false;
                    }
                }
                g.slope = gn.num("slope")?;
                g.duration_s = gn.num("duration_s")?;
                g.tau_s = gn.num("time_constant_s")?;
                if g.slope < seq.min_slope {
                    g.slope = seq.min_slope;
                    in_range = false;
                }
                if g.slope > seq.max_slope {
                    g.slope = seq.max_slope;
                    in_range = false;
                }
                if g.duration_s < MIN_GESTURE_DURATION_S {
                    g.duration_s = MIN_GESTURE_DURATION_S;
                    in_range = false;
                }
                if g.duration_s > MAX_GESTURE_DURATION_S {
                    g.duration_s = MAX_GESTURE_DURATION_S;
                    in_range = false;
                }
                if g.tau_s < seq.min_tau_s {
                    g.tau_s = seq.min_tau_s;
                    in_range = false;
                }
                if g.tau_s > seq.max_tau_s {
                    g.tau_s = seq.max_tau_s;
                    in_range = false;
                }
                g.neutral = gn.num("neutral").map(|v| v as i64 > 0).unwrap_or(false);
                seq.gestures.push(g);
            }
        }
        Ok(in_range)
}

/// Tiers as a .ges file, as VocalTractLab writes one.
pub fn tiers_xml(tiers: &[GestureSequence]) -> String {
        let mut s = String::from("<gestural_score>\n");
        for seq in tiers {
            s += &format!("  <gesture_sequence type=\"{}\" unit=\"{}\">\n", seq.abbr, seq.unit);
            for g in &seq.gestures {
                let value = if seq.nominal { g.s_val.clone() } else { format!("{:.6}", g.d_val) };
                s += &format!(
                    "    <gesture value=\"{value}\" slope=\"{:.6}\" duration_s=\"{:.6}\" time_constant_s=\"{:.6}\" neutral=\"{}\" />\n",
                    g.slope, g.duration_s, g.tau_s, g.neutral as i32
                );
            }
            s += "  </gesture_sequence>\n";
        }
        s + "</gestural_score>\n"
}

impl GesturalScore {
    pub fn duration_s(&self) -> f64 {
        let mut d = 0.0;
        for s in &self.seq {
            let x = s.duration_s();
            if x > d {
                d = x;
            }
        }
        d
    }

    fn tract_targets(&self, vt: &VocalTract) -> Vec<Vec<Target>> {
        const N: usize = 5;
        let mut slices: Vec<[Gesture; N]> = Vec::new();
        let mut index = [0usize; N];
        let mut gesture_pos = [0.0; N];
        let mut pos = 0.0;
        // (The C++ reuses one gesture for a tier that has run out: its slope stays from the last one copied.)
        let mut g = Gesture::default();
        while (0..N).any(|i| index[i] < self.seq[i].gestures.len()) {
            let mut k: i64 = -1;
            let mut nearest = 1000000.0;
            for i in 0..N {
                if index[i] < self.seq[i].gestures.len() && gesture_pos[i] + self.seq[i].gestures[index[i]].duration_s < nearest {
                    nearest = gesture_pos[i] + self.seq[i].gestures[index[i]].duration_s;
                    k = i as i64;
                }
            }
            if k != -1 {
                let k = k as usize;
                if nearest > pos {
                    let slice_duration = nearest - pos;
                    let mut slice: [Gesture; N] = Default::default();
                    for i in 0..N {
                        if index[i] < self.seq[i].gestures.len() {
                            g = self.seq[i].gestures[index[i]].clone();
                        } else {
                            g.d_val = self.seq[i].min_value;
                            g.tau_s = self.seq[i].min_tau_s;
                            g.neutral = true;
                            g.s_val = String::new();
                        }
                        g.duration_s = slice_duration;
                        slice[i] = g.clone();
                    }
                    // (No more than 1023 slices: past them the last is written over, as the C++ does.)
                    if slices.len() < MAX_SLICES - 1 {
                        slices.push(slice);
                    } else {
                        *slices.last_mut().unwrap() = slice;
                    }
                }
                pos = nearest;
                gesture_pos[k] = nearest;
                index[k] += 1;
            }
        }
        // A neutral consonantal gesture takes the name of the last one before it, and stays neutral.
        for i in 1..=3 {
            for k in 1..slices.len() {
                if slices[k][i].s_val.is_empty() || slices[k][i].neutral {
                    slices[k][i].s_val = slices[k - 1][i].s_val.clone();
                    slices[k][i].neutral = true;
                }
            }
        }
        let mut targets: Vec<Vec<Target>> = vec![Vec::new(); NUM_PARAMS];
        let schwa = vt.shape("@");
        for sl in &slices {
            let vowel_tau = sl[VOWEL].tau_s;
            let base = vt.shape(&sl[VOWEL].s_val).or(schwa);
            let mut value = [0.0; NUM_PARAMS];
            let mut tau = [vowel_tau; NUM_PARAMS];
            for k in 0..NUM_PARAMS {
                value[k] = match base {
                    Some(b) => b[k],
                    None => vt.param[k].neutral,
                };
            }
            let (mut at, mut bt, mut al, mut bl) = map_to_vowel_subspace(vt, &value);
            limit_vowel_subspace_coord(&mut at, &mut bt, &mut al, &mut bl);
            let mut active = 0;
            let mut tau_sum = 0.0;
            let mut param_sum = [0.0; NUM_PARAMS];
            let mut exists = [false; 3];
            let mut cp = [[0.0; NUM_PARAMS]; 3];
            for k in 0..3 {
                let c = &sl[LIP + k];
                if !c.neutral {
                    exists[k] = context_dependent_consonant(vt, &c.s_val, at, bt, al, bl, &mut cp[k]);
                    if exists[k] {
                        active += 1;
                        tau_sum += c.tau_s;
                        for m in 0..NUM_PARAMS {
                            param_sum[m] += cp[k][m];
                        }
                    }
                }
            }
            if active > 0 {
                for m in 0..NUM_PARAMS {
                    value[m] = param_sum[m] / active as f64;
                    tau[m] = tau_sum / active as f64;
                }
                // (Each consonant has its primary articulator wholly.)
                if exists[0] {
                    value[LP] = cp[0][LP];
                    value[LD] = cp[0][LD];
                }
                if exists[1] {
                    value[TTX] = cp[1][TTX];
                    value[TTY] = cp[1][TTY];
                    value[TS3] = cp[1][TS3];
                }
                if exists[2] {
                    value[TCX] = cp[2][TCX];
                    value[TCY] = cp[2][TCY];
                    value[TS2] = cp[2][TS2];
                }
            }
            if !sl[VELIC].neutral {
                value[VO] = sl[VELIC].d_val;
                tau[VO] = sl[VELIC].tau_s;
            }
            for k in 0..NUM_PARAMS {
                targets[k].push(Target { duration: sl[VOWEL].duration_s, value: value[k], tau_s: tau[k], slope: 0.0 });
            }
        }
        // Each articulator's own speed rising and falling.
        const EPSILON: f64 = 0.001;
        for (k, t) in targets.iter_mut().enumerate() {
            for i in 1..t.len() {
                let mut f = if t[i].value > t[i - 1].value { vt.anatomy.positive_velocity_factor[k] } else { vt.anatomy.negative_velocity_factor[k] };
                if f.abs() < EPSILON {
                    f = EPSILON;
                }
                t[i].tau_s /= f;
            }
        }
        targets
    }

    fn glottis_targets(&self, glottis_shapes: &[(String, Vec<f64>)], neutral: &[f64]) -> Vec<Vec<Target>> {
        const FIRST_SHAPE_PARAM: usize = 2;
        let mut targets: Vec<Vec<Target>> = vec![Vec::new(); NUM_CONTROL_PARAMS];
        for g in &self.seq[GLOTTAL_SHAPE].gestures {
            let shape = glottis_shapes.iter().find(|(n, _)| *n == g.s_val).map(|(_, v)| v.as_slice());
            for k in FIRST_SHAPE_PARAM..NUM_CONTROL_PARAMS {
                targets[k].push(Target { duration: g.duration_s, tau_s: g.tau_s, value: shape.map(|v| v[k]).unwrap_or(neutral[k]), slope: 0.0 });
            }
        }
        for g in &self.seq[F0].gestures {
            targets[FREQUENCY].push(Target { duration: g.duration_s, tau_s: g.tau_s, value: g.d_val, slope: g.slope });
        }
        for g in &self.seq[LUNG_PRESSURE].gestures {
            targets[PRESSURE].push(Target { duration: g.duration_s, tau_s: g.tau_s, value: g.d_val, slope: g.slope });
        }
        targets
    }

    /// The parameter curves at 400 Hz (GesturalScore::calcCurves). Their length VocalTractLab's 60 s, or the score's
    /// own where longer.
    pub fn curves(&self, vt: &VocalTract, glottis_shapes: &[(String, Vec<f64>)], glottis_neutral: &[f64]) -> Curves {
        let duration = self.duration_s();
        let final_index = ((duration + 0.010) * CURVE_SAMPLING_RATE as f64) as usize;
        let len = MAX_CURVE_SAMPLES.max(final_index + 2);
        let mut tract: Vec<Vec<f64>> = (0..NUM_PARAMS).map(|i| vec![vt.param[i].neutral; len]).collect();
        let mut glottis: Vec<Vec<f64>> = (0..NUM_CONTROL_PARAMS).map(|i| vec![if i == FREQUENCY { f0_st(glottis_neutral[i]) } else { glottis_neutral[i] }; len]).collect();
        let mut tt = self.tract_targets(vt);
        let mut gt = self.glottis_targets(glottis_shapes, glottis_neutral);
        for (t, c) in tt.iter_mut().zip(tract.iter_mut()) {
            param_curve(t, c, final_index);
        }
        for (t, c) in gt.iter_mut().zip(glottis.iter_mut()) {
            param_curve(t, c, final_index);
        }
        for x in glottis[FREQUENCY].iter_mut() {
            *x = f0_hz(*x);
        }
        Curves { tract, glottis }
    }

    /// The tract's parameters at t as the curves give them (calcCurves then getParams), only the two samples about t
    /// computed: the same numbers. For the searches that place closing and velic gestures (segments.rs).
    pub fn tract_params_at(&self, vt: &VocalTract, t: f64) -> [f64; NUM_PARAMS] {
        let final_index = ((self.duration_s() + 0.010) * CURVE_SAMPLING_RATE as f64) as usize;
        let len = MAX_CURVE_SAMPLES.max(final_index + 2);
        let period = 1.0 / CURVE_SAMPLING_RATE as f64;
        let mut index = (t * CURVE_SAMPLING_RATE as f64) as i64;
        let mut s = (t - index as f64 * period) / period;
        let mut s1 = 1.0 - s;
        if index < 0 {
            index = 0;
        }
        if index > MAX_CURVE_SAMPLES as i64 - 2 && len == MAX_CURVE_SAMPLES {
            index = MAX_CURVE_SAMPLES as i64 - 2;
            s = 0.0;
            s1 = 1.0;
        }
        if index >= len as i64 - 1 {
            index = len as i64 - 2;
            s = 1.0;
            s1 = 0.0;
        }
        let i = index as usize;
        let mut targets = self.tract_targets(vt);
        let mut out = [0.0; NUM_PARAMS];
        for (k, t) in targets.iter_mut().enumerate() {
            let neutral = vt.param[k].neutral;
            let (y0, y1) = if t.is_empty() {
                (neutral, neutral)
            } else {
                let mut w = Walker::new(t);
                let y0 = if i <= final_index { w.sample(t, i) } else { neutral };
                let y1 = if i + 1 <= final_index { w.sample(t, i + 1) } else { neutral };
                (y0, y1)
            };
            out[k] = s1 * y0 + s * y1;
        }
        out
    }

    /// The frames VocalTractLab synthesizes the score from (Synthesizer::synthesizeGesturalScore): the curves read at
    /// 0 and then every 110 samples, one more chunk than the score's whole length holds.
    pub fn frames(&self, vt: &VocalTract, glottis_shapes: &[(String, Vec<f64>)], glottis_neutral: &[f64]) -> Vec<(Vec<f64>, Vec<f64>)> {
        let curves = self.curves(vt, glottis_shapes, glottis_neutral);
        let length_pt = (self.duration_s() * crate::constants::SAMPLING_RATE as f64) as i64;
        let chunks = (length_pt / 110) as usize + 1;
        (0..=chunks).map(|i| params_at(&curves, i as f64 * 110.0 / crate::constants::SAMPLING_RATE as f64)).collect()
    }

    /// The tract's half of `frames`, every `every`th frame: the same numbers, its curves computed only as far as the
    /// frames read them (for the fits that make a score's frames many times: speaker_fit.rs).
    pub fn tract_frames(&self, vt: &VocalTract, every: usize) -> Vec<[f64; NUM_PARAMS]> {
        let reads = self.reads(every);
        let mut out = vec![[0.0; NUM_PARAMS]; reads.at.len()];
        let mut column = vec![0.0; reads.at.len()];
        for (k, mut t) in self.tract_targets(vt).into_iter().enumerate() {
            param_frames(&mut t, vt.param[k].neutral, &reads, &mut column);
            for (o, c) in out.iter_mut().zip(&column) {
                o[k] = *c;
            }
        }
        out
    }

    /// The tract's targets, a list for each parameter, as the curves are made from them.
    pub fn targets(&self, vt: &VocalTract) -> Vec<Vec<Target>> {
        self.tract_targets(vt)
    }

    /// Where every `every`th of `frames` reads the curves, as params_at finds it.
    pub fn reads(&self, every: usize) -> Reads {
        let duration = self.duration_s();
        let final_index = ((duration + 0.010) * CURVE_SAMPLING_RATE as f64) as usize;
        let len = MAX_CURVE_SAMPLES.max(final_index + 2);
        let length_pt = (duration * crate::constants::SAMPLING_RATE as f64) as i64;
        let chunks = (length_pt / 110) as usize + 1;
        let period = 1.0 / CURVE_SAMPLING_RATE as f64;
        let at = (0..=chunks)
            .step_by(every.max(1))
            .map(|f| {
                let pos_s = f as f64 * 110.0 / crate::constants::SAMPLING_RATE as f64;
                let mut index = (pos_s * CURVE_SAMPLING_RATE as f64) as i64;
                let n = len as i64;
                let mut s = (pos_s - index as f64 * period) / period;
                let mut s1 = 1.0 - s;
                if index < 0 {
                    index = 0;
                }
                if index > MAX_CURVE_SAMPLES as i64 - 2 && n == MAX_CURVE_SAMPLES as i64 {
                    index = MAX_CURVE_SAMPLES as i64 - 2;
                    s = 0.0;
                    s1 = 1.0;
                }
                if index >= n - 1 {
                    index = n - 2;
                    s = 1.0;
                    s1 = 0.0;
                }
                (index as usize, s1, s)
            })
            .collect();
        Reads { at, final_index }
    }
}

/// Where a score's frames read its curves: for each frame the sample before it and the weights of that one and the next.
#[derive(Clone, Debug)]
pub struct Reads {
    pub at: Vec<(usize, f64, f64)>,
    pub final_index: usize,
}

/// One parameter's frames from its targets, its curve made (calcParamCurve) only as far as the frames read it and its
/// neutral value past the score's end, as `curves` leaves it.
pub fn param_frames(targets: &mut [Target], neutral: f64, reads: &Reads, out: &mut [f64]) {
    let last = reads.at.iter().map(|r| r.0 + 1).max().unwrap_or(0);
    let mut curve = vec![neutral; last + 1];
    if !targets.is_empty() {
        let mut w = Walker::new(targets);
        for (i, c) in curve.iter_mut().enumerate().take(last.min(reads.final_index) + 1) {
            *c = w.sample(targets, i);
        }
    }
    for (o, &(i, s1, s)) in out.iter_mut().zip(&reads.at) {
        *o = s1 * curve[i] + s * curve[i + 1];
    }
}

/// The curves read at pos_s, between their samples (GesturalScore::getParams).
pub fn params_at(c: &Curves, pos_s: f64) -> (Vec<f64>, Vec<f64>) {
    let period = 1.0 / CURVE_SAMPLING_RATE as f64;
    let mut index = (pos_s * CURVE_SAMPLING_RATE as f64) as i64;
    let n = c.tract[0].len() as i64;
    let mut s = (pos_s - index as f64 * period) / period;
    let mut s1 = 1.0 - s;
    if index < 0 {
        index = 0;
    }
    if index > MAX_CURVE_SAMPLES as i64 - 2 && n == MAX_CURVE_SAMPLES as i64 {
        index = MAX_CURVE_SAMPLES as i64 - 2;
        s = 0.0;
        s1 = 1.0;
    }
    if index >= n - 1 {
        index = n - 2;
        s = 1.0;
        s1 = 0.0;
    }
    let i = index as usize;
    (c.tract.iter().map(|v| s1 * v[i] + s * v[i + 1]).collect(), c.glottis.iter().map(|v| s1 * v[i] + s * v[i + 1]).collect())
}

/// The targets approached by a fifth-order critically damped system, solved analytically target by target (each its
/// start continuous in value and four derivatives with the last's end) and sampled at 400 Hz (calcParamCurve).
fn param_curve(targets: &mut [Target], curve: &mut [f64], final_index: usize) {
    if targets.is_empty() {
        return;
    }
    let mut w = Walker::new(targets);
    for i in 0..=final_index {
        curve[i] = w.sample(targets, i);
    }
}

/// calcParamCurve's walk through the targets: its coefficients carried from target to target as the samples pass them.
struct Walker {
    ti: usize,
    target_pos: f64,
    a: f64,
    a2: f64,
    a3: f64,
    a4: f64,
    c: [f64; 5],
}

const CURVE_EPSILON: f64 = 0.000000001;

impl Walker {
    fn new(targets: &mut [Target]) -> Walker {
        if targets[0].tau_s.abs() < CURVE_EPSILON {
            targets[0].tau_s = CURVE_EPSILON;
        }
        let a = -1.0 / targets[0].tau_s;
        let a2 = a * a;
        let a3 = a2 * a;
        let a4 = a3 * a;
        // (The first target's coefficients all zero: it is followed exactly.)
        Walker { ti: 0, target_pos: 0.0, a, a2, a3, a4, c: [0.0; 5] }
    }

    /// Sample i (i/400 s), the targets it has passed taken first; samples are asked for in order.
    fn sample(&mut self, targets: &mut [Target], i: usize) -> f64 {
        let n = targets.len();
        let t_s = i as f64 / CURVE_SAMPLING_RATE as f64;
        while t_s > self.target_pos + targets[self.ti].duration && self.ti < n - 1 {
            let tg = targets[self.ti];
            let (a, a2, a3, a4) = (self.a, self.a2, self.a3, self.a4);
            let [c0, c1, c2, c3, c4] = self.c;
            let t = tg.duration;
            let t2 = t * t;
            let t3 = t2 * t;
            let t4 = t3 * t;
            let e = (a * t).exp();
            let f0 = e * ((c0) + (c1) * t + (c2) * t2 + (c3) * t3 + (c4) * t4) + (tg.value + tg.duration * tg.slope);
            let f1 = e * ((c0 * a + c1) + (c1 * a + 2.0 * c2) * t + (c2 * a + 3.0 * c3) * t2 + (c3 * a + 4.0 * c4) * t3 + (c4 * a) * t4) + tg.slope;
            let f2 = e * ((c0 * a2 + 2.0 * c1 * a + 2.0 * c2) + (c1 * a2 + 4.0 * c2 * a + 6.0 * c3) * t + (c2 * a2 + 6.0 * c3 * a + 12.0 * c4) * t2 + (c3 * a2 + 8.0 * c4 * a) * t3 + (c4 * a2) * t4);
            let f3 = e * ((c0 * a3 + 3.0 * c1 * a2 + 6.0 * c2 * a + 6.0 * c3) + (c1 * a3 + 6.0 * c2 * a2 + 18.0 * c3 * a + 24.0 * c4) * t + (c2 * a3 + 9.0 * c3 * a2 + 36.0 * c4 * a) * t2 + (c3 * a3 + 12.0 * c4 * a2) * t3 + (c4 * a3) * t4);
            let f4 = e * ((c0 * a4 + 4.0 * c1 * a3 + 12.0 * c2 * a2 + 24.0 * c3 * a + 24.0 * c4) + (c1 * a4 + 8.0 * c2 * a3 + 36.0 * c3 * a2 + 96.0 * c4 * a) * t + (c2 * a4 + 12.0 * c3 * a3 + 72.0 * c4 * a2) * t2 + (c3 * a4 + 16.0 * c4 * a3) * t3 + (c4 * a4) * t4);
            self.target_pos += tg.duration;
            self.ti += 1;
            if targets[self.ti].tau_s.abs() < CURVE_EPSILON {
                targets[self.ti].tau_s = CURVE_EPSILON;
            }
            let tg = targets[self.ti];
            let a = -1.0 / tg.tau_s;
            let a2 = a * a;
            let a3 = a2 * a;
            let a4 = a3 * a;
            let c0 = f0 - tg.value;
            let c1 = f1 - c0 * a - tg.slope;
            let c2 = (f2 - c0 * a2 - c1 * a * 2.0) / 2.0;
            let c3 = (f3 - c0 * a3 - c1 * a2 * 3.0 - c2 * a * 6.0) / 6.0;
            let c4 = (f4 - c0 * a4 - c1 * a3 * 4.0 - c2 * a2 * 12.0 - c3 * a * 24.0) / 24.0;
            (self.a, self.a2, self.a3, self.a4, self.c) = (a, a2, a3, a4, [c0, c1, c2, c3, c4]);
        }
        let tg = targets[self.ti];
        let [c0, c1, c2, c3, c4] = self.c;
        let t = t_s - self.target_pos;
        let t2 = t * t;
        let t3 = t2 * t;
        let t4 = t3 * t;
        (self.a * t).exp() * ((c0) + (c1) * t + (c2) * t2 + (c3) * t3 + (c4) * t4) + (tg.value + t * tg.slope)
    }
}

/// What the rules ask of a tract: its shapes by name, and its parameters' neutral values (2.3's tract and 2.4's alike,
/// their parameters in the same order).
pub trait Shapes {
    fn shape_named(&self, name: &str) -> Option<[f64; NUM_PARAMS]>;
    fn neutral(&self, k: usize) -> f64;
}

impl Shapes for VocalTract {
    fn shape_named(&self, name: &str) -> Option<[f64; NUM_PARAMS]> {
        self.shape(name)
    }
    fn neutral(&self, k: usize) -> f64 {
        self.param[k].neutral
    }
}

impl Shapes for crate::v24::tract::VocalTract {
    fn shape_named(&self, name: &str) -> Option<[f64; NUM_PARAMS]> {
        self.shape(name)
    }
    fn neutral(&self, k: usize) -> f64 {
        self.param[k].neutral
    }
}

/// A shape's place in the vowel subspace spanned by /a/, /i/ and /u/: the tongue's (alpha, beta) by least squares over
/// its 17 parameters, the lips' from LP and LD (mapToVowelSubspace).
pub fn map_to_vowel_subspace<T: Shapes>(vt: &T, p: &[f64; NUM_PARAMS]) -> (f64, f64, f64, f64) {
    let (Some(sa), Some(si), Some(su)) = (vt.shape_named("a"), vt.shape_named("i"), vt.shape_named("u")) else { return (0.0, 0.0, 0.0, 0.0) };
    const TONGUE: [usize; 17] = [HX, HY, JX, JA, VS, VO, TCX, TCY, TTX, TTY, TBX, TBY, TRX, TRY, TS1, TS2, TS3];
    let mut m = [[0.0; 2]; 17];
    let mut v = [0.0; 17];
    for (i, &k) in TONGUE.iter().enumerate() {
        m[i][0] = si[k] - sa[k];
        m[i][1] = su[k] - sa[k];
        v[i] = p[k] - sa[k];
    }
    let inv = pseudo_inverse_nx2(&m);
    let (mut at, mut bt) = (0.0, 0.0);
    for i in 0..17 {
        at += inv[0][i] * v[i];
        bt += inv[1][i] * v[i];
    }
    let a = si[LP] - sa[LP];
    let b = su[LP] - sa[LP];
    let c = si[LD] - sa[LD];
    let d = su[LD] - sa[LD];
    let x = p[LP] - sa[LP];
    let y = p[LD] - sa[LD];
    const EPSILON: f64 = 0.000000001;
    let mut det = a * d - b * c;
    if det.abs() < EPSILON {
        det = EPSILON;
    }
    (at, bt, (x * d - b * y) / det, (a * y - x * c) / det)
}

fn pseudo_inverse_nx2(m: &[[f64; 2]; 17]) -> [[f64; 17]; 2] {
    let mut a = [[0.0; 2]; 2];
    for x in 0..2 {
        for y in 0..2 {
            let mut sum = 0.0;
            for row in m.iter() {
                sum += row[y] * row[x];
            }
            a[x][y] = sum;
        }
    }
    const EPSILON: f64 = 0.000000001;
    let mut det = a[0][0] * a[1][1] - a[0][1] * a[1][0];
    if det.abs() < EPSILON {
        det = EPSILON;
    }
    let b = [[a[1][1] / det, -a[0][1] / det], [-a[1][0] / det, a[0][0] / det]];
    let mut inv = [[0.0; 17]; 2];
    for x in 0..17 {
        for y in 0..2 {
            inv[y][x] = b[y][0] * m[x][0] + b[y][1] * m[x][1];
        }
    }
    inv
}

/// (alpha, beta) held inside the a-i-u triangle.
pub fn limit_vowel_subspace_coord(at: &mut f64, bt: &mut f64, al: &mut f64, bl: &mut f64) {
    for (alpha, beta) in [(at, bt), (al, bl)] {
        if *alpha < 0.0 {
            *alpha = 0.0;
        }
        if *alpha > 1.0 {
            *alpha = 1.0;
        }
        if *beta < 0.0 {
            *beta = 0.0;
        }
        if *beta > 1.0 {
            *beta = 1.0;
        }
        if *alpha + *beta > 1.0 {
            let d = *alpha + *beta - 1.0;
            *alpha -= 0.5 * d;
            *beta -= 0.5 * d;
        }
    }
}

/// A consonant (e.g. "tt-alveolar-closure") made for a vowel's place in the subspace from its (a), (i) and (u)
/// prototypes, the tongue and the lips each by their own coordinates; false (and the neutral tract) where it has none.
pub fn context_dependent_consonant<T: Shapes>(vt: &T, name: &str, at: f64, bt: f64, al: f64, bl: f64, out: &mut [f64; NUM_PARAMS]) -> bool {
    let (Some(ca), Some(ci), Some(cu)) = (vt.shape_named(&format!("{name}(a)")), vt.shape_named(&format!("{name}(i)")), vt.shape_named(&format!("{name}(u)"))) else {
        for (k, o) in out.iter_mut().enumerate() {
            *o = vt.neutral(k);
        }
        return false;
    };
    for i in 0..NUM_PARAMS {
        out[i] = ca[i] + at * (ci[i] - ca[i]) + bt * (cu[i] - ca[i]);
    }
    for i in [LP, LD] {
        out[i] = ca[i] + al * (ci[i] - ca[i]) + bl * (cu[i] - ca[i]);
    }
    true
}

/// The same for a named context vowel (schwa where it has none).
pub fn consonant_in_context<T: Shapes>(vt: &T, consonant: &str, vowel: &str, out: &mut [f64; NUM_PARAMS]) -> bool {
    let v = vt.shape_named(vowel).or(vt.shape_named("@")).unwrap_or_else(|| {
        let mut n = [0.0; NUM_PARAMS];
        for (k, x) in n.iter_mut().enumerate() {
            *x = vt.neutral(k);
        }
        n
    });
    let (mut at, mut bt, mut al, mut bl) = map_to_vowel_subspace(vt, &v);
    limit_vowel_subspace_coord(&mut at, &mut bt, &mut al, &mut bl);
    context_dependent_consonant(vt, consonant, at, bt, al, bl, out)
}
