// VocalTractLab run live: its geometry, the costly part (each frame's cuts through the tract's meshes), made ahead on
// other cores while one thread steps the tube (the owner, 11 November 2026: "making optimizations as necessary for
// realtime operation (multiplexing is likely required), but without sacrificing modeling accuracy"), for 2.3 and 2.4
// alike. A frame's tube is a function of its parameters alone -- but where it finds no incisors along its center line:
// there VocalTractLab keeps the last frame's position and, within the frame, holds the areas around it open. A worker
// that makes such a frame assumes what its own tract last held; the frames are taken back in their order, and one made
// on another position than the last frame's is made again on it, so the sound is the sequential synthesis's to the bit
// (examples/live_bench.rs and v24_bench.rs check it). (2.3's pool carried the position into the tube's record alone,
// not into the areas the assumed one had shaped.) Each worker holds its own copy of the vocal tract. A frame whose
// parameters are the last frame's, to the bit, is the last frame's tube again -- its incisors found where they were,
// or the position that frame left kept -- and is not made again: a held shape's articulators settle to fixed values
// within a second, and its geometry, which cost two threads some 0.3 of a core each, then costs nothing.
use std::collections::{BTreeMap, BTreeSet};
use std::sync::mpsc::{channel, Receiver, Sender};
use std::thread::JoinHandle;

/// What the pool asks of a version's vocal tract.
pub trait Geometry: Clone + Send + 'static {
    type Tube: Clone + Send + 'static;
    /// This frame's geometry from its parameters.
    fn calculate(&mut self, params: &[f64]);
    fn tube(&self) -> Self::Tube;
    /// Where the incisors are taken to be: found this frame, or kept from the last.
    fn incisor_pos_cm(&self) -> f64;
    fn set_incisor_pos_cm(&mut self, pos_cm: f64);
    fn incisors_found(tube: &Self::Tube) -> bool;
    fn tube_incisor_pos_cm(tube: &Self::Tube) -> f64;
}

impl Geometry for crate::tract::VocalTract {
    type Tube = crate::tract::TractTube;
    fn calculate(&mut self, params: &[f64]) {
        crate::tract::VocalTract::calculate(self, params)
    }
    fn tube(&self) -> Self::Tube {
        crate::tract::VocalTract::tube(self)
    }
    fn incisor_pos_cm(&self) -> f64 {
        self.incisor_pos_cm
    }
    fn set_incisor_pos_cm(&mut self, pos_cm: f64) {
        self.incisor_pos_cm = pos_cm;
    }
    fn incisors_found(tube: &Self::Tube) -> bool {
        tube.incisor_found
    }
    fn tube_incisor_pos_cm(tube: &Self::Tube) -> f64 {
        tube.incisor_pos_cm
    }
}

impl Geometry for crate::v24::tract::VocalTract {
    type Tube = crate::v24::tract::TractTube;
    fn calculate(&mut self, params: &[f64]) {
        crate::v24::tract::VocalTract::calculate(self, params)
    }
    fn tube(&self) -> Self::Tube {
        crate::v24::tract::VocalTract::tube(self)
    }
    fn incisor_pos_cm(&self) -> f64 {
        self.incisor_pos_cm
    }
    fn set_incisor_pos_cm(&mut self, pos_cm: f64) {
        self.incisor_pos_cm = pos_cm;
    }
    fn incisors_found(tube: &Self::Tube) -> bool {
        tube.incisor_found
    }
    fn tube_incisor_pos_cm(tube: &Self::Tube) -> f64 {
        tube.incisor_pos_cm
    }
}

/// A frame made: its ticket, its tube, the incisor position its worker's tract held before it, its parameters.
type Made<T> = (u64, T, f64, Vec<f64>);

/// Geometry made ahead on `workers` threads, handed back in the order asked.
pub struct GeometryPool<G: Geometry> {
    senders: Vec<Sender<(u64, Vec<f64>)>>,
    results: Receiver<Made<G::Tube>>,
    handles: Vec<JoinHandle<()>>,
    next_seq: u64,
    next_out: u64,
    ready: BTreeMap<u64, (G::Tube, f64, Vec<f64>)>,
    /// The last frame's incisor position, as the sequential synthesis's tract would hold it, and a tract of its own to
    /// make again a frame made on another.
    last_incisor_pos_cm: f64,
    own: G,
    /// Frames made again (each on the thread that takes them).
    pub remade: u64,
    /// The last frame asked for's parameters; the frames asked for that repeat the frame before (not sent), and the
    /// last tube given, which they are given again; how many so given, and the frames sent to the workers.
    last_asked: Option<Vec<f64>>,
    repeats: BTreeSet<u64>,
    last_given: Option<G::Tube>,
    pub repeated: u64,
    sent: u64,
}

impl<G: Geometry> GeometryPool<G> {
    pub fn new(tract: &G, workers: usize) -> GeometryPool<G> {
        let (result_tx, results) = channel();
        let mut senders = Vec::new();
        let mut handles = Vec::new();
        for w in 0..workers.max(1) {
            let (tx, rx) = channel::<(u64, Vec<f64>)>();
            let out = result_tx.clone();
            let mut vt = tract.clone();
            handles.push(
                std::thread::Builder::new()
                    .name(format!("vocal-tract-geometry-{w}"))
                    .spawn(move || {
                        while let Ok((seq, params)) = rx.recv() {
                            let assumed = vt.incisor_pos_cm();
                            vt.calculate(&params);
                            if out.send((seq, vt.tube(), assumed, params)).is_err() {
                                break;
                            }
                        }
                    })
                    .expect("a geometry thread"),
            );
            senders.push(tx);
        }
        GeometryPool {
            senders,
            results,
            handles,
            next_seq: 0,
            next_out: 0,
            ready: BTreeMap::new(),
            last_incisor_pos_cm: tract.incisor_pos_cm(),
            own: tract.clone(),
            remade: 0,
            last_asked: None,
            repeats: BTreeSet::new(),
            last_given: None,
            repeated: 0,
            sent: 0,
        }
    }

    /// Asks for a frame's geometry; returns its ticket.
    pub fn submit(&mut self, params: &[f64]) -> u64 {
        let seq = self.next_seq;
        self.next_seq += 1;
        // (The last frame's parameters again, to the bit: its tube again, given as it is taken.)
        let same = |last: &Vec<f64>| last.len() == params.len() && last.iter().zip(params).all(|(a, b)| a.to_bits() == b.to_bits());
        if self.last_asked.as_ref().map_or(false, same) {
            self.repeats.insert(seq);
            return seq;
        }
        self.last_asked = Some(params.to_vec());
        let w = (self.sent % self.senders.len() as u64) as usize;
        self.sent += 1;
        self.senders[w].send((seq, params.to_vec())).expect("a geometry thread");
        seq
    }

    /// Frames asked for and not yet taken.
    pub fn pending(&self) -> u64 {
        self.next_seq - self.next_out
    }

    /// The next frame's geometry in order: waiting for it if `wait`, else None until it is made.
    pub fn next(&mut self, wait: bool) -> Option<G::Tube> {
        if self.next_out == self.next_seq {
            return None;
        }
        if self.repeats.remove(&self.next_out) {
            self.next_out += 1;
            self.repeated += 1;
            return self.last_given.clone();
        }
        loop {
            if let Some((mut t, assumed, params)) = self.ready.remove(&self.next_out) {
                self.next_out += 1;
                // (No incisors found, and its worker's tract held another position than the last frame's: made again on
                // that one, as the sequential synthesis makes it.)
                if !G::incisors_found(&t) && assumed.to_bits() != self.last_incisor_pos_cm.to_bits() {
                    self.own.set_incisor_pos_cm(self.last_incisor_pos_cm);
                    self.own.calculate(&params);
                    t = self.own.tube();
                    self.remade += 1;
                }
                self.last_incisor_pos_cm = G::tube_incisor_pos_cm(&t);
                self.last_given = Some(t.clone());
                return Some(t);
            }
            let got = if wait { self.results.recv().ok() } else { self.results.try_recv().ok() };
            match got {
                Some((seq, t, assumed, params)) => {
                    self.ready.insert(seq, (t, assumed, params));
                }
                None => return None,
            }
        }
    }
}

impl<G: Geometry> Drop for GeometryPool<G> {
    fn drop(&mut self) {
        self.senders.clear();
        for h in self.handles.drain(..) {
            let _ = h.join();
        }
    }
}

/// A whole passage (each frame its tract's and glottis's parameters, `frame` samples apart) synthesized with its
/// geometry made on `workers` other threads, up to `lookahead` frames ahead, each frame's tube and glottis handed to
/// `add` with the samples it fills (none for the first, which only sets where the synthesis starts).
pub fn render_with<G: Geometry>(tract: &G, frames: &[(Vec<f64>, Vec<f64>)], frame: usize, workers: usize, lookahead: usize, mut add: impl FnMut(&G::Tube, &[f64], &mut [f64])) -> Vec<f64> {
    let mut pool = GeometryPool::new(tract, workers);
    let mut out = vec![0.0; frames.len().saturating_sub(1) * frame];
    let mut asked = 0;
    for (f, (_, glottis)) in frames.iter().enumerate() {
        while asked < frames.len() && pool.pending() < lookahead.max(1) as u64 {
            pool.submit(&frames[asked].0);
            asked += 1;
        }
        let geometry = pool.next(true).expect("a frame's geometry");
        let span = if f == 0 { 0..0 } else { (f - 1) * frame..f * frame };
        add(&geometry, glottis, &mut out[span]);
    }
    out
}

/// 2.3: vtlSynthBlock's sound, to the bit.
pub fn render(tract: &crate::tract::VocalTract, synth: &mut crate::synth::Synthesizer, frames: &[(Vec<f64>, Vec<f64>)], frame: usize, workers: usize, lookahead: usize) -> Vec<f64> {
    synth.reset();
    render_with(tract, frames, frame, workers, lookahead, |t, g, out| synth.add_geometry(t, g, out))
}

/// 2.4, at the synthesizer's steps a sample: its sequential synthesis's sound (Synthesizer::add_tract a frame at a
/// time from this tract), to the bit -- the bringing back to 48 kHz's delay still in it.
pub fn render_v24(tract: &crate::v24::tract::VocalTract, synth: &mut crate::v24::synth::Synthesizer, frames: &[(Vec<f64>, Vec<f64>)], workers: usize, lookahead: usize) -> Vec<f64> {
    synth.reset();
    render_with(tract, frames, crate::v24::synth::NUM_CHUNK_SAMPLES, workers, lookahead, |t, g, out| synth.add_geometry(t, g, out))
}

#[cfg(test)]
mod tests {
    use super::*;

    /// A tract whose tube is its parameter, but for a parameter under zero, where it finds no incisors and its tube is
    /// the position it holds from the last frame -- as VocalTractLab's areas are shaped by it.
    #[derive(Clone)]
    struct Toy {
        incisor: f64,
        made: f64,
        found: bool,
    }

    impl Geometry for Toy {
        type Tube = (f64, f64, bool);
        fn calculate(&mut self, params: &[f64]) {
            std::thread::sleep(std::time::Duration::from_micros((params[0].abs() * 7.0) as u64 % 300));
            self.found = params[0] >= 0.0;
            if self.found {
                self.incisor = params[0];
            }
            self.made = self.incisor * 10.0 + params[0];
        }
        fn tube(&self) -> Self::Tube {
            (self.made, self.incisor, self.found)
        }
        fn incisor_pos_cm(&self) -> f64 {
            self.incisor
        }
        fn set_incisor_pos_cm(&mut self, pos_cm: f64) {
            self.incisor = pos_cm;
        }
        fn incisors_found(t: &Self::Tube) -> bool {
            t.2
        }
        fn tube_incisor_pos_cm(t: &Self::Tube) -> f64 {
            t.1
        }
    }

    #[test]
    fn frames_without_incisors_come_out_as_the_sequential_ones() {
        // (Runs of a frame repeated, after frames with incisors and without: given again, not made.)
        let params: Vec<f64> = (0..400).map(|k| if k % 7 == 3 || k % 11 == 5 { -((k % 13) as f64) - 1.0 } else { (k % 17) as f64 }).flat_map(|p| std::iter::repeat(p).take(if p < -5.0 || p == 4.0 { 3 } else { 1 })).collect();
        let mut sequential = Toy { incisor: 2.5, made: 0.0, found: false };
        let expected: Vec<(f64, f64, bool)> = params.iter().map(|p| {
            sequential.calculate(&[*p]);
            sequential.tube()
        }).collect();
        for workers in 1..=4 {
            let mut pool = GeometryPool::new(&Toy { incisor: 2.5, made: 0.0, found: false }, workers);
            let mut got = Vec::new();
            let mut asked = 0;
            while got.len() < params.len() {
                while asked < params.len() && pool.pending() < 8 {
                    pool.submit(&[params[asked]]);
                    asked += 1;
                }
                got.push(pool.next(true).unwrap());
            }
            assert_eq!(got, expected, "{workers} workers");
            if workers > 1 {
                assert!(pool.remade > 0, "no frame was made on a stale position: the test tests nothing");
            }
            assert!(pool.repeated > 0, "no frame was given again: the test tests nothing");
        }
    }
}

