// The speech2vocaltract corpus (R. Picinini Méxas, Y. Chu & U. Park 2025, "Multilingual speech-to-vocal tract
// visualization using deep learning for pronunciation training", EURASIP JASMP 2026:3, doi:10.1186/s13636-025-00438-x;
// its data doi:10.5281/zenodo.15510640, CC BY 4.0): 5,000 sentences each of General American English, Korean and
// Brazilian Portuguese, each one's phones in SAMPA as VocalTractLab 2.3 was given them, and the parameters of the vocal
// tract its rules made of them, with JD3's shapes and the nine the authors added (vowels the speaker's German lacks, and
// /j/ and /w/ as vowels' shapes) and Korean's fortis and aspirated plosives (another voice onset time). What the corpus
// is -- its sources, its frames, its languages, the symbols it adds to the speaker's SAMPA -- is
// languages/speech2vocaltract.json, checked here against the types that hold it; the files stay where they were kept
// (research-downloads/voice/speech2vocaltract: the arrays and transcriptions unpacked, the speech models' features left in
// the archives). Every phone lasts 0.1 s, so each is where it falls in its sentence's frames, with no alignment made.
use crate::npy;
use crate::segments;
use crate::tract;
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;
use std::path::{Path, PathBuf};

/// The parameters' names in VocalTractLab's order (tract::HX ... tract::TS3).
pub const PARAM_NAMES: [&str; tract::NUM_PARAMS] = ["HX", "HY", "JX", "JA", "LP", "LD", "VS", "VO", "TCX", "TCY", "TTX", "TTY", "TBX", "TBY", "TRX", "TRY", "TS1", "TS2", "TS3"];

/// A published work the corpus comes from.
#[derive(Clone, Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Work {
    #[serde(default)]
    pub authors: Option<String>,
    pub title: String,
    #[serde(default)]
    pub venue: Option<String>,
    pub doi: String,
    pub licence: String,
    #[serde(default)]
    pub md5: BTreeMap<String, String>,
}

#[derive(Clone, Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Sources {
    pub paper: Work,
    pub dataset: Work,
    pub software: Work,
    /// Where the files were kept, from the trunk's folder.
    pub kept: String,
}

#[derive(Clone, Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct MadeBy {
    pub engine: String,
    pub speaker: String,
    pub found: String,
}

/// What each sentence's array holds: every `kept_every`th of the states VocalTractLab wrote, a state each
/// `state_samples` at `sampling_hz` from the score's start, the parameters named.
#[derive(Clone, Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Frames {
    pub state_samples: usize,
    pub sampling_hz: f64,
    pub states: String,
    pub kept_every: usize,
    pub params: Vec<String>,
    pub left_out: Vec<String>,
    pub glottis: String,
}

#[derive(Clone, Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Language {
    pub name: String,
    pub variety: String,
    /// Its folder, under where the corpus was kept: the two transcriptions and VTL_Parameters/NNNN.npy.
    pub folder: String,
    /// The eSpeak NG voice of the language.
    pub espeak: String,
    /// Whether its lines begin with their number ("12. ").
    pub numbered: bool,
    /// The authors' IPA into SAMPA as far as it was recovered from eSpeak NG's phones and the corpus's lines (the reader's
    /// own tables, languages/ipa.json, follow it where its phones are the speaker's).
    #[serde(default)]
    pub authors_ipa: Option<AuthorsIpa>,
    /// Phones of its lines the authors' engine made as another of the speaker's, as its frames show.
    #[serde(default)]
    pub made_as: Option<MadeAs>,
}

#[derive(Clone, Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct MadeAs {
    /// How it was found.
    pub found: String,
    /// The phone its lines write and the speaker's phone it was made as.
    pub table: BTreeMap<String, String>,
}

#[derive(Clone, Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct AuthorsIpa {
    /// How it was found, and how far it holds.
    pub found: String,
    /// eSpeak NG's phone (stress dropped) and the SAMPA the authors wrote for it ("" none).
    pub table: BTreeMap<String, String>,
}

#[derive(Clone, Copy, Debug, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "lowercase")]
pub enum Kind {
    Vowel,
    /// An approximant given a vowel's shape and gesture.
    Glide,
    Consonant,
}

#[derive(Clone, Copy, Debug, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "lowercase")]
pub enum Laryngeal {
    Fortis,
    Aspirated,
}

/// A symbol the corpus adds to the speaker's SAMPA.
#[derive(Clone, Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Symbol {
    pub sampa: String,
    pub ipa: String,
    pub kind: Kind,
    pub description: String,
    pub languages: Vec<String>,
    /// The paper's table or section that says so, or "found" in the files.
    pub origin: String,
    /// The speaker's consonant it is made from.
    #[serde(default)]
    pub base: Option<String>,
    #[serde(default)]
    pub laryngeal: Option<Laryngeal>,
    /// The speaker's own symbol, given another kind by the authors (/j/, a vowel's shape where the speaker's is a
    /// fricative's; /{/, a pause where VocalWind's is a vowel).
    #[serde(default)]
    pub redefines: bool,
    /// A vowel's or glide's: the shape its gesture approaches (its own symbol where none is named).
    #[serde(default)]
    pub shape: Option<String>,
    /// A plosive's voice onset time (s), where the frames show another than its base's.
    #[serde(default)]
    pub vot_s: Option<f64>,
    /// Found: the authors' engine made no gesture for it, whatever it stands for -- a pause to its tract -- but kept its
    /// name, so that it is a phone to where the breath and the voice begin and end (segments::Extra::gestureless).
    #[serde(default)]
    pub pause: bool,
    /// How the frames showed what it was made as (shape, onset time or pause).
    #[serde(default)]
    pub made_found: Option<String>,
}

/// The authors' rules where they are not VocalTractLab 2.3's, as the frames showed them
/// (examples/speech2vocaltract_parity.rs).
#[derive(Clone, Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Rules {
    /// A diphthong's two vowels, where they are not the rules' (aI is a and e in the rules).
    pub diphthong_targets: BTreeMap<String, [String; 2]>,
    /// Whether those diphthongs are made two vowels, each half the diphthong's length, not by the diphthong's rule (its
    /// second gesture begun up to 70 ms in).
    pub diphthongs_as_vowels: bool,
    /// An affricate's plosive's share of its length, where it is not the rules' (0.33 for ts and tS, 0.4 for pf and dZ).
    pub affricate_shares: BTreeMap<String, f64>,
    /// The speaker's plosives' voice onset times (s), where they are not the rules' (Klatt 1975's).
    pub voice_onset_times: BTreeMap<String, f64>,
    /// How the frames showed each.
    pub found: String,
}

#[derive(Clone, Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Spec {
    pub about: String,
    pub sources: Sources,
    pub made_by: MadeBy,
    /// Every phone's duration (s).
    pub phone_s: f64,
    pub phone_s_found: String,
    /// The speaker's diphthongs that are one phone in the transcriptions (each lasting two phones).
    pub speaker_diphthongs: Vec<String>,
    pub speaker_diphthongs_found: String,
    /// The authors' rules where they are not VocalTractLab 2.3's.
    pub rules: Rules,
    pub frames: Frames,
    pub languages: Vec<Language>,
    pub symbols: Vec<Symbol>,
}

impl Spec {
    pub fn parse(text: &str) -> Result<Spec, String> {
        let spec: Spec = serde_json::from_str(text).map_err(|e| e.to_string())?;
        spec.check()?;
        Ok(spec)
    }

    pub fn read(path: &Path) -> Result<Spec, String> {
        Spec::parse(&std::fs::read_to_string(path).map_err(|e| format!("{}: {e}", path.display()))?).map_err(|e| format!("{}: {e}", path.display()))
    }

    /// What the types cannot say: every name one of VocalTractLab's, every symbol new and its languages the corpus's.
    fn check(&self) -> Result<(), String> {
        for p in self.frames.params.iter().chain(&self.frames.left_out) {
            if !PARAM_NAMES.contains(&p.as_str()) {
                return Err(format!("{p} is not a parameter of VocalTractLab's"));
            }
        }
        if self.frames.params.len() + self.frames.left_out.len() != tract::NUM_PARAMS {
            return Err(format!("{} parameters kept and left out, of {}", self.frames.params.len() + self.frames.left_out.len(), tract::NUM_PARAMS));
        }
        for d in &self.speaker_diphthongs {
            if !segments::is_diphthong(d) {
                return Err(format!("/{d}/ is not one of the speaker's diphthongs"));
            }
        }
        if let Some((p, _)) = self.rules.voice_onset_times.iter().find(|(p, v)| !segments::is_plosive(p) || !(**v > 0.0 && **v < self.phone_s)) {
            return Err(format!("/{p}/'s voice onset time given, not one of the speaker's plosives or not within its phone"));
        }
        if let Some((a, _)) = self.rules.affricate_shares.iter().find(|(a, r)| !segments::is_affricate(a) || !(0.0..=1.0).contains(*r)) {
            return Err(format!("/{a}/'s plosive's share given, not one of the speaker's affricates or not a share"));
        }
        if let Some(d) = self.rules.diphthong_targets.keys().find(|d| !self.speaker_diphthongs.contains(d)) {
            return Err(format!("/{d}/'s targets given, not one of the diphthongs read"));
        }
        for l in &self.languages {
            if let Some((p, m)) = l.made_as.iter().flat_map(|m| &m.table).find(|(p, m)| !own(p) || !own(m)) {
                return Err(format!("{}: /{p}/ made as /{m}/, not two of the speaker's phones", l.name));
            }
        }
        let mut seen = std::collections::BTreeSet::new();
        for s in &self.symbols {
            if own(&s.sampa) != s.redefines {
                return Err(format!("/{}/ {}", s.sampa, if s.redefines { "is not the speaker's to redefine" } else { "is the speaker's own already" }));
            }
            if !seen.insert(s.sampa.as_str()) {
                return Err(format!("/{}/ twice", s.sampa));
            }
            if let Some(l) = s.languages.iter().find(|l| !self.languages.iter().any(|x| &x.name == *l)) {
                return Err(format!("/{}/: no language {l} in the corpus", s.sampa));
            }
            match (&s.base, s.laryngeal, s.kind) {
                (Some(b), Some(_), Kind::Consonant) if own(b) && !segments::is_vowel(b) => {}
                (None, None, _) => {}
                _ => return Err(format!("/{}/: a laryngeal kind wants a consonant made from one of the speaker's", s.sampa)),
            }
        }
        Ok(())
    }

    pub fn language(&self, name: &str) -> Result<&Language, String> {
        self.languages.iter().find(|l| l.name == name).ok_or_else(|| format!("no language {name} in the corpus"))
    }

    /// Each kept parameter's index among VocalTractLab's.
    pub fn param_indices(&self) -> Vec<usize> {
        self.frames.params.iter().map(|p| PARAM_NAMES.iter().position(|q| q == p).unwrap()).collect()
    }

    /// The seconds between two kept frames.
    pub fn frame_s(&self) -> f64 {
        (self.frames.kept_every * self.frames.state_samples) as f64 / self.frames.sampling_hz
    }

    /// The symbols a transcription is read in: the speaker's vowels and consonants, its diphthongs that are one phone,
    /// and the corpus's own, longest first.
    pub fn alphabet(&self) -> Vec<String> {
        let mut out: Vec<String> = segments::single_phones().map(str::to_string).collect();
        out.extend(self.speaker_diphthongs.iter().cloned());
        out.extend(self.symbols.iter().filter(|s| !s.redefines).map(|s| s.sampa.clone()));
        out.sort_by(|a, b| b.len().cmp(&a.len()).then(a.cmp(b)));
        out.dedup();
        out
    }

    /// A transcription's phones, each the longest symbol of the alphabet that begins where the last ended.
    pub fn phones(&self, sampa: &str) -> Result<Vec<String>, String> {
        let alphabet = self.alphabet();
        let mut out = Vec::new();
        let mut rest = sampa;
        while !rest.is_empty() {
            let Some(s) = alphabet.iter().find(|s| rest.starts_with(s.as_str())) else {
                return Err(format!("no phone at \"{rest}\" of \"{sampa}\""));
            };
            out.push(s.clone());
            rest = &rest[s.len()..];
        }
        Ok(out)
    }

    /// A phone's duration in phones: two for a diphthong.
    pub fn units(&self, phone: &str) -> usize {
        if self.speaker_diphthongs.iter().any(|d| d == phone) {
            2
        } else {
            1
        }
    }

    pub fn symbol(&self, sampa: &str) -> Option<&Symbol> {
        self.symbols.iter().find(|s| s.sampa == sampa)
    }

    /// The rules' phones beyond the speaker's, as the authors' engine made them: each vowel and glide to its shape, each
    /// laryngeal plosive by its base's rule; a pause made a phone with no gesture (still a phone to where the breath and
    /// the voice begin and end), a consonant made from none of the speaker's left a pause.
    pub fn extra(&self) -> segments::Extra {
        let mut extra = segments::Extra::default();
        extra.gestureless = self.symbols.iter().filter(|s| s.pause).map(|s| s.sampa.clone()).collect();
        for s in self.symbols.iter().filter(|s| !s.pause) {
            match (s.kind, &s.base) {
                (Kind::Vowel | Kind::Glide, _) => extra.vowels.push((s.sampa.clone(), s.shape.clone().unwrap_or_else(|| s.sampa.clone()))),
                (Kind::Consonant, Some(base)) if segments::is_plosive(base) => extra.plosives.push((s.sampa.clone(), base.clone(), s.vot_s)),
                _ => {}
            }
        }
        for (d, [a, b]) in &self.rules.diphthong_targets {
            extra.diphthongs.push((d.clone(), a.clone(), b.clone()));
        }
        extra.diphthongs_as_vowels = self.rules.diphthongs_as_vowels;
        extra.affricates = self.rules.affricate_shares.iter().map(|(a, r)| (a.clone(), *r)).collect();
        for (p, vot) in &self.rules.voice_onset_times {
            extra.plosives.push((p.clone(), p.clone(), Some(*vot)));
        }
        extra
    }

    /// A language's line's phones as its authors' engine made them (its `made_as`).
    pub fn made_as(&self, language: &str, phones: &[String]) -> Result<Vec<String>, String> {
        let table = self.language(language)?.made_as.as_ref().map(|m| &m.table);
        Ok(phones.iter().map(|p| table.and_then(|t| t.get(p)).unwrap_or(p).clone()).collect())
    }

    /// A sentence's segments as the corpus made them: each phone its 0.1 s (a diphthong two), from the score's start.
    pub fn segments(&self, phones: &[String]) -> Vec<segments::Segment> {
        phones.iter().map(|p| segments::Segment { name: p.clone(), duration_s: self.phone_s * self.units(p) as f64, labels: Vec::new() }).collect()
    }
}

/// A speaker's shapes as found from a corpus (src/speaker_fit.rs): each replaces the speaker's shape of its name, or is
/// added to them. `params` are the corpus's kept parameters in the spec's order; `sides` (TS1-3, which no frame holds) are
/// taken from the shape named in `sides_from`.
#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct FoundShape {
    pub name: String,
    pub params: Vec<f64>,
    pub sides: [f64; 3],
    pub sides_from: String,
    /// Whether the speaker has a shape of this name, and how far this one is from it (the largest parameter's difference;
    /// none where it has none).
    pub speaker_has: bool,
    pub from_speaker: Option<f64>,
    /// The frames whose values it moved, and the rms of their residuals once found.
    pub frames: usize,
    pub rms: f64,
    /// How it was found: read from the first frames of the sentences that begin on it, or fitted.
    #[serde(default)]
    pub read_from: String,
}

#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct FoundSpeaker {
    pub about: String,
    /// The speaker file whose shapes these replace or join.
    pub speaker: String,
    pub params: Vec<String>,
    pub made: String,
    pub shapes: Vec<FoundShape>,
}

impl FoundSpeaker {
    pub fn read(path: &Path) -> Result<FoundSpeaker, String> {
        serde_json::from_str(&std::fs::read_to_string(path).map_err(|e| format!("{}: {e}", path.display()))?).map_err(|e| format!("{}: {e}", path.display()))
    }

    /// The shapes put into a tract: each replacing the one of its name, or added.
    pub fn apply(&self, vt: &mut tract::VocalTract) -> Result<(), String> {
        let kept: Vec<usize> = self.params.iter().map(|p| PARAM_NAMES.iter().position(|q| q == p).ok_or_else(|| format!("{p} is not a parameter"))).collect::<Result<_, _>>()?;
        for s in &self.shapes {
            if s.params.len() != kept.len() {
                return Err(format!("shape {}: {} parameters of {}", s.name, s.params.len(), kept.len()));
            }
            let mut v = vt.shape(&s.name).unwrap_or([0.0; tract::NUM_PARAMS]);
            for (&k, &x) in kept.iter().zip(&s.params) {
                v[k] = x;
            }
            v[tract::TS1] = s.sides[0];
            v[tract::TS2] = s.sides[1];
            v[tract::TS3] = s.sides[2];
            match vt.shapes.iter_mut().find(|(n, _)| *n == s.name) {
                Some((_, old)) => *old = v,
                None => vt.shapes.push((s.name.clone(), v)),
            }
        }
        Ok(())
    }
}

/// One sentence: its text, its transcription and its frames (each the kept parameters, in the order the spec names).
#[derive(Clone, Debug)]
pub struct Sentence {
    pub index: usize,
    pub text: String,
    pub sampa: String,
    pub phones: Vec<String>,
    pub frames: Vec<Vec<f64>>,
}

/// The corpus where it was kept.
#[derive(Clone, Debug)]
pub struct Corpus {
    pub spec: Spec,
    pub root: PathBuf,
}

/// A transcription's lines, their numbers taken off.
fn lines(path: &Path, numbered: bool) -> Result<Vec<String>, String> {
    let text = std::fs::read_to_string(path).map_err(|e| format!("{}: {e}", path.display()))?;
    text.lines()
        .filter(|l| !l.trim().is_empty())
        .enumerate()
        .map(|(k, l)| {
            let l = l.trim();
            if !numbered {
                return Ok(l.to_string());
            }
            let (n, rest) = l.split_once(". ").ok_or_else(|| format!("{}: line {} unnumbered", path.display(), k + 1))?;
            if n.parse::<usize>() != Ok(k + 1) {
                return Err(format!("{}: line {} numbered {n}", path.display(), k + 1));
            }
            Ok(rest.trim().to_string())
        })
        .collect()
}

impl Corpus {
    /// The corpus described by `spec`, kept in `root` (research-downloads/voice/speech2vocaltract).
    pub fn open(spec: &Path, root: &Path) -> Result<Corpus, String> {
        Ok(Corpus { spec: Spec::read(spec)?, root: root.to_path_buf() })
    }

    fn folder(&self, language: &str) -> Result<PathBuf, String> {
        Ok(self.root.join(&self.spec.language(language)?.folder))
    }

    /// A language's sentences, their texts and transcriptions, without their frames.
    pub fn transcriptions(&self, language: &str) -> Result<Vec<(String, String)>, String> {
        let dir = self.folder(language)?;
        let numbered = self.spec.language(language)?.numbered;
        let texts = lines(&dir.join("SentencesTranscriptionoutput.txt"), numbered)?;
        let sampa = lines(&dir.join("SentencesTranscriptionoutputSAMPA.txt"), numbered)?;
        if texts.len() != sampa.len() {
            return Err(format!("{language}: {} texts and {} transcriptions", texts.len(), sampa.len()));
        }
        Ok(texts.into_iter().zip(sampa).collect())
    }

    /// A sentence's frames, each its kept parameters.
    pub fn frames(&self, language: &str, index: usize) -> Result<Vec<Vec<f64>>, String> {
        let a = npy::read(&self.folder(language)?.join("VTL_Parameters").join(format!("{index:04}.npy")))?;
        if a.shape.len() != 2 || a.shape[1] != self.spec.frames.params.len() {
            return Err(format!("{language} {index}: shape {:?}, not frames of {} parameters", a.shape, self.spec.frames.params.len()));
        }
        let rows = a.rows()?.map(<[f64]>::to_vec).collect();
        Ok(rows)
    }

    /// A language's sentences whole.
    pub fn sentences(&self, language: &str) -> Result<Vec<Sentence>, String> {
        self.transcriptions(language)?
            .into_iter()
            .enumerate()
            .map(|(index, (text, sampa))| {
                let phones = self.spec.phones(&sampa).map_err(|e| format!("{language} {index}: {e}"))?;
                Ok(Sentence { index, text, frames: self.frames(language, index)?, sampa, phones })
            })
            .collect()
    }
}

/// The corpus's own sounds' source in languages/phones.json.
const SOURCE: &str = "speech2vocaltract";

/// One of the speaker's own phones (VocalTractLab's), not one learned from the corpus.
fn own(s: &str) -> bool {
    crate::inventory::phone(s).is_some_and(|p| p.source != SOURCE)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::gestural::{GesturalScore, LUNG_PRESSURE, TONGUE_TIP};

    fn spec() -> Spec {
        Spec::read(&Path::new(env!("CARGO_MANIFEST_DIR")).join("languages/speech2vocaltract.json")).unwrap()
    }

    #[test]
    fn the_corpus_description_holds() {
        let s = spec();
        assert_eq!(s.param_indices(), (0..16).collect::<Vec<_>>());
        assert!((s.frame_s() - 880.0 / 44100.0).abs() < 1e-15);
        assert_eq!(s.symbol("p_h").and_then(|x| x.base.as_deref()), Some("p"));
    }

    #[test]
    fn transcriptions_read_as_phones() {
        let s = spec();
        // (The first sentence of each language.)
        assert_eq!(s.phones("D@k{tsli:pskwaI@tli").unwrap(), ["D", "@", "k", "{", "ts", "l", "i:", "p", "s", "k", "w", "aI", "@", "t", "l", "i"]);
        assert_eq!(s.phones("kMnMnp_hjVndzirMlsMndA").unwrap(), ["k", "M", "n", "M", "n", "p_h", "j", "V", "n", "d", "z", "i", "r", "M", "l", "s", "M", "n", "d", "A"]);
        assert_eq!(s.phones("m6J6").unwrap(), ["m", "6", "J", "6"]);
        assert!(s.phones("k@#").is_err());
        // (Korean's /r/ made as the speaker's /l/, as its frames show; English's as its own.)
        let r: Vec<String> = ["M", "r", "i"].iter().map(|p| p.to_string()).collect();
        assert_eq!(s.made_as("korean", &r).unwrap(), ["M", "l", "i"]);
        assert_eq!(s.made_as("english", &r).unwrap(), r);
    }

    #[test]
    fn refuses_what_it_does_not_hold() {
        let text = std::fs::read_to_string(Path::new(env!("CARGO_MANIFEST_DIR")).join("languages/speech2vocaltract.json")).unwrap();
        assert!(Spec::parse(&text.replacen("\"TRY\"", "\"TRZ\"", 1)).is_err());
        assert!(Spec::parse(&text.replacen("\"sampa\": \"V\"", "\"sampa\": \"a\"", 1)).is_err());
        assert!(Spec::parse(&text.replacen("\"phone_s\": 0.1", "\"phone_s\": 0.1, \"phone\": 1", 1)).is_err());
        // (The rules name only the speaker's plosives, affricates and the diphthongs read, with values they can take.)
        for (from, to) in [
            ("\"voice_onset_times\": {", "\"voice_onset_times\": {\"m\": 0.02, "),
            ("\"voice_onset_times\": {", "\"voice_onset_times\": {\"p\": 0.2, "),
            ("\"affricate_shares\": {", "\"affricate_shares\": {\"t\": 0.5, "),
            ("\"affricate_shares\": {", "\"affricate_shares\": {\"tS\": 1.5, "),
            ("\"diphthong_targets\": {", "\"diphthong_targets\": {\"ei\": [\"e\", \"i\"], "),
        ] {
            assert!(text.contains(from) && Spec::parse(&text.replacen(from, to, 1)).is_err(), "{to}");
        }
    }

    #[test]
    fn a_pause_symbol_is_still_a_phone_to_the_breath() {
        // (The speech2vocaltract speaker, JD3, where VocalTractLab's sources are; skipped elsewhere.)
        let Some(home) = std::env::var_os("HOME") else { return };
        let file = Path::new(&home).join("Library/Application Support/Musebots/synthesis/vocaltractlab-src/resources/JD3.speaker");
        let Ok(text) = std::fs::read_to_string(&file) else {
            eprintln!("skipped: no {}", file.display());
            return;
        };
        let root = crate::xml::parse(&text).unwrap();
        let mut vt = crate::tract::VocalTract::from_xml(root.child("vocal_tract_model").unwrap()).unwrap();
        let s = spec();
        let extra = s.extra();
        assert!(s.symbol("{").unwrap().pause && extra.gestureless.iter().any(|g| g == "{"));
        let made = |phones: &[&str], extra: &segments::Extra, vt: &mut crate::tract::VocalTract| {
            let mut score = GesturalScore::new();
            score.from_segments_with(&s.segments(&phones.iter().map(|p| p.to_string()).collect::<Vec<_>>()), vt, extra);
            score
        };
        // At a sentence's end the lungs' pressure falls 120 ms before the last phone ends, over 170 ms: 50 ms past the
        // pause symbol, as the corpus's frames run (an empty segment's end, 50 ms before it, made them 2 or 3 short).
        // (/1/ is no phone of the inventory's; /{/ is one, a vowel, and is made none all the same.)
        let end = made(&["a", "l", "1"], &extra, &mut vt);
        assert!((end.seq[LUNG_PRESSURE].duration_s() - 0.35).abs() < 1e-9, "{}", end.seq[LUNG_PRESSURE].duration_s());
        assert_eq!(made(&["a", "l", "{"], &extra, &mut vt).seq[LUNG_PRESSURE].duration_s(), end.seq[LUNG_PRESSURE].duration_s());
        let empty = made(&["a", "l", "1"], &segments::Extra::default(), &mut vt);
        assert!((empty.seq[LUNG_PRESSURE].duration_s() - 0.25).abs() < 1e-9);
        // At its start, a fricative after one is not the first phone: its tongue's gesture begins 72 ms before it, not at 0.
        let start = made(&["{", "s", "a"], &extra, &mut vt);
        let first = &start.seq[TONGUE_TIP].gestures[0];
        assert!(first.s_val.is_empty() && (first.duration_s - (0.1 - 0.072)).abs() < 1e-9, "{first:?}");
        assert_eq!(made(&["1", "s", "a"], &segments::Extra::default(), &mut vt).seq[TONGUE_TIP].gestures[0].s_val, "tt-alveolar-fricative");
    }

    /// JD3 with the found speaker's shapes, and the corpus, where they are (the trunk Mac); None elsewhere.
    fn found_speaker_and_corpus() -> Option<(crate::tract::VocalTract, Corpus)> {
        let home = std::env::var_os("HOME")?;
        let file = Path::new(&home).join("Library/Application Support/Musebots/synthesis/vocaltractlab-src/resources/JD3.speaker");
        let crate_dir = Path::new(env!("CARGO_MANIFEST_DIR"));
        let folder = crate_dir.join("../../../research-downloads/voice/speech2vocaltract");
        let (Ok(text), true) = (std::fs::read_to_string(&file), folder.is_dir()) else {
            eprintln!("skipped: no {} or no {}", file.display(), folder.display());
            return None;
        };
        let root = crate::xml::parse(&text).unwrap();
        let mut vt = crate::tract::VocalTract::from_xml(root.child("vocal_tract_model").unwrap()).unwrap();
        FoundSpeaker::read(&crate_dir.join("languages/speech2vocaltract-speaker.json")).unwrap().apply(&mut vt).unwrap();
        Some((vt, Corpus::open(&crate_dir.join("languages/speech2vocaltract.json"), &folder).unwrap()))
    }

    /// The largest of a sentence's frames' differences from the corpus's, its phones made as given.
    fn largest(vt: &crate::tract::VocalTract, corpus: &Corpus, language: &str, index: usize, made_as: &[String], extra: &segments::Extra) -> f64 {
        let s = &corpus.spec;
        let fit = crate::speaker_fit::Fit { kept: s.param_indices(), every: s.frames.kept_every, unknowns: Vec::new(), threads: 1, step: 1e-5 };
        let item = crate::speaker_fit::Item { segments: s.segments(made_as), frames: corpus.frames(language, index).unwrap() };
        let made = fit.make(std::slice::from_ref(&item), vt, extra);
        let (r, same) = fit.residuals(&item, &made[0], vt);
        assert!(same);
        r.iter().fold(0f64, |a, x| a.max(x.abs()))
    }

    #[test]
    fn korean_is_made_as_its_frames_show() {
        // (korean 658 /m u r i t_> A k t_> A t_> M t_h E j o/ through JD3 and the found speaker's shapes.)
        let Some((vt, corpus)) = found_speaker_and_corpus() else { return };
        let s = &corpus.spec;
        let phones = s.phones(&corpus.transcriptions("korean").unwrap()[658].1).unwrap();
        let largest = |made_as: &[String], extra: &segments::Extra| largest(&vt, &corpus, "korean", 658, made_as, extra);
        // Its /r/ the speaker's /l/, its fortis plosives' closures ending 10 ms into the next phone, its aspirated
        // plosives' at the middle of their own: the corpus's frames to their printed digits.
        let extra = s.extra();
        assert_eq!(extra.plosive("t_>"), Some(("t", Some(-0.010))));
        let korean = s.made_as("korean", &phones).unwrap();
        assert!(largest(&korean, &extra) < 2e-5, "{}", largest(&korean, &extra));
        // The speaker's own /r/, or the fortis plosives by their base's rule, far from them.
        assert!(largest(&phones, &extra) > 0.5);
        let mut base = extra.clone();
        base.plosives.iter_mut().filter(|p| p.0 == "t_>").for_each(|p| p.2 = None);
        assert!(largest(&korean, &base) > 0.1);
    }

    #[test]
    fn voiced_plosives_release_as_the_frames_show() {
        // Each sentence exact at the spec's onset time and one step from it the other way not: english 151 from /b/'s
        // 16.7 ms, 3497 up to it; english 3531 at /d/'s 17.5 ms alone; english 666 from /g/'s 36.8 ms, portuguese 3538 up
        // to it.
        let Some((vt, corpus)) = found_speaker_and_corpus() else { return };
        let s = &corpus.spec;
        let extra = s.extra();
        assert_eq!((extra.plosive("b"), extra.plosive("d"), extra.plosive("g")), (Some(("b", Some(0.0167))), Some(("d", Some(0.0175))), Some(("g", Some(0.0368)))));
        for (language, index, plosive, off) in [("english", 151, "b", [0.0166].as_slice()), ("english", 3497, "b", &[0.0168]), ("english", 3531, "d", &[0.01725, 0.01775]), ("english", 666, "g", &[0.0367]), ("portuguese", 3538, "g", &[0.0369])] {
            let phones = s.made_as(language, &s.phones(&corpus.transcriptions(language).unwrap()[index].1).unwrap()).unwrap();
            let at = largest(&vt, &corpus, language, index, &phones, &extra);
            assert!(at < 2e-5, "{language} {index}: {at}");
            for &v in off {
                let mut moved = extra.clone();
                moved.plosives.iter_mut().filter(|p| p.0 == plosive).for_each(|p| p.2 = Some(v));
                let by = largest(&vt, &corpus, language, index, &phones, &moved);
                assert!(by > 1e-3, "{language} {index} at {v}: {by}");
            }
        }
    }
}
