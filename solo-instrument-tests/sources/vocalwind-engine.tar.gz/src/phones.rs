// Phones as VocalTractLab's rules take them: IPA into its German SAMPA, the reader's (ssml.rs) and the live voice's
// (vtl-stream's sing), and the pause 2.4's rules lay before a sequence's first phone. A sound is looked up in its
// language's own table (languages/ipa.json), then among the phones every language shares (languages/phones.json, each
// by its IPA: a sound learned in one language is every language's that has it), then in its language's nearest and the
// shared nearest -- which also say a learned phone for a speaker with no shape of it.

/// The silence each 2.4 score begins with: its rules make every sequence begin with 100 ms of pause at least.
pub const RULES_REACH_24_S: f64 = 0.1;

use crate::inventory::{inventory, language_file};
use serde::Deserialize;
use std::collections::BTreeMap;
use std::sync::OnceLock;

/// The IPA table (languages/ipa.json): the marks dropped, each language's own phones and nearest, and the nearest of
/// the sounds no phone is (the phones' own IPA in languages/phones.json).
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct IpaTable {
    #[allow(dead_code)]
    about: String,
    dropped: Vec<char>,
    vowel_letters: String,
    nearest: BTreeMap<String, String>,
    languages: BTreeMap<String, IpaLanguage>,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct IpaLanguage {
    #[allow(dead_code)]
    about: String,
    #[serde(default)]
    own: BTreeMap<String, String>,
    #[serde(default)]
    nearest: BTreeMap<String, String>,
}

fn ipa_table() -> &'static IpaTable {
    static TABLE: OnceLock<IpaTable> = OnceLock::new();
    TABLE.get_or_init(|| serde_json::from_str(&language_file("ipa.json", include_str!("../languages/ipa.json"))).unwrap_or_else(|e| panic!("languages/ipa.json: {e}")))
}

/// IPA into the speakers' phones (VocalTractLab's German SAMPA) in a language (its BCP 47 tag, as eSpeak NG's voices
/// are named, "pt-br"; or none, ""): the phones -- one, or several that share its time -- and whether they are the
/// nearest of the speaker's, not its own (said in the warnings). Looked up in languages/ipa.json's own table of the full
/// tag, then of its primary subtag ("pt"), then among the phones every language shares (languages/phones.json), then in
/// the tag's and the subtag's nearest, then the shared nearest. None where the speaker has nothing near.
pub fn phones_in(ipa: &str, language: &str) -> Option<(Vec<&'static str>, bool)> {
    let s = bare(ipa);
    tables(language, true).into_iter().find_map(|(m, nearest)| m.get(&s).map(|x| (x.split(' ').collect(), nearest)))
}

/// What a speaker with no shape of a shared phone says its sound as in a language: the sound looked up past the
/// phones every language shares (the language's nearest, then the shared nearest). None where there is none.
pub fn stand_in(ipa: &str, language: &str) -> Option<Vec<&'static str>> {
    let s = bare(ipa);
    tables(language, false).into_iter().filter(|(_, nearest)| *nearest).find_map(|(m, _)| m.get(&s).map(|x| x.split(' ').collect()))
}

/// A shared phone's nearest of the speaker's in no language in particular (the shared nearest of its sound): what the
/// rules make it where the speaker has no shape of it.
pub fn nearest_phone(name: &str) -> Option<&'static str> {
    let table = ipa_table();
    let p = crate::inventory::phone(name)?;
    p.ipa.iter().find_map(|s| table.nearest.get(s)).map(String::as_str).filter(|x| !x.contains(' '))
}

/// The same for a phone cut short (eSpeak NG's phone events hold 8 bytes: "ˈɐ̃ʊ̃" comes as "ˈɐ̃ʊ", a character cut in two
/// as U+FFFD): the phones of the shortest sound in the tables that begins with what is left, looked up as phones_in does.
pub fn phones_begun(ipa: &str, language: &str) -> Option<(Vec<&'static str>, bool)> {
    let s = bare(ipa.trim_end_matches('\u{FFFD}'));
    if s.is_empty() {
        return None;
    }
    tables(language, true).into_iter().find_map(|(m, nearest)| m.iter().filter(|(k, _)| k.starts_with(&s)).min_by_key(|(k, _)| k.len()).map(|(_, x)| (x.split(' ').collect(), nearest)))
}

/// Whether an IPA phone has one of the vowels' letters (languages/ipa.json's `vowel_letters`).
pub fn has_vowel_letter(ipa: &str) -> bool {
    let letters = &ipa_table().vowel_letters;
    ipa.chars().any(|c| letters.contains(c))
}

/// An IPA phone without the marks the table drops.
fn bare(ipa: &str) -> String {
    let table = ipa_table();
    ipa.chars().filter(|c| !table.dropped.contains(c)).collect()
}

/// The tables a language's phones are looked up in, in order, each with whether it holds the nearest phones: its own,
/// the shared phones' (where asked), its nearest, the shared nearest.
fn tables(language: &str, shared: bool) -> Vec<(&'static BTreeMap<String, String>, bool)> {
    let table = ipa_table();
    let tag = language.to_lowercase().replace('_', "-");
    let primary = tag.split('-').next().unwrap_or("");
    let mut names = vec![tag.as_str()];
    if primary != tag {
        names.push(primary);
    }
    let languages: Vec<&IpaLanguage> = names.into_iter().filter_map(|n| table.languages.get(n)).collect();
    let mut out: Vec<(&BTreeMap<String, String>, bool)> = languages.iter().map(|l| (&l.own, false)).collect();
    if shared {
        out.push((inventory().ipa(), false));
    }
    out.extend(languages.iter().map(|l| (&l.nearest, true)));
    out.push((&table.nearest, true));
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    fn one(ipa: &str, language: &str) -> Option<(&'static str, bool)> {
        phones_in(ipa, language).map(|(p, n)| {
            assert_eq!(p.len(), 1, "{ipa}");
            (p[0], n)
        })
    }

    #[test]
    fn ipa_into_the_speakers_sampa() {
        // (German's own one to one, its stress and tie marks dropped; English's nearest of the speaker's, said; a phone
        // with none, none.)
        assert_eq!(one("ˈaː", "de"), Some(("a:", false)));
        assert_eq!(one("t͡ʃ", ""), Some(("tS", false)));
        assert_eq!(one("ɔʏ", "de-DE"), Some(("OY", false)));
        assert_eq!(one("ɔɪ", ""), Some(("OY", true)));
        assert_eq!(one("ɜ", ""), Some(("6", true)));
        // (A phone measured for some speakers is every language's, its nearest the stand-in of a speaker without it.)
        assert_eq!(one("ɝ", "en-us"), Some(("3`", false)));
        assert_eq!(stand_in("ɝ", "en-us"), Some(vec!["6"]));
        assert_eq!(stand_in("ɚ", "en-us"), Some(vec!["@"]));
        assert_eq!(one("ɾ", "de"), Some(("r", false)));
        assert_eq!(one("ɾ", ""), Some(("d", true)));
        assert_eq!(one("ʘ", ""), None);
        // (A language's own table before the shared, its full tag's before its primary subtag's.)
        assert_eq!(one("ɹ", "en-US"), Some(("r", true)));
        assert_eq!(one("y", "pt-BR"), Some(("I", false)));
        assert_eq!(one("y", "pt"), Some(("y", false)));
        assert_eq!(one("ɾ", "pt-br"), Some(("r", true)));
        assert_eq!(one("ɾ", "ko"), Some(("l", true)));
        assert_eq!(phones_in("ˈeɪ", "en-us"), Some((vec!["e", "I"], false)));
        assert_eq!(phones_in("ɐ̃ʊ̃", "pt-br"), Some((vec!["6", "U"], true)));
        // (A nasal vowel as eSpeak writes it, the vowel and a combining tilde.)
        assert_eq!(one("u\u{303}", "pt"), Some(("u", true)));
        // (A phone eSpeak's events cut short, read as the sound it begins.)
        assert_eq!(phones_in("ˈɐ̃ʊ", "pt-br"), None);
        assert_eq!(phones_begun("ˈɐ̃ʊ", "pt-br"), Some((vec!["6", "U"], true)));
        assert_eq!(phones_begun("ˈɐ̃\u{FFFD}", "pt-br"), Some((vec!["6"], true)));
        // (A sound learned from one language any language's, its language's nearest for a speaker without its shape.)
        assert_eq!(one("ʌ", "en-us"), Some(("V", false)));
        assert_eq!(one("ʌ", "ko"), Some(("V", false)));
        assert_eq!(stand_in("ʌ", "en-us"), Some(vec!["a"]));
        assert_eq!(stand_in("ˈʌ", "ko"), Some(vec!["O"]));
        assert_eq!(one("ɯ", "ko"), Some(("M", false)));
        assert_eq!(one("w", "pt-br"), Some(("w", false)));
        assert_eq!(nearest_phone("V"), Some("a"));
        assert_eq!(nearest_phone("M"), Some("u"));
        assert_eq!(stand_in("a", "de"), None);
        assert_eq!(one("ɐ", "ko"), Some(("a", false)));
    }

    #[test]
    fn every_sound_latin_is_read_into_is_the_speakers() {
        // (Each sound public/shared/vocal/latin.js reads Latin's spelling into -- its table's `durations` -- a phone or
        // phones the speaker has in Latin, none a pause; its diphthong the speaker's own, [ɲ] Portuguese's.)
        let table: serde_json::Value = serde_json::from_str(include_str!("../../../public/shared/vocal/latin.json")).unwrap();
        for ipa in table["durations"].as_object().unwrap().keys() {
            assert!(phones_in(ipa, "la").is_some(), "[{ipa}]");
        }
        assert_eq!(one("au", "la"), Some(("aU", false)));
        assert_eq!(one("ˈɛ", "la"), Some(("E", false)));
        assert_eq!(phones_in("dz", "la"), Some((vec!["d", "z"], false)));
        assert_eq!(phones_in("ɲ", "la"), Some((vec!["n", "j"], true)));
    }

    #[test]
    fn every_shared_phone_learned_has_a_stand_in() {
        // (A phone learned from a corpus has a nearest of the German speakers' for a speaker without its shape.)
        for (name, p) in &inventory().phones {
            if p.source != "vocaltractlab-german" {
                let near = nearest_phone(name).and_then(crate::inventory::phone);
                assert!(near.is_some_and(|q| q.source == "vocaltractlab-german"), "{name} has no nearest of the German speakers'");
            }
        }
    }

    #[test]
    fn every_phone_the_table_gives_is_the_speakers() {
        let table = ipa_table();
        let maps = [inventory().ipa(), &table.nearest].into_iter().chain(table.languages.values().flat_map(|l| [&l.own, &l.nearest]));
        for m in maps {
            for (ipa, phones) in m {
                assert!(phones.split(' ').all(crate::segments::is_phoneme), "[{ipa}] as /{phones}/");
            }
        }
    }
}
