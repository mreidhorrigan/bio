// A surface of the vocal tract (Surface.cpp): a grid of vertices (ribs by rib points), two triangles between each four,
// and the edges between them; its bounding box in the midsagittal (xy) plane tiled, each tile listing the triangles over
// it, so that a plane through the z-axis cuts only the triangles near its line. What only drew it (normals, painting
// order, files) is left out. Each expression in the C++'s order.
use crate::geometry::{cross, p2, P2, P3};

pub const MAX_TILES_X: usize = 15;
pub const MAX_TILES_Y: usize = 15;
pub const MAX_TILE_TRIANGLES: usize = 150000 / (MAX_TILES_X * MAX_TILES_Y);
pub const STANDARD_TILE_WIDTH: f64 = 0.5;
pub const STANDARD_TILE_HEIGHT: f64 = 0.5;

#[derive(Clone, Copy, Debug, Default)]
struct Edge {
    vertex: [usize; 2],
    is_intersected: bool,
    // (The cut it was last tested for: the C++ clears a flag on every edge and vertex before each cut; a stamp that
    // differs is the same as a cleared flag, without touching them all.)
    tested_at: u32,
    intersection: P2,
}

#[derive(Clone, Debug, Default)]
pub struct Surface {
    pub num_ribs: usize,
    pub num_rib_points: usize,
    pub coord: Vec<P3>,
    triangle_vertex: Vec<[usize; 3]>,
    triangle_edge: Vec<[usize; 3]>,
    edge: Vec<Edge>,
    // Each vertex's side of the cutting line (-1 left, +1 right, 0 on it), and whether it was found yet.
    reserved: Vec<i32>,
    vertex_tested_at: Vec<u32>,
    cut: u32,
    // The tiles: their triangles, row-major over (x, y).
    tile: Vec<Vec<usize>>,
    left_border: f64,
    right_border: f64,
    top_border: f64,
    bottom_border: f64,
    tile_width: f64,
    tile_height: f64,
    num_tiles_x: usize,
    num_tiles_y: usize,
    line_point: P2,
    left_line_point: P2,
    right_line_point: P2,
    line_vector: P2,
}

impl Surface {
    pub fn new(ribs: usize, rib_points: usize) -> Surface {
        let mut s = Surface { num_ribs: ribs, num_rib_points: rib_points, ..Default::default() };
        if ribs == 0 || rib_points == 0 {
            return s;
        }
        let num_vertices = ribs * rib_points;
        s.coord = vec![P3::default(); num_vertices];
        s.reserved = vec![0; num_vertices];
        s.vertex_tested_at = vec![0; num_vertices];
        let (nr, np) = (ribs, rib_points);
        // (Edges: across the ribs, along them, then the diagonals.)
        for j in 0..np {
            for i in 0..nr - 1 {
                s.edge.push(Edge { vertex: [i * np + j, (i + 1) * np + j], ..Edge::default() });
            }
        }
        for i in 0..nr {
            for j in 0..np - 1 {
                s.edge.push(Edge { vertex: [i * np + j, i * np + j + 1], ..Edge::default() });
            }
        }
        for j in 0..np - 1 {
            for i in 0..nr - 1 {
                s.edge.push(Edge { vertex: [i * np + j, (i + 1) * np + j + 1], ..Edge::default() });
            }
        }
        let a = np * (nr - 1);
        let b = a + (np - 1) * nr;
        for i in 0..nr - 1 {
            for j in 0..np - 1 {
                s.triangle_vertex.push([i * np + j, (i + 1) * np + j + 1, i * np + j + 1]);
                s.triangle_edge.push([b + j * (nr - 1) + i, (j + 1) * (nr - 1) + i, a + i * (np - 1) + j]);
                s.triangle_vertex.push([i * np + j, (i + 1) * np + j, (i + 1) * np + j + 1]);
                s.triangle_edge.push([b + j * (nr - 1) + i, j * (nr - 1) + i, a + (i + 1) * (np - 1) + j]);
            }
        }
        s.tile = vec![Vec::with_capacity(MAX_TILE_TRIANGLES); MAX_TILES_X * MAX_TILES_Y];
        s
    }

    /// The triangles' vertex order reversed (their normals turned): it changes which edges a cut meets first.
    pub fn swap_triangle_orientation(&mut self) {
        for t in self.triangle_vertex.iter_mut() {
            t.swap(0, 2);
        }
    }

    #[inline]
    pub fn set(&mut self, rib: usize, rib_point: usize, p: P3) {
        self.coord[rib * self.num_rib_points + rib_point] = p;
    }
    #[inline]
    pub fn get(&self, rib: usize, rib_point: usize) -> P3 {
        self.coord[rib * self.num_rib_points + rib_point]
    }
    pub fn num_triangles(&self) -> usize {
        self.triangle_vertex.len()
    }

    /// Each triangle into every tile its bounding box (grown by 1 mm) overlaps.
    pub fn prepare_intersections(&mut self) {
        const EXTREME: f64 = 1000000.0;
        const EPSILON: f64 = 0.1;
        self.left_border = EXTREME;
        self.right_border = -EXTREME;
        self.bottom_border = EXTREME;
        self.top_border = -EXTREME;
        for q in &self.coord {
            if q.x < self.left_border {
                self.left_border = q.x;
            }
            if q.x > self.right_border {
                self.right_border = q.x;
            }
            if q.y < self.bottom_border {
                self.bottom_border = q.y;
            }
            if q.y > self.top_border {
                self.top_border = q.y;
            }
        }
        self.left_border -= EPSILON;
        self.bottom_border -= EPSILON;
        self.right_border += EPSILON;
        self.top_border += EPSILON;
        let mut nx = ((self.right_border - self.left_border) / STANDARD_TILE_WIDTH) as i32 + 1;
        let mut ny = ((self.top_border - self.bottom_border) / STANDARD_TILE_HEIGHT) as i32 + 1;
        nx = nx.clamp(1, MAX_TILES_X as i32);
        ny = ny.clamp(1, MAX_TILES_Y as i32);
        self.num_tiles_x = nx as usize;
        self.num_tiles_y = ny as usize;
        self.tile_width = (self.right_border - self.left_border) / nx as f64;
        self.tile_height = (self.top_border - self.bottom_border) / ny as f64;
        for t in self.tile.iter_mut() {
            t.clear();
        }
        for (i, tv) in self.triangle_vertex.iter().enumerate() {
            let (mut min_x, mut min_y, mut max_x, mut max_y) = (EXTREME, EXTREME, -EXTREME, -EXTREME);
            for &v in tv {
                let p = self.coord[v];
                if p.x < min_x {
                    min_x = p.x;
                }
                if p.x > max_x {
                    max_x = p.x;
                }
                if p.y < min_y {
                    min_y = p.y;
                }
                if p.y > max_y {
                    max_y = p.y;
                }
            }
            min_x -= EPSILON;
            max_x += EPSILON;
            min_y -= EPSILON;
            max_y += EPSILON;
            let clamp_x = |v: i32| v.max(0).min(nx - 1) as usize;
            let clamp_y = |v: i32| v.max(0).min(ny - 1) as usize;
            let left = clamp_x(((min_x - self.left_border) / self.tile_width) as i32);
            let right = clamp_x(((max_x - self.left_border) / self.tile_width) as i32);
            let bottom = clamp_y(((min_y - self.bottom_border) / self.tile_height) as i32);
            let top = clamp_y(((max_y - self.bottom_border) / self.tile_height) as i32);
            for x in left..=right {
                for y in bottom..=top {
                    let t = &mut self.tile[x * MAX_TILES_Y + y];
                    if t.len() < MAX_TILE_TRIANGLES {
                        t.push(i);
                    }
                }
            }
        }
    }

    /// The line of the cutting plane: q and its direction v (normalized here).
    pub fn prepare_intersection(&mut self, q: P2, mut v: P2) {
        const EPSILON: f64 = 0.000001;
        self.cut = self.cut.wrapping_add(1);
        if self.cut == 0 {
            // (After 2^32 cuts the stamps start again: every one cleared once.)
            self.vertex_tested_at.iter_mut().for_each(|t| *t = 0);
            self.edge.iter_mut().for_each(|e| e.tested_at = 0);
            self.cut = 1;
        }
        v.normalize();
        self.line_vector = v;
        self.line_point = q;
        let n = p2(-v.y, v.x);
        self.left_line_point = q + EPSILON * n;
        self.right_line_point = q - EPSILON * n;
    }

    // A tile's triangles onto the list; false where they would not fit under max (the C++ stops there).
    fn push_tile(&self, list: &mut Vec<usize>, x: i32, y: i32, max: usize) -> bool {
        if x >= 0 && (x as usize) < self.num_tiles_x && y >= 0 && (y as usize) < self.num_tiles_y {
            let t = &self.tile[x as usize * MAX_TILES_Y + y as usize];
            if list.len() + t.len() > max {
                return false;
            }
            list.extend_from_slice(t);
        }
        true
    }

    /// The triangles the cutting line may cross, tile by tile along it (a triangle once a tile it overlaps), at most
    /// max: as the C++ (getTriangleList), the walk stops at the first tile that would not fit.
    pub fn triangle_list(&self, list: &mut Vec<usize>, max: usize) {
        list.clear();
        let _ = self.walk_tiles(list, max);
    }

    fn walk_tiles(&self, list: &mut Vec<usize>, max: usize) -> bool {
        let q = self.line_point;
        let mut v = self.line_vector;
        let (nx, ny) = (self.num_tiles_x as i32, self.num_tiles_y as i32);
        if v.y.abs() <= v.x.abs() * self.tile_height / self.tile_width {
            // (Rather horizontal: walk the columns.)
            if v.x < 0.0 {
                v.x = -v.x;
                v.y = -v.y;
            }
            let mut y = q.y + (self.left_border - q.x) * v.y / v.x;
            let delta_y = v.y * self.tile_width / v.x;
            let mut tile_y = ((y - self.bottom_border) / self.tile_height) as i32;
            if v.y > 0.0 {
                let mut next_border_y = self.bottom_border + (tile_y + 1) as f64 * self.tile_height;
                for tile_x in 0..nx {
                    if !self.push_tile(list, tile_x, tile_y, max) {
                        return false;
                    }
                    if y + delta_y > next_border_y {
                        tile_y += 1;
                        next_border_y += self.tile_height;
                        if !self.push_tile(list, tile_x, tile_y, max) {
                        return false;
                    }
                    }
                    y += delta_y;
                }
            } else {
                let mut next_border_y = self.bottom_border + tile_y as f64 * self.tile_height;
                for tile_x in 0..nx {
                    if !self.push_tile(list, tile_x, tile_y, max) {
                        return false;
                    }
                    if y + delta_y < next_border_y {
                        tile_y -= 1;
                        next_border_y -= self.tile_height;
                        if !self.push_tile(list, tile_x, tile_y, max) {
                        return false;
                    }
                    }
                    y += delta_y;
                }
            }
        } else {
            // (Rather vertical: walk the rows.)
            if v.y < 0.0 {
                v.x = -v.x;
                v.y = -v.y;
            }
            let mut x = q.x + (self.bottom_border - q.y) * v.x / v.y;
            let delta_x = v.x * self.tile_height / v.y;
            let mut tile_x = ((x - self.left_border) / self.tile_width) as i32;
            if v.x > 0.0 {
                let mut next_border_x = self.left_border + (tile_x + 1) as f64 * self.tile_width;
                for tile_y in 0..ny {
                    if !self.push_tile(list, tile_x, tile_y, max) {
                        return false;
                    }
                    if x + delta_x > next_border_x {
                        tile_x += 1;
                        next_border_x += self.tile_width;
                        if !self.push_tile(list, tile_x, tile_y, max) {
                        return false;
                    }
                    }
                    x += delta_x;
                }
            } else {
                let mut next_border_x = self.left_border + tile_x as f64 * self.tile_width;
                for tile_y in 0..ny {
                    if !self.push_tile(list, tile_x, tile_y, max) {
                        return false;
                    }
                    if x + delta_x < next_border_x {
                        tile_x -= 1;
                        next_border_x -= self.tile_width;
                        if !self.push_tile(list, tile_x, tile_y, max) {
                        return false;
                    }
                    }
                    x += delta_x;
                }
            }
        }
        true
    }

    fn side(&mut self, v: usize) {
        if self.vertex_tested_at[v] == self.cut {
            return;
        }
        self.vertex_tested_at[v] = self.cut;
        let c = self.coord[v];
        let lv = self.line_vector;
        let mut r = 0;
        let (wx, wy) = (c.x - self.left_line_point.x, c.y - self.left_line_point.y);
        if wx * lv.y - wy * lv.x < 0.0 {
            r = -1;
        }
        let (wx, wy) = (c.x - self.right_line_point.x, c.y - self.right_line_point.y);
        if wx * lv.y - wy * lv.x > 0.0 {
            r = 1;
        }
        self.reserved[v] = r;
    }

    fn edge_intersection(&mut self, e: usize) -> bool {
        if self.edge[e].tested_at == self.cut {
            return self.edge[e].is_intersected;
        }
        self.edge[e].tested_at = self.cut;
        let [v0, v1] = self.edge[e].vertex;
        self.side(v0);
        self.side(v1);
        self.edge[e].is_intersected = false;
        let (r0, r1) = (self.reserved[v0], self.reserved[v1]);
        if (r0 >= 0 && r1 <= 0) || (r0 <= 0 && r1 >= 0) {
            const EPSILON: f64 = 0.000001;
            let p = self.coord[v0];
            let u = self.coord[v1] - p;
            let lv = self.line_vector;
            let (rx, ry, rz) = (p.x - self.line_point.x, p.y - self.line_point.y, p.z);
            let denominator = -u.x * lv.y + u.y * lv.x;
            if denominator != 0.0 {
                let d = (-lv.x * ry + lv.y * rx) / denominator;
                if d >= -EPSILON && d < 1.0 + EPSILON {
                    let edge = &mut self.edge[e];
                    edge.is_intersected = true;
                    edge.intersection.x = (lv.x * (u.y * rz - u.z * ry) + lv.y * (u.z * rx - u.x * rz)) / denominator;
                    edge.intersection.y = (-u.x * ry + u.y * rx) / denominator;
                }
            }
        }
        self.edge[e].is_intersected
    }

    /// Where triangle i crosses the cutting plane, in the plane's coordinates: (P0, P1, the triangle's normal there).
    pub fn triangle_intersection(&mut self, i: usize) -> Option<(P2, P2, P2)> {
        let [e0, e1, e2] = self.triangle_edge[i];
        let mut q = [P2::default(); 3];
        let mut n = 0;
        for e in [e0, e1, e2] {
            if self.edge_intersection(e) {
                q[n] = self.edge[e].intersection;
                n += 1;
            }
        }
        if n < 2 {
            return None;
        }
        let [v0, v1, v2] = self.triangle_vertex[i];
        let normal = cross(self.coord[v1] - self.coord[v0], self.coord[v2] - self.coord[v0]);
        let lv = self.line_vector;
        let nn = p2(normal.z, normal.x * lv.x + normal.y * lv.y);
        if n == 2 {
            return Some((q[0], q[1], nn));
        }
        let l = [(q[0] - q[1]).square_magnitude(), (q[1] - q[2]).square_magnitude(), (q[2] - q[0]).square_magnitude()];
        if l[0] >= l[1] && l[0] >= l[2] {
            Some((q[0], q[1], nn))
        } else if l[1] >= l[2] {
            Some((q[1], q[2], nn))
        } else {
            Some((q[2], q[0], nn))
        }
    }
}
