// VocalTractLab's segment sequences and its rules for making a gestural score of one (SegmentSequence.cpp, Sampa.cpp,
// GesturalScore::createFromSegmentSequence): phones in German SAMPA, each its duration, into gestures -- lung pressure
// rising before the first phone and falling before the last, modal phonation, a vowel gesture for each vowel (two for a
// diphthong), and each consonant's oral, glottal and velic gestures timed by Birkholz's rules (voice onset times from
// Klatt 1975; the diphthongs' second targets from Birkholz's study of secondary diphthongs, 2020). A plosive's or nasal's
// closing gesture and a nasal's velic gesture are placed by VocalTractLab's own search: their boundaries moved 2.5 ms at
// a time, the score's curves and the tract's geometry computed at each step, until the closure (or the port's opening)
// begins and ends where the segment says. Each expression in the C++'s order. The F0 tier is left as it was: the
// segments say nothing of pitch.
use crate::gestural::*;
use crate::inventory::{inventory, manner, phone, Kind, Manner};
use crate::rules::rules23;
use crate::tract::{VocalTract, VO};
use crate::tube::{self, Articulator, Tube};

// (The phones and their classes are languages/phones.json's, src/inventory.rs; the rules' numbers languages/rules-2.3.json.)
fn kind_is(s: &str, kind: Kind) -> bool {
    phone(s).is_some_and(|p| p.kind == kind)
}
fn manner_is(s: &str, manners: &[Manner]) -> bool {
    manner(s).is_some_and(|m| manners.contains(&m))
}

/// The phones the rules make that are one sound -- the vowels and the consonants, not the diphthongs.
pub fn single_phones() -> impl Iterator<Item = &'static str> {
    inventory().phones.iter().filter(|(_, p)| p.kind != Kind::Diphthong).map(|(n, _)| n.as_str())
}

/// A vowel or a glide: a phone made one vowel gesture.
pub fn is_vowel(s: &str) -> bool {
    phone(s).is_some_and(|p| p.vowel_shape().is_some())
}

/// A vowel's or glide's shape on a speaker (`has`: whether it has a shape of that name): its own, else, where the
/// speaker has no shape of it (a phone learned from a corpus), its sound's nearest phone's (src/phones.rs).
pub fn vowel_shape_on(name: &str, has: impl Fn(&str) -> bool) -> Option<&'static str> {
    let own = phone(name)?.vowel_shape()?;
    if has(own) {
        return Some(own);
    }
    crate::phones::nearest_phone(name).and_then(|n| phone(n)).and_then(|p| p.vowel_shape()).filter(|s| has(s)).or(Some(own))
}
pub fn is_diphthong(s: &str) -> bool {
    kind_is(s, Kind::Diphthong)
}
pub fn is_phoneme(s: &str) -> bool {
    phone(s).is_some()
}
pub fn is_fricative(s: &str) -> bool {
    manner_is(s, &[Manner::Fricative, Manner::GlottalFricative])
}
pub fn is_plosive(s: &str) -> bool {
    manner_is(s, &[Manner::Plosive, Manner::GlottalStop])
}
/// A plosive made in the mouth with the glottis open (VocalTractLab's /p t k/).
pub fn is_voiceless_oral_plosive(s: &str) -> bool {
    manner_is(s, &[Manner::Plosive]) && !is_voiced(s)
}
pub fn is_affricate(s: &str) -> bool {
    manner_is(s, &[Manner::Affricate])
}
pub fn is_lateral(s: &str) -> bool {
    manner_is(s, &[Manner::Lateral])
}
pub fn is_alveolar(s: &str) -> bool {
    phone(s).is_some_and(|p| p.alveolar)
}
pub fn makes_postalveolar(s: &str) -> bool {
    phone(s).is_some_and(|p| p.makes_postalveolar)
}
pub fn is_voiced(s: &str) -> bool {
    phone(s).is_some_and(|p| p.kind != Kind::Consonant || p.voiced == Some(true))
}

/// Phones beyond the speaker's German, as a language's data declares them (languages/*.json, read by
/// speech2vocaltract.rs): a vowel made a vowel gesture to a shape of its own, a plosive made by another plosive's rule
/// with a voice onset time of its own. German's phones are made as they were, whatever is declared here.
#[derive(Clone, Debug, Default)]
pub struct Extra {
    /// Each vowel's symbol and the name of the speaker's shape its gesture approaches.
    pub vowels: Vec<(String, String)>,
    /// Each plosive's symbol, the speaker's plosive whose rule makes it, and its voice onset time (s; its base's where
    /// none is given).
    pub plosives: Vec<(String, String, Option<f64>)>,
    /// Each diphthong's symbol and the shapes of its two vowel gestures, where the language's are not the rules'.
    pub diphthongs: Vec<(String, String, String)>,
    /// Whether those diphthongs are made as two vowels, each half the diphthong's length, not by the diphthong's rule.
    pub diphthongs_as_vowels: bool,
    /// Each affricate's plosive's share of its length, where the language's is not the rules'.
    pub affricates: Vec<(String, f64)>,
    /// Phones an engine knew as phones but made no gesture for: a pause to every rule but the breath's and the voice's,
    /// which begin with the first phone and end with the last (VocalTractLab skips only an empty segment when it finds
    /// them), so that the lungs' pressure falls 50 ms past such a phone at a sentence's end, and a consonant after one at
    /// its start is not the first phone.
    pub gestureless: Vec<String>,
}

impl Extra {
    pub fn diphthong(&self, s: &str) -> Option<(&str, &str)> {
        self.diphthongs.iter().find(|(d, _, _)| d == s).map(|(_, a, b)| (a.as_str(), b.as_str()))
    }

    /// Whether the language makes a phone a vowel gesture or two beyond the speaker's.
    pub fn is_vowel(&self, s: &str) -> bool {
        self.vowel_shape(s).is_some() || self.diphthong(s).is_some()
    }

    pub fn vowel_shape(&self, s: &str) -> Option<&str> {
        self.vowels.iter().find(|(v, _)| v == s).map(|(_, shape)| shape.as_str())
    }

    pub fn plosive(&self, s: &str) -> Option<(&str, Option<f64>)> {
        self.plosives.iter().find(|(p, _, _)| p == s).map(|(_, base, vot)| (base.as_str(), *vot))
    }
}

/// One phone: its SAMPA name ("" a pause), its duration, and its other labels as read (start_of_syllable, word_accent,
/// phrase_accent, pitch_target_offset_st, ...).
#[derive(Clone, Debug, Default)]
pub struct Segment {
    pub name: String,
    pub duration_s: f64,
    pub labels: Vec<(String, String)>,
}

impl Segment {
    pub fn label(&self, key: &str) -> Option<&str> {
        self.labels.iter().find(|(k, _)| k == key).map(|(_, v)| v.as_str())
    }
}

/// A .seg file: a line a segment, "key = value; key = value; ...".
pub fn parse_segments(text: &str) -> Vec<Segment> {
    let mut out = Vec::new();
    for line in text.lines() {
        let mut seg = Segment::default();
        let mut pairs = 0;
        for part in line.split(';') {
            let Some((k, v)) = part.split_once('=') else { continue };
            let (k, v) = (k.trim_start_matches([' ', '\t']).trim_end_matches(' '), v.trim_start_matches([' ', '\t']).trim_end_matches(' '));
            if k.is_empty() || v.is_empty() {
                continue;
            }
            pairs += 1;
            match k {
                "name" => seg.name = v.to_string(),
                "duration_s" => seg.duration_s = atof(v),
                _ => seg.labels.push((k.to_string(), v.to_string())),
            }
        }
        if pairs > 0 {
            out.push(seg);
        }
    }
    out
}

/// C's atof: the longest leading number, 0 where none.
pub(crate) fn atof(s: &str) -> f64 {
    let s = s.trim_start();
    let mut end = 0;
    for i in (1..=s.len()).rev() {
        if s.is_char_boundary(i) && s[..i].parse::<f64>().is_ok() {
            end = i;
            break;
        }
    }
    if end == 0 { 0.0 } else { s[..end].parse().unwrap() }
}

/// A consonant's tier: its primary articulator's (the glottis's for /h/ and the glottal stop).
pub(crate) fn tier_of(a: Option<crate::inventory::Articulator>) -> usize {
    use crate::inventory::Articulator as A;
    match a {
        Some(A::Lips) => LIP,
        Some(A::TongueTip) => TONGUE_TIP,
        Some(A::TongueBody) => TONGUE_BODY,
        _ => GLOTTAL_SHAPE,
    }
}

fn gesture(duration_s: f64, d_val: f64, s_val: &str, tau_s: f64) -> Gesture {
    Gesture { duration_s, d_val, slope: 0.0, s_val: s_val.to_string(), tau_s, neutral: false }
}

impl GesturalScore {
    /// The score for a segment sequence, as VocalTractLab makes it (createFromSegmentSequence); its F0 tier kept. The
    /// tract is the speaker's, its geometry computed by the searches (and its carried incisor position with it, as the
    /// C++'s shared vocal tract's).
    pub fn from_segments(&mut self, original: &[Segment], vt: &mut VocalTract) {
        self.from_segments_with(original, vt, &Extra::default());
    }

    /// The same, with a language's phones beyond the speaker's: an extra plosive is made by its base's rule (and is its
    /// base to its neighbours' rules) but for its voice onset time; an extra vowel is a vowel to its own shape, a
    /// diphthong two to the shapes it names.
    pub fn from_segments_with(&mut self, original: &[Segment], vt: &mut VocalTract, extra: &Extra) {
        let min_d = MIN_GESTURE_DURATION_S;
        let r = rules23();
        for k in [VOWEL, LIP, TONGUE_TIP, TONGUE_BODY, VELIC, GLOTTAL_SHAPE, LUNG_PRESSURE] {
            self.seq[k].gestures.clear();
        }
        // Plain SAMPA: anything else a pause, the affricates split into their plosive and fricative.
        let mut segs: Vec<(String, f64)> = Vec::new();
        let mut vots: Vec<Option<f64>> = Vec::new();
        let mut gestureless: Vec<bool> = Vec::new();
        for o in original {
            let (n, d) = (o.name.as_str(), o.duration_s);
            if let Some((base, vot)) = extra.plosive(n) {
                segs.push((base.to_string(), d));
                vots.push(vot);
                continue;
            }
            // (A phone the authors' engine made no gesture for is made none, whatever the inventory's phone of its name.)
            let none = extra.gestureless.iter().any(|g| g == n);
            if let (true, Some((a, b))) = (extra.diphthongs_as_vowels, extra.diphthong(n)) {
                segs.push((a.to_string(), d / 2.0));
                vots.push(None);
                segs.push((b.to_string(), d / 2.0));
            } else if !none && extra.is_vowel(n) {
                segs.push((n.to_string(), d));
            } else if let (false, Some(ph)) = (none, phone(n)) {
                if let (Some(Manner::Affricate), Some([a, b]), Some(share)) = (ph.manner, &ph.parts, ph.plosive_share) {
                    // (The plosive's share measured in Birkholz's recordings.)
                    let ratio = extra.affricates.iter().find(|(a, _)| a == n).map(|(_, r)| *r).unwrap_or(share);
                    if ratio > 0.0 {
                        segs.push((a.clone(), ratio * d));
                    }
                    if ratio < 1.0 {
                        segs.push((b.clone(), (1.0 - ratio) * d));
                    }
                } else {
                    segs.push((n.to_string(), d));
                }
            } else {
                gestureless.resize(segs.len(), false);
                segs.push((String::new(), d));
                gestureless.push(none);
            }
            vots.resize(segs.len(), None);
        }
        gestureless.resize(segs.len(), false);
        let n = segs.len();
        let name = |i: i64| -> &str {
            if i >= 0 && (i as usize) < n {
                segs[i as usize].0.as_str()
            } else {
                ""
            }
        };
        let mut begin = vec![0.0; n];
        let mut end = vec![0.0; n];
        let mut t = 0.0;
        for i in 0..n {
            begin[i] = t;
            t += segs[i].1;
            end[i] = t;
        }
        let total = t;
        // /d t n l/ next to /S Z/ in a cluster are made postalveolar.
        let mut postalveolar = vec![false; n];
        for i in 0..n as i64 {
            if makes_postalveolar(name(i)) {
                postalveolar[i as usize] = true;
                for dir in [-1i64, 1] {
                    for step in 1..=3 {
                        let j = i + dir * step;
                        if j >= 0 && (j as usize) < n && is_alveolar(name(j)) {
                            postalveolar[j as usize] = true;
                        } else {
                            break;
                        }
                    }
                }
            }
        }
        let (mut first_begin, mut last_end) = (1000000.0, 0.0);
        let (mut first_name, mut last_name) = ("", "");
        let (mut first_index, mut last_index) = (0usize, 0usize);
        for i in 0..n {
            if segs[i].0.is_empty() && !gestureless[i] {
                continue;
            }
            if begin[i] < first_begin {
                first_begin = begin[i];
                first_name = &segs[i].0;
                first_index = i;
            }
            if end[i] > last_end {
                last_end = end[i];
                last_name = &segs[i].0;
                last_index = i;
            }
        }
        if last_end < min_d {
            return;
        }
        // Lung pressure: from 50 ms before a first plosive (20 ms before anything else), falling 120 ms before the last
        // phone ends (90 before a final /p k/, 70 before /t/, for their bursts).
        let mut d = first_begin;
        if is_plosive(first_name) {
            d -= r.lungs.lead_before_plosive_s;
        } else {
            d -= r.lungs.lead_s;
        }
        if d < min_d {
            d = min_d;
        }
        self.seq[LUNG_PRESSURE].gestures.push(gesture(d, 0.0, "", DEFAULT_TIME_CONSTANT_S));
        let mut lung_end = last_end - r.lungs.fall_before_end_s;
        if let Some(fall) = phone(last_name).and_then(|p| p.rules.v23.as_ref()).and_then(|p| p.lungs_fall_before_end_s) {
            lung_end = last_end - fall;
        }
        let d = lung_end - self.seq[LUNG_PRESSURE].duration_s();
        if d > min_d {
            self.seq[LUNG_PRESSURE].gestures.push(gesture(d, r.lungs.pressure_dpa, "", r.lungs.onset_tau_s));
        }
        self.seq[LUNG_PRESSURE].gestures.push(gesture(r.lungs.release_s, 0.0, "", DEFAULT_TIME_CONSTANT_S));
        self.seq[GLOTTAL_SHAPE].gestures.push(gesture(last_end, 0.0, &r.phonation, DEFAULT_TIME_CONSTANT_S));
        // Vowels, and diphthongs as two.
        for i in 0..n {
            let s = segs[i].0.as_str();
            if !is_vowel(s) && !is_diphthong(s) && !extra.is_vowel(s) {
                continue;
            }
            let ph = phone(s);
            let diphthong: Option<(&str, &str)> = extra.diphthong(s).or(ph.and_then(|p| p.shapes.as_ref()).map(|[a, b]| (a.as_str(), b.as_str())));
            let vowel: Option<&str> = match ph.and_then(|p| p.vowel_shape()) {
                // (A phone learned from a corpus, on a speaker with no shape of it: the corpus's own, else its nearest's.)
                Some(own) if vt.shape(own).is_none() => extra.vowel_shape(s).or_else(|| vowel_shape_on(s, |x| vt.shape(x).is_some())),
                Some(own) => Some(own),
                None => extra.vowel_shape(s),
            };
            let tier = &mut self.seq[VOWEL];
            if let Some(v) = vowel {
                let gd = (end[i] - r.vowels.end_before_end_s) - tier.duration_s();
                if gd > min_d {
                    tier.gestures.push(gesture(gd, 0.0, v, DEFAULT_TIME_CONSTANT_S));
                }
            } else if let Some((v0, v1)) = diphthong {
                // The second target's onset lags by the diphthong's length past 130 ms, up to 70 ms (set by ear).
                let dur = tier.duration_s();
                let seg_d = end[i] - begin[i];
                let mut lag = 0.0;
                if seg_d > r.vowels.diphthong_lag_after_s {
                    lag = seg_d - r.vowels.diphthong_lag_after_s;
                    if lag > r.vowels.diphthong_lag_most_s {
                        lag = r.vowels.diphthong_lag_most_s;
                    }
                }
                let gd = (begin[i] + lag) - dur;
                if gd > min_d {
                    tier.gestures.push(gesture(gd, 0.0, v0, DEFAULT_TIME_CONSTANT_S));
                }
                let gd = (end[i] - r.vowels.end_before_end_s) - tier.duration_s();
                if gd > min_d {
                    tier.gestures.push(gesture(gd, 0.0, v1, DEFAULT_TIME_CONSTANT_S));
                }
            }
        }
        let gd = total - self.seq[VOWEL].duration_s();
        if gd > min_d {
            self.seq[VOWEL].gestures.push(gesture(gd, 0.0, &r.neutral_vowel, DEFAULT_TIME_CONSTANT_S));
        }
        // Fricatives: the oral gesture and the glottis's, 57 ms early (so the glottis is as open at both ends). (A phone
        // a language makes a vowel is a vowel to its neighbours too.)
        let fricative = |x: &str| is_fricative(x) && !extra.is_vowel(x);
        for i in 0..n {
            let s = segs[i].0.as_str();
            if extra.is_vowel(s) {
                continue;
            }
            let Some(ph) = phone(s).filter(|p| p.manner == Some(Manner::Fricative)) else { continue };
            // (/j/'s glottis modal: a voiced fricative's glottis makes its noise too strong.)
            let (tier, oral, glottal) = (tier_of(ph.articulator), ph.oral.as_deref().unwrap_or(""), ph.glottal.as_deref().unwrap_or(""));
            let f = &r.fricatives;
            let mut oral_begin = begin[i] - f.early_s - f.oral_lead_s;
            let oral_end = end[i] - f.early_s + f.oral_held_s;
            if is_voiced(s) {
                oral_begin = begin[i] - f.early_s - f.oral_lead_voiced_s;
            }
            if i == first_index {
                oral_begin = 0.0;
            }
            self.seq[tier].put(gesture(oral_end - oral_begin, 0.0, oral, DEFAULT_TIME_CONSTANT_S), oral_begin);
            let mut glottal_begin = begin[i] - f.early_s;
            let mut glottal_end = end[i] - f.early_s;
            if i == first_index {
                glottal_begin = 0.0;
            }
            let next = name(i as i64 + 1);
            if !is_voiced(s) && is_voiceless_oral_plosive(next) {
                glottal_end += f.glottis_held_before_voiceless_plosive_s;
            }
            if glottal_end >= glottal_begin + min_d {
                self.seq[GLOTTAL_SHAPE].put(gesture(glottal_end - glottal_begin, 0.0, glottal, DEFAULT_TIME_CONSTANT_S), glottal_begin);
            }
        }
        // Plosives, nasals, the lateral, /h/ and the glottal stop, after the vowels and fricatives: their closures are
        // placed against the curves those make.
        let mut prev_oral = String::new();
        for i in 0..n {
            let s = segs[i].0.as_str();
            let prev = name(i as i64 - 1);
            let next = name(i as i64 + 1);
            let mut oral = String::new();
            let mut plosive: Option<(usize, &str, f64)> = None;
            let mut nasal: Option<usize> = None;
            let ph = phone(s);
            // (Voice onset times from Klatt 1975, "Voice onset time, frication, and aspiration in word-initial
            // consonant clusters", languages/phones.json.)
            if let Some(ph) = ph {
                let closure = match (&ph.closure_postalveolar, &ph.closure) {
                    (Some(c), _) if postalveolar[i] => c.clone(),
                    (_, Some(c)) => c.clone(),
                    _ => String::new(),
                };
                match ph.manner {
                    Some(Manner::Plosive) => {
                        oral = closure;
                        let v = ph.rules.v23.as_ref().expect("a plosive's 2.3 numbers");
                        let vot = match (fricative(next), v.vot_before_fricative_s) {
                            (true, Some(before)) => before,
                            _ => v.vot_s.unwrap_or(0.0),
                        };
                        plosive = Some((tier_of(ph.articulator), ph.glottal.as_deref().unwrap_or(""), vot));
                    }
                    Some(Manner::Nasal) => {
                        oral = closure;
                        nasal = Some(tier_of(ph.articulator));
                    }
                    _ => {}
                }
            }
            if let (Some((tier, glottal, _)), Some(vot)) = (plosive, vots[i]) {
                plosive = Some((tier, glottal, vot));
            }
            if let Some((tier, glottal, vot)) = plosive {
                let mut closure_begin = begin[i];
                let mut closure_end = end[i] - vot;
                if i == first_index {
                    closure_begin = 0.0;
                } else {
                    // (The closure at least half the segment and 20 ms.)
                    let seg_d = end[i] - begin[i];
                    if closure_end - closure_begin < r.plosives.closure_least_share * seg_d {
                        closure_end = closure_begin + r.plosives.closure_least_share * seg_d;
                    }
                    if closure_end - closure_begin < r.plosives.closure_least_s {
                        closure_end = closure_begin + r.plosives.closure_least_s;
                    }
                }
                let mut glottal_begin = closure_begin - r.plosives.glottis_lead_s;
                let mut glottal_end = end[i] - r.plosives.glottis_end_before_end_s;
                if i == first_index {
                    glottal_begin = 0.0;
                }
                if fricative(next) && is_voiced(next) {
                    glottal_end -= r.plosives.glottis_shortened_before_voiced_fricative_s;
                }
                // (Released into a homorganic nasal or lateral: at the segment's end, the glottis's gesture much shorter.)
                let ph = ph.expect("a plosive's phone");
                if ph.released_into.iter().any(|x| x == next) {
                    closure_end = end[i];
                    glottal_end = end[i] - r.plosives.released_glottis_end_before_end_s;
                }
                if is_lateral(next) && ph.lateral_release {
                    glottal_end = end[i] - r.plosives.lateral_release_glottis_end_before_end_s;
                }
                let connect = oral == prev_oral;
                self.add_closing_gesture(vt, tier, &oral, closure_begin, closure_end, connect);
                // (A final voiceless plosive's glottis held open 100 ms more, for its burst.)
                if i == last_index && !is_voiced(s) {
                    glottal_end += r.plosives.final_voiceless_glottis_held_s;
                }
                if glottal_end - glottal_begin < min_d {
                    glottal_end = glottal_begin + min_d;
                }
                self.seq[GLOTTAL_SHAPE].put(gesture(glottal_end - glottal_begin, 0.0, glottal, DEFAULT_TIME_CONSTANT_S), glottal_begin);
            } else if let Some(tier) = nasal {
                let (closure_begin, closure_end) = (begin[i], end[i]);
                let v = &r.nasals;
                let mut velic_begin = begin[i] - v.velic_lead_s;
                let mut velic_end = end[i] + v.velic_held_s;
                if is_plosive(prev) {
                    velic_begin = begin[i] - v.velic_lead_after_plosive_s;
                }
                if is_plosive(next) {
                    velic_end = end[i];
                }
                if fricative(prev) {
                    velic_begin = begin[i] - v.velic_beside_fricative_s;
                }
                if fricative(next) {
                    velic_end = end[i] + v.velic_beside_fricative_s;
                }
                if is_lateral(prev) {
                    velic_begin = begin[i] - v.velic_lead_after_lateral_s;
                }
                if is_lateral(next) {
                    velic_end = end[i] + v.velic_held_before_lateral_s;
                }
                let connect = oral == prev_oral;
                self.add_closing_gesture(vt, tier, &oral, closure_begin, closure_end, connect);
                self.add_velic_opening_gesture(vt, velic_begin, velic_end);
            }
            let glottal_shape = || ph.and_then(|p| p.glottal.as_deref()).unwrap_or("");
            match ph.and_then(|p| p.manner) {
                Some(Manner::GlottalFricative) => {
                    let (b, e) = (begin[i] - r.glottal.lead_s, end[i] - r.glottal.lead_s);
                    self.seq[GLOTTAL_SHAPE].put(gesture(e - b, 0.0, glottal_shape(), DEFAULT_TIME_CONSTANT_S), b);
                }
                Some(Manner::GlottalStop) => {
                    let mut b = begin[i] - r.glottal.lead_s;
                    let e = end[i] - r.glottal.lead_s;
                    if i == first_index {
                        b = 0.0;
                    }
                    self.seq[GLOTTAL_SHAPE].put(gesture(e - b, 0.0, glottal_shape(), DEFAULT_TIME_CONSTANT_S), b);
                }
                Some(Manner::Lateral) => {
                    // (A little longer than the segment, and earlier.)
                    let ph = ph.unwrap();
                    let b = begin[i] - r.lateral.early_s - r.lateral.lead_s;
                    let e = end[i] - r.lateral.early_s;
                    let lateral = match (&ph.oral_postalveolar, &ph.oral) {
                        (Some(o), _) if postalveolar[i] => o.as_str(),
                        (_, Some(o)) => o.as_str(),
                        _ => "",
                    };
                    self.seq[tier_of(ph.articulator)].put(gesture(e - b, 0.0, lateral, DEFAULT_TIME_CONSTANT_S), b);
                }
                _ => {}
            }
            prev_oral = oral;
        }
    }

    /// A closing gesture placed so the closure begins and ends at the times given (addClosingGesture): its start moved
    /// earlier 2.5 ms at a time until the tract is closed at the closure's beginning (or, connected, the end of the
    /// tier's last gesture), then its end moved until the closure ends where asked.
    fn add_closing_gesture(&mut self, vt: &mut VocalTract, tier: usize, name: &str, closure_begin: f64, mut closure_end: f64, connect: bool) {
        const STEP: f64 = 1.0 / CURVE_SAMPLING_RATE as f64;
        let c = &rules23().closing;
        let max_d = c.longest_gesture_s;
        if closure_end < closure_begin + c.min_closure_s {
            closure_end = closure_begin + c.min_closure_s;
        }
        let mut gb = closure_begin - c.start_before_closure_s;
        let mut ge = closure_begin;
        if connect {
            let seq = &self.seq[tier];
            let mut prev: i64 = -1;
            let mut end = 0.0;
            for (i, g) in seq.gestures.iter().enumerate() {
                end += g.duration_s;
                if !g.neutral && end < closure_begin {
                    prev = i as i64;
                }
            }
            if prev != -1 {
                gb = seq.gestures[..=prev as usize].iter().fold(0.0, |t, g| t + g.duration_s);
            }
        }
        let mut closed = false;
        let mut error = false;
        if gb <= 0.0 {
            gb = 0.0;
            closed = true;
        }
        while !connect && !closed && !error {
            gb -= STEP;
            closed = self.has_closure(vt, tier, name, gb, ge, closure_begin);
            if gb < c.earliest_start_s || ge - gb > max_d {
                if ge - gb > max_d {
                    gb = closure_begin - c.start_before_closure_s;
                }
                error = true;
            }
        }
        closed = self.has_closure(vt, tier, name, gb, ge, closure_end);
        if closed {
            let (mut onset, mut offset, mut short) = (true, true, false);
            while onset && offset && !short {
                ge -= STEP;
                onset = self.has_closure(vt, tier, name, gb, ge, closure_begin);
                offset = self.has_closure(vt, tier, name, gb, ge, closure_end);
                if ge - gb < c.shortest_gesture_s {
                    short = true;
                }
            }
            if !onset || short {
                ge += STEP;
            }
        } else {
            error = false;
            while !closed && !error {
                ge += STEP;
                closed = self.has_closure(vt, tier, name, gb, ge, closure_end);
                if ge - gb > max_d {
                    ge = gb + c.shortest_gesture_s;
                    error = true;
                }
            }
        }
        self.seq[tier].put(gesture(ge - gb, 0.0, name, DEFAULT_TIME_CONSTANT_S), gb);
    }

    /// Whether, with the gesture put in its tier, the tract at `at` is closed by the tier's articulator: the lower lip,
    /// the tongue within 2.2 cm of its tip, or the tongue behind that (hasVocalTactClosure).
    fn has_closure(&mut self, vt: &mut VocalTract, tier: usize, name: &str, gb: f64, ge: f64, at: f64) -> bool {
        let stored = self.seq[tier].gestures.clone();
        self.seq[tier].put(gesture(ge - gb, 0.0, name, DEFAULT_TIME_CONSTANT_S), gb);
        let params = self.tract_params_at(vt, at);
        self.seq[tier].gestures = stored;
        vt.calculate(&params);
        let geometry = vt.tube();
        let mut t = Tube::new();
        crate::synth::tube_from_tract(&geometry, &mut t);
        let sections = &t.section[tube::FIRST_PHARYNX_SECTION..tube::FIRST_PHARYNX_SECTION + tube::NUM_PHARYNX_MOUTH_SECTIONS];
        let mut tip = 0.0;
        for ts in sections {
            if ts.articulator == Articulator::Tongue {
                tip = ts.pos_cm + ts.length_cm;
            }
        }
        let c = &rules23().closing;
        let tongue_tip_region_cm = c.tongue_tip_region_cm;
        let mut closed = false;
        for ts in sections {
            if ts.area_cm2 < c.closed_area_factor * tube::MIN_AREA_CM2 {
                let pos = ts.pos_cm + 0.5 * ts.length_cm;
                if tier == LIP && ts.articulator == Articulator::LowerLip {
                    closed = true;
                }
                if tier == TONGUE_TIP && ts.articulator == Articulator::Tongue && pos > tip - tongue_tip_region_cm {
                    closed = true;
                }
                if tier == TONGUE_BODY && ts.articulator == Articulator::Tongue && pos < tip - tongue_tip_region_cm {
                    closed = true;
                }
            }
        }
        closed
    }

    /// A velic gesture placed so the port is open from `open_begin` to `open_end` (addVelicOpeningGesture).
    fn add_velic_opening_gesture(&mut self, vt: &VocalTract, open_begin: f64, mut open_end: f64) {
        const STEP: f64 = 1.0 / CURVE_SAMPLING_RATE as f64;
        let v = &rules23().velic;
        let max_d = v.longest_gesture_s;
        if open_end < open_begin + v.min_opening_s {
            open_end = open_begin + v.min_opening_s;
        }
        // (Exact for a full opening with tau 12 ms; widened below for a smaller one.)
        let mut gb = open_begin - v.start_before_opening_s;
        let mut ge = open_end - v.end_before_opening_end_s;
        if gb <= 0.0 {
            gb = 0.0;
        }
        if ge < gb + v.min_gesture_s {
            ge = gb + v.min_gesture_s;
        }
        let mut error = false;
        let mut open = self.has_velic_opening(vt, gb, ge, open_begin);
        while !open && !error {
            gb -= STEP;
            open = self.has_velic_opening(vt, gb, ge, open_begin);
            if gb < v.earliest_start_s || ge - gb > max_d {
                if ge - gb > max_d {
                    gb = open_begin - v.start_before_opening_s;
                }
                error = true;
            }
        }
        open = self.has_velic_opening(vt, gb, ge, open_end);
        error = false;
        while !open && !error {
            ge += STEP;
            open = self.has_velic_opening(vt, gb, ge, open_end);
            if ge - gb > max_d {
                ge = gb + v.first_end_after_start_s;
                error = true;
            }
        }
        self.seq[VELIC].put(Gesture { duration_s: ge - gb, d_val: TARGET_VELIC_OPENING, slope: 0.0, s_val: String::new(), tau_s: DEFAULT_TIME_CONSTANT_S, neutral: false }, gb);
    }

    fn has_velic_opening(&mut self, vt: &VocalTract, gb: f64, ge: f64, at: f64) -> bool {
        let stored = self.seq[VELIC].gestures.clone();
        self.seq[VELIC].put(Gesture { duration_s: ge - gb, d_val: TARGET_VELIC_OPENING, slope: 0.0, s_val: String::new(), tau_s: DEFAULT_TIME_CONSTANT_S, neutral: false }, gb);
        let params = self.tract_params_at(vt, at);
        self.seq[VELIC].gestures = stored;
        // (1% of its range: minimally open.)
        params[VO] >= rules23().velic.open
    }
}
