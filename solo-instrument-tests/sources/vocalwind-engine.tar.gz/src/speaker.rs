// A speaker file (Speaker.cpp): its vocal tract's anatomy and shapes, and its glottis models, one selected. The geometric
// glottis is read here; the vocal tract by tract.rs.
use crate::glottis::{GeometricGlottis, Parameter};
use crate::xml::{self, Node};

pub struct Speaker {
    pub glottis: GeometricGlottis,
    pub root: Node,
}

/// The glottis models' parameters and shapes, as Glottis::readFromXml reads them: each named parameter's range and
/// neutral value (its value the neutral one), each shape's values over the neutral ones.
fn read_glottis(node: &Node, g: &mut GeometricGlottis) -> Result<(), String> {
    fn params(list: Option<&Node>, into: &mut [Parameter], what: &str) -> Result<(), String> {
        if let Some(list) = list {
            for p in &list.children {
                let name = p.attr("name").ok_or("a parameter without a name")?;
                let q = into.iter_mut().find(|q| q.name == name).ok_or_else(|| format!("{what} parameter {name}: not the geometric glottis's"))?;
                q.min = p.num("min")?;
                q.max = p.num("max")?;
                q.neutral = p.num("neutral")?;
                q.x = q.neutral;
            }
        }
        Ok(())
    }
    params(node.child("static_params"), &mut g.statics, "static")?;
    params(node.child("control_params"), &mut g.control, "control")?;
    if let Some(shapes) = node.child("shapes") {
        g.shapes.clear();
        for s in shapes.children_named("shape") {
            let name = s.attr("name").filter(|n| !n.is_empty()).ok_or("a glottis shape without a name")?;
            let mut values: Vec<f64> = g.control.iter().map(|p| p.neutral).collect();
            for c in s.children_named("control_param") {
                let pname = c.attr("name").ok_or("a control value without a name")?;
                let k = g.control.iter().position(|p| p.name == pname).ok_or_else(|| format!("glottis shape {name}: no parameter {pname}"))?;
                values[k] = c.num("value")?;
            }
            g.shapes.push((name.to_string(), values));
        }
    }
    g.reset_motion();
    g.calc_geometry();
    Ok(())
}

impl Speaker {
    pub fn parse(text: &str) -> Result<Speaker, String> {
        let root = xml::parse(text)?;
        if root.name != "speaker" {
            return Err(format!("<{}>: not a speaker file", root.name));
        }
        let models = root.child("glottis_models").ok_or("no glottis models")?;
        let selected = models.children.iter().find(|m| m.attr("selected").map(|s| s.trim() == "1").unwrap_or(false)).or_else(|| models.children.first()).ok_or("no glottis model")?;
        let kind = selected.attr("type").unwrap_or("");
        if kind != "Geometric glottis" {
            return Err(format!("its selected glottis is the {kind}: only the geometric glottis is ported"));
        }
        let mut glottis = GeometricGlottis::new();
        read_glottis(selected, &mut glottis)?;
        Ok(Speaker { glottis, root })
    }

    pub fn read(path: &str) -> Result<Speaker, String> {
        Speaker::parse(&std::fs::read_to_string(path).map_err(|e| format!("{path}: {e}"))?)
    }
}
