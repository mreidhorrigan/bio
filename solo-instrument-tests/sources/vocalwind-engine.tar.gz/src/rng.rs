// The time-domain model's noise, drawn as VocalTractLab draws it: std::mt19937 seeded with 10 at each reset, each sample
// a fresh std::normal_distribution -- libc++'s, as the backend is built on the Mac: Marsaglia's polar method on two
// uniform draws of (-1, 1), each from std::generate_canonical's two 32-bit words, its second value thrown away with the
// distribution (TdsModel.cpp calcNoiseSample).

/// The Mersenne Twister, MT19937 (32-bit), as the C++ standard defines it.
#[derive(Clone)]
pub struct Mt19937 {
    mt: [u32; 624],
    index: usize,
}

impl Mt19937 {
    pub fn new(seed: u32) -> Self {
        let mut g = Mt19937 { mt: [0; 624], index: 624 };
        g.seed(seed);
        g
    }

    pub fn seed(&mut self, seed: u32) {
        self.mt[0] = seed;
        for i in 1..624 {
            let prev = self.mt[i - 1];
            self.mt[i] = 1812433253u32.wrapping_mul(prev ^ (prev >> 30)).wrapping_add(i as u32);
        }
        self.index = 624;
    }

    fn twist(&mut self) {
        for i in 0..624 {
            let y = (self.mt[i] & 0x8000_0000) | (self.mt[(i + 1) % 624] & 0x7fff_ffff);
            let mut v = self.mt[(i + 397) % 624] ^ (y >> 1);
            if y & 1 != 0 {
                v ^= 0x9908_b0df;
            }
            self.mt[i] = v;
        }
        self.index = 0;
    }

    pub fn next_u32(&mut self) -> u32 {
        if self.index >= 624 {
            self.twist();
        }
        let mut y = self.mt[self.index];
        self.index += 1;
        y ^= y >> 11;
        y ^= (y << 7) & 0x9d2c_5680;
        y ^= (y << 15) & 0xefc6_0000;
        y ^= y >> 18;
        y
    }

    /// std::generate_canonical<double, 53>: two words, the first the low.
    pub fn canonical(&mut self) -> f64 {
        let rp = 4294967296.0;
        let mut sp = self.next_u32() as f64;
        sp += self.next_u32() as f64 * rp;
        sp / (rp * rp)
    }

    /// std::uniform_real_distribution<double>(-1, 1).
    pub fn uniform_pm1(&mut self) -> f64 {
        (1.0 - (-1.0)) * self.canonical() + (-1.0)
    }

    /// libc++'s polar method: two standard normal values from one accepted pair of uniform draws.
    pub fn polar_pair(&mut self) -> (f64, f64) {
        loop {
            let u = self.uniform_pm1();
            let v = self.uniform_pm1();
            let s = u * u + v * v;
            if s > 1.0 || s == 0.0 {
                continue;
            }
            let fp = (-2.0 * s.ln() / s).sqrt();
            return (u * fp, v * fp);
        }
    }

    /// A fresh std::normal_distribution<double>(0, stddev), drawn once.
    pub fn normal(&mut self, stddev: f64) -> f64 {
        NormalDistribution::new(stddev).sample(self)
    }
}

/// std::normal_distribution<double>(0, stddev) as libc++ keeps it: the second value of each pair held for its next draw.
pub struct NormalDistribution {
    stddev: f64,
    hot: Option<f64>,
}

impl NormalDistribution {
    pub fn new(stddev: f64) -> Self {
        NormalDistribution { stddev, hot: None }
    }
    pub fn sample(&mut self, g: &mut Mt19937) -> f64 {
        let up = match self.hot.take() {
            Some(v) => v,
            None => {
                let (u, v) = g.polar_pair();
                self.hot = Some(v);
                u
            }
        };
        up * self.stddev + 0.0
    }
}

#[cfg(test)]
mod tests {
    use super::Mt19937;
    #[test]
    fn the_standards_ten_thousandth() {
        // (The C++ standard's check: the 10000th output of a default-seeded mt19937 is 4123659995.)
        let mut g = Mt19937::new(5489);
        let mut x = 0;
        for _ in 0..10000 {
            x = g.next_u32();
        }
        assert_eq!(x, 4123659995);
    }
}
