// Enough XML to read VocalTractLab's speaker files (XmlNode.cpp's use of them): elements with attributes and children,
// comments and declarations skipped, text ignored. Numbers are read as C's strtod reads them (both round correctly).

#[derive(Debug, Clone, Default)]
pub struct Node {
    pub name: String,
    pub attributes: Vec<(String, String)>,
    pub children: Vec<Node>,
}

impl Node {
    pub fn attr(&self, key: &str) -> Option<&str> {
        self.attributes.iter().find(|(k, _)| k == key).map(|(_, v)| v.as_str())
    }
    pub fn num(&self, key: &str) -> Result<f64, String> {
        let v = self.attr(key).ok_or_else(|| format!("<{}>: no attribute {key}", self.name))?;
        v.trim().parse::<f64>().map_err(|e| format!("<{}> {key}=\"{v}\": {e}", self.name))
    }
    pub fn child(&self, name: &str) -> Option<&Node> {
        self.children.iter().find(|c| c.name == name)
    }
    pub fn children_named<'a>(&'a self, name: &'a str) -> impl Iterator<Item = &'a Node> + 'a {
        self.children.iter().filter(move |c| c.name == name)
    }
}

/// The document's root element.
pub fn parse(text: &str) -> Result<Node, String> {
    let b = text.as_bytes();
    let mut stack: Vec<Node> = vec![Node { name: "#document".into(), ..Node::default() }];
    let mut i = 0;
    while i < b.len() {
        if b[i] != b'<' {
            i += 1;
            continue;
        }
        if text[i..].starts_with("<!--") {
            i = text[i..].find("-->").map(|k| i + k + 3).ok_or("an unclosed comment")?;
            continue;
        }
        if text[i..].starts_with("<?") || text[i..].starts_with("<!") {
            i = text[i..].find('>').map(|k| i + k + 1).ok_or("an unclosed declaration")?;
            continue;
        }
        let end = text[i..].find('>').map(|k| i + k).ok_or("an unclosed tag")?;
        let tag = &text[i + 1..end];
        i = end + 1;
        if let Some(name) = tag.strip_prefix('/') {
            let node = stack.pop().ok_or("an unmatched closing tag")?;
            if node.name != name.trim() {
                return Err(format!("</{}> closes <{}>", name.trim(), node.name));
            }
            stack.last_mut().ok_or("an unmatched closing tag")?.children.push(node);
            continue;
        }
        let self_closing = tag.trim_end().ends_with('/');
        let tag = tag.trim_end().trim_end_matches('/');
        let mut node = Node::default();
        let name_end = tag.find(|c: char| c.is_whitespace()).unwrap_or(tag.len());
        node.name = tag[..name_end].to_string();
        let mut rest = &tag[name_end..];
        loop {
            rest = rest.trim_start();
            if rest.is_empty() {
                break;
            }
            let eq = rest.find('=').ok_or_else(|| format!("<{}>: an attribute without a value", node.name))?;
            let key = rest[..eq].trim().to_string();
            rest = rest[eq + 1..].trim_start();
            let quote = rest.chars().next().ok_or("an attribute without a value")?;
            if quote != '"' && quote != '\'' {
                return Err(format!("<{}> {key}: an unquoted value", node.name));
            }
            let close = rest[1..].find(quote).ok_or("an unclosed attribute")? + 1;
            node.attributes.push((key, rest[1..close].to_string()));
            rest = &rest[close + 1..];
        }
        if self_closing {
            stack.last_mut().unwrap().children.push(node);
        } else {
            stack.push(node);
        }
    }
    let mut doc = stack.pop().ok_or("no document")?;
    if !stack.is_empty() {
        return Err(format!("<{}> is not closed", doc.name));
    }
    doc.children.pop().ok_or_else(|| "no root element".to_string())
}
