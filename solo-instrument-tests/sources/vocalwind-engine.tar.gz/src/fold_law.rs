//! The fold law (design C of .claude/handoffs/trunk-vocalwind.md; the owner, 16 November 2026: "Yes, proceed with
//! design C"): the modal shape's three controls of the Geometric glottis 2025 -- its relative amplitude, phase lag and
//! pulse shape -- read at each moment from the pitch and the lung pressure over the threshold at that pitch, from the
//! table the fold fit made for each speaker (native/vocaltract/fold-fit.mjs: the level 8.5 dB a doubling of the
//! pressure over threshold, Titze & Sundberg 1992; their open quotient; Sundberg & Nordenberg 2006's alpha), so that a
//! soft note is soft and a loud one loud and bright where 2.4's glottis swings its folds alike at every pressure.
//! voices/fold-law.json (written by fold-law.mjs from the fit's results); the threshold Titze & Sundberg's,
//! voices/measured-singing.json `threshold`. Between the fitted points straight along each pitch's pressures, in the log
//! of the pressure over threshold, then straight between the pitches (MIDI), the relative amplitude in dB as the fit
//! moved it; held at the nearest beyond them, no reach. The speakers' weighed by a body's blend, as its other values
//! are. A phrase's controls take it as far as the glottis is in its modal shape (`apply`), so that a consonant's
//! glottis keeps its own. Off unless asked (vtl-stream foldlaw=SPEAKER:WEIGHT,...): no default until it is heard.
//!
//! The sung folds (17 November 2026; the owner, of the singers' "ooo": "if you can trace the buzz, yes, do so";
//! "You also have access to fitting tools that you can fork and adapt"): the same law made again by the source fit
//! (native/vocaltract/source-fit.mjs) on a glottis that holds its folds apart as a singer's are at each effort
//! (Glottis2025::sung) and meets softly (Glottis2025::contact_cm), its folds' rest gap closed and the chink behind
//! them a fourth control -- voices/sung-folds.json (written by sung-folds.mjs), asked by vtl-stream
//! sungfolds=SPEAKER:WEIGHT,... (`read_sung`): the table's four controls, each speaker's gap and contact softness,
//! and the open quotient's law, a body's its speakers' weighed.

use crate::v24::glottis::{SungFolds, CHINK_AREA, FREQUENCY, LOWER_END_X, PHASE_LAG, PRESSURE, PULSE_SHAPE, RELATIVE_AMPLITUDE, UPPER_END_X};
use serde_json::Value;

/// The controls the law gives, in the glottis's order: relative amplitude, phase lag, pulse shape.
pub const CONTROLS: [usize; 3] = [RELATIVE_AMPLITUDE, PHASE_LAG, PULSE_SHAPE];
/// The least relative amplitude the fit moved to (fold-fit.mjs RANGES, 40 dB under the folds' full swing).
const LEAST_DB: f64 = -40.0;

/// A pitch's fitted points: their pressures over threshold (logs) and each one's controls (the amplitude in dB; the
/// fourth the chink, the sung folds' alone).
struct Pitch {
    midi: f64,
    over: Vec<f64>,
    shapes: Vec<[f64; 4]>,
}

/// A speaker's table and its threshold's law; the sung folds' rest gap, contact softness and open quotient's k2.
struct Table {
    pitches: Vec<Pitch>,
    kpa: [f64; 2],
    f0_mean_hz: f64,
    sung: Option<Sung>,
}

/// What the sung folds add to a speaker's table.
#[derive(Clone, Copy)]
struct Sung {
    gap_cm: f64,
    contact_cm: f64,
    k2: f64,
}

/// The law for a body: its speakers' tables and their weights (summing to 1).
pub struct FoldLaw {
    speakers: Vec<(String, f64, Table)>,
}

fn voices_file(name: &str) -> Result<Value, String> {
    let path = format!("{}/voices/{name}", crate::home());
    let text = std::fs::read_to_string(&path).map_err(|e| format!("{path}: {e}"))?;
    serde_json::from_str(&text).map_err(|e| format!("{path}: {e}"))
}

fn numbers(v: &Value) -> Option<Vec<f64>> {
    v.as_array()?.iter().map(|x| x.as_f64()).collect()
}

/// Where `x` falls along `grid` (ascending): the point before it and how far toward the next (0 to 1), held at the ends.
fn place(grid: &[f64], x: f64) -> (usize, f64) {
    let n = grid.len();
    if n < 2 || x <= grid[0] {
        return (0, 0.0);
    }
    if x >= grid[n - 1] {
        return (n - 2, 1.0);
    }
    let i = grid.windows(2).position(|w| x < w[1]).unwrap_or(n - 2);
    (i, (x - grid[i]) / (grid[i + 1] - grid[i]))
}

fn between(a: [f64; 4], b: [f64; 4], s: f64) -> [f64; 4] {
    std::array::from_fn(|k| a[k] + s * (b[k] - a[k]))
}

impl Pitch {
    fn at(&self, over: f64) -> [f64; 4] {
        let (j, s) = place(&self.over, over);
        between(self.shapes[j], self.shapes[(j + 1).min(self.shapes.len() - 1)], s)
    }
}

impl Table {
    /// The phonation threshold at `f0_hz` (dPa): Titze & Sundberg 1992's eq. (37).
    fn threshold_dpa(&self, f0_hz: f64) -> f64 {
        (self.kpa[0] + self.kpa[1] * (f0_hz / self.f0_mean_hz).powi(2)) * 1e4
    }

    /// The controls at `f0_hz` and a lung pressure of `pressure_dpa`, the relative amplitude as a factor.
    fn at(&self, f0_hz: f64, pressure_dpa: f64) -> [f64; 4] {
        let f0 = f0_hz.max(1.0);
        let midi = 69.0 + 12.0 * (f0 / 440.0).log2();
        let over = (pressure_dpa.max(1e-6) / self.threshold_dpa(f0)).ln();
        let grid: Vec<f64> = self.pitches.iter().map(|p| p.midi).collect();
        let (i, s) = place(&grid, midi);
        let near = self.pitches[i].at(over);
        let far = self.pitches[(i + 1).min(self.pitches.len() - 1)].at(over);
        let mut out = between(near, far, s);
        out[0] = 10f64.powf(out[0] / 20.0);
        out
    }
}

impl FoldLaw {
    /// The law for a body of `weights`, SPEAKER:WEIGHT,... (each a speaker voices/fold-law.json has), the weights taken
    /// over their sum.
    pub fn read(weights: &str) -> Result<FoldLaw, String> {
        FoldLaw::read_from("fold-law.json", "foldlaw", weights)
    }

    /// The sung folds' law for a body of `weights` (voices/sung-folds.json): its table's four controls, each speaker's
    /// rest gap and contact softness, the open quotient's law.
    pub fn read_sung(weights: &str) -> Result<FoldLaw, String> {
        FoldLaw::read_from("sung-folds.json", "sungfolds", weights)
    }

    fn read_from(name: &str, switch: &str, weights: &str) -> Result<FoldLaw, String> {
        let law = voices_file(name)?;
        // (the sung folds': four controls a shape, a gap and a contact softness a speaker, the open quotient's k2 a voice)
        let sung = law["openQuotient"].is_object();
        let measured = voices_file("measured-singing.json")?;
        let threshold = &measured["threshold"];
        let kpa = numbers(&threshold["kpa"]).filter(|k| k.len() == 2).ok_or("voices/measured-singing.json: threshold.kpa, two numbers")?;
        let mut speakers = Vec::new();
        for part in weights.split(',').filter(|p| !p.is_empty()) {
            let (id, w) = part.split_once(':').ok_or_else(|| format!("{switch}={weights}: SPEAKER:WEIGHT,..."))?;
            let w: f64 = w.parse().ok().filter(|w: &f64| *w >= 0.0 && w.is_finite()).ok_or_else(|| format!("{switch}: {part}: a weight, 0 or more"))?;
            let s = &law["speakers"][id];
            let voice = s["voice"].as_str().ok_or_else(|| format!("{switch}: no speaker {id} in voices/{name}"))?;
            let f0_mean_hz = threshold["f0_mean_hz"][voice].as_f64().ok_or_else(|| format!("voices/measured-singing.json: threshold.f0_mean_hz.{voice}"))?;
            let mut pitches = Vec::new();
            for p in s["pitches"].as_array().ok_or_else(|| format!("fold-law.json: {id}'s pitches"))? {
                let midi = p["midi"].as_f64().ok_or_else(|| format!("fold-law.json: {id}: a pitch's midi"))?;
                let over: Vec<f64> = numbers(&p["overThreshold"]).ok_or_else(|| format!("fold-law.json: {id} {midi}: its pressures"))?.iter().map(|x| x.ln()).collect();
                let width = if sung { 4 } else { 3 };
                let shapes: Vec<[f64; 4]> = p["shapes"]
                    .as_array()
                    .and_then(|a| a.iter().map(|x| numbers(x).filter(|v| v.len() == width).map(|v| [(20.0 * v[0].max(1e-12).log10()).max(LEAST_DB), v[1], v[2], v.get(3).copied().unwrap_or(0.0)])).collect())
                    .ok_or_else(|| format!("{name}: {id} {midi}: its shapes, {width} controls each"))?;
                if shapes.is_empty() || shapes.len() != over.len() {
                    return Err(format!("fold-law.json: {id} {midi}: a shape for each pressure"));
                }
                pitches.push(Pitch { midi, over, shapes });
            }
            if pitches.is_empty() {
                return Err(format!("fold-law.json: {id}: no pitches"));
            }
            pitches.sort_by(|a, b| a.midi.total_cmp(&b.midi));
            let folds = if sung {
                let number = |v: &Value, what: &str| v.as_f64().filter(|x| *x >= 0.0).ok_or_else(|| format!("{name}: {id}: its {what}"));
                Some(Sung { gap_cm: number(&s["gap_cm"], "gap_cm")?, contact_cm: number(&s["contact_cm"], "contact_cm")?, k2: number(&law["openQuotient"]["k2"][voice], "voice's k2 (openQuotient.k2)")? })
            } else {
                None
            };
            speakers.push((id.to_string(), w, Table { pitches, kpa: [kpa[0], kpa[1]], f0_mean_hz, sung: folds }));
        }
        let total: f64 = speakers.iter().map(|s| s.1).sum();
        if !(total > 0.0) {
            return Err(format!("{switch}={weights}: no weight"));
        }
        for s in speakers.iter_mut() {
            s.1 /= total;
        }
        Ok(FoldLaw { speakers })
    }

    /// The modal shape's controls at `f0_hz` and a lung pressure of `pressure_dpa`: relative amplitude, phase lag,
    /// pulse shape.
    pub fn at(&self, f0_hz: f64, pressure_dpa: f64) -> [f64; 3] {
        let v = self.at4(f0_hz, pressure_dpa);
        [v[0], v[1], v[2]]
    }

    /// The same with the chink (cm2), the sung folds' fourth control (nothing in the first law's).
    pub fn at4(&self, f0_hz: f64, pressure_dpa: f64) -> [f64; 4] {
        let mut out = [0.0; 4];
        for (_, w, table) in &self.speakers {
            let v = table.at(f0_hz, pressure_dpa);
            for k in 0..4 {
                out[k] += w * v[k];
            }
        }
        out
    }

    /// The sung folds' rest gap at the vocal processes (cm) and contact softness (cm), the body's speakers' weighed; and
    /// the open quotient's law on its glottis (k2 and the threshold's mean pitch weighed alike). None: the first law.
    pub fn sung(&self) -> Option<(f64, f64, SungFolds)> {
        let mut out = (0.0, 0.0, SungFolds { k2: 0.0, kpa: [0.0; 2], f0_mean_hz: 0.0, gap_cm: 0.0 });
        for (_, w, table) in &self.speakers {
            let s = table.sung?;
            out.0 += w * s.gap_cm;
            out.1 += w * s.contact_cm;
            out.2.k2 += w * s.k2;
            out.2.f0_mean_hz += w * table.f0_mean_hz;
            out.2.kpa = table.kpa;
        }
        out.2.gap_cm = out.0;
        Some(out)
    }

    /// A phrase's glottis curves (v24::gestural::Curves glottis: F0 in Hz, the lung pressure in dPa) given the law: each
    /// sample's three controls moved by its share in the modal shape (`modal_weight`, GesturalScore::glottal_shape_weight)
    /// of the law's values less the modal shape's own (`modal`, the glottis's controls).
    pub fn apply(&self, glottis: &mut [Vec<f64>], modal_weight: &[f64], modal: &[f64]) {
        let n = modal_weight.len().min(glottis[FREQUENCY].len());
        let sung = self.sung();
        for i in 0..n {
            let w = modal_weight[i].clamp(0.0, 1.0);
            if w == 0.0 {
                continue;
            }
            let law = self.at4(glottis[FREQUENCY][i], glottis[PRESSURE][i]);
            for (k, &c) in CONTROLS.iter().enumerate() {
                glottis[c][i] += w * (law[k] - modal[c]);
            }
            // (the sung folds': the chink the law's, the rest gap the speaker's sung one, on both edges)
            if let Some((gap, _, _)) = sung {
                glottis[CHINK_AREA][i] += w * (law[3] - modal[CHINK_AREA]);
                for c in [LOWER_END_X, UPPER_END_X] {
                    glottis[c][i] += w * (gap - modal[c]);
                }
            }
        }
    }

    /// The speakers and their weights, as read.
    pub fn weights(&self) -> Vec<(String, f64)> {
        self.speakers.iter().map(|(id, w, _)| (id.clone(), *w)).collect()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_law_meets_its_points_and_holds_beyond_them() {
        let law = FoldLaw::read("JD2:1").expect("JD2's law");
        let file = voices_file("fold-law.json").unwrap();
        let measured = voices_file("measured-singing.json").unwrap();
        let (kpa, mean) = (numbers(&measured["threshold"]["kpa"]).unwrap(), measured["threshold"]["f0_mean_hz"]["men"].as_f64().unwrap());
        let hz = |midi: f64| 440.0 * 2f64.powf((midi - 69.0) / 12.0);
        let threshold = |f0: f64| (kpa[0] + kpa[1] * (f0 / mean).powi(2)) * 1e4;
        // (At each fitted point, the fit's controls.)
        for p in file["speakers"]["JD2"]["pitches"].as_array().unwrap() {
            let f0 = hz(p["midi"].as_f64().unwrap());
            for (over, shape) in numbers(&p["overThreshold"]).unwrap().iter().zip(p["shapes"].as_array().unwrap()) {
                let want = numbers(shape).unwrap();
                let got = law.at(f0, over * threshold(f0));
                assert!((got[0] - want[0].max(0.01)).abs() < 1e-9 && (got[1] - want[1]).abs() < 1e-9 && (got[2] - want[2]).abs() < 1e-9, "{got:?} against {want:?}");
            }
        }
        // (Beyond its pitches and pressures, held at the nearest.)
        let near = |a: [f64; 3], b: [f64; 3]| (0..3).all(|k| (a[k] - b[k]).abs() < 1e-9);
        assert!(near(law.at(hz(30.0), 0.5 * threshold(hz(30.0))), law.at(hz(45.0), 1.5 * threshold(hz(45.0)))));
        assert!(near(law.at(hz(90.0), 100.0 * threshold(hz(90.0))), law.at(hz(66.0), 1e3 * threshold(hz(66.0)))));
        // (Two speakers half each: half of each one's.)
        let (a, b, both) = (FoldLaw::read("JD2:1").unwrap(), FoldLaw::read("M01:1").unwrap(), FoldLaw::read("JD2:0.5,M01:0.5").unwrap());
        let (x, y, z) = (a.at(150.0, 6000.0), b.at(150.0, 6000.0), both.at(150.0, 6000.0));
        for k in 0..3 {
            assert!((z[k] - 0.5 * (x[k] + y[k])).abs() < 1e-12);
        }
        // (A sample half in the modal shape moved half the way to the law; one out of it not at all.)
        let mut curves: Vec<Vec<f64>> = vec![vec![0.0; 2]; crate::v24::glottis::NUM_CONTROL_PARAMS];
        curves[FREQUENCY] = vec![150.0; 2];
        curves[PRESSURE] = vec![6000.0; 2];
        let modal: Vec<f64> = (0..crate::v24::glottis::NUM_CONTROL_PARAMS).map(|k| if k == RELATIVE_AMPLITUDE { 1.0 } else { 0.25 }).collect();
        for &c in &CONTROLS {
            curves[c] = vec![modal[c]; 2];
        }
        a.apply(&mut curves, &[0.5, 0.0], &modal);
        for (k, &c) in CONTROLS.iter().enumerate() {
            assert!((curves[c][0] - (modal[c] + 0.5 * (x[k] - modal[c]))).abs() < 1e-12);
            assert_eq!(curves[c][1], modal[c]);
        }
        // (The first law gives no sung folds.)
        assert!(a.sung().is_none());
    }

    #[test]
    fn the_sung_folds_law_meets_its_points_and_gives_the_glottis_its_gap_contact_and_quotient() {
        let law = FoldLaw::read_sung("W02:1").expect("W02's sung folds");
        let file = voices_file("sung-folds.json").unwrap();
        let measured = voices_file("measured-singing.json").unwrap();
        let (kpa, mean) = (numbers(&measured["threshold"]["kpa"]).unwrap(), measured["threshold"]["f0_mean_hz"]["women"].as_f64().unwrap());
        let hz = |midi: f64| 440.0 * 2f64.powf((midi - 69.0) / 12.0);
        let threshold = |f0: f64| (kpa[0] + kpa[1] * (f0 / mean).powi(2)) * 1e4;
        // (At each fitted point, the fit's four controls.)
        let own = &file["speakers"]["W02"];
        for p in own["pitches"].as_array().unwrap() {
            let f0 = hz(p["midi"].as_f64().unwrap());
            for (over, shape) in numbers(&p["overThreshold"]).unwrap().iter().zip(p["shapes"].as_array().unwrap()) {
                let want = numbers(shape).unwrap();
                let got = law.at4(f0, over * threshold(f0));
                assert!((got[0] - want[0].max(0.01)).abs() < 1e-9 && (1..4).all(|k| (got[k] - want[k]).abs() < 1e-9), "{got:?} against {want:?}");
            }
        }
        // (Its gap, its contact softness, and the open quotient's law for its glottis: the file's.)
        let (gap, contact, folds) = law.sung().expect("the sung folds'");
        assert_eq!(gap, own["gap_cm"].as_f64().unwrap());
        assert_eq!(contact, own["contact_cm"].as_f64().unwrap());
        assert_eq!(folds.k2, file["openQuotient"]["k2"]["women"].as_f64().unwrap());
        assert_eq!((folds.f0_mean_hz, folds.kpa, folds.gap_cm), (mean, [kpa[0], kpa[1]], gap));
        // (A phrase's sample in the modal shape takes the law's chink and the sung gap on both edges; one out of it none.)
        let n = crate::v24::glottis::NUM_CONTROL_PARAMS;
        let mut curves: Vec<Vec<f64>> = vec![vec![0.05; 2]; n];
        curves[FREQUENCY] = vec![300.0; 2];
        curves[PRESSURE] = vec![9000.0; 2];
        let modal: Vec<f64> = vec![0.05; n];
        law.apply(&mut curves, &[1.0, 0.0], &modal);
        let at = law.at4(300.0, 9000.0);
        assert!((curves[CHINK_AREA][0] - at[3]).abs() < 1e-12 && (curves[LOWER_END_X][0] - gap).abs() < 1e-12 && (curves[UPPER_END_X][0] - gap).abs() < 1e-12);
        assert_eq!((curves[CHINK_AREA][1], curves[LOWER_END_X][1]), (0.05, 0.05));
    }
}
