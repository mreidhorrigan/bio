// The tongue (VocalTract.cpp calcTongue and what it calls): its midsagittal contour from the root's Bezier curve, the
// body's ellipse, the blade's Bezier curve and the tip's circle; its parameters held inside the hull; its ribs normal to
// the contour, their sides raised by TS1-3, each rib widened until it meets the hull's cross-profile there. Each
// expression in the C++'s order.
use crate::geometry::{circle_tangent, ellipse_tangent, p2, p3, P2};
use crate::splines::{BezierCurve3D, Curve3, LineStrip2D};
use crate::tract::*;
use std::f64::consts::PI;

impl VocalTract {
    pub fn tongue_side_param_to_elevation_cm(v: f64) -> f64 {
        if v >= 0.0 {
            const MAX_ELEVATION_CM: f64 = 1.0;
            let e = MAX_ELEVATION_CM * (v / 0.3);
            if e > MAX_ELEVATION_CM {
                MAX_ELEVATION_CM
            } else {
                e
            }
        } else {
            const MIN_ELEVATION_CM: f64 = -1.0;
            let e = MIN_ELEVATION_CM * (v / -0.3);
            if e < MIN_ELEVATION_CM {
                MIN_ELEVATION_CM
            } else {
                e
            }
        }
    }

    /// The minimum area a tongue side's bracing keeps open (fricatives' and laterals' channels).
    pub fn tongue_side_param_to_min_area_cm2(v: f64) -> f64 {
        if v > 0.2 {
            const MAX_AREA_CM2: f64 = 0.15;
            let a = MAX_AREA_CM2 * (v - 0.2) / 0.2;
            if a > MAX_AREA_CM2 {
                MAX_AREA_CM2
            } else {
                a
            }
        } else if v < -0.05 {
            const MAX_AREA_CM2: f64 = 0.25;
            let a = MAX_AREA_CM2 * (v + 0.05) / (-0.2);
            if a > MAX_AREA_CM2 {
                MAX_AREA_CM2
            } else {
                a
            }
        } else {
            0.0
        }
    }

    pub(crate) fn calc_tongue(&mut self) {
        const EPSILON: f64 = 0.000001;
        let hyoid = self.surface[LOWER_COVER].get(NUM_LARYNX_RIBS - 1, NUM_LOWER_COVER_POINTS - 1);
        if self.anatomy.automatic_tongue_root_calc {
            let c = p2(self.param[TCX].limited_x, self.param[TCY].limited_x);
            let distance = (c - hyoid.to_p2()).magnitude();
            self.param[TRX].x = self.anatomy.tongue_root_trx_slope * distance + self.anatomy.tongue_root_trx_intercept;
            self.param[TRY].x = self.anatomy.tongue_root_try_slope * self.param[TCX].x + self.anatomy.tongue_root_try_intercept;
        }
        self.restrict_tongue_params();
        let c0 = p2(self.param[TCX].limited_x, self.param[TCY].limited_x);
        let c1 = p2(self.param[TTX].limited_x, self.param[TTY].limited_x);
        let (r0x, r0y) = (self.anatomy.tongue_center_radius_x_cm, self.anatomy.tongue_center_radius_y_cm);
        let r1 = self.anatomy.tongue_tip_radius_cm;
        let weight = [1.0, 2.0, 1.0];
        let mut alpha = [0.0; 4];
        // The root's Bezier curve.
        let mut q = [hyoid, p3(0.0, 0.0, 0.0), p3(0.0, 0.0, 0.0)];
        alpha[0] = ellipse_tangent(q[0].to_p2(), c0, r0x, r0y, true);
        q[2] = p3(c0.x + r0x * alpha[0].cos(), c0.y + r0y * alpha[0].sin(), 0.0);
        q[1].x = self.param[TRX].x;
        q[1].y = self.param[TRY].x;
        alpha[0] = ellipse_tangent(q[1].to_p2(), c0, r0x, r0y, true);
        q[2] = p3(c0.x + r0x * alpha[0].cos(), c0.y + r0y * alpha[0].sin(), 0.0);
        let mut root_curve = BezierCurve3D::new();
        root_curve.set_points(&q, Some(&weight));
        // The blade's Bezier curve.
        q[1] = p3(self.param[TBX].x, self.param[TBY].x, 0.0);
        alpha[1] = ellipse_tangent(q[1].to_p2(), c0, r0x, r0y, false);
        if alpha[1] > alpha[0] && alpha[1] - alpha[0] < 0.25 * PI {
            alpha[1] = alpha[0];
        }
        q[0] = p3(c0.x + r0x * alpha[1].cos(), c0.y + r0y * alpha[1].sin(), 0.0);
        alpha[2] = circle_tangent(q[1].to_p2(), c1, r1, true);
        q[2] = p3(c1.x + r1 * alpha[2].cos(), c1.y + r1 * alpha[2].sin(), 0.0);
        let mut blade_curve = BezierCurve3D::new();
        blade_curve.set_points(&q, Some(&weight));
        // The whole midsagittal contour.
        let mut target: Vec<P2> = Vec::with_capacity(104);
        let mut side_index = [0usize; 5];
        for i in 0..32 {
            target.push(root_curve.point(i as f64 / 32.0).to_p2());
        }
        side_index[1] = target.len() - 8;
        if alpha[0] < 0.0 {
            alpha[0] += 2.0 * PI;
        }
        let mut delta = alpha[1] - alpha[0];
        if delta > -EPSILON {
            delta = -EPSILON;
        }
        for i in 0..32 {
            let angle = alpha[0] + delta * i as f64 / 32.0;
            target.push(p2(c0.x + r0x * angle.cos(), c0.y + r0y * angle.sin()));
        }
        side_index[2] = target.len() - 8;
        for i in 0..32 {
            target.push(blade_curve.point(i as f64 / 32.0).to_p2());
        }
        side_index[3] = target.len() - 1;
        alpha[3] = 0.0;
        if alpha[2] < 0.0 {
            alpha[2] += 2.0 * PI;
        }
        let mut delta = alpha[3] - alpha[2];
        if delta > -EPSILON {
            delta = -EPSILON;
        }
        for i in 0..8 {
            let angle = alpha[2] + delta * i as f64 / 7.0;
            target.push(p2(c1.x + r1 * angle.cos(), c1.y + r1 * angle.sin()));
        }
        side_index[4] = target.len() - 1;
        let mut target_curve = LineStrip2D::from_points(&target);
        let mut elevation = [0.0; 5];
        elevation[0] = 1.0;
        elevation[1] = Self::tongue_side_param_to_elevation_cm(self.param[TS1].x);
        elevation[2] = Self::tongue_side_param_to_elevation_cm(self.param[TS2].x);
        elevation[3] = Self::tongue_side_param_to_elevation_cm(self.param[TS3].x);
        elevation[4] = elevation[3];
        if elevation[4] > 0.0 {
            elevation[4] = 0.0;
        }
        let side: Vec<P2> = (0..5).map(|i| p2(target_curve.curve_param(side_index[i] as i32), elevation[i])).collect();
        let left_side_height = LineStrip2D::from_points(&side);
        let right_side_height = LineStrip2D::from_points(&side);
        // No midsagittal point beyond the hull.
        let center = p2(0.0, -1.5);
        for i in 0..target_curve.num_points() {
            let c = target_curve.control_point(i as i32);
            let mut n = p2(0.0, 0.0);
            if c.x <= center.x && c.y <= center.y {
                n = p2(1.0, 0.0);
            } else if c.x >= center.x && c.y >= center.y {
                n = p2(0.0, -1.0);
            } else if c.x <= center.x && c.y >= center.y {
                n = center - c;
            }
            if n.x != 0.0 || n.y != 0.0 {
                n.normalize();
                if let Some((t, inter)) = self.upper_outline.special_intersection(c, n) {
                    if t > 0.0 {
                        target_curve.set_point(i, inter);
                    }
                }
            }
        }
        let rib = &mut self.tongue_rib;
        for i in 0..NUM_DYNAMIC_TONGUE_RIBS {
            let t = i as f64 / (NUM_DYNAMIC_TONGUE_RIBS - 1) as f64;
            rib[i].point = target_curve.point(t);
            rib[i].left_side_height = left_side_height.function_value(t);
            rib[i].right_side_height = right_side_height.function_value(t);
        }
        const FILTER_COEFF: f64 = 0.5;
        for i in 1..NUM_DYNAMIC_TONGUE_RIBS {
            rib[i].left_side_height += FILTER_COEFF * (rib[i - 1].left_side_height - rib[i].left_side_height);
            rib[i].right_side_height += FILTER_COEFF * (rib[i - 1].right_side_height - rib[i].right_side_height);
        }
        const N: usize = 4;
        for i in N..NUM_DYNAMIC_TONGUE_RIBS - N {
            rib[i].normal = (rib[i + 1].point - rib[i - 1].point).turn_left();
            rib[i].normal.normalize();
        }
        let (n0, n1) = (p2(-1.0, 0.0), rib[N].normal);
        for i in 0..N {
            let t = i as f64 / N as f64;
            rib[i].normal = (1.0 - t) * n0 + t * n1;
        }
        let (n0, n1) = (rib[NUM_DYNAMIC_TONGUE_RIBS - N - 1].normal, p2(0.0, 1.0));
        for i in 0..N {
            let t = (i + 1) as f64 / N as f64;
            rib[NUM_DYNAMIC_TONGUE_RIBS - N + i].normal = (1.0 - t) * n0 + t * n1;
        }
        let (ts_min, ts_max) = (self.param[TS1].min, self.param[TS1].max);
        let rib = &mut self.tongue_rib;
        for r in rib.iter_mut().take(NUM_DYNAMIC_TONGUE_RIBS) {
            r.min_y = ts_min - 0.5;
            r.max_y = ts_max + 0.5;
        }
        // The ribs' normals turned so neighbours do not cross: a forward and a backward pass, averaged.
        let orig_normal: Vec<P2> = rib[..NUM_DYNAMIC_TONGUE_RIBS].iter().map(|r| r.normal).collect();
        for i in 0..NUM_DYNAMIC_TONGUE_RIBS - 1 {
            self.verify_tongue_rib_normal(i, i + 1);
        }
        let mut new_normal = [P2::default(); NUM_TONGUE_RIBS];
        for i in 0..NUM_DYNAMIC_TONGUE_RIBS {
            new_normal[i] = self.tongue_rib[i].normal;
            self.tongue_rib[i].normal = orig_normal[i];
        }
        for i in (1..NUM_DYNAMIC_TONGUE_RIBS).rev() {
            self.verify_tongue_rib_normal(i, i - 1);
        }
        for i in 0..NUM_DYNAMIC_TONGUE_RIBS {
            new_normal[i] += self.tongue_rib[i].normal;
            self.tongue_rib[i].normal = new_normal[i].normalize();
        }
        // The lower boundary with the mouth floor.
        let mut lower: Vec<P2> = Vec::new();
        let mut c = self.surface[LOWER_COVER].get(NUM_LARYNX_RIBS + NUM_THROAT_RIBS, NUM_LOWER_COVER_POINTS - 1).to_p2();
        c.y += 0.5;
        lower.push(c);
        match self.lower_outline.closest_intersection(c, p2(1.0, 0.0)) {
            Some((_, inter)) => lower.push(inter),
            None => lower.push(c),
        }
        let min_y = lower[1].y;
        for i in NUM_LARYNX_RIBS + NUM_THROAT_RIBS..NUM_LOWER_COVER_RIBS {
            let c = self.surface[LOWER_COVER].get(i, NUM_LOWER_COVER_POINTS - 1).to_p2();
            if c.y > min_y {
                lower.push(c);
            }
        }
        for i in 0..3 {
            lower.push(self.surface[LOWER_TEETH].get(NUM_TEETH_RIBS - 1, i).to_p2());
        }
        let mut lower_boundary = LineStrip2D::from_points(&lower);
        let mut c = lower_boundary.point((lower_boundary.num_points() - 1) as f64);
        c.x += 10.0;
        lower_boundary.add_point(c);
        // The rib that ends the dynamic ribs.
        let tip_radius = self.anatomy.tongue_tip_radius_cm;
        let tty = self.param[TTY].limited_x;
        let rib = &mut self.tongue_rib;
        let i = NUM_DYNAMIC_TONGUE_RIBS - 1;
        let t = if rib[i].left_side_height < rib[i].right_side_height { rib[i].left_side_height } else { rib[i].right_side_height };
        let mut final_point = rib[i].point + rib[i].normal * t;
        if tty - tip_radius < final_point.y {
            final_point.y = tty - tip_radius;
        }
        let i = NUM_DYNAMIC_TONGUE_RIBS;
        rib[i].normal = p2(0.0, 1.0);
        rib[i].left_side_height = 0.0;
        rib[i].right_side_height = 0.0;
        rib[i].point = final_point;
        let up = p2(0.0, 1.0);
        for i in NUM_TONGUE_RIBS / 2..=NUM_DYNAMIC_TONGUE_RIBS {
            if let Some((t, inter)) = lower_boundary.closest_intersection(rib[i].point, up) {
                if t > 0.0 {
                    rib[i].point = inter;
                }
            }
            if let Some((t, _)) = lower_boundary.closest_intersection(rib[i].point, rib[i].normal) {
                if rib[i].left_side_height < t {
                    rib[i].left_side_height = t;
                }
                if rib[i].right_side_height < t {
                    rib[i].right_side_height = t;
                }
            }
        }
        // The three most anterior ribs: the third last at 45 degrees.
        let c = rib[NUM_TONGUE_RIBS - 4].point;
        let mut d = c;
        d.x -= 2.0 * tip_radius;
        d.y -= 2.0 * tip_radius;
        if let Some((t, inter)) = lower_boundary.closest_intersection(c, d - c) {
            if t < 1.0 {
                d = inter;
            }
        }
        let i = NUM_TONGUE_RIBS - 3;
        rib[i].point = d;
        rib[i].normal = p2(0.0, 1.0);
        rib[i].left_side_height = 0.0;
        rib[i].right_side_height = 0.0;
        let c = rib[NUM_TONGUE_RIBS - 3].point;
        rib[NUM_TONGUE_RIBS - 2].point = match lower_boundary.closest_intersection(c, p2(0.0, -1.0)) {
            Some((_, inter)) => inter,
            None => c,
        };
        let floor = lower_boundary.control_point(1);
        rib[NUM_TONGUE_RIBS - 1].point = if rib[NUM_TONGUE_RIBS - 2].point.x < floor.x { floor } else { rib[NUM_TONGUE_RIBS - 2].point };
        for i in [NUM_TONGUE_RIBS - 2, NUM_TONGUE_RIBS - 1] {
            rib[i].normal = p2(0.0, 1.0);
            rib[i].left_side_height = 0.0;
            rib[i].right_side_height = 0.0;
        }
        self.calc_tongue_ribs();
        // The bulge at the tongue root (as the model speaker JD has it).
        const NUM_BULGE_RIBS: usize = 8;
        const BULGE_HEIGHT_CM: f64 = 0.5;
        let s = &mut self.surface[TONGUE];
        let np = s.num_rib_points;
        for i in 0..NUM_BULGE_RIBS {
            let n = self.tongue_rib[i].normal;
            for k in 0..np {
                let b = BULGE_HEIGHT_CM * (0.5 - 0.5 * (2.0 * PI * i as f64 / (NUM_BULGE_RIBS - 1) as f64).cos()) * (0.5 - 0.5 * (2.0 * PI * k as f64 / (np - 1) as f64).cos());
                let mut p = s.get(i, k);
                p.x += n.x * b;
                p.y += n.y * b;
                s.set(i, k, p);
            }
        }
    }

    fn restrict_tongue_params(&mut self) {
        const EPSILON: f64 = 0.000001;
        const DELTA: f64 = 0.3; // (The tongue's circles may reach 3 mm beyond the hull.)
        let tip_radius = self.anatomy.tongue_tip_radius_cm;
        let (orig_ttx, orig_tty, orig_tcx, orig_tcy) = (self.param[TTX].x, self.param[TTY].x, self.param[TCX].x, self.param[TCY].x);
        for i in [TCX, TCY, TTX, TTY] {
            self.restrict_param(i);
        }
        let uc = &self.surface[UPPER_COVER];
        let q0 = uc.get(NUM_UPPER_COVER_RIBS - NUM_PALATE_RIBS + 1, NUM_UPPER_COVER_POINTS - 1).to_p2();
        let q1 = uc.get(NUM_UPPER_COVER_RIBS - 1, NUM_UPPER_COVER_POINTS - 1).to_p2();
        let mut anchor = p2(q0.x, q1.y - (q1.x - q0.x));
        // The upper border: the pharynx's back, the palate, the incisors and a vertical line through them.
        let mut up: Vec<P2> = (NUM_LARYNX_RIBS..NUM_UPPER_COVER_RIBS).map(|i| uc.get(i, NUM_UPPER_COVER_POINTS - 1).to_p2()).collect();
        for i in 0..2 {
            up.push(self.surface[UPPER_TEETH].get(NUM_TEETH_RIBS - 1, i).to_p2());
        }
        let p0 = up[up.len() - 1];
        up.push(p2(p0.x, p0.y - 10.0));
        for c in up.iter_mut() {
            let mut w = *c - anchor;
            *c += w.normalize() * DELTA;
            if c.x > p0.x {
                c.x = p0.x;
            }
        }
        let upper_border = LineStrip2D::from_points(&up);
        let lc = &self.surface[LOWER_COVER];
        let mut tt: Vec<P2> = vec![p2(0.0, 0.0)];
        tt.extend((NUM_LARYNX_RIBS - 1..NUM_LOWER_COVER_RIBS).map(|i| lc.get(i, NUM_LOWER_COVER_POINTS - 1).to_p2()));
        tt.extend((0..3).map(|i| self.surface[LOWER_TEETH].get(NUM_TEETH_RIBS - 1, i).to_p2()));
        let mut c = tt[1];
        c.x -= 10.0;
        tt[0] = c;
        let lower_border_tt = LineStrip2D::from_points(&tt);
        let p0 = lc.get(NUM_LARYNX_RIBS - 1, NUM_LOWER_COVER_POINTS - 1).to_p2();
        let p2_ = lc.get(NUM_LOWER_COVER_RIBS - 1, NUM_LOWER_COVER_POINTS - 1).to_p2();
        let mut p1 = p2(p2_.x - 1.0, p0.y);
        if p1.x < p0.x {
            p1.x = p0.x;
        }
        let mut tb: Vec<P2> = vec![p2(0.0, 0.0), p0, p1, p2_];
        tb.extend((0..3).map(|i| self.surface[LOWER_TEETH].get(NUM_TEETH_RIBS - 1, i).to_p2()));
        let mut c = tb[1];
        c.x -= 10.0;
        tb[0] = c;
        let lower_border_tb = LineStrip2D::from_points(&tb);
        let (rx, ry) = (self.anatomy.tongue_center_radius_x_cm, self.anatomy.tongue_center_radius_y_cm);
        let p = &mut self.param;
        if p[TTX].x < p[TCX].x + rx + tip_radius {
            p[TTX].x = p[TCX].x + rx + tip_radius;
        }
        let c = Self::limit_ellipse_pos(p2(p[TTX].x, p[TTY].x), tip_radius, tip_radius, &upper_border, anchor);
        p[TTX].x = c.x;
        p[TTY].x = c.y;
        if p[TCX].x > p[TTX].x - rx - tip_radius {
            p[TCX].x = p[TTX].x - rx - tip_radius;
        }
        let c = Self::limit_ellipse_pos(p2(p[TCX].x, p[TCY].x), rx, ry, &upper_border, anchor);
        p[TCX].x = c.x;
        p[TCY].x = c.y;
        if p[TTX].x < p[TCX].x + rx + tip_radius {
            p[TTX].x = p[TCX].x + rx + tip_radius;
        }
        // (Against the lower border the anchor is far above, so they retract upward.)
        anchor.y = 1000.0;
        let c = Self::limit_ellipse_pos(p2(p[TTX].x, p[TTY].x), tip_radius, tip_radius, &lower_border_tt, anchor);
        p[TTX].x = c.x;
        p[TTY].x = c.y;
        let c = Self::limit_ellipse_pos(p2(p[TCX].x, p[TCY].x), rx, ry, &lower_border_tb, anchor);
        p[TCX].x = c.x;
        p[TCY].x = c.y;
        self.restrict_param(TRX);
        self.restrict_param(TRY);
        let mut r = rx;
        if ry > r {
            r = ry;
        }
        // (The point on the body's lower left where its tangent has slope -1: Birkholz's dissertation, p. 30.)
        let mut alpha_rad = ry.atan2(rx);
        if (-PI..=PI).contains(&alpha_rad) {
            alpha_rad += PI;
        }
        let p = &mut self.param;
        let c = p2(p[TCX].x + alpha_rad.cos() * (rx + EPSILON), p[TCY].x + alpha_rad.sin() * (ry + EPSILON));
        let h = self.surface[LOWER_COVER].get(NUM_LARYNX_RIBS - 1, NUM_LOWER_COVER_POINTS - 1).to_p2();
        if p[TRY].x < h.y {
            p[TRY].x = h.y;
        }
        if p[TRY].x > p[TCY].x {
            p[TRY].x = p[TCY].x;
        }
        if p[TRX].x - c.x > c.y - p[TRY].x {
            p[TRX].x = c.x + c.y - p[TRY].x;
        }
        let min_x = p[TCX].x - rx - (p[TCY].x - h.y);
        if p[TRX].x < min_x {
            p[TRX].x = min_x;
        }
        let mut max_x = p[TCX].x - r;
        if h.x + 0.5 > max_x {
            max_x = h.x + 0.5;
        }
        if p[TRX].x > max_x {
            p[TRX].x = max_x;
        }
        self.restrict_param(TBX);
        self.restrict_param(TBY);
        let p = &mut self.param;
        if p[TBX].x < p[TCX].x {
            p[TBX].x = p[TCX].x;
        }
        if p[TBX].x > p[TTX].x {
            p[TBX].x = p[TTX].x;
        }
        let mut r = rx;
        if ry > r {
            r = ry;
        }
        r += EPSILON;
        let c = p2(p[TCX].x, p[TCY].x + 1.415 * r);
        if p[TBY].x - c.y > p[TBX].x - c.x {
            p[TBY].x = c.y + p[TBX].x - c.x;
        }
        if p[TBY].x - c.y < -(p[TBX].x - c.x) {
            p[TBY].x = c.y - (p[TBX].x - c.x);
        }
        let r = tip_radius + EPSILON;
        let c = p2(p[TTX].x, p[TTY].x + 1.415 * r);
        if p[TBY].x - c.y < p[TBX].x - c.x {
            p[TBY].x = c.y + p[TBX].x - c.x;
        }
        for i in [TS1, TS2, TS3] {
            self.restrict_param(i);
        }
        let p = &mut self.param;
        for i in [TCX, TCY, TTX, TTY, TBX, TBY, TRX, TRY, TS1, TS2, TS3] {
            p[i].limited_x = p[i].x;
        }
        p[TTX].x = orig_ttx;
        p[TTY].x = orig_tty;
        p[TCX].x = orig_tcx;
        p[TCY].x = orig_tcy;
    }

    /// An ellipse at c (radii rx, ry) moved toward the anchor a until it is inside the border.
    fn limit_ellipse_pos(c: P2, rx: f64, ry: f64, border: &LineStrip2D, a: P2) -> P2 {
        const EPSILON: f64 = 0.000001;
        let n = border.num_points();
        let (rx2, ry2) = (rx * rx, ry * ry);
        let mut final_t = (c - a).magnitude();
        let mut v = c - a;
        let v = v.normalize();
        for i in 0..n {
            let p0 = border.control_point(i as i32);
            let q = a - p0;
            let denominator = v.x * v.x * ry2 + v.y * v.y * rx2;
            if denominator.abs() > EPSILON {
                let p = 2.0 * (q.x * v.x * ry2 + q.y * v.y * rx2) / denominator;
                let qq = (q.x * q.x * ry2 + q.y * q.y * rx2 - rx2 * ry2) / denominator;
                let mut root = 0.25 * p * p - qq;
                if root >= 0.0 {
                    root = root.sqrt();
                    let t = -0.5 * p - root;
                    if t >= 0.0 && t < final_t {
                        final_t = t;
                    }
                }
            }
            if i < n - 1 {
                let p1 = border.control_point(i as i32 + 1);
                let w = p1 - p0;
                let alpha_rad = (-ry * w.x).atan2(rx * w.y);
                let u = p2(rx * alpha_rad.cos(), ry * alpha_rad.sin());
                let denominator = v.x * w.y - v.y * w.x;
                if denominator.abs() > EPSILON {
                    for q in [a - p0 + u, a - p0 - u] {
                        let s = (q.y * v.x - q.x * v.y) / denominator;
                        if (0.0..=1.0).contains(&s) {
                            let t = (q.y * w.x - q.x * w.y) / denominator;
                            if t >= 0.0 && t < final_t {
                                final_t = t;
                            }
                        }
                    }
                }
            }
        }
        a + v * final_t
    }

    fn calc_tongue_ribs(&mut self) {
        const INVALID: f64 = INVALID_PROFILE_SAMPLE;
        let width_factor = -2.0 * self.anatomy.palate_points[0].z / 4.6;
        let half_width = 1.75 * width_factor;
        for r in self.tongue_rib.iter_mut() {
            r.left = p2(-half_width, r.left_side_height);
            r.right = p2(half_width, r.right_side_height);
        }
        // The first rib is the lower cover's hyoid rib.
        let target_rib = NUM_LARYNX_RIBS - 1;
        for k in 0..NUM_TONGUE_POINTS {
            let target_point = 2 + k * (NUM_LOWER_COVER_POINTS * 2 - 1 - 1 - 4) / (NUM_TONGUE_POINTS - 1);
            let q = if target_point < NUM_LOWER_COVER_POINTS {
                self.surface[LOWER_COVER].get(target_rib, target_point)
            } else {
                let mut q = self.surface[LOWER_COVER].get(target_rib, 2 * NUM_LOWER_COVER_POINTS - 1 - target_point);
                q.z = -q.z;
                q
            };
            self.surface[TONGUE].set(0, k, q);
        }
        self.tongue_rib[0].min_x = self.surface[TONGUE].get(0, 0).z;
        self.tongue_rib[0].max_x = self.surface[TONGUE].get(0, NUM_TONGUE_POINTS - 1).z;
        const N2: usize = NUM_PROFILE_SAMPLES / 2;
        let mut a2_left = [0.0; NUM_TONGUE_RIBS];
        let mut a3_left = [0.0; NUM_TONGUE_RIBS];
        let mut a2_right = [0.0; NUM_TONGUE_RIBS];
        let mut a3_right = [0.0; NUM_TONGUE_RIBS];
        let mut upper = vec![[0.0; NUM_PROFILE_SAMPLES]; NUM_TONGUE_RIBS];
        let mut lower = vec![[0.0; NUM_PROFILE_SAMPLES]; NUM_TONGUE_RIBS];
        for i in 1..NUM_TONGUE_RIBS {
            let (point, normal) = (self.tongue_rib[i].point, self.tongue_rib[i].normal);
            self.cross_profiles(point, normal, &mut upper[i], &mut lower[i], false);
            let rib = &mut self.tongue_rib[i];
            let le = rib.left;
            a2_left[i] = 3.0 * le.y / (le.x * le.x);
            a3_left[i] = -2.0 * le.y / (le.x * le.x * le.x);
            rib.min_x = le.x;
            let mut last_inside = false;
            let mut ok = false;
            for k in 0..N2 {
                let x = -0.5 * PROFILE_LENGTH + k as f64 * PROFILE_SAMPLE_LENGTH;
                let mut inside = false;
                if upper[i][k] != INVALID && lower[i][k] != INVALID && x >= le.x {
                    let y = a2_left[i] * x * x + a3_left[i] * x * x * x;
                    if y >= lower[i][k] && y <= upper[i][k] {
                        inside = true;
                    }
                }
                if !last_inside && inside {
                    rib.min_x = x;
                    ok = true;
                }
                last_inside = inside;
            }
            if !ok {
                rib.min_x = -0.1;
            }
            let re = rib.right;
            a2_right[i] = 3.0 * re.y / (re.x * re.x);
            a3_right[i] = -2.0 * re.y / (re.x * re.x * re.x);
            rib.max_x = re.x;
            let mut last_inside = false;
            let mut ok = false;
            for k in (N2 + 1..NUM_PROFILE_SAMPLES).rev() {
                let x = k as f64 * PROFILE_SAMPLE_LENGTH - 0.5 * PROFILE_LENGTH;
                let mut inside = false;
                if upper[i][k] != INVALID && lower[i][k] != INVALID && x <= re.x {
                    let y = a2_right[i] * x * x + a3_right[i] * x * x * x;
                    if y >= lower[i][k] && y <= upper[i][k] {
                        inside = true;
                    }
                }
                if !last_inside && inside {
                    rib.max_x = x;
                    ok = true;
                }
                last_inside = inside;
            }
            if !ok {
                rib.max_x = 0.1;
            }
            // (Each rib at least so wide; a little narrower at the root and toward the tip.)
            let mut min_width = if i < 5 {
                1.0 + 0.3 * i as f64 / 5.0
            } else if i >= NUM_TONGUE_RIBS - 10 {
                let k = i - (NUM_TONGUE_RIBS - 10);
                1.3 - 0.5 * k as f64 / 10.0
            } else {
                1.3
            };
            min_width *= width_factor;
            if rib.max_x < min_width {
                rib.max_x = min_width;
            }
            if rib.min_x > -min_width {
                rib.min_x = -min_width;
            }
        }
        // The width smoothed forward and back, only ever narrowed.
        const LOWPASS_COEFF: f64 = 0.25;
        let rib = &mut self.tongue_rib;
        for i in 1..NUM_TONGUE_RIBS {
            let z = rib[i - 1].max_x + LOWPASS_COEFF * (rib[i].max_x - rib[i - 1].max_x);
            if z <= rib[i].max_x {
                rib[i].max_x = z;
            }
            let z = rib[i - 1].min_x + LOWPASS_COEFF * (rib[i].min_x - rib[i - 1].min_x);
            if z >= rib[i].min_x {
                rib[i].min_x = z;
            }
        }
        for i in (0..NUM_TONGUE_RIBS - 1).rev() {
            let z = rib[i + 1].max_x + LOWPASS_COEFF * (rib[i].max_x - rib[i + 1].max_x);
            if z <= rib[i].max_x {
                rib[i].max_x = z;
            }
            let z = rib[i + 1].min_x + LOWPASS_COEFF * (rib[i].min_x - rib[i + 1].min_x);
            if z >= rib[i].min_x {
                rib[i].min_x = z;
            }
        }
        for i in 1..NUM_TONGUE_RIBS {
            let r = self.tongue_rib[i];
            for k in 0..NUM_TONGUE_POINTS {
                let z = r.min_x + (r.max_x - r.min_x) * k as f64 / (NUM_TONGUE_POINTS - 1) as f64;
                let mut t = if k <= NUM_TONGUE_POINTS / 2 { a2_left[i] * z * z + a3_left[i] * z * z * z } else { a2_right[i] * z * z + a3_right[i] * z * z * z };
                let mut index = ((z + 0.5 * PROFILE_LENGTH) / PROFILE_SAMPLE_LENGTH) as i32;
                let mut ratio = (z + 0.5 * PROFILE_LENGTH - index as f64 * PROFILE_SAMPLE_LENGTH) / PROFILE_SAMPLE_LENGTH;
                if index < 0 {
                    index = 0;
                    ratio = 0.0;
                }
                if index > NUM_PROFILE_SAMPLES as i32 - 2 {
                    index = NUM_PROFILE_SAMPLES as i32 - 2;
                    ratio = 1.0;
                }
                let index = index as usize;
                if upper[i][index] != INVALID && upper[i][index + 1] != INVALID {
                    let y = upper[i][index] + ratio * (upper[i][index + 1] - upper[i][index]) - 0.05;
                    if t > y {
                        t = y;
                    }
                }
                self.surface[TONGUE].set(i, k, p3(r.point.x + r.normal.x * t, r.point.y + r.normal.y * t, z));
            }
        }
    }

    fn verify_tongue_rib_normal(&mut self, rigid: usize, flexible: usize) {
        let rg = self.tongue_rib[rigid];
        let r = rg.point + rg.min_y * rg.normal;
        let w = rg.point + rg.max_y * rg.normal - r;
        let fl = &mut self.tongue_rib[flexible];
        let p = fl.point;
        let v = fl.normal;
        let q = p - r;
        let denominator = v.x * w.y - v.y * w.x;
        if denominator != 0.0 {
            let s = (v.x * q.y - q.x * v.y) / denominator;
            if (0.0..=1.0).contains(&s) {
                let t = (w.x * q.y - q.x * w.y) / denominator;
                if t <= 0.0 && t >= fl.min_y {
                    fl.normal = fl.point - r;
                    fl.normal.normalize();
                } else if t >= 0.0 && t <= fl.max_y {
                    fl.normal = r + w - fl.point;
                    fl.normal.normalize();
                }
            }
        }
    }
}
