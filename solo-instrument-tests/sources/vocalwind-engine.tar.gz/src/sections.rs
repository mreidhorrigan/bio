// From the surfaces to the tube (VocalTract.cpp calcCenterLine, calcCrossSections, getCrossProfiles,
// crossSectionsToTubeSections, getTube): a center line from glottis to lips (the "mu-line" around the tongue body,
// smoothed); at each of its 129 points the surfaces cut by the plane normal to it, the cuts sampled across the tract
// (96 samples over 5.5 cm) into an upper and a lower profile, the tongue merged in, the open part kept; the profile's
// area and perimeter; and those read into the 40 tube sections, their lengths growing along the mouth. Each expression
// in the C++'s order.
use crate::geometry::{p2, P2};
use crate::tract::*;
use crate::tube::Articulator;
use std::f64::consts::PI;

pub const MAX_LIST_ENTRIES: usize = 1024;
pub const MAX_CUTS: usize = 2048;

#[derive(Clone, Copy, Debug, Default)]
pub struct Cut {
    p0: P2,
    p1: P2,
    n: P2,
    surface: usize,
}

// The surfaces cut for the profiles, the upper-posterior ones first.
const PROFILE_SURFACES: [usize; 10] = [UPPER_COVER, UPPER_TEETH, UPPER_LIP, UVULA, LOWER_COVER, LOWER_TEETH, LOWER_LIP, EPIGLOTTIS, LEFT_COVER, RADIATION];

type Profile = [f64; NUM_PROFILE_SAMPLES];
type Owners = [i32; NUM_PROFILE_SAMPLES];

// A cut's line sampled across the tract into a profile (insertUpperProfileLine and its two siblings): its samples'
// heights at each whole sample after its start, from where its extended segment begins to where it ends.
#[inline]
fn sample_line(mut p0: P2, mut p1: P2, mut each: impl FnMut(usize, f64)) {
    if p0.x == p1.x {
        return;
    }
    p0.x += 0.5 * PROFILE_LENGTH;
    p1.x += 0.5 * PROFILE_LENGTH;
    if p0.x > p1.x {
        std::mem::swap(&mut p0, &mut p1);
    }
    const LENGTH_INC: f64 = 0.01;
    let mut v = p1 - p0;
    v.normalize();
    p0 -= LENGTH_INC * v;
    p1 += LENGTH_INC * v;
    let first = (p0.x / PROFILE_SAMPLE_LENGTH) as i32;
    let last = (p1.x / PROFILE_SAMPLE_LENGTH) as i32;
    if first == last {
        return;
    }
    let dx = PROFILE_SAMPLE_LENGTH;
    let dy = (p1.y - p0.y) * dx / (p1.x - p0.x);
    let mut y = p0.y + ((first as f64 + 1.0) * dx - p0.x) * dy / dx;
    for i in first + 1..=last {
        if i >= 0 && (i as usize) < NUM_PROFILE_SAMPLES {
            each(i as usize, y);
        }
        y += dy;
    }
}

fn insert_upper(p0: P2, p1: P2, surface: usize, upper: &mut Profile, owner: &mut Owners) {
    sample_line(p0, p1, |i, y| {
        if y <= upper[i] && y >= MIN_PROFILE_VALUE && y <= MAX_PROFILE_VALUE {
            upper[i] = y;
            owner[i] = surface as i32;
        }
    });
}

fn insert_lower(p0: P2, p1: P2, surface: usize, lower: &mut Profile, owner: &mut Owners) {
    sample_line(p0, p1, |i, y| {
        if y >= lower[i] && y >= MIN_PROFILE_VALUE && y <= MAX_PROFILE_VALUE {
            lower[i] = y;
            owner[i] = surface as i32;
        }
    });
}

// The lower cover into the lower profile, and into the upper where nothing has defined it yet.
fn insert_lower_cover(p0: P2, p1: P2, surface: usize, upper: &mut Profile, upper_owner: &mut Owners, lower: &mut Profile, lower_owner: &mut Owners) {
    sample_line(p0, p1, |i, y| {
        if y >= MIN_PROFILE_VALUE && y <= MAX_PROFILE_VALUE {
            if y >= lower[i] {
                lower[i] = y;
                lower_owner[i] = surface as i32;
            }
            if upper[i] == EXTREME_PROFILE_VALUE && y <= upper[i] {
                upper[i] = y;
                upper_owner[i] = surface as i32;
            }
        }
    });
}

impl VocalTract {
    pub(crate) fn calc_center_line(&mut self) {
        const SKIPPED_LIP_POINTS: usize = 1;
        const N: usize = NUM_CENTERLINE_POINTS;
        let tc = p2(self.param[TCX].limited_x, self.param[TCY].limited_x);
        let (rx, ry) = (self.anatomy.tongue_center_radius_x_cm, self.anatomy.tongue_center_radius_y_cm);
        let mut min_y = self.upper_outline.control_point(0).y;
        let r = self.lower_outline.control_point(0);
        if r.y > min_y {
            min_y = r.y;
        }
        // (The anterior end at the lip rib point more posterior of the two: Lindblom 2007's spread lips.)
        let mut max_x = self.upper_outline.control_point((self.upper_outline.num_points() - 1 - SKIPPED_LIP_POINTS) as i32).x;
        let r = self.lower_outline.control_point((self.lower_outline.num_points() - 1 - SKIPPED_LIP_POINTS) as i32);
        if r.x < max_x {
            max_x = r.x;
        }
        let mu = [tc.y - min_y, 0.5 * PI * 0.5 * (rx + ry), max_x - tc.x];
        let mu_length = mu[0] + mu[1] + mu[2];
        let mut nu_line = [P2::default(); N + 2];
        for i in 0..N {
            let pos = mu_length * i as f64 / (N - 1) as f64;
            let (p, v) = if pos <= mu[0] {
                (p2(tc.x - rx, tc.y - mu[0] + pos), p2(-1.0, 0.0))
            } else if pos <= mu[0] + mu[1] {
                let angle = PI - 0.5 * PI * (pos - mu[0]) / mu[1];
                let (c, s) = (angle.cos(), angle.sin());
                let mut v = p2(rx * c, ry * s);
                v.normalize();
                (p2(tc.x + rx * c, tc.y + ry * s), v)
            } else {
                (p2(tc.x + pos - mu[0] - mu[1], tc.y + ry), p2(0.0, 1.0))
            };
            // (Each fails as the C++'s functions fail: at t 1e6, the point (0, 0).)
            let none = (1000000.0, p2(0.0, 0.0));
            let r0 = self.upper_outline.special_intersection(p, v);
            let r1 = self.lower_outline.closest_intersection(p, v);
            let r2 = self.tongue_outline.closest_intersection(p, v);
            // (getFirstIntersection leaves t at 1e6 and the point at (0, 0) when it fails, as the others.)
            let r3 = self.epiglottis_outline.first_intersection(p, v);
            let ok = [r0.is_some(), r1.is_some(), r2.is_some(), r3.is_some()];
            let t = [r0.unwrap_or(none).0, r1.unwrap_or(none).0, r2.unwrap_or(none).0, r3.unwrap_or(none).0];
            let s = [r0.unwrap_or(none).1, r1.unwrap_or(none).1, r2.unwrap_or(none).1, r3.unwrap_or(none).1];
            let top = 0;
            let mut bottom = 1;
            if ok[0] {
                let mut t_max = -1000000.0;
                if ok[1] && t[1] > t_max {
                    t_max = t[1];
                    bottom = 1;
                }
                if ok[2] && t[2] > t_max {
                    t_max = t[2];
                    bottom = 2;
                }
                if ok[3] && t[3] > t_max {
                    bottom = 3;
                }
            }
            nu_line[i + 1] = 0.5 * (s[top] + s[bottom]);
        }
        // The nu-line: the mu-line's centres smoothed over a 2-cm window.
        let mut nu_line_length = 0.0;
        let mut nu = [0.0; N + 2];
        for i in 1..N {
            nu[i] = nu_line_length;
            nu_line_length += (nu_line[i + 1] - nu_line[i]).magnitude();
        }
        nu[N] = nu_line_length;
        const RANGE_LENGTH: f64 = 2.0;
        const HALF_RANGE_LENGTH: f64 = 0.5 * RANGE_LENGTH;
        nu_line[0] = nu_line[1] + p2(0.0, -HALF_RANGE_LENGTH);
        nu_line[N + 1] = nu_line[N] + p2(HALF_RANGE_LENGTH, 0.0);
        nu[0] = -HALF_RANGE_LENGTH;
        nu[N + 1] = nu[N] + HALF_RANGE_LENGTH;
        let mut range_index = [0usize; 2];
        let mut range_point = [P2::default(); 2];
        for i in 0..N {
            let rp0 = nu_line_length * i as f64 / (N - 1) as f64 - HALF_RANGE_LENGTH;
            let range_pos = [rp0, rp0 + RANGE_LENGTH];
            for k in 0..2 {
                while range_index[k] < N && range_pos[k] > nu[range_index[k] + 1] {
                    range_index[k] += 1;
                }
                let ri = range_index[k];
                let d = (range_pos[k] - nu[ri]) / (nu[ri + 1] - nu[ri]);
                range_point[k] = nu_line[ri] + d * (nu_line[ri + 1] - nu_line[ri]);
            }
            let mut c = p2(0.0, 0.0);
            if range_index[1] > range_index[0] {
                let length = (nu_line[range_index[0] + 1] - range_point[0]).magnitude();
                c += length * 0.5 * (range_point[0] + nu_line[range_index[0] + 1]);
                for k in range_index[0] + 1..range_index[1] {
                    let length = (nu_line[k + 1] - nu_line[k]).magnitude();
                    c += length * 0.5 * (nu_line[k] + nu_line[k + 1]);
                }
                let length = (range_point[1] - nu_line[range_index[1]]).magnitude();
                c += length * 0.5 * (range_point[1] + nu_line[range_index[1]]);
            } else {
                let length = (range_point[1] - range_point[0]).magnitude();
                c += length * 0.5 * (range_point[0] + range_point[1]);
            }
            self.center_line[i].point = c / RANGE_LENGTH;
        }
        // Its ends on the glottis and the lips.
        let q0 = self.upper_outline.control_point(0);
        let q1 = self.lower_outline.control_point(0);
        let x = self.center_line[0].point.x;
        let y = q0.y + (q1.y - q0.y) * (x - q0.x) / (q1.x - q0.x);
        self.center_line[0].point.y = y;
        for i in 0..4 {
            if self.center_line[i].point.y < y {
                self.center_line[i].point.y = y;
            }
        }
        self.center_line[0].normal = q0 - q1;
        self.center_line[0].normal.normalize();
        self.center_line[N - 1].normal = p2(0.0, 1.0);
        let x = self.center_line[N - 1].point.x;
        for i in N - 4..N {
            if self.center_line[i].point.x > x {
                self.center_line[i].point.x = x;
            }
        }
        self.center_line_length = 0.0;
        for i in 0..N - 1 {
            self.center_line[i].pos = self.center_line_length;
            let d = (self.center_line[i + 1].point - self.center_line[i].point).magnitude();
            self.center_line_length += d;
        }
        self.center_line[N - 1].pos = self.center_line_length;
        for i in 1..N - 1 {
            let a = self.center_line[i].point - self.center_line[i - 1].point;
            let b = self.center_line[i + 1].point - self.center_line[i].point;
            self.center_line[i].normal = p2(-a.y - b.y, a.x + b.x);
            self.center_line[i].normal.normalize();
        }
        for i in 0..N {
            self.center_line[i].reserved = 0.0;
            self.set_cut_limits(i, true);
        }
        // The normals turned, coarse to fine, so that no two neighbours cross.
        for i in 0..NUM_CENTERLINE_POINTS_EXPONENT {
            let num_to_check = 1 << i;
            let distance = 1 << (NUM_CENTERLINE_POINTS_EXPONENT - i);
            let mut index = distance / 2;
            for _ in 0..num_to_check {
                self.verify_center_line_normal(index - distance / 2, index, index + distance / 2);
                index += distance;
            }
        }
        for i in 0..N {
            if self.center_line[i].reserved != 0.0 {
                self.set_cut_limits(i, false);
            }
        }
    }

    // A cut line's reach up to the upper contour and down to the lower or the tongue, whichever is nearer.
    fn set_cut_limits(&mut self, i: usize, mark: bool) {
        let (p, n) = (self.center_line[i].point, self.center_line[i].normal);
        let r0 = self.upper_outline.special_intersection(p, n);
        let r1 = self.lower_outline.closest_intersection(p, n);
        let r2 = self.tongue_outline.closest_intersection(p, n);
        let c = &mut self.center_line[i];
        match r0 {
            Some((t, _)) => c.max = t,
            None => {
                c.max = 3.0;
                if mark {
                    c.reserved = 1.0;
                }
            }
        }
        c.min = match (r1, r2) {
            (Some((t1, _)), Some((t2, _))) => {
                if t1 > t2 {
                    t1
                } else {
                    t2
                }
            }
            (None, Some((t2, _))) => t2,
            (Some((t1, _)), None) => t1,
            (None, None) => {
                if mark {
                    c.reserved = 1.0;
                }
                -3.0
            }
        };
    }

    fn verify_center_line_normal(&mut self, l: usize, m: usize, r: usize) {
        // (The middle line as it was before either check: the C++ tests the right neighbour with it too.)
        let p = self.center_line[m].point;
        let v = self.center_line[m].normal;
        for side in [l, r] {
            let s_ = self.center_line[side];
            let rr = s_.point + s_.min * s_.normal;
            let w = s_.point + s_.max * s_.normal - rr;
            let q = p - rr;
            let denominator = v.x * w.y - v.y * w.x;
            if denominator != 0.0 {
                let s = (v.x * q.y - q.x * v.y) / denominator;
                if (0.0..=1.0).contains(&s) {
                    let t = (w.x * q.y - q.x * w.y) / denominator;
                    let c = &mut self.center_line[m];
                    if t <= 0.0 && t >= c.min {
                        c.normal = c.point - rr;
                        c.normal.normalize();
                        c.reserved = 1.0;
                    } else if t >= 0.0 && t <= c.max {
                        c.normal = rr + w - c.point;
                        c.normal.normalize();
                        c.reserved = 1.0;
                    }
                }
            }
        }
    }

    pub(crate) fn calc_cross_sections(&mut self) {
        let mut upper = [0.0; NUM_PROFILE_SAMPLES];
        let mut lower = [0.0; NUM_PROFILE_SAMPLES];
        let tip_radius = self.anatomy.tongue_tip_radius_cm;
        for i in 0..NUM_CENTERLINE_POINTS {
            let (p, n) = (self.center_line[i].point, self.center_line[i].normal);
            let art = self.cross_profiles(p, n, &mut upper, &mut lower, true);
            let (area, circ) = cross_section_of(&upper, &lower);
            self.cross_section[i] = CrossSection { area, circ, pos: self.center_line[i].pos, articulator: art };
        }
        // The velopharyngeal port: its area and where it is along the center line.
        self.nasal_port_area_cm2 = self.anatomy.max_nasal_port_area_cm2 * self.param[VO].x;
        if self.nasal_port_area_cm2 < 0.0 {
            self.nasal_port_area_cm2 = 0.0;
        }
        let port_rib = NUM_LARYNX_RIBS + NUM_PHARYNX_RIBS;
        let s = &self.surface[UPPER_COVER];
        let port = s.get(port_rib, s.num_rib_points / 2).to_p2();
        self.nasal_port_pos_cm = self.center_line_pos(port).0;
        // The incisors' position along the center line (kept from the last frame where none is found, as the C++).
        const EPSILON: f64 = 0.000001;
        let teeth_x = self.surface[UPPER_TEETH].get(NUM_TEETH_RIBS - 1, 2).x;
        self.incisor_found = false;
        for i in 0..NUM_CENTERLINE_POINTS - 1 {
            let (p, q) = (self.center_line[i].point, self.center_line[i + 1].point);
            if p.x < teeth_x && q.x >= teeth_x {
                let mut t = q.x - p.x;
                if t < EPSILON {
                    t = EPSILON;
                }
                self.incisor_pos_cm = self.center_line[i].pos + ((teeth_x - p.x) / t) * (q - p).magnitude();
                self.incisor_found = true;
            }
        }
        // Right of the tongue tip's front, a cut tongue is the mouth floor.
        let (ttx, tty, tcx) = (self.param[TTX].limited_x, self.param[TTY].limited_x, self.param[TCX].limited_x);
        for i in 0..NUM_CENTERLINE_POINTS {
            let (p, w) = (self.center_line[i].point, self.center_line[i].normal);
            let r = p2(ttx, tty) - p;
            if r.y * w.x - r.x * w.y > tip_radius && p.x > tcx && self.cross_section[i].articulator == Articulator::Tongue {
                self.cross_section[i].articulator = Articulator::Other;
            }
        }
        // Around the upper incisors never under 15 mm^2 (the gaps between the teeth: /f, v/, "th").
        const LEFT_INCISOR_MARGIN_CM: f64 = 0.5;
        const RIGHT_INCISOR_MARGIN_CM: f64 = 0.3;
        const MIN_INCISOR_AREA_CM2: f64 = 0.15;
        for cs in self.cross_section.iter_mut() {
            if cs.pos >= self.incisor_pos_cm - LEFT_INCISOR_MARGIN_CM && cs.pos <= self.incisor_pos_cm + RIGHT_INCISOR_MARGIN_CM && cs.area < MIN_INCISOR_AREA_CM2 {
                cs.area = MIN_INCISOR_AREA_CM2;
                cs.circ = 2.0 * (MIN_INCISOR_AREA_CM2 * PI).sqrt();
            }
        }
        // The tongue sides' bracing keeps a minimum area at the tongue back and at its tip.
        let mut min_area = [0.0; 2];
        min_area[0] = Self::tongue_side_param_to_min_area_cm2(self.param[TS2].x);
        if self.param[TS2].x < 0.0 {
            min_area[0] = 0.0;
        }
        min_area[1] = Self::tongue_side_param_to_min_area_cm2(self.param[TS3].x);
        let min_circ = [2.0 * (min_area[0] * PI).sqrt(), 2.0 * (min_area[1] * PI).sqrt()];
        let mut tongue_tip_right_cm = 0.0;
        let mut lower_lip_left_cm = 1000000.0;
        for cs in self.cross_section.iter() {
            if cs.articulator == Articulator::Tongue {
                tongue_tip_right_cm = cs.pos;
            }
            if cs.articulator == Articulator::LowerLip && cs.pos < lower_lip_left_cm {
                lower_lip_left_cm = cs.pos;
            }
        }
        let tongue_tip_left_cm = tongue_tip_right_cm - 2.0;
        for cs in self.cross_section.iter_mut() {
            if cs.pos <= tongue_tip_left_cm {
                if cs.area < min_area[0] {
                    cs.area = min_area[0];
                }
                if cs.circ < min_circ[0] {
                    cs.circ = min_circ[0];
                }
            }
            if cs.pos >= tongue_tip_left_cm && cs.pos <= lower_lip_left_cm {
                if cs.area < min_area[1] {
                    cs.area = min_area[1];
                }
                if cs.circ < min_circ[1] {
                    cs.circ = min_circ[1];
                }
            }
        }
    }

    /// The cut through the tract along the line p + t v: its upper and lower profiles across the tract (96 samples over
    /// 5.5 cm, INVALID where closed), and the articulator under the midline (getCrossProfiles).
    pub(crate) fn cross_profiles(&mut self, p: P2, v: P2, upper: &mut Profile, lower: &mut Profile, consider_tongue: bool) -> Articulator {
        const MIN_SQUARED_NORMAL_LENGTH: f64 = 0.0000001;
        const INVALID: f64 = INVALID_PROFILE_SAMPLE;
        const N: usize = NUM_PROFILE_SAMPLES;
        const N2: usize = NUM_PROFILE_SAMPLES / 2;
        let mut upper_owner: Owners = [-1; N];
        let mut lower_owner: Owners = [-1; N];
        upper.iter_mut().for_each(|x| *x = EXTREME_PROFILE_VALUE);
        lower.iter_mut().for_each(|x| *x = -EXTREME_PROFILE_VALUE);
        let mut cuts = std::mem::take(&mut self.scratch_cuts);
        let mut list = std::mem::take(&mut self.scratch_list);
        let mended = self.mended;
        cuts.clear();
        for &g in PROFILE_SURFACES.iter() {
            if consider_tongue || (g != UVULA && g != EPIGLOTTIS) {
                if !self.intersections_prepared[g] {
                    self.surface[g].prepare_intersections();
                    self.intersections_prepared[g] = true;
                }
                let s = &mut self.surface[g];
                s.prepare_intersection(p, v);
                s.triangle_list(&mut list, if mended { usize::MAX } else { MAX_LIST_ENTRIES });
                for &t in list.iter() {
                    if let Some((p0, p1, n)) = s.triangle_intersection(t) {
                        // (The C++ tests P1.y against the lower bound twice and P0.y not at all; mended, P0.)
                        let p0_above = if mended { p0.y > MIN_PROFILE_VALUE } else { p1.y > MIN_PROFILE_VALUE };
                        if cuts.len() < MAX_CUTS && p0.y < MAX_PROFILE_VALUE && p1.y < MAX_PROFILE_VALUE && p1.y > MIN_PROFILE_VALUE && p0_above {
                            cuts.push(Cut { p0, p1, n, surface: g });
                        }
                    }
                }
            }
        }
        // How the teeth and lips were cut.
        let mut upper_teeth_max_y = -EXTREME_PROFILE_VALUE;
        let mut lower_teeth_min_y = EXTREME_PROFILE_VALUE;
        let mut upper_lip_min_y = EXTREME_PROFILE_VALUE;
        let mut lower_lip_max_y = -EXTREME_PROFILE_VALUE;
        for c in cuts.iter() {
            let (y0, y1) = (c.p0.y, c.p1.y);
            match c.surface {
                UPPER_TEETH => upper_teeth_max_y = upper_teeth_max_y.max_c(y0).max_c(y1),
                LOWER_TEETH => lower_teeth_min_y = lower_teeth_min_y.min_c(y0).min_c(y1),
                UPPER_LIP => upper_lip_min_y = upper_lip_min_y.min_c(y0).min_c(y1),
                LOWER_LIP => lower_lip_max_y = lower_lip_max_y.max_c(y0).max_c(y1),
                _ => {}
            }
        }
        let both_teeth_cut = upper_teeth_max_y > lower_teeth_min_y;
        let both_lips_cut = upper_lip_min_y != EXTREME_PROFILE_VALUE && lower_lip_max_y != -EXTREME_PROFILE_VALUE;
        for c in cuts.iter() {
            let (p0, p1, n, g) = (c.p0, c.p1, c.n, c.surface);
            match g {
                UPPER_COVER | UPPER_TEETH | UPPER_LIP | UVULA => {
                    if n.y < 0.0 {
                        insert_upper(p0, p1, g, upper, &mut upper_owner);
                    }
                }
                LOWER_COVER => {
                    if n.y > 0.0 {
                        insert_lower_cover(p0, p1, g, upper, &mut upper_owner, lower, &mut lower_owner);
                    }
                }
                LOWER_TEETH | LOWER_LIP | EPIGLOTTIS => {
                    if n.y > 0.0 {
                        insert_lower(p0, p1, g, lower, &mut lower_owner);
                    }
                }
                _ => {
                    // (The fill and the radiation surface, upper or lower by their normal, but not where the cut line
                    // points into the lower pharynx.)
                    let right_orientation = !(v.x < 0.0 && v.y < 0.0);
                    if n.x * n.x + n.y * n.y > MIN_SQUARED_NORMAL_LENGTH && right_orientation {
                        if n.y <= 0.0 {
                            insert_upper(p0, p1, g, upper, &mut upper_owner);
                        } else if n.y >= 0.0 {
                            insert_lower(p0, p1, g, lower, &mut lower_owner);
                        }
                    }
                }
            }
        }
        self.scratch_cuts = cuts;
        for i in 0..N2 {
            if upper[i] == EXTREME_PROFILE_VALUE {
                upper[i] = INVALID;
            }
            if lower[i] == -EXTREME_PROFILE_VALUE {
                lower[i] = INVALID;
            }
        }
        // Lateral of the teeth, no higher than their lower edge (and the lower likewise), median to lateral.
        let mut upper_limit = 1000000.0;
        let mut lower_limit = -1000000.0;
        for i in (0..N2).rev() {
            if upper[i] != INVALID {
                if upper_owner[i] == UPPER_TEETH as i32 && upper[i] < upper_limit {
                    upper_limit = upper[i];
                }
                if upper[i] > upper_limit {
                    upper[i] = upper_limit;
                }
            }
            if lower[i] != INVALID {
                if lower_owner[i] == LOWER_TEETH as i32 && lower[i] > lower_limit {
                    lower_limit = lower[i];
                }
                if lower[i] < lower_limit {
                    lower[i] = lower_limit;
                }
            }
        }
        let mut last = INVALID;
        for x in upper.iter_mut().take(N2) {
            if *x == INVALID {
                *x = last;
            } else {
                last = *x;
            }
        }
        let first_upper_valid = (0..N2).find(|&i| upper[i] != INVALID);
        let first_lower_valid = (0..N2).find(|&i| lower[i] != INVALID);
        if first_lower_valid.is_none() {
            for x in lower.iter_mut().take(N2).skip(first_upper_valid.unwrap_or(0)) {
                *x = MIN_PROFILE_VALUE;
            }
        } else {
            let mut i = N2 - 1;
            while i > 0 && lower[i] == INVALID {
                lower[i] = MIN_PROFILE_VALUE;
                i -= 1;
            }
        }
        let (mut left, mut right) = (0usize, 0usize);
        for i in 0..N2 {
            if lower[i] == INVALID {
                if i <= left || i >= right {
                    left = i;
                    right = i;
                    while lower[left] == INVALID && left > 0 {
                        left -= 1;
                    }
                    while lower[right] == INVALID && right < N2 - 1 {
                        right += 1;
                    }
                }
                if i > left && i < right {
                    if lower[left] != INVALID && lower[right] != INVALID {
                        lower[i] = lower[left] + (i - left) as f64 * (lower[right] - lower[left]) / (right - left) as f64;
                    } else if lower[left] != INVALID {
                        lower[i] = lower[left];
                    }
                }
            }
        }
        for i in 0..N2 {
            if lower[i] != INVALID && upper[i] != INVALID && lower[i] > upper[i] {
                lower[i] = upper[i];
            }
        }
        let mut upper_left = 0;
        while upper[upper_left] == INVALID && upper_left < N2 - 1 {
            upper_left += 1;
        }
        let mut lower_left = 0;
        while lower[lower_left] == INVALID && lower_left < N2 - 1 {
            lower_left += 1;
        }
        let mut leftmost = N2 - 1;
        if upper[upper_left] != INVALID && upper_left < leftmost {
            leftmost = upper_left;
        }
        if lower[lower_left] != INVALID && lower_left < leftmost {
            leftmost = lower_left;
        }
        if upper[upper_left] == INVALID {
            upper[upper_left] = MAX_PROFILE_VALUE;
        }
        if lower[lower_left] == INVALID {
            lower[lower_left] = MIN_PROFILE_VALUE;
        }
        if upper_left < lower_left {
            for i in upper_left..lower_left {
                lower[i] = lower[lower_left];
            }
        } else {
            for i in lower_left..upper_left {
                upper[i] = upper[upper_left];
            }
        }
        // Lips both cut and closed at the midline: the whole profile closed.
        if both_lips_cut && !both_teeth_cut && upper[N2 - 1] == lower[N2 - 1] {
            for i in 0..N2 {
                if upper[i] != INVALID && lower[i] != INVALID {
                    let d = 0.5 * (lower[i] + upper[i]);
                    lower[i] = d;
                    upper[i] = d;
                }
            }
        }
        for i in 0..=N2 {
            upper[N - 1 - i] = upper[i];
            lower[N - 1 - i] = lower[i];
        }
        let mut rightmost = N - 1 - leftmost;
        if consider_tongue {
            let mut tongue: Profile = [-EXTREME_PROFILE_VALUE; N];
            let mut tongue_owner: Owners = [-1; N];
            if !self.intersections_prepared[TONGUE] {
                self.surface[TONGUE].prepare_intersections();
                self.intersections_prepared[TONGUE] = true;
            }
            let s = &mut self.surface[TONGUE];
            s.prepare_intersection(p, v);
            s.triangle_list(&mut list, if self.mended { usize::MAX } else { MAX_LIST_ENTRIES });
            for &t in list.iter() {
                if let Some((p0, p1, n)) = s.triangle_intersection(t) {
                    if n.y >= 0.0 {
                        insert_lower(p0, p1, TONGUE, &mut tongue, &mut tongue_owner);
                    }
                }
            }
            for x in tongue.iter_mut() {
                if *x == -EXTREME_PROFILE_VALUE {
                    *x = INVALID;
                }
            }
            let (mut left, mut right) = (0usize, 0usize);
            for i in 0..N {
                if tongue[i] == INVALID {
                    if i <= left || i >= right {
                        left = i;
                        right = i;
                        while tongue[left] == INVALID && left > 0 {
                            left -= 1;
                        }
                        while tongue[right] == INVALID && right < N - 1 {
                            right += 1;
                        }
                    }
                    if right > left {
                        if tongue[left] != INVALID && tongue[right] != INVALID {
                            tongue[i] = tongue[left] + (i - left) as f64 * (tongue[right] - tongue[left]) / (right - left) as f64;
                        } else if tongue[left] != INVALID {
                            tongue[i] = tongue[left];
                        } else if tongue[right] != INVALID {
                            tongue[i] = tongue[right];
                        }
                    }
                }
            }
            for i in leftmost..=rightmost {
                if tongue[i] != INVALID && lower[i] != INVALID && tongue[i] > lower[i] {
                    lower[i] = tongue[i];
                    lower_owner[i] = tongue_owner[i];
                }
            }
            while leftmost < N2 && lower[leftmost] > upper[leftmost] - 0.1 {
                leftmost += 1;
            }
            while rightmost > N2 && lower[rightmost] > upper[rightmost] - 0.1 {
                rightmost -= 1;
            }
            for i in 0..N {
                if i >= leftmost && i <= rightmost {
                    if lower[i] > upper[i] {
                        lower[i] = upper[i];
                    }
                } else {
                    lower[i] = INVALID;
                    upper[i] = INVALID;
                }
            }
        }
        self.scratch_list = list;
        // From the middle outward to the first opening wider than 1 mm, then only as long as it stays open.
        const OPEN_THRESHOLD: f64 = 0.1;
        const CUTOFF_THRESHOLD: f64 = 0.01;
        let mut i = N2 as i32 - 1;
        while upper[i as usize] - lower[i as usize] < OPEN_THRESHOLD && i > 0 {
            i -= 1;
        }
        while upper[i as usize] - lower[i as usize] >= CUTOFF_THRESHOLD && i > 0 {
            i -= 1;
        }
        while i >= 0 {
            upper[i as usize] = INVALID;
            lower[i as usize] = INVALID;
            i -= 1;
        }
        let mut i = N2 - 1;
        while upper[i] - lower[i] < OPEN_THRESHOLD && i < N - 1 {
            i += 1;
        }
        while upper[i] - lower[i] >= CUTOFF_THRESHOLD && i < N - 1 {
            i += 1;
        }
        while i <= N - 1 {
            upper[i] = INVALID;
            lower[i] = INVALID;
            i += 1;
        }
        let mut leftmost = 0;
        while (upper[leftmost] == INVALID || lower[leftmost] == INVALID) && leftmost < N2 - 1 {
            leftmost += 1;
        }
        if upper[leftmost] != INVALID && lower[leftmost] != INVALID {
            let m = 0.5 * (upper[leftmost] + lower[leftmost]);
            upper[leftmost] = m;
            lower[leftmost] = m;
        }
        let mut rightmost = N - 1;
        while (upper[rightmost] == INVALID || lower[rightmost] == INVALID) && rightmost > N2 {
            rightmost -= 1;
        }
        if upper[rightmost] != INVALID && lower[rightmost] != INVALID {
            let m = 0.5 * (upper[rightmost] + lower[rightmost]);
            upper[rightmost] = m;
            lower[rightmost] = m;
        }
        // The articulator under the midline: the two most median samples' owners.
        const CHECK_RANGE_CM: f64 = 0.5;
        let num_check = (CHECK_RANGE_CM / PROFILE_SAMPLE_LENGTH) as usize;
        let (mut has_tongue, mut has_lower_lip, mut has_lower_teeth) = (false, false, false);
        for i in 1..num_check {
            let o = lower_owner[N2 - i];
            if o == TONGUE as i32 {
                has_tongue = true;
            } else if o == LOWER_LIP as i32 || o == RADIATION as i32 {
                has_lower_lip = true;
            } else if o == LOWER_TEETH as i32 {
                has_lower_teeth = true;
            }
        }
        if has_lower_teeth {
            Articulator::LowerIncisors
        } else if has_lower_lip {
            Articulator::LowerLip
        } else if has_tongue {
            Articulator::Tongue
        } else {
            Articulator::Other
        }
    }

    pub(crate) fn cross_sections_to_tube_sections(&mut self) {
        const EPSILON: f64 = 0.000001;
        const N: usize = NUM_CENTERLINE_POINTS;
        for i in 0..NUM_PHARYNX_SECTIONS {
            self.tube_section[i].pos = self.nasal_port_pos_cm * i as f64 / NUM_PHARYNX_SECTIONS as f64;
        }
        const NUM_MOUTH: usize = NUM_TUBE_SECTIONS - NUM_PHARYNX_SECTIONS;
        let mouth_length = self.center_line_length - self.nasal_port_pos_cm;
        let first = mouth_length / 16.0;
        let last = mouth_length / 32.0;
        let im = NUM_MOUTH as f64;
        let im2 = im * NUM_MOUTH as f64;
        let im3 = im2 * NUM_MOUTH as f64;
        let im4 = im3 * NUM_MOUTH as f64;
        let a1 = first;
        let a2 = ((mouth_length - a1 * im) * 3.0 * im2 - im3 * (last - a1)) / im4;
        let a3 = (im2 * (last - a1) - 2.0 * im * (mouth_length - a1 * im)) / im4;
        for i in NUM_PHARYNX_SECTIONS..NUM_TUBE_SECTIONS {
            let k = (i - NUM_PHARYNX_SECTIONS) as f64;
            self.tube_section[i].pos = self.nasal_port_pos_cm + a1 * k + a2 * k * k + a3 * k * k * k;
        }
        for i in 0..NUM_TUBE_SECTIONS {
            self.tube_section[i].length = if i < NUM_TUBE_SECTIONS - 1 { self.tube_section[i + 1].pos - self.tube_section[i].pos } else { self.center_line_length - self.tube_section[i].pos };
        }
        const EXTREME: f64 = 1000000.0;
        let cs = &self.cross_section;
        let (mut li, mut ri) = (0usize, 0usize);
        for i in 0..NUM_TUBE_SECTIONS {
            let left_x = self.tube_section[i].pos;
            let right_x = left_x + self.tube_section[i].length;
            while cs[li].pos > left_x && li > 0 {
                li -= 1;
            }
            while cs[li + 1].pos < left_x && li < N - 2 {
                li += 1;
            }
            while cs[ri].pos > right_x && ri > 0 {
                ri -= 1;
            }
            while cs[ri + 1].pos < right_x && ri < N - 2 {
                ri += 1;
            }
            // (Its articulator the narrowest cross-section's within it.)
            let articulator = if li == ri {
                cs[li].articulator
            } else {
                let mut m = li + 1;
                for k in li + 1..=ri {
                    if cs[k].area < cs[m].area {
                        m = k;
                    }
                }
                cs[m].articulator
            };
            let (mut area, mut circ) = (EXTREME, EXTREME);
            for k in li..=ri {
                if k == li && k == ri {
                    let mut length = cs[li + 1].pos - cs[li].pos;
                    if length < EPSILON {
                        length = EPSILON;
                    }
                    let d = cs[li + 1].area - cs[li].area;
                    area = area.min_c(cs[li].area + d * (left_x - cs[li].pos) / length).min_c(cs[li].area + d * (right_x - cs[li].pos) / length);
                    let d = cs[li + 1].circ - cs[li].circ;
                    circ = circ.min_c(cs[li].circ + d * (left_x - cs[li].pos) / length).min_c(cs[li].circ + d * (right_x - cs[li].pos) / length);
                } else if k == li {
                    let mut length = cs[li + 1].pos - cs[li].pos;
                    if length < EPSILON {
                        length = EPSILON;
                    }
                    let d = cs[li + 1].area - cs[li].area;
                    area = area.min_c(cs[li].area + d * (left_x - cs[li].pos) / length).min_c(cs[li + 1].area);
                    let d = cs[li + 1].circ - cs[li].circ;
                    circ = circ.min_c(cs[li].circ + d * (left_x - cs[li].pos) / length).min_c(cs[li + 1].circ);
                } else if k == ri {
                    let mut length = cs[ri + 1].pos - cs[ri].pos;
                    if length < EPSILON {
                        length = EPSILON;
                    }
                    let d = cs[ri + 1].area - cs[ri].area;
                    area = area.min_c(cs[ri].area).min_c(cs[ri].area + d * (right_x - cs[ri].pos) / length);
                    let d = cs[ri + 1].circ - cs[ri].circ;
                    circ = circ.min_c(cs[ri].circ).min_c(cs[ri].circ + d * (right_x - cs[ri].pos) / length);
                } else {
                    area = area.min_c(cs[k].area).min_c(cs[k + 1].area);
                    circ = circ.min_c(cs[k].circ).min_c(cs[k + 1].circ);
                }
            }
            let ts = &mut self.tube_section[i];
            ts.articulator = articulator;
            ts.area = area;
            ts.circ = circ;
        }
    }

    /// The tube this frame's geometry makes (VocalTract::getTube).
    pub fn tube(&self) -> TractTube {
        let mut t = TractTube {
            length_cm: [0.0; NUM_TUBE_SECTIONS],
            area_cm2: [0.0; NUM_TUBE_SECTIONS],
            articulator: [Articulator::Other; NUM_TUBE_SECTIONS],
            incisor_pos_cm: self.incisor_pos_cm,
            incisor_found: self.incisor_found,
            tongue_tip_side_elevation: self.param[TS3].x,
            velum_opening_cm2: self.nasal_port_area_cm2,
            fossa_length_cm: self.anatomy.piriform_fossa_length_cm,
            fossa_volume_cm3: self.anatomy.piriform_fossa_volume_cm3,
            subglottal_length_cm: self.anatomy.subglottal_cavity_length_cm,
            nasal_length_cm: self.anatomy.nasal_cavity_length_cm,
        };
        for (i, ts) in self.tube_section.iter().enumerate() {
            t.length_cm[i] = ts.length;
            t.area_cm2[i] = ts.area;
            t.articulator[i] = ts.articulator;
        }
        t
    }

    /// The position along the center line nearest q, with the segment and parameter found (getCenterLinePos).
    pub fn center_line_pos(&self, q: P2) -> (f64, usize, f64) {
        const EPSILON: f64 = 0.000001;
        const N: usize = NUM_CENTERLINE_POINTS;
        let mut min_dist = 1000000.0;
        let mut best_index: i32 = -1;
        let mut best_t = 0.0;
        for i in 0..N - 1 {
            let mut p0 = self.center_line[i].point;
            let n0 = self.center_line[i].normal;
            let mut p1 = self.center_line[i + 1].point;
            let n1 = self.center_line[i + 1].normal;
            let v = (p1 - p0) * EPSILON;
            p0 -= v;
            p1 += v;
            if (q.x - p0.x) * n0.y - n0.x * (q.y - p0.y) >= 0.0 && (q.x - p1.x) * n1.y - n1.x * (q.y - p1.y) <= 0.0 {
                let v = p1 - p0;
                let r = q - p0;
                let m = n1 - n0;
                let mut denominator = v.y * m.x - v.x * m.y;
                if denominator == 0.0 {
                    denominator = EPSILON;
                }
                let p = (r.x * m.y - r.y * m.x + v.y * n0.x - v.x * n0.y) / denominator;
                let mut qq = (r.x * n0.y - r.y * n0.x) / denominator;
                qq = 0.25 * p * p - qq;
                if qq < 0.0 {
                    qq = 0.0;
                }
                qq = qq.sqrt();
                let t0 = -0.5 * p + qq;
                let t1 = -0.5 * p - qq;
                let t = if t0 > -EPSILON && t0 < 1.0 + EPSILON { t0 } else { t1 };
                let r = p0 + v * t;
                let dist = (q - r).magnitude();
                if dist < min_dist {
                    min_dist = dist;
                    best_index = i as i32;
                    best_t = t;
                }
            }
        }
        if best_index == -1 {
            best_index = 0;
            for i in 0..N {
                let dist = (self.center_line[i].point - q).magnitude();
                if dist < min_dist {
                    min_dist = dist;
                    best_index = i as i32;
                    best_t = 0.0;
                }
            }
        }
        let mut bi = best_index as usize;
        if bi == N - 1 {
            bi = N - 2;
            best_t = 1.0;
        }
        (self.center_line[bi].pos + best_t * (self.center_line[bi + 1].pos - self.center_line[bi].pos), bi, best_t)
    }
}

/// A cross-section's area and perimeter from its profiles (getCrossSection).
pub(crate) fn cross_section_of(upper: &Profile, lower: &Profile) -> (f64, f64) {
    const INVALID: f64 = INVALID_PROFILE_SAMPLE;
    let d2 = PROFILE_SAMPLE_LENGTH * PROFILE_SAMPLE_LENGTH;
    let (mut area, mut circ) = (0.0, 0.0);
    for i in 0..NUM_PROFILE_SAMPLES - 1 {
        if upper[i] != INVALID && upper[i + 1] != INVALID && lower[i] != INVALID && lower[i + 1] != INVALID {
            let a = upper[i] - lower[i];
            let b = upper[i + 1] - lower[i + 1];
            area += 0.5 * (a + b) * PROFILE_SAMPLE_LENGTH;
            let a = upper[i + 1] - upper[i];
            let b = lower[i + 1] - lower[i];
            circ += (a * a + d2).sqrt() + (b * b + d2).sqrt();
        }
    }
    (area, circ)
}

/// The C++'s `if (y < m) m = y;` and `if (y > m) m = y;` (f64::min and max treat NaN otherwise).
pub(crate) trait CMinMax {
    fn min_c(self, y: f64) -> f64;
    fn max_c(self, y: f64) -> f64;
}
impl CMinMax for f64 {
    #[inline]
    fn min_c(self, y: f64) -> f64 {
        if y < self {
            y
        } else {
            self
        }
    }
    #[inline]
    fn max_c(self, y: f64) -> f64 {
        if y > self {
            y
        } else {
            self
        }
    }
}
