// What a piece of work costs the processor, counted by the processor (the owner, 12 November 2026: "We need a more
// efficient and reliable benchmarking approach than raw timing on this machine"; "There are never going to be 'perfect
// machine conditions'"). Wall-clock time on a shared Mac measures the other sessions' runs as much as the code: under
// a load of 9 the same step timed 5.6 us one hour and 12 the next. The kernel keeps, for each thread, the instructions
// it retired and the cycles it ran, on the performance cores and on the efficiency cores apart, with its time on core
// and its energy (xnu's per-thread counts, proc_pidinfo PROC_PIDTHREADCOUNTS, macOS 13 on): counted only while the
// thread runs, so that time it waits for a core is not in them, and in cycles, so that the clock's speed is not either.
// Instructions are the same from run to run; cycles move a few percent with what shares the core's caches. A short run
// is enough. Elsewhere than macOS, none are counted (`Counts::now` gives None). Every thread of the process is counted
// so as well (`threads`), each by its name: what the live voice reads of itself as it plays (src/stream.rs, Reading).

/// One kind of core's counts.
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct Level {
    pub instructions: u64,
    pub cycles: u64,
    /// Time on core, user and system (ns).
    pub time_ns: u64,
    pub energy_nj: u64,
}

/// The calling thread's counts since it began: [performance cores, efficiency cores].
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct Counts {
    pub levels: [Level; 2],
}

/// One of this process's threads: its id, its name (where it was given one) and its counts since it began.
#[derive(Clone, Debug, Default)]
pub struct Thread {
    pub id: u64,
    pub name: String,
    pub counts: Counts,
}

/// Every thread of this process, counted (none elsewhere than macOS).
pub fn threads() -> Vec<Thread> {
    #[cfg(target_os = "macos")]
    {
        mac::threads()
    }
    #[cfg(not(target_os = "macos"))]
    {
        Vec::new()
    }
}

/// The calling thread's id, as `threads` gives it (0 elsewhere than macOS).
pub fn thread_id() -> u64 {
    #[cfg(target_os = "macos")]
    {
        mac::thread_id()
    }
    #[cfg(not(target_os = "macos"))]
    {
        0
    }
}

/// Asks that the calling thread, and the threads it starts after, be run on the performance cores where they can be
/// (macOS's user-interactive quality of service: what a live instrument's audio is): the work the same, the cores it is
/// given others -- so that what it costs, and whether it keeps up, is the performance cores' (the efficiency cores take
/// two to three times the cycles, and a loaded Mac moves a thread of default service to them). Elsewhere, nothing.
pub fn prefer_performance_cores() {
    #[cfg(target_os = "macos")]
    {
        extern "C" {
            fn pthread_set_qos_class_self_np(qos_class: u32, relative_priority: i32) -> i32;
        }
        const QOS_CLASS_USER_INTERACTIVE: u32 = 0x21;
        // SAFETY: it sets the calling thread's own class, given a valid one.
        unsafe {
            pthread_set_qos_class_self_np(QOS_CLASS_USER_INTERACTIVE, 0);
        }
    }
}

/// Asks that the calling thread be run where it keeps out of the sound's way (macOS's utility quality of service: the
/// efficiency cores where the performance cores are wanted): for work beside a live voice that it may wait on but that
/// must never make it wait, such as its vowel space sounded as it starts. A thread started after
/// `prefer_performance_cores` takes that class with it, and would take a performance core from the sound. Elsewhere,
/// nothing.
pub fn leave_the_performance_cores() {
    #[cfg(target_os = "macos")]
    {
        extern "C" {
            fn pthread_set_qos_class_self_np(qos_class: u32, relative_priority: i32) -> i32;
        }
        const QOS_CLASS_UTILITY: u32 = 0x11;
        // SAFETY: it sets the calling thread's own class, given a valid one.
        unsafe {
            pthread_set_qos_class_self_np(QOS_CLASS_UTILITY, 0);
        }
    }
}

#[cfg(target_os = "macos")]
mod mac {
    #[repr(C)]
    struct Timebase {
        numer: u32,
        denom: u32,
    }
    extern "C" {
        fn proc_pidinfo(pid: i32, flavor: i32, arg: u64, buffer: *mut u8, size: i32) -> i32;
        fn pthread_threadid_np(thread: usize, id: *mut u64) -> i32;
        fn getpid() -> i32;
        fn mach_timebase_info(info: *mut Timebase) -> i32;
    }
    /// (xnu's bsd/sys/proc_info_private.h: PROC_PIDTHREADCOUNTS; its record a u16 count of levels, six bytes reserved,
    /// then per level five u64: instructions, cycles, user and system time in mach units, energy in nJ.)
    const PROC_PIDTHREADCOUNTS: i32 = 34;

    /// (xnu's bsd/sys/proc_info_private.h: its threads' ids, as PROC_PIDTHREADCOUNTS takes them; and bsd/sys/proc_info.h:
    /// a thread's information by its id, its name 64 bytes from its 48th.)
    const PROC_PIDLISTTHREADIDS: i32 = 28;
    const PROC_PIDTHREADID64INFO: i32 = 15;

    pub fn thread_id() -> u64 {
        let mut tid = 0u64;
        // SAFETY: it writes the calling thread's id into the u64 it is given.
        unsafe {
            pthread_threadid_np(0, &mut tid);
        }
        tid
    }

    pub fn now() -> Option<super::Counts> {
        of(thread_id())
    }

    /// A thread of this process's counts, by its id.
    fn of(tid: u64) -> Option<super::Counts> {
        let mut buf = [0u8; 8 + 4 * 40];
        let mut timebase = Timebase { numer: 0, denom: 0 };
        // SAFETY: each call writes only into the buffer it is given, of the size it is told.
        let n = unsafe {
            mach_timebase_info(&mut timebase);
            proc_pidinfo(getpid(), PROC_PIDTHREADCOUNTS, tid, buf.as_mut_ptr(), buf.len() as i32)
        };
        let levels = u16::from_le_bytes([buf[0], buf[1]]) as usize;
        if n < 8 + 40 || levels == 0 || timebase.denom == 0 {
            return None;
        }
        let word = |at: usize| u64::from_le_bytes(buf[at..at + 8].try_into().unwrap());
        let mut c = super::Counts::default();
        for l in 0..levels.min(2) {
            let at = 8 + l * 40;
            let mach = word(at + 16) + word(at + 24);
            c.levels[l] = super::Level { instructions: word(at), cycles: word(at + 8), time_ns: (mach as u128 * timebase.numer as u128 / timebase.denom as u128) as u64, energy_nj: word(at + 32) };
        }
        Some(c)
    }

    pub fn threads() -> Vec<super::Thread> {
        let mut ids = [0u64; 256];
        // SAFETY: as above.
        let bytes = unsafe { proc_pidinfo(getpid(), PROC_PIDLISTTHREADIDS, 0, ids.as_mut_ptr() as *mut u8, (8 * ids.len()) as i32) };
        ids[..(bytes.max(0) as usize / 8).min(ids.len())]
            .iter()
            .filter_map(|&id| {
                let counts = of(id)?;
                let mut info = [0u8; 112];
                // SAFETY: as above.
                let n = unsafe { proc_pidinfo(getpid(), PROC_PIDTHREADID64INFO, id, info.as_mut_ptr(), info.len() as i32) };
                let name = &info[48..112];
                let name = if n as usize >= info.len() { String::from_utf8_lossy(&name[..name.iter().position(|&b| b == 0).unwrap_or(64)]).into_owned() } else { String::new() };
                Some(super::Thread { id, name, counts })
            })
            .collect()
    }
}

impl Counts {
    /// The calling thread's counts now.
    pub fn now() -> Option<Counts> {
        #[cfg(target_os = "macos")]
        {
            mac::now()
        }
        #[cfg(not(target_os = "macos"))]
        {
            None
        }
    }

    /// What was counted between `earlier` and this.
    pub fn since(&self, earlier: &Counts) -> Counts {
        let mut c = Counts::default();
        for l in 0..2 {
            let (a, b) = (&self.levels[l], &earlier.levels[l]);
            c.levels[l] = Level { instructions: a.instructions - b.instructions, cycles: a.cycles - b.cycles, time_ns: a.time_ns - b.time_ns, energy_nj: a.energy_nj - b.energy_nj };
        }
        c
    }

    /// Instructions retired, on either kind of core.
    pub fn instructions(&self) -> u64 {
        self.levels[0].instructions + self.levels[1].instructions
    }

    /// The share of its instructions retired on the performance cores.
    pub fn performance_share(&self) -> f64 {
        self.levels[0].instructions as f64 / self.instructions().max(1) as f64
    }

    /// Cycles an instruction on a kind of core (0 performance, 1 efficiency), where it ran any.
    pub fn cycles_per_instruction(&self, level: usize) -> Option<f64> {
        let l = &self.levels[level];
        (l.instructions > 0).then(|| l.cycles as f64 / l.instructions as f64)
    }

    /// A kind of core's clock while the thread ran on it (Hz), where it ran long enough to tell (a millisecond).
    pub fn clock_hz(&self, level: usize) -> Option<f64> {
        let l = &self.levels[level];
        (l.time_ns > 1_000_000).then(|| l.cycles as f64 / (l.time_ns as f64 * 1e-9))
    }

    /// The work's cycles had it all run on the performance cores: theirs, and the efficiency cores' instructions at the
    /// performance cores' cycles an instruction (None where none ran there).
    pub fn performance_cycles(&self) -> Option<f64> {
        let cpi = self.cycles_per_instruction(0)?;
        Some(self.levels[0].cycles as f64 + self.levels[1].instructions as f64 * cpi)
    }

    /// The seconds the work needs on a performance core: its cycles there (the efficiency cores' instructions at its
    /// cycles an instruction) at its clock; where it ran none there, its time on core.
    pub fn core_seconds(&self) -> f64 {
        match (self.performance_cycles(), self.clock_hz(0)) {
            (Some(cycles), Some(clock)) => cycles / clock,
            _ => (self.levels[0].time_ns + self.levels[1].time_ns) as f64 * 1e-9,
        }
    }

    /// One line: per `units` of work (steps, frames), its instructions, its cycles on a performance core and the time
    /// they take at `clock_hz` (the performance cores' clock; None: as it ran), and the share it ran there.
    pub fn report(&self, units: f64, unit: &str, clock_hz: Option<f64>) -> String {
        let instructions = self.instructions() as f64 / units;
        match (self.performance_cycles(), clock_hz.or(self.clock_hz(0))) {
            (Some(cycles), Some(clock)) => format!(
                "{instructions:.0} instructions a {unit}, {:.0} cycles on a performance core ({:.3} us at {:.2} GHz; {:.0}% of it run there)",
                cycles / units,
                cycles / units / clock * 1e6,
                clock * 1e-9,
                100.0 * self.performance_share()
            ),
            _ => format!("{instructions:.0} instructions a {unit} (none run on a performance core long enough to count)"),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_thread_counts_its_own_work() {
        let Some(a) = Counts::now() else { return };
        let mut x = 1.0f64;
        for i in 0..2_000_000u64 {
            x = x * 1.000_000_1 + (i & 1) as f64 * 1e-9;
        }
        let b = Counts::now().unwrap().since(&a);
        assert!(x > 1.0);
        // (Two million rounds of a multiply, an add and the loop's own: several million instructions, a cycle or more
        // each, the multiply-add's latency their bound.)
        assert!(b.instructions() > 4_000_000, "{b:?}");
        assert!(b.levels[0].cycles + b.levels[1].cycles > 2_000_000, "{b:?}");
    }

    #[test]
    fn every_thread_counted_by_its_name() {
        if Counts::now().is_none() {
            return;
        }
        let (tx, rx) = std::sync::mpsc::channel();
        let (go, wait) = std::sync::mpsc::channel::<()>();
        let worker = std::thread::Builder::new()
            .name("counted-worker".into())
            .spawn(move || {
                tx.send(thread_id()).unwrap();
                let _ = wait.recv();
            })
            .unwrap();
        let id = rx.recv().unwrap();
        let all = threads();
        go.send(()).unwrap();
        worker.join().unwrap();
        assert!(all.iter().any(|t| t.id == thread_id()), "{all:?}");
        let w = all.iter().find(|t| t.id == id).expect("the worker among them");
        assert_eq!(w.name, "counted-worker");
    }
}
