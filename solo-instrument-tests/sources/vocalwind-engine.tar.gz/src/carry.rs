// A shape carried from a VocalTractLab 2.3 speaker to a 2.4 speaker by its area function (research/VOCALWIND_LANGUAGES.md,
// design 2; the owner, 14 November 2026: "Yes, proceed, and you have permission to do the speaker-recovery."). The
// source's sections from the glottis to the lips, each place taken as its fraction of the tract's length; the target's
// 19 parameters (its velum's opening held at the source's) chosen by least squares (Levenberg-Marquardt) so its own
// sections, at the same fractions, have the same areas -- each of `INTERVALS` equal stretches' mean area compared by its
// logarithm, so that a constriction weighs as much as an open cavity -- within the parameters' ranges. Computed on each
// engine's own geometry: the source's 2.3 tract (tract.rs) and the target's 2.4 tract (v24/tract.rs). What the carried
// shape sounds like is checked by the 2.4 engine's own acoustics (`resonances`). Where a carried shape's resonances miss
// its measured area function's on the same tube, they can be tuned on the engine itself (`tune`; the owner, 15 November
// 2026, of the design in research/VOCALWIND_LANGUAGES.md, "Rhotic vowels": "Yes, proceed"), by the settings in
// languages/carry.json.
use crate::inventory::language_file;
use crate::speaker_fit::cholesky_solve;
use crate::tract::VocalTract as Tract23;
use crate::v24::tds::{Options, TdsModel};
use crate::v24::tract::{TractTube, VocalTract as Tract24, NUM_PARAMS, VO};
use crate::v24::tube::{Articulator, Tube, FIRST_PHARYNX_SECTION, MIN_AREA_CM2};
use serde::Deserialize;
use std::sync::OnceLock;

/// How many equal stretches of the tract's length the area functions are compared over: at 400, a 2.4 speaker's own
/// vowel laid on its own tube by its profile keeps its first four resonances within 40 cents (JD2; at 100, the fourth
/// moved up to 113), the larynx's short sections being the finest of its features.
pub const INTERVALS: usize = 400;

/// An area function: the tract's length and each equal stretch's mean area (its volume over its length), by its log.
#[derive(Clone, Debug)]
pub struct Profile {
    pub length_cm: f64,
    pub log_area: Vec<f64>,
}

/// Each stretch's mean area (its volume over its length) of sections laid end to end from the glottis, the stretches'
/// edges given as places along them (from 0 to their whole length).
pub fn mean_areas(lengths_cm: &[f64], areas_cm2: &[f64], edges: &[f64]) -> Vec<f64> {
    let mut volume = vec![0.0; edges.len() - 1];
    let mut at = 0.0;
    for (&l, &a) in lengths_cm.iter().zip(areas_cm2) {
        // (Each section's volume shared among the stretches it overlaps.)
        let (begin, end) = (at, at + l);
        for (k, v) in volume.iter_mut().enumerate() {
            let overlap = end.min(edges[k + 1]) - begin.max(edges[k]);
            if overlap > 0.0 {
                *v += overlap * a;
            }
        }
        at = end;
    }
    volume.iter().enumerate().map(|(k, v)| v / (edges[k + 1] - edges[k])).collect()
}

/// The profile of sections end to end from the glottis (their lengths and areas), over `n` equal stretches.
pub fn profile(lengths_cm: &[f64], areas_cm2: &[f64], n: usize) -> Profile {
    let length_cm: f64 = lengths_cm.iter().sum();
    let edges: Vec<f64> = (0..=n).map(|k| length_cm * k as f64 / n as f64).collect();
    Profile { length_cm, log_area: mean_areas(lengths_cm, areas_cm2, &edges).iter().map(|a| a.max(MIN_AREA_CM2).ln()).collect() }
}

/// The 2.3 tract's profile for a shape.
pub fn profile_23(tract: &mut Tract23, params: &[f64], n: usize) -> Profile {
    tract.calculate(params);
    let t = tract.tube();
    profile(&t.length_cm, &t.area_cm2, n)
}

/// The 2.4 tract's profile for a shape, and its tube.
pub fn profile_24(tract: &mut Tract24, params: &[f64], n: usize) -> (Profile, TractTube) {
    tract.calculate(params);
    let t = tract.tube();
    (profile(&t.length_cm, &t.area_cm2, n), t)
}

/// A shape carried: the target's parameters, the rms of the log areas' differences (by stretch), and the steps taken.
#[derive(Clone, Debug)]
pub struct Carried {
    pub params: [f64; NUM_PARAMS],
    pub rms_log_area: f64,
    pub steps: usize,
}

fn cost(a: &Profile, b: &Profile) -> f64 {
    a.log_area.iter().zip(&b.log_area).map(|(x, y)| (x - y).powi(2)).sum()
}

/// The target's parameters whose profile is the source's, from `start`, the velum's opening held at `velum` (within its
/// range).
pub fn carry(target: &mut Tract24, source: &Profile, start: &[f64; NUM_PARAMS], velum: f64, max_steps: usize) -> Carried {
    let n = source.log_area.len();
    let range: Vec<(f64, f64)> = target.param.iter().map(|p| (p.min, p.max)).collect();
    let clamp = |p: &mut [f64; NUM_PARAMS]| {
        for (x, &(lo, hi)) in p.iter_mut().zip(&range) {
            *x = x.clamp(lo, hi);
        }
    };
    let free: Vec<usize> = (0..NUM_PARAMS).filter(|&k| k != VO).collect();
    let m = free.len();
    let mut p = *start;
    p[VO] = velum;
    clamp(&mut p);
    let mut now = profile_24(target, &p, n).0;
    let mut c = cost(&now, source);
    let mut lambda = 1e-3;
    let mut steps = 0;
    while steps < max_steps {
        steps += 1;
        // The Jacobian of the log areas by each free parameter, by a forward difference of a ten-thousandth of its range
        // (backward where the range ends).
        let mut jac = vec![vec![0.0; n]; m];
        for (c_, &k) in free.iter().enumerate() {
            let h = 1e-4 * (range[k].1 - range[k].0);
            let h = if p[k] + h > range[k].1 { -h } else { h };
            let mut q = p;
            q[k] += h;
            let moved = profile_24(target, &q, n).0;
            for i in 0..n {
                jac[c_][i] = (moved.log_area[i] - now.log_area[i]) / h;
            }
        }
        let r: Vec<f64> = (0..n).map(|i| source.log_area[i] - now.log_area[i]).collect();
        let mut a = vec![0.0; m * m];
        let mut g = vec![0.0; m];
        for i in 0..m {
            g[i] = (0..n).map(|t| jac[i][t] * r[t]).sum();
            for j in 0..m {
                a[i * m + j] = (0..n).map(|t| jac[i][t] * jac[j][t]).sum();
            }
        }
        let largest = (0..m).map(|i| a[i * m + i]).fold(0.0, f64::max);
        let mut accepted = false;
        while lambda < 1e8 {
            let mut damped = a.clone();
            for i in 0..m {
                damped[i * m + i] += lambda * a[i * m + i] + 1e-12 * largest.max(1e-300);
            }
            let Some(d) = cholesky_solve(&mut damped, &g, m) else {
                lambda *= 10.0;
                continue;
            };
            let mut q = p;
            for (c_, &k) in free.iter().enumerate() {
                q[k] += d[c_];
            }
            clamp(&mut q);
            let tried = profile_24(target, &q, n).0;
            let c1 = cost(&tried, source);
            if c1 < c {
                accepted = c1 < c * (1.0 - 1e-9);
                p = q;
                now = tried;
                c = c1;
                lambda = (lambda / 10.0).max(1e-9);
                break;
            }
            lambda *= 10.0;
        }
        if !accepted {
            break;
        }
    }
    Carried { params: p, rms_log_area: (c / n as f64).sqrt(), steps }
}

/// The source's profile laid on the target's tube: each of its sections, at its place along the tube as a fraction of its
/// length, given the source's mean area there -- the shape as the target would have it were the carrying exact, for the
/// acoustics to compare against. (On the tube's own sections, not equal ones: the 2.4 engine couples the piriform
/// fossae to the fifth section wherever it falls, so a tube laid out otherwise sounds otherwise -- 100 to 200 cents at
/// the third and fourth resonances of JD2's vowels, on equal sections.)
pub fn laid(on: &TractTube, source: &Profile) -> TractTube {
    let length_cm: f64 = on.length_cm.iter().sum();
    let m = source.log_area.len();
    let lengths = vec![length_cm / m as f64; m];
    let areas: Vec<f64> = source.log_area.iter().map(|x| x.exp()).collect();
    let mut edges = vec![0.0];
    for l in &on.length_cm {
        edges.push(edges.last().unwrap() + l);
    }
    let mut t = on.clone();
    for (i, a) in mean_areas(&lengths, &areas, &edges).into_iter().enumerate() {
        t.area_cm2[i] = a;
    }
    t
}

/// The grid on which a response's magnitude is searched for its peaks.
const STEP_HZ: f64 = 5.0;

/// The flow radiated at the lips and nostrils of a 2.4 tube (its glottis closed) in the 2.4 engine at its own rate, its
/// noise sources off, after one impulse of flow at the glottis: a quarter of a second of it, and the rate.
fn impulse_response(geometry: &TractTube, options: impl Fn(&mut Options)) -> (Vec<f64>, f64) {
    let mut tube = Tube::new();
    tube.set_from_tract(geometry);
    tube.set_glottis_sections(&[0.3, 0.3], &[MIN_AREA_CM2, MIN_AREA_CM2]);
    let mut tds = TdsModel::new();
    tds.options.generate_noise_sources = false;
    options(&mut tds.options);
    tds.reset_motion();
    tds.set_tube(&tube, false);
    let rate = 1.0 / tds.time_step;
    let samples = (0.25 * rate) as usize;
    let mut response = Vec::with_capacity(samples);
    for s in 0..samples {
        tds.set_flow_source(if s == 0 { 1.0 } else { 0.0 }, FIRST_PHARYNX_SECTION as i32);
        let r = tds.proceed_time_step();
        response.push(r.mouth + r.nostrils);
    }
    (response, rate)
}

/// A response's magnitude at a frequency (Goertzel's recursion).
fn magnitude(response: &[f64], hz: f64, rate: f64) -> f64 {
    let w = 2.0 * std::f64::consts::PI * hz / rate;
    let coeff = 2.0 * w.cos();
    let (mut s1, mut s2) = (0.0, 0.0);
    for &x in response {
        let s0 = x + coeff * s1 - s2;
        s2 = s1;
        s1 = s0;
    }
    (s1 * s1 + s2 * s2 - coeff * s1 * s2).sqrt()
}

/// The response's peaks on the grid below `top_hz`, above 50 Hz: their frequencies.
fn grid_peaks(response: &[f64], rate: f64, top_hz: f64) -> Vec<f64> {
    let bins = (top_hz / STEP_HZ) as usize;
    let m: Vec<f64> = (1..=bins).map(|k| magnitude(response, k as f64 * STEP_HZ, rate)).collect();
    (1..m.len() - 1).filter(|&i| m[i] > m[i - 1] && m[i] >= m[i + 1] && (i + 1) as f64 * STEP_HZ > 50.0).map(|i| (i + 1) as f64 * STEP_HZ).collect()
}

/// The resonances below `top_hz` of a 2.4 tube (its glottis closed) in the 2.4 engine at its own rate, its noise sources
/// off: the flow radiated at the lips and nostrils after one impulse of flow at the glottis, the local maxima of its
/// magnitude on a 5 Hz grid (as examples/v24_resonances.rs).
pub fn resonances(geometry: &TractTube, top_hz: f64) -> Vec<f64> {
    resonances_with(geometry, top_hz, |_| {})
}

/// The same, the engine's options changed first (a part of it turned off, to see what it does).
pub fn resonances_with(geometry: &TractTube, top_hz: f64, options: impl Fn(&mut Options)) -> Vec<f64> {
    let (response, rate) = impulse_response(geometry, options);
    grid_peaks(&response, rate, top_hz)
}

/// The resonances as `resonances` finds them, each refined between its grid's neighbours to a hundredth of a hertz (the
/// same magnitude's greatest, by golden section): moving smoothly with the tube, for a search to take their derivatives.
pub fn resonances_fine(geometry: &TractTube, top_hz: f64) -> Vec<f64> {
    let (response, rate) = impulse_response(geometry, |_| {});
    let golden = (5f64.sqrt() - 1.0) / 2.0;
    grid_peaks(&response, rate, top_hz)
        .into_iter()
        .map(|peak| {
            let (mut a, mut b) = (peak - STEP_HZ, peak + STEP_HZ);
            let (mut x1, mut x2) = (b - golden * (b - a), a + golden * (b - a));
            let (mut m1, mut m2) = (magnitude(&response, x1, rate), magnitude(&response, x2, rate));
            while b - a > 0.01 {
                if m1 >= m2 {
                    (b, x2, m2) = (x2, x1, m1);
                    x1 = b - golden * (b - a);
                    m1 = magnitude(&response, x1, rate);
                } else {
                    (a, x1, m1) = (x1, x2, m2);
                    x2 = a + golden * (b - a);
                    m2 = magnitude(&response, x2, rate);
                }
            }
            (a + b) / 2.0
        })
        .collect()
}

/// How shapes are carried and tuned (languages/carry.json).
#[derive(Clone, Debug, Deserialize)]
pub struct Settings {
    pub steps: usize,
    pub top_hz: f64,
    pub tune: Tuning,
}

/// How a carried shape's resonances are tuned (languages/carry.json `tune`).
#[derive(Clone, Debug, Deserialize)]
pub struct Tuning {
    pub formants: usize,
    pub cents_per_range: f64,
    pub least_area_share: f64,
    pub kept_within_cents: f64,
    pub steps: usize,
    pub difference_share: f64,
}

pub fn settings() -> &'static Settings {
    static SETTINGS: OnceLock<Settings> = OnceLock::new();
    SETTINGS.get_or_init(|| serde_json::from_str(&language_file("carry.json", include_str!("../languages/carry.json"))).unwrap_or_else(|e| panic!("languages/carry.json: {e}")))
}

/// A tube's least area where its tongue, lower incisors or lower lip bound it: where a shape would close the tract.
pub fn least_closable_area(t: &TractTube) -> f64 {
    t.area_cm2
        .iter()
        .zip(&t.articulator)
        .filter(|(_, a)| matches!(a, Articulator::Tongue | Articulator::LowerIncisors | Articulator::LowerLip))
        .map(|(x, _)| *x)
        .fold(f64::INFINITY, f64::min)
}

/// A shape tuned: its parameters, its first resonances and each one's miss in cents, its least closable area, its
/// parameters' rms move from where it began (as shares of their ranges), and the steps taken.
#[derive(Clone, Debug)]
pub struct Tuned {
    pub params: [f64; NUM_PARAMS],
    pub resonances_hz: Vec<f64>,
    pub cents: Vec<f64>,
    pub least_area_cm2: f64,
    pub moved: f64,
    pub steps: usize,
}

/// A shape's first resonances brought to `goal_hz` on the 2.4 engine itself: its free parameters (all but those `held`:
/// a carried shape's velum's opening, a vowel's lips and velum) moved by least squares (Levenberg-Marquardt) on each
/// resonance's miss in cents (`resonances_fine`) and, so that it stays the shape it began as, each parameter's move
/// from `start` as a share of its range (its whole range weighing `cents_per_range` cents); a shape whose least closable
/// area is under `least_area_cm2` refused, as closing the tract, as is one with fewer resonances than its goal. Each
/// derivative a forward difference of `difference_share` of its parameter's range (backward where the forward is refused
/// or out of range). Where `within` is given, it stops once every resonance is within that many cents of its goal.
pub fn tune(target: &mut Tract24, start: &[f64; NUM_PARAMS], goal_hz: &[f64], least_area_cm2: f64, t: &Tuning, top_hz: f64, held: &[usize], within: Option<f64>) -> Result<Tuned, String> {
    let range: Vec<(f64, f64)> = target.param.iter().map(|p| (p.min, p.max)).collect();
    let free: Vec<usize> = (0..NUM_PARAMS).filter(|k| !held.contains(k)).collect();
    let n = goal_hz.len();
    let width = |k: usize| range[k].1 - range[k].0;
    let mut measure = |p: &[f64; NUM_PARAMS]| -> Option<(Vec<f64>, Vec<f64>, f64)> {
        target.calculate(p);
        let tube = target.tube();
        let least = least_closable_area(&tube);
        if least < least_area_cm2 {
            return None;
        }
        let f = resonances_fine(&tube, top_hz);
        if f.len() < n {
            return None;
        }
        let mut r: Vec<f64> = (0..n).map(|k| 1200.0 * (f[k] / goal_hz[k]).log2()).collect();
        r.extend(free.iter().map(|&k| t.cents_per_range * (p[k] - start[k]) / width(k)));
        Some((r, f[..n].to_vec(), least))
    };
    let sum = |r: &[f64]| r.iter().map(|x| x * x).sum::<f64>();
    let mut p = *start;
    for (x, &(lo, hi)) in p.iter_mut().zip(&range) {
        *x = x.clamp(lo, hi);
    }
    let (mut r, mut f, mut least) = measure(&p).ok_or_else(|| format!("its start is refused: fewer than {n} resonances, or its least closable area under {least_area_cm2:.3} cm2"))?;
    let mut c = sum(&r);
    let (m, rows) = (free.len(), r.len());
    let mut lambda = 1e-3;
    let mut steps = 0;
    while steps < t.steps {
        if within.is_some_and(|w| r[..n].iter().all(|c| c.abs() <= w)) {
            break;
        }
        steps += 1;
        let mut jac = vec![vec![0.0; rows]; m];
        for (ci, &k) in free.iter().enumerate() {
            let h = t.difference_share * width(k);
            for h in [h, -h] {
                let mut q = p;
                q[k] += h;
                if q[k] < range[k].0 || q[k] > range[k].1 {
                    continue;
                }
                if let Some((rq, _, _)) = measure(&q) {
                    for i in 0..rows {
                        jac[ci][i] = (rq[i] - r[i]) / h;
                    }
                    break;
                }
                // (Neither way allowed: the column left at nought, the parameter held this step.)
            }
        }
        let mut a = vec![0.0; m * m];
        let mut g = vec![0.0; m];
        for i in 0..m {
            g[i] = -(0..rows).map(|s| jac[i][s] * r[s]).sum::<f64>();
            for j in 0..m {
                a[i * m + j] = (0..rows).map(|s| jac[i][s] * jac[j][s]).sum();
            }
        }
        let largest = (0..m).map(|i| a[i * m + i]).fold(0.0, f64::max);
        let mut accepted = false;
        while lambda < 1e8 {
            let mut damped = a.clone();
            for i in 0..m {
                damped[i * m + i] += lambda * a[i * m + i] + 1e-12 * largest.max(1e-300);
            }
            let Some(d) = cholesky_solve(&mut damped, &g, m) else {
                lambda *= 10.0;
                continue;
            };
            let mut q = p;
            for (ci, &k) in free.iter().enumerate() {
                q[k] = (q[k] + d[ci]).clamp(range[k].0, range[k].1);
            }
            if let Some((rq, fq, lq)) = measure(&q) {
                let c1 = sum(&rq);
                if c1 < c {
                    accepted = c1 < c * (1.0 - 1e-9);
                    (p, r, f, least, c) = (q, rq, fq, lq, c1);
                    lambda = (lambda / 10.0).max(1e-9);
                    break;
                }
            }
            lambda *= 10.0;
        }
        if !accepted {
            break;
        }
    }
    let moved = (free.iter().map(|&k| ((p[k] - start[k]) / width(k)).powi(2)).sum::<f64>() / m as f64).sqrt();
    Ok(Tuned { params: p, resonances_hz: f, cents: r[..n].to_vec(), least_area_cm2: least, moved, steps })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_profile_keeps_the_volume() {
        // Sections of uneven length: each stretch's mean area is its share of their volume.
        let (lengths, areas) = ([1.0, 0.5, 2.5], [2.0, 0.1, 4.0]);
        let p = profile(&lengths, &areas, 8);
        assert!((p.length_cm - 4.0).abs() < 1e-12);
        let volume: f64 = p.log_area.iter().map(|x| x.exp() * 0.5).sum();
        assert!((volume - (2.0 + 0.05 + 10.0)).abs() < 1e-9, "{volume}");
        assert!((p.log_area[0] - 2f64.ln()).abs() < 1e-12);
        // (The third stretch, 1.0 to 1.5 cm, is the narrow section alone.)
        assert!((p.log_area[2] - 0.1f64.ln()).abs() < 1e-12);
        // (Nothing under the tube's least area.)
        assert!(profile(&[1.0], &[0.0], 2).log_area.iter().all(|&x| x == MIN_AREA_CM2.ln()));
    }

    #[test]
    fn the_settings_are_read() {
        let s = settings();
        assert!(s.steps > 0 && s.top_hz > 0.0);
        let t = &s.tune;
        assert!(t.formants > 0 && t.steps > 0 && t.cents_per_range > 0.0 && t.kept_within_cents > 0.0);
        assert!(t.least_area_share > 0.0 && t.least_area_share <= 1.0 && t.difference_share > 0.0 && t.difference_share < 0.1);
    }

    /// A shape's resonances refined lie by their grid's, and tuning brings them to a goal near them; a shape narrower
    /// than its floor is refused.
    #[test]
    fn a_shape_is_tuned_on_the_engine() {
        use crate::blend::{synthesis_home, voices_file, Voices};
        use crate::v24::speaker::Speaker;
        let voices = Voices::read(&voices_file()).unwrap();
        let home = synthesis_home();
        if !std::path::Path::new(&voices.file(&home, "JD2").unwrap()).exists() {
            eprintln!("skipped: JD2's file is not on this machine ({home})");
            return;
        }
        let mut tract = Speaker::read(&voices.file(&home, "JD2").unwrap()).unwrap().tract;
        let start = tract.shape("a").unwrap();
        tract.calculate(&start);
        let tube = tract.tube();
        let (grid, fine) = (resonances(&tube, 4000.0), resonances_fine(&tube, 4000.0));
        assert_eq!(grid.len(), fine.len());
        assert!(grid.iter().zip(&fine).all(|(g, f)| (g - f).abs() <= STEP_HZ), "{grid:?} {fine:?}");
        let tuning = Tuning { formants: 2, steps: 6, ..settings().tune.clone() };
        let goal: Vec<f64> = fine.iter().take(2).map(|f| f * 2f64.powf(15.0 / 1200.0)).collect();
        let least = least_closable_area(&tube);
        let tuned = tune(&mut tract, &start, &goal, 0.5 * least, &tuning, 4000.0, &[crate::tract::VO], None).unwrap();
        assert!(tuned.cents.iter().all(|c| c.abs() < 3.0), "{:?}", tuned.cents);
        assert!(tuned.least_area_cm2 >= 0.5 * least && tuned.moved > 0.0);
        assert!(tune(&mut tract, &start, &goal, 2.0 * least, &tuning, 4000.0, &[crate::tract::VO], None).is_err());
    }
}
