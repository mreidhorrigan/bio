// The vocal tract sung (the owner, 11 November 2026: "We want to get this modeled vocal tract to sing"): notes -- each
// its start and end, its pitch as a floating-point MIDI number (a microtone exactly: the geometric glottis drives its
// phase at F0, so a note sounds the frequency it is given), its vowel (one of the speaker's shapes) and its lung
// pressure -- made into VocalTractLab's frames (110 samples apart at 2.3's 44.1 kHz, 120 at 2.4's 48): the tract's 19 parameters moving toward each vowel,
// the glottis's 11 with F0 and pressure moving through the notes. The articulators approach their targets as a
// critically damped third-order system (three first-order lags in cascade, the form of VocalTractLab's own target
// approximation); its time constant, the onsets' and releases' ramps, the portamento between legato notes and any vibrato
// are the caller's: none is written here. What the caller passes is designed, not measured, unless it says otherwise.
use crate::gestural::Shapes;
use crate::glottis::{FREQUENCY, PRESSURE};
use crate::tract::{VocalTract, NUM_PARAMS};

pub const FRAME: usize = 110;
pub const RATE: f64 = 44100.0;

#[derive(Clone, Debug)]
pub struct SungNote {
    pub start: f64,
    pub end: f64,
    /// Pitch as a MIDI number, any real value (69 = 440 Hz).
    pub pitch: f64,
    /// The vowel: a shape of the speaker's (JD3: a e i o u E: 2 y I E O U 9 Y @ 6 ...).
    pub vowel: String,
    /// Lung pressure while it is held (dPa; JD3's modal voice is about 8000).
    pub pressure_dpa: f64,
}

#[derive(Clone, Debug)]
pub struct Singing {
    /// The glottis's shape for the voice's quality (one of the speaker's: modal, breathy, pressed, ...).
    pub glottis_shape: String,
    /// The articulators' time constant (s): each of the three lags'.
    pub tau_s: f64,
    /// Pressure's rise from silence and fall to it (s).
    pub onset_s: f64,
    pub release_s: f64,
    /// Notes closer than this (s) are joined legato: the pressure held, F0 gliding over `portamento_s`.
    pub legato_gap_s: f64,
    pub portamento_s: f64,
    /// Vibrato: its rate (Hz) and extent (cents either side); 0 for none.
    pub vibrato_hz: f64,
    pub vibrato_cents: f64,
    /// How far ahead (s) the tract heads for the next note's vowel during a rest.
    pub anticipation_s: f64,
}

fn hz(midi: f64) -> f64 {
    440.0 * 2f64.powf((midi - 69.0) / 12.0)
}

/// The frames (tract parameters, glottis parameters) that sing `notes`, from 0 s to the last note's end and `tail_s`
/// after; 110 samples apart (2.3's).
pub fn frames(tract: &VocalTract, glottis_shapes: &[(String, Vec<f64>)], notes: &[SungNote], s: &Singing, tail_s: f64) -> Result<Vec<(Vec<f64>, Vec<f64>)>, String> {
    frames_every(tract, glottis_shapes, notes, s, tail_s, FRAME as f64 / RATE)
}

/// The same for either version's tract (their parameters in the same order; F0 and pressure the first two of either's
/// glottis), `frame_s` apart (2.4's 120 samples at 48 kHz: 2.5 ms).
pub fn frames_every<T: Shapes>(tract: &T, glottis_shapes: &[(String, Vec<f64>)], notes: &[SungNote], s: &Singing, tail_s: f64, frame_s: f64) -> Result<Vec<(Vec<f64>, Vec<f64>)>, String> {
    if notes.is_empty() {
        return Ok(Vec::new());
    }
    let shape = |name: &str| tract.shape_named(name).ok_or_else(|| format!("the speaker has no vocal tract shape {name}"));
    let glottis = glottis_shapes.iter().find(|(n, _)| *n == s.glottis_shape).map(|(_, v)| v.clone()).ok_or_else(|| format!("the speaker has no glottis shape {}", s.glottis_shape))?;
    let vowels: Vec<[f64; NUM_PARAMS]> = notes.iter().map(|n| shape(&n.vowel)).collect::<Result<_, _>>()?;
    let end = notes.iter().map(|n| n.end).fold(0.0, f64::max) + tail_s;
    let dt = frame_s;
    let count = (end / dt).ceil() as usize + 1;
    let a = if s.tau_s > 0.0 { 1.0 - (-dt / s.tau_s).exp() } else { 1.0 };
    // The note sounding or to come at time t.
    let at = |t: f64| -> usize { notes.iter().position(|n| t < n.end).unwrap_or(notes.len() - 1) };
    let mut lag = [vowels[0]; 3];
    let mut out = Vec::with_capacity(count);
    for f in 0..count {
        let t = f as f64 * dt;
        // The tract: toward the vowel of the note sounding, or of the next during a rest (anticipated).
        let k = at(t + s.anticipation_s);
        let target = vowels[k];
        for j in 0..NUM_PARAMS {
            lag[0][j] += a * (target[j] - lag[0][j]);
            lag[1][j] += a * (lag[0][j] - lag[1][j]);
            lag[2][j] += a * (lag[1][j] - lag[2][j]);
        }
        // The glottis: F0 from the notes (legato glides, vibrato), pressure from their onsets and releases.
        let i = at(t);
        let n = &notes[i];
        let prev = if i > 0 { Some(&notes[i - 1]) } else { None };
        let legato = prev.map(|p| n.start - p.end < s.legato_gap_s).unwrap_or(false);
        let mut pitch = n.pitch;
        if legato && s.portamento_s > 0.0 && t < n.start + s.portamento_s {
            let p = prev.unwrap();
            let r = ((t - n.start) / s.portamento_s).clamp(0.0, 1.0);
            pitch = p.pitch + (n.pitch - p.pitch) * (0.5 - 0.5 * (std::f64::consts::PI * r).cos());
        }
        if t < n.start && !legato {
            // (Before an onset after a rest: the note's own pitch, already, for when the folds begin.)
            pitch = n.pitch;
        }
        let vib = if s.vibrato_hz > 0.0 { s.vibrato_cents / 100.0 * (2.0 * std::f64::consts::PI * s.vibrato_hz * (t - n.start).max(0.0)).sin() } else { 0.0 };
        let next_legato = notes.get(i + 1).map(|m| m.start - n.end < s.legato_gap_s).unwrap_or(false);
        let mut pressure = 0.0;
        if t >= n.start || legato {
            let rise = if legato || s.onset_s <= 0.0 { 1.0 } else { ((t - n.start) / s.onset_s).clamp(0.0, 1.0) };
            let fall = if next_legato || s.release_s <= 0.0 { 1.0 } else { ((n.end - t) / s.release_s).clamp(0.0, 1.0) };
            let level = if legato && t < n.start + s.portamento_s {
                let p = prev.unwrap();
                let r = ((t - n.start) / s.portamento_s).clamp(0.0, 1.0);
                p.pressure_dpa + (n.pressure_dpa - p.pressure_dpa) * r
            } else {
                n.pressure_dpa
            };
            pressure = if t <= n.end { level * rise.min(fall) } else { 0.0 };
        }
        let mut g = glottis.clone();
        g[FREQUENCY] = hz(pitch + vib);
        g[PRESSURE] = pressure;
        out.push((lag[2].to_vec(), g));
    }
    Ok(out)
}
