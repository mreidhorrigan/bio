// A singer's body between measured speakers (the owner, 15 November 2026: "it should not just be a single woman-man
// sex-weight but rather reflect interpolation between any specific speaker instance, in case we find more diversity
// later"; "the blending system should be able to take arbitrary new speakers ... architecture and infrastructure happen in
// Rust while loading constants and speaker representations from configuration files"). The speakers are files, named
// in voices/speakers.json with what is known of each; a blend weighs any number of them, every number of each file
// (its anatomy, its articulatory parameters' ranges and neutral values, every shape, its glottis's parameters and
// shapes) by its speaker's weight, and is itself a speaker file, which every tool reads as it reads any other. A
// speaker weighed alone is itself. An element only some of the weighed speakers have is weighed among those that have
// it; a word that is not a number is the heaviest speaker's. Children are matched by the attributes the configuration
// names (a shape by its name, a glottis's control parameter by its index, a glottis model by its type), else by their
// order among their kind. A speaker's file is read with the vowel shapes learned for it (its `learned` files: shapes
// carried from a corpus) that it has none of; a vowel shape only some of the weighed speakers have is made for the others
// from their own vowel space (src/vowel_space.rs), where the sound of those that have it puts it among their own vowels,
// weighed at their weights, so the body moves smoothly from a speaker with it to one without (the owner, 15 November
// 2026: "Yes, proceed"); a glide's, which the space has no place for, is their nearest's (src/phones.rs nearest_phone).
// A body made to sing a language says the vowels measured speakers of it were measured saying where those speakers put
// them among their own (languages/vowel-places.json), each made from each speaker's space before the speakers are
// weighed (research/VOCALWIND_LANGUAGES.md, design 4). research/VOCALWIND_CHOIR.md.
use crate::inventory::{phone, Kind};
use crate::v24::speaker::Speaker;
use crate::v24::tract::NUM_PARAMS;
use crate::vowel_space::{places, sound, space, Heard, Place};
use crate::xml::{self, Node};
use serde::Deserialize;
use std::collections::{BTreeMap, BTreeSet};

/// voices/speakers.json: where the speakers' files are, how a blend matches their elements, and each speaker.
#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Voices {
    pub about: String,
    /// The speakers' folder, under the synthesis folder (soloist.mjs's `synthesis`).
    pub folder: String,
    /// The attributes that tell apart children of one kind under one element, in the order tried.
    pub match_children_by: Vec<String>,
    pub speakers: BTreeMap<String, SpeakerEntry>,
}

/// A speaker: its file, and what is known of the person it was measured from.
#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct SpeakerEntry {
    pub file: String,
    pub described: String,
    pub source: String,
    pub licence: String,
    /// Its walls' tissue as measured of people like it, by its name in acoustics/tract.json's `walls.tissues` (men's or
    /// women's): what a renderer asks the passive core for where it asks the speakers' own walls (`tissue=`).
    pub walls: String,
    /// Files of shapes learned for it beyond its own, under this crate (vtl-carry-shapes' `out`).
    #[serde(default)]
    pub learned: Vec<String>,
    /// Its piriform fossa where a measurement places its trough (the file's `about`): what a renderer asks the engine
    /// for where it asks the measured one (sing-score.mjs --fossa measured, vtl-stream fossa=). The blend itself keeps
    /// each speaker file's own.
    #[serde(default)]
    pub fossa: Option<Fossa>,
}

/// A speaker's measured piriform fossa: its cone's length (cm) and its volume (cm3).
#[derive(Clone, Copy, Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Fossa {
    pub length_cm: f64,
    pub volume_cm3: f64,
}

/// What a body is made to sing (vtl-blend's `language=` and `clarity=`): the language whose measured vowels it says
/// where measured speakers of it put them among their own (languages/vowel-places.json), spread apart by a clarity (0:
/// as measured; src/vowel_space.rs LanguageVowels).
#[derive(Clone, Debug, Default)]
pub struct Sung {
    pub language: String,
    pub clarity: f64,
}

/// The vowel shapes a blend made from its speakers' spaces, by speaker: the language's sung, and those other weighed
/// speakers have; the language's measured vowels it has no phone of its own for (said by their nearest); and, by
/// speaker and shape, how far each made shape's first two resonances are left from those its speaker's map puts at its
/// place (cents; vowel_space::Heard).
#[derive(Clone, Debug, Default)]
pub struct Made {
    pub sung: BTreeMap<String, Vec<String>>,
    pub lacking: BTreeMap<String, Vec<String>>,
    pub by_nearest: Vec<String>,
    pub missed: BTreeMap<String, BTreeMap<String, [f64; 2]>>,
}

/// A file of learned shapes: each one's name and its parameters by name.
#[derive(Debug, Deserialize)]
struct Learned {
    shapes: Vec<LearnedShape>,
}

#[derive(Debug, Deserialize)]
struct LearnedShape {
    name: String,
    params: BTreeMap<String, f64>,
}

impl Voices {
    pub fn read(path: &str) -> Result<Voices, String> {
        let text = std::fs::read_to_string(path).map_err(|e| format!("{path}: {e}"))?;
        serde_json::from_str(&text).map_err(|e| format!("{path}: {e}"))
    }

    /// A speaker's file, under the synthesis folder.
    pub fn file(&self, synthesis: &str, id: &str) -> Result<String, String> {
        let s = self.speakers.get(id).ok_or_else(|| format!("no speaker {id} (voices/speakers.json has {})", self.ids()))?;
        Ok(format!("{synthesis}/{}/{}", self.folder, s.file))
    }

    fn ids(&self) -> String {
        self.speakers.keys().cloned().collect::<Vec<_>>().join(", ")
    }

    /// The speakers' files weighed as asked ("JD2=0.3,W02=0.7"), as a speaker file's text.
    pub fn blend_text(&self, synthesis: &str, asked: &str) -> Result<String, String> {
        self.blend_sung(synthesis, asked, None).map(|(text, _)| text)
    }

    /// The speakers' files weighed as asked, made to sing a language where one is given: a speaker file's text, and the
    /// vowel shapes made from the speakers' spaces.
    pub fn blend_sung(&self, synthesis: &str, asked: &str, sung: Option<&Sung>) -> Result<(String, Made), String> {
        let weights = weights(asked)?;
        let mut roots = Vec::new();
        for (id, w) in &weights {
            roots.push((id.clone(), self.speaker(synthesis, id)?, *w));
        }
        let made = vowels_made(&mut roots, sung)?;
        let mut roots: Vec<(Node, f64)> = roots.into_iter().map(|(_, n, w)| (n, w)).collect();
        stand_ins(&mut roots);
        let weighed: Vec<(&Node, f64)> = roots.iter().map(|(n, w)| (n, *w)).collect();
        Ok((write(&blend(&weighed, &self.match_children_by)?), made))
    }

    /// A speaker's file, with the vowel shapes learned for it that it has none of.
    pub fn speaker(&self, synthesis: &str, id: &str) -> Result<Node, String> {
        let path = self.file(synthesis, id)?;
        let mut root = xml::parse(&std::fs::read_to_string(&path).map_err(|e| format!("{path}: {e}"))?)?;
        for file in &self.speakers[id].learned {
            let path = format!("{}/{file}", crate::home());
            let learned: Learned = serde_json::from_str(&std::fs::read_to_string(&path).map_err(|e| format!("{path}: {e}"))?).map_err(|e| format!("{path}: {e}"))?;
            let shapes = tract_shapes(&mut root).ok_or_else(|| format!("{id}: no vocal tract shapes"))?;
            // (Its parameters in the order of the speaker's own shapes.)
            let order: Vec<String> = shapes.children.first().map(|s| s.children.iter().filter_map(|p| p.attr("name").map(str::to_string)).collect()).unwrap_or_default();
            for s in learned.shapes.iter().filter(|s| is_vowel_shape(&s.name)) {
                if shapes.children.iter().any(|c| c.attr("name") == Some(s.name.as_str())) {
                    continue;
                }
                let mut params = Vec::new();
                for p in &order {
                    let v = s.params.get(p).ok_or_else(|| format!("{path}: /{}/ has no {p}", s.name))?;
                    params.push(Node { name: "param".into(), attributes: vec![("name".into(), p.clone()), ("value".into(), format!("{v}"))], children: Vec::new() });
                }
                shapes.children.push(Node { name: "shape".into(), attributes: vec![("name".into(), s.name.clone())], children: params });
            }
        }
        Ok(root)
    }
}

/// A speaker file's vocal tract's shapes.
fn tract_shapes(root: &mut Node) -> Option<&mut Node> {
    root.children.iter_mut().find(|c| c.name == "vocal_tract_model")?.children.iter_mut().find(|c| c.name == "shapes")
}

/// Whether a shape is the one a vowel or glide of the inventory is made to (languages/phones.json).
fn is_vowel_shape(name: &str) -> bool {
    crate::inventory::phone(name).is_some_and(|p| p.vowel_shape() == Some(name))
}

/// The shape a speaker without a vowel's own makes it to: its nearest phone's (languages/ipa.json's shared nearest).
fn stand_in_shape(name: &str) -> Option<&'static str> {
    if !is_vowel_shape(name) {
        return None;
    }
    crate::phones::nearest_phone(name).and_then(crate::inventory::phone).and_then(|p| p.vowel_shape())
}

/// A vowel's place in the space, where the space has one: a vowel's (not a glide's) phone's IPA's.
fn vowel_place(name: &str) -> Option<Place> {
    let p = phone(name).filter(|p| p.kind == Kind::Vowel && p.vowel_shape() == Some(name))?;
    space().place(p.ipa.first()?).ok()
}

/// A language's measured vowels (languages/vowel-places.json) and the shapes it says them with: each letter's own phone's,
/// never its nearest's (those letters noted).
pub fn language_shapes(language: &str, made: &mut Made) -> Result<Vec<(String, String)>, String> {
    let Some(measured) = places().language(language) else { return Ok(Vec::new()) };
    let mut out: Vec<(String, String)> = Vec::new();
    for c in measured.letters() {
        let letter = c.to_string();
        let shape = match crate::phones::phones_in(&letter, language) {
            Some((found, false)) if found.len() == 1 => phone(found[0]).filter(|p| p.kind == Kind::Vowel).and_then(|p| p.vowel_shape()),
            _ => None,
        };
        let Some(shape) = shape else {
            made.by_nearest.push(letter);
            continue;
        };
        if let Some((other, _)) = out.iter().find(|(_, s)| s == shape) {
            return Err(format!("{language}: [{other}] and [{letter}] are said with one shape, /{shape}/"));
        }
        out.push((letter, shape.to_string()));
    }
    Ok(out)
}

/// A shape set among a speaker's shapes: its parameters' values where it has it, else the shape added.
fn set_shape(shapes: &mut Node, name: &str, params: &[(String, f64)]) {
    let param = |(p, v): &(String, f64)| Node { name: "param".into(), attributes: vec![("name".into(), p.clone()), ("value".into(), format!("{v}"))], children: Vec::new() };
    let children: Vec<Node> = params.iter().map(param).collect();
    match shapes.children.iter_mut().find(|c| c.attr("name") == Some(name)) {
        Some(s) => s.children = children,
        None => shapes.children.push(Node { name: "shape".into(), attributes: vec![("name".into(), name.into())], children }),
    }
}

/// The vowel shapes each weighed speaker is given from its own vowel space as its engine sounds it (Space::of_speaker;
/// research/VOCALWIND_LANGUAGES.md, design 4): the language's sung, at the places its measured speakers put them (but the
/// space's corners', the speaker's own, so its consonants' shapes in their contexts stay its own); and each vowel shape
/// another weighed speaker has and it lacks, where the sound of those that have it puts it among their own vowels
/// (weighed as they are; its rounding and rhoticity its letter's). Each brought to sound at its place on the speaker's
/// own engine (vowel_space::Sounded::heard), each on a thread of its own, once (BroughtBefore). Every shape made from
/// the spaces before any is written.
fn vowels_made(roots: &mut [(String, Node, f64)], sung: Option<&Sung>) -> Result<Made, String> {
    let s = space();
    let mut made = Made::default();
    let language = match sung {
        Some(g) => language_shapes(&g.language, &mut made)?,
        None => Vec::new(),
    };
    // (The speakers weighed that have shapes: the body's.)
    let at: Vec<usize> = (0..roots.len()).filter(|&i| roots[i].2 > 0.0 && tract_shapes(&mut roots[i].1).is_some()).collect();
    let had: Vec<BTreeSet<String>> = at
        .iter()
        .map(|&i| tract_shapes(&mut roots[i].1).map(|s| s.children.iter().filter_map(|c| c.attr("name")).filter(|n| vowel_place(n).is_some()).map(str::to_string).collect()).unwrap_or_default())
        .collect();
    let lacking: BTreeSet<String> = had.iter().flatten().filter(|n| had.iter().any(|h| !h.contains(*n))).cloned().collect();
    if language.is_empty() && lacking.is_empty() {
        return Ok(made);
    }
    // (Each speaker's space sounded on its own thread.)
    let texts: Vec<String> = at.iter().map(|&i| write(&roots[i].1)).collect();
    let tracts = texts.iter().zip(&at).map(|(text, &i)| Speaker::parse(text).map(|s| s.tract).map_err(|e| format!("{}: {e}", roots[i].0))).collect::<Result<Vec<_>, _>>()?;
    let mut sounded = Vec::new();
    let spaces: Vec<_> = std::thread::scope(|scope| {
        let threads: Vec<_> = tracts
            .into_iter()
            .map(|mut tract| {
                scope.spawn(move || {
                    let sp = s.of_speaker(&mut tract);
                    (tract, sp)
                })
            })
            .collect();
        threads.into_iter().map(|t| t.join().expect("a speaker's space")).collect()
    });
    for ((tract, sp), &i) in spaces.into_iter().zip(&at) {
        sounded.push((tract, sp.map_err(|e| format!("{}: {e}", roots[i].0))?));
    }
    // (A vowel the language sings is made where its speakers put it, whoever has it: its sound is not sought.)
    let sung_shapes = |sp: &crate::vowel_space::Sounded| -> Vec<(String, String)> { language.iter().filter(|(_, shape)| !sp.corners.contains(shape)).cloned().collect() };
    let mut lacking_at: Vec<(String, Place)> = Vec::new();
    for name in lacking.iter().filter(|n| !language.iter().any(|(_, shape)| shape == *n)) {
        let own = vowel_place(name).expect("a vowel the space places");
        let mut placed = Vec::new();
        for (k, &i) in at.iter().enumerate() {
            let (tract, sp) = &mut sounded[k];
            let Some(shape) = had[k].contains(name).then(|| tract.shape(name)).flatten() else { continue };
            let p = match &sp.map {
                Some(m) => Place { rhotic: own.rhotic, ..m.place(sound(tract, &shape)?, own.rounding) },
                None => own,
            };
            placed.push((p, roots[i].2));
        }
        lacking_at.push((name.clone(), s.mean_place(&placed).unwrap_or(own)));
    }
    // (Each speaker's shapes to make: the language's sung, at their places, and those it lacks.)
    let mut asked: Vec<Vec<(String, Place)>> = Vec::new();
    for (k, &i) in at.iter().enumerate() {
        let id = roots[i].0.clone();
        let mut these = Vec::new();
        if let Some(g) = sung {
            for (letter, shape) in sung_shapes(&sounded[k].1) {
                these.push((shape.clone(), s.place_in(&letter, &g.language, g.clarity)?));
                made.sung.entry(id.clone()).or_default().push(shape);
            }
        }
        for (name, p) in &lacking_at {
            if !had[k].contains(name) {
                these.push((name.clone(), *p));
                made.lacking.entry(id.clone()).or_default().push(name.clone());
            }
        }
        asked.push(these);
    }
    // (Each brought on a thread of its own, half the machine's at most, each thread a copy of the speakers' tracts as it
    // needs them; those brought before are not brought again: BroughtBefore.)
    let before = BroughtBefore::read();
    let keys: Vec<Vec<u64>> = asked.iter().zip(&texts).map(|(these, text)| these.iter().map(|(_, p)| before.key(text, *p)).collect()).collect();
    let jobs: Vec<(usize, usize)> = keys.iter().enumerate().flat_map(|(k, keys)| keys.iter().enumerate().filter(|(_, key)| before.get(**key).is_none()).map(move |(j, _)| (k, j))).collect();
    let threads = std::thread::available_parallelism().map_or(1, |n| (n.get() / 2).max(1)).min(jobs.len());
    let next = std::sync::atomic::AtomicUsize::new(0);
    let done: Vec<(usize, usize, Result<Heard, String>)> = std::thread::scope(|scope| {
        let (sounded, asked, jobs, next) = (&sounded, &asked, &jobs, &next);
        let workers: Vec<_> = (0..threads)
            .map(|_| {
                scope.spawn(move || {
                    let mut tracts = BTreeMap::new();
                    let mut done = Vec::new();
                    while let Some(&(k, j)) = jobs.get(next.fetch_add(1, std::sync::atomic::Ordering::Relaxed)) {
                        let tract = tracts.entry(k).or_insert_with(|| sounded[k].0.clone());
                        done.push((k, j, sounded[k].1.heard(tract, asked[k][j].1)));
                    }
                    done
                })
            })
            .collect();
        workers.into_iter().flat_map(|w| w.join().expect("vowels brought")).collect()
    });
    let mut now: BTreeMap<(usize, usize), Result<Heard, String>> = done.into_iter().map(|(k, j, h)| ((k, j), h)).collect();
    let brought: Vec<Result<Vec<(String, Heard)>, String>> = asked
        .iter()
        .zip(&keys)
        .enumerate()
        .map(|(k, (these, keys))| {
            these
                .iter()
                .zip(keys)
                .enumerate()
                .map(|(j, ((name, _), key))| {
                    let h = match before.get(*key) {
                        Some(h) => h,
                        None => {
                            let h = now.remove(&(k, j)).expect("a vowel brought")?;
                            before.keep(*key, &h);
                            h
                        }
                    };
                    Ok((name.clone(), h))
                })
                .collect()
        })
        .collect();
    for ((k, &i), heard) in at.iter().enumerate().zip(brought) {
        let tract = &sounded[k].0;
        let id = roots[i].0.clone();
        let heard = heard.map_err(|e| format!("{id}: {e}"))?;
        let shapes: Vec<(String, [f64; NUM_PARAMS])> = heard.iter().map(|(name, h)| (name.clone(), h.shape)).collect();
        if !heard.is_empty() {
            made.missed.insert(id.clone(), heard.iter().map(|(name, h)| (name.clone(), h.after.map(|c| (c * 10.0).round() / 10.0))).collect());
        }
        let node = tract_shapes(&mut roots[i].1).expect("a speaker's shapes");
        for (name, v) in &shapes {
            let params: Vec<(String, f64)> = tract.param.iter().zip(v).map(|(p, x)| (p.name.clone(), x.clamp(p.min, p.max))).collect();
            set_shape(node, name, &params);
        }
    }
    Ok(made)
}

/// The vowels brought to their places in blends before (vowel_space::Heard), so that a speaker's are brought once: a file
/// of lines, each a vowel's key and what it was brought to, the key a hash (FNV-1a, 64 bits) of everything its bringing
/// depends on -- this program's own code, the vowel space's settings and the carry's (as read), the speaker's file and
/// the place -- so that one kept is the one that would be brought now. The file MUSEBOTS_VOCALWIND_HEARD names ("none":
/// none kept); else the trunk's claude-scratch/vocalwind/heard.jsonl (MUSEBOTS_SCRATCH's), where there is a
/// claude-scratch.
struct BroughtBefore {
    file: Option<std::path::PathBuf>,
    kept: BTreeMap<u64, Heard>,
    /// This program, the space's and the carry's settings, hashed.
    given: u64,
}

fn fnv(hash: u64, bytes: &[u8]) -> u64 {
    bytes.iter().fold(hash, |h, &b| (h ^ b as u64).wrapping_mul(0x0000_0100_0000_01b3))
}

const FNV_START: u64 = 0xcbf2_9ce4_8422_2325;

impl BroughtBefore {
    fn file() -> Option<std::path::PathBuf> {
        match std::env::var("MUSEBOTS_VOCALWIND_HEARD") {
            Ok(f) if f == "none" => None,
            Ok(f) if !f.is_empty() => Some(f.into()),
            _ => {
                let scratch = match std::env::var("MUSEBOTS_SCRATCH") {
                    Ok(s) if !s.is_empty() => std::path::PathBuf::from(s),
                    _ => std::path::Path::new(crate::home()).join("../../../claude-scratch"),
                };
                scratch.is_dir().then(|| scratch.join("vocalwind").join("heard.jsonl"))
            }
        }
    }

    fn read() -> BroughtBefore {
        let file = Self::file();
        let program = std::env::current_exe().ok().and_then(|p| std::fs::read(p).ok()).map_or(0, |b| fnv(FNV_START, &b));
        let given = fnv(fnv(fnv(FNV_START, &program.to_le_bytes()), format!("{:?}", space()).as_bytes()), format!("{:?}", crate::carry::settings()).as_bytes());
        let mut kept = BTreeMap::new();
        if let Some(text) = file.as_ref().and_then(|f| std::fs::read_to_string(f).ok()) {
            for line in text.lines() {
                let Ok(v) = serde_json::from_str::<serde_json::Value>(line) else { continue };
                // (Numbers kept as Rust writes them, and read by Rust, which gives back the very number: serde_json's
                // reading of a number may land a bit from it.)
                let numbers = |k: &str| v.get(k).and_then(|x| x.as_array()).map(|a| a.iter().filter_map(|x| x.as_str()?.parse::<f64>().ok()).collect::<Vec<f64>>()).unwrap_or_default();
                let (Some(key), shape, read, before, after) = (v.get("key").and_then(|k| k.as_str()).and_then(|k| u64::from_str_radix(k, 16).ok()), numbers("shape"), numbers("read"), numbers("before"), numbers("after")) else { continue };
                if shape.len() != NUM_PARAMS || read.len() != 4 || before.len() != 2 || after.len() != 2 {
                    continue;
                }
                let whole = |k: &str| v.get(k).and_then(serde_json::Value::as_u64).unwrap_or(0) as usize;
                kept.insert(
                    key,
                    Heard {
                        shape: std::array::from_fn(|k| shape[k]),
                        read: Place { row: read[0], column: read[1], rounding: read[2], rhotic: read[3] },
                        before: [before[0], before[1]],
                        after: [after[0], after[1]],
                        soundings: whole("soundings"),
                        tuned: whole("tuned"),
                    },
                );
            }
        }
        BroughtBefore { file, kept, given }
    }

    /// A vowel's key: what is given, its speaker's file, its place.
    fn key(&self, speaker: &str, p: Place) -> u64 {
        let place: Vec<u8> = [p.row, p.column, p.rounding, p.rhotic].iter().flat_map(|x| x.to_bits().to_le_bytes()).collect();
        fnv(fnv(fnv(FNV_START, &self.given.to_le_bytes()), speaker.as_bytes()), &place)
    }

    fn get(&self, key: u64) -> Option<Heard> {
        self.kept.get(&key).cloned()
    }

    /// One brought now kept, a line added to the file (where there is one; where it cannot be written, not kept).
    fn keep(&self, key: u64, h: &Heard) {
        use std::io::Write;
        let Some(file) = &self.file else { return };
        if self.kept.contains_key(&key) {
            return;
        }
        let exact = |xs: &[f64]| xs.iter().map(|x| x.to_string()).collect::<Vec<_>>();
        let line = serde_json::json!({ "key": format!("{key:016x}"), "shape": exact(&h.shape), "read": exact(&[h.read.row, h.read.column, h.read.rounding, h.read.rhotic]), "before": exact(&h.before), "after": exact(&h.after), "soundings": h.soundings, "tuned": h.tuned });
        let _ = file.parent().map(std::fs::create_dir_all);
        if let Ok(mut f) = std::fs::OpenOptions::new().create(true).append(true).open(file) {
            let _ = f.write_all(format!("{line}\n").as_bytes());
        }
    }
}

/// Each vowel or glide shape some of the weighed speakers have and the space did not make, given to each other weighed
/// speaker as its own stand-in's.
fn stand_ins(roots: &mut [(Node, f64)]) {
    let mut names = BTreeSet::new();
    for (root, _) in roots.iter_mut().filter(|(_, w)| *w > 0.0) {
        if let Some(shapes) = tract_shapes(root) {
            names.extend(shapes.children.iter().filter_map(|c| c.attr("name")).filter(|n| stand_in_shape(n).is_some()).map(str::to_string));
        }
    }
    for (root, _) in roots.iter_mut().filter(|(_, w)| *w > 0.0) {
        let Some(shapes) = tract_shapes(root) else { continue };
        for name in &names {
            if shapes.children.iter().any(|c| c.attr("name") == Some(name.as_str())) {
                continue;
            }
            let near = stand_in_shape(name).and_then(|s| shapes.children.iter().find(|c| c.attr("name") == Some(s)));
            if let Some(near) = near.cloned() {
                let mut shape = near;
                shape.attributes.iter_mut().filter(|(k, _)| k == "name").for_each(|(_, v)| *v = name.clone());
                shapes.children.push(shape);
            }
        }
    }
}

/// The machine's synthesis folder, as render/synthesis/synthesis-home.mjs finds it: MUSEBOTS_SYNTHESIS_HOME, else
/// ~/Library/Application Support/Musebots/synthesis.
pub fn synthesis_home() -> String {
    match std::env::var("MUSEBOTS_SYNTHESIS_HOME") {
        Ok(h) if !h.is_empty() => h,
        _ => format!("{}/Library/Application Support/Musebots/synthesis", std::env::var("HOME").unwrap_or_default()),
    }
}

/// voices/speakers.json, beside this crate.
pub fn voices_file() -> String {
    format!("{}/voices/speakers.json", crate::home())
}

/// Speakers and their weights as asked: "JD2=0.3,W02=0.7" (any positive numbers, taken in proportion).
pub fn weights(asked: &str) -> Result<Vec<(String, f64)>, String> {
    let mut out = Vec::new();
    for part in asked.split(',').map(str::trim).filter(|s| !s.is_empty()) {
        let (id, w) = part.split_once('=').ok_or_else(|| format!("{part}: not speaker=weight"))?;
        let w: f64 = w.trim().parse().map_err(|_| format!("{part}: its weight is not a number"))?;
        if !(w >= 0.0 && w.is_finite()) {
            return Err(format!("{part}: a weight is a number not below zero"));
        }
        if out.iter().any(|(o, _): &(String, f64)| o == id.trim()) {
            return Err(format!("{}: named twice", id.trim()));
        }
        out.push((id.trim().to_string(), w));
    }
    if out.iter().all(|(_, w)| *w == 0.0) {
        return Err(format!("{asked}: no speaker weighed"));
    }
    Ok(out)
}

/// Speakers' files weighed: each node with its weight (in proportion; those of weight zero left out).
pub fn blend(speakers: &[(&Node, f64)], keys: &[String]) -> Result<Node, String> {
    let weighed: Vec<(&Node, f64)> = speakers.iter().filter(|(_, w)| *w > 0.0).cloned().collect();
    if weighed.is_empty() {
        return Err("no speaker weighed".into());
    }
    let names: Vec<&str> = weighed.iter().map(|(n, _)| n.name.as_str()).collect();
    if names.iter().any(|n| *n != names[0]) {
        return Err(format!("not files of one kind: <{}>", names.join(">, <")));
    }
    Ok(blend_node(&weighed, keys))
}

/// One element of several speakers' files weighed: its attributes, then its children matched.
fn blend_node(nodes: &[(&Node, f64)], keys: &[String]) -> Node {
    let heaviest = nodes.iter().enumerate().fold(0, |b, (i, (_, w))| if *w > nodes[b].1 { i } else { b });
    let mut out = Node { name: nodes[0].0.name.clone(), ..Node::default() };
    // (The heaviest speaker's attributes first, in its order; then any only others have.)
    let mut order: Vec<&str> = nodes[heaviest].0.attributes.iter().map(|(k, _)| k.as_str()).collect();
    for (n, _) in nodes {
        for (k, _) in &n.attributes {
            if !order.contains(&k.as_str()) {
                order.push(k);
            }
        }
    }
    for key in order {
        let have: Vec<(&str, f64)> = nodes.iter().filter_map(|(n, w)| n.attr(key).map(|v| (v, *w))).collect();
        let sum: f64 = have.iter().map(|(_, w)| w).sum();
        // (A matching attribute names its element, a number or not: never weighed.)
        let value = match keys.iter().any(|k| k == key) {
            false => numbers_weighed(&have, sum),
            true => None,
        };
        let value = value.unwrap_or_else(|| nodes[heaviest].0.attr(key).unwrap_or(have[0].0).to_string());
        out.attributes.push((key.to_string(), value));
    }
    // Children: each speaker's keyed by its match, in the heaviest's order, then those only others have.
    let keyed: Vec<Vec<(String, &Node)>> = nodes.iter().map(|(n, _)| child_keys(n, keys)).collect();
    let mut order: Vec<String> = keyed[heaviest].iter().map(|(k, _)| k.clone()).collect();
    for k in &keyed {
        for (key, _) in k {
            if !order.contains(key) {
                order.push(key.clone());
            }
        }
    }
    for key in order {
        let have: Vec<(&Node, f64)> = keyed.iter().zip(nodes).filter_map(|(k, (_, w))| k.iter().find(|(c, _)| *c == key).map(|(_, n)| (*n, *w))).collect();
        out.children.push(blend_node(&have, keys));
    }
    out
}

/// A child's key among its siblings: its kind and the first matching attribute's value, else its kind and its place
/// among the unmatched of its kind.
fn child_keys<'a>(node: &'a Node, keys: &[String]) -> Vec<(String, &'a Node)> {
    let mut seen: BTreeMap<&str, usize> = BTreeMap::new();
    node.children
        .iter()
        .map(|c| {
            let key = match keys.iter().find_map(|k| c.attr(k).map(|v| (k, v))) {
                Some((k, v)) => format!("{}[{k}={v}]", c.name),
                None => {
                    let i = seen.entry(c.name.as_str()).or_insert(0);
                    *i += 1;
                    format!("{}#{}", c.name, *i - 1)
                }
            };
            (key, c)
        })
        .collect()
}

/// Values that are all numbers, or lists of as many numbers, weighed; None where any is not.
fn numbers_weighed(have: &[(&str, f64)], sum: f64) -> Option<String> {
    let lists: Vec<Vec<f64>> = have.iter().map(|(v, _)| v.split_whitespace().map(|x| x.parse::<f64>().ok()).collect::<Option<Vec<f64>>>()).collect::<Option<Vec<_>>>()?;
    let n = lists[0].len();
    if n == 0 || lists.iter().any(|l| l.len() != n) {
        return None;
    }
    if have.len() == 1 || lists.iter().all(|l| *l == lists[0]) {
        // (A speaker alone, or speakers agreeing, keep their own words, to the letter.)
        return Some(have[0].0.to_string());
    }
    let weighed: Vec<String> = (0..n).map(|i| format!("{}", lists.iter().zip(have).map(|(l, (_, w))| l[i] * w).sum::<f64>() / sum)).collect();
    Some(weighed.join(" "))
}

/// A speaker file's text from its root: attributes only, as VocalTractLab writes them (src/xml.rs reads them back).
pub fn write(root: &Node) -> String {
    let mut out = String::from("<?xml version=\"1.0\" encoding=\"utf-8\"?>\n");
    write_node(root, 0, &mut out);
    out
}

fn write_node(n: &Node, depth: usize, out: &mut String) {
    out.push_str(&"  ".repeat(depth));
    out.push('<');
    out.push_str(&n.name);
    for (k, v) in &n.attributes {
        // (As read: src/xml.rs takes a value between its quotes as it stands, no entity decoded.)
        let q = if v.contains('"') { '\'' } else { '"' };
        out.push_str(&format!(" {k}={q}{v}{q}"));
    }
    if n.children.is_empty() {
        out.push_str("/>\n");
        return;
    }
    out.push_str(">\n");
    for c in &n.children {
        write_node(c, depth + 1, out);
    }
    out.push_str(&"  ".repeat(depth));
    out.push_str(&format!("</{}>\n", n.name));
}

#[cfg(test)]
mod tests {
    use super::*;

    fn keys() -> Vec<String> {
        ["name", "index", "type"].iter().map(|s| s.to_string()).collect()
    }

    const A: &str = r#"<speaker><anatomy><param index="3" name="TCX" min="-1.0" max="2.5"/></anatomy>
        <shapes><shape name="a"><param name="TCX" value="1.0"/></shape><shape name="i"><param name="TCX" value="2.0"/></shape></shapes>
        <glottis rest="120.0" label="his"/></speaker>"#;
    const B: &str = r#"<speaker><anatomy><param index="3" name="TCX" min="-1.0" max="3.5"/></anatomy>
        <shapes><shape name="i"><param name="TCX" value="3.0"/></shape><shape name="a"><param name="TCX" value="0.0"/></shape>
        <shape name="u-raw"><param name="TCX" value="5.0"/></shape></shapes><glottis rest="220.0" label="hers"/></speaker>"#;

    fn find<'a>(n: &'a Node, path: &[(&str, Option<&str>)]) -> &'a Node {
        path.iter().fold(n, |n, (tag, name)| n.children.iter().find(|c| c.name == *tag && name.map_or(true, |m| c.attr("name") == Some(m))).unwrap())
    }

    #[test]
    fn a_speaker_alone_is_itself_to_the_letter() {
        let a = xml::parse(A).unwrap();
        let b = xml::parse(B).unwrap();
        let alone = blend(&[(&a, 1.0), (&b, 0.0)], &keys()).unwrap();
        assert_eq!(write(&alone), write(&a));
        assert_eq!(write(&xml::parse(&write(&alone)).unwrap()), write(&a));
    }

    #[test]
    fn numbers_are_weighed_in_proportion_and_names_are_not() {
        let (a, b) = (xml::parse(A).unwrap(), xml::parse(B).unwrap());
        let m = blend(&[(&a, 3.0), (&b, 1.0)], &keys()).unwrap();
        let p = find(&m, &[("anatomy", None), ("param", None)]);
        assert_eq!(p.attr("index"), Some("3"));
        assert_eq!(p.attr("min"), Some("-1.0"));
        assert_eq!(p.num("max").unwrap(), 2.75);
        // (Shapes matched by name, whatever their order.)
        assert_eq!(find(&m, &[("shapes", None), ("shape", Some("a")), ("param", None)]).num("value").unwrap(), 0.75);
        assert_eq!(find(&m, &[("shapes", None), ("shape", Some("i")), ("param", None)]).num("value").unwrap(), 2.25);
        let g = find(&m, &[("glottis", None)]);
        assert_eq!(g.num("rest").unwrap(), 145.0);
        assert_eq!(g.attr("label"), Some("his"));
    }

    #[test]
    fn an_element_only_some_have_is_weighed_among_them() {
        let (a, b) = (xml::parse(A).unwrap(), xml::parse(B).unwrap());
        let m = blend(&[(&a, 0.9), (&b, 0.1)], &keys()).unwrap();
        let raw = find(&m, &[("shapes", None), ("shape", Some("u-raw")), ("param", None)]);
        assert_eq!(raw.attr("value"), Some("5.0"));
        // (The heaviest speaker's order first.)
        let names: Vec<&str> = find(&m, &[("shapes", None)]).children.iter().filter_map(|c| c.attr("name")).collect();
        assert_eq!(names, ["a", "i", "u-raw"]);
    }

    #[test]
    fn weights_are_read_as_asked() {
        assert_eq!(weights("JD2=0.3, W02=0.7").unwrap(), vec![("JD2".to_string(), 0.3), ("W02".to_string(), 0.7)]);
        assert!(weights("JD2=0").is_err());
        assert!(weights("JD2=-1").is_err());
        assert!(weights("JD2").is_err());
        assert!(weights("JD2=1,JD2=2").is_err());
    }

    /// The speakers' files, where this machine has them all.
    fn on_this_machine() -> Option<(Voices, String)> {
        let voices = Voices::read(&voices_file()).unwrap();
        let home = synthesis_home();
        if voices.speakers.keys().any(|id| !std::path::Path::new(&voices.file(&home, id).unwrap()).exists()) {
            eprintln!("skipped: the speakers' files are not on this machine ({home})");
            return None;
        }
        Some((voices, home))
    }

    /// A speaker with a learned vowel keeps it alone; one without has none alone, and weighed with one that has it is
    /// given it from its own vowel space, where the sound of the one with it puts it among that one's own vowels, brought
    /// to sound there on its own engine (vowel_space::Sounded::heard), at its own weight: a body nearly all the one
    /// without is nearly that.
    #[test]
    fn a_learned_vowel_is_made_for_the_others_from_their_space() {
        use crate::v24::speaker::Speaker;
        let Some((voices, home)) = on_this_machine() else { return };
        let read = |asked: &str| Speaker::parse(&voices.blend_text(&home, asked).unwrap()).unwrap().tract;
        let ids: Vec<&String> = voices.speakers.keys().collect();
        let (Some(with), Some(without)) = (ids.iter().find(|id| read(&format!("{id}=1")).shape("V").is_some()), ids.iter().find(|id| read(&format!("{id}=1")).shape("V").is_none())) else {
            eprintln!("skipped: no speaker with /V/ and one without");
            return;
        };
        assert!(read(&format!("{without}=1,{with}=0")).shape("V").is_none(), "{without} alone has no /V/");
        let (mut w, mut wo) = (read(&format!("{with}=1")), read(&format!("{without}=1")));
        let s = space();
        let (v, own) = (w.shape("V").unwrap(), vowel_place("V").unwrap());
        let map = s.of_speaker(&mut w).unwrap().map.unwrap();
        let at = Place { rhotic: own.rhotic, ..map.place(sound(&mut w, &v).unwrap(), own.rounding) };
        let sounded = s.of_speaker(&mut wo).unwrap();
        let heard = sounded.heard(&mut wo, at).unwrap();
        let made = heard.shape;
        // (Its first two resonances on the engine where the map of the one without puts the place, as said.)
        let (f, goal) = (sound(&mut wo, &made).unwrap(), sounded.map.as_ref().unwrap().sound(at));
        let off = [1200.0 * (f.0 / goal.0).log2(), 1200.0 * (f.1 / goal.1).log2()];
        assert!((0..2).all(|k| (off[k] - heard.after[k]).abs() < 1e-6 && off[k].abs() <= heard.before[k].abs()), "/V/ on {without}: {off:?}, said {:?}, read {:?}", heard.after, heard.before);
        let m = read(&format!("{without}=0.99,{with}=0.01")).shape("V").unwrap();
        for k in 0..NUM_PARAMS {
            let expect = 0.99 * made[k].clamp(wo.param[k].min, wo.param[k].max) + 0.01 * v[k];
            assert!((m[k] - expect).abs() < 1e-9, "/V/'s {}: {} against {expect}", wo.param[k].name, m[k]);
        }
    }

    /// A body made to sing a language says the vowels its measured speakers were measured saying from each speaker's
    /// space where they put them, brought to sound there on its own engine; the space's corners and the vowels not
    /// measured stay the speaker's own; English's [æ] is a shape of its own, not [ɛ]'s.
    #[test]
    fn a_body_made_to_sing_a_language_says_its_vowels_where_measured() {
        use crate::v24::speaker::Speaker;
        let Some((voices, home)) = on_this_machine() else { return };
        let id = voices.speakers.keys().next().unwrap();
        let own = Speaker::parse(&voices.blend_text(&home, &format!("{id}=1")).unwrap()).unwrap().tract;
        let sung = |language: &str| voices.blend_sung(&home, &format!("{id}=1"), Some(&Sung { language: language.into(), clarity: 0.0 })).unwrap();
        let (text, made) = sung("la");
        let latin = Speaker::parse(&text).unwrap().tract;
        assert!(made.by_nearest.is_empty() && made.lacking.is_empty());
        let mut shapes = made.sung[id].clone();
        shapes.sort();
        assert_eq!(shapes, ["E", "O", "e", "o"]);
        let mut tract = own.clone();
        let sp = space().of_speaker(&mut tract).unwrap();
        for (letter, shape) in [("e", "e"), ("ɛ", "E"), ("o", "o"), ("ɔ", "O")] {
            let heard = sp.heard(&mut tract, space().place_in(letter, "la", 0.0).unwrap()).unwrap();
            let want = heard.shape;
            assert_eq!(made.missed[id][shape], heard.after.map(|c| (c * 10.0).round() / 10.0), "[{letter}] /{shape}/ as said");
            let got = latin.shape(shape).unwrap();
            for k in 0..NUM_PARAMS {
                assert!((got[k] - want[k].clamp(own.param[k].min, own.param[k].max)).abs() < 1e-12, "[{letter}] /{shape}/ {}", own.param[k].name);
            }
        }
        for shape in ["a", "i", "u", "@", "3`"] {
            assert_eq!(latin.shape(shape), own.shape(shape), "/{shape}/ the speaker's own");
        }
        assert_eq!(crate::phones::phones_in("æ", "en"), Some((vec!["{"], false)));
        let (text, made) = sung("en");
        let english = Speaker::parse(&text).unwrap().tract;
        assert!(made.sung[id].iter().any(|s| s == "{") && made.by_nearest.is_empty());
        assert_ne!(english.shape("{"), english.shape("E"));
    }

    /// The speakers named in voices/speakers.json, where this machine has them: each alone, through a blend, plays as
    /// itself to the bit (every shape's tube), and an even blend of all reads back as a speaker whose shapes, drawn twice,
    /// are drawn the same.
    #[test]
    fn the_speakers_weighed_alone_are_themselves() {
        use crate::v24::speaker::Speaker;
        let Some((voices, home)) = on_this_machine() else { return };
        for id in voices.speakers.keys() {
            let own = Speaker::read(&voices.file(&home, id).unwrap()).unwrap();
            let made = Speaker::parse(&voices.blend_text(&home, &format!("{id}=1")).unwrap()).unwrap();
            let (mut a, mut b) = (own.tract.clone(), made.tract.clone());
            for (name, v) in &own.tract.shapes {
                a.calculate(v);
                b.calculate(&made.tract.shape(name).unwrap());
                assert_eq!(a.tube().area_cm2, b.tube().area_cm2, "{id} /{name}/");
                assert_eq!(a.tube().length_cm, b.tube().length_cm, "{id} /{name}/");
            }
        }
        // (Its tongue root partly ruled where the speakers differ in it, every shape drawn again the same.)
        let all: Vec<String> = voices.speakers.keys().map(|id| format!("{id}=1")).collect();
        let even = Speaker::parse(&voices.blend_text(&home, &all.join(",")).unwrap()).unwrap();
        let mut t = even.tract.clone();
        for (_, v) in &even.tract.shapes {
            t.calculate(v);
            let once = t.tube().area_cm2.clone();
            t.calculate_all();
            assert_eq!(t.tube().area_cm2, once);
        }
    }
}
