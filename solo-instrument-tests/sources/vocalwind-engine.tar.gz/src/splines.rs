// VocalTractLab's curves (Splines.cpp): line strips in 2D and 3D, parametrized by their arc length, and rational Bezier
// curves in 3D, each expression in its order. (The C++'s line strips recompute their positions on every call, their flag
// never cleared; they are the same numbers each time, so here they are computed when the points change.)
use crate::geometry::{dot3, p2, p3, P2, P3};

pub const MAX_SPLINE_POINTS: usize = 256;

/// A 3D curve's shared methods (Spline3D), on its own point at t.
pub trait Curve3 {
    fn point(&mut self, t: f64) -> P3;
    fn num_points(&self) -> usize;

    /// The curve parameter at the arc-length ratio t, from 100 points along it.
    fn uniform_param(&mut self, t: f64) -> f64 {
        const EPSILON: f64 = 0.000001;
        const N: usize = 100;
        let mut pts = [P3::default(); N];
        let mut s = [0.0; N];
        let mut pos = [0.0; N];
        for i in 0..N {
            s[i] = i as f64 / (N - 1) as f64;
            pts[i] = self.point(s[i]);
            pos[i] = if i == 0 { 0.0 } else { pos[i - 1] + (pts[i] - pts[i - 1]).magnitude() };
        }
        let mut l = pos[N - 1];
        if l < EPSILON {
            l = EPSILON;
        }
        for p in pos.iter_mut() {
            *p /= l;
        }
        let t = t.clamp(0.0, 1.0);
        let mut k: i32 = -1;
        let mut ratio = 0.0;
        for i in 0..N - 1 {
            if t >= pos[i] && t <= pos[i + 1] {
                k = i as i32;
                let mut l = pos[i + 1] - pos[i];
                if l < EPSILON {
                    l = EPSILON;
                }
                ratio = (t - pos[i]) / l;
            }
        }
        if k == -1 {
            if t < 0.5 {
                k = 0;
                ratio = 0.0;
            } else {
                k = N as i32 - 2;
                ratio = 1.0;
            }
        }
        let k = k as usize;
        s[k] + ratio * (s[k + 1] - s[k])
    }

    fn tangent(&mut self, t: f64) -> P3 {
        const DELTA: f64 = 0.000001;
        (self.point(t + 0.5 * DELTA) - self.point(t - 0.5 * DELTA)) / DELTA
    }

    /// The t, between t_min and t_max, where it crosses the plane nearest plane_point (by bisection over 16 points), or -1.
    fn intersection(&mut self, plane_point: P3, plane_normal: P3, t_min: f64, t_max: f64) -> f64 {
        const NUM_VERTICES: usize = 16;
        if self.num_points() < 2 {
            return -1.0;
        }
        let mut dot = [0.0; NUM_VERTICES];
        let mut vt = [0.0; NUM_VERTICES];
        let mut q = [P3::default(); NUM_VERTICES];
        for i in 0..NUM_VERTICES {
            vt[i] = t_min + (t_max - t_min) * i as f64 / (NUM_VERTICES - 1) as f64;
            q[i] = self.point(vt[i]);
            dot[i] = dot3(plane_normal, q[i] - plane_point);
        }
        let mut min_dist = -1.0;
        let mut k: i32 = -1;
        for i in 0..NUM_VERTICES - 1 {
            if (dot[i] >= 0.0 && dot[i + 1] <= 0.0) || (dot[i] <= 0.0 && dot[i + 1] >= 0.0) {
                let c = (q[i] + q[i + 1]) * 0.5 - plane_point;
                let d = c.x * c.x + c.y * c.y + c.z * c.z;
                if min_dist < 0.0 || d < min_dist {
                    k = i as i32;
                    min_dist = d;
                }
            }
        }
        if k != -1 {
            let k = k as usize;
            if t_max - t_min < 0.0001 {
                return 0.5 * (vt[k] + vt[k + 1]);
            }
            return self.intersection(plane_point, plane_normal, vt[k], vt[k + 1]);
        }
        -1.0
    }
}

#[derive(Clone, Debug, Default)]
pub struct LineStrip2D {
    p: Vec<P2>,
    pos: Vec<f64>,
}

impl LineStrip2D {
    pub fn new() -> Self {
        LineStrip2D::default()
    }
    pub fn from_points(points: &[P2]) -> Self {
        let mut s = LineStrip2D::default();
        s.set_points(points);
        s
    }
    pub fn reset(&mut self, n: usize) {
        self.p = vec![P2::default(); n.min(MAX_SPLINE_POINTS)];
        self.calculate_params();
    }
    pub fn set_points(&mut self, points: &[P2]) {
        self.p = points[..points.len().min(MAX_SPLINE_POINTS)].to_vec();
        self.calculate_params();
    }
    pub fn set_point(&mut self, index: usize, point: P2) {
        if index < self.p.len() {
            self.p[index] = point;
            self.calculate_params();
        }
    }
    pub fn add_point(&mut self, point: P2) {
        if self.p.len() < MAX_SPLINE_POINTS {
            self.p.push(point);
            self.calculate_params();
        }
    }
    pub fn del_point(&mut self) {
        self.p.pop();
        self.calculate_params();
    }
    pub fn num_points(&self) -> usize {
        self.p.len()
    }
    pub fn control_point(&self, index: i32) -> P2 {
        if index < 0 || index as usize >= self.p.len() {
            p2(0.0, 0.0)
        } else {
            self.p[index as usize]
        }
    }
    fn calculate_params(&mut self) {
        let n = self.p.len();
        self.pos.resize(n, 0.0);
        if n < 1 {
            return;
        }
        self.pos[0] = 0.0;
        for i in 1..n {
            self.pos[i] = self.pos[i - 1] + (self.p[i] - self.p[i - 1]).magnitude();
        }
        let length = self.pos[n - 1];
        if length > 0.0 {
            for i in 1..n {
                self.pos[i] /= length;
            }
        }
    }
    pub fn point(&self, t: f64) -> P2 {
        let n = self.p.len();
        if n < 1 {
            return p2(0.0, 0.0);
        }
        if n == 1 {
            return self.p[0];
        }
        let t = t.clamp(0.0, 1.0);
        const EPSILON: f64 = 0.000001;
        let mut ratio = 0.0;
        let mut k: i32 = -1;
        for i in 0..n - 1 {
            if t >= self.pos[i] - EPSILON && t <= self.pos[i + 1] + EPSILON {
                k = i as i32;
                let mut length = self.pos[i + 1] - self.pos[i];
                if length < EPSILON {
                    length = EPSILON;
                }
                ratio = (t - self.pos[i]) / length;
            }
        }
        if k == -1 {
            return p2(0.0, 0.0);
        }
        let k = k as usize;
        self.p[k] + ratio * (self.p[k + 1] - self.p[k])
    }
    /// The strip read as a function y = f(x).
    pub fn function_value(&self, x: f64) -> f64 {
        let n = self.p.len();
        if n < 1 {
            return 0.0;
        }
        if n == 1 {
            return self.p[0].y;
        }
        const EPSILON: f64 = 0.000001;
        let mut result = 0.0;
        for i in 0..n - 1 {
            if x >= self.p[i].x - EPSILON && x <= self.p[i + 1].x + EPSILON {
                let mut length = self.p[i + 1].x - self.p[i].x;
                if length < EPSILON {
                    length = EPSILON;
                }
                result = self.p[i].y + (self.p[i + 1].y - self.p[i].y) * (x - self.p[i].x) / length;
            }
        }
        result
    }
    pub fn tangent(&self, t: f64) -> P2 {
        const DELTA: f64 = 0.000001;
        (self.point(t + 0.5 * DELTA) - self.point(t - 0.5 * DELTA)) / DELTA
    }
    pub fn curve_param(&self, index: i32) -> f64 {
        let index = index.min(self.p.len() as i32 - 1).max(0) as usize;
        self.pos[index]
    }

    // Which side of the line q + t v (within EPSILON of it, 0) each point lies on, as the C++ decides it.
    fn side(&self, i: usize, p_left: P2, p_right: P2, v: P2) -> i32 {
        let mut section = 0;
        let w = self.p[i] - p_left;
        if w.x * v.y - w.y * v.x < 0.0 {
            section = -1;
        }
        let w = self.p[i] - p_right;
        if w.x * v.y - w.y * v.x > 0.0 {
            section = 1;
        }
        section
    }
    fn bounds(q: P2, v: P2) -> (P2, P2) {
        const EPSILON: f64 = 0.000001;
        let mut n = p2(-v.y, v.x);
        n.normalize();
        (q + EPSILON * n, q - EPSILON * n)
    }

    /// The crossing of the line q + t v nearest q: (t, the point), or None.
    pub fn closest_intersection(&self, q: P2, v: P2) -> Option<(f64, P2)> {
        const EPSILON: f64 = 0.000001;
        let (pl, pr) = Self::bounds(q, v);
        let mut ok = false;
        let mut t: f64 = 1000000.0;
        let mut inter = p2(0.0, 0.0);
        let mut old = 0;
        for i in 0..self.p.len() {
            let section = self.side(i, pl, pr, v);
            if i > 0 && ((section >= 0 && old <= 0) || (section <= 0 && old >= 0)) {
                let r = q - self.p[i - 1];
                let w = self.p[i] - self.p[i - 1];
                let denominator = v.x * w.y - v.y * w.x;
                if denominator != 0.0 {
                    let s = (v.x * r.y - r.x * v.y) / denominator;
                    if s >= -EPSILON && s <= 1.0 + EPSILON {
                        let d = (w.x * r.y - r.x * w.y) / denominator;
                        if d.abs() < t.abs() {
                            t = d;
                            inter = q + t * v;
                            ok = true;
                        }
                    }
                }
            }
            old = section;
        }
        ok.then_some((t, inter))
    }

    /// The first crossing of the line q + t v along the strip: (t, the point), or None.
    pub fn first_intersection(&self, q: P2, v: P2) -> Option<(f64, P2)> {
        const EPSILON: f64 = 0.000001;
        let (pl, pr) = Self::bounds(q, v);
        let mut old = 0;
        for i in 0..self.p.len() {
            let section = self.side(i, pl, pr, v);
            if i > 0 && ((section >= 0 && old <= 0) || (section <= 0 && old >= 0)) {
                let r = q - self.p[i - 1];
                let w = self.p[i] - self.p[i - 1];
                let denominator = v.x * w.y - v.y * w.x;
                if denominator != 0.0 {
                    let s = (v.x * r.y - r.x * v.y) / denominator;
                    if s >= -EPSILON && s <= 1.0 + EPSILON {
                        let t = (w.x * r.y - r.x * w.y) / denominator;
                        return Some((t, q + t * v));
                    }
                }
            }
            old = section;
        }
        None
    }

    /// The crossing a vocal tract contour is expected at (crossed from right to left): (t, the point), or None.
    pub fn special_intersection(&self, q: P2, v: P2) -> Option<(f64, P2)> {
        const EPSILON: f64 = 0.000001;
        let (pl, pr) = Self::bounds(q, v);
        let mut ok = false;
        let mut t: f64 = 1000000.0;
        let mut inter = p2(0.0, 0.0);
        let mut old = 0;
        for i in 0..self.p.len() {
            let section = self.side(i, pl, pr, v);
            if i > 0 && section >= 0 && old <= 0 {
                let r = q - self.p[i - 1];
                let w = self.p[i] - self.p[i - 1];
                let denominator = v.x * w.y - v.y * w.x;
                if denominator != 0.0 {
                    let s = (v.x * r.y - r.x * v.y) / denominator;
                    if s >= -EPSILON && s <= 1.0 + EPSILON {
                        let d = (w.x * r.y - r.x * w.y) / denominator;
                        if !ok || (d >= 0.0 && d < t) || (d <= 0.0 && d > t) {
                            t = d;
                            inter = q + t * v;
                            ok = true;
                        }
                    }
                }
            }
            old = section;
        }
        ok.then_some((t, inter))
    }

    /// VocalTractLab 2.4's getSpecialIntersection (src/v24): of the crossings from the line's right, the nearest ahead
    /// of q where there is one, else the nearest behind it -- where 2.3's took whichever came last nearer on its side.
    pub fn special_intersection_v24(&self, q: P2, v: P2) -> Option<(f64, P2)> {
        const EPSILON: f64 = 0.000001;
        let (pl, pr) = Self::bounds(q, v);
        let mut ok = false;
        let mut t: f64 = 1000000.0;
        let mut inter = p2(0.0, 0.0);
        let mut old = 0;
        for i in 0..self.p.len() {
            let section = self.side(i, pl, pr, v);
            if i > 0 && section >= 0 && old <= 0 {
                let r = q - self.p[i - 1];
                let w = self.p[i] - self.p[i - 1];
                let denominator = v.x * w.y - v.y * w.x;
                if denominator != 0.0 {
                    let s = (v.x * r.y - r.x * v.y) / denominator;
                    if s >= -EPSILON && s <= 1.0 + EPSILON {
                        let d = (w.x * r.y - r.x * w.y) / denominator;
                        let accept = if !ok { true } else if d > 0.0 { t < 0.0 || d < t } else { t < 0.0 && d > t };
                        if accept {
                            t = d;
                            inter = q + t * v;
                            ok = true;
                        }
                    }
                }
            }
            old = section;
        }
        ok.then_some((t, inter))
    }

    /// VocalTractLab 2.4's getIntersectionWithGreatestT: of the crossings from either side, the one farthest along v.
    pub fn intersection_with_greatest_t(&self, q: P2, v: P2) -> Option<(f64, P2)> {
        const EPSILON: f64 = 0.000001;
        let (pl, pr) = Self::bounds(q, v);
        let mut ok = false;
        let mut t: f64 = -1000000.0;
        let mut inter = p2(0.0, 0.0);
        let mut old = 0;
        for i in 0..self.p.len() {
            let section = self.side(i, pl, pr, v);
            if i > 0 && ((section >= 0 && old <= 0) || (section <= 0 && old >= 0)) {
                let r = q - self.p[i - 1];
                let w = self.p[i] - self.p[i - 1];
                let denominator = v.x * w.y - v.y * w.x;
                if denominator != 0.0 {
                    let s = (v.x * r.y - r.x * v.y) / denominator;
                    if s >= -EPSILON && s <= 1.0 + EPSILON {
                        let d = (w.x * r.y - r.x * w.y) / denominator;
                        if d > t {
                            t = d;
                            inter = q + t * v;
                            ok = true;
                        }
                    }
                }
            }
            old = section;
        }
        ok.then_some((t, inter))
    }
}

#[derive(Clone, Debug, Default)]
pub struct LineStrip3D {
    p: Vec<P3>,
    pos: Vec<f64>,
}

impl LineStrip3D {
    pub fn from_points(points: &[P3]) -> Self {
        let mut s = LineStrip3D { p: points[..points.len().min(MAX_SPLINE_POINTS)].to_vec(), pos: Vec::new() };
        s.calculate_params();
        s
    }
    fn calculate_params(&mut self) {
        let n = self.p.len();
        self.pos.resize(n, 0.0);
        if n < 1 {
            return;
        }
        self.pos[0] = 0.0;
        for i in 1..n {
            self.pos[i] = self.pos[i - 1] + (self.p[i] - self.p[i - 1]).magnitude();
        }
        let length = self.pos[n - 1];
        if length > 0.0 {
            for i in 1..n {
                self.pos[i] /= length;
            }
        }
    }
    pub fn curve_param(&self, index: i32) -> f64 {
        let index = index.min(self.p.len() as i32 - 1).max(0) as usize;
        self.pos[index]
    }
    pub fn control_point(&self, index: usize) -> P3 {
        if index >= self.p.len() {
            p3(0.0, 0.0, 0.0)
        } else {
            self.p[index]
        }
    }
    /// Where the strip crosses the plane, nearest plane_point: its curve parameter (0 where it does not).
    pub fn plane_intersection(&self, plane_point: P3, plane_normal: P3) -> f64 {
        let n = self.p.len();
        if n < 2 {
            return 0.0;
        }
        const EPSILON: f64 = 0.000001;
        let mut result = 0.0;
        let mut min_dist = 1000000.0;
        for i in 0..n - 1 {
            let mut p0 = self.p[i];
            if i == 0 {
                let mut v = self.p[i + 1] - self.p[i];
                let length = v.magnitude();
                if length > 0.0 {
                    v = v / length;
                    p0 = p0 - v * EPSILON;
                }
            }
            let mut p1 = self.p[i + 1];
            if i + 1 == n - 1 {
                let mut v = self.p[i + 1] - self.p[i];
                let length = v.magnitude();
                if length > 0.0 {
                    v = v / length;
                    p1 += v * EPSILON;
                }
            }
            let d = [dot3(p0 - plane_point, plane_normal), dot3(p1 - plane_point, plane_normal)];
            if (d[0] <= 0.0 && d[1] >= 0.0) || (d[1] <= 0.0 && d[0] >= 0.0) {
                let v = p1 - p0;
                let denominator = dot3(v, plane_normal);
                if denominator != 0.0 {
                    let t = -dot3(p0 - plane_point, plane_normal) / denominator;
                    let q = p0 + t * v;
                    let dist = (q - plane_point).magnitude();
                    if dist < min_dist {
                        result = self.pos[i] + t * (self.pos[i + 1] - self.pos[i]);
                        min_dist = dist;
                    }
                }
            }
        }
        result
    }
}

impl Curve3 for LineStrip3D {
    fn point(&mut self, t: f64) -> P3 {
        let n = self.p.len();
        if n < 1 {
            return p3(0.0, 0.0, 0.0);
        }
        if n == 1 {
            return self.p[0];
        }
        let t = t.clamp(0.0, 1.0);
        const EPSILON: f64 = 0.000001;
        let mut ratio = 0.0;
        let mut k: i32 = -1;
        for i in 0..n - 1 {
            if t >= self.pos[i] - EPSILON && t <= self.pos[i + 1] + EPSILON {
                k = i as i32;
                let mut length = self.pos[i + 1] - self.pos[i];
                if length < EPSILON {
                    length = EPSILON;
                }
                ratio = (t - self.pos[i]) / length;
            }
        }
        if k == -1 {
            return p3(0.0, 0.0, 0.0);
        }
        let k = k as usize;
        self.p[k] + ratio * (self.p[k + 1] - self.p[k])
    }
    fn num_points(&self) -> usize {
        self.p.len()
    }
}

/// A rational Bezier curve, its numerator's and denominator's polynomials in t.
#[derive(Clone, Debug, Default)]
pub struct BezierCurve3D {
    p: Vec<P3>,
    w: Vec<f64>,
    a: Vec<P3>,
    b: Vec<f64>,
    changed: bool,
}

impl BezierCurve3D {
    pub fn new() -> Self {
        BezierCurve3D::default()
    }
    pub fn from_points(points: &[P3]) -> Self {
        let mut c = BezierCurve3D::default();
        c.set_points(points, None);
        c
    }
    pub fn set_points(&mut self, points: &[P3], weights: Option<&[f64]>) {
        let n = points.len().min(MAX_SPLINE_POINTS);
        self.p = points[..n].to_vec();
        self.w = weights.map(|w| w[..n].to_vec()).unwrap_or_else(|| vec![1.0; n]);
        self.changed = true;
    }
    pub fn set_point(&mut self, index: usize, point: P3, weight: f64) {
        if index < self.p.len() {
            self.p[index] = point;
            self.w[index] = weight;
            self.changed = true;
        }
    }
    pub fn add_point(&mut self, point: P3, weight: f64) {
        if self.p.len() < MAX_SPLINE_POINTS {
            self.p.push(point);
            self.w.push(weight);
            self.changed = true;
        }
    }
    pub fn control_point(&self, index: i32) -> P3 {
        if index < 0 || index as usize >= self.p.len() {
            p3(0.0, 0.0, 0.0)
        } else {
            self.p[index as usize]
        }
    }
    fn bernstein_coeff(k: usize, n: usize, coeff: &mut [f64]) {
        for c in coeff.iter_mut().take(n + 1) {
            *c = 0.0;
        }
        coeff[k] = 1.0;
        let mut new_coeff = [0.0; MAX_SPLINE_POINTS];
        for _ in 1..=n - k {
            for c in new_coeff.iter_mut().take(n + 1) {
                *c = 0.0;
            }
            for j in 0..=n {
                new_coeff[j] += coeff[j];
                if j + 1 < MAX_SPLINE_POINTS {
                    new_coeff[j + 1] -= coeff[j];
                }
            }
            coeff[..=n].copy_from_slice(&new_coeff[..=n]);
        }
        let mut numerator = 1.0;
        let mut denominator = 1.0;
        for j in 2..=n {
            numerator *= j as f64;
        }
        for j in 2..=k {
            denominator *= j as f64;
        }
        for j in 2..=n - k {
            denominator *= j as f64;
        }
        let f = numerator / denominator;
        for c in coeff.iter_mut().take(n + 1) {
            *c *= f;
        }
    }
    fn calculate_coeff(&mut self) {
        let n = self.p.len() - 1;
        self.a = vec![p3(0.0, 0.0, 0.0); n + 1];
        self.b = vec![0.0; n + 1];
        let mut coeff = [0.0; MAX_SPLINE_POINTS + 1];
        for i in 0..=n {
            Self::bernstein_coeff(i, n, &mut coeff);
            for j in 0..=n {
                self.a[j] += self.w[i] * coeff[j] * self.p[i];
                self.b[j] += self.w[i] * coeff[j];
            }
        }
        self.changed = false;
    }
}

impl Curve3 for BezierCurve3D {
    fn point(&mut self, t: f64) -> P3 {
        if self.p.len() < 2 {
            return p3(0.0, 0.0, 0.0);
        }
        if self.changed {
            self.calculate_coeff();
        }
        let mut q = p3(0.0, 0.0, 0.0);
        let mut f = 1.0;
        let mut denominator = 0.0;
        for i in 0..self.p.len() {
            q += self.a[i] * f;
            denominator += self.b[i] * f;
            f *= t;
        }
        q / denominator
    }
    fn num_points(&self) -> usize {
        self.p.len()
    }
}
