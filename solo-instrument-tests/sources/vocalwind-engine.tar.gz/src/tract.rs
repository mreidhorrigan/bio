// The vocal tract's geometry (VocalTract.cpp; Birkholz 2005, 2013): a speaker's anatomy (palate, jaw and teeth, lips,
// velum, pharynx, larynx, tongue) as surfaces of triangles in three dimensions, shaped each frame by its 19 parameters
// (hyoid, jaw, lips, velum, tongue body, tip, blade, root and sides); a center line from glottis to lips; at each of its
// 129 points the tract cut by the plane normal to it, the cut's upper and lower profiles giving the cross-section's area
// and perimeter; and those read into the tube's 40 pharynx and mouth sections. Here the anatomy, the frame's surfaces,
// lips and radiation surface; tongue.rs the tongue; sections.rs the center line, the cross-sections and the tube. Each
// expression in the C++'s order; the surfaces only drawn (two-sided copies, normals) are not made.
use crate::geometry::{ellipse_tangent, p2, p3, P2, P3};
use crate::splines::{BezierCurve3D, Curve3, LineStrip2D, LineStrip3D};
use crate::surface::Surface;
use crate::tube::Articulator;
use crate::xml::Node;
use std::f64::consts::PI;

pub const NUM_EPIGLOTTIS_RIBS: usize = 4;
pub const NUM_EPIGLOTTIS_POINTS: usize = 5;
pub const NUM_UVULA_RIBS: usize = 4;
pub const NUM_UVULA_POINTS: usize = 5;
pub const NUM_LARYNX_RIBS: usize = 5;
pub const NUM_PHARYNX_RIBS: usize = 3;
pub const NUM_VELUM_RIBS: usize = 6;
pub const NUM_PALATE_RIBS: usize = 9;
pub const NUM_JAW_RIBS: usize = NUM_PALATE_RIBS;
pub const NUM_THROAT_RIBS: usize = NUM_PHARYNX_RIBS;
pub const NUM_UPPER_COVER_RIBS: usize = NUM_LARYNX_RIBS + NUM_PHARYNX_RIBS + NUM_VELUM_RIBS + NUM_JAW_RIBS;
pub const NUM_UPPER_COVER_POINTS: usize = 6;
pub const NUM_LOWER_COVER_RIBS: usize = NUM_LARYNX_RIBS + NUM_THROAT_RIBS + NUM_JAW_RIBS;
pub const NUM_LOWER_COVER_POINTS: usize = 5;
pub const NUM_DYNAMIC_TONGUE_RIBS: usize = 33;
pub const NUM_STATIC_TONGUE_RIBS: usize = 4;
pub const NUM_TONGUE_RIBS: usize = NUM_DYNAMIC_TONGUE_RIBS + NUM_STATIC_TONGUE_RIBS;
pub const NUM_TONGUE_POINTS: usize = 11;
pub const NUM_TEETH_RIBS: usize = 3 * (NUM_JAW_RIBS - 1) + 1;
pub const NUM_TEETH_POINTS: usize = 5;
pub const NUM_LIP_RIBS: usize = NUM_JAW_RIBS;
pub const NUM_INNER_LIP_POINTS: usize = 5;
pub const NUM_OUTER_LIP_POINTS: usize = 5;
pub const NUM_LIP_POINTS: usize = NUM_INNER_LIP_POINTS + NUM_OUTER_LIP_POINTS;
pub const NUM_FILL_RIBS: usize = NUM_JAW_RIBS + 3;
pub const NUM_FILL_POINTS: usize = 4;
pub const NUM_RADIATION_RIBS: usize = NUM_LIP_RIBS + 4;
pub const NUM_RADIATION_POINTS: usize = 6;
pub const NUM_PROFILE_SAMPLES: usize = 96;
pub const PROFILE_LENGTH: f64 = 5.5;
pub const PROFILE_SAMPLE_LENGTH: f64 = PROFILE_LENGTH / NUM_PROFILE_SAMPLES as f64;
pub const INVALID_PROFILE_SAMPLE: f64 = 1000000.0;
pub const MIN_PROFILE_VALUE: f64 = -2.75;
pub const MAX_PROFILE_VALUE: f64 = 10.0;
pub const EXTREME_PROFILE_VALUE: f64 = 1000000.0;
pub const NUM_CENTERLINE_POINTS_EXPONENT: usize = 7;
pub const NUM_CENTERLINE_POINTS: usize = (1 << NUM_CENTERLINE_POINTS_EXPONENT) + 1;
pub const NUM_TUBE_SECTIONS: usize = crate::tube::NUM_PHARYNX_MOUTH_SECTIONS;
pub const NUM_PHARYNX_SECTIONS: usize = crate::tube::NUM_PHARYNX_SECTIONS;

// The surfaces, by the C++'s SurfaceIndex (the ones only drawn are made empty).
pub const UPPER_TEETH: usize = 0;
pub const LOWER_TEETH: usize = 1;
pub const UPPER_COVER: usize = 2;
pub const LOWER_COVER: usize = 3;
pub const UPPER_LIP: usize = 4;
pub const LOWER_LIP: usize = 5;
pub const PALATE: usize = 6;
pub const MANDIBLE: usize = 7;
pub const LOWER_TEETH_ORIGINAL: usize = 8;
pub const LOW_VELUM: usize = 9;
pub const MID_VELUM: usize = 10;
pub const HIGH_VELUM: usize = 11;
pub const NARROW_LARYNX_FRONT: usize = 12;
pub const NARROW_LARYNX_BACK: usize = 13;
pub const WIDE_LARYNX_FRONT: usize = 14;
pub const WIDE_LARYNX_BACK: usize = 15;
pub const TONGUE: usize = 16;
pub const LEFT_COVER: usize = 23;
pub const UVULA_ORIGINAL: usize = 25;
pub const UVULA: usize = 26;
pub const EPIGLOTTIS_ORIGINAL: usize = 28;
pub const EPIGLOTTIS: usize = 29;
pub const RADIATION: usize = 31;
pub const NUM_SURFACES: usize = 32;

// The parameters, by the C++'s ParamIndex.
pub const HX: usize = 0;
pub const HY: usize = 1;
pub const JX: usize = 2;
pub const JA: usize = 3;
pub const LP: usize = 4;
pub const LD: usize = 5;
pub const VS: usize = 6;
pub const VO: usize = 7;
pub const TCX: usize = 8;
pub const TCY: usize = 9;
pub const TTX: usize = 10;
pub const TTY: usize = 11;
pub const TBX: usize = 12;
pub const TBY: usize = 13;
pub const TRX: usize = 14;
pub const TRY: usize = 15;
pub const TS1: usize = 16;
pub const TS2: usize = 17;
pub const TS3: usize = 18;
pub const NUM_PARAMS: usize = 19;

#[derive(Clone, Debug, Default)]
pub struct Param {
    pub name: String,
    pub x: f64,
    pub limited_x: f64,
    pub min: f64,
    pub max: f64,
    pub neutral: f64,
}

/// The speaker's articulation-invariant anatomy (VocalTract::Anatomy).
#[derive(Clone, Debug, Default)]
pub struct Anatomy {
    pub palate_points: [P3; NUM_PALATE_RIBS],
    pub palate_angle_deg: [f64; NUM_PALATE_RIBS],
    pub palate_height_cm: [f64; NUM_PALATE_RIBS],
    pub upper_teeth_height_cm: [f64; NUM_PALATE_RIBS],
    pub upper_teeth_width_top_cm: [f64; NUM_PALATE_RIBS],
    pub upper_teeth_width_bottom_cm: [f64; NUM_PALATE_RIBS],
    pub jaw_fulcrum: P2,
    pub jaw_rest_pos: P2,
    pub tooth_root_length_cm: f64,
    pub jaw_points: [P3; NUM_JAW_RIBS],
    pub jaw_angle_deg: [f64; NUM_JAW_RIBS],
    pub jaw_height_cm: [f64; NUM_JAW_RIBS],
    pub lower_teeth_height_cm: [f64; NUM_JAW_RIBS],
    pub lower_teeth_width_top_cm: [f64; NUM_JAW_RIBS],
    pub lower_teeth_width_bottom_cm: [f64; NUM_JAW_RIBS],
    pub tongue_tip_radius_cm: f64,
    pub tongue_center_radius_x_cm: f64,
    pub tongue_center_radius_y_cm: f64,
    pub automatic_tongue_root_calc: bool,
    pub tongue_root_trx_slope: f64,
    pub tongue_root_trx_intercept: f64,
    pub tongue_root_try_slope: f64,
    pub tongue_root_try_intercept: f64,
    pub lips_width_cm: f64,
    pub uvula_width_cm: f64,
    pub uvula_height_cm: f64,
    pub uvula_depth_cm: f64,
    pub velum_low_points: [P2; NUM_VELUM_RIBS - 1],
    pub velum_mid_points: [P2; NUM_VELUM_RIBS - 1],
    pub velum_high_points: [P2; NUM_VELUM_RIBS - 1],
    pub max_nasal_port_area_cm2: f64,
    pub pharynx_fulcrum: P2,
    pub pharynx_rotation_angle_deg: f64,
    pub pharynx_top_rib_y_cm: f64,
    pub pharynx_upper_depth_cm: f64,
    pub pharynx_lower_depth_cm: f64,
    pub pharynx_back_width_cm: f64,
    pub epiglottis_width_cm: f64,
    pub epiglottis_height_cm: f64,
    pub epiglottis_depth_cm: f64,
    pub epiglottis_angle_deg: f64,
    pub larynx_upper_depth_cm: f64,
    pub larynx_lower_depth_cm: f64,
    pub larynx_wide_points: [P2; 8],
    pub larynx_narrow_points: [P2; 8],
    pub piriform_fossa_length_cm: f64,
    pub piriform_fossa_volume_cm3: f64,
    pub subglottal_cavity_length_cm: f64,
    pub nasal_cavity_length_cm: f64,
    /// Each parameter's intrinsic speed rising and falling: a gesture's time constant divided by it (GesturalScore).
    pub positive_velocity_factor: [f64; NUM_PARAMS],
    pub negative_velocity_factor: [f64; NUM_PARAMS],
}

#[derive(Clone, Copy, Debug, Default)]
pub struct TongueRib {
    pub point: P2,
    pub left_side_height: f64,
    pub right_side_height: f64,
    pub left: P2,
    pub right: P2,
    pub normal: P2,
    pub min_x: f64,
    pub max_x: f64,
    pub min_y: f64,
    pub max_y: f64,
}

#[derive(Clone, Copy, Debug, Default)]
pub struct CenterLinePoint {
    pub point: P2,
    pub normal: P2,
    pub pos: f64,
    pub min: f64,
    pub max: f64,
    pub reserved: f64,
}

#[derive(Clone, Copy, Debug, Default)]
pub struct CrossSection {
    pub area: f64,
    pub circ: f64,
    pub pos: f64,
    pub articulator: Articulator,
}

#[derive(Clone, Copy, Debug, Default)]
pub struct TubeSection {
    pub area: f64,
    pub circ: f64,
    pub pos: f64,
    pub length: f64,
    pub articulator: Articulator,
}

/// What a frame's geometry hands the tube (VocalTract::getTube): the pharynx and mouth's 40 sections, the incisors'
/// position along them, the tongue tip's sides and the velopharyngeal port.
#[derive(Clone, Debug)]
pub struct TractTube {
    pub length_cm: [f64; NUM_TUBE_SECTIONS],
    pub area_cm2: [f64; NUM_TUBE_SECTIONS],
    pub articulator: [Articulator; NUM_TUBE_SECTIONS],
    pub incisor_pos_cm: f64,
    /// Whether this frame found its incisors along the center line; where not, the C++ keeps the last frame's position
    /// (live.rs carries it so across the workers that make the frames).
    pub incisor_found: bool,
    pub tongue_tip_side_elevation: f64,
    pub velum_opening_cm2: f64,
    /// The speaker's static cavities: (piriform fossa length, its volume, subglottal length, nasal length).
    pub fossa_length_cm: f64,
    pub fossa_volume_cm3: f64,
    pub subglottal_length_cm: f64,
    pub nasal_length_cm: f64,
}

#[derive(Clone)]
pub struct VocalTract {
    pub anatomy: Anatomy,
    pub param: Vec<Param>,
    pub shapes: Vec<(String, [f64; NUM_PARAMS])>,
    pub surface: Vec<Surface>,
    pub(crate) intersections_prepared: [bool; NUM_SURFACES],
    pub tongue_rib: [TongueRib; NUM_TONGUE_RIBS],
    pub(crate) wide_lip_corner_path: LineStrip3D,
    pub(crate) narrow_lip_corner_path: LineStrip3D,
    pub(crate) lip_corner_path: LineStrip3D,
    pub center_line_length: f64,
    pub center_line: [CenterLinePoint; NUM_CENTERLINE_POINTS],
    pub cross_section: [CrossSection; NUM_CENTERLINE_POINTS],
    pub tube_section: [TubeSection; NUM_TUBE_SECTIONS],
    pub nasal_port_pos_cm: f64,
    pub nasal_port_area_cm2: f64,
    pub incisor_pos_cm: f64,
    pub incisor_found: bool,
    /// VocalTractLab's bugs in its geometry mended (docs/VOCAL_TRACT.md, "Found in reading"): a cut's P0 bounded, no
    /// triangle list's tiles dropped, the pharynx's angle normalized in degrees. Off: VocalTractLab's own, to the bit.
    pub mended: bool,
    pub(crate) upper_gums_inner_edge: [P3; NUM_JAW_RIBS],
    pub(crate) upper_gums_outer_edge: [P3; NUM_JAW_RIBS],
    pub(crate) lower_gums_inner_edge: [P3; NUM_JAW_RIBS],
    pub(crate) lower_gums_outer_edge: [P3; NUM_JAW_RIBS],
    pub(crate) lower_gums_inner_edge_orig: [P3; NUM_JAW_RIBS],
    pub(crate) lower_gums_outer_edge_orig: [P3; NUM_JAW_RIBS],
    pub upper_outline: LineStrip2D,
    pub lower_outline: LineStrip2D,
    pub tongue_outline: LineStrip2D,
    pub epiglottis_outline: LineStrip2D,
    // Scratch for the cuts, kept to allocate nothing per frame.
    pub(crate) scratch_list: Vec<usize>,
    pub(crate) scratch_cuts: Vec<crate::sections::Cut>,
}

fn rotate_jaw(a: &Anatomy, jx: f64, cosinus: f64, sinus: f64, v: P3) -> P3 {
    let dx = v.x + a.jaw_rest_pos.x + jx - a.jaw_fulcrum.x;
    let dy = v.y + a.jaw_rest_pos.y - a.jaw_fulcrum.y;
    p3(cosinus * dx - sinus * dy + a.jaw_fulcrum.x, sinus * dx + cosinus * dy + a.jaw_fulcrum.y, v.z)
}

impl VocalTract {
    /// The vocal tract of a speaker file's <vocal_tract_model>, its geometry made for its parameters' neutral values.
    pub fn from_xml(node: &Node) -> Result<VocalTract, String> {
        let mut surface: Vec<Surface> = (0..NUM_SURFACES).map(|_| Surface::default()).collect();
        let dims: [(usize, usize, usize); 20] = [
            (UPPER_COVER, NUM_UPPER_COVER_RIBS, NUM_UPPER_COVER_POINTS),
            (LOWER_COVER, NUM_LOWER_COVER_RIBS, NUM_LOWER_COVER_POINTS),
            (UPPER_TEETH, NUM_TEETH_RIBS, NUM_TEETH_POINTS),
            (LOWER_TEETH, NUM_TEETH_RIBS, NUM_TEETH_POINTS),
            (UPPER_LIP, NUM_LIP_RIBS, NUM_LIP_POINTS),
            (LOWER_LIP, NUM_LIP_RIBS, NUM_LIP_POINTS),
            (TONGUE, NUM_TONGUE_RIBS, NUM_TONGUE_POINTS),
            (LEFT_COVER, NUM_FILL_RIBS, NUM_FILL_POINTS),
            (EPIGLOTTIS, NUM_EPIGLOTTIS_RIBS, NUM_EPIGLOTTIS_POINTS),
            (UVULA, NUM_UVULA_RIBS, NUM_UVULA_POINTS),
            (RADIATION, NUM_RADIATION_RIBS, NUM_RADIATION_POINTS),
            (NARROW_LARYNX_FRONT, NUM_LARYNX_RIBS, NUM_LOWER_COVER_POINTS),
            (NARROW_LARYNX_BACK, NUM_LARYNX_RIBS, NUM_UPPER_COVER_POINTS),
            (WIDE_LARYNX_FRONT, NUM_LARYNX_RIBS, NUM_LOWER_COVER_POINTS),
            (WIDE_LARYNX_BACK, NUM_LARYNX_RIBS, NUM_UPPER_COVER_POINTS),
            (LOWER_TEETH_ORIGINAL, NUM_TEETH_RIBS, NUM_TEETH_POINTS),
            (LOW_VELUM, NUM_VELUM_RIBS, NUM_UPPER_COVER_POINTS),
            (MID_VELUM, NUM_VELUM_RIBS, NUM_UPPER_COVER_POINTS),
            (HIGH_VELUM, NUM_VELUM_RIBS, NUM_UPPER_COVER_POINTS),
            (PALATE, NUM_JAW_RIBS, NUM_UPPER_COVER_POINTS),
        ];
        for (i, r, p) in dims {
            surface[i] = Surface::new(r, p);
        }
        surface[MANDIBLE] = Surface::new(NUM_JAW_RIBS, NUM_LOWER_COVER_POINTS);
        surface[EPIGLOTTIS_ORIGINAL] = Surface::new(NUM_EPIGLOTTIS_RIBS, NUM_EPIGLOTTIS_POINTS);
        surface[UVULA_ORIGINAL] = Surface::new(NUM_UVULA_RIBS, NUM_UVULA_POINTS);
        // (As the C++ turns them for drawing: it turns the triangles' normals, which the profiles read.)
        for i in [LOWER_COVER, UPPER_TEETH, UPPER_LIP, TONGUE, LEFT_COVER, EPIGLOTTIS] {
            surface[i].swap_triangle_orientation();
        }
        let mut vt = VocalTract {
            anatomy: Anatomy::default(),
            param: vec![Param::default(); NUM_PARAMS],
            shapes: Vec::new(),
            surface,
            intersections_prepared: [false; NUM_SURFACES],
            tongue_rib: [TongueRib::default(); NUM_TONGUE_RIBS],
            wide_lip_corner_path: LineStrip3D::default(),
            narrow_lip_corner_path: LineStrip3D::default(),
            lip_corner_path: LineStrip3D::default(),
            center_line_length: 0.0,
            center_line: [CenterLinePoint::default(); NUM_CENTERLINE_POINTS],
            cross_section: [CrossSection::default(); NUM_CENTERLINE_POINTS],
            tube_section: [TubeSection::default(); NUM_TUBE_SECTIONS],
            nasal_port_pos_cm: 0.0,
            nasal_port_area_cm2: 0.0,
            incisor_pos_cm: 0.0,
            incisor_found: false,
            mended: false,
            upper_gums_inner_edge: [P3::default(); NUM_JAW_RIBS],
            upper_gums_outer_edge: [P3::default(); NUM_JAW_RIBS],
            lower_gums_inner_edge: [P3::default(); NUM_JAW_RIBS],
            lower_gums_outer_edge: [P3::default(); NUM_JAW_RIBS],
            lower_gums_inner_edge_orig: [P3::default(); NUM_JAW_RIBS],
            lower_gums_outer_edge_orig: [P3::default(); NUM_JAW_RIBS],
            upper_outline: LineStrip2D::new(),
            lower_outline: LineStrip2D::new(),
            tongue_outline: LineStrip2D::new(),
            epiglottis_outline: LineStrip2D::new(),
            scratch_list: Vec::with_capacity(crate::sections::MAX_LIST_ENTRIES),
            scratch_cuts: Vec::with_capacity(crate::sections::MAX_CUTS),
        };
        for s in vt.surface[TONGUE].coord.iter_mut() {
            *s = p3(-0.31, -1.02, 0.0);
        }
        vt.read_anatomy(node.child("anatomy").ok_or("no <anatomy>")?)?;
        let shapes = node.child("shapes").ok_or("no <shapes>")?;
        for s in shapes.children_named("shape") {
            let mut v = [0.0; NUM_PARAMS];
            for (k, p) in vt.param.iter().enumerate() {
                v[k] = p.neutral;
            }
            for p in s.children_named("param") {
                let name = p.attr("name").unwrap_or("");
                if let Some(k) = vt.param.iter().position(|q| q.name == name) {
                    v[k] = p.num("value")?;
                }
            }
            vt.shapes.push((s.attr("name").unwrap_or("--").to_string(), v));
        }
        vt.calculate_all();
        Ok(vt)
    }

    pub fn shape(&self, name: &str) -> Option<[f64; NUM_PARAMS]> {
        self.shapes.iter().find(|(n, _)| n == name).map(|(_, v)| *v)
    }

    fn read_anatomy(&mut self, an: &Node) -> Result<(), String> {
        let child = |n: &Node, name: &str| -> Result<Node, String> { n.child(name).cloned().ok_or_else(|| format!("<{}>: no <{name}>", n.name)) };
        let points = |n: &Node, count: usize| -> Result<Vec<P2>, String> {
            let v: Vec<f64> = n.attr("points").unwrap_or("").split_whitespace().map(|x| x.parse::<f64>().map_err(|e| e.to_string())).collect::<Result<_, _>>()?;
            if v.len() < 2 * count {
                return Err(format!("<{}>: not enough point coordinates", n.name));
            }
            Ok((0..count).map(|i| p2(v[2 * i], v[2 * i + 1])).collect())
        };
        let a = &mut self.anatomy;
        let palate = child(an, "palate")?;
        for i in 0..NUM_PALATE_RIBS {
            let n = child(&palate, &format!("p{i}"))?;
            a.palate_points[i] = p3(n.num("x")?, 0.0, n.num("z")?);
            a.upper_teeth_height_cm[i] = n.num("teeth_height")?;
            a.upper_teeth_width_top_cm[i] = n.num("top_teeth_width")?;
            a.upper_teeth_width_bottom_cm[i] = n.num("bottom_teeth_width")?;
            a.palate_height_cm[i] = n.num("palate_height")?;
            a.palate_angle_deg[i] = n.num("palate_angle_deg")?;
        }
        let jaw = child(an, "jaw")?;
        a.jaw_fulcrum = p2(jaw.num("fulcrum_x")?, jaw.num("fulcrum_y")?);
        a.jaw_rest_pos = p2(jaw.num("rest_pos_x")?, jaw.num("rest_pos_y")?);
        a.tooth_root_length_cm = jaw.num("tooth_root_length")?;
        for i in 0..NUM_JAW_RIBS {
            let n = child(&jaw, &format!("p{i}"))?;
            a.jaw_points[i] = p3(n.num("x")?, 0.0, n.num("z")?);
            a.lower_teeth_height_cm[i] = n.num("teeth_height")?;
            a.lower_teeth_width_top_cm[i] = n.num("top_teeth_width")?;
            a.lower_teeth_width_bottom_cm[i] = n.num("bottom_teeth_width")?;
            a.jaw_height_cm[i] = n.num("jaw_height")?;
            a.jaw_angle_deg[i] = n.num("jaw_angle_deg")?;
        }
        let tongue = child(an, "tongue")?;
        a.tongue_tip_radius_cm = child(&tongue, "tip")?.num("radius")?;
        let body = child(&tongue, "body")?;
        a.tongue_center_radius_x_cm = body.num("radius_x")?;
        a.tongue_center_radius_y_cm = body.num("radius_y")?;
        let root = child(&tongue, "root")?;
        a.automatic_tongue_root_calc = root.num("automatic_calc")? as i32 != 0;
        a.tongue_root_trx_slope = root.num("trx_slope")?;
        a.tongue_root_trx_intercept = root.num("trx_intercept")?;
        a.tongue_root_try_slope = root.num("try_slope")?;
        a.tongue_root_try_intercept = root.num("try_intercept")?;
        a.lips_width_cm = child(an, "lips")?.num("width")?;
        let velum = child(an, "velum")?;
        a.uvula_width_cm = velum.num("uvula_width")?;
        a.uvula_height_cm = velum.num("uvula_height")?;
        a.uvula_depth_cm = velum.num("uvula_depth")?;
        a.max_nasal_port_area_cm2 = velum.num("max_nasal_port_area")?;
        a.velum_low_points.copy_from_slice(&points(&child(&velum, "low")?, 5)?);
        a.velum_mid_points.copy_from_slice(&points(&child(&velum, "mid")?, 5)?);
        a.velum_high_points.copy_from_slice(&points(&child(&velum, "high")?, 5)?);
        let ph = child(an, "pharynx")?;
        a.pharynx_fulcrum = p2(ph.num("fulcrum_x")?, ph.num("fulcrum_y")?);
        a.pharynx_rotation_angle_deg = ph.num("rotation_angle_deg")?;
        a.pharynx_top_rib_y_cm = ph.num("top_rib_y")?;
        a.pharynx_upper_depth_cm = ph.num("upper_depth")?;
        a.pharynx_lower_depth_cm = ph.num("lower_depth")?;
        a.pharynx_back_width_cm = ph.num("back_side_width")?;
        let lx = child(an, "larynx")?;
        a.larynx_upper_depth_cm = lx.num("upper_depth")?;
        a.larynx_lower_depth_cm = lx.num("lower_depth")?;
        a.epiglottis_width_cm = lx.num("epiglottis_width")?;
        a.epiglottis_height_cm = lx.num("epiglottis_height")?;
        a.epiglottis_depth_cm = lx.num("epiglottis_depth")?;
        a.epiglottis_angle_deg = lx.num("epiglottis_angle_deg")?;
        a.larynx_narrow_points.copy_from_slice(&points(&child(&lx, "narrow")?, 8)?);
        a.larynx_wide_points.copy_from_slice(&points(&child(&lx, "wide")?, 8)?);
        let pf = child(an, "piriform_fossa")?;
        a.piriform_fossa_length_cm = pf.num("length")?;
        a.piriform_fossa_volume_cm3 = pf.num("volume")?;
        a.subglottal_cavity_length_cm = child(an, "subglottal_cavity")?.num("length")?;
        a.nasal_cavity_length_cm = child(an, "nasal_cavity")?.num("length")?;
        let mut read = [false; NUM_PARAMS];
        for n in an.children_named("param") {
            let m = n.num("index")? as i64;
            if !(0..NUM_PARAMS as i64).contains(&m) {
                return Err(format!("<param index=\"{m}\">: out of range"));
            }
            let m = m as usize;
            read[m] = true;
            let p = &mut self.param[m];
            p.name = n.attr("name").unwrap_or("").to_string();
            p.min = n.num("min")?;
            p.max = n.num("max")?;
            p.neutral = n.num("neutral")?;
            p.x = p.neutral;
            p.limited_x = p.neutral;
            self.anatomy.positive_velocity_factor[m] = n.num("positive_velocity_factor")?;
            self.anatomy.negative_velocity_factor[m] = n.num("negative_velocity_factor")?;
        }
        if read.iter().any(|r| !r) {
            return Err("not every vocal tract parameter is defined".into());
        }
        self.init_larynx();
        self.init_jaws();
        self.init_velum();
        Ok(())
    }

    fn init_larynx(&mut self) {
        const EPSILON: f64 = 0.000001;
        for k in 0..2 {
            let l = if k == 0 { &mut self.anatomy.larynx_narrow_points } else { &mut self.anatomy.larynx_wide_points };
            // (The C++ enforces its conditions on the points, saying so.)
            if l[0].y != l[7].y {
                l[7].y = l[0].y;
            }
            if l[2].y != l[5].y {
                l[5].y = l[2].y;
            }
            if l[3].y != l[4].y {
                l[4].y = l[3].y;
            }
            if l[2].y < l[3].y {
                l[2].y = l[3].y;
                l[5].y = l[3].y;
            }
            if l[6].y < l[5].y {
                l[6].y = l[5].y;
            }
            if l[1].y < l[6].y {
                l[1].y = l[6].y;
            }
            if l[0].y < l[1].y {
                l[0].y = l[1].y;
                l[7].y = l[1].y;
            }
            if l[7].x > l[0].x {
                l[7].x = l[0].x;
            }
            if l[5].x > l[2].x {
                l[5].x = l[2].x;
            }
            if l[4].x > l[3].x {
                l[4].x = l[3].x;
            }
        }
        let w = [1.0, 0.7, 1.0];
        let a = &self.anatomy;
        for k in 0..2 {
            let l = if k == 0 { a.larynx_narrow_points } else { a.larynx_wide_points };
            let (mut y, mut xl, mut xr, mut xm, mut zm) = ([0.0; 5], [0.0; 5], [0.0; 5], [0.0; 5], [0.0; 5]);
            y[0] = l[3].y;
            xl[0] = l[4].x;
            xr[0] = l[3].x;
            xm[0] = 0.5 * (xl[0] + xr[0]);
            zm[0] = -0.5 * a.larynx_lower_depth_cm;
            y[1] = l[2].y;
            xl[1] = l[5].x;
            xr[1] = l[2].x;
            xm[1] = 0.5 * (xl[1] + xr[1]);
            zm[1] = -0.5 * a.larynx_upper_depth_cm;
            y[2] = l[6].y;
            xl[2] = l[6].x;
            let mut d = l[1].y - l[2].y;
            if d < EPSILON {
                d = EPSILON;
            }
            xr[2] = l[2].x + (l[1].x - l[2].x) * (l[6].y - l[2].y) / d;
            xm[2] = 0.25 * xl[2] + 0.75 * xr[2];
            zm[2] = -0.5 * a.pharynx_lower_depth_cm;
            y[3] = l[1].y;
            d = l[7].y - l[6].y;
            if d < EPSILON {
                d = EPSILON;
            }
            xl[3] = l[6].x + (l[7].x - l[6].x) * (l[1].y - l[6].y) / d;
            xr[3] = l[1].x;
            xm[3] = 0.2 * xl[3] + 0.8 * xr[3];
            zm[3] = -0.5 * a.pharynx_lower_depth_cm;
            y[4] = l[0].y;
            xl[4] = l[7].x;
            xr[4] = l[0].x;
            xm[4] = 0.5 * (xl[4] + xr[4]);
            zm[4] = -0.5 * a.pharynx_lower_depth_cm;
            let (back, front) = if k == 0 { (NARROW_LARYNX_BACK, NARROW_LARYNX_FRONT) } else { (WIDE_LARYNX_BACK, WIDE_LARYNX_FRONT) };
            for i in 0..NUM_LARYNX_RIBS {
                let mut curve = BezierCurve3D::new();
                curve.set_points(&[p3(xm[i], y[i], zm[i]), p3(xl[i], y[i], zm[i]), p3(xl[i], y[i], 0.0)], Some(&w));
                for j in 0..NUM_UPPER_COVER_POINTS {
                    let d = curve.uniform_param(j as f64 / (NUM_UPPER_COVER_POINTS - 1) as f64);
                    let q = curve.point(d);
                    self.surface[back].set(i, j, q);
                }
                curve.set_points(&[p3(xm[i], y[i], zm[i]), p3(xr[i], y[i], zm[i]), p3(xr[i], y[i], 0.0)], Some(&w));
                for j in 0..NUM_LOWER_COVER_POINTS {
                    let d = curve.uniform_param(j as f64 / (NUM_LOWER_COVER_POINTS - 1) as f64);
                    let q = curve.point(d);
                    self.surface[front].set(i, j, q);
                }
            }
        }
        // The epiglottis.
        let (width, height, depth) = (a.epiglottis_width_cm, a.epiglottis_height_cm, a.epiglottis_depth_cm);
        let mut p = [p3(0.0, 0.0, 0.0), p3(-0.25 * width, 0.0, -0.75 * 0.5 * depth), p3(-0.5 * width, 0.0, -0.5 * depth), p3(-width, 0.0, -0.75 * 0.5 * depth), p3(-width, 0.0, 0.0)];
        let s = &mut self.surface[EPIGLOTTIS_ORIGINAL];
        for (i, q) in p.iter_mut().enumerate() {
            q.y = 0.0;
            s.set(0, i, *q);
            q.y = 0.25 * height;
            s.set(1, i, *q);
            q.y = 0.75 * height;
            s.set(2, i, *q);
        }
        let d = height;
        let rib3 = [p3(-0.5 * width, d, 0.0), p3(-0.5 * width, d, -0.75 * 0.5 * depth), p3(-0.5 * width, d, -0.75 * 0.5 * depth), p3(-0.5 * width, d, -0.75 * 0.5 * depth), p3(-0.5 * width, d, 0.0)];
        for (i, q) in rib3.iter().enumerate() {
            s.set(3, i, *q);
        }
    }

    // One side's teeth (upper or lower): the ribs' heights, widths, points and normals, as initJaws makes them.
    fn teeth_ribs(points: &[P3; NUM_JAW_RIBS], height: &[f64; NUM_JAW_RIBS], top: &[f64; NUM_JAW_RIBS], bottom: &[f64; NUM_JAW_RIBS]) -> ([f64; NUM_TEETH_RIBS], [f64; NUM_TEETH_RIBS], [f64; NUM_TEETH_RIBS], [P3; NUM_TEETH_RIBS], [P3; NUM_TEETH_RIBS]) {
        const GROOVE_DEPTH: f64 = 0.15;
        let (mut th, mut ttw, mut tbw) = ([0.0; NUM_TEETH_RIBS], [0.0; NUM_TEETH_RIBS], [0.0; NUM_TEETH_RIBS]);
        let (mut tp, mut tn) = ([P3::default(); NUM_TEETH_RIBS], [P3::default(); NUM_TEETH_RIBS]);
        tp[0] = points[0];
        tn[0] = p3(points[1].z - points[0].z, 0.0, -(points[1].x - points[0].x));
        tn[0].normalize();
        tp[NUM_TEETH_RIBS - 1] = points[NUM_JAW_RIBS - 1];
        tn[NUM_TEETH_RIBS - 1] = p3(1.0, 0.0, 0.0);
        for i in 1..NUM_JAW_RIBS - 1 {
            let j = i * 3;
            tp[j] = points[i];
            tn[j] = p3(points[i + 1].z - points[i - 1].z, 0.0, -(points[i + 1].x - points[i - 1].x));
            tn[j].normalize();
        }
        for i in 0..NUM_JAW_RIBS - 1 {
            let t = 0.75;
            th[i * 3 + 1] = height[i];
            ttw[i * 3 + 1] = t * top[i] + (1.0 - t) * top[i + 1];
            tbw[i * 3 + 1] = t * bottom[i] + (1.0 - t) * bottom[i + 1];
            tp[i * 3 + 1] = t * tp[i * 3] + (1.0 - t) * tp[i * 3 + 3];
            tn[i * 3 + 1] = t * tn[i * 3] + (1.0 - t) * tn[i * 3 + 3];
            tn[i * 3 + 1].normalize();
            th[i * 3 + 2] = height[i];
            ttw[i * 3 + 2] = (1.0 - t) * top[i] + t * top[i + 1];
            tbw[i * 3 + 2] = (1.0 - t) * bottom[i] + t * bottom[i + 1];
            tp[i * 3 + 2] = (1.0 - t) * tp[i * 3] + t * tp[i * 3 + 3];
            tn[i * 3 + 2] = (1.0 - t) * tn[i * 3] + t * tn[i * 3 + 3];
            tn[i * 3 + 2].normalize();
            if height[i] == 0.0 {
                ttw[i * 3 + 1] = 0.0;
                tbw[i * 3 + 1] = 0.0;
                ttw[i * 3 + 2] = 0.0;
                tbw[i * 3 + 2] = 0.0;
            }
        }
        let t = 0.8;
        th[0] = th[1] - GROOVE_DEPTH;
        ttw[0] = 0.0;
        tbw[0] = 0.0;
        th[NUM_TEETH_RIBS - 1] = t * th[NUM_TEETH_RIBS - 2];
        ttw[NUM_TEETH_RIBS - 1] = t * ttw[NUM_TEETH_RIBS - 2];
        tbw[NUM_TEETH_RIBS - 1] = t * tbw[NUM_TEETH_RIBS - 2];
        for i in 1..NUM_JAW_RIBS - 1 {
            let j = i * 3;
            th[j] = if th[j - 1] < th[j + 1] { th[j - 1] - GROOVE_DEPTH } else { th[j + 1] - GROOVE_DEPTH };
            ttw[j] = t * 0.5 * (ttw[j - 1] + ttw[j + 1]);
            tbw[j] = t * 0.5 * (tbw[j - 1] + tbw[j + 1]);
        }
        for i in 0..NUM_TEETH_RIBS {
            if ttw[i] < 0.0 {
                ttw[i] = 0.0;
            }
            if tbw[i] < 0.0 {
                tbw[i] = 0.0;
            }
            if th[i] < 0.0 {
                th[i] = 0.0;
            }
        }
        (th, ttw, tbw, tp, tn)
    }

    fn init_jaws(&mut self) {
        const MIN_ANGLE_DEG: f64 = 0.000001;
        const MAX_ANGLE_DEG: f64 = 89.999999;
        let w = [1.0, 1.0, 1.0];
        let a = self.anatomy.clone();
        for i in 0..NUM_JAW_RIBS {
            let c0 = a.palate_points[i];
            let height_cm = a.palate_height_cm[i];
            let angle_deg = a.palate_angle_deg[i].clamp(MIN_ANGLE_DEG, MAX_ANGLE_DEG);
            let mut c1 = p3(c0.x, height_cm, c0.z + height_cm / (angle_deg * PI / 180.0).tan());
            if c1.z > 0.0 {
                c1.z = 0.0;
            }
            let c2 = p3(c0.x, height_cm, 0.0);
            let mut curve = BezierCurve3D::new();
            curve.set_points(&[c0, c1, c2], Some(&w));
            for j in 0..NUM_UPPER_COVER_POINTS {
                let u = curve.uniform_param(j as f64 / (NUM_UPPER_COVER_POINTS - 1) as f64);
                let q = curve.point(u);
                self.surface[PALATE].set(i, j, q);
            }
            let c0 = a.jaw_points[i];
            let height_cm = a.jaw_height_cm[i];
            let angle_deg = a.jaw_angle_deg[i].clamp(MIN_ANGLE_DEG, MAX_ANGLE_DEG);
            // (The most posterior jaw ribs a little oblique.)
            let delta = (a.jaw_points[8].x - a.jaw_points[0].x) * 1.0 / 4.5;
            let bottom_x = if c0.x - a.jaw_points[0].x < delta { a.jaw_points[0].x + delta } else { c0.x };
            let mut c1 = p3(bottom_x, -height_cm, c0.z + height_cm / (angle_deg * PI / 180.0).tan());
            if c1.z > 0.0 {
                c1.z = 0.0;
            }
            let c2 = p3(bottom_x, -height_cm, 0.0);
            curve.set_points(&[c0, c1, c2], Some(&w));
            for j in 0..NUM_LOWER_COVER_POINTS {
                let u = curve.uniform_param(j as f64 / (NUM_LOWER_COVER_POINTS - 1) as f64);
                let q = curve.point(u);
                self.surface[MANDIBLE].set(i, j, q);
            }
        }
        // The upper teeth.
        let (th, ttw, tbw, tp, tn) = Self::teeth_ribs(&a.palate_points, &a.upper_teeth_height_cm, &a.upper_teeth_width_top_cm, &a.upper_teeth_width_bottom_cm);
        for i in 0..NUM_TEETH_RIBS {
            let s = &mut self.surface[UPPER_TEETH];
            s.set(i, 0, tp[i]);
            s.set(i, 4, tp[i]);
            let mut q = tp[i] + tn[i] * (ttw[i] - tbw[i]);
            q.y = -th[i];
            s.set(i, 1, q);
            let mut q = tp[i] + tn[i] * ttw[i];
            q.y = -th[i];
            s.set(i, 2, q);
            q.y = 0.0;
            s.set(i, 3, q);
        }
        for i in 0..NUM_JAW_RIBS {
            self.upper_gums_inner_edge[i] = a.palate_points[i];
            self.upper_gums_outer_edge[i] = a.palate_points[i] + a.upper_teeth_width_top_cm[i] * tn[3 * i];
        }
        // The lower teeth.
        let (th, ttw, tbw, tp, tn) = Self::teeth_ribs(&a.jaw_points, &a.lower_teeth_height_cm, &a.lower_teeth_width_top_cm, &a.lower_teeth_width_bottom_cm);
        for i in 0..NUM_TEETH_RIBS {
            let s = &mut self.surface[LOWER_TEETH_ORIGINAL];
            s.set(i, 0, tp[i]);
            s.set(i, 4, tp[i]);
            let mut q = tp[i] + tn[i] * (tbw[i] - ttw[i]);
            q.y = th[i];
            s.set(i, 1, q);
            let mut q = tp[i] + tn[i] * tbw[i];
            q.y = th[i];
            s.set(i, 2, q);
            q.y = 0.0;
            s.set(i, 3, q);
        }
        for i in 0..NUM_JAW_RIBS {
            self.lower_gums_inner_edge_orig[i] = a.jaw_points[i];
            self.lower_gums_outer_edge_orig[i] = a.jaw_points[i] + a.lower_teeth_width_bottom_cm[i] * tn[3 * i];
        }
        // The lines the mouth's corner moves along: the outer teeth edge from the second premolar to the canine's gap,
        // then 1 cm in front of the upper incisors.
        let mut wide = Vec::new();
        let mut narrow = Vec::new();
        for i in 4..=6 {
            let mut q = self.upper_gums_outer_edge[i];
            q.y = 0.0;
            wide.push(q);
            narrow.push(q);
        }
        let palate_length = a.palate_points[8].x - a.palate_points[0].x;
        let palate_depth = -2.0 * a.palate_points[0].z;
        let lip_protrusion = 1.0 * palate_length / 4.5;
        let lip_front_min_z = -1.0 * palate_depth / 4.6;
        let lip_front_max_z = -0.4 * palate_depth / 4.6;
        let max_lip_corner_x = self.upper_gums_outer_edge[8].x + lip_protrusion;
        wide.push(p3(max_lip_corner_x, 0.0, lip_front_min_z));
        narrow.push(p3(max_lip_corner_x, 0.0, lip_front_max_z));
        self.wide_lip_corner_path = LineStrip3D::from_points(&wide);
        self.narrow_lip_corner_path = LineStrip3D::from_points(&narrow);
    }

    fn init_velum(&mut self) {
        let w = [1.0, 1.0, 1.0];
        let a = self.anatomy.clone();
        let source_z = -0.5 * a.pharynx_upper_depth_cm;
        let mut t = a.palate_angle_deg[0];
        if t <= 0.00001 {
            t = 0.00001;
        }
        if t > 89.99999 {
            t = 89.99999;
        }
        let target_z = a.palate_points[0].z + a.palate_height_cm[1] / (t * PI / 180.0).tan();
        let posterior = p3(self.pharynx_back_x(a.pharynx_top_rib_y_cm) + a.pharynx_back_width_cm, a.pharynx_top_rib_y_cm, -0.5 * a.pharynx_upper_depth_cm);
        let anterior = p3(0.0, 0.0, a.palate_points[0].z);
        let mut curve = BezierCurve3D::new();
        for i in 0..NUM_VELUM_RIBS {
            let c0 = if i == 0 {
                posterior
            } else {
                let t = (i - 1) as f64 / (NUM_VELUM_RIBS - 2) as f64;
                (1.0 - t) * posterior + t * anterior
            };
            let t = i as f64 / (NUM_VELUM_RIBS - 1) as f64;
            for (state, pts) in [(LOW_VELUM, a.velum_low_points), (MID_VELUM, a.velum_mid_points), (HIGH_VELUM, a.velum_high_points)] {
                let mut c2 = if i == 0 { p3(self.pharynx_back_x(pts[0].y), pts[0].y, 0.0) } else { pts[i - 1].to_p3() };
                c2.z = 0.0;
                let c1 = p3(c2.x, c2.y, (1.0 - t) * source_z + t * target_z);
                curve.set_points(&[c0, c1, c2], Some(&w));
                for j in 0..NUM_UPPER_COVER_POINTS {
                    let mut u = j as f64 / (NUM_UPPER_COVER_POINTS - 1) as f64;
                    u = curve.uniform_param(u);
                    let q = curve.point(u);
                    self.surface[state].set(i, j, q);
                }
            }
        }
        let (width, height, depth) = (a.uvula_width_cm, a.uvula_height_cm, a.uvula_depth_cm);
        let s = &mut self.surface[UVULA_ORIGINAL];
        for i in 0..NUM_UVULA_POINTS {
            let t = PI * i as f64 / (NUM_UVULA_POINTS - 1) as f64;
            let mut p = p3(0.5 * width * t.cos() - 0.5 * width, 0.0, -0.5 * depth * t.sin());
            s.set(0, i, p);
            p.y = -0.5 * height;
            s.set(1, i, p);
        }
        for i in 0..NUM_UVULA_POINTS {
            let t = PI * i as f64 / (NUM_UVULA_POINTS - 1) as f64;
            s.set(2, i, p3(0.75 * 0.5 * width * t.cos() - 0.5 * width, -0.75 * height, -0.75 * 0.5 * depth * t.sin()));
        }
        for i in 0..NUM_UVULA_POINTS {
            s.set(3, i, p3(-0.5 * width, -height, 0.0));
        }
    }

    /// The x of the pharynx's back wall at height y. (The C++'s getPharynxBackX: an angle above zero, in degrees, has
    /// 2 pi subtracted -- as if in radians; no speaker file's angle is positive.)
    pub fn pharynx_back_x(&self, y: f64) -> f64 {
        const MIN_ANGLE_DEG: f64 = -135.0;
        const MAX_ANGLE_DEG: f64 = -45.0;
        let a = self.anatomy.pharynx_fulcrum;
        let mut angle_deg = self.anatomy.pharynx_rotation_angle_deg;
        if angle_deg > 0.0 {
            angle_deg -= if self.mended { 360.0 } else { 2.0 * PI };
        }
        angle_deg = angle_deg.clamp(MIN_ANGLE_DEG, MAX_ANGLE_DEG);
        let angle_rad = angle_deg * PI / 180.0;
        a.x + (y - a.y) * angle_rad.cos() / angle_rad.sin()
    }

    pub(crate) fn restrict_param(&mut self, i: usize) {
        let p = &mut self.param[i];
        if p.x < p.min {
            p.x = p.min;
        }
        if p.x > p.max {
            p.x = p.max;
        }
    }

    /// The whole geometry for these parameters (VocalTract::calculateAll): surfaces, center line, cross-sections, tube.
    pub fn calculate(&mut self, params: &[f64]) {
        for (p, &x) in self.param.iter_mut().zip(params) {
            p.x = x;
        }
        self.calculate_all();
    }

    pub fn calculate_all(&mut self) {
        for i in 0..NUM_PARAMS {
            self.restrict_param(i);
            self.param[i].limited_x = self.param[i].x;
        }
        self.calc_surfaces();
        self.calc_center_line();
        self.calc_cross_sections();
        self.cross_sections_to_tube_sections();
    }

    fn calc_surfaces(&mut self) {
        let a = self.anatomy.clone();
        let shear_coeff = (a.pharynx_rotation_angle_deg * PI / 180.0).cos() / (a.pharynx_rotation_angle_deg * PI / 180.0).sin();
        self.intersections_prepared = [false; NUM_SURFACES];
        for i in 0..NUM_PARAMS {
            self.restrict_param(i);
        }
        // HY no higher than the most posterior jaw rib's lowest point; the hyoid not right of that rib (limit HX).
        let angle_rad = self.param[JA].x * PI / 180.0;
        let (cosinus, sinus) = (angle_rad.cos(), angle_rad.sin());
        let jx = self.param[JX].x;
        let vertex = rotate_jaw(&a, jx, cosinus, sinus, self.surface[MANDIBLE].get(0, NUM_LOWER_COVER_POINTS - 1));
        if self.param[HY].x > vertex.y {
            self.param[HY].limited_x = vertex.y;
        }
        let p = self.surface[NARROW_LARYNX_FRONT].get(NUM_LARYNX_RIBS - 1, NUM_LOWER_COVER_POINTS - 1);
        let q = self.surface[WIDE_LARYNX_FRONT].get(NUM_LARYNX_RIBS - 1, NUM_LOWER_COVER_POINTS - 1);
        let x_offset = self.pharynx_back_x(self.param[HY].limited_x);
        let mut t = q.x - p.x;
        if t.abs() < 0.000001 {
            t = 0.000001;
        }
        let max_hx = (vertex.x - x_offset - p.x) / t;
        if self.param[HX].x > max_hx {
            self.param[HX].limited_x = max_hx;
        }
        let hx = &mut self.param[HX];
        if hx.limited_x < hx.min {
            hx.limited_x = hx.min;
        }
        if hx.limited_x > hx.max {
            hx.limited_x = hx.max;
        }
        let hy = self.param[HY].limited_x;
        // The upper cover: the larynx's back (sheared to the oblique pharynx wall), the pharynx's back, the velum, the
        // hard palate.
        let mut rib = 0;
        let t = self.param[HX].limited_x;
        let x = self.pharynx_back_x(hy);
        for i in 0..NUM_LARYNX_RIBS {
            for k in 0..NUM_UPPER_COVER_POINTS {
                let p = self.surface[NARROW_LARYNX_BACK].get(i, k);
                let q = self.surface[WIDE_LARYNX_BACK].get(i, k);
                let mut p = p * (1.0 - t) + q * t;
                let shear_x = p.y * shear_coeff;
                p.x += x + shear_x;
                p.y += hy;
                self.surface[UPPER_COVER].set(rib, k, p);
            }
            rib += 1;
        }
        const PHARYNX_X_CM: [f64; NUM_UPPER_COVER_POINTS] = [1.0, 0.69, 0.41, 0.19, 0.05, 0.0];
        const PHARYNX_Z_CM: [f64; NUM_UPPER_COVER_POINTS] = [-1.0, -0.95, -0.81, -0.59, -0.31, 0.0];
        for i in 0..NUM_PHARYNX_RIBS {
            let t = i as f64 / (NUM_PHARYNX_RIBS - 1) as f64;
            let scale_z = 0.5 * ((1.0 - t) * a.pharynx_lower_depth_cm + t * a.pharynx_upper_depth_cm);
            let scale_x = a.pharynx_back_width_cm;
            let t = (i + 1) as f64 / NUM_PHARYNX_RIBS as f64;
            let y = (1.0 - t) * hy + t * a.pharynx_top_rib_y_cm;
            let x = self.pharynx_back_x(y);
            for k in 0..NUM_UPPER_COVER_POINTS {
                self.surface[UPPER_COVER].set(rib, k, p3(x + scale_x * PHARYNX_X_CM[k], y, scale_z * PHARYNX_Z_CM[k]));
            }
            rib += 1;
        }
        let s = (self.param[VS].x - self.param[VS].min) / (self.param[VS].max - self.param[VS].min);
        let t = self.param[VO].x.clamp(0.0, 1.0);
        for i in 0..NUM_VELUM_RIBS {
            for k in 0..NUM_UPPER_COVER_POINTS {
                let p = self.surface[HIGH_VELUM].get(i, k);
                let q = self.surface[MID_VELUM].get(i, k);
                let r = self.surface[LOW_VELUM].get(i, k);
                let mut v = (1.0 - s) * p + s * q;
                v = (1.0 - t) * v + t * r;
                self.surface[UPPER_COVER].set(rib, k, v);
            }
            rib += 1;
        }
        let last_velum_rib = rib - 1;
        for i in 0..NUM_JAW_RIBS {
            // (The posterior hard palate's heights drawn toward the most anterior velum rib, up to 1.2 cm.)
            let factor = a.palate_points[i].x / 1.2;
            for k in 0..NUM_UPPER_COVER_POINTS {
                let q = self.surface[PALATE].get(i, k);
                let v = if factor < 1.0 {
                    let p = self.surface[UPPER_COVER].get(last_velum_rib, k);
                    p3(q.x, (1.0 - factor) * p.y + factor * q.y, if q.x < 0.01 { p.z } else { q.z })
                } else {
                    q
                };
                self.surface[UPPER_COVER].set(rib, k, v);
            }
            rib += 1;
        }
        // The lower cover: the larynx's front, the throat, the mandible.
        rib = 0;
        let t = self.param[HX].limited_x;
        let x = self.pharynx_back_x(hy);
        for i in 0..NUM_LARYNX_RIBS {
            for k in 0..NUM_LOWER_COVER_POINTS {
                let p = self.surface[NARROW_LARYNX_FRONT].get(i, k);
                let q = self.surface[WIDE_LARYNX_FRONT].get(i, k);
                let mut p = p * (1.0 - t) + q * t;
                let shear_x = p.y * shear_coeff;
                p.x += x + shear_x;
                p.y += hy;
                self.surface[LOWER_COVER].set(rib, k, p);
            }
            rib += 1;
        }
        rib += NUM_THROAT_RIBS;
        for i in 0..NUM_JAW_RIBS {
            for k in 0..NUM_LOWER_COVER_POINTS {
                let v = rotate_jaw(&a, jx, cosinus, sinus, self.surface[MANDIBLE].get(i, k));
                self.surface[LOWER_COVER].set(rib, k, v);
            }
            rib += 1;
            self.lower_gums_outer_edge[i] = rotate_jaw(&a, jx, cosinus, sinus, self.lower_gums_outer_edge_orig[i]);
            self.lower_gums_inner_edge[i] = rotate_jaw(&a, jx, cosinus, sinus, self.lower_gums_inner_edge_orig[i]);
        }
        let weight = [1.0, 0.71, 1.0];
        let r = self.surface[LOWER_COVER].get(NUM_LARYNX_RIBS - 1, NUM_LOWER_COVER_POINTS - 1);
        let mut curve = BezierCurve3D::new();
        for i in 0..NUM_THROAT_RIBS {
            let q = self.surface[UPPER_COVER].get(NUM_LARYNX_RIBS + i, 0);
            curve.set_points(&[q, p3(r.x, r.y, q.z), r], Some(&weight));
            for k in 0..NUM_LOWER_COVER_POINTS {
                let q = curve.point(k as f64 / (NUM_LOWER_COVER_POINTS - 1) as f64);
                self.surface[LOWER_COVER].set(NUM_LARYNX_RIBS + i, k, q);
            }
        }
        for i in 0..NUM_TEETH_RIBS {
            for k in 0..NUM_TEETH_POINTS {
                let v = rotate_jaw(&a, jx, cosinus, sinus, self.surface[LOWER_TEETH_ORIGINAL].get(i, k));
                self.surface[LOWER_TEETH].set(i, k, v);
            }
        }
        self.calc_lips();
        // The fill between the upper and lower teeth.
        let uc = |s: &Self, rib: usize| s.surface[UPPER_COVER].get(rib, 0);
        let lc = |s: &Self, rib: usize| s.surface[LOWER_COVER].get(rib, 0);
        let fills = [
            (0, uc(self, NUM_LARYNX_RIBS + NUM_PHARYNX_RIBS), lc(self, NUM_LARYNX_RIBS + NUM_PHARYNX_RIBS - 1)),
            (1, uc(self, NUM_LARYNX_RIBS + NUM_PHARYNX_RIBS + NUM_VELUM_RIBS - 1), lc(self, NUM_LARYNX_RIBS + NUM_PHARYNX_RIBS)),
            (2, uc(self, NUM_LARYNX_RIBS + NUM_PHARYNX_RIBS + NUM_VELUM_RIBS), lc(self, NUM_LARYNX_RIBS + NUM_PHARYNX_RIBS)),
        ];
        for (rib, up, low) in fills {
            let s = &mut self.surface[LEFT_COVER];
            s.set(rib, 0, up);
            s.set(rib, 1, up);
            s.set(rib, 2, low);
            s.set(rib, 3, low);
        }
        let z_lip = [self.surface[UPPER_LIP].get(0, 0).z, self.surface[LOWER_LIP].get(0, 0).z];
        // (These two carry from one rib, and from the upper gums to the lower, as in the C++.)
        let mut inner_point = P3::default();
        let mut outer_point = P3::default();
        for k in 0..2 {
            let (inner, outer) = if k == 0 { (self.upper_gums_inner_edge, self.upper_gums_outer_edge) } else { (self.lower_gums_inner_edge, self.lower_gums_outer_edge) };
            for i in 0..NUM_JAW_RIBS - 1 {
                let p = inner[i];
                let q = inner[i + 1];
                let length = q.z - p.z;
                if p.z <= z_lip[k] {
                    inner_point = inner[i];
                    outer_point = outer[i];
                }
                if p.z <= z_lip[k] && q.z >= z_lip[k] && length > 0.0 {
                    let t = (z_lip[k] - p.z) / length;
                    inner_point = inner[i] + t * (inner[i + 1] - inner[i]);
                    outer_point = outer[i] + t * (outer[i + 1] - outer[i]);
                }
                let s = &mut self.surface[LEFT_COVER];
                if k == 0 {
                    s.set(3 + i, 0, inner_point);
                    s.set(3 + i, 1, outer_point);
                } else {
                    s.set(3 + i, 2, outer_point);
                    s.set(3 + i, 3, inner_point);
                }
            }
            let s = &mut self.surface[LEFT_COVER];
            if k == 0 {
                s.set(NUM_FILL_RIBS - 1, 0, inner_point);
                s.set(NUM_FILL_RIBS - 1, 1, outer_point);
            } else {
                s.set(NUM_FILL_RIBS - 1, 2, outer_point);
                s.set(NUM_FILL_RIBS - 1, 3, inner_point);
            }
        }
        // The upper and lower covers' midsagittal contours.
        let teeth_rib = NUM_TEETH_RIBS - 1;
        let lip_rib = NUM_LIP_RIBS - 1;
        let mut up: Vec<P2> = (0..NUM_UPPER_COVER_RIBS).map(|i| self.surface[UPPER_COVER].get(i, NUM_UPPER_COVER_POINTS - 1).to_p2()).collect();
        up.extend((0..NUM_TEETH_POINTS - 1).map(|i| self.surface[UPPER_TEETH].get(teeth_rib, i).to_p2()));
        up.extend((0..NUM_INNER_LIP_POINTS + 2).map(|i| self.surface[UPPER_LIP].get(lip_rib, i).to_p2()));
        while up[up.len() - 1].x <= up[up.len() - 2].x {
            up.pop();
        }
        self.upper_outline.set_points(&up);
        let mut low: Vec<P2> = (0..NUM_LOWER_COVER_RIBS).map(|i| self.surface[LOWER_COVER].get(i, NUM_LOWER_COVER_POINTS - 1).to_p2()).collect();
        low.extend((0..NUM_TEETH_POINTS - 1).map(|i| self.surface[LOWER_TEETH].get(teeth_rib, i).to_p2()));
        low.extend((0..NUM_INNER_LIP_POINTS + 2).map(|i| self.surface[LOWER_LIP].get(lip_rib, i).to_p2()));
        while low[low.len() - 1].x <= low[low.len() - 2].x {
            low.pop();
        }
        self.lower_outline.set_points(&low);
        self.calc_tongue();
        // The epiglottis, after the tongue.
        let p = self.surface[LOWER_COVER].get(NUM_LARYNX_RIBS - 2, NUM_LOWER_COVER_POINTS - 1);
        let q = self.surface[LOWER_COVER].get(NUM_LARYNX_RIBS - 1, NUM_LOWER_COVER_POINTS - 1);
        let mut v = q - p;
        v.normalize();
        let anchor = p + a.epiglottis_width_cm * v;
        for k in 0..NUM_EPIGLOTTIS_POINTS {
            let p = self.surface[EPIGLOTTIS_ORIGINAL].get(0, k);
            let (x, y) = (v.x * p.x - v.y * p.y, v.y * p.x + v.x * p.y);
            self.surface[EPIGLOTTIS].set(0, k, p3(x + anchor.x, y + anchor.y, p.z + anchor.z));
        }
        let mut min_angle_rad = a.epiglottis_angle_deg * PI / 180.0;
        for i in 1..10 {
            let mut p = self.surface[TONGUE].get(i, NUM_TONGUE_POINTS / 2) - anchor;
            if p.y < a.epiglottis_height_cm {
                if p.y < 0.01 {
                    p.y = 0.01;
                }
                let angle_rad = p.y.atan2(p.x);
                if angle_rad > min_angle_rad {
                    min_angle_rad = angle_rad;
                }
            }
        }
        min_angle_rad -= 0.5 * PI;
        if min_angle_rad > 0.25 * PI {
            min_angle_rad = 0.25 * PI;
        }
        let (sinus, cosinus) = (min_angle_rad.sin(), min_angle_rad.cos());
        for i in 1..NUM_EPIGLOTTIS_RIBS {
            for k in 0..NUM_EPIGLOTTIS_POINTS {
                let p = self.surface[EPIGLOTTIS_ORIGINAL].get(i, k);
                let (x, y) = (cosinus * p.x - sinus * p.y, sinus * p.x + cosinus * p.y);
                self.surface[EPIGLOTTIS].set(i, k, p3(x + anchor.x, y + anchor.y, p.z + anchor.z));
            }
        }
        // The uvula, after the tongue.
        let anchor = self.surface[UPPER_COVER].get(NUM_LARYNX_RIBS + NUM_PHARYNX_RIBS + 1, NUM_UPPER_COVER_POINTS - 1);
        for i in 0..NUM_UVULA_RIBS {
            for k in 0..NUM_UVULA_POINTS {
                let mut p = self.surface[UVULA_ORIGINAL].get(i, k);
                p += anchor;
                self.surface[UVULA].set(i, k, p);
            }
        }
        let tongue_point = NUM_TONGUE_POINTS / 4;
        let tongue: Vec<P2> = (0..NUM_TONGUE_RIBS).map(|i| self.surface[TONGUE].get(i, tongue_point).to_p2()).collect();
        self.tongue_outline.set_points(&tongue);
        let mut epi: Vec<P2> = (0..NUM_EPIGLOTTIS_RIBS).map(|i| self.surface[EPIGLOTTIS].get(i, NUM_EPIGLOTTIS_POINTS - 1).to_p2()).collect();
        epi.extend((0..NUM_EPIGLOTTIS_RIBS - 1).rev().map(|i| self.surface[EPIGLOTTIS].get(i, 0).to_p2()));
        self.epiglottis_outline.set_points(&epi);
    }

    fn important_lip_points(&mut self) -> (P3, P3, P3, P3, f64) {
        let a = &self.anatomy;
        let n = self.narrow_lip_corner_path.num_points();
        let angle_rad = 0.5 * self.param[JA].x * PI / 180.0;
        let (cosinus, sinus) = (angle_rad.cos(), angle_rad.sin());
        let t = (self.param[LD].x - self.param[LD].min) / (self.param[LD].max - self.param[LD].min);
        let mut pts = Vec::with_capacity(n);
        for i in 0..n {
            let q = (1.0 - t) * self.narrow_lip_corner_path.control_point(i) + t * self.wide_lip_corner_path.control_point(i);
            let dx = q.x + a.jaw_rest_pos.x + 0.5 * self.param[JX].x - a.jaw_fulcrum.x;
            let dy = q.y + 0.5 * a.jaw_rest_pos.y - a.jaw_fulcrum.y;
            pts.push(p3(cosinus * dx - sinus * dy + a.jaw_fulcrum.x, sinus * dx + cosinus * dy + a.jaw_fulcrum.y, q.z));
        }
        self.lip_corner_path = LineStrip3D::from_points(&pts);
        let mut separation_x = self.upper_gums_outer_edge[6].x;
        if self.lower_gums_outer_edge[6].x < separation_x {
            separation_x = self.lower_gums_outer_edge[6].x;
        }
        let t0 = self.narrow_lip_corner_path.plane_intersection(p3(separation_x, 0.0, 0.0), p3(1.0, 0.0, 0.0));
        let t = (self.param[LP].x - self.param[LP].min) / (self.param[LP].max - self.param[LP].min);
        let corner = self.lip_corner_path.point(t);
        let onset = if t > t0 { self.lip_corner_path.point(t0) } else { corner };
        let t0p = self.upper_gums_outer_edge[8];
        let t1p = self.lower_gums_outer_edge[8];
        const X_OFFSET: f64 = 0.1;
        let y_offset = 0.35 - t * 0.3;
        const L_MAX: f64 = 1.0;
        const L_MIN: f64 = 0.3;
        let t = (self.param[LP].x - self.param[LP].min) / (self.param[LP].max - self.param[LP].min);
        let l = (1.0 - t) * L_MAX + t * L_MIN;
        let mut f0 = p3(corner.x + l + 0.3, 0.0, 0.0);
        let mut f1 = p3(corner.x + l, 0.0, 0.0);
        if f0.x < t0p.x + X_OFFSET {
            f0.x = t0p.x + X_OFFSET;
        }
        if f1.x < t1p.x + X_OFFSET {
            f1.x = t1p.x + X_OFFSET;
        }
        const MIN_T: f64 = -0.05;
        let t = (self.param[LP].x - self.param[LP].min) / (self.param[LP].max - self.param[LP].min);
        let y_close = 0.5 * (t0p.y + t1p.y) + (1.0 - t) * y_offset;
        let mut t = 0.5 * self.param[LD].x;
        if t < MIN_T {
            t = MIN_T;
        }
        f0.y = y_close + t;
        f1.y = y_close - t;
        if f0.y > t0p.y {
            f0.y = t0p.y;
        }
        if f1.y > t0p.y {
            f1.y = t0p.y;
        }
        if f0.y < t1p.y {
            f0.y = t1p.y;
        }
        if f1.y < t1p.y {
            f1.y = t1p.y;
        }
        let lip_tangent = self.upper_gums_outer_edge[5] - self.upper_gums_outer_edge[0];
        f0.z = corner.z + (lip_tangent.z / lip_tangent.x) * (f0.x - corner.x);
        f1.z = corner.z + (lip_tangent.z / lip_tangent.x) * (f1.x - corner.x);
        (onset, corner, f0, f1, y_close)
    }

    // One lip's ribs' origins along its gums, the fixed ones and those inserted between them (calcLips).
    fn lip_origins(outer_edge: &[P3; NUM_JAW_RIBS], inner_edge: &[P3; NUM_JAW_RIBS], onset: P3, corner: P3) -> ([P3; NUM_LIP_RIBS], [P3; NUM_LIP_RIBS], usize) {
        const EPSILON: f64 = 0.000001;
        // (Room for every rib the C++ could make: its arrays hold NUM_LIP_RIBS, which a jaw this wide never passes.)
        let mut outer = [P3::default(); NUM_LIP_RIBS + 3];
        let mut inner = [P3::default(); NUM_LIP_RIBS + 3];
        let mut num_ribs = 0;
        for i in 1..NUM_JAW_RIBS {
            let (p0, p1) = (outer_edge[i - 1], outer_edge[i]);
            let mut length = p1.x - p0.x;
            if length < EPSILON {
                length = EPSILON;
            }
            let (q0, q1) = (inner_edge[i - 1], inner_edge[i]);
            if p0.x <= onset.x && p1.x >= onset.x {
                let t = (onset.x - p0.x) / length;
                outer[num_ribs] = p0 + t * (p1 - p0);
                inner[num_ribs] = q0 + t * (q1 - q0);
                num_ribs += 1;
            }
            if p0.x <= corner.x && p1.x >= corner.x {
                let t = (corner.x - p0.x) / length;
                outer[num_ribs] = p0 + t * (p1 - p0);
                inner[num_ribs] = q0 + t * (q1 - q0);
                num_ribs += 1;
            }
            if p1.x > onset.x {
                outer[num_ribs] = p1;
                inner[num_ribs] = q1;
                num_ribs += 1;
            }
        }
        let num_fixed = num_ribs;
        let mut divisions = [1usize; NUM_LIP_RIBS + 3];
        while num_ribs < NUM_LIP_RIBS {
            let mut k = 0;
            let mut max_length = -1000000.0;
            for i in 0..num_fixed - 1 {
                let length = (outer[i + 1].z - outer[i].z) / divisions[i] as f64;
                if length > max_length {
                    max_length = length;
                    k = i;
                }
            }
            divisions[k] += 1;
            num_ribs += 1;
        }
        let mut to = [P3::default(); NUM_LIP_RIBS];
        let mut ti = [P3::default(); NUM_LIP_RIBS];
        let mut n = 0;
        for i in 0..num_fixed {
            if i < num_fixed - 1 {
                let (p0, p1, q0, q1) = (outer[i], outer[i + 1], inner[i], inner[i + 1]);
                for k in 0..divisions[i] {
                    let t = k as f64 / divisions[i] as f64;
                    to[n] = p0 + (p1 - p0) * t;
                    ti[n] = q0 + (q1 - q0) * t;
                    n += 1;
                }
            } else {
                to[n] = outer[i];
                ti[n] = inner[i];
                n += 1;
            }
        }
        (to, ti, n)
    }

    fn calc_lips(&mut self) {
        const EPSILON: f64 = 0.000001;
        let mut lip_radius = self.anatomy.lips_width_cm - 0.4;
        if lip_radius < 0.4 {
            lip_radius = 0.4;
        }
        let (onset, corner, f0, f1, _y_close) = self.important_lip_points();
        let mut upper_path = Vec::new();
        let mut lower_path = Vec::new();
        let n = self.lip_corner_path.num_points();
        for i in 0..n - 1 {
            let p0 = self.lip_corner_path.control_point(i);
            let p1 = self.lip_corner_path.control_point(i + 1);
            if p0.x <= onset.x && p1.x >= onset.x {
                upper_path.push(onset);
                lower_path.push(onset);
            }
            if p0.x > onset.x && p0.x < corner.x {
                upper_path.push(p0);
                lower_path.push(p0);
            }
            if p0.x <= corner.x && p1.x >= corner.x {
                upper_path.push(corner);
                lower_path.push(corner);
            }
        }
        let _ = EPSILON;
        let mut curve = BezierCurve3D::new();
        let weight = [1.0, 1.5, 1.0];
        curve.set_points(&[corner, f0, p3(f0.x, f0.y, 0.0)], Some(&weight));
        for i in 1..=7 {
            upper_path.push(curve.point(i as f64 / 7.0));
        }
        curve.set_points(&[corner, f1, p3(f1.x, f1.y, 0.0)], Some(&weight));
        for i in 1..=7 {
            lower_path.push(curve.point(i as f64 / 7.0));
        }
        let upper_path = LineStrip3D::from_points(&upper_path);
        let lower_path = LineStrip3D::from_points(&lower_path);
        for (lip, path, outer_edge, inner_edge, upper) in [
            (UPPER_LIP, upper_path, self.upper_gums_outer_edge, self.upper_gums_inner_edge, true),
            (LOWER_LIP, lower_path, self.lower_gums_outer_edge, self.lower_gums_inner_edge, false),
        ] {
            let mut path = path;
            let (outer, inner, num_ribs) = Self::lip_origins(&outer_edge, &inner_edge, onset, corner);
            let max_x = path.point(1.0).x;
            for i in 0..num_ribs {
                let p0 = outer[i];
                let t = i as f64 / (num_ribs - 1) as f64;
                let p1 = path.point(t);
                // The inner lip points.
                let t = 0.7;
                let mut q = p1;
                q.y = p0.y;
                q = (1.0 - t) * q + t * p1;
                let t = 0.0;
                let mut r = p0;
                r.y = p1.y;
                r = (1.0 - t) * r + t * p1;
                let mut t = (p0.x - outer[0].x) / (outer[NUM_LIP_RIBS - 1].x - outer[0].x);
                t = t * t * t;
                let c1 = (1.0 - t) * q + t * r;
                curve.set_points(&[p0, c1, p1], Some(&[1.0, 2.0, 1.0]));
                self.surface[lip].set(i, 0, inner[i]);
                for k in 0..NUM_INNER_LIP_POINTS - 1 {
                    let t = k as f64 / (NUM_INNER_LIP_POINTS - 2) as f64;
                    let v = curve.point(t);
                    self.surface[lip].set(i, k + 1, v);
                }
                // The outer lip points.
                let mut q = p1;
                let mut radius = lip_radius * (q.x - corner.x) / (max_x - corner.x);
                if radius < 0.0 {
                    radius = 0.0;
                }
                if upper {
                    q.y += radius;
                } else {
                    q.y -= radius;
                }
                for k in 0..NUM_OUTER_LIP_POINTS {
                    let t = if upper {
                        -0.5 * PI + 0.5 * PI * (k + 1) as f64 / NUM_OUTER_LIP_POINTS as f64
                    } else {
                        0.5 * PI - 0.5 * PI * (k + 1) as f64 / NUM_OUTER_LIP_POINTS as f64
                    };
                    self.surface[lip].set(i, NUM_INNER_LIP_POINTS + k, p3(q.x + radius * t.cos(), q.y + radius * t.sin(), q.z));
                }
            }
        }
        self.calc_radiation(corner);
    }

    fn calc_radiation(&mut self, lip_corner: P3) {
        let lip_point = NUM_INNER_LIP_POINTS;
        let mut h = 0.0;
        let mut x = [0.0; NUM_RADIATION_POINTS];
        let mut y = [0.0; NUM_RADIATION_POINTS];
        let mut min_z = 0.0;
        for i in 0..NUM_RADIATION_POINTS {
            let angle_rad = -0.5 * PI + PI * i as f64 / (NUM_RADIATION_POINTS - 1) as f64;
            x[i] = angle_rad.cos();
            y[i] = 0.5 * angle_rad.sin() + 0.5;
        }
        let (mut v, mut l) = (P3::default(), P3::default());
        let mut n: P3;
        for i in 0..NUM_RADIATION_RIBS {
            if i < NUM_LIP_RIBS {
                n = p3(0.0, 0.0, -1.0);
                let u = self.surface[UPPER_LIP].get(i, lip_point);
                l = self.surface[LOWER_LIP].get(i, lip_point);
                let m = 0.5 * (u + l);
                v = u - l;
                h = u.y - l.y;
                if h <= 0.0 {
                    h = 0.0;
                }
                if u.x <= lip_corner.x {
                    h = 0.0;
                } else {
                    let mut new_z = m.z - h;
                    if new_z > min_z {
                        new_z = min_z;
                    } else {
                        min_z = new_z;
                    }
                    let _ = new_z;
                    h = m.z - min_z;
                }
            } else {
                // (The last lip rib's L, v and h kept.)
                let angle_rad = 0.5 * PI - 0.5 * PI * (i - NUM_LIP_RIBS + 1) as f64 / (NUM_RADIATION_RIBS - NUM_LIP_RIBS) as f64;
                n = p3(angle_rad.cos(), 0.0, -angle_rad.sin());
            }
            for k in 0..NUM_RADIATION_POINTS {
                self.surface[RADIATION].set(i, k, l + y[k] * v + x[k] * h * n);
            }
        }
    }

    /// The tongue body's tangent through the hyoid (getHyoidTongueTangent): (the hyoid, the touching point).
    pub fn hyoid_tongue_tangent(&self) -> (P2, P2) {
        let c = p2(self.param[TCX].limited_x, self.param[TCY].limited_x);
        let (rx, ry) = (self.anatomy.tongue_center_radius_x_cm, self.anatomy.tongue_center_radius_y_cm);
        let h = self.surface[LOWER_COVER].get(NUM_LARYNX_RIBS - 1, NUM_LOWER_COVER_POINTS - 1).to_p2();
        let alpha = ellipse_tangent(h, c, rx, ry, true);
        (h, p2(c.x + rx * alpha.cos(), c.y + ry * alpha.sin()))
    }
}
