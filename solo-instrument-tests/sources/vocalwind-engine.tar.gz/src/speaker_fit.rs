// A speaker's shapes found from frames VocalTractLab's rules made of them (the speech2vocaltract corpus; the owner, 14
// November 2026, of the design in research/VOCALWIND_LANGUAGES.md: "Yes, proceed, and you have permission to do the
// speaker-recovery"). Each sentence's segments are made a gestural score by this port's 2.3 rules (segments.rs), the
// score's frames read (gestural.rs) and compared with the frames given, and every shape the scores read is moved by least
// squares (Levenberg-Marquardt) until they agree. The Jacobian is taken through the same code: one parameter of one shape
// moved, the score's targets made again, and the curves of the parameters whose targets changed read again. A score's
// timing -- its closing and velic gestures, placed by the tract's geometry -- is held while the shapes are solved, then
// made again from the shapes found and the solve repeated. Computed on the engine itself: nothing but the port's rules
// and curves. The tongue's sides (TS1-3) are in no frame: they are held.
use crate::gestural::{param_frames, GesturalScore, Reads, Target, LIP, TONGUE_BODY, TONGUE_TIP, VELIC, VOWEL};
use crate::segments::{Extra, Segment};
use crate::tract::VocalTract;

/// A sentence: its segments and the frames given for it (each the kept parameters).
pub struct Item {
    pub segments: Vec<Segment>,
    pub frames: Vec<Vec<f64>>,
}

/// A sentence's score, held while the shapes are solved, and the unknowns it reads.
pub struct Made {
    pub score: GesturalScore,
    pub reads: Reads,
    pub unknowns: Vec<usize>,
}

/// The shapes a score's targets read: its vowels' (schwa's, where a vowel gesture names none), and for its consonants
/// their (a), (i) and (u) prototypes and the /a/, /i/ and /u/ that place each vowel between them.
pub fn shapes_read(score: &GesturalScore) -> Vec<String> {
    let mut out: Vec<String> = vec!["@".into()];
    out.extend(score.seq[VOWEL].gestures.iter().filter(|g| !g.s_val.is_empty()).map(|g| g.s_val.clone()));
    let mut consonants = false;
    for tier in [LIP, TONGUE_TIP, TONGUE_BODY] {
        for g in score.seq[tier].gestures.iter().filter(|g| !g.neutral && !g.s_val.is_empty()) {
            consonants = true;
            out.extend(["a", "i", "u"].map(|c| format!("{}({c})", g.s_val)));
        }
    }
    if consonants {
        out.extend(["a", "i", "u"].map(String::from));
    }
    out.sort();
    out.dedup();
    out
}

/// The shape a score begins on, where its first frame is that shape exactly: the score's first vowel gesture begins it
/// and no consonant's or velic gesture is under way yet. (VocalTractLab's curves begin at their first target.)
pub fn first_shape(score: &GesturalScore) -> Option<&str> {
    let v = score.seq[VOWEL].gestures.first()?;
    if v.neutral || v.s_val.is_empty() {
        return None;
    }
    for tier in [LIP, TONGUE_TIP, TONGUE_BODY, VELIC] {
        if score.seq[tier].gestures.first().is_some_and(|g| !g.neutral) {
            return None;
        }
    }
    Some(&v.s_val)
}

/// A shape read from the first frames of the sentences that begin on it: its kept parameters, the sentences, and the
/// largest difference between them (none, where they are the shape).
pub struct FirstFrames {
    pub name: String,
    pub params: Vec<f64>,
    pub sentences: usize,
    pub spread: f64,
}

/// Every shape some sentence begins on, from its sentences' first frames.
pub fn first_frames(items: &[Item], made: &[Made]) -> Vec<FirstFrames> {
    let mut out: Vec<FirstFrames> = Vec::new();
    for (item, m) in items.iter().zip(made) {
        let (Some(name), Some(frame)) = (first_shape(&m.score), item.frames.first()) else { continue };
        match out.iter_mut().find(|f| f.name == name) {
            Some(f) => {
                f.sentences += 1;
                f.spread = f.params.iter().zip(frame).map(|(a, b)| (a - b).abs()).fold(f.spread, f64::max);
            }
            None => out.push(FirstFrames { name: name.to_string(), params: frame.clone(), sentences: 1, spread: 0.0 }),
        }
    }
    out.sort_by(|a, b| a.name.cmp(&b.name));
    out
}

/// What a pass over the sentences adds up.
#[derive(Clone, Debug, Default)]
pub struct Totals {
    /// The sum of the squared residuals, and the number of them.
    pub cost: f64,
    pub residuals: usize,
    /// Sentences whose frames are not as many as the given.
    pub counts_differ: usize,
}

pub struct Fit {
    /// The parameters compared and fitted (indices among VocalTractLab's), in the order of the given frames.
    pub kept: Vec<usize>,
    /// Every how many of the score's frames the given ones are.
    pub every: usize,
    /// The shapes fitted, by name; each must be among the tract's shapes.
    pub unknowns: Vec<String>,
    pub threads: usize,
    /// The finite difference's step, in the parameters' units.
    pub step: f64,
}

/// The items split among the threads, each thread with its own copy of the tract.
fn split<T: Send, F>(threads: usize, n: usize, vt: &VocalTract, work: F) -> Vec<T>
where
    F: Fn(&mut VocalTract, std::ops::Range<usize>) -> T + Sync,
{
    let threads = threads.max(1).min(n.max(1));
    let chunk = n.div_ceil(threads);
    std::thread::scope(|scope| {
        let handles: Vec<_> = (0..threads)
            .map(|t| {
                let work = &work;
                let mut own = vt.clone();
                scope.spawn(move || work(&mut own, t * chunk..((t + 1) * chunk).min(n)))
            })
            .collect();
        handles.into_iter().map(|h| h.join().expect("a worker failed")).collect()
    })
}

impl Fit {
    fn n(&self) -> usize {
        self.unknowns.len() * self.kept.len()
    }

    fn shape_slot(&self, vt: &VocalTract, u: usize) -> usize {
        vt.shapes.iter().position(|(n, _)| *n == self.unknowns[u]).unwrap_or_else(|| panic!("no shape {} in the tract", self.unknowns[u]))
    }

    /// Each sentence's score made from the tract's shapes as they are.
    pub fn make(&self, items: &[Item], vt: &VocalTract, extra: &Extra) -> Vec<Made> {
        split(self.threads, items.len(), vt, |own, range| {
            items[range]
                .iter()
                .map(|item| {
                    let mut score = GesturalScore::new();
                    score.from_segments_with(&item.segments, own, extra);
                    let read = shapes_read(&score);
                    let unknowns = (0..self.unknowns.len()).filter(|&u| read.contains(&self.unknowns[u])).collect();
                    let reads = score.reads(self.every);
                    Made { score, reads, unknowns }
                })
                .collect::<Vec<_>>()
        })
        .into_iter()
        .flatten()
        .collect()
    }

    /// Each kept parameter's frames, from the targets.
    fn frames_of(&self, targets: &[Vec<Target>], vt: &VocalTract, reads: &Reads) -> Vec<Vec<f64>> {
        self.kept
            .iter()
            .map(|&k| {
                let mut out = vec![0.0; reads.at.len()];
                param_frames(&mut targets[k].clone(), vt.param[k].neutral, reads, &mut out);
                out
            })
            .collect()
    }

    /// The residuals of one sentence, given less made, frame by frame (each frame's kept parameters); and whether as
    /// many frames were made as given.
    pub fn residuals(&self, item: &Item, made: &Made, vt: &VocalTract) -> (Vec<f64>, bool) {
        let f0 = self.frames_of(&made.score.targets(vt), vt, &made.reads);
        let nf = f0[0].len().min(item.frames.len());
        let mut r = Vec::with_capacity(nf * self.kept.len());
        for f in 0..nf {
            for j in 0..self.kept.len() {
                r.push(item.frames[f][j] - f0[j][f]);
            }
        }
        (r, f0[0].len() == item.frames.len())
    }

    pub fn totals(&self, items: &[Item], made: &[Made], vt: &VocalTract) -> Totals {
        split(self.threads, items.len(), vt, |own, range| {
            let mut t = Totals::default();
            for i in range {
                let (r, same) = self.residuals(&items[i], &made[i], own);
                t.cost += r.iter().map(|x| x * x).sum::<f64>();
                t.residuals += r.len();
                t.counts_differ += !same as usize;
            }
            t
        })
        .into_iter()
        .fold(Totals::default(), |a, b| Totals { cost: a.cost + b.cost, residuals: a.residuals + b.residuals, counts_differ: a.counts_differ + b.counts_differ })
    }

    /// The normal equations J'J and J'r over the sentences (J the made frames' derivatives by the unknowns), with the
    /// cost, and how many frames each unknown shape moves.
    pub fn normal(&self, items: &[Item], made: &[Made], vt: &VocalTract) -> (Vec<f64>, Vec<f64>, Totals, Vec<usize>) {
        let n = self.n();
        let kn = self.kept.len();
        let parts = split(self.threads, items.len(), vt, |own, range| {
            let mut a = vec![0.0; n * n];
            let mut g = vec![0.0; n];
            let mut t = Totals::default();
            let mut moved = vec![0usize; self.unknowns.len()];
            for i in range {
                let (item, m) = (&items[i], &made[i]);
                let targets0 = m.score.targets(own);
                let f0 = self.frames_of(&targets0, own, &m.reads);
                let nf = f0[0].len().min(item.frames.len());
                let rows = nf * kn;
                let mut r = vec![0.0; rows];
                for f in 0..nf {
                    for j in 0..kn {
                        r[f * kn + j] = item.frames[f][j] - f0[j][f];
                    }
                }
                t.cost += r.iter().map(|x| x * x).sum::<f64>();
                t.residuals += rows;
                t.counts_differ += (f0[0].len() != item.frames.len()) as usize;
                // Each row's entries: (column, derivative).
                let mut by_row: Vec<Vec<(usize, f64)>> = vec![Vec::new(); rows];
                for &u in &m.unknowns {
                    let slot = self.shape_slot(own, u);
                    let mut frames_moved = vec![false; nf];
                    for (j, &k) in self.kept.iter().enumerate() {
                        let column = u * kn + j;
                        let was = own.shapes[slot].1[k];
                        own.shapes[slot].1[k] = was + self.step;
                        let targets1 = m.score.targets(own);
                        own.shapes[slot].1[k] = was;
                        for (j2, &k2) in self.kept.iter().enumerate() {
                            if targets1[k2] == targets0[k2] {
                                continue;
                            }
                            let mut f1 = vec![0.0; m.reads.at.len()];
                            param_frames(&mut targets1[k2].clone(), own.param[k2].neutral, &m.reads, &mut f1);
                            for f in 0..nf {
                                let d = (f1[f] - f0[j2][f]) / self.step;
                                if d != 0.0 {
                                    by_row[f * kn + j2].push((column, d));
                                    frames_moved[f] = true;
                                }
                            }
                        }
                    }
                    moved[u] += frames_moved.iter().filter(|&&x| x).count();
                }
                for (row, entries) in by_row.iter().enumerate() {
                    for &(c1, d1) in entries {
                        g[c1] += d1 * r[row];
                        for &(c2, d2) in entries {
                            a[c1 * n + c2] += d1 * d2;
                        }
                    }
                }
            }
            (a, g, t, moved)
        });
        let mut a = vec![0.0; n * n];
        let mut g = vec![0.0; n];
        let mut t = Totals::default();
        let mut moved = vec![0usize; self.unknowns.len()];
        for (pa, pg, pt, pm) in parts {
            a.iter_mut().zip(&pa).for_each(|(x, y)| *x += y);
            g.iter_mut().zip(&pg).for_each(|(x, y)| *x += y);
            t.cost += pt.cost;
            t.residuals += pt.residuals;
            t.counts_differ += pt.counts_differ;
            moved.iter_mut().zip(&pm).for_each(|(x, y)| *x += y);
        }
        (a, g, t, moved)
    }

    /// The step (J'J + lambda diag(J'J)) d = J'r, by Cholesky; an unknown no frame moves stays where it is.
    pub fn solve(&self, a: &[f64], g: &[f64], lambda: f64) -> Option<Vec<f64>> {
        let n = self.n();
        let mut m = a.to_vec();
        let largest = (0..n).map(|i| a[i * n + i]).fold(0.0, f64::max);
        for i in 0..n {
            m[i * n + i] += lambda * a[i * n + i] + 1e-12 * largest.max(1e-300);
        }
        cholesky_solve(&mut m, g, n)
    }

    /// The unknowns moved by a step.
    pub fn apply(&self, vt: &mut VocalTract, d: &[f64]) {
        for u in 0..self.unknowns.len() {
            let slot = self.shape_slot(vt, u);
            for (j, &k) in self.kept.iter().enumerate() {
                vt.shapes[slot].1[k] += d[u * self.kept.len() + j];
            }
        }
    }

    /// The scores made, the shapes solved with them held, and again, `outer` times or until the scores no longer change;
    /// each solve at most `inner` steps. Before the scores are made each time, `prepare` sets what the shapes take from
    /// one another (a shape's parameters no frame holds). Returns the totals at the end and how many frames each unknown
    /// moves.
    pub fn run(&self, items: &[Item], vt: &mut VocalTract, extra: &Extra, outer: usize, inner: usize, mut prepare: impl FnMut(&mut VocalTract), mut log: impl FnMut(&str)) -> (Totals, Vec<usize>) {
        let mut moved = vec![0; self.unknowns.len()];
        let mut previous: Option<Vec<GesturalScore>> = None;
        for o in 0..outer {
            prepare(vt);
            let made = self.make(items, vt, extra);
            let scores: Vec<GesturalScore> = made.iter().map(|m| m.score.clone()).collect();
            if let Some(p) = &previous {
                let changed = p.iter().zip(&scores).filter(|(a, b)| a.seq.iter().zip(&b.seq).any(|(x, y)| x.gestures != y.gestures)).count();
                log(&format!("scores made again: {changed} of {} changed", scores.len()));
                if changed == 0 {
                    break;
                }
            }
            previous = Some(scores);
            let mut lambda = 1e-6;
            for it in 0..inner {
                let (a, g, t, m) = self.normal(items, &made, vt);
                moved = m;
                log(&format!("pass {o}, step {it}: rms {:.3e} over {} residuals, {} sentences' frames not as many as given", (t.cost / t.residuals.max(1) as f64).sqrt(), t.residuals, t.counts_differ));
                let mut accepted = false;
                while lambda < 1e8 {
                    let Some(d) = self.solve(&a, &g, lambda) else {
                        lambda *= 10.0;
                        continue;
                    };
                    let mut trial = vt.clone();
                    self.apply(&mut trial, &d);
                    let t1 = self.totals(items, &made, &trial);
                    if t1.cost < t.cost {
                        *vt = trial;
                        lambda = (lambda / 10.0).max(1e-9);
                        accepted = t1.cost < t.cost * (1.0 - 1e-6);
                        break;
                    }
                    lambda *= 10.0;
                }
                if !accepted {
                    break;
                }
            }
        }
        prepare(vt);
        let made = self.make(items, vt, extra);
        (self.totals(items, &made, vt), moved)
    }
}

/// a x = b for a symmetric positive definite a (n by n, row major; overwritten by its factor).
pub(crate) fn cholesky_solve(a: &mut [f64], b: &[f64], n: usize) -> Option<Vec<f64>> {
    for j in 0..n {
        let mut d = a[j * n + j];
        for k in 0..j {
            d -= a[j * n + k] * a[j * n + k];
        }
        if d <= 0.0 || !d.is_finite() {
            return None;
        }
        let d = d.sqrt();
        a[j * n + j] = d;
        for i in j + 1..n {
            let mut s = a[i * n + j];
            for k in 0..j {
                s -= a[i * n + k] * a[j * n + k];
            }
            a[i * n + j] = s / d;
        }
    }
    let mut y = b.to_vec();
    for i in 0..n {
        for k in 0..i {
            y[i] -= a[i * n + k] * y[k];
        }
        y[i] /= a[i * n + i];
    }
    for i in (0..n).rev() {
        for k in i + 1..n {
            y[i] -= a[k * n + i] * y[k];
        }
        y[i] /= a[i * n + i];
    }
    Some(y)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn cholesky_solves() {
        let mut a = vec![4.0, 2.0, 0.6, 2.0, 5.0, 1.0, 0.6, 1.0, 3.0];
        let x = cholesky_solve(&mut a, &[1.0, 2.0, 3.0], 3).unwrap();
        let a = [4.0, 2.0, 0.6, 2.0, 5.0, 1.0, 0.6, 1.0, 3.0];
        for i in 0..3 {
            let s: f64 = (0..3).map(|k| a[i * 3 + k] * x[k]).sum();
            assert!((s - [1.0, 2.0, 3.0][i]).abs() < 1e-12);
        }
        assert!(cholesky_solve(&mut vec![1.0, 2.0, 2.0, 1.0], &[1.0, 1.0], 2).is_none());
    }
}
