// VocalTractLab in Rust (docs/VOCAL_TRACT.md): the articulatory synthesizer of Peter Birkholz (TU Dresden), its backend
// ported part for part and held to it sample for sample (test/audio/vocaltract.test.mjs).
//   constants, rng, iir  -- its constants, its noise's generator as libc++ draws it, its recursive filters
//   counters             -- what work costs, counted by the processor: instructions and cycles a thread ran, by core
//   tube                 -- the branched tube: trachea, glottis, pharynx and mouth, nose and sinuses, piriform fossae
//   glottis              -- the geometric glottis: the folds' motion at F0 into the glottis's two sections
//   tds                  -- the tube's acoustics in the time domain, each sample
//   synth                -- frames interpolated into samples: the glottis and the tube together, the radiated sound
//   xml, speaker         -- speaker files
//   geometry, splines, surface -- points, lines, curves, triangle meshes cut by planes
//   tract, tongue, sections    -- the vocal tract's geometry: surfaces, tongue, center line, cross-sections, tube
//   live                 -- the geometry made ahead on other cores, the tube stepped on one: real time
//   stream               -- the voice played live: its controls approached frame by frame, its samples made as asked
//   yin                  -- VocalTractLab 2.4's F0 estimator: YIN's candidates and the cheapest path through them
//   v24                  -- VocalTractLab 2.4, beside 2.3 (the rest): what it changed, ported and held to it
//   sing                 -- notes at any pitch, vowels and pressures into frames: the tract sung
//   gestural             -- the gestural score: gestures on eight tiers into targets, curves and frames
//   inventory, rules     -- the phones every language shares (languages/phones.json: each by its IPA, its kind, its
//                           place and manner, its shapes and its own numbers) and the rules' numbers (rules-2.3.json,
//                           rules-2.4.json)
//   segments             -- phones (German SAMPA) and their durations into a gestural score, by VocalTractLab's rules
//   phones               -- IPA into that SAMPA, and the pause 2.4's rules begin a sequence with
//   npy, speech2vocaltract -- NumPy's arrays read; the speech2vocaltract corpus (English, Korean, Brazilian Portuguese:
//                           phones and the tract's parameters VocalTractLab made of them), described by languages/
//   speaker_fit          -- a speaker's shapes found from the frames VocalTractLab's rules made of them
//   carry                -- a 2.3 speaker's shape carried to a 2.4 speaker by its area function
//   blend                -- a singer's body weighed from any number of speakers' files (voices/speakers.json)
//   vowel_space          -- every IPA vowel at its place on the chart, a speaker's shape there from its own vowels
//                           (languages/vowel-space.json)
//   espeak, ssml         -- (feature espeak) SSML read aloud: eSpeak NG's phones and timing, the score and its prosody
//   f0_targets           -- a read contour's F0 targets: those whose approach on the engine passes nearest it
//   fitting              -- the voice's fits: the tract's acoustics on its network in frequency against printed and
//                           living tracts, its free parameters' ranges, a bounded search, one scoreboard (vtl-fit)
/// This crate's own folder, where it reads its configuration as it runs (voices/, acoustics/, languages/): the one it
/// was built in. In a browser its files are handed to it under a folder of this name (wasm32: public/studio/engines/
/// vocalwind-wasi.js), so that no path of the machine that built it is written into what a page fetches.
#[cfg(not(target_arch = "wasm32"))]
pub fn home() -> &'static str {
    env!("CARGO_MANIFEST_DIR")
}
#[cfg(target_arch = "wasm32")]
pub fn home() -> &'static str {
    "/vocaltract"
}

pub mod blend;
pub mod carry;
pub mod constants;
pub mod counters;
#[cfg(feature = "espeak")]
pub mod espeak;
pub mod f0_targets;
pub mod fitting;
pub mod fold_law;
pub mod geometry;
pub mod gestural;
pub mod glottis;
pub mod iir;
pub mod inventory;
pub mod live;
pub mod npy;
pub mod phones;
pub mod rng;
pub mod rules;
pub mod segments;
pub mod sections;
pub mod sing;
pub mod singers;
pub mod speaker;
pub mod speaker_fit;
pub mod speech2vocaltract;
pub mod stream;
pub mod splines;
#[cfg(feature = "espeak")]
pub mod ssml;
pub mod surface;
pub mod synth;
pub mod tds;
pub mod tongue;
pub mod tract;
pub mod tube;
pub mod v24;
pub mod vowel_space;
pub mod xml;
pub mod yin;
