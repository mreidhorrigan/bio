// VocalTractLab's plane and solid geometry (Geometry.cpp): points, vectors (a point and a direction), lines, circles and
// ellipses, each expression in its order. As in the C++, normalize, turn_right and turn_left change the point they are
// called on and return it.
use crate::constants::PI;
use std::ops::{Add, AddAssign, Div, Mul, Neg, Sub, SubAssign};

#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct P2 {
    pub x: f64,
    pub y: f64,
}

#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct P3 {
    pub x: f64,
    pub y: f64,
    pub z: f64,
}

pub const fn p2(x: f64, y: f64) -> P2 {
    P2 { x, y }
}
pub const fn p3(x: f64, y: f64, z: f64) -> P3 {
    P3 { x, y, z }
}

impl Add for P2 {
    type Output = P2;
    fn add(self, q: P2) -> P2 {
        p2(self.x + q.x, self.y + q.y)
    }
}
impl Sub for P2 {
    type Output = P2;
    fn sub(self, q: P2) -> P2 {
        p2(self.x - q.x, self.y - q.y)
    }
}
impl Mul<f64> for P2 {
    type Output = P2;
    fn mul(self, d: f64) -> P2 {
        p2(self.x * d, self.y * d)
    }
}
impl Mul<P2> for f64 {
    type Output = P2;
    fn mul(self, p: P2) -> P2 {
        p2(p.x * self, p.y * self)
    }
}
impl Div<f64> for P2 {
    type Output = P2;
    fn div(self, d: f64) -> P2 {
        p2(self.x / d, self.y / d)
    }
}
impl Neg for P2 {
    type Output = P2;
    fn neg(self) -> P2 {
        p2(-self.x, -self.y)
    }
}
impl AddAssign for P2 {
    fn add_assign(&mut self, q: P2) {
        self.x += q.x;
        self.y += q.y;
    }
}
impl SubAssign for P2 {
    fn sub_assign(&mut self, q: P2) {
        self.x -= q.x;
        self.y -= q.y;
    }
}
impl Add for P3 {
    type Output = P3;
    fn add(self, q: P3) -> P3 {
        p3(self.x + q.x, self.y + q.y, self.z + q.z)
    }
}
impl Sub for P3 {
    type Output = P3;
    fn sub(self, q: P3) -> P3 {
        p3(self.x - q.x, self.y - q.y, self.z - q.z)
    }
}
impl Mul<f64> for P3 {
    type Output = P3;
    fn mul(self, d: f64) -> P3 {
        p3(self.x * d, self.y * d, self.z * d)
    }
}
impl Mul<P3> for f64 {
    type Output = P3;
    fn mul(self, p: P3) -> P3 {
        p3(p.x * self, p.y * self, p.z * self)
    }
}
impl Div<f64> for P3 {
    type Output = P3;
    fn div(self, d: f64) -> P3 {
        p3(self.x / d, self.y / d, self.z / d)
    }
}
impl Neg for P3 {
    type Output = P3;
    fn neg(self) -> P3 {
        p3(-self.x, -self.y, -self.z)
    }
}
impl AddAssign for P3 {
    fn add_assign(&mut self, q: P3) {
        self.x += q.x;
        self.y += q.y;
        self.z += q.z;
    }
}

impl P2 {
    pub fn set(&mut self, x: f64, y: f64) {
        self.x = x;
        self.y = y;
    }
    pub fn is_right_from(&self, v: &V2) -> bool {
        (v.v.x * (v.p.y - self.y) - v.v.y * (v.p.x - self.x)) >= 0.0
    }
    pub fn is_left_from(&self, v: &V2) -> bool {
        (v.v.x * (v.p.y - self.y) - v.v.y * (v.p.x - self.x)) <= 0.0
    }
    pub fn to_p3(&self) -> P3 {
        p3(self.x, self.y, 0.0)
    }
    /// The line from the anchor a to this point leaned onto the line of vec, keeping its length.
    pub fn lean_on(&mut self, vec: V2, a: P2) {
        let w = vec.p - a;
        let v = vec.v;
        let r = p2(self.x - a.x, self.y - a.y);
        let c = r.x * r.x + r.y * r.y;
        let denominator = v.x * v.x + v.y * v.y;
        let p = 2.0 * (v.x * w.x + v.y * w.y) / denominator;
        let q = (w.x * w.x + w.y * w.y - c) / denominator;
        let radicant = 0.25 * p * p - q;
        if radicant >= 0.0 {
            let root = radicant.sqrt();
            let s0 = vec.p + v * (-0.5 * p + root);
            let s1 = vec.p + v * (-0.5 * p - root);
            let (t0, t1) = (s0 - a, s1 - a);
            if t0.x * r.x + t0.y * r.y > t1.x * r.x + t1.y * r.y {
                self.x = s0.x;
                self.y = s0.y;
            } else {
                self.x = s1.x;
                self.y = s1.y;
            }
        }
    }
    pub fn normalize(&mut self) -> P2 {
        let l = (self.x * self.x + self.y * self.y).sqrt();
        if l != 0.0 {
            self.x /= l;
            self.y /= l;
        }
        *self
    }
    pub fn turn_right(&mut self) -> P2 {
        let temp = self.x;
        self.x = self.y;
        self.y = -temp;
        *self
    }
    pub fn turn_left(&mut self) -> P2 {
        let temp = self.x;
        self.x = -self.y;
        self.y = temp;
        *self
    }
    pub fn turn(&mut self, angle: f64) {
        let s = angle.sin();
        let c = angle.cos();
        let nx = self.x * c - self.y * s;
        let ny = self.y * c + self.x * s;
        self.x = nx;
        self.y = ny;
    }
    /// Distance from the line of vec, negative to its left.
    pub fn distance_from(&self, vec: V2) -> f64 {
        let w = p2(vec.p.x - self.x, vec.p.y - self.y);
        let v = vec.v;
        let mut denominator = v.x * v.x + v.y * v.y;
        if denominator == 0.0 {
            denominator = 0.0001;
        }
        (v.x * w.y - v.y * w.x) / denominator
    }
    pub fn magnitude(&self) -> f64 {
        (self.x * self.x + self.y * self.y).sqrt()
    }
    pub fn square_magnitude(&self) -> f64 {
        self.x * self.x + self.y * self.y
    }
}

pub fn dot2(p: P2, q: P2) -> f64 {
    p.x * q.x + p.y * q.y
}

impl P3 {
    pub fn set(&mut self, x: f64, y: f64, z: f64) {
        self.x = x;
        self.y = y;
        self.z = z;
    }
    pub fn is_right_from(&self, v: &V2) -> bool {
        (v.v.x * (v.p.y - self.y) - v.v.y * (v.p.x - self.x)) >= 0.0
    }
    pub fn to_p2(&self) -> P2 {
        p2(self.x, self.y)
    }
    pub fn normalize(&mut self) -> P3 {
        let l = (self.x * self.x + self.y * self.y + self.z * self.z).sqrt();
        if l != 0.0 {
            self.x /= l;
            self.y /= l;
            self.z /= l;
        }
        *self
    }
    pub fn magnitude(&self) -> f64 {
        (self.x * self.x + self.y * self.y + self.z * self.z).sqrt()
    }
}

pub fn dot3(p: P3, q: P3) -> f64 {
    p.x * q.x + p.y * q.y + p.z * q.z
}
pub fn cross(p: P3, q: P3) -> P3 {
    p3(p.y * q.z - p.z * q.y, p.z * q.x - p.x * q.z, p.x * q.y - p.y * q.x)
}

/// A point and a direction.
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct V2 {
    pub p: P2,
    pub v: P2,
}

pub const fn v2(p: P2, v: P2) -> V2 {
    V2 { p, v }
}

impl V2 {
    /// Where it meets the line of other: (the point, t along this).
    pub fn intersect_v(&self, other: V2) -> (P2, f64) {
        let b = other.p;
        let w = other.v;
        let v = self.v;
        let mut denominator = v.x * w.y - v.y * w.x;
        if denominator == 0.0 {
            denominator = 0.0001;
        }
        let t = (w.x * (self.p.y - b.y) - w.y * (self.p.x - b.x)) / denominator;
        (self.point(t), t)
    }
    /// Where it meets the segment l: (the point, t along this, whether it does).
    pub fn intersect_line(&self, l: L2) -> (P2, f64, bool) {
        let b = l.p[0];
        let w = l.p[1] - l.p[0];
        let v = self.v;
        let mut denominator = v.x * w.y - v.y * w.x;
        if denominator == 0.0 {
            denominator = 0.0001;
        }
        let m = (v.x * (self.p.y - b.y) - v.y * (self.p.x - b.x)) / denominator;
        if m < -0.01 || m > 1.01 || l.p[0] == l.p[1] {
            return (self.p, 0.0, false);
        }
        let t = (w.x * (self.p.y - b.y) - w.y * (self.p.x - b.x)) / denominator;
        (self.point(t), t, true)
    }
    /// Where the 3D segment l meets the plane through this vector and the z-axis: (the point, t along this, whether).
    pub fn intersect_line3(&self, l: L3) -> (P3, f64, bool) {
        let b = l.p[0];
        let w = l.p[1] - l.p[0];
        let v = self.v;
        let mut denominator = v.x * w.y - v.y * w.x;
        if denominator == 0.0 {
            denominator = 0.0001;
        }
        let m = (v.x * (self.p.y - b.y) - v.y * (self.p.x - b.x)) / denominator;
        if m < -0.01 || m > 1.01 || (w.x == 0.0 && w.y == 0.0) {
            return (p3(self.p.x, self.p.y, 0.0), 0.0, false);
        }
        let t = (w.x * (self.p.y - b.y) - w.y * (self.p.x - b.x)) / denominator;
        (l.point(m), t, true)
    }
    pub fn normalize(&mut self) {
        let mut argument = self.v.x * self.v.x + self.v.y * self.v.y;
        if argument != 1.0 && argument != 0.0 {
            argument = argument.sqrt();
            self.v.x /= argument;
            self.v.y /= argument;
        }
    }
    pub fn point(&self, t: f64) -> P2 {
        self.p + self.v * t
    }
    pub fn length(&self, t: f64) -> f64 {
        (self.v.x * self.v.x + self.v.y * self.v.y).sqrt() * t
    }
    pub fn is_not_null(&self) -> bool {
        self.v.x != 0.0 || self.v.y != 0.0
    }
}

#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct L2 {
    pub p: [P2; 2],
}

pub const fn l2(a: P2, b: P2) -> L2 {
    L2 { p: [a, b] }
}

impl L2 {
    pub fn intersect_v(&self, vec: V2) -> (P2, f64, bool) {
        let a = self.p[0];
        let v = self.p[1] - self.p[0];
        let b = vec.p;
        let w = vec.v;
        let orig_den = v.x * w.y - v.y * w.x;
        let mut denominator = orig_den;
        if denominator == 0.0 {
            denominator = 0.0001;
        }
        let t = (w.x * (a.y - b.y) - w.y * (a.x - b.x)) / denominator;
        let ok = t > -0.01 && t < 1.01 && orig_den != 0.0;
        (self.point(t), t, ok)
    }
    pub fn intersect_line(&self, l: L2) -> (P2, f64, bool) {
        let a = self.p[0];
        let v = self.p[1] - self.p[0];
        let b = l.p[0];
        let w = l.p[1] - l.p[0];
        let orig_den = v.x * w.y - v.y * w.x;
        let mut denominator = orig_den;
        if denominator == 0.0 {
            denominator = 0.0001;
        }
        let t = (w.x * (a.y - b.y) - w.y * (a.x - b.x)) / denominator;
        let m = (v.x * (a.y - b.y) - v.y * (a.x - b.x)) / denominator;
        let ok = t > -0.01 && t < 1.01 && m > -0.01 && m < 1.01 && orig_den != 0.0;
        (self.point(t), t, ok)
    }
    pub fn point(&self, t: f64) -> P2 {
        self.p[0] + (self.p[1] - self.p[0]) * t
    }
    pub fn length(&self) -> f64 {
        ((self.p[1].x - self.p[0].x) * (self.p[1].x - self.p[0].x) + (self.p[1].y - self.p[0].y) * (self.p[1].y - self.p[0].y)).sqrt()
    }
    pub fn encloses(&self, q: P2) -> bool {
        let (left, right) = if self.p[0].x < self.p[1].x { (self.p[0].x, self.p[1].x) } else { (self.p[1].x, self.p[0].x) };
        let (bottom, top) = if self.p[0].y < self.p[1].y { (self.p[0].y, self.p[1].y) } else { (self.p[1].y, self.p[0].y) };
        left - 0.01 < q.x && right + 0.01 > q.x && bottom - 0.01 < q.y && top + 0.01 > q.y
    }
}

#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct L3 {
    pub p: [P3; 2],
}

pub const fn l3(a: P3, b: P3) -> L3 {
    L3 { p: [a, b] }
}

impl L3 {
    pub fn intersect_v(&self, vec: V2) -> (P3, f64, bool) {
        let l = l2(p2(self.p[0].x, self.p[0].y), p2(self.p[1].x, self.p[1].y));
        let (_, t, ok) = l.intersect_v(vec);
        (self.point(t), t, ok)
    }
    pub fn point(&self, t: f64) -> P3 {
        self.p[0] + (self.p[1] - self.p[0]) * t
    }
    pub fn length(&self) -> f64 {
        let d = self.p[1] - self.p[0];
        (d.x * d.x + d.y * d.y + d.z * d.z).sqrt()
    }
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Circle {
    pub m: P2,
    pub r: f64,
    pub arc_angle: [f64; 2],
}

impl Default for Circle {
    fn default() -> Self {
        Circle { m: p2(0.0, 0.0), r: 1.0, arc_angle: [0.0, 0.0] }
    }
}

fn wrap_angle(mut a: f64) -> f64 {
    while a < 0.0 {
        a += 2.0 * PI;
    }
    while a > 2.0 * PI {
        a -= 2.0 * PI;
    }
    a
}

impl Circle {
    pub fn new(c: P2, r: f64) -> Circle {
        Circle { m: c, r, arc_angle: [0.0, 0.0] }
    }
    pub fn set_valid_arc(&mut self, a0: f64, a1: f64) {
        self.arc_angle = [wrap_angle(a0), wrap_angle(a1)];
    }
    pub fn length(&self) -> f64 {
        self.length_between(self.arc_angle[0], self.arc_angle[1])
    }
    pub fn length_between(&self, a0: f64, a1: f64) -> f64 {
        let (a0, a1) = (wrap_angle(a0), wrap_angle(a1));
        if a0 == a1 {
            2.0 * PI * self.r
        } else if a1 > a0 {
            self.r * (a1 - a0)
        } else {
            (a1 + (2.0 * PI - a0)) * self.r
        }
    }
    pub fn point(&self, angle: f64) -> P2 {
        p2(self.m.x + self.r * angle.cos(), self.m.y + self.r * angle.sin())
    }
    pub fn normal(&self, angle: f64) -> V2 {
        let c = angle.cos();
        let s = angle.sin();
        v2(p2(self.m.x + self.r * c, self.m.y + self.r * s), p2(c, s))
    }
    fn in_arc(&self, angle: f64) -> bool {
        let a = self.arc_angle;
        if a[0] == a[1] {
            true
        } else if a[1] > a[0] {
            angle >= a[0] && angle <= a[1]
        } else {
            angle <= a[1] || angle >= a[0]
        }
    }
    fn crossings(&self, p: P2, v: P2) -> Option<([P2; 2], [f64; 2], [f64; 2])> {
        let m = self.m;
        let mut denominator = v.x * v.x + v.y * v.y;
        if denominator == 0.0 {
            denominator = 0.0001;
        }
        let pp = (2.0 * v.x * (p.x - m.x) + 2.0 * v.y * (p.y - m.y)) / denominator;
        let q = ((p.x - m.x) * (p.x - m.x) + (p.y - m.y) * (p.y - m.y) - self.r * self.r) / denominator;
        let radicant = 0.25 * pp * pp - q;
        if radicant < 0.0 {
            return None;
        }
        let root = radicant.sqrt();
        let n = [-0.5 * pp + root, -0.5 * pp - root];
        let s = [p + v * n[0], p + v * n[1]];
        let mut angle = [(s[0].y - m.y).atan2(s[0].x - m.x), (s[1].y - m.y).atan2(s[1].x - m.x)];
        for a in angle.iter_mut() {
            if *a < 0.0 {
                *a += 2.0 * PI;
            }
        }
        Some((s, angle, n))
    }
    fn choose(&self, p: P2, s: [P2; 2], angle: [f64; 2], ok: [bool; 2]) -> (P2, f64, bool) {
        if ok[0] && ok[1] {
            if (s[0].x - p.x) * (s[0].x - p.x) + (s[0].y - p.y) * (s[0].y - p.y) < (s[1].x - p.x) * (s[1].x - p.x) + (s[1].y - p.y) * (s[1].y - p.y) {
                (s[0], angle[0], true)
            } else {
                (s[1], angle[1], true)
            }
        } else if ok[0] {
            (s[0], angle[0], true)
        } else if ok[1] {
            (s[1], angle[1], true)
        } else {
            (p2(0.0, 0.0), 0.0, false)
        }
    }
    /// Where vec meets the valid arc: (the point, its angle, whether).
    pub fn intersect_v(&self, vec: V2) -> (P2, f64, bool) {
        match self.crossings(vec.p, vec.v) {
            None => (p2(0.0, 0.0), 0.0, false),
            Some((s, angle, _)) => self.choose(vec.p, s, angle, [self.in_arc(angle[0]), self.in_arc(angle[1])]),
        }
    }
    /// Where the segment l meets the valid arc: (the point, its angle, whether).
    pub fn intersect_line(&self, l: L2) -> (P2, f64, bool) {
        match self.crossings(l.p[0], l.p[1] - l.p[0]) {
            None => (p2(0.0, 0.0), 0.0, false),
            Some((s, angle, n)) => {
                let in_line = [n[0] >= -0.01 && n[0] <= 1.01, n[1] >= -0.01 && n[1] <= 1.01];
                self.choose(l.p[0], s, angle, [in_line[0] && self.in_arc(angle[0]), in_line[1] && self.in_arc(angle[1])])
            }
        }
    }
    pub fn tangent_contact_angle(&self, h: P2, clockwise: bool) -> f64 {
        circle_tangent(h, self.m, self.r, clockwise)
    }
    pub fn bend(&self) -> f64 {
        let mut a = self.r;
        if a <= 0.0 {
            a = 0.0001;
        }
        -1.0 / a
    }
    pub fn includes(&self, p: P2) -> bool {
        let w = p - self.m;
        w.x * w.x + w.y * w.y <= self.r * self.r
    }
    pub fn includes_line(&self, l: L2) -> bool {
        self.includes(l.p[0]) && self.includes(l.p[1])
    }
    pub fn has_intersection_with(&self, l: L2) -> bool {
        let w = l.p[0] - self.m;
        let mut v = l.p[1] - l.p[0];
        v.normalize();
        let length = l.length();
        let p = 2.0 * (w.x * v.x + w.y * v.y);
        let q = w.x * w.x + w.y * w.y - self.r * self.r;
        let mut root = 0.25 * p * p - q;
        if root <= 0.0 {
            return false;
        }
        root = root.sqrt();
        let t = [-0.5 * p + root, -0.5 * p - root];
        (t[0] >= 0.0 && t[0] <= length) || (t[1] >= 0.0 && t[1] <= length)
    }
    /// The common tangent left of the line from this centre to k's, between the touching points.
    pub fn common_left_tangent_with(&self, k: Circle) -> L2 {
        let mut l = l2(p2(0.0, 0.0), p2(1.0, 1.0));
        let mut length = (k.m - self.m).magnitude();
        if length == 0.0 {
            length = 0.0001;
        }
        let cos_angle = (self.r - k.r) / length;
        if cos_angle > -1.0 && cos_angle < 1.0 {
            let angle = cos_angle.acos();
            let mut w = k.m - self.m;
            w.turn(angle);
            w.normalize();
            l.p[0] = self.m + w * self.r;
            l.p[1] = k.m + w * k.r;
        }
        l
    }
}

/// The angle of the point on a circle where a tangent through h touches it.
pub fn circle_tangent(h: P2, c: P2, r: f64, clockwise: bool) -> f64 {
    let p = h.x - c.x;
    let q = h.y - c.y;
    let radikant = p * p + q * q - r * r;
    if radikant < 0.0 {
        return 0.0;
    }
    let mut n = radikant.sqrt();
    if clockwise {
        n = -n;
    }
    (p * n + q * r).atan2(p * r - q * n)
}

pub const NUM_ELLIPSE_PROPS: usize = 33;

#[derive(Clone, Copy, Debug)]
pub struct Ellipse {
    pub half_width: f64,
    pub half_height: f64,
    pub m: P2,
    prop_angle: [f64; NUM_ELLIPSE_PROPS],
    prop_position: [f64; NUM_ELLIPSE_PROPS],
    perimeter: f64,
}

impl Ellipse {
    pub fn new(m: P2, half_width: f64, half_height: f64) -> Ellipse {
        let mut e = Ellipse { half_width, half_height, m, prop_angle: [0.0; NUM_ELLIPSE_PROPS], prop_position: [0.0; NUM_ELLIPSE_PROPS], perimeter: 0.0 };
        let mut prop_p = [P2::default(); NUM_ELLIPSE_PROPS];
        for i in 0..NUM_ELLIPSE_PROPS {
            e.prop_angle[i] = 2.0 * PI * i as f64 / (NUM_ELLIPSE_PROPS - 1) as f64;
            prop_p[i] = e.point(e.prop_angle[i]);
        }
        e.prop_position[0] = 0.0;
        for i in 1..NUM_ELLIPSE_PROPS {
            e.prop_position[i] = e.prop_position[i - 1] + (prop_p[i] - prop_p[i - 1]).magnitude();
        }
        e.perimeter = e.prop_position[NUM_ELLIPSE_PROPS - 1];
        e
    }
    pub fn point(&self, angle: f64) -> P2 {
        p2(angle.cos() * self.half_width, angle.sin() * self.half_height)
    }
    pub fn angle(&self, t: f64) -> f64 {
        let mut u = t * self.perimeter;
        if u < 0.0 {
            u = 0.0;
        }
        if u > self.perimeter {
            u = self.perimeter;
        }
        let mut i = 0;
        while i < NUM_ELLIPSE_PROPS - 2 && u > self.prop_position[i + 1] {
            i += 1;
        }
        let mut a = self.prop_position[i + 1] - self.prop_position[i];
        if a == 0.0 {
            a = 0.0001;
        }
        self.prop_angle[i] + ((self.prop_angle[i + 1] - self.prop_angle[i]) * (u - self.prop_position[i])) / a
    }
    pub fn perimeter(&self) -> f64 {
        self.perimeter
    }
}

/// The angle of the point on an ellipse (centre c, half-axes a and b) where a tangent through h touches it.
pub fn ellipse_tangent(h: P2, c: P2, a: f64, b: f64, clockwise: bool) -> f64 {
    let r = c - h;
    let mut radikant = r.x * r.x * b * b - b * b * a * a + r.y * r.y * a * a;
    if radikant < 0.0 {
        radikant = 0.0;
    }
    let root = radikant.sqrt();
    let mut deno = r.x * r.x * b * b + r.y * r.y * a * a;
    const EPSILON: f64 = 0.000001;
    if deno.abs() < EPSILON {
        deno = EPSILON;
    }
    let alpha0 = (-b * (r.y * a * a + r.x * root) / deno).atan2(-a * (r.x * b * b - r.y * root) / deno);
    let alpha1 = (-b * (r.y * a * a - r.x * root) / deno).atan2(-a * (r.x * b * b + r.y * root) / deno);
    let cos = alpha0.cos();
    let sin = alpha0.sin();
    let v1 = c + p2(a * cos, b * sin) - h;
    let v2 = p2(-a * sin, b * cos);
    let test = v1.x * v2.x + v1.y * v2.y;
    if (test >= 0.0 && clockwise) || (test < 0.0 && !clockwise) {
        alpha1
    } else {
        alpha0
    }
}
