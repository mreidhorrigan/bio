// VocalTractLab 2.4's F0 estimator (F0EstimatorYin.cpp; its GUI's "Calculate F0"): the signal band-limited (a Chebyshev
// high-pass at 60 Hz of four poles cascaded with a low-pass at 1 kHz of two), every 2 ms YIN's normalized difference
// function over a 1/60 s window (de Cheveigne & Kawahara 2002, JASA 111(4), doi:10.1121/1.1458024), its dips the pitch
// candidates (each refined by a parabola) beside an unvoiced one, and the cheapest path through them all (each
// candidate's cost its dip, an octave's jump 2, a voicing change by the level's change), read every 10 ms. Each
// expression in the C++'s order; its rate a parameter, where VocalTractLab's is fixed at 48 kHz (its every constant made
// from it). A sample is read past either end of the signal by wrapping, as Signal::getValue reads it -- but an index of
// exactly minus its length, which the C++ makes its length (one past its end), made 0.
use crate::iir::IirFilter;

const MAX_PITCH_CANDIDATES: usize = 32;
const INTERNAL_TIME_STEP_S: f64 = 0.002;

#[derive(Clone)]
struct Frame {
    t0: Vec<f64>,
    y: Vec<f64>,
    lowest_path_cost: Vec<f64>,
    best_prev: Vec<i64>,
    rms: f64,
    // (getBestLocalT0Estimate's, which the path does not read: kept as the C++ keeps it.)
    #[allow(dead_code)]
    initial: i64,
    last: i64,
}

pub struct Yin {
    rate: f64,
    integration: usize,
    frame_length: usize,
    threshold: f64,
    time_step_s: f64,
    hann: Vec<f64>,
    filter: IirFilter,
    frames: Vec<Frame>,
}

impl Yin {
    pub fn new(rate: f64) -> Yin {
        let integration = (rate / 60.0) as usize;
        let frame_length = 2 * integration - 1;
        let mut hann = vec![0.0; frame_length];
        let mut window = (0.03 * rate) as usize;
        if window > frame_length {
            window = frame_length;
        }
        let offset = (frame_length - window) / 2;
        for i in 0..window {
            hann[offset + i] = 0.5 * (1.0 - (2.0 * std::f64::consts::PI * i as f64 / (window - 1) as f64).cos());
        }
        let mut filter = IirFilter::default();
        filter.create_chebyshev(1000.0 / rate, false, 2);
        let mut high = IirFilter::default();
        high.create_chebyshev(60.0 / rate, true, 4);
        filter.combine_with(&high, true);
        Yin { rate, integration, frame_length, threshold: 0.1, time_step_s: 0.01, hann, filter, frames: Vec::new() }
    }

    /// F0 (Hz, 0 where unvoiced) every 10 ms of `signal` (in 16-bit units, as VocalTractLab reads a file).
    pub fn f0(&mut self, signal: &[f64]) -> Vec<f64> {
        let n = signal.len();
        let mut filtered = vec![0.0; n];
        if n > 0 {
            self.filter.reset_buffers(signal[0]);
        }
        for i in 0..n {
            filtered[i] = self.filter.output_sample(signal[i]);
        }
        let num_frames = (n as f64 / (self.rate * INTERNAL_TIME_STEP_S)) as usize;
        let il = self.integration;
        let mut frame = vec![0.0; self.frame_length];
        let mut df = vec![0.0; il];
        let mut ndf = vec![0.0; il];
        self.frames = Vec::with_capacity(num_frames);
        let value = |pos: i64| -> f64 {
            if n == 0 {
                return 0.0;
            }
            filtered[pos.rem_euclid(n as i64) as usize]
        };
        for i in 0..num_frames {
            let center = (i as f64 * INTERNAL_TIME_STEP_S * self.rate) as i64;
            for k in 0..self.frame_length {
                frame[k] = value(center - il as i64 + k as i64);
            }
            // (The difference function, each lag's window centred on the frame, and its cumulative-mean normalization.)
            for tau in 0..il {
                let mut sum = 0.0;
                let start = (il - 1 - tau) / 2;
                for k in 0..il {
                    let d = frame[start + k] - frame[start + k + tau];
                    sum += d * d;
                }
                df[tau] = sum;
            }
            ndf[0] = 1.0;
            let mut sum = 0.0;
            for tau in 1..il {
                sum += df[tau];
                ndf[tau] = df[tau] * tau as f64 / sum;
            }
            self.frames.push(self.frame_data(&frame, &df, &ndf));
        }
        self.best_path();
        let count = (n as f64 / (self.rate * self.time_step_s)) as usize;
        (0..count).map(|i| self.final_f0(i as f64 * self.time_step_s)).collect()
    }

    fn frame_data(&self, signal: &[f64], df: &[f64], ndf: &[f64]) -> Frame {
        let min_tau = (self.rate / 800.0) as usize;
        const MIN_DELTA_Y: f64 = 0.1;
        let mut t0 = vec![0.0];
        // (Its first candidate unvoiced, its cost the best a voiced one can save.)
        let mut y = vec![1.0];
        let (mut max_pos, mut min_pos) = (0usize, 0usize);
        for i in 0..self.integration {
            if i > min_pos && min_pos > max_pos && ndf[max_pos] - ndf[min_pos] > MIN_DELTA_Y && ndf[i] - ndf[min_pos] > MIN_DELTA_Y && t0.len() < MAX_PITCH_CANDIDATES && min_pos > min_tau && ndf[min_pos] <= 1.0 {
                let (_, accurate_y) = self.parabola(ndf, min_pos);
                let (accurate_tau, _) = self.parabola(df, min_pos);
                t0.push(accurate_tau / self.rate);
                y.push(accurate_y);
                max_pos = i;
                min_pos = i;
            }
            if ndf[i] > ndf[max_pos] {
                max_pos = i;
                min_pos = i;
            }
            if ndf[i] < ndf[min_pos] {
                min_pos = i;
            }
        }
        let mut initial: i64 = -1;
        for i in 0..t0.len() {
            if y[i] <= self.threshold && (initial == -1 || t0[i] < t0[initial as usize]) {
                initial = i as i64;
            }
        }
        if initial == -1 && !t0.is_empty() {
            initial = 0;
            for i in 1..t0.len() {
                if y[i] < y[initial as usize] {
                    initial = i as i64;
                }
            }
        }
        let mut sum = 0.0;
        for i in 0..self.frame_length {
            let d = signal[i] * self.hann[i];
            sum += d * d;
        }
        sum /= self.frame_length as f64;
        let k = t0.len();
        Frame { t0, y, lowest_path_cost: vec![0.0; k], best_prev: vec![-1; k], rms: sum.sqrt(), initial, last: -1 }
    }

    fn parabola(&self, f: &[f64], raw: usize) -> (f64, f64) {
        const SEARCH_RANGE: i32 = 10;
        let (mut tau, mut y) = (raw as f64, f[raw]);
        let (mut counter, mut increment) = (0, 0i64);
        let mut pos = raw as i64;
        let mut ok = false;
        while !ok && counter < SEARCH_RANGE {
            pos += increment;
            if pos > 0 && pos < self.integration as i64 - 1 {
                let p = pos as usize;
                if f[p] <= f[p - 1] && f[p] < f[p + 1] {
                    ok = true;
                    let s = f[p + 1] - f[p - 1];
                    let t = f[p - 1] - 2.0 * f[p] + f[p + 1];
                    tau = p as f64 - (0.5 * s) / t;
                    y = f[p] - (s * s) / (8.0 * t);
                }
            }
            if !ok {
                counter += 1;
                increment = if increment >= 0 { -increment - 1 } else { -increment + 1 };
            }
        }
        (tau, y)
    }

    fn local_cost(&self, f: usize, c: usize) -> f64 {
        const INFINITY_COST: f64 = 1000000.0;
        const VOICE_RMS_THRESHOLD: f64 = 100.0;
        let fd = &self.frames[f];
        let mut cost;
        if c == 0 {
            let mut min_y = 1.0;
            for &y in &fd.y {
                if y < min_y {
                    min_y = y;
                }
            }
            cost = 1.0 - min_y;
        } else {
            let mut k: i64 = -1;
            for i in 0..fd.t0.len() {
                if fd.y[i] <= self.threshold && (k == -1 || fd.t0[i] < fd.t0[k as usize]) {
                    k = i as i64;
                }
            }
            cost = if k != -1 && c as i64 == k { fd.y[c] - 0.1 } else { fd.y[c] };
            if fd.rms < VOICE_RMS_THRESHOLD {
                cost = INFINITY_COST;
            }
        }
        0.2 * cost
    }

    fn transition_cost(&self, prev: usize, pc: usize, curr: usize, cc: usize) -> f64 {
        const EPSILON: f64 = 1.0;
        const OCTAVE_CHANGE_COST: f64 = 2.0;
        const AMPLITUDE_TRANSITION_COST: f64 = 0.3;
        const FIXED_VOICING_STATE_TRANSITION_COST: f64 = 0.2;
        let per_20ms = (0.02 / INTERNAL_TIME_STEP_S) as i64;
        if pc > 0 && cc > 0 {
            OCTAVE_CHANGE_COST * ((self.frames[prev].t0[pc] / self.frames[curr].t0[cc]).ln() / 2f64.ln()).abs()
        } else if (pc > 0 && cc == 0) || (pc == 0 && cc > 0) {
            let mut right = curr as i64 + per_20ms / 2;
            let mut left = right - per_20ms;
            if left < 0 {
                left = 0;
            }
            if right >= self.frames.len() as i64 {
                right = self.frames.len() as i64 - 1;
            }
            let ratio = self.frames[right as usize].rms / (self.frames[left as usize].rms + EPSILON);
            let cost = if pc == 0 { AMPLITUDE_TRANSITION_COST / ratio } else { AMPLITUDE_TRANSITION_COST * ratio };
            cost + FIXED_VOICING_STATE_TRANSITION_COST
        } else {
            0.0
        }
    }

    fn best_path(&mut self) {
        let n = self.frames.len();
        if n < 1 {
            return;
        }
        for k in 0..self.frames[0].t0.len() {
            self.frames[0].lowest_path_cost[k] = self.local_cost(0, k);
            self.frames[0].best_prev[k] = -1;
        }
        for i in 1..n {
            for k in 0..self.frames[i].t0.len() {
                let local = self.local_cost(i, k);
                let mut lowest = f64::MAX;
                let mut best: i64 = -1;
                for m in 0..self.frames[i - 1].t0.len() {
                    let t = self.transition_cost(i - 1, m, i, k);
                    if self.frames[i - 1].lowest_path_cost[m] + t + local < lowest {
                        lowest = self.frames[i - 1].lowest_path_cost[m] + t + local;
                        best = m as i64;
                    }
                }
                self.frames[i].lowest_path_cost[k] = lowest;
                self.frames[i].best_prev[k] = best;
            }
        }
        let fd = &self.frames[n - 1];
        let mut m: i64 = 0;
        for k in 1..fd.t0.len() {
            if fd.lowest_path_cost[k] < fd.lowest_path_cost[m as usize] {
                m = k as i64;
            }
        }
        let mut i = n as i64 - 1;
        while m != -1 && i >= 0 {
            self.frames[i as usize].last = m;
            m = self.frames[i as usize].best_prev[m as usize];
            i -= 1;
        }
    }

    fn final_f0(&self, t: f64) -> f64 {
        if self.frames.is_empty() {
            return 0.0;
        }
        let mut f = (t / INTERNAL_TIME_STEP_S + 0.5) as i64;
        if f < 0 {
            f = 0;
        }
        if f > self.frames.len() as i64 - 1 {
            f = self.frames.len() as i64 - 1;
        }
        let fd = &self.frames[f as usize];
        if fd.last == -1 {
            return 0.0;
        }
        let t0 = fd.t0[fd.last as usize];
        if t0.abs() < 0.0000001 {
            0.0
        } else {
            1.0 / t0
        }
    }
}
