// A chorister's body: its voice type's measured anatomy, and its own within the measured spread (the owner, 16 November
// 2026: "have VocalWind support realistic physiological variation (even if small, to begin with) from singer to singer
// (women and men), supported by the literature we have"; the choir's design 2, approved 15 November 2026: each voice
// type a registry entry of measured ranges, "a chorister a seeded draw laid on a speaker by 2.4's setFor";
// research/VOCALWIND_CHOIR.md, "Singers drawn by voice type"). voices/voice-types.json `bodies`: each voice type's
// measured tract and folds (Roers, Mürbe & Sundberg 2009), its group's -- the singers of its sex there -- and how much one
// adult's tract differs from another's (Fitch & Giedd 1999). A chorister's body (the speakers its type is weighed from,
// src/blend.rs) is taken to stand for its group's mean, and given its type's pharynx -- the type's tract's difference
// from its group's, all in the pharynx and larynx (atlas to glottis), where Roers et al. found the types to differ most
// --, its own tract's lengths within the measured spread (the pharynx's, the larynx's and the hard palate's: the soft
// palate's, which sets where the velum closes, left the body's), and its folds, its type's mean length and its own
// within its type's measured spread: its glottis's rest length, its rest F0 inversely (a string's frequency at one
// stress). The tract's own vocal fold length (2.4's W3, the larynx's shape there) is left the body's: the speakers'
// differ by more than the singers measured (JD2's 1.2 cm, M01's 2.1), so that it is no length of theirs. Each draw a
// quantile, given (the performer's, from its seed), taken within `within` of the standard normal: feasible by
// construction. The measures are laid on the body by 2.4's setFor, held in no range of 2.4's but the pharynx's rule, as
// the measured speakers lie outside them (vtl-stream anatomy=singer,..., src/v24/anatomy.rs set_for_unheld), its rest
// length and F0 given its glottis (`set s.rest_length=...`).
use crate::v24::anatomy::{HARD_PALATE_LENGTH, LARYNX_LENGTH, NUM_ANATOMY_PARAMS, PHARYNX_LENGTH};
use serde_json::Value;
use std::collections::BTreeMap;
use std::sync::OnceLock;

/// A measured group of singers: its mean tract, pharynx (atlas to glottis) and folds (mm), and how far one adult's
/// tract's length lies from another's (its standard deviation over its mean).
#[derive(Clone, Debug)]
pub struct Group {
    pub tract_mm: f64,
    pub pharynx_mm: f64,
    pub fold_mm: f64,
    pub tract_spread: f64,
}

/// A voice type: its group, its median tract, its mean folds and their standard deviation (mm).
#[derive(Clone, Debug)]
pub struct VoiceType {
    pub group: String,
    pub tract_mm: f64,
    pub fold_mm: f64,
    pub fold_sd_mm: f64,
}

/// The measured bodies (voices/voice-types.json `bodies`).
pub struct Bodies {
    /// The quantiles of the standard normal a draw is taken within.
    pub within: (f64, f64),
    pub groups: BTreeMap<String, Group>,
    pub types: BTreeMap<String, VoiceType>,
    /// Each speaker's reach in each language: the ratios of its pharynx and larynx to its own (2.4's H0 and H1) within
    /// which it keeps every vowel the language is measured to sing on the engine (examples/singer_reach.rs reach), by
    /// language and speaker.
    pub reach: BTreeMap<String, BTreeMap<String, (f64, f64)>>,
}

/// A chorister as drawn on its body.
#[derive(Clone, Debug)]
pub struct Chorister {
    /// Its type's pharynx and larynx as measured, over its group's.
    pub pharynx_measured: f64,
    /// Its pharynx and larynx as its type's (held within its body's reach), its tract's lengths as its own, its folds'
    /// length: each over its body's.
    pub pharynx: f64,
    pub tract: f64,
    pub folds: f64,
    /// The thirteen measures (anatomy::ANATOMY_PARAMS) to lay on its body.
    pub measures: [f64; NUM_ANATOMY_PARAMS],
    /// Its glottis's rest length (cm) and rest F0 (Hz).
    pub rest_length: f64,
    pub rest_f0: f64,
}

/// voices/voice-types.json, beside this crate.
pub fn types_file() -> String {
    format!("{}/voices/voice-types.json", crate::home())
}

/// The measured bodies, read once.
pub fn bodies() -> &'static Bodies {
    static BODIES: OnceLock<Bodies> = OnceLock::new();
    BODIES.get_or_init(|| Bodies::read(&types_file()).unwrap_or_else(|e| panic!("{e}")))
}

impl Bodies {
    pub fn read(path: &str) -> Result<Bodies, String> {
        Bodies::parse(&std::fs::read_to_string(path).map_err(|e| format!("{path}: {e}"))?)
    }

    pub fn parse(text: &str) -> Result<Bodies, String> {
        let root: Value = serde_json::from_str(text).map_err(|e| format!("voice types: {e}"))?;
        let b = root.get("bodies").ok_or("voice types: no `bodies`")?;
        let num = |v: &Value, key: &str, of: &str| v.get(key).and_then(Value::as_f64).filter(|x| x.is_finite()).ok_or_else(|| format!("voice types: {of}'s `{key}` is a number"));
        let within = match b.get("within").and_then(Value::as_array).map(|a| a.iter().map(Value::as_f64).collect::<Vec<_>>()).as_deref() {
            Some([Some(lo), Some(hi)]) if 0.0 < *lo && lo < hi && *hi < 1.0 => (*lo, *hi),
            _ => return Err("voice types: `bodies.within` is two quantiles, 0 < low < high < 1".into()),
        };
        let mut groups = BTreeMap::new();
        for (name, g) in b.get("groups").and_then(Value::as_object).ok_or("voice types: no `bodies.groups`")? {
            let group = Group { tract_mm: num(g, "tract_mm", name)?, pharynx_mm: num(g, "pharynx_mm", name)?, fold_mm: num(g, "fold_mm", name)?, tract_spread: num(g, "tract_spread", name)? };
            if !(group.tract_mm > 0.0 && group.pharynx_mm > 0.0 && group.fold_mm > 0.0 && group.tract_spread >= 0.0) {
                return Err(format!("voice types: {name}'s lengths are above zero, its spread not below"));
            }
            groups.insert(name.clone(), group);
        }
        let mut types = BTreeMap::new();
        for (name, t) in b.get("types").and_then(Value::as_object).ok_or("voice types: no `bodies.types`")? {
            let group = t.get("group").and_then(Value::as_str).ok_or_else(|| format!("voice types: {name} has no `group`"))?;
            if !groups.contains_key(group) {
                return Err(format!("voice types: {name}'s group {group} is not among `bodies.groups`"));
            }
            let v = VoiceType { group: group.to_string(), tract_mm: num(t, "tract_mm", name)?, fold_mm: num(t, "fold_mm", name)?, fold_sd_mm: num(t, "fold_sd_mm", name)? };
            if !(v.tract_mm > 0.0 && v.fold_mm > 0.0 && v.fold_sd_mm >= 0.0) {
                return Err(format!("voice types: {name}'s lengths are above zero, its spread not below"));
            }
            types.insert(name.clone(), v);
        }
        let mut reach = BTreeMap::new();
        for (language, by) in b.get("reach").and_then(|r| r.get("pharynx")).and_then(Value::as_object).ok_or("voice types: no `bodies.reach.pharynx`")? {
            let mut speakers = BTreeMap::new();
            for (id, r) in by.as_object().ok_or_else(|| format!("voice types: the reach in {language} is by speaker"))? {
                match r.as_array().map(|a| a.iter().map(Value::as_f64).collect::<Vec<_>>()).as_deref() {
                    Some([Some(lo), Some(hi)]) if 0.0 < *lo && *lo <= 1.0 && 1.0 <= *hi => speakers.insert(id.clone(), (*lo, *hi)),
                    _ => return Err(format!("voice types: {id}'s reach in {language} is two ratios, 0 < low <= 1 <= high")),
                };
            }
            reach.insert(language.clone(), speakers);
        }
        Ok(Bodies { within, groups, types, reach })
    }

    /// The reach of a body weighed from `speakers` singing `language`: the narrowest of theirs (one not measured, its own
    /// pharynx alone).
    pub fn reach_of<'a>(&self, language: &str, speakers: impl IntoIterator<Item = &'a str>) -> (f64, f64) {
        speakers.into_iter().fold((0.0f64, f64::INFINITY), |(lo, hi), id| {
            let (l, h) = self.reach.get(language).and_then(|r| r.get(id)).copied().unwrap_or((1.0, 1.0));
            (lo.max(l), hi.min(h))
        })
    }

    /// The standard normal's value at a draw's quantile `u` (0 to 1), taken within `within`.
    pub fn drawn(&self, u: f64) -> f64 {
        let (lo, hi) = self.within;
        normal_quantile(lo + u.clamp(0.0, 1.0) * (hi - lo))
    }

    /// A chorister of `voice_type` on a body whose measures are `own` (anatomy::of), whose glottis rests at
    /// `rest_length` (cm) and `rest_f0` (Hz) and whose reach is `reach` (`reach_of`), its draws' quantiles `quantiles`
    /// (its tract's, its folds'; each 0 to 1). Its type's pharynx is held within the reach, and its tract's draw within
    /// what then keeps its pharynx and larynx there: the normal truncated to both `within` and that.
    pub fn chorister(&self, voice_type: &str, quantiles: [f64; 2], own: &[f64; NUM_ANATOMY_PARAMS], rest_length: f64, rest_f0: f64, reach: (f64, f64)) -> Result<Chorister, String> {
        let t = self.types.get(voice_type).ok_or_else(|| format!("no measured body for a {voice_type} (voices/voice-types.json `bodies.types`)"))?;
        let g = &self.groups[&t.group];
        if !(reach.0 <= 1.0 && 1.0 <= reach.1) {
            return Err(format!("a reach of {reach:?} leaves out the body's own pharynx"));
        }
        let pharynx_measured = 1.0 + (t.tract_mm - g.tract_mm) / g.pharynx_mm;
        let pharynx = pharynx_measured.clamp(reach.0, reach.1);
        // (The quantiles its tract is drawn within: `within`'s, and those of the tract that keeps it in the reach.)
        let tract = if g.tract_spread > 0.0 {
            let lo = self.within.0.max(normal_cdf((reach.0 / pharynx - 1.0) / g.tract_spread));
            let hi = self.within.1.min(normal_cdf((reach.1 / pharynx - 1.0) / g.tract_spread));
            // (Its ends within the reach: the distribution's rounding, some 1e-9, not past them.)
            (1.0 + normal_quantile(lo + quantiles[0].clamp(0.0, 1.0) * (hi - lo)) * g.tract_spread).clamp(reach.0 / pharynx, reach.1 / pharynx)
        } else {
            1.0
        };
        let folds = (t.fold_mm + self.drawn(quantiles[1]) * t.fold_sd_mm) / g.fold_mm;
        let mut measures = *own;
        for k in [PHARYNX_LENGTH, LARYNX_LENGTH] {
            measures[k] *= pharynx * tract;
        }
        measures[HARD_PALATE_LENGTH] *= tract;
        Ok(Chorister { pharynx_measured, pharynx, tract, folds, measures, rest_length: rest_length * folds, rest_f0: rest_f0 / folds })
    }
}

/// The standard normal's distribution at `z`: erfc by its Chebyshev fit (Press et al., Numerical Recipes, `erfcc`),
/// its relative error under 1.2e-7.
pub fn normal_cdf(z: f64) -> f64 {
    let x = -z / std::f64::consts::SQRT_2;
    let a = x.abs();
    let t = 1.0 / (1.0 + 0.5 * a);
    let erfc = t * (-a * a - 1.26551223 + t * (1.00002368 + t * (0.37409196 + t * (0.09678418 + t * (-0.18628806 + t * (0.27886807 + t * (-1.13520398 + t * (1.48851587 + t * (-0.82215223 + t * 0.17087277))))))))).exp();
    0.5 * if x >= 0.0 { erfc } else { 2.0 - erfc }
}

/// The standard normal's quantile at `p` (0 < p < 1): Acklam's rational approximation, its relative error under
/// 1.15e-9.
pub fn normal_quantile(p: f64) -> f64 {
    const A: [f64; 6] = [-3.969683028665376e1, 2.209460984245205e2, -2.759285104469687e2, 1.383577518672690e2, -3.066479806614716e1, 2.506628277459239];
    const B: [f64; 5] = [-5.447609879822406e1, 1.615858368580409e2, -1.556989798598866e2, 6.680131188771972e1, -1.328068155288572e1];
    const C: [f64; 6] = [-7.784894002430293e-3, -3.223964580411365e-1, -2.400758277161838, -2.549732539343734, 4.374664141464968, 2.938163982698783];
    const D: [f64; 4] = [7.784695709041462e-3, 3.224671290700398e-1, 2.445134137142996, 3.754408661907416];
    const LOW: f64 = 0.02425;
    let tail = |q: f64| (((((C[0] * q + C[1]) * q + C[2]) * q + C[3]) * q + C[4]) * q + C[5]) / ((((D[0] * q + D[1]) * q + D[2]) * q + D[3]) * q + 1.0);
    if p < LOW {
        tail((-2.0 * p.ln()).sqrt())
    } else if p > 1.0 - LOW {
        -tail((-2.0 * (1.0 - p).ln()).sqrt())
    } else {
        let q = p - 0.5;
        let r = q * q;
        (((((A[0] * r + A[1]) * r + A[2]) * r + A[3]) * r + A[4]) * r + A[5]) * q / (((((B[0] * r + B[1]) * r + B[2]) * r + B[3]) * r + B[4]) * r + 1.0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// The normal's quantile at known points (z of 0.5, 0.975, 0.025, 0.001: 0, 1.959964, -1.959964, -3.090232).
    #[test]
    fn the_normal_quantile() {
        for (p, z) in [(0.5, 0.0), (0.975, 1.959_963_985), (0.025, -1.959_963_985), (0.001, -3.090_232_306), (0.999, 3.090_232_306)] {
            assert!((normal_quantile(p) - z).abs() < 1e-8, "{p}: {} for {z}", normal_quantile(p));
        }
    }

    /// Every voice type's chorister, at its draws' middles and ends: at the middle its tract its group's, its folds its
    /// type's mean, and no measure but its pharynx's, larynx's and hard palate's changed; at the ends within `within`, the
    /// tract longer and the folds longer as the draws rise; a soprano's pharynx shorter than her group's mean, a bass's
    /// longer.
    #[test]
    fn choristers_by_voice_type() {
        let b = bodies();
        const WIDE: (f64, f64) = (0.5, 2.0);
        let own: [f64; NUM_ANATOMY_PARAMS] = std::array::from_fn(|k| 1.0 + k as f64 / 10.0);
        let edge = normal_quantile(b.within.1);
        for (name, t) in &b.types {
            let g = &b.groups[&t.group];
            let mid = b.chorister(name, [0.5, 0.5], &own, 1.2, 220.0, WIDE).unwrap();
            assert!((mid.tract - 1.0).abs() < 1e-12 && (mid.folds - t.fold_mm / g.fold_mm).abs() < 1e-12, "{name}: {mid:?}");
            for k in 0..NUM_ANATOMY_PARAMS {
                if ![PHARYNX_LENGTH, LARYNX_LENGTH, HARD_PALATE_LENGTH].contains(&k) {
                    assert_eq!(mid.measures[k], own[k], "{name}: measure {k}");
                }
            }
            let (low, high) = (b.chorister(name, [0.0, 0.0], &own, 1.2, 220.0, WIDE).unwrap(), b.chorister(name, [1.0, 1.0], &own, 1.2, 220.0, WIDE).unwrap());
            assert!((high.tract - 1.0 - edge * g.tract_spread).abs() < 1e-9 && (low.tract - 1.0 + edge * g.tract_spread).abs() < 1e-9, "{name}: {low:?} {high:?}");
            assert!(low.measures[PHARYNX_LENGTH] < mid.measures[PHARYNX_LENGTH] && mid.measures[PHARYNX_LENGTH] < high.measures[PHARYNX_LENGTH], "{name}");
            assert!(low.rest_length < mid.rest_length && mid.rest_length < high.rest_length && low.rest_f0 > high.rest_f0, "{name}");
            assert!((high.rest_length * high.rest_f0 - 1.2 * 220.0).abs() < 1e-9, "{name}: a string's frequency at one stress");
        }
        assert!(b.chorister("soprano", [0.5, 0.5], &own, 1.2, 220.0, WIDE).unwrap().pharynx < 1.0);
        assert!(b.chorister("bass", [0.5, 0.5], &own, 1.6, 120.0, WIDE).unwrap().pharynx > 1.0);
        assert!(b.chorister("countertenor", [0.5, 0.5], &own, 1.6, 120.0, WIDE).is_err());
    }

    /// Held within a reach: a bass's measured pharynx, beyond it, at its end, and every draw of its tract keeping its
    /// pharynx there, the shorter as the draw is lower; a soprano within it drawn as without; a reach without the body's
    /// own refused; a blend's the narrowest of its speakers'.
    #[test]
    fn choristers_within_their_reach() {
        let b = bodies();
        let own: [f64; NUM_ANATOMY_PARAMS] = std::array::from_fn(|k| 1.0 + k as f64 / 10.0);
        let reach = (0.95, 1.05);
        let mut last = 0.0;
        for i in 0..=10 {
            let c = b.chorister("bass", [i as f64 / 10.0, 0.5], &own, 1.6, 120.0, reach).unwrap();
            assert!(c.pharynx_measured > reach.1 && c.pharynx == reach.1, "{c:?}");
            let length = c.pharynx * c.tract;
            assert!(reach.0 - 1e-12 <= length && length <= reach.1 + 1e-12 && length > last, "{i}: {length}");
            last = length;
        }
        let (held, free) = (b.chorister("soprano", [0.2, 0.5], &own, 1.2, 220.0, (0.85, 1.2)).unwrap(), b.chorister("soprano", [0.2, 0.5], &own, 1.2, 220.0, (0.5, 2.0)).unwrap());
        assert!((held.tract - free.tract).abs() < 1e-12 && held.pharynx == free.pharynx);
        assert!(b.chorister("bass", [0.5, 0.5], &own, 1.6, 120.0, (1.01, 1.2)).is_err());
        for (language, by) in &b.reach {
            let narrowest = b.reach_of(language, by.keys().map(String::as_str));
            assert!(by.values().all(|r| r.0 <= narrowest.0 && narrowest.1 <= r.1), "{language}");
        }
        assert_eq!(b.reach_of("la", ["nobody"]), (1.0, 1.0));
        assert_eq!(b.reach_of("tlh", ["JD2"]), (1.0, 1.0));
    }

    /// A chorister asked for as a singer's (`anatomy=singer,...`) is laid with every measure as drawn, M01's larynx 4.6
    /// cm wide where 2.4 allows 3.5 among them; the same measures asked for plainly are held in 2.4's ranges.
    #[test]
    fn a_chorister_is_laid_as_drawn() {
        use crate::blend::{synthesis_home, voices_file, Voices};
        use crate::v24::anatomy::{asked, of, ANATOMY_PARAMS, LARYNX_WIDTH};
        use crate::v24::speaker::Speaker;
        let voices = Voices::read(&voices_file()).unwrap();
        let file = voices.file(&synthesis_home(), "M01").unwrap();
        if !std::path::Path::new(&file).exists() {
            eprintln!("skipped: M01's file is not on this machine ({file})");
            return;
        }
        let body = Speaker::read(&file).unwrap();
        let c = bodies().chorister("bass", [0.3, 0.7], &of(&body.tract), 1.6, 120.0, (0.5, 2.0)).unwrap();
        let measures = c.measures.iter().map(|x| x.to_string()).collect::<Vec<_>>().join(",");
        let laid = |text: &str| {
            let a = asked(text).unwrap().unwrap();
            let mut tract = body.tract.clone();
            let x = a.lay(&mut tract, &body.tract);
            (x, of(&tract))
        };
        let (x, read) = laid(&format!("singer,{measures}"));
        for k in 0..NUM_ANATOMY_PARAMS {
            assert!(x[k] == c.measures[k] && (read[k] - c.measures[k]).abs() < 1e-9, "{}: {} laid, {} read, {} drawn", ANATOMY_PARAMS[k].key, x[k], read[k], c.measures[k]);
        }
        assert!(c.measures[LARYNX_WIDTH] > ANATOMY_PARAMS[LARYNX_WIDTH].max, "M01's larynx is no longer wider than 2.4 allows");
        let (x, read) = laid(&measures);
        assert!(x[LARYNX_WIDTH] == ANATOMY_PARAMS[LARYNX_WIDTH].max && (read[LARYNX_WIDTH] - x[LARYNX_WIDTH]).abs() < 1e-9);
    }
}
