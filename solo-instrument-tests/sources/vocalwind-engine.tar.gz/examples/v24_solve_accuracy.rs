// What "preserves accurate physics" is measured as, for the tube's own order of the solve (research/
// VOCAL_TRACT_REALTIME_PLAN.md, 1): the same system each step, solved in 2.4's order and in the tree's, each in double
// precision, against its solution in double-double refined against its residual (src/v24/solve.rs) -- the truth for
// these equations.
//   systems  -- every `every`-th step's system of each passage at each rate: each order's forward error (norm-wise, in
//               the 2-norm and the largest current's, over the reference's), the system's condition number (1-norm),
//               and the reference's own residual; their median, 99th percentile and largest over all systems.
//   passages -- each passage synthesized with the noise sources off (nothing random to follow a rounding) with each
//               order's solve and with the reference's: each order's largest and rms deviation from the reference's
//               sound, over its peak and its rms.
//   noise    -- with the noise on, 2.4's order and the tree's: the first sample where they part by more than rounding
//               (a noise source tipped on or off, its draws then other draws of the same law), and their long-term
//               third-octave spectra.
// The passages are 2.4's own: its API's three .seg files, its program's example01 and its 50 sentences, across its three
// speakers in turn (as test/audio/vocaltract.test.mjs plays them), each made into a score by 2.4's rules.
//   cargo run --release --example v24_solve_accuracy -- systems <2.4's folder> [rates=1,2,4] [every=101] [which=0..54]
//   cargo run --release --example v24_solve_accuracy -- passages <2.4's folder> [rates=1,2,4] [which=0,7,21]
//   cargo run --release --example v24_solve_accuracy -- noise <2.4's folder> [rates=1] [which=0..54]
use musebots_vocaltract::segments::parse_segments;
use musebots_vocaltract::v24::gestural::GesturalScore;
use musebots_vocaltract::v24::solve::{Dd, EnvelopeCholesky, System, TreeCholesky};
use musebots_vocaltract::v24::speaker::Speaker;
use musebots_vocaltract::v24::synth::{Synthesizer, NUM_CHUNK_SAMPLES};
use musebots_vocaltract::v24::tds::{Solver, TdsModel};
use std::path::Path;

/// 2.4's 54 passages, each with its speaker.
fn passages(folder: &Path) -> Vec<(String, String)> {
    let segs = |sub: &str| -> Vec<String> {
        let mut v: Vec<String> = std::fs::read_dir(folder.join("unpacked").join(sub)).expect("2.4's examples").filter_map(|e| e.ok()).map(|e| e.file_name().to_string_lossy().into_owned()).filter(|f| f.ends_with(".seg")).map(|f| format!("{sub}/{f}")).collect();
        v.sort();
        v
    };
    let mut all = segs("API");
    all.push("GUI/example01.seg".into());
    all.extend(segs("GUI/Examples"));
    all.into_iter().enumerate().map(|(k, p)| (p, ["JD2", "M01", "W02"][k % 3].to_string())).collect()
}

fn frames(folder: &Path, input: &str, speaker: &Speaker) -> Vec<(Vec<f64>, Vec<f64>)> {
    let mut tract = speaker.tract.clone();
    let mut made = GesturalScore::test();
    made.from_segments(&parse_segments(&std::fs::read_to_string(folder.join("unpacked").join(input)).expect("segments")), &mut tract);
    let (score, _) = GesturalScore::parse(&made.to_xml()).expect("a gestural score");
    score.frames(&tract, &speaker.glottis)
}

/// A passage synthesized at `n` steps a sample, `f` given the synthesizer after each frame.
fn synthesize(speaker: &Speaker, frames: &[(Vec<f64>, Vec<f64>)], n: usize, set: impl Fn(&mut TdsModel), mut f: impl FnMut(&mut Synthesizer)) -> Vec<f64> {
    let mut synth = Synthesizer::new(speaker.glottis.clone(), TdsModel::new());
    set(&mut synth.tds);
    synth.set_oversampling(n);
    let mut tract = speaker.tract.clone();
    let mut out = vec![0.0; (frames.len() - 1) * NUM_CHUNK_SAMPLES];
    for (k, (tp, gp)) in frames.iter().enumerate() {
        let span = if k == 0 { 0..0 } else { (k - 1) * NUM_CHUNK_SAMPLES..k * NUM_CHUNK_SAMPLES };
        synth.add_tract(&mut tract, tp, gp, &mut out[span]);
        f(&mut synth);
    }
    out
}

fn quantiles(v: &mut Vec<f64>) -> (f64, f64, f64) {
    v.sort_by(|a, b| a.partial_cmp(b).unwrap());
    if v.is_empty() {
        return (f64::NAN, f64::NAN, f64::NAN);
    }
    let q = |p: f64| v[((v.len() - 1) as f64 * p).round() as usize];
    (q(0.5), q(0.99), v[v.len() - 1])
}

/// Each order's error against the reference, norm-wise: (2-norm, largest current's), over the reference's.
fn errors(x: &[f64], reference: &[Dd]) -> (f64, f64) {
    let (mut e2, mut r2, mut emax, mut rmax) = (Dd::ZERO, Dd::ZERO, 0.0f64, 0.0f64);
    for (a, r) in x.iter().zip(reference) {
        let d = Dd::from(*a) - *r;
        e2 = e2 + d * d;
        r2 = r2 + *r * *r;
        emax = emax.max(d.to_f64().abs());
        rmax = rmax.max(r.to_f64().abs());
    }
    ((e2.to_f64() / r2.to_f64()).sqrt(), emax / rmax)
}

/// The system's condition number in the 1-norm: its matrix's norm times its inverse's, the inverse's columns solved
/// for one by one (in the tree's order: its accuracy does not matter here).
fn condition(s: &System, tree: &mut TreeCholesky) -> f64 {
    let n = s.n;
    let norm = (0..n).map(|j| (0..n).map(|i| s.get(i, j).abs()).sum::<f64>()).fold(0.0, f64::max);
    let mut unit = s.clone();
    let mut column = vec![0.0; n];
    let mut inverse = 0.0f64;
    for j in 0..n {
        unit.rhs.iter_mut().for_each(|x| *x = 0.0);
        unit.rhs[j] = 1.0;
        tree.solve(&unit, &mut column);
        inverse = inverse.max(column.iter().map(|x| x.abs()).sum());
    }
    norm * inverse
}

fn systems(folder: &Path, rates: &[usize], every: usize, which: &[usize]) {
    let all = passages(folder);
    let (mut env2, mut envmax, mut tree2, mut treemax, mut cond, mut residual, mut ratio) = (vec![], vec![], vec![], vec![], vec![], vec![], vec![]);
    let (mut worse, mut count, mut negative, mut rest) = (0usize, 0usize, 0u64, 0usize);
    for &k in which {
        let (input, who) = &all[k];
        let speaker = Speaker::read(&folder.join(format!("{who}.speaker")).to_string_lossy()).expect("speaker");
        let frames = frames(folder, input, &speaker);
        for &n in rates {
            let mut kept = 0;
            // (The same tube, so the same pattern, every step: each order made once.)
            let mut solvers: Option<(EnvelopeCholesky, TreeCholesky)> = None;
            synthesize(&speaker, &frames, n, |m| m.record_every = every * n, |synth| {
                for s in synth.tds.recorded.drain(..) {
                    let (envelope, tree) = solvers.get_or_insert_with(|| (EnvelopeCholesky::new(&s), TreeCholesky::new(&s)));
                    let before = envelope.negative_pivots + tree.negative_pivots;
                    let (mut a, mut b, mut c) = (vec![0.0; s.n], vec![0.0; s.n], vec![0.0; s.n]);
                    let mut full = vec![Dd::ZERO; s.n];
                    envelope.solve(&s, &mut a);
                    tree.solve(&s, &mut b);
                    let neg = tree.solve_reference(&s, &mut c, &mut full);
                    if neg > 0 || envelope.negative_pivots + tree.negative_pivots > before {
                        negative += 1;
                        continue;
                    }
                    // (A system at rest, every current zero, has no error to measure.)
                    if full.iter().all(|x| x.hi == 0.0) {
                        rest += 1;
                        continue;
                    }
                    let (e2, emax) = errors(&a, &full);
                    let (t2, tmax) = errors(&b, &full);
                    // The reference's own residual, in double-double, over |b| + |A||x|.
                    let mut worst = 0.0f64;
                    for i in 0..s.n {
                        let mut r = Dd::from(s.rhs[i]);
                        let mut scale = s.rhs[i].abs();
                        for j in 0..s.n {
                            let v = s.get(i, j);
                            if v != 0.0 {
                                r = r - Dd::from(v) * full[j];
                                scale += (v * full[j].hi).abs();
                            }
                        }
                        worst = worst.max(r.to_f64().abs() / scale);
                    }
                    let kappa = condition(&s, tree);
                    env2.push(e2);
                    envmax.push(emax);
                    tree2.push(t2);
                    treemax.push(tmax);
                    cond.push(kappa);
                    residual.push(worst * kappa);
                    if e2 > 0.0 {
                        ratio.push(t2 / e2);
                    }
                    worse += (t2 > e2) as usize;
                    count += 1;
                    kept += 1;
                }
            });
            println!("v24_solve_accuracy: {input} ({who}) at {} kHz: {kept} systems", 48 * n);
        }
    }
    let show = |name: &str, v: &mut Vec<f64>| {
        let (m, p, x) = quantiles(v);
        println!("  {name:<44} median {m:.3e}  99th {p:.3e}  largest {x:.3e}");
    };
    println!("v24_solve_accuracy: {count} systems ({negative} with a pivot under zero and {rest} at rest left out)");
    show("2.4's order, error (2-norm, relative)", &mut env2);
    show("the tree's order, error (2-norm, relative)", &mut tree2);
    show("2.4's order, error (largest current's)", &mut envmax);
    show("the tree's order, error (largest current's)", &mut treemax);
    show("the tree's error over 2.4's (2-norm)", &mut ratio);
    show("condition number (1-norm)", &mut cond);
    show("the reference's error, bounded (cond x residual)", &mut residual);
    println!("  the tree's error larger than 2.4's in {worse} of {count} systems");
}

fn compare(name: &str, x: &[f64], truth: &[f64]) {
    let peak = truth.iter().fold(0.0f64, |m, v| m.max(v.abs()));
    let rms = (truth.iter().map(|v| v * v).sum::<f64>() / truth.len() as f64).sqrt();
    let largest = x.iter().zip(truth).fold(0.0f64, |m, (a, b)| m.max((a - b).abs()));
    let drms = (x.iter().zip(truth).map(|(a, b)| (a - b) * (a - b)).sum::<f64>() / truth.len() as f64).sqrt();
    println!("    {name:<12} largest deviation {:.3e} of its peak, rms {:.3e} of its rms", largest / peak, drms / rms);
}

fn passages_mode(folder: &Path, rates: &[usize], which: &[usize]) {
    let all = passages(folder);
    for &k in which {
        let (input, who) = &all[k];
        let speaker = Speaker::read(&folder.join(format!("{who}.speaker")).to_string_lossy()).expect("speaker");
        let frames = frames(folder, input, &speaker);
        for &n in rates {
            let run = |solver: Solver| synthesize(&speaker, &frames, n, |m| {
                m.options.generate_noise_sources = false;
                m.options.solver = solver;
            }, |_| {});
            let truth = run(Solver::Reference);
            println!("v24_solve_accuracy: {input} ({who}) at {} kHz, the noise off, against the reference's solve:", 48 * n);
            compare("2.4's order", &run(Solver::Envelope), &truth);
            compare("the tree's", &run(Solver::Tree), &truth);
        }
    }
}

/// Power in third-octave bands (25 Hz to 20 kHz) of a signal at 48 kHz: Welch's average over Hann-windowed 8192-sample
/// frames, half overlapped.
fn third_octaves(x: &[f64]) -> Vec<(f64, f64)> {
    let m = 8192;
    let mut psd = vec![0.0; m / 2];
    let mut frames = 0;
    let mut start = 0;
    while start + m <= x.len() {
        let mut re: Vec<f64> = (0..m).map(|i| x[start + i] * (0.5 - 0.5 * (2.0 * std::f64::consts::PI * i as f64 / m as f64).cos())).collect();
        let mut im = vec![0.0; m];
        fft(&mut re, &mut im);
        for k in 0..m / 2 {
            psd[k] += re[k] * re[k] + im[k] * im[k];
        }
        frames += 1;
        start += m / 2;
    }
    let mut bands = Vec::new();
    for b in -16..=13 {
        let fc = 1000.0 * 2f64.powf(b as f64 / 3.0);
        let (lo, hi) = (fc / 2f64.powf(1.0 / 6.0), fc * 2f64.powf(1.0 / 6.0));
        let p: f64 = (0..m / 2).filter(|&k| {
            let f = k as f64 * 48000.0 / m as f64;
            f >= lo && f < hi
        }).map(|k| psd[k]).sum();
        if p > 0.0 && frames > 0 {
            bands.push((fc, p / frames as f64));
        }
    }
    bands
}

fn fft(re: &mut [f64], im: &mut [f64]) {
    let n = re.len();
    let mut j = 0;
    for i in 1..n {
        let mut bit = n >> 1;
        while j & bit != 0 {
            j ^= bit;
            bit >>= 1;
        }
        j |= bit;
        if i < j {
            re.swap(i, j);
            im.swap(i, j);
        }
    }
    let mut len = 2;
    while len <= n {
        let w = -2.0 * std::f64::consts::PI / len as f64;
        for start in (0..n).step_by(len) {
            for k in 0..len / 2 {
                let (s, c) = (w * k as f64).sin_cos();
                let (a, b) = (start + k, start + k + len / 2);
                let (xr, xi) = (re[b] * c - im[b] * s, re[b] * s + im[b] * c);
                re[b] = re[a] - xr;
                im[b] = im[a] - xi;
                re[a] += xr;
                im[a] += xi;
            }
        }
        len <<= 1;
    }
}

fn noise_mode(folder: &Path, rates: &[usize], which: &[usize]) {
    let all = passages(folder);
    let mut widest = 0.0f64;
    for &k in which {
        let (input, who) = &all[k];
        let speaker = Speaker::read(&folder.join(format!("{who}.speaker")).to_string_lossy()).expect("speaker");
        let frames = frames(folder, input, &speaker);
        for &n in rates {
            let run = |solver: Solver| synthesize(&speaker, &frames, n, |m| m.options.solver = solver, |_| {});
            let (a, b) = (run(Solver::Envelope), run(Solver::Tree));
            let peak = a.iter().fold(0.0f64, |m, v| m.max(v.abs()));
            let parted = a.iter().zip(&b).position(|(x, y)| (x - y).abs() > 1e-9 * peak);
            let (sa, sb) = (third_octaves(&a), third_octaves(&b));
            // (Bands carrying a millionth of the loudest band's power or more: the rest is under any hearing.)
            let top = sa.iter().map(|x| x.1).fold(0.0, f64::max);
            let apart = sa.iter().zip(&sb).filter(|(x, _)| x.1 > 1e-6 * top).map(|(x, y)| (10.0 * (y.1 / x.1).log10()).abs()).fold(0.0f64, f64::max);
            widest = widest.max(apart);
            println!(
                "v24_solve_accuracy: {input} ({who}) at {} kHz, the noise on: {}; third-octave bands at most {apart:.3} dB apart",
                48 * n,
                match parted {
                    Some(i) => format!("the two orders part at sample {i} of {} ({:.3} s)", a.len(), i as f64 / 48000.0),
                    None => "the two orders never part beyond rounding".into(),
                }
            );
        }
    }
    println!("v24_solve_accuracy: the widest third-octave difference {widest:.3} dB");
}

fn list(arg: Option<&String>, default: Vec<usize>) -> Vec<usize> {
    match arg {
        None => default,
        Some(s) if s.contains("..") => {
            let (a, b) = s.split_once("..").unwrap();
            (a.parse().unwrap()..b.parse().unwrap()).collect()
        }
        Some(s) => s.split(',').map(|x| x.parse().unwrap()).collect(),
    }
}

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let folder = Path::new(&args[1]);
    let rates = list(args.get(2), vec![1, 2, 4]);
    match args[0].as_str() {
        "systems" => {
            let every = args.get(3).map(|s| s.parse().unwrap()).unwrap_or(101);
            systems(folder, &rates, every, &list(args.get(4), (0..54).collect()))
        }
        "passages" => passages_mode(folder, &rates, &list(args.get(3), vec![0, 7, 21])),
        "noise" => noise_mode(folder, &rates, &list(args.get(3), (0..54).collect())),
        _ => panic!("systems, passages or noise"),
    }
}
