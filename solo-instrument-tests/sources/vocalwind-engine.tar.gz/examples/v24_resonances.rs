// Where VocalTractLab 2.4's time-domain simulation is to be trusted (the owner, 11 November 2026, of the 12 kHz
// low-pass: "we will need to remove that 12k lowpass as well as correct whatever flaw of the design it was masking"): a
// held vowel's tube (its 50 sections from the port's 2.4 tract), its glottis closed, driven by one impulse of flow at the
// glottis, the flow radiated at the lips (and nostrils) recorded and its transfer function's resonances found -- with
// the simulation's time step at 48, 96 and 192 kHz -- beside the resonances of an exact transmission line through the
// same 50 cylinders (each distributed, lossless, the same radiation load at the lips). What the rate changes is the time
// discretization's error (the trapezoid's frequency warping); what remains at 192 kHz is the lumped sections' own.
// Measurement only: nothing of the model changed (its time step set; its noise, the skin's flow, the piriform fossae and
// the walls' give off, as the exact line has none of them).
//   cargo run --release --example v24_resonances -- JD2.speaker a
use musebots_vocaltract::v24::constants::{AMBIENT_DENSITY_CGS as RHO, PI, SOUND_VELOCITY_CGS as C};
use musebots_vocaltract::v24::speaker::Speaker;
use musebots_vocaltract::v24::tds::TdsModel;
use musebots_vocaltract::v24::tube::{Tube, FIRST_PHARYNX_SECTION, MIN_AREA_CM2};

const STEP_HZ: f64 = 5.0;
const TOP_HZ: f64 = 24000.0;

/// |H(f)| on the grid, by Goertzel's sums over the response.
fn magnitude(response: &[f64], rate: f64) -> Vec<f64> {
    let n = (TOP_HZ / STEP_HZ) as usize;
    (1..=n)
        .map(|k| {
            let w = 2.0 * PI * k as f64 * STEP_HZ / rate;
            let (mut s1, mut s2) = (0.0, 0.0);
            let coeff = 2.0 * w.cos();
            for &x in response {
                let s0 = x + coeff * s1 - s2;
                s2 = s1;
                s1 = s0;
            }
            (s1 * s1 + s2 * s2 - coeff * s1 * s2).sqrt()
        })
        .collect()
}

/// The local maxima of a magnitude on the grid, above the 50 Hz floor: their frequencies.
fn peaks(m: &[f64]) -> Vec<f64> {
    (1..m.len() - 1).filter(|&i| m[i] > m[i - 1] && m[i] >= m[i + 1] && (i + 1) as f64 * STEP_HZ > 50.0).map(|i| (i + 1) as f64 * STEP_HZ).collect()
}

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let speaker = Speaker::read(&args[0]).expect("speaker");
    let mut tract = speaker.tract;
    let shape = tract.shape(&args[1]).expect("a shape of the speaker's");
    tract.calculate(&shape);
    let geometry = tract.tube();
    let mut tube = Tube::new();
    tube.set_from_tract(&geometry);
    tube.set_glottis_sections(&[0.3, 0.3], &[MIN_AREA_CM2, MIN_AREA_CM2]);
    let lengths: Vec<f64> = (0..50).map(|i| tube.section[FIRST_PHARYNX_SECTION + i].length_cm).collect();
    let areas: Vec<f64> = (0..50).map(|i| tube.section[FIRST_PHARYNX_SECTION + i].area_cm2).collect();
    println!("{}: {:.2} cm of pharynx and mouth in 50 sections of {:.3} to {:.3} cm", args[1], lengths.iter().sum::<f64>(), lengths.iter().cloned().fold(f64::MAX, f64::min), lengths.iter().cloned().fold(0.0, f64::max));
    // The exact line: chain matrices of lossless cylinders, the lips loaded by VocalTractLab's radiation (R and L in
    // parallel); the transfer function U_lips / U_glottis.
    let n = (TOP_HZ / STEP_HZ) as usize;
    let a_lips = areas[49];
    let r_rad = 128.0 * RHO * C / (9.0 * PI * PI * a_lips);
    let l_rad = 8.0 * RHO / (3.0 * PI * (a_lips * PI).sqrt());
    let exact: Vec<f64> = (1..=n)
        .map(|k| {
            let w = 2.0 * PI * k as f64 * STEP_HZ;
            // (complex numbers as pairs)
            let mul = |a: (f64, f64), b: (f64, f64)| (a.0 * b.0 - a.1 * b.1, a.0 * b.1 + a.1 * b.0);
            let add = |a: (f64, f64), b: (f64, f64)| (a.0 + b.0, a.1 + b.1);
            let div = |a: (f64, f64), b: (f64, f64)| {
                let d = b.0 * b.0 + b.1 * b.1;
                ((a.0 * b.0 + a.1 * b.1) / d, (a.1 * b.0 - a.0 * b.1) / d)
            };
            let mut m = [(1.0, 0.0), (0.0, 0.0), (0.0, 0.0), (1.0, 0.0)];
            for i in 0..50 {
                let kl = w / C * lengths[i];
                let z = RHO * C / areas[i];
                let s = [(kl.cos(), 0.0), (0.0, z * kl.sin()), (0.0, kl.sin() / z), (kl.cos(), 0.0)];
                m = [add(mul(m[0], s[0]), mul(m[1], s[2])), add(mul(m[0], s[1]), mul(m[1], s[3])), add(mul(m[2], s[0]), mul(m[3], s[2])), add(mul(m[2], s[1]), mul(m[3], s[3]))];
            }
            let jwl = (0.0, w * l_rad);
            let zr = div(mul((r_rad, 0.0), jwl), add((r_rad, 0.0), jwl));
            let h = div((1.0, 0.0), add(mul(m[2], zr), m[3]));
            (h.0 * h.0 + h.1 * h.1).sqrt()
        })
        .collect();
    let exact_peaks = peaks(&exact);
    println!("exact line:  {}", exact_peaks.iter().map(|f| format!("{f:.0}")).collect::<Vec<_>>().join(" "));
    for rate in [48000.0, 96000.0, 192000.0] {
        let mut tds = TdsModel::new();
        tds.options.generate_noise_sources = false;
        tds.options.radiation_from_skin = false;
        // (Its fossae closed and its walls rigid: the exact line has neither.)
        tds.options.piriform_fossa = false;
        tds.options.soft_walls = false;
        tds.time_step = 1.0 / rate;
        tds.reset_motion();
        tds.set_tube(&tube, false);
        let samples = (0.25 * rate) as usize;
        let mut response = Vec::with_capacity(samples);
        for s in 0..samples {
            // (A small impulse, 1 cm^3/s for a sample: the flow-dependent recovery of pressure stays negligible, and the
            // response linear.)
            tds.set_flow_source(if s == 0 { 1.0 } else { 0.0 }, FIRST_PHARYNX_SECTION as i32);
            let r = tds.proceed_time_step();
            response.push(r.mouth + r.nostrils);
        }
        let finite = response.iter().all(|x| x.is_finite());
        let p = if finite { peaks(&magnitude(&response, rate)) } else { Vec::new() };
        if p.is_empty() {
            println!("TDS {:>3.0} kHz: no resonances (its response {})", rate / 1000.0, if finite { "flat" } else { "not finite" });
            continue;
        }
        // Each exact resonance where the trapezoid's warping puts it (the bilinear map, f -> (rate/pi) atan(pi f / rate)),
        // the simulation's nearest to that, and what remains in cents: the warping's error is the first figure, the rest
        // the lumped sections' and the losses'.
        let errors: Vec<String> = exact_peaks
            .iter()
            .map(|&f| {
                let warped = rate / PI * (PI * f / rate).atan();
                let near = p.iter().cloned().fold(f64::MAX, |best, x| if (x - warped).abs() < (best - warped).abs() { x } else { best });
                format!("{:.0}[{:+.0}c,{:+.0}c]", near, 1200.0 * (warped / f).log2(), 1200.0 * (near / warped).log2())
            })
            .collect();
        println!("TDS {:>3.0} kHz: {}", rate / 1000.0, errors.join(" "));
        // The response's power in four bands of the 48 kHz signal's, in dB of its whole (the radiated pressure, the flow's
        // derivative, as the synthesizer radiates it).
        let m = magnitude(&response, rate);
        let band = |lo: f64, hi: f64| -> f64 { m.iter().enumerate().filter(|(i, _)| { let f = (*i + 1) as f64 * STEP_HZ; f >= lo && f < hi }).map(|(i, x)| { let f = (i + 1) as f64 * STEP_HZ; (x * f).powi(2) }).sum::<f64>() };
        let whole = band(0.0, 24000.0);
        println!("            bands 0-6, 6-12, 12-18, 18-24 kHz: {}", [(0.0, 6000.0), (6000.0, 12000.0), (12000.0, 18000.0), (18000.0, 24000.0)].iter().map(|&(lo, hi)| format!("{:.1}", 10.0 * (band(lo, hi) / whole).log10())).collect::<Vec<_>>().join(" "));
    }
}
