// The intonation models' comparison's measuring tool (docs/VOCAL_TRACT.md, "Intonation"), driven a line at a time on its
// standard input, each answered with one JSON line:
//   f0 RATE N, then N 32-bit floats  -> {"f0": [Hz every 10 ms, 0 unvoiced]} (VocalTractLab 2.4's estimator, src/yin.rs,
//                                       the samples read as 16-bit values, as it reads a file)
//   espeak VOICE TEXT                -> {"phones": [{"ipa", "start", "end", "text"}], "f0": [...]}: eSpeak NG's phones
//                                       and its own audio's F0, eSpeak's intonation as it sounds
//   cargo run --release --features espeak --example intonation
use musebots_vocaltract::espeak::{self, Event};
use musebots_vocaltract::yin::Yin;
use std::io::{BufRead, Read, Write};

fn json(s: &str) -> String {
    let mut o = String::from("\"");
    for c in s.chars() {
        match c {
            '"' => o += "\\\"",
            '\\' => o += "\\\\",
            c if (c as u32) < 0x20 => o += &format!("\\u{:04x}", c as u32),
            c => o.push(c),
        }
    }
    o + "\""
}

fn f0s(samples: &[f64], rate: f64) -> String {
    let f = Yin::new(rate).f0(samples);
    format!("[{}]", f.iter().map(|x| format!("{x:.2}")).collect::<Vec<_>>().join(","))
}

fn main() {
    let stdin = std::io::stdin();
    let mut input = stdin.lock();
    let stdout = std::io::stdout();
    let mut out = stdout.lock();
    let mut line = String::new();
    loop {
        line.clear();
        if input.read_line(&mut line).unwrap_or(0) == 0 {
            break;
        }
        let l = line.trim_end_matches('\n');
        let mut words = l.splitn(3, ' ');
        match words.next() {
            Some("f0") => {
                let rate: f64 = words.next().and_then(|x| x.parse().ok()).unwrap_or(16000.0);
                let n: usize = words.next().and_then(|x| x.parse().ok()).unwrap_or(0);
                let mut bytes = vec![0u8; 4 * n];
                input.read_exact(&mut bytes).expect("the samples");
                let samples: Vec<f64> = bytes.chunks_exact(4).map(|b| 32768.0 * f32::from_le_bytes(b.try_into().unwrap()) as f64).collect();
                writeln!(out, "{{\"f0\":{}}}", f0s(&samples, rate)).unwrap();
            }
            Some("espeak") => {
                let voice = words.next().unwrap_or("de");
                let text = words.next().unwrap_or("").replace('&', "&amp;").replace('<', "&lt;").replace('>', "&gt;");
                let doc = format!("<speak xml:lang=\"{voice}\">{text}</speak>");
                match espeak::spoken(&doc, voice, true) {
                    Ok((events, audio, rate)) => {
                        let raw: Vec<(String, i32, i32)> = events.iter().filter_map(|e| if let Event::Phone { ipa, ms, text } = e { Some((ipa.clone(), *ms, *text)) } else { None }).collect();
                        let last = events.iter().map(|e| match e { Event::Phone { ms, .. } | Event::Mark { ms, .. } | Event::Word { ms, .. } | Event::Sentence { ms } | Event::End { ms } => *ms }).max().unwrap_or(0);
                        let phones: Vec<String> = raw.iter().enumerate().map(|(k, (ipa, ms, t))| {
                            let end = raw.get(k + 1).map(|r| r.1).unwrap_or(last);
                            format!("{{\"ipa\":{},\"start\":{:.3},\"end\":{:.3},\"text\":{t}}}", json(ipa), *ms as f64 / 1000.0, end as f64 / 1000.0)
                        }).collect();
                        let samples: Vec<f64> = audio.iter().map(|x| *x as f64).collect();
                        writeln!(out, "{{\"phones\":[{}],\"f0\":{}}}", phones.join(","), f0s(&samples, rate as f64)).unwrap();
                    }
                    Err(e) => writeln!(out, "{{\"error\":{}}}", json(&e)).unwrap(),
                }
            }
            _ => writeln!(out, "{{\"error\":\"no such command\"}}").unwrap(),
        }
        out.flush().unwrap();
    }
}
