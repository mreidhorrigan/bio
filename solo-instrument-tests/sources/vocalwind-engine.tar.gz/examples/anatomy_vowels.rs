// Whether one speaker's tract given another's anatomy sounds like the other (the owner, 15 November 2026, design 2
// approved: the choir's singers laid on JD2 by VocalTractLab's own setFor, src/v24/anatomy.rs). The reference speaker's
// tract given the target's thirteen measures (anatomy::of, then set_for: every shape carried by adaptArticulation), and
// each vowel's resonances in the 2.4 engine (carry::resonances: the tube's glottis closed, an impulse of flow, the
// radiated flow's peaks) beside the target's own vowel and the reference's -- in cents from the target's own.
// Or the reference given its own measures but those named (key=value, as anatomy= takes them), beside its own vowels.
//   cargo run --release --example anatomy_vowels -- <reference.speaker> <target.speaker | key=value,...> [a,e,i,o,u]
use musebots_vocaltract::carry::resonances;
use musebots_vocaltract::v24::anatomy::{self, ANATOMY_PARAMS};
use musebots_vocaltract::v24::speaker::Speaker;
use musebots_vocaltract::v24::tract::VocalTract;

const TOP_HZ: f64 = 5000.0;

/// A shape's first four resonances on a tract, and the tube's length from glottis to lips (cm).
fn formants(tract: &mut VocalTract, name: &str) -> Option<(Vec<f64>, f64)> {
    let shape = tract.shape(name)?;
    tract.calculate(&shape);
    let tube = tract.tube();
    Some((resonances(&tube, TOP_HZ).into_iter().take(4).collect(), tube.length_cm.iter().sum()))
}

fn cents(a: f64, b: f64) -> f64 {
    1200.0 * (a / b).log2()
}

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    if args.len() < 2 {
        eprintln!("usage: anatomy_vowels <reference.speaker> <target.speaker | key=value,...> [a,e,i,o,u]");
        std::process::exit(2);
    }
    let reference = Speaker::read(&args[0]).expect("reference");
    // (A target named by measures is the reference itself, those measures changed: its "own" vowels the reference's.)
    let (target, x) = if args[1].contains('=') {
        let mut x = anatomy::of(&reference.tract);
        for kv in args[1].split(',') {
            let (k, v) = kv.split_once('=').expect("key=value");
            let i = ANATOMY_PARAMS.iter().position(|p| p.key == k).unwrap_or_else(|| panic!("no measure {k}"));
            x[i] = v.parse().expect("a number");
        }
        (Speaker::read(&args[0]).expect("reference"), x)
    } else {
        let target = Speaker::read(&args[1]).expect("target");
        let x = anatomy::of(&target.tract);
        (target, x)
    };
    let vowels: Vec<String> = args.get(2).map_or("a,e,i,o,u".into(), |s| s.clone()).split(',').map(String::from).collect();
    let mut made = reference.tract.clone();
    anatomy::set_for(&x, &mut made, &reference.tract);
    // (The measures: the reference's, the target's, and the made tract's as read back -- where set_for holds one in its
    // range, the last differs from the second.)
    let (rx, mx) = (anatomy::of(&reference.tract), anatomy::of(&made));
    println!("{:>24} {:>9} {:>9} {:>9}", "measure", "reference", "target", "made");
    for (k, p) in ANATOMY_PARAMS.iter().enumerate() {
        println!("{:>24} {:9.3} {:9.3} {:9.3}", p.key, rx[k], x[k], mx[k]);
    }
    let (mut own_tract, mut ref_tract) = (target.tract.clone(), reference.tract.clone());
    let mut all = Vec::new();
    for v in &vowels {
        let (Some((own, own_cm)), Some((m, m_cm)), Some((r, r_cm))) =
            (formants(&mut own_tract, v), formants(&mut made, v), formants(&mut ref_tract, v))
        else {
            println!("/{v}/: not a shape of both speakers");
            continue;
        };
        let line = |f: &[f64]| f.iter().map(|x| format!("{x:6.0}")).collect::<Vec<_>>().join("");
        let apart = |f: &[f64]| f.iter().zip(&own).map(|(a, b)| format!("{:+6.0}", cents(*a, *b))).collect::<Vec<_>>().join("");
        println!(
            "/{v}/ target {}   {own_cm:5.2} cm\n     made   {}   {m_cm:5.2} cm   cents {}\n     ref.   {}   {r_cm:5.2} cm   cents {}",
            line(&own),
            line(&m),
            apart(&m),
            line(&r),
            apart(&r)
        );
        all.extend(m.iter().zip(&own).map(|(a, b)| cents(*a, *b)));
    }
    let rms = (all.iter().map(|c| c * c).sum::<f64>() / all.len().max(1) as f64).sqrt();
    println!("made from the target's measures: {:.0} cents rms over {} resonances", rms, all.len());
}
