// Diagnosis (research/VOCAL_TRACT_PASSIVE_CORE.md): one vowel sung by VocalTractLab 2.4's network at 192 kHz and by
// VocalFork 3.0's acoustics at its own rate, stepped here as the synthesizer steps them, the glottis's flow and the
// mouth's written each step as raw 64-bit floats (`<folder>/<vowel>-{2.4,vocalfork}-{glottis,mouth}.f64`, with the rate
// in the name's companion `.rate`), for their spectra to be compared before radiation and decimation.
//   cargo run --release --example vocalfork_flows -- <speaker.speaker> <vowel> <folder> [steps for VocalFork]
use musebots_vocaltract::v24::glottis::PRESSURE;
use musebots_vocaltract::v24::passive::PassiveModel;
use musebots_vocaltract::v24::speaker::Speaker;
use musebots_vocaltract::v24::synth::{StepRecord, Synthesizer, NUM_CHUNK_SAMPLES};
use musebots_vocaltract::v24::tds::TdsModel;
use musebots_vocaltract::v24::tube::{Tube, FIRST_PHARYNX_SECTION, FIRST_TRACHEA_SECTION, LAST_TRACHEA_SECTION, LOWER_GLOTTIS_SECTION, UPPER_GLOTTIS_SECTION};

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let sp = Speaker::read(&args[0]).expect("speaker");
    let (vowel, dir) = (&args[1], &args[2]);
    let fork_steps: usize = args.get(3).and_then(|x| x.parse().ok()).unwrap_or(5);
    let mut tract = sp.tract.clone();
    tract.mended = true;
    let mut glottis = sp.glottis.clone();
    glottis.mended = true;
    let params = tract.shape(vowel).expect("a shape").to_vec();
    tract.calculate(&params);
    let mut tube = Tube::new();
    tube.set_from_tract(&tract.tube());
    let mut g: Vec<f64> = glottis.shapes.iter().find(|(n, _)| n == "modal").unwrap().1.clone();
    // (FORK_SNAP=1: the glottis held open, its folds still, then snapped shut at 0.3 s; each VocalFork step from then
    // printed until a value is not finite)
    let snap = std::env::var("FORK_SNAP").is_ok();
    // (FORK_F0=HZ, FORK_DPA=DPA: the pitch and the lung pressure in place of the modal shape's and 8,000 dPa;
    // FORK_GLOTTIS=INDEX=VALUE,...: the modal shape's controls by index -- 2 and 3 the folds' rest gap, 4 the chink)
    let dpa: f64 = std::env::var("FORK_DPA").ok().map_or(8000.0, |x| x.parse().expect("FORK_DPA"));
    if let Ok(f0) = std::env::var("FORK_F0") {
        g[0] = f0.parse().expect("FORK_F0");
    }
    for own in std::env::var("FORK_GLOTTIS").unwrap_or_default().split(',').filter(|x| !x.is_empty()) {
        let (k, v) = own.split_once('=').expect("INDEX=VALUE");
        g[k.parse::<usize>().expect("a control's index")] = v.parse().expect("a control's value");
    }
    if snap {
        g[2] = 0.2;
        g[3] = 0.2;
        g[4] = 0.15;
        g[6] = 0.0;
    }
    for (label, n, fork) in [("2.4", 4usize, false), ("vocalfork", fork_steps, true)] {
        let mut synth = Synthesizer::new(glottis.clone(), TdsModel::new());
        if fork {
            // (FORK_SWITCHES: VocalFork's physics' switches, as a renderer takes them -- walls, folds, reattachment, borda,
            // velocity, tract, noise, each =0|1: PassiveModel::take_switches; trachea=: layout_switches; its defaults
            // otherwise)
            let switches: Vec<String> = std::env::var("FORK_SWITCHES").unwrap_or_default().split_whitespace().map(String::from).collect();
            let mut options = synth.tds.options;
            PassiveModel::layout_switches(&mut options, &switches);
            let mut model = PassiveModel::new(&tube, options);
            model.take_switches(&switches);
            synth.use_vocalfork(model);
        }
        synth.set_oversampling(n);
        synth.stepper.tds.options = synth.tds.options;
        let mut record = StepRecord::default();
        let (mut gl, mut mo, mut tr, mut ar) = (Vec::new(), Vec::new(), Vec::<f64>::new(), Vec::<f64>::new());
        let mut prev: Vec<(String, f64, f64)> = Vec::new();
        let (mut reversals, mut last_change, mut stiffest, mut size) = (Vec::<usize>::new(), Vec::<f64>::new(), Vec::<f64>::new(), Vec::<f64>::new());
        let mut counted = 0usize;
        let chunks = (0.5 * 48000.0 / NUM_CHUNK_SAMPLES as f64) as usize;
        for c in 0..=chunks {
            let t = c as f64 * NUM_CHUNK_SAMPLES as f64 / 48000.0;
            g[1] = dpa * (1.0 - (-t / 0.012).exp());
            if snap && t >= 0.3 {
                g[2] = -0.2;
                g[3] = -0.2;
                g[4] = 0.0;
            }
            if c == 0 {
                synth.stepper.start(&tube, &g);
                continue;
            }
            for i in 0..NUM_CHUNK_SAMPLES * n {
                synth.stepper.step(i, NUM_CHUNK_SAMPLES * n, &tube, &g, &mut record);
                for (k, p) in synth.glottis.control.iter_mut().enumerate() {
                    p.x = record.glottis[k];
                }
                synth.glottis.calc_geometry();
                let (length, area) = synth.glottis.tube_data();
                if std::env::var("FORK_SAY").is_ok() && fork && c == 1 && i == 0 {
                    println!("  the glottis's controls at its first step: {:?}; statics {:?}; derived {:?}", synth.glottis.control.iter().map(|p| p.x).collect::<Vec<_>>(), synth.glottis.statics.iter().map(|p| p.x).collect::<Vec<_>>(), synth.glottis.derived);
                }
                ar.push(area[0].min(area[1]));
                if let Some(p) = synth.passive.as_mut() {
                    p.set_glottis_sections(&length, &area);
                    p.set_pressure_source(synth.glottis.control[PRESSURE].x, FIRST_TRACHEA_SECTION as i32);
                    let pressure = [p.section_pressure(LAST_TRACHEA_SECTION), p.section_pressure(LOWER_GLOTTIS_SECTION), p.section_pressure(UPPER_GLOTTIS_SECTION), p.section_pressure(FIRST_PHARYNX_SECTION)];
                    synth.glottis.inc_time(p.time_step, &pressure);
                    let r = p.proceed_time_step_with(&record.tube);
                    if snap && t >= 0.3 && t < 0.31 {
                        let bad = !(p.glottal_flow().is_finite() && pressure[3].is_finite() && area[0].is_finite());
                        if bad || i % 40 == 0 {
                            println!("  {:.6} s: glottal areas {:.3e} {:.3e}, lengths {:.3e} {:.3e}; flow {:.4e}; pressures below {:.4e} above {:.4e}; supraglottal (filtered) {:.4e}", t + i as f64 / (48000.0 * n as f64), area[0], area[1], length[0], length[1], p.glottal_flow(), pressure[0], pressure[3], synth.glottis.supraglottal_pressure());
                        }
                        if bad {
                            std::process::exit(0);
                        }
                    }
                    gl.push(p.glottal_flow());
                    mo.push(r.mouth);
                    // (FORK_EDGE: the edge recorded, by its name; else the trachea's top)
                    let wanted = std::env::var("FORK_EDGE").unwrap_or_else(|_| "section 22 flow node 1".into());
                    if let Some((_, _, u)) = p.edges_now().into_iter().find(|(w, _, _)| *w == wanted) {
                        tr.push(u);
                    }
                    // (the edges' reversals over the last tenth of a second: each edge's count of steps whose change
                    // reverses the last's, and its stiffness then)
                    if c * NUM_CHUNK_SAMPLES >= 19200 {
                        let now = p.edges_now();
                        if prev.len() == now.len() {
                            for (e, (_, stiff, u)) in now.iter().enumerate() {
                                let d = u - prev[e].2;
                                if d * last_change[e] < 0.0 {
                                    reversals[e] += 1;
                                }
                                last_change[e] = d;
                                stiffest[e] = stiffest[e].max(*stiff);
                                size[e] = size[e].max(d.abs());
                            }
                            counted += 1;
                        } else {
                            reversals = vec![0; now.len()];
                            last_change = vec![0.0; now.len()];
                            stiffest = vec![0.0; now.len()];
                            size = vec![0.0; now.len()];
                        }
                        prev = now;
                    }
                } else {
                    let tds = &mut synth.tds;
                    tds.set_glottis_sections(&length, &area);
                    tds.set_flow_source(0.0, -1);
                    tds.set_pressure_source(synth.glottis.control[PRESSURE].x, FIRST_TRACHEA_SECTION as i32);
                    let pressure = [tds.section_pressure(LAST_TRACHEA_SECTION), tds.section_pressure(LOWER_GLOTTIS_SECTION), tds.section_pressure(UPPER_GLOTTIS_SECTION), tds.section_pressure(FIRST_PHARYNX_SECTION)];
                    synth.glottis.inc_time(tds.time_step, &pressure);
                    let r = tds.proceed_time_step_with(&record.tube);
                    gl.push(tds.section_flow_out(UPPER_GLOTTIS_SECTION));
                    mo.push(r.mouth);
                }
            }
            synth.stepper.finish(&tube, &g);
        }
        let raw = |x: &[f64]| x.iter().flat_map(|v| v.to_le_bytes()).collect::<Vec<u8>>();
        std::fs::write(format!("{dir}/{vowel}-{label}-glottis.f64"), raw(&gl)).unwrap();
        std::fs::write(format!("{dir}/{vowel}-{label}-mouth.f64"), raw(&mo)).unwrap();
        std::fs::write(format!("{dir}/{vowel}-{label}.rate"), format!("{}", 48000 * n)).unwrap();
        std::fs::write(format!("{dir}/{vowel}-{label}-area.f64"), raw(&ar)).unwrap();
        if !tr.is_empty() {
            std::fs::write(format!("{dir}/{vowel}-{label}-trachea22.f64"), raw(&tr)).unwrap();
        }
        println!("{label}: {} steps at {} Hz", gl.len(), 48000 * n);
        if counted > 0 {
            let mut order: Vec<usize> = (0..reversals.len()).collect();
            order.sort_by(|a, b| (reversals[*b] as f64 * size[*b]).partial_cmp(&(reversals[*a] as f64 * size[*a])).unwrap());
            for &e in order.iter().take(12) {
                println!("  {}: reverses {:.0}% of steps, its largest change a step {:.3e} cm3/s, R dt / 2M at most {:.2}", prev[e].0, 100.0 * reversals[e] as f64 / counted as f64, size[e], stiffest[e]);
            }
        }
    }
}
