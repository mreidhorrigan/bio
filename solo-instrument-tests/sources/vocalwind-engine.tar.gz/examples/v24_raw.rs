// A passage's sound at 1, 2 and 4 steps a sample (or the counts given), written raw (little-endian f64) to
// <out>-<n>.f64: for comparing two builds of the crate byte for byte where 2.4 has no reference of its own
// (research/VOCAL_TRACT_REALTIME_PLAN.md, "How to run it"). The passage is a frames file (each line a frame's tract and
// glottis parameters, 120 samples apart, as reference/v24_gestural_parity.cpp writes them) or one of 2.4's .seg files
// (its score made by 2.4's rules). Synthesized frame by frame from the tract (Synthesizer::add_tract), all on one thread.
//   cargo run --release --example v24_raw -- JD2.speaker example01.seg out/example01 [1,2,4]
use musebots_vocaltract::segments::parse_segments;
use musebots_vocaltract::v24::gestural::GesturalScore;
use musebots_vocaltract::v24::speaker::Speaker;
use musebots_vocaltract::v24::synth::{Synthesizer, NUM_CHUNK_SAMPLES};
use musebots_vocaltract::v24::tds::TdsModel;
use musebots_vocaltract::v24::tract::NUM_PARAMS;

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let speaker = Speaker::read(&args[0]).expect("speaker");
    let text = std::fs::read_to_string(&args[1]).expect("frames or segments");
    let frames: Vec<(Vec<f64>, Vec<f64>)> = if args[1].ends_with(".seg") {
        let mut tract = speaker.tract.clone();
        let mut score = GesturalScore::test();
        score.from_segments(&parse_segments(&text), &mut tract);
        score.frames(&tract, &speaker.glottis)
    } else {
        text.lines()
            .map(|l| {
                let v: Vec<f64> = l.split_whitespace().map(|x| x.parse().unwrap()).collect();
                (v[..NUM_PARAMS].to_vec(), v[NUM_PARAMS..].to_vec())
            })
            .collect()
    };
    let rates: Vec<usize> = args.get(3).map(|s| s.split(',').map(|x| x.parse().unwrap()).collect()).unwrap_or(vec![1, 2, 4]);
    for n in rates {
        let mut synth = Synthesizer::new(speaker.glottis.clone(), TdsModel::new());
        synth.set_oversampling(n);
        let mut tract = speaker.tract.clone();
        let mut out = vec![0.0; (frames.len() - 1) * NUM_CHUNK_SAMPLES];
        for (f, (tp, gp)) in frames.iter().enumerate() {
            let span = if f == 0 { 0..0 } else { (f - 1) * NUM_CHUNK_SAMPLES..f * NUM_CHUNK_SAMPLES };
            synth.add_tract(&mut tract, tp, gp, &mut out[span]);
        }
        std::fs::write(format!("{}-{n}.f64", args[2]), out.iter().flat_map(|x| x.to_le_bytes()).collect::<Vec<u8>>()).expect("written");
    }
}
