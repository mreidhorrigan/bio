// The gestural scores VocalTractLab's segment rules make, 2.3's (src/segments.rs) and 2.4's (src/v24/segments.rs),
// each written as its .ges text, so that a change in how the rules are held -- their phones and constants read from
// languages/ (the owner, 15 November 2026: "moving constants and other hardcodings OUT of the Rust and into
// configuration files") -- is held to the same bytes: `diff -r` the folders written before and after. The inputs:
// VocalTractLab's own segment sequences (2.3's examples on JD3; 2.4's API and GUI examples on JD2, M01 and W02 in
// turn), the speech2vocaltract corpus's first sentences of each language (by 2.3's rules with the corpus's own, and by
// 2.4's on JD2), and the reader's SSML in German, English, Portuguese and Korean (eSpeak NG's phones by
// languages/ipa.json, both rule sets).
//   cargo run --release --features espeak --example rules_bytes -- <out folder> [sentences=N]
use musebots_vocaltract::gestural::GesturalScore;
use musebots_vocaltract::segments::{parse_segments, Segment};
use musebots_vocaltract::speech2vocaltract::Corpus;
use musebots_vocaltract::ssml::{self, Settings};
use musebots_vocaltract::tract::VocalTract;
use musebots_vocaltract::v24;
use std::path::{Path, PathBuf};

fn synthesis_home() -> PathBuf {
    PathBuf::from(musebots_vocaltract::blend::synthesis_home())
}

fn tract23(path: &Path) -> VocalTract {
    let speaker = musebots_vocaltract::speaker::Speaker::read(path.to_str().unwrap()).expect("2.3 speaker");
    VocalTract::from_xml(speaker.root.child("vocal_tract_model").expect("a vocal tract")).expect("2.3 anatomy")
}

fn tract24(id: &str) -> v24::tract::VocalTract {
    let file = synthesis_home().join("vocaltractlab-2.4").join(format!("{id}.speaker"));
    v24::speaker::Speaker::read(file.to_str().unwrap()).expect("2.4 speaker").tract
}

fn by23(segs: &[Segment], vt: &mut VocalTract) -> String {
    let mut score = GesturalScore::new();
    score.from_segments(segs, vt);
    score.to_xml()
}

fn by24(segs: &[Segment], vt: &mut v24::tract::VocalTract) -> String {
    let mut score = v24::gestural::GesturalScore::new();
    score.from_segments(segs, vt);
    score.to_xml()
}

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let out = PathBuf::from(args.first().expect("usage: rules_bytes <out folder> [sentences=N]"));
    let sentences: usize = args.iter().find_map(|a| a.strip_prefix("sentences=")).map_or(25, |n| n.parse().expect("sentences"));
    std::fs::create_dir_all(&out).expect("out folder");
    let write = |name: &str, text: &str| std::fs::write(out.join(name), text).expect("written");
    let home = synthesis_home();
    let mut jd3 = tract23(&home.join("vocaltractlab-src/resources/JD3.speaker"));
    let mut v24s: Vec<(&str, v24::tract::VocalTract)> = ["JD2", "M01", "W02"].iter().map(|id| (*id, tract24(id))).collect();
    let mut count = 0;
    // VocalTractLab's own sequences.
    let read_seg = |p: &Path| parse_segments(&std::fs::read_to_string(p).expect("seg"));
    let examples23 = home.join("vocaltractlab-src/examples");
    for f in sorted(&examples23, "seg") {
        write(&format!("vtl23-{}.ges", stem(&f)), &by23(&read_seg(&f), &mut jd3));
        count += 1;
    }
    let unpacked = home.join("vocaltractlab-2.4/unpacked");
    let mut list = sorted(&unpacked.join("API"), "seg");
    list.extend(sorted(&unpacked.join("GUI/Examples"), "seg"));
    for (k, f) in list.iter().enumerate() {
        let (id, vt) = &mut v24s[k % 3];
        write(&format!("vtl24-{id}-{}.ges", stem(f)), &by24(&read_seg(f), vt));
        count += 1;
    }
    // The corpus's sentences, as its authors' engine made them and as 2.4's rules make the same phones.
    let crate_dir = Path::new(env!("CARGO_MANIFEST_DIR"));
    let root = crate_dir.join("../../../research-downloads/voice/speech2vocaltract");
    match Corpus::open(&crate_dir.join("languages/speech2vocaltract.json"), &root) {
        Err(e) => eprintln!("rules_bytes: the corpus skipped: {e}"),
        Ok(corpus) => {
            let spec = &corpus.spec;
            let extra = spec.extra();
            for language in ["english", "korean", "portuguese"] {
                let Ok(lines) = corpus.transcriptions(language) else {
                    eprintln!("rules_bytes: {language} skipped");
                    continue;
                };
                for (index, (_, sampa)) in lines.iter().enumerate().take(sentences) {
                    let Ok(phones) = spec.phones(sampa) else { continue };
                    let made = spec.made_as(language, &phones).expect("made_as");
                    let segs = spec.segments(&made);
                    let mut score = GesturalScore::new();
                    score.from_segments_with(&segs, &mut jd3, &extra);
                    write(&format!("corpus23-{language}-{index:04}.ges"), &score.to_xml());
                    write(&format!("corpus24-{language}-{index:04}.ges"), &by24(&segs, &mut v24s[0].1));
                    count += 2;
                }
            }
        }
    }
    // The reader's SSML in four languages, by both rule sets.
    let settings = Settings { base_hz: 110.0, pitch_levels_st: [-6.0, -3.0, 0.0, 3.0, 6.0], volume_levels_db: [-12.0, -6.0, 0.0, 4.0, 8.0], f0_tau_s: 0.01, intonation: true };
    let docs = [
        ("de", "Die Apfelsine liegt im Schatten, und zwei kleine Vögel singen leise über der Brücke."),
        ("en-us", "The quick brown fox jumps over the lazy dog, while thirty singers rehearse a measured choral hymn."),
        ("en", "Whose voice is that, rising through the cathedral's vaulted ceiling at dawn?"),
        ("pt-br", "A canção do coração não termina; os pássaros cantam junto ao rio, longe da cidade."),
        ("ko", "아름다운 노래가 들려요. 우리는 함께 합창을 연습합니다."),
    ];
    for (lang, text) in docs {
        let doc = format!("<speak xml:lang=\"{lang}\">{text}</speak>");
        let reading = match ssml::read(&doc, &settings) {
            Ok(r) => r,
            Err(e) => {
                eprintln!("rules_bytes: {lang} unread: {e}");
                continue;
            }
        };
        for (k, (_, score)) in reading.scores(&settings, &mut jd3).expect("2.3 scores").iter().enumerate() {
            write(&format!("ssml23-{lang}-{k}.ges"), &score.to_xml());
            count += 1;
        }
        for (k, (_, score)) in reading.scores_v24(&settings, &mut v24s[0].1).expect("2.4 scores").iter().enumerate() {
            write(&format!("ssml24-{lang}-{k}.ges"), &score.to_xml());
            count += 1;
        }
    }
    println!("{count} scores written to {}", out.display());
}

fn sorted(dir: &Path, ext: &str) -> Vec<PathBuf> {
    let mut v: Vec<PathBuf> = std::fs::read_dir(dir).map(|r| r.filter_map(|e| e.ok().map(|e| e.path())).filter(|p| p.extension().is_some_and(|x| x == ext)).collect()).unwrap_or_default();
    v.sort();
    v
}

fn stem(p: &Path) -> String {
    p.file_stem().unwrap().to_string_lossy().into_owned()
}
