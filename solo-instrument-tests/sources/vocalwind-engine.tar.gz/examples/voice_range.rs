// A voice's range on VocalWind (the owner, 15 November 2026, of the singing dynamics design's fourth item, the voice's
// level over its range checked against measured singers': "Yes, as designed"): notes on /a/, modal, each held at a
// lung pressure, sung by the voice the dial and the musebot singer sing with (stream.rs LiveVoice::new_vocalwind:
// VocalFork's acoustics at the steps its network asks, 2.4's order; its speaker's glottis and tract mended, as the dial
// has them), each from rest, and each note's last half second measured: its level (RMS, dBFS), its pitch (`period`:
// VocalTractLab's YIN low-passes at 1 kHz, made for speech, and takes a soprano's top for a subharmonic) and its spectral
// balance (alpha: the level from 1 to 5 kHz less that from 50 Hz to 1 kHz, Hann-windowed, as Sundberg & Nordenberg 2006
// measure a voice's, doi:10.1121/1.2208451). Its notes are a
// file's lines, "<MIDI> <dPa>" (the range check, voice-range.mjs, writes them), or "<MIDI> <dPa> <relative amplitude>
// <phase lag> <pulse shape>", the modal shape's three set so (the fold fit, fold-fit.mjs); a line out for each, in their
// order: "<MIDI> <dPa> <dBFS> <Hz> <alpha dB> <times started again> <open quotient>" (the fifth: the stream's safety
// net, `LiveVoice::unstable`, over the whole note; the last: the share of the measured part's steps in which the folds
// were apart, Glottis2025::open_steps), sung `threads` at a time. Given a highest f0
// (Hz), the glottis takes pitches up to it where its own range (Geometric glottis 2025's, 40 to 600 Hz) holds every
// higher note at 600: what opening it would sing. Given engine=2.4, the notes are sung by 2.4's own acoustics at its
// own rate (LiveVoice::new24), its glottis taking the pressures and pitches VocalWind's takes: the fold fit's first,
// coarse pass, its last made on VocalWind. Given foldlaw=SPEAKER:WEIGHT,..., a note given no shape takes the fold law's
// at its pitch and pressure (design C, src/fold_law.rs): what a sung phrase's held modal vowel takes from it.
// For the source fit (source-fit.mjs, 17 November 2026): a line may go on, "... <pulse shape> <rest gap cm> <chink
// cm2>", the folds' rest gap (both edges' displacement at the vocal processes) and the chink set so; contact=CM, how
// softly the folds meet (Glottis2025::contact_cm); sung=K2:KPA0:KPA1:F0MEAN, a singer's open quotient by effort on
// its folds (Glottis2025::sung); vowel=NAME, the vowel sung where it is not /a/; the passive core's
// own switches as a render gives them (tissue=, noise=, losses=, radiation=); jitter=PERCENT, the glottis's static;
// and sound=FOLDER, each note's measured half second written there raw (<its line's number from 0>.f32, 48 kHz), for
// one measure to read the engine and a recorded singer alike (research/voice-listening/held-notes.mjs).
//   cargo run --release --example voice_range -- <speaker.speaker> <notes file> [threads] [highest f0] [engine=2.4] [foldlaw=...]
//     [sungfolds=SPEAKER:WEIGHT,...: the sung folds' law for each note given no shape] [contact=CM] [sung=K2:KPA0:KPA1:F0MEAN] [vowel=NAME] [tissue=...] [noise=0] [jitter=PERCENT] [sound=FOLDER]
//     [ventricle=VOLUME_CM3] [fossa=LENGTH_CM,VOLUME_CM3]
use musebots_vocaltract::stream::LiveVoice;
use musebots_vocaltract::v24::glottis::{CHINK_AREA, FREQUENCY, JITTER, LOWER_END_X, PHASE_LAG, PRESSURE, PULSE_SHAPE, RELATIVE_AMPLITUDE, UPPER_END_X};
use musebots_vocaltract::v24::speaker::Speaker;
use musebots_vocaltract::v24::tds::Solver;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Mutex;

const RATE: f64 = 48000.0;
/// Each note's length, and its last part measured (s): the breath and the pitch long settled.
const HELD_S: f64 = 1.2;
const MEASURED_S: f64 = 0.5;

/// A band's power by the DFT of the windowed signal, bin by bin (Goertzel), from `lo` to `hi` Hz.
fn band_power(x: &[f64], lo: f64, hi: f64) -> f64 {
    let n = x.len();
    let step = RATE / n as f64;
    let mut sum = 0.0;
    let mut k = (lo / step).ceil() as usize;
    while (k as f64) * step < hi {
        let w = 2.0 * std::f64::consts::PI * k as f64 / n as f64;
        let c = 2.0 * w.cos();
        let (mut s1, mut s2) = (0.0, 0.0);
        for v in x {
            let s0 = v + c * s1 - s2;
            s2 = s1;
            s1 = s0;
        }
        sum += s1 * s1 + s2 * s2 - c * s1 * s2;
        k += 1;
    }
    sum
}

/// A held note's pitch (Hz; 0 where nothing repeats): of the periods from 2 kHz to 50 Hz, the shortest whose normalized
/// autocorrelation is within a tenth of the best (as the render audit's `sounding` takes it: an octave below is as
/// periodic), refined by a parabola through its neighbours; none where the best is under a half.
fn period(x: &[f64]) -> f64 {
    let (shortest, longest) = ((RATE / 2000.0) as usize, (RATE / 50.0) as usize);
    let r: Vec<f64> = (0..=longest + 1)
        .map(|lag| {
            let (a, b) = (&x[..x.len() - lag], &x[lag..]);
            let ab: f64 = a.iter().zip(b).map(|(p, q)| p * q).sum();
            let (aa, bb): (f64, f64) = (a.iter().map(|p| p * p).sum(), b.iter().map(|q| q * q).sum());
            ab / (aa * bb).sqrt().max(1e-30)
        })
        .collect();
    let best = (shortest..=longest).map(|lag| r[lag]).fold(f64::MIN, f64::max);
    if best < 0.5 {
        return 0.0;
    }
    // (none where the best is a slope at the longest period's end: nothing repeats within the range read)
    let Some(lag) = (shortest..=longest).find(|&lag| r[lag] >= 0.9 * best && r[lag] >= r[lag - 1] && r[lag] >= r[lag + 1]) else {
        return 0.0;
    };
    let (before, at, after) = (r[lag - 1], r[lag], r[lag + 1]);
    let shift = 0.5 * (before - after) / (before - 2.0 * at + after).min(-1e-30);
    RATE / (lag as f64 + shift)
}

/// A note: its pitch (MIDI), its lung pressure (dPa), the modal shape's relative amplitude, phase lag and pulse
/// shape where they are set, and its folds' rest gap (cm) and chink (cm2) where they are.
struct Note {
    midi: f64,
    dpa: f64,
    shape: Option<[f64; 3]>,
    folds: Option<[f64; 2]>,
}

/// How every note is sung beyond its own line: the folds' contact softness (cm), the vowel, the passive core's
/// switches, the glottis's jitter where it is set, and where each note's measured part is written.
struct Sung {
    contact_cm: f64,
    folds: Option<musebots_vocaltract::v24::glottis::SungFolds>,
    vowel: String,
    switches: Vec<String>,
    jitter: Option<f64>,
    sound: Option<String>,
}

fn sung(speaker: &Speaker, note: &Note, highest_hz: Option<f64>, own: bool, how: &Sung, index: usize) -> (f64, f64, f64, u32, f64) {
    let mut glottis = speaker.glottis.clone();
    if let Some(hz) = highest_hz {
        glottis.control[FREQUENCY].max = hz;
    }
    let mut voice = if own {
        glottis.control[PRESSURE].max = f64::INFINITY;
        if highest_hz.is_none() {
            glottis.control[FREQUENCY].max = f64::INFINITY;
        }
        LiveVoice::new24(speaker.tract.clone(), glottis, 1, Solver::Envelope, 1, 4)
    } else {
        LiveVoice::new_vocalwind(speaker.tract.clone(), glottis, &how.switches, 1, Solver::Envelope, 1, 4)
    };
    voice.set_contact(how.contact_cm);
    voice.set_sung_folds(how.folds);
    if let Some(percent) = how.jitter {
        voice.set_static(JITTER, Some(percent));
    }
    voice.controls.vowel = how.vowel.clone();
    voice.controls.glottis = "modal".into();
    if let Some([gap, chink]) = note.folds {
        voice.controls.glottis_values[LOWER_END_X] = Some(gap);
        voice.controls.glottis_values[UPPER_END_X] = Some(gap);
        voice.controls.glottis_values[CHINK_AREA] = Some(chink);
    }
    if let Some(s) = note.shape {
        for (j, v) in [RELATIVE_AMPLITUDE, PHASE_LAG, PULSE_SHAPE].into_iter().zip(s) {
            voice.controls.glottis_values[j] = Some(v);
        }
    }
    voice.controls.pitch = note.midi;
    voice.controls.pressure_dpa = note.dpa;
    voice.controls.sounding = true;
    let mut held = voice.pull(((HELD_S - MEASURED_S) * RATE) as usize);
    voice.glottis24().expect("2.4's glottis").open_steps = (0, 0);
    held.extend(voice.pull((MEASURED_S * RATE) as usize));
    let (steps, open) = voice.glottis24().expect("2.4's glottis").open_steps;
    let open_quotient = open as f64 / steps.max(1) as f64;
    let tail: Vec<f64> = held[held.len() - (MEASURED_S * RATE) as usize..].iter().map(|v| *v as f64).collect();
    if let Some(folder) = &how.sound {
        let bytes: Vec<u8> = tail.iter().flat_map(|v| (*v as f32).to_le_bytes()).collect();
        std::fs::write(format!("{folder}/{index}.f32"), bytes).expect("the note's sound");
    }
    let level = 10.0 * (tail.iter().map(|v| v * v).sum::<f64>() / tail.len() as f64 + 1e-30).log10();
    let f0 = period(&tail);
    let n = tail.len();
    let windowed: Vec<f64> = tail.iter().enumerate().map(|(i, v)| v * 0.5 * (1.0 - (2.0 * std::f64::consts::PI * i as f64 / (n - 1) as f64).cos())).collect();
    let alpha = 10.0 * ((band_power(&windowed, 1000.0, 5000.0) + 1e-30) / (band_power(&windowed, 50.0, 1000.0) + 1e-30)).log10();
    (level, f0, alpha, voice.unstable.0, open_quotient)
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    if args.len() < 3 {
        eprintln!("voice_range <speaker.speaker> <notes file> [threads] [highest f0] [engine=2.4] [foldlaw=SPEAKER:WEIGHT,...]");
        std::process::exit(2);
    }
    let mut speaker = Speaker::read(&args[1]).unwrap_or_else(|e| panic!("{}: {e}", args[1]));
    speaker.tract.mended = true;
    // (ventricle=VOLUME_CM3 and fossa=LENGTH_CM,VOLUME_CM3: the larynx's ventricle and the piriform fossa laid as
    // vtl-stream lays them, for the ventricle's fit, ventricle-fit.mjs.)
    if let Some(v) = args.iter().find_map(|a| a.strip_prefix("ventricle=")) {
        speaker.tract.anatomy.ventricle_cm3 = v.parse().unwrap_or_else(|_| panic!("ventricle=VOLUME_CM3"));
    }
    if let Some(v) = args.iter().find_map(|a| a.strip_prefix("fossa=")) {
        let v: Vec<f64> = v.split(',').map(|x| x.parse().unwrap_or_else(|_| panic!("fossa=LENGTH_CM,VOLUME_CM3"))).collect();
        speaker.tract.anatomy.piriform_fossa_length_cm = v[0];
        speaker.tract.anatomy.piriform_fossa_volume_cm3 = v[1];
    }
    speaker.glottis.mended = true;
    let notes: Vec<Note> = std::fs::read_to_string(&args[2])
        .unwrap_or_else(|e| panic!("{}: {e}", args[2]))
        .lines()
        .filter(|l| !l.trim().is_empty())
        .map(|l| {
            let v: Vec<f64> = l.split_whitespace().map(|x| x.parse().unwrap_or_else(|_| panic!("a note: <MIDI> <dPa> [<relative amplitude> <phase lag> <pulse shape>], not '{l}'"))).collect();
            match v.len() {
                2 => Note { midi: v[0], dpa: v[1], shape: None, folds: None },
                5 => Note { midi: v[0], dpa: v[1], shape: Some([v[2], v[3], v[4]]), folds: None },
                7 => Note { midi: v[0], dpa: v[1], shape: Some([v[2], v[3], v[4]]), folds: Some([v[5], v[6]]) },
                _ => panic!("a note: <MIDI> <dPa> [<relative amplitude> <phase lag> <pulse shape> [<rest gap> <chink>]], not '{l}'"),
            }
        })
        .collect();
    let own = args[3..].iter().any(|a| a == "engine=2.4");
    // (The fold law's shape for each note given none, where asked.)
    let law = args[3..].iter().find_map(|a| a.strip_prefix("foldlaw=")).map(|w| musebots_vocaltract::fold_law::FoldLaw::read(w).unwrap_or_else(|e| panic!("{e}")));
    // (Or the sung folds' law, sungfolds=SPEAKER:WEIGHT,... (voices/sung-folds.json): each note given no shape its
    // four controls and the speaker's sung gap, the glottis its contact softness and open quotient's law.)
    let sung_law = args[3..].iter().find_map(|a| a.strip_prefix("sungfolds=")).map(|w| musebots_vocaltract::fold_law::FoldLaw::read_sung(w).unwrap_or_else(|e| panic!("{e}")));
    let sung_folds = sung_law.as_ref().and_then(|l| l.sung());
    let notes: Vec<Note> = notes
        .into_iter()
        .map(|n| match (&sung_law, &law, n.shape) {
            (Some(law), _, None) => {
                let v = law.at4(440.0 * 2f64.powf((n.midi - 69.0) / 12.0), n.dpa);
                Note { shape: Some([v[0], v[1], v[2]]), folds: Some([sung_folds.expect("the sung folds'").0, v[3]]), ..n }
            }
            (None, Some(law), None) => Note { shape: Some(law.at(440.0 * 2f64.powf((n.midi - 69.0) / 12.0), n.dpa)), ..n },
            _ => n,
        })
        .collect();
    let asked = |k: &str| args[3..].iter().find_map(|a| a.strip_prefix(&format!("{k}=")));
    let how = Sung {
        contact_cm: asked("contact").map_or(sung_folds.map_or(0.0, |s| s.1), |c| c.parse().expect("contact=CM")),
        folds: asked("sung")
            .map(|law| {
                let v: Vec<f64> = law.split(':').map(|x| x.parse().expect("sung=K2:KPA0:KPA1:F0MEAN")).collect();
                musebots_vocaltract::v24::glottis::SungFolds { k2: v[0], kpa: [v[1], v[2]], f0_mean_hz: v[3], gap_cm: 0.0 }
            })
            .or(sung_folds.map(|s| s.2)),
        vowel: asked("vowel").unwrap_or("a").to_string(),
        switches: args[3..].iter().filter(|a| ["tissue=", "noise=", "losses=", "radiation="].iter().any(|k| a.starts_with(k))).cloned().collect(),
        jitter: asked("jitter").map(|j| j.parse().expect("jitter=PERCENT")),
        sound: asked("sound").map(str::to_string),
    };
    if let Some(folder) = &how.sound {
        std::fs::create_dir_all(folder).expect("the sound's folder");
    }
    let positional: Vec<&String> = args[3..].iter().filter(|a| !a.contains('=')).collect();
    let threads: usize = positional.first().map(|t| t.parse().expect("threads: a number")).unwrap_or(1).max(1);
    let highest_hz: Option<f64> = positional.get(1).map(|h| h.parse().expect("the highest f0: Hz"));
    let next = AtomicUsize::new(0);
    let out = Mutex::new(vec![None; notes.len()]);
    std::thread::scope(|s| {
        for _ in 0..threads.min(notes.len()) {
            s.spawn(|| loop {
                let k = next.fetch_add(1, Ordering::Relaxed);
                if k >= notes.len() {
                    break;
                }
                let made = sung(&speaker, &notes[k], highest_hz, own, &how, k);
                out.lock().unwrap()[k] = Some(made);
            });
        }
    });
    for (note, made) in notes.iter().zip(out.into_inner().unwrap()) {
        let (level, f0, alpha, unstable, open_quotient) = made.unwrap();
        println!("{} {:.0} {level:.2} {f0:.2} {alpha:.2} {unstable} {open_quotient:.4}", note.midi, note.dpa);
    }
}
