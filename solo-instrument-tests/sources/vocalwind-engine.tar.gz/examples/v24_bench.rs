// What VocalTractLab 2.4 costs, part by part, counted by the processor (src/counters.rs: the instructions and cycles
// the measuring thread ran, by kind of core -- what a shared machine's load does not move). A passage's frames (each its
// tract's and glottis's parameters, 120 samples of 48 kHz apart, as reference/v24_gestural_parity.cpp writes them; or
// one of 2.4's .seg files, its score made by 2.4's rules, src/v24/segments.rs, and read every 120 samples), its first
// `seconds` (repeated where shorter): its geometry (VocalTract::calculateAll and the tube laid from it) a frame; then its
// acoustics a step at 1, 2 and 4 steps a sample -- the glottis, the tube's interpolation and the time-domain simulation
// together, the bringing back to 48 kHz and the radiation -- each in instructions and in cycles on a performance core,
// the time those take at its clock as measured, and that against the step's share of real time. With `pool`, the whole
// synthesis with its geometry on 1, 2 and 3 other threads (live::render_v24), and with the frames' part of each step on
// a thread of its own besides (src/v24/pipeline.rs), each held to the sequential synthesis's sound to the bit, its
// acoustics' thread counted. With `tree`, each step's system solved in the tube's own order (src/v24/
// solve.rs) where 2.4's is the default.
//   cargo run --release --example v24_bench -- JD2.speaker GUI/example01.seg [seconds] [rates] [pool] [pipeline] [tree]
//   cargo run --release --example v24_bench -- JD2.speaker frames.txt 1 4
use musebots_vocaltract::counters::Counts;
use musebots_vocaltract::live;
use musebots_vocaltract::segments::parse_segments;
use musebots_vocaltract::v24::gestural::GesturalScore;
use musebots_vocaltract::v24::pipeline;
use musebots_vocaltract::v24::speaker::Speaker;
use musebots_vocaltract::v24::synth::{Synthesizer, NUM_CHUNK_SAMPLES};
use musebots_vocaltract::v24::tds::{Solver, TdsModel};
use musebots_vocaltract::v24::tract::NUM_PARAMS;
use musebots_vocaltract::v24::tube::Tube;
use std::time::Instant;

fn main() {
    // (Counted where a live voice runs: on the performance cores.)
    musebots_vocaltract::counters::prefer_performance_cores();
    let args: Vec<String> = std::env::args().skip(1).collect();
    let speaker = Speaker::read(&args[0]).expect("speaker");
    let seconds: f64 = args.get(2).and_then(|s| s.parse().ok()).unwrap_or(1.0);
    let rates: Vec<usize> = args.get(3).map(|s| s.split(',').map(|x| x.parse().unwrap()).collect()).unwrap_or(vec![1, 2, 4]);
    let pool = args.iter().any(|a| a == "pool");
    let solver = if args.iter().any(|a| a == "tree") { Solver::Tree } else { Solver::Envelope };
    let text = std::fs::read_to_string(&args[1]).expect("frames or segments");
    let lines: Vec<(Vec<f64>, Vec<f64>)> = if args[1].ends_with(".seg") {
        let mut tract = speaker.tract.clone();
        let mut score = GesturalScore::test();
        score.from_segments(&parse_segments(&text), &mut tract);
        score.frames(&tract, &speaker.glottis)
    } else {
        text.lines()
            .map(|l| {
                let v: Vec<f64> = l.split_whitespace().map(|x| x.parse().unwrap()).collect();
                (v[..NUM_PARAMS].to_vec(), v[NUM_PARAMS..].to_vec())
            })
            .collect()
    };
    let want = (seconds * 48000.0 / NUM_CHUNK_SAMPLES as f64).ceil() as usize + 1;
    let frames: Vec<(Vec<f64>, Vec<f64>)> = lines.iter().cycle().take(want).cloned().collect();
    let audio_s = (frames.len() - 1) as f64 * NUM_CHUNK_SAMPLES as f64 / 48000.0;
    let mut tract = speaker.tract.clone();
    let c0 = Counts::now();
    let mut unfound = 0;
    let tubes: Vec<Tube> = frames
        .iter()
        .map(|(tp, _)| {
            tract.calculate(tp);
            let made = tract.tube();
            unfound += !made.incisor_found as usize;
            let mut t = Tube::new();
            t.set_from_tract(&made);
            t
        })
        .collect();
    let Some(c0) = c0 else {
        println!("v24_bench: this system counts no instructions or cycles (src/counters.rs: macOS alone)");
        return;
    };
    let geometry = Counts::now().unwrap().since(&c0);
    let clock = geometry.clock_hz(0);
    println!("v24_bench: {audio_s:.2} s of audio, {} frames ({unfound} finding no incisors)", frames.len());
    println!("v24_bench: geometry: {}", geometry.report(frames.len() as f64, "frame", clock));
    if let (Some(cycles), Some(clock)) = (geometry.performance_cycles(), clock) {
        println!("v24_bench:   so {:.2} times real time on one performance core", audio_s / (cycles / clock));
    }
    for &n in &rates {
        let mut synth = Synthesizer::new(speaker.glottis.clone(), TdsModel::new());
        synth.tds.options.solver = solver;
        synth.set_oversampling(n);
        let mut buffer = vec![0.0; NUM_CHUNK_SAMPLES];
        let mut sum = 0.0;
        let c0 = Counts::now().unwrap();
        for (f, ((_, gp), tube)) in frames.iter().zip(&tubes).enumerate() {
            let k = if f == 0 { 0 } else { NUM_CHUNK_SAMPLES };
            synth.add_tube(gp, tube, &mut buffer[..k]);
            sum += buffer[..k].iter().map(|x| x * x).sum::<f64>();
        }
        let c = Counts::now().unwrap().since(&c0);
        let steps = audio_s * 48000.0 * n as f64;
        println!(
            "v24_bench: acoustics at {:>3} kHz: {}; rms {:.4e}; sections' coefficients kept {:.1}%",
            48 * n,
            c.report(steps, "step", clock),
            (sum / (audio_s * 48000.0)).sqrt(),
            100.0 * synth.stepper.tds.cache_hits as f64 / (synth.stepper.tds.cache_hits + synth.stepper.tds.cache_misses).max(1) as f64
        );
        if let (Some(cycles), Some(clock)) = (c.performance_cycles(), clock.or(c.clock_hz(0))) {
            println!("v24_bench:   so {:.2} times real time on one performance core", audio_s / (cycles / clock));
        }
    }
    // (`pipeline`: the frames' part on its own thread alone, its acoustics' thread counted -- quick, not compared.)
    if args.iter().any(|a| a == "pipeline") {
        for &n in &rates {
            let mut synth = Synthesizer::new(speaker.glottis.clone(), TdsModel::new());
            synth.tds.options.solver = solver;
            synth.set_oversampling(n);
            let c0 = Counts::now().unwrap();
            pipeline::render(&speaker.tract, &mut synth, &frames, 2, 8);
            let c = Counts::now().unwrap().since(&c0);
            println!("v24_bench: {:>3} kHz, the frames' part on its own thread, geometry on 2: the acoustics' thread {}", 48 * n, c.report(audio_s * 48000.0 * n as f64, "step", clock));
        }
    }
    if !pool {
        return;
    }
    for &n in &rates {
        let sequential = {
            let mut synth = Synthesizer::new(speaker.glottis.clone(), TdsModel::new());
            synth.set_oversampling(n);
            let mut tract = speaker.tract.clone();
            let mut out = vec![0.0; (frames.len() - 1) * NUM_CHUNK_SAMPLES];
            for (f, (tp, gp)) in frames.iter().enumerate() {
                let span = if f == 0 { 0..0 } else { (f - 1) * NUM_CHUNK_SAMPLES..f * NUM_CHUNK_SAMPLES };
                synth.add_tract(&mut tract, tp, gp, &mut out[span]);
            }
            out
        };
        for workers in 1..=3 {
            let mut synth = Synthesizer::new(speaker.glottis.clone(), TdsModel::new());
            synth.set_oversampling(n);
            let (t0, c0) = (Instant::now(), Counts::now().unwrap());
            let out = live::render_v24(&speaker.tract, &mut synth, &frames, workers, 8);
            let (wall, c) = (t0.elapsed().as_secs_f64(), Counts::now().unwrap().since(&c0));
            let same = out.len() == sequential.len() && out.iter().zip(&sequential).all(|(a, b)| a.to_bits() == b.to_bits());
            println!(
                "v24_bench: {:>3} kHz, geometry on {workers} other thread(s): {}; the acoustics' thread {}; {:.2} times real time by the clock on the wall",
                48 * n,
                if same { "the sequential sound to the bit" } else { "NOT the sequential sound" },
                c.report(audio_s * 48000.0 * n as f64, "step", clock),
                audio_s / wall
            );
        }
        for workers in 1..=2 {
            let mut synth = Synthesizer::new(speaker.glottis.clone(), TdsModel::new());
            synth.tds.options.solver = solver;
            synth.set_oversampling(n);
            let (t0, c0) = (Instant::now(), Counts::now().unwrap());
            let out = pipeline::render(&speaker.tract, &mut synth, &frames, workers, 8);
            let (wall, c) = (t0.elapsed().as_secs_f64(), Counts::now().unwrap().since(&c0));
            let same = out.len() == sequential.len() && out.iter().zip(&sequential).all(|(a, b)| a.to_bits() == b.to_bits());
            println!(
                "v24_bench: {:>3} kHz, the frames' part on its own thread, geometry on {workers}: {}; the acoustics' thread {}; {:.2} times real time by the clock on the wall",
                48 * n,
                if solver != Solver::Envelope {
                    "(the tree's order)"
                } else if same {
                    "the sequential sound to the bit"
                } else {
                    "NOT the sequential sound"
                },
                c.report(audio_s * 48000.0 * n as f64, "step", clock),
                audio_s / wall
            );
        }
    }
}
