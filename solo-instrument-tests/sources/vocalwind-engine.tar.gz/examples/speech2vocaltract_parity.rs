// Whether the speech2vocaltract corpus (src/speech2vocaltract.rs) is what this port of VocalTractLab 2.3 makes of the
// same phones: each sentence whose phones are all the speaker's own (none the authors added or redefined) made a segment
// sequence -- a pause of `lead` seconds (none, as the corpus was made), then each phone its 0.1 s -- and a gestural score
// by VocalTractLab's rules, its
// states written as VocalTractLab writes a tract sequence (every 110 samples, two more than the score's length holds),
// every eighth kept, and each kept parameter compared with the corpus's. What agrees says how the authors made it (the
// engine, the speaker, the lead), and that the corpus's frames can be read through this engine. Only the speaker's vocal
// tract is read (2.3's own JD2 has a glottis the port's geometric glottis does not read): the tract's parameters are the
// same whatever the glottis.
//   cargo run --release --example speech2vocaltract_parity -- JD3.speaker languages/speech2vocaltract.json \
//     <research-downloads/voice/speech2vocaltract> english [sentences=40] [lead=0] [tail=0] [show=N]
// (with=added takes sentences with the phones the authors added too, where the spec says how each was made; show=N compares sentence N alone and prints its frames, the port's above the corpus's; start=<found.json> puts a found speaker's shapes in.)
// (has=<phone> only sentences with it, as their lines write it; only=<file> only the sentences it lists, a line "<language> <index>" each, as each= writes them; as=<phone>:<other> each of the one made as the other; each=<file> appends each sentence's rms; with show=N, seg=<file> writes its segment sequence for VocalTractLab's own engine and dump=<file> its frames and the corpus's, every digit.) 14 November 2026, on JD3 and on 2.3's JD2 alike:
// the frames as many as the corpus's in 40 of 40 sentences of English and of Portuguese; equal to the printed digits
// where a shape is the speaker's own, not at /i:/ (research/VOCALWIND_LANGUAGES.md).
use musebots_vocaltract::gestural::GesturalScore;
use musebots_vocaltract::glottis::GeometricGlottis;
use musebots_vocaltract::segments::{self, Segment};
use musebots_vocaltract::speech2vocaltract::Corpus;
use musebots_vocaltract::tract::VocalTract;
use std::path::Path;

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    if args.len() < 4 {
        eprintln!("usage: speech2vocaltract_parity <speaker> <spec.json> <corpus folder> <language> [sentences=N] [lead=s] [tail=s]");
        std::process::exit(2);
    }
    let setting = |key: &str, default: f64| args[4..].iter().find_map(|a| a.strip_prefix(&format!("{key}="))).filter(|_| key != "start").map(|v| v.parse::<f64>().expect(key)).unwrap_or(default);
    let (wanted, lead, tail) = (setting("sentences", 40.0) as usize, setting("lead", 0.0), setting("tail", 0.0));
    let show = setting("show", -1.0);
    let root = musebots_vocaltract::xml::parse(&std::fs::read_to_string(&args[0]).expect("speaker")).expect("speaker");
    let mut tract = VocalTract::from_xml(root.child("vocal_tract_model").expect("vocal tract")).expect("anatomy");
    let glottis = GeometricGlottis::new();
    if let Some(found) = args[4..].iter().find_map(|a| a.strip_prefix("start=")) {
        musebots_vocaltract::speech2vocaltract::FoundSpeaker::read(Path::new(found)).expect("found").apply(&mut tract).expect("found");
    }
    let corpus = Corpus::open(Path::new(&args[1]), Path::new(&args[2])).expect("corpus");
    let spec = &corpus.spec;
    let language = &args[3];
    let neutral: Vec<f64> = glottis.control.iter().map(|p| p.neutral).collect();
    let kept = spec.param_indices();
    // (The authors' rules where they are not the release's: languages/speech2vocaltract.json "rules".)
    let extra = spec.extra();
    let added = args[4..].iter().any(|a| a == "with=added");
    // (only=<file>: the sentences of this language it lists, each line "<language> <index> ...".)
    let only: Option<std::collections::BTreeSet<usize>> = args[4..].iter().find_map(|a| a.strip_prefix("only=")).map(|file| {
        std::fs::read_to_string(file).expect("only").lines().filter_map(|l| {
            let mut w = l.split_whitespace();
            (w.next() == Some(language.as_str())).then(|| w.next().and_then(|i| i.parse().ok())).flatten()
        }).collect()
    });
    let (mut compared, mut counts_same, mut sum2, mut n2) = (0, 0, vec![0.0; kept.len()], 0usize);
    let mut largest = vec![(0.0f64, 0usize, 0usize); kept.len()];
    for (index, (_, sampa)) in corpus.transcriptions(language).expect("transcriptions").into_iter().enumerate() {
        if compared == wanted || (show >= 0.0 && index as f64 > show) {
            break;
        }
        if show >= 0.0 && (index as f64) < show {
            continue;
        }
        if only.as_ref().is_some_and(|o| !o.contains(&index)) {
            continue;
        }
        // (A few lines are not phones -- "~,_~", "i::": research/VOCALWIND_LANGUAGES.md.)
        let Ok(phones) = spec.phones(&sampa) else { continue };
        // (Phones the authors added only where the spec says how they were made -- a pause, a plosive's onset time, a
        // vowel's shape the tract has -- and only with=added.)
        let made = |p: &String| match spec.symbol(p) {
            None => segments::is_phoneme(p),
            Some(s) => added && (s.pause || extra.plosive(p).is_some() || extra.vowel_shape(p).is_some_and(|v| tract.shape(v).is_some())),
        };
        if !phones.iter().all(made) {
            continue;
        }
        // (has=<phone>: only sentences with that phone.)
        if let Some(h) = args[4..].iter().find_map(|a| a.strip_prefix("has=")) {
            if !phones.iter().any(|p| p == h) {
                continue;
            }
        }
        // (The phones as the authors' engine made them; as=<phone>:<other> besides, each of the one made as the other, to
        // see which the corpus's frames are.)
        let phones = spec.made_as(language, &phones).expect("language");
        let phones: Vec<String> = match args[4..].iter().find_map(|a| a.strip_prefix("as=")).and_then(|a| a.split_once(':')) {
            Some((from, to)) => phones.into_iter().map(|p| if p == from { to.to_string() } else { p }).collect(),
            None => phones,
        };
        let mut segs = vec![Segment { name: String::new(), duration_s: lead, labels: Vec::new() }];
        segs.extend(phones.iter().map(|p| Segment { name: p.clone(), duration_s: spec.phone_s * spec.units(p) as f64, labels: Vec::new() }));
        if tail > 0.0 {
            segs.push(Segment { name: String::new(), duration_s: tail, labels: Vec::new() });
        }
        // (seg=<file> with show=N: the sentence's segment sequence written as VocalTractLab reads one, for its own engine.)
        if let Some(file) = args[4..].iter().find_map(|a| a.strip_prefix("seg=")).filter(|_| index as f64 == show) {
            let text: String = segs.iter().map(|s| format!("name = {}; duration_s = {:.6};\n", s.name, s.duration_s)).collect();
            std::fs::write(file, text).expect("seg");
        }
        let mut score = GesturalScore::new();
        score.from_segments_with(&segs, &mut tract, &extra);
        let states = score.frames(&tract, &glottis.shapes, &neutral);
        let ours: Vec<&Vec<f64>> = states.iter().step_by(spec.frames.kept_every).map(|(t, _)| t).collect();
        // (The fits' reader of the same frames: every number the same.)
        let lean = score.tract_frames(&tract, spec.frames.kept_every);
        assert!(lean.len() == ours.len() && lean.iter().zip(&ours).all(|(a, b)| a.iter().zip(b.iter()).all(|(x, y)| x.to_bits() == y.to_bits())), "tract_frames differs from frames");
        let theirs = corpus.frames(language, index).expect("frames");
        compared += 1;
        if ours.len() == theirs.len() {
            counts_same += 1;
        }
        // (each=<file>: a line a sentence, its rms over every kept parameter and frame, and its phones.)
        if let Some(file) = args[4..].iter().find_map(|a| a.strip_prefix("each=")) {
            let (s2, n): (f64, usize) = ours.iter().zip(&theirs).flat_map(|(a, b)| kept.iter().zip(b.iter()).map(move |(&k, &y)| (a[k] - y).powi(2))).fold((0.0, 0), |(s, n), d| (s + d, n + 1));
            let line = format!("{language} {index} {:e} {}\n", (s2 / n.max(1) as f64).sqrt(), phones.join(" "));
            use std::io::Write;
            std::fs::OpenOptions::new().create(true).append(true).open(file).expect("each").write_all(line.as_bytes()).expect("each");
        }
        for (f, (a, b)) in ours.iter().zip(&theirs).enumerate() {
            for (j, &k) in kept.iter().enumerate() {
                let d = a[k] - b[j];
                sum2[j] += d * d;
                if d.abs() > largest[j].0 {
                    largest[j] = (d.abs(), index, f);
                }
            }
            n2 += 1;
        }
        // (dump=<file> with show=N: the port's frames and the corpus's, a line each, every digit.)
        if let Some(file) = args[4..].iter().find_map(|a| a.strip_prefix("dump=")).filter(|_| index as f64 == show) {
            let line = |v: Vec<f64>| v.iter().map(|x| format!("{x:e}")).collect::<Vec<_>>().join(" ") + "\n";
            let text: String = ours.iter().map(|a| "port ".to_string() + &line(kept.iter().map(|&k| a[k]).collect())).chain(theirs.iter().map(|b| "corpus ".to_string() + &line(b.clone()))).collect();
            std::fs::write(file, text).expect("dump");
        }
        if index as f64 == show {
            println!("{language} {index} /{sampa}/ {:?}", phones);
            for (f, (a, b)) in ours.iter().zip(&theirs).enumerate() {
                let port: Vec<String> = kept.iter().map(|&k| format!("{:6.2}", a[k])).collect();
                let corpus: Vec<String> = b.iter().map(|x| format!("{x:6.2}")).collect();
                println!("{f:3} port   {}
    corpus {}", port.join(""), corpus.join(""));
            }
        }
        if compared <= 3 {
            println!("{language} {index} /{sampa}/: {} frames made, the corpus's {}", ours.len(), theirs.len());
        }
    }
    println!("{language}: {compared} sentences of {} (lead {lead} s, tail {tail} s); frames as many as the corpus's in {counts_same}", if added { "phones the spec makes" } else { "the speaker's phones alone" });
    for (j, name) in spec.frames.params.iter().enumerate() {
        let (d, i, f) = largest[j];
        println!("  {name:>4}: rms {:.2e}, largest {d:.2e} (sentence {i}, frame {f})", (sum2[j] / n2.max(1) as f64).sqrt());
    }
}
