// The parity check's port side for VocalTractLab 2.4's tube acoustics (src/v24/tds.rs), apart from its glottis:
// reference/v24_tds_parity.cpp's passage made the same way through the port -- each leg's tube from the port's 2.4
// tract, interpolated each sample, the glottis given the same area, the same lung pressure -- and its radiated flows
// compared with 2.4's, value for value.
//   cargo run --release --example v24_tds_parity -- JD2.speaker flows.f64
use musebots_vocaltract::v24::tds::TdsModel;
use musebots_vocaltract::v24::tract::{VocalTract, NUM_PARAMS, VO};
use musebots_vocaltract::v24::tube::{Tube, FIRST_TRACHEA_SECTION};
use musebots_vocaltract::xml;
use std::f64::consts::PI;

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let root = xml::parse(&std::fs::read_to_string(&args[0]).expect("speaker")).expect("a speaker file");
    let mut vt = VocalTract::from_xml(root.child("vocal_tract_model").expect("vocal tract")).expect("anatomy");
    let reference: Vec<f64> = std::fs::read(&args[1]).expect("flows").chunks_exact(8).map(|b| f64::from_le_bytes(b.try_into().unwrap())).collect();
    let mut tds = TdsModel::new();
    // (2.4 as it is: its noise's speed not held under sound's.)
    tds.options.bound_noise_velocity = false;
    tds.options.recover_at_branches = false;
    tds.options.passive_bernoulli = false;
    tds.reset_motion();
    let legs: [(&str, f64, usize, f64, f64, f64); 8] = [
        ("a", -1.0, 1, 110.0, 0.0, 0.0),
        ("a", -1.0, 30, 110.0, 8000.0, 0.0),
        ("i", -1.0, 30, 140.0, 8000.0, 0.0),
        ("tt-alveolar-fricative(i)", -1.0, 25, 140.0, 8000.0, 0.3),
        ("u", 0.5, 30, 120.0, 9000.0, 0.0),
        ("ll-labial-closure(a)", -1.0, 15, 115.0, 8000.0, 0.0),
        ("a", -1.0, 30, 160.0, 10000.0, 0.0),
        ("a", -1.0, 20, 160.0, 0.0, 0.0),
    ];
    const FRAME: usize = 120;
    let (mut right, mut tube) = (Tube::new(), Tube::new());
    let mut left;
    let mut first = true;
    let (mut phase, mut pressure, mut openness) = (0.0f64, 0.0f64, 0.0f64);
    let mut got = Vec::new();
    for (shape, velum, frames, f0, target, open) in legs {
        let mut p: [f64; NUM_PARAMS] = vt.shape(shape).expect("a shape");
        if velum > -1.0 {
            p[VO] = velum;
        }
        vt.calculate(&p);
        for _ in 0..frames {
            left = right.clone();
            right.set_from_tract(&vt.tube());
            if first {
                left = right.clone();
                first = false;
            }
            for n in 0..FRAME {
                let ratio = n as f64 / FRAME as f64;
                tube.interpolate(&left, &right, ratio);
                phase += f0 / 48000.0;
                if phase >= 1.0 {
                    phase -= 1.0;
                }
                openness += 0.002 * ((if open > 0.0 { 1.0 } else { 0.0 }) - openness);
                let pulse = if phase < 0.6 { 0.15 * (0.5 - 0.5 * (2.0 * PI * phase / 0.6).cos()) } else { 0.0 };
                let area = openness * 0.3 + (1.0 - openness) * pulse;
                tube.set_glottis_sections(&[0.3, 0.3], &[area, area]);
                tds.set_tube(&tube, true);
                pressure += 0.002 * (target - pressure);
                tds.set_pressure_source(pressure, FIRST_TRACHEA_SECTION as i32);
                let r = tds.proceed_time_step();
                got.extend([r.total, r.mouth, r.nostrils, r.skin]);
            }
        }
    }
    let n = got.len().min(reference.len());
    let identical = (0..n).filter(|&i| got[i].to_bits() == reference[i].to_bits()).count();
    let first_bad = (0..n).find(|&i| got[i].to_bits() != reference[i].to_bits());
    let largest = (0..n).map(|i| (got[i] - reference[i]).abs()).fold(0.0, f64::max);
    println!(
        "v24_tds_parity: {} values (reference {}), {identical} identical, first difference {}, largest {largest:.3e}",
        got.len(),
        reference.len(),
        first_bad.map(|i| format!("sample {} ({})", i / 4, ["total", "mouth", "nostrils", "skin"][i % 4])).unwrap_or("none".into())
    );
}
