// A body's vowels on the two engines (the owner, 16 November 2026: "I have been seeing VocalFork and VocalWind language
// used interchangeably ... unsure which we've been working with, and where assumptions might have been merged"): each
// vowel shape's first resonances where VocalTractLab 2.4's own network puts them (carry::resonances_fine -- what every
// shape of the languages' work was carried, tuned and brought to its place on: src/carry.rs, src/vowel_space.rs
// Sounded::heard) beside where the passive core puts them as it steps, its losses the fitted law (PassiveModel::network,
// Stepping::Stepped -- what a score is sung on: sing-score.mjs, acoustics=vocalwind), and how far apart, in cents. The
// glottis shut and the noise silent in both. Measurement only.
//   cargo run --release --example engines_apart -- <speaker.speaker> [vowel,vowel,...]
use musebots_vocaltract::carry::resonances_fine;
use musebots_vocaltract::v24::passive::frequency::{Complex, Stepping};
use musebots_vocaltract::v24::passive::PassiveModel;
use musebots_vocaltract::v24::speaker::Speaker;
use musebots_vocaltract::v24::tds::{TdsModel, TubeCoefficients};
use musebots_vocaltract::v24::tube::{Tube, MIN_AREA_CM2};

const TOP_HZ: f64 = 4000.0;

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let sp = Speaker::read(&args[0]).expect("speaker");
    let vowels: Vec<String> = args.get(1).map_or(["a", "e", "i", "o", "u"].iter().map(|s| s.to_string()).collect(), |s| s.split(',').map(String::from).collect());
    let mut options = TdsModel::new().options;
    options.generate_noise_sources = false;
    let (_, steps) = PassiveModel::for_speaker(&sp.tract, &sp.glottis, options);
    let rate = 48000.0 * steps as f64;
    let mut glottis = sp.glottis.clone();
    glottis.calc_geometry();
    let (lengths, _) = glottis.tube_data();
    println!("{}: 2.4's network at 48 kHz beside the passive core at {steps} steps a sample with the fitted law", args[0].rsplit('/').next().unwrap());
    let (mut worst, mut all): (f64, Vec<f64>) = (0.0, vec![]);
    for vowel in &vowels {
        let Some(params) = sp.tract.shape(vowel) else {
            println!("/{vowel}/: not a shape of this body's");
            continue;
        };
        let mut tract = sp.tract.clone();
        tract.calculate(&params);
        let geometry = tract.tube();
        let network24 = resonances_fine(&geometry, TOP_HZ);
        let mut tube = Tube::new();
        tube.set_from_tract(&geometry);
        let mut tds = TdsModel::new();
        tds.options = options;
        tds.set_tube(&tube, false);
        let mut k = TubeCoefficients::default();
        tds.tube_coefficients(&mut k);
        let (mut model, _) = PassiveModel::for_speaker(&sp.tract, &sp.glottis, options);
        model.take_switches(&["losses=fitted".to_string()]);
        model.set_rate(rate);
        model.set_glottis_sections(&lengths, &[MIN_AREA_CM2; 2]);
        model.set_pressure_source(0.0, 0);
        let network = model.network(&k);
        let grid: Vec<f64> = (0..).map(|i| 50.0 + 10.0 * i as f64).take_while(|&f| f <= TOP_HZ).collect();
        let size: Vec<f64> = grid.iter().map(|&f| network.response(Complex::tone(f), Stepping::Stepped).mouth.abs()).collect();
        let passive: Vec<f64> = (1..grid.len() - 1)
            .filter(|&i| size[i] > size[i - 1] && size[i] >= size[i + 1])
            .filter_map(|i| network.resonance(Complex::resonance(grid[i], 60.0), Stepping::Stepped).map(|pole| pole.frequency_and_bandwidth().0))
            .collect();
        let apart: Vec<f64> = network24.iter().zip(&passive).take(3).map(|(a, b)| 1200.0 * (b / a).log2()).collect();
        for &c in &apart {
            worst = if c.abs() > worst.abs() { c } else { worst };
            all.push(c);
        }
        let hz = |f: &[f64]| f.iter().take(3).map(|x| format!("{x:.0}")).collect::<Vec<_>>().join(" ");
        println!("  /{vowel}/: 2.4's {} Hz; the passive core's {} Hz; apart {} cents", hz(&network24), hz(&passive), apart.iter().map(|c| format!("{c:+.0}")).collect::<Vec<_>>().join(" "));
    }
    if !all.is_empty() {
        let mean = all.iter().sum::<f64>() / all.len() as f64;
        println!("  the first three resonances of {} vowels: the passive core's {mean:+.1} cents from 2.4's on the mean, {worst:+.0} at the most", all.len() / 3);
    }
}
