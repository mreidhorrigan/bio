// The live synthesis: reference/synth_parity.c's frames, repeated to `seconds`, synthesized sequentially (geometry and
// tube on one thread) and with the geometry made on 1, 2 and 3 other threads; each the sequential sound to the bit, and
// how many times faster than real time.
//   cargo run --release --example live_bench -- JD3.speaker frames.txt [seconds]
use musebots_vocaltract::live;
use musebots_vocaltract::speaker::Speaker;
use musebots_vocaltract::synth::Synthesizer;
use musebots_vocaltract::tds::TdsModel;
use musebots_vocaltract::tract::{VocalTract, NUM_PARAMS};
use std::time::Instant;

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let speaker = Speaker::read(&args[0]).expect("speaker");
    let tract = VocalTract::from_xml(speaker.root.child("vocal_tract_model").unwrap()).unwrap();
    let seconds: f64 = args.get(2).and_then(|s| s.parse().ok()).unwrap_or(10.0);
    let lines: Vec<(Vec<f64>, Vec<f64>)> = std::fs::read_to_string(&args[1])
        .unwrap()
        .lines()
        .map(|l| {
            let v: Vec<f64> = l.split_whitespace().map(|x| x.parse().unwrap()).collect();
            (v[..NUM_PARAMS].to_vec(), v[NUM_PARAMS..].to_vec())
        })
        .collect();
    let mut frames = Vec::new();
    while (frames.len() as f64) * 110.0 / 44100.0 < seconds {
        frames.extend(lines.iter().cloned());
    }
    let audio_s = (frames.len() - 1) as f64 * 110.0 / 44100.0;
    let mut synth = Synthesizer::new(speaker.glottis.clone(), TdsModel::new());
    let mut vt = tract.clone();
    let t0 = Instant::now();
    synth.reset();
    let mut sequential = vec![0.0; (frames.len() - 1) * 110];
    for (f, (tp, gp)) in frames.iter().enumerate() {
        let span = if f == 0 { 0..0 } else { (f - 1) * 110..f * 110 };
        synth.add_tract(&mut vt, tp, gp, &mut sequential[span]);
    }
    let s = t0.elapsed().as_secs_f64();
    println!("live_bench: {audio_s:.1} s of audio; sequential {:.2} times real time", audio_s / s);
    for workers in 1..=3 {
        let mut synth = Synthesizer::new(speaker.glottis.clone(), TdsModel::new());
        let t0 = Instant::now();
        let out = live::render(&tract, &mut synth, &frames, 110, workers, 8);
        let s = t0.elapsed().as_secs_f64();
        let same = out.len() == sequential.len() && out.iter().zip(&sequential).all(|(a, b)| a.to_bits() == b.to_bits());
        println!("live_bench: geometry on {workers} thread(s): {:.2} times real time, {}", audio_s / s, if same { "the sequential sound to the bit" } else { "NOT the sequential sound" });
    }
}
