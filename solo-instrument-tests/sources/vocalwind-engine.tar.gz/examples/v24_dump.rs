// VocalTractLab 2.4's tract in the port (src/v24), its intermediate values dumped one per line -- each parameter, every
// surface's vertices, the tongue's ribs, the center line, its length and the nasal port's place -- as a C++ harness
// dumps 2.4's own, to find where the two part when their tubes do.
//   cargo run --release --example v24_dump -- JD2.speaker params.txt > port.txt
use musebots_vocaltract::v24::tract::{VocalTract, NUM_PARAMS, NUM_TONGUE_RIBS};
use musebots_vocaltract::xml;

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let root = xml::parse(&std::fs::read_to_string(&args[0]).expect("speaker")).expect("a speaker file");
    let mut vt = VocalTract::from_xml(root.child("vocal_tract_model").expect("vocal tract")).expect("anatomy");
    let p: Vec<f64> = std::fs::read_to_string(&args[1]).expect("params").split_whitespace().take(NUM_PARAMS).map(|x| x.parse().unwrap()).collect();
    vt.calculate(&p);
    for (j, q) in vt.param.iter().enumerate() {
        println!("param {j} {:e} {:e}", q.x, q.limited_x);
    }
    for (s, f) in vt.surface.iter().enumerate() {
        for r in 0..f.num_ribs {
            for k in 0..f.num_rib_points {
                let q = f.get(r, k);
                println!("surface {s} {r} {k} {:e} {:e} {:e}", q.x, q.y, q.z);
            }
        }
    }
    for i in 0..NUM_TONGUE_RIBS {
        let t = vt.tongue_rib[i];
        println!("rib {i} {:e} {:e} {:e} {:e} {:e} {:e}", t.point.x, t.point.y, t.normal.x, t.normal.y, t.min_x, t.max_x);
    }
    for (i, c) in vt.center_line.iter().enumerate() {
        println!("center {i} {:e} {:e} {:e} {:e} {:e} {:e}", c.point.x, c.point.y, c.normal.x, c.normal.y, c.min, c.max);
    }
    println!("length {:e}\nport {:e}", vt.center_line_length, vt.nasal_port_pos_cm);
}
