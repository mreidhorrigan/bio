// What mending VocalTractLab's bugs changes (docs/VOCAL_TRACT.md, "Found in reading"): every shape of the speaker and
// 200 blends between them made into tubes both ways, the tubes that differ counted; then a gestural score synthesized
// both ways, the sound's level compared.
//   cargo run --release --example mended -- JD3.speaker score.ges
use musebots_vocaltract::gestural::GesturalScore;
use musebots_vocaltract::speaker::Speaker;
use musebots_vocaltract::synth::Synthesizer;
use musebots_vocaltract::tds::TdsModel;
use musebots_vocaltract::tract::{VocalTract, NUM_PARAMS};

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let speaker = Speaker::read(&args[0]).expect("speaker");
    let tract = VocalTract::from_xml(speaker.root.child("vocal_tract_model").expect("vocal tract")).expect("anatomy");
    let shapes: Vec<[f64; NUM_PARAMS]> = tract.shapes.iter().map(|(_, p)| *p).collect();
    let mut params: Vec<[f64; NUM_PARAMS]> = shapes.clone();
    for k in 0..200 {
        let (a, b, r) = (shapes[(k * 7) % shapes.len()], shapes[(k * 13 + 5) % shapes.len()], (k % 9) as f64 / 8.0);
        let mut p = [0.0; NUM_PARAMS];
        for j in 0..NUM_PARAMS {
            p[j] = a[j] + (b[j] - a[j]) * r;
        }
        params.push(p);
    }
    let (mut own, mut mended) = (tract.clone(), tract.clone());
    mended.mended = true;
    let (mut differ, mut largest) = (0, 0.0f64);
    for p in &params {
        own.calculate(p);
        mended.calculate(p);
        let (a, b) = (own.tube(), mended.tube());
        let d = (0..a.area_cm2.len()).map(|i| (a.area_cm2[i] - b.area_cm2[i]).abs().max((a.length_cm[i] - b.length_cm[i]).abs())).fold(0.0, f64::max);
        if d > 0.0 {
            differ += 1;
        }
        largest = largest.max(d);
    }
    println!("mended: {differ} of {} tubes differ, the largest by {largest:.4} (cm2 or cm)", params.len());
    let (score, _) = GesturalScore::parse(&std::fs::read_to_string(&args[1]).expect("score")).expect("a score");
    let neutral: Vec<f64> = speaker.glottis.control.iter().map(|p| p.neutral).collect();
    let mut level = Vec::new();
    for m in [false, true] {
        let mut t = tract.clone();
        t.mended = m;
        let mut g = speaker.glottis.clone();
        g.mended = m;
        let frames = score.frames(&t, &speaker.glottis.shapes, &neutral);
        let mut synth = Synthesizer::new(g, TdsModel::new());
        synth.reset();
        let mut out = Vec::new();
        let mut buffer = vec![0.0; 110];
        for (f, (tp, gp)) in frames.iter().enumerate() {
            let n = if f == 0 { 0 } else { 110 };
            synth.add_tract(&mut t, tp, gp, &mut buffer[..n]);
            out.extend_from_slice(&buffer[..n]);
        }
        let rms = (out.iter().map(|x| x * x).sum::<f64>() / out.len() as f64).sqrt();
        level.push(20.0 * rms.log10());
    }
    println!("mended: the score's level {:.2} dB as VocalTractLab's, {:.2} dB mended ({:+.2} dB)", level[0], level[1], level[1] - level[0]);
}
