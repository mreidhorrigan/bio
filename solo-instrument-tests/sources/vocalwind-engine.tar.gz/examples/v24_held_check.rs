// Held vowels through the geometry pool and the pipeline, against the sequential synthesis, to the bit (src/live.rs: a
// frame whose parameters repeat the last frame's is given its tube again, not made). The articulators approach /a/ from
// the neutral tract through the live voice's three lags (12 ms each), hold it, then /i/ and hold it; the glottis modal
// at 120 Hz with its flutter and jitter, the lungs at 8000 dPa: 3 s, at 1 and 4 steps a sample. Says how many frames
// repeat the frame before, and whether each render is the sequential one's.
//   cargo run --release --example v24_held_check -- JD2.speaker
use musebots_vocaltract::live;
use musebots_vocaltract::v24::pipeline;
use musebots_vocaltract::v24::speaker::Speaker;
use musebots_vocaltract::v24::synth::{Synthesizer, NUM_CHUNK_SAMPLES};
use musebots_vocaltract::v24::tds::TdsModel;

fn main() {
    let path = std::env::args().nth(1).expect("a 2.4 speaker");
    let sp = Speaker::read(&path).expect("speaker");
    let neutral: Vec<f64> = sp.tract.param.iter().map(|p| p.neutral).collect();
    let (a, i) = (sp.tract.shape("a").expect("a").to_vec(), sp.tract.shape("i").expect("i").to_vec());
    let modal = sp.glottis.shapes.iter().find(|(n, _)| n == "modal").expect("modal").1.clone();
    let dt = NUM_CHUNK_SAMPLES as f64 / 48000.0;
    let k = 1.0 - (-dt / 0.012f64).exp();
    let mut lag = [neutral.clone(), neutral.clone(), neutral.clone()];
    let mut frames = Vec::new();
    for f in 0..(3.0 / dt) as usize {
        let target = if (f as f64) * dt < 1.5 { &a } else { &i };
        for j in 0..target.len() {
            lag[0][j] += k * (target[j] - lag[0][j]);
            lag[1][j] += k * (lag[0][j] - lag[1][j]);
            lag[2][j] += k * (lag[1][j] - lag[2][j]);
        }
        let mut g = modal.clone();
        g[0] = 120.0;
        g[1] = 8000.0 * (1.0 - (-(f as f64) * dt / 0.012).exp());
        frames.push((lag[2].clone(), g));
    }
    let repeated = frames.windows(2).filter(|w| w[0].0.iter().zip(&w[1].0).all(|(x, y)| x.to_bits() == y.to_bits())).count();
    println!("{} frames, {repeated} repeating the frame before", frames.len());
    for n in [1usize, 4] {
        let synth = || {
            let mut s = Synthesizer::new(sp.glottis.clone(), TdsModel::new());
            s.set_oversampling(n);
            s
        };
        let mut tract = sp.tract.clone();
        let mut seq = synth();
        let mut sequential = Vec::new();
        let mut buffer = vec![0.0; NUM_CHUNK_SAMPLES];
        for (f, (t, g)) in frames.iter().enumerate() {
            let m = if f == 0 { 0 } else { NUM_CHUNK_SAMPLES };
            seq.add_tract(&mut tract, t, g, &mut buffer[..m]);
            sequential.extend_from_slice(&buffer[..m]);
        }
        let pooled = live::render_v24(&sp.tract, &mut synth(), &frames, 2, 4);
        let piped = pipeline::render(&sp.tract, &mut synth(), &frames, 2, 4);
        let same = |x: &[f64]| x.len() == sequential.len() && x.iter().zip(&sequential).all(|(p, q)| p.to_bits() == q.to_bits());
        println!("{n} steps a sample: the pool's sound {} the sequential one's; the pipeline's {}", if same(&pooled) { "is" } else { "is NOT" }, if same(&piped) { "is" } else { "is NOT" });
    }
}
