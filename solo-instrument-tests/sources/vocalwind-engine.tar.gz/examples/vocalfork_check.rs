// VocalFork 3.0's acoustics (src/v24/passive.rs) against VocalTractLab 2.4's network, the same glottis, tube, noise and
// radiation filter about each (research/VOCAL_TRACT_PASSIVE_CORE.md). VocalFork steps at the rate its network asks
// over every shape of the speaker (PassiveModel::steps_needed); 2.4 at 192 kHz, its passive Bernoulli form.
//   identity: a vowel sung, its energy accounted every step -- the identity's worst residual against the energy.
//   compare: vowels sung by each, the last 16384 samples' level and third-octave bands (100 Hz to 16 kHz), the
//            difference band by band.
//   high: vowels sung by each, the last 16384 samples' third-octave bands from 5.0 to 20.2 kHz re their whole, the
//            vowels' mean, against measured singing (Monson, Lotto & Story 2012; FORK_SEX=female for a woman's voice):
//            docs/VOCALTRACTLAB_FIXES.md 16. With no FORK_SWITCHES, VocalFork is VocalWind as a render lays it, its
//            defaults (stream.rs new_vocalwind).
//   bounded: the cases that ran 2.4's network away -- the glottis held wide open, and a voiceless fricative, at
//            16,000 dPa -- and a glottis snapping shut.
//   nudged: a vowel sung twice, the lungs' pressure a part in 1e13 higher the second time, by VocalFork and by 2.4's
//            network: how far so small a change moves the sound -- what any change of an arithmetic's rounding can
//            move it by (FORK_OPEN="x_bottom,x_top,chink,still": the glottis held so, its folds still where 1).
// FORK_SWITCHES="walls=1 reattachment=0 ...": VocalFork's physics' switches (PassiveModel::take_switches; trachea=,
// how its network is laid: layout_switches), to see each one's part in a difference.
//   cargo run --release --example vocalfork_check -- <speaker.speaker> identity|compare|high|bounded|nudged [vowel,vowel,...]
use musebots_vocaltract::v24::passive::{EnergyAccount, PassiveModel};
use musebots_vocaltract::v24::speaker::Speaker;
use musebots_vocaltract::v24::synth::{Synthesizer, NUM_CHUNK_SAMPLES};
use musebots_vocaltract::v24::tds::{Options, TdsModel, TubeCoefficients};
use musebots_vocaltract::v24::tract::VocalTract;
use musebots_vocaltract::v24::tube::Tube;

/// FORK_SWITCHES's switches, each key=value.
fn fork_switches() -> Vec<String> {
    std::env::var("FORK_SWITCHES").unwrap_or_default().split_whitespace().map(String::from).collect()
}

/// VocalFork's network on `template`, laid as FORK_SWITCHES asks (trachea=: PassiveModel::layout_switches).
fn laid(template: &Tube, mut options: Options) -> PassiveModel {
    PassiveModel::layout_switches(&mut options, &fork_switches());
    PassiveModel::new(template, options)
}

struct Voice {
    vowel: String,
    glottis: String,
    lungs: f64,
    seconds: f64,
    /// x_bottom, x_top and chink held (cm, cm, cm^2), the folds still where `still`.
    open: Option<(f64, f64, f64, bool)>,
    /// the glottis's areas shut at this time (s), within a few steps
    snap: Option<f64>,
}

fn tube_of(tract: &VocalTract, params: &[f64]) -> Tube {
    let mut tract = tract.clone();
    tract.calculate(params);
    let mut t = Tube::new();
    t.set_from_tract(&tract.tube());
    t
}

fn coefficients(tube: &Tube) -> TubeCoefficients {
    let mut tds = TdsModel::new();
    tds.set_tube(tube, false);
    let mut k = TubeCoefficients::default();
    tds.tube_coefficients(&mut k);
    k
}

/// The steps a sample VocalFork asks over every shape of the speaker (the most of them).
fn fork_steps(sp: &Speaker) -> usize {
    let template = tube_of(&sp.tract, &sp.tract.param.iter().map(|p| p.neutral).collect::<Vec<_>>());
    let mut model = laid(&template, TdsModel::new().options);
    // (the speaker's folds' two sections' lengths, as its glottis lays them)
    let mut glottis = sp.glottis.clone();
    glottis.calc_geometry();
    let (lengths, _) = glottis.tube_data();
    let mut most = 1;
    for (name, v) in sp.tract.shapes.iter() {
        let k = coefficients(&tube_of(&sp.tract, v));
        let n = model.steps_needed(&k, &lengths);
        if std::env::var("FORK_SHAPES").is_ok() {
            let (node, what, f) = model.highest_mode(&k, &lengths);
            println!("  {name}: {n} steps; its highest mode {:.0} kHz at node {node}, {what}; lips {:.4} cm2, nostrils {:.4}", f / 1000.0, k.area[74], k.area[93]);
        }
        most = most.max(n);
    }
    most
}

/// The voice rendered at 48 kHz: by 2.4's network at 4 steps, or by VocalFork at `fork` steps (its account kept where
/// `account`). Its samples, the account, and whether every sample was finite and under full scale.
fn render(sp: &Speaker, v: &Voice, fork: Option<usize>, account: bool) -> (Vec<f64>, Option<EnergyAccount>, bool) {
    let mut tract = sp.tract.clone();
    tract.mended = true;
    let mut glottis = sp.glottis.clone();
    glottis.mended = true;
    // (FORK_JITTER: the glottis's jitter, percent, in both, in place of the speaker's)
    if let Some(j) = std::env::var("FORK_JITTER").ok().and_then(|x| x.parse::<f64>().ok()) {
        glottis.statics[musebots_vocaltract::v24::glottis::JITTER].x = j;
    }
    let mut tds = TdsModel::new();
    // (FORK_NOISE=0: no noise sources, in either)
    if std::env::var("FORK_NOISE").map_or(false, |x| x == "0") {
        tds.options.generate_noise_sources = false;
    }
    // (FORK_WALLS=0: no soft walls, in either)
    if std::env::var("FORK_WALLS").map_or(false, |x| x == "0") {
        tds.options.soft_walls = false;
    }
    // (both glottises' jitter band-limited, as VocalFork's, so that a comparison is the acoustics'; FORK_WHITE_JITTER=1:
    // 2.4's white phase kicks in both)
    let white = std::env::var("FORK_WHITE_JITTER").is_ok();
    glottis.jitter_band_limited = !white;
    let mut synth = Synthesizer::new(glottis.clone(), tds);
    let params: Vec<f64> = tract.shape(&v.vowel).expect("a shape of the speaker's").to_vec();
    if let Some(n) = fork {
        let mut model = laid(&tube_of(&tract, &params), synth.tds.options);
        // (FORK_SWITCHES: VocalFork's physics' switches, as a renderer takes them -- walls, folds, reattachment, borda,
        // velocity, tract, noise, each =0|1: PassiveModel::take_switches; its defaults otherwise)
        model.take_switches(&fork_switches());
        if account {
            model.account = Some(Box::default());
        }
        synth.use_vocalfork(model);
        synth.glottis.jitter_band_limited = !white;
        synth.set_oversampling(n);
    } else {
        synth.set_oversampling(4);
    }
    let mut g: Vec<f64> = glottis.shapes.iter().find(|(n, _)| *n == v.glottis).expect("a glottal shape of the speaker's").1.clone();
    if let Some((xb, xt, chink, still)) = v.open {
        g[2] = xb;
        g[3] = xt;
        g[4] = chink;
        if still {
            g[6] = 0.0;
        }
    }
    let chunks = (v.seconds * 48000.0 / NUM_CHUNK_SAMPLES as f64) as usize;
    let began = std::time::Instant::now();
    let mut out = vec![0.0; NUM_CHUNK_SAMPLES];
    let mut heard = Vec::new();
    let mut fine = true;
    for c in 0..=chunks {
        let t = c as f64 * NUM_CHUNK_SAMPLES as f64 / 48000.0;
        g[1] = v.lungs * (1.0 - (-t / 0.012).exp());
        if let Some(at) = v.snap {
            if t >= at {
                g[2] = -0.2;
                g[3] = -0.2;
                g[4] = 0.0;
            }
        }
        let made = if c == 0 { 0 } else { NUM_CHUNK_SAMPLES };
        synth.add_tract(&mut tract, &params, &g, &mut out[..made]);
        // (FORK_TRACE=1: VocalFork's account chunk by chunk from 0.29 s)
        if std::env::var("FORK_TRACE").map_or(false, |x| t >= x.parse::<f64>().unwrap_or(0.29)) {
            if let Some(a) = synth.passive.as_ref().and_then(|p| p.account.as_ref()) {
                let (_, area) = synth.glottis.tube_data();
                println!("  {t:.4} s: glottal areas {:.2e} {:.2e}; energy {:.4e}; summed lungs {:.4e}, sources {:.4e}, volumes {:.4e}, geometry {:.4e}, losses {:.4e}; worst residual {:.2e}; peak out {:.3e}", area[0], area[1], a.energy, a.lungs, a.sources, a.volumes, a.geometry, a.losses, a.worst_residual, out[..made].iter().fold(0.0f64, |m, x| m.max(x.abs())));
            }
        }
        if out[..made].iter().any(|x| !(x.abs() < 1.0)) {
            fine = false;
            break;
        }
        heard.extend_from_slice(&out[..made]);
    }
    // (FORK_TIME=1: how long the render took against the sound it made)
    if std::env::var("FORK_TIME").is_ok() {
        eprintln!("  {}: {:.2} s of sound in {:.2} s", if fork.is_some() { "VocalFork" } else { "2.4 at 192 kHz" }, heard.len() as f64 / 48000.0, began.elapsed().as_secs_f64());
    }
    if let Some(p) = synth.passive.as_ref() {
        if p.overwhelmed > 0 {
            eprintln!("  VocalFork: {} edge-steps where a negative drop outweighed the edge's inertia", p.overwhelmed);
            let labels = p.edges_now();
            for &(e, u, c, beta) in &p.overwhelmed_at {
                eprintln!("    first at {} : flow {u:.3e}, net c {c:.3e}, beta {beta:.3e}", labels[e].0);
            }
        }
    }
    let account = synth.passive.as_ref().and_then(|p| p.account.as_ref().map(|a| (**a).clone()));
    (heard, account, fine)
}

/// The last 16384 samples' level (dB) and third-octave bands from 100 Hz to 16 kHz (dB).
fn bands(x: &[f64]) -> (f64, Vec<f64>) {
    let x = &x[x.len() - 16384..];
    let rms = (x.iter().map(|v| v * v).sum::<f64>() / x.len() as f64).sqrt();
    let (cos, sin): (Vec<f64>, Vec<f64>) = (0..16384).map(|j| { let ph = 2.0 * std::f64::consts::PI * j as f64 / 16384.0; (ph.cos(), ph.sin()) }).unzip();
    let wx: Vec<f64> = x.iter().enumerate().map(|(j, v)| v * (0.5 - 0.5 * cos[j])).collect();
    let power: Vec<f64> = (0..5462)
        .map(|k| {
            let (mut re, mut im) = (0.0, 0.0);
            for (j, v) in wx.iter().enumerate() {
                let i = k * j % 16384;
                re += v * cos[i];
                im -= v * sin[i];
            }
            re * re + im * im
        })
        .collect();
    let b = (0..23)
        .map(|b| {
            let fc = 100.0 * 2f64.powf(b as f64 / 3.0);
            let (lo, hi) = (fc * 2f64.powf(-1.0 / 6.0), fc * 2f64.powf(1.0 / 6.0));
            let p: f64 = (0..power.len()).filter(|&k| { let f = k as f64 * 48000.0 / 16384.0; f >= lo && f < hi }).map(|k| power[k]).sum();
            10.0 * p.max(1e-30).log10()
        })
        .collect();
    (20.0 * rms.max(1e-30).log10(), b)
}

/// The last 16384 samples' third-octave bands at 5.0, 6.3, 8.0, 10.1, 12.7, 16.0 and 20.2 kHz (centres 1000 * 2^(k/3),
/// edges a sixth of an octave either side), Hann-windowed, each dB re the whole spectrum's power: the reading of
/// docs/VOCALTRACTLAB_FIXES.md 16's figures of 13 November, which it gives again within 0.05 dB from their renders.
fn high_band(x: &[f64]) -> [f64; 7] {
    const N: usize = 16384;
    let x = &x[x.len() - N..];
    let (cos, sin): (Vec<f64>, Vec<f64>) = (0..N).map(|j| { let ph = 2.0 * std::f64::consts::PI * j as f64 / N as f64; (ph.cos(), ph.sin()) }).unzip();
    let wx: Vec<f64> = x.iter().enumerate().map(|(j, v)| v * (0.5 - 0.5 * cos[j])).collect();
    // (the one-sided spectrum's whole power, by Parseval)
    let whole = N as f64 * wx.iter().map(|v| v * v).sum::<f64>() / 2.0;
    let mut out = [0.0; 7];
    for (b, o) in out.iter_mut().enumerate() {
        let fc = 1000.0 * 2f64.powf((b + 7) as f64 / 3.0);
        let (lo, hi) = (fc * 2f64.powf(-1.0 / 6.0), fc * 2f64.powf(1.0 / 6.0));
        let p: f64 = (0..=N / 2)
            .filter(|&k| { let f = k as f64 * 48000.0 / N as f64; f >= lo && f < hi })
            .map(|k| {
                let (mut re, mut im) = (0.0, 0.0);
                for (j, v) in wx.iter().enumerate() {
                    let i = k * j % N;
                    re += v * cos[i];
                    im -= v * sin[i];
                }
                re * re + im * im
            })
            .sum();
        *o = 10.0 * (p / whole).max(1e-30).log10();
    }
    out
}

/// FORK_WRITE=folder: a vowel's two renders written there as raw 64-bit floats at 48 kHz, for study.
fn write_for_study(vowel: &str, x24: &[f64], xf: &[f64]) {
    if let Ok(dir) = std::env::var("FORK_WRITE") {
        let raw = |x: &[f64]| x.iter().flat_map(|v| v.to_le_bytes()).collect::<Vec<u8>>();
        std::fs::write(format!("{dir}/{vowel}-2.4.f64"), raw(x24)).unwrap();
        std::fs::write(format!("{dir}/{vowel}-vocalfork.f64"), raw(xf)).unwrap();
    }
}

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let sp = Speaker::read(&args[0]).expect("speaker");
    let mode = args.get(1).map(String::as_str).unwrap_or("compare");
    let vowels: Vec<String> = args.get(2).map_or(vec!["a".into(), "i".into(), "u".into()], |s| s.split(',').map(String::from).collect());
    // (FORK_STEPS: the steps a sample asked, at least the physics' own)
    let n = fork_steps(&sp).max(std::env::var("FORK_STEPS").ok().and_then(|x| x.parse().ok()).unwrap_or(0));
    println!("{}: VocalFork at {} steps a sample ({} kHz), over its {} shapes", args[0].rsplit('/').next().unwrap(), n, 48 * n, sp.tract.shapes.len());
    let sung = |vowel: &str| Voice { vowel: vowel.into(), glottis: "modal".into(), lungs: 8000.0, seconds: 0.5, open: None, snap: None };
    match mode {
        "identity" => {
            for vowel in &vowels {
                let (x, a, fine) = render(&sp, &Voice { seconds: 0.3, ..sung(vowel) }, Some(n), true);
                let a = a.unwrap();
                println!(
                    "/{vowel}/: {} samples, {}; the identity's worst residual {:.1e} of the peak energy ({:.3e} erg); summed (erg): lungs {:.3e}, sources {:.3e}, volumes {:.3e}, geometry {:.3e}, losses {:.3e}; energy now {:.3e}",
                    x.len(),
                    if fine { "every sample finite" } else { "NOT finite" },
                    a.worst_residual / a.peak,
                    a.peak,
                    a.lungs,
                    a.sources,
                    a.volumes,
                    a.geometry,
                    a.losses,
                    a.energy
                );
            }
        }
        "nudged" => {
            let worst = |a: &[f64], b: &[f64]| a.iter().zip(b).fold(0.0f64, |m, (x, y)| m.max((x - y).abs())) / a.iter().fold(0.0f64, |m, x| m.max(x.abs()));
            for vowel in &vowels {
                let open = std::env::var("FORK_OPEN").ok().map(|x| x.split(',').map(|y| y.parse::<f64>().expect("a number")).collect::<Vec<_>>()).map(|o| (o[0], o[1], o[2], o[3] != 0.0));
                let voice = Voice { seconds: 0.3, open, ..sung(vowel) };
                let more = Voice { lungs: voice.lungs * (1.0 + 1e-13), vowel: voice.vowel.clone(), glottis: voice.glottis.clone(), ..voice };
                let fork = worst(&render(&sp, &voice, Some(n), false).0, &render(&sp, &more, Some(n), false).0);
                let tds = worst(&render(&sp, &voice, None, false).0, &render(&sp, &more, None, false).0);
                println!("/{vowel}/: the lungs' pressure a part in 1e13 higher moves the sound by {fork:.1e} of its peak (VocalFork), {tds:.1e} (2.4's network)");
            }
        }
        "compare" => {
            for vowel in &vowels {
                let (x24, _, f24) = render(&sp, &sung(vowel), None, false);
                let (xf, _, ff) = render(&sp, &sung(vowel), Some(n), false);
                if !(f24 && ff) {
                    println!("/{vowel}/: 2.4 {}, VocalFork {}", if f24 { "fine" } else { "NOT fine" }, if ff { "fine" } else { "NOT fine" });
                    continue;
                }
                write_for_study(vowel, &x24, &xf);
                let ((l24, b24), (lf, bf)) = (bands(&x24), bands(&xf));
                let d: Vec<f64> = b24.iter().zip(&bf).map(|(a, b)| b - a).collect();
                let below5: Vec<f64> = d[..14].iter().map(|x| x.abs()).collect();
                let mut sorted = below5.clone();
                sorted.sort_by(|a, b| a.partial_cmp(b).unwrap());
                println!(
                    "/{vowel}/: level 2.4 {l24:.2} dB, VocalFork {lf:.2} ({:+.2}); bands 100 Hz-4 kHz: median |difference| {:.2} dB, most {:.2}; by band {}",
                    lf - l24,
                    sorted[sorted.len() / 2],
                    sorted[sorted.len() - 1],
                    d.iter().map(|x| format!("{x:+.1}")).collect::<Vec<_>>().join(" ")
                );
            }
        }
        "high" => {
            // (Monson, Lotto & Story 2012, JASA 132(3) 1754-1764, doi:10.1121/1.4742724, Table II, normal singing: the
            // same bands re the overall level, dB, men's or women's)
            let female = std::env::var("FORK_SEX").map_or(false, |x| x == "female");
            let measured = if female { [-32.7, -30.6, -28.4, -27.7, -31.4, -36.1, -42.4] } else { [-29.7, -27.2, -27.2, -31.6, -36.7, -40.7, -46.1] };
            let show = |b: &[f64]| b.iter().map(|x| format!("{x:.1}")).collect::<Vec<_>>().join(" ");
            let (mut sums, mut heard) = ([[0.0f64; 7]; 2], 0);
            for vowel in &vowels {
                let (x24, _, f24) = render(&sp, &sung(vowel), None, false);
                let (xf, _, ff) = render(&sp, &sung(vowel), Some(n), false);
                if !(f24 && ff) {
                    println!("/{vowel}/: 2.4 {}, VocalFork {}; left out", if f24 { "fine" } else { "NOT fine" }, if ff { "fine" } else { "NOT fine" });
                    continue;
                }
                write_for_study(vowel, &x24, &xf);
                let (h24, hf) = (high_band(&x24), high_band(&xf));
                println!("/{vowel}/, 5.0-20.2 kHz, dB re its whole: 2.4 {}; VocalFork {}", show(&h24), show(&hf));
                for b in 0..7 {
                    sums[0][b] += h24[b];
                    sums[1][b] += hf[b];
                }
                heard += 1;
            }
            for (who, sum) in ["2.4", "VocalFork"].iter().zip(&sums) {
                let mean: Vec<f64> = sum.iter().map(|s| s / heard as f64).collect();
                let re = mean.iter().zip(&measured).map(|(a, m)| a - m).sum::<f64>() / 7.0;
                println!("{who}, the mean of {heard} vowels: {}; {re:+.1} dB re measured {}", show(&mean), if female { "women" } else { "men" });
            }
        }
        "bounded" => {
            let cases = [
                ("the glottis held wide open, 16,000 dPa", Voice { vowel: "a".into(), glottis: "modal".into(), lungs: 16000.0, seconds: 1.0, open: Some((0.3, 0.3, 0.25, false)), snap: None }),
                ("the same, its folds still", Voice { vowel: "a".into(), glottis: "modal".into(), lungs: 16000.0, seconds: 1.0, open: Some((0.3, 0.3, 0.25, true)), snap: None }),
                ("tb-uvular-fricative(u), a voiceless fricative's glottis, 16,000 dPa", Voice { vowel: "tb-uvular-fricative(u)".into(), glottis: "voiceless-fricative".into(), lungs: 16000.0, seconds: 1.0, open: None, snap: None }),
                ("/a/, the glottis open then snapped shut at 0.3 s, 8,000 dPa", Voice { vowel: "a".into(), glottis: "modal".into(), lungs: 8000.0, seconds: 0.6, open: Some((0.2, 0.2, 0.15, true)), snap: Some(0.3) }),
            ];
            for (what, v) in cases.iter() {
                if sp.tract.shape(&v.vowel).is_none() {
                    continue;
                }
                let (_, _, f24) = render(&sp, v, None, false);
                // (FORK_NO_ACCOUNT=1: rendered without the energy's account, to see it changes nothing)
                let keep = std::env::var("FORK_NO_ACCOUNT").is_err();
                let (x, a, ff) = render(&sp, v, Some(n), keep);
                let a = a.unwrap_or_default();
                let peak = x.iter().fold(0.0f64, |m, v| m.max(v.abs()));
                println!("{what}: 2.4 at 192 kHz {}; VocalFork {} (peak {peak:.3}), the identity's worst residual {:.1e}", if f24 { "bounded" } else { "RAN AWAY" }, if ff { "bounded" } else { "RAN AWAY" }, a.worst_residual / a.peak);
            }
        }
        "mode" => {
            let template = tube_of(&sp.tract, &sp.tract.param.iter().map(|p| p.neutral).collect::<Vec<_>>());
            let mut model = laid(&template, TdsModel::new().options);
            let mut glottis = sp.glottis.clone();
            glottis.calc_geometry();
            let (lengths, _) = glottis.tube_data();
            println!("the folds' sections {:.3} {:.3} cm", lengths[0], lengths[1]);
            for vowel in &vowels {
                let k = coefficients(&tube_of(&sp.tract, &sp.tract.shape(vowel).unwrap()));
                for n in [4usize, 5, 6, 8, 12, 18] {
                    model.set_rate(48000.0 * n as f64);
                    let (node, what, f) = model.highest_mode(&k, &lengths);
                    println!("/{vowel}/ at {n} steps: highest mode {:.0} kHz (w dt {:.2}), largest at node {node}: {what}", f / 1000.0, 2.0 * std::f64::consts::PI * f / (48000.0 * n as f64));
                }
            }
        }
        other => panic!("{other}?"),
    }
}
