// A vowel one speaker lacks, made from its own vowel space where another speaker's sound puts that one's own (src/blend.rs
// vowels_made): the place the other's map gives, the lacking speaker's anchors where their sound puts them, the shape its
// space makes there, its first three resonances beside the other's own and the lacking speaker's nearest, and each
// parameter beside theirs.
//   cargo run --release --example vowel_made -- M01 JD2 M
use musebots_vocaltract::blend::{self, Voices};
use musebots_vocaltract::carry::resonances;
use musebots_vocaltract::v24::speaker::Speaker;
use musebots_vocaltract::v24::tract::{VocalTract, NUM_PARAMS};
use musebots_vocaltract::vowel_space::{space, Place};

const TOP_HZ: f64 = 5000.0;

fn formants(tract: &mut VocalTract, shape: &[f64; NUM_PARAMS]) -> Vec<f64> {
    let mut v = *shape;
    for (k, x) in v.iter_mut().enumerate() {
        *x = x.clamp(tract.param[k].min, tract.param[k].max);
    }
    tract.calculate(&v);
    resonances(&tract.tube(), TOP_HZ).into_iter().take(3).collect()
}

fn show(f: &[f64]) -> String {
    f.iter().map(|x| format!("{x:6.0}")).collect()
}

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let [lacking, having, name] = [0, 1, 2].map(|k| args.get(k).cloned().unwrap_or_else(|| panic!("usage: vowel_made LACKING HAVING SHAPE")));
    let voices = Voices::read(&blend::voices_file()).unwrap_or_else(|e| panic!("{e}"));
    let home = blend::synthesis_home();
    let tract_of = |id: &str| Speaker::parse(&voices.blend_text(&home, &format!("{id}=1")).unwrap_or_else(|e| panic!("{e}"))).unwrap_or_else(|e| panic!("{id}: {e}")).tract;
    let (mut lt, mut ht) = (tract_of(&lacking), tract_of(&having));
    let s = space();
    let hs = s.of_speaker(&mut ht).unwrap_or_else(|e| panic!("{e}"));
    let ls = s.of_speaker(&mut lt).unwrap_or_else(|e| panic!("{e}"));
    let own = ht.shape(&name).unwrap_or_else(|| panic!("{having} has no /{name}/"));
    let fo = formants(&mut ht, &own);
    let place = hs.map.as_ref().expect("a sound map").place((fo[0], fo[1]), 0.0);
    println!("{having}'s /{name}/ {} : at row {:5.2} column {:5.2} by its map", show(&fo), place.row, place.column);
    let mut anchors = s.anchors(|n| lt.shape(n));
    let sounds: Vec<(f64, f64)> = anchors.iter().map(|a| { let f = formants(&mut lt, &a.params); (f[0], f[1]) }).collect();
    let _ = s.place_by_sound(&mut anchors, &sounds);
    println!("{lacking}'s anchors where their sound puts them (row, column, rounding), F1 F2:");
    for (a, f) in anchors.iter().zip(&sounds) {
        println!("  {:>6}  {:5.2} {:5.2} {:3.1}  {:5.0} {:5.0}", a.name, a.place.row, a.place.column, a.place.rounding, f.0, f.1);
    }
    let made = ls.space.at(Place { rhotic: 0.0, ..place });
    println!("{lacking}'s space there: {}", show(&formants(&mut lt, &made)));
    for (row, column) in [(0.0, 2.0), (0.5, 2.0), (1.0, 2.0), (place.row, 2.0), (0.0, place.column)] {
        let m = ls.space.at(Place::new(row, column, 0.0));
        println!("  at {row:4.2} {column:4.2} unrounded: {}", show(&formants(&mut lt, &m)));
    }
    let near = lt.shape("u").unwrap_or([0.0; NUM_PARAMS]);
    println!("parameter        {having:>7}/{name}/ {lacking:>7} made {lacking:>7} /u/   range");
    for k in 0..NUM_PARAMS {
        let p = &lt.param[k];
        println!("  {:>6} {:12.3} {:12.3} {:12.3}   {:.2}..{:.2}", p.name, own[k], made[k], near[k], p.min, p.max);
    }
}
