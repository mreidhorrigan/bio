// A still vowel's transfer on the engine that sings it, written as measured tracts' are (17 November 2026; the owner,
// 16 November 2026: "we likely need to systematize our fitting, tuning, and optimization process for impedance and
// other audio targets, as we did for Openwind"; of what sounded like aliasing in the singers' "ooo": "if you can trace
// the buzz, yes, do so"): the lips' flow for a flow put into the pharynx's first node, from the passive core's own
// network in frequency (PassiveModel::network, Network::response: src/v24/passive/frequency.rs), as the step takes it,
// on a grid of frequencies -- the Dresden Vocal Tract Dataset's `*-vvtf-measured.txt` layout (freq_Hz magnitude
// phase_rad), so that one reader holds the engine beside a printed tract's measurement. The glottis shut, as a sweep
// tone measures a tract (GLOTTIS_CM2=AREA: its two sections at that area instead, the lungs' end as the model has it);
// the noise silent; FORK_SWITCHES the passive core's switches as a render gives them (tissue=, losses=, radiation=). A shape may be asked with parameters of its own -- `u:LD=0.5:HY=-5.9` -- and written under a name, `name@u:LD=0.5`;
// FOSSA=LENGTH_CM,VOLUME_CM3 lays the piriform fossa so in place of the speaker's; VENTRICLE=VOLUME_CM3 a laryngeal
// ventricle; ANATOMY= lays a chorister's
// measures as vtl-stream does; AREAS=1 prints each shape's area
// function from the glottis to the lips. Measurement only.
//   cargo run --release --example tract_response -- <speaker.speaker> <folder> [shape,shape,...] [top Hz] [step Hz]
use musebots_vocaltract::v24::passive::frequency::{Complex, Stepping};
use musebots_vocaltract::v24::passive::PassiveModel;
use musebots_vocaltract::v24::speaker::Speaker;
use musebots_vocaltract::v24::tds::{TdsModel, TubeCoefficients};
use musebots_vocaltract::v24::tube::{Tube, FIRST_FOSSA_SECTION, FIRST_PHARYNX_SECTION, FOSSA_COUPLING_SECTION, LAST_FOSSA_SECTION, LAST_MOUTH_SECTION, MIN_AREA_CM2};
use std::fmt::Write;

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let mut sp = Speaker::read(&args[0]).expect("speaker");
    if let Ok(fossa) = std::env::var("FOSSA") {
        let v: Vec<f64> = fossa.split(',').map(|x| x.parse().expect("FOSSA=LENGTH_CM,VOLUME_CM3")).collect();
        sp.tract.anatomy.piriform_fossa_length_cm = v[0];
        sp.tract.anatomy.piriform_fossa_volume_cm3 = v[1];
    }
    // (VENTRICLE=VOLUME_CM3: the laryngeal ventricle, as vtl-stream's ventricle= lays it.)
    if let Ok(v) = std::env::var("VENTRICLE") {
        sp.tract.anatomy.ventricle_cm3 = v.parse().expect("VENTRICLE=VOLUME_CM3");
    }
    // (ANATOMY=singer,<thirteen measures>, as vtl-stream's anatomy= takes them and lays them: a chorister's body as it
    // is sung -- its speaker file holds only its blend, its measures being laid as the voice starts.)
    if let Ok(asked) = std::env::var("ANATOMY") {
        if let Some(x) = musebots_vocaltract::v24::anatomy::asked(&asked).expect("ANATOMY") {
            let reference = sp.tract.clone();
            x.lay(&mut sp.tract, &reference);
        }
    }
    let folder = &args[1];
    let shapes: Vec<String> = args.get(2).map_or(vec!["a".into(), "i".into(), "u".into()], |s| s.split(',').map(String::from).collect());
    let top: f64 = args.get(3).map_or(20000.0, |s| s.parse().expect("the top frequency"));
    let step: f64 = args.get(4).map_or(2.0, |s| s.parse().expect("the grid's step"));
    let switches: Vec<String> = std::env::var("FORK_SWITCHES").unwrap_or_default().split_whitespace().map(String::from).collect();
    let glottis_cm2: f64 = std::env::var("GLOTTIS_CM2").ok().map_or(MIN_AREA_CM2, |s| s.parse().expect("GLOTTIS_CM2"));
    std::fs::create_dir_all(folder).expect("the folder");
    let mut options = TdsModel::new().options;
    options.generate_noise_sources = false;
    PassiveModel::layout_switches(&mut options, &switches);
    let (_, steps) = PassiveModel::for_speaker(&sp.tract, &sp.glottis, options);
    let rate = 48000.0 * steps as f64;
    let mut glottis = sp.glottis.clone();
    glottis.calc_geometry();
    let (lengths, _) = glottis.tube_data();
    for asked in &shapes {
        // (name@shape:PARAM=value:...: the shape with those parameters its own, written under the name)
        let (name, spec) = asked.split_once('@').unwrap_or((asked.as_str(), asked.as_str()));
        let mut parts = spec.split(':');
        let shape = parts.next().unwrap();
        let mut params = sp.tract.shape(shape).unwrap_or_else(|| panic!("no shape {shape} in {}", args[0]));
        for own in parts {
            let (param, value) = own.split_once('=').expect("PARAM=value");
            let k = sp.tract.param.iter().position(|p| p.name == param).unwrap_or_else(|| panic!("no parameter {param}"));
            params[k] = value.parse().expect("a parameter's value");
        }
        let mut tract = sp.tract.clone();
        tract.calculate(&params);
        let mut tube = Tube::new();
        tube.set_from_tract(&tract.tube());
        // (LARYNX_TUBE=SECTIONS,LENGTH_FACTOR,AREA_FACTOR and PHARYNX_ABOVE=SECTIONS,AREA_FACTOR: the tube's first
        // sections from the glottis lengthened and narrowed or widened, and those above them widened -- a singer's
        // larynx tube and lower pharynx tried on the tube itself, before any anatomy lays them: design H1's question,
        // whether the upper resonances gather.)
        let numbers = |name: &str| std::env::var(name).ok().map(|v| v.split(',').map(|x| x.parse::<f64>().expect("a number")).collect::<Vec<f64>>());
        let larynx = numbers("LARYNX_TUBE");
        if let Some(v) = &larynx {
            for s in tube.section[FIRST_PHARYNX_SECTION..FIRST_PHARYNX_SECTION + v[0] as usize].iter_mut() {
                s.length_cm *= v[1];
                s.area_cm2 *= v[2];
                s.volume_cm3 = s.length_cm * s.area_cm2;
            }
        }
        if let Some(v) = numbers("PHARYNX_ABOVE") {
            let from = FIRST_PHARYNX_SECTION + larynx.as_ref().map_or(0, |l| l[0] as usize);
            for s in tube.section[from..from + v[0] as usize].iter_mut() {
                s.area_cm2 *= v[1];
                s.volume_cm3 = s.length_cm * s.area_cm2;
            }
        }
        if larynx.is_some() {
            let mut pos = tube.section[FIRST_PHARYNX_SECTION].pos_cm;
            for s in tube.section[FIRST_PHARYNX_SECTION..=LAST_MOUTH_SECTION].iter_mut() {
                s.pos_cm = pos;
                pos += s.length_cm;
            }
        }
        if std::env::var("AREAS").is_ok() {
            let sections = &tube.section[FIRST_PHARYNX_SECTION..=LAST_MOUTH_SECTION];
            let from = sections[0].pos_cm;
            println!("/{name}/: its area function, cm from the glottis: cm2 -- {}", sections.iter().map(|s| format!("{:.1}: {:.2}", s.pos_cm - from, s.area_cm2)).collect::<Vec<_>>().join(", "));
            let fossa = &tube.section[FIRST_FOSSA_SECTION..=LAST_FOSSA_SECTION];
            println!("   its fossa off section {FOSSA_COUPLING_SECTION}: {}", fossa.iter().map(|s| format!("{:.2} cm of {:.2} cm2", s.length_cm, s.area_cm2)).collect::<Vec<_>>().join(", "));
        }
        let mut tds = TdsModel::new();
        tds.options = options;
        tds.set_tube(&tube, false);
        let mut k = TubeCoefficients::default();
        tds.tube_coefficients(&mut k);
        let (mut model, _) = PassiveModel::for_speaker(&sp.tract, &sp.glottis, options);
        model.take_switches(&switches);
        model.set_rate(rate);
        model.set_glottis_sections(&lengths, &[glottis_cm2; 2]);
        model.set_pressure_source(0.0, 0);
        let network = model.network(&k);
        let mut text = String::from("freq_Hz  magnitude  phase_rad\n");
        let mut f = step;
        while f <= top {
            let r = network.response(Complex::tone(f), Stepping::Stepped).mouth;
            writeln!(text, "{f} {} {}", r.abs(), r.im.atan2(r.re)).unwrap();
            f += step;
        }
        // (a disk that does not tell case apart: a capital's name spelled out)
        let name: String = name.chars().map(|c| if c.is_uppercase() { format!("{c}-capital") } else { c.to_string() }).collect();
        let file = format!("{folder}/{name}-vvtf-engine.txt");
        std::fs::write(&file, text).expect("the transfer's file");
        println!("{file}: /{spec}/ to {top} Hz every {step} Hz, the glottis {glottis_cm2} cm2{}", if switches.is_empty() { String::new() } else { format!(", {}", switches.join(" ")) });
    }
}
