// The glottis's jitter alone (no acoustics): a speaker's modal glottis stepped at a rate, its phase's crossings of each
// whole cycle timed (interpolated between steps), and the jitter measured as clinicians measure it -- the mean absolute
// difference of consecutive periods over the mean period, percent -- with 2.4's white phase kicks and with them
// band-limited at f0 (Glottis2025::jitter_band_limited); and the glottal area's spectrum, third-octave bands relative to
// its whole, where the white kicks leave their floor (GLOTTIS_JITTER_BANDS=1: a plain DFT, slow).
//   cargo run --release --example glottis_jitter -- <speaker.speaker> [seconds] [steps a sample]
use musebots_vocaltract::v24::glottis::PRESSURE;
use musebots_vocaltract::v24::speaker::Speaker;

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let sp = Speaker::read(&args[0]).expect("speaker");
    let seconds: f64 = args.get(1).and_then(|x| x.parse().ok()).unwrap_or(30.0);
    let n: usize = args.get(2).and_then(|x| x.parse().ok()).unwrap_or(5);
    let rate = 48000.0 * n as f64;
    let dt = 1.0 / rate;
    for limited in [false, true] {
        let mut g = sp.glottis.clone();
        g.mended = true;
        g.jitter_band_limited = limited;
        g.rate_hz = rate;
        g.reset_motion();
        let shape = g.shapes.iter().find(|(name, _)| name == "modal").unwrap().1.clone();
        for (k, p) in g.control.iter_mut().enumerate() {
            p.x = shape[k];
        }
        g.control[PRESSURE].x = 8000.0;
        let steps = (seconds * rate) as usize;
        let (mut crossings, mut area) = (Vec::new(), Vec::with_capacity(steps.min(48000 * n * 2)));
        let mut last = g.phase;
        for i in 0..steps {
            g.calc_geometry();
            if area.len() < 2 * 48000 * n {
                let (_, a) = g.tube_data();
                area.push(a[0].min(a[1]));
            }
            g.inc_time(dt, &[0.0; 4]);
            let cycle = (g.phase / (2.0 * std::f64::consts::PI)).floor();
            if cycle > (last / (2.0 * std::f64::consts::PI)).floor() {
                let target = cycle * 2.0 * std::f64::consts::PI;
                crossings.push((i as f64 + (target - last) / (g.phase - last)) * dt);
            }
            last = g.phase;
        }
        let periods: Vec<f64> = crossings.windows(2).map(|w| w[1] - w[0]).collect();
        let mean = periods.iter().sum::<f64>() / periods.len() as f64;
        let jitter = periods.windows(2).map(|w| (w[1] - w[0]).abs()).sum::<f64>() / (periods.len() - 1) as f64 / mean * 100.0;
        // (the area's last second's third-octave bands, re its whole, from a plain DFT on a decimated grid of bins)
        let x: Vec<f64> = area[area.len() - 48000 * n..].to_vec();
        let m = x.iter().sum::<f64>() / x.len() as f64;
        let len = x.len();
        let band = |fc: f64| -> f64 {
            let (lo, hi) = (fc * 2f64.powf(-1.0 / 6.0), fc * 2f64.powf(1.0 / 6.0));
            let mut p = 0.0;
            let mut f = lo.ceil();
            while f < hi {
                let (mut re, mut im) = (0.0, 0.0);
                for (j, v) in x.iter().enumerate() {
                    let w = 0.5 - 0.5 * (2.0 * std::f64::consts::PI * j as f64 / len as f64).cos();
                    let ph = 2.0 * std::f64::consts::PI * f * j as f64 / rate;
                    re += w * (v - m) * ph.cos();
                    im -= w * (v - m) * ph.sin();
                }
                p += re * re + im * im;
                f += 1.0;
            }
            p
        };
        let bands: Vec<String> = if std::env::var("GLOTTIS_JITTER_BANDS").is_ok() {
            let low = band(120.0) + band(250.0) + band(500.0) + band(1000.0);
            [2000.0, 4000.0, 8000.0, 16000.0, 32000.0].iter().map(|&fc| format!("{:.1}", 10.0 * (band(fc) / low).log10())).collect()
        } else {
            vec!["-".into()]
        };
        println!(
            "{}: jitter {}%, {} periods, mean {:.3} ms (f0 {:.2} Hz); the area's bands at 2, 4, 8, 16, 32 kHz re its lowest four (dB): {}",
            if limited { "band-limited at f0" } else { "2.4's white kicks" },
            format!("{jitter:.3}"),
            periods.len(),
            mean * 1000.0,
            1.0 / mean,
            bands.join(" ")
        );
    }
}
