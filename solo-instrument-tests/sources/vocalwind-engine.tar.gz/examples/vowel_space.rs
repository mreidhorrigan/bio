// The vowel space checked on the engine (src/vowel_space.rs; research/VOCALWIND_LANGUAGES.md, design 4), its anchors
// placed by their sound (languages/vowel-space.json `anchors.placed`; the owner, 15 November 2026: "Proceed according to
// your recommendation"). Resonances as carry::resonances finds them (the glottis closed, an impulse of flow, the
// radiated flow's peaks); a speaker's vowels' places from their own first two.
//   1. each of a speaker's vowels rebuilt from its others where its sound puts it (the interpolation alone; those at its
//      symbol's place left out too), its first three resonances in cents from its own;
//   2. on a speaker with shapes learned from the speech2vocaltract corpus, the space's [ɑ ʌ ɯ] (by their symbols)
//      against them, and against the stand-ins they had;
//   3. each of the speaker's vowels' symbols from the space, against its own: how far its own is from where the chart
//      puts its symbol among its others;
//   r-colouring: the speaker's rhotic shape (languages/vowel-space.json `anchors.rhotic`) where its sound puts it, and
//      the space's r-coloured vowels beside their uncoloured;
//   4. separation (the owner, 15 November 2026: "separation of sounds within a language (e.g., on the vowel chart) is
//      important for intelligibility"): each language's vowels as the voice says them now (the language's table, the
//      speaker's shape or its stand-in), from the space at their letters' places, and from the space where the
//      language's measured speakers put them (languages/vowel-places.json) at clarity 0, 1 and the most measured, each
//      one's nearest other in Bark (F1, F2); and as the voice says them on the speaker made to sing the language
//      (src/blend.rs Sung, clarity 0), which is to be the measured at clarity 0 but at the space's corners.
//   cargo run --release --example vowel_space -- [JD2,M01,W02]
use musebots_vocaltract::blend::{self, Sung, Voices};
use musebots_vocaltract::carry::resonances;
use musebots_vocaltract::inventory;
use musebots_vocaltract::phones;
use musebots_vocaltract::v24::speaker::Speaker;
use musebots_vocaltract::v24::tract::{VocalTract, NUM_PARAMS};
use musebots_vocaltract::vowel_space::{bark, places, space, Anchor, Place, SpeakerSpace};

const TOP_HZ: f64 = 5000.0;
// (English's monophthongs as the soloist's dictionary gives them -- AA AE AH AO EH ER IH IY UH UW, AH and ER
// unstressed [ə ɚ] -- and Latin's, as the Church sings it, its e and o open and closed.)
const LANGUAGES: [(&str, &str); 2] = [("en", "i,ɪ,ɛ,æ,ɑ,ɔ,ʊ,u,ʌ,ə,ɝ"), ("la", "a,e,ɛ,i,o,ɔ,u")];

fn formants(tract: &mut VocalTract, shape: &[f64; NUM_PARAMS]) -> Vec<f64> {
    let mut v = *shape;
    for (k, x) in v.iter_mut().enumerate() {
        *x = x.clamp(tract.param[k].min, tract.param[k].max);
    }
    tract.calculate(&v);
    resonances(&tract.tube(), TOP_HZ).into_iter().take(3).collect()
}

fn cents(a: &[f64], b: &[f64]) -> Vec<f64> {
    a.iter().zip(b).map(|(x, y)| 1200.0 * (x / y).log2()).collect()
}

fn show(f: &[f64]) -> String {
    f.iter().map(|x| format!("{x:6.0}")).collect()
}

fn show_cents(c: &[f64]) -> String {
    c.iter().map(|x| format!("{x:6.0}")).collect()
}

fn rms(errors: &[Vec<f64>], k: usize) -> (f64, f64) {
    let xs: Vec<f64> = errors.iter().filter_map(|c| c.get(k)).cloned().collect();
    ((xs.iter().map(|x| x * x).sum::<f64>() / xs.len() as f64).sqrt(), xs.iter().map(|x| x.abs()).fold(0.0, f64::max))
}

fn spread(errors: &[Vec<f64>]) -> String {
    format!("rms {}  largest {}", (0..3).map(|k| format!("{:5.0}", rms(errors, k).0)).collect::<String>(), (0..3).map(|k| format!("{:5.0}", rms(errors, k).1)).collect::<String>())
}

/// The shape the voice says a language's vowel with now: its table's phone's, else its stand-in's, else the shared
/// nearest's (ssml.rs Phone::on, segments.rs vowel_shape_on).
fn said_now(tract: &VocalTract, ipa: &str, language: &str) -> Option<(String, [f64; NUM_PARAMS])> {
    let (found, _) = phones::phones_in(ipa, language)?;
    let phone = *found.first()?;
    let shape = inventory::phone(phone)?.vowel_shape()?;
    let candidates = [Some(shape.to_string()), phones::stand_in(ipa, language).and_then(|s| s.first().and_then(|p| inventory::phone(p)).and_then(|p| p.vowel_shape()).map(String::from)), phones::nearest_phone(phone).and_then(inventory::phone).and_then(|p| p.vowel_shape()).map(String::from)];
    candidates.into_iter().flatten().find_map(|n| tract.shape(&n).map(|v| (n, v)))
}

fn separation(tract: &mut VocalTract, sung: &mut VocalTract, sp: &SpeakerSpace, language: &str, vowels: &str) {
    let s = space();
    let most = places().most_clarity();
    let list: Vec<&str> = vowels.split(',').collect();
    let mut shapes = Vec::new();
    // The ways each vowel is said: as the voice says it now, from the space at its letter's place, and from the space
    // where the language's measured speakers put it at clarity 0, 1 and the most.
    let mut ways: Vec<(String, Vec<Option<Vec<f64>>>)> = vec![("now".into(), Vec::new()), ("symbol".into(), Vec::new())];
    let clarities = [0.0, 1.0, most];
    for c in clarities {
        ways.push((format!("measured {c:.2}"), Vec::new()));
    }
    ways.push(("sung".into(), Vec::new()));
    for ipa in &list {
        let said = said_now(tract, ipa, language);
        shapes.push(said.as_ref().map_or("-".to_string(), |(n, _)| n.clone()));
        ways[0].1.push(said.map(|(_, v)| formants(tract, &v)));
        ways[1].1.push(Some(formants(tract, &sp.at(s.place(ipa).unwrap_or_else(|e| panic!("{e}"))))));
        for (k, c) in clarities.iter().enumerate() {
            ways[2 + k].1.push(Some(formants(tract, &sp.at(s.place_in(ipa, language, *c).unwrap_or_else(|e| panic!("{e}"))))));
        }
        let last = ways.len() - 1;
        ways[last].1.push(said_now(sung, ipa, language).map(|(_, v)| formants(sung, &v)));
    }
    let nearest = |sounds: &[Option<Vec<f64>>], i: usize| -> (f64, String) {
        let Some(a) = &sounds[i] else { return (f64::NAN, "-".into()) };
        let mut best = (f64::MAX, String::new());
        for (j, b) in sounds.iter().enumerate() {
            if let (true, Some(b)) = (j != i, b) {
                let d = ((bark(a[0]) - bark(b[0])).powi(2) + (bark(a[1]) - bark(b[1])).powi(2)).sqrt();
                if d < best.0 {
                    best = (d, list[j].to_string());
                }
            }
        }
        best
    };
    println!("  {language}: each vowel's F1 F2 (Hz) and its nearest other (Bark), {}", ways.iter().map(|w| w.0.as_str()).collect::<Vec<_>>().join(" | "));
    for (i, ipa) in list.iter().enumerate() {
        let cells: Vec<String> = ways
            .iter()
            .map(|(_, f)| {
                let (d, w) = nearest(f, i);
                match &f[i] {
                    Some(f) => format!("{:5.0}{:5.0} {d:4.2} [{w}]", f[0], f[1]),
                    None => "    -    -    -     ".into(),
                }
            })
            .collect();
        println!("   [{ipa}] {:>5} {}", shapes[i], cells.join(" |"));
    }
    for (name, f) in &ways {
        let d: Vec<(f64, String)> = (0..list.len()).map(|i| nearest(f, i)).filter(|(d, _)| d.is_finite()).collect();
        let least = d.iter().enumerate().min_by(|a, b| a.1 .0.total_cmp(&b.1 .0)).map(|(i, (x, w))| format!("{x:.2} [{}] [{w}]", list[i])).unwrap_or_default();
        let mean = d.iter().map(|x| x.0).sum::<f64>() / d.len() as f64;
        println!("   {name:>14}: least apart {least}; each one's nearest, mean {mean:.2} Bark");
    }
}

fn least_area(tract: &mut VocalTract, shape: &[f64; NUM_PARAMS]) -> f64 {
    let v: [f64; NUM_PARAMS] = std::array::from_fn(|k| shape[k].clamp(tract.param[k].min, tract.param[k].max));
    tract.calculate(&v);
    musebots_vocaltract::carry::least_closable_area(&tract.tube())
}

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let speakers: Vec<String> = args.first().map_or("JD2,M01,W02".into(), |s| s.clone()).split(',').map(String::from).collect();
    let voices = Voices::read(&blend::voices_file()).unwrap_or_else(|e| panic!("{e}"));
    let home = blend::synthesis_home();
    let s = space();
    let (mut all_sound, mut all_symbol) = (Vec::new(), Vec::new());
    for id in &speakers {
        let text = voices.blend_text(&home, &format!("{id}=1")).unwrap_or_else(|e| panic!("{e}"));
        let mut tract = Speaker::parse(&text).unwrap_or_else(|e| panic!("{id}: {e}")).tract;
        let by_symbol: Vec<Anchor> = s.anchors(|n| tract.shape(n));
        let own: Vec<Vec<f64>> = by_symbol.iter().map(|a| formants(&mut tract, &a.params)).collect();
        let mut anchors = by_symbol.clone();
        let map = s.place_by_sound(&mut anchors, &own.iter().map(|f| (f[0], f[1])).collect::<Vec<_>>()).unwrap_or_else(|e| panic!("{e}"));
        println!("{id}: {} anchors, each by its symbol's place and its sound's (row, column)", anchors.len());
        for (a, b) in by_symbol.iter().zip(&anchors) {
            println!("  {:>6}  {:4.1} {:4.2}  ->  {:5.2} {:5.2}", a.name, a.place.row, a.place.column, b.place.row, b.place.column);
        }
        println!("  1. each rebuilt from the others where its sound puts it: its own (Hz), the space's, cents");
        let mut errors = Vec::new();
        for (k, a) in anchors.iter().enumerate() {
            let others: Vec<Anchor> = anchors.iter().zip(&by_symbol).filter(|(_, b)| b.place != by_symbol[k].place).map(|(a, _)| a.clone()).collect();
            let got = formants(&mut tract, &s.speaker(&others).unwrap_or_else(|e| panic!("{e}")).at(a.place));
            let c = cents(&got, &own[k]);
            println!("  {:>6} {}  {}  {}", a.name, show(&own[k]), show(&got), show_cents(&c));
            errors.push(c);
        }
        println!("  spread, F1 F2 F3: {}", spread(&errors));
        all_sound.extend(errors);
        let mut sp = s.speaker(&anchors).unwrap_or_else(|e| panic!("{e}"));
        if let Some(name) = s.rhotic_shape() {
            match tract.shape(name) {
                Some(r) => {
                    let f = formants(&mut tract, &r);
                    let at = s.rhotic_place(Some(&map), (f[0], f[1])).unwrap_or_else(|e| panic!("{e}"));
                    sp.colour(r, at);
                    let plain = formants(&mut tract, &sp.at(Place { rhotic: 0.0, ..at }));
                    println!("  r-colouring: /{name}/ {} at row {:4.2} column {:4.2}; there uncoloured {}", show(&f), at.row, at.column, show(&plain));
                    for ipa in ["ɝ", "ɚ", "ɑ˞", "i˞"] {
                        let p = s.place(ipa).unwrap();
                        let (with, without) = (formants(&mut tract, &sp.at(p)), formants(&mut tract, &sp.at(Place { rhotic: 0.0, ..p })));
                        println!("   [{ipa}] {}  uncoloured {}  ({})", show(&with), show(&without), show_cents(&cents(&with, &without)));
                    }
                }
                None => println!("  r-colouring: no /{name}/ (an r-coloured vowel sung as the vowel it colours)"),
            }
        }
        println!("  2. the corpus's learned sounds: the space's by their symbols, and their stand-ins', cents from them");
        for (ipa, learned, stand_in) in [("ɑ", "A", "a"), ("ʌ", "V", "a"), ("ɯ", "M", "u")] {
            let Some(l) = tract.shape(learned) else { continue };
            let theirs = formants(&mut tract, &l);
            let made = formants(&mut tract, &sp.at(s.place(ipa).unwrap()));
            let near = tract.shape(stand_in).unwrap();
            let near = formants(&mut tract, &near);
            println!("   [{ipa}] learned {}  space {} ({})  stand-in /{stand_in}/ {} ({})", show(&theirs), show(&made), show_cents(&cents(&made, &theirs)), show(&near), show_cents(&cents(&near, &theirs)));
        }
        println!("  3. each vowel's symbol from the space against the speaker's own, cents");
        let mut moved = Vec::new();
        for (k, a) in by_symbol.iter().enumerate() {
            let got = formants(&mut tract, &sp.at(a.place));
            let c = cents(&got, &own[k]);
            println!("  {:>6} {}  {}  {}", a.name, show(&own[k]), show(&got), show_cents(&c));
            moved.push(c);
        }
        println!("  spread, F1 F2 F3: {}", spread(&moved));
        all_symbol.extend(moved);
        println!("  4. separation, the space extended beyond the speaker's vowels (Space::of_speaker)");
        let extended = s.of_speaker(&mut tract).unwrap_or_else(|e| panic!("{e}")).space;
        let t = std::time::Instant::now();
        let _ = s.of_speaker(&mut tract);
        println!("  sounded, extended, in {:.2} s; each vertex's push (row, column: factor): {}", t.elapsed().as_secs_f64(), extended.pushes().iter().map(|(p, _, k)| format!("{:.2},{:.2}: {k:.3}", p.row, p.column)).collect::<Vec<_>>().join("; "));
        // (Each pushed point's least closable area as the space makes it there, at its vertex's rounding and fully
        // rounded, against the narrowest of the speaker's own vowels.)
        let narrowest = s.anchors(|n| tract.shape(n)).iter().map(|a| least_area(&mut tract, &a.params)).fold(f64::INFINITY, f64::min);
        let opened: Vec<String> = extended.pushes().iter().map(|&(_, o, _)| {
            let [u, r] = [0.0, 1.0].map(|f| least_area(&mut tract, &extended.at(Place { rounding: f, ..o })));
            format!("{u:.2}/{r:.2}")
        }).collect();
        println!("  least closable area (cm2) at each pushed point, unrounded/rounded, against the speaker's narrowest vowel's {narrowest:.2}: {}", opened.join("; "));
        for (language, vowels) in LANGUAGES {
            let made = voices.blend_sung(&home, &format!("{id}=1"), Some(&Sung { language: language.into(), clarity: 0.0 })).unwrap_or_else(|e| panic!("{e}")).0;
            let mut sung = Speaker::parse(&made).unwrap_or_else(|e| panic!("{id}: {e}")).tract;
            separation(&mut tract, &mut sung, &extended, language, vowels);
        }
    }
    println!("every speaker's: 1 (rebuilt where its sound is) {}", spread(&all_sound));
    println!("every speaker's: 3 (its symbol from the space)  {}", spread(&all_symbol));
}
