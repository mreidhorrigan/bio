// The port's anatomy from measures (src/v24/anatomy.rs) against VocalTractLab 2.4's own (reference/
// v24_anatomy_parity.cpp): the same speaker, the measures from an age and a sex or given, laid on the tract, and the
// same numbers -- the measures as held; each articulatory parameter's min, max, neutral value and value; each shape's
// 19 values carried over and its tube's 40 sections' areas and lengths -- compared with the reference's file, to the bit
// or by how far.
//   cargo run --release --example v24_anatomy_parity -- JD2.speaker reference.f64 age 120 female
//   cargo run --release --example v24_anatomy_parity -- JD2.speaker reference.f64 measures 1.0,1.2,...
use musebots_vocaltract::v24::anatomy::{self, NUM_ANATOMY_PARAMS};
use musebots_vocaltract::v24::speaker::Speaker;
use musebots_vocaltract::v24::tract::NUM_PARAMS;

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let sp = Speaker::read(&args[0]).expect("speaker");
    let reference = sp.tract.clone();
    let mut tract = sp.tract.clone();
    let x: [f64; NUM_ANATOMY_PARAMS] = if args[2] == "age" {
        anatomy::from_age(args[3].parse().expect("months"), args.get(4).map_or(false, |s| s == "male"))
    } else {
        let v: Vec<f64> = args[3].split(',').map(|s| s.parse().expect("a measure")).collect();
        v.try_into().expect("thirteen measures")
    };
    anatomy::set_for(&x, &mut tract, &reference);
    let mut held = x;
    anatomy::restrict(&mut held);
    let mut out: Vec<(String, f64)> = held.iter().enumerate().map(|(i, v)| (format!("measure {}", anatomy::ANATOMY_PARAMS[i].key), *v)).collect();
    for (k, p) in tract.param.iter().enumerate() {
        for (what, v) in [("min", p.min), ("max", p.max), ("neutral", p.neutral), ("value", p.x)] {
            out.push((format!("{} {what}", p.name.clone() + &format!(" ({k})")), v));
        }
    }
    let shapes = tract.shapes.clone();
    for (name, v) in &shapes {
        for k in 0..NUM_PARAMS {
            out.push((format!("shape {name} param {k}"), v[k]));
        }
        tract.calculate(v);
        let t = tract.tube();
        for k in 0..t.area_cm2.len() {
            out.push((format!("shape {name} section {k} area"), t.area_cm2[k]));
            out.push((format!("shape {name} section {k} length"), t.length_cm[k]));
        }
    }
    let theirs: Vec<f64> = std::fs::read(&args[1]).expect("the reference's numbers").chunks_exact(8).map(|b| f64::from_le_bytes(b.try_into().unwrap())).collect();
    if theirs.len() != out.len() {
        println!("v24_anatomy_parity: {} numbers here, {} in the reference", out.len(), theirs.len());
        std::process::exit(1);
    }
    let differ: Vec<(usize, f64)> = out.iter().zip(&theirs).enumerate().filter(|(_, ((_, a), b))| a.to_bits() != b.to_bits()).map(|(i, ((_, a), b))| (i, (a - b).abs())).collect();
    let worst = differ.iter().fold((0usize, 0.0f64), |w, &(i, d)| if d > w.1 { (i, d) } else { w });
    println!(
        "v24_anatomy_parity: {} shapes, {} numbers; {} differ{}",
        shapes.len(),
        out.len(),
        differ.len(),
        if differ.is_empty() { ", every one the reference's to the bit".to_string() } else { format!(" -- the first: {} ({} here, {} there); the most: {} by {:.3e}", out[differ[0].0].0, out[differ[0].0].1, theirs[differ[0].0], out[worst.0].0, worst.1) }
    );
    if !differ.is_empty() {
        std::process::exit(1);
    }
}
