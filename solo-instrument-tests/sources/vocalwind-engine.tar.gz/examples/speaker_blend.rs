// Singers' bodies weighed from speakers (src/blend.rs, voices/speakers.json; the owner, 15 November 2026), and their
// checks on the 2.4 engine (research/VOCALWIND_CHOIR.md).
//   write: the speakers weighed as asked, as a speaker file any tool reads.
//   line: two speakers and the bodies between them, weighed in `steps` equal steps: each vowel's first four
//     resonances (carry::resonances: the glottis closed, an impulse of flow, the radiated flow's peaks) and its tube's
//     length at each step, and where a resonance turns back on its way from one speaker's to the other's.
//   rule: a speaker's tongue root at each of its shapes, as stored and as its rule computes it (2.4's
//     automatic_calc: the root's two parameters from the tongue body's place and the hyoid's).
//   cargo run --release --example speaker_blend -- write <out.speaker> JD2=0.3,W02=0.7
//   cargo run --release --example speaker_blend -- line JD2 W02 [steps=10] [a,e,i,o,u]
//   cargo run --release --example speaker_blend -- rule JD2
use musebots_vocaltract::blend::{self, Voices};
use musebots_vocaltract::carry::resonances;
use musebots_vocaltract::v24::speaker::Speaker;
use musebots_vocaltract::v24::tract::{VocalTract, TRX, TRY};

const TOP_HZ: f64 = 5000.0;

fn speaker(voices: &Voices, home: &str, asked: &str) -> Speaker {
    Speaker::parse(&voices.blend_text(home, asked).unwrap_or_else(|e| panic!("{e}"))).unwrap_or_else(|e| panic!("{asked}: {e}"))
}

fn vowel(tract: &mut VocalTract, name: &str) -> Option<(Vec<f64>, f64)> {
    let shape = tract.shape(name)?;
    tract.calculate(&shape);
    let tube = tract.tube();
    Some((resonances(&tube, TOP_HZ).into_iter().take(4).collect(), tube.length_cm.iter().sum()))
}

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let voices = Voices::read(&blend::voices_file()).unwrap_or_else(|e| panic!("{e}"));
    let home = blend::synthesis_home();
    match args.first().map(String::as_str) {
        Some("write") => {
            let text = voices.blend_text(&home, &args[2]).unwrap_or_else(|e| panic!("{e}"));
            Speaker::parse(&text).unwrap_or_else(|e| panic!("the blend does not read back: {e}"));
            std::fs::write(&args[1], text).unwrap_or_else(|e| panic!("{}: {e}", args[1]));
            println!("{}: {}", args[1], args[2]);
        }
        Some("rule") => {
            let mut sp = speaker(&voices, &home, &format!("{}=1", args[1]));
            println!("the rule's share: {}", sp.tract.anatomy.tongue_root_rule);
            let shapes = sp.tract.shapes.clone();
            let mut worst: f64 = 0.0;
            for (name, v) in &shapes {
                sp.tract.calculate(v);
                let (x, y) = (sp.tract.param[TRX].x, sp.tract.param[TRY].x);
                println!("{name:>32}  TRX stored {:8.4} ruled {x:8.4}   TRY stored {:8.4} ruled {y:8.4}", v[TRX], v[TRY]);
                worst = worst.max((x - v[TRX]).abs()).max((y - v[TRY]).abs());
            }
            println!("largest difference: {worst:.4} cm");
            // (Between two shapes, the parameters moved in a straight line: the root as the rule makes it, against the
            // root moved straight from the one shape's ruled root to the other's.)
            let ruled = |t: &mut VocalTract, v: &[f64]| {
                t.calculate(v);
                (t.param[TRX].x, t.param[TRY].x)
            };
            let mut worst: (f64, String) = (0.0, String::new());
            let names: Vec<String> = shapes.iter().map(|(n, _)| n.clone()).filter(|n| !n.ends_with("-raw")).collect();
            for (i, p) in names.iter().enumerate() {
                for q in &names[i + 1..] {
                    let (u, v) = (sp.tract.shape(p).unwrap(), sp.tract.shape(q).unwrap());
                    let (r0, r1) = (ruled(&mut sp.tract, &u), ruled(&mut sp.tract, &v));
                    for k in 1..10 {
                        let f = k as f64 / 10.0;
                        let mid: Vec<f64> = u.iter().zip(&v).map(|(a, b)| a + f * (b - a)).collect();
                        let r = ruled(&mut sp.tract, &mid);
                        let d = (r.0 - (r0.0 + f * (r1.0 - r0.0))).abs().max((r.1 - (r0.1 + f * (r1.1 - r0.1))).abs());
                        if d > worst.0 {
                            worst = (d, format!("{p} to {q} at {f:.1}"));
                        }
                    }
                }
            }
            println!("between shapes, the rule from the straight line at most: {:.4} cm ({})", worst.0, worst.1);
        }
        Some("line") => {
            let (a, b) = (&args[1], &args[2]);
            let steps: usize = args.get(3).map_or(10, |s| s.parse().expect("steps"));
            let vowels: Vec<String> = args.get(4).map_or("a,e,i,o,u".into(), |s| s.clone()).split(',').map(String::from).collect();
            let mut tracts: Vec<VocalTract> = (0..=steps)
                .map(|k| {
                    let w = k as f64 / steps as f64;
                    speaker(&voices, &home, &format!("{a}={},{b}={}", 1.0 - w, w)).tract
                })
                .collect();
            let mut worst = (0.0f64, String::new());
            for v in &vowels {
                println!("/{v}/  weight of {b}, resonances (Hz), tube (cm)");
                let line: Vec<Option<(Vec<f64>, f64)>> = tracts.iter_mut().map(|t| vowel(t, v)).collect();
                for (k, f) in line.iter().enumerate() {
                    match f {
                        Some((f, cm)) => println!("  {:4.2} {} {cm:6.2}", k as f64 / steps as f64, f.iter().map(|x| format!("{x:6.0}")).collect::<String>()),
                        None => println!("  {:4.2} (no such shape)", k as f64 / steps as f64),
                    }
                }
                // (A resonance's way from the first to the last: where a step goes against it, by how many cents.)
                let (Some((first, _)), Some((last, _))) = (&line[0], &line[steps]) else { continue };
                for r in 0..first.len().min(last.len()) {
                    let up = last[r] >= first[r];
                    for k in 1..=steps {
                        if let (Some((p, _)), Some((q, _))) = (&line[k - 1], &line[k]) {
                            if r < p.len() && r < q.len() {
                                let c = 1200.0 * (q[r] / p[r]).log2();
                                let back = if up { -c } else { c };
                                if back > worst.0 {
                                    worst = (back, format!("/{v}/ F{} between {:.2} and {:.2}", r + 1, (k - 1) as f64 / steps as f64, k as f64 / steps as f64));
                                }
                            }
                        }
                    }
                }
            }
            println!("largest step against a resonance's way: {:.0} cents ({})", worst.0, if worst.1.is_empty() { "none" } else { &worst.1 });
        }
        _ => {
            eprintln!("usage: speaker_blend write <out.speaker> <id=weight,...> | line <id> <id> [steps] [vowels] | rule <id>");
            std::process::exit(2);
        }
    }
}
