// Where VocalTractLab 2.4's aliasing comes from (the owner, 11 November 2026: "I'm skeptical of oversampling up to
// 96kHz. Make sure we understand the reason for the noise, and we'll choose the most efficient way to mitigate it. I can
// certainly hear the aliasing problem even at lower frequencies"). A held vowel at an F0 that does not divide 48 kHz,
// its noise sources, jitter and flutter off: what it radiates is then periodic but for what sampling folds -- a
// harmonic of the source above 24 kHz comes back between the harmonics below it -- so all that lies off the harmonics
// is aliasing. Measured three ways, each the engine's own loop (Synthesizer::addSample's, its radiation the flow's
// difference, as an LTI filter shapes but cannot alias):
//   engine      -- as 2.4 makes it: the glottis's area computed at each sample;
//   area-clean  -- the same, the glottis's two areas given band-limited instead: each its own Fourier series over one
//                  period (4096 points of its phase), summed to 22 kHz, so the source brings no alias of its own;
//   noise       -- the engine with its noise sources on, for what they put in the high band;
//   96k, 192k   -- the engine with its acoustics and glottis stepped at 96 or 192 kHz (its rate-bound filters, at 25
//                  and 50 Hz, then lower, which a held vowel does not feel), what lies below 24 kHz of it: if the
//                  off-harmonic power is sampling's, it falls as the rate rises; what lies above 24 kHz said apart.
// And the glottal area itself: how much of its power lies above 24 kHz (what folds), and its sampled sequence's alias.
// Each band's power off the harmonics, in dB under the band's harmonics (and under the whole), over the last 65,536
// samples of 2 s (Blackman-Harris window). Measurement only: nothing of the model changes.
//   cargo run --release --example v24_aliasing -- JD2.speaker a modal
use musebots_vocaltract::v24::constants::{AUDIO_SAMPLING_RATE_HZ, PI};
use musebots_vocaltract::v24::glottis::{FLUTTER, FREQUENCY, JITTER, PRESSURE};
use musebots_vocaltract::v24::speaker::Speaker;
use musebots_vocaltract::v24::synth::Synthesizer;
use musebots_vocaltract::v24::tds::TdsModel;
use musebots_vocaltract::v24::constants::{DC_EXPONENT, REF_AREA_CM2};
use musebots_vocaltract::v24::tube::{Tube, FIRST_PHARYNX_SECTION, FIRST_TRACHEA_SECTION, LAST_TRACHEA_SECTION, LOWER_GLOTTIS_SECTION, UPPER_GLOTTIS_SECTION};

const RATE: f64 = AUDIO_SAMPLING_RATE_HZ as f64;
const BANDS: [(f64, f64); 8] = [(0.0, 1000.0), (1000.0, 2000.0), (2000.0, 4000.0), (4000.0, 8000.0), (8000.0, 12000.0), (12000.0, 16000.0), (16000.0, 20000.0), (20000.0, 24000.0)];

fn fft(re: &mut [f64], im: &mut [f64]) {
    let n = re.len();
    let mut j = 0;
    for i in 1..n {
        let mut bit = n >> 1;
        while j & bit != 0 {
            j ^= bit;
            bit >>= 1;
        }
        j |= bit;
        if i < j {
            re.swap(i, j);
            im.swap(i, j);
        }
    }
    let mut len = 2;
    while len <= n {
        let w = -2.0 * PI / len as f64;
        for start in (0..n).step_by(len) {
            for k in 0..len / 2 {
                let (s, c) = (w * k as f64).sin_cos();
                let (a, b) = (start + k, start + k + len / 2);
                let (xr, xi) = (re[b] * c - im[b] * s, re[b] * s + im[b] * c);
                re[b] = re[a] - xr;
                im[b] = im[a] - xi;
                re[a] += xr;
                im[a] += xi;
            }
        }
        len <<= 1;
    }
}

/// The power spectrum of a signal's last 65,536 x rate/48 kHz samples (1.37 s), Blackman-Harris windowed.
fn spectrum(x: &[f64], rate: f64) -> Vec<f64> {
    let n_fft = (65536.0 * rate / RATE) as usize;
    let x = &x[x.len() - n_fft..];
    let n = n_fft;
    let mut re: Vec<f64> = x
        .iter()
        .enumerate()
        .map(|(i, v)| {
            let p = 2.0 * PI * i as f64 / (n - 1) as f64;
            v * (0.35875 - 0.48829 * p.cos() + 0.14128 * (2.0 * p).cos() - 0.01168 * (3.0 * p).cos())
        })
        .collect();
    let mut im = vec![0.0; n];
    fft(&mut re, &mut im);
    (0..n / 2).map(|k| re[k] * re[k] + im[k] * im[k]).collect()
}

/// Each band's harmonic and off-harmonic power (a bin within 5 of a harmonic is the harmonic's: the window's main lobe).
fn bands(p: &[f64], f0: f64) -> Vec<(f64, f64)> {
    let bin = RATE / 65536.0;
    BANDS
        .iter()
        .map(|&(lo, hi)| {
            let (mut h, mut o) = (0.0, 0.0);
            for (k, v) in p.iter().enumerate() {
                let f = k as f64 * bin;
                if f < lo.max(30.0) || f >= hi {
                    continue;
                }
                let d = (f - (f / f0).round() * f0).abs();
                if d <= 5.0 * bin {
                    h += v;
                } else {
                    o += v;
                }
            }
            (h, o)
        })
        .collect()
}

fn db(x: f64) -> f64 {
    10.0 * x.max(1e-300).log10()
}

fn report(name: &str, x: &[f64], f0: f64, rate: f64) {
    let p = spectrum(x, rate);
    let b = bands(&p, f0);
    let total: f64 = b.iter().map(|(h, o)| h + o).sum();
    let off: f64 = b.iter().map(|(_, o)| o).sum();
    let above: f64 = p[p.len() * (RATE as usize) / (rate as usize)..].iter().sum();
    println!(
        "  {name:<16} off-harmonic {:6.1} dB of all{}; by band, under its harmonics (under all): {}",
        db(off / total),
        if rate > RATE { format!(" (above 24 kHz {:.1})", db(above / total)) } else { String::new() },
        b.iter().map(|(h, o)| format!("{:.0}({:.0})", db(o / h), db(o / total))).collect::<Vec<_>>().join(" ")
    );
}

enum Area {
    Engine,
    Clean,
}

/// The vowel held 2 s at f0: what it radiates (the total flow's difference), the glottis's lower area and the flow out
/// of the glottis, per sample.
fn run(speaker: &Speaker, vowel: &str, shape: &str, f0: f64, area: Area, noise: bool, rate: f64) -> (Vec<f64>, Vec<f64>, Vec<f64>) {
    let samples = (2.0 * rate) as usize;
    let mut tract = speaker.tract.clone();
    let p = tract.shape(vowel).expect("the vowel's shape");
    tract.calculate(&p);
    let mut tube = Tube::new();
    tube.set_from_tract(&tract.tube());
    let mut glottis = speaker.glottis.clone();
    let shape = glottis.shape(shape).expect("the glottis's shape").to_vec();
    for (k, c) in glottis.control.iter_mut().enumerate() {
        c.x = shape[k];
    }
    glottis.control[FREQUENCY].x = f0;
    glottis.control[PRESSURE].x = 8000.0;
    glottis.control[FLUTTER].x = 0.0;
    glottis.statics[JITTER].x = 0.0;
    glottis.reset_motion();
    let mut tds = TdsModel::new();
    tds.options.generate_noise_sources = noise;
    // (VTL_PASSIVE=0: Bernoulli's terms as 2.4 has them, none from the smoothed flow; VTL_BERNOULLI_CUTOFF: that flow's
    // low-pass, Hz.)
    if std::env::var("VTL_PASSIVE").map_or(false, |v| v == "0") {
        tds.options.passive_bernoulli = false;
    }
    if let Some(c) = std::env::var("VTL_BERNOULLI_CUTOFF").ok().and_then(|x| x.parse().ok()) {
        tds.options.bernoulli_cutoff_hz = c;
    }
    tds.time_step = 1.0 / rate;
    tds.reset_motion();
    let (mut out, mut areas, mut glottal) = (Vec::with_capacity(samples), Vec::with_capacity(samples), Vec::with_capacity(samples));
    let mut prev_flow = 0.0;
    // The clean areas' Fourier series, taken once settled (0.5 s): each area as a function of the phase over a period.
    let mut series: Option<[Vec<(f64, f64)>; 2]> = None;
    for n in 0..samples {
        glottis.calc_geometry();
        let (length, mut a) = glottis.tube_data();
        if matches!(area, Area::Clean) && n >= samples / 4 {
            let s = series.get_or_insert_with(|| {
                const M: usize = 4096;
                let phase = glottis.phase;
                let mut samples = [vec![0.0; M], vec![0.0; M]];
                for m in 0..M {
                    glottis.phase = 2.0 * PI * m as f64 / M as f64;
                    glottis.calc_geometry();
                    let (_, am) = glottis.tube_data();
                    samples[0][m] = am[0];
                    samples[1][m] = am[1];
                }
                glottis.phase = phase;
                glottis.calc_geometry();
                let top = (22000.0 / f0) as usize;
                samples.map(|v| {
                    (0..=top)
                        .map(|k| {
                            let (mut c, mut s) = (0.0, 0.0);
                            for (m, x) in v.iter().enumerate() {
                                let w = 2.0 * PI * (k * m) as f64 / M as f64;
                                c += x * w.cos();
                                s += x * w.sin();
                            }
                            let scale = if k == 0 { 1.0 } else { 2.0 } / M as f64;
                            (c * scale, s * scale)
                        })
                        .collect()
                })
            });
            let phase = glottis.phase;
            for i in 0..2 {
                a[i] = s[i].iter().enumerate().map(|(k, (c, sn))| c * (k as f64 * phase).cos() + sn * (k as f64 * phase).sin()).sum();
            }
        }
        areas.push(a[0]);
        tube.set_glottis_sections(&length, &a);
        let filtering = tds.sample_index() != 0;
        tds.set_tube(&tube, filtering);
        tds.set_flow_source(0.0, -1);
        tds.set_pressure_source(glottis.control[PRESSURE].x, FIRST_TRACHEA_SECTION as i32);
        let pressure = [tds.section_pressure(LAST_TRACHEA_SECTION), tds.section_pressure(LOWER_GLOTTIS_SECTION), tds.section_pressure(UPPER_GLOTTIS_SECTION), tds.section_pressure(FIRST_PHARYNX_SECTION)];
        glottis.inc_time(1.0 / rate, &pressure);
        let flow = tds.proceed_time_step().total;
        out.push((flow - prev_flow) * rate);
        glottal.push(tds.section_flow_out(UPPER_GLOTTIS_SECTION));
        prev_flow = flow;
    }
    (out, areas, glottal)
}

/// How far the glottis's own laws widen its area's spectrum: over one period of its phase (4096 points), the power
/// above 24 kHz -- what a 48 kHz step folds -- of the area, of its DC resistance (as the area to -2.6) and of its
/// Bernoulli coefficient (as the area to -2), each in dB of its own power apart from its mean.
fn widening(speaker: &Speaker, shape: &str, f0: f64) {
    let mut glottis = speaker.glottis.clone();
    let s = glottis.shape(shape).expect("the glottis's shape").to_vec();
    for (k, c) in glottis.control.iter_mut().enumerate() {
        c.x = s[k];
    }
    glottis.control[FREQUENCY].x = f0;
    glottis.control[PRESSURE].x = 8000.0;
    glottis.reset_motion();
    const M: usize = 4096;
    let area: Vec<f64> = (0..M)
        .map(|m| {
            glottis.phase = 2.0 * PI * m as f64 / M as f64;
            glottis.calc_geometry();
            glottis.tube_data().1[0]
        })
        .collect();
    let above = |x: &[f64]| -> f64 {
        let (mut re, mut im) = (x.to_vec(), vec![0.0; M]);
        fft(&mut re, &mut im);
        let power: Vec<f64> = (0..M / 2).map(|k| re[k] * re[k] + im[k] * im[k]).collect();
        let top = (24000.0 / f0) as usize;
        db(power[top + 1..].iter().sum::<f64>() / power[1..].iter().sum::<f64>())
    };
    let r_dc: Vec<f64> = area.iter().map(|a| (REF_AREA_CM2 / a).powf(DC_EXPONENT)).collect();
    let bernoulli: Vec<f64> = area.iter().map(|a| 1.0 / (a * a)).collect();
    println!(
        "  widening    power above 24 kHz: area {:.1} dB, DC resistance {:.1} dB, Bernoulli coefficient {:.1} dB (area {:.3} to {:.3} cm2)",
        above(&area),
        above(&r_dc),
        above(&bernoulli),
        area.iter().cloned().fold(f64::MAX, f64::min),
        area.iter().cloned().fold(0.0, f64::max)
    );
}

/// The vowel held 2 s through the synthesizer itself at n steps a sample (set_oversampling), 2.4's 12 kHz low-pass off.
fn synth_run(speaker: &Speaker, vowel: &str, shape: &str, f0: f64, n: usize, noise: bool) -> Vec<f64> {
    let mut tract = speaker.tract.clone();
    let tp = tract.shape(vowel).expect("the vowel's shape");
    let mut glottis = speaker.glottis.clone();
    let mut gp = glottis.shape(shape).expect("the glottis's shape").to_vec();
    gp[FREQUENCY] = f0;
    gp[PRESSURE] = 8000.0;
    gp[FLUTTER] = 0.0;
    glottis.statics[JITTER].x = 0.0;
    let mut tds = TdsModel::new();
    tds.options.generate_noise_sources = noise;
    // (VTL_PASSIVE=0: Bernoulli's terms as 2.4 has them, none from the smoothed flow; VTL_BERNOULLI_CUTOFF: that flow's
    // low-pass, Hz.)
    if std::env::var("VTL_PASSIVE").map_or(false, |v| v == "0") {
        tds.options.passive_bernoulli = false;
    }
    if let Some(c) = std::env::var("VTL_BERNOULLI_CUTOFF").ok().and_then(|x| x.parse().ok()) {
        tds.options.bernoulli_cutoff_hz = c;
    }
    let mut synth = Synthesizer::new(glottis, tds);
    synth.set_oversampling(n);
    synth.lowpass = false;
    let mut out = vec![0.0; SYNTH_SECONDS * 48000];
    synth.add_tract(&mut tract, &tp, &gp, &mut []);
    for chunk in out.chunks_mut(120) {
        synth.add_tract(&mut tract, &tp, &gp, chunk);
    }
    out
}

const SYNTH_SECONDS: usize = 2;

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let speaker = Speaker::read(&args[0]).expect("speaker");
    let (vowel, shape) = (args.get(1).map(String::as_str).unwrap_or("a"), args.get(2).map(String::as_str).unwrap_or("modal"));
    println!("bands: {}", BANDS.iter().map(|(a, b)| format!("{:.0}-{:.0}k", a / 1000.0, b / 1000.0)).collect::<Vec<_>>().join(" "));
    let only: Option<f64> = args.get(3).and_then(|x| x.parse().ok());
    if args.get(4).map(String::as_str) == Some("synth") {
        for f0 in [110.3, 220.7, 441.1, 587.3].into_iter().filter(|f| only.map(|o| o == *f).unwrap_or(true)) {
            println!("F0 {f0} Hz, /{vowel}/, {shape}, the synthesizer at n steps a sample (2.4's low-pass off):");
            for n in [1, 2, 3, 4] {
                report(&format!("n {n}"), &synth_run(&speaker, vowel, shape, f0, n, false), f0, RATE);
                let noisy = synth_run(&speaker, vowel, shape, f0, n, true);
                report(&format!("n {n} noise on"), &noisy, f0, RATE);
                let p = spectrum(&noisy, RATE);
                let bin = RATE / 65536.0;
                println!("  {:<16} power by band, dB: {}", "", BANDS.iter().map(|&(lo, hi)| format!("{:.1}", db(p.iter().enumerate().filter(|(k, _)| { let f = *k as f64 * bin; f >= lo && f < hi }).map(|(_, v)| v).sum::<f64>()))).collect::<Vec<_>>().join(" "));
            }
        }
        return;
    }
    for f0 in [110.3, 220.7, 441.1, 587.3].into_iter().filter(|f| only.map(|o| o == *f).unwrap_or(true)) {
        println!("F0 {f0} Hz, /{vowel}/, {shape}:");
        let (engine, areas, glottal) = run(&speaker, vowel, shape, f0, Area::Engine, false, RATE);
        report("engine", &engine, f0, RATE);
        report("its glottal flow", &glottal, f0, RATE);
        let (clean, _, clean_glottal) = run(&speaker, vowel, shape, f0, Area::Clean, false, RATE);
        report("area-clean", &clean, f0, RATE);
        report("its glottal flow", &clean_glottal, f0, RATE);
        let (noisy, _, _) = run(&speaker, vowel, shape, f0, Area::Engine, true, RATE);
        report("noise on", &noisy, f0, RATE);
        report("its area", &areas, f0, RATE);
        widening(&speaker, shape, f0);
        for rate in [2.0 * RATE, 4.0 * RATE] {
            let (fast, _, fast_glottal) = run(&speaker, vowel, shape, f0, Area::Engine, false, rate);
            report(&format!("{:.0}k", rate / 1000.0), &fast, f0, rate);
            report("its glottal flow", &fast_glottal, f0, rate);
        }
    }
}
