// VocalTractLab 2.4's instability at a closing glottis (docs/VOCAL_TRACT.md, "Found in reading"): a fricative's glottis
// held open on 800 Pa, then closed over 1, 10, 120 or 480 samples of 48 kHz while its flow (some 430 cm3/s) still runs,
// at 48, 96 and 192 kHz. 2.4 figures a constriction's turbulence noise from the cube of its speed, its smoothed flow
// over its area as they are: the flow of before over the area of after, speeds past sound's, and the noise put into the
// pharynx runs the tract away to NaN. Run as 2.4 is, without its noise (VTL_SNAP_OFF=noise, or walls, contacts, skin,
// fossa), and with the speed held to what the pressure across the constriction can drive (Options::
// bound_noise_velocity); the largest pressure after the closing (dPa), against its lungs' 8000.
//   cargo run --release --example v24_snap -- JD2.speaker
use musebots_vocaltract::v24::speaker::Speaker;
use musebots_vocaltract::v24::tds::TdsModel;
use musebots_vocaltract::v24::tube::{Tube, FIRST_TRACHEA_SECTION, MIN_AREA_CM2, UPPER_GLOTTIS_SECTION};

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let speaker = Speaker::read(&args[0]).expect("speaker");
    let mut tract = speaker.tract.clone();
    let shape = tract.shape("tt-alveolar-fricative(i)").expect("the fricative's shape");
    tract.calculate(&shape);
    let mut tube = Tube::new();
    tube.set_from_tract(&tract.tube());
    let off = std::env::var("VTL_SNAP_OFF").unwrap_or_default();
    for bound in [false, true] {
        for over in [1usize, 2, 4] {
            for ramp48 in [1usize, 10, 120, 480] {
                let ramp = ramp48 * over;
                let mut tds = TdsModel::new();
                tds.options.bound_noise_velocity = bound;
                for o in off.split(',') {
                    match o {
                        "noise" => tds.options.generate_noise_sources = false,
                        "walls" => tds.options.soft_walls = false,
                        "contacts" => tds.options.soft_contacts = false,
                        "skin" => tds.options.radiation_from_skin = false,
                        "fossa" => tds.options.piriform_fossa = false,
                        _ => {}
                    }
                }
                tds.set_rate(48000.0 * over as f64);
                let (start, total) = (9600 * over, 14400 * over);
                let (mut first_bad, mut pmax, mut flow_before) = (None, 0.0f64, 0.0);
                for n in 0..total {
                    let area = if n < start { 0.3 } else if n < start + ramp { 0.3 + (MIN_AREA_CM2 - 0.3) * (n + 1 - start) as f64 / ramp as f64 } else { MIN_AREA_CM2 };
                    tube.set_glottis_sections(&[0.3, 0.3], &[area, area]);
                    tds.set_tube(&tube, n != 0);
                    tds.set_flow_source(0.0, -1);
                    tds.set_pressure_source(8000.0, FIRST_TRACHEA_SECTION as i32);
                    let r = tds.proceed_time_step();
                    if n == start - 1 {
                        flow_before = tds.section_flow_out(UPPER_GLOTTIS_SECTION);
                    }
                    if n >= start {
                        pmax = pmax.max((0..80).map(|i| tds.section_pressure(i).abs()).fold(0.0, f64::max));
                    }
                    if !r.total.is_finite() && first_bad.is_none() {
                        first_bad = Some(n);
                    }
                }
                println!(
                    "v24_snap: {}, {:>3} kHz, closed over {ramp48:>3} samples of 48 kHz: {flow_before:.0} cm3/s before; largest pressure after {pmax:.3e} dPa; {}",
                    if bound { "noise's speed bounded" } else { "2.4" },
                    48 * over,
                    match first_bad { Some(n) => format!("NaN from sample {n}"), None => "finite".to_string() }
                );
            }
        }
    }
}
