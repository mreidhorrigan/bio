// A sweep for runaways (the owner, 13 November 2026: "fix the model's errors so there are no further detected blowup
// cases"): on the engine itself, each of 2.4's speakers, each of its shapes and its neutral tract, its tube made once,
// its acoustics stepped as the synthesizer steps (Synthesizer::add_tube; the tube's own order of the solve, as accurate
// as 2.4's: research/VOCAL_TRACT_REALTIME_PLAN.md, 1), at 48 and 192 kHz, a third of a second each, its lungs rising to
// 8,000 or 16,000 dPa over 12 ms:
//   held  -- each of its glottal shapes, and the glottis held at its extremes, wide open (its displacements 0.3 cm, its
//            chink 0.25 cm2) and shut (-0.05 cm, -0.25 cm2);
//   turned -- on its vowels, the glottis turned at once from open (h, breathy, voiceless fricative, wide open) to shut
//            (stop, pressed, voiced plosive, shut) halfway, and back;
//   larynx -- its larynx's static parameters at their corners (the folds' rest thickness and length, the chink's length:
//            each its least and most), modal, on its neutral tract, /a/, /i/ and /u/;
//   anatomy -- its anatomy made a child's or young person's (1.5, 5, 10 and 15 years, female and male, by 2.4's growth
//            curves), or one of its thirteen measures at its least or most (src/v24/anatomy.rs), modal, on its
//            neutral tract and its vowels, at 192 kHz.
// A runaway: any section's pressure past 60,000 dPa (beyond any lungs'), or its sound not finite. Each is printed, with
// when it ran away and where; then the count of each kind.
//   cargo run --release --example v24_stability_sweep -- <2.4's folder> [threads 3] [seconds 0.3] [only: cases whose
//   description holds this]
use musebots_vocaltract::v24::glottis::{Glottis2025, PRESSURE};
use musebots_vocaltract::v24::speaker::Speaker;
use musebots_vocaltract::v24::synth::{Synthesizer, NUM_CHUNK_SAMPLES};
use musebots_vocaltract::v24::tds::{Solver, TdsModel};
use musebots_vocaltract::v24::tube::{Tube, NUM_SECTIONS};
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::{Arc, Mutex};

const RUNAWAY_DPA: f64 = 60000.0;
const X_BOTTOM: usize = 2;
const X_TOP: usize = 3;
const CHINK: usize = 4;

struct Job {
    what: String,
    speaker: usize,
    /// Its set of tubes (the speaker's own, or an anatomy's) and the tube in it.
    set: usize,
    tube: usize,
    glottis: Vec<f64>,
    then: Option<Vec<f64>>,
    statics: Option<Vec<f64>>,
    pressure: f64,
    n: usize,
}

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let folder = &args[0];
    let threads: usize = args.get(1).and_then(|x| x.parse().ok()).unwrap_or(3);
    let seconds: f64 = args.get(2).and_then(|x| x.parse().ok()).unwrap_or(0.3);
    let names = ["JD2", "M01", "W02"];
    let speakers: Vec<Speaker> = names.iter().map(|n| Speaker::read(&format!("{folder}/{n}.speaker")).expect("speaker")).collect();
    // (Each speaker's tubes: its neutral tract's, then each shape's.)
    let mut tubes: Vec<Vec<(String, Tube)>> = Vec::new();
    for sp in &speakers {
        let mut tract = sp.tract.clone();
        tract.mended = true;
        let neutral: Vec<f64> = tract.param.iter().map(|p| p.neutral).collect();
        let shapes: Vec<(String, Vec<f64>)> = std::iter::once(("neutral".to_string(), neutral)).chain(tract.shapes.iter().map(|(n, v)| (n.clone(), v.to_vec()))).collect();
        tubes.push(
            shapes
                .into_iter()
                .map(|(name, params)| {
                    tract.calculate(&params);
                    let mut t = Tube::new();
                    t.set_from_tract(&tract.tube());
                    (name, t)
                })
                .collect(),
        );
    }
    let vowel = |name: &str| !name.contains('-') && name != "neutral";
    let mut jobs: Vec<Job> = Vec::new();
    for (s, sp) in speakers.iter().enumerate() {
        let shape = |name: &str| sp.glottis.shapes.iter().find(|(n, _)| n == name).map(|(_, v)| v.clone());
        let modal = shape("modal").expect("a modal glottis");
        let mut open = modal.clone();
        (open[X_BOTTOM], open[X_TOP], open[CHINK]) = (0.3, 0.3, 0.25);
        let mut shut = modal.clone();
        (shut[X_BOTTOM], shut[X_TOP], shut[CHINK]) = (-0.05, -0.05, -0.25);
        let mut held: Vec<(String, Vec<f64>)> = sp.glottis.shapes.clone();
        held.push(("wide open".into(), open.clone()));
        held.push(("shut".into(), shut.clone()));
        let opens: Vec<(String, Vec<f64>)> = ["h", "breathy", "voiceless-fricative"].iter().filter_map(|n| shape(n).map(|v| (n.to_string(), v))).chain([("wide open".to_string(), open)]).collect();
        let shuts: Vec<(String, Vec<f64>)> = ["stop", "pressed", "voiced-plosive"].iter().filter_map(|n| shape(n).map(|v| (n.to_string(), v))).chain([("shut".to_string(), shut)]).collect();
        let rest_f0 = sp.glottis.statics[2].x;
        for &n in &[1usize, 4] {
            for &pressure in &[8000.0, 16000.0] {
                for (t, (tube_name, _)) in tubes[s].iter().enumerate() {
                    for (g, values) in &held {
                        let mut v = values.clone();
                        v[0] = rest_f0;
                        jobs.push(Job { what: format!("held: {} {tube_name}, glottis {g}", names[s]), speaker: s, set: s, tube: t, glottis: v, then: None, statics: None, pressure, n });
                    }
                    if !vowel(tube_name) {
                        continue;
                    }
                    for (a, va) in &opens {
                        for (b, vb) in &shuts {
                            for (from, to, fa, fb) in [(a, b, va, vb), (b, a, vb, va)] {
                                let (mut x, mut y) = (fa.clone(), fb.clone());
                                x[0] = rest_f0;
                                y[0] = rest_f0;
                                jobs.push(Job { what: format!("turned: {} {tube_name}, glottis {from} to {to}", names[s]), speaker: s, set: s, tube: t, glottis: x, then: Some(y), statics: None, pressure, n });
                            }
                        }
                    }
                }
            }
        }
        // (Its larynx at its corners: each static parameter's least or most, the other two likewise.)
        let st: Vec<(f64, f64)> = sp.glottis.statics.iter().map(|p| (p.min, p.max)).collect();
        for corner in 0..8 {
            let mut statics: Vec<f64> = sp.glottis.statics.iter().map(|p| p.x).collect();
            for (bit, k) in [0usize, 1, 3].iter().enumerate() {
                statics[*k] = if corner >> bit & 1 == 1 { st[*k].1 } else { st[*k].0 };
            }
            for (t, (tube_name, _)) in tubes[s].iter().enumerate() {
                if !["neutral", "a", "i", "u"].contains(&tube_name.as_str()) {
                    continue;
                }
                for &pressure in &[8000.0, 16000.0] {
                    let mut v = shape("modal").unwrap();
                    v[0] = rest_f0;
                    jobs.push(Job { what: format!("larynx: {} {tube_name}, modal, rest thickness {:.2} length {:.2} chink length {:.2}", names[s], statics[0], statics[1], statics[3]), speaker: s, set: s, tube: t, glottis: v, then: None, statics: Some(statics.clone()), pressure, n: 4 });
                }
            }
        }
    }
    // (Each speaker's anatomies: its tubes made again on each, its neutral tract and its vowels.)
    use musebots_vocaltract::v24::anatomy;
    for (s, sp) in speakers.iter().enumerate() {
        let own = anatomy::of(&sp.tract);
        let mut variants: Vec<(String, [f64; anatomy::NUM_ANATOMY_PARAMS])> = Vec::new();
        for years in [1.5, 5.0, 10.0, 15.0] {
            for male in [false, true] {
                variants.push((format!("{} of {years} years", if male { "male" } else { "female" }), anatomy::from_age((years * 12.0) as i32, male)));
            }
        }
        for (i, p) in anatomy::ANATOMY_PARAMS.iter().enumerate() {
            for (end, v) in [("least", p.min), ("most", p.max)] {
                let mut x = own;
                x[i] = v;
                variants.push((format!("its {} at its {end}", p.key), x));
            }
        }
        let modal = sp.glottis.shapes.iter().find(|(n, _)| n == "modal").expect("modal").1.clone();
        for (label, x) in variants {
            let mut tract = sp.tract.clone();
            tract.mended = true;
            anatomy::set_for(&x, &mut tract, &sp.tract);
            let neutral: Vec<f64> = tract.param.iter().map(|p| p.neutral).collect();
            let shapes: Vec<(String, Vec<f64>)> = std::iter::once(("neutral".to_string(), neutral)).chain(tract.shapes.iter().filter(|(n, _)| vowel(n)).map(|(n, v)| (n.clone(), v.to_vec()))).collect();
            let set = tubes.len();
            tubes.push(
                shapes
                    .into_iter()
                    .map(|(name, params)| {
                        tract.calculate(&params);
                        let mut t = Tube::new();
                        t.set_from_tract(&tract.tube());
                        (name, t)
                    })
                    .collect(),
            );
            for (t, (tube_name, _)) in tubes[set].iter().enumerate() {
                for &pressure in &[8000.0, 16000.0] {
                    let mut v = modal.clone();
                    v[0] = sp.glottis.statics[2].x;
                    jobs.push(Job { what: format!("anatomy: {} as a {label}, {tube_name}, modal", names[s]), speaker: s, set, tube: t, glottis: v, then: None, statics: None, pressure, n: 4 });
                }
            }
        }
    }
    if let Some(only) = args.get(3) {
        jobs.retain(|j| j.what.contains(only.as_str()));
    }
    eprintln!("v24_stability_sweep: {} cases on {threads} threads, {seconds} s each", jobs.len());
    let (jobs, tubes, next, found, done) = (Arc::new(jobs), Arc::new(tubes), Arc::new(AtomicUsize::new(0)), Arc::new(Mutex::new(Vec::<(String, String)>::new())), Arc::new(AtomicUsize::new(0)));
    let glottises: Arc<Vec<Glottis2025>> = Arc::new(speakers.iter().map(|s| { let mut g = s.glottis.clone(); g.mended = true; g }).collect());
    let workers: Vec<_> = (0..threads)
        .map(|_| {
            let (jobs, tubes, next, found, done, glottises) = (jobs.clone(), tubes.clone(), next.clone(), found.clone(), done.clone(), glottises.clone());
            std::thread::spawn(move || loop {
                let k = next.fetch_add(1, Ordering::Relaxed);
                let Some(job) = jobs.get(k) else { break };
                if let Some(said) = run(job, &tubes[job.set][job.tube].1, &glottises[job.speaker], seconds) {
                    let kind = job.what.split(':').next().unwrap_or("").to_string();
                    println!("RUNAWAY {}, {:.0} dPa, {} kHz: {said}", job.what, job.pressure, 48 * job.n);
                    found.lock().unwrap().push((kind, job.what.clone()));
                }
                let d = done.fetch_add(1, Ordering::Relaxed) + 1;
                if d % 1000 == 0 {
                    eprintln!("v24_stability_sweep: {d} of {}", jobs.len());
                }
            })
        })
        .collect();
    for w in workers {
        w.join().unwrap();
    }
    let found = found.lock().unwrap();
    let count = |kind: &str| found.iter().filter(|(k, _)| k == kind).count();
    let total = |kind: &str| jobs.iter().filter(|j| j.what.starts_with(kind)).count();
    println!("v24_stability_sweep: runaways -- held {} of {}, turned {} of {}, larynx {} of {}, anatomy {} of {}", count("held"), total("held"), count("turned"), total("turned"), count("larynx"), total("larynx"), count("anatomy"), total("anatomy"));
}

/// One case stepped: None where it stayed bounded, else when and where it ran away.
fn run(job: &Job, tube: &Tube, glottis: &Glottis2025, seconds: f64) -> Option<String> {
    let mut g = glottis.clone();
    if let Some(s) = &job.statics {
        for (p, x) in g.statics.iter_mut().zip(s) {
            p.x = *x;
        }
    }
    let mut tds = TdsModel::new();
    tds.options.solver = Solver::Tree;
    let mut synth = Synthesizer::new(g, tds);
    synth.set_oversampling(job.n);
    let chunks = (seconds * 48000.0 / NUM_CHUNK_SAMPLES as f64) as usize;
    let mut out = vec![0.0; NUM_CHUNK_SAMPLES];
    for c in 0..=chunks {
        let t = c as f64 * NUM_CHUNK_SAMPLES as f64 / 48000.0;
        let mut v = match &job.then {
            Some(then) if c > chunks / 2 => then.clone(),
            _ => job.glottis.clone(),
        };
        v[PRESSURE] = job.pressure * (1.0 - (-t / 0.012).exp());
        let made = if c == 0 { 0 } else { NUM_CHUNK_SAMPLES };
        synth.add_tube(&v, tube, &mut out[..made]);
        let (worst, at) = (0..NUM_SECTIONS).map(|i| (synth.tds.section_pressure(i).abs(), i)).fold((0.0f64, 0), |a, b| if !(b.0 <= a.0) { b } else { a });
        if !(worst <= RUNAWAY_DPA) || out[..made].iter().any(|x| !x.is_finite()) {
            return Some(format!("at {t:.3} s, section {at} at {worst:.3e} dPa"));
        }
    }
    None
}
