// The tract's volume-velocity transfer as VocalFork 3.0 computes it in time (src/v24/passive.rs), to set against the
// stepped tube's exact transfer in the frequency domain (research/vocal-tract-passive-core/losses.py): each vowel's
// tube held still, the glottis shut, the lungs and the noise silent, a flow put into the pharynx's first node for one
// step (PassiveModel::injected) and the lips' flow out recorded at the model's own rate -- with 2.4's losses, and with
// Zwikker and Kosten's as OpenWInD takes them (PassiveModel::viscous_layer and thermal_layer), or 2.4's laws with their frequency
// left in (PassiveModel::fitted_law; FORK_LOSSES=2.4,zk,viscous,thermal,fitted those asked;
// FORK_SWITCHES its other switches, as vocalfork_check's: circumference=0, trachea=fine). A transfer function is the small signal's: the model
// is linear but for its jets' terms (Bernoulli's drops and recoveries), quadratic in the flow, whose share of the
// response grows with the volume put in. So it is put in twice, a microlitre and a tenth of one, the model as it
// plays both times, and the two responses per unit volume set against each other: their difference is that share,
// printed. Writes <folder>/<vowel>-<losses>.f64 (the lips' flow per unit volume put in, at the rate it prints), raw
// (on a disk that does not tell case apart, as the Mac's, shapes named e and E write one file: ask them in two runs)
// 64-bit floats, from the microlitre. And what a step costs with each law, counted by the processor (src/counters.rs:
// instructions retired, the microlitre's response's over its steps).
//   cargo run --release --example vocalfork_transfer -- <speaker.speaker> <folder> [vowel,vowel,...] [seconds]
use musebots_vocaltract::counters::Counts;
use musebots_vocaltract::v24::passive::PassiveModel;
use musebots_vocaltract::v24::speaker::Speaker;
use musebots_vocaltract::v24::tds::{TdsModel, TubeCoefficients};
use musebots_vocaltract::v24::tube::{Tube, MIN_AREA_CM2};

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let sp = Speaker::read(&args[0]).expect("speaker");
    let folder = &args[1];
    let vowels: Vec<String> = args.get(2).map_or(vec!["a".into(), "i".into(), "u".into()], |s| s.split(',').map(String::from).collect());
    let seconds: f64 = args.get(3).map_or(0.25, |s| s.parse().unwrap());
    std::fs::create_dir_all(folder).expect("the folder");
    let switches: Vec<String> = std::env::var("FORK_SWITCHES").unwrap_or_default().split_whitespace().map(String::from).collect();
    let mut options = TdsModel::new().options;
    options.generate_noise_sources = false;
    PassiveModel::layout_switches(&mut options, &switches);
    let (_, steps) = PassiveModel::for_speaker(&sp.tract, &sp.glottis, options);
    // (FORK_STEPS: more steps a sample than the physics asks, to see what the step's size does)
    let steps = std::env::var("FORK_STEPS").ok().and_then(|x| x.parse::<usize>().ok()).unwrap_or(steps);
    let rate = 48000.0 * steps as f64;
    let mut glottis = sp.glottis.clone();
    glottis.calc_geometry();
    let (lengths, _) = glottis.tube_data();
    println!("{}: VocalFork at {steps} steps a sample, {rate} Hz; {seconds} s each", args[0].rsplit('/').next().unwrap());
    for vowel in &vowels {
        let params = sp.tract.shape(vowel).expect("a shape of the speaker's");
        let mut tract = sp.tract.clone();
        tract.calculate(&params);
        let mut tube = Tube::new();
        tube.set_from_tract(&tract.tube());
        let mut tds = TdsModel::new();
        tds.options = options;
        tds.set_tube(&tube, false);
        let mut k = TubeCoefficients::default();
        tds.tube_coefficients(&mut k);
        let laws: Vec<String> = std::env::var("FORK_LOSSES").map_or(vec!["2.4".into(), "zk".into()], |x| x.split(',').map(String::from).collect());
        for losses in &laws {
            let (mut model, _) = PassiveModel::for_speaker(&sp.tract, &sp.glottis, options);
            model.take_switches(&[format!("losses={losses}")]);
            model.take_switches(&switches);
            model.set_rate(rate);
            model.set_glottis_sections(&lengths, &[MIN_AREA_CM2; 2]);
            model.set_pressure_source(0.0, 0);
            let n = (seconds * rate) as usize;
            // (one step's flow of the volume, the lips' flow scaled back to a unit volume)
            let respond = |model: &mut PassiveModel, volume: f64| -> Vec<f64> {
                model.reset_motion();
                (0..n)
                    .map(|s| {
                        model.injected = if s == 0 { volume * rate } else { 0.0 };
                        model.proceed_time_step_with(&k).mouth / volume
                    })
                    .collect()
            };
            let began = Counts::now();
            let out = respond(&mut model, 1e-6);
            let cost = began.and_then(|b| Counts::now().map(|now| now.since(&b).instructions() as f64 / n as f64));
            let tenth = respond(&mut model, 1e-7);
            let peak = out.iter().fold(0.0f64, |m, x| m.max(x.abs()));
            let nonlinear = out.iter().zip(&tenth).fold(0.0f64, |m, (a, b)| m.max((a - b).abs())) / peak;
            let bytes: Vec<u8> = out.iter().flat_map(|x| x.to_le_bytes()).collect();
            std::fs::write(format!("{folder}/{vowel}-{losses}.f64"), bytes).expect("written");
            println!(
                "/{vowel}/, losses {losses}: {n} steps, the lips' peak flow {peak:.3e} cm^3/s a unit volume, every step finite: {}; a microlitre's response and a tenth's differ by at most {nonlinear:.1e} of its peak{}",
                out.iter().all(|x| x.is_finite()),
                cost.map_or(String::new(), |c| format!("; {c:.0} instructions a step"))
            );
        }
    }
}
