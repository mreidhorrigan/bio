// A wide-open glottis held under a lung pressure, on the neutral tract (the owner, 13 November 2026: "High chink area
// blew up the model"; the live voice at a lower displacement of 0.2713 cm and a chink area of 0.202 cm^2 went to NaN at 3
// and 4 steps a sample, not at 1 or 2): each chunk's output and glottal pressures, at the steps and with the TDS options
// asked, and where the sound is first not finite.
// With STEPWISE=1, stepped here step by step as the synthesizer steps (Synthesizer::step), the upper glottal section's
// pressure kept at each, and the growth before it is first not finite said: its frequency and its growth a step. With
// MONITOR=1 too, the acoustics' power balance above the Bernoulli terms' cutoff (TdsModel::monitor_power), by blocks of
// 1024 steps before the end: the fluctuations' energy stored, the work Bernoulli's terms and the viscous losses did on
// them, and the section whose Bernoulli terms gave the most.
//   cargo run --release --example v24_open_glottis -- <JD2.speaker> <steps> <seconds> [x_bottom] [chink] [option=0|1 ...]
use musebots_vocaltract::v24::speaker::Speaker;
use musebots_vocaltract::v24::glottis::PRESSURE;
use musebots_vocaltract::v24::synth::{StepRecord, Synthesizer, NUM_CHUNK_SAMPLES};
use musebots_vocaltract::v24::tds::TdsModel;
use musebots_vocaltract::v24::tube::{Tube, FIRST_PHARYNX_SECTION, FIRST_TRACHEA_SECTION, LAST_TRACHEA_SECTION, LOWER_GLOTTIS_SECTION, UPPER_GLOTTIS_SECTION};

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let mut sp = Speaker::read(&args[0]).expect("speaker");
    let (n, seconds): (usize, f64) = (args[1].parse().unwrap(), args[2].parse().unwrap());
    let x_bottom: f64 = args.get(3).and_then(|x| x.parse().ok()).unwrap_or(0.2713);
    let chink: f64 = args.get(4).and_then(|x| x.parse().ok()).unwrap_or(0.202);
    sp.tract.mended = true;
    sp.glottis.mended = true;
    let mut synth = Synthesizer::new(sp.glottis.clone(), TdsModel::new());
    for a in args.iter().skip(5) {
        let (k, v) = a.split_once('=').expect("option=0|1");
        let v = v == "1";
        let o = &mut synth.tds.options;
        match k {
            "noise" => o.generate_noise_sources = v,
            "soft_walls" => o.soft_walls = v,
            "soft_contacts" => o.soft_contacts = v,
            "skin" => o.radiation_from_skin = v,
            "fossa" => o.piriform_fossa = v,
            "corrections" => o.inner_length_corrections = v,
            "bound" => o.bound_noise_velocity = v,
            "branches" => o.recover_at_branches = v,
            "mean" => o.passive_bernoulli = v,
            "cutoff" => {}
            other => panic!("{other}?"),
        }
    }
    // (RECOVERY_CUTOFF: the recovered pressure's flow's low-pass, Hz.)
    if let Some(c) = std::env::var("RECOVERY_CUTOFF").ok().and_then(|x| x.parse().ok()) {
        synth.tds.options.bernoulli_cutoff_hz = c;
    }
    synth.set_oversampling(n);
    // (VOWEL: a shape of the speaker's for the tract, else its neutral one; GLOTTIS: a glottal shape of its, its x_bottom
    // and chink then as asked unless they are given as "-".)
    let tract_params: Vec<f64> = match std::env::var("VOWEL") {
        Ok(v) => sp.tract.shape(&v).expect("a shape of the speaker's").to_vec(),
        Err(_) => sp.tract.param.iter().map(|p| p.neutral).collect(),
    };
    let mut g: Vec<f64> = match std::env::var("GLOTTIS") {
        Ok(name) => sp.glottis.shapes.iter().find(|(n, _)| *n == name).expect("a glottal shape of the speaker's").1.clone(),
        Err(_) => sp.glottis.control.iter().map(|p| p.neutral).collect(),
    };
    if args.get(3).map_or(true, |a| a != "-") {
        g[2] = x_bottom;
    }
    if args.get(4).map_or(true, |a| a != "-") {
        g[4] = chink;
    }
    // (X_TOP: the upper displacement too; PRESSURE: the lungs' (dPa), else 8000.)
    if let Some(v) = std::env::var("X_TOP").ok().and_then(|x| x.parse().ok()) {
        g[3] = v;
    }
    let lungs: f64 = std::env::var("PRESSURE").ok().and_then(|x| x.parse().ok()).unwrap_or(8000.0);
    // (REL_AMP=0: the folds held still, the glottis's areas constant.)
    if let Some(r) = std::env::var("REL_AMP").ok().and_then(|x| x.parse().ok()) {
        g[6] = r;
    }
    let mut tract = sp.tract.clone();
    let chunks = (seconds * 48000.0 / NUM_CHUNK_SAMPLES as f64) as usize;
    if std::env::var("STEPWISE").is_ok() {
        tract.calculate(&tract_params);
        let mut tube = Tube::new();
        tube.set_from_tract(&tract.tube());
        let mut record = StepRecord::default();
        synth.stepper.tds.options = synth.tds.options;
        let rate = 48000.0 * n as f64;
        let mut kept: Vec<f64> = Vec::new();
        let mut at = 0usize;
        let monitor = std::env::var("MONITOR").map_or(false, |v| v == "1");
        if monitor {
            let cutoff = synth.tds.options.bernoulli_cutoff_hz;
            synth.tds.monitor_power(cutoff);
        }
        // (Each block's most energy stored, and the work done by its end: Bernoulli's at each section, the viscous.)
        let mut blocks: Vec<(f64, Vec<f64>, f64)> = Vec::new();
        let mut most = 0.0f64;
        'chunks: for c in 0..=chunks {
            let t = c as f64 * NUM_CHUNK_SAMPLES as f64 / 48000.0;
            g[1] = lungs * (1.0 - (-t / 0.012).exp());
            if c == 0 {
                synth.stepper.start(&tube, &g);
                continue;
            }
            for i in 0..NUM_CHUNK_SAMPLES * n {
                synth.stepper.step(i, NUM_CHUNK_SAMPLES * n, &tube, &g, &mut record);
                let (glottis, tds) = (&mut synth.glottis, &mut synth.tds);
                for (k, p) in glottis.control.iter_mut().enumerate() {
                    p.x = record.glottis[k];
                }
                glottis.calc_geometry();
                let (length, area) = glottis.tube_data();
                tds.set_glottis_sections(&length, &area);
                tds.set_flow_source(0.0, -1);
                tds.set_pressure_source(glottis.control[PRESSURE].x, FIRST_TRACHEA_SECTION as i32);
                let pressure = [tds.section_pressure(LAST_TRACHEA_SECTION), tds.section_pressure(LOWER_GLOTTIS_SECTION), tds.section_pressure(UPPER_GLOTTIS_SECTION), tds.section_pressure(FIRST_PHARYNX_SECTION)];
                glottis.inc_time(tds.time_step, &pressure);
                tds.proceed_time_step_with(&record.tube);
                let p = tds.section_pressure(UPPER_GLOTTIS_SECTION);
                kept.push(p);
                at += 1;
                if let Some(m) = tds.monitor.as_ref() {
                    most = most.max(m.stored);
                    if at % 1024 == 0 {
                        blocks.push((most, m.bernoulli_absorbed.clone(), m.viscous_absorbed));
                        most = 0.0;
                    }
                }
                if !(p.abs() < 1e5) {
                    break 'chunks;
                }
            }
            synth.stepper.finish(&tube, &g);
        }
        println!("steps {n}: {}", if at < kept.len() + 1 && kept.last().map_or(false, |p| !(p.abs() < 1e5)) { format!("|p| past 1e5 dPa at {:.4} s", at as f64 / rate) } else { "bounded throughout".into() });
        // (The 4096 steps before it: their mean taken off, the strongest frequency in them, and how the swing grew.)
        let m = kept.len().saturating_sub(64);
        let w = 4096.min(m);
        let x: Vec<f64> = kept[m - w..m].to_vec();
        let mean = x.iter().sum::<f64>() / w as f64;
        let x: Vec<f64> = x.iter().map(|v| v - mean).collect();
        let (mut best, mut best_f) = (0.0, 0.0);
        for k in 1..w / 2 {
            let f = k as f64 * rate / w as f64;
            let (mut re, mut im) = (0.0, 0.0);
            for (j, v) in x.iter().enumerate() {
                let ph = 2.0 * std::f64::consts::PI * k as f64 * j as f64 / w as f64;
                re += v * ph.cos();
                im -= v * ph.sin();
            }
            let mag = (re * re + im * im).sqrt();
            if mag > best {
                best = mag;
                best_f = f;
            }
        }
        let swing = |a: &[f64]| a.iter().fold(0.0f64, |m, v| m.max(v.abs()));
        let q = w / 4;
        println!("the {w} steps before: mean {mean:.0} dPa; strongest at {best_f:.0} Hz; swing by quarters {:.0} {:.0} {:.0} {:.0} dPa", swing(&x[..q]), swing(&x[q..2 * q]), swing(&x[2 * q..3 * q]), swing(&x[3 * q..]));
        println!("its last 12 steps: {}", kept[m..(m + 12).min(kept.len())].iter().map(|p| format!("{p:.0}")).collect::<Vec<_>>().join(" "));
        if blocks.len() > 4 {
            let b = &blocks[blocks.len() - 5..];
            let sum = |v: &Vec<f64>| v.iter().sum::<f64>();
            println!(
                "power above {:.0} Hz, by 1024 steps: stored at most {} erg; Bernoulli's terms took {} erg, the viscous losses {} erg",
                synth.tds.options.bernoulli_cutoff_hz,
                b[1..].iter().map(|x| format!("{:.3e}", x.0)).collect::<Vec<_>>().join(" "),
                (1..5).map(|k| format!("{:.3e}", sum(&b[k].1) - sum(&b[k - 1].1))).collect::<Vec<_>>().join(" "),
                (1..5).map(|k| format!("{:.3e}", b[k].2 - b[k - 1].2)).collect::<Vec<_>>().join(" ")
            );
            let (last, before) = (&b[4].1, &b[3].1);
            let (section, given) = (0..last.len()).map(|i| (i, last[i] - before[i])).fold((0, 0.0f64), |w, x| if x.1 < w.1 { x } else { w });
            println!("in the last block, Bernoulli's terms gave most at section {section}: {:.3e} erg", -given);
        }
        return;
    }
    let mut out = vec![0.0; NUM_CHUNK_SAMPLES];
    let mut first_bad = None;
    let mut heard: Vec<f64> = Vec::new();
    for c in 0..=chunks {
        let t = c as f64 * NUM_CHUNK_SAMPLES as f64 / 48000.0;
        g[1] = lungs * (1.0 - (-t / 0.012).exp());
        let made = if c == 0 { 0 } else { NUM_CHUNK_SAMPLES };
        synth.add_tract(&mut tract, &tract_params, &g, &mut out[..made]);
        heard.extend_from_slice(&out[..made]);
        let peak = out[..made].iter().fold(0.0f64, |a, x| if x.is_finite() { a.max(x.abs()) } else { f64::INFINITY });
        if first_bad.is_none() && !(peak < 100.0) {
            first_bad = Some(t);
        }
        let every: usize = std::env::var("EVERY").ok().and_then(|x| x.parse().ok()).unwrap_or(20);
        if c % every == 0 || (first_bad.is_some() && first_bad.unwrap() == t) {
            let (_, l) = synth.glottis.tube_data();
            println!(
                "{t:.4} s: peak {peak:.3e}; glottal areas {:.3} {:.3} cm2; pressure below, lower, upper, above {:.0} {:.0} {:.0} {:.0} dPa; supraglottal filtered {:.1}; amplitude {:.5}",
                l[0], l[1], synth.tds.section_pressure(LOWER_GLOTTIS_SECTION - 1), synth.tds.section_pressure(LOWER_GLOTTIS_SECTION), synth.tds.section_pressure(UPPER_GLOTTIS_SECTION), synth.tds.section_pressure(UPPER_GLOTTIS_SECTION + 1), synth.glottis.supraglottal_pressure(), synth.glottis.derived.amplitude
            );
        }
        if first_bad.is_some() && t > first_bad.unwrap() + 0.01 {
            break;
        }
    }
    println!("steps {n}: {}", first_bad.map_or("finite throughout".to_string(), |t| format!("not finite from {t:.3} s")));
    // (BANDS=1: the last 16384 samples' level and their third-octave bands from 100 Hz to 16 kHz, dB.)
    if std::env::var("BANDS").is_ok() && heard.len() >= 16384 {
        let x = &heard[heard.len() - 16384..];
        let rms = (x.iter().map(|v| v * v).sum::<f64>() / x.len() as f64).sqrt();
        let power: Vec<f64> = (0..8192)
            .map(|k| {
                let (mut re, mut im) = (0.0, 0.0);
                for (j, v) in x.iter().enumerate() {
                    let w = 0.5 - 0.5 * (2.0 * std::f64::consts::PI * j as f64 / 16384.0).cos();
                    let ph = 2.0 * std::f64::consts::PI * (k * j % 16384) as f64 / 16384.0;
                    re += w * v * ph.cos();
                    im -= w * v * ph.sin();
                }
                re * re + im * im
            })
            .collect();
        let bands: Vec<String> = (0..23)
            .map(|b| {
                let fc = 100.0 * 2f64.powf(b as f64 / 3.0);
                let (lo, hi) = (fc * 2f64.powf(-1.0 / 6.0), fc * 2f64.powf(1.0 / 6.0));
                let p: f64 = (0..8192).filter(|&k| { let f = k as f64 * 48000.0 / 16384.0; f >= lo && f < hi }).map(|k| power[k]).sum();
                format!("{:.1}", 10.0 * p.max(1e-30).log10())
            })
            .collect();
        println!("level {:.2} dB; bands {}", 20.0 * rms.log10(), bands.join(" "));
    }
}
