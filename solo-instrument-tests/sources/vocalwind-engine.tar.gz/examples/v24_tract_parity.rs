// The parity check's port side for VocalTractLab 2.4's geometry (src/v24), as examples/tract_parity.rs is 2.3's:
// `params`, every shape of a 2.4 speaker (JD2, M01, W02) and blends between random pairs of them, for
// reference/tract_parity.c built against 2.4's library; `compare`, the same through the port, number for number.
//   cargo run --release --example v24_tract_parity -- JD2.speaker params params.txt
//   cargo run --release --example v24_tract_parity -- JD2.speaker compare params.txt tubes.txt
use musebots_vocaltract::v24::tract::{VocalTract, NUM_PARAMS, NUM_TUBE_SECTIONS as NT};
use musebots_vocaltract::xml;

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let root = xml::parse(&std::fs::read_to_string(&args[0]).expect("speaker")).expect("a speaker file");
    let mut vt = VocalTract::from_xml(root.child("vocal_tract_model").expect("vocal tract")).expect("anatomy");
    match args[1].as_str() {
        "params" => {
            let mut lines: Vec<[f64; NUM_PARAMS]> = vt.shapes.iter().map(|(_, v)| *v).collect();
            let n = lines.len();
            let mut seed: u64 = 20261111;
            let mut rnd = || {
                seed = seed.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
                (seed >> 11) as f64 / (1u64 << 53) as f64
            };
            for _ in 0..200 {
                let (a, b, t) = ((rnd() * n as f64) as usize, (rnd() * n as f64) as usize, rnd());
                let mut v = [0.0; NUM_PARAMS];
                for k in 0..NUM_PARAMS {
                    v[k] = (1.0 - t) * lines[a][k] + t * lines[b][k];
                }
                lines.push(v);
            }
            let text: String = lines.iter().map(|v| v.iter().map(|x| format!("{x:.17e}")).collect::<Vec<_>>().join(" ") + "\n").collect();
            std::fs::write(&args[2], text).expect("write");
            println!("v24_tract_parity: {} parameter lines", lines.len());
        }
        _ => {
            let params = std::fs::read_to_string(&args[2]).expect("params");
            let tubes = std::fs::read_to_string(&args[3]).expect("tubes");
            let (mut lines, mut identical, mut worst, mut first_bad) = (0, 0, 0.0f64, None);
            for (i, (p, t)) in params.lines().zip(tubes.lines()).enumerate() {
                let p: Vec<f64> = p.split_whitespace().map(|x| x.parse().unwrap()).collect();
                let want: Vec<f64> = t.split_whitespace().map(|x| x.parse().unwrap()).collect();
                vt.calculate(&p);
                let tube = vt.tube();
                let mut got: Vec<f64> = tube.length_cm.to_vec();
                // (As the tube takes them: no area under 0.01 mm^2, Tube::setPharynxMouthGeometry.)
                got.extend(tube.area_cm2.iter().map(|&a| a.max(musebots_vocaltract::v24::tube::MIN_AREA_CM2)));
                got.extend(tube.articulator.iter().map(|a| *a as u8 as f64));
                // (2.4's tube takes the port's area as its first nose section's, floored as an area is, and reports that.)
                got.extend([tube.incisor_pos_cm, tube.tongue_tip_side_elevation, tube.velum_opening_cm2.max(musebots_vocaltract::v24::tube::MIN_AREA_CM2)]);
                assert_eq!(got.len(), 3 * NT + 3);
                let bits = got.iter().zip(&want).all(|(a, b)| a.to_bits() == b.to_bits() || (*a == 0.0 && *b == 0.0));
                let rel = got.iter().zip(&want).map(|(a, b)| (a - b).abs() / b.abs().max(1e-3)).fold(0.0, f64::max);
                if bits {
                    identical += 1;
                } else {
                    if first_bad.is_none() {
                        first_bad = Some(i);
                    }
                    if std::env::var("VTL_SHOW").map(|v| v == i.to_string()).unwrap_or(false) {
                        for (k, (a, b)) in got.iter().zip(&want).enumerate() {
                            if a.to_bits() != b.to_bits() {
                                println!("  line {i} value {k}: port {a:.17e} VocalTractLab {b:.17e}");
                            }
                        }
                    }
                }
                worst = worst.max(rel);
                lines += 1;
            }
            println!("v24_tract_parity: {lines} tubes, {identical} identical, first differing {}, largest relative difference {worst:.3e}", first_bad.map(|i| i.to_string()).unwrap_or("none".into()));
        }
    }
}
