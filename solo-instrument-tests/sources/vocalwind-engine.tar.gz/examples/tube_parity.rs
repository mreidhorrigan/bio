// The parity check's port side for the tube's acoustics: the frames reference/tube_parity.c wrote, played through the port
// as VocalTractLab's API plays them (vtlSynthesisReset, then vtlSynthesisAddTube a frame at a time: its persistent tube
// given each frame's pharynx and mouth, velum and no aspiration, the synthesizer interpolating), the audio compared with
// the reference's sample for sample.
//   cargo run --release --example tube_parity -- JD3.speaker frames.txt audio.f64 [port.f64]
use musebots_vocaltract::speaker::Speaker;
use musebots_vocaltract::synth::Synthesizer;
use musebots_vocaltract::tds::TdsModel;
use musebots_vocaltract::tube::{Articulator, Tube, NUM_PHARYNX_MOUTH_SECTIONS as NT};

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let speaker = Speaker::read(&args[0]).expect("speaker");
    let frames = std::fs::read_to_string(&args[1]).expect("frames");
    let reference: Vec<f64> = std::fs::read(&args[2]).expect("audio").chunks_exact(8).map(|b| f64::from_le_bytes(b.try_into().unwrap())).collect();
    let mut tds = TdsModel::new();
    tds.options.generate_noise_sources = !args.iter().any(|a| a == "quiet");
    let mut synth = Synthesizer::new(speaker.glottis, tds);
    let mut tube = Tube::new();
    // (vtlSynthesisReset)
    synth.reset();
    tube.reset_dynamic_part();
    let mut out = Vec::with_capacity(reference.len());
    let mut buffer = vec![0.0; 110];
    for (f, line) in frames.lines().enumerate() {
        let v: Vec<f64> = line.split_whitespace().map(|x| x.parse().unwrap()).collect();
        let (len, area) = (&v[0..NT], &v[NT..2 * NT]);
        let art: Vec<Articulator> = v[2 * NT..3 * NT].iter().map(|&a| Articulator::from_index(a as i32)).collect();
        let (inc, tts, vel) = (v[3 * NT], v[3 * NT + 1], v[3 * NT + 2]);
        let glottis = &v[3 * NT + 3..];
        tube.set_pharynx_mouth_geometry(len, area, &art, inc, tts);
        tube.set_velum_opening(vel);
        tube.set_aspiration_strength(0.0);
        let n = if f == 0 { 0 } else { 110 };
        synth.add_tube(glottis, &tube, &mut buffer[..n]);
        out.extend_from_slice(&buffer[..n]);
    }
    if let Some(path) = args.get(3).filter(|a| *a != "quiet") {
        std::fs::write(path, out.iter().flat_map(|x| x.to_le_bytes()).collect::<Vec<u8>>()).expect("write");
    }
    let n = out.len().min(reference.len());
    let first = (0..n).find(|&i| out[i].to_bits() != reference[i].to_bits());
    let max = (0..n).map(|i| (out[i] - reference[i]).abs()).fold(0.0, f64::max);
    let peak = reference.iter().fold(0.0f64, |m, x| m.max(x.abs()));
    println!(
        "tube_parity: {} samples (reference {}), {} identical, first difference {}, largest {:.3e} (peak {:.3e})",
        out.len(),
        reference.len(),
        (0..n).filter(|&i| out[i].to_bits() == reference[i].to_bits()).count(),
        first.map(|i| i.to_string()).unwrap_or("none".into()),
        max,
        peak
    );
}
