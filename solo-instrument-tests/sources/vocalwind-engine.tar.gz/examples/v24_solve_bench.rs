// The solve alone (src/v24/solve.rs), counted by the processor (src/counters.rs) on systems recorded from a passage: its
// systems every `every` steps at 1, 2 and 4 steps a sample, each solver run over each of them in turn, its instructions
// and cycles a solve; and 2.4's order's currents held against 2.4's order as the port made it before (a copy of that
// code here: the matrix negated whole, factorized over its envelope, then substituted), bit for bit.
//   cargo run --release --example v24_solve_bench -- JD2.speaker example01.seg [every]
use musebots_vocaltract::segments::parse_segments;
use musebots_vocaltract::v24::gestural::GesturalScore;
use musebots_vocaltract::v24::solve::{EnvelopeCholesky, System, TreeCholesky};
use musebots_vocaltract::v24::speaker::Speaker;
use musebots_vocaltract::v24::synth::{Synthesizer, NUM_CHUNK_SAMPLES};
use musebots_vocaltract::v24::tds::TdsModel;
use musebots_vocaltract::counters::Counts;

/// 2.4's order as the port made it at 0f7d1423f, on a dense copy of the system.
struct Before {
    n: usize,
    start: Vec<usize>,
    off: Vec<usize>,
    col_ptr: Vec<usize>,
    col_rows: Vec<usize>,
    matrix: Vec<f64>,
    factor: Vec<f64>,
    solution: Vec<f64>,
}

impl Before {
    fn new(s: &System) -> Before {
        let n = s.n;
        let start: Vec<usize> = (0..n).map(|i| (0..i).find(|&j| s.at(i, j) != s.zero_slot()).unwrap_or(i)).collect();
        let mut off = vec![0; n + 1];
        for i in 0..n {
            off[i + 1] = off[i] + i - start[i] + 1;
        }
        let (mut col_ptr, mut col_rows) = (vec![0; n + 1], Vec::new());
        for j in 0..n {
            col_ptr[j] = col_rows.len();
            for i in j + 1..n {
                if start[i] <= j {
                    col_rows.push(i);
                }
            }
        }
        col_ptr[n] = col_rows.len();
        Before { n, factor: vec![0.0; off[n]], start, off, col_ptr, col_rows, matrix: vec![0.0; n * n], solution: vec![0.0; n] }
    }

    fn load(&mut self, s: &System) {
        let n = self.n;
        for i in 0..n {
            for j in 0..n {
                self.matrix[i * n + j] = if j <= i { s.get(i, j) } else { 0.0 };
            }
            self.solution[i] = s.rhs[i];
        }
    }

    fn solve(&mut self, flow: &mut [f64]) {
        let n = self.n;
        let (start, off, col_ptr, col_rows) = (&self.start, &self.off, &self.col_ptr, &self.col_rows);
        let (m, f) = (&self.matrix, &mut self.factor);
        for i in 0..n {
            let s = start[i];
            for (x, y) in f[off[i]..off[i + 1]].iter_mut().zip(&m[i * n + s..=i * n + i]) {
                *x = -*y;
            }
        }
        for x in self.solution.iter_mut() {
            *x = -*x;
        }
        for k in 0..n {
            let sk = start[k];
            let (upto, below) = f.split_at_mut(off[k + 1]);
            let row_k = &mut upto[off[k]..];
            let mut d = row_k[k - sk];
            for &x in &row_k[..k - sk] {
                d -= x * x;
            }
            if d < 0.0 {
                d = 0.0;
            }
            d = d.sqrt();
            row_k[k - sk] = d;
            for &i in &col_rows[col_ptr[k]..col_ptr[k + 1]] {
                let si = start[i];
                let row_i = &mut below[off[i] - off[k + 1]..off[i + 1] - off[k + 1]];
                let from = si.max(sk);
                let mut sum = row_i[k - si];
                for (a, b) in row_i[from - si..k - si].iter().zip(&row_k[from - sk..k - sk]) {
                    sum -= a * b;
                }
                row_i[k - si] = sum / d;
            }
        }
        let solution = &mut self.solution;
        for k in 0..n {
            let sk = start[k];
            let row_k = &f[off[k]..off[k + 1]];
            let mut sum = solution[k];
            for (a, b) in row_k[..k - sk].iter().zip(&solution[sk..k]) {
                sum -= a * b;
            }
            solution[k] = sum / row_k[k - sk];
        }
        for k in (0..n).rev() {
            let mut sum = solution[k];
            for &i in &col_rows[col_ptr[k]..col_ptr[k + 1]] {
                sum -= f[off[i] + k - start[i]] * flow[i];
            }
            solution[k] = sum;
            flow[k] = sum / f[off[k + 1] - 1];
        }
    }
}

fn main() {
    // (Counted where a live voice runs: on the performance cores.)
    musebots_vocaltract::counters::prefer_performance_cores();
    let args: Vec<String> = std::env::args().skip(1).collect();
    let speaker = Speaker::read(&args[0]).expect("speaker");
    let every: usize = args.get(2).and_then(|s| s.parse().ok()).unwrap_or(997);
    let text = std::fs::read_to_string(&args[1]).expect("segments");
    let mut tract = speaker.tract.clone();
    let mut score = GesturalScore::test();
    score.from_segments(&parse_segments(&text), &mut tract);
    let frames = score.frames(&tract, &speaker.glottis);
    let mut systems: Vec<System> = Vec::new();
    for n in [1usize, 2, 4] {
        let mut synth = Synthesizer::new(speaker.glottis.clone(), TdsModel::new());
        synth.set_oversampling(n);
        let mut tract = speaker.tract.clone();
        let mut buffer = vec![0.0; 1];
        let mut steps = 0;
        // (A sample at a time, so that the system can be taken after any step.)
        for (f, (tp, gp)) in frames.iter().enumerate() {
            tract.calculate(tp);
            let geometry = tract.tube();
            if f == 0 {
                synth.add_geometry(&geometry, gp, &mut buffer[..0]);
                continue;
            }
            let mut out = vec![0.0; NUM_CHUNK_SAMPLES];
            synth.add_geometry(&geometry, gp, &mut out);
            steps += NUM_CHUNK_SAMPLES * n;
            if steps / every != (steps - NUM_CHUNK_SAMPLES * n) / every {
                systems.push(synth.tds.system().clone());
            }
        }
    }
    println!("v24_solve_bench: {} systems", systems.len());
    let n = systems[0].n;
    let mut before = Before::new(&systems[0]);
    let mut envelope = EnvelopeCholesky::new(&systems[0]);
    let (mut a, mut b) = (vec![0.0; n], vec![0.0; n]);
    let mut differ = 0;
    for s in &systems {
        before.load(s);
        before.solve(&mut a);
        envelope.solve(s, &mut b);
        differ += a.iter().zip(&b).any(|(x, y)| x.to_bits() != y.to_bits()) as usize;
    }
    println!("v24_solve_bench: 2.4's order, as made now, against as made before: {differ} of {} systems differ", systems.len());
    let mut tree = TreeCholesky::new(&systems[0]);
    println!(
        "v24_solve_bench: the tree's order: {} entries below the diagonal (2.4's {}), {} products (2.4's 996), its longest chain of pivots {}, its last pivot current {}",
        tree.len(),
        envelope.len(),
        tree.updates(),
        tree.height,
        tree.order[n - 1]
    );
    // Each solver run on each system in turn (the dense copy loaded outside the count, as the engine wrote it in place),
    // `reps` times over.
    let reps = 20;
    let count = |f: &mut dyn FnMut(&System)| -> Counts {
        let c0 = Counts::now().expect("counts (macOS)");
        for s in &systems {
            for _ in 0..reps {
                f(s);
            }
        }
        Counts::now().unwrap().since(&c0)
    };
    let solves = (systems.len() * reps) as f64;
    let now = count(&mut |s| envelope.solve(s, &mut b));
    let treed = count(&mut |s| tree.solve(s, &mut b));
    // (The copy loaded once a system, outside the count: a solve's own work alone.)
    let c0 = Counts::now().unwrap();
    let mut loading = Counts::default();
    for s in &systems {
        let l0 = Counts::now().unwrap();
        before.load(s);
        let l = Counts::now().unwrap().since(&l0);
        for k in 0..2 {
            loading.levels[k].instructions += l.levels[k].instructions;
            loading.levels[k].cycles += l.levels[k].cycles;
            loading.levels[k].time_ns += l.levels[k].time_ns;
        }
        for _ in 0..reps {
            before.solve(&mut a);
        }
    }
    let mut was = Counts::now().unwrap().since(&c0);
    for k in 0..2 {
        was.levels[k].instructions -= loading.levels[k].instructions;
        was.levels[k].cycles -= loading.levels[k].cycles;
        was.levels[k].time_ns -= loading.levels[k].time_ns;
    }
    let clock = now.clock_hz(0);
    println!("v24_solve_bench: 2.4's order as made before: {}", was.report(solves, "solve", clock));
    println!("v24_solve_bench: 2.4's order as made now:    {}", now.report(solves, "solve", clock));
    println!("v24_solve_bench: the tube's own order:       {}", treed.report(solves, "solve", clock));
}
