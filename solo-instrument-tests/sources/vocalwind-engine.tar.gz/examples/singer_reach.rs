// Whether the choristers drawn by voice type (src/singers.rs) keep every vowel they sing, on the engine (the owner, 16
// November 2026: "have VocalWind support realistic physiological variation ... supported by the literature we have";
// the choir's design 2: "first a check on the engine", research/VOCALWIND_CHOIR.md, "The check on the engine"). A
// speaker's body as vtl-blend makes it to sing a language (`vtl-blend write <file> JD2=1 language=la`), and for each
// voice type whose preset weighs that speaker, its choristers at the middle and the corners of their draws (tract and
// folds at the ends of `within`) laid on it by 2.4's setFor; each vowel shape's (its own and those made for the
// language) first three resonances (carry::resonances_fine) and least closable area on the engine, beside the body's
// own: the largest move (cents) and the least area's smallest ratio over the vowels, and each vowel whose area falls
// below half its own or whose resonance moves more than twice the tract's length explains and 100 cents (the vowel
// named, its moves, its areas).
//   cargo run --release --example singer_reach -- JD2:la:<JD2's Latin body.speaker> W02:la:<...> ...
// Its reach (`reach` first): the pharynx and larynx (H0 and H1) of each body scaled from 0.80 to 1.20 times its own, by
// 0.02, its hard palate (W1) at the shortest and the longest its group's tract is drawn (src/singers.rs), and the
// ratios at which every vowel the language is measured to sing (blend::language_shapes) keeps at least half its own
// least area, around 1 -- the worst of the body's other vowels beside it; `tongue=own` keeps the body's tongue (its
// radii, which 2.4's setFor scales with the pharynx and the mouth) to see what that scaling costs. Mended, as a score
// is sung.
use musebots_vocaltract::blend;
use musebots_vocaltract::carry::{least_closable_area, resonances_fine, settings};
use musebots_vocaltract::singers::{bodies, types_file};
use musebots_vocaltract::v24::anatomy::{self, ANATOMY_PARAMS, HARD_PALATE_LENGTH, LARYNX_LENGTH, PHARYNX_LENGTH};
use musebots_vocaltract::v24::glottis::{REST_F0, REST_LENGTH};
use musebots_vocaltract::v24::speaker::Speaker;
use musebots_vocaltract::v24::tract::{VocalTract, NUM_PARAMS};

/// A shape's first three resonances (Hz) and least closable area (cm2) on a tract, its parameters within their ranges.
fn heard(tract: &mut VocalTract, shape: &[f64; NUM_PARAMS]) -> ([f64; 3], f64) {
    let v: [f64; NUM_PARAMS] = std::array::from_fn(|k| shape[k].clamp(tract.param[k].min, tract.param[k].max));
    tract.calculate(&v);
    let tube = tract.tube();
    let f = resonances_fine(&tube, settings().top_hz);
    ([f[0], f[1], f.get(2).copied().unwrap_or(f64::NAN)], least_closable_area(&tube))
}

// (Every vowel's least area on a body's measures `x` over its own, at the worst, and the vowel there: of those sung
// (`sung`), and of the others.)
fn kept(body: &Speaker, vowels: &[String], own: &[([f64; 3], f64)], x: &[f64; 13], own_tongue: bool, sung: &[String]) -> [(f64, String); 2] {
    let mut tract = body.tract.clone();
    anatomy::set_for_unheld(x, &mut tract, &body.tract);
    if own_tongue {
        let o = &body.tract.anatomy;
        tract.anatomy.tongue_center_radius_x_cm = o.tongue_center_radius_x_cm;
        tract.anatomy.tongue_center_radius_y_cm = o.tongue_center_radius_y_cm;
        tract.anatomy.tongue_tip_radius_cm = o.tongue_tip_radius_cm;
        tract.init_reference_surfaces();
        tract.calculate_all();
    }
    let mut worst = [(f64::INFINITY, String::new()), (f64::INFINITY, String::new())];
    for (v, (_, a0)) in vowels.iter().zip(own) {
        let shape = tract.shape(v).unwrap();
        let (_, a) = heard(&mut tract, &shape);
        let w = &mut worst[usize::from(!sung.contains(v))];
        if a / a0 < w.0 {
            *w = (a / a0, v.clone());
        }
    }
    worst
}

fn reach(args: &[String]) {
    let b = bodies();
    let own_tongue = args.iter().any(|a| a == "tongue=own");
    for asked in args.iter().filter(|a| a.contains(':')) {
        let mut parts = asked.splitn(3, ':');
        let (Some(id), Some(language), Some(file)) = (parts.next(), parts.next(), parts.next()) else { panic!("{asked}: ID:LANGUAGE:FILE") };
        let mut body = Speaker::read(file).unwrap_or_else(|e| panic!("{e}"));
        // (Mended, as a score is sung (sing-score.mjs mended=1); `unmended` for 2.4's own.)
        body.tract.mended = !args.iter().any(|a| a == "unmended");
        let vowels: Vec<String> = body.tract.shapes.iter().map(|(n, _)| n.clone()).filter(|n| !n.contains('(') && !n.ends_with("-raw")).collect();
        let mut own_tract = body.tract.clone();
        let own: Vec<([f64; 3], f64)> = vowels.iter().map(|v| heard(&mut own_tract, &body.tract.shape(v).unwrap())).collect();
        let x = anatomy::of(&body.tract);
        let sung: Vec<String> = blend::language_shapes(language, &mut Default::default()).unwrap().into_iter().map(|(_, shape)| shape).filter(|s| vowels.contains(s)).collect();
        // (Its mouth at its group's tract's ends: the widest spread among the groups, at `within`'s edge.)
        let spread = b.groups.values().map(|g| g.tract_spread).fold(0.0, f64::max) * b.drawn(1.0);
        println!("{id} {language}{}: {} vowels, [{}] sung; each pharynx ratio's least area (x its own) and its vowel, the mouth x{:.3} | x{:.3}, of those sung (of the others)", if own_tongue { ", the body's tongue" } else { "" }, vowels.len(), sung.join(" "), 1.0 - spread, 1.0 + spread);
        // (The body laid at its own measures: setFor's round trip, against which a change of them is measured.)
        let [(least, v), (other, w)] = kept(&body, &vowels, &own, &x, own_tongue, &sung);
        println!("  laid at its own measures: {least:.2} [{v}] ({other:.2} [{w}]); the sung vowels' own least areas (cm2): {}", sung.iter().map(|s| format!("[{s}] {:.3}", own[vowels.iter().position(|v| v == s).unwrap()].1)).collect::<Vec<_>>().join(" "));
        if args.iter().any(|a| a == "own-only") {
            // (What the round trip changes: the anatomy, the parameters' ranges and neutral values, and the worst
            // vowel's shape, each as printed, for a diff.)
            let mut laid = body.tract.clone();
            anatomy::set_for_unheld(&x, &mut laid, &body.tract);
            let dir = std::env::var("ROUND_TRIP_DIR").unwrap_or_else(|_| ".".into());
            let ranges = |t: &musebots_vocaltract::v24::tract::VocalTract| t.param.iter().map(|p| format!("{} {} {} {}", p.name, p.min, p.max, p.neutral)).collect::<Vec<_>>().join("\n");
            let shape = |t: &musebots_vocaltract::v24::tract::VocalTract| t.shape(&v).unwrap().iter().zip(&t.param).map(|(x, p)| format!("{} {x}", p.name)).collect::<Vec<_>>().join("\n");
            std::fs::write(format!("{dir}/{id}-own.txt"), format!("{:#?}\n{}\n[{v}]\n{}\n", body.tract.anatomy, ranges(&body.tract), shape(&body.tract))).unwrap();
            std::fs::write(format!("{dir}/{id}-laid.txt"), format!("{:#?}\n{}\n[{v}]\n{}\n", laid.anatomy, ranges(&laid), shape(&laid))).unwrap();
            continue;
        }
        let mut passed = Vec::new();
        for i in 0..=20 {
            let r = 0.80 + 0.02 * i as f64;
            let mut line = format!("  {r:.2}");
            let mut ok = true;
            for mouth in [1.0 - spread, 1.0 + spread] {
                let mut m = x;
                m[PHARYNX_LENGTH] *= r;
                m[LARYNX_LENGTH] *= r;
                m[HARD_PALATE_LENGTH] *= mouth;
                let [(least, v), (other, w)] = kept(&body, &vowels, &own, &m, own_tongue, &sung);
                ok &= least >= 0.5;
                line += &format!("  {least:.2} [{v}] ({other:.2} [{w}])");
            }
            println!("{line}{}", if ok { "" } else { "  (closes)" });
            passed.push((r, ok));
        }
        // (The run of ratios that pass around 1.)
        let at_one = passed.iter().position(|&(r, _)| (r - 1.0).abs() < 1e-9).unwrap();
        let lo = (0..=at_one).rev().take_while(|&k| passed[k].1).last().map(|k| passed[k].0);
        let hi = (at_one..passed.len()).take_while(|&k| passed[k].1).last().map(|k| passed[k].0);
        println!("  {id} {language}: reach {}", match (lo, hi) {
            (Some(lo), Some(hi)) => format!("{lo:.2} to {hi:.2}"),
            _ => "none: its own closes a vowel".into(),
        });
    }
}

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    if args.first().map(String::as_str) == Some("reach") {
        return reach(&args[1..]);
    }
    let presets: serde_json::Value = serde_json::from_str(&std::fs::read_to_string(types_file()).unwrap()).unwrap();
    let b = bodies();
    let corners = [[0.5, 0.5], [0.0, 0.0], [0.0, 1.0], [1.0, 0.0], [1.0, 1.0]];
    for asked in std::env::args().skip(1) {
        let mut parts = asked.splitn(3, ':');
        let (Some(id), Some(language), Some(file)) = (parts.next(), parts.next(), parts.next()) else { panic!("{asked}: ID:LANGUAGE:FILE") };
        let types: Vec<&String> = b.types.keys().filter(|t| presets["presets"][t.as_str()].get(id).is_some()).collect();
        {
            let mut body = Speaker::read(file).unwrap_or_else(|e| panic!("{e}"));
            body.tract.mended = true;
            // (Its vowels: the shapes that are neither a consonant's, by its context, nor kept raw.)
            let vowels: Vec<String> = body.tract.shapes.iter().map(|(n, _)| n.clone()).filter(|n| !n.contains('(') && !n.ends_with("-raw")).collect();
            let mut own_tract = body.tract.clone();
            let own: Vec<([f64; 3], f64)> = vowels.iter().map(|v| heard(&mut own_tract, &body.tract.shape(v).unwrap_or_else(|| panic!("{id} {language}: no {v}")))).collect();
            let x = anatomy::of(&body.tract);
            let s = |k: usize| body.glottis.statics[k].x;
            println!("{id} {language}: {} vowels [{}]", vowels.len(), vowels.join(" "));
            for t in &types {
                for q in corners {
                    let c = b.chorister(t, q, &x, s(REST_LENGTH), s(REST_F0), b.reach_of(language, [id])).unwrap();
                    let mut tract = body.tract.clone();
                    anatomy::set_for_unheld(&c.measures, &mut tract, &body.tract);
                    let read = anatomy::of(&tract);
                    // (Measures setFor held in its ranges, where they differ from those asked.)
                    let held: Vec<String> = (0..x.len()).filter(|&k| (read[k] - c.measures[k]).abs() > 1e-6).map(|k| format!("{} {:.3} for {:.3}", ANATOMY_PARAMS[k].key, read[k], c.measures[k])).collect();
                    let (mut most, mut least, mut flagged) = (0.0f64, f64::INFINITY, Vec::new());
                    // (The tract's length as scaled, in cents: how far its resonances move with length alone.)
                    let by_length = 1200.0 * (c.pharynx * c.tract).log2().abs();
                    for (v, (f0, a0)) in vowels.iter().zip(&own) {
                        let shape = tract.shape(v).unwrap();
                        let (f, a) = heard(&mut tract, &shape);
                        let moves: Vec<f64> = (0..3).map(|k| 1200.0 * (f[k] / f0[k]).log2()).collect();
                        let m = moves.iter().fold(0.0f64, |m, x| m.max(x.abs()));
                        most = most.max(m);
                        least = least.min(a / a0);
                        if a < 0.5 * a0 || m > 2.0 * by_length + 100.0 {
                            flagged.push(format!("[{v}] {:+.0} {:+.0} {:+.0} c, area {:.3} for {:.3}", moves[0], moves[1], moves[2], a, a0));
                        }
                    }
                    println!(
                        "  {t:>13} at {:.1},{:.1}: pharynx x{:.3}, tract x{:.3}, folds x{:.3} (rest {:.2} cm {:.0} Hz); moves at most {most:.0} c, least area x{least:.2}{}{}",
                        q[0],
                        q[1],
                        c.pharynx,
                        c.tract,
                        c.folds,
                        c.rest_length,
                        c.rest_f0,
                        if held.is_empty() { String::new() } else { format!("; held: {}", held.join(", ")) },
                        if flagged.is_empty() { String::new() } else { format!("\n      {}", flagged.join("\n      ")) }
                    );
                }
            }
        }
    }
}
