// The parity check's port side for the whole synthesis: reference/synth_parity.c's frames played as vtlSynthBlock plays
// them (a reset, the first frame only set, then 110 samples a frame, each frame's vocal tract made by the port's
// geometry), the audio compared with VocalTractLab's sample for sample; and the time each part took.
//   cargo run --release --example synth_parity -- JD3.speaker frames.txt audio.f64 [port.f64]
use musebots_vocaltract::speaker::Speaker;
use musebots_vocaltract::synth::Synthesizer;
use musebots_vocaltract::tds::TdsModel;
use musebots_vocaltract::tract::{VocalTract, NUM_PARAMS};
use std::time::Instant;

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let speaker = Speaker::read(&args[0]).expect("speaker");
    let mut tract = VocalTract::from_xml(speaker.root.child("vocal_tract_model").expect("vocal tract")).expect("anatomy");
    let frames = std::fs::read_to_string(&args[1]).expect("frames");
    let reference: Vec<f64> = std::fs::read(&args[2]).expect("audio").chunks_exact(8).map(|b| f64::from_le_bytes(b.try_into().unwrap())).collect();
    let mut synth = Synthesizer::new(speaker.glottis, TdsModel::new());
    synth.reset();
    let mut out = Vec::with_capacity(reference.len());
    let mut buffer = vec![0.0; 110];
    let (mut geometry_s, mut acoustics_s) = (0.0, 0.0);
    for (f, line) in frames.lines().enumerate() {
        let v: Vec<f64> = line.split_whitespace().map(|x| x.parse().unwrap()).collect();
        let n = if f == 0 { 0 } else { 110 };
        let t0 = Instant::now();
        tract.calculate(&v[..NUM_PARAMS]);
        let geometry = tract.tube();
        let t1 = Instant::now();
        synth.add_geometry(&geometry, &v[NUM_PARAMS..], &mut buffer[..n]);
        let t2 = Instant::now();
        geometry_s += (t1 - t0).as_secs_f64();
        acoustics_s += (t2 - t1).as_secs_f64();
        out.extend_from_slice(&buffer[..n]);
    }
    if let Some(path) = args.get(3) {
        std::fs::write(path, out.iter().flat_map(|x| x.to_le_bytes()).collect::<Vec<u8>>()).expect("write");
    }
    let n = out.len().min(reference.len());
    let identical = (0..n).filter(|&i| out[i].to_bits() == reference[i].to_bits()).count();
    let first = (0..n).find(|&i| out[i].to_bits() != reference[i].to_bits());
    let largest = (0..n).map(|i| (out[i] - reference[i]).abs()).fold(0.0, f64::max);
    let audio_s = out.len() as f64 / 44100.0;
    println!(
        "synth_parity: {} samples (reference {}), {identical} identical, first difference {}, largest {largest:.3e}; {audio_s:.2} s of audio: geometry {:.3} s ({:.0}% of a core), acoustics {:.3} s ({:.0}%)",
        out.len(),
        reference.len(),
        first.map(|i| i.to_string()).unwrap_or("none".into()),
        geometry_s,
        100.0 * geometry_s / audio_s,
        acoustics_s,
        100.0 * acoustics_s / audio_s
    );
}
