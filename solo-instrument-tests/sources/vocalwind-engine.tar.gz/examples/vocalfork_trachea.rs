// What the trachea's resolution does to what the voice hears (src/v24/passive.rs, Trachea; the owner, 14 November
// 2026: "proceed ... with the trachea redesign, maintaining, with regard to the trachea, the ability to step up the
// accuracy for offline rendering"): a speaker's still vowels' networks in frequency (src/v24/passive/frequency.rs),
// laid with the trachea one element to each of its sections (the default) and as finely as the other static ducts
// (trachea=fine), the glottis open at each area asked (cm^2, both its sections; 0 shut, where the trachea takes no
// part) so that the flow put in above it reaches the trachea, the noise silent, the losses' law the default's. For
// each, as the engine plays it (stepped, at each layout's own rate) and with d/dt as s (continuous): the lips' transfer
// and the impedance above the glottis (Response::inlet), their largest difference in decibels in each band to 1, 2, 3,
// 4, 5, 6, 8 and 10 kHz, and where the largest of all lies (how far under its band's highest level: in a dip or on a
// peak); and the lips' transfer's resonances to 5 kHz -- each found in the fine network from the transfer's peaks on a 10-Hz
// grid, then in the other from it (Network::resonance) -- the default's shift in cents and its bandwidth's ratio.
//   cargo run --release --example vocalfork_trachea -- <speaker.speaker> [vowel,vowel,...] [area,area,...]
use musebots_vocaltract::v24::passive::frequency::{Complex, Network, Response, Stepping};
use musebots_vocaltract::v24::passive::{PassiveModel, Trachea, MAX_ELEMENT_CM};
use musebots_vocaltract::v24::speaker::Speaker;
use musebots_vocaltract::v24::tds::{TdsModel, TubeCoefficients};
use musebots_vocaltract::v24::tube::{Tube, MIN_AREA_CM2};

/// The bands the differences are taken in, each to its top (Hz) from the last's.
const BANDS: [f64; 8] = [1000.0, 2000.0, 3000.0, 4000.0, 5000.0, 6000.0, 8000.0, 10000.0];

/// In each band (BANDS), the largest difference (dB) between two responses' sizes on the grid; and the largest of all,
/// where it lies (Hz) and how far under its band's highest level (dB, `b`'s).
fn differences(grid: &[f64], a: &[Complex], b: &[Complex]) -> (Vec<f64>, (f64, f64, f64)) {
    let (mut each, mut worst, mut from) = (vec![0.0f64; BANDS.len()], (0.0f64, 0.0, 0.0), 0.0);
    for (j, &top) in BANDS.iter().enumerate() {
        let inside: Vec<usize> = (0..grid.len()).filter(|&i| grid[i] > from && grid[i] <= top).collect();
        let highest = inside.iter().fold(0.0f64, |m, &i| m.max(b[i].abs()));
        for &i in &inside {
            let d = (20.0 * (a[i].abs() / b[i].abs()).log10()).abs();
            each[j] = each[j].max(d);
            if d > worst.0 {
                worst = (d, grid[i], 20.0 * (highest / b[i].abs()).log10());
            }
        }
        from = top;
    }
    (each, worst)
}

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let sp = Speaker::read(&args[0]).expect("speaker");
    let vowels: Vec<String> = args.get(1).map_or(vec!["a".into(), "i".into(), "u".into()], |s| s.split(',').map(String::from).collect());
    let areas: Vec<f64> = args.get(2).map_or(vec![0.0, 0.1, 1.0], |s| s.split(',').map(|x| x.parse().expect("an area, cm^2")).collect());
    let mut options = TdsModel::new().options;
    options.generate_noise_sources = false;
    // the default's network and the fine one's, each laid for the speaker, with its steps a sample
    let laid: Vec<(PassiveModel, usize)> = [Trachea::Sections, Trachea::Finer(MAX_ELEMENT_CM)]
        .into_iter()
        .map(|trachea| PassiveModel::for_speaker(&sp.tract, &sp.glottis, { let mut o = options; o.fork_trachea = trachea; o }))
        .collect();
    let mut glottis = sp.glottis.clone();
    glottis.calc_geometry();
    let (lengths, _) = glottis.tube_data();
    println!(
        "{}: the trachea by sections at {} steps a sample, fine at {}; the stepped responses each at its own rate",
        args[0].rsplit('/').next().unwrap(),
        laid[0].1,
        laid[1].1
    );
    let grid: Vec<f64> = (0..).map(|i| 50.0 + 10.0 * i as f64).take_while(|&f| f <= 10000.0).collect();
    let (mut worst_cents, mut worst_ratio) = (0.0f64, 1.0f64);
    for vowel in &vowels {
        let params = sp.tract.shape(vowel).expect("a shape of the speaker's");
        let mut tract = sp.tract.clone();
        tract.calculate(&params);
        let mut tube = Tube::new();
        tube.set_from_tract(&tract.tube());
        let mut tds = TdsModel::new();
        tds.options = options;
        tds.set_tube(&tube, false);
        let mut k = TubeCoefficients::default();
        tds.tube_coefficients(&mut k);
        for &area in &areas {
            let networks: Vec<Network> = laid
                .iter()
                .map(|(model, steps)| {
                    let mut model = model.clone();
                    model.set_rate(48000.0 * *steps as f64);
                    model.set_glottis_sections(&lengths, &[area.max(MIN_AREA_CM2); 2]);
                    model.set_pressure_source(0.0, 0);
                    model.network(&k)
                })
                .collect();
            println!(
                "/{vowel}/, the glottis {}: the largest difference (dB) in each band to 1, 2, 3, 4, 5, 6, 8 and 10 kHz",
                if area > MIN_AREA_CM2 { format!("{area} cm^2") } else { "shut".into() }
            );
            for (stepping, name) in [(Stepping::Stepped, "stepped"), (Stepping::Continuous, "continuous")] {
                let answers: Vec<Vec<_>> = networks.iter().map(|n| grid.iter().map(|&f| n.response(Complex::tone(f), stepping)).collect()).collect();
                for (what, pick) in [("the lips' transfer", (|r: &Response| r.mouth) as fn(&Response) -> Complex), ("the impedance", |r: &Response| r.inlet)] {
                    let (a, b): (Vec<Complex>, Vec<Complex>) = (answers[0].iter().map(pick).collect(), answers[1].iter().map(pick).collect());
                    let (each, (_, f, under)) = differences(&grid, &a, &b);
                    let row: Vec<String> = each.iter().map(|x| format!("{x:7.4}")).collect();
                    println!("   {:30} {}; the largest at {f} Hz, {under:.1} dB under its band's highest", format!("{what}, {name}"), row.join(" "));
                }
            }
            // the resonances to 5 kHz, as the engine plays them
            let size: Vec<f64> = grid.iter().map(|&f| networks[1].response(Complex::tone(f), Stepping::Stepped).mouth.abs()).collect();
            for i in 1..grid.len() - 1 {
                if grid[i] > 5000.0 || !(size[i] > size[i - 1] && size[i] >= size[i + 1]) {
                    continue;
                }
                let fine = networks[1].resonance(Complex::resonance(grid[i], 60.0), Stepping::Stepped);
                let sections = fine.and_then(|p| networks[0].resonance(p, Stepping::Stepped));
                match (fine, sections) {
                    (Some(p), Some(q)) => {
                        let ((fp, bp), (fq, bq)) = (p.frequency_and_bandwidth(), q.frequency_and_bandwidth());
                        let (cents, ratio) = (1200.0 * (fq / fp).log2(), bq / bp);
                        worst_cents = worst_cents.max(cents.abs());
                        worst_ratio = if (ratio - 1.0).abs() > (worst_ratio - 1.0).abs() { ratio } else { worst_ratio };
                        println!("   {fp:9.2} Hz, {bp:8.2} wide: by sections {cents:+8.4} cents, its bandwidth {ratio:.5} of the fine one's");
                    }
                    _ => println!("   (a peak at {} Hz: its pole not settled in both)", grid[i]),
                }
            }
        }
    }
    println!("the resonances to 5 kHz: by sections at most {worst_cents:.4} cents from the fine trachea's, the bandwidths' ratio at worst {worst_ratio:.5}");
}
