// A vowel made from a speaker's space brought to sound at its place (src/vowel_space.rs SpeakerSpace::heard; the owner,
// 16 November 2026, of design 1: "Yes, proceed"), checked on the engine:
//   1. each of a speaker's own vowels rebuilt from its others where its sound puts it, as read and as brought there:
//      its first three resonances in cents from its own (F1 and F2 brought; F3 left to the shape), the times sounded;
//   2. each language's measured vowels (languages/vowel-places.json, clarity 0) made from the speaker's space, as read
//      and as brought: F1 and F2 in cents from where the speaker's map puts the place, steps and time;
//   3. a vowel one speaker lacks, made where another's own sound puts it (src/blend.rs vowels_made): JD2's /M/ [ɯ] on
//      M01's space, read and brought.
//   cargo run --release --example vowel_heard -- [JD2,M01,W02] [languages: 2 and 3 alone]
use musebots_vocaltract::blend::{self, Voices};
use musebots_vocaltract::carry::resonances_fine;
use musebots_vocaltract::v24::speaker::Speaker;
use musebots_vocaltract::v24::tract::{VocalTract, NUM_PARAMS};
use musebots_vocaltract::vowel_space::{space, Anchor, Place};
use std::time::Instant;

const TOP_HZ: f64 = 5000.0;
const LANGUAGES: [(&str, &str); 2] = [("en", "i,ɪ,ɛ,æ,ɑ,ɔ,ʊ,u,ʌ,ə"), ("la", "a,e,ɛ,i,o,ɔ,u")];

fn formants(tract: &mut VocalTract, shape: &[f64; NUM_PARAMS]) -> Vec<f64> {
    let v: [f64; NUM_PARAMS] = std::array::from_fn(|k| shape[k].clamp(tract.param[k].min, tract.param[k].max));
    tract.calculate(&v);
    resonances_fine(&tract.tube(), TOP_HZ).into_iter().take(3).collect()
}

fn cents(a: &[f64], b: &[f64]) -> Vec<f64> {
    a.iter().zip(b).map(|(x, y)| 1200.0 * (x / y).log2()).collect()
}

fn show(c: &[f64]) -> String {
    c.iter().map(|x| format!("{x:6.0}")).collect()
}

fn rms(xs: &[f64]) -> f64 {
    (xs.iter().map(|x| x * x).sum::<f64>() / xs.len().max(1) as f64).sqrt()
}

fn largest(xs: &[f64]) -> f64 {
    xs.iter().map(|x| x.abs()).fold(0.0, f64::max)
}

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let speakers: Vec<String> = args.first().map_or("JD2,M01,W02".into(), |s| s.clone()).split(',').map(String::from).collect();
    let voices = Voices::read(&blend::voices_file()).unwrap_or_else(|e| panic!("{e}"));
    let home = blend::synthesis_home();
    let s = space();
    let tract_of = |id: &str| Speaker::parse(&voices.blend_text(&home, &format!("{id}=1")).unwrap_or_else(|e| panic!("{e}"))).unwrap_or_else(|e| panic!("{id}: {e}")).tract;
    // (`scan LANGUAGE IPA`: the space's sound on a grid about the vowel's place, each point's F1 and F2 in cents from
    // the place's, the nearest found, to see whether what the bringing stopped at is the space's nearest.)
    if let [_, "scan", language, ipa] = args.iter().map(String::as_str).collect::<Vec<_>>()[..] {
        let mut tract = tract_of(&speakers[0]);
        let sounded = s.of_speaker(&mut tract).unwrap_or_else(|e| panic!("{e}"));
        let map = sounded.map.clone().expect("a sound map");
        let p = s.place_in(ipa, language, 0.0).unwrap_or_else(|e| panic!("{e}"));
        let (t1, t2) = map.sound(p);
        let mut best = (f64::MAX, 0.0, 0.0, [0.0; 2]);
        println!("[{ipa}] at {:.2},{:.2}: {t1:.0} {t2:.0} Hz; each point's distance (cents, F1 and F2's hypotenuse)", p.row, p.column);
        for i in -12..=12 {
            let row = p.row + 0.1 * i as f64;
            let mut line = format!("{row:5.2}");
            for j in -6..=6 {
                let column = p.column + 0.1 * j as f64;
                let f = formants(&mut tract, &sounded.space.at(Place { row, column, ..p }));
                let c = [1200.0 * (f[0] / t1).log2(), 1200.0 * (f[1] / t2).log2()];
                let d = c[0].hypot(c[1]);
                if d < best.0 {
                    best = (d, row, column, c);
                }
                line += &format!("{d:5.0}");
            }
            println!("{line}");
        }
        println!("nearest {:.0} cents ({:.0}, {:.0}) at {:.2},{:.2}", best.0, best.3[0], best.3[1], best.1, best.2);
        let h = sounded.heard(&mut tract, p).unwrap();
        println!("brought {:.0} cents ({:.0}, {:.0}) at {:.2},{:.2}", h.after[0].hypot(h.after[1]), h.after[0], h.after[1], h.read.row, h.read.column);
        return;
    }
    let (mut read_all, mut heard_all): (Vec<[f64; 3]>, Vec<[f64; 3]>) = (Vec::new(), Vec::new());
    let mut language_all: (Vec<[f64; 2]>, Vec<[f64; 2]>, usize, f64, usize) = (Vec::new(), Vec::new(), 0, 0.0, 0);
    for id in &speakers {
        let mut tract = tract_of(id);
        let by_symbol: Vec<Anchor> = s.anchors(|n| tract.shape(n));
        let own: Vec<Vec<f64>> = by_symbol.iter().map(|a| formants(&mut tract, &a.params)).collect();
        let mut anchors = by_symbol.clone();
        let map = s.place_by_sound(&mut anchors, &own.iter().map(|f| (f[0], f[1])).collect::<Vec<_>>()).unwrap_or_else(|e| panic!("{e}"));
        let rebuilt = args.get(1).map(String::as_str) != Some("languages");
        if rebuilt {
            println!("{id}: 1. each own vowel rebuilt from the others: its own (Hz); read, cents; brought, cents (sounded)");
        }
        let (mut read, mut heard) = (Vec::new(), Vec::new());
        for (k, a) in anchors.iter().enumerate().filter(|_| rebuilt) {
            let others: Vec<Anchor> = anchors.iter().zip(&by_symbol).filter(|(_, b)| b.place != by_symbol[k].place).map(|(a, _)| a.clone()).collect();
            let sp = s.speaker(&others).unwrap_or_else(|e| panic!("{e}"));
            let r = cents(&formants(&mut tract, &sp.at(a.place)), &own[k]);
            let h = sp.heard(&map, &mut tract, a.place).unwrap_or_else(|e| panic!("{e}"));
            let b = cents(&formants(&mut tract, &h.shape), &own[k]);
            println!("  {:>6} {}  {}  {}  ({}, {} tuned)", a.name, own[k].iter().map(|x| format!("{x:6.0}")).collect::<String>(), show(&r), show(&b), h.soundings, h.tuned);
            read.push([r[0], r[1], r[2]]);
            heard.push([b[0], b[1], b[2]]);
        }
        let line = |xs: &[[f64; 3]]| (0..3).map(|j| format!("{:5.0}/{:4.0}", rms(&xs.iter().map(|x| x[j]).collect::<Vec<_>>()), largest(&xs.iter().map(|x| x[j]).collect::<Vec<_>>()))).collect::<Vec<_>>().join(" ");
        println!("  rms/largest F1 F2 F3: read {}; brought {}", line(&read), line(&heard));
        read_all.extend(read);
        heard_all.extend(heard);

        let t = Instant::now();
        let sounded = s.of_speaker(&mut tract).unwrap_or_else(|e| panic!("{e}"));
        println!("  its space sounded in {:.2} s", t.elapsed().as_secs_f64());
        for (language, vowels) in LANGUAGES {
            println!("  2. {language}: each vowel's F1 F2 read, cents from its place; brought; sounded in reading; tuning steps; s");
            for ipa in vowels.split(',') {
                let p = s.place_in(ipa, language, 0.0).unwrap_or_else(|e| panic!("{e}"));
                let t = Instant::now();
                let h = sounded.heard(&mut tract, p).unwrap_or_else(|e| panic!("{e}"));
                let took = t.elapsed().as_secs_f64();
                println!("   [{ipa}] {}  {}  {:3} {:2} {took:5.2}  read at {:4.2},{:4.2} for {:4.2},{:4.2}", show(&h.before), show(&h.after), h.soundings, h.tuned, h.read.row, h.read.column, p.row, p.column);
                language_all.0.push(h.before);
                language_all.1.push(h.after);
                language_all.2 += h.soundings;
                language_all.3 += took;
                language_all.4 += 1;
            }
        }
    }
    let line3 = |xs: &[[f64; 3]]| (0..3).map(|j| format!("{:5.0}/{:4.0}", rms(&xs.iter().map(|x| x[j]).collect::<Vec<_>>()), largest(&xs.iter().map(|x| x[j]).collect::<Vec<_>>()))).collect::<Vec<_>>().join(" ");
    let line2 = |xs: &[[f64; 2]]| (0..2).map(|j| format!("{:5.1}/{:5.1}", rms(&xs.iter().map(|x| x[j]).collect::<Vec<_>>()), largest(&xs.iter().map(|x| x[j]).collect::<Vec<_>>()))).collect::<Vec<_>>().join(" ");
    println!("every speaker's 1 (rms/largest F1 F2 F3): read {}; brought {}", line3(&read_all), line3(&heard_all));
    let n = language_all.4 as f64;
    println!("every speaker's 2 (rms/largest F1 F2): read {}; brought {}; {:.1} soundings and {:.2} s a vowel", line2(&language_all.0), line2(&language_all.1), language_all.2 as f64 / n, language_all.3 / n);
    if speakers.iter().any(|i| i == "M01") {
        let (mut jd2, mut m01) = (tract_of("JD2"), tract_of("M01"));
        let (hj, hm) = (s.of_speaker(&mut jd2).unwrap(), s.of_speaker(&mut m01).unwrap());
        let m = jd2.shape("M").expect("JD2's /M/");
        let theirs = formants(&mut jd2, &m);
        let p = hj.map.as_ref().unwrap().place((theirs[0], theirs[1]), 1.0);
        let p = Place { rounding: 0.0, ..p };
        let read = formants(&mut m01, &hm.space.at(p));
        let h = hm.heard(&mut m01, p).unwrap();
        let brought = formants(&mut m01, &h.shape);
        let u = m01.shape("u").unwrap();
        let u = formants(&mut m01, &u);
        println!("3. JD2's /M/ [ɯ] {} at {:4.2},{:4.2}; on M01's space read {} ({}), brought {} ({}); M01's /u/ {}", show(&theirs), p.row, p.column, show(&read), show(&h.before), show(&brought), show(&h.after), show(&u));
    }
}
