// The parity check's port side for VocalTractLab 2.4's gestural score: a .ges file read, its curves read every 120
// samples (src/v24/gestural.rs) and set against 2.4's own (reference/v24_gestural_parity.cpp's frames), then
// synthesized as Synthesizer::synthesizeGesturalScore does (a reset, the first frame only set, then 120 samples a
// frame) and the audio compared with 2.4's sample for sample. Given a .seg, the port makes its own score by 2.4's rules
// (src/v24/segments.rs), compares it as text with the one 2.4 made and saved, and plays its own.
//   cargo run --release --example v24_gestural_parity -- JD2.speaker score.ges frames.txt audio.f64
//   cargo run --release --example v24_gestural_parity -- JD2.speaker phones.seg frames.txt audio.f64 made.ges
use musebots_vocaltract::segments::parse_segments;
use musebots_vocaltract::v24::gestural::GesturalScore;
use musebots_vocaltract::v24::speaker::Speaker;
use musebots_vocaltract::v24::synth::Synthesizer;
use musebots_vocaltract::v24::tds::TdsModel;
use std::time::Instant;

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let speaker = Speaker::read(&args[0]).expect("speaker");
    let mut tract = speaker.tract.clone();
    let text = if args[1].ends_with(".seg") {
        let segs = parse_segments(&std::fs::read_to_string(&args[1]).expect("segments"));
        let mut made = GesturalScore::test();
        let t0 = Instant::now();
        made.from_segments(&segs, &mut tract);
        let ours = made.to_xml();
        let theirs = std::fs::read_to_string(&args[4]).expect("2.4's score");
        let lines = ours.lines().zip(theirs.lines()).filter(|(a, b)| a != b).count();
        println!("v24_gestural_parity: {} segments into a score in {:.2} s; its text {} ({lines} lines differ of {}, {} against {})", segs.len(), t0.elapsed().as_secs_f64(), if ours == theirs { "identical to 2.4's" } else { "differs" }, theirs.lines().count(), ours.lines().count(), theirs.lines().count());
        for (a, b) in ours.lines().zip(theirs.lines()).filter(|(a, b)| a != b).take(6) {
            println!("  port: {a}\n  2.4:  {b}");
        }
        ours
    } else {
        std::fs::read_to_string(&args[1]).expect("score")
    };
    let (score, in_range) = GesturalScore::parse(&text).expect("a gestural score");
    let t0 = Instant::now();
    let frames = score.frames(&tract, &speaker.glottis);
    let theirs: Vec<Vec<f64>> = std::fs::read_to_string(&args[2]).expect("frames").lines().map(|l| l.split_whitespace().map(|x| x.parse().unwrap()).collect()).collect();
    let mut same = 0;
    let mut largest: f64 = 0.0;
    let mut first: Option<(usize, usize)> = None;
    for (f, ((tp, gp), t)) in frames.iter().zip(&theirs).enumerate() {
        for (k, (a, b)) in tp.iter().chain(gp.iter()).zip(t).enumerate() {
            if a.to_bits() == b.to_bits() {
                same += 1;
            } else {
                largest = largest.max((a - b).abs());
                first.get_or_insert((f, k));
            }
        }
    }
    println!(
        "v24_gestural_parity: {} frames (reference {}){}, {same} values identical, first difference {}, largest {largest:.3e}",
        frames.len(),
        theirs.len(),
        if in_range { "" } else { " (values out of range)" },
        first.map(|(f, k)| format!("frame {f} value {k}")).unwrap_or("none".into())
    );
    let reference: Vec<f64> = std::fs::read(&args[3]).expect("audio").chunks_exact(8).map(|b| f64::from_le_bytes(b.try_into().unwrap())).collect();
    let mut tds = TdsModel::new();
    // (2.4 as it is, its noise's speed not held under sound's; VTL_BOUND holds it so, as the tools do, to see that it
    // leaves the examples as 2.4 has them.)
    tds.options.bound_noise_velocity = std::env::var("VTL_BOUND").is_ok();
    // (2.4's whole pressure recovered at a junction with a side branch, as it is.)
    tds.options.recover_at_branches = false;
    tds.options.passive_bernoulli = false;
    let mut synth = Synthesizer::new(speaker.glottis.clone(), tds);
    let mut out = Vec::with_capacity(reference.len());
    let mut buffer = vec![0.0; 120];
    for (f, (tp, gp)) in frames.iter().enumerate() {
        let n = if f == 0 { 0 } else { 120 };
        synth.add_tract(&mut tract, tp, gp, &mut buffer[..n]);
        out.extend_from_slice(&buffer[..n]);
    }
    let wall = t0.elapsed().as_secs_f64();
    let n = out.len().min(reference.len());
    let identical = (0..n).filter(|&i| out[i].to_bits() == reference[i].to_bits()).count();
    let first = (0..n).find(|&i| out[i].to_bits() != reference[i].to_bits());
    let largest = (0..n).map(|i| (out[i] - reference[i]).abs()).fold(0.0, f64::max);
    println!(
        "v24_gestural_parity: {} samples (reference {}), {identical} identical, first difference {}, largest {largest:.3e}; {:.2} s for {:.2} s",
        out.len(),
        reference.len(),
        first.map(|i| i.to_string()).unwrap_or("none".into()),
        wall,
        out.len() as f64 / 48000.0
    );
}
