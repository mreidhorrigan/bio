// The geometry's cost a frame: every shape of the speaker and blends between them made over and over (for profiling).
//   cargo run --release --example bench_geometry -- JD3.speaker [seconds]
use musebots_vocaltract::speaker::Speaker;
use musebots_vocaltract::tract::{VocalTract, NUM_PARAMS};
use std::time::Instant;

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let speaker = Speaker::read(&args[0]).expect("speaker");
    let seconds: f64 = args.get(1).and_then(|s| s.parse().ok()).unwrap_or(3.0);
    let mut vt = VocalTract::from_xml(speaker.root.child("vocal_tract_model").unwrap()).unwrap();
    let shapes: Vec<[f64; NUM_PARAMS]> = vt.shapes.iter().map(|(_, v)| *v).collect();
    let t0 = Instant::now();
    let mut n = 0;
    while t0.elapsed().as_secs_f64() < seconds {
        for (i, s) in shapes.iter().enumerate() {
            let next = &shapes[(i + 7) % shapes.len()];
            let p: Vec<f64> = s.iter().zip(next).map(|(a, b)| 0.5 * (a + b)).collect();
            vt.calculate(&p);
            n += 1;
        }
    }
    let per = t0.elapsed().as_secs_f64() / n as f64;
    println!("bench_geometry: {n} frames, {:.3} ms a frame = {:.0}% of a core at 400.9 frames a second", 1e3 * per, 100.0 * per * 44100.0 / 110.0);
}
