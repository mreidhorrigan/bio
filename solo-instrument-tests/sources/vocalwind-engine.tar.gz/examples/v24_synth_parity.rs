// The parity check's port side for VocalTractLab 2.4's whole synthesis (src/v24: tract, glottis, acoustics,
// synthesizer): reference/v24_synth_parity.cpp's frames played as its Synthesizer plays them (the first frame only
// setting where it starts, then 120 samples a frame, each frame's tract made by the port's geometry), the audio compared
// with 2.4's sample for sample; and the time each part took.
//   cargo run --release --example v24_synth_parity -- JD2.speaker frames.txt audio.f64
use musebots_vocaltract::v24::speaker::Speaker;
use musebots_vocaltract::v24::synth::{Synthesizer, NUM_CHUNK_SAMPLES};
use musebots_vocaltract::v24::tds::TdsModel;
use musebots_vocaltract::v24::tract::NUM_PARAMS;
use std::time::Instant;

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let speaker = Speaker::read(&args[0]).expect("speaker");
    let mut tract = speaker.tract;
    let frames = std::fs::read_to_string(&args[1]).expect("frames");
    let reference: Vec<f64> = std::fs::read(&args[2]).expect("audio").chunks_exact(8).map(|b| f64::from_le_bytes(b.try_into().unwrap())).collect();
    // (2.4 as it is: its noise's speed not held under sound's.)
    let mut tds = TdsModel::new();
    tds.options.bound_noise_velocity = false;
    tds.options.recover_at_branches = false;
    tds.options.passive_bernoulli = false;
    let mut synth = Synthesizer::new(speaker.glottis, tds);
    // (VTL_NO_LOWPASS=out.f64: the passage made without the 12 kHz low-pass, and written there, to look at.)
    let unfiltered = std::env::var("VTL_NO_LOWPASS").ok();
    if unfiltered.is_some() {
        synth.lowpass = false;
    }
    let mut out = Vec::with_capacity(reference.len());
    let mut buffer = vec![0.0; NUM_CHUNK_SAMPLES];
    let (mut geometry_s, mut acoustics_s) = (0.0, 0.0);
    for (f, line) in frames.lines().enumerate() {
        let v: Vec<f64> = line.split_whitespace().map(|x| x.parse().unwrap()).collect();
        let n = if f == 0 { 0 } else { NUM_CHUNK_SAMPLES };
        let t0 = Instant::now();
        tract.calculate(&v[..NUM_PARAMS]);
        let geometry = tract.tube();
        let t1 = Instant::now();
        synth.add_geometry(&geometry, &v[NUM_PARAMS..], &mut buffer[..n]);
        let t2 = Instant::now();
        geometry_s += (t1 - t0).as_secs_f64();
        acoustics_s += (t2 - t1).as_secs_f64();
        out.extend_from_slice(&buffer[..n]);
    }
    if let Some(path) = &unfiltered {
        std::fs::write(path, out.iter().flat_map(|x| x.to_le_bytes()).collect::<Vec<u8>>()).expect("write");
    }
    let n = out.len().min(reference.len());
    let identical = (0..n).filter(|&i| out[i].to_bits() == reference[i].to_bits()).count();
    let first = (0..n).find(|&i| out[i].to_bits() != reference[i].to_bits());
    let largest = (0..n).map(|i| (out[i] - reference[i]).abs()).fold(0.0, f64::max);
    let audio_s = out.len() as f64 / 48000.0;
    println!(
        "v24_synth_parity: {} samples (reference {}), {identical} identical, first difference {}, largest {largest:.3e}; {audio_s:.2} s of audio: geometry {:.3} s ({:.0}% of a core), acoustics {:.3} s ({:.0}%)",
        out.len(),
        reference.len(),
        first.map(|i| i.to_string()).unwrap_or("none".into()),
        geometry_s,
        100.0 * geometry_s / audio_s,
        acoustics_s,
        100.0 * acoustics_s / audio_s
    );
}
