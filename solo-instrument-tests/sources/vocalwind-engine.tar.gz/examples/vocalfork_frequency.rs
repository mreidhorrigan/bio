// VocalWind's network in frequency (src/v24/passive/frequency.rs) on a speaker's still vowels: each tube's resonances,
// the poles of its lips' transfer, found in the network's continuous response (d/dt as s) and in the stepped one at
// the model's own rate -- the step's own error in each, in cents and in bandwidth -- and what a response costs against
// stepping the model through a transfer, as vocalfork_transfer does (counted by the processor: src/counters.rs). The
// glottis shut as vocalfork_transfer shuts it; the noise silent; the losses' law `losses` (fitted, the default; 2.4, zk,
// viscous, thermal). The resonances from the transfer's peaks on a 10-Hz grid to 12 kHz, each pole then found by the
// secant method (Network::resonance).
//   cargo run --release --example vocalfork_frequency -- <speaker.speaker> [vowel,vowel,...] [losses]
use musebots_vocaltract::counters::Counts;
use musebots_vocaltract::v24::passive::frequency::{Complex, Stepping};
use musebots_vocaltract::v24::passive::PassiveModel;
use musebots_vocaltract::v24::speaker::Speaker;
use musebots_vocaltract::v24::tds::{TdsModel, TubeCoefficients};
use musebots_vocaltract::v24::tube::{Tube, MIN_AREA_CM2};
use std::time::Instant;

/// The instructions retired since `began`, where the processor counts them.
fn counted(began: &Option<Counts>) -> Option<u64> {
    began.as_ref().and_then(|b| Counts::now().map(|now| now.since(b).instructions()))
}

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let sp = Speaker::read(&args[0]).expect("speaker");
    let vowels: Vec<String> = args.get(1).map_or(vec!["a".into(), "i".into(), "u".into()], |s| s.split(',').map(String::from).collect());
    let losses = args.get(2).cloned().unwrap_or_else(|| "fitted".into());
    let mut options = TdsModel::new().options;
    options.generate_noise_sources = false;
    let (_, steps) = PassiveModel::for_speaker(&sp.tract, &sp.glottis, options);
    let rate = 48000.0 * steps as f64;
    let mut glottis = sp.glottis.clone();
    glottis.calc_geometry();
    let (lengths, _) = glottis.tube_data();
    println!("{}: VocalFork's network at {steps} steps a sample, {rate} Hz; losses={losses}", args[0].rsplit('/').next().unwrap());
    for vowel in &vowels {
        let params = sp.tract.shape(vowel).expect("a shape of the speaker's");
        let mut tract = sp.tract.clone();
        tract.calculate(&params);
        let mut tube = Tube::new();
        tube.set_from_tract(&tract.tube());
        let mut tds = TdsModel::new();
        tds.options = options;
        tds.set_tube(&tube, false);
        let mut k = TubeCoefficients::default();
        tds.tube_coefficients(&mut k);
        let (mut model, _) = PassiveModel::for_speaker(&sp.tract, &sp.glottis, options);
        model.take_switches(&[format!("losses={losses}")]);
        model.set_rate(rate);
        model.set_glottis_sections(&lengths, &[MIN_AREA_CM2; 2]);
        model.set_pressure_source(0.0, 0);
        let (began, clock) = (Counts::now(), Instant::now());
        let network = model.network(&k);
        let (laying, laying_s) = (counted(&began), clock.elapsed().as_secs_f64());
        let (unknowns, band) = network.size();
        // the lips' transfer on the grid, continuous, its peaks the resonances' first guesses
        let grid: Vec<f64> = (0..).map(|i| 50.0 + 10.0 * i as f64).take_while(|&f| f <= 12000.0).collect();
        let (began, clock) = (Counts::now(), Instant::now());
        let size: Vec<f64> = grid.iter().map(|&f| network.response(Complex::tone(f), Stepping::Continuous).mouth.abs()).collect();
        let (responses, responses_s) = (counted(&began), clock.elapsed().as_secs_f64());
        let each = responses.map(|c| c as f64 / grid.len() as f64);
        println!(
            "/{vowel}/: {unknowns} unknowns, banded {} (stepped {}); the network laid in {}, a continuous response {} ({:.0} us)",
            band[0],
            band[1],
            laying.map_or(format!("{:.1} ms", 1e3 * laying_s), |c| format!("{c} instructions")),
            each.map_or(String::new(), |c| format!("{c:.0} instructions")),
            1e6 * responses_s / grid.len() as f64
        );
        println!("   continuous: f (Hz), bandwidth (Hz)   stepped: f, bandwidth   the step's error: cents, bandwidth's ratio");
        for i in 1..grid.len() - 1 {
            if !(size[i] > size[i - 1] && size[i] >= size[i + 1]) {
                continue;
            }
            let guess = Complex::resonance(grid[i], 60.0);
            let continuous = network.resonance(guess, Stepping::Continuous);
            let stepped = network.resonance(continuous.unwrap_or(guess), Stepping::Stepped);
            match (continuous, stepped) {
                (Some(c), Some(s)) => {
                    let ((fc, bc), (fs, bs)) = (c.frequency_and_bandwidth(), s.frequency_and_bandwidth());
                    println!("   {fc:10.2} {bc:9.2}                   {fs:10.2} {bs:9.2}       {:+8.4} {:9.6}", 1200.0 * (fs / fc).log2(), bs / bc);
                }
                _ => println!("   (a peak at {} Hz: its pole not settled)", grid[i]),
            }
        }
        // the same transfer stepped, as vocalfork_transfer steps it: a quarter of a second
        let n = (0.25 * rate) as usize;
        // (a stepped response's cost)
        let (began, clock) = (Counts::now(), Instant::now());
        for &f in grid.iter().take(200) {
            network.response(Complex::tone(f), Stepping::Stepped);
        }
        let (stepped_each, stepped_each_s) = (counted(&began).map(|c| c as f64 / 200.0), clock.elapsed().as_secs_f64() / 200.0);
        println!(
            "   a stepped response {} ({:.0} us)",
            stepped_each.map_or(String::new(), |c| format!("{c:.0} instructions")),
            1e6 * stepped_each_s
        );
        let (began, clock) = (Counts::now(), Instant::now());
        for s in 0..n {
            model.injected = if s == 0 { 1e-6 * rate } else { 0.0 };
            model.proceed_time_step_with(&k);
        }
        let (stepping, stepping_s) = (counted(&began), clock.elapsed().as_secs_f64());
        println!(
            "   a quarter second's transfer stepped: {} ({:.2} s), {:.0} continuous responses' worth",
            stepping.map_or(String::new(), |c| format!("{:.3e} instructions", c as f64)),
            stepping_s,
            match (stepping, each) {
                (Some(t), Some(r)) => t as f64 / r,
                _ => stepping_s / (responses_s / grid.len() as f64),
            }
        );
    }
}
