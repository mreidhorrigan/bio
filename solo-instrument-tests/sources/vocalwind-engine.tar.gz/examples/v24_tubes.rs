// Every shape's whole tube, as 2.4 lays it for its acoustics (Tube::set_from_tract), written as JSON for study outside
// the engine (research/VOCAL_TRACT_PASSIVE_CORE.md): each section's area, length and volume in the tube's order, with
// the places the nose, the piriform fossa and the sinuses join it. And what 2.4's tract knows of its walls and its
// acoustics drop: each pharynx and mouth section's circumference (`circumference`, in the tube's order, 0 elsewhere:
// the least within the section, as its area is), the cross-sections along the centre line they are cut from (`cross`:
// each its place, area and circumference), and each section's wall against its equal-area circle's as the tube now
// carries it for the passive core (`shape`: VocalTract::section_shapes, 1 elsewhere), for the walls' losses on a
// section's own circumference (research/VOCALWIND_BOUNDARY_LAYER.md).
//   cargo run --release --example v24_tubes -- <speaker.speaker> > tubes.json
use musebots_vocaltract::v24::speaker::Speaker;
use musebots_vocaltract::v24::tube::*;

fn main() {
    let path = std::env::args().nth(1).expect("a speaker file");
    let sp = Speaker::read(&path).expect("speaker");
    let mut tract = sp.tract.clone();
    let mut shapes = Vec::new();
    for (name, v) in sp.tract.shapes.iter() {
        tract.calculate(v);
        let mut tube = Tube::new();
        tube.set_from_tract(&tract.tube());
        let list = |f: &dyn Fn(&Section) -> f64| tube.section.iter().map(|s| format!("{:.6e}", f(s))).collect::<Vec<_>>().join(",");
        let circumference = (0..tube.section.len())
            .map(|i| if (FIRST_PHARYNX_SECTION..FIRST_PHARYNX_SECTION + NUM_PHARYNX_MOUTH_SECTIONS).contains(&i) { tract.tube_section[i - FIRST_PHARYNX_SECTION].circ } else { 0.0 })
            .map(|c| format!("{c:.6e}"))
            .collect::<Vec<_>>()
            .join(",");
        let cross = tract.cross_section.iter().map(|c| format!("[{:.6e},{:.6e},{:.6e}]", c.pos, c.area, c.circ)).collect::<Vec<_>>().join(",");
        shapes.push(format!(
            "{{\"name\":{:?},\"area\":[{}],\"length\":[{}],\"volume\":[{}],\"shape\":[{}],\"circumference\":[{}],\"cross\":[{}]}}",
            name,
            list(&|s| s.area_cm2),
            list(&|s| s.length_cm),
            list(&|s| s.volume_cm3),
            list(&|s| s.shape),
            circumference,
            cross
        ));
    }
    println!(
        "{{\"speaker\":{:?},\"first\":{{\"trachea\":{},\"glottis\":{},\"pharynx\":{},\"mouth\":{},\"nose\":{},\"fossa\":{},\"sinus\":{}}},\"count\":{{\"trachea\":{},\"pharynx\":{},\"mouth\":{},\"nose\":{},\"fossa\":{},\"sinus\":{}}},\"fossa_at\":{},\"sinus_at\":{:?},\"shapes\":[{}]}}",
        path.rsplit('/').next().unwrap(),
        FIRST_TRACHEA_SECTION, FIRST_GLOTTIS_SECTION, FIRST_PHARYNX_SECTION, FIRST_MOUTH_SECTION, FIRST_NOSE_SECTION, FIRST_FOSSA_SECTION, FIRST_SINUS_SECTION,
        NUM_TRACHEA_SECTIONS, NUM_PHARYNX_SECTIONS, NUM_MOUTH_SECTIONS, NUM_NOSE_SECTIONS, NUM_FOSSA_SECTIONS, NUM_SINUS_SECTIONS,
        FIRST_PHARYNX_SECTION + FOSSA_COUPLING_SECTION,
        SINUS_COUPLING_SECTION.iter().map(|k| FIRST_NOSE_SECTION + k).collect::<Vec<_>>(),
        shapes.join(",")
    );
}
