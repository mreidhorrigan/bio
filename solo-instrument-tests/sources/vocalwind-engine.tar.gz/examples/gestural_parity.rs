// The parity check's port side for the gestural score: a .ges file (or the score reference/gestural_parity.c made from a
// .seg) read, made into frames by the port's gestural score and synthesized as vtlGesturalScoreToAudio does (a reset,
// the first frame only set, then 110 samples a frame), the audio compared with VocalTractLab's sample for sample.
//   cargo run --release --example gestural_parity -- JD3.speaker score.ges audio.f64
//   cargo run --release --example gestural_parity -- JD3.speaker phones.seg audio.f64 made.ges
// Given a .seg, the port makes its own score (src/segments.rs) and compares it, as text, with the one VocalTractLab made
// and saved; then synthesizes its own, saved as VocalTractLab saves it (six decimals), as VocalTractLab synthesizes it.
use musebots_vocaltract::gestural::{self, GesturalScore};
use musebots_vocaltract::segments;
use std::time::Instant;
use musebots_vocaltract::speaker::Speaker;
use musebots_vocaltract::synth::Synthesizer;
use musebots_vocaltract::tds::TdsModel;
use musebots_vocaltract::tract::VocalTract;

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let speaker = Speaker::read(&args[0]).expect("speaker");
    let mut tract = VocalTract::from_xml(speaker.root.child("vocal_tract_model").expect("vocal tract")).expect("anatomy");
    let text = if args[1].ends_with(".seg") {
        let segs = segments::parse_segments(&std::fs::read_to_string(&args[1]).expect("segments"));
        let mut score = GesturalScore::new();
        // (VocalTractLab's new score carries its test score's F0 -- 80, 83, 78 semitones re 1 Hz -- which its segment
        // rules keep; the port's starts with none. Given here only to compare.)
        for (d, st) in [(0.01, 80.0), (0.3, 83.0), (0.3, 78.0)] {
            score.seq[gestural::F0].gestures.push(gestural::Gesture { duration_s: d, d_val: st, slope: 0.0, s_val: String::new(), tau_s: 0.030, neutral: false });
        }
        let t0 = Instant::now();
        score.from_segments(&segs, &mut tract);
        let made = score.to_xml();
        let theirs = std::fs::read_to_string(&args[3]).expect("VocalTractLab's score");
        let lines = made.lines().zip(theirs.lines()).filter(|(a, b)| a != b).count();
        println!("gestural_parity: {} segments into a score in {:.2} s; its text {} ({} lines differ of {})", segs.len(), t0.elapsed().as_secs_f64(), if made == theirs { "identical to VocalTractLab's" } else { "differs" }, lines, theirs.lines().count());
        if made != theirs {
            for (a, b) in made.lines().zip(theirs.lines()).filter(|(a, b)| a != b).take(6) {
                println!("  port: {a}\n  VTL:  {b}");
            }
        }
        made
    } else {
        std::fs::read_to_string(&args[1]).expect("score")
    };
    let (score, in_range) = GesturalScore::parse(&text).expect("a gestural score");
    assert!(in_range, "values out of range: VocalTractLab refuses this score");
    let reference: Vec<f64> = std::fs::read(&args[2]).expect("audio").chunks_exact(8).map(|b| f64::from_le_bytes(b.try_into().unwrap())).collect();
    let neutral: Vec<f64> = speaker.glottis.control.iter().map(|p| p.neutral).collect();
    let frames = score.frames(&tract, &speaker.glottis.shapes, &neutral);
    let mut synth = Synthesizer::new(speaker.glottis, TdsModel::new());
    synth.reset();
    let mut out = Vec::with_capacity(reference.len());
    let mut buffer = vec![0.0; 110];
    for (f, (tp, gp)) in frames.iter().enumerate() {
        let n = if f == 0 { 0 } else { 110 };
        synth.add_tract(&mut tract, tp, gp, &mut buffer[..n]);
        out.extend_from_slice(&buffer[..n]);
    }
    let n = out.len().min(reference.len());
    let identical = (0..n).filter(|&i| out[i].to_bits() == reference[i].to_bits()).count();
    let first = (0..n).find(|&i| out[i].to_bits() != reference[i].to_bits());
    let largest = (0..n).map(|i| (out[i] - reference[i]).abs()).fold(0.0, f64::max);
    println!(
        "gestural_parity: {} samples (reference {}), {identical} identical, first difference {}, largest {largest:.3e}",
        out.len(),
        reference.len(),
        first.map(|i| i.to_string()).unwrap_or("none".into())
    );
}
