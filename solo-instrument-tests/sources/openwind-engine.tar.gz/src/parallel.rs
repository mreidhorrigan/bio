//! A body stepped on several cores (research/OPENWIND_REALTIME_PLAN.md; claude-scratch/openwind-multicore/PROGRESS.md):
//! for a woodwind one core steps slower than it sounds -- the live dial's English horn, bassoon, saxophones (the owner,
//! 31 October 2026: the dial stuttering for them). Its lossy pipes share nothing within a step -- each pipe's nodes its
//! own, its elements joined only by the pressure nodes they share -- and meet only through their connectors, at their
//! ends. So the bore is split by whole pipes, in memory order, into parts of about equal cost, each laid out on its own
//! as Mirror lays out the whole (its state and coefficients, doubles or singles as the body is stepped, padded to whole
//! blocks with zeros, which stay so), and each stepped on a thread of its own with the connectors whose ends are all its
//! own. The main thread sets the others going, steps the connectors that join two parts (and the reed with its player's
//! tract, a flute's jet) while they step their own connectors, says so, steps its own part, waits for them, and takes
//! from them what it reads: the no-flow pressures at its connectors' ends, and the records its outputs sum. A worker's
//! nodes wait for its connectors' flows set by the main thread (`flows`), never longer: so the main thread's connectors,
//! which had stood alone at the head of every step, now lie under the workers' own. Every value is the one thread's, bit for bit: each node's
//! arithmetic is unchanged, each pressure node's sum keeps its order (the two elements that share a node are one pipe's,
//! so in one part, in their groups' order), and each connector reads and writes only its own ends and block.
//!
//! A worker steps its connectors in a copy of `d` of its own, not in `d`: its connectors' blocks and flows lie between
//! other parts' in `d`, and two threads writing one cache line every step would pass it from core to core (some 16-21
//! lines a step at four parts, claude-scratch/openwind-multicore/inspect-lines.mjs). What the main thread reads of it
//! comes through a line of its own. Each worker spins on the main thread's count of steps while it plays, and sleeps
//! once it has waited past IDLE -- between the stream's calls -- woken by the next step.
//!
//! A part is taken for each step by whichever thread comes to it first: its worker, or the main thread once its own part
//! is done. So a worker late to a step -- without a core of its own while others' work fills the machine, or woken late
//! -- does not hold the step back: the main thread steps its part for it, and only a part begun is waited for. Whoever
//! steps it, a part is stepped in the same arrays and the same copy of `d`, in the same order.

use super::{at, bore_step, connect, lossless_pipe, region_length, shape_of, Bore, Conn, Decoded, End, Group, Real, BLOCK, BORE_COEFFICIENTS,
            BORE_STATE, B_H, B_N, B_PI, B_PIP0, B_PNF, B_PPI, B_T, B_V, B_VI, B_VIV, B_VV, B_VVI, B_XV, FIELDS, NONE, PIPE_REC, T_DISCONTINUITY,
            T_CROSS, T_RADIATION, T_SIMPLE, T_SWITCH, T_TJOINT};
use crate::tract::Tract;
use std::cell::UnsafeCell;
use std::sync::atomic::{AtomicBool, AtomicPtr, AtomicU64, Ordering};
use std::sync::Arc;
use std::thread::JoinHandle;
use std::time::{Duration, Instant};

/// How long a worker spins for the next step before it sleeps: past the stream's own work between its calls (a block's
/// controls and flows, some 100-200 us), well short of the dial's between its blocks (some 10 ms).
const IDLE: Duration = Duration::from_micros(250);

/// A connector's cost a step, in the bore's units (a node through one loss variable): a few of its nodes' -- what its
/// part is charged for it, so that the parts' times come out about equal (the English horn's 211 connectors some third
/// of its step).
const CONNECTOR_COST: usize = 40;

/// What lies in a cache line of its own (Apple silicon's are 128 bytes), so that what one thread writes is never in the
/// line another reads for something else.
#[repr(align(128))]
struct Line<X>(X);

/// The main thread's: its count of steps, the count of the last whose connectors joining two parts it has stepped (their
/// flows set in `d`), the row of controls of the step it counts, its `d`, and whether the workers are let go.
struct Beat {
    epoch: AtomicU64,
    flows: AtomicU64,
    row: AtomicPtr<f64>,
    d: AtomicPtr<f64>,
    stop: AtomicBool,
}

/// A worker's: the last step its part was taken for (by it or the main thread) and the last its worker has done, and
/// whether its worker sleeps.
struct Hand {
    taken: AtomicU64,
    done: AtomicU64,
    asleep: AtomicBool,
}

struct Shared {
    beat: Line<Beat>,
    hands: Vec<Line<Hand>>,
}

/// A worker's part with what it is stepped in: its view, a copy of `d` of its own for its connectors, and its exports
/// (what the main thread reads of it: its `places` in that copy, put in `out` as each step ends).
struct Seat<T> {
    part: Part<T>,
    view: Bore<T>,
    dq: Vec<f64>,
    places: Vec<usize>,
    out: Vec<Line<[f64; 16]>>,
}

impl<T: Real> Seat<T> {
    /// A step of its part, by whichever thread has taken it (Part::step), and its exports.
    ///
    /// # Safety
    /// As Part::step; taken for this step by the thread stepping it alone.
    #[inline(always)]
    unsafe fn step(&mut self, ends: &[End], d: *const f64, row: *const f64, flows: Option<(&AtomicU64, u64)>) {
        let dq = self.dq.as_mut_ptr();
        self.part.step(&self.view, ends, dq, d, row, flows);
        let out = self.out.as_mut_ptr() as *mut f64;
        for (k, &place) in self.places.iter().enumerate() {
            *out.add(k) = *dq.add(place);
        }
    }
}

/// A seat where its worker steps it, handed to its thread.
struct SeatAt<T>(*mut Seat<T>);

/// A worker's step of its seat (Seat::step), a function of its own in a page's WebAssembly (wait's).
///
/// # Safety
/// As Seat::step.
#[cfg_attr(target_arch = "wasm32", inline(never))]
unsafe fn stepped<T: Real>(seat: &SeatAt<T>, ends: &[End], d: *const f64, row: *const f64, flows: Option<(&AtomicU64, u64)>) {
    (*seat.at()).step(ends, d, row, flows)
}

// (Stepped only by the thread that has taken it for the step, its Hand's counts ordering one step's taker before the
// next's; kept by the crew until its threads are joined.)
unsafe impl<T> Send for SeatAt<T> {}

impl<T> SeatAt<T> {
    fn at(&self) -> *mut Seat<T> {
        self.0
    }
}

/// A part of the bore, laid out on its own: its state and coefficients (`data`, each region at `fields`, then its groups'
/// matrices), its no-flow pressures, its groups' elements' first nodes (`index`, renumbered as its own), its groups
/// (theirs, less those with none of its elements), each with the bore's group it is of and its elements' places there
/// (`origin`); its ends (its node, the end, and whether its flow is set by the main thread's connectors, in `d`); and the
/// connectors it steps.
struct Part<T> {
    h: usize,
    l: usize,
    n: usize,
    data: Vec<T>,
    fields: [usize; FIELDS],
    pnf: Vec<f64>,
    index: Vec<i64>,
    groups: Vec<Group>,
    origin: Vec<(usize, Vec<usize>)>,
    ends: Vec<(usize, usize, bool)>,
    conns: Vec<Conn>,
}

/// Its loss variables' place in a region of them, node `x`'s `q`th of `n` ([block][variable][lane]: openwind_compiled.py
/// _blocked).
#[inline(always)]
fn blocked(x: usize, q: usize, n: usize) -> usize {
    (x - x % BLOCK) * n + q * BLOCK + x % BLOCK
}

impl<T: Real> Part<T> {
    /// The part of the bore (the record at `b` in `i`, `d` its values) of the pressure and velocity nodes given (each
    /// ascending), each group's elements of it given by their place in the group.
    fn of(i: &[i64], d: &[f64], b: usize, groups: &[Group], pressures: &[usize], velocities: &[usize], elements: &[Vec<usize>]) -> Part<T> {
        let n = at(i[b + B_N]);
        let (h, l) = (pressures.len().div_ceil(BLOCK) * BLOCK, velocities.len().div_ceil(BLOCK) * BLOCK);
        let (mut fields, mut next) = ([0; FIELDS], 0);
        for &f in BORE_STATE.iter().chain(&BORE_COEFFICIENTS) {
            fields[f] = next;
            next += region_length(f, h, l, n);
        }
        let matrices: usize = groups.iter().zip(elements).map(|(g, e)| 2 * e.len() * g.w * g.w).sum();
        let mut data = vec![T::default(); next + matrices];
        for &f in BORE_STATE.iter().chain(&BORE_COEFFICIENTS) {
            let (from, to) = (at(i[b + f]), fields[f]);
            let nodes = if matches!(f, B_V | B_T | B_VV | B_XV | B_VI | B_VIV | B_VVI) { velocities } else { pressures };
            let losses = matches!(f, B_PI | B_PIP0 | B_PPI | B_VI | B_VIV | B_VVI);
            for (j, &x) in nodes.iter().enumerate() {
                if losses {
                    for q in 0..n {
                        data[to + blocked(j, q, n)] = T::of(d[from + blocked(x, q, n)]);
                    }
                } else {
                    data[to + j] = T::of(d[from + x]);
                }
            }
        }
        let mut pnf = vec![0.0; h];
        for (j, &x) in pressures.iter().enumerate() {
            pnf[j] = d[at(i[b + B_PNF]) + x];
        }
        // (Each node's place here, by its place in the bore: its elements' nodes, consecutive there, consecutive here.)
        let local = |nodes: &[usize], x: usize| nodes.binary_search(&x).unwrap_or_else(|_| unreachable!()) as i64;
        let (mut index, mut own_groups, mut origin) = (Vec::new(), Vec::new(), Vec::new());
        for (j, (g, mine)) in groups.iter().zip(elements).enumerate() {
            if mine.is_empty() {
                continue;
            }
            origin.push((j, mine.clone()));
            let (w, count) = (g.w, mine.len());
            let (hs, ls, a) = (index.len(), index.len() + count, next);
            index.extend(mine.iter().map(|&e| local(pressures, at(i[g.hs + e]))));
            index.extend(mine.iter().map(|&e| local(velocities, at(i[g.ls + e]))));
            for (k, &e) in mine.iter().enumerate() {
                for c in 0..w * w {
                    data[a + k * w * w + c] = T::of(d[g.a + e * w * w + c]);
                    data[a + (count + k) * w * w + c] = T::of(d[g.b + e * w * w + c]);
                }
            }
            own_groups.push(Group { w, count, hs, ls, a, b: a + count * w * w });
            next += 2 * count * w * w;
        }
        Part { h, l, n, data, fields, pnf, index, groups: own_groups, origin, ends: Vec::new(), conns: Vec::new() }
    }

    /// Its arrays where bore_step reads them.
    ///
    /// # Safety
    /// Kept no longer than the part, whose arrays are not resized meanwhile.
    unsafe fn view(&mut self) -> Bore<T> {
        let base = self.data.as_mut_ptr();
        let mut at_field = [std::ptr::null_mut(); FIELDS];
        for &f in BORE_STATE.iter().chain(&BORE_COEFFICIENTS) {
            at_field[f] = base.add(self.fields[f]);
        }
        Bore { h: self.h, l: self.l, n: self.n, at: at_field, pnf: self.pnf.as_mut_ptr(),
               a: self.groups.iter().map(|g| base.add(g.a) as *const T).collect(), b: self.groups.iter().map(|g| base.add(g.b) as *const T).collect() }
    }

    /// A step of its own: its connectors in `dq` (`d` itself on the main thread, a worker's own copy of it), its ends'
    /// pressures at the half step from their flows (in `d` where the main thread's connectors set them: once `flows`
    /// counts the step, where it is given), its nodes, and its ends' no-flow pressures put where its connectors read them
    /// at the next.
    ///
    /// # Safety
    /// `view` is its own; `dq` and `d` address the body's doubles, its connectors' places in `dq` no other thread's, and
    /// `row` the step's controls.
    #[inline(always)]
    unsafe fn step(&mut self, view: &Bore<T>, ends: &[End], dq: *mut f64, d: *const f64, row: *const f64, flows: Option<(&AtomicU64, u64)>) {
        for conn in self.conns.iter_mut() {
            connect(conn, ends, dq, row, None, 0);
        }
        if let Some((set, step)) = flows {
            while set.load(Ordering::Acquire) < step {
                std::hint::spin_loop();
            }
        }
        for &(node, k, theirs) in &self.ends {
            let e = ends.get_unchecked(k);
            *view.pnf.add(node) -= *dq.add(e.alpha) * *(if theirs { d } else { dq as *const f64 }).add(e.w);
        }
        bore_step(&self.index, view, &self.groups);
        for &(node, k, _) in &self.ends {
            *dq.add(ends.get_unchecked(k).pnf) = *view.pnf.add(node);
        }
    }
}

/// The bore's pipes: its elements joined by the pressure nodes they share, in memory order (by their first node), each
/// its pressure and velocity nodes, ascending, and its cost a step (each node through its loss variables, each element's
/// two matrices). -> them, and each group's elements' pipes.
#[allow(clippy::type_complexity)]
fn pipes_of(i: &[i64], groups: &[Group], h: usize, n: usize) -> (Vec<(Vec<usize>, Vec<usize>, usize)>, Vec<Vec<usize>>) {
    let mut parent: Vec<usize> = (0..h).collect();
    fn root(parent: &mut [usize], mut x: usize) -> usize {
        while parent[x] != x {
            parent[x] = parent[parent[x]];
            x = parent[x];
        }
        x
    }
    let mut covered = vec![false; h];
    for g in groups {
        for e in 0..g.count {
            let first = at(i[g.hs + e]);
            covered[first..first + g.w].fill(true);
            for c in 1..g.w {
                let (a, b) = (root(&mut parent, first), root(&mut parent, first + c));
                parent[b] = a;
            }
        }
    }
    let (mut pipe_of_root, mut pipes) = (vec![NONE; h], Vec::new());
    for x in 0..h {
        if covered[x] {
            let r = root(&mut parent, x);
            if pipe_of_root[r] == NONE {
                pipe_of_root[r] = pipes.len();
                pipes.push((Vec::new(), Vec::new(), 0));
            }
            let pipe = &mut pipes[pipe_of_root[r]];
            pipe.0.push(x);
            pipe.2 += 1 + n;
        }
    }
    let mut element_pipes = Vec::with_capacity(groups.len());
    for g in groups {
        element_pipes.push((0..g.count).map(|e| {
            let p = pipe_of_root[root(&mut parent, at(i[g.hs + e]))];
            let first = at(i[g.ls + e]);
            pipes[p].1.extend(first..first + g.w);
            pipes[p].2 += (1 + n) * g.w + 2 * g.w * g.w;
            p
        }).collect());
    }
    for pipe in pipes.iter_mut() {
        pipe.1.sort_unstable();
        pipe.1.dedup();
    }
    (pipes, element_pipes)
}

/// A worker's wait for the main thread's next step: spun, then slept once it has waited past IDLE (woken by the step
/// that ends it). -> that step's count.
// (Its own function, as its step is (stepped), in a page's WebAssembly: a browser optimizes a function's code only for
// its next call, and a worker's loop is never called again, so that what it calls each step is what is optimized.)
#[cfg_attr(target_arch = "wasm32", inline(never))]
fn wait(beat: &Beat, hand: &Hand, seen: u64) -> u64 {
    let (mut spins, mut since) = (0u32, None::<Instant>);
    loop {
        let now = beat.epoch.load(Ordering::Acquire);
        if now != seen {
            return now;
        }
        spins = spins.wrapping_add(1);
        if spins % 256 == 0 && since.get_or_insert_with(Instant::now).elapsed() > IDLE {
            // (Said asleep before the count is read again, as the main thread counts before it reads who sleeps: the
            // one sees the other.)
            hand.asleep.store(true, Ordering::SeqCst);
            if beat.epoch.load(Ordering::SeqCst) == seen {
                std::thread::park();
            }
            hand.asleep.store(false, Ordering::SeqCst);
            since = None;
        }
        std::hint::spin_loop();
    }
}

/// A worker thread's own priority: the user's interactive work, as an audio thread's (macOS's QoS classes), so that it
/// keeps to the performance cores.
pub(super) fn interactive() {
    #[cfg(target_os = "macos")]
    {
        extern "C" {
            fn pthread_set_qos_class_self_np(class: u32, relative_priority: i32) -> i32;
        }
        // (QOS_CLASS_USER_INTERACTIVE, <sys/qos.h>.)
        unsafe {
            pthread_set_qos_class_self_np(0x21, 0);
        }
    }
}

/// A player's bore on several threads: its own part (the first in memory order) and its view, the threads stepping the
/// rest, and what the main thread reads of them.
pub(super) struct Crew<T: Real> {
    shared: Arc<Shared>,
    workers: Vec<JoinHandle<()>>,
    own: Part<T>,
    view: Bore<T>,
    // (The connectors no part steps, by their place among the body's -- those joining two parts, a reed, a flute's jet
    // -- stepped before the parts.)
    first: Vec<usize>,
    // (Each worker's seat, the main thread's to step where it takes it, and where it reads its exports.)
    seats: Box<[Line<UnsafeCell<Seat<T>>>]>,
    export_at: Vec<*const f64>,
    // (Each no-flow pressure the main thread's connectors read of a worker's: its place in `d`, the worker, its slot.)
    taken: Vec<(usize, usize, usize)>,
    // (Each output's terms: in `d` (0) or a worker's exports (1 + it), at a place or a slot.)
    terms: Vec<Vec<(usize, usize)>>,
    epoch: u64,
}

impl<T: Real + Send + 'static> Crew<T> {
    /// The bore of the body `i`, `d` (as `body` decoded it) split into at most `parts` parts, one a thread. -> None
    /// where it has no bore, too few pipes to split, an end found in no pipe, or no thread to be had.
    fn of(i: &[i64], d: &[f64], body: &Decoded, parts: usize) -> Option<Crew<T>> {
        let b = body.bore?;
        let (h, n) = (at(i[b + B_H]), at(i[b + B_N]));
        let (ends, groups) = (&body.ends, &body.groups);
        let (pipes, element_pipes) = pipes_of(i, groups, h, n);
        let mut pipe_of_node = vec![NONE; h];
        for (p, pipe) in pipes.iter().enumerate() {
            for &x in &pipe.0 {
                pipe_of_node[x] = p;
            }
        }
        // (Each bore end's pipe; each connector charged to its first end's.)
        let pnf_at = at(i[b + B_PNF]);
        let mut pipe_of_end = vec![NONE; ends.len()];
        for &k in &body.bore_ends {
            let node = ends[k].pnf.checked_sub(pnf_at).filter(|&x| x < h)?;
            pipe_of_end[k] = Some(pipe_of_node[node]).filter(|&p| p != NONE)?;
        }
        let mut costs: Vec<usize> = pipes.iter().map(|p| p.2).collect();
        for conn in &body.conns {
            if let Some(&p) = pipe_of_end.get(conn.e[0]).filter(|&&p| p != NONE) {
                costs[p] += CONNECTOR_COST;
            }
        }
        // The parts: the pipes in memory order, each part's share of the cost about the same.
        let total: usize = costs.iter().sum();
        let mut acc = 0;
        let mut part_of_pipe: Vec<usize> = costs.iter().map(|&c| {
            let k = ((2 * acc + c) * parts / (2 * total.max(1))).min(parts.max(1) - 1);
            acc += c;
            k
        }).collect();
        // (Renumbered where a part has no pipe: a long pipe, or fewer pipes than parts.)
        let mut used: Vec<usize> = part_of_pipe.clone();
        used.dedup();
        for k in part_of_pipe.iter_mut() {
            *k = used.binary_search(k).unwrap_or_else(|_| unreachable!());
        }
        let parts = used.len();
        if parts < 2 {
            return None;
        }
        let part_of_end: Vec<usize> = pipe_of_end.iter().map(|&p| if p == NONE { NONE } else { part_of_pipe[p] }).collect();
        // Each connector's part: the one all its ends are in, where it is a junction's or a radiation's and its ends
        // are the bore's alone; else none, the main thread's.
        let owner: Vec<usize> = body.conns.iter().map(|conn| {
            let joined = shape_of(conn.kind).map_or(0, |s| s.1);
            let mut of = conn.e[..joined].iter().map(|&k| if ends[k].half == NONE { part_of_end[k] } else { NONE });
            let first = of.next().unwrap_or(NONE);
            let junction = matches!(conn.kind, T_SIMPLE | T_TJOINT | T_CROSS | T_DISCONTINUITY | T_RADIATION | T_SWITCH);
            if junction && first != NONE && of.all(|p| p == first) { first } else { NONE }
        }).collect();
        let mut conn_of_end = vec![NONE; ends.len()];
        for (c, conn) in body.conns.iter().enumerate() {
            for &k in &conn.e[..shape_of(conn.kind).map_or(0, |s| s.1)] {
                conn_of_end[k] = c;
            }
        }
        // The parts laid out: their nodes, their elements, their ends, their connectors.
        let mut laid: Vec<Part<T>> = (0..parts).map(|p| {
            let mine = |x: &usize| part_of_pipe[*x] == p;
            let mut pressures: Vec<usize> = (0..pipes.len()).filter(mine).flat_map(|x| pipes[x].0.iter().copied()).collect();
            let mut velocities: Vec<usize> = (0..pipes.len()).filter(mine).flat_map(|x| pipes[x].1.iter().copied()).collect();
            pressures.sort_unstable();
            velocities.sort_unstable();
            let elements: Vec<Vec<usize>> = element_pipes.iter().map(|g| (0..g.len()).filter(|&e| part_of_pipe[g[e]] == p).collect()).collect();
            let mut part = Part::of(i, d, b, groups, &pressures, &velocities, &elements);
            part.ends = body.bore_ends.iter().filter(|&&k| part_of_end[k] == p).map(|&k| {
                let node = pressures.binary_search(&(ends[k].pnf - pnf_at)).unwrap_or_else(|_| unreachable!());
                (node, k, conn_of_end[k] == NONE || owner[conn_of_end[k]] != p)
            }).collect();
            part.conns = body.conns.iter().zip(&owner).filter(|(_, &o)| o == p).map(|(c, _)| *c).collect();
            part
        }).collect();
        // What the main thread reads of each worker: the no-flow pressures at its own connectors' ends, and the records
        // of the worker's connectors its outputs sum.
        let mut places: Vec<Vec<usize>> = vec![Vec::new(); parts - 1];
        let mut taken = Vec::new();
        for &k in &body.bore_ends {
            let p = part_of_end[k];
            if p > 0 && (conn_of_end[k] == NONE || owner[conn_of_end[k]] != p) {
                taken.push((ends[k].pnf, p - 1, places[p - 1].len()));
                places[p - 1].push(ends[k].pnf);
            }
        }
        let terms = body.outs.iter().map(|(_, terms)| terms.iter().map(|&t| {
            let recorder = body.conns.iter().position(|c| c.rec != NONE && (t == c.rec || t == c.rec + 1));
            match recorder.map(|c| owner[c]) {
                Some(p) if p != NONE && p > 0 => {
                    let slot = places[p - 1].iter().position(|&x| x == t).unwrap_or_else(|| {
                        places[p - 1].push(t);
                        places[p - 1].len() - 1
                    });
                    (p, slot)
                }
                _ => (0, t),
            }
        }).collect()).collect();
        let seats: Box<[Line<UnsafeCell<Seat<T>>>]> = laid.split_off(1).into_iter().zip(places).map(|(mut part, places)| {
            let view = unsafe { part.view() };
            let out = (0..places.len().div_ceil(16).max(1)).map(|_| Line([0.0; 16])).collect();
            Line(UnsafeCell::new(Seat { part, view, dq: d.to_vec(), places, out }))
        }).collect();
        let export_at = seats.iter().map(|s| unsafe { (*s.0.get()).out.as_ptr() as *const f64 }).collect();
        let shared = Arc::new(Shared {
            beat: Line(Beat { epoch: AtomicU64::new(0), flows: AtomicU64::new(0), row: AtomicPtr::new(std::ptr::null_mut()), d: AtomicPtr::new(std::ptr::null_mut()), stop: AtomicBool::new(false) }),
            hands: (1..parts).map(|_| Line(Hand { taken: AtomicU64::new(0), done: AtomicU64::new(0), asleep: AtomicBool::new(false) })).collect(),
        });
        let mut own = laid.pop()?;
        let view = unsafe { own.view() };
        let mut crew = Crew { shared, workers: Vec::new(), own, view, first: (0..body.conns.len()).filter(|&c| owner[c] == NONE).collect(), seats,
                              export_at, taken, terms, epoch: 0 };
        for w in 0..parts - 1 {
            let (shared, ends, seat) = (crew.shared.clone(), ends.clone(), SeatAt(crew.seats[w].0.get()));
            let worker = std::thread::Builder::new().name(format!("openwind part {}", w + 1)).spawn(move || {
                interactive();
                let (beat, hand) = (&shared.beat.0, &shared.hands[w].0);
                let mut seen = 0;
                loop {
                    seen = wait(beat, hand, seen);
                    if beat.stop.load(Ordering::Acquire) {
                        break;
                    }
                    // (Its part taken for the step, unless the main thread took it first, finding it not begun.)
                    if hand.taken.fetch_max(seen, Ordering::AcqRel) < seen {
                        let (d, row) = (beat.d.load(Ordering::Relaxed), beat.row.load(Ordering::Relaxed));
                        unsafe { stepped(&seat, &ends, d, row, Some((&beat.flows, seen))) };
                        hand.done.store(seen, Ordering::Release);
                    }
                }
            });
            // (No thread to be had: those begun let go as the crew is dropped, and the body stepped on one.)
            crew.workers.push(worker.ok()?);
        }
        Some(crew)
    }

    /// `steps` steps (Player::steps) on the body `i`, `d` as `body` decoded it, its player's tract `tract`.
    ///
    /// # Safety
    /// As Decoded::run; `d` the doubles this crew was made from, unchanged in their layout since.
    #[allow(clippy::too_many_arguments)]
    unsafe fn run(&mut self, i: &[i64], d: &mut [f64], body: &mut Decoded, mut tract: Option<&mut Tract>, u: &[f64], y: &mut [f64],
                  steps: usize) -> i64 {
        let (dp, nd, up) = (d.as_mut_ptr(), d.len(), u.as_ptr());
        let (cols, nouts, ends) = (body.cols, body.nouts, body.ends.as_slice());
        let beat = &self.shared.beat.0;
        // (Its `d` for the workers' reads, published with the first step's count.)
        beat.d.store(dp, Ordering::Relaxed);
        for s in 0..steps {
            let row = up.add(s * cols);
            // The workers set going, each woken where it sleeps, their own connectors stepped while the main thread steps
            // those joining two parts; its own part then; then each worker waited for.
            self.epoch += 1;
            beat.row.store(row as *mut f64, Ordering::Relaxed);
            beat.epoch.store(self.epoch, Ordering::SeqCst);
            for (hand, worker) in self.shared.hands.iter().zip(&self.workers) {
                if hand.0.asleep.load(Ordering::SeqCst) {
                    worker.thread().unpark();
                }
            }
            let mut status = 0;
            for &c in &self.first {
                status = connect(body.conns.get_unchecked_mut(c), ends, dp, row, tract.as_deref_mut(), s);
                if status != 0 {
                    break;
                }
            }
            beat.flows.store(self.epoch, Ordering::Release);
            // (Stopped: no part stepped further, each not begun taken so that none is, each begun waited for -- no worker
            // still stepping once this returns.)
            if status != 0 {
                for hand in self.shared.hands.iter() {
                    if hand.0.taken.fetch_max(self.epoch, Ordering::AcqRel) >= self.epoch {
                        while hand.0.done.load(Ordering::Acquire) < self.epoch {
                            std::hint::spin_loop();
                        }
                    }
                }
                return status;
            }
            self.own.step(&self.view, ends, dp, dp, row, None);
            // Each worker's part no thread has begun stepped here, then each begun waited for.
            let mut stepped = 0u64;
            for (w, hand) in self.shared.hands.iter().enumerate() {
                let taken = &hand.0.taken;
                if taken.load(Ordering::Relaxed) < self.epoch && taken.fetch_max(self.epoch, Ordering::AcqRel) < self.epoch {
                    (*self.seats.get_unchecked(w).0.get()).step(ends, dp, row, None);
                    stepped |= 1 << w;
                }
            }
            // (Every worker's count read in each pass, so that their lines come in together, not one after another.)
            let (mut waiting, mut spins) = (!stepped & ((1 << self.workers.len()) - 1), 0u32);
            while waiting != 0 {
                for (w, hand) in self.shared.hands.iter().enumerate() {
                    if waiting & (1 << w) != 0 && hand.0.done.load(Ordering::Acquire) == self.epoch {
                        waiting &= !(1 << w);
                    }
                }
                spins = spins.wrapping_add(1);
                if spins % (1 << 16) == 0 {
                    std::thread::yield_now();
                }
                std::hint::spin_loop();
            }
            for &(place, w, slot) in &self.taken {
                *dp.add(place) = *self.export_at.get_unchecked(w).add(slot);
            }
            for j in 0..body.npipes {
                lossless_pipe(i, std::slice::from_raw_parts_mut(dp, nd), body.pipes + j * PIPE_REC);
            }
            // What it records: each output a sum of recorded values, in its order, each from where it was written.
            for (j, terms) in self.terms.iter().enumerate() {
                let value = |&(from, at): &(usize, usize)| if from == 0 { *dp.add(at) } else { *self.export_at.get_unchecked(from - 1).add(at) };
                let mut sum = value(terms.get_unchecked(0));
                for t in terms.get_unchecked(1..) {
                    sum += value(t);
                }
                *y.get_unchecked_mut(s * nouts + j) = sum;
            }
        }
        0
    }
}

impl<T: Real> Crew<T> {
    /// Where element `e` of the bore's group `g` lies among the parts: the part (0 the main thread's own, 1 + w worker
    /// w's) and where its two blocks begin in that part's data. -> None where no part has it.
    fn element_at(&self, g: usize, e: usize) -> Option<(usize, usize, usize)> {
        let find = |part: &Part<T>| {
            let j = part.origin.iter().position(|(of, _)| *of == g)?;
            let k = part.origin[j].1.binary_search(&e).ok()?;
            let (group, size) = (&part.groups[j], part.groups[j].w * part.groups[j].w);
            Some((group.a + k * size, group.b + k * size))
        };
        if let Some((a, b)) = find(&self.own) {
            return Some((0, a, b));
        }
        // (Read while no worker steps: between Crew::run's calls.)
        self.seats.iter().enumerate().find_map(|(w, seat)| find(unsafe { &(*seat.0.get()).part }).map(|(a, b)| (1 + w, a, b)))
    }

    /// `values` put in a part's data from `at` (as element_at places a block), each as its bore is stepped.
    ///
    /// # Safety
    /// Between Crew::run's calls, no worker stepping; `at` and its values within that part's data.
    unsafe fn put(&mut self, part: usize, at: usize, values: &[f64]) {
        let data = if part == 0 { &mut self.own.data } else { &mut (*self.seats[part - 1].0.get()).part.data };
        for (x, &v) in data[at..at + values.len()].iter_mut().zip(values) {
            *x = T::of(v);
        }
    }

    /// `value` put at `at` in every worker's copy of `d`, where its connectors and its parts' ends read it.
    ///
    /// # Safety
    /// As put; `at` within `d`.
    unsafe fn put_d(&mut self, at: usize, value: f64) {
        for seat in self.seats.iter() {
            (&mut (*seat.0.get()).dq)[at] = value;
        }
    }
}

impl<T: Real> Drop for Crew<T> {
    fn drop(&mut self) {
        let beat = &self.shared.beat.0;
        beat.stop.store(true, Ordering::SeqCst);
        beat.epoch.store(self.epoch + 1, Ordering::SeqCst);
        for worker in &self.workers {
            worker.thread().unpark();
        }
        for worker in self.workers.drain(..) {
            let _ = worker.join();
        }
    }
}

/// A player's crew, its bore in doubles or singles as the body is stepped.
pub(super) enum Crews {
    Double(Crew<f64>),
    Single(Crew<f32>),
}

impl Crews {
    /// The body `i`, `d` (as `body` decoded it) on `threads` threads where its bore splits so, else on as many as it
    /// splits into; None where it does not split.
    pub(super) fn of(i: &[i64], d: &[f64], body: &Decoded, single: bool, threads: usize) -> Option<Crews> {
        // (At most 64, the main thread's and 63 workers', which a step's masks of its workers hold.)
        let threads = threads.min(64);
        if single { Crew::of(i, d, body, threads).map(Crews::Single) } else { Crew::of(i, d, body, threads).map(Crews::Double) }
    }

    /// The threads it steps the body on, the main thread with them.
    pub(super) fn threads(&self) -> usize {
        1 + match self {
            Crews::Double(c) => c.workers.len(),
            Crews::Single(c) => c.workers.len(),
        }
    }

    /// Where element `e` of the bore's group `g` lies among its parts (Crew::element_at).
    pub(super) fn element_at(&self, g: usize, e: usize) -> Option<(usize, usize, usize)> {
        match self {
            Crews::Double(c) => c.element_at(g, e),
            Crews::Single(c) => c.element_at(g, e),
        }
    }

    /// # Safety
    /// As Crew::put.
    pub(super) unsafe fn put(&mut self, part: usize, at: usize, values: &[f64]) {
        match self {
            Crews::Double(c) => c.put(part, at, values),
            Crews::Single(c) => c.put(part, at, values),
        }
    }

    /// # Safety
    /// As Crew::put_d.
    pub(super) unsafe fn put_d(&mut self, at: usize, value: f64) {
        match self {
            Crews::Double(c) => c.put_d(at, value),
            Crews::Single(c) => c.put_d(at, value),
        }
    }

    /// # Safety
    /// As Crew::run.
    #[allow(clippy::too_many_arguments)]
    pub(super) unsafe fn run(&mut self, i: &[i64], d: &mut [f64], body: &mut Decoded, tract: Option<&mut Tract>, u: &[f64], y: &mut [f64],
                             steps: usize) -> i64 {
        match self {
            Crews::Double(c) => c.run(i, d, body, tract, u, y, steps),
            Crews::Single(c) => c.run(i, d, body, tract, u, y, steps),
        }
    }
}
