//! A body stepped on several cores (research/OPENWIND_REALTIME_PLAN.md; claude-scratch/openwind-multicore/PROGRESS.md):
//! for a woodwind one core steps slower than it sounds -- the live dial's English horn, bassoon, saxophones (the owner,
//! 31 October 2026: the dial stuttering for them). Its lossy pipes share nothing within a step -- each pipe's nodes its
//! own, its elements joined only by the pressure nodes they share -- and meet only through their connectors, at their
//! ends. So the bore is split by whole pipes, in memory order, into parts of about equal cost, each laid out on its own
//! as Mirror lays out the whole (its state and coefficients, doubles or singles as the body is stepped, padded to whole
//! blocks with zeros, which stay so), and each stepped on a thread of its own with every connector at its ends: those
//! whose ends are all its own, and those joining it to the parts beside it, which each of those parts steps alike in its
//! own copy of `d` -- the same values in, the same out. The main thread steps the part with the player's reed, lips or
//! jet, and its tract.
//!
//! So a part waits on nothing but the parts beside it, and on them for the step before: the no-flow pressures at their
//! ends that its joining connectors read, which each part posts on its board with the count of its steps as each step
//! ends -- one pass of a cache line from core to core a step, whatever the bore's length, where its steps' cost is shared
//! among as many cores as it is split for (the owner, 2 November 2026: "Can you find a way to optimize such that making
//! an instrument larger does not make it slower?"). Every part had waited each step for the main thread, which stepped
//! the joining connectors and then waited for every part: some five passes a step, some 0.5 us natively and over 1 us in
//! a page, however small the parts (the baritone saxophone 0.97 of real time on one core, 0.55 on three, 0.50 on four).
//! So, against that, at the same moment (best of three, the machine loaded: claude-scratch/openwind-multicore/neighbours/
//! runs): the bassoon in singles 0.80 of real time on four cores where it had taken 1.07, the English horn 0.74 on six
//! (0.94), the trombone 0.55 on three (0.76); in WebAssembly, each core a Worker, the bassoon 0.84 on eight (0.98), the
//! tenor saxophone 0.82 on four (0.94). Its outputs are summed once its parts have stepped the call's steps, each part's
//! records kept a step at a time.
//!
//! Every value is the one thread's, bit for bit: each node's arithmetic is unchanged, each pressure node's sum keeps its
//! order (the two elements that share a node are one pipe's, so in one part, in their groups' order), and each connector
//! reads and writes only its own ends and block -- a joining connector the same values in each of its parts' copies of
//! `d`, from the same.
//!
//! A worker steps its connectors in a copy of `d` of its own, not in `d`: two threads writing one cache line every step
//! would pass it from core to core. Each worker spins on the main thread's count of calls between them, and sleeps once
//! it has waited past IDLE -- between the stream's calls -- woken by the next.
//!
//! A part's step is taken by whichever thread comes to it first: its worker, or the main thread where it waits on the
//! part and the part's worker sleeps, or has not taken it for HELP spins once it might. So a worker late to a call --
//! woken late, or without a core of its own while others' work fills the machine -- does not hold the steps back: the
//! main thread steps its part for it, and only a step begun is waited for. Whoever steps it, a part is stepped in the
//! same arrays and the same copy of `d`, in the same order.

use super::{at, bore_step, connect, region_length, shape_of, Bore, Conn, Decoded, End, Group, Real, BLOCK, BORE_COEFFICIENTS,
            BORE_STATE, B_H, B_N, B_PI, B_PIP0, B_PNF, B_PPI, B_T, B_V, B_VI, B_VIV, B_VV, B_VVI, B_XV, FIELDS, NONE, T_FLUTE,
            T_LIPS, T_REED};
use crate::tract::Tract;
use std::cell::UnsafeCell;
use std::sync::atomic::{fence, AtomicBool, AtomicPtr, AtomicU64, Ordering};
use std::sync::Arc;
use std::thread::JoinHandle;
use std::time::{Duration, Instant};

/// How long a worker spins for the next call before it sleeps: past the stream's own work between its calls (a block's
/// controls and flows, some 100-200 us), well short of the dial's between its blocks (some 10 ms).
const IDLE: Duration = Duration::from_micros(250);

/// How long the main thread waits on an awake worker's part that could take its next step and has not, before it steps
/// it itself: spins, some 5-20 us -- past a step's own time (1-3 us), short of a block's.
const HELP: u32 = 1 << 12;

/// A connector's cost a step, in the bore's units (a node through one loss variable): a few of its nodes' -- what its
/// part is charged for it, so that the parts' times come out about equal (the English horn's 211 connectors some third
/// of its step).
const CONNECTOR_COST: usize = 40;

/// The no-flow pressures a part posts on its board, each at the last two steps (by their parity): with the board's count,
/// one cache line.
const POSTED: usize = 7;

/// What lies in a cache line of its own (Apple silicon's are 128 bytes), so that what one thread writes is never in the
/// line another reads for something else.
#[repr(align(128))]
struct Line<X>(X);

/// The main thread's, written only as a call begins: its count of calls -- odd while the call's steps and rows are
/// written, so that a worker reading them while they change reads them again --, the call's first and last steps
/// (counted from the body's first, 1), its rows of controls, and whether the workers are let go.
struct Beat {
    epoch: AtomicU64,
    first: AtomicU64,
    last: AtomicU64,
    u: AtomicPtr<f64>,
    stop: AtomicBool,
}

/// A part's board, read by the parts beside it: the last step it has done, and the no-flow pressures it posts as that
/// step and the one before left them ([place][parity]).
struct Board {
    done: AtomicU64,
    posted: UnsafeCell<[f64; 2 * POSTED]>,
}

// (Each place written only by the thread stepping its part, at a step whose parity no part beside it reads meanwhile --
// none reads a step's but after the count that tells of it, and none of them is two steps behind -- before the count;
// read only after it.)
unsafe impl Sync for Board {}

struct Shared {
    beat: Line<Beat>,
    // (Each worker's: the last step of its part taken, by it or the main thread; whether it sleeps.)
    taken: Vec<Line<AtomicU64>>,
    asleep: Vec<Line<AtomicBool>>,
    // (Each part's, the main thread's first.)
    boards: Vec<Line<Board>>,
}

/// A worker's part with what it is stepped in: its view, a copy of `d` of its own for its connectors, and its records
/// of the call's steps.
struct Seat<T> {
    part: Part<T>,
    view: Bore<T>,
    dq: Vec<f64>,
    recs: Vec<f64>,
}

impl<T: Real> Seat<T> {
    /// Its part's step `s`, the call's `k`th (Part::step), by whichever thread has taken it.
    ///
    /// # Safety
    /// As Part::step; taken for this step by the thread stepping it alone.
    #[inline(always)]
    unsafe fn step(&mut self, ends: &[End], row: *const f64, s: u64, k: usize, boards: &[Line<Board>], board: &Board) {
        let recs = self.recs.as_mut_ptr().add(k * self.part.records.len());
        self.part.step(&self.view, ends, self.dq.as_mut_ptr(), row, None, s, k, boards, board, recs);
    }
}

/// A seat where its worker steps it, handed to its thread.
struct SeatAt<T>(*mut Seat<T>);

// (Stepped only by the thread that has taken it for the step, its counts ordering one step's taker before the next's;
// kept by the crew until its threads are joined.)
unsafe impl<T> Send for SeatAt<T> {}

impl<T> SeatAt<T> {
    fn at(&self) -> *mut Seat<T> {
        self.0
    }
}

/// A worker's step of its seat (Seat::step), a function of its own in a page's WebAssembly (wait's).
///
/// # Safety
/// As Seat::step.
#[cfg_attr(target_arch = "wasm32", inline(never))]
unsafe fn stepped<T: Real>(seat: &SeatAt<T>, ends: &[End], row: *const f64, s: u64, k: usize, boards: &[Line<Board>], board: &Board) {
    (*seat.at()).step(ends, row, s, k, boards, board)
}

/// A part of the bore, laid out on its own: its state and coefficients (`data`, each region at `fields`, then its groups'
/// matrices), its no-flow pressures, its groups' elements' first nodes (`index`, renumbered as its own), its groups
/// (theirs, less those with none of its elements), each with the bore's group it is of and its elements' places there
/// (`origin`); its ends (its node, the end); every connector at its ends; the parts beside it, what it takes from their
/// boards (the part, the place there, and where in `d` its connectors read it) and what it posts on its own (its node,
/// the place); and where in `d` its connectors write the records its outputs sum.
struct Part<T> {
    h: usize,
    l: usize,
    n: usize,
    data: Vec<T>,
    fields: [usize; FIELDS],
    pnf: Vec<f64>,
    index: Vec<i64>,
    groups: Vec<Group>,
    origin: Vec<(usize, Vec<usize>)>,
    ends: Vec<(usize, usize)>,
    conns: Vec<Conn>,
    beside: Vec<usize>,
    takes: Vec<(usize, usize, usize)>,
    posts: Vec<(usize, usize)>,
    records: Vec<usize>,
}

/// Its loss variables' place in a region of them, node `x`'s `q`th of `n` ([block][variable][lane]: openwind_compiled.py
/// _blocked).
#[inline(always)]
fn blocked(x: usize, q: usize, n: usize) -> usize {
    (x - x % BLOCK) * n + q * BLOCK + x % BLOCK
}

impl<T: Real> Part<T> {
    /// The part of the bore (the record at `b` in `i`, `d` its values) of the pressure and velocity nodes given (each
    /// ascending), each group's elements of it given by their place in the group.
    fn of(i: &[i64], d: &[f64], b: usize, groups: &[Group], pressures: &[usize], velocities: &[usize], elements: &[Vec<usize>]) -> Part<T> {
        let n = at(i[b + B_N]);
        let (h, l) = (pressures.len().div_ceil(BLOCK) * BLOCK, velocities.len().div_ceil(BLOCK) * BLOCK);
        let (mut fields, mut next) = ([0; FIELDS], 0);
        for &f in BORE_STATE.iter().chain(&BORE_COEFFICIENTS) {
            fields[f] = next;
            next += region_length(f, h, l, n);
        }
        let matrices: usize = groups.iter().zip(elements).map(|(g, e)| 2 * e.len() * g.w * g.w).sum();
        let mut data = vec![T::default(); next + matrices];
        for &f in BORE_STATE.iter().chain(&BORE_COEFFICIENTS) {
            let (from, to) = (at(i[b + f]), fields[f]);
            let nodes = if matches!(f, B_V | B_T | B_VV | B_XV | B_VI | B_VIV | B_VVI) { velocities } else { pressures };
            let losses = matches!(f, B_PI | B_PIP0 | B_PPI | B_VI | B_VIV | B_VVI);
            for (j, &x) in nodes.iter().enumerate() {
                if losses {
                    for q in 0..n {
                        data[to + blocked(j, q, n)] = T::of(d[from + blocked(x, q, n)]);
                    }
                } else {
                    data[to + j] = T::of(d[from + x]);
                }
            }
        }
        let mut pnf = vec![0.0; h];
        for (j, &x) in pressures.iter().enumerate() {
            pnf[j] = d[at(i[b + B_PNF]) + x];
        }
        // (Each node's place here, by its place in the bore: its elements' nodes, consecutive there, consecutive here.)
        let local = |nodes: &[usize], x: usize| nodes.binary_search(&x).unwrap_or_else(|_| unreachable!()) as i64;
        let (mut index, mut own_groups, mut origin) = (Vec::new(), Vec::new(), Vec::new());
        for (j, (g, mine)) in groups.iter().zip(elements).enumerate() {
            if mine.is_empty() {
                continue;
            }
            origin.push((j, mine.clone()));
            let (w, count) = (g.w, mine.len());
            let (hs, ls, a) = (index.len(), index.len() + count, next);
            index.extend(mine.iter().map(|&e| local(pressures, at(i[g.hs + e]))));
            index.extend(mine.iter().map(|&e| local(velocities, at(i[g.ls + e]))));
            for (k, &e) in mine.iter().enumerate() {
                for c in 0..w * w {
                    data[a + k * w * w + c] = T::of(d[g.a + e * w * w + c]);
                    data[a + (count + k) * w * w + c] = T::of(d[g.b + e * w * w + c]);
                }
            }
            own_groups.push(Group { w, count, hs, ls, a, b: a + count * w * w });
            next += 2 * count * w * w;
        }
        Part { h, l, n, data, fields, pnf, index, groups: own_groups, origin, ends: Vec::new(), conns: Vec::new(), beside: Vec::new(),
               takes: Vec::new(), posts: Vec::new(), records: Vec::new() }
    }

    /// Its arrays where bore_step reads them.
    ///
    /// # Safety
    /// Kept no longer than the part, whose arrays are not resized meanwhile.
    unsafe fn view(&mut self) -> Bore<T> {
        let base = self.data.as_mut_ptr();
        let mut at_field = [std::ptr::null_mut(); FIELDS];
        for &f in BORE_STATE.iter().chain(&BORE_COEFFICIENTS) {
            at_field[f] = base.add(self.fields[f]);
        }
        Bore { h: self.h, l: self.l, n: self.n, at: at_field, pnf: self.pnf.as_mut_ptr(),
               a: self.groups.iter().map(|g| base.add(g.a) as *const T).collect(), b: self.groups.iter().map(|g| base.add(g.b) as *const T).collect() }
    }

    /// Its step `s` (counted from the body's first), the call's `k`th, the parts beside it done to the step before: what
    /// it takes from their boards put where its connectors read it in `dq` (`d` itself on the main thread, a worker's own
    /// copy of it); its connectors there (`tract` its player's, where its reed is); its ends' pressures at the half step
    /// from their flows; its nodes; its ends' no-flow pressures put where its connectors read them at the next, and those
    /// it posts on its board, `board`; its records at `recs`; and the step told. -> as connect, where a connector stops it
    /// (the step then neither ended nor told).
    ///
    /// # Safety
    /// `view` is its own; `dq` addresses the body's doubles, its connectors' places in `dq` no other thread's; `row` the
    /// step's controls; `boards` every part's, `board` its own among them; `recs` room for its records.
    #[allow(clippy::too_many_arguments)]
    #[inline(always)]
    unsafe fn step(&mut self, view: &Bore<T>, ends: &[End], dq: *mut f64, row: *const f64, mut tract: Option<&mut Tract>, s: u64,
                   k: usize, boards: &[Line<Board>], board: &Board, recs: *mut f64) -> i64 {
        let before = ((s - 1) & 1) as usize;
        for &(q, slot, place) in &self.takes {
            *dq.add(place) = *(boards.get_unchecked(q).0.posted.get() as *const f64).add(2 * slot + before);
        }
        for conn in self.conns.iter_mut() {
            let status = connect(conn, ends, dq, row, tract.as_deref_mut(), k);
            if status != 0 {
                return status;
            }
        }
        for &(node, e) in &self.ends {
            let e = ends.get_unchecked(e);
            *view.pnf.add(node) -= *dq.add(e.alpha) * *dq.add(e.w);
        }
        bore_step(&self.index, view, &self.groups);
        for &(node, e) in &self.ends {
            *dq.add(ends.get_unchecked(e).pnf) = *view.pnf.add(node);
        }
        let (posted, now) = (board.posted.get() as *mut f64, (s & 1) as usize);
        for &(node, slot) in &self.posts {
            *posted.add(2 * slot + now) = *view.pnf.add(node);
        }
        for (j, &place) in self.records.iter().enumerate() {
            *recs.add(j) = *dq.add(place);
        }
        board.done.store(s, Ordering::Release);
        0
    }
}

/// The bore's pipes: its elements joined by the pressure nodes they share, in memory order (by their first node), each
/// its pressure and velocity nodes, ascending, and its cost a step (each node through its loss variables, each element's
/// two matrices). -> them, and each group's elements' pipes.
#[allow(clippy::type_complexity)]
fn pipes_of(i: &[i64], groups: &[Group], h: usize, n: usize) -> (Vec<(Vec<usize>, Vec<usize>, usize)>, Vec<Vec<usize>>) {
    let mut parent: Vec<usize> = (0..h).collect();
    fn root(parent: &mut [usize], mut x: usize) -> usize {
        while parent[x] != x {
            parent[x] = parent[parent[x]];
            x = parent[x];
        }
        x
    }
    let mut covered = vec![false; h];
    for g in groups {
        for e in 0..g.count {
            let first = at(i[g.hs + e]);
            covered[first..first + g.w].fill(true);
            for c in 1..g.w {
                let (a, b) = (root(&mut parent, first), root(&mut parent, first + c));
                parent[b] = a;
            }
        }
    }
    let (mut pipe_of_root, mut pipes) = (vec![NONE; h], Vec::new());
    for x in 0..h {
        if covered[x] {
            let r = root(&mut parent, x);
            if pipe_of_root[r] == NONE {
                pipe_of_root[r] = pipes.len();
                pipes.push((Vec::new(), Vec::new(), 0));
            }
            let pipe = &mut pipes[pipe_of_root[r]];
            pipe.0.push(x);
            pipe.2 += 1 + n;
        }
    }
    let mut element_pipes = Vec::with_capacity(groups.len());
    for g in groups {
        element_pipes.push((0..g.count).map(|e| {
            let p = pipe_of_root[root(&mut parent, at(i[g.hs + e]))];
            let first = at(i[g.ls + e]);
            pipes[p].1.extend(first..first + g.w);
            pipes[p].2 += (1 + n) * g.w + 2 * g.w * g.w;
            p
        }).collect());
    }
    for pipe in pipes.iter_mut() {
        pipe.1.sort_unstable();
        pipe.1.dedup();
    }
    (pipes, element_pipes)
}

/// A worker's wait for the main thread's next call: spun, then slept once it has waited past IDLE (woken by the call
/// that ends it). -> that call's count, once its steps and rows are written (even).
// (Its own function, as its step is (stepped), in a page's WebAssembly: a browser optimizes a function's code only for
// its next call, and a worker's loop is never called again, so that what it calls each step is what is optimized.)
#[cfg_attr(target_arch = "wasm32", inline(never))]
fn wait(beat: &Beat, asleep: &AtomicBool, seen: u64) -> u64 {
    let (mut spins, mut since) = (0u32, None::<Instant>);
    loop {
        let now = beat.epoch.load(Ordering::Acquire);
        if now != seen && now & 1 == 0 {
            return now;
        }
        spins = spins.wrapping_add(1);
        if spins % 256 == 0 && since.get_or_insert_with(Instant::now).elapsed() > IDLE {
            // (Said asleep before the count is read again, as the main thread counts before it reads who sleeps: the
            // one sees the other.)
            asleep.store(true, Ordering::SeqCst);
            if beat.epoch.load(Ordering::SeqCst) == seen {
                std::thread::park();
            }
            asleep.store(false, Ordering::SeqCst);
            since = None;
        }
        std::hint::spin_loop();
    }
}

/// A worker's call: its part's steps from the first not yet done to the call's `last`, each taken as the parts beside it
/// are done to the step before it -- where the main thread has not taken it first, which it then waits out.
///
/// # Safety
/// As Seat::step; `u` the call's rows from its `first` step, `cols` a row.
#[allow(clippy::too_many_arguments)]
#[cfg_attr(target_arch = "wasm32", inline(never))]
unsafe fn played<T: Real>(seat: &SeatAt<T>, ends: &[End], shared: &Shared, w: usize, beside: &[usize], cols: usize, first: u64,
                          last: u64, u: *const f64) {
    let (taken, boards) = (&shared.taken[w].0, shared.boards.as_slice());
    let board = &boards[w + 1].0;
    loop {
        let done = board.done.load(Ordering::Acquire);
        if done >= last || done + 1 < first {
            return;
        }
        let s = done + 1;
        if taken.load(Ordering::Relaxed) < s && beside.iter().all(|&q| boards.get_unchecked(q).0.done.load(Ordering::Acquire) >= done)
            && taken.fetch_max(s, Ordering::AcqRel) < s {
            let k = (s - first) as usize;
            stepped(seat, ends, u.add(k * cols), s, k, boards, board);
        } else {
            std::hint::spin_loop();
        }
    }
}

/// A connector's ends that it joins (its block's shape).
fn joined(conn: &Conn) -> &[usize] {
    &conn.e[..shape_of(conn.kind).map_or(0, |s| s.1)]
}

/// A worker thread's own priority: the user's interactive work, as an audio thread's (macOS's QoS classes), so that it
/// keeps to the performance cores.
pub(super) fn interactive() {
    #[cfg(target_os = "macos")]
    {
        extern "C" {
            fn pthread_set_qos_class_self_np(class: u32, relative_priority: i32) -> i32;
        }
        // (QOS_CLASS_USER_INTERACTIVE, <sys/qos.h>.)
        unsafe {
            pthread_set_qos_class_self_np(0x21, 0);
        }
    }
}

/// A player's bore on several threads: the main thread's part (that of its reed, lips or jet) and its view and records,
/// the threads stepping the rest, and how its outputs are summed.
pub(super) struct Crew<T: Real> {
    shared: Arc<Shared>,
    workers: Vec<JoinHandle<()>>,
    own: Part<T>,
    view: Bore<T>,
    recs: Vec<f64>,
    // (Each worker's seat, the main thread's to step where it takes it.)
    seats: Box<[Line<UnsafeCell<Seat<T>>>]>,
    // (Each part's parts beside it, the main thread's first: what it reads where it steps a worker's.)
    beside: Vec<Vec<usize>>,
    // (Each output's terms: a part's records (its place among the parts, the main thread's 0) at a slot, or a place in
    // `d` none writes (NONE).)
    terms: Vec<Vec<(usize, usize)>>,
    cols: usize,
    epoch: u64,
    // (The steps stepped.)
    n: u64,
}

impl<T: Real + Send + 'static> Crew<T> {
    /// The bore of the body `i`, `d` (as `body` decoded it) split into at most `parts` parts, one a thread: into fewer
    /// where a part would post more than its board holds. -> None where it has no bore, too few pipes to split, a lossless
    /// pipe, a connector's end found in no pipe, its players' connectors in two parts, or no thread to be had.
    fn of(i: &[i64], d: &[f64], body: &Decoded, parts: usize) -> Option<Crew<T>> {
        let b = body.bore?;
        if body.npipes > 0 {
            return None;
        }
        let (h, n) = (at(i[b + B_H]), at(i[b + B_N]));
        let (ends, groups) = (&body.ends, &body.groups);
        let (pipes, element_pipes) = pipes_of(i, groups, h, n);
        let mut pipe_of_node = vec![NONE; h];
        for (p, pipe) in pipes.iter().enumerate() {
            for &x in &pipe.0 {
                pipe_of_node[x] = p;
            }
        }
        // (Each bore end's pipe; each connector's ends the bore's, none read at a half step; each charged to its first
        // end's pipe.)
        let pnf_at = at(i[b + B_PNF]);
        let mut pipe_of_end = vec![NONE; ends.len()];
        for &k in &body.bore_ends {
            let node = ends[k].pnf.checked_sub(pnf_at).filter(|&x| x < h)?;
            pipe_of_end[k] = Some(pipe_of_node[node]).filter(|&p| p != NONE)?;
        }
        if body.conns.iter().any(|c| joined(c).iter().any(|&k| pipe_of_end[k] == NONE || ends[k].half != NONE)) {
            return None;
        }
        let mut costs: Vec<usize> = pipes.iter().map(|p| p.2).collect();
        for conn in &body.conns {
            if let Some(&k) = joined(conn).first() {
                costs[pipe_of_end[k]] += CONNECTOR_COST;
            }
        }
        let total: usize = costs.iter().sum();
        for parts in (2..=parts).rev() {
            if let Some(split) = Split::of(&costs, total, parts) {
                if let Some(crew) = Self::split(i, d, body, b, &split, &pipes, &element_pipes, &pipe_of_end) {
                    return Some(crew);
                }
            }
        }
        None
    }

    /// The crew of a split: its parts laid out, each with its connectors, what it takes and posts and records, its
    /// threads begun. -> None where a part would post more than its board holds, its players' connectors are in two
    /// parts, or no thread is to be had.
    #[allow(clippy::too_many_arguments)]
    fn split(i: &[i64], d: &[f64], body: &Decoded, b: usize, split: &Split, pipes: &[(Vec<usize>, Vec<usize>, usize)],
             element_pipes: &[Vec<usize>], pipe_of_end: &[usize]) -> Option<Crew<T>> {
        let (ends, groups, parts) = (&body.ends, &body.groups, split.parts);
        let pnf_at = at(i[b + B_PNF]);
        let part_of_pipe = &split.of;
        let part_of_end: Vec<usize> = pipe_of_end.iter().map(|&p| if p == NONE { NONE } else { part_of_pipe[p] }).collect();
        // Each connector's parts, those of its ends, each of which steps it.
        let parts_of: Vec<Vec<usize>> = body.conns.iter().map(|c| {
            let mut of: Vec<usize> = joined(c).iter().map(|&k| part_of_end[k]).collect();
            of.sort_unstable();
            of.dedup();
            of
        }).collect();
        // The main thread's part: its player's (whose tract is the main thread's), else the first; renumbered first.
        let mut players: Vec<usize> = body.conns.iter().zip(&parts_of).filter(|(c, _)| matches!(c.kind, T_REED | T_LIPS | T_FLUTE))
            .filter_map(|(_, of)| of.first().copied()).collect();
        players.sort_unstable();
        players.dedup();
        let own = match players[..] {
            [] => 0,
            [p] => p,
            _ => return None,
        };
        let number = |p: usize| if p == own { 0 } else if p < own { p + 1 } else { p };
        // What each part posts: its ends at a connector joining it to another part, each a place on its board.
        let (mut posts, mut slot_of_end) = (vec![Vec::new(); parts], vec![NONE; ends.len()]);
        for (c, of) in body.conns.iter().zip(&parts_of) {
            if of.len() > 1 {
                for &k in joined(c) {
                    if slot_of_end[k] == NONE {
                        let p = part_of_end[k];
                        slot_of_end[k] = posts[p].len();
                        posts[p].push(k);
                    }
                }
            }
        }
        if posts.iter().any(|p| p.len() > POSTED) {
            return None;
        }
        // What each part records: the places in `d` its outputs' terms are written by its connectors (a radiation's, a
        // reed's, a jet's: each of one end, in one part).
        let mut records: Vec<Vec<usize>> = vec![Vec::new(); parts];
        let terms: Vec<Vec<(usize, usize)>> = body.outs.iter().map(|(_, terms)| terms.iter().map(|&t| {
            match body.conns.iter().position(|c| c.rec != NONE && (t == c.rec || t == c.rec + 1)) {
                Some(c) if !parts_of[c].is_empty() => {
                    let p = parts_of[c][0];
                    let slot = records[p].iter().position(|&x| x == t).unwrap_or_else(|| {
                        records[p].push(t);
                        records[p].len() - 1
                    });
                    (number(p), slot)
                }
                _ => (NONE, t),
            }
        }).collect()).collect();
        // The parts laid out: their nodes, their elements, their ends, their connectors, what they take, post and record.
        let mut laid: Vec<Option<Part<T>>> = (0..parts).map(|p| {
            let mine = |x: &usize| part_of_pipe[*x] == p;
            let mut pressures: Vec<usize> = (0..pipes.len()).filter(mine).flat_map(|x| pipes[x].0.iter().copied()).collect();
            let mut velocities: Vec<usize> = (0..pipes.len()).filter(mine).flat_map(|x| pipes[x].1.iter().copied()).collect();
            pressures.sort_unstable();
            velocities.sort_unstable();
            let elements: Vec<Vec<usize>> = element_pipes.iter().map(|g| (0..g.len()).filter(|&e| part_of_pipe[g[e]] == p).collect()).collect();
            let mut part = Part::of(i, d, b, groups, &pressures, &velocities, &elements);
            let node = |k: usize| pressures.binary_search(&(ends[k].pnf - pnf_at)).unwrap_or_else(|_| unreachable!());
            part.ends = body.bore_ends.iter().filter(|&&k| part_of_end[k] == p).map(|&k| (node(k), k)).collect();
            let at_mine: Vec<usize> = (0..body.conns.len()).filter(|&c| parts_of[c].contains(&p)).collect();
            part.conns = at_mine.iter().map(|&c| body.conns[c]).collect();
            let mut beside: Vec<usize> = at_mine.iter().flat_map(|&c| parts_of[c].iter().copied()).filter(|&q| q != p).collect();
            beside.sort_unstable();
            beside.dedup();
            part.beside = beside.into_iter().map(number).collect();
            part.takes = at_mine.iter().filter(|&&c| parts_of[c].len() > 1).flat_map(|&c| joined(&body.conns[c]).iter().copied())
                .filter(|&k| part_of_end[k] != p).map(|k| (number(part_of_end[k]), slot_of_end[k], ends[k].pnf)).collect();
            part.posts = posts[p].iter().map(|&k| (node(k), slot_of_end[k])).collect();
            part.records = records[p].clone();
            Some(part)
        }).collect();
        let mut ordered: Vec<Part<T>> = (0..parts).map(|j| laid[(0..parts).find(|&p| number(p) == j).unwrap_or_else(|| unreachable!())].take())
            .collect::<Option<_>>()?;
        // (Each board's count the steps stepped, none; what it posts as they left it, at the parity of step 0.)
        let boards = ordered.iter().map(|part| {
            let mut posted = [0.0; 2 * POSTED];
            for &(node, slot) in &part.posts {
                posted[2 * slot] = part.pnf[node];
            }
            Line(Board { done: AtomicU64::new(0), posted: UnsafeCell::new(posted) })
        }).collect();
        let beside: Vec<Vec<usize>> = ordered.iter().map(|part| part.beside.clone()).collect();
        let seats: Box<[Line<UnsafeCell<Seat<T>>>]> = ordered.split_off(1).into_iter().map(|mut part| {
            let view = unsafe { part.view() };
            Line(UnsafeCell::new(Seat { part, view, dq: d.to_vec(), recs: Vec::new() }))
        }).collect();
        let shared = Arc::new(Shared {
            beat: Line(Beat { epoch: AtomicU64::new(0), first: AtomicU64::new(0), last: AtomicU64::new(0), u: AtomicPtr::new(std::ptr::null_mut()),
                              stop: AtomicBool::new(false) }),
            taken: (1..parts).map(|_| Line(AtomicU64::new(0))).collect(),
            asleep: (1..parts).map(|_| Line(AtomicBool::new(false))).collect(),
            boards,
        });
        let mut own = ordered.pop()?;
        let view = unsafe { own.view() };
        let mut crew = Crew { shared, workers: Vec::new(), own, view, recs: Vec::new(), seats, beside, terms, cols: body.cols, epoch: 0, n: 0 };
        for w in 0..parts - 1 {
            let (shared, ends, seat, beside, cols) = (crew.shared.clone(), ends.clone(), SeatAt(crew.seats[w].0.get()), crew.beside[w + 1].clone(), crew.cols);
            let worker = std::thread::Builder::new().name(format!("openwind part {}", w + 1)).spawn(move || {
                interactive();
                let beat = &shared.beat.0;
                let mut seen = 0;
                loop {
                    seen = wait(beat, &shared.asleep[w].0, seen);
                    if beat.stop.load(Ordering::Acquire) {
                        break;
                    }
                    // (The call's steps and rows, read whole: read again where the main thread has begun another
                    // meanwhile.)
                    let (first, last, u) = (beat.first.load(Ordering::Relaxed), beat.last.load(Ordering::Relaxed), beat.u.load(Ordering::Relaxed));
                    fence(Ordering::Acquire);
                    if beat.epoch.load(Ordering::Relaxed) != seen {
                        continue;
                    }
                    unsafe { played(&seat, &ends, &shared, w, &beside, cols, first, last, u) };
                }
            });
            // (No thread to be had: those begun let go as the crew is dropped, and the body stepped on one.)
            crew.workers.push(worker.ok()?);
        }
        Some(crew)
    }

    /// `steps` steps (Player::steps) on the body `i`, `d` as `body` decoded it, its player's tract `tract`.
    ///
    /// # Safety
    /// As Decoded::run; `d` the doubles this crew was made from, unchanged in their layout since.
    #[allow(clippy::too_many_arguments)]
    unsafe fn run(&mut self, _i: &[i64], d: &mut [f64], body: &mut Decoded, mut tract: Option<&mut Tract>, u: &[f64], y: &mut [f64],
                  steps: usize) -> i64 {
        if steps == 0 {
            return 0;
        }
        let (dp, up, nouts, ends) = (d.as_mut_ptr(), u.as_ptr(), body.nouts, body.ends.as_slice());
        let (first, last) = (self.n + 1, self.n + steps as u64);
        // (Kept by the crew, which outlives the call.)
        let shared = &*Arc::as_ptr(&self.shared);
        // (Room for each part's records of the call's steps, made while no worker steps.)
        let mine = self.own.records.len();
        if self.recs.len() < steps * mine {
            self.recs.resize(steps * mine, 0.0);
        }
        for seat in self.seats.iter() {
            let seat = &mut *seat.0.get();
            if seat.recs.len() < steps * seat.part.records.len() {
                seat.recs.resize(steps * seat.part.records.len(), 0.0);
            }
        }
        // The call begun: its steps and rows written between two counts of calls, the first odd; each worker woken
        // where it sleeps.
        let beat = &shared.beat.0;
        self.epoch += 1;
        beat.epoch.store(self.epoch, Ordering::Relaxed);
        fence(Ordering::Release);
        beat.first.store(first, Ordering::Relaxed);
        beat.last.store(last, Ordering::Relaxed);
        beat.u.store(up as *mut f64, Ordering::Relaxed);
        self.epoch += 1;
        beat.epoch.store(self.epoch, Ordering::SeqCst);
        for (asleep, worker) in shared.asleep.iter().zip(&self.workers) {
            if asleep.0.load(Ordering::SeqCst) {
                worker.thread().unpark();
            }
        }
        // Its own part's steps, each once the parts beside it are done to the step before.
        let board = &shared.boards[0].0;
        for s in first..=last {
            let k = (s - first) as usize;
            for &q in &self.own.beside {
                self.until(q, s - 1, s - 1, ends, up, first);
            }
            let recs = self.recs.as_mut_ptr().add(k * mine);
            let status = self.own.step(&self.view, ends, dp, up.add(k * self.cols), tract.as_deref_mut(), s, k, &shared.boards, board, recs);
            // (Stopped: no step taken further, each begun waited for -- no worker still stepping once this returns.)
            if status != 0 {
                self.close(last);
                self.n = last;
                return status;
            }
        }
        // Every part done to the call's last step; then what it records: each output a sum of recorded values, in its
        // order, each from where it was kept.
        for q in 1..shared.boards.len() {
            self.until(q, last, last, ends, up, first);
        }
        for k in 0..steps {
            for (j, terms) in self.terms.iter().enumerate() {
                let value = |&(from, at): &(usize, usize)| match from {
                    0 => *self.recs.get_unchecked(k * mine + at),
                    NONE => *dp.add(at),
                    _ => {
                        let seat = &*self.seats.get_unchecked(from - 1).0.get();
                        *seat.recs.get_unchecked(k * seat.part.records.len() + at)
                    }
                };
                let mut sum = value(terms.get_unchecked(0));
                for t in terms.get_unchecked(1..) {
                    sum += value(t);
                }
                *y.get_unchecked_mut(k * nouts + j) = sum;
            }
        }
        self.n = last;
        0
    }

    /// Part `q` waited for until it has done step `want`: meanwhile, each worker's part whose next step is at most `upto`
    /// and could be taken stepped here where its worker sleeps, or has not taken it for HELP spins.
    ///
    /// # Safety
    /// Within Crew::run: `up` its rows from its `first` step.
    unsafe fn until(&self, q: usize, want: u64, upto: u64, ends: &[End], up: *const f64, first: u64) {
        let done = &self.shared.boards.get_unchecked(q).0.done;
        let mut spins = 0u32;
        while done.load(Ordering::Acquire) < want {
            spins = spins.saturating_add(1);
            if spins % 32 == 0 {
                self.help(upto, spins >= HELP, ends, up, first);
            }
            std::hint::spin_loop();
        }
    }

    /// Each worker's part whose next step is at most `upto`, the parts beside it done to the step before, stepped here
    /// where its worker sleeps (or, `long`, has not taken it), taken first.
    ///
    /// # Safety
    /// As until.
    unsafe fn help(&self, upto: u64, long: bool, ends: &[End], up: *const f64, first: u64) {
        let (shared, boards) = (&*self.shared, self.shared.boards.as_slice());
        for (w, taken) in shared.taken.iter().enumerate() {
            if !(long || shared.asleep.get_unchecked(w).0.load(Ordering::Relaxed)) {
                continue;
            }
            let (taken, board) = (&taken.0, &boards.get_unchecked(w + 1).0);
            let done = board.done.load(Ordering::Acquire);
            let s = done + 1;
            if s > upto || s < first || taken.load(Ordering::Relaxed) >= s {
                continue;
            }
            if self.beside.get_unchecked(w + 1).iter().all(|&r| boards.get_unchecked(r).0.done.load(Ordering::Acquire) >= done)
                && taken.fetch_max(s, Ordering::AcqRel) < s {
                let k = (s - first) as usize;
                (*self.seats.get_unchecked(w).0.get()).step(ends, up.add(k * self.cols), s, k, boards, board);
            }
        }
    }

    /// The call ended at a stop: every worker's part's steps to `last` taken, so that none is begun, each begun waited
    /// for, and every part counted done to `last`.
    fn close(&self, last: u64) {
        let shared = &*self.shared;
        for (w, taken) in shared.taken.iter().enumerate() {
            let board = &shared.boards[w + 1].0;
            let begun = taken.0.fetch_max(last, Ordering::AcqRel);
            while board.done.load(Ordering::Acquire) < begun {
                std::hint::spin_loop();
            }
            board.done.store(last, Ordering::Release);
        }
        shared.boards[0].0.done.store(last, Ordering::Release);
    }
}

/// A split of the bore's pipes, in memory order, into parts of about the same cost: each pipe's part, and how many.
struct Split {
    of: Vec<usize>,
    parts: usize,
}

impl Split {
    /// -> None where it comes to fewer than two parts.
    fn of(costs: &[usize], total: usize, parts: usize) -> Option<Split> {
        let mut acc = 0;
        let mut of: Vec<usize> = costs.iter().map(|&c| {
            let k = ((2 * acc + c) * parts / (2 * total.max(1))).min(parts.max(1) - 1);
            acc += c;
            k
        }).collect();
        // (Renumbered where a part has no pipe: a long pipe, or fewer pipes than parts.)
        let mut used: Vec<usize> = of.clone();
        used.dedup();
        for k in of.iter_mut() {
            *k = used.binary_search(k).unwrap_or_else(|_| unreachable!());
        }
        (used.len() >= 2).then_some(Split { of, parts: used.len() })
    }
}

impl<T: Real> Crew<T> {
    /// Where element `e` of the bore's group `g` lies among the parts: the part (0 the main thread's own, 1 + w worker
    /// w's) and where its two blocks begin in that part's data. -> None where no part has it.
    fn element_at(&self, g: usize, e: usize) -> Option<(usize, usize, usize)> {
        let find = |part: &Part<T>| {
            let j = part.origin.iter().position(|(of, _)| *of == g)?;
            let k = part.origin[j].1.binary_search(&e).ok()?;
            let (group, size) = (&part.groups[j], part.groups[j].w * part.groups[j].w);
            Some((group.a + k * size, group.b + k * size))
        };
        if let Some((a, b)) = find(&self.own) {
            return Some((0, a, b));
        }
        // (Read while no worker steps: between Crew::run's calls.)
        self.seats.iter().enumerate().find_map(|(w, seat)| find(unsafe { &(*seat.0.get()).part }).map(|(a, b)| (1 + w, a, b)))
    }

    /// `values` put in a part's data from `at` (as element_at places a block), each as its bore is stepped.
    ///
    /// # Safety
    /// Between Crew::run's calls, no worker stepping; `at` and its values within that part's data.
    unsafe fn put(&mut self, part: usize, at: usize, values: &[f64]) {
        let data = if part == 0 { &mut self.own.data } else { &mut (*self.seats[part - 1].0.get()).part.data };
        for (x, &v) in data[at..at + values.len()].iter_mut().zip(values) {
            *x = T::of(v);
        }
    }

    /// `value` put at `at` in every worker's copy of `d`, where its connectors and its parts' ends read it.
    ///
    /// # Safety
    /// As put; `at` within `d`.
    unsafe fn put_d(&mut self, at: usize, value: f64) {
        for seat in self.seats.iter() {
            (&mut (*seat.0.get()).dq)[at] = value;
        }
    }
}

impl<T: Real> Drop for Crew<T> {
    fn drop(&mut self) {
        let beat = &self.shared.beat.0;
        beat.stop.store(true, Ordering::SeqCst);
        beat.epoch.store(self.epoch + 2, Ordering::SeqCst);
        for worker in &self.workers {
            worker.thread().unpark();
        }
        for worker in self.workers.drain(..) {
            let _ = worker.join();
        }
    }
}

/// A player's crew, its bore in doubles or singles as the body is stepped.
pub(super) enum Crews {
    Double(Crew<f64>),
    Single(Crew<f32>),
}

impl Crews {
    /// The body `i`, `d` (as `body` decoded it) on `threads` threads where its bore splits so, else on as many as it
    /// splits into; None where it does not split.
    pub(super) fn of(i: &[i64], d: &[f64], body: &Decoded, single: bool, threads: usize) -> Option<Crews> {
        let threads = threads.min(64);
        if single { Crew::of(i, d, body, threads).map(Crews::Single) } else { Crew::of(i, d, body, threads).map(Crews::Double) }
    }

    /// The threads it steps the body on, the main thread with them.
    pub(super) fn threads(&self) -> usize {
        1 + match self {
            Crews::Double(c) => c.workers.len(),
            Crews::Single(c) => c.workers.len(),
        }
    }

    /// Where element `e` of the bore's group `g` lies among its parts (Crew::element_at).
    pub(super) fn element_at(&self, g: usize, e: usize) -> Option<(usize, usize, usize)> {
        match self {
            Crews::Double(c) => c.element_at(g, e),
            Crews::Single(c) => c.element_at(g, e),
        }
    }

    /// # Safety
    /// As Crew::put.
    pub(super) unsafe fn put(&mut self, part: usize, at: usize, values: &[f64]) {
        match self {
            Crews::Double(c) => c.put(part, at, values),
            Crews::Single(c) => c.put(part, at, values),
        }
    }

    /// # Safety
    /// As Crew::put_d.
    pub(super) unsafe fn put_d(&mut self, at: usize, value: f64) {
        match self {
            Crews::Double(c) => c.put_d(at, value),
            Crews::Single(c) => c.put_d(at, value),
        }
    }

    /// # Safety
    /// As Crew::run.
    #[allow(clippy::too_many_arguments)]
    pub(super) unsafe fn run(&mut self, i: &[i64], d: &mut [f64], body: &mut Decoded, tract: Option<&mut Tract>, u: &[f64], y: &mut [f64],
                             steps: usize) -> i64 {
        match self {
            Crews::Double(c) => c.run(i, d, body, tract, u, y, steps),
            Crews::Single(c) => c.run(i, d, body, tract, u, y, steps),
        }
    }
}
