//! OpenWInD's time loop: TemporalSolver.one_step and the components a woodwind's simulation calls, as
//! render/synthesis/workers/openwind_kernel_fast.c steps them -- the same scheme on the same laid-out body (two arrays, of
//! integers `i` and doubles `d`, built by openwind_compiled.py Compiled), its lossy pipes stepped as one bore along
//! memory, each step's controls a row of `u`, its outputs a row of `y`. Port of that file, record for record and
//! operation for operation; its sums in its order, so that it is the C kernel's within rounding (render/synthesis/tools/
//! rust_kernel_check.py measures how near). A derivative of OpenWInD's scheme (Inria, GPL-3.0-or-later).
//!
//! The components, as OpenWInD's temporal/ files write them:
//!   - a pipe with the diffusive representation of its wall losses (tpipe_lossy.py), or none (tpipe.py);
//!   - a simple junction (tsimplejunction.py), a T-joint (tjunction.py TemporalJunction), a discontinuity of section
//!     (TemporalJunctionDiscontinuity), a brass valve's switch (TemporalJunctionSwitch), its opening set each step;
//!   - two side holes nearer each other than a body's shortest slice and the bore between them, one junction of four
//!     ports (render/synthesis/workers/openwind_bodies.py TemporalCross);
//!   - a radiating end, Pade (tradiation.py), its opening set by the fingering each step;
//!   - a reed, scaled (treed1dof_scaled.py), and a flute's jet (tflute.py), their parameters given step by step.
//!   - and the player's vocal tract upstream of a reed where it has one (tract.rs); none, the C kernel's steps.
//! Each step the connectors first, then the pipes (temporal_solver.py one_step).

use crate::tract::Tract;

// (The body stepped on several cores, its bore split by pipes: natively, or in a page's WebAssembly built with threads
// (wasm32-wasip1-threads, --features threads: its threads the page's Workers, sharing its memory -- src/wasm.rs).)
#[cfg(any(not(target_arch = "wasm32"), feature = "threads"))]
#[path = "parallel.rs"]
mod parallel;

/// The calling thread's priority raised to the user's interactive work, as the crew's workers raise theirs (parallel.rs):
/// the live dial's main thread, which steps the joins between the bore's parts, its lips or reed and its own part, so
/// that it keeps to the performance cores and is never put behind work at a lower priority (overnight fits run at the
/// background's, on the efficiency cores).
#[cfg(not(target_arch = "wasm32"))]
pub fn interactive() {
    parallel::interactive();
}

const T_SIMPLE: i64 = 1;
const T_TJOINT: i64 = 2;
const T_DISCONTINUITY: i64 = 3;
const T_RADIATION: i64 = 4;
const T_REED: i64 = 5;
const T_FLUTE: i64 = 6;
const T_LIPS: i64 = 7;
const T_SWITCH: i64 = 8;
const T_CROSS: i64 = 9;

// The bore's record in `i` (openwind_kernel_fast.c, its enum of the same names).
const B_H: usize = 0;
const B_L: usize = 1;
const B_N: usize = 2;
const B_P: usize = 3;
const B_V: usize = 4;
const B_P0: usize = 5;
const B_PNF: usize = 6;
const B_PI: usize = 7;
const B_VI: usize = 8;
const B_S: usize = 9;
const B_T: usize = 10;
const B_PPNF: usize = 11;
const B_P0PNF: usize = 12;
const B_M: usize = 13;
const B_PP0: usize = 14;
const B_P0P0: usize = 15;
const B_PIP0: usize = 16;
const B_PPI: usize = 17;
const B_VV: usize = 18;
const B_VIV: usize = 19;
const B_VVI: usize = 20;
const B_XV: usize = 21;
const B_GROUPS: usize = 22;
const B_NGROUPS: usize = 23;
const B_ENDS: usize = 24;
const B_NENDS: usize = 25;
// A group of a lossy pipe's mesh's elements of one width.
const G_W: usize = 0;
const G_COUNT: usize = 1;
const G_H: usize = 2;
const G_L: usize = 3;
const G_A: usize = 4;
const G_B: usize = 5;
const GROUP_REC: usize = 6;
// A pipe without losses.
const L_NH1: usize = 0;
const L_NL2: usize = 1;
const L_MINUS: usize = 2;
const L_PLUS: usize = 3;
const L_P: usize = 4;
const L_V: usize = 5;
const L_MBTV: usize = 6;
const L_A_PTR: usize = 7;
const L_A_IDX: usize = 8;
const L_A_DAT: usize = 9;
const L_B_PTR: usize = 10;
const L_B_IDX: usize = 11;
const L_B_DAT: usize = 12;
const PIPE_REC: usize = 13;
// An end.
const E_PNF: usize = 0;
const E_HALF: usize = 1;
const E_ALPHA: usize = 2;
const E_W: usize = 3;
const END_REC: usize = 4;
// A connector.
const C_TYPE: usize = 0;
const C_E1: usize = 1;
const C_D: usize = 4;
const C_U: usize = 5;
const C_REC: usize = 6;
const C_MEM: usize = 7;
const C_MEMLEN: usize = 8;
const C_MEMCAP: usize = 9;
// (A cross's fourth end, in the place a flute's memory takes.)
const C_E4: usize = C_MEM;
const CONN_REC: usize = 10;
// The header.
const H_BORE: usize = 0;
const H_PIPES: usize = 1;
const H_NPIPES: usize = 2;
const H_ENDS: usize = 3;
const H_CONNS: usize = 5;
const H_NCONNS: usize = 6;
const H_OUTS: usize = 7;
const H_NOUTS: usize = 8;
const H_UCOLS: usize = 9;

// A radiation's block in `d`.
const R_MEND: usize = 0;
const R_HALFDT: usize = 1;
const R_ZPLUS: usize = 2;
const R_A: usize = 3;
const R_BETA: usize = 4;
const R_FLOWSCALE: usize = 6;
const R_PRESSSCALE: usize = 7;
const R_PHI: usize = 8;
const R_ZETA: usize = 9;
const R_STEP: usize = 10;
const R_INFL: usize = 11;
const R_ZTOF: usize = 12;
const R_PTOF: usize = 13;
const R_KAPPA: usize = 14;
// A valve's switch's: its opening, the step, and its gamma's influence from its three ends' no-flow pressures.
const S_PHI: usize = 0;
const S_DT: usize = 1;
const S_INFL: usize = 2;
// A reed's.
const Q_ZC: usize = 0;
const Q_THETA: usize = 2;
const Q_CONTACT: usize = 3;
const Q_SP: usize = 4;
const Q_SF: usize = 5;
const Q_SIMP: usize = 6;
const Q_DT: usize = 7;
const Q_FLOWSCALE: usize = 8;
const Q_PRESSSCALE: usize = 9;
const Q_THISY: usize = 10;
const Q_LASTY: usize = 11;
const Q_PREVZ: usize = 12;
const Q_LASTKC: usize = 13;
const Q_EXPONENT: usize = 14;
const Q_LEAK: usize = 15;
const Q_PSI: usize = 16;
// (A reed's block ends there; brass lips' with their inward mode (T_LIPS: render/synthesis/workers/openwind_lips.py) go
// on: its state, then its area over the outward's, its direction. Its resonance over the outward one's, its Q and the
// outward mass over its own are its register's, each step's controls after the reed's: U_RATIO...)
const Q_THISQ: usize = 17;
const Q_LASTQ: usize = 18;
const Q_SHARE: usize = 19;
const Q_MODEL2: usize = 20;
// (Lips' controls after a reed's nine: their inward mode's values, openwind_compiled.py LIPS_PARAMETERS.)
const U_RATIO: usize = 9;
const U_QFACTOR2: usize = 10;
const U_COUPLING: usize = 11;
// A flute's.
const F_ALPHAR: usize = 5;
const F_BETAR: usize = 6;
const F_RHO: usize = 7;
const F_CELERITY: usize = 8;
const F_ZC: usize = 9;
const F_SP: usize = 10;
const F_SIMP: usize = 11;
const F_STIME: usize = 12;
const F_DT: usize = 13;
const F_FLOWSCALE: usize = 14;
const F_PRESSSCALE: usize = 15;
const F_PREVZETA: usize = 16;
const F_THISETA: usize = 17;
const F_LASTETA: usize = 18;

/// Nodes stepped together through every loss variable (openwind_compiled.py BLOCK).
pub const BLOCK: usize = 8;

#[inline(always)]
fn at(x: i64) -> usize {
    x as usize
}

/// An end's record, by its index.
#[inline(always)]
fn end_of(i: &[i64], k: i64) -> usize {
    at(i[H_ENDS]) + at(k) * END_REC
}

/// scipy's csr_matvec: y += A x.
fn csr_matvec(rows: usize, i: &[i64], ptr: usize, idx: usize, d: &mut [f64], dat: usize, x: usize, y: usize) {
    for r in 0..rows {
        let mut sum = d[y + r];
        for jj in at(i[ptr + r])..at(i[ptr + r + 1]) {
            sum += d[dat + jj] * d[x + at(i[idx + jj])];
        }
        d[y + r] = sum;
    }
}

/// Whether every region the bore's record names lies within `nd` doubles and its groups' nodes within the bore: what lets
/// its loops read without a check at each value (lossy_pipes).
fn bore_fits(i: &[i64], nd: usize, b: usize) -> bool {
    let field = |f: usize| i.get(b + f).copied();
    let (Some(h), Some(l), Some(n)) = (field(B_H), field(B_L), field(B_N)) else { return false };
    if h < 0 || l < 0 || n < 0 || h as usize % BLOCK != 0 || l as usize % BLOCK != 0 {
        return false;
    }
    let (h, l, n) = (h as usize, l as usize, n as usize);
    let within = |f: usize, len: usize| field(f).is_some_and(|o| o >= 0 && (o as usize).checked_add(len).is_some_and(|e| e <= nd));
    let by_h = [B_P, B_P0, B_PNF, B_S, B_PPNF, B_P0PNF, B_M, B_PP0, B_P0P0];
    let by_l = [B_V, B_T, B_VV, B_XV];
    if !by_h.iter().all(|&f| within(f, h)) || !by_l.iter().all(|&f| within(f, l))
        || ![B_PI, B_PIP0, B_PPI].iter().all(|&f| within(f, h * n)) || ![B_VI, B_VIV, B_VVI].iter().all(|&f| within(f, l * n)) {
        return false;
    }
    // (And no two of them overlapping: its loops take each as a slice of its own, as the C kernel's take restrict
    // pointers, so that what one writes is never what another reads.)
    let mut regions: Vec<(usize, usize)> = by_h.iter().map(|&f| (at(i[b + f]), h)).chain(by_l.iter().map(|&f| (at(i[b + f]), l)))
        .chain([B_PI, B_PIP0, B_PPI].iter().map(|&f| (at(i[b + f]), h * n))).chain([B_VI, B_VIV, B_VVI].iter().map(|&f| (at(i[b + f]), l * n)))
        .filter(|&(_, len)| len > 0).collect();
    regions.sort_unstable();
    if regions.windows(2).any(|pair| pair[0].0 + pair[0].1 > pair[1].0) {
        return false;
    }
    let (Some(groups), Some(n_groups)) = (field(B_GROUPS), field(B_NGROUPS)) else { return false };
    for g in 0..n_groups.max(0) as usize {
        let at_g = groups as usize + g * GROUP_REC;
        let Some(rec) = i.get(at_g..at_g + GROUP_REC) else { return false };
        let (w, count, hs, ls, a, bk) = (rec[G_W], rec[G_COUNT], rec[G_H], rec[G_L], rec[G_A], rec[G_B]);
        if w < 1 || count < 0 || hs < 0 || ls < 0 || a < 0 || bk < 0 {
            return false;
        }
        let (w, count) = (w as usize, count as usize);
        let (Some(h_first), Some(l_first)) = (i.get(hs as usize..hs as usize + count), i.get(ls as usize..ls as usize + count)) else { return false };
        if h_first.iter().any(|&x| x < 0 || x as usize + w > h) || l_first.iter().any(|&x| x < 0 || x as usize + w > l)
            || a as usize + count * w * w > nd || bk as usize + count * w * w > nd {
            return false;
        }
    }
    true
}

/// The bore's numbers: doubles, as OpenWInD's, or singles (research/OPENWIND_REALTIME_PLAN.md, stage 4: twice the lanes a
/// vector, half the memory), its no-flow pressures doubles either way, where its connectors read them.
pub trait Real: Copy + Default + std::ops::Add<Output = Self> + std::ops::Sub<Output = Self> + std::ops::Mul<Output = Self>
    + std::ops::Neg<Output = Self> + std::ops::AddAssign {
    const TWO: Self;
    /// self * a + b, rounded once -- but in WebAssembly, which has no fused multiply-add, rounded twice: mul_add there is
    /// libm's fma in software, which made a page's player 11 to 43 times slower than this one natively (the studio page,
    /// 25 October 2026), held to the native within rounding (test/audio/openwind-wasm.test.mjs).
    fn fma(self, a: Self, b: Self) -> Self;
    fn of(x: f64) -> Self;
    fn wide(self) -> f64;
}

impl Real for f64 {
    const TWO: f64 = 2.0;
    #[cfg(not(target_arch = "wasm32"))]
    #[inline(always)]
    fn fma(self, a: f64, b: f64) -> f64 { self.mul_add(a, b) }
    #[cfg(target_arch = "wasm32")]
    #[inline(always)]
    fn fma(self, a: f64, b: f64) -> f64 { self * a + b }
    #[inline(always)]
    fn of(x: f64) -> f64 { x }
    #[inline(always)]
    fn wide(self) -> f64 { self }
}

impl Real for f32 {
    const TWO: f32 = 2.0;
    #[cfg(not(target_arch = "wasm32"))]
    #[inline(always)]
    fn fma(self, a: f32, b: f32) -> f32 { self.mul_add(a, b) }
    #[cfg(target_arch = "wasm32")]
    #[inline(always)]
    fn fma(self, a: f32, b: f32) -> f32 { self * a + b }
    #[inline(always)]
    fn of(x: f64) -> f32 { x as f32 }
    #[inline(always)]
    fn wide(self) -> f64 { self as f64 }
}

/// One block of the bore's pressure nodes through every loss variable: P_next = 2 P_nph - P, and P0_next; then each
/// Pi_next, summed through pi_to_p0 as it comes for the next P0_next and the next no-flow pressure (S); and of that
/// no-flow pressure, all but its velocities' -- each array its own slice (openwind_kernel_fast.c pressure_block, its
/// restrict pointers), what each node carries meanwhile held in registers.
#[allow(clippy::too_many_arguments)]
#[inline(always)]
fn pressure_block<T: Real>(p: &mut [T; BLOCK], p0: &mut [T; BLOCK], pnf: &mut [f64; BLOCK], pi: &mut [T], s: &mut [T; BLOCK],
                           pp0: &[T; BLOCK], p0p0: &[T; BLOCK], ppnf: &[T; BLOCK], p0pnf: &[T; BLOCK], m: &[T; BLOCK],
                           ppi: &[T], pip0: &[T]) {
    let half = pnf.map(T::of);
    let mut sx = [T::default(); BLOCK];
    let mut sum_pi = [T::default(); BLOCK];
    for j in 0..BLOCK {
        let next = T::TWO.fma(half[j], -p[j]);
        let sum = p[j] + next;
        let p0_next = sum.fma(pp0[j], p0p0[j].fma(p0[j], s[j]));
        sx[j] = sum - p0[j] - p0_next;
        p[j] = next;
        p0[j] = p0_next;
    }
    // (Each loss variable's block read whole before it is written, so that its lanes stay vectors throughout; and sx - 2 x
    // as written, no fused form needed: 2 x is exact.)
    for ((x, a), c) in pi.as_chunks_mut::<BLOCK>().0.iter_mut().zip(ppi.as_chunks::<BLOCK>().0).zip(pip0.as_chunks::<BLOCK>().0) {
        let (was, a, c) = (*x, *a, *c);
        let mut y = [T::default(); BLOCK];
        for j in 0..BLOCK {
            y[j] = a[j].fma(sx[j] - T::TWO * was[j], was[j]);
            sum_pi[j] = c[j].fma(y[j], sum_pi[j]);
        }
        *x = y;
    }
    for j in 0..BLOCK {
        s[j] = sum_pi[j];
        pnf[j] = ppnf[j].fma(p[j], p0pnf[j].fma(p0[j], m[j] * sum_pi[j])).wide();
    }
}

/// One block of the bore's velocity nodes through every loss variable: each Vi_next, summed through vi_to_v (T) for the
/// next V_next.
#[inline(always)]
fn velocity_block<T: Real>(vi: &mut [T], t: &mut [T; BLOCK], xv: &[T; BLOCK], vvi: &[T], viv: &[T]) {
    let mut sum_vi = [T::default(); BLOCK];
    for ((x, a), c) in vi.as_chunks_mut::<BLOCK>().0.iter_mut().zip(vvi.as_chunks::<BLOCK>().0).zip(viv.as_chunks::<BLOCK>().0) {
        let (was, a, c) = (*x, *a, *c);
        let mut y = [T::default(); BLOCK];
        for j in 0..BLOCK {
            y[j] = a[j].fma(xv[j] - T::TWO * was[j], was[j]);
            sum_vi[j] = c[j].fma(y[j], sum_vi[j]);
        }
        *x = y;
    }
    *t = sum_vi;
}

/// The bore's element groups, decoded: each group's width, its elements' count, where in `i` its elements' first pressure
/// and velocity nodes are listed, and where in `d` its two matrices' blocks are.
#[derive(Clone, Copy)]
struct Group {
    w: usize,
    count: usize,
    hs: usize,
    ls: usize,
    a: usize,
    b: usize,
}

/// The bore's ends (by their place among the ends) and its groups, read once from its record (bore_fits checked it). ->
/// None where an end is not among the ends.
fn bore_decoded(i: &[i64], b: usize, n_ends: usize) -> Option<(Vec<usize>, Vec<Group>)> {
    let listed = at(i[b + B_ENDS]);
    let ends = (0..at(i[b + B_NENDS])).map(|k| i.get(listed + k).and_then(|&e| usize::try_from(e).ok()).filter(|&e| e < n_ends))
        .collect::<Option<Vec<_>>>()?;
    let groups = (0..at(i[b + B_NGROUPS])).map(|g| {
        let rec = at(i[b + B_GROUPS]) + g * GROUP_REC;
        Group { w: at(i[rec + G_W]), count: at(i[rec + G_COUNT]), hs: at(i[rec + G_H]), ls: at(i[rec + G_L]), a: at(i[rec + G_A]), b: at(i[rec + G_B]) }
    }).collect();
    Some((ends, groups))
}

/// The bore's state, each step's and kept between calls, by its record's field.
const BORE_STATE: [usize; 8] = [B_P, B_V, B_P0, B_PI, B_VI, B_S, B_T, B_XV];
/// Its record's fields that are regions, all before its groups'.
const FIELDS: usize = B_GROUPS;
/// Its coefficients, read only.
const BORE_COEFFICIENTS: [usize; 10] = [B_PPNF, B_P0PNF, B_M, B_PP0, B_P0P0, B_PIP0, B_PPI, B_VV, B_VIV, B_VVI];

/// A region's length, by its field, for a bore of `h` pressure and `l` velocity nodes and `n` loss variables each.
fn region_length(field: usize, h: usize, l: usize, n: usize) -> usize {
    match field {
        B_PI | B_PIP0 | B_PPI => h * n,
        B_VI | B_VIV | B_VVI => l * n,
        B_V | B_T | B_VV | B_XV => l,
        _ => h,
    }
}

/// The bore's arrays where its loops read them: each region's first value, of doubles in `d` or singles in a mirror
/// (Mirror), by its record's field; each group's two matrices; its no-flow pressures always in `d`.
struct Bore<T> {
    h: usize,
    l: usize,
    n: usize,
    at: [*mut T; FIELDS],
    pnf: *mut f64,
    a: Vec<*const T>,
    b: Vec<*const T>,
}

impl Bore<f64> {
    /// The bore's arrays in `d` itself.
    unsafe fn in_d(i: &[i64], dp: *mut f64, b: usize, groups: &[Group]) -> Bore<f64> {
        let mut at_field = [std::ptr::null_mut(); FIELDS];
        for &f in BORE_STATE.iter().chain(&BORE_COEFFICIENTS) {
            at_field[f] = dp.add(at(i[b + f]));
        }
        Bore { h: at(i[b + B_H]), l: at(i[b + B_L]), n: at(i[b + B_N]), at: at_field, pnf: dp.add(at(i[b + B_PNF])),
               a: groups.iter().map(|g| dp.add(g.a) as *const f64).collect(), b: groups.iter().map(|g| dp.add(g.b) as *const f64).collect() }
    }
}

/// The bore's arrays in singles: its state copied in from `d` at each call's start and back at its end, its
/// coefficients copied in (each rounded to the nearest single); its no-flow pressures left in `d`.
struct Mirror {
    data: Vec<f32>,
    // (Each region: where in `d`, where in the mirror, its length, and whether it is state, copied back.)
    regions: Vec<(usize, usize, usize, bool)>,
    fields: [usize; FIELDS],
    groups: Vec<(usize, usize)>,
}

impl Mirror {
    fn of(i: &[i64], d: &[f64], b: usize, groups: &[Group]) -> Mirror {
        let (h, l, n) = (at(i[b + B_H]), at(i[b + B_L]), at(i[b + B_N]));
        let (mut regions, mut fields, mut groups_at, mut next) = (Vec::new(), [0; FIELDS], Vec::new(), 0);
        for (&f, state) in BORE_STATE.iter().map(|f| (f, true)).chain(BORE_COEFFICIENTS.iter().map(|f| (f, false))) {
            let len = region_length(f, h, l, n);
            regions.push((at(i[b + f]), next, len, state));
            fields[f] = next;
            next += len;
        }
        for g in groups {
            let len = g.count * g.w * g.w;
            regions.push((g.a, next, len, false));
            regions.push((g.b, next + len, len, false));
            groups_at.push((next, next + len));
            next += 2 * len;
        }
        let mut data = vec![0.0f32; next];
        for &(from, to, len, _) in &regions {
            for (m, &x) in data[to..to + len].iter_mut().zip(&d[from..from + len]) {
                *m = x as f32;
            }
        }
        Mirror { data, regions, fields, groups: groups_at }
    }

    /// Its state back into `d`.
    fn back(&self, d: &mut [f64]) {
        for &(to, from, len, state) in &self.regions {
            if state {
                for (x, &m) in d[to..to + len].iter_mut().zip(&self.data[from..from + len]) {
                    *x = m as f64;
                }
            }
        }
    }

    /// The bore's arrays in the mirror, its no-flow pressures in `d`.
    unsafe fn bore(&mut self, i: &[i64], dp: *mut f64, b: usize) -> Bore<f32> {
        let base = self.data.as_mut_ptr();
        let mut at_field = [std::ptr::null_mut(); FIELDS];
        for &f in BORE_STATE.iter().chain(&BORE_COEFFICIENTS) {
            at_field[f] = base.add(self.fields[f]);
        }
        Bore { h: at(i[b + B_H]), l: at(i[b + B_L]), n: at(i[b + B_N]), at: at_field, pnf: dp.add(at(i[b + B_PNF])),
               a: self.groups.iter().map(|&(a, _)| base.add(a) as *const f32).collect(),
               b: self.groups.iter().map(|&(_, b)| base.add(b) as *const f32).collect() }
    }
}

/// tpipe_lossy.py TemporalLossyPipe.one_step and _compute_next_p_no_flow, every lossy pipe at once (`bore` its arrays,
/// `bore_ends` and `groups` it decoded).
///
/// # Safety
/// `dp` addresses the body's doubles, which no one else touches meanwhile; the bore's regions lie within them, or its
/// mirror, and apart (bore_fits); its ends are among `ends` (bore_decoded), whose places lie within them (decoded).
unsafe fn lossy_pipes<T: Real>(i: &[i64], dp: *mut f64, bore: &Bore<T>, bore_ends: &[usize], groups: &[Group], ends: &[End]) {
    // (Each pipe's end pressures at the half step, from the flows its connectors have just set: accept_q_nph.)
    for &k in bore_ends {
        let e = ends.get_unchecked(k);
        *dp.add(e.pnf) -= *dp.add(e.alpha) * *dp.add(e.w);
    }
    bore_step(i, bore, groups);
}

/// The bore's nodes stepped, its ends' pressures at the half step already taken (lossy_pipes): the whole bore's, or one
/// part's of it on a thread of its own (parallel.rs), `i` then that part's own list of its elements' nodes.
///
/// # Safety
/// As lossy_pipes; each group's elements' nodes listed in `i` within the bore's.
#[inline(always)]
unsafe fn bore_step<T: Real>(i: &[i64], bore: &Bore<T>, groups: &[Group]) {
    use std::slice::{from_raw_parts, from_raw_parts_mut};
    let (h_n, l_n, n) = (bore.h, bore.l, bore.n);
    let mut_of = |f: usize| from_raw_parts_mut(bore.at[f], region_length(f, h_n, l_n, n));
    let of = |f: usize| from_raw_parts(bore.at[f] as *const T, region_length(f, h_n, l_n, n));
    let (p, v, p0, pi, vi, s, t, xv) = (mut_of(B_P), mut_of(B_V), mut_of(B_P0), mut_of(B_PI), mut_of(B_VI), mut_of(B_S), mut_of(B_T), mut_of(B_XV));
    let pnf = from_raw_parts_mut(bore.pnf, h_n);
    let (ppnf, p0pnf, m, pp0, p0p0, pip0, ppi) = (of(B_PPNF), of(B_P0PNF), of(B_M), of(B_PP0), of(B_P0P0), of(B_PIP0), of(B_PPI));
    let (vv, viv, vvi) = (of(B_VV), of(B_VIV), of(B_VVI));
    // (A block of nodes at `h`, and its loss variables: within their regions, their counts whole blocks -- bore_fits.)
    fn block<T>(x: &[T], h: usize) -> &[T; BLOCK] { unsafe { &*(x.as_ptr().add(h) as *const [T; BLOCK]) } }
    fn block_mut<T>(x: &mut [T], h: usize) -> &mut [T; BLOCK] { unsafe { &mut *(x.as_mut_ptr().add(h) as *mut [T; BLOCK]) } }
    for h in (0..h_n).step_by(BLOCK) {
        let losses = h * n..(h + BLOCK) * n;
        pressure_block(block_mut(p, h), block_mut(p0, h), block_mut(pnf, h), pi.get_unchecked_mut(losses.clone()), block_mut(s, h),
                       block(pp0, h), block(p0p0, h), block(ppnf, h), block(p0pnf, h), block(m, h), ppi.get_unchecked(losses.clone()),
                       pip0.get_unchecked(losses));
    }
    // V_next, element by element; then each Vi_next, summed through vi_to_v as it comes for the next V_next.
    for (g, &a) in groups.iter().zip(&bore.a) {
        let (w, count) = (g.w, g.count);
        let (hs, ls) = (i.get_unchecked(g.hs..g.hs + count), i.get_unchecked(g.ls..g.ls + count));
        let a = from_raw_parts(a, count * w * w);
        match w {
            2 => element_velocities::<T, 2>(hs, ls, a, p, v, xv, t, vv),
            3 => element_velocities::<T, 3>(hs, ls, a, p, v, xv, t, vv),
            4 => element_velocities::<T, 4>(hs, ls, a, p, v, xv, t, vv),
            5 => element_velocities::<T, 5>(hs, ls, a, p, v, xv, t, vv),
            _ => element_velocities_any(hs, ls, a, p, v, xv, t, vv, w),
        }
    }
    for l in (0..l_n).step_by(BLOCK) {
        let losses = l * n..(l + BLOCK) * n;
        velocity_block(vi.get_unchecked_mut(losses.clone()), block_mut(t, l), block(xv, l), vvi.get_unchecked(losses.clone()),
                       viv.get_unchecked(losses));
    }
    // The next no-flow pressure's velocities, element by element.
    for (g, &bk) in groups.iter().zip(&bore.b) {
        let (w, count) = (g.w, g.count);
        let (hs, ls) = (i.get_unchecked(g.hs..g.hs + count), i.get_unchecked(g.ls..g.ls + count));
        let bk = from_raw_parts(bk, count * w * w);
        match w {
            2 => element_pressures::<T, 2>(hs, ls, bk, v, pnf),
            3 => element_pressures::<T, 3>(hs, ls, bk, v, pnf),
            4 => element_pressures::<T, 4>(hs, ls, bk, v, pnf),
            5 => element_pressures::<T, 5>(hs, ls, bk, v, pnf),
            _ => element_pressures_any(hs, ls, bk, v, pnf, w),
        }
    }
}

/// A group's elements of width W: V_next, from its loss variables' sum (T), its own, and its element's pressures through
/// p_to_v; and V + V_next (xv) for its loss variables after.
///
/// # Safety
/// Each element's nodes within the bore (bore_fits).
#[allow(clippy::too_many_arguments)]
#[inline(always)]
unsafe fn element_velocities<T: Real, const W: usize>(hs: &[i64], ls: &[i64], a: &[T], p: &[T], v: &mut [T], xv: &mut [T], t: &[T], vv: &[T]) {
    let (p, v, xv, t, vv) = (p.as_ptr(), v.as_mut_ptr(), xv.as_mut_ptr(), t.as_ptr(), vv.as_ptr());
    for ((&h, &l), block) in hs.iter().zip(ls).zip(a.chunks_exact(W * W)) {
        let pressures = *(p.add(at(h)) as *const [T; W]);
        for r in 0..W {
            let node = at(l) + r;
            let mut next = (*vv.add(node)).fma(*v.add(node), *t.add(node));
            for c in 0..W {
                next = block[r * W + c].fma(pressures[c], next);
            }
            *xv.add(node) = *v.add(node) + next;
            *v.add(node) = next;
        }
    }
}

/// # Safety
/// As element_velocities.
#[allow(clippy::too_many_arguments)]
unsafe fn element_velocities_any<T: Real>(hs: &[i64], ls: &[i64], a: &[T], p: &[T], v: &mut [T], xv: &mut [T], t: &[T], vv: &[T], w: usize) {
    let (p, v, xv, t, vv) = (p.as_ptr(), v.as_mut_ptr(), xv.as_mut_ptr(), t.as_ptr(), vv.as_ptr());
    for ((&h, &l), block) in hs.iter().zip(ls).zip(a.chunks_exact(w * w)) {
        for r in 0..w {
            let node = at(l) + r;
            let mut next = (*vv.add(node)).fma(*v.add(node), *t.add(node));
            for c in 0..w {
                next = block[r * w + c].fma(*p.add(at(h) + c), next);
            }
            *xv.add(node) = *v.add(node) + next;
            *v.add(node) = next;
        }
    }
}

/// A group's elements of width W: the next no-flow pressure's velocities, through v_to_p_noflow (two elements' at the
/// pressure they share).
///
/// # Safety
/// As element_velocities.
#[inline(always)]
unsafe fn element_pressures<T: Real, const W: usize>(hs: &[i64], ls: &[i64], bk: &[T], v: &[T], pnf: &mut [f64]) {
    let (v, pnf) = (v.as_ptr(), pnf.as_mut_ptr());
    for ((&h, &l), block) in hs.iter().zip(ls).zip(bk.chunks_exact(W * W)) {
        let velocities = *(v.add(at(l)) as *const [T; W]);
        for c in 0..W {
            let mut sum = T::default();
            for r in 0..W {
                sum = block[c * W + r].fma(velocities[r], sum);
            }
            *pnf.add(at(h) + c) += sum.wide();
        }
    }
}

/// # Safety
/// As element_velocities.
unsafe fn element_pressures_any<T: Real>(hs: &[i64], ls: &[i64], bk: &[T], v: &[T], pnf: &mut [f64], w: usize) {
    let (v, pnf) = (v.as_ptr(), pnf.as_mut_ptr());
    for ((&h, &l), block) in hs.iter().zip(ls).zip(bk.chunks_exact(w * w)) {
        for c in 0..w {
            let mut sum = T::default();
            for r in 0..w {
                sum = block[c * w + r].fma(*v.add(at(l) + r), sum);
            }
            *pnf.add(at(h) + c) += sum.wide();
        }
    }
}

/// tpipe.py TemporalPipe.one_step (`q` its record): A is dtinvML2B, B dtinvMBt, mbtv dtinvMBtV.
fn lossless_pipe(i: &[i64], d: &mut [f64], q: usize) {
    let (nh1, nl2) = (at(i[q + L_NH1]), at(i[q + L_NL2]));
    let (minus, plus) = (end_of(i, i[q + L_MINUS]), end_of(i, i[q + L_PLUS]));
    let (p, v, mbtv) = (at(i[q + L_P]), at(i[q + L_V]), at(i[q + L_MBTV]));
    for j in 0..nh1 {
        d[p + j] -= d[mbtv + j];
    }
    d[p] += -2.0 * d[at(i[minus + E_ALPHA])] * d[at(i[minus + E_W])];
    d[p + nh1 - 1] += -2.0 * d[at(i[plus + E_ALPHA])] * d[at(i[plus + E_W])];
    csr_matvec(nl2, i, at(i[q + L_A_PTR]), at(i[q + L_A_IDX]), d, at(i[q + L_A_DAT]), p, v);
    for j in 0..nh1 {
        d[mbtv + j] = 0.0;
    }
    csr_matvec(nh1, i, at(i[q + L_B_PTR]), at(i[q + L_B_IDX]), d, at(i[q + L_B_DAT]), v, mbtv);
}

#[inline(always)]
fn positive_part(y: f64) -> f64 {
    if y > 0.0 { y } else { 0.0 * y }
}

#[inline(always)]
fn abs_negative_part(y: f64) -> f64 {
    if y < 0.0 { -y } else { -y * 0.0 }
}

/// tjunction.py TemporalJunctionSwitch._precompute_constants at its opening factor, its discontinuity's mass none (M_J 0,
/// as OpenWInD's time domain takes a switch): its transmission T = [1, -phi, phi - 1], each end's m = dt / (2 alpha), and
/// the influence -dt/2 (dt^2/4 T diag(1/m) T')^-1 T -- in numpy's order, so that it is OpenWInD's within rounding.
fn switch_coefficients(s: &mut [f64], alpha: [f64; 3]) {
    let (phi, dt) = (s[S_PHI], s[S_DT]);
    let t = [1.0, -phi, phi - 1.0];
    let mut a_g = 0.0;
    for (k, &a) in alpha.iter().enumerate() {
        a_g += t[k] * (1.0 / (dt / (2.0 * a))) * t[k];
    }
    let inv = 1.0 / (0.0 + dt * dt / 4.0 * a_g);
    let c = -dt / 2.0 * inv;
    for k in 0..3 {
        s[S_INFL + k] = c * t[k];
    }
}

/// numpy's sign: a zero of either sign 0, NaN itself.
#[inline(always)]
fn sign(x: f64) -> f64 {
    if x > 0.0 { 1.0 } else if x < 0.0 { -1.0 } else if x == 0.0 { 0.0 } else { x }
}

/// tradiation.py TemporalRadiation._precompute_coefficients, for its opening factor (RadiationPade
/// compute_temporal_coefs: alpha proportional to it, beta to its square).
fn radiation_coefficients(r: &mut [f64]) {
    let phi = r[R_PHI];
    let (alpha, beta) = (r[R_A] * phi, r[R_BETA] * (phi * phi));
    let (m_end, half_dt, zplus) = (r[R_MEND], r[R_HALFDT], r[R_ZPLUS]);
    let m_end_rad = m_end + half_dt * beta / zplus;
    let rt_alpha = alpha.sqrt();
    let z_dt = zplus + (half_dt * half_dt) * alpha / m_end_rad;
    r[R_STEP] = zplus / z_dt;
    r[R_INFL] = -half_dt * rt_alpha / z_dt * m_end / m_end_rad;
    r[R_ZTOF] = rt_alpha * m_end / m_end_rad;
    r[R_PTOF] = -beta / zplus * m_end / m_end_rad;
}

const NONE: usize = usize::MAX;

/// An end, decoded: where in `d` its no-flow pressure is (less half its `half` where it has one), its alpha and its flow.
#[derive(Clone, Copy)]
struct End {
    pnf: usize,
    half: usize,
    alpha: usize,
    w: usize,
}

/// A connector, decoded: its kind, its ends (by their place among the ends), its block in `d`, its first control column
/// and where it records (NONE: none), and a flute's memory.
#[derive(Clone, Copy)]
struct Conn {
    kind: i64,
    e: [usize; 4],
    blk: usize,
    u: usize,
    rec: usize,
    mem: usize,
    memlen: i64,
    memcap: i64,
}

/// Each kind's block in `d`, the ends it joins, and the control columns it reads.
fn shape_of(kind: i64) -> Option<(usize, usize, usize)> {
    Some(match kind {
        T_SIMPLE => (1, 2, 0),
        T_TJOINT => (12, 3, 0),
        T_DISCONTINUITY => (4, 2, 0),
        T_RADIATION => (R_KAPPA + 1, 1, 1),
        T_REED => (Q_PSI + 1, 1, 9),
        T_LIPS => (Q_MODEL2 + 1, 1, U_COUPLING + 1),
        T_SWITCH => (S_INFL + 3, 3, 1),
        T_CROSS => (24, 4, 0),
        T_FLUTE => (F_LASTETA + 1, 1, 12),
        _ => return None,
    })
}

/// The ends, connectors and outputs read once from the header, each place in `d` checked: what lets the steps read without
/// a check at each value. -> None where any lies outside.
#[allow(clippy::type_complexity)]
fn decoded(i: &[i64], nd: usize, cols: usize) -> Option<(Vec<End>, Vec<Conn>, Vec<(usize, Vec<usize>)>)> {
    let place = |x: i64| if x >= 0 && (x as usize) < nd { Some(x as usize) } else { None };
    let n_ends = usize::try_from(i[4]).ok()?;
    let mut ends = Vec::with_capacity(n_ends);
    for k in 0..n_ends {
        let e = i.get(at(i[H_ENDS]) + k * END_REC..at(i[H_ENDS]) + (k + 1) * END_REC)?;
        ends.push(End { pnf: place(e[E_PNF])?, half: if e[E_HALF] < 0 { NONE } else { place(e[E_HALF])? }, alpha: place(e[E_ALPHA])?, w: place(e[E_W])? });
    }
    let mut conns = Vec::new();
    for c in 0..usize::try_from(i[H_NCONNS]).ok()? {
        let k = i.get(at(i[H_CONNS]) + c * CONN_REC..at(i[H_CONNS]) + (c + 1) * CONN_REC)?;
        let (size, joined, controls) = shape_of(k[C_TYPE])?;
        let blk = place(k[C_D])?;
        if blk + size > nd {
            return None;
        }
        let mut e = [NONE; 4];
        for (j, slot) in e.iter_mut().enumerate().take(joined) {
            let end = usize::try_from(k[if j < 3 { C_E1 + j } else { C_E4 }]).ok()?;
            if end >= ends.len() {
                return None;
            }
            *slot = end;
        }
        let u = if k[C_U] < 0 { NONE } else { k[C_U] as usize };
        // (A radiation's opening and a valve's are a column where the fingering moves them, else held as laid out.)
        if controls > 0 && u == NONE && !matches!(k[C_TYPE], T_RADIATION | T_SWITCH) || u != NONE && u + controls > cols {
            return None;
        }
        let rec = if k[C_REC] < 0 { NONE } else { place(k[C_REC])? };
        if rec != NONE && rec + 2 > nd {
            return None;
        }
        let (mem, memlen, memcap) = if k[C_TYPE] == T_FLUTE {
            let mem = place(k[C_MEM])?;
            if k[C_MEMCAP] < 1 || k[C_MEMLEN] < 0 || mem + 2 * k[C_MEMCAP] as usize > nd {
                return None;
            }
            (mem, k[C_MEMLEN], k[C_MEMCAP])
        } else {
            (NONE, 0, 0)
        };
        conns.push(Conn { kind: k[C_TYPE], e, blk, u, rec, mem, memlen, memcap });
    }
    let mut outs = Vec::new();
    let mut o = at(i[H_OUTS]);
    for _ in 0..usize::try_from(i[H_NOUTS]).ok()? {
        let (kind, terms) = (*i.get(o)?, usize::try_from(*i.get(o + 1)?).ok()?);
        if !(0..=1).contains(&kind) || terms == 0 {
            return None;
        }
        let mut at_terms = Vec::with_capacity(terms);
        for t in 0..terms {
            at_terms.push(place(*i.get(o + 2 + t)? + kind)?);
        }
        outs.push((kind as usize, at_terms));
        o += 2 + terms;
    }
    Some((ends, conns, outs))
}

/// Steps `steps`, each its row of the header's control columns in `u`, its row of the header's outputs written to `y`.
/// -> 0, or where and why it stopped: -(1 + the step) * 8 - the reason (1 a flute's jet at rest, 2 its delay under two
/// steps, 3 its memory too short for its delay, 4 its dipole's sources past its delay); -1 where the body's places lie
/// outside its arrays.
pub fn steps(i: &mut [i64], d: &mut [f64], u: &[f64], y: &mut [f64], steps: usize) -> i64 {
    stepped(i, d, u, y, steps, false)
}

/// The same, its bore stepped in singles (Mirror): its connectors, its ends and its no-flow pressures in doubles still.
pub fn steps_single(i: &mut [i64], d: &mut [f64], u: &[f64], y: &mut [f64], steps: usize) -> i64 {
    stepped(i, d, u, y, steps, true)
}

fn stepped(i: &mut [i64], d: &mut [f64], u: &[f64], y: &mut [f64], steps: usize, single: bool) -> i64 {
    let Some(mut body) = Decoded::of(i, d.len()) else { return -1 };
    if u.len() < steps * body.cols || y.len() < steps * body.nouts {
        return -1;
    }
    let mut mirror = if single { body.bore.map(|b| Mirror::of(i, d, b, &body.groups)) } else { None };
    let status = unsafe { body.run(i, d, mirror.as_mut(), None, u, y, steps) };
    if let Some(m) = mirror {
        m.back(d);
    }
    // (A flute's memory as far as it has filled, kept in its record for the next call.)
    for (c, conn) in body.conns.iter().enumerate() {
        if conn.kind == T_FLUTE {
            i[at(i[H_CONNS]) + c * CONN_REC + C_MEMLEN] = conn.memlen;
        }
    }
    status
}

/// A body decoded once: its header's counts, its ends, connectors and outputs, its bore's place, ends and groups --
/// every place checked (decoded, bore_fits), so that its steps read and write without a check at each.
struct Decoded {
    npipes: usize,
    nouts: usize,
    cols: usize,
    pipes: usize,
    bore: Option<usize>,
    ends: Vec<End>,
    conns: Vec<Conn>,
    outs: Vec<(usize, Vec<usize>)>,
    bore_ends: Vec<usize>,
    groups: Vec<Group>,
}

impl Decoded {
    fn of(i: &[i64], nd: usize) -> Option<Decoded> {
        if i.len() < H_UCOLS + 1 {
            return None;
        }
        let (npipes, nouts, cols) = (usize::try_from(i[H_NPIPES]).ok()?, usize::try_from(i[H_NOUTS]).ok()?, usize::try_from(i[H_UCOLS]).ok()?);
        let bore = if i[H_BORE] >= 0 { Some(at(i[H_BORE])) } else { None };
        if bore.is_some_and(|b| !bore_fits(i, nd, b)) {
            return None;
        }
        let (ends, conns, outs) = decoded(i, nd, cols)?;
        let (bore_ends, groups) = bore.map_or(Some((vec![], vec![])), |b| bore_decoded(i, b, ends.len()))?;
        Some(Decoded { npipes, nouts, cols, pipes: at(i[H_PIPES]), bore, ends, conns, outs, bore_ends, groups })
    }

    /// `steps` steps on the body `i`, `d` this was decoded from, its bore in `mirror` where it is stepped in singles.
    ///
    /// # Safety
    /// `i` and `d` are the arrays this was decoded from, unchanged in their layout since, and `mirror` (where given) the
    /// mirror of their bore; `u` and `y` hold `steps` rows.
    unsafe fn run(&mut self, i: &[i64], d: &mut [f64], mirror: Option<&mut Mirror>, tract: Option<&mut Tract>, u: &[f64], y: &mut [f64],
                  steps: usize) -> i64 {
        let (dp, nd) = (d.as_mut_ptr(), d.len());
        let (cols, nouts, pipes, npipes) = (self.cols, self.nouts, self.pipes, self.npipes);
        let (bore_ends, groups) = (self.bore_ends.as_slice(), self.groups.as_slice());
        match (self.bore, mirror) {
            (Some(b), Some(m)) => {
                let view = m.bore(i, dp, b);
                step_all(i, dp, nd, u, y, steps, cols, nouts, Some((&view, bore_ends, groups)), pipes, npipes, &self.ends, &mut self.conns, &self.outs, tract)
            }
            (Some(b), None) => {
                let view = Bore::in_d(i, dp, b, groups);
                step_all(i, dp, nd, u, y, steps, cols, nouts, Some((&view, bore_ends, groups)), pipes, npipes, &self.ends, &mut self.conns, &self.outs, tract)
            }
            (None, _) => step_all::<f64>(i, dp, nd, u, y, steps, cols, nouts, None, pipes, npipes, &self.ends, &mut self.conns, &self.outs, tract),
        }
    }
}

/// A body played for as long as it is played (research/OPENWIND_REALTIME_PLAN.md, design 3): decoded once, its bore's
/// singles kept between blocks where it is stepped in singles, each block's controls a row a step -- the live host's
/// and, from stage 7, the renders'. Its arrays its own.
pub struct Player {
    i: Vec<i64>,
    d: Vec<f64>,
    body: Decoded,
    mirror: Option<Mirror>,
    /// Its player's vocal tract, upstream of its reed (tract.rs); none, a mouth's pressure alone.
    pub tract: Option<Tract>,
    // (Its bore's parts and the threads stepping them, where it is stepped on several cores: parallel.rs.)
    #[cfg(any(not(target_arch = "wasm32"), feature = "threads"))]
    crew: Option<parallel::Crews>,
    // (Its slide, where it has one: Player::slide_on.)
    slide: Option<Slide>,
}

/// A slide's pipe as laid out at its first position, and where its stretching is written (Player::stretch): its elements
/// (each its group and its place there; and in a crew, its part and where its two blocks begin in that part's data), their
/// two blocks one after the other as laid out, p_to_v's and v_to_p_noflow's; its ends, each where its alpha is and its
/// alpha as laid out; the connectors at its ends; the connectors' step; and the stretch it stands at.
struct Slide {
    elements: Vec<(usize, usize)>,
    placed: Vec<(usize, usize, usize)>,
    blocks: Vec<f64>,
    ends: Vec<(usize, f64)>,
    joins: Vec<Join>,
    dt: f64,
    s: f64,
    scaled: Vec<f64>,
}

/// A connector at a slide's end: its kind, its block, where its two ends' alphas are, its discontinuity's mass, and its
/// block's coefficients as laid out (a simple junction's one, a discontinuity's Step and Infl).
struct Join {
    kind: i64,
    blk: usize,
    alphas: [usize; 2],
    mass: f64,
    laid: [f64; 3],
}

impl Join {
    /// Its coefficients at its ends' alphas `a1`, `a2`, as OpenWInD computes them (tsimplejunction.py
    /// _precompute_coefficients; tjunction.py TemporalJunctionDiscontinuity._precompute_constants, in numpy's order).
    fn coefficients(&self, a1: f64, a2: f64, dt: f64) -> [f64; 3] {
        if self.kind == T_SIMPLE {
            return [1.0 / (a1 + a2), 0.0, 0.0];
        }
        let (m1, m2) = (dt / (2.0 * a1), dt / (2.0 * a2));
        let a_g = -(1.0 / m1) * -1.0 + (1.0 / m2) * 1.0;
        let inv = 1.0 / (self.mass + dt * dt / 4.0 * a_g);
        let c = -dt / 2.0 * inv;
        [inv * self.mass, c * -1.0, c * 1.0]
    }

    /// Its coefficients' count in its block (a discontinuity's gamma, after them, its state).
    fn width(&self) -> usize {
        if self.kind == T_SIMPLE { 1 } else { 3 }
    }
}

impl Player {
    /// A player of the laid-out body `i`, `d` (openwind_compiled.py Compiled's, saved by openwind_bodies.py), its bore in
    /// singles where `single`. -> None where its places lie outside its arrays.
    pub fn new(i: Vec<i64>, d: Vec<f64>, single: bool) -> Option<Player> {
        let body = Decoded::of(&i, d.len())?;
        let mirror = if single { body.bore.map(|b| Mirror::of(&i, &d, b, &body.groups)) } else { None };
        Some(Player { i, d, body, mirror, tract: None, #[cfg(any(not(target_arch = "wasm32"), feature = "threads"))] crew: None, slide: None })
    }

    /// Its slide (body.rs SlideHeader) taken up, at its first position: each place it names checked -- its elements among
    /// its bore's groups, its ends among the bore's ends, its connectors simple junctions or discontinuities at one of
    /// them -- and what it stretches kept as laid out. -> why not, where it is not this body's.
    pub fn slide_on(&mut self, header: &crate::body::SlideHeader) -> Result<(), String> {
        let groups = &self.body.groups;
        if header.elements.is_empty() || !(header.dt > 0.0 && header.length > 0.0 && header.most >= 0.0 && header.most.is_finite()) {
            return Err("no elements, or its step, length or reach not a length".into());
        }
        let mut blocks = Vec::new();
        for &[g, e] in &header.elements {
            let Some(group) = groups.get(g).filter(|group| e < group.count) else { return Err(format!("no element {e} of group {g}")) };
            let size = group.w * group.w;
            blocks.extend_from_slice(&self.d[group.a + e * size..group.a + (e + 1) * size]);
            blocks.extend_from_slice(&self.d[group.b + e * size..group.b + (e + 1) * size]);
        }
        if header.ends[0] == header.ends[1] || !header.ends.iter().all(|k| self.body.bore_ends.contains(k)) {
            return Err(format!("its ends {:?} are not two of its bore's", header.ends))
        }
        let ends = header.ends.iter().map(|&k| (self.body.ends[k].alpha, self.d[self.body.ends[k].alpha])).collect();
        let mut joins = Vec::new();
        for join in &header.joins {
            let Some(conn) = self.body.conns.get(join.conn) else { return Err(format!("no connector {}", join.conn)) };
            if !matches!(conn.kind, T_SIMPLE | T_DISCONTINUITY) || !conn.e[..2].iter().any(|k| header.ends.contains(k)) || !(join.mass >= 0.0) {
                return Err(format!("connector {} is not a simple junction or a discontinuity at its ends", join.conn));
            }
            let laid = [self.d[conn.blk], if conn.kind == T_SIMPLE { 0.0 } else { self.d[conn.blk + 1] }, if conn.kind == T_SIMPLE { 0.0 } else { self.d[conn.blk + 2] }];
            joins.push(Join { kind: conn.kind, blk: conn.blk, alphas: [self.body.ends[conn.e[0]].alpha, self.body.ends[conn.e[1]].alpha], mass: join.mass, laid });
        }
        let elements: Vec<(usize, usize)> = header.elements.iter().map(|&[g, e]| (g, e)).collect();
        #[allow(unused_mut)]
        let mut placed = Vec::new();
        #[cfg(any(not(target_arch = "wasm32"), feature = "threads"))]
        if let Some(crew) = &self.crew {
            for &(g, e) in &elements {
                placed.push(crew.element_at(g, e).ok_or_else(|| format!("element {e} of group {g} in none of its parts"))?);
            }
        }
        let scaled = vec![0.0; blocks.len()];
        self.slide = Some(Slide { elements, placed, blocks, ends, joins, dt: header.dt, s: 1.0, scaled });
        Ok(())
    }

    /// Its slide's pipe stretched to `s` times its length at first position (its slide drawn out (s - 1) of it): each of
    /// its elements' masses and losses s times theirs, so its two blocks (p_to_v and v_to_p_noflow) and its ends' alphas
    /// 1/s times theirs, every ratio of them -- the rest of its coefficients -- as they were, and the connectors at its ends
    /// computed again from the alphas (claude-scratch/dials/slide/coefficients.py: OpenWInD's own pipe meshed in as many
    /// elements at that length, within 1e-15). At 1, its laid-out values themselves. Nothing without a slide.
    pub fn stretch(&mut self, s: f64) {
        let Some(slide) = self.slide.as_mut() else { return };
        if s == slide.s || !(s > 0.0 && s.is_finite()) {
            return;
        }
        slide.s = s;
        let laid = s == 1.0;
        let inv = 1.0 / s;
        for (x, &b) in slide.scaled.iter_mut().zip(&slide.blocks) {
            *x = if laid { b } else { b * inv };
        }
        let groups = &self.body.groups;
        let mut at = 0;
        for (k, &(g, e)) in slide.elements.iter().enumerate() {
            let group = groups[g];
            let size = group.w * group.w;
            let (a, b) = (&slide.scaled[at..at + size], &slide.scaled[at + size..at + 2 * size]);
            self.d[group.a + e * size..group.a + (e + 1) * size].copy_from_slice(a);
            self.d[group.b + e * size..group.b + (e + 1) * size].copy_from_slice(b);
            if let Some(m) = self.mirror.as_mut() {
                let (ma, mb) = m.groups[g];
                for (x, &v) in m.data[ma + e * size..ma + (e + 1) * size].iter_mut().zip(a) {
                    *x = v as f32;
                }
                for (x, &v) in m.data[mb + e * size..mb + (e + 1) * size].iter_mut().zip(b) {
                    *x = v as f32;
                }
            }
            #[cfg(any(not(target_arch = "wasm32"), feature = "threads"))]
            if let (Some(crew), Some(&(part, pa, pb))) = (self.crew.as_mut(), slide.placed.get(k)) {
                // (Between its steps: no worker steps meanwhile -- each is waited for before Crew::run returns.)
                unsafe {
                    crew.put(part, pa, a);
                    crew.put(part, pb, b);
                }
            }
            #[cfg(all(target_arch = "wasm32", not(feature = "threads")))]
            let _ = k;
            at += 2 * size;
        }
        let mut put = |d: &mut [f64], place: usize, value: f64| {
            d[place] = value;
            #[cfg(any(not(target_arch = "wasm32"), feature = "threads"))]
            if let Some(crew) = self.crew.as_mut() {
                unsafe { crew.put_d(place, value) };
            }
        };
        for &(place, alpha) in &slide.ends {
            put(&mut self.d, place, if laid { alpha } else { alpha * inv });
        }
        for join in &slide.joins {
            let values = if laid { join.laid } else { join.coefficients(self.d[join.alphas[0]], self.d[join.alphas[1]], slide.dt) };
            for (c, &v) in values.iter().enumerate().take(join.width()) {
                put(&mut self.d, join.blk + c, v);
            }
        }
    }

    /// The stretch its slide stands at: 1 at its first position, or without a slide.
    pub fn stretched(&self) -> f64 {
        self.slide.as_ref().map_or(1.0, |s| s.s)
    }

    /// The same, stepped on `threads` cores (parallel.rs): its bore split by whole pipes among them, bit for bit as on
    /// one -- for a body one core steps slower than it sounds. On one where its bore does not split (no bore, too few
    /// pipes), where `threads` is 1, or in a page's WebAssembly built without threads.
    pub fn with_threads(i: Vec<i64>, d: Vec<f64>, single: bool, threads: usize) -> Option<Player> {
        #[allow(unused_mut)]
        let mut player = Player::new(i, d, single)?;
        #[cfg(any(not(target_arch = "wasm32"), feature = "threads"))]
        if threads > 1 {
            player.crew = parallel::Crews::of(&player.i, &player.d, &player.body, single, threads);
            // (Its singles the parts' own.)
            if player.crew.is_some() {
                player.mirror = None;
            }
        }
        #[cfg(all(target_arch = "wasm32", not(feature = "threads")))]
        let _ = threads;
        Some(player)
    }

    /// The cores it is stepped on.
    pub fn threads(&self) -> usize {
        #[cfg(any(not(target_arch = "wasm32"), feature = "threads"))]
        if let Some(crew) = &self.crew {
            return crew.threads();
        }
        1
    }

    /// Its control columns, and its outputs, a step.
    pub fn columns(&self) -> (usize, usize) {
        (self.body.cols, self.body.nouts)
    }

    /// `steps` more steps, each its row of controls in `u`, its outputs a row of `y`. -> as `steps` (above); -1 where `u`
    /// or `y` holds too few rows.
    pub fn steps(&mut self, u: &[f64], y: &mut [f64], steps: usize) -> i64 {
        if u.len() < steps * self.body.cols || y.len() < steps * self.body.nouts {
            return -1;
        }
        #[cfg(any(not(target_arch = "wasm32"), feature = "threads"))]
        if let Some(crew) = self.crew.as_mut() {
            return unsafe { crew.run(&self.i, &mut self.d, &mut self.body, self.tract.as_mut(), u, y, steps) };
        }
        unsafe { self.body.run(&self.i, &mut self.d, self.mirror.as_mut(), self.tract.as_mut(), u, y, steps) }
    }
}

#[inline(always)]
unsafe fn p_no_flow_at(dp: *const f64, e: &End) -> f64 {
    if e.half == NONE { *dp.add(e.pnf) } else { *dp.add(e.pnf) - *dp.add(e.half) / 2.0 }
}

#[inline(always)]
unsafe fn q_nph_at(dp: *const f64, e: &End) -> f64 {
    p_no_flow_at(dp, e) - *dp.add(e.alpha) * *dp.add(e.w)
}

/// A connector's step (`conn` it, `row` its step's controls, `tract` its player's where it is a reed's, `s` the step):
/// its ends' no-flow pressures read, their flows set, its own block stepped with them. -> 0, or where and why it stopped
/// (steps). Each connector reads and writes only its own ends and block, so that the connectors may be stepped in any
/// order, on any thread (parallel.rs).
///
/// # Safety
/// As step_all.
#[inline(always)]
unsafe fn connect(conn: &mut Conn, ends: &[End], dp: *mut f64, row: *const f64, mut tract: Option<&mut Tract>, s: usize) -> i64 {
    macro_rules! d {
        ($k:expr) => { *dp.add($k) };
    }
    let blk = conn.blk;
    let e1 = ends.get_unchecked(conn.e[0]);
    match conn.kind {
        T_SIMPLE => {
            let e2 = ends.get_unchecked(conn.e[1]);
            let flow = d!(blk) * (p_no_flow_at(dp, e2) - p_no_flow_at(dp, e1));
            d!(e1.w) = -flow;
            d!(e2.w) = flow;
        }
        T_TJOINT => {
            // d: Step (2x2), Infl (2x3), gamma (2)
            let (e2, e3) = (ends.get_unchecked(conn.e[1]), ends.get_unchecked(conn.e[2]));
            let pc = [p_no_flow_at(dp, e1), p_no_flow_at(dp, e2), p_no_flow_at(dp, e3)];
            let mut gb = [0.0f64; 2];
            for (r, g) in gb.iter_mut().enumerate() {
                let a = d!(blk + 2 * r) * d!(blk + 10) + d!(blk + 2 * r + 1) * d!(blk + 11);
                let b = d!(blk + 4 + 3 * r) * pc[0] + d!(blk + 4 + 3 * r + 1) * pc[1] + d!(blk + 4 + 3 * r + 2) * pc[2];
                *g = a + b;
            }
            d!(blk + 10) = 2.0 * gb[0] - d!(blk + 10);
            d!(blk + 11) = 2.0 * gb[1] - d!(blk + 11);
            d!(e1.w) = -gb[0];
            d!(e2.w) = -gb[1];
            d!(e3.w) = gb[0] + gb[1];
        }
        T_CROSS => {
            // d: Step (3x3), Infl (3x4), gamma (3) -- its ends the bore in, the bore out, the upstream hole and the
            // downstream one; its variables the upstream joint's flow on the bore in, the flow through the slice between
            // the holes, the downstream joint's on the bore out; each end's flow -T^t gamma_b (openwind_bodies.py
            // TemporalCross, T_CROSS).
            let (e2, e3, e4) = (ends.get_unchecked(conn.e[1]), ends.get_unchecked(conn.e[2]), ends.get_unchecked(conn.e[3]));
            let pc = [p_no_flow_at(dp, e1), p_no_flow_at(dp, e2), p_no_flow_at(dp, e3), p_no_flow_at(dp, e4)];
            let mut gb = [0.0f64; 3];
            for (r, g) in gb.iter_mut().enumerate() {
                let a = d!(blk + 3 * r) * d!(blk + 21) + d!(blk + 3 * r + 1) * d!(blk + 22) + d!(blk + 3 * r + 2) * d!(blk + 23);
                let b = d!(blk + 9 + 4 * r) * pc[0] + d!(blk + 9 + 4 * r + 1) * pc[1] + d!(blk + 9 + 4 * r + 2) * pc[2]
                    + d!(blk + 9 + 4 * r + 3) * pc[3];
                *g = a + b;
            }
            for (r, g) in gb.iter().enumerate() {
                d!(blk + 21 + r) = 2.0 * g - d!(blk + 21 + r);
            }
            d!(e1.w) = -gb[0];
            d!(e2.w) = -gb[2];
            d!(e3.w) = gb[0] + gb[1];
            d!(e4.w) = gb[2] - gb[1];
        }
        T_DISCONTINUITY => {
            // d: Step (1), Infl (1x2), gamma (1)
            let e2 = ends.get_unchecked(conn.e[1]);
            let gb = d!(blk) * d!(blk + 3) + (d!(blk + 1) * p_no_flow_at(dp, e1) + d!(blk + 2) * p_no_flow_at(dp, e2));
            d!(blk + 3) = 2.0 * gb - d!(blk + 3);
            d!(e1.w) = gb;
            d!(e2.w) = -gb;
        }
        T_SWITCH => {
            // d: its opening, dt, Infl (3) -- its gamma moved by nothing of its own (Step, M_J's, 0): gamma_b = Infl . P,
            // each end's flow -T gamma_b. Its opening taken from the row where it moved, as set_opening_factor takes it.
            let (e2, e3) = (ends.get_unchecked(conn.e[1]), ends.get_unchecked(conn.e[2]));
            if conn.u != NONE {
                let phi = *row.add(conn.u);
                if !((phi - d!(blk + S_PHI)).abs() < 1e-5) {
                    d!(blk + S_PHI) = phi;
                    switch_coefficients(std::slice::from_raw_parts_mut(dp.add(blk), S_INFL + 3), [d!(e1.alpha), d!(e2.alpha), d!(e3.alpha)]);
                }
            }
            let gb = d!(blk + S_INFL) * p_no_flow_at(dp, e1) + d!(blk + S_INFL + 1) * p_no_flow_at(dp, e2) + d!(blk + S_INFL + 2) * p_no_flow_at(dp, e3);
            let phi = d!(blk + S_PHI);
            d!(e1.w) = -gb;
            d!(e2.w) = phi * gb;
            d!(e3.w) = -(phi - 1.0) * gb;
        }
        T_RADIATION => {
            if conn.u != NONE {
                let phi = *row.add(conn.u);
                if !((phi - d!(blk + R_PHI)).abs() < 1e-5) {
                    d!(blk + R_PHI) = phi;
                    radiation_coefficients(std::slice::from_raw_parts_mut(dp.add(blk), R_KAPPA + 1));
                }
            }
            let pc = p_no_flow_at(dp, e1);
            let zeta = d!(blk + R_ZETA);
            if d!(blk + R_KAPPA) > 0.0 {
                // (Its edge's jet loss in series with its radiation, p = rho C v|v| (openwind_worker.py
                // edge_losses): its flow out w by its stable root; its radiation then driven by what the loss
                // leaves.)
                let phi = d!(blk + R_PHI);
                let (alpha, beta) = (d!(blk + R_A) * phi, d!(blk + R_BETA) * (phi * phi));
                let (half_dt, zplus) = (d!(blk + R_HALFDT), d!(blk + R_ZPLUS));
                let rt_alpha = alpha.sqrt();
                let kk = (beta + half_dt * alpha) / zplus;
                let drive = -rt_alpha * zeta + kk * pc;
                let aa = 1.0 + kk * d!(e1.alpha);
                let bb = kk * d!(blk + R_KAPPA);
                let w = 2.0 * drive / (aa + (aa * aa + 4.0 * bb * drive.abs()).sqrt());
                let pr = if kk > 0.0 { (w + rt_alpha * zeta) / kk } else { 0.0 };
                let zeta_b = zeta - half_dt * rt_alpha / zplus * pr;
                d!(blk + R_ZETA) = 2.0 * zeta_b - zeta;
                d!(e1.w) = w;
            } else {
                let zeta_b = d!(blk + R_STEP) * zeta + d!(blk + R_INFL) * pc;
                d!(blk + R_ZETA) = 2.0 * zeta_b - zeta;
                d!(e1.w) = -(d!(blk + R_ZTOF) * zeta_b + d!(blk + R_PTOF) * pc);
            }
            if conn.rec != NONE {
                d!(conn.rec) = d!(e1.w) * d!(blk + R_FLOWSCALE);
                d!(conn.rec + 1) = q_nph_at(dp, e1) * d!(blk + R_PRESSSCALE);
            }
        }
        T_REED | T_LIPS => {
            // u: gamma, zeta, kappa, Qr, omegar, Kc, alpha_c, epsilon, Pclosed; lips' then ratio, Q2, coupling
            let q = row.add(conn.u);
            let (mut gamma, zeta, kappa, qr, omegar, kc, alpha_c, epsilon, pclosed) =
                (*q, *q.add(1), *q.add(2), *q.add(3), *q.add(4), *q.add(5), *q.add(6), *q.add(7), *q.add(8));
            // (The mouth's pressure less its tract's answer to the flow a step before: tract.rs.)
            if let Some(t) = tract.as_deref() {
                gamma -= t.pressure() / pclosed;
            }
            let theta = d!(blk + Q_THETA);
            let dt_scaled = omegar * d!(blk + Q_DT);
            let (last_y, this_y) = (d!(blk + Q_LASTY), d!(blk + Q_THISY));
            // (Its contact's variable kept to its stiffness: z brought to a new Kc at its y before it is
            // stepped -- openwind_kernel.c.)
            let mut prev_z = d!(blk + Q_PREVZ);
            if d!(blk + Q_LASTKC) > 0.0 && kc != d!(blk + Q_LASTKC) {
                let stored = prev_z * prev_z - d!(blk + Q_CONTACT);
                prev_z = (d!(blk + Q_CONTACT) + (if stored > 0.0 { stored } else { 0.0 }) * kc / d!(blk + Q_LASTKC)).sqrt();
            }
            d!(blk + Q_LASTKC) = kc;
            let p_scaling = pclosed / d!(blk + Q_SP);
            let flow_scaling = pclosed / d!(blk + Q_ZC) / d!(blk + Q_SF);
            let pnf = p_no_flow_at(dp, e1) / p_scaling;
            let a_lambda = d!(blk + Q_ZC) / (d!(e1.alpha) * d!(blk + Q_SIMP));
            let yn_minus = abs_negative_part(this_y);
            let contact = d!(blk + Q_CONTACT);
            // (Its contact's force, nothing while the reed is open.)
            let h_yn = if contact == 0.0 {
                if yn_minus == 0.0 && alpha_c > 1.0 { 0.0 } else { -0.5 * (2.0 * kc * (alpha_c + 1.0)).sqrt() * yn_minus.powf(alpha_c / 2.0 - 0.5) }
            } else if yn_minus == 0.0 && alpha_c > 0.0 {
                0.0
            } else {
                -kc * yn_minus.powf(alpha_c) / (contact + 2.0 * kc / (alpha_c + 1.0) * yn_minus.powf(alpha_c + 1.0)).sqrt()
            };
            let dt2 = dt_scaled * dt_scaled;
            // (In contact, critically damped by its contact's stiffness, none at a touch: it lands without bouncing.)
            let a_yn = 1.0 / (1.0 / dt2 + 1.0 / (2.0 * qr * dt_scaled)
                + (if yn_minus > 0.0 { 2.0 * (alpha_c * kc * yn_minus.powf(alpha_c - 1.0)).sqrt() / (2.0 * dt_scaled) } else { 0.0 })
                + theta + 0.25 * (h_yn * h_yn));
            let b1_y = 2.0 / dt2 + 2.0 * theta - 1.0;
            let b2_y = -1.0 * (2.0 / dt2 + 2.0 * theta);
            let b3_y = 1.0 - h_yn * prev_z;
            let b_yn = a_yn * (b1_y * this_y + b2_y * last_y + b3_y);
            // (Brass lips' inward mode, where they have one (openwind_kernel_fast.c T_LIPS): its own theta-scheme, from
            // rest at 0, its share of the flow the lips sweep and of their opening. A reed's step as it was.)
            let lips = conn.kind == T_LIPS;
            let (this_q, last_q, ratio, coupling) =
                if lips { (d!(blk + Q_THISQ), d!(blk + Q_LASTQ), *q.add(U_RATIO), *q.add(U_COUPLING)) } else { (0.0, 0.0, 0.0, 0.0) };
            let a_q = if lips { 1.0 / (1.0 / dt2 + ratio / (2.0 * *q.add(U_QFACTOR2) * dt_scaled) + theta * (ratio * ratio)) } else { 0.0 };
            let b_q = if lips {
                a_q * (this_q * (2.0 / dt2 - (ratio * ratio) * (1.0 - 2.0 * theta)) + last_q * (-2.0 / dt2 - 2.0 * theta * (ratio * ratio)))
            } else {
                0.0
            };
            let an = if lips {
                a_lambda + (a_yn + d!(blk + Q_SHARE) * coupling * a_q) * kappa / (2.0 * dt_scaled)
            } else {
                a_lambda + a_yn * kappa / (2.0 * dt_scaled)
            };
            // (Its slit's area as its opening leaves it: OpenWInD's, or a double reed's, the opening's power and a
            // leak -- openwind_worker.py reed_law.)
            let opened = positive_part(if lips { this_y + this_q } else { this_y });
            let (exponent, leak, psi) = (d!(blk + Q_EXPONENT), d!(blk + Q_LEAK), d!(blk + Q_PSI));
            let slit = (if exponent == 1.0 && leak == 0.0 { opened } else { opened.powf(exponent) + leak }) * zeta;
            // (And a double reed's channel's losses in series with its slit.)
            let bn = if psi == 0.0 { slit } else { slit / (1.0 + psi * slit * slit).sqrt() };
            let cn = if lips {
                a_lambda * (pnf - gamma) + (epsilon * b_yn + d!(blk + Q_MODEL2) * d!(blk + Q_SHARE) * b_q) * kappa / (2.0 * dt_scaled)
            } else {
                a_lambda * (pnf - gamma) + epsilon * b_yn * kappa / (2.0 * dt_scaled)
            };
            let discr = bn * bn + 4.0 * an * cn.abs();
            let root_poly = (-bn + discr.sqrt()) / (2.0 * an);
            let delta_p = -sign(cn) * (root_poly * root_poly);
            let delta_y = b_yn + epsilon * a_yn * delta_p;
            d!(e1.w) = a_lambda * (delta_p + pnf - gamma) * flow_scaling;
            // (Its end's flow out of the bore: the flow from the mouth its negative.)
            if let Some(t) = tract.as_deref_mut() {
                t.take(-d!(e1.w) * d!(blk + Q_FLOWSCALE));
            }
            d!(blk + Q_THISY) = delta_y + last_y;
            d!(blk + Q_LASTY) = this_y;
            d!(blk + Q_PREVZ) = 0.5 * h_yn * delta_y + prev_z;
            if lips {
                d!(blk + Q_THISQ) = b_q + d!(blk + Q_MODEL2) * coupling * a_q * delta_p + last_q;
                d!(blk + Q_LASTQ) = this_q;
            }
            if conn.rec != NONE {
                d!(conn.rec) = d!(e1.w) * d!(blk + Q_FLOWSCALE);
                d!(conn.rec + 1) = q_nph_at(dp, e1) * d!(blk + Q_PRESSSCALE);
            }
        }
        T_FLUTE => {
            // u: Uj, dUj, next_Uj, the jet's noise, its window's opening, its jet's parameters (Ascale, Gj, Gl, C,
            // y0), its presence, its dipole's span
            let q = row.add(conn.u);
            let (uj, d_uj) = (*q, *q.add(1));
            let mut next_uj = *q.add(2);
            if uj < 1e-8 {
                return -(1 + s as i64) * 8 - 1;
            }
            if next_uj < 1e-8 {
                next_uj = uj;
            }
            let (dt, prev_zeta, this_eta, last_eta) = (d!(blk + F_DT), d!(blk + F_PREVZETA), d!(blk + F_THISETA), d!(blk + F_LASTETA));
            let (ascale, gj, gl, cj, y0) = (*q.add(5), *q.add(6), *q.add(7), *q.add(8), *q.add(9));
            let p_scaling = (d!(blk + F_RHO) * d!(blk + F_CELERITY) * uj) / ascale / d!(blk + F_SP);
            let u_scaling = p_scaling / (d!(blk + F_ZC) / d!(blk + F_SIMP));
            let next_tau = cj / next_uj / d!(blk + F_STIME);
            // get_next_eta
            let n = conn.memlen;
            let big_n = (next_tau / dt).floor() as i64;
            let eps = next_tau / dt - big_n as f64;
            if big_n < 2 {
                return -(1 + s as i64) * 8 - 2;
            }
            let n_n = if n - big_n > 0 { n - big_n } else { 0 };
            let n_np1 = if n - big_n + 1 > 0 { n - big_n + 1 } else { 0 };
            // (Its memory a ring of memcap flows, so that a part plays on for as long as it is played: what it
            // reads written at most memcap steps ago, else it is too short for its jet's delay. A ring as long as
            // the run, as the renders lay it out, never wraps: OpenWInD's own memory.)
            let cap = conn.memcap;
            if n_n + cap < n {
                return -(1 + s as i64) * 8 - 3;
            }
            let mut next_eta = (1.0 - eps) * d!(conn.mem + at(n_np1 % cap)) + eps * d!(conn.mem + at(n_n % cap));
            let presence = *q.add(10);
            next_eta += *q.add(3) * presence;
            let big_gamma = (this_eta - y0).tanh();
            // (Its dipole's flow sources on the convected jet, q[11] their distance over twice its disturbance's
            // speed's share of U_j (m; 0 where its dipole is Verge's): its jet's flow split differenced at t + s
            // and t - s, ahead its delay line as next_eta reads it with next_eta's turbulence, behind its own
            // places -- where s is under a step, OpenWInD's own centred difference (openwind_worker.py
            // jet_dipole). Its places a ring of memcap after its flows, at each step's place.)
            let place = conn.mem + at(cap);
            d!(place + at((n + 1) % cap)) = next_eta;
            let span = *q.add(11) / uj / d!(blk + F_STIME) / dt;
            let d_gamma = if span <= 1.0 {
                ((next_eta - y0).tanh() - (last_eta - y0).tanh()) / (2.0 * dt)
            } else {
                if span > next_tau / dt - 2.0 {
                    return -(1 + s as i64) * 8 - 4;
                }
                let ka = (n as f64 + span - next_tau / dt).max(0.0);
                let ia = ka.floor() as i64;
                let ea = ka - ia as f64;
                let ahead = if ea == 0.0 {
                    d!(conn.mem + at(ia % cap))
                } else {
                    (1.0 - ea) * d!(conn.mem + at(ia % cap)) + ea * d!(conn.mem + at((ia + 1) % cap))
                } + *q.add(3) * presence;
                let kb = n as f64 - span;
                let ib = kb.floor() as i64;
                let (eb, jb) = (kb - ib as f64, ib.rem_euclid(cap));
                let behind = if eb == 0.0 {
                    d!(place + at(jb))
                } else {
                    (1.0 - eb) * d!(place + at(jb)) + eb * d!(place + at((jb + 1) % cap))
                };
                ((ahead - y0).tanh() - (behind - y0).tanh()) / (2.0 * span * dt)
            };
            let pnf = p_no_flow_at(dp, e1) / p_scaling;
            let ap = -(d!(e1.alpha) * d!(blk + F_SIMP)) / d!(blk + F_ZC);
            let window = *q.add(4);
            let (alpha_r, beta_r) = (d!(blk + F_ALPHAR) * window, d!(blk + F_BETAR) * (window * window));
            let ar = 1.0 / (beta_r + alpha_r * dt / 2.0);
            let br = alpha_r.sqrt() * ar * prev_zeta;
            let btot = br - pnf;
            let source = presence * gj * (big_gamma * d_uj / uj + d_gamma);
            let (alpha, beta, gamma) = (gl * uj, ar - ap, btot - source);
            let flow = if alpha > 1e-8 || alpha * gamma / (beta * beta) > 1e-6 {
                -1.0 * sign(gamma) * (-beta + (beta * beta + 4.0 * alpha * gamma.abs()).sqrt()) / (2.0 * alpha)
            } else {
                -gamma / beta + sign(gamma) * alpha * (gamma * gamma) / (beta * beta * beta)
            };
            let next_zeta = 2.0 * ar * (beta_r * prev_zeta - dt / 2.0 * alpha_r.sqrt() * flow) - prev_zeta;
            d!(e1.w) = flow * u_scaling;
            if conn.rec != NONE {
                d!(conn.rec) = d!(e1.w) * d!(blk + F_FLOWSCALE);
                d!(conn.rec + 1) = q_nph_at(dp, e1) * d!(blk + F_PRESSSCALE);
            }
            d!(blk + F_PREVZETA) = next_zeta;
            d!(conn.mem + at(n % cap)) = flow;
            conn.memlen = n + 1;
            d!(blk + F_THISETA) = next_eta;
            d!(blk + F_LASTETA) = this_eta;
        }
        _ => {}
    }
    0
}

/// The steps themselves, on the decoded body.
///
/// # Safety
/// `dp` addresses `nd` doubles no one else touches meanwhile, and every place `ends`, `conns` and `outs` name lies within
/// them and `u` (decoded); every view of them below is made from `dp`.
#[allow(clippy::too_many_arguments)]
unsafe fn step_all<T: Real>(i: &[i64], dp: *mut f64, nd: usize, u: &[f64], y: &mut [f64], steps: usize, cols: usize, nouts: usize,
                            bore: Option<(&Bore<T>, &[usize], &[Group])>, pipes: usize, npipes: usize, ends: &[End], conns: &mut [Conn],
                            outs: &[(usize, Vec<usize>)], mut tract: Option<&mut Tract>) -> i64 {
    let up = u.as_ptr();
    let all = || std::slice::from_raw_parts_mut(dp, nd);
    macro_rules! d {
        ($k:expr) => { *dp.add($k) };
    }
    for s in 0..steps {
        let row = up.add(s * cols);
        for conn in conns.iter_mut() {
            let status = connect(conn, ends, dp, row, tract.as_deref_mut(), s);
            if status != 0 {
                return status;
            }
        }
        if let Some((view, bore_ends, groups)) = bore {
            lossy_pipes(i, dp, view, bore_ends, groups, ends);
        }
        for j in 0..npipes {
            lossless_pipe(i, all(), pipes + j * PIPE_REC);
        }
        // What it records: each output a sum of recorded values, in its order (kind 0 a flow, 1 a pressure).
        for (j, (_, terms)) in outs.iter().enumerate() {
            let mut sum = d!(*terms.get_unchecked(0));
            for &t in terms.get_unchecked(1..) {
                sum += d!(t);
            }
            *y.get_unchecked_mut(s * nouts + j) = sum;
        }
    }
    0
}
