//! OpenWInD's time loop: TemporalSolver.one_step and the components a woodwind's simulation calls, as
//! render/synthesis/workers/openwind_kernel_fast.c steps them -- the same scheme on the same laid-out body (two arrays, of
//! integers `i` and doubles `d`, built by openwind_compiled.py Compiled), its lossy pipes stepped as one bore along
//! memory, each step's controls a row of `u`, its outputs a row of `y`. Port of that file, record for record and
//! operation for operation; its sums in its order, so that it is the C kernel's within rounding (render/synthesis/tools/
//! rust_kernel_check.py measures how near). A derivative of OpenWInD's scheme (Inria, GPL-3.0-or-later).
//!
//! The components, as OpenWInD's temporal/ files write them:
//!   - a pipe with the diffusive representation of its wall losses (tpipe_lossy.py), or none (tpipe.py);
//!   - a simple junction (tsimplejunction.py), a T-joint (tjunction.py TemporalJunction), a discontinuity of section
//!     (TemporalJunctionDiscontinuity), a brass valve's switch (TemporalJunctionSwitch), its opening set each step;
//!   - two side holes nearer each other than a body's shortest slice and the bore between them, one junction of four
//!     ports (render/synthesis/workers/openwind_bodies.py TemporalCross);
//!   - a radiating end, Pade (tradiation.py), its opening set by the fingering each step;
//!   - a reed, scaled (treed1dof_scaled.py), and a flute's jet (tflute.py), their parameters given step by step.
//!   - and the player's vocal tract upstream of a reed where it has one (tract.rs); none, the C kernel's steps.
//! Each step the connectors first, then the pipes (temporal_solver.py one_step).

use crate::tract::Tract;

// (The body stepped on several cores, its bore split by pipes: natively, or in a page's WebAssembly built with threads
// (wasm32-wasip1-threads, --features threads: its threads the page's Workers, sharing its memory -- src/wasm.rs).)
#[cfg(any(not(target_arch = "wasm32"), feature = "threads"))]
#[path = "parallel.rs"]
mod parallel;

/// The calling thread's priority raised to the user's interactive work, as the crew's workers raise theirs (parallel.rs):
/// the live dial's main thread, which steps its own part of the bore, its lips, reed or jet and the joins at that part's
/// ends, so that it keeps to the performance cores and is never put behind work at a lower priority (overnight fits run
/// at the background's, on the efficiency cores).
#[cfg(not(target_arch = "wasm32"))]
pub fn interactive() {
    parallel::interactive();
}

const T_SIMPLE: i64 = 1;
const T_TJOINT: i64 = 2;
const T_DISCONTINUITY: i64 = 3;
const T_RADIATION: i64 = 4;
const T_REED: i64 = 5;
const T_FLUTE: i64 = 6;
const T_LIPS: i64 = 7;
const T_SWITCH: i64 = 8;
const T_CROSS: i64 = 9;

// The bore's record in `i` (openwind_kernel_fast.c, its enum of the same names).
const B_H: usize = 0;
const B_L: usize = 1;
const B_N: usize = 2;
const B_P: usize = 3;
const B_V: usize = 4;
const B_P0: usize = 5;
const B_PNF: usize = 6;
const B_PI: usize = 7;
const B_VI: usize = 8;
const B_S: usize = 9;
const B_T: usize = 10;
const B_PPNF: usize = 11;
const B_P0PNF: usize = 12;
const B_M: usize = 13;
const B_PP0: usize = 14;
const B_P0P0: usize = 15;
const B_PIP0: usize = 16;
const B_PPI: usize = 17;
const B_VV: usize = 18;
const B_VIV: usize = 19;
const B_VVI: usize = 20;
const B_XV: usize = 21;
const B_GROUPS: usize = 22;
const B_NGROUPS: usize = 23;
const B_ENDS: usize = 24;
const B_NENDS: usize = 25;
// A group of a lossy pipe's mesh's elements of one width.
const G_W: usize = 0;
const G_COUNT: usize = 1;
const G_H: usize = 2;
const G_L: usize = 3;
const G_A: usize = 4;
const G_B: usize = 5;
const GROUP_REC: usize = 6;
// A pipe without losses.
const L_NH1: usize = 0;
const L_NL2: usize = 1;
const L_MINUS: usize = 2;
const L_PLUS: usize = 3;
const L_P: usize = 4;
const L_V: usize = 5;
const L_MBTV: usize = 6;
const L_A_PTR: usize = 7;
const L_A_IDX: usize = 8;
const L_A_DAT: usize = 9;
const L_B_PTR: usize = 10;
const L_B_IDX: usize = 11;
const L_B_DAT: usize = 12;
const PIPE_REC: usize = 13;
// An end.
const E_PNF: usize = 0;
const E_HALF: usize = 1;
const E_ALPHA: usize = 2;
const E_W: usize = 3;
const END_REC: usize = 4;
// A connector.
const C_TYPE: usize = 0;
const C_E1: usize = 1;
const C_D: usize = 4;
const C_U: usize = 5;
const C_REC: usize = 6;
const C_MEM: usize = 7;
const C_MEMLEN: usize = 8;
const C_MEMCAP: usize = 9;
// (A cross's fourth end, in the place a flute's memory takes.)
const C_E4: usize = C_MEM;
const CONN_REC: usize = 10;
// The header.
const H_BORE: usize = 0;
const H_PIPES: usize = 1;
const H_NPIPES: usize = 2;
const H_ENDS: usize = 3;
const H_CONNS: usize = 5;
const H_NCONNS: usize = 6;
const H_OUTS: usize = 7;
const H_NOUTS: usize = 8;
const H_UCOLS: usize = 9;

// A radiation's block in `d`.
const R_MEND: usize = 0;
const R_HALFDT: usize = 1;
const R_ZPLUS: usize = 2;
const R_A: usize = 3;
const R_BETA: usize = 4;
const R_FLOWSCALE: usize = 6;
const R_PRESSSCALE: usize = 7;
const R_PHI: usize = 8;
const R_ZETA: usize = 9;
const R_STEP: usize = 10;
const R_INFL: usize = 11;
const R_ZTOF: usize = 12;
const R_PTOF: usize = 13;
const R_KAPPA: usize = 14;
// A valve's switch's: its opening, the step, and its gamma's influence from its three ends' no-flow pressures.
const S_PHI: usize = 0;
const S_DT: usize = 1;
const S_INFL: usize = 2;
// A reed's.
const Q_ZC: usize = 0;
const Q_THETA: usize = 2;
const Q_CONTACT: usize = 3;
const Q_SP: usize = 4;
const Q_SF: usize = 5;
const Q_SIMP: usize = 6;
const Q_DT: usize = 7;
const Q_FLOWSCALE: usize = 8;
const Q_PRESSSCALE: usize = 9;
const Q_THISY: usize = 10;
const Q_LASTY: usize = 11;
const Q_PREVZ: usize = 12;
const Q_LASTKC: usize = 13;
const Q_EXPONENT: usize = 14;
const Q_LEAK: usize = 15;
const Q_CONSTRICTION: usize = 16;
// (A reed's staple's recovery after its constriction, where its block has one -- read only where its constriction is not
// 0 (openwind_compiled.py); a lips' block has its inward mode there.)
const Q_RECOVERY: usize = 17;
// (A reed's block ends there; brass lips' with their inward mode (T_LIPS: render/synthesis/workers/openwind_lips.py) go
// on: its state, then its area over the outward's, its direction. Its resonance over the outward one's, its Q and the
// outward mass over its own are its register's, each step's controls after the reed's: U_RATIO...)
const Q_THISQ: usize = 17;
const Q_LASTQ: usize = 18;
const Q_SHARE: usize = 19;
const Q_MODEL2: usize = 20;
// (Lips' controls after a reed's nine: their inward mode's values, openwind_compiled.py LIPS_PARAMETERS.)
const U_RATIO: usize = 9;
const U_QFACTOR2: usize = 10;
const U_COUPLING: usize = 11;
// A flute's.
const F_ALPHAR: usize = 5;
const F_BETAR: usize = 6;
const F_RHO: usize = 7;
const F_CELERITY: usize = 8;
const F_ZC: usize = 9;
const F_SP: usize = 10;
const F_SIMP: usize = 11;
const F_STIME: usize = 12;
const F_DT: usize = 13;
const F_FLOWSCALE: usize = 14;
const F_PRESSSCALE: usize = 15;
const F_PREVZETA: usize = 16;
const F_THISETA: usize = 17;
const F_LASTETA: usize = 18;

/// Nodes stepped together through every loss variable (openwind_compiled.py BLOCK).
pub const BLOCK: usize = 8;

#[inline(always)]
fn at(x: i64) -> usize {
    x as usize
}

/// An end's record, by its index.
#[inline(always)]
fn end_of(i: &[i64], k: i64) -> usize {
    at(i[H_ENDS]) + at(k) * END_REC
}

/// scipy's csr_matvec: y += A x.
fn csr_matvec(rows: usize, i: &[i64], ptr: usize, idx: usize, d: &mut [f64], dat: usize, x: usize, y: usize) {
    for r in 0..rows {
        let mut sum = d[y + r];
        for jj in at(i[ptr + r])..at(i[ptr + r + 1]) {
            sum += d[dat + jj] * d[x + at(i[idx + jj])];
        }
        d[y + r] = sum;
    }
}

/// Whether every region the bore's record names lies within `nd` doubles and its groups' nodes within the bore: what lets
/// its loops read without a check at each value (lossy_pipes).
fn bore_fits(i: &[i64], nd: usize, b: usize) -> bool {
    let field = |f: usize| i.get(b + f).copied();
    let (Some(h), Some(l), Some(n)) = (field(B_H), field(B_L), field(B_N)) else { return false };
    if h < 0 || l < 0 || n < 0 || h as usize % BLOCK != 0 || l as usize % BLOCK != 0 {
        return false;
    }
    let (h, l, n) = (h as usize, l as usize, n as usize);
    let within = |f: usize, len: usize| field(f).is_some_and(|o| o >= 0 && (o as usize).checked_add(len).is_some_and(|e| e <= nd));
    let by_h = [B_P, B_P0, B_PNF, B_S, B_PPNF, B_P0PNF, B_M, B_PP0, B_P0P0];
    let by_l = [B_V, B_T, B_VV, B_XV];
    if !by_h.iter().all(|&f| within(f, h)) || !by_l.iter().all(|&f| within(f, l))
        || ![B_PI, B_PIP0, B_PPI].iter().all(|&f| within(f, h * n)) || ![B_VI, B_VIV, B_VVI].iter().all(|&f| within(f, l * n)) {
        return false;
    }
    // (And no two of them overlapping: its loops take each as a slice of its own, as the C kernel's take restrict
    // pointers, so that what one writes is never what another reads.)
    let mut regions: Vec<(usize, usize)> = by_h.iter().map(|&f| (at(i[b + f]), h)).chain(by_l.iter().map(|&f| (at(i[b + f]), l)))
        .chain([B_PI, B_PIP0, B_PPI].iter().map(|&f| (at(i[b + f]), h * n))).chain([B_VI, B_VIV, B_VVI].iter().map(|&f| (at(i[b + f]), l * n)))
        .filter(|&(_, len)| len > 0).collect();
    regions.sort_unstable();
    if regions.windows(2).any(|pair| pair[0].0 + pair[0].1 > pair[1].0) {
        return false;
    }
    let (Some(groups), Some(n_groups)) = (field(B_GROUPS), field(B_NGROUPS)) else { return false };
    for g in 0..n_groups.max(0) as usize {
        let at_g = groups as usize + g * GROUP_REC;
        let Some(rec) = i.get(at_g..at_g + GROUP_REC) else { return false };
        let (w, count, hs, ls, a, bk) = (rec[G_W], rec[G_COUNT], rec[G_H], rec[G_L], rec[G_A], rec[G_B]);
        if w < 1 || count < 0 || hs < 0 || ls < 0 || a < 0 || bk < 0 {
            return false;
        }
        let (w, count) = (w as usize, count as usize);
        let (Some(h_first), Some(l_first)) = (i.get(hs as usize..hs as usize + count), i.get(ls as usize..ls as usize + count)) else { return false };
        if h_first.iter().any(|&x| x < 0 || x as usize + w > h) || l_first.iter().any(|&x| x < 0 || x as usize + w > l)
            || a as usize + count * w * w > nd || bk as usize + count * w * w > nd {
            return false;
        }
    }
    true
}

/// The bore's numbers: doubles, as OpenWInD's, or singles (research/OPENWIND_REALTIME_PLAN.md, stage 4: twice the lanes a
/// vector, half the memory), its no-flow pressures doubles either way, where its connectors read them.
pub trait Real: Copy + Default + std::ops::Add<Output = Self> + std::ops::Sub<Output = Self> + std::ops::Mul<Output = Self>
    + std::ops::Neg<Output = Self> + std::ops::AddAssign {
    const TWO: Self;
    /// self * a + b, rounded once -- but in WebAssembly, which has no fused multiply-add, rounded twice: mul_add there is
    /// libm's fma in software, which made a page's player 11 to 43 times slower than this one natively (the studio page,
    /// 25 October 2026), held to the native within rounding (test/audio/openwind-wasm.test.mjs).
    fn fma(self, a: Self, b: Self) -> Self;
    fn of(x: f64) -> Self;
    fn wide(self) -> f64;
}

impl Real for f64 {
    const TWO: f64 = 2.0;
    #[cfg(not(target_arch = "wasm32"))]
    #[inline(always)]
    fn fma(self, a: f64, b: f64) -> f64 { self.mul_add(a, b) }
    #[cfg(target_arch = "wasm32")]
    #[inline(always)]
    fn fma(self, a: f64, b: f64) -> f64 { self * a + b }
    #[inline(always)]
    fn of(x: f64) -> f64 { x }
    #[inline(always)]
    fn wide(self) -> f64 { self }
}

impl Real for f32 {
    const TWO: f32 = 2.0;
    #[cfg(not(target_arch = "wasm32"))]
    #[inline(always)]
    fn fma(self, a: f32, b: f32) -> f32 { self.mul_add(a, b) }
    #[cfg(target_arch = "wasm32")]
    #[inline(always)]
    fn fma(self, a: f32, b: f32) -> f32 { self * a + b }
    #[inline(always)]
    fn of(x: f64) -> f32 { x as f32 }
    #[inline(always)]
    fn wide(self) -> f64 { self as f64 }
}

/// One block of the bore's pressure nodes through every loss variable: P_next = 2 P_nph - P, and P0_next; then each
/// Pi_next, summed through pi_to_p0 as it comes for the next P0_next and the next no-flow pressure (S); and of that
/// no-flow pressure, all but its velocities' -- each array its own slice (openwind_kernel_fast.c pressure_block, its
/// restrict pointers), what each node carries meanwhile held in registers.
#[allow(clippy::too_many_arguments)]
#[inline(always)]
fn pressure_block<T: Real>(p: &mut [T; BLOCK], p0: &mut [T; BLOCK], pnf: &mut [f64; BLOCK], pi: &mut [T], s: &mut [T; BLOCK],
                           pp0: &[T; BLOCK], p0p0: &[T; BLOCK], ppnf: &[T; BLOCK], p0pnf: &[T; BLOCK], m: &[T; BLOCK],
                           ppi: &[T], pip0: &[T]) {
    let half = pnf.map(T::of);
    let mut sx = [T::default(); BLOCK];
    let mut sum_pi = [T::default(); BLOCK];
    for j in 0..BLOCK {
        let next = T::TWO.fma(half[j], -p[j]);
        let sum = p[j] + next;
        let p0_next = sum.fma(pp0[j], p0p0[j].fma(p0[j], s[j]));
        sx[j] = sum - p0[j] - p0_next;
        p[j] = next;
        p0[j] = p0_next;
    }
    // (Each loss variable's block read whole before it is written, so that its lanes stay vectors throughout; and sx - 2 x
    // as written, no fused form needed: 2 x is exact.)
    for ((x, a), c) in pi.as_chunks_mut::<BLOCK>().0.iter_mut().zip(ppi.as_chunks::<BLOCK>().0).zip(pip0.as_chunks::<BLOCK>().0) {
        let (was, a, c) = (*x, *a, *c);
        let mut y = [T::default(); BLOCK];
        for j in 0..BLOCK {
            y[j] = a[j].fma(sx[j] - T::TWO * was[j], was[j]);
            sum_pi[j] = c[j].fma(y[j], sum_pi[j]);
        }
        *x = y;
    }
    for j in 0..BLOCK {
        s[j] = sum_pi[j];
        pnf[j] = ppnf[j].fma(p[j], p0pnf[j].fma(p0[j], m[j] * sum_pi[j])).wide();
    }
}

/// One block of the bore's velocity nodes through every loss variable: each Vi_next, summed through vi_to_v (T) for the
/// next V_next.
#[inline(always)]
fn velocity_block<T: Real>(vi: &mut [T], t: &mut [T; BLOCK], xv: &[T; BLOCK], vvi: &[T], viv: &[T]) {
    let mut sum_vi = [T::default(); BLOCK];
    for ((x, a), c) in vi.as_chunks_mut::<BLOCK>().0.iter_mut().zip(vvi.as_chunks::<BLOCK>().0).zip(viv.as_chunks::<BLOCK>().0) {
        let (was, a, c) = (*x, *a, *c);
        let mut y = [T::default(); BLOCK];
        for j in 0..BLOCK {
            y[j] = a[j].fma(xv[j] - T::TWO * was[j], was[j]);
            sum_vi[j] = c[j].fma(y[j], sum_vi[j]);
        }
        *x = y;
    }
    *t = sum_vi;
}

/// The bore's element groups, decoded: each group's width, its elements' count, where in `i` its elements' first pressure
/// and velocity nodes are listed, and where in `d` its two matrices' blocks are.
#[derive(Clone, Copy)]
struct Group {
    w: usize,
    count: usize,
    hs: usize,
    ls: usize,
    a: usize,
    b: usize,
}

/// The bore's ends (by their place among the ends) and its groups, read once from its record (bore_fits checked it). ->
/// None where an end is not among the ends.
fn bore_decoded(i: &[i64], b: usize, n_ends: usize) -> Option<(Vec<usize>, Vec<Group>)> {
    let listed = at(i[b + B_ENDS]);
    let ends = (0..at(i[b + B_NENDS])).map(|k| i.get(listed + k).and_then(|&e| usize::try_from(e).ok()).filter(|&e| e < n_ends))
        .collect::<Option<Vec<_>>>()?;
    let groups = (0..at(i[b + B_NGROUPS])).map(|g| {
        let rec = at(i[b + B_GROUPS]) + g * GROUP_REC;
        Group { w: at(i[rec + G_W]), count: at(i[rec + G_COUNT]), hs: at(i[rec + G_H]), ls: at(i[rec + G_L]), a: at(i[rec + G_A]), b: at(i[rec + G_B]) }
    }).collect();
    Some((ends, groups))
}

/// The bore's state, each step's and kept between calls, by its record's field.
const BORE_STATE: [usize; 8] = [B_P, B_V, B_P0, B_PI, B_VI, B_S, B_T, B_XV];
/// Its record's fields that are regions, all before its groups'.
const FIELDS: usize = B_GROUPS;
/// Its coefficients, read only.
const BORE_COEFFICIENTS: [usize; 10] = [B_PPNF, B_P0PNF, B_M, B_PP0, B_P0P0, B_PIP0, B_PPI, B_VV, B_VIV, B_VVI];

/// A region's length, by its field, for a bore of `h` pressure and `l` velocity nodes and `n` loss variables each.
fn region_length(field: usize, h: usize, l: usize, n: usize) -> usize {
    match field {
        B_PI | B_PIP0 | B_PPI => h * n,
        B_VI | B_VIV | B_VVI => l * n,
        B_V | B_T | B_VV | B_XV => l,
        _ => h,
    }
}

/// The bore's arrays where its loops read them: each region's first value, of doubles in `d` or singles in a mirror
/// (Mirror), by its record's field; each group's two matrices; its no-flow pressures always in `d`.
struct Bore<T> {
    h: usize,
    l: usize,
    n: usize,
    at: [*mut T; FIELDS],
    pnf: *mut f64,
    a: Vec<*const T>,
    b: Vec<*const T>,
}

impl Bore<f64> {
    /// The bore's arrays in `d` itself.
    unsafe fn in_d(i: &[i64], dp: *mut f64, b: usize, groups: &[Group]) -> Bore<f64> {
        let mut at_field = [std::ptr::null_mut(); FIELDS];
        for &f in BORE_STATE.iter().chain(&BORE_COEFFICIENTS) {
            at_field[f] = dp.add(at(i[b + f]));
        }
        Bore { h: at(i[b + B_H]), l: at(i[b + B_L]), n: at(i[b + B_N]), at: at_field, pnf: dp.add(at(i[b + B_PNF])),
               a: groups.iter().map(|g| dp.add(g.a) as *const f64).collect(), b: groups.iter().map(|g| dp.add(g.b) as *const f64).collect() }
    }
}

/// The bore's arrays in singles: its state copied in from `d` at each call's start and back at its end, its
/// coefficients copied in (each rounded to the nearest single); its no-flow pressures left in `d`.
struct Mirror {
    data: Vec<f32>,
    // (Each region: where in `d`, where in the mirror, its length, and whether it is state, copied back.)
    regions: Vec<(usize, usize, usize, bool)>,
    fields: [usize; FIELDS],
    groups: Vec<(usize, usize)>,
}

impl Mirror {
    fn of(i: &[i64], d: &[f64], b: usize, groups: &[Group]) -> Mirror {
        let (h, l, n) = (at(i[b + B_H]), at(i[b + B_L]), at(i[b + B_N]));
        let (mut regions, mut fields, mut groups_at, mut next) = (Vec::new(), [0; FIELDS], Vec::new(), 0);
        for (&f, state) in BORE_STATE.iter().map(|f| (f, true)).chain(BORE_COEFFICIENTS.iter().map(|f| (f, false))) {
            let len = region_length(f, h, l, n);
            regions.push((at(i[b + f]), next, len, state));
            fields[f] = next;
            next += len;
        }
        for g in groups {
            let len = g.count * g.w * g.w;
            regions.push((g.a, next, len, false));
            regions.push((g.b, next + len, len, false));
            groups_at.push((next, next + len));
            next += 2 * len;
        }
        let mut data = vec![0.0f32; next];
        for &(from, to, len, _) in &regions {
            for (m, &x) in data[to..to + len].iter_mut().zip(&d[from..from + len]) {
                *m = x as f32;
            }
        }
        Mirror { data, regions, fields, groups: groups_at }
    }

    /// Its state back into `d`.
    fn back(&self, d: &mut [f64]) {
        for &(to, from, len, state) in &self.regions {
            if state {
                for (x, &m) in d[to..to + len].iter_mut().zip(&self.data[from..from + len]) {
                    *x = m as f64;
                }
            }
        }
    }

    /// The bore's arrays in the mirror, its no-flow pressures in `d`.
    unsafe fn bore(&mut self, i: &[i64], dp: *mut f64, b: usize) -> Bore<f32> {
        let base = self.data.as_mut_ptr();
        let mut at_field = [std::ptr::null_mut(); FIELDS];
        for &f in BORE_STATE.iter().chain(&BORE_COEFFICIENTS) {
            at_field[f] = base.add(self.fields[f]);
        }
        Bore { h: at(i[b + B_H]), l: at(i[b + B_L]), n: at(i[b + B_N]), at: at_field, pnf: dp.add(at(i[b + B_PNF])),
               a: self.groups.iter().map(|&(a, _)| base.add(a) as *const f32).collect(),
               b: self.groups.iter().map(|&(_, b)| base.add(b) as *const f32).collect() }
    }
}

/// tpipe_lossy.py TemporalLossyPipe.one_step and _compute_next_p_no_flow, every lossy pipe at once (`bore` its arrays,
/// `bore_ends` and `groups` it decoded).
///
/// # Safety
/// `dp` addresses the body's doubles, which no one else touches meanwhile; the bore's regions lie within them, or its
/// mirror, and apart (bore_fits); its ends are among `ends` (bore_decoded), whose places lie within them (decoded).
unsafe fn lossy_pipes<T: Real>(i: &[i64], dp: *mut f64, bore: &Bore<T>, bore_ends: &[usize], groups: &[Group], ends: &[End]) {
    // (Each pipe's end pressures at the half step, from the flows its connectors have just set: accept_q_nph.)
    for &k in bore_ends {
        let e = ends.get_unchecked(k);
        *dp.add(e.pnf) -= *dp.add(e.alpha) * *dp.add(e.w);
    }
    bore_step(i, bore, groups);
}

/// The bore's nodes stepped, its ends' pressures at the half step already taken (lossy_pipes): the whole bore's, or one
/// part's of it on a thread of its own (parallel.rs), `i` then that part's own list of its elements' nodes.
///
/// # Safety
/// As lossy_pipes; each group's elements' nodes listed in `i` within the bore's.
#[inline(always)]
unsafe fn bore_step<T: Real>(i: &[i64], bore: &Bore<T>, groups: &[Group]) {
    use std::slice::{from_raw_parts, from_raw_parts_mut};
    let (h_n, l_n, n) = (bore.h, bore.l, bore.n);
    let mut_of = |f: usize| from_raw_parts_mut(bore.at[f], region_length(f, h_n, l_n, n));
    let of = |f: usize| from_raw_parts(bore.at[f] as *const T, region_length(f, h_n, l_n, n));
    let (p, v, p0, pi, vi, s, t, xv) = (mut_of(B_P), mut_of(B_V), mut_of(B_P0), mut_of(B_PI), mut_of(B_VI), mut_of(B_S), mut_of(B_T), mut_of(B_XV));
    let pnf = from_raw_parts_mut(bore.pnf, h_n);
    let (ppnf, p0pnf, m, pp0, p0p0, pip0, ppi) = (of(B_PPNF), of(B_P0PNF), of(B_M), of(B_PP0), of(B_P0P0), of(B_PIP0), of(B_PPI));
    let (vv, viv, vvi) = (of(B_VV), of(B_VIV), of(B_VVI));
    // (A block of nodes at `h`, and its loss variables: within their regions, their counts whole blocks -- bore_fits.)
    fn block<T>(x: &[T], h: usize) -> &[T; BLOCK] { unsafe { &*(x.as_ptr().add(h) as *const [T; BLOCK]) } }
    fn block_mut<T>(x: &mut [T], h: usize) -> &mut [T; BLOCK] { unsafe { &mut *(x.as_mut_ptr().add(h) as *mut [T; BLOCK]) } }
    for h in (0..h_n).step_by(BLOCK) {
        let losses = h * n..(h + BLOCK) * n;
        pressure_block(block_mut(p, h), block_mut(p0, h), block_mut(pnf, h), pi.get_unchecked_mut(losses.clone()), block_mut(s, h),
                       block(pp0, h), block(p0p0, h), block(ppnf, h), block(p0pnf, h), block(m, h), ppi.get_unchecked(losses.clone()),
                       pip0.get_unchecked(losses));
    }
    // V_next, element by element; then each Vi_next, summed through vi_to_v as it comes for the next V_next.
    for (g, &a) in groups.iter().zip(&bore.a) {
        let (w, count) = (g.w, g.count);
        let (hs, ls) = (i.get_unchecked(g.hs..g.hs + count), i.get_unchecked(g.ls..g.ls + count));
        let a = from_raw_parts(a, count * w * w);
        match w {
            2 => element_velocities::<T, 2>(hs, ls, a, p, v, xv, t, vv),
            3 => element_velocities::<T, 3>(hs, ls, a, p, v, xv, t, vv),
            4 => element_velocities::<T, 4>(hs, ls, a, p, v, xv, t, vv),
            5 => element_velocities::<T, 5>(hs, ls, a, p, v, xv, t, vv),
            _ => element_velocities_any(hs, ls, a, p, v, xv, t, vv, w),
        }
    }
    for l in (0..l_n).step_by(BLOCK) {
        let losses = l * n..(l + BLOCK) * n;
        velocity_block(vi.get_unchecked_mut(losses.clone()), block_mut(t, l), block(xv, l), vvi.get_unchecked(losses.clone()),
                       viv.get_unchecked(losses));
    }
    // The next no-flow pressure's velocities, element by element.
    for (g, &bk) in groups.iter().zip(&bore.b) {
        let (w, count) = (g.w, g.count);
        let (hs, ls) = (i.get_unchecked(g.hs..g.hs + count), i.get_unchecked(g.ls..g.ls + count));
        let bk = from_raw_parts(bk, count * w * w);
        match w {
            2 => element_pressures::<T, 2>(hs, ls, bk, v, pnf),
            3 => element_pressures::<T, 3>(hs, ls, bk, v, pnf),
            4 => element_pressures::<T, 4>(hs, ls, bk, v, pnf),
            5 => element_pressures::<T, 5>(hs, ls, bk, v, pnf),
            _ => element_pressures_any(hs, ls, bk, v, pnf, w),
        }
    }
}

/// A group's elements of width W: V_next, from its loss variables' sum (T), its own, and its element's pressures through
/// p_to_v; and V + V_next (xv) for its loss variables after.
///
/// # Safety
/// Each element's nodes within the bore (bore_fits).
#[allow(clippy::too_many_arguments)]
#[inline(always)]
unsafe fn element_velocities<T: Real, const W: usize>(hs: &[i64], ls: &[i64], a: &[T], p: &[T], v: &mut [T], xv: &mut [T], t: &[T], vv: &[T]) {
    let (p, v, xv, t, vv) = (p.as_ptr(), v.as_mut_ptr(), xv.as_mut_ptr(), t.as_ptr(), vv.as_ptr());
    for ((&h, &l), block) in hs.iter().zip(ls).zip(a.chunks_exact(W * W)) {
        let pressures = *(p.add(at(h)) as *const [T; W]);
        for r in 0..W {
            let node = at(l) + r;
            let mut next = (*vv.add(node)).fma(*v.add(node), *t.add(node));
            for c in 0..W {
                next = block[r * W + c].fma(pressures[c], next);
            }
            *xv.add(node) = *v.add(node) + next;
            *v.add(node) = next;
        }
    }
}

/// # Safety
/// As element_velocities.
#[allow(clippy::too_many_arguments)]
unsafe fn element_velocities_any<T: Real>(hs: &[i64], ls: &[i64], a: &[T], p: &[T], v: &mut [T], xv: &mut [T], t: &[T], vv: &[T], w: usize) {
    let (p, v, xv, t, vv) = (p.as_ptr(), v.as_mut_ptr(), xv.as_mut_ptr(), t.as_ptr(), vv.as_ptr());
    for ((&h, &l), block) in hs.iter().zip(ls).zip(a.chunks_exact(w * w)) {
        for r in 0..w {
            let node = at(l) + r;
            let mut next = (*vv.add(node)).fma(*v.add(node), *t.add(node));
            for c in 0..w {
                next = block[r * w + c].fma(*p.add(at(h) + c), next);
            }
            *xv.add(node) = *v.add(node) + next;
            *v.add(node) = next;
        }
    }
}

/// A group's elements of width W: the next no-flow pressure's velocities, through v_to_p_noflow (two elements' at the
/// pressure they share).
///
/// # Safety
/// As element_velocities.
#[inline(always)]
unsafe fn element_pressures<T: Real, const W: usize>(hs: &[i64], ls: &[i64], bk: &[T], v: &[T], pnf: &mut [f64]) {
    let (v, pnf) = (v.as_ptr(), pnf.as_mut_ptr());
    for ((&h, &l), block) in hs.iter().zip(ls).zip(bk.chunks_exact(W * W)) {
        let velocities = *(v.add(at(l)) as *const [T; W]);
        for c in 0..W {
            let mut sum = T::default();
            for r in 0..W {
                sum = block[c * W + r].fma(velocities[r], sum);
            }
            *pnf.add(at(h) + c) += sum.wide();
        }
    }
}

/// # Safety
/// As element_velocities.
unsafe fn element_pressures_any<T: Real>(hs: &[i64], ls: &[i64], bk: &[T], v: &[T], pnf: &mut [f64], w: usize) {
    let (v, pnf) = (v.as_ptr(), pnf.as_mut_ptr());
    for ((&h, &l), block) in hs.iter().zip(ls).zip(bk.chunks_exact(w * w)) {
        for c in 0..w {
            let mut sum = T::default();
            for r in 0..w {
                sum = block[c * w + r].fma(*v.add(at(l) + r), sum);
            }
            *pnf.add(at(h) + c) += sum.wide();
        }
    }
}

/// tpipe.py TemporalPipe.one_step (`q` its record): A is dtinvML2B, B dtinvMBt, mbtv dtinvMBtV.
fn lossless_pipe(i: &[i64], d: &mut [f64], q: usize) {
    let (nh1, nl2) = (at(i[q + L_NH1]), at(i[q + L_NL2]));
    let (minus, plus) = (end_of(i, i[q + L_MINUS]), end_of(i, i[q + L_PLUS]));
    let (p, v, mbtv) = (at(i[q + L_P]), at(i[q + L_V]), at(i[q + L_MBTV]));
    for j in 0..nh1 {
        d[p + j] -= d[mbtv + j];
    }
    d[p] += -2.0 * d[at(i[minus + E_ALPHA])] * d[at(i[minus + E_W])];
    d[p + nh1 - 1] += -2.0 * d[at(i[plus + E_ALPHA])] * d[at(i[plus + E_W])];
    csr_matvec(nl2, i, at(i[q + L_A_PTR]), at(i[q + L_A_IDX]), d, at(i[q + L_A_DAT]), p, v);
    for j in 0..nh1 {
        d[mbtv + j] = 0.0;
    }
    csr_matvec(nh1, i, at(i[q + L_B_PTR]), at(i[q + L_B_IDX]), d, at(i[q + L_B_DAT]), v, mbtv);
}

#[inline(always)]
fn positive_part(y: f64) -> f64 {
    if y > 0.0 { y } else { 0.0 * y }
}

#[inline(always)]
fn abs_negative_part(y: f64) -> f64 {
    if y < 0.0 { -y } else { -y * 0.0 }
}

/// tjunction.py TemporalJunctionSwitch._precompute_constants at its opening factor, its discontinuity's mass none (M_J 0,
/// as OpenWInD's time domain takes a switch): its transmission T = [1, -phi, phi - 1], each end's m = dt / (2 alpha), and
/// the influence -dt/2 (dt^2/4 T diag(1/m) T')^-1 T -- in numpy's order, so that it is OpenWInD's within rounding.
fn switch_coefficients(s: &mut [f64], alpha: [f64; 3]) {
    let (phi, dt) = (s[S_PHI], s[S_DT]);
    let t = [1.0, -phi, phi - 1.0];
    let mut a_g = 0.0;
    for (k, &a) in alpha.iter().enumerate() {
        a_g += t[k] * (1.0 / (dt / (2.0 * a))) * t[k];
    }
    let inv = 1.0 / (0.0 + dt * dt / 4.0 * a_g);
    let c = -dt / 2.0 * inv;
    for k in 0..3 {
        s[S_INFL + k] = c * t[k];
    }
}

/// numpy's sign: a zero of either sign 0, NaN itself.
#[inline(always)]
fn sign(x: f64) -> f64 {
    if x > 0.0 { 1.0 } else if x < 0.0 { -1.0 } else if x == 0.0 { 0.0 } else { x }
}

/// tradiation.py TemporalRadiation._precompute_coefficients, for its opening factor (RadiationPade
/// compute_temporal_coefs: alpha proportional to it, beta to its square).
fn radiation_coefficients(r: &mut [f64]) {
    let phi = r[R_PHI];
    let (alpha, beta) = (r[R_A] * phi, r[R_BETA] * (phi * phi));
    let (m_end, half_dt, zplus) = (r[R_MEND], r[R_HALFDT], r[R_ZPLUS]);
    let m_end_rad = m_end + half_dt * beta / zplus;
    let rt_alpha = alpha.sqrt();
    let z_dt = zplus + (half_dt * half_dt) * alpha / m_end_rad;
    r[R_STEP] = zplus / z_dt;
    r[R_INFL] = -half_dt * rt_alpha / z_dt * m_end / m_end_rad;
    r[R_ZTOF] = rt_alpha * m_end / m_end_rad;
    r[R_PTOF] = -beta / zplus * m_end / m_end_rad;
}

const NONE: usize = usize::MAX;

/// An end, decoded: where in `d` its no-flow pressure is (less half its `half` where it has one), its alpha and its flow.
#[derive(Clone, Copy)]
struct End {
    pnf: usize,
    half: usize,
    alpha: usize,
    w: usize,
}

/// A connector, decoded: its kind, its ends (by their place among the ends), its block in `d`, its first control column
/// and where it records (NONE: none), and a flute's memory.
#[derive(Clone, Copy)]
struct Conn {
    kind: i64,
    e: [usize; 4],
    blk: usize,
    u: usize,
    rec: usize,
    mem: usize,
    memlen: i64,
    memcap: i64,
    // (A reed whose lay stiffens it before its tip shuts: T_REED_LAY, read as a reed -- lay_contact, at the file's end.)
    lay: bool,
}

/// Each kind's block in `d`, the ends it joins, and the control columns it reads.
fn shape_of(kind: i64) -> Option<(usize, usize, usize)> {
    Some(match kind {
        T_SIMPLE => (1, 2, 0),
        T_TJOINT => (12, 3, 0),
        T_DISCONTINUITY => (4, 2, 0),
        T_RADIATION => (R_KAPPA + 1, 1, 1),
        T_REED => (Q_RECOVERY + 1, 1, 9),
        T_REED_LAY => (Q_LAYOPENING + 1, 1, 9),
        T_LIPS => (Q_MODEL2 + 1, 1, U_COUPLING + 1),
        T_SWITCH => (S_INFL + 3, 3, 1),
        T_CROSS => (24, 4, 0),
        T_FLUTE => (F_LASTETA + 1, 1, 12),
        _ => return None,
    })
}

/// The ends, connectors and outputs read once from the header, each place in `d` checked: what lets the steps read without
/// a check at each value. -> None where any lies outside.
#[allow(clippy::type_complexity)]
fn decoded(i: &[i64], nd: usize, cols: usize) -> Option<(Vec<End>, Vec<Conn>, Vec<(usize, Vec<usize>)>)> {
    let place = |x: i64| if x >= 0 && (x as usize) < nd { Some(x as usize) } else { None };
    let n_ends = usize::try_from(i[4]).ok()?;
    let mut ends = Vec::with_capacity(n_ends);
    for k in 0..n_ends {
        let e = i.get(at(i[H_ENDS]) + k * END_REC..at(i[H_ENDS]) + (k + 1) * END_REC)?;
        ends.push(End { pnf: place(e[E_PNF])?, half: if e[E_HALF] < 0 { NONE } else { place(e[E_HALF])? }, alpha: place(e[E_ALPHA])?, w: place(e[E_W])? });
    }
    let mut conns = Vec::new();
    for c in 0..usize::try_from(i[H_NCONNS]).ok()? {
        let k = i.get(at(i[H_CONNS]) + c * CONN_REC..at(i[H_CONNS]) + (c + 1) * CONN_REC)?;
        let (size, joined, controls) = shape_of(k[C_TYPE])?;
        let blk = place(k[C_D])?;
        if blk + size > nd {
            return None;
        }
        let mut e = [NONE; 4];
        for (j, slot) in e.iter_mut().enumerate().take(joined) {
            let end = usize::try_from(k[if j < 3 { C_E1 + j } else { C_E4 }]).ok()?;
            if end >= ends.len() {
                return None;
            }
            *slot = end;
        }
        let u = if k[C_U] < 0 { NONE } else { k[C_U] as usize };
        // (A radiation's opening and a valve's are a column where the fingering moves them, else held as laid out.)
        if controls > 0 && u == NONE && !matches!(k[C_TYPE], T_RADIATION | T_SWITCH) || u != NONE && u + controls > cols {
            return None;
        }
        let rec = if k[C_REC] < 0 { NONE } else { place(k[C_REC])? };
        if rec != NONE && rec + 2 > nd {
            return None;
        }
        let (mem, memlen, memcap) = if k[C_TYPE] == T_FLUTE {
            let mem = place(k[C_MEM])?;
            if k[C_MEMCAP] < 1 || k[C_MEMLEN] < 0 || mem + 2 * k[C_MEMCAP] as usize > nd {
                return None;
            }
            (mem, k[C_MEMLEN], k[C_MEMCAP])
        } else {
            (NONE, 0, 0)
        };
        let lay = k[C_TYPE] == T_REED_LAY;
        conns.push(Conn { kind: if lay { T_REED } else { k[C_TYPE] }, e, blk, u, rec, mem, memlen, memcap, lay });
    }
    let mut outs = Vec::new();
    let mut o = at(i[H_OUTS]);
    for _ in 0..usize::try_from(i[H_NOUTS]).ok()? {
        let (kind, terms) = (*i.get(o)?, usize::try_from(*i.get(o + 1)?).ok()?);
        if !(0..=1).contains(&kind) || terms == 0 {
            return None;
        }
        let mut at_terms = Vec::with_capacity(terms);
        for t in 0..terms {
            at_terms.push(place(*i.get(o + 2 + t)? + kind)?);
        }
        outs.push((kind as usize, at_terms));
        o += 2 + terms;
    }
    Some((ends, conns, outs))
}

/// Steps `steps`, each its row of the header's control columns in `u`, its row of the header's outputs written to `y`.
/// -> 0, or where and why it stopped: -(1 + the step) * 8 - the reason (1 a flute's jet at rest, 2 its delay under two
/// steps, 3 its memory too short for its delay, 4 its dipole's sources past its delay); -1 where the body's places lie
/// outside its arrays.
pub fn steps(i: &mut [i64], d: &mut [f64], u: &[f64], y: &mut [f64], steps: usize) -> i64 {
    stepped(i, d, u, y, steps, false)
}

/// The same, its bore stepped in singles (Mirror): its connectors, its ends and its no-flow pressures in doubles still.
pub fn steps_single(i: &mut [i64], d: &mut [f64], u: &[f64], y: &mut [f64], steps: usize) -> i64 {
    stepped(i, d, u, y, steps, true)
}

fn stepped(i: &mut [i64], d: &mut [f64], u: &[f64], y: &mut [f64], steps: usize, single: bool) -> i64 {
    let Some(mut body) = Decoded::of(i, d.len()) else { return -1 };
    if u.len() < steps * body.cols || y.len() < steps * body.nouts {
        return -1;
    }
    let mut mirror = if single { body.bore.map(|b| Mirror::of(i, d, b, &body.groups)) } else { None };
    let status = unsafe { body.run(i, d, mirror.as_mut(), None, u, y, steps) };
    if let Some(m) = mirror {
        m.back(d);
    }
    // (A flute's memory as far as it has filled, kept in its record for the next call.)
    for (c, conn) in body.conns.iter().enumerate() {
        if conn.kind == T_FLUTE {
            i[at(i[H_CONNS]) + c * CONN_REC + C_MEMLEN] = conn.memlen;
        }
    }
    status
}

/// A body decoded once: its header's counts, its ends, connectors and outputs, its bore's place, ends and groups --
/// every place checked (decoded, bore_fits), so that its steps read and write without a check at each.
struct Decoded {
    npipes: usize,
    nouts: usize,
    cols: usize,
    pipes: usize,
    bore: Option<usize>,
    ends: Vec<End>,
    conns: Vec<Conn>,
    outs: Vec<(usize, Vec<usize>)>,
    bore_ends: Vec<usize>,
    groups: Vec<Group>,
}

impl Decoded {
    fn of(i: &[i64], nd: usize) -> Option<Decoded> {
        if i.len() < H_UCOLS + 1 {
            return None;
        }
        let (npipes, nouts, cols) = (usize::try_from(i[H_NPIPES]).ok()?, usize::try_from(i[H_NOUTS]).ok()?, usize::try_from(i[H_UCOLS]).ok()?);
        let bore = if i[H_BORE] >= 0 { Some(at(i[H_BORE])) } else { None };
        if bore.is_some_and(|b| !bore_fits(i, nd, b)) {
            return None;
        }
        let (ends, conns, outs) = decoded(i, nd, cols)?;
        let (bore_ends, groups) = bore.map_or(Some((vec![], vec![])), |b| bore_decoded(i, b, ends.len()))?;
        Some(Decoded { npipes, nouts, cols, pipes: at(i[H_PIPES]), bore, ends, conns, outs, bore_ends, groups })
    }

    /// `steps` steps on the body `i`, `d` this was decoded from, its bore in `mirror` where it is stepped in singles.
    ///
    /// # Safety
    /// `i` and `d` are the arrays this was decoded from, unchanged in their layout since, and `mirror` (where given) the
    /// mirror of their bore; `u` and `y` hold `steps` rows.
    unsafe fn run(&mut self, i: &[i64], d: &mut [f64], mirror: Option<&mut Mirror>, tract: Option<&mut Tract>, u: &[f64], y: &mut [f64],
                  steps: usize) -> i64 {
        let (dp, nd) = (d.as_mut_ptr(), d.len());
        let (cols, nouts, pipes, npipes) = (self.cols, self.nouts, self.pipes, self.npipes);
        let (bore_ends, groups) = (self.bore_ends.as_slice(), self.groups.as_slice());
        match (self.bore, mirror) {
            (Some(b), Some(m)) => {
                let view = m.bore(i, dp, b);
                step_all(i, dp, nd, u, y, steps, cols, nouts, Some((&view, bore_ends, groups)), pipes, npipes, &self.ends, &mut self.conns, &self.outs, tract)
            }
            (Some(b), None) => {
                let view = Bore::in_d(i, dp, b, groups);
                step_all(i, dp, nd, u, y, steps, cols, nouts, Some((&view, bore_ends, groups)), pipes, npipes, &self.ends, &mut self.conns, &self.outs, tract)
            }
            (None, _) => step_all::<f64>(i, dp, nd, u, y, steps, cols, nouts, None, pipes, npipes, &self.ends, &mut self.conns, &self.outs, tract),
        }
    }
}

/// A body played for as long as it is played (research/OPENWIND_REALTIME_PLAN.md, design 3): decoded once, its bore's
/// singles kept between blocks where it is stepped in singles, each block's controls a row a step -- the live host's
/// and, from stage 7, the renders'. Its arrays its own.
pub struct Player {
    i: Vec<i64>,
    d: Vec<f64>,
    body: Decoded,
    mirror: Option<Mirror>,
    /// Its player's vocal tract, upstream of its reed (tract.rs); none, a mouth's pressure alone.
    pub tract: Option<Tract>,
    // (Its bore's parts and the threads stepping them, where it is stepped on several cores: parallel.rs.)
    #[cfg(any(not(target_arch = "wasm32"), feature = "threads"))]
    crew: Option<parallel::Crews>,
    // (Its slide, where it has one: Player::slide_on.)
    slide: Option<Slide>, points: Option<Box<Points>>,
    // (Its output of the flow its reed or lips let into its bore, where it was asked for: Player::breathing.)
    air: Option<usize>,
}

/// A slide's pipe as laid out at its first position, and where its stretching is written (Player::stretch): its elements
/// (each its group and its place there; and in a crew, its part and where its two blocks begin in that part's data), their
/// two blocks one after the other as laid out, p_to_v's and v_to_p_noflow's; its ends, each where its alpha is and its
/// alpha as laid out; the connectors at its ends; the connectors' step; and the stretch it stands at.
struct Slide {
    elements: Vec<(usize, usize)>,
    placed: Vec<(usize, usize, usize)>,
    blocks: Vec<f64>,
    ends: Vec<(usize, f64)>,
    joins: Vec<Join>,
    dt: f64,
    s: f64,
    scaled: Vec<f64>,
}

/// A connector at a slide's end: its kind, its block, where its two ends' alphas are, its discontinuity's mass, and its
/// block's coefficients as laid out (a simple junction's one, a discontinuity's Step and Infl).
struct Join {
    kind: i64,
    blk: usize,
    alphas: [usize; 2],
    mass: f64,
    laid: [f64; 3],
}

impl Join {
    /// Its coefficients at its ends' alphas `a1`, `a2`, as OpenWInD computes them (tsimplejunction.py
    /// _precompute_coefficients; tjunction.py TemporalJunctionDiscontinuity._precompute_constants, in numpy's order).
    fn coefficients(&self, a1: f64, a2: f64, dt: f64) -> [f64; 3] {
        if self.kind == T_SIMPLE {
            return [1.0 / (a1 + a2), 0.0, 0.0];
        }
        let (m1, m2) = (dt / (2.0 * a1), dt / (2.0 * a2));
        let a_g = -(1.0 / m1) * -1.0 + (1.0 / m2) * 1.0;
        let inv = 1.0 / (self.mass + dt * dt / 4.0 * a_g);
        let c = -dt / 2.0 * inv;
        [inv * self.mass, c * -1.0, c * 1.0]
    }

    /// Its coefficients' count in its block (a discontinuity's gamma, after them, its state).
    fn width(&self) -> usize {
        if self.kind == T_SIMPLE { 1 } else { 3 }
    }
}

impl Player {
    /// A player of the laid-out body `i`, `d` (openwind_compiled.py Compiled's, saved by openwind_bodies.py), its bore in
    /// singles where `single`. -> None where its places lie outside its arrays.
    pub fn new(i: Vec<i64>, d: Vec<f64>, single: bool) -> Option<Player> {
        let body = Decoded::of(&i, d.len())?;
        let mirror = if single { body.bore.map(|b| Mirror::of(&i, &d, b, &body.groups)) } else { None };
        Some(Player { i, d, body, mirror, tract: None, #[cfg(any(not(target_arch = "wasm32"), feature = "threads"))] crew: None, slide: None, points: None, air: None })
    }

    /// Its slide (body.rs SlideHeader) taken up, at its first position: each place it names checked -- its elements among
    /// its bore's groups, its ends among the bore's ends, its connectors simple junctions or discontinuities at one of
    /// them -- and what it stretches kept as laid out. -> why not, where it is not this body's.
    pub fn slide_on(&mut self, header: &crate::body::SlideHeader) -> Result<(), String> {
        let groups = &self.body.groups;
        if header.elements.is_empty() || !(header.dt > 0.0 && header.length > 0.0 && header.most >= 0.0 && header.most.is_finite()) {
            return Err("no elements, or its step, length or reach not a length".into());
        }
        let mut blocks = Vec::new();
        for &[g, e] in &header.elements {
            let Some(group) = groups.get(g).filter(|group| e < group.count) else { return Err(format!("no element {e} of group {g}")) };
            let size = group.w * group.w;
            blocks.extend_from_slice(&self.d[group.a + e * size..group.a + (e + 1) * size]);
            blocks.extend_from_slice(&self.d[group.b + e * size..group.b + (e + 1) * size]);
        }
        if header.ends[0] == header.ends[1] || !header.ends.iter().all(|k| self.body.bore_ends.contains(k)) {
            return Err(format!("its ends {:?} are not two of its bore's", header.ends))
        }
        let ends = header.ends.iter().map(|&k| (self.body.ends[k].alpha, self.d[self.body.ends[k].alpha])).collect();
        let mut joins = Vec::new();
        for join in &header.joins {
            let Some(conn) = self.body.conns.get(join.conn) else { return Err(format!("no connector {}", join.conn)) };
            if !matches!(conn.kind, T_SIMPLE | T_DISCONTINUITY) || !conn.e[..2].iter().any(|k| header.ends.contains(k)) || !(join.mass >= 0.0) {
                return Err(format!("connector {} is not a simple junction or a discontinuity at its ends", join.conn));
            }
            let laid = [self.d[conn.blk], if conn.kind == T_SIMPLE { 0.0 } else { self.d[conn.blk + 1] }, if conn.kind == T_SIMPLE { 0.0 } else { self.d[conn.blk + 2] }];
            joins.push(Join { kind: conn.kind, blk: conn.blk, alphas: [self.body.ends[conn.e[0]].alpha, self.body.ends[conn.e[1]].alpha], mass: join.mass, laid });
        }
        let elements: Vec<(usize, usize)> = header.elements.iter().map(|&[g, e]| (g, e)).collect();
        #[allow(unused_mut)]
        let mut placed = Vec::new();
        #[cfg(any(not(target_arch = "wasm32"), feature = "threads"))]
        if let Some(crew) = &self.crew {
            for &(g, e) in &elements {
                placed.push(crew.element_at(g, e).ok_or_else(|| format!("element {e} of group {g} in none of its parts"))?);
            }
        }
        let scaled = vec![0.0; blocks.len()];
        self.slide = Some(Slide { elements, placed, blocks, ends, joins, dt: header.dt, s: 1.0, scaled });
        Ok(())
    }

    /// Its slide's pipe stretched to `s` times its length at first position (its slide drawn out (s - 1) of it): each of
    /// its elements' masses and losses s times theirs, so its two blocks (p_to_v and v_to_p_noflow) and its ends' alphas
    /// 1/s times theirs, every ratio of them -- the rest of its coefficients -- as they were, and the connectors at its ends
    /// computed again from the alphas (claude-scratch/dials/slide/coefficients.py: OpenWInD's own pipe meshed in as many
    /// elements at that length, within 1e-15). At 1, its laid-out values themselves. Nothing without a slide.
    pub fn stretch(&mut self, s: f64) {
        let Some(slide) = self.slide.as_mut() else { return };
        if s == slide.s || !(s > 0.0 && s.is_finite()) {
            return;
        }
        slide.s = s;
        let laid = s == 1.0;
        let inv = 1.0 / s;
        for (x, &b) in slide.scaled.iter_mut().zip(&slide.blocks) {
            *x = if laid { b } else { b * inv };
        }
        let groups = &self.body.groups;
        let mut at = 0;
        for (k, &(g, e)) in slide.elements.iter().enumerate() {
            let group = groups[g];
            let size = group.w * group.w;
            let (a, b) = (&slide.scaled[at..at + size], &slide.scaled[at + size..at + 2 * size]);
            self.d[group.a + e * size..group.a + (e + 1) * size].copy_from_slice(a);
            self.d[group.b + e * size..group.b + (e + 1) * size].copy_from_slice(b);
            if let Some(m) = self.mirror.as_mut() {
                let (ma, mb) = m.groups[g];
                for (x, &v) in m.data[ma + e * size..ma + (e + 1) * size].iter_mut().zip(a) {
                    *x = v as f32;
                }
                for (x, &v) in m.data[mb + e * size..mb + (e + 1) * size].iter_mut().zip(b) {
                    *x = v as f32;
                }
            }
            #[cfg(any(not(target_arch = "wasm32"), feature = "threads"))]
            if let (Some(crew), Some(&(part, pa, pb))) = (self.crew.as_mut(), slide.placed.get(k)) {
                // (Between its steps: no worker steps meanwhile -- each is waited for before Crew::run returns.)
                unsafe {
                    crew.put(part, pa, a);
                    crew.put(part, pb, b);
                }
            }
            #[cfg(all(target_arch = "wasm32", not(feature = "threads")))]
            let _ = k;
            at += 2 * size;
        }
        let mut put = |d: &mut [f64], place: usize, value: f64| {
            d[place] = value;
            #[cfg(any(not(target_arch = "wasm32"), feature = "threads"))]
            if let Some(crew) = self.crew.as_mut() {
                unsafe { crew.put_d(place, value) };
            }
        };
        for &(place, alpha) in &slide.ends {
            put(&mut self.d, place, if laid { alpha } else { alpha * inv });
        }
        for join in &slide.joins {
            let values = if laid { join.laid } else { join.coefficients(self.d[join.alphas[0]], self.d[join.alphas[1]], slide.dt) };
            for (c, &v) in values.iter().enumerate().take(join.width()) {
                put(&mut self.d, join.blk + c, v);
            }
        }
    }

    /// The stretch its slide stands at: 1 at its first position, or without a slide.
    pub fn stretched(&self) -> f64 {
        self.slide.as_ref().map_or(1.0, |s| s.s)
    }

    /// The same, stepped on `threads` cores (parallel.rs): its bore split by whole pipes among them, bit for bit as on
    /// one -- for a body one core steps slower than it sounds. On one where its bore does not split (no bore, too few
    /// pipes, a lossless pipe), where `threads` is 1, or in a page's WebAssembly built without threads.
    pub fn with_threads(i: Vec<i64>, d: Vec<f64>, single: bool, threads: usize) -> Option<Player> {
        Player::made(i, d, single, threads, false)
    }

    /// The same, an output after its body's own besides: the flow at its reed's or its lips' end (m^3/s, as it leaves
    /// the bore, as an exit's is recorded: what they let in, its negative), the sum of what each records, as its sound
    /// is -- the air its player spends (stream.rs air). None added where it has neither (a flute's jet: stream.rs JetAir).
    pub fn breathing(i: Vec<i64>, d: Vec<f64>, single: bool, threads: usize) -> Option<Player> {
        Player::made(i, d, single, threads, true)
    }

    fn made(i: Vec<i64>, d: Vec<f64>, single: bool, threads: usize, air: bool) -> Option<Player> {
        let mut player = Player::new(i, d, single)?;
        // (Before its crew is made, which takes its outputs' terms from its parts: parallel.rs Crews::of.)
        let terms: Vec<usize> = player.body.conns.iter().filter(|c| matches!(c.kind, T_REED | T_LIPS) && c.rec != NONE).map(|c| c.rec).collect();
        if air && !terms.is_empty() {
            player.air = Some(player.body.nouts);
            player.body.outs.push((0, terms));
            player.body.nouts += 1;
        }
        #[cfg(any(not(target_arch = "wasm32"), feature = "threads"))]
        if threads > 1 {
            player.crew = parallel::Crews::of(&player.i, &player.d, &player.body, single, threads);
            // (Its singles the parts' own.)
            if player.crew.is_some() {
                player.mirror = None;
            }
        }
        #[cfg(all(target_arch = "wasm32", not(feature = "threads")))]
        let _ = threads;
        Some(player)
    }

    /// The cores it is stepped on.
    pub fn threads(&self) -> usize {
        #[cfg(any(not(target_arch = "wasm32"), feature = "threads"))]
        if let Some(crew) = &self.crew {
            return crew.threads();
        }
        1
    }

    /// Its control columns, and its outputs, a step.
    pub fn columns(&self) -> (usize, usize) {
        (self.body.cols, self.body.nouts)
    }

    /// Which of its outputs is the flow into its bore, where it was asked for and it has a reed or lips (breathing).
    pub fn air(&self) -> Option<usize> {
        self.air
    }

    /// `steps` more steps, each its row of controls in `u`, its outputs a row of `y`. -> as `steps` (above); -1 where `u`
    /// or `y` holds too few rows.
    pub fn steps(&mut self, u: &[f64], y: &mut [f64], steps: usize) -> i64 {
        if u.len() < steps * self.body.cols || y.len() < steps * self.body.nouts {
            return -1;
        }
        #[cfg(any(not(target_arch = "wasm32"), feature = "threads"))]
        if let Some(crew) = self.crew.as_mut() {
            return unsafe { crew.run(&self.i, &mut self.d, &mut self.body, self.tract.as_mut(), u, y, steps) };
        }
        unsafe { self.body.run(&self.i, &mut self.d, self.mirror.as_mut(), self.tract.as_mut(), u, y, steps) }
    }
}

#[inline(always)]
unsafe fn p_no_flow_at(dp: *const f64, e: &End) -> f64 {
    if e.half == NONE { *dp.add(e.pnf) } else { *dp.add(e.pnf) - *dp.add(e.half) / 2.0 }
}

#[inline(always)]
unsafe fn q_nph_at(dp: *const f64, e: &End) -> f64 {
    p_no_flow_at(dp, e) - *dp.add(e.alpha) * *dp.add(e.w)
}

/// A connector's step (`conn` it, `row` its step's controls, `tract` its player's where it is a reed's, `s` the step):
/// its ends' no-flow pressures read, their flows set, its own block stepped with them. -> 0, or where and why it stopped
/// (steps). Each connector reads and writes only its own ends and block, so that the connectors may be stepped in any
/// order, on any thread (parallel.rs).
///
/// # Safety
/// As step_all.
#[inline(always)]
unsafe fn connect(conn: &mut Conn, ends: &[End], dp: *mut f64, row: *const f64, mut tract: Option<&mut Tract>, s: usize) -> i64 {
    macro_rules! d {
        ($k:expr) => { *dp.add($k) };
    }
    let blk = conn.blk;
    let e1 = ends.get_unchecked(conn.e[0]);
    match conn.kind {
        T_SIMPLE => {
            let e2 = ends.get_unchecked(conn.e[1]);
            let flow = d!(blk) * (p_no_flow_at(dp, e2) - p_no_flow_at(dp, e1));
            d!(e1.w) = -flow;
            d!(e2.w) = flow;
        }
        T_TJOINT => {
            // d: Step (2x2), Infl (2x3), gamma (2)
            let (e2, e3) = (ends.get_unchecked(conn.e[1]), ends.get_unchecked(conn.e[2]));
            let pc = [p_no_flow_at(dp, e1), p_no_flow_at(dp, e2), p_no_flow_at(dp, e3)];
            let mut gb = [0.0f64; 2];
            for (r, g) in gb.iter_mut().enumerate() {
                let a = d!(blk + 2 * r) * d!(blk + 10) + d!(blk + 2 * r + 1) * d!(blk + 11);
                let b = d!(blk + 4 + 3 * r) * pc[0] + d!(blk + 4 + 3 * r + 1) * pc[1] + d!(blk + 4 + 3 * r + 2) * pc[2];
                *g = a + b;
            }
            d!(blk + 10) = 2.0 * gb[0] - d!(blk + 10);
            d!(blk + 11) = 2.0 * gb[1] - d!(blk + 11);
            d!(e1.w) = -gb[0];
            d!(e2.w) = -gb[1];
            d!(e3.w) = gb[0] + gb[1];
        }
        T_CROSS => {
            // d: Step (3x3), Infl (3x4), gamma (3) -- its ends the bore in, the bore out, the upstream hole and the
            // downstream one; its variables the upstream joint's flow on the bore in, the flow through the slice between
            // the holes, the downstream joint's on the bore out; each end's flow -T^t gamma_b (openwind_bodies.py
            // TemporalCross, T_CROSS).
            let (e2, e3, e4) = (ends.get_unchecked(conn.e[1]), ends.get_unchecked(conn.e[2]), ends.get_unchecked(conn.e[3]));
            let pc = [p_no_flow_at(dp, e1), p_no_flow_at(dp, e2), p_no_flow_at(dp, e3), p_no_flow_at(dp, e4)];
            let mut gb = [0.0f64; 3];
            for (r, g) in gb.iter_mut().enumerate() {
                let a = d!(blk + 3 * r) * d!(blk + 21) + d!(blk + 3 * r + 1) * d!(blk + 22) + d!(blk + 3 * r + 2) * d!(blk + 23);
                let b = d!(blk + 9 + 4 * r) * pc[0] + d!(blk + 9 + 4 * r + 1) * pc[1] + d!(blk + 9 + 4 * r + 2) * pc[2]
                    + d!(blk + 9 + 4 * r + 3) * pc[3];
                *g = a + b;
            }
            for (r, g) in gb.iter().enumerate() {
                d!(blk + 21 + r) = 2.0 * g - d!(blk + 21 + r);
            }
            d!(e1.w) = -gb[0];
            d!(e2.w) = -gb[2];
            d!(e3.w) = gb[0] + gb[1];
            d!(e4.w) = gb[2] - gb[1];
        }
        T_DISCONTINUITY => {
            // d: Step (1), Infl (1x2), gamma (1)
            let e2 = ends.get_unchecked(conn.e[1]);
            let gb = d!(blk) * d!(blk + 3) + (d!(blk + 1) * p_no_flow_at(dp, e1) + d!(blk + 2) * p_no_flow_at(dp, e2));
            d!(blk + 3) = 2.0 * gb - d!(blk + 3);
            d!(e1.w) = gb;
            d!(e2.w) = -gb;
        }
        T_SWITCH => {
            // d: its opening, dt, Infl (3) -- its gamma moved by nothing of its own (Step, M_J's, 0): gamma_b = Infl . P,
            // each end's flow -T gamma_b. Its opening taken from the row at every change (as a hole's, below).
            let (e2, e3) = (ends.get_unchecked(conn.e[1]), ends.get_unchecked(conn.e[2]));
            if conn.u != NONE {
                let phi = *row.add(conn.u);
                if phi != d!(blk + S_PHI) {
                    d!(blk + S_PHI) = phi;
                    switch_coefficients(std::slice::from_raw_parts_mut(dp.add(blk), S_INFL + 3), [d!(e1.alpha), d!(e2.alpha), d!(e3.alpha)]);
                }
            }
            let gb = d!(blk + S_INFL) * p_no_flow_at(dp, e1) + d!(blk + S_INFL + 1) * p_no_flow_at(dp, e2) + d!(blk + S_INFL + 2) * p_no_flow_at(dp, e3);
            let phi = d!(blk + S_PHI);
            d!(e1.w) = -gb;
            d!(e2.w) = phi * gb;
            d!(e3.w) = -(phi - 1.0) * gb;
        }
        T_RADIATION => {
            // (Its opening taken from the row at every change. OpenWInD's set_opening_factor takes one only once it has
            // moved by 1e-5 -- "Only update the factor if it changed significantly : too expensive" -- and so did this,
            // after it: a fingering eased across a change then stopped up to 1e-5 short of where it went, by as much as
            // the path the fingers took left, and a note sounded otherwise after another note than from rest -- the
            // clarinet's written C4 0.25 c higher after its C6, 0.95 c at half the step: no physics (KNOWN_ISSUES
            // MB-WIND-011). As openwind_kernel.c and openwind_kernel_fast.c, and OpenWInD's own components
            // (openwind_worker.py openings_kept), to the bit.)
            if conn.u != NONE {
                let phi = *row.add(conn.u);
                if phi != d!(blk + R_PHI) {
                    d!(blk + R_PHI) = phi;
                    radiation_coefficients(std::slice::from_raw_parts_mut(dp.add(blk), R_KAPPA + 1));
                }
            }
            let pc = p_no_flow_at(dp, e1);
            let zeta = d!(blk + R_ZETA);
            if d!(blk + R_KAPPA) > 0.0 {
                // (Its edge's jet loss in series with its radiation, p = rho C v|v| (openwind_worker.py
                // edge_losses): its flow out w by its stable root; its radiation then driven by what the loss
                // leaves.)
                let phi = d!(blk + R_PHI);
                let (alpha, beta) = (d!(blk + R_A) * phi, d!(blk + R_BETA) * (phi * phi));
                let (half_dt, zplus) = (d!(blk + R_HALFDT), d!(blk + R_ZPLUS));
                let rt_alpha = alpha.sqrt();
                let kk = (beta + half_dt * alpha) / zplus;
                let drive = -rt_alpha * zeta + kk * pc;
                let aa = 1.0 + kk * d!(e1.alpha);
                let bb = kk * d!(blk + R_KAPPA);
                let w = 2.0 * drive / (aa + (aa * aa + 4.0 * bb * drive.abs()).sqrt());
                let pr = if kk > 0.0 { (w + rt_alpha * zeta) / kk } else { 0.0 };
                let zeta_b = zeta - half_dt * rt_alpha / zplus * pr;
                d!(blk + R_ZETA) = 2.0 * zeta_b - zeta;
                d!(e1.w) = w;
            } else {
                let zeta_b = d!(blk + R_STEP) * zeta + d!(blk + R_INFL) * pc;
                d!(blk + R_ZETA) = 2.0 * zeta_b - zeta;
                d!(e1.w) = -(d!(blk + R_ZTOF) * zeta_b + d!(blk + R_PTOF) * pc);
            }
            if conn.rec != NONE {
                d!(conn.rec) = d!(e1.w) * d!(blk + R_FLOWSCALE);
                d!(conn.rec + 1) = q_nph_at(dp, e1) * d!(blk + R_PRESSSCALE);
            }
        }
        T_REED | T_LIPS => {
            // u: gamma, zeta, kappa, Qr, omegar, Kc, alpha_c, epsilon, Pclosed; lips' then ratio, Q2, coupling
            let q = row.add(conn.u);
            let (mut gamma, zeta, kappa, qr, omegar, kc, alpha_c, epsilon, pclosed) =
                (*q, *q.add(1), *q.add(2), *q.add(3), *q.add(4), *q.add(5), *q.add(6), *q.add(7), *q.add(8));
            // (The mouth's pressure less its tract's answer to the flow a step before: tract.rs.)
            if let Some(t) = tract.as_deref() {
                gamma -= t.pressure() / pclosed;
            }
            let theta = d!(blk + Q_THETA);
            let dt_scaled = omegar * d!(blk + Q_DT);
            let (last_y, this_y) = (d!(blk + Q_LASTY), d!(blk + Q_THISY));
            // (Its contact's variable kept to its stiffness: z brought to a new Kc at its y before it is
            // stepped -- openwind_kernel.c.)
            let mut prev_z = d!(blk + Q_PREVZ);
            // (Its lay's part of what its contact's variable holds, where its lay stiffens it: none of its tip's.)
            let (lay, lay_held) = if conn.lay { lay_contact(d!(blk + Q_LAYONSET), d!(blk + Q_LAYSTIFFNESS), d!(blk + Q_LAYEXPONENT), d!(blk + Q_LAYGAIN), d!(blk + Q_LAYOPENING), this_y) } else { (None, 0.0) };
            // (Its slit and the flow its reed's own motion drives, as wide as its opening at rest is of its rules'.)
            let (zeta, kappa) = match lay {
                Some(l) => (zeta * l.opening, kappa * l.opening),
                None => (zeta, kappa),
            };
            if d!(blk + Q_LASTKC) > 0.0 && kc != d!(blk + Q_LASTKC) {
                let stored = prev_z * prev_z - d!(blk + Q_CONTACT) - lay_held;
                prev_z = (d!(blk + Q_CONTACT) + (if stored > 0.0 { stored } else { 0.0 }) * kc / d!(blk + Q_LASTKC) + lay_held).sqrt();
            }
            d!(blk + Q_LASTKC) = kc;
            let p_scaling = pclosed / d!(blk + Q_SP);
            let flow_scaling = pclosed / d!(blk + Q_ZC) / d!(blk + Q_SF);
            let pnf = p_no_flow_at(dp, e1) / p_scaling;
            let a_lambda = d!(blk + Q_ZC) / (d!(e1.alpha) * d!(blk + Q_SIMP));
            let yn_minus = abs_negative_part(this_y);
            let contact = d!(blk + Q_CONTACT);
            // (Its contact's variable taken again from its opening at every step its tip is open: what it stands in for
            // there, the root of its contact's constant and twice its lay's potential half a step ago -- of its
            // constant alone where it has no lay with stiffness, as it rests (openwind_bodies.py contact_started). Carried
            // from step to step it drifts, by no physics: OpenWInD's step advances it by a centred estimate of its
            // change, whose error, of the second order in the step, each touch leaves in it, nothing taking it out --
            // the step halved, its drift a quarter as fast. A reed on its lay touches it through every cycle: a held
            // note's lay's force stood 1.6 of its law after ten seconds, its pitch 20 c up. A reed of one spring, or
            // lips, only as they beat: an oboe's held ff note rose 1.5 c in eight seconds, and sounded 2.2 c higher
            // after another note than before it (KNOWN_ISSUES MB-WIND-011). While its tip is in contact, OpenWInD's own
            // step; as openwind_kernel.c and openwind_kernel_fast.c, and OpenWInD's own loop (openwind_worker.py
            // contact_kept), to the bit -- a lay of no stiffness as no lay.)
            if this_y >= 0.0 && last_y >= 0.0 {
                let held = if lay.is_some() {
                    lay_contact(d!(blk + Q_LAYONSET), d!(blk + Q_LAYSTIFFNESS), d!(blk + Q_LAYEXPONENT), d!(blk + Q_LAYGAIN), d!(blk + Q_LAYOPENING), 0.5 * (this_y + last_y)).1
                } else {
                    0.0
                };
                prev_z = (contact + held).sqrt();
            }
            // (Its contact's force, nothing while the reed is open.)
            let h_yn = if contact == 0.0 {
                if yn_minus == 0.0 && alpha_c > 1.0 { 0.0 } else { -0.5 * (2.0 * kc * (alpha_c + 1.0)).sqrt() * yn_minus.powf(alpha_c / 2.0 - 0.5) }
            } else if yn_minus == 0.0 && alpha_c > 0.0 {
                0.0
            } else {
                -kc * yn_minus.powf(alpha_c) / (contact + 2.0 * kc / (alpha_c + 1.0) * yn_minus.powf(alpha_c + 1.0)).sqrt()
            };
            // (Its lay's force with its tip's, and the gain its own spring then answers the pressure with: a reed's alone.)
            let (h_yn, gain) = match lay {
                Some(l) => (lay_force(l, kc, alpha_c, yn_minus, contact, lay_held), l.gain),
                None => (h_yn, 1.0),
            };
            let dt2 = dt_scaled * dt_scaled;
            // (In contact, critically damped by its contact's stiffness, none at a touch: it lands without bouncing.)
            let a_yn = 1.0 / (1.0 / dt2 + 1.0 / (2.0 * qr * dt_scaled)
                + (if yn_minus > 0.0 { 2.0 * (alpha_c * kc * yn_minus.powf(alpha_c - 1.0)).sqrt() / (2.0 * dt_scaled) } else { 0.0 })
                + theta + 0.25 * (h_yn * h_yn));
            let b1_y = 2.0 / dt2 + 2.0 * theta - 1.0;
            let b2_y = -1.0 * (2.0 / dt2 + 2.0 * theta);
            let b3_y = 1.0 - h_yn * prev_z;
            let b_yn = a_yn * (b1_y * this_y + b2_y * last_y + b3_y);
            // (Brass lips' inward mode, where they have one (openwind_kernel_fast.c T_LIPS): its own theta-scheme, from
            // rest at 0, its share of the flow the lips sweep and of their opening. A reed's step as it was.)
            let lips = conn.kind == T_LIPS;
            let (this_q, last_q, ratio, coupling) =
                if lips { (d!(blk + Q_THISQ), d!(blk + Q_LASTQ), *q.add(U_RATIO), *q.add(U_COUPLING)) } else { (0.0, 0.0, 0.0, 0.0) };
            let a_q = if lips { 1.0 / (1.0 / dt2 + ratio / (2.0 * *q.add(U_QFACTOR2) * dt_scaled) + theta * (ratio * ratio)) } else { 0.0 };
            let b_q = if lips {
                a_q * (this_q * (2.0 / dt2 - (ratio * ratio) * (1.0 - 2.0 * theta)) + last_q * (-2.0 / dt2 - 2.0 * theta * (ratio * ratio)))
            } else {
                0.0
            };
            // (Its slit's area as its opening leaves it: OpenWInD's, or a double reed's, the opening's power and a
            // leak -- openwind_worker.py reed_law.)
            let opened = positive_part(if lips { this_y + this_q } else { this_y });
            let (exponent, leak, constriction) = (d!(blk + Q_EXPONENT), d!(blk + Q_LEAK), d!(blk + Q_CONSTRICTION));
            let slit = (if exponent == 1.0 && leak == 0.0 { opened } else { opened.powf(exponent) + leak }) * zeta;
            let cn = if lips {
                a_lambda * (pnf - gamma) + (epsilon * b_yn + d!(blk + Q_MODEL2) * d!(blk + Q_SHARE) * b_q) * kappa / (2.0 * dt_scaled)
            } else {
                a_lambda * (pnf - gamma) + epsilon * b_yn * kappa / (2.0 * dt_scaled)
            };
            // (And a double reed's staple recovering pressure past its constriction, where the flow is forward (cn < 0):
            // the drop across its slit k of the whole's, its flow sqrt(1/k) of the bare slit's, its blades driven by
            // dp/k -- openwind_worker.py slit_law. Elsewhere k 1, a division by 1: exact.)
            let c2 = if !lips && constriction != 0.0 && cn < 0.0 { constriction * pclosed * slit * slit } else { 0.0 };
            let kr = if c2 != 0.0 {
                let recovery = d!(blk + Q_RECOVERY);
                if c2 <= 1.0 { 1.0 - recovery * c2 } else { c2 * (1.0 - recovery) }
            } else {
                1.0
            };
            let an = if lips {
                a_lambda + (a_yn + d!(blk + Q_SHARE) * coupling * a_q) * kappa / (2.0 * dt_scaled)
            } else {
                a_lambda + gain * a_yn * kappa / (2.0 * dt_scaled) / kr
            };
            let bn = slit / kr.sqrt();
            let discr = bn * bn + 4.0 * an * cn.abs();
            let root_poly = (-bn + discr.sqrt()) / (2.0 * an);
            let delta_p = -sign(cn) * (root_poly * root_poly);
            let delta_y = b_yn + epsilon * (gain * a_yn) * delta_p / kr;
            d!(e1.w) = a_lambda * (delta_p + pnf - gamma) * flow_scaling;
            // (Its end's flow out of the bore: the flow from the mouth its negative.)
            if let Some(t) = tract.as_deref_mut() {
                t.take(-d!(e1.w) * d!(blk + Q_FLOWSCALE));
            }
            d!(blk + Q_THISY) = delta_y + last_y;
            d!(blk + Q_LASTY) = this_y;
            d!(blk + Q_PREVZ) = 0.5 * h_yn * delta_y + prev_z;
            if lips {
                d!(blk + Q_THISQ) = b_q + d!(blk + Q_MODEL2) * coupling * a_q * delta_p + last_q;
                d!(blk + Q_LASTQ) = this_q;
            }
            if conn.rec != NONE {
                d!(conn.rec) = d!(e1.w) * d!(blk + Q_FLOWSCALE);
                d!(conn.rec + 1) = q_nph_at(dp, e1) * d!(blk + Q_PRESSSCALE);
            }
        }
        T_FLUTE => {
            // u: Uj, dUj, next_Uj, the jet's noise, its window's opening, its jet's parameters (Ascale, Gj, Gl, C,
            // y0), its presence, its dipole's span
            let q = row.add(conn.u);
            let (uj, d_uj) = (*q, *q.add(1));
            let mut next_uj = *q.add(2);
            if uj < 1e-8 {
                return -(1 + s as i64) * 8 - 1;
            }
            if next_uj < 1e-8 {
                next_uj = uj;
            }
            let (dt, prev_zeta, this_eta, last_eta) = (d!(blk + F_DT), d!(blk + F_PREVZETA), d!(blk + F_THISETA), d!(blk + F_LASTETA));
            let (ascale, gj, gl, cj, y0) = (*q.add(5), *q.add(6), *q.add(7), *q.add(8), *q.add(9));
            let p_scaling = (d!(blk + F_RHO) * d!(blk + F_CELERITY) * uj) / ascale / d!(blk + F_SP);
            let u_scaling = p_scaling / (d!(blk + F_ZC) / d!(blk + F_SIMP));
            let next_tau = cj / next_uj / d!(blk + F_STIME);
            // get_next_eta
            let n = conn.memlen;
            let big_n = (next_tau / dt).floor() as i64;
            let eps = next_tau / dt - big_n as f64;
            if big_n < 2 {
                return -(1 + s as i64) * 8 - 2;
            }
            let n_n = if n - big_n > 0 { n - big_n } else { 0 };
            let n_np1 = if n - big_n + 1 > 0 { n - big_n + 1 } else { 0 };
            // (Its memory a ring of memcap flows, so that a part plays on for as long as it is played: what it
            // reads written at most memcap steps ago, else it is too short for its jet's delay. A ring as long as
            // the run, as the renders lay it out, never wraps: OpenWInD's own memory.)
            let cap = conn.memcap;
            if n_n + cap < n {
                return -(1 + s as i64) * 8 - 3;
            }
            let mut next_eta = (1.0 - eps) * d!(conn.mem + at(n_np1 % cap)) + eps * d!(conn.mem + at(n_n % cap));
            let presence = *q.add(10);
            next_eta += *q.add(3) * presence;
            let big_gamma = (this_eta - y0).tanh();
            // (Its dipole's flow sources on the convected jet, q[11] their distance over twice its disturbance's
            // speed's share of U_j (m; 0 where its dipole is Verge's): its jet's flow split differenced at t + s
            // and t - s, ahead its delay line as next_eta reads it with next_eta's turbulence, behind its own
            // places -- where s is under a step, OpenWInD's own centred difference (openwind_worker.py
            // jet_dipole). Its places a ring of memcap after its flows, at each step's place.)
            let place = conn.mem + at(cap);
            d!(place + at((n + 1) % cap)) = next_eta;
            let span = *q.add(11) / uj / d!(blk + F_STIME) / dt;
            let d_gamma = if span <= 1.0 {
                ((next_eta - y0).tanh() - (last_eta - y0).tanh()) / (2.0 * dt)
            } else {
                if span > next_tau / dt - 2.0 {
                    return -(1 + s as i64) * 8 - 4;
                }
                let ka = (n as f64 + span - next_tau / dt).max(0.0);
                let ia = ka.floor() as i64;
                let ea = ka - ia as f64;
                let ahead = if ea == 0.0 {
                    d!(conn.mem + at(ia % cap))
                } else {
                    (1.0 - ea) * d!(conn.mem + at(ia % cap)) + ea * d!(conn.mem + at((ia + 1) % cap))
                } + *q.add(3) * presence;
                let kb = n as f64 - span;
                let ib = kb.floor() as i64;
                let (eb, jb) = (kb - ib as f64, ib.rem_euclid(cap));
                let behind = if eb == 0.0 {
                    d!(place + at(jb))
                } else {
                    (1.0 - eb) * d!(place + at(jb)) + eb * d!(place + at((jb + 1) % cap))
                };
                ((ahead - y0).tanh() - (behind - y0).tanh()) / (2.0 * span * dt)
            };
            let pnf = p_no_flow_at(dp, e1) / p_scaling;
            let ap = -(d!(e1.alpha) * d!(blk + F_SIMP)) / d!(blk + F_ZC);
            let window = *q.add(4);
            let (alpha_r, beta_r) = (d!(blk + F_ALPHAR) * window, d!(blk + F_BETAR) * (window * window));
            let ar = 1.0 / (beta_r + alpha_r * dt / 2.0);
            let br = alpha_r.sqrt() * ar * prev_zeta;
            let btot = br - pnf;
            let source = presence * gj * (big_gamma * d_uj / uj + d_gamma);
            let (alpha, beta, gamma) = (gl * uj, ar - ap, btot - source);
            let flow = if alpha > 1e-8 || alpha * gamma / (beta * beta) > 1e-6 {
                -1.0 * sign(gamma) * (-beta + (beta * beta + 4.0 * alpha * gamma.abs()).sqrt()) / (2.0 * alpha)
            } else {
                -gamma / beta + sign(gamma) * alpha * (gamma * gamma) / (beta * beta * beta)
            };
            let next_zeta = 2.0 * ar * (beta_r * prev_zeta - dt / 2.0 * alpha_r.sqrt() * flow) - prev_zeta;
            d!(e1.w) = flow * u_scaling;
            if conn.rec != NONE {
                d!(conn.rec) = d!(e1.w) * d!(blk + F_FLOWSCALE);
                d!(conn.rec + 1) = q_nph_at(dp, e1) * d!(blk + F_PRESSSCALE);
            }
            d!(blk + F_PREVZETA) = next_zeta;
            d!(conn.mem + at(n % cap)) = flow;
            conn.memlen = n + 1;
            d!(blk + F_THISETA) = next_eta;
            d!(blk + F_LASTETA) = this_eta;
        }
        _ => {}
    }
    0
}

/// The steps themselves, on the decoded body.
///
/// # Safety
/// `dp` addresses `nd` doubles no one else touches meanwhile, and every place `ends`, `conns` and `outs` name lies within
/// them and `u` (decoded); every view of them below is made from `dp`.
#[allow(clippy::too_many_arguments)]
unsafe fn step_all<T: Real>(i: &[i64], dp: *mut f64, nd: usize, u: &[f64], y: &mut [f64], steps: usize, cols: usize, nouts: usize,
                            bore: Option<(&Bore<T>, &[usize], &[Group])>, pipes: usize, npipes: usize, ends: &[End], conns: &mut [Conn],
                            outs: &[(usize, Vec<usize>)], mut tract: Option<&mut Tract>) -> i64 {
    let up = u.as_ptr();
    let all = || std::slice::from_raw_parts_mut(dp, nd);
    macro_rules! d {
        ($k:expr) => { *dp.add($k) };
    }
    for s in 0..steps {
        let row = up.add(s * cols);
        for conn in conns.iter_mut() {
            let status = connect(conn, ends, dp, row, tract.as_deref_mut(), s);
            if status != 0 {
                return status;
            }
        }
        if let Some((view, bore_ends, groups)) = bore {
            lossy_pipes(i, dp, view, bore_ends, groups, ends);
        }
        for j in 0..npipes {
            lossless_pipe(i, all(), pipes + j * PIPE_REC);
        }
        // What it records: each output a sum of recorded values, in its order (kind 0 a flow, 1 a pressure).
        for (j, (_, terms)) in outs.iter().enumerate() {
            let mut sum = d!(*terms.get_unchecked(0));
            for &t in terms.get_unchecked(1..) {
                sum += d!(t);
            }
            *y.get_unchecked_mut(s * nouts + j) = sum;
        }
    }
    0
}

// ---- Its state read and set between its steps (orbit.rs: a note's oscillation found on the engine itself), here at the
// file's end so that no line above it moves: a page's WebAssembly of the rest built the same, its panics' places with it.
impl Mirror {
    /// Its state taken from `d` (each rounded to the nearest single), as `back` gives it there.
    fn take(&mut self, d: &[f64]) {
        for &(from, to, len, state) in &self.regions {
            if state {
                for (m, &x) in self.data[to..to + len].iter_mut().zip(&d[from..from + len]) {
                    *m = x as f32;
                }
            }
        }
    }
}

impl Player {
    /// Its doubles, its state among its coefficients, as they stand between calls of `steps`: a bore stepped in singles
    /// brought back into them first (Mirror::back), whose singles are its state between calls.
    pub fn data(&mut self) -> &[f64] {
        if let Some(m) = &self.mirror {
            m.back(&mut self.d);
        }
        &self.d
    }

    /// Its doubles set to `d` (laid out as `data` gives them), a bore stepped in singles taken from them.
    pub fn set_data(&mut self, d: &[f64]) {
        self.d.copy_from_slice(d);
        if let Some(m) = self.mirror.as_mut() {
            m.take(&self.d);
        }
    }

    /// Whether its bore is stepped in singles.
    pub fn single(&self) -> bool {
        self.mirror.is_some()
    }

    /// Whether it is stepped by a crew, whose workers keep copies of its doubles of their own (parallel.rs).
    pub fn crewed(&self) -> bool {
        #[cfg(any(not(target_arch = "wasm32"), feature = "threads"))]
        if self.crew.is_some() {
            return true;
        }
        false
    }

    /// Whether a jet's flows are kept in a ring (T_FLUTE: its memory, written at its count of steps, kept in its
    /// connector, not among its doubles).
    pub fn ringed(&self) -> bool {
        self.body.conns.iter().any(|c| c.kind == T_FLUTE)
    }
}

impl Player {
    /// Where its bore's state lies among its doubles, a field at a time (start, length) -- its no-flow pressures with
    /// them: each one quantity, its values sized alike (orbit.rs scales each by its field's largest).
    pub fn fields(&self) -> Vec<(usize, usize)> {
        let Some(b) = self.body.bore else { return vec![] };
        let i = &self.i;
        let (h, l, n) = (at(i[b + B_H]), at(i[b + B_L]), at(i[b + B_N]));
        BORE_STATE.iter().chain(&[B_PNF]).map(|&f| (at(i[b + f]), region_length(f, h, l, n))).collect()
    }
}

impl Player {
    /// Its bore stepped in doubles from here, its singles brought back into them; or in singles again, taken from its
    /// doubles (each rounded to the nearest single). The same steps either way (bore_step's): orbit.rs solves on them in
    /// doubles, where a derivative's nudge is not lost in its singles' rounding.
    pub fn in_doubles(&mut self, doubles: bool) {
        if doubles {
            if let Some(m) = self.mirror.take() {
                m.back(&mut self.d);
            }
        } else if self.mirror.is_none() {
            self.mirror = self.body.bore.map(|b| Mirror::of(&self.i, &self.d, b, &self.body.groups));
        }
    }
}

// ---- Its bore's answer at its reed, and its reed's step alone (starts.rs: where a note starts, found by arithmetic on the
// engine's own equations), here at the file's end so that no line above it moves. ----

// (What its reed's own step carries from one step to the next: this opening, the last, its contact's variable; lips' then
// their inward mode's two. Its tract's (Tract::state) after them, in Player::reed_state.)
const REED_STATE: [usize; 3] = [Q_THISY, Q_LASTY, Q_PREVZ];
const LIPS_STATE: [usize; 5] = [Q_THISY, Q_LASTY, Q_PREVZ, Q_THISQ, Q_LASTQ];

/// Where its reed's controls are in a row (gamma first, then zeta, kappa, Qr, omegar, Kc, alpha_c, epsilon and its closing
/// pressure in Pa), its end's alpha (the bore's pressure there, at once, for a unit of flow out of it), and its scales: a
/// pressure and a flow of the bore's own, in Pa and m^3/s.
#[derive(Clone, Copy, Debug)]
pub struct ReedPlace {
    pub columns: usize,
    pub alpha: f64,
    pub pressure: f64,
    pub flow: f64,
    pub lips: bool,
}

impl Player {
    fn reed_conn(&self) -> Result<usize, String> {
        self.body.conns.iter().position(|c| matches!(c.kind, T_REED | T_LIPS)).ok_or_else(|| "it has no reed or lips".to_string())
    }

    /// Where its reed's controls and scales are (ReedPlace).
    pub fn reed_place(&self) -> Result<ReedPlace, String> {
        let c = self.body.conns[self.reed_conn()?];
        let e = &self.body.ends[c.e[0]];
        Ok(ReedPlace { columns: c.u, alpha: self.d[e.alpha], pressure: self.d[c.blk + Q_PRESSSCALE], flow: self.d[c.blk + Q_FLOWSCALE], lips: c.kind == T_LIPS })
    }

    /// Its reed's state now: its own (REED_STATE's, or LIPS_STATE's), then its tract's (Tract::state), where it has one.
    pub fn reed_state(&self) -> Result<Vec<f64>, String> {
        let c = self.body.conns[self.reed_conn()?];
        let own: &[usize] = if c.kind == T_LIPS { &LIPS_STATE } else { &REED_STATE };
        Ok(own.iter().map(|&k| self.d[c.blk + k]).chain(self.tract.as_ref().map(|t| t.state()).unwrap_or_default()).collect())
    }

    /// Its reed's one step alone at `row`: from `state` (as reed_state gives it), with the bore's no-flow pressure at its end
    /// `pnf` (the bore's units) and nothing else of the bore, its contact's stiffness as the row holds it -> its end's flow
    /// out of the bore (the bore's units) and its state after. The engine's own step (connect); its doubles and its tract
    /// put back as they stood.
    pub fn reed_step(&mut self, row: &[f64], pnf: f64, state: &[f64]) -> Result<(f64, Vec<f64>), String> {
        let k = self.reed_conn()?;
        let mut c = self.body.conns[k];
        let own: &[usize] = if c.kind == T_LIPS { &LIPS_STATE } else { &REED_STATE };
        let tract_len = self.tract.as_ref().map_or(0, |t| t.state().len());
        if row.len() < self.body.cols || state.len() != own.len() + tract_len {
            return Err(format!("a row of {} columns and a state of {}", self.body.cols, own.len() + tract_len));
        }
        let e = self.body.ends[c.e[0]];
        let (size, _, _) = shape_of(c.kind).ok_or("its reed's kind unknown")?;
        let mut places = vec![e.pnf, e.w];
        if e.half != NONE {
            places.push(e.half);
        }
        places.extend(c.blk..c.blk + size);
        if c.rec != NONE {
            places.extend([c.rec, c.rec + 1]);
        }
        let kept: Vec<f64> = places.iter().map(|&p| self.d[p]).collect();
        let tract = self.tract.clone();
        self.d[e.pnf] = pnf;
        if e.half != NONE {
            self.d[e.half] = 0.0;
        }
        for (j, &q) in own.iter().enumerate() {
            self.d[c.blk + q] = state[j];
        }
        self.d[c.blk + Q_LASTKC] = row[c.u + 5];
        if let Some(t) = self.tract.as_mut() {
            t.set_state(&state[own.len()..]);
        }
        let status = unsafe { connect(&mut c, &self.body.ends, self.d.as_mut_ptr(), row.as_ptr(), self.tract.as_mut(), 0) };
        let w = self.d[e.w];
        let after = self.reed_state();
        for (&p, &v) in places.iter().zip(&kept) {
            self.d[p] = v;
        }
        self.tract = tract;
        if status != 0 {
            return Err(format!("its reed's step stopped ({status})"));
        }
        Ok((w, after?))
    }

    /// Its bore's answer at its reed's end: the no-flow pressure there after each step (the bore's units), for a flow `w0` out
    /// of the bore at the first step (a flow in, its negative), its end shut after -- every other connector stepped at
    /// `row` as it plays, the reed's own step left out, and with it the tract's. Read as the difference between the bore
    /// stepped so from its state now and stepped from it with no flow, so that what it still rang with goes; a block of
    /// `block` steps at a time, until the last block's share of the answer's energy is under `quiet` or `most` steps are
    /// read. In doubles (Player::in_doubles), on one thread; its doubles put back as they stood.
    pub fn bore_answer(&mut self, row: &[f64], w0: f64, block: usize, most: usize, quiet: f64) -> Result<Vec<f64>, String> {
        #[cfg(any(not(target_arch = "wasm32"), feature = "threads"))]
        if self.crew.is_some() {
            return Err("its bore's answer is read on one thread".into());
        }
        if self.mirror.is_some() {
            return Err("its bore's answer is read in doubles".into());
        }
        if row.len() < self.body.cols || block == 0 {
            return Err(format!("a row of {} columns, and a block", self.body.cols));
        }
        let k = self.reed_conn()?;
        let e = self.body.ends[self.body.conns[k].e[0]];
        let kept = self.d.clone();
        let mut states = [kept.clone(), kept.clone()];
        let reed = self.body.conns.remove(k);
        let (mut answer, mut energy, mut y) = (Vec::new(), 0.0, vec![0.0; self.body.nouts]);
        let mut status = 0;
        'read: while answer.len() < most {
            let mut runs = [Vec::with_capacity(block), Vec::with_capacity(block)];
            for (r, run) in runs.iter_mut().enumerate() {
                self.d.copy_from_slice(&states[r]);
                for _ in 0..block {
                    self.d[e.w] = if r == 0 && answer.is_empty() && run.is_empty() { w0 } else { 0.0 };
                    status = unsafe { self.body.run(&self.i, &mut self.d, None, None, row, &mut y, 1) };
                    if status != 0 {
                        break 'read;
                    }
                    run.push(unsafe { p_no_flow_at(self.d.as_ptr(), &e) });
                }
                states[r].copy_from_slice(&self.d);
            }
            let last: f64 = runs[0].iter().zip(&runs[1]).map(|(a, b)| (a - b) * (a - b)).sum();
            answer.extend(runs[0].iter().zip(&runs[1]).map(|(a, b)| a - b));
            energy += last;
            if last <= quiet * energy {
                break;
            }
        }
        self.body.conns.insert(k, reed);
        self.d.copy_from_slice(&kept);
        if status != 0 {
            return Err(format!("its bore stopped ({status})"));
        }
        Ok(answer)
    }
}

impl Player {
    /// Its bore stepped `steps` steps at `row` under a steady flow `w` out of it at its reed's end (the bore's units), the
    /// reed's own step left out: its bore brought to what that flow holds it at (starts.rs's check). In doubles, on one
    /// thread; its state left there.
    pub fn bore_steady(&mut self, row: &[f64], w: f64, steps: usize) -> Result<(), String> {
        #[cfg(any(not(target_arch = "wasm32"), feature = "threads"))]
        if self.crew.is_some() {
            return Err("its bore is held on one thread".into());
        }
        if self.mirror.is_some() || row.len() < self.body.cols {
            return Err(format!("in doubles, and a row of {} columns", self.body.cols));
        }
        let k = self.reed_conn()?;
        let e = self.body.ends[self.body.conns[k].e[0]];
        let reed = self.body.conns.remove(k);
        let (mut y, mut status) = (vec![0.0; self.body.nouts], 0);
        for _ in 0..steps {
            self.d[e.w] = w;
            status = unsafe { self.body.run(&self.i, &mut self.d, None, None, row, &mut y, 1) };
            if status != 0 {
                break;
            }
        }
        self.body.conns.insert(k, reed);
        if status != 0 {
            return Err(format!("its bore stopped ({status})"));
        }
        Ok(())
    }

    /// Its reed's state set (as reed_state gives it), its contact's last stiffness `kc`.
    pub fn set_reed_state(&mut self, state: &[f64], kc: f64) -> Result<(), String> {
        let c = self.body.conns[self.reed_conn()?];
        let own: &[usize] = if c.kind == T_LIPS { &LIPS_STATE } else { &REED_STATE };
        let tract_len = self.tract.as_ref().map_or(0, |t| t.state().len());
        if state.len() != own.len() + tract_len {
            return Err(format!("a state of {}", own.len() + tract_len));
        }
        for (j, &q) in own.iter().enumerate() {
            self.d[c.blk + q] = state[j];
        }
        self.d[c.blk + Q_LASTKC] = kc;
        if let Some(t) = self.tract.as_mut() {
            t.set_state(&state[own.len()..]);
        }
        Ok(())
    }
}

impl Player {
    /// The bore's no-flow pressure at its reed's end now (the bore's units).
    pub fn reed_pnf(&self) -> Result<f64, String> {
        let c = self.body.conns[self.reed_conn()?];
        Ok(unsafe { p_no_flow_at(self.d.as_ptr(), &self.body.ends[c.e[0]]) })
    }
}

// ---- Its bore's one step as a linear map, and its reed's constants (starts.rs: where a note starts, computed backward from
// its pitch on the engine's own equations), here at the file's end so that no line above it moves. ----

/// Its bore's one step taken small about its doubles as they stand, its reed's own step left out and the flow out of the
/// bore at its reed's end `w` (the bore's units): x' = B x + b w over the doubles a step moves (`moving`), and the no-flow
/// pressure its reed reads after it c x'. Each column of B kept by its entries that are not nothing (its rows among
/// `moving`, and their values), b and c likewise; `off`, the largest move of any of them in a step from where they
/// stand, relative to its field's largest (nothing where its bore is held steady).
#[derive(Clone, Debug, Default)]
pub struct BoreMap {
    pub moving: Vec<usize>,
    pub cols: Vec<Vec<(usize, f64)>>,
    pub b: Vec<(usize, f64)>,
    pub c: Vec<(usize, f64)>,
    pub off: f64,
}

/// Its reed's constants, as its step reads them (connect's T_REED and T_LIPS): its scheme's theta and step, its scales
/// (Q_SP, Q_ZC, Q_SF, Q_SIMP, Q_FLOWSCALE), its slit's law (its opening's power, its leak, a double reed's constriction
/// and the pressure its staple recovers), its contact's constant (Q_CONTACT), its end's alpha, and a lips' inward mode's
/// share of the flow and of the opening.
#[derive(Clone, Copy, Debug, Default)]
pub struct ReedConstants {
    pub theta: f64,
    pub dt: f64,
    pub sp: f64,
    pub zc: f64,
    pub sf: f64,
    pub simp: f64,
    pub flowscale: f64,
    pub exponent: f64,
    pub leak: f64,
    pub constriction: f64,
    pub recovery: f64,
    pub contact: f64,
    pub alpha: f64,
    pub lips: bool,
    pub share: f64,
    pub model2: f64,
    /// Its lay's onset, stiffness, exponent, gain and opening, where its lay stiffens it (T_REED_LAY: lay_contact); no
    /// stiffness, none.
    pub lay: [f64; 5],
}

impl Player {
    /// Its bore's map about its doubles now, or (`rest`) about its rest (BoreMap), read a column at a time by central
    /// differences of the engine's own step: exact to rounding where the step is linear in the double nudged (every
    /// pipe's, every junction's), and to the nudge's square where it is not (an edge's loss, square in its flow, where its
    /// bore holds a steady flow). Each double nudged by `nudge` of its field's largest, or where its field stands at
    /// nothing, by NOTHING_NUDGED, so small that an edge's loss adds nothing to it. Which doubles a step moves: those that
    /// change over MOVED steps from its bore's fields drawn at random. In doubles, on one thread; its doubles put back as
    /// they stood.
    pub fn bore_map(&mut self, row: &[f64], w: f64, nudge: f64, rest: bool) -> Result<BoreMap, String> {
        #[cfg(any(not(target_arch = "wasm32"), feature = "threads"))]
        if self.crew.is_some() {
            return Err("its bore's map is read on one thread".into());
        }
        if self.mirror.is_some() {
            return Err("its bore's map is read in doubles".into());
        }
        if row.len() < self.body.cols {
            return Err(format!("a row of {} columns", self.body.cols));
        }
        let k = self.reed_conn()?;
        let e = self.body.ends[self.body.conns[k].e[0]];
        let kept = self.d.clone();
        let reed = self.body.conns.remove(k);
        let found = self.mapped(row, w, nudge, rest, &e, &kept);
        self.body.conns.insert(k, reed);
        self.d.copy_from_slice(&kept);
        found
    }

    fn bore_stepped(&mut self, row: &[f64], w: f64, at: usize, y: &mut [f64]) -> Result<(), String> {
        self.d[at] = w;
        let status = unsafe { self.body.run(&self.i, &mut self.d, None, None, row, y, 1) };
        if status != 0 {
            return Err(format!("its bore stopped ({status})"));
        }
        Ok(())
    }

    fn mapped(&mut self, row: &[f64], w: f64, nudge: f64, rest: bool, e: &End, kept: &[f64]) -> Result<BoreMap, String> {
        const MOVED: usize = 4;
        const NOTHING_NUDGED: f64 = 1e-30;
        let n = kept.len();
        let mut y = vec![0.0; self.body.nouts];
        // (Which doubles a step moves: its fields drawn at random, by a xorshift from a fixed seed.)
        let mut seed = 0x9e37_79b9_7f4a_7c15u64;
        let mut draw = || {
            seed ^= seed << 13;
            seed ^= seed >> 7;
            seed ^= seed << 17;
            (seed >> 11) as f64 / (1u64 << 53) as f64 * 2.0 - 1.0
        };
        let fields = self.fields();
        for &(from, len) in &fields {
            for v in self.d[from..from + len].iter_mut() {
                *v = draw();
            }
        }
        let mut moved = vec![false; n];
        let mut before = self.d.clone();
        for _ in 0..MOVED {
            before.copy_from_slice(&self.d);
            self.bore_stepped(row, draw(), e.w, &mut y)?;
            for (m, (a, b)) in moved.iter_mut().zip(self.d.iter().zip(&before)) {
                *m |= a != b;
            }
        }
        moved[e.w] = false;
        let moving: Vec<usize> = (0..n).filter(|&k| moved[k]).collect();
        // (Taken small about its doubles as they stand, or at rest: every double a step moves at nothing.)
        let mut base = kept.to_vec();
        if rest {
            for &k in &moving {
                base[k] = 0.0;
            }
        }
        let kept = &base[..];
        self.d.copy_from_slice(kept);
        // (Each double's nudge: its field's largest, or its own where it is in no field.)
        let mut size: Vec<f64> = kept.iter().map(|v| v.abs()).collect();
        for &(from, len) in &fields {
            let largest = size[from..from + len].iter().copied().fold(0.0, f64::max);
            size[from..from + len].fill(largest);
        }
        let nudged = |s: f64| if s > 0.0 { nudge * s } else { NOTHING_NUDGED };
        let read = |p: &Player| -> Vec<f64> { moving.iter().map(|&k| p.d[k]).collect() };
        let restore = |p: &mut Player| {
            for &k in &moving {
                p.d[k] = kept[k];
            }
        };
        let column = |up: &[f64], down: &[f64], h: f64| -> Vec<(usize, f64)> {
            up.iter().zip(down).enumerate().filter_map(|(i, (a, b))| Some((i, (a - b) / (2.0 * h))).filter(|c| c.1 != 0.0)).collect()
        };
        self.bore_stepped(row, w, e.w, &mut y)?;
        let off = moving.iter().map(|&k| (self.d[k] - kept[k]).abs() / size[k].max(f64::MIN_POSITIVE)).fold(0.0, f64::max);
        let mut cols = Vec::with_capacity(moving.len());
        for &k in &moving {
            let h = nudged(size[k]);
            restore(self);
            self.d[k] = kept[k] + h;
            self.bore_stepped(row, w, e.w, &mut y)?;
            let up = read(self);
            restore(self);
            self.d[k] = kept[k] - h;
            self.bore_stepped(row, w, e.w, &mut y)?;
            cols.push(column(&up, &read(self), h));
        }
        let h = nudged(w.abs());
        restore(self);
        self.bore_stepped(row, w + h, e.w, &mut y)?;
        let up = read(self);
        restore(self);
        self.bore_stepped(row, w - h, e.w, &mut y)?;
        let b = column(&up, &read(self), h);
        restore(self);
        // (Its reed's no-flow pressure: p_no_flow_at, linear in its doubles.)
        let c: Vec<(usize, f64)> = moving
            .iter()
            .enumerate()
            .filter_map(|(j, &k)| {
                let h = nudged(size[k]);
                self.d[k] = kept[k] + h;
                let up = unsafe { p_no_flow_at(self.d.as_ptr(), e) };
                self.d[k] = kept[k] - h;
                let down = unsafe { p_no_flow_at(self.d.as_ptr(), e) };
                self.d[k] = kept[k];
                Some((j, (up - down) / (2.0 * h))).filter(|c| c.1 != 0.0)
            })
            .collect();
        Ok(BoreMap { moving, cols, b, c, off })
    }

    /// Its reed's constants (ReedConstants).
    pub fn reed_constants(&self) -> Result<ReedConstants, String> {
        let c = self.body.conns[self.reed_conn()?];
        let q = |k: usize| self.d[c.blk + k];
        let lips = c.kind == T_LIPS;
        Ok(ReedConstants {
            theta: q(Q_THETA),
            dt: q(Q_DT),
            sp: q(Q_SP),
            zc: q(Q_ZC),
            sf: q(Q_SF),
            simp: q(Q_SIMP),
            flowscale: q(Q_FLOWSCALE),
            exponent: q(Q_EXPONENT),
            leak: q(Q_LEAK),
            constriction: q(Q_CONSTRICTION),
            recovery: if lips { 0.0 } else { q(Q_RECOVERY) },
            contact: q(Q_CONTACT),
            alpha: self.d[self.body.ends[c.e[0]].alpha],
            lips,
            share: if lips { q(Q_SHARE) } else { 0.0 },
            model2: if lips { q(Q_MODEL2) } else { 0.0 },
            lay: if c.lay { [q(Q_LAYONSET), q(Q_LAYSTIFFNESS), q(Q_LAYEXPONENT), q(Q_LAYGAIN), q(Q_LAYOPENING)] } else { [0.0; 5] },
        })
    }
}

// ---- What the orbit's solve reads of the body's own equations (orbit.rs), here at the file's end so that no line above
// it moves. ----

impl Player {
    /// Its bore's loss values, each where it lies among its doubles and the share of itself it keeps from one step to the
    /// next on its own, the sound that drives it apart: a loss variable's 1 - 2 a (pressure_block's and velocity_block's
    /// y = x + a (drive - 2 x)), a P0's own coefficient (p0p0). How far each settles over a period, read off the engine's
    /// own equations: orbit.rs divides it out of the orbit's solve.
    pub fn settling(&self) -> Vec<(usize, f64)> {
        let Some(b) = self.body.bore else { return vec![] };
        let i = &self.i;
        let (h, l, n) = (at(i[b + B_H]), at(i[b + B_L]), at(i[b + B_N]));
        let mut out = Vec::with_capacity((h + l) * n + h);
        for (state, kept, len) in [(B_PI, B_PPI, h * n), (B_VI, B_VVI, l * n)] {
            let (s, c) = (at(i[b + state]), at(i[b + kept]));
            out.extend((0..len).map(|k| (s + k, 1.0 - 2.0 * self.d[c + k])));
        }
        let (s, c) = (at(i[b + B_P0]), at(i[b + B_P0P0]));
        out.extend((0..h).map(|k| (s + k, self.d[c + k])));
        out
    }

    /// Where its flows lie among its doubles: its bore's (its field of them: start, length), and outside its fields each
    /// pipe end's and each joint's own (a discontinuity's, a T-joint's, a cross's gamma, stepped as 2 gamma_b - gamma), so
    /// that orbit.rs sizes them all as the bore's are.
    pub fn flows(&self) -> (Option<(usize, usize)>, Vec<usize>) {
        let bore = self.body.bore.map(|b| {
            let i = &self.i;
            (at(i[b + B_V]), region_length(B_V, at(i[b + B_H]), at(i[b + B_L]), at(i[b + B_N])))
        });
        let mut out: Vec<usize> = self.body.ends.iter().map(|e| e.w).collect();
        for c in &self.body.conns {
            let (from, count) = match c.kind {
                T_DISCONTINUITY => (3, 1),
                T_TJOINT => (10, 2),
                T_CROSS => (21, 3),
                _ => continue,
            };
            out.extend((0..count).map(|k| c.blk + from + k));
        }
        (bore, out)
    }
}

impl Player {
    /// Each joint's own flows -- a discontinuity's, a T-joint's, a cross's gamma: where they lie among its doubles -- and
    /// its Step, row by row, through which alone they move anything (gamma_b = Step gamma + Infl P): what of gamma Step
    /// does not read (none of a discontinuity's of no mass, one direction of a T-joint's) is never read again, and
    /// flickers from step to step as 2 gamma_b - gamma leaves it, undamped (orbit.rs leaves it out of the orbit's state).
    pub fn joints(&self) -> Vec<(Vec<usize>, Vec<f64>)> {
        self.body
            .conns
            .iter()
            .filter_map(|c| {
                let (k, gamma) = match c.kind {
                    T_DISCONTINUITY => (1, 3),
                    T_TJOINT => (2, 10),
                    T_CROSS => (3, 21),
                    _ => return None,
                };
                Some(((0..k).map(|j| c.blk + gamma + j).collect(), self.d[c.blk..c.blk + k * k].to_vec()))
            })
            .collect()
    }
}

impl Player {
    /// Where its reed's or lips' contact variable lies among its doubles (Q_PREVZ): a stand-in for its contact's energy,
    /// moved only while the reed touches its lay and never pulled back to it after, so that it drifts from touch to touch
    /// and closes over no period (orbit.rs holds it where the note has it).
    pub fn contact_variables(&self) -> Vec<usize> {
        self.body.conns.iter().filter(|c| matches!(c.kind, T_REED | T_LIPS)).map(|c| c.blk + Q_PREVZ).collect()
    }
}

impl Player {
    /// Its slide's pipe stretched to `s` (Player::stretch), and each T-joint at its ends -- the hole a reed's barrel's
    /// pipe ends at -- computed again from its ends' alphas as OpenWInD computes it (tjunction.py
    /// TemporalJunction._precompute_constants: Step = M_Jdt^-1 M_J, Infl = -dt/2 M_Jdt^-1 T_J, M_Jdt = M_J + dt^2/4 T_J
    /// diag(2 alpha/dt) T_J^t), its masses M_J read back from its coefficients as they stood (M_Jdt^-1 = -2/dt Infl's first
    /// two columns, M_J = M_Jdt Step); its slide's own connectors computed again by Player::stretch. A trombone's slide
    /// ends at none.
    pub fn stretch_joined(&mut self, s: f64) {
        let Some(slide) = self.slide.as_ref().filter(|slide| s != slide.s) else { return };
        let dt = slide.dt;
        let places: Vec<usize> = slide.ends.iter().map(|&(p, _)| p).collect();
        let ends = &self.body.ends;
        let joints: Vec<Conn> =
            self.body.conns.iter().filter(|c| c.kind == T_TJOINT && c.e[..3].iter().any(|&k| places.contains(&ends[k].alpha))).copied().collect();
        let inverse = |m: [f64; 4]| {
            let det = m[0] * m[3] - m[1] * m[2];
            [m[3] / det, -m[1] / det, -m[2] / det, m[0] / det]
        };
        let times = |a: [f64; 4], b: [f64; 4]| [a[0] * b[0] + a[1] * b[2], a[0] * b[1] + a[1] * b[3], a[2] * b[0] + a[3] * b[2], a[2] * b[1] + a[3] * b[3]];
        let masses: Vec<[f64; 4]> = joints
            .iter()
            .map(|c| {
                let (b, d) = (c.blk, &self.d);
                let n = [-2.0 / dt * d[b + 4], -2.0 / dt * d[b + 5], -2.0 / dt * d[b + 7], -2.0 / dt * d[b + 8]];
                times(inverse(n), [d[b], d[b + 1], d[b + 2], d[b + 3]])
            })
            .collect();
        self.stretch(s);
        for (c, m_j) in joints.iter().zip(masses) {
            let g: Vec<f64> = c.e[..3].iter().map(|&k| 2.0 * self.d[self.body.ends[k].alpha] / dt).collect();
            let q = dt * dt / 4.0;
            let n = inverse([m_j[0] + q * (g[0] + g[2]), m_j[1] + q * g[2], m_j[2] + q * g[2], m_j[3] + q * (g[1] + g[2])]);
            let step = times(n, m_j);
            let h = -dt / 2.0;
            let infl = [h * n[0], h * n[1], -h * (n[0] + n[1]), h * n[2], h * n[3], -h * (n[2] + n[3])];
            for (k, v) in step.iter().chain(infl.iter()).enumerate() {
                self.d[c.blk + k] = *v;
                #[cfg(any(not(target_arch = "wasm32"), feature = "threads"))]
                if let Some(crew) = self.crew.as_mut() {
                    // (Between its steps: no worker steps meanwhile, as Player::stretch.)
                    unsafe { crew.put_d(c.blk + k, *v) };
                }
            }
        }
    }
}

/// A body's joints as its player pulls them open to tune (body.rs PointsHeader; the owner, 9 November 2026: "Pulling a
/// joint lengthens the bore there and adds the small air space left in the socket"): the pipes beside them as laid out
/// (each its elements' two blocks and its ends' alphas, and where they are written, as a slide's: Slide), each joint's
/// pipe, its end at the joint, the stretch and the share of that end's air a metre of pull adds, and its range; the
/// connectors at the pipes' ends, the T-joints among them with their masses M_J; the connectors' step; its pulls.
struct Points {
    pipes: Vec<PointPipe>,
    joints: Vec<(usize, usize, f64, f64, [f64; 2])>,
    joins: Vec<Join>,
    tees: Vec<(usize, [usize; 3], [f64; 4], [f64; 10])>,
    dt: f64,
    pulls: Vec<f64>,
}

struct PointPipe {
    elements: Vec<(usize, usize)>,
    placed: Vec<(usize, usize, usize)>,
    blocks: Vec<f64>,
    ends: [(usize, f64); 2],
    scaled: Vec<f64>,
}

impl Player {
    /// Its joints (body.rs PointsHeader) taken up, each closed: each place they name checked -- their elements among its
    /// bore's groups, their ends among its bore's ends, the connectors at those ends simple junctions, discontinuities or
    /// T-joints -- and what they change kept as laid out, the T-joints' masses read back from their coefficients (M_Jdt^-1
    /// = -2/dt Infl's first two columns, M_J = M_Jdt Step: Player::stretch_joined). -> why not, where they are not this
    /// body's.
    pub fn points_on(&mut self, header: &crate::body::PointsHeader) -> Result<(), String> {
        if !(header.dt > 0.0 && header.dt.is_finite()) || header.joints.is_empty() {
            return Err("no joints, or its step not a step".into());
        }
        let groups = &self.body.groups;
        let mut pipes: Vec<PointPipe> = Vec::new();
        let mut placed_ends: Vec<[usize; 2]> = Vec::new();
        let mut joints = Vec::new();
        for joint in &header.joints {
            let fine = |v: f64| v >= 0.0 && v.is_finite();
            if joint.end > 1 || !fine(joint.stretch) || !fine(joint.volume) || !fine(joint.range[0]) || !(joint.range[1] >= joint.range[0] && joint.range[1].is_finite()) {
                return Err(format!("its joint {}: its end, stretch, volume or range not one", joint.name));
            }
            let pipe = match placed_ends.iter().position(|e| *e == joint.ends) {
                Some(k) => k,
                None => {
                    if joint.elements.is_empty() || joint.ends[0] == joint.ends[1] || !joint.ends.iter().all(|k| self.body.bore_ends.contains(k)) {
                        return Err(format!("its joint {}: no elements, or its ends {:?} not two of its bore's", joint.name, joint.ends));
                    }
                    let mut blocks = Vec::new();
                    for &[g, e] in &joint.elements {
                        let Some(group) = groups.get(g).filter(|group| e < group.count) else { return Err(format!("its joint {}: no element {e} of group {g}", joint.name)) };
                        let size = group.w * group.w;
                        blocks.extend_from_slice(&self.d[group.a + e * size..group.a + (e + 1) * size]);
                        blocks.extend_from_slice(&self.d[group.b + e * size..group.b + (e + 1) * size]);
                    }
                    let elements: Vec<(usize, usize)> = joint.elements.iter().map(|&[g, e]| (g, e)).collect();
                    #[allow(unused_mut)]
                    let mut placed = Vec::new();
                    #[cfg(any(not(target_arch = "wasm32"), feature = "threads"))]
                    if let Some(crew) = &self.crew {
                        for &(g, e) in &elements {
                            placed.push(crew.element_at(g, e).ok_or_else(|| format!("element {e} of group {g} in none of its parts"))?);
                        }
                    }
                    let alpha = |k: usize| (self.body.ends[k].alpha, self.d[self.body.ends[k].alpha]);
                    let scaled = vec![0.0; blocks.len()];
                    pipes.push(PointPipe { elements, placed, blocks, ends: [alpha(joint.ends[0]), alpha(joint.ends[1])], scaled });
                    placed_ends.push(joint.ends);
                    pipes.len() - 1
                }
            };
            joints.push((pipe, joint.end, joint.stretch, joint.volume, joint.range));
        }
        let ends: Vec<usize> = placed_ends.iter().flatten().copied().collect();
        let (mut joins, mut tees) = (Vec::new(), Vec::new());
        let dt = header.dt;
        for conn in self.body.conns.iter().filter(|c| c.e.iter().any(|k| ends.contains(k))) {
            let (b, d) = (conn.blk, &self.d);
            let alpha = |j: usize| self.body.ends[conn.e[j]].alpha;
            match conn.kind {
                T_SIMPLE => joins.push(Join { kind: T_SIMPLE, blk: b, alphas: [alpha(0), alpha(1)], mass: 0.0, laid: [d[b], 0.0, 0.0] }),
                T_DISCONTINUITY => {
                    let inv = -2.0 * d[b + 2] / dt;
                    let mass = if d[b] == 0.0 { 0.0 } else { d[b] / inv };
                    joins.push(Join { kind: T_DISCONTINUITY, blk: b, alphas: [alpha(0), alpha(1)], mass, laid: [d[b], d[b + 1], d[b + 2]] });
                }
                T_TJOINT => {
                    let n = [-2.0 / dt * d[b + 4], -2.0 / dt * d[b + 5], -2.0 / dt * d[b + 7], -2.0 / dt * d[b + 8]];
                    let det = n[0] * n[3] - n[1] * n[2];
                    let inv = [n[3] / det, -n[1] / det, -n[2] / det, n[0] / det];
                    let m_j = [inv[0] * d[b] + inv[1] * d[b + 2], inv[0] * d[b + 1] + inv[1] * d[b + 3], inv[2] * d[b] + inv[3] * d[b + 2], inv[2] * d[b + 1] + inv[3] * d[b + 3]];
                    let mut laid = [0.0; 10];
                    laid.copy_from_slice(&d[b..b + 10]);
                    tees.push((b, [alpha(0), alpha(1), alpha(2)], m_j, laid));
                }
                _ => return Err(format!("connector at {b}, at a joint's pipe's end, is not a simple junction, a discontinuity or a T-joint")),
            }
        }
        let pulls = vec![0.0; joints.len()];
        self.points = Some(Box::new(Points { pipes, joints, joins, tees, dt, pulls }));
        Ok(())
    }

    /// Its joints pulled open `pulls` m (each within its range; Player::points_on), from where they stand: each joint's
    /// pipe stretched as a slide's is (Player::stretch) by the length its joints add to it (1 + their stretch times their
    /// pulls), so that every element's mass and losses are that many times theirs and its two blocks and its ends'
    /// alphas that many times less; and at each end where a joint stands, its node's air -- its mass on its pressure's
    /// node, and its losses with it -- the more by the air its socket leaves beside its bore (the joint's volume times its
    /// pull, a share of that node's own), its row of v_to_p_noflow and its end's alpha as many times less; the
    /// connectors at the pipes' ends computed again from their ends' alphas (Join::coefficients; T-joints from their
    /// masses as Player::stretch_joined). All closed, its laid-out values themselves. Nothing without joints.
    pub fn pull_points(&mut self, pulls: &[f64]) {
        let Some(points) = self.points.as_mut() else { return };
        let given: Vec<f64> = points.joints.iter().enumerate().map(|(k, j)| pulls.get(k).copied().filter(|v| v.is_finite()).unwrap_or(points.pulls[k]).clamp(j.4[0], j.4[1])).collect();
        if given == points.pulls {
            return;
        }
        points.pulls = given;
        let closed = points.pulls.iter().all(|&v| v == 0.0);
        let groups = &self.body.groups;
        let mut put_d: Vec<(usize, f64)> = Vec::new();
        for (p, pipe) in points.pipes.iter_mut().enumerate() {
            let mut s = 1.0;
            let mut more = [0.0; 2];
            for (k, j) in points.joints.iter().enumerate().filter(|(_, j)| j.0 == p) {
                s += j.2 * points.pulls[k];
                more[j.1] += j.3 * points.pulls[k];
            }
            let laid = s == 1.0 && more == [0.0, 0.0];
            let inv = 1.0 / s;
            for (x, &b) in pipe.scaled.iter_mut().zip(&pipe.blocks) {
                *x = if laid { b } else { b * inv };
            }
            if !laid {
                let (first, last) = (pipe.elements[0], pipe.elements[pipe.elements.len() - 1]);
                let (w0, w1) = (groups[first.0].w, groups[last.0].w);
                // (Its first node's row of the first element's v_to_p_noflow, and its last node's of the last's.)
                let row0 = w0 * w0;
                let row1 = pipe.blocks.len() - w1;
                for (start, w, end) in [(row0, w0, 0), (row1, w1, 1)] {
                    let f = 1.0 / (s + more[end]);
                    for c in start..start + w {
                        pipe.scaled[c] = pipe.blocks[c] * f;
                    }
                }
            }
            let mut at = 0;
            for (k, &(g, e)) in pipe.elements.iter().enumerate() {
                let group = groups[g];
                let size = group.w * group.w;
                let (a, b) = (&pipe.scaled[at..at + size], &pipe.scaled[at + size..at + 2 * size]);
                self.d[group.a + e * size..group.a + (e + 1) * size].copy_from_slice(a);
                self.d[group.b + e * size..group.b + (e + 1) * size].copy_from_slice(b);
                if let Some(m) = self.mirror.as_mut() {
                    let (ma, mb) = m.groups[g];
                    for (x, &v) in m.data[ma + e * size..ma + (e + 1) * size].iter_mut().zip(a) {
                        *x = v as f32;
                    }
                    for (x, &v) in m.data[mb + e * size..mb + (e + 1) * size].iter_mut().zip(b) {
                        *x = v as f32;
                    }
                }
                #[cfg(any(not(target_arch = "wasm32"), feature = "threads"))]
                if let (Some(crew), Some(&(part, pa, pb))) = (self.crew.as_mut(), pipe.placed.get(k)) {
                    // (Between its steps: no worker steps meanwhile, as Player::stretch.)
                    unsafe {
                        crew.put(part, pa, a);
                        crew.put(part, pb, b);
                    }
                }
                #[cfg(all(target_arch = "wasm32", not(feature = "threads")))]
                let _ = k;
                at += 2 * size;
            }
            for (end, &(place, alpha)) in pipe.ends.iter().enumerate() {
                put_d.push((place, if laid { alpha } else { alpha * (1.0 / (s + more[end])) }));
            }
        }
        for &(place, v) in &put_d {
            self.d[place] = v;
        }
        let dt = points.dt;
        for join in &points.joins {
            let values = if closed { join.laid } else { join.coefficients(self.d[join.alphas[0]], self.d[join.alphas[1]], dt) };
            for (c, &v) in values.iter().enumerate().take(join.width()) {
                put_d.push((join.blk + c, v));
                self.d[join.blk + c] = v;
            }
        }
        for &(blk, alphas, m_j, laid) in &points.tees {
            let values = if closed {
                laid
            } else {
                let g: Vec<f64> = alphas.iter().map(|&k| 2.0 * self.d[k] / dt).collect();
                let q = dt * dt / 4.0;
                let m = [m_j[0] + q * (g[0] + g[2]), m_j[1] + q * g[2], m_j[2] + q * g[2], m_j[3] + q * (g[1] + g[2])];
                let det = m[0] * m[3] - m[1] * m[2];
                let n = [m[3] / det, -m[1] / det, -m[2] / det, m[0] / det];
                let step = [n[0] * m_j[0] + n[1] * m_j[2], n[0] * m_j[1] + n[1] * m_j[3], n[2] * m_j[0] + n[3] * m_j[2], n[2] * m_j[1] + n[3] * m_j[3]];
                let h = -dt / 2.0;
                [step[0], step[1], step[2], step[3], h * n[0], h * n[1], -h * (n[0] + n[1]), h * n[2], h * n[3], -h * (n[2] + n[3])]
            };
            for (c, &v) in values.iter().enumerate() {
                put_d.push((blk + c, v));
                self.d[blk + c] = v;
            }
        }
        #[cfg(any(not(target_arch = "wasm32"), feature = "threads"))]
        if let Some(crew) = self.crew.as_mut() {
            for &(place, v) in &put_d {
                // (Between its steps, as Player::stretch.)
                unsafe { crew.put_d(place, v) };
            }
        }
    }

    /// The pulls its joints stand at (m), in its header's order; none without joints.
    pub fn pulls(&self) -> Vec<f64> {
        self.points.as_ref().map_or_else(Vec::new, |p| p.pulls.clone())
    }
}

impl Player {
    /// The range each of its joints is pulled within (m), in its header's order; none without joints.
    pub fn joint_ranges(&self) -> Vec<[f64; 2]> {
        self.points.as_ref().map_or_else(Vec::new, |p| p.joints.iter().map(|j| j.4).collect())
    }
}

// ---- Its body remade in place (native/openwind-maker src/points.rs: its makers' adjustment points set on its own mesh,
// held; the owner, 9 November 2026: "Each is applied to the engine's own body in place"), here at the file's end so that
// no line above it moves. ----

impl Player {
    /// Its body's coefficients those of `made`, a body made on its own layout (its ints `i` its own, its mesh and step
    /// held), set where they differ from `laid`, the doubles it was made with (both at rest, so that only coefficients
    /// differ): its joints closed first, their laid-out values back, then taken up again on `points` (made's) and pulled
    /// where they stood. Its state as it stands. On one core only: a crew's workers keep their own copies. -> the
    /// doubles set; why not, where `made` is not its layout's or it has a slide.
    pub fn remade(&mut self, i: &[i64], laid: &[f64], made: &[f64], points: Option<&crate::body::PointsHeader>) -> Result<usize, String> {
        if self.slide.is_some() {
            return Err("a slide's body is not remade in place".into());
        }
        if self.crewed() {
            return Err("its crew keeps its own copies: remade on one core only".into());
        }
        if i != self.i.as_slice() || laid.len() != self.d.len() || made.len() != self.d.len() {
            return Err("not made on its layout: its ints or its doubles' count another's".into());
        }
        if self.points.is_some() != points.is_some() {
            return Err("its joints and the made body's not alike".into());
        }
        let state = self.fields();
        let changed: Vec<usize> = (0..made.len()).filter(|&k| made[k].to_bits() != laid[k].to_bits()).collect();
        if let Some(&k) = changed.iter().find(|&&k| state.iter().any(|&(at, len)| at <= k && k < at + len)) {
            return Err(format!("its state at {k} not at rest in the bodies given"));
        }
        let pulls = self.pulls();
        if self.points.is_some() {
            self.pull_points(&vec![0.0; pulls.len()]);
        }
        // (Each radiation and valve whose coefficients its opening's moves have set (bore_step's T_RADIATION and T_SWITCH):
        // set again at its opening from the made body's, as the made body holds them once its opening has moved there.)
        let derived = |c: &Conn| -> Vec<usize> {
            match c.kind {
                T_RADIATION => [R_STEP, R_INFL, R_ZTOF, R_PTOF].map(|r| c.blk + r).to_vec(),
                T_SWITCH => (0..3).map(|j| c.blk + S_INFL + j).collect(),
                _ => vec![],
            }
        };
        let opened: Vec<(i64, usize, [usize; 3], Vec<usize>)> = self.body.conns.iter().filter(|c| c.u != NONE).map(|c| (c, derived(c))).filter(|(_, at)| at.iter().any(|&k| self.d[k].to_bits() != laid[k].to_bits())).map(|(c, at)| (c.kind, c.blk, [0, 1, 2].map(|j| self.body.ends.get(c.e[j]).map_or(0, |e| e.alpha)), at)).collect();
        for &k in &changed {
            self.d[k] = made[k];
        }
        let mut changed = changed;
        for (kind, blk, alphas, at) in opened {
            if kind == T_RADIATION {
                radiation_coefficients(&mut self.d[blk..blk + R_KAPPA + 1]);
            } else {
                let alpha = alphas.map(|k| self.d[k]);
                switch_coefficients(&mut self.d[blk..blk + S_INFL + 3], alpha);
            }
            changed.extend(at);
        }
        changed.sort_unstable();
        changed.dedup();
        if let Some(m) = self.mirror.as_mut() {
            for &(from, to, len, state) in &m.regions {
                if !state {
                    for k in changed.iter().copied().filter(|&k| from <= k && k < from + len) {
                        m.data[to + k - from] = self.d[k] as f32;
                    }
                }
            }
        }
        if let Some(header) = points {
            self.points = None;
            self.points_on(header)?;
            self.pull_points(&pulls);
        }
        Ok(changed.len())
    }
}

// ---- Its bore's one step applied to doubles given (points.rs: each maker's point's rate on a note's own start, read
// from each moved body's own step), here at the file's end so that no line above it moves. ----

impl Player {
    /// Its bore's one step, its reed's own left out, applied from rest to `x` over the doubles `moving` (a BoreMap's) with
    /// the flow `w` out of it at its reed's end: B x + b w over `moving`, read from the step itself at `row` -- its
    /// doubles given TINY of their largest, so small that an edge's loss, square in its flow, adds nothing, as bore_map
    /// nudges a bore at rest. In doubles, on one thread; its doubles put back as they stood.
    pub fn bore_applied(&mut self, row: &[f64], moving: &[usize], x: &[f64], w: f64) -> Result<Vec<f64>, String> {
        const TINY: f64 = 1e-30;
        #[cfg(any(not(target_arch = "wasm32"), feature = "threads"))]
        if self.crew.is_some() {
            return Err("its bore's step is applied on one thread".into());
        }
        if self.mirror.is_some() || row.len() < self.body.cols || x.len() != moving.len() {
            return Err(format!("in doubles, a row of {} columns, and a double for each its step moves", self.body.cols));
        }
        let largest = x.iter().fold(w.abs(), |m, v| m.max(v.abs()));
        if !(largest > 0.0 && largest.is_finite()) {
            return if largest == 0.0 { Ok(vec![0.0; x.len()]) } else { Err("its doubles given are not numbers".into()) };
        }
        let k = self.reed_conn()?;
        let e = self.body.ends[self.body.conns[k].e[0]];
        let scale = TINY / largest;
        let kept: Vec<f64> = moving.iter().map(|&q| self.d[q]).collect();
        let kept_w = self.d[e.w];
        for (&q, v) in moving.iter().zip(x) {
            self.d[q] = v * scale;
        }
        let reed = self.body.conns.remove(k);
        let mut y = vec![0.0; self.body.nouts];
        let stepped = self.bore_stepped(row, w * scale, e.w, &mut y);
        self.body.conns.insert(k, reed);
        let out = moving.iter().map(|&q| self.d[q] / scale).collect();
        for (&q, v) in moving.iter().zip(&kept) {
            self.d[q] = *v;
        }
        self.d[e.w] = kept_w;
        stepped?;
        Ok(out)
    }
}

// ---- A reed whose lay stiffens it before its tip shuts (the owner, 10 November 2026: "yes, I am OKing the full
// solution here"; "factor so that we can roll out the change one instrument at a time, so that currently-functioning
// instruments on the old system are not broken while we work on the clarinet"; research/MODELING_GAPS.md, "The single
// reed stiffens as it bends towards the lay"), here at the file's end. ----

/// A reed as T_REED's, its block five doubles longer: its lay's onset, stiffness, exponent, gain and opening. A body made
/// with it is its own kind, so that every body made before plays as it did, to the bit; read, it is a reed whose connector
/// says so (Conn::lay), and every reed's place and state are its own.
const T_REED_LAY: i64 = 10;
const Q_LAYONSET: usize = 18;
const Q_LAYSTIFFNESS: usize = 19;
const Q_LAYEXPONENT: usize = 20;
const Q_LAYGAIN: usize = 21;
const Q_LAYOPENING: usize = 22;

/// A lay's law as a step reads it: where the reed first touches it (`onset`, a share of its opening at rest), its
/// stiffness and exponent there -- its force kl (onset - y)^al, in the reed's own spring's units, pushing it open from
/// there to its tip's shutting and past it -- and the gain its own spring answers the pressure with: its row's closing
/// pressure over the pressure its own spring alone would shut at (1 + kl onset^al where the row's is the pressure that
/// shuts the reed on its lay; 1 where it is its own spring's); and its opening at rest over the one its rules' slit and
/// its reed's own flow are given for (`opening`: both that much the larger). V. Chatziioannou & M. van Walstijn 2012, "Estimation of
/// clarinet reed parameters by inverse modelling", Acta Acustica united with Acustica 98(4), 629-639,
/// doi:10.3813/AAA.918543: a contact force kc (y - yc)^2 added to the reed's own stiffness.
#[derive(Clone, Copy, Debug)]
struct Lay {
    force: f64,
    gain: f64,
    opening: f64,
}

/// The lay's law at the opening `y` (none where it has no stiffness), and twice its potential there: what the reed's
/// contact's variable holds of it.
fn lay_contact(onset: f64, stiffness: f64, exponent: f64, gain: f64, opening: f64, y: f64) -> (Option<Lay>, f64) {
    if !(stiffness > 0.0) {
        return (None, 0.0);
    }
    let reach = positive_part(onset - y);
    (Some(Lay { force: stiffness * reach.powf(exponent), gain, opening }), 2.0 * stiffness / (exponent + 1.0) * reach.powf(exponent + 1.0))
}

/// The contact's force over its variable with the lay's in it: the tip's as the step has it (kc yn_minus^alpha_c, once
/// shut) and the lay's, over the root of the contact's constant and twice their potentials.
fn lay_force(lay: Lay, kc: f64, alpha_c: f64, yn_minus: f64, contact: f64, lay_held: f64) -> f64 {
    let tip = if yn_minus > 0.0 { kc * yn_minus.powf(alpha_c) } else { 0.0 };
    let held = if yn_minus > 0.0 { 2.0 * kc / (alpha_c + 1.0) * yn_minus.powf(alpha_c + 1.0) } else { 0.0 };
    if tip + lay.force == 0.0 { 0.0 } else { -(tip + lay.force) / (contact + held + lay_held).sqrt() }
}

// ---- What its reed's end recorded at the step last taken (stream.rs Stream::mouth: research/PLAYER_TRACT_PLAN.md, C),
// here at the file's end so that no line above it moves. ----

impl Player {
    /// What its reed's or its lips' end recorded at the step last taken: the flow there as it leaves the bore (m^3/s:
    /// what the reed let in, its negative) and the pressure in the bore at that end (Pa: a mouthpiece's). Read from its
    /// doubles, a bore stepped in singles brought back into them first; not of a crew's, whose workers keep their own.
    pub fn reed_recorded(&mut self) -> Result<(f64, f64), String> {
        let c = self.body.conns[self.reed_conn()?];
        if c.rec == NONE {
            return Err("its reed's end records nothing".into());
        }
        if self.crewed() {
            return Err("its reed's end is read on one thread".into());
        }
        let d = self.data();
        Ok((d[c.rec], d[c.rec + 1]))
    }
}

// ---- A wind's speaking map about the steady flow its breath sends through its bore (speaking.rs): the flows out of its
// ends whose edges lose their jet, its bore's one step from a state given at the amplitude given -- those losses in it, as
// the engine plays them -- and its map's columns read again about such a state, here at the file's end. ----

impl Player {
    /// The doubles holding the flows out of its ends whose edges lose their jet (a radiation's kappa above nothing:
    /// openwind_worker.py edge_losses), each written by its step: in a BoreMap's `moving`, each one's row names the columns
    /// its flow is read from -- those a steady flow through its edge changes, its loss square in that flow.
    pub fn lossy_flows(&self) -> Vec<usize> {
        self.body.conns.iter().filter(|c| c.kind == T_RADIATION && self.d[c.blk + R_KAPPA] > 0.0).map(|c| self.body.ends[c.e[0]].w).collect()
    }

    /// Its bore's one step, its reed's own left out, from the state `at` over the doubles `moving` (a BoreMap's) with the
    /// flow `w` into it at its reed's end, at that amplitude -- its edges' losses as the engine plays them -> those doubles
    /// after it. In doubles, on one thread; its doubles put back as they stood.
    pub fn bore_step(&mut self, row: &[f64], moving: &[usize], at: &[f64], w: f64) -> Result<Vec<f64>, String> {
        #[cfg(any(not(target_arch = "wasm32"), feature = "threads"))]
        if self.crew.is_some() {
            return Err("its bore's step is taken on one thread".into());
        }
        if self.mirror.is_some() || row.len() < self.body.cols || at.len() != moving.len() {
            return Err(format!("in doubles, a row of {} columns, and a double for each its step moves", self.body.cols));
        }
        let k = self.reed_conn()?;
        let e = self.body.ends[self.body.conns[k].e[0]];
        let kept = self.d.clone();
        for (&q, v) in moving.iter().zip(at) {
            self.d[q] = *v;
        }
        let reed = self.body.conns.remove(k);
        let mut y = vec![0.0; self.body.nouts];
        let stepped = self.bore_stepped(row, w, e.w, &mut y);
        self.body.conns.insert(k, reed);
        let out = moving.iter().map(|&q| self.d[q]).collect();
        self.d.copy_from_slice(&kept);
        stepped?;
        Ok(out)
    }

    /// Its bore's map's columns `which` (places in `moving`, a BoreMap's) read again about the state `at` over those
    /// doubles, with the flow `w` into it at its reed's end: by central differences of its own step, as bore_map reads every
    /// column -- each double nudged by `nudge` of its field's largest there (or by a nothing's nudge where it stands at
    /// nothing). In doubles, on one thread; its doubles put back as they stood.
    pub fn bore_columns(&mut self, row: &[f64], w: f64, moving: &[usize], at: &[f64], which: &[usize], nudge: f64) -> Result<Vec<Vec<(usize, f64)>>, String> {
        const NOTHING_NUDGED: f64 = 1e-30;
        #[cfg(any(not(target_arch = "wasm32"), feature = "threads"))]
        if self.crew.is_some() {
            return Err("its bore's map is read on one thread".into());
        }
        if self.mirror.is_some() || row.len() < self.body.cols || at.len() != moving.len() {
            return Err(format!("in doubles, a row of {} columns, and a double for each its step moves", self.body.cols));
        }
        let k = self.reed_conn()?;
        let e = self.body.ends[self.body.conns[k].e[0]];
        let kept = self.d.clone();
        let mut base = kept.clone();
        for (&q, v) in moving.iter().zip(at) {
            base[q] = *v;
        }
        let mut size: Vec<f64> = base.iter().map(|v| v.abs()).collect();
        for (from, len) in self.fields() {
            let largest = size[from..from + len].iter().copied().fold(0.0, f64::max);
            size[from..from + len].fill(largest);
        }
        let reed = self.body.conns.remove(k);
        let mut y = vec![0.0; self.body.nouts];
        let mut found = Vec::with_capacity(which.len());
        let mut failed = None;
        for &j in which {
            let q = moving[j];
            let h = if size[q] > 0.0 { nudge * size[q] } else { NOTHING_NUDGED };
            let mut stepped = |shift: f64, p: &mut Player| -> Result<Vec<f64>, String> {
                p.d.copy_from_slice(&base);
                p.d[q] = base[q] + shift;
                p.bore_stepped(row, w, e.w, &mut y)?;
                Ok(moving.iter().map(|&m| p.d[m]).collect())
            };
            match stepped(h, self).and_then(|up| Ok((up, stepped(-h, self)?))) {
                Ok((up, down)) => found.push(up.iter().zip(&down).enumerate().filter_map(|(i, (a, b))| Some((i, (a - b) / (2.0 * h))).filter(|c| c.1 != 0.0)).collect()),
                Err(why) => {
                    failed = Some(why);
                    break;
                }
            }
        }
        self.body.conns.insert(k, reed);
        self.d.copy_from_slice(&kept);
        match failed {
            Some(why) => Err(why),
            None => Ok(found),
        }
    }
}
