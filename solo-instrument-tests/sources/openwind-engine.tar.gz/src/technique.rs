//! A player's techniques in its breath, as the renders play them (render/synthesis/workers/openwind_worker.py TECHNIQUES,
//! voice_source and mouth_pressure; openwind_passages.py passage_breath): a forcing of the breath its reed or its lips or
//! its jet answers through the bore at every step, never a sound mixed in afterwards.
//!   - a hum {hz, level}: the player's voice at hz, a glottal pulse train -- its partials falling 12 dB an octave, as a
//!     glottal flow's derivative falls, band-limited under VOICE_TOP -- swinging the breath by `level` of itself; the
//!     beating, sum and difference tones with the bore's note are its reed's or its lips';
//!   - a growl {hz, level, rough}: a hum made rough, every other pulse weakened by `rough` (a period doubled, as a vocal
//!     fry's is) and breath noise with it, BREATH_NOISE of the pulses' peak at `rough` 1;
//!   - a flutter {hz, depth}: flutter-tonguing, the tongue's roll closing the breath off hz times a second, `depth` of
//!     it, its closing sharper than its opening (the raised cosine squared).
//! The engine's breath groups shape them on their grid as the renders do (law.rs, voice_source); the live dial's held
//! row carries them a step at a time (Held: stream.rs), its voice from one period of it tabulated.

use crate::controls::{eased, Normal};
use serde::Deserialize;
use std::f64::consts::PI;

/// The highest a voice's partials reach (Hz): openwind_worker.py voice_source's.
pub const VOICE_TOP: f64 = 4000.0;
/// A growl's breath noise at `rough` 1, a share of its pulses' peak: openwind_worker.py voice_source's.
pub const BREATH_NOISE: f64 = 0.3;
/// The rate a voice's source is drawn at (Hz): the renders' (openwind_worker.py voice_source), its breath noise drawn
/// there.
pub const VOICE_RATE: f64 = 48000.0;

/// A voice hummed or growled: its pitch (Hz), its swing of the breath (a share of it) and its roughness (none, a hum's).
#[derive(Deserialize, Clone, Copy, Debug, PartialEq)]
pub struct Voice {
    pub hz: f64,
    pub level: f64,
    #[serde(default)]
    pub rough: f64,
}

/// A flutter: its tongue's turns a second and the share of the breath it closes off.
#[derive(Deserialize, Clone, Copy, Debug, PartialEq)]
pub struct Roll {
    pub hz: f64,
    pub depth: f64,
}

/// A note's techniques (openwind_worker.py technique_of; openwind_engine.py note_values): a hum, a growl -- the growl
/// played where both are given, as the renders play it -- and a flutter.
#[derive(Deserialize, Clone, Debug, Default, PartialEq)]
pub struct Techniques {
    #[serde(default)]
    pub hum: Option<Voice>,
    #[serde(default)]
    pub growl: Option<Voice>,
    #[serde(default)]
    pub flutter: Option<Roll>,
}

impl Techniques {
    /// The voice it plays: its growl, else its hum.
    pub fn voiced(&self) -> Option<Voice> {
        self.growl.or(self.hum)
    }

    /// -> why not, where one lies outside the renders' reach (technique_of: a voice 40 to 1200 Hz, its level and
    /// roughness none to all; a flutter 5 to 60 turns a second, none to all of the breath).
    pub fn check(&self) -> Result<(), String> {
        let within = |x: f64, lo: f64, hi: f64| x.is_finite() && (lo..=hi).contains(&x);
        for (name, v) in [("hum", self.hum), ("growl", self.growl)] {
            if let Some(v) = v {
                if !(within(v.hz, 40.0, 1200.0) && within(v.level, 0.0, 1.0) && within(v.rough, 0.0, 1.0)) {
                    return Err(format!("a {name} of 40 to 1200 Hz, its level and roughness none to all, not {v:?}"));
                }
            }
        }
        if let Some(r) = self.flutter {
            if !(within(r.hz, 5.0, 60.0) && within(r.depth, 0.0, 1.0)) {
                return Err(format!("a flutter of 5 to 60 turns a second, none to all of the breath, not {r:?}"));
            }
        }
        Ok(())
    }
}

/// How many partials a voice at `hz` has, drawn at `rate`: those under VOICE_TOP and under 0.45 of the rate, one at least
/// (voice_source's).
fn partials(hz: f64, rate: f64) -> usize {
    ((VOICE_TOP.min(rate * 0.45) / hz) as usize).max(1)
}

/// A voice's pulse train at `hz` over `seconds`, as openwind_worker.py voice_source draws it at `rate`: its partials
/// falling 12 dB an octave, every other pulse weakened by `rough`, its peak 1; and its breath noise beside it, `rough`
/// times BREATH_NOISE times a normal draw each sample (seeded by `seed`: the renders' own draws are numpy's). -> its
/// values at i / rate.
pub fn voice_source(hz: f64, seconds: f64, rate: f64, rough: f64, seed: u64) -> Vec<f64> {
    let n = (seconds * rate).ceil() as usize + 2;
    let top = partials(hz, rate);
    let mut w: Vec<f64> = (0..n).map(|i| {
        let t = i as f64 / rate;
        let mut sum = 0.0;
        for k in 1..=top {
            sum += (2.0 * PI * k as f64 * hz * t).sin() / (k * k) as f64;
        }
        sum
    }).collect();
    if rough != 0.0 {
        for (i, x) in w.iter_mut().enumerate() {
            *x *= 1.0 - rough * 0.5 * (1.0 + (PI * hz * (i as f64 / rate)).cos());
        }
    }
    let peak = w.iter().fold(0.0f64, |m, x| m.max(x.abs())).max(1e-12);
    for x in w.iter_mut() {
        *x /= peak;
    }
    if rough != 0.0 {
        let mut draws = Normal::new(seed);
        for x in w.iter_mut() {
            *x += rough * BREATH_NOISE * draws.next();
        }
    }
    w
}

/// numpy's interp of a source drawn at `rate` from 0 (voice_source's): `x` between its samples, none outside them.
pub fn source_at(source: &[f64], rate: f64, x: f64) -> f64 {
    let n = source.len();
    let at = |j: usize| j as f64 / rate;
    if !(x >= 0.0) || x > at(n - 1) {
        return 0.0;
    }
    let mut j = ((x * rate) as usize).min(n - 2);
    while j > 0 && at(j) > x {
        j -= 1;
    }
    while j + 2 < n && at(j + 1) <= x {
        j += 1;
    }
    (source[j + 1] - source[j]) / (at(j + 1) - at(j)) * (x - at(j)) + source[j]
}

// (A voice's period tabulated so many points, and its roughness's peaks at so many roughnesses from none to all.)
const TABLE: usize = 4096;
const ROUGHS: usize = 33;

/// A share moving from one value to another along the raised cosine over so many steps, so many taken.
#[derive(Clone, Copy, Debug, Default)]
struct Moving {
    from: f64,
    to: f64,
    steps: u64,
    taken: u64,
}

impl Moving {
    fn at(&self, ahead: u64) -> f64 {
        let p = if self.steps == 0 { 1.0 } else { eased((self.taken + ahead).min(self.steps) as f64 / self.steps as f64) };
        self.from + (self.to - self.from) * p
    }

    fn to(&mut self, to: f64, steps: u64) {
        *self = Moving { from: self.at(0), to, steps, taken: 0 };
    }

    fn step(&mut self) {
        self.taken = (self.taken + 1).min(self.steps);
    }
}

/// A held row's techniques, a step at a time (stream.rs Stream::technique): the column of its breath they move -- a
/// reed's or the lips' gamma, a reed's mouth pressure, a jet's speed -- its voice's period tabulated at its pitch, the
/// pulses' peaks by roughness, its phase over two periods (its every other pulse) and its level and roughness moving;
/// its flutter's turns, its phase and its depth moving; its breath noise drawn at VOICE_RATE, three draws about the step
/// (the one before it, after it, and after that), between them along the line.
pub struct Held {
    pub column: usize,
    rate: f64,
    hz: f64,
    table: Vec<f64>,
    peaks: [f64; ROUGHS],
    phase: f64,
    level: Moving,
    rough: Moving,
    roll_hz: f64,
    roll_phase: f64,
    depth: Moving,
    /// Where its note stops speaking, in its column's units (law.rs NoteValues `speaks`): a reed's roll closes off only
    /// the breath over it; none, a jet's or the lips', all of it.
    pub floor: Option<f64>,
    draws: Normal,
    noise: [f64; 3],
    frame: u64,
    n: u64,
}

impl Held {
    /// None of either yet on `column`, stepped at the native `rate`.
    pub fn new(column: usize, rate: f64) -> Held {
        let mut draws = Normal::new(2);
        let noise = [draws.next(), draws.next(), draws.next()];
        Held { column, rate, hz: 0.0, table: vec![], peaks: [1.0; ROUGHS], phase: 0.0, level: Moving::default(), rough: Moving::default(),
               roll_hz: 0.0, roll_phase: 0.0, depth: Moving::default(), floor: None, draws, noise, frame: 0, n: 0 }
    }

    /// Whether either sounds or is moving.
    pub fn active(&self) -> bool {
        self.level.at(0) != 0.0 || self.level.to != 0.0 || self.depth.at(0) != 0.0 || self.depth.to != 0.0
    }

    /// Its techniques moved to `t` over `seconds`: a voice's level and roughness to its own (to none where it has none,
    /// its pitch kept), its pitch at once; a flutter's depth to its own (none where it has none), its turns at once.
    pub fn set(&mut self, t: &Techniques, seconds: f64) -> Result<(), String> {
        t.check()?;
        let steps = (seconds * self.rate).round().max(0.0) as u64;
        match t.voiced() {
            Some(v) => {
                if v.hz != self.hz {
                    self.tabulate(v.hz);
                }
                self.level.to(v.level, steps);
                self.rough.to(v.rough, steps);
            }
            None => self.level.to(0.0, steps),
        }
        match t.flutter {
            Some(r) => {
                self.roll_hz = r.hz;
                self.depth.to(r.depth, steps);
            }
            None => self.depth.to(0.0, steps),
        }
        Ok(())
    }

    /// Its voice's period at `hz`, its pulses' peaks by roughness over two periods (voice_source's, a period doubled).
    fn tabulate(&mut self, hz: f64) {
        let top = partials(hz, VOICE_RATE);
        self.table = (0..=TABLE).map(|i| {
            let x = 2.0 * PI * i as f64 / TABLE as f64;
            (1..=top).map(|k| (k as f64 * x).sin() / (k * k) as f64).sum()
        }).collect();
        for (r, peak) in self.peaks.iter_mut().enumerate() {
            let rough = r as f64 / (ROUGHS - 1) as f64;
            *peak = (0..2 * TABLE).map(|i| {
                let x = 2.0 * PI * i as f64 / TABLE as f64;
                (self.table[i % TABLE] * (1.0 - rough * 0.5 * (1.0 + (x / 2.0).cos()))).abs()
            }).fold(0.0, f64::max).max(1e-12);
        }
        self.hz = hz;
    }

    /// Its column's value `x` as it leaves it `ahead` steps on: times its factor, or where its note has a floor, its
    /// voice's share of it and its roll closing off only what stands over the floor (law.rs, as the renders play it).
    pub fn applied(&self, x: f64, ahead: u64) -> f64 {
        let Some(floor) = self.floor else { return x * self.factor(ahead) };
        let v = x * self.voiced(ahead);
        v - self.rolled(ahead) * (v - floor).max(0.0)
    }

    /// The share of its breath it leaves `ahead` steps on (0 or 1): one, plus its voice's level times its pulses and
    /// breath noise; times what its flutter's tongue leaves.
    pub fn factor(&self, ahead: u64) -> f64 {
        let f = self.voiced(ahead);
        let roll = self.rolled(ahead);
        if roll != 0.0 { f * (1.0 - roll) } else { f }
    }

    /// Its flutter's closing `ahead` steps on: its depth times its roll's shape (the raised cosine squared), 0 where it
    /// has none.
    fn rolled(&self, ahead: u64) -> f64 {
        let depth = self.depth.at(ahead);
        if depth == 0.0 {
            return 0.0;
        }
        let turn = 2.0 * PI * self.roll_hz / self.rate * ahead as f64;
        depth * (0.5 - 0.5 * (self.roll_phase + turn).cos()).powi(2)
    }

    /// One plus its voice's level times its pulses and breath noise, `ahead` steps on.
    fn voiced(&self, ahead: u64) -> f64 {
        let mut f = 1.0;
        let level = self.level.at(ahead);
        if level != 0.0 && !self.table.is_empty() {
            let phase = (self.phase + 2.0 * PI * self.hz / self.rate * ahead as f64) % (4.0 * PI);
            let x = phase / (2.0 * PI) * TABLE as f64;
            let i = x as usize;
            let w = self.table[i % TABLE] + (self.table[i % TABLE + 1] - self.table[i % TABLE]) * (x - i as f64);
            let rough = self.rough.at(ahead);
            let at = rough * (ROUGHS - 1) as f64;
            let r = (at as usize).min(ROUGHS - 2);
            let peak = self.peaks[r] + (self.peaks[r + 1] - self.peaks[r]) * (at - r as f64);
            let mut voice = w * (1.0 - rough * 0.5 * (1.0 + (phase / 2.0).cos())) / peak;
            if rough != 0.0 {
                // (Its breath noise between the draws about its step, at VOICE_RATE.)
                let t = ((self.n + ahead) as f64 * VOICE_RATE / self.rate - self.frame as f64).max(0.0);
                let k = (t as usize).min(1);
                voice += rough * BREATH_NOISE * (self.noise[k] + (self.noise[k + 1] - self.noise[k]) * (t - k as f64));
            }
            f += level * voice;
        }
        f
    }

    /// A step taken.
    pub fn step(&mut self) {
        self.level.step();
        self.rough.step();
        self.depth.step();
        self.phase = (self.phase + 2.0 * PI * self.hz / self.rate) % (4.0 * PI);
        self.roll_phase = (self.roll_phase + 2.0 * PI * self.roll_hz / self.rate) % (2.0 * PI);
        self.n += 1;
        while (self.n as f64) * VOICE_RATE / self.rate >= (self.frame + 1) as f64 {
            self.frame += 1;
            self.noise = [self.noise[1], self.noise[2], self.draws.next()];
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    // (`n` steps of `held`'s share of the breath; a sound's magnitude at `hz`.)
    fn played(held: &mut Held, n: usize) -> Vec<f64> {
        (0..n).map(|_| {
            let f = held.factor(0);
            held.step();
            f
        }).collect()
    }

    fn magnitude(x: &[f64], hz: f64, rate: f64) -> f64 {
        let (mut re, mut im) = (0.0, 0.0);
        for (i, v) in x.iter().enumerate() {
            let a = 2.0 * PI * hz * i as f64 / rate;
            re += v * a.cos();
            im += v * a.sin();
        }
        2.0 * (re * re + im * im).sqrt() / x.len() as f64
    }

    #[test]
    fn its_hum_swings_the_breath_by_its_level_its_partials_falling_as_the_renders_draw_them() {
        let rate = 288_000.0;
        let mut held = Held::new(0, rate);
        held.set(&Techniques { hum: Some(Voice { hz: 150.0, level: 0.2, rough: 0.0 }), ..Default::default() }, 0.0).unwrap();
        let x = played(&mut held, 288_000);
        let most = x.iter().fold(0.0f64, |m, v| m.max((v - 1.0).abs()));
        assert!((most - 0.2).abs() < 2e-3, "{most}");
        // (Its source as the renders draw it, its peak the same, its partials the same: the second a quarter of the first.)
        let source = voice_source(150.0, 1.0, VOICE_RATE, 0.0, 0);
        let (one, two) = (magnitude(&x, 150.0, rate), magnitude(&x, 300.0, rate));
        let (a, b) = (magnitude(&source, 150.0, VOICE_RATE), magnitude(&source, 300.0, VOICE_RATE));
        assert!((one / (0.2 * a) - 1.0).abs() < 2e-3 && (two / one - b / a).abs() < 2e-3, "{one} {two} {a} {b}");
        assert!((two / one - 0.25).abs() < 0.01);
    }

    #[test]
    fn its_growl_halves_its_pitch_every_other_pulse_and_breathes() {
        let rate = 192_000.0;
        let mut held = Held::new(0, rate);
        held.set(&Techniques { growl: Some(Voice { hz: 120.0, level: 0.3, rough: 0.6 }), ..Default::default() }, 0.0).unwrap();
        let x = played(&mut held, 192_000);
        // (A subharmonic at half its pitch, and noise between its partials; neither in a hum.)
        let (sub, own, between) = (magnitude(&x, 60.0, rate), magnitude(&x, 120.0, rate), magnitude(&x, 1230.0, rate));
        assert!(sub > 0.1 * own, "{sub} {own}");
        let mut hum = Held::new(0, rate);
        hum.set(&Techniques { growl: Some(Voice { hz: 120.0, level: 0.3, rough: 0.0 }), ..Default::default() }, 0.0).unwrap();
        let y = played(&mut hum, 192_000);
        assert!(magnitude(&y, 60.0, rate) < 1e-3 * own);
        assert!(between > 3.0 * magnitude(&y, 1230.0, rate) && between < 0.05 * own, "{between} {own}");
    }

    #[test]
    fn its_flutter_closes_the_breath_off_its_depth_at_its_rate_from_open() {
        let rate = 96_000.0;
        let mut held = Held::new(0, rate);
        held.set(&Techniques { flutter: Some(Roll { hz: 25.0, depth: 0.7 }), ..Default::default() }, 0.0).unwrap();
        let x = played(&mut held, 96_000);
        assert_eq!(x[0], 1.0);
        let least = x.iter().fold(1.0f64, |m, &v| m.min(v));
        assert!((least - 0.3).abs() < 1e-6, "{least}");
        // (Shut at each turn's middle: 1/50 s on.)
        assert!((x[1920] - 0.3).abs() < 1e-6, "{}", x[1920]);
    }

    #[test]
    fn a_reed_s_flutter_closes_off_only_the_breath_over_where_its_note_speaks() {
        // (A reed's note blown at 3000 Pa, speaking from 2000: its roll at a depth of 0.7 closes 700 of the 1000 over it,
        // at a depth of 1 all of them and never more; with no floor, as before, 70 % of the whole.)
        let rate = 96_000.0;
        for (depth, least) in [(0.7, 2300.0), (1.0, 2000.0)] {
            let mut held = Held::new(0, rate);
            held.floor = Some(2000.0);
            held.set(&Techniques { flutter: Some(Roll { hz: 25.0, depth }), ..Default::default() }, 0.0).unwrap();
            let x: Vec<f64> = (0..9600).map(|_| { let v = held.applied(3000.0, 0); held.step(); v }).collect();
            assert_eq!(x[0], 3000.0);
            assert!((x[1920] - least).abs() < 1e-6 && x.iter().all(|&v| v >= least - 1e-9), "{depth}: {}", x[1920]);
        }
        let mut held = Held::new(0, rate);
        held.set(&Techniques { flutter: Some(Roll { hz: 25.0, depth: 0.7 }), ..Default::default() }, 0.0).unwrap();
        for _ in 0..1920 {
            held.step();
        }
        assert_eq!(held.applied(3000.0, 0), 3000.0 * held.factor(0));
        // (A breath already under its floor left as it is.)
        held.floor = Some(4000.0);
        assert_eq!(held.applied(3000.0, 0), 3000.0);
    }

    #[test]
    fn it_moves_in_and_out_over_its_time_and_leaves_the_breath_at_none() {
        let rate = 48_000.0;
        let mut held = Held::new(0, rate);
        assert!(!held.active());
        held.set(&Techniques { hum: Some(Voice { hz: 200.0, level: 0.5, rough: 0.0 }), flutter: Some(Roll { hz: 20.0, depth: 1.0 }), ..Default::default() }, 0.1).unwrap();
        let x = played(&mut held, 4800);
        assert!(held.active());
        assert!((x[0] - 1.0).abs() < 1e-9);
        held.set(&Techniques::default(), 0.1).unwrap();
        played(&mut held, 4800);
        assert!(!held.active());
        assert_eq!(held.factor(0), 1.0);
        assert!(held.set(&Techniques { flutter: Some(Roll { hz: 80.0, depth: 0.5 }), ..Default::default() }, 0.0).is_err());
    }
}
