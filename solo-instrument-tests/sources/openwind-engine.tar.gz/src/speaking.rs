//! A wind's speaking map on the engine's own equations (the owner, 14 November 2026, of its design -- the map computed on
//! the engine's start equations, each note by dynamic by place of its breath dial, the start that grows fastest its
//! register, the same outputs, checked against today's maps before render/synthesis/tools/speaking_map.py is archived:
//! "Yes, proceed."; docs/SPEAKING_MAP.md). For each charted note's row at each dynamic, as the dial plays it:
//! - its tube's linear map (starts.rs Tube) about the steady state its breath holds in it -- its map about rest
//!   (kernel.rs bore_map) with the columns that feed its lossy ends read again about that state (bore_columns): a register
//!   vent's or a sharp end's loss, square in the flow through it, half shuts it to the oscillation once a steady flow
//!   passes, and so moves its resonances and their damping (the clarinet's D5: about rest its start at 541 Hz dying at
//!   128/s, the engine's from rest near 570 to 590 Hz at 24 to 33/s; claude-scratch/speaking-map-rust/probe-roots.mjs, 14
//!   November 2026). The steady state found by Newton's steps on the engine's own step (bore_step);
//! - its reed at rest there (starts.rs rested), its resting opening the one at which the steady flow through it holds the
//!   breath against the pressure that flow holds at its reed through the tube;
//! - its tube's resonances: its answer's peaks along the unit circle, each one's pole found from its peak (the root of
//!   1/G), kept where its pole stands in its own stretch, as tools/speaking_map.py keeps its fits;
//! - each resonance's start, followed across the places by Newton's steps from the last place's: the root in z of
//!   K(z)/q(z) - 1, as starts.rs grows has it, its slope by the tube's own factors (G' = -c (z - B)^-2 b);
//! - the race of their growths under the breath's rise from rest (tools/speaking_map.py races), and the note's speaking
//!   range and its margin.
//! Its player's tract is not in it (none: the mouth's pressure alone), as today's maps took none.
use crate::kernel::{BoreMap, Player, ReedConstants};
use crate::sparse::{Banded, Eliminated, Factored, FactoredReal, C};
use crate::starts::{rested, Reed, Rest, Tube};
use serde_json::{json, Value};
use std::cell::OnceCell;
use std::rc::Rc;

// (How the tube's map is read, about rest and about a steady state: as starts.rs reads it.)
const NUDGE: f64 = 1e-6;
// (The reed's resting opening halved so many times between shut and open; a root's Newton's steps, closed under so small
// a step in z, each halved so many times at most until it lowers |f|, but for a step so short that Newton's own is taken
// unasked -- within a root's quadratic reach, where |f| is at its rounding; the steady state's Newton's steps, closed
// under so small a step of its largest double.)
const OPENING_HALVINGS: usize = 64;
const ROOT_STEPS: usize = 40;
const ROOT_CLOSED: f64 = 1e-13;
const HALVINGS: usize = 10;
const TRUSTED: f64 = 1e-9;
const STEADY_STEPS: usize = 30;
const STEADY_CLOSED: f64 = 1e-12;
// (Its rest and its steady state taken again with the pressure the steady state holds at its reed, so many times at most.)
const HELD_AGAIN: usize = 6;
// (Where its resonances are sought: tools/reed_stability.py LOW and HIGH; its answer read every so many cents, each peak
// its pole's first guess.)
const LOW: f64 = 20.0;
const HIGH: f64 = 12000.0;
const SCAN_CENTS: f64 = 10.0;
// (The race: tools/speaking_map.py races -- the first resonance to grow 60 dB, within `held` s.)
const WON: f64 = 6.907755278982137;

/// What the map is asked: its places (the breath dial's x: its breath reach^x times its players'), the dial's reach, its
/// breath's rise from rest (s), how long a note is held before it is heard (s), how many resonances are raced at least,
/// and every how many places its tube is taken again about its steady state where a lossy end moves it.
pub struct Asked {
    pub places: Vec<f64>,
    pub reach: f64,
    pub rise: f64,
    pub held: f64,
    pub resonances: usize,
    pub stride: usize,
    /// (Each stage's time said as it goes.)
    pub trace: bool,
    /// (The places at which its map is checked against the engine stepped, if any.)
    pub checked: Vec<f64>,
    /// (Mapped on its tube itself alone, its fit not tried: "One tube a note", below.)
    pub exact: bool,
}

impl Asked {
    /// tools/speaking_map.py's: from -2 to 1 every eightieth, 1.5 s, eight resonances, every sixth place.
    pub fn standard(reach: f64, rise: f64) -> Asked {
        Asked { places: (0..241).map(|j| -2.0 + 3.0 * j as f64 / 240.0).collect(), reach, rise, held: 1.5, resonances: 8, stride: 6, trace: false, checked: vec![],
                exact: false }
    }
}

/// A tube's linear map laid out for its solves: its pattern eliminated once in the order that keeps it sparse (sparse.rs
/// Eliminated: the clarinet's 9140 doubles took 97 ms an answer in their band), shared by the maps of one fingering about
/// its steady states where their entries stand in it; its band (starts.rs Tube, its pivots chosen) laid out only where a
/// solve in that order does not stand.
struct Laid {
    map: BoreMap,
    order: Rc<Eliminated>,
    slots: Vec<usize>,
    values: Vec<C>,
    // (Its largest row's and column's sums of magnitudes, for each solve's own residual, and its transpose's.)
    norm: f64,
    norm_t: f64,
    band: OnceCell<Tube>,
    band_t: OnceCell<Tube>,
}

thread_local! {
    // (How many times this thread has factored a tube, and how many of its solves were taken again or solved in its band,
    // said where its map is traced.)
    static FACTORED: std::cell::Cell<[usize; 3]> = const { std::cell::Cell::new([0; 3]) };
}

fn factored() -> usize {
    FACTORED.with(|n| n.get()[0])
}

// (Its counts since `from` (tally's), said.)
fn tally() -> [usize; 3] {
    FACTORED.with(|n| n.get())
}

fn spent(from: [usize; 3]) -> String {
    let now = tally();
    format!("{} factored, {} solves taken again, {} in its band", now[0] - from[0], now[1] - from[1], now[2] - from[2])
}

fn counted(which: usize) {
    FACTORED.with(|n| {
        let mut c = n.get();
        c[which] += 1;
        n.set(c);
    });
}

// (A solve stands where its residual is within so much of its matrix's size times its own, and its right side's.)
const STANDS: f64 = 1e-12;

/// z - B factored at one z: in its order, or in its band (or its transpose's).
struct Factors<'a> {
    laid: &'a Laid,
    z: C,
    sparse: Option<Factored<'a>>,
    band: OnceCell<Result<Banded, String>>,
    band_t: OnceCell<Result<Banded, String>>,
}

impl Laid {
    /// Its map laid out in `order` where its entries all stand in it, else in an order of its own.
    fn of(map: BoreMap, order: Option<&Rc<Eliminated>>) -> Laid {
        let pattern: Vec<(usize, usize)> = map.cols.iter().enumerate().flat_map(|(j, col)| col.iter().map(move |&(i, _)| (i, j))).collect();
        let values: Vec<C> = map.cols.iter().flat_map(|col| col.iter().map(|&(_, v)| C::new(-v, 0.0))).collect();
        let (order, slots) = match order.and_then(|o| Some((o.clone(), o.slots(&pattern)?))) {
            Some(found) => found,
            None => {
                let own = Rc::new(Eliminated::of(map.moving.len(), &pattern));
                let slots = own.slots(&pattern).expect("its own pattern");
                (own, slots)
            }
        };
        let mut rows = vec![0.0; map.moving.len()];
        for col in &map.cols {
            for &(i, v) in col {
                rows[i] += v.abs();
            }
        }
        let norm = rows.iter().fold(0.0f64, |m, v| m.max(*v));
        let norm_t = map.cols.iter().map(|col| col.iter().map(|(_, v)| v.abs()).sum::<f64>()).fold(0.0f64, f64::max);
        Laid { map, order, slots, values, norm, norm_t, band: OnceCell::new(), band_t: OnceCell::new() }
    }

    fn n(&self) -> usize {
        self.map.moving.len()
    }

    /// z - B factored: in its order where no pivot of it is nothing, else in its band.
    fn at(&self, z: C) -> Result<Factors<'_>, String> {
        counted(0);
        let sparse = self.order.factor(&self.slots, &self.values, z).ok();
        let f = Factors { laid: self, z, sparse, band: OnceCell::new(), band_t: OnceCell::new() };
        if f.sparse.is_none() {
            f.banded(false)?;
        }
        Ok(f)
    }

    /// (z - B) x, or (`transposed`) (z - B)^T x.
    fn times(&self, z: C, x: &[C], transposed: bool) -> Vec<C> {
        let mut y: Vec<C> = x.iter().map(|v| *v * z).collect();
        for (j, col) in self.map.cols.iter().enumerate() {
            for &(i, v) in col {
                if transposed {
                    y[j] = y[j] - x[i] * v;
                } else {
                    y[i] = y[i] - x[j] * v;
                }
            }
        }
        y
    }

    /// Its band laid out, or its transpose's.
    fn band_of(&self, transposed: bool) -> &Tube {
        if transposed {
            self.band_t.get_or_init(|| {
                let mut cols = vec![vec![]; self.map.cols.len()];
                for (j, col) in self.map.cols.iter().enumerate() {
                    for &(i, v) in col {
                        cols[i].push((j, v));
                    }
                }
                Tube::of(BoreMap { cols, ..self.map.clone() })
            })
        } else {
            self.band.get_or_init(|| Tube::of(self.map.clone()))
        }
    }
}

impl Factors<'_> {
    fn banded(&self, transposed: bool) -> Result<&Banded, String> {
        let cell = if transposed { &self.band_t } else { &self.band };
        cell.get_or_init(|| {
            counted(2);
            let t = self.laid.band_of(transposed);
            let mut m = Banded::new(t.n, t.kl, t.ku);
            for i in 0..t.n {
                m.add(t.position[i], t.position[i], self.z);
            }
            for &(i, j, v) in &t.entries {
                m.add(t.position[i], t.position[j], C::new(-v, 0.0));
            }
            m.lu().map(|_| m)
        }).as_ref().map_err(|e| e.clone())
    }

    /// Whether x solves (z - B) x = r (or its transpose's) as its matrix's size allows (its residual within STANDS of its
    /// size times x's, and r's) -> its residual, where it does not.
    fn misses(&self, x: &[C], r: &[C], transposed: bool) -> Option<Vec<C>> {
        let ax = self.laid.times(self.z, x, transposed);
        let residual: Vec<C> = r.iter().zip(&ax).map(|(a, b)| *a - *b).collect();
        let size = |v: &[C]| v.iter().fold(0.0f64, |m, c| m.max(c.abs()));
        let scale = (self.z.abs() + if transposed { self.laid.norm_t } else { self.laid.norm }) * size(x) + size(r);
        (!(size(&residual) <= STANDS * scale)).then_some(residual)
    }

    /// (z - B) x = r, r and x over the map's moving doubles in their order: in its order, taken again once from its
    /// residual where it does not stand, else in its band.
    fn solve(&self, r: &[C]) -> Result<Vec<C>, String> {
        self.solved_as(r, false)
    }

    /// (z - B)^T x = r, as `solve` solves (z - B) x = r: x^T is r^T (z - B)^-1, the rows of its inverse.
    fn solve_transposed(&self, r: &[C]) -> Result<Vec<C>, String> {
        self.solved_as(r, true)
    }

    fn solved_as(&self, r: &[C], transposed: bool) -> Result<Vec<C>, String> {
        if let Some(f) = &self.sparse {
            let by = |v: &[C]| if transposed { f.solve_transposed(v) } else { f.solve(v) };
            let mut x = by(r);
            let Some(residual) = self.misses(&x, r, transposed) else { return Ok(x) };
            counted(1);
            for (v, d) in x.iter_mut().zip(by(&residual)) {
                *v = *v + d;
            }
            if self.misses(&x, r, transposed).is_none() {
                return Ok(x);
            }
        }
        let m = self.banded(transposed)?;
        let t = self.laid.band_of(transposed);
        let mut rhs = vec![C::default(); r.len()];
        for (i, &v) in r.iter().enumerate() {
            rhs[t.position[i]] = v;
        }
        let x = m.solve(&rhs);
        Ok((0..r.len()).map(|i| x[t.position[i]]).collect())
    }
}

/// The tube's answer at z factored once: G(z) = c (z - B)^-1 b and its slope -c (z - B)^-2 b.
fn answer(tube: &Laid, z: C) -> Result<(C, C), String> {
    solved(tube, &tube.at(z)?)
}

fn solved(tube: &Laid, f: &Factors) -> Result<(C, C), String> {
    let mut rhs = vec![C::default(); tube.n()];
    for &(i, v) in &tube.map.b {
        rhs[i] = C::new(v, 0.0);
    }
    let x1 = f.solve(&rhs)?;
    let x2 = f.solve(&x1)?;
    let dot = |x: &[C]| tube.map.c.iter().fold(C::default(), |s, &(i, v)| s + x[i] * v);
    Ok((dot(&x1), C::default() - dot(&x2)))
}

/// (I - B)^-1 r over the map's moving doubles, in their order.
fn steady_solve(tube: &Laid, r: &[f64]) -> Result<Vec<f64>, String> {
    let rhs: Vec<C> = r.iter().map(|v| C::new(*v, 0.0)).collect();
    Ok(tube.at(C::new(1.0, 0.0))?.solve(&rhs)?.iter().map(|x| x.re).collect())
}

/// Its map with its columns `which` (places in its moving doubles) put in from `columns`.
fn with_columns(map: &BoreMap, which: &[usize], columns: Vec<Vec<(usize, f64)>>) -> BoreMap {
    let mut out = map.clone();
    for (&j, col) in which.iter().zip(columns) {
        out.cols[j] = col;
    }
    out
}

/// The steady state its bore holds with the flow `w` into it at its reed (x = its step from x), its lossy ends' losses
/// as the engine plays them: from `from` (a steady state found before, scaled to this flow) or the linear one (its tube
/// about rest, `rest`), by Newton's steps on its own step, its lossy columns read again at each -> (its state over the
/// map's moving doubles, its map about it). Where it has no lossy end, the linear one and its map.
fn steady(player: &mut Player, row: &[f64], map: &BoreMap, rest: &Laid, lossy: &[usize], w: f64, from: Option<(&[f64], f64)>) -> Result<(Vec<f64>, BoreMap), String> {
    let n = map.moving.len();
    let mut x = match from {
        Some((x, was)) if was != 0.0 && x.len() == n => x.iter().map(|v| v * w / was).collect(),
        _ => {
            let mut b = vec![0.0; n];
            for &(i, v) in &map.b {
                b[i] = v * w;
            }
            steady_solve(rest, &b)?
        }
    };
    if lossy.is_empty() || w == 0.0 {
        return Ok((x, map.clone()));
    }
    for _ in 0..STEADY_STEPS {
        let about = with_columns(map, lossy, player.bore_columns(row, w, &map.moving, &x, lossy, NUDGE)?);
        let stepped = player.bore_step(row, &map.moving, &x, w)?;
        let f: Vec<f64> = stepped.iter().zip(&x).map(|(s, v)| s - v).collect();
        let delta = steady_solve(&Laid::of(about, Some(&rest.order)), &f)?;
        let largest = x.iter().fold(0.0f64, |m, v| m.max(v.abs())).max(f64::MIN_POSITIVE);
        let moved = delta.iter().fold(0.0f64, |m, v| m.max(v.abs()));
        for (v, d) in x.iter_mut().zip(&delta) {
            *v += d;
        }
        if moved <= STEADY_CLOSED * largest {
            break;
        }
    }
    let about = with_columns(map, lossy, player.bore_columns(row, w, &map.moving, &x, lossy, NUDGE)?);
    Ok((x, about))
}

/// The reed's breath's share at rest at its opening `rest` against `held` (the pressure the steady flow holds at its
/// reed, over that flow: starts.rs grows' g1) -- starts.rs grows' gamma_of.
fn gamma_of(rest: &Rest, k: &ReedConstants, held: f64) -> f64 {
    held * rest.w_over * k.sp / (k.zc * k.sf) - rest.pi_less_gamma
}

/// Its reed's resting opening at the breath `gamma` against `held`: the breath falls from where it rests shut to none
/// as it opens (starts.rs grows) -> its opening and its rest, or none where it rests shut there.
fn rest_at(reed: &Reed, k: &ReedConstants, gamma: f64, held: f64) -> Option<(f64, Rest)> {
    let shut = gamma_of(&rested(reed, k, 0.0)?, k, held);
    if !(gamma > 0.0) || gamma >= shut {
        return None;
    }
    let (mut lo, mut hi) = (0.0, 1.0);
    for _ in 0..OPENING_HALVINGS {
        let m = 0.5 * (lo + hi);
        match rested(reed, k, m) {
            Some(r) if gamma_of(&r, k, held) >= gamma => lo = m,
            _ => hi = m,
        }
    }
    let y = 0.5 * (lo + hi);
    Some((y, rested(reed, k, y)?))
}

/// Its start's equation at z, K(z)/q(z) - 1 (starts.rs grows, its tract none), and its slope, from the tube's answer
/// there and its slope (g, dg).
fn equation_of(g: C, dg: C, rest: &Rest, k: &ReedConstants, z: C) -> (C, C) {
    let one = C::new(1.0, 0.0);
    let lambda = k.zc / (k.alpha * k.simp);
    let a = k.sp * lambda / (k.zc * k.sf);
    let (lt, dlt) = (g * a, dg * a);
    let q = lt * lambda / (lt - one);
    let dq = dlt * (-lambda) / ((lt - one) * (lt - one));
    let d = C::new(1e-7, 0.0);
    let (kz, dk) = (rest.k(z), (rest.k(z + d) - rest.k(z - d)) / (d * 2.0));
    (kz / q - one, (dk * q - kz * dq) / (q * q))
}

/// A root of f (its value and slope at z: `f`) by Newton's steps from `from`, each no longer than `limit` and halved
/// until |f| falls -- an analytic function's modulus has no hollow but its roots, so they go down to the one nearest
/// rather than leaping to another far off (1/G's from a broad resonance had leapt to the scheme's own poles near 106 kHz)
/// -- closed under ROOT_CLOSED -> the root, or why none.
fn newton(f: impl Fn(C) -> Result<(C, C), String>, from: C, limit: f64) -> Result<C, String> {
    let (mut z, (mut v, mut d)) = (from, f(from)?);
    for _ in 0..ROOT_STEPS {
        let mut dz = v / d;
        if !(dz.re.is_finite() && dz.im.is_finite()) {
            return Err("its step not finite".into());
        }
        if dz.abs() > limit {
            dz = dz * (limit / dz.abs());
        }
        let mut halved = 0;
        loop {
            let next = z - dz;
            let (w, e) = f(next)?;
            if w.abs() < v.abs() || dz.abs() <= TRUSTED {
                (z, v, d) = (next, w, e);
                break;
            }
            halved += 1;
            if halved > HALVINGS {
                return Err(format!("no step lowers it, at |f| {:.1e}", v.abs()));
            }
            dz = dz * 0.5;
        }
        if dz.abs() <= ROOT_CLOSED {
            return Ok(z);
        }
    }
    Err(format!("not closed in {ROOT_STEPS} steps"))
}

/// A start's root from `from` by Newton's steps, each within `limit`, on the tube's answer `answer` (G and its slope at z:
/// the tube's own, or its fit's) -> (its growth 1/s, its frequency Hz), none where its steps do not close.
fn root_on(answer: impl Fn(C) -> Result<(C, C), String>, rest: &Rest, k: &ReedConstants, rate: f64, from: C, limit: f64) -> Option<(f64, f64)> {
    let z = newton(|z| answer(z).map(|(g, dg)| equation_of(g, dg, rest, k, z)), from, limit).ok()?;
    let f = z.arg() * rate / (2.0 * std::f64::consts::PI);
    (z.abs() > 0.0 && f > 0.0).then(|| (rate * z.abs().ln(), f))
}

fn root(tube: &Laid, rest: &Rest, k: &ReedConstants, rate: f64, from: C, limit: f64) -> Option<(f64, f64)> {
    root_on(|z| answer(tube, z), rest, k, rate, from, limit)
}

/// A resonance: the pole (its frequency, Hz, and its damping, 1/s) of the answer `answer` found from `from` -- the root
/// of 1/G by Newton's steps, each within `limit`.
fn pole_on(answer: impl Fn(C) -> Result<(C, C), String>, rate: f64, from: C, limit: f64) -> Result<(f64, f64), String> {
    let hz = |z: C| z.arg() * rate / (2.0 * std::f64::consts::PI);
    // (1/G and its slope -G'/G^2.)
    let z = newton(|z| answer(z).map(|(g, dg)| (g.inv(), C::default() - dg / (g * g))), from, limit)
        .map_err(|e| format!("from {:.2} Hz: {e}", hz(from)))?;
    if hz(z) > 0.0 { Ok((hz(z), rate * z.abs().ln())) } else { Err(format!("closed at {:.2} Hz", hz(z))) }
}

fn pole(tube: &Laid, rate: f64, from: C, limit: f64) -> Result<(f64, f64), String> {
    pole_on(|z| answer(tube, z), rate, from, limit)
}

/// Resonance n's stretch: halfway to its neighbours, a fifth beyond it at either end (tools/speaking_map.py band).
fn band(hz: &[f64], n: usize) -> (f64, f64) {
    (if n > 0 { (hz[n - 1] + hz[n]) / 2.0 } else { 0.8 * hz[n] }, if n + 1 < hz.len() { (hz[n] + hz[n + 1]) / 2.0 } else { 1.2 * hz[n] })
}

/// A resonance of the tube: the pole of its answer it stands for -- its frequency (Hz) and its damping (1/s) -- and so its
/// Q, pi f / -damping. Its frequency the pole's, not its answer's peak's, as tools/speaking_map.py reads its impedance's:
/// G is its bore's answer without the scheme's own share at its reed (starts.rs grows' simp), which moves its peaks but not
/// its poles (the clarinet's G3, 14 November 2026: its lowest pole at 205.65 Hz, Q 19.0; G's peak at 205.56 Hz, Q 22.2 by
/// its line there; the tool's on OpenWInD's impedance 206.99 Hz, Q 19.2).
#[derive(Clone, Copy, Debug)]
struct Resonance {
    hz: f64,
    q: f64,
    pole: (f64, f64),
}

impl Resonance {
    fn of(pole: (f64, f64)) -> Resonance {
        Resonance { hz: pole.0, q: std::f64::consts::PI * pole.0 / -pole.1, pole }
    }
}

/// The pole a peak of its answer along the unit circle stands for, from the three readings about it (`seen`: (hz, G), the
/// middle the largest): Newton's steps on 1/G from the middle reading's z, else from where a single resonance's shape
/// through the three puts its pole -- 1/|G|^2 a parabola in f, its vertex its frequency and its height over its curvature
/// its half-width squared -- kept where it stands within its own width (or that shape's, or the readings' spacing) of the
/// peak -> its resonance, or why none (a ripple on a slope, a shoulder).
fn peak_pole(tube: &Laid, rate: f64, seen: &[(f64, C)]) -> Result<Resonance, String> {
    peak_pole_on(&|z| answer(tube, z), rate, seen)
}

/// peak_pole on the answer `answer` (the tube's own, or its fit's).
fn peak_pole_on(answer: &dyn Fn(C) -> Result<(C, C), String>, rate: f64, seen: &[(f64, C)]) -> Result<Resonance, String> {
    let pole = |rate: f64, from: C, limit: f64| pole_on(answer, rate, from, limit);
    let (f1, f2, f3) = (seen[0].0, seen[1].0, seen[2].0);
    let (y1, y2, y3) = (seen[0].1.abs().powi(-2), seen[1].1.abs().powi(-2), seen[2].1.abs().powi(-2));
    let (d1, d3) = (f1 - f2, f3 - f2);
    let a = ((y1 - y2) / d1 - (y3 - y2) / d3) / (d1 - d3);
    let b = (y1 - y2) / d1 - a * d1;
    let (centre, height) = if a > 0.0 { (f2 - b / (2.0 * a), y2 - b * b / (4.0 * a)) } else { (f2, -1.0) };
    let half = if height > 0.0 { (height / a).sqrt() } else { f64::NAN };
    let (tau, spacing) = (2.0 * std::f64::consts::PI, f3 - f1);
    let near = |p: (f64, f64)| -> Result<(f64, f64), String> {
        let width = spacing.max(-p.1 / tau).max(if half.is_finite() { half } else { 0.0 });
        if p.1 < 0.0 && (p.0 - centre).abs() <= width {
            Ok(p)
        } else {
            Err(format!("its pole at {:.2} Hz, {:.1}/s, beyond {width:.1} Hz of {centre:.2}", p.0, p.1))
        }
    };
    let limit = tau * spacing.max(if half.is_finite() { half } else { 0.0 }) / rate;
    let first = pole(rate, C::polar(1.0, tau * f2 / rate), limit).and_then(near);
    first.or_else(|e| {
        if !half.is_finite() {
            return Err(format!("from the peak: {e}; its shape no single resonance's"));
        }
        pole(rate, C::polar((-tau * half / rate).exp(), tau * centre / rate), limit).and_then(near)
            .map_err(|f| format!("from the peak: {e}; from its shape ({centre:.2} Hz, half {half:.1} Hz): {f}"))
    }).map(Resonance::of)
}

/// The tube's resonances from LOW up -- the lowest `count` and every one under half again `target`, and one past them --
/// its answer's peaks along the unit circle every SCAN_CENTS, each read and its pole found (peak_pole), kept where its pole
/// stands in its own stretch and its damping's width within it, the stretches drawn between the peaks kept (tools/
/// speaking_map.py resonances).
fn resonances(tube: &Laid, rate: f64, target: f64, count: usize, trace: bool) -> Result<Vec<Resonance>, String> {
    let at = |f: f64| -> Result<(f64, C), String> { Ok((f, answer(tube, C::polar(1.0, 2.0 * std::f64::consts::PI * f / rate))?.0)) };
    let top = HIGH.min(0.45 * rate);
    let step = 2f64.powf(SCAN_CENTS / 1200.0);
    let (mut f, mut seen) = (LOW, vec![at(LOW)?]);
    let mut found: Vec<Resonance> = vec![];
    while f < top {
        f *= step;
        seen.push(at(f)?);
        let k = seen.len();
        // (A peak at the middle of the last three readings.)
        if k >= 3 && seen[k - 2].1.abs() > seen[k - 3].1.abs() && seen[k - 2].1.abs() >= seen[k - 1].1.abs() {
            let before = factored();
            let got = peak_pole(tube, rate, &seen[k - 3..]).and_then(|r| match found.iter().find(|s| (s.pole.0 / r.pole.0).ln().abs() <= 1e-6) {
                Some(s) => Err(format!("its pole at {:.2} Hz, found before", s.pole.0)),
                None => Ok(r),
            });
            if trace {
                let said = match &got {
                    Ok(r) => format!("{:.2} Hz, Q {:.1}; its pole at {:.2} Hz, {:.1}/s", r.hz, r.q, r.pole.0, r.pole.1),
                    Err(e) => format!("none -- {e}"),
                };
                eprintln!("    a peak at {:.1} Hz: {said} ({} factored)", seen[k - 2].0, factored() - before);
            }
            if let Ok(r) = got {
                found.push(r);
                let under = found.iter().filter(|r| r.hz < 1.5 * target).count();
                if found.len() > count.max(under) {
                    break;
                }
            }
        }
    }
    Ok(kept_of(found, target, count))
}

/// The resonances found kept: in order, each where its pole stands in its stretch and its width within it, the stretches
/// drawn again among those kept until all stand; the lowest `count` and every one under half again `target`, and one past.
fn kept_of(mut found: Vec<Resonance>, target: f64, count: usize) -> Vec<Resonance> {
    found.sort_by(|a, b| a.hz.total_cmp(&b.hz));
    let mut kept = found;
    loop {
        let hz: Vec<f64> = kept.iter().map(|r| r.hz).collect();
        let good: Vec<bool> = kept.iter().enumerate().map(|(n, r)| {
            let (lo, hi) = band(&hz, n);
            lo <= r.pole.0 && r.pole.0 <= hi && -r.pole.1 / std::f64::consts::PI <= hi - lo
        }).collect();
        if good.iter().all(|g| *g) {
            break;
        }
        kept = kept.into_iter().zip(good).filter(|(_, g)| *g).map(|(r, _)| r).collect();
    }
    let under = kept.iter().filter(|r| r.hz < 1.5 * target).count();
    kept.truncate(count.max(under + 1));
    kept
}

/// A resonance found again on a tube about a steady state: its pole from its pole at rest -> it, or as it was where none
/// is found there.
fn read_again(tube: &Laid, rate: f64, at_rest: &Resonance) -> Resonance {
    let tau = 2.0 * std::f64::consts::PI;
    let (f, sigma) = at_rest.pole;
    match pole(tube, rate, C::polar((sigma / rate).exp(), tau * f / rate), (-sigma).max(tau * 10.0) / rate) {
        Ok(p) if p.1 < 0.0 => Resonance::of(p),
        _ => *at_rest,
    }
}

/// Each note's maps at its dynamics (`rows`: [(dynamic, its row)], one fingering), its pitch `target` Hz, on the player
/// as it stands -> [(dynamic, its map as tools/speaking_map.py note_map writes it)]. Its player in doubles and on one
/// thread; its doubles put back as they stood.
pub fn note_maps(player: &mut Player, rate: f64, rows: &[(String, Vec<f64>)], target: f64, asked: &Asked) -> Result<Vec<(String, Value)>, String> {
    let single = player.single() && !player.crewed();
    if single {
        player.in_doubles(true);
    }
    let tract = player.tract.take();
    let kept = player.data().to_vec();
    let found = mapped(player, rate, rows, target, asked);
    player.set_data(&kept);
    player.tract = tract;
    if single {
        player.in_doubles(false);
    }
    found
}

fn mapped(player: &mut Player, rate: f64, rows: &[(String, Vec<f64>)], target: f64, asked: &Asked) -> Result<Vec<(String, Value)>, String> {
    let place = player.reed_place()?;
    let k = player.reed_constants()?;
    if k.lips {
        return Err(crate_unported("the lips' starts (their inward mode)"));
    }
    let u = place.columns;
    let first = &rows.first().ok_or("no row")?.1;
    if first.len() <= u + 8 {
        return Err("a row without its reed's columns".into());
    }
    // (Its fingering's tube about rest, its caches brought to this row first by a few steps of it.)
    let mut out = vec![0.0; player.columns().1 * 4];
    let mut stepped = Vec::with_capacity(first.len() * 4);
    for _ in 0..4 {
        stepped.extend_from_slice(first);
    }
    player.steps(&stepped, &mut out, 4);
    let since = std::time::Instant::now();
    let map = player.bore_map(first, 0.0, NUDGE, true)?;
    // (The columns its lossy ends' flows are read from: their rows in its map.)
    let flows: Vec<usize> = player.lossy_flows().iter().filter_map(|w| map.moving.iter().position(|m| m == w)).collect();
    let mut lossy: Vec<usize> = (0..map.cols.len()).filter(|&j| map.cols[j].iter().any(|(i, _)| flows.contains(i))).collect();
    lossy.dedup();
    let rest_tube = Laid::of(map.clone(), None);
    if asked.trace {
        let laid = since.elapsed().as_secs_f64();
        // (Its answers in its order against its band's, along the unit circle and inside it: their largest difference
        // beside the answer.)
        let one = std::time::Instant::now();
        answer(&rest_tube, C::polar(1.0, 0.1))?;
        let took = one.elapsed().as_secs_f64();
        let mut worst = 0.0f64;
        for k in 0..24 {
            let z = C::polar(if k % 2 == 0 { 1.0 } else { 0.999 }, std::f64::consts::PI * (k as f64 + 0.5) / 24.0);
            let (g, dg) = answer(&rest_tube, z)?;
            let (gb, dgb) = solved(&rest_tube, &Factors { laid: &rest_tube, z, sparse: None, band: OnceCell::new(), band_t: OnceCell::new() })?;
            worst = worst.max((g - gb).abs() / gb.abs()).max((dg - dgb).abs() / dgb.abs());
        }
        let doubles = player.data().len();
        eprintln!("  its tube about rest: {laid:.2} s, {} doubles of its {doubles}, {} entries and {} with its fill, one answer {:.3} ms, against its band's at most {worst:.1e} apart; {} lossy flows, {} columns feed them",
                  rest_tube.n(), rest_tube.slots.len(), rest_tube.order.size, took * 1e3, flows.len(), lossy.len());
    }
    // (Its fitted path first ("One tube a note", below); its tube itself where its fit is refused, or where that is asked.)
    let mut refused = None;
    if !asked.exact {
        match fitted_maps(player, rate, rows, u, &k, &map, &rest_tube, &lossy, target, asked) {
            Ok(maps) => return Ok(maps),
            Err(why) => {
                if asked.trace {
                    eprintln!("  its fit refused ({why}): mapped on its tube itself");
                }
                refused = Some(why);
            }
        }
    }
    let (began, counts) = (std::time::Instant::now(), tally());
    let at_rest = resonances(&rest_tube, rate, target, asked.resonances, asked.trace)?;
    if asked.trace {
        eprintln!("  its resonances: {:.2} s ({}), {:?}", began.elapsed().as_secs_f64(), spent(counts), at_rest.iter().map(|r| (r.hz.round(), r.pole.1.round())).collect::<Vec<_>>());
    }
    if at_rest.is_empty() {
        return Err("its tube has no resonance between 20 Hz and 12 kHz".into());
    }
    let mut maps = vec![];
    for (dynamic, row) in rows {
        let mut m = dynamic_map(player, rate, row, u, &k, &map, &rest_tube, &lossy, &at_rest, target, asked)?;
        if let Some(why) = &refused {
            m["fit"] = json!({"refused": why});
        }
        maps.push((dynamic.clone(), m));
    }
    Ok(maps)
}

// (A refusal for what is not made here yet, as the maker's: its callers take what is kept instead.)
fn crate_unported(what: &str) -> String {
    format!("{what}: not yet made in Rust (unported)")
}

/// A place's starts: none where its reed rests shut, else each resonance's (growth 1/s, frequency Hz), none where no root
/// of it stands in its stretch.
type Taken = Option<Vec<Option<(f64, f64)>>>;

/// The resonance growing fastest among a place's growths, or -1 where none grows.
fn leader(s: &[f64]) -> i64 {
    let (best, at) = s.iter().enumerate().fold((f64::NEG_INFINITY, -1i64), |(b, a), (r, v)| if *v > b { (*v, r as i64) } else { (b, a) });
    if best > 0.0 { at } else { -1 }
}

/// Whether two places taken differ in what a map reads off them: whether its reed rests shut, whether each resonance's
/// root stands, the sign of its growth, the resonance that leads.
fn differs(a: &Taken, b: &Taken) -> bool {
    let growths = |t: &[Option<(f64, f64)>]| -> Vec<f64> { t.iter().map(|r| r.map_or(f64::NEG_INFINITY, |r| r.0)).collect() };
    match (a, b) {
        (None, None) => false,
        (Some(x), Some(y)) => leader(&growths(x)) != leader(&growths(y)) || x.iter().zip(y).any(|(p, q)| match (p, q) {
            (Some(p), Some(q)) => (p.0 > 0.0) != (q.0 > 0.0),
            (None, None) => false,
            _ => true,
        }),
        _ => true,
    }
}

/// Every place's growths and frequencies from the places taken, drawn straight between two taken next to one another
/// where both have a root of that resonance (none between where either has none: where they differ so, every place
/// between them is taken) -> (growths, frequencies), [place][resonance].
fn drawn(taken: &[Option<Taken>], n: usize) -> (Vec<Vec<f64>>, Vec<Vec<f64>>) {
    let (mut sigma, mut heard) = (vec![vec![f64::NEG_INFINITY; n]; taken.len()], vec![vec![f64::NAN; n]; taken.len()]);
    let at: Vec<usize> = (0..taken.len()).filter(|&j| taken[j].is_some()).collect();
    for &j in &at {
        if let Some(Some(roots)) = &taken[j] {
            for (r, root) in roots.iter().enumerate() {
                if let Some((g, f)) = root {
                    (sigma[j][r], heard[j][r]) = (*g, *f);
                }
            }
        }
    }
    for w in at.windows(2) {
        let (a, b) = (w[0], w[1]);
        for j in a + 1..b {
            let t = (j - a) as f64 / (b - a) as f64;
            for r in 0..n {
                if sigma[a][r].is_finite() && sigma[b][r].is_finite() {
                    sigma[j][r] = sigma[a][r] + (sigma[b][r] - sigma[a][r]) * t;
                    heard[j][r] = heard[a][r] + (heard[b][r] - heard[a][r]) * t;
                }
            }
        }
    }
    (sigma, heard)
}

#[allow(clippy::too_many_arguments)]
fn dynamic_map(player: &mut Player, rate: f64, row: &[f64], u: usize, k: &ReedConstants, map: &BoreMap, rest_tube: &Laid, lossy: &[usize],
               at_rest: &[Resonance], target: f64, asked: &Asked) -> Result<Value, String> {
    let reed = Reed::of(row, u);
    let base = row[u];
    let places = &asked.places;
    let shares: Vec<f64> = places.iter().map(|x| asked.reach.powf(*x)).collect();
    let fs = reed.closing / (k.zc * k.sf);
    let g1 = answer(rest_tube, C::new(1.0, 0.0))?.0.re;
    // (Its tube about the steady state at a breath, and its reed's rest there: the pressure that steady flow holds at its
    // reed taken again until its rest and its flow agree; each steady state begun from the last found, scaled to its flow.
    // Its map about it none where its tube is its tube about rest: no lossy end, or no flow.)
    let mut found: Option<(Vec<f64>, f64)> = None;
    let mut held_at = |gamma: f64| -> Result<Option<(f64, Rest, Option<BoreMap>)>, String> {
        let mut held = g1;
        let mut about = None;
        let mut last = None;
        for _ in 0..HELD_AGAIN {
            let Some((y, rest)) = rest_at(&reed, k, gamma, held) else { return Ok(None) };
            let w = rest.w_over * fs;
            if lossy.is_empty() || w == 0.0 {
                return Ok(Some((y, rest, None)));
            }
            let (x, m) = steady(player, row, map, rest_tube, lossy, w, found.as_ref().map(|(x, was)| (&x[..], *was)))?;
            let pressure = map.c.iter().fold(0.0, |s, &(i, v)| s + x[i] * v);
            let now = pressure / w;
            about = Some(m);
            found = Some((x, w));
            let done = last.is_some_and(|l: f64| (now - l).abs() <= 1e-12 * now.abs());
            last = Some(now);
            held = now;
            if done {
                break;
            }
        }
        Ok(rest_at(&reed, k, gamma, held).map(|(y, rest)| (y, rest, about)))
    };
    let middle = places.iter().enumerate().min_by(|a, b| a.1.abs().total_cmp(&b.1.abs())).map(|(j, _)| j).unwrap();
    // (Its resonances as at its players' breath: each read again on its tube there (read_again), as tools/speaking_map.py
    // reads them on its curve at their breath.)
    let tau = 2.0 * std::f64::consts::PI;
    let res: Vec<Resonance> = match held_at(base)? {
        Some((_, _, Some(m))) => {
            let mid_tube = Laid::of(m, Some(&rest_tube.order));
            at_rest.iter().map(|r| read_again(&mid_tube, rate, r)).collect()
        }
        _ => at_rest.to_vec(),
    };
    let hz0: Vec<f64> = res.iter().map(|r| r.hz).collect();
    let q0: Vec<f64> = res.iter().map(|r| r.q).collect();
    let bands: Vec<(f64, f64)> = (0..hz0.len()).map(|n| band(&hz0, n)).collect();
    let n = hz0.len();
    // (Each place taken: none where its reed rests shut there, else each resonance's (growth, frequency) where its root
    // stands in its stretch. Taken every `stride`-th place, the first, its players' breath and the last; then every place
    // between two taken that differ in what a place's map reads off them -- whether its reed rests shut, whether a root
    // stands, the sign of a growth, the resonance that leads -- and between two where its race's winner differs; drawn
    // straight between the rest (tools/speaking_map.py draws every sixth straight where a lossy end moves its tube).)
    let mut taken: Vec<Option<Taken>> = vec![None; places.len()];
    let mut spent_on = vec![(0usize, 0usize); n];
    let (began, counts) = (std::time::Instant::now(), tally());
    let mut take_run = |run: &[usize], taken: &mut Vec<Option<Taken>>| -> Result<(), String> {
        // (Each resonance's roots at the last two places taken, each root begun where those two put it -- the run's first
        // from the place taken just under it -- else at its pole.)
        let mut last: Vec<Vec<(usize, C)>> = vec![vec![]; n];
        if let Some(a) = run.first().and_then(|&first| (0..first).rev().find(|&i| taken[i].is_some())) {
            if let Some(Some(roots)) = &taken[a] {
                for (r, root) in roots.iter().enumerate() {
                    if let Some((g, f)) = root {
                        last[r].push((a, C::polar((g / rate).exp(), tau * f / rate)));
                    }
                }
            }
        }
        for &j in run {
            let at = std::time::Instant::now();
            let held = held_at(base * shares[j])?;
            if asked.trace && (j % 24 == 0 || j + 1 == places.len()) {
                eprintln!("  place {:.3}: its steady state and rest {:.3} s", places[j], at.elapsed().as_secs_f64());
            }
            let Some((_, rest, about)) = held else {
                taken[j] = Some(None);
                last = vec![vec![]; n];
                continue;
            };
            let own;
            let tube = match about {
                Some(m) => {
                    own = Laid::of(m, Some(&rest_tube.order));
                    &own
                }
                None => rest_tube,
            };
            let mut roots = vec![None; n];
            for r in 0..n {
                let from = match last[r][..] {
                    [(i, a), (l, b)] => b + (b - a) * ((j - l) as f64 / (l - i) as f64),
                    [(_, b)] => b,
                    _ => C::polar((res[r].pole.1 / rate).exp(), tau * res[r].pole.0 / rate),
                };
                let before = factored();
                let found = root(tube, &rest, k, rate, from, tau * (bands[r].1 - bands[r].0) / (4.0 * rate)).filter(|(_, f)| bands[r].0 <= *f && *f <= bands[r].1);
                spent_on[r].1 += factored() - before;
                match found {
                    Some((g, f)) => {
                        spent_on[r].0 += 1;
                        roots[r] = Some((g, f));
                        last[r].push((j, C::polar((g / rate).exp(), tau * f / rate)));
                        if last[r].len() > 2 {
                            last[r].remove(0);
                        }
                    }
                    None => last[r].clear(),
                }
            }
            taken[j] = Some(Some(roots));
        }
        Ok(())
    };
    // (The runs of places between two taken next to one another that `differ`.)
    let between = |taken: &[Option<Taken>], differ: &dyn Fn(usize, usize) -> bool| -> Vec<Vec<usize>> {
        let at: Vec<usize> = (0..places.len()).filter(|&j| taken[j].is_some()).collect();
        at.windows(2).filter(|w| w[1] - w[0] > 1 && differ(w[0], w[1])).map(|w| (w[0] + 1..w[1]).collect()).collect()
    };
    let stride = asked.stride.max(1);
    let first: Vec<usize> = (0..places.len()).filter(|&j| j % stride == 0 || j + 1 == places.len() || j == middle).collect();
    take_run(&first, &mut taken)?;
    let read = |t: &Option<Taken>| t.clone().expect("taken");
    for run in between(&taken, &|a, b| differs(&read(&taken[a]), &read(&taken[b]))) {
        take_run(&run, &mut taken)?;
    }
    let (mut sigma, mut heard) = drawn(&taken, n);
    let (mut winner, mut seconds) = races(&sigma, &shares, asked.rise, asked.held);
    let runs = between(&taken, &|a, b| winner[a] != winner[b]);
    if !runs.is_empty() {
        for run in runs {
            take_run(&run, &mut taken)?;
        }
        (sigma, heard) = drawn(&taken, n);
        (winner, seconds) = races(&sigma, &shares, asked.rise, asked.held);
    }
    let count = taken.iter().filter(|t| t.is_some()).count();
    if asked.trace {
        eprintln!("  {count} places taken in {:.2} s ({}); each resonance's roots found and factorings: {:?}", began.elapsed().as_secs_f64(), spent(counts), spent_on);
    }
    let taken: Vec<bool> = taken.iter().map(|t| t.is_some()).collect();
    let mut out = written(&sigma, &heard, &taken, &winner, &seconds, &hz0, &q0, target, places, middle, !lossy.is_empty(), asked.trace);
    if !asked.checked.is_empty() {
        // (Each place's rest first, then the engine stepped from each.)
        let mut wanted = vec![];
        for (j, r) in check_places(places, &sigma, &heard, &asked.checked) {
            let held = match r {
                Some(_) => held_at(base * shares[j])?.map(|(y, rest, _)| (y, rest)),
                None => None,
            };
            wanted.push((j, r, held));
        }
        out["checked"] = json!(engine_checks(player, rate, row, u, k, fs, base, &shares, places, &sigma, &heard, wanted, asked.trace)?);
    }
    Ok(out)
}

// (Rounded to so many places.)
fn round(v: f64, places: i32) -> f64 {
    let s = 10f64.powi(places);
    (v * s).round() / s
}

/// A dynamic's map as tools/speaking_map.py note_map wrote it, from every place's growths and frequencies (`sigma`,
/// `heard`) and its race (`winner`, `seconds`): its asked resonance, its leading and its sounding resonance at each place
/// of its dial, its speaking range and margin, each resonance's growth at its players' breath and where it begins to grow;
/// traced, every place's growths and frequencies, and whether each was taken or drawn between.
#[allow(clippy::too_many_arguments)]
fn written(sigma: &[Vec<f64>], heard: &[Vec<f64>], taken: &[bool], winner: &[i64], seconds: &[Option<f64>], hz0: &[f64], q0: &[f64],
           target: f64, places: &[f64], middle: usize, lossy: bool, trace: bool) -> Value {
    let n = hz0.len();
    let asked_n = (0..n).min_by(|a, b| (hz0[*a] / target).ln().abs().total_cmp(&(hz0[*b] / target).ln().abs())).unwrap();
    let dial: Vec<usize> = (0..places.len()).filter(|&j| places[j] >= -1.0 - 1e-9).collect();
    let leading: Vec<i64> = sigma.iter().map(|s| leader(s)).collect();
    let sounds: Vec<bool> = dial.iter().map(|&j| winner[j] == asked_n as i64).collect();
    let mut runs: Vec<(usize, usize)> = vec![];
    let mut start = None;
    for (j, &s) in sounds.iter().enumerate() {
        if s && start.is_none() {
            start = Some(j);
        }
        if (!s || j + 1 == sounds.len()) && start.is_some() {
            runs.push((start.unwrap(), if s { j } else { j - 1 }));
            start = None;
        }
    }
    let here = middle - dial[0];
    let run = runs.iter().copied().find(|r| r.0 <= here && here <= r.1);
    let nearest = run.or_else(|| runs.iter().copied().min_by_key(|r| r.0.abs_diff(here).min(r.1.abs_diff(here))));
    let margin = run.map(|r| places[dial[r.1]].min(-places[dial[r.0]]));
    let first_grows = |r: usize| dial.iter().find(|&&j| sigma[j][r] > 0.0).map(|&j| round(places[j], 3));
    let resonances: Vec<Value> = (0..n).map(|r| json!({
        "hz": round(hz0[r], 2), "q": round(q0[r], 1),
        "growth": if sigma[middle][r].is_finite() { json!(round(sigma[middle][r], 2)) } else { Value::Null },
        "rootHz": if heard[middle][r].is_finite() { json!(round(heard[middle][r], 2)) } else { Value::Null },
        "misfit": Value::Null, "grows": first_grows(r),
    })).collect();
    let mut out = json!({
        "asked": asked_n, "askedHz": round(hz0[asked_n], 2), "cents": round(1200.0 * (hz0[asked_n] / target).log2(), 1),
        "resonances": resonances,
        "leads": dial.iter().map(|&j| leading[j]).collect::<Vec<_>>(),
        "sounds": dial.iter().map(|&j| winner[j]).collect::<Vec<_>>(),
        "speaks": winner[middle] == asked_n as i64,
        "range": nearest.map(|r| vec![round(places[dial[r.0]], 3), round(places[dial[r.1]], 3)]),
        "margin": margin.map(|m| round(m, 3)),
        "race": {"winner": winner[middle], "seconds": seconds[middle].map(|s| round(s, 4))},
        "lossy": lossy,
    });
    if trace {
        let finite = |v: f64, d: i32| if v.is_finite() { json!(round(v, d)) } else { Value::Null };
        out["traced"] = json!({
            "places": places.iter().map(|x| round(*x, 4)).collect::<Vec<_>>(),
            "taken": taken,
            "growths": sigma.iter().map(|s| s.iter().map(|v| finite(*v, 2)).collect::<Vec<_>>()).collect::<Vec<_>>(),
            "hz": heard.iter().map(|h| h.iter().map(|v| finite(*v, 2)).collect::<Vec<_>>()).collect::<Vec<_>>(),
        });
    }
    out
}

/// The places its map is checked against the engine at (`checked`): the place nearest each, and the resonance leading
/// there (the fastest of those with a root), if any.
fn check_places(places: &[f64], sigma: &[Vec<f64>], heard: &[Vec<f64>], checked: &[f64]) -> Vec<(usize, Option<usize>)> {
    checked.iter().map(|&x| {
        let j = (0..places.len()).min_by(|a, b| (places[*a] - x).abs().total_cmp(&(places[*b] - x).abs())).unwrap();
        let r = (0..sigma[j].len()).filter(|&r| sigma[j][r].is_finite() && heard[j][r].is_finite()).max_by(|a, b| sigma[j][*a].total_cmp(&sigma[j][*b]));
        (j, r)
    }).collect()
}

/// Its map checked against the engine at each place `wanted` (the place, its leading resonance, its reed's resting opening
/// and rest there): the engine stepped from the steady state the map is taken about -- its bore held under that steady
/// flow, its reed set at its rest there and nudged (starts.rs engine_growth) -- and the growth and pitch it sounds about
/// that resonance's root, beside the map's.
#[allow(clippy::too_many_arguments)]
fn engine_checks(player: &mut Player, rate: f64, row: &[f64], u: usize, k: &ReedConstants, fs: f64, base: f64, shares: &[f64], places: &[f64], sigma: &[Vec<f64>],
                 heard: &[Vec<f64>], wanted: Vec<(usize, Option<usize>, Option<(f64, Rest)>)>, trace: bool) -> Result<Vec<Value>, String> {
    let mut checks = vec![];
    for (j, r, held) in wanted {
        let (Some(r), Some((y, rest))) = (r, held) else {
            checks.push(json!({"x": round(places[j], 4), "why": "its reed rests shut there, or no root"}));
            continue;
        };
        let mut blown = row.to_vec();
        blown[u] = base * shares[j];
        let [onset, stiffness, exponent, ..] = k.lay;
        let contact = if stiffness > 0.0 { (k.contact + 2.0 * stiffness / (exponent + 1.0) * (onset - y).max(0.0).powf(exponent + 1.0)).sqrt() } else { 0.0 };
        let (g, h, seconds) = crate::starts::engine_growth(player, rate, &blown, u, rest.w_over * fs, &[y, y, contact], heard[j][r])?;
        if trace {
            eprintln!("  checked at {:.4}: resonance {r} grows {:.2}/s at {:.2} Hz on the map, {}/s at {} Hz on the engine ({seconds:.2} s stepped)",
                      places[j], sigma[j][r], heard[j][r], g.map_or("-".into(), |g| format!("{g:.2}")), h.map_or("-".into(), |h| format!("{h:.2}")));
        }
        checks.push(json!({"x": round(places[j], 4), "resonance": r, "growth": round(sigma[j][r], 2), "hz": round(heard[j][r], 2),
                           "engineGrowth": g.map(|g| round(g, 2)), "engineHz": h.map(|h| round(h, 2)), "seconds": round(seconds, 3)}));
    }
    Ok(checks)
}

/// Which resonance a note blown from rest sounds at each place: its breath rising from nothing over `rise` s to the
/// place's share of its players', each resonance's amplitude growing from the same noise at its growth at the breath of
/// the moment (by the logarithm of its share; under the least, dying) -- the first to grow 60 dB wins, none in `held` s
/// none (tools/speaking_map.py races) -> (winner or -1, seconds) at each place.
fn races(sigma: &[Vec<f64>], shares: &[f64], rise: f64, held: f64) -> (Vec<i64>, Vec<Option<f64>>) {
    let (m, n) = (shares.len(), sigma.first().map_or(0, |s| s.len()));
    let dt = if rise > 0.0 { (rise / 40.0).min(0.002) } else { 0.002 };
    let steps = (held / dt) as usize;
    let logs: Vec<f64> = shares.iter().map(|s| s.ln()).collect();
    let mut grown = vec![vec![0.0; n]; m];
    let (mut winner, mut seconds) = (vec![-1i64; m], vec![None; m]);
    let mut open = vec![true; m];
    let lowest: Vec<f64> = (0..n).map(|r| sigma[0][r].min(0.0)).collect();
    let finite = |v: f64| if v.is_finite() { v } else { -50.0 };
    for step in 0..steps {
        let t = (step as f64 + 0.5) * dt;
        let lift = if rise > 0.0 { (t / rise).min(1.0).ln() } else { 0.0 };
        let mut any = false;
        for j in 0..m {
            if !open[j] {
                continue;
            }
            let now = logs[j] + lift;
            // (Where the breath of the moment stands among the places: numpy's interp of the index.)
            let at = if now <= logs[0] { 0.0 } else if now >= logs[m - 1] { (m - 1) as f64 } else {
                let i = logs.iter().rposition(|&l| l <= now).unwrap().min(m - 2);
                i as f64 + (now - logs[i]) / (logs[i + 1] - logs[i])
            };
            let below = now < logs[0];
            let lo = at.floor() as usize;
            let hi = (lo + 1).min(m - 1);
            let w = at - lo as f64;
            let mut best = (f64::NEG_INFINITY, 0usize);
            for r in 0..n {
                let s = if below { lowest[r] } else { (1.0 - w) * finite(sigma[lo][r]) + w * finite(sigma[hi][r]) };
                grown[j][r] = (grown[j][r] + s * dt).max(-20.0);
                if grown[j][r] > best.0 {
                    best = (grown[j][r], r);
                }
            }
            if best.0 >= WON {
                winner[j] = best.1 as i64;
                seconds[j] = Some((step + 1) as f64 * dt);
                open[j] = false;
            } else {
                any = true;
            }
        }
        if !any {
            break;
        }
    }
    (winner, seconds)
}

// ---- One tube a note, its answers fitted once (the owner, 15 November 2026, of its design: "Yes, proceed.") ----
//
// (1) A vented note's tube about each place's steady flow is its tube at rest with its lossy columns put in from that
// flow (with_columns): B_s = B + U V^T, V the unit columns of its lossy columns and U their change. So its answer is the
// rest tube's, exactly, by Woodbury's identity: G_s = G + (h C)(I - M C)^-1 g, where h, M and g are the rest tube's own
// answers from the directions its change takes (Vent) and to its lossy columns' doubles, and C each place's change in
// those directions; and its steady states likewise, from the rest tube's factors at z = 1 taken once (Steadies). (2)
// Those answers fitted once a note as one rational function in barycentric form, one denominator for them all, over the
// readings its scan takes along the unit circle (AAA: Y. Nakatsukasa, O. Sete & L. N. Trefethen 2018, "The AAA algorithm
// for rational approximation", SIAM J. Sci. Comput. 40(3), A1494-A1522, doi:10.1137/16M1106122; its answers together:
// P. Lietaert, K. Meerbergen, J. Perez & B. Vandereycken 2022, "Automatic rational approximation and linearization of
// nonlinear eigenvalue problems", IMA J. Numer. Anal. 42(2), 1087-1115, doi:10.1093/imanum/draa098). Each resonance's pole
// found on the fit, then on the tube itself. (3) Every root of every place of every dynamic found on the fit; then the fit
// read against the tube itself at each dynamic's players' breath and at each resonance's onset, and the note mapped on
// the tube itself wherever they stand more than FIT_APART apart.

// (How far apart, over its answer there, its fit and its tube itself may stand at a key root before the note is mapped on
// its tube itself; how close its fit is asked to stand to its readings, over each answer's largest -- each in turn until
// its roots stand within FIT_APART, its roots' own readings taken among them each time they do not -- with at most so many support points, its weights taken over the answers that carry
// so much of what they serve; how far a pole on its fit and the one found from it on its tube may stand apart; its vent's
// directions kept above so small a share of its largest change; how many peaks past those asked its scan reads before it
// reads a quarter beyond the last; inverse iteration's steps for its least singular vector.)
const FIT_APART: f64 = 1e-9;
const FIT_STAGES: [f64; 4] = [1e-11, 1e-11, 1e-12, 1e-13];
const LEAST_CARRIED: f64 = 1e-6;
const FIT_MOST: usize = 200;
const POLES_APART: f64 = 1e-6;
const VENT_TINY: f64 = 1e-13;
const PEAKS_PAST: usize = 4;
// (Its scan's readings so many cents apart: twice the tube itself's, its fit standing between them.)
const FIT_CENTS: f64 = 20.0;
// (A steady state's Newton's step so short, beside its state, that the next would be within its rounding: taken as the last.)
const STEADY_QUADRATIC: f64 = 1e-7;
const INVERSE_STEPS: usize = 10;

thread_local! {
    // (How many times this thread has taken a place's held pressure again, and a steady state's Newton's step, said where
    // its map is traced.)
    static STEADIED: std::cell::Cell<[usize; 2]> = const { std::cell::Cell::new([0; 2]) };
    static TIMED: std::cell::Cell<[f64; 3]> = const { std::cell::Cell::new([0.0; 3]) };
}

/// A place's rest on the fitted path: its reed's resting opening and its rest there, and -- a vented tube's -- its lossy
/// columns about the steady flow there, and their change from rest in its vent's directions (directions x columns).
#[derive(Clone)]
struct Held {
    y: f64,
    rest: Rest,
    columns: Option<Vec<Vec<(usize, f64)>>>,
    change: Option<Vec<Vec<f64>>>,
}

/// A column's change from its column at rest, over the rows either stands on: [(row, change)], its rows in order.
fn change_of(about: &[(usize, f64)], rest: &[(usize, f64)]) -> Vec<(usize, f64)> {
    let mut out: std::collections::BTreeMap<usize, f64> = std::collections::BTreeMap::new();
    for &(i, v) in about {
        *out.entry(i).or_default() += v;
    }
    for &(i, v) in rest {
        *out.entry(i).or_default() -= v;
    }
    out.into_iter().filter(|(_, d)| *d != 0.0).collect()
}

/// a x = b, a small and dense, by Gaussian elimination, its pivots chosen.
fn small_solve(a: &[Vec<C>], b: &[C]) -> Result<Vec<C>, String> {
    let n = b.len();
    let mut m: Vec<Vec<C>> = a.iter().zip(b).map(|(row, v)| {
        let mut r = row.clone();
        r.push(*v);
        r
    }).collect();
    for col in 0..n {
        let p = (col..n).max_by(|x, y| m[*x][col].abs().total_cmp(&m[*y][col].abs())).unwrap();
        if m[p][col].abs() == 0.0 {
            return Err("its small matrix is singular".into());
        }
        m.swap(col, p);
        let inverse = m[col][col].inv();
        for r in col + 1..n {
            let f = m[r][col] * inverse;
            for c in col..=n {
                m[r][c] = m[r][c] - f * m[col][c];
            }
        }
    }
    let mut x = vec![C::default(); n];
    for r in (0..n).rev() {
        let s = (r + 1..n).fold(m[r][n], |s, c| s - m[r][c] * x[c]);
        x[r] = s / m[r][r];
    }
    Ok(x)
}

fn dot(a: &[C], b: &[C]) -> C {
    a.iter().zip(b).fold(C::default(), |s, (x, y)| s + *x * *y)
}

/// A tube's steady states by Woodbury's identity on its rest's factors at z = 1, taken once: (I - B_s)^-1 f, B_s its map
/// at rest with its lossy columns put in from a steady flow's (B + U V^T, V the unit columns `which`).
struct Steadies<'a> {
    tube: &'a Laid,
    // (Its factors at one in real numbers, and in complex ones where a real solve does not stand.)
    real: Option<FactoredReal<'a>>,
    one: Factors<'a>,
    which: Vec<usize>,
    rest: Vec<Vec<(usize, f64)>>,
    // (The rows of (I - B)^-1 at its lossy columns, solved for once.)
    rows: Vec<Vec<f64>>,
}

impl<'a> Steadies<'a> {
    fn of(tube: &'a Laid, which: &[usize]) -> Result<Steadies<'a>, String> {
        let values: Vec<f64> = tube.values.iter().map(|v| v.re).collect();
        let one = tube.at(C::new(1.0, 0.0))?;
        let rows = which.iter().map(|&j| {
            let mut e = vec![C::default(); tube.n()];
            e[j] = C::new(1.0, 0.0);
            one.solve_transposed(&e).map(|r| r.iter().map(|x| x.re).collect())
        }).collect::<Result<_, _>>()?;
        Ok(Steadies { tube, real: tube.order.factor_real(&tube.slots, &values, 1.0).ok(), one, which: which.to_vec(),
                      rest: which.iter().map(|&j| tube.map.cols[j].clone()).collect(), rows })
    }

    /// (I - B)^-1 v: in real numbers, taken again once from its residual where it does not stand (as Factors::solve
    /// judges one), else as a complex solve.
    fn plain(&self, v: &[f64]) -> Result<Vec<f64>, String> {
        if let Some(f) = &self.real {
            let misses = |x: &[f64]| -> Option<Vec<f64>> {
                let mut y = x.to_vec();
                for (j, col) in self.tube.map.cols.iter().enumerate() {
                    for &(i, b) in col {
                        y[i] -= x[j] * b;
                    }
                }
                let residual: Vec<f64> = v.iter().zip(&y).map(|(a, b)| a - b).collect();
                let size = |u: &[f64]| u.iter().fold(0.0f64, |m, c| m.max(c.abs()));
                (!(size(&residual) <= STANDS * ((1.0 + self.tube.norm) * size(x) + size(v)))).then_some(residual)
            };
            let mut x = f.solve(v);
            let Some(residual) = misses(&x) else { return Ok(x) };
            counted(1);
            for (a, d) in x.iter_mut().zip(f.solve(&residual)) {
                *a += d;
            }
            if misses(&x).is_none() {
                return Ok(x);
            }
        }
        let v: Vec<C> = v.iter().map(|x| C::new(*x, 0.0)).collect();
        Ok(self.one.solve(&v)?.iter().map(|x| x.re).collect())
    }

    /// (I - B_s)^-1 f, B_s its map at rest with its lossy columns from `columns`: by Woodbury's identity, x0 + Y (I - V^T
    /// Y)^-1 V^T x0 with x0 = (I - B)^-1 f and Y = (I - B)^-1 U -- that is (I - B)^-1 (f + U eta), eta = (I - V^T Y)^-1
    /// V^T x0, whose V^T x0 and V^T Y read off the rows of (I - B)^-1 at its lossy columns: one solve.
    fn solve(&mut self, columns: &[Vec<(usize, f64)>], f: &[f64]) -> Result<Vec<f64>, String> {
        let jn = self.which.len();
        let changes: Vec<Vec<(usize, f64)>> = (0..jn).map(|t| change_of(&columns[t], &self.rest[t])).collect();
        let s: Vec<Vec<C>> = (0..jn).map(|a| (0..jn).map(|t| {
            let vy: f64 = changes[t].iter().map(|&(i, d)| self.rows[a][i] * d).sum();
            C::new(if a == t { 1.0 } else { 0.0 } - vy, 0.0)
        }).collect()).collect();
        let vx: Vec<C> = (0..jn).map(|a| C::new(self.rows[a].iter().zip(f).map(|(r, v)| r * v).sum(), 0.0)).collect();
        let eta = small_solve(&s, &vx)?;
        let mut rhs = f.to_vec();
        for (t, change) in changes.iter().enumerate() {
            for &(i, d) in change {
                rhs[i] += eta[t].re * d;
            }
        }
        self.plain(&rhs)
    }
}

/// `steady`'s steady state on the fitted path: Newton's steps on the engine's own step, each solved by Woodbury's identity
/// (Steadies) -> its state, and its lossy columns about it.
fn steady_low(player: &mut Player, row: &[f64], map: &BoreMap, steadies: &mut Steadies, lossy: &[usize], w: f64, from: Option<(&[f64], f64)>)
              -> Result<(Vec<f64>, Vec<Vec<(usize, f64)>>), String> {
    let n = map.moving.len();
    let mut x = match from {
        Some((x, was)) if was != 0.0 && x.len() == n => x.iter().map(|v| v * w / was).collect(),
        _ => {
            let mut b = vec![0.0; n];
            for &(i, v) in &map.b {
                b[i] = v * w;
            }
            steadies.plain(&b)?
        }
    };
    // (Its columns read about the state its last step began from: that step moved it under STEADY_QUADRATIC, within what
    // reading them by differences leaves in them.)
    let mut columns = vec![];
    for _ in 0..STEADY_STEPS {
        STEADIED.with(|c| c.set([c.get()[0], c.get()[1] + 1]));
        let t0 = std::time::Instant::now();
        columns = player.bore_columns(row, w, &map.moving, &x, lossy, NUDGE)?;
        let t1 = std::time::Instant::now();
        let stepped = player.bore_step(row, &map.moving, &x, w)?;
        let f: Vec<f64> = stepped.iter().zip(&x).map(|(s, v)| s - v).collect();
        let t2 = std::time::Instant::now();
        let delta = steadies.solve(&columns, &f)?;
        TIMED.with(|c| { let mut v = c.get(); v[0] += (t1 - t0).as_secs_f64(); v[1] += (t2 - t1).as_secs_f64(); v[2] += t2.elapsed().as_secs_f64(); c.set(v) });
        let largest = x.iter().fold(0.0f64, |m, v| m.max(v.abs())).max(f64::MIN_POSITIVE);
        let moved = delta.iter().fold(0.0f64, |m, v| m.max(v.abs()));
        for (v, d) in x.iter_mut().zip(&delta) {
            *v += d;
        }
        if moved <= STEADY_QUADRATIC * largest {
            break;
        }
    }
    Ok((x, columns))
}

/// A place's rest at the breath `gamma`, as dynamic_map's held_at finds it, on the fitted path: the pressure its steady
/// flow holds at its reed (`held`, over that flow) found where its rest and its flow agree -- by the secant's steps on
/// what the flow holds against what was asked of it, begun from what the place before held (`found`: its steady state,
/// its flow and its pressure held), each steady state begun from the last found, scaled to its flow -> its Held, or none
/// where its reed rests shut there.
#[allow(clippy::too_many_arguments)]
fn held_low(player: &mut Player, row: &[f64], map: &BoreMap, steadies: Option<&mut Steadies>, lossy: &[usize], reed: &Reed, k: &ReedConstants, fs: f64,
            g1: f64, gamma: f64, found: &mut Option<(Vec<f64>, f64, f64)>) -> Result<Option<Held>, String> {
    let Some(steadies) = steadies.filter(|_| !lossy.is_empty()) else {
        return Ok(rest_at(reed, k, gamma, g1).map(|(y, rest)| Held { y, rest, columns: None, change: None }));
    };
    let (mut held, mut columns) = (found.as_ref().map_or(g1, |f| f.2), None);
    let mut tried: Option<(f64, f64)> = None;
    for _ in 0..HELD_AGAIN {
        STEADIED.with(|c| c.set([c.get()[0] + 1, c.get()[1]]));
        let Some((_, rest)) = rest_at(reed, k, gamma, held) else { return Ok(None) };
        let w = rest.w_over * fs;
        if w == 0.0 {
            break;
        }
        let (x, cols) = steady_low(player, row, map, steadies, lossy, w, found.as_ref().map(|(x, was, _)| (&x[..], *was)))?;
        let now = map.c.iter().fold(0.0, |s, &(i, v)| s + x[i] * v) / w;
        columns = Some(cols);
        *found = Some((x, w, now));
        let apart = now - held;
        if apart.abs() <= 1e-12 * now.abs() {
            held = now;
            break;
        }
        let next = match tried {
            Some((h, a)) if a != apart => held - apart * (held - h) / (apart - a),
            _ => now,
        };
        tried = Some((held, apart));
        held = next;
    }
    Ok(rest_at(reed, k, gamma, held).map(|(y, rest)| Held { y, rest, columns, change: None }))
}

/// A vented tube's change from rest across every place held: its lossy columns (`which`), the rows their changes stand
/// on, and the directions those changes take over them -- orthonormal, by Gram-Schmidt's steps, the largest left first,
/// kept above VENT_TINY of the largest change -- each place's change in them put on its Held; none where nothing changes.
struct Vent {
    which: Vec<usize>,
    rows: Vec<usize>,
    basis: Vec<Vec<f64>>,
    // (Each direction's size when it was taken, over the largest change's.)
    sizes: Vec<f64>,
}

fn vent_of(which: &[usize], rest: &[Vec<(usize, f64)>], holds: &mut [Vec<Option<Held>>]) -> Option<Vent> {
    let all: Vec<&Vec<Vec<(usize, f64)>>> = holds.iter().flatten().flatten().filter_map(|h| h.columns.as_ref()).collect();
    let vent = vent_over(which, rest, &all)?;
    for h in holds.iter_mut().flatten().flatten() {
        if let Some(cols) = &h.columns {
            h.change = Some(vent.change_in(cols, rest));
        }
    }
    Some(vent)
}

/// vent_of over its lossy columns about every place (`all`), each place's columns in turn.
fn vent_over(which: &[usize], rest: &[Vec<(usize, f64)>], all: &[&Vec<Vec<(usize, f64)>>]) -> Option<Vent> {
    let changes: Vec<Vec<(usize, f64)>> = all.iter().flat_map(|cols| cols.iter().zip(rest).map(|(a, r)| change_of(a, r)).collect::<Vec<_>>()).collect();
    let mut rows: Vec<usize> = changes.iter().flatten().map(|(i, _)| *i).collect();
    rows.sort_unstable();
    rows.dedup();
    if rows.is_empty() {
        return None;
    }
    let dense = |c: &[(usize, f64)]| {
        let mut v = vec![0.0; rows.len()];
        for &(i, d) in c {
            v[rows.binary_search(&i).unwrap()] = d;
        }
        v
    };
    let size = |v: &[f64]| v.iter().map(|x| x * x).sum::<f64>().sqrt();
    let mut left: Vec<Vec<f64>> = changes.iter().map(|c| dense(c)).collect();
    let largest = left.iter().map(|v| size(v)).fold(0.0, f64::max);
    let (mut basis, mut sizes): (Vec<Vec<f64>>, Vec<f64>) = (vec![], vec![]);
    while basis.len() < rows.len() {
        let Some((k, s)) = left.iter().enumerate().map(|(k, v)| (k, size(v))).max_by(|a, b| a.1.total_cmp(&b.1)) else { break };
        if !(s > VENT_TINY * largest) {
            break;
        }
        let e: Vec<f64> = left[k].iter().map(|x| x / s).collect();
        for v in left.iter_mut() {
            for _ in 0..2 {
                let p: f64 = v.iter().zip(&e).map(|(a, b)| a * b).sum();
                for (a, b) in v.iter_mut().zip(&e) {
                    *a -= p * b;
                }
            }
        }
        basis.push(e);
        sizes.push(s / largest);
    }
    Some(Vent { which: which.to_vec(), rows, basis, sizes })
}

impl Vent {
    /// A place's lossy columns' change from rest in its directions -> [direction][column].
    fn change_in(&self, columns: &[Vec<(usize, f64)>], rest: &[Vec<(usize, f64)>]) -> Vec<Vec<f64>> {
        let dense: Vec<Vec<f64>> = columns.iter().zip(rest).map(|(a, r)| {
            let mut v = vec![0.0; self.rows.len()];
            for (i, d) in change_of(a, r) {
                if let Ok(at) = self.rows.binary_search(&i) {
                    v[at] = d;
                }
            }
            v
        }).collect();
        self.basis.iter().map(|e| dense.iter().map(|d| d.iter().zip(e).map(|(x, y)| x * y).sum()).collect()).collect()
    }
}

/// Its tube's answers at z, exactly, as its fit takes them: from its reed's flow (b) and from each of its vent's
/// directions (over its rows), to the pressure at its reed (c) and to each of its lossy columns' doubles -> each input's
/// outputs in turn, and (`slopes`) their slopes in z. Read from its outputs' side: each output's row of (z - B)^-1 by a
/// transposed solve (and of (z - B)^-2 for its slope, -c (z - B)^-2 b), so that its directions cost nothing more.
fn ported(tube: &Laid, vent: Option<&Vent>, z: C, slopes: bool) -> Result<(Vec<C>, Vec<C>), String> {
    let f = tube.at(z)?;
    let n = tube.n();
    let mut outputs = vec![vec![C::default(); n]];
    for &(i, w) in &tube.map.c {
        outputs[0][i] = C::new(w, 0.0);
    }
    let mut inputs: Vec<Vec<(usize, f64)>> = vec![tube.map.b.clone()];
    if let Some(v) = vent {
        for &j in &v.which {
            let mut e = vec![C::default(); n];
            e[j] = C::new(1.0, 0.0);
            outputs.push(e);
        }
        inputs.extend(v.basis.iter().map(|d| v.rows.iter().copied().zip(d.iter().copied()).collect::<Vec<_>>()));
    }
    let on = |row: &[C], input: &[(usize, f64)]| input.iter().fold(C::default(), |s, &(i, v)| s + row[i] * v);
    let rows: Vec<Vec<C>> = outputs.iter().map(|o| f.solve_transposed(o)).collect::<Result<_, _>>()?;
    let squared: Vec<Vec<C>> = if slopes { rows.iter().map(|r| f.solve_transposed(r)).collect::<Result<_, _>>()? } else { vec![] };
    let (mut values, mut slope) = (Vec::with_capacity(inputs.len() * rows.len()), vec![]);
    for input in &inputs {
        for (o, row) in rows.iter().enumerate() {
            values.push(on(row, input));
            if slopes {
                slope.push(C::default() - on(&squared[o], input));
            }
        }
    }
    Ok((values, slope))
}

/// A tube's answer and its slope from its rest tube's answers (`ported`'s, or its fit's: each input's outputs in turn)
/// and their slopes, about a place's change `change` (directions x lossy columns; none at rest, or unvented), each input
/// having `outputs`: by Woodbury's identity, G + (h C)(I - M C)^-1 g.
fn combined(values: &[C], slopes: &[C], change: Option<&[Vec<f64>]>, outputs: usize) -> (C, C) {
    let (g0, dg0) = (values[0], slopes.first().copied().unwrap_or_default());
    let Some(c) = change else { return (g0, dg0) };
    let (r, jn) = (c.len(), outputs.saturating_sub(1));
    if r == 0 || jn == 0 {
        return (g0, dg0);
    }
    let at = |v: &[C], input: usize, output: usize| v.get(input * outputs + output).copied().unwrap_or_default();
    let g: Vec<C> = (0..jn).map(|j| at(values, 0, 1 + j)).collect();
    let dg: Vec<C> = (0..jn).map(|j| at(slopes, 0, 1 + j)).collect();
    // (P = h C, 1 x J; Q = M C, J x J; and their slopes.)
    let p: Vec<C> = (0..jn).map(|t| (0..r).fold(C::default(), |s, k| s + at(values, 1 + k, 0) * c[k][t])).collect();
    let dp: Vec<C> = (0..jn).map(|t| (0..r).fold(C::default(), |s, k| s + at(slopes, 1 + k, 0) * c[k][t])).collect();
    let q = |v: &[C], j: usize, t: usize| (0..r).fold(C::default(), |s, k| s + at(v, 1 + k, 1 + j) * c[k][t]);
    let iq: Vec<Vec<C>> = (0..jn).map(|j| (0..jn).map(|t| C::new(if j == t { 1.0 } else { 0.0 }, 0.0) - q(values, j, t)).collect()).collect();
    let Ok(u) = small_solve(&iq, &g) else { return (C::new(f64::NAN, f64::NAN), C::default()) };
    let value = g0 + dot(&p, &u);
    if slopes.is_empty() {
        return (value, C::default());
    }
    // (Its slope: P' u + P (I - Q)^-1 (Q' u + g').)
    let rhs: Vec<C> = (0..jn).map(|j| (0..jn).fold(dg[j], |s, t| s + q(slopes, j, t) * u[t])).collect();
    let v = small_solve(&iq, &rhs).unwrap_or_else(|_| vec![C::default(); jn]);
    (value, dg0 + dot(&dp, &u) + dot(&p, &v))
}

/// A rational function in barycentric form, its answers together over one denominator: its support points, their
/// weights, and its answers at each.
struct Rational {
    support: Vec<C>,
    weights: Vec<C>,
    values: Vec<Vec<C>>,
}

impl Rational {
    /// Its answers at z, and their slopes.
    fn at(&self, z: C) -> (Vec<C>, Vec<C>) {
        let k = self.values.first().map_or(0, |v| v.len());
        if let Some(s) = self.support.iter().position(|&p| p == z) {
            // (At a support point, its answers there; their slopes read a hair off it.)
            let (_, slopes) = self.at(z + C::new(0.0, 1e-12));
            return (self.values[s].clone(), slopes);
        }
        let (mut d, mut dd) = (C::default(), C::default());
        let (mut n, mut dn) = (vec![C::default(); k], vec![C::default(); k]);
        for ((&p, &w), f) in self.support.iter().zip(&self.weights).zip(&self.values) {
            let a = w / (z - p);
            let b = a / (z - p);
            d = d + a;
            dd = dd - b;
            for l in 0..k {
                n[l] = n[l] + a * f[l];
                dn[l] = dn[l] - b * f[l];
            }
        }
        ((0..k).map(|l| n[l] / d).collect(), (0..k).map(|l| (dn[l] * d - n[l] * dd) / (d * d)).collect())
    }
}

/// The unit vector w that makes |A w| least, A given by its columns: A's triangle by Householder's reflections, then
/// inverse iteration on it (R^H R w = the last w), its least singular vector.
fn least_vector(mut columns: Vec<Vec<C>>) -> Vec<C> {
    let n = columns.len();
    let m = columns.first().map_or(0, |c| c.len());
    for k in 0..n.min(m) {
        let norm = columns[k][k..].iter().map(|x| x.abs() * x.abs()).sum::<f64>().sqrt();
        if norm == 0.0 {
            continue;
        }
        let x0 = columns[k][k];
        let alpha = if x0.abs() > 0.0 { x0 * (-norm / x0.abs()) } else { C::new(-norm, 0.0) };
        let mut v: Vec<C> = columns[k][k..].to_vec();
        v[0] = v[0] - alpha;
        let vv: f64 = v.iter().map(|x| x.abs() * x.abs()).sum();
        if vv == 0.0 {
            continue;
        }
        for j in k..n {
            let s = v.iter().zip(&columns[j][k..]).fold(C::default(), |s, (a, b)| s + a.conj() * *b) * (2.0 / vv);
            for (i, a) in columns[j][k..].iter_mut().enumerate() {
                *a = *a - v[i] * s;
            }
        }
    }
    let r = |i: usize, j: usize| if i < m { columns[j][i] } else { C::default() };
    let largest = (0..n).map(|i| r(i, i).abs()).fold(0.0, f64::max).max(f64::MIN_POSITIVE);
    let diagonal = |i: usize| if r(i, i).abs() > 1e-15 * largest { r(i, i) } else { C::new(1e-15 * largest, 0.0) };
    let mut w: Vec<C> = (0..n).map(|i| C::polar(1.0, 2.399963229728653 * i as f64)).collect();
    for _ in 0..INVERSE_STEPS {
        let mut y = vec![C::default(); n];
        for i in 0..n {
            let s = (0..i).fold(w[i], |s, j| s - r(j, i).conj() * y[j]);
            y[i] = s / diagonal(i).conj();
        }
        let mut x = vec![C::default(); n];
        for i in (0..n).rev() {
            let s = (i + 1..n).fold(y[i], |s, j| s - r(i, j) * x[j]);
            x[i] = s / diagonal(i);
        }
        let size = x.iter().map(|v| v.abs() * v.abs()).sum::<f64>().sqrt();
        if !(size > 0.0 && size.is_finite()) {
            break;
        }
        w = x.iter().map(|v| *v / size).collect();
    }
    w
}

/// AAA's weights for the support points `support` (indices into `points`) over the answers `f` ([point][answer]) taken
/// together: the least singular vector of their Loewner matrices stacked, over every point not a support point.
fn aaa_weights(points: &[C], f: &[Vec<C>], answers: &[usize], support: &[usize], is_support: &[bool]) -> Vec<C> {
    let rows: Vec<usize> = (0..points.len()).filter(|&i| !is_support[i]).collect();
    let columns: Vec<Vec<C>> = support.iter().map(|&s| {
        answers.iter().flat_map(|&l| rows.iter().map(move |&i| (f[i][l] - f[s][l]) / (points[i] - points[s]))).collect()
    }).collect();
    least_vector(columns)
}

/// AAA's rational function over readings at `points` (`values`: [point][answer]), its answers together over one
/// denominator, each weighed by its `importance` (what share of the answer it serves it carries): support points taken
/// greedily where a combination of its answers (each over its largest, weighed, turned by the golden angle) stands
/// furthest from the function so far; its weights then the least-squares ones over every answer, support points added
/// where any answer stands beyond `tolerance` of its largest, weighed, `most` at most -> it, and how far its answers stand
/// from the readings at most, each over its largest, weighed.
fn aaa(points: &[C], values: &[Vec<C>], importance: &[f64], tolerance: f64, most: usize, from: &[usize]) -> Result<(Rational, f64, Vec<usize>), String> {
    let (m, k) = (points.len(), values.first().map_or(0, |v| v.len()));
    if m < 8 || k == 0 || importance.len() != k {
        return Err("too few readings to fit".into());
    }
    let scale: Vec<f64> = (0..k).map(|l| values.iter().map(|v| v[l].abs()).fold(0.0, f64::max).max(f64::MIN_POSITIVE) / importance[l].max(f64::MIN_POSITIVE)).collect();
    let f: Vec<Vec<C>> = values.iter().map(|v| (0..k).map(|l| v[l] / scale[l]).collect()).collect();
    let combination: Vec<Vec<C>> = f.iter().map(|v| vec![v.iter().enumerate().fold(C::default(), |s, (l, a)| s + *a * C::polar(1.0, 2.399963229728653 * l as f64))]).collect();
    // (Begun from the support points of a fit taken before, where one is given.)
    let mut support: Vec<usize> = from.to_vec();
    let mut is_support = vec![false; m];
    for &s in from {
        is_support[s] = true;
    }
    let made = |support: &[usize], weights: Vec<C>, of: &[Vec<C>]| Rational {
        support: support.iter().map(|&s| points[s]).collect(), weights, values: support.iter().map(|&s| of[s].clone()).collect(),
    };
    // (The support points on the combination.)
    let largest = combination.iter().map(|v| v[0].abs()).fold(0.0, f64::max).max(f64::MIN_POSITIVE);
    let mean = combination.iter().fold(C::default(), |s, v| s + v[0]) / m as f64;
    let mut now: Vec<C> = if support.is_empty() {
        vec![mean; m]
    } else {
        let r = made(&support, aaa_weights(points, &combination, &[0], &support, &is_support), &combination);
        points.iter().map(|&z| r.at(z).0[0]).collect()
    };
    while support.len() < most {
        let Some(next) = (0..m).filter(|&i| !is_support[i]).max_by(|a, b| (combination[*a][0] - now[*a]).abs().total_cmp(&(combination[*b][0] - now[*b]).abs())) else { break };
        if (combination[next][0] - now[next]).abs() <= tolerance * largest {
            break;
        }
        support.push(next);
        is_support[next] = true;
        let r = made(&support, aaa_weights(points, &combination, &[0], &support, &is_support), &combination);
        now = points.iter().map(|&z| r.at(z).0[0]).collect();
    }
    // (Its weights the least-squares ones over every answer that carries LEAST_CARRIED of what it serves -- the rest ride on
    // the same denominator, read with the others -- support points added where any answer stands beyond its tolerance.)
    let answers: Vec<usize> = (0..k).filter(|&l| importance[l] >= LEAST_CARRIED).collect();
    loop {
        let r = made(&support, aaa_weights(points, &f, &answers, &support, &is_support), &f);
        let mut worst = (0usize, 0.0f64);
        for i in (0..m).filter(|&i| !is_support[i]) {
            let at = r.at(points[i]).0;
            for l in 0..k {
                let apart = (at[l] - f[i][l]).abs();
                if !(apart <= worst.1) {
                    worst = (i, if apart.is_finite() { apart } else { f64::INFINITY });
                }
            }
        }
        if worst.1 <= tolerance || support.len() >= most {
            let weights = r.weights;
            return Ok((made(&support, weights, values), worst.1, support));
        }
        support.push(worst.0);
        is_support[worst.0] = true;
    }
}

/// A tube's answers fitted (`rational`, each input's outputs in turn, as `ported` reads them), each input having
/// `outputs`.
struct Fitted {
    rational: Rational,
    outputs: usize,
}

impl Fitted {
    /// Its tube's answer and slope at z about a place's change (`combined`).
    fn answer(&self, z: C, change: Option<&[Vec<f64>]>) -> (C, C) {
        let (values, slopes) = self.rational.at(z);
        combined(&values, &slopes, change, self.outputs)
    }
}

/// Its rest tube's answers along the unit circle every FIT_CENTS from LOW, exactly (`ported`), until PEAKS_PAST more
/// peaks of its answer than the resonances it is asked for, then a quarter beyond the last, or HIGH -> [(hz, z,
/// answers)].
fn scanned(tube: &Laid, vent: Option<&Vent>, rate: f64, target: f64, count: usize) -> Result<Vec<(f64, C, Vec<C>)>, String> {
    let (tau, top, step) = (2.0 * std::f64::consts::PI, HIGH.min(0.45 * rate), 2f64.powf(FIT_CENTS / 1200.0));
    let (mut f, mut seen, mut peaks, mut until) = (LOW, vec![], vec![], f64::INFINITY);
    loop {
        let z = C::polar(1.0, tau * f / rate);
        seen.push((f, z, ported(tube, vent, z, false)?.0));
        let k = seen.len();
        let level = |i: usize| seen[i].2[0].abs();
        if k >= 3 && level(k - 2) > level(k - 3) && level(k - 2) >= level(k - 1) {
            peaks.push(seen[k - 2].0);
            let under = peaks.iter().filter(|p| **p < 1.5 * target).count();
            if until.is_infinite() && peaks.len() >= count.max(under) + 1 + PEAKS_PAST {
                until = 1.25 * seen[k - 2].0;
            }
        }
        if f >= until || f >= top {
            break;
        }
        f *= step;
    }
    Ok(seen)
}

/// Its tube's resonances from its readings along the unit circle (`seen`): each peak of its answer's pole found on its
/// fit (peak_pole_on), then on its tube itself from there -- the two within POLES_APART, or its fit is refused -- kept
/// as `resonances` keeps them.
fn resonances_fitted(tube: &Laid, fitted: &Fitted, seen: &[(f64, C, Vec<C>)], rate: f64, target: f64, count: usize, trace: bool) -> Result<Vec<Resonance>, String> {
    let tau = 2.0 * std::f64::consts::PI;
    let mut found: Vec<Resonance> = vec![];
    for k in 2..seen.len() {
        let level = |i: usize| seen[i].2[0].abs();
        if !(level(k - 1) > level(k - 2) && level(k - 1) >= level(k)) {
            continue;
        }
        let triple: Vec<(f64, C)> = (k - 2..=k).map(|i| (seen[i].0, seen[i].2[0])).collect();
        let before = factored();
        let on_fit = peak_pole_on(&|z| Ok(fitted.answer(z, None)), rate, &triple);
        let got = match on_fit {
            Ok(r) => {
                let limit = (-r.pole.1).max(tau * 10.0) / rate;
                let p = pole(tube, rate, C::polar((r.pole.1 / rate).exp(), tau * r.pole.0 / rate), limit)?;
                if (p.0 - r.pole.0).abs() > POLES_APART * p.0 || (p.1 - r.pole.1).abs() > POLES_APART * p.0 {
                    return Err(format!("its pole on its fit ({:.4} Hz, {:.3}/s) and on its tube ({:.4} Hz, {:.3}/s) stand apart", r.pole.0, r.pole.1, p.0, p.1));
                }
                match found.iter().find(|s| (s.pole.0 / p.0).ln().abs() <= 1e-6) {
                    Some(s) => Err(format!("its pole at {:.2} Hz, found before", s.pole.0)),
                    None => Ok(Resonance::of(p)),
                }
            }
            Err(e) => Err(e),
        };
        if trace {
            let said = match &got {
                Ok(r) => format!("its pole at {:.2} Hz, {:.1}/s", r.pole.0, r.pole.1),
                Err(e) => format!("none -- {e}"),
            };
            eprintln!("    a peak at {:.1} Hz: {said} ({} factored)", seen[k - 1].0, factored() - before);
        }
        if let Ok(r) = got {
            found.push(r);
            let under = found.iter().filter(|r| r.hz < 1.5 * target).count();
            if found.len() > count.max(under) {
                break;
            }
        }
    }
    Ok(kept_of(found, target, count))
}

/// A note's maps on the fitted path (the section's head): every place of every dynamic held; its vent's directions; its
/// rest tube's answers read along the unit circle and fitted; its resonances; and every dynamic's starts on the fit,
/// checked against its tube itself -> [(dynamic, its map)], or why its fit was refused.
#[allow(clippy::too_many_arguments)]
fn fitted_maps(player: &mut Player, rate: f64, rows: &[(String, Vec<f64>)], u: usize, k: &ReedConstants, map: &BoreMap, rest_tube: &Laid, lossy: &[usize],
               target: f64, asked: &Asked) -> Result<Vec<(String, Value)>, String> {
    let shares: Vec<f64> = asked.places.iter().map(|x| asked.reach.powf(*x)).collect();
    let g1 = answer(rest_tube, C::new(1.0, 0.0))?.0.re;
    // (1) Every place of every dynamic held.
    let (began, counts) = (std::time::Instant::now(), tally());
    let mut holds: Vec<Vec<Option<Held>>> = Vec::with_capacity(rows.len());
    {
        let mut steadies = if lossy.is_empty() { None } else { Some(Steadies::of(rest_tube, lossy)?) };
        for (_, row) in rows {
            let reed = Reed::of(row, u);
            let fs = reed.closing / (k.zc * k.sf);
            let mut found = None;
            let mut held = Vec::with_capacity(shares.len());
            for &s in &shares {
                held.push(held_low(player, row, map, steadies.as_mut(), lossy, &reed, k, fs, g1, row[u] * s, &mut found)?);
            }
            holds.push(held);
        }
    }
    let rest_columns: Vec<Vec<(usize, f64)>> = lossy.iter().map(|&j| map.cols[j].clone()).collect();
    let vent = if lossy.is_empty() { None } else { vent_of(lossy, &rest_columns, &mut holds) };
    if asked.trace {
        let (steadied, timed) = (STEADIED.with(|c| c.get()), TIMED.with(|c| c.get()));
        eprintln!("  every place held: {:.2} s ({}; {} pressures held, {} Newton's steps: its columns read {:.2} s, stepped {:.2} s, solved {:.2} s); {}", began.elapsed().as_secs_f64(), spent(counts), steadied[0], steadied[1], timed[0], timed[1], timed[2],
                  vent.as_ref().map_or("unvented".to_string(), |v| format!("its vent's change {} directions over {} rows, their sizes {:?}", v.basis.len(), v.rows.len(), v.sizes.iter().map(|s| format!("{s:.1e}")).collect::<Vec<_>>())));
    }
    // (2) Its answers along the unit circle, and their fit.
    let (began, counts) = (std::time::Instant::now(), tally());
    let seen = scanned(rest_tube, vent.as_ref(), rate, target, asked.resonances)?;
    let points: Vec<C> = seen.iter().map(|s| s.1).collect();
    let values: Vec<Vec<C>> = seen.iter().map(|s| s.2.clone()).collect();
    let read = began.elapsed().as_secs_f64();
    // (Each answer weighed by the largest share of its vent's change its direction carries at any place: its answers from
    // its reed's flow in full.)
    let outputs = 1 + vent.as_ref().map_or(0, |v| v.which.len());
    let carried: Vec<f64> = match &vent {
        Some(v) => {
            let most: Vec<f64> = (0..v.basis.len()).map(|d| holds.iter().flatten().flatten().filter_map(|h| h.change.as_ref())
                .map(|c| c[d].iter().fold(0.0f64, |m, x| m.max(x.abs()))).fold(0.0, f64::max)).collect();
            let largest = most.iter().copied().fold(0.0, f64::max).max(f64::MIN_POSITIVE);
            most.iter().map(|m| m / largest).collect()
        }
        None => vec![],
    };
    let importance: Vec<f64> = (0..values[0].len()).map(|a| match a / outputs {
        0 => 1.0,
        d => carried[d - 1],
    }).collect();
    if asked.trace {
        eprintln!("  its answers read at {} points to {:.0} Hz in {read:.2} s ({})", seen.len(), seen.last().map_or(0.0, |s| s.0), spent(counts));
    }
    // (Fitted at each of FIT_STAGES' tolerances in turn, each begun from the last's support points, until its fit stands
    // within FIT_APART of its tube at every root it is read at -- each time it does not, the tube's own answers read at
    // those roots taken among its readings, off the circle where its roots stand; else refused.)
    let (mut points, mut values) = (points, values);
    let (mut from, mut refused) = (vec![], String::new());
    for &tolerance in &FIT_STAGES {
        let began = std::time::Instant::now();
        let (rational, apart, support) = aaa(&points, &values, &importance, tolerance, FIT_MOST, &from)?;
        from = support;
        if asked.trace {
            eprintln!("  fitted to {tolerance:.0e} over {} readings on {} support points, {apart:.1e} apart at most, in {:.2} s", points.len(), rational.support.len(),
                      began.elapsed().as_secs_f64());
        }
        if !(apart <= FIT_APART) {
            refused = format!("its fit stood {apart:.1e} from its readings");
            continue;
        }
        let fitted = Fitted { rational, outputs };
        // (3) Its resonances.
        let (began, counts) = (std::time::Instant::now(), tally());
        let at_rest = match resonances_fitted(rest_tube, &fitted, &seen, rate, target, asked.resonances, asked.trace) {
            Ok(r) => r,
            Err(why) => {
                refused = why;
                continue;
            }
        };
        if asked.trace {
            eprintln!("  its resonances: {:.2} s ({}), {:?}", began.elapsed().as_secs_f64(), spent(counts), at_rest.iter().map(|r| (r.hz.round(), r.pole.1.round())).collect::<Vec<_>>());
        }
        if at_rest.is_empty() {
            return Err("its tube has no resonance between 20 Hz and 12 kHz".into());
        }
        // (4) Each dynamic.
        let mut made = vec![];
        for held in &holds {
            made.push(dynamic_fitted(rate, k, rest_tube, vent.as_ref(), &fitted, held, &at_rest, target, asked, !lossy.is_empty())?);
        }
        let worst = made.iter().map(|m| m.apart).fold(0.0, f64::max);
        if !(worst <= FIT_APART) {
            refused = format!("its fit stood {worst:.1e} from its tube at a root it was read at");
            for (z, v) in made.into_iter().flat_map(|m| m.readings) {
                if points.iter().all(|p| (*p - z).abs() > 1e-14) {
                    points.push(z);
                    values.push(v);
                }
            }
            continue;
        }
        // (Its fit taken: each dynamic checked against the engine where that is asked.)
        let mut maps = vec![];
        for ((dynamic, row), (mut m, held)) in rows.iter().zip(made.into_iter().zip(&holds)) {
            if !asked.checked.is_empty() {
                let fs = Reed::of(row, u).closing / (k.zc * k.sf);
                let wanted = check_places(&asked.places, &m.sigma, &m.heard, &asked.checked).into_iter().map(|(j, r)| (j, r, held[j].as_ref().map(|h| (h.y, h.rest)))).collect();
                m.out["checked"] = json!(engine_checks(player, rate, row, u, k, fs, row[u], &shares, &asked.places, &m.sigma, &m.heard, wanted, asked.trace)?);
            }
            maps.push((dynamic.clone(), m.out));
        }
        return Ok(maps);
    }
    Err(refused)
}

/// A dynamic's map on the fitted path, with how far its fit stood from its tube at the roots it was read at, every
/// place's growths and frequencies, and its tube's answers read there.
struct Made {
    out: Value,
    apart: f64,
    sigma: Vec<Vec<f64>>,
    heard: Vec<Vec<f64>>,
    // (Its tube's answers read at the roots its fit was read against there, exactly.)
    readings: Vec<(C, Vec<C>)>,
}

/// A dynamic's map on the fitted path: its resonances as at its players' breath, every place's starts on its fit, the fit
/// read against its tube itself at its players' breath and at each resonance's onset (refused beyond FIT_APART), its race,
/// and its map written as the tube itself's is.
#[allow(clippy::too_many_arguments)]
fn dynamic_fitted(rate: f64, k: &ReedConstants, rest_tube: &Laid, vent: Option<&Vent>, fitted: &Fitted,
                  held: &[Option<Held>], at_rest: &[Resonance], target: f64, asked: &Asked, lossy: bool) -> Result<Made, String> {
    let places = &asked.places;
    let shares: Vec<f64> = places.iter().map(|x| asked.reach.powf(*x)).collect();
    let middle = places.iter().enumerate().min_by(|a, b| a.1.abs().total_cmp(&b.1.abs())).map(|(j, _)| j).unwrap();
    let tau = 2.0 * std::f64::consts::PI;
    let exact = |z: C, change: Option<&[Vec<f64>]>, slopes: bool| -> Result<(C, C), String> {
        let (values, d) = ported(rest_tube, vent, z, slopes)?;
        Ok(combined(&values, &d, change, fitted.outputs))
    };
    let change_at = |j: usize| held[j].as_ref().and_then(|h| h.change.as_deref());
    // (Its resonances as at its players' breath: each pole found again there, on its fit from its pole at rest, then on
    // its tube itself.)
    let res: Vec<Resonance> = match change_at(middle) {
        Some(change) => at_rest.iter().map(|r| {
            let limit = (-r.pole.1).max(tau * 10.0) / rate;
            pole_on(|z| Ok(fitted.answer(z, Some(change))), rate, C::polar((r.pole.1 / rate).exp(), tau * r.pole.0 / rate), limit)
                .and_then(|p| pole_on(|z| exact(z, Some(change), true), rate, C::polar((p.1 / rate).exp(), tau * p.0 / rate), limit))
                .ok().filter(|p| p.1 < 0.0).map(Resonance::of).unwrap_or(*r)
        }).collect(),
        None => at_rest.to_vec(),
    };
    let hz0: Vec<f64> = res.iter().map(|r| r.hz).collect();
    let q0: Vec<f64> = res.iter().map(|r| r.q).collect();
    let bands: Vec<(f64, f64)> = (0..hz0.len()).map(|n| band(&hz0, n)).collect();
    let n = hz0.len();
    // (Every place's starts on its fit, each root begun where its roots at the last two places put it, else at its pole.)
    let (began, counts) = (std::time::Instant::now(), tally());
    let (mut sigma, mut heard) = (vec![vec![f64::NEG_INFINITY; n]; places.len()], vec![vec![f64::NAN; n]; places.len()]);
    let mut last: Vec<Vec<(usize, C)>> = vec![vec![]; n];
    for j in 0..places.len() {
        let Some(h) = &held[j] else {
            last = vec![vec![]; n];
            continue;
        };
        let change = h.change.as_deref();
        for r in 0..n {
            let from = match last[r][..] {
                [(i, a), (l, b)] => b + (b - a) * ((j - l) as f64 / (l - i) as f64),
                [(_, b)] => b,
                _ => C::polar((res[r].pole.1 / rate).exp(), tau * res[r].pole.0 / rate),
            };
            let found = root_on(|z| Ok(fitted.answer(z, change)), &h.rest, k, rate, from, tau * (bands[r].1 - bands[r].0) / (4.0 * rate))
                .filter(|(_, f)| bands[r].0 <= *f && *f <= bands[r].1);
            match found {
                Some((g, f)) => {
                    sigma[j][r] = g;
                    heard[j][r] = f;
                    last[r].push((j, C::polar((g / rate).exp(), tau * f / rate)));
                    if last[r].len() > 2 {
                        last[r].remove(0);
                    }
                }
                None => last[r].clear(),
            }
        }
    }
    let rooted = began.elapsed().as_secs_f64();
    // (Its fit read against its tube itself at its players' breath and at each resonance's onset.)
    let dial: Vec<usize> = (0..places.len()).filter(|&j| places[j] >= -1.0 - 1e-9).collect();
    let mut keys: Vec<(usize, usize)> = (0..n).filter(|&r| sigma[middle][r].is_finite()).map(|r| (middle, r)).collect();
    keys.extend((0..n).filter_map(|r| dial.iter().find(|&&j| sigma[j][r] > 0.0).map(|&j| (j, r))));
    let (mut apart, mut readings) = (0.0f64, Vec::with_capacity(keys.len()));
    for &(j, r) in &keys {
        let z = C::polar((sigma[j][r] / rate).exp(), tau * heard[j][r] / rate);
        let (values, _) = ported(rest_tube, vent, z, false)?;
        let (g, _) = combined(&values, &[], change_at(j), fitted.outputs);
        let (f, _) = fitted.answer(z, change_at(j));
        let d = (f - g).abs() / g.abs();
        apart = apart.max(if d.is_finite() { d } else { f64::INFINITY });
        readings.push((z, values));
    }
    if asked.trace {
        eprintln!("  {} places' starts on its fit in {rooted:.2} s, read against its tube at {} roots, {apart:.1e} apart at most ({})", places.len(), keys.len(), spent(counts));
    }
    let (winner, seconds) = races(&sigma, &shares, asked.rise, asked.held);
    let mut out = written(&sigma, &heard, &vec![true; places.len()], &winner, &seconds, &hz0, &q0, target, places, middle, lossy, asked.trace);
    out["fit"] = json!({"apart": apart, "checked": keys.len()});
    Ok(Made { out, apart, sigma, heard, readings })
}

#[cfg(test)]
mod tests {
    use super::*;

    // (The race: where one resonance dies, the other, growing slowly everywhere, wins it; where the first grows fastest,
    // the first, and sooner; where both die, none.)
    #[test]
    fn the_race_is_won_by_the_fastest() {
        let shares: Vec<f64> = (0..11).map(|j| 4f64.powf(-1.0 + 0.2 * j as f64)).collect();
        let sigma: Vec<Vec<f64>> = shares.iter().map(|s| vec![100.0 * s.ln() + 50.0, 20.0]).collect();
        let (winner, seconds) = races(&sigma, &shares, 0.05, 1.5);
        assert_eq!(winner[0], 1, "the first dying at its least breath: {:?}", winner);
        assert_eq!(winner[10], 0, "the first growing fastest at its most: {:?}", winner);
        assert!(seconds[10].unwrap() < seconds[0].unwrap(), "{:?}", seconds);
        let dying: Vec<Vec<f64>> = shares.iter().map(|_| vec![-10.0, -20.0]).collect();
        assert!(races(&dying, &shares, 0.05, 1.5).0.iter().all(|w| *w == -1));
    }

    // (A stretch halfway to its neighbours, a fifth beyond at the ends.)
    #[test]
    fn stretches_as_the_python_draws_them() {
        let hz = [100.0, 300.0, 500.0];
        assert_eq!(band(&hz, 0), (80.0, 200.0));
        assert_eq!(band(&hz, 1), (200.0, 400.0));
        assert_eq!(band(&hz, 2), (400.0, 600.0));
    }

    // (The least singular vector of columns one of which is the others' sum: their null direction.)
    #[test]
    fn least_vector_finds_the_null_direction() {
        let a: Vec<C> = (0..7).map(|i| C::new(1.0 + i as f64, 0.3 * i as f64)).collect();
        let b: Vec<C> = (0..7).map(|i| C::new((i * i) as f64 * 0.1, -1.0)).collect();
        let c: Vec<C> = a.iter().zip(&b).map(|(x, y)| *x + *y * 2.0).collect();
        let w = least_vector(vec![a.clone(), b.clone(), c.clone()]);
        let residual = (0..7).map(|i| (a[i] * w[0] + b[i] * w[1] + c[i] * w[2]).abs()).fold(0.0, f64::max);
        assert!(residual < 1e-12, "{residual:e}");
        assert!((w[1] / w[0] - C::new(2.0, 0.0)).abs() < 1e-10 && (w[2] / w[0] + C::new(1.0, 0.0)).abs() < 1e-10);
    }

    // (A sum of poles near the unit circle, two answers over one denominator, fitted on an arc of it: held within its
    // tolerance there and off the circle near it, its slopes too.)
    #[test]
    fn aaa_fits_poles_near_the_circle() {
        let poles: Vec<C> = (0..5).map(|k| C::polar(0.9995 - 0.0002 * k as f64, 0.02 + 0.07 * k as f64)).collect();
        let answer = |z: C, l: usize| poles.iter().enumerate().fold(C::new(0.3, 0.0), |s, (k, p)| s + C::new(1.0 + (l * k) as f64, 0.2 * k as f64) * 1e-3 / (z - *p));
        let points: Vec<C> = (0..300).map(|i| C::polar(1.0, 0.33 * i as f64 / 299.0)).collect();
        let values: Vec<Vec<C>> = points.iter().map(|&z| vec![answer(z, 0), answer(z, 1)]).collect();
        let (r, apart, _) = aaa(&points, &values, &[1.0, 1.0], 1e-13, 80, &[]).expect("its fit");
        assert!(apart <= 1e-13, "{apart:e}");
        for i in 0..40 {
            let z = C::polar(if i % 2 == 0 { 0.9997 } else { 1.0004 }, 0.01 + 0.3 * i as f64 / 39.0);
            let (v, s) = r.at(z);
            for l in 0..2 {
                assert!((v[l] - answer(z, l)).abs() < 1e-9 * answer(z, l).abs(), "{i} {l}");
                let d = C::new(1e-8, 0.0);
                let slope = (answer(z + d, l) - answer(z - d, l)) / (d * 2.0);
                assert!((s[l] - slope).abs() < 1e-5 * slope.abs(), "slope {i} {l}");
            }
        }
    }

    // (A small tube with two lossy columns, read again about a flow -- an entry changed and a row it stood on none at rest
    // -- answering by Woodbury's identity on its rest tube as the tube about that flow answers itself, its slope too; and
    // its steady state's solve likewise.)
    #[test]
    fn the_low_rank_tube_answers_as_the_tube_itself() {
        let n = 24;
        let mut cols: Vec<Vec<(usize, f64)>> = vec![vec![]; n];
        for j in 0..n {
            cols[j].push((j, 0.6 - 0.01 * j as f64));
            if j + 1 < n {
                cols[j].push((j + 1, 0.2 + 0.003 * j as f64));
            }
            if j > 0 {
                cols[j].push((j - 1, -0.15));
            }
        }
        let rest = BoreMap { moving: (0..n).collect(), cols: cols.clone(), b: vec![(0, 1.0), (1, 0.3)], c: vec![(0, 1.0)], off: 0.0 };
        let which = [9usize, 10];
        let mut about = rest.clone();
        about.cols[9] = vec![(8, -0.15), (9, 0.41), (10, 0.25), (3, 0.02)];
        about.cols[10] = vec![(9, -0.11), (10, 0.47), (11, 0.23)];
        let rest_columns: Vec<Vec<(usize, f64)>> = which.iter().map(|&j| rest.cols[j].clone()).collect();
        let about_columns: Vec<Vec<(usize, f64)>> = which.iter().map(|&j| about.cols[j].clone()).collect();
        let vent = vent_over(&which, &rest_columns, &[&about_columns]).expect("its change");
        let change = vent.change_in(&about_columns, &rest_columns);
        let (rest_tube, about_tube) = (Laid::of(rest.clone(), None), Laid::of(about.clone(), None));
        for k in 0..8 {
            let z = C::polar(if k % 2 == 0 { 1.0 } else { 0.99 }, 0.1 + 0.3 * k as f64);
            let (values, slopes) = ported(&rest_tube, Some(&vent), z, true).expect("its answers");
            let (g, dg) = combined(&values, &slopes, Some(&change), 1 + which.len());
            let (h, dh) = answer(&about_tube, z).expect("its own");
            assert!((g - h).abs() < 1e-12 * h.abs() && (dg - dh).abs() < 1e-10 * dh.abs(), "{k}: {:?} {:?}", (g.re, g.im), (h.re, h.im));
        }
        let mut steadies = Steadies::of(&rest_tube, &which).expect("its steadies");
        let f: Vec<f64> = (0..n).map(|i| 0.1 * i as f64 - 1.0).collect();
        let x = steadies.solve(&about_columns, &f).expect("its steady solve");
        let y = steady_solve(&about_tube, &f).expect("its own");
        assert!(x.iter().zip(&y).all(|(a, b)| (a - b).abs() < 1e-12 * (1.0 + b.abs())));
    }
}
