//! Each step's controls, as render/synthesis/workers/openwind_compiled.py Compiled.controls computes them
//! (research/OPENWIND_REALTIME_PLAN.md, design 3): the time OpenWInD reads them at (its clock's half steps added as it
//! adds them), each hole's opening (its fingering mixed into the next across a change, along the raised cosine where its
//! keys move smoothly), the reed's dimensionless parameters and closing pressure from its physical ones (OpenWInD's
//! Reed1dof get_dimensionless_values and get_Pclosed) or a scaled reed's own, and a flute's jet: its speed and its
//! derivative, its turbulence, its presence (its player's own breath over the speed the solver is given), its window's
//! opening, its parameters from its lip's opening and its length (openwind_compiled.py jet_parameters), and its window's
//! radiation moved by its length (window_inertance). Each physical control a curve: a number held, or its values on the
//! control grid read between its points as openwind_passages.py `sampled` reads them. The jet's turbulence from a
//! generator of its own, seeded. A derivative of OpenWInD's scheme (Inria), under its licence, GPL-3.0-or-later.

use serde::{Deserialize, Serialize};
use std::f64::consts::PI;

/// A control over time: a number held, or values every `step` seconds, read between its points (its last held after it).
#[derive(Deserialize, Serialize, Clone, Debug)]
#[serde(untagged)]
pub enum Curve {
    Held(f64),
    Grid { step: f64, grid: Vec<f64> },
}

impl Curve {
    /// Its value at `t`, as openwind_passages.py `sampled` reads it: x = t / step, its point below and the next.
    pub fn at(&self, t: f64) -> f64 {
        match self {
            Curve::Held(v) => *v,
            Curve::Grid { step, grid } => {
                let x = t / step;
                let below = x as i64;
                let n = grid.len() as i64;
                if n == 0 {
                    return 0.0;
                }
                if below >= n - 1 {
                    return grid[(n - 1) as usize];
                }
                let i = below.max(0) as usize;
                grid[i] + (grid[i + 1] - grid[i]) * (x - i as f64)
            }
        }
    }
}

/// The raised cosine from 0 to 1 over x in [0, 1] (transitions.py eased).
pub fn eased(x: f64) -> f64 {
    0.5 - 0.5 * (PI * x.clamp(0.0, 1.0)).cos()
}

/// Each hole's opening over time, as ExecuteScore.set_fingering finds it (openwind_compiled.py Compiled.openings): the
/// fingering of the note sounding, or two notes' mixed over the `transition` before each change's time.
#[derive(Deserialize, Serialize, Clone, Debug)]
pub struct Fingerings {
    /// Each note's time (s), its first's the start.
    pub times: Vec<f64>,
    /// Each note's opening of each hole, the holes in the chart's order.
    pub factors: Vec<Vec<f64>>,
    pub transition: f64,
    /// Its keys moved along the raised cosine, else along OpenWInD's straight line.
    pub smooth: bool,
}

impl Fingerings {
    fn hole(&self, t: f64, k: usize) -> f64 {
        let i = self.times.partition_point(|&x| x < t);
        let f = &self.factors;
        if i == 0 {
            return f[0][k];
        }
        if i >= self.times.len() {
            return f[f.len() - 1][k];
        }
        let end = self.times[i];
        let begin = end - self.transition;
        if t < begin {
            return f[i - 1][k];
        }
        let mut p = (t - begin) / (end - begin);
        if self.smooth {
            p = eased(p);
        }
        p * f[i][k] + (1.0 - p) * f[i - 1][k]
    }
}

/// A reed's controls: a physical one's (OpenWInD's Reed1dof) or a scaled one's (Reed1dof_Scaled), each a curve.
#[derive(Deserialize, Serialize, Clone, Debug)]
#[serde(tag = "kind", rename_all = "lowercase")]
pub enum Reed {
    Physical {
        section: Curve,
        mass: Curve,
        dissip: Curve,
        pulsation: Curve,
        width: Curve,
        opening: Curve,
        model: Curve,
        mouth_pressure: Curve,
        contact_pulsation: Curve,
        contact_exponent: Curve,
        zc: f64,
        rho: f64,
    },
    Scaled {
        gamma: Curve,
        zeta: Curve,
        kappa: Curve,
        pulsation: Curve,
        qfactor: Curve,
        contact_stifness: Curve,
        contact_exponent: Curve,
        model: Curve,
        closing_pressure: Curve,
        /// Its resting opening (m), where its reed is measured: no part of its kernel's columns, which are scaled, but
        /// what another engine's reed is made from (render/synthesis/src/ness-woodwind.mjs; ness_woodwind.py physical).
        #[serde(default, skip_serializing_if = "Option::is_none")]
        opening: Option<Curve>,
    },
}

/// The kernel's reed columns, in openwind_compiled.py REED_PARAMETERS' order.
pub const REED_PARAMETERS: [&str; 9] = ["gamma", "zeta", "kappa", "qfactor", "pulsation", "contact_stifness", "contact_exponent", "model", "closing_pressure"];

impl Reed {
    /// Its columns at `t`: gamma, zeta, kappa, Qr, omega_r, Kc, alpha_c, epsilon, its closing pressure.
    pub fn values(&self, t: f64) -> [f64; 9] {
        match self {
            Reed::Physical { section, mass, dissip, pulsation, width, opening, model, mouth_pressure, contact_pulsation, contact_exponent, zc, rho } => {
                // (get_dimensionless_values, its order: its dimensionful values, then the closing pressure, get_Pclosed's.)
                let (sr, mr, g) = (section.at(t), mass.at(t), dissip.at(t));
                let pulse = pulsation.at(t);
                let omega02 = pulse.powi(2);
                let (w, y0, epsilon, pm) = (width.at(t), opening.at(t), model.at(t), mouth_pressure.at(t));
                let (omega_nl, alpha_c) = (contact_pulsation.at(t), contact_exponent.at(t));
                let omegar = omega02.sqrt();
                let kc = omega_nl.powf(alpha_c + 1.0) / omega02;
                let qr = omegar / g;
                let pclosed = pulse.powi(2) * mr * y0 / sr;
                let gamma = pm / pclosed;
                let zeta = zc * y0 * w * (2.0 / (rho * pclosed)).sqrt();
                let kappa = y0 * zc * sr * omegar / pclosed;
                [gamma, zeta, kappa, qr, omegar, kc, alpha_c, epsilon, pclosed]
            }
            Reed::Scaled { gamma, zeta, kappa, pulsation, qfactor, contact_stifness, contact_exponent, model, closing_pressure, .. } => [
                gamma.at(t), zeta.at(t), kappa.at(t), qfactor.at(t), pulsation.at(t), contact_stifness.at(t), contact_exponent.at(t), model.at(t),
                closing_pressure.at(t),
            ],
        }
    }
}

/// A flute's controls and the constants its jet's parameters are made from (OpenWInD's Flute, as the body has it).
#[derive(Deserialize, Serialize, Clone, Debug)]
pub struct Flute {
    pub jet_velocity: Curve,
    pub noise_level: Curve,
    /// Its player's own breath (the jet's speed it asks, unfloored), where given: its presence over the speed given.
    pub breath: Option<Curve>,
    /// Its window's opening: its player's rolling in and out, or where it stands.
    pub window: Curve,
    /// Its jet's height and length (m), where its player's lip moves them; else `held`, or a transverse flute's own.
    pub jet: Option<(Curve, Curve)>,
    /// Its jet's parameters as the body holds them (Ascale, Gj, Gl, C, y0).
    pub held: [f64; 5],
    pub celerity: f64,
    /// A transverse flute's jet: a lip opening `aspect` times as wide as tall, over the share of its section its window
    /// leaves (openwind_worker.py transverse_window).
    pub aspect: Option<f64>,
    pub profile: Option<f64>,
    /// Whether its window rolls (a curve), which moves a transverse flute's jet with it.
    pub rolling: bool,
    pub gain: f64,
    pub loss_mag: f64,
    pub section: f64,
    pub convection: f64,
    pub edge_offset: f64,
    pub channel_height: f64,
    pub width: f64,
    pub edge_angle: f64,
    pub wall_thickness: f64,
    /// Its window's inertance where its radiation was made and the main pipe's section there, where the jet's length
    /// moves it (no transverse window's).
    pub inertance: Option<(f64, f64)>,
    /// Its dipole's flow sources on the convected jet (openwind_worker.py jet_dipole), else Verge et al.'s.
    #[serde(default)]
    pub two_point: bool,
}

/// The flute's columns, in openwind_compiled.py's order.
pub const FLUTE_COLUMNS: [&str; 12] = ["Uj", "dUj", "next_Uj", "noise", "window", "Ascale", "Gj", "Gl", "C", "y0", "presence", "span"];

impl Flute {
    /// Its jet's scaled parameters (Ascale, Gj, Gl, C, y0) for a channel's height `h` and a jet's length `w` (m), over the
    /// share `cover` of its window's section (openwind_compiled.py jet_parameters).
    pub fn jet_parameters(&self, h: f64, w: f64, cover: f64) -> [f64; 5] {
        let alpha_i = 0.3 / h;
        let b = match self.profile { Some(p) => p * h, None => 2.0 * h / 5.0 };
        let delta_d = 4.0 / PI * (2.0 * h * w).sqrt();
        let (delta_j, alpha_vc) = (1.0, 0.6f64);
        let (mut gain, mut loss_mag) = (self.gain, self.loss_mag);
        let mut ascale = (alpha_i * w).exp() * delta_j * h / b;
        if let Some(aspect) = self.aspect {
            ascale /= cover;
            gain = aspect * h * w / (cover * self.section);
            loss_mag /= cover * cover;
        }
        [ascale, gain * ascale * delta_d * b / (self.celerity * w), loss_mag / (2.0 * self.celerity * ascale * alpha_vc.powi(2)),
         w / self.convection, self.edge_offset / b]
    }

    /// Its dipole's flow sources' distance over twice its jet's disturbance's speed's share of U_j (m), for a channel's
    /// height `h` and a jet's length `w` (m): 0 where its dipole is Verge's (openwind_compiled.py jet_span).
    pub fn jet_span(&self, h: f64, w: f64) -> f64 {
        if self.two_point { 4.0 / PI * (2.0 * h * w).sqrt() / (2.0 * self.convection) } else { 0.0 }
    }

    /// Its window's inertance for a jet of length `w` (m), the main pipe's `section` there (openwind_compiled.py
    /// window_inertance).
    pub fn window_inertance(&self, section: f64, w: f64) -> f64 {
        let (sw, angle, wall) = (self.section, self.edge_angle * PI / 180.0, self.wall_thickness);
        let (delta, hh, rw) = (sw / section * 2.0, sw / w, (sw / PI).sqrt());
        let right = 2.0 * w / (PI * rw) * (((1.0 + delta.powi(2) / 4.0) / (2.0 * delta)).ln() + 2.0 / delta * (1.0 - delta.powi(2) / 4.0) * (delta / 2.0).atan());
        let edge = w / rw * (angle.tan() * (1.0 + wall / (w * angle.tan())).ln() + 0.85 / 32f64.powf(angle) * (wall / hh).sqrt());
        right + edge + 0.695
    }
}

/// What a control column is: a hole's opening (its place in the chart), a reed's parameter, a flute's.
#[derive(Clone, Copy, Debug)]
enum Column {
    Opening(usize),
    Reed(usize, usize),
    Flute(usize, usize),
}

/// A seeded generator of normal deviates: xoshiro256++ (D. Blackman & S. Vigna), its state from SplitMix64, each pair by
/// Box and Muller's transform.
pub struct Normal {
    s: [u64; 4],
    spare: Option<f64>,
}

impl Normal {
    pub fn new(seed: u64) -> Normal {
        let mut x = seed;
        let mut next = || {
            x = x.wrapping_add(0x9e3779b97f4a7c15);
            let mut z = x;
            z = (z ^ (z >> 30)).wrapping_mul(0xbf58476d1ce4e5b9);
            z = (z ^ (z >> 27)).wrapping_mul(0x94d049bb133111eb);
            z ^ (z >> 31)
        };
        Normal { s: [next(), next(), next(), next()], spare: None }
    }

    fn uniform(&mut self) -> f64 {
        let s = &mut self.s;
        let out = s[0].wrapping_add(s[3]).rotate_left(23).wrapping_add(s[0]);
        let t = s[1] << 17;
        s[2] ^= s[0];
        s[3] ^= s[1];
        s[1] ^= s[2];
        s[0] ^= s[3];
        s[2] ^= t;
        s[3] = s[3].rotate_left(45);
        // (In (0, 1]: its log finite.)
        ((out >> 11) as f64 + 1.0) * (1.0 / (1u64 << 53) as f64)
    }

    pub fn next(&mut self) -> f64 {
        if let Some(z) = self.spare.take() {
            return z;
        }
        let (u, v) = (self.uniform(), self.uniform());
        let r = (-2.0 * u.ln()).sqrt();
        self.spare = Some(r * (2.0 * PI * v).sin());
        r * (2.0 * PI * v).cos()
    }
}

/// A body's controls, laid out as its kernel reads them: its columns, its fingerings, reeds and flutes, its clock.
#[derive(Deserialize, Serialize, Clone, Debug)]
pub struct Spec {
    /// Each column, as openwind_compiled.py names it: ["opening", k], ["reed", r, name], ["flute", f, name].
    pub columns: Vec<Vec<serde_json::Value>>,
    pub fingerings: Option<Fingerings>,
    #[serde(default)]
    pub reeds: Vec<Reed>,
    #[serde(default)]
    pub flutes: Vec<Flute>,
    /// Its clock where it begins (s), and half a step (s).
    pub time: f64,
    pub half: f64,
    #[serde(default)]
    pub seed: u64,
}

pub struct Controls {
    columns: Vec<Column>,
    fingerings: Option<Fingerings>,
    reeds: Vec<Reed>,
    flutes: Vec<Flute>,
    time: f64,
    half: f64,
    noise: Normal,
}

impl Controls {
    pub fn new(spec: Spec) -> Result<Controls, String> {
        let mut columns = Vec::with_capacity(spec.columns.len());
        for c in &spec.columns {
            let kind = c.first().and_then(|v| v.as_str()).ok_or("a column without its kind")?;
            let index = c.get(1).and_then(|v| v.as_u64()).ok_or("a column without its index")? as usize;
            let name = || c.get(2).and_then(|v| v.as_str()).ok_or("a column without its name");
            columns.push(match kind {
                "opening" => {
                    let f = spec.fingerings.as_ref().ok_or("an opening without fingerings")?;
                    if f.factors.is_empty() || f.factors.len() != f.times.len() || f.factors.iter().any(|row| index >= row.len()) {
                        return Err("a hole beyond its fingerings".into());
                    }
                    Column::Opening(index)
                }
                "reed" => {
                    let n = name()?;
                    let at = REED_PARAMETERS.iter().position(|p| *p == n).ok_or_else(|| format!("no reed parameter {n}"))?;
                    if index >= spec.reeds.len() {
                        return Err("a reed column without its reed".into());
                    }
                    Column::Reed(index, at)
                }
                "flute" => {
                    let n = name()?;
                    let at = FLUTE_COLUMNS.iter().position(|p| *p == n).ok_or_else(|| format!("no flute column {n}"))?;
                    if index >= spec.flutes.len() {
                        return Err("a flute column without its flute".into());
                    }
                    Column::Flute(index, at)
                }
                other => return Err(format!("no column of kind {other}")),
            });
        }
        Ok(Controls { columns, fingerings: spec.fingerings, reeds: spec.reeds, flutes: spec.flutes, time: spec.time, half: spec.half,
                      noise: Normal::new(spec.seed) })
    }

    pub fn width(&self) -> usize {
        self.columns.len()
    }

    /// The next `steps` steps' controls, a row a step, into `u`.
    pub fn fill(&mut self, steps: usize, u: &mut [f64]) {
        let cols = self.columns.len();
        let mut reed_rows: Vec<[f64; 9]> = vec![[0.0; 9]; self.reeds.len()];
        let mut flute_rows: Vec<[f64; 12]> = vec![[0.0; 12]; self.flutes.len()];
        for s in 0..steps {
            // (Its time as OpenWInD's clock adds it: half a step, the time read, half a step.)
            self.time += self.half;
            let t = self.time;
            self.time += self.half;
            for (r, reed) in self.reeds.iter().enumerate() {
                reed_rows[r] = reed.values(t);
            }
            for (f, flute) in self.flutes.iter().enumerate() {
                flute_rows[f] = self.flute_row(flute, t);
            }
            let row = &mut u[s * cols..(s + 1) * cols];
            for (c, column) in self.columns.iter().enumerate() {
                row[c] = match *column {
                    Column::Opening(k) => self.fingerings.as_ref().map_or(0.0, |f| f.hole(t, k)),
                    Column::Reed(r, p) => reed_rows[r][p],
                    Column::Flute(f, p) => flute_rows[f][p],
                };
            }
            for (f, flute) in self.flutes.iter().enumerate() {
                if let Some(at) = self.columns.iter().position(|c| matches!(c, Column::Flute(g, 3) if *g == f)) {
                    row[at] = flute.noise_level.at(t) * self.noise.next();
                }
            }
        }
    }

    /// Each flute's turbulence column and its level at the step last filled: a held row (the live dial's, stream.rs)
    /// holds the level and draws its turbulence itself, a step at a time, as `fill` draws a group's.
    pub fn noise_levels(&self) -> Vec<(usize, f64)> {
        let t = self.time - self.half;
        self.flutes.iter().enumerate()
            .filter_map(|(f, flute)| self.columns.iter().position(|c| matches!(c, Column::Flute(g, 3) if *g == f)).map(|at| (at, flute.noise_level.at(t))))
            .collect()
    }

    /// `steps` steps passed over as `fill` passes them, nothing written: its clock added up as filling adds it, and each
    /// flute's turbulence drawn, so that the controls go on from there as they would have. (A group taken up where it
    /// stands: stream.rs. Its clock set at once, by multiplying, had rounded otherwise, and a grid read a point over.)
    pub fn skip(&mut self, steps: u64) {
        let drawn = (0..self.flutes.len()).filter(|&f| self.columns.iter().any(|c| matches!(c, Column::Flute(g, 3) if *g == f))).count();
        for _ in 0..steps {
            self.time += self.half;
            self.time += self.half;
            for _ in 0..drawn {
                self.noise.next();
            }
        }
    }

    fn flute_row(&self, flute: &Flute, t: f64) -> [f64; 12] {
        let dt = 2.0 * self.half;
        let (uj, after, before) = (flute.jet_velocity.at(t), flute.jet_velocity.at(t + dt), flute.jet_velocity.at(t - dt));
        let presence = match &flute.breath {
            Some(b) => (b.at(t) / uj.max(1e-12)).clamp(0.0, 1.0),
            None => 1.0,
        };
        let mut window = flute.window.at(t);
        let cover = window * window;
        let jet = if let Some((h, w)) = &flute.jet {
            flute.jet_parameters(h.at(t), w.at(t), if flute.aspect.is_some() { cover } else { 1.0 })
        } else if flute.aspect.is_some() && flute.rolling {
            flute.jet_parameters(flute.channel_height, flute.width, cover)
        } else {
            flute.held
        };
        if let Some((made, section)) = flute.inertance {
            let length = flute.jet.as_ref().map_or(flute.width, |(_, w)| w.at(t));
            window *= made / flute.window_inertance(section, length);
        }
        let span = match &flute.jet {
            Some((h, w)) => flute.jet_span(h.at(t), w.at(t)),
            None => flute.jet_span(flute.channel_height, flute.width),
        };
        [uj, (after - before) / (2.0 * dt), after, 0.0, window, jet[0], jet[1], jet[2], jet[3], jet[4], presence, span]
    }
}
