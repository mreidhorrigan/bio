//! Linear algebra on the engine's own maps (starts.rs): complex numbers; a square sparse matrix's rows and columns put in
//! the order that keeps its entries nearest its diagonal (reverse Cuthill-McKee: Cuthill & McKee 1969,
//! doi:10.1145/800195.805928; George 1971, its reversal); and such a matrix, banded so, factored by Gaussian elimination
//! with partial pivoting (as LAPACK's zgbtrf and zgbtrs) and solved directly. Nothing iterated.

#[derive(Clone, Copy, Debug, PartialEq, Default)]
pub struct C {
    pub re: f64,
    pub im: f64,
}

impl C {
    pub fn new(re: f64, im: f64) -> C {
        C { re, im }
    }
    pub fn polar(r: f64, a: f64) -> C {
        C { re: r * a.cos(), im: r * a.sin() }
    }
    pub fn abs(self) -> f64 {
        self.re.hypot(self.im)
    }
    pub fn arg(self) -> f64 {
        self.im.atan2(self.re)
    }
    pub fn conj(self) -> C {
        C { re: self.re, im: -self.im }
    }
    pub fn inv(self) -> C {
        let n = self.re * self.re + self.im * self.im;
        C { re: self.re / n, im: -self.im / n }
    }
    pub fn sqrt(self) -> C {
        let r = self.abs().sqrt();
        C::polar(r, self.arg() / 2.0)
    }
}

impl std::ops::Add for C {
    type Output = C;
    fn add(self, o: C) -> C {
        C { re: self.re + o.re, im: self.im + o.im }
    }
}
impl std::ops::Sub for C {
    type Output = C;
    fn sub(self, o: C) -> C {
        C { re: self.re - o.re, im: self.im - o.im }
    }
}
impl std::ops::Neg for C {
    type Output = C;
    fn neg(self) -> C {
        C { re: -self.re, im: -self.im }
    }
}
impl std::ops::Mul for C {
    type Output = C;
    fn mul(self, o: C) -> C {
        C { re: self.re * o.re - self.im * o.im, im: self.re * o.im + self.im * o.re }
    }
}
impl std::ops::Mul<f64> for C {
    type Output = C;
    fn mul(self, k: f64) -> C {
        C { re: self.re * k, im: self.im * k }
    }
}
impl std::ops::Div for C {
    type Output = C;
    fn div(self, o: C) -> C {
        self * o.inv()
    }
}
impl std::ops::Div<f64> for C {
    type Output = C;
    fn div(self, k: f64) -> C {
        C { re: self.re / k, im: self.im / k }
    }
}

/// The order (new position -> old index) that keeps the entries of a square matrix of `n` rows nearest its diagonal, its
/// entries `pattern` (row, column), taken both ways: reverse Cuthill-McKee from a far end of each connected part (a
/// pseudo-peripheral node: the last reached from a node of least degree, twice).
pub fn rcm(n: usize, pattern: &[(usize, usize)]) -> Vec<usize> {
    let mut adj: Vec<Vec<usize>> = vec![vec![]; n];
    for &(i, j) in pattern {
        if i != j {
            adj[i].push(j);
            adj[j].push(i);
        }
    }
    for a in adj.iter_mut() {
        a.sort_unstable();
        a.dedup();
    }
    let degree: Vec<usize> = adj.iter().map(|a| a.len()).collect();
    let mut placed = vec![false; n];
    let mut order = Vec::with_capacity(n);
    let bfs = |from: usize, seen: &mut Vec<bool>| -> Vec<usize> {
        let mut out = vec![from];
        seen[from] = true;
        let mut k = 0;
        while k < out.len() {
            let mut next: Vec<usize> = adj[out[k]].iter().copied().filter(|&j| !seen[j]).collect();
            next.sort_by_key(|&j| (degree[j], j));
            for j in next {
                seen[j] = true;
                out.push(j);
            }
            k += 1;
        }
        out
    };
    let mut by_degree: Vec<usize> = (0..n).collect();
    by_degree.sort_by_key(|&j| (degree[j], j));
    for &start in &by_degree {
        if placed[start] {
            continue;
        }
        // (A far end of its part: the last reached from it, and from that, the last reached again.)
        let mut root = start;
        for _ in 0..2 {
            let mut seen = placed.clone();
            root = *bfs(root, &mut seen).last().unwrap();
        }
        let part = bfs(root, &mut placed);
        order.extend(part.into_iter().rev());
    }
    order
}

/// A square complex matrix of `n` rows, banded: `kl` diagonals below its main one and `ku` above, stored as LAPACK's
/// band storage with `kl` more above for the pivots' fill, then factored in place (lu) and solved (solve).
pub struct Banded {
    pub n: usize,
    pub kl: usize,
    pub ku: usize,
    ld: usize,
    a: Vec<C>,
    pivots: Vec<usize>,
}

impl Banded {
    pub fn new(n: usize, kl: usize, ku: usize) -> Banded {
        let ld = 2 * kl + ku + 1;
        Banded { n, kl, ku, ld, a: vec![C::default(); ld * n], pivots: vec![0; n] }
    }

    #[inline(always)]
    fn at(&self, i: usize, j: usize) -> usize {
        j * self.ld + (self.kl + self.ku + i) - j
    }

    /// Its entry (i, j) added to (inside its band).
    pub fn add(&mut self, i: usize, j: usize, v: C) {
        let k = self.at(i, j);
        self.a[k] = self.a[k] + v;
    }

    /// Factored in place, P A = L U, by Gaussian elimination with partial pivoting (zgbtf2's): Err where a pivot is nothing.
    pub fn lu(&mut self) -> Result<(), String> {
        let (n, kl, ku) = (self.n, self.kl, self.ku);
        let kv = ku + kl;
        let mut ju = 0usize;
        for j in 0..n {
            let km = kl.min(n - 1 - j);
            // (The pivot: the largest of the column's entries on and below the diagonal.)
            let mut p = 0;
            let mut best = -1.0;
            for i in 0..=km {
                let v = self.a[j * self.ld + kv + i].abs();
                if v > best {
                    best = v;
                    p = i;
                }
            }
            self.pivots[j] = j + p;
            if best == 0.0 {
                return Err(format!("its matrix is singular at its row {j}"));
            }
            ju = ju.max((j + ku + p).min(n - 1));
            if p != 0 {
                for c in j..=ju {
                    let (x, y) = (self.at(j, c), self.at(j + p, c));
                    self.a.swap(x, y);
                }
            }
            if km > 0 {
                let pivot = self.a[j * self.ld + kv].inv();
                for i in 1..=km {
                    let k = j * self.ld + kv + i;
                    self.a[k] = self.a[k] * pivot;
                }
                for c in j + 1..=ju {
                    let u = self.a[self.at(j, c)];
                    if u == C::default() {
                        continue;
                    }
                    for i in 1..=km {
                        let l = self.a[j * self.ld + kv + i];
                        let k = self.at(j + i, c);
                        self.a[k] = self.a[k] - l * u;
                    }
                }
            }
        }
        Ok(())
    }

    /// A X = b solved, once factored (zgbtrs's).
    pub fn solve(&self, b: &[C]) -> Vec<C> {
        let (n, kl, ku) = (self.n, self.kl, self.ku);
        let kv = ku + kl;
        let mut x = b.to_vec();
        for j in 0..n {
            let p = self.pivots[j];
            if p != j {
                x.swap(p, j);
            }
            let km = kl.min(n - 1 - j);
            let xj = x[j];
            for i in 1..=km {
                x[j + i] = x[j + i] - self.a[j * self.ld + kv + i] * xj;
            }
        }
        for j in (0..n).rev() {
            x[j] = x[j] / self.a[j * self.ld + kv];
            let xj = x[j];
            let top = j.saturating_sub(kv);
            for i in top..j {
                x[i] = x[i] - self.a[self.at(i, j)] * xj;
            }
        }
        x
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn banded_solves_as_dense() {
        // (A tridiagonal-and-more matrix, put out of order, ordered and solved, against its product.)
        let n = 40;
        let mut entries = vec![];
        for i in 0..n {
            entries.push((i, i, C::new(4.0 + i as f64 * 0.1, 1.0)));
            if i + 1 < n {
                entries.push((i, i + 1, C::new(-1.0, 0.3)));
                entries.push((i + 1, i, C::new(0.5, -0.2)));
            }
            if i + 3 < n {
                entries.push((i + 3, i, C::new(0.25, 0.0)));
            }
        }
        let shuffle: Vec<usize> = (0..n).map(|k| (k * 17) % n).collect();
        let entries: Vec<(usize, usize, C)> = entries.iter().map(|&(i, j, v)| (shuffle[i], shuffle[j], v)).collect();
        let order = rcm(n, &entries.iter().map(|&(i, j, _)| (i, j)).collect::<Vec<_>>());
        let mut position = vec![0; n];
        for (p, &o) in order.iter().enumerate() {
            position[o] = p;
        }
        let (mut kl, mut ku) = (0, 0);
        for &(i, j, _) in &entries {
            let (pi, pj) = (position[i], position[j]);
            kl = kl.max(pi.saturating_sub(pj));
            ku = ku.max(pj.saturating_sub(pi));
        }
        assert!(kl <= 6 && ku <= 6, "{kl} {ku}");
        let mut m = Banded::new(n, kl, ku);
        for &(i, j, v) in &entries {
            m.add(position[i], position[j], v);
        }
        m.lu().unwrap();
        let x: Vec<C> = (0..n).map(|k| C::new(k as f64, 1.0 - k as f64 * 0.5)).collect();
        let mut b = vec![C::default(); n];
        for &(i, j, v) in &entries {
            b[i] = b[i] + v * x[j];
        }
        let bp: Vec<C> = order.iter().map(|&o| b[o]).collect();
        let xp = m.solve(&bp);
        for (p, &o) in order.iter().enumerate() {
            assert!((xp[p] - x[o]).abs() < 1e-12 * (1.0 + x[o].abs()), "{p}");
        }
    }
}

// ---- A sparse matrix eliminated in an order that keeps it sparse (speaking.rs), here at the file's end. ----

/// A sparse matrix's pattern laid out for Gaussian elimination in the order that keeps it sparsest, the least connected
/// first (minimum degree, on its pattern made symmetric), each step's fill laid out once: a tube's map's loss states each
/// eliminated onto its own node without fill, where a band would carry them all (the clarinet's 9140 doubles in a band
/// 176 wide either side, 97 ms an answer). Its values then factored at any z by the steps laid out (`factor`), its
/// pivots on its diagonal; any matrix whose entries stand in its pattern factored by it (`slots`), as the maps of one
/// tube about its steady states are.
pub struct Eliminated {
    pub n: usize,
    // (Each step's double, in order; and each double's own slot, its later neighbours' slots in its column (L) and its
    // row (U), and the updates its step makes: target, its L's, its U's.)
    order: Vec<usize>,
    diagonal: Vec<usize>,
    lower: Vec<Vec<(usize, usize)>>,
    upper: Vec<Vec<(usize, usize)>>,
    updates: Vec<Vec<(usize, usize, usize)>>,
    // (Each entry's slot, its fill's among them, and how many.)
    slot: std::collections::HashMap<(usize, usize), usize>,
    pub size: usize,
}

/// Its values factored, L unit below and U above its diagonal, in its slots.
pub struct Factored<'a> {
    by: &'a Eliminated,
    v: Vec<C>,
}

impl Eliminated {
    /// The pattern of the n-square matrix whose entries are `pattern` (row, column), its diagonal among them always.
    pub fn of(n: usize, pattern: &[(usize, usize)]) -> Eliminated {
        use std::collections::{BTreeSet, BinaryHeap, HashMap};
        use std::cmp::Reverse;
        let mut adjacent: Vec<BTreeSet<usize>> = vec![BTreeSet::new(); n];
        for &(i, j) in pattern {
            if i != j {
                adjacent[i].insert(j);
                adjacent[j].insert(i);
            }
        }
        // (The order: the least connected left each time, ties the lowest; a step's neighbours joined to one another.)
        let mut heap: BinaryHeap<Reverse<(usize, usize)>> = (0..n).map(|i| Reverse((adjacent[i].len(), i))).collect();
        let mut gone = vec![false; n];
        let mut order = Vec::with_capacity(n);
        let mut later: Vec<Vec<usize>> = vec![vec![]; n];
        while let Some(Reverse((degree, v))) = heap.pop() {
            if gone[v] || degree != adjacent[v].len() {
                continue;
            }
            gone[v] = true;
            order.push(v);
            let neighbours: Vec<usize> = adjacent[v].iter().copied().collect();
            for &a in &neighbours {
                adjacent[a].remove(&v);
                for &b in &neighbours {
                    if a != b {
                        adjacent[a].insert(b);
                    }
                }
            }
            for &a in &neighbours {
                heap.push(Reverse((adjacent[a].len(), a)));
            }
            later[v] = neighbours;
        }
        // (Each entry's slot: the matrix's, and each step's fill.)
        let mut slot: HashMap<(usize, usize), usize> = HashMap::new();
        let take = |i: usize, j: usize, slot: &mut HashMap<(usize, usize), usize>| -> usize {
            let next = slot.len();
            *slot.entry((i, j)).or_insert(next)
        };
        for &(i, j) in pattern {
            take(i, j, &mut slot);
        }
        let diagonal: Vec<usize> = (0..n).map(|i| take(i, i, &mut slot)).collect();
        let (mut lower, mut upper, mut updates) = (vec![vec![]; n], vec![vec![]; n], vec![vec![]; n]);
        for &v in &order {
            let l: Vec<(usize, usize)> = later[v].iter().map(|&r| (r, take(r, v, &mut slot))).collect();
            let u: Vec<(usize, usize)> = later[v].iter().map(|&c| (c, take(v, c, &mut slot))).collect();
            let mut ups = Vec::with_capacity(l.len() * u.len());
            for &(r, ls) in &l {
                for &(c, us) in &u {
                    ups.push((take(r, c, &mut slot), ls, us));
                }
            }
            lower[v] = l;
            upper[v] = u;
            updates[v] = ups;
        }
        let size = slot.len();
        Eliminated { n, order, diagonal, lower, upper, updates, slot, size }
    }

    /// Where each entry of `pattern` (row, column) stands in its slots, or none where one stands outside its pattern.
    pub fn slots(&self, pattern: &[(usize, usize)]) -> Option<Vec<usize>> {
        pattern.iter().map(|p| self.slot.get(p).copied()).collect()
    }

    /// A matrix factored: its entries `values` in their `slots` (`slots`'s) and `diagonal` added on its diagonal -> its
    /// factors, or why not: a pivot at nothing. Its pivots unchosen, a solve's own residual says whether they stood (the
    /// caller's: a matrix nearly singular where it is asked -- a tube's at its own resonance -- is solved well in its order,
    /// its last pivots small as they should be).
    pub fn factor(&self, slots: &[usize], values: &[C], diagonal: C) -> Result<Factored<'_>, String> {
        let mut v = vec![C::default(); self.size];
        for (&s, &x) in slots.iter().zip(values) {
            v[s] = v[s] + x;
        }
        for &s in &self.diagonal {
            v[s] = v[s] + diagonal;
        }
        for &k in &self.order {
            let pivot = v[self.diagonal[k]];
            if !(pivot.abs() > 0.0 && pivot.abs().is_finite()) {
                return Err(format!("its pivot at {k} is {:e}", pivot.abs()));
            }
            let inverse = pivot.inv();
            for &(_, s) in &self.lower[k] {
                v[s] = v[s] * inverse;
            }
            for &(target, l, u) in &self.updates[k] {
                v[target] = v[target] - v[l] * v[u];
            }
        }
        Ok(Factored { by: self, v })
    }
}

impl Factored<'_> {
    /// A x = b solved, b and x in the matrix's own order.
    pub fn solve(&self, b: &[C]) -> Vec<C> {
        let e = self.by;
        let mut x = b.to_vec();
        for &k in &e.order {
            let xk = x[k];
            for &(r, s) in &e.lower[k] {
                x[r] = x[r] - self.v[s] * xk;
            }
        }
        for &k in e.order.iter().rev() {
            let mut s = x[k];
            for &(c, slot) in &e.upper[k] {
                s = s - self.v[slot] * x[c];
            }
            x[k] = s / self.v[e.diagonal[k]];
        }
        x
    }

    /// A^T x = b solved (its transpose, not its conjugate): U^T y = b down its order, then L^T x = y back up it.
    pub fn solve_transposed(&self, b: &[C]) -> Vec<C> {
        let e = self.by;
        let mut x = b.to_vec();
        for &k in &e.order {
            x[k] = x[k] / self.v[e.diagonal[k]];
            let xk = x[k];
            for &(c, s) in &e.upper[k] {
                x[c] = x[c] - self.v[s] * xk;
            }
        }
        for &k in e.order.iter().rev() {
            let mut s = x[k];
            for &(r, slot) in &e.lower[k] {
                s = s - self.v[slot] * x[r];
            }
            x[k] = s;
        }
        x
    }
}

/// A real matrix's values factored in an Eliminated's order, as Factored a complex one's: its steady states' (z = 1) in
/// a quarter of the arithmetic.
pub struct FactoredReal<'a> {
    by: &'a Eliminated,
    v: Vec<f64>,
}

impl Eliminated {
    /// `factor` in real numbers.
    pub fn factor_real(&self, slots: &[usize], values: &[f64], diagonal: f64) -> Result<FactoredReal<'_>, String> {
        let mut v = vec![0.0; self.size];
        for (&s, &x) in slots.iter().zip(values) {
            v[s] += x;
        }
        for &s in &self.diagonal {
            v[s] += diagonal;
        }
        for &k in &self.order {
            let pivot = v[self.diagonal[k]];
            if !(pivot.abs() > 0.0 && pivot.is_finite()) {
                return Err(format!("its pivot at {k} is {pivot:e}"));
            }
            let inverse = 1.0 / pivot;
            for &(_, s) in &self.lower[k] {
                v[s] *= inverse;
            }
            for &(target, l, u) in &self.updates[k] {
                v[target] -= v[l] * v[u];
            }
        }
        Ok(FactoredReal { by: self, v })
    }
}

impl FactoredReal<'_> {
    /// A x = b solved, b and x in the matrix's own order.
    pub fn solve(&self, b: &[f64]) -> Vec<f64> {
        let e = self.by;
        let mut x = b.to_vec();
        for &k in &e.order {
            let xk = x[k];
            for &(r, s) in &e.lower[k] {
                x[r] -= self.v[s] * xk;
            }
        }
        for &k in e.order.iter().rev() {
            let mut s = x[k];
            for &(c, slot) in &e.upper[k] {
                s -= self.v[slot] * x[c];
            }
            x[k] = s / self.v[e.diagonal[k]];
        }
        x
    }
}

#[cfg(test)]
mod eliminated_tests {
    use super::*;

    // (A matrix whose leaves hang on a chain -- as a tube's loss states hang on its nodes -- solved by elimination in its
    // order against the banded solve.)
    #[test]
    fn elimination_solves_as_the_band_does() {
        let (chain, leaves) = (40usize, 6usize);
        let n = chain * (1 + leaves);
        let mut entries: Vec<(usize, usize, C)> = vec![];
        for i in 0..chain {
            entries.push((i, i, C::new(4.0 + i as f64 * 0.01, 0.3)));
            if i + 1 < chain {
                entries.push((i, i + 1, C::new(-1.0, 0.2)));
                entries.push((i + 1, i, C::new(-0.7, -0.1)));
            }
            for k in 0..leaves {
                let leaf = chain + i * leaves + k;
                entries.push((leaf, leaf, C::new(2.0 + k as f64 * 0.1, -0.2)));
                entries.push((leaf, i, C::new(0.3, 0.05 * k as f64)));
                entries.push((i, leaf, C::new(-0.2, 0.1)));
            }
        }
        let pattern: Vec<(usize, usize)> = entries.iter().map(|&(i, j, _)| (i, j)).collect();
        let e = Eliminated::of(n, &pattern);
        let values: Vec<C> = entries.iter().map(|&(_, _, v)| v).collect();
        let f = e.factor(&e.slots(&pattern).expect("its own pattern"), &values, C::default()).expect("its factors");
        assert!(e.slots(&[(0, chain - 1)]).is_none(), "an entry outside its pattern");
        let x: Vec<C> = (0..n).map(|k| C::new(k as f64 * 0.1, 1.0 - k as f64 * 0.03)).collect();
        let mut b = vec![C::default(); n];
        for &(i, j, v) in &entries {
            b[i] = b[i] + v * x[j];
        }
        let got = f.solve(&b);
        for k in 0..n {
            assert!((got[k] - x[k]).abs() < 1e-11 * (1.0 + x[k].abs()), "{k}: {:?} against {:?}", (got[k].re, got[k].im), (x[k].re, x[k].im));
        }
        // (Its transpose by the same factors.)
        let mut bt = vec![C::default(); n];
        for &(i, j, v) in &entries {
            bt[j] = bt[j] + v * x[i];
        }
        let got = f.solve_transposed(&bt);
        for k in 0..n {
            assert!((got[k] - x[k]).abs() < 1e-11 * (1.0 + x[k].abs()), "transposed {k}: {:?} against {:?}", (got[k].re, got[k].im), (x[k].re, x[k].im));
        }
        // (Its real parts alone, factored and solved in real numbers.)
        let real: Vec<f64> = values.iter().map(|v| v.re).collect();
        let fr = e.factor_real(&e.slots(&pattern).unwrap(), &real, 0.5).expect("its real factors");
        let xr: Vec<f64> = (0..n).map(|k| 1.0 - k as f64 * 0.01).collect();
        let mut br: Vec<f64> = xr.iter().map(|v| v * 0.5).collect();
        for &(i, j, v) in &entries {
            br[i] += v.re * xr[j];
        }
        let got = fr.solve(&br);
        for k in 0..n {
            assert!((got[k] - xr[k]).abs() < 1e-11 * (1.0 + xr[k].abs()), "real {k}: {} against {}", got[k], xr[k]);
        }
    }
}
