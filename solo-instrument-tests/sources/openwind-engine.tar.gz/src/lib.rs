//! OpenWInD's woodwinds stepped in Rust (research/OPENWIND_REALTIME_PLAN.md, stage 2): the fast kernel's scheme
//! (kernel.rs) on the body openwind_compiled.py lays out, loaded by it as the C kernels are (ctypes), sizes given so that
//! every read is checked. A derivative of OpenWInD's scheme (Inria), under its licence, GPL-3.0-or-later.

pub mod body;
pub mod controls;
pub mod kernel;
pub mod law;
pub mod noise;
pub mod stream;
pub mod technique;
pub mod tract;
#[cfg(target_arch = "wasm32")]
pub mod wasm;

use std::ffi::{c_char, CStr};

/// The C kernels' own call (openwind_kernel_fast.c openwind_steps) with each array's length:
/// `i` (`ni` integers) and `d` (`nd` doubles) the body, stepped in place; `u` (`nu`) the steps' controls; `y` (`ny`) the
/// outputs written. -> 0, or the C kernels' code for where and why it stopped; -1 where an array is shorter than its
/// header says.
///
/// # Safety
/// Each pointer must address that many values, and nothing else may touch them during the call.
#[no_mangle]
pub unsafe extern "C" fn openwind_steps_sized(i: *mut i64, ni: i64, d: *mut f64, nd: i64, u: *const f64, nu: i64,
                                              y: *mut f64, ny: i64, steps: i64) -> i64 {
    if i.is_null() || d.is_null() || u.is_null() || y.is_null() || ni < 10 || nd < 0 || nu < 0 || ny < 0 || steps < 0 {
        return -1;
    }
    let (i, d) = (std::slice::from_raw_parts_mut(i, ni as usize), std::slice::from_raw_parts_mut(d, nd as usize));
    let (u, y) = (std::slice::from_raw_parts(u, nu as usize), std::slice::from_raw_parts_mut(y, ny as usize));
    let (cols, outs) = (i[9].max(0) as usize, i[8].max(0) as usize);
    if u.len() < steps as usize * cols || y.len() < steps as usize * outs {
        return -1;
    }
    kernel::steps(i, d, u, y, steps as usize)
}

/// openwind_steps_sized with its bore stepped in singles (kernel.rs steps_single; research/OPENWIND_REALTIME_PLAN.md,
/// stage 4): its connectors, its ends and its no-flow pressures in doubles still.
///
/// # Safety
/// As openwind_steps_sized.
#[no_mangle]
pub unsafe extern "C" fn openwind_steps_single(i: *mut i64, ni: i64, d: *mut f64, nd: i64, u: *const f64, nu: i64,
                                               y: *mut f64, ny: i64, steps: i64) -> i64 {
    if i.is_null() || d.is_null() || u.is_null() || y.is_null() || ni < 10 || nd < 0 || nu < 0 || ny < 0 || steps < 0 {
        return -1;
    }
    let (i, d) = (std::slice::from_raw_parts_mut(i, ni as usize), std::slice::from_raw_parts_mut(d, nd as usize));
    let (u, y) = (std::slice::from_raw_parts(u, nu as usize), std::slice::from_raw_parts_mut(y, ny as usize));
    let (cols, outs) = (i[9].max(0) as usize, i[8].max(0) as usize);
    if u.len() < steps as usize * cols || y.len() < steps as usize * outs {
        return -1;
    }
    kernel::steps_single(i, d, u, y, steps as usize)
}

/// Each step's controls from their curves (controls.rs; research/OPENWIND_REALTIME_PLAN.md, design 3): `spec` a JSON
/// controls.rs Spec, NUL-terminated. -> its controls, or null where it is not one (said on stderr). Freed by
/// openwind_controls_free.
///
/// # Safety
/// `spec` must address a NUL-terminated string.
#[no_mangle]
pub unsafe extern "C" fn openwind_controls_new(spec: *const c_char) -> *mut controls::Controls {
    if spec.is_null() {
        return std::ptr::null_mut();
    }
    let read = CStr::from_ptr(spec).to_str().map_err(|e| e.to_string())
        .and_then(|text| serde_json::from_str::<controls::Spec>(text).map_err(|e| e.to_string()))
        .and_then(controls::Controls::new);
    match read {
        Ok(c) => Box::into_raw(Box::new(c)),
        Err(e) => {
            eprintln!("openwind_controls_new: {e}");
            std::ptr::null_mut()
        }
    }
}

/// The next `steps` steps' controls into `u` (`nu` doubles), a row a step. -> 0; -1 where `u` is too short.
///
/// # Safety
/// `c` must be openwind_controls_new's, not freed; `u` must address `nu` doubles.
#[no_mangle]
pub unsafe extern "C" fn openwind_controls_fill(c: *mut controls::Controls, steps: i64, u: *mut f64, nu: i64) -> i64 {
    if c.is_null() || u.is_null() || steps < 0 || nu < 0 {
        return -1;
    }
    let c = &mut *c;
    if (nu as usize) < steps as usize * c.width() {
        return -1;
    }
    c.fill(steps as usize, std::slice::from_raw_parts_mut(u, nu as usize));
    0
}

/// `steps` steps passed over, nothing written (controls.rs skip: a group taken up where it stands). -> 0; -1 where
/// it is not one.
///
/// # Safety
/// `c` must be openwind_controls_new's, not freed.
#[no_mangle]
pub unsafe extern "C" fn openwind_controls_skip(c: *mut controls::Controls, steps: i64) -> i64 {
    if c.is_null() || steps < 0 {
        return -1;
    }
    (*c).skip(steps as u64);
    0
}

/// # Safety
/// `c` must be openwind_controls_new's, freed once.
#[no_mangle]
pub unsafe extern "C" fn openwind_controls_free(c: *mut controls::Controls) {
    if !c.is_null() {
        drop(Box::from_raw(c));
    }
}

/// A saved body's player (body.rs, kernel.rs Player): `folder` its folder (NUL-terminated), its bore in singles where
/// `single` is not 0. -> its player, or null where it cannot be read (said on stderr). Freed by openwind_player_free.
///
/// # Safety
/// `folder` must address a NUL-terminated string.
#[no_mangle]
pub unsafe extern "C" fn openwind_player_load(folder: *const c_char, single: i64) -> *mut kernel::Player {
    if folder.is_null() {
        return std::ptr::null_mut();
    }
    let made = CStr::from_ptr(folder).to_str().map_err(|e| e.to_string())
        .and_then(|f| body::Body::load(std::path::Path::new(f))).and_then(|b| b.player(single != 0));
    match made {
        Ok(p) => Box::into_raw(Box::new(p)),
        Err(e) => {
            eprintln!("openwind_player_load: {e}");
            std::ptr::null_mut()
        }
    }
}

/// `steps` more steps of a player: `u` (`nu` doubles) their controls, a row a step; `y` (`ny`) its outputs written. -> as
/// openwind_steps_sized.
///
/// # Safety
/// `p` must be openwind_player_load's, not freed; `u` and `y` must address `nu` and `ny` doubles.
#[no_mangle]
pub unsafe extern "C" fn openwind_player_steps(p: *mut kernel::Player, u: *const f64, nu: i64, y: *mut f64, ny: i64, steps: i64) -> i64 {
    if p.is_null() || u.is_null() || y.is_null() || nu < 0 || ny < 0 || steps < 0 {
        return -1;
    }
    (*p).steps(std::slice::from_raw_parts(u, nu as usize), std::slice::from_raw_parts_mut(y, ny as usize), steps as usize)
}

/// # Safety
/// `p` must be openwind_player_load's, freed once.
#[no_mangle]
pub unsafe extern "C" fn openwind_player_free(p: *mut kernel::Player) {
    if !p.is_null() {
        drop(Box::from_raw(p));
    }
}

/// A breath group's controls shaped by the engine (law.rs): `law` a model's law (openwind_engine.py law_of, JSON),
/// `folder` its saved body's folder, `group` the group (law.rs Group, JSON), each NUL-terminated. -> its controls' Spec
/// as JSON (controls.rs), or null where it cannot be shaped (said on stderr); freed by openwind_text_free.
///
/// # Safety
/// Each pointer must address a NUL-terminated string.
#[no_mangle]
pub unsafe extern "C" fn openwind_shape(law: *const c_char, folder: *const c_char, group: *const c_char) -> *mut c_char {
    if law.is_null() || folder.is_null() || group.is_null() {
        return std::ptr::null_mut();
    }
    let text = |p: *const c_char| CStr::from_ptr(p).to_str().map_err(|e| e.to_string());
    let shaped = (|| -> Result<String, String> {
        let law: law::Law = serde_json::from_str(text(law)?).map_err(|e| format!("its law: {e}"))?;
        let header = body::Header::load(std::path::Path::new(text(folder)?))?;
        let group: law::Group = serde_json::from_str(text(group)?).map_err(|e| format!("its group: {e}"))?;
        let spec = law::Shaper { law, header }.shape(&group)?;
        serde_json::to_string(&spec).map_err(|e| e.to_string())
    })();
    match shaped.and_then(|s| std::ffi::CString::new(s).map_err(|e| e.to_string())) {
        Ok(s) => s.into_raw(),
        Err(e) => {
            eprintln!("openwind_shape: {e}");
            std::ptr::null_mut()
        }
    }
}

/// # Safety
/// `s` must be a string the engine returned, freed once.
#[no_mangle]
pub unsafe extern "C" fn openwind_text_free(s: *mut c_char) {
    if !s.is_null() {
        drop(std::ffi::CString::from_raw(s));
    }
}
