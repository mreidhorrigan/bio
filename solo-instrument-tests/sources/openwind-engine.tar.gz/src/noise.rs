//! The noise of a player's actions, for the winds' engine: public/shared/noise.js in Rust, step for step, as
//! native/strings-model/musebots-noise.h is in C++ -- the same counter-based source (lowbias32 over the piece's seed, a
//! path's FNV-1a and an index), so its uniforms are the same bits; the same Box-Muller deviates and the same shaping
//! (bilinear one-poles an octave apart weighted by the power law, and a tremor's resonance), so its streams agree with the
//! page's to the last digits of each library's log, cos and pow (test/noise.test.mjs builds examples/noise-parity.rs
//! against noise.js). noise.js says why and how, with its sources; a path is ASCII. The tree of temperatures is the
//! page's: the engine is given each parameter's temperature as a number.

use std::f64::consts::PI;

pub fn lowbias32(mut x: u32) -> u32 {
    x ^= x >> 16;
    x = x.wrapping_mul(0x7feb352d);
    x ^= x >> 15;
    x = x.wrapping_mul(0x846ca68b);
    x ^ (x >> 16)
}

/// FNV-1a over a text's bytes (public/shared/fnv1a.js, whose code units they are for ASCII).
pub fn fnv1a(text: &str) -> u32 {
    text.bytes().fold(2166136261u32, |h, c| (h ^ c as u32).wrapping_mul(16777619))
}

pub fn noise_key(path: &str) -> u32 {
    fnv1a(path)
}

pub fn noise_base(seed: u32, key: u32) -> u32 {
    lowbias32(lowbias32(seed) ^ key)
}

fn word(base: u32, c: u64) -> u32 {
    lowbias32(lowbias32(base ^ (c >> 32) as u32) ^ lowbias32(c as u32))
}

/// Uniform in (0, 1) at an index: 52 bits and a half, every step exact.
pub fn uniform_at(base: u32, index: u64, sub: u64) -> f64 {
    let c = index.wrapping_mul(4).wrapping_add(sub * 2);
    (word(base, c) as f64 * 1048576.0 + (word(base, c.wrapping_add(1)) >> 12) as f64 + 0.5) / 4503599627370496.0
}

pub fn normal_at(base: u32, index: u64) -> f64 {
    (-2.0 * uniform_at(base, index, 0).ln()).sqrt() * (2.0 * PI * uniform_at(base, index, 1)).cos()
}

/// A profile: its power falling as 1/f^beta from `low` to `high` (Hz, or cycles an event), and a tremor at `tremor_hz` of
/// bandwidth tremor_hz/tremor_q carrying `tremor_share` of the variance (none where its share is 0).
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct Profile {
    pub beta: f64,
    pub low: f64,
    pub high: f64,
    pub tremor_hz: f64,
    pub tremor_q: f64,
    pub tremor_share: f64,
}

#[derive(Clone, Copy, Debug)]
struct Section {
    k: usize,
    a: f64,
    weight: f64,
    variance: f64,
}

#[derive(Clone, Debug, Default)]
struct Shape {
    sections: Vec<Section>,
    power: f64,
    share: f64,
    tremor: bool,
    p1: f64,
    p2: f64,
    variance: f64,
    rho: f64,
}

/// A profile's sections at `rate` (noise.js shaping). -> why not, where its band, slope or tremor is not one.
fn shaping(p: &Profile, rate: f64) -> Result<Shape, String> {
    if !(rate > 0.0) {
        return Err(format!("noise rate {rate}"));
    }
    if !(p.low > 0.0 && p.high >= p.low && p.high < rate / 2.0) {
        return Err(format!("noise band {}-{} at rate {rate} (0 < low <= high < rate/2)", p.low, p.high));
    }
    if !(p.beta >= 0.0 && p.beta <= 2.0) {
        return Err(format!("noise beta {} (0 to 2)", p.beta));
    }
    let mut corners = Vec::new();
    let mut f = p.low;
    while f < p.high * (1.0 - 1e-9) {
        corners.push(f);
        f *= 2.0;
    }
    corners.push(p.high);
    let n = corners.len();
    let span = |k: usize| (corners[k + 1] / corners[k]).ln();
    let mut s = Shape::default();
    for (k, &f) in corners.iter().enumerate() {
        let w = if p.beta <= 0.0 {
            if k == n - 1 { 1.0 } else { 0.0 }
        } else if p.beta >= 2.0 {
            if k == 0 { 1.0 } else { 0.0 }
        } else {
            let mut w = f.powf(-p.beta) * ((if k > 0 { span(k - 1) } else { 0.0 }) + (if k < n - 1 { span(k) } else { 0.0 })) / 2.0;
            if k == 0 {
                w += p.low.powf(-p.beta) / (2.0 - p.beta);
            }
            if k == n - 1 {
                w += p.high.powf(-p.beta) / p.beta;
            }
            w
        };
        if !(w > 0.0) {
            continue;
        }
        let t = (PI * f / rate).tan();
        let a = (1.0 - t) / (1.0 + t);
        s.sections.push(Section { k, a, weight: w, variance: w * (1.0 - a) / 2.0 });
    }
    s.power = s.sections.iter().map(|x| x.variance).sum();
    if p.tremor_share > 0.0 {
        if !(p.tremor_share <= 1.0 && p.tremor_hz > 0.0 && p.tremor_hz < rate / 2.0 && p.tremor_q > 0.0) {
            return Err(format!("noise tremor {} Hz, q {}, share {}", p.tremor_hz, p.tremor_q, p.tremor_share));
        }
        let theta = 2.0 * PI * p.tremor_hz / rate;
        let r = (-PI * (p.tremor_hz / p.tremor_q) / rate).exp();
        s.tremor = true;
        s.share = p.tremor_share;
        s.p1 = 2.0 * r * theta.cos();
        s.p2 = -r * r;
        s.variance = (1.0 - s.p2) / ((1.0 + s.p2) * ((1.0 - s.p2) * (1.0 - s.p2) - s.p1 * s.p1));
        s.rho = s.p1 / (1.0 - s.p2);
    }
    Ok(s)
}

/// A stream of shaped noise, unit variance from its first draw: next() its next deviate, skip(n) past n as drawn.
#[derive(Clone, Debug)]
pub struct NoiseStream {
    pub index: u64,
    shape: Shape,
    bases: Vec<u32>,
    lasts: Vec<f64>,
    states: Vec<f64>,
    gains: Vec<f64>,
    tremor_base: u32,
    y1: f64,
    y2: f64,
}

impl NoiseStream {
    pub fn new(seed: u32, path: &str, rate: f64, profile: &Profile) -> Result<NoiseStream, String> {
        let shape = shaping(profile, rate)?;
        let start = noise_base(seed, noise_key(&format!("{path}#start")));
        let (mut bases, mut lasts, mut states, mut gains) = (vec![], vec![], vec![], vec![]);
        for s in &shape.sections {
            bases.push(noise_base(seed, noise_key(&format!("{path}#{}", s.k))));
            let last = normal_at(start, 2 * s.k as u64 + 1);
            lasts.push(last);
            states.push((1.0 - s.a) / 2.0 * last + ((1.0 - s.a * s.a) / 4.0).sqrt() * normal_at(start, 2 * s.k as u64));
            gains.push((s.weight / shape.power).sqrt());
        }
        let (mut tremor_base, mut y1, mut y2) = (0, 0.0, 0.0);
        if shape.tremor {
            tremor_base = noise_base(seed, noise_key(&format!("{path}#tremor")));
            y2 = shape.variance.sqrt() * normal_at(start, 1000);
            y1 = shape.rho * y2 + (shape.variance * (1.0 - shape.rho * shape.rho)).sqrt() * normal_at(start, 1001);
        }
        Ok(NoiseStream { index: 0, shape, bases, lasts, states, gains, tremor_base, y1, y2 })
    }

    #[allow(clippy::should_implement_trait)]
    pub fn next(&mut self) -> f64 {
        let i = self.index;
        self.index += 1;
        let mut power = 0.0;
        for k in 0..self.shape.sections.len() {
            let a = self.shape.sections[k].a;
            let x = normal_at(self.bases[k], i);
            self.states[k] = a * self.states[k] + (1.0 - a) / 2.0 * (x + self.lasts[k]);
            self.lasts[k] = x;
            power += self.gains[k] * self.states[k];
        }
        if !self.shape.tremor {
            return power;
        }
        let y = self.shape.p1 * self.y1 + self.shape.p2 * self.y2 + normal_at(self.tremor_base, i);
        self.y2 = self.y1;
        self.y1 = y;
        (1.0 - self.shape.share).sqrt() * power + self.shape.share.sqrt() * y / self.shape.variance.sqrt()
    }

    pub fn skip(&mut self, n: u64) -> &mut Self {
        for _ in 0..n {
            self.next();
        }
        self
    }
}

/// A value as a player gives it (noise.js played).
pub fn played(value: f64, deviate: f64, sd: f64, relative: bool, temperature: f64) -> f64 {
    let n = deviate.clamp(-4.0, 4.0) * sd * temperature;
    if relative { value * (1.0 + n) } else { value + n }
}

/// A path's fixed dither (noise.js dither).
pub fn dither(seed: u32, path: &str, sd: f64, temperature: f64) -> f64 {
    normal_at(noise_base(seed, noise_key(path)), 0).clamp(-4.0, 4.0) * sd * temperature
}

/// A seed given as text, its base for `key` (noise.js noiseBase's).
pub fn noise_base_text(seed: &str, key: u32) -> u32 {
    lowbias32(lowbias32(fnv1a(seed)) ^ key)
}

/// A wind player's noise as the engine plays it (stream.rs), as a string player's is (native/strings-model/
/// musebots-player-noise.h; research/NOISE_AND_TEMPERATURE.md): its breath's pressure and its lips' tension, each a
/// stream of its own, a share of what is asked -- the breath's of its mouth's pressure, the lips' of their tension. Each
/// stream is drawn every EVERY samples of its sound's rate, at its index there counted from the part's start (so a part
/// is the same however its sound is asked for, and a stream asked late is skipped to where it would have stood), and its
/// value moved to over the next EVERY: the value at a native step its draw before's, moved along the line to its own. Its
/// paths the player's own, `breath/pressure` and `lips/tension`, seeded from the player's seed folded to 32 bits (its low
/// word xor its high). Where none is asked and none is moving, it moves nothing: the exact machine, sample for sample.
#[derive(Clone, Debug)]
pub struct PlayerNoise {
    key: u32,
    every: u64,
    rate: f64,
    kinds: [Kind; 2],
}

/// What a wind player's noise moves: its breath's pressure, or its lips' tension.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum What {
    Breath = 0,
    Lips = 1,
}

impl What {
    pub fn named(name: &str) -> Option<What> {
        match name {
            "breath" => Some(What::Breath),
            "lips" => Some(What::Lips),
            _ => None,
        }
    }
    fn path(self) -> &'static str {
        match self {
            What::Breath => "breath/pressure",
            What::Lips => "lips/tension",
        }
    }
}

#[derive(Clone, Debug, Default)]
struct Kind {
    profile: Option<Profile>,
    size: f64,
    stream: Option<NoiseStream>,
    // (Its values drawn, by their index, the last few kept: a step asks its draw's and the one before's.)
    drawn: Vec<(u64, f64)>,
}

impl PlayerNoise {
    /// Samples of its sound between two draws, as the strings' (musebots-player-noise.h EVERY).
    pub const EVERY: u64 = 64;

    /// A player's noise on an engine of `rate` Hz sound, `ratio` native steps a sample of it; none asked.
    pub fn new(rate: f64, ratio: usize) -> PlayerNoise {
        PlayerNoise { key: 0, every: PlayerNoise::EVERY * ratio as u64, rate: rate / PlayerNoise::EVERY as f64, kinds: Default::default() }
    }

    /// Its player's seed: every stream begun again from it.
    pub fn seed(&mut self, seed: u64) {
        self.key = (seed ^ (seed >> 32)) as u32;
        for k in &mut self.kinds {
            k.stream = None;
            k.drawn.clear();
        }
    }

    /// One kind asked: its deviation at temperature 1 (`sd`, a share of what is asked), its temperature and its
    /// profile (Hz). -> why not, where they are not one.
    pub fn set(&mut self, what: What, sd: f64, temperature: f64, profile: Profile) -> Result<(), String> {
        if !(sd >= 0.0 && sd.is_finite() && temperature >= 0.0 && temperature.is_finite()) {
            return Err(format!("a noise's deviation and temperature of none or more, not {sd} and {temperature}"));
        }
        shaping(&profile, self.rate)?;
        let k = &mut self.kinds[what as usize];
        if k.profile != Some(profile) {
            k.stream = None;
            k.drawn.clear();
        }
        k.profile = Some(profile);
        k.size = sd * temperature;
        Ok(())
    }

    /// Whether it moves anything from native step `n` on (or the step before, a jet's derivative's): a stream asked, or a
    /// value it drew that a step from there moves between not the exact machine's.
    pub fn active(&self, n: u64) -> bool {
        let first = (n.saturating_sub(1) / self.every).saturating_sub(1);
        self.kinds.iter().any(|k| k.size > 0.0 || k.drawn.iter().any(|&(i, v)| i >= first && v != 1.0))
    }

    /// Its share of what is asked of `what` at native step `n` (1 none).
    pub fn at(&mut self, what: What, n: u64) -> f64 {
        let (j, into) = (n / self.every, n % self.every);
        // (The draw before first, the stream asked late skipped once.)
        let from = if j == 0 { 1.0 } else { self.value(what, j - 1) };
        let to = self.value(what, j);
        from + (to - from) * into as f64 / self.every as f64
    }

    // (Its value at draw `index`: drawn where it was not, the stream made where it is wanted and skipped to there.)
    fn value(&mut self, what: What, index: u64) -> f64 {
        let (key, rate) = (self.key, self.rate);
        let k = &mut self.kinds[what as usize];
        if let Some(&(_, v)) = k.drawn.iter().find(|&&(i, _)| i == index) {
            return v;
        }
        let v = match k.profile {
            Some(profile) if k.size > 0.0 => {
                if k.stream.as_ref().is_some_and(|s| s.index > index) {
                    k.stream = None;
                }
                let stream = k.stream.get_or_insert_with(|| NoiseStream::new(key, what.path(), rate, &profile).expect("its profile shaped when it was set"));
                let behind = index - stream.index;
                played(1.0, stream.skip(behind).next(), k.size, true, 1.0)
            }
            _ => {
                k.stream = None;
                1.0
            }
        };
        if k.drawn.len() >= 4 {
            k.drawn.remove(0);
        }
        k.drawn.push((index, v));
        v
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const ACTION: Profile = Profile { beta: 1.0, low: 0.05, high: 20.0, tremor_hz: 10.0, tremor_q: 2.0, tremor_share: 0.2 };

    // (A player's noise at 48 kHz, its native rate eight times that: a draw every 512 native steps.)
    fn player(size: f64) -> PlayerNoise {
        let mut p = PlayerNoise::new(48000.0, 8);
        p.seed(0x1234_5678_9abc_def0);
        p.set(What::Breath, size, 1.0, ACTION).unwrap();
        p
    }

    #[test]
    fn none_asked_moves_nothing() {
        let mut p = PlayerNoise::new(48000.0, 8);
        assert!(!p.active(0));
        assert!((0..5000).all(|n| p.at(What::Breath, n) == 1.0 && p.at(What::Lips, n) == 1.0));
    }

    #[test]
    fn its_draws_the_stream_as_played_and_the_line_between() {
        let mut p = player(0.015);
        let every = 64 * 8;
        let mut stream = NoiseStream::new((0x1234_5678_9abc_def0u64 ^ (0x1234_5678_9abc_def0u64 >> 32)) as u32, "breath/pressure", 750.0, &ACTION).unwrap();
        let drawn: Vec<f64> = (0..6).map(|_| played(1.0, stream.next(), 0.015, true, 1.0)).collect();
        // (From the exact machine's at its start to its first draw's, then each draw's to the next.)
        assert_eq!(p.at(What::Breath, 0), 1.0);
        for j in 1..6u64 {
            assert_eq!(p.at(What::Breath, j * every), drawn[j as usize - 1]);
            let half = p.at(What::Breath, j * every + every / 2);
            assert!((half - (drawn[j as usize - 1] + drawn[j as usize]) / 2.0).abs() < 1e-15);
        }
        assert!(drawn.iter().all(|v| (v - 1.0).abs() < 0.06) && drawn.iter().any(|v| *v != 1.0));
    }

    #[test]
    fn the_same_however_it_is_asked() {
        let (mut a, mut b) = (player(0.015), player(0.015));
        let steps: Vec<f64> = (0..20000).map(|n| a.at(What::Breath, n)).collect();
        // (Asked late, and a step back each time, as a jet's derivative asks it.)
        for n in (9000..20000).step_by(7) {
            assert_eq!(b.at(What::Breath, n), steps[n as usize]);
            assert_eq!(b.at(What::Breath, n - 1), steps[n as usize - 1]);
        }
    }

    #[test]
    fn its_temperature_scales_it_and_none_returns_to_the_machine() {
        let (mut a, mut b) = (player(0.015), player(0.0));
        b.set(What::Breath, 0.015, 2.0, ACTION).unwrap();
        let n = 512 * 40;
        assert!(((b.at(What::Breath, n) - 1.0) / (a.at(What::Breath, n) - 1.0) - 2.0).abs() < 1e-9);
        a.set(What::Breath, 0.015, 0.0, ACTION).unwrap();
        // (Moved back over a draw's steps, then none.)
        let back: Vec<f64> = (n..n + 4 * 512).map(|k| a.at(What::Breath, k)).collect();
        assert!(back.iter().skip(2 * 512).all(|v| *v == 1.0));
        assert!(a.active(n + 512) && !a.active(n + 4 * 512));
    }

    #[test]
    fn a_profile_not_one_refused() {
        let mut p = PlayerNoise::new(48000.0, 8);
        assert!(p.set(What::Lips, 0.01, 1.0, Profile { high: 400.0, ..ACTION }).is_err());
        assert!(p.set(What::Lips, -0.01, 1.0, ACTION).is_err());
        assert!(p.set(What::Lips, 0.01, 1.0, Profile { beta: 3.0, ..ACTION }).is_err());
    }
}
