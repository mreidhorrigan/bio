//! A body saved for the engine (render/synthesis/workers/openwind_bodies.py save_body; research/OPENWIND_REALTIME_PLAN.md,
//! design 3): its laid-out arrays (I.bin, int64; D.bin, float64; little-endian) and body.json -- its control columns, its
//! holes in their fingerings' order, its step, the constants its controls are made from, and the filter its sound is
//! brought to 48 kHz by -- read once, and played (kernel.rs Player) for as long as it is played.

use crate::kernel::Player;
use serde::Deserialize;
use std::path::Path;

/// A reed's kind and its entry (controls.rs Reed).
#[derive(Deserialize, Clone, Debug)]
pub struct ReedHeader {
    pub kind: String,
    pub zc: f64,
    pub rho: f64,
}

/// A flute's jet and window as the body holds them (controls.rs Flute's constants).
#[derive(Deserialize, Clone, Debug)]
pub struct FluteHeader {
    pub held: [f64; 5],
    pub celerity: f64,
    pub window: f64,
    pub aspect: Option<f64>,
    pub profile: Option<f64>,
    pub gain: f64,
    pub loss_mag: f64,
    pub section: f64,
    pub convection: f64,
    pub edge_offset: f64,
    pub channel_height: f64,
    pub width: f64,
    pub edge_angle: f64,
    pub wall_thickness: f64,
    pub inertance: Option<(f64, f64)>,
    /// Its jet drive's dipole: Verge et al.'s (None, "verge") or its flow sources on the convected jet ("twopoint";
    /// openwind_worker.py jet_dipole).
    #[serde(default)]
    pub dipole: Option<String>,
}

/// A trombone's slide as its body holds it (render/synthesis/tools/save_slide_body.py): the pipe of its bore its slide
/// draws out -- its elements, each its group and its place in the group; its two ends, by their place among the body's
/// ends; the connectors joining them to the bore, each a discontinuity's mass (none for a simple junction) -- laid out
/// at its first position, `length` m long, drawn out up to `most` m more, its connectors' step `dt` (OpenWInD's, scaled).
/// The kernel stretches it in place (kernel.rs Player::stretch).
#[derive(Deserialize, Clone, Debug)]
pub struct SlideHeader {
    pub elements: Vec<[usize; 2]>,
    pub ends: [usize; 2],
    pub joins: Vec<JoinHeader>,
    pub dt: f64,
    pub length: f64,
    pub most: f64,
}

/// A connector at a slide's end: its place among the body's connectors, and its discontinuity's mass.
#[derive(Deserialize, Clone, Debug)]
pub struct JoinHeader {
    pub conn: usize,
    #[serde(default)]
    pub mass: f64,
}

/// scipy's resample_poly filter from the native rate down to `rate`: its taps (firwin, Kaiser 5), `down` the ratio.
#[derive(Deserialize, Clone, Debug)]
pub struct Resample {
    pub down: usize,
    #[serde(rename = "halfLength")]
    pub half_length: usize,
    pub taps: Vec<f64>,
}

#[derive(Deserialize, Clone, Debug)]
pub struct Header {
    pub model: String,
    pub losses: String,
    pub mesh: String,
    pub order: u32,
    /// Its bore stepped in singles: its scheme's (render/synthesis/realtime-schemes.json), its saver's to say.
    #[serde(default)]
    pub single: bool,
    pub ring: usize,
    pub rate: f64,
    pub ratio: usize,
    pub half: f64,
    pub ni: usize,
    pub nd: usize,
    pub outputs: usize,
    pub columns: Vec<Vec<serde_json::Value>>,
    pub holes: Vec<String>,
    pub reed: Option<ReedHeader>,
    pub flute: Option<FluteHeader>,
    pub resample: Resample,
    /// Its slide, where it has one (a trombone's).
    #[serde(default)]
    pub slide: Option<SlideHeader>,
}

/// A saved body: its header and its arrays.
pub struct Body {
    pub header: Header,
    pub i: Vec<i64>,
    pub d: Vec<f64>,
}

impl Header {
    /// The header of the body saved in `folder`.
    pub fn load(folder: &Path) -> Result<Header, String> {
        let path = folder.join("body.json");
        let text = std::fs::read(&path).map_err(|e| format!("{}: {e}", path.display()))?;
        serde_json::from_slice(&text).map_err(|e| format!("{}: {e}", path.display()))
    }
}

impl Body {
    /// The body saved in `folder`. -> its reason where it cannot be read.
    pub fn load(folder: &Path) -> Result<Body, String> {
        let read = |name: &str| std::fs::read(folder.join(name)).map_err(|e| format!("{}: {e}", folder.join(name).display()));
        Body::from_bytes(Header::load(folder)?, &read("I.bin")?, &read("D.bin")?).map_err(|e| format!("{}: {e}", folder.display()))
    }

    /// The body its header and its arrays' bytes (I.bin, D.bin) make: a body saved and fetched, as a page has it.
    pub fn from_bytes(header: Header, ib: &[u8], db: &[u8]) -> Result<Body, String> {
        if ib.len() != 8 * header.ni || db.len() != 8 * header.nd {
            return Err("its arrays are not the length its header says".into());
        }
        let i = ib.chunks_exact(8).map(|b| i64::from_le_bytes(b.try_into().unwrap())).collect();
        let d = db.chunks_exact(8).map(|b| f64::from_le_bytes(b.try_into().unwrap())).collect();
        Ok(Body { header, i, d })
    }

    /// A player of it, from rest, its bore in singles where `single`; its slide, where it has one, at its first position.
    pub fn player(&self, single: bool) -> Result<Player, String> {
        self.player_threaded(single, 1)
    }

    /// The same, stepped on `threads` cores where its bore splits so (kernel.rs Player::with_threads).
    pub fn player_threaded(&self, single: bool, threads: usize) -> Result<Player, String> {
        let mut player = Player::with_threads(self.i.clone(), self.d.clone(), single, threads)
            .ok_or_else(|| format!("the {}'s body's places lie outside its arrays", self.header.model))?;
        if let Some(slide) = &self.header.slide {
            player.slide_on(slide).map_err(|e| format!("the {}'s slide: {e}", self.header.model))?;
        }
        Ok(player)
    }
}
