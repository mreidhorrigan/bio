//! Each note's own start, and how far each of its body's makers' points moves it (the owner, 10 November 2026: "Yes,
//! proceed"; "yes, I am OKing the full solution here"; research/OPENWIND_REALTIME_PLAN.md, design 8): what steers a
//! body's tuning by its notes as they are heard (native/openwind/tune-body.mjs). Computed on the engine's own
//! equations, nothing played: the tube's one step taken small about rest (kernel.rs Player::bore_map) and its reed's at
//! its rest (starts.rs rested) -- the equation starts.rs grows solves, K(z) / q(z) = 1.
//! - Its own resonance: of the peaks of the tube's answer about the pitch asked, the nearest it, and that peak's pole
//!   (Newton's steps on 1 / G). The start's root is then followed from the tube alone to the tube with its reed, the
//!   reed's answer let in by shares (K_theta = lambda + theta (K - lambda): at none the equation's root is the tube's
//!   pole, at the whole the start's own), each share's root begun from the last's -- so that the root found is the one
//!   that resonance becomes, never another's (KNOWN_ISSUES MB-WIND-008: Newton's steps from a pitch ended on another
//!   resonance's root, or on none's). Where a root found before is given and its steps stay near it, followed from it.
//! - Each of Newton's steps exact: the tube's answer's slope in z is -(c (z - B)^-1) ((z - B)^-1 b), the product of its
//!   two solves -- the same two solves, at the root, that give every point's rate.
//! - Each point's rate: its moved body's own step applied to the root's solve (kernel.rs Player::bore_applied, the
//!   player remade to that body in place, its holes as the note's row has them: Player::remade -- KNOWN_ISSUES
//!   MB-WIND-006, a hole the note closes read open), less the body's own; so the tube's answer's move,
//!   v (B' - B) u + v (b' - b), and the root's by the equation's own slopes. No orbit and no search: two solves a
//!   note, three steps of the engine a point.
//! Its reed's resting opening is the body's as it stands: the steady flow's pressure in the tube, G(1), which a point's
//! move leaves it by, is taken as unmoved.
use crate::body::Body;
use crate::kernel::{Player, ReedConstants};
use crate::sparse::{Banded, C};
use crate::starts::{rested, Reed, Rest, Tube};
use crate::tract::{Resonance, Tract};
use serde::{Deserialize, Serialize};

/// A note asked: its row (its fingering, its reed as its player holds it, its breath), its tract's resonances (its
/// tract as it stands, where none), the pitch its own resonance is sought about (Hz), and a root found before
/// ([growth 1/s, pitch Hz]: followed from it where its steps stay near).
#[derive(Deserialize, Clone, Debug)]
pub struct StartNote {
    pub row: Vec<f64>,
    #[serde(default)]
    pub tract: Option<Vec<Resonance>>,
    pub hz: f64,
    #[serde(default)]
    pub from: Option<[f64; 2]>,
}

/// A note's own start: its pitch (Hz) and its growth (its amplitude's rate, 1/s: below nothing, it dies), none where it
/// has none (`why`); its tube's own resonance (its pole's pitch, Hz); each point's rate on its pitch (cents for a move of
/// one of that point's units) and on its growth (1/s for one); what is left of its equation there; the solves it took,
/// and the seconds.
#[derive(Serialize, Clone, Debug, Default)]
pub struct Rooted {
    pub hz: Option<f64>,
    pub growth: Option<f64>,
    pub pole: Option<f64>,
    pub cents: Vec<f64>,
    pub growths: Vec<f64>,
    pub left: f64,
    pub solves: usize,
    pub why: Option<String>,
    pub seconds: f64,
}

// (The bore's map nudged as starts.rs nudges it, and its reed's resting opening halved as often; its tube's peak sought
// ABOUT cents either side of the pitch asked, every GRID; a root closed where Newton's step is under CLOSED, STEPS at
// most; the reed's answer let in a share SHARE at a time, halved to LEAST where a share's root does not close or moves
// more than FAR cents -- as far, too, as a root may stand from the one it is followed from; z nudged SLOPE for the
// slopes of the reed's and the tract's answers, which are arithmetic.)
const NUDGE: f64 = 1e-6;
const HALVINGS: usize = 64;
const ABOUT: f64 = 300.0;
const GRID: f64 = 50.0;
const CLOSED: f64 = 1e-13;
const STEPS: usize = 40;
const SHARE: f64 = 0.25;
const LEAST: f64 = 1.0 / 64.0;
const FAR: f64 = 100.0;
const SLOPE: f64 = 1e-6;

impl Tube {
    /// u = (z - B)^-1 b and v = c (z - B)^-1, each over the doubles a step moves, in their order, and G = c u: the
    /// tube's answer at z with what its slopes are made of -- its slope in z, -v u; in its own step, v dB u.
    pub(crate) fn solved_both(&self, z: C) -> Result<(Vec<C>, Vec<C>, C), String> {
        let (mut m, mut t) = (Banded::new(self.n, self.kl, self.ku), Banded::new(self.n, self.ku, self.kl));
        for i in 0..self.n {
            m.add(self.position[i], self.position[i], z);
            t.add(self.position[i], self.position[i], z);
        }
        for &(i, j, v) in &self.entries {
            m.add(self.position[i], self.position[j], C::new(-v, 0.0));
            t.add(self.position[j], self.position[i], C::new(-v, 0.0));
        }
        m.lu()?;
        t.lu()?;
        let placed = |of: &[(usize, f64)]| {
            let mut rhs = vec![C::default(); self.n];
            for &(i, v) in of {
                rhs[self.position[i]] = C::new(v, 0.0);
            }
            rhs
        };
        let (x, y) = (m.solve(&placed(&self.b)), t.solve(&placed(&self.c)));
        let u: Vec<C> = (0..self.n).map(|i| x[self.position[i]]).collect();
        let v: Vec<C> = (0..self.n).map(|i| y[self.position[i]]).collect();
        let g = self.c.iter().fold(C::default(), |s, &(i, c)| s + u[i] * c);
        Ok((u, v, g))
    }
}

/// The start's equation at a row: its tube, its reed at rest, its tract, and the constants between them.
struct Equation<'a> {
    tube: &'a Tube,
    rest: Rest,
    tract: Option<Tract>,
    lambda: f64,
    sp: f64,
    flowscale: f64,
    scale: f64,
}

/// The equation at a z: what is left of it (e), its slopes in z and in the tube's answer, and the tube's two solves.
struct At {
    e: C,
    de_dz: C,
    de_dg: C,
    u: Vec<C>,
    v: Vec<C>,
}

impl Equation<'_> {
    /// The tract's answer as the reed reads it, a step late: z^-1 h(z); nothing without one.
    fn late(&self, z: C) -> C {
        self.tract.as_ref().map_or(C::default(), |t| {
            let (re, im) = t.answer_at(z.re, z.im);
            z.inv() * C::new(re, im)
        })
    }

    /// At z, its reed's answer let in by `theta` (1: its own): E = (K_theta / lambda) (1 - 1 / Lt) - 1, Lt what the tube
    /// and the tract take, (G sp - z^-1 h flowscale) lambda / (zc sf) -- starts.rs grown's K / q - 1 at the whole.
    fn at(&self, z: C, theta: f64) -> Result<At, String> {
        let (u, v, g) = self.tube.solved(z)?;
        let dg = -u.iter().zip(&v).fold(C::default(), |s, (a, b)| s + *a * *b);
        let d = C::new(SLOPE, 0.0);
        let slope = |f: &dyn Fn(C) -> C| (f(z + d) - f(z - d)) / (d * 2.0);
        let (one, lambda) = (C::new(1.0, 0.0), C::new(self.lambda, 0.0));
        let k = lambda + (self.rest.k(z) - lambda) * theta;
        let dk = slope(&|z| self.rest.k(z)) * theta;
        let lt = (g * self.sp - self.late(z) * self.flowscale) * self.scale;
        let dlt = (dg * self.sp - slope(&|z| self.late(z)) * self.flowscale) * self.scale;
        let taken = one - lt.inv();
        Ok(At {
            e: k / lambda * taken - one,
            de_dz: dk / lambda * taken + k / lambda * dlt / (lt * lt),
            de_dg: k / lambda * (self.sp * self.scale) / (lt * lt),
            u,
            v,
        })
    }

    /// The equation's root at `theta` by Newton's steps from `z` -> (the root, the equation there, the steps taken).
    fn root(&self, mut z: C, theta: f64) -> Result<(C, At, usize), String> {
        for step in 1..=STEPS {
            let at = self.at(z, theta)?;
            let dz = at.e / at.de_dz;
            if !(dz.re.is_finite() && dz.im.is_finite()) {
                return Err("its equation's slope is none at its root's step".into());
            }
            z = z - dz;
            if dz.abs() <= CLOSED {
                return Ok((z, self.at(z, theta)?, step + 1));
            }
        }
        Err(format!("its root's steps did not close in {STEPS}"))
    }
}

fn cents(a: f64, b: f64) -> f64 {
    1200.0 * (a / b).log2()
}

/// The reed at rest at the row's breath `gamma` (a share of its closing pressure), `g1` the pressure a steady flow
/// holds in its tube: its resting opening the one whose steady flow holds that breath, halved between shut and open as
/// starts.rs grown halves it -> its rest there, or why it has none.
fn resting(reed: &Reed, k: &ReedConstants, gamma: f64, g1: f64) -> Result<Rest, String> {
    let gamma_of = |rest: &Rest| g1 * rest.w_over * k.sp / (k.zc * k.sf) - rest.pi_less_gamma;
    let shut = gamma_of(&rested(reed, k, 0.0).ok_or("its reed has no rest shut")?);
    if !(gamma > 0.0) {
        return Err("no breath: its reed rests open, nothing flowing".into());
    }
    if gamma >= shut {
        return Err("its reed rests shut at that breath".into());
    }
    let (mut lo, mut hi) = (0.0, 1.0);
    for _ in 0..HALVINGS {
        let m = 0.5 * (lo + hi);
        match rested(reed, k, m) {
            Some(r) if gamma_of(&r) >= gamma => lo = m,
            _ => hi = m,
        }
    }
    rested(reed, k, 0.5 * (lo + hi)).ok_or_else(|| "its reed has no rest at its breath".into())
}

/// The pole of the tube's answer that is its resonance nearest `hz`: its answer's size read every GRID cents within
/// ABOUT of it on the unit circle, the peak nearest the pitch (the taller of two as near), and Newton's steps on 1 / G
/// from there, z + G / G' -> (the pole, the solves it took).
fn pole_near(tube: &Tube, hz: f64, rate: f64) -> Result<(C, usize), String> {
    let angle = |f: f64| 2.0 * std::f64::consts::PI * f / rate;
    let half = (ABOUT / GRID).round() as i64;
    let at: Vec<f64> = (-half..=half).map(|k| hz * (k as f64 * GRID / 1200.0).exp2()).collect();
    let size = at.iter().map(|&f| tube.answered(C::polar(1.0, angle(f))).map(|g| g.abs())).collect::<Result<Vec<f64>, String>>()?;
    let mut solves = size.len();
    let peak = (1..size.len() - 1)
        .filter(|&i| size[i] > size[i - 1] && size[i] >= size[i + 1])
        .min_by(|&a, &b| (a as i64 - half).abs().cmp(&(b as i64 - half).abs()).then(size[b].total_cmp(&size[a])))
        .ok_or_else(|| format!("its tube has no resonance within {ABOUT} c of {hz:.1} Hz"))?;
    let mut z = C::polar(1.0, angle(at[peak]));
    for _ in 0..STEPS {
        let (u, v, g) = tube.solved(z)?;
        solves += 2;
        let dg = -u.iter().zip(&v).fold(C::default(), |s, (a, b)| s + *a * *b);
        let dz = g / dg;
        if !(dz.re.is_finite() && dz.im.is_finite()) {
            return Err("its tube's answer's slope is none at its pole's step".into());
        }
        z = z + dz;
        if dz.abs() <= CLOSED {
            let found = z.arg() * rate / (2.0 * std::f64::consts::PI);
            if !(cents(found, at[peak]).abs() <= GRID) {
                return Err(format!("its pole at {found:.1} Hz, not its peak's at {:.1}", at[peak]));
            }
            return Ok((z, solves));
        }
    }
    Err(format!("its pole's steps did not close in {STEPS}"))
}

/// A note's own start on the body `player` plays -- `base`, its doubles as made, at rest -- and each point's rate on
/// it, from the body made with that point moved by its nudge (`moved`, `nudges`, each in its point's unit), each on the
/// base's layout. Its player in doubles, on one thread; its doubles and its tract as they stand on return are the
/// caller's to put back.
fn rooted(player: &mut Player, rate: f64, base: &Body, moved: &[Body], nudges: &[f64], note: &StartNote) -> Result<Rooted, String> {
    let place = player.reed_place()?;
    let k = player.reed_constants()?;
    if k.lips {
        return Err("lips' starts are not yet written out (their inward mode)".into());
    }
    let (col, row) = (place.columns, note.row.as_slice());
    if row.len() <= col + 8 {
        return Err("a row without its reed's columns".into());
    }
    if !(note.hz > 0.0 && note.hz < rate / 2.0) {
        return Err(format!("a pitch between nothing and half its rate ({} Hz)", rate / 2.0));
    }
    if let Some(rs) = &note.tract {
        let mut t = player.tract.take().unwrap_or_else(|| Tract::new(rate));
        t.set(rs.clone(), 0.0);
        player.tract = Some(t);
    }
    if let Some(t) = player.tract.as_mut() {
        t.settle();
    }
    // (Its holes as its row has them before its map is read: each one's radiation, set as its opening first moves, is
    // else counted among the doubles a step moves -- KNOWN_ISSUES MB-WIND-007.)
    player.bore_steady(row, 0.0, 1)?;
    let map = player.bore_map(row, 0.0, NUDGE, true)?;
    let moving = map.moving.clone();
    let tube = Tube::of(map);
    let (reed, gamma) = (Reed::of(row, col), row[col]);
    let g1 = tube.at(C::new(1.0, 0.0))?.re;
    let mut solves = 1;
    let lambda = k.zc / (k.alpha * k.simp);
    let eq = Equation { tube: &tube, rest: resting(&reed, &k, gamma, g1)?, tract: player.tract.clone(), lambda, sp: k.sp, flowscale: k.flowscale, scale: lambda / (k.zc * k.sf) };
    let pitch = |z: C| z.arg() * rate / (2.0 * std::f64::consts::PI);
    // (From a root found before, where its steps stay near it.)
    let followed = note.from.filter(|f| f[0].is_finite() && f[1] > 0.0 && f[1] < rate / 2.0).and_then(|[growth, f]| {
        let found = eq.root(C::polar((growth / rate).exp(), 2.0 * std::f64::consts::PI * f / rate), 1.0).ok()?;
        (cents(pitch(found.0), f).abs() <= FAR).then_some(found)
    });
    let mut pole = None;
    let (z, at) = match followed {
        Some((z, at, steps)) => {
            solves += 2 * steps;
            (z, at)
        }
        None => {
            let (mut z, taken) = pole_near(&tube, note.hz, rate)?;
            solves += taken;
            pole = Some(pitch(z));
            // (Its reed's answer let in by shares, each share's root begun from the last's.)
            let (mut theta, mut share, mut last) = (0.0, SHARE, None);
            while theta < 1.0 {
                let next = (theta + share).min(1.0);
                match eq.root(z, next) {
                    Ok((found, at, steps)) if cents(pitch(found), pitch(z)).abs() <= FAR => {
                        solves += 2 * steps;
                        (z, theta, last) = (found, next, Some(at));
                    }
                    _ if share / 2.0 >= LEAST => share /= 2.0,
                    _ => return Err(format!("its start's root is lost from its tube's resonance at {:.1} Hz, its reed's answer let in {theta:.3}", pitch(z))),
                }
            }
            (z, last.expect("a share taken"))
        }
    };
    let mut out = Rooted { hz: Some(pitch(z)), growth: Some(rate * z.abs().ln()), pole, left: at.e.abs(), ..Rooted::default() };
    // (Each point's rate: the engine's own step of the body as made and of each moved body, applied to the root's solve
    // and to a flow at its reed's end; the tube's answer's move for them, and the root's.)
    let (re, im): (Vec<f64>, Vec<f64>) = (at.u.iter().map(|c| c.re).collect(), at.u.iter().map(|c| c.im).collect());
    let none = vec![0.0; moving.len()];
    let stepped = |player: &mut Player| -> Result<(Vec<C>, Vec<f64>), String> {
        let (a, b) = (player.bore_applied(row, &moving, &re, 0.0)?, player.bore_applied(row, &moving, &im, 0.0)?);
        Ok((a.iter().zip(&b).map(|(x, y)| C::new(*x, *y)).collect(), player.bore_applied(row, &moving, &none, 1.0)?))
    };
    let (own_u, own_b) = stepped(player)?;
    for (body, &nudge) in moved.iter().zip(nudges) {
        player.remade(&body.i, &base.d, &body.d, body.header.points.as_ref())?;
        let there = stepped(player);
        player.remade(&base.i, &body.d, &base.d, base.header.points.as_ref())?;
        let (its_u, its_b) = there?;
        let dg = (0..moving.len()).fold(C::default(), |s, i| s + at.v[i] * (its_u[i] - own_u[i] + C::new(its_b[i] - own_b[i], 0.0)));
        let dz = -(at.de_dg * dg) / at.de_dz / z;
        out.cents.push(1200.0 / std::f64::consts::LN_2 * dz.im / z.arg() / nudge);
        out.growths.push(rate * dz.re / nudge);
    }
    out.solves = solves;
    Ok(out)
}

/// Each of `notes`' own start on the body `player` plays (`base`) and each point's rate on it (`moved`, `nudges`): a
/// note that has none says why, the rest are found all the same. Its player in doubles meanwhile, on one thread; its
/// doubles and its tract put back as they stood.
pub fn start_rates(player: &mut Player, rate: f64, base: &Body, moved: &[Body], nudges: &[f64], notes: &[StartNote]) -> Result<Vec<Rooted>, String> {
    if player.crewed() {
        return Err("its starts' rates are found on one core: a dial of one thread (--threads 1)".into());
    }
    if moved.len() != nudges.len() || nudges.iter().any(|n| !(*n != 0.0 && n.is_finite())) {
        return Err("each moved body, and the nudge it was made at".into());
    }
    let single = player.single();
    if single {
        player.in_doubles(true);
    }
    let (kept, tract) = (player.data().to_vec(), player.tract.clone());
    let found = notes
        .iter()
        .map(|note| {
            let since = std::time::Instant::now();
            let mut one = rooted(player, rate, base, moved, nudges, note).unwrap_or_else(|why| Rooted { why: Some(why), ..Rooted::default() });
            player.set_data(&kept);
            player.tract = tract.clone();
            one.seconds = since.elapsed().as_secs_f64();
            one
        })
        .collect();
    if single {
        player.in_doubles(false);
    }
    Ok(found)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::kernel::BoreMap;

    // (A tube of a few doubles, each moved by its neighbours and losing a little, driven at one end and read at the
    // other: its two solves give its answer either way, c u and v b, and its answer's slope in z, -v u, is its
    // difference's.)
    fn tube() -> Tube {
        let n = 12;
        let cols = (0..n)
            .map(|j| {
                let mut col = vec![(j, 0.9 - 0.01 * j as f64)];
                if j > 0 {
                    col.push((j - 1, 0.3));
                }
                if j + 1 < n {
                    col.push((j + 1, -0.25));
                }
                col
            })
            .collect();
        Tube::of(BoreMap { moving: (0..n).collect(), cols, b: vec![(0, 1.0), (1, 0.5)], c: vec![(n - 1, 2.0), (n - 2, -1.0)], off: 0.0 })
    }

    #[test]
    fn both_solves_give_the_answer_and_its_slope() {
        let tube = tube();
        let z = C::polar(0.98, 0.4);
        let (u, v, g) = tube.solved_both(z).unwrap();
        let direct = tube.at(z).unwrap();
        assert!((g - direct).abs() <= 1e-13 * direct.abs(), "{g:?} against {direct:?}");
        let other = tube.b.iter().fold(C::default(), |s, &(i, b)| s + v[i] * b);
        assert!((other - direct).abs() <= 1e-13 * direct.abs(), "v b {other:?} against {direct:?}");
        let slope = -u.iter().zip(&v).fold(C::default(), |s, (a, b)| s + *a * *b);
        let d = C::new(1e-6, 0.0);
        let differenced = (tube.at(z + d).unwrap() - tube.at(z - d).unwrap()) / (d * 2.0);
        assert!((slope - differenced).abs() <= 1e-8 * differenced.abs(), "{slope:?} against {differenced:?}");
    }

    // (Three resonances, each two doubles turned by its angle a step and keeping KEPT of themselves, driven and read
    // alike: the pole found from a pitch 40 c off the middle one's is the middle one's own, at its angle and its size.)
    #[test]
    fn the_pole_nearest_a_pitch() {
        const KEPT: f64 = 0.9995;
        let (rate, pitches) = (48_000.0, [440.0, 1320.0, 2210.0]);
        let mut cols = vec![];
        for (q, hz) in pitches.iter().enumerate() {
            let (sin, cos) = (2.0 * std::f64::consts::PI * hz / rate).sin_cos();
            cols.push(vec![(2 * q, KEPT * cos), (2 * q + 1, KEPT * sin)]);
            cols.push(vec![(2 * q, -KEPT * sin), (2 * q + 1, KEPT * cos)]);
        }
        let ends: Vec<(usize, f64)> = (0..pitches.len()).map(|q| (2 * q, 1.0)).collect();
        let tube = Tube::of(BoreMap { moving: (0..2 * pitches.len()).collect(), cols, b: ends.clone(), c: ends, off: 0.0 });
        let (z, _) = pole_near(&tube, pitches[1] * (40.0f64 / 1200.0).exp2(), rate).unwrap();
        let found = z.arg() * rate / (2.0 * std::f64::consts::PI);
        assert!(cents(found, pitches[1]).abs() < 1e-6, "its pole at {found} Hz, its resonance at {}", pitches[1]);
        assert!((z.abs() - KEPT).abs() < 1e-9, "its pole's size {}", z.abs());
    }
}

// ---- A note's starts kept on what they were solved on (native/openwind-tuner src/joint_run.rs; the owner, 14 November
// 2026, of the body and its player found at once: "Yes, optimize the fitting"), here at the file's end so that no line
// above it moves: its tube's map at its row read once for every start of its fingering, each start kept with its
// tube's two solves, and how far a move of its player or its reed moves it read off its equation there by arithmetic --
// such a move leaves its tube as it is. (Profiled that day on the clarinet: two thirds of a reading with its rates went
// to finding every start again -- its tube's map read and solved anew -- for each control moved either side: eighty
// starts a note, 0.36 s each.) ----

/// What every start of a note's fingering is a root of, at a row on the body its player plays: its tube's map there (its
/// holes as its row has them, as `rooted` reads it), its reed at rest at its breath, its tract's answer and the
/// constants between them.
pub struct Starts {
    tube: Tube,
    moving: Vec<usize>,
    row: Vec<f64>,
    col: usize,
    k: ReedConstants,
    g1: f64,
    rate: f64,
    rest: Rest,
    tract: Option<Tract>, flowed: Option<Flowed>,
}

/// A start found on them (Starts::root): its pitch (Hz) and its growth (its amplitude's rate, 1/s), its tube's own
/// resonance where it was sought from it (its pole's pitch, Hz), what is left of its equation there and the solves it
/// took; kept with its equation's slopes and its tube's two solves at it.
pub struct Root {
    pub hz: f64,
    pub growth: f64,
    pub pole: Option<f64>,
    pub left: f64,
    pub solves: usize,
    z: C,
    at: At,
}

/// A tube's own resonance nearest a pitch (Starts::pole): its pitch (Hz) and the solves it took.
pub struct Pole {
    pub hz: f64,
    pub solves: usize,
    z: C,
}

/// A move of what a start's equation is made of that leaves its tube as it is: its row (its reed's columns as its
/// player's lip holds them, its breath, its reed's flow), its tract's resonances, its reed's constants (its lay's
/// opening and its own spring's share, as another body holds them) -- each as it stands, where none.
#[derive(Clone, Copy, Default)]
pub struct Move<'a> {
    pub row: Option<&'a [f64]>,
    pub tract: Option<&'a [Resonance]>,
    pub reed: Option<ReedConstants>,
}

impl Equation<'_> {
    /// As `at`, its reed's answer whole, its tube's answer `g` and that answer's slope in z `dg` given: what is left of
    /// the equation at z and its slope in z, by arithmetic -- no solve of its tube.
    fn given(&self, z: C, g: C, dg: C) -> (C, C) {
        let d = C::new(SLOPE, 0.0);
        let slope = |f: &dyn Fn(C) -> C| (f(z + d) - f(z - d)) / (d * 2.0);
        let (one, lambda) = (C::new(1.0, 0.0), C::new(self.lambda, 0.0));
        let k = self.rest.k(z);
        let dk = slope(&|z| self.rest.k(z));
        let lt = (g * self.sp - self.late(z) * self.flowscale) * self.scale;
        let dlt = (dg * self.sp - slope(&|z| self.late(z)) * self.flowscale) * self.scale;
        let taken = one - lt.inv();
        (k / lambda * taken - one, dk / lambda * taken + k / lambda * dlt / (lt * lt))
    }
}

impl Starts {
    /// Made at `row` and `tract` (its tract as it stands, where none) on the body `player` plays, at rest: in doubles,
    /// on one thread; its player's doubles and its tract put back as they stood.
    pub fn of(player: &mut Player, rate: f64, row: &[f64], tract: Option<&[Resonance]>) -> Result<Starts, String> {
        if player.crewed() {
            return Err("its starts are found on one core: a dial of one thread (--threads 1)".into());
        }
        let single = player.single();
        if single {
            player.in_doubles(true);
        }
        let (kept, was) = (player.data().to_vec(), player.tract.clone());
        let made = Starts::made(player, rate, row, tract);
        player.set_data(&kept);
        player.tract = was;
        if single {
            player.in_doubles(false);
        }
        made
    }

    // (As `rooted` makes its equation before it seeks its root.)
    fn made(player: &mut Player, rate: f64, row: &[f64], tract: Option<&[Resonance]>) -> Result<Starts, String> {
        let place = player.reed_place()?;
        let k = player.reed_constants()?;
        if k.lips {
            return Err("lips' starts are not yet written out (their inward mode)".into());
        }
        let col = place.columns;
        if row.len() <= col + 8 {
            return Err("a row without its reed's columns".into());
        }
        if let Some(rs) = tract {
            let mut t = player.tract.take().unwrap_or_else(|| Tract::new(rate));
            t.set(rs.to_vec(), 0.0);
            player.tract = Some(t);
        }
        if let Some(t) = player.tract.as_mut() {
            t.settle();
        }
        player.bore_steady(row, 0.0, 1)?;
        let map = player.bore_map(row, 0.0, NUDGE, true)?;
        let moving = map.moving.clone();
        let tube = Tube::of(map);
        let g1 = tube.at(C::new(1.0, 0.0))?.re;
        let rest = resting(&Reed::of(row, col), &k, row[col], g1)?;
        Ok(Starts { tube, moving, row: row.to_vec(), col, k, g1, rate, rest, tract: player.tract.clone(), flowed: None })
    }

    fn equation(&self, k: &ReedConstants, rest: Rest, tract: Option<Tract>) -> Equation<'_> {
        let lambda = k.zc / (k.alpha * k.simp);
        Equation { tube: &self.tube, rest, tract, lambda, sp: k.sp, flowscale: k.flowscale, scale: lambda / (k.zc * k.sf) }
    }

    /// Its tube's own resonance nearest `hz`, as `rooted` finds it (pole_near).
    pub fn pole(&self, hz: f64) -> Result<Pole, String> {
        if !(hz > 0.0 && hz < self.rate / 2.0) {
            return Err(format!("a pitch between nothing and half its rate ({} Hz)", self.rate / 2.0));
        }
        let (z, solves) = pole_near(&self.tube, hz, self.rate)?;
        Ok(Pole { hz: z.arg() * self.rate / (2.0 * std::f64::consts::PI), solves, z })
    }

    /// The start its tube's resonance `pole` becomes, as `rooted` follows it: its reed's answer let in by shares, each
    /// share's root begun from the last's.
    pub fn grown(&self, pole: &Pole) -> Result<Root, String> {
        let rate = self.rate;
        let eq = self.equation(&self.k, self.rest, self.tract.clone());
        let pitch = |z: C| z.arg() * rate / (2.0 * std::f64::consts::PI);
        let (mut z, mut solves) = (pole.z, pole.solves);
        let (mut theta, mut share, mut last) = (0.0, SHARE, None);
        while theta < 1.0 {
            let next = (theta + share).min(1.0);
            match eq.root(z, next) {
                Ok((found, at, steps)) if cents(pitch(found), pitch(z)).abs() <= FAR => {
                    solves += 2 * steps;
                    (z, theta, last) = (found, next, Some(at));
                }
                _ if share / 2.0 >= LEAST => share /= 2.0,
                _ => return Err(format!("its start's root is lost from its tube's resonance at {:.1} Hz, its reed's answer let in {theta:.3}", pitch(z))),
            }
        }
        let at = last.expect("a share taken");
        Ok(Root { hz: pitch(z), growth: rate * z.abs().ln(), pole: Some(pole.hz), left: at.e.abs(), solves, z, at })
    }

    /// Its start about `hz`, its own resonance's, as `rooted` finds it: followed from `from` ([growth 1/s, pitch Hz])
    /// where given and its steps stay near it, else the start its tube's pole nearest `hz` becomes (pole, grown).
    pub fn root(&self, hz: f64, from: Option<[f64; 2]>) -> Result<Root, String> {
        let rate = self.rate;
        if !(hz > 0.0 && hz < rate / 2.0) {
            return Err(format!("a pitch between nothing and half its rate ({} Hz)", rate / 2.0));
        }
        let eq = self.equation(&self.k, self.rest, self.tract.clone());
        let pitch = |z: C| z.arg() * rate / (2.0 * std::f64::consts::PI);
        let followed = from.filter(|f| f[0].is_finite() && f[1] > 0.0 && f[1] < rate / 2.0).and_then(|[growth, f]| {
            let found = eq.root(C::polar((growth / rate).exp(), 2.0 * std::f64::consts::PI * f / rate), 1.0).ok()?;
            (cents(pitch(found.0), f).abs() <= FAR).then_some(found)
        });
        match followed {
            Some((z, at, steps)) => Ok(Root { hz: pitch(z), growth: rate * z.abs().ln(), pole: None, left: at.e.abs(), solves: 2 * steps, z, at }),
            None => self.grown(&self.pole(hz)?),
        }
    }

    /// Each of `roots`' rates on each maker's point, as `rooted` reads them: from the body made with that point moved
    /// by its nudge (`moved`, `nudges`, each in its point's unit), each on `base`'s layout, the body `player` plays -> for
    /// each root, (cents for a move of one of each point's units, 1/s for one). Each moved body's own step taken once
    /// for them all. Its player in doubles meanwhile, on one thread; its doubles put back as they stood.
    pub fn points(&self, player: &mut Player, base: &Body, moved: &[Body], nudges: &[f64], roots: &[&Root]) -> Result<Vec<(Vec<f64>, Vec<f64>)>, String> {
        if player.crewed() {
            return Err("its starts' rates are found on one core: a dial of one thread (--threads 1)".into());
        }
        if moved.len() != nudges.len() || nudges.iter().any(|n| !(*n != 0.0 && n.is_finite())) {
            return Err("each moved body, and the nudge it was made at".into());
        }
        let single = player.single();
        if single {
            player.in_doubles(true);
        }
        let kept = player.data().to_vec();
        let found = self.pointed(player, base, moved, nudges, roots);
        player.set_data(&kept);
        if single {
            player.in_doubles(false);
        }
        found
    }

    fn pointed(&self, player: &mut Player, base: &Body, moved: &[Body], nudges: &[f64], roots: &[&Root]) -> Result<Vec<(Vec<f64>, Vec<f64>)>, String> {
        let (row, moving) = (self.row.as_slice(), &self.moving);
        player.bore_steady(row, 0.0, 1)?;
        let parts: Vec<(Vec<f64>, Vec<f64>)> = roots.iter().map(|r| (r.at.u.iter().map(|c| c.re).collect(), r.at.u.iter().map(|c| c.im).collect())).collect();
        let none = vec![0.0; moving.len()];
        let stepped = |player: &mut Player| -> Result<(Vec<Vec<C>>, Vec<f64>), String> {
            let us = parts
                .iter()
                .map(|(re, im)| {
                    let (a, b) = (player.bore_applied(row, moving, re, 0.0)?, player.bore_applied(row, moving, im, 0.0)?);
                    Ok(a.iter().zip(&b).map(|(x, y)| C::new(*x, *y)).collect())
                })
                .collect::<Result<Vec<Vec<C>>, String>>()?;
            Ok((us, player.bore_applied(row, moving, &none, 1.0)?))
        };
        let (own_u, own_b) = stepped(player)?;
        let mut out: Vec<(Vec<f64>, Vec<f64>)> = roots.iter().map(|_| (Vec::with_capacity(moved.len()), Vec::with_capacity(moved.len()))).collect();
        for (body, &nudge) in moved.iter().zip(nudges) {
            player.remade(&body.i, &base.d, &body.d, body.header.points.as_ref())?;
            let there = stepped(player);
            player.remade(&base.i, &body.d, &base.d, base.header.points.as_ref())?;
            let (its_u, its_b) = there?;
            for (q, root) in roots.iter().enumerate() {
                let (at, z) = (&root.at, root.z);
                let dg = (0..moving.len()).fold(C::default(), |s, i| s + at.v[i] * (its_u[q][i] - own_u[q][i] + C::new(its_b[i] - own_b[i], 0.0)));
                let dz = -(at.de_dg * dg) / at.de_dz / z;
                out[q].0.push(1200.0 / std::f64::consts::LN_2 * dz.im / z.arg() / nudge);
                out[q].1.push(self.rate * dz.re / nudge);
            }
        }
        Ok(out)
    }

    /// Where a move `to` of its player or its reed takes `root`, read off its equation there with its tube's answer as
    /// it is: one of Newton's steps on the equation so moved, from the root, its slope in z the moved equation's own
    /// -> [its growth there, 1/s; its pitch there, Hz]. By arithmetic: no solve of its tube. (Against the root found
    /// again, the clarinet's written C#5 to D#5, each of its player's controls and its reed's values a hundredth of its
    /// scale: a move either side's mean the same within 2 parts in 10,000, one side's within a hundredth -- as near
    /// as that side's own slope stands to the rate at the root. Its tube's answer taken along its slope, or its
    /// inverse's, and the step repeated, stood 3 and 6 per cent off: its answer about a root is neither.)
    pub fn moved(&self, root: &Root, to: &Move) -> Result<[f64; 2], String> {
        let k = to.reed.unwrap_or(self.k);
        let row = to.row.unwrap_or(&self.row);
        if row.len() <= self.col + 8 {
            return Err("a row without its reed's columns".into());
        }
        let rest = resting(&Reed::of(row, self.col), &k, row[self.col], self.g1)?;
        let tract = match to.tract {
            Some(rs) => {
                let mut t = Tract::new(self.rate);
                t.set(rs.to_vec(), 0.0);
                t.settle();
                Some(t)
            }
            None => self.tract.clone(),
        };
        let eq = self.equation(&k, rest, tract);
        let (at, z) = (&root.at, root.z);
        let g = self.tube.c.iter().fold(C::default(), |s, &(i, c)| s + at.u[i] * c);
        let dg = -at.u.iter().zip(&at.v).fold(C::default(), |s, (a, b)| s + *a * *b);
        let (e, de_dz) = eq.given(z, g, dg);
        let there = z - e / de_dz + self.flow_shift(root, rest.w_over * row[self.col + 8] / (k.zc * k.sf));
        if !(there.re.is_finite() && there.im.is_finite() && there.abs() > 0.0) {
            return Err("its equation's slope is none at its root's move".into());
        }
        Ok([self.rate * there.abs().ln(), there.arg() * self.rate / (2.0 * std::f64::consts::PI)])
    }

    /// Its reed's constants as it was made with them (its body's own): what a Move's are set beside.
    pub fn reed(&self) -> ReedConstants {
        self.k
    }
}

#[cfg(test)]
mod kept_tests {
    use super::*;
    use crate::kernel::BoreMap;

    // (Three resonances as the_pole_nearest_a_pitch's, each driven a thousandth as strongly, so that the tube's answer
    // about one is of its reed's own order, and each fed a thousandth of the next, so that none's pole is a number its
    // step holds exactly -- at one that is, its solve has no pivot; a reed's columns as starts.rs's tests have them, its
    // constants plain and in the tube's own units.)
    const ROW: [f64; 9] = [0.680180061812813, 0.717672465956056, 0.7002896279296936, 1.8228268537802204, 17259.91, 10576.899054607233, 4.0, -1.0, 5439.7360459799065];
    const RATE: f64 = 48_000.0;

    fn plain() -> ReedConstants {
        ReedConstants { theta: 0.25, dt: 1.0 / RATE, sp: 1.0, zc: 1.0, sf: 1.0, simp: 1.0, flowscale: 1.0, exponent: 1.0, alpha: 1.0, ..Default::default() }
    }

    fn starts(row: &[f64], k: ReedConstants, tract: Option<&[Resonance]>) -> Starts {
        const KEPT: f64 = 0.9995;
        let pitches = [440.0, 1320.0, 2210.0];
        let mut cols = vec![];
        for (q, hz) in pitches.iter().enumerate() {
            let (sin, cos) = (2.0 * std::f64::consts::PI * hz / RATE).sin_cos();
            cols.push(vec![(2 * q, KEPT * cos), (2 * q + 1, KEPT * sin), (2 * ((q + 1) % pitches.len()), 1e-3)]);
            cols.push(vec![(2 * q, -KEPT * sin), (2 * q + 1, KEPT * cos)]);
        }
        let ends = |gain: f64| -> Vec<(usize, f64)> { (0..pitches.len()).map(|q| (2 * q, gain)).collect() };
        let tube = Tube::of(BoreMap { moving: (0..2 * pitches.len()).collect(), cols, b: ends(1e-3), c: ends(1.0), off: 0.0 });
        let g1 = tube.at(C::new(1.0, 0.0)).unwrap().re;
        let rest = resting(&Reed::of(row, 0), &k, row[0], g1).unwrap();
        let tract = tract.map(|rs| {
            let mut t = Tract::new(RATE);
            t.set(rs.to_vec(), 0.0);
            t.settle();
            t
        });
        Starts { tube, moving: (0..2 * pitches.len()).collect(), row: row.to_vec(), col: 0, k, g1, rate: RATE, rest, tract, flowed: None }
    }

    fn cents_of(a: f64, b: f64) -> f64 {
        1200.0 * (a / b).log2()
    }

    // (A start found from its tube's resonance, and followed from itself: the same root, its equation closed.)
    #[test]
    fn a_start_is_its_resonances_own_and_followed_is_itself() {
        let own = starts(&ROW, plain(), None);
        let pole = own.pole(1320.0 * (30.0f64 / 1200.0).exp2()).unwrap();
        assert!(cents_of(pole.hz, 1320.0).abs() < 1e-2, "its pole at {} Hz", pole.hz);
        let root = own.grown(&pole).unwrap();
        assert!(root.left < 1e-9 && cents_of(root.hz, 1320.0).abs() < FAR, "{} Hz, {} left", root.hz, root.left);
        assert_eq!(root.pole, Some(pole.hz));
        let again = own.root(1320.0, Some([root.growth, root.hz])).unwrap();
        assert!(cents_of(again.hz, root.hz).abs() < 1e-9 && (again.growth - root.growth).abs() < 1e-6, "{} Hz {} /s against {} Hz {} /s", again.hz, again.growth, root.hz, root.growth);
        assert!(again.pole.is_none() && again.solves <= root.solves);
        // (No root from a pitch beyond its rate's half.)
        assert!(own.root(30_000.0, None).is_err());
    }

    // (A move of its reed's columns, of its breath, of its tract and of its reed's constants, each a hundredth: where
    // the root is read off its equation to go against the root found again on what is so moved -- a move either side,
    // the two sides' difference within a thousandth of itself; one side, within a twentieth.)
    #[test]
    fn a_move_read_off_the_equation_is_the_root_found_again() {
        let own = starts(&ROW, plain(), None);
        let root = own.root(1320.0, None).unwrap();
        let from = Some([root.growth, root.hz]);
        let held = |by: [f64; 2], found: &Root| (cents_of(by[1], root.hz), cents_of(found.hz, root.hz), by[0] - root.growth, found.growth - root.growth);
        let near = |a: f64, b: f64, share: f64, what: &str| assert!((a - b).abs() <= share * b.abs() + 1e-12, "{what}: {a} read off, {b} found again");
        let mut checked = 0;
        for col in [0usize, 1, 2, 3] {
            let side = |sign: f64| {
                let mut row = ROW;
                row[col] *= 1.0 + sign * 0.01;
                let by = own.moved(&root, &Move { row: Some(&row), ..Move::default() }).unwrap();
                held(by, &starts(&row, plain(), None).root(1320.0, from).unwrap())
            };
            let (up, down) = (side(1.0), side(-1.0));
            near(up.0 - down.0, up.1 - down.1, 1e-3, "its pitch, either side");
            near(up.2 - down.2, up.3 - down.3, 1e-3, "its growth, either side");
            near(up.0, up.1, 0.05, "its pitch, one side");
            near(up.2, up.3, 0.05, "its growth, one side");
            checked += ((up.1 - down.1).abs() > 1e-9 || (up.3 - down.3).abs() > 1e-9) as usize;
        }
        assert!(checked >= 3, "only {checked} of its columns move its start at all");
        // (Its tract: a resonance near the note taken up, then moved a hundredth either side.)
        let tract = |hz: f64| [Resonance { frequency: hz, q: 6.0, peak: 0.02 }];
        let with = starts(&ROW, plain(), Some(&tract(1400.0)));
        let rooted = with.root(1320.0, from).unwrap();
        let side = |sign: f64| {
            let moved = tract(1400.0 * (1.0 + sign * 0.01));
            let by = with.moved(&rooted, &Move { tract: Some(&moved), ..Move::default() }).unwrap();
            let found = starts(&ROW, plain(), Some(&moved)).root(1320.0, Some([rooted.growth, rooted.hz])).unwrap();
            (cents_of(by[1], rooted.hz), cents_of(found.hz, rooted.hz), by[0] - rooted.growth, found.growth - rooted.growth)
        };
        let (up, down) = (side(1.0), side(-1.0));
        assert!((up.1 - down.1).abs() > 1e-9, "its tract moves its start");
        near(up.0 - down.0, up.1 - down.1, 1e-3, "its pitch on its tract, either side");
        near(up.2 - down.2, up.3 - down.3, 1e-3, "its growth on its tract, either side");
        // (Its reed's constants as another body holds them: its slit's leak.)
        let side = |leak: f64| {
            let k = ReedConstants { leak, ..plain() };
            let by = own.moved(&root, &Move { reed: Some(k), ..Move::default() }).unwrap();
            held(by, &starts(&ROW, k, None).root(1320.0, from).unwrap())
        };
        let (up, down) = (side(0.01), side(0.02));
        near(down.0 - up.0, down.1 - up.1, 2e-2, "its pitch on its reed's constants, between two moves");
        near(down.2 - up.2, down.3 - up.3, 2e-2, "its growth on its reed's constants, between two moves");
        // (A move of nothing leaves it where it is.)
        let still = own.moved(&root, &Move::default()).unwrap();
        assert!(cents_of(still[1], root.hz).abs() < 1e-9 && (still[0] - root.growth).abs() < 1e-6);
    }
}

// ---- How large its tongue's release leaves each start (native/openwind-tuner src/race.rs; the owner, 15 November 2026,
// of which register takes a note: "can this be computed deterministically - as in, is there a formula for dominant
// largeness over time, apart from simulating the note itself?"; "build according to your proposal for the
// dominant-resonance calculator"), here at the file's end so that no line above it moves. ----

// (The places along a release its reed's rest, its root and its flow are read at.)
const RELEASED: usize = 256;

impl Starts {
    /// The size each of `roots` begins at as its tongue leaves its reed, at the release's end -> each one's [flow at
    /// its reed's end, m^3/s; pressure there, the bore's own units -- one over another, the head start the attack
    /// gives it], and its resting flow's rise over the release (m^3/s), by arithmetic on its start equations. Before
    /// the release its reed is held at the row `from` (its tongue on it: its slit nearly shut), which is eased to its
    /// own row over `seconds` along the raised cosine, as the engine's stream eases a row held. What strikes its
    /// starts is taken to be the flow its reed lets through at rest, as it follows the row from the tongued row's to
    /// its own (each place's resting flow, `resting`): a flow w let into the loop its reed and its tube close answers
    /// with the flow w(z) / D(z), D = 1 - Lt (1 - lambda / K) -- the loop's own equation, E = -K D / (lambda Lt) --
    /// so that a root's share of a step of it is its residue there, (K - lambda) / (lambda E'(z)), over 1 - 1/z; and
    /// its pressure at the reed's end that flow times what the tube answers a flow there with less its end's own
    /// (G - alpha). Each start is followed through the release: at each of its RELEASED places the root the loop has
    /// with its reed as the row then holds it -- under the tongue the tube's own pole, dying -- found from the next
    /// place's by Newton's steps, its tube's answer about the root taken as its own pole's alone (rho / (z - p), from
    /// its answer and its slope at the start's own root: no solve of its tube); the flow let in at a place taken up
    /// with that place's residue, what was taken up before carried on at that place's root. (Taken whole at its own
    /// root from the release's first step, a fast start grew through the release as if its slit stood open: the
    /// clarinet's written B-flat 4's own, 301 /s, 10 dB over the engine; followed, 2 under.) The reed's own motion as
    /// its tongue leaves it is left out. Beside the engine on eleven of the clarinet's notes (race.rs, 15 November
    /// 2026): the starts read cleanly within 4 dB, but two notes' own 6 and 10 dB under -- a release this smooth
    /// leaves each start what is left of a near cancellation, so its size turns on a tenth of a millisecond of the
    /// release's shape, and the stilled reed's closing to its rest as the tongue lets go is such a difference.
    pub fn struck(&self, roots: &[&Root], from: &[f64], seconds: f64) -> Result<(Vec<[f64; 2]>, f64), String> {
        let (col, k) = (self.col, &self.k);
        if from.len() != self.row.len() || from.len() <= col + 8 {
            return Err("the row its reed is held at before its release, as long as its own".into());
        }
        if !(seconds >= 0.0 && seconds.is_finite()) {
            return Err("the seconds its release takes".into());
        }
        let eased = |x: f64| 0.5 - 0.5 * (std::f64::consts::PI * x.clamp(0.0, 1.0)).cos();
        // (Each place's reed at rest -- none where it rests shut there, or has no breath -- and the flow it lets
        // through so, in the bore's units.)
        let places: Vec<(Option<Rest>, f64)> = (0..=RELEASED)
            .map(|m| {
                let share = eased(m as f64 / RELEASED as f64);
                let row: Vec<f64> = from.iter().zip(&self.row).map(|(a, b)| a + (b - a) * share).collect();
                let reed = Reed::of(&row, col);
                match resting(&reed, k, row[col], self.g1) {
                    Ok(rest) => (Some(rest), rest.w_over * reed.closing / (k.zc * k.sf)),
                    Err(_) => (None, 0.0),
                }
            })
            .collect();
        let risen = places[RELEASED].1 - places[0].1;
        if !(risen != 0.0 && risen.is_finite()) {
            return Err("its resting flow is the same before its release and after".into());
        }
        let lambda = k.zc / (k.alpha * k.simp);
        let scale = lambda / (k.zc * k.sf);
        let (one, lam, d) = (C::new(1.0, 0.0), C::new(lambda, 0.0), C::new(SLOPE, 0.0));
        let each = seconds * self.rate / RELEASED as f64;
        let late = |z: C| {
            self.tract.as_ref().map_or(C::default(), |t| {
                let (re, im) = t.answer_at(z.re, z.im);
                z.inv() * C::new(re, im)
            })
        };
        let sizes = roots
            .iter()
            .map(|root| {
                let (at, own) = (&root.at, root.z);
                let g = self.tube.c.iter().fold(C::default(), |s, &(i, c)| s + at.u[i] * c);
                let dg = C::default() - at.u.iter().zip(&at.v).fold(C::default(), |s, (a, b)| s + *a * *b);
                // (Its tube's answer about its root as its own pole's alone: rho / (z - p).)
                let (pole, rho) = (own + g / dg, C::default() - g * g / dg);
                // (The loop at a place's rest and a z: what is left of its equation, its slope in z, its reed's answer
                // and its tract's as its reed reads it.)
                let looped = |rest: &Rest, z: C| -> (C, C, C, C) {
                    let (gz, dgz) = (rho / (z - pole), C::default() - rho / ((z - pole) * (z - pole)));
                    let (lt, dlt) = ((gz * k.sp - late(z) * k.flowscale) * scale, (dgz * k.sp - (late(z + d) - late(z - d)) / (d * 2.0) * k.flowscale) * scale);
                    let (kz, dk) = (rest.k(z), (rest.k(z + d) - rest.k(z - d)) / (d * 2.0));
                    let taken = one - lt.inv();
                    (kz / lam * taken - one, dk / lam * taken + kz / lam * dlt / (lt * lt), kz, late(z))
                };
                // (Each place's root and its residue in the pressure at its reed's end, followed back from its own:
                // (K - lambda) (G - alpha) / (lambda E'), its G by the loop's own equation at the root; under a reed
                // that answers nothing, its tube's pole and that pole's own residue.)
                let mut found: Vec<(C, C)> = vec![(pole, C::default() - rho); RELEASED + 1];
                let mut z = own;
                for m in (0..=RELEASED).rev() {
                    let Some(rest) = &places[m].0 else { continue };
                    let mut closed = m == RELEASED;
                    for _ in 0..if closed { 0 } else { STEPS } {
                        let (e, de, ..) = looped(rest, z);
                        let dz = e / de;
                        if !(dz.re.is_finite() && dz.im.is_finite()) {
                            break;
                        }
                        z = z - dz;
                        if dz.abs() <= CLOSED {
                            closed = true;
                            break;
                        }
                    }
                    if !closed {
                        return Err(format!("a start's root is lost {m} of {RELEASED} places into its release"));
                    }
                    let (_, de, kz, lz) = looped(rest, z);
                    found[m] = (z, (kz + (kz - lam) * (lz * (k.flowscale * scale) - C::new(k.alpha * k.sp * scale, 0.0))) / (de * (k.sp * scale * lambda)));
                }
                // (What each place lets in taken up at its root, what was taken up before carried on at it.)
                let mut size = C::default();
                for m in 1..=RELEASED {
                    let (z, residue) = found[m];
                    let log = C::new(z.abs().ln(), z.arg());
                    size = size * C::polar((each * log.re).exp(), each * log.im) + residue * (places[m].1 - places[m - 1].1) / (one - z.inv());
                }
                // (Both of its pair.)
                let pressure = 2.0 * size.abs();
                let sizes = [pressure / (g - C::new(k.alpha, 0.0)).abs() * k.flowscale, pressure];
                sizes.iter().all(|v| v.is_finite()).then_some(sizes).ok_or_else(|| "a start's size at its release is no number".to_string())
            })
            .collect::<Result<Vec<[f64; 2]>, String>>()?;
        Ok((sizes, risen * k.flowscale))
    }
}

// ---- Its starts on its tube as its breath's steady flow leaves it (the owner, 15 November 2026, of what the attack's
// race might show of the engine: "that might reveal something about the engine, which could be further investigated";
// "yes, find this"; of gaps so found: "build physically accurate remedies for them"), here at the file's end so that
// no line above it moves. The engine's attack, read with nothing presumed of it (race.rs), had the clarinet's written
// C#6's fundamental register growing 105 /s where its equation about rest gave 136.5: an edge's loss, square in the flow
// through it, is nothing to a tube at rest, and half shuts a vent to the oscillation once its breath's steady flow
// passes -- as speaking.rs found of its map, and takes its tube the same way (its `steady`: the steady state by
// Newton's steps on the engine's own step, the columns that feed its lossy ends read again about it). ----

// (As speaking.rs's: its rest and its steady state taken again so many times at most, until the pressure the steady
// flow holds at its reed stands; its steady state's Newton's steps, closed under so small a step of its largest double.)
const HELD_AGAIN: usize = 6;
const STEADY_STEPS: usize = 30;
const STEADY_CLOSED: f64 = 1e-12;

/// (1 - B)^-1 r on `tube`, r and its answer over the doubles its step moves, in their order.
fn steadied(tube: &Tube, r: &[f64]) -> Result<Vec<f64>, String> {
    let mut m = Banded::new(tube.n, tube.kl, tube.ku);
    for i in 0..tube.n {
        m.add(tube.position[i], tube.position[i], C::new(1.0, 0.0));
    }
    for &(i, j, v) in &tube.entries {
        m.add(tube.position[i], tube.position[j], C::new(-v, 0.0));
    }
    m.lu()?;
    let mut rhs = vec![C::default(); tube.n];
    for (i, v) in r.iter().enumerate() {
        rhs[tube.position[i]] = C::new(*v, 0.0);
    }
    let x = m.solve(&rhs);
    Ok((0..tube.n).map(|i| x[tube.position[i]].re).collect())
}

/// The steady state its bore holds with the flow `w` into it at its reed (its own step's fixed point, its lossy ends'
/// losses as the engine plays them), from `from` (one found before, scaled to this flow) or the one its tube about rest
/// holds, by Newton's steps on its own step -> (its state over the map's moving doubles, its map about it: `map` with
/// the columns `lossy`, those that feed its lossy ends' flows, read again there).
fn blown_state(player: &mut Player, row: &[f64], map: &crate::kernel::BoreMap, rest: &Tube, lossy: &[usize], w: f64, from: Option<(&[f64], f64)>) -> Result<(Vec<f64>, crate::kernel::BoreMap), String> {
    let n = map.moving.len();
    let mut x: Vec<f64> = match from {
        Some((x, was)) if was != 0.0 && x.len() == n => x.iter().map(|v| v * w / was).collect(),
        _ => {
            let mut b = vec![0.0; n];
            for &(i, v) in &map.b {
                b[i] = v * w;
            }
            steadied(rest, &b)?
        }
    };
    let about = |player: &mut Player, x: &[f64]| -> Result<crate::kernel::BoreMap, String> {
        let mut out = map.clone();
        for (&j, col) in lossy.iter().zip(player.bore_columns(row, w, &map.moving, x, lossy, NUDGE)?) {
            out.cols[j] = col;
        }
        Ok(out)
    };
    for _ in 0..STEADY_STEPS {
        let stepped = player.bore_step(row, &map.moving, &x, w)?;
        let f: Vec<f64> = stepped.iter().zip(&x).map(|(s, v)| s - v).collect();
        let delta = steadied(&Tube::of(about(player, &x)?), &f)?;
        let largest = x.iter().fold(0.0f64, |m, v| m.max(v.abs())).max(f64::MIN_POSITIVE);
        let moved = delta.iter().fold(0.0f64, |m, v| m.max(v.abs()));
        for (v, d) in x.iter_mut().zip(&delta) {
            *v += d;
        }
        if moved <= STEADY_CLOSED * largest {
            break;
        }
    }
    let map = about(player, &x)?;
    Ok((x, map))
}

impl Starts {
    /// As `of`, on its tube as its breath's steady flow leaves it: its lossy ends' losses about that flow, as the engine
    /// plays them, and its reed at rest against the pressure that flow holds at it. A body without such an end, or a
    /// row that lets no flow through: `of`'s own.
    pub fn blown(player: &mut Player, rate: f64, row: &[f64], tract: Option<&[Resonance]>) -> Result<Starts, String> {
        if player.crewed() {
            return Err("its starts are found on one core: a dial of one thread (--threads 1)".into());
        }
        let single = player.single();
        if single {
            player.in_doubles(true);
        }
        let (kept, was) = (player.data().to_vec(), player.tract.clone());
        let made = Starts::made(player, rate, row, tract).and_then(|rested| rested.steadied_on(player));
        player.set_data(&kept);
        player.tract = was;
        if single {
            player.in_doubles(false);
        }
        made
    }

    /// Its tube and the pressure a steady flow holds in it (a share of that flow), as a start from silence takes them
    /// (starts.rs grows).
    pub(crate) fn tube_held(self) -> (Tube, f64) {
        (self.tube, self.g1)
    }

    // (Made about rest, taken about its steady state: its player as `made` left it.)
    fn steadied_on(self, player: &mut Player) -> Result<Starts, String> {
        let (row, col, k) = (self.row.clone(), self.col, self.k);
        let map = player.bore_map(&row, 0.0, NUDGE, true)?;
        // (The columns its lossy ends' flows are read from: their rows in its map.)
        let flows: Vec<usize> = player.lossy_flows().iter().filter_map(|w| map.moving.iter().position(|m| m == w)).collect();
        let lossy: Vec<usize> = (0..map.cols.len()).filter(|&j| map.cols[j].iter().any(|(i, _)| flows.contains(i))).collect();
        if lossy.is_empty() {
            return Ok(self);
        }
        let reed = Reed::of(&row, col);
        let fs = reed.closing / (k.zc * k.sf);
        let (mut held, mut about, mut found, mut last): (f64, Option<crate::kernel::BoreMap>, Option<(Vec<f64>, f64)>, Option<f64>) = (self.g1, None, None, None);
        for _ in 0..HELD_AGAIN {
            let w = resting(&reed, &k, row[col], held)?.w_over * fs;
            if w == 0.0 {
                break;
            }
            let (x, m) = blown_state(player, &row, &map, &self.tube, &lossy, w, found.as_ref().map(|(x, was)| (&x[..], *was)))?;
            let now = map.c.iter().fold(0.0, |s, &(i, v)| s + x[i] * v) / w;
            (about, found) = (Some(m), Some((x, w)));
            let done = last.is_some_and(|l: f64| (now - l).abs() <= 1e-12 * now.abs());
            (last, held) = (Some(now), now);
            if done {
                break;
            }
        }
        let Some(about) = about else { return Ok(self) };
        let rest = resting(&reed, &k, row[col], held)?;
        Ok(Starts { tube: Tube::of(about), g1: held, rest, ..self })
    }
}

// ---- Its starts on its tube as its attack finds it (15 November 2026): the breath's flow, let into a bore at rest as
// its tongue leaves its reed, is not yet where it settles -- a bore's steady flow finds its way among its open holes
// against their edges' losses and its walls' alone, over tens of milliseconds to a second, and a note's registers race
// in its first thirty or so. The state its lossy ends' losses are taken about is then the one the engine's own bore
// stands in over that time: stepped here as the engine steps it, its reed's own left out, under the flow its reed lets
// through at rest along the rows its script holds. ----

// (Its attack's state: the mean of its bore's, read every so many steps.)
const READ_EVERY: usize = 48;

/// A row its script holds: the row, the seconds it is eased to over (the raised cosine, as the stream eases a row held),
/// and the seconds it is then held before the next.
pub struct HeldFor<'a> {
    pub row: &'a [f64],
    pub eased: f64,
    pub held: f64,
}

impl Starts {
    /// As `blown`, about the state its bore stands in as its attack begins: `script` the rows held before its own and
    /// its own last (each eased to from the one before; the first from rest), its bore's state the mean over `over` s
    /// from its own row's reaching. A body without a lossy end: `of`'s own.
    pub fn attacked(player: &mut Player, rate: f64, script: &[HeldFor], tract: Option<&[Resonance]>, over: f64) -> Result<Starts, String> {
        let own = script.last().ok_or("a script that holds its note's own row")?.row;
        if player.crewed() {
            return Err("its starts are found on one core: a dial of one thread (--threads 1)".into());
        }
        let single = player.single();
        if single {
            player.in_doubles(true);
        }
        let (kept, was) = (player.data().to_vec(), player.tract.clone());
        let made = Starts::made(player, rate, own, tract).and_then(|rested| rested.attacked_on(player, script, over));
        player.set_data(&kept);
        player.tract = was;
        if single {
            player.in_doubles(false);
        }
        made
    }

    // (Made about rest, its bore at rest: stepped through its script, then taken about where that leaves it.)
    fn attacked_on(self, player: &mut Player, script: &[HeldFor], over: f64) -> Result<Starts, String> {
        let (row, col, k, rate) = (self.row.clone(), self.col, self.k, self.rate);
        if script.iter().any(|h| h.row.len() != row.len()) || !(over > 0.0) {
            return Err("each row its script holds as long as its own, and the seconds its attack's state is read over".into());
        }
        let map = player.bore_map(&row, 0.0, NUDGE, true)?;
        let flows: Vec<usize> = player.lossy_flows().iter().filter_map(|w| map.moving.iter().position(|m| m == w)).collect();
        let lossy: Vec<usize> = (0..map.cols.len()).filter(|&j| map.cols[j].iter().any(|(i, _)| flows.contains(i))).collect();
        if lossy.is_empty() {
            return Ok(self);
        }
        let reed = Reed::of(&row, col);
        let eased = |x: f64| 0.5 - 0.5 * (std::f64::consts::PI * x.clamp(0.0, 1.0)).cos();
        // (Its bore at rest, as `made` left it: where each pass through its script begins.)
        let silent = player.data().to_vec();
        let (mut held, mut found): (f64, Option<(Vec<f64>, f64)>) = (self.g1, None);
        for _ in 0..HELD_AGAIN {
            // (The flow a row lets through at rest, the bore's units: none where it has no breath or rests shut.)
            let flow_of = |r: &[f64]| -> f64 {
                let reed = Reed::of(r, col);
                resting(&reed, &k, r[col], held).map_or(0.0, |rest| rest.w_over * reed.closing / (k.zc * k.sf))
            };
            let w = flow_of(&row);
            if w == 0.0 {
                return Err("its own row lets no flow through at rest".into());
            }
            player.set_data(&silent);
            // (Its first row held from the beginning: eased to from itself. Nothing stepped while nothing has flowed
            // yet: its bore stays at rest.)
            let mut before: Vec<f64> = script[0].row.to_vec();
            let mut still = true;
            let mut stepped = |player: &mut Player, flow: f64, steps: usize| -> Result<(), String> {
                if flow == 0.0 && still || steps == 0 {
                    return Ok(());
                }
                still = false;
                player.bore_steady(&row, flow, steps)
            };
            for (n, h) in script.iter().enumerate() {
                let steps = (h.eased * rate).round() as usize;
                let pieces = RELEASED.min(steps.max(1));
                for m in 1..=pieces {
                    let share = eased(m as f64 / pieces as f64);
                    let at: Vec<f64> = before.iter().zip(h.row).map(|(a, b)| a + (b - a) * share).collect();
                    stepped(player, flow_of(&at), steps * m / pieces - steps * (m - 1) / pieces)?;
                }
                if n + 1 < script.len() {
                    stepped(player, flow_of(h.row), (h.held * rate).round() as usize)?;
                }
                before = h.row.to_vec();
            }
            let reads = ((over * rate) as usize / READ_EVERY).max(1);
            let mut mean = vec![0.0; map.moving.len()];
            for _ in 0..reads {
                player.bore_steady(&row, w, READ_EVERY)?;
                let d = player.data();
                for (m, &q) in mean.iter_mut().zip(&map.moving) {
                    *m += d[q] / reads as f64;
                }
            }
            let now = map.c.iter().fold(0.0, |s, &(i, v)| s + mean[i] * v) / w;
            let done = (now - held).abs() <= 1e-6 * now.abs();
            (found, held) = (Some((mean, w)), now);
            if done {
                break;
            }
        }
        let Some((x, w)) = found else { return Ok(self) };
        let mut about = map.clone();
        // (And what its flow puts into each of those columns, over what it holds at rest: `moved`'s.)
        let mut columns = vec![];
        for (&j, c) in lossy.iter().zip(player.bore_columns(&row, w, &map.moving, &x, &lossy, NUDGE)?) {
            let mut change: std::collections::BTreeMap<usize, f64> = std::collections::BTreeMap::new();
            for &(i, v) in &c {
                *change.entry(i).or_insert(0.0) += v;
            }
            for &(i, v) in &map.cols[j] {
                *change.entry(i).or_insert(0.0) -= v;
            }
            columns.push((j, change.into_iter().filter(|c| c.1 != 0.0).collect()));
            about.cols[j] = c;
        }
        let rest = resting(&reed, &k, row[col], held)?;
        Ok(Starts { tube: Tube::of(about), g1: held, rest, flowed: Some(Flowed { flow: w, columns }), ..self })
    }
}

// ---- Its tube's solves in the order that keeps it sparse (sparse.rs Eliminated, as speaking.rs lays its tubes out: a
// clarinet's answer in 3 to 7 ms where its band took 97; the joint optimizer's notes' starts had taken 2 to 5 s a note
// at every stand, a minute a note where its competitors were sought afresh), here at the file's end so that no line
// above it moves. ----

// (As speaking.rs's: a solve stands where its residual is within so much of its matrix's size times its own, and its
// right side's.)
const STANDS: f64 = 1e-12;

impl Tube {
    // (Its pattern eliminated once in its sparse order, where each of its entries stands in it, -B's entries, and its
    // matrix's size by rows and by columns.)
    fn sparse(&self) -> &(crate::sparse::Eliminated, Vec<usize>, Vec<C>, f64, f64) {
        self.sparse.get_or_init(|| {
            let pattern: Vec<(usize, usize)> = self.entries.iter().map(|&(i, j, _)| (i, j)).collect();
            let order = crate::sparse::Eliminated::of(self.n, &pattern);
            let slots = order.slots(&pattern).expect("its own pattern");
            let (mut rows, mut cols) = (vec![0.0; self.n], vec![0.0; self.n]);
            for &(i, j, v) in &self.entries {
                rows[i] += v.abs();
                cols[j] += v.abs();
            }
            let largest = |v: &[f64]| v.iter().fold(0.0f64, |m, x| m.max(*x));
            (order, slots, self.entries.iter().map(|&(_, _, v)| C::new(-v, 0.0)).collect(), largest(&rows), largest(&cols))
        })
    }

    // ((z - B) x = r for each of `sides` (its right side over the doubles its step moves, and whether its transpose's is
    // solved), in its sparse order: each taken again once from its residual where it does not stand; none where its
    // order has no pivot there or a solve still does not stand -- its band's then.)
    fn sparsely(&self, z: C, sides: &[(&[(usize, f64)], bool)]) -> Option<Vec<Vec<C>>> {
        let (order, slots, values, norm, norm_t) = self.sparse();
        let f = order.factor(slots, values, z).ok()?;
        let size = |v: &[C]| v.iter().fold(0.0f64, |m, c| m.max(c.abs()));
        sides
            .iter()
            .map(|&(of, transposed)| {
                let mut r = vec![C::default(); self.n];
                for &(i, v) in of {
                    r[i] = C::new(v, 0.0);
                }
                let by = |v: &[C]| if transposed { f.solve_transposed(v) } else { f.solve(v) };
                let mut x = by(&r);
                for again in [false, true] {
                    let mut left: Vec<C> = r.iter().zip(&x).map(|(a, b)| *a - *b * z).collect();
                    for &(i, j, v) in &self.entries {
                        if transposed {
                            left[j] = left[j] + x[i] * v;
                        } else {
                            left[i] = left[i] + x[j] * v;
                        }
                    }
                    if size(&left) <= STANDS * ((z.abs() + if transposed { *norm_t } else { *norm }) * size(&x) + size(&r)) {
                        return Some(x);
                    }
                    if again {
                        break;
                    }
                    for (v, d) in x.iter_mut().zip(by(&left)) {
                        *v = *v + d;
                    }
                }
                None
            })
            .collect()
    }

    /// As `solved_both`, in its sparse order where its solves stand; else its band's.
    pub(crate) fn solved(&self, z: C) -> Result<(Vec<C>, Vec<C>, C), String> {
        match self.sparsely(z, &[(&self.b, false), (&self.c, true)]) {
            Some(mut found) => {
                let v = found.pop().expect("two sides");
                let u = found.pop().expect("two sides");
                let g = self.c.iter().fold(C::default(), |s, &(i, c)| s + u[i] * c);
                Ok((u, v, g))
            }
            None => self.solved_both(z),
        }
    }

    /// G(z), as `at`, in its sparse order where its solve stands; else its band's.
    pub(crate) fn answered(&self, z: C) -> Result<C, String> {
        match self.sparsely(z, &[(&self.b, false)]) {
            Some(found) => Ok(self.c.iter().fold(C::default(), |s, &(i, c)| s + found[0][i] * c)),
            None => self.at(z),
        }
    }
}

#[cfg(test)]
mod sparse_tests {
    use super::*;
    use crate::kernel::BoreMap;

    // (A tube of three coupled resonances, as kept_tests's: its sparse solves give its band's, its answer and both of
    // its solves, on the circle and off it.)
    #[test]
    fn its_sparse_solves_are_its_bands() {
        const KEPT: f64 = 0.9995;
        let pitches = [440.0, 1320.0, 2210.0];
        let mut cols = vec![];
        for (q, hz) in pitches.iter().enumerate() {
            let (sin, cos) = (2.0 * std::f64::consts::PI * hz / 48_000.0).sin_cos();
            cols.push(vec![(2 * q, KEPT * cos), (2 * q + 1, KEPT * sin), (2 * ((q + 1) % pitches.len()), 1e-3)]);
            cols.push(vec![(2 * q, -KEPT * sin), (2 * q + 1, KEPT * cos)]);
        }
        let ends = |gain: f64| -> Vec<(usize, f64)> { (0..pitches.len()).map(|q| (2 * q, gain)).collect() };
        let tube = Tube::of(BoreMap { moving: (0..2 * pitches.len()).collect(), cols, b: ends(1e-3), c: ends(1.0), off: 0.0 });
        for z in [C::polar(1.0, 0.06), C::polar(1.0003, 0.1728), C::polar(0.999, 0.29), C::new(1.0, 0.0)] {
            let (u, v, g) = tube.solved(z).unwrap();
            let (bu, bv, bg) = tube.solved_both(z).unwrap();
            let near = |a: C, b: C| (a - b).abs() <= 1e-9 * (1.0 + b.abs());
            assert!(near(g, bg) && near(tube.answered(z).unwrap(), tube.at(z).unwrap()), "{g:?} against {bg:?}");
            assert!(u.iter().zip(&bu).all(|(a, b)| near(*a, *b)) && v.iter().zip(&bv).all(|(a, b)| near(*a, *b)));
        }
    }
}

// ---- What a move of the flow through its reed does to a start, where its tube is taken about that flow (15 November
// 2026: the joint optimizer's own check, a lead's rate read 0.049 where its starts found again moved 0.096 --
// test/audio/winds-joint.test.mjs): a lossy end's loss, square in the flow through it, takes from a start in
// proportion to the flow, so a move of its player's breath or lip or of its reed that changes the flow at rest moves
// its tube's lossy columns with it, as far as the flow moved. ----

/// The flow its tube was taken about (the bore's units), and what that flow puts into each of its map's lossy columns
/// over what the column holds at rest (its place among the map's columns, its entries).
struct Flowed {
    flow: f64,
    columns: Vec<(usize, Vec<(usize, f64)>)>,
}

impl Starts {
    // (How far a root moves in z where its reed's flow at rest moves to `flow`: its tube's answer's move, v dB u over
    // its lossy columns' share of the flow's move, by its equation's own slopes; nothing on a tube taken at rest.)
    fn flow_shift(&self, root: &Root, flow: f64) -> C {
        let Some(f) = &self.flowed else { return C::default() };
        let at = &root.at;
        let dg = f.columns.iter().fold(C::default(), |s, (j, col)| s + col.iter().fold(C::default(), |t, &(i, v)| t + at.v[i] * v) * at.u[*j]);
        C::default() - at.de_dg * dg / at.de_dz * (flow / f.flow - 1.0)
    }
}
