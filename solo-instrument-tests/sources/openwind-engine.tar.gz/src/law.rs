//! A breath group's controls shaped from its plan and its notes' values (research/OPENWIND_REALTIME_PLAN.md, design 5), as
//! render/synthesis/workers/openwind_passages.py shapes them: passage_breath -- its breath's shape (its first rise, its
//! shares as led), each note's own breath moved across each change (`between`, a slur's fall of air before its fingers),
//! a repeat's half attack, an overblown note's kick, a register's kick and dip, its tongue on its reed (tongue_shares,
//! tongue_let_go) -- and simulate_passage_once's assembly of the excitator's controls from them: the reed's breath,
//! zeta, closing pressure, opening, width under the tongue, its resonance, mass and damping with the lips; a flute's
//! jet, presence, window and lip; the fingerings' times. The plan is breath.mjs's (openwind-passages.mjs); each note's
//! values its player table's (openwind_engine.py note_values); the model's law and its body's constants
//! (openwind_engine.py law_of, openwind_bodies.py save_body). -> the controls' Spec (controls.rs), its curves on the
//! control grid. A derivative of OpenWInD's scheme's use (Inria), under its licence, GPL-3.0-or-later.

use crate::body::Header;
use crate::controls::{eased, Curve, Fingerings, Flute, Reed, Spec};
use crate::technique::{source_at, voice_source, Techniques, VOICE_RATE};
use serde::Deserialize;
use std::collections::HashMap;

#[derive(Deserialize, Clone, Debug)]
pub struct JetLength {
    pub length: f64,
    pub pressure: f64,
    pub lead: f64,
}

#[derive(Deserialize, Clone, Debug)]
pub struct Transverse {
    pub hole: f64,
    pub size: f64,
    pub aspect: f64,
    pub convection: f64,
    pub profile: f64,
}

#[derive(Deserialize, Clone, Debug)]
pub struct HalfLaw {
    pub seconds: f64,
    pub step: f64,
    pub depth: f64,
    pub most: f64,
    pub levels: i32,
}

#[derive(Deserialize, Clone, Debug)]
pub struct TongueLaw {
    pub touch: f64,
    pub release: f64,
    pub shut: f64,
    pub soft: f64,
}

/// A model's law (openwind_engine.py law_of).
#[derive(Deserialize, Clone, Debug)]
#[serde(rename_all = "camelCase")]
pub struct Law {
    pub model: String,
    pub control: String,
    pub measured: bool,
    pub jet: bool,
    pub blowing: Option<f64>,
    pub reed: HashMap<String, f64>,
    pub epsilon: f64,
    pub noise_level: Option<f64>,
    pub roll: Option<f64>,
    pub jet_length: Option<JetLength>,
    pub transverse: Option<Transverse>,
    pub control_rate: f64,
    pub transitions: HashMap<String, f64>,
    pub relaxed: f64,
    pub attack_kick: f64,
    pub kick_seconds: f64,
    pub dip: [f64; 2],
    pub restart: [f64; 2],
    pub register_levels: Vec<(f64, Option<String>)>,
    pub ease_levels: Vec<Option<String>>,
    pub half: HalfLaw,
    pub tongue: TongueLaw,
    pub probe_rise: f64,
}

/// A note's values (openwind_engine.py note_values).
#[derive(Deserialize, Clone, Debug)]
pub struct NoteValues {
    pub target: f64,
    pub mode: i64,
    pub fingering: HashMap<String, f64>,
    pub lips: f64,
    pub embouchure: Option<f64>,
    #[serde(default)]
    pub half: i32,
    #[serde(default)]
    pub register: usize,
    #[serde(default)]
    pub eased: usize,
    pub value: f64,
    pub force: Option<f64>,
    pub zeta: Option<f64>,
    pub threshold: Option<f64>,
    #[serde(rename = "tongueForce")]
    pub tongue_force: Option<f64>,
    pub reed: Option<HashMap<String, f64>>,
    pub roll: Option<f64>,
    pub jet: Option<[f64; 2]>,
    pub uncovered: Option<f64>,
    #[serde(default)]
    pub technique: Option<Techniques>,
}

#[derive(Deserialize, Clone, Debug)]
pub struct Change {
    pub to: usize,
    pub at: f64,
    pub seconds: f64,
    pub span: Option<[f64; 2]>,
    pub repeat: Option<bool>,
}

#[derive(Deserialize, Clone, Debug)]
pub struct Tongue {
    pub to: usize,
    pub shut: f64,
    pub open: f64,
    pub soft: Option<bool>,
}

#[derive(Deserialize, Clone, Debug)]
pub struct Anticipation {
    pub most: f64,
    pub share: f64,
    pub window: f64,
    pub reach: f64,
    pub margin: f64,
}

#[derive(Deserialize, Clone, Debug)]
pub struct PlanNote {
    pub start: f64,
    pub end: f64,
    pub attack: Option<f64>,
}

/// A breath group's plan (breath.mjs, openwind_engine.py plan_of).
#[derive(Deserialize, Clone, Debug)]
#[serde(rename_all = "camelCase")]
pub struct Plan {
    pub origin: f64,
    pub share: Vec<[f64; 2]>,
    pub changes: Vec<Change>,
    pub entries: Vec<String>,
    pub end: f64,
    pub onsets: Option<Vec<f64>>,
    pub first_risen: Option<f64>,
    pub tongues: Option<Vec<Tongue>>,
    pub anticipation: Option<Anticipation>,
    pub notes: Vec<PlanNote>,
}

/// A breath group to shape: its plan, its notes' values, how early its first breath begins (s), each change's lead (s),
/// and how long it is simulated (s, its tail with it).
#[derive(Deserialize, Clone, Debug)]
pub struct Group {
    pub plan: Plan,
    pub notes: Vec<NoteValues>,
    pub ahead: f64,
    pub leads: Option<Vec<f64>>,
    pub seconds: f64,
    #[serde(default)]
    pub seed: u64,
}

/// A change down and back over x in [0, 1] (transitions.py bump).
fn bump(x: f64) -> f64 {
    let c = x.clamp(0.0, 1.0);
    if c < 0.5 { eased(2.0 * c) } else { eased(2.0 - 2.0 * c) }
}

/// numpy's interp: `x` on the points (xp, fp), held beyond them.
fn interp(x: f64, xp: &[f64], fp: &[f64]) -> f64 {
    let n = xp.len();
    if x <= xp[0] {
        return fp[0];
    }
    if x >= xp[n - 1] {
        return fp[n - 1];
    }
    let j = xp.partition_point(|&v| v <= x) - 1;
    if xp[j + 1] == xp[j] {
        return fp[j];
    }
    let slope = (fp[j + 1] - fp[j]) / (xp[j + 1] - xp[j]);
    slope * (x - xp[j]) + fp[j]
}

/// openwind_passages.py curve_at.
fn curve_at(points: &[[f64; 2]], t: f64) -> f64 {
    if t <= points[0][0] {
        return points[0][1];
    }
    for w in points.windows(2) {
        let ([a, x], [b, y]) = (w[0], w[1]);
        if t <= b {
            let span = if b - a == 0.0 { 1.0 } else { b - a };
            return x + (y - x) * (t - a) / span;
        }
    }
    points[points.len() - 1][1]
}

/// A time as played with its leads, and back (openwind_passages.py anticipation, windows_of): piecewise linear through
/// its anchors, on past its ends.
#[derive(Clone)]
struct Through {
    x: Vec<f64>,
    y: Vec<f64>,
}

impl Through {
    fn at(&self, t: f64) -> f64 {
        let (x, y) = (&self.x, &self.y);
        if t < x[0] {
            t - x[0] + y[0]
        } else if t > x[x.len() - 1] {
            t - x[x.len() - 1] + y[y.len() - 1]
        } else {
            interp(t, x, y)
        }
    }
}

struct Window {
    lo: f64,
    hi: f64,
    changes: Vec<usize>,
    fixed: bool,
}

fn windows_of(plan: &Plan) -> Result<Vec<Window>, String> {
    let a = plan.anticipation.as_ref().ok_or("a group led without its anticipation")?;
    let first = plan.first_risen.ok_or("a group led without its first rise")?;
    let cs = &plan.changes;
    let spans: Vec<[f64; 2]> = cs.iter().map(|c| c.span.unwrap_or([c.at - c.seconds / 2.0, c.at + c.seconds / 2.0])).collect();
    let mut windows = vec![Window { lo: 0.0, hi: first, changes: vec![], fixed: true }];
    for (i, &[s0, s1]) in spans.iter().enumerate() {
        let before = spans[..i].iter().map(|s| s[1]).fold(first, f64::max);
        let after = spans[i + 1..].iter().map(|s| s[0]).fold(plan.end, f64::min);
        let mut lo = s0.min((cs[i].at - a.window).max(s0 - a.reach * (s0 - before).max(0.0)));
        let mut hi = s1.max((cs[i].at + a.window).min(s1 + a.reach * (after - s1).max(0.0)));
        let (mut changes, mut fixed) = (vec![i], false);
        while windows.last().is_some_and(|w| lo <= w.hi) {
            let w = windows.pop().unwrap();
            lo = lo.min(w.lo);
            hi = hi.max(w.hi);
            changes = [w.changes, changes].concat();
            fixed = fixed || w.fixed;
        }
        windows.push(Window { lo, hi, changes, fixed });
    }
    Ok(windows)
}

fn anticipation(plan: &Plan, leads: &[f64]) -> Result<(Through, Through), String> {
    let cs = &plan.changes;
    let mut anchors = Vec::new();
    for w in windows_of(plan)? {
        let lead = if w.fixed { 0.0 } else { leads[cs[w.changes[0]].to] };
        anchors.push((w.lo, w.lo - lead));
        anchors.push((w.hi, w.hi - lead));
    }
    anchors.push((plan.end, plan.end));
    let kept: Vec<(f64, f64)> = anchors.iter().enumerate()
        .filter(|&(i, p)| i == 0 || anchors[..i].iter().all(|q| p.0 > q.0 && p.1 > q.1)).map(|(_, &p)| p).collect();
    let (xs, ys): (Vec<f64>, Vec<f64>) = kept.into_iter().unzip();
    Ok((Through { x: xs.clone(), y: ys.clone() }, Through { x: ys, y: xs }))
}

/// A model's law and its body, ready to shape its groups.
pub struct Shaper {
    pub law: Law,
    pub header: Header,
}

impl Shaper {
    /// A change of `kind`'s time: what is asked, never under its least (transitions.py seconds).
    fn seconds(&self, kind: &str, asked: f64) -> f64 {
        let least = self.law.transitions.get(kind).copied().unwrap_or(0.0);
        (if asked.is_finite() { asked } else { 0.0 }).max(least)
    }

    /// Its first note's breath rise (openwind_passages.py rise_of).
    fn rise_of(&self, note: &PlanNote) -> f64 {
        let held = (note.end - note.start).max(0.0);
        let attack = note.attack.filter(|a| a.is_finite()).unwrap_or(self.law.probe_rise);
        self.seconds("breathRise", attack.min(held / 2.0))
    }

    /// The group's controls. -> its Spec, or why it cannot be shaped.
    pub fn shape(&self, group: &Group) -> Result<Spec, String> {
        let (law, plan, items) = (&self.law, &group.plan, &group.notes);
        if items.is_empty() || items.len() != plan.notes.len() || items.len() != plan.entries.len() {
            return Err("a group's notes, its plan's notes and its entries must agree".into());
        }
        let rate = law.control_rate;
        let n = (group.seconds * rate).ceil() as usize + 2;
        let grid: Vec<f64> = (0..n).map(|i| i as f64 / rate).collect();
        let ahead = group.ahead;
        // (Its time as led, and back: openwind_passages.py anticipation.)
        let led = group.leads.as_ref().filter(|l| l.iter().any(|&x| x != 0.0));
        let (played, planned) = match led {
            Some(leads) => {
                let (p, q) = anticipation(plan, leads)?;
                (Some(p), Some(q))
            }
            None => (None, None),
        };
        let play = |t: f64| played.as_ref().map_or(t, |p| p.at(t));
        let plan_of = |t: f64| planned.as_ref().map_or(t, |p| p.at(t));
        // ---- passage_breath ----
        struct Moved {
            to: usize,
            at: f64,
            seconds: f64,
        }
        let changes: Vec<Moved> = plan.changes.iter().map(|c| Moved { to: c.to, at: play(c.at) + ahead, seconds: self.seconds("key", c.seconds) }).collect();
        let gaps = changes.windows(2).map(|w| w[1].at - w[0].at).filter(|&g| g > 0.0);
        let transition = changes.iter().map(|c| c.seconds).chain(gaps).fold(None, |m: Option<f64>, x| Some(m.map_or(x, |m| m.min(x))))
            .unwrap_or_else(|| self.seconds("key", f64::NAN));
        let mode = |k: usize| items[k].mode;
        let descends: Vec<bool> = (0..items.len()).map(|k| k > 0 && mode(k) < mode(k - 1)).collect();
        let r0 = self.rise_of(&plan.notes[0]);
        let level0 = curve_at(&plan.share, r0);
        let (times, shares): (Vec<f64>, Vec<f64>) = plan.share.iter().map(|p| (p[0], p[1])).unzip();
        let shape: Vec<f64> = grid.iter().map(|&t| {
            if t < r0 { eased(t / r0) * level0 } else if t < ahead + r0 { level0 } else { interp(plan_of(t - ahead), &times, &shares) }
        }).collect();
        let values: Vec<f64> = items.iter().map(|it| it.value).collect();
        let relaxed = (&plan.entries, &descends);
        let held = self.between(&grid, &changes.iter().map(|c| (c.to, c.at, c.seconds)).collect::<Vec<_>>(), &values, "breathRise", Some(relaxed));
        let mut breath: Vec<f64> = held.iter().zip(&shape).map(|(h, s)| h * s).collect();
        let swell = |a: f64, width: f64, kind: &str| -> Vec<f64> {
            let w = 2.0 * self.seconds(kind, width / 2.0);
            grid.iter().map(|&t| bump((t - a) / w)).collect()
        };
        // (Each note's technique in its breath, over its own span (technique.rs): a voice hummed or growled into it, a
        // fluttering tongue -- each taken up from its span's start and let go by its end, a technique's move each, a note
        // shorter than the two its technique let go after it.)
        let moving = self.seconds("technique", f64::NAN);
        for (k, it) in items.iter().enumerate() {
            let Some(t) = &it.technique else { continue };
            let (voiced, roll) = (t.voiced(), t.flutter);
            if voiced.is_none() && roll.is_none() {
                continue;
            }
            let a = play(plan.notes[k].start - plan.origin) + ahead;
            let b = (plan.notes[k].end - plan.origin + ahead).max(a + 2.0 * moving);
            let source = voiced.map(|v| voice_source(v.hz, b - a + 0.05, VOICE_RATE, v.rough, (plan.notes[k].start * 1000.0) as u64));
            for (i, &t) in grid.iter().enumerate() {
                if t < a || t > b {
                    continue;
                }
                let taken = eased((t - a) / moving) * (1.0 - eased((t - (b - moving)) / moving));
                if let (Some(v), Some(source)) = (voiced, &source) {
                    breath[i] += v.level * values[k] * shape[i] * taken * source_at(source, VOICE_RATE, t - a);
                }
                if let Some(r) = roll {
                    breath[i] *= 1.0 - r.depth * taken * (0.5 - 0.5 * (2.0 * std::f64::consts::PI * r.hz * (t - a)).cos()).powi(2);
                }
            }
        }
        // (A repeat's half attack, where its group's ear deepened it.)
        let touched: Vec<usize> = plan.tongues.iter().flatten().filter(|t| t.soft == Some(true)).map(|t| t.to).collect();
        for (k, it) in items.iter().enumerate() {
            let deeper = it.half;
            if deeper <= 0 || touched.contains(&k) || plan.entries[k] != "soft" {
                continue;
            }
            let on = play(plan.notes[k].start - plan.origin) + ahead;
            let width = 2.0 * self.seconds("tongueStop", law.half.seconds * law.half.step.powi(deeper - 1) / 2.0);
            let depth = law.half.most.min(law.half.depth * deeper as f64);
            let s = swell(on - width / 2.0, width, "tongueStop");
            for (b, x) in breath.iter_mut().zip(&s) {
                *b *= 1.0 - depth * x;
            }
        }
        // (An overblown note's attack kicked.)
        if mode(0) > 1 {
            let s = swell(0.0, r0 + law.kick_seconds, "breathRise");
            for (b, x) in breath.iter_mut().zip(&s) {
                *b *= 1.0 + law.attack_kick * x;
            }
        }
        for c in &changes {
            if plan.entries[c.to] == "tongued" && mode(c.to) > 1 {
                let s = swell(c.at - c.seconds / 2.0, c.seconds + law.kick_seconds, "breathRise");
                for (b, x) in breath.iter_mut().zip(&s) {
                    *b *= 1.0 + law.attack_kick * x;
                }
            }
        }
        // (A register's kick and dip, or an easing's dip.)
        for c in &changes {
            let it = &items[c.to];
            let level = law.register_levels.get(it.register.min(law.register_levels.len() - 1)).cloned().unwrap_or((0.0, None));
            let (kick, dip) = if it.eased > 0 { (0.0, law.ease_levels.get(it.eased).cloned().flatten()) } else { level };
            let done = c.at + c.seconds / 2.0;
            if let Some(d) = &dip {
                let (depth, length) = if d == "dip" { (law.dip[0], law.dip[1]) } else { (law.restart[0], law.restart[1]) };
                let length = 2.0 * self.seconds("breathRise", length / 2.0);
                let s = swell(done - length, length, "breathRise");
                for (b, x) in breath.iter_mut().zip(&s) {
                    *b *= 1.0 - depth * x;
                }
            }
            if kick != 0.0 {
                let (a, b) = if dip.is_some() { (done, done + law.kick_seconds) } else { (c.at - c.seconds / 2.0, done + law.kick_seconds) };
                let s = swell(a, b - a, "breathRise");
                for (v, x) in breath.iter_mut().zip(&s) {
                    *v *= 1.0 + kick * x;
                }
            }
        }
        // (Its tongue on its reed: tongue_shares, its first let go as tongue_let_go has it.)
        let mut shut: Option<Vec<f64>> = None;
        let tongues = plan.tongues.as_deref().unwrap_or(&[]);
        if !law.jet && !tongues.is_empty() {
            let first_go = self.tongue_let_go(&items[0], values[0] * level0, r0);
            let mut spans = vec![(-law.tongue.touch, first_go, None)];
            for t in tongues.iter().filter(|t| t.to > 0) {
                let (a, b) = (play(t.shut) + ahead, play(t.open) + ahead);
                if t.soft != Some(true) {
                    spans.push((a, b, None));
                    continue;
                }
                let levels = law.half.levels;
                let deeper = items[t.to].half.clamp(-levels, levels);
                let (middle, half) = ((a + b) / 2.0, (b - a) / 2.0 * law.half.step.powi(deeper));
                let (soft, closed) = (law.tongue.soft, law.tongue.shut);
                let left = if deeper >= 0 { soft * (closed / soft).powf(deeper as f64 / levels as f64) } else { 1.0 - (1.0 - soft) * law.half.step.powi(deeper) };
                spans.push((middle - half, middle + half, Some(left)));
            }
            shut = Some(self.tongue_shares(&grid, &spans));
        }
        // ---- simulate_passage_once ----
        let blown = breath.clone();
        let step = 1.0 / rate;
        let on_grid = |v: Vec<f64>| Curve::Grid { step, grid: v };
        let moves: Vec<(usize, f64, f64)> = changes.iter().map(|c| (c.to, c.at, c.seconds)).collect();
        let lipped = |per_note: &[f64]| self.between(&grid, &moves, per_note, "lips", None);
        let one = |per_note: &[f64]| -> Curve {
            if per_note.iter().any(|&v| v != per_note[0]) { on_grid(lipped(per_note)) } else { Curve::Held(per_note[0]) }
        };
        // (The fingerings: each note's, from its change's middle, mixed across the group's one transition.)
        let factors: Vec<Vec<f64>> = items.iter().map(|it| self.header.holes.iter().map(|h| it.fingering.get(h).copied().unwrap_or(0.0)).collect()).collect();
        let fingerings = if self.header.holes.is_empty() { None } else {
            let mut times = vec![0.0];
            times.extend(changes.iter().map(|c| c.at + transition / 2.0));
            Some(Fingerings { times, factors, transition, smooth: true })
        };
        let mut spec = Spec { columns: self.header.columns.clone(), fingerings, reeds: vec![], flutes: vec![], time: 0.0, half: self.header.half, seed: group.seed };
        if law.jet {
            spec.flutes.push(self.flute(items, &blown, &breath, &values, &lipped, &on_grid)?);
            return Ok(spec);
        }
        let base = |k: &str| -> Result<f64, String> {
            let reed = if law.measured { items[0].reed.as_ref().ok_or("a measured reed's note without its reed")? } else { &law.reed };
            reed.get(k).copied().ok_or_else(|| format!("the {}'s reed has no {k}", law.model))
        };
        let lips: Vec<f64> = items.iter().map(|it| it.lips).collect();
        let pulse = base("pulsation")?;
        let scaled = law.measured || law.reed.contains_key("zeta");
        let owns: Vec<f64> = lips.iter().map(|l| if scaled { pulse } else { pulse * l }).collect();
        let pulsations: Vec<f64> = owns.iter().zip(items).map(|(&own, it)| match it.embouchure {
            Some(e) if e != 0.0 => own.max(2.0 * std::f64::consts::PI * e * it.target),
            _ => own,
        }).collect();
        let moved = pulsations.iter().any(|&p| p != pulsations[0]) || pulsations[0] != pulse;
        let pulsation = if moved { one(&pulsations) } else { Curve::Held(pulse) };
        if scaled {
            let zetas: Vec<f64> = items.iter().map(|it| it.zeta.unwrap_or(0.0)).collect();
            let zeta = match &shut {
                Some(s) => on_grid(lipped(&zetas).iter().zip(s).map(|(z, s)| z * s).collect()),
                None => one(&zetas),
            };
            let per = |k: &str| -> Result<Vec<f64>, String> {
                items.iter().map(|it| it.reed.as_ref().and_then(|r| r.get(k)).copied().ok_or_else(|| format!("a measured note without its {k}"))).collect()
            };
            let closing = if law.measured { one(&per("closing_pressure")?) } else { Curve::Held(base("closing_pressure")?) };
            // (A measured reed's resting opening, each note's as its lips leave it: openwind_passages.py's.)
            let opening = if law.measured { Some(one(&per("opening")?)) } else { None };
            spec.reeds.push(Reed::Scaled {
                gamma: on_grid(breath), zeta, kappa: Curve::Held(base("kappa")?), pulsation, qfactor: Curve::Held(base("qfactor")?),
                contact_stifness: Curve::Held(base("contact_stifness")?), contact_exponent: Curve::Held(base("contact_exponent")?),
                model: Curve::Held(law.epsilon), closing_pressure: closing, opening,
            });
            return Ok(spec);
        }
        let reed_header = self.header.reed.as_ref().ok_or("a reed's body without its reed")?;
        let forces: Vec<f64> = items.iter().map(|it| it.force.unwrap_or(1.0)).collect();
        let opening = base("opening")?;
        let opening = if forces.iter().any(|&f| f != 1.0) { one(&forces.iter().map(|f| opening * f).collect::<Vec<_>>()) } else { Curve::Held(opening) };
        let width = base("width")?;
        let width = match &shut { Some(s) => on_grid(s.iter().map(|x| width * x).collect()), None => Curve::Held(width) };
        let (mass, dissip) = (base("mass")?, base("dissip")?);
        let (mass, dissip) = if moved {
            (one(&owns.iter().zip(&pulsations).map(|(o, p)| mass * (o / p).powi(2)).collect::<Vec<_>>()),
             one(&owns.iter().zip(&pulsations).map(|(o, p)| dissip * p / o).collect::<Vec<_>>()))
        } else { (Curve::Held(mass), Curve::Held(dissip)) };
        spec.reeds.push(Reed::Physical {
            section: Curve::Held(base("section")?), mass, dissip, pulsation, width, opening, model: Curve::Held(law.epsilon),
            mouth_pressure: on_grid(breath), contact_pulsation: Curve::Held(base("contact_pulsation")?),
            contact_exponent: Curve::Held(base("contact_exponent")?), zc: reed_header.zc, rho: reed_header.rho,
        });
        Ok(spec)
    }

    /// Each note's value over the grid, moved across each change about its middle along the raised cosine, over its
    /// change's time, never under `kind`'s least; `relaxed` (its entries and whether each note falls a register) a
    /// slur's fall of air moved before its fingers (openwind_passages.py between).
    fn between(&self, grid: &[f64], changes: &[(usize, f64, f64)], per_note: &[f64], kind: &str, relaxed: Option<(&Vec<String>, &Vec<bool>)>) -> Vec<f64> {
        let mut v = vec![per_note[0]; grid.len()];
        for &(j, at, seconds) in changes {
            let length = self.seconds(kind, seconds);
            let early = match relaxed {
                Some((entries, descends)) if entries[j] != "tongued" && (per_note[j] < self.law.relaxed * per_note[j - 1] || descends[j]) => length,
                _ => 0.0,
            };
            let from = at - early - length / 2.0;
            for (x, &t) in v.iter_mut().zip(grid) {
                *x += (per_note[j] - *x) * eased((t - from) / length);
            }
        }
        v
    }

    /// How much of a reed's opening its tongue leaves over the grid (openwind_worker.py tongue_shares).
    fn tongue_shares(&self, grid: &[f64], spans: &[(f64, f64, Option<f64>)]) -> Vec<f64> {
        let (touch, release, closed) = (self.law.tongue.touch, self.law.tongue.release, self.law.tongue.shut);
        let mut shares = vec![1.0f64; grid.len()];
        let mut free = f64::NEG_INFINITY;
        for &(a, b, left) in spans {
            let a = a.max(free);
            let b = b.max(a + touch);
            free = b + release;
            let left = left.unwrap_or(closed);
            for (s, &t) in shares.iter_mut().zip(grid) {
                let touched = eased((t - a) / touch) * (1.0 - eased((t - b) / release));
                *s = s.min(1.0 - (1.0 - left) * touched);
            }
        }
        shares
    }

    /// When a group's first tongue lets its reed go (openwind_passages.py tongue_let_go): as its rising breath reaches its
    /// note's threshold, where one is baked; else at its rise's end.
    fn tongue_let_go(&self, item: &NoteValues, breath: f64, rise: f64) -> f64 {
        let reed = &self.law.reed;
        let (Some(threshold), false, Some(mass)) = (item.threshold, self.law.measured, reed.get("mass")) else { return rise };
        if breath == 0.0 {
            return rise;
        }
        let force = item.tongue_force.unwrap_or(1.0);
        let closing = mass / reed["section"] * (reed["pulsation"] * item.lips).powi(2) * reed["opening"] * force;
        let share = threshold * closing / breath;
        if 0.0 < share && share < 1.0 { rise * ((1.0 - 2.0 * share.clamp(0.0, 1.0)).acos() / std::f64::consts::PI) } else { rise }
    }

    #[allow(clippy::too_many_arguments)]
    fn flute(&self, items: &[NoteValues], blown: &[f64], breath: &[f64], values: &[f64], lipped: &dyn Fn(&[f64]) -> Vec<f64>,
             on_grid: &dyn Fn(Vec<f64>) -> Curve) -> Result<Flute, String> {
        let law = &self.law;
        let body = self.header.flute.as_ref().ok_or("a jet's body without its flute")?;
        let reed = |k: &str| law.reed.get(k).copied();
        // (Its jet's length its notes' own at their middle (jet_of), its height its preset's; each note's own where its
        // law sets them, its solver's its first note's.)
        let jets = law.jet_length.as_ref().ok_or("a jet without its law")?;
        let middle = (items.iter().map(|it| it.target.ln()).sum::<f64>() / items.len() as f64).exp();
        let (mut height, mut length) = (reed("channel_height").unwrap_or(body.channel_height), jets.length / middle.sqrt() + jets.lead);
        let path = items.iter().all(|it| it.jet.is_some());
        if path {
            let first = items[0].jet.unwrap();
            height = first[0];
            length = first[1];
        }
        let (mut section, mut gain, mut convection) = (reed("section").unwrap_or(body.section), reed("gain").unwrap_or(body.gain), reed("convection").unwrap_or(body.convection));
        let (aspect, profile) = match &law.transverse {
            Some(t) => {
                section = items[0].uncovered.ok_or("a transverse flute's note without its uncovered share")? * t.hole;
                gain = t.aspect * height * length / section;
                convection = t.convection;
                (Some(t.aspect), Some(t.profile))
            }
            None => (None, None),
        };
        let floor = 0.01 * values.iter().copied().fold(f64::INFINITY, f64::min);
        let speed: Vec<f64> = breath.iter().map(|b| b.max(floor)).collect();
        let mut rolls: Vec<f64> = items.iter().map(|it| it.roll.or(law.roll).unwrap_or(1.0)).collect();
        if law.transverse.is_some() {
            let first = items[0].uncovered.unwrap_or(1.0);
            for (r, it) in rolls.iter_mut().zip(items) {
                *r *= (it.uncovered.unwrap_or(first) / first).sqrt();
            }
        }
        let rolling = rolls.iter().any(|&r| r != rolls[0]);
        let window = if rolling { on_grid(lipped(&rolls)) } else { Curve::Held(rolls[0]) };
        let jet = if path {
            Some((on_grid(lipped(&items.iter().map(|it| it.jet.unwrap()[0]).collect::<Vec<_>>())),
                  on_grid(lipped(&items.iter().map(|it| it.jet.unwrap()[1]).collect::<Vec<_>>()))))
        } else { None };
        let mut flute = Flute {
            jet_velocity: on_grid(speed), noise_level: Curve::Held(law.noise_level.unwrap_or(1e-4)), breath: Some(on_grid(blown.to_vec())),
            window, jet, held: [0.0; 5], celerity: body.celerity, aspect, profile, rolling,
            gain, loss_mag: reed("loss_mag").unwrap_or(body.loss_mag), section, convection,
            edge_offset: reed("edge_offset").unwrap_or(body.edge_offset), channel_height: height, width: length,
            edge_angle: body.edge_angle, wall_thickness: body.wall_thickness,
            inertance: if aspect.is_some() { None } else { body.inertance },
            two_point: match body.dipole.as_deref() {
                None | Some("verge") => false,
                Some("twopoint") => true,
                Some(other) => return Err(format!("a jet's dipole {other} (verge or twopoint)")),
            },
        };
        // (Its jet's parameters as its solver holds them: its first note's height and length, over the share of its
        // section its window leaves where it stands (window_of).)
        let cover = if aspect.is_some() && !rolling && (rolls[0] - 1.0).abs() > 1e-9 { rolls[0] * rolls[0] } else { 1.0 };
        flute.held = flute.jet_parameters(height, length, cover);
        Ok(flute)
    }
}

/// A model's player table (openwind_engine.py rules_table, design 5): each chromatic note's values at each velocity,
/// read between the velocities linearly.
#[derive(Deserialize, Clone, Debug)]
pub struct Table {
    pub kind: String,
    pub model: String,
    pub velocities: Vec<f64>,
    pub notes: Vec<TableNote>,
}

#[derive(Deserialize, Clone, Debug)]
pub struct TableNote {
    pub midi: f64,
    pub values: Vec<NoteValues>,
}

fn mix(a: f64, b: f64, w: f64) -> f64 {
    a + (b - a) * w
}

fn mix_option(a: Option<f64>, b: Option<f64>, w: f64) -> Option<f64> {
    match (a, b) {
        (Some(x), Some(y)) => Some(mix(x, y, w)),
        _ => a,
    }
}

impl Table {
    /// A note's values at `midi` (fractional) and `velocity` (0..1): its chromatic note's, between the velocities baked.
    /// -> why not, where its table has no such note (the rules' table plays its chart's chromatic notes only).
    pub fn at(&self, midi: f64, velocity: f64) -> Result<NoteValues, String> {
        let note = self.notes.iter().find(|n| (n.midi - midi).abs() <= 0.01)
            .ok_or_else(|| format!("the {}'s {} table has no note at {midi:.2}: its rules play its chart's chromatic notes only", self.model, self.kind))?;
        let v = &self.velocities;
        let x = velocity.clamp(v[0], v[v.len() - 1]);
        let k = (v.partition_point(|&u| u <= x)).clamp(1, v.len() - 1) - 1;
        let w = if v[k + 1] > v[k] { (x - v[k]) / (v[k + 1] - v[k]) } else { 0.0 };
        let (a, b) = (&note.values[k], &note.values[k + 1]);
        let mut out = a.clone();
        out.value = mix(a.value, b.value, w);
        out.lips = mix(a.lips, b.lips, w);
        out.embouchure = mix_option(a.embouchure, b.embouchure, w);
        out.force = mix_option(a.force, b.force, w);
        out.zeta = mix_option(a.zeta, b.zeta, w);
        out.threshold = mix_option(a.threshold, b.threshold, w);
        out.tongue_force = mix_option(a.tongue_force, b.tongue_force, w);
        out.roll = mix_option(a.roll, b.roll, w);
        out.uncovered = mix_option(a.uncovered, b.uncovered, w);
        if let (Some(x), Some(y)) = (a.jet, b.jet) {
            out.jet = Some([mix(x[0], y[0], w), mix(x[1], y[1], w)]);
        }
        if let (Some(x), Some(y)) = (&a.reed, &b.reed) {
            out.reed = Some(x.iter().map(|(k, &p)| (k.clone(), y.get(k).map_or(p, |&q| mix(p, q, w)))).collect());
        }
        Ok(out)
    }
}
