//! What a player does to start a note at its pitch, computed backward from that pitch on the engine's own equations (the
//! owner, 8 November 2026: "yes, all of that computed backward from a frequency profile matching the note at that
//! dynamic"; "except not modifying the instrument, only what the player does"; "there's no 'homing in', we need to
//! compute the fixed values that start and maintain each note at each dynamic"; research/OPENWIND_REALTIME_PLAN.md,
//! design 7, item 1). Nothing is played and nothing is tried from a starting point:
//! - the tube: its one step as the engine takes it, read as a linear map about rest (Player::bore_map: x' = B x + b w,
//!   its reed's no-flow pressure c x), and its answer at the note's pitch, G(z) = c (z - B)^-1 b at z = e^(j 2 pi f / rate),
//!   solved directly (sparse.rs: its order by reverse Cuthill-McKee, Gaussian elimination in its band); at nothing
//!   (z = 1), the pressure a steady flow holds at the reed;
//! - the tract: its sections' answer at the same z (Tract::answer_at);
//! - the reed: the engine's reed step (kernel.rs connect, T_REED) written out at rest and taken small there, as a
//!   function of its resting opening and of its columns, which the player's lip moves (the players' lip law, LipLaw,
//!   public/shared/performers/reed-lip.js lippedRow's, in Rust);
//! - the start: at the note's pitch, growing as fast as players' notes grow from rest (`growth`, its amplitude's rate: Li,
//!   Almeida, Smith & Wolfe 2016, doi:10.1121/1.4941660; nothing, where it would neither grow nor die, and so never
//!   speak -- the owner, 8 November 2026, of a G4 that spoke only when its breath's noise dipped it: "So, why didn't the
//!   solver compute it already?"), the reed exactly makes up what the tube and the tract take, in step with them -- one
//!   complex equation, two real ones, in the player's two unknowns, the lip's force and the breath (the breath through
//!   the reed's resting opening, which gives it explicitly). Where the lip moves only the reed's opening (a single
//!   reed's lip pressed, its damping not moved by it), both by arithmetic (by_arithmetic). Elsewhere, until the lips'
//!   own arithmetic is written (the owner: "we need to find a way to solve for the lips arithmetically"), every pair
//!   across the lip's whole range, to the force that shuts the reed's tip, and the reed's whole opening is computed at
//!   once and each crossing read off, then read again on a finer table inside its cell, until the cell is at rounding --
//!   a search, said so on each start (Start::how);
//! - where the reed shuts: the breath at which it rests shut at the start's lip (Start::shut), the most that breath can
//!   be;
//! - the tract, the third thing the player does (the owner, 8 November 2026: "Yes, add tract"): every shape its players
//!   keep it in (Tract's Shapes, vocal-tract-played.js's), its kept resonance across the shapes' whole range, each
//!   answering at the pitch; the same table taken with what the reed must make up there, its starts read off. Of all of
//!   them, and of those on the tract as it stands, the one that moves the player least from how they hold the note now,
//!   read again inside its cell until at rounding.
//! The instrument is never changed: its bore, its holes as the fingering sets them and its reed as built; only what the
//! player does is solved for.
use crate::kernel::{Player, ReedConstants};
use crate::sparse::{rcm, Banded, C};
use crate::tract::{Resonance, Shapes, Tract, TractShapes};
use serde::{Deserialize, Serialize};

/// A lip's damping (law.json lipDamping: woodwind_reeds.py lip_damping): the reed's damping at an opening y the note's
/// own times ((tip - y) / (tip - y0))^exponent.
#[derive(Deserialize, Serialize, Clone, Copy, Debug)]
pub struct Damping {
    pub tip: f64,
    pub exponent: f64,
}

/// The players' lip (public/shared/performers/reed-lip.js): the reed's scale (its bore's characteristic impedance `zc`,
/// its air's density `rho`, its reed's width, m), its players' lip (`area`, m^2; `lengthening`, 1/N) and its damping.
#[derive(Deserialize, Serialize, Clone, Copy, Debug)]
pub struct LipLaw {
    pub zc: f64,
    pub rho: f64,
    pub width: f64,
    pub area: f64,
    pub lengthening: f64,
    #[serde(default)]
    pub damping: Option<Damping>,
}

/// The most a lip may press past the note's own: this share of the force that shuts the reed's tip (reed-lip.js) -- ours,
/// not measured. The starts are not held under it: one past it is said (Start::past_most).
pub const PRESSED_MOST: f64 = 0.9;

/// A reed's columns as a row holds them (connect's T_REED: after its gamma at u, these at u + 1 ..= u + 8).
#[derive(Clone, Copy, Debug, Serialize)]
pub struct Reed {
    pub zeta: f64,
    pub kappa: f64,
    pub qr: f64,
    pub omegar: f64,
    pub kc: f64,
    pub alpha_c: f64,
    pub epsilon: f64,
    pub closing: f64,
}

impl Reed {
    pub fn of(row: &[f64], u: usize) -> Reed {
        Reed { zeta: row[u + 1], kappa: row[u + 2], qr: row[u + 3], omegar: row[u + 4], kc: row[u + 5], alpha_c: row[u + 6], epsilon: row[u + 7], closing: row[u + 8] }
    }

    /// Set into `row` at its reed's columns, its breath `gamma` (a share of its closing pressure) at u.
    pub fn into_row(&self, row: &mut [f64], u: usize, gamma: f64) {
        let v = [gamma, self.zeta, self.kappa, self.qr, self.omegar, self.kc, self.alpha_c, self.epsilon, self.closing];
        row[u..u + 9].copy_from_slice(&v);
    }

    /// Its lip `force` N past the note's own (negative: eased), as reed-lip.js lippedRow has it: the force closes the reed's
    /// tip as the mouth's pressure does over the lip's area, pressed no further than PRESSED_MOST of the force that shuts
    /// it; eased, the reed's vibrating length the longer by `lengthening` a newton, its pulsation as the length's inverse
    /// squared, its stiffness as its inverse cubed.
    pub fn lipped(&self, law: &LipLaw, force: f64) -> Reed {
        if force == 0.0 || force.is_nan() {
            return *self;
        }
        self.lipped_free(law, force.min(PRESSED_MOST * self.closing * law.area))
    }

    /// As `lipped`, pressed as far as `force` asks, past PRESSED_MOST to the force that shuts its tip: the starts'.
    pub fn lipped_free(&self, law: &LipLaw, force: f64) -> Reed {
        if force == 0.0 || force.is_nan() {
            return *self;
        }
        let (pc, wr) = (self.closing, self.omegar);
        let shutting = pc * law.area;
        let y0 = self.zeta * (law.rho * pc / 2.0).sqrt() / (law.zc * law.width);
        let sr = self.kappa * pc / (y0 * law.zc * wr);
        let g = wr / self.qr;
        let f = force;
        let lambda = 1.0 + law.lengthening * (-f).max(0.0);
        let y = y0 * (1.0 - f / shutting);
        let w = wr / (lambda * lambda);
        let s = sr * lambda;
        let closing = pc * y / (y0 * lambda.powi(4));
        let damped = law.damping.map_or(g, |d| g * ((d.tip - y) / (d.tip - y0)).powf(d.exponent));
        Reed {
            closing,
            omegar: w,
            qr: w / damped,
            zeta: law.zc * y * law.width * (2.0 / (law.rho * closing)).sqrt(),
            kappa: y * law.zc * s * w / closing,
            kc: self.kc * (wr / w) * (wr / w),
            ..*self
        }
    }
}

/// The reed at rest at a resting opening y (its opening's share of its opening with nothing against it), as its step
/// (connect's T_REED) has it there and taken small there: Delta p the pressure across its slit (its own units), s its
/// square root, kr its staple's share of it, the slit and the step's coefficients, each with its derivative in the
/// opening (_y); cn the step's constant at rest, and w its flow out of the bore over its flow's scale.
#[derive(Clone, Copy, Debug)]
pub(crate) struct Rest {
    dp: f64,
    s: f64,
    kr: f64,
    kr_y: f64,
    an: f64,
    an_y: f64,
    bn: f64,
    bn_y: f64,
    a_yn: f64,
    beta1: f64,
    beta2: f64,
    kp: f64,
    eps: f64,
    // (Pi - gamma at rest: its no-flow pressure less its breath, its own units; and its flow out over the flow's scale.)
    pub(crate) pi_less_gamma: f64,
    pub(crate) w_over: f64,
    // (The gain its own spring answers the pressure with, where its lay stiffens it (kernel.rs lay_contact); else 1.)
    gain: f64,
}

/// The reed's constant part, from its constants and columns: its scheme's coefficients (a_yn, b1, b2), its contact's
/// force at an opening (h, nothing where it is open but at alpha_c <= 1), lambda (Q_ZC over its end's alpha and Q_SIMP).
pub(crate) fn rested(r: &Reed, k: &ReedConstants, y: f64) -> Option<Rest> {
    let dt = r.omegar * k.dt;
    let dt2 = dt * dt;
    let theta = k.theta;
    // (Its contact's force while open (yn_minus nothing), as the step has it.)
    let yn_minus = 0.0f64;
    let h = if k.contact == 0.0 {
        if r.alpha_c > 1.0 { 0.0 } else { -0.5 * (2.0 * r.kc * (r.alpha_c + 1.0)).sqrt() * yn_minus.powf(r.alpha_c / 2.0 - 0.5) }
    } else if r.alpha_c > 0.0 {
        0.0
    } else {
        -r.kc * yn_minus.powf(r.alpha_c) / (k.contact + 2.0 * r.kc / (r.alpha_c + 1.0) * yn_minus.powf(r.alpha_c + 1.0)).sqrt()
    };
    // (Its lay's, where its lay stiffens it before its tip shuts (kernel.rs lay_contact, T_REED_LAY): its force at the
    // opening, that force's slope there, the gain its own spring answers the pressure with, and the contact's force
    // with it, over its variable.)
    let [onset, stiffness, exponent, given, wider] = k.lay;
    let reach = (onset - y).max(0.0);
    let (lay, slope, gain, opening) = if stiffness > 0.0 {
        (stiffness * reach.powf(exponent), if reach > 0.0 { stiffness * exponent * reach.powf(exponent - 1.0) } else { 0.0 }, given, wider)
    } else {
        (0.0, 0.0, 1.0, 1.0)
    };
    let h = if lay > 0.0 { -lay / (k.contact + 2.0 * stiffness / (exponent + 1.0) * reach.powf(exponent + 1.0)).sqrt() } else { h };
    // (Shut, y nothing, is a rest too: the breath that holds it there is the most a start's can be.)
    if !h.is_finite() || y < 0.0 {
        return None;
    }
    let a_yn = 1.0 / (1.0 / dt2 + 1.0 / (2.0 * r.qr * dt) + theta + 0.25 * h * h);
    let b1 = 2.0 / dt2 + 2.0 * theta - 1.0;
    let b2 = -(2.0 / dt2 + 2.0 * theta);
    let lambda = k.zc / (k.alpha * k.simp);
    // (Its slit and its reed's own flow as wide as its opening at rest is of its rules', where its lay stiffens it.)
    let kp = opening * r.kappa / (2.0 * dt);
    let eps = r.epsilon;
    let plain = k.exponent == 1.0 && k.leak == 0.0;
    let slit = (if plain { y } else { y.powf(k.exponent) + k.leak }) * (opening * r.zeta);
    let slit_y = (if plain { 1.0 } else { k.exponent * y.powf(k.exponent - 1.0) }) * (opening * r.zeta);
    // (A double reed's staple, its flow forward at rest.)
    let c2 = if k.constriction != 0.0 { k.constriction * r.closing * slit * slit } else { 0.0 };
    let c2_y = if k.constriction != 0.0 { k.constriction * r.closing * 2.0 * slit * slit_y } else { 0.0 };
    let (kr, kr_y) = if c2 != 0.0 {
        if c2 <= 1.0 { (1.0 - k.recovery * c2, -k.recovery * c2_y) } else { (c2 * (1.0 - k.recovery), (1.0 - k.recovery) * c2_y) }
    } else {
        (1.0, 0.0)
    };
    // (At rest its opening still: Delta y nothing, so that b_yn + eps a_yn Delta p / kr = 0, b_yn = a_yn (1 - y) -- its
    // contact's variable at rest from silence nothing; its lay's force with its spring's, the pressure's gain its own.)
    let dp = eps * kr * (y - 1.0 - lay) / gain;
    if !(dp > 0.0) || !(kr > 0.0) {
        return None;
    }
    let s = dp.sqrt();
    let an = lambda + gain * a_yn * kp / kr;
    let an_y = -gain * a_yn * kp * kr_y / (kr * kr);
    let bn = slit / kr.sqrt();
    let bn_y = slit_y / kr.sqrt() - slit * kr_y / (2.0 * kr * kr.sqrt());
    let cn = -(an * dp + bn * s);
    let b_rest = a_yn * (1.0 - y + lay);
    let pi_less_gamma = (cn - eps * b_rest * kp) / lambda;
    Some(Rest {
        dp,
        s,
        kr,
        kr_y,
        an,
        an_y,
        bn,
        bn_y,
        a_yn,
        // (Where its lay stiffens it, its force's slope too: what its contact's force over its variable changes by
        // with its opening, times that variable -- the slope less the force over the variable, squared.)
        beta1: b1 - 0.5 * h * h - if stiffness > 0.0 { slope - h * h } else { 0.0 },
        beta2: b2 - 0.5 * h * h,
        kp,
        eps,
        pi_less_gamma,
        w_over: lambda * (dp + pi_less_gamma),
        gain,
    })
}

impl Rest {
    /// K(z): from the step taken small at rest, its slit's drop P = -lambda (Pi - Gamma) / K(z), and so its flow out
    /// W = fs lambda (1 - lambda / K) (Pi - Gamma).
    pub(crate) fn k(&self, z: C) -> C {
        let zi = z.inv();
        let b = (C::new(self.beta1, 0.0) + zi * self.beta2) * self.a_yn;
        let d = z - zi - b + C::new(self.eps * self.gain * self.a_yn * self.dp * self.kr_y / (self.kr * self.kr), 0.0);
        let coupling = C::new(self.dp * self.an_y + self.s * self.bn_y, 0.0) + b * (self.eps * self.kp);
        C::new(self.an + self.bn / (2.0 * self.s), 0.0) + coupling * (self.eps * self.gain * self.a_yn / self.kr) / d
    }
}

/// The resting opening y, and the slit's zeta, at which a plain single reed (its slit as its opening, no leak, no staple)
/// with the columns of `r` but its zeta answers `q` at z -> (y, zeta), by arithmetic: its answer is K = A0 + zeta (y /
/// (2 s) + s E), s = sqrt(eps (y - 1)), A0 and E set by its columns but its zeta and by z, not by its opening (Rest::k
/// with kr 1); E's imaginary part gives zeta s, then its real part zeta y / (2 s), and their ratio y. None where it is not
/// plain, or no opening between shut and open answers q.
fn opening_for(r: &Reed, k: &ReedConstants, z: C, q: C) -> Option<(f64, f64)> {
    if k.exponent != 1.0 || k.leak != 0.0 || k.constriction != 0.0 || k.lay[1] > 0.0 {
        return None;
    }
    // (A0 and E at any opening: its middle.)
    let rest = rested(r, k, 0.5)?;
    let zi = z.inv();
    let b = (C::new(rest.beta1, 0.0) + zi * rest.beta2) * rest.a_yn;
    let e = C::new(rest.eps * rest.a_yn, 0.0) / (z - zi - b);
    let a0 = C::new(rest.an, 0.0) + b * (rest.eps * rest.kp) * e;
    let left = q - a0;
    if e.im == 0.0 {
        return None;
    }
    // (zeta s, and zeta y / (2 s).)
    let zs = left.im / e.im;
    let zy = left.re - zs * e.re;
    let eps = rest.eps;
    let y = -2.0 * eps * zy / (zs - 2.0 * eps * zy);
    if !(zs > 0.0 && zy > 0.0 && y > 0.0 && y < 1.0) {
        return None;
    }
    Some((y, zs / (eps * (y - 1.0)).sqrt()))
}

/// The start, by arithmetic, where the lip moves nothing but its reed's opening and its slit: its law without damping,
/// pressed (zeta = zeta0 sqrt(1 - F / S), S the force that shuts its tip, its other columns its own). Its opening and
/// zeta (opening_for), its force read back through the law, F = S (1 - (zeta / zeta0)^2) -> (force, closure). None
/// where its law damps the reed (the lips' arithmetic: not yet written), or its start asks its lip eased (its reed
/// lengthened), or none answers.
fn by_arithmetic(own: &Reed, k: &ReedConstants, law: &LipLaw, z: C, q: C) -> Option<(f64, f64)> {
    if law.damping.is_some() {
        return None;
    }
    let (y, zeta) = opening_for(own, k, z, q)?;
    let shutting = own.closing * law.area;
    let force = shutting * (1.0 - (zeta / own.zeta).powi(2));
    // (Its own lip, at rounding of nothing, is not eased.)
    (force > -1e-12 * shutting && force < shutting).then_some((force.max(0.0), 1.0 - y))
}

/// What is asked: the row held (the note's fingering, its reed's columns its own); the note's pitch (Hz, any: microtones
/// as they come); the lip's law, its force's range (N past the note's own) and how many forces and openings the tables
/// take; how many of its overtones' answers are given (for its dynamics: item 1's second half); whether it is checked
/// against the engine (Checked); and the shapes its players keep their tract in, read so many cents apart (none: its
/// tract as it stands alone).
pub struct Asked<'a> {
    pub row: &'a [f64],
    pub hz: f64,
    pub lip: Option<LipLaw>,
    pub forces: [f64; 2],
    pub force_steps: usize,
    pub opening_steps: usize,
    pub overtones: usize,
    pub checked: bool,
    pub tract: Option<&'a TractShapes>,
    pub tract_cents: f64,
}

/// A start: the lip's force (N past the note's own), the breath (Pa, and as a share of the lipped reed's closing
/// pressure), the reed's resting opening (its share), its closing pressure (Pa), the steady flow through it (m^3/s),
/// what is left of the equation there (|K/q - 1|), the tract it starts on (none: as it stands), and how far it moves
/// the player from how they hold the note now -- its lip, its breath and its tract, each a share of its whole range;
/// how it was found ('arithmetic', or 'table': read off the tables, a search); the breath at which its reed rests shut
/// at its lip (Pa: none can start it above); and whether its lip presses past PRESSED_MOST.
#[derive(Clone, Debug, Default, Serialize)]
pub struct Start {
    pub force: f64,
    pub breath: f64,
    pub gamma: f64,
    pub opening: f64,
    pub closing: f64,
    pub flow: f64,
    pub left: f64,
    pub tract: Option<TractAt>,
    pub moved: [f64; 3],
    pub how: String,
    pub shut: Option<f64>,
    pub past_most: bool,
}

/// A tract a start is made on: the way its players keep it ('normal', 'bend', or 'own' as it stands), the frequency its
/// kept resonance is asked at (Hz), and its resonances (given for the start chosen).
#[derive(Clone, Debug, Default, Serialize)]
pub struct TractAt {
    pub how: String,
    pub target: f64,
    pub resonances: Vec<Shaped>,
}

/// A tract's resonance as a start gives it: its frequency (Hz), its quality factor, its peak (Pa s/m^3).
#[derive(Clone, Copy, Debug, Default, Serialize)]
pub struct Shaped {
    pub frequency: f64,
    pub q: f64,
    pub peak: f64,
}

impl Shaped {
    fn of(r: &Resonance) -> Shaped {
        Shaped { frequency: r.frequency, q: r.q, peak: r.peak }
    }
}

/// The tube's answer at a frequency (Hz): its impedance at the reed (Pa s/m^3, re and im), as the engine plays it.
#[derive(Clone, Debug, Default, Serialize)]
pub struct Answer {
    pub hz: f64,
    pub re: f64,
    pub im: f64,
}

/// The tube's equations' size: the doubles a step moves, B's entries, and its band below and above once ordered.
#[derive(Clone, Debug, Default, Serialize)]
pub struct Sizes {
    pub moving: usize,
    pub entries: usize,
    pub below: usize,
    pub above: usize,
    pub map_seconds: f64,
    pub solve_seconds: f64,
}

/// The arithmetic checked against the engine (Asked::checked), at each start: the written reed against the engine's own
/// step taken small there (its rest's step from rest, relative, and its answer at the pitch, relative); the tube's
/// answer against the z-transform of its answer to one puff (relative); and the engine stepped there from rest, its reed
/// nudged: the growth (1/s) and the pitch (Hz) it sounds, nothing and the note's at a start.
#[derive(Clone, Debug, Default, Serialize)]
pub struct Checked {
    pub rest_off: f64,
    pub reed_off: f64,
    pub tube_off: f64,
    pub growth: Option<f64>,
    pub hz: Option<f64>,
    pub seconds: f64,
}

/// What was found: the note's pitch (Hz) and its own closing pressure (Pa); its starts on its tract as it stands, by
/// breath; where the tables came nearest one (its least |K/q - 1|), where they found none; the start that moves its
/// player least, on any of its tract's shapes or as it stands, at rounding; every start on its tract's shapes, at its
/// table's (its `left` says how near); the most its lip presses (N past the note's own); what the reed must make up at
/// the pitch with its tract as it stands, q (its own units: re, im); the tube's answers; its equations' size; the
/// checks (its starts', its nearest's, then the chosen's on its own tract); how long it took (s); the growth asked (its
/// amplitude's rate, 1/s); the breath at which its reed rests shut at the note's own lip (Pa); and the lip's force that
/// shuts its reed's tip with no breath (N past the note's own), the most its tables press it.
#[derive(Clone, Debug, Default, Serialize)]
pub struct Started {
    pub growth: f64,
    pub shut: Option<f64>,
    pub shutting: f64,
    pub hz: f64,
    pub closing: f64,
    pub starts: Vec<Start>,
    pub nearest: Option<Start>,
    pub chosen: Option<Start>,
    pub line: Vec<Start>,
    pub pressed_most: f64,
    pub q: [f64; 2],
    pub tube: Vec<Answer>,
    pub sizes: Sizes,
    pub checks: Vec<Checked>,
    pub seconds: f64,
}

// (The bore's map nudged by NUDGE of each field's largest where it is not at rest; a crossing read on finer tables of
// REFINE x REFINE inside its cell, at most LEVELS times, until its cell is CLOSED of the table's span.)
const NUDGE: f64 = 1e-6;
// (Its tract's shapes read this many cents apart where none is asked.)
const TRACT_CENTS: f64 = 5.0;
const REFINE: usize = 3;
const LEVELS: usize = 60;
const CLOSED: f64 = 1e-15;

/// What starts the note asked at `asked.row` (above), where it would neither grow nor die (`growing` at nothing).
pub fn starts(player: &mut Player, rate: f64, asked: &Asked) -> Result<Started, String> {
    growing(player, rate, asked, 0.0)
}

/// What starts the note asked at `asked.row` (above), growing from rest at `growth` (its amplitude's rate, 1/s). Its
/// player in doubles and on one thread; its tract settled at its resonances' ends; its doubles and its tract put back as
/// they stood.
pub fn growing(player: &mut Player, rate: f64, asked: &Asked, growth: f64) -> Result<Started, String> {
    if !growth.is_finite() {
        return Err(format!("a growth of {growth}/s"));
    }
    let since = std::time::Instant::now();
    let single = player.single() && !player.crewed();
    if single {
        player.in_doubles(true);
    }
    let tract = player.tract.clone();
    if let Some(t) = player.tract.as_mut() {
        t.settle();
    }
    let kept = player.data().to_vec();
    let found = started(player, rate, asked, growth);
    player.set_data(&kept);
    player.tract = tract;
    if single {
        player.in_doubles(false);
    }
    let mut found = found?;
    found.seconds = since.elapsed().as_secs_f64();
    Ok(found)
}

/// The tube's linear map about rest, ordered once, answering at any z: G(z) = c (z - B)^-1 b.
pub(crate) struct Tube {
    pub(crate) n: usize,
    pub(crate) entries: Vec<(usize, usize, f64)>,
    pub(crate) b: Vec<(usize, f64)>,
    pub(crate) c: Vec<(usize, f64)>,
    pub(crate) position: Vec<usize>,
    pub(crate) kl: usize,
    pub(crate) ku: usize, pub(crate) sparse: std::sync::OnceLock<(crate::sparse::Eliminated, Vec<usize>, Vec<C>, f64, f64)>,
}

impl Tube {
    pub(crate) fn of(map: crate::kernel::BoreMap) -> Tube {
        let n = map.moving.len();
        let entries: Vec<(usize, usize, f64)> = map.cols.iter().enumerate().flat_map(|(j, col)| col.iter().map(move |&(i, v)| (i, j, v))).collect();
        let mut pattern: Vec<(usize, usize)> = entries.iter().map(|&(i, j, _)| (i, j)).collect();
        pattern.extend((0..n).map(|i| (i, i)));
        let order = rcm(n, &pattern);
        let mut position = vec![0; n];
        for (p, &o) in order.iter().enumerate() {
            position[o] = p;
        }
        let (mut kl, mut ku) = (0, 0);
        for &(i, j) in &pattern {
            let (pi, pj) = (position[i], position[j]);
            kl = kl.max(pi.saturating_sub(pj));
            ku = ku.max(pj.saturating_sub(pi));
        }
        Tube { n, entries, b: map.b, c: map.c, position, kl, ku, sparse: std::sync::OnceLock::new() }
    }

    /// G(z), solved directly.
    pub(crate) fn at(&self, z: C) -> Result<C, String> {
        let mut m = Banded::new(self.n, self.kl, self.ku);
        for i in 0..self.n {
            m.add(self.position[i], self.position[i], z);
        }
        for &(i, j, v) in &self.entries {
            m.add(self.position[i], self.position[j], C::new(-v, 0.0));
        }
        m.lu()?;
        let mut rhs = vec![C::default(); self.n];
        for &(i, v) in &self.b {
            rhs[self.position[i]] = C::new(v, 0.0);
        }
        let x = m.solve(&rhs);
        Ok(self.c.iter().fold(C::default(), |s, &(i, v)| s + x[self.position[i]] * v))
    }
}

fn started(player: &mut Player, rate: f64, asked: &Asked, growth: f64) -> Result<Started, String> {
    let place = player.reed_place()?;
    let k = player.reed_constants()?;
    if k.lips {
        return Err("lips' starts are not yet written out (their inward mode)".into());
    }
    let (u, row) = (place.columns, asked.row);
    if row.len() <= u + 8 {
        return Err("a row without its reed's columns".into());
    }
    if !(asked.hz > 0.0 && asked.hz < rate / 2.0) {
        return Err(format!("a pitch between nothing and half its rate ({} Hz)", rate / 2.0));
    }
    let own = Reed::of(row, u);
    // (The tube: its map about rest, its answer at the pitch, its overtones and at nothing.)
    let since = std::time::Instant::now();
    let map = player.bore_map(row, 0.0, NUDGE, true)?;
    let map_seconds = since.elapsed().as_secs_f64();
    let since = std::time::Instant::now();
    let tube = Tube::of(map);
    let angle = |f: f64| 2.0 * std::f64::consts::PI * f / rate;
    // (Its note growing from rest at `growth`: the equation taken at z = e^((growth + j 2 pi f) / rate), off the unit
    // circle by its growth a step.)
    let zt = C::polar((growth / rate).exp(), angle(asked.hz));
    let g = tube.at(zt)?;
    let g1 = tube.at(C::new(1.0, 0.0))?.re;
    // (The tube's answers said at the pitch itself, on the unit circle.)
    let mut answers = vec![(asked.hz, if growth == 0.0 { g } else { tube.at(C::polar(1.0, angle(asked.hz)))? })];
    for h in 2..=asked.overtones + 1 {
        let f = asked.hz * h as f64;
        if f < rate / 2.0 {
            answers.push((f, tube.at(C::polar(1.0, angle(f)))?));
        }
    }
    let solve_seconds = since.elapsed().as_secs_f64();
    let scale = place.pressure / place.flow;
    let tube_answers = answers.iter().map(|&(hz, g)| {
        let z = (C::new(place.alpha, 0.0) - g) * scale;
        Answer { hz, re: z.re, im: z.im }
    }).collect();
    // (The tract at the pitch, read a step late.)
    let h = player.tract.as_ref().map_or(C::default(), |t| {
        let (re, im) = t.answer_at(zt.re, zt.im);
        C::new(re, im)
    });
    // (What the reed must make up with a tract answering h: Lt = lambda (G sp - z^-1 h flowscale) / (zc sf), and
    // K = q = lambda Lt / (Lt - 1).)
    let lambda = k.zc / (k.alpha * k.simp);
    let q_of = |h: C| {
        let lt = (g * k.sp - zt.inv() * h * k.flowscale) * (lambda / (k.zc * k.sf));
        lt * lambda / (lt - C::new(1.0, 0.0))
    };
    let q = q_of(h);
    // (Its breath at rest: gamma = Pi - (Pi - gamma), Pi the no-flow pressure the steady flow holds, G(1) w / ps; the
    // tract's answer at nothing is none.)
    let gamma_of = |rest: &Rest| g1 * rest.w_over * k.sp / (k.zc * k.sf) - rest.pi_less_gamma;
    // (Its reed at a lip's force: pressed as far as asked, to the force that shuts its tip, or eased; none where it is
    // left no opening.)
    let reed_at = |force: f64| -> Option<Reed> {
        let r = asked.lip.map_or(own, |law| own.lipped_free(&law, force));
        (r.closing > 0.0 && r.zeta > 0.0 && r.zeta.is_finite() && r.qr > 0.0 && r.qr.is_finite() && r.omegar > 0.0).then_some(r)
    };
    // (The reed's answer at the pitch, K, at a force and a closure; and over what it must make up.)
    let kk = |force: f64, closure: f64| -> Option<C> {
        let r = reed_at(force)?;
        Some(rested(&r, &k, 1.0 - closure)?.k(zt))
    };
    let e = |force: f64, closure: f64| -> Option<C> { Some(kk(force, closure)? / q - C::new(1.0, 0.0)) };
    // (Where its reed shuts at a lip's force: the breath that holds it at rest shut, Pa.)
    let shut_at = |force: f64| -> Option<f64> {
        let r = reed_at(force)?;
        Some(gamma_of(&rested(&r, &k, 0.0)?) * r.closing)
    };
    let Some(law) = asked.lip else {
        return Err("its players' lip has no law: the breath alone does not set the pitch".into());
    };
    // (Its lip pressed as far as the force that shuts its reed's tip with no breath; past PRESSED_MOST, said.)
    let shutting = own.closing * law.area;
    let pressed_most = PRESSED_MOST * shutting;
    let (lo, hi) = (asked.forces[0], asked.forces[1].min(shutting));
    // (By arithmetic where its lip moves only its reed's opening (by_arithmetic); else, or where that start asks its lip
    // eased, the tables: forces across the lip's range, and the reed's closure at rest from none, left out, to shut -- a
    // start just open of shut read in the last cell, as a breath just under where its reed shuts starts it.)
    let arithmetic = |q: C| by_arithmetic(&own, &k, &law, zt, q).filter(|&(f, _)| f >= lo && f <= hi);
    let by_formula = arithmetic(q);
    let tabled = by_formula.is_none();
    let steps = asked.force_steps.max(2);
    let forces: Vec<f64> = (0..steps).map(|j| lo + (hi - lo) * j as f64 / (steps - 1) as f64).collect();
    let closures: Vec<f64> = (1..=asked.opening_steps).map(|i| i as f64 / asked.opening_steps as f64).collect();
    let ks: Vec<Vec<Option<C>>> = if tabled { forces.iter().map(|&f| closures.iter().map(|&c| kk(f, c)).collect()).collect() } else { vec![] };
    let table: Vec<Vec<Option<C>>> = ks.iter().map(|r| r.iter().map(|v| v.map(|v| v / q - C::new(1.0, 0.0))).collect()).collect();
    let mut found: Vec<(f64, f64, &str)> = by_formula.map(|(f, c)| vec![(f, c, "arithmetic")]).unwrap_or_default();
    for j in 1..table.len() {
        for i in 1..closures.len() {
            let cell = [table[j - 1][i - 1], table[j - 1][i], table[j][i - 1], table[j][i]];
            if cell.iter().any(|v| v.is_none()) {
                continue;
            }
            let cell: Vec<C> = cell.iter().map(|v| v.unwrap()).collect();
            if crossing(&cell).is_some() {
                if let Some(p) = refine(&e, [forces[j - 1], forces[j]], [closures[i - 1], closures[i]]) {
                    found.push((p.0, p.1, "table"));
                }
            }
        }
    }
    let nearest = if found.is_empty() {
        let mut best: Option<(f64, f64, f64)> = None;
        for (j, r) in table.iter().enumerate() {
            for (i, v) in r.iter().enumerate() {
                if let Some(v) = v {
                    if best.is_none_or(|b| v.abs() < b.2) {
                        best = Some((forces[j], closures[i], v.abs()));
                    }
                }
            }
        }
        best.map(|b| (b.0, b.1))
    } else {
        None
    };
    let start_at = |force: f64, closure: f64, q: C, how: &str| -> Option<Start> {
        let r = reed_at(force)?;
        let rest = rested(&r, &k, 1.0 - closure)?;
        let gamma = gamma_of(&rest);
        let fs = r.closing / (k.zc * k.sf);
        Some(Start {
            force,
            breath: gamma * r.closing,
            gamma,
            opening: 1.0 - closure,
            closing: r.closing,
            flow: -rest.w_over * fs * k.flowscale,
            left: (rest.k(zt) / q - C::new(1.0, 0.0)).abs(),
            how: how.into(),
            shut: shut_at(force),
            past_most: force > pressed_most,
            ..Start::default()
        })
    };
    // (How far a start moves its player from how they hold the note now: its lip's force over the lip's whole range, its
    // breath from the note's own over its closing pressure, and its tract's kept resonance -- its second, the one its
    // players keep (Chen, Smith & Wolfe 2009) -- in octaves of its frequency and of its height, each over the shapes'
    // whole span of it, the two together the root of their squares; all three together, the root of their squares.)
    let own_breath = row[u] * own.closing;
    let now: Option<Vec<Resonance>> = player.tract.as_ref().map(|t| t.now());
    let now_kept = now.as_ref().and_then(|rs| rs.get(1).copied());
    let ways: Vec<(&str, &Shapes)> = match (asked.tract, now_kept) {
        (Some(t), Some(_)) => [("normal", t.normal.as_ref()), ("bend", t.bend.as_ref())]
            .into_iter()
            .filter_map(|(how, shapes)| shapes.filter(|s| s.rows.len() >= 2).map(|s| (how, s)))
            .collect(),
        _ => vec![],
    };
    let kepts: Vec<Resonance> = ways.iter().flat_map(|(_, s)| s.rows.iter().filter_map(|r| r.resonances.get(1).copied())).collect();
    let span = |of: fn(&Resonance) -> f64| {
        let (least, most) = kepts.iter().map(of).fold((f64::INFINITY, 0.0_f64), |(a, b), x| (a.min(x), b.max(x)));
        (most / least).log2()
    };
    let (f_span, p_span) = (span(|r| r.frequency), span(|r| r.peak));
    let tract_moved = |rs: &[Resonance]| match (now_kept, rs.get(1)) {
        (Some(a), Some(b)) => (((b.frequency / a.frequency).log2() / f_span).powi(2) + ((b.peak / a.peak).log2() / p_span).powi(2)).sqrt(),
        _ => 0.0,
    };
    let moved_by = |s: &Start, tract: f64| [s.force.abs() / (hi - lo), (s.breath - own_breath).abs() / own.closing, tract];
    let total = |s: &Start| s.moved.iter().map(|m| m * m).sum::<f64>().sqrt();
    let as_it_stands = |resonances: Vec<Shaped>| TractAt { how: "own".into(), target: now_kept.map_or(0.0, |r| r.frequency), resonances };
    let nearest = nearest.and_then(|(f, c)| start_at(f, c, q, "table")).map(|mut s| {
        s.moved = moved_by(&s, 0.0);
        s.tract = now.as_ref().map(|_| as_it_stands(vec![]));
        s
    });
    let mut starts: Vec<Start> = found
        .iter()
        .filter_map(|&(force, closure, how)| start_at(force, closure, q, how))
        .map(|mut s| {
            s.moved = moved_by(&s, 0.0);
            s.tract = now.as_ref().map(|_| as_it_stands(vec![]));
            s
        })
        .collect();
    starts.sort_by(|a, b| a.breath.total_cmp(&b.breath));
    // (The tract's shapes: each cell's two triangles of K taken linear, once; at each shape, every triangle that takes
    // what the reed must make up there read off, a cell once.)
    struct Tri {
        j: usize,
        i: usize,
        p: [(f64, f64); 3],
        e0: C,
        a: C,
        b: C,
        det: f64,
        least: (f64, f64),
        most: (f64, f64),
    }
    let mut tris: Vec<Tri> = vec![];
    if !ways.is_empty() {
        for j in 1..ks.len() {
            for i in 1..closures.len() {
                let v = [ks[j - 1][i - 1], ks[j - 1][i], ks[j][i - 1], ks[j][i]];
                if v.iter().any(|x| x.is_none()) {
                    continue;
                }
                let v: Vec<C> = v.iter().map(|x| x.unwrap()).collect();
                for t in [[(0.0, 0.0, v[0]), (1.0, 0.0, v[2]), (0.0, 1.0, v[1])], [(1.0, 1.0, v[3]), (0.0, 1.0, v[1]), (1.0, 0.0, v[2])]] {
                    let (a, b) = (t[1].2 - t[0].2, t[2].2 - t[0].2);
                    let det = a.re * b.im - a.im * b.re;
                    if det == 0.0 || !det.is_finite() {
                        continue;
                    }
                    let (res, ims) = ([t[0].2.re, t[1].2.re, t[2].2.re], [t[0].2.im, t[1].2.im, t[2].2.im]);
                    let low = |x: [f64; 3]| x[0].min(x[1]).min(x[2]);
                    let high = |x: [f64; 3]| x[0].max(x[1]).max(x[2]);
                    tris.push(Tri {
                        j,
                        i,
                        p: [(t[0].0, t[0].1), (t[1].0, t[1].1), (t[2].0, t[2].1)],
                        e0: t[0].2,
                        a,
                        b,
                        det,
                        least: (low(res), low(ims)),
                        most: (high(res), high(ims)),
                    });
                }
            }
        }
    }
    let cents = if asked.tract_cents > 0.0 { asked.tract_cents } else { TRACT_CENTS };
    // (Each start on a shape with the table's cell it was read in, none where it came by arithmetic.)
    let mut line: Vec<(Start, Option<(usize, usize)>, C, Vec<Resonance>)> = vec![];
    for &(how, shapes) in &ways {
        let (first, last) = (shapes.rows[0].target, shapes.rows[shapes.rows.len() - 1].target);
        let n = (1200.0 * (last / first).log2() / cents).floor() as usize + 1;
        for m in 0..n {
            let target = first * 2f64.powf(m as f64 * cents / 1200.0);
            let rs = shapes.played(target);
            let mut t = Tract::new(rate);
            t.set(rs.clone(), 0.0);
            let (hr, him) = t.answer_at(zt.re, zt.im);
            let qt = q_of(C::new(hr, him));
            if let Some(mut st) = arithmetic(qt).and_then(|(force, closure)| start_at(force, closure, qt, "arithmetic")) {
                st.moved = moved_by(&st, tract_moved(&rs));
                st.tract = Some(TractAt { how: how.into(), target, resonances: vec![] });
                line.push((st, None, qt, rs.clone()));
                continue;
            }
            let mut cells = std::collections::HashSet::new();
            for tri in &tris {
                if qt.re < tri.least.0 || qt.re > tri.most.0 || qt.im < tri.least.1 || qt.im > tri.most.1 {
                    continue;
                }
                let r = qt - tri.e0;
                let s = (r.re * tri.b.im - r.im * tri.b.re) / tri.det;
                let w = (tri.a.re * r.im - tri.a.im * r.re) / tri.det;
                if s < 0.0 || w < 0.0 || s + w > 1.0 || !cells.insert((tri.j, tri.i)) {
                    continue;
                }
                let fshare = tri.p[0].0 + s * (tri.p[1].0 - tri.p[0].0) + w * (tri.p[2].0 - tri.p[0].0);
                let cshare = tri.p[0].1 + s * (tri.p[1].1 - tri.p[0].1) + w * (tri.p[2].1 - tri.p[0].1);
                let force = forces[tri.j - 1] + fshare * (forces[tri.j] - forces[tri.j - 1]);
                let closure = closures[tri.i - 1] + cshare * (closures[tri.i] - closures[tri.i - 1]);
                if let Some(mut st) = start_at(force, closure, qt, "table") {
                    st.moved = moved_by(&st, tract_moved(&rs));
                    st.tract = Some(TractAt { how: how.into(), target, resonances: vec![] });
                    line.push((st, Some((tri.j, tri.i)), qt, rs.clone()));
                }
            }
        }
    }
    // (Of the starts on its tract as it stands and on every shape, the one that moves its player least: a shape's read
    // again inside its cell, at its own shape, until at rounding.)
    let mut chosen: Option<Start> = starts.iter().min_by(|a, b| total(a).total_cmp(&total(b))).cloned();
    let mut chosen_tract: Option<Vec<Resonance>> = None;
    if let Some((st, cell, qt, rs)) = line.iter().min_by(|a, b| total(&a.0).total_cmp(&total(&b.0))) {
        if chosen.as_ref().is_none_or(|c| total(st) < total(c)) {
            let qt = *qt;
            let e_t = |force: f64, closure: f64| -> Option<C> { Some(kk(force, closure)? / qt - C::new(1.0, 0.0)) };
            let exact = cell.and_then(|(j, i)| {
                refine(&e_t, [forces[j - 1], forces[j]], [closures[i - 1], closures[i]]).and_then(|(f, c)| start_at(f, c, qt, "table"))
            });
            let mut s = exact.unwrap_or_else(|| st.clone());
            s.moved = moved_by(&s, tract_moved(rs));
            let at = st.tract.as_ref().map_or((String::new(), 0.0), |t| (t.how.clone(), t.target));
            s.tract = Some(TractAt { how: at.0, target: at.1, resonances: rs.iter().map(Shaped::of).collect() });
            chosen = Some(s);
            chosen_tract = Some(rs.clone());
        }
    }
    let mut checks = vec![];
    if asked.checked {
        for s in starts.iter().chain(&nearest) {
            let r = reed_at(s.force).ok_or("its start's reed has no opening")?;
            checks.push(check(player, rate, asked, &k, u, &r, s, g, g1, zt)?);
        }
        if let (Some(s), Some(rs)) = (&chosen, &chosen_tract) {
            let r = reed_at(s.force).ok_or("its start's reed has no opening")?;
            let kept = player.tract.clone();
            let mut t = Tract::new(rate);
            t.set(rs.clone(), 0.0);
            player.tract = Some(t);
            let checked = check(player, rate, asked, &k, u, &r, s, g, g1, zt);
            player.tract = kept;
            checks.push(checked?);
        }
    }
    let line: Vec<Start> = line.into_iter().map(|l| l.0).collect();
    Ok(Started {
        growth,
        shut: shut_at(0.0),
        shutting,
        hz: asked.hz,
        closing: own.closing,
        starts,
        nearest,
        chosen,
        line,
        pressed_most,
        q: [q.re, q.im],
        tube: tube_answers,
        sizes: Sizes { moving: tube.n, entries: tube.entries.len(), below: tube.kl, above: tube.ku, map_seconds, solve_seconds },
        checks,
        seconds: 0.0,
    })
}

/// Where in a cell of the table (its corners' values: (0,0), (0,1), (1,0), (1,1) -- force, then closure) both parts of
/// the equation cross nothing, on either of its two triangles taken linear -> the point, as shares of the cell's sides,
/// and how far outside its triangle it lies (nothing inside).
fn crossing(v: &[C]) -> Option<(f64, f64)> {
    // (Triangles (0,0),(1,0),(0,1) and (1,1),(0,1),(1,0), corners as (force, closure) shares.)
    let tris = [[(0.0, 0.0, v[0]), (1.0, 0.0, v[2]), (0.0, 1.0, v[1])], [(1.0, 1.0, v[3]), (0.0, 1.0, v[1]), (1.0, 0.0, v[2])]];
    let mut best: Option<(f64, f64, f64)> = None;
    for t in &tris {
        let (e0, e1, e2) = (t[0].2, t[1].2, t[2].2);
        let (a, b) = (e1 - e0, e2 - e0);
        let det = a.re * b.im - a.im * b.re;
        if det == 0.0 || !det.is_finite() {
            continue;
        }
        let (r0, r1) = (-e0.re, -e0.im);
        let s = (r0 * b.im - r1 * b.re) / det;
        let w = (a.re * r1 - a.im * r0) / det;
        let outside = (-s).max(0.0) + (-w).max(0.0) + (s + w - 1.0).max(0.0);
        let p = (t[0].0 + s * (t[1].0 - t[0].0) + w * (t[2].0 - t[0].0), t[0].1 + s * (t[1].1 - t[0].1) + w * (t[2].1 - t[0].1));
        if best.is_none_or(|b| outside < b.2) {
            best = Some((p.0, p.1, outside));
        }
    }
    best.filter(|b| b.2 == 0.0).map(|b| (b.0, b.1))
}

/// A crossing inside the cell of forces `f` and closures `c`, read on finer tables (REFINE x REFINE) inside it until its
/// cell is CLOSED of its span -> (force, closure). At each level, the finer cell whose triangles cross, else the one
/// whose crossing lies least outside.
fn refine(e: &dyn Fn(f64, f64) -> Option<C>, mut f: [f64; 2], mut c: [f64; 2]) -> Option<(f64, f64)> {
    let span = ((f[1] - f[0]).abs(), (c[1] - c[0]).abs());
    for _ in 0..LEVELS {
        let fs: Vec<f64> = (0..=REFINE).map(|j| f[0] + (f[1] - f[0]) * j as f64 / REFINE as f64).collect();
        let cs: Vec<f64> = (0..=REFINE).map(|i| c[0] + (c[1] - c[0]) * i as f64 / REFINE as f64).collect();
        let mut t = vec![vec![None; REFINE + 1]; REFINE + 1];
        for j in 0..=REFINE {
            for i in 0..=REFINE {
                t[j][i] = e(fs[j], cs[i]);
            }
        }
        let mut chosen: Option<(usize, usize, f64)> = None;
        for j in 1..=REFINE {
            for i in 1..=REFINE {
                let cell = [t[j - 1][i - 1], t[j - 1][i], t[j][i - 1], t[j][i]];
                if cell.iter().any(|v| v.is_none()) {
                    continue;
                }
                let cell: Vec<C> = cell.iter().map(|v| v.unwrap()).collect();
                let outside = outside_of(&cell);
                if chosen.is_none_or(|c| outside < c.2) {
                    chosen = Some((j, i, outside));
                }
            }
        }
        let (j, i, _) = chosen?;
        f = [fs[j - 1], fs[j]];
        c = [cs[i - 1], cs[i]];
        if (f[1] - f[0]).abs() <= CLOSED * span.0.max(1.0) && (c[1] - c[0]).abs() <= CLOSED * span.1.max(1.0) {
            break;
        }
    }
    Some((0.5 * (f[0] + f[1]), 0.5 * (c[0] + c[1])))
}

/// How far outside its cell the crossing its triangles take linear lies (nothing where it lies inside).
fn outside_of(v: &[C]) -> f64 {
    let tris = [[v[0], v[2], v[1]], [v[3], v[1], v[2]]];
    let mut least = f64::INFINITY;
    for t in &tris {
        let (a, b) = (t[1] - t[0], t[2] - t[0]);
        let det = a.re * b.im - a.im * b.re;
        if det == 0.0 || !det.is_finite() {
            continue;
        }
        let (r0, r1) = (-t[0].re, -t[0].im);
        let s = (r0 * b.im - r1 * b.re) / det;
        let w = (a.re * r1 - a.im * r0) / det;
        least = least.min((-s).max(0.0) + (-w).max(0.0) + (s + w - 1.0).max(0.0));
    }
    least
}

/// The bore's answer to a puff, as a transform: g[k] its no-flow pressure k + 1 steps after a unit of flow out, so that
/// G(z) = sum g[k] z^-(k+1) (Checked: the direct solve against it).
fn puffed(g: &[f64], z: C) -> C {
    let w = z.inv();
    let mut s = C::default();
    for &x in g.iter().rev() {
        s = s * w + C::new(x, 0.0);
    }
    w * s
}

// (The checks: the engine's reed step taken small by central differences, each quantity nudged by STEP_NUDGE of its
// size; the bore's answer to a puff of PUFF of the start's flow, read in blocks of BLOCK s until the last block's share
// of its energy is under QUIET, for at most MOST s; the engine held steady under the start's flow for SETTLE s, then
// stepped from rest with its reed's opening nudged by NUDGED for CHECKED s at most, until its opening has swung SMALL
// from its rest (its own unit, the reed open at rest with no breath) -- past it, no longer small, its growth slows as it
// nears its held note, and its pitch moves to the held note's -- its growth and pitch read from its sound's steps
// demodulated at the note's pitch over WINDOW of its periods, a period apart, after the first share EARLY, READ readings
// at least. Any window reads one start's growth and pitch exactly; a longer one shuts out the others its nudge sets
// going, above all the register above's, which its steps' differences weigh by their pitch: over two periods the
// clarinet's found body's G4 read 1.0e-3 off its equation's growth and 0.016 Hz off its pitch, by level of either sign;
// over six, within 5e-5 and 7e-4 Hz.)
const STEP_NUDGE: f64 = 1e-5;
const PUFF: f64 = 1e-6;
const BLOCK: f64 = 0.01;
const QUIET: f64 = 1e-24;
const MOST: f64 = 6.0;
const SETTLE: f64 = 1.0;
const NUDGED: f64 = 1e-8;
const CHECKED: f64 = 0.3;
const SMALL: f64 = 1e-3;
const WINDOW: f64 = 6.0;
const LEAST_WINDOW: f64 = 2.0;
const READ: usize = 4;
const EARLY: f64 = 0.4;

#[allow(clippy::too_many_arguments)]
fn check(player: &mut Player, rate: f64, asked: &Asked, k: &ReedConstants, u: usize, reed: &Reed, s: &Start, g: C, g1: f64, zt: C) -> Result<Checked, String> {
    let mut row = asked.row.to_vec();
    reed.into_row(&mut row, u, s.gamma);
    let rest = rested(reed, k, s.opening).ok_or("its start has no rest")?;
    let fs = reed.closing / (k.zc * k.sf);
    let ps = reed.closing / k.sp;
    let w = rest.w_over * fs;
    let pnf = g1 * w;
    // (Its state at rest: its opening still, its contact's variable nothing, its tract held by the steady flow.)
    let mut tract = player.tract.clone();
    // (Its contact's variable at rest: nothing while nothing touches the reed; on its lay, the root of its contact's
    // constant and twice the lay's potential there -- kernel.rs lay_contact -- so that the lay's force holds it.)
    let [onset, stiffness, exponent, ..] = k.lay;
    let held = if stiffness > 0.0 { (k.contact + 2.0 * stiffness / (exponent + 1.0) * (onset - s.opening).max(0.0).powf(exponent + 1.0)).sqrt() } else { 0.0 };
    let mut state = vec![s.opening, s.opening, held];
    if let Some(t) = tract.as_mut() {
        t.steady(-w * k.flowscale);
        state.extend(t.state());
    }
    let kept_tract = player.tract.clone();
    player.tract = tract;
    let checked = (|| -> Result<Checked, String> {
        let (w_e, next) = player.reed_step(&row, pnf, &state)?;
        let rest_off = (0..2).map(|i| (next[i] - state[i]).abs()).fold((w_e - w).abs() / w.abs(), f64::max);
        // (The engine's reed taken small at rest, R(z) = d + c (z - A)^-1 b from its pnf (the bore's units) to its flow.)
        let n = state.len();
        // (Each quantity nudged by its own size: the reed's opening and its contact's variable by 1, its tract's pressures by
        // its closing pressure.)
        let size: Vec<f64> = state.iter().enumerate().map(|(j, v)| v.abs().max(if j < 3 { 1.0 } else { reed.closing })).collect();
        let (mut a, mut cc) = (vec![vec![0.0; n]; n], vec![0.0; n]);
        for j in 0..n {
            let h = STEP_NUDGE * size[j];
            let (mut up, mut down) = (state.clone(), state.clone());
            up[j] += h;
            down[j] -= h;
            let ((wu, xu), (wd, xd)) = (player.reed_step(&row, pnf, &up)?, player.reed_step(&row, pnf, &down)?);
            for i in 0..n {
                a[i][j] = (xu[i] - xd[i]) / (2.0 * h);
            }
            cc[j] = (wu - wd) / (2.0 * h);
        }
        let hp = STEP_NUDGE * pnf.abs().max(ps);
        let ((wu, xu), (wd, xd)) = (player.reed_step(&row, pnf + hp, &state)?, player.reed_step(&row, pnf - hp, &state)?);
        let bb: Vec<f64> = (0..n).map(|i| (xu[i] - xd[i]) / (2.0 * hp)).collect();
        let d = (wu - wd) / (2.0 * hp);
        let r_engine = {
            // (A contact's variable that nothing moves and that moves nothing is left out, so that its 1 is no root.)
            let mut m: Vec<Vec<C>> = (0..n).map(|i| (0..n).map(|j| (if i == j { zt } else { C::default() }) - C::new(a[i][j], 0.0)).collect()).collect();
            let mut rhs: Vec<C> = bb.iter().map(|&x| C::new(x, 0.0)).collect();
            solve_dense(&mut m, &mut rhs);
            C::new(d, 0.0) + rhs.iter().zip(&cc).fold(C::default(), |s, (&x, &c)| s + x * c)
        };
        let hz_t = player.tract.as_ref().map_or(C::default(), |t| {
            let (re, im) = t.answer_at(zt.re, zt.im);
            C::new(re, im)
        });
        let lambda = k.zc / (k.alpha * k.simp);
        let a_w = (C::new(1.0, 0.0) - C::new(lambda, 0.0) / rest.k(zt)) * (fs * lambda);
        let r_written = a_w / ps / (C::new(1.0, 0.0) + a_w * zt.inv() * hz_t * (k.flowscale / reed.closing));
        let reed_off = (r_engine - r_written).abs() / r_written.abs();
        // (The tube against its answer to a puff.)
        let w0 = (w.abs() * PUFF).max(f64::MIN_POSITIVE);
        let block = (BLOCK * rate).round().max(1.0) as usize;
        let answer = player.bore_answer(asked.row, w0, block, (MOST * rate).round() as usize, QUIET)?;
        let gp: Vec<f64> = answer.iter().map(|x| x / w0).collect();
        let tube_off = (puffed(&gp, zt) - g).abs() / g.abs();
        // (The engine stepped there from rest: its bore held under the steady flow, its reed set at rest, nudged.)
        let (growth, hz, seconds) = engine_growth(player, rate, &row, u, w, &state, asked.hz)?;
        Ok(Checked { rest_off, reed_off, tube_off, growth, hz, seconds })
    })();
    player.tract = kept_tract;
    checked
}

fn solve_dense(m: &mut [Vec<C>], r: &mut [C]) {
    let n = r.len();
    for k in 0..n {
        let p = (k..n).max_by(|&i, &j| m[i][k].abs().total_cmp(&m[j][k].abs())).unwrap();
        m.swap(k, p);
        r.swap(k, p);
        if m[k][k].abs() == 0.0 {
            continue;
        }
        for i in k + 1..n {
            let f = m[i][k] / m[k][k];
            for j in k..n {
                let t = m[k][j];
                m[i][j] = m[i][j] - f * t;
            }
            let t = r[k];
            r[i] = r[i] - f * t;
        }
    }
    for k in (0..n).rev() {
        let s = (k + 1..n).fold(r[k], |s, j| s - m[k][j] * r[j]);
        r[k] = if m[k][k].abs() == 0.0 { C::default() } else { s / m[k][k] };
    }
}

/// The engine's own growth (1/s) and pitch (Hz) at a start: its bore held under the start's steady flow `w` for SETTLE
/// s, its reed set at rest (`state`), its opening nudged, and the whole stepped at `row` for CHECKED s at most, while its
/// opening swings less than SMALL from its rest -> those, where enough windows were read, and the seconds stepped. Its
/// doubles and its tract put back as they stood.
pub(crate) fn engine_growth(player: &mut Player, rate: f64, row: &[f64], u: usize, w: f64, state: &[f64], hz: f64) -> Result<(Option<f64>, Option<f64>, f64), String> {
    let kept = player.data().to_vec();
    let tract = player.tract.clone();
    let stepped = (|| -> Result<Vec<f64>, String> {
        player.bore_steady(row, w, (SETTLE * rate).round() as usize)?;
        let mut nudged = state.to_vec();
        nudged[0] += NUDGED;
        player.set_reed_state(&nudged, row[u + 5])?;
        let (cols, outs) = player.columns();
        let chunk = 64;
        let rows = row[..cols].repeat(chunk);
        let (mut y, mut sound) = (vec![0.0; chunk * outs], vec![]);
        while (sound.len() as f64) < CHECKED * rate {
            let status = player.steps(&rows, &mut y, chunk);
            if status != 0 {
                return Err(format!("the engine stopped ({status})"));
            }
            sound.extend(y.chunks(outs).map(|r| r[0]));
            if (player.reed_state()?[0] - state[0]).abs() > SMALL {
                break;
            }
        }
        Ok(sound)
    })();
    player.set_data(&kept);
    player.tract = tract;
    let sound = stepped?;
    let d: Vec<f64> = sound.windows(2).map(|w| w[1] - w[0]).collect();
    let (period, omega) = (rate / hz, 2.0 * std::f64::consts::PI * hz / rate);
    // (Its windows WINDOW periods long, or as long as leaves READ readings past its first share EARLY where its run is too
    // short for that -- a start that reaches SMALL fast -- two at least.)
    let window = WINDOW.min(d.len() as f64 / period + 1.0 - READ as f64 / (1.0 - EARLY)).max(LEAST_WINDOW);
    let (len, hop) = ((window * period).round() as usize, period.round().max(1.0) as usize);
    let hann: Vec<f64> = (0..len).map(|n| 0.5 - 0.5 * (2.0 * std::f64::consts::PI * n as f64 / len as f64).cos()).collect();
    let mut read: Vec<(f64, C)> = vec![];
    let mut start = 0;
    while start + len <= d.len() {
        let c = (0..len).fold(C::default(), |s, n| s + C::polar(hann[n] * d[start + n], -omega * (start + n) as f64));
        read.push(((start as f64 + len as f64 / 2.0) / rate, c));
        start += hop;
    }
    let seconds = sound.len() as f64 / rate;
    let from = (EARLY * read.len() as f64) as usize;
    if read.len() < from + READ {
        return Ok((None, None, seconds));
    }
    let mut phase = vec![read[from].1.arg()];
    for r in &read[from + 1..] {
        let last = *phase.last().unwrap();
        let mut a = r.1.arg();
        while a - last > std::f64::consts::PI {
            a -= 2.0 * std::f64::consts::PI;
        }
        while a - last < -std::f64::consts::PI {
            a += 2.0 * std::f64::consts::PI;
        }
        phase.push(a);
    }
    let t: Vec<f64> = read[from..].iter().map(|r| r.0).collect();
    let slope = |v: &[f64]| {
        let (mt, mv) = (t.iter().sum::<f64>() / t.len() as f64, v.iter().sum::<f64>() / v.len() as f64);
        t.iter().zip(v).map(|(a, b)| (a - mt) * (b - mv)).sum::<f64>() / t.iter().map(|a| (a - mt) * (a - mt)).sum::<f64>()
    };
    let size: Vec<f64> = read[from..].iter().map(|r| r.1.abs().ln()).collect();
    Ok((Some(slope(&size)), Some(hz + slope(&phase) / (2.0 * std::f64::consts::PI)), seconds))
}

// ---- a start from silence at the controls a row holds: how fast it grows, and at what pitch ----
// (The owner, 8 November 2026, of the dynamic range within which a note can start from silence: "if it grows at all, its
// ability to do so is of interest"; design approved: "Yes, build".) The same equation as the starts' (started), turned
// round: there the growth and the pitch are asked and the player's lip and breath found; here the lip and the breath
// are the row's and the growth and the pitch found -- the root in z of K(z) / q(z) - 1, K the reed's answer at its
// resting opening, q what the tube and the tract take, z = e^((growth + j 2 pi f) / rate). Its resting opening the one at
// which the steady flow through it holds the row's breath (gamma_of, halved OPENING_HALVINGS times between shut and
// open); the root by Newton's steps in z, its derivative read ROOT_NUDGE either side, from the pitch given (or a root
// found before: a start followed as its player moves), until a step moves it under ROOT_CLOSED, ROOT_STEPS at most.
const OPENING_HALVINGS: usize = 64;
const ROOT_NUDGE: f64 = 1e-6;
const ROOT_CLOSED: f64 = 1e-13;
const ROOT_STEPS: usize = 40;

/// A start from silence at a row: its growth (its amplitude's rate, 1/s: below nothing, it dies) and its pitch (Hz) --
/// none where its reed rests shut at that breath (`shut`), or there is no breath -- with what is left of its equation
/// there (|K/q - 1|) and Newton's steps; its reed's resting opening (its share); its breath and the breath at which its
/// reed rests shut (shares of its closing pressure); where `checked`, the engine stepped there from rest, its reed
/// nudged (engine_growth): the growth and pitch it sounds, and the seconds stepped; how long it took (s).
#[derive(Clone, Debug, Default, Serialize)]
pub struct Grows {
    pub growth: Option<f64>,
    pub hz: Option<f64>,
    pub left: f64,
    pub newton: usize,
    pub opening: Option<f64>,
    pub gamma: f64,
    pub shut_gamma: f64,
    pub shut: bool,
    pub why: Option<String>,
    pub engine_growth: Option<f64>,
    pub engine_hz: Option<f64>,
    pub engine_seconds: Option<f64>,
    pub seconds: f64,
}

/// How a start from silence grows at `row` (its lip and its breath as the row holds them; its tract as the player's
/// stands), its root sought from the pitch `hz` or from `from` (growth 1/s, pitch Hz: a root found before). Its player in
/// doubles and on one thread; its tract settled at its resonances' ends; its doubles and its tract put back as they
/// stood.
pub fn grows(player: &mut Player, rate: f64, row: &[f64], hz: f64, from: Option<[f64; 2]>, checked: bool) -> Result<Grows, String> {
    let since = std::time::Instant::now();
    let single = player.single() && !player.crewed();
    if single {
        player.in_doubles(true);
    }
    let tract = player.tract.clone();
    if let Some(t) = player.tract.as_mut() {
        t.settle();
    }
    let kept = player.data().to_vec();
    let found = grown(player, rate, row, hz, from, checked);
    player.set_data(&kept);
    player.tract = tract;
    if single {
        player.in_doubles(false);
    }
    let mut found = found?;
    found.seconds = since.elapsed().as_secs_f64();
    Ok(found)
}

fn grown(player: &mut Player, rate: f64, row: &[f64], hz: f64, from: Option<[f64; 2]>, checked: bool) -> Result<Grows, String> {
    let place = player.reed_place()?;
    let k = player.reed_constants()?;
    if k.lips {
        return Err("lips' starts are not yet written out (their inward mode)".into());
    }
    let u = place.columns;
    if row.len() <= u + 8 {
        return Err("a row without its reed's columns".into());
    }
    if !(hz > 0.0 && hz < rate / 2.0) {
        return Err(format!("a pitch between nothing and half its rate ({} Hz)", rate / 2.0));
    }
    let (reed, gamma) = (Reed::of(row, u), row[u]);
    // (Where it rests shut, its tube at rest: shut, nothing flows, and its lossy ends lose nothing.)
    let at_rest = Tube::of(player.bore_map(row, 0.0, NUDGE, true)?).at(C::new(1.0, 0.0))?.re;
    let lambda = k.zc / (k.alpha * k.simp);
    let gamma_with = |g1: f64, rest: &Rest| g1 * rest.w_over * k.sp / (k.zc * k.sf) - rest.pi_less_gamma;
    let shut_gamma = gamma_with(at_rest, &rested(&reed, &k, 0.0).ok_or("its reed has no rest shut")?);
    let none = |why: &str, shut: bool| Grows { gamma, shut_gamma, shut, why: Some(why.into()), ..Grows::default() };
    if !(gamma > 0.0) {
        return Ok(none("no breath: its reed rests open, nothing flowing", false));
    }
    if gamma >= shut_gamma {
        return Ok(none("its reed rests shut at that breath", true));
    }
    // (Its tube about the steady flow its breath lets through its reed at rest, its lossy ends' losses about that flow
    // as the engine plays them (points.rs Starts::blown): the state its check holds its bore in before it lets its reed
    // go (engine_growth). About no flow, an edge's or a tone hole's loss, square in the flow through it, is nothing: the
    // clarinet's found body's G4 grew 3.3% faster by its equation than on the engine, 0.10% with its losses taken out
    // (research/KNOWN_ISSUES.md MB-WIND-018; research/PLAYER_TRACT_PLAN.md, Proposed 11, the owner's "Yes, proceed".)
    let (tube, g1) = crate::points::Starts::blown(player, rate, row, None)?.tube_held();
    let gamma_of = |rest: &Rest| gamma_with(g1, rest);
    // (Its resting opening: the breath falls from where its reed rests shut to none as it opens.)
    let (mut lo, mut hi) = (0.0, 1.0);
    for _ in 0..OPENING_HALVINGS {
        let m = 0.5 * (lo + hi);
        match rested(&reed, &k, m) {
            Some(r) if gamma_of(&r) >= gamma => lo = m,
            _ => hi = m,
        }
    }
    let y = 0.5 * (lo + hi);
    let rest = rested(&reed, &k, y).ok_or("its reed has no rest at its breath")?;
    // (Its equation at z: the tract read a step late, as the starts read it.)
    let e = |z: C| -> Result<C, String> {
        let g = tube.at(z)?;
        let h = player.tract.as_ref().map_or(C::default(), |t| {
            let (re, im) = t.answer_at(z.re, z.im);
            C::new(re, im)
        });
        let lt = (g * k.sp - z.inv() * h * k.flowscale) * (lambda / (k.zc * k.sf));
        let q = lt * lambda / (lt - C::new(1.0, 0.0));
        Ok(rest.k(z) / q - C::new(1.0, 0.0))
    };
    let angle = |f: f64| 2.0 * std::f64::consts::PI * f / rate;
    let mut z = match from {
        Some([growth, f]) if growth.is_finite() && f > 0.0 && f < rate / 2.0 => C::polar((growth / rate).exp(), angle(f)),
        _ => C::polar(1.0, angle(hz)),
    };
    let mut ez = e(z)?;
    let mut newton = 0;
    while newton < ROOT_STEPS {
        let d = C::new(ROOT_NUDGE, 0.0);
        let slope = (e(z + d)? - e(z - d)?) / (d * 2.0);
        let dz = ez / slope;
        if !(dz.re.is_finite() && dz.im.is_finite()) {
            return Err("its equation's slope is none at its root's step".into());
        }
        z = z - dz;
        ez = e(z)?;
        newton += 1;
        if dz.abs() <= ROOT_CLOSED {
            break;
        }
    }
    let (growth, f) = (rate * z.abs().ln(), z.arg() * rate / (2.0 * std::f64::consts::PI));
    let mut found = Grows { growth: Some(growth), hz: Some(f), left: ez.abs(), newton, opening: Some(y), gamma, shut_gamma, ..Grows::default() };
    if checked && f > 0.0 {
        // (Its state at rest, as the starts' checks set it: its opening still, its contact's variable nothing -- on its
        // lay, what holds its force there -- its tract held by the steady flow.)
        let fs = reed.closing / (k.zc * k.sf);
        let w = rest.w_over * fs;
        let [onset, stiffness, exponent, ..] = k.lay;
        let held = if stiffness > 0.0 { (k.contact + 2.0 * stiffness / (exponent + 1.0) * (onset - y).max(0.0).powf(exponent + 1.0)).sqrt() } else { 0.0 };
        let mut state = vec![y, y, held];
        let kept_tract = player.tract.clone();
        if let Some(t) = player.tract.as_mut() {
            t.steady(-w * k.flowscale);
            state.extend(t.state());
        }
        let stepped = engine_growth(player, rate, row, u, w, &state, f);
        player.tract = kept_tract;
        let (g, h, s) = stepped?;
        (found.engine_growth, found.engine_hz, found.engine_seconds) = (g, h, Some(s));
    }
    Ok(found)
}

#[cfg(test)]
mod tests {
    use super::*;

    // (The lip law at nothing, its own columns; and held to reed-lip.js lippedRow's saved answers below.)
    #[test]
    fn lip_law_unmoved_at_nothing() {
        let r = Reed { zeta: 0.3, kappa: 0.5, qr: 3.0, omegar: 20000.0, kc: 1e6, alpha_c: 2.0, epsilon: -1.0, closing: 6000.0 };
        let law = LipLaw { zc: 3e6, rho: 1.2, width: 0.013, area: 1e-4, lengthening: 0.05, damping: None };
        let same = r.lipped(&law, 0.0);
        assert_eq!(same.zeta, r.zeta);
        // (Its own law at nothing gives back its own columns: y = y0, lambda 1.)
        let near = r.lipped(&law, -1e-300);
        assert!((near.zeta - r.zeta).abs() < 1e-12 * r.zeta && (near.kappa - r.kappa).abs() < 1e-12 * r.kappa);
        assert!((near.closing - r.closing).abs() < 1e-9 * r.closing);
    }

    // (reed-lip.js lippedRow's answers, saved, on test/reed-lip.test.mjs's row -- its reed made as the engine makes one,
    // its lip the clarinet's players' -- eased, pressed and pressed past the most, with and without its lip's damping.)
    #[test]
    fn lip_law_as_the_javascript_has_it() {
        let row = [0.680180061812813, 0.717672465956056, 0.7002896279296936, 1.8228268537802204, 17259.91, 10576.899054607233, 4.0, -1.0, 5439.7360459799065];
        let damping = Damping { tip: 0.00114, exponent: 0.222 };
        let saved: [(f64, bool, [f64; 9]); 8] = [
            (-1.7, false, [0.680180061812813, 1.4448591659689494, 1.171196729231299, 1.2937309861183746, 12250.02821211822, 20997.192765446493, 4.0, -1.0, 5594.619321912044]),
            (-0.5, false, [0.680180061812813, 0.9129924745476478, 0.8223090555984017, 1.6377231902070666, 15507.207834505065, 13102.923276019696, 4.0, -1.0, 5736.407254296498]),
            (0.4, false, [0.680180061812813, 0.6235454868327527, 0.7002896279296935, 1.8228268537802204, 17259.91, 10576.899054607233, 4.0, -1.0, 4106.402712646573]),
            (2.468728732414575, false, [0.680180061812813, 0.22694796064107875, 0.7002896279296934, 1.8228268537802204, 17259.91, 10576.899054607233, 4.0, -1.0, 543.9736045979906]),
            (-1.7, true, [0.680180061812813, 1.4448591659689494, 1.171196729231299, 1.502985074469284, 12250.02821211822, 20997.192765446493, 4.0, -1.0, 5594.619321912044]),
            (-0.5, true, [0.680180061812813, 0.9129924745476478, 0.8223090555984017, 1.695422991533729, 15507.207834505065, 13102.923276019696, 4.0, -1.0, 5736.407254296498]),
            (0.4, true, [0.680180061812813, 0.6235454868327527, 0.7002896279296935, 1.7791165998100869, 17259.91, 10576.899054607233, 4.0, -1.0, 4106.402712646573]),
            (2.468728732414575, true, [0.680180061812813, 0.22694796064107875, 0.7002896279296934, 1.6852013576469522, 17259.91, 10576.899054607233, 4.0, -1.0, 543.9736045979906]),
        ];
        for (force, damped, js) in saved {
            let law = LipLaw { zc: 8633525.68, rho: 1.19929, width: 0.013, area: 3e-4, lengthening: 0.11, damping: damped.then_some(damping) };
            let mut ours = row;
            Reed::of(&row, 0).lipped(&law, force).into_row(&mut ours, 0, row[0]);
            for (k, (a, b)) in ours.iter().zip(js.iter()).enumerate() {
                assert!((a - b).abs() <= 1e-13 * b.abs().max(1.0), "{force} N (damped {damped}), column {k}: {a} against the JavaScript's {b}");
            }
        }
    }

    // (A plain single reed, its columns the lip law's test's, its scheme's step at 48 kHz.)
    fn plain() -> (Reed, ReedConstants, LipLaw) {
        let row = [0.680180061812813, 0.717672465956056, 0.7002896279296936, 1.8228268537802204, 17259.91, 10576.899054607233, 4.0, -1.0, 5439.7360459799065];
        let k = ReedConstants { theta: 0.25, dt: 1.0 / 48000.0, sp: 1.0, zc: 8633525.68, sf: 1.0, simp: 1.0, flowscale: 1.0, exponent: 1.0, alpha: 1.0, ..Default::default() };
        let law = LipLaw { zc: 8633525.68, rho: 1.19929, width: 0.013, area: 3e-4, lengthening: 0.11, damping: None };
        (Reed::of(&row, 0), k, law)
    }

    // (What a pressed lip and a resting opening make the reed answer, read back by arithmetic to the same lip and opening
    // -- at a G4 neither growing nor dying and growing at players' 1000 dB/s, its lip pressed short of PRESSED_MOST and
    // past it -- and the table's search (refine), read inside a cell about it, finding the same.)
    #[test]
    fn arithmetic_reads_back_the_lip_and_the_opening() {
        let (own, k, law) = plain();
        let shutting = own.closing * law.area;
        let growth = 1000.0 * std::f64::consts::LN_10 / 20.0;
        for (force, y, g) in [(0.6, 0.4, 0.0), (0.6, 0.4, growth), (0.95 * shutting, 0.25, growth), (0.0, 0.7, 0.0)] {
            let z = C::polar((g / 48000.0f64).exp(), 2.0 * std::f64::consts::PI * 392.0 / 48000.0);
            let q = rested(&own.lipped_free(&law, force), &k, y).unwrap().k(z);
            let (f, closure) = by_arithmetic(&own, &k, &law, z, q).expect("a start");
            // (Its answer there q's to rounding; the lip and the opening to rounding of q, whose lambda stands some 1e7
            // times the reed's own part of it.)
            let back = rested(&own.lipped_free(&law, f), &k, 1.0 - closure).unwrap().k(z);
            assert!((back / q - C::new(1.0, 0.0)).abs() <= 1e-15, "{force} N at {y}, growth {g}: its answer off by {:e}", (back / q - C::new(1.0, 0.0)).abs());
            assert!((f - force).abs() <= 1e-7 * shutting, "{force} N at {y}, growth {g}: read back {f} N");
            assert!((1.0 - closure - y).abs() <= 1e-7, "{force} N at {y}, growth {g}: read back the opening {}", 1.0 - closure);
            if force > 0.0 {
                let e = |f: f64, c: f64| -> Option<C> { Some(rested(&own.lipped_free(&law, f), &k, 1.0 - c)?.k(z) / q - C::new(1.0, 0.0)) };
                let (tf, tc) = refine(&e, [force - 0.05, force + 0.05], [1.0 - y - 0.02, 1.0 - y + 0.02]).expect("the table's");
                assert!((tf - f).abs() <= 1e-6 * shutting && (tc - closure).abs() <= 1e-6, "the table's {tf} N at {} against {f} at {}", 1.0 - tc, 1.0 - closure);
            }
        }
        // (Its law damping the reed: not by this arithmetic.)
        let damped = LipLaw { damping: Some(Damping { tip: 0.00114, exponent: 0.222 }), ..law };
        let z = C::polar(1.0, 0.05);
        assert!(by_arithmetic(&own, &k, &damped, z, rested(&own, &k, 0.5).unwrap().k(z)).is_none());
    }

    // (A plain single reed rests shut with no flow at its closing pressure, its breath's share 1, whatever its lip.)
    #[test]
    fn plain_reed_shuts_at_its_closing_pressure() {
        let (own, k, law) = plain();
        for force in [-1.0, 0.0, 0.7, 1.5] {
            let r = own.lipped_free(&law, force);
            let rest = rested(&r, &k, 0.0).unwrap();
            assert!(rest.w_over.abs() <= 1e-12, "{force} N: a flow {} shut", rest.w_over);
            assert!((-rest.pi_less_gamma - 1.0).abs() <= 1e-12, "{force} N: its breath's share shut {}", -rest.pi_less_gamma);
        }
    }
}
