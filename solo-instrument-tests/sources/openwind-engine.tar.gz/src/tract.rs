//! The player's vocal tract (research/MODELING_GAPS.md, "No vocal tract"): an impedance upstream of the reed, in series
//! with the bore -- what the reed is driven by is the mouth's pressure less the tract's answer to the flow it lets
//! through, so that the tract's resonances act inside the oscillation (its pitch, its register, its attack), as no filter
//! on the sound after it can. Its impedance a sum of resonances, each a parallel resonance's,
//! Z(w) = peak / (1 + j Q (w/w0 - w0/w)): its peak at its frequency, nothing at none -- the breath's steady pressure the
//! player's own, as measured in the mouth -- and nothing at the step's Nyquist frequency. Each resonance stepped as its
//! bilinear transform, warped to its frequency, from the flow a step before (the tract's answer one native step late:
//! some 3 us at the bodies' rates, its own coefficient on the flow then some 1e-4 of a playing pressure). Its
//! resonances as the player sets them, each change eased along the raised cosine over the time it is given.
//! Measured: clarinettists' first peak 200-300 Hz at 1.8-5.6 MPa s/m^3 (some to 18), later ones to 30-100 near the
//! bore's own (Fritz & Wolfe 2005, doi:10.1121/1.2041287; Chen, Smith & Wolfe 2009, doi:10.1121/1.3177269).

use crate::controls::eased;
use serde::Deserialize;

/// One resonance of the tract: its frequency (Hz), its quality factor and its impedance at its peak (Pa s/m^3).
#[derive(Deserialize, Clone, Copy, Debug, PartialEq)]
pub struct Resonance {
    pub frequency: f64,
    pub q: f64,
    pub peak: f64,
}

/// A resonance's bilinear section, transposed direct form II, and the pressure it last answered with.
#[derive(Clone, Copy, Debug, Default)]
struct Section {
    b0: f64,
    a1: f64,
    a2: f64,
    z1: f64,
    z2: f64,
}

impl Section {
    fn tuned(&mut self, r: &Resonance, step: f64) {
        let w0 = 2.0 * std::f64::consts::PI * r.frequency;
        let k = w0 / (w0 * step / 2.0).tan();
        let damping = w0 / r.q;
        let a0 = k * k + damping * k + w0 * w0;
        self.b0 = r.peak * damping * k / a0;
        self.a1 = (2.0 * w0 * w0 - 2.0 * k * k) / a0;
        self.a2 = (k * k - damping * k + w0 * w0) / a0;
    }

    // (Its numerator b0 (1 - z^-2): b1 nothing, b2 -b0.)
    fn answer(&mut self, flow: f64) -> f64 {
        let p = self.b0 * flow + self.z1;
        self.z1 = -self.a1 * p + self.z2;
        self.z2 = -self.b0 * flow - self.a2 * p;
        p
    }
}

/// The tract a player plays with: its resonances now, where they are going, its sections and its last answer (Pa).
pub struct Tract {
    step: f64,
    from: Vec<Resonance>,
    to: Vec<Resonance>,
    steps: u64,
    taken: u64,
    sections: Vec<Section>,
    pressure: f64,
}

// (Its sections tuned again every this many steps while it moves.)
const RETUNED: u64 = 32;

impl Tract {
    /// A tract stepped at `rate` (Hz), with no resonances yet: it answers nothing.
    pub fn new(rate: f64) -> Tract {
        Tract { step: 1.0 / rate, from: vec![], to: vec![], steps: 0, taken: 0, sections: vec![], pressure: 0.0 }
    }

    /// Its resonances from here to `to`, over `seconds` (none: at once, as at its start). A resonance the one side lacks
    /// comes or goes by its peak alone, at the other side's frequency and Q.
    pub fn set(&mut self, to: Vec<Resonance>, seconds: f64) {
        let now = self.now();
        let n = now.len().max(to.len());
        let silent = |r: Option<&Resonance>, other: Option<&Resonance>| r.copied().unwrap_or_else(|| Resonance { peak: 0.0, ..*other.unwrap() });
        self.from = (0..n).map(|k| silent(now.get(k), to.get(k))).collect();
        self.to = (0..n).map(|k| silent(to.get(k), now.get(k))).collect();
        self.sections.resize(n, Section::default());
        self.steps = (seconds / self.step).round().max(0.0) as u64;
        self.taken = 0;
        self.tune();
    }

    /// Its resonances where they stand.
    pub fn now(&self) -> Vec<Resonance> {
        let p = if self.steps == 0 { 1.0 } else { eased((self.taken as f64 / self.steps as f64).min(1.0)) };
        let between = |a: f64, b: f64| a * (b / a).powf(p);
        self.from.iter().zip(&self.to).map(|(a, b)| Resonance {
            frequency: between(a.frequency, b.frequency), q: between(a.q, b.q), peak: a.peak + (b.peak - a.peak) * p,
        }).collect()
    }

    fn tune(&mut self) {
        let now = self.now();
        for (section, r) in self.sections.iter_mut().zip(&now) {
            section.tuned(r, self.step);
        }
    }

    /// Its answer now (Pa): the pressure it takes from the mouth's.
    #[inline(always)]
    pub fn pressure(&self) -> f64 {
        self.pressure
    }

    /// A step's flow from the mouth through the reed (m^3/s) taken: its answer for the next step.
    #[inline(always)]
    pub fn take(&mut self, flow: f64) {
        if self.taken < self.steps {
            self.taken += 1;
            if self.taken % RETUNED == 0 || self.taken == self.steps {
                self.tune();
            }
        }
        let mut p = 0.0;
        for section in self.sections.iter_mut() {
            p += section.answer(flow);
        }
        self.pressure = p;
    }

    /// Its impedance's magnitude at `frequency` (Hz), as its sections now step it: what is measured of a tract.
    pub fn magnitude(&self, frequency: f64) -> f64 {
        let w = 2.0 * std::f64::consts::PI * frequency * self.step;
        let (c1, s1, c2, s2) = (w.cos(), -w.sin(), (2.0 * w).cos(), -(2.0 * w).sin());
        let (mut re, mut im) = (0.0, 0.0);
        for s in &self.sections {
            // H(e^jw) = b0 (1 - e^-2jw) / (1 + a1 e^-jw + a2 e^-2jw)
            let (nr, ni) = (s.b0 * (1.0 - c2), -s.b0 * s2);
            let (dr, di) = (1.0 + s.a1 * c1 + s.a2 * c2, s.a1 * s1 + s.a2 * s2);
            let den = dr * dr + di * di;
            re += (nr * dr + ni * di) / den;
            im += (ni * dr - nr * di) / den;
        }
        (re * re + im * im).sqrt()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn its_peaks_where_they_are_set_and_nothing_at_rest() {
        let mut t = Tract::new(288_000.0);
        t.set(vec![Resonance { frequency: 250.0, q: 5.0, peak: 3.0e6 }, Resonance { frequency: 1300.0, q: 12.0, peak: 2.0e7 }], 0.0);
        assert!((t.magnitude(1300.0) / 2.0e7 - 1.0).abs() < 0.05, "{}", t.magnitude(1300.0));
        assert!(t.magnitude(250.0) > 3.0e6 * 0.95);
        assert!(t.magnitude(0.5) < 1.0e4);
        // (A steady flow answered by nothing, once its resonances have rung down.)
        for _ in 0..288_000 {
            t.take(1.0e-4);
        }
        assert!(t.pressure().abs() < 1e-3, "{}", t.pressure());
    }

    #[test]
    fn its_moves_eased_over_their_time() {
        let mut t = Tract::new(48_000.0);
        t.set(vec![Resonance { frequency: 300.0, q: 5.0, peak: 2.0e6 }], 0.0);
        t.set(vec![Resonance { frequency: 1200.0, q: 5.0, peak: 2.0e6 }], 0.1);
        for _ in 0..2400 {
            t.take(0.0);
        }
        let half = t.now()[0].frequency;
        assert!((half - 600.0).abs() < 1.0, "{half}");
        for _ in 0..2400 {
            t.take(0.0);
        }
        assert_eq!(t.now()[0].frequency, 1200.0);
    }
}
