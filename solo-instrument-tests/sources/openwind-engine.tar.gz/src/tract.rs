//! The player's vocal tract (research/MODELING_GAPS.md, "No vocal tract"): an impedance upstream of the reed, in series
//! with the bore -- what the reed is driven by is the mouth's pressure less the tract's answer to the flow it lets
//! through, so that the tract's resonances act inside the oscillation (its pitch, its register, its attack), as no filter
//! on the sound after it can. Its impedance a sum of resonances, each a parallel resonance's,
//! Z(w) = peak / (1 + j Q (w/w0 - w0/w)): its peak at its frequency, nothing at none -- the breath's steady pressure the
//! player's own, as measured in the mouth -- and nothing at the step's Nyquist frequency. Each resonance stepped as its
//! bilinear transform, warped to its frequency, from the flow a step before (the tract's answer one native step late:
//! some 3 us at the bodies' rates, its own coefficient on the flow then some 1e-4 of a playing pressure). Its
//! resonances as the player sets them, each change eased along the raised cosine over the time it is given.
//! Measured: clarinettists' first peak 200-300 Hz at 1.8-5.6 MPa s/m^3 (some to 18), later ones to 30-100 near the
//! bore's own (Fritz & Wolfe 2005, doi:10.1121/1.2041287; Chen, Smith & Wolfe 2009, doi:10.1121/1.3177269).

use crate::controls::eased;
use serde::Deserialize;

/// One resonance of the tract: its frequency (Hz), its quality factor and its impedance at its peak (Pa s/m^3).
#[derive(Deserialize, Clone, Copy, Debug, PartialEq)]
pub struct Resonance {
    pub frequency: f64,
    pub q: f64,
    pub peak: f64,
}

/// A resonance's bilinear section, transposed direct form II, and the pressure it last answered with.
#[derive(Clone, Copy, Debug, Default)]
struct Section {
    b0: f64,
    a1: f64,
    a2: f64,
    z1: f64,
    z2: f64,
}

impl Section {
    fn tuned(&mut self, r: &Resonance, step: f64) {
        let w0 = 2.0 * std::f64::consts::PI * r.frequency;
        let k = w0 / (w0 * step / 2.0).tan();
        let damping = w0 / r.q;
        let a0 = k * k + damping * k + w0 * w0;
        self.b0 = r.peak * damping * k / a0;
        self.a1 = (2.0 * w0 * w0 - 2.0 * k * k) / a0;
        self.a2 = (k * k - damping * k + w0 * w0) / a0;
    }

    // (Its numerator b0 (1 - z^-2): b1 nothing, b2 -b0.)
    fn answer(&mut self, flow: f64) -> f64 {
        let p = self.b0 * flow + self.z1;
        self.z1 = -self.a1 * p + self.z2;
        self.z2 = -self.b0 * flow - self.a2 * p;
        p
    }
}

/// The tract a player plays with: its resonances now, where they are going, its sections and its last answer (Pa).
pub struct Tract {
    step: f64,
    from: Vec<Resonance>,
    to: Vec<Resonance>,
    steps: u64,
    taken: u64,
    sections: Vec<Section>,
    pressure: f64,
}

// (Its sections tuned again every this many steps while it moves.)
const RETUNED: u64 = 32;

impl Tract {
    /// A tract stepped at `rate` (Hz), with no resonances yet: it answers nothing.
    pub fn new(rate: f64) -> Tract {
        Tract { step: 1.0 / rate, from: vec![], to: vec![], steps: 0, taken: 0, sections: vec![], pressure: 0.0 }
    }

    /// Its resonances from here to `to`, over `seconds` (none: at once, as at its start). A resonance the one side lacks
    /// comes or goes by its peak alone, at the other side's frequency and Q.
    pub fn set(&mut self, to: Vec<Resonance>, seconds: f64) {
        let now = self.now();
        let n = now.len().max(to.len());
        let silent = |r: Option<&Resonance>, other: Option<&Resonance>| r.copied().unwrap_or_else(|| Resonance { peak: 0.0, ..*other.unwrap() });
        self.from = (0..n).map(|k| silent(now.get(k), to.get(k))).collect();
        self.to = (0..n).map(|k| silent(to.get(k), now.get(k))).collect();
        self.sections.resize(n, Section::default());
        self.steps = (seconds / self.step).round().max(0.0) as u64;
        self.taken = 0;
        self.tune();
    }

    /// Its resonances where they stand.
    pub fn now(&self) -> Vec<Resonance> {
        let p = if self.steps == 0 { 1.0 } else { eased((self.taken as f64 / self.steps as f64).min(1.0)) };
        let between = |a: f64, b: f64| a * (b / a).powf(p);
        self.from.iter().zip(&self.to).map(|(a, b)| Resonance {
            frequency: between(a.frequency, b.frequency), q: between(a.q, b.q), peak: a.peak + (b.peak - a.peak) * p,
        }).collect()
    }

    fn tune(&mut self) {
        let now = self.now();
        for (section, r) in self.sections.iter_mut().zip(&now) {
            section.tuned(r, self.step);
        }
    }

    /// Its answer now (Pa): the pressure it takes from the mouth's.
    #[inline(always)]
    pub fn pressure(&self) -> f64 {
        self.pressure
    }

    /// A step's flow from the mouth through the reed (m^3/s) taken: its answer for the next step.
    #[inline(always)]
    pub fn take(&mut self, flow: f64) {
        if self.taken < self.steps {
            self.taken += 1;
            if self.taken % RETUNED == 0 || self.taken == self.steps {
                self.tune();
            }
        }
        let mut p = 0.0;
        for section in self.sections.iter_mut() {
            p += section.answer(flow);
        }
        self.pressure = p;
    }

    /// Its impedance's magnitude at `frequency` (Hz), as its sections now step it: what is measured of a tract.
    pub fn magnitude(&self, frequency: f64) -> f64 {
        let w = 2.0 * std::f64::consts::PI * frequency * self.step;
        let (c1, s1, c2, s2) = (w.cos(), -w.sin(), (2.0 * w).cos(), -(2.0 * w).sin());
        let (mut re, mut im) = (0.0, 0.0);
        for s in &self.sections {
            // H(e^jw) = b0 (1 - e^-2jw) / (1 + a1 e^-jw + a2 e^-2jw)
            let (nr, ni) = (s.b0 * (1.0 - c2), -s.b0 * s2);
            let (dr, di) = (1.0 + s.a1 * c1 + s.a2 * c2, s.a1 * s1 + s.a2 * s2);
            let den = dr * dr + di * di;
            re += (nr * dr + ni * di) / den;
            im += (ni * dr - nr * di) / den;
        }
        (re * re + im * im).sqrt()
    }
}

// (Its state read and set between steps, and its move ended at once: orbit.rs's. Here, below every line a page's
// WebAssembly builds from, so that none of them moves.)
impl Tract {
    /// What it carries from one step to the next: each section's two delays, then its last answer (orbit.rs).
    pub fn state(&self) -> Vec<f64> {
        self.sections.iter().flat_map(|s| [s.z1, s.z2]).chain([self.pressure]).collect()
    }

    /// That put back (as `state` gave it, for as many sections as it has).
    pub fn set_state(&mut self, state: &[f64]) {
        for (k, s) in self.sections.iter_mut().enumerate() {
            s.z1 = state[2 * k];
            s.z2 = state[2 * k + 1];
        }
        self.pressure = state[2 * self.sections.len()];
    }

    /// Its resonances where they are going reached at once (orbit.rs: a note's tract held as its player holds it).
    pub fn settle(&mut self) {
        if self.taken < self.steps {
            self.taken = self.steps;
            self.tune();
        }
    }
}

impl Clone for Tract {
    fn clone(&self) -> Tract {
        Tract { step: self.step, from: self.from.clone(), to: self.to.clone(), steps: self.steps, taken: self.taken, sections: self.sections.clone(), pressure: self.pressure }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn its_peaks_where_they_are_set_and_nothing_at_rest() {
        let mut t = Tract::new(288_000.0);
        t.set(vec![Resonance { frequency: 250.0, q: 5.0, peak: 3.0e6 }, Resonance { frequency: 1300.0, q: 12.0, peak: 2.0e7 }], 0.0);
        assert!((t.magnitude(1300.0) / 2.0e7 - 1.0).abs() < 0.05, "{}", t.magnitude(1300.0));
        assert!(t.magnitude(250.0) > 3.0e6 * 0.95);
        assert!(t.magnitude(0.5) < 1.0e4);
        // (A steady flow answered by nothing, once its resonances have rung down.)
        for _ in 0..288_000 {
            t.take(1.0e-4);
        }
        assert!(t.pressure().abs() < 1e-3, "{}", t.pressure());
    }

    #[test]
    fn its_moves_eased_over_their_time() {
        let mut t = Tract::new(48_000.0);
        t.set(vec![Resonance { frequency: 300.0, q: 5.0, peak: 2.0e6 }], 0.0);
        t.set(vec![Resonance { frequency: 1200.0, q: 5.0, peak: 2.0e6 }], 0.1);
        for _ in 0..2400 {
            t.take(0.0);
        }
        let half = t.now()[0].frequency;
        assert!((half - 600.0).abs() < 1.0, "{half}");
        for _ in 0..2400 {
            t.take(0.0);
        }
        assert_eq!(t.now()[0].frequency, 1200.0);
    }
}

// (Its answer at any z: starts.rs's. Here at the file's end, so that no line above it moves.)
impl Tract {
    /// Its answer at z = (re, im), as its sections now step it: H(z) = sum b0 (1 - z^-2) / (1 + a1 z^-1 + a2 z^-2), the
    /// pressure (Pa) it answers a flow taken (m^3/s) with, read by the reed a step later -> (re, im).
    pub fn answer_at(&self, re: f64, im: f64) -> (f64, f64) {
        let n = re * re + im * im;
        let (wr, wi) = (re / n, -im / n);
        let (w2r, w2i) = (wr * wr - wi * wi, 2.0 * wr * wi);
        let (mut hr, mut hi) = (0.0, 0.0);
        for s in &self.sections {
            let (nr, ni) = (s.b0 * (1.0 - w2r), -s.b0 * w2i);
            let (dr, di) = (1.0 + s.a1 * wr + s.a2 * w2r, s.a1 * wi + s.a2 * w2i);
            let den = dr * dr + di * di;
            hr += (nr * dr + ni * di) / den;
            hi += (ni * dr - nr * di) / den;
        }
        (hr, hi)
    }
}

impl Tract {
    /// Its state set to what a steady `flow` (m^3/s) holds it at: each section's answer nothing (its numerator's zero at
    /// nothing), its delays z1 = z2 = -b0 flow.
    pub fn steady(&mut self, flow: f64) {
        for s in self.sections.iter_mut() {
            s.z1 = -s.b0 * flow;
            s.z2 = -s.b0 * flow;
        }
        self.pressure = 0.0;
    }
}

// (The tract as clarinettists keep it as they play, a measured speaker's shapes baked: public/shared/performers/
// vocal-tract-played.js playedTract and vocal-tract-space.json, in Rust for starts.rs. Here at the file's end, so that no
// line above it moves.)

/// One baked shape: the frequency its kept resonance is asked at (Hz) and its resonances.
#[derive(Deserialize, Clone, Debug)]
pub struct ShapeRow {
    pub target: f64,
    pub resonances: Vec<Resonance>,
}

/// A way its players keep their tract ('normal' or 'bend'): its shapes, baked a step of target apart.
#[derive(Deserialize, Clone, Debug)]
pub struct Shapes {
    pub rows: Vec<ShapeRow>,
}

impl Shapes {
    /// The resonances of the shape whose kept resonance is asked at `target` Hz (vocal-tract-played.js playedTract):
    /// between two rows their geometric blend, each resonance matched by its place, and one only one row has brought in
    /// as that row is neared; the first row's below the first, the last's (the nearest the shapes come) above the last.
    pub fn played(&self, target: f64) -> Vec<Resonance> {
        let rows = &self.rows;
        let step = rows[1].target - rows[0].target;
        let at = ((target - rows[0].target) / step).max(0.0).min((rows.len() - 1) as f64);
        let k = (at.floor() as usize).min(rows.len() - 2);
        let share = at - k as f64;
        let (a, b) = (&rows[k].resonances, &rows[k + 1].resonances);
        let blend = |u: f64, v: f64| u.powf(1.0 - share) * v.powf(share);
        (0..a.len().max(b.len()))
            .filter_map(|i| match (a.get(i), b.get(i)) {
                (Some(p), Some(q)) => Some(Resonance { frequency: blend(p.frequency, q.frequency), q: blend(p.q, q.q), peak: blend(p.peak, q.peak) }),
                (Some(p), None) => Some(Resonance { peak: p.peak * (1.0 - share), ..*p }),
                (None, Some(q)) => Some(Resonance { peak: q.peak * share, ..*q }),
                (None, None) => None,
            })
            .filter(|r| r.peak > 0.0)
            .collect()
    }
}

/// The ways its players keep their tract, each its shapes (vocal-tract-space.json's `normal` and `bend`).
#[derive(Deserialize, Clone, Debug, Default)]
pub struct TractShapes {
    #[serde(default)]
    pub normal: Option<Shapes>,
    #[serde(default)]
    pub bend: Option<Shapes>,
}

#[cfg(test)]
mod played_tests {
    use super::*;

    // (The JavaScript's playedTract at these targets, 8 November 2026, against the Rust's on the same baked shapes:
    // within rounding. Made again from vocal-tract-played.js where the shapes are baked again.)
    #[test]
    fn played_as_the_javascript_plays_it() {
        let space: serde_json::Value = serde_json::from_str(include_str!("../../../public/shared/performers/vocal-tract-space.json")).unwrap();
        let shapes: TractShapes = serde_json::from_value(serde_json::json!({"normal": space["normal"], "bend": space["bend"]})).unwrap();
        let saved: &[(&str, f64, &[[f64; 3]])] = &[
            ("normal", 300.0, &[[243.47, 0.8972, 4346000.0], [578.94, 5.946, 7512000.0]]),
            ("normal", 612.5, &[[253.21497684773706, 0.8666291709837605, 4678296.2710798895], [586.7374895129849, 5.528868419486939, 7181217.16702677], [3237.5, 100.0, 431600.0]]),
            ("normal", 1337.7, &[[223.98296512946246, 0.8791099389272945, 3959523.7159453686], [1345.3008777033076, 8.041051580042534, 8626408.901414879], [2404.2437366765544, 14.400584457736679, 9721926.33323194], [3315.7350517781533, 27.76116475372428, 31533236.974508274]]),
            ("normal", 2500.0, &[[221.59, 1.645, 4831000.0], [1973.1, 14.71, 8852000.0], [3089.9, 41.85, 8447000.0]]),
            ("bend", 612.5, &[[197.94808814434154, 0.29999999999999993, 2933492.79869578], [605.1594659261309, 9.532788259475817, 33589343.54821481]]),
            ("bend", 1000.0, &[[217.06, 0.8831, 3558000.0], [996.29, 13.35, 34300000.0], [2397.6, 14.44, 1029000.0], [3350.3, 27.84, 6589000.0]]),
            ("bend", 1337.7, &[[223.2290378046707, 0.840953358161403, 3908354.7597861555], [1336.4944648743215, 12.89910312722011, 34218441.679912105], [2400.5742069150515, 14.235648889329438, 11110627.250163713], [3270.5023104724078, 27.941652201867907, 35236556.740848795]]),
            ("bend", 1975.0, &[[238.08, 0.9582, 4868000.0], [1752.3, 9.024, 29040000.0], [2271.1, 21.58, 273000000.0], [2853.5, 25.26, 52850000.0]]),
        ];
        for &(how, target, js) in saved {
            let ways = if how == "normal" { shapes.normal.as_ref() } else { shapes.bend.as_ref() };
            let rust = ways.unwrap().played(target);
            assert_eq!(rust.len(), js.len(), "{how} {target}");
            for (r, j) in rust.iter().zip(js) {
                for (a, b) in [(r.frequency, j[0]), (r.q, j[1]), (r.peak, j[2])] {
                    assert!((a - b).abs() <= 1e-13 * b.abs(), "{how} {target}: {a} against {b}");
                }
            }
        }
    }
}
