//! The streaming player (stream.rs) in a page: built for wasm32 (research/BROWSER_RENDERING_PLAN.md, the studio page),
//! its body and law handed over as the bytes of the files save_body writes, its groups as the stream binary's `g` lines'
//! JSON, its sound taken from its memory. Called by public/studio/engines/openwind-worker.js; each call's failure said
//! by ow_error. And the live dial's controls as the stream binary takes them (src/bin/musebots-openwind-stream.rs: its
//! `h`, `v`, `t`, `s`, `o` and `c` lines), so that the winds' dial (native/openwind/dial.mjs) plays in a page by itself;
//! built for wasm32-wasip1-threads, its bore stepped on several cores as natively (parallel.rs), each core a Worker of
//! the page's sharing its memory (public/studio/engines/openwind-stream.js).
use crate::body::{Body, Header};
use crate::stream::{GroupLine, HeldLine, NoiseLine, RowLine, SlideLine, Stream, TechniqueLine, TractLine, TurbulenceLine, VibratoLine};
use std::cell::RefCell;

thread_local! {
    static ERROR: RefCell<String> = RefCell::new(String::new());
    static OUT: RefCell<Vec<f32>> = RefCell::new(Vec::new());
    static TEXT: RefCell<String> = RefCell::new(String::new());
}

fn failed(e: String) {
    ERROR.with(|cell| *cell.borrow_mut() = e);
}

unsafe fn bytes<'a>(p: *const u8, n: usize) -> &'a [u8] {
    if n == 0 { &[] } else { std::slice::from_raw_parts(p, n) }
}

// (The threaded build's main thread made one as its libc makes its threads -- its thread pointer and local storage -- as
// a program's start would; a library's has none: called once by the page before anything else, openwind-stream.js.)
#[cfg(feature = "threads")]
extern "C" {
    fn __wasi_init_tp();
}

/// The threaded build's main thread set up, once, before any other call (its thread-locals, ERROR's among them).
#[cfg(feature = "threads")]
#[no_mangle]
pub extern "C" fn ow_start() {
    unsafe { __wasi_init_tp() }
}

/// `n` bytes for the page to write into. -> where; freed by ow_free.
#[no_mangle]
pub extern "C" fn ow_alloc(n: usize) -> *mut u8 {
    let mut v = Vec::<u8>::with_capacity(n.max(1));
    let p = v.as_mut_ptr();
    std::mem::forget(v);
    p
}

/// # Safety
/// `p` must be ow_alloc's of `n`, freed once.
#[no_mangle]
pub unsafe extern "C" fn ow_free(p: *mut u8, n: usize) {
    if !p.is_null() {
        drop(Vec::from_raw_parts(p, 0, n.max(1)));
    }
}

/// The last failure's text: where it is (ow_error_len its length).
#[no_mangle]
pub extern "C" fn ow_error() -> *const u8 {
    ERROR.with(|cell| cell.borrow().as_ptr())
}

#[no_mangle]
pub extern "C" fn ow_error_len() -> usize {
    ERROR.with(|cell| cell.borrow().len())
}

/// A part's player on a saved body: body.json, I.bin, D.bin, law.json and rules.json's bytes, its bore in singles where
/// `single` is not 0 or its body says. -> it, or null (ow_error says why); freed by ow_close.
///
/// # Safety
/// Each pointer must address that many bytes.
#[no_mangle]
pub unsafe extern "C" fn ow_open(header: *const u8, nh: usize, ib: *const u8, ni: usize, db: *const u8, nd: usize,
                                 law: *const u8, nl: usize, rules: *const u8, nr: usize, single: i32) -> *mut Stream {
    let made = serde_json::from_slice::<Header>(bytes(header, nh)).map_err(|e| format!("body.json: {e}"))
        .and_then(|h| Body::from_bytes(h, bytes(ib, ni), bytes(db, nd)))
        .and_then(|b| Stream::from_parts(b, bytes(law, nl), bytes(rules, nr), single != 0));
    match made {
        Ok(s) => Box::into_raw(Box::new(s)),
        Err(e) => {
            failed(e);
            std::ptr::null_mut()
        }
    }
}

/// The same, its bore stepped on `threads` cores where it splits so (Stream::from_parts_threaded): in a build with threads.
///
/// # Safety
/// As ow_open.
#[no_mangle]
pub unsafe extern "C" fn ow_open_threaded(header: *const u8, nh: usize, ib: *const u8, ni: usize, db: *const u8, nd: usize,
                                          law: *const u8, nl: usize, rules: *const u8, nr: usize, single: i32, threads: usize) -> *mut Stream {
    let made = serde_json::from_slice::<Header>(bytes(header, nh)).map_err(|e| format!("body.json: {e}"))
        .and_then(|h| Body::from_bytes(h, bytes(ib, ni), bytes(db, nd)))
        .and_then(|b| Stream::from_parts_threaded(b, bytes(law, nl), bytes(rules, nr), single != 0, threads.max(1)));
    match made {
        Ok(s) => Box::into_raw(Box::new(s)),
        Err(e) => {
            failed(e);
            std::ptr::null_mut()
        }
    }
}

/// # Safety
/// `s` must be ow_open's, not closed.
#[no_mangle]
pub unsafe extern "C" fn ow_native_rate(s: *const Stream) -> f64 {
    (*s).native_rate()
}

/// The cores its bore is stepped on.
///
/// # Safety
/// As ow_native_rate.
#[no_mangle]
pub unsafe extern "C" fn ow_threads(s: *const Stream) -> usize {
    (*s).threads()
}

/// The groups that came after their start so far.
///
/// # Safety
/// As ow_native_rate.
#[no_mangle]
pub unsafe extern "C" fn ow_late(s: *const Stream) -> u64 {
    (*s).late
}

/// A breath group (stream.rs GroupLine as JSON, `n` bytes). -> 0, or -1 (ow_error says why).
///
/// # Safety
/// `s` as ow_native_rate; `line` must address `n` bytes.
#[no_mangle]
pub unsafe extern "C" fn ow_group(s: *mut Stream, line: *const u8, n: usize) -> i32 {
    match serde_json::from_slice::<GroupLine>(bytes(line, n)).map_err(|e| e.to_string()).and_then(|g| (*s).group(g)) {
        Ok(()) => 0,
        Err(e) => {
            failed(format!("group refused: {e}"));
            -1
        }
    }
}

/// A breath group's controls as the stream would shape them, `tail` seconds past its end besides (stream.rs spec): its
/// Spec as JSON (controls.rs), where it is (ow_text_len its length), valid until the next call; null where it cannot be
/// shaped (ow_error says why). What NESS plays a group from in a page (render/synthesis/src/ness-woodwind.mjs).
///
/// # Safety
/// `s` as ow_native_rate; `line` must address `n` bytes.
#[no_mangle]
pub unsafe extern "C" fn ow_spec(s: *const Stream, line: *const u8, n: usize, tail: f64) -> *const u8 {
    let made = serde_json::from_slice::<GroupLine>(bytes(line, n)).map_err(|e| e.to_string())
        .and_then(|g| (*s).spec(&g, tail)).and_then(|spec| serde_json::to_string(&spec).map_err(|e| e.to_string()));
    match made {
        Ok(text) => TEXT.with(|cell| {
            *cell.borrow_mut() = text;
            cell.borrow().as_ptr()
        }),
        Err(e) => {
            failed(format!("group not shaped: {e}"));
            std::ptr::null()
        }
    }
}

// (A live control's JSON, `n` bytes at `line`, taken by `take`: -> 0, or -1, `what` refused (ow_error says why).)
unsafe fn taken<T: serde::de::DeserializeOwned>(line: *const u8, n: usize, what: &str, take: impl FnOnce(T) -> Result<(), String>) -> i32 {
    match serde_json::from_slice::<T>(bytes(line, n)).map_err(|e| e.to_string()).and_then(take) {
        Ok(()) => 0,
        Err(e) => {
            failed(format!("{what} refused: {e}"));
            -1
        }
    }
}

// (Text for the page, where it is, valid until the next call; null where there is none (ow_error says why).)
fn text(made: Result<String, String>, what: &str) -> *const u8 {
    match made {
        Ok(text) => TEXT.with(|cell| {
            *cell.borrow_mut() = text;
            cell.borrow().as_ptr()
        }),
        Err(e) => {
            failed(format!("{what} refused: {e}"));
            std::ptr::null()
        }
    }
}

/// Its controls held at a row (stream.rs HeldLine as JSON): the stream binary's `h`. -> 0, or -1 (ow_error says why).
///
/// # Safety
/// `s` as ow_native_rate; `line` must address `n` bytes.
#[no_mangle]
pub unsafe extern "C" fn ow_hold(s: *mut Stream, line: *const u8, n: usize) -> i32 {
    taken(line, n, "held row", |h: HeldLine| (*s).hold(h.row, h.seconds, h.floor))
}

/// A vibrato on the row held (stream.rs VibratoLine): the stream binary's `v`.
///
/// # Safety
/// As ow_hold.
#[no_mangle]
pub unsafe extern "C" fn ow_vibrato(s: *mut Stream, line: *const u8, n: usize) -> i32 {
    taken(line, n, "vibrato", |v: VibratoLine| (*s).vibrato(v))
}

/// Its player's techniques on the row held (stream.rs TechniqueLine): the stream binary's `k`.
///
/// # Safety
/// As ow_hold.
#[no_mangle]
pub unsafe extern "C" fn ow_technique(s: *mut Stream, line: *const u8, n: usize) -> i32 {
    taken(line, n, "technique", |k: TechniqueLine| (*s).technique(k))
}

/// Its reed's or lips' flow's turbulence (stream.rs TurbulenceLine): the stream binary's `n`.
///
/// # Safety
/// As ow_hold.
#[no_mangle]
pub unsafe extern "C" fn ow_turbulence(s: *mut Stream, line: *const u8, n: usize) -> i32 {
    taken(line, n, "turbulence", |t: TurbulenceLine| (*s).turbulence(t))
}

/// Its player's noise of one kind (stream.rs NoiseLine): the stream binary's `p`.
///
/// # Safety
/// As ow_hold.
#[no_mangle]
pub unsafe extern "C" fn ow_noise(s: *mut Stream, line: *const u8, n: usize) -> i32 {
    taken(line, n, "noise", |p: NoiseLine| (*s).noise(p))
}

/// Its player's vocal tract (stream.rs TractLine): the stream binary's `t`.
///
/// # Safety
/// As ow_hold.
#[no_mangle]
pub unsafe extern "C" fn ow_tract(s: *mut Stream, line: *const u8, n: usize) -> i32 {
    taken(line, n, "tract", |t: TractLine| {
        (*s).tract(t.resonances, t.seconds);
        Ok(())
    })
}

/// Its slide drawn, where its body has one (stream.rs SlideLine): the stream binary's `s`.
///
/// # Safety
/// As ow_hold.
#[no_mangle]
pub unsafe extern "C" fn ow_slide(s: *mut Stream, line: *const u8, n: usize) -> i32 {
    taken(line, n, "slide", |l: SlideLine| (*s).slide(l.out, l.seconds))
}

/// The row a group's controls give some seconds after its start (stream.rs RowLine), as JSON: the stream binary's `o`.
/// -> where it is (ow_text_len its length), or null (ow_error says why).
///
/// # Safety
/// As ow_hold.
#[no_mangle]
pub unsafe extern "C" fn ow_row(s: *const Stream, line: *const u8, n: usize) -> *const u8 {
    text(serde_json::from_slice::<RowLine>(bytes(line, n)).map_err(|e| e.to_string())
        .and_then(|o| (*s).row(&o.line, o.seconds)).and_then(|row| serde_json::to_string(&row).map_err(|e| e.to_string())), "row")
}

/// Its controls' columns, as its body names them, as JSON: the stream binary's `c`. -> as ow_row.
///
/// # Safety
/// As ow_native_rate.
#[no_mangle]
pub unsafe extern "C" fn ow_columns(s: *const Stream) -> *const u8 {
    text(serde_json::to_string((*s).columns()).map_err(|e| e.to_string()), "columns")
}

/// The air its player spent since it was last asked (stream.rs Air) as JSON: the stream binary's `a`. -> as ow_row.
///
/// # Safety
/// As ow_native_rate.
#[no_mangle]
pub unsafe extern "C" fn ow_air(s: *mut Stream) -> *const u8 {
    text(serde_json::to_string(&(*s).air()).map_err(|e| e.to_string()), "air")
}

#[no_mangle]
pub extern "C" fn ow_text_len() -> usize {
    TEXT.with(|cell| cell.borrow().len())
}

/// The groups waiting from `seconds` of its clock on let go.
///
/// # Safety
/// As ow_native_rate.
#[no_mangle]
pub unsafe extern "C" fn ow_let_go(s: *mut Stream, seconds: f64) {
    (*s).let_go(seconds)
}

/// `frames` more frames of its sound at 48 kHz. -> where they are, valid until the next call; null where it failed
/// (ow_error says why).
///
/// # Safety
/// As ow_native_rate.
#[no_mangle]
pub unsafe extern "C" fn ow_render(s: *mut Stream, frames: usize) -> *const f32 {
    match (*s).render(frames) {
        Ok(v) => OUT.with(|cell| {
            *cell.borrow_mut() = v;
            cell.borrow().as_ptr()
        }),
        Err(e) => {
            failed(e);
            std::ptr::null()
        }
    }
}

/// # Safety
/// `s` must be ow_open's, closed once.
#[no_mangle]
pub unsafe extern "C" fn ow_close(s: *mut Stream) {
    if !s.is_null() {
        drop(Box::from_raw(s));
    }
}
