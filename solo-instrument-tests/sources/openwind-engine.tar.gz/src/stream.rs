//! A woodwind part played as one simulation for as long as it is played (research/OPENWIND_REALTIME_PLAN.md, design 0
//! and 6): its saved body (body.rs), its law and its player table (law.rs), each breath group shaped as it comes and
//! placed on the one simulation at its start (its first breath's), its controls driving the body from there until the
//! next group's begin -- held at its last values between them (its breath at rest, its tube ringing on), and every one
//! moved to the next group's first along the raised cosine over a key's or the lips' least time before it begins, as a
//! player sets fingers and lips in the rest. (Moved at once, the reed's opening and lips had jumped while the first
//! group's tail still rang: the closing pressure the reed's pressure is scaled by stepped with them, a click at the
//! second group's start.) Its sound what its holes and bell
//! radiate (each exit's flow's time derivative, summed: openwind_passages.py simulate_passage_once), brought to 48 kHz
//! by the renders' own filter (scipy's resample_poly, its taps in the body) and scaled as the renders scale it
//! (RADIATED_GAIN). The live host's and, from stage 7, the renders'. A body the engine has no law for -- brass lips, so
//! far (render/synthesis/tools/save_brass_body.py: its law.json `rowsOnly`) -- is played by rows held alone, the live
//! dial's, and refuses a group.

use crate::body::Body;
use crate::controls::{eased, Controls, Normal, Spec};
use crate::kernel::Player;
use crate::law::{Group, Law, NoteValues, Plan, Shaper, Table};
use crate::tract::{Resonance, Tract};
use serde::Deserialize;
use std::path::Path;

/// A breath group as the stream is told it: its origin (s, the player's clock), its plan (breath.mjs: times from its
/// origin), each note's pitch (MIDI, fractional) and velocity (0..1) -- or, where a note gives them, its values
/// themselves (law.rs NoteValues: a trial player's, as a fit plays it on the engine's own body) -- how early its first
/// breath begins and each change's lead (s).
#[derive(Deserialize, Clone, Debug)]
pub struct GroupLine {
    pub origin: f64,
    pub plan: Plan,
    pub notes: Vec<NoteLine>,
    #[serde(default)]
    pub ahead: f64,
    pub leads: Option<Vec<f64>>,
}

/// A row held as the live dial tells it (Stream::hold), or a group's row asked for (Stream::row); and where its body has a
/// jet, its speed's `floor` (m/s) beside it: the speed swayed by its vibrato, then never under it, its presence the share
/// of the speed asked that remains -- as the renders' law floors a jet (law.rs: a player's breath, its vibrato in it,
/// floored at JET_FLOOR of its notes'; controls.rs its presence).
#[derive(Deserialize, Clone, Debug)]
pub struct HeldLine {
    pub row: Vec<f64>,
    #[serde(default)]
    pub seconds: f64,
    #[serde(default)]
    pub floor: Option<f64>,
}

/// A vibrato on the row held, as the live dial sways it (Stream::vibrato): these columns, each by its depth -- a share of
/// its value where `cents` is false (a breath's sway: times 1 + depth sin), cents where true (the lips' frequency: times
/// 2^(depth sin / 1200)) -- at `rate` Hz, each depth moved to the one given along the raised cosine over `seconds`.
#[derive(Deserialize, Clone, Debug)]
pub struct VibratoLine {
    pub columns: Vec<usize>,
    pub depths: Vec<f64>,
    #[serde(default)]
    pub cents: Vec<bool>,
    pub rate: f64,
    #[serde(default)]
    pub seconds: f64,
}

/// A trombone's slide drawn as the live dial draws it (Stream::slide): to `out` m of tube added past its first position
/// (twice its hand's travel), along the raised cosine over `seconds` from where it stands.
#[derive(Deserialize, Clone, Debug)]
pub struct SlideLine {
    pub out: f64,
    #[serde(default)]
    pub seconds: f64,
}

#[derive(Deserialize, Clone, Debug)]
pub struct RowLine {
    pub line: GroupLine,
    pub seconds: f64,
}

/// Its player's vocal tract as the stream is told it: its resonances and the time it takes to move to them (s).
#[derive(Deserialize, Clone, Debug)]
pub struct TractLine {
    pub resonances: Vec<Resonance>,
    #[serde(default)]
    pub seconds: f64,
}

#[derive(Deserialize, Clone, Debug)]
pub struct NoteLine {
    pub midi: f64,
    pub velocity: f64,
    #[serde(default)]
    pub values: Option<NoteValues>,
}

/// A row of controls held as the live dial sets it (native/openwind/live.mjs): the row it moves from and the row it moves
/// to along the raised cosine, over so many native steps, so many taken; a jet's floor moved with it, where it has one.
struct Held {
    from: Vec<f64>,
    to: Vec<f64>,
    floor: Option<(f64, f64)>,
    steps: u64,
    taken: u64,
}

impl Held {
    fn into_row(&self, row: &mut [f64]) {
        let p = if self.steps == 0 { 1.0 } else { eased(self.taken as f64 / self.steps as f64) };
        for ((x, a), b) in row.iter_mut().zip(&self.from).zip(&self.to) {
            *x = a + (b - a) * p;
        }
    }

    /// Its jet's floor `ahead` native steps on, where it has one.
    fn floor_at(&self, ahead: u64) -> Option<f64> {
        let p = if self.steps == 0 { 1.0 } else { eased((self.taken + ahead).min(self.steps) as f64 / self.steps as f64) };
        self.floor.map(|(a, b)| a + (b - a) * p)
    }
}

/// A slide's motion: its pipe's length at first position and the most it is drawn out (m), the tube added it moves from
/// and to over so many native steps, so many taken, and the tube added its pipe was last stretched to.
struct Motion {
    length: f64,
    most: f64,
    from: f64,
    to: f64,
    steps: u64,
    taken: u64,
    set: f64,
}

impl Motion {
    /// The tube added where it stands.
    fn out(&self) -> f64 {
        let p = if self.steps == 0 { 1.0 } else { eased(self.taken as f64 / self.steps as f64) };
        self.from + (self.to - self.from) * p
    }
}

/// The held row's vibrato: each column's depth moving from one to the next over so many native steps, so many taken,
/// whether it is in cents, and the sway's phase (radians) and its step a native step.
struct Vibrato {
    from: Vec<f64>,
    to: Vec<f64>,
    cents: Vec<bool>,
    steps: u64,
    taken: u64,
    phase: f64,
    turn: f64,
}

impl Vibrato {
    fn depth(&self, c: usize, ahead: u64) -> f64 {
        let p = if self.steps == 0 { 1.0 } else { eased((self.taken + ahead) as f64 / self.steps as f64) };
        self.from[c] + (self.to[c] - self.from[c]) * p
    }

    /// `row` swayed as it stands `ahead` native steps on.
    fn into_row(&self, row: &mut [f64], ahead: u64) {
        let sine = (self.phase + self.turn * ahead as f64).sin();
        for (c, x) in row.iter_mut().enumerate() {
            let d = self.depth(c, ahead);
            if d != 0.0 {
                *x *= if self.cents[c] { (d * sine / 1200.0).exp2() } else { 1.0 + d * sine };
            }
        }
    }

    fn step(&mut self) {
        self.taken = (self.taken + 1).min(self.steps);
        self.phase = (self.phase + self.turn) % (2.0 * std::f64::consts::PI);
    }
}

/// A group shaped and waiting, or playing: the native step it begins at, its controls, its origin, its controls' first
/// row.
struct Placed {
    start: u64,
    origin: f64,
    controls: Controls,
    first: Vec<f64>,
}

pub struct Stream {
    pub law: Option<Law>,
    table: Option<Table>,
    shaper: Option<Shaper>,
    columns: Vec<Vec<serde_json::Value>>,
    player: Player,
    cols: usize,
    outs: usize,
    ratio: usize,
    rate: f64,
    gain: f64,
    taps: Vec<f64>,
    half_length: usize,
    // (Its columns moved to the next group's before it begins: all but a jet's turbulence.)
    moved: Vec<usize>,
    // (Native steps taken; the groups to come, by their start; the one playing; its last openings.)
    n: u64,
    waiting: Vec<Placed>,
    playing: Option<Placed>,
    // (Its radiated sound, native samples from `base`; the flow before them; the next output frame.)
    radiated: Vec<f64>,
    base: u64,
    flows: [f64; 2],
    frame: u64,
    started: bool,
    pub late: u64,
    u: Vec<f64>,
    y: Vec<f64>,
    // (The row held, where the live dial holds one; its vibrato; the last row stepped.)
    held: Option<Held>,
    vibrato: Option<Vibrato>,
    last: Vec<f64>,
    // (A flute's jet velocity, its time derivative and its next value, where its body has a jet: the columns a held row's
    // jet is followed by, as openwind_compiled.py's controls follow a group's; its value a step before.)
    jet: Option<(usize, usize, usize)>,
    jet_before: Option<f64>,
    // (A jet's presence column: the share of its speed asked that a held row's floor leaves it.)
    presence: Option<usize>,
    // (A jet's turbulence columns, and their draws: a held row holds each one's level, drawn from a step at a time.)
    noise: Vec<usize>,
    draws: Normal,
    // (A trombone's slide, where its body has one.)
    slide: Option<Motion>,
}

/// Native steps a block at most.
const BLOCK: usize = 4096;

impl Stream {
    /// The part's player on the body saved in `folder` (body.json, I.bin, D.bin, law.json, rules.json), its bore in
    /// singles where `single` or where its body says (its scheme's: body.json `single`).
    pub fn open(folder: &Path, single: bool) -> Result<Stream, String> {
        Stream::open_threaded(folder, single, 1)
    }

    /// The same, its bore stepped on `threads` cores where it splits so (kernel.rs Player::with_threads; parallel.rs):
    /// for a woodwind one core steps slower than it sounds.
    pub fn open_threaded(folder: &Path, single: bool, threads: usize) -> Result<Stream, String> {
        let body = Body::load(folder)?;
        let read = |name: &str| std::fs::read(folder.join(name)).map_err(|e| format!("{}: {e}", folder.join(name).display()));
        Stream::from_parts_threaded(body, &read("law.json")?, &read("rules.json")?, single, threads)
    }

    /// The part's player on a body and its law.json's and rules.json's bytes: a body saved and fetched, as a page has it
    /// (wasm.rs).
    pub fn from_parts(body: Body, law_text: &[u8], rules_text: &[u8], single: bool) -> Result<Stream, String> {
        Stream::from_parts_threaded(body, law_text, rules_text, single, 1)
    }

    /// The same, on `threads` cores where its bore splits so (one in a page whose WebAssembly is built without threads).
    pub fn from_parts_threaded(body: Body, law_text: &[u8], rules_text: &[u8], single: bool, threads: usize) -> Result<Stream, String> {
        let given: serde_json::Value = serde_json::from_slice(law_text).map_err(|e| format!("law.json: {e}"))?;
        let gain = given.get("radiatedGain").and_then(|g| g.as_f64()).ok_or("law.json has no radiatedGain")?;
        // (Played by rows held alone where its law says so: its rules the live dial's, none of the engine's.)
        let (law, table) = if given.get("rowsOnly").and_then(|r| r.as_bool()) == Some(true) {
            (None, None)
        } else {
            let law: Law = serde_json::from_value(given).map_err(|e| format!("law.json: {e}"))?;
            let table: Table = serde_json::from_slice(rules_text).map_err(|e| format!("rules.json: {e}"))?;
            (Some(law), Some(table))
        };
        let single = single || body.header.single;
        let player = if threads > 1 { body.player_threaded(single, threads)? } else { body.player(single)? };
        let (cols, outs) = player.columns();
        let h = &body.header;
        if h.resample.down != h.ratio || h.resample.taps.len() != 2 * h.resample.half_length + 1 {
            return Err("its resampling filter is not its ratio's".into());
        }
        let moved = h.columns.iter().enumerate().filter(|(_, col)| col.get(2).and_then(|k| k.as_str()) != Some("noise")).map(|(c, _)| c).collect();
        let noise = h.columns.iter().enumerate().filter(|(_, col)| col.first().and_then(|k| k.as_str()) == Some("flute") && col.get(2).and_then(|k| k.as_str()) == Some("noise")).map(|(c, _)| c).collect();
        let column = |name: &str| h.columns.iter().position(|col| col.first().and_then(|k| k.as_str()) == Some("flute") && col.get(2).and_then(|k| k.as_str()) == Some(name));
        let jet = match (column("Uj"), column("dUj"), column("next_Uj")) {
            (Some(a), Some(b), Some(c)) => Some((a, b, c)),
            _ => None,
        };
        Ok(Stream {
            shaper: law.as_ref().map(|law| Shaper { law: law.clone(), header: h.clone() }), law, table, columns: h.columns.clone(), player, cols, outs,
            ratio: h.ratio, rate: h.rate, gain,
            taps: h.resample.taps.clone(), half_length: h.resample.half_length, moved, n: 0, waiting: vec![], playing: None,
            radiated: vec![], base: 0, flows: [0.0, 0.0], frame: 0, started: false, late: 0, u: vec![], y: vec![], held: None, vibrato: None, last: vec![],
            jet, jet_before: None, presence: column("presence"), noise, draws: Normal::new(0),
            slide: h.slide.as_ref().map(|s| Motion { length: s.length, most: s.most, from: 0.0, to: 0.0, steps: 0, taken: 0, set: 0.0 }),
        })
    }

    /// Its native rate.
    pub fn native_rate(&self) -> f64 {
        self.rate * self.ratio as f64
    }

    /// The cores its bore is stepped on (fewer than asked where it splits into fewer parts).
    pub fn threads(&self) -> usize {
        self.player.threads()
    }

    /// A line's group as the shaper takes it: each note's values its table's (or its own), its seconds its plan's end
    /// and `tail` besides (openwind_passages.py passage_controls: its end, then its tail).
    fn shaped(&self, line: &GroupLine, tail: f64) -> Result<Spec, String> {
        let (Some(shaper), Some(table)) = (&self.shaper, &self.table) else {
            return Err("its body has no law to shape a group by: it plays rows held alone".into());
        };
        let items = line.notes.iter().map(|n| n.values.clone().map_or_else(|| table.at(n.midi, n.velocity), Ok)).collect::<Result<Vec<_>, _>>()?;
        let plan = line.plan.clone();
        let end = plan.end.max(plan.notes.last().map_or(0.0, |n| n.end - plan.origin)) + line.ahead;
        let group = Group { plan, notes: items, ahead: line.ahead, leads: line.leads.clone(), seconds: end + tail, seed: (line.origin * 1000.0) as u64 };
        shaper.shape(&group)
    }

    /// A breath group's controls as the stream would shape them, `tail` seconds past its end besides: what another
    /// engine plays the same group from (NESS's woodwinds in a page: render/synthesis/src/ness-woodwind.mjs).
    pub fn spec(&self, line: &GroupLine, tail: f64) -> Result<Spec, String> {
        self.shaped(line, tail)
    }

    /// A breath group shaped and placed: in place of a waiting one of the same origin, or of the one playing (its
    /// controls taken up where it stands). One whose start has already been rendered begins at once, counted late.
    pub fn group(&mut self, line: GroupLine) -> Result<(), String> {
        let spec = self.shaped(&line, 0.0)?;
        self.held = None;
        let begins = line.origin - line.ahead;
        let start_frame = (begins * self.rate).round().max(0.0) as u64;
        let mut start = start_frame * self.ratio as u64;
        let replacing = self.playing.as_ref().is_some_and(|p| (p.origin - line.origin).abs() < 1e-9);
        // (Its controls taken up where it now stands: that many steps on, as playing would have taken them.)
        let mut since = 0;
        if replacing || start < self.n {
            if !replacing {
                self.late += 1;
                start = self.n;
            } else {
                start = self.playing.as_ref().unwrap().start;
                since = self.n - start;
            }
        }
        // (Its controls' first row, which the group before moves to before it begins.)
        let mut first = vec![0.0; self.cols];
        Controls::new(spec.clone())?.fill(1, &mut first);
        let mut controls = Controls::new(spec)?;
        controls.skip(since);
        let placed = Placed { start, origin: line.origin, controls, first };
        if replacing {
            self.playing = Some(placed);
        } else {
            self.waiting.retain(|p| (p.origin - line.origin).abs() >= 1e-9);
            let at = self.waiting.partition_point(|p| p.start <= placed.start);
            self.waiting.insert(at, placed);
        }
        Ok(())
    }

    /// Its player's vocal tract (tract.rs) moved to `resonances` over `seconds` from where it stands; none, a mouth's
    /// pressure alone again once its answer has eased to nothing.
    pub fn tract(&mut self, resonances: Vec<Resonance>, seconds: f64) {
        let rate = self.native_rate();
        self.player.tract.get_or_insert_with(|| Tract::new(rate)).set(resonances, seconds);
    }

    /// Its controls' columns, as its body names them (body.json `columns`).
    pub fn columns(&self) -> &[Vec<serde_json::Value>] {
        &self.columns
    }

    /// The row of controls a group's shaping gives `seconds` after its start (its first breath's): where the live dial
    /// begins a note from. A jet's turbulence its level there, not a draw: held, the stream draws it a step at a time.
    pub fn row(&self, line: &GroupLine, seconds: f64) -> Result<Vec<f64>, String> {
        let mut controls = Controls::new(self.shaped(line, 0.0)?)?;
        controls.skip((seconds * self.native_rate()).round().max(0.0) as u64);
        let mut row = vec![0.0; self.cols];
        controls.fill(1, &mut row);
        for (at, level) in controls.noise_levels() {
            row[at] = level;
        }
        Ok(row)
    }

    /// Its controls held at `row` (the live dial's), moved there from where they stand along the raised cosine over
    /// `seconds`; a jet's speed, swayed, never under `floor` (HeldLine), where given; the groups waiting and playing let
    /// go. A group sent after plays from its own controls again.
    pub fn hold(&mut self, row: Vec<f64>, seconds: f64, floor: Option<f64>) -> Result<(), String> {
        if row.len() != self.cols {
            return Err(format!("a held row of {} controls for a body of {}", row.len(), self.cols));
        }
        if floor.is_some_and(|f| !(f > 0.0 && f.is_finite())) || floor.is_some() && self.jet.is_none() {
            return Err("a held row's floor is a jet's speed, more than none".into());
        }
        let from = match &self.held {
            Some(h) => {
                let mut now = vec![0.0; self.cols];
                h.into_row(&mut now);
                now
            }
            None if self.last.len() == self.cols => self.last.clone(),
            None => row.clone(),
        };
        // (Its floor moved from the one held, else from the one given.)
        let floor = floor.map(|f| (self.held.as_ref().and_then(|h| h.floor_at(0)).unwrap_or(f), f));
        // (A jet's value a step before: none where its row was a group's, its derivative then one-sided for a step.)
        if self.held.is_none() {
            self.jet_before = None;
        }
        self.held = Some(Held { from, to: row, floor, steps: (seconds * self.native_rate()).round().max(0.0) as u64, taken: 0 });
        self.waiting.clear();
        self.playing = None;
        self.started = true;
        Ok(())
    }

    /// Its slide drawn to `out` m of tube added past its first position (0 to its body's most), along the raised cosine
    /// over `seconds` from where it stands: its pipe stretched to it a sample at a time as it moves (Player::stretch), so
    /// a glissando as a trombonist's hand draws it. -> why not, where its body has no slide or `out` lies past it.
    pub fn slide(&mut self, out: f64, seconds: f64) -> Result<(), String> {
        let rate = self.native_rate();
        let Some(m) = self.slide.as_mut() else { return Err("its body has no slide".into()) };
        if !(0.0..=m.most).contains(&out) || !(seconds >= 0.0 && seconds.is_finite()) {
            return Err(format!("a slide drawn to {out} m, past its reach (0 to {} m), or over {seconds} s", m.most));
        }
        *m = Motion { from: m.out(), to: out, steps: (seconds * rate).round() as u64, taken: 0, ..*m };
        Ok(())
    }

    /// The tube its slide adds where it stands (m): none without one.
    pub fn slide_out(&self) -> f64 {
        self.slide.as_ref().map_or(0.0, |m| m.out())
    }

    /// The held row swayed by a vibrato (VibratoLine), each column's depth moved from where it stands to the one given
    /// over `seconds`, the rest's to none; its phase going on, its rate the one given from now.
    pub fn vibrato(&mut self, line: VibratoLine) -> Result<(), String> {
        let cols = self.cols;
        if line.depths.len() != line.columns.len() || !line.cents.is_empty() && line.cents.len() != line.columns.len() {
            return Err("a vibrato's depths (and cents, where given) one a column".into());
        }
        if line.columns.iter().any(|&c| c >= cols) || !line.rate.is_finite() || line.rate < 0.0 || line.depths.iter().any(|d| !d.is_finite()) {
            return Err(format!("a vibrato on columns under {cols}, at a rate of none or more, its depths finite"));
        }
        let (now, mut cents, phase) = match &self.vibrato {
            Some(v) => ((0..cols).map(|c| v.depth(c, 0)).collect(), v.cents.clone(), v.phase),
            None => (vec![0.0; cols], vec![false; cols], 0.0),
        };
        let mut to = vec![0.0; cols];
        for (k, &c) in line.columns.iter().enumerate() {
            to[c] = line.depths[k];
            let given = line.cents.get(k).copied().unwrap_or(false);
            // (A column whose kind of depth changes: from none, as the other kind's depth is no share of this one's.)
            if given != cents[c] && now[c] != 0.0 {
                return Err(format!("column {c}'s vibrato changes between cents and shares while it sways"));
            }
            cents[c] = given;
        }
        let rate = self.native_rate();
        self.vibrato = Some(Vibrato { from: now, to, cents, steps: (line.seconds * rate).round().max(0.0) as u64, taken: 0, phase,
                                      turn: 2.0 * std::f64::consts::PI * line.rate / rate });
        Ok(())
    }

    /// The held row `ahead` native steps on, its vibrato in it; then a jet's speed floored, the speed asked under its
    /// floor its presence's (controls.rs: its player's breath over the speed given).
    fn held_at(&self, held: &Held, ahead: u64, row: &mut [f64]) {
        let p = if held.steps == 0 { 1.0 } else { eased((held.taken + ahead).min(held.steps) as f64 / held.steps as f64) };
        for ((x, a), b) in row.iter_mut().zip(&held.from).zip(&held.to) {
            *x = a + (b - a) * p;
        }
        if let Some(v) = &self.vibrato {
            v.into_row(row, ahead);
        }
        if let (Some((uj, _, _)), Some(floor)) = (self.jet, held.floor_at(ahead)) {
            let asked = row[uj];
            row[uj] = asked.max(floor);
            if let Some(at) = self.presence {
                row[at] *= (asked / row[uj]).clamp(0.0, 1.0);
            }
        }
    }

    /// The groups waiting from `seconds` of its clock on let go.
    pub fn let_go(&mut self, seconds: f64) {
        let from = ((seconds * self.rate).round().max(0.0) as u64) * self.ratio as u64;
        self.waiting.retain(|p| p.start < from || p.start < self.n);
    }

    /// `frames` more frames of its sound at 48 kHz, scaled as the renders scale it.
    pub fn render(&mut self, frames: usize) -> Result<Vec<f32>, String> {
        let (ratio, l) = (self.ratio as u64, self.half_length as u64);
        let last = self.frame + frames as u64;
        // (Native samples needed: to the last frame's filter's end, and one more for its time derivative.)
        let needed = (last - 1) * ratio + l + 1;
        while self.base + (self.radiated.len() as u64) < needed {
            self.advance(needed)?;
        }
        let mut out = Vec::with_capacity(frames);
        for m in self.frame..last {
            let centre = m * ratio + l;
            let mut sum = 0.0;
            for (j, &h) in self.taps.iter().enumerate() {
                let i = centre as i64 - j as i64;
                if i >= self.base as i64 {
                    sum += h * self.radiated[(i as u64 - self.base) as usize];
                }
            }
            out.push((sum * self.gain) as f32);
        }
        self.frame = last;
        // (What no later frame reads let go.)
        let keep_from = (self.frame * ratio).saturating_sub(l + 1);
        if keep_from > self.base + 65536 {
            let drop = (keep_from - self.base) as usize;
            self.radiated.drain(..drop);
            self.base += drop as u64;
        }
        Ok(out)
    }

    /// Native samples of its radiated sound until `needed` are known (each the flow's central difference, so one step
    /// past it taken).
    fn advance(&mut self, needed: u64) -> Result<(), String> {
        let scale = self.ratio as f64 * self.rate;
        if let Some(mut held) = self.held.take() {
            // (Only the steps its sound needs: a row held next, between two of the dial's pulls of sound, begins on the
            // step after the last one heard, not up to a block of steps later.)
            let steps = (needed + 1).saturating_sub(self.n).clamp(1, BLOCK as u64) as usize;
            let cols = self.cols;
            let mut u = std::mem::take(&mut self.u);
            u.resize(steps * cols, 0.0);
            self.y.resize(steps * self.outs, 0.0);
            let mut next = vec![0.0; cols];
            for k in 0..steps {
                let row = &mut u[k * cols..(k + 1) * cols];
                self.held_at(&held, 0, row);
                // (A jet's turbulence: its level held, drawn each step as a group's is.)
                for &c in &self.noise {
                    row[c] *= self.draws.next();
                }
                // (A jet's derivative and next value its held curve's, a step either side, as a group's are.)
                if let Some((uj, duj, next_uj)) = self.jet {
                    self.held_at(&held, 1, &mut next);
                    let before = self.jet_before.unwrap_or(row[uj]);
                    row[duj] = (next[uj] - before) / 2.0 * scale;
                    row[next_uj] = next[uj];
                    self.jet_before = Some(row[uj]);
                }
                held.taken = (held.taken + 1).min(held.steps);
                if let Some(v) = self.vibrato.as_mut() {
                    v.step();
                }
            }
            self.u = u;
            self.held = Some(held);
            return self.stepped(steps, scale);
        }
        // (Its next group begins: it plays from here.)
        if self.waiting.first().is_some_and(|p| p.start <= self.n) {
            self.playing = Some(self.waiting.remove(0));
            self.started = true;
        }
        if !self.started {
            // (Nothing begun: the body at rest, its flow nothing, no step taken.)
            let until = self.waiting.first().map_or(needed + 1, |p| p.start).min(needed + 1);
            for _ in self.n..until.max(self.n + 1) {
                self.take(0.0, scale);
            }
            return Ok(());
        }
        let next = self.waiting.first().map(|p| p.start);
        let least = |kind: &str| self.law.as_ref().and_then(|law| law.transitions.get(kind).copied()).unwrap_or(0.01);
        let key = (least("key").max(least("lips")) * scale).round() as u64;
        let mut steps = BLOCK as u64;
        if let Some(s) = next {
            // (Stop where the controls begin to move to the next group's, and where it begins.)
            let moving = s.saturating_sub(key);
            if self.n < moving {
                steps = steps.min(moving - self.n);
            } else {
                steps = steps.min(s - self.n);
            }
        }
        let steps = steps.max(1) as usize;
        let (cols, outs) = (self.cols, self.outs);
        self.u.resize(steps * cols, 0.0);
        self.y.resize(steps * outs, 0.0);
        let playing = self.playing.as_mut().ok_or("no group playing")?;
        playing.controls.fill(steps, &mut self.u);
        if let Some(s) = next {
            let first = &self.waiting[0].first;
            if s > self.n && s - self.n <= key + steps as u64 && !first.is_empty() {
                for k in 0..steps {
                    let at = self.n + k as u64;
                    if at + key < s {
                        continue;
                    }
                    let p = eased(1.0 - (s - at) as f64 / key.max(1) as f64);
                    for &c in &self.moved {
                        let was = self.u[k * cols + c];
                        self.u[k * cols + c] = was + (first[c] - was) * p;
                    }
                }
            }
        }
        self.stepped(steps, scale)
    }

    /// The `steps` rows of controls in `u` stepped, their flows taken, the last row kept. While a slide moves, its pipe
    /// stretched to where it stands at each output sample's steps.
    fn stepped(&mut self, steps: usize, scale: f64) -> Result<(), String> {
        let (cols, outs) = (self.cols, self.outs);
        let mut done = 0;
        while done < steps {
            // (Moving, or moved to where its pipe does not yet stand: an output sample's steps at a time.)
            let run = match self.slide.as_mut() {
                Some(m) if m.taken < m.steps || m.out() != m.set => {
                    let out = m.out();
                    if out != m.set {
                        self.player.stretch((m.length + out) / m.length);
                        m.set = out;
                    }
                    let run = (steps - done).min(self.ratio);
                    m.taken = (m.taken + run as u64).min(m.steps);
                    run
                }
                _ => steps - done,
            };
            let status = self.player.steps(&self.u[done * cols..(done + run) * cols], &mut self.y[done * outs..(done + run) * outs], run);
            if status != 0 {
                return Err(format!("the body stopped at step {} ({status})", self.n + done as u64));
            }
            done += run;
        }
        for k in 0..steps {
            let flow = self.y[k * outs];
            self.take(flow, scale);
        }
        self.last.clear();
        self.last.extend_from_slice(&self.u[(steps - 1) * cols..steps * cols]);
        Ok(())
    }

    /// A step's flow taken: the radiated sound at the step before it, the flow's central difference (np.gradient's;
    /// from rest before the first), `scale` the native rate.
    fn take(&mut self, flow: f64, scale: f64) {
        if self.n >= 1 {
            self.radiated.push((flow - self.flows[0]) / 2.0 * scale);
        }
        self.flows = [self.flows[1], flow];
        self.n += 1;
    }
}
