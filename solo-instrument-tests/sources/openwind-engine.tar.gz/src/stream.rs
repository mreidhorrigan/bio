//! A woodwind part played as one simulation for as long as it is played (research/OPENWIND_REALTIME_PLAN.md, design 0
//! and 6): its saved body (body.rs), its law and its player table (law.rs), each breath group shaped as it comes and
//! placed on the one simulation at its start (its first breath's), its controls driving the body from there until the
//! next group's begin -- held at its last values between them (its breath at rest, its tube ringing on), and every one
//! moved to the next group's first along the raised cosine over a key's or the lips' least time before it begins, as a
//! player sets fingers and lips in the rest. (Moved at once, the reed's opening and lips had jumped while the first
//! group's tail still rang: the closing pressure the reed's pressure is scaled by stepped with them, a click at the
//! second group's start.) Its sound what its holes and bell
//! radiate (each exit's flow's time derivative, summed: openwind_passages.py simulate_passage_once), brought to 48 kHz
//! by the renders' own filter (scipy's resample_poly, its taps in the body) and scaled as the renders scale it
//! (RADIATED_GAIN). The live host's and, from stage 7, the renders'. A body the engine has no law for -- brass lips, so
//! far (render/synthesis/tools/save_brass_body.py: its law.json `rowsOnly`) -- is played by rows held alone, the live
//! dial's, and refuses a group.

use crate::body::Body;
use crate::controls::{eased, Controls, Normal, Spec};
use crate::kernel::Player;
use crate::law::{Group, Law, NoteValues, Plan, Shaper, Table};
use crate::noise::{PlayerNoise, Profile, What};
use crate::technique::{self, Techniques};
use crate::tract::{Resonance, Tract};
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::path::Path;

/// A breath group as the stream is told it: its origin (s, the player's clock), its plan (breath.mjs: times from its
/// origin), each note's pitch (MIDI, fractional) and velocity (0..1) -- or, where a note gives them, its values
/// themselves (law.rs NoteValues: a trial player's, as a fit plays it on the engine's own body) -- how early its first
/// breath begins and each change's lead (s).
#[derive(Deserialize, Clone, Debug)]
pub struct GroupLine {
    pub origin: f64,
    pub plan: Plan,
    pub notes: Vec<NoteLine>,
    #[serde(default)]
    pub ahead: f64,
    pub leads: Option<Vec<f64>>,
}

/// A row held as the live dial tells it (Stream::hold), or a group's row asked for (Stream::row); and where its body has a
/// jet, its speed's `floor` (m/s) beside it: the speed swayed by its vibrato, then never under it, its presence the share
/// of the speed asked that remains -- as the renders' law floors a jet (law.rs: a player's breath, its vibrato in it,
/// floored at JET_FLOOR of its notes'; controls.rs its presence).
#[derive(Deserialize, Clone, Debug)]
pub struct HeldLine {
    pub row: Vec<f64>,
    #[serde(default)]
    pub seconds: f64,
    #[serde(default)]
    pub floor: Option<f64>,
}

/// A vibrato on the row held, as the live dial sways it (Stream::vibrato): these columns, each by its depth -- a share of
/// its value where `cents` is false (a breath's sway: times 1 + depth sin), cents where true (the lips' frequency: times
/// 2^(depth sin / 1200)) -- at `rate` Hz, each depth moved to the one given along the raised cosine over `seconds`.
#[derive(Deserialize, Clone, Debug)]
pub struct VibratoLine {
    pub columns: Vec<usize>,
    pub depths: Vec<f64>,
    #[serde(default)]
    pub cents: Vec<bool>,
    pub rate: f64,
    #[serde(default)]
    pub seconds: f64,
}

/// A trombone's slide drawn as the live dial draws it (Stream::slide): to `out` m of tube added past its first position
/// (twice its hand's travel), along the raised cosine over `seconds` from where it stands.
#[derive(Deserialize, Clone, Debug)]
pub struct SlideLine {
    pub out: f64,
    #[serde(default)]
    pub seconds: f64,
}

#[derive(Deserialize, Clone, Debug)]
pub struct RowLine {
    pub line: GroupLine,
    pub seconds: f64,
}

/// Its player's vocal tract as the stream is told it: its resonances and the time it takes to move to them (s).
#[derive(Deserialize, Clone, Debug)]
pub struct TractLine {
    pub resonances: Vec<Resonance>,
    #[serde(default)]
    pub seconds: f64,
}

/// A reed's or the lips' flow's turbulence as the stream is told it (registry/players/winds.json flow.turbulence;
/// public/shared/performers/turbulence.js): its level, a share of the flow per root hertz, white to the native rate.
#[derive(Deserialize, Clone, Debug)]
pub struct TurbulenceLine {
    pub level: f64,
}

/// Its player's noise of one kind as the stream is told it (noise.rs PlayerNoise; public/shared/performers/
/// player-noise.js): what it moves -- `breath`, its mouth's pressure, or `lips`, brass lips' tension -- its deviation at
/// temperature 1 (a share of what is asked), its temperature, and its profile (Hz: its power falling as 1/f^beta from
/// `low` to `high`, a tremor carrying its share of the variance); and its player's seed, where given, every stream begun
/// again from it.
#[derive(Deserialize, Clone, Debug)]
pub struct NoiseLine {
    #[serde(default)]
    pub seed: Option<u64>,
    pub what: String,
    pub sd: f64,
    pub temperature: f64,
    pub beta: f64,
    pub low: f64,
    pub high: f64,
    #[serde(default)]
    pub tremor: Option<TremorLine>,
}

/// A noise's tremor: a resonance at `hz`, of bandwidth hz/q, carrying `share` of its variance.
#[derive(Deserialize, Clone, Copy, Debug)]
pub struct TremorLine {
    pub hz: f64,
    pub q: f64,
    pub share: f64,
}

/// The air its player spent since it was last asked (Stream::air): what flowed into its bore (L) over the seconds of its
/// clock that passed, sounding or not.
#[derive(Serialize, Clone, Copy, Debug, Default)]
pub struct Air {
    pub litres: f64,
    pub seconds: f64,
}

/// A flute's jet's flow (m^3/s) from a row of its controls, as its kernel takes its jet from them -- which reports none of
/// it, its jet's flow leaving by its window and not into its bore: its speed, times its presence, times its section. Its
/// height h its edge's offset over its row's y0 (controls.rs jet_parameters: y0 its edge's offset over b, b its profile's
/// share of h, else 2h/5); its width a transverse flute's lip opening's, `aspect` times h, else its window's, the window's
/// section over its jet's length (its row's C times its convection).
struct JetAir {
    uj: usize,
    presence: Option<usize>,
    y0: usize,
    c: usize,
    edge: f64,
    profile: f64,
    aspect: Option<f64>,
    convection: f64,
    section: f64,
}

impl JetAir {
    fn flow(&self, row: &[f64]) -> f64 {
        let y0 = row[self.y0];
        if !(y0 > 0.0) {
            return 0.0;
        }
        let h = self.edge / y0 / self.profile;
        let width = match self.aspect {
            Some(aspect) => aspect * h,
            None => {
                let length = row[self.c] * self.convection;
                if !(length > 0.0) {
                    return 0.0;
                }
                self.section / length
            }
        };
        row[self.uj] * self.presence.map_or(1.0, |p| row[p]) * h * width
    }
}

/// A group's note: its pitch (MIDI, fractional), its velocity (0..1), its values where it gives them, and its techniques
/// where it has them (technique.rs: a hum, a growl, a flutter), in its breath as the renders play them.
#[derive(Deserialize, Clone, Debug)]
pub struct NoteLine {
    pub midi: f64,
    pub velocity: f64,
    #[serde(default)]
    pub values: Option<NoteValues>,
    #[serde(default)]
    pub technique: Option<Techniques>,
}

/// Its player's techniques on the row held, as the live dial plays them (Stream::technique): the column of its breath
/// they move (a reed's or the lips' gamma, a reed's mouth pressure, a jet's speed), a hum, a growl or a flutter
/// (technique.rs), each moved to from where it stands over `seconds`, one not given let go; and where its note stops
/// speaking in that column's units (`floor`: a reed's, law.rs NoteValues `speaks`), its flutter closing off only the
/// breath over it.
#[derive(Deserialize, Clone, Debug)]
pub struct TechniqueLine {
    pub column: usize,
    #[serde(flatten)]
    pub techniques: Techniques,
    #[serde(default)]
    pub seconds: f64,
    #[serde(default)]
    pub floor: Option<f64>,
}

/// A row of controls held as the live dial sets it (native/openwind/live.mjs): the row it moves from and the row it moves
/// to along the raised cosine, over so many native steps, so many taken; a jet's floor moved with it, where it has one.
struct Held {
    from: Vec<f64>,
    to: Vec<f64>,
    floor: Option<(f64, f64)>,
    steps: u64,
    taken: u64,
}

impl Held {
    fn into_row(&self, row: &mut [f64]) {
        let p = if self.steps == 0 { 1.0 } else { eased(self.taken as f64 / self.steps as f64) };
        for ((x, a), b) in row.iter_mut().zip(&self.from).zip(&self.to) {
            *x = a + (b - a) * p;
        }
    }

    /// Its jet's floor `ahead` native steps on, where it has one.
    fn floor_at(&self, ahead: u64) -> Option<f64> {
        let p = if self.steps == 0 { 1.0 } else { eased((self.taken + ahead).min(self.steps) as f64 / self.steps as f64) };
        self.floor.map(|(a, b)| a + (b - a) * p)
    }
}

/// A slide's motion: its pipe's length at first position and the most it is drawn out (m), the tube added it moves from
/// and to over so many native steps, so many taken, and the tube added its pipe was last stretched to.
struct Motion {
    length: f64,
    most: f64,
    from: f64,
    to: f64,
    steps: u64,
    taken: u64,
    set: f64,
}

impl Motion {
    /// The tube added where it stands.
    fn out(&self) -> f64 {
        let p = if self.steps == 0 { 1.0 } else { eased(self.taken as f64 / self.steps as f64) };
        self.from + (self.to - self.from) * p
    }
}

/// The held row's vibrato: each column's depth moving from one to the next over so many native steps, so many taken,
/// whether it is in cents, and the sway's phase (radians) and its step a native step.
struct Vibrato {
    from: Vec<f64>,
    to: Vec<f64>,
    cents: Vec<bool>,
    steps: u64,
    taken: u64,
    phase: f64,
    turn: f64,
}

impl Vibrato {
    fn depth(&self, c: usize, ahead: u64) -> f64 {
        let p = if self.steps == 0 { 1.0 } else { eased((self.taken + ahead) as f64 / self.steps as f64) };
        self.from[c] + (self.to[c] - self.from[c]) * p
    }

    /// `row` swayed as it stands `ahead` native steps on.
    fn into_row(&self, row: &mut [f64], ahead: u64) {
        let sine = (self.phase + self.turn * ahead as f64).sin();
        for (c, x) in row.iter_mut().enumerate() {
            let d = self.depth(c, ahead);
            if d != 0.0 {
                *x *= if self.cents[c] { (d * sine / 1200.0).exp2() } else { 1.0 + d * sine };
            }
        }
    }

    fn step(&mut self) {
        self.taken = (self.taken + 1).min(self.steps);
        self.phase = (self.phase + self.turn) % (2.0 * std::f64::consts::PI);
    }
}

/// A group shaped and waiting, or playing: the native step it begins at, its controls, its origin, its controls' first
/// row.
struct Placed {
    start: u64,
    origin: f64,
    controls: Controls,
    first: Vec<f64>,
}

pub struct Stream {
    pub law: Option<Law>,
    table: Option<Table>,
    shaper: Option<Shaper>,
    columns: Vec<Vec<serde_json::Value>>,
    player: Player,
    cols: usize,
    outs: usize,
    ratio: usize,
    rate: f64,
    gain: f64,
    taps: Vec<f64>,
    half_length: usize,
    // (Its columns moved to the next group's before it begins: all but a jet's turbulence.)
    moved: Vec<usize>,
    // (Native steps taken; the groups to come, by their start; the one playing; its last openings.)
    n: u64,
    waiting: Vec<Placed>,
    playing: Option<Placed>,
    // (Its radiated sound, native samples from `base`; the flow before them; the next output frame.)
    radiated: Vec<f64>,
    base: u64,
    flows: [f64; 2],
    frame: u64,
    started: bool,
    pub late: u64,
    u: Vec<f64>,
    y: Vec<f64>,
    // (The row held, where the live dial holds one; its vibrato; the last row stepped.)
    held: Option<Held>,
    vibrato: Option<Vibrato>,
    technique: Option<technique::Held>,
    last: Vec<f64>,
    // (A flute's jet velocity, its time derivative and its next value, where its body has a jet: the columns a held row's
    // jet is followed by, as openwind_compiled.py's controls follow a group's; its value a step before.)
    jet: Option<(usize, usize, usize)>,
    jet_before: Option<f64>,
    // (A jet's presence column: the share of its speed asked that a held row's floor leaves it.)
    presence: Option<usize>,
    // (A jet's turbulence columns, and their draws: a held row holds each one's level, drawn from a step at a time.)
    noise: Vec<usize>,
    draws: Normal,
    // (A reed's or the lips' flow's turbulence: its level, the columns of each slit's coefficient it moves, and their
    // draws, apart from a jet's.)
    turbulence: f64,
    slits: Vec<usize>,
    whirls: Normal,
    // (A trombone's slide, where its body has one.)
    slide: Option<Motion>,
    // (The air it spends: its player's output of the flow into its bore (kernel.rs Player::breathing), or its jet's; the
    // flow summed over the native steps since it was last asked (m^3 a step), and those steps.)
    air_at: Option<usize>,
    jet_air: Option<JetAir>,
    spent: f64,
    spent_steps: u64,
    // (Its player's noise: the columns its breath's pressure moves -- a reed's or the lips' gamma; a jet's speed, `jet` --
    // and the columns of the lips' resonance their tension moves, where it has lips.)
    player_noise: PlayerNoise,
    gammas: Vec<usize>,
    pulsations: Vec<usize>,
    // (Native samples of its radiated sound under SILENT, in a row: its bore rung down once they reach RUNG_DOWN's.)
    quiet: u64,
}

/// Native steps a block at most.
const BLOCK: usize = 4096;
/// The smallest step of a 24-bit file (openwind-stream.js SILENT): a sound under it is none.
const SILENT: f64 = 1.0 / 8_388_608.0;
/// How long its sound stays under SILENT before its bore counts as rung down (s): more than half a period of the
/// lowest note a wind plays (the contrabassoon's B♭0, 34 ms), so a wave still swinging is never taken for one gone.
const RUNG_DOWN: f64 = 0.05;

impl Stream {
    /// The part's player on the body saved in `folder` (body.json, I.bin, D.bin, law.json, rules.json), its bore in
    /// singles where `single` or where its body says (its scheme's: body.json `single`).
    pub fn open(folder: &Path, single: bool) -> Result<Stream, String> {
        Stream::open_threaded(folder, single, 1)
    }

    /// The same, its bore stepped on `threads` cores where it splits so (kernel.rs Player::with_threads; parallel.rs):
    /// for a woodwind one core steps slower than it sounds.
    pub fn open_threaded(folder: &Path, single: bool, threads: usize) -> Result<Stream, String> {
        let body = Body::load(folder)?;
        let read = |name: &str| std::fs::read(folder.join(name)).map_err(|e| format!("{}: {e}", folder.join(name).display()));
        Stream::from_parts_threaded(body, &read("law.json")?, &read("rules.json")?, single, threads)
    }

    /// The part's player on a body and its law.json's and rules.json's bytes: a body saved and fetched, as a page has it
    /// (wasm.rs).
    pub fn from_parts(body: Body, law_text: &[u8], rules_text: &[u8], single: bool) -> Result<Stream, String> {
        Stream::from_parts_threaded(body, law_text, rules_text, single, 1)
    }

    /// The same, on `threads` cores where its bore splits so (one in a page whose WebAssembly is built without threads).
    pub fn from_parts_threaded(body: Body, law_text: &[u8], rules_text: &[u8], single: bool, threads: usize) -> Result<Stream, String> {
        let given: serde_json::Value = serde_json::from_slice(law_text).map_err(|e| format!("law.json: {e}"))?;
        let gain = given.get("radiatedGain").and_then(|g| g.as_f64()).ok_or("law.json has no radiatedGain")?;
        // (What its law sets of a jet's: its reed's constants, a transverse flute's.)
        let jet_given = |group: &str, k: &str| given.get(group).and_then(|g| g.get(k)).and_then(|v| v.as_f64());
        let (edge, convection, section) = (jet_given("reed", "edge_offset"), jet_given("reed", "convection"), jet_given("reed", "section"));
        let transverse = given.get("transverse").filter(|t| t.is_object())
            .map(|_| (jet_given("transverse", "aspect"), jet_given("transverse", "profile"), jet_given("transverse", "convection")));
        // (Played by rows held alone where its law says so: its rules the live dial's, none of the engine's.)
        let (law, table) = if given.get("rowsOnly").and_then(|r| r.as_bool()) == Some(true) {
            (None, None)
        } else {
            let law: Law = serde_json::from_value(given).map_err(|e| format!("law.json: {e}"))?;
            let table: Table = serde_json::from_slice(rules_text).map_err(|e| format!("rules.json: {e}"))?;
            (Some(law), Some(table))
        };
        // (Lips where its rules are the lips': render/synthesis/tools/save_brass_body.py.)
        #[derive(Deserialize)]
        struct Kind {
            kind: Option<String>,
        }
        let lips = serde_json::from_slice::<Kind>(rules_text).ok().and_then(|k| k.kind).as_deref() == Some("lips");
        let single = single || body.header.single;
        let player = body.breathing(single, threads)?;
        let (cols, outs) = player.columns();
        let h = &body.header;
        if h.resample.down != h.ratio || h.resample.taps.len() != 2 * h.resample.half_length + 1 {
            return Err("its resampling filter is not its ratio's".into());
        }
        let moved = h.columns.iter().enumerate().filter(|(_, col)| col.get(2).and_then(|k| k.as_str()) != Some("noise")).map(|(c, _)| c).collect();
        let noise = h.columns.iter().enumerate().filter(|(_, col)| col.first().and_then(|k| k.as_str()) == Some("flute") && col.get(2).and_then(|k| k.as_str()) == Some("noise")).map(|(c, _)| c).collect();
        let column = |name: &str| h.columns.iter().position(|col| col.first().and_then(|k| k.as_str()) == Some("flute") && col.get(2).and_then(|k| k.as_str()) == Some(name));
        let reeds = |name: &str| -> Vec<usize> {
            h.columns.iter().enumerate().filter(|(_, col)| col.first().and_then(|k| k.as_str()) == Some("reed") && col.get(2).and_then(|k| k.as_str()) == Some(name)).map(|(c, _)| c).collect()
        };
        let slits = reeds("zeta");
        let (gammas, pulsations) = (reeds("gamma"), if lips { reeds("pulsation") } else { vec![] });
        let jet = match (column("Uj"), column("dUj"), column("next_Uj")) {
            (Some(a), Some(b), Some(c)) => Some((a, b, c)),
            _ => None,
        };
        // (Its jet's constants as its law gives them its flute (law.rs Shaper flute), else as its body holds them.)
        let jet_air = match (&h.flute, jet, column("y0"), column("C")) {
            (Some(f), Some((uj, _, _)), Some(y0), Some(c)) if player.air().is_none() => Some(JetAir {
                uj, presence: column("presence"), y0, c,
                edge: edge.unwrap_or(f.edge_offset),
                profile: transverse.map_or(f.profile, |t| t.1).unwrap_or(0.4),
                aspect: transverse.map_or(f.aspect, |t| t.0),
                convection: transverse.and_then(|t| t.2).or(convection).unwrap_or(f.convection),
                section: section.unwrap_or(f.section),
            }),
            _ => None,
        };
        let air_at = player.air();
        Ok(Stream {
            shaper: law.as_ref().map(|law| Shaper { law: law.clone(), header: h.clone() }), law, table, columns: h.columns.clone(), player, cols, outs,
            ratio: h.ratio, rate: h.rate, gain,
            taps: h.resample.taps.clone(), half_length: h.resample.half_length, moved, n: 0, waiting: vec![], playing: None,
            radiated: vec![], base: 0, flows: [0.0, 0.0], frame: 0, started: false, late: 0, u: vec![], y: vec![], held: None, vibrato: None, technique: None, last: vec![],
            jet, jet_before: None, presence: column("presence"), noise, draws: Normal::new(0), turbulence: 0.0, slits, whirls: Normal::new(1),
            slide: h.slide.as_ref().map(|s| Motion { length: s.length, most: s.most, from: 0.0, to: 0.0, steps: 0, taken: 0, set: 0.0 }),
            air_at, jet_air, spent: 0.0, spent_steps: 0,
            player_noise: PlayerNoise::new(h.rate, h.ratio), gammas, pulsations, quiet: 0,
        })
    }

    /// The air its player spent since it was last asked: the flow into its bore its reed or its lips let in (kernel.rs
    /// Player::breathing), or its jet's (JetAir), summed over its native steps.
    pub fn air(&mut self) -> Air {
        let seconds = self.spent_steps as f64 / self.native_rate();
        let air = Air { litres: self.spent * 1000.0 / self.native_rate(), seconds };
        self.spent = 0.0;
        self.spent_steps = 0;
        air
    }

    /// Its native rate.
    pub fn native_rate(&self) -> f64 {
        self.rate * self.ratio as f64
    }

    /// The cores its bore is stepped on (fewer than asked where it splits into fewer parts).
    pub fn threads(&self) -> usize {
        self.player.threads()
    }

    /// A line's group as the shaper takes it: each note's values its table's (or its own), its seconds its plan's end
    /// and `tail` besides (openwind_passages.py passage_controls: its end, then its tail).
    fn shaped(&self, line: &GroupLine, tail: f64) -> Result<Spec, String> {
        let (Some(shaper), Some(table)) = (&self.shaper, &self.table) else {
            return Err("its body has no law to shape a group by: it plays rows held alone".into());
        };
        // (Each note after the group's first fingered as its player's fingers stand from the note before it, where its
        // table's values are its own: Table::fingered, as the renders finger it.)
        let mut before: Option<HashMap<String, f64>> = None;
        let items = line.notes.iter().map(|n| {
            let mut values = match &n.values {
                Some(own) => own.clone(),
                None => {
                    let mut values = table.at(n.midi, n.velocity)?;
                    if let Some(held) = &before {
                        table.fingered(n.midi, &mut values, held);
                    }
                    values
                }
            };
            before = Some(values.fingering.clone());
            if let Some(t) = &n.technique {
                t.check()?;
                values.technique = Some(t.clone());
            }
            Ok(values)
        }).collect::<Result<Vec<_>, String>>()?;
        let plan = line.plan.clone();
        let end = plan.end.max(plan.notes.last().map_or(0.0, |n| n.end - plan.origin)) + line.ahead;
        let group = Group { plan, notes: items, ahead: line.ahead, leads: line.leads.clone(), seconds: end + tail, seed: (line.origin * 1000.0) as u64 };
        shaper.shape(&group)
    }

    /// A breath group's controls as the stream would shape them, `tail` seconds past its end besides: what another
    /// engine plays the same group from (NESS's woodwinds in a page: render/synthesis/src/ness-woodwind.mjs).
    pub fn spec(&self, line: &GroupLine, tail: f64) -> Result<Spec, String> {
        self.shaped(line, tail)
    }

    /// A breath group shaped and placed: in place of a waiting one of the same origin, or of the one playing (its
    /// controls taken up where it stands). One whose start has already been rendered begins at once, counted late.
    pub fn group(&mut self, line: GroupLine) -> Result<(), String> {
        let spec = self.shaped(&line, 0.0)?;
        self.held = None;
        let begins = line.origin - line.ahead;
        let start_frame = (begins * self.rate).round().max(0.0) as u64;
        let mut start = start_frame * self.ratio as u64;
        let replacing = self.playing.as_ref().is_some_and(|p| (p.origin - line.origin).abs() < 1e-9);
        // (Its controls taken up where it now stands: that many steps on, as playing would have taken them.)
        let mut since = 0;
        if replacing || start < self.n {
            if !replacing {
                self.late += 1;
                start = self.n;
            } else {
                start = self.playing.as_ref().unwrap().start;
                since = self.n - start;
            }
        }
        // (Its controls' first row, which the group before moves to before it begins.)
        let mut first = vec![0.0; self.cols];
        Controls::new(spec.clone())?.fill(1, &mut first);
        let mut controls = Controls::new(spec)?;
        controls.skip(since);
        let placed = Placed { start, origin: line.origin, controls, first };
        if replacing {
            self.playing = Some(placed);
        } else {
            self.waiting.retain(|p| (p.origin - line.origin).abs() >= 1e-9);
            let at = self.waiting.partition_point(|p| p.start <= placed.start);
            self.waiting.insert(at, placed);
        }
        Ok(())
    }

    /// Its player's vocal tract (tract.rs) moved to `resonances` over `seconds` from where it stands; none, a mouth's
    /// pressure alone again once its answer has eased to nothing.
    pub fn tract(&mut self, resonances: Vec<Resonance>, seconds: f64) {
        let rate = self.native_rate();
        self.player.tract.get_or_insert_with(|| Tract::new(rate)).set(resonances, seconds);
    }

    /// Its reed's or lips' flow made turbulent at `line.level` from the next step on (none at 0, nothing then drawn, the
    /// sound as without it to the bit): each step each slit's coefficient -- the flow's alone, kernel.rs -- moved by a
    /// share of itself, its deviation the level times the root of half the native rate, never below none
    /// (openwind_compiled.py controls, the renders' the same).
    pub fn turbulence(&mut self, line: TurbulenceLine) -> Result<(), String> {
        if !(line.level.is_finite() && line.level >= 0.0) {
            return Err(format!("a turbulence of none or more, not {}", line.level));
        }
        self.turbulence = line.level;
        Ok(())
    }

    /// Its player's noise of one kind as `line` asks it, from the next step on (noise.rs PlayerNoise): its breath's a share
    /// of its mouth's pressure (a reed's or the lips' gamma; a jet's speed by its root, the pressure its speed's square),
    /// its lips' a share of their tension (their resonance by its root, a spring's) -- refused where its body has no lips.
    pub fn noise(&mut self, line: NoiseLine) -> Result<(), String> {
        let what = What::named(&line.what).ok_or_else(|| format!("a noise of the breath or the lips, not {}", line.what))?;
        if what == What::Lips && self.pulsations.is_empty() {
            return Err("its body has no lips".into());
        }
        let tremor = line.tremor.unwrap_or(TremorLine { hz: 0.0, q: 0.0, share: 0.0 });
        let profile = Profile { beta: line.beta, low: line.low, high: line.high, tremor_hz: tremor.hz, tremor_q: tremor.q, tremor_share: tremor.share };
        if let Some(seed) = line.seed {
            self.player_noise.seed(seed);
        }
        self.player_noise.set(what, line.sd, line.temperature, profile)
    }

    /// Its controls' columns, as its body names them (body.json `columns`).
    pub fn columns(&self) -> &[Vec<serde_json::Value>] {
        &self.columns
    }

    /// The row of controls a group's shaping gives `seconds` after its start (its first breath's): where the live dial
    /// begins a note from. A jet's turbulence its level there, not a draw: held, the stream draws it a step at a time.
    pub fn row(&self, line: &GroupLine, seconds: f64) -> Result<Vec<f64>, String> {
        let mut controls = Controls::new(self.shaped(line, 0.0)?)?;
        controls.skip((seconds * self.native_rate()).round().max(0.0) as u64);
        let mut row = vec![0.0; self.cols];
        controls.fill(1, &mut row);
        for (at, level) in controls.noise_levels() {
            row[at] = level;
        }
        Ok(row)
    }

    /// Its controls held at `row` (the live dial's), moved there from where they stand along the raised cosine over
    /// `seconds`; a jet's speed, swayed, never under `floor` (HeldLine), where given; the groups waiting and playing let
    /// go. A group sent after plays from its own controls again.
    pub fn hold(&mut self, row: Vec<f64>, seconds: f64, floor: Option<f64>) -> Result<(), String> {
        if row.len() != self.cols {
            return Err(format!("a held row of {} controls for a body of {}", row.len(), self.cols));
        }
        if floor.is_some_and(|f| !(f > 0.0 && f.is_finite())) || floor.is_some() && self.jet.is_none() {
            return Err("a held row's floor is a jet's speed, more than none".into());
        }
        let from = match &self.held {
            Some(h) => {
                let mut now = vec![0.0; self.cols];
                h.into_row(&mut now);
                now
            }
            None if self.last.len() == self.cols => self.last.clone(),
            None => row.clone(),
        };
        // (Its floor moved from the one held, else from the one given.)
        let floor = floor.map(|f| (self.held.as_ref().and_then(|h| h.floor_at(0)).unwrap_or(f), f));
        // (A jet's value a step before: none where its row was a group's, its derivative then one-sided for a step.)
        if self.held.is_none() {
            self.jet_before = None;
        }
        self.held = Some(Held { from, to: row, floor, steps: (seconds * self.native_rate()).round().max(0.0) as u64, taken: 0 });
        self.waiting.clear();
        self.playing = None;
        self.started = true;
        Ok(())
    }

    /// Its slide drawn to `out` m of tube added past its first position (0 to its body's most), along the raised cosine
    /// over `seconds` from where it stands: its pipe stretched to it a sample at a time as it moves (Player::stretch), so
    /// a glissando as a trombonist's hand draws it. -> why not, where its body has no slide or `out` lies past it.
    pub fn slide(&mut self, out: f64, seconds: f64) -> Result<(), String> {
        let rate = self.native_rate();
        let Some(m) = self.slide.as_mut() else { return Err("its body has no slide".into()) };
        if !(0.0..=m.most).contains(&out) || !(seconds >= 0.0 && seconds.is_finite()) {
            return Err(format!("a slide drawn to {out} m, past its reach (0 to {} m), or over {seconds} s", m.most));
        }
        *m = Motion { from: m.out(), to: out, steps: (seconds * rate).round() as u64, taken: 0, ..*m };
        Ok(())
    }

    /// The tube its slide adds where it stands (m): none without one.
    pub fn slide_out(&self) -> f64 {
        self.slide.as_ref().map_or(0.0, |m| m.out())
    }

    /// The held row swayed by a vibrato (VibratoLine), each column's depth moved from where it stands to the one given
    /// over `seconds`, the rest's to none; its phase going on, its rate the one given from now.
    pub fn vibrato(&mut self, line: VibratoLine) -> Result<(), String> {
        let cols = self.cols;
        if line.depths.len() != line.columns.len() || !line.cents.is_empty() && line.cents.len() != line.columns.len() {
            return Err("a vibrato's depths (and cents, where given) one a column".into());
        }
        if line.columns.iter().any(|&c| c >= cols) || !line.rate.is_finite() || line.rate < 0.0 || line.depths.iter().any(|d| !d.is_finite()) {
            return Err(format!("a vibrato on columns under {cols}, at a rate of none or more, its depths finite"));
        }
        let (now, mut cents, phase) = match &self.vibrato {
            Some(v) => ((0..cols).map(|c| v.depth(c, 0)).collect(), v.cents.clone(), v.phase),
            None => (vec![0.0; cols], vec![false; cols], 0.0),
        };
        let mut to = vec![0.0; cols];
        for (k, &c) in line.columns.iter().enumerate() {
            to[c] = line.depths[k];
            let given = line.cents.get(k).copied().unwrap_or(false);
            // (A column whose kind of depth changes: from none, as the other kind's depth is no share of this one's.)
            if given != cents[c] && now[c] != 0.0 {
                return Err(format!("column {c}'s vibrato changes between cents and shares while it sways"));
            }
            cents[c] = given;
        }
        let rate = self.native_rate();
        self.vibrato = Some(Vibrato { from: now, to, cents, steps: (line.seconds * rate).round().max(0.0) as u64, taken: 0, phase,
                                      turn: 2.0 * std::f64::consts::PI * line.rate / rate });
        Ok(())
    }

    /// Its player's techniques on the row held (TechniqueLine; technique.rs Held) from the next step on: a hum's or a
    /// growl's voice swinging its breath's column, a flutter closing it off, each moved to from where it stands over
    /// `seconds` -- its breath's column changed only once they are let go.
    pub fn technique(&mut self, line: TechniqueLine) -> Result<(), String> {
        if line.column >= self.cols || !(line.seconds >= 0.0 && line.seconds.is_finite()) {
            return Err(format!("techniques on a column under {}, over none or more seconds", self.cols));
        }
        let rate = self.native_rate();
        let mut held = match self.technique.take() {
            Some(h) if h.column == line.column || !h.active() => h,
            Some(h) => {
                self.technique = Some(h);
                return Err("its techniques move one breath's column: let them go before they move another".into());
            }
            None => technique::Held::new(line.column, rate),
        };
        held.column = line.column;
        held.floor = line.floor;
        let set = held.set(&line.techniques, line.seconds);
        self.technique = Some(held);
        set
    }

    /// The held row `ahead` native steps on, its vibrato in it, its techniques on its breath; then a jet's speed floored, the speed asked under its
    /// floor its presence's (controls.rs: its player's breath over the speed given).
    fn held_at(&self, held: &Held, ahead: u64, row: &mut [f64]) {
        let p = if held.steps == 0 { 1.0 } else { eased((held.taken + ahead).min(held.steps) as f64 / held.steps as f64) };
        for ((x, a), b) in row.iter_mut().zip(&held.from).zip(&held.to) {
            *x = a + (b - a) * p;
        }
        if let Some(v) = &self.vibrato {
            v.into_row(row, ahead);
        }
        if let Some(t) = &self.technique {
            row[t.column] = t.applied(row[t.column], ahead);
        }
        if let (Some((uj, _, _)), Some(floor)) = (self.jet, held.floor_at(ahead)) {
            let asked = row[uj];
            row[uj] = asked.max(floor);
            if let Some(at) = self.presence {
                row[at] *= (asked / row[uj]).clamp(0.0, 1.0);
            }
        }
    }

    /// Whether it rests at the row held: that row reached, its breath none as it steps it (a reed's or the lips' gamma,
    /// a jet's speed or its presence; its vibrato and its techniques on it), and its sound under SILENT for RUNG_DOWN.
    /// A body with no breath's column it knows never rests.
    fn resting(&self, held: &Held) -> bool {
        if held.taken < held.steps || (self.quiet as f64) < RUNG_DOWN * self.native_rate() {
            return false;
        }
        let mut row = vec![0.0; self.cols];
        self.held_at(held, 0, &mut row);
        match self.jet {
            Some((uj, _, _)) => row[uj] == 0.0 || self.presence.is_some_and(|p| row[p] == 0.0),
            None => !self.gammas.is_empty() && self.gammas.iter().all(|&c| row[c] == 0.0),
        }
    }

    /// The groups waiting from `seconds` of its clock on let go.
    pub fn let_go(&mut self, seconds: f64) {
        let from = ((seconds * self.rate).round().max(0.0) as u64) * self.ratio as u64;
        self.waiting.retain(|p| p.start < from || p.start < self.n);
    }

    /// `frames` more frames of its sound at 48 kHz, scaled as the renders scale it.
    pub fn render(&mut self, frames: usize) -> Result<Vec<f32>, String> {
        let (ratio, l) = (self.ratio as u64, self.half_length as u64);
        let last = self.frame + frames as u64;
        // (Native samples needed: to the last frame's filter's end, and one more for its time derivative.)
        let needed = (last - 1) * ratio + l + 1;
        while self.base + (self.radiated.len() as u64) < needed {
            self.advance(needed)?;
        }
        let mut out = Vec::with_capacity(frames);
        for m in self.frame..last {
            let centre = m * ratio + l;
            let mut sum = 0.0;
            for (j, &h) in self.taps.iter().enumerate() {
                let i = centre as i64 - j as i64;
                if i >= self.base as i64 {
                    sum += h * self.radiated[(i as u64 - self.base) as usize];
                }
            }
            out.push((sum * self.gain) as f32);
        }
        self.frame = last;
        // (What no later frame reads let go.)
        let keep_from = (self.frame * ratio).saturating_sub(l + 1);
        if keep_from > self.base + 65536 {
            let drop = (keep_from - self.base) as usize;
            self.radiated.drain(..drop);
            self.base += drop as u64;
        }
        Ok(out)
    }

    /// Native samples of its radiated sound until `needed` are known (each the flow's central difference, so one step
    /// past it taken).
    fn advance(&mut self, needed: u64) -> Result<(), String> {
        let scale = self.ratio as f64 * self.rate;
        if let Some(mut held) = self.held.take() {
            // (Only the steps its sound needs: a row held next, between two of the dial's pulls of sound, begins on the
            // step after the last one heard, not up to a block of steps later.)
            let steps = (needed + 1).saturating_sub(self.n).clamp(1, BLOCK as u64) as usize;
            // (At rest -- its breath none and its bore rung down -- no step taken and its sound none, until a row held
            // next blows it: a page's player costs nothing while its wind is silent.)
            if self.resting(&held) {
                self.radiated.resize(self.radiated.len() + steps, 0.0);
                self.n += steps as u64;
                self.spent_steps += steps as u64;
                self.quiet += steps as u64;
                // (Its vibrato, its techniques and its slide go on meanwhile, so a note blown next finds them where its
                // player left them: the pipe stretched to its slide's place as its next step is taken.)
                for _ in 0..steps {
                    if let Some(v) = self.vibrato.as_mut() {
                        v.step();
                    }
                    if let Some(t) = self.technique.as_mut() {
                        t.step();
                    }
                }
                if let Some(m) = self.slide.as_mut() {
                    m.taken = (m.taken + steps as u64).min(m.steps);
                }
                self.held = Some(held);
                return Ok(());
            }
            let cols = self.cols;
            let mut u = std::mem::take(&mut self.u);
            u.resize(steps * cols, 0.0);
            self.y.resize(steps * self.outs, 0.0);
            let mut next = vec![0.0; cols];
            for k in 0..steps {
                let row = &mut u[k * cols..(k + 1) * cols];
                self.held_at(&held, 0, row);
                // (A jet's turbulence: its level held, drawn each step as a group's is.)
                for &c in &self.noise {
                    row[c] *= self.draws.next();
                }
                // (A jet's derivative and next value its held curve's, a step either side, as a group's are.)
                if let Some((uj, duj, next_uj)) = self.jet {
                    self.held_at(&held, 1, &mut next);
                    let before = self.jet_before.unwrap_or(row[uj]);
                    row[duj] = (next[uj] - before) / 2.0 * scale;
                    row[next_uj] = next[uj];
                    self.jet_before = Some(row[uj]);
                }
                held.taken = (held.taken + 1).min(held.steps);
                if let Some(v) = self.vibrato.as_mut() {
                    v.step();
                }
                if let Some(t) = self.technique.as_mut() {
                    t.step();
                }
            }
            self.u = u;
            self.held = Some(held);
            return self.stepped(steps, scale);
        }
        // (Its next group begins: it plays from here.)
        if self.waiting.first().is_some_and(|p| p.start <= self.n) {
            self.playing = Some(self.waiting.remove(0));
            self.started = true;
        }
        if !self.started {
            // (Nothing begun: the body at rest, its flow nothing, no step taken.)
            let until = self.waiting.first().map_or(needed + 1, |p| p.start).min(needed + 1);
            for _ in self.n..until.max(self.n + 1) {
                self.take(0.0, scale);
            }
            return Ok(());
        }
        let next = self.waiting.first().map(|p| p.start);
        let least = |kind: &str| self.law.as_ref().and_then(|law| law.transitions.get(kind).copied()).unwrap_or(0.01);
        let key = (least("key").max(least("lips")) * scale).round() as u64;
        let mut steps = BLOCK as u64;
        if let Some(s) = next {
            // (Stop where the controls begin to move to the next group's, and where it begins.)
            let moving = s.saturating_sub(key);
            if self.n < moving {
                steps = steps.min(moving - self.n);
            } else {
                steps = steps.min(s - self.n);
            }
        }
        let steps = steps.max(1) as usize;
        let (cols, outs) = (self.cols, self.outs);
        self.u.resize(steps * cols, 0.0);
        self.y.resize(steps * outs, 0.0);
        let playing = self.playing.as_mut().ok_or("no group playing")?;
        playing.controls.fill(steps, &mut self.u);
        if let Some(s) = next {
            let first = &self.waiting[0].first;
            if s > self.n && s - self.n <= key + steps as u64 && !first.is_empty() {
                for k in 0..steps {
                    let at = self.n + k as u64;
                    if at + key < s {
                        continue;
                    }
                    let p = eased(1.0 - (s - at) as f64 / key.max(1) as f64);
                    for &c in &self.moved {
                        let was = self.u[k * cols + c];
                        self.u[k * cols + c] = was + (first[c] - was) * p;
                    }
                }
            }
        }
        self.stepped(steps, scale)
    }

    /// The `steps` rows of controls in `u` stepped, their flows taken, the last row kept. While a slide moves, its pipe
    /// stretched to where it stands at each output sample's steps.
    fn stepped(&mut self, steps: usize, scale: f64) -> Result<(), String> {
        let (cols, outs) = (self.cols, self.outs);
        // (The last row as its controls give it, before its flow is stirred: a row held next moves from it.)
        self.last.clear();
        self.last.extend_from_slice(&self.u[(steps - 1) * cols..steps * cols]);
        if self.player_noise.active(self.n) {
            self.noised(steps, scale);
        }
        if self.turbulence > 0.0 && !self.slits.is_empty() {
            let deviation = self.turbulence * (self.native_rate() / 2.0).sqrt();
            for k in 0..steps {
                for &c in &self.slits {
                    let share = (1.0 + deviation * self.whirls.next()).max(0.0);
                    self.u[k * cols + c] *= share;
                }
            }
        }
        let mut done = 0;
        while done < steps {
            // (Moving, or moved to where its pipe does not yet stand: an output sample's steps at a time.)
            let run = match self.slide.as_mut() {
                Some(m) if m.taken < m.steps || m.out() != m.set => {
                    let out = m.out();
                    if out != m.set {
                        self.player.stretch((m.length + out) / m.length);
                        m.set = out;
                    }
                    let run = (steps - done).min(self.ratio);
                    m.taken = (m.taken + run as u64).min(m.steps);
                    run
                }
                _ => steps - done,
            };
            let status = self.player.steps(&self.u[done * cols..(done + run) * cols], &mut self.y[done * outs..(done + run) * outs], run);
            if status != 0 {
                return Err(format!("the body stopped at step {} ({status})", self.n + done as u64));
            }
            done += run;
        }
        for k in 0..steps {
            let flow = self.y[k * outs];
            self.take(flow, scale);
        }
        if let Some(a) = self.air_at {
            // (Each end's flow recorded as it leaves the bore, as an exit's: the reed's let in, its negative.)
            self.spent -= (0..steps).map(|k| self.y[k * outs + a]).sum::<f64>();
        } else if let Some(jet) = &self.jet_air {
            self.spent += (0..steps).map(|k| jet.flow(&self.u[k * cols..(k + 1) * cols])).sum::<f64>();
        }
        Ok(())
    }

    /// Its player's noise on the `steps` rows in `u`, at the steps they are (noise.rs PlayerNoise): its breath's pressure's
    /// share on each gamma, or on a jet's speed by its root -- its derivative by the product's rule, the share's a step
    /// either side, and its next value by the next step's -- and its lips' tension's on their resonance, by its root.
    fn noised(&mut self, steps: usize, scale: f64) {
        let cols = self.cols;
        for k in 0..steps {
            let n = self.n + k as u64;
            let breath = self.player_noise.at(What::Breath, n);
            let row = &mut self.u[k * cols..(k + 1) * cols];
            for &c in &self.gammas {
                row[c] *= breath;
            }
            if let Some((uj, duj, next_uj)) = self.jet {
                let (before, after) = (self.player_noise.at(What::Breath, n.saturating_sub(1)).sqrt(), self.player_noise.at(What::Breath, n + 1).sqrt());
                let share = breath.sqrt();
                row[duj] = share * row[duj] + row[uj] * (after - before) / 2.0 * scale;
                row[uj] *= share;
                row[next_uj] *= after;
            }
            if !self.pulsations.is_empty() {
                let tension = self.player_noise.at(What::Lips, n).sqrt();
                for &c in &self.pulsations {
                    row[c] *= tension;
                }
            }
        }
    }

    /// A step's flow taken: the radiated sound at the step before it, the flow's central difference (np.gradient's;
    /// from rest before the first), `scale` the native rate.
    fn take(&mut self, flow: f64, scale: f64) {
        self.spent_steps += 1;
        if self.n >= 1 {
            let radiated = (flow - self.flows[0]) / 2.0 * scale;
            self.quiet = if (radiated * self.gain).abs() < SILENT { self.quiet + 1 } else { 0 };
            self.radiated.push(radiated);
        }
        self.flows = [self.flows[1], flow];
        self.n += 1;
    }
}

// ---- A note's oscillation found on the engine itself at the row the live dial holds (orbit.rs), and its sound, here at
// the file's end so that no line above it moves (kernel.rs's the same). ----

/// What is asked of the orbit at the row held (orbit.rs): how long its player is warmed at that row first (s), how many
/// of its multipliers, a column moved to a value (`nudged`) whose period's move is sought, and the seconds of its sound
/// wanted (none: none).
#[derive(Deserialize, Clone, Debug)]
pub struct OrbitLine {
    #[serde(default)]
    pub warm: f64,
    #[serde(default)]
    pub multipliers: usize,
    #[serde(default)]
    pub nudged: Option<(usize, f64)>,
    #[serde(default)]
    pub seconds: f64,
}

/// The orbit found and its sound: what orbit.rs found, and its sound -- a whole number of its periods, so that it repeats
/// as it is looped -- at 48 kHz, scaled as the stream scales its own, its 32-bit floats in base 64.
#[derive(Serialize, Debug)]
pub struct Orbited {
    #[serde(flatten)]
    pub found: crate::orbit::Found,
    pub frames: usize,
    pub sound: String,
}

impl Stream {
    /// The orbit of its note at the row held (orbit.rs), as its player stands now -- without its vibrato, its techniques,
    /// its noise or its flow's turbulence: the row its controls are moving to, a jet's speed floored as it is held --
    /// and, `line.seconds` given, its sound: its radiated flow over a period read along the cubic through the steps about
    /// each point, its time derivative and its filter to 48 kHz and its gain the stream's own. Its player and its tract
    /// put back as they stood, so that it plays on from there.
    pub fn orbit(&mut self, line: OrbitLine) -> Result<Orbited, String> {
        let held = self.held.as_ref().ok_or("its orbit is found at a row held, as the live dial holds one")?;
        let mut row = held.to.clone();
        if let (Some((uj, _, _)), Some((_, floor))) = (self.jet, held.floor) {
            let asked = row[uj];
            row[uj] = asked.max(floor);
            if let Some(at) = self.presence {
                row[at] *= (asked / row[uj]).clamp(0.0, 1.0);
            }
        }
        let nudged = match line.nudged {
            Some((c, v)) if c < self.cols && v.is_finite() => {
                let mut r = row.clone();
                r[c] = v;
                Some(r)
            }
            Some((c, v)) => return Err(format!("a row moved at a column under {}, to a finite value, not {c} to {v}", self.cols)),
            None => None,
        };
        let rate = self.native_rate();
        let kept = self.player.data().to_vec();
        let tract = self.player.tract.clone();
        let asked = crate::orbit::Asked { row: &row, nudged: nudged.as_deref(), warm: line.warm, multipliers: line.multipliers, least: SILENT / self.gain, jet: self.jet };
        let found = crate::orbit::orbit(&mut self.player, self.cols, self.outs, rate, &asked);
        self.player.set_data(&kept);
        self.player.tract = tract;
        let found = found?;
        let mut orbited = Orbited { frames: 0, sound: String::new(), found };
        if !orbited.found.sounds || !(line.seconds > 0.0) {
            return Ok(orbited);
        }
        let (t, g) = (orbited.found.steps, &orbited.found.flows);
        // (Its flow at any step `s` from its start, over its second period: `g`'s first the flow a step on.)
        let flow = |s: f64| {
            let s = t + 1.0 + (s - t - 1.0).rem_euclid(t);
            let (n, th) = (s.floor() as usize, s - s.floor());
            let w = [-th * (th - 1.0) * (th - 2.0) / 6.0, (th + 1.0) * (th - 1.0) * (th - 2.0) / 2.0, -(th + 1.0) * th * (th - 2.0) / 2.0,
                     (th + 1.0) * th * (th - 1.0) / 6.0];
            (0..4).map(|j| w[j] * g[n + j - 2]).sum::<f64>()
        };
        let radiated = |s: f64| (flow(s + 1.0) - flow(s - 1.0)) / 2.0 * rate * self.gain;
        // (A whole number of its periods, near the seconds asked, that comes nearest a whole number of frames.)
        let (ratio, l) = (self.ratio, self.half_length);
        let per = t / ratio as f64;
        let first = ((line.seconds * self.rate / per).round() as usize).max(1);
        let periods = (first..=first + first / 4 + 1).min_by(|&a, &b| {
            let off = |p: usize| (p as f64 * per - (p as f64 * per).round()).abs();
            off(a).total_cmp(&off(b))
        }).unwrap_or(first);
        let frames = (periods as f64 * per).round() as usize;
        // (Its radiated sound at each native step its frames' filter reads, from `l` steps before its first.)
        let steps: Vec<f64> = (0..frames * ratio + 2 * l).map(|i| radiated(i as f64 - l as f64)).collect();
        let mut out = Vec::with_capacity(frames);
        for m in 0..frames {
            let centre = m * ratio + 2 * l;
            out.push(self.taps.iter().enumerate().map(|(j, h)| h * steps[centre - j]).sum::<f64>() as f32);
        }
        orbited.frames = frames;
        let bytes: Vec<u8> = out.iter().flat_map(|x| x.to_le_bytes()).collect();
        orbited.sound = base64(&bytes);
        Ok(orbited)
    }
}

/// `bytes` in base 64 (RFC 4648, padded).
fn base64(bytes: &[u8]) -> String {
    const ABC: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut out = String::with_capacity(bytes.len().div_ceil(3) * 4);
    for c in bytes.chunks(3) {
        let n = (c[0] as u32) << 16 | (*c.get(1).unwrap_or(&0) as u32) << 8 | *c.get(2).unwrap_or(&0) as u32;
        for k in 0..4 {
            out.push(if k <= c.len() { ABC[(n >> (18 - 6 * k) & 63) as usize] as char } else { '=' });
        }
    }
    out
}

// ---- What starts its note at the row held, computed backward from its pitch on the engine's own equations (starts.rs),
// here at the file's end so that no line above it moves. ----

/// What is asked of the starts at the row held, or at `row` (its note's own, as the dial has it before its lip and its
/// tongue move it) (starts.rs Asked): the note's pitch (Hz), its players' lip's law and its
/// force's range (N past the note's own), the tables' sizes, how many overtones' answers, whether it is checked
/// against the engine, and the shapes its players keep their tract in, read so many cents apart (none: the starts
/// module's own step).
#[derive(Deserialize, Clone, Debug)]
pub struct StartsLine {
    pub hz: f64,
    #[serde(default)]
    pub row: Option<Vec<f64>>,
    #[serde(default)]
    pub lip: Option<crate::starts::LipLaw>,
    #[serde(default = "StartsLine::forces")]
    pub forces: [f64; 2],
    #[serde(default = "StartsLine::force_steps")]
    pub force_steps: usize,
    #[serde(default = "StartsLine::opening_steps")]
    pub opening_steps: usize,
    #[serde(default)]
    pub overtones: usize,
    #[serde(default)]
    pub checked: bool,
    #[serde(default)]
    pub tract: Option<crate::tract::TractShapes>,
    #[serde(default)]
    pub tract_cents: f64,
}

impl StartsLine {
    fn forces() -> [f64; 2] {
        [-2.0, 1.0]
    }
    fn force_steps() -> usize {
        121
    }
    fn opening_steps() -> usize {
        200
    }
}

impl Stream {
    /// What starts its note at the row held (starts.rs), the row's columns its controls are moving to; its player and its
    /// tract put back as they stood, so that it plays on from there.
    pub fn starts(&mut self, line: StartsLine) -> Result<crate::starts::Started, String> {
        let row = match line.row {
            Some(row) => row,
            None => self.held.as_ref().ok_or("its starts are found at a row held, as the live dial holds one, or a row given")?.to.clone(),
        };
        let rate = self.native_rate();
        let kept = self.player.data().to_vec();
        let tract = self.player.tract.clone();
        let asked = crate::starts::Asked {
            row: &row,
            hz: line.hz,
            lip: line.lip,
            forces: line.forces,
            force_steps: line.force_steps,
            opening_steps: line.opening_steps,
            overtones: line.overtones,
            checked: line.checked,
            tract: line.tract.as_ref(),
            tract_cents: line.tract_cents,
        };
        let found = crate::starts::starts(&mut self.player, rate, &asked);
        self.player.set_data(&kept);
        self.player.tract = tract;
        found
    }
}

// ---- the starts growing from rest at a rate asked (starts.rs growing): here at the file's end so that no line above it
// moves. ----

impl Stream {
    /// As `starts`, its note growing from rest at `growth` (its amplitude's rate, 1/s; nothing: neither growing nor
    /// dying).
    pub fn starts_growing(&mut self, line: StartsLine, growth: f64) -> Result<crate::starts::Started, String> {
        let row = match line.row {
            Some(row) => row,
            None => self.held.as_ref().ok_or("its starts are found at a row held, as the live dial holds one, or a row given")?.to.clone(),
        };
        let rate = self.native_rate();
        let kept = self.player.data().to_vec();
        let tract = self.player.tract.clone();
        let asked = crate::starts::Asked {
            row: &row,
            hz: line.hz,
            lip: line.lip,
            forces: line.forces,
            force_steps: line.force_steps,
            opening_steps: line.opening_steps,
            overtones: line.overtones,
            checked: line.checked,
            tract: line.tract.as_ref(),
            tract_cents: line.tract_cents,
        };
        let found = crate::starts::growing(&mut self.player, rate, &asked, growth);
        self.player.set_data(&kept);
        self.player.tract = tract;
        found
    }
}

/// A held note's rates asked (orbit.rs rates): its row (the row held, where none), its tract's resonances (its tract as it
/// stands, where none), warmed `warm` s there, so many multipliers, and each move of its controls whose rates are sought.
#[derive(Deserialize, Debug, Default)]
pub struct RatesLine {
    #[serde(default)]
    pub warm: f64,
    #[serde(default)]
    pub multipliers: usize,
    #[serde(default)]
    pub row: Option<Vec<f64>>,
    #[serde(default)]
    pub tract: Option<Vec<Resonance>>,
    #[serde(default)]
    pub moved: Vec<crate::orbit::Moved>,
    /// Its orbit begun from one a call before found (Followed), not from the note as it sounds: a held note followed as
    /// its player moves it, as a player moves from where it last sounded, never in one leap from where it began.
    #[serde(default)]
    pub follow: bool,
    /// The orbit the call before found kept as the one to follow (its move taken).
    #[serde(default)]
    pub keep: bool,
}

/// A held note's orbit as a call found it: its player's state and its tract's where it begins, where the next may begin.
#[derive(Clone, Debug, Default)]
pub struct Followed {
    pub data: Vec<f64>,
    pub tract: Option<Vec<f64>>,
}

impl Stream {
    /// Its note's orbit at a row and a tract (orbit.rs, as `orbit` finds it at the row held) and how far its period and
    /// its level move for each move asked: what a held note's pitch and loudness do as its player moves each control
    /// (dial.mjs heldAt), begun from `from` where given (RatesLine::follow); the orbit found, where it sounds, to be
    /// followed. Its player and its tract put back as they stood, so that it plays on from there.
    pub fn rates(&mut self, line: RatesLine, from: Option<&Followed>) -> Result<(crate::orbit::Found, Option<Followed>), String> {
        let row = match line.row {
            Some(row) => row,
            None => self.held.as_ref().ok_or("its rates are found at a row held, as the live dial holds one, or a row given")?.to.clone(),
        };
        let cols = self.cols;
        if row.len() != cols || line.moved.iter().any(|m| m.row.as_ref().is_some_and(|r| r.len() != cols)) {
            return Err(format!("its rows each its body's {cols} columns"));
        }
        let rate = self.native_rate();
        let kept = self.player.data().to_vec();
        let tract = self.player.tract.clone();
        if let Some(rs) = line.tract {
            let mut t = self.player.tract.take().unwrap_or_else(|| Tract::new(rate));
            t.set(rs, 0.0);
            self.player.tract = Some(t);
        }
        if let Some(f) = from.filter(|f| f.data.len() == kept.len()) {
            self.player.set_data(&f.data);
            if let (Some(s), Some(t)) = (&f.tract, self.player.tract.as_mut()) {
                if s.len() == t.state().len() {
                    t.set_state(s);
                }
            }
        }
        let asked = crate::orbit::Asked { row: &row, nudged: None, warm: line.warm, multipliers: line.multipliers, least: SILENT / self.gain, jet: self.jet };
        let found = crate::orbit::rates(&mut self.player, self.cols, self.outs, rate, &asked, &line.moved);
        // (The player left at the orbit's state where it sounds: kept so that the next may begin there.)
        let followed = found.as_ref().ok().filter(|f| f.sounds).map(|_| Followed { data: self.player.data().to_vec(), tract: self.player.tract.as_ref().map(|t| t.state()) });
        self.player.set_data(&kept);
        self.player.tract = tract;
        found.map(|f| (f, followed))
    }
}

// ---- a start from silence at a row, and a held note settling once moved (starts.rs grows, orbit.rs settles): here at
// the file's end so that no line above it moves. ----

/// A start from silence asked (starts.rs grows): its row (the row held, where none), its tract's resonances (its tract as
/// it stands, where none), the pitch its root is sought from (Hz), or a root found before ([growth 1/s, pitch Hz]), and
/// whether it is checked against the engine.
#[derive(Deserialize, Debug, Default)]
pub struct GrowsLine {
    #[serde(default)]
    pub row: Option<Vec<f64>>,
    #[serde(default)]
    pub tract: Option<Vec<Resonance>>,
    pub hz: f64,
    #[serde(default)]
    pub from: Option<[f64; 2]>,
    #[serde(default)]
    pub checked: bool,
}

/// A held note's move asked (orbit.rs settles): from the orbit `from` (Followed), its controls moved at once to `row` and
/// its tract's resonances to `tract` (as they stand, where none), and the held note there it should settle on.
#[derive(Deserialize, Debug, Default)]
pub struct SettleLine {
    pub row: Vec<f64>,
    #[serde(default)]
    pub tract: Option<Vec<Resonance>>,
    #[serde(flatten)]
    pub settle: crate::orbit::Settle,
}

impl Stream {
    /// How a start from silence grows at a row and a tract (starts.rs grows); its player and its tract put back as they
    /// stood.
    pub fn grows(&mut self, line: GrowsLine) -> Result<crate::starts::Grows, String> {
        let row = match line.row {
            Some(row) => row,
            None => self.held.as_ref().ok_or("its start is found at a row held, as the live dial holds one, or a row given")?.to.clone(),
        };
        if row.len() != self.cols {
            return Err(format!("its row its body's {} columns", self.cols));
        }
        let rate = self.native_rate();
        let kept = self.player.data().to_vec();
        let tract = self.player.tract.clone();
        if let Some(rs) = line.tract {
            let mut t = self.player.tract.take().unwrap_or_else(|| Tract::new(rate));
            t.set(rs, 0.0);
            self.player.tract = Some(t);
        }
        let found = crate::starts::grows(&mut self.player, rate, &row, line.hz, line.from, line.checked);
        self.player.set_data(&kept);
        self.player.tract = tract;
        found
    }

    /// How a held note settles once moved (orbit.rs settles), from the orbit `from`; its player and its tract put back as
    /// they stood.
    pub fn settles(&mut self, line: SettleLine, from: &Followed) -> Result<crate::orbit::Settled, String> {
        let rate = self.native_rate();
        let kept = self.player.data().to_vec();
        let tract = self.player.tract.clone();
        if from.data.len() != kept.len() {
            return Err("its orbit from another body".into());
        }
        self.player.set_data(&from.data);
        if let (Some(s), Some(t)) = (&from.tract, self.player.tract.as_mut()) {
            if s.len() == t.state().len() {
                t.set_state(s);
            }
        }
        if let Some(rs) = line.tract {
            let mut t = self.player.tract.take().unwrap_or_else(|| Tract::new(rate));
            t.set(rs, 0.0);
            self.player.tract = Some(t);
        }
        let found = crate::orbit::settles(&mut self.player, self.cols, self.outs, rate, &line.row, &line.settle);
        self.player.set_data(&kept);
        self.player.tract = tract;
        found
    }
}

// ---- a held note picked up near a pitch, and tuned with its controls and its orbit solved together (orbit.rs picked,
// tune): here at the file's end so that no line above it moves. ----

/// A held note's orbit asked near a pitch (orbit.rs picked): its row (the row held, where none), its tract's resonances
/// (its tract as it stands, where none), warmed `warm` s there, so many multipliers, its period sought near `near` (Hz).
#[derive(Deserialize, Debug, Default)]
pub struct PickLine {
    #[serde(default)]
    pub row: Option<Vec<f64>>,
    #[serde(default)]
    pub tract: Option<Vec<Resonance>>,
    #[serde(default)]
    pub warm: f64,
    #[serde(default)]
    pub multipliers: usize,
    pub near: f64,
}

impl Stream {
    /// Its note's orbit at a row and a tract, from the note as it sounds, its period sought near a pitch (orbit.rs
    /// picked); the orbit found, where it sounds, to be followed. Its player and its tract put back as they stood.
    pub fn picks(&mut self, line: PickLine) -> Result<(crate::orbit::Found, Option<Followed>), String> {
        let row = match line.row {
            Some(row) => row,
            None => self.held.as_ref().ok_or("its orbit is found at a row held, as the live dial holds one, or a row given")?.to.clone(),
        };
        if row.len() != self.cols {
            return Err(format!("its row its body's {} columns", self.cols));
        }
        let rate = self.native_rate();
        let kept = self.player.data().to_vec();
        let tract = self.player.tract.clone();
        if let Some(rs) = line.tract {
            let mut t = self.player.tract.take().unwrap_or_else(|| Tract::new(rate));
            t.set(rs, 0.0);
            self.player.tract = Some(t);
        }
        let asked = crate::orbit::Asked { row: &row, nudged: None, warm: line.warm, multipliers: line.multipliers, least: SILENT / self.gain, jet: self.jet };
        let found = crate::orbit::picked(&mut self.player, self.cols, self.outs, rate, &asked, line.near);
        let followed = found.as_ref().ok().filter(|f| f.sounds).map(|_| Followed { data: self.player.data().to_vec(), tract: self.player.tract.as_ref().map(|t| t.state()) });
        self.player.set_data(&kept);
        self.player.tract = tract;
        found.map(|f| (f, followed))
    }

    /// One step of a held note's tuning (orbit.rs tune) from the orbit `from` (Followed), at its row and its tract's
    /// resonances asked; the orbit it steps to -- or, where tuned, its orbit at its controls now -- to be followed. Its
    /// player and its tract put back as they stood.
    pub fn tunes(&mut self, line: crate::orbit::Tune, from: &Followed) -> Result<(crate::orbit::Tuned, Option<Followed>), String> {
        let rate = self.native_rate();
        let kept = self.player.data().to_vec();
        let tract = self.player.tract.clone();
        if from.data.len() != kept.len() {
            return Err("its orbit from another body".into());
        }
        if let Some(rs) = line.tract.clone() {
            let mut t = self.player.tract.take().unwrap_or_else(|| Tract::new(rate));
            t.set(rs, 0.0);
            self.player.tract = Some(t);
        }
        self.player.set_data(&from.data);
        if let (Some(s), Some(t)) = (&from.tract, self.player.tract.as_mut()) {
            if s.len() == t.state().len() {
                t.set_state(s);
            }
        }
        let found = crate::orbit::tune(&mut self.player, self.cols, self.outs, rate, &line, SILENT / self.gain);
        let followed = found.as_ref().ok().filter(|f| f.sounds).map(|_| Followed { data: self.player.data().to_vec(), tract: self.player.tract.as_ref().map(|t| t.state()) });
        self.player.set_data(&kept);
        self.player.tract = tract;
        found.map(|f| (f, followed))
    }
}

impl Stream {
    /// A step along a held note's path (orbit.rs bend) from the orbit `from` (Followed), tuned on the path at its row and
    /// its tract's resonances asked; the orbit predicted where it goes, to be followed. Its player and its tract put back
    /// as they stood.
    pub fn bends(&mut self, line: crate::orbit::Bend, from: &Followed) -> Result<(crate::orbit::Bent, Option<Followed>), String> {
        let rate = self.native_rate();
        let kept = self.player.data().to_vec();
        let tract = self.player.tract.clone();
        if from.data.len() != kept.len() {
            return Err("its orbit from another body".into());
        }
        if let Some(rs) = line.tract.clone() {
            let mut t = self.player.tract.take().unwrap_or_else(|| Tract::new(rate));
            t.set(rs, 0.0);
            self.player.tract = Some(t);
        }
        self.player.set_data(&from.data);
        if let (Some(s), Some(t)) = (&from.tract, self.player.tract.as_mut()) {
            if s.len() == t.state().len() {
                t.set_state(s);
            }
        }
        let found = crate::orbit::bend(&mut self.player, self.cols, self.outs, rate, &line, SILENT / self.gain);
        let followed = found.as_ref().ok().filter(|f| f.sounds).map(|_| Followed { data: self.player.data().to_vec(), tract: self.player.tract.as_ref().map(|t| t.state()) });
        self.player.set_data(&kept);
        self.player.tract = tract;
        found.map(|f| (f, followed))
    }
}

impl Stream {
    /// Its slide's pipe set at once to `out` m longer than laid out, or shorter where `out` is negative as far as `least`
    /// (m): a reed's barrel pulled out or pushed in to tune before it is played, as a trombone's slide is drawn
    /// (Stream::slide) but either way. Its pipe stretched now, the hole it ends at joined again (Player::stretch_joined),
    /// so a solve asked next hears it. `least`
    /// its body's (body.json `slide.least`: shortened no stiffer than its stiffest pipe, openwind_bodies.py
    /// tuning_slide). -> why not, where its body has no slide, or `out` lies past its reach or `least` past its pipe.
    pub fn pull(&mut self, out: f64, least: f64) -> Result<(), String> {
        let Some(m) = self.slide.as_mut() else { return Err("its body has no slide".into()) };
        if !(least <= 0.0 && least > -m.length) || !(least..=m.most).contains(&out) {
            return Err(format!("its pipe set {out} m past as laid out, past its reach ({least} to {} m)", m.most));
        }
        *m = Motion { from: out, to: out, steps: 0, taken: 0, set: out, ..*m };
        let s = (m.length + out) / m.length;
        self.player.stretch_joined(s);
        Ok(())
    }
}

/// A reed's barrel pulled out or pushed in to tune (Stream::pull): `out` m past its pipe as laid out, as far as `least`
/// (its body's body.json `slide.least`).
#[derive(Deserialize, Clone, Debug)]
pub struct PullLine {
    pub out: f64,
    pub least: f64,
}

impl Stream {
    /// Its joints pulled open `pulls` m at once, each within its range (kernel.rs Player::pull_points): a reed tuned as
    /// its player tunes it before it plays, never while it sounds, so that a solve asked next hears it. -> the pulls they
    /// stand at; why not, where its body has no joints.
    pub fn pull_points(&mut self, pulls: &[f64]) -> Result<Vec<f64>, String> {
        if self.player.pulls().is_empty() {
            return Err("its body has no joints".into());
        }
        self.player.pull_points(pulls);
        Ok(self.player.pulls())
    }
}

/// Its joints pulled open (Stream::pull_points): each one's pull (m), in its body's order (body.json `points.joints`).
#[derive(Deserialize, Clone, Debug)]
pub struct PointsLine {
    pub pulls: Vec<f64>,
}

impl Stream {
    /// Its joints pulled to tune held notes (orbit.rs pull_points), each note's orbit begun from its own (`from`, in its
    /// notes' order, found at its joints' pulls as they stand); its player and its tract put back as they stood, its
    /// joints left where the tuning leaves them.
    pub fn pulls_tuned(&mut self, line: crate::orbit::Pulls, from: Vec<Followed>) -> Result<crate::orbit::Pulled, String> {
        let rate = self.native_rate();
        let kept = self.player.data().to_vec();
        let tract = self.player.tract.clone();
        let own = self.player.pulls();
        if from.iter().any(|f| f.data.len() != kept.len()) {
            return Err("its orbits from another body".into());
        }
        let mut begun: Vec<(Vec<f64>, Option<Vec<f64>>)> = from.into_iter().map(|f| (f.data, f.tract)).collect();
        let found = crate::orbit::pull_points(&mut self.player, self.cols, self.outs, rate, &line, &mut begun, SILENT / self.gain, self.jet);
        // (Its doubles as they stood at its pulls as they stood, then its joints pulled where the tuning left them.)
        let tuned = self.player.pulls();
        self.player.pull_points(&own);
        self.player.set_data(&kept);
        self.player.tract = tract;
        self.player.pull_points(&tuned);
        found
    }
}

// ---- Its body remade in place (kernel.rs Player::remade), here at the file's end so that no line above it moves. ----

/// Its body remade in place (Stream::remade): the folder of the body it plays (`laid`: its own, or the last it was remade
/// to) and the folder of the one made on its layout with its makers' points set (native/openwind-maker maker.mjs
/// bodyFolder), each its I.bin, D.bin and body.json.
#[derive(Deserialize, Clone, Debug)]
pub struct RemadeLine {
    pub laid: String,
    pub made: String,
}

impl Stream {
    /// Its body's coefficients those of the body saved in `line.made`, set where they differ from `line.laid`'s (kernel.rs
    /// Player::remade): what it read of its body's header at its start (its columns, holes, step, reed) the same in
    /// both. -> the doubles set.
    pub fn remade(&mut self, line: &RemadeLine) -> Result<usize, String> {
        let (laid, made) = (Body::load(Path::new(&line.laid))?, Body::load(Path::new(&line.made))?);
        let same = |h: &crate::body::Header| (h.ratio, h.ni, h.nd, h.columns.clone(), h.holes.clone(), h.reed.as_ref().map(|r| (r.zc.to_bits(), r.rho.to_bits())));
        if same(&laid.header) != same(&made.header) || laid.i != made.i {
            return Err("the made body not on the layout of the one it plays".into());
        }
        self.player.remade(&made.i, &laid.d, &made.d, made.header.points.as_ref())
    }
}

// ---- Its makers' points moved to tune held notes (orbit.rs points_step), here at the file's end so that no line above it
// moves. ----

/// A step of its makers' points' tuning (orbit.rs PointsAsked, its notes each begun from the orbit saved under its
/// `from`): the folder of the body it plays (`laid`), of the one made at the points where this step stands (`base`: it
/// is remade to it, kernel.rs Player::remade), and of each point's moved one (`moved`, in its points' order), each made
/// on its layout, its mesh and step held (native/openwind-maker maker.mjs bodyFolder).
#[derive(Deserialize, Clone, Debug)]
pub struct PointsStepLine {
    pub laid: String,
    pub base: String,
    pub moved: Vec<String>,
    #[serde(flatten)]
    pub asked: crate::orbit::PointsAsked,
}

impl Stream {
    /// A step of its makers' points' tuning (orbit.rs points_step): its body remade to `line.base`, its notes' orbits
    /// (`from`, in its notes' order, found at `line.laid`) given the coefficients that moved; each moved body's
    /// coefficients read as it is remade to it and back, bit for bit; each note's orbit and each point's rate found there.
    /// Its player and its tract put back as they stood, on its body remade to `line.base` -- on `line.laid` again where the
    /// step fails. -> the step, and each note's orbit at `line.base`.
    pub fn points_stepped(&mut self, line: &PointsStepLine, from: Vec<Followed>) -> Result<(crate::orbit::PointsStep, Vec<Followed>), String> {
        let rate = self.native_rate();
        let (laid, base) = (Body::load(Path::new(&line.laid))?, Body::load(Path::new(&line.base))?);
        let moved = line.moved.iter().map(|p| Body::load(Path::new(p))).collect::<Result<Vec<Body>, String>>()?;
        let same = |h: &crate::body::Header| (h.ratio, h.ni, h.nd, h.columns.clone(), h.holes.clone(), h.reed.as_ref().map(|r| (r.zc.to_bits(), r.rho.to_bits())));
        if std::iter::once(&base).chain(&moved).any(|b| same(&b.header) != same(&laid.header) || b.i != laid.i) {
            return Err("its bodies not on the layout of the one it plays".into());
        }
        let single = self.player.single();
        self.player.in_doubles(true);
        let mut kept = self.player.data().to_vec();
        let tract = self.player.tract.clone();
        if from.iter().any(|f| f.data.len() != kept.len()) {
            if single {
                self.player.in_doubles(false);
            }
            return Err("its orbits from another body".into());
        }
        let mut begun: Vec<(Vec<f64>, Option<Vec<f64>>)> = from.into_iter().map(|f| (f.data, f.tract)).collect();
        // (Remade to its base, the coefficients that moved carried into its state kept and its notes' orbits.)
        let carried = self.player.remade(&base.i, &laid.d, &base.d, base.header.points.as_ref()).map(|_| {
            let after = self.player.data();
            let changed: Vec<usize> = (0..kept.len()).filter(|&k| after[k].to_bits() != kept[k].to_bits()).collect();
            for k in changed {
                kept[k] = after[k];
                for b in begun.iter_mut() {
                    b.0[k] = after[k];
                }
            }
        });
        let on_base = carried.is_ok();
        let found = carried.and_then(|_| {
            // (Each moved body's coefficients: those its remaking moves, read as its player is remade to it and back.)
            let mut coefficients = Vec::with_capacity(moved.len());
            for (m, path) in moved.iter().zip(&line.moved) {
                let own = self.player.data().to_vec();
                self.player.remade(&m.i, &base.d, &m.d, m.header.points.as_ref())?;
                let there = self.player.data();
                coefficients.push((0..own.len()).filter(|&k| there[k].to_bits() != own[k].to_bits()).map(|k| (k, there[k])).collect::<Vec<(usize, f64)>>());
                self.player.remade(&base.i, &m.d, &base.d, base.header.points.as_ref())?;
                let back = self.player.data();
                let off: Vec<usize> = (0..own.len()).filter(|&k| back[k].to_bits() != own[k].to_bits()).collect();
                if let Some(&k) = off.first() {
                    return Err(format!("its body not remade back bit for bit from {path}: {} doubles, the first at {k} ({} for {})", off.len(), back[k], own[k]));
                }
            }
            crate::orbit::points_step(&mut self.player, self.cols, self.outs, rate, &line.asked, &coefficients, &mut begun, SILENT / self.gain, self.jet)
        });
        // (On its base where the step was taken, on the body it played where it was not.)
        let found = found.map_err(|e| match on_base && !carried_back(&mut self.player, &laid, &base, &mut kept) {
            true => format!("{e}; and its body not remade back to {}", line.laid),
            false => e,
        });
        self.player.set_data(&kept);
        self.player.tract = tract;
        if single {
            self.player.in_doubles(false);
        }
        found.map(|f| (f, begun.into_iter().map(|(data, tract)| Followed { data, tract }).collect()))
    }
}

// (Its player remade from `base` back to `laid`, the coefficients that moved carried into `kept` -> whether it was.)
fn carried_back(player: &mut Player, laid: &Body, base: &Body, kept: &mut [f64]) -> bool {
    let before = player.data().to_vec();
    if player.remade(&laid.i, &base.d, &laid.d, laid.header.points.as_ref()).is_err() {
        return false;
    }
    let after = player.data();
    for k in (0..kept.len()).filter(|&k| after[k].to_bits() != before[k].to_bits()) {
        kept[k] = after[k];
    }
    true
}

// ---- Each note's own start and its makers' points' rates on it (points.rs), and the points' move for notes heard
// (orbit.rs points_move): here at the file's end so that no line above it moves. ----

/// Its notes' own starts asked (points.rs start_rates): the folder of the body it plays (`base`: made where its points
/// stand, its player remade to it), of each point's moved one (`moved`, in its points' order, each on its layout) and
/// the nudge each was made at; and its notes -- each its row, its tract, the pitch its resonance is sought about and a
/// root found before.
#[derive(Deserialize, Clone, Debug)]
pub struct StartRatesLine {
    pub base: String,
    pub moved: Vec<String>,
    pub nudges: Vec<f64>,
    pub notes: Vec<crate::points::StartNote>,
}

/// Its points' move asked (orbit.rs points_move): each note's rates, its cents off and its weight; each point's value
/// and span; the cents each note is kept at or above its pitch, where it is.
#[derive(Deserialize, Clone, Debug)]
pub struct PointsMoveLine {
    pub rates: Vec<Vec<f64>>,
    pub off: Vec<f64>,
    pub weights: Vec<f64>,
    pub at: Vec<f64>,
    pub within: Vec<[f64; 2]>,
    #[serde(default)]
    pub above: Option<f64>,
}

impl Stream {
    /// Each note's own start on the body it plays and each point's rate on it (points.rs start_rates); its player and its
    /// tract put back as they stood, so that it plays on from there. On one core only.
    pub fn start_rates(&mut self, line: &StartRatesLine) -> Result<Vec<crate::points::Rooted>, String> {
        let base = Body::load(Path::new(&line.base))?;
        let moved = line.moved.iter().map(|p| Body::load(Path::new(p))).collect::<Result<Vec<Body>, String>>()?;
        let same = |h: &crate::body::Header| (h.ratio, h.ni, h.nd, h.columns.clone(), h.holes.clone(), h.reed.as_ref().map(|r| (r.zc.to_bits(), r.rho.to_bits())));
        if moved.iter().any(|b| same(&b.header) != same(&base.header) || b.i != base.i) || base.d.len() != self.player.data().len() {
            return Err("its bodies not on the layout of the one it plays".into());
        }
        if line.notes.iter().any(|n| n.row.len() != self.cols) {
            return Err(format!("each note's row its body's {} columns", self.cols));
        }
        let rate = self.native_rate();
        crate::points::start_rates(&mut self.player, rate, &base, &moved, &line.nudges, &line.notes)
    }
}

// ---- What its player's mouth sounds beside its mouthpiece (research/PLAYER_TRACT_PLAN.md, C), here at the file's end
// so that no line above it moves. ----

/// The mouth's sounding pressure beside the mouthpiece's over the native steps read: how many; each one's rms about its
/// mean over them (Pa) -- the mouth's its tract's answer to the reed's flow (tract.rs: what the reed is driven by is the
/// mouth's pressure less it), nothing where it has no tract; the mouthpiece's the pressure in the bore at the reed's end
/// -- the mouthpiece's mean (Pa), and the mouth's over the mouthpiece's (M. Pamies-Vila, A. Hofmann & V. Chatziioannou
/// 2020, doi:10.1080/09298215.2019.1708412: the dynamic mouth pressure's rms over the mouthpiece pressure's, a tone).
#[derive(Serialize, Debug, Clone, Default)]
pub struct Mouth {
    pub steps: u64,
    pub mouth: f64,
    pub mouthpiece: f64,
    pub mean: f64,
    pub ratio: f64,
}

impl Stream {
    /// `frames` more frames of its sound at 48 kHz at the row held, as `render` gives them -- stepped a native step at a
    /// time, so that each step's mouth pressure and mouthpiece pressure are read as the engine itself has them -- and
    /// what its mouth sounded over them (Mouth). The same sound as `render`'s: nothing of its playing is moved.
    pub fn mouth(&mut self, frames: usize) -> Result<(Vec<f32>, Mouth), String> {
        if self.held.is_none() {
            return Err("its mouth is read at a row held, as the live dial holds one".into());
        }
        let air = self.air_at.ok_or("its mouth is read where it has a reed or lips")?;
        let (ratio, l) = (self.ratio as u64, self.half_length as u64);
        let needed = (self.frame + frames.max(1) as u64 - 1) * ratio + l + 1;
        // (Sums over the steps read: the mouth's and its square, the mouthpiece's and its square.)
        let (mut steps, mut sums) = (0u64, [0.0f64; 4]);
        while self.base + (self.radiated.len() as u64) < needed {
            let resting = self.held.as_ref().is_some_and(|held| self.resting(held));
            let before = self.n;
            // (A row held is stepped to the step asked, one at the least: one.)
            self.advance(before)?;
            if self.n != before + 1 {
                return Err(format!("its mouth is read a step at a time, not {}", self.n - before));
            }
            let (mouth, piece) = if resting {
                (0.0, 0.0)
            } else {
                let (flow, pressure) = self.player.reed_recorded()?;
                let told = self.y[air];
                if (flow - told).abs() > 1e-6 * told.abs().max(1e-12) {
                    return Err(format!("its reed's end's flow read {flow}, its output's {told}"));
                }
                (self.player.tract.as_ref().map_or(0.0, |t| t.pressure()), pressure)
            };
            steps += 1;
            sums = [sums[0] + mouth, sums[1] + mouth * mouth, sums[2] + piece, sums[3] + piece * piece];
        }
        let sound = self.render(frames)?;
        let n = steps.max(1) as f64;
        let about = |sum: f64, square: f64| (square / n - (sum / n).powi(2)).max(0.0).sqrt();
        let (mouth, mouthpiece) = (about(sums[0], sums[1]), about(sums[2], sums[3]));
        Ok((sound, Mouth { steps, mouth, mouthpiece, mean: sums[2] / n, ratio: if mouthpiece > 0.0 { mouth / mouthpiece } else { 0.0 } }))
    }
}

// ---- A held note's period's rates alone (orbit.rs period_rates: native/openwind-tuner src/joint_run.rs), here at the
// file's end so that no line above it moves. ----

impl Stream {
    /// As `rates`, its note's period's move alone for each move asked, each solved until its residual is `tolerance` of
    /// its right side (orbit.rs period_rates): begun from the note as it sounds, nothing followed or kept. Its player
    /// and its tract put back as they stood.
    pub fn period_rates(&mut self, line: RatesLine, tolerance: f64) -> Result<crate::orbit::Found, String> {
        let row = match line.row {
            Some(row) => row,
            None => self.held.as_ref().ok_or("its rates are found at a row held, as the live dial holds one, or a row given")?.to.clone(),
        };
        let cols = self.cols;
        if row.len() != cols || line.moved.iter().any(|m| m.row.as_ref().is_some_and(|r| r.len() != cols)) {
            return Err(format!("its rows each its body's {cols} columns"));
        }
        let rate = self.native_rate();
        let kept = self.player.data().to_vec();
        let tract = self.player.tract.clone();
        if let Some(rs) = line.tract {
            let mut t = self.player.tract.take().unwrap_or_else(|| Tract::new(rate));
            t.set(rs, 0.0);
            self.player.tract = Some(t);
        }
        let asked = crate::orbit::Asked { row: &row, nudged: None, warm: line.warm, multipliers: line.multipliers, least: SILENT / self.gain, jet: self.jet };
        let found = crate::orbit::period_rates(&mut self.player, self.cols, self.outs, rate, &asked, &line.moved, tolerance);
        self.player.set_data(&kept);
        self.player.tract = tract;
        found
    }
}

// ---- A note's attack as the engine plays it, a native step at a time (native/openwind-tuner src/race.rs; the owner,
// 15 November 2026, of which register takes a note: "can this be computed deterministically ... apart from simulating
// the note itself?"; "build according to your proposal for the dominant-resonance calculator"), here at the file's
// end so that no line above it moves. ----

impl Stream {
    /// `frames` more frames of its sound at 48 kHz at the row held, as `mouth` steps them -- a native step at a time
    /// -- and each of those steps': [its mouth's pressure (its tract's answer to the reed's flow, nothing where it
    /// has no tract), its mouthpiece's (in the bore at the reed's end), Pa; the flow at the reed's end as it leaves the
    /// bore, m^3/s], nothing of them while it rests. The same sound as `render`'s: nothing of its playing is moved.
    pub fn traced(&mut self, frames: usize) -> Result<(Vec<f32>, Vec<[f64; 3]>), String> {
        if self.held.is_none() {
            return Err("its attack is traced at a row held, as the live dial holds one".into());
        }
        let (ratio, l) = (self.ratio as u64, self.half_length as u64);
        let needed = (self.frame + frames.max(1) as u64 - 1) * ratio + l + 1;
        let mut steps = Vec::new();
        while self.base + (self.radiated.len() as u64) < needed {
            let resting = self.held.as_ref().is_some_and(|held| self.resting(held));
            let before = self.n;
            self.advance(before)?;
            if self.n != before + 1 {
                return Err(format!("its attack is traced a step at a time, not {}", self.n - before));
            }
            steps.push(if resting {
                [0.0, 0.0, 0.0]
            } else {
                let (flow, pressure) = self.player.reed_recorded()?;
                [self.player.tract.as_ref().map_or(0.0, |t| t.pressure()), pressure, flow]
            });
        }
        Ok((self.render(frames)?, steps))
    }
}
