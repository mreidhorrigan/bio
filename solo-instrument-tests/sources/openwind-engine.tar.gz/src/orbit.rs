//! A note's oscillation found on the engine itself (the owner, 8 November 2026: "'The fix I'd make: solve on the engine
//! itself,' - obviously - this was implicit from the beginning"; "make that solver fix we proposed earlier"): its
//! periodic orbit on the engine's own one-period map -- its player stepped from a state at a row of controls held, its
//! tract with it, for a period -- found by Newton's method on the state and the period together, each linear solve by
//! GMRES on the map's own derivative (its steps from a state and from that state moved a little), never on a copy of the
//! bore or the reed; a phase fixed by the state's motion. Each solve with the bore's loss memory's own settling divided
//! out (the owner, 8 November 2026: "Ok, proceed"): some 840 of the clarinet's loss values keep more than 90 per cent of
//! themselves over its G4's period, the most 99.7, so that unaided the solve, its residual brought down to LINEAR, could
//! leave its answer along them wrong a hundredfold (a lip's rate read -5323 c/N where the held notes either side measure
//! 52); each one's share kept from step to step on its own read off the engine's own equations
//! (kernel.rs Player::settling), raised over the period as the map reads it, the solve sees each as settled on its own,
//! and finds from the map how the sound couples it. Its period a fraction of steps: the state between two steps read
//! along the polynomial through the POINTS about it (the cubic through four left the orbit closed only to 1e-3, its
//! reading's own error). What it computes besides, from the same map: the multipliers that say
//! whether the orbit holds (each eigenvalue of the map's derivative about it, by Arnoldi's method, the one of its own
//! motion, 1, apart), and how far its period moves for a row moved (a lip pressed, a breath raised), so that a search
//! steps along them (native/openwind/tuning-solver.mjs). Its state: every double the player changes from step to step at
//! the row (its coefficients and the row's own columns unchanged, so never moved), each scaled by its size (a bore's field's
//! by that field's largest; its pipes' ends' and joints' flows by its bore's flows' largest: a joint's own flow, stepped
//! as 2 gamma_b - gamma, flickers from step to step about a mean some sixth its flicker, and sized by itself its flicker
//! had ruled the orbit's closing), and its tract's sections. A body played in singles solved on its same steps in doubles
//! (Player::in_doubles): in its singles, a derivative's nudge is lost in their rounding. Not yet a
//! jet's: its flows kept in a ring its connector counts (kernel.rs Player::ringed), which its state must be read along.
use crate::kernel::Player;

/// What is asked: the row held (the body's columns), where the orbit begins (the player's state now, after `warm`
/// seconds at the row), and, where given, a second row whose period's move from this one's is sought, and how many
/// multipliers.
pub struct Asked<'a> {
    pub row: &'a [f64],
    pub nudged: Option<&'a [f64]>,
    pub warm: f64,
    pub multipliers: usize,
    /// The least swing of its radiated sound that is one (its flow's time derivative, before the stream's gain): the
    /// stream's silence, the smallest step of a 24-bit file.
    pub least: f64,
    /// A jet's columns (its speed, its derivative, its next value): a constant speed's derivative none.
    pub jet: Option<(usize, usize, usize)>,
}

/// What it found: its period in steps and in Hz, the closing of the orbit (its state's move over a period, against its
/// size), Newton's steps and the map's evaluations, its largest multipliers' sizes (its own motion's apart) and whether
/// it holds, the period's move in steps for the row moved, and whether it sounds at all; and the flow it radiates each
/// step over two of its periods from its start and five steps more (`flows`: its sound, Stream::orbit).
#[derive(Debug, Clone, Default, serde::Serialize)]
pub struct Found {
    pub sounds: bool,
    pub steps: f64,
    pub hz: f64,
    pub closing: f64,
    /// Its closing before Newton's first step and after each, and how far each step's linear solve brought its residual
    /// down (against LINEAR).
    pub closings: Vec<f64>,
    pub linear: Vec<f64>,
    pub newton: usize,
    pub maps: usize,
    pub multipliers: Vec<f64>,
    /// The same multipliers, each its real and imaginary parts.
    pub values: Vec<[f64; 2]>,
    pub holds: Option<bool>,
    pub moved: Option<f64>,
    pub why: Option<String>,
    #[serde(skip)]
    pub flows: Vec<f64>,
    /// Its sound's level: its radiated flow's mean square over exactly a period, dB, the stream's gain apart (level_of).
    pub level: f64,
    /// For each move asked (`rates`), how far its period and its level move.
    #[serde(skip_serializing_if = "Vec::is_empty")]
    pub rates: Vec<Rate>,
}

/// A move of its player's controls whose rates are sought: its row moved, its tract's resonances moved, or both; or its
/// body's joints pulled to tune (`pulls`, m each in its header's order: kernel.rs Player::pull_points), in `rates` only.
#[derive(serde::Deserialize, Clone, Debug, Default)]
pub struct Moved {
    #[serde(default)]
    pub row: Option<Vec<f64>>,
    #[serde(default)]
    pub tract: Option<Vec<crate::tract::Resonance>>,
    #[serde(default)]
    pub pulls: Option<Vec<f64>>,
    /// Its body remade (`points_step`): each coefficient its remaking moves and its value there, put in the map's base.
    #[serde(skip)]
    pub coefficients: Option<Vec<(usize, f64)>>,
}

/// How far a move moves its orbit: its period (steps) and its level (dB), along the orbit's derivative.
#[derive(Debug, Clone, Default, serde::Serialize)]
pub struct Rate {
    pub steps: f64,
    pub level: f64,
    /// Its derivative's linear solve's residual, of its right side.
    pub residual: f64,
}

// (Newton's steps at most; its closing sought, a state's move over a period against its size; GMRES's iterations at
// most and how far each of Newton's solves brings its residual down, and each rate's (its residual at LINEAR left a
// breath's rate half a per cent from the held notes either side, its level's five); the share of the state a derivative's nudge moves it; the steps
// the state between two is read through; the highest and lowest pitches sought (Hz), the rate the period is first sought at, and how far below the
// rest a lag's difference is taken for a period, YIN's.)
const NEWTON: usize = 10;
const CLOSED: f64 = 1e-8;
const KRYLOV: usize = 160;
const LINEAR: f64 = 1e-3;
const RATED: f64 = 1e-6;
// (How far each solve of a multiplier's rates brings its residual down: its rate wanted to a ten-thousandth.)
const MOVED: f64 = 1e-4;
const NUDGE: f64 = 1e-6;
const POINTS: usize = 6;
const BEFORE: usize = POINTS / 2 - 1;
const PITCHES: [f64; 2] = [5000.0, 25.0];
const SOUGHT: f64 = 48_000.0;
const YIN: f64 = 0.1;
// (How far either side of a pitch its period is sought, octaves, where it is sought near one (picked): within a tritone,
// so that neither its octave nor its fifth below is taken for it.)
const NEAR: f64 = 0.5;

/// The swing of the sound radiated over the flows `f` (a step a value, at `rate`): its time derivative's largest size.
fn swing_of(f: &[f64], rate: f64) -> f64 {
    f.windows(3).map(|w| ((w[2] - w[0]) / 2.0 * rate).abs()).fold(0.0, f64::max)
}

struct Map<'a> {
    player: &'a mut Player,
    u: Vec<f64>,
    y: Vec<f64>,
    cols: usize,
    outs: usize,
    base: Vec<f64>,
    mask: Vec<usize>,
    scale: Vec<f64>,
    /// Each value's share of itself kept from one step to the next on its own: a loss value's (kernel.rs
    /// Player::settling), none (0) for the rest.
    kept: Vec<f64>,
    /// Each joint's own flows, where they lie among its doubles, and the projection onto what of them its Step reads
    /// (row by row): the rest left out of the state (joints).
    joints: Vec<(Vec<usize>, Vec<f64>)>,
    maps: usize,
}

impl Map<'_> {
    fn tracted(&self) -> usize {
        self.player.tract.as_ref().map_or(0, |t| t.state().len())
    }

    /// The state as it stands, scaled: each joint's own flows only as far as its Step reads them.
    fn read(&mut self) -> Vec<f64> {
        let mut d = self.player.data().to_vec();
        for (at, p) in &self.joints {
            let g: Vec<f64> = at.iter().map(|&k| d[k]).collect();
            for (r, &k) in at.iter().enumerate() {
                d[k] = (0..g.len()).map(|c| p[r * g.len() + c] * g[c]).sum();
            }
        }
        let mut x: Vec<f64> = self.mask.iter().map(|&k| d[k]).collect();
        if let Some(t) = &self.player.tract {
            x.extend(t.state());
        }
        x.iter().zip(&self.scale).map(|(v, s)| v / s).collect()
    }

    /// The state `x` (scaled) put in place, the rest of the player's doubles as they stood at its start.
    fn load(&mut self, x: &[f64]) {
        let (n, scale) = (self.mask.len(), &self.scale);
        let mut d = self.base.clone();
        for (j, &k) in self.mask.iter().enumerate() {
            d[k] = x[j] * scale[j];
        }
        self.player.set_data(&d);
        if let Some(t) = self.player.tract.as_mut() {
            let s: Vec<f64> = x[n..].iter().zip(&scale[n..]).map(|(v, s)| v * s).collect();
            t.set_state(&s);
        }
    }

    /// `steps` steps at the row; its first output (the flow it radiates) each step into `flows` where given.
    fn step(&mut self, steps: usize, mut flows: Option<&mut Vec<f64>>) -> Result<(), String> {
        let mut done = 0;
        while done < steps {
            let run = (steps - done).min(self.u.len() / self.cols);
            let status = self.player.steps(&self.u[..run * self.cols], &mut self.y[..run * self.outs], run);
            if status != 0 {
                return Err(format!("the body stopped ({status})"));
            }
            if let Some(f) = flows.as_deref_mut() {
                f.extend((0..run).map(|k| self.y[k * self.outs]));
            }
            done += run;
        }
        Ok(())
    }

    /// The period map: from `x` (scaled) over `t` steps, the state there read along the polynomial through the POINTS
    /// steps about it -> (that state, its rate of change a step).
    fn map(&mut self, x: &[f64], t: f64) -> Result<(Vec<f64>, Vec<f64>), String> {
        self.mapped(x, t, None)
    }

    /// As `map`, the flow it radiates each step from `x` into `flows` where given (its first the flow a step on: t + 3 of
    /// them, as level_of reads them).
    fn mapped(&mut self, x: &[f64], t: f64, mut flows: Option<&mut Vec<f64>>) -> Result<(Vec<f64>, Vec<f64>), String> {
        self.maps += 1;
        let n = t.floor() as usize;
        // (A period under the steps its map reads before its end is none: `n - BEFORE` would wrap and step for ever.)
        if n <= BEFORE {
            return Err(format!("a period of {t} steps, under the {POINTS} its map reads at its end"));
        }
        self.load(x);
        self.step(n - BEFORE, flows.as_deref_mut())?;
        let mut nodes = Vec::with_capacity(POINTS);
        for k in 0..POINTS {
            if k > 0 {
                self.step(1, flows.as_deref_mut())?;
            }
            nodes.push(self.read());
        }
        let (w, dw) = weights(t - n as f64);
        let m = x.len();
        let (mut at, mut rate) = (vec![0.0; m], vec![0.0; m]);
        for (j, node) in nodes.iter().enumerate() {
            for i in 0..m {
                at[i] += w[j] * node[i];
                rate[i] += dw[j] * node[i];
            }
        }
        Ok((at, rate))
    }

    /// Its doubles outside the state (`base`) as the row now held sets them: stepped once from `x` at that row, each double
    /// the state leaves out taken from there -- those a row's move sets once, as a reed's contact stiffness as it was last
    /// stepped (kernel.rs Q_LASTKC), against which it rescales its contact once where its stiffness moves -- so that a map
    /// at a moved row is that row's own, not a move to it made again every period.
    fn rebased(&mut self, x: &[f64]) -> Result<Vec<f64>, String> {
        self.load(x);
        self.step(1, None)?;
        let d = self.player.data();
        let mut base = self.base.clone();
        let mut j = 0;
        for (k, b) in base.iter_mut().enumerate() {
            if j < self.mask.len() && self.mask[j] == k {
                j += 1;
            } else {
                *b = d[k];
            }
        }
        Ok(base)
    }

    /// How little each value settles on its own over the map's period `t`: 1 less the share of itself it keeps, its share
    /// a step raised over the period's steps and read along the same polynomial as the map reads the state (1 where it
    /// keeps none, or where that is not above 0) -- what the orbit's solve divides out.
    fn settled(&self, t: f64) -> Vec<f64> {
        let n = t.floor() as usize;
        let (w, _) = weights(t - n as f64);
        self.kept
            .iter()
            .map(|&r| {
                if r == 0.0 {
                    return 1.0;
                }
                let first = r.powi((n - BEFORE) as i32);
                let kept: f64 = w.iter().enumerate().map(|(j, wj)| wj * first * r.powi(j as i32)).sum();
                if 1.0 - kept > 0.0 { 1.0 - kept } else { 1.0 }
            })
            .collect()
    }
}

/// What of a joint's own flows its Step (`k` by `k`, row by row) reads: the projection onto its rows' span (Gram and
/// Schmidt's, a row within 1e-12 of the largest's size of those before it read as theirs), row by row -- none where its
/// Step is none. The rest, never read, is no part of the note: a discontinuity of no mass's gamma flickers from step to
/// step as 2 gamma_b - gamma leaves it, undamped, and closes over no period.
fn read_by(step: &[f64], k: usize) -> Vec<f64> {
    let largest = (0..k).map(|r| norm(&step[r * k..(r + 1) * k])).fold(0.0, f64::max);
    let mut basis: Vec<Vec<f64>> = Vec::new();
    for r in 0..k {
        let mut v = step[r * k..(r + 1) * k].to_vec();
        for q in &basis {
            let c = dot(&v, q);
            for (vi, qi) in v.iter_mut().zip(q) {
                *vi -= c * qi;
            }
        }
        let n = norm(&v);
        if n > 1e-12 * largest {
            basis.push(v.iter().map(|x| x / n).collect());
        }
    }
    let mut p = vec![0.0; k * k];
    for q in &basis {
        for i in 0..k {
            for j in 0..k {
                p[i * k + j] += q[i] * q[j];
            }
        }
    }
    p
}

/// Lagrange's weights at `th` between the steps, the POINTS nodes at -BEFORE.. about it: each node's, and its
/// derivative's.
fn weights(th: f64) -> (Vec<f64>, Vec<f64>) {
    let at_node = |j: usize| j as f64 - BEFORE as f64;
    let (mut w, mut dw) = (vec![0.0; POINTS], vec![0.0; POINTS]);
    for j in 0..POINTS {
        let mut prod = 1.0;
        for i in (0..POINTS).filter(|&i| i != j) {
            prod *= (th - at_node(i)) / (at_node(j) - at_node(i));
        }
        w[j] = prod;
        for l in (0..POINTS).filter(|&l| l != j) {
            let mut q = 1.0 / (at_node(j) - at_node(l));
            for i in (0..POINTS).filter(|&i| i != j && i != l) {
                q *= (th - at_node(i)) / (at_node(j) - at_node(i));
            }
            dw[j] += q;
        }
    }
    (w, dw)
}

fn dot(a: &[f64], b: &[f64]) -> f64 {
    a.iter().zip(b).map(|(x, y)| x * y).sum()
}

fn norm(a: &[f64]) -> f64 {
    dot(a, a).sqrt()
}

/// GMRES from nothing on `apply` (an operator on vectors of `b`'s length), until its residual is `tolerance` of `b`'s or
/// KRYLOV iterations -> the solution, and its residual's size against `b`'s.
fn gmres(b: &[f64], tolerance: f64, mut apply: impl FnMut(&[f64]) -> Result<Vec<f64>, String>) -> Result<(Vec<f64>, f64), String> {
    let (n, beta) = (b.len(), norm(b));
    if beta == 0.0 {
        return Ok((vec![0.0; n], 0.0));
    }
    let mut v: Vec<Vec<f64>> = vec![b.iter().map(|x| x / beta).collect()];
    let mut h: Vec<Vec<f64>> = Vec::new();
    let (mut cs, mut sn, mut g): (Vec<f64>, Vec<f64>, Vec<f64>) = (Vec::new(), Vec::new(), vec![beta]);
    let mut k = 0;
    while k < KRYLOV {
        let mut w = apply(&v[k])?;
        let mut col = vec![0.0; k + 2];
        for (j, vj) in v.iter().enumerate() {
            col[j] = dot(&w, vj);
            for (wi, x) in w.iter_mut().zip(vj) {
                *wi -= col[j] * x;
            }
        }
        col[k + 1] = norm(&w);
        for j in 0..k {
            let t = cs[j] * col[j] + sn[j] * col[j + 1];
            col[j + 1] = -sn[j] * col[j] + cs[j] * col[j + 1];
            col[j] = t;
        }
        let r = (col[k] * col[k] + col[k + 1] * col[k + 1]).sqrt();
        let (c, s) = if r == 0.0 { (1.0, 0.0) } else { (col[k] / r, col[k + 1] / r) };
        let hk1 = col[k + 1];
        col[k] = r;
        col[k + 1] = 0.0;
        cs.push(c);
        sn.push(s);
        g.push(-s * g[k]);
        g[k] *= c;
        h.push(col);
        let done = g[k + 1].abs() <= tolerance * beta || hk1 == 0.0;
        if !done {
            v.push(w.iter().map(|x| x / hk1).collect());
        }
        k += 1;
        if done {
            break;
        }
    }
    // (The least-squares solution's coefficients, back-substituted, then the solution itself.)
    let mut y = vec![0.0; k];
    for i in (0..k).rev() {
        let mut s = g[i];
        for j in i + 1..k {
            s -= h[j][i] * y[j];
        }
        y[i] = s / h[i][i];
    }
    let mut x = vec![0.0; n];
    for (j, yj) in y.iter().enumerate() {
        for (xi, vi) in x.iter_mut().zip(&v[j]) {
            *xi += yj * vi;
        }
    }
    Ok((x, g[k].abs() / beta))
}

/// The eigenvalues of an upper Hessenberg matrix `a` (n by n, rows), by the shifted QR algorithm (Numerical Recipes'
/// hqr: its double shifts, real arithmetic) -> each one, its real and imaginary parts.
fn hessenberg_values(mut a: Vec<Vec<f64>>) -> Vec<[f64; 2]> {
    let n = a.len();
    let mut out = Vec::new();
    let anorm: f64 = a.iter().flatten().map(|x| x.abs()).sum();
    let mut nn = n as isize - 1;
    let mut t = 0.0;
    while nn >= 0 {
        let mut its = 0;
        loop {
            let mut l = nn;
            while l >= 1 {
                let s = a[(l - 1) as usize][(l - 1) as usize].abs() + a[l as usize][l as usize].abs();
                let s = if s == 0.0 { anorm } else { s };
                if a[l as usize][(l - 1) as usize].abs() + s == s {
                    a[l as usize][(l - 1) as usize] = 0.0;
                    break;
                }
                l -= 1;
            }
            let nu = nn as usize;
            let x = a[nu][nu];
            if l == nn {
                out.push([x + t, 0.0]);
                nn -= 1;
                break;
            }
            let y = a[nu - 1][nu - 1];
            let w = a[nu][nu - 1] * a[nu - 1][nu];
            if l == nn - 1 {
                let p = 0.5 * (y - x);
                let q = p * p + w;
                let z = q.abs().sqrt();
                let xx = x + t;
                if q >= 0.0 {
                    let z = p + if p >= 0.0 { z } else { -z };
                    let a1 = xx + z;
                    let a2 = if z != 0.0 { xx - w / z } else { a1 };
                    out.push([a1, 0.0]);
                    out.push([a2, 0.0]);
                } else {
                    let re = xx + p;
                    out.push([re, z]);
                    out.push([re, -z]);
                }
                nn -= 2;
                break;
            }
            if its == 60 {
                return out;
            }
            let (mut x, mut y, mut w) = (x, y, w);
            if its == 10 || its == 20 {
                t += x;
                for i in 0..=nu {
                    a[i][i] -= x;
                }
                let s = a[nu][nu - 1].abs() + a[nu - 1][nu - 2].abs();
                x = 0.75 * s;
                y = x;
                w = -0.4375 * s * s;
            }
            its += 1;
            let mut m = nn - 2;
            let (mut p, mut q, mut r);
            loop {
                let mu = m as usize;
                let z = a[mu][mu];
                let rr = x - z;
                let ss = y - z;
                p = (rr * ss - w) / a[mu + 1][mu] + a[mu][mu + 1];
                q = a[mu + 1][mu + 1] - z - rr - ss;
                r = a[mu + 2][mu + 1];
                let s = p.abs() + q.abs() + r.abs();
                p /= s;
                q /= s;
                r /= s;
                if m == l {
                    break;
                }
                let u = a[mu][mu - 1].abs() * (q.abs() + r.abs());
                let v = p.abs() * (a[mu - 1][mu - 1].abs() + z.abs() + a[mu + 1][mu + 1].abs());
                if u + v == v {
                    break;
                }
                m -= 1;
            }
            let mu = m as usize;
            for i in mu + 2..=nu {
                a[i][i - 2] = 0.0;
                if i != mu + 2 {
                    a[i][i - 3] = 0.0;
                }
            }
            let mut k = mu;
            while k + 1 <= nu {
                let mut sized = 0.0;
                if k != mu {
                    p = a[k][k - 1];
                    q = a[k + 1][k - 1];
                    r = if k + 1 != nu { a[k + 2][k - 1] } else { 0.0 };
                    sized = p.abs() + q.abs() + r.abs();
                    if sized != 0.0 {
                        p /= sized;
                        q /= sized;
                        r /= sized;
                    }
                }
                let s = (p * p + q * q + r * r).sqrt() * if p >= 0.0 { 1.0 } else { -1.0 };
                if s != 0.0 {
                    if k == mu {
                        if l as usize != mu {
                            a[k][k - 1] = -a[k][k - 1];
                        }
                    } else {
                        a[k][k - 1] = -s * sized;
                    }
                    p += s;
                    let x = p / s;
                    let y = q / s;
                    let z = r / s;
                    q /= p;
                    r /= p;
                    for j in k..=nu {
                        let mut pp = a[k][j] + q * a[k + 1][j];
                        if k + 1 != nu {
                            pp += r * a[k + 2][j];
                            a[k + 2][j] -= pp * z;
                        }
                        a[k + 1][j] -= pp * y;
                        a[k][j] -= pp * x;
                    }
                    let mmin = if nu < k + 3 { nu } else { k + 3 };
                    for i in l as usize..=mmin {
                        let mut pp = x * a[i][k] + y * a[i][k + 1];
                        if k + 1 != nu {
                            pp += z * a[i][k + 2];
                            a[i][k + 2] -= pp * r;
                        }
                        a[i][k + 1] -= pp * q;
                        a[i][k] -= pp;
                    }
                }
                k += 1;
            }
        }
    }
    out
}

/// The period of the radiated flow `f` (a step a value, at `rate`), as it repeats over its last stretch -> steps. Sought first among the flow's means over SOUGHT's frames, from PITCHES' highest to their
/// lowest, as YIN takes it (de Cheveigne & Kawahara 2002, doi:10.1121/1.1458024: each lag's squared difference against
/// its mean over the lags below it, the first under YIN taken at its least, so that no multiple of the period is) --
/// then among the steps about it, its least read between steps on its parabola.
fn period_of(f: &[f64], rate: f64) -> Option<f64> {
    period_within(f, rate, PITCHES)
}

/// As `period_of`, its period sought only between the pitches `pitches` (Hz, the highest first).
fn period_within(f: &[f64], rate: f64, pitches: [f64; 2]) -> Option<f64> {
    let q = (rate / SOUGHT).round().max(1.0) as usize;
    let (lo, hi) = (((rate / q as f64) / pitches[0]).floor().max(2.0) as usize, ((rate / q as f64) / pitches[1]).ceil() as usize);
    if f.len() < 2 * hi * q + 4 * q {
        return None;
    }
    let tail = &f[f.len() - 2 * hi * q..];
    let coarse: Vec<f64> = tail.chunks(q).map(|c| c.iter().sum::<f64>() / c.len() as f64).collect();
    let diff = |g: &[f64], lag: usize, w: usize| (0..w).map(|i| (g[i + lag] - g[i]).powi(2)).sum::<f64>();
    let mut normal = vec![1.0; hi + 1];
    let mut running = 0.0;
    for lag in 1..=hi {
        let d = diff(&coarse, lag, hi);
        running += d;
        normal[lag] = if running > 0.0 { d * lag as f64 / running } else { 1.0 };
    }
    let mut at = (lo..=hi).find(|&lag| normal[lag] < YIN).unwrap_or_else(|| (lo..=hi).min_by(|&a, &b| normal[a].total_cmp(&normal[b])).unwrap());
    while at < hi && normal[at + 1] < normal[at] {
        at += 1;
    }
    // (Among the steps about it.)
    let (from, to) = ((at * q).saturating_sub(2 * q).max(2), at * q + 2 * q);
    let w = tail.len() - to - 1;
    let d: Vec<f64> = (from - 1..=to + 1).map(|lag| diff(tail, lag, w)).collect();
    let (mut best, mut k) = (f64::INFINITY, 1);
    for (j, v) in d.iter().enumerate().skip(1).take(d.len() - 2) {
        if *v < best {
            best = *v;
            k = j;
        }
    }
    let (a, b, c) = (d[k - 1], d[k], d[k + 1]);
    let den = a - 2.0 * b + c;
    // (Read on its parabola only where its least is the least of the three: the lag before the first searched, lower,
    // put a parabola nearly flat's least 1618 steps before it, a period under none.)
    let shift = if den > 0.0 && b <= a && b <= c { 0.5 * (a - c) / den } else { 0.0 };
    Some((from - 1 + k) as f64 + shift)
}

/// The orbit of `player` at `asked.row`, from its state now (warmed `asked.warm` s at the row first) -> what it found;
/// the player left wherever its search left it (the caller keeps its own state and puts it back). A bore played in
/// singles solved on its same steps in doubles (Player::in_doubles), played in singles again after.
pub fn orbit(player: &mut Player, cols: usize, outs: usize, rate: f64, asked: &Asked) -> Result<Found, String> {
    rates(player, cols, outs, rate, asked, &[])
}

/// As `orbit`, and for each of `moved` -- a move of its controls, small enough that the orbit moves along its
/// derivative -- how far its period and its level move (Found::rates): what a held note's pitch and loudness do as its
/// player moves each control, read on the engine's own one-period map, so that the least move that puts the note at its
/// pitch is arithmetic on them (dial.mjs heldAt).
pub fn rates(player: &mut Player, cols: usize, outs: usize, rate: f64, asked: &Asked, moved: &[Moved]) -> Result<Found, String> {
    let single = player.single() && !player.crewed();
    if single {
        player.in_doubles(true);
    }
    let found = solved(player, cols, outs, rate, asked, moved);
    if single {
        player.in_doubles(false);
    }
    found
}

/// As `orbit`, its period sought only within NEAR octaves of `near` (Hz): a held note picked up where its start's pitch
/// says it sounds, so that neither a multiple of its period nor its reed's sound coming to rest is taken for it.
pub fn picked(player: &mut Player, cols: usize, outs: usize, rate: f64, asked: &Asked, near: f64) -> Result<Found, String> {
    if !(near > 0.0) {
        return Err("the pitch its period is sought near".into());
    }
    let single = player.single() && !player.crewed();
    if single {
        player.in_doubles(true);
    }
    let found = solved_near(player, cols, outs, rate, asked, &[], Some(near));
    if single {
        player.in_doubles(false);
    }
    found
}

/// The level of the sound over a period of `t` steps, from the flows radiated each step from the orbit's start (`f`: its
/// first the flow a step on, at least `t` + 3 of them): its time derivative's mean square over exactly the period -- the
/// step past its whole steps counted at the period's fraction, so that it moves smoothly as the period does -- in dB.
fn level_of(f: &[f64], t: f64, rate: f64) -> f64 {
    let n = t.floor() as usize;
    let r = |k: usize| (f[k + 2] - f[k]) / 2.0 * rate;
    let sum = (0..n).map(|k| r(k) * r(k)).sum::<f64>() + (t - n as f64) * r(n) * r(n);
    10.0 * (sum / t).log10()
}

// ---- a held note settling once its player has moved: how long until it is the held note there ----
// (The owner, 8 November 2026, of the dynamic range a note reaches a few moments after it starts, and what its player
// does to get there; design approved: "Yes, build".) Its largest multipliers are its bore's loss memory, which keeps
// some 99.8% of itself a period whether or not the sound shows it, so how soon the note is there is read from the
// engine stepped, not from them: from a held note's orbit, its controls moved at once to another's, the engine stepped
// at them and its sound read over windows of WINDOWS of the held note's periods a period apart -- its pitch from its
// phase's move at the held note's pitch from window to window, its level over each window's first period as an orbit's
// is read (level_of) -- until both stay within what is asked of the held note there for `hold` s, or `horizon` s.
const WINDOWS: f64 = 2.0;
// (Its sound read SETTLED_KEPT times over the time it settles at most, so that the way it settles is seen too.)
const SETTLED_KEPT: usize = 64;

/// What is asked of a move: the held note it moves to (its pitch, Hz, and level, dB, as its orbit has them), how near
/// it must stay (cents, dB) for how long (s), and for how long at most it is stepped (s).
#[derive(serde::Deserialize, Clone, Debug, Default)]
pub struct Settle {
    pub hz: f64,
    pub level: f64,
    pub cents: f64,
    pub decibels: f64,
    pub hold: f64,
    pub horizon: f64,
}

/// How a move settled: the seconds from the move until the note stays near the held note asked (none, where it did not
/// by its horizon), the seconds stepped, how far its pitch (cents) and its level (dB) stood from the held note's at its
/// last window and at most after its first, and its windows' (seconds, cents, dB) at SETTLED_KEPT times; whether it
/// sounds at all at its end.
#[derive(Debug, Clone, Default, serde::Serialize)]
pub struct Settled {
    pub seconds: Option<f64>,
    pub stepped: f64,
    pub cents: f64,
    pub level: f64,
    pub most: [f64; 2],
    pub sounds: bool,
    pub windows: Vec<[f64; 3]>,
}

/// The player, from its state now (a held note's orbit), stepped at `row` (its tract as it stands) until it settles on
/// the held note `asked` describes (above) -> how it settled; the player left where its steps left it (the caller keeps
/// its own state and puts it back). A bore played in singles stepped in doubles, as its orbits are found.
pub fn settles(player: &mut Player, cols: usize, outs: usize, rate: f64, row: &[f64], asked: &Settle) -> Result<Settled, String> {
    if !(asked.hz > 0.0 && asked.hz < rate / 2.0) || !(asked.horizon > 0.0) {
        return Err("a held note's pitch and a horizon".into());
    }
    if row.len() != cols {
        return Err(format!("its row its body's {cols} columns"));
    }
    let single = player.single() && !player.crewed();
    if single {
        player.in_doubles(true);
    }
    let found = settling(player, outs, rate, row, asked);
    if single {
        player.in_doubles(false);
    }
    found
}

fn settling(player: &mut Player, outs: usize, rate: f64, row: &[f64], asked: &Settle) -> Result<Settled, String> {
    use crate::sparse::C;
    let t = rate / asked.hz;
    let (len, hop) = ((WINDOWS * t).round() as usize, t.round().max(1.0) as usize);
    let omega = 2.0 * std::f64::consts::PI * asked.hz / rate;
    let hann: Vec<f64> = (0..len).map(|n| 0.5 - 0.5 * (2.0 * std::f64::consts::PI * n as f64 / len as f64).cos()).collect();
    let chunk = 64;
    let rows = row.repeat(chunk);
    let mut y = vec![0.0; chunk * outs];
    let (mut f, mut windows): (Vec<f64>, Vec<[f64; 3]>) = (vec![], vec![]);
    let (most_steps, hold) = ((asked.horizon * rate).ceil() as usize, asked.hold.max(0.0));
    let (mut start, mut last_phase): (usize, Option<f64>) = (0, None);
    let (mut since, mut settled): (Option<f64>, Option<f64>) = (None, None);
    while f.len() < most_steps {
        if player.steps(&rows, &mut y, chunk) != 0 {
            return Err("the body stopped".into());
        }
        f.extend((0..chunk).map(|k| y[k * outs]));
        // (Each window whose flows are all in: its derivative's phase at the held note's pitch, and its first period's
        // level.)
        while start + len + 2 <= f.len() && start + t.floor() as usize + 3 <= f.len() {
            let r = |k: usize| (f[k + 2] - f[k]) / 2.0 * rate;
            let c = (0..len).fold(C::default(), |s, n| s + C::polar(hann[n] * r(start + n), -omega * (start + n) as f64));
            let phase = c.arg();
            let level = level_of(&f[start..], t, rate) - asked.level;
            if let Some(last) = last_phase {
                let mut d = phase - last;
                while d > std::f64::consts::PI {
                    d -= 2.0 * std::f64::consts::PI;
                }
                while d < -std::f64::consts::PI {
                    d += 2.0 * std::f64::consts::PI;
                }
                let cents = 1200.0 * (1.0 + d / (omega * hop as f64)).log2();
                let at = (start + len) as f64 / rate;
                windows.push([at, cents, level]);
                let near = cents.abs() <= asked.cents && level.abs() <= asked.decibels;
                since = if near { since.or(Some(at)) } else { None };
                if since.is_some_and(|s| at - s >= hold) {
                    settled = since;
                }
            }
            last_phase = Some(phase);
            start += hop;
        }
        if settled.is_some() {
            break;
        }
    }
    let stepped = f.len() as f64 / rate;
    let last = windows.last().copied().unwrap_or([0.0, f64::NAN, f64::NAN]);
    let most = windows.iter().skip(1).fold([0.0f64, 0.0f64], |m, w| [m[0].max(w[1].abs()), m[1].max(w[2].abs())]);
    let tail = f.len().saturating_sub((2.0 * t).ceil() as usize + 4);
    let sounds = swing_of(&f[tail..], rate) > 0.0 && last[2].is_finite();
    let every = windows.len().div_ceil(SETTLED_KEPT).max(1);
    let kept: Vec<[f64; 3]> = windows.iter().enumerate().filter(|(i, _)| i % every == 0 || *i + 1 == windows.len()).map(|(_, w)| *w).collect();
    Ok(Settled { seconds: settled, stepped, cents: last[1], level: last[2], most, sounds, windows: kept })
}

/// The orbit's move for the map moved by `b` (the moved map's step from the orbit's state, against its own, negated; or
/// its closing, negated, for Newton's step): its state's move and its period's, its phase held by its own motion (`own`)
/// -> the two together, and its solve's residual against `b`. Solved for its move with each value's own settling over
/// the period divided out (Map::settled), then that move divided by it: along the loss memory, nearly still from period
/// to period, the solve sees each value as settled on its own, the map saying how the sound couples it.
#[allow(clippy::too_many_arguments)]
fn derivative(map: &mut Map, x: &[f64], t: f64, px: &[f64], rate_x: &[f64], own: &[f64], b: Vec<f64>, tolerance: f64) -> Result<(Vec<f64>, f64), String> {
    derivative_kept(map, x, t, px, rate_x, own, b, tolerance, None)
}

/// As `derivative`, the directions its solve takes kept in `kept` where given and those kept before taken first
/// (gcr_kept): about one orbit, each solve after the first adds only the directions its own move needs.
fn derivative_kept(map: &mut Map, x: &[f64], t: f64, px: &[f64], rate_x: &[f64], own: &[f64], b: Vec<f64>, tolerance: f64, kept: Option<&mut Kept>) -> Result<(Vec<f64>, f64), String> {
    let m = x.len();
    let size = norm(x);
    let settled = map.settled(t);
    let apply = |given: &[f64]| {
        let v: Vec<f64> = given.iter().enumerate().map(|(i, g)| if i < m { g / settled[i] } else { *g }).collect();
        let (dx, dt) = (&v[..m], v[m]);
        let dn = norm(dx);
        let mut out = vec![0.0; m + 1];
        if dn > 0.0 {
            let e = NUDGE * size / dn;
            let moved: Vec<f64> = x.iter().zip(dx).map(|(a, d)| a + e * d).collect();
            let (pm, _) = map.map(&moved, t)?;
            for i in 0..m {
                out[i] = (pm[i] - px[i]) / e - dx[i];
            }
        }
        for i in 0..m {
            out[i] += rate_x[i] * dt;
        }
        out[m] = dot(own, dx);
        Ok(out)
    };
    let (mut step, residual) = match kept {
        Some(kept) => gcr_kept(&b, tolerance, kept, apply)?,
        None => gmres(&b, tolerance, apply)?,
    };
    for (s, by) in step.iter_mut().zip(&settled) {
        *s /= by;
    }
    Ok((step, residual))
}

fn solved(player: &mut Player, cols: usize, outs: usize, rate: f64, asked: &Asked, moved: &[Moved]) -> Result<Found, String> {
    solved_near(player, cols, outs, rate, asked, moved, None)
}

/// As `solved`, its period sought within NEAR octaves of `near` (Hz) where given (picked).
fn solved_near(player: &mut Player, cols: usize, outs: usize, rate: f64, asked: &Asked, moved: &[Moved], near: Option<f64>) -> Result<Found, String> {
    if player.crewed() {
        return Err("its orbit is found on one core: a dial of one thread (--threads 1)".into());
    }
    if player.ringed() {
        return Err("a jet's orbit is not yet found: its flows are kept in a ring, not yet read in its order".into());
    }
    let row = |given: &[f64]| {
        let mut r = given.to_vec();
        if let Some((uj, duj, next)) = asked.jet {
            r[duj] = 0.0;
            r[next] = r[uj];
        }
        r
    };
    let block = 2 * (rate / PITCHES[1]).ceil() as usize + 8;
    let mut map = Map { player, u: row(asked.row).repeat(block), y: vec![0.0; block * outs], cols, outs, base: vec![], mask: vec![], scale: vec![], kept: vec![], joints: vec![], maps: 0 };
    if let Some(t) = map.player.tract.as_mut() {
        t.settle();
    }
    // (Warmed at the row, its radiated flow kept: its period found where it repeats; then its state's every double that
    // moves over the next period, and each one's size over it.)
    let mut flows = Vec::new();
    let warm = ((asked.warm * rate) as usize).max(3 * (rate / PITCHES[1]).ceil() as usize);
    map.step(warm, Some(&mut flows))?;
    // (Silent where its sound is under the stream's silence.)
    let silent = |why: String| Ok(Found { sounds: false, why: Some(why), ..Found::default() });
    if swing_of(&flows[flows.len() / 2..], rate) < asked.least {
        return silent("its sound at the row is under the smallest step of a 24-bit file".into());
    }
    // (Sought near `near` within the pitches any wind plays: a start that grows at a pitch beyond them -- the clarinet's
    // A6 at its rules, its root some way past them -- sounds none of them.)
    let pitches = match near {
        Some(hz) if hz / NEAR.exp2() > PITCHES[0] || hz * NEAR.exp2() < PITCHES[1] => {
            return silent(format!("its start grows at {hz:.0} Hz, beyond the pitches it plays"));
        }
        Some(hz) => [(hz * NEAR.exp2()).min(PITCHES[0]), (hz / NEAR.exp2()).max(PITCHES[1])],
        None => PITCHES,
    };
    let found_period = match near {
        Some(_) => period_within(&flows, rate, pitches),
        None => period_of(&flows, rate),
    };
    let Some(mut t) = found_period else {
        return silent("no period in its sound at the row".into());
    };
    prepare(&mut map, t)?;
    let mut x = map.read();
    // (Newton's method on the state and the period: each step the least move -- its phase held by the state's own
    // motion -- that closes the orbit by the map's derivative, halved until it closes it more; none that does, the orbit
    // as closed as its map allows.)
    let (mut px, mut rate_x) = map.map(&x, t)?;
    let mut f: Vec<f64> = px.iter().zip(&x).map(|(a, b)| a - b).collect();
    let mut closing = norm(&f) / norm(&x);
    let mut newton = 0;
    let (mut closings, mut linear) = (vec![closing], Vec::new());
    let still = |r: &[f64]| norm(r) == 0.0 || !norm(r).is_finite();
    while closing > CLOSED && newton < NEWTON && !still(&rate_x) {
        newton += 1;
        let phase: Vec<f64> = {
            let n = norm(&rate_x);
            rate_x.iter().map(|v| v / n).collect()
        };
        let m = x.len();
        let mut b: Vec<f64> = f.iter().map(|v| -v).collect();
        b.push(0.0);
        let (x0, t0, px0, r0) = (x.clone(), t, px.clone(), rate_x.clone());
        let (step, reached) = derivative(&mut map, &x0, t0, &px0, &r0, &phase, b, LINEAR)?;
        let mut scale = 1.0;
        let mut closer = false;
        while scale >= 1.0 / 16.0 {
            let tried: Vec<f64> = x0.iter().zip(&step[..m]).map(|(a, d)| a + scale * d).collect();
            let tt = t0 + scale * step[m];
            // (A period outside the pitches it was sought within is no step: a step of Newton's that sent it to many
            // seconds had the map run each for as long, the clarinet's B-flat 6 at its rules for over ten minutes.)
            if !(tt >= rate / pitches[0] && tt <= rate / pitches[1]) {
                scale /= 2.0;
                continue;
            }
            let (p2, r2) = map.map(&tried, tt)?;
            let f2: Vec<f64> = p2.iter().zip(&tried).map(|(a, b)| a - b).collect();
            let c2 = norm(&f2) / norm(&tried);
            if c2 < closing {
                x = tried;
                t = tt;
                px = p2;
                rate_x = r2;
                f = f2;
                closing = c2;
                closings.push(c2);
                linear.push(reached);
                closer = true;
                break;
            }
            scale /= 2.0;
        }
        if !closer {
            break;
        }
    }
    // (Its flow over two periods and five steps from its start: its sound, and whether it swings at all -- an orbit
    // closed on the body at rest, no oscillation, is none.)
    map.load(&x);
    let mut flows = Vec::new();
    map.step((2.0 * t).ceil() as usize + 5, Some(&mut flows))?;
    if still(&rate_x) || swing_of(&flows, rate) < asked.least {
        map.load(&x);
        return Ok(Found { sounds: false, why: Some("its oscillation dies away at the row: it comes to rest".into()), newton, maps: map.maps, ..Found::default() });
    }
    let mut found = Found { sounds: true, steps: t, hz: rate / t, closing, closings, linear, newton, flows, ..Found::default() };
    // (Its multipliers: Arnoldi's method on the map's derivative about the orbit, its own motion -- the direction the
    // state moves along it, whose multiplier is 1 -- set apart, so that those left are the others.)
    let own: Vec<f64> = {
        let n = norm(&rate_x);
        rate_x.iter().map(|v| v / n).collect()
    };
    if asked.multipliers > 0 {
        let values = multipliers_of(&mut map, &x, t, &px, &own, asked.multipliers)?;
        found.holds = Some(values.first().is_none_or(|&v| size_of(v) < 1.0));
        found.multipliers = values.iter().take(6).map(|&v| size_of(v)).collect();
        found.values = values.into_iter().take(6).collect();
    }
    // (Its period's move for the row moved to `nudged`: the orbit's derivative along it, solved as Newton's steps are.)
    if let Some(nudged) = asked.nudged {
        let moved_row = row(nudged).repeat(block);
        let own_row = std::mem::replace(&mut map.u, moved_row);
        let own_base = map.rebased(&x).map(|b| std::mem::replace(&mut map.base, b))?;
        let (pn, _) = map.map(&x, t)?;
        map.u = own_row;
        map.base = own_base;
        let mut b: Vec<f64> = pn.iter().zip(&px).map(|(a, c)| -(a - c)).collect();
        b.push(0.0);
        let (step, _) = derivative(&mut map, &x, t, &px, &rate_x, &own, b, RATED)?;
        found.moved = Some(step[x.len()]);
    }
    // (Its level; and for each move asked, the orbit's derivative along it -- its state's move and its period's -- and its
    // level read again from its state so moved, over its period so moved, at its controls so moved: the map at its
    // controls so moved that row's own (Map::rebased).)
    found.level = level_of(&found.flows, t, rate);
    if !moved.is_empty() {
        let own_row = map.u.clone();
        let own_tract = map.player.tract.as_ref().map(|tr| tr.now());
        let own_pulls = map.player.pulls();
        let own_base = map.base.clone();
        // (The directions each move's solve takes, kept for the next: one orbit, one derivative.)
        let mut kept = Kept::default();
        let to = |map: &mut Map, mv: &Moved, on: bool| {
            if let Some(r) = &mv.row {
                map.u = if on { row(r).repeat(block) } else { own_row.clone() };
            }
            if let (Some(rs), Some(base), Some(tr)) = (&mv.tract, &own_tract, map.player.tract.as_mut()) {
                tr.set(if on { rs.clone() } else { base.clone() }, 0.0);
            }
            // (Its joints pulled: the coefficients the pull changes put in the map's base, which its state is loaded on.)
            if let Some(p) = &mv.pulls {
                pulled_base(map, if on { p } else { &own_pulls });
            }
            // (Its body remade: the coefficients its remaking moves put in the map's base.)
            if let Some(cs) = &mv.coefficients {
                for &(k, v) in cs {
                    map.base[k] = if on { v } else { own_base[k] };
                }
            }
        };
        for mv in moved {
            to(&mut map, mv, true);
            map.base = map.rebased(&x)?;
            let (pn, _) = map.map(&x, t)?;
            let moved_base = std::mem::replace(&mut map.base, own_base.clone());
            to(&mut map, mv, false);
            let mut b: Vec<f64> = pn.iter().zip(&px).map(|(a, c)| -(a - c)).collect();
            b.push(0.0);
            let (step, residual) = derivative_kept(&mut map, &x, t, &px, &rate_x, &own, b, RATED, Some(&mut kept))?;
            let m = x.len();
            let (xm, tm): (Vec<f64>, f64) = (x.iter().zip(&step[..m]).map(|(a, d)| a + d).collect(), t + step[m]);
            to(&mut map, mv, true);
            map.base = moved_base;
            map.load(&xm);
            let mut f = Vec::new();
            let stepped = map.step(tm.floor() as usize + 3, Some(&mut f));
            map.base = own_base.clone();
            to(&mut map, mv, false);
            stepped?;
            found.rates.push(Rate { steps: step[m], level: level_of(&f, tm, rate) - found.level, residual });
        }
    }
    found.maps = map.maps;
    // (The player left at the orbit's state, where it begins.)
    map.load(&x);
    Ok(found)
}

/// The map's derivative's `count` largest eigenvalues about the orbit `x` over `t` (its map there `px`), its own motion `own`
/// -- the direction the state moves along it, whose multiplier is 1 -- set apart: Arnoldi's method, the largest first,
/// each its real and imaginary parts.
fn multipliers_of(map: &mut Map, x: &[f64], t: f64, px: &[f64], own: &[f64], count: usize) -> Result<Vec<[f64; 2]>, String> {
    let (_, h) = arnoldi(map, x, t, px, own, count)?;
    Ok(sorted_values(h))
}

/// The eigenvalues of the Hessenberg matrix `h`, the largest first.
fn sorted_values(h: Vec<Vec<f64>>) -> Vec<[f64; 2]> {
    let mut values = hessenberg_values(h);
    values.sort_by(|a, b| size_of(*b).partial_cmp(&size_of(*a)).unwrap_or(std::cmp::Ordering::Equal));
    values
}

/// The map's derivative about the orbit `x` over `t` (its map there `px`), its own motion `own` set apart (multipliers_of),
/// reduced by Arnoldi's method over `count` directions -> those directions, orthonormal, and the upper Hessenberg matrix
/// the derivative is reduced to over them.
fn arnoldi(map: &mut Map, x: &[f64], t: f64, px: &[f64], own: &[f64], count: usize) -> Result<(Vec<Vec<f64>>, Vec<Vec<f64>>), String> {
    let apart = |w: &mut Vec<f64>| {
        let c = dot(w, own);
        for (wi, o) in w.iter_mut().zip(own) {
            *wi -= c * o;
        }
    };
    let m = x.len();
    let size = norm(x);
    let start: Vec<f64> = {
        let mut s: Vec<f64> = (0..m).map(|i| ((i * 7919) % 101) as f64 - 50.0).collect();
        apart(&mut s);
        let n = norm(&s);
        s.iter().map(|v| v / n).collect()
    };
    let k = count.min(m);
    let mut v = vec![start];
    let mut h = vec![vec![0.0; k]; k];
    let mut size_k = k;
    for j in 0..k {
        let e = NUDGE * size;
        let moved: Vec<f64> = x.iter().zip(&v[j]).map(|(a, d)| a + e * d).collect();
        let (pm, _) = map.map(&moved, t)?;
        let mut w: Vec<f64> = pm.iter().zip(px).map(|(a, b)| (a - b) / e).collect();
        apart(&mut w);
        for (i, vi) in v.iter().enumerate() {
            let c = dot(&w, vi);
            h[i][j] = c;
            for (wl, x) in w.iter_mut().zip(vi) {
                *wl -= c * x;
            }
        }
        let n = norm(&w);
        if j + 1 < k {
            if n < 1e-12 {
                size_k = j + 1;
                break;
            }
            h[j + 1][j] = n;
            v.push(w.iter().map(|x| x / n).collect());
        }
    }
    let h: Vec<Vec<f64>> = h.into_iter().take(size_k).map(|r| r.into_iter().take(size_k).collect()).collect();
    v.truncate(size_k);
    Ok((v, h))
}

/// A multiplier's size.
fn size_of(v: [f64; 2]) -> f64 {
    v[0].hypot(v[1])
}

// ---- a held note's multipliers held within 1 (research/PLAYER_TRACT_PLAN.md, Proposed 10; the owner, 15 November 2026:
// "Yes, proceed") ----
// A multiplier's rate on each of its player's controls, from the map's derivative's own vector for it: its value moves by
// w^H E v / w^H v for a move E of the derivative (v and w its right and left own vectors), found as the bordered system
// (M - value) dv - v dvalue = -E v, v^H dv = 0 finds it, on the map's own derivative alone -- its left vector never
// formed, since the map is only ever applied, never transposed. E v is the derivative moved with the control: the map's
// derivative about the orbit moved for it, at its row moved, applied to v, either side.

/// The eigenvector of the upper Hessenberg matrix `h` for its eigenvalue `value`, by inverse iteration -- its value moved
/// a billionth of its size off it, so that the solve stands -- as its real parts and its imaginary parts (none where its
/// value is real), its size one; none where it is not found.
fn hessenberg_vector(h: &[Vec<f64>], value: [f64; 2]) -> Option<(Vec<f64>, Vec<f64>)> {
    let k = h.len();
    let complex = value[1] != 0.0;
    let (a, b) = (value[0] + 1e-9 * size_of(value).max(f64::MIN_POSITIVE), value[1]);
    let n = if complex { 2 * k } else { k };
    // (Its value's complex system in real form: [[H - a, b], [-b, H - a]] on its real and imaginary parts.)
    let matrix = || {
        let mut m = vec![vec![0.0; n]; n];
        for i in 0..k {
            for j in 0..k {
                m[i][j] = h[i][j];
                if complex {
                    m[k + i][k + j] = h[i][j];
                }
            }
            m[i][i] -= a;
            if complex {
                m[k + i][k + i] -= a;
                m[i][k + i] = b;
                m[k + i][i] = -b;
            }
        }
        m
    };
    let mut y: Vec<f64> = (0..n).map(|i| 1.0 + (i % 7) as f64 / 7.0).collect();
    for _ in 0..3 {
        y = solve(&mut matrix(), &mut y)?;
        let size = norm(&y);
        if !(size > 0.0 && size.is_finite()) {
            return None;
        }
        y.iter_mut().for_each(|v| *v /= size);
    }
    Some(if complex { (y[..k].to_vec(), y[k..].to_vec()) } else { (y, Vec::new()) })
}

/// The map's derivative about the state `y` over `t` applied to `p` and to `q` (none where `q` is empty), each by the map
/// from `y` moved along it, against the map from `y` (`py`, read where none is given).
fn applied_at(map: &mut Map, y: &[f64], t: f64, py: Option<&[f64]>, p: &[f64], q: &[f64]) -> Result<(Vec<f64>, Vec<f64>), String> {
    let own;
    let py = match py {
        Some(py) => py,
        None => {
            own = map.map(y, t)?.0;
            &own
        }
    };
    let size = norm(y);
    let mut along = |d: &[f64]| -> Result<Vec<f64>, String> {
        let dn = norm(d);
        if dn == 0.0 {
            return Ok(vec![0.0; d.len()]);
        }
        let e = NUDGE * size / dn;
        let moved: Vec<f64> = y.iter().zip(d).map(|(a, b)| a + e * b).collect();
        let (pm, _) = map.map(&moved, t)?;
        Ok(pm.iter().zip(py).map(|(a, b)| (a - b) / e).collect())
    };
    Ok((along(p)?, if q.is_empty() { Vec::new() } else { along(q)? }))
}

/// The map's derivative's own vector for its multiplier `value` about the orbit `x` over `t` (its map there `px`, its
/// own motion `own`), from Arnoldi's directions `basis` and matrix `h` about it: the matrix's own vector carried into the
/// state's directions -- an own vector of the derivative with its own motion set apart, P M, P taking out `own` -- and its
/// share along its own motion put back, that it be the derivative's own (M v = value v: v + a own, a = own^T M v / (value
/// - 1)) -> its real parts and its imaginary parts (none where its value is real), its size one.
#[allow(clippy::too_many_arguments)]
fn own_vector(map: &mut Map, x: &[f64], t: f64, px: &[f64], own: &[f64], basis: &[Vec<f64>], h: &[Vec<f64>], value: [f64; 2]) -> Result<(Vec<f64>, Vec<f64>), String> {
    let (yr, yi) = hessenberg_vector(h, value).ok_or("its multiplier's own vector: its matrix's not found")?;
    let m = x.len();
    let carried = |y: &[f64]| {
        let mut v = vec![0.0; m];
        for (c, d) in y.iter().zip(basis) {
            for (vi, di) in v.iter_mut().zip(d) {
                *vi += c * di;
            }
        }
        v
    };
    let (mut p, mut q) = (carried(&yr), if yi.is_empty() { Vec::new() } else { carried(&yi) });
    let (mp, mq) = applied_at(map, x, t, Some(px), &p, &q)?;
    let (br, bi) = (dot(own, &mp), if q.is_empty() { 0.0 } else { dot(own, &mq) });
    let (dr, di) = (value[0] - 1.0, value[1]);
    let d2 = dr * dr + di * di;
    let (ar, ai) = ((br * dr + bi * di) / d2, (bi * dr - br * di) / d2);
    for (pi, o) in p.iter_mut().zip(own) {
        *pi += ar * o;
    }
    if !q.is_empty() {
        for (qi, o) in q.iter_mut().zip(own) {
            *qi += ai * o;
        }
    }
    let size = (dot(&p, &p) + dot(&q, &q)).sqrt();
    p.iter_mut().for_each(|v| *v /= size);
    q.iter_mut().for_each(|v| *v /= size);
    Ok((p, q))
}

/// Its multiplier `value`'s move for each move of the map's derivative `moved` (each E v, its real and its imaginary
/// parts), about the orbit `x` over `t` (its map there `px`), its own vector `v` (own_vector): the bordered system above,
/// each solved by gcr_kept to `tolerance` on the same operator, the directions of one kept for the next -> each move
/// (real, imaginary), and each solve's residual.
#[allow(clippy::too_many_arguments)]
fn multiplier_moves(map: &mut Map, x: &[f64], t: f64, px: &[f64], value: [f64; 2], v: &(Vec<f64>, Vec<f64>), moved: &[(Vec<f64>, Vec<f64>)], tolerance: f64) -> Result<(Vec<[f64; 2]>, Vec<f64>), String> {
    let m = x.len();
    let (p, q) = (&v.0, &v.1);
    let complex = !q.is_empty();
    let [a, b] = value;
    let n = if complex { 2 * m + 2 } else { m + 1 };
    let mut kept = Kept::default();
    let (mut out, mut residuals) = (Vec::with_capacity(moved.len()), Vec::with_capacity(moved.len()));
    for (ep, eq) in moved {
        let mut right = vec![0.0; n];
        for i in 0..m {
            right[i] = -ep[i];
            if complex {
                right[m + i] = -eq[i];
            }
        }
        let apply = |u: &[f64]| -> Result<Vec<f64>, String> {
            let mut out = vec![0.0; n];
            if complex {
                let (dp, dq, da, db) = (&u[..m], &u[m..2 * m], u[2 * m], u[2 * m + 1]);
                let (mdp, mdq) = applied_at(map, x, t, Some(px), dp, dq)?;
                for i in 0..m {
                    out[i] = mdp[i] - a * dp[i] + b * dq[i] - p[i] * da + q[i] * db;
                    out[m + i] = mdq[i] - a * dq[i] - b * dp[i] - q[i] * da - p[i] * db;
                }
                out[2 * m] = dot(p, dp) + dot(q, dq);
                out[2 * m + 1] = dot(p, dq) - dot(q, dp);
            } else {
                let (dp, da) = (&u[..m], u[m]);
                let (mdp, _) = applied_at(map, x, t, Some(px), dp, &[])?;
                for i in 0..m {
                    out[i] = mdp[i] - a * dp[i] - p[i] * da;
                }
                out[m] = dot(p, dp);
            }
            Ok(out)
        };
        let (solution, residual) = gcr_kept(&right, tolerance, &mut kept, apply)?;
        out.push(if complex { [solution[2 * m], solution[2 * m + 1]] } else { [solution[m], 0.0] });
        residuals.push(residual);
    }
    Ok((out, residuals))
}

/// The map made ready from its player's state now, its period `t` (steps) known: its joints' read flows, its orbit begun
/// where its reed is open, and its state's every double that moves over a period, each scaled by its size over it, each
/// one's own settling, the rest of its doubles held (Map's base) -- as `solved` makes it ready, and `tune` each step.
fn prepare(map: &mut Map, t: f64) -> Result<(), String> {
    map.joints = map.player.joints().into_iter().map(|(at, step)| {
        let k = at.len();
        (at, read_by(&step, k))
    }).collect();
    // (Begun where its reed is open: its contact variable, held out of the state below, still there -- the middle of the
    // longest run of steps over a period that leave it as it was -- so that holding it is exact over the reed's open
    // part of its period, and the orbit moved or the row moved keeps it as the note has it where it last touched. Begun
    // where the reed touches its lay, held there while the note's own changes, its rates read a breath's level 4% from
    // the held notes either side and moved with where in its period the orbit was begun.)
    let held = map.player.contact_variables();
    if !held.is_empty() {
        let steps = t.ceil() as usize;
        let at = |map: &mut Map| held.iter().map(|&k| map.player.data()[k]).collect::<Vec<f64>>();
        let mut still = Vec::with_capacity(steps);
        let mut was = at(map);
        for _ in 0..steps {
            map.step(1, None)?;
            let now = at(map);
            still.push(now == was);
            was = now;
        }
        // (Its longest run, around the period's end too.)
        let (mut longest, mut from, mut run) = ((0, 0), 0, 0);
        for k in 0..2 * steps {
            if still[k % steps] {
                if run == 0 {
                    from = k;
                }
                run += 1;
                if run > longest.1 && run <= steps {
                    longest = (from, run);
                }
            } else {
                run = 0;
            }
        }
        if longest.1 > 0 {
            map.step((longest.0 + longest.1 / 2) % steps, None)?;
        }
    }
    let start = map.player.data().to_vec();
    let mut moving = start.clone();
    let tracted = map.tracted();
    let (mut low, mut high) = (start.clone(), start.clone());
    let mut tract_size = vec![0.0f64; tracted];
    let samples = 16;
    for _ in 0..samples {
        map.step((t / samples as f64).ceil() as usize, None)?;
        moving.copy_from_slice(map.player.data());
        for (k, &v) in moving.iter().enumerate() {
            low[k] = low[k].min(v);
            high[k] = high[k].max(v);
        }
        if let Some(tr) = &map.player.tract {
            for (s, v) in tract_size.iter_mut().zip(tr.state()) {
                *s = s.max(v.abs());
            }
        }
    }
    // (Its reed's contact variable held where the note has it, out of the state: it drifts from touch to touch, some 5e-5
    // of itself a period at the clarinet's G4, and its drift, closed, would move it without end.)
    map.mask = (0..start.len()).filter(|&k| high[k] > low[k] && !held.contains(&k)).collect();
    // (Each value scaled by its size over the period; a bore's field's every value by that field's largest, so that a
    // node nearly still -- by a node of its standing wave -- is nudged as far as its field's others, its derivative not
    // lost in their rounding.)
    let mut size: Vec<f64> = low.iter().zip(&high).map(|(a, b)| a.abs().max(b.abs())).collect();
    for (from, len) in map.player.fields() {
        let largest = size[from..from + len].iter().copied().fold(0.0, f64::max);
        size[from..from + len].fill(largest);
    }
    if let (Some((from, len)), joints) = map.player.flows() {
        let largest = size[from..from + len].iter().copied().fold(0.0, f64::max);
        for k in joints {
            size[k] = largest;
        }
    }
    map.scale = map.mask.iter().map(|&k| size[k]).chain(tract_size.iter().map(|s| s.max(f64::MIN_POSITIVE))).collect();
    map.base = map.player.data().to_vec();
    let mut own_kept = vec![0.0; start.len()];
    for (k, r) in map.player.settling() {
        own_kept[k] = r;
    }
    map.kept = map.mask.iter().map(|&k| own_kept[k]).chain(std::iter::repeat_n(0.0, tracted)).collect();
    Ok(())
}

// ---- a held note tuned: its orbit and its player's controls solved together ----
// (The owner, 9 November 2026: "The solver needs to solve"; design approved: "Yes, build that, and ABSOLUTELY NO BRUTE
// FORCE".) Newton's method on the note's state over a period and its player's controls at once: its period fixed at the
// pitch asked, its level the level asked, its motion repeating on the engine's own one-period map. Each step the least
// move of its controls, each over its span, that its derivatives say meets both, and the orbit's move with it, solved
// from the same derivative as the orbit's own (`derivative`): the orbit's step at the controls where they stand, and its
// move for each control moved either side, so that the two together are one step of Newton's method on all of them. No
// step is tried and taken back; a control its step would take past its player's reach is held at its reach and the
// others solved for, and where too few are left for both, its level is left free -- the note held in tune as loud or as
// soft as its reach allows. Where its note at the controls where they stand is already within what is asked, no step is
// taken: its rates read there more closely (RATED), and its multipliers.
/// One step asked of a held note's tuning (tune): the row at its player's controls now and its tract's resonances there
/// (the stream sets them), and for each control its rows -- or its tract's resonances -- a move `moves` either side
/// ([up, down]), where it stands (`at`, in the units of its move), its span (the least move weighs each control's move
/// over it) and its reach ([least, most], either none); the pitch of the orbit it begins from (Hz), and the pitch (Hz)
/// and the level (dB; none: its level free) asked, within `cents` and `decibels`; the pitch (Hz) and level (dB) its
/// path ends at, where the pitch and level asked are a point on one (its tangent toward them read where tuned); the
/// pitch (Hz) and level (dB) its path's share is counted from (`anchor_hz`, `anchor_level`: the point on it closed last)
/// and the weight of a share of its way against its controls' moves (`share_weight`: the least move's for a span of
/// each), where its step solves for the share of its path its note is closed at too -- none: closed where asked;
/// `stay`: its note read where its controls stand and no step taken, its player left at its orbit there; and so many
/// multipliers where its note is tuned.
#[derive(serde::Deserialize, Clone, Debug, Default)]
pub struct Tune {
    pub row: Vec<f64>,
    #[serde(default)]
    pub tract: Option<Vec<crate::tract::Resonance>>,
    pub moved: Vec<[Moved; 2]>,
    pub moves: Vec<f64>,
    pub at: Vec<f64>,
    pub spans: Vec<f64>,
    #[serde(default)]
    pub reach: Vec<[Option<f64>; 2]>,
    pub from_hz: f64,
    pub hz: f64,
    #[serde(default)]
    pub level: Option<f64>,
    pub cents: f64,
    pub decibels: f64,
    #[serde(default)]
    pub goal_hz: Option<f64>,
    #[serde(default)]
    pub goal_level: Option<f64>,
    #[serde(default)]
    pub anchor_hz: Option<f64>,
    #[serde(default)]
    pub anchor_level: Option<f64>,
    #[serde(default)]
    pub share_weight: f64,
    #[serde(default)]
    pub stay: bool,
    #[serde(default)]
    pub multipliers: usize,
    /// Where given (with `multipliers`), its multipliers held within 1: read at its orbit at its controls now, and one
    /// past 1 there, or that its step would take past 1, held at this size, as a control is held at its reach; and the
    /// tangent keeps one standing within `holding_near` of it from growing. `held`: the multipliers held at the point
    /// before (their values there), each followed to its nearest here.
    #[serde(default)]
    pub holding: Option<f64>,
    #[serde(default)]
    pub holding_near: f64,
    #[serde(default)]
    pub held: Vec<[f64; 2]>,
}

/// A multiplier followed where a held note's multipliers are held within 1: its value and its size; its size's rate for
/// a move of one unit of each control; whether its step holds it, and whether its tangent does; and its rates' solves'
/// largest residual.
#[derive(Debug, Clone, Default, serde::Serialize)]
pub struct Watched {
    pub value: [f64; 2],
    pub size: f64,
    pub rates: Vec<f64>,
    pub held: bool,
    pub tangent_held: bool,
    pub residual: f64,
}

/// A step of a held note's tuning: whether its note sounds at its controls now, and there its pitch (Hz) and its level
/// (dB) -- its orbit closed by Newton's step at those controls -- how far they stand from what is asked (cents, dB), and
/// how closed the orbit it began from was; whether that is within what is asked (`tuned`: no step taken); each control's
/// rates there ([cents, dB] for a move of one of its units); the step taken -- each control's move, those held at their
/// reach, whether its level was left free, the pitch its orbit is moved to (Hz) and the level its rates say it reaches
/// -- and each linear solve's residual against its right side, and the map's evaluations; its multipliers' sizes where
/// tuned and asked, and whether it holds; the share of its path the step moves its aim by, where asked to solve for it;
/// and where tuned on a path, its tangent toward the path's end (each control's move for the whole way there, those
/// held at their reach, and whether its level is left free), and where as many controls are left as it follows, the
/// determinant of their rates (`tangent_turn`): its sign turns where its path does.
#[derive(Debug, Clone, Default, serde::Serialize)]
pub struct Tuned {
    pub sounds: bool,
    pub why: Option<String>,
    pub hz: f64,
    pub level: f64,
    pub cents: f64,
    pub off: f64,
    pub closing: f64,
    pub tuned: bool,
    pub rates: Vec<[f64; 2]>,
    pub step: Vec<f64>,
    pub pinned: Vec<bool>,
    pub level_free: bool,
    pub next_hz: f64,
    pub next_level: f64,
    pub residuals: Vec<f64>,
    pub maps: usize,
    pub multipliers: Vec<f64>,
    /// The same multipliers, each its real and imaginary parts.
    pub values: Vec<[f64; 2]>,
    pub holds: Option<bool>,
    /// Where its multipliers are held within 1, those followed.
    #[serde(skip_serializing_if = "Vec::is_empty")]
    pub watched: Vec<Watched>,
    pub tangent: Vec<f64>,
    pub tangent_pinned: Vec<bool>,
    pub tangent_free: bool,
    pub step_share: f64,
    pub tangent_turn: Option<f64>,
}

/// One step of a held note's tuning (above), from its player's state now (an orbit found or stepped to before, at the
/// row asked) -> what it found; the player left at the orbit stepped to -- or, where tuned, at its orbit at its controls
/// now -- for the next step to begin from (the caller keeps its own state and puts it back). `least`: the least swing of
/// its sound that is one (Asked::least). A bore played in singles solved in doubles, as its orbits are.
pub fn tune(player: &mut Player, cols: usize, outs: usize, rate: f64, asked: &Tune, least: f64) -> Result<Tuned, String> {
    let single = player.single() && !player.crewed();
    if single {
        player.in_doubles(true);
    }
    let found = tuning(player, cols, outs, rate, asked, least);
    if single {
        player.in_doubles(false);
    }
    found
}

/// The level of the sound from the state `x` (scaled) over `t` steps at the map's row, and its swing.
fn level_at(map: &mut Map, x: &[f64], t: f64, rate: f64) -> Result<(f64, f64), String> {
    map.load(x);
    let mut f = Vec::new();
    map.step(t.floor() as usize + 3, Some(&mut f))?;
    Ok((level_of(&f, t, rate), swing_of(&f, rate)))
}

/// The least move `d` (each control's over its span, `w` their squares), of the controls `free`, that moves the
/// conditions `g` (each a control's rate) by `r`: d = W G^T (G W G^T)^-1 r -> each free control's move, or none where its
/// controls do not move them apart (a condition's rates, the part of them those before it leave, under a millionth of
/// their own size).
fn least_move(g: &[&[f64]], r: &[f64], w: &[f64], free: &[usize]) -> Option<Vec<f64>> {
    let n = g.len();
    let a = |i: usize, k: usize| free.iter().map(|&j| g[i][j] * w[j] * g[k][j]).sum::<f64>();
    let gram: Vec<Vec<f64>> = (0..n).map(|i| (0..n).map(|k| a(i, k)).collect()).collect();
    let mut l = vec![vec![0.0; n]; n];
    for i in 0..n {
        for k in 0..=i {
            let s = gram[i][k] - (0..k).map(|q| l[i][q] * l[k][q]).sum::<f64>();
            if i == k {
                if !(gram[i][i] > 0.0 && s > 1e-12 * gram[i][i]) {
                    return None;
                }
                l[i][i] = s.sqrt();
            } else {
                l[i][k] = s / l[k][k];
            }
        }
    }
    let y = backward_solved(&l, &forward_solved(&l, r));
    Some(free.iter().map(|&j| w[j] * (0..n).map(|i| g[i][j] * y[i]).sum::<f64>()).collect())
}

/// The determinant of the square matrix `m` (rows), by elimination with its largest pivot.
fn determinant(mut m: Vec<Vec<f64>>) -> f64 {
    let n = m.len();
    let mut det = 1.0;
    for col in 0..n {
        let Some(p) = (col..n).max_by(|&i, &j| m[i][col].abs().total_cmp(&m[j][col].abs())) else {
            return 0.0;
        };
        if m[p][col] == 0.0 {
            return 0.0;
        }
        if p != col {
            m.swap(col, p);
            det = -det;
        }
        det *= m[col][col];
        for row in col + 1..n {
            let f = m[row][col] / m[col][col];
            for c in col..n {
                m[row][c] -= f * m[col][c];
            }
        }
    }
    det
}

/// A held note's path's tangent at its note tuned on it (`g_t`, `g_l`: each control's rate on its period, steps, and its
/// level, dB; `t_here`, `level`: its period and level there): the least move of its controls, each over its span, that
/// its rates say takes its note the whole way to the path's end, a control at its reach that the move would take past it
/// held there and the rest solved for again; where too few are left for both its pitch and its level, or its controls
/// no longer move them apart, its level left free. Each multiplier followed (`watched`) that stands within
/// `asked.holding_near` of the size it is held at and that the move would grow, held where it stands, as a control at its
/// reach. -> each control's move (none for those held), those held, whether its level is left free, the determinant of
/// its rates where as many controls are left as it follows, and the multipliers it holds; or why none.
fn toward(g_t: &[f64], g_l: &[f64], asked: &Tune, rate: f64, t_here: f64, level: f64, watched: &[Watched]) -> Result<Tangent, String> {
    let k = asked.at.len();
    let t_goal = rate / asked.goal_hz.ok_or("its path's end")?;
    let w: Vec<f64> = asked.spans.iter().map(|s| s * s).collect();
    // (At its reach, within a millionth of its span, and moved past it.)
    let past = |j: usize, d: f64| {
        let [low, high] = asked.reach.get(j).copied().unwrap_or([None, None]);
        let near = 1e-6 * asked.spans[j];
        (d < 0.0 && low.is_some_and(|l| asked.at[j] - l <= near)) || (d > 0.0 && high.is_some_and(|h| h - asked.at[j] <= near))
    };
    let edge = asked.holding.map(|h| h - asked.holding_near);
    let at_edge = |m: &Watched| edge.is_some_and(|e| m.size >= e);
    let (mut held, mut level_free) = (vec![false; k], asked.level.is_none() || asked.goal_level.is_none());
    let mut kept = vec![false; watched.len()];
    loop {
        let free: Vec<usize> = (0..k).filter(|&j| !held[j]).collect();
        let (mut g, mut r): (Vec<&[f64]>, Vec<f64>) = (vec![g_t], vec![t_goal - t_here]);
        if !level_free {
            g.push(g_l);
            r.push(asked.goal_level.unwrap_or(level) - level);
        }
        for (m, _) in watched.iter().zip(&kept).filter(|(_, &on)| on) {
            g.push(&m.rates);
            r.push(0.0);
        }
        if free.len() < g.len() {
            if !level_free {
                level_free = true;
                continue;
            }
            return Err(if kept.contains(&true) { "its multiplier held within 1, no control left within its reach to move its pitch along its path" } else { "no control left within its reach to move its pitch along its path" }.into());
        }
        let Some(d) = least_move(&g, &r, &w, &free) else {
            if !level_free {
                level_free = true;
                continue;
            }
            return Err(if kept.contains(&true) { "its multiplier held within 1, its controls within their reach no longer move its pitch: its path turns back here" } else { "its controls within their reach no longer move its pitch: its path turns back here" }.into());
        };
        let mut pushed = false;
        for (&j, &dj) in free.iter().zip(&d) {
            if past(j, dj) {
                held[j] = true;
                pushed = true;
            }
        }
        if pushed {
            continue;
        }
        let mut all = vec![0.0; k];
        for (&j, &dj) in free.iter().zip(&d) {
            all[j] = dj;
        }
        for (i, m) in watched.iter().enumerate() {
            if !kept[i] && at_edge(m) && dot(&m.rates, &all) > 0.0 {
                kept[i] = true;
                pushed = true;
            }
        }
        if pushed {
            continue;
        }
        // (As many controls left as it follows: their rates' determinant, its controls in their order.)
        let turn = (free.len() == g.len()).then(|| determinant(g.iter().map(|row| free.iter().map(|&j| row[j]).collect()).collect()));
        return Ok(Tangent { d: all, pinned: held, level_free, turn, kept });
    }
}

/// A held note's path's tangent (toward).
struct Tangent {
    d: Vec<f64>,
    pinned: Vec<bool>,
    level_free: bool,
    turn: Option<f64>,
    kept: Vec<bool>,
}

fn tuning(player: &mut Player, cols: usize, outs: usize, rate: f64, asked: &Tune, least: f64) -> Result<Tuned, String> {
    if player.crewed() {
        return Err("its orbit is found on one core: a dial of one thread (--threads 1)".into());
    }
    if player.ringed() {
        return Err("a jet's orbit is not yet found: its flows are kept in a ring, not yet read in its order".into());
    }
    let k = asked.at.len();
    let sized = |v: usize| v == k;
    if asked.row.len() != cols || !sized(asked.moved.len()) || !sized(asked.moves.len()) || !sized(asked.spans.len()) || !(asked.reach.is_empty() || sized(asked.reach.len()))
        || asked.moved.iter().flatten().any(|m| m.row.as_ref().is_some_and(|r| r.len() != cols)) || k == 0 {
        return Err(format!("its row its body's {cols} columns, and for each of its controls its moves either side, its move, its span and its reach"));
    }
    if asked.moved.iter().flatten().any(|m| m.pulls.is_some()) {
        return Err("its joints are tuned by `points` (orbit.rs pull_points), not as a player's control".into());
    }
    if !(asked.from_hz > 0.0 && asked.hz > 0.0 && asked.moves.iter().all(|&m| m > 0.0)) {
        return Err("the pitch it begins at, the pitch asked, and each control's move".into());
    }
    let block = 2 * (rate / PITCHES[1]).ceil() as usize + 8;
    let mut map = Map { player, u: asked.row.repeat(block), y: vec![0.0; block * outs], cols, outs, base: vec![], mask: vec![], scale: vec![], kept: vec![], joints: vec![], maps: 0 };
    if let Some(t) = map.player.tract.as_mut() {
        t.settle();
    }
    let (t, target) = (rate / asked.from_hz, rate / asked.hz);
    prepare(&mut map, t)?;
    let x = map.read();
    let m = x.len();
    let mut flows = Vec::new();
    let (px, rate_x) = map.mapped(&x, t, Some(&mut flows))?;
    let still = |r: &[f64]| norm(r) == 0.0 || !norm(r).is_finite();
    let silent = |why: &str, maps: usize| Ok(Tuned { sounds: false, why: Some(why.into()), maps, ..Tuned::default() });
    if still(&rate_x) || swing_of(&flows, rate) < least {
        return silent("its oscillation dies away at its controls: it comes to rest", map.maps);
    }
    let f: Vec<f64> = px.iter().zip(&x).map(|(a, b)| a - b).collect();
    let closing = norm(&f) / norm(&x);
    let own: Vec<f64> = {
        let n = norm(&rate_x);
        rate_x.iter().map(|v| v / n).collect()
    };
    // (Its note at its controls now: the orbit's own step there, on its state and its period alone. Each of its solves to
    // RATED: the note's slowest motion, its largest multiplier near one, makes a solve's error its residual's several
    // hundredfold -- read to LINEAR, the clarinet's breath's rate on its pitch moved from -39 to -2 cents across a move of
    // its lip of 2e-4 N -- and Newton's step is only as good as its rates.)
    let mut b: Vec<f64> = f.iter().map(|v| -v).collect();
    b.push(0.0);
    let (z0, r0) = derivative(&mut map, &x, t, &px, &rate_x, &own, b, RATED)?;
    let here: Vec<f64> = x.iter().zip(&z0[..m]).map(|(a, d)| a + d).collect();
    let t_here = t + z0[m];
    let (level, swing) = level_at(&mut map, &here, t_here, rate)?;
    if !(t_here > 0.0) || swing < least {
        return silent("its oscillation dies away at its controls: its orbit there comes to rest", map.maps);
    }
    let cents = 1200.0 * (target / t_here).log2();
    let off = asked.level.map_or(0.0, |l| level - l);
    // (Its orbit's own step at its controls moving its pitch and its level by no more than what is asked, so that their
    // readings after it, at `here`, stand within the linear solve's share of that: its orbit as closed as its note needs.
    // Its closing itself is no measure of it: each step's orbit is begun from the engine stepped on from the last's and
    // aligned where its reed is open, and the period's map read there, a period of steps not a whole number of them,
    // closes a few millionths apart from where it closes begun elsewhere.)
    let (level_x, _) = level_at(&mut map, &x, t, rate)?;
    let settled = (1200.0 * (t / t_here).log2()).abs() <= asked.cents && (level - level_x).abs() <= asked.decibels;
    let tuned = settled && cents.abs() <= asked.cents && off.abs() <= asked.decibels;
    let mut out = Tuned { sounds: true, hz: rate / t_here, level, cents, off, closing, tuned, residuals: vec![r0], ..Tuned::default() };
    // (Each control's move either side: the map's move for it at the orbit's state, each at its row's own base
    // (Map::rebased), and the orbit's move for it; its level read at the orbit so moved, at the controls so moved.)
    let own_row = map.u.clone();
    let own_tract = map.player.tract.as_ref().map(|tr| tr.now());
    let own_base = map.base.clone();
    let to = |map: &mut Map, mv: &Moved, on: bool| {
        if let Some(r) = &mv.row {
            map.u = if on { r.repeat(block) } else { own_row.clone() };
        }
        if let (Some(rs), Some(base), Some(tr)) = (&mv.tract, &own_tract, map.player.tract.as_mut()) {
            tr.set(if on { rs.clone() } else { base.clone() }, 0.0);
        }
    };
    let (mut moved_orbits, mut g_t, mut g_l) = (Vec::with_capacity(k), vec![0.0; k], vec![0.0; k]);
    for (j, sides) in asked.moved.iter().enumerate() {
        let mut maps = Vec::with_capacity(2);
        let mut bases = Vec::with_capacity(2);
        for mv in sides {
            to(&mut map, mv, true);
            map.base = map.rebased(&x)?;
            let (p, _) = map.map(&x, t)?;
            bases.push(std::mem::replace(&mut map.base, own_base.clone()));
            to(&mut map, mv, false);
            maps.push(p);
        }
        let mut b: Vec<f64> = maps[0].iter().zip(&maps[1]).map(|(u, d)| -(u - d) / 2.0).collect();
        b.push(0.0);
        let (z, residual) = derivative(&mut map, &x, t, &px, &rate_x, &own, b, RATED)?;
        out.residuals.push(residual);
        let mut levels = [0.0; 2];
        for (s, (mv, base)) in sides.iter().zip(bases).enumerate() {
            let sign = if s == 0 { 1.0 } else { -1.0 };
            let xm: Vec<f64> = x.iter().zip(&z[..m]).map(|(a, d)| a + sign * d).collect();
            to(&mut map, mv, true);
            map.base = base;
            let read = level_at(&mut map, &xm, t + sign * z[m], rate);
            map.base = own_base.clone();
            to(&mut map, mv, false);
            levels[s] = read?.0;
        }
        g_t[j] = z[m] / asked.moves[j];
        g_l[j] = (levels[0] - levels[1]) / 2.0 / asked.moves[j];
        out.rates.push([-1200.0 * ((t + z[m]) / (t - z[m])).log2() / (2.0 * asked.moves[j]), g_l[j]]);
        moved_orbits.push(z);
    }
    // (Its multipliers at its orbit at its controls now, where they are held within 1 (Proposed 10): Arnoldi's method
    // about it; and those it follows -- each past 1 there, and each nearest one held at the point before -- each one's
    // size's rate for each control, from its own vector (the bordered system: multiplier_moves) and the map's derivative
    // moved with the control, about the orbit moved for it at its row moved, either side.)
    let holding = asked.holding.filter(|_| asked.multipliers > 0);
    let mut read_here = false;
    if holding.is_some() {
        map.load(&here);
        let (p_here, r_here) = map.map(&here, t_here)?;
        let own_here: Vec<f64> = {
            let n = norm(&r_here);
            r_here.iter().map(|v| v / n).collect()
        };
        let (basis, h) = arnoldi(&mut map, &here, t_here, &p_here, &own_here, asked.multipliers)?;
        let values = sorted_values(h.clone());
        out.holds = Some(values.first().is_none_or(|&v| size_of(v) < 1.0));
        out.multipliers = values.iter().take(6).map(|&v| size_of(v)).collect();
        out.values = values.iter().take(6).copied().collect();
        read_here = true;
        // (One of each pair: its imaginary part not below nothing.)
        let ones: Vec<[f64; 2]> = values.iter().copied().filter(|v| v[1] >= 0.0).collect();
        let mut followed: Vec<[f64; 2]> = ones.iter().copied().filter(|&v| size_of(v) >= 1.0).collect();
        for &was in &asked.held {
            let apart = |v: [f64; 2]| (v[0] - was[0]).hypot(v[1] - was[1].abs());
            if let Some(&near) = ones.iter().min_by(|a, b| apart(**a).total_cmp(&apart(**b))) {
                if !followed.contains(&near) {
                    followed.push(near);
                }
            }
        }
        for value in followed {
            let v = own_vector(&mut map, &here, t_here, &p_here, &own_here, &basis, &h, value)?;
            let mut moved_by = Vec::with_capacity(k);
            for (j, sides) in asked.moved.iter().enumerate() {
                let z = &moved_orbits[j];
                let mut either: Vec<(Vec<f64>, Vec<f64>)> = Vec::with_capacity(2);
                for (s, mv) in sides.iter().enumerate() {
                    let sign = if s == 0 { 1.0 } else { -1.0 };
                    let ys: Vec<f64> = here.iter().zip(&z[..m]).map(|(a, d)| a + sign * d).collect();
                    to(&mut map, mv, true);
                    let applied = map.rebased(&ys).and_then(|base| {
                        map.base = base;
                        applied_at(&mut map, &ys, t_here + sign * z[m], None, &v.0, &v.1)
                    });
                    map.base = own_base.clone();
                    to(&mut map, mv, false);
                    either.push(applied?);
                }
                let by = 2.0 * asked.moves[j];
                let less = |a: &[f64], b: &[f64]| a.iter().zip(b).map(|(x, y)| (x - y) / by).collect::<Vec<f64>>();
                moved_by.push((less(&either[0].0, &either[1].0), less(&either[0].1, &either[1].1)));
            }
            let (moves, residuals) = multiplier_moves(&mut map, &here, t_here, &p_here, value, &v, &moved_by, MOVED)?;
            let size = size_of(value);
            out.watched.push(Watched {
                value,
                size,
                rates: moves.iter().map(|[da, db]| (value[0] * da + value[1] * db) / size).collect(),
                residual: residuals.iter().copied().fold(0.0, f64::max),
                ..Watched::default()
            });
        }
        map.load(&here);
    }
    // (Where its multipliers are held within 1, its note tuned only where it holds.)
    let tuned = tuned && (holding.is_none() || out.holds == Some(true));
    out.tuned = tuned;
    // (Its note tuned: its multipliers at its orbit there, where asked and not read already, and its player left there.)
    let held = |map: &mut Map, out: &mut Tuned| -> Result<(), String> {
        map.load(&here);
        if asked.multipliers > 0 && !read_here {
            let (p_here, r_here) = map.map(&here, t_here)?;
            let own_here: Vec<f64> = {
                let n = norm(&r_here);
                r_here.iter().map(|v| v / n).collect()
            };
            let values = multipliers_of(map, &here, t_here, &p_here, &own_here, asked.multipliers)?;
            out.holds = Some(values.first().is_none_or(|&v| size_of(v) < 1.0));
            out.multipliers = values.iter().take(6).map(|&v| size_of(v)).collect();
            out.values = values.into_iter().take(6).collect();
        }
        out.maps = map.maps;
        map.load(&here);
        Ok(())
    };
    // (Its path's tangent where it is tuned on one.)
    let along = |out: &mut Tuned| {
        if asked.goal_hz.is_some() {
            match toward(&g_t, &g_l, asked, rate, t_here, level, &out.watched) {
                Ok(tangent) => {
                    for (m, &kept) in out.watched.iter_mut().zip(&tangent.kept) {
                        m.tangent_held = kept;
                    }
                    (out.tangent, out.tangent_pinned, out.tangent_free, out.tangent_turn) = (tangent.d, tangent.pinned, tangent.level_free, tangent.turn);
                }
                Err(why) => out.why = Some(why),
            }
        }
    };
    if tuned {
        along(&mut out);
        held(&mut map, &mut out)?;
        return Ok(out);
    }
    if asked.stay {
        held(&mut map, &mut out)?;
        return Ok(out);
    }
    // (The least move that puts its period at the pitch asked and its level at the level asked, each control within its
    // reach: a control the move would take past it held at it, and the rest solved for again; where too few are left
    // for both, its level left free. On a path, the share of its way it is closed at solved for with them, a share
    // weighed as `share_weight` asks, its pitch and level asked moving with it along the path (Allgower & Georg 1990,
    // Numerical Continuation Methods, Newton's method on the path itself): where a control held at its reach leaves the
    // rest no longer moving its pitch and its level apart, the path turns back at a point before the one asked, and the
    // step closes it on the path there rather than nowhere. A multiplier followed that is past 1, or that the move would
    // take past it, held at `asked.holding` as a control at its reach is, the rest solved for again.)
    let w: Vec<f64> = asked.spans.iter().map(|s| s * s).chain([asked.share_weight]).collect();
    let reach = |j: usize| asked.reach.get(j).copied().unwrap_or([None, None]);
    let sharing = asked.share_weight > 0.0 && asked.anchor_hz.is_some_and(|a| a > 0.0) && asked.goal_hz.is_some();
    let path_t = if sharing { rate / asked.goal_hz.unwrap_or(1.0) - rate / asked.anchor_hz.unwrap_or(1.0) } else { 0.0 };
    let (mut pinned, mut level_free): (Vec<Option<f64>>, bool) = (vec![None; k], asked.level.is_none());
    let mut kept: Vec<bool> = out.watched.iter().map(|m| m.size >= 1.0).collect();
    let rates_on: Vec<Vec<f64>> = out.watched.iter().map(|m| m.rates.iter().copied().chain([0.0]).collect()).collect();
    let step = loop {
        let path_l = match (sharing && !level_free, asked.goal_level, asked.anchor_level) {
            (true, Some(g), Some(a)) => g - a,
            _ => 0.0,
        };
        let g_t_on: Vec<f64> = g_t.iter().copied().chain([-path_t]).collect();
        let g_l_on: Vec<f64> = g_l.iter().copied().chain([-path_l]).collect();
        let free: Vec<usize> = (0..k).filter(|&j| pinned[j].is_none()).collect();
        let held = |g: &[f64]| (0..k).filter_map(|j| pinned[j].map(|d| g[j] * d)).sum::<f64>();
        let (mut g, mut r): (Vec<&[f64]>, Vec<f64>) = (vec![g_t_on.as_slice()], vec![target - t_here - held(&g_t)]);
        if !level_free {
            g.push(g_l_on.as_slice());
            r.push(asked.level.unwrap_or(level) - level - held(&g_l));
        }
        for (i, m) in out.watched.iter().enumerate().filter(|&(i, _)| kept[i]) {
            g.push(rates_on[i].as_slice());
            r.push(holding.unwrap_or(1.0) - m.size - held(&m.rates));
        }
        let holding_one = kept.contains(&true);
        if free.len() < g.len() {
            if !level_free {
                level_free = true;
                continue;
            }
            out.why = Some(if holding_one { "its multiplier held within 1, no control left within its reach to move its pitch" } else { "no control left within its reach to move its pitch" }.into());
            break None;
        }
        let on: Vec<usize> = free.iter().copied().chain(sharing.then_some(k)).collect();
        let Some(d) = least_move(&g, &r, &w, &on) else {
            if !level_free {
                level_free = true;
                continue;
            }
            out.why = Some(if holding_one { "its multiplier held within 1, its controls within their reach do not move its pitch" } else { "its controls within their reach do not move its pitch" }.into());
            break None;
        };
        out.step_share = if sharing { d[free.len()] } else { 0.0 };
        let d = &d[..free.len()];
        let mut past = false;
        for (&j, &dj) in free.iter().zip(d) {
            let [low, high] = reach(j);
            let to = asked.at[j] + dj;
            if let Some(l) = low.filter(|&l| to < l) {
                pinned[j] = Some(l - asked.at[j]);
                past = true;
            } else if let Some(h) = high.filter(|&h| to > h) {
                pinned[j] = Some(h - asked.at[j]);
                past = true;
            }
        }
        if past {
            continue;
        }
        let mut all = vec![0.0; k];
        for (&j, &dj) in free.iter().zip(d) {
            all[j] = dj;
        }
        for j in 0..k {
            if let Some(dj) = pinned[j] {
                all[j] = dj;
            }
        }
        let mut grown = false;
        for (i, m) in out.watched.iter().enumerate() {
            if !kept[i] && m.size + dot(&m.rates, &all) > 1.0 {
                kept[i] = true;
                grown = true;
            }
        }
        if grown {
            continue;
        }
        break Some(all);
    };
    out.pinned = pinned.iter().map(Option::is_some).collect();
    out.level_free = level_free;
    for (m, &on) in out.watched.iter_mut().zip(&kept) {
        m.held = on;
    }
    let Some(step) = step else {
        out.maps = map.maps;
        map.load(&here);
        return Ok(out);
    };
    // (Its note in tune at the end of its reach: its pitch within what is asked and its orbit closed, its level left free
    // because its reach goes no nearer the level asked, and the whole step that remains -- its controls held at their
    // reach -- moving its pitch and its level by no more than what is asked: Newton's step within its tolerance. Not
    // where a multiplier held within 1 is past it.)
    if level_free && settled && cents.abs() <= asked.cents && (holding.is_none() || out.holds == Some(true)) {
        let t_full = t_here + (0..k).map(|j| step[j] / asked.moves[j] * moved_orbits[j][m]).sum::<f64>();
        let level_full: f64 = (0..k).map(|j| g_l[j] * step[j]).sum();
        if (1200.0 * (t_here / t_full).log2()).abs() <= asked.cents && level_full.abs() <= asked.decibels {
            out.tuned = true;
            along(&mut out);
            held(&mut map, &mut out)?;
            return Ok(out);
        }
    }
    // (The step on all of them: the orbit's at its controls now, and its move for each control's.)
    let mut next = here;
    let mut t_next = t_here;
    for (j, z) in moved_orbits.iter().enumerate() {
        let a = step[j] / asked.moves[j];
        for (v, d) in next.iter_mut().zip(&z[..m]) {
            *v += a * d;
        }
        t_next += a * z[m];
    }
    out.next_hz = rate / t_next;
    out.next_level = level + (0..k).map(|j| g_l[j] * step[j]).sum::<f64>();
    out.step = step;
    out.maps = map.maps;
    map.load(&next);
    Ok(out)
}

// ---- a held note's path: how far its next step goes ----
// (The owner, 9 November 2026: "We need to compute the solution, not apply trial and error"; "Ok, continue building".) A
// held note followed along its path -- its pitch and its level moved together from where it sounds to what is asked, its
// controls by the least move that keeps it on them (tune's tangent) -- each step as long as the path's own bend allows:
// the second derivative of its held note's pitch and level along its tangent, read on the engine's one-period map as its
// rates are, so that the step's prediction from its tangent and its bend stands within what is asked of it before
// Newton's method closes it on the path there. Nothing in it depends on where a step before landed.

/// A step along a held note's path asked (bend): the row at its controls now and its tract's resonances there, its rows
/// -- or its tract's resonances -- moved along its tangent either side ([along, against]), that move the share `share`
/// of the tangent's whole way; the most of the way the step may go (`most`: 1 to the path's end, less where a control
/// meets its reach); the pitch of its orbit there (Hz); and how far its prediction may stand from the path: `cents`,
/// and `decibels` where its level is followed (none: its level free).
#[derive(serde::Deserialize, Clone, Debug, Default)]
pub struct Bend {
    pub row: Vec<f64>,
    #[serde(default)]
    pub tract: Option<Vec<crate::tract::Resonance>>,
    pub along: [Moved; 2],
    pub share: f64,
    pub most: f64,
    pub from_hz: f64,
    pub cents: f64,
    #[serde(default)]
    pub decibels: Option<f64>,
}

/// A step along a held note's path: whether its note sounds, the share of the way it goes (`h`); its pitch's first
/// difference along its tangent for the share `share` (cents), and its bend, its pitch's (cents) and its level's (dB)
/// second difference there; the pitch (Hz) and level (dB) its orbit is predicted to there; each linear solve's residual
/// against its right side and its evaluations of the map, and the map's evaluations in all.
#[derive(Debug, Clone, Default, serde::Serialize)]
pub struct Bent {
    pub sounds: bool,
    pub why: Option<String>,
    pub h: f64,
    pub moved_cents: f64,
    pub bend_cents: f64,
    pub bend_level: f64,
    pub hz: f64,
    pub level: f64,
    pub residuals: Vec<f64>,
    pub solves: Vec<usize>,
    pub maps: usize,
}

/// A step along a held note's path (above), from its player's state now (its orbit tuned on the path, at the row asked)
/// -> how far it goes; the player left at the orbit predicted there, for Newton's method to close it on the path. A bore
/// played in singles solved in doubles, as its orbits are.
pub fn bend(player: &mut Player, cols: usize, outs: usize, rate: f64, asked: &Bend, least: f64) -> Result<Bent, String> {
    let single = player.single() && !player.crewed();
    if single {
        player.in_doubles(true);
    }
    let found = bending(player, cols, outs, rate, asked, least);
    if single {
        player.in_doubles(false);
    }
    found
}

fn bending(player: &mut Player, cols: usize, outs: usize, rate: f64, asked: &Bend, least: f64) -> Result<Bent, String> {
    if player.crewed() {
        return Err("its orbit is found on one core: a dial of one thread (--threads 1)".into());
    }
    if player.ringed() {
        return Err("a jet's orbit is not yet found: its flows are kept in a ring, not yet read in its order".into());
    }
    if asked.row.len() != cols || asked.along.iter().any(|m| m.row.as_ref().is_some_and(|r| r.len() != cols)) {
        return Err(format!("its row its body's {cols} columns, and its rows moved along its tangent either side"));
    }
    if asked.along.iter().any(|m| m.pulls.is_some()) {
        return Err("its joints are tuned by `points` (orbit.rs pull_points), not along a player's path".into());
    }
    if !(asked.share > 0.0 && asked.most > 0.0 && asked.from_hz > 0.0 && asked.cents > 0.0) {
        return Err("the share of its tangent its move is, the most of the way it may go, its orbit's pitch, and its cents".into());
    }
    let block = 2 * (rate / PITCHES[1]).ceil() as usize + 8;
    let mut map = Map { player, u: asked.row.repeat(block), y: vec![0.0; block * outs], cols, outs, base: vec![], mask: vec![], scale: vec![], kept: vec![], joints: vec![], maps: 0 };
    if let Some(t) = map.player.tract.as_mut() {
        t.settle();
    }
    let t = rate / asked.from_hz;
    prepare(&mut map, t)?;
    let x = map.read();
    let m = x.len();
    let mut flows = Vec::new();
    let (px, rate_x) = map.mapped(&x, t, Some(&mut flows))?;
    if norm(&rate_x) == 0.0 || !norm(&rate_x).is_finite() || swing_of(&flows, rate) < least {
        return Ok(Bent { sounds: false, why: Some("its oscillation dies away at its controls: it comes to rest".into()), maps: map.maps, ..Bent::default() });
    }
    let own: Vec<f64> = {
        let n = norm(&rate_x);
        rate_x.iter().map(|v| v / n).collect()
    };
    let own_row = map.u.clone();
    let own_tract = map.player.tract.as_ref().map(|tr| tr.now());
    let own_base = map.base.clone();
    let to = |map: &mut Map, mv: &Moved, on: bool| {
        if let Some(r) = &mv.row {
            map.u = if on { r.repeat(block) } else { own_row.clone() };
        }
        if let (Some(rs), Some(base), Some(tr)) = (&mv.tract, &own_tract, map.player.tract.as_mut()) {
            tr.set(if on { rs.clone() } else { base.clone() }, 0.0);
        }
    };
    // (Its orbit's own equation at its controls now, each map read at its row's own base (Map::rebased), as its rates are.)
    let here_base = map.rebased(&x)?;
    map.base = here_base.clone();
    let (p0, _) = map.map(&x, t)?;
    let (level0, _) = level_at(&mut map, &x, t, rate)?;
    map.base = own_base.clone();
    // (Its orbit's move along its tangent: the maps at its rows moved either side.)
    let (mut sides, mut bases) = (Vec::with_capacity(2), Vec::with_capacity(2));
    for mv in &asked.along {
        to(&mut map, mv, true);
        map.base = map.rebased(&x)?;
        let (p, _) = map.map(&x, t)?;
        bases.push(std::mem::replace(&mut map.base, own_base.clone()));
        to(&mut map, mv, false);
        sides.push(p);
    }
    let mut b: Vec<f64> = sides[0].iter().zip(&sides[1]).map(|(u, d)| -(u - d) / 2.0).collect();
    b.push(0.0);
    let spent = map.maps;
    let (z, r1) = derivative(&mut map, &x, t, &px, &rate_x, &own, b, RATED)?;
    let solves = vec![map.maps - spent];
    // (Its bend: its orbit's own equation's second difference along its tangent, its state and its period moved with
    // it, and the move of its orbit that answers it.)
    let mut d2: Vec<f64> = p0.iter().zip(&x).map(|(p, v)| -2.0 * (p - v)).collect();
    for (s, (mv, base)) in asked.along.iter().zip(&bases).enumerate() {
        let sign = if s == 0 { 1.0 } else { -1.0 };
        let xs: Vec<f64> = x.iter().zip(&z[..m]).map(|(a, d)| a + sign * d).collect();
        to(&mut map, mv, true);
        map.base = base.clone();
        let read = map.map(&xs, t + sign * z[m]);
        map.base = own_base.clone();
        to(&mut map, mv, false);
        let (p, _) = read?;
        for i in 0..m {
            d2[i] += p[i] - xs[i];
        }
    }
    let mut b: Vec<f64> = d2.iter().map(|v| -v).collect();
    b.push(0.0);
    let spent = map.maps;
    let (w, r2) = derivative(&mut map, &x, t, &px, &rate_x, &own, b, RATED)?;
    let solves = [solves, vec![map.maps - spent]].concat();
    // (Its level either side, its orbit moved to the second order with its controls.)
    let mut levels = [0.0; 2];
    for (s, (mv, base)) in asked.along.iter().zip(&bases).enumerate() {
        let sign = if s == 0 { 1.0 } else { -1.0 };
        let xs: Vec<f64> = (0..m).map(|i| x[i] + sign * z[i] + w[i] / 2.0).collect();
        to(&mut map, mv, true);
        map.base = base.clone();
        let read = level_at(&mut map, &xs, t + sign * z[m] + w[m] / 2.0, rate);
        map.base = own_base.clone();
        to(&mut map, mv, false);
        levels[s] = read?.0;
    }
    let bend_level = levels[0] + levels[1] - 2.0 * level0;
    let bend_cents = 1200.0 * (t / (t + w[m])).log2();
    // (The share of the way: its prediction's error, half its bend times its share over `share` squared, within what is
    // asked of it; and its orbit predicted there, to the second order.)
    let ratio = (bend_cents.abs() / asked.cents).max(asked.decibels.map_or(0.0, |d| bend_level.abs() / d));
    let h = if ratio > 0.0 { asked.share * (2.0 / ratio).sqrt() } else { f64::INFINITY }.min(asked.most);
    let a = h / asked.share;
    let next: Vec<f64> = (0..m).map(|i| x[i] + a * z[i] + 0.5 * a * a * w[i]).collect();
    let t_next = t + a * z[m] + 0.5 * a * a * w[m];
    if !(t_next > 0.0) {
        return Ok(Bent { sounds: false, why: Some("its orbit predicted along its path has no period".into()), maps: map.maps, ..Bent::default() });
    }
    let moved_cents = 1200.0 * (t / (t + z[m])).log2();
    let out = Bent { sounds: true, why: None, h, moved_cents, bend_cents, bend_level, hz: rate / t_next, level: level0 + a * (levels[0] - levels[1]) / 2.0 + 0.5 * a * a * bend_level, residuals: vec![r1, r2], solves, maps: map.maps };
    map.load(&next);
    Ok(out)
}

#[cfg(test)]
mod tests {
    use super::*;

    // (A held note's level: a sinusoid's flow over exactly its period reads its radiated mean square, whatever the period's
    // fraction of a step, and moves smoothly as its period crosses a whole number of steps -- so that a period's move
    // never reads as a level's.)
    #[test]
    fn level_reads_a_period_exactly_and_smoothly() {
        let rate = 48_000.0;
        let flows = |t: f64| -> Vec<f64> { (0..(t as usize + 3)).map(|k| (2.0 * std::f64::consts::PI * (k + 1) as f64 / t).sin()).collect() };
        for t in [100.0, 100.25, 100.5, 122.4489] {
            // (Its radiated: the central difference's amplitude, sin(2 pi / t) rate, its mean square half its square.)
            let amplitude = (2.0 * std::f64::consts::PI / t).sin() * rate;
            let expected = 10.0 * (amplitude * amplitude / 2.0).log10();
            let read = level_of(&flows(t), t, rate);
            assert!((read - expected).abs() < 2e-3, "period {t}: read {read} dB, its mean square {expected}");
        }
        let (below, above) = (level_of(&flows(100.0 - 1e-9), 100.0 - 1e-9, rate), level_of(&flows(100.0), 100.0, rate));
        assert!((below - above).abs() < 1e-6, "across a whole step: {below} against {above}");
    }

    // (A held note's multipliers held within 1 (Proposed 10), its pieces on matrices whose answers are known: an upper
    // Hessenberg matrix's eigenvalues, a flip's at -1.2 and a pair at 0.3 +- 0.4i about one at 0.5, and each one's own
    // vector, H v = value v; a determinant; and the least move that meets two conditions, each control weighed, its move
    // along the conditions' rates alone.)
    #[test]
    fn multipliers_held_pieces() {
        // (Similar to the block matrix B of those values by an upper triangular T with ones on its diagonal, which
        // keeps it upper Hessenberg.)
        let b = [[-1.2, 0.7, 0.1, 0.0], [0.0, 0.3, -0.4, 0.2], [0.0, 0.4, 0.3, 0.5], [0.0, 0.0, 0.0, 0.5]];
        let t = [[1.0, 0.3, -0.2, 0.1], [0.0, 1.0, 0.4, -0.3], [0.0, 0.0, 1.0, 0.25], [0.0, 0.0, 0.0, 1.0]];
        let mut ti = [[0.0; 4]; 4];
        for c in 0..4 {
            let mut e: Vec<f64> = (0..4).map(|r| if r == c { 1.0 } else { 0.0 }).collect();
            let x = solve(&mut t.iter().map(|r| r.to_vec()).collect::<Vec<_>>(), &mut e).expect("T inverted");
            for r in 0..4 {
                ti[r][c] = x[r];
            }
        }
        let product = |a: &[[f64; 4]; 4], c: &[[f64; 4]; 4]| -> [[f64; 4]; 4] {
            let mut p = [[0.0; 4]; 4];
            for i in 0..4 {
                for j in 0..4 {
                    p[i][j] = (0..4).map(|k| a[i][k] * c[k][j]).sum();
                }
            }
            p
        };
        let h: Vec<Vec<f64>> = product(&product(&t, &b), &ti).iter().map(|r| r.to_vec()).collect();
        let values = sorted_values(h.clone());
        let want = [[-1.2, 0.0], [0.3, 0.4], [0.3, -0.4], [0.5, 0.0]];
        assert_eq!(values.len(), 4);
        assert!((values[0][0] + 1.2).abs() < 1e-10 && values[0][1].abs() < 1e-10, "the flip first: {:?}", values[0]);
        for w in &want {
            assert!(values.iter().any(|v| (v[0] - w[0]).abs() < 1e-10 && (v[1] - w[1]).abs() < 1e-10), "{w:?} among {values:?}");
        }
        for value in [[-1.2, 0.0], [0.3, 0.4]] {
            let (re, im) = hessenberg_vector(&h, value).expect("its own vector");
            let im = if im.is_empty() { vec![0.0; 4] } else { im };
            let size = (dot(&re, &re) + dot(&im, &im)).sqrt();
            for i in 0..4 {
                let (hr, hi): (f64, f64) = ((0..4).map(|j| h[i][j] * re[j]).sum(), (0..4).map(|j| h[i][j] * im[j]).sum());
                let (vr, vi) = (value[0] * re[i] - value[1] * im[i], value[0] * im[i] + value[1] * re[i]);
                assert!((hr - vr).abs() < 1e-7 * size && (hi - vi).abs() < 1e-7 * size, "{value:?}: row {i}, H v ({hr}, {hi}) against value v ({vr}, {vi})");
            }
        }
        // (Its determinant: B's, -1.2 * 0.25 * 0.5, T's one.)
        assert!((determinant(h) - (-1.2 * 0.25 * 0.5)).abs() < 1e-12);
        assert_eq!(determinant(vec![vec![1.0, 2.0], vec![2.0, 4.0]]), 0.0);
        // (Two conditions on four controls, the third held: G d = r over those free, and d = W G^T y.)
        let (g0, g1) = ([1.0, 2.0, 5.0, -1.0], [0.5, -1.0, 3.0, 2.0]);
        let (r, w, free) = ([0.3, -0.2], [1.0, 4.0, 1.0, 0.25], [0usize, 1, 3]);
        let d = least_move(&[&g0, &g1], &r, &w, &free).expect("a move");
        for (g, want) in [(&g0, r[0]), (&g1, r[1])] {
            let met: f64 = free.iter().zip(&d).map(|(&j, dj)| g[j] * dj).sum();
            assert!((met - want).abs() < 1e-12, "a condition met: {met} against {want}");
        }
        // (Along the conditions' rates alone: d_j / w_j lies in the span of the two rows.)
        let rows = |j: usize| [g0[free[j]], g1[free[j]]];
        let along: Vec<f64> = (0..3).map(|j| d[j] / w[free[j]]).collect();
        let det = rows(0)[0] * rows(1)[1] - rows(0)[1] * rows(1)[0];
        let y = [(along[0] * rows(1)[1] - along[1] * rows(0)[1]) / det, (rows(0)[0] * along[1] - rows(1)[0] * along[0]) / det];
        assert!((along[2] - (y[0] * rows(2)[0] + y[1] * rows(2)[1])).abs() < 1e-12, "its move along its conditions' rates");
        // (No move where its conditions' rates are one: refused.)
        assert!(least_move(&[&g0, &g0], &r, &w, &free).is_none());
    }
}

// ---- A body's joints pulled to tune its held notes (the owner, 9 November 2026: "make sure we have code that optimizes
// the body's tuning points"; its design approved: "Yes, proceed"): here at the file's end. ----

/// The coefficients a pull of its joints changes put in the map's base (the doubles outside its state, which `load`
/// puts back each map): its player pulled to `pulls`, each double the pull moved taken from there.
fn pulled_base(map: &mut Map, pulls: &[f64]) {
    let before = map.player.data().to_vec();
    map.player.pull_points(pulls);
    let after = map.player.data();
    for (k, (b, a)) in before.iter().zip(after).enumerate() {
        if a != b {
            map.base[k] = *a;
        }
    }
}

/// Its player's joints pulled to `pulls`, and each note's orbit to begin from (`from`: its player's doubles, at the
/// pulls its player stood at, and its tract's state) given the coefficients the pull moved.
fn pull_carried(player: &mut Player, pulls: &[f64], from: &mut [(Vec<f64>, Option<Vec<f64>>)]) {
    let before = player.data().to_vec();
    player.pull_points(pulls);
    let after = player.data();
    for (k, (b, a)) in before.iter().zip(after).enumerate() {
        if a != b {
            for f in from.iter_mut() {
                f.0[k] = *a;
            }
        }
    }
}

/// A held note its joints are pulled to tune: its row, its tract's resonances (its tract as it stands, where none), the
/// pitch asked (Hz: its period sought within NEAR octaves of it) and its weight among the notes.
#[derive(serde::Deserialize, Clone, Debug)]
pub struct PointNote {
    pub row: Vec<f64>,
    #[serde(default)]
    pub tract: Option<Vec<crate::tract::Resonance>>,
    pub hz: f64,
    #[serde(default = "one")]
    pub weight: f64,
}

fn one() -> f64 {
    1.0
}

/// Its joints pulled to tune its held notes: the notes; the joints moved (in its header's order) and the span each is
/// kept within (m; its range, where none); the pull each one's rate is read over (m); how near each note is tuned
/// (cents); its steps at most; and the seconds each note is warmed at its row, from its orbit, before its orbit is found.
#[derive(serde::Deserialize, Clone, Debug)]
pub struct Pulls {
    pub notes: Vec<PointNote>,
    pub joints: Vec<usize>,
    #[serde(default)]
    pub within: Vec<[f64; 2]>,
    pub nudge: f64,
    pub cents: f64,
    pub steps: usize,
    #[serde(default)]
    pub warm: f64,
}

/// A note at its joints' pulls: whether it sounds (why not, where it does not), its pitch (Hz), how far from the pitch
/// asked (cents), how closed its orbit, and each joint's rate on it (cents for a pull of 1 mm) with its linear solve's
/// residual.
#[derive(Debug, Clone, Default, serde::Serialize)]
pub struct PulledNote {
    pub sounds: bool,
    pub why: Option<String>,
    pub hz: f64,
    pub off: f64,
    pub closing: f64,
    pub rates: Vec<f64>,
    pub residuals: Vec<f64>,
}

/// A step of the joints' tuning: the pulls its notes were found at (m, every joint's), each note there, their weighted
/// mean square's root of cents off, and the move taken from there (each joint moved, m) and which were held at the end
/// of their spans.
#[derive(Debug, Clone, Default, serde::Serialize)]
pub struct PullStep {
    pub pulls: Vec<f64>,
    pub notes: Vec<PulledNote>,
    pub off: f64,
    pub moved: Vec<f64>,
    pub held: Vec<bool>,
}

/// What the joints' tuning found: whether each note is within its cents, why not where it is not, the pulls it leaves its
/// joints at (the step whose notes stood nearest), each step, and the map's evaluations.
#[derive(Debug, Clone, Default, serde::Serialize)]
pub struct Pulled {
    pub tuned: bool,
    pub why: Option<String>,
    pub pulls: Vec<f64>,
    pub steps: Vec<PullStep>,
    pub maps: usize,
}

/// Its joints pulled to tune its held notes, computed on the engine itself: at its pulls each note's orbit found (from
/// its orbit `from`, warmed at its row), and how far a pull of `nudge` of each joint moves its pitch (`rates`, along
/// the orbit's derivative); then every joint moved at once by the least squares of its notes' cents off over those rates
/// -- the least move, each over its span, where the notes leave the joints free -- a joint the move would take past its
/// span's end held there and the rest solved again; and its notes found again there, until each is within its cents,
/// its steps are spent or a step leaves its notes no nearer. No search: each move is arithmetic on the rates its notes'
/// orbits give. Its player left at the pulls whose notes stood nearest, its doubles wherever its last orbit left them (the
/// caller keeps its own state and puts it back); `from` each note's orbit at the pulls last measured. `least`: the least
/// swing of its sound that is one (Asked::least). A bore played in singles solved in doubles, as its orbits are.
pub fn pull_points(player: &mut Player, cols: usize, outs: usize, rate: f64, asked: &Pulls, from: &mut [(Vec<f64>, Option<Vec<f64>>)], least: f64, jet: Option<(usize, usize, usize)>) -> Result<Pulled, String> {
    if player.crewed() {
        return Err("its orbit is found on one core: a dial of one thread (--threads 1)".into());
    }
    if player.ringed() {
        return Err("a jet's orbit is not yet found: its flows are kept in a ring, not yet read in its order".into());
    }
    let ranges = player.joint_ranges();
    let k = asked.joints.len();
    if ranges.is_empty() {
        return Err("its body has no joints".into());
    }
    if k == 0 || asked.joints.iter().any(|&j| j >= ranges.len()) || !(asked.within.is_empty() || asked.within.len() == k) {
        return Err(format!("the joints moved, each of its body's {}, and a span for each or none", ranges.len()));
    }
    if asked.notes.is_empty() || from.len() != asked.notes.len() || asked.notes.iter().any(|n| n.row.len() != cols || !(n.hz > 0.0) || !(n.weight > 0.0)) {
        return Err(format!("its notes, each its orbit to begin from, its row of its body's {cols} columns, its pitch and its weight"));
    }
    if !(asked.nudge > 0.0 && asked.cents > 0.0) || asked.steps == 0 {
        return Err("the pull its rates are read over, the cents its notes are tuned within, and its steps".into());
    }
    let within: Vec<[f64; 2]> = asked.joints.iter().enumerate().map(|(i, &j)| {
        let w = asked.within.get(i).copied().unwrap_or(ranges[j]);
        [w[0].max(ranges[j][0]), w[1].min(ranges[j][1])]
    }).collect();
    if within.iter().any(|w| !(w[0] <= w[1])) {
        return Err("each joint's span within its range".into());
    }
    let single = player.single();
    if single {
        player.in_doubles(true);
    }
    let found = pulling(player, cols, outs, rate, asked, &within, &ranges, from, least, jet);
    if single {
        player.in_doubles(false);
    }
    found
}

fn pulling(player: &mut Player, cols: usize, outs: usize, rate: f64, asked: &Pulls, within: &[[f64; 2]], ranges: &[[f64; 2]], from: &mut [(Vec<f64>, Option<Vec<f64>>)], least: f64, jet: Option<(usize, usize, usize)>) -> Result<Pulled, String> {
    let mut pulls = player.pulls();
    for (i, &j) in asked.joints.iter().enumerate() {
        pulls[j] = pulls[j].clamp(within[i][0], within[i][1]);
    }
    let cents = |hz: f64, asked: f64| 1200.0 * (hz / asked).log2();
    let mut out = Pulled::default();
    let mut nearest: Option<(f64, Vec<f64>)> = None;
    for step in 0..=asked.steps {
        pull_carried(player, &pulls, from);
        let mut here = PullStep { pulls: pulls.clone(), ..PullStep::default() };
        // (Each note's orbit at these pulls, and each joint's rate on it: a pull of `nudge` more, or less where it would
        // pass its range.)
        let signs: Vec<f64> = asked.joints.iter().map(|&j| if pulls[j] + asked.nudge <= ranges[j][1] { 1.0 } else { -1.0 }).collect();
        let moved: Vec<Moved> = asked.joints.iter().zip(&signs).map(|(&j, &sign)| {
            let mut p = pulls.clone();
            p[j] += sign * asked.nudge;
            Moved { pulls: Some(p), ..Moved::default() }
        }).collect();
        for (i, note) in asked.notes.iter().enumerate() {
            player.set_data(&from[i].0);
            if let Some(rs) = &note.tract {
                let t = player.tract.get_or_insert_with(|| crate::tract::Tract::new(rate));
                t.set(rs.clone(), 0.0);
            }
            if let (Some(s), Some(t)) = (&from[i].1, player.tract.as_mut()) {
                if s.len() == t.state().len() {
                    t.set_state(s);
                }
            }
            let a = Asked { row: &note.row, nudged: None, warm: asked.warm, multipliers: 0, least, jet };
            let found = solved_near(player, cols, outs, rate, &a, &moved, Some(note.hz))?;
            out.maps += found.maps;
            if !found.sounds {
                here.notes.push(PulledNote { sounds: false, why: found.why, ..PulledNote::default() });
                continue;
            }
            from[i] = (player.data().to_vec(), player.tract.as_ref().map(|t| t.state()));
            // (Its cents for a pull of 1 mm: its period's move, steps, for the pull's nudge.)
            let rates = found.rates.iter().zip(&signs).map(|(r, s)| -1200.0 / std::f64::consts::LN_2 * (r.steps / found.steps) / (s * asked.nudge) * 1e-3).collect();
            here.notes.push(PulledNote { sounds: true, why: None, hz: found.hz, off: cents(found.hz, note.hz), closing: found.closing, rates, residuals: found.rates.iter().map(|r| r.residual).collect() });
        }
        if let Some(n) = here.notes.iter().position(|n| !n.sounds) {
            out.why = Some(format!("its note {n} does not sound at pulls {:?} m: {}", pulls, here.notes[n].why.clone().unwrap_or_default()));
            out.steps.push(here);
            break;
        }
        let weights: f64 = asked.notes.iter().map(|n| n.weight).sum();
        here.off = (here.notes.iter().zip(&asked.notes).map(|(h, n)| n.weight * h.off * h.off).sum::<f64>() / weights).sqrt();
        let worse = nearest.as_ref().is_some_and(|(off, _)| here.off >= *off);
        if !worse {
            nearest = Some((here.off, pulls.clone()));
        }
        if here.notes.iter().all(|n| n.off.abs() <= asked.cents) {
            out.tuned = true;
            out.steps.push(here);
            break;
        }
        if worse {
            out.why = Some(format!("its last move left its notes no nearer ({:.3} c against {:.3})", here.off, nearest.as_ref().map_or(0.0, |n| n.0)));
            out.steps.push(here);
            break;
        }
        if step == asked.steps {
            out.why = Some(format!("its notes not within {} c after {} steps", asked.cents, asked.steps));
            out.steps.push(here);
            break;
        }
        // (The move: its rates per m, each note's cents to go.)
        let c: Vec<Vec<f64>> = here.notes.iter().map(|n| n.rates.iter().map(|r| r * 1e3).collect()).collect();
        let r: Vec<f64> = here.notes.iter().map(|n| -n.off).collect();
        let w: Vec<f64> = asked.notes.iter().map(|n| n.weight).collect();
        let at: Vec<f64> = asked.joints.iter().map(|&j| pulls[j]).collect();
        let (d, held) = joints_move(&c, &r, &w, &at, within);
        here.moved = d.clone();
        here.held = held;
        out.steps.push(here);
        if d.iter().all(|&v| v == 0.0) {
            out.why = Some("each joint held at the end of its span its notes ask it past".into());
            break;
        }
        for (q, &j) in asked.joints.iter().enumerate() {
            pulls[j] = (pulls[j] + d[q]).clamp(within[q][0], within[q][1]);
        }
    }
    // (Left at the pulls whose notes stood nearest.)
    if let Some((_, best)) = nearest {
        pull_carried(player, &best, from);
        out.pulls = best;
    } else {
        out.pulls = player.pulls();
    }
    Ok(out)
}

/// The move of the joints (`c`: each note's rate, cents per m, of each joint; `r`: each note's cents to go, `w` their
/// weights; `at`: where each joint stands, `within` its span) that takes its notes nearest by their rates: least squares
/// over its joints each measured over its span, a millionth of its largest curvature added so that where the notes leave
/// the joints free it is the least move; a joint the move would take past its span's end held there and the rest solved
/// again -> each joint's move (m) and whether it is held.
fn joints_move(c: &[Vec<f64>], r: &[f64], w: &[f64], at: &[f64], within: &[[f64; 2]]) -> (Vec<f64>, Vec<bool>) {
    let k = at.len();
    let span: Vec<f64> = within.iter().map(|s| s[1] - s[0]).collect();
    let mut held: Vec<bool> = span.iter().map(|&s| !(s > 0.0)).collect();
    let mut d: Vec<f64> = (0..k).map(|j| if held[j] { within[j][0] - at[j] } else { 0.0 }).collect();
    loop {
        let free: Vec<usize> = (0..k).filter(|&j| !held[j]).collect();
        if free.is_empty() {
            return (d, held);
        }
        let left: Vec<f64> = r.iter().enumerate().map(|(i, &ri)| ri - (0..k).filter(|&j| held[j]).map(|j| c[i][j] * d[j]).sum::<f64>()).collect();
        let n = free.len();
        let a = |i: usize, q: usize| c[i][free[q]] * span[free[q]];
        let mut m: Vec<Vec<f64>> = (0..n).map(|p| (0..n).map(|q| (0..r.len()).map(|i| w[i] * a(i, p) * a(i, q)).sum()).collect()).collect();
        let mut b: Vec<f64> = (0..n).map(|p| (0..r.len()).map(|i| w[i] * a(i, p) * left[i]).sum()).collect();
        let largest = (0..n).map(|p| m[p][p]).fold(0.0, f64::max);
        for (p, row) in m.iter_mut().enumerate() {
            row[p] += 1e-6 * largest;
        }
        let Some(u) = solve(&mut m, &mut b) else {
            return ((0..k).map(|j| if held[j] { d[j] } else { 0.0 }).collect(), held);
        };
        let mut past = false;
        for (q, &j) in free.iter().enumerate() {
            let to = at[j] + u[q] * span[j];
            if to > within[j][1] || to < within[j][0] {
                held[j] = true;
                d[j] = to.clamp(within[j][0], within[j][1]) - at[j];
                past = true;
            } else {
                d[j] = u[q] * span[j];
            }
        }
        if !past {
            return (d, held);
        }
    }
}

/// Directions an operator has been applied to, kept to be used again (gcr_kept): each one `u` and what the operator makes
/// of it `c`, the `c`s orthonormal.
#[derive(Default)]
struct Kept {
    u: Vec<Vec<f64>>,
    c: Vec<Vec<f64>>,
}

/// The generalized conjugate residual method on `apply` (an operator on vectors of `b`'s length) begun from the
/// directions `kept`: its residual first taken out along those, then each new direction its residual, its image made
/// orthonormal to the images kept (Gram and Schmidt's, a second time where the first leaves under 0.7 of its size, as
/// Daniel, Gragg, Kaufman and Stewart's), until its residual is `tolerance` of `b`'s or KRYLOV new directions; each new
/// one kept. Over the same directions the least-squares solution gmres finds: begun from none, over the same Krylov
/// space. -> the solution, and its residual's size against `b`'s.
fn gcr_kept(b: &[f64], tolerance: f64, kept: &mut Kept, mut apply: impl FnMut(&[f64]) -> Result<Vec<f64>, String>) -> Result<(Vec<f64>, f64), String> {
    let (n, beta) = (b.len(), norm(b));
    if beta == 0.0 {
        return Ok((vec![0.0; n], 0.0));
    }
    let (mut x, mut r) = (vec![0.0; n], b.to_vec());
    for (u, c) in kept.u.iter().zip(&kept.c) {
        let a = lanes_dot(c, &r);
        less(&mut x, -a, u);
        less(&mut r, a, c);
    }
    let mut new = 0;
    while norm(&r) > tolerance * beta && new < KRYLOV {
        let mut u = r.clone();
        let mut c = apply(&u)?;
        let mut size = norm(&c);
        for pass in 0..2 {
            for (uj, cj) in kept.u.iter().zip(&kept.c) {
                let a = lanes_dot(cj, &c);
                less(&mut c, a, cj);
                less(&mut u, a, uj);
            }
            let after = norm(&c);
            let enough = after >= 0.7 * size;
            size = after;
            if enough || pass == 1 {
                break;
            }
        }
        if !(size > 0.0 && size.is_finite()) {
            break;
        }
        c.iter_mut().for_each(|v| *v /= size);
        u.iter_mut().for_each(|v| *v /= size);
        let a = lanes_dot(&c, &r);
        less(&mut x, -a, &u);
        less(&mut r, a, &c);
        kept.u.push(u);
        kept.c.push(c);
        new += 1;
    }
    let residual = norm(&r) / beta;
    Ok((x, residual))
}

// (gcr_kept's dot product over eight running sums, so that it is computed in the machine's lanes, and `x` less `a`
// times `y`.)
fn lanes_dot(a: &[f64], b: &[f64]) -> f64 {
    let mut s = [0.0; 8];
    let (ca, cb) = (a.chunks_exact(8), b.chunks_exact(8));
    let rest: f64 = ca.remainder().iter().zip(cb.remainder()).map(|(x, y)| x * y).sum();
    for (x, y) in ca.zip(cb) {
        for k in 0..8 {
            s[k] += x[k] * y[k];
        }
    }
    s.iter().sum::<f64>() + rest
}

fn less(x: &mut [f64], a: f64, y: &[f64]) {
    for (xi, yi) in x.iter_mut().zip(y) {
        *xi -= a * yi;
    }
}

/// `m x = b` by Gauss's elimination, its largest pivot first -> x, or none where `m` is singular.
fn solve(m: &mut [Vec<f64>], b: &mut [f64]) -> Option<Vec<f64>> {
    let n = b.len();
    for col in 0..n {
        let p = (col..n).max_by(|&i, &j| m[i][col].abs().total_cmp(&m[j][col].abs()))?;
        if !(m[p][col].abs() > 0.0) {
            return None;
        }
        m.swap(col, p);
        b.swap(col, p);
        for row in col + 1..n {
            let f = m[row][col] / m[col][col];
            for c in col..n {
                m[row][c] -= f * m[col][c];
            }
            b[row] -= f * b[col];
        }
    }
    let mut x = vec![0.0; n];
    for row in (0..n).rev() {
        x[row] = (b[row] - (row + 1..n).map(|c| m[row][c] * x[c]).sum::<f64>()) / m[row][row];
    }
    Some(x)
}

// ---- Its makers' points moved to tune its held notes (native/openwind-maker src/points.rs; the owner, 9 November 2026:
// "optimize the tuning of the instrument, within normal parameters, at all of the instrument makers' usual adjustment
// points"; its design approved: "Yes, build"): here at the file's end. ----

/// A step of its makers' points' tuning: its held notes; each point's value where the body its player plays was made, the
/// span it is kept within, and how far the body made for its rate moved it (each in its own unit: m, or a share of its
/// bore's radius); how near each note is tuned (cents); the seconds each note is warmed at its row, from its orbit,
/// before its orbit is found; and, where given, the cents each note is kept at or above its pitch at its rules, so that
/// its player lips none of them up (above_move).
#[derive(serde::Deserialize, Clone, Debug)]
pub struct PointsAsked {
    pub notes: Vec<PointNote>,
    pub at: Vec<f64>,
    pub within: Vec<[f64; 2]>,
    pub nudges: Vec<f64>,
    pub cents: f64,
    #[serde(default)]
    pub warm: f64,
    #[serde(default)]
    pub above: Option<f64>,
}

/// A step of its makers' points' tuning: each note at its body (its rates, cents for a move of one of each point's units),
/// their weighted mean square's root of cents off, how far the note lowest under its pitch stands under it (cents, none
/// where none is), whether each is within its cents (and, kept above, none under its pitch; why not, where one does not
/// sound), the move taken from there (each point's, in its unit) and which were held at the end of their spans, whether
/// that move keeps every note at or above its pitch by its rates where asked (where no move within the spans does, the
/// least-squares move in its place), and the map's evaluations.
#[derive(Debug, Clone, Default, serde::Serialize)]
pub struct PointsStep {
    pub notes: Vec<PulledNote>,
    pub off: f64,
    pub under: f64,
    pub tuned: bool,
    pub why: Option<String>,
    pub moved: Vec<f64>,
    pub held: Vec<bool>,
    pub above: Option<bool>,
    pub maps: usize,
}

/// Its makers' points' rates at the body its player plays, computed on the engine itself: each note's orbit found (from
/// its orbit `from`, warmed at its row), and how far each point's moved body -- `moved`, the coefficients its remaking
/// moves, each with its value there (kernel.rs Player::remade) -- moves its pitch, along the orbit's derivative; then
/// every point moved at once by the least squares of its notes' cents off over those rates, each over its span, the least
/// move where the notes leave the points free, a point the move would take past its span's end held there (joints_move).
/// No search: the move is arithmetic on its notes' orbits' rates. `from` each note's orbit at the body. `least`: the
/// least swing of its sound that is one (Asked::least). A bore played in singles solved in doubles, as its orbits are.
pub fn points_step(player: &mut Player, cols: usize, outs: usize, rate: f64, asked: &PointsAsked, moved: &[Vec<(usize, f64)>], from: &mut [(Vec<f64>, Option<Vec<f64>>)], least: f64, jet: Option<(usize, usize, usize)>) -> Result<PointsStep, String> {
    if player.crewed() {
        return Err("its orbit is found on one core: a dial of one thread (--threads 1)".into());
    }
    if player.ringed() {
        return Err("a jet's orbit is not yet found: its flows are kept in a ring, not yet read in its order".into());
    }
    let k = asked.at.len();
    if k == 0 || moved.len() != k || asked.within.len() != k || asked.nudges.len() != k || asked.nudges.iter().any(|n| !(*n != 0.0 && n.is_finite())) {
        return Err("each point's value, its span, the nudge its moved body was made at, and that body".into());
    }
    if asked.within.iter().zip(&asked.at).any(|(w, a)| !(w[0] <= *a && *a <= w[1])) {
        return Err("each point within its span".into());
    }
    if asked.notes.is_empty() || from.len() != asked.notes.len() || asked.notes.iter().any(|n| n.row.len() != cols || !(n.hz > 0.0) || !(n.weight > 0.0)) {
        return Err(format!("its notes, each its orbit to begin from, its row of its body's {cols} columns, its pitch and its weight"));
    }
    if !(asked.cents > 0.0) {
        return Err("the cents its notes are tuned within".into());
    }
    let single = player.single();
    if single {
        player.in_doubles(true);
    }
    let found = pointing(player, cols, outs, rate, asked, moved, from, least, jet);
    if single {
        player.in_doubles(false);
    }
    found
}

fn pointing(player: &mut Player, cols: usize, outs: usize, rate: f64, asked: &PointsAsked, moved: &[Vec<(usize, f64)>], from: &mut [(Vec<f64>, Option<Vec<f64>>)], least: f64, jet: Option<(usize, usize, usize)>) -> Result<PointsStep, String> {
    let cents = |hz: f64, asked: f64| 1200.0 * (hz / asked).log2();
    let moves: Vec<Moved> = moved.iter().map(|c| Moved { coefficients: Some(c.clone()), ..Moved::default() }).collect();
    let mut out = PointsStep::default();
    for (i, note) in asked.notes.iter().enumerate() {
        player.set_data(&from[i].0);
        if let Some(rs) = &note.tract {
            let t = player.tract.get_or_insert_with(|| crate::tract::Tract::new(rate));
            t.set(rs.clone(), 0.0);
        }
        if let (Some(s), Some(t)) = (&from[i].1, player.tract.as_mut()) {
            if s.len() == t.state().len() {
                t.set_state(s);
            }
        }
        let a = Asked { row: &note.row, nudged: None, warm: asked.warm, multipliers: 0, least, jet };
        let found = solved_near(player, cols, outs, rate, &a, &moves, Some(note.hz))?;
        out.maps += found.maps;
        if !found.sounds {
            out.notes.push(PulledNote { sounds: false, why: found.why, ..PulledNote::default() });
            continue;
        }
        from[i] = (player.data().to_vec(), player.tract.as_ref().map(|t| t.state()));
        // (Its cents for a move of one of each point's units: its period's move, steps, for its nudge.)
        let rates = found.rates.iter().zip(&asked.nudges).map(|(r, n)| -1200.0 / std::f64::consts::LN_2 * (r.steps / found.steps) / n).collect();
        out.notes.push(PulledNote { sounds: true, why: None, hz: found.hz, off: cents(found.hz, note.hz), closing: found.closing, rates, residuals: found.rates.iter().map(|r| r.residual).collect() });
    }
    if let Some(n) = out.notes.iter().position(|n| !n.sounds) {
        out.why = Some(format!("its note {n} does not sound at this body: {}", out.notes[n].why.clone().unwrap_or_default()));
        return Ok(out);
    }
    let weights: f64 = asked.notes.iter().map(|n| n.weight).sum();
    out.off = (out.notes.iter().zip(&asked.notes).map(|(h, n)| n.weight * h.off * h.off).sum::<f64>() / weights).sqrt();
    out.under = out.notes.iter().map(|n| -n.off).fold(0.0, f64::max);
    out.tuned = out.notes.iter().all(|n| n.off.abs() <= asked.cents && (asked.above.is_none() || n.off >= 0.0));
    if out.tuned {
        return Ok(out);
    }
    let c: Vec<Vec<f64>> = out.notes.iter().map(|n| n.rates.clone()).collect();
    let r: Vec<f64> = out.notes.iter().map(|n| -n.off).collect();
    let w: Vec<f64> = asked.notes.iter().map(|n| n.weight).collect();
    let kept = asked.above.and_then(|margin| above_move(&c, &r, &w, &asked.at, &asked.within, margin));
    out.above = asked.above.map(|_| kept.is_some());
    (out.moved, out.held) = match kept {
        Some(m) => m,
        None => joints_move(&c, &r, &w, &asked.at, &asked.within),
    };
    Ok(out)
}

// ---- Its notes kept at or above their pitches at their rules (the owner, 9 November 2026: "We should not have players
// doing things that would feel unnatural or bad for a human. So, no player should have to correct the tuning of a note
// upward. Measured ranges will need to constrain our optimizer"): least squares under inequalities, here at the file's
// end. ----

/// The move of its points that takes its notes nearest by their rates (as joints_move: `c` each note's rate, cents per
/// unit, of each point; `r` each note's cents to go, `w` their weights; `at` where each point stands, `within` its span),
/// every note kept at or above its pitch by `margin` cents and each point within its span: least squares under
/// inequalities, solved exactly -- made a problem of least distance, and that solved by non-negative least squares (C. L.
/// Lawson & R. J. Hanson 1974, Solving Least Squares Problems, ch. 23, its LSI, LDP and NNLS) -- each point measured over
/// its span, a millionth of the largest curvature added so that where the notes leave the points free it is the least
/// move -> each point's move and whether it ends at its span's end; none where no move within the spans keeps every note
/// at or above.
fn above_move(c: &[Vec<f64>], r: &[f64], w: &[f64], at: &[f64], within: &[[f64; 2]], margin: f64) -> Option<(Vec<f64>, Vec<bool>)> {
    let (k, notes) = (at.len(), r.len());
    let span: Vec<f64> = within.iter().map(|s| s[1] - s[0]).collect();
    let free: Vec<usize> = (0..k).filter(|&j| span[j] > 0.0).collect();
    let mut held: Vec<bool> = span.iter().map(|&s| !(s > 0.0)).collect();
    let mut d: Vec<f64> = (0..k).map(|j| if held[j] { within[j][0] - at[j] } else { 0.0 }).collect();
    // (What the points with no span leave each note to go; the rest's rates over their spans.)
    let left: Vec<f64> = (0..notes).map(|i| r[i] - (0..k).filter(|&j| held[j]).map(|j| c[i][j] * d[j]).sum::<f64>()).collect();
    let n = free.len();
    let a: Vec<Vec<f64>> = (0..notes).map(|i| free.iter().map(|&j| c[i][j] * span[j]).collect()).collect();
    // (Its constraints g u >= h: each note at or above its pitch, then each point within its span either side.)
    let mut g: Vec<Vec<f64>> = a.clone();
    let mut h: Vec<f64> = left.iter().map(|l| l + margin).collect();
    for (q, &j) in free.iter().enumerate() {
        let mut e = vec![0.0; n];
        e[q] = 1.0;
        g.push(e.clone());
        h.push((within[j][0] - at[j]) / span[j]);
        e[q] = -1.0;
        g.push(e);
        h.push(-(within[j][1] - at[j]) / span[j]);
    }
    if n == 0 {
        return h.iter().all(|&v| v <= 0.0).then_some((d, held));
    }
    // (Its curvature A^T W A with its ridge and its slope A^T W left, so that its notes' squares are u^T H u - 2 b^T u
    // and their own; H = L L^T; its least move u0 = H^-1 b, and z = L^T (u - u0), whose least size under
    // (L^-1 g) z >= h - g u0 is the least distance's problem.)
    let mut hm: Vec<Vec<f64>> = (0..n).map(|p| (0..n).map(|q| (0..notes).map(|i| w[i] * a[i][p] * a[i][q]).sum()).collect()).collect();
    let b: Vec<f64> = (0..n).map(|p| (0..notes).map(|i| w[i] * a[i][p] * left[i]).sum()).collect();
    let largest = (0..n).map(|p| hm[p][p]).fold(0.0, f64::max);
    let ridge = 1e-6 * if largest > 0.0 { largest } else { 1.0 };
    for (p, row) in hm.iter_mut().enumerate() {
        row[p] += ridge;
    }
    let l = cholesky(&hm)?;
    let u0 = backward_solved(&l, &forward_solved(&l, &b));
    let gz: Vec<Vec<f64>> = g.iter().map(|row| forward_solved(&l, row)).collect();
    let hz: Vec<f64> = g.iter().zip(&h).map(|(row, hv)| hv - dot(row, &u0)).collect();
    let z = least_distance(&gz, &hz)?;
    let u: Vec<f64> = backward_solved(&l, &z).iter().zip(&u0).map(|(x, y)| x + y).collect();
    // (Kept by its constraints to within its arithmetic's own.)
    if g.iter().zip(&h).any(|(row, hv)| dot(row, &u) < hv - 1e-8 * (1.0 + hv.abs() + row.iter().zip(&u).map(|(x, y)| (x * y).abs()).sum::<f64>())) {
        return None;
    }
    for (q, &j) in free.iter().enumerate() {
        let to = (at[j] + u[q] * span[j]).clamp(within[j][0], within[j][1]);
        d[j] = to - at[j];
        held[j] = to - within[j][0] <= 1e-9 * span[j] || within[j][1] - to <= 1e-9 * span[j];
    }
    Some((d, held))
}

/// The least `z` with each `g` row's z at least its `h` (Lawson & Hanson's LDP): non-negative least squares of the rows
/// with their `h` beside them, as columns, against (0, ..., 0, 1), its residual's last share setting z -> z, or none
/// where no z keeps them all.
fn least_distance(g: &[Vec<f64>], h: &[f64]) -> Option<Vec<f64>> {
    let n = g.first().map_or(0, |row| row.len());
    let cols: Vec<Vec<f64>> = g.iter().zip(h).map(|(row, &hv)| row.iter().copied().chain([hv]).collect()).collect();
    let mut f = vec![0.0; n + 1];
    f[n] = 1.0;
    let u = non_negative(&cols, &f)?;
    let res: Vec<f64> = (0..=n).map(|i| cols.iter().zip(&u).map(|(col, uj)| col[i] * uj).sum::<f64>() - f[i]).collect();
    if !(norm(&res) > 1e-10 && res[n] < 0.0) {
        return None;
    }
    Some((0..n).map(|i| -res[i] / res[n]).collect())
}

/// The non-negative weights of `cols` whose sum stands nearest `f` (Lawson & Hanson's NNLS: a column joins its passive
/// set where its residual's slope is largest, and the passive set's least squares, kept positive, moves its weights) ->
/// the weights, or none where its passive columns fail to stand apart.
fn non_negative(cols: &[Vec<f64>], f: &[f64]) -> Option<Vec<f64>> {
    let m = cols.len();
    let (mut x, mut passive, mut refused) = (vec![0.0; m], vec![false; m], vec![false; m]);
    let size = cols.iter().map(|col| norm(col)).fold(0.0, f64::max).max(f64::MIN_POSITIVE);
    let least = 1e-12 * size * norm(f).max(1.0);
    for _ in 0..3 * m + 3 {
        let res: Vec<f64> = (0..f.len()).map(|i| f[i] - cols.iter().zip(&x).map(|(col, xj)| col[i] * xj).sum::<f64>()).collect();
        let slope: Vec<f64> = cols.iter().map(|col| dot(col, &res)).collect();
        let Some(t) = (0..m).filter(|&j| !passive[j] && !refused[j] && slope[j] > least).max_by(|&a, &b| slope[a].total_cmp(&slope[b])) else {
            return Some(x);
        };
        passive[t] = true;
        let mut first = true;
        loop {
            let on: Vec<usize> = (0..m).filter(|&j| passive[j]).collect();
            let z = least_squares(&on.iter().map(|&j| cols[j].as_slice()).collect::<Vec<_>>(), f);
            // (A column that would join at no weight, or not apart from those in: set aside until the weights move.)
            let at_t = on.iter().position(|&j| j == t);
            let refuse = match (&z, first, at_t) {
                (None, _, _) => true,
                (Some(z), true, Some(p)) => !(z[p] > 0.0),
                _ => false,
            };
            if refuse {
                passive[t] = false;
                refused[t] = true;
                if z.is_none() && !first {
                    return None;
                }
                break;
            }
            first = false;
            let z = z?;
            if z.iter().all(|&v| v > 0.0) {
                for (&j, &v) in on.iter().zip(&z) {
                    x[j] = v;
                }
                refused.iter_mut().for_each(|v| *v = false);
                break;
            }
            let alpha = on.iter().zip(&z).filter(|(_, &v)| v <= 0.0).map(|(&j, &v)| x[j] / (x[j] - v)).fold(f64::INFINITY, f64::min);
            for (&j, &v) in on.iter().zip(&z) {
                x[j] += alpha * (v - x[j]);
            }
            for &j in &on {
                if x[j] <= least {
                    x[j] = 0.0;
                    passive[j] = false;
                }
            }
        }
    }
    Some(x)
}

/// The least-squares weights of `cols` (columns of one length) against `f`, by Householder's reflections -> the weights,
/// or none where a column does not stand apart from those before it.
fn least_squares(cols: &[&[f64]], f: &[f64]) -> Option<Vec<f64>> {
    let (rows, p) = (f.len(), cols.len());
    if p > rows {
        return None;
    }
    let size = cols.iter().map(|col| norm(col)).fold(0.0, f64::max);
    let (mut m, mut y): (Vec<Vec<f64>>, Vec<f64>) = (cols.iter().map(|col| col.to_vec()).collect(), f.to_vec());
    for k in 0..p {
        let s = m[k][k..].iter().map(|v| v * v).sum::<f64>().sqrt();
        if !(s > 1e-12 * size) {
            return None;
        }
        let alpha = if m[k][k] > 0.0 { -s } else { s };
        let mut v = m[k][k..].to_vec();
        v[0] -= alpha;
        let vv = dot(&v, &v);
        let reflect = |x: &mut [f64]| {
            let a = 2.0 * dot(&v, x) / vv;
            less(x, a, &v);
        };
        for col in m.iter_mut().skip(k) {
            reflect(&mut col[k..]);
        }
        reflect(&mut y[k..]);
    }
    let mut z = vec![0.0; p];
    for i in (0..p).rev() {
        z[i] = (y[i] - (i + 1..p).map(|j| m[j][i] * z[j]).sum::<f64>()) / m[i][i];
    }
    Some(z)
}

/// `h`'s lower Cholesky factor (h = L L^T) -> L, or none where `h` is not positive definite.
fn cholesky(h: &[Vec<f64>]) -> Option<Vec<Vec<f64>>> {
    let n = h.len();
    let mut l = vec![vec![0.0; n]; n];
    for i in 0..n {
        for j in 0..=i {
            let s = h[i][j] - (0..j).map(|k| l[i][k] * l[j][k]).sum::<f64>();
            if i == j {
                if !(s > 0.0) {
                    return None;
                }
                l[i][i] = s.sqrt();
            } else {
                l[i][j] = s / l[j][j];
            }
        }
    }
    Some(l)
}

// (L y = b, and L^T x = y, for a lower factor L.)
fn forward_solved(l: &[Vec<f64>], b: &[f64]) -> Vec<f64> {
    let mut y = vec![0.0; b.len()];
    for i in 0..b.len() {
        y[i] = (b[i] - (0..i).map(|k| l[i][k] * y[k]).sum::<f64>()) / l[i][i];
    }
    y
}

fn backward_solved(l: &[Vec<f64>], y: &[f64]) -> Vec<f64> {
    let n = y.len();
    let mut x = vec![0.0; n];
    for i in (0..n).rev() {
        x[i] = (y[i] - (i + 1..n).map(|k| l[k][i] * x[k]).sum::<f64>()) / l[i][i];
    }
    x
}

#[cfg(test)]
mod above_tests {
    use super::*;

    // (Two notes on one point, one 5 c flat and one 5 c sharp: least squares leaves the point where it stands; kept above,
    // it raises both 5 c, the flat one to its pitch; its span ending short of that, none.)
    #[test]
    fn notes_kept_above_their_pitches() {
        let (c, r, w) = (vec![vec![1.0], vec![1.0]], [5.0, -5.0], [1.0, 1.0]);
        let (d, _) = joints_move(&c, &r, &w, &[0.0], &[[-10.0, 10.0]]);
        assert!(d[0].abs() < 1e-4, "{d:?}");
        let (d, held) = above_move(&c, &r, &w, &[0.0], &[[-10.0, 10.0]], 0.0).expect("a move kept above");
        assert!((d[0] - 5.0).abs() < 1e-8 && !held[0], "{d:?}");
        assert!(above_move(&c, &r, &w, &[0.0], &[[-10.0, 3.0]], 0.0).is_none());
    }

    // (Points and notes drawn at random, each note's cents to go below what a point drawn within their spans gives it, so
    // that one keeps them: the move kept above keeps them, and its notes' squares are no more than those of any of many
    // moves drawn within the spans that keep them.)
    #[test]
    fn kept_above_no_worse_than_any_drawn() {
        let mut s = 0x2545_F491_4F6C_DD1Du64;
        let mut draw = move || {
            s ^= s << 13;
            s ^= s >> 7;
            s ^= s << 17;
            (s >> 11) as f64 / (1u64 << 53) as f64
        };
        for _ in 0..4 {
            let (k, notes) = (3, 6);
            let c: Vec<Vec<f64>> = (0..notes).map(|_| (0..k).map(|_| 40.0 * draw() - 20.0).collect()).collect();
            let kept: Vec<f64> = (0..k).map(|_| 2.0 * draw() - 1.0).collect();
            let r: Vec<f64> = c.iter().map(|ci| dot(ci, &kept) - 10.0 * draw()).collect();
            let (w, at, within) = (vec![1.0; notes], vec![0.0; k], vec![[-1.0, 1.0]; k]);
            let gives = |d: &[f64]| c.iter().zip(&r).map(|(ci, ri)| dot(ci, d) - ri).collect::<Vec<f64>>();
            let cost = |d: &[f64]| gives(d).iter().map(|v| v * v).sum::<f64>();
            let keeps = |d: &[f64]| gives(d).iter().all(|&v| v >= -1e-7);
            let (d, _) = above_move(&c, &r, &w, &at, &within, 0.0).expect("a move kept above");
            assert!(keeps(&d), "{:?}", gives(&d));
            let best = (0..100_000).map(|_| (0..k).map(|_| 2.0 * draw() - 1.0).collect::<Vec<f64>>()).filter(|d| keeps(d)).map(|d| cost(&d)).fold(f64::INFINITY, f64::min);
            assert!(cost(&d) <= best * (1.0 + 1e-6) + 1e-9, "{} against {best}", cost(&d));
        }
    }
}

// ---- The points' move for notes whose distances and rates are read elsewhere (points.rs: each note heard, each
// point's rate on its own start; native/openwind/tune-body.mjs), here at the file's end. ----

/// The move of its makers' points that takes its notes nearest (pointing's own arithmetic, for rates of any kind):
/// `rates` each note's, cents for a move of one of each point's units; `off` each note's cents from the pitch asked of
/// it and `weights` their weights; `at` where each point stands and `within` its span; `above`, where given, the cents
/// each note is kept at or above its pitch (above_move) -> each point's move (in its unit), which end at their spans'
/// ends, and, where `above` is given, whether a move within the spans keeps every note so (where none does, the
/// least-squares move in its place: joints_move).
pub fn points_move(rates: &[Vec<f64>], off: &[f64], weights: &[f64], at: &[f64], within: &[[f64; 2]], above: Option<f64>) -> Result<(Vec<f64>, Vec<bool>, Option<bool>), String> {
    let k = at.len();
    if k == 0 || within.len() != k || rates.is_empty() || rates.len() != off.len() || weights.len() != off.len() || rates.iter().any(|r| r.len() != k) {
        return Err("each note's rates for every point, its cents off and its weight; each point's value and its span".into());
    }
    if within.iter().zip(at).any(|(w, a)| !(w[0] <= *a && *a <= w[1])) || weights.iter().any(|w| !(*w > 0.0)) {
        return Err("each point within its span, each weight above nothing".into());
    }
    let r: Vec<f64> = off.iter().map(|o| -o).collect();
    let kept = above.and_then(|margin| above_move(rates, &r, weights, at, within, margin));
    let held_above = above.map(|_| kept.is_some());
    let (moved, held) = kept.unwrap_or_else(|| joints_move(rates, &r, weights, at, within));
    Ok((moved, held, held_above))
}

// ---- A held note's period's rates alone, each solved as far as asked (native/openwind-tuner src/joint_run.rs; the
// owner, 14 November 2026, of the body and its player found at once: "Yes, optimize the fitting"), here at the file's
// end so that no line above it moves. Profiled that day on the clarinet's written C5: of the 40 s its 135 moves' rates
// took, a quarter went to the map and the rest to keeping each new direction apart from the 1600 kept -- twelve new a
// move, each solved to RATED, its whole state's move kept though its period's alone was read. ----

/// Directions an operator has been applied to, kept for solves whose answer's last value alone is read (gcr_last): what
/// the operator makes of each (`c`, orthonormal) and, of the direction so combined, its last value (`last`).
#[derive(Default)]
struct KeptLast {
    c: Vec<Vec<f64>>,
    last: Vec<f64>,
}

/// As gcr_kept, its answer's last value alone -> that value, and its residual's size against `b`'s. Each direction is
/// the residual it was begun from and is never applied again, so of the directions themselves only what the answer
/// reads of them is kept: their last values.
fn gcr_last(b: &[f64], tolerance: f64, kept: &mut KeptLast, mut apply: impl FnMut(&[f64]) -> Result<Vec<f64>, String>) -> Result<(f64, f64), String> {
    let beta = norm(b);
    if beta == 0.0 || b.is_empty() {
        return Ok((0.0, 0.0));
    }
    let (mut x, mut r) = (0.0, b.to_vec());
    for (c, last) in kept.c.iter().zip(&kept.last) {
        let a = lanes_dot(c, &r);
        x += a * last;
        less(&mut r, a, c);
    }
    let mut new = 0;
    while norm(&r) > tolerance * beta && new < KRYLOV {
        let mut last = r[r.len() - 1];
        let mut c = apply(&r)?;
        let mut size = norm(&c);
        for pass in 0..2 {
            for (cj, lj) in kept.c.iter().zip(&kept.last) {
                let a = lanes_dot(cj, &c);
                less(&mut c, a, cj);
                last -= a * lj;
            }
            let after = norm(&c);
            let enough = after >= 0.7 * size;
            size = after;
            if enough || pass == 1 {
                break;
            }
        }
        if !(size > 0.0 && size.is_finite()) {
            break;
        }
        c.iter_mut().for_each(|v| *v /= size);
        last /= size;
        let a = lanes_dot(&c, &r);
        x += a * last;
        less(&mut r, a, &c);
        kept.c.push(c);
        kept.last.push(last);
        new += 1;
    }
    Ok((x, norm(&r) / beta))
}

/// The orbit's derivative applied to `given` (its state's move, each value's own settling divided out, then its
/// period's), as derivative_kept's solve applies it: the map's own move for the state so moved, less that move, and its
/// motion's for the period's; its phase's condition last.
#[allow(clippy::too_many_arguments)]
fn derivative_applied(map: &mut Map, x: &[f64], t: f64, px: &[f64], rate_x: &[f64], own: &[f64], settled: &[f64], size: f64, given: &[f64]) -> Result<Vec<f64>, String> {
    let m = x.len();
    let v: Vec<f64> = given.iter().enumerate().map(|(i, g)| if i < m { g / settled[i] } else { *g }).collect();
    let (dx, dt) = (&v[..m], v[m]);
    let dn = norm(dx);
    let mut out = vec![0.0; m + 1];
    if dn > 0.0 {
        let e = NUDGE * size / dn;
        let moved: Vec<f64> = x.iter().zip(dx).map(|(a, d)| a + e * d).collect();
        let (pm, _) = map.map(&moved, t)?;
        for i in 0..m {
            out[i] = (pm[i] - px[i]) / e - dx[i];
        }
    }
    for i in 0..m {
        out[i] += rate_x[i] * dt;
    }
    out[m] = dot(own, dx);
    Ok(out)
}

// (How far its orbit, taken up again where `solved_near` left its player and closed again there, may stand from closed
// for its rates to be read there: past it, they are read as `rates` reads them.)
const TAKEN_UP: f64 = 1e-6;

/// As `rates`, its period's move alone for each move asked (Rate::steps; its level's not read, nothing), each
/// derivative solved until its residual is `tolerance` of its right side: its orbit found as `orbit` finds it, its map
/// made ready again where that leaves its player, and each move's solve kept to what its period reads (gcr_last).
pub fn period_rates(player: &mut Player, cols: usize, outs: usize, rate: f64, asked: &Asked, moved: &[Moved], tolerance: f64) -> Result<Found, String> {
    if !(tolerance > 0.0 && tolerance < 1.0) {
        return Err("how far each rate is solved: its residual's share of its right side, between nothing and the whole".into());
    }
    let single = player.single() && !player.crewed();
    if single {
        player.in_doubles(true);
    }
    let found = period_rated(player, cols, outs, rate, asked, moved, tolerance);
    if single {
        player.in_doubles(false);
    }
    found
}

fn period_rated(player: &mut Player, cols: usize, outs: usize, rate: f64, asked: &Asked, moved: &[Moved], tolerance: f64) -> Result<Found, String> {
    let mut found = solved_near(player, cols, outs, rate, asked, &[], None)?;
    if !found.sounds || moved.is_empty() {
        return Ok(found);
    }
    let row = |given: &[f64]| {
        let mut r = given.to_vec();
        if let Some((uj, duj, next)) = asked.jet {
            r[duj] = 0.0;
            r[next] = r[uj];
        }
        r
    };
    let block = 2 * (rate / PITCHES[1]).ceil() as usize + 8;
    let before = player.data().to_vec();
    let before_tract = player.tract.as_ref().map(|tr| tr.state());
    let mut map = Map { player, u: row(asked.row).repeat(block), y: vec![0.0; block * outs], cols, outs, base: vec![], mask: vec![], scale: vec![], kept: vec![], joints: vec![], maps: 0 };
    let mut t = found.steps;
    prepare(&mut map, t)?;
    let mut x = map.read();
    let (mut px, mut rate_x) = map.map(&x, t)?;
    let mut f: Vec<f64> = px.iter().zip(&x).map(|(a, b)| a - b).collect();
    let mut closing = norm(&f) / norm(&x);
    // (Closed again on the map made ready here, by Newton's steps as solved_near takes them: its reed's contact variable,
    // let go over the periods between, leaves it some 1e-5 from closed -- the clarinet's written C#5 to D#5, 2e-6 to
    // 1.2e-5, 14 November 2026.)
    let mut newton = 0;
    while closing > CLOSED && newton < NEWTON && norm(&rate_x) > 0.0 {
        newton += 1;
        let phase: Vec<f64> = {
            let n = norm(&rate_x);
            rate_x.iter().map(|v| v / n).collect()
        };
        let m = x.len();
        let mut b: Vec<f64> = f.iter().map(|v| -v).collect();
        b.push(0.0);
        let (x0, t0, px0, r0) = (x.clone(), t, px.clone(), rate_x.clone());
        let (step, _) = derivative(&mut map, &x0, t0, &px0, &r0, &phase, b, LINEAR)?;
        let (mut scale, mut closer) = (1.0, false);
        while scale >= 1.0 / 16.0 {
            let tried: Vec<f64> = x0.iter().zip(&step[..m]).map(|(a, d)| a + scale * d).collect();
            let tt = t0 + scale * step[m];
            if tt >= rate / PITCHES[0] && tt <= rate / PITCHES[1] {
                let (p2, r2) = map.map(&tried, tt)?;
                let f2: Vec<f64> = p2.iter().zip(&tried).map(|(a, b)| a - b).collect();
                let c2 = norm(&f2) / norm(&tried);
                if c2 < closing {
                    (x, t, px, rate_x, f, closing, closer) = (tried, tt, p2, r2, f2, c2, true);
                    break;
                }
            }
            scale /= 2.0;
        }
        if !closer {
            break;
        }
    }
    if !(closing <= TAKEN_UP) || norm(&rate_x) == 0.0 {
        // (Not closed where it was taken up again: as `rates` reads them, from where its orbit was found.)
        let spent = map.maps;
        map.player.set_data(&before);
        if let (Some(s), Some(tr)) = (&before_tract, map.player.tract.as_mut()) {
            tr.set_state(s);
        }
        let mut whole = solved_near(map.player, cols, outs, rate, asked, moved, None)?;
        whole.maps += found.maps + spent;
        return Ok(whole);
    }
    (found.steps, found.hz, found.closing, found.newton) = (t, rate / t, closing, found.newton + newton);
    let own: Vec<f64> = {
        let n = norm(&rate_x);
        rate_x.iter().map(|v| v / n).collect()
    };
    let own_row = map.u.clone();
    let own_tract = map.player.tract.as_ref().map(|tr| tr.now());
    let own_pulls = map.player.pulls();
    let own_base = map.base.clone();
    let (settled, size) = (map.settled(t), norm(&x));
    // (What a move of nothing reads: the map from its own base taken a step on, as each moved map's is (Map::rebased).
    // Each moved map is set against it, not against the orbit's own: a value the state leaves out that a step moves
    // -- the contact variable of a reed its lay stiffens, never still over a period -- is taken a step on in both, and
    // so reads no move. Set against the orbit's own, every move had carried what that step alone moves the period by:
    // on the clarinet's written C#5 and D#5, 1.0e-3 and -5.4e-4 c a move -- 10 and 5 c a span of each of the body's
    // points, read one side over a ten-thousandth of its span, about rates of 2 to 23 -- and every rate read either
    // side had lost it in its two sides' difference, 14 November 2026.)
    let unmoved = {
        map.base = map.rebased(&x)?;
        let mapped = map.map(&x, t);
        map.base = own_base.clone();
        mapped?.0
    };
    let mut kept = KeptLast::default();
    let to = |map: &mut Map, mv: &Moved, on: bool| {
        if let Some(r) = &mv.row {
            map.u = if on { row(r).repeat(block) } else { own_row.clone() };
        }
        if let (Some(rs), Some(base), Some(tr)) = (&mv.tract, &own_tract, map.player.tract.as_mut()) {
            tr.set(if on { rs.clone() } else { base.clone() }, 0.0);
        }
        if let Some(p) = &mv.pulls {
            pulled_base(map, if on { p } else { &own_pulls });
        }
        if let Some(cs) = &mv.coefficients {
            for &(k, v) in cs {
                map.base[k] = if on { v } else { own_base[k] };
            }
        }
    };
    for mv in moved {
        to(&mut map, mv, true);
        map.base = map.rebased(&x)?;
        let moved_map = map.map(&x, t);
        map.base = own_base.clone();
        to(&mut map, mv, false);
        let (pn, _) = moved_map?;
        let mut b: Vec<f64> = pn.iter().zip(&unmoved).map(|(a, c)| -(a - c)).collect();
        b.push(0.0);
        let (steps, residual) = gcr_last(&b, tolerance, &mut kept, |given| derivative_applied(&mut map, &x, t, &px, &rate_x, &own, &settled, size, given))?;
        found.rates.push(Rate { steps, level: 0.0, residual });
    }
    found.maps += map.maps;
    map.load(&x);
    Ok(found)
}

#[cfg(test)]
mod period_tests {
    use super::*;

    // (An operator on vectors of forty values, the identity and four tenths of a seeded matrix; six right sides one
    // after another, each solved by gcr_kept and by gcr_last on directions kept alike: the last value gcr_last gives is
    // the last of gcr_kept's whole answer, which is the operator's own, and both keep as many directions.)
    #[test]
    fn the_last_value_alone_is_the_last_of_the_whole_answer() {
        let n = 40;
        let mut seed = 20261114u64;
        let mut draw = || {
            seed = seed.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
            ((seed >> 11) as f64) / ((1u64 << 53) as f64) * 2.0 - 1.0
        };
        let a: Vec<Vec<f64>> = (0..n).map(|i| (0..n).map(|j| 0.4 * draw() / (n as f64).sqrt() + if i == j { 1.0 } else { 0.0 }).collect()).collect();
        let apply = |v: &[f64]| -> Result<Vec<f64>, String> { Ok(a.iter().map(|row| dot(row, v)).collect()) };
        let (mut whole, mut last) = (Kept::default(), KeptLast::default());
        let mut new_each = vec![];
        for _ in 0..6 {
            let b: Vec<f64> = (0..n).map(|_| draw()).collect();
            let before = last.c.len();
            let (x, left) = gcr_kept(&b, 1e-11, &mut whole, apply).unwrap();
            let (value, left_last) = gcr_last(&b, 1e-11, &mut last, apply).unwrap();
            assert!(left <= 1e-11 && left_last <= 1e-11, "{left} {left_last}");
            assert!((x[n - 1] - value).abs() <= 1e-9 * (1.0 + x[n - 1].abs()), "{} against {value}", x[n - 1]);
            let back = apply(&x).unwrap();
            assert!(back.iter().zip(&b).all(|(p, q)| (p - q).abs() < 1e-9), "its whole answer is the operator's own");
            assert_eq!(whole.c.len(), last.c.len());
            assert_eq!(last.c.len(), last.last.len());
            new_each.push(last.c.len() - before);
        }
        // (Each right side after the first begins from the directions kept: once they span the whole space, none new.)
        assert!(new_each[0] > 0 && *new_each.last().unwrap() <= new_each[0], "{new_each:?}");
        assert!(last.c.len() <= n, "{} directions for {n} values", last.c.len());
        // (Nothing asked: nothing, at once.)
        assert_eq!(gcr_last(&vec![0.0; n], 1e-11, &mut last, apply).unwrap(), (0.0, 0.0));
    }
}
