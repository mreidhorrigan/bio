// The registry's reader (registry/README.md): every value an instrument, its player, the physics, a method or a test
// takes, each with where it came from -- read here and nowhere else (registry/registry.py reads the same files the same
// way). An object's or player's value is found on its node, else on its parent's, up its tree (`is`); a `strings.*`
// rule is read with the asking node's own values; a derived value computed by its equation (equations.js) from its
// inputs; a value passed down by a law (`passes`) scaled to the asking node and said to be borrowed.
import SOURCES from './sources.json' with {type:'json'};
import CONSTANTS from './physics/constants.json' with {type:'json'};
import EQUATIONS from './physics/equations.json' with {type:'json'};
import MODULES from './modules.json' with {type:'json'};
import BOWED from './objects/bowed.json' with {type:'json'};
import ARTIFASTRING_STRINGS from './objects/artifastring-strings.json' with {type:'json'};
import BOWED_PLAYERS from './players/bowed.json' with {type:'json'};
import WINDS from './objects/winds.json' with {type:'json'};
import WINDS_PLAYERS from './players/winds.json' with {type:'json'};
import STIMULI from './stimuli/stimuli.json' with {type:'json'};
import STRINGS_METHODS from './method/strings.json' with {type:'json'};
import LEVELS_METHODS from './method/levels.json' with {type:'json'};
import {EQUATION} from './equations.js';

// (Every file the registry reads, by its path here: the test holds them to the folder's.)
export const FILES=Object.freeze({'sources.json':SOURCES,'physics/constants.json':CONSTANTS,'physics/equations.json':EQUATIONS,'modules.json':MODULES,
  'objects/bowed.json':BOWED,'objects/artifastring-strings.json':ARTIFASTRING_STRINGS,'players/bowed.json':BOWED_PLAYERS,'objects/winds.json':WINDS,'players/winds.json':WINDS_PLAYERS,'stimuli/stimuli.json':STIMULI,'method/strings.json':STRINGS_METHODS,'method/levels.json':LEVELS_METHODS});
export const KINDS=Object.freeze(['literature','vernacular','other','fit','derived','borrowed','unmeasured','setting']);
const within=(folder,key)=>Object.freeze(Object.assign({},...Object.entries(FILES).filter(([path])=>path.startsWith(`${folder}/`)).map(([,file])=>file[key]??{})));
export const OBJECTS=within('objects','nodes'),PLAYERS=within('players','nodes'),METHODS=within('method','methods');
export {SOURCES,CONSTANTS,EQUATIONS,MODULES,STIMULI};

export const isLeaf=v=>Boolean(v)&&typeof v==='object'&&!Array.isArray(v)&&typeof v.kind==='string';
const tableOf=of=>{if(of==='objects')return OBJECTS;if(of==='players')return PLAYERS;throw new Error(`registry: no tree ${of}`)};

// A node's line up its tree, itself first.
export function lineage(id){
  const out=[];
  for(let at=id;at!=null;at=OBJECTS[at].is){
    if(!Object.hasOwn(OBJECTS,at))throw new Error(`registry: no object ${at}${at===id?'':` (an ancestor of ${id})`}`);
    if(out.includes(at))throw new Error(`registry: ${id}'s tree runs in a circle at ${at}`);
    out.push(at);
  }
  return out;
}
export const children=id=>Object.keys(OBJECTS).filter(k=>OBJECTS[k].is===id);

// The leaf at `path` among a node's values: each key itself, else its rule `*` beside it (the keys it stood for kept, in
// order) -- a string's own value before the rule for every string.
function dig(values,path){
  const go=(at,keys,captures)=>{
    if(!keys.length)return isLeaf(at)?{leaf:at,captures}:null;
    if(!at||typeof at!=='object'||isLeaf(at)||Array.isArray(at))return null;
    const [key,...rest]=keys;
    return (Object.hasOwn(at,key)?go(at[key],rest,captures):null)??(Object.hasOwn(at,'*')?go(at['*'],rest,[...captures,key]):null);
  };
  return go(values,path.split('.'),[]);
}
const fill=(path,captures)=>{let k=0;return path.replace(/\{\}/g,()=>captures[k++])};

// Where an object's value is: on its node, or on the part its path names (`parts`: each a node of its own, on its own
// tree -- a set of strings, a body, a reed), else up its tree -> {leaf, captures, at, part, rest} or null.
function locate(of,id,path){
  const [first,...rest]=path.split('.');
  for(const at of lineage(id)){
    const node=tableOf(of)[at]??{},hit=dig(node.values,path);
    if(hit)return {...hit,at,part:null};
    const part=of==='objects'?OBJECTS[at].parts?.[first]:null;
    if(part&&rest.length)return {at,part,rest:rest.join('.')};
  }
  return null;
}

function resolve(of,id,path,stack){
  const found=locate(of,id,path);
  if(!found)throw new Error(`registry: ${id} has no ${of==='players'?'player value':'value'} ${path} (its tree: ${lineage(id).join(' < ')})`);
  if(found.part){
    const inner=resolve(of,found.part,found.rest,stack);
    return Object.freeze({...inner,id,path,inherited:found.at!==id||inner.inherited,part:found.part});
  }
  const {leaf,at,captures}=found,key=`${of}:${id}:${path}`,inherited=at!==id;
  if(stack.includes(key))throw new Error(`registry: ${path} of ${id} is derived from itself (${stack.join(' <- ')})`);
  if(inherited&&leaf.passes===false)throw new Error(`registry: ${path} is ${at}'s own, and ${id} gives none`);
  // (An input that is a type's range, not one instrument's value, leaves what it derives a range's too: no value.)
  let ranged=leaf.value===undefined&&Array.isArray(leaf.range)&&!leaf.derive&&!leaf.like;
  const read=(node,p,caps,tree=of)=>{
    if(p.startsWith('constant:'))return constant(p.slice('constant:'.length));
    if(p.startsWith('setting:'))return settingEntry(...p.slice('setting:'.length).split(':'),[...stack,key]).value;
    // (Another tree's value, or another node's: 'object:<path>' the asking node's object -- a player's instrument --,
    // 'object:<node>:<path>' or 'player:<node>:<path>' a named node's.)
    const cross=/^(object|player):(?:([^:]+):)?(.+)$/.exec(p);
    if(cross){const [,t,n,rest]=cross;return readIn(t==='object'?'objects':'players',n??node,rest,caps)}
    if(tree!==of)return readIn(tree,node,p,caps);
    const full=fill(p,caps);
    // (A path through `*`: the list of its values over the keys there, in order.)
    if(full.includes('*')){const [before,after]=full.split('*');return keysOf(node,before.replace(/\.$/,''),of).map(k=>read(node,`${before}${k}${after}`,[]))}
    const e=resolve(of,node,full,[...stack,key]);if(e.ranged)ranged=true;return e.value;
  };
  const readIn=(tree,node,p,caps)=>{const full=fill(p,caps);
    if(full.includes('*')){const [before,after]=full.split('*');return keysOf(node,before.replace(/\.$/,''),tree).map(k=>readIn(tree,node,`${before}${k}${after}`,[]))}
    const e=resolve(tree,node,full,[...stack,key]);if(e.ranged)ranged=true;return e.value};
  // (A value to compute on a node: a path, or an equation over paths -- `here` paths read on the asking node.)
  const compute=(node,spec,caps)=>typeof spec==='string'?read(node,spec,caps):equation(spec.equation,{
    ...Object.fromEntries(Object.entries(spec.inputs??{}).map(([name,p])=>[name,read(node,p,caps)])),
    ...Object.fromEntries(Object.entries(spec.here??{}).map(([name,p])=>[name,read(id,p,captures)]))});
  let value=leaf.value??leaf.range??leaf.file??null,kind=leaf.kind,borrowedFrom=null;
  // (A rule on an abstract type is a template for the types below it: no value of its own.)
  if((leaf.derive||leaf.like)&&OBJECTS[id]?.abstract)return Object.freeze({...leaf,id,path,at,inherited,kind,value:null,template:true});
  if(leaf.derive){
    const inputs=Object.fromEntries(Object.entries(leaf.derive.inputs).map(([name,p])=>[name,read(id,p,captures)]));
    value=ranged?null:equation(leaf.derive.equation,inputs);
  }
  // (Like the nearest of its candidates -- or of their keys, each string of each set -- by a quantity's logarithm, the
  // first of them where two are as near: its value taken from it, or the node itself.)
  if(leaf.like){
    const L=leaf.like,target=compute(id,L.here??L.match,captures);
    const options=L.keys?L.candidates.flatMap(c=>keysOf(c,'',of).map(k=>({node:c,caps:[k]}))):L.candidates.map(c=>({node:c,caps:[]}));
    let best=null,score=Infinity;
    for(const o of options){const d=Math.abs(Math.log(compute(o.node,L.match,o.caps)/target));if(d<score){best=o;score=d}}
    value=L.take==='@id'?best.node:compute(best.node,L.take,best.caps);
    borrowedFrom=[best.node,...best.caps].join(' ');
  }
  if(inherited&&leaf.passes?.by&&!(leaf.measuredOn??[]).includes(id)&&!ranged){
    // (Its law the ratio of the asking node's quantities to the node it was measured on: `inputs` read on each, the
    // reference's named with a 0 after them.)
    const at=(node,suffix)=>Object.fromEntries(Object.entries(leaf.passes.inputs).map(([name,p])=>[name+suffix,read(node,p,[])]));
    value=value*equation(leaf.passes.by,{...at(id,''),...at(leaf.passes.reference,'0')});kind='borrowed';borrowedFrom=leaf.passes.reference;
  }
  return Object.freeze({...leaf,id,path,at,inherited,kind,value,...(ranged?{ranged}:{}),...(borrowedFrom?{borrowedFrom}:{})});
}

// An object's value with its provenance: {value, unit, kind, source..., at (the node it is written on), inherited}.
export const entry=(id,path)=>resolve('objects',id,path,[]);
export const value=(id,path)=>entry(id,path).value;
// A player's, on the same tree.
export const playerEntry=(id,path)=>resolve('players',id,path,[]);
export const player=(id,path)=>playerEntry(id,path).value;
// The keys under a group of a node's values, in order, from its node, its parts and its ancestors' (its own first); ''
// the top of its values.
export function keysOf(id,path,of='objects'){
  const out=[],parts=path===''?[]:path.split('.');
  const add=keys=>{for(const k of keys)if(k!=='*'&&!out.includes(k))out.push(k)};
  for(const at of lineage(id)){
    let group=tableOf(of)[at]?.values;
    for(const key of parts)group=group&&typeof group==='object'&&!isLeaf(group)?group[key]:undefined;
    // (Its groups only -- a string, not a value of the set's.)
    if(group&&typeof group==='object'&&!isLeaf(group))add(Object.keys(group).filter(k=>!isLeaf(group[k])));
    const part=parts.length&&of==='objects'?OBJECTS[at].parts?.[parts[0]]:null;
    if(part)add(keysOf(part,parts.slice(1).join('.'),of));
    if(!parts.length&&of==='objects')add(Object.keys(OBJECTS[at].parts??{}));
  }
  return out;
}

// An equation by its name, to call with its inputs ({name: value}); `equation` calls it at once.
export function equationOf(name){
  if(!Object.hasOwn(EQUATION,name)||!Object.hasOwn(EQUATIONS.equations,name))throw new Error(`registry: no equation ${name}`);
  return EQUATION[name];
}
export const equation=(name,inputs)=>equationOf(name)(inputs);
export function constant(name){
  if(!Object.hasOwn(CONSTANTS.constants,name))throw new Error(`registry: no constant ${name}`);
  return CONSTANTS.constants[name].value;
}
// A method's setting with its reason: its value, or computed by its equation from other settings, constants and the
// trees' values ('setting:<method>:<name>', 'constant:<name>', 'object:<node>:<path>', 'player:<node>:<path>').
export function settingEntry(method,name,stack=[]){
  const m=METHODS[method];
  if(!m||!Object.hasOwn(m.settings??{},name))throw new Error(`registry: method ${method} has no setting ${name}`);
  const leaf=m.settings[name],key=`setting:${method}:${name}`;
  if(stack.includes(key))throw new Error(`registry: setting ${method} ${name} is derived from itself`);
  const input=p=>{
    const [kind,...rest]=p.split(':');
    if(kind==='constant')return constant(rest.join(':'));
    if(kind==='setting')return settingEntry(rest[0],rest[1],[...stack,key]).value;
    if(kind==='object')return resolve('objects',rest[0],rest.slice(1).join(':'),[...stack,key]).value;
    if(kind==='player')return resolve('players',rest[0],rest.slice(1).join(':'),[...stack,key]).value;
    throw new Error(`registry: setting ${method} ${name}: no input ${p}`);
  };
  const value=leaf.derive?equation(leaf.derive.equation,Object.fromEntries(Object.entries(leaf.derive.inputs).map(([k,p])=>[k,input(p)]))):leaf.value??leaf.range??null;
  return Object.freeze({...leaf,method,name,value});
}
export const setting=(method,name)=>settingEntry(method,name).value;
export function source(id){
  if(!Object.hasOwn(SOURCES.sources,id))throw new Error(`registry: no source ${id}`);
  return SOURCES.sources[id];
}

// Every value a node holds, its own, its parts' and its ancestors', each rule read for each of its keys -> [path].
export function pathsOf(id,of='objects'){
  const out=[],seen=new Set;
  const add=p=>{if(!out.includes(p))out.push(p)};
  const walk=(group,prefix)=>{
    for(const [key,inner] of Object.entries(group)){
      if(key==='*'){
        for(const k of keysOf(id,prefix.slice(0,-1),of))walk({[k]:inner},prefix);
        continue;
      }
      if(isLeaf(inner))add(prefix+key);
      else if(inner&&typeof inner==='object')walk(inner,`${prefix}${key}.`);
    }
  };
  for(const at of lineage(id)){
    walk(tableOf(of)[at]?.values??{},'');
    for(const [name,part] of Object.entries(of==='objects'?OBJECTS[at].parts??{}:{})){
      if(seen.has(name))continue;seen.add(name);
      for(const p of pathsOf(part,of))add(`${name}.${p}`);
    }
  }
  return out;
}
// A group of a node's values as one object, each leaf its value, in order (its own, its parts' and its ancestors'):
// `group('violin-family', 'change', 'players')` -> {reversal, tremoloReversal, bite: {change, held}, biteFor}.
export function group(id,path,of='objects'){
  const read=of==='players'?player:value,out={},freeze=o=>{for(const v of Object.values(o))if(v&&typeof v==='object')freeze(v);return Object.freeze(o)};
  for(const p of pathsOf(id,of)){
    if(!p.startsWith(`${path}.`))continue;
    const keys=p.slice(path.length+1).split('.');let at=out;
    for(const k of keys.slice(0,-1))at=at[k]??={};
    at[keys.at(-1)]=read(id,p);
  }
  if(!Object.keys(out).length)throw new Error(`registry: ${id} has no group ${path}`);
  return freeze(out);
}
