// A player's MIDI 2.0 played on the strings' dial (native/strings-model/dial.mjs), as the winds' dial plays it (native/
// openwind/dial-midi2.mjs DialMidi2): its notes read as every bowed synth reads them (bowed-midi2.js BowedDecoder) and
// its part compiled as the realtime bridge compiles it (strings-part.mjs StringsPart: a render's compileActions, again as
// each stroke comes), so that a musebot plays the dial as its synthesizer (docs/MUSEBOTS_3_SPECIFICATION.md:
// "Synthesizers ingest the MIDI 2.0 data"). Its notes come as its player sends them, ahead of their times: each time
// more comes, what changed of its part is planned again, what waits from where it first differs let go and its own
// queued, what its host has taken and the part no longer has counted (`late`, its lines sent at once). Its host takes
// the driver's lines untimed, as they are due (musebots-strings-live.cpp: f, h, b, a, p, t, d and r); the compiler's
// hair (x) and noise (n) are the page's own, its end (w) no live part's. The same module on the Mac's dial and the
// website's.
//
//   new StringsMidi2({seat, variant, send(text)})
//     .take(events, now) -- its MIDI 2.0 come since, each {seconds, packet} on the dial's clock, and the dial's clock
//       (s) -- its part compiled again and what changed queued. -> {late, queued, from (the earliest time it changed, s,
//       or null)}
//     .due(now) -> how many lines it sent: those due by `now` (s on the dial's clock), each as its host takes it
//     .waiting: lines still queued; .late, .sent, .strokes
import {BowedDecoder} from '../../public/shared/performers/bowed-midi2.js';
import {readActions} from '../../public/shared/performers/physical-strings.js';
import {StringsPart} from './strings-part.mjs';

// (The driver's actions the live host takes, each as it takes it: its kind, its values and its span, no time.)
const TAKEN=new Set(['f','h','b','a','p','t','d','r']);
export const hostLine=line=>{const [a]=readActions([line]);return TAKEN.has(a.kind)?[a.kind,...a.values,...a.span!=null?[a.span]:[]].join(' '):null};

export class StringsMidi2{
  constructor({seat,variant=0,send}){
    Object.assign(this,{part:new StringsPart({seat,variant}),decoder:new BowedDecoder(),send,queue:[],taken:-Infinity,late:0,sent:0,strokes:0});
  }
  take(events,now){
    for(const stroke of this.decoder.take(events))if(this.part.stroke(stroke))this.strokes++;
    // (What its host has taken: every line due by the last time it was sent its lines.)
    const taken=this.taken,{cancel,lines}=this.part.update({applied:t=>t<=taken,now});
    if(cancel!==null)this.queue=this.queue.filter(entry=>entry.t<cancel);
    let late=0;
    for(const {t,line} of lines){if(t<=taken)late++;this.queue.push({t,line})}
    this.late+=late;
    // (In time order, those at one time as the compiler put them.)
    this.queue.sort((a,b)=>a.t-b.t);
    const from=Math.min(cancel??Infinity,...lines.map(entry=>entry.t));
    return {late,queued:lines.length,from:Number.isFinite(from)?from:null};
  }
  due(now){
    let n=0;while(n<this.queue.length&&this.queue[n].t<=now)n++;
    this.taken=Math.max(this.taken,now);
    if(!n)return 0;
    const out=this.queue.splice(0,n).map(entry=>hostLine(entry.line)).filter(Boolean);
    if(out.length)this.send(`${out.join('\n')}\n`);
    this.sent+=out.length;
    return out.length;
  }
  get waiting(){return this.queue.length}
}
