// One player's instrument as the engine plays it, one code for every program that plays timed actions: the render
// driver (musebots-strings.cpp, a part to a file) and the band's live host (musebots-strings-band.cpp, a band heard at
// once). Its instrument (musebots-instruments.h), its body (musebots-body.h), what each string was last given, and the
// driver's actions -- their vocabulary is the driver's header's -- applied as they come, each at the moment its caller
// has rendered to; its samples rendered through the body, a sample that runs away (not finite, or past RUNAWAY) not let
// poison the rest: the 10 ms before it faded, silence from it, and a fresh instrument made with every string as it was,
// from which the part goes on, each time kept in `recoveries`. Moved here from the driver whole (17 October 2026), so
// that the live band plays what a render plays.
#pragma once
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>
#include "artifastring_instrument.h"
#include "musebots-body.h"
#include "musebots-instruments.h"
#ifdef MUSEBOTS_NOISE
#include "musebots-player-noise.h"
#endif

class MusebotsPlayer {
public:
    static constexpr float RUNAWAY = 2.0f;
    static constexpr long FADE = ARTIFASTRING_INSTRUMENT_SAMPLE_RATE / 100;
    // What each string was last given, to give a fresh instrument.
    struct Bowed { bool on; char kind; float pos, force, vel, acc; };

    // (`bridge`: the strings' forces on the bridge summed, before the body, in place of the sound -- a build with the
    // bridge's force only.)
    MusebotsPlayer(int type, int variant, bool bridge = false)
        : type(type), variant(variant), bridge(bridge), body(ARTIFASTRING_INSTRUMENT_SAMPLE_RATE) {
        instrument = musebotsInstrument(type, variant);
        instrument->set_noise_seed(noiseSeed);
        body.instrument(type, variant);
        body.correct(true, 0);
        body.radiate(body.fittedCorner(), 2, 0);
        for (int s = 0; s < 4; s++) own[s] = instrument->get_physical_constants(s);
    }
    ~MusebotsPlayer() { delete instrument; }
    MusebotsPlayer(const MusebotsPlayer &) = delete;
    MusebotsPlayer &operator=(const MusebotsPlayer &) = delete;

    // (The samples it has rendered.)
    long rendered() const { return done; }
    // Its strings' noise seeded (each string its own, from this and its number: the patched Artifastring's
    // set_noise_seed), so that what it plays is the same however its audio is asked for -- a render's in one piece, a live
    // player's in the blocks its page asks. A fresh instrument after a runaway seeded on from it, its count of them.
    void seed(unsigned long long seed) {
        noiseSeed = seed; rebuilt = 0; instrument->set_noise_seed(seed);
#ifdef MUSEBOTS_NOISE
        noise.seed(seed);
#endif
    }

    // Its next `n` samples into `x`: through its body (not the bridge's force), a runaway recovered as the driver did.
    void render(float *x, int n) {
        if (n <= 0) return;
        const long start = done, target = done + n;
#ifdef MUSEBOTS_NOISE
        // (The player's noise drawn at its every EVERY samples, the strings rendered between.)
        while (noise.active() && done < target) {
            if (done % PlayerNoise::EVERY == 0) {
                float length[4];
                for (int s = 0; s < 4; s++) length[s] = own[s].L;
                noise.step(instrument, done, length);
            }
            strings(x, start, std::min(target, done + PlayerNoise::until(done)));
        }
#endif
        strings(x, start, target);
        // (Through the body once its samples stand: a runaway's recovery heard through it as the rest is.)
        if (!bridge) body.process(x, n);
    }

    // One action (the driver's line, its time already rendered to). -> 0, or 3 where it is invalid (said on stderr), as
    // the driver exits; an unknown action -1.
    int apply(const std::string &line) {
        float t, a, b, c, d, span = 0; int s, straight = 0, n = 0, steps = 0;
        switch (line[0]) {
        case 'w': break;
        case 'f': if ((n = sscanf(line.c_str(), "f\t%f\t%i\t%f\t%f\t%i", &t, &s, &a, &span, &straight)) >= 3) {
            steps = ramp(n, 4, span);
#ifdef MUSEBOTS_RAMPS
            if (steps > 0 && s >= 0 && s < 4) instrument->finger_ramp(s, a, 1.0f, steps, straight == 1); else
#endif
            instrument->finger(s, a);
            if (s >= 0 && s < 4) { fingers[s] = a; firmness[s] = 1; } } break;
        case 'h':
            if ((n = sscanf(line.c_str(), "h\t%f\t%i\t%f\t%f\t%f\t%i", &t, &s, &a, &b, &span, &straight)) < 4 ||
                !std::isfinite(t) || t < 0 || s < 0 || s >= 4 || !std::isfinite(a) || a <= 0 || a >= 1 ||
                !std::isfinite(b) || b <= 0 || b > 1) { fprintf(stderr, "invalid harmonic contact: %s\n", line.c_str()); return 3; }
            steps = ramp(n, 5, span);
#ifdef MUSEBOTS_RAMPS
            if (steps > 0) instrument->finger_ramp(s, a, b, steps, straight == 1); else
#endif
            instrument->finger(s, a, b);
            fingers[s] = a; firmness[s] = b; break;
        case 'b': if ((n = sscanf(line.c_str(), "b\t%f\t%i\t%f\t%f\t%f\t%f\t%i", &t, &s, &a, &b, &c, &span, &straight)) >= 5) {
            steps = ramp(n, 6, span);
#ifdef MUSEBOTS_RAMPS
            if (steps > 0 && s >= 0 && s < 4) instrument->bow_ramp(s, a, b, c, steps, straight == 1); else
#endif
            instrument->bow(s, a, b, c);
            if (s >= 0 && s < 4) bows[s] = {b > 0, 'b', a, b, c, 0}; } break;
        case 'a': if ((n = sscanf(line.c_str(), "a\t%f\t%i\t%f\t%f\t%f\t%f\t%f\t%i", &t, &s, &a, &b, &c, &d, &span, &straight)) >= 6) {
            steps = ramp(n, 7, span);
#ifdef MUSEBOTS_RAMPS
            if (steps > 0 && s >= 0 && s < 4) instrument->bow_accel_ramp(s, a, b, c, d, steps, straight == 1); else
#endif
            instrument->bow_accel(s, a, b, c, d);
            if (s >= 0 && s < 4) bows[s] = {b > 0, 'a', a, b, c, d}; } break;
        // (A pluck's grip and pull taken over its span: Artifastring's pluck, patched.)
        case 'p': if ((n = sscanf(line.c_str(), "p\t%f\t%i\t%f\t%f\t%f", &t, &s, &a, &b, &span)) >= 4) instrument->pluck(s, a, b, ramp(n, 5, span)); break;
        case 't': if ((n = sscanf(line.c_str(), "t\t%f\t%i\t%f\t%f\t%i", &t, &s, &a, &span, &straight)) >= 3 && s >= 0 && s < 4) { tune[s] = a; set(s, ramp(n, 4, span), straight); } break;
        case 'd': if ((n = sscanf(line.c_str(), "d\t%f\t%i\t%f\t%f\t%f\t%i", &t, &s, &a, &b, &span, &straight)) >= 4 && s >= 0 && s < 4) { loss[s] = a; slope[s] = b; set(s, ramp(n, 5, span), straight); } break;
        case 'c': case 'v': {
            float T, L, dd, pl, E, r0 = 0, r2 = 0, eF = 0, eB = 0, eA = 0;
            const bool valette = line[0] == 'v';
            if ((valette ? sscanf(line.c_str(), "v\t%f\t%i\t%f\t%f\t%f\t%f\t%f\t%f\t%f\t%f", &t, &s, &T, &L, &dd, &pl, &E, &eF, &eB, &eA) != 10
                         : sscanf(line.c_str(), "c\t%f\t%i\t%f\t%f\t%f\t%f\t%f\t%f\t%f", &t, &s, &T, &L, &dd, &pl, &E, &r0, &r2) != 9) || s < 0 || s >= 4 ||
                !(T > 0) || !(L > 0) || !(dd > 0) || !(pl > 0) || !(E > 0) || !(r0 >= 0) || !(r2 >= 0) || !(eF >= 0) || !(eB >= 0) || !(eA >= 0) ||
                (valette && !(eF + eB + eA > 0))) { fprintf(stderr, "invalid string: %s\n", line.c_str()); return 3; }
            // (Its decay: r0 + r2 f^2, or Valette's Q's, w / 2 Q.)
            const double EI = E * M_PI * pow(dd, 4) / 64;
            own[s] = replacedString(own[s], type, s, T, L, dd, pl, E, MAX_MODAL_DECAY_MODES, [&](double f, unsigned int m) {
                const double k = (m + 1) * M_PI / L, w = 2 * M_PI * f;
                return valette ? w * (T * (eF + eA / w) + EI * eB * k * k) / (2 * (T + EI * k * k)) : r0 + r2 * f * f; });
            set(s); break;
        }
        case 'u': if ((n = sscanf(line.c_str(), "u\t%f\t%i\t%f\t%f\t%f\t%f\t%i", &t, &s, &a, &b, &c, &span, &straight)) >= 5 && s >= 0 && s < 4) { grip[s][0] = a; grip[s][1] = b; grip[s][2] = c; set(s, ramp(n, 6, span), straight); } break;
        case 'r': if (sscanf(line.c_str(), "r\t%f\t%i\t%f", &t, &s, &a) == 3 && s >= 0 && s < 4) { instrument->finger_damping(s, a); damping[s] = a; } break;
        // (The bow's hair `a` m across the string, moved over its span: the live host's ribbon, its cells as many as the
        // string's modes hold apart; 0 the point bow. What the dial bows with, the renders and the band bow with.)
        case 'x': if ((n = sscanf(line.c_str(), "x\t%f\t%i\t%f\t%f", &t, &s, &a, &span)) >= 3 && s >= 0 && s < 4 && a >= 0) {
            instrument->bow_hair(s, a, ramp(n, 4, span)); hairs[s] = a; } break;
#ifdef MUSEBOTS_FRICTION
        case 'e': {
            float e1, e2, e3, e4, e5;
            if (sscanf(line.c_str(), "e\t%f\t%i\t%f\t%f\t%f\t%f\t%f", &t, &s, &e1, &e2, &e3, &e4, &e5) == 7 && s >= 0 && s < 4) {
                instrument->set_friction_exponential(s, e1, e2, e3, e4, e5);
                exponential[s][0] = e1; exponential[s][1] = e2; exponential[s][2] = e3; exponential[s][3] = e4; exponential[s][4] = e5; }
            break;
        }
#endif
#ifdef MUSEBOTS_TORSION
        case 'q': if (sscanf(line.c_str(), "q\t%f\t%i\t%f\t%f\t%f", &t, &s, &a, &b, &c) == 5 && s >= 0 && s < 4) {
            instrument->set_torsion(s, a, b, c); torsion[s][0] = a; torsion[s][1] = b; torsion[s][2] = c; } break;
#endif
#ifdef MUSEBOTS_NOISE
        // (The player's noise: musebots-player-noise.h.)
        case 'n': { int at = 0;
            if (sscanf(line.c_str(), "n\t%f\t%n", &t, &at) < 1 || at == 0 || !noise.set(line.c_str() + at)) {
                fprintf(stderr, "invalid noise: %s\n", line.c_str()); return 3; }
            break; }
#endif
        default: return -1;
        }
        return 0;
    }

    // (Its slowest mode's decay rate (1/s: a mode's amplitude falls as exp(-rn t), artifastring_string.cpp cache_pc_c),
    // each string's as its last 't' and 'd' left it; 0 where a bow is still on a string, each said.)
    double slowest() const {
        double least = INFINITY;
        for (int s = 0; s < 4; s++) {
            if (bows[s].on) { fprintf(stderr, "string %d still bowed at its last action: not rung down\n", s); least = 0; }
            for (unsigned int n = 0; n < own[s].N && n < (unsigned int) MAX_MODAL_DECAY_MODES; n++)
                least = std::fmin(least, own[s].rn[n] * loss[s] * powf((float) (n + 1), slope[s]));
        }
        return least;
    }

    std::vector<double> recoveries;
    unsigned long long noiseSeed = 0;
    int rebuilt = 0;

private:
    // (Its strings from `done` to `target` into x (x[0] the sample `start`), a runaway recovered as the driver did.)
    void strings(float *x, long start, long target) {
        for (int tries = 0; done < target; tries++) {
            float *at = x + (done - start);
#ifdef MUSEBOTS_BRIDGE_FORCE
            if (bridge) instrument->wait_samples_bridge(at, (int)(target - done));
            else
#endif
            instrument->wait_samples_float(at, (int)(target - done));
            long bad = -1;
            // (A force in newtons is not held to the sound's full scale: only a sample not finite runs away there.)
            for (long i = done; i < target; i++) {
                const float v = x[i - start];
                if (!std::isfinite(v) || (!bridge && std::fabs(v) > RUNAWAY)) { bad = i; break; }
            }
            if (bad < 0) { done = target; break; }
            long from = bad - FADE < done ? done : bad - FADE;
            for (long i = from; i < bad; i++) x[i - start] *= (float)(bad - i) / (float)(bad - from + 1);
            for (long i = bad; i < target; i++) x[i - start] = 0;
            recoveries.push_back((double)bad / ARTIFASTRING_INSTRUMENT_SAMPLE_RATE);
            // (Three times running at one moment: left silent to the next action.)
            if (tries >= 2) { done = target; break; }
            rebuild();
            done = bad;
        }
    }
    // (A trailing duration in the instrument's samples, 0 none; a build without ramps refuses one.)
    static int ramp(int fields, int needed, float seconds) {
        if (fields < needed || !(seconds > 0)) return 0;
#ifndef MUSEBOTS_RAMPS
        fprintf(stderr, "this build has no ramps (MUSEBOTS_RAMPS): a change over %g s refused\n", seconds); exit(3);
#endif
        return (int) lrintf(seconds * ARTIFASTRING_INSTRUMENT_SAMPLE_RATE);
    }
    // (Each string's tension, friction and losses as its last 't', 'u' and 'd' set them, from its own constants; moved
    // over `samples` where given, inside the string.)
    void set(int s, int samples = 0, int straight = 0) {
        String_Physical pc = own[s]; pc.T *= tune[s] * tune[s];
        pc.mu_s *= grip[s][0]; pc.mu_d *= grip[s][1]; pc.v0 *= grip[s][2];
        for (unsigned int n = 0; n < pc.N && n < (unsigned int) MAX_MODAL_DECAY_MODES; n++) pc.rn[n] *= loss[s] * powf((float) (n + 1), slope[s]);
#ifdef MUSEBOTS_RAMPS
        if (samples > 0) { instrument->physical_constants_ramp(s, pc, samples, straight == 1); return; }
#else
        (void) samples; (void) straight;
#endif
        instrument->set_physical_constants(s, pc);
    }
    void rebuild() {
        delete instrument; instrument = musebotsInstrument(type, variant);
        instrument->set_noise_seed(noiseSeed + 0x100000000ULL * (unsigned long long) ++rebuilt);
        for (int s = 0; s < 4; s++) {
            String_Physical pc = own[s]; pc.T *= tune[s] * tune[s];
            pc.mu_s *= grip[s][0]; pc.mu_d *= grip[s][1]; pc.v0 *= grip[s][2];
            for (unsigned int n = 0; n < pc.N && n < (unsigned int) MAX_MODAL_DECAY_MODES; n++) pc.rn[n] *= loss[s] * powf((float) (n + 1), slope[s]);
            instrument->set_physical_constants(s, pc);
            if (damping[s] >= 0) instrument->finger_damping(s, damping[s]);
            instrument->bow_hair(s, hairs[s], 0);
#ifdef MUSEBOTS_TORSION
            instrument->set_torsion(s, torsion[s][0], torsion[s][1], torsion[s][2]);
#endif
#ifdef MUSEBOTS_FRICTION
            if (exponential[s][0] > 0) instrument->set_friction_exponential(s, exponential[s][0], exponential[s][1], exponential[s][2], exponential[s][3], exponential[s][4]);
#endif
            instrument->finger(s, fingers[s], firmness[s]);
            if (bows[s].on) instrument->bow(s, bows[s].pos, bows[s].force, bows[s].vel);
        }
#ifdef MUSEBOTS_NOISE
        noise.restore(instrument);
#endif
    }

    int type, variant;
    bool bridge;
    ArtifastringInstrument *instrument = nullptr;
    MusebotsBody body;
    long done = 0;
#ifdef MUSEBOTS_NOISE
    PlayerNoise noise;
#endif
    String_Physical own[4];
    float tune[4] = {1, 1, 1, 1}, loss[4] = {1, 1, 1, 1}, slope[4] = {0, 0, 0, 0};
    float grip[4][3] = {{1, 1, 1}, {1, 1, 1}, {1, 1, 1}, {1, 1, 1}};
    float fingers[4] = {0, 0, 0, 0}, damping[4] = {-1, -1, -1, -1}, firmness[4] = {1, 1, 1, 1}, hairs[4] = {0, 0, 0, 0};
    // (Each string's torsion as its last q set it: speed, impedance, Q; impedance 0 none.)
    float torsion[4][3] = {{0, 0, 1}, {0, 0, 1}, {0, 0, 1}, {0, 0, 1}};
    // (Each string's two-exponential friction as its last e set it: mu_s, mu_d, a, v1, v2; mu_s 0 none.)
    float exponential[4][5] = {{0, 0, 1, 1, 1}, {0, 0, 1, 1, 1}, {0, 0, 1, 1, 1}, {0, 0, 1, 1, 1}};
    Bowed bows[4] = {{false, 0, 0, 0, 0, 0}, {false, 0, 0, 0, 0, 0}, {false, 0, 0, 0, 0, 0}, {false, 0, 0, 0, 0, 0}};
};
