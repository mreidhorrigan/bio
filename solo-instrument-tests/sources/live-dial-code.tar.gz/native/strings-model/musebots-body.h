// The bowed strings' body as every program that plays them hears it, one code: the render driver's (musebots-strings.cpp)
// and the live host's (musebots-strings-live.cpp) -- the owner, 17 October 2026: the live engine and the renders had been
// split, the radiation reaching the live page and not the renders. Artifastring's sound, its offset from zero (the bow's
// friction leaves one) blocked under MUSEBOTS_BODY_DC_HZ; its body corrected to its instrument's radiation (Artifastring's
// bodies fall as a low-pass does above their bridge hill: a minimum-phase FIR an instrument's variant, designed by
// scripts/design-string-bodies.mjs); and radiating as a body does under its corner -- nothing at 0 Hz, falling 12 dB an
// octave (order 2) or 24 (order 4), Butterworth high-passes: the corner where the correction's own cut stops, fitted to
// continue its target (native/strings-model/body_target.py --fit --write). Its tables baked at build time from the files
// that hold them (engine.mjs writes musebots-body-tables.h from render/node/string-body-corrections.json and
// string-body-radiation.json; the contrabass's, the cello's scaled as its body is: musebots-instruments.h). Every change moves along a raised cosine over the samples asked: the correction's share,
// the radiation's share and order, its corner along a geometric line. An instrument set comes in at rest, its filters'
// memories cleared.
#pragma once
#include <algorithm>
#include <cmath>
#include <vector>
#include "musebots-body-tables.h"

class MusebotsBody {
public:
    explicit MusebotsBody(double rate) : rate(rate) {}

    // (An instrument's body: its variant's correction, at the tables' rate only; its fitted corner.)
    void instrument(int type, int variant) {
        fir.clear();
        fitted = 0;
        if (type >= 0 && type < MUSEBOTS_BODY_INSTRUMENTS && rate == MUSEBOTS_BODY_RATE && MUSEBOTS_BODY_COUNT[type] > 0) {
            const double *taps = MUSEBOTS_BODY_FIRS[type][variant % MUSEBOTS_BODY_COUNT[type]];
            fir.assign(taps, taps + MUSEBOTS_BODY_TAPS[type]);
            std::reverse(fir.begin(), fir.end());
            fitted = MUSEBOTS_BODY_CORNER[type];
        }
        history.assign(2 * std::max<size_t>(1, fir.size()), 0.0);
        at = 0;
        dcX1 = dcY1 = 0;
        dcR = MUSEBOTS_BODY_DC_HZ > 0 ? 1 - 2 * M_PI * MUSEBOTS_BODY_DC_HZ / rate : 1;
        for (Section *f : {&second, &fourth[0], &fourth[1]}) f->x1 = f->x2 = f->y1 = f->y2 = 0;
    }
    // (The corner where the instrument's correction stops: the radiation's under a corrected body.)
    double fittedCorner() const { return fitted; }
    bool correctable() const { return !fir.empty(); }

    // (The correction's share to 1 (on) or 0 over `samples`.)
    void correct(bool on, long samples) {
        correctedFrom = corrected; correctedTarget = on && !fir.empty() ? 1 : 0; correctAt = done; correctSamples = samples;
    }
    // (Radiating under `hz` (0: not), order 2 or 4, moved over `samples`; the first corner asked set at once, nothing yet
    // heard through it; a corner of 0 leaves the filters at their last.)
    void radiate(double hz, int order, long samples) {
        if (cornerTarget == 0 && hz > 0) { corner = cornerFrom = cornerTarget = hz; designs(hz); }
        cornerFrom = corner; cornerTarget = hz > 0 ? hz : corner; wetFrom = wet; wetTarget = hz > 0 ? 1 : 0;
        steepFrom = steep; steepTarget = order == 4 ? 1 : 0; radiateAt = done; radiateSamples = samples;
    }

    void process(float *x, int frames) {
        if (!fir.empty() && (corrected > 0 || correctedTarget > 0)) for (int i = 0; i < frames; i++) {
            if (corrected != correctedTarget) {
                const double t = correctSamples > 0 ? std::min(1.0, (double) (done + i - correctAt) / correctSamples) : 1;
                corrected = t >= 1 ? correctedTarget : correctedFrom + (correctedTarget - correctedFrom) * (.5 - .5 * cos(M_PI * t));
            }
            const double in = x[i], y = dcR < 1 ? in - dcX1 + dcR * dcY1 : in;
            dcX1 = in; dcY1 = y;
            const int n = (int) fir.size();
            history[at] = history[at + n] = y;
            at = (at + 1) % n;
            double z = 0;
            const double *h = &history[at];
            for (int k = 0; k < n; k++) z += fir[k] * h[k];
            x[i] = (float) ((1 - corrected) * in + corrected * z);
        }
        if (cornerTarget > 0) for (int i = 0; i < frames; i++) {
            const double t = radiateSamples > 0 ? std::min(1.0, (double) (done + i - radiateAt) / radiateSamples) : 1;
            const double eased = .5 - .5 * cos(M_PI * t);
            if (corner != cornerTarget || wet != wetTarget || steep != steepTarget) {
                const double next = t >= 1 ? cornerTarget : cornerFrom * pow(cornerTarget / cornerFrom, t);
                if (next != corner) { corner = next; designs(corner); }
                wet = t >= 1 ? wetTarget : wetFrom + (wetTarget - wetFrom) * eased;
                steep = t >= 1 ? steepTarget : steepFrom + (steepTarget - steepFrom) * eased;
            }
            const double in = x[i], y2 = run(second, in), y4 = run(fourth[1], run(fourth[0], in));
            x[i] = (float) ((1 - wet) * in + wet * ((1 - steep) * y2 + steep * y4));
        }
        done += frames;
    }

private:
    struct Section { double b0 = 0, b1 = 0, b2 = 0, a1 = 0, a2 = 0, x1 = 0, x2 = 0, y1 = 0, y2 = 0; };
    void design(Section &f, double hz, double q) const {
        const double k = tan(M_PI * hz / rate), norm = 1 / (1 + k / q + k * k);
        f.b0 = norm; f.b1 = -2 * norm; f.b2 = norm; f.a1 = 2 * (k * k - 1) * norm; f.a2 = (1 - k / q + k * k) * norm;
    }
    static double run(Section &f, double x) {
        const double y = f.b0 * x + f.b1 * f.x1 + f.b2 * f.x2 - f.a1 * f.y1 - f.a2 * f.y2;
        f.x2 = f.x1; f.x1 = x; f.y2 = f.y1; f.y1 = y;
        return y;
    }
    // (Butterworth's poles: Q 1/sqrt 2 for the second order, 1/(2 cos(pi/8)) and 1/(2 cos(3 pi/8)) for the fourth's pair.)
    void designs(double hz) {
        design(second, hz, M_SQRT1_2); design(fourth[0], hz, 1 / (2 * cos(M_PI / 8))); design(fourth[1], hz, 1 / (2 * cos(3 * M_PI / 8)));
    }

    double rate, fitted = 0;
    long done = 0;
    std::vector<double> fir, history;
    int at = 0;
    double dcR = 1, dcX1 = 0, dcY1 = 0;
    double corrected = 0, correctedFrom = 0, correctedTarget = 0;
    long correctAt = 0, correctSamples = 0;
    Section second, fourth[2];
    double corner = 0, cornerFrom = 0, cornerTarget = 0, wet = 0, wetFrom = 0, wetTarget = 0, steep = 0, steepFrom = 0, steepTarget = 0;
    long radiateAt = 0, radiateSamples = 0;
};
