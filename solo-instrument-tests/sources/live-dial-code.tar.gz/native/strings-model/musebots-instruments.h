// The bowed-string engine's instruments, one code for every program that plays them (the render driver,
// musebots-strings.cpp, and the live host, musebots-strings-live.cpp): Artifastring's own violin, viola and cello (types
// 0, 1 and 2), then every instrument with strings of its own, in the registry's order (public/shared/performers/
// bowed-instruments.js: the contrabass, 3, then each instrument given as data) -- each played on the solver and rates
// of the Artifastring instrument it names, with four strings of its own, measured or derived from what was measured, and
// that instrument's bodies or another's scaled to its size, interim until its own is fitted (engine.mjs bakes them into
// musebots-instrument-tables.h). Each played at its own pitch, never slowed (the owner, 17 October 2026: "make sure we
// actually have a bass").
#pragma once
#include <algorithm>
#include <cmath>
#include "artifastring_instrument.h"
#include "musebots-instrument-tables.h"

static const int MUSEBOTS_ARTIFASTRING = 3;
// (Whether a type is one of the engine's; the Artifastring instrument whose solver and rates it is played on.)
inline bool musebotsType(int type) { return type >= 0 && type < MUSEBOTS_ARTIFASTRING + MUSEBOTS_OWN_COUNT; }
inline InstrumentType artifastringType(int type) {
    return type < MUSEBOTS_ARTIFASTRING ? (InstrumentType) type : (InstrumentType) MUSEBOTS_OWN_SOLVER[type - MUSEBOTS_ARTIFASTRING];
}
// (A string's rate as a multiple of the instrument's.)
inline int rateFactor(int type, int s) { return FS_MULTIPLICATION_FACTOR[artifastringType(type)][s]; }

// A string replaced: its tension (N), length (m), diameter (m), linear density (kg/m) and Young's modulus (Pa), the rest
// of `pc` kept; as many modes as stand under 0.45 of its rate, at most `most` (and the build's MAX_MODAL_DECAY_MODES),
// a multiple of four, each losing `loss(f, n)` (1/s) at its frequency f with the string's stiffness (B its inharmonicity:
// f_n = n f0 sqrt(1 + B n^2)).
template <class Loss>
inline String_Physical replacedString(String_Physical pc, int type, int s, double T, double L, double d, double pl, double E,
                                      unsigned int most, Loss loss) {
    pc.T = (float) T; pc.L = (float) L; pc.d = (float) d; pc.pl = (float) pl; pc.E = (float) E;
    const double f0 = sqrt(T / pl) / (2 * L), B = M_PI * M_PI * M_PI * E * pow(d, 4) / (64 * T * L * L);
    const double highest = 0.45 * ARTIFASTRING_INSTRUMENT_SAMPLE_RATE * rateFactor(type, s);
    const unsigned int cap = std::min(most, (unsigned int) MAX_MODAL_DECAY_MODES);
    unsigned int n = 0;
    while (n < cap) {
        const double f = (n + 1) * f0 * sqrt(1 + B * (n + 1) * (n + 1));
        if (f >= highest) break;
        pc.rn[n] = (float) loss(f, n);
        n++;
    }
    pc.N = n - n % 4;
    return pc;
}

// An own string's loss at a frequency (1/s): its law, r0 + r2 f^2 (the contrabass's, measured), or, where it has a table
// (an instrument given as data: its like string's measured decays by frequency), read between its points, and past its
// last two by their line.
inline double ownLoss(int k, int s, double f) {
    const double *m = MUSEBOTS_OWN_STRINGS[k][s];
    const int count = MUSEBOTS_OWN_LOSS_COUNT[k][s];
    if (count == 0) return m[5] + m[6] * f * f;
    const double *hz = MUSEBOTS_OWN_LOSS[k][s], *r = hz + count;
    if (f <= hz[0]) return r[0];
    for (int i = 1; i < count; i++)
        if (f <= hz[i]) return r[i - 1] + (r[i] - r[i - 1]) * (f - hz[i - 1]) / (hz[i] - hz[i - 1]);
    return r[count - 1] + (r[count - 1] - r[count - 2]) * (f - hz[count - 1]) / (hz[count - 1] - hz[count - 2]);
}

// An instrument of the engine's, at rest: Artifastring's own, or one with strings of its own -- all the modes under each
// string's rate, losing as its strings lose (ownLoss), its body the one of its scaled bodies Artifastring's choice
// gives this variant.
inline ArtifastringInstrument *musebotsInstrument(int type, int variant) {
    ArtifastringInstrument *made = new ArtifastringInstrument(artifastringType(type), variant);
    if (type >= MUSEBOTS_ARTIFASTRING) {
        const int k = type - MUSEBOTS_ARTIFASTRING;
        for (int s = 0; s < 4; s++) {
            const double *m = MUSEBOTS_OWN_STRINGS[k][s];
            made->set_physical_constants(s, replacedString(made->get_physical_constants(s), type, s, m[0], m[1], m[2], m[3], m[4],
                MAX_MODAL_DECAY_MODES, [k, s](double f, unsigned int) { return ownLoss(k, s, f); }));
        }
        // (Artifastring's own choice among its bodies, artifastring_instrument.cpp's.)
        const int count = MUSEBOTS_OWN_BODY_COUNT[k];
        const int body = (variant + variant / count) % count;
        made->set_body(MUSEBOTS_OWN_BODIES[k][body], MUSEBOTS_OWN_BODY_TAPS[k]);
    }
    return made;
}
