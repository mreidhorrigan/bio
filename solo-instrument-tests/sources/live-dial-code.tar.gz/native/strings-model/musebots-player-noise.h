// A string player's noise as the engine plays it, one code for every program that plays the strings (the player's,
// musebots-player.h, the render driver's and the stream's; and the dial's live host): the streams of musebots-noise.h
// (public/shared/noise.js) moving the bow's force, speed and place and each stopping finger's pitch, as
// research/NOISE_AND_TEMPERATURE.md has them -- the owner, 1 November 2026: "Noise is necessary anywhere a human player
// acts". Asked by the action
//   n what sd temperature beta low high [tremorHz tremorQ tremorShare]
// `what` 0 the bow's force or 1 its speed (`sd` a share of the asked value), 2 its place (a share of the string's length)
// or 3 the stopping finger's pitch (cents) -- numbers, as every other field of the driver's actions;
// its profile in Hz; temperature 0 none. Each stream is drawn every EVERY samples of the instrument's, at its index
// there counted from the part's start (so a part is the same however its audio is asked for, and a stream asked late is
// skipped to where it would have stood), and its value moved to over the next EVERY samples inside the string
// (ArtifastringString::player_noise, patches/noise.patch). Its paths are the seat's own: bow/force, bow/speed,
// bow/contact, finger/<string>/pitch, seeded from the player's seed folded to 32 bits (its low word xor its high). One
// bow, so its force, speed and place move every string alike; a finger each string. A fixed dither is the action
// writer's (noise.js dither), added to what it asks. With no noise asked, nothing here touches the instrument: the exact
// machine, sample for sample.
#pragma once
#include <cstdio>
#include <memory>
#include <stdexcept>
#include <string>
#include "artifastring_instrument.h"
#include "musebots-noise.h"

class PlayerNoise {
public:
    static constexpr int EVERY = 64;
    enum Kind { FORCE, SPEED, CONTACT, FINGER, KINDS };

    void seed(unsigned long long s) {
        key = (uint32_t) (s ^ (s >> 32));
        for (Stream &k : kinds) for (std::unique_ptr<musebots_noise::NoiseStream> &x : k.streams) x.reset();
    }
    // One action's fields after its time ("what sd temperature beta low high [tremorHz tremorQ tremorShare]"). -> false
    // where it is invalid.
    bool set(const char *fields) {
        int kind;
        double sd, temperature;
        musebots_noise::Profile p;
        const int got = sscanf(fields, "%d %lf %lf %lf %lf %lf %lf %lf %lf", &kind, &sd, &temperature, &p.beta, &p.low, &p.high,
                               &p.tremorHz, &p.tremorQ, &p.tremorShare);
        if (got != 6 && got != 9) return false;
        if (got == 6) p.tremorHz = p.tremorQ = p.tremorShare = 0;
        if (kind < 0 || kind >= KINDS || !(sd >= 0) || !(temperature >= 0)) return false;
        try { musebots_noise::shaping(p, RATE); } catch (const std::invalid_argument &) { return false; }
        Stream &k = kinds[kind];
        const bool same = k.profile.beta == p.beta && k.profile.low == p.low && k.profile.high == p.high && k.profile.tremorHz == p.tremorHz
            && k.profile.tremorQ == p.tremorQ && k.profile.tremorShare == p.tremorShare;
        if (!same) for (std::unique_ptr<musebots_noise::NoiseStream> &x : k.streams) x.reset();
        k.profile = p; k.size = sd * temperature;
        return true;
    }
    // Whether it moves the instrument: a stream asked, or its last values not yet the exact machine's.
    bool active() const {
        for (const Stream &k : kinds) if (k.size > 0) return true;
        for (int s = 0; s < 4; s++) if (last[s][0] != 1 || last[s][1] != 1 || last[s][2] != 0 || last[s][3] != 1) return true;
        return false;
    }
    // Samples from `at` to its next draw.
    static int until(long at) { return EVERY - (int) (at % EVERY); }
    // At a draw (`at` a multiple of EVERY): each string's values there, moved to over the next EVERY samples; `length`
    // each string's (m).
    void step(ArtifastringInstrument *instrument, long at, const float length[4]) {
        const uint64_t index = (uint64_t) (at / EVERY);
        const double force = draw(FORCE, 0, "bow/force", index), speed = draw(SPEED, 0, "bow/speed", index),
                     contact = draw(CONTACT, 0, "bow/contact", index);
        for (int s = 0; s < 4; s++) {
            const double cents = draw(FINGER, s, "finger/" + std::to_string(s) + "/pitch", index);
            last[s][0] = (float) musebots_noise::played(1, force, kinds[FORCE].size, true);
            last[s][1] = (float) musebots_noise::played(1, speed, kinds[SPEED].size, true);
            last[s][2] = (float) (musebots_noise::played(0, contact, kinds[CONTACT].size, false) * length[s]);
            last[s][3] = (float) pow(2.0, -musebots_noise::played(0, cents, kinds[FINGER].size, false) / 1200);
            instrument->player_noise(s, last[s][0], last[s][1], last[s][2], last[s][3], EVERY);
        }
    }
    // Its last values given a fresh instrument at once (one made again after a runaway, or another).
    void restore(ArtifastringInstrument *instrument) const {
        if (!active()) return;
        for (int s = 0; s < 4; s++) instrument->player_noise(s, last[s][0], last[s][1], last[s][2], last[s][3], 0);
    }

private:
    static constexpr double RATE = (double) ARTIFASTRING_INSTRUMENT_SAMPLE_RATE / EVERY;
    struct Stream { musebots_noise::Profile profile; double size = 0; std::unique_ptr<musebots_noise::NoiseStream> streams[4]; };
    // (A stream's deviate at `index`, made where it is wanted and skipped to there; 0 where none is asked.)
    double draw(int kind, int s, const std::string &path, uint64_t index) {
        Stream &k = kinds[kind];
        if (!(k.size > 0)) { k.streams[s].reset(); return 0; }
        if (k.streams[s] && k.streams[s]->index > index) k.streams[s].reset();
        if (!k.streams[s]) k.streams[s].reset(new musebots_noise::NoiseStream(key, path, RATE, k.profile));
        musebots_noise::NoiseStream &x = *k.streams[s];
        if (x.index < index) x.skip(index - x.index);
        return x.next();
    }
    uint32_t key = 0;
    Stream kinds[KINDS];
    float last[4][4] = {{1, 1, 0, 1}, {1, 1, 0, 1}, {1, 1, 0, 1}, {1, 1, 0, 1}};
};
