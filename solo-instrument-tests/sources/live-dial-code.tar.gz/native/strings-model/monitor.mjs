// What the strings' live dial (dial.mjs) is handed from the Mac: the monitor's gain for a note, measured by the engine's
// render driver, and what Artifastring's built source and the body's tables say -- read by the Mac's server as it goes
// (live.mjs), and by the website's build beforehand for its page (scripts/build-live-site.mjs).
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {mkdirSync,readFileSync} from 'node:fs';
import {basename,dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {SCRATCH} from '../../render/rendered-audio.mjs';
import {MASTERING_PROFILES} from '../../render/master.mjs';
import RADIATION from '../../render/node/string-body-radiation.json' with {type:'json'};
import {ARTIFASTRING_FINGER_DAMPING,ENGINE,FINGER_DAMPING,ensureDriver} from './engine.mjs';
import {variantsOf} from './dial.mjs';

const here=dirname(fileURLToPath(import.meta.url));

// (The monitor's gain: a note -- the note started from; an instrument's neutral note -- rendered by the engine's driver
// (its body as the host's starts, corrected and radiating), its held part's rms brought to the broadcast mastering
// profile's loudness (master.mjs, EBU R128) -- loud enough to hear, and every other setting heard against it. Its sound
// written to claude-scratch/strings-live/<wav>.)
export function monitorDb(path,{type,variant,seed,wav=`${basename(path,'.actions')}.wav`}){
  const DRIVER=ensureDriver();
  const folder=join(SCRATCH,'strings-live');mkdirSync(folder,{recursive:true});
  const file=join(folder,wav),lines=readFileSync(path,'utf8').split('\n').map(line=>line.split('\t'));
  const result=spawnSync('nice',['-n','10',DRIVER,path,file,String(type),String(variant),String(seed)],{stdio:'inherit'});
  if(result.status!==0)throw new Error('the starting note did not render');
  const data=readFileSync(file),rate=data.readUInt32LE(24),samples=new Float32Array(data.buffer.slice(data.byteOffset+44,data.byteOffset+data.length));
  const stroke=lines.filter(f=>f[0]==='a'&&+f[4]>0).at(-1),release=lines.find(f=>(f[0]==='a'||f[0]==='b')&&+f[1]>+stroke[1]&&!(+f[4]>0));
  const from=Math.round(rate*(+stroke[1]+Math.abs(+stroke[5])/+stroke[6])),to=Math.round(rate*(release?+release[1]:samples.length/rate));
  let sum=0;for(let i=from;i<to;i++)sum+=samples[i]**2;
  return MASTERING_PROFILES.broadcast.targetLufs-10*Math.log10(sum/(to-from));
}
// (How many instruments of each kind Artifastring's built source has.)
export const variantsHere=()=>variantsOf(kind=>readFileSync(join(ENGINE,'patched/artifastring/constants',`strings_${kind}.h`),'utf8'));
// (Whether string-body-radiation.json was fitted to string-body-corrections.json as it is.)
export const fittedHere=()=>createHash('sha256').update(readFileSync(join(here,'../../render/node/string-body-corrections.json'))).digest('hex')===RADIATION.corrections.sha256;
// (The stopping finger's damping, N s/m: a fingertip's measured, the engine's, and Artifastring's own before it.)
export const FINGER=Object.freeze({damping:FINGER_DAMPING,artifastring:ARTIFASTRING_FINGER_DAMPING});
