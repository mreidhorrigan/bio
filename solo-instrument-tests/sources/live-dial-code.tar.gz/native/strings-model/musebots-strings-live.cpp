// Musebots' live host for Artifastring (GPL-3.0, Graham Percival): one instrument bowed as its settings arrive, heard at
// once through the Mac's audio output, so that its bowing can be dialled in by ear (the owner, 17 October 2026: "I think
// I need to dial in parameters myself"). native/strings-model/live.mjs runs it behind a page of sliders.
//   musebots-strings-live TYPE(0 violin, 1 viola, 2 cello, 3 contrabass) VARIANT SEED BUFFER_SECONDS [RECORD.wav]
// TYPE as the engine has its instruments, the render driver's (musebots-instruments.h).
// RECORD, where given: everything heard written there too, a 32-bit float WAV, when it stops; with
// MUSEBOTS_LIVE_UNHEARD=1, written there only, nothing sent to the speakers (a test's).
// Built with build.mjs from this file (MUSEBOTS_STRINGS_SOURCE) against variants/live (patches/live.patch:
// wait_samples_both), linked with AudioToolbox (MUSEBOTS_STRINGS_FRAMEWORKS). Its buffer BUFFER_SECONDS long, the least
// a bow's change may take (live.mjs: public/shared/performers/transitions.js), so that a change is heard a buffer or
// three after it is asked.
// Settings on stdin, one a line, as the driver's actions (musebots-strings.cpp) without their time, each taken up at the
// start of the next buffer and moved over its trailing duration (nothing changes in one sample: live.mjs gives each at
// least its kind's least):
//   f string position seconds              a finger at `position` (fraction of the string from the nut)
//   h string position firmness seconds     a finger at `position`, its firmness a share of Artifastring's K_FINGER (a
//                                          light touch sounds a harmonic)
//   r string ratio                         the finger's damping, a share of Artifastring's own
//   p string pos force                     a pluck at `pos` (fraction of the string from the bridge), pulled with `force` N
//   k string T L d pl E mu_s mu_d v0 loss slope seconds [modes]
//                                          the string itself: tension (N), length (m), diameter (m), linear density
//                                          (kg/m), Young's modulus (Pa), static and dynamic friction and its curve's slope
//                                          (Artifastring's mu_s, mu_d, v0), and its modes' losses, mode n's Artifastring's
//                                          own times loss * n^slope -- moved over `seconds` where its modes stay as they
//                                          are; where its length, diameter, density or stiffness changes, or the modes
//                                          under its rate's limit do, set while the sound is brought down and up again
//                                          over a buffer each; `modes` the most it may have (0 or none: Artifastring's
//                                          own count), as many as stand under its rate's limit, those past its own
//                                          losing as its own measured decays' course carries on
//   s seed                                 the model's random numbers seeded again
//   n what sd temperature beta low high [tremorHz tremorQ tremorShare]
//                                          the player's noise (built with -DMUSEBOTS_NOISE: musebots-player-noise.h), as
//                                          the driver's n: `what` 0 the bow's force, 1 its speed, 2 its place, 3 each
//                                          stopping finger's pitch, a seeded stream of its profile times its temperature
//                                          (0 none)
//   z NAME value                           one of the constants Artifastring's source fixed, made variables in the live
//                                          build (patches/live.patch): A_noise (its friction noise), the pluck's
//                                          PLUCK_VELOCITY, PLUCK_DISPLACEMENT, PLUCK_SECONDS, K_PLUCK, R_PLUCK and
//                                          PLUCK_WIDTH, and the finger's FINGER_WIDTH
//   b string pos force vel seconds         the bow at `pos` (fraction of the string from the bridge), `force` (N, 0 lifts
//                                          it), `vel` (m/s, signed)
//   a string pos force vel acc seconds     the bow moving toward `vel` at `acc` (m/s^2): a stroke begun from rest
//   g gain seconds                         the monitor's gain, along a straight line over `seconds`
//   o 0|1 seconds                          what is heard: 0 the instrument's sound (through its body), 1 the strings'
//                                          forces on the bridge before the body, at the sound's loudness (its rms over
//                                          the last BUFFERS buffers matched: A/Bs at matched loudness) -- crossfaded
//                                          along a raised cosine over `seconds`
//   m string stroke end start              the bow turned by itself at each stroke's end: `stroke` m of bow a stroke,
//                                          the bow slowing to the turn over `end` s and on through it, up to speed the
//                                          other way over `start` s (stroke 0: no longer)
//   c what n t1 y1 ... tn yn               the player's attack (public/shared/performers/attack-curves.js): `what` 0 the
//                                          bow's force, 1 its speed, a multiple of the stroke's at `n` points, t s from
//                                          the stroke's start (the first 0), straight between, the last settled -- the
//                                          bow moved along it ATTACK samples at a time at each stroke's start, the one
//                                          set going (a) and each after a turn; n 0: none (the force as asked from the
//                                          start, the speed brought up at its start's acceleration)
//   y string width rate step               a vibrato: `width` cents peak to peak at `rate` Hz, the finger moved a `step`
//                                          (s) at a time about where it stands (width 0: none)
//   l seconds                              every bow lifted and every vibrato stopped, over `seconds`: the strings left
//                                          to ring down (the page closed)
//   i type variant                         another instrument, at rest (brought down and up again as k is)
//   x string width seconds                 the bow's hair `width` m across on the string, moved over `seconds`: cut into
//                                          cells as fine as the string's modes hold apart, each its share of the force,
//                                          its own friction and its mode shapes averaged over it (0: Artifastring's
//                                          point bow)
//   e 0|1 seconds                          the body as the renders hear it (musebots-body.h, one code for both): corrected
//                                          to its instrument's radiation (1, as it starts) or as Artifastring has it (0),
//                                          moved over `seconds`
//   w corner order seconds                 what the body radiates below its lowest air mode: nothing at 0 Hz, falling
//                                          12 dB an octave (order 2) or 24 (order 4) under `corner` Hz -- Artifastring's
//                                          bodies pass 0 Hz (body_response.py) -- moved over `seconds` (corner 0: the
//                                          bodies as Artifastring has them)
// Prints `ready RATE`, each of Artifastring's constants as it has them (`constant NAME value`), each string's own constants (`string s T L d pl E mu_s mu_d v0 N f0`) on every instrument made,
// and `runaway
// SECONDS` where the model ran away and was made again (as the driver recovers: the moment silent), `hair string CELLS
// MM` where the cells the hair bows a string with change (0: the point bow; MM the narrowest the modes hold apart), `unsolved string STEPS` where a string's steps whose hair's
// forces did not settle (counted since its instrument was made) grow, `turn string
// down|up SAMPLE` at each turn (the sample of what is heard it starts at), and `level DB` (what is heard, its rms) every BUFFERS buffers.
// Built by Emscripten (scripts/build-studio.mjs buildStringsLiveWasm) for a page that plays it, the same host with no
// audio of its own: its settings handed over a line at a time (live_say), what it says printed as here, and each buffer
// of what is heard made as the page asks for it (live_fill), the page sounding it (native/live/site).
#ifndef __EMSCRIPTEN__
#include <AudioToolbox/AudioToolbox.h>
#endif
#include <algorithm>
#include <cmath>
#include <condition_variable>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <mutex>
#include <sstream>
#include <string>
#include <vector>
#include "artifastring_instrument.h"
#include "musebots-body.h"
#include "musebots-instruments.h"
#ifdef MUSEBOTS_NOISE
#include "musebots-player-noise.h"
#endif

// (Buffers queued at once: Apple's Audio Queue Services Programming Guide's three -- one playing, one queued, one being
// filled.)
static const int BUFFERS = 3;
static const float RUNAWAY = 2.0f;
static std::mutex lock;
static std::condition_variable quiet;
static bool stopping = false, silent = false;
static std::vector<std::string> pending;
static ArtifastringInstrument *instrument = nullptr;
static int kind = 0, number = 0, frames = 0;
static long done = 0;
// What each string was last given, to give a fresh instrument after a runaway.
struct Bowed { bool on; float pos, force, vel; };
static float fingers[4] = {0, 0, 0, 0};
// (Each string's bow hair across it (m), kept to be set again on an instrument made again.)
static float hairs[4] = {0, 0, 0, 0};
// (Each string's constants, Artifastring's own for the instrument made and as last set (k); its finger's firmness, a
// share of K_FINGER, and damping, a share of its own (h, r).)
static String_Physical own[4], current[4];
static float firmness[4] = {1, 1, 1, 1}, damping[4] = {1, 1, 1, 1};
static Bowed bows[4] = {{false, 0, 0, 0}, {false, 0, 0, 0}, {false, 0, 0, 0}, {false, 0, 0, 0}};
// (Each bow's motion as asked, followed here to turn it: its speed now and the speed it moves toward, at its rate
// (m/s^2), the bow drawn since it last stood still (m), and, where it alternates, its stroke's length (m, 0 not), how
// long a stroke's end takes to slow to the turn and its start to come up to speed (s), whether it is slowing to a turn,
// and the sample of this buffer it turns at (-1 none). A bow slowing to a turn has the next stroke's velocity.)
struct Motion { double v, target, rate, drawn, stroke, end, start; bool stopping; int turnAt; };
static Motion motion[4] = {};
// (The player's attack, as c gives it: each curve's points [t (s from a stroke's start), y (a multiple of the stroke's
// force, or its speed)], straight between, the last settled -- empty, none. Each string's attack under way: the sample
// of what is heard it began at (-1 none), how long its speed takes to come up where no curve shapes it (s), the samples
// its force comes in over -- from rest the bow set on the string, at a turn the curve's departure from the stroke's own
// (the least a bow's force may change: the span of the a that set its stroke going) -- and whether it began from rest.
// Its pieces ATTACK samples at most, each moved straight to where its curves stand at its end: the curves the page
// sends sampled finely enough that straight between them is their shape (attack-curves.js sampledCurve).)
static const int ATTACK = 32;
static std::vector<std::pair<double, double>> curves[2];
struct Onset { long at; double rise; int over; bool fromRest; };
static Onset onsets[4] = {{-1, 0, 0, false}, {-1, 0, 0, false}, {-1, 0, 0, false}, {-1, 0, 0, false}};
static int forceLeast = 0;
static bool attacking() { return !curves[0].empty() || !curves[1].empty(); }
static double curveAt(int what, double t) {
    const std::vector<std::pair<double, double>> &c = curves[what];
    if (c.empty()) return 1;
    if (t <= c[0].first) return c[0].second;
    for (size_t k = 1; k < c.size(); k++)
        if (t < c[k].first) return c[k - 1].second + (c[k].second - c[k - 1].second) * (t - c[k - 1].first) / (c[k].first - c[k - 1].first);
    return c.back().second;
}
// (A stroke's force and speed `t` s into its attack, multiples of its own.)
static double forceAt(const Onset &o, double t) {
    const double in = o.over > 0 ? std::min(1.0, t * ARTIFASTRING_INSTRUMENT_SAMPLE_RATE / o.over) : 1;
    return o.fromRest ? curveAt(0, t) * in : 1 + (curveAt(0, t) - 1) * in;
}
static double speedAt(const Onset &o, double t) { return curves[1].empty() ? (o.rise > 0 ? std::min(1.0, t / o.rise) : 1) : curveAt(1, t); }
static double settles(const Onset &o) {
    return std::max({curves[0].empty() ? 0.0 : curves[0].back().first, curves[1].empty() ? o.rise : curves[1].back().first,
        (double) o.over / ARTIFASTRING_INSTRUMENT_SAMPLE_RATE});
}
// (Each string's speed at each sample of this buffer where its attack moved it, NaN elsewhere: followed below as moved.)
static std::vector<double> attackSpeed[4];
// (Where a string's bow alternates, an asked speed keeps the bow's direction.)
static float keep(int s, float vel) { return motion[s].stroke > 0 && bows[s].on && bows[s].vel != 0 ? std::copysign(vel, bows[s].vel) : vel; }
// (Each string's vibrato: its width (cents, peak to peak, as vibrato.js measures it), its rate (Hz) and its step (s): its
// finger moved about where it stands a step at a time, each a straight segment to where its curve is a step on, as the
// strings' compiler moves it (physical-strings.js); its phase carried on through a change of rate. Width 0: none.)
struct Vibrato { double width, rate, step, phase; };
static Vibrato vibrato[4] = {{0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}, {0, 0, 0, 0}};
// (A finger's place for a pitch `cents` from where it stands.)
static float about(int s, double cents) { return (float) (1 - (1 - fingers[s]) * pow(2, -cents / 1200)); }
// (The monitor's gain and the output's mix, bridge 0 to 1, each moving toward its target a step a sample.)
static double gain = 0, gainTarget = 0, gainStep = 0, mix = 0, mixFrom = 0, mixTarget = 0;
static long mixAt = 0, mixSamples = 0;
static std::vector<float> sound, bridge, recorded;
static bool recording = false, unheard = false;
// (Each output's sum of squares over the last BUFFERS buffers, for matching their loudness.)
static double heard[2][BUFFERS] = {{0}};
// (Artifastring's constants its source fixed, variables in the live build: each settable by its name.)
struct Constant { const char *name; float *value; };
static const Constant CONSTANTS[] = {{"A_noise", &A_noise}, {"PLUCK_VELOCITY", &PLUCK_VELOCITY}, {"PLUCK_DISPLACEMENT", &PLUCK_DISPLACEMENT},
    {"PLUCK_SECONDS", &PLUCK_SECONDS}, {"K_PLUCK", &K_PLUCK}, {"R_PLUCK", &R_PLUCK}, {"PLUCK_WIDTH", &PLUCK_WIDTH}, {"FINGER_WIDTH", &FINGER_WIDTH}};
// (The body every program of the engine hears its strings through (musebots-body.h), as the render driver hears it: its
// offset blocked, corrected to its instrument's radiation, radiating under its corner -- each as the page last asked (on,
// and at the correction's fitted corner, from the start), and kept across an instrument made.)
static MusebotsBody body(ARTIFASTRING_INSTRUMENT_SAMPLE_RATE);
static bool correcting = true;
static double radiating = -1;
static int falling = 2;
static void bodyOf(int type, int variant) {
    body.instrument(type, variant);
    if (radiating < 0) radiating = body.fittedCorner();
    body.correct(correcting, 0);
    body.radiate(radiating, falling, 0);
}

static void constants() {
    for (int s = 0; s < 4; s++) {
        const String_Physical &pc = own[s];
        printf("string %d %g %g %g %g %g %g %g %g %u %g\n", s, pc.T, pc.L, pc.d, pc.pl, pc.E, pc.mu_s, pc.mu_d, pc.v0, pc.N,
               sqrt(pc.T / pc.pl) / (2 * pc.L));
    }
    fflush(stdout);
}
// (Its strings' noise seeded as the players' are: musebots-player.h seed.)
static unsigned long long noise = 0;
#ifdef MUSEBOTS_NOISE
// (The player's noise, as the players play it: musebots-player-noise.h.)
static PlayerNoise playerNoise;
#endif
static void make() {
    delete instrument;
    instrument = musebotsInstrument(kind, number);
    instrument->set_noise_seed(noise);
#ifdef MUSEBOTS_NOISE
    playerNoise.restore(instrument);
#endif
}
static void fresh() {
    make();
    for (int s = 0; s < 4; s++) { own[s] = current[s] = instrument->get_physical_constants(s); firmness[s] = damping[s] = 1; hairs[s] = 0; }
}
static void rebuild() {
    make();
    for (int s = 0; s < 4; s++) {
        instrument->set_physical_constants(s, current[s]);
        instrument->finger_damping(s, damping[s]);
        instrument->finger(s, fingers[s], firmness[s]);
        instrument->bow_hair(s, hairs[s], 0);
        if (bows[s].on) instrument->bow(s, bows[s].pos, bows[s].force, bows[s].vel);
    }
}
// (A string's constants as k asks them, its modes those of Artifastring's own under 0.45 of its rate (the driver's c),
// as many as stand there -- or as many as asked, up to that limit and the most Artifastring keeps losses for: a mode past
// its own count losing as its own measured decays' course carries on, a parabola in frequency fitted by least squares to
// their top quarter (never under its highest).)
static double carried(const String_Physical &o, double f0, double B, unsigned int k) {
    const unsigned int from = o.N - o.N / 4;
    double S[5] = {0}, R[3] = {0};
    for (unsigned int m = from; m < o.N; m++) {
        const double f = (m + 1) * f0 * sqrt(1 + B * (m + 1) * (m + 1)), r = o.rn[m];
        double p = 1;
        for (int i = 0; i < 5; i++) { S[i] += p; if (i < 3) R[i] += p * r; p *= f; }
    }
    // (The normal equations, 3 by 3, by Cramer's rule.)
    const double M[3][3] = {{S[0], S[1], S[2]}, {S[1], S[2], S[3]}, {S[2], S[3], S[4]}};
    auto det = [](const double A[3][3]) { return A[0][0] * (A[1][1] * A[2][2] - A[1][2] * A[2][1]) - A[0][1] * (A[1][0] * A[2][2] - A[1][2] * A[2][0])
        + A[0][2] * (A[1][0] * A[2][1] - A[1][1] * A[2][0]); };
    const double D = det(M);
    double c[3];
    for (int j = 0; j < 3; j++) {
        double A[3][3];
        for (int i = 0; i < 3; i++) for (int l = 0; l < 3; l++) A[i][l] = l == j ? R[i] : M[i][l];
        c[j] = det(A) / D;
    }
    const double f = (k + 1) * f0 * sqrt(1 + B * (k + 1) * (k + 1));
    return std::max((double) o.rn[o.N - 1], c[0] + c[1] * f + c[2] * f * f);
}
static bool asked(const std::string &line, int &s, String_Physical &pc, float &span) {
    float T, L, d, pl, E, mus, mud, v0, loss, slope;
    int most = 0;
    const int got = sscanf(line.c_str(), "k %i %f %f %f %f %f %f %f %f %f %f %f %i", &s, &T, &L, &d, &pl, &E, &mus, &mud, &v0, &loss, &slope, &span, &most);
    if (got < 12 || s < 0 || s >= 4 || !(T > 0) || !(L > 0) || !(d > 0) || !(pl > 0) || !(E > 0) || !(mus >= 0) || !(mud >= 0) || !(v0 > 0)
        || !(loss > 0) || !std::isfinite(slope) || most < 0) return false;
    pc = own[s]; pc.T = T; pc.L = L; pc.d = d; pc.pl = pl; pc.E = E; pc.mu_s = mus; pc.mu_d = mud; pc.v0 = v0;
    const double f0 = sqrt(T / pl) / (2 * L), B = M_PI * M_PI * M_PI * E * pow(d, 4) / (64 * T * L * L);
    const double highest = 0.45 * ARTIFASTRING_INSTRUMENT_SAMPLE_RATE * rateFactor(kind, s);
    const unsigned int cap = most > 0 ? std::min((unsigned int) most, (unsigned int) MAX_MODAL_DECAY_MODES) : own[s].N;
    unsigned int n = 0;
    while (n < cap && (n + 1) * f0 * sqrt(1 + B * (n + 1) * (n + 1)) < highest) n++;
    pc.N = n - n % 4;
    const double of = sqrt(own[s].T / own[s].pl) / (2 * own[s].L), oB = M_PI * M_PI * M_PI * own[s].E * pow(own[s].d, 4) / (64 * own[s].T * own[s].L * own[s].L);
    for (unsigned int k = 0; k < pc.N && k < (unsigned int) MAX_MODAL_DECAY_MODES; k++)
        pc.rn[k] = (k < own[s].N ? own[s].rn[k] : (float) carried(own[s], of, oB, k)) * loss * powf((float) (k + 1), slope);
    return pc.N > 0;
}
// (Whether a setting changes the string's modes or the instrument: set at once, so set while the sound is down.)
static bool structural(const std::string &line) {
    if (line[0] == 'i') return true;
    int s; String_Physical pc; float span;
    if (line[0] != 'k' || !asked(line, s, pc, span)) return false;
    const String_Physical &now = current[s];
    return pc.N != now.N || pc.L != now.L || pc.d != now.d || pc.pl != now.pl || pc.E != now.E;
}
static int samples(float seconds) { return seconds > 0 ? (int) lrintf(seconds * ARTIFASTRING_INSTRUMENT_SAMPLE_RATE) : 0; }
static void apply(const std::string &line) {
    float a, b, c, d, span = 0;
    int s, n;
    switch (line[0]) {
    // (A finger in vibrato: where it stands, its next step going there.)
    case 'f': if (sscanf(line.c_str(), "f %i %f %f", &s, &a, &span) >= 2 && s >= 0 && s < 4) {
        if (vibrato[s].width > 0) { fingers[s] = a; break; }
        if (samples(span) > 0) instrument->finger_ramp(s, a, firmness[s], samples(span)); else instrument->finger(s, a, firmness[s]);
        fingers[s] = a; } break;
    case 'h': if (sscanf(line.c_str(), "h %i %f %f %f", &s, &a, &b, &span) >= 3 && s >= 0 && s < 4 && a >= 0 && a < 1 && b > 0 && b <= 1) {
        fingers[s] = a; firmness[s] = b;
        if (vibrato[s].width > 0) break;
        if (samples(span) > 0) instrument->finger_ramp(s, a, b, samples(span)); else instrument->finger(s, a, b); } break;
    case 'r': if (sscanf(line.c_str(), "r %i %f", &s, &a) == 2 && s >= 0 && s < 4 && a >= 0) { instrument->finger_damping(s, a); damping[s] = a; } break;
    case 'p': span = 0; if (sscanf(line.c_str(), "p %i %f %f %f", &s, &a, &b, &span) >= 3 && s >= 0 && s < 4 && a > 0 && a < 1 && b > 0) instrument->pluck(s, a, b, samples(span)); break;
    case 's': if (sscanf(line.c_str(), "s %i", &n) == 1) {
        srand((unsigned) n); noise = (unsigned long long) n; instrument->set_noise_seed(noise);
#ifdef MUSEBOTS_NOISE
        playerNoise.seed(noise);
#endif
        } break;
#ifdef MUSEBOTS_NOISE
    case 'n': if (!playerNoise.set(line.c_str() + 1)) fprintf(stderr, "invalid noise: %s\n", line.c_str()); break;
#endif
    case 'z': { char key[32];
        if (sscanf(line.c_str(), "z %31s %f", key, &a) == 2 && a >= 0) for (const Constant &k : CONSTANTS) if (!strcmp(k.name, key)) *k.value = a;
        break; }
    case 'k': { String_Physical pc;
        if (!asked(line, s, pc, span)) { fprintf(stderr, "invalid string: %s\n", line.c_str()); break; }
        const String_Physical &now = current[s];
        if (pc.N == now.N && pc.L == now.L && pc.d == now.d && pc.pl == now.pl && pc.E == now.E) instrument->physical_constants_ramp(s, pc, std::max(1, samples(span)));
        else instrument->set_physical_constants(s, pc);
        current[s] = pc;
        printf("modes %d %u\n", s, pc.N); fflush(stdout); break; }
    // (y string width rate step: a vibrato; width 0 none, the finger back where it stands over a step.)
    case 'y': if (sscanf(line.c_str(), "y %i %f %f %f", &s, &a, &b, &c) == 4 && s >= 0 && s < 4 && a >= 0 && b >= 0 && c > 0) {
        if (!(a > 0) && vibrato[s].width > 0) instrument->finger_ramp(s, fingers[s], firmness[s], std::max(1, samples(c)), true);
        vibrato[s].width = a; vibrato[s].rate = b; vibrato[s].step = c; } break;
    case 'b': if (sscanf(line.c_str(), "b %i %f %f %f %f", &s, &a, &b, &c, &span) >= 4 && s >= 0 && s < 4) {
        // (A bow that alternates: its speed reached at its start's acceleration, or, stopping, its place and force moved
        // and its stop let finish.)
        if (b > 0 && motion[s].stroke > 0 && bows[s].on) {
            Motion &m = motion[s];
            c = keep(s, c);
            if (m.stopping) instrument->bow_accel_ramp(s, a, b, 0, (float) m.rate, std::max(1, samples(span)));
            else { m.rate = std::fabs(c) / m.start; m.target = c; instrument->bow_accel_ramp(s, a, b, c, (float) m.rate, std::max(1, samples(span))); }
        } else {
            if (samples(span) > 0) instrument->bow_ramp(s, a, b, c, samples(span)); else instrument->bow(s, a, b, c);
            motion[s].rate = samples(span) > 0 ? std::fabs(c - motion[s].v) / span : INFINITY;
            motion[s].target = c; motion[s].stopping = false;
        }
        // (A bow lifted leaves the string; set down again, it starts from rest.)
        if (b <= 0) { motion[s].v = motion[s].drawn = motion[s].target = 0; motion[s].stopping = false; onsets[s].at = -1; }
        bows[s] = {b > 0, a, b, c}; } break;
    case 'a': if (sscanf(line.c_str(), "a %i %f %f %f %f %f", &s, &a, &b, &c, &d, &span) >= 5 && s >= 0 && s < 4) {
        c = keep(s, c);
        const bool was = bows[s].on;
        if (samples(span) > 0) instrument->bow_accel_ramp(s, a, b, c, d, samples(span)); else instrument->bow_accel(s, a, b, c, d);
        if (!bows[s].on) motion[s].v = motion[s].drawn = 0;
        motion[s].rate = d; motion[s].target = c; motion[s].stopping = false;
        if (b <= 0) motion[s].v = motion[s].drawn = motion[s].target = 0;
        bows[s] = {b > 0, a, b, c};
        // (Its attack, where the player shapes one: from this buffer's start, the bow set on the string where it was
        // lifted.)
        forceLeast = samples(span);
        onsets[s] = b > 0 && attacking() ? Onset{done, d > 0 ? std::fabs(c) / d : 0, forceLeast, !was} : Onset{-1, 0, 0, false}; } break;
    // (m string stroke stop start: the bow turned by itself at each stroke's end, `stroke` m of bow a stroke: stopping over
    // `stop` s, then setting off the other way at `start` m/s^2; stroke 0 no longer.)
    case 'm': if (sscanf(line.c_str(), "m %i %f %f %f", &s, &a, &b, &c) == 4 && s >= 0 && s < 4 && a >= 0 && b > 0 && c > 0) {
        motion[s].stroke = a; motion[s].end = b; motion[s].start = c; } break;
    // (c what n t y ...: the player's attack for the bow's force (0) or speed (1); n 0 none. An attack under way carries
    // on along the curve as it now is.)
    case 'c': { std::istringstream in(line.substr(1));
        int what = -1, count = -1;
        std::vector<std::pair<double, double>> points;
        bool good = (bool) (in >> what >> count) && (what == 0 || what == 1) && count >= 0 && count <= 4096;
        for (int k = 0; good && k < count; k++) {
            double t, y;
            good = (bool) (in >> t >> y) && std::isfinite(t) && std::isfinite(y) && y >= 0 && (k == 0 ? t == 0 : t > points.back().first);
            if (good) points.emplace_back(t, y);
        }
        if (!good) { fprintf(stderr, "invalid attack: %s\n", line.c_str()); break; }
        curves[what] = points; } break;
    case 'g': if ((n = sscanf(line.c_str(), "g %f %f", &a, &span)) >= 1 && a >= 0) {
        gainTarget = a; gainStep = samples(span) > 0 ? (gainTarget - gain) / samples(span) : gainTarget - gain; } break;
    case 'o': if (sscanf(line.c_str(), "o %f %f", &a, &span) >= 1 && (a == 0 || a == 1)) {
        mixFrom = mix; mixTarget = a; mixAt = done; mixSamples = samples(span); } break;
    case 'l': if (sscanf(line.c_str(), "l %f", &span) == 1) for (int k = 0; k < 4; k++) {
        if (vibrato[k].width > 0) { instrument->finger_ramp(k, fingers[k], firmness[k], std::max(1, samples(span)), true); vibrato[k].width = 0; }
        if (bows[k].on) instrument->bow_ramp(k, bows[k].pos, 0, bows[k].vel, std::max(1, samples(span)));
        bows[k].on = false; motion[k].v = motion[k].drawn = motion[k].target = 0; motion[k].stopping = false; onsets[k].at = -1; } break;
    case 'e': if (sscanf(line.c_str(), "e %i %f", &n, &span) >= 1 && (n == 0 || n == 1)) {
        correcting = n == 1; body.correct(correcting, samples(span)); } break;
    case 'x': if (sscanf(line.c_str(), "x %i %f %f", &s, &a, &span) >= 2 && s >= 0 && s < 4 && a >= 0) { instrument->bow_hair(s, a, samples(span)); hairs[s] = a; } break;
    case 'w': if (sscanf(line.c_str(), "w %f %f %f", &a, &b, &span) >= 2 && a >= 0 && a < .45 * ARTIFASTRING_INSTRUMENT_SAMPLE_RATE && (b == 2 || b == 4)) {
        radiating = a; falling = (int) b; body.radiate(a, (int) b, samples(span)); } break;
    case 'i': if (sscanf(line.c_str(), "i %i %i", &s, &n) == 2 && musebotsType(s) && n >= 0) {
        kind = s; number = n;
        for (int k = 0; k < 4; k++) { fingers[k] = 0; bows[k] = {false, 0, 0, 0}; motion[k] = {}; vibrato[k] = {}; onsets[k].at = -1; }
        fresh(); bodyOf(kind, number); constants(); } break;
    default: fprintf(stderr, "unknown setting: %s\n", line.c_str());
    }
}
// (Where the model runs away, as the driver does: the moment before it faded, silence from it, the instrument made again
// with every string's finger and bow as they were.)
static void render() {
    // (In pieces as long as the shortest vibrato's step, each string in vibrato fingered toward its curve a step on; and cut
    // where a bow turns, the next stroke set going there.)
    int piece = frames;
    for (int s = 0; s < 4; s++) if (vibrato[s].width > 0) piece = std::min(piece, std::max(1, samples((float) vibrato[s].step)));
    for (int s = 0; s < 4; s++) std::fill(attackSpeed[s].begin(), attackSpeed[s].end(), NAN);
    for (int at = 0; at < frames;) {
        int n = std::min(piece, frames - at);
#ifdef MUSEBOTS_NOISE
        // (The player's noise drawn at its every EVERY samples of the part, the pieces cut there.)
        if (playerNoise.active()) {
            if ((done + at) % PlayerNoise::EVERY == 0) {
                float length[4];
                for (int s = 0; s < 4; s++) length[s] = current[s].L;
                playerNoise.step(instrument, done + at, length);
            }
            n = std::min(n, PlayerNoise::until(done + at));
        }
#endif
        for (int s = 0; s < 4; s++) {
            Motion &m = motion[s];
            // (A turn: the next stroke's attack begun there, where the player shapes one.)
            if (m.turnAt == at) {
                if (attacking()) onsets[s] = {done + at, m.start, forceLeast, false};
                else instrument->bow_accel_ramp(s, bows[s].pos, bows[s].force, bows[s].vel, (float) (std::fabs(bows[s].vel) / m.start), 1);
            }
            else if (m.turnAt > at) n = std::min(n, m.turnAt - at);
        }
        // (Each attack under way: the bow moved straight to where its curves stand at the piece's end, its speed there
        // followed as moved; the attack done once its curves have settled.)
        for (int s = 0; s < 4; s++) if (onsets[s].at >= 0 && bows[s].on) n = std::min(n, ATTACK);
        for (int s = 0; s < 4; s++) {
            Onset &o = onsets[s];
            if (o.at < 0 || !bows[s].on) continue;
            const double t0 = (double) (done + at - o.at) / ARTIFASTRING_INSTRUMENT_SAMPLE_RATE, t = t0 + (double) n / ARTIFASTRING_INSTRUMENT_SAMPLE_RATE;
            const double v0 = bows[s].vel * speedAt(o, t0), v = bows[s].vel * speedAt(o, t);
            instrument->bow_ramp(s, bows[s].pos, (float) (bows[s].force * forceAt(o, t)), (float) v, n);
            for (int i = 0; i < n; i++) attackSpeed[s][at + i] = v0 + (v - v0) * (i + 1) / n;
            if (t >= settles(o)) o.at = -1;
        }
        for (int s = 0; s < 4; s++) {
            Vibrato &v = vibrato[s];
            if (!(v.width > 0)) continue;
            v.phase = fmod(v.phase + v.rate * n / ARTIFASTRING_INSTRUMENT_SAMPLE_RATE, 1.0);
            instrument->finger_ramp(s, about(s, v.width / 2 * sin(2 * M_PI * v.phase)), firmness[s], n, true);
        }
        instrument->wait_samples_both(sound.data() + at, bridge.data() + at, n);
        at += n;
    }
    for (int i = 0; i < frames; i++) {
        if (std::isfinite(bridge[i]) && std::isfinite(sound[i]) && std::fabs(sound[i]) <= RUNAWAY) continue;
        for (int k = 0; k < i; k++) { const float fade = (float) (i - k) / (float) (i + 1); sound[k] *= fade; bridge[k] *= fade; }
        for (int k = i; k < frames; k++) sound[k] = bridge[k] = 0;
        printf("runaway %.3f\n", (double) (done + i) / ARTIFASTRING_INSTRUMENT_SAMPLE_RATE); fflush(stdout);
        rebuild();
        break;
    }
}
// (A buffer of what is heard made into x, the settings asked since the last taken up first: for the Mac's audio queue,
// or for a page.)
static void produce(float *x) {
    std::vector<std::string> lines;
    { std::lock_guard<std::mutex> hold(lock); lines.swap(pending); }
    // (A setting that changes the string's modes or the instrument held until the sound is down -- brought down over a
    // buffer -- then set, and the sound brought up again over the next.)
    static std::vector<std::string> held;
    static double restore = 0;
    if (!held.empty() && gain == 0) {
        for (const std::string &line : held) apply(line);
        held.clear();
        gainTarget = restore; gainStep = restore / frames;
    }
    for (const std::string &line : lines) {
        if (line.empty()) continue;
        // (A volume asked while the sound is down: the one it comes up to.)
        float asked_gain;
        if (!held.empty() && line[0] == 'g' && sscanf(line.c_str(), "g %f", &asked_gain) == 1 && asked_gain >= 0) { restore = asked_gain; continue; }
        if (!held.empty() || (structural(line) && gain > 0)) {
            if (held.empty()) { restore = gainTarget; gainTarget = 0; gainStep = -gain / frames; }
            held.push_back(line);
        } else apply(line);
    }
    // (A bow that alternates: slowed to the turn where, over its end's time, it would stand still at its stroke's end, and
    // from the sample it does, without waiting there, brought up to speed the other way over its start's time -- every
    // stroke started up, the first and each after a turn alike.)
    for (int s = 0; s < 4; s++) {
        Motion &m = motion[s];
        m.turnAt = -1;
        if (!(m.stroke > 0) || !bows[s].on) continue;
        if (!m.stopping) {
            if (m.v == 0 || std::signbit(m.v) != std::signbit(bows[s].vel)) continue;
            const double rate = std::fabs(bows[s].vel) / m.end;
            if (m.drawn + m.v * m.v / (2 * rate) < m.stroke) continue;
            m.stopping = true; m.target = 0; m.rate = rate; bows[s].vel = -bows[s].vel; onsets[s].at = -1;
            instrument->bow_accel_ramp(s, bows[s].pos, bows[s].force, 0, (float) rate, frames);
        }
        // (The sample it stands still at, as its speed is followed below.)
        const long still = (long) ceil(std::fabs(m.v) / (m.rate / ARTIFASTRING_INSTRUMENT_SAMPLE_RATE) - 1e-9);
        if (still < frames) m.turnAt = (int) still;
    }
    render();
    for (int s = 0; s < 4; s++) {
        Motion &m = motion[s];
        if (!bows[s].on) continue;
        const double step = std::isfinite(m.rate) ? m.rate / ARTIFASTRING_INSTRUMENT_SAMPLE_RATE : INFINITY;
        for (int i = 0; i < frames; i++) {
            if (i == m.turnAt) {
                m.stopping = false; m.target = bows[s].vel; m.rate = std::fabs(bows[s].vel) / m.start;
                printf("turn %d %s %ld\n", s, bows[s].vel > 0 ? "down" : "up", done + i); fflush(stdout);
            }
            const double was = m.v, gap = m.target - m.v;
            m.v = !std::isnan(attackSpeed[s][i]) ? attackSpeed[s][i] : std::fabs(gap) <= step ? m.target : m.v + std::copysign(step, gap);
            // (Its stroke measured from where the bow last stood still.)
            if (was != 0 && (m.v == 0 || std::signbit(m.v) != std::signbit(was))) m.drawn = 0;
            m.drawn += std::fabs(m.v) / ARTIFASTRING_INSTRUMENT_SAMPLE_RATE;
        }
    }
    body.process(sound.data(), frames);
    static int slot = 0;
    double sums[2] = {0, 0};
    for (int i = 0; i < frames; i++) { sums[0] += (double) sound[i] * sound[i]; sums[1] += (double) bridge[i] * bridge[i]; }
    heard[0][slot] = sums[0]; heard[1][slot] = sums[1]; slot = (slot + 1) % BUFFERS;
    double recent[2] = {0, 0};
    for (int k = 0; k < BUFFERS; k++) { recent[0] += heard[0][k]; recent[1] += heard[1][k]; }
    // (The bridge's force brought to the sound's rms; where either is silent, as it was.)
    static double match = 0;
    if (recent[0] > 0 && recent[1] > 0) match = sqrt(recent[0] / recent[1]);
    for (int i = 0; i < frames; i++, done++) {
        if (mix != mixTarget) {
            const double t = mixSamples > 0 ? (double) (done - mixAt) / mixSamples : 1;
            mix = t >= 1 ? mixTarget : mixFrom + (mixTarget - mixFrom) * (.5 - .5 * cos(M_PI * t));
        }
        if (gain != gainTarget) gain = std::fabs(gainTarget - gain) <= std::fabs(gainStep) ? gainTarget : gain + gainStep;
        x[i] = (float) (gain * ((1 - mix) * sound[i] + mix * match * bridge[i]));
    }
    if (recording) recorded.insert(recorded.end(), x, x + frames);
    // (What is heard, its rms over the last BUFFERS buffers in dB of full scale, said once each BUFFERS buffers: the
    // page's meter.)
    static double out = 0;
    static int count = 0;
    for (int i = 0; i < frames; i++) out += (double) x[i] * x[i];
    // (The points each string's hair touches it at, said where they change.)
    static int points[4] = {1, 1, 1, 1}, unsolved[4] = {0, 0, 0, 0};
    static float cells[4] = {0, 0, 0, 0};
    for (int k = 0; k < 4; k++) {
        const int now = instrument->hair_points(k);
        const float cell = instrument->hair_cell(k);
        if (now != points[k] || fabsf(cell - cells[k]) > 1e-4f) {
            points[k] = now; cells[k] = cell; printf("hair %d %d %.2f\n", k, now, 1000 * cell); fflush(stdout);
        }
        const int failed = instrument->hair_unsolved(k);
        if (failed != unsolved[k]) { unsolved[k] = failed; printf("unsolved %d %d\n", k, failed); fflush(stdout); }
    }
    if (++count == BUFFERS) {
        printf("level %.1f\n", out > 0 ? 10 * log10(out / (BUFFERS * frames)) : -INFINITY); fflush(stdout);
        out = 0; count = 0;
    }
    if (unheard) std::fill(x, x + frames, 0.0f);
}
// (The instrument made, at rest, and its buffers BUFFER_SECONDS long: false where its type, variant or buffer is none.)
static bool begin(int type, int variant, unsigned long long seed, float seconds) {
    kind = type; number = variant;
    if (!musebotsType(kind) || number < 0) { fprintf(stderr, "invalid TYPE or VARIANT: %d %d\n", type, variant); return false; }
    srand((unsigned) seed);
    noise = seed;
#ifdef MUSEBOTS_NOISE
    playerNoise.seed(noise);
#endif
    frames = samples(seconds);
    if (frames <= 0) { fprintf(stderr, "invalid BUFFER_SECONDS: %g\n", (double) seconds); return false; }
    sound.resize(frames); bridge.resize(frames);
    for (int s = 0; s < 4; s++) attackSpeed[s].assign(frames, NAN);
    fresh();
    bodyOf(kind, number);
    return true;
}
// (Its rate, Artifastring's constants and its strings' said, once it is ready to be asked.)
static void ready() {
    printf("ready %d\n", ARTIFASTRING_INSTRUMENT_SAMPLE_RATE);
    for (const Constant &k : CONSTANTS) printf("constant %s %g\n", k.name, *k.value);
    constants();
}
#ifdef __EMSCRIPTEN__
#include <emscripten/emscripten.h>
// (The page's side: the host begun, a setting said, and a buffer made -- its frames at the pointer it gives, read before
// the next is asked.)
static std::vector<float> out;
extern "C" {
EMSCRIPTEN_KEEPALIVE int live_begin(int type, int variant, double seed, double seconds) {
    if (!begin(type, variant, (unsigned long long) seed, (float) seconds)) return 0;
    out.assign(frames, 0.0f);
    ready();
    return frames;
}
EMSCRIPTEN_KEEPALIVE void live_say(const char *line) { pending.push_back(line); }
EMSCRIPTEN_KEEPALIVE float *live_fill() { produce(out.data()); return out.data(); }
}
#else
static void fill(void *, AudioQueueRef queue, AudioQueueBufferRef buffer) {
    produce((float *) buffer->mAudioData);
    buffer->mAudioDataByteSize = (UInt32) (frames * sizeof(float));
    AudioQueueEnqueueBuffer(queue, buffer, 0, nullptr);
    if (stopping && gain == 0) { std::lock_guard<std::mutex> hold(lock); silent = true; quiet.notify_all(); }
}
int main(int argc, char **argv) {
    if (argc < 5) { fprintf(stderr, "usage: musebots-strings-live TYPE VARIANT SEED BUFFER_SECONDS [RECORD.wav]\n"); return 1; }
    recording = argc > 5;
    unheard = recording && getenv("MUSEBOTS_LIVE_UNHEARD") && !strcmp(getenv("MUSEBOTS_LIVE_UNHEARD"), "1");
    if (!begin(atoi(argv[1]), atoi(argv[2]), strtoull(argv[3], NULL, 10), (float) atof(argv[4]))) return 1;
    AudioStreamBasicDescription format = {};
    format.mSampleRate = ARTIFASTRING_INSTRUMENT_SAMPLE_RATE;
    format.mFormatID = kAudioFormatLinearPCM;
    format.mFormatFlags = kAudioFormatFlagIsFloat | kAudioFormatFlagIsPacked;
    format.mBytesPerPacket = format.mBytesPerFrame = sizeof(float);
    format.mFramesPerPacket = format.mChannelsPerFrame = 1;
    format.mBitsPerChannel = 32;
    AudioQueueRef queue;
    // (No run loop given: its callbacks on the queue's own thread.)
    if (AudioQueueNewOutput(&format, fill, nullptr, nullptr, nullptr, 0, &queue)) { fprintf(stderr, "no audio output\n"); return 4; }
    for (int k = 0; k < BUFFERS; k++) {
        AudioQueueBufferRef buffer;
        if (AudioQueueAllocateBuffer(queue, (UInt32) (frames * sizeof(float)), &buffer)) { fprintf(stderr, "no audio buffer\n"); return 4; }
        fill(nullptr, queue, buffer);
    }
    ready();
    if (AudioQueueStart(queue, nullptr)) { fprintf(stderr, "audio output would not start\n"); return 4; }
    std::string line;
    while (std::getline(std::cin, line)) {
        if (line == "q") break;
        std::lock_guard<std::mutex> hold(lock);
        pending.push_back(line);
    }
    // (Stopped, by q or its input's end: its gain brought to nothing over a buffer, and the buffers queued then played
    // out -- never cut.)
    {
        std::unique_lock<std::mutex> hold(lock);
        pending.push_back("g 0 " + std::string(argv[4]));
        stopping = true;
        quiet.wait(hold, [] { return silent; });
    }
    AudioQueueStop(queue, false);
    AudioQueueDispose(queue, true);
    if (recording) {
        FILE *f = fopen(argv[5], "wb");
        if (!f) { fprintf(stderr, "could not write %s\n", argv[5]); return 4; }
        const uint32_t bytes = (uint32_t) (recorded.size() * 4), rate = ARTIFASTRING_INSTRUMENT_SAMPLE_RATE;
        const uint16_t format = 3, channels = 1, align = 4, bits = 32;
        const uint32_t sixteen = 16, whole = 36 + bytes, rateBytes = rate * 4;
        fwrite("RIFF", 1, 4, f); fwrite(&whole, 4, 1, f); fwrite("WAVEfmt ", 1, 8, f); fwrite(&sixteen, 4, 1, f);
        fwrite(&format, 2, 1, f); fwrite(&channels, 2, 1, f); fwrite(&rate, 4, 1, f); fwrite(&rateBytes, 4, 1, f);
        fwrite(&align, 2, 1, f); fwrite(&bits, 2, 1, f); fwrite("data", 1, 4, f); fwrite(&bytes, 4, 1, f);
        fwrite(recorded.data(), 4, recorded.size(), f); fclose(f);
    }
    delete instrument;
    return 0;
}
#endif
