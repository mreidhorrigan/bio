// A bowed player's part compiled as its strokes come (the owner, 2 November 2026: "Centralize in as modular an approach
// as possible, so that the same modules apply to the web versions as to other versions"): its strokes compiled as a
// render compiles them (public/shared/performers/physical-strings.js compileActions), again as each comes -- a stroke
// changes how the one before it ends, joined to it or lifted -- from the last stroke that settles what came before (a
// checkpoint: a bowed stroke begun from silence, the part before it all sounded), and what changed sent again: what its
// player had not taken, in place of what it had; what it had, at once, late. The realtime bridge's (render/node/
// strings-stream.mjs StringsStream) and the strings' live dial's (dial-midi2.mjs StringsMidi2), each a player of its own.
import {compileActions} from '../../public/shared/performers/physical-strings.js';

const timeOf=line=>Number(line.slice(line.indexOf('\t')+1,line.indexOf('\t',line.indexOf('\t')+1)));
// (A stroke the page logged: its time, length and pitch finite, its length positive.)
const strokeOf=entry=>entry&&typeof entry==='object'&&Number.isFinite(entry.at)&&Number.isFinite(entry.seconds)&&Number.isFinite(entry.note)?entry:null;

// One player's part, compiled as its strokes come. update() -> what to tell its player: {cancel, lines} -- `cancel` the
// time (the page's clock, s) from which its waiting actions are let go, or null; `lines` the actions to send after it,
// each {t, line}, those late first.
export class StringsPart{
  constructor({seat,variant=0}){this.seat=seat;this.variant=variant;this.strokes=[];this.from=null;this.sent=[];this.late=0;this.changed=0;this.compiles=0;this.settled=new Set}
  // A stroke as its note was read (BowedDecoder: each time its note is told more -- an earlier Note Off -- whole again):
  // taken, or in place of itself; one settled before, nothing to change.
  stroke(entry){const stroke=strokeOf(entry);if(!stroke||this.settled.has(stroke.id))return false;
    const at=this.strokes.findIndex(each=>each.id===stroke.id);if(at>=0)this.strokes[at]={...stroke};else this.strokes.push({...stroke});return true}
  // The part compiled again. `applied(t)`: whether its player has taken its actions at `t` (rendered past it); `now`:
  // the page's clock (s), before which no stroke comes now.
  update({applied,now}){
    const compiled=compileActions(this.strokes,{seat:this.seat,variant:this.variant,ringsDown:true,...(this.from?{from:this.from}:{})});this.compiles++;
    // (Its end, w, left out: a live part goes on.)
    const plan=compiled.lines.slice(0,-1).map((line,k)=>({t:timeOf(line),line,origin:compiled.origins[k]}));
    // What its player has taken: what the plan has there and it did not take, sent at once; what it took and the plan no
    // longer has, counted.
    const taken=new Map;for(const entry of this.sent)if(applied(entry.t))taken.set(entry.line,(taken.get(entry.line)??0)+1);
    const late=[];for(const entry of plan)if(applied(entry.t)){const count=taken.get(entry.line)??0;if(count)taken.set(entry.line,count-1);else late.push(entry)}
    for(const count of taken.values())this.changed+=count;
    this.late+=late.length;
    // What waits: let go from where it first differs from the plan, and the plan sent from there.
    const waiting=this.sent.filter(entry=>!applied(entry.t)),planned=plan.filter(entry=>!applied(entry.t));
    let i=0;while(i<waiting.length&&i<planned.length&&waiting[i].line===planned[i].line)i++;
    const cancel=i<waiting.length||i<planned.length?Math.min(waiting[i]?.t??Infinity,planned[i]?.t??Infinity):null;
    this.sent=plan;
    this.settle(compiled,{applied,now});
    return {cancel,lines:[...late,...(cancel===null?[]:planned.filter(entry=>entry.t>=cancel))]};
  }
  // Resumes its compiles from its latest checkpoint whose part before it is settled: every stroke before it over (its
  // end before now, so no release can move it) and every action of theirs taken, and none to come before it.
  settle(compiled,{applied,now}){
    // (Those the compiler plays, as it chooses them: compileActions.)
    const valid=stroke=>Number.isFinite(stroke.at)&&stroke.seconds>0&&!(Number.isFinite(stroke.released)&&stroke.released<=stroke.at);
    const order=this.strokes.map((_,i)=>i).filter(i=>valid(this.strokes[i])).sort((a,b)=>this.strokes[a].at-this.strokes[b].at);
    const base=this.from?.index??0,ended=stroke=>Math.min(stroke.at+stroke.seconds,Number.isFinite(stroke.released)?stroke.released:Infinity)<now;
    let settled=null;
    for(const checkpoint of compiled.checkpoints){
      const before=order.slice(0,checkpoint.index-base);
      if(checkpoint.index<=base||!(checkpoint.at<now))continue;
      if(!before.every(i=>ended(this.strokes[i])))break;
      if(this.sent.some(entry=>entry.origin!=null&&entry.origin<checkpoint.index&&!applied(entry.t)))break;
      settled=checkpoint;
    }
    if(!settled)return;
    const gone=new Set(order.slice(0,settled.index-base));
    this.strokes=this.strokes.filter((stroke,i)=>{const kept=!gone.has(i)&&!(!valid(stroke)&&stroke.at<settled.at);if(!kept)this.settled.add(stroke.id);return kept});
    this.sent=this.sent.filter(entry=>entry.origin==null||entry.origin>=settled.index);
    this.from={index:settled.index,state:settled.state};
  }
}
