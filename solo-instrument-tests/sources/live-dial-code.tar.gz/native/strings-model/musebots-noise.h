// The noise of a player's actions, for the native engines: public/shared/noise.js in C++, step for step -- the same
// counter-based source (lowbias32 over the piece's seed, a path's FNV-1a and an index), so its uniforms are the same bits;
// the same Box-Muller deviates and the same shaping (bilinear one-poles an octave apart weighted by the power law, and a
// tremor's resonance), so its streams agree with the page's to the last digits of each library's log, cos and pow
// (test/noise.test.mjs compiles this against noise.js). noise.js says why and how, with its sources; a path is ASCII.
// The tree of temperatures is the page's: an engine is given each parameter's temperature as a number.
#pragma once

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <stdexcept>
#include <string>
#include <vector>

namespace musebots_noise {

inline uint32_t lowbias32(uint32_t x) {
    x ^= x >> 16; x *= 0x7feb352dU; x ^= x >> 15; x *= 0x846ca68bU; x ^= x >> 16;
    return x;
}
// FNV-1a over a text's bytes (public/shared/fnv1a.js, whose code units they are for ASCII).
inline uint32_t fnv1a(const std::string& text, uint32_t h = 2166136261U) {
    for (unsigned char c : text) { h ^= c; h *= 16777619U; }
    return h;
}
inline uint32_t noiseKey(const std::string& path) { return fnv1a(path); }
inline uint32_t noiseBase(uint32_t seed, uint32_t key) { return lowbias32(lowbias32(seed) ^ key); }
inline uint32_t noiseBase(const std::string& seed, uint32_t key) { return lowbias32(lowbias32(fnv1a(seed)) ^ key); }

inline uint32_t noiseWord(uint32_t base, uint64_t c) {
    return lowbias32(lowbias32(base ^ (uint32_t) (c >> 32)) ^ lowbias32((uint32_t) c));
}
// Uniform in (0, 1) at an index: 52 bits and a half, every step exact.
inline double uniformAt(uint32_t base, uint64_t index, int sub = 0) {
    const uint64_t c = index * 4 + (uint64_t) sub * 2;
    return ((double) noiseWord(base, c) * 1048576.0 + (double) (noiseWord(base, c + 1) >> 12) + .5) / 4503599627370496.0;
}
inline double normalAt(uint32_t base, uint64_t index) {
    return std::sqrt(-2 * std::log(uniformAt(base, index, 0))) * std::cos(2 * M_PI * uniformAt(base, index, 1));
}

// A profile: its power falling as 1/f^beta from `low` to `high` (Hz, or cycles an event), and a tremor at tremorHz of
// bandwidth tremorHz/tremorQ carrying tremorShare of the variance (none where its share is 0).
struct Profile { double beta = 0, low = 0, high = 0, tremorHz = 0, tremorQ = 0, tremorShare = 0; };
struct Section { int k; double hz, a, weight, variance; };
struct Shape {
    std::vector<Section> sections;
    double power = 0, share = 0;
    bool tremor = false;
    double p1 = 0, p2 = 0, variance = 0, rho = 0;
};

inline Shape shaping(const Profile& p, double rate) {
    if (!(rate > 0)) throw std::invalid_argument("noise rate");
    if (!(p.low > 0 && p.high >= p.low && p.high < rate / 2)) throw std::invalid_argument("noise band (0 < low <= high < rate/2)");
    if (!(p.beta >= 0 && p.beta <= 2)) throw std::invalid_argument("noise beta (0 to 2)");
    std::vector<double> corners;
    for (double f = p.low; f < p.high * (1 - 1e-9); f *= 2) corners.push_back(f);
    corners.push_back(p.high);
    const int n = (int) corners.size();
    auto span = [&](int k) { return std::log(corners[k + 1] / corners[k]); };
    Shape s;
    for (int k = 0; k < n; k++) {
        const double f = corners[k];
        double w;
        if (p.beta <= 0) w = k == n - 1 ? 1 : 0;
        else if (p.beta >= 2) w = k == 0 ? 1 : 0;
        else {
            w = std::pow(f, -p.beta) * ((k > 0 ? span(k - 1) : 0) + (k < n - 1 ? span(k) : 0)) / 2;
            if (k == 0) w += std::pow(p.low, -p.beta) / (2 - p.beta);
            if (k == n - 1) w += std::pow(p.high, -p.beta) / p.beta;
        }
        if (!(w > 0)) continue;
        const double t = std::tan(M_PI * f / rate), a = (1 - t) / (1 + t);
        s.sections.push_back({k, f, a, w, w * (1 - a) / 2});
    }
    for (const Section& x : s.sections) s.power += x.variance;
    if (p.tremorShare > 0) {
        if (!(p.tremorShare <= 1 && p.tremorHz > 0 && p.tremorHz < rate / 2 && p.tremorQ > 0)) throw std::invalid_argument("noise tremor");
        const double theta = 2 * M_PI * p.tremorHz / rate, r = std::exp(-M_PI * (p.tremorHz / p.tremorQ) / rate);
        s.tremor = true;
        s.share = p.tremorShare;
        s.p1 = 2 * r * std::cos(theta);
        s.p2 = -r * r;
        s.variance = (1 - s.p2) / ((1 + s.p2) * ((1 - s.p2) * (1 - s.p2) - s.p1 * s.p1));
        s.rho = s.p1 / (1 - s.p2);
    }
    return s;
}

// A stream of shaped noise, unit variance from its first draw: next() its next deviate, skip(n) past n as drawn.
class NoiseStream {
public:
    NoiseStream(uint32_t seed, const std::string& path, double rate, const Profile& profile) : shape(shaping(profile, rate)) {
        const uint32_t start = noiseBase(seed, noiseKey(path + "#start"));
        for (const Section& s : shape.sections) {
            bases.push_back(noiseBase(seed, noiseKey(path + "#" + std::to_string(s.k))));
            const double last = normalAt(start, 2 * (uint64_t) s.k + 1);
            lasts.push_back(last);
            states.push_back((1 - s.a) / 2 * last + std::sqrt((1 - s.a * s.a) / 4) * normalAt(start, 2 * (uint64_t) s.k));
            gains.push_back(std::sqrt(s.weight / shape.power));
        }
        if (shape.tremor) {
            tremorBase = noiseBase(seed, noiseKey(path + "#tremor"));
            y2 = std::sqrt(shape.variance) * normalAt(start, 1000);
            y1 = shape.rho * y2 + std::sqrt(shape.variance * (1 - shape.rho * shape.rho)) * normalAt(start, 1001);
        }
    }
    double next() {
        const uint64_t i = index++;
        double power = 0;
        for (size_t k = 0; k < shape.sections.size(); k++) {
            const double a = shape.sections[k].a, x = normalAt(bases[k], i);
            states[k] = a * states[k] + (1 - a) / 2 * (x + lasts[k]);
            lasts[k] = x;
            power += gains[k] * states[k];
        }
        if (!shape.tremor) return power;
        const double y = shape.p1 * y1 + shape.p2 * y2 + normalAt(tremorBase, i);
        y2 = y1;
        y1 = y;
        return std::sqrt(1 - shape.share) * power + std::sqrt(shape.share) * y / std::sqrt(shape.variance);
    }
    NoiseStream& skip(uint64_t n) { for (uint64_t k = 0; k < n; k++) next(); return *this; }
    uint64_t index = 0;
private:
    Shape shape;
    std::vector<uint32_t> bases;
    std::vector<double> lasts, states, gains;
    uint32_t tremorBase = 0;
    double y1 = 0, y2 = 0;
};

// A value as a player gives it (noise.js played), and a path's fixed dither.
inline double played(double value, double deviate, double sd, bool relative, double temperature = 1) {
    const double n = std::max(-4.0, std::min(4.0, deviate)) * sd * temperature;
    return relative ? value * (1 + n) : value + n;
}
inline double dither(uint32_t seed, const std::string& path, double sd, double temperature = 1) {
    return std::max(-4.0, std::min(4.0, normalAt(noiseBase(seed, noiseKey(path)), 0))) * sd * temperature;
}

}  // namespace musebots_noise
