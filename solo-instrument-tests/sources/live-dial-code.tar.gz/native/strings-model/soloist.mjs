// The musebot player on the strings' dial (the owner, 3 November 2026: "we also need to add the musebot-player function
// to the strings (so make sure the strings expose their parameters to the bot for setup, as we've done for the
// aerophones; use the modular factoring to facilitate this"; "Implement the strings' musebot so that it is the same as
// the aerophones' musebot. The MCP handshake process at its startup should establish its relationship to its
// instrument"): its band composes a piece for the dial's instrument as the winds' does (native/live/solo-band.mjs), its
// player bowedstring_clodbot told through its instrument's MCP server, as it starts, the dial's compass -- its lowest
// open string to its fingerboard's end, within its players' compass -- and what the dial plays of its instrument (its
// techniques: STRINGS_ENGINE), and so its personality's tone played as the dial's instrument is. Its strokes, planned
// for the model as a render plans them (audio.js physicalStroke), are its MIDI 2.0, each note sent whole a little ahead,
// as a musebot sends its line (musicxml-performer.js PerformanceFeed), and played on the dial as its synthesizer
// (dial-midi2.mjs StringsMidi2: read back as every bowed synth reads them, compiled as a render compiles them, on the
// dial's variant). The instrument stays as the page dialled it -- its strings' builds, Artifastring's constants, its
// body, its bow's hair, its player's noise and its attack -- so the compiler's own hair and noise are not sent; the
// page's turning bow and vibrato are stopped as a piece starts (its compiler turns its bow and makes its vibrato), and
// every bow lifted as it ends or is stopped. The same module on the Mac's dial and the website's (dial.mjs imports it
// when a piece is first asked for).
//
//   playerOf(instrument) -> {id, instrument}
//   compassOf(instrument, variant, fingerboard) -> [low, high]: the notes the dial's strings reach
//   STRINGS_ENGINE: what the dial says it plays of its instrument (instrument-facts.js `engine`)
//   await composeSolo({instrument, variant, fingerboard, seed, seconds, personality}) -> {player, variant, seed, seconds
//     (its music's), notes: [{at, events}] (each note's MIDI 2.0 whole, s from the piece's start), lead (s: the most any
//     note changed its part ahead of its time, compiled as the dial compiles it), compass, personality, warnings}
//   new StringsLine(composed, {send(text), start, every}) -- `every`, s: the dial's step between its sends
//     .take(now) -> how many lines it sent: the notes due by `now` + its lead given to its StringsMidi2, its lines due by
//     `now` (s on the dial's clock) sent; .done(now); .shown(now) what the page says of it
import {BOWED_INSTRUMENTS} from '../../public/shared/performers/bowed-line.js';
import {opensOf} from '../../public/shared/performers/physical-strings.js';
import {PerformanceFeed} from '../../public/shared/performers/musicxml-performer.js';
import {composeBand,wholeNotes,playerSettingsOf,playerShown} from '../live/solo-band.mjs';
import {StringsMidi2} from './dial-midi2.mjs';
export {playerSettingsOf,playerShown};

export function playerOf(instrument){
  if(!BOWED_INSTRUMENTS[instrument])throw new RangeError(`${instrument}: no musebot plays it yet`);
  return {id:'bowedstring_clodbot',instrument};
}
// (The notes the dial's strings reach: from its lowest open string, as its variant tunes it, to its highest stopped at
// the fingerboard's end (`fingerboard` semitones over it: string-bodies.js fingerboardEnd), within its players' compass.)
export function compassOf(instrument,variant,fingerboard){
  const opens=opensOf(instrument,variant),[low,high]=BOWED_INSTRUMENTS[instrument].range;
  return [Math.max(low,Math.min(...opens)),Math.min(high,Math.max(...opens)+fingerboard)];
}
// (What the dial plays of its instrument: the compiler's bow pressure and contact, natural harmonics and multiphonics,
// each a line its host takes.)
export const STRINGS_ENGINE=Object.freeze({name:'the strings dial (Artifastring)',techniques:Object.freeze(['pressure','contact','harmonic','multiphonic'])});

// (How far ahead of its time each note is sent: the most any of its notes changed its part ahead of its own time -- a
// stroke's bow placed before it sounds, the stroke before it ended as it is joined or lifted -- its part compiled as the
// dial compiles it, each note come PROBE ahead.)
const PROBE=1;
function leadOf(notes,{seat,variant}){
  const midi2=new StringsMidi2({seat,variant,send:()=>{}});let most=0;
  for(const note of notes){const now=note.at-PROBE;midi2.due(now);const {from}=midi2.take(note.events,now);if(from!=null)most=Math.max(most,note.at-from)}
  return most;
}

export async function composeSolo({instrument,variant=0,fingerboard,seed,seconds,personality={}}){
  const player=playerOf(instrument),compass=compassOf(instrument,variant,fingerboard);
  const composed=await composeBand({player,seed,seconds,compass,engine:STRINGS_ENGINE,personality,plan:true});
  const notes=wholeNotes(composed.planned?.ump??[]);
  return {player,variant,seed:composed.seed,seconds:composed.seconds,notes,lead:leadOf(notes,{seat:instrument,variant}),compass,personality:composed.personality,
    warnings:composed.warnings};
}

export class StringsLine{
  constructor(composed,{send,start,every=0}){
    const lead=composed.lead+every;
    Object.assign(this,{composed,start,lead,feed:new PerformanceFeed(composed.notes,{start,lead}),midi2:new StringsMidi2({seat:composed.player.instrument,variant:composed.variant,send})});
    const last=composed.notes.at(-1)?.events.at(-1);
    this.end=start+Math.max(composed.seconds,last?.seconds??0);
  }
  take(now){
    const due=this.feed.due(now);
    if(due.length)this.midi2.take(due,now);
    return this.midi2.due(now);
  }
  done(now){return this.feed.done&&!this.midi2.waiting&&now>=this.end}
  shown(now){
    const {player,seed,seconds,notes,compass,personality,warnings}=this.composed;
    return {player:player.id,instrument:player.instrument,seed,seconds:+seconds.toFixed(3),notes:notes.length,lines:this.midi2.sent,compass,personality,
      lead:+this.lead.toFixed(3),start:+this.start.toFixed(6),at:+Math.max(0,now-this.start).toFixed(3),late:this.midi2.late,unplayed:[],refused:[],warnings};
  }
}
