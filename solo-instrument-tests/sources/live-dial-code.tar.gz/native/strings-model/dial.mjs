// The bowed strings' live dial (native/strings-model/live.mjs's, and the page's, native/live/strings.js): Artifastring
// played live by its host (musebots-strings-live.cpp), its bowing dialled by ear -- the instrument's state as the page
// reads it, each setting the page asks turned into the host's line and moved over the least its kind may take
// (public/shared/performers/transitions.js), and what the host says followed -- behind an environment the one running
// it hands it: its host, the monitor's gains, its variants, and where a setting kept goes. The Mac's server runs it on
// the host built natively, heard through the Mac's audio (live.mjs); the website's page on the host in WebAssembly,
// heard through the page (native/live/site) -- one dial, the same on both (the owner, 2 November 2026: "Centralize in
// as modular an approach as possible, so that the same modules apply to the web versions as to other versions"), as
// native/openwind/dial.mjs is the winds'.
//
//   stringsDial({type, variant, seed, from, start, variants, fitted, gainDb, neutralDb, finger, heardThrough, labels,
//     send, keep, kept, forget, clock, every}) -> {state, heard(line), listen(fn) -> stop, await handle(method, path, body)
//     -> {status, json|text}, due()}
// type, variant, seed: the instrument it starts on; from: the note it starts from, by its name, and start that note's
// bowing (startOf its actions); variants: how many instruments Artifastring has of each kind (variantsOf); fitted:
// whether string-body-radiation.json was fitted to the corrections as they are; gainDb: the monitor's gain for the
// started note, and neutralDb(name, type) an instrument's neutral note's, or null where it has none (live.mjs monitor);
// heardThrough: what it is heard through, said on the page; labels: where a setting kept goes, said to the page; send(text): lines to the host; keep(record), kept(), forget(at)
// -> {left} or null: the settings kept. clock() -> the dial's time, s, as its host is heard -- the Mac's wall clock, the
// website's frames made over its rate -- and every (s), how often its runner calls due(): its musebot player's lines
// sent as they are due (soloist.mjs; the route /soloist).
import {MODEL,ONSETS,PLAYER_NOISE,noiseFields,onsetOf} from '../../public/shared/performers/physical-strings.js';
import {ARTICULATIONS,MARKEDNESS} from '../../public/shared/performers/bowed-articulation.js';
import {curveOf,sampledCurve} from '../../public/shared/performers/attack-curves.js';
import {transition} from '../../public/shared/performers/transitions.js';
import {instrumentRange} from '../../public/shared/performers/instrument-ranges.js';
import {BOW} from '../../public/shared/performers/bow.js';
import {airMode,fingerboardEnd} from '../../public/shared/performers/string-bodies.js';
import {bowedOf} from '../../public/shared/performers/bowed-instruments.js';
import {AUTHORED_VIBRATO,instrumentVibrato} from '../../public/shared/performers/vibrato.js';
import {LEVERS,TONE_RANGES} from '../../public/shared/performers/personality.js';
import {LINE} from '../../public/shared/performers/line.js';
import {gainOf} from '../../render/synthesis/src/strings-parts.mjs';
import BODIES from '../../render/node/string-body-corrections.json' with {type:'json'};
import RADIATION from '../../render/node/string-body-radiation.json' with {type:'json'};
import NEUTRALS from './neutral-notes.json' with {type:'json'};
import {stringsRanges} from '../live/players-ranges.mjs';
import {DEFAULT_SEED} from '../../public/shared/opening-time.js';

// (The engine's instruments in its types' order (physical-strings.js MODEL.types, musebots-instruments.h); each one's
// name to the player, and in string-bodies.js's measurements.)
export const INSTRUMENTS=Object.entries(MODEL.types).sort((a,b)=>a[1]-b[1]).map(([name])=>name);
export const NEUTRAL_NOTES=NEUTRALS.notes;
const least=kind=>transition(kind).least;
// (Where the live dial's strings start (native/live/live.mjs, the website's page): on the violin, from the note the owner
// picked on it (starts/violin-c4-pp.actions, as Start Strings Live Dial.command started it) -- its loudness the one every
// other is heard against, its bowing the good note each other string instrument is given -- on its first variant and
// seed 1; another taken up on the page.)
export const STRINGS_START=Object.freeze({from:'native/strings-model/starts/violin-c4-pp.actions',type:0,variant:0,seed:1});
// (The host's buffer: the least a bow's change may take, so that a change is heard a buffer or three after it is asked.)
export const BUFFER_SECONDS=least('bowForce');
// (The most frames a pull of its sound asks, where its runner renders it as it is pulled rather than heard (live.mjs,
// native/live/site/strings-worker.js): the winds' dial's most (native/openwind/dial.mjs PULL_MOST).)
export const PULL_MOST=16384;
// (The body as the renders hear it -- one code in both, musebots-body.h: its offset blocked, corrected to its instrument's
// radiation (string-body-corrections.json: its bridge hill and its fall above it) -- or, off, as Artifastring has it:
// the host's e.)
const correctionLine=on=>`e ${on?1:0} ${least('any')}`;

// (How many instruments Artifastring has of each kind: its own tables' counts, constants/strings_<kind>.h -- one whose
// body is another's scaled (the registry's bodyScale: the double bass the cello's, the violello the viola's) as
// many as that one's -- each table's text given by its kind's name.)
export const variantsOf=header=>Object.fromEntries(INSTRUMENTS.map(name=>[name,
  +/CONSTANTS_\w+_NUM\s*=\s*(\d+)/.exec(header(bowedOf(name).bodyScale?.from??name))[1]]));

// (The bow the note drew before its release (m): its speed followed from rest toward each line's, at an 'a''s
// acceleration or over a 'b''s duration, in one direction.)
function drawn(lines){
  let v=0,target=0,rate=Infinity,at=null,total=0;
  for(const f of lines.filter(f=>f[0]==='a'||f[0]==='b')){
    const t=+f[1];
    if(at!=null){const dt=t-at,need=target===v?0:Math.abs(target-v)/rate,reach=Math.min(dt,need),end=need<=dt?target:v+Math.sign(target-v)*rate*dt;
      total+=Math.abs(v+end)/2*reach+Math.abs(target)*(dt-reach);v=end}
    if(!(+f[4]>0))break;
    at=t;target=+f[5];rate=f[0]==='a'?+f[6]:+f[6]>0?Math.abs(target-v)/+f[6]:Infinity;
  }
  return total;
}
// (The note's string and finger, and its stroke's bow: its last 'a' with a force, where the stroke was set going -- not
// its release, an 'a' to no force -- from its actions' text.)
export function startOf(text,name){
  const lines=text.split('\n').map(line=>line.split('\t'));
  const finger=lines.find(f=>f[0]==='f'),stroke=lines.filter(f=>f[0]==='a'&&+f[4]>0).at(-1);
  if(!finger||!stroke)throw new Error(`${name}: no finger or no stroke ('f', 'a') to start from`);
  const speed=Math.abs(+stroke[5]);
  return {string:+finger[2],finger:+finger[3],pos:+stroke[3],force:+stroke[4],speed,direction:Math.sign(+stroke[5])||1,startSeconds:speed/+stroke[6],
    drawn:drawn(lines)};
}

// (The attacks the renders play, for the page's curves (attack-curves.js bowedAttack): from silence, the force set on the
// string at MODEL.attackFrom of its own and brought to it over the attack; each named articulation's onset at its
// neutral note's dynamic -- its speed and force over the held bow's, where its force begins and its decay (onsetOf: the
// instrument's fitted onsets, else MODEL.onset's) -- and its bite.)
const attacksOf=name=>{const dynamic=NEUTRAL_NOTES[name]?.dynamic??'mf',onset=ONSETS.instruments?.[name]?.[dynamic]??MODEL.onset;
  return {from:MODEL.attackFrom,least:least('bowForce'),dynamic,fitted:onset!==MODEL.onset,
    articulations:Object.fromEntries(MARKEDNESS.map(a=>{const point=ARTICULATIONS[a];return [a,{...onsetOf(point,{speed:1,force:1},MODEL.attackFrom,onset),bite:point.bite}]}))}};

const NUMBERS=['finger','firmness','pos','force','vel','acc','gain','stroke','end','start','width','rate','ratio','T','L','d','pl','E','mus','mud','v0','loss','slope','seed','type','variant','value',
  'corner','order','modes','temperature'];
const number=v=>Number.isFinite(+v)?+v:null;

export function stringsDial({type,variant,seed,from,start,variants,fitted,gainDb,neutralDb,finger,heardThrough,labels,send,keep,kept,forget,clock=()=>performance.now()/1000,every=.005}){
  // (What belongs to the instrument played: its compass; where its strings meet the fingerboard's end and its body's
  // lowest air mode (A0), under which it radiates ever less (musebots-strings-live.cpp's w) -- string-bodies.js, from a
  // luthier's measurements; and its vibrato -- vibrato.js's, measured for the violin and the contrabass, authored for the
  // viola and cello, the registry's for an instrument given (the violello's).)
  // (Under a corrected body, the radiation's corner continuing its instrument's target under where the correction's cut
  // stops: fitted to the correction as it is (body_target.py --fit --write, string-body-radiation.json); one designed
  // since is said, and its corner is A0's until it is fitted again.)
  // (A body another's scaled to its size, interim (the registry's bodyScale): its corner the other's with it -- as the
  // engine bakes it.)
  // (Its neutral note on the dial, where the neutral-note fit mapped one (neutral-notes.json, dial_neutral.py), and the
  // monitor's gain for it: its neutral note at broadcast loudness. An instrument with none heard at its renders' one
  // scale (gainOf) against the started one's.)
  const kindOf=type=>{const name=INSTRUMENTS[type],body=name,{hz,measured,source}=airMode(body),scaled=bowedOf(name).bodyScale??null;
    const radiation=fitted?RADIATION.instruments[scaled?scaled.from:name]:null;
    return {instrument:name,name,range:instrumentRange(name),fingerboard:fingerboardEnd(body),airMode:{hz:Math.round(10*hz)/10,measured,source},
      bodyScaled:scaled?{from:scaled.from,ratio:+scaled.ratio.toFixed(4)}:null,
      correctedRadiation:radiation?(scaled?{hz:+(radiation.hz/scaled.ratio).toFixed(1),scaled:true}:{hz:radiation.hz,offDb:radiation.offDb,unradiatedOffDb:radiation.unradiatedOffDb}):null,
      vibrato:instrumentVibrato(name),neutral:NEUTRAL_NOTES[name]??null,neutralDb:neutralDb(name,type),rendersDb:20*Math.log10(gainOf(name)),attacks:attacksOf(name),
      // (What players were measured doing with its dials, drawn on them: players-ranges.mjs.)
      players:stringsRanges(name)}};
  const state={...kindOf(type),type,variant,seed,variants,from,start,
    gainDb,startedRendersDb:20*Math.log10(gainOf(INSTRUMENTS[type])),neutralLimitMs:NEUTRALS.limitMs,strings:[],labels,
    // (The bow's length and its change's time: bow.js's, authored -- a starting profile, as it says; a stroke's end the
    // first half of its change. A pluck's place and its pulls by dynamic: physical-strings.js's.)
    // (The bow hair's width: the renders' and the band's, physical-strings.js MODEL.hair.)
    bow:{length:BOW.lengthCm/100,endSeconds:BOW.changeSeconds/2,hairWidth:MODEL.hair},pluck:MODEL.pluck,constants:{},
    // (The player's noise, each kind's deviation at temperature 1 and the profile the engine draws it with:
    // physical-strings.js PLAYER_NOISE, the registry's.)
    noise:PLAYER_NOISE,
    // (The stopping finger's damping, N s/m: a fingertip's measured, the engine's (engine.mjs FINGER_DAMPING), and
    // Artifastring's own before it.)
    finger,
    // (The note a good note is made from: the one started from, on its instrument, variant and seed, and its string as
    // the host built it (its first 'string' lines).)
    pick:{type,variant,seed,start,string:null},
    // (The most modes a string may be given: the most Artifastring keeps losses for in the live build (patched
    // artifastring_defines.h's MAX_MODAL_DECAY_MODES); the host gives as many as stand under its rate.)
    mostModes:512,inUse:{modes:[],points:[],cellMm:[]},corrected:true,correction:{target:BODIES.targets,sources:BODIES.sources},heardThrough};

  // (What the host says, followed: its rate and constants; an instrument made, its strings as Artifastring has them, each
  // its own modes and a point bow; then each string's modes and hair's points as the host says they change -- and every
  // line passed to whoever listens.)
  const listeners=new Set();
  function heard(line){
    const [word,...rest]=line.split(' ');
    if(word==='ready')state.rate=+rest[0];
    else if(word==='constant')state.constants[rest[0]]=+rest[1];
    else if(word==='modes')state.inUse.modes[+rest[0]]=+rest[1];
    else if(word==='hair'){state.inUse.points[+rest[0]]=+rest[1];state.inUse.cellMm[+rest[0]]=+rest[2]}
    else if(word==='string'){const [s,T,L,d,pl,E,mus,mud,v0,N,f0]=rest.map(Number);state.strings[s]={T,L,d,pl,E,mus,mud,v0,N,f0};
      state.inUse.modes[s]=N;state.inUse.points[s]=0;
      if(!state.pick.string&&s===state.pick.start.string&&state.type===state.pick.type)state.pick.string=state.strings[s]}
    for(const listener of listeners)listener(line);
  }
  // (A page listening; the last one gone, every bow is lifted (the owner: "when I close the web interface it keeps
  // playing - don't allow that").)
  function listen(listener){
    listeners.add(listener);
    return ()=>{if(listeners.delete(listener)&&!listeners.size){stopSolo();send(`l ${least('bowLift')}\n`)}};
  }

  // (What the page asks, as the host's settings, each moving over the least its kind may take.)
  function setting(ask){
    const s=number(ask.string),v=Object.fromEntries(NUMBERS.map(k=>[k,number(ask[k])])),inside=x=>x>0&&x<1;
    if(!['gain','output','stop','seed','instrument','constant','radiate','correct','noise','attack'].includes(ask.do)&&!(s>=0&&s<4&&Number.isInteger(s)))return null;
    switch(ask.do){
    case 'finger':return v.finger>=0&&v.finger<1&&v.firmness>0&&v.firmness<=1?`h ${s} ${v.finger} ${v.firmness} ${least('finger')}`:null;
    case 'damping':return v.ratio>=0?`r ${s} ${v.ratio}`:null;
    case 'bow':return inside(v.pos)&&v.force>=0&&v.vel!=null?`b ${s} ${v.pos} ${v.force} ${v.vel} ${least('bowForce')}`:null;
    case 'stroke':return inside(v.pos)&&v.force>0&&v.vel!=null&&v.acc>0?`a ${s} ${v.pos} ${v.force} ${v.vel} ${v.acc} ${least('bowForce')}`:null;
    case 'lift':return inside(v.pos)&&v.vel!=null?`b ${s} ${v.pos} 0 ${v.vel} ${least('bowLift')}`:null;
    case 'stop':return `l ${least('bowLift')}`;
    case 'pluck':return inside(v.pos)&&v.force>0?`p ${s} ${v.pos} ${v.force} ${least('finger')}`:null;
    // (A vibrato's curve stepped as finely for each of its cycles as the compiler steps the instrument's own: vibrato.js's
    // step at its rate, shorter as the rate is faster.)
    case 'vibrato':return v.width>=0&&v.rate>0?`y ${s} ${v.width} ${v.rate} ${Math.min(AUTHORED_VIBRATO.step,AUTHORED_VIBRATO.step*state.vibrato.rate/v.rate)}`:null;
    case 'alternate':return v.stroke>=0&&v.end>0&&v.start>0?`m ${s} ${v.stroke} ${v.end} ${v.start}`:null;
    // (The player's attack at each stroke's start, the bow's force or its speed (from rest), as a curve (attack-curves.js):
    // sent as the host follows it, straight between points a millisecond apart; none, the stroke as asked.)
    case 'attack':{if(!['force','speed'].includes(ask.what))return null;
      if(ask.points==null)return `c ${ask.what==='force'?0:1} 0`;
      let points;try{points=sampledCurve(curveOf(ask.points,{from:ask.what==='speed'?0:null}),.001)}catch{return null}
      return `c ${ask.what==='force'?0:1} ${points.length} ${points.map(([t,y])=>`${+t.toFixed(6)} ${+y.toFixed(6)}`).join(' ')}`}
    // (A string's build, and the most modes it may have -- none asked, Artifastring's own count.)
    case 'build':return ['T','L','d','pl','E','v0','loss'].every(k=>v[k]>0)&&v.mus>=0&&v.mud>=0&&v.slope!=null&&(v.modes==null||Number.isInteger(v.modes)&&v.modes>=0)
      ?`k ${s} ${v.T} ${v.L} ${v.d} ${v.pl} ${v.E} ${v.mus} ${v.mud} ${v.v0} ${v.loss} ${v.slope} ${least('any')}${v.modes!=null?` ${v.modes}`:''}`:null;
    // (The bow's hair across the string, moved as the bow's contact moves.)
    case 'hair':return v.width>=0&&v.width<=.05?`x ${s} ${v.width} ${least('bowContact')}`:null;
    case 'constant':return ask.name in state.constants&&v.value>=0?`z ${ask.name} ${v.value}`:null;
    case 'seed':return Number.isInteger(v.seed)&&v.seed>=0?`s ${v.seed}`:null;
    // (The player's noise of one kind -- the bow's force, speed or place, or the stopping finger's pitch -- at its
    // temperature, the page's layers multiplied: 0 none, 1 a player's.)
    case 'noise':return Object.hasOwn(PLAYER_NOISE.kinds,ask.what)&&v.temperature>=0?`n ${noiseFields(ask.what,v.temperature).join(' ')}`:null;
    // (Another instrument, its body corrected as the one before was.)
    case 'instrument':return Number.isInteger(v.type)&&v.type>=0&&v.type<INSTRUMENTS.length&&Number.isInteger(v.variant)&&v.variant>=0&&v.variant<variants[INSTRUMENTS[v.type]]
      ?`i ${v.type} ${v.variant}\n${correctionLine(state.corrected)}`:null;
    case 'correct':return typeof ask.on==='boolean'?correctionLine(ask.on):null;
    case 'gain':return v.gain>=0?`g ${v.gain} ${least('any')}`:null;
    case 'output':return `o ${ask.bridge?1:0} ${least('any')}`;
    case 'radiate':return v.corner>=0&&v.corner<.45*(state.rate??44100)&&(v.order===2||v.order===4)?`w ${v.corner} ${v.order} ${least('any')}`:null;
    default:return null;
    }
  }

  // ---- the musebot player: a piece its band composes for the instrument, played on it as its synthesizer (soloist.mjs,
  // imported when a piece is first asked for) ----
  // (Its player's settings, the last given -- a page's, a file's -- kept across instruments: its seed the band's own
  // until one is given (opening-time.js DEFAULT_SEED), the most it plays, and its personality's levers and tone ranges
  // given, the rest drawn from its seed.)
  let soloist=null,playerSettings={seed:DEFAULT_SEED,seconds:60,personality:{}},solos=null;
  const soloists=()=>solos??=import('./soloist.mjs');
  const playerShown=()=>({...playerSettings,levers:LEVERS,grammars:LINE.grammars,ranges:TONE_RANGES});
  const soloShown=()=>soloist&&{said:soloist.line?soloist.line.shown(clock()):soloist.said,playing:soloist.playing};
  // (A piece stopped, or ended: every bow lifted, the strings left to ring down.)
  function stopSolo(){
    if(!soloist?.line)return;
    soloist={said:soloist.line.shown(clock()),playing:false};send(`l ${least('bowLift')}\n`);
  }
  // (`given`: {on, seed, seconds (the most it plays), personality (its levers, grammars and tone ranges given:
  // soloist.mjs playerSettingsOf)}, each left out its last. Its player told, through its instrument's MCP server, the
  // dial's compass and what the dial plays of it (soloist.mjs STRINGS_ENGINE). The page's bow lifted and its turning bow
  // and vibrato stopped as it starts -- its compiler turns its bow and makes its vibrato -- its first note a lift and its
  // lead after now.)
  async function solo(given){
    stopSolo();
    if(!given.on)return {status:200,json:{soloist:soloShown(),player:playerShown()}};
    const {composeSolo,StringsLine,playerSettingsOf}=await soloists();
    const of=name=>given[name]===undefined?playerSettings[name]:name==='personality'?given[name]:Number(given[name]);
    try{playerSettings=playerSettingsOf({seed:of('seed'),seconds:of('seconds'),personality:of('personality')})}catch(error){return {status:400,text:error.message}}
    send(`l ${least('bowLift')}\n${[0,1,2,3].map(s=>`m ${s} 0 1 1\ny ${s} 0 ${state.vibrato.rate} ${AUTHORED_VIBRATO.step}`).join('\n')}\n`);
    const composed=await composeSolo({instrument:state.instrument,variant:state.variant,fingerboard:state.fingerboard,...playerSettings});
    const start=clock()+least('bowLift')+composed.lead+every;
    soloist={line:new StringsLine(composed,{send,start,every}),playing:true};
    return {status:200,json:{soloist:{said:soloist.line.shown(start),playing:true},player:playerShown()}};
  }
  // (Its runner's step: the player's lines due by now sent, and a piece ended once its last has been and its time is
  // past.)
  function due(){
    if(!soloist?.line)return 0;
    const now=clock(),sent=soloist.line.take(now);
    if(soloist.line.done(now))stopSolo();
    return sent;
  }

  // (The page's routes: the state, the settings, and the settings kept -- each with its line, and one forgotten by its
  // time; the musebot player.)
  async function handle(method,path,body={}){
    if(method==='GET'&&path==='/state')return {status:200,json:{...state,soloist:soloShown(),player:playerShown()}};
    if(method==='POST'&&path==='/soloist')return await solo(body);
    // (Its player's settings, a file's, kept for its next piece.)
    if(method==='POST'&&path==='/player'){try{const {playerSettingsOf}=await soloists();playerSettings=playerSettingsOf(body)}catch(error){return {status:400,text:error.message}}return {status:200,json:{player:playerShown()}}}
    if(method==='POST'&&path==='/set'){
      const asks=body.asks??[],lines=asks.map(setting),bad=asks.filter((_,i)=>lines[i]==null);
      if(bad.length)return {status:400,text:`refused: ${JSON.stringify(bad)}`};
      // (What the instrument is, once its settings are taken.)
      // (Another instrument ends the piece on the one before, as the page's stop does.)
      for(const ask of asks){if(ask.do==='stop')stopSolo();if(ask.do==='seed')state.seed=+ask.seed;if(ask.do==='correct')state.corrected=ask.on;if(ask.do==='instrument'){stopSolo();Object.assign(state,kindOf(+ask.type),{type:+ask.type,variant:+ask.variant})}}
      send(lines.map(line=>`${line}\n`).join(''));return {status:204};
    }
    if(method==='GET'&&path==='/kept')return {status:200,json:kept()};
    if(method==='POST'&&path==='/forget'){const left=forget(body.at);return left?{status:200,json:left}:{status:404,text:`nothing kept at ${body.at}`}}
    if(method==='POST'&&path==='/keep')return {status:200,json:{kept:keep({at:new Date().toISOString(),instrument:state.instrument,type:state.type,variant:state.variant,seed:state.seed,from:state.from,...body})}};
    return {status:404};
  }
  // (Its body corrected as it starts.)
  send(`${correctionLine(state.corrected)}\n`);
  return {state,heard,listen,handle,due};
}
