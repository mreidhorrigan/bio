// The one bowed-string engine (the owner, 17 October 2026: the live engine and the renders had been split, the body's
// radiation reaching the live page and not the renders, the renders' driver built from an older source than the live
// host's). Artifastring as Musebots patch it -- the live variant: its ramps, the bridge's force, the bow's hair, modes past
// its own, its fixed constants made variables (patches/ramps.patch, bridge-force.patch, live.patch) -- built with one set
// of flags into every program that plays it: the render driver (musebots-strings.cpp, a player's timed actions to a
// file), the live host (musebots-strings-live.cpp, heard at once) and the live band's streaming player
// (musebots-strings-stream.cpp, a player's timed actions rendered as the page asks), all with one body (musebots-body.h, its tables
// baked here from render/node/string-body-corrections.json and string-body-radiation.json) and one set of instruments
// (musebots-instruments.h: Artifastring's violin, viola and cello, then every instrument with strings of its own in the
// registry's order -- the contrabass, the cello's solver with strings of its own and the cello's bodies scaled to its
// size, and each instrument given as data: public/shared/performers/bowed-instruments.js). What the live page plays is
// what the renders play; the renders may ask it finer (more modes). Each program built where missing or any of its inputs
// changed since -- its source, Artifastring's, the body and its tables -- beside itself and renamed into place, so that
// one already running keeps its own. Where the engine's source is not on this machine (a cloud session), nothing is
// built: the renders' strings play their substitutes, and say so.
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {existsSync,mkdirSync,readFileSync,renameSync,writeFileSync} from 'node:fs';
import {homedir} from 'node:os';
import {dirname,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import BODIES from '../../render/node/string-body-corrections.json' with {type:'json'};
import RADIATION from '../../render/node/string-body-radiation.json' with {type:'json'};
import {BOWED} from '../../public/shared/performers/bowed-instruments.js';
import {magnitudeDb,minimumPhase} from '../../public/shared/grains/minimum-phase.js';
import {besselI0} from '../../public/shared/bessel.js';
import {player,setting} from '../../registry/registry.js';
// (Its settings the registry's, each with its reason: registry/method/strings.json `strings-engine`.)
const ENGINE_SETTING=name=>setting('strings-engine',name);

const here=dirname(fileURLToPath(import.meta.url));
// (Another build of it where MUSEBOTS_STRINGS_ENGINE names one -- its folder holding Artifastring's patched source, or a
// link to the live one's -- as the tests and ness_bowed.py take it.)
export const ENGINE=process.env.MUSEBOTS_STRINGS_ENGINE||join(homedir(),'Library/Application Support/Musebots/strings-model/variants/live');
export const DRIVER=join(ENGINE,'musebots-strings'),LIVE_HOST=join(ENGINE,'musebots-strings-live'),STREAM=join(ENGINE,'musebots-strings-stream');
// (MUSEBOTS_NOISE: the player's noise, the actions' n -- musebots-player-noise.h, patches/noise.patch.)
export const DEFINES='-DMUSEBOTS_RAMPS -DMUSEBOTS_RINGS_DOWN -DMUSEBOTS_BRIDGE_FORCE -DMUSEBOTS_NOISE';
// (The offset from zero the bow's friction leaves in Artifastring's sound, blocked under this (Hz), first order, from
// silence.)
export const DC_BLOCK_HZ=ENGINE_SETTING('dcBlockHz');
// (The engine's instruments, in its types' order (musebots-instruments.h); the body's tables hold each that has a
// correction: one with strings of its own the correction of the instrument whose bodies it is played with, scaled, as
// its body is.)
export const BODY_INSTRUMENTS=BOWED.map(i=>i.name);
const OWN=BOWED.filter(i=>i.strings);
const scaleOf=name=>BOWED.find(i=>i.name===name)?.bodyScale;

// An impulse response stretched in time by `ratio`, its level kept: a body `ratio` times the size, every resonance
// `ratio` lower, as loud (y(t) = x(t / ratio) / ratio, its spectrum x's at ratio times the frequency). Read between its
// samples by a windowed sinc (Kaiser, beta 8, `half` samples either side): a stretch only narrows the band, so nothing
// folds back. For a response that begins at rest, as a measured body's does; one that begins with a jump (a minimum-
// phase filter's) rings before its start once band-limited, which a causal stretch leaves out -- scaledMinimumPhase.
export function stretched(taps,ratio,half=ENGINE_SETTING('sincHalf')){
  const beta=ENGINE_SETTING('kaiserBeta'),norm=besselI0(beta),out=new Float64Array(Math.ceil(taps.length*ratio));
  for(let m=0;m<out.length;m++){
    const t=m/ratio;let sum=0;
    for(let k=Math.max(0,Math.ceil(t-half));k<=Math.min(taps.length-1,Math.floor(t+half));k++){
      const u=t-k,w=besselI0(beta*Math.sqrt(Math.max(0,1-(u/half)**2)))/norm;
      sum+=taps[k]*(u===0?1:Math.sin(Math.PI*u)/(Math.PI*u))*w;
    }
    out[m]=sum/ratio;
  }
  return out;
}
// A minimum-phase filter scaled to a body `ratio` times the size: its magnitude at ratio times each frequency (above its
// own band, its top's), made minimum phase as it was designed (design-string-bodies.mjs), its taps `ratio` times as many.
const SCALED_BINS=ENGINE_SETTING('scaledBins');
export function scaledMinimumPhase(taps,ratio){
  const db=magnitudeDb(taps,SCALED_BINS),top=db.length-1;
  const scaled=Float64Array.from(db,(_,k)=>{const x=k*ratio,i=Math.floor(x);return i>=top?db[top]:db[i]+(db[i+1]-db[i])*(x-i)});
  return minimumPhase(scaled,{n:SCALED_BINS,taps:Math.ceil(taps.length*ratio)});
}
// (Each instrument's correction's variants: one played with another's bodies scaled that one's scaled with them.)
const correctionsOf=name=>{const scale=scaleOf(name);
  return scale?(BODIES.instruments?.[scale.from]?.variants??[]).map(v=>scaledMinimumPhase(v,scale.ratio)):BODIES.instruments?.[name]?.variants??[]};
// (Artifastring's own bodies of an instrument, as its constants hold them: constants/body_<name>_1.h's impulse responses;
// none where the engine's source is not on this machine.)
export function artifastringBodies(name){
  const path=join(ENGINE,'patched/artifastring/constants',`body_${name}_1.h`);
  if(!existsSync(path))return [];
  const text=readFileSync(path,'utf8');
  const table=text.slice(text.indexOf('{',text.indexOf(`BODY_${name.toUpperCase()}_S_1`)));
  return table.split(/\}\s*,?\s*\{/).map(chunk=>chunk.replace(/\/\*[\s\S]*?\*\//g,'').split(/[\s,{};]+/).filter(token=>/^[-+]?[\d.]/.test(token)).map(parseFloat))
    .filter(v=>v.length>0);
}

// (The body's tables as C++: each instrument's variants' taps, its fitted corner, the offset blocker's corner, the rate
// they were designed at. The corner is the correction's own: fitted to it as it is, or none (A0's is the page's).)
function bodyTables(){
  const fittedTo=createHash('sha256').update(readFileSync(join(here,'../../render/node/string-body-corrections.json'))).digest('hex')===RADIATION.corrections?.sha256;
  const lines=['// Generated by native/strings-model/engine.mjs from render/node/string-body-corrections.json and',
    '// render/node/string-body-radiation.json: not to be edited.','#pragma once'];
  const counts=[],names=[],lengths=[];
  BODY_INSTRUMENTS.forEach(name=>{
    const variants=correctionsOf(name),taps=variants[0]?.length??0;
    counts.push(variants.length);lengths.push(taps);
    names.push(variants.map((v,k)=>{
      if(v.length!==taps)throw new Error(`${name} variant ${k}: ${v.length} taps, not ${taps}`);
      const id=`musebots_body_${name.replace(/\W/g,'_')}_${k}`;
      lines.push(`static const double ${id}[${taps}] = {${Array.from(v,x=>Number(x).toPrecision(17)).join(',')}};`);
      return id;
    }));
  });
  // (A corner fitted to the correction as it is; one played with another's bodies scaled that one's scaled with it.)
  const cornerOf=name=>{const scale=scaleOf(name);
    return !fittedTo?0:scale?(RADIATION.instruments?.[scale.from]?.hz??0)/scale.ratio:RADIATION.instruments?.[name]?.hz??0};
  const most=Math.max(1,...counts);
  lines.push(`static const int MUSEBOTS_BODY_INSTRUMENTS = ${BODY_INSTRUMENTS.length};`,
    `static const int MUSEBOTS_BODY_TAPS[${BODY_INSTRUMENTS.length}] = {${lengths.join(', ')}};`,
    `static const double MUSEBOTS_BODY_RATE = ${BODIES.sampleRate};`,`static const double MUSEBOTS_BODY_DC_HZ = ${DC_BLOCK_HZ};`,
    `static const int MUSEBOTS_BODY_COUNT[${BODY_INSTRUMENTS.length}] = {${counts.join(', ')}};`,
    `static const double *const MUSEBOTS_BODY_FIRS[${BODY_INSTRUMENTS.length}][${most}] = {${names.map(ids=>`{${[...ids,...Array(most-ids.length).fill('nullptr')].join(', ')}}`).join(', ')}};`,
    `static const double MUSEBOTS_BODY_CORNER[${BODY_INSTRUMENTS.length}] = {${BODY_INSTRUMENTS.map(cornerOf).join(', ')}};`);
  if(!fittedTo)console.error('engine.mjs: string-body-radiation.json was fitted to another string-body-corrections.json; no corner baked until python3 native/strings-model/body_target.py --fit --write');
  return lines.join('\n')+'\n';
}

// (The instruments' tables as C++, for every one with strings of its own, in the registry's order: its solver (an
// Artifastring InstrumentType), its strings, each {T (N), L (m), d (m), pl (kg/m), E (Pa), r0 (1/s), r2 (s)} -- its law
// r0 + r2 f^2, or, where it has one, its loss table (its frequencies, then its decays) -- and its bodies, the
// Artifastring instrument's it is played with stretched by its ratio, in that instrument's order.)
// (Artifastring's own instruments, its types in its order: the registry's bowed instruments with no strings of their own.)
const SOLVERS=Object.fromEntries(BOWED.filter(i=>!i.strings).map((i,type)=>[i.name,type]));
function instrumentTables(){
  const lines=['// Generated by native/strings-model/engine.mjs from public/shared/performers/bowed-instruments.js and Artifastring\'s',
    '// constants/body_<instrument>_1.h (the bodies stretched: interim): not to be edited.','#pragma once'];
  const bodies=OWN.map(i=>artifastringBodies(i.bodyScale.from).map(v=>stretched(v,i.bodyScale.ratio)));
  const losses=OWN.map((i,k)=>i.strings.map((s,j)=>{
    if(!s.losses)return null;
    const id=`MUSEBOTS_OWN_LOSS_${k}_${j}`,values=[...s.losses.map(p=>p[0]),...s.losses.map(p=>p[1])];
    lines.push(`static const double ${id}[${values.length}] = {${values.map(x=>Number(x).toPrecision(17)).join(', ')}};`);
    return {id,count:s.losses.length};
  }));
  bodies.forEach((set,k)=>lines.push(`static const float MUSEBOTS_OWN_BODIES_${k}[${set.length}][${set[0].length}] = {${set.map(v=>`{${Array.from(v,x=>`${Number(x).toPrecision(9)}f`).join(',')}}`).join(', ')}};`));
  const most=Math.max(1,...bodies.map(set=>set.length));
  lines.push(`static const int MUSEBOTS_OWN_COUNT = ${OWN.length};`,
    `static const int MUSEBOTS_OWN_SOLVER[${OWN.length}] = {${OWN.map(i=>SOLVERS[i.solver]).join(', ')}};`,
    `static const double MUSEBOTS_OWN_STRINGS[${OWN.length}][4][7] = {${OWN.map(i=>`{${i.strings.map(s=>`{${[s.T,s.L,s.d,s.pl,s.E,s.r0??0,s.r2??0].map(x=>Number(x).toPrecision(17)).join(', ')}}`).join(', ')}}`).join(', ')}};`,
    `static const int MUSEBOTS_OWN_LOSS_COUNT[${OWN.length}][4] = {${losses.map(set=>`{${set.map(l=>l?l.count:0).join(', ')}}`).join(', ')}};`,
    `static const double *const MUSEBOTS_OWN_LOSS[${OWN.length}][4] = {${losses.map(set=>`{${set.map(l=>l?l.id:'nullptr').join(', ')}}`).join(', ')}};`,
    `static const double MUSEBOTS_OWN_BODY_RATIO[${OWN.length}] = {${OWN.map(i=>i.bodyScale.ratio.toPrecision(17)).join(', ')}};`,
    `static const int MUSEBOTS_OWN_BODY_COUNT[${OWN.length}] = {${bodies.map(set=>set.length).join(', ')}};`,
    `static const int MUSEBOTS_OWN_BODY_TAPS[${OWN.length}] = {${bodies.map(set=>set[0].length).join(', ')}};`,
    `static const float *const MUSEBOTS_OWN_BODIES[${OWN.length}][${most}] = {${bodies.map((set,k)=>`{${[...set.map((_,b)=>`MUSEBOTS_OWN_BODIES_${k}[${b}]`),...Array(most-set.length).fill('nullptr')].join(', ')}}`).join(', ')}};`);
  return lines.join('\n')+'\n';
}

// (The finger as the engine holds it, a fingertip's measured, the registry's (registry/players/bowed.json
// `stoppingFinger`): a light touch the pad's spring and damper, its damping in proportion to its firmness at the measured
// pad's ratio (`padStiffness`), held at the measured `damping` from the measured touch to a finger stopping the string
// (patches/finger-damping.patch, in R_FINGER's place) -- a header of its own, so that every file including the constants
// does not take the instruments' tables with it.)
export const FINGER_DAMPING=player('violin-family','stoppingFinger.damping');
export const FINGER_PAD_STIFFNESS=player('violin-family','stoppingFinger.padStiffness');
// (Artifastring's own before it, the registry's too: a setting kept with it heard as it was.)
export const ARTIFASTRING_FINGER_DAMPING=player('violin-family','stoppingFinger.dampingArtifastring');
function fingerTables(){
  return ['// Generated by native/strings-model/engine.mjs from registry/players/bowed.json: not to be edited.','#pragma once',
    `#define MUSEBOTS_FINGER_DAMPING ${Number(FINGER_DAMPING).toPrecision(9)}f`,
    `#define MUSEBOTS_FINGER_PAD_SECONDS ${(FINGER_DAMPING/FINGER_PAD_STIFFNESS).toPrecision(9)}f`].join('\n')+'\n';
}

// (A program of the engine built where missing or any input changed: its .build.json's hashes of each, the body's and the
// instruments' tables among them, written first where they changed.)
function build(source,output,frameworks=''){
  if(!existsSync(join(ENGINE,'patched')))return null;
  const generated=join(ENGINE,'generated');
  mkdirSync(generated,{recursive:true});
  for(const [name,text] of [['musebots-body-tables.h',bodyTables()],['musebots-instrument-tables.h',instrumentTables()],['musebots-finger.h',fingerTables()]]){
    // (Written beside it and renamed, so that a process building at once never reads half of one.)
    const file=join(generated,name);
    if(!existsSync(file)||readFileSync(file,'utf8')!==text){writeFileSync(`${file}.next-${process.pid}`,text);renameSync(`${file}.next-${process.pid}`,file)}
  }
  const hash=file=>createHash('sha256').update(readFileSync(file)).digest('hex');
  const record=existsSync(`${output}.build.json`)?JSON.parse(readFileSync(`${output}.build.json`,'utf8')):null;
  const main=join(here,source);
  const current=record&&existsSync(output)&&record.inputs?.[main]===hash(main)
    &&Object.entries(record.inputs).every(([file,sha])=>existsSync(file)&&hash(file)===sha)
    &&DEFINES.split(/\s+/).every(flag=>record.args?.includes(flag));
  if(current)return output;
  // (Built beside it under this process's own name, so that two processes building at once each rename a whole one.)
  const next=`${output}.next-${process.pid}`;
  const result=spawnSync('node',[join(here,'build.mjs'),ENGINE,next],{stdio:['ignore','ignore','inherit'],env:{...process.env,
    MUSEBOTS_STRINGS_SOURCE:source,MUSEBOTS_STRINGS_FRAMEWORKS:frameworks,MUSEBOTS_STRINGS_DEFINES:DEFINES,MUSEBOTS_STRINGS_INCLUDE:generated}});
  if(result.status!==0)throw new Error(`the strings engine's ${source} did not build`);
  renameSync(`${next}.build.json`,`${output}.build.json`);renameSync(next,output);
  return output;
}
// (The render driver, the live host and the live band's streaming player, each built as it needs to be; null where the
// engine is not here.)
export const ensureDriver=()=>build('musebots-strings.cpp',DRIVER);
export const ensureLiveHost=()=>build('musebots-strings-live.cpp',LIVE_HOST,'AudioToolbox');
export const ensureStream=()=>build('musebots-strings-stream.cpp',STREAM);
