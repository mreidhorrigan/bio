// A woodwind's row of controls between two of its charted notes' (native/openwind/live.mjs): a share of the way from one
// to the other, each hole a finger covers itself and a reed column that changes sign in proportion, a positive reed
// column in its logarithm -- a finger sliding off its hole and the reed between the two, as a glissando is played (Chen,
// Smith & Wolfe 2009, doi:10.1121/1.3177269) -- and each padded key's hole the one note's or the other's, moved at half
// way: a pad is open or shut, never held between ("On a real clarinet (or sax, or other padded instrument), it's quite
// difficult to smoothly 'partially close' a key and rather I think it basically never happens; rather, the keys go
// suddenly from open to closed", the owner, 5 November 2026; a pad held part-way had sounded the clarinet's 60.37 at
// 61.27, watery). What each share sounds is the physics's, and far from even -- a hole's first opening moves the pitch
// most (the clarinet's C5 to C#5: a third of the way, 85 of its 112 cents) -- so it is measured, in one rising glide
// (glideOf), and a pitch is found where the glide sounds it (shareAt), as a string's stopping finger is. `columns`: the
// body's (body.json), each [kind, index, name]; `shaded`: those a finger may hold part-way (shadedColumns).
import {SERIES,seriesPitch} from '../../public/shared/estimation/harmonic-series.js';
import {transition} from '../../public/shared/performers/transitions.js';
import {sha1Hex} from '../../public/shared/sha1.js';
import FINGER_HOLES from './finger-holes.json' with {type:'json'};

// The columns of a woodwind's rows whose holes a finger covers itself (finger-holes.json: scripts/make-finger-holes.mjs),
// as a Set: `holes` its body's hole labels (body.json), an opening column's index one of them.
export function shadedColumns(model,columns,holes){
  const own=FINGER_HOLES.instruments[model];
  if(!own)throw new Error(`no keywork's finger holes for the ${model} (native/openwind/finger-holes.json)`);
  return new Set(columns.flatMap((c,k)=>c[0]==='opening'&&own.includes(holes[c[1]])?[k]:[]));
}

// (The padded keys' holes that move between rows `a` and `b`: their columns.)
export const padsMoved=(a,b,columns,shaded)=>a.flatMap((x,c)=>columns[c][0]==='opening'&&!shaded.has(c)&&x!==b[c]?[c]:[]);

export function blendRows(a,b,share,columns,shaded){
  return a.map((x,c)=>{
    const kind=columns[c][0];
    if(kind==='reed'&&x>0&&b[c]>0)return x*(b[c]/x)**share;
    if(kind==='opening'&&!shaded.has(c))return share<.5?x:b[c];
    return x+(b[c]-x)*share;
  });
}

// The pitch each of `steps` + 1 even shares of the blend from row `a` to row `b` sounds (fractional MIDI, null where none
// is heard) -> [[share, pitch], ...]: measured on `stream` (a WindsStream of its own, at `rate`) in one rising glide, the
// first row blown in as a breath rises and given `attack` s, each next moved to as a finger moves and held `settle` s,
// its pitch read over its last `listen` s as its harmonic series (harmonic-series.js seriesPitch: YIN read the oboe's
// notes a twelfth or an octave down) -- SERIES.reading samples by default, so that the contrabassoon's B-flat 0, its
// harmonics 29 Hz apart, is resolved (on 4096 it is not) -- each step held `settle` s, longer than it listens.
export async function glideOf(stream,a,b,columns,shaded,{rate,steps=24,attack=.4,listen=SERIES.reading/rate,settle=listen+.05}={}){
  const out=[];
  for(let k=0;k<=steps;k++){
    const share=k/steps;
    stream.hold(blendRows(a,b,share,columns,shaded),transition(k?'key':'breathRise').least);
    const sound=await stream.render(Math.round((k?settle:attack)*rate));
    const heard=seriesPitch(sound.subarray(sound.length-Math.round(listen*rate)),rate).hz;
    out.push([share,heard?69+12*Math.log2(heard/440):null]);
  }
  return out;
}

// The share at which a glide [[share, pitch], ...] first sounds `pitch`, between the two measured shares about it; null
// where it never does. `padded`: whether pads move between its rows (padsMoved), whose step at half way no share
// between the two measured about it sounds.
export function shareAt(glide,pitch,padded=false){
  for(let k=1;k<glide.length;k++){
    const [s0,p0]=glide[k-1],[s1,p1]=glide[k];
    if(p0==null||p1==null||(p0-pitch)*(p1-pitch)>0||padded&&s0<.5&&s1>=.5)continue;
    return p1===p0?s0:s0+(s1-s0)*(pitch-p0)/(p1-p0);
  }
  return null;
}

// A body's glides, each kept by the two rows, the steps and the ear it was measured with, and the padded keys' holes
// moved whole between them (`key`; a changed rule, body or ear is measured again: those YIN heard, keyed without one,
// are, and those with a pad held part-way, keyed without the pads moved whole): one kept read at once, the rest measured
// one at a time by `measure(job)` -- the Mac's on an engine of its own (glides.mjs Glides) -- those asked for now ahead
// of those asked for later, each kept as it is measured (`keep(kept)`). One without `measure` -- the page's, its glides
// those the Mac kept -- refuses a glide not kept. `columns` and `shaded` the body's, as blendRows takes them.
const GLIDE_EAR=`series ${SERIES.reading} ${SERIES.series}`;
export class GlideBook{
  constructor({columns,shaded,kept={},steps=24}){this.columns=columns;this.shaded=shaded;this.kept=kept;this.steps=steps;this.waiting=[];this.asked=new Map;this.working=false}
  key(a,b){
    const padded=padsMoved(a,b,this.columns,this.shaded);
    return sha1Hex(JSON.stringify({a,b,steps:this.steps,ear:GLIDE_EAR,...padded.length?{padded}:{}})).slice(0,20);
  }
  // (The glide from row `a` to row `b` where it is kept, else null: none measured.)
  known(a,b){return this.kept[this.key(a,b)]??null}
  // The glide from row `a` to row `b`: [[share, pitch], ...], measured where it is not kept.
  glide(a,b,{now=false}={}){
    const key=this.key(a,b);
    if(this.kept[key])return Promise.resolve(this.kept[key]);
    if(!this.measure)return Promise.reject(new Error('a glide not measured where it was kept'));
    let job=this.asked.get(key);
    if(job){if(now&&this.waiting.includes(job)){this.waiting.splice(this.waiting.indexOf(job),1);this.waiting.unshift(job);job.now=true}return job.promise}
    job={key,a,b,now};job.promise=new Promise((done,fail)=>Object.assign(job,{done,fail}));
    this.asked.set(key,job);now?this.waiting.unshift(job):this.waiting.push(job);this.work();
    return job.promise;
  }
  async work(){
    if(this.working)return;this.working=true;
    while(this.waiting.length){
      const job=this.waiting.shift();
      try{
        const glide=await this.measure(job);
        if(this.stopped)throw new Error('the glides were stopped');
        this.kept[job.key]=glide;this.keep?.(this.kept);
        job.done(glide);
      }catch(error){job.fail(error)}
      this.asked.delete(job.key);
    }
    this.working=false;
  }
  // Every glide still asked for given up (the dial's instrument changed).
  stop(){
    this.stopped=true;
    const given=new Error('the glides were stopped');
    for(const job of this.waiting.splice(0))job.fail(given);
    this.asked.clear();
  }
}

// (The `near` pairs of neighbouring charted notes nearest `pitch`, nearest first: those rowSounding asks the glides of.)
function pairsAbout(pitch,notes,near){
  const order=notes.map((m,k)=>k).sort((a,b)=>notes[a]-notes[b]);
  const pairs=order.slice(0,-1).map((k,i)=>[k,order[i+1]]);
  const away=([k,next])=>pitch<notes[k]?notes[k]-pitch:pitch>notes[next]?pitch-notes[next]:0;
  return [...pairs].sort((x,y)=>away(x)-away(y)).slice(0,near);
}
// (Whether rowSounding answers `pitch` from kept glides alone, measuring none: each pair it asks, in its order, kept, up
// to the first whose glide sounds the pitch. Glides that keep none -- an environment's without `known` -- keep none.)
export function measuredAbout(pitch,{notes,rows,columns,shaded,glides,near=4}){
  for(const [k,next] of pairsAbout(pitch,notes,near)){
    const glide=glides.known?.(rows[k],rows[next])??null;
    if(!glide)return false;
    if(shareAt(glide,pitch,padsMoved(rows[k],rows[next],columns,shaded).length>0)!==null)return true;
  }
  return true;
}
// (A pitch's row before its glides are measured: the two charted notes' rows about it blended by its place between
// their pitches -- `provisional`, not yet heard to sound it.)
export function provisionalRow(pitch,{notes,rows,columns,shaded}){
  const order=notes.map((m,k)=>k).sort((a,b)=>notes[a]-notes[b]),above=order.findIndex(k=>notes[k]>=pitch),i=above<0?order.length-1:Math.max(1,above),k=order[i-1],next=order[i];
  const share=notes[next]===notes[k]?0:Math.min(1,Math.max(0,(pitch-notes[k])/(notes[next]-notes[k])));
  return {low:notes[k],high:notes[next],share,row:blendRows(rows[k],rows[next],share,columns,shaded),sounds:null,provisional:true};
}
// The row that sounds `pitch` (fractional MIDI) among the blends of `rows`, each charted note's (`notes` their MIDI):
// the pair of notes about it first, then the `near` pairs nearest it, each glide measured as it is needed; where none
// sounds it, the measured share that sounds nearest. -> {low, high, share, sounds, row}
export async function rowSounding(pitch,{notes,rows,columns,shaded,glides,near=4}){
  let nearest=null;
  for(const [k,next] of pairsAbout(pitch,notes,near)){
    const glide=await glides.glide(rows[k],rows[next],{now:true}),share=shareAt(glide,pitch,padsMoved(rows[k],rows[next],columns,shaded).length>0);
    const of=s=>({low:notes[k],high:notes[next],share:s,row:blendRows(rows[k],rows[next],s,columns,shaded)});
    if(share!==null)return {...of(share),sounds:pitch};
    for(const [s,p] of glide)if(p!=null&&(!nearest||Math.abs(p-pitch)<Math.abs(nearest.sounds-pitch)))nearest={...of(s),sounds:p};
  }
  if(!nearest)throw new Error(`nothing near ${pitch} sounds`);
  return nearest;
}
