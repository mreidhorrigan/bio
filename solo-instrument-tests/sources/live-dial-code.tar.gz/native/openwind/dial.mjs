// The winds' live dial (native/openwind/live.mjs's, and the page's, live.html winds.js): a wind instrument played live
// on OpenWInD's engine, its reed, jet or lips, fingers and vocal tract dialled by ear -- every route the page takes,
// behind an environment the one running it hands it: its instruments, each one's body and engine, its glides, its
// neutral note, its bore's impedance, and where a setting kept goes. The Mac's server runs it on the stream binary and
// the bodies the batch made (live.mjs); a page by itself is to run it on the engine in WebAssembly and the bodies packed
// with the page (the owner, 1 November 2026: "can we then prepare this page for push to my website?"; "The website is
// static ... so it's WASM-focussed": research/LIVE_DIAL_ON_THE_WEBSITE.md) -- one dial, the same on both.
//
// Every wind the engine plays is chosen on the page, and every one plays live (the owner, 31 October 2026: "ALL
// instruments need to play live in live-dial. ALL"; "Every physically-modeled instrument we have needs to be
// live-dialable"): the reed woodwinds and the flutes with a fingering chart, their bodies made and their glides and
// impedance kept as for the first, and the brass with a scheme for the engine. One whose engine one core steps slower
// than it sounds is stepped on several, its bore split by pipes (src/parallel.rs; the same sound, bit for bit): THREADS
// below, or --threads N for each. Its engine's pace is shown as it plays.
//
// The brass (the owner, 31 October 2026: OpenWInD's brass "opens the door to adding brass to a realtime dashboard for
// similar testing"), each its lips and its bore (render/synthesis/tools/save_brass_body.py, realtime-schemes.json
// `brass`): the engine has no law for lips, so the dial holds their row itself -- the lips' values at the lip frequency
// asked, from the rows saved every few cents over their reach, and the breath its players blow there at the dynamic
// (src/brass-breath.mjs playersBreath) -- and the pitch dialled is the lips': where the charted partials' lips stand to
// the pitches they sound, the partial heard the one the bore locks to. Blown from rest, its lips attack where the engine
// finds the partial from at that dynamic, and settle to their own once its oscillation has grown (render/node/
// brass-attacks.mjs: at mf and over, the trombone's lips set for a partial attack the one above it). A valved one's
// valves each a column pair of its row (save_brass_body.py: OpenWInD's deviation pipe and its two switches), set by its
// players' chart for each charted note (brass-standard-fingerings.json, the standard fingering), each dialled between
// raised and pressed -- a half-valve -- until the pitch moves; a pitch between two charted notes on the nearer's
// fingering, the partial heard the one that fingering's bore locks to (the owner, 31 October 2026: "Show all instrument
// parameters there, including valves"). The trombone's slide drawn as its players draw it (render/synthesis/tools/
// save_slide_body.py: its slide's pipe stretched in the engine as it moves, kernel.rs Player::stretch; the owner, 1 November
// 2026: "we do need that trombone slide fully functioning in the manner of a trombone"): each charted note at its
// position, standard or alternate, where its partial plays it in tune; a pitch between them on the partial its players
// play there, the slide placed where that partial sounds it -- a glissando, slurred; each move at its players' speed
// (SLIDE_SPEED), a tongued or legato-tongued note's stroke lasting while it moves; the slide drawn by itself, its lips
// held, the bore giving the pitch.
//
// Its player's tongue, its repeated notes and its vibrato, as the renders' players have them (the owner, 31 October 2026:
// "the parameters related to tonguing, note repetition, and player vibrato (as per the strings' live-dial page)"): a note
// changed while it is blown is slurred, legato-tongued or tongued, as the page says -- a slurred note on the same pitch
// legato-tongued, a half attack, as the renders play it (breath.mjs samePitch); a reed player's tongue holds its reed
// shut (its scaled opening, zeta, a share of itself: TONGUE below, the renders' openwind_worker.py TONGUE_SHUT and
// TONGUE_SOFT), a flutist's and a brass player's stops its air or, legato, dips it (breath.mjs BREATH softDip) -- a brass
// player's closing the air off before its lips as a reed player's tongue closes its reed, their flow (their zeta) and the
// pressure across them (their gamma) both a share of themselves, the cavity between tongue and lips no longer fed --
// each let go into the attack's curve over the tongue's release, the breath behind it all the while (the owner, 2
// November 2026: "Tonguing,
// even with me tinkering with the settings, doesn't seem able to produce sharp enough attacks": a brass player's breath
// had fallen and risen again over its own times with its lips' flow open, the bore ringing through, its oscillation
// grown again over some 40 ms); its stroke as long as the page sets, from the measured contact times the page shows; a
// note repeated by itself, so many a second; a vibrato in its breath (a woodwind's, VIBRATO_SHARE a cent of its curve,
// as the renders sway it: openwind-passages.mjs) or in its lips' frequency (a brass player's), its width and rate the
// page's. Each change is made at the frame it falls on, the engine's sound pulled to there and no further before it
// (`pulled`). Its attack a curve the page draws (the owner, 1 November 2026: "attacks usually involve a curve where a
// parameter peaks over the settling value, before settling ... An analogous situation is likely true around tonguing
// for the aerophones"): its breath at a note's start a multiple of the breath held, its points each a move of the
// engine (attack-curves.js) -- from rest, its first segment as long as the note's rise; after a tongued stroke, as the
// tongue's release. Its player breathes (the owner, 1 November 2026: "have the live-dial perform note reattacks for winds similarly to
// strings (rather than one continuous stream of breath) which might require a concept of performer lung capacity"): a
// breath as deep as wind players take one, spent as its players spend air at the dynamic and pitch and its breath
// setting (lungs.js), then the note let go, a breath taken in and the note attacked again as from rest -- as the
// strings' dial turns its bow. Off here until the page turns it on: one breath without end, as the neutral notes were
// found (neutral.mjs). Its player flutters and hums through it (the owner, 1 November 2026: "growl, flutter, and
// humming through the instrument"; "these need to be supported live"), as the renders' players do (openwind_worker.py
// mouth_pressure): a flutter its breath closed off and let go `hz` times a second, riding on whatever moves under it; a
// hum its breath swung at the hummed pitch, an interval under the note folded into the player's voice (techniques.js
// windTechniqueAt) -- the voice's fundamental alone, by the engine's one oscillator, in place of the vibrato while it
// hums. Each off until the page turns it on. A growl, the hum's upper partials and the renders' sharper flutter wait on
// the engine's own source of them (research/deferred-edits.json winds-flutter-growl-hum-live).
//
// The page is served at once and an instrument taken up behind it, its body the one the batch made (kept.mjs: never made
// here, a page load no making), its taking up said as it goes (`loading`); another
// chosen meanwhile is taken up next, the latest chosen winning; the one playing silenced while the next is made, let go
// once it is ready, and kept where it fails, with why. Each is taken up on its neutral note, one it sounds, at its
// dynamic (neutral.mjs, found by make-bodies.mjs). Each change the page makes names the instrument it was made for
// (`version`), and one made for an instrument no longer played is refused, so that no column of one is dialled on
// another (the owner, 31 October 2026, on the page's "counterintuitive behaviour ... around instrument loading").
//
//   const dial=windsDial(environment); dial.choose(model);
//   await dial.handle(method, path, query (URLSearchParams), given) -> {status, json} or {status, samples, headers}
// `environment`: {instruments, kinds, body(model) -> {folder, name, rules, laid, attacks}, engine({model, folder,
// onError}) -> its engine (winds-stream.mjs WindsStream's ready, threads, columns(), hold, vibrato, tract, slide,
// render(frames), close()), glides({model, folder, columns}) (blend.mjs GlideBook's), rulesRow(engine, model, midi,
// dynamic), neutral(folder) (neutral.mjs neutralOf's), impedance(made, {current}) (sets made.impedance, now or when
// made), keep(record) -> where it went, log, warn}.
import {WINDS_RATE,lipsColumn,lipsRow,noteKey} from './rows.mjs';
import {playersBreath} from '../../render/synthesis/src/brass-breath.mjs';
import {BREATH} from '../../render/synthesis/src/breath.mjs';
import {VIBRATO_SHARE} from '../../render/synthesis/src/openwind-passages.mjs';
import {DYNAMIC_VELOCITY} from '../../public/shared/dynamics.js';
import {transition} from '../../public/shared/performers/transitions.js';
import {curveAt,curveOf,firstEndingAt} from '../../public/shared/performers/attack-curves.js';
import {BREATH_LITRES,LUNGS,Lungs,airflow} from '../../public/shared/performers/lungs.js';
import {windTechniqueAt} from '../../public/shared/performers/techniques.js';
import {VocalTract} from '../../public/shared/performers/vocal-tract.js';
import {player,playerEntry} from '../../registry/registry.js';
import {WIND_VIBRATO,WIND_VIBRATO_REACH} from '../../public/shared/performers/vibrato.js';
import {measuredAbout,provisionalRow,rowSounding} from './blend.mjs';
import DIAL_REACH from './dial-reach.json' with {type:'json'};

// (How far a column the page multiplies is dialled: from 1/REACH to REACH times its rules' value -- one reach with the
// body's jet memory, laid out to hold the longest delay it can ask: dial-reach.json, openwind_bodies.py ring_of.)
export const REACH=DIAL_REACH.factor;
const least=kind=>transition(kind).least;

// The tongue, as the renders' players tongue (breath.mjs passageBreath; openwind_passages.py, openwind_worker.py): a reed
// held shut to `shut` of its opening, touched lightly to `soft` for a legato tongue, touched and let go over the
// tongue's least (transitions.js tongueTouch, tongueRelease); a flutist's or brass player's air stopped over
// `fall` (transitions.js tongueStop), dipped to `dip` of itself for a legato tongue; a stroke `stroke` s long by default
// (breath.mjs tongueStop: the air cut that long before a tongued note), a legato tongue `softSeconds`; a slurred note
// within `samePitch` cents of the one before it, legato-tongued. And the measured contact times the page shows its
// dial against, each DOI checked on Crossref: clarinettists' portato 37 ms (sd 14), their staccato 115 ms at four notes
// a second and 347 ms at two (the registry's, registry/players/winds.json reed-woodwind tongue: M. Pàmies-Vilà, A.
// Hofmann & V. Chatziioannou 2018, doi:10.3389/fpsyg.2018.00617); saxophonists' 25.5 ms
// (A. Hofmann & W. Goebl 2014, "Production and perception of legato, portato, and staccato articulation in saxophone
// playing", Front. Psychol. 5:690, doi:10.3389/fpsyg.2014.00690); and single tonguing to some 8 notes a second, double
// some 11.5 (M. Bertsch & P. Hoole 2014, "Tonguing on brass instruments -- high speed ultrasound study", ISMA 2014,
// no DOI).
export const TONGUE=Object.freeze({shut:.03,soft:.3,touch:least('tongueTouch'),release:least('tongueRelease'),fall:least('tongueStop'),dip:BREATH.softDip,
  stroke:BREATH.tongueStop,softSeconds:BREATH.softSeconds,samePitch:BREATH.samePitch,
  measured:Object.freeze({portato:[player('reed-woodwind','tongue.portato.contact'),playerEntry('reed-woodwind','tongue.portato.contact').sd],
    staccato:player('reed-woodwind','tongue.staccato.contact'),saxophone:.0255,single:8,double:11.5})});
// (A flute's jet given the solver never under this share of its note's -- the breath under it its presence's, its
// drive fading with it: openwind_worker.py JET_FLOOR, law.rs the same.)
export const JET_FLOOR=.01;
// (A breath's rise from rest by default, s: the renders' tuning probe's (breath.mjs probeRise), the standard a tone's
// speaking is measured against.)
export const RISE=BREATH.probeRise;
// A trombone's slide moved as its players move it: along the raised cosine, its hand travelling half the tube it adds --
// its slide's two legs -- over SLIDE_LEAST s, or a longer move at a peak of SLIDE_SPEED m/s. Fast slide moves accelerate
// over some 0.1 s and speeds of some 2 m/s are sometimes exceeded, the peak speed going roughly with the distance (J.
// Kemp, A. López-Carromero, A. Woolley & M. Campbell 2015, "Experimental investigation of Doppler shift and infrasound
// generation during wave propagation within the bore of the trombone during slide movement", Proceedings of the Third
// Vienna Talk on Music Acoustics, no DOI; their [2], W. J. Wadman, J. J. D. van der Gon, R. H. Geuze & C. R. Mol 1979,
// "Control of fast goal-directed arm movements", Journal of Human Movement Studies 5(1) 3-17); a hand's first position to
// seventh some 0.6 m (G. Ekdahl 2001, "A simple model of the mechanics of trombone playing", KTH Department of Mechanics
// technical report).
export const SLIDE_SPEED=2,SLIDE_LEAST=.2;
// A flutter and a hum as the renders' players play them, each its default and its reach the renders' (openwind_worker.py
// techniques: a flutter 25 times a second by default, 5 to 60, closing off 0.7 of the breath, none to all; a hum's
// level 0.2 of the breath by default, none to all of it) -- the hummed pitch an octave under the note by default, the
// middle of what the renders' hummers draw (techniques.js windTechniqueFor: a fifth to an octave and a fourth under), from
// three octaves under it to an octave over, folded into the player's voice. Ours, not measured: a flutter's rate is
// authored (techniques.js: "some 20 to 30 times a second").
export const TECHNIQUE=Object.freeze({flutter:Object.freeze({hz:25,depth:.7,hzReach:[5,60],depthReach:[0,1]}),
  hum:Object.freeze({interval:-12,level:.2,intervalReach:[-36,12],levelReach:[0,1]})});
const slideSeconds=(from,to)=>{const travel=Math.abs(to-from)/2;return travel>0?Math.max(SLIDE_LEAST,Math.PI*travel/(2*SLIDE_SPEED)):0};

export function windsDial(env){
const {log=console.log,warn=console.error}=env;
// The instrument played (`current`): its model and kind, its body, its notes, its engine and the frames pulled from it,
// its columns, and what is measured of it as it plays (each dynamic's rows, its glides, its bore's impedance) -- all
// made again when another is chosen. A brass instrument's `lips`: its rules.json (their rows over their reach, its
// partials), and `attacks`, its attacks.json (each partial's attack at each dynamic); null for a woodwind.
let current=null,version=0;
// What the page dials: a note (the charted note nearest `pitch`), its dynamic, the rules' row there, the row held
// (`row`: the rules' with the page's dials -- each reed or jet column `x`, -1 to 1, 1/REACH to REACH times the rules'
// value; each hole the page moved its own until the pitch moves), whether it is blown, the tract; its articulation,
// its tongue's stroke, its breath's rise and its attack's curve (`breathAttack`: its first segment the rise; by default
// the rise alone), its repeats, its vibrato and its breathing (`breathing`: off, one breath without end; on, a breath
// `litres` deep, taken in over `inhale` s); its flutter and its hum (TECHNIQUE); and its player's swell through a note
// (`swell`, a share of the row's breath: /swell).
const state={midi:null,note:null,pitch:null,dynamic:'mf',rules:null,row:null,x:{},fingers:{},between:null,blowing:false,tract:null,lip:null,lipDialled:false,valves:null,
  slide:null,slideDialled:false,articulation:'tongued',stroke:TONGUE.stroke,softSeconds:TONGUE.softSeconds,rise:RISE,breathAttack:[[0,0],[RISE,1]],repeat:{on:false,rate:4},vibrato:{on:false,width:0,rate:5},
  breathing:{on:false,litres:BREATH_LITRES,inhale:LUNGS.inhale.seconds},
  flutter:{on:false,hz:TECHNIQUE.flutter.hz,depth:TECHNIQUE.flutter.depth},hum:{on:false,interval:TECHNIQUE.hum.interval,level:TECHNIQUE.hum.level},swell:1};
// How the row is held now: its breath's share (0 to 1) and how much of the reed's opening the tongue leaves.
const held={breath:0,tongue:1};
// Its player's lungs (lungs.js): the air left in its breath, and whether it is taking one.
const lungs=new Lungs();
// (Each instrument's airflow: the air it takes at a dynamic, a pitch and a breath setting.)
const flows=new Map;
const airflowOf=model=>{if(!flows.has(model))flows.set(model,airflow(model));return flows.get(model)};

// ---- the row ----
const columnName=k=>current.columns[k][2];
// (Which kind of motion each column's change is: the breath's, the lips' on the reed or jet, a finger's on a key or a
// valve.)
const fingered=()=>current.lips?'valve':'key';
const kindOf=k=>k===current.breath?'breath':current.columns[k][0]==='opening'?fingered():'lips';
// (A column the page dials: a reed's or a jet's, but not what follows from another -- a jet's derivative and next value,
// its presence -- nor a reed's model; the lips' frequency dialled by itself, in Hz.)
const DERIVED=new Set(['model','dUj','next_Uj','presence']);
const dialled=k=>['reed','flute'].includes(current.columns[k][0])&&!DERIVED.has(columnName(k));
// (A dial's place x, -1 to 1: 1/REACH to REACH times the rules' value; the reed's contact exponent three either side of
// it, a jet's offset from the edge one of its widths -- each of these may stand at nothing.)
const ADDITIVE={contact_exponent:3,y0:1};
const ofDial=(k,v,x)=>!x||!dialled(k)||current.lips&&columnName(k)==='pulsation'?v:columnName(k) in ADDITIVE?v+ADDITIVE[columnName(k)]*x:v>0?v*REACH**x:v;
// The row the page sets: the rules' at the pitch, each dial's share on it, each hole the page moved.
const composed=()=>state.rules.map((v,k)=>current.columns[k][0]==='opening'?state.fingers[k]??v:ofDial(k,v,state.x[k]??0));
// The row as its player holds it: its breath `breath` of itself (a reed's or the lips' gamma; a jet's speed), its reed's
// opening, or its lips' flow, `tongue` of itself (zeta).
function played(row,{breath=held.breath,tongue=held.tongue}={}){
  const out=[...row],{breath:b,zeta}=current;
  out[b]=row[b]*breath*state.swell;
  if(zeta!=null)out[zeta]=row[zeta]*tongue;
  return out;
}
// The row held, moved to over `seconds`, as its player holds it (`how`: played's); a jet's speed, once its vibrato has
// swayed it, never under JET_FLOOR of the one dialled, the rest of its breath its presence's -- floored in the engine,
// after the sway, as the renders' law floors it (stream.rs HeldLine; law.rs), so its vibrato never takes the jet under it.
const holdAs=(row,seconds,how)=>send(played(row,how),seconds,current.presence!=null?JET_FLOOR*row[current.breath]:undefined);
const hold=(row,seconds)=>holdAs(row,seconds);
// The row held as the engine moves it (stream.rs HeldLine): from where it stood to the row last sent along the raised
// cosine (controls.rs eased) -- `line`, where it stands at a frame (lineAt) -- so that a flutter rides on whatever moves
// under it. Sent as it is; while it flutters, to the flutter's next turn on it (roll).
const eased=x=>.5-.5*Math.cos(Math.PI*Math.min(1,Math.max(0,x)));
const lineAt=frame=>{const l=current.line;if(!l)return null;const p=l.frames>0?eased((frame-l.at)/l.frames):1;return l.from.map((a,k)=>a+(l.to[k]-a)*p)};
function send(row,seconds,floor){
  const now=current.frames;
  current.line={from:lineAt(now)??row,to:row,at:now,frames:Math.max(0,Math.round(seconds*WINDS_RATE)),floor};
  if(current.roll)roll();else current.stream.hold(row,seconds,floor);
}

// ---- what the player does at frames to come: each at the frame it falls on (`pulled`) ----
let queue=[];
function after(seconds,run,tag='tongue'){
  const at=current.frames+Math.max(1,Math.round(seconds*WINDS_RATE));
  queue.push({at,run,tag});queue.sort((a,b)=>a.at-b.at);
}
const cancel=tag=>{queue=queue.filter(e=>e.tag!==tag)};
const tonguing=()=>queue.some(e=>e.tag==='tongue');

// A stroke's length, s, as `how` asks it ('tongued' or 'legato'): the page's stroke or legato tongue's (`asked`), no
// shorter than its tongue and fingers allow -- what a player sending its notes ahead counts back from (`strokeLeast`).
const strokeLength=(how,asked=how==='legato'?state.softSeconds:state.stroke)=>how==='legato'?Math.max(asked,2*TONGUE.fall,current.kind==='reed'?least('breathRise'):0)
  :Math.max(asked,TONGUE.touch+least(fingered()));
// A stroke of the tongue now, from row `before` (the row held before it) to the page's, as `how` says: 'tongued' (the
// reed held shut, the air closed off before the lips, or a flute's air stopped, for the page's stroke, the fingers moving
// behind it) or 'legato' (a touch, or a dip of the air, for a legato tongue's length); tongued, let go into the
// attack's curve over the tongue's release, a brass instrument's lips attacking as from rest; a trombone's stroke lasting
// while its slide moves (`moving` s), the note let go as it arrives.
function stroke(before,how,moving=0){
  cancel('tongue');cancel('attack');
  const kind=current.kind,legato=how==='legato';
  const seconds=Math.max(moving,strokeLength(how));
  // (A repeat's stroke no longer than most of its time: what the faster staccato measured leaves -- 115 ms of 250.)
  const length=state.repeat.on&&state.blowing?Math.min(seconds,.7/state.repeat.rate):seconds;
  if(kind==='reed'||kind==='lips'&&!legato){
    // (A brass player's tongue before its lips: the pressure across them left as their flow is.)
    const touch=TONGUE.touch,left=legato?TONGUE.soft:TONGUE.shut;
    held.tongue=left;if(kind==='lips')held.breath=left;holdAs(before,touch);
    after(touch,()=>hold(state.row,Math.max(length-touch,least(fingered()))));
    // (Tongued, let go into the attack's curve, its first segment the tongue's release; legato-tongued, a half attack,
    // let go plainly.)
    after(length,()=>{held.tongue=1;legato?hold(state.row,TONGUE.release):attackNow(TONGUE.release)});
    return length;
  }
  if(legato){
    held.breath=TONGUE.dip;holdAs(before,length/2);
    after(length/2,()=>{held.breath=1;hold(state.row,length/2)});
    return length;
  }
  held.breath=0;holdAs(before,TONGUE.fall);
  after(TONGUE.fall,()=>hold(state.row,Math.max(length-TONGUE.fall,least(fingered()))));
  after(length,()=>attackNow(TONGUE.release));
  return length;
}
// The breath let go into the row held along the page's attack (state.breathAttack): its first segment over `seconds`,
// each after it over its own time, each a move of the engine made at its frame; a reed held shut by the tongue until
// `shut` s (a note from rest: its tongue let go as its breath has risen), then let go over the tongue's release; a brass
// instrument's lips attacking from where its attack is found at that dynamic and settled to their own once its
// oscillation has grown (brass-attacks.mjs) -- each of these a move of its own, the breath carried on along its curve
// across it.
function attackNow(seconds,{shut=null}={}){
  cancel('attack');
  const attack=attackHeld(),lips=current.lips&&attack&&attack.share!==1?attack:null;
  // (The rise alone -- the curve as it starts -- one move, as the breath has always risen: the neutral notes were found
  // so (neutral.mjs).)
  if(state.breathAttack.length===2){
    held.breath=1;held.tongue=shut!=null?TONGUE.shut:1;
    if(lips){
      const own=lipsRow(current.lips,state.lip,1,state.valves),from=lipsRow(current.lips,state.lip*lips.share,1,state.valves);
      send(played(state.row).map((v,k)=>own[k]?v*from[k]/own[k]:v),seconds);
      after(lips.settleAfter,()=>hold(state.row,least('lips')),'attack');
    }else hold(state.row,seconds);
    if(shut!=null)after(shut,()=>{held.tongue=1;hold(state.row,TONGUE.release)},'attack');
    return;
  }
  const curve=firstEndingAt(state.breathAttack,seconds);
  const times=[...new Set([...curve.slice(1).map(p=>p[0]),...lips?[lips.settleAfter,lips.settleAfter+least('lips')]:[],...shut!=null?[shut,shut+TONGUE.release]:[]])]
    .filter(t=>t>0).sort((a,b)=>a-b);
  // (Where the row stands at `t` s, moved to over `span` s.)
  const move=(t,span)=>{
    held.breath=curveAt(curve,t);held.tongue=shut!=null&&t<=shut?TONGUE.shut:1;
    if(lips&&t<=lips.settleAfter){
      const own=lipsRow(current.lips,state.lip,1,state.valves),from=lipsRow(current.lips,state.lip*lips.share,1,state.valves);
      send(played(state.row).map((v,k)=>own[k]?v*from[k]/own[k]:v),span);
    }else hold(state.row,span);
  };
  times.forEach((t,k)=>{const from=k?times[k-1]:0;if(k)after(from,()=>move(t,t-from),'attack');else move(t,t)});
}
// A change the page made to the row held (`before` the row before it): moved to, as its player moves -- blown, a new
// pitch is slurred, legato-tongued or tongued as the page says (a slurred note on the same pitch legato-tongued); else
// moved over the longest least of the kinds of what changed, its breath held where its tongue holds it; a trombone's lips
// moving with its slide (`moving` s), a slurred note a glissando.
function changed(before,{pitch=null,moving=0}={}){
  if(state.blowing&&!lungs.taking&&pitch!==null){
    const how=state.articulation==='slurred'&&Math.abs(100*(pitch.to-pitch.from))<TONGUE.samePitch?'legato':state.articulation;
    if(how!=='slurred'){stroke(before,how,moving);return}
  }
  const kinds=new Set(state.row.map((v,k)=>v!==before[k]?kindOf(k):null).filter(Boolean));
  const breath=current.breath,rising=state.row[breath]>before[breath];
  hold(state.row,Math.max(moving,...[...kinds].map(kind=>kind==='breath'?least(rising?'breathRise':'breathFall'):least(kind))));
}
// Blown or not: from rest, a reed's tongue on its reed as the breath rises (the renders' first note: breath.mjs), let
// go as it has risen; a flute's air or a brass player's let go into its rise; stopped, the breath falling over its least.
function blow(on){
  if(on===state.blowing)return;
  state.blowing=on;cancel('tongue');cancel('repeat');cancel('attack');cancel('breath');lungs.filled();
  if(on){
    fromRest();
    repeating();
  }else{held.breath=0;held.tongue=1;hold(state.row,least('breathFall'))}
  flutter();sway();
}
// (A note from rest: a reed's tongue on its reed as the breath rises, let go as it has risen; a flute's air or a brass
// player's let go into its rise.)
function fromRest(){
  if(current.kind==='reed')attackNow(state.rise,{shut:state.rise});
  else{held.tongue=1;attackNow(state.rise)}
}
// The air it spends now, L/s, where its player breathes: its players' at the dynamic and pitch (lungs.js airflow), at
// its breath setting over the rules' there, and the moment's share of it -- none while its tongue stops the air or
// shuts its reed, while it is not blown, or while a breath is taken. `asHeld`: as its note is held, whatever the moment.
function spending({asHeld=false}={}){
  if(!current||state.pitch==null||!state.row)return 0;
  if(!asHeld&&(!state.breathing.on||!state.blowing||lungs.taking))return 0;
  const b=current.breath,rules=state.rules?.[b],share=rules>0?state.row[b]*state.swell/rules:1;
  return airflowOf(current.model).of({dynamic:state.dynamic,midi:state.pitch,share})*(asHeld?1:held.breath*held.tongue*(current.roll?1-current.roll.depth/2:1));
}
// Its breath spent: the note let go as blowing stops, a breath taken in, and the note attacked again as from rest -- its
// tongue, its repeats and its vibrato stopped meanwhile.
function breathe(){
  cancel('tongue');cancel('repeat');cancel('attack');
  lungs.breathe();flutter();held.breath=0;held.tongue=1;hold(state.row,least('breathFall'));sway();
  after(least('breathFall')+lungs.inhale,()=>{lungs.filled();fromRest();repeating();flutter();sway()},'breath');
}
// The note repeated by itself while it is blown, `rate` a second: each a stroke as the page says, a slurred one a
// legato tongue's.
function repeating(){
  cancel('repeat');
  if(!(state.repeat.on&&state.blowing)||lungs.taking)return;
  const next=()=>{stroke(state.row,state.articulation==='tongued'?'tongued':'legato');after(1/state.repeat.rate,next,'repeat')};
  after(1/state.repeat.rate,next,'repeat');
}
// The vibrato held: a woodwind's in its breath (VIBRATO_SHARE of it a cent of its curve, half the width each way), a
// brass player's in its lips' frequency, in cents; none unblown.
function sway(seconds=.2){
  const sounding=state.blowing&&!lungs.taking;
  if(state.hum.on){oscillate('hum',{columns:[current.breath],depths:[sounding?state.hum.level:0],cents:[false],rate:hummed(),seconds});return}
  const {on,width,rate}=state.vibrato,v=on&&sounding?width/2:0;
  if(current.lips)oscillate('vibrato',{columns:[current.columns.findIndex(c=>c[0]==='reed'&&c[2]==='pulsation')],depths:[v],cents:[true],rate,seconds});
  else oscillate('vibrato',{columns:[current.breath],depths:[VIBRATO_SHARE*v],cents:[false],rate,seconds});
}
// (The engine's one oscillator moved to `line` (stream.rs VibratoLine): from a vibrato to a hum or back, the one swaying
// let go at its own rate first and the other begun after -- never a vibrato's depth carried at a hum's rate, nor a hum's
// at a vibrato's.)
function oscillate(kind,line){
  cancel('sway');
  const o=current.oscillator;
  if(o&&o.kind!==kind&&o.line.depths.some(d=>d!==0)&&line.seconds>0){
    const off={...o.line,depths:o.line.depths.map(()=>0),seconds:line.seconds};
    current.stream.vibrato(off);current.oscillator={kind:o.kind,line:off};
    after(line.seconds,()=>{current.stream.vibrato(line);current.oscillator={kind,line}},'sway');
    return;
  }
  current.stream.vibrato(line);current.oscillator={kind,line};
}
// The hummed pitch, Hz: the page's interval under the note, folded into the player's voice (techniques.js windTechniqueAt).
const hummed=()=>windTechniqueAt({kind:'hum',interval:state.hum.interval,level:state.hum.level},state.pitch).hum.hz;
// A flutter while it is blown (the renders' openwind_worker.py mouth_pressure: the tongue's roll closing the breath off
// `hz` times a second, `depth` of it): its breath closed off at each half turn of the roll and let go at each whole one,
// along the raised cosine -- the renders' closing sharper, their curve squared -- each turn a move of the engine to the
// row as its line will stand there, so that an attack, a stroke or a breath moves on under it; none while a breath is
// taken. Stopped, the line's own row held again over what is left of it, or half a turn.
function flutter(){
  cancel('flutter');
  if(state.flutter.on&&state.blowing&&!lungs.taking){current.roll={from:current.frames,turn:0,hz:state.flutter.hz,depth:state.flutter.depth};rolling();return}
  if(!current.roll)return;
  const l=current.line,half=Math.round(WINDS_RATE/(2*current.roll.hz));current.roll=null;
  if(l)current.stream.hold(l.to,Math.max(l.at+l.frames-current.frames,half)/WINDS_RATE,l.floor);
}
// (The roll's turn `turn` sent: the row as its line will stand there, its breath closed off at an odd turn; each turn
// sent at the last one's frame.)
const turnAt=r=>r.from+Math.round(r.turn*WINDS_RATE/(2*r.hz));
function roll(){
  const r=current.roll,at=turnAt(r),row=lineAt(at);
  if(!row)return;
  if(r.turn%2)row[current.breath]*=1-r.depth;
  current.stream.hold(row,Math.max(1,at-current.frames)/WINDS_RATE,current.line.floor);
}
function rolling(){
  const r=current.roll;r.turn++;roll();
  queue.push({at:turnAt(r),run:rolling,tag:'flutter'});queue.sort((a,b)=>a.at-b.at);
}
// (A player's own vibrato on the instrument: vibrato.js's, authored, its reach where one is played without it.)
const vibratoOf=model=>{const own=WIND_VIBRATO[model]??WIND_VIBRATO[{'alto-flute':'alto'}[model]]??{rate:5,width:0};return {...own,reach:WIND_VIBRATO_REACH[model]??null}};

// ---- the notes: every charted note's row as the engine's rules give it at a dynamic, once; a brass partial's, its lips
// where they sound it and its players' breath ----
async function rowsOf(made,dynamic){
  const rows=[];
  for(const [k,midi] of made.notes.entries())rows.push(made.lips?lipsRow(made.lips,made.lips.notes[k].lip,made.lips.notes[k].pressures[dynamic],made.lips.notes[k].valves):await env.rulesRow(made.stream,made.model,midi,dynamic));
  return rows;
}
// A pitch on a brass instrument's lips: their frequency where the charted partials' lips stand to the pitches they
// sound, drawn between the nearest two by the logarithm, and its players' breath at it, its valves the nearer one's
// fingering; the partial heard the one the bore locks to there.
function onLips(pitch,dynamic){
  if(current.lips.slide)return onSlide(pitch,dynamic);
  const hz=440*2**((pitch-69)/12),notes=current.lips.notes,{k,share}=charted(pitch),of=n=>Math.log(n.lip/n.hz);
  const lip=hz*Math.exp(of(notes[k])+(notes.length<2?0:(of(notes[k+1])-of(notes[k]))*share));
  const valves=notes[share<.5?k:Math.min(k+1,notes.length-1)].valves??null;
  return {low:notes[k].midi,high:notes[Math.min(k+1,notes.length-1)].midi,share,sounds:null,lip,valves,row:lipsRow(current.lips,lip,playersBreath(hz,DYNAMIC_VELOCITY[dynamic]),valves)};
}
// The pitch whose lips on the instrument stand at lip frequency `lip` (onLips turned about: found by halving, within its
// charted partials' pitches): the partial whose lips they are, for its attack, where the lips are dialled by themselves.
function pitchOfLips(lip,dynamic){
  let [low,high]=[current.notes[0],current.notes.at(-1)];
  if(lip<=onLips(low,dynamic).lip)return low;if(lip>=onLips(high,dynamic).lip)return high;
  for(let k=0;k<40;k++){const mid=(low+high)/2;onLips(mid,dynamic).lip<lip?low=mid:high=mid}
  return (low+high)/2;
}
// (The attack the lips held are blown with from rest: the pitch's, or where the lips were dialled by themselves, the one
// of the partial whose lips they are -- a trombone's, the pitch's, its slide where it stands for it.)
const attackHeld=()=>{
  if(!(current?.lips&&state.lip))return null;
  // (A trombone's charted note at its own position -- an alternate's too -- that note's own.)
  const own=current.lips.slide&&state.note!=null&&current.notes[state.note]===state.pitch?current.lips.notes[state.note]:null;
  return attackOn(state.lipDialled&&!current.lips.slide?pitchOfLips(state.lip,state.dynamic):state.pitch,state.dynamic,own);
};
// ---- a trombone's slide ----
// (Its charted notes its players play at their standard positions -- and its open partials beyond its chart -- in order
// of pitch: where a pitch between them is played.)
function standardOf(rules){
  const charted=rules.notes.filter(n=>n.names?.length).map(n=>n.midi),[low,high]=[Math.min(...charted),Math.max(...charted)];
  return rules.notes.filter(n=>!n.alternate&&(n.names?.length||n.midi<low||n.midi>high));
}
// (The notes on partial `n` about a pitch, in order of pitch -- k at or under it, the lowest where none is -- and how far
// it stands toward the next.)
function about(notes,pitch){
  const k=Math.max(0,Math.min(notes.length-2,notes.findLastIndex(n=>n.midi<=pitch))),a=notes[k],b=notes[Math.min(k+1,notes.length-1)];
  return {a,b,share:a===b?0:Math.min(Math.max((pitch-a.midi)/(b.midi-a.midi),0),1)};
}
// (The tube that has partial `n` play `hz`: its resonance where its notes on that partial play their pitch over theirs,
// drawn between theirs by the logarithm, and that resonance found among its positions' (rules.json `slide`), drawn
// between the two about it by the logarithm -- past its first position or its seventh as the nearest two stand.)
function tubeFor(n,hz){
  const rules=current.lips,on=rules.notes.filter(m=>m.partial===n).sort((x,y)=>x.hz-y.hz),{a,b,share}=about(on,69+12*Math.log2(hz/440));
  const over=Math.exp(Math.log(a.hz/a.resonance)+(Math.log(b.hz/b.resonance)-Math.log(a.hz/a.resonance))*share),r=hz/over;
  const ps=rules.slide.positions.filter(p=>p.resonances.length>=n).map(p=>({out:p.out,r:p.resonances[n-1]}));
  const i=Math.min(Math.max(ps.findIndex(p=>p.r<=r),1),ps.length-1)||ps.length-1,[p,q]=[ps[i-1],ps[i]];
  return p.out+(q.out-p.out)*Math.log(r/p.r)/Math.log(q.r/p.r);
}
// A pitch on a trombone: on the partial of the nearer of the standard notes about it, or the other's where the nearer's
// slide cannot reach it; its slide where that partial plays it (tubeFor), within its reach; its lips where that partial's
// notes' lips stand to the pitches they sound, drawn between the nearest two by the logarithm, and its players' breath at
// it.
function onSlide(pitch,dynamic){
  const rules=current.lips,hz=440*2**((pitch-69)/12),{a,b,share}=about(standardOf(rules),pitch),most=rules.slide.most;
  const tried=(share<.5?[a,b]:[b,a]).map(n=>({partial:n.partial,out:tubeFor(n.partial,hz)}));
  const {partial,out}=tried.find(t=>t.out>=0&&t.out<=most)??tried[0];
  const on=about(rules.notes.filter(n=>n.partial===partial).sort((x,y)=>x.hz-y.hz),pitch),of=n=>Math.log(n.lip/n.hz);
  const lip=hz*Math.exp(of(on.a)+(of(on.b)-of(on.a))*on.share);
  return {low:on.a.midi,high:on.b.midi,share:on.share,sounds:null,lip,valves:null,out:Math.min(Math.max(out,0),most),partial,on,
    row:lipsRow(rules,lip,playersBreath(hz,DYNAMIC_VELOCITY[dynamic]),null)};
}
// (Where its slide stands as a position: drawn between its positions' tube, past its seventh as its sixth and seventh
// stand apart.)
function positionAt(out){
  const ps=current.lips.slide.positions,k=Math.max(0,Math.min(ps.length-2,ps.findLastIndex(p=>p.out<=out)));
  return ps[k].position+(out-ps[k].out)/(ps[k+1].out-ps[k].out);
}
// Its slide drawn to `out` m of tube as its players draw it. -> the seconds it takes.
function slideTo(out){
  const seconds=slideSeconds(state.slide??out,out);
  state.slide=out;current.stream.slide(out,seconds);
  return seconds;
}
// (The charted partial at or under a pitch, k -- the lowest where none is -- and how far it stands toward the next.)
function charted(pitch){
  const notes=current.lips.notes,k=Math.max(0,Math.min(notes.length-2,notes.findLastIndex(n=>n.midi<=pitch)));
  return {k,share:notes.length<2?0:Math.min(Math.max((pitch-notes[k].midi)/(notes[k+1].midi-notes[k].midi),0),1)};
}
// The attack a pitch on the lips is blown with from rest at a dynamic: their share of their own lips and how long after
// the breath's start they settle to them (brass-attacks.mjs), drawn between the nearest two charted partials' as their
// lips are -- where one's attack does not find it at that dynamic, the other's; null where neither's does.
function attackOn(pitch,dynamic,own=null){
  const at=n=>{const a=current.attacks?.notes.find(a=>noteKey(a)===noteKey(n))?.dynamics[dynamic];return a?.share!=null?a:null};
  // (A trombone's two notes about it on the partial it is played on.)
  const notes=current.lips.notes,{k,share:shared}=charted(pitch),{a:na,b:nb,share}=own?{a:own,b:own,share:0}:current.lips.slide?onSlide(pitch,dynamic).on:{a:notes[k],b:notes[Math.min(k+1,notes.length-1)],share:shared};
  const a=at(na),b=at(nb);
  const kept=g=>g&&{share:g.share,settleAfter:g.settleAfter};
  if(!a||!b||share===0||share===1)return kept(share===1?b??a:a??b);
  return {share:Math.exp(Math.log(a.share)+(Math.log(b.share)-Math.log(a.share))*share),settleAfter:a.settleAfter+(b.settleAfter-a.settleAfter)*share};
}
// The row found sounding a pitch: the glides about it measured as it is first asked for, and the rest of the dynamic's
// after.
// Where its glides are not yet measured, the two charted rows about it blended by its place between their pitches, at
// once, and the row measured to sound it taken up as soon as they are: the page's sound never waits on a measurement (2
// November 2026: the clarinet's sound stopped each time a pitch between two charted notes was asked, every pull of sound
// held behind up to four glides, each measured on an engine of its own).
async function sounding(pitch,dynamic){
  if(current.lips)return onLips(pitch,dynamic);
  const made=current,rows=made.rows.get(dynamic),asked={notes:made.notes,rows,columns:made.columns,glides:made.glides};
  const measured=measuredAbout(pitch,asked),found=measured?rowSounding(pitch,asked):null;
  if(!made.glided.has(dynamic)){made.glided.add(dynamic);const order=made.notes.map((m,k)=>k).sort((a,b)=>made.notes[a]-made.notes[b]);
    for(let i=1;i<order.length;i++)made.glides.glide(rows[order[i-1]],rows[order[i]]).catch(error=>{if(current===made)warn(`  a glide: ${error.message}`)})}
  if(measured)return await found;
  const still=()=>current===made&&state.pitch===pitch&&state.dynamic===dynamic&&state.between?.provisional;
  rowSounding(pitch,asked).then(found=>still()&&serial(()=>still()?settleAt(made,pitch,dynamic,false,null,found):null)).catch(error=>{if(current===made)warn(`  a glide: ${error.message}`)});
  return provisionalRow(pitch,asked);
}
// A pitch taken up: the row found sounding it (`charted`, a charted note's own), the page's dials on it, its fingers
// the row's; moved to as its player moves.
// `note`: the charted note chosen by its place among them (a trombone's alternate positions too).
async function toPitch(pitch,dynamic,charted=false,note=null){
  const made=current,[low,high]=[Math.min(...made.notes),Math.max(...made.notes)];
  if(note!==null){if(!(Number.isInteger(note)&&note>=0&&note<made.notes.length))throw new Error('no such charted note');pitch=made.notes[note];charted=true}
  if(!(pitch>=low&&pitch<=high)||!(dynamic in DYNAMIC_VELOCITY))throw new Error(`a pitch from ${low} to ${high}, and a dynamic`);
  if(charted&&!made.notes.includes(pitch))throw new Error('no such charted note');
  const k=note??made.notes.indexOf(pitch);
  const found=charted?{low:pitch,high:pitch,share:0,sounds:null,row:made.rows.get(dynamic)[k],lip:made.lips?made.lips.notes[k].lip:null,valves:made.lips?.notes[k].valves??null,
    out:made.lips?.notes[k].out??null}
    :await sounding(pitch,dynamic);
  settleAt(made,pitch,dynamic,charted,k,found);
}
// (The row `found` for a pitch taken up: the page's dials on it, its fingers the row's.)
function settleAt(made,pitch,dynamic,charted,k,found){
  if(current!==made)throw new Error('another instrument was taken up');
  const before=state.row,from=state.pitch,near=made.notes.reduce((a,m,j)=>Math.abs(m-pitch)<Math.abs(made.notes[a]-pitch)?j:a,0);
  Object.assign(state,{pitch,dynamic,midi:made.notes[charted?k:near],note:charted?k:near,rules:[...found.row],fingers:{},lip:found.lip??null,lipDialled:false,
    valves:found.valves??null,slideDialled:false,
    between:{low:found.low,high:found.high,share:found.share,sounds:found.sounds,...found.provisional?{provisional:true}:{}}});
  state.row=composed();
  changed(before,{pitch:{from,to:pitch},moving:found.out!=null?slideTo(found.out):0});
  if(state.hum.on)sway();
}
// (Its players' normal tract at a pitch where the registry has their tract measured -- the clarinettists' alone so far
// (registry/players/winds.json) -- else none.)
const tractMeasured=of=>{try{VocalTract.normal(of,440);return true}catch{return false}};
const normalTract=(of,hz)=>tractMeasured(of)?VocalTract.normal(of,hz).resonances:[];
function tract(resonances){state.tract=new VocalTract(resonances);current.stream.tract(state.tract.resonances,least('tract'))}

// The bore's input impedance for each charted fingering, as the reed meets it (export_impedance.py), made once a body
// and read into its instrument's `impedance` while it is still the one played; a brass instrument's its one, saved with
// its body.

// ---- an instrument taken up: behind the page, said as it goes ----
// (`wanted`: the one last chosen; `loading`: the one being made and how far it has come; `failed`: the last that could
// not be, and why, until another is chosen.)
let wanted=null,loading=null,failed=null,loader=null;
const step=said=>{if(loading)Object.assign(loading,{step:said})};
function choose(model){
  if(!env.instruments.includes(model))throw new Error(`one of ${env.instruments.join(', ')}`);
  wanted=model;failed=null;
  loader??=(async()=>{
    while(wanted&&wanted!==current?.model){
      const model=wanted;loading={model,step:'its body',since:Date.now()};
      try{await takeUp(model)}catch(error){if(wanted===model){failed={model,error:error.message};wanted=current?.model??null;warn(`The ${model}: ${error.message}`)}}
    }
    loading=null;loader=null;
  })();
}
// Its body made (or read), a fresh engine and every dynamic's rows found on it, all before a sound -- given up where
// another is chosen meanwhile -- then taken up between two of the page's pulls of sound: the one before silenced and let
// go, its neutral note as its rules play it at its dynamic (else the middle of its charted notes at the dynamic
// dialled), its players' normal tract, silent until blown.
async function takeUp(model){
  log(`The ${model}'s body ...`);
  const kind=env.kinds[model],brass=kind==='lips';
  // (Silent while the next is made: what the one played was doing let go.)
  if(current&&state.blowing)await serial(()=>{cancel('repeat');cancel('tongue');cancel('attack');cancel('breath');lungs.filled();state.blowing=false;flutter();held.breath=0;held.tongue=1;hold(state.row,least('breathFall'));sway()});
  // (Its body as the batch made it -- with a brass body's attacks and its neutral note -- taken up at once and never made
  // here: kept.mjs, make-bodies.mjs.)
  const body=await env.body(model),folder=body.folder;
  if(wanted!==model)return;
  step('its engine');
  const stream=env.engine({model,folder,onError:said=>warn(`  the engine: ${said}`)});
  try{
    await stream.ready;
    const columns=await stream.columns(),rules=body.rules;
    // (A brass body's rows are its lips' columns and its valves' switches', in the engine's order.)
    const width=brass?rules.valves?.width??rules.columns.length:null;
    if(brass&&!(width===columns.length&&rules.columns.every(name=>columns[lipsColumn(rules,name)]?.[0]==='reed'&&columns[lipsColumn(rules,name)][2]===name)
      &&(rules.valves?.columns??[]).flat().every(k=>columns[k]?.[0]==='opening')))throw new Error(`the ${model}'s saved rows are not its engine's columns`);
    const at=(kind_,name)=>{const k=columns.findIndex(c=>c[0]===kind_&&c[2]===name);return k<0?null:k};
    const laid=body.laid;
    const made={model,kind,folder,name:body.name,stream,columns,frames:0,notes:rules.notes.map(n=>n.midi),lips:brass?rules:null,
      attacks:brass?body.attacks:null,holes:laid.holes,
      // (How its body is laid out for the engine -- its losses, its mesh, its elements' order, its precision and rates:
      // the page's physics.)
      layout:{losses:laid.losses,mesh:laid.mesh,order:laid.order,single:laid.single,rate:laid.rate,ratio:laid.ratio,unknowns:laid.ni,entries:laid.nd,madeFrom:laid.madeFrom},
      breath:kind==='air'?at('flute','Uj'):at('reed','gamma'),presence:kind==='air'?at('flute','presence'):null,zeta:kind==='air'?null:at('reed','zeta'),
      rows:new Map,glided:new Set,impedance:null};
    made.glides=brass?null:env.glides({model,folder,columns});
    // (Its neutral note, where make-bodies.mjs found one on this body and these rules: neutral.mjs.)
    made.neutral=env.neutral(folder);
    if(made.neutral&&made.notes[made.neutral.note]!==made.neutral.midi)made.neutral=null;
    // (Every dynamic's rows found now, before a sound: asked of the engine while it plays, a dynamic's took it some 50 ms
    // from its sound, a stutter each time a new one was dialled.)
    for(const dynamic of Object.keys(DYNAMIC_VELOCITY)){
      step(`its notes at ${dynamic}`);made.rows.set(dynamic,await rowsOf(made,dynamic));
      if(wanted!==model){stream.close();return}
    }
    env.impedance(made,{current:()=>current===made});
    await serial(()=>{
      const before=current;
      current=made;version++;queue=[];refused=[];pace=null;
      before?.glides?.stop();before?.stream.close();
      Object.assign(state,{x:{},fingers:{},blowing:false,lip:null,lipDialled:false,valves:null,slide:null,slideDialled:false,vibrato:{on:false,...vibratoOf(model)},row:null,pitch:null});
      Object.assign(held,{breath:0,tongue:1});
      // (Its neutral note at its dynamic, a note it sounds (neutral.mjs); where none has been found on this body, the
      // middle of its charted notes at the dynamic dialled, the page saying so.)
      if(made.neutral)state.dynamic=made.neutral.dynamic;
      const k=made.neutral?made.neutral.note:Math.floor(made.notes.length/2),middle=made.notes[k];
      Object.assign(state,{pitch:middle,midi:middle,note:k,rules:[...made.rows.get(state.dynamic)[k]],lip:made.lips?made.lips.notes[k].lip:null,valves:made.lips?.notes[k].valves??null,
        between:{low:middle,high:middle,share:0,sounds:null}});
      // (Its breath where its neutral note was found to sound: its players', or dialled from theirs.)
      if(made.neutral?.breath)state.x[made.breath]=made.neutral.breath;
      state.row=composed();state.vibrato.on=state.vibrato.width>0;
      holdAs(state.row,0);
      if(made.lips?.slide)slideTo(made.lips.notes[k].out);
      tract(normalTract(model,440*2**((middle-69)/12)));sway(0);
    });
    log(`  the ${model} ready${stream.threads>1?`, its engine on ${stream.threads} cores`:''}`);
  }catch(error){stream.close();throw error}
}

// (The engine's work one at a time -- its sound, and an instrument taken up between two pulls of it -- one that fails
// not stopping the next.)
let rendering=Promise.resolve();
const serial=job=>rendering=rendering.catch(()=>{}).then(job);
// Its sound pulled to `frames` more, each change to come made at the frame it falls on. Its pace: the seconds its engine
// takes for a block of sound over the block's own, averaged over the last score or so, shown on the page; begun again for
// each instrument. None played yet: silence.
let pace=null;
async function pulled(frames){
  if(!current)return new Float32Array(frames);
  const t=performance.now(),out=new Float32Array(frames),made=current;
  for(let got=0;got<frames;){
    while(queue.length&&queue[0].at<=made.frames)await queue.shift().run();
    // (Its breath spent as it plays, to the frame where it runs out.)
    const flow=spending();
    const next=Math.min(frames-got,queue.length?queue[0].at-made.frames:frames-got,flow>0?Math.max(1,Math.ceil(lungs.secondsLeft(flow)*WINDS_RATE)):Infinity);
    out.set(await made.stream.render(next),got);got+=next;made.frames+=next;
    if(flow>0&&current===made&&lungs.spend(flow,next/WINDS_RATE))breathe();
  }
  const taken=(performance.now()-t)/1000/(frames/WINDS_RATE);
  pace=pace==null?taken:.9*pace+.1*taken;return out;
}
// Everything the page shows: the instruments, what is being made, and the one played -- its columns, its notes, and
// what it plays now.
function shown(){
  const out={instruments:env.instruments.map(model=>({model,kind:env.kinds[model]})),wanted,loading:loading&&{model:loading.model,step:loading.step,seconds:(Date.now()-loading.since)/1000},failed,
    rate:WINDS_RATE,dynamics:Object.keys(DYNAMIC_VELOCITY),tongue:TONGUE,limits:LIMITS(),reach:REACH,version,model:current?.model??null};
  if(!current)return out;
  const {lips,attacks}=current;
  return {...out,kind:current.kind,tractMeasured:tractMeasured(current.model),columns:current.columns,breath:current.breath,holes:current.holes,notes:current.notes,
    dials:current.columns.map((c,k)=>dialled(k)?k:-1).filter(k=>k>=0),threads:current.stream.threads,impedance:Boolean(current.impedance),
    strokeLeast:{tongued:strokeLength('tongued',0),legato:strokeLength('legato',0)},
    partials:lips?lips.notes.map(n=>n.partial):null,fingerings:lips?.valves?lips.notes.map(n=>n.fingering):null,names:lips?.valves||lips?.slide?lips.notes.map(n=>n.names??[]):null,
    positions:lips?.slide?lips.notes.map(n=>n.position):null,alternates:lips?.slide?lips.notes.map(n=>Boolean(n.alternate)):null,
    slide:lips?.slide?{most:lips.slide.most,positions:lips.slide.positions.map(p=>({position:p.position,out:p.out})),speed:SLIDE_SPEED,least:SLIDE_LEAST}:null,
    valves:lips?.valves?.columns??null,unplayed:lips?lips.unplayed:null,lipReach:lips?[lips.grid.lips[0],lips.grid.lips.at(-1)]:null,
    unattacked:attacks?attacks.notes.map(a=>Object.entries(a.dynamics).filter(([,g])=>g.share==null).map(([d])=>d)):null,
    vibratoOwn:vibratoOf(current.model),layout:current.layout,lungs:{...LUNGS,breath:BREATH_LITRES,airflow:airflowOf(current.model).source},
    neutral:current.neutral?{note:current.neutral.note,midi:current.neutral.midi,dynamic:current.neutral.dynamic,cents:current.neutral.cents,found:current.neutral.found,
      breath:current.neutral.breath??0,breathTimes:current.neutral.breathTimes??1}:null,
    played:playing(),refused};
}
// (What each of the page's settings may be, s, notes a second, cents and Hz: the routes below hold them to it.)
// (A breath from half a litre to the vital capacity two deviations over wind players' measured; taken in over 0.2 to 2
// s, about a catch breath's to a slow one's.)
const LIMITS=()=>({stroke:[TONGUE.touch+least('key'),.5],softSeconds:[2*TONGUE.fall,.2],rise:[least('breathRise'),.5],repeat:[.5,16],width:[0,200],rate:[.5,12],
  litres:[.5,+(LUNGS.capacity.litres+2*LUNGS.capacity.sd).toFixed(2)],inhale:[.2,2],
  flutterHz:TECHNIQUE.flutter.hzReach,flutterDepth:TECHNIQUE.flutter.depthReach,humInterval:TECHNIQUE.hum.intervalReach,humLevel:TECHNIQUE.hum.levelReach,
  swell:[1/REACH,REACH]});
// (What it plays now: the page's settings and the row held, and a valved instrument's fingering as its valves stand in
// it, each pressed past half way.)
const fingeringOf=row=>current?.lips?.valves?current.lips.valves.columns.map(([k])=>row[k]<.5?'1':'0').join(''):null;
const playing=()=>({...state,tract:state.tract?.resonances??[],attack:attackHeld(),fingering:state.row?fingeringOf(state.row):null,
  lungs:{air:lungs.air,taking:lungs.taking,flow:spending({asHeld:true})},hummed:current&&state.pitch!=null?hummed():null,
  position:current?.lips?.slide&&state.slide!=null?positionAt(state.slide):null});

// Each change the page makes, by its route -> what it plays then, or null where it makes no such change.
async function change(path,given){
  const before=state.row;
  switch(path){
    // (A pitch: the row found sounding it, or `charted`, a charted note's own.)
    case '/pitch':await toPitch(Number(given.pitch),given.dynamic??state.dynamic,Boolean(given.charted),given.note===undefined?null:Number(given.note));break;
    // (A reed's or jet's column dialled: its share of the rules' value, -1 to 1 1/REACH to REACH times it.)
    case '/dial':{const k=Number(given.column),x=Number(given.x);
      if(!(Number.isInteger(k)&&dialled(k))||!(x>=-1&&x<=1))throw new Error('a dialled column, and a place from -1 to 1');
      state.x[k]=x;state.row=composed();changed(before);break}
    // (A hole's opening, 0 closed to 1 open, or a valve's, 0 pressed to 1 raised, until the pitch moves: every column
    // of its side -- a valve's two switches -- together.)
    case '/hole':{const k=Number(given.column),v=Number(given.value);
      if(current.columns[k]?.[0]!=='opening'||!(v>=0&&v<=1))throw new Error('a hole or a valve, and its opening from 0 to 1');
      current.columns.forEach((c,j)=>{if(c[0]==='opening'&&c[1]===current.columns[k][1])state.fingers[j]=v});state.row=composed();changed(before);break}
    // (Every dial back to the rules' value at the pitch and dynamic, the holes the pitch's.)
    case '/reset':state.x={};state.fingers={};state.row=composed();changed(before);break;
    // (Its neutral note again -- read again from its body's folder, so that one found since it was taken up is played
    // -- at its dynamic and breath, every other dial the rules' there; the middle of its charted notes at the dynamic
    // dialled where none has been found.)
    case '/neutral':{
      const found=env.neutral(current.folder);
      current.neutral=found&&current.notes[found.note]===found.midi?found:null;
      const n=current.neutral,k=n?n.note:Math.floor(current.notes.length/2);
      await toPitch(current.notes[k],n?n.dynamic:state.dynamic,true,k);
      state.x=n?.breath?{[current.breath]:n.breath}:{};state.fingers={};state.row=composed();changed(before);break;
    }
    // (The lips' frequency dialled by itself, the pitch asked kept: their other values those that go with it
    // (lipsRow, its register's), the breath the pitch's; the partial heard the one the bore locks to. Its attack
    // from rest the partial's whose lips these are.)
    case '/lip':{
      if(!current.lips)throw new Error('only a brass instrument\'s lips are dialled by their frequency');
      const [low,high]=[current.lips.grid.lips[0],current.lips.grid.lips.at(-1)],lip=Number(given.lip);
      if(!(lip>=low&&lip<=high))throw new Error(`lips from ${low.toFixed(1)} to ${high.toFixed(1)} Hz`);
      Object.assign(state,{lip,lipDialled:true,rules:lipsRow(current.lips,lip,playersBreath(440*2**((state.pitch-69)/12),DYNAMIC_VELOCITY[state.dynamic]),state.valves)});
      state.row=composed();changed(before);break;
    }
    // (A trombone's slide drawn by itself, `out` m of tube past its first position, as its players draw it: its lips
    // and breath held, the pitch the bore gives there.)
    case '/slide':{
      if(!current.lips?.slide)throw new Error('only a trombone\'s slide is drawn');
      const out=Number(given.out),most=current.lips.slide.most;
      if(!(out>=0&&out<=most))throw new Error(`a slide drawn from 0 to ${most.toFixed(3)} m of tube`);
      slideTo(out);state.slideDialled=true;break;
    }
    // (A row of the body's columns held as it is given: the brass stream's test, a tool.)
    case '/row':
      if(!Array.isArray(given.row)||given.row.length!==current.columns.length||!given.row.every(Number.isFinite))throw new Error('a row of the body\'s columns');
      state.row=given.row;changed(before);break;
    case '/blow':blow(Boolean(given.on));break;
    // (The tongue now, as the articulation says: a slurred note's a legato tongue's.)
    case '/tongue':if(state.blowing&&!lungs.taking)stroke(state.row,state.articulation==='tongued'?'tongued':'legato');break;
    case '/articulation':{
      if(given.articulation!==undefined){if(!['slurred','legato','tongued'].includes(given.articulation))throw new Error('slurred, legato or tongued');state.articulation=given.articulation}
      const within=(name,low,high)=>{if(given[name]===undefined)return;const v=Number(given[name]);if(!(v>=low&&v<=high))throw new Error(`${name} from ${low} to ${high} s`);state[name]=v};
      const limits=LIMITS();for(const name of ['stroke','softSeconds','rise'])within(name,...limits[name]);
      state.breathAttack=firstEndingAt(state.breathAttack,state.rise);
      if(state.repeat.on)repeating();
      break;
    }
    // (The breath's attack, a curve (attack-curves.js) from rest, each segment eased as the engine moves: its first
    // segment the rise, within the rise's limits.)
    case '/attack':{
      const points=curveOf(given.points,{from:0,straight:false}),[low,high]=LIMITS().rise;
      if(!(points[1][0]>=low&&points[1][0]<=high))throw new Error(`its first segment, the rise, from ${low} to ${high} s`);
      state.breathAttack=points;state.rise=points[1][0];break;
    }
    // (Its breathing: on, a breath `litres` deep taken in over `inhale` s each time it is spent; off, one breath
    // without end -- one being taken let go, the note attacked again at once.)
    case '/breathing':{
      const litres=given.litres===undefined?state.breathing.litres:Number(given.litres),inhale=given.inhale===undefined?state.breathing.inhale:Number(given.inhale);
      const limits=LIMITS();
      if(!(litres>=limits.litres[0]&&litres<=limits.litres[1]))throw new Error(`a breath from ${limits.litres[0]} to ${limits.litres[1]} L`);
      if(!(inhale>=limits.inhale[0]&&inhale<=limits.inhale[1]))throw new Error(`a breath taken in over ${limits.inhale[0]} to ${limits.inhale[1]} s`);
      const on=given.on===undefined?state.breathing.on:Boolean(given.on),begun=on&&!state.breathing.on;
      state.breathing={on,litres,inhale};lungs.set({litres,inhale});
      if(begun)lungs.filled();
      if(!on&&lungs.taking){cancel('breath');lungs.filled();if(state.blowing){fromRest();repeating();flutter();sway()}}
      break;
    }
    // (Its flutter: on while it is blown, `hz` turns of the roll a second, `depth` of the breath closed off; its hum:
    // on, the hummed pitch `interval` semitones from the note, its breath swung `level` of itself.)
    case '/flutter':{
      const hz=given.hz===undefined?state.flutter.hz:Number(given.hz),depth=given.depth===undefined?state.flutter.depth:Number(given.depth),limits=LIMITS();
      if(!(hz>=limits.flutterHz[0]&&hz<=limits.flutterHz[1]))throw new Error(`a flutter from ${limits.flutterHz[0]} to ${limits.flutterHz[1]} times a second`);
      if(!(depth>=limits.flutterDepth[0]&&depth<=limits.flutterDepth[1]))throw new Error(`a flutter's depth from ${limits.flutterDepth[0]} to ${limits.flutterDepth[1]}`);
      state.flutter={on:given.on===undefined?state.flutter.on:Boolean(given.on),hz,depth};flutter();break;
    }
    case '/hum':{
      const interval=given.interval===undefined?state.hum.interval:Number(given.interval),level=given.level===undefined?state.hum.level:Number(given.level),limits=LIMITS();
      if(!(interval>=limits.humInterval[0]&&interval<=limits.humInterval[1]))throw new Error(`a hummed pitch from ${limits.humInterval[0]} to ${limits.humInterval[1]} semitones from the note`);
      if(!(level>=limits.humLevel[0]&&level<=limits.humLevel[1]))throw new Error(`a hum's level from ${limits.humLevel[0]} to ${limits.humLevel[1]}`);
      state.hum={on:given.on===undefined?state.hum.on:Boolean(given.on),interval,level};sway();break;
    }
    case '/repeat':{
      const rate=given.rate===undefined?state.repeat.rate:Number(given.rate);
      if(!(rate>=.5&&rate<=16))throw new Error('a rate from 0.5 to 16 notes a second');
      state.repeat={on:given.on===undefined?state.repeat.on:Boolean(given.on),rate};repeating();break;
    }
    case '/vibrato':{
      const width=given.width===undefined?state.vibrato.width:Number(given.width),rate=given.rate===undefined?state.vibrato.rate:Number(given.rate);
      if(!(width>=0&&width<=200)||!(rate>=.5&&rate<=12))throw new Error('a width from 0 to 200 cents and a rate from 0.5 to 12 Hz');
      state.vibrato={on:given.on===undefined?state.vibrato.on:Boolean(given.on),width,rate};sway();break;
    }
    // (Its player's swell through a note: its breath `share` of the row's, the breath dialled kept, moved there over
    // `seconds` -- its expression, as the renders' players swell a note (breath.mjs swellOf) and breathe its vibrato
    // (openwind-passages.mjs VIBRATO_SHARE); taken up by the next move where its tongue or its attack is moving it.)
    case '/swell':{
      const share=Number(given.share),seconds=given.seconds===undefined?0:Number(given.seconds),[low,high]=LIMITS().swell;
      if(!(share>=low&&share<=high)||!(seconds>=0))throw new Error(`a swell from ${low.toFixed(3)} to ${high.toFixed(3)} of the breath, over some seconds`);
      const rising=share>state.swell;state.swell=share;
      if(state.blowing&&!lungs.taking&&!tonguing()&&!queue.some(e=>e.tag==='attack'))hold(state.row,Math.max(seconds,least(rising?'breathRise':'breathFall')));
      break;
    }
    case '/tract':
      if(!Array.isArray(given.resonances)||!given.resonances.every(r=>r.frequency>0&&r.q>0&&r.peak>=0))throw new Error('resonances, each its frequency, q and peak');
      tract(given.resonances);break;
    default:return null;
  }
  return playing();
}
// (A change given its time, `at` s on the dial's clock (its frames over WINDS_RATE, `x-seconds` with each pull of sound):
// made where its time has come, else queued to the frame it falls on, made there as the sound is pulled -- a gesture
// recorded to be played ahead of its hearing, a player's note sent before it sounds. One refused at its time is said
// in `refused`, the last ten. `by`: the player that gave it, whose changes still to come it may withdraw.)
const CHANGES=new Set(['/pitch','/dial','/hole','/reset','/neutral','/lip','/slide','/row','/blow','/tongue','/articulation','/attack',
  '/breathing','/flutter','/hum','/repeat','/vibrato','/swell','/tract']);
let refused=[];
async function later(path,given){
  if(!CHANGES.has(path))return {status:404};
  const seconds=Number(given.at),{at:_,by=null,...rest}=given;
  if(!(seconds>=0))throw new Error('a time from 0 s on the dial\'s clock');
  const at=Math.round(seconds*WINDS_RATE);
  if(at<=current.frames)return {status:200,json:{...await change(path,rest),rules:state.rules}};
  queue.push({at,tag:'given',by,run:()=>change(path,rest).catch(error=>{refused=[...refused.slice(-9),{path,at:seconds,error:error.message}]})});
  queue.sort((a,b)=>a.at-b.at);
  return {status:200,json:{queued:path,at:seconds}};
}
// (A player's changes given their times, from `from` s on the dial's clock, let go -- what it sent ahead and now plays
// otherwise: the rest of its line planned again as more of it comes, its MIDI 2.0's next note heard.)
function withdrawn({by=null,from}){
  const seconds=Number(from);
  if(!(seconds>=0))throw new Error('a time from 0 s on the dial\'s clock');
  const at=Math.round(seconds*WINDS_RATE),before=queue.length;
  queue=queue.filter(e=>!(e.tag==='given'&&e.by===by&&e.at>=at));
  return {status:200,json:{withdrawn:before-queue.length}};
}

// Each route the page takes: what it asks (`method`, `path`, `query` its URLSearchParams, `given` what it sends) ->
// {status, json} or, its sound, {status, samples, headers}.
async function handle(method,path,query,given={}){
  try{
    if(path==='/state')return {status:200,json:shown()};
    if(path==='/impedance')return {status:200,json:current?.impedance??null};
    if(path==='/audio'){
      const frames=Math.min(Math.max(1,Number(query?.get('frames'))||1024),16384);
      const samples=await serial(()=>pulled(frames));
      return {status:200,samples,headers:{'x-pace':pace==null?'':pace.toFixed(3),'x-model':current?.model??'','x-version':String(version),
        'x-lungs':`${lungs.air.toFixed(3)} ${lungs.taking?1:0}`,'x-seconds':String((current?.frames??0)/WINDS_RATE)}};
    }
    if(method!=='POST')return {status:404};
    // (Another instrument: made behind the page, the latest chosen taken up -- the page follows /state.)
    if(path==='/instrument'){choose(given.model);return {status:200,json:shown()}}
    if(path==='/keep'){
      if(!current)throw new Error('no instrument yet');
      const named=row=>Object.fromEntries(current.columns.map((c,k)=>[c.join(':'),row[k]]));
      const kept=await env.keep({at:new Date().toISOString(),model:current.model,body:current.name,midi:state.midi,pitch:state.pitch,...(current.lips?{lip:state.lip}:{}),
        ...(current.lips?.slide?{slide:state.slide,position:positionAt(state.slide)}:{}),
        dynamic:state.dynamic,words:String(given.words??''),row:named(state.row),rules:named(state.rules),tract:state.tract.resonances,
        articulation:state.articulation,stroke:state.stroke,softSeconds:state.softSeconds,rise:state.rise,breathAttack:state.breathAttack,repeat:state.repeat,vibrato:state.vibrato,
        breathing:state.breathing,flutter:state.flutter,hum:state.hum});
      return {status:200,json:{kept}};
    }
    if(!current)throw new Error('no instrument yet');
    // (A change the page made for the instrument it was showing: refused where another has been taken up since, so that
    // no column of one is dialled on another.)
    if(given.version!==undefined&&given.version!==version)return {status:409,json:{error:'another instrument was taken up',version}};
    // (Each change the page makes, made between two of its pulls of sound, so that it falls on the frame after the last
    // one pulled -- or, given `at`, at the frame that falls on: s on the dial's own clock, as each pull of sound says it.)
    if(path==='/withdraw')return await serial(()=>withdrawn(given));
    if(given.at!=null)return await serial(()=>later(path,given));
    const answer=await serial(()=>change(path,given));
    if(answer===null)return {status:404};
    return {status:200,json:{...answer,rules:state.rules}};
  }catch(error){return {status:400,json:{error:error.message}}}
}

// (Let go: the engine played stopped.)
const close=()=>{current?.glides?.stop();current?.stream.close()};
return {choose,handle,close};
}
