// The musebot player on the winds' dial (the owner, 2 November 2026: "Let's add the musebot player component, so that we
// can test with more than just a single repeated note"; 3 November 2026: "display on the instrument-soloist page the
// musebot player (integrate it)"): a 3.0 band -- plex_clodbot planning its harmony, MemoryBOT, and the instrument's one
// player (flute_clodbot, woodwind_clodbot or brass_clodbot) -- composes a piece on the score engine (public/render/
// score-engine.js: the bots as in an audio render, their notes and no audio), and its player's MIDI 2.0, as a winds
// synth is sent it (wind-midi2.js withWindControllers: its slurs, legato tongues and phrasing), is played on the dial
// (dial-midi2.mjs DialMidi2) as the dial's sound is pulled, each note sent whole a little ahead, as a musebot sends its
// line (musicxml-performer.js PerformanceFeed). Everything musical is the band's, drawn from its seed -- its meter,
// tempo, harmony, phrases, dynamics and ending (CLAUDE.md, "No musical default written"); the page gives the seed and
// the most it may play, the band ending it within that. The same module on the Mac's dial and the website's (dial.mjs,
// which imports it when a piece is first asked for): in Node its WebAssembly read from the repository, in the
// website's Worker fetched beside it (scripts/build-live-site.mjs).
//
//   playerOf(model, kind) -> {id, instrument}: the dial's wind as its player and the instrument it is asked to play
//   await composeSolo({model, kind, seed, seconds}) -> {player, seconds (its music's), notes: [{at, events}] (each note's
//     MIDI 2.0 whole, s from the piece's start), warnings}
//   new SoloLine(composed, {dial (the dial's /state), send(path, given) -> {status, json}, start, lead})
//     .take(now) -> what it sent: the notes due by `now` + `lead` (s on the dial's clock) given to its DialMidi2;
//     .done(now) once its last note has ended; .shown(now) what the page says of it: its player, seed, length, notes,
//     start (s on the dial's clock), how far it has played, its notes come late, those the dial does not play and why
import '../../public/meter.js';
import {normalizeRenderSpec,RenderSession,listRenderEngines,listHearings,listOutputFormats} from '../../public/render/index.js';
import {AGENTS} from '../../public/agents.js';
import {initializeMidi2,inspectUMP} from '../../public/shared/ump.js';
import {musicalCoreReady} from '../../public/shared/musical-core-installed.js';
import {withWindControllers} from '../../public/shared/performers/wind-midi2.js';
import {WIND_INSTRUMENTS} from '../../public/shared/performers/wind-line.js';
import {PerformanceFeed} from '../../public/shared/performers/musicxml-performer.js';
import {DialMidi2} from './dial-midi2.mjs';

// (Each kind of wind's one player, and the name its player gives an instrument the dial names otherwise.)
const PLAYERS={air:'flute_clodbot',reed:'woodwind_clodbot',lips:'brass_clodbot'},NAMED={'alto-flute':'alto'};
export function playerOf(model,kind){
  const id=PLAYERS[kind],instrument=NAMED[model]??model;
  if(!id||!WIND_INSTRUMENTS[instrument])throw new RangeError(`${model}: no musebot plays it yet`);
  return {id,instrument};
}

// (The MIDI 2.0 codec and the bots' planning core, once: in Node read from the repository, as musical-core-installed.js
// reads its core; in a Worker fetched as ump.js fetches it, beside the page.)
let prepared=null;
const prepare=()=>prepared??=(async()=>{
  const url=new URL('../../public/wasm/midi2.wasm',import.meta.url),fs=globalThis.process?.getBuiltinModule?.('node:fs');
  await initializeMidi2(fs&&url.protocol==='file:'?{bytes:fs.readFileSync(url)}:{});
  await musicalCoreReady;
})();

// (A line's MIDI 2.0 as its notes, each whole: from its Per-Note Management -- or its first event on its key -- to the
// next note begun on that key, its Note Off and its release's controllers with it; what names no note -- a channel's,
// as its bend range -- with the note after it. Each at its first event's time.)
const PER_NOTE=new Set(['perNoteManagement','perNoteController','assignablePerNoteController','perNoteBend','perNotePressure','noteOn','noteOff']);
function wholeNotes(events){
  const notes=[],open=new Map;let loose=[];
  for(const event of events){
    const m=inspectUMP(event.packet);
    if(!PER_NOTE.has(m.kind)){loose.push(event);continue}
    let note=open.get(m.key);
    if(!note||m.kind==='perNoteManagement'){note={at:loose[0]?.seconds??event.seconds,events:loose};loose=[];notes.push(note);open.set(m.key,note)}
    note.events.push(event);
  }
  if(loose.length&&notes.length)notes.at(-1).events.push(...loose);
  return notes;
}

export async function composeSolo({model,kind,seed,seconds}){
  if(!Number.isInteger(seed)||seed<0)throw new RangeError('a seed, a whole number from 0');
  if(!(seconds>0))throw new RangeError('the most it plays, s');
  await prepare();
  const player=playerOf(model,kind);
  const spec=normalizeRenderSpec({version:1,seed,engine:'score',length:{seconds,untilEnding:true},outputs:{midi:true},
    bots:[{id:'plex_clodbot',output:'none',settings:{harmony:'plan'}},{id:'memory',output:'none'},{id:player.id,output:'synth',settings:{instrument:player.instrument}}]},
    {agents:AGENTS,engines:listRenderEngines(),hearings:listHearings(),formats:listOutputFormats()});
  const session=await RenderSession.create({spec,agents:AGENTS,sink:null,clips:new Map,environment:{captureEvents:true},logs:{},strict:false});
  const {engine}=session,result=await session.run();
  const [track,ump]=[...session.umpTracks].find(([id])=>id.startsWith(`bot:${player.id}:`))??[null,[]];
  const events=withWindControllers(ump,engine.captured.filter(c=>c.trackId===track).map(c=>c.event));
  return {player,seed,seconds:result.musicSeconds,notes:wholeNotes(events),warnings:[...(result.warnings??[]),...(result.errors??[]).map(String)]};
}

export class SoloLine{
  constructor(composed,{dial,send,start,lead}){
    Object.assign(this,{composed,start,feed:new PerformanceFeed(composed.notes,{start,lead}),midi2:new DialMidi2({dial,send,by:'soloist'}),sent:0});
    const last=composed.notes.at(-1)?.events.at(-1);
    this.end=start+Math.max(composed.seconds,last?.seconds??0);
  }
  async take(now){
    const due=this.feed.due(now);
    if(!due.length)return {sent:0};
    const answer=await this.midi2.take(due,now);this.sent+=answer.sent;
    return answer;
  }
  done(now){return this.feed.done&&now>=this.end}
  shown(now){
    const {player,seed,seconds,notes,warnings}=this.composed;
    return {player:player.id,instrument:player.instrument,seed,seconds:+seconds.toFixed(3),notes:notes.length,start:+this.start.toFixed(6),at:+Math.max(0,now-this.start).toFixed(3),
      late:this.midi2.late,unplayed:this.midi2.unplayed.map(u=>({at:+u.at.toFixed(3),why:u.why})),refused:this.midi2.refused,warnings};
  }
}
