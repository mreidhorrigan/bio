// The musebot player on the winds' dial (the owner, 2 November 2026: "Let's add the musebot player component, so that we
// can test with more than just a single repeated note"; 3 November 2026: "display on the instrument-soloist page the
// musebot player (integrate it)"): a 3.0 band -- plex_clodbot planning its harmony, MemoryBOT, and the instrument's one
// player (flute_clodbot, woodwind_clodbot or brass_clodbot) -- composes a piece on the score engine (public/render/
// score-engine.js: the bots as in an audio render, their notes and no audio), and its player's MIDI 2.0, as a winds
// synth is sent it (wind-midi2.js withWindControllers: its slurs, legato tongues and phrasing), is played on the dial
// (dial-midi2.mjs DialMidi2) as the dial's sound is pulled, each note sent whole a little ahead, as a musebot sends its
// line (musicxml-performer.js PerformanceFeed). Everything musical is the band's, drawn from its seed -- its meter,
// tempo, harmony, phrases, dynamics and ending (CLAUDE.md, "No musical default written"); the page gives the seed and
// the most it may play, the band ending it within that. Its band is the strings' too (native/live/solo-band.mjs), its
// player told through its instrument's MCP server, as it starts, the dial's compass and what the dial plays of its
// wind (windsEngineOf), and so its personality played as the dial's wind is (the owner, 3 November 2026: "The point of
// this is that the bot applies its personality differently depending on the properties of the instrument it's linked
// to"). The same module on the Mac's dial and the website's (dial.mjs, which imports it when a piece is first asked
// for): in Node its WebAssembly read from the repository, in the website's Worker fetched beside it (scripts/
// build-live-site.mjs).
//
//   playerOf(model, kind) -> {id, instrument}: the dial's wind as its player and the instrument it is asked to play
//   windsEngineOf(dial) -> what the dial (its /state) says it plays of its wind (instrument-facts.js `engine`)
//   await composeSolo({model, kind, seed, seconds, compass, engine, personality}) -> {player, seed, seconds (its
//     music's), notes: [{at, events}] (each note's MIDI 2.0 whole, s from the piece's start), personality (as its player
//     drew it), warnings}; compass the dial's notes, [low, high], its register kept within them (instrument-facts.js
//     compass.engine); personality its levers, grammars and tone ranges given (playerSettingsOf), the rest drawn from
//     its seed
//   new SoloLine(composed, {dial (the dial's /state), send(path, given) -> {status, json}, start, lead})
//     .take(now) -> what it sent: the notes due by `now` + `lead` (s on the dial's clock) given to its DialMidi2;
//     .done(now) once its last note has ended; .shown(now) what the page says of it: its player, seed, length, notes,
//     start (s on the dial's clock), how far it has played, its notes come late, those the dial does not play and why
import {withWindControllers} from '../../public/shared/performers/wind-midi2.js';
import {WIND_INSTRUMENTS} from '../../public/shared/performers/wind-line.js';
import {PerformanceFeed} from '../../public/shared/performers/musicxml-performer.js';
import {composeBand,wholeNotes,playerSettingsOf,playerShown} from '../live/solo-band.mjs';
import {DialMidi2} from './dial-midi2.mjs';
export {playerSettingsOf,playerShown};

// (Each kind of wind's one player, and the name its player gives an instrument the dial names otherwise.)
const PLAYERS={air:'flute_clodbot',reed:'woodwind_clodbot',lips:'brass_clodbot'},NAMED={'alto-flute':'alto'};
export function playerOf(model,kind){
  const id=PLAYERS[kind],instrument=NAMED[model]??model;
  if(!id||!WIND_INSTRUMENTS[instrument])throw new RangeError(`${model}: no musebot plays it yet`);
  return {id,instrument};
}

// (What the dial plays of its wind, as it says itself in its /state: its player's flutter, hum and growl, the mutes its
// player has where it takes one (brass-mutes.mjs), and its quickest note, its tongue's stroke -- not a multiphonic,
// which DialMidi2 says it does not play.)
export function windsEngineOf(dial){
  const mutes=dial.mutes??[];
  return {name:'the winds dial (OpenWInD)',techniques:['hum','growl','flutter',...mutes.length?['mute']:[]],mutes,...dial.strokeLeast?.tongued>0?{quickest:dial.strokeLeast.tongued}:{}};
}

export async function composeSolo({model,kind,seed,seconds,compass=null,engine=null,personality={}}){
  const player=playerOf(model,kind);
  const composed=await composeBand({player,seed,seconds,compass,engine,personality});
  return {player,seed:composed.seed,seconds:composed.seconds,notes:wholeNotes(withWindControllers(composed.ump,composed.events)),personality:composed.personality,warnings:composed.warnings};
}

export class SoloLine{
  constructor(composed,{dial,send,start,lead}){
    Object.assign(this,{composed,start,feed:new PerformanceFeed(composed.notes,{start,lead}),midi2:new DialMidi2({dial,send,by:'soloist'}),sent:0});
    const last=composed.notes.at(-1)?.events.at(-1);
    this.end=start+Math.max(composed.seconds,last?.seconds??0);
  }
  async take(now){
    const due=this.feed.due(now);
    if(!due.length)return {sent:0};
    const answer=await this.midi2.take(due,now);this.sent+=answer.sent;
    return answer;
  }
  done(now){return this.feed.done&&now>=this.end}
  shown(now){
    const {player,seed,seconds,notes,personality,warnings}=this.composed;
    return {player:player.id,instrument:player.instrument,seed,seconds:+seconds.toFixed(3),notes:notes.length,personality,start:+this.start.toFixed(6),at:+Math.max(0,now-this.start).toFixed(3),
      late:this.midi2.late,unplayed:this.midi2.unplayed.map(u=>({at:+u.at.toFixed(3),why:u.why})),refused:this.midi2.refused,warnings};
  }
}
