// A woodwind note's fingerings as its players choose among them by where their fingers stand: of the fingerings its
// chart gives the note on the register its standard one speaks, those its players' guide documents (each candidate's
// `documented`: render/synthesis/openwind-fingerings/<model>.json), the one that moves the fewest of its holes from the
// fingering held -- a clarinettist's fingers kept down through the throat tones from the clarion and back, a
// saxophonist's bis or side B-flat by the note before -- and its standard where none moves fewer. Only one that sounds
// its note no further from it than its standard does, within a steady tone's pitch difference limen (LIMEN): never a
// note put out of tune to save a finger.
//   Its sound, not only its fingers' economy: the clarinet's clarion slurred down to a throat tone on its standard
// fingering, every finger lifted at once, rode the clarion's resonance up into the throat fingering's second, a squeal
// some 1125 Hz and 10 dB over its note at every dynamic (C5, D5 or B4 to G4, 6 November 2026; UNSW's clarinet holds that
// peak as high, 0.64 of its first), where the fingers it keeps down land on its G4 within some 30 ms -- its right
// hand's (A---| 123), or with its left hand's second and third (A-23|-23 F, the fewest moved from the clarion) -- from
// C5, D5 and B4 alike (claude-scratch/keys/slur-rows.mjs, break-probe3.mjs). One module for the Mac's dial and the page's (dial.mjs settleAt), each fed its
// body's chart (alternatesOf: native/openwind/live.mjs, scripts/build-live-site.mjs).

// (A steady tone's pitch difference limen, cents: 2.5 to 2.8, J. C. Brown & K. V. Vaughn 1996, "Pitch center of
// stringed instrument vibrato tones", JASA 100(3), 1728-1735, doi:10.1121/1.416070 -- its upper end.)
export const LIMEN=2.8;

// Each charted note's fingerings among which its players choose, where it has more than one, from its chart (`chart`, a
// woodwind's openwind-fingerings JSON): {midi: [{documented, open: {hole: its opening}, cents}]}, its standard first --
// the chart's first candidate, which its body's rules play -- then each documented on its register, in the chart's order.
export function alternatesOf(chart){
  return Object.fromEntries(chart.notes.flatMap(n=>{
    if(!n.candidates?.length)return [];
    const [standard,...rest]=n.candidates,near=Math.abs(standard.cents)+LIMEN;
    const own=[standard,...rest.filter(c=>c.documented&&c.mode===standard.mode&&Math.abs(c.cents)<=near)];
    return own.length>1?[[n.midi,own.map(c=>({documented:c.documented??null,open:{...c.fingering},cents:c.cents}))]]:[];
  }));
}

// The row a note is played on from the row held before it (`before`): of its fingerings (`alternatives`, alternatesOf's
// for the note, its standard first), the one whose holes move least from `before`'s -- a finger's part-way hole moved
// as far as it moves -- its standard's where none moves less; each a row of `row` (its rules' at the note, the standard
// fingering's) with only the holes its fingerings differ in set as it sets them, so that every other hole stays as the
// rules hold it. `row` as it is where it stands off its standard in a hole they differ in -- a pitch between charted
// notes a finger shades -- or there is nothing to choose among. `columns`: its body's (an opening's [kind, its hole's
// place in `holes`]). -> {row, documented: its fingering's name, or null where none is documented or none chosen}
export function fingeringAmong(alternatives,row,before,columns,holes){
  if(!alternatives||!before||before.length!==row.length)return {row,documented:null};
  const opening=columns.flatMap((c,k)=>c[0]==='opening'?[[k,holes[c[1]]]]:[]),[standard]=alternatives;
  const varied=opening.filter(([,h])=>alternatives.some(a=>(a.open[h]??0)!==(standard.open[h]??0)));
  if(varied.some(([k,h])=>row[k]!==(standard.open[h]??0)))return {row,documented:null};
  let best=null;
  for(const a of alternatives){
    const own=[...row];for(const [k,h] of varied)own[k]=a.open[h]??0;
    const moved=opening.reduce((sum,[k])=>sum+Math.abs(own[k]-before[k]),0);
    if(!best||moved<best.moved)best={row:own,documented:a.documented,moved};
  }
  return {row:best.row,documented:best.documented};
}
