// A wind player's standing settings, what it plays with besides its rows: as the live dial takes an instrument up and
// follows its notes (dial.mjs), and as every fit's probe plays it (render/synthesis/tools/engine_probe.py, through this
// file run alone) -- written once for both (the owner, 6 November 2026: "don't omit anything from the fits that the
// live-dial includes! Those should be synchronized"). Its vocal tract: its players' following the note where theirs is
// measured (vocal-tract.js; Chen, Smith & Wolfe 2009), or raised toward it as they raise it where the bore alone will
// not hold the note's register -- the shape bending at `raised` times the note's frequency, at a bend's height
// (VocalTract.bent; "Don't underestimate the involvement of the vocal tract and other player-manipulable parameters in
// accessing notes considered extreme"); its reed's or lips' flow's turbulence (turbulence.js); its noise, each kind its
// player has, at the player's temperature, seeded by the band's seed (player-noise.js); and its vibrato as its players
// keep one, a woodwind's in its breath (vibrato.js; a brass player's along its lips, dial.mjs sway).
//   node native/openwind/standing.mjs MODEL KIND '[[hz, raised|null], ...]'
//     -> {turbulence, noise: [lines], vibrato: {rate, width, reach}, share, tractSeconds (the dial's move to a
//         note's: transitions.js), tracts: [resonances]}
import {VocalTract} from '../../public/shared/performers/vocal-tract.js';
import {turbulenceOf} from '../../public/shared/performers/turbulence.js';
import {windsNoiseKinds,windsNoiseLine} from '../../public/shared/performers/player-noise.js';
import {WIND_VIBRATO,WIND_VIBRATO_REACH} from '../../public/shared/performers/vibrato.js';
import {DEFAULT_SEED} from '../../public/shared/opening-time.js';
import {VIBRATO_SHARE} from '../../render/synthesis/src/openwind-passages.mjs';
import {transition} from '../../public/shared/performers/transitions.js';

// (Whether its players' tract is measured -- the reed woodwinds', theirs the clarinettists' so far (registry/players/
// winds.json) -- else it plays none.)
export const tractMeasured=model=>{try{VocalTract.normal(model,440);return true}catch{return false}};
// Its players' tract at a note sounding at `hz`: theirs in normal playing, or raised toward it at `raised` times its
// frequency -> its resonances (none where theirs is not measured).
export function playersTract(model,hz,raised=null){
  if(!tractMeasured(model))return [];
  return (raised?VocalTract.bent(model,hz*raised):VocalTract.normal(model,hz)).resonances;
}
// Its reed's or lips' flow's turbulence as it is taken up: its players' (registry/players/winds.json flow.turbulence),
// none for a jet's, whose turbulence is its law's.
export const turbulenceLevel=model=>turbulenceOf(model)??0;
// (Its noise's temperatures as it is taken up: the player's and each kind's.)
export const NOISE_TEMPERATURES=Object.freeze({player:1,breath:1,lips:1});
// Its noise's lines (stream.rs NoiseLine), each kind its player has -- a reed's or jet's `kind` its breath's, the lips'
// its breath's and its lips' tension -- the first seeded by the band's seed where `seeded`.
export function noiseLines(kind,temperatures=NOISE_TEMPERATURES,seeded=false){
  return windsNoiseKinds(kind).map((what,k)=>windsNoiseLine(what,temperatures.player*temperatures[what],seeded&&k===0?DEFAULT_SEED:undefined));
}
// Its players' vibrato: its rate and its width peak to peak, cents (none, 0, where they play without one), and the
// widest those without one take in a style that asks for it.
export const vibratoOf=model=>{const own=WIND_VIBRATO[model]??WIND_VIBRATO[{'alto-flute':'alto'}[model]]??{rate:5,width:0};return {...own,reach:WIND_VIBRATO_REACH[model]??null}};
// A woodwind's vibrato on its breath's `column` (stream.rs VibratoLine): VIBRATO_SHARE of its breath a cent of its
// curve, half `width` each way, moved to over `seconds`.
export const breathVibrato=(column,{width,rate},seconds=0)=>({columns:[column],depths:[VIBRATO_SHARE*width/2],cents:[false],rate,seconds});

// (Run alone, under Node: never in a page, which reads it as a module only.)
if(globalThis.process?.argv?.[1]&&decodeURIComponent(new URL(import.meta.url).pathname)===globalThis.process.argv[1]){
  const [model,kind,pairs='[]']=process.argv.slice(2);
  console.log(JSON.stringify({turbulence:turbulenceLevel(model),noise:noiseLines(kind,NOISE_TEMPERATURES,true),vibrato:vibratoOf(model),share:VIBRATO_SHARE,
    tractSeconds:transition('tract').least,
    tracts:JSON.parse(pairs).map(([hz,raised])=>playersTract(model,hz,raised))}));
}
