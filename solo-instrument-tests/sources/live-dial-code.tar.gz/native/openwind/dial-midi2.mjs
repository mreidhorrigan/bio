// A player's MIDI 2.0 played on the winds' dial (native/openwind/dial.mjs): its notes read as every winds synth reads
// them (wind-midi2.js WindDecoder) and made the dial's own changes at their times (`at`, s on the dial's clock), beside a
// visitor's gestures -- so that a musebot plays the dial as its synthesizer (docs/MUSEBOTS_3_SPECIFICATION.md:
// "Synthesizers ingest the MIDI 2.0 data"; research/LIVE_DIAL_ON_THE_WEBSITE.md, "Players on the dial"). Its notes come
// as its player sends them, a few ms ahead: each time more comes, its line is planned again, what was made stands, the
// present is put right at once where a note came late (`late`), and the changes still to come that differ are withdrawn
// (the dial's /withdraw) and sent again.
//
// A note, as the dial's player plays it: from rest, blown (its attack's rise its MIDI 2.0's, #73, within the dial's
// reach; on a reed or the lips begun that rise before its onset, its tongue let go at it); within the breath of the
// note before -- after a rest shorter than a breath (breath.mjs BREATH.breathGap, the renders' own) -- slurred where it
// is joined to it and its controllers say so (wind-midi2.js #16), else legato-tongued (portato) or tongued, its air
// stopped by the tongue from that note's end, or the dial's stroke before its onset, whichever is earlier (as the
// renders' breath stops it, breath.mjs), its stroke sent that long ahead so that it speaks at its onset (the dial's
// /state strokeLeast: the least its tongue and fingers allow); its pitch its Note On's with its bend where it holds
// (physical-events.mjs heldCents, as the renders sound it: as it began, a slurred note had been fingered at the note it
// slurred from), at the mark its velocity falls in (dynamics.js scoredDynamicOf: the dial's rows are its eight marks);
// its swell its Per-Note Pressure, within the renders' reach of its mean (breath.mjs swellOf), and on a woodwind its
// pitch's path breathed about the pitch it holds, a slur's glide in its fingers', as the renders breathe a woodwind's
// vibrato (physical-events.mjs breathedCents), both the player's swell (/swell); on a brass instrument its pitch's path
// followed by its player's lips about the pitch it holds (/bend), as the renders bend a brass note; its flutter, hum and growl its own
// (/flutter, /hum, /growl); let go at its end where no note follows joined. One note at a time: a note begun ends the
// one before. A brass player's mute (/mute) put in from the end of the note before the first it plays, the dial putting
// it in once its breath is let go and the bell has rung down, and each mute its line names readied as soon as the line
// names it (/mute ready), as its player takes it out onto its stand. What the dial does not play is said in `unplayed`:
// a pitch outside its notes, a mute its player has none of, a multiphonic.
import {WindDecoder} from '../../public/shared/performers/wind-midi2.js';
import {scoredDynamicOf} from '../../public/shared/dynamics.js';
import {controlCurve,heldCents,breathedCents} from '../../render/synthesis/physical-events.mjs';
import {BREATH,swellOf,swellAt} from '../../render/synthesis/src/breath.mjs';
import {VIBRATO_SHARE} from '../../render/synthesis/src/openwind-passages.mjs';

// (Two times this near are one: the engine's capture's tick, audio.js captureUMP. A change made this long ago and more
// is let go of, its note too, the state it left kept: what is planned again stays short.)
const TICK=1/9600,SETTLED_SECONDS=2;
const clamp=(x,[low,high])=>Math.min(high,Math.max(low,x));
// (The player's voices through its instrument: a hum, a growl.)
const VOICES=['hum','growl'];
const midiOf=hz=>69+12*Math.log2(hz/440);
// (Seconds as the dial is given them: to a microsecond.)
const micro=t=>+t.toFixed(6);

// A note's pitch path, cents from its Note On's pitch, over the note, as the renders read it (physical-events.mjs
// controlCurve): [{seconds, cents}], or null where it has none.
function pathOf(n){
  const bends=(n.controls??[]).filter(c=>c.action===1),start=n.atSeconds;
  if(!bends.length)return null;
  return controlCurve(bends.map(c=>({...c,atSeconds:start+c.seconds})),start,start+Math.max(TICK,n.duration),0,{scale:100}).map(p=>({seconds:p.seconds,cents:p.value}));
}
// (The cents it holds, as the renders sound a note on a model of one pitch a note: physical-events.mjs heldCents -- a
// microtone held, a glide in or a scoop arrived, a vibrato swaying about it.)
const heldOf=(n,path=pathOf(n))=>path?heldCents(path,n.atSeconds,n.atSeconds+Math.max(TICK,n.duration),{period:1/n.frequency}):0;
const along=(points,t)=>{
  if(t<=points[0][0])return points[0][1];
  for(let k=1;k<points.length;k++)if(t<=points[k][0]){const [a,x]=points[k-1],[b,y]=points[k];return b>a?x+(y-x)*(t-a)/(b-a):y}
  return points.at(-1)[1];
};

// The player's swell through a note from `start` (its change's, at or before its onset) to `end`: [[s, share]], its
// first at `start`, as it is at its onset -- its pressure's swell times, on a woodwind (`breathed`), its pitch's path
// breathed about the pitch it holds, a slur's glide in its fingers' (physical-events.mjs breathedCents, as the renders
// breathe it); each within the dial's `reach`.
function sharesOf(n,start,end,breathed,reach){
  const performance=n.performance??{},onset=n.atSeconds,last=Number.isFinite(end)?end:Math.max(onset,...(performance.pressureTimes??[]).map(t=>onset+t),...(n.controls??[]).map(c=>onset+c.seconds+(c.ramp??0)));
  const swell=swellOf(performance.pressureCurve,{from:onset,seconds:Math.max(TICK,last-onset),until:last,times:performance.pressureTimes});
  const path=breathed?pathOf(n):null;
  const sway=path?breathedCents(path,onset,Math.max(last,onset+TICK),{held:heldOf(n,path),slurred:n.slurred===true}).map(p=>[p.seconds,p.cents]):null;
  const times=[...new Set([start,...(swell??[]).map(([t])=>t),...(sway??[]).map(([t])=>t)].map(micro))].filter(t=>t>=micro(start)&&t<=micro(last)).sort((a,b)=>a-b);
  return times.map(t=>[t,+clamp(swellAt(swell,Math.max(t,onset))*(sway?1+VIBRATO_SHARE*along(sway,Math.max(t,onset)):1),reach).toFixed(6)]);
}

// A brass note's pitch path as its player's lips follow it from `start` (its change's, at or before its onset) to `end`:
// [[s, cents from the pitch it holds]], its first at `start`, as it is at its onset; null where it has none.
function bendsOf(n,start,end){
  const path=pathOf(n);if(!path)return null;
  const onset=n.atSeconds,held=heldOf(n,path),points=path.map(p=>[p.seconds,p.cents]);
  const times=[...new Set([start,...points.map(([t])=>t)].map(micro))].filter(t=>t>=micro(start)&&t<=micro(end)).sort((a,b)=>a-b);
  return times.map(t=>[t,+(along(points,Math.max(t,onset))-held).toFixed(3)]);
}

// A line's notes (WindDecoder's events) as the dial's changes, each {at, path, given, note}, in the order made: what
// the dial (`dial`: its /state -- its notes, its limits, whether it has lips, its tongue as the player found it and the
// least its strokes take, the mute in and its mutes) is told for each. -> {changes, unplayed}.
export function dialChanges(notes,dial){
  const limits=dial.limits,[low,high]=[Math.min(...dial.notes),Math.max(...dial.notes)],breathed=!dial.partials,out=[],unplayed=[];
  const playable=[];
  for(const n of [...notes].sort((a,b)=>a.atSeconds-b.atSeconds||a.identity-b.identity)){
    if(!(n.duration>0))continue;
    const pitch=midiOf(n.frequency)+heldOf(n)/100;
    if(!(pitch>=low&&pitch<=high)){unplayed.push({note:n.identity,at:n.atSeconds,why:`its pitch, ${pitch.toFixed(2)}, is outside the instrument's notes, ${low} to ${high}`});continue}
    playable.push({n,pitch});
  }
  // (How each is joined to the note before, and when its change begins: within its breath, slurred at its onset, or its
  // stroke sent ahead -- never before the change of the note before it.)
  const joins=[];
  playable.forEach(({n},k)=>{
    const prev=playable[k-1]?.n,gap=prev?n.atSeconds-(prev.atSeconds+prev.duration):Infinity,t=n.atSeconds;
    // (From rest, a reed's or a brass player's tongue is held on its reed or before its lips while its breath rises and let
    // go as it has risen (dial.mjs fromRest): its change begun that rise before its onset, so that it speaks at it, never
    // before the note before has ended -- begun at its onset, it had spoken its rise late, 85 ms on the website's
    // clarinet; a flute's air let go into its rise at its onset.)
    if(!(gap<BREATH.breathGap)){
      const rise=dial.kind==='air'?0:n.performance?.attackSeconds>0?clamp(n.performance.attackSeconds,limits.rise):dial.played?.rise??0;
      joins.push({begin:Math.max(prev?prev.atSeconds+prev.duration:-Infinity,t-rise),how:null});return;
    }
    if(n.slurred&&!n.portato&&gap<=TICK){joins.push({begin:t,how:{articulation:'slurred'}});return}
    const legato=n.portato===true,name=legato?'softSeconds':'stroke',asked=clamp(Math.max(gap,dial.played[name]),limits[name]);
    const length=Math.max(asked,dial.strokeLeast?.[legato?'legato':'tongued']??0);
    joins.push({begin:Math.max(joins[k-1].begin+TICK,t-length),how:{articulation:legato?'legato':'tongued',[name]:+asked.toFixed(6)}});
  });
  let flutter=false,mute=dial.mute??null;const voiced={hum:false,growl:false},mutes=dial.mutes??[];
  playable.forEach(({n,pitch},k)=>{
    const own=n.atSeconds+n.duration,next=playable[k+1]?.n,{begin:t,how}=joins[k],joined=how!==null;
    const followed=Boolean(next)&&joins[k+1].how!==null,end=Math.min(own,next?joins[k+1].begin:Infinity);
    const at=(time,path,given)=>out.push({at:micro(time),path,given,note:n.identity});
    const x=n.extended??{};
    if(x.flutter){at(t,'/flutter',{on:true,...(x.flutter.hz>0?{hz:clamp(x.flutter.hz,limits.flutterHz)}:{}),...(Number.isFinite(x.flutter.depth)?{depth:clamp(x.flutter.depth,limits.flutterDepth)}:{})});flutter=true}
    else if(flutter){at(t,'/flutter',{on:false});flutter=false}
    for(const kind of VOICES){
      const v=x[kind];
      if(v){at(t,`/${kind}`,{on:true,...(v.hz>0?{interval:+clamp(12*Math.log2(v.hz/n.frequency),limits[`${kind}Interval`]).toFixed(4)}:{}),...(Number.isFinite(v.level)?{level:clamp(v.level,limits[`${kind}Level`])}:{}),
        ...(kind==='growl'&&Number.isFinite(v.rough)?{rough:clamp(v.rough,limits.growlRough)}:{})});voiced[kind]=true}
      else if(voiced[kind]){at(t,`/${kind}`,{on:false});voiced[kind]=false}
    }
    // (Its mute put in from the end of the note before, or its own start.)
    const muted=x.mute?.kind??null;
    if(muted!==mute){
      if(muted!==null&&!mutes.includes(muted))unplayed.push({note:n.identity,at:n.atSeconds,why:`its mute, ${muted}: its player has none (${mutes.join(', ')||'no mute'})`});
      else{const prev=playable[k-1]?.n;at(prev?Math.min(t,prev.atSeconds+prev.duration):t,'/mute',{mute:muted});mute=muted}
    }
    if(x.multiphonic)unplayed.push({note:n.identity,at:n.atSeconds,why:'its multiphonic: the dial plays none yet'});
    const shares=sharesOf(n,t,end,breathed,limits.swell);
    if(joined)at(t,'/articulation',how);
    else if(n.performance?.attackSeconds>0)at(t,'/articulation',{rise:+clamp(n.performance.attackSeconds,limits.rise).toFixed(6)});
    at(t,'/swell',{share:shares[0][1]});
    at(t,'/pitch',{pitch:+pitch.toFixed(4),dynamic:scoredDynamicOf(n.velocity)});
    const bends=breathed?null:bendsOf(n,t,end);
    if(bends)at(t,'/bend',{cents:bends[0][1]});
    if(!joined)at(t,'/blow',{on:true});
    for(let j=1;j<shares.length;j++)at(shares[j-1][0],'/swell',{share:shares[j][1],seconds:micro(shares[j][0]-shares[j-1][0])});
    for(let j=1;j<(bends?.length??0);j++)at(bends[j-1][0],'/bend',{cents:bends[j][1],seconds:micro(bends[j][0]-bends[j-1][0])});
    if(Number.isFinite(own)&&!followed){
      at(own,'/blow',{on:false});at(own,'/swell',{share:1});
      if(!next){if(flutter){at(own,'/flutter',{on:false});flutter=false}for(const kind of VOICES)if(voiced[kind]){at(own,`/${kind}`,{on:false});voiced[kind]=false}}
    }
  });
  return {changes:out.map((c,k)=>({c,k})).sort((a,b)=>a.c.at-b.c.at||a.k-b.k).map(({c})=>c),unplayed};
}

// What a line's changes leave the dial playing at `time` (s), from `base`: whether it is blown, its note, pitch and
// dynamic, its articulation, flutter, hum, growl, swell and mute.
const NOTHING=Object.freeze({blowing:false,note:null,pitch:null,dynamic:null,articulation:null,flutter:false,hum:false,growl:false,swell:1,mute:undefined});
function stateAt(changes,time,base=NOTHING){
  const s={...base};
  for(const c of changes){
    if(c.at>time)break;
    const g=c.given;
    if(c.path==='/blow'){s.blowing=g.on;if(!g.on)s.note=null}
    else if(c.path==='/pitch'){s.pitch=g.pitch;s.dynamic=g.dynamic;s.note=c.note}
    else if(c.path==='/articulation'&&g.articulation)s.articulation=g.articulation;
    else if(c.path==='/flutter')s.flutter=g.on?g:false;
    else if(c.path==='/hum'||c.path==='/growl')s[c.path.slice(1)]=g.on?g:false;
    else if(c.path==='/swell')s.swell=g.share;
    else if(c.path==='/mute')s.mute=g.mute;
  }
  return s;
}
const keyOf=c=>JSON.stringify([c.at,c.path,c.given]);

// One player's line on the dial. `dial`: its /state (its version, notes, limits and lips); `send(path, given)`: a change
// made on it (the dial's handle, a request to its server, a message to its Worker) -> its answer; `by`: the player's
// name there. take(events, now) -- its MIDI 2.0 come since, each {seconds, packet} on the dial's clock, and the dial's
// clock as last heard (s) -- plans its line again and tells the dial what changed. -> {late, sent, withdrawn}.
export class DialMidi2{
  constructor({dial,send,by='player'}){
    Object.assign(this,{dial,send,by,decoder:new WindDecoder(),notes:new Map,sent:[],base:NOTHING,late:0,unplayed:[],refused:[],readied:new Set});
  }
  async take(events,now){
    for(const event of this.decoder.take(events))this.notes.set(event.identity,event);
    // (Each mute its line names readied at once, the one in kept.)
    for(const n of this.notes.values()){
      const mute=n.extended?.mute?.kind;
      if(!mute||this.readied.has(mute)||!(this.dial.mutes??[]).includes(mute))continue;
      this.readied.add(mute);await this.send('/mute',{mute,ready:true,by:this.by,version:this.dial.version});
    }
    const {changes,unplayed}=dialChanges([...this.notes.values()],this.dial);this.unplayed=unplayed;
    const made=this.sent.filter(c=>c.at<=now),want=stateAt(changes,now,this.base),have=stateAt(made,now,this.base),out=[];
    // (Put right at once: a note that should sound now and has not begun -- come after its time -- or one that should
    // have ended.)
    if(want.note!==have.note){
      const now6=micro(now),fix=(path,given)=>out.push({at:now6,path,given,note:want.note});
      if(want.note==null){if(have.blowing){fix('/blow',{on:false});fix('/swell',{share:1})}}
      else{
        this.late++;
        if(JSON.stringify(want.flutter)!==JSON.stringify(have.flutter))fix('/flutter',want.flutter||{on:false});
        for(const kind of VOICES)if(JSON.stringify(want[kind])!==JSON.stringify(have[kind]))fix(`/${kind}`,want[kind]||{on:false});
        if(want.mute!==undefined&&want.mute!==have.mute)fix('/mute',{mute:want.mute});
        if(have.blowing)fix('/articulation',{articulation:want.articulation??'tongued'});
        fix('/swell',{share:want.swell});
        fix('/pitch',{pitch:want.pitch,dynamic:want.dynamic});
        if(!have.blowing&&want.blowing)fix('/blow',{on:true});
      }
    }
    // (Still to come: from the first change that differs, what was sent withdrawn and the line's own sent.)
    const planned=changes.filter(c=>c.at>now),waiting=this.sent.filter(c=>c.at>now);
    let i=0;while(i<planned.length&&i<waiting.length&&keyOf(planned[i])===keyOf(waiting[i]))i++;
    let withdrawn=0,kept=waiting;
    if(i<planned.length||i<waiting.length){
      // (Frames as the dial counts them, a change withdrawn by its frame.)
      const from=Math.min(planned[i]?.at??Infinity,waiting[i]?.at??Infinity),frame=t=>Math.round(t*this.dial.rate),cut=frame(from);
      if(waiting.some(c=>frame(c.at)>=cut))withdrawn=(await this.send('/withdraw',{by:this.by,from,version:this.dial.version}))?.json?.withdrawn??0;
      kept=waiting.filter(c=>frame(c.at)<cut);
      out.push(...planned.filter(c=>frame(c.at)>=cut));
    }
    for(const c of out){
      const answer=await this.send(c.path,{...c.given,at:c.at,by:this.by,version:this.dial.version});
      if(answer&&answer.status!==200)this.refused=[...this.refused.slice(-9),{...c,status:answer.status,error:answer.json?.error}];
    }
    this.sent=[...made,...kept,...out].sort((a,b)=>a.at-b.at);
    this.settle(now);
    return {late:this.late,sent:out.length,withdrawn};
  }
  // (What was made long since let go of, the state it left kept; each note ended long since, but the last.)
  settle(now){
    const before=now-SETTLED_SECONDS,old=this.sent.filter(c=>c.at<before);
    if(!old.length)return;
    this.base=stateAt(old,before,this.base);this.sent=this.sent.filter(c=>c.at>=before);
    const ended=[...this.notes.values()].filter(n=>n.atSeconds+n.duration<before).sort((a,b)=>a.atSeconds-b.atSeconds);
    for(const n of ended.slice(0,-1))this.notes.delete(n.identity);
  }
}
