// A wind's rows of controls as its engine takes them, and the names of a brass body's notes: one module for the Mac's
// dial and tools (render/node/winds-stream.mjs, brass-attacks.mjs) and for the dial in a page (native/live/site), so
// that neither keeps its own.

// (The rate its player renders at: the renders' own, its body's filter brought down to it.)
export const WINDS_RATE=48000;

// A brass body's row at lip frequency `lip` (Hz), from its rules.json (`rules`): drawn straight between the two rows
// saved about it (a row's values go as powers of the lip frequency, so within some 1e-5 of its own: save_brass_body.py
// GRID_CENTS), its breath `pressure` (Pa) over the row's closing pressure, as OpenWInD's Reed1dof takes it; and, where
// it has valves, each valve's two switches at its opening of `valves` (1 raised, 0 pressed: a fingering's, rules.notes
// `valves`), every one raised where none is given; a mute's hollow in its bell, a side branch closed at the mute's base,
// held shut (save_brass_body.py muted: its layout's `closed`, rules.json `valves`, or `row` where it has none).
export function lipsRow(rules,lip,pressure,valves=null){
  const {lips,rows,cents}=rules.grid,at=Math.min(Math.max(1200*Math.log2(lip/lips[0])/cents,0),lips.length-1),k=Math.min(Math.floor(at),lips.length-2),share=at-k;
  const own=rows[k].map((v,c)=>v+(rows[k+1][c]-v)*share);
  own[rules.columns.indexOf(rules.breath)]=pressure/own[rules.columns.indexOf(rules.closing)];
  const laid=rowLayout(rules);
  if(!laid)return own;
  const row=new Array(laid.width).fill(1);
  laid.lips.forEach((at,c)=>row[at]=own[c]);
  (rules.valves?.columns??[]).forEach((columns,v)=>columns.forEach(at=>row[at]=valves?.[v]??1));
  (laid.closed??[]).forEach(at=>row[at]=0);
  return row;
}
// (A brass body's row's layout -- its lips', valves' and a mute's hollow's columns -- where its row is more than its lips'.)
export const rowLayout=rules=>rules.valves??rules.row??null;
// (Where a brass body's lips' column `name` stands in its row: lipsRow's.)
export const lipsColumn=(rules,name)=>{const c=rules.columns.indexOf(name),laid=rowLayout(rules);return laid?laid.lips[c]:c};
// The way a brass player's embouchure moves its lips about lip frequency `lip`: every column of its row the grid moves
// there (rules.json `grid`, its register's law), each one's cents per cent of the lips' frequency, its mouth's pressure
// kept -- the breath's column as their closing pressure moves against it. A vibrato sways them all along it, as a
// player's press of the mouthpiece into the lips moves the whole embouchure toward a higher note's (its players' force
// rising with the note: P. Amann et al. 2026, doi:10.1051/aacus/2026025) -- never their frequency alone, their closing
// pressure, damping and flow left where the note's were. -> {columns, slopes}
export function lipsDirection(rules,lip,pressure,valves=null){
  const h=rules.grid.cents,[down,up]=[-h,h].map(c=>lipsRow(rules,lip*2**(c/1200),pressure,valves)),columns=[],slopes=[];
  down.forEach((v,c)=>{const w=up[c];if(v>0&&w>0&&w!==v){columns.push(c);slopes.push(600*Math.log2(w/v)/h)}});
  return {columns,slopes};
}

// (A note's name among its body's: its partial, on its fingering or at its slide's position where it has one -- the key
// of its attacks, attacks.json. brass-attacks.mjs keeps its own copy, held to this one (test/winds-dial.test.mjs), until
// its attacks are next measured: its own source is in their digest (madeFrom), so that changing it measures them all.)
export const noteKey=n=>n.fingering?`${n.fingering} ${n.partial}`:n.position!=null?`${n.position} ${n.partial}`:String(n.partial);
