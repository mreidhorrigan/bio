// A wind's rows of controls as its engine takes them, and the names of a brass body's notes: one module for the Mac's
// dial and tools (render/node/winds-stream.mjs, brass-attacks.mjs) and for the dial in a page (native/live/site), so
// that neither keeps its own.

// (The rate its player renders at: the renders' own, its body's filter brought down to it.)
export const WINDS_RATE=48000;

// A brass body's row at lip frequency `lip` (Hz), from its rules.json (`rules`): drawn straight between the two rows
// saved about it (a row's values go as powers of the lip frequency, so within some 1e-5 of its own: save_brass_body.py
// GRID_CENTS), its breath `pressure` (Pa) over the row's closing pressure, as OpenWInD's Reed1dof takes it; and, where
// it has valves, each valve's two switches at its opening of `valves` (1 raised, 0 pressed: a fingering's, rules.notes
// `valves`), every one raised where none is given.
export function lipsRow(rules,lip,pressure,valves=null){
  const {lips,rows,cents}=rules.grid,at=Math.min(Math.max(1200*Math.log2(lip/lips[0])/cents,0),lips.length-1),k=Math.min(Math.floor(at),lips.length-2),share=at-k;
  const own=rows[k].map((v,c)=>v+(rows[k+1][c]-v)*share);
  own[rules.columns.indexOf(rules.breath)]=pressure/own[rules.columns.indexOf(rules.closing)];
  if(!rules.valves)return own;
  const row=new Array(rules.valves.width).fill(1);
  rules.valves.lips.forEach((at,c)=>row[at]=own[c]);
  rules.valves.columns.forEach((columns,v)=>columns.forEach(at=>row[at]=valves?.[v]??1));
  return row;
}
// (Where a brass body's lips' column `name` stands in its row: lipsRow's.)
export const lipsColumn=(rules,name)=>{const c=rules.columns.indexOf(name);return rules.valves?rules.valves.lips[c]:c};

// (A note's name among its body's: its partial, on its fingering or at its slide's position where it has one -- the key
// of its attacks, attacks.json. brass-attacks.mjs keeps its own copy, held to this one (test/winds-dial.test.mjs), until
// its attacks are next measured: its own source is in their digest (madeFrom), so that changing it measures them all.)
export const noteKey=n=>n.fingering?`${n.fingering} ${n.partial}`:n.position!=null?`${n.position} ${n.partial}`:String(n.partial);
