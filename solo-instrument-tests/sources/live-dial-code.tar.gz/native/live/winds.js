// The winds on the live dial (live.html): OpenWInD's engine played by its dial (native/openwind/live.mjs, its routes
// here under /winds/), heard through the page -- its sound pulled as the page plays it -- every control its page had,
// each under the heading it belongs to: the player's note, breath and embouchure or lips, fingers, valves or slide,
// tongue, vibrato and vocal tract; the instrument's body and its reed; the model's own constants and its engine. Each
// instrument taken up on its neutral note, one it sounds (neutral.mjs).
import {VocalTract} from '/public/shared/performers/vocal-tract.js';
import {playerEntry,player} from '/registry/registry.js';
import {SERIES,seriesPitch} from '/public/shared/estimation/harmonic-series.js';
import {attackKind,firstEndingAt,peakOf} from '/public/shared/performers/attack-curves.js';
import {curveEditor} from '/curves.js';
import {heldFingering,keywork,slideSvg,valvesSvg,woodwindDiagram} from '/public/shared/performers/fingering-diagrams.js';
import {atPitch,playersBand} from '/players.js';
import {DEFAULT_SEED} from '/public/shared/opening-time.js';
import {musebotControls} from '/musebot.js';

const $=id=>document.getElementById(`w-${id}`);
const NAMES=['C','C♯','D','E♭','E','F','F♯','G','A♭','A','B♭','B'];
const noteName=m=>`${NAMES[((m%12)+12)%12]}${Math.floor(m/12)-1}`;
const etName=p=>{const m=Math.round(p),c=Math.round(100*(p-m));return `${noteName(m)}${c?` ${c>0?'+':''}${c} ¢`:''}`};
// (A valved fingering as its players name it: its pressed valves, "1+3", or "open".)
const valvesName=f=>[...f].map((v,k)=>v==='1'?k+1:null).filter(Boolean).join('+')||'open';
const label=m=>m.replace(/-/g,' ');
// (A trombone's slide: its tube past first position (m) as a position, drawn between its positions' -- past its seventh as
// its sixth and seventh stand apart -- and a position as its tube.)
const slideAt=(v,from,to)=>{const ps=S.slide.positions,k=Math.max(0,Math.min(ps.length-2,ps.findLastIndex(p=>p[from]<=v)));return ps[k][to]+(v-ps[k][from])*(ps[k+1][to]-ps[k][to])/(ps[k+1][from]-ps[k][from])};
const positionOf=out=>slideAt(out,'out','position'),outOf=position=>slideAt(position,'position','out');
const hzOf=m=>440*2**((m-69)/12);
// (The server's state (`S`, /state), the instrument the page's controls were built for (`V`, its version), and what it
// plays now (`P`): every control shows P, and every change the page makes is for V -- the server refuses one for an
// instrument no longer played, and the page follows the one that is.)
let S=null,V=null,P=null;
// (Shown: the winds the family chosen on the page. Put to rest, nothing is asked of their dial -- which any request
// would start -- and their sound is not pulled.)
let active=false,status=null;
const say=text=>{$('said').textContent=text??''};
async function post(path,value={}){
  const r=await fetch(`/winds${path}`,{method:'POST',body:JSON.stringify({...value,version:V})});
  const got=await r.json();if(r.status===409){poll();return {}}return got;
}
// (A control's changes sent one at a time, the latest while one is on its way; each answer what is played now.)
function sender(path){
  let flying=false,next=null;
  return async value=>{
    next=value;if(flying)return;flying=true;
    try{while(next){const asked=next;next=null;const r=await post(path,asked);if(r.error){say(r.error);break}if(r.pitch!==undefined)took(r)}}finally{flying=false}
  };
}
const took=r=>{P=r;say('');refresh()};
// (The controls' blocks -- under Player, Instrument and Physics -- held still while an instrument is made.)
let busy=true,what='';
const blocks=()=>document.querySelectorAll('.w-controls');

// ---- the server's state: what is being made and what plays; the controls built again for each instrument taken up ----
let polling=null;
async function poll(){
  clearTimeout(polling);
  if(!active)return;
  let s;try{s=await (await fetch('/winds/state',{cache:'no-store'})).json()}catch{polling=setTimeout(poll,1500);return}
  if(!active)return;
  S=s;
  if(s.model&&s.version!==V)build(s);
  shown(s);soloShown(s);
  // (A musebot playing: the controls follow what it plays.)
  if(s.soloist?.playing&&s.version===V&&s.played?.pitch!=null){P=s.played;refresh()}
  // (Blown: its breath said as the dial measures the air its model lets in.)
  else if(P?.blowing&&s.version===V&&s.played?.lungs&&P.breathing&&S.lungs){P.lungs=s.played.lungs;lungsSaid()}
  if(s.model&&s.impedance&&!impedance&&!fetchingImpedance){fetchingImpedance=true;const asked=V;
    fetch('/winds/impedance').then(r=>r.json()).then(z=>{if(asked===V){impedance=z;legend();draw()}}).finally(()=>{fetchingImpedance=false})}
  polling=setTimeout(poll,s.loading||s.muting||s.soloist?.playing?500:P?.blowing?1000:!s.model||!s.impedance?2000:5000);
}
// (What is being made said as it goes; the one played silent until the next is ready, its controls held still
// meanwhile.)
function shown(s){
  status.classList.toggle('failed',Boolean(s.failed&&!s.loading));
  const breathSaid=n=>n.breathTimes&&n.breathTimes!==1?`, its breath ${n.breathTimes} times its players' law's, where it sounds`:'';
  const neutral=s.neutral?`, on its neutral note (${etName(s.notes[s.neutral.note])} at ${s.neutral.dynamic}${breathSaid(s.neutral)})`:s.model?`, on the middle of its charted notes: no neutral note found on its body yet (Commands/Make Dial Bodies.command finds it)`:'';
  status.textContent=s.loading?`Making the ${label(s.loading.model)}: ${s.loading.step} (${Math.round(s.loading.seconds)} s)${s.model?`. The ${label(s.model)} is silent until it is ready.`:'.'}`:
    s.failed?`The ${label(s.failed.model)} could not be taken up: ${s.failed.error}${s.model?`. The ${label(s.model)} still plays.`:''}`:
    s.model?`The ${label(s.model)}, ready${neutral}${s.threads>1?`; its engine on ${s.threads} cores`:''}.`:'Starting ...';
  busy=Boolean(s.loading)||!s.model;
  for(const b of blocks())b.disabled=busy;for(const id of ['blow','reset','neutral'])$(id).disabled=busy;
  $('tongueNow').disabled=busy||!P?.blowing;
}

// ---- the controls for the instrument played ----
const MEANING={gamma:['breath','mouth pressure over the closing pressure'],zeta:['embouchure','the reed\'s opening and width under the lips, scaled'],
  kappa:['reed flow','the flow the reed itself moves, scaled'],qfactor:['reed damping (Q)','the lips\' damping of the reed'],pulsation:['reed resonance, Hz','its frequency'],
  contact_stifness:['lay contact','the stiffness of the reed against the lay'],contact_exponent:['contact exponent','how the contact stiffens, three either side'],
  closing_pressure:['closing pressure, kPa','the pressure that shuts the reed']};
const LIPS={gamma:['breath','mouth pressure over the closing pressure'],zeta:['lip opening','the lips\' opening and width, scaled'],kappa:['lip flow','the flow the lips themselves move, scaled'],
  qfactor:['lips\' damping (Q)','their outward mode\'s quality'],pulsation:['lip frequency','their outward resonance, dialled by itself: the pitch asked and its breath kept, their other values their register\'s there; the bore picks the partial'],
  contact_stifness:['contact','none: lips have no lay'],contact_exponent:['contact exponent','none: lips have no lay'],closing_pressure:['closing pressure, kPa','the pressure that shuts the lips'],
  inward_ratio:['inward resonance','the inward mode\'s over the outward\'s'],inward_qfactor:['inward damping (Q)','the inward mode\'s quality'],inward_coupling:['inward coupling','the outward mass over the inward\'s']};
const JET={Uj:['breath','the jet\'s speed at the flue, m/s'],noise:['turbulence','the jet\'s noise, its level'],window:['window','the share of the embouchure hole the lip leaves'],
  Ascale:['jet amplification','its disturbance\'s growth over its length'],Gj:['jet drive','the jet\'s push on the air at the edge'],Gl:['edge losses','the flow\'s losses at the edge (vena contracta)'],
  C:['jet delay','its length over its disturbance\'s speed: the time it takes to cross'],y0:['jet offset','its centre from the edge, in its width: one either side'],span:['dipole span','the spread of its push about the edge']};
const meaningOf=name=>(S.kind==='lips'?LIPS[name]:S.kind==='air'?JET[name]:null)??MEANING[name]??[name,''];
// (Each column under the heading it belongs to. A reed's: the breath, the embouchure and the lips' damping of it the
// player's; its own flow, resonance, lay contact and closing pressure the reed's, a part of the instrument; how its
// contact stiffens the model's. A brass player's lips are the player's, their contact the model's. A flutist's breath,
// window, jet length and aim the player's; the jet's turbulence, growth, drive, edge losses and span the model's.)
const GROUP={reed:{gamma:'Player',zeta:'Player',qfactor:'Player',kappa:'Instrument',pulsation:'Instrument',contact_stifness:'Instrument',closing_pressure:'Instrument',contact_exponent:'Physics'},
  lips:{contact_stifness:'Physics',contact_exponent:'Physics'},air:{Uj:'Player',window:'Player',C:'Player',y0:'Player',noise:'Physics',Ascale:'Physics',Gj:'Physics',Gl:'Physics',span:'Physics'}};
const groupOf=name=>GROUP[S.kind]?.[name]??'Player';
const col=k=>S.columns[k][2];
// (A dial's place x, -1 to 1, as the server takes it: 1/reach to reach times the rules' value (dial-reach.json); the contact's exponent
// three either side of it, the jet's offset one; a column the rules hold at nothing, or a brass player's contact, fixed.)
const ADDITIVE={contact_exponent:3,y0:1};
const fixed=k=>S.kind==='lips'&&col(k)==='contact_exponent'||!(col(k) in ADDITIVE)&&!(P.rules[k]>0);
const valueOf=(k,x)=>col(k) in ADDITIVE?P.rules[k]+ADDITIVE[col(k)]*x:P.rules[k]*S.reach**x;
const placeOf=(k,v)=>col(k) in ADDITIVE?(v-P.rules[k])/ADDITIVE[col(k)]:Math.log(v/P.rules[k])/Math.log(S.reach);
// (A column's value in the units its box shows: a resonance in Hz, a pressure in kPa; and back.)
const unit={pulsation:[v=>v/2/Math.PI,v=>2*Math.PI*v],closing_pressure:[v=>v/1000,v=>1000*v]};
const shownValue=(name,v)=>{const u=unit[name]?unit[name][0](v):v;return Math.abs(u)>=1e4||Math.abs(u)<.01&&u!==0?u.toExponential(3):(+u.toPrecision(5)).toString()};
const controls={};
// (A slider and a box in a row of `box`: the slider's place `to`/`from` the value, the box the value itself.)
function row(box,id,text,{min,max,to=v=>v,from=x=>x,step='any',format=v=>+(+v).toPrecision(4),change,note}){
  const r=document.createElement('div');r.className='row';
  r.innerHTML=`<label for="w-${id}"></label><input type="range" id="w-${id}" step="any"><input type="number" id="w-${id}N" step="${step}">`;
  r.querySelector('label').textContent=text;box.append(r);
  let n=null;if(note!==undefined){n=document.createElement('div');n.className='note';n.textContent=note;box.append(n)}
  const range=r.querySelector('input[type=range]'),number=r.querySelector('input[type=number]');
  range.min=to(min);range.max=to(max);
  const set=v=>{if(held!==range)range.value=to(Math.min(max,Math.max(min,v)));if(document.activeElement!==number)number.value=format(v)};
  range.oninput=()=>{const v=from(+range.value);number.value=format(v);change(v)};
  number.onchange=()=>{const v=+number.value;if(Number.isFinite(v)&&v>=min&&v<=max)change(v);else refresh()};
  // (Each slider's players' band (players.js), a value placed on it as the slider places it.)
  return controls[id]={set,range,number,note:n,band:playersBand(range),place:v=>(to(v)-to(min))/(to(max)-to(min))};
}
// (The slider a pointer holds is not moved under it by an answer.)
let held=null;
addEventListener('pointerdown',e=>{if(e.target.type==='range')held=e.target});addEventListener('pointerup',()=>{held=null});
const sendDial=sender('/dial'),sendHole=sender('/hole'),sendPitch=sender('/pitch'),sendLip=sender('/lip'),sendArticulation=sender('/articulation'),
  sendRepeat=sender('/repeat'),sendVibrato=sender('/vibrato'),sendTract=sender('/tract'),sendSlide=sender('/slide'),sendAttack=sender('/attack'),
  sendBreathing=sender('/breathing'),sendFlutter=sender('/flutter'),sendHum=sender('/hum'),sendGrowl=sender('/growl'),sendNoise=sender('/noise'),sendMute=sender('/mute');
// (The player's noise (dial.mjs /noise): the player's temperature and each kind's under it, multiplied as the engine is
// given them; each kind's size at 1 said beside it.)
const NOISE_LABEL={breath:"The breath's pressure",lips:"The lips' tension"},noiseId=what=>`noise${what[0].toUpperCase()}${what.slice(1)}`;
// (The breath's attack: its curve drawn once, the dial's answer shown on it; its first segment, the rise, held within
// the rise's limits.)
const RISEN=[[0,0],[.05,1]];
const attack=curveEditor($('attack'),{kind:attackKind({from:0,straight:false}),label:'Breath at a note\'s start',change:points=>{
  if(!S?.model||busy){if(P?.breathAttack)attack.set(P.breathAttack);return}
  const [low,high]=S.limits.rise,rise=points[1][0];
  sendAttack({points:rise<low||rise>high?firstEndingAt(points,Math.min(high,Math.max(low,rise))):points})}});
$('plainRise').onclick=()=>{if(S?.model&&!busy)sendAttack({points:firstEndingAt(RISEN,P?.rise??RISEN[1][0])})};

function build(s){
  V=s.version;P=s.played;impedance=null;
  for(const box of ['tongue','repeat','lungs','vibrato','noise','flutter','hum','growl','excitorPlayer','excitorInstrument','excitorPhysics','holes','slideBox','diagram'])$(box).replaceChildren();
  drawnFor=null;$('diagramNote').textContent='';
  for(const k in controls)delete controls[k];
  const kind=s.kind,brass=kind==='lips';
  what=`The ${label(s.model)} on OpenWInD's engine, heard through this page: its player's ${brass?'lips':kind==='air'?'air and fingers':'reed and fingers'}, tongue, vibrato${kind==='air'?'':' and vocal tract'} dialled by ear.`;
  document.getElementById('what').textContent=what;
  // (The notes: each charted note, a brass instrument's each partial its lips sound -- a trombone's at each position its
  // chart gives it, alternates too; the pitch between them.)
  const noteText=(m,k)=>!brass?`${noteName(m)} (${m})`:`${etName(m)} (${s.fingerings?`${valvesName(s.fingerings[k])}, `:''}${s.positions?`position ${s.positions[k]}${s.alternates[k]?', alternate':''}, `:''}partial ${s.partials[k]})`;
  $('note').replaceChildren(...s.notes.map((m,k)=>new Option(noteText(m,k)+(s.neutral?.note===k?' · neutral':''),k)));
  if(!$('dynamic').options.length)for(const d of s.dynamics)$('dynamic').add(new Option(d,d));
  const [low,high]=[Math.min(...s.notes),Math.max(...s.notes)];
  for(const el of [$('pitch'),$('pitchN')]){el.min=low;el.max=high}
  // (The tongue: its stroke, a legato tongue's length, the breath's rise, beside what was measured of players.)
  const t=s.tongue,m=t.measured,ms=v=>Math.round(1000*v),L=s.limits;
  $('articulationNote').textContent=`A slurred note on the same pitch (within ${t.samePitch} ¢) is legato-tongued, a half attack.`;
  row($('tongue'),'stroke','Tongued stroke, ms',{min:ms(L.stroke[0]),max:ms(L.stroke[1]),step:1,format:Math.round,change:v=>sendArticulation({stroke:v/1000}),
    note:`The air ${kind==='reed'?'shut by the tongue on the reed':'stopped'} that long before a tongued note. Measured: clarinettists' portato ${ms(m.portato[0])} ms (sd ${ms(m.portato[1])}), their staccato ${ms(m.staccato[0][1])} ms at four notes a second and ${ms(m.staccato[1][1])} at two (Pàmies-Vilà, Hofmann & Chatziioannou 2018); saxophonists' ${(1000*m.saxophone).toFixed(1)} ms (Hofmann & Goebl 2014).`});
  row($('tongue'),'softSeconds','Legato tongue, ms',{min:ms(L.softSeconds[0]),max:ms(L.softSeconds[1]),step:1,format:Math.round,change:v=>sendArticulation({softSeconds:v/1000}),
    note:kind==='reed'?`The tongue touching the reed to ${Math.round(100*t.soft)} % of its opening that long: a half attack.`:`The air dipped to ${Math.round(100*t.dip)} % of itself that long: a half attack.`});
  row($('tongue'),'rise','Breath rise from rest, ms',{min:ms(L.rise[0]),max:ms(L.rise[1]),step:1,format:Math.round,change:v=>sendArticulation({rise:v/1000}),
    note:kind==='reed'?'A note from rest: the tongue on the reed as the breath rises, let go as it has risen.':brass?'A note from rest: the air let go into the lips, attacked as their attack was measured on the engine.':'A note from rest: the air let go into its rise.'});
  row($('repeat'),'repeatRate','Notes a second',{min:L.repeat[0],max:L.repeat[1],to:Math.log,from:Math.exp,step:.1,format:v=>v.toFixed(1),change:v=>sendRepeat({rate:v}),
    note:`Each a stroke as the articulation says. Measured on brass: single tonguing to some ${m.single} notes a second, double some ${m.double} (Bertsch & Hoole 2014).`});
  // (Its breathing: a breath as deep as wind players take one, taken in as fast as a singer's full breath; the page's
  // choice whether it breathes sent to the dial, which holds one breath without end until it is told.)
  if(s.lungs){const n=s.lungs;
    row($('lungs'),'litres','Breath taken, L',{min:L.litres[0],max:L.litres[1],step:.05,format:v=>v.toFixed(2),change:v=>sendBreathing({litres:v}),
      note:`Wind players' vital capacity ${n.capacity.litres} L (sd ${n.capacity.sd}; Bouros, Protogerou, Castana & Vasilopoulos 2018), ${Math.round(100*n.spent.share)} % of it spent in a breath (Cossette, Sliwinski & Macklem 2000): ${n.breath} L.`});
    row($('lungs'),'inhale','Breath in, ms',{min:ms(L.inhale[0]),max:ms(L.inhale[1]),step:10,format:Math.round,change:v=>sendBreathing({inhale:v/1000}),
      note:`Fast and deep (Bouhuys 1964), reed players' fastest some 300 ms (Fuks & Sundberg 1998); by default a singer's full breath, ${ms(n.inhale.seconds)} ms (Salomoni, van den Hoorn & Hodges 2016), until wind players' own is measured.`});
    if(P.breathing&&$('breathing').checked!==P.breathing.on)sendBreathing({on:$('breathing').checked});
  }
  // (The vibrato: the player's own as authored, in a woodwind player's breath, in a brass player's lips.)
  const own=s.vibratoOwn;
  $('vibratoNote').textContent=`${own.width>0?`the ${label(s.model)} players' own: ${own.width} ¢ at ${own.rate} Hz`:`the ${label(s.model)} is played without one${own.reach?`; ${own.reach} ¢ where a style asks`:''}`}; ${brass?'the whole embouchure swayed, as the mouthpiece is pressed into the lips and eased, as deep as the note is heard so wide':'in the breath'}`;
  row($('vibrato'),'vibratoWidth','Width, cents',{min:L.width[0],max:L.width[1],step:1,format:Math.round,change:v=>sendVibrato({width:v})});
  row($('vibrato'),'vibratoRate','Rate, Hz',{min:L.rate[0],max:L.rate[1],step:.1,format:v=>v.toFixed(1),change:v=>sendVibrato({rate:v})});
  if(s.noise){const {profile:f,most}=s.noise,dial={min:0,max:most,step:.05,format:v=>v.toFixed(2)};
    row($('noise'),'noisePlayer',"The player's temperature",{...dial,change:v=>sendNoise({player:v}),
      note:`Each kind's under it. Its power falling as 1/f^${f.beta} from ${f.low} to ${f.high} Hz, a ${f.tremor.hz} Hz tremor ${Math.round(100*f.tremor.share)} % of it.`});
    for(const {what,sd} of s.noise.kinds)row($('noise'),noiseId(what),NOISE_LABEL[what],{...dial,change:v=>sendNoise({[what]:v}),
      note:`At 1, ${+(100*sd).toPrecision(2)} % of the ${what==='breath'?'pressure':'tension'} asked.`});
  }
  // (Its flutter, its hum and its growl, as the renders' players play them, by the engine's own source of them; a dial
  // started before them has none, one started before its growl no growl.)
  if(L.flutterHz){
    row($('flutter'),'flutterHz','Turns a second',{min:L.flutterHz[0],max:L.flutterHz[1],step:.5,format:v=>v.toFixed(1),change:v=>sendFlutter({hz:v}),
      note:'The middle of the renders\' flutters by default: 28 to 33 a second, as speakers\' voiceless tongue-tip trills were measured (Elie & Laprie 2017); no wind player\'s measured.'});
    row($('flutter'),'flutterDepth','Breath closed off',{min:L.flutterDepth[0],max:L.flutterDepth[1],step:.01,format:v=>v.toFixed(2),change:v=>sendFlutter({depth:v}),
      note:'At each turn this share of the breath closed off and let go, its curve squared as the renders\' is, on whatever moves under it: an attack, a stroke, a breath.'});
    row($('hum'),'humInterval','Hummed, semitones from the note',{min:L.humInterval[0],max:L.humInterval[1],step:.01,format:v=>v.toFixed(2),change:v=>sendHum({interval:v}),
      note:'Folded into the player\'s voice (the registry\'s low and high breath-model voices), as the renders\' hummers are; an octave under by default, the middle of what they draw.'});
    row($('hum'),'humLevel','Level, × the breath',{min:L.humLevel[0],max:L.humLevel[1],step:.01,format:v=>v.toFixed(2),change:v=>sendHum({level:v}),
      note:'Its breath swung this much of itself by the voice, its partials falling as the square of their number: the renders\' 0.2 by default.'});
    if(L.growlInterval){
      row($('growl'),'growlInterval','Growled, semitones from the note',{min:L.growlInterval[0],max:L.growlInterval[1],step:.01,format:v=>v.toFixed(2),change:v=>sendGrowl({interval:v}),
        note:'Folded into the player\'s voice as the hum is; an octave under by default, the middle of what the renders\' growlers draw.'});
      row($('growl'),'growlLevel','Level, × the breath',{min:L.growlLevel[0],max:L.growlLevel[1],step:.01,format:v=>v.toFixed(2),change:v=>sendGrowl({level:v}),
        note:'Its breath swung this much of itself by the rough voice.'});
      row($('growl'),'growlRough','Roughness',{min:L.growlRough[0],max:L.growlRough[1],step:.01,format:v=>v.toFixed(2),change:v=>sendGrowl({rough:v}),
        note:'Its voice\'s period doubled, every other pulse this much weaker, with breath noise this rough: 0.3 to 0.9 in the renders.'});
      $('techniqueNote').textContent='Played by the engine as the renders play them. A growl and a hum both on: the growl.';
    }else $('techniqueNote').textContent='This dial was started before its growl: Commands/Start Live Dial.command again brings it.';
  }else $('techniqueNote').textContent='This dial was started before its flutter and hum: Commands/Start Live Dial.command again brings them.';
  // (The reed, the lips or the jet: each column the engine takes, 1/reach to reach times the rules' value at the pitch,
  // under the heading it belongs to.)
  const reach=s.reach===4?'a quarter to four':`1/${s.reach} to ${s.reach}`,between=`each ${reach} times the rules' value at the pitch and dynamic; the box, its value.`;
  $('playerLegend').textContent=brass?'Lips and breath':kind==='air'?'Breath and jet':'Breath and embouchure';
  $('excitorNote').textContent=`The player's columns of the engine, ${between}`+(brass?' The lips\' frequency in Hz, over their reach.':'');
  $('instrumentLegend').textContent='Reed';
  $('instrumentNote').textContent=`The reed's own columns, ${between}`;
  $('physicsLegend').textContent=brass?'The lips\' contact':kind==='air'?'The jet\'s model':'The reed\'s contact';
  $('physicsNote').textContent=`The model's constants for the ${brass?'lips':kind==='air'?'jet':'reed'}, ${between}`;
  const boxOf={Player:$('excitorPlayer'),Instrument:$('excitorInstrument'),Physics:$('excitorPhysics')};
  for(const k of s.dials){
    const name=col(k),[text,about]=meaningOf(name),box=boxOf[groupOf(name)];
    if(brass&&name==='pulsation'){
      const [lo,hi]=s.lipReach;
      Object.assign(row(box,`lip${k}`,`${text}, Hz`,{min:lo,max:hi,to:Math.log,from:Math.exp,step:.1,format:v=>v.toFixed(1),change:v=>sendLip({lip:v}),note:about}),{lip:true});
      continue;
    }
    const c=row(box,`col${k}`,text,{min:-1,max:1,change:x=>sendDial({column:k,x}),note:about});
    c.range.oninput=()=>{const x=+c.range.value;c.number.value=shownValue(name,valueOf(k,x));sendDial({column:k,x})};
    // (Its box the column's value: the place it stands at found from it.)
    c.number.onchange=()=>{const v=+c.number.value,x=placeOf(k,unit[name]?unit[name][1](v):v);if(Number.isFinite(x)&&x>=-1&&x<=1)sendDial({column:k,x});else refresh()};
    Object.assign(c,{k,name});
  }
  $('instrumentSet').hidden=!$('excitorInstrument').children.length;
  $('physicsSet').hidden=!$('excitorPhysics').children.length;
  // (The fingers: each hole's opening; a valved instrument's, each valve's -- its two switches moved as one.)
  $('fingerSet').hidden=brass&&!s.valves&&!s.slide;
  $('fingerLegend').textContent=brass?s.slide?'Slide':'Valves':'Fingers';
  // (A brass player's mutes, as its players' kit has them (render/synthesis/geometry/brass-mutes.json), or none.)
  $('muteSet').hidden=!s.mutes?.length;
  $('mute').replaceChildren(new Option('none',''),...(s.mutes??[]).map(m=>new Option(MUTE_NAME[m]??m,m)));
  $('fingerNote').textContent=s.slide?'The slide, at a position from 1 (in) to 7 and past: the note\'s, its players\' chart\'s, placed where its partial plays it in tune; a pitch between them on the partial played there, glided to. Drawn here by itself, its lips held: the bore gives the pitch.'
    :brass?'Each valve, 0 pressed to 1 raised -- a half-valve between: the note\'s fingering, its players\' chart\'s, until the pitch moves.'
    :'Each hole\'s opening, 0 closed to 1 open: the pitch\'s, until the pitch moves.';
  // (A trombone's slide: its slider as long as its tube, each position marked; its box the position.)
  if(s.slide){
    const c=row($('slideBox'),'slide','Slide position',{min:1,max:positionOf(s.slide.most),to:outOf,from:positionOf,step:.01,format:v=>v.toFixed(2),
      change:v=>sendSlide({out:Math.min(Math.max(outOf(v),0),s.slide.most)}),note:''});
    c.note.style.minHeight='2.9em';
    const marks=document.createElement('datalist');marks.id='w-slideMarks';marks.append(...s.slide.positions.map(p=>new Option(String(p.position),p.out)));
    $('slideBox').append(marks);c.range.setAttribute('list','w-slideMarks');
  }
  s.columns.forEach((c,k)=>{if(c[0]!=='opening'||brass&&!s.valves.some(([first])=>first===k))return;
    const box=document.createElement('div');box.innerHTML=`<label><span></span><b></b></label><input type="range" min="0" max="1" step="0.01">`;
    box.querySelector('span').textContent=brass?`Valve ${c[1]+1}`:s.holes?.[c[1]]??c[2]??c[1];
    const slider=box.querySelector('input'),value=box.querySelector('b');
    slider.oninput=()=>{value.textContent=(+slider.value).toFixed(2);sendHole({column:k,value:+slider.value})};
    controls[`hole${k}`]={set:v=>{if(held!==slider)slider.value=v;value.textContent=v.toFixed(2)},hole:k};
    $('holes').append(box)});
  // (The tract: its players' where measured; a flute's jet blown from the mouth, no tract before it in the engine.)
  $('tractLegend').textContent=brass?'Vocal tract, upstream of the lips':kind==='air'?'The bore, as the jet meets it':'Vocal tract, upstream of the reed';
  tract=new VocalTract(P.tract);
  const range=path=>playerEntry(s.model,`tract.${path}`);
  MEASURED=s.tractMeasured?{first:{f:range('first.frequency').range,p:range('first.peak').range},held:player(s.model,'tract.normal.held'),offset:player(s.model,'tract.normal.offset'),
    normal:player(s.model,'tract.normal.peak'),bend:range('bend.peak').range}:null;
  $('normal').hidden=$('none').hidden=$('tractHow').hidden=kind==='air';
  $('normal').disabled=!s.tractMeasured;$('normal').title=s.tractMeasured?'':`no ${label(s.model)} players' tract measured yet`;
  // (What the instrument is, and what its engine holds.)
  const rows=(id,pairs)=>{$(id).replaceChildren(...pairs.filter(([,v])=>v!=null&&v!=='').map(([a,b])=>{const tr=document.createElement('tr');tr.innerHTML='<td></td><td></td>';
    tr.cells[0].textContent=a;tr.cells[1].textContent=b;tr.cells[1].title=b;return tr}))};
  const holes=s.columns.filter(c=>c[0]==='opening').length;
  rows('body',[['Instrument',label(s.model)],['Compass',`${etName(low)} to ${etName(high)}, ${s.notes.length} ${brass?'partials and fingerings':'charted notes'}`],
    ['Holes',brass?null:`${new Set(s.columns.filter(c=>c[0]==='opening').map(c=>c[1])).size} (${holes} columns)`],
    ['Valves',s.valves?`${s.valves.length}, each its deviation pipe and two switches`:null],
    ['Slide',s.slide?`${(1000*s.slide.most).toFixed(0)} mm of tube past first position, ${s.slide.positions.length} positions`:null],
    ['Neutral note',s.neutral?`${etName(s.notes[s.neutral.note])} at ${s.neutral.dynamic}${s.neutral.breathTimes!==1?`, its breath ${s.neutral.breathTimes} times its players' law's`:''}, heard ${s.neutral.cents} ¢ from its pitch (found ${new Date(s.neutral.found).toLocaleDateString()})`:'not found on this body yet: Commands/Make Dial Bodies.command finds it'],
    ['Its body',s.layout?.madeFrom?`made from ${s.layout.madeFrom.slice(0,12)}`:null]]);
  const lay=s.layout??{};
  rows('engineTable',[['Losses',lay.losses],['Mesh',lay.mesh],['Elements',lay.order!=null?`order ${lay.order}`:null],['Precision',lay.single==null?null:lay.single?'single':'double'],
    ['Rate',lay.rate?`${lay.rate} Hz${lay.ratio?`, stepped ${lay.ratio} times a sample`:''}`:null],['Unknowns',lay.unknowns?`${lay.unknowns} (${lay.entries} entries)`:null],
    ['Cores',String(s.threads)],['Dials\' reach',`1/${s.reach} to ${s.reach} times the rules' value`]]);
  for(const b of blocks())b.hidden=false;
  refresh();legend();draw();
}

// ---- every control as what is played now ----
function refresh(){
  if(!P||!S?.model)return;
  if(dragging<0){tract=new VocalTract(P.tract??[]);draw()}
  $('blow').textContent=P.blowing?'Blowing':'Blow';$('blow').classList.toggle('on',P.blowing);
  $('tongueNow').disabled=!P.blowing||busy;
  if(document.activeElement!==$('note'))$('note').value=String(P.note??S.notes.indexOf(P.midi));
  if(document.activeElement!==$('dynamic'))$('dynamic').value=P.dynamic;
  if(held!==$('pitch'))$('pitch').value=P.pitch;if(document.activeElement!==$('pitchN'))$('pitchN').value=P.pitch.toFixed(2);
  for(const r of document.querySelectorAll('input[name=w-articulation]'))r.checked=r.value===P.articulation;
  controls.stroke.set(1000*P.stroke);controls.softSeconds.set(1000*P.softSeconds);controls.rise.set(1000*P.rise);
  if(P.breathAttack){attack.set(P.breathAttack);const [t,y]=peakOf(P.breathAttack);
    $('attackNote').textContent=(y>1?`Its peak ${y.toFixed(2)} times the breath dialled, ${Math.round(1000*t)} ms in, settled at ${Math.round(1000*P.breathAttack.at(-1)[0])} ms. `:'A plain rise: the breath brought up to what is dialled and held. ')
      +`Played from rest and after every tongued stroke${S.kind==='reed'?' (the tongue let go of the reed as the first segment ends)':''}. Press anywhere on the plot to put a point there and drag it -- above the dashed line, a peak over the breath dialled; drag a point; select one to set it as numbers; double-click it, or press Delete, to take it away. Its first rise is the breath's rise (above); each segment is eased, as the engine moves.`}
  $('repeating').checked=P.repeat.on;controls.repeatRate.set(P.repeat.rate);
  if(P.breathing&&S.lungs){
    $('breathing').checked=P.breathing.on;controls.litres.set(P.breathing.litres);controls.inhale.set(1000*P.breathing.inhale);
    lungsSaid();
  }
  $('vibrating').checked=P.vibrato.on;controls.vibratoWidth.set(P.vibrato.width);controls.vibratoRate.set(P.vibrato.rate);
  if(P.noise&&controls.noisePlayer){controls.noisePlayer.set(P.noise.player);for(const {what} of S.noise.kinds)controls[noiseId(what)].set(P.noise[what])}
  if(P.flutter&&controls.flutterHz){
    $('fluttering').checked=P.flutter.on;controls.flutterHz.set(P.flutter.hz);controls.flutterDepth.set(P.flutter.depth);
    $('humming').checked=P.hum.on;controls.humInterval.set(P.hum.interval);controls.humLevel.set(P.hum.level);
    if(P.growl&&controls.growlInterval){$('growling').checked=P.growl.on;controls.growlInterval.set(P.growl.interval);controls.growlLevel.set(P.growl.level);controls.growlRough.set(P.growl.rough)}
    // (The voice's pitch, and where the reed, lips or jet sum and difference it with the note.)
    const growling=P.growl?.on&&P.growled!=null,h=growling?P.growled:P.hummed,f=hzOf(P.pitch);
    $('humNote').textContent=h==null?'':`${growling?'Growled':'Hummed'} at ${h.toFixed(1)} Hz (${etName(12*Math.log2(h/440)+69)}); with the note's ${f.toFixed(1)} Hz, its difference tone ${Math.abs(f-h).toFixed(1)} Hz and its sum ${(f+h).toFixed(1)} Hz.`;
  }
  if(controls.slide&&P.slide!=null){controls.slide.set(positionOf(P.slide));
    controls.slide.note.textContent=`${Math.round(1000*P.slide)} mm of tube past first position, the hand ${Math.round(500*P.slide)} mm out; moved as its players move it, over ${Math.round(1000*S.slide.least)} ms or at some ${S.slide.speed} m/s.`}
  muteSaid();
  fingered();
  for(const c of Object.values(controls)){
    if(c.hole!==undefined)c.set(P.row[c.hole]);
    if(c.lip&&P.lip!=null)c.set(P.lip);
    if(c.k===undefined)continue;
    const off=fixed(c.k);c.range.disabled=c.number.disabled=off;
    if(held!==c.range)c.range.value=P.x[c.k]??0;
    if(document.activeElement!==c.number)c.number.value=shownValue(c.name,P.row[c.k]);
    if(c.name==='gamma'&&c.note){const at=S.columns.findIndex(q=>q[0]==='reed'&&q[2]==='closing_pressure');if(at>=0)c.note.textContent=`${meaningOf('gamma')[1]}: ${(P.row[c.k]*P.row[at]/1000).toFixed(2)} kPa`}
  }
  drawPlayers();
  said();
}
// (Its breath said: the air its model let into its bore as it was last blown, the engine's own (stream.rs Air), and what
// its players were measured spending there -- as the page refreshes, and as the dial measures it while it is blown
// (poll).)
function lungsSaid(){
  const f=P.lungs.flow,players=P.lungs.players,src=S.lungs.airflow,b=S.breath,dialled=P.rules[b]>0&&Math.abs(P.row[b]/P.rules[b]-1)>.005;
  $('lungsNote').textContent=`${f>0?`As it was last blown its model let ${f.toFixed(3)} L a second into its bore (its engine's own flow)`:'Its model\'s flow is measured as it is blown'}; at ${P.dynamic} on ${etName(P.pitch)}${dialled?', at the breath dialled,':''} its players spend ${players.toFixed(2)} L a second (`
    +(src.evidence==='measured'?`measured of ${label(S.model)} players: Bouhuys 1965`:`borrowed from ${src.from.map(label).join(', ')} players' measured flows, Bouhuys 1965: none measured on the ${label(S.model)}`)
    +`). ${P.breathing.on?`${f>0?`A breath of ${P.breathing.litres.toFixed(2)} L lasts it ${(P.breathing.litres/f).toFixed(1)} s`:`A breath of ${P.breathing.litres.toFixed(2)} L spent`}, then the note is let go, a breath taken in over ${Math.round(1000*P.breathing.inhale)} ms and the note attacked again as from rest -- as the strings' bow turns.`:'Unbreathing, it blows one breath without end.'}`;
}
// (What players were measured doing (the state's `players`, players-ranges.mjs), on each slider: the breath the mouth's
// pressure its players blew at the pitch played, over the closing pressure as it stands; the reed's columns the published
// reeds'; the tongue, the repeats and the breath taken in their sliders' units; the pitch its players' compass.)
const kPa=v=>`${(v/1000).toFixed(1)} kPa`,msOf=v=>`${Math.round(v)} ms`,shortly=v=>String(+(+v).toPrecision(2));
const WRITTEN={pulsation:v=>`${Math.round(v/2/Math.PI)} Hz`,closing_pressure:kPa,qfactor:shortly};
const OWN={stroke:[1000,msOf],softSeconds:[1000,msOf],rise:[1000,msOf],inhale:[1000,msOf],repeatRate:[1,v=>`${v} a second`],litres:[1,v=>`${v.toFixed(1)} L`],
  vibratoWidth:[1,v=>`${Math.round(v)} ¢`],vibratoRate:[1,v=>`${shortly(v)} Hz`]};
let pitchBand=null;
function drawPlayers(){
  const R=S.players;if(!R)return;
  pitchBand??=playersBand($('pitch'));
  const low=+$('pitch').min,high=+$('pitch').max;
  pitchBand(R.pitch,m=>(m-low)/(high-low),m=>noteName(Math.round(m)));
  const shut=S.columns.findIndex(q=>q[0]==='reed'&&q[2]==='closing_pressure'),blown=atPitch(R.breath,P.pitch);
  for(const [id,c] of Object.entries(controls)){
    if(!c.band)continue;
    const x=v=>(placeOf(c.k,v)+1)/2;
    if(c.name==='gamma')c.band(shut>=0?blown:null,p=>x(p/P.row[shut]),kPa);
    else if(c.k!==undefined)c.band(R.columns[c.name]??null,x,WRITTEN[c.name]??shortly);
    else{const [scale,written]=OWN[id]??[1,shortly];c.band(R[id]??null,v=>c.place(scale*v),v=>written(scale*v))}
  }
}
// (The fingering drawn as its players read it (fingering-diagrams.js), from what the engine holds: a woodwind's keys
// found from its holes as they stand, each drawn as far as its holes stand -- a charted fingering's as its players' guide
// writes it, a dialled one's the keys nearest it, a key that moves a hole only with others drawn faint, any hole no keys
// leave so said -- a valved instrument's valves each as far down as it is pressed, a trombone's slide at its position.
// Drawn again only where it changes.)
let drawnFor=null;
function fingered(){
  const brass=S.kind==='lips',holes=S.columns.map((c,k)=>[c,k]).filter(([c])=>c[0]==='opening');
  let svg='',note='',key;
  if(brass&&S.slide&&P.slide!=null){key=`slide ${P.slide.toFixed(4)}`;if(key===drawnFor)return;const at=positionOf(P.slide);
    svg=slideSvg(at,positionOf(S.slide.most),`Slide at position ${at.toFixed(2)}`)}
  else if(brass&&S.valves){const down=S.valves.map(([first])=>1-P.row[first]);key=`valves ${down.map(d=>d.toFixed(3))}`;if(key===drawnFor)return;
    svg=valvesSvg(down,`Valves: ${valvesName(down.map(d=>d>=.5?'1':'0').join(''))}`);
    note=down.some(d=>d>.01&&d<.99)?`Half-valved: ${down.map((d,k)=>d>.01&&d<.99?`valve ${k+1} ${Math.round(100*d)} % down`:null).filter(Boolean).join(', ')}.`:''}
  else if(!brass&&keywork(S.model)){
    const open=Object.fromEntries(holes.map(([c,k])=>[S.holes[c[1]],P.row[k]]));key=`holes ${holes.map(([,k])=>P.row[k].toFixed(3))}`;if(key===drawnFor)return;
    const f=heldFingering(S.model,open),w=keywork(S.model),faint=Object.entries(f.faint),parts=Object.entries(f.parts);
    const d=woodwindDiagram(S.model,f.keys,`Fingering${f.documented?` ${f.documented}`:''}`,{whole:true,parts:f.parts,faint:Object.fromEntries(faint.map(([key,v])=>[key,v.share]))});
    // (A hole of its body its keywork has no key for, dialled from where the rules hold it.)
    const unkeyed=holes.filter(([c,k])=>!w.holes.includes(S.holes[c[1]])&&Math.abs(P.row[k]-P.rules[k])>.005).map(([c,k])=>`${S.holes[c[1]]} at ${P.row[k].toFixed(2)}`);
    const pct=a=>`${Math.round(100*a)} %`,shown=new Set(faint.map(([,v])=>v.hole)),off=f.off.filter(h=>!shown.has(h));
    svg=d.svg;
    note=(f.documented?`${f.documented}, as its players' guide writes it.`:f.off.length?'No fingering of its keys leaves its holes so: the keys nearest them.':'Its keys for the holes as they stand: no charted fingering.')
      +(parts.length?` Pressed part way: ${parts.map(([key,a])=>`${key} ${pct(a)}`).join(', ')}.`:'')
      +(faint.length?` Drawn faint: ${faint.map(([key,v])=>`${key} ${pct(v.share)} for ${v.hole} (${open[v.hole].toFixed(2)} open), which it moves only with ${v.moves.join(', ')}`).join('; ')}.`:'')
      +(off.length?` Left otherwise than they stand: ${off.map(h=>`${h} (${open[h].toFixed(2)} open)`).join(', ')}.`:'')
      +(d.undrawn.length?` Also pressed, with no place in LilyPond's ${w.diagram} diagram: ${d.undrawn.join(', ')}.`:'')
      +(unkeyed.length?` Dialled, with no key on its diagram: ${unkeyed.join(', ')}.`:'')}
  drawnFor=key;
  $('diagram').classList.toggle('brass',brass);$('diagram').innerHTML=svg??'';$('diagramNote').textContent=note;
}
// (The mute in its bell, or the one asked: its body made or taken up, then put in once the breath is let go and the
// bell has rung down.)
const MUTE_NAME={straight:'straight mute',cup:'cup mute','harmon-stem-out':'harmon, stem out','harmon-stem-in':'harmon, stem in',stopped:'stopped, the hand in the bell'};
function muteSaid(){
  if(!S.mutes?.length)return;
  const m=S.muting,name=k=>k?MUTE_NAME[k]??k:'no mute';
  if(document.activeElement!==$('mute'))$('mute').value=(m?m.mute:S.mute)??'';
  $('muteNote').textContent=m?.error?`The ${name(m.mute)}'s body could not be made: ${m.error}. Still played with ${name(S.mute)}.`:
    m?`${name(m.mute)[0].toUpperCase()+name(m.mute).slice(1)} asked: ${m.ready?'put in as soon as the breath is let go and the bell has rung down':`its body being made: ${m.step} (${Math.round(m.seconds)} s)`}. Played with ${name(S.mute)} until then.`:
    S.mute?`Played with its ${name(S.mute)} in: its body's bore the mute's ring, its hollow a closed branch at its tip.`:'Played open.';
}
// (Where the pitch stands among the charted notes, a brass instrument's lips among its partials'.)
function said(){
  const b=P.between,partialOf=m=>{const k=S.notes.indexOf(m);return S.partials?.[k]+(S.fingerings?` (${valvesName(S.fingerings[k])})`:'')+(S.positions?` (position ${S.positions[k]})`:'')};
  if(S.kind==='lips'){
    const k=P.note??S.notes.indexOf(P.midi),none=S.unattacked?.[k]??[],a=P.attack;
    $('pitchSaid').textContent=P.lip==null?'':(P.slideDialled?'The slide drawn by itself: the bore gives the pitch. ':'')+`Lips at ${P.lip.toFixed(1)} Hz: `+(P.lipDialled?'dialled by themselves; the bore picks the partial':
      !b||b.share===0&&b.low===b.high?`partial ${partialOf(P.midi)}, as its lips sound it`:`between partial ${partialOf(b.low)}'s lips and ${partialOf(b.high)}'s, ${Math.round(100*b.share)} % of the way; the bore picks the partial`)+
      (!a?`. Blown from rest at ${P.dynamic}, no attack found it.`:a.share===1?'.':`. Blown from rest: attacked from lips ${Math.abs(100*(1-a.share)).toFixed(0)} % ${a.share<1?'lower':'higher'}, settled after ${Math.round(1000*a.settleAfter)} ms.`)+
      (none.length?` Partial ${partialOf(P.midi)}'s attack finds it at no lips at ${none.join(', ')}.`:'')+
      (P.vibrato.on&&P.vibrato.width>0?P.vibratoHeard==null?' Its vibrato\'s swing is not measured on this body.':
        P.vibratoHeard<P.vibrato.width-.05?` Its vibrato heard ${P.vibratoHeard.toFixed(1)} ¢ wide, the widest its partial holds.`:'':'');
    return;
  }
  $('pitchSaid').textContent=!b?'':b.sounds==null?`${etName(P.pitch)}: the charted note, as the rules play it.`:
    `${b.share>0&&b.share<1?`Between the charted ${noteName(b.low)} and ${noteName(b.high)}, ${Math.round(100*b.share)} % of the way`:`The charted ${noteName(b.share<1?b.low:b.high)}`}`+
    `${Math.abs(b.sounds-P.pitch)>.005?`; the nearest it reaches, ${etName(b.sounds)}.`:'.'}`;
}

// ---- what the page changes ----
let pitchSlow=null;
const toPitch=(pitch,charted=false,dynamic=$('dynamic').value,note=null)=>{
  // (A glide not yet measured takes a second or two, once.)
  clearTimeout(pitchSlow);pitchSlow=setTimeout(()=>{$('pitchSaid').textContent=`Measuring the glides near ${etName(pitch)} ...`},300);
  return sendPitch({pitch:Math.min(Math.max(pitch,+$('pitch').min),+$('pitch').max),dynamic,charted,...(note!=null?{note}:{})}).finally(()=>{clearTimeout(pitchSlow);if(P)said()});
};
$('pitch').oninput=()=>{$('pitchN').value=(+$('pitch').value).toFixed(2);toPitch(+$('pitch').value)};
$('pitchN').onchange=()=>toPitch(+$('pitchN').value);
$('note').onchange=()=>toPitch(S.notes[+$('note').value],true,undefined,+$('note').value);
$('dynamic').onchange=()=>{const charted=P.between?.sounds==null&&S.notes.includes(P.pitch);toPitch(P.pitch,charted,undefined,charted?P.note:null)};
$('reset').onclick=async()=>{const r=await post('/reset');r.error?say(r.error):r.pitch!==undefined&&took(r)};
// (Its neutral note again, at its dynamic -- the middle of its charted notes where none is found -- every dial the
// rules' there, its players' normal tract following the note where theirs is measured.)
$('neutral').onclick=async()=>{
  const r=await post('/neutral');if(r.error)return say(r.error);
  S=await (await fetch('/winds/state',{cache:'no-store'})).json();shown(S);if(r.pitch!==undefined)took(r);
  const k=S.neutral?S.neutral.note:Math.floor(S.notes.length/2);
  if(S.kind!=='air'&&S.tractMeasured)sendTract({follow:true});
};
for(const r of document.querySelectorAll('input[name=w-articulation]'))r.onchange=()=>sendArticulation({articulation:r.value});
$('repeating').onchange=()=>sendRepeat({on:$('repeating').checked});
$('breathing').onchange=()=>{if(S?.model&&!busy&&P?.breathing)sendBreathing({on:$('breathing').checked})};
$('vibrating').onchange=()=>sendVibrato({on:$('vibrating').checked});
$('fluttering').onchange=()=>sendFlutter({on:$('fluttering').checked});
$('humming').onchange=()=>sendHum({on:$('humming').checked});
$('growling').onchange=()=>sendGrowl({on:$('growling').checked});
$('mute').onchange=()=>{if(S?.model&&!busy)sendMute({mute:$('mute').value||null}).finally(poll)};
const blow=async()=>{if(!S?.model||busy)return;sound();const r=await post('/blow',{on:!P.blowing});r.error?say(r.error):r.pitch!==undefined&&took(r);
  // (Its breath said once it has been blown a moment.)
  if(P?.blowing){clearTimeout(polling);polling=setTimeout(poll,1000)}};
const tongueNow=async()=>{if(!P?.blowing||busy)return;const r=await post('/tongue');if(r.error)say(r.error)};
$('blow').onclick=blow;$('tongueNow').onclick=tongueNow;

// ---- the musebot player: a piece its band composes for the instrument, played on it (dial.mjs /soloist) ----
// (Its seed the page's, by default the band's own (opening-time.js DEFAULT_SEED), the most it plays, and its
// personality's levers and grammars, each drawn from its seed unless set (musebot.js); everything else in the piece the
// band's.)
$('soloSeed').value=DEFAULT_SEED;
const musebot=musebotControls({box:$('personality'),seed:$('soloSeed'),seconds:$('soloSeconds')});
$('solo').onclick=async()=>{
  if(!S?.model||busy)return;
  const on=!S.soloist?.playing;
  if(on){sound();$('soloSaid').textContent='Its band composes the piece ...'}
  const r=await post('/soloist',on?{on,...musebot.given()}:{on});
  if(r.error){$('soloSaid').textContent=r.error;return}
  if(r.pitch!==undefined)took(r);
  if(r.soloist!==undefined){S={...S,soloist:r.soloist};soloShown(S)}
  poll();
};
// (The musebot playing, or the piece it last played: whose, its seed, how far, and what the dial did not play of it.)
const clock=x=>`${Math.floor(x/60)}:${String(Math.floor(x%60)).padStart(2,'0')}`;
function soloShown(s){
  const playing=Boolean(s.soloist?.playing),said=s.soloist?.said;
  $('solo').textContent=playing?'■ Stop the musebot':'▶ A musebot plays';$('solo').classList.toggle('on',playing);$('solo').disabled=busy;
  musebot.show(s.player,said?.personality);
  if(!said)return;
  $('soloSaid').textContent=`${said.player} on the ${label(s.model??said.instrument)}, seed ${said.seed}: ${playing?'':'played '}${clock(Math.min(said.at,said.seconds))} of ${clock(said.seconds)}, ${said.notes} notes`
    +(said.unplayed.length?`; ${said.unplayed.length} not played here (${said.unplayed[0].why})`:'')+(said.late?`; ${said.late} came late`:'')
    +(said.refused.length?`; ${said.refused.length} refused (${said.refused.at(-1).error})`:'')
    +(said.personality?`; its register ${etName(said.personality.register[0])} to ${etName(said.personality.register[1])}, its motif ${said.personality.motif}`:'')+'.';
}
$('keep').onclick=async()=>{const r=await post('/keep',{words:$('words').value});$('kept').textContent=r.kept?'kept':r.error??'';if(r.kept)$('words').value=''};

// ---- the tract and the bore's impedance ----
let tract=new VocalTract([]),MEASURED=null,impedance=null,fetchingImpedance=false;
const setTract=resonances=>{tract=new VocalTract(resonances);draw();sendTract({resonances:tract.resonances})};
$('normal').onclick=()=>sendTract({follow:true});
$('none').onclick=()=>setTract([]);
const canvas=$('plot'),F=[50,6000],Z=[1e5,3e8];
const css=name=>getComputedStyle(document.documentElement).getPropertyValue(name).trim();
// (The canvas sized only when its box changes: sizing it clears it.)
let W=0,H=0,ratio=1;
const x=f=>W*Math.log(f/F[0])/Math.log(F[1]/F[0]),y=p=>H-H*Math.log(Math.max(p,Z[0])/Z[0])/Math.log(Z[1]/Z[0]);
const fx=px=>F[0]*(F[1]/F[0])**(px/W),py=v=>Z[0]*(Z[1]/Z[0])**((H-v)/H);
new ResizeObserver(()=>{const w=canvas.clientWidth,h=canvas.clientHeight,r=devicePixelRatio||1;if(w===W&&h===H&&r===ratio)return;
  W=w;H=h;ratio=r;canvas.width=Math.round(W*ratio);canvas.height=Math.round(H*ratio);draw()}).observe(canvas);
let heard=null,lungsHeard=null;
function draw(){
  if(!W||!S?.model||!P)return;
  const g=canvas.getContext('2d');g.setTransform(ratio,0,0,ratio,0,0);g.clearRect(0,0,W,H);g.font='11px system-ui';
  if(MEASURED){
    g.fillStyle=css('--band');g.fillRect(x(MEASURED.first.f[0]),y(MEASURED.first.p[1]),x(MEASURED.first.f[1])-x(MEASURED.first.f[0]),y(MEASURED.first.p[0])-y(MEASURED.first.p[1]));
    g.fillStyle=css('--bend');g.fillRect(x(MEASURED.held),y(MEASURED.bend[1]),W-x(MEASURED.held),y(MEASURED.bend[0])-y(MEASURED.bend[1]));
  }
  g.strokeStyle=css('--line');g.fillStyle=css('--muted');g.lineWidth=1;
  for(const f of [100,200,500,1000,2000,5000]){g.beginPath();g.moveTo(x(f),0);g.lineTo(x(f),H);g.stroke();g.fillText(f>=1000?`${f/1000} kHz`:`${f} Hz`,x(f)+3,H-4)}
  for(const p of [1e6,1e7,1e8]){g.beginPath();g.moveTo(0,y(p));g.lineTo(W,y(p));g.stroke();g.fillText(`${p/1e6} MPa s/m³`,3,y(p)-3)}
  const f0=heard??hzOf(P.pitch);
  g.strokeStyle=css('--harm');for(let h=1;h*f0<F[1];h++){g.lineWidth=h===1?2:1;g.beginPath();g.moveTo(x(h*f0),0);g.lineTo(x(h*f0),H);g.stroke()}
  if(MEASURED){g.fillStyle=css('--accent');g.beginPath();g.arc(x(Math.max(MEASURED.held,f0+MEASURED.offset)),y(MEASURED.normal),3,0,7);g.fill()}
  const line=(fn,color,width,dash=[])=>{g.strokeStyle=color;g.lineWidth=width;g.setLineDash(dash);g.beginPath();for(let px=0;px<=W;px+=2){const v=fn(fx(px));px?g.lineTo(px,y(v)):g.moveTo(px,y(v))}g.stroke();g.setLineDash([])};
  const bore=impedance?.notes?.[P.midi]??impedance?.fingerings?.[P.fingering]??(P.position!=null?impedance?.positions?.[String(Math.min(7,Math.max(1,Math.round(P.position))))]:null)??impedance?.bore;
  if(bore){
    const at=f=>{const fs=impedance.freqs;let lo=0,hi=fs.length-1;if(f<=fs[0])return 0;if(f>=fs[hi])return hi;while(hi-lo>1){const m=(lo+hi)>>1;fs[m]<=f?lo=m:hi=m}return lo};
    line(f=>{const k=at(f);return Math.hypot(bore.re[k],bore.im[k])},css('--bore'),1.5);
    if(tract.resonances.length)line(f=>{const k=at(f),t=tract.impedance(f);return Math.hypot(bore.re[k]+t.re,bore.im[k]+t.im)},css('--sum'),1,[5,4]);
  }
  if(tract.resonances.length)line(f=>tract.magnitude(f),css('--accent'),2.5);
  g.fillStyle=css('--accent');
  tract.resonances.forEach(r=>{g.beginPath();g.arc(x(r.frequency),y(r.peak),7,0,7);g.fill();g.fillText(`${r.frequency.toFixed(0)} Hz, Q ${r.q.toFixed(1)}, ${(r.peak/1e6).toFixed(1)} MPa s/m³`,x(r.frequency)+10,y(r.peak)-8)});
}
// (Said once for each instrument, and again when its bore's impedance comes.)
function legend(){
  const brass=S.kind==='lips',air=S.kind==='air';
  $('legend').textContent=`Grey: the bore's input impedance ${brass?S.slide?'at its slide\'s nearest position':S.valves?'at its fingering, as its valves stand (each pressed past half way)':'(its one fingering, open)':'for the nearest charted fingering'}${impedance?'':' (being computed: a minute or two, the first time)'}. `+
    (air?'The jet is blown from the mouth\'s pressure: no tract stands before it in the engine. ':`Red: the tract's impedance; dashed: the two in series, what the ${brass?'lips meet':'reed meets'}. `)+
    'Blue lines: the pitch heard and its harmonics. '+
    (MEASURED?`Shaded: measured -- clarinettists' first resonance (Fritz & Wolfe 2005), and above ${MEASURED.held} Hz the peaks of bends and glissandi (Chen, Smith & Wolfe 2009); the dot, where their tract keeps its resonance in normal playing, ${MEASURED.offset} Hz above the note, held at ${MEASURED.held} Hz under it -- the tract a shape's, its resonances its physics', following the note${P.tractFollows?'':' when asked for again'}.`:
      air?'':`No ${label(S.model)} players' tract is measured yet: double-click to add a resonance.`);
}
let dragging=-1;
const near=e=>{const r=canvas.getBoundingClientRect(),px=e.clientX-r.left,pyy=e.clientY-r.top;return {px,pyy,k:tract.resonances.findIndex(q=>Math.hypot(x(q.frequency)-px,y(q.peak)-pyy)<12)}};
const tractOn=()=>S?.model&&S.kind!=='air'&&!busy;
canvas.onpointerdown=e=>{if(!tractOn())return;const {k}=near(e);if(k>=0){dragging=k;canvas.setPointerCapture(e.pointerId)}};
canvas.onpointermove=e=>{if(dragging<0)return;const {px,pyy}=near(e),r=[...tract.resonances];r[dragging]={...r[dragging],frequency:fx(Math.min(Math.max(px,0),W)),peak:py(Math.min(Math.max(pyy,0),H))};setTract(r)};
canvas.onpointerup=()=>{dragging=-1};
canvas.onwheel=e=>{if(!tractOn())return;const {k}=near(e);if(k<0)return;e.preventDefault();const r=[...tract.resonances];r[k]={...r[k],q:Math.min(Math.max(r[k].q*1.08**(-Math.sign(e.deltaY)),.5),60)};setTract(r)};
canvas.ondblclick=e=>{if(!tractOn())return;const {px,pyy,k}=near(e),r=[...tract.resonances];if(k>=0)r.splice(k,1);else r.push({frequency:fx(px),q:8,peak:py(pyy)});setTract(r)};

// ---- the sound: pulled from the engine as the page plays it, begun at the first press of Blow ----
const RATE=48000;
const RING=`class Ring extends AudioWorkletProcessor{constructor(){super();this.b=new Float32Array(${RATE*2});this.r=0;this.w=0;this.n=0;this.under=0;this.t=0;
this.port.onmessage=({data})=>{this.s=1;for(let i=0;i<data.length&&this.n<this.b.length;i++){this.b[this.w]=data[i];this.w=(this.w+1)%this.b.length;this.n++}}}
process(_,outs){const o=outs[0];for(let i=0;i<o[0].length;i++){let v=0;if(this.n>0){v=this.b[this.r];this.r=(this.r+1)%this.b.length;this.n--}else if(this.s)this.under++;for(const c of o)c[i]=v}
if(++this.t%4===0)this.port.postMessage({n:this.n,under:this.under});return true}}registerProcessor('ring',Ring);`;
// (Its shortfall counted from the first sound, said over the last five seconds; the engine's pace as the server times it.)
const AHEAD=Math.round(RATE*.12),BLOCK=2048,recent=new Float32Array(SERIES.reading),SHORT_SECONDS=5;
let started=null,context=null,pulling=false,buffered=0,under=0,pace=null;const shorts=[];
function sound(){
  if(started){if(context?.state==='suspended')context.resume();return}
  started=(async()=>{
    context=new AudioContext({sampleRate:RATE});
    await context.audioWorklet.addModule(URL.createObjectURL(new Blob([RING],{type:'text/javascript'})));
    const node=new AudioWorkletNode(context,'ring',{numberOfInputs:0,outputChannelCount:[2]});node.connect(context.destination);
    const pull=async()=>{if(pulling||buffered>=AHEAD||!active)return;pulling=true;
      try{const r=await fetch(`/winds/audio?frames=${BLOCK}`);pace=Number(r.headers.get('x-pace'))||pace;lungsHeard=r.headers.get('x-lungs');
        // (Another instrument taken up: the page follows at once.)
        if(r.headers.get('x-model')&&r.headers.get('x-version')!==String(V))poll();
        const samples=new Float32Array(await r.arrayBuffer());buffered+=samples.length;node.port.postMessage(samples);
        recent.copyWithin(0,samples.length);recent.set(samples,recent.length-samples.length)}finally{pulling=false}pull()};
    node.port.onmessage=({data})=>{buffered=data.n;under=data.under;pull()};
    pull();
  })();
}
setInterval(()=>{
  if(!active||!started||!S?.model||!P)return;
  // (Heard as its harmonic series, as the dial's tools hear it: YIN read a reed's notes a twelfth or an octave down.)
  const p=seriesPitch(recent,RATE,{silent:-90}),rms=Math.sqrt(recent.reduce((a,v)=>a+v*v,0)/recent.length);
  heard=p.hz;
  // (Blown and nothing heard: its model does not sound the note there.)
  $('heard').textContent=heard?`${heard.toFixed(1)} Hz = ${etName(69+12*Math.log2(heard/440))}, ${(1200*Math.log2(heard/hzOf(P.pitch))).toFixed(0)} ¢ from the pitch asked`:
    P.blowing&&pace!=null&&!(rms>1e-5)?`blown, but no tone: the ${label(S.model)}'s model does not sound this note here`:'--';
  const db=rms>0?20*Math.log10(rms):-Infinity;
  $('level').textContent=db>-120?`${db.toFixed(1)} dBFS`:'silent';$('meter').style.width=`${Math.max(0,Math.min(100,(db+60)/60*100))}%`;
  // (The air left in its breath, as the dial last said it.)
  if(lungsHeard&&P.breathing){const [air,taking]=lungsHeard.split(' ').map(Number),share=Math.max(0,Math.min(1,air/P.breathing.litres));
    $('air').style.width=`${100*share}%`;$('airN').textContent=taking?'breathing in':!P.breathing.on?'unbreathing':`${Math.max(0,air).toFixed(2)} L`}
  const now=performance.now()/1000;shorts.push([now,under]);while(shorts[0][0]<now-SHORT_SECONDS)shorts.shift();
  const short=(under-shorts[0][1])/RATE*1000;
  $('engine').textContent=`${pace?`${Math.round(100*pace)} % of real time`:'--'}${S.threads>1?` on ${S.threads} cores`:''}; ${(buffered/RATE*1000).toFixed(0)} ms ahead${short>0?`, ${short.toFixed(0)} ms short in the last ${SHORT_SECONDS} s`:''}`;
  draw();
},150);

// ---- its settings as a file (live.html, dial-settings.js): what the dial says it is set to, and a file's made on it ----
// (-> {model, settings, words, heard}: the words written to keep it and what the page hears now with them.)
export async function settings(){
  const r=await fetch('/winds/settings',{cache:'no-store'}),got=await r.json();
  if(!r.ok)throw new Error(got.error);
  return {model:got.model,settings:got,words:$('words').value,
    heard:{hz:heard,level:$('level').textContent,heardAs:$('heard').textContent,blowing:Boolean(P?.blowing),pace,threads:S?.threads??null}};
}
// (A file's settings made on its instrument, once the page has taken it up and the dial is not making it: -> what was
// made and what refused.)
export async function load(file,{wait=120}={}){
  for(let k=0;k<wait*4&&!(S?.model===file.model&&!busy&&!S.loading&&!S.muting&&V===S.version);k++)await new Promise(go=>setTimeout(go,250));
  if(S?.model!==file.model||busy)throw new Error(`the ${label(file.model)} was not taken up`);
  const r=await post('/settings',{settings:file.settings});
  if(r.error)throw new Error(r.error);
  if(r.pitch!==undefined)took(r);
  if(file.words)$('words').value=file.words;
  if(r.player)S={...S,player:r.player};
  poll();return r.loaded;
}

// ---- the page's hold on it: taken up, put to rest, its keys ----
// (A wind taken up: the dial asked for it where it plays another and is not already making it, then followed as it
// makes it. One already played is left as it was dialled.)
export async function take(model,{status:el}){
  status=el;active=true;
  if(started&&context?.state==='suspended')context.resume();
  if(S?.model===model&&what)document.getElementById('what').textContent=what;
  let s;try{s=await (await fetch('/winds/state',{cache:'no-store'})).json()}catch(error){el.classList.add('failed');el.textContent=`The winds' dial did not answer: ${error.message}`;return}
  if(s.model!==model&&(s.loading?.model??s.wanted)!==model){
    const r=await (await fetch('/winds/instrument',{method:'POST',body:JSON.stringify({model})})).json();
    if(r.error)say(r.error);
  }
  poll();
}
// (Another family chosen: the breath let go, the sound no longer pulled, the dial no longer asked.)
export function rest(){
  if(!active)return;
  if(P?.blowing&&!busy)post('/blow',{on:false}).then(r=>{if(r.pitch!==undefined)P=r});
  active=false;clearTimeout(polling);
  if(context?.state==='running')context.suspend();
}
export function keys(e){
  if(['INPUT','SELECT','TEXTAREA'].includes(e.target.tagName)&&!['range','radio','checkbox'].includes(e.target.type))return;
  if(e.code==='Space'){e.preventDefault();blow()}else if(e.key==='t')tongueNow();
}
