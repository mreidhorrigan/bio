// The winds on the live dial (live.html): OpenWInD's engine played by its dial (native/openwind/live.mjs, its routes
// here under /winds/), heard through the page -- its sound pulled as the page plays it -- every control its page had,
// each under the heading it belongs to: the player's note, breath and embouchure or lips, fingers, valves or slide,
// tongue, vibrato and vocal tract; the instrument's body and its reed; the model's own constants and its engine. Each
// instrument taken up on its neutral note, one it sounds (neutral.mjs).
import {VocalTract} from '/public/shared/performers/vocal-tract.js';
import {playerEntry,player,source} from '/registry/registry.js';
import {SERIES,seriesPitch} from '/public/shared/estimation/harmonic-series.js';
import {attackKind,firstEndingAt,peakOf} from '/public/shared/performers/attack-curves.js';
import {curveEditor} from '/curves.js';
import {heldFingering,keywork,slideSvg,valvesSvg,woodwindDiagram} from '/public/shared/performers/fingering-diagrams.js';
import {atPitch,playersBand} from '/players.js';
import {DEFAULT_SEED} from '/public/shared/opening-time.js';
import {musebotControls} from '/musebot.js';
import {prerenderControls} from '/prerender.js';

const $=id=>document.getElementById(`w-${id}`);
const NAMES=['C','C♯','D','E♭','E','F','F♯','G','A♭','A','B♭','B'];
const noteName=m=>`${NAMES[((m%12)+12)%12]}${Math.floor(m/12)-1}`;
const etName=p=>{const m=Math.round(p),c=Math.round(100*(p-m));return `${noteName(m)}${c?` ${c>0?'+':''}${c} ¢`:''}`};
// (A valved fingering as its players name it: its pressed valves, "1+3", or "open".)
const valvesName=f=>[...f].map((v,k)=>v==='1'?k+1:null).filter(Boolean).join('+')||'open';
const label=m=>m.replace(/-/g,' ');
// (A trombone's slide: its tube past first position (m) as a position, drawn between its positions' -- past its seventh as
// its sixth and seventh stand apart -- and a position as its tube.)
const slideAt=(v,from,to)=>{const ps=S.slide.positions,k=Math.max(0,Math.min(ps.length-2,ps.findLastIndex(p=>p[from]<=v)));return ps[k][to]+(v-ps[k][from])*(ps[k+1][to]-ps[k][to])/(ps[k+1][from]-ps[k][from])};
const positionOf=out=>slideAt(out,'out','position'),outOf=position=>slideAt(position,'position','out');
const hzOf=m=>440*2**((m-69)/12);
// (The server's state (`S`, /state), the instrument the page's controls were built for (`V`, its version) and its body
// (`B`, the mute in its bell: null none), and what it plays now (`P`): every control shows P, and every change the page
// makes is for V -- the server refuses one for an instrument no longer played, and the page follows the one that is,
// and the body: a mute put in plays its own chart and rows, whose notes the page's must be.)
let S=null,V=null,B=null,P=null;
// (Shown: the winds the family chosen on the page. Put to rest, nothing is asked of their dial -- which any request
// would start -- and their sound is not pulled.)
let active=false,status=null;
const say=text=>{$('said').textContent=text??''};
async function post(path,value={}){
  const r=await fetch(`/winds${path}`,{method:'POST',body:JSON.stringify({...value,version:V})});
  const got=await r.json();if(r.status===409){poll();return {}}return got;
}
// (A control's changes sent one at a time, the latest while one is on its way; each answer what is played now.)
function sender(path){
  let flying=false,next=null;
  return async value=>{
    next=value;if(flying)return;flying=true;
    try{while(next){const asked=next;next=null;const r=await post(path,asked);if(r.error){say(r.error);break}if(r.pitch!==undefined)took(r)}}finally{flying=false}
  };
}
// (What it plays now, shown; where it plays another body -- a mute put in or taken out -- the controls built for it first,
// from its /state.)
const took=r=>{if('mute' in r&&r.mute!==B)return poll();P=r;say('');refresh()};
// (The controls' blocks -- under Player, Instrument and Physics -- held still while an instrument is made.)
let busy=true,what='';
const blocks=()=>document.querySelectorAll('.w-controls');

// ---- the server's state: what is being made and what plays; the controls built again for each instrument taken up ----
let polling=null;
async function poll(){
  clearTimeout(polling);
  if(!active)return;
  let s;try{s=await (await fetch('/winds/state',{cache:'no-store'})).json()}catch{polling=setTimeout(poll,1500);return}
  if(!active)return;
  S=s;
  if(s.model&&(s.version!==V||(s.mute??null)!==B))build(s);
  shown(s);soloShown(s);
  // (A musebot playing: the controls follow what it plays.)
  if(s.soloist?.playing&&s.version===V&&s.played?.pitch!=null){P=s.played;refresh()}
  // (Blown: its breath said as the dial measures the air its model lets in.)
  else if(P?.blowing&&s.version===V&&s.played?.lungs&&P.breathing&&S.lungs){P.lungs=s.played.lungs;lungsSaid()}
  if(s.model&&s.impedance&&!impedance&&!fetchingImpedance){fetchingImpedance=true;const asked=V;
    fetch('/winds/impedance').then(r=>r.json()).then(z=>{if(asked===V){impedance=z;legend();draw()}}).finally(()=>{fetchingImpedance=false})}
  polling=setTimeout(poll,s.loading||s.muting||s.soloist?.playing?500:P?.blowing?1000:!s.model||!s.impedance?2000:5000);
}
// (What is being made said as it goes; the one played silent until the next is ready, its controls held still
// meanwhile.)
function shown(s){
  status.classList.toggle('failed',Boolean(s.failed&&!s.loading));
  const breathSaid=n=>n.breathTimes&&n.breathTimes!==1?`, blown at ${n.breathTimes} times its players' usual breath pressure so that it sounds`:'';
  const neutral=s.neutral?`. It starts on its neutral note, ${etName(s.notes[s.neutral.note])} at ${s.neutral.dynamic}${breathSaid(s.neutral)}`:s.model?`. It starts on the middle of its charted notes: no neutral note has been found for this body yet (Commands/Make Dial Bodies.command finds one)`:'';
  status.textContent=s.loading?`Making the ${label(s.loading.model)}: ${s.loading.step} (${Math.round(s.loading.seconds)} s so far).${s.model?` The ${label(s.model)} is silent until it is ready.`:''}`:
    s.failed?`The ${label(s.failed.model)} could not be loaded: ${s.failed.error}.${s.model?` The ${label(s.model)} still plays.`:''}`:
    s.model?`The ${label(s.model)} is ready${neutral}.${s.threads>1?` Its engine runs on ${s.threads} processor cores.`:''}`:'Starting …';
  busy=Boolean(s.loading)||!s.model;
  for(const b of blocks())b.disabled=busy;for(const id of ['blow','reset','neutral'])$(id).disabled=busy;
  $('tongueNow').disabled=busy||!P?.blowing;
}

// ---- the controls for the instrument played ----
// (Each column's label, its unit in brackets -- "no unit" where the engine takes it scaled -- and a sentence saying
// what it is.)
const MEANING={gamma:['Breath pressure (× the closing pressure)','The pressure in the player\'s mouth, as a multiple of the pressure that would push the reed shut.'],
  zeta:['Embouchure (no unit)','How far the lip lets the reed open, together with the reed\'s width, as one scaled number.'],
  kappa:['Reed\'s own flow (no unit)','The air the reed itself pushes as it moves, scaled.'],
  qfactor:['Reed damping, Q (no unit)','How quickly the lip damps the reed\'s vibration. A lower Q means more damping.'],
  pulsation:['Reed resonance (Hz)','The frequency at which the reed vibrates by itself.'],
  contact_stifness:['Lay contact stiffness (no unit)','How hard the reed is pushed back once it touches the mouthpiece\'s lay, scaled.'],
  contact_exponent:['Contact exponent (no unit)','How sharply that push grows as the reed presses into the lay; the slider moves it up to 3 either way.'],
  closing_pressure:['Closing pressure (kPa)','The mouth pressure that would push the reed shut against the mouthpiece.']};
const LIPS={gamma:['Breath pressure (× the closing pressure)','The pressure in the player\'s mouth, as a multiple of the pressure that would push the lips shut.'],
  zeta:['Lip opening (no unit)','How far apart the lips rest, together with the width of their opening, as one scaled number.'],
  kappa:['Lips\' own flow (no unit)','The air the lips themselves push as they move, scaled.'],
  qfactor:['Lip damping, Q (no unit)','How quickly the lips\' outward motion dies away. A lower Q means more damping.'],
  pulsation:['Lip frequency','The frequency at which the lips buzz by themselves. Moving it alone keeps the pitch asked for and the breath; the bore then decides which partial sounds.'],
  contact_stifness:['Contact (none)','None: lips have no lay to touch.'],contact_exponent:['Contact exponent (none)','None: lips have no lay to touch.'],
  closing_pressure:['Closing pressure (kPa)','The mouth pressure that would push the lips shut.'],
  inward_ratio:['Inward resonance (× the outward)','The frequency of the lips\' inward motion, as a multiple of their outward one.'],
  inward_qfactor:['Inward damping, Q (no unit)','How quickly the lips\' inward motion dies away.'],
  inward_coupling:['Inward coupling (no unit)','The mass of the lips\' outward motion divided by the mass of their inward one.']};
const JET={Uj:['Jet speed (m/s)','The speed of the air as it leaves the player\'s lips.'],noise:['Turbulence (no unit)','How much noise the jet carries.'],
  window:['Window (share, 0 to 1)','How much of the embouchure hole the lip leaves uncovered.'],
  Ascale:['Jet amplification (no unit)','How much a disturbance on the jet grows as it crosses to the edge.'],
  Gj:['Jet drive (no unit)','How strongly the jet pushes the air at the edge, scaled.'],
  Gl:['Edge losses (no unit)','How much of the flow is lost where it narrows at the edge (the vena contracta), scaled.'],
  C:['Jet length (m)','The jet\'s length over the speed of its disturbances as a share of the jet\'s: divided by the jet speed, it gives the time a disturbance takes to cross.'],
  y0:['Jet offset (× the jet\'s profile width)','How far the jet\'s centre sits from the edge; the slider moves it up to 1 either way.'],
  span:['Dipole span (m)','How far apart the jet\'s two pushes on the air sit, either side of the edge.']};
const meaningOf=name=>(S.kind==='lips'?LIPS[name]:S.kind==='air'?JET[name]:null)??MEANING[name]??[name,''];
// (Each column under the heading it belongs to. A reed's: the breath, the embouchure and the lips' damping of it the
// player's; its own flow, resonance, lay contact and closing pressure the reed's, a part of the instrument; how its
// contact stiffens the model's. A brass player's lips are the player's, their contact the model's. A flutist's breath,
// window, jet length and aim the player's; the jet's turbulence, growth, drive, edge losses and span the model's.)
const GROUP={reed:{gamma:'Player',zeta:'Player',qfactor:'Player',kappa:'Instrument',pulsation:'Instrument',contact_stifness:'Instrument',closing_pressure:'Instrument',contact_exponent:'Physics'},
  lips:{contact_stifness:'Physics',contact_exponent:'Physics'},air:{Uj:'Player',window:'Player',C:'Player',y0:'Player',noise:'Physics',Ascale:'Physics',Gj:'Physics',Gl:'Physics',span:'Physics'}};
const groupOf=name=>GROUP[S.kind]?.[name]??'Player';
const col=k=>S.columns[k][2];
// (A dial's place x, -1 to 1, as the server takes it: 1/reach to reach times the rules' value (dial-reach.json); the contact's exponent
// three either side of it, the jet's offset one; a column the rules hold at nothing, or a brass player's contact, fixed.)
const ADDITIVE={contact_exponent:3,y0:1};
const fixed=k=>S.kind==='lips'&&col(k)==='contact_exponent'||!(col(k) in ADDITIVE)&&!(P.rules[k]>0);
const valueOf=(k,x)=>col(k) in ADDITIVE?P.rules[k]+ADDITIVE[col(k)]*x:P.rules[k]*S.reach**x;
const placeOf=(k,v)=>col(k) in ADDITIVE?(v-P.rules[k])/ADDITIVE[col(k)]:Math.log(v/P.rules[k])/Math.log(S.reach);
// (A column's value in the units its box shows: a resonance in Hz, a pressure in kPa; and back.)
const unit={pulsation:[v=>v/2/Math.PI,v=>2*Math.PI*v],closing_pressure:[v=>v/1000,v=>1000*v]};
const shownValue=(name,v)=>{const u=unit[name]?unit[name][0](v):v;return Math.abs(u)>=1e4||Math.abs(u)<.01&&u!==0?u.toExponential(3):(+u.toPrecision(5)).toString()};
const controls={};
// (A slider and a box in a row of `box`: the slider's place `to`/`from` the value, the box the value itself.)
function row(box,id,text,{min,max,to=v=>v,from=x=>x,step='any',format=v=>+(+v).toPrecision(4),change,note}){
  const r=document.createElement('div');r.className='row';
  r.innerHTML=`<label for="w-${id}"></label><input type="range" id="w-${id}" step="any"><input type="number" id="w-${id}N" step="${step}">`;
  r.querySelector('label').textContent=text;box.append(r);
  let n=null;if(note!==undefined){n=document.createElement('div');n.className='note';n.textContent=note;box.append(n)}
  const range=r.querySelector('input[type=range]'),number=r.querySelector('input[type=number]');
  range.min=to(min);range.max=to(max);
  const set=v=>{if(held!==range)range.value=to(Math.min(max,Math.max(min,v)));if(document.activeElement!==number)number.value=format(v)};
  range.oninput=()=>{const v=from(+range.value);number.value=format(v);change(v)};
  number.onchange=()=>{const v=+number.value;if(Number.isFinite(v)&&v>=min&&v<=max)change(v);else refresh()};
  // (Each slider's players' band (players.js), a value placed on it as the slider places it.)
  return controls[id]={set,range,number,note:n,band:playersBand(range),place:v=>(to(v)-to(min))/(to(max)-to(min))};
}
// (The slider a pointer holds is not moved under it by an answer.)
let held=null;
addEventListener('pointerdown',e=>{if(e.target.type==='range')held=e.target});addEventListener('pointerup',()=>{held=null});
const sendDial=sender('/dial'),sendHole=sender('/hole'),sendPitch=sender('/pitch'),sendLip=sender('/lip'),sendArticulation=sender('/articulation'),
  sendRepeat=sender('/repeat'),sendVibrato=sender('/vibrato'),sendTract=sender('/tract'),sendSlide=sender('/slide'),sendAttack=sender('/attack'),
  sendBreathing=sender('/breathing'),sendFlutter=sender('/flutter'),sendHum=sender('/hum'),sendGrowl=sender('/growl'),sendNoise=sender('/noise'),sendMute=sender('/mute');
// (The player's noise (dial.mjs /noise): the player's temperature and each kind's under it, multiplied as the engine is
// given them; each kind's size at 1 said beside it.)
const NOISE_LABEL={breath:"The breath's pressure",lips:"The lips' tension"},noiseId=what=>`noise${what[0].toUpperCase()}${what.slice(1)}`;
// (The breath's attack: its curve drawn once, the dial's answer shown on it; its first segment, the rise, held within
// the rise's limits.)
const RISEN=[[0,0],[.05,1]];
const attack=curveEditor($('attack'),{kind:attackKind({from:0,straight:false}),label:'Breath at a note\'s start',change:points=>{
  if(!S?.model||busy){if(P?.breathAttack)attack.set(P.breathAttack);return}
  const [low,high]=S.limits.rise,rise=points[1][0];
  sendAttack({points:rise<low||rise>high?firstEndingAt(points,Math.min(high,Math.max(low,rise))):points})}});
$('plainRise').onclick=()=>{if(S?.model&&!busy)sendAttack({points:firstEndingAt(RISEN,P?.rise??RISEN[1][0])})};

function build(s){
  V=s.version;B=s.mute??null;P=s.played;impedance=null;
  for(const box of ['tongue','repeat','lungs','vibrato','noise','flutter','hum','growl','excitorPlayer','excitorInstrument','excitorPhysics','holes','slideBox','diagram'])$(box).replaceChildren();
  drawnFor=null;$('diagramNote').textContent='';
  for(const k in controls)delete controls[k];
  const kind=s.kind,brass=kind==='lips';
  what=`The ${label(s.model)}, simulated by OpenWInD's engine and heard through this page. You or a musebot play it. You can set its player's ${brass?'lips':kind==='air'?'breath and fingers':'reed and fingers'}, tongue, vibrato${kind==='air'?'':' and vocal tract'}, and the musebot's personality, by ear.`;
  document.getElementById('what').textContent=what;
  // (The notes: each charted note, a brass instrument's each partial its lips sound -- a trombone's at each position its
  // chart gives it, alternates too; the pitch between them.)
  const noteText=(m,k)=>!brass?`${noteName(m)} (${m})`:`${etName(m)} (${s.fingerings?`${valvesName(s.fingerings[k])}, `:''}${s.positions?`position ${s.positions[k]}${s.alternates[k]?', alternate':''}, `:''}partial ${s.partials[k]})`;
  $('note').replaceChildren(...s.notes.map((m,k)=>new Option(noteText(m,k)+(s.neutral?.note===k?' · neutral':''),k)));
  if(!$('dynamic').options.length)for(const d of s.dynamics)$('dynamic').add(new Option(d,d));
  const [low,high]=[Math.min(...s.notes),Math.max(...s.notes)];
  for(const el of [$('pitch'),$('pitchN')]){el.min=low;el.max=high}
  // (The tongue: its stroke, a legato tongue's length, the breath's rise, beside what was measured of players.)
  const t=s.tongue,m=t.measured,ms=v=>Math.round(1000*v),L=s.limits;
  $('articulationNote').textContent=`A slurred note on the same pitch (within ${t.samePitch} cents) is tongued legato: a half attack.`;
  row($('tongue'),'stroke','Tongued stroke (ms)',{min:ms(L.stroke[0]),max:ms(L.stroke[1]),step:1,format:Math.round,change:v=>sendArticulation({stroke:v/1000}),
    note:`How long the air is ${kind==='reed'?'stopped by the tongue on the reed':'stopped'} before a tongued note. Measured: clarinettists' portato ${ms(m.portato[0])} ms (standard deviation ${ms(m.portato[1])} ms), and their staccato ${ms(m.staccato[0][1])} ms at four notes a second and ${ms(m.staccato[1][1])} ms at two (Pàmies-Vilà, Hofmann & Chatziioannou 2018); saxophonists' ${(1000*m.saxophone).toFixed(1)} ms (Hofmann & Goebl 2014).`});
  row($('tongue'),'softSeconds','Legato tongue (ms)',{min:ms(L.softSeconds[0]),max:ms(L.softSeconds[1]),step:1,format:Math.round,change:v=>sendArticulation({softSeconds:v/1000}),
    note:kind==='reed'?`How long the tongue touches the reed in a legato tongue, closing it to ${Math.round(100*t.soft)} % of its opening: a half attack.`:`How long the air dips, to ${Math.round(100*t.dip)} % of itself, in a legato tongue: a half attack.`});
  row($('tongue'),'rise','Breath rise from rest (ms)',{min:ms(L.rise[0]),max:ms(L.rise[1]),step:1,format:Math.round,change:v=>sendArticulation({rise:v/1000}),
    note:kind==='reed'?'For a note from silence: the tongue holds the reed while the breath rises, and lets it go once the breath has risen.':brass?'For a note from silence: the air is let into the lips, which start as they were measured starting on this engine.':'For a note from silence: how long the breath takes to rise.'});
  row($('repeat'),'repeatRate','Repeated notes (per second)',{min:L.repeat[0],max:L.repeat[1],to:Math.log,from:Math.exp,step:.1,format:v=>v.toFixed(1),change:v=>sendRepeat({rate:v}),
    note:`Each note is articulated as chosen above. Measured on brass players: single tonguing up to about ${m.single} notes a second, double tonguing about ${m.double} (Bertsch & Hoole 2014).`});
  // (Its breathing: a breath as deep as wind players take one, taken in as fast as a singer's full breath; the page's
  // choice whether it breathes sent to the dial, which holds one breath without end until it is told.)
  if(s.lungs){const n=s.lungs;
    row($('lungs'),'litres','Breath taken (L)',{min:L.litres[0],max:L.litres[1],step:.05,format:v=>v.toFixed(2),change:v=>sendBreathing({litres:v}),
      note:`Wind players' lungs hold ${n.capacity.litres} L at most (standard deviation ${n.capacity.sd} L; Bouros, Protogerou, Castana & Vasilopoulos 2018), and they spend ${Math.round(100*n.spent.share)} % of that in a breath (Cossette, Sliwinski & Macklem 2000): ${n.breath} L.`});
    row($('lungs'),'inhale','Breathing in (ms)',{min:ms(L.inhale[0]),max:ms(L.inhale[1]),step:10,format:Math.round,change:v=>sendBreathing({inhale:v/1000}),
      note:`Wind players breathe in fast and deep (Bouhuys 1964); reed players' fastest breaths take about 300 ms (Fuks & Sundberg 1998). By default, a singer's full breath: ${ms(n.inhale.seconds)} ms (Salomoni, van den Hoorn & Hodges 2016), until wind players' own is measured.`});
    if(P.breathing&&$('breathing').checked!==P.breathing.on)sendBreathing({on:$('breathing').checked});
  }
  // (The vibrato: the player's own as authored, in a woodwind player's breath, in a brass player's lips.)
  const own=s.vibratoOwn;
  $('vibratoNote').textContent=`${own.width>0?`The ${label(s.model)}'s players use one ${own.width} cents wide at ${own.rate} Hz`:`The ${label(s.model)} is usually played without vibrato${own.reach?`; ${own.reach} cents wide where a style asks for one`:''}`}. ${brass?'It sways the whole embouchure, as the mouthpiece is pressed into the lips and eased off, deeply enough that the note is heard swaying this wide.':'It sways the breath.'}`;
  row($('vibrato'),'vibratoWidth','Width (cents)',{min:L.width[0],max:L.width[1],step:1,format:Math.round,change:v=>sendVibrato({width:v})});
  row($('vibrato'),'vibratoRate','Rate (Hz)',{min:L.rate[0],max:L.rate[1],step:.1,format:v=>v.toFixed(1),change:v=>sendVibrato({rate:v})});
  if(s.noise){const {profile:f,most}=s.noise,dial={min:0,max:most,step:.05,format:v=>v.toFixed(2)};
    row($('noise'),'noisePlayer',"The player's unsteadiness (× a player's)",{...dial,change:v=>sendNoise({player:v}),
      note:`Scales every kind below. The wavering's power falls as 1/f^${f.beta} from ${f.low} to ${f.high} Hz, with a ${f.tremor.hz} Hz tremor making up ${Math.round(100*f.tremor.share)} % of it.`});
    for(const {what,sd} of s.noise.kinds)row($('noise'),noiseId(what),`${NOISE_LABEL[what]} (× a player's)`,{...dial,change:v=>sendNoise({[what]:v}),
      note:`At 1, it wavers by ${+(100*sd).toPrecision(2)} % of the ${what==='breath'?'pressure':'tension'} asked for.`});
  }
  // (Its flutter, its hum and its growl, as the renders' players play them, by the engine's own source of them; a dial
  // started before them has none, one started before its growl no growl.)
  if(L.flutterHz){
    row($('flutter'),'flutterHz','Flutter rate (per second)',{min:L.flutterHz[0],max:L.flutterHz[1],step:.5,format:v=>v.toFixed(1),change:v=>sendFlutter({hz:v}),
      note:'By default the middle of the renders\' flutters, 28 to 33 a second, as fast as speakers\' voiceless tongue-tip trills were measured (Elie & Laprie 2017). No wind player\'s flutter has been measured.'});
    row($('flutter'),'flutterDepth','Breath closed off (share, 0 to 1)',{min:L.flutterDepth[0],max:L.flutterDepth[1],step:.01,format:v=>v.toFixed(2),change:v=>sendFlutter({depth:v}),
      note:'How much of the breath each flutter closes off and lets go, as the renders do it, on top of whatever else the breath is doing: an attack, a tongued note or a new breath.'});
    row($('hum'),'humInterval','Hummed pitch (semitones from the note)',{min:L.humInterval[0],max:L.humInterval[1],step:.01,format:v=>v.toFixed(2),change:v=>sendHum({interval:v}),
      note:'Hummed in the player\'s own voice (the registry\'s low and high voices), as the renders hum. By default an octave below the note, the middle of what the renders use.'});
    row($('hum'),'humLevel','Hum level (× the breath)',{min:L.humLevel[0],max:L.humLevel[1],step:.01,format:v=>v.toFixed(2),change:v=>sendHum({level:v}),
      note:'How much the voice swings the breath, its overtones weakening as the square of their number. The renders use 0.2.'});
    if(L.growlInterval){
      row($('growl'),'growlInterval','Growled pitch (semitones from the note)',{min:L.growlInterval[0],max:L.growlInterval[1],step:.01,format:v=>v.toFixed(2),change:v=>sendGrowl({interval:v}),
        note:'Growled in the player\'s voice, as the hum is. By default an octave below the note, the middle of what the renders use.'});
      row($('growl'),'growlLevel','Growl level (× the breath)',{min:L.growlLevel[0],max:L.growlLevel[1],step:.01,format:v=>v.toFixed(2),change:v=>sendGrowl({level:v}),
        note:'How much the rough voice swings the breath.'});
      row($('growl'),'growlRough','Roughness (0 to 1)',{min:L.growlRough[0],max:L.growlRough[1],step:.01,format:v=>v.toFixed(2),change:v=>sendGrowl({rough:v}),
        note:'The voice\'s period doubled, every other pulse this much weaker, with breath noise as rough. The renders use 0.3 to 0.9.'});
      $('techniqueNote').textContent='Played by the engine as the renders play them. With both a growl and a hum on, the growl is heard.';
    }else $('techniqueNote').textContent='This dial was started before growls were added: run Commands/Start Live Dial.command again to get them.';
  }else $('techniqueNote').textContent='This dial was started before flutter and humming were added: run Commands/Start Live Dial.command again to get them.';
  // (The reed, the lips or the jet: each column the engine takes, 1/reach to reach times the rules' value at the pitch,
  // under the heading it belongs to.)
  const reach=s.reach===4?'from a quarter of to four times':`from 1/${s.reach} of to ${s.reach} times`,between=`Each slider moves its value ${reach} the value the playing rules give at this pitch and dynamic; the box beside it shows the value itself. The shaded band under a slider is what was measured of real players and reeds.`;
  $('playerLegend').textContent=brass?'Lips and breath':kind==='air'?'Breath and jet':'Breath and embouchure';
  $('excitorNote').textContent=`What the player controls. ${between}`+(brass?' The lip frequency slider is in Hz, across the lips\' reach.':'');
  $('instrumentLegend').textContent='Reed';
  $('instrumentNote').textContent=`The reed itself. ${between}`;
  $('physicsLegend').textContent=brass?'The lips\' contact':kind==='air'?'The jet\'s model':'The reed\'s contact';
  $('physicsNote').textContent=`The model's constants for the ${brass?'lips':kind==='air'?'jet':'reed'}. ${between}`;
  const boxOf={Player:$('excitorPlayer'),Instrument:$('excitorInstrument'),Physics:$('excitorPhysics')};
  for(const k of s.dials){
    const name=col(k),[text,about]=meaningOf(name),box=boxOf[groupOf(name)];
    if(brass&&name==='pulsation'){
      const [lo,hi]=s.lipReach;
      Object.assign(row(box,`lip${k}`,`${text} (Hz)`,{min:lo,max:hi,to:Math.log,from:Math.exp,step:.1,format:v=>v.toFixed(1),change:v=>sendLip({lip:v}),note:about}),{lip:true});
      continue;
    }
    const c=row(box,`col${k}`,text,{min:-1,max:1,change:x=>sendDial({column:k,x}),note:about});
    c.range.oninput=()=>{const x=+c.range.value;c.number.value=shownValue(name,valueOf(k,x));sendDial({column:k,x})};
    // (Its box the column's value: the place it stands at found from it.)
    c.number.onchange=()=>{const v=+c.number.value,x=placeOf(k,unit[name]?unit[name][1](v):v);if(Number.isFinite(x)&&x>=-1&&x<=1)sendDial({column:k,x});else refresh()};
    Object.assign(c,{k,name});
  }
  $('instrumentSet').hidden=!$('excitorInstrument').children.length;
  $('physicsSet').hidden=!$('excitorPhysics').children.length;
  // (The fingers: each hole's opening; a valved instrument's, each valve's -- its two switches moved as one.)
  $('fingerSet').hidden=brass&&!s.valves&&!s.slide;
  $('fingerLegend').textContent=brass?s.slide?'Slide':'Valves':'Fingers';
  // (A brass player's mutes, as its players' kit has them (render/synthesis/geometry/brass-mutes.json), or none.)
  $('muteSet').hidden=!s.mutes?.length;
  $('mute').replaceChildren(new Option('none',''),...(s.mutes??[]).map(m=>new Option(MUTE_NAME[m]??m,m)));
  $('fingerNote').textContent=s.slide?'The slide position, from 1 (all the way in) to 7 and beyond. Each note sits where the players\' chart puts it, adjusted so its partial plays in tune; a pitch between notes is glided to on the partial played there. Moved here by itself, with the lips held, the bore sets the pitch.'
    :brass?'Each valve, from 0 (pressed down) to 1 (up); in between is a half-valve. They follow the fingering in the players\' chart until you move the pitch.'
    :'Each hole\'s opening, from 0 (closed) to 1 (open). They follow the fingering for the pitch until you move the pitch.';
  // (A trombone's slide: its slider as long as its tube, each position marked; its box the position.)
  if(s.slide){
    const c=row($('slideBox'),'slide','Slide position (1 to 7)',{min:1,max:positionOf(s.slide.most),to:outOf,from:positionOf,step:.01,format:v=>v.toFixed(2),
      change:v=>sendSlide({out:Math.min(Math.max(outOf(v),0),s.slide.most)}),note:''});
    c.note.style.minHeight='2.9em';
    const marks=document.createElement('datalist');marks.id='w-slideMarks';marks.append(...s.slide.positions.map(p=>new Option(String(p.position),p.out)));
    $('slideBox').append(marks);c.range.setAttribute('list','w-slideMarks');
  }
  s.columns.forEach((c,k)=>{if(c[0]!=='opening'||brass&&!s.valves.some(([first])=>first===k))return;
    const box=document.createElement('div');box.innerHTML=`<label><span></span><b></b></label><input type="range" min="0" max="1" step="0.01">`;
    box.querySelector('span').textContent=brass?`Valve ${c[1]+1}`:s.holes?.[c[1]]??c[2]??c[1];
    const slider=box.querySelector('input'),value=box.querySelector('b');
    slider.oninput=()=>{value.textContent=(+slider.value).toFixed(2);sendHole({column:k,value:+slider.value})};
    controls[`hole${k}`]={set:v=>{if(held!==slider)slider.value=v;value.textContent=v.toFixed(2)},hole:k};
    $('holes').append(box)});
  // (The tract: its players' where measured; a flute's jet blown from the mouth, no tract before it in the engine.)
  $('tractLegend').textContent=brass?'Vocal tract, upstream of the lips':kind==='air'?'The bore, as the jet meets it':'Vocal tract, upstream of the reed';
  tract=new VocalTract(P.tract);
  const range=path=>playerEntry(s.model,`tract.${path}`);
  // (Whose: each entry's source, its authors' surnames and year; the saxophones' tract saxophonists' on the tenor.)
  const cite=e=>{const {authors,year}=source(e.source),names=authors.split(', ').map(a=>a.split(' ').at(-1));return `${names.length>1?`${names.slice(0,-1).join(', ')} & ${names.at(-1)}`:names[0]} ${year}`};
  MEASURED=s.tractMeasured?{first:{f:range('first.frequency').range,p:range('first.peak').range},held:player(s.model,'tract.normal.held'),offset:player(s.model,'tract.normal.offset'),
    normal:player(s.model,'tract.normal.peak'),bend:range('bend.peak').range,whose:s.model.endsWith('-saxophone')?`saxophonists'${s.model==='tenor-saxophone'?'':' (on the tenor)'}`:'clarinettists\'',
    cites:{first:cite(range('first.frequency')),bend:cite(range('bend.peak')),normal:cite(range('normal.offset'))}}:null;
  $('normal').hidden=$('none').hidden=$('tractHow').hidden=kind==='air';
  $('normal').disabled=!s.tractMeasured;$('normal').title=s.tractMeasured?'':`No ${label(s.model)} player's vocal tract has been measured yet.`;
  // (What the instrument is, and what its engine holds.)
  const rows=(id,pairs)=>{$(id).replaceChildren(...pairs.filter(([,v])=>v!=null&&v!=='').map(([a,b])=>{const tr=document.createElement('tr');tr.innerHTML='<td></td><td></td>';
    tr.cells[0].textContent=a;tr.cells[1].textContent=b;tr.cells[1].title=b;return tr}))};
  const holes=s.columns.filter(c=>c[0]==='opening').length;
  rows('body',[['Instrument',label(s.model)],['Compass',`${etName(low)} to ${etName(high)}, ${s.notes.length} ${brass?'partials and fingerings':'charted notes'}`],
    ['Holes',brass?null:`${new Set(s.columns.filter(c=>c[0]==='opening').map(c=>c[1])).size} holes (${holes} openings in the model)`],
    ['Valves',s.valves?`${s.valves.length}, each with its own extra tube and two switches in the model`:null],
    ['Slide',s.slide?`${(1000*s.slide.most).toFixed(0)} mm of extra tube at full reach; ${s.slide.positions.length} positions`:null],
    ['Neutral note',s.neutral?`${etName(s.notes[s.neutral.note])} at ${s.neutral.dynamic}${s.neutral.breathTimes!==1?`, blown at ${s.neutral.breathTimes} times its players' usual breath pressure`:''}; it sounds ${s.neutral.cents} cents from its pitch (found ${new Date(s.neutral.found).toLocaleDateString()})`:'Not found for this body yet: Commands/Make Dial Bodies.command finds one.'],
    ['Body file',s.layout?.madeFrom?`made from ${s.layout.madeFrom.slice(0,12)}`:null]]);
  const lay=s.layout??{};
  rows('engineTable',[['Losses',lay.losses],['Mesh',lay.mesh],['Finite elements',lay.order!=null?`order ${lay.order}`:null],['Precision',lay.single==null?null:lay.single?'single':'double'],
    ['Rate',lay.rate?`${lay.rate} Hz${lay.ratio?`, ${lay.ratio} steps a sample`:''}`:null],['Unknowns',lay.unknowns?`${lay.unknowns} (${lay.entries} matrix entries)`:null],
    ['Processor cores',String(s.threads)],['Sliders\' reach',`from 1/${s.reach} of to ${s.reach} times the playing rules' value`]]);
  for(const b of blocks())b.hidden=false;
  refresh();legend();draw();
}

// ---- every control as what is played now ----
function refresh(){
  if(!P||!S?.model)return;
  if(dragging<0){tract=new VocalTract(P.tract??[]);draw()}
  $('blow').textContent=P.blowing?'Blowing':'Blow';$('blow').classList.toggle('on',P.blowing);
  $('tongueNow').disabled=!P.blowing||busy;
  if(document.activeElement!==$('note'))$('note').value=String(P.note??S.notes.indexOf(P.midi));
  if(document.activeElement!==$('dynamic'))$('dynamic').value=P.dynamic;
  if(held!==$('pitch'))$('pitch').value=P.pitch;if(document.activeElement!==$('pitchN'))$('pitchN').value=P.pitch.toFixed(2);
  for(const r of document.querySelectorAll('input[name=w-articulation]'))r.checked=r.value===P.articulation;
  controls.stroke.set(1000*P.stroke);controls.softSeconds.set(1000*P.softSeconds);controls.rise.set(1000*P.rise);
  if(P.breathAttack){attack.set(P.breathAttack);const [t,y]=peakOf(P.breathAttack);
    $('attackNote').textContent=(y>1?`The breath peaks at ${y.toFixed(2)} times the breath set, ${Math.round(1000*t)} ms in, and settles by ${Math.round(1000*P.breathAttack.at(-1)[0])} ms. `:'A plain rise: the breath comes up to what is set and stays there. ')
      +`This shape is used for a note from silence and after every tongued stroke${S.kind==='reed'?' (the tongue lets go of the reed as the first segment ends)':''}. To edit it: press anywhere on the plot to add a point and drag it (above the dashed line is a peak over the breath set); drag a point to move it; select one to type its numbers; double-click it, or press Delete, to remove it. The first segment is the breath's rise set above. The engine eases through each segment.`}
  $('repeating').checked=P.repeat.on;controls.repeatRate.set(P.repeat.rate);
  if(P.breathing&&S.lungs){
    $('breathing').checked=P.breathing.on;controls.litres.set(P.breathing.litres);controls.inhale.set(1000*P.breathing.inhale);
    lungsSaid();
  }
  $('vibrating').checked=P.vibrato.on;controls.vibratoWidth.set(P.vibrato.width);controls.vibratoRate.set(P.vibrato.rate);
  if(P.noise&&controls.noisePlayer){controls.noisePlayer.set(P.noise.player);for(const {what} of S.noise.kinds)controls[noiseId(what)].set(P.noise[what])}
  if(P.flutter&&controls.flutterHz){
    $('fluttering').checked=P.flutter.on;controls.flutterHz.set(P.flutter.hz);controls.flutterDepth.set(P.flutter.depth);
    $('humming').checked=P.hum.on;controls.humInterval.set(P.hum.interval);controls.humLevel.set(P.hum.level);
    if(P.growl&&controls.growlInterval){$('growling').checked=P.growl.on;controls.growlInterval.set(P.growl.interval);controls.growlLevel.set(P.growl.level);controls.growlRough.set(P.growl.rough)}
    // (The voice's pitch, and where the reed, lips or jet sum and difference it with the note.)
    const growling=P.growl?.on&&P.growled!=null,h=growling?P.growled:P.hummed,f=hzOf(P.pitch);
    $('humNote').textContent=h==null?'':`${growling?'Growled':'Hummed'} at ${h.toFixed(1)} Hz (${etName(12*Math.log2(h/440)+69)}). Against the note's ${f.toFixed(1)} Hz, it makes a difference tone at ${Math.abs(f-h).toFixed(1)} Hz and a sum tone at ${(f+h).toFixed(1)} Hz.`;
  }
  if(controls.slide&&P.slide!=null){controls.slide.set(positionOf(P.slide));
    controls.slide.note.textContent=`${Math.round(1000*P.slide)} mm of extra tube; the hand is ${Math.round(500*P.slide)} mm out. The slide moves as players move it: taking at least ${Math.round(1000*S.slide.least)} ms, at about ${S.slide.speed} m/s.`}
  muteSaid();
  fingered();
  for(const c of Object.values(controls)){
    if(c.hole!==undefined)c.set(P.row[c.hole]);
    if(c.lip&&P.lip!=null)c.set(P.lip);
    if(c.k===undefined)continue;
    const off=fixed(c.k);c.range.disabled=c.number.disabled=off;
    if(held!==c.range)c.range.value=P.x[c.k]??0;
    if(document.activeElement!==c.number)c.number.value=shownValue(c.name,P.row[c.k]);
    if(c.name==='gamma'&&c.note){const at=S.columns.findIndex(q=>q[0]==='reed'&&q[2]==='closing_pressure');if(at>=0)c.note.textContent=`${meaningOf('gamma')[1]} Now ${(P.row[c.k]*P.row[at]/1000).toFixed(2)} kPa.`}
  }
  drawPlayers();
  said();
}
// (Its breath said: the air its model let into its bore as it was last blown, the engine's own (stream.rs Air), and what
// its players were measured spending there -- as the page refreshes, and as the dial measures it while it is blown
// (poll).)
function lungsSaid(){
  const f=P.lungs.flow,players=P.lungs.players,src=S.lungs.airflow,b=S.breath,dialled=P.rules[b]>0&&Math.abs(P.row[b]/P.rules[b]-1)>.005;
  $('lungsNote').textContent=`${f>0?`When last blown, the model let ${f.toFixed(3)} L of air a second into the bore`:'The model\'s air flow is measured once it is blown'}. At ${P.dynamic} on ${etName(P.pitch)}${dialled?', at the breath set,':''} real players use ${players.toFixed(2)} L a second (`
    +(src.evidence==='measured'?`measured of ${label(S.model)} players by Bouhuys 1965`:`taken from ${src.from.map(label).join(', ')} players measured by Bouhuys 1965, since no ${label(S.model)} player was measured`)
    +`). ${P.breathing.on?`${f>0?`A breath of ${P.breathing.litres.toFixed(2)} L lasts ${(P.breathing.litres/f).toFixed(1)} s`:`When a breath of ${P.breathing.litres.toFixed(2)} L is spent`}; then the note stops, a new breath is taken in over ${Math.round(1000*P.breathing.inhale)} ms, and the note starts again from silence, as a string player's bow changes direction.`:'With breathing off, it blows one endless breath.'}`;
}
// (What players were measured doing (the state's `players`, players-ranges.mjs), on each slider: the breath the mouth's
// pressure its players blew at the pitch played, over the closing pressure as it stands; the reed's columns the published
// reeds'; the tongue, the repeats and the breath taken in their sliders' units; the pitch its players' compass.)
const kPa=v=>`${(v/1000).toFixed(1)} kPa`,msOf=v=>`${Math.round(v)} ms`,shortly=v=>String(+(+v).toPrecision(2));
const WRITTEN={pulsation:v=>`${Math.round(v/2/Math.PI)} Hz`,closing_pressure:kPa,qfactor:v=>`Q ${shortly(v)}`};
const OWN={stroke:[1000,msOf],softSeconds:[1000,msOf],rise:[1000,msOf],inhale:[1000,msOf],repeatRate:[1,v=>`${v} a second`],litres:[1,v=>`${v.toFixed(1)} L`],
  vibratoWidth:[1,v=>`${Math.round(v)} ¢`],vibratoRate:[1,v=>`${shortly(v)} Hz`]};
let pitchBand=null;
function drawPlayers(){
  const R=S.players;if(!R)return;
  pitchBand??=playersBand($('pitch'));
  const low=+$('pitch').min,high=+$('pitch').max;
  pitchBand(R.pitch,m=>(m-low)/(high-low),m=>noteName(Math.round(m)));
  const shut=S.columns.findIndex(q=>q[0]==='reed'&&q[2]==='closing_pressure'),blown=atPitch(R.breath,P.pitch);
  for(const [id,c] of Object.entries(controls)){
    if(!c.band)continue;
    const x=v=>(placeOf(c.k,v)+1)/2;
    if(c.name==='gamma')c.band(shut>=0?blown:null,p=>x(p/P.row[shut]),kPa);
    else if(c.k!==undefined)c.band(R.columns[c.name]??null,x,WRITTEN[c.name]??shortly);
    else{const [scale,written]=OWN[id]??[1,shortly];c.band(R[id]??null,v=>c.place(scale*v),v=>written(scale*v))}
  }
}
// (The fingering drawn as its players read it (fingering-diagrams.js), from what the engine holds: a woodwind's keys
// found from its holes as they stand, each drawn as far as its holes stand -- a charted fingering's as its players' guide
// writes it, a dialled one's the keys nearest it, a key that moves a hole only with others drawn faint, any hole no keys
// leave so said -- a valved instrument's valves each as far down as it is pressed, a trombone's slide at its position.
// Drawn again only where it changes.)
let drawnFor=null;
function fingered(){
  const brass=S.kind==='lips',holes=S.columns.map((c,k)=>[c,k]).filter(([c])=>c[0]==='opening');
  let svg='',note='',key;
  if(brass&&S.slide&&P.slide!=null){key=`slide ${P.slide.toFixed(4)}`;if(key===drawnFor)return;const at=positionOf(P.slide);
    svg=slideSvg(at,positionOf(S.slide.most),`Slide at position ${at.toFixed(2)}`)}
  else if(brass&&S.valves){const down=S.valves.map(([first])=>1-P.row[first]);key=`valves ${down.map(d=>d.toFixed(3))}`;if(key===drawnFor)return;
    svg=valvesSvg(down,`Valves: ${valvesName(down.map(d=>d>=.5?'1':'0').join(''))}`);
    note=down.some(d=>d>.01&&d<.99)?`Half-valved: ${down.map((d,k)=>d>.01&&d<.99?`valve ${k+1} ${Math.round(100*d)} % down`:null).filter(Boolean).join(', ')}.`:''}
  else if(!brass&&keywork(S.model)){
    const open=Object.fromEntries(holes.map(([c,k])=>[S.holes[c[1]],P.row[k]]));key=`holes ${holes.map(([,k])=>P.row[k].toFixed(3))}`;if(key===drawnFor)return;
    const f=heldFingering(S.model,open),w=keywork(S.model),faint=Object.entries(f.faint),parts=Object.entries(f.parts);
    const d=woodwindDiagram(S.model,f.keys,`Fingering${f.documented?` ${f.documented}`:''}`,{whole:true,parts:f.parts,faint:Object.fromEntries(faint.map(([key,v])=>[key,v.share]))});
    // (A hole of its body its keywork has no key for, dialled from where the rules hold it.)
    const unkeyed=holes.filter(([c,k])=>!w.holes.includes(S.holes[c[1]])&&Math.abs(P.row[k]-P.rules[k])>.005).map(([c,k])=>`${S.holes[c[1]]} at ${P.row[k].toFixed(2)}`);
    const pct=a=>`${Math.round(100*a)} %`,shown=new Set(faint.map(([,v])=>v.hole)),off=f.off.filter(h=>!shown.has(h));
    svg=d.svg;
    note=(f.documented?`${f.documented}, as the players' fingering chart gives it.`:f.off.length?'No fingering of the keys leaves the holes exactly as they are; these are the nearest keys.':'The keys for the holes as they stand; this is not a charted fingering.')
      +(parts.length?` Pressed part way: ${parts.map(([key,a])=>`${key} ${pct(a)}`).join(', ')}.`:'')
      +(faint.length?` Drawn faint: ${faint.map(([key,v])=>`${key} ${pct(v.share)} for hole ${v.hole} (${open[v.hole].toFixed(2)} open), which it only moves together with ${v.moves.join(', ')}`).join('; ')}.`:'')
      +(off.length?` Holes the drawn keys cannot leave as they are: ${off.map(h=>`${h} (${open[h].toFixed(2)} open)`).join(', ')}.`:'')
      +(d.undrawn.length?` Also pressed, but not shown on LilyPond's ${w.diagram} diagram: ${d.undrawn.join(', ')}.`:'')
      +(unkeyed.length?` Set by hand, with no key on the diagram: ${unkeyed.join(', ')}.`:'')}
  drawnFor=key;
  $('diagram').classList.toggle('brass',brass);$('diagram').innerHTML=svg??'';$('diagramNote').textContent=note;
}
// (The mute in its bell, or the one asked: its body made or taken up, then put in once the breath is let go and the
// bell has rung down.)
const MUTE_NAME={straight:'straight mute',cup:'cup mute','harmon-stem-out':'harmon, stem out','harmon-stem-in':'harmon, stem in',stopped:'stopped, the hand in the bell'};
function muteSaid(){
  if(!S.mutes?.length)return;
  const m=S.muting,name=k=>k?MUTE_NAME[k]??k:'no mute';
  if(document.activeElement!==$('mute'))$('mute').value=(m?m.mute:S.mute)??'';
  $('muteNote').textContent=m?.error?`The model with the ${name(m.mute)} could not be made: ${m.error}. It is still played with ${name(S.mute)}.`:
    m?`${name(m.mute)[0].toUpperCase()+name(m.mute).slice(1)} asked for: ${m.ready?'it goes in as soon as the breath stops and the bell has stopped ringing':`its model is being made: ${m.step} (${Math.round(m.seconds)} s so far)`}. Until then it is played with ${name(S.mute)}.`:
    S.mute?`Played with the ${name(S.mute)} in. The model treats the gap around the mute as the end of the bore, and the mute's hollow as a closed side branch.`:'Played open, without a mute.';
}
// (Where the pitch stands among the charted notes, a brass instrument's lips among its partials'.)
function said(){
  const b=P.between,partialOf=m=>{const k=S.notes.indexOf(m);return S.partials?.[k]+(S.fingerings?` (${valvesName(S.fingerings[k])})`:'')+(S.positions?` (position ${S.positions[k]})`:'')};
  if(S.kind==='lips'){
    const k=P.note??S.notes.indexOf(P.midi),none=S.unattacked?.[k]??[],a=P.attack;
    $('pitchSaid').textContent=P.lip==null?'':(P.slideDialled?'The slide was moved by itself, so the bore sets the pitch. ':'')+`Lips at ${P.lip.toFixed(1)} Hz: `+(P.lipDialled?'set by hand, so the bore decides which partial sounds':
      !b||b.share===0&&b.low===b.high?`partial ${partialOf(P.midi)}, as the lips sound it`:`${Math.round(100*b.share)} % of the way from partial ${partialOf(b.low)}'s lip frequency to partial ${partialOf(b.high)}'s; the bore decides which partial sounds`)+
      (!a?`. Started from silence at ${P.dynamic}, no attack was found that sounds it.`:a.share===1?'.':`. Started from silence: the lips start ${Math.abs(100*(1-a.share)).toFixed(0)} % ${a.share<1?'lower':'higher'} and settle after ${Math.round(1000*a.settleAfter)} ms.`)+
      (none.length?` Partial ${partialOf(P.midi)} could not be started from silence at ${none.join(', ')}.`:'')+
      (P.vibrato.on&&P.vibrato.width>0?P.vibratoHeard==null?' How far its vibrato swings the pitch has not been measured on this body.':
        P.vibratoHeard<P.vibrato.width-.05?` Its vibrato is heard ${P.vibratoHeard.toFixed(1)} cents wide, the widest this partial allows.`:'':'');
    return;
  }
  $('pitchSaid').textContent=!b?'':b.sounds==null?`${etName(P.pitch)}: the charted note, as the playing rules play it.`:
    `${b.share>0&&b.share<1?`${Math.round(100*b.share)} % of the way from the charted ${noteName(b.low)} to ${noteName(b.high)}`:`The charted ${noteName(b.share<1?b.low:b.high)}`}`+
    `${Math.abs(b.sounds-P.pitch)>.005?`; the nearest it can reach is ${etName(b.sounds)}.`:'.'}`;
}

// ---- what the page changes ----
let pitchSlow=null;
const toPitch=(pitch,charted=false,dynamic=$('dynamic').value,note=null)=>{
  // (A glide not yet measured takes a second or two, once.)
  clearTimeout(pitchSlow);pitchSlow=setTimeout(()=>{$('pitchSaid').textContent=`Measuring how the pitch bends near ${etName(pitch)} ...`},300);
  return sendPitch({pitch:Math.min(Math.max(pitch,+$('pitch').min),+$('pitch').max),dynamic,charted,...(note!=null?{note}:{})}).finally(()=>{clearTimeout(pitchSlow);if(P)said()});
};
$('pitch').oninput=()=>{$('pitchN').value=(+$('pitch').value).toFixed(2);toPitch(+$('pitch').value)};
$('pitchN').onchange=()=>toPitch(+$('pitchN').value);
$('note').onchange=()=>toPitch(S.notes[+$('note').value],true,undefined,+$('note').value);
$('dynamic').onchange=()=>{const charted=P.between?.sounds==null&&S.notes.includes(P.pitch);toPitch(P.pitch,charted,undefined,charted?P.note:null)};
$('reset').onclick=async()=>{const r=await post('/reset');r.error?say(r.error):r.pitch!==undefined&&took(r)};
// (Its neutral note again, at its dynamic -- the middle of its charted notes where none is found -- every dial the
// rules' there, its players' normal tract following the note where theirs is measured.)
$('neutral').onclick=async()=>{
  const r=await post('/neutral');if(r.error)return say(r.error);
  S=await (await fetch('/winds/state',{cache:'no-store'})).json();shown(S);if(r.pitch!==undefined)took(r);
  const k=S.neutral?S.neutral.note:Math.floor(S.notes.length/2);
  if(S.kind!=='air'&&S.tractMeasured)sendTract({follow:true});
};
for(const r of document.querySelectorAll('input[name=w-articulation]'))r.onchange=()=>sendArticulation({articulation:r.value});
$('repeating').onchange=()=>sendRepeat({on:$('repeating').checked});
$('breathing').onchange=()=>{if(S?.model&&!busy&&P?.breathing)sendBreathing({on:$('breathing').checked})};
$('vibrating').onchange=()=>sendVibrato({on:$('vibrating').checked});
$('fluttering').onchange=()=>sendFlutter({on:$('fluttering').checked});
$('humming').onchange=()=>sendHum({on:$('humming').checked});
$('growling').onchange=()=>sendGrowl({on:$('growling').checked});
$('mute').onchange=()=>{if(S?.model&&!busy)sendMute({mute:$('mute').value||null}).finally(poll)};
const blow=async()=>{if(!S?.model||busy)return;sound();const r=await post('/blow',{on:!P.blowing});r.error?say(r.error):r.pitch!==undefined&&took(r);
  // (Its breath said once it has been blown a moment.)
  if(P?.blowing){clearTimeout(polling);polling=setTimeout(poll,1000)}};
const tongueNow=async()=>{if(!P?.blowing||busy)return;const r=await post('/tongue');if(r.error)say(r.error)};
$('blow').onclick=blow;$('tongueNow').onclick=tongueNow;

// ---- the musebot player: a piece its band composes for the instrument, played on it (dial.mjs /soloist) ----
// (Its seed the page's, by default the band's own (opening-time.js DEFAULT_SEED), the most it plays, and its
// personality's levers and grammars, each drawn from its seed unless set (musebot.js); everything else in the piece the
// band's.)
$('soloSeed').value=DEFAULT_SEED;
const musebot=musebotControls({box:$('personality'),seed:$('soloSeed'),seconds:$('soloSeconds')});
$('solo').onclick=async()=>{
  if(!S?.model||busy||rendering)return;
  const on=!S.soloist?.playing;
  if(on){sound();$('soloSaid').textContent='Its band is composing the piece ...'}
  const r=await post('/soloist',on?{on,...musebot.given()}:{on});
  if(r.error){$('soloSaid').textContent=r.error;return}
  if(r.pitch!==undefined)took(r);
  if(r.soloist!==undefined){S={...S,soloist:r.soloist};soloShown(S)}
  poll();
};
// (Its piece rendered first, then heard (prerender.js): the page's own sound not pulled meanwhile, nor its shortfall
// counted, the musebot's live button held.)
let rendering=false;
const prerendered=prerenderControls({family:'winds',button:$('render'),box:$('rendered'),rate:()=>RATE,given:()=>musebot.given(),named:()=>label(S.model),
  before:()=>{rendering=true;soloShown(S)},after:()=>{rendering=false;shorts.length=0;poll()}});
// (The musebot playing, or the piece it last played: whose, its seed, how far, and what the dial did not play of it.)
const clock=x=>`${Math.floor(x/60)}:${String(Math.floor(x%60)).padStart(2,'0')}`;
function soloShown(s){
  const playing=Boolean(s.soloist?.playing)&&!rendering,said=s.soloist?.said;
  $('solo').textContent=playing?'■ Stop the musebot':'▶ A musebot plays';$('solo').classList.toggle('on',playing);$('solo').disabled=busy||rendering;
  $('render').disabled=busy&&!prerendered.running();
  musebot.show(s.player,said?.personality);
  if(!said)return;
  $('soloSaid').textContent=`${said.player} on the ${label(s.model??said.instrument)}, seed ${said.seed}: ${playing?'':'played '}${clock(Math.min(said.at,said.seconds))} of ${clock(said.seconds)}, ${said.notes} notes`
    +(said.unplayed.length?`; ${said.unplayed.length} not played here (${said.unplayed[0].why})`:'')+(said.late?`; ${said.late} came late`:'')
    +(said.refused.length?`; ${said.refused.length} refused (${said.refused.at(-1).error})`:'')
    +(said.personality?`. Its register is ${etName(said.personality.register[0])} to ${etName(said.personality.register[1])}, and its motif ${said.personality.motif}`:'')+'.';
}
$('keep').onclick=async()=>{const r=await post('/keep',{words:$('words').value});$('kept').textContent=r.kept?'kept':r.error??'';if(r.kept)$('words').value=''};

// ---- the tract and the bore's impedance ----
let tract=new VocalTract([]),MEASURED=null,impedance=null,fetchingImpedance=false;
const setTract=resonances=>{tract=new VocalTract(resonances);draw();sendTract({resonances:tract.resonances})};
$('normal').onclick=()=>sendTract({follow:true});
$('none').onclick=()=>setTract([]);
const canvas=$('plot'),F=[50,6000],Z=[1e5,3e8];
const css=name=>getComputedStyle(document.documentElement).getPropertyValue(name).trim();
// (The canvas sized only when its box changes: sizing it clears it.)
let W=0,H=0,ratio=1;
const x=f=>W*Math.log(f/F[0])/Math.log(F[1]/F[0]),y=p=>H-H*Math.log(Math.max(p,Z[0])/Z[0])/Math.log(Z[1]/Z[0]);
const fx=px=>F[0]*(F[1]/F[0])**(px/W),py=v=>Z[0]*(Z[1]/Z[0])**((H-v)/H);
new ResizeObserver(()=>{const w=canvas.clientWidth,h=canvas.clientHeight,r=devicePixelRatio||1;if(w===W&&h===H&&r===ratio)return;
  W=w;H=h;ratio=r;canvas.width=Math.round(W*ratio);canvas.height=Math.round(H*ratio);draw()}).observe(canvas);
let heard=null,lungsHeard=null;
function draw(){
  if(!W||!S?.model||!P)return;
  const g=canvas.getContext('2d');g.setTransform(ratio,0,0,ratio,0,0);g.clearRect(0,0,W,H);g.font='11px system-ui';
  if(MEASURED){
    g.fillStyle=css('--band');g.fillRect(x(MEASURED.first.f[0]),y(MEASURED.first.p[1]),x(MEASURED.first.f[1])-x(MEASURED.first.f[0]),y(MEASURED.first.p[0])-y(MEASURED.first.p[1]));
    g.fillStyle=css('--bend');g.fillRect(x(MEASURED.held),y(MEASURED.bend[1]),W-x(MEASURED.held),y(MEASURED.bend[0])-y(MEASURED.bend[1]));
  }
  g.strokeStyle=css('--line');g.fillStyle=css('--muted');g.lineWidth=1;
  for(const f of [100,200,500,1000,2000,5000]){g.beginPath();g.moveTo(x(f),0);g.lineTo(x(f),H);g.stroke();g.fillText(f>=1000?`${f/1000} kHz`:`${f} Hz`,x(f)+3,H-4)}
  for(const p of [1e6,1e7,1e8]){g.beginPath();g.moveTo(0,y(p));g.lineTo(W,y(p));g.stroke();g.fillText(`${p/1e6} MPa s/m³`,3,y(p)-3)}
  const f0=heard??hzOf(P.pitch);
  g.strokeStyle=css('--harm');for(let h=1;h*f0<F[1];h++){g.lineWidth=h===1?2:1;g.beginPath();g.moveTo(x(h*f0),0);g.lineTo(x(h*f0),H);g.stroke()}
  if(MEASURED){g.fillStyle=css('--accent');g.beginPath();g.arc(x(Math.max(MEASURED.held,f0+MEASURED.offset)),y(MEASURED.normal),3,0,7);g.fill()}
  const line=(fn,color,width,dash=[])=>{g.strokeStyle=color;g.lineWidth=width;g.setLineDash(dash);g.beginPath();for(let px=0;px<=W;px+=2){const v=fn(fx(px));px?g.lineTo(px,y(v)):g.moveTo(px,y(v))}g.stroke();g.setLineDash([])};
  const bore=impedance?.notes?.[P.midi]??impedance?.fingerings?.[P.fingering]??(P.position!=null?impedance?.positions?.[String(Math.min(7,Math.max(1,Math.round(P.position))))]:null)??impedance?.bore;
  if(bore){
    const at=f=>{const fs=impedance.freqs;let lo=0,hi=fs.length-1;if(f<=fs[0])return 0;if(f>=fs[hi])return hi;while(hi-lo>1){const m=(lo+hi)>>1;fs[m]<=f?lo=m:hi=m}return lo};
    line(f=>{const k=at(f);return Math.hypot(bore.re[k],bore.im[k])},css('--bore'),1.5);
    if(tract.resonances.length)line(f=>{const k=at(f),t=tract.impedance(f);return Math.hypot(bore.re[k]+t.re,bore.im[k]+t.im)},css('--sum'),1,[5,4]);
  }
  if(tract.resonances.length)line(f=>tract.magnitude(f),css('--accent'),2.5);
  g.fillStyle=css('--accent');
  tract.resonances.forEach(r=>{g.beginPath();g.arc(x(r.frequency),y(r.peak),7,0,7);g.fill();g.fillText(`${r.frequency.toFixed(0)} Hz, Q ${r.q.toFixed(1)}, ${(r.peak/1e6).toFixed(1)} MPa s/m³`,x(r.frequency)+10,y(r.peak)-8)});
}
// (Said once for each instrument, and again when its bore's impedance comes.)
function legend(){
  const brass=S.kind==='lips',air=S.kind==='air';
  $('legend').textContent=`Frequency (Hz) runs across; impedance (MPa s/m³) runs up. Grey: the bore's input impedance ${brass?S.slide?'at the nearest slide position':S.valves?'at the fingering the valves are in (each counted as pressed once past half way)':'(open, its one fingering)':'for the nearest charted fingering'}${impedance?'':' (being computed: a minute or two the first time)'}. `+
    (air?'The jet is driven by the mouth\'s pressure alone: the engine puts no vocal tract before it. ':`Red: the vocal tract's impedance. Dashed: the two together, which is what the ${brass?'lips meet':'reed meets'}. `)+
    'Blue lines: the pitch heard and its harmonics. '+
    (MEASURED?`Shaded, measured: the ${MEASURED.whose} first tract resonance (${MEASURED.cites.first}), and above ${MEASURED.held} Hz, the peaks they reached in bends and glissandi (${MEASURED.cites.bend}). The dot: where their tract resonance sits in normal playing, ${MEASURED.offset} Hz above the note, and never below ${MEASURED.held} Hz (${MEASURED.cites.normal}). The tract follows the note${P.tractFollows?'':' when you press its button again'}; its shape is a real tract's, and its resonances come from that shape's physics.`:
      air?'':`No ${label(S.model)} player's vocal tract has been measured yet: double-click to add a resonance.`);
}
let dragging=-1;
const near=e=>{const r=canvas.getBoundingClientRect(),px=e.clientX-r.left,pyy=e.clientY-r.top;return {px,pyy,k:tract.resonances.findIndex(q=>Math.hypot(x(q.frequency)-px,y(q.peak)-pyy)<12)}};
const tractOn=()=>S?.model&&S.kind!=='air'&&!busy;
canvas.onpointerdown=e=>{if(!tractOn())return;const {k}=near(e);if(k>=0){dragging=k;canvas.setPointerCapture(e.pointerId)}};
canvas.onpointermove=e=>{if(dragging<0)return;const {px,pyy}=near(e),r=[...tract.resonances];r[dragging]={...r[dragging],frequency:fx(Math.min(Math.max(px,0),W)),peak:py(Math.min(Math.max(pyy,0),H))};setTract(r)};
canvas.onpointerup=()=>{dragging=-1};
canvas.onwheel=e=>{if(!tractOn())return;const {k}=near(e);if(k<0)return;e.preventDefault();const r=[...tract.resonances];r[k]={...r[k],q:Math.min(Math.max(r[k].q*1.08**(-Math.sign(e.deltaY)),.5),60)};setTract(r)};
canvas.ondblclick=e=>{if(!tractOn())return;const {px,pyy,k}=near(e),r=[...tract.resonances];if(k>=0)r.splice(k,1);else r.push({frequency:fx(px),q:8,peak:py(pyy)});setTract(r)};

// ---- the sound: pulled from the engine as the page plays it, begun at the first press of Blow ----
const RATE=48000;
const RING=`class Ring extends AudioWorkletProcessor{constructor(){super();this.b=new Float32Array(${RATE*2});this.r=0;this.w=0;this.n=0;this.under=0;this.t=0;
this.port.onmessage=({data})=>{this.s=1;for(let i=0;i<data.length&&this.n<this.b.length;i++){this.b[this.w]=data[i];this.w=(this.w+1)%this.b.length;this.n++}}}
process(_,outs){const o=outs[0];for(let i=0;i<o[0].length;i++){let v=0;if(this.n>0){v=this.b[this.r];this.r=(this.r+1)%this.b.length;this.n--}else if(this.s)this.under++;for(const c of o)c[i]=v}
if(++this.t%4===0)this.port.postMessage({n:this.n,under:this.under});return true}}registerProcessor('ring',Ring);`;
// (Its shortfall counted from the first sound, said over the last five seconds; the engine's pace as the server times it.)
const AHEAD=Math.round(RATE*.12),BLOCK=2048,recent=new Float32Array(SERIES.reading),SHORT_SECONDS=5;
let started=null,context=null,pulling=false,buffered=0,under=0,pace=null;const shorts=[];
function sound(){
  if(started){if(context?.state==='suspended')context.resume();return}
  started=(async()=>{
    context=new AudioContext({sampleRate:RATE});
    await context.audioWorklet.addModule(URL.createObjectURL(new Blob([RING],{type:'text/javascript'})));
    const node=new AudioWorkletNode(context,'ring',{numberOfInputs:0,outputChannelCount:[2]});node.connect(context.destination);
    const pull=async()=>{if(pulling||buffered>=AHEAD||!active||rendering)return;pulling=true;
      try{const r=await fetch(`/winds/audio?frames=${BLOCK}`);pace=Number(r.headers.get('x-pace'))||pace;lungsHeard=r.headers.get('x-lungs');
        // (Another instrument taken up: the page follows at once.)
        if(r.headers.get('x-model')&&r.headers.get('x-version')!==String(V))poll();
        const samples=new Float32Array(await r.arrayBuffer());buffered+=samples.length;node.port.postMessage(samples);
        recent.copyWithin(0,samples.length);recent.set(samples,recent.length-samples.length)}
      // (A pull cut short -- the page leaving, or its dial gone -- tried again as the worklet next asks; the dial's own
      // state said by poll.)
      catch{return}finally{pulling=false}pull()};
    node.port.onmessage=({data})=>{buffered=data.n;under=data.under;pull()};
    pull();
  })();
}
setInterval(()=>{
  if(!active||!started||!S?.model||!P||rendering)return;
  // (Heard as its harmonic series, as the dial's tools hear it: YIN read a reed's notes a twelfth or an octave down.)
  const p=seriesPitch(recent,RATE,{silent:-90}),rms=Math.sqrt(recent.reduce((a,v)=>a+v*v,0)/recent.length);
  heard=p.hz;
  // (Blown and nothing heard: its model does not sound the note there.)
  $('heard').textContent=heard?`${heard.toFixed(1)} Hz = ${etName(69+12*Math.log2(heard/440))}, ${(1200*Math.log2(heard/hzOf(P.pitch))).toFixed(0)} cents from the pitch asked for`:
    P.blowing&&pace!=null&&!(rms>1e-5)?`Blown, but no tone: the ${label(S.model)}'s model does not sound this note with these settings`:'--';
  const db=rms>0?20*Math.log10(rms):-Infinity;
  $('level').textContent=db>-120?`${db.toFixed(1)} dBFS`:'silent';$('meter').style.width=`${Math.max(0,Math.min(100,(db+60)/60*100))}%`;
  // (The air left in its breath, as the dial last said it.)
  if(lungsHeard&&P.breathing){const [air,taking]=lungsHeard.split(' ').map(Number),share=Math.max(0,Math.min(1,air/P.breathing.litres));
    $('air').style.width=`${100*share}%`;$('airN').textContent=taking?'breathing in':!P.breathing.on?'unbreathing':`${Math.max(0,air).toFixed(2)} L`}
  const now=performance.now()/1000;shorts.push([now,under]);while(shorts[0][0]<now-SHORT_SECONDS)shorts.shift();
  const short=(under-shorts[0][1])/RATE*1000;
  $('engine').textContent=`${pace?`computing at ${Math.round(100*pace)} % of real time`:'--'}${S.threads>1?` on ${S.threads} cores`:''}; ${(buffered/RATE*1000).toFixed(0)} ms of sound buffered${short>0?`; ${short.toFixed(0)} ms missing in the last ${SHORT_SECONDS} s`:''}`;
  draw();
},150);

// ---- its settings as a file (live.html, dial-settings.js): what the dial says it is set to, and a file's made on it ----
// (-> {model, settings, words, heard}: the words written to keep it and what the page hears now with them; its musebot's
// as set on the page, what a piece is asked with, as the strings' are (musebot.js given).)
export async function settings(){
  const r=await fetch('/winds/settings',{cache:'no-store'}),got=await r.json();
  if(!r.ok)throw new Error(got.error);
  return {model:got.model,settings:{...got,player:musebot.given(got.player)},words:$('words').value,
    heard:{hz:heard,level:$('level').textContent,heardAs:$('heard').textContent,blowing:Boolean(P?.blowing),pace,threads:S?.threads??null}};
}
// (Whether `model` is taken up, waiting up to `wait` seconds while the dial makes it: the page's controls built for it,
// the dial no longer making or muting it.)
export async function taken(model,{wait=120}={}){
  const ready=()=>S?.model===model&&!busy&&!S.loading&&!S.muting&&V===S.version;
  for(let k=0;k<wait*4&&!ready();k++)await new Promise(go=>setTimeout(go,250));
  return ready();
}
// (A file's settings made on its instrument, once the page has taken it up and the dial is not making it: -> what was
// made and what refused.)
export async function load(file,{wait=120}={}){
  if(!await taken(file.model,{wait}))throw new Error(`the ${label(file.model)} was not taken up`);
  const r=await post('/settings',{settings:file.settings});
  if(r.error)throw new Error(r.error);
  if(r.pitch!==undefined)await took(r);
  if(file.words)$('words').value=file.words;
  if(r.player)S={...S,player:r.player};
  poll();return r.loaded;
}

// ---- the page's hold on it: taken up, put to rest, its keys ----
// (A wind taken up: the dial asked for it where it plays another and is not already making it, then followed as it
// makes it. One already played is left as it was dialled; one made, taken up fresh (takenFresh).)
let fresh=null;
export const takenFresh=model=>fresh===model;
export async function take(model,{status:el}){
  status=el;active=true;
  // (A piece being rendered first stopped where another instrument is taken up: its piece one instrument's.)
  if(S?.model!==model)await prerendered.stop();
  if(started&&context?.state==='suspended')context.resume();
  if(S?.model===model&&what)document.getElementById('what').textContent=what;
  let s;try{s=await (await fetch('/winds/state',{cache:'no-store'})).json()}catch(error){el.classList.add('failed');el.textContent=`The winds' dial did not answer: ${error.message}`;return}
  if(s.model!==model)fresh=model;
  if(s.model!==model&&(s.loading?.model??s.wanted)!==model){
    const r=await (await fetch('/winds/instrument',{method:'POST',body:JSON.stringify({model})})).json();
    if(r.error)say(r.error);
  }
  poll();
}
// (Another family chosen: the breath let go, the sound no longer pulled, the dial no longer asked.)
export function rest(){
  if(!active)return;
  prerendered.stop();
  if(P?.blowing&&!busy)post('/blow',{on:false}).then(r=>{if(r.pitch!==undefined)P=r});
  active=false;clearTimeout(polling);
  if(context?.state==='running')context.suspend();
}
export function keys(e){
  if(['INPUT','SELECT','TEXTAREA'].includes(e.target.tagName)&&!['range','radio','checkbox'].includes(e.target.type))return;
  if(e.code==='Space'){e.preventDefault();blow()}else if(e.key==='t')tongueNow();
}
