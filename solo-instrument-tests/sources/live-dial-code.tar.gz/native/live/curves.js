// The live dial's drawn curves (live.html): any quantity a player holds drawn over time, of its kind
// (public/shared/performers/drawn-curves.js) -- a note's attack (attack-curves.js ATTACK) the first. Press anywhere on
// the plot to put a point there and drag it; drag a point; double-click a point, or select it and press Delete, to take
// it away; the arrow keys move the one selected (shift: ten times as far). Under the plot, the point selected as numbers
// -- its time, its value, the shape of the segment that reaches it (eased, or straight where its kind allows) -- with a
// point added or taken away there too. Each change said at once (`change`), its points as drawn-curves.js has them.
//   curveEditor(box, {kind, label, color, change, unit, meaning})
//     kind     the curve's kind (drawn-curves.js): its reach, its fixed ends, its shapes, its most points
//     unit     how its values are written ('×': multiples), and meaning(y) what one stands for, said beside it
//   -> {set(points), get(), dragging()}
import {curveAt,curveOf,fewestOf,peakOf} from '/public/shared/performers/drawn-curves.js';

const SVG='http://www.w3.org/2000/svg';
const make=(name,attrs={},parent)=>{const el=document.createElementNS(SVG,name);for(const [k,v] of Object.entries(attrs))el.setAttribute(k,v);parent?.append(el);return el};
const html=(name,attrs={},parent)=>{const el=document.createElement(name);for(const [k,v] of Object.entries(attrs))el[k]=v;parent?.append(el);return el};
// (The plot's size, in its own units: its width the page's, its height fixed.)
const W=640,H=180,PAD={left:46,right:12,top:12,bottom:24};
// (Ticks a readable step apart over [low, high].)
const stepOver=(span,most)=>[.001,.002,.005,.01,.02,.05,.1,.2,.5,1,2,5,10,20,50,100].find(s=>span/s<=most)??span/most;
const ms=t=>`${Math.round(1000*t)} ms`;

export function curveEditor(box,{kind,label,color='var(--accent)',change,unit='×',meaning=null}){
  const fewest=fewestOf(kind),longest=Math.min(kind.longest??2,60);
  const svg=make('svg',{viewBox:`0 0 ${W} ${H}`,class:'curve',role:'img',tabindex:'0','aria-label':label},box);
  const grid=make('g',{},svg),settled=make('line',{class:'settled'},svg),path=make('path',{class:'line',fill:'none',stroke:color},svg);
  const dots=make('g',{},svg),tip=make('text',{class:'tip',x:W-PAD.right,y:PAD.top+10,'text-anchor':'end'},svg);
  // (The point selected, as numbers.)
  const tools=html('div',{className:'curveTools'},box);
  const which=html('span',{className:'muted'},tools);
  const tBox=html('input',{type:'number',step:'1',min:'0',title:'its time (ms)'},tools),tUnit=html('span',{textContent:'ms',className:'muted'},tools);
  const yBox=html('input',{type:'number',step:'0.01',title:'its value'},tools),yUnit=html('span',{textContent:unit,className:'muted'},tools);
  const shapeBox=html('select',{title:'the segment that reaches it'},tools);
  shapeBox.innerHTML='<option value="eased">eased into it</option><option value="straight">straight into it</option>';
  const remove=html('button',{type:'button',textContent:'− Remove it'},tools),add=html('button',{type:'button',textContent:'+ Add a point'},tools);
  const count=html('span',{className:'muted'},tools);
  let points=curveOf(kind.from!=null?[[0,kind.from],[.05,kind.settled??kind.from]]:[[0,kind.settled??kind.least]],kind);
  let span=.2,low=kind.least,top=kind.settled!=null?2*kind.settled:kind.most,dragging=-1,selected=-1;
  // (Its axes: time to well past where it settles, room to put a point after it; its values over their peak, from the
  // least its kind reaches.)
  const X=t=>PAD.left+(W-PAD.left-PAD.right)*t/span,Y=y=>H-PAD.bottom-(H-PAD.top-PAD.bottom)*(y-low)/(top-low);
  const tOf=px=>(px-PAD.left)/(W-PAD.left-PAD.right)*span,yOf=py=>low+(H-PAD.bottom-py)/(H-PAD.top-PAD.bottom)*(top-low);
  const fit=()=>{
    span=Math.min(longest*1.1,Math.max(.1,1.6*points.at(-1)[0]));
    const peak=peakOf(points)[1];
    top=Number.isFinite(kind.most)?Math.min(kind.most,Math.max(kind.settled!=null?2*kind.settled:kind.least+1,1.15*peak)):Math.max(1,1.15*peak);
  };
  const where=e=>{const r=svg.getBoundingClientRect();return [(e.clientX-r.left)*W/r.width,(e.clientY-r.top)*H/r.height]};
  const fixedT=k=>k===0,fixedY=k=>k===0&&kind.from!=null||k===points.length-1&&points.length>1&&kind.settled!=null;
  function draw(){
    grid.replaceChildren();
    const ts=stepOver(span,8);
    for(let t=0;t<=span+1e-9;t+=ts){make('line',{x1:X(t),x2:X(t),y1:PAD.top,y2:H-PAD.bottom,class:'grid'},grid);make('text',{x:X(t),y:H-6,'text-anchor':'middle'},grid).textContent=ms(t)}
    const ys=stepOver(top-low,5);
    for(let y=Math.ceil(low/ys)*ys;y<=top+1e-9;y+=ys){make('line',{x1:PAD.left,x2:W-PAD.right,y1:Y(y),y2:Y(y),class:'grid'},grid);make('text',{x:PAD.left-6,y:Y(y)+4,'text-anchor':'end'},grid).textContent=`${+y.toFixed(3)}${unit}`}
    if(kind.settled!=null)Object.entries({x1:PAD.left,x2:W-PAD.right,y1:Y(kind.settled),y2:Y(kind.settled)}).forEach(([k,v])=>settled.setAttribute(k,v));
    // (The curve as it is played: its eased segments followed closely, its straight ones as they are.)
    let d=`M${X(0)},${Y(points[0][1])}`;
    for(let k=1;k<points.length;k++){const [a]=points[k-1],[b]=points[k];for(let i=1;i<=24;i++){const t=a+(b-a)*i/24;d+=`L${X(t)},${Y(curveAt(points,t))}`}}
    d+=`L${X(span)},${Y(points.at(-1)[1])}`;path.setAttribute('d',d);
    dots.replaceChildren();
    points.forEach(([t,y],k)=>{const dot=make('circle',{cx:X(t),cy:Y(y),r:k===selected?8:6,fill:color,class:k===selected?'dot selected':'dot'},dots);dot.dataset.point=k;
      make('title',{},dot).textContent=`${ms(t)}, ${y.toFixed(2)}${unit}`+(k===0&&kind.from!=null?' (from rest)':k===points.length-1&&kind.settled!=null?' (settled)':'')});
    const [pt,py]=peakOf(points);
    tip.textContent=`peak ${py.toFixed(2)}${unit}${meaning?` (${meaning(py)})`:''} at ${ms(pt)} · settled at ${ms(points.at(-1)[0])}`;
    shown();
  }
  // (The point selected, its numbers, and what may be done there.)
  function shown(){
    const k=selected,on=k>=0&&k<points.length;
    which.textContent=on?`Point ${k+1} of ${points.length}:`:`${points.length} points: press on the plot to add one, or select one to set it.`;
    for(const el of [tBox,tUnit,yBox,yUnit,remove])el.style.display=on?'':'none';
    shapeBox.style.display=on&&kind.straight?'':'none';
    if(on){const [t,y,shape]=points[k];
      if(document.activeElement!==tBox)tBox.value=Math.round(1000*t);if(document.activeElement!==yBox)yBox.value=+y.toFixed(3);
      tBox.disabled=fixedT(k);yBox.disabled=fixedY(k);
      shapeBox.value=shape==='straight'?'straight':'eased';shapeBox.disabled=k===0||!kind.straight;
      remove.disabled=k===0||points.length<=fewest;}
    add.disabled=points.length>=(kind.points??64);
    count.textContent=`${points.length} of at most ${kind.points??64}`;
  }
  const changed=()=>{draw();change?.(points.map(p=>[...p]))};
  // (A point placed: its time between its neighbours', a millisecond from each; its value within its kind's reach, where
  // it is free.)
  function place(k,t,y){
    const last=points.length-1;
    if(fixedT(k))t=0;else t=Math.min(k<last?points[k+1][0]-.001:longest,Math.max(points[k-1][0]+.001,t));
    y=fixedY(k)?points[k][1]:Math.min(kind.most,Math.max(kind.least,y));
    points[k]=[+t.toFixed(4),+y.toFixed(3),...points[k].slice(2)];
  }
  // (A point put at `t`, `y`: between two, there; past the last, there too, and where its kind settles, the curve settled
  // after it as long again. -> its index, or -1.)
  function added(t,y){
    if(points.length>=(kind.points??64)||!(t>0&&t<longest))return -1;
    y=Math.min(kind.most,Math.max(kind.least,y));
    const at=points.findIndex(p=>p[0]>t);
    if(at>0){if(t-points[at-1][0]<.001||points[at][0]-t<.001)return -1;points.splice(at,0,[+t.toFixed(4),+y.toFixed(3)]);return at}
    if(t-points.at(-1)[0]<.001)return -1;
    if(kind.settled!=null){
      if(points.length+1>=(kind.points??64))return -1;
      const end=Math.min(longest,t+Math.max(.02,t-points.at(-1)[0]));if(end-t<.001)return -1;
      points.push([+t.toFixed(4),+y.toFixed(3)],[+end.toFixed(4),kind.settled]);return points.length-2;
    }
    points.push([+t.toFixed(4),+y.toFixed(3)]);return points.length-1;
  }
  function removed(k){
    if(k<=0||points.length<=fewest)return;
    points.splice(k,1);points=curveOf(points,kind);selected=Math.min(k,points.length-1);fit();changed();
  }
  // (A point pressed twice within DOUBLE ms is taken away: its dot is drawn again between the two presses, so the browser's
  // own double-click never falls on one.)
  const DOUBLE=400;let pressed={k:-1,at:0};
  svg.onpointerdown=e=>{
    if(e.button!==0)return;
    const k=e.target.dataset?.point;
    if(k!=null&&pressed.k===+k&&e.timeStamp-pressed.at<DOUBLE){pressed={k:-1,at:0};removed(+k);e.preventDefault();return}
    pressed={k:k!=null?+k:-1,at:e.timeStamp};
    if(k!=null){dragging=selected=+k}
    else{const [px,py]=where(e),at=added(tOf(px),yOf(py));if(at<0)return;dragging=selected=at;changed()}
    svg.setPointerCapture(e.pointerId);svg.focus();draw();e.preventDefault();
  };
  svg.onpointermove=e=>{if(dragging<0)return;const [px,py]=where(e);place(dragging,tOf(px),yOf(py));changed()};
  svg.onpointerup=svg.onpointercancel=()=>{if(dragging>=0){dragging=-1;fit();draw()}};
  svg.onkeydown=e=>{
    if(selected<0)return;
    if(e.key==='Delete'||e.key==='Backspace'){removed(selected);e.preventDefault();return}
    const step=e.shiftKey?10:1,moves={ArrowLeft:[-.001,0],ArrowRight:[.001,0],ArrowUp:[0,.01],ArrowDown:[0,-.01]}[e.key];
    if(!moves)return;e.preventDefault();
    place(selected,points[selected][0]+step*moves[0],points[selected][1]+step*moves[1]);fit();changed();
  };
  tBox.onchange=()=>{const v=+tBox.value;if(Number.isFinite(v)&&selected>0){place(selected,v/1000,points[selected][1]);fit();changed()}else shown()};
  yBox.onchange=()=>{const v=+yBox.value;if(Number.isFinite(v)&&selected>=0){place(selected,points[selected][0],v);fit();changed()}else shown()};
  shapeBox.onchange=()=>{if(selected<1)return;const [t,y]=points[selected];points[selected]=shapeBox.value==='straight'?[t,y,'straight']:[t,y];changed()};
  remove.onclick=()=>removed(selected);
  // (A point added in the longest segment's middle, on the curve.)
  add.onclick=()=>{
    let k=1;for(let i=2;i<points.length;i++)if(points[i][0]-points[i-1][0]>points[k][0]-points[k-1][0])k=i;
    const t=points.length>1?(points[k-1][0]+points[k][0])/2:Math.min(longest/2,.05),at=added(t,curveAt(points,t));
    if(at>=0){selected=at;fit();changed()}
  };
  fit();draw();
  return {
    // (Set from outside -- a preset, a kept setting, a dial moving its time, the dial's answer -- without saying it back,
    // and never under the pointer dragging it.)
    set(given){if(dragging>=0)return;points=curveOf(given,kind);if(selected>=points.length)selected=points.length-1;fit();draw()},
    get:()=>points.map(p=>[...p]),
    dragging:()=>dragging>=0,
  };
}
