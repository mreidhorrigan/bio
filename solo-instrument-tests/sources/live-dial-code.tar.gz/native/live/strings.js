// The bowed strings on the live dial (live.html): Artifastring played by its host through the Mac's audio, or a page's
// (native/strings-model/live.mjs, its routes here under /strings/), every dial its page had -- the player's hands, bow,
// strokes, vibrato, pluck and noise; the instrument's variant, seed, body and strings; Artifastring's friction, losses and
// constants -- each under the heading it belongs to. Each instrument taken up on its neutral note, one it sounds (the
// owner, 1 November 2026: "a safe starting point"), where the neutral-note fit mapped it (neutral()); on another, its good
// note -- the same bowing as the violin's started note at the same place on Schelleng's diagram (good()). Each stroke's
// attack drawn: its bow's force and speed over its start (attack-curves.js, curves.js).
import {LONGEST,attackKind,bowedAttack,peakOf,segmentLasting} from '/public/shared/performers/attack-curves.js';
import {curveEditor} from '/curves.js';
import {playersBand} from '/players.js';
import {DEFAULT_SEED} from '/public/shared/opening-time.js';
import {musebotControls} from '/musebot.js';
import {prerenderControls} from '/prerender.js';

const $=id=>document.getElementById(`s-${id}`);
const NAMES=['C','C♯','D','E♭','E','F','F♯','G','A♭','A','B♭','B'];
const name=midi=>{const n=Math.round(midi),c=Math.round(100*(midi-n));return `${NAMES[((n%12)+12)%12]}${Math.floor(n/12)-1}${c?` ${c>0?'+':''}${c} ¢`:''}`};
const midiOf=f=>69+12*Math.log2(f/440);
let state,s=0,bowing=false,bridge=false,direction=1,builds=[],INSTRUMENT_OF=[];
const value={},setters={},notes={};
// (A dial: a slider over a log scale where its quantity is one, and a box for any value inside its bounds, in `box`.)
function dial(box,id,label,{min,max,log,value:start,step='any',onchange,note}){
  // (A dial's ids its own: one taken already would wire it to another control.)
  for(const taken of [id,`${id}N`,`${id}Note`])if($(taken))throw new Error(`dial ${id}: the id s-${taken} is taken`);
  const row=document.createElement('div');row.className='row';
  row.innerHTML=`<label for="s-${id}"></label><input type="range" id="s-${id}" step="any"><input type="number" id="s-${id}N" step="${step}">`;
  row.querySelector('label').textContent=label;$(box).append(row);
  if(note!==undefined){const n=document.createElement('div');n.className='note';n.id=`s-${id}Note`;n.textContent=note;$(box).append(n);notes[id]=n}
  const range=$(id),number=$(id+'N'),to=v=>log?Math.log(v):v,from=x=>log?Math.exp(x):x;
  const bounds=(lo,hi)=>{range.min=to(lo);range.max=to(hi);min=lo;max=hi;range.value=to(Math.min(max,Math.max(min,value[id])))};
  const set=(v,quiet)=>{value[id]=v;range.value=to(Math.min(max,Math.max(min,v)));number.value=+(+v).toPrecision(4);if(!quiet)onchange?.()};
  range.min=to(min);range.max=to(max);
  range.oninput=()=>set(from(+range.value));
  number.onchange=()=>{const v=+number.value;if(Number.isFinite(v)&&(!log||v>0))set(v);else number.value=value[id]};
  set(start,true);setters[id]=Object.assign(set,{bounds,place:v=>(to(v)-range.min)/(range.max-range.min)});
}
async function ask(asks){
  if(!asks.length)return;
  const r=await fetch('/strings/set',{method:'POST',body:JSON.stringify({asks})});
  $('said').textContent=r.ok?'':`The model refused a setting: ${await r.text()}`;
}
// (The settings a moving dial asks, at most once a frame each: the host moves to each over the least its kind may take.)
const pending=new Map();
function later(key,build){
  if(!pending.size)requestAnimationFrame(()=>{const asks=[...pending.values()].flatMap(b=>b());pending.clear();ask(asks)});
  pending.set(key,build);
}
const finger=()=>1-2**(-value.pitch/12);
const pos=()=>value.beta*(1-finger());
const alternating=()=>$('alternate').checked;
const fingerAsk=()=>({do:'finger',string:s,finger:finger(),firmness:value.firmness});
const dampingAsk=()=>({do:'damping',string:s,ratio:value.damping});
const bowAsk=()=>({do:'bow',string:s,pos:pos(),force:value.force,vel:direction*value.speed});
const strokeAsk=()=>({do:'stroke',string:s,pos:pos(),force:value.force,vel:direction*value.speed,acc:value.speed/value.start});
const alternateAsk=()=>({do:'alternate',string:s,stroke:alternating()?value.stroke/100:0,end:value.end,start:value.start});
const vibratoAsk=(string=s)=>({do:'vibrato',string,width:$('vibrating').checked?value.width:0,rate:value.rate});
const buildAsk=(string=s)=>({do:'build',string,...builds[string]});
const radiateAsk=()=>({do:'radiate',corner:$('radiating').checked?value.corner:0,order:+$('falling').value});
const correctAsk=()=>({do:'correct',on:$('correcting').checked});
// (Where the radiation's fall starts: under a corrected body, where the correction's own cut stops (fitted, the server's
// correctedRadiation); else the body's lowest air mode.)
// (Its sound's one scale, the volume dial's 0 dB: its neutral note at broadcast loudness; one without, the started note
// there and the instrument as much louder or softer as its renders' one scale is than the started one's (gainOf).)
const heardDb=()=>state.neutralDb??state.gainDb+state.rendersDb-state.startedRendersDb;
const cornerFor=corrected=>corrected&&state.correctedRadiation?state.correctedRadiation.hz:state.airMode.hz;
const hairAsk=(string=s)=>({do:'hair',string,width:value.hair/1000});
// (The player's noise (the server's state.noise, physical-strings.js PLAYER_NOISE): the player's temperature and each
// kind's under it, multiplied as the engine is given them; each kind's size at 1 said beside it.)
const NOISE_KINDS=[['force','Bow force (× a player\'s)',sd=>`At 1, it wavers by ${+(100*sd).toPrecision(2)} % of the force set.`],['speed','Bow speed (× a player\'s)',sd=>`At 1, it wavers by ${+(100*sd).toPrecision(2)} % of the speed set.`],
  ['contact',"Bow's place (× a player's)",sd=>`At 1, it wavers by ${+(1000*sd).toPrecision(2)} thousandths of the string's length.`],['finger',"Finger's pitch (× a player's)",sd=>`At 1, it wavers by ${sd} cents.`]];
const noiseId=kind=>`noise${kind[0].toUpperCase()}${kind.slice(1)}`;
const noiseAsks=()=>NOISE_KINDS.map(([kind])=>({do:'noise',what:kind,temperature:value.noisePlayer*value[noiseId(kind)]}));
const noiseAt=(player,kinds={})=>{setters.noisePlayer(player,true);for(const [kind] of NOISE_KINDS)setters[noiseId(kind)](kinds[kind]??1,true)};
// (The string's build: what the instrument is -- its tension, length, diameter, density and stiffness -- under
// Instrument; its friction curve, its modes' losses and how many modes resolve it under Physics.)
const BUILD=[['T','Tension (N)','build'],['L','Length (m)','build'],['d','Diameter (m)','build'],['pl','Linear density (kg/m)','build'],['E',"Young's modulus (Pa)",'build'],
  ['mus','Static friction μs (no unit)','buildPhysics'],['mud','Dynamic friction μd (no unit)','buildPhysics'],['v0','Friction curve slope v0 (m/s)','buildPhysics'],
  ['loss',"Losses (× Artifastring's)",'buildPhysics'],['slope','Losses tilt (exponent: mode n\'s losses × n^tilt)','buildPhysics'],['modes','Modes (at most, count)','buildPhysics']];
const ownBuild=k=>({T:k.T,L:k.L,d:k.d,pl:k.pl,E:k.E,mus:k.mus,mud:k.mud,v0:k.v0,loss:1,slope:0,modes:k.N});
// (The strings as the page starts them: each Artifastring's own, given as many modes as its rate holds, so that the bow's
// hair is resolved as finely as it can be.)
const startBuild=k=>({...ownBuild(k),modes:state.mostModes});
// (The modes each string has in use, the cells its hair bows it with and the narrowest its modes hold apart, as the host
// says them: the server's, then each as it changes.)
let inUse={modes:[],points:[],cellMm:[]};
const openHz=k=>Math.sqrt(k.T/k.pl)/(2*k.L);
function way(){$('way').textContent=bowing?direction>0?'↓ down-bow':'↑ up-bow':''}
function read(){
  const k=builds[s];if(!k)return;
  const f0=openHz(k),length=k.L*(1-finger()),Z=Math.sqrt(k.T*k.pl),v=value.speed,b=value.beta,F=value.force;
  // (Schelleng's greatest force for Helmholtz motion, 2 Z v / (beta (mu_s - mu_d)); the Helmholtz corner's force on the
  // bridge, 2 Z v / beta, Cremer's -- the loudness the stroke asks.)
  const most=2*Z*v/(b*(k.mus-k.mud)),corner=2*Z*v/b;
  notes.pitch.textContent=`${name(midiOf(f0)+value.pitch)}. The finger is ${(100*finger()).toFixed(1)} % of the string's length from the nut.`;
  notes.beta.textContent=`${(1000*b*length).toFixed(1)} mm from the bridge, on ${(1000*length).toFixed(0)} mm of sounding string. Smaller is nearer the bridge (sul ponticello); larger is nearer the fingerboard (sul tasto).`;
  notes.stroke.textContent=`${(value.stroke/state.bow.length).toFixed(0)} % of a ${(100*state.bow.length).toFixed(0)} cm bow. At this speed a stroke lasts about ${(value.stroke/100/value.speed).toFixed(2)} s.`;
  const rows=[['The force most for a clean (Helmholtz) tone',k.mus>k.mud?`${most.toFixed(2)} N — you are at ${(100*F/most).toFixed(0)} % of it`:'none: μs is not over μd'],
    ['Helmholtz force on the bridge, 2Zv/β',`${corner.toFixed(2)} N (${(20*Math.log10(corner)).toFixed(1)} dB re 1 N): what loudness the stroke asks`],
    ['Speed over contact point, v/β',`${(v/b).toFixed(2)} m/s`],['This string',`open ${name(midiOf(f0))} (${f0.toFixed(1)} Hz), impedance Z ${Z.toFixed(3)} kg/s`]];
  $('reading').innerHTML=rows.map(([a,b])=>`<tr><td>${a}</td><td>${b}</td></tr>`).join('');
  attackSaid();
}
function strings(){
  $('strings').innerHTML=builds.map((k,i)=>`<label><input type="radio" name="s-string" value="${i}"${i===s?' checked':''}> ${name(midiOf(openHz(k)))} string</label>`).join('');
  for(const r of document.querySelectorAll('input[name=s-string]'))r.onchange=()=>cross(+r.value);
}
// (A crossing: the bow leaves one string as it reaches the next, the hand moved to the new one, its build shown.)
function cross(next){
  const was=s;if(next===was)return;
  const asks=[{do:'vibrato',string:was,width:0,rate:value.rate},...bowing?[{do:'lift',string:was,pos:pos(),vel:direction*value.speed}]:[]];
  s=next;limits();showBuild();
  asks.push(fingerAsk(),dampingAsk(),vibratoAsk(),hairAsk());
  if(bowing)asks.push(alternateAsk(),strokeAsk());
  ask(asks);read();hairNote();
}
// (The physical limits, each on or off. The fingerboard's end: the pitch over the open string at most where the string
// meets the fingerboard's end (string-bodies.js, a luthier's measurements); off, to the compass's top on any string. The
// bow hair's width: the ribbon's middle no nearer the bridge than half its width; off, from the robot grid's nearest
// (0.02). A value past a limit switched on is brought back to it.)
const fingerboard=()=>$('limitFingerboard').checked,hairLimited=()=>$('limitHair').checked;
function limits(){
  const top=fingerboard()?state.fingerboard:Math.max(state.fingerboard,state.range.range[1]-midiOf(openHz(builds[s])));
  setters.pitch.bounds(0,top);if(value.pitch>top)setters.pitch(top,true);
  const length=builds[s].L*(1-finger()),nearest=Math.min(.5,hairLimited()?Math.max(.02,value.hair/2000/length):.02);
  setters.beta.bounds(nearest,.5);if(value.beta<nearest)setters.beta(nearest,true);
  hairNote();drawPlayers();
  $('fingerboardLimit').textContent=`up to ${state.fingerboard.toFixed(1)} semitones above the open string, where the ${state.name}'s fingerboard ends (measured by Goldblatt)`;
  $('hairLimit').textContent=`the middle of the bow hair stays at least ${(value.hair/2).toFixed(1)} mm from the bridge (half the hair on the string). A violin bow's hair is about ${(1000*state.bow.hairWidth).toFixed(0)} mm wide (Schoonderwaldt, Guettler & Askenfelt 2003)${state.instrument==='violin'?'':`; no measurement found for the ${state.name}'s`}`;
}
// (What players were measured doing (the state's `players`, players-ranges.mjs), on each dial but the volume: the pitch
// its players' compass from the string's open pitch, the contact point and force as violinists and violists bowed,
// the finger's damping a fingertip's, its vibrato its players'.)
const bands={};
function drawPlayers(){
  const R=state.players;if(!R)return;
  const open=midiOf(openHz(builds[s])),shortly=v=>String(+(+v).toPrecision(2));
  const WRITTEN={pitch:v=>name(Math.round(open+v)),force:v=>`${shortly(v)} N`,width:v=>`${Math.round(v)} cents`,rate:v=>`${shortly(v)} Hz`,damping:v=>`${shortly(v)}× a fingertip's`,beta:v=>`${shortly(v)} of the string`};
  for(const [id,set] of Object.entries(setters)){
    if(id==='volume')continue;
    const entry=id==='pitch'&&R.pitch?{...R.pitch,range:R.pitch.range.map(m=>m-open)}:R[id]??null;
    (bands[id]??=playersBand($(id)))(entry,set.place,WRITTEN[id]??shortly);
  }
}
// (What the hair bows the string with: its width cut into cells no finer than its modes hold apart, each its share of
// the force spread over it.)
function hairNote(){
  const modes=inUse.modes[s]??state.strings[s].N,cells=inUse.points[s]??0,cell=inUse.cellMm[s];
  notes.hair.textContent=value.hair>0&&cells>0?`The hair is computed as ${cells>1?`${cells} strips of ${(value.hair/cells).toFixed(1)} mm`:`one strip of ${value.hair.toFixed(1)} mm`}, each sticking and slipping on its own. With ${modes} modes, strips can be no narrower than ${Number.isFinite(cell)?cell.toFixed(1):'?'} mm (more modes allow narrower strips). Less than the full ${(1000*state.bow.hairWidth).toFixed(0)} mm means the bow is tilted.`
    :"At 0, Artifastring's bow touching at a single point.";
  notes.modes.textContent=`${modes} in use: as many as asked for, up to what the sample rate allows (Artifastring's own is ${state.strings[s].N}). More modes compute the bow's hair more finely, and take more processing.`;
}
function bodyNote(){
  const c=state.correctedRadiation;
  const b=state.bodyScaled;
  $('bodyNote').textContent=(b?`The body is Artifastring's ${b.from} body scaled to the ${state.name}'s size, with every resonance ${b.ratio} times lower (the ratio of the two instruments' lowest air resonances). This stands in until a measured bass body is fitted. `:'')
    +`Corrected: Artifastring's ${b?b.from:state.name} bodies lose their high frequencies like a low-pass filter; the renders' own filter${b?', scaled the same way,':''} restores the instrument's measured radiation. `
    +`Radiating: a real body makes no sound at 0 Hz, so the bow's drag, building up as a stroke starts, is not heard as a low thump. `
    +`Lowest air resonance (A0): ${state.airMode.hz} Hz, ${state.airMode.source}.`
    +(c?` When corrected, the roll-off starts at ${c.hz} Hz, where the correction's own cut ends`+(c.scaled?` (the ${b.from}'s, scaled).`:` (within ${c.offDb} dB of the radiation below A0, compared with ${c.unradiatedOffDb} dB without it).`):'');
}
function showBuild(){
  const own=state.strings[s];
  for(const [key] of BUILD){if(!['loss','slope','modes'].includes(key))setters[key].bounds(own[key]/10,own[key]*10);setters[key](builds[s][key],true)}
}
function play(){bowing=!bowing;$('play').classList.toggle('on',bowing);$('play').textContent=bowing?'■ Stop':'▶ Play';
  way();return ask(bowing?[alternateAsk(),strokeAsk()]:[{do:'stop'}])}
function reverse(){direction=-direction;way();if(bowing)ask([{...alternateAsk(),stroke:0},strokeAsk(),alternateAsk()])}
let arrived=null;
async function instrument(type,variant){
  if(bowing)play();
  const got=new Promise(done=>{arrived={left:4,done}});
  await ask([{do:'stop'},{do:'instrument',type,variant}]);
  await got;
  state=await (await fetch('/strings/state',{cache:'no-store'})).json();
  builds=state.strings.map(startBuild);s=Math.min(s,builds.length-1);inUse=state.inUse;
  variants();strings();limits();showBuild();
  $('vibratoNote').textContent=`measured on ${state.name} players: ${state.vibrato.width} cents wide at ${state.vibrato.rate} Hz`;
  // (A body changed, its lowest air mode with it.)
  setters.corner(cornerFor($('correcting').checked),true);bodyNote();
  await ask([fingerAsk(),dampingAsk(),radiateAsk(),...builds.map((_,i)=>buildAsk(i)),hairAsk()]);read();describe();
}
function variants(){
  const n=state.variants[state.instrument];
  $('variant').innerHTML=Array.from({length:n},(_,i)=>`<option value="${i}"${i===state.variant?' selected':''}>no. ${i}</option>`).join('');
  $('variants').textContent=`of ${n}`;
}
function describe(){document.getElementById('what').textContent=`The ${state.name}, modelled by Artifastring and heard through ${state.heardThrough}: ${state.bodyScaled?`the ${state.bodyScaled.from}'s body`:'Artifastring\'s'} no. ${state.variant}, seed ${state.seed}. `+(state.neutral?`It starts on its neutral note, from ${state.neutral.map.split('/').pop()}.`:`It starts on a good note made from ${state.from.split('/').pop()}.`)}
async function init(status){
  // (The host just started: its rate, its constants and its four strings said before anything is dialled -- a minute
  // allowed, macOS some seconds letting a host built just before run for the first time.)
  for(const until=performance.now()+60e3;;){
    state=await (await fetch('/strings/state',{cache:'no-store'})).json();
    if(state.rate&&Object.keys(state.constants).length&&state.strings.filter(Boolean).length===4)break;
    if(performance.now()>until)throw new Error('its host did not say its strings within a minute');
    status.textContent='Starting the strings\' engine ...';await new Promise(done=>setTimeout(done,250));
  }
  INSTRUMENT_OF=Object.keys(state.variants);soloShown();
  const st=state.start;s=st.string;direction=st.direction;builds=state.strings.map(startBuild);inUse=state.inUse;
  variants();strings();$('seed').value=state.seed;
  // (The dials' reach, not anything played. Pitch from the open string as far up a string as the instrument is played.
  // Contact and a pluck's place from the robot grid's nearest the bridge (0.02, Schoonderwaldt's) to the string's middle;
  // force over the robot grid's (0.1 to 4 N); speed a decade either side of the note's. A stroke's bow from a hundredth
  // of the bow (bow.js's) to all of it, starting at what the note drew; its start and end a decade beyond both the
  // note's start and half bow.js's change. The finger's firmness from a thousandth of Artifastring's K_FINGER to all of
  // it; its damping from a tenth of a fingertip's measured to past Artifastring's own. A pluck's pull from
  // physical-strings.js's ppp to its fff. Vibrato a decade either side of the instrument's measured (vibrato.js). The
  // string's build a decade either side of Artifastring's own; its losses' tilt from 1/n^2 to n^2. Any value inside the
  // physics' bounds may be typed in a box.)
  const semis=-12*Math.log2(1-st.finger),beta=st.pos/(1-st.finger);
  const times=[st.startSeconds,state.bow.endSeconds];
  const bowed=()=>{if(bowing)later('bow',()=>[bowAsk()]);read()};
  const strokes=()=>{if(bowing)later('alternate',()=>[alternateAsk()]);read()};
  dial('strokes','stroke','Bow length per stroke (cm)',{min:state.bow.length,max:100*state.bow.length,log:true,value:Math.min(100*state.bow.length,100*st.drawn),onchange:strokes,note:''});
  dial('strokes','start',"Stroke start (s)",{min:Math.min(...times)/10,max:Math.max(...times)*10,log:true,value:st.startSeconds,onchange:()=>{started();strokes()},
    note:'How long the bow takes to come up to speed, when you press Play and after every change of bow.'});
  dial('strokes','end',"Stroke end (s)",{min:Math.min(...times)/10,max:Math.max(...times)*10,log:true,value:state.bow.endSeconds,onchange:strokes,
    note:'How long the bow takes to slow down before changing direction. It then comes up to speed the other way over the start time.'});
  attackCurves();
  dial('left','pitch','Pitch (semitones above the open string)',{min:0,max:1,value:semis,onchange:()=>{limits();later('finger',()=>[fingerAsk()]);bowed()},note:''});
  dial('left','firmness','Finger firmness (share, 0 to 1)',{min:.001,max:1,log:true,value:1,onchange:()=>later('finger',()=>[fingerAsk()]),
    note:"A share of Artifastring's finger stiffness (K_FINGER). At 1 the finger stops the string; a light touch sounds a harmonic."});
  const fingertip=state.finger,artifastring=fingertip.artifastring/fingertip.damping;
  dial('left','damping',"Finger damping (× a fingertip's)",{min:.1,max:10*Math.ceil(artifastring/10),log:true,value:1,onchange:()=>later('damping',()=>[dampingAsk()]),
    note:`At 1, a fingertip's measured damping, ${fingertip.damping} N·s/m (Wiertlewski & Hayward 2012); a light touch damps in proportion. Artifastring's own value, ${Math.round(artifastring)}, kills stopped notes within a fifth of a second and gives high ones sidebands.`});
  dial('right','beta','Contact point β (share of the string from the bridge)',{min:.02,max:.5,log:true,value:beta,onchange:()=>{limits();bowed()},note:''});
  dial('right','force','Bow force (N)',{min:.1,max:4,log:true,value:st.force,onchange:bowed});
  dial('right','speed','Bow speed (m/s)',{min:st.speed/10,max:st.speed*10,log:true,value:st.speed,onchange:bowed});
  // (The bow's hair on the string: none, Artifastring's point bow, to the ribbon's whole width, flat.)
  dial('right','hair','Bow hair on the string (mm)',{min:0,max:1000*state.bow.hairWidth,value:1000*state.bow.hairWidth,step:.1,
    onchange:()=>{limits();later('hair',()=>[hairAsk()]);bowed()},note:''});
  const vibrated=()=>{$('vibrating').checked=true;later('vibrato',()=>[vibratoAsk()])};
  dial('vibrato','width','Width (cents)',{min:state.vibrato.width/10,max:state.vibrato.width*10,log:true,value:state.vibrato.width,onchange:vibrated,
    note:'From lowest to highest: the pitch goes half of it above the note and half below.'});
  dial('vibrato','rate','Rate (Hz)',{min:state.vibrato.rate/10,max:state.vibrato.rate*10,log:true,value:state.vibrato.rate,onchange:vibrated});
  $('vibrating').onchange=()=>later('vibrato',()=>[vibratoAsk()]);
  $('vibratoNote').textContent=`measured on ${state.name} players: ${state.vibrato.width} cents wide at ${state.vibrato.rate} Hz`;
  const profile=state.noise.profile,noised=()=>later('noise',noiseAsks);
  dial('noise','noisePlayer',"The player's unsteadiness (× a player's)",{min:0,max:5,value:1,step:.05,onchange:noised,
    note:`Scales all the kinds below. Each is random, its power falling as 1/f^${profile.beta} from ${profile.low} to ${profile.high} Hz, with a ${profile.tremor.hz} Hz tremor carrying ${Math.round(100*profile.tremor.share)} % of it.`});
  for(const [kind,label,size] of NOISE_KINDS)dial('noise',noiseId(kind),label,{min:0,max:5,value:1,step:.05,onchange:noised,note:size(state.noise.kinds[kind].sd)});
  const pulls=Object.values(state.pluck.pull);
  dial('plucking','pluckPos','Where (share of the string from the bridge)',{min:.02,max:.5,log:true,value:state.pluck.position});
  dial('plucking','pluckForce','Pull (N)',{min:Math.min(...pulls),max:Math.max(...pulls),log:true,value:state.pluck.pull.mf});
  const built=key=>()=>{builds[s][key]=value[key];later('build',()=>[buildAsk()]);read();strings()};
  for(const [key,label,box] of BUILD){
    const own=state.strings[s][key];
    dial(box,key,label,key==='slope'?{min:-2,max:2,value:0,step:.01,onchange:built(key)}:key==='loss'?{min:.1,max:10,log:true,value:1,onchange:built(key)}
      :key==='modes'?{min:4,max:state.mostModes,log:true,value:state.mostModes,step:1,onchange:()=>{setters.modes(Math.round(value.modes),true);built('modes')()},note:''}
      :{min:own/10,max:own*10,log:true,value:own,onchange:built(key)});
  }
  // (Artifastring's constants, a decade either side of its own; its friction noise from none to a decade over.)
  const CONSTANTS=[['A_noise','Friction noise (share of v0, 0 to 1)','estimated from listening'],['PLUCK_VELOCITY','Pluck: finger speed (m/s)','estimated from listening'],
    ['PLUCK_DISPLACEMENT','Pluck: how far the string is pulled at full (m)','estimated from listening'],['PLUCK_SECONDS','Pluck: how long it is held (s)','estimated from listening'],
    ['K_PLUCK','Pluck: stiffness (N/m)'],['R_PLUCK','Pluck: damping (kg/s)'],['PLUCK_WIDTH','Pluck: width (m)'],['FINGER_WIDTH','Finger: width (m)']];
  for(const [key,label,said] of CONSTANTS){
    const own=state.constants[key];
    dial('constants',key,label,key==='A_noise'?{min:0,max:own*10,value:own,step:.001,onchange:()=>later(key,()=>[{do:'constant',name:key,value:value[key]}]),note:said?`Artifastring's value is ${own}, ${said}.`:undefined}
      :{min:own/10,max:own*10,log:true,value:own,onchange:()=>later(key,()=>[{do:'constant',name:key,value:value[key]}]),note:said?`Artifastring's value is ${own}, ${said}.`:undefined});
  }
  $('ownConstants').onclick=()=>{for(const [key] of CONSTANTS)setters[key](state.constants[key],true);ask(CONSTANTS.map(([key])=>({do:'constant',name:key,value:state.constants[key]})))};
  dial('listening','volume','Volume (dB)',{min:-40,max:40,value:0,step:.5,onchange:()=>later('gain',()=>[{do:'gain',gain:10**((heardDb()+value.volume)/20)}]),
    note:'At 0 dB the instrument\'s neutral note plays at broadcast loudness (EBU R128). Louder or softer playing is heard louder or softer than that.'});
  $('correcting').checked=state.corrected;
  dial('body','corner','Radiation corner frequency (Hz)',{min:20,max:1000,log:true,value:cornerFor(state.corrected),onchange:()=>{$('radiating').checked=true;later('radiate',()=>[radiateAsk()])}});
  $('radiating').onchange=$('falling').onchange=()=>later('radiate',()=>[radiateAsk()]);
  // (The correction switched, the radiation's corner moved to meet it.)
  $('correcting').onchange=()=>{setters.corner(cornerFor($('correcting').checked),true);later('correct',()=>[correctAsk(),radiateAsk()])};
  const limited=()=>{limits();later('finger',()=>[fingerAsk()]);bowed()};
  $('limitFingerboard').onchange=$('limitHair').onchange=limited;
  // (Listening to the host before anything is asked of it, so that nothing it says of the first settings is missed.)
  new EventSource('/strings/events').onmessage=e=>{
    const [word,...rest]=e.data.split(' ');
    if(word==='level'){const db=Number(rest[0]);$('meter').style.width=`${Number.isFinite(db)?Math.max(0,Math.min(100,100+100*db/60)):0}%`;
      $('level').textContent=Number.isFinite(db)?`${db.toFixed(1)} dB relative to full scale (rms)`:'silent'}
    else if(word==='turn'){if(+rest[0]===s){direction=rest[1]==='down'?1:-1;way()}}
    else if(word==='runaway')$('said').textContent=`The model became unstable at ${rest[0]} s and was restarted (a moment of silence).`;
    else if(word==='string'&&arrived&&!--arrived.left){arrived.done();arrived=null}
    else if(word==='modes'){inUse.modes[+rest[0]]=+rest[1];hairNote()}
    else if(word==='hair'){inUse.points[+rest[0]]=+rest[1];inUse.cellMm[+rest[0]]=+rest[2];hairNote()}
  };
  limits();showBuild();read();bodyNote();describe();
  await ask([{do:'gain',gain:10**(heardDb()/20)},fingerAsk(),radiateAsk(),...builds.map((_,i)=>buildAsk(i)),hairAsk(),...noiseAsks()]);
  $('good').onclick=()=>state.neutral?neutral():good();
  $('play').onclick=play;$('reverse').onclick=reverse;
  $('alternate').onchange=()=>{if(bowing)ask([alternateAsk()]);read()};
  $('output').onclick=()=>{bridge=!bridge;$('output').textContent=bridge?'Hearing: the bridge force (no body)':'Hearing: the instrument';ask([{do:'output',bridge}])};
  $('pluck').onclick=()=>ask([{do:'pluck',string:s,pos:value.pluckPos*(1-finger()),force:value.pluckForce}]);
  $('ownBuild').onclick=()=>{builds[s]=ownBuild(state.strings[s]);showBuild();ask([buildAsk()]);read();strings()};
  $('variant').onchange=()=>instrument(state.type,+$('variant').value);
  $('reseed').onclick=async()=>{const seed=Math.round(+$('seed').value);if(seed>=0){await ask([{do:'seed',seed}]);state.seed=seed;describe()}};
  $('keep').onclick=async()=>{
    const r=await fetch('/strings/keep',{method:'POST',body:JSON.stringify({words:$('words').value,...settingsNow()})});
    $('kept').textContent=r.ok?` kept (${new Date().toLocaleTimeString()})`:` not kept: ${await r.text()}`;if(r.ok){$('words').value='';kept()}};
  kept();
}
// (Every setting the page makes, kept (/keep) and saved as a file alike: its string, finger, bowing, attack, vibrato,
// build, constants, body, limits and noise, each as recall takes it back.)
function settingsNow(){
  return {string:s,openHz:openHz(builds[s]),
      pitchSemitones:value.pitch,finger:finger(),firmness:value.firmness,damping:value.damping,dampingNsPerM:value.damping*state.finger.damping,beta:value.beta,pos:pos(),force:value.force,speed:value.speed,direction,
      bowing,alternating:alternating(),strokeCm:value.stroke,startSeconds:value.start,endSeconds:value.end,
      attack:{shape:$('attackFrom').value,force:forceCurve.get(),speed:speedCurve.get()},
      vibrato:$('vibrating').checked?{widthCents:value.width,rateHz:value.rate}:null,build:builds[s],
      constants:Object.fromEntries(Object.keys(state.constants).map(key=>[key,value[key]])),heard:bridge?'bridge force':'instrument',
      body:{corrected:$('correcting').checked,radiated:$('radiating').checked,cornerHz:value.corner,order:+$('falling').value},limits:{fingerboard:fingerboard(),hair:hairLimited()},hairMm:value.hair,
      noise:{player:value.noisePlayer,...Object.fromEntries(NOISE_KINDS.map(([kind])=>[kind,value[noiseId(kind)]]))}};
}
// (The settings kept, newest first: each one's words and bowing, to be loaded again -- its dials set, sent at once where
// it plays -- or deleted.)
export async function kept(){
  const all=(await (await fetch('/strings/kept',{cache:'no-store'})).json()).reverse();
  $('keptNone').style.display=all.length?'none':'';
  $('keptList').innerHTML='';
  for(const k of all){
    const row=document.createElement('tr'),open=k.openHz?midiOf(k.openHz):null;
    const what=[k.instrument,open!=null&&k.pitchSemitones!=null?name(open+k.pitchSemitones):null,k.beta!=null?`β ${k.beta.toFixed(3)}`:null,k.force!=null?`${k.force.toFixed(2)} N`:null,
      k.speed!=null?`${k.speed.toFixed(3)} m/s`:null,k.strokeCm!=null&&k.alternating?`${k.strokeCm.toFixed(1)} cm a stroke`:null,
      k.vibrato?`vibrato ${k.vibrato.widthCents.toFixed(0)} ¢ at ${k.vibrato.rateHz.toFixed(2)} Hz`:null,k.heard==='bridge force'?'bridge force':null].filter(Boolean).join(' · ');
    row.innerHTML=`<td>${new Date(k.at).toLocaleString([],{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'})}</td><td><b></b><br><span class="muted"></span></td><td><button>Load</button><button>Delete</button></td>`;
    row.querySelector('b').textContent=k.words||'(no words)';row.querySelector('.muted').textContent=what;
    const [load,forget]=row.querySelectorAll('button');
    load.onclick=()=>recall(k);
    forget.onclick=async()=>{if(!confirm(`Delete "${k.words||'(no words)'}"?`))return;
      const r=await fetch('/strings/forget',{method:'POST',body:JSON.stringify({at:k.at})});if(!r.ok)$('said').textContent=await r.text();kept()};
    $('keptList').append(row);
  }
}
// ---- a stroke's attack: the bow's force and speed over its first moments, multiples of those dialled (attack-curves.js),
// drawn here and played by the host at Play and at every turn (the owner, 1 November 2026: "attacks usually involve a
// curve where a parameter peaks over the settling value, before settling, so I'll need visual curves to make proper
// attacks") ----
let forceCurve=null,speedCurve=null;
// (The speed's first rise -- after a bite, the one after it: the stroke's start, as long as the start dialled.)
const riseOf=points=>points.findIndex((p,k)=>k&&p[1]>0);
const startOf=points=>{const k=riseOf(points);return points[k][0]-points[k-1][0]};
const startingAt=(points,seconds)=>segmentLasting(points,riseOf(points),seconds,LONGEST);
// (The host's own attack -- the force as dialled, set down on the string over its least time; the bow drawn up to speed
// at one acceleration over the start -- asked as none, so that it plays as it always has; each curve asked only where
// it changed.)
const ownForce=points=>points.every(p=>p[1]===1),ownSpeed=points=>points.length===2&&points[1][2]==='straight';
let asked={force:null,speed:null};
function attackAsks(){
  const now={force:ownForce(forceCurve.get())?null:forceCurve.get(),speed:ownSpeed(speedCurve.get())?null:speedCurve.get()};
  const asks=['force','speed'].filter(what=>JSON.stringify(now[what])!==JSON.stringify(asked[what])).map(what=>({do:'attack',what,points:now[what]}));
  asked=now;return asks;
}
// (The shapes to start from, over the start dialled: as the neutral note is played; the renders' from silence, its force
// set down at a share of its own; each articulation's, as the renders play it (physical-strings.js onsetOf), its force
// and speed over the held bow's, its bite, its decay back.)
function shaped(name){
  const start=value.start,a=state.attacks;
  if(name==='neutral'||!a)return {force:[[0,1],[start,1]],speed:[[0,0],[start,1,'straight']]};
  if(name==='silence')return bowedAttack(a,{attack:start});
  const onset=a.articulations[name];return bowedAttack(a,{attack:start,onset,bite:onset.bite});
}
function shape(name){
  const {force,speed}=shaped(name);
  forceCurve.set(force);speedCurve.set(speed);$('attackFrom').value=name;attackSaid();
}
// (The start dialled: a shape chosen made again over it; one drawn, its speed's first rise moved to it.)
function started(){
  const name=$('attackFrom').value;
  if(name==='drawn')speedCurve.set(startingAt(speedCurve.get(),value.start));else shape(name);
  later('attack',attackAsks);
}
function attackSaid(){
  if(!forceCurve||!builds[s])return;
  const [ft,fy]=peakOf(forceCurve.get()),[vt,vy]=peakOf(speedCurve.get());
  $('attackSaid').textContent=`The force peaks at ${(fy*value.force).toFixed(2)} N (${fy.toFixed(2)}×) after ${Math.round(1000*ft)} ms; the speed peaks at ${(vy*value.speed).toFixed(3)} m/s (${vy.toFixed(2)}×) after ${Math.round(1000*vt)} ms`
    +`. Both have settled after ${Math.round(1000*Math.max(forceCurve.get().at(-1)[0],speedCurve.get().at(-1)[0]))} ms.`;
}
function attackCurves(){
  const a=state.attacks;
  $('attackFrom').innerHTML=`<option value="neutral">the neutral note's: the bow set down, then drawn up to speed</option>`
    +(a?`<option value="silence">the renders' attack from silence</option>`+Object.keys(a.articulations).map(n=>`<option value="${n}">the renders' ${n}</option>`).join(''):'')
    +`<option value="drawn" disabled>as drawn below</option>`;
  $('attackNote').textContent=a?`The attacks the renders play at ${a.dynamic}: ${a.fitted?`the ${state.name}'s fitted onset`:"the model's hand-written onset (physical-strings.js MODEL.onset), since no onset has been fitted yet"}, each stretched over the stroke's start set above. A quiet held note may need an attack that peaks above what it settles at, to get the string going.`
    :'The renders\' attacks appear once the strings\' server is restarted.';
  const drawn=()=>{$('attackFrom').value='drawn';attackSaid();later('attack',attackAsks)};
  forceCurve=curveEditor($('forceCurve'),{kind:attackKind({straight:true}),label:"Bow force at a stroke's start",color:'var(--strings)',change:drawn,
    meaning:y=>`${(y*value.force).toFixed(2)} N`});
  speedCurve=curveEditor($('speedCurve'),{kind:attackKind({from:0,straight:true}),label:"Bow speed at a stroke's start",color:'var(--strings)',
    meaning:y=>`${(y*value.speed).toFixed(3)} m/s`,change:points=>{
    const start=startOf(points);
    if(Math.abs(start-value.start)>1e-6){setters.start(start,true);if(bowing)later('alternate',()=>[alternateAsk()])}
    drawn()}});
  $('attackFrom').onchange=()=>{shape($('attackFrom').value);later('attack',attackAsks)};
  shape('neutral');
}

// (A setting kept on another instrument: the page's picker moved to it, as if chosen there.)
let chosen=()=>{};
async function recall(k){
  if(k.type!=null&&(k.type!==state.type||(k.variant??0)!==state.variant)){
    await instrument(k.type,k.variant??0);chosen(INSTRUMENT_OF[k.type]);
  }
  if(k.string!=null&&k.string!==s&&builds[k.string])cross(k.string);
  // (Its finger's damping as it was heard: one kept before the engine took a fingertip's measured, a share of
  // Artifastring's own.)
  const damping=Number.isFinite(k.dampingNsPerM)?k.dampingNsPerM/state.finger.damping:k.damping*state.finger.artifastring/state.finger.damping;
  for(const [id,v] of [['pitch',k.pitchSemitones],['firmness',k.firmness],['damping',damping],['beta',k.beta],['force',k.force],['speed',k.speed],
    ['stroke',k.strokeCm],['start',k.startSeconds],['end',k.endSeconds]])if(Number.isFinite(v))setters[id](v,true);
  if(k.alternating!=null)$('alternate').checked=k.alternating;
  // (Its bow's way as it was kept: an up-bow kept had been recalled down, the contrabass's address opened so.)
  if(k.direction===1||k.direction===-1){direction=k.direction;way()}
  // (Its attack as it was drawn: one kept before the page drew attacks, the host's own.)
  if(k.attack){forceCurve.set(k.attack.force);speedCurve.set(k.attack.speed);$('attackFrom').value=k.attack.shape??'drawn';attackSaid()}else shape('neutral');
  $('vibrating').checked=Boolean(k.vibrato);if(k.vibrato){setters.width(k.vibrato.widthCents,true);setters.rate(k.vibrato.rateHz,true)}
  if(k.build){builds[s]={...builds[s],...k.build};showBuild();strings()}
  const constants=Object.entries(k.constants??{}).filter(([key,v])=>setters[key]&&Number.isFinite(v));
  for(const [key,v] of constants)setters[key](v,true);
  setters.hair(Number.isFinite(k.hairMm)?k.hairMm:0,true);
  // (Its hands' noise as it was heard: one kept before the page had it, none.)
  if(k.noise)noiseAt(k.noise.player,k.noise);else noiseAt(0);
  if(k.body){$('radiating').checked=k.body.radiated;$('falling').value=String(k.body.order);if(Number.isFinite(k.body.cornerHz))setters.corner(k.body.cornerHz,true)}
  // (Its body as it was heard: one kept before the page corrected bodies uncorrected, and said.)
  const before=$('correcting').checked&&k.body?.corrected==null;
  $('correcting').checked=k.body?.corrected??false;
  // (A setting kept past a limit now on: the limit switched off to play it, and said.)
  const past=[];
  if(fingerboard()&&k.pitchSemitones>state.fingerboard){$('limitFingerboard').checked=false;past.push("past the fingerboard's end")}
  if(hairLimited()&&value.beta*builds[s].L*(1-finger())<state.bow.hairWidth/2){$('limitHair').checked=false;past.push("with the bow nearer the bridge than half its hair's width")}
  limits();
  const asks=[fingerAsk(),dampingAsk(),vibratoAsk(),...attackAsks(),...k.build?[buildAsk()]:[],...constants.map(([name,v])=>({do:'constant',name,value:v})),correctAsk(),radiateAsk(),hairAsk(),...noiseAsks()];
  if(bowing)asks.push(alternateAsk(),bowAsk());
  await ask(asks);read();
  $('said').textContent=[past.length?`This setting plays ${past.join(' and ')}, so that limit has been switched off under The hands' reach.`:'',
    before?'Kept before the bodies were corrected, so it is heard as it was then, uncorrected (switch the correction on under Instrument).':'',
    k.noise?'':"Kept before the hands' noise existed, so it is heard without it, as it was then.",
    Number.isFinite(k.dampingNsPerM)||!Number.isFinite(k.damping)?'':"Kept before the finger's measured damping, so the stopping finger is heard as it was then, with Artifastring's own damping."].filter(Boolean).join(' ');
}
// (A good note on the instrument played: the note started from, where this is its instrument; on another, its bowing at
// the same place on Schelleng's diagram -- its string's place among the strings, its pitch over it, its contact point,
// speed, start and stroke -- its force carried in proportion to the most a clean tone allows, 2Zv/(beta(mu_s - mu_d)):
// the string's impedance and its friction's span against the started note's. Everything else as the model has it: each
// string's own build, Artifastring's constants, the note's seed and variant, a stopping finger, no vibrato, the body
// as the renders correct it and radiating, the starting volume. Played on again if it was playing.)
async function good(){
  const p=state.pick,st=p.start,was=bowing;
  if(bowing)play();
  if(state.variant!==p.variant&&p.variant<state.variants[state.instrument])await instrument(state.type,p.variant);
  if(st.string!==s&&builds[st.string])cross(st.string);
  // (Each string Artifastring's own, its modes as they were: how finely it is resolved is not the note.)
  builds=state.strings.map((k,i)=>({...ownBuild(k),modes:builds[i]?.modes??state.mostModes}));showBuild();strings();
  const k=state.strings[s],q=p.string,own=state.type===p.type||!q;
  const force=own?st.force:st.force*Math.sqrt(k.T*k.pl)/Math.sqrt(q.T*q.pl)*(k.mus-k.mud)/(q.mus-q.mud);
  const set={pitch:-12*Math.log2(1-st.finger),firmness:1,damping:1,beta:st.pos/(1-st.finger),force,speed:st.speed,stroke:Math.min(100*state.bow.length,100*st.drawn),
    start:st.startSeconds,end:state.bow.endSeconds,width:state.vibrato.width,rate:state.vibrato.rate,corner:cornerFor(true),volume:0,...state.constants};
  for(const [id,v] of Object.entries(set))if(setters[id]&&Number.isFinite(v))setters[id](v,true);
  direction=st.direction;$('alternate').checked=true;$('vibrating').checked=false;$('correcting').checked=true;$('radiating').checked=true;$('falling').value='2';
  bridge=false;$('output').textContent='Hearing: the instrument';
  limits();
  noiseAt(1);shape('neutral');
  await ask([{do:'seed',seed:p.seed},...builds.map((_,i)=>buildAsk(i)),...Object.entries(state.constants).map(([name,v])=>({do:'constant',name,value:v})),
    fingerAsk(),dampingAsk(),vibratoAsk(),...attackAsks(),{do:'gain',gain:10**(heardDb()/20)},{do:'output',bridge:false},correctAsk(),radiateAsk(),hairAsk(),...noiseAsks()]);
  state.seed=p.seed;$('seed').value=p.seed;describe();read();way();
  if(was)await play();
  $('said').textContent=own?'':`A good note made from the ${INSTRUMENT_OF[p.type]}'s: the same bowing at the same place on Schelleng's diagram, which is ${force.toFixed(2)} N here.`;
}

// ---- the page's hold on it: taken up, put to rest, its keys ----
let begun=null,taking=Promise.resolve();
const placed=new Set();
// (Its neutral note: the neutral-note fit's (native/strings-model/neutral-notes.json, dial_neutral.py) -- its string and
// stop, the bow set down at ordinario at its neutral force and drawn up to its dynamic's speed over its attack time,
// neutral.py's reference note, the stroke the whole bow -- with everything else as good() leaves it: each string's own
// build, Artifastring's constants, the variant mapped, no vibrato, the body as the renders correct it and radiating, the
// starting volume. Played on again if it was playing.)
async function neutral(){
  const n=state.neutral,was=bowing;
  if(bowing)play();
  if(state.variant!==n.variant)await instrument(state.type,n.variant);
  if(n.string!==s&&builds[n.string])cross(n.string);
  builds=state.strings.map((k,i)=>({...ownBuild(k),modes:builds[i]?.modes??state.mostModes}));showBuild();strings();
  const set={pitch:n.stop,firmness:1,damping:1,beta:n.contact,force:n.force,speed:n.speed,stroke:100*state.bow.length,start:n.attack,
    end:state.bow.endSeconds,width:state.vibrato.width,rate:state.vibrato.rate,corner:cornerFor(true),volume:0,...state.constants};
  for(const [id,v] of Object.entries(set))if(setters[id]&&Number.isFinite(v))setters[id](v,true);
  $('alternate').checked=true;$('vibrating').checked=false;$('correcting').checked=true;$('radiating').checked=true;$('falling').value='2';
  bridge=false;$('output').textContent='Hearing: the instrument';
  limits();
  noiseAt(1);shape('neutral');
  await ask([...builds.map((_,i)=>buildAsk(i)),...Object.entries(state.constants).map(([name,v])=>({do:'constant',name,value:v})),
    fingerAsk(),dampingAsk(),vibratoAsk(),...attackAsks(),{do:'gain',gain:10**(heardDb()/20)},{do:'output',bridge:false},correctAsk(),radiateAsk(),hairAsk(),...noiseAsks()]);
  describe();read();way();
  if(was)await play();
  $('said').textContent='';
}
// (Where its neutral note is, said.)
const neutralSaid=n=>`its neutral note (${n.dynamic}, ${name(n.pitch)} on its ${['first','second','third','fourth','fifth','sixth'][n.string]??`${n.string+1}th`} string,`
  +` ${+n.force.toPrecision(3)} N at ${+n.speed.toPrecision(3)} m/s, settling in ${n.settlesMs} ms${n.withinLimit?'':`; none of its notes settles within the ${state.neutralLimitMs} ms listeners accept`};`
  +` from the neutral-note fit's ${n.rehearsal?'rehearsal ':''}map, round ${n.round})`;

// (An instrument of the strings' taken up: its dial's page made the first time, then the instrument -- at rest, its
// sound brought down and up again around it -- on its neutral note, else its good note. One already played is left as it
// was dialled; one made, taken up fresh (takenFresh).)
let fresh=null;
export const takenFresh=model=>fresh===model;
export function take(model,{status,choose}){
  chosen=choose??chosen;
  return taking=taking.catch(()=>{}).then(async()=>{
    begun??=init(status);await begun.catch(error=>{begun=null;throw error});
    const type=INSTRUMENT_OF.indexOf(model);
    if(type<0)throw new Error(`no ${model} among the strings`);
    status.classList.remove('failed');
    if(type!==state.type||!placed.has(type)){
      status.textContent=`Loading the ${model.replace(/-/g,' ')} ...`;
      // (A piece being rendered first stopped where another instrument is taken up: its piece one instrument's.)
      if(type!==state.type){await prerendered.stop();await instrument(type,0);fresh=model}
      await (state.neutral?neutral():good());placed.add(type);
    }
    status.textContent=`The ${state.name} is ready, heard through ${state.heardThrough}, on `+(state.neutral?neutralSaid(state.neutral)
      :`its good note${type===state.pick.type?' (the note it started from)':' (the violin\'s note, bowed at the same place on Schelleng\'s diagram)'}`)+'.';
    describe();
  }).catch(error=>{status.classList.add('failed');status.textContent=`The strings could not load the ${model}: ${error.message}`});
}
// ---- the musebot player: a piece its band composes for the instrument, played on it as its synthesizer (dial.mjs
// /soloist, soloist.mjs) ----
// (Its seed the page's, by default the band's own (opening-time.js DEFAULT_SEED), the most it plays, and its
// personality's levers, grammars and tone ranges, each drawn from its seed unless set (musebot.js); everything else in
// the piece the band's. The page's bow stopped as it starts: the musebot bows, turns its bow and makes its vibrato.)
$('soloSeed').value=DEFAULT_SEED;
const musebot=musebotControls({box:$('personality'),seed:$('soloSeed'),seconds:$('soloSeconds')});
let following=null;
$('solo').onclick=async()=>{
  if(!state||rendering)return;
  const on=!state.soloist?.playing;
  if(on){if(bowing)play();$('soloSaid').textContent='Its band is composing the piece ...'}
  const r=await fetch('/strings/soloist',{method:'POST',body:JSON.stringify(on?{on,...musebot.given()}:{on})});
  if(!r.ok){$('soloSaid').textContent=await r.text();return}
  state={...state,...await r.json()};soloShown();follow();
};
// (Followed while it plays: how far it has come.)
async function follow(){
  clearTimeout(following);
  state=await (await fetch('/strings/state',{cache:'no-store'})).json();soloShown();
  if(state.soloist?.playing)following=setTimeout(follow,500);
}
const minutes=x=>`${Math.floor(x/60)}:${String(Math.floor(x%60)).padStart(2,'0')}`;
// (Its piece rendered first, then heard (prerender.js): the page's bow lifted as it starts, as for the musebot playing
// live, whose button is held meanwhile.)
let rendering=false;
const prerendered=prerenderControls({family:'strings',button:$('render'),box:$('rendered'),rate:()=>state.rate,given:()=>musebot.given(),named:()=>state.name,
  before:()=>{rendering=true;if(bowing)play();soloShown()},after:()=>{rendering=false;return follow()}});
$('render').disabled=true;
// (The musebot playing, or the piece it last played: whose, its seed, how far, its lines come late, its register and
// its tone on the instrument.)
function soloShown(){
  const playing=Boolean(state.soloist?.playing)&&!rendering,said=state.soloist?.said,tone=said?.personality?.tone;
  $('solo').textContent=playing?'■ Stop the musebot':'▶ A musebot plays';$('solo').classList.toggle('on',playing);$('solo').disabled=rendering;
  $('render').disabled=!state.rate&&!prerendered.running();
  musebot.show(state.player,said?.personality);
  if(!said)return;
  $('soloSaid').textContent=`${said.player} on the ${state.name}, seed ${said.seed}: ${playing?'':'played '}${minutes(Math.min(said.at,said.seconds))} of ${minutes(said.seconds)}, ${said.notes} notes`
    +(said.late?`; ${said.late} lines came late`:'')
    +(said.personality?`; its register ${name(said.personality.register[0])} to ${name(said.personality.register[1])}`:'')
    +(tone?`; its tone ${said.personality.levers.tone.toFixed(2)}: ${tone.kinds.length?`${tone.kinds.join(', ')} in ${Math.round(100*tone.share)}% of phrases`:'no techniques'}, vibrato ${tone.vibrato[0].toFixed(1)} to ${tone.vibrato[1].toFixed(1)} × its players'`:'')+'.';
}

// (Its settings as a file (live.html, dial-settings.js): the page's own, as Keep keeps them, with its instrument, its
// variant and its seed, and its musebot's as set here (musebot.js given); and a file's made as a kept one is loaded,
// once the instrument is taken up, its musebot's kept by the dial for its next piece.)
export async function settings(){
  await taking.catch(()=>{});if(!state)throw new Error('no instrument yet');
  const model=INSTRUMENT_OF[state.type];
  return {model,settings:{family:'strings',model,type:state.type,variant:state.variant,seed:state.seed,...settingsNow(),player:musebot.given(state.player)},words:$('words').value,
    heard:{through:bridge?'bridge force':'instrument',bowing,said:$('listening').textContent}};
}
// (Whether `model` is taken up, once the page has done taking an instrument up.)
export async function taken(model){
  await taking.catch(()=>{});
  return Boolean(state)&&INSTRUMENT_OF[state.type]===model;
}
export async function load(file){
  await taking.catch(()=>{});if(!state)throw new Error('no instrument yet');
  const k=file.settings;
  if(Number.isInteger(k.seed)&&k.seed!==state.seed){await ask([{do:'seed',seed:k.seed}]);state.seed=k.seed;describe()}
  await recall(k);
  if(file.words)$('words').value=file.words;
  const refused=[];
  if(k.player){const r=await fetch('/strings/player',{method:'POST',body:JSON.stringify(k.player)});
    if(r.ok){state={...state,...await r.json()};soloShown()}else refused.push({path:'/player',error:await r.text()})}
  return {made:'every one',refused};
}
// (Another family chosen: the bow lifted and the musebot stopped, the host left stepping its strings, silent.)
export function rest(){prerendered.stop();if(bowing)play();if(state?.soloist?.playing)fetch('/strings/soloist',{method:'POST',body:JSON.stringify({on:false})}).then(follow)}
export function keys(e){
  if(e.target.tagName==='INPUT'||e.target.tagName==='SELECT')return;
  if(e.code==='Space'){e.preventDefault();play()}else if(e.key==='r')reverse();else if(e.key==='p')$('pluck').click();
}
