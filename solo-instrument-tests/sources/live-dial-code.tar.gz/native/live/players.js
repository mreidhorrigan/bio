// What real players were measured doing, drawn on a slider (the owner, 3 November 2026: "Displaying the realistic range
// should be done concisely on each slider"): a band under its track over the measured range -- a tick for one measured
// value -- and a short line beside it, "measured 2.6–6.4 kPa", whose, from what, and whether borrowed in its title. The
// ranges are each dial's own (native/live/players-ranges.mjs), in its units; the page gives where a value stands on the
// slider (0 to 1) and how it is written.

// (A slider's band, made under it once: show(entry, place, written) draws an entry -- {range: [low, high]}, either end
// null, {value}, or null where nobody measured it -- placing each end by `place` (its value to the slider's 0 to 1) and
// writing it by `written`.)
export function playersBand(input){
  let track=input.parentElement;
  if(!track.classList.contains('track')){track=document.createElement('span');track.className='track';input.replaceWith(track);track.append(input)}
  const band=document.createElement('span'),fill=document.createElement('i'),said=document.createElement('small');
  band.className='players';band.append(fill,said);track.append(band);
  return (entry,place,written)=>{
    const value=entry?.value!=null,[low,high]=value?[entry.value,entry.value]:entry?.range??[null,null];
    if(!entry||low==null&&high==null){fill.hidden=true;said.textContent='unmeasured';band.title='Nobody measured yet for this control.';return}
    const clip=x=>Math.min(1,Math.max(0,x)),a=low==null?0:place(low),b=high==null?1:place(high);
    // (A slider that cannot place it -- its column held at nothing -- only says it.)
    const placed=Number.isFinite(a)&&Number.isFinite(b),from=clip(Math.min(a,b)),to=clip(Math.max(a,b)),beyond=placed&&(Math.max(a,b)<0||Math.min(a,b)>1);
    fill.hidden=!placed||beyond;fill.classList.toggle('tick',value);
    // (The thumb's centre travels inside the track by half its width either side.)
    fill.style.left=`calc(8px + (100% - 16px) * ${from})`;fill.style.width=value?'':`calc((100% - 16px) * ${to-from})`;
    said.textContent=`measured ${value?written(low):low==null?`≤ ${written(high)}`:high==null?`≥ ${written(low)}`:`${written(low)}–${written(high)}`}`
      +(beyond?', beyond its reach':'')+(entry.by?' (borrowed)':'');
    band.title=`${entry.what[0].toUpperCase()}${entry.what.slice(1)}: ${entry.source}${entry.by?`; borrowed from ${entry.by}`:''}.`;
  };
}

// (What changes with the pitch, at a pitch: {points: [[midi, low, high], ...]} read between its two nearest; outside
// the pitches measured, nothing.)
export function atPitch(entry,midi){
  const p=entry?.points;
  if(!p?.length||midi<p[0][0]||midi>p.at(-1)[0])return null;
  const k=Math.max(0,p.findLastIndex(q=>q[0]<=midi)),[m0,l0,h0]=p[k],[m1,l1,h1]=p[Math.min(k+1,p.length-1)],t=m1>m0?(midi-m0)/(m1-m0):0;
  return {...entry,range:[l0+t*(l1-l0),h0+t*(h1-h0)]};
}
