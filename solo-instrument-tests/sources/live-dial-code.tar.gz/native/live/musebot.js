// The musebot player's settings on the live dial's page (winds.js; strings.js), each family's the same: its seed, the
// most it plays, and its personality -- each lever and each motif grammar a share, 0 to 1, and each of its tone's ranges
// a low and a high share, drawn from its seed unless set here (public/shared/performers/personality.js; docs/
// PLAYER_PERSONALITY.md). The dial's /state `player` says which levers, grammars and ranges there are and what was last
// given (a page's, a file's); a piece's personality, as its player drew it, is shown on those not set.
const words=name=>name.replace(/[A-Z]/g,c=>` ${c.toLowerCase()}`);

// (Its controls in `box`, its seed and length the page's own inputs `seed` and `seconds`.) -> {given() -> {seed,
// seconds, personality}, show(player, drawn)}.
export function musebotControls({box,seed,seconds}){
  let built=null,shown=null;
  // (A share's row: a box ticked when it is set here, a slider and a number; moved, it is set.)
  function share(into,id,name,{grammar=false}={}){
    const r=document.createElement('div');r.className='row';
    r.innerHTML='<label><input type="checkbox"> <span></span></label><input type="range" min="0" max="1" step="0.01"><input type="number" min="0" max="1" step="0.01">';
    r.querySelector('span').textContent=words(name);
    r.title=`${grammar?`its motifs' ${name} grammar's share`:`its ${words(name)}`}: drawn from its seed unless ticked, 0 to 1 across its range (registry/method/personality.json)`;
    const [tick,range,number]=r.querySelectorAll('input');range.id=`${id}-${name}`;r.querySelector('label').htmlFor=range.id;
    const drawnShown=()=>r.classList.toggle('drawn',!tick.checked);
    const set=v=>{range.value=v;number.value=(+v).toFixed(2)};
    range.oninput=()=>{tick.checked=true;number.value=(+range.value).toFixed(2);drawnShown()};
    number.onchange=()=>{const v=+number.value;if(Number.isFinite(v)&&v>=0&&v<=1){tick.checked=true;range.value=v;drawnShown()}else number.value=(+range.value).toFixed(2)};
    tick.onchange=drawnShown;into.append(r);set(.5);drawnShown();
    return {name,grammar,get given(){return tick.checked},value:()=>+range.value,
      take(v,given){tick.checked=given;if(v!=null)set(v);drawnShown()}};
  }
  // (A tone range's row: a box ticked when it is set here, its low and its high share; changed, it is set, low first.)
  function span(into,id,name){
    const r=document.createElement('div');r.className='row';
    r.innerHTML='<label><input type="checkbox"> <span></span></label><input type="number" min="0" max="1" step="0.01"><input type="number" min="0" max="1" step="0.01">';
    r.querySelector('span').textContent=words(name);
    r.title=`its range of ${words(name)}, its low and high shares of its span on its instrument: drawn from its seed unless ticked (personality.js TONE_RANGES; docs/PLAYER_PERSONALITY.md)`;
    const [tick,low,high]=r.querySelectorAll('input');low.id=`${id}-range-${name}`;r.querySelector('label').htmlFor=low.id;
    let last=[0,1];
    const drawnShown=()=>r.classList.toggle('drawn',!tick.checked);
    const set=([a,b])=>{low.value=(+a).toFixed(2);high.value=(+b).toFixed(2);last=[+a,+b]};
    low.onchange=high.onchange=()=>{const a=+low.value,b=+high.value;if(!(a>=0&&a<=1&&b>=0&&b<=1)){set(last);return}set([Math.min(a,b),Math.max(a,b)]);tick.checked=true;drawnShown()};
    tick.onchange=drawnShown;into.append(r);set(last);drawnShown();
    return {name,range:true,get given(){return tick.checked},value:()=>[...last],
      take(v,given){tick.checked=given;if(v!=null)set(v);drawnShown()}};
  }
  function build(player){
    box.replaceChildren();
    const id=box.id||'musebot',head=document.createElement('div');head.className='note musebotNote';
    head.textContent='Each drawn from its seed unless ticked; a piece\'s draw shown on those not ticked.';
    const all=document.createElement('button');all.type='button';all.textContent='All from its seed';
    all.onclick=()=>{for(const s of built)s.take(null,false)};
    box.append(head,all);
    const levers=player.levers.map(name=>share(box,id,name));
    const g=document.createElement('div');g.className='curveLabel';g.textContent='Its motifs\' grammars';box.append(g);
    built=[...levers,...(player.grammars??[]).map(name=>share(box,id,name,{grammar:true}))];
    if(player.ranges?.length){const r=document.createElement('div');r.className='curveLabel';r.textContent='Its tone\'s ranges, low and high';box.append(r);
      built.push(...player.ranges.map(name=>span(box,id,name)))}
  }
  return {
    // (What a piece is asked with: the levers, grammars and ranges ticked, each by its name.)
    given(){
      const personality={},grammars={},ranges={};
      for(const s of built??[])if(s.given)(s.range?ranges:s.grammar?grammars:personality)[s.name]=s.value();
      if(Object.keys(grammars).length)personality.grammars=grammars;
      if(Object.keys(ranges).length)personality.ranges=ranges;
      return {seed:Number(seed.value),seconds:Number(seconds.value),personality};
    },
    // (The dial's player: its controls built the first time, and set again only when it changes -- a file loaded, a
    // piece asked -- so that what is being set here is not undone by a poll; `drawn`, a piece's own levers.)
    show(player,drawn=null){
      if(!player?.levers)return;
      if(!built)build(player);
      const now=JSON.stringify([player.seed,player.seconds,player.personality,drawn?.levers??null,drawn?.ranges??null]);
      if(now===shown)return;shown=now;
      if(document.activeElement!==seed)seed.value=player.seed;
      if(document.activeElement!==seconds)seconds.value=player.seconds;
      const given=player.personality??{};
      for(const s of built){
        const set=s.range?given.ranges?.[s.name]:s.grammar?given.grammars?.[s.name]:given[s.name];
        s.take(set??(s.range?drawn?.ranges?.[s.name]:s.grammar?drawn?.grammars?.[s.name]:drawn?.levers?.[s.name])??null,set!=null);
      }
    },
  };
}
