// The winds' live dial in a page by itself (the owner's website: research/LIVE_DIAL_ON_THE_WEBSITE.md), in a Worker of
// its own: the dial the Mac's server runs (native/openwind/dial.mjs windsDial, as native/openwind/live.mjs runs it), on
// the engine in WebAssembly (public/studio/engines/openwind-stream.js) -- its bore on several cores where the page is
// cross-origin isolated, each core a Worker (openwind-thread.js), else on one -- and the bodies packed with the page
// (scripts/build-live-site.mjs): each wind's files, its rules' rows as the Mac's engine gave them, its neutral note, its
// impedance and the glides the Mac kept. Every route the page takes (native/live/live.mjs's /families and /start, the
// winds' own under /winds/) answered here as the Mac answers it, the page's fetches handed over by page.js.
//
//   page -> {id, method, path, query, given};  here -> {id, status, json} or {id, status, samples, headers}
//   here -> {kept: record} (a setting kept: the page keeps it), {said: text}
import {windsDial} from '../../openwind/dial.mjs';
import {lipsRow} from '../../openwind/rows.mjs';
import {GlideBook} from '../../openwind/blend.mjs';
import {liveStream,openwindEngine} from '../../../public/studio/engines/openwind-stream.js';

const at=path=>new URL(path,self.location.href);
// (Every file packed gzipped, as a static host serves it, unpacked here: the flute's body 17 MB as it is, 57 kB so.)
const got=async(path,as='json')=>{const r=await fetch(at(`${path}.gz`));if(!r.ok)throw new Error(`${path}: ${r.status}`);
  return new Response(r.body.pipeThrough(new DecompressionStream('gzip')))[as]()};
const say=text=>self.postMessage({said:text});

// (The threaded build where the page may share its memory, each core a Worker; else the one-core build. Its bore on as
// many cores as the browser has but one, the page's and its sound's (the owner, 2 November 2026: "the web engine should
// also use as many cores as are available"; "We can't predict how many cores another user will have"): the visitor's
// own count, read here, on fewer where the bore splits into fewer parts (src/parallel.rs) -- at most the 16 Workers
// openwind-stream.js keeps.)
const threaded=Boolean(self.crossOriginIsolated)&&typeof SharedArrayBuffer!=='undefined';
const CORES=threaded?Math.max(1,Math.min(16,(navigator.hardwareConcurrency||1)-1)):1;
const engine=got(threaded?'openwind-threads.wasm':'openwind.wasm','arrayBuffer').then(bytes=>openwindEngine(bytes,{said:say,
  thread:threaded?()=>new Worker(at('openwind-thread.js'),{type:'module'}):null}));

// Each wind's files, fetched once it is first chosen (its engine's as its engine opens) -- those the packer found
// (`files`: a neutral note, an impedance, glides where the Mac has them, a woodwind's fingerings among which it chooses)
// -- and at hand by its folder once they are: the dial asks its neutral note and impedance at once. A brass body with a
// mute in its bell its own, beside its open one (`mutes`: each published mute's).
const fetched=new Map,loaded=new Map,cores=new Map;
function filesOf(m,mute=null){
  const own=mute?m.mutes?.[mute]:m;
  if(!own)return Promise.reject(new Error(`the ${m.model}'s body with its ${mute} mute is not published here`));
  const folder=mute?`winds/${m.model}/muted/${mute}`:`winds/${m.model}`,of=file=>`${folder}/${file}`,has=file=>own.files.includes(file)?got(of(file)):null;
  if(!fetched.has(folder))fetched.set(folder,(async()=>{
    const [laid,rules,attacks,vibrato,neutral,rows,glides,impedance,alternates]=await Promise.all(['body.json','rules.json','attacks.json','vibrato.json','neutral.json','rows.json','glides.json','impedance.json','alternates.json'].map(has));
    const files={folder,laid,rules,attacks,vibrato,neutral,rows,glides,impedance,alternates,
      engine:Promise.all([got(of('body.json'),'text'),got(of('I.bin'),'arrayBuffer'),got(of('D.bin'),'arrayBuffer'),got(of('law.json'),'text'),got(of('rules.json'),'text')])
        .then(([header,I,D,law,text])=>({header,I:new Uint8Array(I),D:new Uint8Array(D),law,rules:text}))};
    files.engine.catch(()=>{});
    loaded.set(folder,files);return files;
  })());
  return fetched.get(folder);
}

// (Its neutral note's row at mf, or its first charted note's: what its cores are timed blowing.)
function neutralRow(m,{rules,rows,neutral}){
  const note=rules.notes[neutral?.note??0];
  return m.kind==='lips'?lipsRow(rules,note.lip,note.pressures.mf,note.valves):rows.mf[String(note.midi)];
}

const ready=(async()=>{
  const {instruments,first,strings}=await got('winds/manifest.json');
  const by=Object.fromEntries(instruments.map(m=>[m.model,m]));
  const dial=windsDial({instruments:instruments.map(m=>m.model),kinds:Object.fromEntries(instruments.map(m=>[m.model,m.kind])),
    body:async(model,{mute=null}={})=>{const m=by[model],f=await filesOf(m,mute);return {folder:f.folder,name:mute?m.mutes[mute].name:m.name,rules:f.rules,laid:{...f.laid,single:f.laid.single||m.single},attacks:f.attacks,vibrato:f.vibrato,alternates:f.alternates}},
    // (On the cores found fastest for it here, the first time it is taken up: openwind-stream.js fastestCores.)
    engine:({model,folder,onError})=>{const m=by[model];
      const stream=liveStream(engine,(async()=>{await engine;const f=loaded.get(folder);return {...await f.engine,row:neutralRow(m,f)}})(),{single:m.single,...cores.has(model)?{threads:cores.get(model)}:{most:CORES},onError});
      stream.ready.then(()=>{if(!cores.has(model)){cores.set(model,stream.threads);if(stream.paces)say(`  the ${model} on ${stream.threads} of ${CORES} cores, timed here: ${
        Object.entries(stream.paces).map(([k,pace])=>`${k} ${Math.round(100*pace)} %`).join(', ')} of real time`)}},()=>{});
      return stream},
    // (The glides the Mac kept; one it never measured is the two notes' rows blended -- `provisional` -- here.)
    glides:({folder,columns,shaded})=>new GlideBook({columns,shaded,kept:loaded.get(folder).glides??{}}),
    // (Its rules' rows at each dynamic, as the Mac's engine gave them for this body: glides.mjs rulesRow.)
    rulesRow:async(_,model,midi,dynamic)=>{const row=(await filesOf(by[model])).rows?.[dynamic]?.[String(midi)];
      if(!row)throw new Error(`no row of the ${model}'s at ${midi} ${dynamic} was packed`);return row},
    neutral:folder=>loaded.get(folder)?.neutral??null,
    impedance:made=>{made.impedance=loaded.get(made.folder)?.impedance??null},
    keep:record=>{self.postMessage({kept:record});return 'this browser (live.kept() in the console gives them)'},
    log:say,warn:say});
  const built=engine.then(e=>({threaded:e.threaded,cores:CORES}),error=>({error:error.message}));
  // (The families as live.mjs shows them: the winds running here; the strings' instruments, their dial in a Worker of its
  // own (strings-worker.js) whose state the page says.)
  const families=async()=>({strings:{instruments:strings,running:false,starting:false,ended:null},
    winds:{instruments:instruments.map(({model,kind})=>({model,kind})),running:true,starting:false,ended:null},first,engine:await built});
  return {dial,families};
})();

self.onmessage=async({data:{id,method,path,query,given}})=>{
  try{
    const {dial,families}=await ready;
    if(path==='/families'||path==='/start'){self.postMessage({id,status:200,json:await families()});return}
    const m=/^\/winds(\/.*)$/.exec(path);
    if(!m){self.postMessage({id,status:404});return}
    const answer=await dial.handle(method,m[1],new URLSearchParams(query),given??{});
    if(answer.samples){const samples=new Float32Array(answer.samples);self.postMessage({id,status:answer.status,samples,headers:answer.headers},[samples.buffer]);return}
    self.postMessage({id,status:answer.status,json:answer.json});
  }catch(error){self.postMessage({id,status:400,json:{error:error.message}})}
};
