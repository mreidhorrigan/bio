// The bowed strings' live dial in a page by itself (the owner's website: research/LIVE_DIAL_ON_THE_WEBSITE.md), in a
// Worker of its own: the dial the Mac's server runs (native/strings-model/dial.mjs stringsDial, as live.mjs runs it), on
// its host in WebAssembly (musebots-strings-live.cpp by Emscripten: scripts/build-studio.mjs buildStringsLiveWasm, its
// loader strings-live.js), and
// what the Mac measured for it packed with the page (scripts/build-live-site.mjs: the monitor's gains, Artifastring's
// variants, the started note's bowing, the finger's damping). The host steps a buffer at a time as the Mac's does: kept
// ahead of the page's sound where the page plays it (its AudioWorklet's port, handed here), else on this Worker's own
// clock while the page asks things of it -- an instrument taken up is said only once a buffer is made -- and at rest once
// it has been neither heard nor asked for a while, as nothing is to be heard of it then. Or rendered as it is pulled
// rather than heard (GET /audio: a musebot's piece made before it is heard, native/live/prerender.js), as fast or as slowly
// as this computer makes it, the page's sound and this Worker's clock left until nothing has pulled it for PULLED_IDLE s.
//
//   page -> {id, method, path, query, given};  here -> {id, status, json} or {id, status, text}, or its sound pulled (GET
//     /audio?frames=N) {id, status, samples, headers}
//   page -> {listen: true};  here -> {line} for each the host says, as the Mac's server's /events
//   page -> {sound: port}: its AudioWorklet's;  port -> {n, got} (frames it holds, and has been given);  here -> port: samples
//   here -> {kept: record} (a setting kept: the page keeps it), {said: text}
import {BUFFER_SECONDS,PULL_MOST,stringsDial} from '../../strings-model/dial.mjs';

const at=path=>new URL(path,self.location.href);
// (Every file packed gzipped, as a static host serves it, unpacked here.)
const got=async(path,as='json')=>{const r=await fetch(at(`${path}.gz`));if(!r.ok)throw new Error(`${path}: ${r.status}`);
  return new Response(r.body.pipeThrough(new DecompressionStream('gzip')))[as]()};

// (How far ahead of the page's sound the host is kept, s: the Mac's host keeps three of its buffers queued, 30 ms; a
// Worker's turns come less evenly than an audio thread's. How long it steps unheard after it was last asked, s.)
const AHEAD=.06,AWAKE=5,PULLED_IDLE=1;
const ready=(async()=>{
  const packed=await got('strings/manifest.json');
  const [{default:create},module]=await Promise.all([import(at('strings-live.js').href),got('strings-live.wasm','arrayBuffer').then(bytes=>WebAssembly.compile(bytes))]);
  // (The dial's clock, the host's frames made over its rate -- at the middle of the buffer to be made, so that its
  // musebot player's lines, sent before it and taken at its start, come at their times within half a buffer.)
  let dial=null,madeFrames=0,step=0,rateHere=1;
  // (Its binary handed over compiled, as the studio's engines hand theirs: Emscripten's loader reads no wasmBinary.)
  const host=await create({instantiateWasm(imports,receive){WebAssembly.instantiate(module,imports).then(made=>receive(made,module));return {}},
    print:line=>dial.heard(line),printErr:line=>self.postMessage({said:line})});
  const say=line=>host.ccall('live_say',null,['string'],[line]);
  dial=stringsDial({...packed.dial,neutralDb:name=>packed.neutralDb[name]??null,heardThrough:'this browser',labels:'this browser',
    send:text=>{for(const line of text.split('\n'))if(line)say(line)},
    keep:record=>{self.postMessage({kept:record});return 'this browser'},kept:()=>[],forget:()=>null,
    clock:()=>(madeFrames+step/2)/rateHere,every:BUFFER_SECONDS});
  const frames=host._live_begin(packed.dial.type,packed.dial.variant,packed.dial.seed,BUFFER_SECONDS),rate=dial.state.rate;
  if(!frames)throw new Error('the strings\' host did not begin');
  step=frames;rateHere=rate;
  const made=()=>{dial.due();const at=host._live_fill()>>2;madeFrames+=frames;return host.HEAPF32.slice(at,at+frames)};
  return {dial,frames,rate,made,seconds:()=>madeFrames/rate};
})();

// (The host's clock: the page's sound, where it plays and asks; else this Worker's own while it was asked lately.)
let port=null,given=0,heardAt=-Infinity,askedAt=performance.now(),since=null,steps=0,pulledAt=-Infinity;
const pulledLately=()=>performance.now()-pulledAt<PULLED_IDLE*1000;
async function playing({data:{n,got}}){
  const {frames,rate,made}=await ready;
  if(pulledLately())return;
  heardAt=performance.now();since=null;
  while(n+given-got<AHEAD*rate){const samples=made();given+=frames;port.postMessage(samples,[samples.buffer])}
}
setInterval(async()=>{
  const {frames,rate,made}=await ready,now=performance.now();
  if(now-heardAt<100||now-askedAt>AWAKE*1000||pulledLately()){since=null;return}
  if(since==null){since=now;steps=0}
  for(const due=((now-since)/1000+AHEAD)*rate;steps*frames<due;steps++)made();
},10);

self.onmessage=async({data})=>{
  askedAt=performance.now();
  if(data.sound){port=data.sound;given=0;port.onmessage=playing;return}
  try{
    const {dial}=await ready;
    if(data.listen){dial.listen(line=>self.postMessage({line}));return}
    const {id,method,path,query,given:body}=data;
    if(method==='GET'&&path==='/audio'){
      const {frames,made,seconds}=await ready,asked=Math.min(Math.max(1,Number(new URLSearchParams(query).get('frames'))||1024),PULL_MOST);
      const buffers=Math.max(1,Math.round(asked/frames)),samples=new Float32Array(buffers*frames);
      for(let k=0;k<buffers;k++)samples.set(made(),k*frames);
      pulledAt=performance.now();
      self.postMessage({id,status:200,samples,headers:{'x-seconds':seconds()}},[samples.buffer]);return;
    }
    const answer=await dial.handle(method,path,body??{});
    self.postMessage({id,status:answer.status,json:answer.json,text:answer.text});
  }catch(error){if(data.id!==undefined)self.postMessage({id:data.id,status:500,text:error.message});else self.postMessage({said:`the strings' dial: ${error.message}`})}
};
