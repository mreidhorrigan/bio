// The bowed strings' live dial in a page by itself (the owner's website: research/LIVE_DIAL_ON_THE_WEBSITE.md), in a
// Worker of its own: the dial the Mac's server runs (native/strings-model/dial.mjs stringsDial, as live.mjs runs it), on
// its host in WebAssembly (musebots-strings-live.cpp by Emscripten: scripts/build-studio.mjs buildStringsLiveWasm, its
// loader strings-live.js), and
// what the Mac measured for it packed with the page (scripts/build-live-site.mjs: the monitor's gains, Artifastring's
// variants, the started note's bowing, the finger's damping). The host steps a buffer at a time as the Mac's does: kept
// ahead of the page's sound where the page plays it (its AudioWorklet's port, handed here), else on this Worker's own
// clock while the page asks things of it -- an instrument taken up is said only once a buffer is made -- and at rest once
// it has been neither heard nor asked for a while, as nothing is to be heard of it then.
//
//   page -> {id, method, path, given};  here -> {id, status, json} or {id, status, text}
//   page -> {listen: true};  here -> {line} for each the host says, as the Mac's server's /events
//   page -> {sound: port}: its AudioWorklet's;  port -> {n, got} (frames it holds, and has been given);  here -> port: samples
//   here -> {kept: record} (a setting kept: the page keeps it), {said: text}
import {BUFFER_SECONDS,stringsDial} from '../../strings-model/dial.mjs';

const at=path=>new URL(path,self.location.href);
// (Every file packed gzipped, as a static host serves it, unpacked here.)
const got=async(path,as='json')=>{const r=await fetch(at(`${path}.gz`));if(!r.ok)throw new Error(`${path}: ${r.status}`);
  return new Response(r.body.pipeThrough(new DecompressionStream('gzip')))[as]()};

// (How far ahead of the page's sound the host is kept, s: the Mac's host keeps three of its buffers queued, 30 ms; a
// Worker's turns come less evenly than an audio thread's. How long it steps unheard after it was last asked, s.)
const AHEAD=.06,AWAKE=5;
const ready=(async()=>{
  const packed=await got('strings/manifest.json');
  const [{default:create},module]=await Promise.all([import(at('strings-live.js').href),got('strings-live.wasm','arrayBuffer').then(bytes=>WebAssembly.compile(bytes))]);
  let dial=null;
  // (Its binary handed over compiled, as the studio's engines hand theirs: Emscripten's loader reads no wasmBinary.)
  const host=await create({instantiateWasm(imports,receive){WebAssembly.instantiate(module,imports).then(made=>receive(made,module));return {}},
    print:line=>dial.heard(line),printErr:line=>self.postMessage({said:line})});
  const say=line=>host.ccall('live_say',null,['string'],[line]);
  dial=stringsDial({...packed.dial,neutralDb:name=>packed.neutralDb[name]??null,heardThrough:'this browser',labels:'this browser',
    send:text=>{for(const line of text.split('\n'))if(line)say(line)},
    keep:record=>{self.postMessage({kept:record});return 'this browser'},kept:()=>[],forget:()=>null});
  const frames=host._live_begin(packed.dial.type,packed.dial.variant,packed.dial.seed,BUFFER_SECONDS),rate=dial.state.rate;
  if(!frames)throw new Error('the strings\' host did not begin');
  const made=()=>{const at=host._live_fill()>>2;return host.HEAPF32.slice(at,at+frames)};
  return {dial,frames,rate,made};
})();

// (The host's clock: the page's sound, where it plays and asks; else this Worker's own while it was asked lately.)
let port=null,given=0,heardAt=-Infinity,askedAt=performance.now(),since=null,steps=0;
async function playing({data:{n,got}}){
  const {frames,rate,made}=await ready;
  heardAt=performance.now();since=null;
  while(n+given-got<AHEAD*rate){const samples=made();given+=frames;port.postMessage(samples,[samples.buffer])}
}
setInterval(async()=>{
  const {frames,rate,made}=await ready,now=performance.now();
  if(now-heardAt<100||now-askedAt>AWAKE*1000){since=null;return}
  if(since==null){since=now;steps=0}
  for(const due=((now-since)/1000+AHEAD)*rate;steps*frames<due;steps++)made();
},10);

self.onmessage=async({data})=>{
  askedAt=performance.now();
  if(data.sound){port=data.sound;given=0;port.onmessage=playing;return}
  try{
    const {dial}=await ready;
    if(data.listen){dial.listen(line=>self.postMessage({line}));return}
    const {id,method,path,given:body}=data,answer=dial.handle(method,path,body??{});
    self.postMessage({id,status:answer.status,json:answer.json,text:answer.text});
  }catch(error){if(data.id!==undefined)self.postMessage({id:data.id,status:500,text:error.message});else self.postMessage({said:`the strings' dial: ${error.message}`})}
};
