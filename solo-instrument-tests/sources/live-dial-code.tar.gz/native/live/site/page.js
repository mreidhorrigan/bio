// The live dial's page by itself, on a static site (scripts/build-live-site.mjs): its fetches of the dial's routes --
// /families, /start, /winds/... -- answered by the dial in a Worker beside it (dial-worker.js) in place of the Mac's
// server (native/live/live.mjs), so that live.html, winds.js and strings.js are the Mac's own, unchanged; everything
// else fetched as it is. Imported ahead of them. A setting kept is kept in this browser (live.kept()); a line at the top
// says what plays here and where its source is.
const worker=new Worker(new URL('dial-worker.js',document.baseURI),{type:'module'});
const waiting=new Map;let next=0;
const KEPT='musebots-live-dial-kept';
worker.onmessage=({data})=>{
  if(data.said!==undefined){console.log(data.said);return}
  if(data.kept){try{localStorage.setItem(KEPT,JSON.stringify([...kept(),data.kept]))}catch{}return}
  const {resolve}=waiting.get(data.id)??{};waiting.delete(data.id);
  if(!resolve)return;
  const headers=Object.fromEntries(Object.entries(data.headers??{}).map(([k,v])=>[k,String(v)]));
  resolve(data.samples?new Response(data.samples.buffer,{status:data.status,headers:{'content-type':'application/octet-stream',...headers}}):
    data.json===undefined?new Response(null,{status:data.status}):new Response(JSON.stringify(data.json),{status:data.status,headers:{'content-type':'application/json'}}));
};
worker.onerror=error=>{for(const {reject} of waiting.values())reject(new Error(`the dial stopped: ${error.message??error}`));waiting.clear()};
function kept(){try{return JSON.parse(localStorage.getItem(KEPT)??'[]')}catch{return []}}

const own=globalThis.fetch.bind(globalThis);
const ROUTE=/^\/(families|start|winds\/.*)$/;
globalThis.fetch=async(input,init={})=>{
  const url=new URL(typeof input==='string'?input:input.url,location.origin);
  if(url.origin!==location.origin||!url.pathname.startsWith('/')||!ROUTE.test(url.pathname))return own(input,init);
  const method=(init.method??'GET').toUpperCase(),given=typeof init.body==='string'&&init.body?JSON.parse(init.body):undefined;
  const id=next++;
  return new Promise((resolve,reject)=>{waiting.set(id,{resolve,reject});worker.postMessage({id,method,path:url.pathname,query:url.search,given})});
};

// (The page's line: the winds here, in this browser; the strings later; the source.)
function line(){
  const note=document.createElement('div');note.className='muted';note.style.margin='0 0 10px';
  note.innerHTML='Wind instruments modelled by OpenWInD\'s scheme, played in this browser by the Musebots engine in WebAssembly '+
    '(<a href="SOURCES.html">its source, GPL-3.0</a>); the bowed strings come later. Press <b>space</b> or <b>blow</b> to sound it.';
  const say=document.createElement('span');
  fetch('/families').then(r=>r.json()).then(f=>{say.textContent=f.engine?.error?` The engine did not load: ${f.engine.error}`:
    f.engine?.threaded?'':' This browser gives the page one core (it is not cross-origin isolated): the larger instruments may play slower than real time.'});
  note.append(say);document.body.prepend(note);
}
if(document.readyState==='loading')addEventListener('DOMContentLoaded',line);else line();
window.addEventListener('load',()=>{if(window.live)window.live.kept=kept});
