// The live dial's page by itself, on a static site (scripts/build-live-site.mjs): its fetches of the dial's routes --
// /families, /start, /winds/..., /strings/... -- answered by the dials in Workers beside it (dial-worker.js the winds',
// strings-worker.js the strings', started the first time a string instrument is chosen) in place of the Mac's server
// (native/live/live.mjs), and the strings' event stream by theirs, so that live.html, winds.js and strings.js are the
// Mac's own, unchanged; everything else fetched as it is. Imported ahead of them. The strings' sound played here, as
// the Mac's host plays it through the Mac's audio (the winds' page pulls its own). A setting kept is kept in this
// browser (live.kept()); a line at the top says what plays here and where its source is.
const KEPT='musebots-live-dial-kept',STRINGS_KEPT='musebots-live-dial-strings-kept';
const kept=(key=KEPT)=>{try{return JSON.parse(localStorage.getItem(key)??'[]')}catch{return []}};
const keep=(key,record)=>{try{localStorage.setItem(key,JSON.stringify([...kept(key),record]))}catch{}};

// A Worker answering the routes: each request handed over with its id, its answer a Response.
function served(worker,{key,line}={}){
  const waiting=new Map;let next=0;
  worker.onmessage=({data})=>{
    if(data.said!==undefined){console.log(data.said);return}
    if(data.line!==undefined){line?.(data.line);return}
    if(data.kept){keep(key,data.kept);return}
    const {resolve}=waiting.get(data.id)??{};waiting.delete(data.id);
    if(!resolve)return;
    const headers=Object.fromEntries(Object.entries(data.headers??{}).map(([k,v])=>[k,String(v)]));
    resolve(data.samples?new Response(data.samples.buffer,{status:data.status,headers:{'content-type':'application/octet-stream',...headers}}):
      data.json!==undefined?new Response(JSON.stringify(data.json),{status:data.status,headers:{'content-type':'application/json'}}):
      new Response(data.text??null,{status:data.status}));
  };
  worker.onerror=error=>{for(const {reject} of waiting.values())reject(new Error(`the dial stopped: ${error.message??error}`));waiting.clear()};
  return (method,path,query,given)=>{const id=next++;
    return new Promise((resolve,reject)=>{waiting.set(id,{resolve,reject});worker.postMessage({id,method,path,query,given})})};
}
const winds=served(new Worker(new URL('dial-worker.js',document.baseURI),{type:'module'}),{key:KEPT});

// The strings' dial, started once, and those listening to it.
const listening=new Set;
let strings=null;
function stringsWorker(){
  if(strings)return strings;
  const worker=new Worker(new URL('strings-worker.js',document.baseURI),{type:'module'});
  const ask=served(worker,{key:STRINGS_KEPT,line:line=>{for(const listener of listening)listener(line)}});
  strings={worker,ask,ended:null,running:false};
  strings.ready=ask('GET','/state').then(async r=>{if(!r.ok)throw new Error(await r.text());strings.rate=(await r.json()).rate;strings.running=true;sound()},
    error=>{strings.ended=`the strings' dial stopped: ${error.message}`;throw error});
  strings.ready.catch(()=>{});
  worker.postMessage({listen:true});
  return strings;
}
const family=()=>({instruments:[],...strings?{running:strings.running,starting:!strings.running&&!strings.ended,ended:strings.ended}:{running:false,starting:false,ended:null}});
// (The families as the winds' dial says them, the strings' state as theirs is here.)
async function families(){
  const f=await (await winds('GET','/families')).json();
  f.strings={...f.strings,...family(),instruments:f.strings.instruments};
  return new Response(JSON.stringify(f),{headers:{'content-type':'application/json'}});
}
// (A setting kept is kept here; the list read and one forgotten here.)
function stringsKept(path,given){
  if(path==='/kept')return new Response(JSON.stringify(kept(STRINGS_KEPT)),{headers:{'content-type':'application/json'}});
  const all=kept(STRINGS_KEPT),left=all.filter(k=>k.at!==given?.at);
  if(left.length===all.length)return new Response(`nothing kept at ${given?.at}`,{status:404});
  try{localStorage.setItem(STRINGS_KEPT,JSON.stringify(left))}catch{}
  return new Response(JSON.stringify({left:left.length}),{headers:{'content-type':'application/json'}});
}

const own=globalThis.fetch.bind(globalThis);
const ROUTE=/^\/(families|start|winds\/.*|strings\/.*)$/;
globalThis.fetch=async(input,init={})=>{
  const url=new URL(typeof input==='string'?input:input.url,location.origin);
  if(url.origin!==location.origin||!url.pathname.startsWith('/')||!ROUTE.test(url.pathname))return own(input,init);
  const method=(init.method??'GET').toUpperCase(),given=typeof init.body==='string'&&init.body?JSON.parse(init.body):undefined;
  if(url.pathname==='/families')return families();
  if(url.pathname==='/start'){
    if(url.searchParams.get('family')!=='strings'){const r=await winds(method,url.pathname,url.search,given);if(!r.ok)return r}
    else try{await stringsWorker().ready}catch(error){return new Response(JSON.stringify({error:error.message}),{status:503,headers:{'content-type':'application/json'}})}
    return families();
  }
  const m=/^\/strings(\/.*)$/.exec(url.pathname);
  if(m){
    if(m[1]==='/kept'||m[1]==='/forget')return stringsKept(m[1],given);
    const {ask,ready}=stringsWorker();
    try{await ready}catch(error){return new Response(JSON.stringify({error:error.message}),{status:503,headers:{'content-type':'application/json'}})}
    return ask(method,m[1],url.search,given);
  }
  return winds(method,url.pathname,url.search,given);
};
// (The strings' event stream, /strings/events, from their dial here; any other as it is.)
const OwnEventSource=globalThis.EventSource;
globalThis.EventSource=class extends EventTarget{
  constructor(address,options){
    const url=new URL(address,location.origin);
    if(url.origin!==location.origin||url.pathname!=='/strings/events')return new OwnEventSource(address,options);
    super();this.url=url.href;this.readyState=0;this.onmessage=this.onopen=this.onerror=null;
    const heard=line=>{const e=new MessageEvent('message',{data:line});this.onmessage?.(e);this.dispatchEvent(e)};
    listening.add(heard);stringsWorker();
    this.close=()=>{listening.delete(heard);this.readyState=2};
    queueMicrotask(()=>{if(this.readyState===0){this.readyState=1;const e=new Event('open');this.onopen?.(e);this.dispatchEvent(e)}});
  }
};

// The strings' sound: their host's buffers, made in their Worker as this page's AudioWorklet asks for them (its port
// handed there), played once the page may sound -- its first press -- while the strings are shown, and let go some
// seconds after they are not, their bow lifted and rung down.
const RING=`class Ring extends AudioWorkletProcessor{constructor(){super();this.b=new Float32Array(sampleRate*2);this.r=0;this.w=0;this.n=0;this.got=0;this.t=0;
this.port.onmessage=({data})=>{this.out=data.port;this.out.onmessage=({data})=>{this.got+=data.length;for(let i=0;i<data.length&&this.n<this.b.length;i++){this.b[this.w]=data[i];this.w=(this.w+1)%this.b.length;this.n++}};this.ask()}}
ask(){this.out?.postMessage({n:this.n,got:this.got})}
process(_,outs){const o=outs[0];for(let i=0;i<o[0].length;i++){let v=0;if(this.n>0){v=this.b[this.r];this.r=(this.r+1)%this.b.length;this.n--}for(const c of o)c[i]=v}
if(++this.t%2===0)this.ask();return true}}registerProcessor('strings-ring',Ring);`;
const LET_GO=3;
let context=null,letting=null;
const shown=()=>document.querySelector('[data-family="strings"]')?.hidden===false;
async function sound(){
  if(!strings?.running||!shown()||!navigator.userActivation?.hasBeenActive)return;
  clearTimeout(letting);
  if(context){if(context.state==='suspended')context.resume();return}
  context=new AudioContext({sampleRate:strings.rate});
  await context.audioWorklet.addModule(URL.createObjectURL(new Blob([RING],{type:'text/javascript'})));
  const node=new AudioWorkletNode(context,'strings-ring',{numberOfInputs:0,outputChannelCount:[2]});node.connect(context.destination);
  const channel=new MessageChannel();
  strings.worker.postMessage({sound:channel.port2},[channel.port2]);node.port.postMessage({port:channel.port1},[channel.port1]);
}
for(const event of ['pointerdown','keydown'])addEventListener(event,()=>{sound()},true);
function watch(){
  new MutationObserver(()=>{if(shown())sound();else if(context?.state==='running'){clearTimeout(letting);letting=setTimeout(()=>{if(!shown())context.suspend()},LET_GO*1000)}})
    .observe(document.body,{subtree:true,attributes:true,attributeFilter:['hidden']});
}

// (The page's line: the winds and strings here, in this browser; the source.)
function line(){
  const note=document.createElement('div');note.className='muted';note.style.margin='0 0 10px';
  note.innerHTML='Wind instruments modelled by OpenWInD\'s scheme and bowed strings by Artifastring, played in this browser by the '+
    'Musebots engines in WebAssembly (<a href="SOURCES.html">their source, GPL-3.0</a>). Press <b>space</b> or <b>blow</b> to sound a wind, '+
    '<b>play</b> to bow a string.';
  const say=document.createElement('span');
  fetch('/families').then(r=>r.json()).then(f=>{say.textContent=f.engine?.error?` The engine did not load: ${f.engine.error}`:
    f.engine?.threaded?'':' This browser gives the page one core (it is not cross-origin isolated): the larger instruments may play slower than real time.'});
  note.append(say);document.body.prepend(note);watch();
}
if(document.readyState==='loading')addEventListener('DOMContentLoaded',line);else line();
window.addEventListener('load',()=>{if(window.live)window.live.kept=()=>kept()});
