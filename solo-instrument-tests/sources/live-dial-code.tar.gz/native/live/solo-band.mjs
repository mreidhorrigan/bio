// A musebot's piece for a live dial's instrument, each family's the same (the winds' native/openwind/soloist.mjs, the
// strings' native/strings-model/soloist.mjs): a 3.0 band -- plex_clodbot planning its harmony, MemoryBOT, and the
// instrument's one player -- composes it on the score engine (public/render/score-engine.js: the bots as in an audio
// render, their notes and no audio), its player told the dial's compass, the notes its engine plays (instrument-facts.js
// compass.engine), and what else its engine says it plays of its instrument -- the techniques and mutes it sounds, its
// quickest note (instrument-facts.js `engine`) -- learned through its instrument's MCP server as it starts, and given the
// levers and tone ranges of its personality the page sets, every other drawn from its seed (personality.js;
// docs/PLAYER_PERSONALITY.md), so that its personality is played as the dial's instrument is. Its line's rhythms are the
// rhythm engine's, the piece's as its personality leans them (settings.rhythm 'euclidean': line-rhythm.js; the owner,
// 4 November 2026: "I am hoping that the new rhythm engine will allow much faster and more rhythmically diverse
// passages"). Everything musical is the band's, drawn from its seed -- its meter,
// tempo, harmony, phrases, dynamics and ending (CLAUDE.md, "No musical default written"); the page gives the seed and the
// most it may play, the band ending it within that. In Node its WebAssembly read from the repository; in a website's
// Worker fetched beside it (scripts/build-live-site.mjs).
//
//   playerSettingsOf({seed, seconds, personality}) -> {seed, seconds, personality}, or why not
//   await composeBand({player: {id, instrument}, seed, seconds, compass: [low, high], engine, personality, plan}) ->
//     {player, seed, seconds (its music's), ump (the player's track), events (its MIDI 2.0 as captured), planned (with
//     `plan`, a bowed string's strokes planned for a physical model as a render plans them: {log, ump}), personality
//     (as its player drew it: its levers, grammars and tone ranges, those given, its register, its tone on its
//     instrument, its motif and its rhythm's shares), warnings}
//   wholeNotes(events) -> [{at, events}]: a line's MIDI 2.0 as its notes, each whole, as a musebot sends its line
import '../../public/meter.js';
import {normalizeRenderSpec,RenderSession,listRenderEngines,listHearings,listOutputFormats} from '../../public/render/index.js';
import {AGENTS} from '../../public/agents.js';
import {initializeMidi2,inspectUMP} from '../../public/shared/ump.js';
import {musicalCoreReady} from '../../public/shared/musical-core-installed.js';
import {LEVERS,TONE_RANGES} from '../../public/shared/performers/personality.js';
import {LINE} from '../../public/shared/performers/line.js';

// A player's settings as a page gives them: its seed, the most it plays, s, and the levers of its personality it is
// given, each a share 0 to 1 by its name (personality.js LEVERS) -- a motif grammar's under `grammars`, a tone range's,
// [low, high] shares, under `ranges` (TONE_RANGES) -- every other drawn from its seed. -> {seed, seconds, personality},
// or why not.
export function playerSettingsOf({seed,seconds,personality}={}){
  if(!Number.isInteger(seed)||seed<0)throw new RangeError('a seed, a whole number from 0');
  if(!(seconds>0))throw new RangeError('the most it plays, s');
  const share=v=>typeof v==='number'&&v>=0&&v<=1,given={};
  for(const [name,value] of Object.entries(personality??{})){
    if(name==='grammars'&&value&&typeof value==='object'){const grammars=Object.fromEntries(Object.entries(value).filter(([g,v])=>LINE.grammars.includes(g)&&share(v)));if(Object.keys(grammars).length)given.grammars=grammars}
    else if(name==='ranges'&&value&&typeof value==='object'){
      const ranges=Object.fromEntries(Object.entries(value).filter(([r,v])=>TONE_RANGES.includes(r)&&Array.isArray(v)&&v.length===2&&v.every(share)&&v[0]<=v[1]));
      if(Object.keys(ranges).length!==Object.keys(value).length)throw new RangeError(`a personality's tone ranges, each [low, high] shares 0 to 1, low first: ${TONE_RANGES.join(', ')}`);
      if(Object.keys(ranges).length)given.ranges=ranges}
    else if(LEVERS.includes(name)&&share(value))given[name]=value;
    else throw new RangeError(`a personality's levers, each a share 0 to 1: ${LEVERS.join(', ')}, grammars (${LINE.grammars.join(', ')}) and ranges (${TONE_RANGES.join(', ')})`);
  }
  return {seed,seconds,personality:given};
}
// (What a page is shown of a player's settings: what can be given, its personality's levers, motif grammars and tone
// ranges, with those last given.)
export const playerShown=settings=>({...settings,levers:LEVERS,grammars:LINE.grammars,ranges:TONE_RANGES});

// (The MIDI 2.0 codec and the bots' planning core, once: in Node read from the repository, as musical-core-installed.js
// reads its core; in a Worker fetched as ump.js fetches it, beside the page.)
let prepared=null;
const prepare=()=>prepared??=(async()=>{
  const url=new URL('../../public/wasm/midi2.wasm',import.meta.url),fs=globalThis.process?.getBuiltinModule?.('node:fs');
  await initializeMidi2(fs&&url.protocol==='file:'?{bytes:fs.readFileSync(url)}:{});
  await musicalCoreReady;
})();

// (A line's MIDI 2.0 as its notes, each whole: from its Per-Note Management -- or its first event on its key -- to the
// next note begun on that key, its Note Off and its release's controllers with it; what names no note -- a channel's,
// as its bend range -- with the note after it. Each at its first event's time.)
const PER_NOTE=new Set(['perNoteManagement','perNoteController','assignablePerNoteController','perNoteBend','perNotePressure','noteOn','noteOff']);
export function wholeNotes(events){
  const notes=[],open=new Map;let loose=[];
  for(const event of events){
    const m=inspectUMP(event.packet);
    if(!PER_NOTE.has(m.kind)){loose.push(event);continue}
    let note=open.get(m.key);
    if(!note||m.kind==='perNoteManagement'){note={at:loose[0]?.seconds??event.seconds,events:loose};loose=[];notes.push(note);open.set(m.key,note)}
    note.events.push(event);
  }
  if(loose.length&&notes.length)notes.at(-1).events.push(...loose);
  return notes;
}

export async function composeBand({player,seed,seconds,compass=null,engine=null,personality={},plan=false}){
  ({seed,seconds,personality}=playerSettingsOf({seed,seconds,personality}));
  await prepare();
  const told=compass?{compass:{instruments:{[player.instrument]:{low:compass[0],high:compass[1]}}}}:{};
  const spec=normalizeRenderSpec({version:1,seed,engine:'score',length:{seconds,untilEnding:true},outputs:{midi:true},
    bots:[{id:'plex_clodbot',output:'none',settings:{harmony:'plan'}},{id:'memory',output:'none'},{id:player.id,output:'synth',settings:{instrument:player.instrument,rhythm:'euclidean',...told,
      ...(engine?{engine}:{}),...(Object.keys(personality).length?{personality}:{})}}]},
    {agents:AGENTS,engines:listRenderEngines(),hearings:listHearings(),formats:listOutputFormats()});
  // (Its personality as it drew it, said as it starts: personality.js's report, a decision of its kind.)
  const drawn=[];
  const session=await RenderSession.create({spec,agents:AGENTS,sink:null,clips:new Map,environment:{captureEvents:true},
    logs:{decisions:{write:record=>{if(record.kind==='personality')drawn.push(record)}}},strict:false});
  // (Planned, as a render's first pass plans its strings: render/node/physical-strings.mjs.)
  if(plan)session.physical={mode:'plan',logs:new Map};
  const score=session.engine,result=await session.run();
  const [track,ump]=[...session.umpTracks].find(([id])=>id.startsWith(`bot:${player.id}:`))??[null,[]];
  const said=drawn[0],own=said?{levers:said.levers,grammars:said.grammars,ranges:said.ranges,given:said.given,register:said.register,tone:said.tone,engine:said.engine,motif:said.motif,rhythm:said.rhythm}:null;
  return {player,seed,seconds:result.musicSeconds,ump,events:score.captured.filter(c=>c.trackId===track).map(c=>c.event),
    planned:plan?session.physical.logs.get(track)??null:null,personality:own,
    warnings:[...(result.warnings??[]),...(result.errors??[]).map(String)]};
}
