// A musebot's piece composed and rendered before it is heard, on the live dial's page (winds.js; strings.js): the
// soloist's page given the studio's way of making a piece (the owner, 5 November 2026: "integrate the functionality of
// the soloist page with that of the composition-studio page so that the soloist page has an option to pre-compose and
// pre-render pieces of music (which will also give access to the soloist page to users whose computers aren't fast
// enough to run it in realtime)"). Its band composes the piece as for ▶ A musebot plays (the dial's /soloist), and the
// dial's sound is pulled (its /audio) as fast as its engine makes it -- faster or slower than real time -- rather than as
// the page plays it: the same engine on the same settings as dialled, its clock its frames made, so that what is heard is
// what the dial plays live (the winds' native/openwind/dial.mjs; the strings' runners, native/strings-model/live.mjs and
// site/strings-worker.js). Pulled until the piece has ended and its sound has rung down, then heard here and kept as a
// WAV, as the studio keeps a piece's (public/studio/outputs.js, public/shared/wav.js).
import {encodeWav} from '/public/shared/wav.js';

// (A pull: as many frames as the page pulls as it plays (winds.js BLOCK), so that its dial sends its musebot's notes as
// far ahead of the sound made as it does live -- in larger pulls a note sent less than a pull ahead comes late. Rung down
// once the piece has ended: pulled until a pull's peak is under QUIET_DB (dBFS: the page's silence, its pitch
// tracker's) or for RING_MOST s at most, the studio's tail after a piece's end (public/studio/band.js TAIL_SECONDS).)
const PULL=2048,QUIET_DB=-90,RING_MOST=8;
const clock=x=>`${Math.floor(x/60)}:${String(Math.floor(x%60)).padStart(2,'0')}`;
const dbOf=x=>x>0?20*Math.log10(x):-Infinity;

// (Its button, and in `box` what it is making and what it made: `family` the dial's routes (winds, strings), `rate()` its
// sound's, `given()` what its piece is asked with (musebot.js given), `named()` its instrument, for its file's name;
// `before()` the page's own playing put aside, `after()` taken up again.) -> {running(), stop()}: stop() ends a piece
// being made, nothing kept, before the page takes up another instrument -- its piece one instrument's. What it made said
// on `box`'s data too (seconds, the piece's own, peakDb, notes, pace), for a check, and only while it is the last made.
export function prerenderControls({family,button,box,rate,given,named,before=()=>{},after=()=>{}}){
  box.innerHTML='<div class="meter"><div></div></div><div class="muted renderSaid"></div><audio controls hidden></audio><a download hidden>Save it (WAV)</a>';
  const bar=box.querySelector('.meter div'),said=box.querySelector('.renderSaid'),audio=box.querySelector('audio'),save=box.querySelector('a');
  let running=false,stopping=false,url=null,ending=Promise.resolve();
  const say=text=>{said.textContent=text};
  const shown=share=>{bar.style.width=`${Math.round(100*Math.max(0,Math.min(1,share)))}%`};
  const answer=async r=>{const text=await r.text();try{return JSON.parse(text)}catch{return {error:text}}};
  const ask=(path,value)=>fetch(`/${family}${path}`,value?{method:'POST',body:JSON.stringify(value)}:{cache:'no-store'});

  // (Its piece composed and pulled from its dial to its end and rung down: -> {pulls, made (frames), took (s), piece},
  // or null where it was stopped.)
  async function render(){
    const r=await ask('/soloist',{on:true,...given()}),started=await answer(r);
    if(!r.ok||started.error)throw new Error(started.error??`the dial answered ${r.status}`);
    const piece=started.soloist.said,end=piece.start+piece.seconds,began=performance.now(),pulls=[];
    let made=0,ended=null;
    while(!stopping){
      const got=await fetch(`/${family}/audio?frames=${PULL}`,{cache:'no-store'});
      if(!got.ok)throw new Error(`its sound: ${(await answer(got)).error}`);
      const samples=new Float32Array(await got.arrayBuffer()),at=Number(got.headers.get('x-seconds'));
      pulls.push(samples);made+=samples.length;
      const pace=made/rate()/((performance.now()-began)/1000);
      if(ended==null){
        // (Asked whether it has ended only once its time is past: its last note may end after it.)
        if(at>=end){const s=await answer(await ask('/state'));if(!s.soloist?.playing){ended=made;Object.assign(piece,s.soloist?.said??{})}}
        shown((at-piece.start)/piece.seconds);
        say(`Rendering: ${clock(Math.max(0,Math.min(at-piece.start,piece.seconds)))} of ${clock(piece.seconds)} made, at ${Math.round(100*pace)} % of real time`);
      }else{
        say('Rendering: its sound ringing down');
        if(!(dbOf(samples.reduce((a,v)=>Math.max(a,Math.abs(v)),0))>QUIET_DB)||(made-ended)/rate()>=RING_MOST)break;
      }
    }
    if(stopping)return null;
    return {pulls,made,took:(performance.now()-began)/1000,piece};
  }
  // (What it made heard here, and kept: a WAV of what the dial played, as the studio writes one.)
  function heard({pulls,made,took,piece}){
    const all=new Float32Array(made);let at=0;for(const p of pulls){all.set(p,at);at+=p.length}
    const peak=all.reduce((a,v)=>Math.max(a,Math.abs(v)),0),seconds=made/rate();
    if(url)URL.revokeObjectURL(url);
    url=URL.createObjectURL(new Blob([encodeWav({sampleRate:rate(),channels:[all],format:'pcm24',dither:true})],{type:'audio/wav'}));
    audio.src=url;audio.hidden=false;save.href=url;save.hidden=false;
    save.download=`${named()}, ${piece.player}, seed ${piece.seed}, ${clock(seconds).replace(':','m')}s.wav`;
    shown(1);
    say(`Rendered: ${clock(seconds)} of sound in ${clock(took)}, at ${Math.round(100*seconds/took)} % of real time -- ${piece.notes} notes, ${piece.player}'s, seed ${piece.seed}`
      +(piece.late?`; ${piece.late} came late`:'')+(piece.unplayed?.length?`; ${piece.unplayed.length} not played here (${piece.unplayed[0].why})`:'')+'.');
    Object.assign(box.dataset,{seconds:seconds.toFixed(3),piece:String(piece.seconds),peakDb:dbOf(peak).toFixed(1),notes:String(piece.notes),pace:(seconds/took).toFixed(3)});
    audio.play().catch(()=>{});
  }

  button.onclick=()=>{
    if(running){stopping=true;return ending}
    running=true;stopping=false;box.hidden=false;audio.pause();
    // (What it made before said no longer: another instrument's, or another seed's.)
    for(const key of Object.keys(box.dataset))delete box.dataset[key];
    audio.hidden=true;save.hidden=true;
    button.textContent='■ Stop rendering';button.classList.add('on');shown(0);say('Its band composes the piece ...');
    return ending=(async()=>{
      try{
        await before();
        const made=await render();
        if(made)heard(made);
        else{await ask('/soloist',{on:false});say('Stopped: nothing kept.')}
      }catch(error){say(`Not rendered: ${error.message}`);ask('/soloist',{on:false}).catch(()=>{})}
      finally{running=false;button.textContent='Render its piece first';button.classList.remove('on');await after()}
    })();
  };
  return {running:()=>running,stop:()=>{if(running)stopping=true;return ending}};
}
