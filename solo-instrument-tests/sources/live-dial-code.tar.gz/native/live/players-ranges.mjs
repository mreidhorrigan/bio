// What real players were measured doing with each of the live dial's controls (the owner, 3 November 2026: "display on
// the instrument-soloist page ... the realistic ranges for each parameter"; "Displaying the realistic range should be
// done concisely on each slider"): each dial's state carries its instrument's (native/openwind/dial.mjs,
// native/strings-model/dial.mjs), and the page draws each as a band on its slider (native/live/players.js). Every range
// here is read from the measurements the renders and fits already use, never written here: a control nobody measured
// has none (null), and the page says so.
//
// An entry, in the dial's own units (s, Pa, rad/s, L, Hz, cents, N, a share of the string): {range: [low, high]} (either
// end null where only the other was measured), or {value} where one value was measured; or, for what changes with the
// pitch, {points: [[midi, low, high], ...]} -- each with `what` (whose, and what of them), `source` (short), and `by`
// where it is another instrument's players', borrowed, and said so.
import BREATHS from '../../render/synthesis/breath-literature.json' with {type:'json'};
import REEDS from '../../render/synthesis/reed-literature.json' with {type:'json'};
import {PLAYERS_BREATH,MOST} from '../../render/synthesis/src/brass-breath.mjs';
import {DEFAULT_INSTRUMENT_RANGES,instrumentRange} from '../../public/shared/performers/instrument-ranges.js';
import {LUNGS} from '../../public/shared/performers/lungs.js';
import {player,playerEntry} from '../../registry/registry.js';

const label=m=>m.replace(/-/g,' ');
const STEP={C:0,D:2,E:4,F:5,G:7,A:9,B:11};
// (A pitch as Fuks & Sundberg's tables name it, sounding: 'Eb3', 'Bb5'.)
const midiNamed=name=>{const m=/^([A-G])(b|#)?(-?\d)$/.exec(name);if(!m)throw new Error(`a pitch named ${name}`);return 12*(+m[3]+1)+STEP[m[1]]+(m[2]==='b'?-1:m[2]==='#'?1:0)};
const CM_H2O=98.0665;

// ---- the compass ----
// (Each instrument's players' compass, sounding: instrument-ranges.js, the dial's B-flat trumpet the C trumpet's, the
// only trumpet's compass there.)
function compassOf(model){
  const r=instrumentRange(DEFAULT_INSTRUMENT_RANGES[model]??model);
  if(!r?.range)return null;
  const host=String(r.sources?.[0]??'').match(/^https?:\/\/(?:www\.)?([^/]+)/)?.[1];
  return {range:[...r.range],what:`its players' compass (${r.name})`,source:host==='vsl.co.at'?'Vienna Symphonic Library':host==='phys.unsw.edu.au'?'Chen, Smith & Wolfe':host??'instrument-ranges.js',
    ...(model==='trumpet'?{by:'the C trumpet\'s'}:{})};
}

// ---- a reed player's breath: the mouth's pressure, pp to ff, at each pitch ----
// Fuks & Sundberg's two professional players of each of four instruments (breath-literature.json), each pitch's lowest
// pp and highest ff of the two, ascending and descending; an instrument they did not measure its family's, at the same
// written note (each instrument's transposition, instrument-ranges.js) -- the saxophones the alto's, the clarinets the B-flat
// clarinet's, the English horn the oboe's, the contrabassoon the bassoon's.
const MEASURED_BREATH={clarinet:'clarinet','e-flat-clarinet':'clarinet','bass-clarinet':'clarinet',oboe:'oboe','english-horn':'oboe',bassoon:'bassoon',contrabassoon:'bassoon',
  'soprano-saxophone':'alto-saxophone','alto-saxophone':'alto-saxophone','tenor-saxophone':'alto-saxophone','baritone-saxophone':'alto-saxophone'};
const transposition=model=>instrumentRange(DEFAULT_INSTRUMENT_RANGES[model]??model)?.writtenToSounding??0;
function reedBreath(model){
  const from=MEASURED_BREATH[model];
  if(!from)return null;
  const table=BREATHS[from].find(t=>t.source==='fuks-sundberg-1996'),shift=transposition(model)-transposition(from),at=new Map;
  table.pitches.forEach((name,k)=>{
    const midi=midiNamed(name)+shift,rows=Object.values(table.players);
    const low=Math.min(...rows.map(p=>p.pp?.[k]).filter(Number.isFinite)),high=Math.max(...rows.map(p=>p.ff?.[k]).filter(Number.isFinite));
    const was=at.get(midi);at.set(midi,was?[Math.min(was[0],low),Math.max(was[1],high)]:[low,high]);
  });
  return {points:[...at].sort((a,b)=>a[0]-b[0]).map(([midi,[low,high]])=>[midi,Math.round(low*CM_H2O),Math.round(high*CM_H2O)]),
    what:'the mouth\'s pressure two professional players blew, pp to ff',source:'Fuks & Sundberg 1996',...(from!==model?{by:`the ${label(from)}'s players, at the same written note`}:{})};
}
// A brass player's: the measured brass players' pp and ff lines in the note's frequency (brass-breath.mjs: Fletcher &
// Tarnopolsky's trumpeter, Bouhuys's tuba and C trumpet players), each widened by the factor its players lie within of
// it, never past the most measured in a brass player's mouth; the trombone's and the horn's borrowed, as the renders
// blow them.
function lipsBreath(model,compass){
  const [lo,hi]=compass?.range??[24,96],line=({at,slope},hz)=>Math.exp(at+slope*Math.log(hz)),points=[];
  for(let midi=lo;midi<=hi;midi++){
    const hz=440*2**((midi-69)/12);
    points.push([midi,Math.round(line(PLAYERS_BREATH.pp,hz)/PLAYERS_BREATH.pp.scatter),Math.round(Math.min(MOST,line(PLAYERS_BREATH.ff,hz)*PLAYERS_BREATH.ff.scatter))]);
  }
  return {points,what:'the mouth\'s pressure brass players blew, pp to ff',source:'Fletcher & Tarnopolsky 1999; Bouhuys 1965',
    ...(['trumpet','tuba'].includes(model)?{}:{by:'the trumpet and tuba players measured, at its pitch'})};
}

// ---- a reed's own: the published reeds' ----
// The reeds Chabassier & Auvray 2022 gather and the two papers after them (reed-literature.json), each in OpenWInD's
// terms (its excitator.py get_dimensionless_values): its resonance ω_r = 2π hz, its quality factor ω_r over its damping,
// its closing pressure ω_r² (M_r/S_r) y_0 -- or its stiffness per area times its opening, where that was measured.
// A clarinet's for the clarinets, a (tenor) saxophone's for the saxophones; none published for a double reed.
const REED_KIND={clarinet:'clarinet','e-flat-clarinet':'clarinet','bass-clarinet':'clarinet',
  'soprano-saxophone':'saxophone','alto-saxophone':'saxophone','tenor-saxophone':'saxophone','baritone-saxophone':'saxophone'};
const spanOf=values=>values.length?values.length>1?{range:[Math.min(...values),Math.max(...values)]}:{value:values[0]}:null;
function reedOwn(model){
  const kind=REED_KIND[model];
  if(!kind)return {};
  const reeds=REEDS.reeds.filter(r=>r.instrument===kind),omega=r=>2*Math.PI*r.hz;
  const about=(what,values)=>{const s=spanOf(values);return s&&{...s,what:`${what}, ${values.length} published ${kind} reed${values.length>1?'s':''}`,source:'Chabassier & Auvray 2022; Muñoz Arancón et al. 2016; Tonetti & Piana 2025',
    ...(kind==='saxophone'&&model!=='tenor-saxophone'?{by:'a tenor saxophone\'s reeds'}:{})}};
  return {
    pulsation:about('its resonance',reeds.filter(r=>r.hz>0).map(omega)),
    qfactor:about('its quality factor',reeds.filter(r=>r.hz>0&&r.dissip>0).map(r=>omega(r)/r.dissip)),
    closing_pressure:about('its closing pressure',reeds.map(r=>r.hz>0&&r.massPerArea>0&&r.opening>0?omega(r)**2*r.massPerArea*r.opening:r.stiffness>0&&r.opening>0?r.stiffness*r.opening:null).filter(Number.isFinite)),
  };
}

// ---- the tongue, the breath taken, the repeats ----
// The tongue's contact, a stroke: clarinettists' portato, a deviation under its mean, to their staccato at two notes a
// second (registry/players/winds.json reed-woodwind tongue: Pàmies-Vilà, Hofmann & Chatziioannou 2018); every other
// wind's players borrowed from them. Repeats: single tonguing to some 8 notes a second (brass players: Bertsch & Hoole
// 2014). A breath: wind players' vital capacity, two deviations either side (lungs.js: Bouros et al. 2018), as much of
// it as they were measured spending in one (Cossette, Sliwinski & Macklem 2000); taken in no faster than reed players'
// fastest, some 300 ms (Fuks & Sundberg 1998), and as slowly as a singer's full breath.
function tongueOf(model){
  const portato=playerEntry('reed-woodwind','tongue.portato.contact'),staccato=player('reed-woodwind','tongue.staccato.contact');
  const clarinets=['clarinet','e-flat-clarinet','bass-clarinet'].includes(model);
  return {range:[+(portato.value-portato.sd).toFixed(3),Math.max(...staccato.map(([,s])=>s))],what:'the tongue\'s contact, portato to staccato at two notes a second',
    source:'Pàmies-Vilà, Hofmann & Chatziioannou 2018',...(clarinets?{}:{by:'clarinettists\''})};
}
function breathTaken(){
  const {capacity,spent}=LUNGS,low=Math.max(0,capacity.litres-2*capacity.sd)*spent.share,high=(capacity.litres+2*capacity.sd)*spent.share;
  return {litres:{range:[+low.toFixed(2),+high.toFixed(2)],what:`a breath: ${Math.round(100*spent.share)} % of wind players' vital capacity, two deviations either side`,source:'Bouros et al. 2018; Cossette, Sliwinski & Macklem 2000'},
    inhale:{range:[.3,LUNGS.inhale.seconds],what:'a breath taken in: reed players\' fastest to a singer\'s full breath',source:'Fuks & Sundberg 1998; Salomoni, van den Hoorn & Hodges 2016'}};
}

// A wind's: keyed by the page's controls (native/live/winds.js), each null where nobody measured it.
export function windsRanges(model,kind){
  const compass=compassOf(model),{litres,inhale}=breathTaken();
  return {pitch:compass,
    breath:kind==='reed'?reedBreath(model):kind==='lips'?lipsBreath(model,compass):null,
    columns:kind==='reed'?reedOwn(model):{},
    stroke:tongueOf(model),softSeconds:null,rise:null,
    repeatRate:{range:[null,8],what:'single tonguing, some 8 notes a second (double some 11.5)',source:'Bertsch & Hoole 2014',...(kind==='lips'?{}:{by:'brass players\''})},
    litres,inhale,vibratoWidth:null,vibratoRate:null,flutterHz:null,flutterDepth:null,humInterval:null,humLevel:null};
}

// A bowed string's (native/live/strings.js): its contact point, near the bridge to over the fingerboard, and the most
// force, as violinists and violists were measured bowing (Schoonderwaldt 2009); its vibrato where it was measured for
// the instrument (registry/players/bowed.json); the stopping finger's damping a fingertip's (Wiertlewski & Hayward 2012),
// the dial's 1.
export function stringsRanges(name){
  const measured=path=>{try{const e=playerEntry(name,path);return e.kind==='literature'?e:null}catch{return null}};
  const rate=measured('vibrato.rate'),width=measured('vibrato.width'),contacts=playerEntry('violin-family','contacts'),force=playerEntry('violin-family','mostForce');
  const by=name==='violin'||name==='viola'?{}:{by:'violinists\' and violists\''};
  return {pitch:compassOf(name),
    beta:{range:[...contacts.range],what:'the contact point players bow at, a share of the string from the bridge',source:'Schoonderwaldt 2009',...by},
    force:{range:[null,force.value],what:'the most bow force players were seen to use',source:'Schoonderwaldt 2009',...by},
    speed:null,damping:{value:1,what:'a fingertip\'s measured damping',source:'Wiertlewski & Hayward 2012'},
    width:width?{value:width.value,what:`its players' vibrato, peak to peak`,source:width.source}:null,
    rate:rate?{value:rate.value,what:'its players\' vibrato',source:rate.source}:null};
}
