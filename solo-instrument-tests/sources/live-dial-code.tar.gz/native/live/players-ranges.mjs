// What real players were measured doing with each of the live dial's controls (the owner, 3 November 2026: "display on
// the instrument-soloist page ... the realistic ranges for each parameter"; "Displaying the realistic range should be
// done concisely on each slider"): each dial's state carries its instrument's (native/openwind/dial.mjs,
// native/strings-model/dial.mjs), and the page draws each as a band on its slider (native/live/players.js). Every range
// here is read from the measurements the renders and fits already use, never written here: a control nobody measured
// has none (null), and the page says so.
//
// An entry, in the dial's own units (s, Pa, rad/s, L, Hz, cents, N, a share of the string): {range: [low, high]} (either
// end null where only the other was measured), or {value} where one value was measured; or, for what changes with the
// pitch, {points: [[midi, low, high], ...]} -- each with `what` (whose, and what of them), `source` (short), and `by`
// where it is another instrument's players', borrowed, and said so.
import BREATHS from '../../render/synthesis/breath-literature.json' with {type:'json'};
import REEDS from '../../render/synthesis/reed-literature.json' with {type:'json'};
import {PLAYERS_BREATH,MOST} from '../../render/synthesis/src/brass-breath.mjs';
import {DEFAULT_INSTRUMENT_RANGES,instrumentRange} from '../../public/shared/performers/instrument-ranges.js';
import {LUNGS} from '../../public/shared/performers/lungs.js';
import {player,playerEntry} from '../../registry/registry.js';

const label=m=>m.replace(/-/g,' ');
const STEP={C:0,D:2,E:4,F:5,G:7,A:9,B:11};
// (A pitch as Fuks & Sundberg's tables name it, sounding: 'Eb3', 'Bb5'.)
const midiNamed=name=>{const m=/^([A-G])(b|#)?(-?\d)$/.exec(name);if(!m)throw new Error(`a pitch named ${name}`);return 12*(+m[3]+1)+STEP[m[1]]+(m[2]==='b'?-1:m[2]==='#'?1:0)};
const CM_H2O=98.0665;

// ---- the compass ----
// (Each instrument's players' compass, sounding: instrument-ranges.js, the dial's B-flat trumpet the C trumpet's, the
// only trumpet's compass there.)
function compassOf(model){
  const r=instrumentRange(DEFAULT_INSTRUMENT_RANGES[model]??model);
  if(!r?.range)return null;
  const host=String(r.sources?.[0]??'').match(/^https?:\/\/(?:www\.)?([^/]+)/)?.[1];
  return {range:[...r.range],what:`The range of notes its players play (${r.name}).`,source:host==='vsl.co.at'?'Vienna Symphonic Library':host==='phys.unsw.edu.au'?'Chen, Smith & Wolfe':host??'instrument-ranges.js',
    ...(model==='trumpet'?{by:'the C trumpet'}:{})};
}

// ---- a reed player's breath: the mouth's pressure, pp to ff, at each pitch ----
// Fuks & Sundberg's two professional players of each of four instruments (breath-literature.json), each pitch's lowest
// pp and highest ff of the two, ascending and descending; an instrument they did not measure its family's, at the same
// written note (each instrument's transposition, instrument-ranges.js) -- the saxophones the alto's, the clarinets the B-flat
// clarinet's, the English horn the oboe's, the contrabassoon the bassoon's.
const MEASURED_BREATH={clarinet:'clarinet','e-flat-clarinet':'clarinet','bass-clarinet':'clarinet',oboe:'oboe','english-horn':'oboe',bassoon:'bassoon',contrabassoon:'bassoon',
  'soprano-saxophone':'alto-saxophone','alto-saxophone':'alto-saxophone','tenor-saxophone':'alto-saxophone','baritone-saxophone':'alto-saxophone'};
const transposition=model=>instrumentRange(DEFAULT_INSTRUMENT_RANGES[model]??model)?.writtenToSounding??0;
function reedBreath(model){
  const from=MEASURED_BREATH[model];
  if(!from)return null;
  const table=BREATHS[from].find(t=>t.source==='fuks-sundberg-1996'),shift=transposition(model)-transposition(from),at=new Map;
  table.pitches.forEach((name,k)=>{
    const midi=midiNamed(name)+shift,rows=Object.values(table.players);
    const low=Math.min(...rows.map(p=>p.pp?.[k]).filter(Number.isFinite)),high=Math.max(...rows.map(p=>p.ff?.[k]).filter(Number.isFinite));
    const was=at.get(midi);at.set(midi,was?[Math.min(was[0],low),Math.max(was[1],high)]:[low,high]);
  });
  return {points:[...at].sort((a,b)=>a[0]-b[0]).map(([midi,[low,high]])=>[midi,Math.round(low*CM_H2O),Math.round(high*CM_H2O)]),
    what:'The pressure in the mouths of two professional players, from their softest (pp) to their loudest (ff) at this note.',source:'Fuks & Sundberg 1996',...(from!==model?{by:`${label(from)} players, at the same written note`}:{})};
}
// A brass player's: the measured brass players' pp and ff lines in the note's frequency (brass-breath.mjs: Fletcher &
// Tarnopolsky's trumpeter, Bouhuys's tuba and C trumpet players), each widened by the factor its players lie within of
// it, never past the most measured in a brass player's mouth; the trombone's and the horn's borrowed, as the renders
// blow them.
function lipsBreath(model,compass){
  const [lo,hi]=compass?.range??[24,96],line=({at,slope},hz)=>Math.exp(at+slope*Math.log(hz)),points=[];
  for(let midi=lo;midi<=hi;midi++){
    const hz=440*2**((midi-69)/12);
    points.push([midi,Math.round(line(PLAYERS_BREATH.pp,hz)/PLAYERS_BREATH.pp.scatter),Math.round(Math.min(MOST,line(PLAYERS_BREATH.ff,hz)*PLAYERS_BREATH.ff.scatter))]);
  }
  return {points,what:'The pressure in brass players\' mouths, from their softest (pp) to their loudest (ff) at this pitch.',source:'Fletcher & Tarnopolsky 1999; Bouhuys 1965',
    ...(['trumpet','tuba'].includes(model)?{}:{by:'trumpet and tuba players, at the same pitch'})};
}

// ---- a reed's own: the measured reeds' ----
// Each column's band the reed as measured while a player played it (reed-literature.json `reeds` under a player's lip:
// Chatziioannou & van Walstijn 2012, Chatziioannou 2010, Muñoz Arancón et al. 2016), in OpenWInD's terms (its
// excitator.py get_dimensionless_values): its resonance ω_r = 2π hz, its quality factor ω_r over its damping, its
// closing pressure its stiffness per area times its opening. Where nobody measured it in playing, the reed alone
// (`measured`: no lip), said so; what was measured under a machine's lip, and alone, said beside it, never mixed into
// it; the simulations' chosen reeds Chabassier & Auvray gather left out. A clarinet's for the clarinets, a tenor
// saxophone's for the saxophones but each size's own where it was measured; none published for a double reed.
const REED_KIND={clarinet:'clarinet','e-flat-clarinet':'clarinet','bass-clarinet':'clarinet',
  'soprano-saxophone':'saxophone','alto-saxophone':'saxophone','tenor-saxophone':'saxophone','baritone-saxophone':'saxophone'};
const spanOf=values=>values.length?values.length>1?{range:[Math.min(...values),Math.max(...values)]}:{value:values[0]}:null;
const hzText=values=>{const [lo,hi]=[Math.min(...values),Math.max(...values)];return lo===hi?`${Math.round(lo)}`:`${Math.round(lo)}-${Math.round(hi)}`};
function reedOwn(model){
  const kind=REED_KIND[model];
  if(!kind)return {};
  const size=model.replace(/-saxophone$/,''),mine=r=>r.instrument===kind&&(!r.size||kind!=='saxophone'||r.size===size);
  const played=REEDS.reeds.filter(r=>r.instrument===kind&&r.lip==='player'),machine=REEDS.reeds.filter(r=>r.instrument===kind&&r.lip==='foam');
  const alone=REEDS.measured.filter(r=>r.condition==='alone'&&r.instrument===kind),aloneMine=alone.filter(mine);
  const by=kind==='saxophone'&&model!=='tenor-saxophone'?{by:'a tenor saxophone\'s reed'}:kind==='clarinet'&&model!=='clarinet'?{by:'a B-flat clarinet\'s reed'}:{};
  const aloneHz=alone.flatMap(r=>r.hzRange??(r.hz?[r.hz]:[])),machineHz=machine.filter(r=>r.hz).map(r=>r.hz);
  const said=parts=>parts.filter(Boolean).join(' ');
  // (Its resonance: in playing where measured, else alone.)
  const playedHz=played.filter(r=>r.hz>0).map(r=>r.hz);
  const pulsation=playedHz.length?{...spanOf(playedHz.map(h=>2*Math.PI*h)),what:said([`The reed's resonance while a player plays it, the lip on it: ${hzText(playedHz)} Hz.`,aloneHz.length&&`The reed alone, with no lip on it: ${hzText(aloneHz)} Hz.`,machineHz.length&&`Under a playing machine's foam lip: ${hzText(machineHz)} Hz.`]),
      source:'Chatziioannou & van Walstijn 2012; Chatziioannou 2010; Gaillard, Koehl & Gazengel 2024',...by}
    :aloneHz.length?{...spanOf(alone.flatMap(r=>r.hz?[r.hz]:[]).map(h=>2*Math.PI*h)),what:said([`The reed's resonance alone, with no lip on it: ${hzText(aloneHz)} Hz. Nobody has measured it while a player plays it.`,machineHz.length&&`Under a playing machine's foam lip: ${hzText(machineHz)} Hz.`]),
      source:'Tonetti & Piana 2025',...by}:null;
  // (Its quality factor: the same.)
  const playedQ=played.filter(r=>r.hz>0&&r.dissip>0).map(r=>2*Math.PI*r.hz/r.dissip),aloneQ=alone.flatMap(r=>r.qRange??(r.q?[r.q]:[])),machineQ=machine.filter(r=>r.hz>0&&r.dissip>0).map(r=>2*Math.PI*r.hz/r.dissip);
  const qText=values=>{const [lo,hi]=[Math.min(...values),Math.max(...values)];return lo===hi?lo.toFixed(1):`${lo.toFixed(1)}-${hi.toFixed(1)}`};
  const qfactor=playedQ.length?{...spanOf(playedQ),what:said([`How lightly the reed is damped (its Q, no unit) while a player plays it: ${qText(playedQ)}.`,aloneQ.length&&`The reed alone, with no lip on it: ${qText(aloneQ)}.`]),source:'Chatziioannou & van Walstijn 2012; Chatziioannou 2010; Gaillard, Koehl & Gazengel 2024',...by}
    :aloneQ.length?{...spanOf(alone.flatMap(r=>r.q?[r.q]:[])),what:said([`How lightly the reed is damped (its Q, no unit) alone, with no lip on it: ${qText(aloneQ)}. Nobody has measured it while a player plays it; a lip damps it more.`,machineQ.length&&`Under a playing machine's foam lip: ${qText(machineQ)}.`]),source:'Tonetti & Piana 2025',...by}:null;
  // (Its closing pressure: its stiffness per area times its opening, both measured under a player's lip; its stiffness
  // alone, each size's where measured, said beside.)
  const shut=played.filter(r=>r.stiffness>0&&r.opening>0).map(r=>r.stiffness*r.opening);
  const stiffAlone=aloneMine.flatMap(r=>r.stiffnessRange??(r.stiffness?[r.stiffness]:[])).map(k=>(k/1e6).toFixed(1));
  const closing_pressure=shut.length?{...spanOf(shut),what:said([`The pressure that pushes the reed shut while a player plays it (its stiffness times its opening): ${hzText(shut)} Pa.`,stiffAlone.length&&`The reed's stiffness alone: ${[...new Set(stiffAlone)].join(', ')} MPa per metre.`]),
    source:'Muñoz Arancón et al. 2016; Chatziioannou 2010; Gaillard, Koehl & Gazengel 2024 (Nederveen 1969)',...by}:null;
  // (Its stiffening as it nears the lay, measured in playing: not the engine's contact, which acts once it is shut.)
  const nonlinear=played.filter(r=>r.nonlinearStiffness).map(r=>r.nonlinearStiffness);
  const contact_stifness=nonlinear.length?{value:null,what:`How much stiffer the reed grows as it bends towards the mouthpiece, measured while played: ${nonlinear.map(k=>k.toExponential(1)).join(', ')} N/m⁴. This slider is something else: the model's stiffness once the reed is fully shut, which nobody has measured.`,
    source:'Gaillard, Koehl & Gazengel 2024, Table A7',...by}:null;
  return {pulsation,qfactor,closing_pressure,contact_stifness};
}

// ---- the tongue, the breath taken, the repeats ----
// The tongue's contact, a stroke: clarinettists' portato, a deviation under its mean, to their staccato at two notes a
// second (registry/players/winds.json reed-woodwind tongue: Pàmies-Vilà, Hofmann & Chatziioannou 2018); every other
// wind's players borrowed from them. Repeats: single tonguing to some 8 notes a second (brass players: Bertsch & Hoole
// 2014). A breath: wind players' vital capacity, two deviations either side (lungs.js: Bouros et al. 2018), as much of
// it as they were measured spending in one (Cossette, Sliwinski & Macklem 2000); taken in no faster than reed players'
// fastest, some 300 ms (Fuks & Sundberg 1998), and as slowly as a singer's full breath.
function tongueOf(model){
  const portato=playerEntry('reed-woodwind','tongue.portato.contact'),staccato=player('reed-woodwind','tongue.staccato.contact');
  const clarinets=['clarinet','e-flat-clarinet','bass-clarinet'].includes(model);
  return {range:[+(portato.value-portato.sd).toFixed(3),Math.max(...staccato.map(([,s])=>s))],what:'How long the tongue touches the reed, from portato to staccato, at two notes a second.',
    source:'Pàmies-Vilà, Hofmann & Chatziioannou 2018',...(clarinets?{}:{by:'clarinettists'})};
}
function breathTaken(){
  const {capacity,spent}=LUNGS,low=Math.max(0,capacity.litres-2*capacity.sd)*spent.share,high=(capacity.litres+2*capacity.sd)*spent.share;
  return {litres:{range:[+low.toFixed(2),+high.toFixed(2)],what:`The air in one breath: ${Math.round(100*spent.share)} % of what wind players' lungs hold, from two standard deviations below the average to two above.`,source:'Bouros et al. 2018; Cossette, Sliwinski & Macklem 2000'},
    inhale:{range:[.3,LUNGS.inhale.seconds],what:'How long a breath takes to draw in: from reed players\' quickest to a singer\'s full breath.',source:'Fuks & Sundberg 1998; Salomoni, van den Hoorn & Hodges 2016'}};
}

// A wind's: keyed by the page's controls (native/live/winds.js), each null where nobody measured it.
export function windsRanges(model,kind){
  const compass=compassOf(model),{litres,inhale}=breathTaken();
  return {pitch:compass,
    breath:kind==='reed'?reedBreath(model):kind==='lips'?lipsBreath(model,compass):null,
    columns:kind==='reed'?reedOwn(model):{},
    stroke:tongueOf(model),softSeconds:null,rise:null,
    repeatRate:{range:[null,8],what:'The fastest repeated notes with single tonguing: about 8 a second (about 11.5 with double tonguing).',source:'Bertsch & Hoole 2014',...(kind==='lips'?{}:{by:'brass players'})},
    litres,inhale,vibratoWidth:null,vibratoRate:null,flutterHz:null,flutterDepth:null,humInterval:null,humLevel:null};
}

// A bowed string's (native/live/strings.js): its contact point, near the bridge to over the fingerboard, and the most
// force, as violinists and violists were measured bowing (Schoonderwaldt 2009); its vibrato where it was measured for
// the instrument (registry/players/bowed.json); the stopping finger's damping a fingertip's (Wiertlewski & Hayward 2012),
// the dial's 1.
export function stringsRanges(name){
  const measured=path=>{try{const e=playerEntry(name,path);return e.kind==='literature'?e:null}catch{return null}};
  const rate=measured('vibrato.rate'),width=measured('vibrato.width'),contacts=playerEntry('violin-family','contacts'),force=playerEntry('violin-family','mostForce');
  const by=name==='violin'||name==='viola'?{}:{by:'violinists and violists'};
  return {pitch:compassOf(name),
    beta:{range:[...contacts.range],what:'Where players put the bow on the string, as a share of the string\'s length from the bridge.',source:'Schoonderwaldt 2009',...by},
    force:{range:[null,force.value],what:'The most force players were seen pressing the bow into the string.',source:'Schoonderwaldt 2009',...by},
    speed:null,damping:{value:1,what:'How much a fingertip damps the string it stops, as measured.',source:'Wiertlewski & Hayward 2012'},
    width:width?{value:width.value,what:'How wide its players\' vibrato swings, from lowest to highest pitch.',source:width.source}:null,
    rate:rate?{value:rate.value,what:'How fast its players\' vibrato swings.',source:rate.source}:null};
}
