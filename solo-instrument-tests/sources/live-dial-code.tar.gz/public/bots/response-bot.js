import {Agent, defineBot} from '../framework/index.js';
import {actor, sameActor, frozenJson, planReference} from '../shared/planning-data.js';
import {overplanReference} from '../shared/overplanning.js';
import {validateMotif} from '../shared/motifs.js';
import {InputReportClient} from '../shared/estimation/input-report.js';
import {continuousInfluence} from '../shared/estimation/influence-policy.js';
import {responseProfile,responseTiming} from '../shared/estimation/response-profile.js';
import {serveProfileQuery} from '../shared/estimation/profile-report.js';

const freeze = value => frozenJson(value).data;
const names = ['C', 'Cs', 'D', 'Eb', 'E', 'F', 'Fs', 'G', 'Ab', 'A', 'Bb', 'B'];
const retain = (array, value, limit = 128) => { array.push(value); if (array.length > limit) array.shift(); };
const usable = (evidence, kind) => Boolean(evidence?.report?.coverage === 'complete' && !evidence.stale &&
  !evidence.report.possibleSelfOutput && evidence.report.role !== 'mixture' &&
  evidence[`${kind}AgeSeconds`] !== null && evidence[`${kind}AgeSeconds`] <= 3);

export class ResponseBot extends Agent {
  constructor(send, audio) { super(send, audio); this.evidence = []; this.decisions = []; this.enabled = false; }
  async start() { this.audio?.report?.('bot_status', {state: 'idle', message: 'Choose an input and response style, then enable responses.'}); }
  onTick() {} // The ordinary maintenance pump schedules prepared clips; receipt never plays a note.
  connectInput({source, runtime, mode = 'follow-timing', ownPeriod = .5}) {
    if (!['follow-timing', 'keep-pulse'].includes(mode) || !Number.isFinite(ownPeriod) || ownPeriod < .25 || ownPeriod > 1)
      throw new Error('Choose a response style and a period from 0.25 to 1 second.');
    this.setFuturePlanning(runtime); this.identity = actor(runtime.identity);
    this.input = new InputReportClient({identity: this.identity, source, send: this.send, now: () => runtime.now()});
    this.inputAvailable=true;this.inputAvailabilityReason=null;this.inputRouteVersion=null;
    this.mode = mode; this.period = ownPeriod; this.register = 60; this.previousProposalAt = runtime.now();
    this.count = 0; this.nextBeat = null; this.currentDecision = null; this.enabled = true;
  }
  onMessage(message) {
    if(serveProfileQuery(this,message,{now:this.futurePlanning?.now()??performance.now()/1000}))return;
    if (this.input && message.address === '/agent/estimation/response') {
      if(this.inputAvailable===false)return;
      try { this.input.receive(message); } catch (error) { this.lastError = error.message; }
      return;
    }
    super.onMessage(message);
  }
  updateInputPublisher({identity,source}) {
    if(!this.enabled||!this.input)return false;
    identity=actor(identity);source=actor(source);
    if(sameActor(identity,this.input.identity)&&sameActor(source,this.input.source))return false;
    this.bindingChanges||=[];
    retain(this.bindingChanges,freeze({at:this.futurePlanning.now(),previousPublisher:this.input.identity,
      publisher:identity,previousSource:this.input.source,source,executionIdentity:this.identity}),16);
    // The local executor identity and committed plans stay pinned. Only the
    // transport endpoints change; old pending replies cannot enter new input.
    this.input=new InputReportClient({identity,source,send:this.send,now:()=>this.futurePlanning.now()});
    return true;
  }
  setInputAvailability(available,reason=null,routeVersion=null) {
    if(!this.enabled||!this.input||this.inputAvailable===available&&this.inputRouteVersion===routeVersion)return false;
    // Retire pending requests and source evidence at a routing discontinuity.
    // Existing local execution identity, sealed decisions and plans stay fixed.
    const {identity,source}=this.input;
    this.input=new InputReportClient({identity,source,send:this.send,now:()=>this.futurePlanning.now()});
    this.inputAvailable=available;this.inputAvailabilityReason=available?null:reason;this.inputRouteVersion=routeVersion;
    return true;
  }
  propose(evidence, startBeat, scope) {
    const runtime = this.futurePlanning, now = runtime.now(), report = evidence?.report;
    const timing = usable(evidence, 'timing') && report.timing?.state === 'tracking' ? report.timing : null;
    // Explicit conversion from the reported rational note unit to a quarter.
    const quarterPeriod = timing ? timing.periodSeconds * timing.referencePulse.denominator / (4 * timing.referencePulse.numerator) : null;
    const base = {botId: this.identity.id, version: 'response-policy-v1', authorityScope: scope,
      unknownInputPolicy: 'hold', gain: .5, maxAgeSeconds: 3, sources: report ? [{sourceId: report.sourceId, artisticWeight: 1}] : []};
    const belief = (parameter, units, value, evidenceAge) => report && value !== null ? [{
      beliefId: report.reportId, sourceId: report.sourceId, sourceIncarnation: report.sourceIncarnation,
      revision: Math.max(1, report.sequence), stateSchema: parameter, units, value,
      lastEvidenceAt: now - evidenceAge, availableAt: evidence.receivedAt, receivedAt: evidence.receivedAt,
      trackingState: 'tracking', possibleSelfOutput: report.possibleSelfOutput,
      calibrationStatus: report.clock.calibrationStatus,
    }] : [];
    const common = {now, previousProposalAt: this.previousProposalAt, effectiveAt: runtime.timeline.referenceAtBeat(startBeat),
      decisionDeadline: runtime.timeline.referenceAtBeat(startBeat - 1), expiresAt: runtime.timeline.referenceAtBeat(startBeat + 16)};
    const period = continuousInfluence({...common, current: this.period, proposalId: `response-period:${this.count}`,
      policy: {...base, parameter: 'quarter-period', units: 'seconds-per-quarter', mode: this.mode === 'follow-timing' ? 'follow' : 'maintain',
        minimum: .25, maximum: 1, maxRatePerSecond: .08},
      beliefs: belief('quarter-period', 'seconds-per-quarter', quarterPeriod, evidence?.timingAgeSeconds)});
    const pitches = usable(evidence, 'pitch') ? report.pitches : [], mean = pitches.length ? pitches.reduce((a, b) => a + b, 0) / pitches.length : null;
    const register = continuousInfluence({...common, current: this.register, proposalId: `response-register:${this.count}`,
      policy: {...base, parameter: 'pitch-register', units: 'MIDI-semitones', mode: this.mode === 'keep-pulse' ? 'follow' : 'maintain',
        minimum: 36, maximum: 84, maxRatePerSecond: 6},
      beliefs: belief('pitch-register', 'MIDI-semitones', mean, evidence?.pitchAgeSeconds)});
    this.period = period.result.target; this.register = register.result.target; this.previousProposalAt = now;
    return {period, register, pitches};
  }
  async prepareResponse() {
    const runtime = this.futurePlanning;
    if (!this.enabled || !runtime?.ready()) return;
    const generation = this.responseGeneration || 0, map = runtime.timeline, now = runtime.now();
    const startBeat = this.nextBeat !== null && this.nextBeat >= map.beatAtReference(now) + 6.5
      ? this.nextBeat : map.futureBoundary(now, 2);
    const occurrenceId = `response:${++this.count}`, scope = {mode: 'local', membershipId: occurrenceId, participants: [this.identity]};
    const evidence = this.input.snapshot(),previousTargets={periodSeconds:this.period,register:this.register},mode=this.mode;
    const proposals = this.propose(evidence, startBeat, scope);
    // The explicit 12-EDO vocabulary is the only source of major/minor labels.
    const harmony = usable(evidence, 'pitch') ? evidence.report.harmony : null;
    const label = harmony?.status === 'interpreted' && harmony.vocabularyId === 'major-minor-triads-12' && harmony.tuningId === '12-equal'
      ? harmony.candidates[0]?.label : null;
    const rootName = label?.split('-')[0], rootClass = names.indexOf(rootName);
    const anchor = proposals.pitches[0] ?? this.register;
    const root = rootClass >= 0 ? Math.max(36, Math.min(83, Math.round((this.register - rootClass) / 12) * 12 + rootClass)) :
      Math.max(36, Math.min(83, anchor + 12 * Math.round((this.register - anchor) / 12)));
    const over = {version: 1, guardVersion: 1, author: this.identity.id, authorIncarnation: this.identity.incarnation,
      overplanId: 'input-response', revision: 1, occurrenceId, sessionId: map.sessionId, epoch: map.epoch,
      // Whole local pulses preserve this bot's phase between phrases, even
      // when its independent period is not a divisor of the room's bar.
      tempoId: map.id, tempoRevision: map.revision, startBeat,
      endBeat: startBeat + Math.max(8, Math.ceil(4 / this.period)) * this.period * map.bpm / 60,
      prepareByBeat: startBeat - 6, windowStartBeat: startBeat - 6, windowEndBeat: startBeat - 3,
      snapshotCloseBeat: startBeat - 2.5, selectionByBeat: startBeat - 2, commitByBeat: startBeat - 1,
      selector: this.identity, delegated: false, scope,
      inputs: [{name: 'harmony', publisher: this.identity, type: 'string', units: 'prepared-compatibility', maxAgeBeats: 1,
        completeness: 'watermark', ordering: 'observed-beat-then-sequence'}], branches: [],
      unknownOutcome: 'open', noMatchOutcome: 'open', unreadyOutcome: 'omit', missingFinalOutcome: 'omit'};
    const variants = [{id: 'major', pitches: [root, root + 4, root + 7, root + 4]},
      {id: 'minor', pitches: [root, root + 3, root + 7, root + 3]},
      {id: 'open', pitches: [root, root + 7]}];
    for (const [index, variant] of variants.entries()) {
      const clip = validateMotif({motifId: `${occurrenceId}:${variant.id}`, events: variant.pitches.map((pitch, i) => ({
        at: i * this.period * map.bpm / 60, duration: Math.min(.3, this.period * .65) * map.bpm / 60, pitch, velocity: .5,
      })), metadata: {name: `Input response: ${variant.id}`, authority: 'own-output', periodProposal: proposals.period.proposalId}});
      const entry = await runtime.cache.put(clip);
      if (!this.enabled || generation !== (this.responseGeneration || 0)) return;
      const plan = await runtime.publish({version: 2, author: over.author, authorIncarnation: over.authorIncarnation,
        planId: variant.id, revision: 1, occurrenceId, sessionId: over.sessionId, epoch: over.epoch,
        tempoId: over.tempoId, tempoRevision: over.tempoRevision, kind: 'motif', startBeat, endBeat: over.endBeat,
        prepareByBeat: over.prepareByBeat, commitByBeat: over.commitByBeat, scope, selector: this.identity, delegated: false,
        dependencies: [], content: {format: 'ump-clip', digest: entry.digest, bytes: entry.bytes, motifId: clip.motifId}, decision: overplanReference(over)});
      over.branches.push({id: variant.id, priority: index + 1, plan: planReference(plan), guard: {op: 'eq', input: 'harmony', value: variant.id}});
    }
    if (!this.enabled || generation !== (this.responseGeneration || 0)) return;
    runtime.publishOverplan(over);
    this.currentDecision = {over, rootClass: Number.isInteger(root) ? root % 12 : null, sequence: 0, complete: false};
    this.nextBeat = over.endBeat;
    retain(this.decisions, freeze({occurrenceId, startBeat, proposals, preparationEvidence: evidence, alternatives: variants,
      overplan:overplanReference(over),mode,previousTargets,timing:responseTiming(over,map)}));
  }
  pump() {
    const runtime = this.futurePlanning;
    if (!this.enabled || !runtime) return;
    if(this.inputAvailable!==false)this.input.query();
    const now = runtime.now(); if (now === null) return;
    const beat = runtime.timeline.beatAtReference(now), decision = this.currentDecision;
    if (decision) {
      const {over} = decision;
      if (beat >= over.windowStartBeat && beat < over.windowEndBeat && beat - (decision.lastSampleBeat ?? -Infinity) >= .4) {
        decision.lastSampleBeat = beat;
        const evidence = this.input.snapshot(), harmony = usable(evidence, 'pitch') ? evidence.report.harmony : null;
        const label = harmony?.status === 'interpreted' && harmony.vocabularyId === 'major-minor-triads-12' && harmony.tuningId === '12-equal'
          ? harmony.candidates[0]?.label : null;
        const choice = decision.rootClass !== null && label === `${names[decision.rootClass]}-major` ? 'major' :
          decision.rootClass !== null && label === `${names[decision.rootClass]}-minor` ? 'minor' : 'open';
        const observationId = `${over.occurrenceId}:belief:${++decision.sequence}`;
        const value = {version: 1, overplan: overplanReference(over), input: 'harmony', publisher: this.identity,
          sequence: decision.sequence, observationId, observedBeat: beat, units: 'prepared-compatibility', value: choice};
        runtime.ingestInput(value, this.identity);
        retain(this.evidence, freeze({observationId, evidence, choice, availableAt: now,
          overplan:overplanReference(over),epoch:over.epoch}));
      }
      if (!decision.complete && beat >= over.windowEndBeat && beat < over.snapshotCloseBeat) {
        decision.complete = true;
        runtime.ingestInput({version: 1, overplan: overplanReference(over), input: 'harmony', publisher: this.identity,
          throughBeat: over.windowEndBeat, maxSequence: decision.sequence}, this.identity, {complete: true});
      }
    }
    runtime.advance();
    if (runtime.ready() && !this.preparing && (!decision || beat >= decision.over.startBeat)) {
      this.preparing = this.prepareResponse().catch(error => { this.lastError = error.message; }).finally(() => { this.preparing = null; });
    }
  }
  responseSnapshot() {
    return {enabled: this.enabled, mode: this.mode || null, periodSeconds: this.period ?? null, register: this.register ?? null,
      source: this.input?.snapshot() || null, decisions: this.decisions.slice(-4), evidence: this.evidence.slice(-16),
      planning: this.futurePlanning?.status() || null, execution: this.futurePlanning?.facts.slice(-16) || [],
      profile:responseProfile(this),
      bindingChanges: this.bindingChanges || [],
      inputAvailability:{available:this.inputAvailable!==false,reason:this.inputAvailabilityReason??null},
      lastError: this.lastError || null, scope: 'own output; ensemble tempo and meter are unchanged'};
  }
  disengage() {
    this.enabled = false; this.responseGeneration = (this.responseGeneration || 0) + 1;
    this.futurePlanning?.stop(); this.input = null; this.currentDecision = null;
  }
  stop() { this.disengage(); }
}

export const responseBot = defineBot({id: 'response', name: 'ResponseBot', status: 'native', category: 'melody',
  requiresPerformerInput: true,
  outputModes: ['synth'], pitchContract: 'floating-mpe', description: 'Prepared MIDI 2 responses to a chosen performer input, with separate timing and pitch policies.',
  visualizers: [{id: 'influence', name: 'Influence and execution', module: './influence.js'}],
  planningCapabilities: {rhythm: false, harmony: false, form: false}}, (send, audio) => new ResponseBot(send, audio));
