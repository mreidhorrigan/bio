import {Agent} from '../framework/agent.js';
import {actor,planReference,planKey} from '../shared/planning-data.js';
import {overplanReference} from '../shared/overplanning.js';
import {compileUmpPlayback} from '../ump-playback.js';

function nextClipBoundary(runtime,participants,leadBars=4) {
  let beat=runtime.timeline.futureBoundary(runtime.now(),leadBars);
  for(const record of runtime.records.values())if(!['completed','cancelled','expired','degraded'].includes(record.state)&&
    record.plan.scope.participants.some(p=>participants.some(q=>p.id===q.id&&p.incarnation===q.incarnation)))
    beat=Math.max(beat,runtime.timeline.beatAtReference(record.timeline.referenceAtBeat(record.plan.endBeat)));
  return Math.ceil(beat/runtime.timeline.beatsPerBar)*runtime.timeline.beatsPerBar;
}
const commitBoundary=(map,start)=>Math.min(start-1,map.beatAtReference(map.referenceAtBeat(start)-.5));

// A normal Musebot participant. The Node/in-page room owns aggregation;
// planning and clock adapters are injected, never imported by this bot.
export class ConductorBot extends Agent {
  constructor(send,audio,options={}) {
    super(send,audio);
    this.role = options.role || 'participant';
    this.participants = new Map();
    this.rosterRevision = 0;
    this.diagnostics = [];
    this.protocolCapabilities = {aggregation: this.role === 'host' ? 1 : 0};
    if(options.planningRuntime)this.setFuturePlanning(options.planningRuntime);
  }
  announce(state = 'loaded') {
    this.broadcast('agentState',[{instanceId:this.instanceId,incarnation:this.incarnation,definitionId:'conductor',
      name:'mh_ConductorBOT',state,category:'conductor',performanceType:'silent',outputModes:[],
      protocolCapabilities:{...this.protocolCapabilities}}]);
  }
  async start() {this.announce();}
  stop() {this.announce('stopped');}
  onTick(_tick,clock = {}) {this.currentClock = clock;}
  onMessage(message) {
    super.onMessage(message);
    if (message.address === '/broadcast/agentState') {
      const value = message.args?.[0];
      if (value?.instanceId && typeof value.instanceId === 'string') {
        if(message.source?.includes('::')&&(message.source!==value.instanceId||message.sourceIncarnation!==value.incarnation))return;
        const previous=this.participants.get(value.instanceId);
        if(['leaving','stopped'].includes(value.state)){
          if(previous?.incarnation===value.incarnation)this.participants.delete(value.instanceId);
        }else this.participants.set(value.instanceId,{...structuredClone(value),
          rosterRevision:previous&&previous.incarnation===value.incarnation?previous.rosterRevision:++this.rosterRevision});
        while(this.participants.size > 64)this.participants.delete(this.participants.keys().next().value);
      }
    }
  }
  async prepareConditionalClips({memory,motifIds,participants,publisher,leadBars=4,intervalBars=2}) {
    const runtime=this.futurePlanning;
    if(!runtime||!this.planningMemory)throw new Error('Start the shared timeline before preparing a decision');
    if(!runtime.ready())throw new Error('Conductor clock is not ready');
    if(!motifIds)motifIds=(await this.planningMemory.query(actor(memory),{limit:2})).map(motif=>motif.motifId);
    if(!Array.isArray(motifIds)||motifIds.length!==2||new Set(motifIds).size!==2)throw new Error('Choose two distinct stored motifs');
    if(!Array.isArray(participants)||!participants.length||participants.length>64)throw new Error('Name the required clip executors');
    participants=participants.map(actor);publisher=actor(publisher);memory=actor(memory);
    for(const participant of participants) {
      const state=this.participants.get(participant.id);
      if(state?.incarnation!==participant.incarnation||state.protocolCapabilities?.scheduledClips!==1||state.protocolCapabilities?.clockReady!==true)
        throw new Error(`Executor is not ready: ${participant.id}`);
    }
    if(!participants.some(p=>p.id===publisher.id&&p.incarnation===publisher.incarnation))throw new Error('The demo input publisher must be one of its executors');
    if(!Number.isInteger(leadBars)||leadBars<4||leadBars>16||!Number.isInteger(intervalBars)||intervalBars<2||intervalBars>8)throw new Error('Invalid demo lead or interval');
    const content=[];
    for(const motifId of motifIds) {
      const motifs=await this.planningMemory.query(memory,{motifId,limit:1}),motif=motifs.find(value=>value.motifId===motifId);
      if(!motif)throw new Error(`MemoryBot did not return ${motifId}`);
      const entry=await runtime.cache.put(motif);
      content.push({format:'ump-clip',digest:entry.digest,bytes:entry.bytes,motifId,memory});
    }
    const map=runtime.timeline,identity=runtime.identity,index=(this.decisionCount||0)+1;this.decisionCount=index;
    const startBeat=Math.max(16,nextClipBoundary(runtime,participants,leadBars)),endBeat=startBeat+intervalBars*map.beatsPerBar,
      prepareByBeat=startBeat-8,commitByBeat=commitBoundary(map,startBeat);
    const overplan={version:1,guardVersion:1,author:identity.id,authorIncarnation:identity.incarnation,
      overplanId:`${identity.id}:conditional-clips`,revision:1,occurrenceId:`choice:${index}`,
      sessionId:map.sessionId,epoch:map.epoch,tempoId:map.id,tempoRevision:map.revision,
      startBeat,endBeat,prepareByBeat,commitByBeat,selector:identity,delegated:false,
      scope:{mode:'shared',membershipId:`${map.epoch}:choice:${index}`,participants},
      windowStartBeat:startBeat-7,windowEndBeat:commitByBeat-2,snapshotCloseBeat:commitByBeat-1.5,selectionByBeat:commitByBeat-1,
      inputs:[{name:'activity',publisher,type:'number',units:'density',maxAgeBeats:4,completeness:'watermark',ordering:'observed-beat-then-sequence'}],
      branches:[],unknownOutcome:'low',noMatchOutcome:'omit',unreadyOutcome:'omit',missingFinalOutcome:'omit'};
    for(let i=0;i<2;i++) {
      const plan=await runtime.publish({version:2,author:identity.id,authorIncarnation:identity.incarnation,
        planId:`${overplan.overplanId}:${i}`,revision:1,occurrenceId:overplan.occurrenceId,
        sessionId:map.sessionId,epoch:map.epoch,tempoId:map.id,tempoRevision:map.revision,kind:'motif',
        startBeat,endBeat,prepareByBeat,commitByBeat,selector:identity,delegated:false,scope:overplan.scope,dependencies:[],
        content:content[i],decision:overplanReference(overplan)});
      overplan.branches.push({id:i?'high':'low',priority:i+1,plan:planReference(plan),guard:{op:i?'gt':'lte',input:'activity',value:.5}});
    }
    const published=runtime.publishOverplan(overplan);
    this.report('conditional-clips-preparing',{overplan:overplanReference(published),plans:published.branches.map(branch=>planKey(branch.plan))});
    return published;
  }
  async prepareReserve({memory,motifId,participants}) {
    const runtime=this.futurePlanning;
    if(!runtime?.ready()||!this.planningMemory)throw new Error('Start and calibrate the shared timeline first');
    if(this.reserve&&this.reserve.endReference>runtime.now())throw new Error('A reserve is already pending or active');
    memory=actor(memory);
    if(!Array.isArray(participants)||!participants.length||participants.length>64)throw new Error('Name the reserve executors');
    participants=participants.map(actor);
    for(const participant of participants) {
      const p=this.participants.get(participant.id);
      if(p?.incarnation!==participant.incarnation||p.protocolCapabilities?.scheduledClips!==1||p.protocolCapabilities?.clockReady!==true)
        throw new Error(`Executor is not ready: ${participant.id}`);
    }
    const [motif]=await this.planningMemory.query(memory,{...(motifId?{motifId}:{}),limit:1});
    if(!motif||(motifId&&motif.motifId!==motifId))throw new Error('Choose a stored clip for the reserve');
    const entry=await runtime.cache.put(motif),content={format:'ump-clip',digest:entry.digest,bytes:entry.bytes,memory,motifId:motif.motifId};
    const map=runtime.timeline,startBeat=nextClipBoundary(runtime,participants),endBeat=startBeat+8*map.beatsPerBar;
    const unitBars=[1,2,4,8].find(bars=>{
      for(let bar=0;bar<8;bar+=bars){
        const start=startBeat+bar*map.beatsPerBar,end=start+bars*map.beatsPerBar;
        const duration=compileUmpPlayback(motif,{bpm:map.bpmAtBeat?.(start)??map.bpm}).durationSeconds+.12;
        if(map.referenceAtBeat(end)-map.referenceAtBeat(start)<duration)return false;
      }
      return true;
    });
    if(!unitBars)throw new Error('This clip is too long for an eight-bar reserve');
    const index=(this.reserveCount||0)+1;this.reserveCount=index;
    const refs=[],identity=runtime.identity;
    for(let bar=0;bar<8;bar+=unitBars) {
      const plan=await runtime.publish({version:2,author:identity.id,authorIncarnation:identity.incarnation,
        planId:`${identity.id}:reserve:${index}`,revision:1,occurrenceId:`reserve:${index}:${bar}`,
        sessionId:map.sessionId,epoch:map.epoch,tempoId:map.id,tempoRevision:map.revision,kind:'motif',
        startBeat:startBeat+bar*map.beatsPerBar,endBeat:startBeat+(bar+unitBars)*map.beatsPerBar,
        prepareByBeat:startBeat-map.beatsPerBar,commitByBeat:commitBoundary(map,startBeat),
        selector:identity,delegated:false,scope:{mode:'shared',membershipId:`${map.epoch}:reserve:${index}`,participants},
        dependencies:[],content,rationale:'Eight bars of prepared, committed outage reserve; omit after clock expiry.'});
      refs.push(planReference(plan));
    }
    this.reserve={startBeat,endBeat,startReference:map.referenceAtBeat(startBeat),endReference:map.referenceAtBeat(endBeat),
      unitBars,plans:refs,state:'preparing'};return this.reserveStatus();
  }
  advanceReserve() {
    const reserve=this.reserve,runtime=this.futurePlanning;if(!reserve||reserve.state!=='preparing'||!runtime)return;
    const records=reserve.plans.map(ref=>runtime.records.get(planKey(ref)));
    if(records.some(record=>!record))return;
    if(runtime.now()>records[0].timeline.referenceAtBeat(records[0].plan.commitByBeat)) {
      reserve.state='expired';this.report('reserve-expired');return;
    }
    if(runtime.ready()&&records.every(record=>runtime.allPrepared(record))) {
      try {
        for(const record of records)runtime.commit(record.plan);
        reserve.state='committed';this.report('reserve-committed',{startBeat:reserve.startBeat,endBeat:reserve.endBeat});
      }catch(error){reserve.state='degraded';reserve.reason=error.message;this.report('reserve-degraded',{reason:error.message});}
    }
  }
  reserveStatus() {
    const reserve=this.reserve,runtime=this.futurePlanning;if(!reserve||!runtime)return null;
    let acceptedBars=0;
    for(const reference of reserve.plans) {
      const record=runtime.records.get(planKey(reference));
      if(record?.final&&record.plan.scope.participants.every(p=>['accepted','admitting','scheduled','executed','completed'].includes(
        record.statuses.get(JSON.stringify([p.id,p.incarnation]))?.state)))acceptedBars+=reserve.unitBars;
    }
    return {...reserve,acceptedBars,seconds:reserve.endReference-reserve.startReference,
      clockLimited:true,afterReserve:'omit'};
  }
  report(type,details = {}) {
    this.diagnostics.push({type,...details});
    if(this.diagnostics.length > 256)this.diagnostics.shift();
    this.audio?.report?.(type,details);
  }
}
