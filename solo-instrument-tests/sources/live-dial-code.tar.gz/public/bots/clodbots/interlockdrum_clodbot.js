// interlockdrum_clodbot: hand percussion that interlocks with the patterns it hears (the shared part:
// ../lib/rhythm-pattern-bot.js), each stroke played as a hand drummer plays it (../../shared/percussion-expression.js),
// its two drums tuned to the harmony it hears as a drum kit's toms are (../lib/modules/drum-tuning.js).
import {defineBot} from '../../framework/index.js';
import {GroupingChoice} from '../lib/modules/grouping-choice.js';
import {Agent} from '../../framework/agent.js';
import {HeardRhythm,metricStrength,hearRhythmMessage} from '../../shared/rhythm-spaces.js';
import {onsetsPayload} from '../../shared/sounding-voices.js';
import {measuredSpread,metricPlace,onBeat} from '../../shared/percussion-expression.js';
import {tactusOf} from '../../shared/meter-tactus.js';
import {createRandomStream} from '../../random-source.js';
import {clamp01,nextPattern,characterShift} from '../lib/rhythm-pattern-bot.js';
import {Closure} from '../lib/modules/closure.js';
import {tunedStrike} from '../lib/modules/drum-tuning.js';
import {PerformedTiming} from '../lib/modules/performed-timing.js';
import {revoicedHits} from '../../shared/performance-timing.js';
import {gestureStroke} from '../lib/modules/cycle-gestures.js';
import {bandMeter} from '../../shared/opening-time.js';
import {scoreTime,readScoreTime,withScoreTime} from '../../shared/score-time.js';
import {patternIntervals} from '../../shared/performers/rhythm-cell.js';

// Hand percussion: which drum at which strength of position, as a conga player's low and high drums and a bell; the
// shaker goes back and forth, its down stroke General MIDI's maracas (70), its up stroke the shaker (82).
const HAND=Object.freeze({low:{kind:'tom',note:64,pitch:52},high:{kind:'tom',note:63,pitch:57},bell:{kind:'perc',note:56},
  shaker:{kind:'closedHat',note:70},shakerUp:{kind:'closedHat',note:82}});
// Ours: the strokes a conga player uses by where they fall -- the low drum's bass tone (the palm in the centre) on the
// downbeat and its open tone elsewhere; on the high drum a slap on a beat when struck at SLAP_VELOCITY or harder, an open
// tone below it, and a muted stroke between the beats -- the up stroke of the shaker at UP_STROKE of its down stroke,
// and a stroke's spread the share HUMAN_SHARE of the drummers' measured one (a tom's: MEASURED.spread).
const SLAP_VELOCITY=.6,UP_STROKE=.85,HUMAN_SHARE=.5,WIDEST_SPREAD=2;
const clamp=(value,low,high)=>Math.max(low,Math.min(high,value));

export class InterlockDrumClodbot extends Closure(Agent) {
  constructor(send,audio,settings={}){
    super(send,audio);
    this.settings={dissonance:.45,density:.45,velocity:.6,expression:true,...settings};
    // Its drums tuned to the harmony: settings.tuneDrums true (the default), false, or the pieces to tune.
    this.tuneDrums=this.settings.tuneDrums??true;
    this.heardRhythm=new HeardRhythm();this.pattern=null;this.rhythmChange=.35;this.decisions=[];this.shakerDown=true;
  }
  onMessage(message){super.onMessage(message);hearRhythmMessage(this.heardRhythm,message,this.instanceId??null)}
  intended(){return clamp01(this.settings.dissonance+characterShift(this))}
  // Its strokes' own random stream, apart from its patterns'.
  strokeRandom(){this.strokes??=createRandomStream(`${this.audio?.seed??0}:${this.seedIdentity??'interlockdrum_clodbot'}:strokes`);return this.strokes.next()}
  spread(place){
    let u=0,v=0;while(u<=Number.EPSILON)u=this.strokeRandom();while(v<=Number.EPSILON)v=this.strokeRandom();
    return 1+HUMAN_SHARE*measuredSpread('tom',place)*clamp(Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v),-WIDEST_SPREAD,WIDEST_SPREAD);
  }
  // A hand's stroke on a drum at a place: {drum, velocity, strike}; `stroke` names one outright.
  stroke(drum,velocity,clock,stroke=null){
    if(!this.settings.expression)return {drum,velocity,strike:null};
    if(stroke)return {drum,velocity,strike:{stroke}};
    const beat=Math.max(1,tactusOf(clock.meter).ticks||clock.meter.subdivision||bandMeter().subdivision),place=metricPlace(clock.tickInBar??0,beat),shaped=clamp(velocity*this.spread(place),.05,1);
    if(drum===HAND.low)return {drum,velocity:shaped,strike:{stroke:clock.tickInBar===0?'bass':'open'}};
    if(drum===HAND.high)return {drum,velocity:shaped,strike:{stroke:onBeat(place)?(shaped>=SLAP_VELOCITY?'slap':'open'):'mute'}};
    if(drum===HAND.shaker){const down=this.shakerDown;this.shakerDown=!down;return {drum:down?HAND.shaker:HAND.shakerUp,velocity:down?shaped:shaped*UP_STROKE,strike:null}}
    return {drum,velocity:shaped,strike:null};
  }
  play(drum,velocity,clock,stroke,written){
    // In a named cycle, as its tradition marks it (cycle-gestures.js): the low drum, its bass, rests where a Hindustani
    // theka's bol has no bayan; sam, the talis and a Carnatic tala's claps are accented.
    const marked=gestureStroke(clock,{velocity,bass:drum===HAND.low});
    if(!marked.play)return;
    velocity=marked.velocity;
    const {drum:played,velocity:level,strike}=this.stroke(drum,velocity,clock,stroke);
    // The low and high drums, as the hand drums they are, tuned as toms are; the bell and the shaker as they are.
    const hand=strike&&(played===HAND.low||played===HAND.high)?tunedStrike(this,'conga',{...strike,piece:'conga'}):strike?{...strike,piece:'conga'}:null;
    withScoreTime(this.audio,written,()=>this.audio.drum?.(played.kind,level,{note:played.note,...(played.pitch?{pitch:played.pitch}:{}),...(hand?{strike:hand}:{})}));
    this.broadcast('onsets',[onsetsPayload({voice:this.instanceId??'interlockdrum_clodbot',role:'drums',onsets:[{tick:clock.tick,strength:level,kind:played.kind}]})]);
  }
  onTick(tick,clock){
    if(!clock?.meter)return;
    // Its ending (Closure): one low stroke on the last bar's downbeat, with the band, then nothing.
    const closing=this.closingAt(clock);
    if(closing.phase==='after')return;
    if(closing.phase==='final'){
      if(clock.tickInBar===0)this.play(HAND.low,Math.min(1,this.settings.velocity*1.3),clock,'open',scoreTime(clock.tick,closing.ticksLeft));
      return;
    }
    if(clock.barStart||!this.pattern){
      this.pattern=nextPattern(this,clock,this.intended(),this.settings.density*(.6+.8*(this.density??.5)));
      this.intervals=patternIntervals(this.pattern.positions,clock.meter.pulsesPerBar);
      this.decisions.push({tick:clock.tick,bar:clock.bar,space:this.pattern.space,positions:[...this.pattern.positions],dissonance:this.pattern.dissonance,heard:this.pattern.heard});
      if(this.decisions.length>256)this.decisions.shift();
    }
    // Its strokes at this tick; in a feel that re-voices (shared/performance-timing.js revoicedHits), a stroke on a swing's
    // "a" is played with its "and".
    const at=clock.tickInBar,bar=clock.meter.pulsesPerBar,sixteenth=clock.meter.subdivision*(Number(clock.meter.denominator)||bandMeter().denominator)/16;
    // What the re-voicing rewrote is kept (rewrites), the written pattern beside it (decisions).
    const strokes=revoicedHits(this.currentFeel?.(clock),at,{hitsAt:tick=>this.pattern.positions.includes(tick)?[tick]:[],steps:bar,
      phaseOf:tick=>this.feelPhase?.(tick)??null,next:tick=>Number.isInteger(sixteenth)?(tick+sixteenth)%bar:null,
      onRewrite:rewrite=>{(this.rewrites??=[]).push({bar:clock.bar,...rewrite});if(this.rewrites.length>64)this.rewrites.shift();}});
    for(const tick of strokes){
      const strength=metricStrength(clock.meter)[tick]??.1,drum=strength>=.6?HAND.low:strength>=.4?HAND.high:this.pattern.space==='cross'||this.pattern.space==='anticipations'?HAND.bell:HAND.shaker;
      // Revoicing explicitly changes this attack to `at`. Its original cell's ending is still an authored boundary;
      // neither endpoint comes from the swing offset, the stroke's transient or its decay.
      const cell=readScoreTime({scoreTime:this.intervals[this.pattern.positions.indexOf(tick)]});
      const written=scoreTime(clock.tick,cell.end.sub(at));
      this.play(drum,Math.max(.2,Math.min(1,this.settings.velocity*(.7+.5*strength))),clock,null,written);
    }
  }
}

// Under a home (meterform_clodbot), it hears the home bars in a grouping of its own (bots/lib/modules/grouping-choice.js).
// Played in the ensemble's feel, where one is set (the performance layer: docs/PERFORMANCE_TIMING.md).
const GroupedInterlockDrum=PerformedTiming(GroupingChoice(InterlockDrumClodbot,{role:'drums'}));
export const interlockdrumClodbot=defineBot(
  {
    id: "interlockdrum_clodbot", name: "interlockdrum_clodbot", status: "native", source: "clodbot",
    category: "beat", midiChannel: 10, outputModes: ["synth", "midi"], pitchContract: "fixed-percussion",
    description:
      "Hand percussion that hears the performer's attacks and the drums' hits and plays patterns that fit them without copying them: in the heard pattern's gaps at its own level (interlocking), or doubling its accents, anticipating them or crossing them, by an intended rhythmic dissonance; with no pattern heard, the meter's own. Its strokes are a conga player's: bass tones, open tones, slaps and muted strokes, a shaker back and forth; its two drums are tuned to the harmony it hears.",
  },
  (...args) => new GroupedInterlockDrum(...args),
);
