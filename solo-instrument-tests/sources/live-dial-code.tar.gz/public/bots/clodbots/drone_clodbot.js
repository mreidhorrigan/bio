// drone_clodbot: a fork of ae_DroneBOT that moves to the chord tone nearest its note, in the register it may play (the
// mathematical audit's B05; the user, 27 September 2026: "fix in forked form"). Made from the class it forks, which
// agents.js holds, by a function, so this file imports nothing from agents.js; ae_DroneBOT itself is unchanged.
//
// ae_DroneBOT compares a chord's classes at one octave (its base note plus the class) and only then folds the winner
// into its range, so the distance it minimizes is not the distance it plays: after 83, with a chord of classes 0 and 6
// in its range 72 to 91, it chooses 78, five semitones away, though 84, one away, is a chord tone in range. Here each
// class is placed at its octave nearest the drone's note within the range first (shared/pitch-domain.js
// nearestRegistered: the exact register domain p + 12k), and the nearest of those is taken; with no note yet, the
// phrase's common class (or the chord's first) at its octave nearest the base note, as the port prefers. A range too
// narrow to hold any of the chord's classes is a rest, never a pitch outside the chord. Its plans, renewals, durations
// and density are the port's.
//
// It also reinterprets a held tone (the extreme-aesthetics report's §4.4 and M4, E13): where the chord moves and its
// nearest chord tone is the pitch it holds, the note is held on under the new chord, its role changed, neither struck
// again nor retuned (the engine never retunes a sounding note). A note is scheduled across the chords of its cycle that
// keep its class (heldSpan), so it ends with the harmony that holds it; a new plan that moves the pitch sooner lets it go
// by identity. The port strikes a common tone again at every chord change. A MIDI part plays the port's way; settings
// {reinterpretHeld: false} do everywhere.
import {defineBot} from '../../framework/index.js';
import {pitchClass} from '../../shared/pitch.js';
import {nearestRegistered} from '../../shared/pitch-domain.js';
import {bandTempo} from '../../shared/opening-time.js';
import {writtenOn,writtenSeconds,ticksUntil,phraseTicksLeft} from '../lib/written.js';

// ---- Choices ---------------------------------------------------------------------------------------------------------
// The longest a held note is scheduled for (ours: half a minute; a tone held longer is renewed), and how near its end a
// held note is renewed rather than held on.
export const HELD_TONE=Object.freeze({mostSeconds:30,renewWithinSeconds:.25});

export function droneClodbotClass(DroneBot){
  class DroneClodbot extends DroneBot {
    constructor(...args){super(...args);this.reinterpretHeld=args[2]?.reinterpretHeld!==false;this.held=null}
    choosePitch(chord){
      const pcs=[...new Set(chord.map(pitchClass).filter(value=>value!==null))],common=this.mostCommonPitchClass(),
        preferred=pcs.includes(common)?common:(pcs[0]??pitchClass(this.notes[0])),
        range={low:this.config.range[0],high:this.config.range[1]},target=this.currentPitch??this.config.baseMidi+preferred;
      // With no note yet, the preferred class alone (the port's choice); with one, every class of the chord.
      const classes=this.currentPitch==null?[preferred,...pcs.filter(pc=>pc!==preferred)]:pcs;
      let best=null,distance=Infinity;
      for(const pc of classes){
        if(pc===null)continue;
        const note=nearestRegistered(this.config.baseMidi+pc,target,range);if(note===null)continue;
        if(Math.abs(note-target)<distance){best=note;distance=Math.abs(note-target)}
        if(this.currentPitch==null)break;
      }
      return best;
    }
    // The port's tick (ae_DroneBOT: its renewal and hold rules are documented there), resting where no class fits.
    onTick(tick,clock){
      if(clock.phraseStart&&clock.phrase!==this.lastMemoryPhrase&&(clock.phrase||0)%4===0){this.lastMemoryPhrase=clock.phrase;this.consultMemory({limit:12})}
      if(!clock.beatStart&&!clock.phraseStart)return;
      const plan=this.currentPlan(clock),canAdvance=(this.chords.length?this.chords:[this.notes]).length>1;
      if(this.remainingBeats>0)this.remainingBeats-=1;
      if(plan.index===this.lastChord&&(canAdvance||this.remainingBeats>0))return;
      this.lastChord=plan.index;
      const pitch=this.choosePitch(plan.chord);
      if(pitch===null)return;
      // Held only where its notes can be let go by identity: the DSP voices.
      if(this.reinterpretHeld&&this.audio.mode!=='midi'&&this.audio.dspNode){this.holdOrMove(pitch,plan,clock);return}
      const duration=Math.max(this.config.minimumSeconds,(plan.duration*60)/(clock.bpm||bandTempo()));
      this.remainingBeats=(duration*(clock.bpm||bandTempo()))/60;
      this.currentPitch=pitch;
      // (Written to its plan's next chord, or its phrase's end: lib/written.js.)
      const bars=clock.meter.phraseBars||this.phraseBars;
      writtenOn(this.audio,clock.tick,ticksUntil(clock,ahead=>ahead.bar%bars===0&&ahead.tickInBar===0||this.currentPlan(ahead).index!==plan.index,phraseTicksLeft(clock,bars)),()=>this.audio.dronePad(this.currentPitch,duration,this.density));
    }
    // How long `pitch` stays a tone of the harmony from the chord at `index` on, in seconds at `bpm`: that chord and each
    // following one of the cycle that holds its class, once round at most, within HELD_TONE.mostSeconds.
    heldSpan(pitch,index,bpm){
      const chords=this.chords.length?this.chords:[this.notes],pc=pitchClass(pitch),
        beats=this.chordDurations.length===chords.length?this.chordDurations:Array(chords.length).fill((this.phraseBars*this.config.assumedBeatsPerBar)/chords.length);
      let total=0;
      for(let k=0;k<chords.length;k++){const j=(index+k)%chords.length;if(k>0&&!chords[j].some(note=>pitchClass(note)===pc))break;total+=beats[j]}
      return Math.min(HELD_TONE.mostSeconds,Math.max(this.config.minimumSeconds,total*60/bpm));
    }
    // The tone held on under the new chord, where it is still sounding for as long as the harmony keeps it; else the
    // sounding note let go and the pitch begun for its span.
    holdOrMove(pitch,plan,clock){
      const bpm=clock.bpm||bandTempo(),now=this.audio.eventStart?.(0)??0,span=this.heldSpan(pitch,plan.index,bpm);
      this.remainingBeats=span*bpm/60;
      if(this.held&&pitch===this.currentPitch&&this.held.until-now>=span-HELD_TONE.renewWithinSeconds){
        this.audio.report?.('heldTone',{pitch,chord:plan.index});
        return;
      }
      // Let go where the new pitch begins (the pulse's sounding time), not when it is scheduled, a lookahead before it.
      for(const identity of this.held?.identities??[])this.audio.releaseNote?.(identity,{atSeconds:now});
      this.currentPitch=pitch;
      // (Written for its span, the harmony's that keeps it, as it composes it in seconds.)
      const identities=writtenSeconds(this.audio,clock,span,()=>this.audio.dronePad(this.currentPitch,span,this.density))??[];
      this.held={identities,until:now+span};
    }
  }
  return DroneClodbot;
}
export function defineDroneClodbot(DroneBot){
  const DroneClodbot=droneClodbotClass(DroneBot);
  return defineBot({
      id:'drone_clodbot',name:'drone_clodbot',status:'native',source:'clodbot',forkOf:'drone',specSettings:Object.freeze(['reinterpretHeld']),
      category:'keys-pads',midiChannel:6,outputModes:['synth','midi'],pitchContract:'floating-mpe',
      description:
        'A fork of ae_DroneBOT that moves to the chord tone nearest its note within its range (the port compares classes at one octave, then folds, and can leap past a chord tone a semitone away); a range holding none of the chord\'s classes is a rest.',
    },(...args)=>new DroneClodbot(...args));
}
