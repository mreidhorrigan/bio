// gong_clodbot: a gong player (the family atlas's F30: research/family-atlas.md). The gong marks the music's large
// units, as a gamelan's gong ageng closes each gongan and an orchestra's tam-tam marks an arrival
// (shared/performers/gong.js): the form's joins, where the music arrives in a new section, and within a section the
// start of each cycle of phrases, the fewest whole phrases lasting at least eight seconds, so at any tempo and in any
// meter it marks what is large there. Each stroke as hard as the intensity the music arrives at, a join a step over a
// cycle; its ring as long as the band's space asks, damped by a hand where the band is dry. The piece opens on its
// first stroke, and it strikes the last bar's downbeat with the band and lets it ring.
//
// Its gong is recorded (VSCO 2 CE's, struck at four dynamics: data/drum-kits/vsco-percussion.json), played where its
// kit has one; its note goes to a plugin or out to MIDI, for the instrument there to sound. Elsewhere it has no gong
// and plays nothing, and says so: the synthesized kit has none, and nothing stands in for one.
import {defineBot} from '../../framework/index.js';
import {Agent} from '../../framework/agent.js';
import {Closure} from '../lib/modules/closure.js';
import {PerformedTiming} from '../lib/modules/performed-timing.js';
import {FormMarks,marksJoin} from '../lib/modules/form-marks.js';
import {onsetsPayload} from '../../shared/sounding-voices.js';
import {secondsPerTick} from '../../shared/meter-tactus.js';
import {formJoins} from '../../shared/form-joins.js';
import {GONG,beginsCycle,cyclePhrases,strokeDamping,strokeLevel} from '../../shared/performers/gong.js';
import {bandPhraseBars} from '../../shared/opening-time.js';
import {ScoreEvents} from '../../shared/score-time.js';

const clamp=(value,low,high)=>Math.max(low,Math.min(high,value));

export class GongClodbot extends FormMarks(Closure(Agent)) {
  constructor(send,audio,settings={}){
    super(send,audio);
    this.settings={...settings};
    this.decisions=[];
  }
  // Whether its voice has a gong (audio.js percussionVoice): a sampled kit with one, a plugin or MIDI out (their
  // instrument sounds its note), or none to ask (a notes-only render); never the synthesized kit.
  hasGong(){
    const voice=this.audio?.percussionVoice?.();
    if(voice==='sampled')return Boolean(this.audio.sampledKit?.()?.notes?.includes(GONG.note));
    return voice!=='synthesized';
  }
  // The form's joins, where there is a form (shared/form-joins.js).
  joins(){const form=this.activeFormPlan??this.markedForm;return form?formJoins(form,{announced:this.announcedSections}):[]}
  // The section a bar lies in: where it began, and the intensity it arrives at, 0 to 1 (ManageBOT's casting for it,
  // else the form's tension; with no form, the middle).
  sectionAt(bar,joins=this.joins()){
    const form=this.activeFormPlan??this.markedForm,join=joins.filter(one=>one.bar<=bar).at(-1);
    const start=join?.bar??(Number(form?.appliesAt?.bar)||0),cast=this.castIntensities.get(start);
    const tension=join?join.toTension:Number(form?.payload?.sections?.[0]?.tension);
    return {start,join:join??null,intensity:clamp(Number.isFinite(cast)?cast:Number.isFinite(tension)?tension:.5,0,1)};
  }
  strike(clock,{kind,intensity,why,ticks}){
    const level=strokeLevel(intensity,kind),damping=strokeDamping(this.character?.space),sounds=this.hasGong();
    this.decisions.push({bar:clock.bar,kind,why,intensity:+intensity.toFixed(3),level:+level.toFixed(3),damping:+damping.toFixed(3),
      ...(sounds?{}:{silent:'its voice has no gong: a sampled kit with one (vsco-percussion), a plugin, or MIDI out'})});
    if(this.decisions.length>128)this.decisions.shift();
    if(!sounds)return;
    const events=this.written??=new ScoreEvents('arrival'),event=events.create(clock.tick,ticks,{replace:true});
    events.perform(this.audio,event,()=>this.audio.drum?.('perc',level,{note:GONG.note,strike:{damping}}));
    this.broadcast('onsets',[onsetsPayload({voice:this.instanceId??'gong_clodbot',role:'drums',onsets:[{tick:clock.tick,strength:level,kind:'perc'}]})]);
  }
  onTick(tick,clock){
    if(!clock?.meter||clock.tickInBar!==0)return;
    const closing=this.closingAt(clock);
    if(closing.phase==='after')return;
    const joins=this.joins(),section=this.sectionAt(clock.bar,joins);
    // Its ending (Closure): the last bar's downbeat, the piece's last arrival, left to ring.
    if(closing.phase==='final'){this.strike(clock,{kind:'join',intensity:section.intensity,why:'ending',ticks:closing.ticksLeft});return}
    // A section's first bar begins its cycles: a join the intensity moves across as the drummers mark one (form-marks.js
    // marksJoin) is marked as a join, else as a cycle.
    const meter=clock.meter,phraseBars=Math.max(1,meter.phraseBars||bandPhraseBars()),phrases=cyclePhrases(phraseBars*meter.pulsesPerBar*secondsPerTick(clock));
    if(!beginsCycle(clock.bar,{sectionStart:section.start,phraseBars,phrases}))return;
    const arriving=section.join?.bar===clock.bar&&marksJoin({move:section.intensity-this.sectionAt(clock.bar-1,joins).intensity});
    const next=joins.find(join=>join.bar>clock.bar)?.bar??Infinity;
    const ticks=Math.min(phrases*phraseBars*meter.pulsesPerBar,(next-clock.bar)*meter.pulsesPerBar,closing.ticksLeft);
    this.strike(clock,{kind:arriving?'join':'cycle',intensity:section.intensity,why:arriving?'join':'cycle',ticks});
  }
}

// Played in the ensemble's feel, where one is set (the performance layer: docs/PERFORMANCE_TIMING.md).
const PerformedGong=PerformedTiming(GongClodbot);
export const gongClodbot=defineBot(
  {
    id:"gong_clodbot",orchestral:true,name:"gong_clodbot",status:"native",source:"clodbot",
    category:"beat",midiChannel:10,outputModes:["synth","midi"],pitchContract:"fixed-percussion",
    description:
      "A gong player: the gong marks the music's large units, as a gamelan's gong closes each cycle and an orchestra's tam-tam marks an arrival: the form's joins, and within a section each cycle of phrases eight seconds or more long; each stroke as hard as the intensity the music arrives at, its ring as long as the band's space asks; the piece's first stroke and its last, left to ring. A recorded gong, where its kit has one.",
  },
  (...args)=>new PerformedGong(...args),
);
