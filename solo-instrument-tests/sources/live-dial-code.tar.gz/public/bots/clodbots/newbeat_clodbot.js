// newbeat_clodbot: a fork of ae_newBeatBOT whose every bar is as active as its share of the phrase's activity (the
// mathematical audit's B02; the user, 27 September 2026: "fix in forked form"). Made from the class it forks, which
// agents.js holds, by a function, so this file imports nothing from agents.js; ae_newBeatBOT itself is unchanged.
//
// ae_newBeatBOT builds a phrase of as many bars as the meter's phrase has, but measures each bar's activity by slicing
// its sixteen-cell activity mask into four, its configured phrase length. In an eight-bar phrase, bars five to eight get
// empty slices, and their activity is 0 / 0: their hats and percussion take their counts from NaN. Here a bar's
// activity is the mask's average over the bar's own share of the phrase, cells cut by the bar's edges weighted by the
// part of them it covers, so every phrase length works, from one bar to many more than sixteen, and the phrase's whole
// activity is kept however it is divided. Where the port's slices are whole cells (four bars of sixteen cells) the
// levels are the port's to the last digit. Its kick on the tala's group starts, its backbeat, and its patterns shared by
// repeated labels are the port's.
import {defineBot} from '../../framework/index.js';
import {cyclicPattern} from '../../shared/rhythm.js';

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const NEWBEAT_CLODBOT=Object.freeze({
  // The largest value a cell of an activity mask holds (the port's scale: 0 to 9).
  maskScale:9,
});

// A bar's activity, 0 to 1: the mask's average over the bar's part of the phrase, [bar, bar + 1) of `bars`, each cell
// weighted by how much of it lies in the bar.
export function barActivity(mask,bar,bars,{choices=NEWBEAT_CLODBOT}={}){
  const cells=mask.length;
  if(!cells||!(bars>0))return 0;
  const from=bar*cells/bars,to=(bar+1)*cells/bars;let sum=0;
  for(let cell=Math.floor(from);cell<Math.min(cells,Math.ceil(to));cell++){
    const overlap=Math.min(cell+1,to)-Math.max(cell,from);
    if(overlap>0)sum+=Number(mask[cell])*overlap;
  }
  return sum/((to-from)*choices.maskScale);
}

export function newbeatClodbotClass(NewBeatBot){
  class NewBeatClodbot extends NewBeatBot {
    // The port's bar, with its activity measured over the bar's own share of the phrase.
    makeBarPattern(clock,barIndex,label,phraseStarts){
      const steps=clock.meter.pulsesPerBar,offset=barIndex*steps,bars=clock.meter.phraseBars||this.config.phraseBars,
        anchors=phraseStarts.filter(value=>value>=offset&&value<offset+steps).map(value=>value-offset),
        level=barActivity(this.activityMask,barIndex,bars),rotation=(this.instancePhase||0)+barIndex;
      const kick=Array(steps).fill(0),snare=Array(steps).fill(0);
      for(const onset of anchors)kick[onset]=1;
      kick[0]=1;snare[Math.floor(steps/2)]=1;
      const hat=cyclicPattern({steps,hits:Math.max(1,Math.round(steps*(.18+level*.54))),rotation}),
        percussion=this.config.percussionVoices.map((voice,index)=>cyclicPattern({steps,hits:Math.max(1,Math.round(steps*Math.max(.04,level)*voice.density)),rotation:rotation+voice.rotation+index}));
      return {label,kick,snare,hat,percussion,level};
    }
  }
  return NewBeatClodbot;
}
export function defineNewbeatClodbot(NewBeatBot){
  const NewBeatClodbot=newbeatClodbotClass(NewBeatBot);
  return defineBot({
      id:'newbeat_clodbot',name:'newbeat_clodbot',status:'native',source:'clodbot',forkOf:'newBeat',
      category:'beat',midiChannel:15,outputModes:['synth','midi'],pitchContract:'fixed-percussion',
      description:
        'A fork of ae_newBeatBOT whose every bar is as active as its share of the phrase\'s activity mask, in phrases of any length (the port leaves bars five to eight of an eight-bar phrase without a level); its kicks, backbeat and shared patterns are the port\'s.',
    },(...args)=>new NewBeatClodbot(...args));
}
