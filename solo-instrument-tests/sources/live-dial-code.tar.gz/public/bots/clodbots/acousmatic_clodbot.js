// acousmatic_clodbot: a fixed-media performer, the projectionist of sounds made from recordings (the rap and acousmatic
// supplement's first acousmatic slice; the owner, 1 October 2026: "the items regarding ... challenging aesthetics
// (acousmatic, rap)"). New, a player of its own instrument: the loudspeakers.
//
// It takes approved recordings (CC0 percussion, timpani and harp from VSCO 2 CE: shared/acousmatic/material.js ingest,
// their terms and credit kept) and makes each a family (family.js): the impact as recorded; its decay stretched into a
// field (its attack kept, the rest by WSOLA); a grain cloud from it; that cloud heard through another source's ringing
// (convolution: cross-synthesis); its reversal, a swell that leads into the impact. Every stage is a derived material
// that keeps its parents, its operation, its parameters and its seed, so nothing played loses where it came from.
//
// Its form is relations, not a beat grid (graphs.js): an impact and its residue, an answer, an interruption, fields
// accumulating, a cross-synthesis concealed under them, and late the first source's return, recognizable, its reversal
// arriving exactly at it. The relations are a temporal network solved for the earliest times that keep them; its
// transformations a graph made in the order their inputs allow (made before the first sound: a late sound's material
// may have to exist before an early one's). Each event a gesture in free time (gesture.js): its level and its place
// between the speakers each a curve over its own seconds, which no tempo moves. Its plan, with every material's
// provenance, is broadcast (/broadcast/acousmatic/plan) and logged.
//
// Its form is a conductor's or its own (ACOUSMATIC, timingOf): where a conductor says the piece's form, its length is the
// form's and its stages meet the form's roles -- its development where the form first leaves the role it opened in, its
// return where the form returns -- and where none does, its own, drawn from its seed (the render's length where the
// render fixes one). It says when its last sound ends (its plan's endTick), and the conductor ends the piece after it,
// as after a song set whole: a fixed medium is played whole.
import {defineBot} from '../../framework/index.js';
import {Agent} from '../../framework/agent.js';
import {decodeWav} from '../../shared/wav.js';
import {unitRandom} from '../../shared/stochastic.js';
import {ingest,derive,makeRegion,regionSamples,provenanceOf} from '../../shared/acousmatic/material.js';
import {apply,keyedRandom} from '../../shared/acousmatic/transforms.js';
import {SoundFamily} from '../../shared/acousmatic/family.js';
import {solveTemporal,relationBounds,topologicalOrder} from '../../shared/acousmatic/graphs.js';
import {gesture,controlsAt} from '../../shared/acousmatic/gesture.js';
import {secondsPerTick} from '../../shared/meter-tactus.js';
import {CaptureBuffer} from '../../shared/acousmatic/capture.js';
import {bandPhraseBars,bandTempo,bandMeter} from '../../shared/opening-time.js';

const CREDIT='Versilian Studios Chamber Orchestra 2: Community Edition (VSCO 2 CE), CC0 1.0';
const VSCO='https://github.com/sgossner/VSCO-2-CE';
// The recordings it may play, each with what an author says it is; `rings`: one whose decay is long enough to become a
// field (the protagonist is one of them).
export const ACOUSMATIC_SOURCES=Object.freeze([
  {id:'gong',url:'/vendor/drum-kits/vsco-percussion/Percussion/gongHit_fff.wav',tags:['gong, struck hard'],rings:true},
  {id:'gong-soft',url:'/vendor/drum-kits/vsco-percussion/Percussion/gongHit_p.wav',tags:['gong, touched'],rings:true},
  {id:'timpani',url:'/vendor/timpani-samples/vsco2-ce/Timpani2_Hit_v4_rr1_Sum.wav',tags:['timpani, struck'],rings:true},
  {id:'harp-low',url:'/vendor/harp-samples/vsco2-ce/KSHarp_E1_f.wav',tags:['harp, lowest string plucked'],rings:true},
  {id:'log-drum',url:'/vendor/drum-kits/vsco-percussion/Percussion/LogDrumLo_MedM_v3_rr1_Sum.wav',tags:['log drum, struck']},
  {id:'claves',url:'/vendor/drum-kits/vsco-percussion/Percussion/Claves1_Hit_v3_rr1_Sum.wav',tags:['claves, struck']},
  {id:'cowbell',url:'/vendor/drum-kits/vsco-percussion/Percussion/Cowbell1_Hit_v4_rr1_Sum.wav',tags:['cowbell, struck']},
  {id:'harp-high',url:'/vendor/harp-samples/vsco2-ce/KSHarp_A6_mf.wav',tags:['harp, high string plucked']},
].map(Object.freeze));
// Its choices, authored: a material's level (dB of full scale, RMS), the share of the piece each section takes, and the
// lead before its first sound (s).
// A field lasts until the next section has come in, overlapping it by `overlap` seconds: the sections join under each
// other, never through a silence.
// Its own form, where no conductor says one (the owner, 2 October 2026: "Make sure the acousmatic player can itself
// contribute to the form or take it from a conductor or other service, in keeping with the principle that the bots do
// the composing"): its length drawn within `seconds`, its development and its return each at a share of it drawn within
// `stages` (authored ranges, its seed choosing within them). Where a conductor's form is heard, it takes its stages from
// the form's roles instead (stagesOf), and its length is the form's.
// And a stage it may rest through as its own formal choice (`rest`): its development, the orchestra left to develop
// alone, with this chance (drawn from its seed apart from its other draws), where the silence between its exposition's
// field fading and its swell into the return would be at least `least` seconds and at most `most` of the piece (a rest,
// not an absence: Op. 3.9's first render rested 144 s of 387; ours; the owner, 2 October 2026: "A
// silent fixed-media part for one or more parts of a piece of music can be acceptable later as part of the form, but
// you're right to make sure it doesn't happen by accident"): a rest it chose, said in its plan, never a gap.
export const ACOUSMATIC=Object.freeze({levelDb:-24,impactPeakDb:-7,stages:Object.freeze({development:Object.freeze([.2,.4]),return:Object.freeze([.6,.8])}),
  seconds:Object.freeze([90,210]),overlap:4,lead:.25,rest:Object.freeze({chance:.35,least:15,most:1/3}),
  // And its dynamics the piece's, as every section's are: each event's level moved by the conductor's planned level for
  // the section of the form it begins in (its constraints' middle, 0 to 1), this many dB from pp to ff around its own
  // (ours: Op. 3.9's tape held one level while the orchestra went from ff to pp).
  dynamicsDb:12,
  // Its relation to the band (the owner, 2 October 2026: "For mixed acousmatic/orchestral music, we need a continuum of
  // strategies for relating samples with orchestra -- continuity (as through imitation), harmony, et cetera"; Smalley's
  // spectromorphology, Organised Sound 2(2), 1997, doi:10.1017/S1355771897009059; Emmerson, Living Electronic Music,
  // doi:10.4324/9781351217866): shares, drawn once a piece within these ranges, or a spec's settings.relation --
  //   harmony    how far its pitched sounds move toward the band's harmony as each chord is said (0 their own pitches,
  //              1 the chord's nearest tone, every state between), a sound pitched where its own autocorrelation's peak
  //              reaches `clarity`, moved over `glide` seconds;
  //   synchrony  how far its struck events move toward the form's nearest bar line (0 free time, 1 on the bar);
  //   imitation  how much of it is the band's own sound returned (`capture`, below): its return's field the exposition's
  //              last seconds, and each of its development's fields the band's last seconds before it, each by this share;
  //   fusion     how far each of its sounds' brightness moves toward the band's as the hall hears it (0 its own, 1 as far
  //              as `shelf` moves it): a high shelf at the sound's own brightness, raised or lowered `perOctave` dB for
  //              each octave the band's brightness lies above or below it, `most` at the most, set every `every` seconds
  //              from the band's last `window` seconds and reached over `rise` (a timbral fusion, the band and the tape
  //              heard as one source where they meet: Smalley's spectromorphology, above);
  // Ours: the ranges.
  relation:Object.freeze({harmony:Object.freeze([0,1]),synchrony:Object.freeze([0,1]),imitation:Object.freeze([0,1]),fusion:Object.freeze([0,1]),clarity:.5,glide:.08,
    shelf:Object.freeze({perOctave:6,most:12,every:1,window:3,rise:.5,lowest:200,highest:8000})}),
  // And where the form changes after its events are laid out, its events not yet sounding placed again where a stage has
  // moved more than this many seconds (ours).
  revise:.5,
  // And, where it can hear the band (a render's: its audio's hearBand), the band's own sound returned (the supplement's
  // S029: "live capture for later, transformed returns"): the exposition's last `seconds` as the hall hears them, captured,
  // and laid under the return granulated, a field as long as the return or `lasts` at most; the capture's buffer holds
  // `holds` seconds (ours).
  capture:Object.freeze({seconds:12,lasts:40,holds:20,density:14,grainSeconds:.12,spread:.05,jitter:.4})});
// The events of its development, which a rest through it leaves out.
const DEVELOPMENT=Object.freeze(['scatter','hidden','cut-across']);

const mono=decoded=>{const [a,b]=decoded.channels;if(!b)return Float32Array.from(a);return Float32Array.from(a,(v,i)=>(v+b[i])/2)};
const db=x=>10**(x/20);
// A conductor's form in seconds -- each section its phrases' bars, a bar its numerator's beats at its tempo -- its joins
// and its sections' roles (plex_clodbot's /broadcast/form); and where it has not yet decided them all, the roles still to
// come (`sketch`) in equal shares of the rest of the length it expects (`seconds`), as it will share them out.
// -> {total, joins, roles, expected (how many of them are expected, not decided)}.
// A sound's pitch, measured once (MIDI, between the keys too) and how clear it is: the normalized autocorrelation's
// highest peak between 40 and 1000 Hz, over 4096 samples from a tenth of the way in (past an attack), or from
// `position` of the way. -> {pitch, clarity}.
// Its contour: its pitch where clear at three places along it (CONTOUR_AT), for the orchestra to imitate. -> [pitch |
// null].
export const CONTOUR_AT=Object.freeze([.2,.5,.8]);
export const contourOf=(channel,sampleRate,{clarity=.5}={})=>CONTOUR_AT.map(position=>{const {pitch,clarity:clear}=pitchOf(channel,sampleRate,{position});return clear>=clarity?pitch:null});
export function pitchOf(channel,sampleRate,{position=.1}={}){
  const length=Math.min(4096,channel.length),from=Math.min(Math.floor(channel.length*position),Math.max(0,channel.length-length)),x=channel.subarray(from,from+length);
  const at=lag=>{let sum=0;for(let i=0;i+lag<x.length;i++)sum+=x[i]*x[i+lag];return sum},zero=at(0);if(!(zero>0))return {pitch:null,clarity:0};
  let best=0,lagBest=0;for(let lag=Math.floor(sampleRate/1000);lag<=Math.min(x.length/2,Math.ceil(sampleRate/40));lag++){const r=at(lag)/zero;if(r>best){best=r;lagBest=lag}}
  return lagBest?{pitch:+(69+12*Math.log2(sampleRate/lagBest/440)).toFixed(3),clarity:+best.toFixed(3)}:{pitch:null,clarity:0};
}
// A sound's brightness, measured once: its RMS frequency (Hz) over up to 8192 samples from a tenth of the way in, from
// the energy of its first difference against its own (for a sine of frequency f, a difference's energy is 4 sin^2(pi f /
// rate) of its own, which this inverts; a mixture's, the spectrum's second moment, as a centroid weighted by power).
// -> Hz, or null for silence.
export function brightnessOf(channel,sampleRate,{from=Math.floor(channel.length*.1),length=8192}={}){
  const start=Math.min(Math.max(0,from),Math.max(0,channel.length-Math.min(length,channel.length))),x=channel.subarray(start,start+Math.min(length,channel.length));
  let energy=0,difference=0;for(let i=1;i<x.length;i++){energy+=x[i]*x[i];const d=x[i]-x[i-1];difference+=d*d}
  if(!(energy>1e-12))return null;
  return +(sampleRate/Math.PI*Math.asin(Math.min(1,Math.sqrt(difference/energy)/2))).toFixed(2);
}
export function formTimes(sections,{sketch=[],seconds=null}={}){
  let at=0;const joins=[],roles=[],grid=[];
  for(const section of sections){
    const bars=(Number(section.phrases)||1)*(Number(section.phraseBars)||bandPhraseBars()),bpm=Number(section.tempo?.targetBpm)||bandTempo(),barSeconds=(Number(section.numerator)||bandMeter().numerator)*60/bpm;
    joins.push(+at.toFixed(3));roles.push(String(section.role??''));grid.push({at:+at.toFixed(3),bars,barSeconds,beatSeconds:60/bpm,denominator:Number(section.denominator)||bandMeter().denominator});at+=bars*barSeconds;
  }
  const rest=Number(seconds)-at,coming=Array.isArray(sketch)&&rest>0?sketch:[];
  for(const role of coming){joins.push(+at.toFixed(3));roles.push(String(role));at+=rest/coming.length}
  return {total:at,joins,roles,expected:coming.length,grid};
}
// Where its stages meet a form, read from the form's roles: its development where the form first leaves the role it
// opened in, its return where the form returns (a return or complex-return section after that), else at the form's last
// section; null where the form has too few sections to hold them. -> {developmentAt, returnAt, from: 'form'} or null.
const RETURNS=new Set(['return','complex-return']);
export function stagesOf({joins,roles}){
  const departs=roles.findIndex((role,k)=>k>0&&role!==roles[0]);if(departs<1)return null;
  let returns=roles.findIndex((role,k)=>k>departs&&RETURNS.has(role));if(returns<0)returns=roles.length-1;
  return returns>departs?{developmentAt:joins[departs],returnAt:joins[returns],from:'form'}:null;
}
// Its own form, drawn from its seed (`random`): its length (where nothing gives one) and its stages' shares of it.
export function ownStages(total,random){
  const draw=([low,high])=>low+(high-low)*random(),{development,return:back}=ACOUSMATIC.stages;
  return {total,developmentAt:draw(development)*total,returnAt:draw(back)*total,from:'own'};
}
// Its timing: the form's where a conductor said one with roles enough, its own stages within the form's length where it
// has too few, its own form where none was heard (the render's length where fixed, else its own drawn).
export function timingOf(form,random,renderSeconds=null){
  if(form){const stages=stagesOf(form),expected=form.expected?{expected:form.expected}:{};return stages?{total:form.total,joins:form.joins,...stages,...expected}:{...ownStages(form.total,random),joins:form.joins,...expected}}
  const [low,high]=ACOUSMATIC.seconds;
  return ownStages(Number(renderSeconds)>0?Number(renderSeconds):low+(high-low)*random(),random);
}
const rmsOf=x=>{let s=0;for(const v of x)s+=v*v;return Math.sqrt(s/Math.max(1,x.length))};
const peakOf=x=>{let p=0;for(const v of x)p=Math.max(p,Math.abs(v));return p};

export class AcousmaticClodbot extends Agent{
  constructor(send,audio,settings={}){
    super(send,audio);
    this.settings={...settings};this.decisions=[];this.seed=Number.isFinite(settings.seed)?settings.seed:Math.floor(unitRandom()*2**31);
    this.plan=null;this.started=false;
    // (Its relation to the band: a spec's, else its own draw, apart from its other draws.)
    const given=settings.relation,draw=keyedRandom(`${this.seed}:relation`),{harmony,synchrony,imitation,fusion}=ACOUSMATIC.relation;
    const share=(value,[low,high])=>Number.isFinite(Number(value))?Math.max(0,Math.min(1,Number(value))):+(low+(high-low)*draw()).toFixed(3);
    this.relation={harmony:share(given?.harmony,harmony),synchrony:share(given?.synchrony,synchrony),imitation:share(given?.imitation,imitation),fusion:share(given?.fusion,fusion)};
    // A render waits for its sources (`loading`); its families are made, and its events placed, once it knows the piece's
    // form (onTick).
    if(typeof fetch==='function')this.loading=this.gather().catch(error=>{this.decide({failed:String(error?.message??error)});return null});
  }
  // The conductor's form, where one says it (plex_clodbot's /broadcast/form): its sections' lengths in seconds (a bar
  // its numerator's beats at its tempo), so that its own sections meet the piece's joins.
  onMessage(message){
    super.onMessage?.(message);
    // (Each chord the band says: its pitched sounds moved toward it, as far as its harmony relation asks.)
    if(message?.address==='/broadcast/notepool'&&Array.isArray(message.args)){
      const classes=[...new Set(message.args.map(Number).filter(Number.isFinite).map(p=>((p%12)+12)%12))];
      if(classes.length){this.chordClasses=classes;for(const id of this.placed?.keys()??[])this.retune(id)}
    }
    // (And once begun, a form decided further, or otherwise: its events not yet sounding placed again, onTick revise.)
    if(message?.address==='/broadcast/form'&&Array.isArray(message.args?.[0]?.sections)){
      const form=formTimes(message.args[0].sections,{sketch:message.args[0].sketch,seconds:message.args[0].expected?.seconds});
      if(!this.started)this.form=form;else this.revisedForm=form;
    }
    // (The band's piece plan, not a section's -- a section's group is its kind and size, 'strings:full' -- its sections'
    // planned levels.)
    const plan=message?.address==='/broadcast/plan'?message.args?.[0]:null;
    // (The band's theme, where MemoryBOT's motif plans carry one (its top line: thematic-form.js), the first heard: its
    // onsets marks its struck events are drawn toward with the bar lines, by its synchrony -- its events not yet sounding
    // placed again, once begun.)
    if(plan?.kind==='motif'&&!this.motifLine&&Array.isArray(plan.payload?.theme?.line)&&plan.payload.theme.line.length>=2){
      this.motifLine=plan.payload.theme.line.map(note=>({at:Number(note.at)})).filter(note=>Number.isFinite(note.at));
      if(this.started&&this.form&&this.relation?.synchrony>0){this.revisedForm=this.revisedForm??this.form;this.motifHeard=true}
    }
    if(plan?.kind==='piece'&&Array.isArray(plan.payload?.units)&&!String(plan.payload.group??'').includes(':'))
      this.levels=new Map(plan.payload.units.map(unit=>{const range=unit.layers?.constraints?.level;return [unit.index,Array.isArray(range)?(Number(range[0])+Number(range[1]))/2:null]}).filter(([,level])=>Number.isFinite(level)));
  }
  // The planned level where `seconds` falls (the form's section it lies in), or null where none is planned.
  levelAt(seconds,joins=this.form?.joins??[]){
    if(!this.levels?.size||!joins.length)return null;
    let k=0;for(let i=0;i<joins.length;i++)if(joins[i]<=seconds+1e-9)k=i;
    return this.levels.get(k)??null;
  }
  decide(record){this.decisions.push(record);if(this.decisions.length>128)this.decisions.shift()}
  // Its sources fetched, decoded and admitted (CC0, credited), before the piece begins.
  async gather(){
    const random=keyedRandom(`${this.seed}:acousmatic`),library=new Map;
    const ringing=ACOUSMATIC_SOURCES.filter(s=>s.rings),dry=ACOUSMATIC_SOURCES.filter(s=>!s.rings);
    const pick=list=>list[Math.floor(random()*list.length)];
    const protagonist=pick(ringing),otherRing=pick(ringing.filter(s=>s!==protagonist)),answerer=pick(dry),interrupter=pick(dry.filter(s=>s!==answerer));
    const chosen=[protagonist,otherRing,answerer,interrupter];
    for(const source of chosen){
      const response=await fetch(source.url);if(!response.ok)throw new Error(`${source.url}: ${response.status}`);
      const decoded=decodeWav(new Uint8Array(await response.arrayBuffer()));
      const admitted=ingest({id:source.id,channels:[mono(decoded)],sampleRate:decoded.sampleRate,tags:source.tags,
        source:{kind:'recording',title:source.tags[0],creator:'Versilian Studios',url:`${VSCO} ${source.url.split('/').slice(-2).join('/')}`,licence:'CC0-1.0',attribution:CREDIT}},'render-local');
      if(!admitted.approved)throw new Error(`${source.id}: ${admitted.reason}`);
      library.set(source.id,admitted.material);
    }
    // (Its draws after its sources' picks, again from the start: a form revised is solved from the same draws.)
    const fresh=()=>{const again=keyedRandom(`${this.seed}:acousmatic`);for(let k=0;k<chosen.length;k++)again();return again};
    this.gathered={random,fresh,library,protagonist,otherRing,answerer,interrupter,chosen};
    return this.gathered;
  }
  // Its families made, its form solved, its events laid out, for a piece of `timing` ({total, developmentAt, returnAt,
  // from}: timingOf, the form's where it heard one, else its own).
  prepare(timing=timingOf(this.form??null,this.gathered.random,this.renderLength??this.audio?.renderEnd?.seconds),random=this.gathered.random){
    const {library,protagonist,otherRing,answerer,interrupter,chosen}=this.gathered;this.timing=timing;
    const {total,developmentAt,returnAt}=timing,rate=library.get(protagonist.id).sampleRate,scale=total/120;
    // The transformation graph: each node an operation on its inputs (graphs.js topologicalOrder: made in that order).
    const P=library.get(protagonist.id),attack=Math.min(P.frames-1,Math.round(.12*rate));
    const tailRegion=makeRegion(P,{id:`${P.id}.tail`,start:attack,end:P.frames,label:'its decay'});
    const ring=library.get(otherRing.id),ringTail=makeRegion(ring,{id:`${ring.id}.tail`,start:Math.min(ring.frames-1,Math.round(.05*rate)),end:ring.frames});
    // (Each field as long as its section and into the next: the decay's until the development's cloud is in, the cloud's
    // until the return has come.)
    // (And the return's closing field from the return to the piece's end, however long the form makes it: Op. 3.7's first
    // render, its return eight phrases long, had the exposition's field for it, and no tape for its last 106 s.)
    const fieldSeconds=developmentAt+ACOUSMATIC.overlap,cloudSeconds=returnAt-developmentAt+ACOUSMATIC.overlap,closeSeconds=total-returnAt+ACOUSMATIC.overlap;
    const nodes=[
      {id:'field',inputs:[P.id],op:'stretch',read:[{material:P,region:tailRegion}],params:{ratio:Math.max(2,fieldSeconds/Math.max(.5,tailRegion.end/rate-tailRegion.start/rate)),attackSeconds:.01}},
      {id:'cloud',inputs:[P.id],op:'granulate',read:[{material:P}],params:{seconds:cloudSeconds,density:18+random()*30,grainSeconds:.05+random()*.1,position:[[0,.02],[.6,.4],[1,.9]],spread:.04,rate:1,jitter:.3+random()*2},seeded:true},
      {id:'ghost',inputs:['cloud',ring.id],op:'convolve',read:[{node:'cloud'},{material:ring,region:ringTail}],params:{normalize:true}},
      {id:'close',inputs:[P.id],op:'stretch',read:[{material:P,region:tailRegion}],params:{ratio:Math.max(2,closeSeconds/Math.max(.5,tailRegion.end/rate-tailRegion.start/rate)),attackSeconds:.01}},
      {id:'swell',inputs:[P.id],op:'reverse',read:[{material:P,region:makeRegion(P,{id:`${P.id}.first`,start:0,end:Math.min(P.frames,Math.round(Math.min(8,P.seconds)*rate))})}],params:{}},
      {id:'answer-echo',inputs:[answerer.id],op:'rate',read:[{material:library.get(answerer.id)}],params:{rate:.5}},
    ];
    const graph=[...chosen.map(s=>({id:s.id,inputs:[]})),...nodes];
    const made=new Map;
    for(const node of topologicalOrder(graph)){
      if(library.has(node.id)){made.set(node.id,library.get(node.id));continue}
      const inputs=node.read.map(entry=>entry.node?made.get(entry.node).channels[0]:regionSamples(entry.material,entry.region));
      const seed=node.seeded?`${this.seed}:${node.id}`:null;
      const result=apply(node.op,inputs,node.params,{seed,sampleRate:rate});
      const parents=node.read.map(entry=>entry.node?{material:made.get(entry.node)}:{material:entry.material,...(entry.region?{region:entry.region}:{})});
      made.set(node.id,derive({id:node.id,channels:[result.samples],sampleRate:rate,parents,operation:{id:node.op,version:result.spec.version},parameters:node.params,seed}));
    }
    // Its family: what each stage keeps of the protagonist, and what it is meant to do.
    const family=new SoundFamily(P)
      .add(made.get('field'),{parent:P.id,transform:'stretch',changed:['attack','envelope','density'],retained:['spectrum','pitch'],relation:'its decay held into a field'})
      .add(made.get('cloud'),{parent:P.id,transform:'granulate',changed:['attack','envelope','trajectory','density'],retained:['spectrum'],relation:'the impact scattered into the texture the next comes out of'})
      .add(made.get('ghost'),{parent:'cloud',transform:'convolve',changed:['spectrum','context'],relation:'the scattered impact heard through the other source\'s ringing'})
      .add(made.get('close'),{parent:P.id,transform:'stretch',changed:['attack','envelope','density'],retained:['spectrum','pitch'],relation:'its decay held again, from the return to the end'})
      .add(made.get('swell'),{parent:P.id,transform:'reverse',changed:['envelope','trajectory'],retained:['spectrum','pitch','association'],relation:'its own decay running back into it: the return announced'});
    // The form: events and their relations, solved (graphs.js). Bounds scaled to the piece's length.
    const len=id=>made.get(id).seconds;
    // (Whether it rests through its development: its own choice, where the silence would be long enough to be one.)
    // (Its field into the development begun at most 1.5 s after its impact: the residue relation's bound, below.)
    const restFrom=developmentAt+ACOUSMATIC.overlap+1.5,restTo=returnAt-len('swell');
    const rests=restTo-restFrom>=ACOUSMATIC.rest.least&&restTo-restFrom<=ACOUSMATIC.rest.most*total&&keyedRandom(`${this.seed}:acousmatic:rest`)()<ACOUSMATIC.rest.chance
      ?[{stage:'development',from:+restFrom.toFixed(3),to:+restTo.toFixed(3),why:'its own choice: the orchestra develops alone'}]:[];
    const resting=id=>rests.length>0&&DEVELOPMENT.includes(id);
    const events=[
      {id:'impact',material:P.id},{id:'residue',material:'field'},{id:'answer',material:answerer.id},{id:'echo',material:'answer-echo'},
      {id:'interrupt',material:interrupter.id},{id:'scatter',material:'cloud'},{id:'hidden',material:'ghost'},{id:'cut-across',material:answerer.id},
      {id:'swell',material:'swell'},{id:'return',material:P.id},{id:'last-residue',material:'close'}];
    const relations=[
      {from:'impact',to:'residue',kind:'residue',lower:.3,upper:1.5},{from:'impact',to:'answer',kind:'answer',lower:3*scale,upper:8*scale},
      {from:'answer',to:'echo',kind:'answer',lower:.4,upper:2},{from:'answer',to:'interrupt',kind:'interrupt',lower:4*scale,upper:10*scale},
      {from:'impact',to:'scatter',kind:'accumulate',lower:developmentAt,upper:developmentAt+4},{from:'scatter',to:'hidden',kind:'conceal',lower:3*scale,upper:8*scale},
      {from:'scatter',to:'cut-across',kind:'interrupt',lower:12*scale,upper:20*scale},
      {from:'impact',to:'return',kind:'return',lower:returnAt,upper:returnAt+6},
      // (The swell ends exactly where the impact returns.)
      {from:'swell',to:'return',kind:'answer',lower:len('swell'),upper:len('swell')},{from:'return',to:'last-residue',kind:'residue',lower:.3,upper:1.5}]
      .filter(relation=>!resting(relation.from)&&!resting(relation.to));
    events.splice(0,events.length,...events.filter(e=>!resting(e.id)));
    const solved=solveTemporal(events.map(e=>e.id),relationBounds(relations));
    if(solved.inconsistent)throw new Error(`its relations cannot all hold: ${solved.cycle.join(' -> ')}`);
    // (Its struck events drawn toward the form's nearest bar line by its synchrony, its fields after them moved with
    // them: relation.synchrony.)
    const grid=this.form?.grid??[],nearestBar=t=>{const section=grid.findLast(item=>item.at<=t+1e-9);if(!section)return t;const k=Math.round((t-section.at)/section.barSeconds);return section.at+Math.max(0,Math.min(section.bars,k))*section.barSeconds};
    // (And, where the band's theme is heard, its onsets in each bar too -- the theme's first bar laid over every bar, in
    // the section's own beat: the orchestra's motif the tape's struck events take after, the continuum's other way.)
    const first=this.motifLine?.length>=2?Math.min(...this.motifLine.map(note=>note.at)):null,onsets=first==null?[]:this.motifLine.map(note=>note.at-first);
    const nearestMark=t=>{let best=nearestBar(t);const section=grid.findLast(item=>item.at<=t+1e-9);if(!section||!onsets.length||!(section.beatSeconds>0))return best;
      const k0=Math.floor((t-section.at)/section.barSeconds);
      for(const k of [k0-1,k0,k0+1]){if(k<0||k>=section.bars)continue;for(const quarters of onsets){const offset=quarters*section.denominator/4*section.beatSeconds;if(offset>=section.barSeconds-1e-9)continue;
        const at=section.at+k*section.barSeconds+offset;if(Math.abs(at-t)<Math.abs(best-t))best=at}}
      return best};
    if(this.relation.synchrony>0&&grid.length){
      const after={residue:'impact',scatter:null,hidden:null,'last-residue':'return'},moved=new Map;
      for(const e of events){if(e.id in after)continue;const t=solved.times.get(e.id);if(!Number.isFinite(t))continue;const to=t+this.relation.synchrony*(nearestMark(t)-t);moved.set(e.id,to-t);solved.times.set(e.id,to)}
      for(const [id,from] of Object.entries(after))if(from&&solved.times.has(id)&&moved.has(from))solved.times.set(id,solved.times.get(id)+moved.get(from));
    }
    // Each event a gesture in free time: its level and its place between the speakers (impacts placed, fields moving).
    const place=()=>+(random()*1.4-.7).toFixed(3);
    this.plan=events.map(e=>{
      const m=made.get(e.material),start=solved.times.get(e.id),field=['residue','scatter','hidden','last-residue'].includes(e.id);
      const seconds=Math.min(m.seconds,Math.max(.5,total-start));
      const from=place(),to=field?-from:from;
      const level=this.levelAt(start),dynamic=level==null?1:db(ACOUSMATIC.dynamicsDb*(level-.5));
      return {...e,start,seconds,...(level!=null?{level:+level.toFixed(3)}:{}),gain:dynamic*(e.id.includes('residue')||field?db(ACOUSMATIC.levelDb)/Math.max(1e-6,rmsOf(m.channels[0])):db(ACOUSMATIC.impactPeakDb)/Math.max(1e-6,peakOf(m.channels[0]))),
        gesture:gesture({clock:'seconds',start,length:seconds,curves:{level:field?[[0,0],[.15,1],[.8,.7],[1,0]]:[[0,1],[.97,1],[1,0]],pan:[[0,from],[1,to]]}})};
    }).filter(e=>e.start<total);
    // (The band's own sound returned, where it can hear the band and the exposition is long enough to give it: planned
    // now, made once its seconds have been heard, at the return's level.)
    const {capture}=ACOUSMATIC,imitate=keyedRandom(`${this.seed}:imitation`),hears=typeof this.audio?.hearBand==='function';
    // (Its development's fields made from the band's own last seconds before each, by its imitation's share.)
    if(hears)for(const field of this.plan.filter(e=>['scatter','hidden'].includes(e.id))){
      const to=field.start-1,from=to-capture.seconds;if(from<0||!(imitate()<this.relation.imitation))continue;
      Object.assign(field,{material:`capture:${field.id}`,capture:{from,to},pending:true});
    }
    if(hears&&developmentAt>=capture.seconds+1&&returnAt<total-1&&imitate()<this.relation.imitation){
      const seconds=Math.min(capture.lasts,total-returnAt),level=this.levelAt(returnAt);
      this.plan.push({id:'band-return',material:'capture',start:returnAt,seconds,capture:{from:developmentAt-capture.seconds,to:developmentAt},...(level!=null?{level:+level.toFixed(3)}:{}),
        pending:true,gesture:gesture({clock:'seconds',start:returnAt,length:seconds,curves:{level:[[0,0],[.2,1],[.8,.8],[1,0]],pan:[[0,-.5],[1,.5]]}})});
    }
    // (A rest's span as its events leave it: from where the last before it ends to where the swell into the return begins.)
    for(const rest of rests){const swell=this.plan.find(e=>e.id==='swell');rest.to=+swell.start.toFixed(3);
      rest.from=+Math.max(...this.plan.filter(e=>e.start<swell.start).map(e=>e.start+e.seconds)).toFixed(3)}
    this.materials=made;this.family=family;
    // (Each material's pitch, measured once: what its harmony relation moves.)
    this.pitches=new Map([...made.values()].map(m=>[m.id,pitchOf(m.channels[0],m.sampleRate)]));
    // (And its contour, said with each of its events for the orchestra to imitate: plex_clodbot tapeMaterial.)
    this.contours=new Map([...made.values()].map(m=>[m.id,contourOf(m.channels[0],m.sampleRate,{clarity:ACOUSMATIC.relation.clarity})]));
    // (And its brightness: what its fusion with the band moves.)
    this.brightness=new Map([...made.values()].map(m=>[m.id,brightnessOf(m.channels[0],m.sampleRate)]));
    const provenance=[...made.values()].map(m=>({id:m.id,hash:m.hash,seconds:+m.seconds.toFixed(3),sources:provenanceOf(m,made),...(m.operation?{operation:m.operation.id,version:m.operation.version,parameters:m.operation.parameters,seed:m.operation.seed}:{credit:m.source.attribution,url:m.source.url}),rights:m.rights}));
    // (Its end: the last of its events', which whoever ends the piece waits for, as for a song set whole.)
    const end=Math.max(...this.plan.map(e=>e.start+e.seconds));
    const summary={seed:this.seed,protagonist:P.id,seconds:total,end:+end.toFixed(3),...(this.plan.some(e=>e.pending)?{captures:this.plan.filter(e=>e.pending).map(e=>({id:e.id,from:+e.capture.from.toFixed(3),to:+e.capture.to.toFixed(3),at:+e.start.toFixed(3)}))}:{}),stages:timing.from,developmentAt:+developmentAt.toFixed(3),returnAt:+returnAt.toFixed(3),rests,...(timing.joins?{joins:timing.joins}:{}),events:this.plan.map(e=>{const heard=this.pitches.get(e.material),contour=this.contours.get(e.material);
      return {id:e.id,material:e.material,start:+e.start.toFixed(3),seconds:+e.seconds.toFixed(3),...(heard?.clarity>=ACOUSMATIC.relation.clarity?{pitch:heard.pitch}:{}),...(contour?.some(p=>p!=null)?{contour}:{})}}),family:family.edges.map(edge=>({from:edge.from,to:edge.to,transform:edge.transform,relation:edge.relation})),provenance};
    this.decide({plan:summary});
    return summary;
  }
  // The render's length in seconds where the render fixes one (audio.renderEnd): as given in seconds; in bars or ticks, at
  // the bar and tempo its clock begins in, as the soloists read it. Null where none is fixed.
  renderSeconds(clock){
    const end=this.audio?.renderEnd,perTick=clock?secondsPerTick(clock):null,perBar=clock?.meter?.pulsesPerBar;
    return end?.seconds>0?Number(end.seconds):end?.bars>0&&perBar&&perTick?end.bars*perBar*perTick:end?.ticks>0&&perTick?end.ticks*perTick:null;
  }
  // Its events placed on the audio clock once its sources are ready and it knows the form (or has waited for it as long
  // as its lead allows): each a buffer through its level and its place between the speakers, into its channel, its time
  // from the piece's first tick.
  onTick(tick,clock){
    if(this.started){if(this.revisedForm)this.revise(clock);this.returnBand();this.fuse();return}
    if(!this.gathered||!this.audio?.ctx||!this.audio?.master)return;
    const elapsed=(this.firstTick==null?(this.firstTick=tick,0):(tick-this.firstTick))*secondsPerTick(clock);
    if(!this.form&&elapsed<ACOUSMATIC.lead/2)return;
    this.started=true;this.renderLength=this.renderSeconds(clock);const summary=this.prepare();
    const ctx=this.audio.ctx,t0=ctx.currentTime-elapsed+ACOUSMATIC.lead;
    // (Said with the tick its last sound ends at, so that the piece is not ended before it: plex_clodbot hears it as a song
    // set whole.)
    const perTick=secondsPerTick(clock);
    this.broadcast?.('acousmatic/plan',[{...summary,startTick:this.firstTick,endTick:Math.ceil(this.firstTick+(summary.end+ACOUSMATIC.lead)/perTick)}]);
    this.t0=t0;this.perTick=perTick;
    for(const event of this.plan)if(!event.pending)this.schedule(event);
    // (The band heard, as the hall hears it, from now: the captures it returns, and the brightness its fusion moves to.)
    if((this.plan.some(event=>event.pending)||this.relation.fusion>0)&&typeof this.audio.hearBand==='function'){
      const rate=this.audio.ctx.sampleRate;this.captured=new CaptureBuffer({sampleRate:rate,seconds:ACOUSMATIC.capture.holds,title:'the band, as the hall hears it',creator:'the band'});
      this.capturedFrom=null;
      this.untapBand=this.audio.hearBand(({channels,frame,silent})=>{this.capturedFrom??=frame;const [a,b]=channels;
        this.captured.write(silent?new Float32Array(a.length):b?Float32Array.from(a,(v,i)=>(v+b[i])/2):a)});
    }
    this.decide({started:+t0.toFixed(3),events:this.plan.length});
  }
  // An event's buffer through its level and its place between the speakers, into its channel, at its time.
  schedule(event){
    const ctx=this.audio.ctx,m=this.materials.get(event.material),frames=Math.min(m.frames,Math.round(event.seconds*m.sampleRate));
    const buffer=ctx.createBuffer(1,frames,m.sampleRate);buffer.getChannelData(0).set(m.channels[0].subarray(0,frames));
    const source=ctx.createBufferSource(),level=ctx.createGain(),pan=ctx.createStereoPanner();source.buffer=buffer;
    // (Its fusion's shelf, at its own brightness, flat until the band is heard: relation.fusion.)
    const {lowest,highest}=ACOUSMATIC.relation.shelf,own=this.brightness?.get(event.material)??null;
    const shelf=this.relation.fusion>0&&own&&typeof ctx.createBiquadFilter==='function'?ctx.createBiquadFilter():null;
    if(shelf){shelf.type='highshelf';shelf.frequency.value=Math.max(lowest,Math.min(highest,own));shelf.gain.value=0}
    const steps=Math.max(2,Math.ceil(event.seconds*20)),curve=key=>Float32Array.from({length:steps},(_,k)=>controlsAt(event.gesture,k/(steps-1))[key]);
    // (Each held at its curve's first value until the curve begins: a source's first frame can fall a rounding before its
    // curve's time, and there a gain left at its default of 1 sounded the field's first sample whole -- Op. 3.7's click
    // at its residue's start, 0.3 s in.)
    const at=this.t0+event.start,levels=curve('level').map(v=>v*event.gain),pans=curve('pan');
    level.gain.value=levels[0];pan.pan.value=pans[0];level.gain.setValueCurveAtTime(levels,at,event.seconds);pan.pan.setValueCurveAtTime(pans,at,event.seconds);
    (shelf?source.connect(shelf).connect(level):source.connect(level)).connect(pan).connect(this.audio.master);source.start(at);source.stop(at+event.seconds+.05);
    (this.placed??=new Map).set(event.id,{source,level,at,end:at+event.seconds,material:event.material,...(shelf?{shelf,own}:{})});
    if(this.chordClasses)this.retune(event.id);
  }
  // Its sounds' brightness moved toward the band's (relation.fusion): every `every` seconds, the band's brightness over its
  // last `window` seconds as captured, and each placed event not yet ended given its shelf's gain for it, from its start
  // or from now. Nothing where the band is silent or not yet heard long enough.
  fuse(){
    const ctx=this.audio?.ctx,{every,window,perOctave,most,rise}=ACOUSMATIC.relation.shelf;
    if(!(this.relation.fusion>0)||!this.captured||!ctx||!this.placed?.size)return;
    const now=ctx.currentTime??0;if(now<(this.fusedAt??-Infinity)+every)return;this.fusedAt=now;
    const heard=this.captured.recent(window);if(!heard)return;
    const band=brightnessOf(heard,this.captured.sampleRate,{from:0,length:heard.length});if(!band)return;
    let moved=0;
    for(const entry of this.placed.values()){
      if(!entry.shelf||!entry.own||entry.end<=now)continue;
      const db=this.relation.fusion*Math.max(-most,Math.min(most,perOctave*Math.log2(band/entry.own)));
      entry.shelf.gain.setTargetAtTime?.(db,Math.max(now,entry.at),rise);entry.fusedDb=+db.toFixed(2);moved++;
    }
    if(moved)this.decide({fusion:{band,moved,at:+now.toFixed(2)}});
  }
  // A placed event moved toward the chord last said (relation.harmony): its material's pitch to the nearest of the chord's
  // classes, that share of the way, by its playback's rate, gliding; a sound without a clear pitch, or one that has ended,
  // as it is.
  retune(id){
    const entry=this.placed?.get(id),ctx=this.audio?.ctx,heard=entry&&this.pitches?.get(entry.material);
    if(!entry||!heard||!(heard.clarity>=ACOUSMATIC.relation.clarity)||!(this.relation.harmony>0)||!this.chordClasses?.length||!entry.source?.playbackRate)return;
    const now=ctx?.currentTime??0;if(entry.end<=now)return;
    const own=((heard.pitch%12)+12)%12,shift=this.chordClasses.map(pc=>((pc-own+18)%12)-6).reduce((best,d)=>Math.abs(d)<Math.abs(best)?d:best);
    entry.source.playbackRate.setTargetAtTime?.(2**(this.relation.harmony*shift/12),Math.max(now,entry.at),ACOUSMATIC.relation.glide);
    entry.shift=+(this.relation.harmony*shift).toFixed(3);
  }
  // Its events placed again where the form has changed since they were laid out (a conductor planning a phrase ahead
  // decides its form as it goes, and the tape, laid out before its first sound, had only what it expected of it; measured,
  // research/PLANNING_AHEAD.md: its return 20 to 89 s from the band's). The form solved again from the same draws (its
  // gathered `fresh`), at the form's new stages; each event begun, or due within its lead, kept as it sounds (what has
  // begun to sound stays: the rap supplement's R024), each other one taken back and placed anew; a capture of the band
  // already made kept, moved with its return. Not where the stages are as they were.
  revise(clock){
    const form=this.revisedForm;this.revisedForm=null;
    const random=this.gathered.fresh(),timing=timingOf(form,random,this.renderLength??this.audio?.renderEnd?.seconds),was=this.timing;
    if(was&&!this.motifHeard&&['total','developmentAt','returnAt'].every(key=>Math.abs((timing[key]??0)-(was[key]??0))<=ACOUSMATIC.revise))return;
    this.motifHeard=false;
    const now=this.audio.ctx.currentTime,begun=event=>this.t0+event.start<now+ACOUSMATIC.lead,old=new Map(this.plan.map(event=>[event.id,event]));
    const oldMaterials=this.materials;this.form=form;
    const summary=this.prepare(timing,random),kept=[],moved=[];
    this.plan=this.plan.map(event=>{
      const before=old.get(event.id);
      if(before&&begun(before)){kept.push(event.id);return before}
      const handle=this.placed?.get(event.id);
      if(handle){try{handle.source.stop(0)}catch{/* never started */}handle.level.disconnect?.();this.placed.delete(event.id)}
      // (The band's sound already captured and made: the same field, at the return's new time; refused, still refused.)
      if(before?.capture&&!before.pending){
        const made=oldMaterials.get(before.material);
        if(!made||!handle){moved.push(event.id);return {...event,pending:false,refused:true}}
        this.materials.set(event.material,made);event={...event,pending:false,gain:before.gain};
      }
      if(!event.pending)this.schedule(event);moved.push(event.id);return event;
    });
    for(const [id,event] of old)if(!this.plan.some(item=>item.id===id)&&!begun(event)){const handle=this.placed?.get(id);if(handle){try{handle.source.stop(0)}catch{}handle.level.disconnect?.();this.placed.delete(id)}}
    const end=Math.max(...this.plan.map(event=>event.start+event.seconds));
    this.broadcast?.('acousmatic/plan',[{...summary,end:+end.toFixed(3),revised:true,startTick:this.firstTick,endTick:Math.ceil(this.firstTick+(end+ACOUSMATIC.lead)/this.perTick)}]);
    this.decide({revised:{returnAt:+timing.returnAt.toFixed(3),total:+timing.total.toFixed(3),kept,moved}});
  }
  // Each capture it planned, once its seconds have all been heard (CaptureBuffer: closed and still held): sealed, made
  // its event's field (granulated to the event's length), and placed, where its time has not come; else let go, and said.
  returnBand(){
    if(!this.captured)return;
    for(const event of this.plan.filter(item=>item.pending)){
      const offset=this.t0-(this.capturedFrom??0)/this.audio.ctx.sampleRate,from=event.capture.from+offset,to=event.capture.to+offset;
      if(this.captured.status(from,to)==='open')continue;
      event.pending=false;
      const sealed=this.captured.seal(from,to);
      const said={id:event.id,from:+event.capture.from.toFixed(3),to:+event.capture.to.toFixed(3),at:+event.start.toFixed(3)};
      if(sealed.refused||this.t0+event.start<this.audio.ctx.currentTime+ACOUSMATIC.lead){const why=sealed.refused??'its time had come';this.decide({capture:event.id,refused:why});this.broadcast?.('acousmatic/capture',[{...said,refused:why}]);continue}
      const made=this.captureField(sealed.material,event);this.materials.set(event.material,made.material);event.gain=made.gain;
      this.schedule(event);this.decide({capture:event.id,made:made.material.id,seconds:+event.seconds.toFixed(3)});
      // (Said, with what it was made from: the band, as the hall heard it, and how.)
      this.broadcast?.('acousmatic/capture',[{...said,seconds:+event.seconds.toFixed(3),hash:made.material.hash,from_hash:sealed.material.hash,operation:'granulate'}]);
    }
    // (Its captures made, the band let go of -- unless its fusion still hears it.)
    if(!this.plan.some(item=>item.pending)&&!(this.relation.fusion>0)){this.untapBand?.();this.untapBand=null;this.captured=null}
  }
  // A capture made its event's field: granulated to the event's length, at a field's level moved by the event's planned
  // level. -> {material, gain}.
  captureField(captured,event){
    const {capture}=ACOUSMATIC,rate=captured.sampleRate,params={seconds:event.seconds,density:capture.density,grainSeconds:capture.grainSeconds,position:[[0,.05],[1,.95]],spread:capture.spread,rate:1,jitter:capture.jitter};
    const seed=`${this.seed}:${event.id}`,result=apply('granulate',[captured.channels[0]],params,{seed,sampleRate:rate});
    const material=derive({id:event.id,channels:[result.samples],sampleRate:rate,parents:[{material:captured}],operation:{id:'granulate',version:result.spec.version},parameters:params,seed});
    const dynamic=Number.isFinite(event.level)?db(ACOUSMATIC.dynamicsDb*(event.level-.5)):1;
    return {material,gain:dynamic*db(ACOUSMATIC.levelDb)/Math.max(1e-6,rmsOf(result.samples))};
  }
}

export const acousmaticClodbot=defineBot(
  {
    id:'acousmatic_clodbot',name:'acousmatic_clodbot',status:'native',source:'clodbot',category:'texture',outputModes:['synth'],pitchContract:'none',
    // (What a programme calls it: its instrument is fixed media.)
    instrument:'fixed media',
    // (Its instrument is fetched recordings: silent in a bare bar with none; test/acousmatic-clodbot.test.mjs plays it.)
    requiresCorpus:true,
    description:'A fixed-media performer, the projectionist of sounds made from recordings: approved CC0 recordings (gong, timpani, harp, wood and metal percussion) made into families -- the impact, its decay held into a field, a grain cloud, that cloud heard through another source\'s ringing, the impact\'s reversal -- each keeping its provenance; its form relations in free time (an impact and its residue, answers, interruptions, fields accumulating, a concealed cross-synthesis, the first source\'s late return), solved as a temporal network; each event a gesture of level and place between the speakers.',
    specSettings:Object.freeze(['seed','relation']),
    // (Its relation to the band an object: {harmony, synchrony}.)
    specObjects:Object.freeze(['relation']),
  },
  (...args)=>new AcousmaticClodbot(...args),
);
