// edit_clodbot: the Mixbot's edits, made at the form's joins as a producer makes them in a mix. New, not a fork. The user,
// 26 September 2026: "6. Submix and whole-mix cuts -- for example, heavy rock mixes (think Linkin Park) sometimes cut
// whole sections of a mix, reverb and all, at drastic section transitions."
//
// It hears the form's plan (form_clodbot's, each section with its tension, 0 to 1; or PlexBOT's, each section announced a
// phrase ahead where the clock will make it: shared/form-joins.js), as feedback_clodbot does, and finds the
// form's drastic joins: those across which the tension moves furthest, by the form's own measure (EDIT.dramaShare of its
// largest move, and at least leastDrama). Before each it cuts the mix for the last felt beat of the bar (meter-tactus.js
// feltBeats: the beat a listener counts, a group in an additive meter), reverb and all (/agent/cut: shared/mix-cuts.js),
// so the next section lands out of silence:
//   - into more tension (a climax, a contrast), the band drops out and the lead carries across (what: 'band');
//   - into less (a climax giving way to its relaxation, to the return, to the close), the whole mix stops (what: 'all').
// Whole again on the join's downbeat. What it cuts and when is its own decision, from the plan; the desk only cuts.
//
// And at the form's other joins, those the tension still moves across (EDIT.leastEdit or more), it decorates the last felt
// beat with an edit from what was just played (/agent/edit: shared/mix-edits.js; the user: "7. Effects that can only be
// done as postprocessing, such as reverses (again think Linkin Park and its vinyl-inspired short-term sample repetitions
// and other in-the-mix decorations)"):
//   - into a return, a rewind: the beat just played, played backwards, back to where the piece began ('reverse');
//   - into more tension otherwise, a stutter: the beat's first slice, a quarter of it, over and over ('repeat');
//   - into less, a tape stop: the mix slowing to a halt into the join ('tapeStop').
// It says what it will do at each join as soon as it hears the form (/broadcast/edits: shared/form-joins.js), so that the
// players can play into it -- a drummer fills into a stutter and lands the join on a crash, leaves a cut's beat to the
// cut (bots/lib/modules/form-marks.js): the user, on these edits heard while the band played on unchanged, "it didn't
// have enough reinforcement from other simultaneous changes to sound intentional."
//
// These need only the past, so a live desk can play them. What they cannot do is reverse what has not been played yet:
// a reversed swell of the next section's first chord. That is where musebots' plans help: the harmony that is coming is
// announced bars ahead, so a bot that plays it can play it reversed, swelling in to its downbeat (the user's question
// 7.1); this bot, which plays nothing, asks only for what the desk can make from the past.
import {SOUND_STATES_ADDRESS} from '../../shared/rate-contract.js';
import {defineBot} from '../../framework/index.js';
import {Agent} from '../../framework/agent.js';
import {secondsPerTick,feltBeats} from '../../shared/meter-tactus.js';
import {Closure} from '../lib/modules/closure.js';
import {EDITS_ADDRESS,formJoins,isReturn,withAnnouncement} from '../../shared/form-joins.js';

export {formJoins};

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const EDIT=Object.freeze({
  // A join is drastic when the tension moves across it by this share of the form's largest move or more, and by at least
  // leastDrama (ours: the form's biggest changes, and none in a form whose sections barely differ).
  dramaShare:.8,leastDrama:.3,
  // The least move in tension a join takes an edit at (ours: a join with barely a change needs no decoration), and a
  // stutter's slice, the share of the felt beat it repeats (ours: a sixteenth of a quarter-note beat).
  leastEdit:.15,sliceShare:.25,
  decisionsKept:256,
});

// The drastic joins: those whose move is the form's largest, or near it.
export function drasticJoins(joins,{dramaShare,leastDrama}=EDIT){
  const largest=Math.max(0,...joins.map(join=>Math.abs(join.move)));
  return joins.filter(join=>Math.abs(join.move)>=Math.max(leastDrama,dramaShare*largest));
}

// The joins that take an edit: those the tension moves across by leastEdit or more that are not drastic (those are cut),
// each with the edit it takes.
export function editedJoins(joins,choices=EDIT){
  const drastic=new Set(drasticJoins(joins,choices).map(join=>join.bar));
  return joins.filter(join=>!drastic.has(join.bar)&&Math.abs(join.move)>=choices.leastEdit)
    .map(join=>({...join,edit:isReturn(join.to)?'reverse':join.move>0?'repeat':'tapeStop'}));
}

export class EditClodbot extends Closure(Agent){
  constructor(send,audio,settings={}){
    super(send,audio);
    this.settings={...settings};this.form=null;this.cut=new Set;this.edited=new Set;this.prepared=false;this.decisions=[];this.announcedSections=[];
  }
  decide(entry){this.decisions.push(entry);if(this.decisions.length>EDIT.decisionsKept)this.decisions.shift()}
  // form_clodbot's plan: its sections and where it begins.
  onPlan(plan){
    this.announcedSections=withAnnouncement(this.announcedSections,plan);
    if(plan?.kind==='form')this.form=plan;
    if(this.form)this.announce();
    return super.onPlan?.(plan);
  }
  // The form's joins, where the clock will make them (shared/form-joins.js).
  joins(){return formJoins(this.form,{announced:this.announcedSections})}
  // What it will do at each join still to come (none once the ending is known: the close is the players'), said to the
  // ensemble whenever that changes.
  plannedJoins(){
    if(this.closingAt?.(this.currentClock??{})?.ending)return [];
    const joins=this.joins();
    return [...drasticJoins(joins).map(join=>({bar:join.bar,kind:'cut',what:join.move>0?'band':'all',move:+join.move.toFixed(3),to:join.to})),
      ...editedJoins(joins).map(join=>({bar:join.bar,kind:join.edit,what:'all',move:+join.move.toFixed(3),to:join.to}))].sort((a,b)=>a.bar-b.bar);
  }
  announce(){
    const joins=this.plannedJoins(),key=JSON.stringify(joins);
    if(key===this.announced)return;
    this.announced=key;
    this.send(EDITS_ADDRESS,[{source:this.instanceId??'edit_clodbot',form:this.form?.planId??null,joins}]);
  }
  onTick(tick,clock){
    if(!clock?.meter)return;
    // The desk's edits made ready at the start, so the first is not waiting on its module.
    if(!this.prepared){this.prepared=true;this.send('/agent/edit',[{prepare:true}])}
    const perTick=secondsPerTick(clock),beats=feltBeats(clock.meter,{secondsPerTick:perTick}),last=beats.at(-1);
    // No cut once the ending is known: the close is the players'.
    this.announce();
    if(this.closingAt?.({...clock,tick})?.ending)return;
    for(const join of drasticJoins(this.joins())){
      if(this.cut.has(join.bar)||clock.bar!==join.bar-1||clock.tickInBar<last.start)continue;
      this.cut.add(join.bar);
      const what=join.move>0?'band':'all',seconds=(last.start+last.length-clock.tickInBar)*perTick;
      const why=`${what==='band'?'the band drops out under the lead':'the whole mix stops'}, reverb and all, for the last beat before bar ${join.bar} `
        +`(${join.from} to ${join.to}, the tension ${join.move>0?'rising':'falling'} by ${Math.abs(join.move).toFixed(2)})`;
      this.send('/agent/cut',[{what,seconds,inSeconds:0,returns:true,bar:join.bar,why}]);
      // Said as an intentional silence to the join's downbeat (shared/rate-contract.js): the quiet is the edit's, not a
      // stop, a failure or a gap for anyone to fill.
      this.send(SOUND_STATES_ADDRESS,[{voice:what,state:'intentional-silence',since:tick,until:tick+clock.meter.pulsesPerBar-clock.tickInBar,basis:'ticks'}]);
      this.decide({tick,bar:clock.bar,join:join.bar,what,seconds:+seconds.toFixed(3),why});
    }
    for(const join of editedJoins(this.joins())){
      if(this.edited.has(join.bar)||clock.bar!==join.bar-1||clock.tickInBar<last.start)continue;
      this.edited.add(join.bar);
      const seconds=(last.start+last.length-clock.tickInBar)*perTick,slice=EDIT.sliceShare*last.length*perTick;
      const why=`${join.edit==='reverse'?'a rewind: the last beat played backwards':join.edit==='repeat'?'a stutter: the last beat\'s first slice repeated':'a tape stop'} `
        +`into bar ${join.bar} (${join.from} to ${join.to}, the tension ${join.move>0?'rising':'falling'} by ${Math.abs(join.move).toFixed(2)})`;
      this.send('/agent/edit',[{kind:join.edit,what:'all',seconds,inSeconds:0,...(join.edit==='repeat'?{slice}:{}),bar:join.bar,why}]);
      this.decide({tick,bar:clock.bar,join:join.bar,edit:join.edit,seconds:+seconds.toFixed(3),why});
    }
  }
}

export const editClodbot=defineBot(
  {
    id:'edit_clodbot',name:'edit_clodbot',status:'native',source:'clodbot',
    category:'conductor',outputModes:[],pitchContract:'none',
    description:'A mixbot for the edits a producer makes in a mix at the form\'s joins: before each section the tension moves furthest into or out of, it cuts the mix for the last felt beat of the bar, reverb and all -- the band dropping out under the lead into a climax, the whole mix stopping dead as a climax gives way -- so the next section lands out of silence; at the other joins it decorates that beat from what was just played: a rewind into a return, a stutter into more tension, a tape stop into less. It says what it will do at each join as soon as it hears the form (/broadcast/edits), so the players can play into it.',
  },
  (...args)=>new EditClodbot(...args),
);
