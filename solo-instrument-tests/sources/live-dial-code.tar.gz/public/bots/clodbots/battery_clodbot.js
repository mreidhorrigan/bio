// battery_clodbot: an orchestral percussionist on the battery -- bass drum, clash cymbals, snare drum, suspended cymbal,
// tambourine and triangle, one at a time (shared/performers/battery.js; the owner, 2 October 2026: "include the rest of
// the orchestra to the extent possible"). Seated in an orchestra's percussion section, it takes the instrument its
// section's conductor casts it on for each phrase (the formation's `instruments`, by seat), and rests where its section
// rests it; alone, it casts itself, a phrase at a time, by the intensity the music is at. What it plays on that
// instrument through the phrase is its own: battery.js batteryPhrase, from the form's joins (where the music arrives,
// and where the next section begins), the meter's groups, its level and its pulse (from colouring to a groove).
//
// Its instruments are recorded (VSCO 2 CE's: data/drum-kits/vsco-orchestral.json), played where its kit has them; its
// notes go to a plugin or out to MIDI, for the instrument there to sound. On the synthesized kit it plays what that kit
// has (a kick, a snare, a crash, a struck voice), and on a sampled kit without an instrument it plays nothing there, and
// says so.
import {defineBot} from '../../framework/index.js';
import {Agent} from '../../framework/agent.js';
import {Closure} from '../lib/modules/closure.js';
import {PerformedTiming} from '../lib/modules/performed-timing.js';
import {FormMarks,marksJoin} from '../lib/modules/form-marks.js';
import {InSection} from '../lib/modules/section-member.js';
import {onsetsPayload} from '../../shared/sounding-voices.js';
import {secondsPerTick} from '../../shared/meter-tactus.js';
import {formJoins} from '../../shared/form-joins.js';
import {BATTERY,castBattery,batteryPhrase,batteryHocket} from '../../shared/performers/battery.js';
import {bandPhraseBars} from '../../shared/opening-time.js';
import {seededSource} from '../../shared/performers/string-section.js';
import {dynamicOf} from '../../shared/performers/section-voices.js';
import {scoreTime,withScoreTime} from '../../shared/score-time.js';

const clamp=(value,low,high)=>Math.max(low,Math.min(high,value));

export class BatteryClodbot extends FormMarks(Closure(Agent)) {
  constructor(send,audio,settings={}){
    super(send,audio);
    this.settings={...settings};
    this.decisions=[];this.phrase=null;
  }
  // Whether its voice sounds `note`: a sampled kit with it, the synthesized kit, a plugin or MIDI out; never a notes-only
  // render's absent voice (which plays nothing, as every voice there does).
  sounds(note){
    const voice=this.audio?.percussionVoice?.();
    return voice==='sampled'?Boolean(this.audio.sampledKit?.()?.notes?.includes(note)):true;
  }
  // The form's joins, where there is a form (shared/form-joins.js), and the intensity the music arrives at in a bar
  // (ManageBOT's casting for its section, else the form's tension; the middle with no form): as gong_clodbot reads them.
  joins(){const form=this.activeFormPlan??this.markedForm;return form?formJoins(form,{announced:this.announcedSections}):[]}
  intensityAt(bar,joins=this.joins()){
    const form=this.activeFormPlan??this.markedForm,join=joins.filter(one=>one.bar<=bar).at(-1);
    const start=join?.bar??(Number(form?.appliesAt?.bar)||0),cast=this.castIntensities.get(start);
    const tension=join?join.toTension:Number(form?.payload?.sections?.[0]?.tension);
    return clamp(Number.isFinite(cast)?cast:Number.isFinite(tension)?tension:.5,0,1);
  }
  // The phrase beginning at the clock's bar: its length and level (its section's formation, else the band's phrase and
  // the music's intensity), its instrument (its section's casting, else its own), and its strokes.
  planPhrase(clock){
    const bar=clock.bar,said=this.memberPhraseAt?.(bar),joins=this.joins(),closing=this.closingAt(clock);
    const start=said?.bar??bar,bars=Math.max(1,said?.bars??clock.meter.phraseBars??bandPhraseBars());
    const level=Number.isFinite(said?.pool?.level)?clamp(said.pool.level,0,1):this.intensityAt(bar,joins);
    const random=seededSource(Number(said?.pool?.seed)||Number(this.settings.seed)||bar+1,`${this.memberOf?.seat??this.instanceId??'battery'}:${start}`);
    const instrument=said?.pool?.instruments?.[this.memberOf?.seat]??this.settings.instrument??castBattery(1,{level,random})[0];
    // (Its pulse, from colouring to a groove: its section's (none where it says none), else its settings', else alone its
    // own draw for the phrase, toward colouring as a section's is.)
    const asked=Number(this.settings.pulse),pulse=said?clamp(Number(said.pool?.pulse)||0,0,1):Number.isFinite(asked)?clamp(asked,0,1)
      :seededSource(Number(this.settings.seed)||bar+1,`${this.instanceId??'battery'}:${start}:pulse`)()**2;
    const end=start+bars,join=joins.find(one=>one.bar===start),next=joins.find(one=>one.bar===end);
    const arriving=Boolean(join)&&marksJoin({move:this.intensityAt(start,joins)-this.intensityAt(start-1,joins)})&&this.intensityAt(start,joins)>this.intensityAt(start-1,joins);
    const final=said?.final===true||closing.phase==='final'||(closing.ending?Number(closing.ending.finalBar)<end:false);
    // (A hocket where its section's battery grooves together and its pool's share draws one for the phrase: every tick of
    // the bar struck by one of its players, each its cell at its own entry -- battery.js batteryHocket.)
    const pool=said?.pool,seats=Array.isArray(pool?.seats)?pool.seats:[],index=seats.indexOf(this.memberOf?.seat);
    const hocketing=pulse>0&&seats.length>=2&&index>=0&&Number(pool?.hocket)>0&&seededSource(Number(pool.seed)>>>0,`hocket:${start}`)()<Number(pool.hocket);
    const hocket=hocketing?batteryHocket({ticks:Number(clock.meter?.pulsesPerBar)||0,players:seats.length,index,seed:Number(pool.seed)>>>0}):null;
    const strokes=batteryPhrase(instrument,{meter:clock.meter,bars,level,arriving,announcing:Boolean(next),final,secondsPerTick:secondsPerTick(clock),pulse,random,hocket});
    this.phrase={start,end,instrument,level,strokes,silent:!this.sounds(BATTERY.instruments[instrument].note)};
    this.decisions.push({bar:start,bars,instrument,level:+level.toFixed(3),pulse:+pulse.toFixed(3),...(hocket?{hocket:{cell:hocket.cell,entry:hocket.entry}}:{}),arriving,announcing:Boolean(next),final,strokes:strokes.length,
      ...(this.phrase.silent?{silent:`its kit has no ${BATTERY.instruments[instrument].name.toLowerCase()}`}:{})});
    if(this.decisions.length>128)this.decisions.shift();
  }
  // A coordinated hit: one stroke of the instrument its section casts it on, at the hit's level (section-member.js).
  punctuate(clock,pool){
    const instrument=pool?.instruments?.[this.memberOf?.seat]??this.phrase?.instrument,own=BATTERY.instruments[instrument];if(!own||!this.sounds(own.note))return;
    this.strike(clock,{kind:own.kind,note:own.note,velocity:dynamicOf(Math.max(0,Math.min(1,Number(pool?.level)||.7))).velocity,stroke:'hit'});
  }
  // (Written on its tick for its ticks, as its phrase composed it: battery.js batteryPhrase; a hit a beat.)
  strike(clock,stroke){
    const held=stroke.stroke==='roll'||stroke.stroke==='swell',ticks=stroke.ticks??(clock.meter?.subdivision||1);
    withScoreTime(this.audio,scoreTime(clock.tick,ticks),()=>this.audio.drum?.(stroke.kind,stroke.velocity,{note:stroke.note,...(held?{duration:stroke.seconds}:{}),
      ...(stroke.stroke==='hit'?{}:{strike:{stroke:stroke.stroke,...(stroke.stroke==='swell'?{peakIn:stroke.seconds}:{})}})}));
    this.broadcast('onsets',[onsetsPayload({voice:this.instanceId??'battery_clodbot',role:'drums',onsets:[{tick:clock.tick,strength:stroke.velocity,kind:'perc'}],group:this.memberOf?.group})]);
  }
  onTick(tick,clock){
    if(!clock?.meter||!Number.isInteger(clock.bar))return;
    if(this.closingAt(clock).phase==='after')return;
    // (Seated, it waits for its section's first word; then each phrase as its section says it, planned on the phrase's
    // first tick, or on the first tick it hears of it.)
    const said=this.memberOf?this.memberPhraseAt(clock.bar):null;if(this.memberOf&&!said)return;
    const begins=said?said.bar!==this.phrase?.start:(clock.tickInBar??0)===0&&(!this.phrase||clock.bar>=this.phrase.end||clock.bar<this.phrase.start);
    if(begins)this.planPhrase(clock);
    const phrase=this.phrase;if(!phrase||phrase.silent)return;
    const into=clock.bar-phrase.start,at=clock.tickInBar??0;
    for(const stroke of phrase.strokes)if(stroke.bar===into&&stroke.tick===at)this.strike(clock,stroke);
  }
}

// Played in the ensemble's feel, where one is set (the performance layer: docs/PERFORMANCE_TIMING.md); seated in a section
// where its settings seat it (section-member.js).
const PerformedBattery=InSection(PerformedTiming(BatteryClodbot));
export const batteryClodbot=defineBot(
  {
    id:"battery_clodbot",orchestral:true,name:"battery_clodbot",status:"native",source:"clodbot",
    category:"beat",midiChannel:10,outputModes:["synth","midi"],pitchContract:"fixed-percussion",instrument:"percussion",plural:"percussionists",
    kit:"vsco-orchestral",
    // Its seat in a percussion section, or alone the instrument it keeps to and its pulse (0 colouring, 1 a groove).
    specSettings:Object.freeze(["seat","size","kind","section","arrival","instrument","pulse"]),
    description:
      "An orchestral percussionist on the battery: bass drum, clash cymbals, snare drum, suspended cymbal, tambourine and triangle, one at a time, the instrument its section's conductor casts it on for each phrase by how loud the orchestra plays; on it, the bass drum's downbeats, the cymbals' arrivals, the suspended cymbal's swell into the next section, the snare's ostinato and its roll into a join, the tambourine's groups, the triangle's strokes or its roll. Recorded instruments, where its kit has them.",
  },
  (...args)=>new PerformedBattery(...args),
);
