// modalline_clodbot: a protected modal line with ornaments and an accompaniment that adapts around it (the harmonic-
// systems report §0.3.2: "a separately specified modal melody with a protected contextual pitch trajectory. The
// accompaniment must adapt around it instead of 'correcting' it to a convenient Western interval. Label this as a
// declared test profile until a knowledgeable practitioner validates its stylistic claims").
//
// The line's material is the rast declared test profile (harmonic-systems/package-fixtures.js MAQAM_RAST_TEST_PROFILE: its
// 24-EDO approximations, sikah at 350 cents, awj at 1050 rising and ajam at 1000 falling) -- a test profile, not maqam
// fidelity, and labelled so on every note. Its long notes take a grace from the step above, and it glides into sikah
// and awj from the step below (the synth's own glide), so its trajectory, not only its targets, is what it protects.
//
// The line is phrased (the user, 28 September 2026: "The maqam-based melodies seem to have a tendency to degrade into
// just going basically up and down a scale ... Usual well-formed melody rules - e.g., avoiding repeating apexes, etc;
// whatever you have stored - also apply in a maqam context"; and on another kit, "distinct phrasing or motifs"). It had
// walked up the ascending material and down the descending, a note a beat. Now:
// - Its phrases, of five to nine felt beats with a breath of one or two after each, follow rast's seyir as the maqam
//   contours give it (shared/melodic-contour.js MAQAM_CONTOURS): in the lower jins resting on rast; rising to rest on
//   nawa, the ghammaz; in the upper jins, awj going up, resting on nawa; and down through ajam to rast.
// - Each note is the cheapest of the degrees within a fifth by the rules of melodies stored there: proximity, reversal
//   after a leap, the mode's notes by direction, its path, one climax a phrase and not at its end, closure by step onto
//   the phrase's resting tone. Two more are asked for: a phrase's climax not the phrase before's, and no run of more
//   than four steps the same way. A little of its seeded source keeps two phrases from being the same.
// - A motif: the first phrase's opening four notes, as steps of the maqam's degrees, open later phrases, transposed to
//   where each begins and now and then turned upside down.
// - The phrase's last note is held into its breath.
//
// Under it two voices -- a drone on rast and a voice that moves -- are planned by the harmonic-systems generator from a
// companion package (an engineering fixture), with the melody as a protected voice (T09): each step's accompaniment is
// chosen around the melody's pitch as given, never the melody moved; it keeps clear of a semitone or a neutral second
// against it, and the moving voice gives way where the line reaches its degree. The accompaniment has no E or E-flat to
// offer: it adapts by what it holds. Each note says what it
// is into notes.jsonl: the line's degree, direction, ornament and profile status; the accompaniment's structure and role.
import {defineBot} from '../../framework/index.js';
import {VoiceLeadingBot} from '../lib/voice-leading-bot.js';
import {feltBeats} from '../../shared/meter-tactus.js';
import {voicesPayload} from '../../shared/sounding-voices.js';
import {rulePackage} from '../../shared/harmonic-systems/packages.js';
import {generate} from '../../shared/harmonic-systems/generator.js';
import {MAQAM_RAST_TEST_PROFILE} from '../../shared/harmonic-systems/package-fixtures.js';
import {strikeWith,languageOf} from '../lib/note-language.js';
import {unitRandom} from '../../shared/stochastic.js';
import {contourCost,maqamContour} from '../../shared/melodic-contour.js';
import {graceTime,readScoreTime} from '../../shared/score-time.js';
import {authoredFraction} from '../../shared/performers/rhythm-cell.js';

// ---- Choices ---------------------------------------------------------------------------------------------------
// The qarar (rast) in MIDI, the line's register, how long a grace is, how long a glide takes, and how it sounds.
export const MODALLINE=Object.freeze({qarar:60,melodyRange:Object.freeze([60,77]),grace:.07,glide:.09,melody:Object.freeze({family:'lead',velocity:.55,gain:.06}),
  accompaniment:Object.freeze({family:'bowed',velocity:.36,gain:.035}),phraseBeats:8});
const mod=(x,n)=>((x%n)+n)%n;
// The line's phrasing (ours): its lengths in felt beats and its breath after, the seyir's four phrases (the focus, its
// resting degree, the register it centres on), the motif's length and how often it opens a phrase, and the noise that
// keeps two phrases apart.
export const MODALLINE_PHRASES=Object.freeze({beats:Object.freeze([5,9]),breath:Object.freeze([1,2]),motif:4,restate:.7,invert:.3,noise:.6,
  // A solo line's own weights over the stored rules: its notes seldom repeated, its path held to more firmly, and each
  // phrase drawn to its register (per semitone beyond three from its centre).
  focus:.25,
  seyir:Object.freeze([Object.freeze({focus:'lower',rest:'rast',center:64}),Object.freeze({focus:'rising',rest:'nawa',center:66}),
    Object.freeze({focus:'upper',rest:'nawa',center:70}),Object.freeze({focus:'descent',rest:'rast',center:65})]),
  weights:Object.freeze({run:.8,runSteps:4,newClimax:1.2,repeat:1,arch:.3}),
  // The accompaniment's dyad for each phrase of the seyir (ours): rast with dukah under the lower jins, with jaharkah
  // as the line rises and as it comes down, with nawa under the upper jins; the generator's own choice where the line
  // rules it out. So the accompaniment moves with the phrases, not only where the line collides with it.
  structures:Object.freeze({lower:'rast-dukah',rising:'rast-jaharkah',upper:'rast-nawa',descent:'rast-jaharkah'})});
// Its ladder: the maqam's degrees in the line's range, a step a place; the seventh is awj going up and ajam going down.
const LADDER=['rast','dukah','sikah','jaharkah','nawa','husayni','seventh','rast','dukah','sikah','jaharkah'];
const ladderDegree=(place,direction)=>{const id=LADDER[place]==='seventh'?(direction==='descending'?'ajam':'awj'):LADDER[place];
  return {id,octave:place>=7?1:0,cents:degreeCents[id]+(place>=7?1200:0)}};
const degreeCents=Object.fromEntries(MAQAM_RAST_TEST_PROFILE.degrees.map(degree=>[degree.id,degree.interval.value]));
const collection=id=>MAQAM_RAST_TEST_PROFILE.collections.find(item=>item.id===id).degrees;

// The accompaniment's companion package: rast's degrees, a drone of rast and nawa and the dyads a moving voice may take
// over it, the melody protected and kept clear of a semitone or a neutral second. An engineering fixture.
export const MODAL_ACCOMPANIMENT=rulePackage({
  id:'modal-accompaniment-fixture',version:'1',provenance:{status:'engineering-fixture',notes:'An accompaniment for the rast declared test profile\'s line: a drone and one moving voice, the line protected. Not a practice of any tradition.'},
  scope:{description:'A drone on rast with a moving voice, around a protected line.'},
  period:{kind:'ratio',numerator:'2',denominator:'1'},referenceId:'qarar',
  degrees:MAQAM_RAST_TEST_PROFILE.degrees.map(degree=>({id:degree.id,interval:degree.interval})),
  structures:[
    {id:'rast-nawa',roles:[{role:'drone',degree:'rast',required:true},{role:'fifth',degree:'nawa',required:true}]},
    {id:'rast-jaharkah',roles:[{role:'drone',degree:'rast',required:true},{role:'fourth',degree:'jaharkah',required:true}]},
    {id:'rast-dukah',roles:[{role:'drone',degree:'rast',required:true},{role:'second',degree:'dukah',required:true}]},
  ],
  contexts:[{id:'drone',structures:['rast-nawa','rast-jaharkah','rast-dukah']}],start:['drone'],transitions:[{from:'drone',to:'drone'}],
  rules:[{id:'line-protected',type:'protect-voice',strength:'hard',voice:'melody'},
    {id:'no-semitone',type:'avoid-interval',strength:'hard',interval:{kind:'cents',value:100},toleranceCents:20},
    {id:'no-neutral-second',type:'avoid-interval',strength:'hard',interval:{kind:'cents',value:150},toleranceCents:20},
    // The moving voice gives way to the line: it never doubles the line's degree, so it moves when the line reaches it.
    {id:'mover-gives-way',type:'avoid-interval',strength:'hard',interval:{kind:'cents',value:0},toleranceCents:20,scope:{voices:['mover']}}],
});

export class ModallineClodbot extends VoiceLeadingBot {
  constructor(send,audio,settings={}){super(send,audio,{style:'modalline',...settings});this.line={index:0,last:null,rising:true,accompaniment:null}}
  rearticulates(){return false}
  attack(){}
  noteLanguage(note){return languageOf(this.pendingLanguage,note)}
  // A new phrase: its length and breath, its place in the seyir, and whether the motif opens it (and upside down).
  beginPhrase(){
    const {beats,breath,seyir,restate,invert}=MODALLINE_PHRASES,n=(this.line.phrases??0);this.line.phrases=n+1;
    const plan=seyir[n%seyir.length];
    this.line.phrase={n,...plan,beats:beats[0]+Math.floor(unitRandom()*(beats[1]-beats[0]+1)),breath:breath[0]+Math.floor(unitRandom()*(breath[1]-breath[0]+1)),
      at:0,start:null,high:null,history:[],motif:n>0&&this.line.motif&&unitRandom()<restate?{steps:unitRandom()<invert?this.line.motif.map(step=>-step):[...this.line.motif]}:null};
  }
  // The line's next degree, or null in a breath: the cheapest of the places within a fifth by the rules of melodies,
  // the mode's path and the phrase's own (shared/melodic-contour.js), or the motif's where it opens the phrase.
  nextDegree(clock){
    if(!this.line.phrase)this.beginPhrase();
    let phrase=this.line.phrase;
    if(phrase.at>=phrase.beats){
      if(phrase.at<phrase.beats+phrase.breath){phrase.at++;return null}
      this.line.apexes=[phrase.high,...(this.line.apexes??[])].slice(0,2);
      this.beginPhrase();phrase=this.line.phrase;
    }
    const mode=maqamContour('rast',mod(MODALLINE.qarar,12)),history=this.line.history??=[],last=history.at(-1)??null,place=this.line.place;
    const position=phrase.at/Math.max(1,phrase.beats-1),ending=phrase.at===phrase.beats-1;
    // (The path: the seyir's arch from the qarar in the lower phrases, up to the ghammaz in the rising one, down from the
    // upper rast in the descent, and in the upper jins an arch from where the phrase begins.)
    const context={history,center:phrase.center,span:12,mode:{...mode,path:{lower:'arch',rising:'ascending',upper:null,descent:'descending'}[phrase.focus],
      rests:[degreeCents[phrase.rest]/100]},weights:MODALLINE_PHRASES.weights,
      // (The phrase before's apex is not this one's to reach again, unless it is this phrase's own resting tone: a rise
      // to rest on nawa is not a repeated climax.)
      phrase:{position,start:phrase.start,high:phrase.high,ending,strong:Boolean(clock.barStart),
        previousHigh:mod(Math.round((this.line.apexes?.[0]??NaN)*100)-MODALLINE.qarar*100-degreeCents[phrase.rest],1200)===0?undefined:this.line.apexes?.[0]}};
    const motifTarget=phrase.motif&&phrase.at>0&&phrase.at<phrase.motif.steps.length+1&&Number.isInteger(place)?place+phrase.motif.steps[phrase.at-1]:null;
    const options=[];
    for(let next=0;next<LADDER.length;next++){
      if(Number.isInteger(place)&&Math.abs(next-place)>4)continue;
      const direction=!Number.isInteger(place)||next>place?'ascending':next<place?'descending':this.line.direction??'ascending';
      const degree=ladderDegree(next,direction),pitch=MODALLINE.qarar+degree.cents/100;
      if(pitch<MODALLINE.melodyRange[0]-1e-9||pitch>MODALLINE.melodyRange[1]+1e-9)continue;
      // After awj the line goes on up, after ajam on down: the direction that chose them (rast's B half-flat rises to
      // the octave; going down it is B flat).
      if(last!==null&&(this.line.degree==='awj'&&!(pitch>last+.1)||this.line.degree==='ajam'&&!(pitch<last-.1)))continue;
      let cost=contourCost(pitch,context).cost+MODALLINE_PHRASES.focus*Math.max(0,Math.abs(pitch-phrase.center)-3);
      if(motifTarget!==null)cost+=next===motifTarget?-3:0;
      options.push({place:next,direction,degree,pitch,cost:cost+unitRandom()*MODALLINE_PHRASES.noise});
    }
    const chosen=options.reduce((best,option)=>option.cost<best.cost?option:best,options[0]);
    // A phrase ends where it arrives: a last note that is not its resting tone lengthens the phrase by a beat, twice at
    // most, so that it cadences rather than stops.
    let cadence=ending;
    if(ending&&chosen.degree.id!==phrase.rest&&(phrase.extended??0)<2){phrase.beats++;phrase.extended=(phrase.extended??0)+1;cadence=false}
    // And where it arrives early: past two-thirds of it, its resting tone reached by a step down ends it there.
    if(!cadence&&position>=2/3&&chosen.degree.id===phrase.rest&&last!==null&&chosen.pitch<last-.1&&last-chosen.pitch<=2.5){cadence=true;phrase.beats=phrase.at+1}
    // The first phrase's opening is the motif, as the ladder's steps it moves by (a repeated note is no step of it).
    if(phrase.n===0&&phrase.at<MODALLINE_PHRASES.motif&&Number.isInteger(place)&&chosen.place!==place)(this.line.motifSteps??=[]).push(chosen.place-place);
    if(phrase.n===0&&phrase.at===MODALLINE_PHRASES.motif-1&&this.line.motifSteps?.length>=2)this.line.motif=[...this.line.motifSteps];
    history.push(chosen.pitch);if(history.length>16)history.shift();
    this.line.place=chosen.place;this.line.direction=chosen.direction;this.line.degree=chosen.degree.id;
    phrase.start??=chosen.pitch;phrase.high=Math.max(phrase.high??-Infinity,chosen.pitch);phrase.at++;
    return {...chosen.degree,direction:chosen.direction,phrase:phrase.n,ending:cadence,breath:cadence?phrase.breath:0};
  }
  everyTick(clock){
    if(this.closing?.phase==='after'||!clock.meter)return;
    const beats=feltBeats(clock.meter,{secondsPerTick:this.secondsPerTick(clock)}),beat=beats.find(item=>item.start===clock.tickInBar);
    if(!beat)return;
    const spt=this.secondsPerTick(clock),degree=this.nextDegree(clock);
    if(!degree)return;
    // The phrase's last note is held into its breath (half of it), then silence until the next phrase.
    const seconds=Math.max(.15,beat.length*spt*(.96+(degree.ending?degree.breath*.5:0)));
    const pitch=MODALLINE.qarar+degree.cents/100,previous=this.line.last,long=clock.barStart||beat.length>beats[0].length;
    // Ornaments: a grace from the step above on a long note; a glide from the step below into sikah and awj.
    const glideInto=['sikah','awj'].includes(degree.id)&&previous!==null&&previous<pitch;
    const language={modal:{profile:MAQAM_RAST_TEST_PROFILE.id,status:MAQAM_RAST_TEST_PROFILE.provenance.status,degree:degree.id,direction:degree.direction,protected:true,
      phrase:degree.phrase,...(degree.ending?{cadence:true}:{})}};
    const written=this.lineInterval(clock,beat,degree);
    const strikes=[];
    if(long&&!glideInto){const above=MODALLINE.qarar+this.stepAbove(degree)/100;strikes.push({pitch:above,seconds:MODALLINE.grace,language:{modal:{...language.modal,ornament:'grace'}},offset:0,
      written:{scoreId:`${written.scoreId}:grace:0`,scoreTime:graceTime(clock.tick,{anchor:written.scoreId,order:0,type:'eighth'}),group:'ornaments'}})}
    strikes.push({pitch,seconds,language:{modal:{...language.modal,...(glideInto?{ornament:'glide'}:{})}},offset:strikes.length?MODALLINE.grace:0,glideFrom:glideInto?previous:null,written});
    strikeWith(this,strikes.map(({pitch,language})=>({pitch,language})),()=>{
      for(const strike of strikes)this.play(strike.pitch,strike.seconds,MODALLINE.melody,'lead',strike.offset,
        {...(strike.glideFrom!==null&&strike.glideFrom!==undefined?{glide:MODALLINE.glide,glideFrom:strike.glideFrom}:{glide:false}),line:'modal'},strike.written);
    });
    this.broadcast('voices',[voicesPayload({voice:`${this.instanceId??'modalline'}:line`,role:'line',pitches:[pitch],clock,style:'modalline'})]);
    this.line.last=pitch;
    this.accompany(clock,pitch,seconds,written);
  }
  lineInterval(clock,beat,note){
    const ticks=authoredFraction(beat.length).mul(authoredFraction(1).add(authoredFraction(note.ending?note.breath:0).div(2)));
    return this.writtenInterval(clock,ticks,{group:'melody',replace:true});
  }
  // Performance offsets include the grace's attack time on every output; their written relation is explicit.
  play(pitch,seconds,spec,profile,offset,expression,written){
    return this.playWritten(written,()=>{
      if(this.audio.mode==='midi'||this.audio.mode==='samples'||typeof this.audio.voice!=='function')return this.audio.pitched(pitch,seconds,spec.gain,'sawtooth',profile,spec.velocity,spec.family,expression,offset);
      return this.audio.voice(pitch,seconds,spec.gain,'sawtooth',offset,{instrument:spec.family,profile,velocity:spec.velocity,...expression});
    });
  }
  stepAbove(degree){
    const material=collection(degree.direction),order=material.map(id=>degreeCents[id]).sort((a,b)=>a-b);
    const within=mod(degree.cents,1200),next=order.find(cents=>cents>within+1e-6);
    return (next??1200)+1200*Math.floor(degree.cents/1200);
  }
  // Two voices under the protected line, planned by the core around it.
  accompany(clock,pitch,seconds,melody){
    const voices=[{id:'drone',range:[4300,5500]},{id:'mover',range:[5000,6400]},{id:'melody',range:[pitch*100-1,pitch*100+1]}];
    const previous=this.line.accompaniment,wanted=MODALLINE_PHRASES.structures[this.line.phrase?.focus]??null;
    const plan=structure=>generate(MODAL_ACCOMPANIMENT,{start:{context:'drone',...(structure?{structure}:{}),...(previous?{after:previous}:{})},steps:0,voices,tonicCents:MODALLINE.qarar*100-1200,
      protectedPitches:{melody:[pitch*100]}});
    let outcome=plan(wanted);
    if(outcome.status!=='validated'&&wanted)outcome=plan(null);
    if(outcome.status!=='validated'){this.decide({tick:clock.tick,accompaniment:outcome.status,melody:pitch});return}
    const step=outcome.plan[0],notes=step.voicing.filter(note=>note.voice!=='melody'&&Number.isFinite(note.cents));
    this.line.accompaniment=Object.fromEntries(notes.map(note=>[note.voice,note.cents]));
    const written=this.writtenInterval(clock,readScoreTime(melody).duration,{group:'accompaniment',replace:true});
    // (Each note says its voice as well as its role: the generator gives the structure's roles to the voices as they fit,
    // so the voice named drone may hold the fifth while the mover takes rast.)
    strikeWith(this,notes.map(note=>({pitch:note.cents/100,language:{accompaniment:{structure:step.structure,role:note.role,voice:note.voice,around:+pitch.toFixed(4)}}})),()=>{
      for(const note of notes)this.play(note.cents/100,seconds,MODALLINE.accompaniment,'pad',0,{glide:false,line:note.voice},written);
    });
  }
}

export const modallineClodbot=defineBot(
  {
    id:'modalline_clodbot',name:'modalline_clodbot',status:'native',source:'clodbot',
    category:'melody',midiChannel:9,performanceType:'polyphonic',outputModes:['synth','midi'],
    pitchContract:'floating-mpe',nativeTuning:true,
    description:'A protected modal line with ornaments (the rast declared test profile: sikah at 350 cents, awj rising and ajam falling; graces and glides) and an accompaniment the harmonic-systems generator plans around it, a drone and a moving voice that never correct the line; a test profile, not maqam fidelity.',
  },
  (...args)=>new ModallineClodbot(...args),
);
