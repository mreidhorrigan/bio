// ornament_clodbot: a fork of mh_OrnamentBOT that spreads its plucks over the bar in the transport's own beats (the mathematical audit's B04,
// ../lib/quarter-tempo.js). The port reads the transport's tempo as quarter notes; in 7/8 its plucks fill the bar, where
// the port's took half the time, and in 3/2 it no longer takes twice. The port's code is untouched: scheduleBar is the port's
// own, given its clock with the tempo in quarter notes (it reads the tempo for nothing else). In a meter of quarters it
// plays exactly as mh_OrnamentBOT. Made from the class it forks, which agents.js holds, by a function (no import cycle).
// As registered, its calls wait for the pulse they fall in (../lib/pulse-release.js; the audit's T01), so a tempo curve
// keeps its notes on the beat; its class here is the fork without that (the twin tests' subject).
import {defineBot} from '../../framework/index.js';
import {quarterNoteClock} from '../lib/quarter-tempo.js';
import {releasedInPulse} from '../lib/pulse-release.js';

export function ornamentClodbotClass(OrnamentBot){
  return class OrnamentClodbot extends OrnamentBot {
    scheduleBar(clock){return super.scheduleBar(quarterNoteClock(clock))}
  };
}
export function defineOrnamentClodbot(OrnamentBot){
  const OrnamentClodbot=releasedInPulse(ornamentClodbotClass(OrnamentBot));
  return defineBot({
      id:'ornament_clodbot',name:'ornament_clodbot',status:'native',source:'clodbot',forkOf:'ornament',category:'melody',midiChannel:7,outputModes:['synth', 'midi'],pitchContract:'floating-mpe',
      description:"A fork of mh_OrnamentBOT that spreads its plucks over the bar in the transport's own beats (the mathematical audit's B04): in 7/8 its plucks fill the bar, where the port's took half the time, and in 3/2 it no longer takes twice. At a steady tempo in a meter of quarters it plays exactly as mh_OrnamentBOT. Under a tempo curve its notes stay on the beat: each waits for the pulse it falls in and is placed at that pulse's tempo (T01).",
    },(...args)=>new OrnamentClodbot(...args));
}
