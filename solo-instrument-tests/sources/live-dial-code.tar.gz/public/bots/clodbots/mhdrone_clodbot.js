// mhdrone_clodbot: a fork of mh_DroneBOT whose drone and its break last as long as each says (the mathematical audit's
// B07; the user, 27 September 2026: "fix in forked form"). Made from the class it forks, which agents.js holds, by a
// function, so this file imports nothing from agents.js; mh_DroneBOT itself is unchanged.
//
// mh_DroneBOT draws a duration for its playing state and draws again for the drone it sounds, so the two disagree: a
// state of 2 s with a drone of 5 s breaks while its drone still sounds. Here:
//   - **one draw** gives a state its length and, when it plays, its drone's (the port's own law: activity-dependent,
//     randomized by its percent range); the later random draws shift by the one it no longer makes;
//   - **the length is elapsed seconds,** as the drone's is: the state ends when that many seconds have passed, however
//     the tempo moves meanwhile, not at a tick deadline fixed at its start's tempo;
//   - **its listening is smoothed per second, not per beat:** mh_DroneBOT moves its density and activity a fifth of the
//     way to what it hears on each beat, so it answers faster at faster tempos. The fork moves by
//     1 - exp(-seconds / tau), tau chosen so that at MHDRONE_CLODBOT.referenceBpm (its default tempo) it answers as the
//     port does, and at every other tempo in the same time.
// Its notes, octaves, tremolo and density are the port's.
import {defineBot} from '../../framework/index.js';
import {secondsPerTick} from '../../shared/meter-tactus.js';
import {writtenSeconds} from '../lib/written.js';

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const MHDRONE_CLODBOT=Object.freeze({
  // The tempo the port's per-beat smoothing is matched at (bpm): the port's default tempo.
  referenceBpm:108,
});

// The per-second time constant that gives the port's per-beat smoothing amount at the reference tempo (s).
export function smoothingSeconds(perBeat,{choices=MHDRONE_CLODBOT}={}){
  if(!(perBeat>0&&perBeat<1))throw new RangeError('a per-beat smoothing amount between 0 and 1');
  return -(60/choices.referenceBpm)/Math.log1p(-perBeat);
}

export function mhdroneClodbotClass(MhDroneBot){
  class MhDroneClodbot extends MhDroneBot {
    constructor(send,audio,settings={}){
      super(send,audio,settings);
      this.stateSeconds=null;this.elapsedSeconds=0;
      this.smoothingTau=smoothingSeconds(this.config.controlSmoothing);
    }
    // Move density and activity toward what the bot heard, by the share `seconds` of elapsed time earns.
    smoothOver(seconds){
      const amount=-Math.expm1(-seconds/this.smoothingTau);
      this.density+=(this.targetDensity-this.density)*amount;
      this.activity+=(this.targetActivity-this.activity)*amount;
    }
    onTick(tick,clock){
      const seconds=secondsPerTick(clock);
      this.smoothOver(seconds);
      if(this.stateSeconds===null||this.elapsedSeconds>=this.stateSeconds-1e-9){
        if(this.stateSeconds!==null)this.playing=!this.playing;
        // One draw: this state's length, and the drone's when it plays.
        this.stateSeconds=this.durationSeconds(this.playing);this.elapsedSeconds=0;this.stateStarted=false;
      }
      if(this.playing&&!this.stateStarted){
        this.stateStarted=true;
        // (Written for its state's length, as it composes it in seconds: lib/written.js.)
        writtenSeconds(this.audio,clock,this.stateSeconds,()=>this.audio.wubDrone(this.note(),this.stateSeconds,this.tremolo(),this.density));
      }
      this.elapsedSeconds+=seconds;
    }
  }
  return MhDroneClodbot;
}
export function defineMhdroneClodbot(MhDroneBot){
  const MhDroneClodbot=mhdroneClodbotClass(MhDroneBot);
  return defineBot({
      id:'mhdrone_clodbot',name:'mhdrone_clodbot',status:'native',source:'clodbot',forkOf:'mhDrone',
      category:'keys-pads',midiChannel:6,outputModes:['synth','midi'],pitchContract:'floating-mpe',
      description:
        'A fork of mh_DroneBOT whose drone and its break last as long as each says: one duration for a state and its sound, counted in elapsed seconds through tempo changes, and its listening smoothed per second rather than per beat.',
    },(...args)=>new MhDroneClodbot(...args));
}
