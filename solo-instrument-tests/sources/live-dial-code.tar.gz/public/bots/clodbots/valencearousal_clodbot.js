// valencearousal_clodbot: a fork of ae_ValenceArousalBOT whose arousal and valence approach their targets in musical
// time, however finely the meter's grid is counted (the mathematical audit's B07; the user, 27 September 2026: "fix in
// forked form"). Made from the class it forks, which agents.js holds, by a function, so this file imports nothing from
// agents.js; ae_ValenceArousalBOT itself is unchanged.
//
// The port moves arousal and valence a fixed share of the way to their targets on every tick, so how fast the form's
// mood follows its targets depends on how many ticks a bar is counted in: twice as fast in 4/4 counted in
// thirty-seconds as in sixteenths, half as fast in 7/8 counted in eighths. Here the step is 1 - exp(-w / tau), w the
// tick's length in whole notes (the bar's numerator / denominator over its ticks) and tau chosen so that on the port's
// own grid (a 4/4 bar of VALENCEAROUSAL_CLODBOT.referenceTicks ticks) it moves exactly as the port does. So the mood
// follows in musical time, a phrase at any tempo shaped as the port shapes it, at any grid. Its targets, phrase
// lengths, meters and broadcasts are the port's.
import {defineBot} from '../../framework/index.js';
import {bandMeter} from '../../shared/opening-time.js';

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const VALENCEAROUSAL_CLODBOT=Object.freeze({
  // The grid the port's per-tick smoothing is matched on: ticks in a 4/4 bar (its default clock's).
  referenceTicks:16,
});

// A tick's length in whole notes: the bar's notated length over the ticks it is counted in.
export function wholeNotesPerTick(meter={}){
  const numerator=Number(meter.numerator)||bandMeter().numerator,denominator=Number(meter.denominator)||bandMeter().denominator,ticks=Number(meter.pulsesPerBar)||16;
  return numerator/denominator/ticks;
}
// The time constant, in whole notes, that gives the port's per-tick amount on its reference grid.
export function smoothingWholeNotes(perTick,{choices=VALENCEAROUSAL_CLODBOT}={}){
  if(!(perTick>0&&perTick<1))throw new RangeError('a per-tick smoothing amount between 0 and 1');
  return -(1/choices.referenceTicks)/Math.log1p(-perTick);
}

export function valencearousalClodbotClass(ValenceArousalBot){
  class ValenceArousalClodbot extends ValenceArousalBot {
    constructor(send,audio,settings={}){
      super(send,audio,settings);
      this.smoothingTau=smoothingWholeNotes(this.config.smoothFactor);
    }
    onTick(tick,clock){
      if(clock.phraseStart&&clock.phrase!==this.lastPhrase){this.lastPhrase=clock.phrase;this.beginPhrase()}
      const amount=-Math.expm1(-wholeNotesPerTick(clock.meter)/this.smoothingTau);
      this.arousal+=(this.arousalTarget-this.arousal)*amount;
      this.valence+=(this.valenceTarget-this.valence)*amount;
      const bars=clock.meter?.phraseBars||this.phraseBars,pulses=clock.meter?.pulsesPerBar||bandMeter().pulsesPerBar,
        progress=((clock.bar%bars)+(clock.tickInBar||0)/pulses)/bars;
      this.broadcast('progress',[Math.max(0,Math.min(1,progress))]);
      this.broadcast('arousal',[this.arousal]);
      this.broadcast('valence',[this.valence]);
    }
  }
  return ValenceArousalClodbot;
}
export function defineValencearousalClodbot(ValenceArousalBot){
  const ValenceArousalClodbot=valencearousalClodbotClass(ValenceArousalBot);
  return defineBot({
      id:'valencearousal_clodbot',name:'valencearousal_clodbot',status:'native',source:'clodbot',forkOf:'valenceArousal',
      category:'utility',outputModes:[],pitchContract:'none',
      description:
        'A fork of ae_ValenceArousalBOT whose arousal and valence approach their targets in musical time at any grid (the port moves a fixed share per tick, so a finer grid hurries it); its targets, phrases, meters and broadcasts are the port\'s.',
    },(...args)=>new ValenceArousalClodbot(...args));
}
