// profile_clodbot: the person the band plays with, as the band can plan on them (Musebots 3.0, docs/MUSEBOTS_3.md; the owner,
// 30 September 2026: "a profile_clodbot representing a human player or ensemble"; "I think of them in Musebots 3.0 as
// profile_clodbot"; "the profiles currently including listening capabilities for beat tracking, et cetera").
//
// A fork of ListenerBot: it hears one input as the listener does, and does everything the listener does with it (its
// beat tracking, which the conductor's tempo following reads; its harmony following, which leads the band's harmony;
// its onsets and notes; its answers for the performer as the ending nears). And it says what it hears of the person as
// one profile, on /broadcast/profile, at each of the meter's felt groups (a second or two apart in any meter, where a
// long bar would say it too seldom) and whenever they start or stop, for the conductors that plan
// contingencies on it (plex_clodbot) and the managers that make room for it:
//   present      heard and playing (a silence longer than they rest, the listener's own test, is a stop)
//   stopped      heard, and not playing now (the listener's judgement, meant for the ending: a silence of at least half a
//                phrase, so slow in a long bar)
//   silentSeconds how long since their last attack (null before any): the quick word, a conductor's contingencies weigh
//                it against their own bar
//   activity     how busy they are, 0 to 1: their attacks a beat over the last PROFILE.windowBeats beats, against
//                PROFILE.busy attacks a beat (ours)
//   tempo        their beat as tracked: its period, its BPM, and the BPM in the band's own beat (their beat taken the
//                octave that comes nearest the band's: a player counting in halves or doubles is at the same tempo)
//   harmony      whether their harmony leads the band's, and the chord heard
//   coordination how closely they ask to be followed ('tight', 'loose', 'released' for a cadenza), and whether they lead
//   meter        their bar as heard, where the listening hears downbeats (the learned tracker's): how many of the
//                band's beats it lasts (`beats`; their beat taken the octave the tempo takes), their beats a bar
//                (`theirs`), and the band's tick of their last downbeat (`downbeatTick`, on the band's nearest beat, placed
//                as the listener places an attack: listener-bot.js sendOnsets) -- for a conductor following them to
//                count the band's bars as theirs (plex_clodbot followHeardMeter)
//   ahead        with foresight only (a render that knows their recording before it sounds, render/foresight.js): what
//                they will play from now, PROFILE.aheadSeconds of it -- their attacks and where their sound ends, in
//                the render's seconds -- so that a conductor choosing a section's contingencies reads the person over
//                that section rather than as they were a moment ago (shared/conducting/contingencies.js foreseen)
// A listening bot stands for a person (CLAUDE.md): its profile is the person's word, and a conductor plans for it.
import {defineBot} from '../../framework/index.js';
import {ListenerBot} from '../listener-bot.js';
import {secondsPerTick} from '../../shared/meter-tactus.js';
import {bandMeter} from '../../shared/opening-time.js';

export const PROFILE_ADDRESS='/broadcast/profile';
// Ours: the window activity is heard over, and the attacks a beat heard as fully busy (sixteenths in any beat); with
// foresight, how far ahead a profile says what is coming (some minutes: past it, what a section holds is read as far as
// it reaches); and how near an octave of their beat the band's must be for their bar to be said in the band's beats (a
// few just-noticeable differences of tempo).
export const PROFILE=Object.freeze({windowBeats:8,busy:4,aheadSeconds:150,locked:.04});
const round=value=>Math.round(value*1000)/1000;

// A person's profile from what a listener holds of them: state (ListenerBot.performerState), attacks (capture seconds),
// now (capture seconds), beat (the tracked forecast: periodSeconds), the band's clock, the harmony it follows (label or
// null), what they said of following, and with foresight what is to come (`foreseen`: the input's foresight, at `when`,
// render seconds). -> the profile (plain values).
export function performerProfile({voice,listening=null,state={},attacks=[],now=null,beat=null,clock={},harmony=null,leadsHarmony=false,coordination=null,leading=null,foreseen=null,when=null,delay=0}){
  const beatSeconds=secondsPerTick(clock)*(Number(clock.meter?.subdivision)||bandMeter().subdivision),heard=Boolean(state.heard);
  const window=PROFILE.windowBeats*beatSeconds,recent=Number.isFinite(now)?attacks.filter(at=>at>now-window&&at<=now).length:0;
  const pulse=Number(beat?.periodSeconds);
  let tempo=null,meter=null;
  if(pulse>0&&beatSeconds>0){const k=2**Math.round(Math.log2(beatSeconds/pulse));tempo={pulseSeconds:round(pulse),bpm:round(60/pulse),beatsBpm:round(60/(pulse*k))};
    // (Their bar in the band's beats: a whole number of them, or none said -- nor while the band's beat is not one of theirs
    // at some octave, within PROFILE.locked: counted against a beat between octaves, their bar flipped between two lengths.)
    const theirs=Number(beat?.beatsPerBar),down=Number(beat?.downbeatAt),beats=theirs/k,sub=Number(clock.meter?.subdivision)||0,locked=Math.abs(beatSeconds/(pulse*k)-1)<=PROFILE.locked;
    if(locked&&Number.isInteger(theirs)&&theirs>0&&Number.isInteger(beats)&&beats>0&&sub>0&&Number.isFinite(down)&&Number.isFinite(now)&&Number.isFinite(clock.tick)){
      const tick=clock.tick-(now+(Number(delay)||0)-down)/(beatSeconds/sub);meter={beats,theirs,downbeatTick:Math.round(tick/sub)*sub}}}
  const last=attacks.filter(at=>at<=now).at(-1),silentSeconds=heard&&Number.isFinite(now)&&Number.isFinite(last)?round(now-last):null;
  return {voice,role:'performer',listening,bar:Number.isInteger(clock.bar)?clock.bar:null,heard,present:heard&&Boolean(state.playing),stopped:heard&&Boolean(state.stopped),silentSeconds,
    activity:heard?round(Math.min(1,recent/Math.max(1,PROFILE.windowBeats)/PROFILE.busy)):0,tempo,
    harmony:{leads:Boolean(leadsHarmony&&harmony),label:harmony??null},coordination:coordination??null,leading:leading??null,
    ...(meter?{meter}:{}),...(foreseen&&Number.isFinite(when)?{ahead:aheadOf(foreseen,when)}:{})};
}
// What a take known ahead holds from `when` (render seconds) for PROFILE.aheadSeconds: {at, through, attacks, end, busy}.
export function aheadOf({attacks=[],audibleEnd=null},when){
  const through=round(when+PROFILE.aheadSeconds);
  return {at:round(when),through,attacks:attacks.filter(at=>at>=when&&at<through),end:Number.isFinite(audibleEnd)?round(audibleEnd):null,busy:PROFILE.busy};
}

export class ProfileClodbot extends ListenerBot{
  onTick(tick,clock){
    super.onTick(tick,clock);
    if(!clock?.meter)return;
    const profile=this.profile(clock),change=this.lastProfile&&this.lastProfile.present!==profile.present;
    if(!clock.groupStart&&!clock.barStart&&!change)return;
    this.lastProfile=profile;
    this.send(PROFILE_ADDRESS,[profile]);
  }
  profile(clock){
    const current=this.harmonyFollower?.current,label=typeof current==='string'?current:current?.label??null;
    return performerProfile({voice:this.instanceId??'profile_clodbot',listening:this.state,state:this.performerState(clock),attacks:this.attacks,
      now:this.capture?.captureNow?.()??null,beat:this.latestBeat,clock,harmony:label,leadsHarmony:Boolean(this.harmonyFollower),
      coordination:this.capture?this.coordination??null:null,leading:this.capture?this.leading??null:null,
      foreseen:this.foresightInput?.foresight?.()??null,when:this.inputs?.now?.()??null,delay:this.inputs?.outputDelaySeconds??this.audio?.clock?.lookahead??.25});
  }
}

export const profileClodbot=defineBot({id:'profile_clodbot',name:'profile_clodbot',status:'native',source:'clodbot',category:'utility',
  outputModes:[],pitchContract:'none',roles:Object.freeze(['profile']),
  description:'A profile of the person the band plays with: a fork of ListenerBot that hears one input as the listener does '
    +'(its beat tracking, followed by the conductor; its harmony, leading the band; its onsets and notes; its answers for the '
    +'performer near the ending) and says what it hears of them as one profile at each felt group and whenever they start or stop: '
    +'whether they are playing or have stopped, how busy they are, their tempo in the band\'s own beat, whether their harmony '
    +'leads and which chord, and how closely they ask to be followed. Conductors plan their contingencies on it.',
  visualizers:[{id:'input-estimates',name:'Input estimates',module:'./input-estimates.js'}],
  planningCapabilities:{rhythm:false,harmony:false,form:false}},(send,audio,options)=>new ProfileClodbot(send,audio,options));
