// timpani_clodbot: a timpanist, an instrument clodbot (research/family-atlas.md F31, orchestral and kit membranes: the
// timpani; research/MUSEBOTS_WORLD_INSTRUMENTS_CONSTRAINTS_RESEARCH_AND_IMPLEMENTATION_REPORT.md). New, not a fork. Taken
// by 2a at c2's word, 29 September (SESSIONS.md 10:32).
//
// Its harmony is the band's, as jazzvoicing_clodbot reads it; the instrument clodbots' principles are its own
// (instrument-performer.js): its strokes on the meter's groups, comp and figure as one continuum, a solo's course to a
// climax, the band's attention, a last note on the final downbeat (Closure). What a timpanist adds:
// - **Its drums tuned to the harmony by their pedals, in time.** At a change it wants the chord's root and its fifth
//   (the timpani's tonic and dominant), each on a drum whose range holds it (shared/performers/timpani.js): a drum at the
//   pitch already keeps it; another is retuned by a free foot once its last note has ended, and is struck only once its
//   pedal has settled. A stroke asked of a drum still being retuned is left out, and counted. So its pitches are the
//   band's own, microtones included, wherever a drum reaches them.
// - **Two sticks, by construction**: each stroke by a stick that has recovered and whose hand reaches the drum in time
//   (stickReaches), the hands by turns; on a change's downbeat, and on the last note, a double stop, a stick each; a note
//   held longer than its drum rings is rolled, both sticks on it to its end.
// - **Its figure**: tonic and dominant by turns on the felt beats' subdivisions where the fillness asks for more than the
//   comp, drawn once as a cycle and played bar after bar, busier toward a solo's climax.
// - **Glissandi, by the ensemble's character**: at a change, as much as the character is spacious more than it is spiky,
//   the old root's drum is struck where it stands and slides to the new root as a foot moves its pedal (where that drum
//   reaches both), rather than muffled and retuned.
// - **Its sound**: the VSCO 2 Community Edition's timpani (CC0; scripts/download-timpani-samples.mjs), five drums at three
//   dynamics and their recorded rolls, a velocity choosing its layer; its own struck membrane (the tom family); or MIDI.
import {defineBot} from '../../framework/index.js';
import {withScoreTime,shiftScoreTime,scoreTimeFields} from '../../shared/score-time.js';
import {dividedBeats} from '../../shared/performers/rhythm-cell.js';
import {JazzVoicingClodbot} from './jazzvoicing_clodbot.js';
import {PerformedTiming} from '../lib/modules/performed-timing.js';
import {HearsAttention} from '../lib/modules/attention.js';
import {InSection} from '../lib/modules/section-member.js';
import {InstrumentPerformer} from '../lib/modules/instrument-performer.js';
import {TIMPANI,timpaniSet,drumsFor,retuneSeconds,ringOf,stickReaches} from '../../shared/performers/timpani.js';
import {secondsPerTick} from '../../shared/meter-tactus.js';
import {blendLevel,metricalWeight,rankThresholds} from '../../shared/performers/figure-blend.js';
import {modulo} from '../lib/pitch-helpers.js';

// Its recordings: the VSCO 2 Community Edition's (scripts/download-timpani-samples.mjs; c2's suggestion).
export const TIMPANI_BANK='vscoTimpani';
export const TIMPANI_CLODBOT=Object.freeze({
  // Its built-in voice's gain: the struck membrane (the tom family) at the mallet player's level, the median bot voice's.
  voiceGain:.05,
  // The figure's strokes a felt beat, up to twice as many at a solo's climax (ours).
  perBeat:2,
  // Levels (velocity): the figure's, the figure's at a solo's peak (ours).
  run:.5,runTop:.9,
  // Where its root sits: the octave nearest this pitch (A2 to B2, the middle of the common set; ours).
  centre:46,
  // How long a stroke is let ring before the player muffles it (felt beats, within its drum's ring; ours), so a drum is
  // free to be retuned soon after.
  ringBeats:2,
  // A position this heavy or heavier (figure-blend.js metricalWeight) takes the root in the figure (ours).
  strong:.5,
  // A solo this far toward its climax (soloArc) rolls its strong beats (ours).
  rollAt:.75,
  // Placing a pitch: each semitone from where it belongs weighs as this many seconds more to wait for its drum (ours).
  registerSeconds:.02,
  // A glissando into a change's root: the old root's drum struck where it stands and slid to the new root as its pedal
  // moves, over this many felt beats at least (or the pedal's travel, if longer), as much as the ensemble's character is
  // spacious more than it is spiky (space less attack, 0 to 1; none where no character is heard; ours).
  glideBeats:.5,
});

export class TimpaniClodbot extends InstrumentPerformer(JazzVoicingClodbot,{name:'timpani_clodbot',kinds:['comp','run']}) {
  constructor(send,audio,settings={}){
    super(send,audio,settings);
    const drums=settings?.drums??'four';if(drums!=='four'&&drums!=='five')throw new RangeError('settings.drums is four or five');
    this.set=timpaniSet({drums});
    // Each drum's pitch, when it can be struck (its pedal settled) and when its last note ends; each foot's free time;
    // each stick's place, when it left and when it strikes again, and whose turn it is (s of its own time).
    this.drumState=Object.fromEntries(this.set.map(drum=>[drum.id,{pitch:null,ready:-Infinity,end:-Infinity}]));
    this.feet={LF:-Infinity,RF:-Infinity};this.sticks={LH:null,RH:null,turn:'RH'};
    this.bars=[];this.figure=null;this.runPlan=null;this.voiced=null;this.struck=[];this.retunes=[];this.leftOut={untuned:0,retuning:0,sticks:0};
    // On samples, its recordings (the bank's one preset), where another was loaded for it; a render waits for them.
    if(this.audio?.mode==='samples'&&typeof this.audio.loadSampleBank==='function'&&this.audio.samplePreset!=='timpani')
      this.loading=this.audio.loadSampleBank(TIMPANI_BANK,{preset:'timpani'}).catch(error=>this.decide({samples:{preset:'timpani',failed:String(error?.message??error)}}));
  }
  // Its time now (s).
  now(clock){return this.elapsedSeconds?.(clock)??(Number(clock?.tick)||0)*secondsPerTick(clock)}
  // The share of its changes it glides into: as much as the character is spacious more than it is spiky.
  glideShare(){const character=this.character;return character?Math.max(0,Math.min(1,(character.space??.5)-(character.attack??.5))):0}
  // When a drum could be struck at `pitch`: now where it stands at it already; else once its last note has ended and a
  // foot is free, in its pedal's time (s of its own time).
  readyFor(drum,pitch,at){
    const s=this.drumState[drum.id],seconds=retuneSeconds(s.pitch,pitch);
    return seconds>0?Math.max(at,s.end,s.ready,Math.min(this.feet.LF,this.feet.RF))+seconds:Math.max(at,s.ready);
  }
  // A chord's root and fifth placed on two drums together: of the octaves and drums that reach them, the pair whose drums
  // are ready soonest (the later of the two), nearest where each belongs between equals (the root the centre, the fifth
  // a fourth under the root: the dominant below the tonic); the root alone where no second drum reaches the fifth.
  // -> {root: {pitch, drum}, fifth: {pitch, drum} | null} | null (no drum reaches the root).
  placeChord(rootPc,fifthPc,at){
    const options=pc=>{const out=[];if(pc===null||pc===undefined)return out;
      for(let octave=2;octave<=5;octave++){const pitch=12*octave+modulo(pc,12);for(const drum of drumsFor(this.set,pitch))out.push({pitch,drum,ready:this.readyFor(drum,pitch,at)})}
      return out};
    const roots=options(rootPc),fifths=options(fifthPc),weigh=TIMPANI_CLODBOT.registerSeconds;let best=null;
    for(const root of roots){
      const own=weigh*Math.abs(root.pitch-TIMPANI_CLODBOT.centre),pairs=fifths.filter(fifth=>fifth.drum.id!==root.drum.id);
      for(const fifth of pairs.length?pairs:[null]){
        const score=Math.max(root.ready,fifth?.ready??-Infinity)+own+(fifth?weigh*Math.abs(fifth.pitch-(root.pitch-5)):0)+(fifth?0:1e3);
        if(!best||score<best.score-1e-9)best={score,root,fifth};
      }
    }
    return best&&{root:{pitch:best.root.pitch,drum:best.root.drum},fifth:best.fifth&&{pitch:best.fifth.pitch,drum:best.fifth.drum}};
  }
  // A fifth placed alone beside a root on a drum of its own (not `except`): the octave and drum ready soonest, nearest a
  // fourth under the root between equals. -> {pitch, drum} | null.
  placeFifth(pc,root,at,except){
    if(pc===null||pc===undefined)return null;let best=null;
    for(let octave=2;octave<=5;octave++){const pitch=12*octave+modulo(pc,12);for(const drum of drumsFor(this.set,pitch)){
      if(drum.id===except)continue;const score=this.readyFor(drum,pitch,at)+TIMPANI_CLODBOT.registerSeconds*Math.abs(pitch-(root-5));
      if(!best||score<best.score-1e-9)best={score,pitch,drum};
    }}
    return best&&{pitch:best.pitch,drum:best.drum};
  }
  // Each placed pitch's drum tuned to it: where it stands at it already, kept; else retuned by the foot free first, once
  // the drum's last note has ended, struck only once its pedal has settled.
  tune(placed,at){
    for(const {pitch,drum} of placed){
      const s=this.drumState[drum.id],seconds=retuneSeconds(s.pitch,pitch);
      if(seconds>0){
        const foot=this.feet.LF<=this.feet.RF?'LF':'RF',start=Math.max(at,s.end,s.ready,this.feet[foot]),ready=start+seconds;
        this.feet[foot]=ready;this.drumState[drum.id]={...s,pitch,ready};
        this.retunes.push({drum:drum.id,foot,from:s.pitch,to:pitch,start:+start.toFixed(3),end:+ready.toFixed(3)});if(this.retunes.length>64)this.retunes.shift();
      }else this.drumState[drum.id]={...s,pitch};
    }
  }
  // The drum tuned to a pitch now, if any.
  drumAt(pitch){
    const voiced=this.voiced?.drums?.[pitch],at=drum=>Math.abs((this.drumState[drum.id].pitch??-99)-pitch)<=TIMPANI.tolerance;
    return this.set.find(drum=>drum.id===voiced&&at(drum))??this.set.find(at)??null;
  }
  // A chord on a change: its root and fifth placed on the drums and the drums tuned for them; struck on the change as a
  // double stop, and its root again as it is between changes, rolled where it outlasts the drum's ring.
  attack(clock,{change}){
    const chord=this.chord;if(!chord)return;let glide=null;
    const spt=this.secondsPerTick(clock),beat=this.beatTicks(clock),offbeat=clock.tickInBar%beat!==0,final=this.closing?.phase==='final',at=this.now(clock);
    if(change||!this.voiced){
      // (Its two drums' tones from the chord's readings (chord-readings.js), each in the object's own tuning: a reading's
      // root and fifth -- where it holds no fifth, the next of its tones -- the one dearest to its taste its drums can be
      // tuned to.)
      const before=this.voiced;let placed=null,read=null;
      for(const reading of [...this.readingsOf(clock)].sort((a,b)=>a.cost-b.cost)){
        const root=reading.roles.root??reading.pcs[0],fifth=reading.roles.fifth??reading.pcs.find(pc=>Math.abs(modulo(pc-root+6,12)-6)>.2)??null;
        if(root===null||root===undefined)continue;placed=this.placeChord(root,fifth,at);if(placed){read={id:reading.id,root,fifth};break}}
      if(!placed){this.decide({tick:clock.tick,noDrum:chord.root});return}
      // A glissando into it, as much as the character asks: of the last chord's two drums, where they stand and ready,
      // the one with the shortest slide into an octave of the new root it reaches (the old root's, between equals), a
      // foot free for its pedal; the fifth then on another drum.
      glide=null;
      if(before&&Math.min(this.feet.LF,this.feet.RF)<=at+1e-9&&this.random(`glide:${clock.bar}:${clock.tickInBar??0}`)()<this.glideShare()){
        let best=null;
        for(const from of [before.root,before.fifth].filter(pitch=>pitch!==null&&pitch!==undefined)){
          const drum=this.drumAt(from);if(!drum||this.drumState[drum.id].ready>at+1e-9)continue;
          for(let octave=2;octave<=5;octave++){
            const to=12*octave+modulo(read.root,12),size=Math.abs(to-from);
            if(size<=TIMPANI.tolerance||!drumsFor([drum],to).length)continue;
            if(!best||size<best.size-1e-9||Math.abs(size-best.size)<=1e-9&&from===before.root)best={from,to,drum,size};
          }
        }
        if(best){
          glide={from:best.from,seconds:Math.max(TIMPANI.pedal.perSemitone*best.size,TIMPANI_CLODBOT.glideBeats*beat*spt)};
          placed={root:{pitch:best.to,drum:best.drum},fifth:this.placeFifth(read.fifth,best.to,at,best.drum.id)};
        }
      }
      const both=[placed.root,placed.fifth].filter(Boolean);this.tune(glide?both.filter(each=>each!==placed.root):both,at);
      this.voiced={root:placed.root.pitch,fifth:placed.fifth?.pitch??null,pitches:both.map(each=>each.pitch),drums:Object.fromEntries(both.map(each=>[each.pitch,each.drum.id]))};this.voicing=this.voiced.pitches;
      this.decide({tick:clock.tick,change:true,chord:`${chord.root}:${chord.quality}`,drums:Object.fromEntries(both.map(each=>[each.drum.id,each.pitch]))});
    }
    // Rolled where a timpanist rolls: the last note, to the end, and a strong beat toward a solo's climax, to the next
    // felt beat; else let ring a felt beat or two and muffled.
    const climax=!offbeat&&(this.soloIntensity(clock)??0)>=TIMPANI_CLODBOT.rollAt,rolled=final||climax;
    const ring=(climax?beat*.95:(offbeat?1:TIMPANI_CLODBOT.ringBeats)*beat)*spt;
    // Its pitches: on a change and the last note, the fifth and root at once; else the root on the downbeat and the fifth
    // and the root by turns on the bar's other strokes, as a timpani part moves between tonic and dominant.
    const tick=clock.tickInBar??0,hits=this.comp?.bar===clock.bar?this.comp.hits.filter(hit=>hit>0&&hit<=tick).length:0;
    const both=(change||final)&&this.voiced.fifth!==null,which=tick===0||this.voiced.fifth===null||hits%2===0?'root':'fifth';
    const pitches=both?[this.voiced.fifth,this.voiced.root]:[this.voiced[which]];
    this.sound(clock,pitches,ring,this.vl.velocity-(offbeat?.04:0),{rolled:rolled&&!glide,glides:glide?{[this.voiced.root]:glide}:null});
    // (A glide not played, its drum still where it stood: retuned for the new root instead.)
    const id=glide?this.voiced.drums[this.voiced.root]:null;
    if(id&&Math.abs((this.drumState[id].pitch??-99)-this.voiced.root)>TIMPANI.tolerance)this.tune([{pitch:this.voiced.root,drum:this.set.find(drum=>drum.id===id)}],at);
    this.announce(clock,pitches);
  }
  // Its drums struck now, at the level the fillness leaves the comp (compLevelAt): each by its stick (a double stop, a
  // stick each; a note that outlasts its drum's ring rolled, both sticks); a drum still retuning, or out of every stick's
  // reach, left out.
  sound(clock,pitches,seconds,velocity=this.vl.velocity,{rolled=false,glides=null}={}){
    const compLevel=this.compLevelAt(clock);if(!(compLevel>0))return;
    if((clock.tickInBar??0)===0)this.planFigure(clock);
    const at=this.now(clock),level=Math.max(0,Math.min(1,velocity*compLevel));
    const played=withScoreTime(this.audio,this.compInterval(clock),()=>this.strokes(pitches,at,seconds,level,0,{rolled,glides}));
    if(played.length){this.count(clock,'comp');this.struck.push({bar:clock.bar,tick:clock.tickInBar??0,pitches:played.map(each=>each.pitch),rolled:played.some(each=>each.rolled)});if(this.struck.length>64)this.struck.shift()}
  }
  // Strokes at `time` (s of its own time), `offset` from now: each pitch on its drum where the drum is ready and a stick
  // reaches it, the stick whose turn it is first; rolled (both sticks, one drum) where asked or where the note outlasts
  // its drum's ring, and where it cannot be, struck once. -> [{pitch, drum, hand, rolled}].
  strokes(pitches,time,seconds,velocity,offset,{rolled=null,glides=null}={}){
    // (A pitch it glides into is struck on the drum where the glide begins.)
    const out=[],drums=pitches.map(pitch=>({pitch,drum:this.drumAt(glides?.[pitch]?.from??pitch),glide:glides?.[pitch]??null}));
    for(const entry of drums){
      if(!entry.drum){this.leftOut.untuned++;continue}
      if(this.drumState[entry.drum.id].ready>time+1e-9){this.leftOut.retuning++;entry.drum=null}
    }
    const ready=drums.filter(entry=>entry.drum);if(!ready.length)return out;
    const reaches=(hand,drum)=>stickReaches(this.sticks[hand],drum.x,time);
    // One drum: rolled where it is to be, both sticks on it; else the stick whose turn it is, or the other.
    if(ready.length===1){
      const {pitch,drum,glide}=ready[0],roll=!glide&&(rolled??seconds>ringOf(this.set,drum)+1e-9);
      if(roll&&reaches('LH',drum)&&reaches('RH',drum)){
        this.rollDrum(pitch,seconds,velocity,offset,{every:1/TIMPANI.rollHz});for(const hand of ['LH','RH'])this.sticks[hand]={x:drum.x,from:time+seconds,free:time+seconds};
        this.drumState[drum.id].end=time+seconds;out.push({pitch,drum:drum.id,hand:'both',rolled:true});return out;
      }
      const other=this.sticks.turn==='RH'?'LH':'RH',hand=[other,this.sticks.turn].find(each=>reaches(each,drum));
      if(!hand){this.leftOut.sticks++;return out}
      const ring=Math.min(seconds,ringOf(this.set,drum));
      this.strike(pitch,ring,velocity,offset,glide);this.sticks[hand]={x:drum.x,from:time,free:time+TIMPANI.strokeSeconds};this.sticks.turn=hand;
      this.drumState[drum.id].end=time+ring;if(glide)this.slid(drum,pitch,glide,time);out.push({pitch,drum:drum.id,hand,rolled:false,...(glide?{glideFrom:glide.from}:{})});return out;
    }
    // Two drums, a stick each: the left on the lower (the American setup's), or the other way where only that reaches;
    // rolled, each stick on its own drum.
    const [low,high]=[...ready].sort((a,b)=>a.drum.x-b.drum.x),ways=[{LH:low,RH:high},{LH:high,RH:low}];
    const way=ways.find(each=>reaches('LH',each.LH.drum)&&reaches('RH',each.RH.drum));
    if(!way){this.leftOut.sticks++;return this.strokes([ready[1].pitch],time,seconds,velocity,offset,{rolled})}
    const roll=!ready.some(entry=>entry.glide)&&(rolled??ready.some(entry=>seconds>ringOf(this.set,entry.drum)+1e-9));
    for(const hand of ['LH','RH']){
      const {pitch,drum,glide}=way[hand],ring=roll?seconds:Math.min(seconds,ringOf(this.set,drum));
      // (Held, the sticks by turns between the two drums: each drum a stroke in two, the right's between the left's.)
      if(roll)this.rollDrum(pitch,ring,velocity,offset,{every:2/TIMPANI.rollHz,from:hand==='RH'?1/TIMPANI.rollHz:0});else this.strike(pitch,ring,velocity,offset,glide);
      this.sticks[hand]=roll?{x:drum.x,from:time+ring,free:time+ring}:{x:drum.x,from:time,free:time+TIMPANI.strokeSeconds};
      this.drumState[drum.id].end=time+ring;if(glide&&!roll)this.slid(drum,pitch,glide,time);out.push({pitch,drum:drum.id,hand,rolled:roll,...(glide&&!roll?{glideFrom:glide.from}:{})});
    }
    return out;
  }
  // A drum slid to `pitch` from where it stood as it rings (a glissando): its pedal moved by the foot free first, for the
  // glide's seconds; the drum at its new pitch after.
  slid(drum,pitch,glide,time){
    const foot=this.feet.LF<=this.feet.RF?'LF':'RF';this.feet[foot]=Math.max(this.feet[foot],time)+glide.seconds;
    this.drumState[drum.id].pitch=pitch;
    this.retunes.push({drum:drum.id,foot,from:glide.from,to:pitch,start:+time.toFixed(3),end:+(time+glide.seconds).toFixed(3),glissando:true});if(this.retunes.length>64)this.retunes.shift();
  }
  // A drum struck: its recordings (samples: the layer its velocity chooses), its own struck membrane (the tom family), or
  // MIDI to timpani outside.
  strike(pitch,seconds,asked,offset,glide=null,musical={}){
    const velocity=this.plannedVelocity(asked,'tom');
    const sliding=glide?{glide:glide.seconds,glideFrom:glide.from}:{};
    if(this.audio?.mode==='midi'){this.audio.midiNote?.(pitch,seconds,velocity,undefined,offset,{instrument:'tom',profile:'pluck',...musical});return}
    if(this.audio?.mode==='samples'&&typeof this.audio.samplePitch==='function'){this.audio.countFamily?.('tom');this.audio.samplePitch(pitch,offset,.565,seconds,velocity,{...sliding,...musical,stroke:musical});return}
    this.audio?.voice?.(pitch,seconds,TIMPANI_CLODBOT.voiceGain,'sine',offset,{instrument:'tom',profile:'pluck',velocity,...sliding,...musical});
  }
  // A drum rolled from `offset` for `seconds`: struck `every` seconds from `from` (both sticks on it by turns, every
  // 1/rollHz; or, a double stop held, a stroke in two, the sticks by turns between its two drums), one note (audio.js
  // roll: on samples its recorded roll).
  rollDrum(pitch,seconds,velocity,offset,{every=1/TIMPANI.rollHz,from=0}={}){
    const length=seconds-from,strokes=Array.from({length:Math.max(2,Math.floor(length/every))},(_,k)=>k*every);
    if(!(length>0))return;
    if(typeof this.audio?.roll==='function'){this.audio.roll(pitch,length,TIMPANI_CLODBOT.voiceGain,'sine',offset+from,{instrument:'tom',profile:'pluck',velocity},{strokes,ring:2*every,later:.85});return}
    strokes.forEach((at,k)=>this.strike(pitch,k?Math.min(2*every,length-at):length,velocity*(k?.85:1),offset+from+at,null,
      {technique:'tremolo',...(k?{captured:false}:{})}));
  }
  // Each tick, the figure's strokes due in it, each where its drum is ready and a stick reaches it then (a chord struck on
  // this tick comes first: the voice leader's attack runs before everyTick).
  everyTick(clock){
    super.everyTick?.(clock);
    if((clock.tickInBar??0)===0)this.planFigure(clock);
    const plan=this.runPlan;if(plan?.bar!==clock.bar||!plan.notes.length||!this.voiced)return;
    const tick=clock.tickInBar??0,spt=secondsPerTick(clock),at=this.now(clock);
    for(const note of plan.notes){
      if(!(note.at>=tick-1e-9&&note.at<tick+1-1e-9))continue;
      const offset=(note.at-tick)*spt,pitch=note.which==='fifth'&&this.voiced.fifth!==null?this.voiced.fifth:this.voiced.root;
      const played=withScoreTime(this.audio,note,()=>this.strokes([pitch],at+offset,note.seconds,note.velocity,offset,{rolled:false}));
      note.played=played.length>0;
    }
  }
  // Its figure's cycle for a bar of `n` positions: tonic or dominant at each, the tonic where the position is strong
  // (TIMPANI_CLODBOT.strong), by turns between, drawn once from its seed and drawn again only where the bar's number of
  // positions changes.
  drawFigure(n,weights){
    const u=this.random(`figure:${n}`);let last='fifth';
    return Array.from({length:n},(_,k)=>{const which=weights[k]>=TIMPANI_CLODBOT.strong?'root':u()<.7?(last==='root'?'fifth':'root'):last;last=which;return {which}});
  }
  // The figure, planned once at a bar's start where the fillness asks for one: its cycle on the felt beats' subdivisions
  // (faster at a solo's climax, never quicker than two sticks alternating), but those within a stroke of a comp stroke,
  // each at the level the fillness gives it, within the band's attention's allowance.
  planFigure(clock){
    if(this.runPlan?.bar===clock.bar)return;
    this.runPlan={bar:clock.bar,notes:[]};
    if(!this.chord||!this.voiced)return;
    const fillness=this.fillnessOf(clock)??0,solo=this.soloIntensity(clock);if(!(fillness>0)&&solo===null)return;
    const spt=secondsPerTick(clock),span=clock.meter.pulsesPerBar,felt=this.felt(clock),intensity=solo??0;
    const shortest=Math.min(...felt.map(beat=>beat.length))*spt,most=Math.max(1,Math.floor(shortest/(TIMPANI.strokeSeconds/2)+1e-9));
    const perBeat=Math.min(most,Math.round(TIMPANI_CLODBOT.perBeat*(1+intensity))),beatStarts=felt.map(beat=>beat.start);
    const all=dividedBeats(felt,perBeat);
    const weights=all.map(({at})=>metricalWeight(at,{beatStarts,span}));
    if(this.figure?.length!==all.length){this.figure=this.drawFigure(all.length,weights);this.figuresDrawn=(this.figuresDrawn??0)+1}
    const struck=this.comp?.bar===clock.bar?this.comp.hits:[];
    const kept=all.map((cell,k)=>({...cell,k})).filter(({at})=>!struck.some(hit=>Math.abs(at-hit)*spt<TIMPANI.strokeSeconds-1e-9));
    if(!kept.length)return;
    const u=this.random(`figure-levels:${clock.bar}`),items=kept.map(({at,scoreTime},k)=>({id:`fig${k}`,at,scoreTime,weight:metricalWeight(at,{beatStarts,span}),position:at/span,u:u()}));
    const thresholds=rankThresholds(items,{order:this.fillOrder}),gap=span/(felt.length*perBeat);
    const notes=items.map((item,k)=>({scoreTime:shiftScoreTime(item.scoreTime,clock.tick-(clock.tickInBar??0),{axis:'ensemble'}),which:this.figure[kept[k].k].which,at:item.at,start:item.at*spt,seconds:2*gap*spt,
      level:blendLevel(thresholds.get(item.id),this.fillnessOf(clock,Math.min(span-1e-9,item.at))??0,{entering:true})})).filter(note=>note.level>0);
    const level=TIMPANI_CLODBOT.run+(TIMPANI_CLODBOT.runTop-TIMPANI_CLODBOT.run)*intensity;
    const {heard,claim,givenBackDb}=this.licensed(clock,notes.map(note=>({at:note.start,velocity:level*note.level})));
    this.runPlan={bar:clock.bar,notes:notes.map(note=>({...scoreTimeFields(note),which:note.which,at:note.at,start:note.start,seconds:note.seconds,velocity:this.softer(level*note.level,givenBackDb)}))};
    this.count(clock,'run',notes.length);
    this.bars.push({bar:clock.bar,fillness:+fillness.toFixed(3),run:notes.length,of:items.length,perBeat,...(solo===null?{}:{intensity:+intensity.toFixed(3)}),
      ...(heard?{attention:{claimDb:claim?+claim.claimDb.toFixed(2):null,allowanceDb:+heard.allowanceDb.toFixed(2),soloing:heard.soloing,givenBackDb:+givenBackDb.toFixed(2)}}:{})});
    if(this.bars.length>64)this.bars.shift();
  }
}

export const PerformedTimpani=HearsAttention(PerformedTiming(TimpaniClodbot,{instrument:'comping'}));
// Seated in a percussion section (settings.seat, settings.kind 'percussion'), it rests where its section's conductor
// rests it (bots/lib/modules/section-member.js).
export const SeatedTimpani=InSection(PerformedTimpani);
export const timpaniClodbot=defineBot(
  {
    id: "timpani_clodbot",orchestral:true, name: "timpani_clodbot", status: "native", source: "clodbot",
    category: "harmony", midiChannel: 11, performanceType: "percussive", outputModes: ["synth", "samples", "midi"],
    sampleBank: TIMPANI_BANK,
    // Its drums tuned by their pedals to the band's pitches, wherever a drum reaches them.
    pitchContract: "floating-mpe", planningCapabilities: Object.freeze({tuning: true}),
    specSettings: Object.freeze(["fillness", "fillOrder", "density", "drums", "seat", "size", "kind", "section", "arrival"]),
    description:
      "A timpanist whose drums, pedals and sticks play only what a timpanist's can, by construction: the band's harmony as its tonic and dominant, each on a drum its pedal tunes to it in time (a retune by a free foot once the drum's last note ends, the drum not struck until it has settled), microtones included; its two sticks by turns, never quicker than they recover or can cross the drums, a double stop on a change, a note that outlasts its drum rolled; comp and figure as one continuum, a solo's course, and the band's attention.",
  },
  (...args) => new SeatedTimpani(...args),
);
