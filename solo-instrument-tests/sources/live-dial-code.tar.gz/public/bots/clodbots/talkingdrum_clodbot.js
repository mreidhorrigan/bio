// talkingdrum_clodbot: a talking drummer on an hourglass drum (the family atlas's F33, variable-tension and friction
// membranes), playing phrases on the tones its squeeze reaches (shared/performers/talkingdrum.js). A new clodbot carrying
// the melody's principles to a drum, as steelpan_clodbot carries them to a pan; taken by 2a at c2's word, 29 September
// (SESSIONS.md 12:04).
//   - Its tones measured: the low, mid and high a talking drummer's squeeze reaches over the drum's rest, as three players
//     were measured reaching them (Akinbo 2019, doi:10.4000/lla.347), the drum's own pitches, not the band's harmony.
//     Each phrase is planned whole at its downbeat on those three (line.js on three steps, each step a tone): phrases of
//     its own motif in the sentence's shape, ending on its low tone.
//   - Contours by construction: its arm moves the pitch no faster than TALKING_DRUM.squeezePerSecond, so a note the arm
//     has not reached by its stroke is struck where the arm is and glides the rest of the way under it. So after a high
//     a low falls, and after a low a high rises, where the arm had not the time, and a low and a mid, closer, come
//     without one: as Akinbo measured the tones of a pair. One stick: a note the stick has not recovered for is left
//     out, said.
//   - Its share of the band's attention shapes it (given the solo, denser and louder toward its climax; behind another's,
//     less and softer); it plays in the ensemble's feel and rubato, and makes room for another's entrance.
//   - Its sound: hand drums' open tones (the VSCO 2 Community Edition's tumba, conga and quinto, CC0; c2's suggestion;
//     scripts/download-membrane-samples.mjs), the nearest recording played at its tone and slid as its arm squeezes (a
//     smaller drum, `relaxed` higher, keeps its tones near theirs); its own struck membrane (the tom family), gliding
//     so; or MIDI. No talking drum's own strokes under a free licence were found (c2 and 2a, 29 September).
import {Agent,defineBot} from '../../framework/index.js';
import {secondsPerTick} from '../../shared/meter-tactus.js';
import {TALKING_DRUM,talkingDrum,toneOf,squeezeSeconds} from '../../shared/performers/talkingdrum.js';
import {transportSeconds} from '../lib/modules/timekeeping.js';
import {licenseReach,soloArc} from '../../shared/attention.js';
import {HearsAttention} from '../lib/modules/attention.js';
import {HearsPartRubato,playLagged} from '../lib/modules/part-rubato.js';
import {PlaysPickups} from '../lib/modules/line-pickups.js';
import {HearsLineMotifs,occurrenceRecords} from '../lib/modules/line-motifs.js';
import {strikeWith} from '../lib/note-language.js';
import {Closure} from '../lib/modules/closure.js';
import {GroupingChoice} from '../lib/modules/grouping-choice.js';
import {LINE,meterKey,phraseBeforeEnding,phraseOffset,planLine} from '../../shared/performers/line.js';
import {PerformedTiming} from '../lib/modules/performed-timing.js';
import {makingRoom} from '../../shared/presentation.js';
import {createRandomStream} from '../../random-source.js';
import {withScoreTime,shiftScoreTime} from '../../shared/score-time.js';
import {bandPhraseBars,bandTempo} from '../../shared/opening-time.js';

const PHRASES_KEPT=16;
// Its density and loudness among equals, its fioriture as a soloist, and its built-in voice's gain (the median bot
// voice's loudness, as the mallet player's).
export const TALKING_DRUM_CLODBOT=Object.freeze({density:.45,loudness:.55,fioriture:.3,voiceGain:.05});
// Its recordings: hand drums' open tones (scripts/download-membrane-samples.mjs), the bank's one preset.
export const TALKING_DRUM_BANK='vscoMembranes';
// Its three tones as the line's three steps (line.js planLine), low to high.
const STEPS=Object.freeze([60,61,62]),TONES=Object.freeze(['L','M','H']);

// Where the arm can bring the pitch by a stroke: from `arm` (its pitch, settled at `settled`), toward `pitch`, no faster
// than it squeezes. -> {first (struck at), glide (s, the rest of the way under the note; 0 where reached)}.
export function reachFor(pitch,time,arm,settled,{choices=TALKING_DRUM}={}){
  if(arm===null||arm===undefined)return {first:pitch,glide:0};
  const reach=choices.squeezePerSecond*Math.max(0,time-settled),left=pitch-arm;
  const first=Math.abs(left)<=reach+1e-9?pitch:arm+Math.sign(left)*reach;
  return {first,glide:Math.abs(pitch-first)>choices.tolerance?squeezeSeconds(first,pitch,{choices}):0};
}
// A phrase on the drum: the line (line.js planLine) on three steps, each a tone of the drum, its stick and squeeze
// planned with it: a note the stick has not recovered for left out; each struck where the arm can be by then (reachFor),
// gliding the rest of the way under it. `arm` is where the last phrase left the arm ({pitch, settled, free}, in the
// phrase's seconds). -> {status, notes (each with its tone, and glideFrom and glide where it glides), changes, arm, motif,
// apex, lead, choice?}.
export function talkingPhrase({drum=talkingDrum(),arm=null,drumChoices=TALKING_DRUM,...line}){
  // (Its line no quicker than its stick recovers: feasible as it is planned, not thinned after.)
  const given=line.choices??LINE,planned=planLine({...line,choices:{...given,shortest:Math.max(given.shortest??LINE.shortest,drumChoices.strokeSeconds)},pool:[...STEPS],register:[STEPS[0],STEPS.at(-1)]});
  if(planned.status==='declined')return {...planned,changes:[]};
  const choices=drumChoices,notes=[],changes=[];let pitchNow=arm?.pitch??null,settled=arm?.settled??-Infinity,free=arm?.free??-Infinity,moving=null;
  for(const note of planned.notes){
    // (A note the line could not place, a motif's repetition beyond its three steps, left out as a pan's is.)
    if(!Number.isFinite(note.pitch)){changes.push({at:note.start,change:'a note left out',because:'the line has no step for it'});continue}
    const step=Math.max(0,Math.min(2,Math.round(note.pitch-STEPS[0]))),tone=TONES[step],pitch=toneOf(drum,tone,{choices});
    if(note.start<free-1e-9){changes.push({at:note.start,change:'a note left out',because:'the stick has not recovered'});continue}
    // (Struck while the arm still squeezes toward the last note's pitch: struck where the arm is then, gliding on from
    // there -- not as if it had arrived: the owner, 2 October 2026, "attack notes mid-glissando".)
    const midway=moving&&note.start<settled-1e-9,armAt=midway?moving.from+(pitchNow-moving.from)*(note.start-moving.at)/(settled-moving.at):pitchNow;
    const {first,glide}=reachFor(pitch,note.start,armAt,midway?note.start:settled,{choices});
    notes.push({...note,pitch,tone,...(glide>0?{glideFrom:first,glide}:{})});
    moving=glide>0?{from:first,at:note.start}:null;pitchNow=pitch;settled=note.start+glide;free=note.start+choices.strokeSeconds;
  }
  return {status:'stuck',notes,changes,arm:{pitch:pitchNow,settled,free},motif:planned.motif,apex:planned.apex,variation:planned.variation,lead:planned.lead,...(planned.choice?{choice:planned.choice}:{})};
}

export class TalkingDrumClodbot extends Agent {
  constructor(...args){
    super(...args);
    const relaxed=Number(args[2]?.relaxed??TALKING_DRUM.relaxed);
    this.drum=talkingDrum({relaxed});
    this.phrase=null;this.phrases=[];
    // Where its arm holds the pitch and since when, and when its stick is free (s of its own time: transportSeconds).
    this.arm={pitch:null,settled:-Infinity,free:-Infinity};
    // Its motif, kept and varied phrase by phrase, and its last phrase's apex, not taken again (line.js).
    this.motif=null;this.phraseIndex=0;this.previousApex=null;this.lead=null;
    // On samples, its recordings (the bank's one preset), where another was loaded for it; a render waits for them.
    if(this.audio?.mode==='samples'&&typeof this.audio.loadSampleBank==='function'&&this.audio.samplePreset!=='membranes')
      this.loading=this.audio.loadSampleBank(TALKING_DRUM_BANK,{preset:'membranes'}).catch(error=>this.decide?.({samples:{preset:'membranes',failed:String(error?.message??error)}}));
  }
  // Its time now (s).
  now(clock){return transportSeconds(this.transportClock??={},clock)}
  // Its density, loudness and fioriture for a phrase beginning at `bar`, from its attention there.
  shaping(bar){
    const attention=this.attentionAt?.(bar),base=TALKING_DRUM_CLODBOT;
    if(!attention||!Number.isFinite(attention.typicalDb))return {density:base.density,loudness:base.loudness,fioriture:0};
    const {reach,belowDb}=licenseReach({allowance:attention.allowanceDb,typicalDb:attention.typicalDb});
    if(attention.soloing){const arc=soloArc(attention.progress??.5)*reach;return {density:base.density+(1-base.density)*arc,loudness:base.loudness+(1-base.loudness)*arc,fioriture:base.fioriture+(1-base.fioriture)*arc}}
    const scale=10**(-belowDb/10);return {density:base.density*scale,loudness:base.loudness*Math.sqrt(scale),fioriture:0};
  }
  // A stroke: its recordings (samples: a hand drum's open tone at the layer its velocity chooses), its built-in voice
  // (the tom family's struck membrane), either gliding as the arm squeezes; or MIDI.
  strike(pitch,seconds,velocity,offset,glide=null){
    const sliding=glide?{glide:glide.seconds,glideFrom:glide.from}:{};
    if(this.audio?.mode==='midi'){this.audio.midiNote?.(pitch,seconds,velocity,undefined,offset,{instrument:'tom',profile:'pluck'});return}
    if(this.audio?.mode==='samples'&&typeof this.audio.samplePitch==='function'){this.audio.countFamily?.('tom');this.audio.samplePitch(pitch,offset,.565,seconds,velocity,sliding);return}
    this.audio?.voice?.(pitch,seconds,TALKING_DRUM_CLODBOT.voiceGain,'sine',offset,{instrument:'tom',profile:'pluck',velocity,...sliding});
  }
  onTick(tick,clock){
    super.onTick?.(tick,clock);
    const meter=clock?.meter;
    if(!meter||!Number.isInteger(clock.bar))return;
    const phraseBars=Math.max(1,Number(meter.phraseBars)||bandPhraseBars()),perTick=secondsPerTick(clock);
    // A phrase planned whole at its downbeat, its stick and squeeze with it, on its phrase grid (as the flute's); it ends
    // with the piece where the ending is known, rests through an answering silence and thins under a texture
    // (shared/presentation.js). At its entry it never waits.
    const ending=this.closingAt?.(clock)?.ending??null,endsAt=Number.isInteger(ending?.endsAt?.bar)?ending.endsAt.bar:null;
    if(endsAt!=null&&clock.bar>=endsAt||this.presentationOver?.(clock.bar,clock.bar+1)?.kind==='silence'){this.phrase=null;return}
    const offset=phraseOffset(this.attentionAt?.(clock.bar),phraseBars),current=this.phrase;
    const acting=current?makingRoom(this.presentationOver?.(clock.bar,current.endBar)).key:null;
    const due=clock.tickInBar===0&&(current?clock.bar>=current.endBar||clock.bar<current.startBar||current.meterKey!==meterKey(meter)||endsAt!=null&&current.endBar>endsAt&&!current.final||acting!=null&&acting!==current.room:true);
    if(due){
      const whole=phraseBeforeEnding(clock.bar,{phraseBars,offset,endsAt}),room=makingRoom(this.presentationOver?.(clock.bar,clock.bar+whole.bars));
      const span=phraseBeforeEnding(clock.bar,{phraseBars,offset,endsAt,breakAt:room.silentBar}),bars=span.bars;
      const random=(this.phraseRandom??=createRandomStream(`${this.randomStream?.seed??0}:talkingdrum`)),draw=()=>random.next();
      const shaped=this.shaping(clock.bar);shaped.density*=room.density;
      const pickup=span.final?null:this.pickupAt?.(clock.bar+bars,clock,draw)??null;
      // Its arm and stick where the last phrase left them, in this phrase's seconds.
      const start=this.now(clock),arm={pitch:this.arm.pitch,settled:this.arm.settled-start,free:this.arm.free-start};
      const planned=talkingPhrase({drum:this.drum,arm,coreOnly:room.thin,meter,bpm:Number(clock.bpm)||bandTempo(),bars,...shaped,motif:this.motif,motifDensity:TALKING_DRUM_CLODBOT.density,
        phraseIndex:this.phraseIndex,previousApex:this.previousApex,pickup,lead:this.lead,heard:[],climax:this.attentionAt?.(clock.bar)?.role==='climax',
        final:span.final?{tonic:STEPS[0]%12}:null,random:draw,choices:LINE});
      if(planned.motif)this.motif=planned.motif;if(planned.apex!=null)this.previousApex=planned.apex;this.lead=planned.lead??null;this.phraseIndex++;
      this.phrase={startTick:tick,perTick,notes:planned.notes,status:planned.status,startBar:clock.bar,endBar:clock.bar+bars,meterKey:meterKey(meter),final:span.final,room:room.key,
        records:occurrenceRecords(planned.notes,{by:this.instanceId,phrase:`${clock.bar}`,motif:this.motif})};
      this.phrases.push(this.phrase.entry={bar:clock.bar,bars,offset,pickup:pickup?.fill??null,status:planned.status,notes:planned.notes.length,glides:planned.notes.filter(note=>note.glide).length,
        ...(planned.choice?{choice:planned.choice}:{}),...(room.key?{room:room.key}:{}),changes:planned.changes.map(change=>change.change),leftOut:0,...shaped});
      if(this.phrases.length>PHRASES_KEPT)this.phrases.shift();
    }
    const phrase=this.phrase;
    if(!phrase?.notes?.length)return;
    // Each note as its tick comes round (as the flute's), at its part's own time where ManageBOT says one; a note is
    // never played late. Its stroke and squeeze again from where the stick and the arm are then (a rubato may have
    // hurried it): struck where the arm can be, gliding the rest; left out, counted, where the stick has not recovered.
    phrase.sounded??=new Set;
    if(Number.isFinite(phrase.lastTick)&&tick>phrase.lastTick+1)phrase.notes.forEach((note,index)=>{if(phrase.startTick+note.start/phrase.perTick<tick)phrase.sounded.add(index)});
    phrase.lastTick=tick;
    for(const [index,note] of phrase.notes.entries()){
      if(phrase.sounded.has(index))continue;
      const planned=phrase.startTick+note.start/phrase.perTick,at=Math.max(tick,this.partTick?.(planned,clock)??planned);
      if(at>=tick+1)continue;
      phrase.sounded.add(index);
      const seconds=(note.end-note.start)*.95,offsetSeconds=(at-tick)*perTick,time=this.now(clock)+offsetSeconds;
      if(time<this.arm.free-1e-9){if(phrase.entry)phrase.entry.leftOut++;continue}
      const {first,glide}=reachFor(note.pitch,time,this.arm.pitch,this.arm.settled);
      this.arm={pitch:note.pitch,settled:time+glide,free:time+TALKING_DRUM.strokeSeconds};
      const strike=()=>this.strike(note.pitch,seconds,note.velocity,offsetSeconds,glide>0?{from:first,seconds:glide}:null);
      // (Its rubato and its ornament's warp how it is played, not written: audio.js lagged.)
      const record=phrase.records?.[index];
      const play=()=>{if(record)strikeWith(this,[{pitch:note.pitch,language:record}],strike);else strike()},lag=(at-planned)*perTick+(Number(note.lag)||0);
      withScoreTime(this.audio,shiftScoreTime(note.scoreTime,phrase.startTick,{axis:'ensemble'}),()=>playLagged(this.audio,lag,play));
    }
  }
}
export function defineTalkingDrumClodbot(){
  const Bot=PerformedTiming(HearsAttention(PlaysPickups(HearsPartRubato(HearsLineMotifs(GroupingChoice(Closure(TalkingDrumClodbot),{role:'layer'}))))),{instrument:'melody'});
  return defineBot({
    id:'talkingdrum_clodbot',name:'talkingdrum_clodbot',status:'native',source:'clodbot',category:'beat',midiChannel:10,outputModes:['synth','samples','midi'],sampleBank:TALKING_DRUM_BANK,
    pitchContract:'floating-mpe',specSettings:Object.freeze(['relaxed']),
    description:'A talking drummer on an hourglass drum, playing phrases of its own motif on the three tones its squeeze reaches (a low, a mid and a high, as players were measured reaching them), its one stick never faster than it recovers and its arm never faster than it squeezes: a note the arm has not reached by its stroke struck where the arm is and glided the rest of the way, so a low after a high falls into place and a high after a low rises; given the solo, busier and louder toward its climax.',
  },(...args)=>new Bot(...args));
}
export const talkingdrumClodbot=defineTalkingDrumClodbot();
