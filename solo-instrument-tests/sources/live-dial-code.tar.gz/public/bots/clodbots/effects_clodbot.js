// effects_clodbot: a fork of ae_effectsBOT that does what the original did. The original put live input (`adc~`) through
// its effects -- AUDelay, AUDistortion, AUPitch and AUNewTimePitch presets, allpass and chamber reverbs, a ring
// modulator -- and moved between presets as the ensemble's valence and arousal moved (research/native-audio-bots-
// design.md); its browser port sounds a monitor note instead, and stays as it is. This fork processes a part of the
// ensemble: it asks whoever mixes to send that part into its own channel, where its chain is (shared/effects-routing.js),
// and moves the chain as the original moved its presets. From the original's patch (ae_effectsBOTnew.maxpat):
//   - "high arousal means change happens more often": a new preset every 10 s at arousal 0, every second at 1;
//   - "high valence means longer slide times": the glide into it from half a second at valence 0 to 10 s at 1 (its
//     5-100, read here as tenths of a second: ours);
//   - "if slewed valence goes below 0.5": the darker presets while it does, the brighter ones above.
// Its presets are ours: the AU presets hold unlabelled parameters of Apple's plug-ins, which cannot be carried over.
// Settings: `source`, the part it processes (a role, a bot's id, a channel; 'lead' if unsaid), and `send` (0-1, how much
// of it the chain hears; 0.7 if unsaid).
import {defineBot} from '../../framework/index.js';
import {EFFECTS_ADDRESS} from '../../shared/effects-routing.js';
import {secondsPerTick} from '../../shared/meter-tactus.js';
import {createRandomStream} from '../../random-source.js';

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const EFFECTS_CLODBOT=Object.freeze({
  // Seconds between presets at arousal 0 and 1, and glide seconds at valence 0 and 1 (above).
  intervalSeconds:Object.freeze([10,1]),glideSeconds:Object.freeze([.5,10]),
  source:'lead',send:.7,
  // Its presets (ours): a warm and a hard drive, a dub echo, a murk, a wide shimmer and a telephone band; each darker or
  // brighter by its band. The drive's amounts are small because insert-chain.js's drive is steep (a tenth of its range
  // already raises a quiet signal 16 dB into its curve); what it adds is taken back after it (effects-routing.js).
  presets:Object.freeze({
    dark:Object.freeze([
      Object.freeze({name:'warm drive',drive:{amount:.03,tone:3200},tone:{lowHz:80,highHz:5000},chorus:{rateHz:.3,depthMs:1},delay:.1,reverb:.25}),
      Object.freeze({name:'dub echo',drive:{amount:.01,tone:2400},tone:{lowHz:150,highHz:2600},chorus:{rateHz:.2,depthMs:.5},delay:.55,reverb:.35}),
      Object.freeze({name:'murk',drive:{amount:.02,tone:1800},tone:{lowHz:40,highHz:1400},chorus:{rateHz:.1,depthMs:3},delay:.2,reverb:.5}),
    ]),
    bright:Object.freeze([
      Object.freeze({name:'hard drive',drive:{amount:.1,tone:9000},tone:{lowHz:180,highHz:14000},chorus:{rateHz:.8,depthMs:.5},delay:.05,reverb:.1}),
      Object.freeze({name:'shimmer',drive:{amount:0,tone:12000},tone:{lowHz:300,highHz:18000},chorus:{rateHz:4.5,depthMs:6},delay:.2,reverb:.45}),
      Object.freeze({name:'telephone',drive:{amount:.06,tone:6000},tone:{lowHz:500,highHz:3400},chorus:{rateHz:.4,depthMs:.5},delay:.1,reverb:0}),
    ]),
  }),
});
const along=([from,to],x)=>from+(to-from)*Math.max(0,Math.min(1,Number(x)||0));

export function effectsClodbotClass(EffectsBot){
  return class EffectsClodbot extends EffectsBot {
    constructor(send,audio,settings={}){
      super(send,audio,settings);
      this.source=typeof settings?.source==='string'&&settings.source?settings.source:EFFECTS_CLODBOT.source;
      this.sendLevel=Number.isFinite(Number(settings?.send))?Math.max(0,Math.min(1,Number(settings.send))):EFFECTS_CLODBOT.send;
      this.elapsed=0;this.nextChange=0;this.presetsSaid=[];
    }
    // Its own stream for its choices of preset, apart from anything else it draws.
    presetRandom(){this.presetStream??=createRandomStream(`${this.audio?.seed??0}:${this.seedIdentity??'effects_clodbot'}:presets`);return this.presetStream.next()}
    onTick(tick,clock){
      if(this.enabled===false)return;
      const perTick=clock?.meter?secondsPerTick(clock):0;
      if(this.said===undefined){this.said=true;this.change({first:true});}
      else if(this.elapsed>=this.nextChange)this.change();
      this.elapsed+=perTick;
    }
    // A preset from the bank the valence is in, glided into as the valence asks, the next change as the arousal asks.
    change({first=false}={}){
      const bank=EFFECTS_CLODBOT.presets[this.valence<.5?'dark':'bright'],preset=bank[Math.floor(this.presetRandom()*bank.length)];
      const {name,...values}=preset;
      this.send(EFFECTS_ADDRESS,[{...(first?{source:this.source,send:this.sendLevel}:{}),...values,glideSeconds:first?0:along(EFFECTS_CLODBOT.glideSeconds,this.valence)}]);
      this.presetsSaid.push({at:this.elapsed,name});if(this.presetsSaid.length>64)this.presetsSaid.shift();
      this.nextChange=this.elapsed+along(EFFECTS_CLODBOT.intervalSeconds,this.arousal);
    }
  };
}

export function defineEffectsClodbot(EffectsBot){
  const EffectsClodbot=effectsClodbotClass(EffectsBot);
  return defineBot({id:'effects_clodbot',name:'effects_clodbot',status:'native',source:'clodbot',category:'utility',outputModes:['synth'],pitchContract:'none',
    specSettings:Object.freeze(['source','send']),
    // Silent alone: it sounds only what it processes (test/audio/effects-clodbot.test.mjs covers it against a part).
    requiresHeardVoices:true,
    description:'A fork of ae_effectsBOT that does what the original did: puts sound through its effects -- a drive, a band, a chorus, the ensemble\'s delay and reverb -- moving between presets as valence and arousal move (more often with more arousal, gliding longer with more valence). It processes a part of the ensemble (its `source`, the lead unless told), sent after its fader into this bot\'s channel, beside the part as it plays.'},
    (...args)=>new EffectsClodbot(...args));
}
