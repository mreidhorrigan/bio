// hindemith_clodbot: the voice leader (../lib/voice-leader.js) standing at Hindemith's location of the voice leaders'
// style space (../../shared/voice-leader-space.js): three voices from the whole space, their root the harmony's, their
// chord group rising and falling in tension over the phrase (harmonic fluctuation, hindemith.js), voiced anew each bar,
// under a line in seconds whose intervals with the bass it hears Series 2 values; in just intonation. It recalls anyone's
// material, as a voice imitates another (recallFrom).
import {defineBot} from '../../framework/index.js';
import {VoiceLeader} from '../lib/voice-leader.js';

export class HindemithClodbot extends VoiceLeader {
  constructor(send,audio,settings={}){super(send,audio,{style:'hindemith',location:'hindemith',recallFrom:'any',...settings})}
}

export const hindemithClodbot=defineBot(
  {
    id: "hindemith_clodbot", name: "hindemith_clodbot", status: "native", source: "clodbot", nativeTuning: true,
    category: "harmony", midiChannel: 14, performanceType: "polyphonic", outputModes: ["synth", "midi"],
    pitchContract: "floating-mpe",
    description:
      "Hindemith's harmony and melody following note pools and chord plans, in just intonation: three voices whose chord group rises and falls in tension (harmonic fluctuation), their space widening with it, under a line in seconds whose intervals with the bass it hears Series 2 values. Hindemith's location in the voice leaders' style space, which it shares with romantic_clodbot, impressionist_clodbot and jazzvoicing_clodbot (location).",
  },
  (...args) => new HindemithClodbot(...args),
);
