// hindemith_clodbot: Hindemith's harmony and melody, chords whose tension follows the phrase under a line in seconds
// (the shared core: ../lib/voice-leading-bot.js).
import {defineBot} from '../../framework/index.js';
import {unitRandom} from '../../shared/stochastic.js';
import {leadVoices,pitchClassOf,parallelsAgainst} from '../../shared/voice-leading.js';
import {chordTension,chordRoot,fluctuationTarget,melodicCost,harmonicRank} from '../../shared/hindemith.js';
import {voicesPayload} from '../../shared/sounding-voices.js';
import {contourCost} from '../../shared/melodic-contour.js';
import {modulo,near,has,clamp01,chordTones,VoiceLeadingBot} from '../lib/voice-leading-bot.js';
import {bandPhraseBars} from '../../shared/opening-time.js';

export class HindemithClodbot extends VoiceLeadingBot {
  constructor(send,audio,settings={}){super(send,audio,{style:'hindemith',velocity:.44,lineVelocity:.55,high:.62,intonation:'just',returns:.6,recallFrom:'any',contourWeight:.4,lineContourWeight:.8,...settings});this.line=null;this.strongLine=null;this.lineHistory=[];this.lineTop=null;}
  // The phrase's harmonic fluctuation: the tension it aims at now, or `ahead` ticks from now (a chord struck for a bar
  // aims at the tension at the middle of its bar).
  target(clock,ahead=0){
    const bars=clock.meter?.phraseBars||bandPhraseBars(),position=((clock.bar%bars)+(clock.tickInBar+ahead)/this.barTicks(clock))/bars;
    return fluctuationTarget(position,{low:.02,high:this.vl.high});
  }
  // Its intended dissonance follows the fluctuation: a narrow space at the phrase's ends, a wide one at its peak; in the
  // final bar, none: its last chord is the harmony's own (group I, as Hindemith's cadences end).
  ownDissonance(clock){return this.closing?.phase==='final'?0:clamp01(.12+this.target(clock))}
  palette(clock,{line=false}={}){const chord=this.chord,tones=chordTones(chord),{space}=this.space(clock,tones,{voicing:!line});return [...new Set([...tones.map(pc=>this.objectTuned(pc)),...space.pitchClasses,...(this.objectVoicing(tones,3)?.pcs??[])])]}
  attack(clock,{change}){
    const chord=this.chord;if(!chord)return;
    const hold=this.holdTicks(clock,{half:false}),spt=this.secondsPerTick(clock),target=this.target(clock,hold/2),bass=this.bassHeard(clock);
    const pcs=this.palette(clock),ranges=this.overBass(clock,[[50,64],[55,69],[59,74]]),previous=this.voicing?.length===3?this.voicing:null;
    // Three voices from its space, the harmony's root theirs (Hindemith's root, over the bass heard), their group as
    // near the phrase's tension as voice leading allows.
    const sonority=candidate=>bass!==null&&bass<candidate[0]?[bass,...candidate]:candidate;
    const contour=this.contourScore(clock,ranges.at(-1));
    const score=candidate=>{
      const whole=sonority(candidate),tension=chordTension(whole),root=chordRoot(whole);
      return 14*Math.abs(tension-target)+(root&&near(root.rootPc,chord.root)?0:3.5)+(contour?.(candidate)??0);
    };
    // A harmonic object no chord names: its root and its own notes held (objectVoicing).
    // (Its root in the object's own tuning where the object holds it, never beside its name on the grid as well.)
    const object=this.objectVoicing(chordTones(chord),3),root=this.objectTone(chord.root),required=object?[...new Set([root,...object.required])].slice(0,3):[chord.root];
    const next=leadVoices(previous,pcs,{voices:3,ranges,required,maxDoubling:pcs.length<3?2:1,style:'common-practice',...this.others(clock),maxStep:7,score});
    if(!next)return;
    const tuned=this.tuneChord(next.voicing);
    this.sound(clock,tuned,hold*spt*.98,this.vl.velocity,this.writtenInterval(clock,hold));this.announce(clock,tuned,'chord');
    this.moved={tick:clock.tick,from:this.voicing,to:next.voicing};this.voicing=next.voicing;
    this.decide({tick:clock.tick,change,chord:`${chord.root}:${chord.quality}`,voicing:next.voicing,target:+target.toFixed(2),tension:+chordTension(sonority(next.voicing)).toFixed(2)});
  }
  // The line: a note a beat above the chords, chosen by its melodic value, the step progression of its strong-beat
  // tones, its interval with the bass heard on a strong beat (Series 2), and how near the whole sonority's tension comes
  // to the phrase's; among the best few, by chance, so that it does not repeat itself. Its notes are its space's, in
  // any tuning: a quarter-tone space's line moves by quarter tones where it has them.
  everyTick(clock){
    if(!this.onBeat(clock)||!this.chord||!this.voicing)return;
    // In the final bar, one note: its closing note on the downbeat, as long as a strong beat's note is (its arrival).
    const final=this.closing?.phase==='final';if(final&&clock.tickInBar>0)return;
    const beat=this.beatTicks(clock),strong=clock.barStart||clock.tickInBar===this.barTicks(clock)/2,theme=this.themeAt(clock.tick,beat);
    // A recalled theme sets the line's rhythm: it plays where the theme has a note, and is drawn to the theme's pitch.
    if(theme?!theme.begins&&!strong:!strong&&unitRandom()>.35+.6*(this.density??.5))return;
    // Its notes: the harmony's and its space's, and a mode's going up and down (a maqam's B flat descending). A mode's
    // note that a collection heard does not hold (rast's B flat over a pool with only B half-flat) is where the object
    // and the maqam's practice conflict: kept out unless the bot plays the inflections (maqamInflections).
    const mode=this.contourMode(),target=this.target(clock),bass=this.bassHeard(clock),collection=this.collection();
    const modeNotes=mode?[...mode.ascending,...mode.descending].map(pc=>modulo(mode.tonic+pc,12)):[];
    const outside=collection?modeNotes.filter(pc=>!has(collection,pc)):[];
    const palette=[...new Set([...this.palette(clock,{line:true}),...modeNotes])];
    const last=this.line??76,low=65,high=86,candidates=[];
    const pitches=[];for(const pc of palette)for(let octave=Math.floor((low-pc)/12);pc+12*octave<=high;octave++){const p=pc+12*octave;if(p>=low&&Math.abs(p-last)<=9)pitches.push(p);}
    const {othersFrom,othersTo}=this.others(clock),own=this.moved?.tick===clock.tick&&this.moved.from?.length===this.moved.to.length?this.moved:{from:[],to:[]};
    // Its contour (melodic-contour.js): the line's own history and the highest it has reached in this phrase.
    const contour=this.vl.lineContourWeight>0?this.contourContext(clock,[low,high],{history:this.lineHistory,top:this.lineTop}):null;
    for(const pitch of pitches){
      const whole=[...(bass!==null?[bass]:[]),...this.voicing,pitch],tension=chordTension(whole);
      let cost=3*melodicCost(pitch-last)+8*Math.abs(tension-target)+Math.abs(pitch-75)*.04;
      if(strong&&bass!==null)cost+=3*harmonicRank(pitch-bass)/11;
      if(strong&&this.strongLine!==null){const step=Math.abs(pitch-this.strongLine);cost+=step>=.4&&step<=2.5?0:step<.4?.8:1.2;}
      if(this.lineHistory.slice(-3).includes(pitch))cost+=.5;
      if(theme)cost+=2.5*this.themeDistance(pitch,theme.pitch);
      // No parallels with the voices heard, nor with its own chord where that moved on this beat.
      cost+=10*parallelsAgainst([last],[pitch],[...othersFrom,...own.from],[...othersTo,...own.to]).length;
      if(contour)cost+=this.vl.lineContourWeight*contourCost(pitch,contour).cost;
      candidates.push({pitch,cost});
    }
    if(!candidates.length)return;
    candidates.sort((a,b)=>a.cost-b.cost);
    // Its last note is the tonic: the root of the chord it ends on.
    if(final){const tonic=candidates.filter(candidate=>near(pitchClassOf(candidate.pitch),this.chord.root));if(tonic.length)candidates.splice(0,candidates.length,...tonic);}
    // The conflict met where it bites (the best note is the inflection the collection does not hold), and the
    // inflections kept out.
    if(outside.length&&!this.vl.maqamInflections){
      if(has(outside,pitchClassOf(candidates[0].pitch)))this.meetConflict('maqam-inflection-outside-pool',clock,{note:candidates[0].pitch,maqam:mode.name});
      const kept=candidates.filter(candidate=>!has(outside,pitchClassOf(candidate.pitch)));if(!kept.length)return;candidates.splice(0,candidates.length,...kept);
    }
    const pool=candidates.slice(0,4),weights=pool.map(c=>Math.exp(-(c.cost-pool[0].cost)/.5)),total=weights.reduce((a,b)=>a+b,0);
    let draw=unitRandom()*total,chosen=pool[0];for(let i=0;i<pool.length;i++){draw-=weights[i];if(draw<=0){chosen=pool[i];break;}}
    const seconds=beat*this.secondsPerTick(clock)*(strong?1.9:.95),sounded=this.tuneOne(chosen.pitch);
    const span=Math.min(beat*(strong?2:1),this.barTicks(clock)-clock.tickInBar);
    this.sound(clock,[sounded],seconds,this.vl.lineVelocity+(strong?.04:0),this.writtenInterval(clock,span,{group:'line',replace:true}));
    this.broadcast('voices',[voicesPayload({voice:`${this.instanceId??'hindemith'}:line`,role:'line',pitches:[sounded],clock,style:this.styleName})]);
    this.keepOpening(clock,[sounded],'line');
    this.line=chosen.pitch;if(strong)this.strongLine=chosen.pitch;this.lineHistory.push(chosen.pitch);if(this.lineHistory.length>16)this.lineHistory.shift();
    if(this.lineTop?.phrase!==(clock.phrase??0))this.lineTop={phrase:clock.phrase??0,high:chosen.pitch,start:chosen.pitch};else this.lineTop.high=Math.max(this.lineTop.high,chosen.pitch);
    this.decide({tick:clock.tick,line:chosen.pitch,sounded,strong,target:+target.toFixed(2),cost:+chosen.cost.toFixed(2),...(theme?{theme:theme.pitch}:{})});
  }
}

export const hindemithClodbot=defineBot(
  {
    id: "hindemith_clodbot", name: "hindemith_clodbot", status: "native", source: "clodbot", nativeTuning: true,
    category: "harmony", midiChannel: 14, performanceType: "polyphonic", outputModes: ["synth", "midi"],
    pitchContract: "floating-mpe",
    description:
      "Hindemith's harmony and melody following note pools and chord plans, in just intonation: three voices whose chord group rises and falls in tension (harmonic fluctuation), their space widening with it, under a line in seconds whose intervals with the bass it hears Series 2 values.",
  },
  (...args) => new HindemithClodbot(...args),
);
