import {authoredFraction as Q} from '../../shared/performers/rhythm-cell.js';
import {scoreTime,shiftScoreTime,withScoreTime} from '../../shared/score-time.js';
// papmelody_clodbot: a fork of PAP_MelodyBot that restates its own theme where the form returns to it (the thematic form:
// docs/MOTIVIC_RETURN.md, shared/thematic-form.js).
//
// mh_MemoryBOT plans each return the form owes as a motif plan carrying the theme's line. The voice leaders draw their top
// voices to it, and in a return MemoryBOT brings back the harmony the theme was first heard in. The user heard the top
// voices alone as no change (27 September, on the thematic-returns A/B): a chord's top voice moves with the harmony and
// cannot carry a melody's rhythm. So the melody that wrote the theme plays it again, literally: its pitches in its rhythm,
// from the window's start, in the harmony MemoryBOT restores. Only its own themes, only in a return (a development's theme
// is heard against new harmony, which the voice leaders carry), never past the window, and everywhere else it plays as the
// port does. Made from the class it forks, which agents.js holds, by a function (no import cycle).
//
// Each return after the first is ornamented more than the last, as Chopin's nocturnes ornament a theme's returns
// (shared/performers/fioritura.js: the drummer's fill carried to the melody). A held note's end becomes a fioritura, a
// tuplet run of its own that lands on the next note's onset, so the theme's notes keep their places and it is still the
// theme. The first return is the theme as it was; the second ornaments about half its long notes, and the third and
// after all of them, more quickly and more freely, each by its share of the band's attention: ManageBOT features a
// theme's author where it returns, and that license gives the full amount; behind the band's focus, fewer.
// settings.fioriture sets the amount itself: 0 plays every return as it was, 1 ornaments the first as much as it can.
//
// Everywhere else it plays phrases (the user, 28 September 2026, on 0f's Debussy kit: "it lacks distinct phrasing or
// motifs ... The lead just goes on for a long time with no sense of phrases. Rubato should be part of the solution").
// The port draws each beat's notes from its pool at random, and so never phrases. The fork's main voice plays the line
// the bowed strings and the flute play (shared/performers/line.js): phrases made of its own motif, in the sentence's
// shape (the idea, its repetition, a continuation climbing to one apex, a held cadence, then a rest), keeping the
// melody rules, each note taking the harmony sounding when it plays. Its phrases fall on the form's (where the band's
// attention makes it the focus; half a phrase later where another's share is larger), so that its cadences and rests
// come where the rubato broadens. Its density is the port's (its phrase curve, the room's density, its attention
// share), its loudness with it; given the solo, its long notes take fioriture. The port's two other voices join the
// main voice's notes on the beat, half as often as the port plays them, and never in a rest. settings.phrasing 'port'
// plays as the port does, for comparison.
import {defineBot} from '../../framework/index.js';
import {secondsPerTick} from '../../shared/meter-tactus.js';
import {storedLine} from '../../shared/motifs.js';
import {PerformedTiming} from '../lib/modules/performed-timing.js';
import {TakesCadenza} from '../lib/modules/cadenza.js';
import {AnnouncesBroadening} from '../lib/modules/broadening.js';
import {FIORITURA,planFioritura} from '../../shared/performers/fioritura.js';
import {licenseReach,soloArc} from '../../shared/attention.js';
import {HearsAttention} from '../lib/modules/attention.js';
import {HearsPartRubato,playLagged} from '../lib/modules/part-rubato.js';
import {followHarmony,meterKey,phraseBeforeEnding,phraseOffset,planLine} from '../../shared/performers/line.js';
import {makingRoom,registerAway} from '../../shared/presentation.js';
import {PlaysPickups} from '../lib/modules/line-pickups.js';
import {HearsLineMotifs,occurrenceRecords} from '../lib/modules/line-motifs.js';
import {strikeWith} from '../lib/note-language.js';
import {Closure} from '../lib/modules/closure.js';
import {GroupingChoice} from '../lib/modules/grouping-choice.js';
import {createRandomStream} from '../../random-source.js';
import {bandPhraseBars,bandTempo,bandMeter} from '../../shared/opening-time.js';

// A restated note lasts to the next onset, at this share of the gap (a line's notes carry onsets, not lengths), and at
// most this many quarter notes; the last note lasts a quarter.
const LEGATO=.92,LONGEST_QUARTERS=2,RESTATEMENTS_KEPT=16;
// The ornament's amount a return takes by its place among its theme's returns (the first, the second, ...), where the
// settings do not say; and how long a held note must be (seconds) to be ornamented as surely as the amount allows.
const FIORITURE_BY_RETURN=Object.freeze([0,.5,1]),SURE_SECONDS=1;
// The share of that amount a return's ornaments take at its typical claim, before its license's reach adds the rest.
const ORNAMENT_BASE=.6;
// A run is played legato, as a pianist's fingers overlap: each of its notes sounds into the next, and none shorter than
// this (seconds). Played detached, its very short notes sounded cut off, even to a click (the user, 28 September).
const RUN_LEGATO=1.15,RUN_LEAST_SECONDS=.08;
// Its phrases: the density its motif is made at (its character; each phrase's density realizes it), how much less often
// than the port its other two voices join the main voice, and the phrases kept for inspection.
export const PHRASED=Object.freeze({motifDensity:.4,companions:.5,kept:16,
  // Given the solo, how much slower than the band's span it asks its phrase's last bar to end (relative, at its license's
  // full reach; ours), within what ManageBOT's follower may grant (RUB-002).
  soloStretch:.18});
function checkedPhrasing(value){
  if(value==null)return 'line';
  if(value!=='line'&&value!=='port')throw new RangeError('A melody\'s phrasing is \'line\' or \'port\'');
  return value;
}
function checkedFioriture(value){
  if(value==null)return null;
  if(!(Number.isFinite(value)&&value>=0&&value<=1))throw new RangeError('A melody\'s fioriture are an amount from 0 to 1');
  return value;
}

export function papmelodyClodbotClass(PapMelodyBot){
  return class PapMelodyClodbot extends PapMelodyBot {
    constructor(...args){
      super(...args);this.fioritureAsked=checkedFioriture(args[2]?.fioriture);this.phrasing=checkedPhrasing(args[2]?.phrasing);
      // Its phrases, its motif kept and varied phrase by phrase, and its last phrase's apex, not taken again (line.js).
      this.linePhrase=null;this.linePhrases=[];this.motif=null;this.phraseIndex=0;this.previousApex=null;this.lead=null;
    }
    // Its share of the band's attention (shared/attention.js, said by ManageBOT): soloing, its density rises with the
    // solo's arc to a climax as far as its license reaches, and with it its loudness and its tuplets, which the port draws
    // from its density, so its fast passages are loud at the top; behind another's solo, its density falls as far as its
    // allowance is under its typical claim. Without an allocation it plays as the port does.
    phraseDensity(clock){
      const own=super.phraseDensity(clock),pulses=Number(clock?.meter?.pulsesPerBar)||16;
      const attention=this.attentionAt?.((Number(clock?.bar)||0)+(Number(clock?.tickInBar)||0)/pulses);
      if(!attention||!Number.isFinite(attention.typicalDb))return own;
      const {reach,belowDb}=licenseReach({allowance:attention.allowanceDb,typicalDb:attention.typicalDb});
      if(attention.soloing)return own+(1-own)*reach*soloArc(attention.progress??.5);
      return own*10**(-belowDb/10);
    }
    // How far its share of the band's attention lets a return be ornamented, as its return asks (1 where nothing has been
    // said): featured where its theme returns (ManageBOT), the full amount; otherwise its license's reach, the full
    // amount at its top; behind the band's focus, thinned as its allowance falls under its typical claim, as its density
    // is.
    ornamentShare(bar){
      const attention=this.attentionAt?.(bar);
      if(!attention||!Number.isFinite(attention.typicalDb)||attention.featured)return 1;
      const {reach,belowDb}=licenseReach({allowance:attention.allowanceDb,typicalDb:attention.typicalDb});
      return belowDb>0?10**(-belowDb/10):Math.min(1,ORNAMENT_BASE+(1-ORNAMENT_BASE)*reach);
    }
    // The spans ManageBOT declares, by their first bar (the clocks play them; a soloist may ask to shape its own).
    onMessage(message){
      super.onMessage?.(message);
      if(message?.address!=='/broadcast/rubato')return;
      const span=message.args?.[0];
      if(span&&typeof span.id==='string'&&Number.isInteger(span.bar)&&Array.isArray(span.knots)&&span.knots.length>=2){
        (this.spansHeard??=new Map).set(span.bar,span);
        while(this.spansHeard.size>16)this.spansHeard.delete(this.spansHeard.keys().next().value);
      }
    }
    // Given the solo, its phrase's last bar held back (RUB-002, the band answering a performer): the span's knots there
    // asked slower, rising to soloStretch times its license's reach at the phrase's end, announced as the phrase begins.
    // ManageBOT follows within its box, or declines and the band keeps its plan.
    requestStretch(clock,bars,attention){
      const span=this.spansHeard?.get(clock.bar);
      if(!span||!attention?.soloing||!Number.isFinite(attention.typicalDb))return null;
      const reach=licenseReach({allowance:attention.allowanceDb,typicalDb:attention.typicalDb}).reach;
      if(!(reach>0))return null;
      const meter=clock.meter,barQuarters=Number(meter.pulsesPerBar)*4/((Number(meter.denominator)||bandMeter().denominator)*(Number(meter.subdivision)||bandMeter().subdivision));
      const quarters=span.knots.map(knot=>Array.isArray(knot.at)?knot.at[0]/knot.at[1]:Number(knot.at)),lastBar=(bars-1)*barQuarters;
      const from=quarters.findIndex((quarter,i)=>i>0&&quarter>=lastBar-1e-9);
      if(from<1)return null;
      const n=span.knots.length-from,densities=span.knots.slice(from).map((knot,k)=>Number(knot.density)*(1+PHRASED.soloStretch*reach*(k+1)/n));
      this.broadcast('rubatoRequest',[{id:span.id,performer:this.instanceId,from,densities}]);
      return {from,stretch:PHRASED.soloStretch*reach};
    }
    // A return of its own theme: accepted, and kept for its window. Anything else is the framework's to answer.
    onPlan(plan,message){
      const payload=plan?.payload,action=payload?.return;
      if(plan?.kind!=='motif'||!action||payload?.motif)return super.onPlan?.(plan,message);
      // (Its notes naming the stored motif, for what it plays of it to be said to MemoryBOT: motifs.js storedLine.)
      const line=storedLine(payload.theme).filter(note=>Number.isFinite(note?.at)&&Number.isFinite(note?.pitch));
      const own=payload.theme?.author===this.instanceId,restates=own&&action.action==='present'&&!action.transformation&&line.length>=3&&
        Number.isInteger(plan.appliesAt?.bar)&&Number.isInteger(plan.expiresAt?.bar)&&plan.expiresAt.bar>plan.appliesAt.bar;
      if(!restates)return super.onPlan?.(plan,message);
      // A section's returns come together, each with its own window: kept in order, each played in its turn.
      (this.restatementPlans??=[]).push({planId:plan.planId,family:payload.theme.family,line:[...line].sort((a,b)=>a.at-b.at),
        fromBar:plan.appliesAt.bar,toBar:plan.expiresAt.bar,startTick:null,played:0});
      if(this.restatementPlans.length>8)this.restatementPlans.shift();
      this.respondToPlan(plan,'accept',{createdAt:plan.createdAt,
        rationale:`${payload.theme.family} is this melody's own theme: it plays it again as it was, where the form returns to it.`});
    }
    // In a restatement's window its line, a note as its tick comes round (so a tempo curve carries it); elsewhere its
    // phrases (or the port, where its settings ask).
    onTick(tick,clock){
      if(this.restatementPlans?.length&&Number.isInteger(clock?.bar)&&clock.meter){
        this.restatementPlans=this.restatementPlans.filter(window=>clock.bar<window.toBar);
        const window=this.restatementPlans.find(entry=>clock.bar>=entry.fromBar);
        if(window)return this.restate(window,tick,clock);
      }
      if(this.phrasing==='line'&&Number.isInteger(clock?.bar)&&clock.meter)return this.playPhrases(tick,clock);
      return super.onTick(tick,clock);
    }
    // Its phrases: each planned whole at its downbeat on its phrase grid (the form's, or half a phrase later where
    // another's share of the band's attention is larger), ending at the grid's next bar, re-planned where the meter
    // changes; each note as its tick comes round. At its entry it never waits: its first phrase runs from there to its
    // grid's next bar (the user: "we need to fix the bug where some renders have silence at their beginnings").
    playPhrases(tick,clock){
      this.boundary(clock);
      const meter=clock.meter,phraseBars=Math.max(1,Number(meter.phraseBars)||bandPhraseBars()),perTick=secondsPerTick(clock),range=this.familyConfig.voiceRanges[0];
      // The piece's ending, where it is known (Closure: form_clodbot's closing, or the stop the ensemble committed to): its
      // last phrase ends with it, its cadence on the tonic held to the end, and nothing after. A phrase planned before the
      // ending was known that runs past it gives way, at a bar line, to a last phrase.
      // Room for another's entrance (shared/presentation.js, ManageBOT's): through an answering silence it rests, its
      // phrase ending before it; under a texture it thins, and under a register it keeps out of the author's. A phrase
      // planned before the presentation acting on its bars was said is planned again from the bar line.
      const ending=this.closingAt?.(clock)?.ending??null,endsAt=Number.isInteger(ending?.endsAt?.bar)?ending.endsAt.bar:null;
      if(endsAt!=null&&clock.bar>=endsAt||this.presentationOver?.(clock.bar,clock.bar+1)?.kind==='silence'){this.linePhrase=null;return}
      const attention=this.attentionAt?.(clock.bar),offset=phraseOffset(attention,phraseBars),current=this.linePhrase;
      const acting=current?makingRoom(this.presentationOver?.(clock.bar,current.endBar)).key:null;
      const due=clock.tickInBar===0&&(current?clock.bar>=current.endBar||clock.bar<current.startBar||current.meterKey!==meterKey(meter)||endsAt!=null&&current.endBar>endsAt&&!current.final||acting!=null&&acting!==current.room:true);
      if(due){
        const whole=phraseBeforeEnding(clock.bar,{phraseBars,offset,endsAt}),room=makingRoom(this.presentationOver?.(clock.bar,clock.bar+whole.bars));
        const span=phraseBeforeEnding(clock.bar,{phraseBars,offset,endsAt,breakAt:room.silentBar}),bars=span.bars;
        // The port's phrase: a new curve for its density, and its form said as the port says it.
        this.phraseBars=bars;this.generateCurve();this.announceForm();
        // Its density across the phrase, as the port's would be through it (its curve, the room's, its attention).
        const density=[0,.25,.5,.75].reduce((sum,x)=>{const at=x*bars;return sum+this.phraseDensity({...clock,bar:clock.bar+Math.floor(at),tickInBar:0,beat:(at%1)*(Number(meter.numerator)||bandMeter().numerator)})},0)/4;
        const register=room.awayFrom?registerAway(range,room.awayFrom)??range:range;
        // Its fioriture as a soloist: its license's reach along the solo's arc through the phrase (few at the solo's
        // opening, the most at its climax), as its density goes.
        const reach=attention?.soloing&&Number.isFinite(attention.typicalDb)?licenseReach({allowance:attention.allowanceDb,typicalDb:attention.typicalDb}).reach*soloArc(this.attentionAt?.(clock.bar+bars/2)?.progress??attention.progress??.5):0;
        const random=(this.phraseRandom??=createRandomStream(`${this.randomStream?.seed??0}:phrases`)),draw=()=>random.next();
        // Where the form marks the join its phrase ends at, a pickup into it, as the drummer's fill (line-pickups.js).
        const pickup=span.final?null:this.pickupAt?.(clock.bar+bars,clock,draw)??null;
        const planned=planLine({register,coreOnly:room.thin,pool:this.notes,meter,bpm:Number(clock.bpm)||bandTempo(),bars,density:density*room.density,loudness:density,fioriture:reach,
          motif:this.motif,motifDensity:PHRASED.motifDensity,phraseIndex:this.phraseIndex,previousApex:this.previousApex,climax:attention?.role==='climax',pickup,lead:this.lead,heard:this.motifsHeard?.()??[],final:span.final?{tonic:ending?.tonic??null,...(band=>band?{motif:band}:{})(this.bandMotif?.({meter,bpm:Number(clock.bpm)||bandTempo(),pool:this.notes,register:register??null}))}:null,random:draw});
        if(planned.status==='planned'){this.motif=planned.motif;this.previousApex=planned.apex;this.lead=planned.lead??null}
        // A motif chosen now, from a slate unlike the other lines' (line.js chooseMotif), said to them (line-motifs.js).
        if(planned.choice)this.sayMotif?.(planned.motif);
        this.phraseIndex++;
        this.linePhrase={startTick:tick,perTick,notes:planned.notes,startBar:clock.bar,endBar:clock.bar+bars,meterKey:meterKey(meter),final:span.final,room:room.key,
          // Each segment an occurrence of its motif, declared on its first note's strike (line-motifs.js).
          records:occurrenceRecords(planned.notes,{by:this.instanceId,phrase:`${clock.bar}`,motif:this.motif})};
        const stretched=this.requestStretch(clock,bars,attention);
        this.linePhrases.push({bar:clock.bar,bars,offset,pickup:pickup?.fill??null,stretch:stretched?.stretch??null,density,status:planned.status,notes:planned.notes.length,variation:planned.variation,apex:planned.apex,...(planned.choice?{choice:planned.choice}:{}),...(room.key?{room:room.key}:{})});
        if(this.linePhrases.length>PHRASED.kept)this.linePhrases.shift();
      }
      const phrase=this.linePhrase;
      if(!phrase?.notes?.length)return;
      const [low,high]=this.config.velocityRange;
      const companions=(this.companionRandom??=createRandomStream(`${this.randomStream?.seed??0}:companions`));
      // Each at its part's own time where ManageBOT says one over the band's clock (part-rubato.js): a note that moved
      // earlier than the tick it was planned in sounds at once.
      // Ticks it was not given (paused, and started again) take their notes with them: a note is never played late.
      phrase.sounded??=new Set;
      if(Number.isFinite(phrase.lastTick)&&tick>phrase.lastTick+1)phrase.notes.forEach((note,index)=>{if(phrase.startTick+note.start/phrase.perTick<tick)phrase.sounded.add(index)});
      phrase.lastTick=tick;
      for(const [index,note] of phrase.notes.entries()){
        if(phrase.sounded.has(index))continue;
        const planned=phrase.startTick+note.start/phrase.perTick,at=Math.max(tick,this.partTick?.(planned,clock)??planned);
        if(at>=tick+1)continue;
        phrase.sounded.add(index);
        // Notes under one slur sound into each other (legato); others a little short of their length.
        const next=phrase.notes[index+1],slurred=Boolean(note.slur)&&next?.slur===note.slur;
        const seconds=slurred?(next.start-note.start)*RUN_LEGATO:(note.end-note.start)*.95;
        const velocity=low+(high-low)*note.velocity,offsetSeconds=(at-tick)*perTick;
        const pitch=followHarmony(note.pitch,this.notes,range),record=phrase.records?.[index];
        const strike=()=>this.audio.papMelodyVoice(pitch,Math.max(RUN_LEAST_SECONDS,seconds),velocity,offsetSeconds,0,...(note.fioritura?[{ownSubdivision:true}]:[]));
        // (Its rubato and its ornament's warp how it is played, not written: audio.js lagged.)
        const play=()=>{if(record)strikeWith(this,[{pitch,language:record}],strike);else strike()},lag=(at-planned)*perTick+(Number(note.lag)||0);
        withScoreTime(this.audio,shiftScoreTime(note.scoreTime,phrase.startTick,{axis:'ensemble'}),()=>playLagged(this.audio,lag,play));
        // (A note of the band's theme, MemoryBOT's, returned in its last phrase: said to it, line-motifs.js rememberPlayed.)
        this.rememberPlayed?.(note,{phrase:phrase.startBar,offset:offsetSeconds+lag,seconds:Math.max(RUN_LEAST_SECONDS,seconds)});
        // The port's other two voices, on the main voice's beats, half as often as the port plays them; none while it
        // makes room for another's entrance (they thicken it first).
        if(!note.beatStart||note.fioritura||note.figure||phrase.room)continue;
        for(const voice of [1,2])if(companions.next()<this.familyConfig.voicePlayProbability*PHRASED.companions)
          {const companion=()=>this.audio.papMelodyVoice(this.voiceNote(voice),seconds,velocity*.8,offsetSeconds,voice);withScoreTime(this.audio,shiftScoreTime(note.scoreTime,phrase.startTick,{axis:'ensemble'}),()=>playLagged(this.audio,lag,companion))}
      }
      this.memoryPlayed?.report(tick);
    }
    restate(window,tick,clock){
      const perTick=secondsPerTick(clock),ticksPerQuarter=Math.max(1,Number(clock.meter.subdivision)||bandMeter().subdivision)*(Number(clock.meter.denominator)||bandMeter().denominator)/4;
      if(window.startTick===null){
        window.startTick=tick-(clock.tickInBar??0)+(clock.bar-window.fromBar)*(Number(clock.meter.pulsesPerBar)||16);
        const count=(this.returnsOf??=new Map).set(window.family,(this.returnsOf.get(window.family)??0)+1).get(window.family);
        const amount=this.fioritureAsked??FIORITURE_BY_RETURN[Math.min(count,FIORITURE_BY_RETURN.length)-1]*this.ornamentShare(window.fromBar);
        window.notes=this.ornamentedLine(window.line,{amount,ticksPerQuarter,perTick,velocity:Math.min(1,Number(this.config?.velocityRange?.[1])||.8),
          windowTicks:(window.toBar-window.fromBar)*(Number(clock.meter.pulsesPerBar)||16)});
        (this.restatements??=[]).push({family:window.family,fromBar:window.fromBar,toBar:window.toBar,notes:0,amount,
          ornaments:window.notes.filter(note=>note.ornament&&note.first).length,ornamentNotes:window.notes.filter(note=>note.ornament).length});
        if(this.restatements.length>RESTATEMENTS_KEPT)this.restatements.shift();
      }
      for(const note of window.notes){
        const at=window.startTick+note.at;
        if(at<tick||at>=tick+1)continue;
        // An ornament keeps its own subdivision: the feel does not swing it (performed-timing.js), as a fill's is not.
        // (Its warp how it is played, not written: audio.js lagged.)
        const strike=()=>this.audio.papMelodyVoice(note.pitch,note.seconds,note.velocity,(at-tick)*perTick,0,...(note.ornament?[{ownSubdivision:true}]:[]));
        withScoreTime(this.audio,shiftScoreTime(note.scoreTime,window.startTick,{axis:'ensemble'}),()=>playLagged(this.audio,note.lag,strike));
        if(!note.ornament){window.played++;this.restatements.at(-1).notes++}
        // (Its theme's note, stored: said to MemoryBOT, line-motifs.js rememberPlayed.)
        this.rememberPlayed?.(note,{phrase:window.fromBar,offset:(at-tick)*perTick+(Number(note.lag)||0),seconds:note.seconds});
      }
      this.memoryPlayed?.report(tick);
    }
    // The return's notes, in ticks from its window's start: the theme's line as it was, and at `amount` a fioritura over
    // the end of each held note it ornaments, landing on the next note's onset, inside the window. A note is ornamented
    // with the amount's chance, surely only where it is held a second or more.
    ornamentedLine(line,{amount,ticksPerQuarter,perTick,velocity,windowTicks=Infinity}){
      const first=line[0].at,notes=[];
      const random=(this.fioritureRandom??=createRandomStream(`${this.randomStream?.seed??0}:fioriture`)),draw=()=>random.next();
      line.forEach((note,index)=>{
        const scoreAt=Q(note.at).sub(Q(first)).mul(Q(ticksPerQuarter)),at=scoreAt.toNumber(),following=line[index+1],next=following&&(following.at-first)*ticksPerQuarter<windowTicks?following:null;
        const gap=next?(next.at-note.at)*ticksPerQuarter:null;
        const spanTicks=gap==null?0:Math.round(gap*(1-FIORITURA.held));
        const chance=amount*Math.min(1,(gap??0)*perTick/SURE_SECONDS);
        const ornament=amount>0&&spanTicks>0&&draw()<chance?planFioritura({from:note.pitch,to:next.pitch,pool:this.notes,range:this.familyConfig?.voiceRanges?.[0]??[48,84],
          spanTicks,tickSeconds:perTick,amount,random:draw}):null;
        const heldTicks=ornament?gap-spanTicks:following?Math.min(LONGEST_QUARTERS*ticksPerQuarter,(following.at-note.at)*ticksPerQuarter*LEGATO):ticksPerQuarter;
        // A held note ornamented sounds until its run begins, with no gap before it.
        const full=following?Q(following.at).sub(Q(note.at)).mul(Q(ticksPerQuarter)):Q(ticksPerQuarter),written=ornament?full.sub(spanTicks):full.min(Q(LONGEST_QUARTERS).mul(Q(ticksPerQuarter)));
        notes.push({scoreTime:scoreTime(scoreAt,written,{axis:'phrase'}),at,pitch:note.pitch,seconds:heldTicks*perTick,velocity,ornament:false,
          ...(typeof note.motifId==='string'&&Number.isInteger(note.index)?{source:{motifId:note.motifId,index:note.index}}:{})});
        if(!ornament)return;
        const start=at+gap-spanTicks;
        ornament.notes.forEach((step,k)=>{
          const until=k+1<ornament.notes.length?ornament.notes[k+1].at:spanTicks;
          notes.push({scoreTime:shiftScoreTime(step.scoreTime,scoreAt.add(full).sub(spanTicks),{axis:'phrase'}),at:start+step.at,pitch:step.pitch,seconds:Math.max(RUN_LEAST_SECONDS,(until-step.at)*perTick*RUN_LEGATO),velocity:Math.min(1,velocity*step.velocity),
            ornament:true,...(k===0?{first:true}:{}),...(Math.abs(step.at-step.written)>1e-9?{lag:(step.at-step.written)*perTick}:{})});
        });
      });
      return notes.sort((a,b)=>a.at-b.at);
    }
  };
}
export function definePapmelodyClodbot(PapMelodyBot){
  // Played in the ensemble's feel, where one is set (the performance layer: docs/PERFORMANCE_TIMING.md), its restatements too;
  // and a cadenza where a render asks the melody for one (cadenza.js), from its own pool, in its main voice's range; and
  // a broadening it announces where a render's settings ask for one (broadening.js), the band slowing with it.
  const PapMelodyClodbot=PerformedTiming(TakesCadenza(AnnouncesBroadening(HearsAttention(PlaysPickups(HearsPartRubato(HearsLineMotifs(GroupingChoice(Closure(papmelodyClodbotClass(PapMelodyBot)),{role:'layer'}))))),{instrument:'melody'}),{instrument:'melody',
    material(){return {pool:this.notes,range:this.familyConfig.voiceRanges[0]}},
    voice(pitch,seconds,velocity,offset){this.audio.papMelodyVoice(pitch,seconds,velocity,offset,0,{free:true})}}),{instrument:'melody'});
  return defineBot({
      id:'papmelody_clodbot',name:'papmelody_clodbot',status:'native',source:'clodbot',forkOf:'papMelody',category:'melody',midiChannel:3,
      outputModes:['synth','midi'],pitchContract:'floating-mpe',specSettings:Object.freeze(['broadening','fioriture','phrasing']),
      description:"A fork of PAP_MelodyBot that plays phrases: its main voice a line made of its own motif, in the sentence's shape (the idea, its repetition, a continuation climbing to one apex, a held cadence, then a rest), keeping the melody rules, its phrases on the form's so that its cadences come where the rubato broadens (half a phrase later where another's attention share is larger), with the port's other two voices joining it on the beat; and it restates its own theme where the form returns to it: its pitches in its rhythm, in the harmony mh_MemoryBOT brings back for the return, each return after the first ornamented more than the last with fioriture (tuplet runs landing on the theme's next note, as Chopin's nocturnes ornament their returns); given the solo by the band's attention it builds it to a climax, fast and loud together, and behind another's it plays lighter; it plays in the ensemble's feel. settings.phrasing 'port' plays as PAP_MelodyBot does.",
    },(...args)=>new PapMelodyClodbot(...args));
}
