// riff_clodbot: a riff, its rhythm from what it hears (../lib/rhythm-pattern-bot.js) and its notes from the harmony it
// hears, led as the voice leaders lead theirs (../lib/voice-leading-bot.js).
import {defineBot} from '../../framework/index.js';
import {GroupingChoice} from '../lib/modules/grouping-choice.js';
import {unitRandom} from '../../shared/stochastic.js';
import {HeardRhythm,hearRhythmMessage} from '../../shared/rhythm-spaces.js';
import {pitchClassOf,parallelsAgainst} from '../../shared/voice-leading.js';
import {VoiceLeadingBot} from '../lib/voice-leading-bot.js';
import {Phrasing} from '../lib/modules/phrasing.js';
import {clamp01,nextPattern,characterShift} from '../lib/rhythm-pattern-bot.js';
import {pitchClassDistance} from '../../shared/estimation/harmonic-levels.js';

// It phrases its line (bots/lib/modules/phrasing.js): a glide into a note of weight after a leap, a vibrato on a held
// note, a held note's tone swelling and its last note's closing.
export class RiffClodbot extends Phrasing(VoiceLeadingBot) {
  constructor(send,audio,settings={}){
    super(send,audio,{style:'riff',velocity:.52,dissonance:.3,rhythmDissonance:.35,riffDensity:.4,intonation:'equal',returns:.4,rhythmLayers:'groove',...settings});
    // What it takes its rhythm from: the layers that repeat (a drum's groove under a part that changes every bar), or
    // everything heard together (riffmotif_clodbot).
    this.heardRhythm=new HeardRhythm({layers:this.vl.rhythmLayers});this.pattern=null;this.rhythmChange=.25;this.cell=null;this.riffPitch=null;
  }
  onMessage(message){super.onMessage(message);hearRhythmMessage(this.heardRhythm,message,this.instanceId??null)}
  rearticulates(){return false}
  attack(){}
  // Its line: at each onset of its pattern, the next step of its cell within the space (the first of a bar on a chord
  // tone near where it was), clear of parallels with the voices heard, drawn to a recalled theme.
  everyTick(clock){
    if(!this.chord)return;
    // Its ending: on the last bar's downbeat, the chord's root (the tonic, where the ensemble has cadenced) nearest where
    // it was, as long as its own downbeat notes are (to its pattern's next note, a beat at most), never held to the stop;
    // nothing else in that bar.
    if(this.closing?.phase==='final'){
      if(clock.tickInBar!==0)return;
      const last=this.riffPitch??64,pitch=[55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74].filter(p=>pitchClassDistance(p,this.chord.root,12)<.2)
        .sort((a,b)=>Math.abs(a-last)-Math.abs(b-last))[0]??last,sounded=this.tuneOne(pitch),own=Math.min(Math.max(1,(this.pattern?.positions?.[1]??Infinity)-(this.pattern?.positions?.[0]??0)),this.beatTicks(clock)),seconds=own*this.secondsPerTick(clock)*.9;
      const phrase=this.phraseNote({pitch:sounded,seconds,at:this.elapsedSeconds(clock),clock,accent:1,last:true});
      const written=this.writtenInterval(clock,own,{group:'line',replace:true});
      this.playWritten(written,()=>this.audio.sequencerNote?this.audio.sequencerNote(sounded,seconds,this.vl.velocity+.06,phrase):this.sound(clock,[sounded],seconds,this.vl.velocity+.06,written));
      this.riffPitch=pitch;this.announce(clock,[sounded],'line');this.decide({tick:clock.tick,riff:pitch,sounded,final:true});
      return;
    }
    const beat=this.beatTicks(clock);
    if(clock.barStart||!this.pattern){
      const renewed=nextPattern(this,clock,clamp01(this.vl.rhythmDissonance+characterShift(this)),this.vl.riffDensity*(.6+.8*(this.density??.5)));
      if(renewed!==this.pattern||!this.cell){this.pattern=renewed;this.cell=renewed.positions.map((_,i)=>i===0?0:[1,-1,2,-2,1,1,-1][Math.floor(unitRandom()*7)]);}
    }
    const index=this.pattern.positions.indexOf(clock.tickInBar);if(index<0)return;
    // Its tones: the chord's, or a harmonic object's own notes where no chord names them (objectVoicing).
    const named=[this.chord.root,this.chord.third,this.chord.fifth,this.chord.seventh].filter(pc=>pc!==null&&pc!==undefined),tones=this.objectVoicing(named,Infinity)?.pcs??named;
    const {space}=this.space(clock,tones),scale=[...new Set([...space.pitchClasses,...tones])].sort((a,b)=>a-b);
    const low=55,high=74,last=this.riffPitch??64,ladder=[];
    for(let octave=3;octave<=7;octave++)for(const pc of scale){const p=12*octave+pc;if(p>=low&&p<=high)ladder.push(p);}
    ladder.sort((a,b)=>a-b);if(!ladder.length)return;
    const nearest=pitch=>ladder.reduce((best,p)=>Math.abs(p-pitch)<Math.abs(best-pitch)?p:best,ladder[0]);
    let target;
    if(index===0){const chordTones=ladder.filter(p=>tones.some(t=>pitchClassDistance(p,t,12)<.2));target=(chordTones.length?chordTones:ladder).reduce((best,p)=>Math.abs(p-last)<Math.abs(best-last)?p:best);}
    else{const at=ladder.indexOf(nearest(last)),step=this.cell[index]??0;target=ladder[Math.max(0,Math.min(ladder.length-1,at+step))];}
    // Clear of the voices heard, and drawn to a theme: among the ladder's notes a step either way, the cheapest.
    const theme=this.themeAt(clock.tick,beat),{othersFrom,othersTo}=this.others(clock),at=ladder.indexOf(target);
    const options=[at,at-1,at+1].filter(i=>i>=0&&i<ladder.length).map(i=>ladder[i]);
    const cost=p=>(p===target?0:1)+(theme?1.5*this.themeDistance(p,theme.pitch):0)+(this.riffPitch!==null?20*parallelsAgainst([this.riffPitch],[p],othersFrom,othersTo).length:0);
    const pitch=options.sort((a,b)=>cost(a)-cost(b))[0];
    const next=this.pattern.positions[index+1]??this.pattern.positions[0]+this.barTicks(clock),span=Math.max(1,next-clock.tickInBar);
    const sounded=this.tuneOne(pitch),seconds=Math.min(span,beat)*this.secondsPerTick(clock)*.9;
    const phrase=this.phraseNote({pitch:sounded,seconds,at:this.elapsedSeconds(clock),clock,accent:index===0?1:0});
    const written=this.writtenInterval(clock,Math.min(span,beat),{group:'line',replace:true});
    this.playWritten(written,()=>this.audio.sequencerNote?this.audio.sequencerNote(sounded,seconds,this.vl.velocity+(index===0?.06:0),phrase):this.sound(clock,[sounded],seconds,this.vl.velocity,written));
    this.riffPitch=pitch;this.announce(clock,[sounded],'line');
    this.decide({tick:clock.tick,riff:pitch,sounded,space:space.id,rhythm:this.pattern.space,heard:this.pattern.heard,index,...(theme?{theme:theme.pitch}:{})});
  }
}

// Under a home (meterform_clodbot), it hears the home bars in a grouping of its own, laid across the others' most freely
// (bots/lib/modules/grouping-choice.js).
export const GroupedRiffClodbot=GroupingChoice(RiffClodbot,{role:'layer'});
export const riffClodbot=defineBot(
  {
    id: "riff_clodbot", name: "riff_clodbot", status: "native", source: "clodbot",
    category: "melody", midiChannel: 15, outputModes: ["synth", "midi"], pitchContract: "floating-mpe",
    description:
      "A riff following note pools and chord plans: its rhythm chosen from the patterns it hears (the performer's, the drums') by an intended rhythmic dissonance, its notes a cell of steps in the space the heard chord opens, realized in each chord, clear of octaves and fifths with the bass it hears.",
  },
  (...args) => new GroupedRiffClodbot(...args),
);
