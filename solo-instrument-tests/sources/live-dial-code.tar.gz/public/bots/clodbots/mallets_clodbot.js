// mallets_clodbot: a mallet player, the third of the instrument clodbots (research/family-atlas.md F29, mallet bars,
// bells and fixed-pitch percussion; research/MUSEBOTS_WORLD_INSTRUMENTS_CONSTRAINTS_RESEARCH_AND_IMPLEMENTATION_REPORT.md).
// New, not a fork. Taken by 2a from c2's "Percussion beyond the kit", 29 September (SESSIONS.md 04:08).
//
// Its harmony is the band's, as jazzvoicing_clodbot reads it (the chord's guide tones, its fifth, its root where no bass
// is heard); the drummer's principles are the instrument clodbots' (instrument-performer.js): its comp on the meter's
// groups, comp and run as one continuum, a solo's course to a climax, the band's attention, its arrival at the cadence
// on the last downbeat (Closure). What a mallet player adds:
// - **Voicings two hands hold, by construction.** Its chords are chosen among those its mallets can strike together
//   (malletVoicings): four mallets, two a hand (two, one a hand, where it holds two), each hand's two from adjacent bars
//   to about an octave apart, the hands not crossing (shared/performers/mallets.js MALLETS). Voice-led from the last,
//   its hands moving as little as they can. The mallet planner (planMallets) is the reference in its tests, never asked
//   while it plays.
// - **Rolled where a bar would die.** A marimba's or xylophone's bar rings briefly: a chord held longer than it rings is
//   rolled, the two hands alternating at MALLETS.rollHz. A vibraphone's chord rings on under its pedal, and a
//   glockenspiel's rings undamped; neither is rolled.
// - **A vibraphone's pedal and mallets damp.** Under the pedal a bar rings on until the pedal changes (re-pedalled at
//   the comp's next chord, else at the bar line), its run's notes too; a run's note that would clash is stopped by the
//   mallet that struck it as the other hand strikes the next, where that hand is free to (simultaneous dampening, Jones
//   2009; MALLETS_CLODBOT.dampening).
// - **Its runs alternate hands**, a step at a time up and down the scale from its voicing's top, never quicker than
//   its two mallets alternating (MALLETS.strokeSeconds). Around a chord each hand keeps to what the planner's hand can:
//   its mallets recovered and its travel to and from the chord's grip in time (reaches). A run note its hand cannot
//   reach is the other hand's, or left out; a roll ends in time for its hands' next strokes; and a chord changed
//   mid-run is struck by the hands that reach it.
// - **Its bars in the band's tuning** by default (a set built for the piece), so its chords sound as the band tunes
//   them; a spec may ask for a fixed set (`bars: 'fixed'`, twelve to the octave), which has no bar for a pitch between its
//   bars: that pitch is left out of the chord, never rounded, and a tuning plan is declined.
import {defineBot} from '../../framework/index.js';
import {withScoreTime,shiftScoreTime,scoreTimeFields} from '../../shared/score-time.js';
import {dividedBeats} from '../../shared/performers/rhythm-cell.js';
import {JazzVoicingClodbot} from './jazzvoicing_clodbot.js';
import {PerformedTiming} from '../lib/modules/performed-timing.js';
import {HearsAttention} from '../lib/modules/attention.js';
import {InSection} from '../lib/modules/section-member.js';
import {InstrumentPerformer} from '../lib/modules/instrument-performer.js';
import {MALLETS,malletInstrument,barFor,barX,ringOf} from '../../shared/performers/mallets.js';
import {secondsPerTick} from '../../shared/meter-tactus.js';
import {blendLevel,metricalWeight,rankThresholds} from '../../shared/performers/figure-blend.js';
import {modulo} from '../lib/pitch-helpers.js';
import {broughtOut,louderBy} from '../../shared/performers/chord-voicing.js';
import {FAMILIES} from '../../shared/articulation.js';
import {figurePayload,oneTone,oneToneFigure} from '../../shared/performers/figuration.js';

// Its recordings: the University of Iowa's, one preset an instrument (scripts/download-mallet-samples.mjs; c2's choice).
export const MALLETS_BANK='iowaMallets';
export const MALLETS_CLODBOT=Object.freeze({
  // Its built-in voice's gain: the struck bar (the bell family's sine) at about the median bot voice's loudness, as the
  // pianist's is (sample-levels.mjs, 29 September: at .003 it sat 24 dB under every other voice, so its recordings had
  // nothing to be trimmed to).
  voiceGain:.05,
  // The run's notes a felt beat, up to twice as many at a solo's climax (ours).
  perBeat:4,
  // Levels (velocity): a run's, a run's at a solo's peak (ours).
  run:.45,runTop:.85,
  // Where its voicings sit on each instrument: the middle of a voicing near this pitch (ours), weighed against how far
  // its hands move.
  centres:Object.freeze({marimba:62,vibraphone:67,xylophone:79,glockenspiel:91}),
  // What a voicing costs: each semitone its voices move, each 100 mm its hands travel, each semitone its middle lies from
  // the centre, and each semitone it spreads wider than an octave and a half (a comp's voicing kept together; ours).
  cost:Object.freeze({voice:1,travel:.5,register:.25,spread:.5}),
  // The bars a voicing is sought among: this far either side of the centre (semitones).
  reach:14,
  // The note of a chord it brings out (chord-voicing.js broughtOut: its top, or the voice moving under a held top, the
  // line carried from chord to chord), this many dB over the others (the user, 29 September: "these 'voicings' within
  // chords should produce subtle senses of melody from chord to chord"). Authored: no measured value for four mallets was found
  // (7a, 29 September); the nearest measured is a plucked chord's soprano, 3 to 6 dB over its other voices (Freire,
  // Nézio & dos Reis 2014, doi:10.5281/zenodo.850753), whose middle this is.
  lead:4.5,
  // Its ways of playing a note, by the ensemble's character (aesthetic.js; ours). On the marimba and the xylophone, a
  // share of its short notes (the run's, and the comp's off the downbeat) struck dead, the mallet left on the bar: as
  // much as the character is spikier than it is spacious (attack less space, 0 to 1). On the vibraphone, the pedal as
  // deep as the character is spacious (its space; down where none is heard): each note a damped note's length while it
  // is up (under the first step), and longer from there to its own at the bottom, continuously, played as the
  // recordings of the pedal up, half down or down (under a third, under two thirds, above). A dead stroke sounds this
  // long (s), a damped note this long at most.
  articulation:Object.freeze({deadOn:Object.freeze(['marimba','xylophone']),pedalSteps:Object.freeze([1/3,2/3]),deadSeconds:.08,dampedSeconds:.35}),
  // Under a vibraphone's pedal (at its first step or deeper), a run's note stopped by the mallet that struck it as the
  // other hand strikes the next (simultaneous dampening: "the vibraphonist plays a note with one mallet while dampening
  // a different bar with another mallet"; "to add clarity a vibraphonist can dampen notes that are not a part of the chord
  // or that are a half step or whole step away from the final note of a run": Jones 2009, research/kalman-references.md).
  // Which, drawn note by note (ours): a note clashing so (not of the ringing chord's classes, or within `step`
  // semitones of the run's last note) unless the character washes it (its space over its attack), a chord tone as much
  // as the character is spiky (its attack) and unwashed.
  dampening:Object.freeze({step:2}),
});

// The struck bar's velocity curve (articulation.js FAMILIES.bell), in which its brought-out note is louder.
export const BELL_CURVE=Object.freeze({rangeDb:FAMILIES.bell.rangeDb??30,exponent:FAMILIES.bell.velocityExponent??2});

// The voicings its mallets can strike together for a chord's pitch classes `pcs`, every one holding the `required`
// ones: `mallets` notes where it can (fewer where the chord has fewer tones), two a hand at most, each hand's two within
// its span (MALLETS.leastMm to mostMm apart), the hands not crossing; every note a bar of the instrument (on a fixed set,
// a pitch class between its bars has none, so it is left out). -> [{pitches (low to high), hands: {LH, RH}, x: {LH, RH}}].
export function malletVoicings(pcs,required=[],{instrument=malletInstrument(),mallets=4,centre=62,choices=MALLETS,reach=MALLETS_CLODBOT.reach}={}){
  const near=(a,b)=>Math.abs(modulo(a-b+6,12)-6)<=choices.tolerance;
  const tones=[...new Set(pcs.map(Number))],needed=[...new Set(required.map(Number))];
  // Each tone's bars within reach of the centre.
  const [low,high]=instrument.range,bars=[];
  for(let octave=0;octave<=10;octave++)for(const pc of tones){
    const pitch=12*octave+modulo(pc,12);
    if(pitch<Math.max(low,centre-reach)||pitch>Math.min(high,centre+reach))continue;
    const bar=barFor(instrument,pitch,{choices});if(bar!==null)bars.push({pitch:bar,pc});
  }
  bars.sort((a,b)=>a.pitch-b.pitch);
  // The tones its bars sound (on a fixed set, not those between its bars); a mallet a tone, one doubled where there are
  // fewer tones than mallets.
  const sounding=tones.filter(pc=>bars.some(bar=>bar.pc===pc)),perHand=mallets/2,size=Math.min(mallets,sounding.length+(sounding.length<mallets?1:0)),out=[];
  const span=list=>list.length<2?0:barX(list.at(-1),{choices,range:instrument.range})-barX(list[0],{choices,range:instrument.range});
  const walk=(start,chosen)=>{
    if(chosen.length===size){
      const pitches=chosen.map(bar=>bar.pitch);
      if(!needed.every(pc=>chosen.some(bar=>near(bar.pc,pc))))return;
      // Distinct classes: a tone a mallet, as far as the chord's tones go.
      if(new Set(chosen.map(bar=>modulo(bar.pc,12))).size<Math.min(size,sounding.length))return;
      for(let split=Math.max(0,size-perHand);split<=Math.min(perHand,size);split++){
        const left=pitches.slice(0,split),right=pitches.slice(split);
        if([left,right].some(list=>list.length>1&&(span(list)<choices.leastMm-1e-9||span(list)>choices.mostMm+1e-9)))continue;
        if(left.length&&right.length&&barX(left.at(-1),{choices,range:instrument.range})>=barX(right[0],{choices,range:instrument.range})-choices.leastMm+1e-9)continue;
        const centreOf=list=>list.length?(barX(list[0],{choices,range:instrument.range})+barX(list.at(-1),{choices,range:instrument.range}))/2:null;
        out.push({pitches,hands:{LH:left,RH:right},x:{LH:centreOf(left),RH:centreOf(right)}});
        return;
      }
      return;
    }
    for(let k=start;k<bars.length;k++){if(chosen.length&&bars[k].pitch-chosen.at(-1).pitch<1-choices.tolerance)continue;walk(k+1,[...chosen,bars[k]])}
  };
  walk(0,[]);
  return out;
}
// The voicing to strike next: the one whose voices move least from the last's, its hands travelling least, its middle
// nearest the centre (MALLETS_CLODBOT.cost).
export function nextVoicing(voicings,previous=null,{centre=62,choices=MALLETS_CLODBOT}={}){
  const middle=pitches=>(Math.min(...pitches)+Math.max(...pitches))/2;
  const moved=voicing=>{if(!previous)return 0;const a=previous.pitches,b=voicing.pitches,n=Math.min(a.length,b.length);let sum=0;for(let k=0;k<n;k++)sum+=Math.abs(a[a.length-1-k]-b[b.length-1-k]);return sum};
  const travel=voicing=>previous?['LH','RH'].reduce((sum,hand)=>sum+(previous.x[hand]!=null&&voicing.x[hand]!=null?Math.abs(voicing.x[hand]-previous.x[hand]):0),0)/100:0;
  const spread=voicing=>Math.max(0,Math.max(...voicing.pitches)-Math.min(...voicing.pitches)-18);
  // (And its chord reading's cost to its player, where it was voiced from one: chord-readings.js.)
  const cost=voicing=>choices.cost.voice*moved(voicing)+choices.cost.travel*travel(voicing)+choices.cost.register*Math.abs(middle(voicing.pitches)-centre)+choices.cost.spread*spread(voicing)+(voicing.readingCost??0);
  return voicings.reduce((best,voicing)=>!best||cost(voicing)<cost(best)-1e-9?voicing:best,null);
}

export class MalletsClodbot extends InstrumentPerformer(JazzVoicingClodbot,{name:'mallets_clodbot',kinds:['comp','run']}) {
  constructor(send,audio,settings={}){
    super(send,audio,settings);
    const kind=settings?.instrument??'marimba';
    if(!MALLETS.instruments[kind])throw new RangeError(`settings.instrument is one of ${Object.keys(MALLETS.instruments).join(', ')}`);
    const mallets=settings?.mallets??4;if(mallets!==2&&mallets!==4)throw new RangeError('settings.mallets is 2 or 4');
    const bars=settings?.bars??'band';if(bars!=='band'&&bars!=='fixed')throw new RangeError('settings.bars is band or fixed');
    // (How far its rolls answer the rolls and tremolos it hears, settings.inspiration, 0 to 1; else drawn once a piece.)
    if(settings?.inspiration!=null&&!(Number(settings.inspiration)>=0&&Number(settings.inspiration)<=1))throw new RangeError('A mallet player\'s inspiration is a share from 0 to 1');
    this.inspirationAsked=settings?.inspiration!=null?Number(settings.inspiration):null;
    this.instrument=malletInstrument({kind,bars});this.mallets=mallets;this.centre=MALLETS_CLODBOT.centres[kind];
    this.bars=[];this.runPlan=null;this.voiced=null;this.strokes=[];
    // Each hand's strokes, struck and planned ({at, x (mm), from, free}, s of its own time), as the planner reads a hand.
    this.handStrokes={LH:[],RH:[]};
    // On samples, its instrument's recordings (the bank's preset of its name: scripts/download-mallet-samples.mjs), where
    // another was loaded for it; a render waits for them (`loading`).
    if(this.audio?.mode==='samples'&&typeof this.audio.loadSampleBank==='function'&&this.audio.samplePreset!==kind)
      this.loading=this.audio.loadSampleBank(MALLETS_BANK,{preset:kind}).catch(error=>this.decide({samples:{preset:kind,failed:String(error?.message??error)}}));
  }
  // Its time now (s).
  now(clock){return this.elapsedSeconds?.(clock)??(Number(clock?.tick)||0)*secondsPerTick(clock)}
  // How far its chords lean toward a roll beyond its bars' need: its inspiration (asked, else drawn once a piece) times how
  // near the last figure it heard is to the one-tone corner (figuration.js oneTone: a drummer's roll, a section's
  // tremolo); 0 on an instrument it does not roll.
  rollLean(){
    if(!this.instrument.rolls||!this.heardFigure)return 0;
    return (this.inspirationAsked??(this.inspirationDrawn??=this.random('inspiration')()))*oneTone(this.heardFigure);
  }
  // Its roll's speed (strokes a second, both hands): its own (MALLETS.rollHz), moved toward the last roll or tremolo it
  // heard -- that figure's rate of its own quickest, two hands each a stroke every MALLETS.strokeSeconds -- as far as it
  // leans toward it (rollLean), never quicker than its hands.
  rollHz(){
    const own=MALLETS.rollHz,quickest=2/MALLETS.strokeSeconds,lean=this.rollLean(),heard=Number(this.heardFigure?.rate);
    return Number.isFinite(heard)&&heard>0&&lean>0?Math.min(quickest,own+(heard*quickest-own)*lean):own;
  }
  // The figures the others say, for its rolls to answer.
  onMessage(message){super.onMessage?.(message);
    if(message?.address==='/broadcast/figure'&&message.args?.[0]&&String(message.args[0].voice)!==String(this.instanceId??'mallets_clodbot'))this.heardFigure=message.args[0]}
  // The share of its short notes it strikes dead: a dry, spiky character's (attack less space), on the instruments that
  // have dead strokes; none where no character is heard.
  deadShare(){
    const character=this.character;if(!character||!MALLETS_CLODBOT.articulation.deadOn.includes(this.instrument.kind))return 0;
    return Math.max(0,Math.min(1,(character.attack??.5)-(character.space??.5)));
  }
  // A vibraphone's pedal depth: its character's space (0 up, 1 down); down where no character is heard, or on another
  // instrument (which has no pedal to lift).
  pedalDepth(){return this.instrument.kind==='vibraphone'&&this.character?Math.max(0,Math.min(1,this.character.space??.5)):1}
  // A note's way of playing: on the vibraphone, its pedal's (damped, short, or null: down); elsewhere a short note drawn
  // dead at the dead share (`key`, the draw's), else null (plain).
  articulationOf(key,{short=true}={}){
    if(this.instrument.kind==='vibraphone'){const [up,half]=MALLETS_CLODBOT.articulation.pedalSteps,depth=this.pedalDepth();return depth<up?'damped':depth<half?'short':null}
    const share=this.deadShare();return short&&share>0&&this.random(`dead:${key}`)()<share?'dead':null;
  }
  // How long a note of `seconds` sounds, played so: a dead stroke's short length; a vibraphone's a damped note's while
  // its pedal is up (the damper on the bars below the first step), and from there longer as the pedal goes down, to its
  // ring under the pedal down at the bottom (`ring`: pedalRing), continuously; stopped sooner where its mallet damps it
  // (`damp`, seconds after its stroke).
  sounding(seconds,articulation,{ring=seconds,damp=null}={}){
    const choices=MALLETS_CLODBOT.articulation;
    if(articulation==='dead')return Math.min(seconds,choices.deadSeconds);
    if(this.instrument.kind!=='vibraphone')return seconds;
    const least=Math.min(seconds,choices.dampedSeconds),up=choices.pedalSteps[0],open=Math.max(0,Math.min(1,(this.pedalDepth()-up)/(1-up)));
    const pedalled=least+(ring-least)*open;
    return damp===null?pedalled:Math.min(pedalled,damp);
  }
  // How long a vibraphone's bar rings under the pedal down, struck `at` seconds into the bar: until the pedal changes
  // (re-pedalled at the next chord the comp strikes in the bar, else at the bar line; ours), within its bar's ring
  // (ringOf); `to`, where given, its own end (a final chord's, the pedal held to it). (A chord the band changes to
  // between the comp's hits is struck under the pedal as it is.)
  pedalRing(clock,pitch,at,{to=null}={}){
    const spt=secondsPerTick(clock),span=clock.meter.pulsesPerBar;
    // (The bar's comp planned as the comp plans it, where its first chord comes before its hits are asked for.)
    if(this.comp?.bar!==clock.bar)this.rearticulates(clock);
    const struck=this.comp.hits.filter(hit=>hit*spt>at+1e-9&&this.compLevelAt({...clock,tickInBar:hit})>0);
    return to??Math.min(ringOf(this.instrument,pitch),Math.min(span,...struck)*spt-at);
  }
  // A stroke's recovery: a dead stroke's mallet held on the bar (MALLETS.deadSeconds), else a plain stroke's.
  recovery(articulation){return articulation==='dead'?MALLETS.deadSeconds:MALLETS.strokeSeconds}
  // Whether a hand strikes where `x` is (mm) at `at` (s), as the planner reads a hand (planMallets): its mallets free
  // from its stroke before, and free again for its stroke after (struck, or planned: a run's notes, and `extra`, a chord
  // the run is planned around), its travel to and from them within MALLETS.handMmPerSecond of the time it has (from
  // when it left its bars: its stroke, a roll's end). `from` and `free` are this stroke's.
  reaches(hand,x,at,{from=at,free=at+MALLETS.strokeSeconds,extra=[]}={}){
    return [...this.handStrokes[hand],...extra.filter(stroke=>stroke.hand===hand)].every(stroke=>{
      if(stroke.at<=at-1e-9)return at>=stroke.free-1e-9&&Math.abs(x-stroke.x)<=MALLETS.handMmPerSecond*Math.max(0,at-stroke.from)+1e-9;
      if(stroke.at>=at+1e-9)return stroke.at>=free-1e-9&&Math.abs(stroke.x-x)<=MALLETS.handMmPerSecond*Math.max(0,stroke.at-from)+1e-9;
      return false;
    });
  }
  // A hand's stroke kept (struck now, or a run's note planned ahead), and each hand's strokes long past at `now` let go.
  stroke(hand,at,x,{from=at,free=at+MALLETS.strokeSeconds}={}){this.handStrokes[hand].push({at,x,from,free});this.handStrokes[hand].sort((a,b)=>a.at-b.at)}
  forget(now){for(const hand of ['LH','RH'])this.handStrokes[hand]=this.handStrokes[hand].filter(stroke=>stroke.free>now-2)}
  // A chord on a change: its guide tones (third, seventh), its fifth, its root where no bass is heard, among the voicings
  // its mallets can strike, voice-led from the last, and its hands can reach from the run around it (where none can, the
  // nearest, struck by the hands that reach it). Struck again as it is between changes.
  attack(clock,{change}){
    const chord=this.chord;if(!chord)return;
    // (Its last chord, its arrival at the cadence, as long as any it strikes on its beat: rolled where its bars would die
    // before it ends, struck and left to ring where they would not -- never held to the stop.)
    const spt=this.secondsPerTick(clock),beat=this.beatTicks(clock),offbeat=clock.tickInBar%beat!==0;
    const seconds=(offbeat?.6:1.4)*beat*spt;
    if(!change&&this.voiced){this.sound(clock,this.voiced,seconds,this.vl.velocity-(offbeat?.02:.06));this.announce(clock,this.voiced.pitches);return}
    // (Every reading of the chord its mallets can strike (chord-readings.js: as heard, common practice's, jazz's, a
    // power chord's, a colourist's), each in the object's own tuning -- a microtonal pool's third its third, never a named
    // chord's rounded one -- each dearer as its taste for the reading is less; on a fixed set a tone between its bars left
    // out, never required.)
    const onBars=pc=>!this.instrument.fixed||Math.abs(pc-Math.round(pc))<=MALLETS.tolerance,readings=this.readingsOf(clock),at=this.now(clock);
    const options=readings.flatMap(reading=>malletVoicings(reading.pcs.filter(onBars),reading.required.filter(onBars),{instrument:this.instrument,mallets:this.mallets,centre:this.centre})
      .map(voicing=>({...voicing,reading:reading.id,readingCost:reading.cost})));
    const reachable=options.filter(voicing=>['LH','RH'].every(hand=>!voicing.hands[hand].length||this.reaches(hand,voicing.x[hand],at)));
    const voicing=nextVoicing(reachable.length?reachable:options,this.voiced,{centre:this.centre});
    if(!voicing){this.decide({tick:clock.tick,noVoicing:readings.map(reading=>reading.id)});return}
    this.voiced=voicing;this.voicing=voicing.pitches;this.lastReading=voicing.reading;
    this.sound(clock,voicing,seconds,this.vl.velocity);this.announce(clock,voicing.pitches);
    this.decide({tick:clock.tick,change:true,chord:`${chord.root}:${chord.quality}`,reading:voicing.reading,voicing:{pitches:voicing.pitches,LH:voicing.hands.LH,RH:voicing.hands.RH}});
  }
  // Struck together, at the level the fillness leaves the comp (compLevelAt); rolled where the instrument's bars would
  // die before the chord ends (the hands alternating at MALLETS.rollHz), the roll ending in time for each hand to reach
  // its next stroke (the run's next note, the comp's next chord or the next bar's first), and struck once where that
  // leaves no roll. In a bar it runs, the chord is let go before the run's next note, and a hand that cannot reach its
  // bars between the run's notes leaves them out (a chord changed mid-run struck by the hand free for it).
  sound(clock,voicing,seconds,velocity=this.vl.velocity){
    const compLevel=this.compLevelAt(clock);if(!(compLevel>0))return;
    if((clock.tickInBar??0)===0)this.planRun(clock);
    const spt=secondsPerTick(clock),tick=clock.tickInBar??0,now=tick*spt,at=this.now(clock),final=this.closing?.phase==='final';
    this.forget(at);
    const next=this.runPlan?.bar===clock.bar?this.runPlan.notes.map(note=>note.start).find(start=>start>now+1e-9):undefined;
    const held=next===undefined?seconds:Math.max(.05,Math.min(seconds,next-now-MALLETS.strokeSeconds));
    const level=Math.max(0,Math.min(1,velocity*compLevel)),used=['LH','RH'].filter(hand=>voicing.hands[hand].length);
    const hit=[...(this.comp?.bar===clock.bar?this.comp.hits:[]),clock.meter.pulsesPerBar].find(value=>value>tick);
    const rolling=Math.min(held,...used.map(hand=>Math.min(...[this.handStrokes[hand].find(stroke=>stroke.at>at+1e-9),{at:at+(hit-tick)*spt,x:voicing.x[hand]}]
      .filter(Boolean).map(stroke=>stroke.at-at-Math.max(MALLETS.strokeSeconds,Math.abs(stroke.x-voicing.x[hand])/MALLETS.handMmPerSecond)))));
    // (Rolled where its bars would die before the chord ends -- and, as far as it leans toward the rolls it hears, where
    // they would ring that much less long: at a full lean, any chord its hands have room to roll.)
    const lean=this.rollLean(),rollHz=this.rollHz();
    const rolled=this.instrument.rolls&&voicing.pitches.some(pitch=>held>ringOf(this.instrument,pitch)*(1-lean)+1e-9)&&rolling>=2/rollHz-1e-9
      &&used.every(hand=>this.reaches(hand,voicing.x[hand],at,{from:at+rolling,free:at+rolling}));
    const articulation=rolled?null:this.articulationOf(`comp:${clock.bar}:${tick}`,{short:tick!==0}),recovery=this.recovery(articulation);
    const hands=rolled?used:used.filter(hand=>this.reaches(hand,voicing.x[hand],at,{free:at+recovery}));
    if(!hands.length){this.decide({tick:clock.tick,chordLeftOut:voicing.pitches,because:'neither hand reaches it between the run\'s notes'});return}
    if(hands.length<used.length)this.decide({tick:clock.tick,handLeftOut:used.find(hand=>!hands.includes(hand)),because:'it cannot reach its bars between the run\'s notes'});
    const pitches=hands.flatMap(hand=>voicing.hands[hand]);
    // The note it brings out, MALLETS_CLODBOT.lead dB over the others, rolled or struck.
    const sounding=[...(rolled?voicing.pitches:pitches)].sort((a,b)=>a-b);
    const line=sounding.length>1?sounding[broughtOut(sounding,this.previousVoicing,this.previousLine,{bass:this.bassHeard(clock)===null})]:null;
    const loud=louderBy(level,MALLETS_CLODBOT.lead,BELL_CURVE),levelOf=pitch=>line!==null&&Math.abs(pitch-line)<1e-9?loud:level;
    withScoreTime(this.audio,this.compInterval(clock),()=>{if(rolled){
      // The hands in turn, a stroke each 1/rollHz, the left's first, through the roll; each stroke rings to the next of
      // its hand, the last to the chord's end. Each bar is one note, rolled (the engine's roll: its strokes its
      // realization), as a score prints it.
      const step=1/rollHz,strokes=Math.max(2,Math.floor(rolling/step)),both=voicing.hands.LH.length&&voicing.hands.RH.length;
      for(const hand of ['LH','RH'])for(const pitch of voicing.hands[hand]){
        const turns=Array.from({length:strokes},(_,k)=>k).filter(k=>!both||(k%2?'RH':'LH')===hand);
        if(turns.length)this.rollBar(pitch,held,levelOf(pitch)*(turns[0]?.8:1),turns.map(k=>(k-turns[0])*step),turns[0]*step,{ring:2*step,later:turns[0]?1:.8});
      }
      // (Said for the others, once a bar it rolls in: the one-tone corner's figure, its hands' roll a share of their
      // quickest, each a stroke every MALLETS.strokeSeconds -- figuration.js oneToneFigure.)
      if(this.rollSaid!==clock.bar){this.rollSaid=clock.bar;this.broadcast?.('figure',[figurePayload(this.instanceId??'mallets_clodbot',oneToneFigure(rollHz*MALLETS.strokeSeconds/2),clock.bar)])}
    }else for(const pitch of pitches)this.strike(pitch,held,levelOf(pitch),0,articulation,this.instrument.pedal?{ring:this.pedalRing(clock,pitch,now,{to:final?seconds:null})}:{});
    });
    this.previousVoicing=sounding;this.previousLine=line;
    for(const hand of hands)this.stroke(hand,at,voicing.x[hand],rolled?{from:at+rolling,free:at+rolling}:{free:at+recovery});
    this.count(clock,'comp');
    this.strokes.push({bar:clock.bar,tick,rolled,pitches:rolled?[...voicing.pitches]:pitches,...(articulation?{articulation}:{}),...(line===null?{}:{line,level:+level.toFixed(4),lead:+loud.toFixed(4)})});if(this.strokes.length>64)this.strokes.shift();
  }
  // A bar struck: its instrument's recording (samples: the bank's preset for it, its one dynamic given the others by
  // level and brightness), the synthesized struck bar (the bell family's FM), or MIDI to an instrument outside.
  strike(pitch,seconds,asked,offset,articulation=null,pedalled={},musical={}){
    const velocity=this.plannedVelocity(asked,'bell');
    const length=this.sounding(seconds,articulation,pedalled);
    if(this.audio?.mode==='midi'){this.audio.midiNote?.(pitch,length,velocity,undefined,offset,{instrument:'bell',profile:'bell',...musical});return}
    if(this.audio?.mode==='samples'&&typeof this.audio.samplePitch==='function'){this.audio.samplePitch(pitch,offset,this.audio.sampleLevel?.(.565,velocity,'bell')??.565*velocity,length,velocity,{...(articulation?{articulation}:{}),...musical,stroke:musical});return}
    this.audio?.voice?.(pitch,length,MALLETS_CLODBOT.voiceGain,'sine',offset,{instrument:'bell',profile:'bell',velocity,...musical});
  }
  // A bar rolled from `at` to the chord's end (`held` from its start): its strokes at `strokes` seconds after its first,
  // as one note (audio.js roll); where an engine has no roll, stroke by stroke.
  rollBar(pitch,held,velocity,strokes,at,{ring,later}){
    if(typeof this.audio?.roll==='function'){this.audio.roll(pitch,held-at,MALLETS_CLODBOT.voiceGain,'sine',at,{instrument:'bell',profile:'bell',velocity},{strokes,ring,later});return}
    strokes.forEach((after,k)=>this.strike(pitch,k?Math.min(ring,held-at-after):held-at-after,velocity*(k?later:1),at+after,null,{},
      {technique:'tremolo',...(k?{captured:false}:{})}));
  }
  everyTick(clock){
    super.everyTick?.(clock);
    if((clock.tickInBar??0)===0)this.planRun(clock);
  }
  // The run, planned once at a bar's start where the fillness asks for one: single strokes, the hands in turn, a step at
  // a time along the scale's bars from the voicing's top, turning back at the reach's edge; its notes at the felt beats'
  // subdivisions but near a chord (faster at a solo's climax, never quicker than two mallets alternating),
  // each at the level the fillness gives it, within the band's attention's allowance.
  planRun(clock){
    if(this.runPlan?.bar===clock.bar)return;
    this.runPlan={bar:clock.bar,notes:[]};
    if(!this.chord||!this.voiced)return;
    const fillness=this.fillnessOf(clock)??0,solo=this.soloIntensity(clock);if(!(fillness>0)&&solo===null)return;
    const spt=secondsPerTick(clock),span=clock.meter.pulsesPerBar,felt=this.felt(clock),intensity=solo??0;
    const shortest=Math.min(...felt.map(beat=>beat.length))*spt,strokes=Math.max(1,Math.floor(shortest/(MALLETS.strokeSeconds/2)));
    const perBeat=Math.min(strokes,Math.round(MALLETS_CLODBOT.perBeat*(1+intensity)));
    // A chord takes both hands, so no run note falls within a stroke's recovery of one, nor of the bar's end (the next
    // bar's first chord, and its run beginning again with the right hand).
    const busy=[...(this.comp?.bar===clock.bar?this.comp.hits:[]),span];
    const positions=dividedBeats(felt,perBeat)
      .filter(({at})=>busy.every(hit=>Math.abs(hit-at)*spt>=MALLETS.strokeSeconds-1e-9));
    // The scale's bars within reach, low to high (on a fixed set, those it has).
    const tuned=pc=>this.objectTuned?.(pc)??pc;
    const scale=[...new Set((this.collection?.()??this.scaleFor?.(this.poolPcs??[])??[]).map(Number).map(tuned))];
    const steps=this.runSteps(scale,{grid:Array.from({length:12},(_,k)=>tuned(k)),collection:Boolean(this.collection?.()),draw:this.random(`runSteps:${clock.bar}`)()});
    const [low,high]=this.instrument.range,under=[];
    for(let octave=0;octave<=10;octave++)for(const pc of steps){const pitch=12*octave+modulo(pc,12);if(pitch<Math.max(low,this.centre-MALLETS_CLODBOT.reach)||pitch>Math.min(high,this.centre+MALLETS_CLODBOT.reach))continue;const bar=barFor(this.instrument,pitch);if(bar!==null)under.push(bar)}
    under.sort((a,b)=>a-b);if(under.length<2)return;
    const top=Math.max(...this.voiced.pitches),start=Math.max(0,under.findIndex(pitch=>pitch>=top)),last=under.length-1;
    const path=positions.map((_,k)=>{const period=2*last,phase=(start+k)%period;return under[phase<=last?phase:period-phase]});
    const u=this.random(`run:${clock.bar}`),items=positions.map(({at,scoreTime},k)=>({id:`run${k}`,at,scoreTime,weight:metricalWeight(at,{beatStarts:felt.map(beat=>beat.start),span}),position:at/span,u:u()}));
    const thresholds=rankThresholds(items,{order:this.fillOrder});
    const notes=items.map((item,k)=>({scoreTime:shiftScoreTime(item.scoreTime,clock.tick-(clock.tickInBar??0),{axis:'ensemble'}),pitch:path[k],hand:k%2?'LH':'RH',start:item.at*spt,end:(item.at+span/(felt.length*perBeat)*.9)*spt,
      level:blendLevel(thresholds.get(item.id),this.fillnessOf(clock,Math.min(span-1e-9,item.at))??0,{entering:true})})).filter(note=>note.level>0);
    // Each note where its hand reaches it (reaches): from the strokes before the bar, and to and from the chords the comp
    // strikes in it and the next bar's first, struck with this voicing where its hands hold it. Where its hand cannot and
    // the other can, the other's (a hand struck twice running, as a player sticks a run round a chord); else left out.
    const barStart=this.now(clock);this.forget(barStart);
    const chords=[...(this.comp?.bar===clock.bar?this.comp.hits:[]),span].flatMap(hit=>['LH','RH']
      .filter(hand=>this.voiced.hands[hand].length).map(hand=>({hand,at:barStart+hit*spt,x:this.voiced.x[hand],from:barStart+hit*spt,free:barStart+hit*spt+MALLETS.strokeSeconds})));
    const kept=[],range=this.instrument.range;
    for(const [k,note] of notes.entries()){
      note.articulation=this.articulationOf(`run:${clock.bar}:${k}`);
      const at=barStart+note.start,x=barX(note.pitch,{range}),free=at+this.recovery(note.articulation);
      const hand=[note.hand,note.hand==='RH'?'LH':'RH'].find(each=>this.reaches(each,x,at,{free,extra:[...chords,...kept]}));
      if(!hand)continue;
      note.hand=hand;kept.push({hand,at,x,from:at,free,note});
    }
    const left=notes.length-kept.length;notes.splice(0,notes.length,...kept.map(entry=>entry.note));
    // Under a vibraphone's pedal, a note stopped by the mallet that struck it as the other hand strikes the next
    // (MALLETS_CLODBOT.dampening): only where that hand has recovered by then, and reaches its next stroke after the
    // press (MALLETS.dampSeconds), its hand at the bar till then.
    let damped=0;
    if(this.instrument.pedal&&this.pedalDepth()>=MALLETS_CLODBOT.articulation.pedalSteps[0]&&kept.length>1){
      const attack=this.character?.attack??.5,wash=Math.max(0,(this.character?.space??.5)-attack),draw=this.random(`damp:${clock.bar}`);
      const ringing=this.voiced.pitches.map(pitch=>modulo(pitch,12)),arrival=kept.at(-1).note.pitch;
      const clashes=pitch=>!ringing.some(pc=>Math.abs(modulo(pitch-pc+6,12)-6)<=MALLETS.tolerance)
        ||Math.abs(pitch-arrival)>MALLETS.tolerance&&Math.abs(pitch-arrival)<=MALLETS_CLODBOT.dampening.step+1e-9;
      for(let k=0;k+1<kept.length;k++){
        const entry=kept[k],next=kept[k+1],u=draw(),press=next.at,released=press+MALLETS.dampSeconds;
        if(next.hand===entry.hand||press<entry.free-1e-9)continue;
        const later=[...this.handStrokes[entry.hand],...[...chords,...kept].filter(stroke=>stroke.hand===entry.hand)].filter(stroke=>stroke.at>entry.at+1e-9).sort((a,b)=>a.at-b.at)[0];
        if(later&&(later.at<released-1e-9||Math.abs(later.x-entry.x)>MALLETS.handMmPerSecond*(later.at-released)+1e-9))continue;
        if(u>=(clashes(entry.note.pitch)?1:attack)*(1-wash))continue;
        entry.note.damp=press-barStart;entry.from=entry.free=released;damped++;
      }
    }
    for(const entry of kept)this.stroke(entry.hand,entry.at,entry.x,{from:entry.from,free:entry.free});
    const level=MALLETS_CLODBOT.run+(MALLETS_CLODBOT.runTop-MALLETS_CLODBOT.run)*intensity;
    const {heard,claim,givenBackDb}=this.licensed(clock,notes.map(note=>({at:note.start,velocity:level*note.level})));
    for(const note of notes)withScoreTime(this.audio,note,()=>this.strike(note.pitch,note.end-note.start,this.softer(level*note.level,givenBackDb),note.start,note.articulation,
      this.instrument.pedal?{ring:this.pedalRing(clock,note.pitch,note.start),damp:note.damp===undefined?null:note.damp-note.start}:{}));
    this.runPlan={bar:clock.bar,notes:notes.map(note=>({...scoreTimeFields(note),pitch:note.pitch,hand:note.hand,start:note.start,end:note.end,...(note.articulation?{articulation:note.articulation}:{}),...(note.damp===undefined?{}:{damp:note.damp})}))};
    this.count(clock,'run',notes.length);
    this.bars.push({bar:clock.bar,fillness:+fillness.toFixed(3),run:notes.length,of:items.length,perBeat,...(left?{unreached:left}:{}),...(damped?{damped}:{}),...(solo===null?{}:{intensity:+intensity.toFixed(3)}),
      ...(heard?{attention:{claimDb:claim?+claim.claimDb.toFixed(2):null,allowanceDb:+heard.allowanceDb.toFixed(2),soloing:heard.soloing,givenBackDb:+givenBackDb.toFixed(2)}}:{})});
    if(this.bars.length>64)this.bars.shift();
  }
}

export const PerformedMallets=HearsAttention(PerformedTiming(MalletsClodbot,{instrument:'comping'}));
// Seated in a percussion section (settings.seat, settings.kind 'percussion'), it rests where its section's conductor
// rests it (bots/lib/modules/section-member.js).
export const SeatedMallets=InSection(PerformedMallets);
export const malletsClodbot=defineBot(
  {
    id: "mallets_clodbot",orchestral:true, name: "mallets_clodbot", status: "native", source: "clodbot",
    category: "harmony", midiChannel: 6, performanceType: "polyphonic", outputModes: ["synth", "samples", "midi"],
    sampleBank: MALLETS_BANK,
    // Its bars in the band's tuning unless a spec asks for a fixed set (bars: 'fixed'), which takes no tuning plan.
    pitchContract: "floating-mpe", planningCapabilities: Object.freeze({tuning: true}),
    specSettings: Object.freeze(["fillness", "fillOrder", "density", "instrument", "mallets", "bars", "chromatic", "seat", "size", "kind", "section", "arrival", "inspiration"]),
    description:
      "A mallet player (marimba, vibraphone, xylophone or glockenspiel) whose hands play only what a mallet player's can, by construction: the band's harmony (its guide tones, fifth, and root where no bass is heard) in voicings two hands hold with four mallets, voice-led from the last, rolled where a bar would die before the chord ends, a vibraphone's held by its pedal; its runs alternating hands, never quicker than its mallets; comp and run as one continuum, a solo's course, and the band's attention.",
  },
  (...args) => new SeatedMallets(...args),
);
