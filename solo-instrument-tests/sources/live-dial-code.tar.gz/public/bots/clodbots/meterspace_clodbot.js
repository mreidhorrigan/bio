// meterspace_clodbot: meterform_clodbot's fork, whose home moves through the space of meters (shared/meter-space.js)
// and which modulates parts apart. The user, 28 September 2026: "don't hardcode the meters. Implement them using a
// forked bot." "The point is that, to the extent possible, everything must be interpolable." "The purpose of this
// forked bot can, for now, to be mainly to help with testing; but, subject to interpolability, it might become formally
// important in ensembles eventually." What interpolable means: "A parameter or set of parameters is interpolable when
// intermediate states exist between all the their possible states ... but in actual music, parameters can and should
// jump or have strong discontinuities sometimes." And: "we also need metric modulations, including multiple
// simultaneous metric modulations across different parts; make sure the system has capability for this".
//
// It keeps the base's home bars, grouping dissonances and metric modulations, each within a home, and adds:
// - Its home moves. Where a phrase of the home has been heard, it may take another: a meter drawn from anywhere in the
//   space (drawMeter: numerators to 40, power-of-two and irrational denominators, groupings of its own, the talas'
//   cycles) where it is felt at the tempo it takes (felt-tempo.js; settings.meterSelection 'score-selection-v2' draws from
//   the research catalog's intended readings instead), or a state between two meters at a fraction drawn between them
//   (interpolateMeter).
//   A jump or a state between, as it draws them: never a walk by small steps.
// - Its first home is its own draw (settings.opening 'draw'), unless it is told to keep the piece's ('home').
// - Across a move the notated note keeps its length (an eighth stays an eighth, a twelfth is a triplet eighth), the
//   tempo folded by octaves into the clocks' range where it must be (a 2:1 modulation then, which its decision says).
// - Its metric modulations are the base's: every ratio whose bars fit and whose tempo the clocks play.
// - It modulates parts apart (/agent/stream, framework/agent.js). Now and then, over a home, up to three of the sounding
//   parts it has heard announce themselves are each told a stream of their own: a meter from the space whose beat is
//   another whole number of the ensemble's ticks, so each part has its own tempo relation to the ensemble, several at
//   once. Each is told in the same breath to come home where its cycle and the home's bar next begin together, and
//   the home moves only once every part is home.
// - A part's relation may be any ratio (7a, 28 September; shared/part-time-map.js): held at p:q, or taken there and
//   back by glides, an accelerando or ritardando away, a hold, and the reverse home, each glide landing where its bar
//   and the home's meet (settings.relations 'any'; 'grain' keeps to the relations the ensemble's grain allows).
import {defineBot} from '../../framework/index.js';
import {unitRandom} from '../../shared/stochastic.js';
import {Rational} from '../../transcript/rational.js';
import {tempoRange} from '../../shared/tempo-range.js';
import {drawScoreMeter,metricReadingFor,readingClockWindow} from '../../shared/meter-reading.js';
import {isFeltMeter,FELT_TEMPO} from '../../shared/felt-tempo.js';
import {secondsPerTick} from '../../shared/meter-tactus.js';
import {interpolateMeter,METER_SPACE,drawMeter,TALAS} from '../../shared/meter-space.js';
import {RHYTHM_VOCABULARY,meterOfTala} from '../../shared/rhythm-vocabulary.js';
import {MeterFormClodbot,METER_FORM} from './meterform_clodbot.js';
import {bandPhraseBars,bandMeter} from '../../shared/opening-time.js';

// ---- The space ------------------------------------------------------------------------------------------------------
// Where it draws meters from, and how (shared/meter-space.js, where the piece's opening draws its meter too).
export {METER_SPACE,drawMeter} from '../../shared/meter-space.js';

// Its choices over the space (ours).
export const METER_SPACE_FORM=Object.freeze({
  moves:.5,                  // of a home's phrase ends, the share at which the home moves
  between:.5,                // of its moves, the share that take a state between two meters rather than a meter itself
  partStreams:.35,           // of a home's phrases, the share in which parts are modulated apart
  streamsAtMost:3,           // parts modulated apart at once
  barSeconds:METER_SPACE.barSeconds,   // a home's bar, in seconds at its tempo (longer bars: the base's sections)
  phraseSeconds:8,           // a home's phrase, about (its phraseBars: 1 to 8)
  tickSeconds:.3,            // a home's tick at most this long, so that its grain leaves the band figures to play
  pulsesPerBarAtMost:1024,   // a home's ticks a bar
  numeratorAtMost:128,       // and its units (a state between two long bars may have many)
  betweens:9,                // the fractions between two meters it considers (tenths), of which it takes one that fits
  // A part's tempo relation to the ensemble: its beat's rate over the ensemble's, from 1:4 to 4:1, a whole number of the
  // ensemble's ticks its beat; the smaller integers likelier.
  relation:Object.freeze([1/4,4]),
  // Any ratio's terms at most this (settings.relations 'any'): 5:4, 7:5, 3:2 and the like, held or glided to.
  ratioTermsAtMost:7,
  awayHomeBars:Object.freeze([2,8]),  // a part away for at least, and at most, this many home bars
  // Ratios drawn between the base's for its metric modulations, besides the base's own: this many, their denominators
  // bounded so that a home bars still hold b modulated bars exactly.

});

const weighted=(list,random)=>{let draw=random()*list.reduce((sum,[,weight])=>sum+weight,0);for(const [value,weight] of list){draw-=weight;if(draw<=0)return value}return list.at(-1)[0]};
const gcd=(a,b)=>{while(b)[a,b]=[b,a%b];return a};
const lcm=(a,b)=>a/gcd(a,b)*b;
// A bar's seconds at `bpm` (the clock's tempo counts the meter's own note: shared/tempo-display.js).
const barSeconds=(meter,bpm)=>meter.numerator*60/bpm;
// The tempo that keeps the notated note's length from one meter to another, folded by octaves into the new one's range:
// {bpm, octaves} (octaves the fold, a 2:1 modulation for each).
export function keptNoteTempo(bpm,from,to){
  const [low,high]=tempoRange(to);let value=bpm*to.denominator/from.denominator,octaves=0;
  while(value>high&&value/2>=low){value/=2;octaves--}
  while(value<low&&value*2<=high){value*=2;octaves++}
  return {bpm:Math.max(low,Math.min(high,value)),octaves};
}
const sameBar=(a,b)=>a&&b&&a.tempoUnit===b.tempoUnit&&JSON.stringify(a.metricReading)===JSON.stringify(b.metricReading)&&a.numerator===b.numerator&&a.denominator===b.denominator&&(a.groups??[]).join('+')===(b.groups??[]).join('+')&&(a.subdivision??bandMeter().subdivision)===(b.subdivision??bandMeter().subdivision);
// (Another bar, not the same one on another grain: the base proposes a bar that differs in its length or groups.)
const sameShape=(a,b)=>a.numerator===b.numerator&&a.denominator===b.denominator&&(a.groups??[]).join('+')===(b.groups??[]).join('+');

export class MeterSpaceClodbot extends MeterFormClodbot{
  constructor(send,audio,settings={}){
    super(send,audio,settings);
    this.settings={moves:METER_SPACE_FORM.moves,between:METER_SPACE_FORM.between,partStreams:METER_SPACE_FORM.partStreams,opening:'draw',relations:'any',meterSelection:'unrestricted',...this.settings};
    if(!['any','grain'].includes(this.settings.relations))throw new RangeError('meterspace_clodbot\'s relations are \'any\' or \'grain\'');
    if(!['score-selection-v2','unrestricted'].includes(this.settings.meterSelection))throw new RangeError('Unknown meter selection policy');
    this.parts=new Map;this.away=new Map;this.moves=[];this.nextMoveBar=Infinity;this.elapsed=0;
  }
  // The sounding parts, as they announce themselves (/broadcast/agentState): the ones it may modulate apart.
  onMessage(message){
    if(message?.address==='/broadcast/agentState'){
      const state=message.args?.[0];
      if(state?.instanceId&&state.instanceId!==this.instanceId){
        if(state.state==='performing'&&!state.messageOnly&&state.outputModes?.length)this.parts.set(state.instanceId,state);
        else this.parts.delete(state.instanceId);
      }
    }
    return super.onMessage(message);
  }
  // A home the band can play, chosen from those that fit rather than drawn and refused (the user, 28 September 2026: "We
  // are not building a brute-force system, we are checking the accuracy of a precise system while developing it"): a
  // meter of the space, or a state between two, its bar within barSeconds at the tempo keeping the notated note from
  // `from` at `bpm`, other than `from`. {meter, bpm, octaves, kind, between?}, or null where none fits.
  drawHome(from,bpm){
    const target=this.jumpHome(from,bpm);
    if(!target)return null;
    if(!(unitRandom()<this.settings.between))return this.finishHome(target.meter,target.tempo,'jump',null);
    // Between the home, or another meter that fits, and the target: of the tenths between them, those whose state fits.
    const a=unitRandom()<.5?from:this.jumpHome(from,bpm)?.meter??from,states=[];
    for(let k=1;k<=METER_SPACE_FORM.betweens;k++){
      const t=k/(METER_SPACE_FORM.betweens+1),meter=interpolateMeter(a,target.meter,t,{maxDenominator:32});
      if(meter.numerator>METER_SPACE_FORM.numeratorAtMost)continue;
      let tempo;
      if(this.settings.meterSelection==='score-selection-v2'){
        meter.tempoUnit=4;
        meter.metricReading=metricReadingFor(meter,{id:'authored-between',kind:Number.isInteger(Math.log2(meter.denominator))?'grouped':'specialist',
          editorialAction:Number.isInteger(Math.log2(meter.denominator))?'PUBLISH_GROUPED':'PUBLISH_SPECIALIST_WITH_LEGEND',
          reason:'New intermediate gesture, with its declared groups as beats; exact prior music is unchanged.'});
        const range=readingClockWindow(meter,{candidate:true}),kept=bpm*meter.denominator/from.denominator;
        if(!range)continue;
        const low=Math.ceil(Math.log2(range[0]/kept)),high=Math.floor(Math.log2(range[1]/kept));
        if(low>high)continue;
        const octaves=Math.max(low,Math.min(high,0));tempo={bpm:kept*2**octaves,octaves};
      }else tempo=keptNoteTempo(bpm,from,meter);
      if(this.fits(meter,tempo.bpm)&&!sameShape(meter,from))states.push({meter,tempo,t});
    }
    if(!states.length)return this.finishHome(target.meter,target.tempo,'jump',null);
    const {meter,tempo,t}=states[Math.floor(unitRandom()*states.length)];
    return this.finishHome(meter,tempo,'between',{from:a.label??`${a.numerator}/${a.denominator}`,to:meter.between.to,t});
  }
  // A meter of the space that fits: now and then a tala's cycle among those whose bar fits at its tempo; else a
  // denominator, the tempo keeping the notated note at it, and a numerator from those whose bar fits that tempo.
  // {meter, tempo}, or null.
  jumpHome(from,bpm){
    if(this.settings.meterSelection==='unrestricted')return this.unrestrictedHome(from,bpm);
    const selected=drawScoreMeter(unitRandom,{quarterBPM:bpm*4/from.denominator,exclude:from.metricReading?.id});
    return selected?{meter:selected.meter,tempo:{bpm:selected.bpm,octaves:selected.octaves}}:null;
  }
  // The whole space (its default: which meters is never restricted, the owner, 4 October 2026), each meter only where
  // it is felt at the tempo it would take -- its bar no longer than a listener hears as one group (felt-tempo.js); the
  // research catalog (settings.meterSelection 'score-selection-v2') a choice beside it.
  unrestrictedHome(from,bpm){
    const shortest=METER_SPACE_FORM.barSeconds[0],longest=Math.min(METER_SPACE_FORM.barSeconds[1],FELT_TEMPO.longestBarSeconds);
    if(unitRandom()<METER_SPACE.talas){
      const talas=TALAS.map(id=>({id,meter:meterOfTala(RHYTHM_VOCABULARY[id])})).filter(({meter})=>this.fits(meter,keptNoteTempo(bpm,from,meter).bpm)&&!sameShape(meter,from));
      if(talas.length){
        const {id,meter}=talas[Math.floor(unitRandom()*talas.length)];
        return {meter:{numerator:meter.numerator,denominator:meter.denominator,groups:[...meter.groups],subdivision:meter.subdivision,tala:id,
          label:`${RHYTHM_VOCABULARY[id].name}, ${meter.groups.join('+')}/${meter.denominator}`},tempo:keptNoteTempo(bpm,from,meter)};
      }
    }
    const denominator=weighted(METER_SPACE.denominators,unitRandom),tempo=keptNoteTempo(bpm,from,{denominator});
    const low=Math.max(METER_SPACE.numerators[0],Math.ceil(shortest*tempo.bpm/60-1e-9)),high=Math.min(METER_SPACE.numerators[1],Math.floor(longest*tempo.bpm/60+1e-9));
    const numerators=[];for(let n=low;n<=high;n++)if(!(n===from.numerator&&denominator===from.denominator))numerators.push(n);
    if(!numerators.length)return null;
    const numerator=numerators[Math.floor(unitRandom()*numerators.length)],meter=drawMeter(unitRandom,{numerators:[numerator,numerator],denominator,talas:false});
    return this.fits(meter,tempo.bpm)?{meter,tempo}:null;
  }
  // Whether a meter's bar fits at `bpm`: felt there (its reading's window where it has one; else felt-tempo.js: its bar
  // no longer than a listener hears as one group, a level of it at a beat heard as one), its units and ticks within bounds.
  fits(meter,bpm){
    const range=meter.metricReading?readingClockWindow(meter,{candidate:true}):null;
    const fits=range?bpm>=range[0]-1e-9&&bpm<=range[1]+1e-9:!meter.metricReading&&isFeltMeter(meter,bpm);
    return fits&&meter.numerator<=METER_SPACE_FORM.numeratorAtMost&&meter.numerator*(meter.subdivision??1)<=METER_SPACE_FORM.pulsesPerBarAtMost;
  }
  // The home as the band will play it: its phrase about phraseSeconds, its grain fine enough to play in.
  finishHome(meter,tempo,kind,between){
    const seconds=barSeconds(meter,tempo.bpm),phraseBars=Math.max(1,Math.min(8,Math.round(METER_SPACE_FORM.phraseSeconds/seconds)));
    const fine=Math.ceil(60/tempo.bpm/METER_SPACE_FORM.tickSeconds-1e-9),subdivision=Math.min(96,Math.floor(METER_SPACE_FORM.pulsesPerBarAtMost/meter.numerator),Math.max(meter.subdivision??1,fine));
    return {meter:{...meter,numerator:meter.numerator,denominator:meter.denominator,groups:[...meter.groups],subdivision,phraseBars,
      pulsesPerBar:meter.numerator*subdivision,label:meter.label,...(meter.tala?{tala:meter.tala}:{})},bpm:tempo.bpm,octaves:tempo.octaves,kind,...(between?{between}:{})};
  }
  // The home taken: the base's home adopted from it, home time begun again at its first downbeat (`at`, the tick it
  // begins on, where known). Its decision says where it came from, at what tempo, and how.
  takeHome(clock,drawn,at=null){
    const from=this.home?{meter:`${this.home.groups.join('+')}/${this.home.denominator}`,denominator:this.home.denominator,bpm:this.homeBpm}:null;
    this.adoptHome({...clock,meter:drawn.meter,bpm:drawn.bpm});
    this.homeTime=Rational.ZERO;this.lastDissonanceBar=-Infinity;this.lastRegroupedBar=undefined;
    this.nextMoveBar=this.home.phraseBars;
    const entry={tick:clock.tick,...(at!==null?{at}:{}),move:drawn.kind,...(from?{from}:{}),meter:`${drawn.meter.groups.join('+')}/${drawn.meter.denominator}`,denominator:drawn.meter.denominator,subdivision:drawn.meter.subdivision,
      bpm:drawn.bpm,...(drawn.octaves?{octaves:drawn.octaves}:{}),...(drawn.between?{between:drawn.between}:{}),...(drawn.meter.tala?{tala:drawn.meter.tala}:{})};
    this.moves.push(entry);if(this.moves.length>METER_FORM.decisionsKept)this.moves.shift();this.decide(entry);
  }
  // A conductor that joins after the parts has heard none of them announce themselves: it asks the room to, as ManageBOT
  // does (both hosts answer /system/announce with each bot's agentState), once a phrase at most while it knows none.
  askRoll(bar=0){
    if(this.askedRollAt!=null&&bar-this.askedRollAt<(this.home?.phraseBars??bandPhraseBars()))return;
    this.askedRollAt=bar;this.send('/system/announce',[]);
  }
  onPrepare(clock={}){
    if(!this.parts.size)this.askRoll(Number(clock.bar)||0);
    if(!clock.meter||this.home||this.settings.opening!=='draw')return super.onPrepare(clock);
    const bpm=Number(clock.bpm)>0?Number(clock.bpm):108,drawn=this.drawHome(clock.meter,bpm);
    if(!drawn)return super.onPrepare(clock);
    this.takeHome(clock,drawn);this.planSpan({...clock,meter:drawn.meter,bpm:drawn.bpm},Number.isSafeInteger(clock.bar)?clock.bar:0);
    // The meter first, then its tempo: a clock bounds a tempo by the meter it is in (tempo-range.js).
    const first=this.queue[0];
    if(first&&!sameBar(first,clock.meter)){const {ratio,bpm:_,enter,...meter}=first;this.broadcast('timeSignature',[meter,'opening'])}
    if(drawn.bpm!==bpm)this.broadcast('tempoCurve',[{targetBpm:drawn.bpm,durationBars:0,shape:'linear'},'opening']);
    return true;
  }
  // What it decides, kept as the base keeps it; its moves and its parts apart also reported, for a render's record.
  decide(entry){super.decide(entry);if(entry?.move||entry?.streams)this.audio?.report?.('meterspace',entry)}
  // The seconds its clock has run, tempo changes and all (as the drummer counts a solo's), for an end given in seconds.
  // A move's tempo is stepped after the base has proposed the new home's first bar, as the base steps a modulation's.
  onTick(tick,clock){
    if(Number.isFinite(clock?.tick)){if(this.lastTick!==undefined&&clock.tick>this.lastTick)this.elapsed+=secondsPerTick(clock)*(clock.tick-this.lastTick);this.lastTick=clock.tick}
    super.onTick(tick,clock);
    if(this.movedTempo!=null){this.broadcast('tempoCurve',[{targetBpm:this.movedTempo,durationBars:0,shape:'linear'},'nextBar']);this.movedTempo=null}
  }
  // Its metric modulations: the base's, every ratio a/b whose bars fit and whose tempo the clocks play (so every ratio
  // between any two already: interpolateRatio's place), only while it is home.
  modulation(limit,startsAtBar){
    if(this.away.size)return null;
    return super.modulation(limit,startsAtBar);
  }
  // The bars a span may take before the piece's final bar: the base's, from an end in bars; from an end in seconds, the
  // home's bars that fit between the span's start and the end, at the home's tempo.
  barsBeforeEnd(startsAtBar){
    const end=this.audio?.renderEnd;
    if(!(end?.seconds>0)||end?.bars>0||end?.ticks>0)return super.barsBeforeEnd(startsAtBar);
    const bar=this.home&&this.homeBpm>0?this.home.numerator*60/this.homeBpm:null;
    return bar&&Number.isFinite(this.spanStartSeconds)?Math.floor((end.seconds-this.spanStartSeconds)/bar+1e-9)-1:Infinity;
  }
  // The next span, from a home downbeat, as the base plans it. But where a phrase of the home has been heard and every
  // part is home, first a choice: a new home (settings.moves), or, keeping the home, parts modulated apart
  // (settings.partStreams).
  planSpan(clock,startsAtBar){
    if(!this.home)return super.planSpan(clock,startsAtBar);
    // (The span's first tick and second: this bar's, or the next's, in the meter now sounding.)
    const known=Number.isSafeInteger(clock.tick)&&clock.meter?.pulsesPerBar&&Number.isSafeInteger(clock.bar),ahead=known?(startsAtBar-clock.bar)*clock.meter.pulsesPerBar-(clock.tickInBar??0):0;
    const startTick=known?clock.tick+ahead:null;
    this.spanStartSeconds=this.elapsed+(known?ahead*secondsPerTick(clock):0);
    const [bar]=this.homeTime.divmod(this.barLength),ending=this.closingAt?.(clock)?.phase??'none',limit=this.barsBeforeEnd(startsAtBar);
    for(const [id,away] of this.away)if(startTick!==null&&away.until<=startTick)this.away.delete(id);
    const free=!this.away.size&&this.partsBusyUntil<=startsAtBar&&ending==='none'&&limit>=1;
    if(!free||bar<this.nextMoveBar)return super.planSpan(clock,startsAtBar);
    this.nextMoveBar=bar+this.home.phraseBars;
    if(unitRandom()<this.settings.moves){
      const drawn=this.drawHome(this.homeBar(),this.homeBpm??Number(clock.bpm));
      if(drawn){
        this.takeHome(clock,drawn,startTick);this.movedTempo=drawn.bpm;
        return super.planSpan({...clock,bpm:drawn.bpm},startsAtBar);
      }
    }
    super.planSpan(clock,startsAtBar);
    // (Never under a metric modulation of the whole band.)
    if(startTick===null||this.span?.kind==='modulation')return;
    if(!this.parts.size)this.askRoll(startsAtBar);
    else if(unitRandom()<this.settings.partStreams)this.modulateParts(clock,startTick,Math.min(limit,METER_SPACE_FORM.awayHomeBars[1]));
  }
  // Parts modulated apart from `anchor`, a home downbeat: each its own meter and its own tempo relation to the ensemble,
  // and each home again where its cycle and the home's bar next begin together, within `bars`. Its relation and its bar
  // are chosen from those that come home in time, not drawn and refused. Three kinds, the one drawn first among those
  // that fit (settings.relations 'any'; 'grain', the first only):
  //   - its beat another whole number of the ensemble's ticks (s/s' against the ensemble's s, from 1:4 to 4:1);
  //   - held at any ratio p:q, its terms at most ratioTermsAtMost, its ticks the ensemble's grain (part-time-map.js);
  //   - there and back: a glide from 1:1 to p:q, held there for a meeting of the two bars or not at all, and a glide
  //     home, each glide as long as it takes to land on both bars' downbeats, so that it rejoins the ensemble in step.
  // The smaller integers likelier in each.
  modulateParts(clock,anchor,bars){
    const s=this.home.subdivision,N=this.home.numerator,homeTicks=N*s,[slowest,fastest]=METER_SPACE_FORM.relation,[least]=METER_SPACE_FORM.awayHomeBars;
    if(bars<least)return;
    const most=Math.max(2,Math.min(17,N+6)),limit=bars*homeTicks,kinds={grain:[],held:[],glided:[]};
    // (The first meeting of a bar `every` shared ticks with the home's that is at least `least` home bars on.)
    const firstMeeting=every=>{const both=lcm(every,homeTicks);return Math.ceil(least*homeTicks/both)*both};
    for(let own=1;own<=Math.min(96,4*s);own++){
      if(own===s)continue;const r=s/own;if(r<slowest||r>fastest)continue;
      const numerators=[];
      for(let n=2;n<=most;n++){const first=firstMeeting(n*own);if(first<=limit)numerators.push({n,first})}
      if(!numerators.length)continue;
      const g=gcd(s,own);kinds.grain.push([{kind:'grain',p:s/g,q:own/g,own,numerators},1/(s/g+own/g)]);
    }
    if(this.settings.relations==='any')for(let p=1;p<=METER_SPACE_FORM.ratioTermsAtMost;p++)for(let q=1;q<=METER_SPACE_FORM.ratioTermsAtMost;q++){
      if(p===q||gcd(p,q)!==1||p/q<slowest||p/q>fastest)continue;
      const held=[],glided=[];
      for(let n=2;n<=most;n++){
        // Held at p:q, its bar of n beats is n·s·q/p shared ticks; with the home's, it meets every N·s·n·q/gcd(n·q, N·p).
        const period=homeTicks*n*q/gcd(n*q,N*p),first=Math.ceil(least*homeTicks/period)*period;
        if(first<=limit)held.push({n,first});
        // A glide from 1:1 to p:q over D shared ticks goes D(1 + p/q)/2 of its ticks: on both downbeats when D is j home
        // bars, j = 2nq / gcd(2nq, N(p + q)). The glide home is its mirror.
        const glide=homeTicks*2*n*q/gcd(2*n*q,N*(p+q));
        for(const hold of [0,period])if(2*glide+hold<=limit&&2*glide+hold>=least*homeTicks)glided.push({n,first:2*glide+hold,glide,hold});
      }
      if(held.length)kinds.held.push([{kind:'held',p,q,own:s,numerators:held},1/(p+q)]);
      if(glided.length)kinds.glided.push([{kind:'glided',p,q,own:s,numerators:glided},1/(p+q)]);
    }
    const present=Object.values(kinds).filter(list=>list.length);
    if(!present.length)return;
    const candidates=[...this.parts.keys()].sort(),count=1+Math.floor(unitRandom()*Math.min(METER_SPACE_FORM.streamsAtMost,candidates.length));
    const chosen=[];while(chosen.length<count){const id=candidates.splice(Math.floor(unitRandom()*candidates.length),1)[0];if(!id)break;chosen.push(id)}
    const told=[];
    for(const id of chosen){
      const list=present[Math.floor(unitRandom()*present.length)];
      const {kind,p,q,own,numerators}=weighted(list,unitRandom),{n,first,glide,hold}=numerators[Math.floor(unitRandom()*numerators.length)];
      const meter=drawMeter(unitRandom,{numerators:[n,n],subdivision:own,talas:false});
      // Written as a metric modulation is: its note values the home's own, scaled by the relation where that makes a
      // note (the home's eighth at 1:2 a quarter, at 3:2 a triplet eighth), else the home's with a tempo of its own; a
      // glide's the home's.
      const scaled=kind==='glided'?this.home.denominator:this.home.denominator*p/q;
      meter.denominator=Number.isInteger(scaled)&&scaled>=1&&METER_SPACE.denominators.some(([d])=>d===scaled)?scaled:this.home.denominator;
      meter.label=meter.label.replace(/\/\d+$/,`/${meter.denominator}`);
      const until=anchor+first,label=kind==='glided'?`${meter.label} at 1:1 to ${p}:${q} and back`:`${meter.label} at ${p}:${q}`;
      const stream={meter:{numerator:meter.numerator,denominator:meter.denominator,groups:[...meter.groups],...(meter.sections?{sections:meter.sections}:{}),subdivision:own,phraseBars:this.home.phraseBars,label:meter.label},id:label};
      const relation=kind==='held'?{ratio:[p,q]}:kind==='glided'?{from:[1,1],to:[p,q],ticks:glide}:null;
      this.send('/agent/stream',[{target:id,stream,...(relation?{relation}:{}),anchor,coordinator:this.instanceId}]);
      if(kind==='glided')this.send('/agent/stream',[{target:id,relation:{to:[1,1],ticks:glide},anchor:anchor+glide+hold,coordinator:this.instanceId}]);
      this.send('/agent/stream',[{target:id,stream:null,anchor:until,coordinator:this.instanceId}]);
      this.away.set(id,{until,ratio:[p,q],meter:label});
      told.push({part:id,meter:label,ratio:[p,q],kind,anchor,until,...(kind==='glided'?{glide,hold}:{})});
    }
    if(told.length)this.decide({tick:clock.tick,streams:told});
  }
}

export const meterspaceClodbot=defineBot(
  {
    id:'meterspace_clodbot',name:'meterspace_clodbot',status:'native',source:'clodbot',
    category:'conductor',outputModes:[],pitchContract:'none',
    // The settings a render spec may give it: the base's two, how often its home moves and to states between, how often
    // it modulates parts apart, and whether its first home is its own ('draw') or the piece's ('home').
    specSettings:Object.freeze(['dissonance','modulation','moves','between','partStreams','opening','relations','meterSelection']),
    description:'meterform_clodbot\'s fork whose home moves through the whole space of meters: now and then, where a phrase of the home has been heard, it jumps to a meter drawn from anywhere in the space (any numerator to 40, power-of-two and irrational denominators, groupings of its own, the talas\' cycles) or takes a state between two meters of it, the notated note keeping its length across the move; within each home, the base\'s grouping dissonances and metric modulations, their ratios from between the base\'s too; and it modulates parts apart, up to three at once, each told a stream of its own whose beat is another whole number of the ensemble\'s ticks, so each has its own tempo relation to the ensemble, and each told to come home where its cycle and the home\'s bar next begin together.',
  },
  (...args)=>new MeterSpaceClodbot(...args),
);
