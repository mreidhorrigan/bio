import {scoreTime,scoreTimeFields,shiftScoreTime,readScoreTime} from '../../shared/score-time.js';
import {authoredFraction as Q} from '../../shared/performers/rhythm-cell.js';
// clodbot_singerbot: a singer (docs/VOCALS.md). It sings words to a line it plans a phrase ahead in the harmony it hears, and the
// vocal service renders each phrase through OpenUtau and a recorded voicebank (Meilin by default: Japanese, CC BY 3.0 TW),
// so that what it sings is concatenated from a person's recorded syllables, at the exact pitches it chose.
//
// - Words: whatever /broadcast/lyrics sends ({text, language}), or a traditional Japanese song chosen by its seed
//   (public/shared/vocal/lyrics.js), sung mora by mora in order, breathing where the text does.
// - Line: two-bar phrases, a note to a mora on the felt beats and sometimes between them, chord tones on strong beats and
//   steps between, in an alto's register; its own just intonation where no tuning bot leads, the ensemble's tuning where
//   one does. Pitches stay floats end to end: the service carries them to OpenUtau to a thousandth of a cent.
// - Time: each phrase is committed a bar and more ahead of its first beat, and the rendered audio is placed on that beat's
//   audio time (public/vocal/vocal-player.js). A harmony heard to change before the phrase is frozen re-plans it as a new
//   revision; one that is too late to render is dropped and reported, never sung late.
// - Where it cannot sing (a page opened from a file, a client-only page, a server with no vocal service) it is silent
//   and says so on its card; it never substitutes another voice.
import {defineBot} from '../../framework/index.js';
import {unitRandom} from '../../shared/stochastic.js';
import {VoiceLeadingBot,modulo,clamp01} from '../lib/voice-leading-bot.js';
import {spaceFor} from '../../shared/harmonic-spaces.js';
import {HearsPartRubato} from '../lib/modules/part-rubato.js';
import {HearsAttention} from '../lib/modules/attention.js';
import {licenseReach} from '../../shared/attention.js';
import {assertion} from '../../shared/performers/evidence.js';
import {heldNote} from '../../shared/hold-timing.js';
import {normalizeHold,holdTick} from '../../shared/clock-hold.js';
import {normalizeRubato,rubatoMap} from '../../shared/clock-rubato.js';
import {ratio,toNumber} from '../../shared/rhythm-vocabulary.js';
import {createRandomStream} from '../../random-source.js';
import {contourCost} from '../../shared/melodic-contour.js';
import {VocalPlayer,vocalAvailability} from '../../vocal/vocal-player.js';
import {LiveVocalPlayer} from '../../vocal/live-vocal-player.js';
import {AnalyticVocalPlayer,ANALYTIC_BANK} from '../../vocal/analytic-vocal-player.js';
import {DiphoneVocalPlayer,DIPHONE_BANK} from '../../vocal/diphone-vocal-player.js';
import {FLOW_STYLE,flowPositions,planFlow,syllableSteps,markRhymes} from '../../shared/vocal/flow.js';
import {doublePlan} from '../../shared/vocal/double.js';
import {rowDefinition,rowInstance,FIXTURE_ROW_12} from '../../shared/pitch-languages/rows.js';
import {motive as makeMotive,motiveGraph,introduce,derive} from '../../shared/pitch-languages/motives.js';
import {japaneseMorae,checkJapaneseCoverage,annotateJapaneseWords,tailVowel,TRADITIONAL_LYRICS,EXTENDER} from '../../shared/vocal/lyrics.js';
import {englishWords,englishKeys,englishSyllables,englishUnitsFromSegments,englishSyllableText,wordNotes} from '../../shared/vocal/english.js';
import {annotateJapaneseAccent,afterFall} from '../../shared/vocal/japanese-accent.js';
import {englishProminence,japaneseProminence,phrasePositions,setSyllables,syllableVolume,consonantsBefore,codaOf,japaneseOnset,glideJoin,vowelOf,consonantTicks} from '../../shared/vocal/prosody.js';
import {parseSsml,SsmlError} from '../../shared/vocal/ssml.js';
import {FAMILIES,velocityGain} from '../../shared/articulation.js';
import {phraseTrajectories,onControlGrid} from '../../shared/vocal/transitions.js';
import {controlGridMs} from '../../shared/vocal/openutau-pitch.js';
import {planBreaths,singer as breathProfile,drain as breathDrain} from '../../shared/performers/voice.js';
import {CHOIR_PARTS,PART_GENDER,SPACING,isPart,partsAbove,harmonize,chooseByCost} from '../../shared/vocal/choir.js';
import {instrumentRange} from '../../shared/performers/instrument-ranges.js';
import {bandMeter} from '../../shared/opening-time.js';

// The singer's level at the pivot velocity (articulation.js VELOCITY_PIVOT), calibrated as every bot's is
// (scripts/audio-probes/bot-loudness.mjs: alone, 12 bars, seed 11, BS.1770): at its default velocity it sits at
// -16.6 LUFS, the median of the monophonic melody bots in research/derived/bot-loudness-2026-09-23.json. The rendered
// voicebank is close to full scale and a bot's output chain gains it by 4 into a limiter, so the level is set below
// the limiter, where the stem is linear in it (measured 2026-09-26: -25.4 LUFS at 0.05, -19.4 at 0.1; a fixed 0.9
// before this gave -5.9, limited). Velocity moves it as the lead family's does (24 dB, square law), which is a choice,
// not a measurement of singers. Re-measured when the vocalise left the seeded choice (its open vowels had been this
// seed's material): words sat at -17.76 LUFS at 0.138 (さくら alone -17.79), so 0.158 puts them back at -16.6.
const LEVEL=.158;
// The bank each language is sung with (a `bank` setting names another). Where it is not installed the singer is silent
// and says so: no other voice stands in for it.
export const VOCAL_BANKS=Object.freeze({ja:'meilin-ja-2015',en:'milk-en'});
const DEFAULTS=Object.freeze({
  style:'vocal',velocity:.6,intonation:'just',dissonance:.2,
  // How open the line is to tones outside its ladder (0 to 1): chromatic passing and neighbour tones, each between the
  // last note and a ladder step beside it and resolved by step to the ladder, in the band's tuning. Never diatonic-only
  // by default (the owner, 30 September 2026: "The default settings for the musebots are never to be diatonic only ...
  // unless explicitly stated otherwise by the user"): 0 is the ladder alone, set only where the owner asks for it.
  chromatic:.5,
  bank:null,language:'ja',
  // An alto's register (G3 to D5: the instrument registry's choral alto, instrument-ranges.js), around where the Meilin
  // recordings sit (330-360 Hz).
  low:instrumentRange('voice-alto').register[0],high:instrumentRange('voice-alto').register[1],
  phraseBars:2,          // a sung phrase, then a breath
  breath:null,           // how long one breath sings, in seconds (else its voice's comfortable breath: voice.js)
  phraseSeconds:null,    // or a sung phrase about this long, in whole bars (at least one): for meters whose bars are far
                         // from a phrase's length, as the meter bot's are (meterspace_clodbot)
  leadBars:1,            // committed at least this far ahead of its first beat
  frozenSec:1.5,         // inside this, a committed phrase is not re-planned
  subdivideChance:.25,   // how often a beat carries two syllables
  flow:'song',           // 'song': syllables set to the phrase's beats as they are sung; 'rap': a rapper's flow, its
                         // syllables wherever the meter's divisions let them be said (shared/vocal/flow.js)
  pitched:null,          // 0 (spoken) to 1 (sung on its notes), for a voice that can speak (the analytic route); unset,
                         // a song is sung and a rap drawn once from the seed between spoken and half pitched
  lyrics:null,           // a TRADITIONAL_LYRICS id; otherwise one chosen by the seed
  once:false,            // sing the text through once, then rest while the piece goes on (a poem set whole); otherwise
                         // begin it again
  route:'render',        // 'render': phrases rendered by the service and played; 'live': sung by the live WORLD voice;
                         // 'analytic': synthesized on the page from its phones, no recordings (English); 'diphone': a
                         // diphone speech voice (MBROLA) from the same phones, for a rapper, offline only (English)
  double:false,          // a second take of each phrase, performed independently (shared/vocal/double.js): true, or its
                         // options ({lagMs, pitchCents, levelDb, gainDb}); never reported as notes of its own
  // Where the line's pitches come from (docs/PITCH_LANGUAGES.md): 'harmony', the harmony it hears (just intonation); 'row', a
  // serial row, one member a syllable, its cursor carried from phrase to phrase, a new form each statement (a row of
  // rowSteps classes sounds in rowSteps equal steps a period: 31 gives 31-EDO); 'motive', a cell ({0,1,4}, or `motive`)
  // developed phrase by phrase through a motive graph. Each note's row position or derivation goes with its report.
  pitchLanguage:'harmony',row:null,rowSteps:12,motive:null,
  // Between notes the pitch moves as singers' does (transitions.js: 'measured', Saitou et al.'s overshoot) or jumps
  // ('none'). A deliberate glide takes `glideChance` of the changes, `glideMs` long, `glideLead` of it sung before the new
  // syllable (transitions.js: 1 slid on the old vowel, arriving as the new syllable begins; 0 a scoop on the new vowel):
  // a share, or a range drawn from once a piece, most toward its top (the owner, 2 October 2026: "attack notes
  // mid-glissando or attack directly into glissandos in ways that I think should occur less often"). The bot's own choices.
  transitions:'measured',glideChance:.2,glideMs:[120,260],glideLead:[0,1],
  // A choir (shared/vocal/choir.js): `part`, a register ('soprano', 'alto', 'tenor', 'bass'; the alto's where none is
  // given); `follow`, the singer whose words and rhythm it sings, harmonized under the parts above it (a voice id, or
  // 'lead': the first singer it hears that follows no one). A singer that follows no one sings its own line.
  part:null,follow:null,
  // An ad-lib (the rap supplement's R017, "double-tracking, ad-libs and turn-taking as separate performers"): a singer
  // following a rapper (its `follow`, 'lead' where it names none) sings only its lead's rhymes, a line at a time as its
  // own draw gives: 'stack', the line's rhyme said with the lead's, syllable on syllable; 'answer', said again in the gap
  // the line leaves after it, where it fits before the lead goes on; 'both', each line one of them or neither
  // (ADLIB.chances). Never a lyric stream of its own, and never over the lead where it answers. Or 'double': every
  // syllable with its lead, at its lead's pitch in its own range, in its own voice (a double-tracked lead's double as a
  // performer, not the lead's own second take: `double`).
  adlib:null,
  // The voice's gender, -100 to 100, where its part does not set one (shared/vocal/choir.js): a bank's spectral envelope
  // moved, so that a high bank sung low keeps a low voice's colour. 0 sings the bank as recorded.
  gender:null,
});
const OFFSET_RESOLUTION=1000;
// The line's choice among its candidates by their contour costs (line, melodic-contour.js; choir.js chooseByCost): the
// line mostly takes the best and sometimes the nearly best, so a seed has its own line. A clash with another singer
// costs CLASH_COST, taken only where every candidate clashes; a tone outside the chord on a stressed syllable
// NONCHORD_COST, less the singer's intended dissonance. The lead's weights: LINE_WEIGHTS.
// A tone outside the ladder (a chromatic passing or neighbour tone) costs CHROMATIC_COST, less the line's openness to
// them (`chromatic`).
const CLASH_COST=4,NONCHORD_COST=1,CHROMATIC_COST=1;
const LINE_WEIGHTS=Object.freeze({repeat:.8,inertia:.6});
// A phrase longer than a breath is sung as breaths (breathLines): split where the meter's groups begin, each part no
// longer than one breath carries, the next committed at least BREATH_LEAD_SECONDS ahead where a phrase's bar-lengths
// lead would be most of a minute (ours).
const BREATH_LEAD_SECONDS=3;
// An ad-lib's draws for a line where it is 'both' (ours): stack its rhyme, answer it, or leave the line to the lead;
// and how loud an answer is beside the syllables it echoes (a foreground voice's answer, a step back).
const ADLIB=Object.freeze({chances:Object.freeze({stack:.4,answer:.35}),answerVolume:.8});
const FOLLOW_MARGIN_SEC=.5;   // a follower stops re-planning this much before a lead does (ours)   // trajectory offsets in thousandths of a tick (a tick is a subdivision: 150 ms at 100 BPM in 4ths)
// A syllable sung again on the vowel it follows, with nothing between -- あ after ら or あ, "ow" after "ow" -- is
// re-attacked, not held: the note before it ends this much early, so the voice starts it again from silence (the
// phonemizer chooses its onset from silence, "- あ"). Held, the two sound as one: the user heard a tie in a MusebotTV take
// (2026-09-26), where those joins dipped 1.6-2.5 dB against 5-6 dB where a consonant re-articulates. An extender (ー) is
// a hold and stays one. The length is this singer's choice, not a measurement.
const REATTACK_SEC=.05;
// The rest is left before where the syllable will sound. Where the bank check moves its unit from silence earlier (a
// vowel-onset plan: the third of its unit times, vocal-service.mjs units), the note before ends that much earlier again:
// Meilin's "- あ" is moved 37.5 ms earlier, which filled the 50 ms to a dip of 10 dB where there should be silence.
// The singer's own numbers with their evidence (the family atlas's voice, F38; shared/performers/evidence.js; the
// voice's breath and choir: voice-evidence.js): its level measured as every bot's is, its line's two weights estimated
// from a corpus, its re-attack and its glides authored.
export const SINGER_EVIDENCE=Object.freeze({
  level:assertion({value:LEVEL,unit:'gain at the pivot velocity',status:'measured',scope:'the singer alone, 12 bars, seed 11',
    source:{citation:'scripts/audio-probes/bot-loudness.mjs, BS.1770: -16.6 LUFS, the median of the monophonic melody bots (research/derived/bot-loudness-2026-09-23.json)'}}),
  'line.repeat':assertion({value:LINE_WEIGHTS.repeat,unit:'contour cost',status:'model-estimated',scope:'the lead\'s line',
    source:{citation:'fitted to the voice parts of the Schubert Winterreise Dataset (Weiß et al. 2021), measured on this machine (scripts/measure-sung-lines.mjs)',doi:'10.1145/3429743'}}),
  'line.inertia':assertion({value:LINE_WEIGHTS.inertia,unit:'contour cost',status:'model-estimated',scope:'the lead\'s line',
    source:{citation:'fitted with line.repeat',doi:'10.1145/3429743'}}),
  reattackSeconds:assertion({value:REATTACK_SEC,unit:'s',status:'authored',scope:'a syllable sung again on its vowel',source:{citation:'this singer\'s choice, not a measurement'}}),
  glideChance:assertion({value:DEFAULTS.glideChance,unit:'share of pitch changes',status:'authored',scope:'a deliberate glide',source:{citation:'this singer\'s choice'}}),
  glideMs:assertion({value:[...DEFAULTS.glideMs],unit:'ms',status:'authored',scope:'a deliberate glide',source:{citation:'this singer\'s choice'}}),
});
export function reattackSec(next,units,english){
  const shiftMs=units?.[`- ${english?next.vowel:next.lyric}`]?.[2];
  return REATTACK_SEC+(Number.isFinite(shiftMs)&&shiftMs<0?-shiftMs/1000:0);
}
function sungAgain(a,b,english){
  if(!a||!b||b.lyric===EXTENDER||a.lyric===EXTENDER||(b.before?.length??0)>0)return false;
  if(english)return Boolean(a.vowel)&&a.vowel===b.vowel;
  const vowel=tailVowel(a.lyric);
  return vowel!=null&&vowel===tailVowel(b.lyric);
}

// Singers keep out of each other's unisons and octaves. Two voices from the same voicebank an octave apart share half
// their harmonics: as the phases drift the pair partly cancels (down to 5 dB under two independent voices, measured in
// the English duet) and the upper voice fuses into the lower -- the user heard the vocals "inexplicably fade mid-phrase"
// (2026-09-26), where the duet held octaves. Each singer announces the phrase it commits (/broadcast/vocal/plan: its
// notes' ticks, lengths and pitches) and writes its own line clear of every other singer's overlapping notes. A clash
// that arrives after a phrase was committed is re-planned by the singer whose voice id sorts later, so two singers
// never answer each other back and forth.
const DOUBLING_SEMITONES=.35;   // within this of a unison or an octave counts as doubling
const doubles=(p,q)=>Math.abs(modulo(p-q+6,12)-6)<DOUBLING_SEMITONES;

// The singer is a melody: where drums or a steady accompaniment keep the clock, it takes the melody's part of each
// phrase's arch (/broadcast/partRubato; commitPhrase, partTimed). It hears its share of the band's attention
// (/broadcast/attention; attentionShare).
export class SingerBot extends HearsAttention(HearsPartRubato(VoiceLeadingBot,{instrument:'melody'})) {
  constructor(send,audio,settings={}){
    super(send,audio,{...DEFAULTS,...settings});
    this.ready=false;this.state='idle';this.player=null;this.aliases=null;
    this.units=[];this.cursor=0;this.lyricsId=null;
    this.phraseSerial=0;this.committed=new Map;this.sung=[];this.lastPitch=null;this.clockRef=null;this.languagePlans=new Map;
    this.othersPlans=new Map;this.replanSoon=new Set;
    // A choir part's register, where it is given one and no range of its own; a follower's lead's phrases by anchor, and
    // each singer's part and lead as their plans say them.
    if(isPart(this.vl.part)&&settings.low==null&&settings.high==null)Object.assign(this.vl,CHOIR_PARTS[this.vl.part]);
    if(isPart(this.vl.part)&&this.vl.gender==null)this.vl.gender=PART_GENDER[this.vl.part];
    this.followed=new Map;this.followDue=new Set;this.voiceRoles=new Map;this.leadId=null;
    if(this.vl.adlib&&!this.vl.follow)this.vl.follow='lead';
  }
  // Other singers' committed notes overlapping [from, to) in ticks: their pitches. Not those of a singer following this
  // one, whose tones are this line's own harmony (a choir doubles its tones): a lead planned again kept clear of the
  // octaves its followers took under its plan before, so each revision changed its notes and cascaded down the parts.
  othersBetween(from,to){
    const out=[];
    for(const [voice,plans] of this.othersPlans){
      if(this.followsThis(voice))continue;
      for(const plan of plans.values())for(const note of plan.notes)if(note.tick<to&&note.tick+note.length>from)out.push(note.pitch);
    }
    return out;
  }
  followsThis(voice){const follows=this.voiceRoles.get(voice)?.follows;return !this.vl.follow&&(follows===this.voiceId||follows==='lead')}
  hearPlan(payload){
    const voice=typeof payload?.voiceId==='string'?payload.voiceId:null;
    if(!voice||voice===this.voiceId||typeof payload.planId!=='string')return;
    const plans=this.othersPlans.get(voice)??new Map;this.othersPlans.set(voice,plans);
    const known=plans.get(payload.planId);
    if(known&&known.revision>payload.revision)return;
    const notes=(Array.isArray(payload.notes)?payload.notes:[]).filter(note=>[note?.tick,note?.length,note?.pitch].every(Number.isFinite)).slice(0,256)
      .map(note=>({tick:note.tick,length:note.length,pitch:note.pitch}));
    this.voiceRoles.set(voice,{part:isPart(payload.part)?payload.part:null,follows:typeof payload.follows==='string'?payload.follows:null});
    if(this.isLead(voice,payload))this.followLead(payload,notes);
    if(!notes.length){plans.delete(payload.planId);return}
    plans.set(payload.planId,{revision:payload.revision??0,notes});
    // A follower under a part above it that has just said its phrase: harmonized again under it.
    if(this.vl.follow){if(this.isAbove(voice))for(const [anchor] of this.committed)if(notes.some(note=>note.tick>=anchor&&note.tick<anchor+this.phraseTicks()))this.replanSoon.add(anchor);return}
    // A clash with one of this singer's open phrases: the later voice id re-plans it on its next tick. (Not a follower's:
    // a choir doubles its tones.)
    if(typeof payload.follows==='string'||this.voiceId<voice)return;
    for(const [anchor,entry] of this.committed)
      if(entry.notes.some(mine=>notes.some(theirs=>theirs.tick<mine.tick+mine.length&&theirs.tick+theirs.length>mine.tick&&doubles(mine.pitch,theirs.pitch))))this.replanSoon.add(anchor);
  }
  // The lead a follower sings under: the voice it names, or ('lead') the first it hears that follows no one.
  isLead(voice,payload){
    const follow=this.vl.follow;if(!follow)return false;
    if(follow!=='lead')return voice===follow;
    if(this.leadId)return voice===this.leadId;
    if(typeof payload.follows==='string')return false;
    this.leadId=voice;return true;
  }
  // Whether another singer stands above this follower: its lead, or a part above this one's.
  isAbove(voice){
    if(voice===this.leadId||voice===this.vl.follow)return true;
    const role=this.voiceRoles.get(voice);
    return Boolean(role?.part)&&partsAbove(this.vl.part).includes(role.part);
  }
  phraseTicks(){
    const clock=this.currentClock;if(!clock?.meter)return Infinity;
    const bar=this.barTicks(clock),phrase=bar*this.phraseBarsAt(clock),lines=this.breathLines(clock,0,phrase);
    return Math.max(...lines.map(line=>line.length));
  }
  // How long one breath lets this voice sing a phrase, in seconds: its `breath` setting, else its voice's comfortable
  // breath (shared/performers/voice.js VOICE.phonationSeconds: 8 s high, 12 s low, from the literature it cites). The
  // user, 29 September 2026: "a bot tasked with singing or representing a singer has a breath parameter that limits how
  // long their phrases can be, regardless of bars".
  breathSeconds(){const own=Number(this.vl.breath);return own>0?own:this.breathVoice().breath.phonationSeconds}
  // A phrase as it is breathed, from `from` (a tick) for `length` ticks: [{at, length}], one part where one breath carries
  // it, else parts no longer than a breath each (the last beat of each its breath, as a phrase's always is), split where
  // the meter's groups begin, across bar lines as they fall, the last running to the phrase's end. MusebotTV's long primes
  // made the need plain: 61/4 at 46 is 80 s a bar, and a two-bar phrase held one syllable for two minutes.
  breathLines(clock,from,length){
    const perTick=this.secondsPerTick(clock),most=Math.floor(this.breathSeconds()/perTick)+this.beatTicks(clock);
    if(length<=most)return [{at:from,length}];
    const bar=this.barTicks(clock),sub=Number(clock.meter.subdivision)||bandMeter().subdivision;
    const sizes=clock.meter.groups?.length?clock.meter.groups.map(Number):Array(Number(clock.meter.numerator)||bandMeter().numerator).fill(1);
    // Every group start within the phrase, bar after bar (from the bar `from` lies in).
    const barStart=from-((from-(clock.tick-clock.tickInBar))%bar+bar)%bar,starts=[];
    for(let at=barStart;at<from+length;at+=bar){let within=0;for(const size of sizes){const tick=at+within;if(tick>from&&tick<from+length)starts.push(tick);within+=size*sub}}
    // As many parts as the breath needs, as even as the groups allow: each cut at the group start nearest its even share,
    // never further than a breath from the cut before (so no part is a fragment left over).
    const parts=Math.ceil(length/most),lines=[];let begin=from;
    for(let k=1;k<parts;k++){
      const ideal=from+Math.round(k*length/parts),reach=starts.filter(tick=>tick>begin&&tick-begin<=most);
      const cut=reach.length?reach.reduce((best,tick)=>Math.abs(tick-ideal)<Math.abs(best-ideal)?tick:best):Math.min(begin+most,ideal);
      lines.push({at:begin,length:cut-begin});begin=cut;
    }
    lines.push({at:begin,length:from+length-begin});
    // (A last part a breath could not carry, where the groups fell badly: split once more at the groups within it.)
    if(lines.at(-1).length>most){const last=lines.pop();lines.push(...this.breathLines(clock,last.at,last.length).filter(line=>line.length>0))}
    return lines;
  }
  // Whether the host waits for a phrase's audio (an offline render: vocal-player.js commit), so that a phrase needs no lead.
  renderWaits(){return typeof this.audio?.holdRender==='function'}
  // Bars a phrase: its setting, or the whole bars nearest `phraseSeconds` at the tempo and meter now.
  phraseBarsAt(clock){
    const seconds=Number(this.vl.phraseSeconds);
    if(!(seconds>0))return this.vl.phraseBars;
    return Math.max(1,Math.round(seconds/(this.barTicks(clock)*this.secondsPerTick(clock))));
  }
  // A lead's phrase: its slots and anchor are this follower's words and rhythm there (committed on its next tick,
  // everyTick); a lead's withdrawn phrase withdraws its own.
  followLead(payload,notes){
    const anchor=payload.anchor;if(!Number.isSafeInteger(anchor))return;
    if(!notes.length){const entry=this.committed.get(anchor);if(entry){this.withdrawPhrase(entry.planId);this.committed.delete(anchor);this.announcePhrase(entry.planId,entry.revision+1,[])}this.followed.delete(anchor);return}
    const slots=(Array.isArray(payload.slots)?payload.slots:[]).filter(slot=>Number.isFinite(slot?.at)&&Number.isFinite(slot?.length)&&typeof slot?.lyric==='string').slice(0,256);
    if(!slots.length)return;
    const known=this.followed.get(anchor);
    if(known&&known.revision>=(payload.revision??0))return;
    this.followed.set(anchor,{planId:payload.planId,revision:payload.revision??0,slots});this.followDue.add(anchor);
  }
  // Its phrase at `anchor`, in its lead's words and rhythm, a new revision where it had one there. Not again where its
  // notes would be the same (a lead's revision, or a part above's, that leaves this part's notes as they were: without
  // this each revision of the lead cascaded down the parts, and one arriving late dropped the phrase), unless the time
  // it is placed by has changed (`retimed`: a tempo, or a span of the conductor's heard, revised or refused), and not
  // within the frozen stretch and half a second more (the parts above re-plan first).
  commitFollowed(clock,anchor,{retimed=false}={}){
    const followed=this.followed.get(anchor),mine=this.committed.get(anchor);if(!followed)return;
    // (An ad-lib's share of its lead's phrase: its rhymes, stacked or answered; none, and the phrase is its lead's alone.)
    const lead=this.vl.adlib?{...followed,slots:this.adlibSlots(clock,anchor,followed)}:followed;
    if(!lead.slots.length){if(mine){this.withdrawPhrase(mine.planId);this.committed.delete(anchor);this.announcePhrase(mine.planId,mine.revision+1,[])}return}
    if(mine&&!(this.phraseStart(anchor,mine)-(this.audio?.ctx?.currentTime??0)>this.vl.frozenSec+FOLLOW_MARGIN_SEC))return;
    if(mine&&!retimed){
      const before=this.lastPitch;this.lastPitch=mine.startPitch;
      this.draws={harmony:this.phraseDraws(mine.planId,'harmony')};
      let pitches;try{pitches=this.harmonized(clock,lead.slots,anchor).map(p=>this.tuned(p))}finally{this.draws=null}
      const same=mine.notes.length===lead.slots.length&&mine.notes.every((note,i)=>note.tick===anchor+lead.slots[i].at&&note.lyric===lead.slots[i].lyric&&Math.abs(note.pitch-pitches[i])<1e-6);
      this.lastPitch=same?before:mine.startPitch;
      if(same)return;
    }
    this.harmonizing=true;
    try{this.commitPhrase(clock,anchor,lead.slots.map(slot=>({...slot})),mine?mine.revision+1:0,mine?.planId??`${this.voiceId}:follows-${lead.planId}`)}
    finally{this.harmonizing=false}
  }
  // An ad-lib's syllables for its lead's phrase at `anchor` (its slots, as the lead's flow marked them: each line's rhyme
  // from its stressed syllable to the line's end, `rhyme: 'end'`, the line's last syllable `lineEnd`): for each line, as
  // its setting says or (both) its draw for that line gives -- keyed to the lead's phrase and the line, so that its draws
  // never move the lead's or another ad-lib's -- the rhyme stacked (its syllables at the lead's times), answered (the same
  // syllables, their lengths and spacing kept, from the first beat after the line ends, where they end before the lead's
  // next syllable or its phrase's end; a step quieter), or nothing.
  adlibSlots(clock,anchor,{planId,slots}){
    const mode=String(this.vl.adlib),beat=Math.max(1,this.beatTicks(clock)),out=[];
    // (A double: every syllable with the lead's, a performer of its own -- its voice, its delivery -- not a copy.)
    if(mode==='double')return slots.map(slot=>({...slot,adlib:'double'}));
    const end=slots.at(-1)?slots.at(-1).at+slots.at(-1).length:0,phraseEnd=Math.max(end,this.phraseTicks());
    let line=0;
    for(let i=0;i<slots.length;i++){
      if(slots[i].rhyme!=='end')continue;
      // (From its word's first syllable: a rhyme from a stressed syllable within a word -- "be-guiled" -- is said as the
      // word, since a syllable that continues a word, '+', cannot begin one.)
      let j=i,from=i;while(j+1<slots.length&&!slots[j].lineEnd)j++;while(from>0&&slots[from].lyric===EXTENDER)from--;
      const span=slots.slice(from,j+1),draw=createRandomStream(`${this.voiceId}:adlib:${planId}:${line++}`).next();
      const take=mode==='stack'||mode==='answer'?mode:draw<ADLIB.chances.stack?'stack':draw<ADLIB.chances.stack+ADLIB.chances.answer?'answer':null;
      if(take==='stack'){out.push(...span.map(slot=>({...slot,adlib:'stack'})));i=j;continue}
      if(take==='answer'){
        const from=span[0].at,last=span.at(-1),length=last.at+last.length-from,start=Math.ceil((last.at+last.length)/beat)*beat;
        const next=slots[j+1]?.at??phraseEnd;
        if(start+length<=next+1e-9)out.push(...span.map(slot=>({...slot,...(slot.scoreTime?{scoreTime:shiftScoreTime(slot.scoreTime,Q(start).sub(Q(from)))}:{}),at:start+slot.at-from,adlib:'answer',...(slot.volume!=null?{volume:Math.round(slot.volume*ADLIB.answerVolume)}:{})})));
      }
      i=j;
    }
    return out;
  }
  // Pitches of the singers above this follower under [from, to) in ticks.
  aboveBetween(from,to){
    const out=[];
    for(const [voice,plans] of this.othersPlans)if(this.isAbove(voice))for(const plan of plans.values())
      for(const note of plan.notes)if(note.tick<to&&note.tick+note.length>from)out.push(note.pitch);
    return out;
  }
  // A follower's pitches: the harmony's tones under the parts above it (shared/vocal/choir.js).
  harmonized(clock,slots,anchor){
    // (A double sings its lead's pitches, each moved by octaves into its own range: R017's double, a related performance.)
    if(this.vl.adlib==='double'){
      let last=this.lastPitch??this.bandOpening.chord[0];
      const pitches=slots.map(slot=>{const theirs=this.aboveBetween(anchor+slot.at,anchor+slot.at+slot.length)[0];if(!Number.isFinite(theirs))return last;
        let p=theirs;while(p<this.vl.low)p+=12;while(p>this.vl.high&&p-12>=this.vl.low)p-=12;return last=p});
      this.lastPitch=pitches.at(-1);this.lineChosen=pitches;return pitches;
    }
    const named=this.chord?[this.chord.root,this.chord.third,this.chord.fifth,this.chord.seventh].filter(pc=>pc!=null):[];
    const tuned=pc=>this.objectTuned?.(pc)??pc;
    const classes=named.length?named.map(tuned):(this.notes?.length?this.notes:this.bandOpening.chord).map(Number);
    const above=slots.map(slot=>this.aboveBetween(anchor+slot.at,anchor+slot.at+slot.length));
    // (Its line so far, as the lead's is heard: the phrases it committed before this one.)
    const history=[...this.committed.entries()].filter(([at])=>at<anchor).sort((a,b)=>a[0]-b[0]).flatMap(([,entry])=>entry.line??entry.notes.map(note=>note.pitch)).slice(-8);
    const pitches=harmonize(slots,{classes,root:this.chord?.root==null?null:tuned(this.chord.root),low:this.vl.low,high:this.vl.high,above,last:this.lastPitch,
      spacing:SPACING[this.vl.part]??12,bass:this.vl.part==='bass',history,random:this.draws?.harmony??unitRandom});
    this.lastPitch=pitches.at(-1);this.lineChosen=pitches;
    return pitches;
  }
  forgetPlansBefore(tick){
    for(const plans of this.othersPlans.values())for(const [id,plan] of plans)if(plan.notes.every(note=>note.tick+note.length<tick))plans.delete(id);
  }
  status(state,message){this.state=state;this.audio?.report?.('bot_status',{state,message})}
  get bankId(){return this.vl.route==='analytic'?ANALYTIC_BANK:this.vl.route==='diphone'?DIPHONE_BANK:this.vl.bank??VOCAL_BANKS[this.vl.language]??null}
  start(){
    const availability=vocalAvailability();
    if(availability.state==='unavailable'){this.status('unavailable',availability.message);return}
    this.chooseLyrics(this.vl.lyrics,unitRandom());
    // Its audio is rendered PCM, played only where the host plays its samples output: a card set to MIDI, or a singer
    // heard and not sounding, has no use for a phrase, so nothing is asked of the service (which would start its worker
    // for nothing). A score render's samples output makes none of its audio (audio.notesOnly): its phrases are planned
    // and committed as anywhere, and their notes reported, nothing synthesized (vocal-player.js notesOnly).
    if(this.audio?.mode!=='samples'||!this.audio.notesOnly&&typeof this.audio?.ctx?.createBufferSource!=='function')
      return this.status('unavailable','This host plays no audio for a singer here, so no phrases are rendered.');
    this.status('loading','Asking the vocal service…');
    // Not awaited by start(): a live page joins the room at once and the bot is silent until the service answers. An
    // offline render's host awaits `loading` (render/bot-host.js), so a render's singer is ready from its first bar.
    this.connecting=this.connect();
    this.loading=this.connecting;
  }
  async connect(){
    try{
      // The route: phrases rendered by the service and played (docs/VOCALS.md), or sung by a live voice on this audio thread
      // from units the service prepares (docs/VOCALS_LIVE.md, gate E), or synthesized on this page from its phones (the analytic
      // voice). The same plans, anchors and lateness every way.
      const Player=this.vl.route==='live'?LiveVocalPlayer:this.vl.route==='analytic'?AnalyticVocalPlayer:this.vl.route==='diphone'?DiphoneVocalPlayer:VocalPlayer;
      const player=new Player(this.audio,{onEvent:(kind,details)=>this.playerEvent(kind,details)});
      const status=await player.status();
      if(!status.available)return this.status('unavailable',`The vocal service is not available here: ${status.reason}`);
      const bank=status.banks?.find(entry=>entry.id===this.bankId);
      if(!bank?.installed)return this.status('unavailable',`The voicebank ${this.bankId??`for ${this.vl.language}`} is not installed; no other voice is used in its place.`);
      // (A voice that sings other languages refuses this one now, as the service would refuse each phrase.)
      if(bank.languages?.length&&!bank.languages.includes(String(this.vl.language).split('-')[0]))return this.status('unavailable',`${bank.name} sings ${bank.languages.join(', ')}, not ${this.vl.language}.`);
      this.aliases=new Set(await player.aliases(this.bankId));
      // The bank's unit times: English syllables are given their consonants' time by them (readEnglish), and a re-attack
      // leaves its rest before where the next unit will sound (reattackSec).
      if(!this.unitTimes&&player.units)this.unitTimes=await player.units(this.bankId).catch(()=>null);
      // English words are read by the bank's own phonemizer before a note is planned for them.
      if(this.pendingText){
        const read=await this.readEnglish(this.pendingText,player);this.pendingText=null;
        if(!read.ok)return this.status('unavailable',`The voicebank cannot read these words: ${read.missing.slice(0,6).join(', ')}`);
      }
      this.player=player;this.ready=true;
      this.status('ready',`${bank.name} · ${bank.rights?.license??'licence unknown'} · ${this.lyricsTitle}`);
    }catch(error){this.status('unavailable',`The vocal service did not answer: ${error.message}`)}
  }
  // (Not `heard`: that is the ensemble it hears, lib/modules/ensemble-hearing.js.)
  playerEvent(kind,details){
    if(kind==='vocal_late')this.decide({late:details.planId,revision:details.revision,lateBySec:details.lateBySec});
    if(kind==='vocal_failed')this.audio?.report?.('bot_status',{state:'limited',message:`A phrase could not be rendered: ${details.error}`});
  }
  // ---- Words --------------------------------------------------------------------------------------------------------
  // A text asked for by id, or one chosen by the seed among those with words (the vocalise only when asked for: the user
  // heard a MusebotTV take sung on ら and あ as "vocables", 2026-09-26).
  chooseLyrics(id,draw){
    // A seed chooses among the texts with words that are seeded (blake.js: the first seven); any is sung by its id.
    const own=TRADITIONAL_LYRICS.filter(entry=>entry.language===this.vl.language),worded=own.filter(entry=>entry.words!==false&&entry.seeded!==false);
    const chosen=own.find(entry=>entry.id===id)??worded[Math.floor(draw*worded.length)%worded.length];
    if(!chosen)return;
    // (A poem's own readings of its words, where it has them: smith.js.)
    this.lyricsReadings=chosen.readings??null;this.lyricsReadingsFor=chosen.title;
    this.adoptText(chosen.text,chosen.title);this.lyricsId=chosen.id;
  }
  adoptText(text,title='sent words'){
    return this.adoptUnits(this.vl.language==='en'?englishWords(text):japaneseMorae(text),title);
  }
  // Words with marked emphasis (SSML, ssml.js): segments read in the singer's language, emphasis and loudness kept.
  readSegments(segments){
    if(this.vl.language==='en')return englishUnitsFromSegments(segments);
    const units=[],unreadable=[];
    for(const segment of segments){
      if(segment.breath){units.push({kind:'breath'});continue}
      const read=japaneseMorae(segment.text);unreadable.push(...read.unreadable);
      for(const unit of read.units)units.push(unit.kind==='mora'||unit.kind==='extend'?{...unit,...(segment.emphasis?{emphasis:segment.emphasis}:{}),...(segment.volumeDb?{volumeDb:segment.volumeDb}:{})}:unit);
    }
    return {units,unreadable};
  }
  adoptUnits({units,unreadable},title){
    if(this.vl.language==='en'){
      // A word's syllables and stress are the bank's phonemizer's reading of it, asked for when the service answers
      // (readEnglish); its prominence follows (prosody.js).
      if(!units.some(unit=>unit.kind==='word'))return false;
      this.pendingText={units,title,unreadable};
      return true;
    }
    units=japaneseProminence(annotateJapaneseAccent(annotateJapaneseWords(units)));
    if(!units.some(unit=>unit.kind==='mora'))return false;
    this.units=units;this.cursor=0;this.lyricsTitle=title;this.unreadable=unreadable;
    return true;
  }
  onMessage(message){
    super.onMessage(message);
    if(message?.address==='/broadcast/vocal/plan'){this.hearPlan(message.args?.[0]);return}
    // A span of the melody's rubato said after a phrase inside it was committed: that phrase is planned again (everyTick).
    // A hold declared (clock-hold.js): its length known, a fermata's, the singer's phrases take it as every other bot's
    // notes do (hold-timing.js), since they are rendered whole, outside the engine calls hold-timing places (clockTimed).
    if(message?.address==='/broadcast/hold'){this.hearHold(message.args?.[0]);return}
    if(message?.address==='/broadcast/holdSelected'){const chosen=this.holds?.get(message.args?.[0]?.id);if(chosen)chosen.selected=message.args[0].branch??chosen.selected;return}
    if(message?.address==='/broadcast/partRubato'){const span=this.partRubatos?.find(entry=>entry.bar===message.args?.[0]?.bar);if(span)(this.partSpansHeard??=[]).push(span);return}
    // The conductor's rubato (/broadcast/rubato, clock-rubato.js): each span as the clocks will play it, revised where the
    // clock says it revised it, dropped where it refused it. The singer's phrases are rendered whole, so it places them
    // by the spans itself (timeOfTick, clockTimed), as it places holds.
    if(message?.address==='/broadcast/rubato'){this.hearSpan(message.args?.[0]);return}
    if(message?.address==='/broadcast/rubatoRevise'){const value=message.args?.[0];if(typeof value?.id==='string')(this.spanRevisions??=new Map).set(`${value.id}:${value.revision}`,value);return}
    if(message?.address==='/broadcast/rubatoRevised'){this.spanRevised(message.args?.[0]);return}
    if(message?.address==='/broadcast/rubatoRefused'){if(this.spans?.delete(message.args?.[0]?.id))this.spansChanged=true;return}
    if(message?.address!=='/broadcast/lyrics')return;
    const payload=message.args?.[0],ssml=typeof payload==='object'?payload?.ssml:null,text=typeof payload==='string'?payload:payload?.text??ssml;
    const language=typeof payload==='object'?payload?.language??'ja':'ja';
    if(typeof text!=='string'||!text.trim()||text.length>4000)return;
    if(language!==this.vl.language){this.decide({lyricsRefused:`language ${language}: this bank sings ${this.vl.language}`});return}
    // SSML marks emphasis a person wants (ssml.js); markup outside its subset refuses the text whole.
    let segments=null;
    if(typeof ssml==='string'){try{segments=parseSsml(ssml).segments}catch(error){if(error instanceof SsmlError){this.decide({lyricsRefused:error.message});return}throw error}}
    if(this.vl.language==='en'){
      const {units,unreadable}=segments?englishUnitsFromSegments(segments):englishWords(text);
      if(!units.some(unit=>unit.kind==='word'))return;
      const text60=text.slice(0,60);
      if(!this.player){this.pendingText={units,title:'sent words',unreadable};return}
      this.readEnglish({units,title:'sent words',unreadable}).then(
        read=>this.decide(read.ok?{lyricsAdopted:text60}:{lyricsRefused:read.missing.slice(0,8)}),
        error=>this.decide({lyricsRefused:error.message}));
      return;
    }
    const read=segments?this.readSegments(segments):japaneseMorae(text);
    // Words the bank cannot sing are refused whole, and said so, rather than sung around (report §15.7).
    if(this.aliases){const coverage=checkJapaneseCoverage(read.units,this.aliases);if(!coverage.ok){this.decide({lyricsRefused:coverage.missing.slice(0,8).map(entry=>entry.mora)});return}}
    if(this.adoptUnits(read,'sent words'))this.decide({lyricsAdopted:text.slice(0,60)});
  }
  // An English text read by the bank's phonemizer: adopted whole, or refused whole naming the words it cannot read. The
  // bank's unit time needs come with it, once, so that each syllable is planned long enough for its consonants.
  async readEnglish({units,title,unreadable},player=this.player){
    const [words,unitTimes]=await Promise.all([player.words(this.bankId,englishKeys(units)),
      this.unitTimes||!player.units?this.unitTimes??null:player.units(this.bankId).catch(()=>null)]);
    this.unitTimes=unitTimes;
    const read=englishSyllables(units,words,{readings:title===this.lyricsReadingsFor?this.lyricsReadings:null});
    if(!read.ok)return {ok:false,missing:read.missing};
    this.units=englishProminence(read.units);this.cursor=0;this.lyricsTitle=title;this.unreadable=unreadable;
    return {ok:true};
  }
  // The next notes' syllables, up to `count`, stopping at a breath mark once `atLeast` are taken: {lyric, prominence,
  // volumeDb} for a Japanese mora or an extended vowel, or for each syllable of an English word, sung over as many notes
  // as it has syllables. A word is not split across phrases; one that does not fit waits for the next, unless it is
  // longer than a whole phrase.
  takeSyllables(count,atLeast){
    const taken=[];
    // `before` on each syllable: the consonants sung between its vowel and the previous one (the previous word's coda,
    // then its own onset), which decide whether a glide may cross into it (prosody.js glideJoin).
    let coda=[];
    // Where the text's last sung unit is: its last syllable is marked `textEnds`, and every syllable carries `pass`, how
    // many times the text had been sung through before it (0 on the first), so a transcript shows where a poem ended and
    // whether it was begun again.
    if(this.lastSungOf!==this.units){this.lastSungOf=this.units;this.lastSungAt=this.units.findLastIndex(unit=>unit.kind==='word'||unit.kind==='mora')}
    for(let guard=0;taken.length<count&&guard<count*4+8;guard++){
      if(!this.units.length||this.vl.once&&this.cursor>=this.units.length)break;
      const index=this.cursor%this.units.length,unit=this.units[index],pass=Math.floor(this.cursor/this.units.length);
      const marked=notes=>{for(const note of notes)note.display.pass=pass;if(index===this.lastSungAt&&notes.length)notes.at(-1).display.textEnds=true;return notes};
      if(unit.kind==='word'){
        // For printed lyrics (the note reports' `lyric`): the word's written syllables, case kept, punctuation after.
        const parts=englishSyllableText(unit.text,unit.syllables,{phonemes:unit.phonemes,stress:unit.stress}),last=parts.length-1,phonemes=unit.phonemes??[];
        // `vowel` and `coda` (the consonants after the vowel, where the word ends) decide how long the syllable must be
        // for its consonants to sound whole (prosody.js consonantTicks).
        const notes=wordNotes(unit).map((lyric,i)=>({lyric,prominence:unit.prominence?.[i]??(i?0:2),volumeDb:unit.volumeDb??0,
          before:i===0?[...coda,...consonantsBefore(phonemes,0)]:consonantsBefore(phonemes,i),
          vowel:vowelOf(phonemes,i),coda:i===last?codaOf(phonemes):consonantsBefore(phonemes,i+1),
          // A poetic elision sung as the poem scans it (english.js ELISIONS): its phonemes go to the phonemizer as a hint.
          ...(i===0&&unit.hint?{hint:unit.hint}:{}),
          // An empty written part is a syllable sung but not spelled ("fire" as f ay er): printed as an extender, the
          // word before it ending there. Opening quotation marks are printed before the first syllable.
          display:{text:parts[i]??'',word:unit.text,syllable:i,syllables:parts.length,continues:i<last&&parts[i+1]!=='',melisma:parts[i]==='',language:'en',
            ...(i===0&&unit.before?{before:unit.before}:{}),...(i===last&&unit.after?{after:unit.after}:{})}}));
        if(taken.length+notes.length>count){if(taken.length)break;taken.push(...marked(notes.slice(0,count)));this.cursor++;break}
        taken.push(...marked(notes));coda=codaOf(phonemes);
      }
      else if(unit.kind==='mora'||unit.kind==='extend'&&taken.length){
        const display={text:unit.kind==='mora'?unit.text:'',word:unit.word??unit.text??'',syllable:unit.syllable??0,syllables:unit.syllables??1,
          continues:(unit.syllable??0)<(unit.syllables??1)-1,melisma:unit.kind==='extend',language:'ja',...(unit.after?{after:unit.after}:{})};
        // A mora's onset, after the previous mora's closure if it ended in っ (a stop: no voice across it).
        const before=[...(coda.length?coda:[]),...(unit.kind==='mora'?japaneseOnset(unit.text):[])];coda=[];
        taken.push(...marked([{lyric:unit.kind==='mora'?unit.text:EXTENDER,prominence:unit.kind==='mora'?unit.prominence?.[0]??0:0,volumeDb:unit.volumeDb??0,before,display,
          ...(unit.accent?{accent:unit.accent}:{})}]));
      }
      else if(unit.kind==='break')coda=['q'];   // っ: a glottal stop before the next mora
      else if(unit.kind==='breath'){
        // (A line's end, which a rapper's flow leaves a breath at.)
        if(taken.length)taken.at(-1).lineEnd=true;
        if(taken.length>=atLeast){this.cursor++;break}
      }
      this.cursor++;
    }
    return taken;
  }
  // ---- Time ---------------------------------------------------------------------------------------------------------
  // The audio time of a future tick, from the tick mapping as it stands (asked again when a phrase's audio arrives): the
  // pulses between as the clock will play them (secondsBetween: a known span of the conductor's rubato by its map). (A
  // known hold ahead, between the tick now and that one, delays it by its length: the pulses after a held one come after
  // the hold. One passed is in the clock's own times already.)
  timeOfTick(tick){
    const ref=this.clockRef;if(!ref)return NaN;
    let held=0;for(const hold of this.holdsAhead())if(hold.tick>=ref.tick&&hold.tick<tick)held+=hold.seconds;
    return ref.eventTime+this.secondsBetween(ref.tick,tick)+held;
  }
  // The seconds the clock takes from tick `a` to tick `b` (fractional; negative where b comes first), holds apart: inside
  // a known span by the span's map, after one at its last density (the clock goes on at it), elsewhere at the tempo now.
  // With no clock heard yet, at `perTick`.
  secondsBetween(a,b,perTick=NaN){
    const ref=this.clockRef;
    if(!ref)return (b-a)*perTick;
    if(b<a)return -this.secondsBetween(b,a);
    const spans=this.spansAhead();
    let seconds=0,at=a,outside=ref.secondsPerTick;
    for(const span of spans){
      if(at>=b)break;
      if(span.end<=at){outside=span.last;continue}
      if(span.tick>=b)break;
      if(span.tick>at){seconds+=(span.tick-at)*outside;at=span.tick}
      const to=Math.min(b,span.end),quarters=tick=>Math.max(0,Math.min(span.quarters,(tick-span.tick)*span.pulse));
      seconds+=span.map.timeAt(quarters(to))-span.map.timeAt(quarters(at));at=to;outside=span.last;
    }
    return seconds+Math.max(0,b-at)*outside;
  }
  // Where a committed phrase begins, in audio time: its anchor's, moved by its shift (in its own ticks, at the tempo it is
  // rendered at) where its melody's rubato brings it in early.
  phraseStart(anchor,entry){return this.timeOfTick(anchor)+(entry?.shift??0)*(entry?.secondsPerTick??0)}
  // How long a phrase's written slots last as the clock will play them.
  phraseSeconds(anchor,slots){const last=slots?.at(-1);return last?this.secondsBetween(anchor,anchor+last.at+last.length):0}
  // The spans of the conductor's rubato this singer has heard that the clock is still to play or playing, as ticks in the
  // meter now (as holdsAhead places holds): [{id, tick, end, map, pulse (a tick's quarters), quarters (the span's), last
  // (seconds a tick after it, at its last density)}], in order. The span playing is placed where the clock's pulse says
  // it is (`rubato.position`). One span plays at a time: one whose downbeat falls inside another's never begins (the
  // clock drops it, and says so: /broadcast/rubatoRefused), so it is not counted on.
  spansAhead(){
    const ref=this.clockRef,meter=ref?.meter;
    if(!this.spans?.size||!meter||!Number.isInteger(ref.bar))return [];
    const pulse=4/((Number(meter.denominator)||bandMeter().denominator)*(Number(meter.subdivision)||bandMeter().subdivision)),out=[];
    for(const {span,map} of this.spans.values()){
      const playing=ref.rubato?.id===span.id&&ref.rubato.position!=null,quarters=toNumber(map.end);
      const tick=playing?ref.tick-toNumber(ratio(ref.rubato.position))/pulse:ref.tick-ref.tickInBar+(span.bar-ref.bar)*meter.pulsesPerBar;
      if(tick+quarters/pulse>ref.tick)out.push({id:span.id,tick,end:tick+quarters/pulse,map,pulse,quarters,last:span.knots.at(-1).density*pulse});
    }
    out.sort((a,b)=>a.tick-b.tick);
    const played=[];for(const span of out)if(!played.length||span.tick>=played.at(-1).end-1e-9)played.push(span);
    return played;
  }
  // A span the conductor declares, as the clocks queue it (normalizeRubato), with its map; a revision the clock says it
  // made, applied as the clock applies it (clock-rubato.js reviseRubato: the knots from `from` on, their positions kept).
  hearSpan(value){
    let span;try{span=normalizeRubato(value)}catch{return}
    (this.spans??=new Map).set(span.id,{span,map:rubatoMap(span.knots)});
    if(this.spans.size>16)this.spans.delete(this.spans.keys().next().value);
    this.spansChanged=true;
  }
  spanRevised(value){
    const key=`${value?.id}:${value?.revision}`,revision=this.spanRevisions?.get(key),known=this.spans?.get(value?.id);
    this.spanRevisions?.delete(key);
    if(!value?.revised||!revision||!known)return;
    const knots=known.span.knots,from=revision.from;
    if(!Number.isInteger(from)||from<1||!Array.isArray(revision.knots)||revision.knots.length!==knots.length-from)return;
    const replaced=[...knots.slice(0,from),...revision.knots.map((knot,i)=>({at:knots[from+i].at,density:Number(knot?.density??knot)}))];
    if(!replaced.every(knot=>knot.density>0))return;
    const span={...known.span,knots:replaced,revision:value.revision};
    this.spans.set(span.id,{span,map:rubatoMap(span.knots)});this.spansChanged=true;
  }
  // The draws a phrase's choices take (its line, its harmony, its glides): streams of its own, seeded by the bot's seed
  // and the phrase, so that a phrase planned again chooses as it chose where what it hears is unchanged, and a revision
  // differs from the one before only where their inputs do. (Drawn afresh, each revision of a lead cascaded down a
  // choir's parts, whose check for notes unchanged it never passed: p061, 29 September.)
  phraseDraws(planId,purpose){const stream=createRandomStream(`${this.randomStream?.seed??0}:${planId}:${purpose}`);return ()=>unitRandom(()=>stream.next())}
  // The holds this singer has heard that will be held, their pulses as ticks in the meter now (hold-timing.js places
  // them so too): [{id, tick, seconds, band, bound}], in order.
  holdsAhead(){
    const ref=this.clockRef,meter=ref?.meter;
    if(!this.holds?.size||!meter||!Number.isInteger(ref.bar))return [];
    const out=[];
    for(const hold of this.holds.values()){
      if(hold.optional&&(hold.selected??hold.branch)!=='hold'||!hold.known)continue;
      const inBar=holdTick(hold,meter);if(inBar===null)continue;
      out.push({id:hold.id,tick:ref.tick-ref.tickInBar+(hold.bar-ref.bar)*meter.pulsesPerBar+inBar,seconds:hold.seconds,band:hold.band,bound:hold.bound});
    }
    return out.sort((a,b)=>a.tick-b.tick);
  }
  hearHold(value){
    let hold;try{hold=normalizeHold(value)}catch{return}
    // (A cued hold, its length unknown until its cue, is left to the clock: a phrase over it cannot be lengthened after
    // the fact, and dropping its later syllables would cut its words.)
    (this.holds??=new Map).set(hold.id,hold);
    if(this.holds.size>32)this.holds.delete(this.holds.keys().next().value);
    (this.holdsHeard??=[]).push(hold.id);
  }
  // VoiceLeadingBot calls attack() on a beat where the heard harmony changed (and would on every beat while no voicing
  // is held, so one is marked held: the singer's voicing is its line).
  attack(clock,{change}={}){this.voicing??=[];if(change)this.harmonyChangedAt=clock.tick}
  rearticulates(){return false}
  everyTick(clock){
    this.clockRef={tick:clock.tick,eventTime:this.audio?.eventTime??NaN,secondsPerTick:this.secondsPerTick(clock),bar:clock.bar,tickInBar:clock.tickInBar,meter:clock.meter,rubato:clock.rubato??null};
    this.announceDue(clock);
    // The ending (Closure: form_clodbot's closing, or the stop the ensemble committed to; bars count from 0 and the
    // ensemble stops at the downbeat of endsAt.bar): nothing is sung at or after it. A phrase already committed there is
    // withdrawn -- the closing can arrive on the very tick the phrase was committed, or only in the final bar -- and one
    // running past it is cut.
    const bar=this.barTicks(clock),ending=this.ending?.(),barStart=clock.tick-clock.tickInBar;
    // An offline render's own end counts as one (audio.renderEnd, in bars or ticks; a length in seconds is not guessed at).
    const length=this.audio?.renderEnd,renderEndTick=Number.isFinite(length?.ticks)?length.ticks:Number.isFinite(length?.bars)?barStart+(length.bars-clock.bar)*bar:Infinity;
    const endTick=Math.min(ending?barStart+(ending.endsAt.bar-clock.bar)*bar:Infinity,renderEndTick);
    if(Number.isFinite(endTick))this.keepBefore(clock,endTick);
    if(!this.ready||this.closing?.phase==='final')return;
    const bars=this.phraseBarsAt(clock),phrase=bar*bars,lead=bar*this.vl.leadBars;
    // Phrases start on every phraseBars-th bar line, each sung as its breaths allow (breathLines: one part where one
    // breath carries it). The next part at least `lead` ahead is planned (where a phrase is breathed in parts, at least
    // BREATH_LEAD_SECONDS ahead); a harmony heard to change re-plans the committed ones still open.
    const line=clock.tick-clock.tickInBar-(clock.bar%bars)*bar,next=line+phrase;
    const parts=[...this.breathLines(clock,line,phrase),...this.breathLines(clock,next,phrase),...this.breathLines(clock,next+phrase,phrase)];
    const breathed=parts.length>3,leadTicks=breathed?Math.min(lead,Math.ceil(BREATH_LEAD_SECONDS/this.secondsPerTick(clock))):lead;
    const part=parts.find(each=>each.at>clock.tick&&each.at-clock.tick>=leadTicks)??parts.at(-1);
    let anchor=part.at,phraseLength=part.length;
    // A singer entering on a phrase line in an offline render sings from it: the render waits for a phrase's audio
    // (audio.holdRender), so no lead is needed there, and a singer who waited a phrase to begin left the start of an a
    // cappella choir silent for five seconds (the user, 28 September: "we need to fix the bug where some renders have
    // silence at their beginnings"). Live, a phrase is committed its lead ahead, so that it is rendered in time.
    if(!this.committed.size&&!this.phraseSerial&&clock.tickInBar===0&&clock.bar%bars===0&&this.renderWaits()){
      anchor=clock.tick;phraseLength=this.breathLines(clock,clock.tick,phrase)[0].length;
    }
    // (A phrase begins after the one before has ended: where the phrase's length follows the meter, a change of meter
    // can put a phrase line inside a phrase already committed.)
    let sungTo=-Infinity;for(const [at,entry] of this.committed){const last=entry.slots.at(-1);if(last)sungTo=Math.max(sungTo,at+last.at+last.length)}
    if(this.vl.follow){for(const at of this.followDue)if((at>clock.tick||at===clock.tick&&this.renderWaits())&&at<endTick)this.commitFollowed(clock,at);this.followDue.clear()}
    else if(!this.committed.has(anchor)&&anchor<endTick&&anchor>=sungTo)this.plan(clock,anchor,{endTick,phraseTicks:phraseLength});
    // A harmony heard to change, or a tempo that is no longer the one a phrase was planned at (a tempo curve, mh_PlexBOT:
    // its length as the clock will now play it half a percent off the length it was planned to), re-plans the committed
    // phrases still open. One already frozen sounds as it was planned. A span of the conductor's rubato the singer has
    // heard is the time it planned by (timeOfTick), so its tempo moving on every pulse is no reason to plan again (p061,
    // 29 September: each phrase was announced 17 to 30 times while it waited, on every pulse its span moved the tempo); a
    // span heard, revised or refused since re-plans them all.
    const spansChanged=this.spansChanged;this.spansChanged=false;
    for(const [at,entry] of this.committed){
      if(at<=clock.tick)continue;
      const seconds=this.phraseSeconds(at,entry.slots),retimed=Math.abs(seconds-entry.seconds)>entry.seconds*.005;
      if(this.harmonyChangedAt===clock.tick||retimed||spansChanged)this.replanIfOpen(clock,at,{retimed:retimed||spansChanged});
    }
    // A span of the melody's rubato heard since: the committed phrases it reaches are planned again while open.
    if(this.partSpansHeard?.length){
      const pulses=Number(clock.meter?.pulsesPerBar),barStart=clock.tick-clock.tickInBar;
      for(const span of this.partSpansHeard){
        const from=barStart+(span.bar-clock.bar)*pulses,to=from+span.bars*pulses;
        for(const [at,entry] of this.committed){const last=entry.slots.at(-1);if(last&&at<to&&at+last.at+last.length>from)this.replanSoon.add(at)}
      }
      this.partSpansHeard=null;
    }
    // A hold heard since: the committed phrases sounding over its pulse are planned again while open (those after it
    // are placed by it where they come: timeOfTick).
    if(this.holdsHeard?.length){
      for(const hold of this.holdsAhead())if(this.holdsHeard.includes(hold.id))for(const [at,entry] of this.committed){
        const last=entry.slots.at(-1);if(last&&at<=hold.tick&&at+last.at+last.length>hold.tick)this.replanSoon.add(at);
      }
      this.holdsHeard=null;
    }
    // A clash another singer announced after this one committed (hearPlan), re-planned while the phrase is open.
    for(const at of this.replanSoon)if(this.committed.has(at)&&at>clock.tick)this.replanIfOpen(clock,at);
    this.replanSoon.clear();
    for(const [at] of this.committed)if(at+phrase*2<clock.tick)this.committed.delete(at);
    if(clock.tick%bar===0)this.forgetPlansBefore(clock.tick-phrase);
  }
  // Nothing sung at or after `endTick`: phrases anchored there are withdrawn (never placed, and their queued renders
  // dropped); an open phrase running past it is re-planned to end there. A frozen one sounds as planned.
  keepBefore(clock,endTick){
    for(const [at,entry] of [...this.committed]){
      if(at>=endTick){this.withdrawPhrase(entry.planId);this.committed.delete(at);this.announcePhrase(entry.planId,entry.revision+1,[]);this.decide({withdrawn:entry.planId,anchor:at,endTick});continue}
      const last=entry.slots.at(-1);
      if(at+last.at+last.length<=endTick||entry.cutAt===endTick)continue;
      const seconds=this.phraseStart(at,entry)-(this.audio?.ctx?.currentTime??0);
      if(!(seconds>this.vl.frozenSec))continue;
      const slots=entry.slots.filter(slot=>at+slot.at<endTick).map(slot=>({...slot,...(slot.scoreTime?{scoreTime:scoreTime(readScoreTime(slot).at,readScoreTime(slot).end.min(Q(endTick-at)).sub(readScoreTime(slot).at),{axis:'phrase'})}:{}),length:Math.min(slot.length,endTick-at-slot.at)}));
      if(!slots.length){this.withdrawPhrase(entry.planId);this.committed.delete(at);this.announcePhrase(entry.planId,entry.revision+1,[]);continue}
      slots.at(-1).last=true;
      this.lastPitch=entry.startPitch;
      const cut=entry.slots.filter(slot=>at+slot.at>=endTick);
      this.commitPhrase(clock,at,slots,entry.revision+1,entry.planId,{textLeft:entry.textLeft==null?null:entry.textLeft+this.unitsIn(cut)});
      this.committed.get(at).cutAt=endTick;
    }
  }
  // The words and rhythm are kept and the pitches and tempo planned again, as a new revision of the same phrase, while
  // the phrase is still outside its frozen stretch; the player replaces the older revision if it has not begun. A frozen
  // phrase is not asked again: it keeps its revision, and its tempo (docs/VOCALS.md, Limits).
  replanIfOpen(clock,anchor,{retimed=false}={}){
    if(this.vl.follow&&this.followed.has(anchor))return this.commitFollowed(clock,anchor,{retimed});
    // (Open until its frozen stretch before it sounds: where its melody's rubato brings it in early, before its anchor.)
    const entry=this.committed.get(anchor),seconds=entry?this.phraseStart(anchor,entry)-(this.audio?.ctx?.currentTime??0):NaN;
    if(!entry||!(seconds>this.vl.frozenSec)){if(entry)entry.seconds=this.phraseSeconds(anchor,entry.slots);return}
    this.lastPitch=entry.startPitch;
    this.commitPhrase(clock,anchor,entry.slots,entry.revision+1,entry.planId,{textLeft:entry.textLeft});
  }
  // ---- A phrase -----------------------------------------------------------------------------------------------------
  // A new phrase: its syllables taken from the words (a line, or as much of one as fits), then set to the phrase's
  // metrical positions as they would be spoken (prosody.js): prominent syllables toward strong positions and longer
  // notes, weak ones between. Its last felt beat is left for breath. A phrase has room for about a syllable a beat, and
  // sometimes more (subdivideChance), never more than its positions.
  // English needs time for its consonant clusters: a syllable is at least a quarter of a second, and longer where its
  // join to the next vowel needs it -- every consonant sung whole, in the bank's own recorded timing (prosody.js
  // consonantTicks; the worker's layout then keeps them whole: ConsonantLayout.cs). A phrase whose consonants need more
  // time than it has sings fewer words, and the rest wait for the next. A phrase ends at its line, so its stresses have
  // room to lengthen. Japanese morae are short and even (Japanese is mora-timed).
  // `phraseTicks`: its length as its breath allows (everyTick, breathLines); else whole bars.
  plan(clock,anchor,{endTick=Infinity,phraseTicks=null}={}){
    // A phrase the ending cuts short needs no breath after it: its last note may hold to the end.
    const english=this.vl.language==='en',beat=this.beatTicks(clock),bar=this.barTicks(clock),phrase=phraseTicks??bar*this.phraseBarsAt(clock);
    const span=Math.max(beat,anchor+phrase>endTick?endTick-anchor:phrase-beat);
    if(span<=0||anchor>=endTick)return;
    const secondsPerTick=this.secondsPerTick(clock);
    // (Its positions' strengths are its bar's: a phrase inside a long bar begins on a group, not a downbeat.)
    const offset=((anchor-(clock.tick-clock.tickInBar))%bar+bar)%bar;
    if(this.vl.flow==='rap')return this.planFlow(clock,anchor,{span,beat,offset,secondsPerTick});
    const positions=phrasePositions({meter:clock.meter,span,secondsPerTick,minSyllableSec:english?.25:.16,offset});
    const share=this.attentionShare(clock,anchor);
    const beats=Math.max(1,Math.round(span/beat)),room=Math.min(positions.length,beats+Math.round(beats*this.vl.subdivideChance*share*2*unitRandom()));
    const atLeast=english?Math.ceil(room*.35):Math.ceil(beats*.6),cursor=this.cursor;
    let syllables=this.takeSyllables(room,atLeast),placed=null;
    for(;;){
      if(!syllables.length)return;
      if(syllables[0].lyric===EXTENDER)syllables[0]={...syllables[0],lyric:syllables.find(syllable=>syllable.lyric!==EXTENDER)?.lyric??'あ'};
      const minLengths=english?consonantTicks(syllables,this.unitTimes,secondsPerTick*1000):null;
      placed=setSyllables(syllables.map(syllable=>syllable.prominence),positions,{span,beat,minLengths});
      // A phrase the singer's breath cannot carry, even at the top of its voice, did not fit either
      // (shared/performers/voice.js): fewer syllables, as for a word too long for its place.
      const breathless=Boolean(placed)&&!this.breathCarries(placed.map((place,i)=>({at:place.at,length:place.length,display:syllables[i].display})),secondsPerTick,anchor);
      if(breathless)placed=null;
      // Never fewer than the first word's syllables: a word is not cut to fit.
      if(placed||!minLengths&&!breathless||syllables.length<=(syllables[0].display?.syllables??1))break;
      this.cursor=cursor;
      syllables=this.takeSyllables(syllables.length-1,Math.min(atLeast,syllables.length-1));
    }
    // One word too heavy for the whole phrase is still sung: the worker compresses it, never past its floor.
    placed??=setSyllables(syllables.map(syllable=>syllable.prominence),positions,{span,beat});
    if(!placed)return;
    const slots=placed.map((place,i)=>({...scoreTimeFields(place),at:place.at,length:place.length,lyric:syllables[i].lyric,prominence:syllables[i].prominence,display:syllables[i].display,
      ...(syllables[i].accent?{accent:syllables[i].accent}:{}),
      before:syllables[i].before,vowel:syllables[i].vowel,coda:syllables[i].coda,...(syllables[i].hint?{hint:syllables[i].hint}:{}),
      volume:syllableVolume(syllables[i].prominence,syllables[i].volumeDb),strong:place.strength>=2,last:i===placed.length-1}));
    // A singer setting its text whole (`once`) says how much of it is left after this phrase (words, or morae).
    let textLeft=null;
    if(this.vl.once){textLeft=0;for(let i=this.cursor;i<this.units.length;i++)if(this.units[i].kind==='word'||this.units[i].kind==='mora')textLeft++}
    this.commitPhrase(clock,anchor,slots,0,`${this.voiceId}:phrase-${++this.phraseSerial}`,{textLeft});
  }
  // A rapper's phrase (shared/vocal/flow.js): as many syllables as could follow each other at the fastest its phones
  // allow, set by the flow's search on every division of the meter's groups they can be said on; the flow keeps as many
  // whole words as fit, and the rest wait for the next phrase. Its rate drawn toward faster as its share of the band's
  // attention grows (the band's attention is a budget).
  planFlow(clock,anchor,{span,beat,offset,secondsPerTick}){
    const cursor=this.cursor,share=this.attentionShare(clock,anchor);
    const fastest=syllableSteps([{vowel:'ah',coda:[]},{vowel:'ah',before:[]}])[0].least;
    let syllables=this.takeSyllables(Math.min(256,Math.floor(span*secondsPerTick/fastest)+1),1);
    if(!syllables.length)return;
    const steps=syllableSteps(syllables),shortest=Math.min(...steps.map(step=>step.least));
    const positions=flowPositions({meter:clock.meter,span,offset,secondsPerTick,shortest});
    const style={...FLOW_STYLE,targetSeconds:FLOW_STYLE.targetSeconds*2**(.5-share),breathSeconds:this.breathVoice().breath.breaths.catch?.seconds??FLOW_STYLE.breathSeconds};
    // (Its rhymes, by their sounds: each line's, and those inside its lines: flow.js markRhymes.)
    syllables=markRhymes(syllables,{remembered:this.flowMemory?.rhymes});
    const flow=planFlow({syllables,steps,positions,span,beat,secondsPerTick,style,random:unitRandom,bar:clock.meter?.pulsesPerBar,offset,memory:this.flowMemory??null});
    if(!flow){this.cursor=cursor;return}
    // (What the next phrase's flow is drawn to: this one's places in the bar, its rhyme's.)
    const rhymed=flow.placements.findIndex((place,k)=>syllables[k]?.rhyme&&!syllables[k].internal);
    // (And where each rhyme's sound last landed, so a line that rhymes with an earlier one lands its rhyme where that did.)
    const rhymes={...(this.flowMemory?.rhymes??{})},slants={...(this.flowMemory?.slants??{})};
    const keep=(map,key,at)=>{if(!key)return;delete map[key];map[key]=at;for(const old of Object.keys(map).slice(0,-FLOW_STYLE.rhymesKept))delete map[old]};
    flow.placements.forEach((place,k)=>{keep(rhymes,syllables[k]?.rhymeKey,place.inBar);keep(slants,syllables[k]?.slantKey,place.inBar)});
    this.flowMemory={motif:flow.placements.map(place=>place.inBar),rhymeAt:rhymed>=0?flow.placements[rhymed].inBar:this.flowMemory?.rhymeAt??null,rhymes,slants};
    if(flow.count<syllables.length){this.cursor=cursor;syllables=this.takeSyllables(flow.count,flow.count)}
    if(flow.fallback||flow.exhausted)this.decide({flow:flow.fallback?'fallback':'exhausted',syllables:flow.count});
    const slots=flow.placements.map((place,i)=>({...scoreTimeFields(place),at:place.at,length:place.length,lyric:syllables[i].lyric,prominence:syllables[i].prominence,display:syllables[i].display,
      before:syllables[i].before,vowel:syllables[i].vowel,coda:syllables[i].coda,...(syllables[i].hint?{hint:syllables[i].hint}:{}),
      volume:syllableVolume(syllables[i].prominence,syllables[i].volumeDb),strong:place.strength>=2,last:i===flow.placements.length-1,
      // (Its rhymes and its lines' ends, as markRhymes heard them, for whoever answers it: an ad-lib.)
      ...(syllables[i].rhyme?{rhyme:syllables[i].internal?'internal':'end'}:{}),...(syllables[i].lineEnd?{lineEnd:true}:{})}));
    let textLeft=null;
    if(this.vl.once){textLeft=0;for(let i=this.cursor;i<this.units.length;i++)if(this.units[i].kind==='word'||this.units[i].kind==='mora')textLeft++}
    this.commitPhrase(clock,anchor,slots,0,`${this.voiceId}:phrase-${++this.phraseSerial}`,{textLeft});
  }
  // How much of a glide it sings before the new syllable: its setting, or drawn once from the seed within its range, most
  // toward its top (as a string pool's glissandi hold: string-section.js).
  get glideLead(){
    const lead=this.vl.glideLead;if(typeof lead==='number'&&Number.isFinite(lead))return Math.min(1,Math.max(0,Number(lead)));
    if(this.drawnLead==null){const [low,high]=Array.isArray(lead)?lead.map(Number):[0,1],stream=createRandomStream(`${this.randomStream?.seed??0}:glide-lead`);
      this.drawnLead=Math.min(1,Math.max(0,low+(high-low)*Math.sqrt(unitRandom(()=>stream.next()))))}
    return this.drawnLead;
  }
  // How pitched it is (plan-phones.js DELIVERY): its setting, else a song's sung and a rap's drawn once from the seed.
  get pitched(){return this.vl.pitched??(this.drawnPitched??=this.vl.flow==='rap'?unitRandom()*.5:1)}
  // ---- Breath (shared/performers/voice.js: the performer contract's voice) ----
  // This singer's voice: a high or a low voice by its range, the range its own.
  breathVoice(){return this.breathModel??=breathProfile({id:this.voiceId??'singer',performer:this.voiceId??'singer',voice:this.vl.low<52?'low':'high',range:[this.vl.low,this.vl.high]})}
  // Some slots as the breath hears them: seconds from the phrase's anchor, the pitch, the singer's velocity, and the words.
  breathNotes(slots,perTick,pitches=null,anchor=null){
    const at=x=>anchor==null?x*perTick:this.secondsBetween(anchor,anchor+x,perTick);
    return slots.map((slot,i)=>({id:`s${i}`,pitch:pitches?.[i]??this.vl.high,velocity:this.vl.velocity,start:at(slot.at),end:at(slot.at+slot.length),
      ...(slot.display?{lyric:{text:slot.display.text,word:slot.display.word,syllable:slot.display.syllable,syllables:slot.display.syllables,continues:slot.display.continues,melisma:slot.display.melisma}}:{})}));
  }
  // The air a phrase at `anchor` begins with: a comfortable breath where the rest before it has room for a full one; a
  // catch breath's worth on what the phrase before left, where it has room for that; else what that phrase left.
  airBefore(anchor,perTick){
    const {breaths}=this.breathVoice().breath;let before=null;
    for(const [at,entry] of this.committed)if(at<anchor&&entry.breath&&(!before||at>before.at))before={at,breath:entry.breath};
    if(!before)return 1;
    const rest=this.secondsBetween(before.breath.endTick,anchor,perTick),left=Math.max(0,Math.min(1,before.breath.airLeft));
    return rest>=breaths.full.seconds-1e-9?1:breaths.catch&&rest>=breaths.catch.seconds-1e-9?Math.min(1,left+breaths.catch.refill):left;
  }
  // Whether the breath carries some slots at the top of the voice (a check before the pitches are chosen).
  breathCarries(slots,perTick,anchor){
    const model=this.breathVoice().breath,top=note=>breathDrain({...note,pitch:model.range[1]},model);
    return planBreaths(this.breathNotes(slots,perTick,null,anchor),{who:this.breathVoice(),initialAir:this.airBefore(anchor,perTick),drainOf:top}).status==='witness-within-declared-model';
  }
  // The phrase's breaths, placed with its pitches: {slots (the note before each breath shortened, the one after marked),
  // airLeft}. A plan the breath refuses (plan() has checked it at the top of the voice, so this is not expected) is sung
  // as it stands, and the refusal is a decision the singer reports.
  breathe(slots,perTick,pitches,anchor){
    const planned=planBreaths(this.breathNotes(slots,perTick,pitches,anchor),{who:this.breathVoice(),initialAir:this.airBefore(anchor,perTick)});
    if(planned.status!=='witness-within-declared-model'){this.decide({breath:{refused:planned.reason,alternatives:planned.alternatives?.map(item=>item.kind)}});return {slots,airLeft:0}}
    if(!planned.breaths.length)return {slots,airLeft:planned.airLeft};
    const out=slots.map(slot=>({...slot}));
    for(const breath of planned.breaths){
      if(breath.shortens)out[Number(breath.shortens.note.slice(1))].length-=breath.shortens.seconds/perTick;
      const next=out[Number(breath.before.slice(1))];next.display={...(next.display??{}),breathBefore:true};
    }
    return {slots:out,airLeft:planned.airLeft};
  }
  // The text's units (words, or morae) among some slots: those a phrase's cut leaves unsung.
  unitsIn(slots){return slots.filter(slot=>this.vl.language==='en'?slot.display?.syllable===0:slot.lyric!==EXTENDER).length}
  commitPhrase(clock,anchor,slots,revision,planId,{textLeft=null}={}){
    slots=slots.map(slot=>slot.scoreTime?slot:{...slot,scoreTime:scoreTime(Q(slot.at),Q(slot.length),{axis:'phrase'})});
    this.lineChosen=null;
    this.draws={line:this.phraseDraws(planId,'line'),harmony:this.phraseDraws(planId,'harmony'),shape:this.phraseDraws(planId,'shape')};
    const beat=this.beatTicks(clock),bar=this.barTicks(clock),startPitch=this.lastPitch,{pitches,languageMeta}=this.phrasePitches(clock,slots,anchor,planId);
    // (The line as it chose its pitches, before their tuning: what the next phrase's contour hears. line() says it.)
    const chosen=this.lineChosen?.length===slots.length?this.lineChosen:null;
    // A syllable sung again on the same vowel is re-attacked: the note before it ends REATTACK_SEC before the syllable
    // will sound (reattackSec; never the vowel late), at most a third of that note.
    const english=this.vl.language==='en',perTick=this.secondsPerTick(clock);
    const reattacked=slots.map((slot,i)=>i+1<slots.length&&sungAgain(slot,slots[i+1],english)?{...slot,length:slot.length-Math.min(slot.length/3,reattackSec(slots[i+1],this.unitTimes,english)/perTick)}:slot);
    // Its breaths (shared/performers/voice.js), with the pitches known: the note before each ends early to make its time
    // (never the next note late), and the syllable after it says so for the score (display.breathBefore).
    const {slots:sung,airLeft}=this.breathe(reattacked,perTick,pitches,anchor);
    // Each syllable at its part's own time where a span of the melody's rubato holds (partTimed), the plan's anchor
    // moved back where its first syllable comes early; a moved boundary is placed once, each length the difference of its
    // placed ends, so that no note begins before the one before it ends.
    const rubato=this.partTimed(clock,anchor,sung,english?consonantTicks(sung,this.unitTimes,perTick*1000):null);
    const timed=this.clockTimed(anchor,rubato??sung,perTick)??rubato,shift=timed?Math.min(0,timed[0].at):0;
    const trajectories=this.shape(clock,timed?timed.map(slot=>({...slot,at:slot.at-shift})):sung,pitches,this.attentionShare(clock,anchor));
    this.draws=null;
    const lengthOf=slot=>Number.isInteger(slot.length)?{n:slot.length,d:beat}:{n:Math.round(slot.length*OFFSET_RESOLUTION),d:beat*OFFSET_RESOLUTION};
    const place=at=>Math.round((at-shift)*OFFSET_RESOLUTION),fine=beat*OFFSET_RESOLUTION;
    // (A syllable off the tick grid -- a rapper's flow on a tuplet's division -- is placed at the fine resolution as a timed
    // one is, its length the difference of its placed ends: a plan's times are exact fractions, and the voice service
    // refused a phrase with a fractional numerator, every phrase of Op. 3.4's rap whose flow took a tuplet.)
    const exact=at=>Math.round(at*OFFSET_RESOLUTION),untimed=slot=>Number.isInteger(slot.at)?{start:{n:slot.at,d:beat},length:lengthOf(slot)}
      :{start:{n:exact(slot.at),d:fine},length:{n:exact(slot.at+slot.length)-exact(slot.at),d:fine}};
    const timing=i=>timed?{start:{n:place(timed[i].at),d:fine},length:{n:place(timed[i].at+timed[i].length)-place(timed[i].at),d:fine}}:untimed(sung[i]);
    const notes=sung.map((slot,i)=>({occurrenceId:`${this.voiceId}:${anchor}:${revision}:${i}`,lyric:slot.lyric,...(slot.hint?{hint:slot.hint}:{}),
      ...timing(i),pitch:{form:'semitones',semitones:pitches[i]},
      ...(slot.volume!=null&&slot.volume!==100?{volume:slot.volume}:{}),
      ...(trajectories?.[i]?.length?{trajectory:trajectories[i]}:{})}));
    const gender=Number(this.vl.gender);
    const rap=this.vl.flow==='rap',delivery=rap||this.pitched<1?{delivery:{pitched:this.pitched,layout:rap?'spoken':'sung'}}:{};
    const plan={kind:'vocal.phrase.plan',schemaVersion:1,planId,revision,voiceId:this.voiceId,bank:this.bankId,language:this.vl.language,...(gender?{gender}:{}),...delivery,
      tempo:{bpm:60/(beat*this.secondsPerTick(clock)),beatUnit:4},meter:{numerator:Math.max(1,Math.round(bar/beat)),denominator:4},notes};
    const textComplete=slots.some(slot=>slot.display?.textEnds===true);
    const last=sung.at(-1),breath=last?{endTick:anchor+last.at+last.length,airLeft}:null;
    this.committed.set(anchor,{planId,revision,slots,startPitch,secondsPerTick:perTick,seconds:this.phraseSeconds(anchor,slots),textLeft,textComplete,breath,
      ...(chosen?{line:chosen}:{}),...(shift?{shift}:{}),notes:slots.map((slot,i)=>({tick:anchor+slot.at,length:slot.length,pitch:pitches[i],lyric:slot.lyric}))});
    this.announcePhrase(planId,revision,this.committed.get(anchor).notes,{textComplete,textLeft,anchor,slots});
    // Each note's planned transport tick and printed-lyric fields travel with it to the note reports (vocal-player.js).
    const gain=LEVEL*velocityGain(this.vl.velocity,FAMILIES.lead.rangeDb,FAMILIES.lead.velocityExponent??2),anchorTime=()=>this.timeOfTick(anchor)+shift*perTick;
    this.player.commit(plan,{anchorTime,velocity:this.vl.velocity,gain,
      notes:sung.map((slot,i)=>({scoreTime:shiftScoreTime(slots[i].scoreTime,anchor,{axis:'ensemble'}),tick:anchor+slot.at,...(slot.display?{lyric:slot.display}:{}),...(languageMeta?.[i]?{pitchLanguage:languageMeta[i]}:{})}))});
    // The double: the same phrase as a second, independent take, its own voice and plan, heard and not reported as notes
    // (a score prints the line once). What its take did goes on record instead (/broadcast/vocal/double: the render's
    // decisions and its transcript): each note's lag and pitch bias, the texture relation it is (docs/PITCH_LANGUAGES.md).
    if(this.vl.double){
      const twin=doublePlan(plan,{seed:`${this.voiceId}:${planId}:${revision}`,...(this.vl.double===true?{}:this.vl.double)});
      this.player.commit(twin.plan,{anchorTime,velocity:this.vl.velocity,gain:gain*10**(twin.gainDb/20),reportNotes:false});
      try{this.broadcast('vocal/double',[{voiceId:twin.plan.voiceId,of:this.voiceId,planId:twin.plan.planId,revision,relation:'independent-double',gainDb:twin.gainDb,
        notes:sung.map((slot,i)=>({scoreTime:shiftScoreTime(slots[i].scoreTime,anchor,{axis:'ensemble'}),tick:anchor+slot.at,lagMs:Number(twin.lagsMs[i].toFixed(3)),biasCents:Number(twin.biasCents[i].toFixed(3))}))}])}
      catch{/* a host without a room: nobody to tell */}
    }
    this.decide({tick:clock.tick,phrase:planId,revision,anchor,lyrics:slots.map(slot=>slot.lyric).join(''),pitches:notes.map(note=>Number(note.pitch.semitones.toFixed(4)))});
  }
  // Each note's pitch curve (plan trajectories: offsets in beats, cents from the note's pitch), from the transitions
  // between the phrase's notes, fitted to the renderer's control grid at this tempo.
  // The melody's own rubato (HearsPartRubato: ManageBOT's /broadcast/partRubato, where drums or a steady accompaniment
  // keep the clock; 0f's proposal, SESSIONS.md 29 September 01:20): each syllable sung at its part's own time, as the
  // flute plays its notes, behind where the arch holds back and ahead where it presses on, and back with the band at its
  // span's end. The score keeps the written ticks (the note reports' tick): a performer's rubato is not written. No
  // syllable goes below the time its consonants need (`floors`, English: prosody.js consonantTicks; its written length
  // where that was less already): one the arch would squeeze keeps that time, and those after it follow as near their
  // own times as it leaves them. The breaths are placed in the written times. -> the slots at their own times (`at` and
  // `length` in ticks from the anchor, fractional), or null where nothing moves.
  partTimed(clock,anchor,slots,floors=null){
    if(!this.partRubatos?.length||!slots.length)return null;
    const own=at=>{const moved=this.partTick(anchor+at,clock);return Number.isFinite(moved)?moved-anchor:at};
    const moved=slots.map(slot=>({from:own(slot.at),to:own(slot.at+slot.length)}));
    if(moved.every((each,i)=>Math.abs(each.from-slots[i].at)<1e-9&&Math.abs(each.to-slots[i].at-slots[i].length)<1e-9))return null;
    // Syllable by syllable: one the arch would squeeze below its consonants' time keeps that time, and the next starts
    // at its own time or, where that comes first, where the one before ends. (Drawing the whole phrase toward the written
    // times instead left it none of the arch wherever one syllable was set at its consonants' least, as English often
    // is.)
    const out=[];let end=-Infinity;
    for(const [i,slot] of slots.entries()){
      const from=Math.max(moved[i].from,end),to=Math.max(moved[i].to,from+Math.min(slot.length,floors?.[i]??0));
      out.push({...slot,at:from,length:to-from});end=to;
    }
    return out;
  }
  // How far its share of the band's attention (shared/attention.js, said by ManageBOT) lets a phrase be ornamented and
  // filled, as the melody's does (papmelody_clodbot ornamentShare): in full where it is featured, the band's focus, or
  // nothing has been said; behind the focus, thinned as its allowance falls under its typical claim (its glides, and the
  // beats that carry two syllables). A singer takes no solo over its words, so there is no solo's arc; its loudness is
  // the desk's, which balances by the shares. -> 0 to 1.
  attentionShare(clock,anchor){
    const pulses=Number(clock?.meter?.pulsesPerBar)||16,barStart=Number(clock?.tick)-Number(clock?.tickInBar);
    const bar=(Number(clock?.bar)||0)+(Number.isFinite(barStart)?Math.floor((anchor-barStart)/pulses):0);
    const attention=this.attentionAt?.(bar);
    if(!attention||!Number.isFinite(attention.typicalDb)||attention.featured||attention.focus)return 1;
    return 10**(-licenseReach({allowance:attention.allowanceDb,typicalDb:attention.typicalDb}).belowDb/10);
  }
  // The phrase as the clock will play it: each syllable where a known span of the conductor's rubato puts its written
  // position (secondsBetween), in ticks of the tempo the phrase is rendered at (`perTick`); and a known hold over it
  // (holdsAhead) as hold-timing.js holds every other bot's notes (heldNote): a syllable after the held pulse's attack
  // comes after the hold; one sounding past that pulse is held the hold longer (a fermata's band) or ends there (a
  // cadenza's, which rests). Holds and spans before the phrase place its anchor (timeOfTick). -> the slots so placed
  // (ticks from the anchor, fractional), or null where no span or hold reaches the phrase.
  clockTimed(anchor,slots,perTick){
    if(!slots.length||!(perTick>0))return null;
    const end=anchor+Math.max(...slots.map(slot=>slot.at+slot.length));
    const holds=this.holds?.size?this.holdsAhead().filter(hold=>hold.tick>=anchor&&hold.tick<end):[];
    const spanned=this.spansAhead().length>0;
    if(!holds.length&&!spanned)return null;
    // (Seconds from the anchor to a written position x ticks after it.)
    const seconds=x=>spanned?this.secondsBetween(anchor,anchor+x,perTick):x*perTick;
    let out=slots.map(slot=>{const from=seconds(slot.at);return {...slot,at:from/perTick,length:(seconds(slot.at+slot.length)-from)/perTick}}),delay=0;
    for(const hold of holds){
      const at=seconds(hold.tick-anchor)+delay;
      out=out.map(slot=>{
        const placed=heldNote({offset:slot.at*perTick,duration:slot.length*perTick},{at,seconds:hold.seconds,bound:hold.bound,band:hold.band,perTick});
        return placed.drop?slot:{...slot,at:slot.at+placed.shift/perTick,length:placed.duration/perTick};
      });
      delay+=hold.seconds;
    }
    return out;
  }
  shape(clock,slots,pitches,share=1){
    if(this.vl.transitions==='none'||slots.length<2)return null;
    const beat=this.beatTicks(clock),msPerTick=this.secondsPerTick(clock)*1000,gridMs=controlGridMs(60000/(beat*msPerTick));
    const [shortest,longest]=this.vl.glideMs,draw=this.draws?.shape??unitRandom,lead=this.glideLead;
    const glides=slots.map((slot,i)=>{
      if(!i||draw()>=this.vl.glideChance*share)return null;
      // A glide joins two notes long enough to carry it and takes at most 30% of the shorter: on short syllables a
      // glide slides through the consonants and the words slur (the user heard it in the first English demo).
      const shorter=Math.min(slots[i-1].length,slot.length)*msPerTick;
      if(shorter<400)return null;
      // (Within the old vowel's time before the new syllable's consonants, half of it at most: the vowel held as long as it
      // slides. Never through a stop or a fricative: prosody.js glideJoin.)
      const join=glideJoin(this.unitTimes,slots[i-1].vowel,slot.before,slot.vowel);
      const glideMs=Math.min(shorter*.3,(slots[i-1].length*msPerTick-join.beforeMs)/2,shortest+(longest-shortest)*draw());
      return glideMs>=40?{glideMs,lead,...join}:null;
    });
    const {trajectories}=phraseTrajectories(slots.map((slot,i)=>({startMs:slot.at*msPerTick,lengthMs:slot.length*msPerTick,cents:100*pitches[i]})),
      {glides,maxCentsPerMs:90/gridMs});
    return trajectories.map((points,i)=>{
      if(points.every(point=>Math.abs(point.cents)<1e-9))return null;   // a note held on its pitch needs no curve
      // (Read on the voice's control grid: what it can follow, never a corner it would refuse.)
      const limit=Math.floor(slots[i].length*OFFSET_RESOLUTION);
      return onControlGrid(points,slots[i].length*msPerTick,gridMs).map(point=>({offset:{n:Math.min(limit,Math.round(point.atMs/msPerTick*OFFSET_RESOLUTION)),d:beat*OFFSET_RESOLUTION},cents:point.cents}));
    });
  }
  get voiceId(){return String(this.instanceId??this.definitionId??'vocal').replace(/[^A-Za-z0-9_.:@-]/g,'_')}
  // Pitch as it will sound: the bot's own intonation where no tuning bot leads, then the ensemble's tuning plan.
  tuned(pitch){const own=this.tuneOne(pitch);return this.audio?.tunePitch?this.audio.tunePitch(own):own}
  // The phrase's pitches, and each note's pitch-language ancestry (a row member's form and position, a motive note's node):
  // from the harmony heard, or from a row or a motive graph. A revision of the same phrase (a re-plan, a cut) sings the
  // pitches first given it, so the row's cursor and the graph move once a phrase.
  phrasePitches(clock,slots,anchor,planId){
    const language=this.vl.pitchLanguage;
    if(this.harmonizing)return {pitches:this.harmonized(clock,slots,anchor).map(p=>this.tuned(p)),languageMeta:null};
    if(language!=='row'&&language!=='motive')return {pitches:this.line(clock,slots,anchor).map(p=>this.tuned(p)),languageMeta:null};
    let memo=this.languagePlans.get(planId);
    if(!memo||memo.pitches.length<slots.length){memo=language==='row'?this.rowPhrase(slots.length):this.motivePhrase(slots.length);this.languagePlans.set(planId,memo)}
    this.lastPitch=memo.pitches[slots.length-1];
    return {pitches:memo.pitches.slice(0,slots.length),languageMeta:memo.meta.slice(0,slots.length)};
  }
  // A class placed in the singer's range, in the octave (the domain's period) nearest the previous pitch.
  placeClass(semitoneClass){
    const {low,high}=this.vl,last=this.lastPitch??(low+high)/2;
    let best=null;
    for(let k=-2;k<=10;k++){const p=12*k+semitoneClass;if(p<low||p>high)continue;if(best===null||Math.abs(p-last)<Math.abs(best-last))best=p}
    return best??Math.min(high,Math.max(low,12*Math.round((last-semitoneClass)/12)+semitoneClass));
  }
  rowPhrase(count){
    const steps=this.vl.rowSteps??12;
    if(!this.rowState){
      const classes=this.vl.row??(steps===12?[...FIXTURE_ROW_12]:shuffled(steps));
      const definition=rowDefinition(classes,{steps,id:`${this.voiceId}:row`});
      this.rowState={definition,instance:rowInstance(definition,{operation:'P',transposition:0}),forms:0};
    }
    const state=this.rowState,pitches=[],meta=[];
    for(let k=0;k<count;k++){
      const {members:[member],next}=state.instance.take(1);
      // Twelve classes go through the ensemble's tuning; another domain sounds in its own equal steps.
      const place=this.placeClass(member.class*12/steps),pitch=steps===12&&this.audio?.tunePitch?this.audio.tunePitch(place):place;
      pitches.push(pitch);this.lastPitch=place;
      meta.push({kind:'row',row:state.definition.id,steps,form:state.instance.form.label,position:member.position,statement:state.forms});
      if(next.statement>state.instance.statement){
        // A statement complete: the next form, prime, retrograde inversion, inversion, retrograde in turn.
        state.forms++;const operation=['P','RI','I','R'][state.forms%4];
        state.instance=rowInstance(state.definition,{operation,transposition:Math.floor(unitRandom()*steps)});
      }else state.instance=next;
    }
    return {pitches,meta};
  }
  motivePhrase(count){
    const cell=this.vl.motive??[0,1,4];
    if(!this.motiveState){
      const graph=introduce(motiveGraph(),makeMotive({pitches:cell.map(p=>p+60)}),{id:'cell'});
      this.motiveState={graph,last:'cell',turn:0};
    }
    const state=this.motiveState,pitches=[],meta=[];
    // Each phrase develops what the last one sang: transposed, inverted, answered backwards, widened, and, every fifth
    // turn, the cell itself again.
    const operators=[['transpose',()=>({by:[1,3,4,-1,-3][Math.floor(unitRandom()*5)]})],['invert',()=>({})],['retrograde',()=>({})],['expand',()=>({factor:2})],['repeat',()=>({})]];
    while(pitches.length<count){
      const [op,args]=operators[state.turn%operators.length],parent=op==='repeat'?'cell':state.last;
      state.graph=derive(state.graph,parent,op,args(),{id:`m${state.graph.nodes.length}`});
      const node=state.graph.nodes.at(-1);state.last=node.id;state.turn++;
      node.motive.pitches.forEach((p,index)=>{
        if(pitches.length>=count)return;
        const place=this.placeClass(((p%12)+12)%12);
        pitches.push(this.audio?.tunePitch?this.audio.tunePitch(place):place);this.lastPitch=place;
        meta.push({kind:'motive',node:node.id,index,op,parents:[...node.parents]});
      });
    }
    return {pitches,meta};
  }
  // The line: chord tones on strong beats and at the end, steps from the last note between, in the register, each the
  // one its contour prefers (melodic-contour.js contourCost).
  line(clock,slots,anchor=null){
    const {low,high}=this.vl,named=this.chord?[this.chord.root,this.chord.third,this.chord.fifth,this.chord.seventh].filter(pc=>pc!=null):[];
    // Other singers' pitches under each slot: this line keeps out of their unisons and octaves where it can.
    const others=slots.map(slot=>anchor==null?[]:this.othersBetween(anchor+slot.at,anchor+slot.at+slot.length));
    const clear=(p,index)=>!others[index].some(q=>doubles(p,q));
    const pool=(this.notes?.length?this.notes:this.bandOpening.chord).map(Number);
    // The chord is named on the grid and sung in the band's own tuning (harmony-hearing.js objectTuned, as its spaces
    // are): a seventh the pool sounds at 10.4 is sung there, not at the grid's 10.5 beside it.
    const classes=named.length?named.map(pc=>this.objectTuned?.(pc)??pc):pool.map(pitch=>modulo(pitch,12));
    const ladder=[];
    // A melody's ladder is a scale: the space the singer's intended dissonance chooses among those of five notes or more
    // (a pentatonic, a mode, a maqam, an eight-note scale: a line's, whose added note is a passing tone), not the chord's
    // own, which it chooses over a plain triad at a low dissonance and which left the line only the chord's tones to move
    // by, an arpeggio with no steps.
    const heard=named.length?this.space(clock,named,{voicing:false}):null;
    const melodic=heard?(heard.space.pitchClasses.length>=5?heard.space:spaceFor(heard.spaces.filter(space=>space.pitchClasses.length>=5),clamp01(this.intended(clock)))??heard.space):null;
    const scale=[...new Set([...(melodic?.pitchClasses??[]),...classes])].sort((a,b)=>a-b);
    for(let octave=3;octave<=7;octave++)for(const pc of scale){const p=12*octave+pc;if(p>=low&&p<=high)ladder.push(p)}
    ladder.sort((a,b)=>a-b);if(!ladder.length)return slots.map(()=>(low+high)/2);
    const chordTone=p=>classes.some(pc=>Math.abs(modulo(p-pc,12))<.2),onLadder=p=>ladder.some(q=>Math.abs(q-p)<.05);
    // The tones outside the ladder: the band's whole grid in its tuning (the chromatic space the hearing measures; the
    // twelve where it names none), those between neighbouring steps of the ladder.
    const grid=heard?.spaces.find(space=>space.id==='chromatic')?.pitchClasses??Array.from({length:12},(_,k)=>this.objectTuned?.(k)??k);
    const chromatic=[];
    for(let octave=3;octave<=7;octave++)for(const pc of grid){const p=12*octave+pc;if(p>low&&p<high&&!onLadder(p))chromatic.push(p)}
    const openness=Math.max(0,Math.min(1,Number(this.vl.chromatic)||0));
    let last=this.lastPitch??ladder[Math.floor(ladder.length/2)];
    // (A phrase breathed in parts: where the part before this one ended on an accented mora, this one's first falls.)
    const earlier=anchor==null?[]:[...this.committed.entries()].filter(([at])=>at<anchor).sort((a,b)=>a[0]-b[0]);
    const before=earlier.at(-1)?.[1]??null;
    const fallsIn=Boolean(before?.slots?.at(-1)?.accent?.fall);
    // The line before this phrase as its contour hears it (the phrases committed before, as the line chose them, not as
    // tuned), and the highest of the one before, so that successive phrases peak on different notes.
    const sungOf=entry=>entry.line??entry.notes.map(note=>note.pitch);
    const history=earlier.flatMap(([,entry])=>sungOf(entry)).slice(-8),previousHigh=before?Math.max(...sungOf(before)):null;
    const out=[];
    for(const [index,slot] of slots.entries()){
      // After a Japanese accented mora, its word's next mora or particle falls (japanese-accent.js): the candidates below
      // it, the nearest first -- across a breath too.
      const falls=(index>0?Boolean(slots[index-1]?.accent?.fall):fallsIn)&&slot.lyric!==EXTENDER;
      if(falls){
        // (A chord tone for a strong mora where one lies below; else any tone of the line below: the fall is the word's,
        // and a chord tone that does not fall would lose it.)
        const tones=slot.strong||slot.last||slot.prominence>=2?ladder.filter(chordTone):ladder;
        let below=afterFall(tones.length?tones:ladder,last).filter(p=>p<last);
        if(!below.length)below=afterFall(ladder,last).filter(p=>p<last);
        const free=below.filter(p=>clear(p,index)),pitch=(free.length?free:below)[0]??last;
        out.push(pitch);last=pitch;continue;
      }
      const nearest=ladder.reduce((best,p)=>Math.abs(p-last)<Math.abs(best-last)?p:best,ladder[0]);
      // Its candidates: a stressed syllable, like a strong beat, takes a chord tone; another a tone of the ladder within
      // two steps of the last note. Of them the line takes the one its contour prefers (melodic-contour.js contourCost,
      // the rules of melodies in general: proximity, regression toward the middle of the voice, the phrase's arch, one
      // climax and not the last phrase's, few repeated notes, a phrase closed by step onto a chord tone), clear of another
      // singer's unisons and octaves where it can be, drawn among the nearly best (chooseByCost). Before, a stressed
      // syllable took the chord tone nearest the last note, the last note itself where it was one: the line repeated a
      // pitch on 36-50% of its notes, where Schubert's Winterreise repeats 22% (RESEARCH_BACKLOG, "The sung line repeats
      // one pitch for long runs"), and it sank to the foot of its range under dense accents or sat at its top without.
      const tones=ladder.filter(chordTone),at=ladder.indexOf(nearest);
      const stressed=slot.strong||slot.last||slot.prominence>=2;
      const near=[...new Set([-2,-1,0,1,2].map(k=>ladder[Math.max(0,Math.min(ladder.length-1,at+k))]))];
      // A tone outside the ladder resolves by step: the next note is a ladder step beside it, above or below.
      const resolving=!onLadder(last)&&index>0;
      const beside=[ladder.findLast(p=>p<last-.05),ladder.find(p=>p>last+.05)].filter(p=>p!==undefined);
      // (A stressed syllable may also step to a tone outside the chord, an appoggiatura or a passing tone, at a cost the
      // singer's intended dissonance lowers; a phrase's last syllable is a chord tone. Any syllable but the last, not
      // resolving, may take a tone outside the ladder between the last note and a ladder step beside it: a chromatic
      // passing or neighbour tone, or on a stressed one a chromatic appoggiatura, at a cost the line's openness lowers.)
      // (Before a phrase's last syllable, only one a chord tone lies a step beside, for the last to resolve it onto.)
      const stepsOf=p=>[ladder.findLast(q=>q<p-.05),ladder.find(q=>q>p+.05)].filter(q=>q!==undefined),beforeLast=Boolean(slots[index+1]?.last);
      const passing=!slot.last&&!resolving&&openness>0?chromatic.filter(p=>(beside.some(q=>(p-last)*(p-q)<0)||Math.abs(p-last)<1.05&&beside.some(q=>Math.abs(q-p)<1.05))
        &&(!beforeLast||stepsOf(p).some(chordTone))):[];
      const candidates=resolving&&beside.length?(stressed&&tones.length?[...new Set([...beside.filter(chordTone),...(slot.last?[]:beside)])].filter(Boolean):beside)
        :stressed&&tones.length?[...new Set([...tones,...(slot.last?[]:[...near,...passing])])]:[...near,...passing];
      if(!candidates.length)candidates.push(...(tones.length?tones:near));
      const outside=p=>(stressed&&!chordTone(p)?NONCHORD_COST*(1-Math.max(0,Math.min(1,Number(this.vl.dissonance)||0))):0)+(onLadder(p)?0:CHROMATIC_COST*(1-openness));
      const sung=[...history,...out];
      const phrase={position:slots.length>1?index/(slots.length-1):0,start:out.length?out[0]:null,high:out.length?Math.max(...out):null,
        previousHigh,ending:Boolean(slot.last),strong:Boolean(slot.strong)};
      const costs=candidates.map(p=>contourCost(p,{history:sung.length?sung:[last],phrase,center:(low+high)/2,span:high-low,stable:classes,weights:LINE_WEIGHTS}).cost
        +outside(p)+(clear(p,index)?0:CLASH_COST));
      let pitch=chooseByCost(candidates,costs,(this.draws?.line??unitRandom)());
      // An accented mora whose next must fall leaves room below it: at the foot of the range the line steps up to the
      // lowest tone that has one beneath (a line that sank there had nowhere to fall to).
      if(slot.accent?.fall&&!ladder.some(p=>p<pitch-1e-6))pitch=ladder.find(p=>p>pitch+1e-6)??pitch;
      out.push(pitch);last=pitch;
    }
    this.lastPitch=last;this.lineChosen=out;
    return out;
  }
  // The phrase committed (or, with no notes, withdrawn), for the other singers to write clear of (hearPlan), and for the
  // form to follow the song: `once` (this singer sets its text whole), `textComplete` (this phrase sings the text's last
  // syllable) and `textLeft` (with once: the words, or morae, still to come after it). form_clodbot defers its ending
  // while a singer setting its text whole has not completed it, and closes after the phrase that does.
  // For a choir it says, too, the singer's part and whom it follows, and the phrase's anchor and slots: its syllables, as
  // a follower sings them in the same rhythm (followLead).
  announcePhrase(planId,revision,notes,{textComplete=false,textLeft=null,anchor=null,slots=null}={}){
    try{this.broadcast('vocal/plan',[{voiceId:this.voiceId,planId,revision,notes:notes.map(note=>({tick:note.tick,length:note.length,pitch:Number(note.pitch.toFixed(4)),...(note.lyric!=null?{lyric:note.lyric}:{})})),
      once:this.vl.once===true,textComplete:textComplete&&notes.length>0,...(textLeft==null?{}:{textLeft}),
      part:isPart(this.vl.part)?this.vl.part:null,follows:this.vl.follow?this.leadId??this.vl.follow:null,
      ...(anchor!=null&&slots?{anchor,slots}:{})}])}
    catch{/* a host without a room: nobody to tell */}
  }
  // Each sung note is announced on its own tick as this bot's line (/broadcast/voices), as the voice leaders announce theirs.
  announceDue(clock){
    for(const [,entry] of this.committed)for(const note of entry.notes)if(note.tick===clock.tick&&note.lyric!==EXTENDER)this.announce(clock,[note.pitch],'line');
  }
  // A phrase no longer wanted, and its double with it.
  withdrawPhrase(planId){
    this.player?.withdraw?.(this.voiceId,planId);
    if(this.vl.double)this.player?.withdraw?.(`${this.voiceId}:double`,`${planId}:double`);
  }
  stop(){this.player?.stop();super.stop?.()}
}

// A row over n classes, in an order the render's seed chooses.
function shuffled(n){const out=Array.from({length:n},(_,i)=>i);for(let i=n-1;i>0;i--){const j=Math.floor(unitRandom()*(i+1));[out[i],out[j]]=[out[j],out[i]]}return out}

export const singerBot=defineBot(
  {
    id:'clodbot_singerbot',name:'clodbot_singerbot',status:'native',source:'clodbot',
    category:'melody',performanceType:'monophonic',outputModes:['samples'],placedNotes:true,pitchContract:'floating-mpe',nativeTuning:true,
    // A voice at the desk, not a second instrumental lead: alone in front, in the middle (the Mixbot's `vocal` role).
    deskRole:'vocal',
    // The settings a render spec may give it (the bot host's definition.specSettings): its words (a TRADITIONAL_LYRICS id),
    // their language, `once` (a poem set whole: the song lasts as long as its words), `route` ('render', 'live' or 'analytic'),
    // `double` (an independent second take) and `intonation` (where no tuning bot leads: 'just', its own, the default; or
    // 'equal', a tempered band's, as a singer with a piano sings: native-tuning.js).
    specSettings:Object.freeze(['lyrics','language','once','route','double','pitchLanguage','rowSteps','part','follow','gender','phraseSeconds','bank','breath','intonation','chromatic','flow','pitched','adlib']),
    // Its instrument is a voicebank the Musebots server renders from; without the server it is silent and says so.
    requiresCorpus:true,availability:()=>vocalAvailability(),
    description:'A singer: words from /broadcast/lyrics or a traditional Japanese song, sung mora by mora to a line it plans a phrase ahead in the harmony it hears, rendered by the vocal service through OpenUtau and a recorded voicebank (Meilin, CC BY 3.0 TW) at exact floating pitches and placed on the ensemble\'s beat; silent, and saying so, where the service is not available.',
  },
  (...args)=>new SingerBot(...args),
);

// The same singer in English: the Milk voicebank ("Milk - English -"), a poem from William Blake's Songs of Innocence and
// of Experience unless it is sent words. A render spec cannot set a bot's language (HeadlessBot passes on only a fork's
// settings), so a band that wants English words -- MusebotTV's -- names this id.
export const singerBotEn=defineBot(
  {
    id:'clodbot_singerbot_en',name:'clodbot_singerbot_en',status:'native',source:'clodbot',
    category:'melody',performanceType:'monophonic',outputModes:['samples'],placedNotes:true,pitchContract:'floating-mpe',nativeTuning:true,
    deskRole:'vocal',
    // The settings a render spec may give it (the bot host's definition.specSettings): its words (a TRADITIONAL_LYRICS id),
    // their language, `once` (a poem set whole: the song lasts as long as its words), `route` ('render', 'live' or 'analytic'),
    // `double` (an independent second take) and `intonation` (where no tuning bot leads: 'just', its own, the default; or
    // 'equal', a tempered band's, as a singer with a piano sings: native-tuning.js).
    specSettings:Object.freeze(['lyrics','language','once','route','double','pitchLanguage','rowSteps','part','follow','gender','phraseSeconds','bank','breath','intonation','chromatic','flow','pitched','adlib']),
    requiresCorpus:true,availability:()=>vocalAvailability(),
    description:'A singer in English: words from /broadcast/lyrics or a poem from William Blake\'s Songs of Innocence and of Experience, each word over as many notes as it has syllables and set as it is spoken, to a line it plans a phrase ahead in the harmony it hears, rendered by the vocal service through OpenUtau and the "Milk - English -" voicebank at exact floating pitches and placed on the ensemble\'s beat; silent, and saying so, where the service is not available.',
  },
  (send,audio,settings={})=>new SingerBot(send,audio,{language:'en',...settings}),
);
