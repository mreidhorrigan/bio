// meterform_clodbot: a form bot for rhythm. The user, 25 September 2026: "provide the musebots with a type of formbot
// that handles rhythm as I described, with an underlying meter and rhythmic dissonances overtop. From there, the bots
// themselves will handle a variety of groupings, et cetera." And: "if 13 is specified as the home meter for the piece,
// the piece needs to be structured around 13-beat bars and grouping dissonances that resolve back to them." New, not a
// fork: no earlier bot does this.
//
// It holds the piece's meter as its home: the meter the piece is declared in (a render's transport meter, a room's at
// its first tick), and every bar of the piece is a home bar, however long (research/HOME_TIME_SIGNATURE_DESIGN.md,
// public/shared/metric-home/). Over the home bars, now and then, a grouping dissonance: groups of another length laid
// across one home bar or a few, crossing the bar lines where they fall, the last group taking whatever length is left so
// that the dissonance lands on a home downbeat (the resolve rule, metric-home/resolve.js; the user: "the final bar - a
// different length - functions as the resolution ... So, don't 'repair' or 'omit' - 'resolve'"); then the home's own
// grouping again. 25/8 heard in 2/4 is one bar grouped 4+4+4+4+4+5 eighths; a hemiola, groups of 2 across bars of 3.
//
// It proposes each bar's grouping a bar ahead (/broadcast/timeSignature: the home meter, its groups the part of the
// dissonance that falls in that bar), so every bot keeps time in it, and it says what it is doing (/broadcast/meterForm:
// the home, and a dissonance's groups across its whole span, in beats from the span's first downbeat), so bots can phrase
// across the bar lines as the dissonance does.
//
// What it chooses, by its own seeded random source and its taste (settings.dissonance, moved by the ensemble's
// character): whether a span stays home or departs, a home bar at least between departures and none in an ending; the
// dissonance's group length (one sharing no factor with the bar clashes most, and is likelier); and how many home bars it
// spans (enough for its group to sound twice). It counts home time from the bars actually played: a bar of another length
// (another bot's meter change) puts the home downbeat elsewhere, and it resolves that too, by a bar of whatever length is
// left, before the home bars go on.
//
// Now and then a departure is a metric modulation instead (research/metric-modulation-specification.md; the user's
// request: "metric modulations and changes can occur, but they must always 'resolve' to the underlying time"). The home
// meter's bars at a tempo in a small ratio to the home's, "old beat = new beat": at a/b (half time 2/1, double time 1/2,
// 3/2, 2/3, 4/3, 3/4), b bars fill a home bars exactly, so the home downbeat after them is where home time puts it.
// - It steps into the new tempo and back at the bar lines (a /broadcast/tempoCurve of no bars: shared/tempo-curve.js).
// - It counts each modulated bar as its ratio of home time.
// - It modulates only once every part is back in the home: the parts' own groupings (/broadcast/grouping) have landed.
//
// And now and then a departure regroups the home bar itself (the user, 28 September 2026: "We need the ability to have
// multiple subdivisions of the same meter playing in sequence or sometimes against each other; for example, 9/8 as 3x3
// and 9/8 as 5+4 simultaneous and/or in sequence ... The same applies for any meter; 25/8, 107/16, et cetera"): for a
// home bar or a few, each bar (each of a long bar's sections) in near-equal parts of its own, each part heard in its
// cells (9 as 5+4 where the home is 3+3+3, 25 as 7+6+6+6 or 5 x 5, 107/16's halves each in two), or its cells regrouped
// (9 as 3+3+3 where the home is 5+4), then the home again: the bars' groupings in sequence. The parts that hear their
// own groupings may hold the home against it, or regroup otherwise (grouping-choice.js): the groupings against each
// other.
import {defineBot} from '../../framework/index.js';
import {Agent} from '../../framework/agent.js';
import {unitRandom} from '../../shared/stochastic.js';
import {secondsPerTick} from '../../shared/meter-tactus.js';
import {Rational} from '../../transcript/rational.js';
import {groupCounts,groupsByBar,regroupings,scansionFirst} from '../../shared/metric-home/grouping.js';
import {resolveExcursion} from '../../shared/metric-home/resolve.js';
import {crossGroupings,nestedGrouping} from '../../shared/metric-home/nested.js';
import {sectionLevels} from '../../shared/metric-home/sections.js';
import {Closure} from '../lib/modules/closure.js';
import {tempoRange} from '../../shared/tempo-range.js';
import {createRandomStream} from '../../random-source.js';

// ---- Choices ---------------------------------------------------------------------------------------------------
export const METER_FORM=Object.freeze({
  dissonance:.45,            // its taste: how likely a span departs from home, at a character of one half
  characterShift:.3,         // how far the ensemble's complexity (0-1, about one half) moves that
  homeBarsBetween:1,         // home bars at least between two dissonances (the home heard before it is left)
  soundsAtLeast:2,           // a dissonance spans enough home bars for its group to sound this many times
  maxBars:4,                 // and at most this many
  modulationBars:32,         // a modulation's bars at most where the piece's end is not known (a live room's; ours)
  sharedFactorWeight:.25,    // a group length sharing a factor with the bar, against one sharing none
  longestGroupSeconds:5,     // the longest group it lays over the bars (ours: a group a listener hears as one)
  shortestGroupSeconds:.1,   // and the shortest: a beat's lower limit (London 2012), so 32nds at 200 are regrouped in 3s
  decisionsKept:512,
  // Of its departures, the share that modulate the tempo by a small ratio, "old beat = new beat" (a metric modulation:
  // research/metric-modulation-specification.md; the user's request, "metric modulations and changes can occur, but they
  // must always 'resolve' to the underlying time"), rather than regroup the bars. Ours.
  modulation:.3,
  // The ratios it may modulate by, the new beat's length over the old one's, a/b: any in lowest terms (2/1 half time, 1/2
  // double time, 3/2, 4/3, 7/4, 11/8 ...) whose bars fit before the piece's last and whose tempo the clocks play, the
  // smaller integers likelier (the specification's safeguard, as weights: (a + b) to the -3, so that however many larger
  // ratios fit, they are a quarter of the draws or so); no list of ratios (the owner, 2 October 2026: "make sure EVERY
  // tuplet ratio is allowed ... even though some are quite unlikely. NO HARDCODING OF TUPLETS"). a home bars hold b bars
  // of the home meter at the home tempo times b/a exactly, so each lands on a home downbeat.
  // (The clocks' range is the home meter's: the notated beat's, or its named tempo unit's, shared/tempo-range.js.)
  // A home bar longer than a group heard as one (longestGroupSeconds) is heard in sections (metric-home/nested.js;
  // RESEARCH_BACKLOG P1, "Extreme meters, made perceptible"): a split it chooses among the best `sectionsOffered`, each
  // top-level section at a dynamic of its own, one louder and the rest `sectionContrast` softer (the user: "grouped into
  // larger sections with distinguishable differences between them"). Ours.
  sectionsOffered:6,sectionContrast:.25,
  // Only a bar of more units than two levels of groups hold is heard in layers: with cells of about three and at most
  // three groups under one (grouping.js MAX_GROUPS_UNDER_ONE), 27; a longer bar needs a third level, however fast it goes.
  // A bar heard as one group (a figure: 103/32 at a quarter of 200 is 3.9 s) has its groups of groups for its layers, the
  // top ones at dynamics of their own as a long bar's sections are; a longer bar has sections, and their groups under them.
  sectionAbove:27,
  // Of a sectioned home's regroupings, the share laid within one section, against the section's own groups, resolving
  // at its end (a hemiola at its level: 70 as seven 10s against 35 + 35), rather than across the bar. Ours.
  withinSection:.65,
  // A sectioned home needs them (the user, 27 September 2026: "massively large-denominator prime meters probably actually
  // REQUIRE hemiola-like grouping dissonances in order to become perceptible"): the share of its bars, the first and the
  // last among them, in which one section is regrouped against its own groups, resolving where it ends, while the bar's
  // other sections hold the home. In an ending the bar's last section is left to cadence. None where its taste is none.
  // And never two bars together without one, nor a piece of one bar (a form of minutes) without its one. Its other
  // departures come as they come in any home, in the bars left without one. Ours.
  sectionedRegrouping:.8,
  // Of its departures that do not modulate, the share that regroup the home bar itself (in parts of its own, or its cells
  // otherwise) rather than lay groups of another length across the bars, and, of a sectioned home's bars that need a
  // regrouping, the share regrouped whole (each section in parts) rather than within one section; the least units in a
  // part; and the most parts to a bar (or to a long bar's section). Its regrouping choices are drawn from a stream of
  // their own, so its other choices stay as they were. Ours.
  regrouping:.4,leastPart:4,mostParts:8,
});

// (A home-length bar carries the home's sections and their dynamics; a bar of another length, which resolves, does not.)
// A regrouped bar (`levels`) carries its own levels as its sections: under a long bar's, whose top level and dynamics it
// keeps.
const meterOf=(numerator,home,groups,levels=null)=>({numerator,denominator:home.denominator,subdivision:home.subdivision,phraseBars:home.phraseBars,groups:[...groups],
  ...(home.tempoUnit?{tempoUnit:home.tempoUnit}:{}),
  ...(home.metricReading&&numerator===home.numerator&&groups.join()===home.groups.join()?{metricReading:home.metricReading}:{}),
  ...(home.fixedDenominator?{fixedDenominator:true}:{}),
  ...(levels?.length&&numerator===home.numerator?{sections:levels.map(level=>[...level]),...(home.sectionDynamics?{sectionDynamics:[...home.sectionDynamics]}:{})}
    :home.sections&&numerator===home.numerator?{sections:home.sections.map(level=>[...level]),sectionDynamics:[...home.sectionDynamics]}:{})});
const sameLength=(a,b)=>a&&b&&a.numerator===b.numerator&&a.denominator===b.denominator;
const sameGroups=(a,b)=>(a?.groups??[]).join('+')===(b?.groups??[]).join('+');
// (A bar's sections and their dynamics are part of it: a long bar's sections must reach the clock even where their
// cells happen to be the meter's own most-threes, as 103 as 72 + 31 is.)
const sameSections=(a,b)=>JSON.stringify(a?.sections??null)===JSON.stringify(b?.sections??null)&&JSON.stringify(a?.sectionDynamics??null)===JSON.stringify(b?.sectionDynamics??null);
const sameBar=(a,b)=>sameLength(a,b)&&sameGroups(a,b)&&sameSections(a,b)&&a.tempoUnit===b.tempoUnit&&JSON.stringify(a.metricReading)===JSON.stringify(b.metricReading);
const gcd=(a,b)=>{while(b)[a,b]=[b,a%b];return a};
// Most-threes of a span, as the form bot hears a bar it has not grouped otherwise (bots may hear it otherwise).
const groupsOf=units=>scansionFirst(groupCounts(units));
// A span's groups cut at every bar line: each bar's part of them (metric-home/grouping.js, where the parts find it too).
export {groupsByBar};

// The modulations a home at `bpm` may take with `limit` of the transport's bars before its last: every a/b in lowest
// terms, b within the limit (METER_FORM.modulationBars where none is known), a as many as the clocks' range allows,
// its tempo bpm b/a within it, weighted (a + b) to the -3 (METER_FORM.ratios' account). -> [{a, b, bpm, weight}].
export function modulationOptions({home,bpm,limit=Infinity}){
  const [low,high]=tempoRange(home),options=[],gcd=(x,y)=>y?gcd(y,x%y):x;
  const most=Number.isFinite(limit)?limit:METER_FORM.modulationBars;
  for(let b=1;b<=most;b++)for(let a=1;a<=Math.ceil(b*high/low);a++){
    if(a===b||gcd(a,b)!==1)continue;
    const tempo=bpm*b/a;
    if(tempo>=low&&tempo<=high)options.push({a,b,bpm:tempo,weight:(a+b)**-3});
  }
  return options;
}
export class MeterFormClodbot extends Closure(Agent){
  constructor(send,audio,settings={}){
    super(send,audio);
    this.settings={dissonance:METER_FORM.dissonance,modulation:METER_FORM.modulation,regrouping:METER_FORM.regrouping,...settings};
    this.home=null;this.barLength=null;this.homeTime=Rational.ZERO;this.homeBpm=null;
    this.queue=[];this.span=null;this.lastDissonanceBar=-Infinity;this.decisions=[];this.partsBusyUntil=-Infinity;
  }
  // The parts' own groupings (/broadcast/grouping: bots/lib/modules/grouping-choice.js): the bar the last of them lands
  // on. It modulates only once every part is back in the home.
  onMessage(message){
    const value=message?.args?.[0];
    if(String(message?.address??'').endsWith('/grouping')&&value&&value.kind!=='home'&&value.kind!=='follow'&&Number.isSafeInteger(value.startsAtBar)&&Number.isSafeInteger(value.bars))
      this.partsBusyUntil=Math.max(this.partsBusyUntil,value.startsAtBar+value.bars);
    return super.onMessage?.(message);
  }
  decide(entry){this.decisions.push(entry);if(this.decisions.length>METER_FORM.decisionsKept)this.decisions.shift()}
  // Its regrouping choices' own stream.
  regroupRandom(){this.regroupStream??=createRandomStream(`${this.settings.seed??0}:${this.seedIdentity??'meterform'}:regroup`);return this.regroupStream.next()}
  // How likely a span departs: its taste, moved by the ensemble's complexity.
  intended(){
    const complexity=Number(this.character?.complexity);
    return Math.max(0,Math.min(1,this.settings.dissonance+(Number.isFinite(complexity)?(complexity-.5)*METER_FORM.characterShift*2:0)));
  }
  // The home: the meter the piece is in when it begins, grouped as declared (most-threes where it is not).
  adoptHome(clock){
    const meter=clock.meter,groups=Array.isArray(meter.groups)&&meter.groups.reduce((a,b)=>a+b,0)===meter.numerator?meter.groups:groupsOf(meter.numerator);
    this.home={numerator:meter.numerator,denominator:meter.denominator,subdivision:meter.subdivision,phraseBars:meter.phraseBars,groups:[...groups],
      ...(meter.tempoUnit?{tempoUnit:meter.tempoUnit}:{}),...(meter.metricReading?{metricReading:meter.metricReading}:{}),...(meter.fixedDenominator?{fixedDenominator:true}:{})};
    this.barLength=new Rational(meter.numerator,meter.denominator);
    this.unitSeconds=secondsPerTick(clock)*meter.subdivision;
    this.homeBpm=Number(clock.bpm)>0?Number(clock.bpm):null;
    // A bar longer than a group heard as one is heard in sections: the declared ones, else its own choice of them, and
    // their cells are the home's groups.
    const declared=sectionLevels(meter);
    if(declared){this.home.sections=declared;this.home.sectionDynamics=Array.isArray(meter.sectionDynamics)?[...meter.sectionDynamics]:declared[0].map(()=>1)}
    // (Never over a grouping the piece declares: only its most-threes, or none, gives way to the sections' cells.)
    else if(meter.numerator>METER_FORM.sectionAbove&&groups.join('+')===groupsOf(meter.numerator).join('+')){
      const nested=nestedGrouping(meter.numerator,{unitSeconds:this.unitSeconds,longestSeconds:METER_FORM.longestGroupSeconds,
        choose:(splits,depth)=>depth===0?splits[Math.floor(unitRandom()*Math.min(METER_FORM.sectionsOffered,splits.length))]:splits[0]});
      // Every level above the cells: the sections and the groups of groups under them.
      const levels=nested.levels.filter(level=>level.spans.length>1&&level.spans.length<nested.cells.length).map(level=>[...level.spans]);
      if(levels.length){
        const loud=Math.floor(unitRandom()*levels[0].length);
        this.home.groups=[...nested.cells];this.home.sections=levels;
        this.home.sectionDynamics=levels[0].map((_,index)=>index===loud?1:1-METER_FORM.sectionContrast);
        this.decide({tick:clock.tick,sections:levels,sectionDynamics:[...this.home.sectionDynamics]});
      }
    }
  }
  // A regrouping within one section of a sectioned home, against the section's own groups (the level below's sections in
  // it where there are more than one, else its cells), ending where the section ends: equal groups across them (a hemiola
  // at their level), or groups of one length resolved (metric-home/nested.js crossGroupings). A top-level section where
  // one may be regrouped, else one a level down. `first` false keeps the bar's first section as it is (a piece's first
  // bar: the home heard before it is left), `last` false its last top-level section (an ending's, which cadences).
  // {section (the top-level one it is in), level, start, length, groups (the bar's), inner (the section's), kind}, or null.
  sectionDissonance({first=true,last=true}={}){
    const levels=this.home.sections;if(!levels)return null;
    const within=(list,from,to)=>{const out=[];let at=0;for(const size of list){if(at>=from&&at+size<=to)out.push(size);at+=size}return out};
    const spansOf=list=>{let at=0;return list.map(length=>{const span={start:at,length};at+=length;return span})};
    const top=spansOf(levels[0]),lastStart=top.at(-1).start,{shortest,longest}=this.groupLengths();
    for(let level=0;level<levels.length;level++){
      const eligible=spansOf(levels[level]).filter(span=>(first||span.start>0)&&(last||span.start+span.length<=lastStart));
      if(!eligible.length)continue;
      const {start,length}=eligible[Math.floor(unitRandom()*eligible.length)],end=start+length;
      const sub=level+1<levels.length?within(levels[level+1],start,end):[],own=sub.length>1?sub:within(this.home.groups,start,end);
      const options=crossGroupings(length,own,{longest,shortest});
      if(!options.length)continue;
      const chosen=options[Math.floor(unitRandom()*options.length)];
      return {section:top.findLastIndex(span=>span.start<=start),level,start,length,inner:[...chosen.groups],kind:chosen.kind,
        groups:[...within(this.home.groups,0,start),...chosen.groups,...within(this.home.groups,end,this.home.numerator)]};
    }
    return null;
  }
  homeBar(){return meterOf(this.home.numerator,this.home,this.home.groups)}
  // The group lengths it may lay, in the home's units: from a beat's lower limit (2 at least) to a group heard as one.
  groupLengths(){
    return {shortest:Math.max(2,Math.ceil(METER_FORM.shortestGroupSeconds/this.unitSeconds-1e-9)),longest:Math.max(2,Math.floor(METER_FORM.longestGroupSeconds/this.unitSeconds))};
  }
  // A dissonance from here: its group length (2 beats to the longest group a listener hears as one, not the bar's own
  // length), weighted by the clash it makes with the bar; the home bars it spans (enough for its group to sound twice);
  // its groups across the span, resolved; and each bar's part of them. A length that would leave every bar grouped as
  // home is no dissonance, and is passed over. {length, bars, groups, perBar, resolution}, or null.
  // `limit`: the bars it may take before the piece's final bar (barsBeforeEnd).
  dissonance(limit=Infinity){
    const n=this.home.numerator,{shortest,longest}=this.groupLengths(),options=[];
    for(let length=shortest;length<=longest;length++){
      if(length===n)continue;
      const bars=Math.min(METER_FORM.maxBars,Math.max(1,Math.ceil(METER_FORM.soundsAtLeast*length/n)));
      if(bars>limit)continue;
      const resolved=resolveExcursion(this.home,{bars:[{numerator:length,denominator:this.home.denominator}],at:this.homeTime,cycles:bars});
      const groups=resolved.bars.map(bar=>bar.numerator),perBar=groupsByBar(groups,n);
      if(perBar.every(barGroups=>barGroups.join('+')===this.home.groups.join('+')))continue;
      options.push({length,bars,groups,perBar,resolution:resolved.resolution.kind,weight:gcd(length,n)===1?1:METER_FORM.sharedFactorWeight});
    }
    if(!options.length)return null;
    let draw=unitRandom()*options.reduce((sum,option)=>sum+option.weight,0),chosen=options.at(-1);
    for(const option of options){draw-=option.weight;if(draw<=0){chosen=option;break}}
    return chosen;
  }
  // The home bar regrouped from here (metric-home/grouping.js regroupings): each bar (each of a long bar's top-level
  // sections) in near-equal parts of at least leastPart units, each part in its cells, or its cells regrouped; never the
  // home's own grouping, nor a cell shorter than a beat's lower limit. For a home bar or a few (at most maxBars, and no
  // further than `limit`). {groups (across the span), perBar, levels, parts, count, bars}, or null.
  regroup(limit=Infinity){
    if(!(limit>=1))return null;
    const {shortest}=this.groupLengths(),tops=this.home.sections?[...this.home.sections[0]]:[this.home.numerator];
    const options=regroupings(tops,{least:Math.max(METER_FORM.leastPart,shortest),most:METER_FORM.mostParts,home:this.home.groups,cells:!this.home.sections})
      .filter(option=>option.groups.every(cell=>cell>=shortest));
    if(!options.length)return null;
    const chosen=options[Math.floor(this.regroupRandom()*options.length)],bars=1+Math.floor(this.regroupRandom()*Math.min(METER_FORM.maxBars,limit));
    return {...chosen,bars,perBar:Array.from({length:bars},()=>[...chosen.groups]),groups:Array.from({length:bars},()=>chosen.groups).flat()};
  }
  // A metric modulation from here: a ratio a/b, over a home bars, which hold b bars of the home meter at the home tempo
  // times b/a exactly and so land on a home downbeat; its tempo within the clocks' range; its b bars before the piece's
  // final bar. Only while no part is mid-way through a grouping of its own: under a part's cross-rhythm a modulation would
  // leave it no home downbeat to land on. Weighted to the smaller integers. {a, b, bpm}, or null.
  modulation(limit,startsAtBar){
    if(!(this.homeBpm>0)||this.partsBusyUntil>startsAtBar)return null;
    const options=modulationOptions({home:this.home,bpm:this.homeBpm,limit});
    if(!options.length)return null;
    let draw=unitRandom()*options.reduce((sum,option)=>sum+option.weight,0),chosen=options.at(-1);
    for(const option of options){draw-=option.weight;if(draw<=0){chosen=option;break}}
    return chosen;
  }
  // The bars a span from `startsAtBar` may take before the piece's final bar, which stays home: an offline render's own
  // end (audio.renderEnd, in bars, as the singer reads it), so that no dissonance is left open when the render stops.
  // Infinity where no end is known.
  barsBeforeEnd(startsAtBar){
    const bars=Number(this.audio?.renderEnd?.bars);
    return Number.isSafeInteger(bars)&&Number.isSafeInteger(startsAtBar)?bars-1-startsAtBar:Infinity;
  }
  // The next span, from a home downbeat: a home bar, or a dissonance across home bars resolved to the downbeat it spans to.
  // `startsAtBar`: the transport's bar it begins on, which /broadcast/meterForm states, so a part (bots/lib/modules/
  // grouping-choice.js) can hear the span from its first bar.
  planSpan(clock,startsAtBar){
    const [bar]=this.homeTime.divmod(this.barLength);
    // No departure in an ending (Closure: the approach, cadence and final bars), nor before the home is heard.
    const ending=this.closingAt?.(clock)?.phase??'none',rested=bar-this.lastDissonanceBar>METER_FORM.homeBarsBetween;
    const limit=this.barsBeforeEnd(startsAtBar);
    // A sectioned home's bar regrouped within one of its sections, as it needs (METER_FORM.sectionedRegrouping): no home
    // bar is wanted before or after it, since the bar's other sections hold the home. (None past the piece's last bar.)
    const overdue=bar-(this.lastRegroupedBar??-1)>=2||(bar===0&&limit===0);
    const wanted=this.home.sections&&this.settings.dissonance>0&&ending!=='after'&&limit>=0&&(unitRandom()<METER_FORM.sectionedRegrouping||overdue);
    // (Some of those bars regrouped whole, each section in parts of its own: not the first, nor one in an ending.)
    const whole=wanted&&bar>0&&ending==='none'&&limit>=1&&this.regroupRandom()<this.settings.regrouping?this.regroup(Math.min(limit,1)):null;
    const needed=wanted&&!whole?this.sectionDissonance({first:bar>0,last:ending==='none'&&limit>=1}):null;
    const depart=!needed&&!whole&&bar>0&&rested&&ending==='none'&&limit>=1&&unitRandom()<this.intended();
    const modulated=depart&&unitRandom()<this.settings.modulation?this.modulation(limit,startsAtBar):null;
    // (A sectioned home's other regroupings are mostly within one section too, resolving at its end.)
    const within=needed??(depart&&!modulated&&this.home.sections&&unitRandom()<METER_FORM.withinSection?this.sectionDissonance():null);
    // (Or the home bar regrouped: its groupings in sequence.)
    const regrouped=whole??(depart&&!modulated&&!within&&this.regroupRandom()<this.settings.regrouping?this.regroup(limit):null);
    const chosen=depart&&!modulated&&!within&&!regrouped?this.dissonance(limit):null;
    if(modulated){
      // The home meter's bars at the new tempo, the first stepped into at its bar line, the home downbeat after the last
      // stepped back to (onTick).
      const {a,b,bpm}=modulated;
      this.span={kind:'modulation',fromBar:bar,bars:b,homeBars:a,ratio:[a,b],bpm,groups:Array.from({length:b},()=>this.home.groups).flat()};
      this.queue=Array.from({length:b},(_,index)=>({...this.homeBar(),ratio:new Rational(a,b),bpm,...(index===0?{enter:true}:{})}));
      this.lastDissonanceBar=bar+a-1;
    }else if(within){
      this.span={kind:'dissonance',fromBar:bar,bars:1,length:within.inner[0],groups:[...within.groups],resolution:within.kind,
        within:{section:within.section,level:within.level,start:within.start,length:within.length,groups:[...within.inner],kind:within.kind}};
      this.queue=[meterOf(this.home.numerator,this.home,within.groups)];
      this.lastDissonanceBar=bar;this.lastRegroupedBar=bar;
    }else if(regrouped){
      this.span={kind:'regroup',fromBar:bar,bars:regrouped.bars,groups:regrouped.groups,levels:regrouped.levels.map(level=>[...level]),parts:[...regrouped.parts],count:regrouped.count};
      this.queue=regrouped.perBar.map(groups=>meterOf(this.home.numerator,this.home,groups,regrouped.levels));
      this.lastDissonanceBar=bar+regrouped.bars-1;if(whole)this.lastRegroupedBar=bar;
    }else if(chosen){
      this.span={kind:'dissonance',fromBar:bar,bars:chosen.bars,length:chosen.length,groups:chosen.groups,resolution:chosen.resolution};
      this.queue=chosen.perBar.map(groups=>meterOf(this.home.numerator,this.home,groups));
      this.lastDissonanceBar=bar+chosen.bars-1;
    }else{
      this.span={kind:'home',fromBar:bar,bars:1,groups:[...this.home.groups]};
      this.queue=[this.homeBar()];
    }
    this.decide({tick:clock.tick,bar,span:this.span.kind,...(chosen?{length:chosen.length,bars:chosen.bars,resolution:chosen.resolution}:{}),
      ...(regrouped?{bars:regrouped.bars,parts:[...regrouped.parts],levels:regrouped.levels.map(level=>[...level])}:{}),
      ...(within?{within:this.span.within}:{}),
      ...(modulated?{ratio:[modulated.a,modulated.b],bpm:modulated.bpm,bars:modulated.b,homeBars:modulated.a}:{}),
      groups:[...this.span.groups],perBar:this.queue.map(item=>[...item.groups])});
    this.broadcast('meterForm',[{home:{numerator:this.home.numerator,denominator:this.home.denominator,groups:[...this.home.groups],
      ...(this.home.sections?{sections:this.home.sections.map(level=>[...level]),sectionDynamics:[...this.home.sectionDynamics]}:{})},bar,
      ...(Number.isSafeInteger(startsAtBar)?{startsAtBar}:{}),span:{...this.span,groups:[...this.span.groups],perBar:this.queue.map(item=>[...item.groups])}}]);
  }
  // Before the first pulse: the home adopted and the first span planned; its first bar opened where the declared meter
  // came without a grouping of its own.
  onPrepare(clock={}){
    if(!clock.meter||this.home)return false;
    this.adoptHome(clock);this.planSpan(clock,Number.isSafeInteger(clock.bar)?clock.bar:0);
    const first=this.queue[0];
    if(first&&!sameBar(first,clock.meter)){this.broadcast('timeSignature',[first,'opening']);return true}
    return false;
  }
  onTick(tick,clock){
    if(!clock?.meter)return;
    // (A span planned on a bar's first pulse begins with that bar; one planned within a bar, with the next.)
    if(!this.home){this.adoptHome(clock);this.planSpan(clock,clock.barStart?clock.bar:clock.bar+1)}
    // A notated beat's seconds as the tempo now has it (60 / bpm), so the longest group a listener hears as one follows a
    // tempo change (the audit's B14: it was kept from the tempo the home was adopted in).
    this.unitSeconds=secondsPerTick(clock)*clock.meter.subdivision;
    if(!clock.barStart)return;
    // The bar now sounding, counted in home time as it is, whatever was proposed.
    const sounding=this.queue.shift(),played=clock.meter,planned=sounding&&sameBar(sounding,played);
    if(sounding&&!sameBar(sounding,played))this.decide({tick,heard:{numerator:played.numerator,denominator:played.denominator,groups:[...(played.groups??[])]},
      proposed:{numerator:sounding.numerator,denominator:sounding.denominator,groups:[...sounding.groups]}});
    // A modulated bar is its length times its ratio of home time; a home bar's tempo is the home tempo from here on.
    this.homeTime=this.homeTime.add(new Rational(played.numerator,played.denominator).mul(planned&&sounding.ratio?sounding.ratio:Rational.ONE));
    if(!sounding?.ratio&&Number(clock.bpm)>0)this.homeBpm=Number(clock.bpm);
    const [,phase]=this.homeTime.divmod(this.barLength);
    // A bar of another length (another bot's change): on a home downbeat anyway, the span is over; else a bar of whatever
    // length is left brings the home downbeat back, and the home bars go on from it.
    if(sounding&&!sameLength(sounding,played)){
      // (A modulation broken off steps back to the home tempo with the bars that resolve it.)
      if(sounding.ratio)this.broadcast('tempoCurve',[{targetBpm:this.homeBpm,durationBars:0,shape:'linear'},'nextBar']);
      if(phase.isZero())this.queue=[];
      else{
        const rest=resolveExcursion(this.home,{bars:[{numerator:this.home.numerator,denominator:this.home.denominator}],at:this.homeTime}).bars;
        this.queue=rest.map(item=>meterOf(item.numerator,this.home,groupsOf(item.numerator)));
      }
    }
    // The span ends with this bar: the next planned from the downbeat it lands on.
    if(!this.queue.length&&phase.isZero())this.planSpan({...clock,tick},clock.bar+1);
    const next=this.queue[0];
    if(next&&!sameBar(next,played)){const {ratio,bpm,enter,...meter}=next;this.broadcast('timeSignature',[meter,'nextBar'])}
    // Into a modulation and out of it: the tempo stepped at the bar line (a curve of no bars, shared/tempo-curve.js), so
    // the modulated bars and the home downbeat after them fall exactly where home time puts them.
    if(next?.enter)this.broadcast('tempoCurve',[{targetBpm:next.bpm,durationBars:0,shape:'linear'},'nextBar']);
    else if(planned&&sounding.ratio&&!next?.ratio&&this.homeBpm>0)this.broadcast('tempoCurve',[{targetBpm:this.homeBpm,durationBars:0,shape:'linear'},'nextBar']);
  }
}

export const meterformClodbot=defineBot(
  {
    id:'meterform_clodbot',name:'meterform_clodbot',status:'native',source:'clodbot',
    category:'conductor',outputModes:[],pitchContract:'none',
    // The settings a render spec may give it: its taste for departing (dissonance) and, of its departures, for modulating
    // and for regrouping the home bar.
    specSettings:Object.freeze(['dissonance','modulation','regrouping']),
    description:'A form bot for rhythm: every bar is a bar of the meter the piece begins in, its home, and over the home bars it lays grouping dissonances -- groups of another length across a bar or a few, crossing the bar lines, the last group whatever length is left, so each lands on a home downbeat -- and now and then a metric modulation, the home meter\'s bars at a tempo in a small ratio to the home\'s, as many as fill whole home bars exactly, stepped into and out of at the bar lines, or the home bar itself regrouped (9/8 as 5+4 where it is 3+3+3; 25/8 as 7+6+6+6; any meter, each part heard in its own beats) for a bar or a few; proposing each bar a bar ahead and saying what it is doing.',
  },
  (...args)=>new MeterFormClodbot(...args),
);
