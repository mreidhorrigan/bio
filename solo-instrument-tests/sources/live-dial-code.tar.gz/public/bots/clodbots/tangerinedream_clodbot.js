// tangerinedream_clodbot: a fork of ae_TangerineDreamBOT whose form chooses its active parts in a bounded number of
// random draws, by the same law (the mathematical audit's B03; the user, 27 September 2026: "fix in forked form"). Made
// from the class it forks, which agents.js holds, by a function, so this file imports nothing from agents.js;
// ae_TangerineDreamBOT itself is unchanged.
//
// For each phrase the port draws each part on or off (sequencer, bass, drums, melody, pad, each with its probability,
// halved for a part the phrase before left out), then repairs the draw: it sets a random part on until enough play
// (one at the form's ends, two between), then sets a random part off until no more than the phrase's density allows
// play. A pick of a part already on (or off) changes nothing and is drawn again, so how many draws a phrase takes has no
// bound. The law that repair gives is exact and simple: of the parts left out, a uniformly random set of the size
// needed is added; then, of the parts playing, a uniformly random set of the size needed is removed. Here that law is
// sampled directly (repairedParts: two partial shuffles), every part drawn once and each repair in exactly as many
// draws as parts it changes. Where both limits cannot hold (fewer allowed than required), the limit wins, as in the
// port, whose removal comes last. Its density curve, phrases, harmony, sequences and parts are the port's; the random
// stream after the first repair differs, the distribution of forms does not.
import {defineBot} from '../../framework/index.js';
import {interpolateCurvePoints,randomFivePointCurve,randomInt,unitRandom} from '../../shared/stochastic.js';

// `count` of `indices`, uniformly (a partial Fisher-Yates shuffle): exactly `count` draws of `draw(n)`, 0 <= r < n.
export function uniformSubset(indices,count,draw=randomInt){
  const pool=[...indices],take=Math.max(0,Math.min(pool.length,Math.trunc(count)));
  for(let k=0;k<take;k++){const j=k+draw(pool.length-k);[pool[k],pool[j]]=[pool[j],pool[k]]}
  return pool.slice(0,take);
}
// The port's repair of a part state, sampled directly: raise it to `minimum` parts on, then lower it to `limit`.
export function repairedParts(state,{minimum,limit,draw=randomInt}){
  const next=[...state],count=()=>next.reduce((sum,value)=>sum+value,0);
  const lacking=minimum-count();
  if(lacking>0)for(const index of uniformSubset(next.flatMap((on,i)=>on?[]:[i]),lacking,draw))next[index]=1;
  const excess=count()-limit;
  if(excess>0)for(const index of uniformSubset(next.flatMap((on,i)=>on?[i]:[]),excess,draw))next[index]=0;
  return next;
}

export function tangerinedreamClodbotClass(TangerineDreamBot){
  class TangerineDreamClodbot extends TangerineDreamBot {
    // The port's form (ae_TangerineDreamBOT generateForm), its repair sampled directly.
    generateForm(){
      const c=this.config,[low,high]=c.phraseCountRange;
      this.totalPhrases=low+randomInt(high-low);
      this.densityCurve=randomFivePointCurve({xRanges:c.densityPointXRanges,terminalWeights:c.densityTerminalWeights});
      this.form=[];let previous=null;
      for(let phrase=0;phrase<this.totalPhrases;phrase++){
        const density=Math.max(.05,Math.min(1,interpolateCurvePoints(this.densityCurve,phrase/Math.max(1,this.totalPhrases-1)))),
          limit=c.maximumActiveParts[Math.min(c.maximumActiveParts.length-1,Math.floor(density*c.maximumActiveParts.length))],
          drawn=c.partProbabilities.map((probability,index)=>unitRandom()<probability*(previous?.[index]===0?.5:1)?1:0),
          minimum=phrase===0||phrase===this.totalPhrases-1?1:2,
          state=repairedParts(drawn,{minimum,limit});
        this.form.push({state,density});previous=state;
      }
    }
  }
  return TangerineDreamClodbot;
}
export function defineTangerinedreamClodbot(TangerineDreamBot){
  const TangerineDreamClodbot=tangerinedreamClodbotClass(TangerineDreamBot);
  return defineBot({
      id:'tangerinedream_clodbot',name:'tangerinedream_clodbot',status:'native',source:'clodbot',forkOf:'tangerineDream',
      category:'composition',midiChannel:2,outputModes:['synth','midi'],pitchContract:'hybrid-mpe-percussion',
      description:
        'A fork of ae_TangerineDreamBOT whose form picks each phrase\'s active parts by the port\'s own law in a bounded number of random draws (the port repairs a draw by picking parts at random until the counts fit, however long that takes); its music is the port\'s.',
    },(...args)=>new TangerineDreamClodbot(...args));
}
