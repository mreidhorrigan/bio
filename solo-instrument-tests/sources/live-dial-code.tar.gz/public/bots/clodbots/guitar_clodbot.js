import {scoreTime,readScoreTime,shiftScoreTime,withScoreTime,scoreTimeFields} from '../../shared/score-time.js';
import {dividedBeats} from '../../shared/performers/rhythm-cell.js';
// guitar_clodbot: a guitarist, the second of the instrument clodbots (research/family-atlas.md F05, plucked fretted
// necked strings; research/MUSEBOTS_WORLD_INSTRUMENTS_CONSTRAINTS_RESEARCH_AND_IMPLEMENTATION_REPORT.md). New, not a
// fork. The user, 28 September 2026: "we should use other instruments for testing ... help us generalize on some of the
// testing we've been doing with drums"; 2a, the same day: "Please take the guitar".
//
// Its harmony is the band's, as jazzvoicing_clodbot reads it (the chord's guide tones, its fifth, its root where no bass
// is heard); the drummer's principles are the instrument clodbots' (instrument-performer.js): its comp on the meter's
// groups, comp and run as one continuum, a solo's course to a climax, the band's attention. What a guitarist adds:
// - **Chord shapes a fretting hand holds, by construction** (the user, 28 September: "Checks should be used only for
//   system development ... We are not building a brute-force system"). Its chords are chosen among the shapes its hand
//   can hold (chordShapes): one note a string, open or within the hand's window (shared/performers/guitar.js
//   GUITAR.window frets from its first finger), on four adjacent strings (three where four have no shape), the fretted
//   notes each at a fret of their own for a finger of their own but the window's first, which the first finger may
//   barre. Voice-led from the last shape, the hand moving as little as it can. The guitar planner (planGuitar) is the
//   reference in its tests, never asked while it plays.
// - **Strummed.** A chord's strings a few milliseconds apart: down, low to high, on a group's start or a felt beat's, and
//   up, high to low, on an offbeat.
// - **Its strums voiced** (the user, 29 September 2026, on the pianist: "these 'voicings' within chords should produce
//   subtle senses of melody from chord to chord as some notes receive more emphasis"; the backlog: "apply to the
//   guitarist's chords too"). The note making a line (chord-voicing.js broughtOut: its top, or the voice moving under a
//   held top) is plucked louder than the others (GUITAR_CLODBOT.lead), as guitarists bring out a soprano; its top voice
//   keeps the rules of melodic contour as the pianist's right hand does (top-contour.js, in nextShape's cost). A strum's
//   timing is its stroke's, the pick crossing the strings in order: on a guitar the notes' times do not voice the chord
//   as a piano's hammers do (the user: "on piano has nuances that it doesn't always in guitar strums").
// - **Its runs in position, by the line's rules.** A run is single notes where the hand already is (the shape's window,
//   and the open strings), never quicker than its picking hand (GUITAR.pluckSeconds), shaped over its phrase as the
//   pianist's are (run-phrase.js: one apex a phrase, never the last phrase's; the user: "even quite fast passagework
//   should still be subject to good contour principles").
// - **Beyond jazz, by the band's character** (the backlog's "a guitarist's open chords, power chords and a strummed pop
//   pattern"; shared/aesthetic.js, which every bot hears as this.character). Its chords are chosen among three
//   vocabularies' shapes at once, each worth as much as the character asks (guitarVocabulary): jazz's (guide tones, a
//   seventh) as the piece is intricate; a plain piece's triads, the root in the bass, rung over as many strings as they
//   hold with the open strings they can use (open chords) as it is atmospheric, or its root and fifth on the low strings
//   (power chords) as it is spiky. Every mixture between is a character's, so a piece moving between styles moves its
//   guitarist with it. A plain, steady piece strums more of the bar, a pop strum's hand never still; a spiky one damps its
//   chords short, an atmospheric one lets them ring. With no character heard it plays jazz's alone, as before.
// - **A fantasy guitar's frets** (the user, 29 September 2026: "our fantasy piano should be fully capable of
//   microtones"): its frets are wherever the band's pitches are, a quarter tone or a just third fretted exactly, the
//   hand's window a span in semitones as on a fretted neck, and it takes the band's tuning plan. A spec may ask for a
//   real guitar's frets (`frets: 'fixed'`), where a pitch between them is left out, never rounded (guitar.js refuses
//   it), and a tuning plan is declined.
import {defineBot} from '../../framework/index.js';
import {JazzVoicingClodbot} from './jazzvoicing_clodbot.js';
import {CHORD_READINGS} from '../../shared/performers/chord-readings.js';
import {PerformedTiming} from '../lib/modules/performed-timing.js';
import {HearsAttention} from '../lib/modules/attention.js';
import {InstrumentPerformer} from '../lib/modules/instrument-performer.js';
import {GUITAR} from '../../shared/performers/guitar.js';
import {figure,inspiredFigure,figurePayload,oneTone} from '../../shared/performers/figuration.js';
import {metricalGrid} from '../../shared/performers/section-voices.js';
import {bandMeter,bandPhraseBars} from '../../shared/opening-time.js';
import {secondsPerTick} from '../../shared/meter-tactus.js';
import {blendLevel,metricalWeight,rankThresholds} from '../../shared/performers/figure-blend.js';
import {modulo} from '../lib/pitch-helpers.js';
import {FAMILIES} from '../../shared/articulation.js';
import {broughtOut,louderBy} from '../../shared/performers/chord-voicing.js';
import {phraseRun} from '../../shared/performers/run-phrase.js';

export const GUITAR_CLODBOT=Object.freeze({
  // A strum's spread between strings (s; ours: about 12 ms a string, a relaxed strum, 36 ms across four).
  strumSeconds:.012,
  // The strings a shape takes: four adjacent (a drop voicing's), else three (a shell's).
  sizes:Object.freeze([4,3]),
  // The run's notes a felt beat, up to twice as many at a solo's climax.
  perBeat:4,
  // How often it picks a figure across its shape's strings instead of strumming them, a phrase at a time (figuration.js;
  // the owner, 2 October 2026: "guitar tremoloes, among others"; 3 October, "fingerpicked-like guitar ... in terms of
  // compound melodies": its shape's strings, voice-led from shape to shape, walked): a share drawn once a piece (the square of a uniform draw over
  // `share`: most guitarists seldom, some often; a spec's settings.figuration the range), and the figure's own draws --
  // how many strings it walks (one: a tremolo on the line's note), how often it turns, how surely its lowest string takes
  // the strong positions (a thumb's bass), its rate a share of as fast as its picking hand goes. Each string rings on to
  // the chord's end but the one picked again. Ours.
  // (And how often its thumb alternates between its two lowest strings, a Travis picking's: figuration.js alternate.)
  figuration:Object.freeze({share:Object.freeze([0,1]),tones:Object.freeze([1,4]),turn:Object.freeze([0,1]),anchor:Object.freeze([.3,1]),rate:Object.freeze([.35,.9]),alternate:Object.freeze([0,1]),inspiration:Object.freeze([0,1])}),
  // Levels (velocity): the comp's (jazzvoicing's own), a run's, a run's at a solo's peak (ours).
  run:.45,runTop:.85,
  // Where its shapes sit: the middle of a shape near this pitch (G3; ours: a comping guitar's register), weighed against
  // how far its hand moves.
  centre:55,
  // What a shape costs: each semitone its voices move from the last shape's, each fret its hand shifts, and each
  // semitone its middle lies from the centre (ours).
  cost:Object.freeze({voice:1,shift:1.5,register:.25}),
  // Its top voice's register, for the contour its line keeps (ours: a shape's top about a comping guitar's middle).
  top:Object.freeze([55,72]),
  // How much louder (dB) it plucks the note it brings out than the strum's others: guitarists' soprano over the other
  // voices of their chords, 3 to 6 dB (Freire, Nézio & dos Reis 2014, "Analysis of the simultaneity, voice/layer balance,
  // and rhythmic phrasing in works for guitar by Rodrigo, Brouwer and Villa-Lobos", ICMC-SMC 2014, 1010-1015,
  // doi:10.5281/zenodo.850753, Fig. 5, read from its renditions LB1 and LB3 of Brouwer's Étude II; LB1's "soprano line is
  // the most prominent throughout"). Its strum's spread, 12 ms a string, is in the range of theirs: 5 to 12.5 ms a string
  // in moderate strums (Freire, Armondes, Viana & Silva 2018, SMC 2018, doi:10.5281/zenodo.1422685, Table 6).
  lead:4.5,
  // A run's shape (run-phrase.js): from `below` notes under its shape's top to the highest under its hand, one climax a
  // phrase at its `climax` share, a scalar run `runMost` moves one way at most.
  runShape:Object.freeze({below:7,climax:.6,runMost:7}),
  // Its frets: a fantasy guitar's, wherever its pitches are (microtones fretted exactly, the tuning plan taken), unless a
  // spec asks for a real one ('fixed'), where a pitch between its frets is left out.
  frets:'fantasy',
  // Beyond jazz (guitarVocabulary): what a shape of a vocabulary the character does not ask for costs, per unit of its
  // missing worth (ours: three octaves of voice movement, so the character decides and voice leading chooses within it:
  // at one octave a power chord's parallel leap along the neck, 28 semitones between two chords, lost to a jazz shape
  // near the last; where the character asks for an even mixture, voice leading still decides); an
  // open chord's worth of each open string it rings (ours); the strings each vocabulary's shapes take (an open chord's
  // as many as hold it, a power chord's two: the root and its fifth, a finger each).
  // An open chord is a first-position chord (ours: its hand's each fret up the neck costs this), a barre chord where no
  // first position holds the triad.
  vocabularyCost:36,openString:1.5,openPosition:.75,openSizes:Object.freeze([6,5,4]),powerSizes:Object.freeze([2]),
  // Where each vocabulary's shapes sit (the middle of a shape, as `centre` is jazz's): an open chord's over the low
  // strings, E2 to E4 (ours: E3), a power chord's on the lowest two (ours: A2).
  centres:Object.freeze({jazz:55,colour:55,heard:55,open:52,power:45}),
  // How long its chords ring against a jazz comp's, from atmospheric to spiky (ours: half again as long, to a damped
  // two fifths), and the share of the bar's other beats and offbeats a plain, steady piece strums up to (all).
  ring:Object.freeze([1.5,.4]),
});
const clamp01=value=>Math.max(0,Math.min(1,Number.isFinite(value)?value:.5));
// Its vocabularies as its taste among a chord's readings weighs them (chord-readings.js readingWeights: the band's
// character where one is heard -- jazz's and a colourist's as the piece is intricate, open chords as it is plain and
// atmospheric, power chords as it is plain and spiky -- else its own seed's, never jazz's alone): {jazz, colour, heard,
// open (a common-practice reading's chord as an open chord holds it), power}.
export function guitarVocabulary(taste){
  return Object.freeze({jazz:taste?.jazz??0,colour:taste?.colour??0,heard:taste?.heard??0,open:taste?.common??0,power:taste?.power??0});
}
// A chord's shapes from each of its readings (chord-readings.js) its taste weighs at all, each named by its vocabulary:
// jazz's, a colourist's, the harmony as heard (its tones, those it requires held: chordShapes as it has always played
// them); an open chord's (a common-practice reading's triad, its root and third required, the root its lowest note, on
// four, five or six adjacent strings, as each chord's shape holds it: an open C on five, a D on four, an E on six); a
// power chord's (the root and its fifth, the root on the low E or A string). All within the hand (chordShapes'
// construction).
export function chordFamilies(readings,{fretboard=GUITAR_CLODBOT.frets,vocabulary=guitarVocabulary(null),choices=GUITAR_CLODBOT}={}){
  const out=[];
  for(const reading of readings){
    const name=reading.id==='common'?'open':reading.id,root=reading.roles.root;if(!(vocabulary[name]>0))continue;
    const rootLowest=shape=>root!==null&&root!==undefined&&nearly(modulo(Math.min(...shape.pitches)-root+6,12),6);
    if(name==='open'){const triad=[root,reading.roles.third,reading.roles.fifth].filter(pc=>pc!==null&&pc!==undefined);
      for(const size of choices.openSizes)out.push(...chordShapes(triad,[root,reading.roles.third],{fretboard,sizes:[size]}).filter(rootLowest).map(shape=>({...shape,vocabulary:name,reading:reading.id})))}
    else if(name==='power')out.push(...chordShapes(reading.pcs,reading.required,{fretboard,sizes:choices.powerSizes})
      .filter(shape=>shape.strings[0]<=1&&rootLowest(shape)&&Math.max(...shape.pitches)-Math.min(...shape.pitches)<12).map(shape=>({...shape,vocabulary:name,reading:reading.id})));
    else out.push(...chordShapes(reading.pcs,reading.required,{fretboard}).map(shape=>({...shape,vocabulary:name,reading:reading.id})));
  }
  return out;
}

// A pitch counts as on a fixed guitar's fret within this of it (semitones), as a fixed piano keyboard's key.
const ON_FRET=.05;
// The plucked string's velocity curve (articulation.js FAMILIES.pluck), in which its brought-out note is louder.
const PLUCK_CURVE=Object.freeze({rangeDb:FAMILIES.pluck.rangeDb??30,exponent:FAMILIES.pluck.velocityExponent??2});
const nearly=(a,b)=>Math.abs(a-b)<=1e-6;

// The notes under a hand at `position` (its first finger's fret, a fantasy guitar's any): the scale's (`steps`, pitch
// classes as its frets have them) on each string, open, within the window or a finger's stretch past it (GUITAR.stretch,
// as the planner allows), low to high. Without the stretch, a window of four frets on two strings a fourth apart has
// one note under no finger, and a scale's note there left a third between its neighbours, where a run meant a step.
export function notesUnderHand(position,steps,{choices=GUITAR}={}){
  const lowest=position-choices.stretch,reach=position+choices.window-1+choices.stretch;
  return [...new Set(choices.tuning.flatMap(open=>steps.flatMap(pc=>{const list=[],fret=modulo(pc-open,12);if(nearly(fret,0))list.push(open);
    for(let above=fret;above<=reach+1e-6;above+=12)if(above>=lowest-1e-6)list.push(+(open+above).toFixed(6));return list})))].sort((a,b)=>a-b);
}

// The shapes a fretting hand can hold for a chord's pitch classes `pcs`, every one holding the `required` ones: on each
// set of adjacent strings (GUITAR_CLODBOT.sizes: four, else three), at each position of the hand (its first finger's
// fret), one note a string, open or within the window's span above the position (GUITAR.window frets, as semitones:
// the same reach on a fantasy guitar's frets), every note a chord tone, the fretted notes each at a fret of their own but
// the position's (the first finger's barre), one a finger. On a fantasy guitar (`fretboard: 'fantasy'`) its frets are
// wherever the chord's pitches are, so a microtone is fretted exactly and a position may be one; on a real guitar
// ('fixed') a pitch between its frets is left out, and a chord whose required tone lies between them has no shape. In
// equal temperament the two are the same. -> [{position, strings, frets, pitches}] (pitches string by string, low to high).
export function chordShapes(pcs,required=[],{choices=GUITAR,sizes=GUITAR_CLODBOT.sizes,fretboard=GUITAR_CLODBOT.frets}={}){
  const fantasy=fretboard==='fantasy',onFret=pc=>fantasy||Math.abs(pc-Math.round(pc))<=ON_FRET;
  const classOf=pc=>+modulo(fantasy?pc:Math.round(pc),12).toFixed(6);
  if(required.some(pc=>!onFret(pc)))return [];
  const tones=[...new Set(pcs.filter(onFret).map(classOf))],needed=[...new Set(required.map(classOf))];
  const tuning=choices.tuning,window=choices.window,span=window-1;
  // Each string's frets for the chord's tones, in every octave up to its last fret.
  const frets=tuning.map(open=>[...new Set(tones.flatMap(pc=>{const list=[];for(let fret=modulo(pc-open,12);fret<=choices.frets+1e-6;fret+=12)list.push(+fret.toFixed(6));return list}))].sort((x,y)=>x-y));
  // The hand's positions: every fret's, and a fantasy fret's wherever one lies between them.
  const between=[...new Set(frets.flat().filter(fret=>fret>=1&&!nearly(fret,Math.round(fret))&&fret+span<=choices.frets+1e-6))];
  const positions=[...Array.from({length:Math.max(0,choices.frets-span)},(_,k)=>k+1),...between].sort((x,y)=>x-y);
  for(const size of sizes){
    const shapes=[];
    for(let first=0;first+size<=tuning.length;first++){
      const strings=Array.from({length:size},(_,k)=>first+k);
      for(const position of positions){
        const options=strings.map(string=>frets[string].filter(fret=>fret<=1e-6||fret>=position-1e-6&&fret<=position+span+1e-6));
        if(options.some(list=>!list.length))continue;
        const walk=(k,chosen)=>{
          if(k===strings.length){
            const above=chosen.filter(fret=>fret>1e-6).map(fret=>+(fret-position).toFixed(6)).filter(offset=>offset>1e-6);
            if(new Set(above).size!==above.length||above.length>window-1)return;
            const pitches=strings.map((string,i)=>+(tuning[string]+chosen[i]).toFixed(6));
            if(!needed.every(pc=>pitches.some(pitch=>nearly(modulo(pitch-pc+6,12),6))))return;
            if(new Set(pitches.map(pitch=>+modulo(pitch,12).toFixed(6))).size<Math.min(3,tones.length))return;
            shapes.push({position,strings,frets:[...chosen],pitches});
            return;
          }
          for(const fret of options[k])walk(k+1,[...chosen,fret]);
        };
        walk(0,[]);
      }
    }
    if(shapes.length)return shapes;
  }
  return [];
}

// The shape to play next: the one whose voices move least from the last shape's, its hand shifting least, its middle
// nearest the centre (GUITAR_CLODBOT.cost), and its top voice keeping the line's contour (`contour`: a cost on its
// pitches, top-contour.js contourScore); the lowest position among equals. With a vocabulary's worth (`worth`:
// guitarVocabulary), a shape of a vocabulary the character asks less for costs as much more, an open chord's open
// strings are worth their ringing, and a power chord keeps no top line of its own (it moves as a block, the contour
// left out), so it stays low on the neck where its register puts it.
export function nextShape(shapes,previous=null,{choices=GUITAR_CLODBOT,contour=null,worth=null,last=null}={}){
  const middle=pitches=>(Math.min(...pitches)+Math.max(...pitches))/2;
  const moved=shape=>{if(!previous)return 0;const a=previous.pitches,b=shape.pitches,n=Math.min(a.length,b.length);let sum=0;
    for(let k=0;k<n;k++)sum+=Math.abs(a[a.length-1-k]-b[b.length-1-k]);return sum};
  const style=shape=>worth?choices.vocabularyCost*(1-(worth[shape.vocabulary??'jazz']??0))
    +(shape.vocabulary==='open'?choices.openPosition*shape.position-choices.openString*shape.frets.filter(fret=>fret<=1e-6).length:0)
    // (Leaving the reading it voiced the last chord from: a player keeps an idiom through a passage, chord-readings.js.)
    +(last&&shape.reading&&shape.reading!==last?choices.vocabularyCost*CHORD_READINGS.change/CHORD_READINGS.cost:0):0;
  const centre=shape=>worth?choices.centres?.[shape.vocabulary??'jazz']??choices.centre:choices.centre;
  const cost=shape=>choices.cost.voice*moved(shape)+choices.cost.shift*(previous?Math.abs(shape.position-previous.position):0)+choices.cost.register*Math.abs(middle(shape.pitches)-centre(shape))+
    (contour&&shape.vocabulary!=='power'?contour([...shape.pitches].sort((x,y)=>x-y)):0)+style(shape);
  return shapes.reduce((best,shape)=>!best||cost(shape)<cost(best)-1e-9||Math.abs(cost(shape)-cost(best))<=1e-9&&shape.position<best.position?shape:best,null);
}

export class GuitarClodbot extends InstrumentPerformer(JazzVoicingClodbot,{name:'guitar_clodbot',kinds:['comp','run']}) {
  constructor(send,audio,settings={}){
    super(send,audio,settings);
    // (How often it picks rather than strums, a spec's range for its share: [0, 0] never.)
    const range=settings.figuration;
    if(range!=null&&!(Array.isArray(range)&&range.length===2&&range.every(x=>Number.isFinite(Number(x))&&x>=0&&x<=1)&&range[0]<=range[1]))throw new RangeError('A guitarist\'s figuration is a range [low, high] within 0 to 1');
    this.figurationRange=range?range.map(Number):null;
    // (How far its figures take after the others' it hears, settings.inspiration, 0 to 1; else drawn once a piece.)
    if(settings.inspiration!=null&&!(Number(settings.inspiration)>=0&&Number(settings.inspiration)<=1))throw new RangeError('A guitarist\'s inspiration is a share from 0 to 1');
    if(settings.inspiration!=null)this.inspiration=Number(settings.inspiration);
    const fretboard=settings.frets??GUITAR_CLODBOT.frets;
    if(!['fantasy','fixed'].includes(fretboard))throw new RangeError(`A guitarist's frets are fantasy or fixed, not ${fretboard}`);
    this.fretboard=fretboard;
    this.bars=[];this.runPlan=null;this.shape=null;this.strums=[];this.previousVoicing=null;this.previousLine=null;this.runPhrase=null;
  }
  // A new character heard: its next chord chosen afresh in the new vocabulary, not voice-led from the last shape (a
  // change of style is a change of texture; voice leading holds within one: from an open chord a power chord two
  // octaves lower costs more voice movement than the character's asking is worth, and it kept the open chord's
  // register through a spiky section).
  onCharacter(character,message){super.onCharacter?.(character,message);this.shape=null;this.previousVoicing=null;this.previousLine=null}
  // The share of the bar's other felt beats and offbeats it strums (instrument-performer.js rearticulates): with no
  // character heard, the other instrument clodbots' (null: a third of its busyness); with one, up to all of them as the
  // piece is plain and steady (a pop strum's hand never still).
  compShare(clock,busy){
    const character=this.character;if(!character)return null;
    const drive=(1-clamp01(character.complexity))*clamp01(character.continuity);
    return busy/3+(1-busy/3)*drive;
  }
  // A real guitar's frets take no tuning plan (a pitch between them would be left out); a fantasy guitar's take it.
  setCapabilities(value={}){super.setCapabilities?.({...value,...(this.fretboard==='fixed'?{tuning:false}:{})})}
  // A pitch class as its frets have it: exact on a fantasy guitar, a fret's on a real one, or null between its frets.
  fretClass(pc){if(this.fretboard==='fantasy')return +modulo(pc,12).toFixed(6);return Math.abs(pc-Math.round(pc))<=ON_FRET?modulo(Math.round(pc),12):null}
  // A chord on a change: its guide tones (third, seventh), its fifth, its root where no bass is heard, among the shapes
  // its hand can hold, voice-led from the last. Struck again as it is between changes.
  attack(clock,{change}){
    const chord=this.chord;if(!chord)return;
    const spt=this.secondsPerTick(clock),beat=this.beatTicks(clock),offbeat=clock.tickInBar%beat!==0;
    // (How long it rings: as a jazz comp's with no character heard, else from atmospheric's longer to spiky's damped.)
    const ring=this.character?GUITAR_CLODBOT.ring[0]+(GUITAR_CLODBOT.ring[1]-GUITAR_CLODBOT.ring[0])*clamp01(this.character.attack):1;
    const seconds=(offbeat?.6:1.4)*beat*spt*ring;
    if(!change&&this.shape){this.sound(clock,this.shape.pitches,seconds,this.vl.velocity-(offbeat?.02:.06));this.announce(clock,this.shape.pitches);return}
    // Its shapes from the chord's readings, as its taste weighs them (guitarVocabulary: the band's character, else its
    // own seed's).
    const readings=this.readingsOf(clock),vocabulary=guitarVocabulary(this.readingTaste());
    const shape=nextShape(chordFamilies(readings,{fretboard:this.fretboard,vocabulary}),this.shape,{contour:this.contourScore(clock,GUITAR_CLODBOT.top),worth:vocabulary,last:this.lastReading??null});
    if(!shape){this.decide({tick:clock.tick,noShape:readings.map(reading=>reading.id)});return}
    this.shape=shape;this.voicing=shape.pitches;this.lastReading=shape.reading;
    this.sound(clock,shape.pitches,seconds,this.vl.velocity);this.announce(clock,shape.pitches);
    this.decide({tick:clock.tick,change:true,chord:`${chord.root}:${chord.quality}`,shape:{position:shape.position,strings:shape.strings,frets:shape.frets,vocabulary:shape.vocabulary}});
  }
  // Strummed: down (low to high) on a group's start or a felt beat's, up (high to low) on an offbeat; at the level the
  // fillness leaves the comp (compLevelAt), the note it brings out (broughtOut: its top, or the voice moving under a held
  // top) GUITAR_CLODBOT.lead dB over the others. In a bar it runs, the run's notes and the chords share its hands: a chord
  // struck, let go a pick's time before the run's next note (a string rings one note at a time), the run's notes between.
  sound(clock,pitches,seconds,velocity=this.vl.velocity){
    const compLevel=this.compLevelAt(clock);if(!(compLevel>0))return;
    if((clock.tickInBar??0)===0)this.planRun(clock);
    const tick=clock.tickInBar??0,down=this.felt(clock).some(beat=>beat.start===tick),order=down?pitches:[...pitches].reverse();
    const now=tick*secondsPerTick(clock),next=this.runPlan?.bar===clock.bar?this.runPlan.notes.map(note=>note.start).find(start=>start>now+1e-9):undefined;
    const held=next===undefined?seconds:Math.max(.05,Math.min(seconds,next-now-GUITAR.pluckSeconds)),composed=this.compInterval(clock),scoreEnd=readScoreTime(composed).end.sub(clock.tick-tick);
    const level=Math.max(0,Math.min(1,velocity*compLevel)),sorted=[...pitches].sort((a,b)=>a-b);
    const line=sorted.length>1?sorted[broughtOut(sorted,this.previousVoicing,this.previousLine,{bass:this.bassHeard(clock)===null})]:null,lead=line===null?-1:down?order.lastIndexOf(line):order.indexOf(line),loud=louderBy(level,GUITAR_CLODBOT.lead,PLUCK_CURVE);
    // (Or picked: a figure across its strings, where this chord's draw falls under its share.)
    if(this.pickFigure(clock,{sorted,line,held,now,scoreEnd,level,loud})){this.previousVoicing=sorted;this.previousLine=line;this.count(clock,'comp');return}
    withScoreTime(this.audio,composed,()=>order.forEach((pitch,k)=>this.pluck(pitch,Math.max(.03,held-k*GUITAR_CLODBOT.strumSeconds),k===lead?loud:level,k*GUITAR_CLODBOT.strumSeconds)));
    this.previousVoicing=sorted;this.previousLine=line;
    this.count(clock,'comp');
    this.strums.push({bar:clock.bar,tick,down,pitches:[...order],...(line===null?{}:{line,level:+level.toFixed(4),lead:+loud.toFixed(4)})});if(this.strums.length>64)this.strums.shift();
  }
  // A figure picked across the shape's strings to `held` (GUITAR_CLODBOT.figuration): its notes from the meter's positions
  // (figuration.js), each string ringing on to the chord's end unless picked again, the line's note brought out; a
  // figure of one string a tremolo on the line's note. -> whether it picked one.
  pickFigure(clock,{sorted,line,held,now,scoreEnd,level,loud}){
    const f=GUITAR_CLODBOT.figuration,draw=key=>this.random(`figuration:${key}`)(),across=([a,b],u)=>a+(b-a)*u;
    this.figureShape??={share:across(this.figurationRange??f.share,draw('share')**2),tones:Math.round(across(f.tones,draw('tones'))),turn:across(f.turn,draw('turn')),anchor:across(f.anchor,draw('anchor')),rate:across(f.rate,draw('rate')),alternate:across(f.alternate,draw('alternate'))};
    // (Its figure moved toward the last another player said, as far as its inspiration: figuration.js inspiredFigure.)
    this.inspiration??=across(f.inspiration,draw('inspiration'));
    // (And how often: its own share, raised toward every chord as far as it leans toward a roll or a tremolo it heard --
    // its inspiration times the heard figure's nearness to the one-tone corner, figuration.js oneTone -- its figure
    // then moving toward one string, a tremolo.)
    const lean=this.inspiration*oneTone(this.heardFigure),share=this.figureShape.share+(1-this.figureShape.share)*lean;
    // (A phrase picked or strummed whole, as a guitarist fingerpicks a passage: its share the chance its phrase picks.)
    const phrase=Math.floor((Number(clock.bar)||0)/Math.max(1,Number(clock.meter?.phraseBars)||bandPhraseBars()));
    const shape=inspiredFigure(this.figureShape,this.heardFigure,this.inspiration,{tones:f.tones});if(sorted.length<1||!(held>2*GUITAR.pluckSeconds)||!(this.random(`figure:phrase:${phrase}`)()<share))return false;
    const set=shape.tones<=1?[line??sorted.at(-1)]:sorted,spt=secondsPerTick(clock),beat=spt*(clock.meter.subdivision||bandMeter().subdivision),{positions,barSeconds}=metricalGrid(clock.meter,beat);
    const notes=figure({set,positions,barSeconds,scoreEnd,start:0,seconds:scoreEnd.toNumber()*spt,rate:shape.rate/GUITAR.pluckSeconds,shortest:GUITAR.pluckSeconds,tones:shape.tones,direction:1,turn:shape.turn,anchor:shape.anchor,alternate:this.figureShape.alternate,random:this.random(`figure:${clock.bar}:walk`)}).filter(note=>note.at>=now-1e-9);
    if(!notes.length)return false;
    notes.forEach((note,k)=>{const again=notes.slice(k+1).find(other=>Math.abs(other.pitch-note.pitch)<1e-6),ring=(again?again.at:now+held)-note.at;
      withScoreTime(this.audio,shiftScoreTime(note.scoreTime,clock.tick-(clock.tickInBar??0),{axis:'ensemble'}),()=>this.pluck(note.pitch,Math.max(.03,ring),Math.abs(note.pitch-(line??NaN))<1e-6?loud:level,note.at-now))});
    this.strums.push({bar:clock.bar,tick:clock.tickInBar??0,picked:notes.length,pitches:[...set]});if(this.strums.length>64)this.strums.shift();
    // (Said for the others, once a bar it figures in.)
    if(this.figureSaid!==clock.bar){this.figureSaid=clock.bar;this.broadcast?.('figure',[figurePayload(this.instanceId??'guitar_clodbot',shape,clock.bar)])}
    return true;
  }
  // The figures the others say, for its own to take after.
  onMessage(message){super.onMessage?.(message);
    if(message?.address==='/broadcast/figure'&&message.args?.[0]&&String(message.args[0].voice)!==String(this.instanceId??'guitar_clodbot'))this.heardFigure=message.args[0]}
  // A string plucked: the synthesized plucked string (the pluck family), or MIDI to a guitar outside.
  pluck(pitch,seconds,asked,offset){
    const velocity=this.plannedVelocity(asked,'pluck');
    if(this.audio?.mode==='midi'){this.audio.midiNote?.(pitch,seconds,velocity,undefined,offset,{instrument:'pluck',profile:'pluck'});return}
    this.audio?.voice?.(pitch,seconds,.07,'sawtooth',offset,{instrument:'pluck',profile:'pluck',velocity});
  }
  everyTick(clock){
    super.everyTick?.(clock);
    if((clock.tickInBar??0)===0)this.planRun(clock);
  }
  // The run, planned once at a bar's start where the fillness asks for one: single notes where the hand is (the
  // shape's window and the open strings), the scale's as its frets have it, shaped over the phrase by the line's rules
  // (run-phrase.js, from GUITAR_CLODBOT.runShape's `below` notes under the shape's top); its notes at the felt beats'
  // subdivisions but where a chord is struck (faster at a solo's climax, never quicker than its picking hand), each at
  // the level the fillness gives it, within the band's attention's allowance.
  planRun(clock){
    if(this.runPlan?.bar===clock.bar)return;
    this.runPlan={bar:clock.bar,notes:[]};
    if(!this.chord||!this.shape)return;
    const fillness=this.fillnessOf(clock)??0,solo=this.soloIntensity(clock);if(!(fillness>0)&&solo===null)return;
    const spt=secondsPerTick(clock),span=clock.meter.pulsesPerBar,felt=this.felt(clock),intensity=solo??0;
    const shortest=Math.min(...felt.map(beat=>beat.length))*spt,picks=Math.max(1,Math.floor(shortest/GUITAR.pluckSeconds));
    const perBeat=Math.min(picks,Math.round(GUITAR_CLODBOT.perBeat*(1+intensity)));
    const struck=new Set(this.comp?.bar===clock.bar?this.comp.hits:[]);
    const positions=dividedBeats(felt,perBeat).filter(({at})=>!struck.has(at));
    // The notes under the hand (notesUnderHand): the scale's, as its frets have it.
    const scale=[...new Set((this.scaleFor?.(this.poolPcs??[])??[]).map(pc=>this.fretClass(pc)).filter(pc=>pc!==null))];
    // Too few for a scale: every class its frets have (run-steps.js); a share of the runs on the chord's eight-note scale.
    const steps=this.runSteps(scale,{grid:Array.from({length:12},(_,k)=>this.fretClass(k)).filter(pc=>pc!==null),draw:this.random(`runSteps:${clock.bar}`)()})
      .map(pc=>this.fretClass(pc)).filter(pc=>pc!==null);
    const window=this.shape.position,under=notesUnderHand(window,steps);
    if(under.length<2)return;
    // The notes that sound, each at the level the fillness gives it: the line is shaped over them alone, since a line
    // shaped over every position and then thinned keeps none of its rules (a note twice running, its apex twice).
    const u=this.random(`run:${clock.bar}`),items=positions.map(({at,scoreTime},k)=>({id:`run${k}`,at,scoreTime,weight:metricalWeight(at,{beatStarts:felt.map(beat=>beat.start),span}),position:at/span,u:u()}));
    const thresholds=rankThresholds(items,{order:this.fillOrder});
    const sounding=items.map(item=>({at:item.at,scoreTime:item.scoreTime,level:blendLevel(thresholds.get(item.id),this.fillnessOf(clock,Math.min(span-1e-9,item.at))??0,{entering:true})})).filter(item=>item.level>0);
    if(!sounding.length)return;
    // Its line over the phrase (run-phrase.js), from `below` notes under the shape's top (as the band's tuning sounds
    // them) to the highest under the hand.
    const top=Math.max(...this.shape.pitches);
    const run=phraseRun({tones:under,from:top,below:GUITAR_CLODBOT.runShape.below,count:sounding.length,bar:clock.bar,phrase:clock.phrase??0,phraseBars:clock.meter?.phraseBars,state:this.runPhrase,
      randomFor:reachNow=>this.random(`runContour:${clock.bar}:${reachNow}`),sound:pitch=>this.audio?.tunePitch?.(pitch),choices:GUITAR_CLODBOT.runShape});
    this.runPhrase=run.state;
    if(!run.pitches.length)return;
    const notes=sounding.map((item,k)=>({scoreTime:shiftScoreTime(item.scoreTime,clock.tick-(clock.tickInBar??0),{axis:'ensemble'}),pitch:run.pitches[k],start:item.at*spt,end:(item.at+span/(felt.length*perBeat)*.9)*spt,level:item.level}));
    const level=GUITAR_CLODBOT.run+(GUITAR_CLODBOT.runTop-GUITAR_CLODBOT.run)*intensity;
    const {heard,claim,givenBackDb}=this.licensed(clock,notes.map(note=>({at:note.start,velocity:level*note.level})));
    for(const note of notes)withScoreTime(this.audio,note,()=>this.pluck(note.pitch,note.end-note.start,this.softer(level*note.level,givenBackDb),note.start));
    this.runPlan={bar:clock.bar,notes:notes.map(note=>({...scoreTimeFields(note),pitch:note.pitch,start:note.start,end:note.end}))};
    this.count(clock,'run',notes.length);
    this.bars.push({bar:clock.bar,fillness:+fillness.toFixed(3),run:notes.length,of:items.length,perBeat,position:window,...(solo===null?{}:{intensity:+intensity.toFixed(3)}),
      ...(heard?{attention:{claimDb:claim?+claim.claimDb.toFixed(2):null,allowanceDb:+heard.allowanceDb.toFixed(2),soloing:heard.soloing,givenBackDb:+givenBackDb.toFixed(2)}}:{})});
    if(this.bars.length>64)this.bars.shift();
  }
}

export const PerformedGuitar=HearsAttention(PerformedTiming(GuitarClodbot,{instrument:'comping'}));
export const guitarClodbot=defineBot(
  {
    id: "guitar_clodbot", name: "guitar_clodbot", status: "native", source: "clodbot",
    category: "harmony", midiChannel: 5, performanceType: "polyphonic", outputModes: ["synth", "midi"],
    // Pitched, its pitches floating: a fantasy guitar's frets take the tuning plan (a real guitar's decline it:
    // setCapabilities).
    pitchContract: "floating-mpe",
    specSettings: Object.freeze(["fillness", "fillOrder", "density", "frets", "chromatic", "figuration", "inspiration"]),
    description:
      "A guitarist whose hands play only what a guitarist's can, by construction: the band's harmony (its guide tones, fifth, and root where no bass is heard) in chord shapes its fretting hand can hold, voice-led from the last, strummed down on the beats and up on the offbeats, the note that makes a line plucked louder and its top voice keeping the rules of contour; a fantasy guitar's frets, wherever its pitches are (microtones exact and the tuning plan taken), or a real guitar's (frets: 'fixed'), where a pitch between them is left out; comping on the meter's groups (in 7/8 as 2+2+3); comp and run as one continuum (settings.fillness), its runs single notes in position, shaped over the phrase by the line's rules to one climax; a solo's course building to a climax ('solo', or where the band's attention gives it one), within the allowance the band's attention gives it.",
  },
  (...args) => new PerformedGuitar(...args),
);
