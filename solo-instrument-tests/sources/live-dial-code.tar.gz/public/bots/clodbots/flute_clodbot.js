import {shiftScoreTime,withScoreTime} from '../../shared/score-time.js';
// flute_clodbot: a transverse flute, a concert flute, piccolo or alto flute (the world-instruments atlas's F16), playing a
// line with its breath planned (shared/performers/wind-line.js, on the singer's breath planner). A new clodbot carrying
// the melody's principles to a wind (the user, 28 September 2026: "we should use other instruments for testing ... which
// should hopefully help us generalize on some of the testing we've been doing with drums").
//   - Each phrase is planned whole at its downbeat, from the harmony it hears (its pool, whatever the tuning) and the
//     meter's felt beats: phrases of its own motif in the sentence's shape (line.js), its breaths planned with it by
//     construction (at its commas and rests; where the air would run out, at the latest place that can take one; in a
//     run with no room, a weak note left out for a catch breath; a note no breath carries eased, then shortened).
//   - Its share of the band's attention (shared/attention.js) shapes it: given the solo, its density and loudness rise
//     with the solo's arc to a climax and its long notes take fioriture; behind another's solo it plays less and softer.
//   - It plays in the ensemble's feel and rubato (the performance layer; the clocks' spans), its runs in their own time.
// settings.instrument: flute (unless given), piccolo or alto.
// Seated in a woodwind section (settings.seat, 'fl.2', of a section of settings.size: shared/performers/wind-section.js),
// it plays its part of the section's formations instead, in its breaths (bots/lib/modules/wind-seat.js). On samples it
// plays its instrument's recordings (scripts/download-wind-samples.mjs, where they are here), else its own voice, which a
// plugin's synthesizer plays where it has one (Surge XT's "Winds/Flute 2"). The reeds' and the brass's players are this
// one with another family's instruments (woodwind_clodbot, brass_clodbot).
import {Agent,defineBot} from '../../framework/index.js';
import {secondsPerTick} from '../../shared/meter-tactus.js';
import {WIND_INSTRUMENTS,WIND_LINE,windFamily,planPhrase} from '../../shared/performers/wind-line.js';
import {licenseReach,soloArc} from '../../shared/attention.js';
import {HearsAttention} from '../lib/modules/attention.js';
import {HearsPartRubato,playLagged} from '../lib/modules/part-rubato.js';
import {PlaysPickups} from '../lib/modules/line-pickups.js';
import {HearsLineMotifs,occurrenceRecords} from '../lib/modules/line-motifs.js';
import {strikeWith} from '../lib/note-language.js';
import {Closure} from '../lib/modules/closure.js';
import {GroupingChoice} from '../lib/modules/grouping-choice.js';
import {followHarmony,meterKey,phraseBeforeEnding,phraseOffset} from '../../shared/performers/line.js';
import {PerformedTiming} from '../lib/modules/performed-timing.js';
import {makingRoom,registerAway} from '../../shared/presentation.js';
import {createRandomStream} from '../../random-source.js';
import {WindSeat,windSeatOf} from '../lib/modules/wind-seat.js';
import {sectionStream} from '../lib/modules/section-seat.js';
import {memoryReport} from '../lib/modules/memory-played.js';
import {declareMember} from '../../shared/conducting/group-routing.js';
import {BREATH} from '../lib/modules/wind-seat.js';
import {bandPhraseBars,bandTempo} from '../../shared/opening-time.js';
import {PlaysItsPersonality} from '../lib/modules/personality.js';
import {windTechniqueAt,windMultiphonicNear} from '../../shared/performers/techniques.js';

const PHRASES_KEPT=16;
// Its density and loudness among equals (a line, not a soloist), and its fioriture as a soloist.
export const FLUTE=Object.freeze({density:.35,loudness:.5,fioriture:.35});
function checkedInstrument(value,family='flute',fallback='flute'){
  if(value==null)return fallback;
  if(WIND_INSTRUMENTS[value]?.family!==family)throw new RangeError(`A ${family} is ${windFamily(family).join(', ')}`);
  return value;
}
// The bank its recordings may be in, a preset an instrument (vsco-<instrument>).
export const WIND_BANKS=Object.freeze([Object.freeze({bank:'vscoWinds',prefix:'vsco'})]);

export class FluteClodbot extends Agent {
  // Its family, and its instrument where none is given (a reed's player and a brass player's are this class's).
  static family='flute';static instrument='flute';
  constructor(...args){
    super(...args);
    const {family,instrument}=new.target;
    // Its seat, where a spec seats it in a section: its instrument is the seat's, and what it plays of stored material
    // said to MemoryBOT (memory-played.js).
    const seated=windSeatOf(args[2]??{});
    if(seated&&WIND_INSTRUMENTS[seated.instrument]?.family!==family)throw new RangeError(`Seat ${seated.seat.id} is a ${seated.instrument}'s, not a ${family}'s`);
    this.family=family;this.instrument=seated?seated.instrument:checkedInstrument(args[2]?.instrument,family,instrument);
    this.seat=seated?new WindSeat(seated,{audio:this.audio,pool:()=>this.notes,closing:clock=>this.closingAt?.(clock)??{phase:'none'},stream:sectionStream(this),streamOf:()=>this.stream??null,partTick:(at,clock)=>this.partTick?.(at,clock)??at,say:(address,args)=>this.broadcast(address,args),remember:memoryReport(this)}):null;
    if(this.audio?.mode==='samples'&&typeof this.audio.loadSampleBank==='function')this.loading=this.loadRecordings();
    this.phrase=null;this.phrases=[];
    // Its motif, kept and varied phrase by phrase, and its last phrase's apex, not taken again (line.js).
    this.motif=null;this.phraseIndex=0;this.previousApex=null;this.lead=null;
  }
  // On samples, its instrument's recordings, where the bank is here and holds them; else its own voice, said.
  async loadRecordings(){
    const failed=[];
    for(const {bank,prefix} of WIND_BANKS){
      const preset=`${prefix}-${this.instrument}`;
      try{
        await this.audio.loadSampleBank(bank,{preset});
        if(!Object.values(this.audio.sampleMetadata??{}).some(entry=>entry?.instrument===this.instrument)){failed.push(`${bank}: no ${this.instrument}'s recordings`);continue}
        this.recordings={bank,preset};this.decide?.({samples:{bank,preset}});return this.recordings;
      }catch(error){failed.push(`${bank} ${preset}: ${String(error?.message??error)}`)}
    }
    this.recordings=null;this.decide?.({samples:{none:this.instrument,failed}});
    this.audio.report?.('substitution',{instrument:this.instrument,reason:`no ${this.instrument}'s recordings here: its own voice`,failed});
    return null;
  }
  onMessage(message){
    super.onMessage?.(message);
    this.seat?.hear(message);
  }
  // Its density, loudness and fioriture for a phrase beginning at `bar`, from its attention there.
  shaping(bar){
    // (Its own, where its personality says them: bots/lib/modules/personality.js.)
    const attention=this.attentionAt?.(bar),base=this.playing?.shaping??FLUTE;
    if(!attention||!Number.isFinite(attention.typicalDb))return {density:base.density,loudness:base.loudness,fioriture:0};
    const {reach,belowDb}=licenseReach({allowance:attention.allowanceDb,typicalDb:attention.typicalDb});
    if(attention.soloing){const arc=soloArc(attention.progress??.5)*reach;return {density:base.density+(1-base.density)*arc,loudness:base.loudness+(1-base.loudness)*arc,fioriture:base.fioriture+(1-base.fioriture)*arc}}
    const scale=10**(-belowDb/10);return {density:base.density*scale,loudness:base.loudness*Math.sqrt(scale),fioriture:0};
  }
  // The conductor's cutoff at the ensemble's stop (framework/agent.js cutOffAt): seated, its seat lets go what it holds,
  // its bow lifted or its breath ended, as at a cutoff it hears.
  onCutoff(clock,{atSeconds}={}){if(this.seat)this.seat.cutOff(Number.isFinite(atSeconds)?atSeconds:this.seat.clockSeconds)}
  onTick(tick,clock){
    super.onTick?.(tick,clock);
    // Seated, it plays its part of its section's formation, its group said to its room once (group-routing.js).
    if(this.seat){declareMember(this,this.seat.group);this.seat.tick(tick,clock);return}
    const meter=clock?.meter;
    if(!meter||!Number.isInteger(clock.bar))return;
    const phraseBars=Math.max(1,Number(meter.phraseBars)||bandPhraseBars()),perTick=secondsPerTick(clock);
    // A phrase planned whole at its downbeat, its breaths with it, on its phrase grid: the form's where it is the band's
    // focus, half a phrase later where another's share of the band's attention is larger (it answers). A phrase ends at
    // the grid's next bar; a bar of another meter re-plans it from there. At its entry it never waits: its first phrase
    // runs from there to its grid's next bar (the user: "we need to fix the bug where some renders have silence at their
    // beginnings").
    // The piece's ending, where it is known (Closure: form_clodbot's closing, or the stop the ensemble committed to): its
    // last phrase ends with it, its cadence on the tonic held to the end, and nothing after. A phrase planned before the
    // ending was known that runs past it gives way, at a bar line, to a last phrase.
    // Room for another's entrance (shared/presentation.js, ManageBOT's): through an answering silence it rests, its phrase
    // ending before it; under a texture it thins, and under a register it keeps out of the author's. A phrase planned
    // before the presentation acting on its bars was said is planned again from the bar line.
    const ending=this.closingAt?.(clock)?.ending??null,endsAt=Number.isInteger(ending?.endsAt?.bar)?ending.endsAt.bar:null;
    if(endsAt!=null&&clock.bar>=endsAt||this.presentationOver?.(clock.bar,clock.bar+1)?.kind==='silence'){this.phrase=null;return}
    const offset=phraseOffset(this.attentionAt?.(clock.bar),phraseBars),current=this.phrase;
    const acting=current?makingRoom(this.presentationOver?.(clock.bar,current.endBar)).key:null;
    const due=clock.tickInBar===0&&(current?clock.bar>=current.endBar||clock.bar<current.startBar||current.meterKey!==meterKey(meter)||endsAt!=null&&current.endBar>endsAt&&!current.final||acting!=null&&acting!==current.room:true);
    if(due){
      const whole=phraseBeforeEnding(clock.bar,{phraseBars,offset,endsAt}),room=makingRoom(this.presentationOver?.(clock.bar,clock.bar+whole.bars));
      const span=phraseBeforeEnding(clock.bar,{phraseBars,offset,endsAt,breakAt:room.silentBar}),bars=span.bars;
      const random=(this.phraseRandom??=createRandomStream(`${this.randomStream?.seed??0}:${this.family==='flute'?'flute':this.instrument}`)),draw=()=>random.next();
      const shaped=this.shaping(clock.bar);shaped.density*=room.density;
      // (Its register its personality's, where it has one: its instrument's widened toward its compass as it dares.)
      const own=this.playing?.register??WIND_INSTRUMENTS[this.instrument].register,register=room.awayFrom?registerAway(own,room.awayFrom)??own:own;
      // Where the form marks the join its phrase ends at, a pickup into it, as the drummer's fill (line-pickups.js).
      const pickup=span.final?null:this.pickupAt?.(clock.bar+bars,clock,draw)??null;
      // The harmony it hears: the pool every bot keeps from the room's note pools and harmony plans (framework/agent.js).
      // Its motif made at its density among equals, FLUTE's, which its phrase then plays sparser or denser by its own
      // (its personality's, its share of the band's attention): made at its personality's, its phrase had played its motif
      // as made at every density but where its attention moved it.
      const planned=planPhrase({instrument:this.instrument,register,coreOnly:room.thin,pool:this.notes,meter,bpm:Number(clock.bpm)||bandTempo(),bars,...shaped,motif:this.motifToStart?.({meter,bpm:Number(clock.bpm)||bandTempo(),register})??this.motif,motifDensity:FLUTE.density,phraseIndex:this.phraseIndex,previousApex:this.previousApex,pickup,lead:this.lead,heard:this.motifsHeard?.()??[],
        climax:this.attentionAt?.(clock.bar)?.role==='climax',final:span.final?{tonic:ending?.tonic??null,...(band=>band?{motif:band}:{})(this.bandMotif?.({meter,bpm:Number(clock.bpm)||bandTempo(),pool:this.notes,register:register??null}))}:null,random:draw,...(this.playing?{choices:this.playing.choices}:{})});
      // (Its tone in the phrase, as its personality plays its instrument: personality.js phraseTone.)
      const tone=this.toneFor?.({phrase:this.phraseIndex,level:shaped.loudness})??{};
      if(planned.motif)this.motif=planned.motif;if(planned.apex!=null)this.previousApex=planned.apex;this.lead=planned.lead??null;this.phraseIndex++;
      // A motif chosen now, from a slate unlike the other lines' (line.js chooseMotif), said to them (line-motifs.js).
      if(planned.choice)this.sayMotif?.(planned.motif);
      this.phrase={startTick:tick,perTick,notes:planned.notes,status:planned.status,startBar:clock.bar,endBar:clock.bar+bars,meterKey:meterKey(meter),final:span.final,room:room.key,tone,
        // Each segment an occurrence of its motif, declared on its first note's strike (line-motifs.js).
        records:occurrenceRecords(planned.notes,{by:this.instanceId,phrase:`${clock.bar}`,motif:this.motif})};
      this.phrases.push({bar:clock.bar,bars,offset,pickup:pickup?.fill??null,status:planned.status,notes:planned.notes.length,...(planned.choice?{choice:planned.choice}:{}),...(room.key?{room:room.key}:{}),breaths:planned.breaths.length,
        changes:planned.changes.map(r=>r.change),...shaped});
      if(this.phrases.length>PHRASES_KEPT)this.phrases.shift();
    }
    const phrase=this.phrase;
    if(!phrase?.notes?.length)return;
    // Each note as its tick comes round (the phrase's seconds counted in the ticks it was planned in). Notes under one
    // slur are played in one breath, tongued once: each sounds into the next (legato).
    // Each at its part's own time where ManageBOT says one over the band's clock (part-rubato.js): a note that moved
    // earlier than the tick it was planned in sounds at once.
    // Ticks it was not given (paused, and started again) take their notes with them: a note is never played late.
    phrase.sounded??=new Set;
    if(Number.isFinite(phrase.lastTick)&&tick>phrase.lastTick+1)phrase.notes.forEach((note,index)=>{if(phrase.startTick+note.start/phrase.perTick<tick)phrase.sounded.add(index)});
    phrase.lastTick=tick;
    for(const [index,note] of phrase.notes.entries()){
      if(phrase.sounded.has(index))continue;
      const planned=phrase.startTick+note.start/phrase.perTick,at=Math.max(tick,this.partTick?.(planned,clock)??planned);
      if(at>=tick+1)continue;
      phrase.sounded.add(index);
      const next=phrase.notes[index+1],slurred=Boolean(note.slur)&&next?.slur===note.slur;
      const seconds=slurred?(next.start-note.start)*1.08:(note.end-note.start)*.95;
      // Its pitch in the harmony sounding now (the phrase was planned at its downbeat).
      const pitch=followHarmony(note.pitch,this.notes,this.playing?.register??WIND_INSTRUMENTS[this.instrument].register);
      // (On its recordings, or a reed's or a brass instrument's voice, a wind's note; a flute's own voice otherwise.)
      // (No glide of its voice's own: a note slurred to from the last moves to its pitch as quickly as the fingers do, any
      // other begins on it -- the wind family's voice glides into every joined note otherwise: wind-seat.js BREATH.slur.)
      const before=phrase.notes[index-1],fromSlur=Boolean(note.slur)&&before?.slur===note.slur;
      // (Its phrase's tone: a fingered multiphonic in place of the note where its instrument has one measured near it, else
      // its technique -- a hum under the note drawn to the harmony heard, a growl, a flutter -- and its mute: techniques.js,
      // as a section's seat plays them, wind-seat.js.)
      const tone=phrase.tone??{},multiphonic=tone.multiphonic&&!slurred&&!fromSlur?windMultiphonicNear(tone.multiphonic.choice,pitch,{instrument:this.instrument,compass:this.facts?.compass.range,pool:this.notes??[]}):null;
      const sounded=multiphonic?multiphonic.pitches[0]:pitch,extended=multiphonic?{multiphonic:{id:multiphonic.id}}:windTechniqueAt(tone.technique??null,sounded,{pool:this.notes??[],mute:tone.mute??null});
      // (Whether it is slurred to the note before -- legato-tongued where it repeats that note's pitch -- told its synth
      // as a seated player's stroke tells it (wind-seat.js), its player saying where its slurs are: told none, a winds
      // synth had tongued every note of its line.)
      const joined={phrased:true,...(fromSlur?{slurred:true,...(Math.abs(sounded-phrase.lastSounded)<1e-6?{portato:true}:{})}:{})};
      phrase.lastSounded=sounded;
      const options={instrument:this.instrument,family:this.family,glide:fromSlur?BREATH.slur:false,stroke:{captured:joined},...(note.fioritura?{ownSubdivision:true}:{}),
        ...(extended?{extended}:{}),...(multiphonic?{multiphonic:{...multiphonic,pitches:[...multiphonic.pitches]}}:{})};
      const strike=()=>this.family==='flute'&&!this.recordings?this.audio.flute(sounded,seconds,note.velocity,(at-tick)*perTick,options):this.audio.windNote(sounded,seconds,note.velocity,(at-tick)*perTick,options);
      // (Its rubato and its ornament's warp how it is played, not written: audio.js lagged.)
      const record=phrase.records?.[index];
      const play=()=>{if(record)strikeWith(this,[{pitch:sounded,language:record}],strike);else strike()},lag=(at-planned)*perTick+(Number(note.lag)||0);
      withScoreTime(this.audio,shiftScoreTime(note.scoreTime,phrase.startTick,{axis:'ensemble'}),()=>playLagged(this.audio,lag,play));
      // (A note of the band's theme, MemoryBOT's, returned in its last phrase: said to it, line-motifs.js rememberPlayed.)
      this.rememberPlayed?.(note,{phrase:phrase.startBar,offset:(at-tick)*perTick+lag,seconds});
    }
    this.memoryPlayed?.report(tick);
  }
}
// A wind player's bot, its class wrapped in the instrument clodbots' modules.
// (Its personality learned of its instrument as it starts: personality.js.)
export const windPlayerBot=Class=>PerformedTiming(HearsAttention(PlaysPickups(HearsPartRubato(HearsLineMotifs(GroupingChoice(Closure(PlaysItsPersonality(Class,{base:WIND_LINE})),{role:'layer'}))))),{instrument:'melody'});
export function defineFluteClodbot(){
  const Bot=windPlayerBot(FluteClodbot);
  return defineBot({
    id:'flute_clodbot',orchestral:true,name:'flute_clodbot',status:'native',source:'clodbot',category:'melody',midiChannel:4,outputModes:['synth','samples','midi'],
    pitchContract:'floating-mpe',specSettings:Object.freeze(['instrument','seat','size','kind','section','arrival','compass','personality','motifs','engine','rhythm']),
    // (Its compass an object where the engines that will play it say theirs, its windows by instrument: wind-section.js windSeats.)
    // (Its personality an object of its levers' shares: personality.js; the engine it is linked to, what that engine says
    // it plays: instrument-facts.js `engine`.)
    specObjects:Object.freeze(['compass','personality','engine']),
    description:'A transverse flute -- a concert flute, piccolo or alto flute -- playing phrases of its own motif (the idea, its repetition, a climb to one apex, a held cadence, a rest) with its breaths planned with them: at its commas and rests, and where the air would run out at the latest place that can take one (in a run with no room, a weak note left out for a catch breath); on its own phrase grid, answering a line with a larger share of the band\'s attention; given the solo it builds to a climax, fast and loud, its long notes taking fioriture, and behind another\'s it plays less and softer.',
  },(...args)=>new Bot(...args));
}
