// kalimba_clodbot: a kalimba player, an instrument clodbot (research/family-atlas.md F34, lamellophones and plucked
// idiophones; research/MUSEBOTS_WORLD_INSTRUMENTS_CONSTRAINTS_RESEARCH_AND_IMPLEMENTATION_REPORT.md). New, not a fork.
// Taken by 2a from c2's "Percussion beyond the kit", 29 September (SESSIONS.md 07:30).
//
// Its harmony is the band's, as jazzvoicing_clodbot reads it (the chord's third, fifth and seventh, its root where no
// bass is heard); the drummer's principles are the instrument clodbots' (instrument-performer.js): its comp on the
// meter's groups, comp and figure as one continuum, a solo's course to a climax, the band's attention, its arrival at the cadence on
// the last downbeat (Closure). What a kalimba player adds:
// - **Chords its thumbs can pluck, by construction.** Its tines lie low in the middle and higher outward, by turns right
//   and left (shared/performers/kalimba.js): a chord is two to four tines its two thumbs pluck at once, one tine a thumb
//   or two neighbours on its own side, voice-led from the last (kalimbaVoicings). The planner (planKalimba) is the
//   reference in its tests, never asked while it plays.
// - **Its figure a cycle.** Kalimba music is made of patterns the thumbs share by turns, played again and again: its
//   figure, drawn once for the bar (its thumbs by turns, each aiming along its own side), is played bar after bar, its
//   tines found again on each chord (a chord tone where the beat is strong, any tine between). Never quicker than two
//   thumbs alternating: each thumb plucks again only once its stroke has recovered, a chord's as a figure's (a figure's
//   note a thumb has no time for is left out, and a chord takes only the thumbs that are free), so what it plays is
//   always what two thumbs can.
// - **Its tines in the band's scale** by default (the kalimba retuned for the piece, a tine to each step), so its tines
//   are wherever the band's pitches are, microtones included; a spec may ask for a fixed kalimba (`tines: 'fixed'`,
//   seventeen in C major from C4), which has no tine for a pitch between its tines: that pitch is left out, never rounded.
// - **Its sound**: a plucked tine (the bell family's sine) of its own, a Surge XT pluck (c2's candidates, 29 September:
//   Plucks/Magic Music Box, Tinker or Woody, none making a rhythm of its own), or MIDI out.
import {defineBot} from '../../framework/index.js';
import {withScoreTime,shiftScoreTime,scoreTimeFields} from '../../shared/score-time.js';
import {dividedBeats} from '../../shared/performers/rhythm-cell.js';
import {JazzVoicingClodbot} from './jazzvoicing_clodbot.js';
import {PerformedTiming} from '../lib/modules/performed-timing.js';
import {HearsAttention} from '../lib/modules/attention.js';
import {InstrumentPerformer} from '../lib/modules/instrument-performer.js';
import {KALIMBA,kalimbaTines,tinePlace,thumbsFor,plucks} from '../../shared/performers/kalimba.js';
import {secondsPerTick} from '../../shared/meter-tactus.js';
import {blendLevel,metricalWeight,rankThresholds} from '../../shared/performers/figure-blend.js';
import {modulo} from '../lib/pitch-helpers.js';
import {broughtOut,louderBy} from '../../shared/performers/chord-voicing.js';
import {BELL_CURVE} from './mallets_clodbot.js';

export const KALIMBA_CLODBOT=Object.freeze({
  // Its built-in voice's gain: the plucked tine (the bell family's sine) at the mallet player's level, the median bot
  // voice's (sample-levels.mjs, 29 September).
  voiceGain:.05,
  // The figure's notes a felt beat, up to twice as many at a solo's climax (ours).
  perBeat:2,
  // Levels (velocity): the figure's, the figure's at a solo's peak (ours).
  run:.45,runTop:.8,
  // Its chords: this many tines (ours: a kalimba's chords are thin); their middle near this pitch, the kalimba's own
  // (C4 to E6), weighed against how far its voices move; within this far of it (semitones).
  chordSize:3,centre:67,reach:12,
  // What a chord costs: each semitone its voices move, each semitone its middle lies from the centre (ours).
  cost:Object.freeze({voice:1,register:.25}),
  // The figure's aim: a thumb's home places either side of the middle, and how far it walks from its home (places; ours).
  home:Object.freeze({LT:-2,RT:2}),walk:2,
  // A position this heavy or heavier (figure-blend.js metricalWeight) takes a chord tone (ours).
  strong:.5,
  // The note of a chord it brings out (chord-voicing.js broughtOut: its top, or the voice moving under a held top, the
  // line carried from chord to chord), this many dB over the others (the user, 29 September: "these 'voicings' within
  // chords should produce subtle senses of melody from chord to chord"). Authored: no measured value for a kalimba's tines was found
  // (7a, 29 September); the nearest measured is a plucked chord's soprano, 3 to 6 dB over its other voices (Freire,
  // Nézio & dos Reis 2014, doi:10.5281/zenodo.850753), whose middle this is.
  lead:4.5,
});
const near=(a,b)=>Math.abs(modulo(a-b+6,12)-6)<=KALIMBA.tolerance;

// The chords its thumbs can pluck together for a chord's pitch classes `pcs`, every one holding the `required` ones:
// `size` tines where the chord has that many classes on its tines (fewer where it has fewer), no class twice while there
// are more to sound, each thumb one tine or two neighbours on its side, the chord's middle within `reach` of the centre.
// -> [{pitches (low to high), tines (indices), thumbs: {LT, RT}, x}].
export function kalimbaVoicings(pcs,required=[],{tines=kalimbaTines({tines:'fixed'}),size=KALIMBA_CLODBOT.chordSize,centre=KALIMBA_CLODBOT.centre,reach=KALIMBA_CLODBOT.reach}={}){
  const classes=[...new Set(pcs.map(Number))],needed=[...new Set(required.map(Number))];
  const candidates=tines.map((pitch,index)=>({pitch,index})).filter(tine=>classes.some(pc=>near(tine.pitch,pc))&&Math.abs(tine.pitch-centre)<=reach);
  const sounding=classes.filter(pc=>candidates.some(tine=>near(tine.pitch,pc))),count=Math.min(size,Math.max(1,sounding.length)),out=[];
  const walk=(start,chosen)=>{
    if(chosen.length===count){
      if(!needed.every(pc=>chosen.some(tine=>near(tine.pitch,pc))))return;
      if(new Set(chosen.map(tine=>classes.findIndex(pc=>near(tine.pitch,pc)))).size<Math.min(count,sounding.length))return;
      const indices=chosen.map(tine=>tine.index),ways=plucks(indices);
      // (Both thumbs where it can: the one that uses each.)
      const way=ways.find(each=>each.thumbs.LT.length&&each.thumbs.RT.length)??ways[0];
      if(way)out.push({pitches:chosen.map(tine=>tine.pitch),tines:indices,thumbs:way.thumbs,x:way.x});
      return;
    }
    for(let k=start;k<candidates.length;k++)walk(k+1,[...chosen,candidates[k]]);
  };
  walk(0,[]);
  return out;
}
// The chord to pluck next: the one whose voices move least from the last's, its middle nearest the centre, its chord
// reading's cost to its player added where it was voiced from one (chord-readings.js).
export function nextKalimbaVoicing(voicings,previous=null,{centre=KALIMBA_CLODBOT.centre,choices=KALIMBA_CLODBOT}={}){
  const middle=pitches=>(Math.min(...pitches)+Math.max(...pitches))/2;
  const moved=voicing=>{if(!previous)return 0;const a=previous.pitches,b=voicing.pitches,n=Math.min(a.length,b.length);let sum=0;for(let k=0;k<n;k++)sum+=Math.abs(a[a.length-1-k]-b[b.length-1-k]);return sum};
  const cost=voicing=>choices.cost.voice*moved(voicing)+choices.cost.register*Math.abs(middle(voicing.pitches)-centre)+(voicing.readingCost??0);
  return voicings.reduce((best,voicing)=>!best||cost(voicing)<cost(best)-1e-9?voicing:best,null);
}

export class KalimbaClodbot extends InstrumentPerformer(JazzVoicingClodbot,{name:'kalimba_clodbot',kinds:['comp','run']}) {
  constructor(send,audio,settings={}){
    super(send,audio,settings);
    const tines=settings?.tines??'band';if(tines!=='band'&&tines!=='fixed')throw new RangeError('settings.tines is band or fixed');
    this.tineSetting=tines;this.fixedTines=tines==='fixed'?kalimbaTines({tines:'fixed',choices:this.fixedKey()}):null;
    this.bars=[];this.figure=null;this.runPlan=null;this.voiced=null;this.plucked=[];
    // When each thumb is free again (s of its own time: elapsedSeconds), its last stroke recovered.
    this.thumbFree={LT:-Infinity,RT:-Infinity};
  }
  // A fixed kalimba's key: the common instrument's (C), preferred but not always taken (shared/opening-harmony.js); its
  // tines the same scale on the key drawn.
  fixedKey(){
    const {base,scale}=KALIMBA.fixed,tonic=this.preferredTonic(base);
    return {...KALIMBA,fixed:{base:tonic,scale:scale.map(step=>step+tonic-base)}};
  }
  // Its time now (s), and whether a thumb is free at a time.
  now(clock){return this.elapsedSeconds?.(clock)??(Number(clock?.tick)||0)*this.secondsPerTick(clock)}
  free(thumb,at){return at>=this.thumbFree[thumb]-1e-9}
  // A chord's thumbs, those of `voicing` that are free now; its tines on a busy thumb left out.
  playable(voicing,at){
    const thumbs=['LT','RT'].filter(thumb=>voicing.thumbs[thumb].length&&this.free(thumb,at));
    return {thumbs,tines:thumbs.flatMap(thumb=>voicing.thumbs[thumb]),pitches:voicing.tines.map((index,k)=>thumbs.some(thumb=>voicing.thumbs[thumb].includes(index))?voicing.pitches[k]:null).filter(pitch=>pitch!==null)};
  }
  // Its tines in a bar: a fixed kalimba's, or the band's scale as it stands at the bar's start (the kalimba retuned for the
  // piece, between bars, never under a bar's figure): the pool's own classes where it holds five or more (a collection),
  // else its scale, each in the object's own tuning where the object sounds one between the keys (objectTuned), a major
  // scale on the chord's root where it hears fewer than five. Kept by bar (layouts) for inspection.
  tinesNow(clock=null){
    if(this.fixedTines)return this.fixedTines;
    const bar=Number(clock?.bar);
    if(Number.isFinite(bar)&&this.bandTines?.bar===bar)return this.bandTines.tines;
    const tuned=pc=>this.objectTuned?.(pc)??pc;
    const scale=[...new Set((this.collection?.()??this.scaleFor?.(this.poolPcs??[])??[]).map(Number).map(tuned))];
    // (Its tines are laid out by the scale, a thumb's reach counted in tines, so they keep to the scale heard, and where
    // it hears none, every step of the grid: run-steps.js, never a major scale guessed on the root.)
    const steps=this.runSteps(scale,{grid:Array.from({length:12},(_,k)=>tuned(k)),collection:true});
    const key=steps.map(pc=>modulo(pc,12).toFixed(4)).sort().join(',');
    const tines=this.bandTines?.key===key?this.bandTines.tines:kalimbaTines({tines:'band',scale:steps});
    if(Number.isFinite(bar)){this.bandTines={key,bar,tines};(this.layouts??=new Map).set(bar,tines);if(this.layouts.size>64)this.layouts.delete(this.layouts.keys().next().value)}
    return tines;
  }
  // A chord on a change: its third, fifth and seventh, its root where no bass is heard, among the chords its thumbs can
  // pluck, voice-led from the last. Plucked again as it is between changes.
  attack(clock,{change}){
    const chord=this.chord;if(!chord)return;
    const spt=this.secondsPerTick(clock),beat=this.beatTicks(clock),offbeat=clock.tickInBar%beat!==0,final=this.closing?.phase==='final';
    const seconds=(offbeat?.6:1.4)*beat*spt;
    if(!change&&this.voiced){this.sound(clock,this.voiced,seconds,this.vl.velocity-(offbeat?.02:.06));this.announce(clock,this.voiced.pitches);return}
    // (Every reading of the chord its thumbs can reach (chord-readings.js), each in the object's own tuning -- a neutral
    // third its third -- each dearer as its taste for the reading is less; a class no tine sounds, on a fixed kalimba, left
    // out, never required; where its thumbs reach no chord holding every tone of one, the most of its tones they do, those
    // it requires first.)
    const tines=this.tinesNow(clock),onTines=pc=>tines.some(pitch=>near(pitch,pc)),at=this.now(clock),readings=this.readingsOf(clock);
    const voicings=readings.flatMap(reading=>{
      const needed=reading.required.filter(onTines),sounding=[...needed,...reading.pcs.filter(pc=>onTines(pc)&&!needed.includes(pc))];
      let found=kalimbaVoicings(sounding,needed,{tines});
      for(let keep=sounding.length;!found.length&&keep>=1;keep--)found=kalimbaVoicings(sounding.slice(0,keep),[],{tines});
      return found.map(voicing=>({...voicing,reading:reading.id,readingCost:reading.cost}))});
    // (Its chords whose thumbs are free now; any, where none is, its busy thumb's tines then left out.)
    const ready=voicings.filter(voicing=>['LT','RT'].every(thumb=>!voicing.thumbs[thumb].length||this.free(thumb,at)));
    const voicing=nextKalimbaVoicing(ready.length?ready:voicings,this.voiced);
    if(!voicing){this.decide({tick:clock.tick,noVoicing:readings.map(reading=>reading.id)});return}
    this.voiced=voicing;this.voicing=voicing.pitches;this.lastReading=voicing.reading;
    this.sound(clock,voicing,seconds,this.vl.velocity);this.announce(clock,voicing.pitches);
    this.decide({tick:clock.tick,change:true,chord:`${chord.root}:${chord.quality}`,reading:voicing.reading,voicing:{pitches:voicing.pitches,LT:voicing.thumbs.LT,RT:voicing.thumbs.RT}});
  }
  // Plucked together by its free thumbs, at the level the fillness leaves the comp (compLevelAt); its tines ring on under
  // the figure, as a kalimba's do.
  sound(clock,voicing,seconds,velocity=this.vl.velocity){
    const compLevel=this.compLevelAt(clock);if(!(compLevel>0))return;
    if((clock.tickInBar??0)===0)this.planFigure(clock);
    const at=this.now(clock),{thumbs,pitches}=this.playable(voicing,at);if(!pitches.length)return;
    const level=Math.max(0,Math.min(1,velocity*compLevel));
    // The note it brings out, KALIMBA_CLODBOT.lead dB over the others.
    const sorted=[...pitches].sort((a,b)=>a-b),line=sorted.length>1?sorted[broughtOut(sorted,this.previousVoicing,this.previousLine,{bass:this.bassHeard(clock)===null})]:null;
    const loud=louderBy(level,KALIMBA_CLODBOT.lead,BELL_CURVE);
    withScoreTime(this.audio,this.compInterval(clock),()=>{
      for(const pitch of pitches)this.pluck(pitch,seconds,line!==null&&Math.abs(pitch-line)<1e-9?loud:level,0);
    });
    this.previousVoicing=sorted;this.previousLine=line;
    for(const thumb of thumbs)this.thumbFree[thumb]=at+KALIMBA.strokeSeconds;
    this.count(clock,'comp');
    this.plucked.push({bar:clock.bar,tick:clock.tickInBar??0,pitches,thumbs});if(this.plucked.length>64)this.plucked.shift();
  }
  // A tine plucked: its built-in voice (the bell family's sine), the synth a spec names (a Surge XT pluck), or MIDI.
  pluck(pitch,seconds,asked,offset){
    const velocity=this.plannedVelocity(asked,'bell');
    if(this.audio?.mode==='midi'){this.audio.midiNote?.(pitch,seconds,velocity,undefined,offset,{instrument:'bell',profile:'bell'});return}
    this.audio?.voice?.(pitch,seconds,KALIMBA_CLODBOT.voiceGain,'sine',offset,{instrument:'bell',profile:'bell',velocity});
  }
  // Each tick, the figure's notes due in it, each by its thumb where the thumb is free by then (a chord plucked on this
  // tick comes first: the voice leader's attack runs before everyTick).
  everyTick(clock){
    super.everyTick?.(clock);
    if((clock.tickInBar??0)===0)this.planFigure(clock);
    const plan=this.runPlan;if(plan?.bar!==clock.bar||!plan.notes.length)return;
    const tick=clock.tickInBar??0,spt=secondsPerTick(clock),at=this.now(clock);
    for(const note of plan.notes){
      if(!(note.at>=tick-1e-9&&note.at<tick+1-1e-9))continue;
      const offset=(note.at-tick)*spt,time=at+offset;
      if(!this.free(note.thumb,time)){note.skipped=true;continue}
      withScoreTime(this.audio,note,()=>this.pluck(note.pitch,note.seconds,note.velocity,offset));this.thumbFree[note.thumb]=time+KALIMBA.strokeSeconds;note.played=true;
    }
  }
  // Its figure's cycle for a bar of `n` positions: each position's thumb (by turns, the left on the downbeat) and the
  // place it aims at, a walk along its own side about its home (KALIMBA_CLODBOT.home, walk), drawn once from its seed and
  // drawn again only where the bar's number of positions changes.
  drawFigure(n){
    const u=this.random(`figure:${n}`),aims={LT:KALIMBA_CLODBOT.home.LT,RT:KALIMBA_CLODBOT.home.RT};
    return Array.from({length:n},(_,k)=>{
      const thumb=k%2?'RT':'LT',home=KALIMBA_CLODBOT.home[thumb],step=Math.floor(u()*3)-1;
      aims[thumb]=Math.max(home-KALIMBA_CLODBOT.walk,Math.min(home+KALIMBA_CLODBOT.walk,aims[thumb]+step));
      return {thumb,aim:aims[thumb]};
    });
  }
  // The figure, planned once at a bar's start where the fillness asks for one: its cycle realized on the chord, each
  // position's tine the one on its thumb's side nearest its aim (a chord tone where the position is strong, any tine
  // between), at the felt beats' subdivisions but where a chord is plucked or a thumb has not recovered from it (faster
  // at a solo's climax, never quicker than two thumbs alternating), each at the level the fillness gives it, within the
  // band's attention's allowance.
  planFigure(clock){
    if(this.runPlan?.bar===clock.bar)return;
    this.runPlan={bar:clock.bar,notes:[]};
    if(!this.chord||!this.voiced)return;
    const fillness=this.fillnessOf(clock)??0,solo=this.soloIntensity(clock);if(!(fillness>0)&&solo===null)return;
    const spt=secondsPerTick(clock),span=clock.meter.pulsesPerBar,felt=this.felt(clock),intensity=solo??0;
    const shortest=Math.min(...felt.map(beat=>beat.length))*spt,most=Math.max(1,Math.floor(shortest/(KALIMBA.strokeSeconds/2)+1e-9));
    const perBeat=Math.min(most,Math.round(KALIMBA_CLODBOT.perBeat*(1+intensity)));
    // (Its cycle drawn over every position of the bar, so it is the same bar after bar; those where a chord is plucked, or
    // a thumb is still recovering from one, left out as it is played.)
    const struck=this.comp?.bar===clock.bar?this.comp.hits:[];
    const all=dividedBeats(felt,perBeat);
    if(this.figure?.length!==all.length){this.figure=this.drawFigure(all.length);this.figuresDrawn=(this.figuresDrawn??0)+1}
    const kept=all.map((cell,k)=>({...cell,k})).filter(({at})=>!struck.some(hit=>at>=hit-1e-9&&(at-hit)*spt<KALIMBA.strokeSeconds-1e-9));
    if(!kept.length)return;
    const tines=this.tinesNow(clock),chordPcs=this.voiced.pitches.map(pitch=>modulo(pitch,12)),beatStarts=felt.map(beat=>beat.start);
    const onSide=(thumb,index)=>thumbsFor(tinePlace(index)).includes(thumb);
    const path=kept.map(({at,k})=>{
      const {thumb,aim}=this.figure[k],strong=metricalWeight(at,{beatStarts,span})>=KALIMBA_CLODBOT.strong;
      const fits=tines.map((pitch,index)=>({pitch,index})).filter(tine=>onSide(thumb,tine.index)&&(!strong||chordPcs.some(pc=>near(tine.pitch,pc))));
      const pool=fits.length?fits:tines.map((pitch,index)=>({pitch,index})).filter(tine=>onSide(thumb,tine.index));
      return pool.reduce((best,tine)=>!best||Math.abs(tinePlace(tine.index)-aim)<Math.abs(tinePlace(best.index)-aim)?tine:best,null);
    });
    const u=this.random(`figure-levels:${clock.bar}`),items=kept.map(({at,scoreTime},k)=>({id:`fig${k}`,at,scoreTime,weight:metricalWeight(at,{beatStarts,span}),position:at/span,u:u()}));
    const thresholds=rankThresholds(items,{order:this.fillOrder});
    const gap=span/(felt.length*perBeat);
    const notes=items.map((item,k)=>({scoreTime:shiftScoreTime(item.scoreTime,clock.tick-(clock.tickInBar??0),{axis:'ensemble'}),pitch:path[k].pitch,tine:path[k].index,thumb:this.figure[kept[k].k].thumb,at:item.at,start:item.at*spt,end:(item.at+2*gap)*spt,
      level:blendLevel(thresholds.get(item.id),this.fillnessOf(clock,Math.min(span-1e-9,item.at))??0,{entering:true})})).filter(note=>note.level>0);
    const level=KALIMBA_CLODBOT.run+(KALIMBA_CLODBOT.runTop-KALIMBA_CLODBOT.run)*intensity;
    const {heard,claim,givenBackDb}=this.licensed(clock,notes.map(note=>({at:note.start,velocity:level*note.level})));
    // (Played tick by tick, everyTick: each where its thumb is free then.)
    this.runPlan={bar:clock.bar,notes:notes.map(note=>({...scoreTimeFields(note),pitch:note.pitch,tine:note.tine,thumb:note.thumb,at:note.at,
      start:note.start,end:note.end,seconds:note.end-note.start,velocity:this.softer(level*note.level,givenBackDb)}))};
    this.count(clock,'run',notes.length);
    this.bars.push({bar:clock.bar,fillness:+fillness.toFixed(3),run:notes.length,of:items.length,perBeat,...(solo===null?{}:{intensity:+intensity.toFixed(3)}),
      ...(heard?{attention:{claimDb:claim?+claim.claimDb.toFixed(2):null,allowanceDb:+heard.allowanceDb.toFixed(2),soloing:heard.soloing,givenBackDb:+givenBackDb.toFixed(2)}}:{})});
    if(this.bars.length>64)this.bars.shift();
  }
}

export const PerformedKalimba=HearsAttention(PerformedTiming(KalimbaClodbot,{instrument:'comping'}));
export const kalimbaClodbot=defineBot(
  {
    id: "kalimba_clodbot", name: "kalimba_clodbot", status: "native", source: "clodbot",
    category: "harmony", midiChannel: 6, performanceType: "polyphonic", outputModes: ["synth", "midi"],
    // Its tines in the band's tuning unless a spec asks for a fixed kalimba (tines: 'fixed'), which takes no tuning plan.
    pitchContract: "floating-mpe", planningCapabilities: Object.freeze({tuning: true}),
    specSettings: Object.freeze(["fillness", "fillOrder", "density", "tines"]),
    description:
      "A kalimba player whose thumbs play only what a kalimba player's can, by construction: the band's harmony in chords its two thumbs pluck at once, one tine each or two neighbours on its side, voice-led from the last; its figure a cycle the thumbs share by turns, played bar after bar and found again on each chord; comp and figure as one continuum, a solo's course, and the band's attention. Its tines take the band's scale, microtones included.",
  },
  (...args) => new PerformedKalimba(...args),
);
