// papperc_clodbot: a fork of PAP_PercBot whose kick and toms are tuned to the harmony it hears, by the function every
// drum bot shares (../lib/modules/drum-tuning.js). Made from the class it forks, which agents.js holds, by a function,
// so that this file imports nothing from agents.js (no import cycle).
//
// Which drum sounds on which step is the ported bot's, and so is how hard: PAP_PercBot's probability tables and its
// density. Each hit of its kick and of its mid drum (audio.js papPercussion's tom) is played with a strike naming the
// notes of the harmony, and the voice that plays it tunes it, as a drummer tunes a kit's toms to a song: the kick and
// the toms each to the most resonant note they reach within two and a half semitones (percussion-expression.js TUNING).
// Its noise hits are as they were. Before any harmony is heard it plays as PAP_PercBot does, and with settings
// {tuneDrums: false} always.
import {defineBot} from '../../framework/index.js';
import {tunedStrike} from '../lib/modules/drum-tuning.js';

// The drum each of its kinds strikes, for tuning it: its "mid" is a tom.
const KIND_PIECES=Object.freeze({kick:'kick',mid:'tom'});

export function pappercClodbotClass(PapPercBot){
  class PapPercClodbot extends PapPercBot {
    // Its hits are tuned by wrapping its own audio's papPercussion, once per audio; a bot made again on the same audio
    // takes the wrapper over. A hit whose caller gave its strike keeps it.
    constructor(send,audio,settings={}){
      super(send,audio,settings);
      this.tuneDrums=settings?.tuneDrums??true;
      if(audio&&typeof audio.papPercussion==='function'){
        if(audio.papPercussion.tunesDrums)audio.papPercussion.owner=this;
        else{
          const play=audio.papPercussion.bind(audio),wrapped=(kind,variant,accent,strike,...rest)=>{
            const owner=wrapped.owner,piece=KIND_PIECES[kind];
            return play(kind,variant,accent,strike===undefined&&owner&&piece?tunedStrike(owner,piece,null):strike??null,...rest)};
          wrapped.tunesDrums=true;wrapped.owner=this;audio.papPercussion=wrapped;
        }
      }
    }
  }
  return PapPercClodbot;
}
export function definePappercClodbot(PapPercBot){
  const PapPercClodbot=pappercClodbotClass(PapPercBot);
  return defineBot({
      id:'papperc_clodbot',name:'papperc_clodbot',status:'native',source:'clodbot',
      category:'beat',midiChannel:10,outputModes:['synth','midi'],pitchContract:'fixed-percussion',
      description:
        'A fork of PAP_PercBot whose kick and toms are tuned to the harmony it hears, each to the most resonant note it reaches within two and a half semitones, as a drummer tunes a kit to a song; its patterns and density are PAP_PercBot\'s.',
    },(...args)=>new PapPercClodbot(...args));
}
