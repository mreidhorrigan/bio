// mass_clodbot: a section of many lines at once, for the user's stress test, 28 September 2026: "extremely large
// ensembles, xenakis or ligeti size". One bot plays up to eight lines (the kit's Surge XT patches carry a polylimit of
// eight, and MPE gives fifteen member channels: 7a's reading of the renderer), so a mass of Ligeti's or Xenakis's size
// is a few of these, each its own section, not a hundred bots. New, not a fork: no earlier bot plays a section.
//
// Its texture (settings.texture):
// - 'micropolyphony', after Ligeti's Atmosphères and Lontano. Every line sings one slow line (its cantus) in canon, each
//   in its own division of the beat and a little slower than the one before, so their attacks seldom meet and the
//   canon thickens into a band that shimmers. The cantus moves by the smallest steps of the harmony heard (or by
//   semitones where none is), within a narrow band.
// - 'masses', after Xenakis's Metastaseis and Pithoprakta. Each line is a glissando from one pitch to another over its
//   own length. Onsets come as a Poisson stream at the section's density, pitches from a normal spread about its
//   centre.
// In both, the section's centre, width and density follow a slow arc over each of its phrases (the mass rises,
// widens and thickens toward its middle, then settles), so the texture has a shape to hear.
import {defineBot} from '../../framework/index.js';
import {Agent} from '../../framework/agent.js';
import {unitRandom} from '../../shared/stochastic.js';
import {secondsPerTick} from '../../shared/meter-tactus.js';
import {bandPhraseBars,bandMeter} from '../../shared/opening-time.js';
import {scoreTime,withScoreTime} from '../../shared/score-time.js';
import {Rational} from '../../transcript/rational.js';

// ---- Choices (ours) -------------------------------------------------------------------------------------------------
export const MASS=Object.freeze({
  lines:8,                   // lines at most (Surge's polylimit in the kit's patches)
  center:Object.freeze([52,74]),   // where a section's centre may lie (MIDI)
  width:Object.freeze([2,9]),      // its band's width in semitones, from narrow to wide over an arc
  // Each line's division of the beat: an arch over the lines, the middle lines the finest, from two to as many as its
  // beat holds notes of `shortest` s (no list of divisions: the owner, 2 October 2026, "NO HARDCODING OF TUPLETS").
  shortest:.08,
  drift:.06,                 // each line's notes this much longer than the line before's (the canon's thickening)
  cantusBeats:2,             // a cantus note's length in beats (before drift)
  cantusNotes:16,            // the cantus's length
  density:Object.freeze([.6,4]),   // masses: onsets a second, from sparse to dense over an arc
  glissando:Object.freeze([1.2,5]),   // masses: a glissando's seconds
  gain:.05,velocity:.4,      // quiet, each line (many sum)
});
const clamp=(x,low,high)=>Math.max(low,Math.min(high,x));
// A normal draw (Box-Muller) from the seeded source.
const normal=()=>Math.sqrt(-2*Math.log(Math.max(1e-12,unitRandom())))*Math.cos(2*Math.PI*unitRandom());

export class MassClodbot extends Agent{
  constructor(send,audio,settings={}){
    super(send,audio);
    this.settings={texture:'micropolyphony',lines:MASS.lines,...settings};
    this.lines=Math.max(1,Math.min(MASS.lines,Math.trunc(Number(this.settings.lines)||MASS.lines)));
    this.busyUntil=Array(this.lines).fill(-Infinity);this.lineEnds=Array(this.lines).fill(-Infinity);this.cantus=null;this.phrase=null;this.clockSeconds=0;this.lastTick=null;
  }
  // The section's arc over a phrase: 0 at its start and end, 1 at its middle.
  arc(clock){const bars=clock.meter?.phraseBars||bandPhraseBars(),at=((clock.bar??0)%bars+(clock.tickInBar??0)/(clock.meter?.pulsesPerBar||bandMeter().pulsesPerBar))/bars;return Math.sin(Math.PI*at)}
  // Where the section stands now: its centre (a phrase's own, drawn where it begins), width and density by the arc.
  shape(clock){
    const phrase=clock.phrase??0;
    if(this.phrase?.n!==phrase)this.phrase={n:phrase,center:MASS.center[0]+unitRandom()*(MASS.center[1]-MASS.center[0])};
    const a=this.arc(clock);
    return {center:this.phrase.center+3*a,width:MASS.width[0]+(MASS.width[1]-MASS.width[0])*a,density:MASS.density[0]+(MASS.density[1]-MASS.density[0])*a};
  }
  // The cantus: from the centre, by the steps of the scale heard (a pool of five classes or more), else by semitones,
  // within the phrase's widest band (the canon's drift makes the band that sounds: lines at different places in the
  // cantus sound different pitches at once).
  makeCantus(shape){
    const pool=(this.notes?.length?this.notes:[]).map(Number).filter(Number.isFinite),steps=[];
    const heard=[...new Set(pool.map(p=>+(((p%12)+12)%12).toFixed(6)))].sort((a,b)=>a-b),classes=heard.length>=5?heard:[0,1,2,3,4,5,6,7,8,9,10,11];
    const ladder=[];for(let octave=3;octave<=7;octave++)for(const pc of classes)ladder.push(12*octave+pc);
    ladder.sort((a,b)=>a-b);
    let at=ladder.reduce((best,p,i)=>Math.abs(p-shape.center)<Math.abs(ladder[best]-shape.center)?i:best,0);
    const low=shape.center-shape.width/2,high=shape.center+shape.width/2;
    for(let k=0;k<MASS.cantusNotes;k++){
      steps.push(ladder[at]);
      const up=at+1<ladder.length&&ladder[at+1]<=high,down=at>0&&ladder[at-1]>=low;
      at=up&&down?at+(unitRandom()<.5?1:-1):up?at+1:down?at-1:at;
    }
    return steps;
  }
  // (Each note written as it was composed -- `written`, its scoreTime -- its seconds and offset how it is played.)
  play(pitch,seconds,offset,expression={},written=null){
    if(written)return withScoreTime(this.audio,written,()=>this.play(pitch,seconds,offset,expression));
    const gain=MASS.gain/Math.sqrt(this.lines);
    if(this.audio.mode==='midi'||this.audio.mode==='samples'||typeof this.audio.voice!=='function'){this.audio.pitched(pitch,seconds,gain,'sawtooth','pad',MASS.velocity,'bowed',expression);return}
    this.audio.voice(pitch,seconds,gain,'sawtooth',offset,{instrument:'bowed',profile:'pad',velocity:MASS.velocity,...expression});
  }
  onTick(tick,clock){
    if(!clock?.meter)return;
    const spt=secondsPerTick(clock);
    if(this.lastTick!==null&&tick>this.lastTick)this.clockSeconds+=spt*(tick-this.lastTick);this.lastTick=tick;
    const shape=this.shape(clock);
    if(this.settings.texture==='masses')this.masses(clock,shape,spt);else this.micropolyphony(clock,shape,spt);
  }
  // Each line walks the cantus in its own division of the beat, its notes a little longer than the line before's, from
  // a start a beat later: attacks on each line's own grid, the canon thickening. A note held to the next, legato.
  // (Written on the same grid in ticks from the cantus's first: its entry a beat a line, each note its whole step.)
  micropolyphony(clock,shape,spt){
    const beatTicks=clock.meter.subdivision||bandMeter().subdivision,beatSeconds=beatTicks*spt;
    if(!this.cantus||(clock.phraseStart&&clock.tickInBar===0))this.cantus={notes:this.makeCantus({center:this.phrase.center,width:MASS.width[1]}),start:this.clockSeconds,startTick:clock.tick,next:Array(this.lines).fill(null)};
    const now=this.clockSeconds,until=now+spt;
    for(let line=0;line<this.lines;line++){
      const arch=1-Math.abs(2*(line+.5)/this.lines-1),most=Math.max(2,Math.floor(beatSeconds/MASS.shortest+1e-9));
      const division=Math.round(2+arch*(most-2)),unit=beatSeconds/division;
      const steps=Math.max(1,Math.round(MASS.cantusBeats*division*(1+MASS.drift*line))),length=steps*unit,ticks=new Rational(steps*beatTicks,division);
      let next=this.cantus.next[line]??{at:this.cantus.start+line*beatSeconds,score:Rational.of(this.cantus.startTick+line*beatTicks),index:0};
      // (A line enters its phrase's new cantus once its last note of the one before has ended, a step of its own later
      // where that one still sounds: entered at once, a phrase that began under the last one's long notes had sounded
      // more lines than the section has.)
      while(next.at<until&&next.index<this.cantus.notes.length){
        if(next.at>=now-1e-9&&next.at>=this.lineEnds[line]-1e-9){
          this.play(this.cantus.notes[next.index],length*.98,next.at-now,{line:`mass:${line}`,glide:false},scoreTime(next.score,ticks));this.lineEnds[line]=next.at+length*.98}
        next={at:next.at+length,score:next.score.add(ticks),index:next.index+1};
      }
      this.cantus.next[line]=next;
    }
  }
  // Glissandi: a Poisson stream of onsets at the section's density; each on a free line, from a pitch about the centre
  // to another, over its own length -- a count of ticks, its seconds' range bounding it; written on its tick, its place
  // within the tick how it is played.
  masses(clock,shape,spt){
    const now=this.clockSeconds,expected=shape.density*spt;
    let onsets=0;{let p=Math.exp(-expected),sum=p,u=unitRandom();while(u>sum&&onsets<this.lines){onsets++;p*=expected/onsets;sum+=p}}
    for(let k=0;k<onsets;k++){
      const line=this.busyUntil.findIndex(until=>until<=now);if(line<0)break;
      const from=clamp(shape.center+normal()*shape.width/2,24,108),to=clamp(shape.center+normal()*shape.width/2,24,108);
      const least=Math.max(1,Math.ceil(MASS.glissando[0]/spt-1e-9)),most=Math.max(least,Math.floor(MASS.glissando[1]/spt+1e-9));
      const ticks=least+Math.floor(unitRandom()*(most-least+1)),seconds=ticks*spt,offset=unitRandom()*spt;
      this.busyUntil[line]=now+offset+seconds;
      this.play(to,seconds,offset,{line:`mass:${line}`,glide:seconds,glideKind:'through',glideFrom:from},scoreTime(clock.tick,ticks));
    }
  }
}

export const massClodbot=defineBot(
  {
    id:'mass_clodbot',name:'mass_clodbot',status:'native',source:'clodbot',
    category:'melody',midiChannel:4,performanceType:'polyphonic',outputModes:['synth','midi'],pitchContract:'floating-mpe',
    // Its lines are a section's players (each note names its line: mass:0..7), so a score writes it divisi.
    section:true,
    specSettings:Object.freeze(['texture','lines']),
    description:'A section of up to eight lines at once, for textures of Ligeti\'s or Xenakis\'s size made of a few of them: micropolyphony (every line one slow cantus in canon, each in its own division of the beat and a little slower than the one before, so the canon thickens into a shimmering band) or masses (glissandi from pitch to pitch, their onsets a Poisson stream at the section\'s density, their pitches spread about its centre); its centre, width and density follow an arc over each phrase.',
  },
  (...args)=>new MassClodbot(...args),
);
