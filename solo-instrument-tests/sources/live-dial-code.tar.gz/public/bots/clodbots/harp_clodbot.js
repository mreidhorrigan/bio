// harp_clodbot: a harpist on a concert pedal harp, the fifth of the instrument clodbots (research/family-atlas.md F14,
// harps, lyres and harp-lutes; research/MUSEBOTS_WORLD_INSTRUMENTS_CONSTRAINTS_RESEARCH_AND_IMPLEMENTATION_REPORT.md).
// New, not a fork. Taken by c2 at 2a's offer, 29 September (SESSIONS.md 12:45).
//
// Its harmony is the band's, as jazzvoicing_clodbot reads it (the chord's guide tones, its fifth, its root where no bass
// is heard); the drummer's principles are the instrument clodbots' (instrument-performer.js): its comp on the meter's
// groups, comp and run as one continuum, a solo's course to a climax, the band's attention, its arrival at the cadence on the last
// downbeat (Closure). What a harpist adds (shared/performers/harp.js):
// - **Strings tuned for the piece, and seven pedals.** Before its first chord its strings are tuned to the band's pool
//   (each letter's natural at the band's pitch nearest it: `strings: 'band'`, the default; 'fixed', twelve-tone), and
//   its pedals set to the collection heard then. A pedal sets every string of its letter flat, natural or sharp, so
//   a letter sounds one setting at a time, across the harp (the report's §11.2).
// - **Voicings two hands pluck, and the pedals they need, by construction.** Its chords are chosen among those four
//   fingers a hand can pluck at once (harpVoicings), voice-led from the last, each pedal change a cost; a change is
//   taken only where its foot can make it within the chord's first beat (a foot moves one pedal at a time, and a pedal
//   moves only once its letter's strings are quiet), and a note on a changed letter sounds when its pedal is set. With
//   the chord, the pedals of the letters it leaves free move toward the collection heard (the report: "choose
//   enharmonic spelling and pedal state jointly with future transitions"). The pedal planner (planHarp) is the
//   reference in its tests, never asked while it plays.
// - **Rolled chords, voiced within.** A chord rolled from its lowest string to its highest (HARP_BODY.rollSeconds a
//   string) as often as the band's character is spacious more than spiky, else plucked together; its top voice, or a
//   voice moving under a held top, brought out a few dB (chord-voicing.js), so its chords make a line.
// - **Its runs along the pedals' scale**, a string at a time up and down from its voicing's top, its hands taking turns
//   by groups of four fingers (crossing over each other, as a harpist's do), never quicker than one hand's fingers
//   (HARP_BODY.noteSeconds) and each hand reaching its group in time.
// - **Its glissandi into the form's joins** (form-marks.js, as the drummers place their fills): over the last felt beat
//   before a join the intensity moves across, a hand sweeps the strings as its pedals set them, rising into more
//   intensity and falling into less, landing just before the join's downbeat; the comp and the run leave that beat to it.
// - **Its sound:** VSCO 2 CE's concert harp (CC0; scripts/download-harp-samples.mjs), else the built-in plucked voice.
import {defineBot} from '../../framework/index.js';
import {scoreTime,withScoreTime,shiftScoreTime,scoreTimeFields} from '../../shared/score-time.js';
import {dividedBeats} from '../../shared/performers/rhythm-cell.js';
import {JazzVoicingClodbot} from './jazzvoicing_clodbot.js';
import {PerformedTiming} from '../lib/modules/performed-timing.js';
import {HearsAttention} from '../lib/modules/attention.js';
import {InSection} from '../lib/modules/section-member.js';
import {InstrumentPerformer} from '../lib/modules/instrument-performer.js';
import {FormMarks} from '../lib/modules/form-marks.js';
import {HARP,HARP_BODY,harpStrings,harpVoicings,nextHarpVoicing,pedalsFor,stringPitch,stringTuning} from '../../shared/performers/harp.js';
import {secondsPerTick} from '../../shared/meter-tactus.js';
import {blendLevel,metricalWeight,rankThresholds} from '../../shared/performers/figure-blend.js';
import {broughtOut,louderBy} from '../../shared/performers/chord-voicing.js';
import {FAMILIES} from '../../shared/articulation.js';

// Its recordings: VSCO 2 CE's concert harp (scripts/download-harp-samples.mjs).
export const HARP_BANK='vscoHarp';
export const HARP_CLODBOT=Object.freeze({
  // Its built-in voice's gain: the plucked family's at about the median bot voice's loudness, as the mallet player's is
  // (bot-loudness-priors.mjs, 29 September: at the guitarist's .07 it sat 8.6 LU over the median, -27.5 LUFS).
  voiceGain:.026,
  // The run's notes a felt beat, up to twice as many at a solo's climax (ours).
  perBeat:4,
  // Levels (velocity): a run's, a run's at a solo's peak (ours).
  run:.45,runTop:.85,
  // Where its voicings sit (the middle of a voicing near this pitch: ours) and how far either side it looks.
  centre:62,reach:14,
  // How often a chord is rolled: this share where no character is heard, and from there as much more as the character
  // is spacious, as much less as it is spiky (ours).
  rolled:.75,
  // The note of a chord it brings out (chord-voicing.js broughtOut: its top, or the voice moving under a held top, the
  // line carried from chord to chord), this many dB over the others: a plucked chord's soprano, measured 3 to 6 dB over
  // its other voices (Freire, Nézio & dos Reis 2014, doi:10.5281/zenodo.850753), the middle of it, as the mallet player
  // and the guitarist take it.
  lead:4.5,
  // A glissando: its strings a second (a hand's sweep; authored), how many strings it sweeps at least and at most, how
  // long before the join's downbeat it lands (s), how long each string rings on (s), and its levels at its first string
  // and its last, rising (into more intensity) and falling (ours).
  glissPerSecond:28,glissStrings:Object.freeze([7,22]),glissGap:.02,glissRing:.6,
  glissLevels:Object.freeze({up:Object.freeze([.45,.85]),down:Object.freeze([.7,.35])}),
});
// The plucked string's velocity curve (articulation.js FAMILIES.pluck), in which its brought-out note is louder.
export const PLUCK_CURVE=Object.freeze({rangeDb:FAMILIES.pluck.rangeDb??30,exponent:FAMILIES.pluck.velocityExponent??2});

const clamp=(value,low,high)=>Math.max(low,Math.min(high,value));
const LETTERS=Object.keys(HARP.letters);

export class HarpClodbot extends FormMarks(InstrumentPerformer(JazzVoicingClodbot,{name:'harp_clodbot',kinds:['comp','run']})) {
  constructor(send,audio,settings={}){
    super(send,audio,settings);
    const strings=settings?.strings??'band';if(strings!=='band'&&strings!=='fixed')throw new RangeError('settings.strings is band or fixed');
    this.stringsKind=strings;this.tuned=null;this.pedals=null;
    // Each foot's time free (s), each letter's strings' time quiet (s), and the pedal moves made ({letter, setting, foot, from, at}).
    this.feet={LF:-Infinity,RF:-Infinity};this.quiet={};this.pedalMoves=[];
    this.voiced=null;this.runPlan=null;this.bars=[];this.strokes=[];this.glissandi=[];
    // On samples, its harp's recordings, where another bank was loaded for it; a render waits for them (`loading`).
    if(this.audio?.mode==='samples'&&typeof this.audio.loadSampleBank==='function'&&this.audio.samplePreset!=='harp')
      this.loading=this.audio.loadSampleBank(HARP_BANK,{preset:'harp'}).catch(error=>this.decide({samples:{preset:'harp',failed:String(error?.message??error)}}));
  }
  // Its time now (s).
  now(clock){return this.elapsedSeconds?.(clock)??(Number(clock?.tick)||0)*secondsPerTick(clock)}
  // Its strings tuned and its pedals set, before its first chord: to the band's pool, and the collection heard then.
  tune(){
    if(this.tuned)return this.tuned;
    const pool=this.poolPcs??[],tuning=this.stringsKind==='band'?stringTuning(pool):{};
    this.tuned={tuning,strings:harpStrings({tuning})};
    this.pedals=pedalsFor(this.collection?.()??this.scaleFor?.(pool)??pool,{tuning});
    this.decide({strings:{kind:this.stringsKind,tuning,pedals:{...this.pedals}}});
    return this.tuned;
  }
  // The pedals moved from `at` (s): each by its foot, one at a time, once the foot is free and its letter's strings are
  // quiet. -> {feet, done: {letter: when set (s)}}, or null where one cannot be set by `by`.
  pedalling(changes,at,{by=Infinity}={}){
    const feet={...this.feet},done={};
    for(const [letter,setting] of Object.entries(changes)){
      if((this.pedals[letter]??'natural')===setting)continue;
      const foot=HARP.feet[letter],from=Math.max(at,feet[foot],this.quiet[letter]??-Infinity),end=from+HARP.pedalSeconds;
      if(end>by+1e-9)return null;
      feet[foot]=end;done[letter]=end;
    }
    return {feet,done};
  }
  // Those moves made: the pedals set, the feet busy until then, each move kept.
  move(changes,pedalling){
    for(const [letter,end] of Object.entries(pedalling.done)){
      this.pedalMoves.push({letter,setting:changes[letter],foot:HARP.feet[letter],from:end-HARP.pedalSeconds,at:end});
      this.pedals[letter]=changes[letter];
    }
    this.feet=pedalling.feet;if(this.pedalMoves.length>256)this.pedalMoves.splice(0,this.pedalMoves.length-256);
  }
  // How often a chord is rolled: its share, more as the character is spacious than spiky.
  rollShare(){const character=this.character;return character?clamp(HARP_CLODBOT.rolled+(character.space??.5)-(character.attack??.5),0,1):HARP_CLODBOT.rolled}
  // A chord on a change: its guide tones (third, seventh), its fifth, its root where no bass is heard, among the voicings
  // its hands can pluck, voice-led from the last, each pedal change a cost and taken only where a foot sets it within
  // the chord's first beat. Plucked again as it is between changes.
  attack(clock,{change}){
    const chord=this.chord;if(!chord)return;
    const {strings}=this.tune();
    const spt=this.secondsPerTick(clock),beat=this.beatTicks(clock),offbeat=clock.tickInBar%beat!==0,final=this.closing?.phase==='final';
    const seconds=(offbeat?.6:1.4)*beat*spt;
    if(!change&&this.voiced){this.sound(clock,this.voiced,seconds,this.vl.velocity-(offbeat?.02:.06));this.announce(clock,this.voiced.pitches);return}
    const at=this.now(clock),by=at+beat*spt,readings=this.readingsOf(clock);
    // (Every reading of the chord its hands and pedals can hold (chord-readings.js), each in the object's own tuning, each
    // dearer as its taste for the reading is less; where they hold none with every tone of one, the most of its tones they
    // do, those it requires first.)
    const voicingsOf=(tones,required)=>harpVoicings(tones,required,{strings,pedals:this.pedals,free:LETTERS,centre:HARP_CLODBOT.centre,reach:HARP_CLODBOT.reach})
      .filter(voicing=>this.pedalling(voicing.changes,at,{by})!==null);
    const options=readings.flatMap(reading=>{
      const ordered=[...reading.required,...reading.pcs.filter(pc=>!reading.required.includes(pc))];let found=voicingsOf(ordered,reading.required);
      for(let keep=ordered.length;!found.length&&keep>=1;keep--)found=voicingsOf(ordered.slice(0,keep),[]);
      return found.map(voicing=>({...voicing,reading:reading.id,readingCost:reading.cost}))});
    const voicing=nextHarpVoicing(options,this.voiced,{centre:HARP_CLODBOT.centre});
    if(!voicing){this.decide({tick:clock.tick,noVoicing:readings.map(reading=>reading.id)});return}
    // Its pedals, then those of the letters it leaves free toward the collection heard, as their feet come free.
    const pedalling=this.pedalling(voicing.changes,at);this.move(voicing.changes,pedalling);
    const used=new Set(voicing.notes.map(note=>note.letter)),toward=pedalsFor(this.collection?.()??[],{tuning:this.tuned.tuning});
    const ahead=Object.fromEntries(LETTERS.filter(letter=>!used.has(letter)&&this.collection?.()&&toward[letter]!==this.pedals[letter]).map(letter=>[letter,toward[letter]]));
    const later=this.pedalling(ahead,at);if(later&&Object.keys(later.done).length)this.move(ahead,later);
    this.voiced={...voicing,setAt:pedalling.done};this.voicing=voicing.pitches;this.lastReading=voicing.reading;
    this.sound(clock,this.voiced,seconds,this.vl.velocity);this.announce(clock,voicing.pitches);
    this.decide({tick:clock.tick,change:true,chord:`${chord.root}:${chord.quality}`,reading:voicing.reading,voicing:{pitches:voicing.pitches,LH:voicing.hands.LH,RH:voicing.hands.RH},
      ...(Object.keys(voicing.changes).length?{pedals:voicing.changes}:{}),...(Object.keys(ahead).length?{ahead}:{})});
  }
  // Plucked at the level the fillness leaves the comp (compLevelAt): rolled from its lowest string to its highest, or
  // together, each note on a changed letter once its pedal is set; held to the run's next note in a bar it runs.
  sound(clock,voicing,seconds,velocity=this.vl.velocity){
    const compLevel=this.compLevelAt(clock);if(!(compLevel>0))return;
    // A glissando's beat is its own (glide).
    if(this.gliding(clock))return;
    if((clock.tickInBar??0)===0)this.planRun(clock);
    const spt=secondsPerTick(clock),tick=clock.tickInBar??0,now=tick*spt,at=this.now(clock);
    const next=this.runPlan?.bar===clock.bar?this.runPlan.notes.map(note=>note.start).find(start=>start>now+1e-9):undefined;
    const held=next===undefined?seconds:Math.max(.05,Math.min(seconds,next-now-HARP_BODY.noteSeconds));
    const level=clamp(velocity*compLevel,0,1),rolled=this.random(`roll:${clock.bar}:${tick}`)()<this.rollShare();
    const notes=[...voicing.notes].sort((a,b)=>a.pitch-b.pitch),pitches=notes.map(note=>note.pitch);
    // The note it brings out, HARP_CLODBOT.lead dB over the others.
    const line=pitches.length>1?pitches[broughtOut(pitches,this.previousVoicing,this.previousLine,{bass:this.bassHeard(clock)===null})]:null;
    const loud=louderBy(level,HARP_CLODBOT.lead,PLUCK_CURVE);
    // (A string's place in the roll is the chord's, written with it: its roll; a pedal still setting, later than that, is
    // the string sounding late, its lag.)
    withScoreTime(this.audio,{...this.compInterval(clock),scoreArpeggio:rolled},()=>notes.forEach((note,k)=>{
      const roll=rolled?k*HARP_BODY.rollSeconds:0,offset=Math.max(roll,(voicing.setAt?.[note.letter]??-Infinity)-at);
      this.strike(note.pitch,Math.max(.05,held-offset),line!==null&&Math.abs(note.pitch-line)<1e-9?loud:level,offset,{roll,lag:offset-roll});
      this.quiet[note.letter]=Math.max(this.quiet[note.letter]??-Infinity,at+offset+held);
    }));
    this.previousVoicing=pitches;this.previousLine=line;
    this.count(clock,'comp');
    this.strokes.push({bar:clock.bar,tick,rolled,pitches,...(line!==null?{line}:{})});if(this.strokes.length>64)this.strokes.shift();
  }
  // A string plucked: its recording (samples: the bank's nearest, at its pitch; its one dynamic given the others by level
  // and brightness), the built-in plucked voice, or MIDI to an instrument outside. `roll`, `lag` (s): how much of `offset`
  // is its chord's roll and how much its sounding late (audio.js expression.roll, expression.lag: a score writes the
  // chord together, rolled); `gliss`: the glissando it is a string of (expression.gliss).
  strike(pitch,seconds,asked,offset,{roll=0,lag=0,gliss=null}={}){
    const velocity=this.plannedVelocity(asked,'pluck');
    const told={...(roll?{roll}:{}),...(Math.abs(lag)>1e-9?{lag}:{}),...(gliss?{gliss}:{})};
    if(this.audio?.mode==='midi'){this.audio.midiNote?.(pitch,seconds,velocity,undefined,offset,{instrument:'pluck',profile:'pluck',...told});return}
    if(this.audio?.mode==='samples'&&typeof this.audio.samplePitch==='function'){this.audio.samplePitch(pitch,offset,this.audio.sampleLevel?.(.565,velocity,'pluck')??.565*velocity,seconds,velocity,told);return}
    this.audio?.voice?.(pitch,seconds,HARP_CLODBOT.voiceGain,'sawtooth',offset,{instrument:'pluck',profile:'pluck',velocity,...told});
  }
  everyTick(clock){
    super.everyTick?.(clock);
    if((clock.tickInBar??0)===0)this.planRun(clock);
    const mark=this.gliding(clock);if(mark&&mark.step===0)this.glide(clock,mark);
  }
  // The form's mark at this tick where it asks a glissando (a fill up or down, form-marks.js), else null.
  gliding(clock){const mark=this.enabled===false?null:this.formMark?.(clock);return mark&&(mark.fill==='up'||mark.fill==='down')?mark:null}
  // A glissando over the mark's beat: a hand sweeping the strings as its pedals set them, from the harp's middle, up or
  // down, as many strings as a sweep crosses in the beat (within glissStrings), landing glissGap before the join.
  glide(clock,mark){
    if(!this.tuned||!this.pedals)return;
    const spt=secondsPerTick(clock),at=this.now(clock),seconds=Math.max(.1,mark.steps*spt-HARP_CLODBOT.glissGap),[least,most]=HARP_CLODBOT.glissStrings;
    const count=clamp(Math.round(seconds*HARP_CLODBOT.glissPerSecond),least,most),step=seconds/count,up=mark.fill==='up',strings=this.tuned.strings;
    const middle=strings.reduce((best,string)=>Math.abs(string.natural-HARP_CLODBOT.centre)<Math.abs(best.natural-HARP_CLODBOT.centre)?string:best);
    const from=clamp(middle.index+(up?-1:1)*Math.floor(count/2),0,strings.length-1),[first,last]=HARP_CLODBOT.glissLevels[mark.fill],notes=[];
    for(let k=0;k<count;k++){const index=from+(up?k:-k);if(index<0||index>=strings.length)break;notes.push({string:strings[index],offset:k*step})}
    // (Written as a harpist reads one: its first string on the mark's beat and its last on the beat's last tick, joined by
    // a line; the strings between sounded, not printed. The last string's time from that tick is its lag.)
    const lastWritten=mark.steps>1?(mark.steps-1)*spt:null;
    notes.forEach(({string,offset},k)=>{
      const pitch=stringPitch(string,this.pedals[string.letter]??'natural'),level=first+(last-first)*(notes.length>1?k/(notes.length-1):1);
      const ring=Math.max(.05,seconds-offset+HARP_CLODBOT.glissRing),gliss={id:clock.tick,index:k,of:notes.length};
      const lag=k===notes.length-1&&k>0&&lastWritten!==null?offset-lastWritten:0;
      const isLast=k===notes.length-1&&k>0,lastTick=clock.tick+Math.max(0,mark.steps-1);
      const written=isLast?scoreTime(lastTick,1):scoreTime(clock.tick,Math.max(1,mark.steps-1));
      withScoreTime(this.audio,written,()=>this.strike(pitch,ring,clamp(level*(this.vl?.velocity??.46)/.46,0,1),offset,{lag,gliss}));
      this.quiet[string.letter]=Math.max(this.quiet[string.letter]??-Infinity,at+offset+ring);
    });
    this.glissandi.push({bar:clock.bar,tick:clock.tickInBar??0,join:mark.join,fill:mark.fill,seconds:+seconds.toFixed(3),at:+at.toFixed(4),
      pitches:notes.map(({string})=>stringPitch(string,this.pedals[string.letter]??'natural')),strings:notes.map(({string})=>string.index)});
    if(this.glissandi.length>64)this.glissandi.shift();
  }
  // The run, planned once at a bar's start where the fillness asks for one: a string at a time along the pedals' scale
  // from the voicing's top, turning back at the reach's edge; its hands taking turns by groups of four fingers, each
  // group within a hand's span and reached in time; its notes at the felt beats' subdivisions but near a chord (faster at
  // a solo's climax, never quicker than a hand's fingers), each at the level the fillness gives it, within the band's
  // attention's allowance.
  planRun(clock){
    if(this.runPlan?.bar===clock.bar)return;
    this.runPlan={bar:clock.bar,notes:[]};
    if(!this.chord||!this.voiced||!this.tuned)return;
    const fillness=this.fillnessOf(clock)??0,solo=this.soloIntensity(clock);if(!(fillness>0)&&solo===null)return;
    const spt=secondsPerTick(clock),span=clock.meter.pulsesPerBar,felt=this.felt(clock),intensity=solo??0;
    const shortest=Math.min(...felt.map(beat=>beat.length))*spt,fastest=Math.max(1,Math.floor(shortest/HARP_BODY.noteSeconds));
    const perBeat=Math.min(fastest,Math.round(HARP_CLODBOT.perBeat*(1+intensity)));
    // No run note within a finger's note of a chord, nor of the bar's end (the next bar's first chord), nor in a
    // glissando's beat (its window: form-marks.js fillAhead).
    const busy=[...(this.comp?.bar===clock.bar?this.comp.hits:[]),span],ahead=this.fillAhead?.(clock);
    const window=ahead&&(ahead.fill==='up'||ahead.fill==='down')?[ahead.ticksUntil,ahead.ticksUntil+ahead.steps]:null;
    const positions=dividedBeats(felt,perBeat)
      .filter(({at})=>busy.every(hit=>Math.abs(hit-at)*spt>=HARP_BODY.noteSeconds-1e-9)&&!(window&&at>=window[0]-1e-9&&at<window[1]+1e-9));
    // The strings within reach at their pedals, low to high: the pedals' scale.
    const {centre,reach}=HARP_CLODBOT,under=this.tuned.strings.map(string=>({string,pitch:stringPitch(string,this.pedals[string.letter]??'natural')}))
      .filter(({pitch})=>pitch>=centre-reach-1e-9&&pitch<=centre+reach+1e-9);
    if(under.length<2)return;
    const top=Math.max(...this.voiced.pitches),start=Math.max(0,under.findIndex(({pitch})=>pitch>=top)),last=under.length-1;
    const path=positions.map((_,k)=>{const period=2*last,phase=(start+k)%period;return under[phase<=last?phase:period-phase]});
    const u=this.random(`run:${clock.bar}`),items=positions.map(({at,scoreTime},k)=>({id:`run${k}`,at,scoreTime,weight:metricalWeight(at,{beatStarts:felt.map(beat=>beat.start),span}),position:at/span,u:u()}));
    const thresholds=rankThresholds(items,{order:this.fillOrder});
    // The hands by groups of four fingers, the right's first; a group's strings within its hand's span, and each hand
    // reaching its next group's first string by the time it is plucked (from its last group's last). A note its hand
    // cannot reach is left out.
    const barStart=this.now(clock),notes=[];let left=0;const reachOf={RH:null,LH:null};
    positions.forEach(({at,scoreTime},k)=>{
      const hand=Math.floor(k/HARP_BODY.fingers)%2?'LH':'RH',{string,pitch}=path[k],time=barStart+at*spt,last=reachOf[hand];
      const group=path.slice(k-k%HARP_BODY.fingers,k-k%HARP_BODY.fingers+HARP_BODY.fingers).map(entry=>entry.string.index);
      const within=Math.max(...group)-Math.min(...group)<=HARP_BODY.spanStrings;
      const reaches=!last||k%HARP_BODY.fingers!==0||Math.abs(string.x-last.x)<=HARP_BODY.handMmPerSecond*Math.max(0,time-last.at)+1e-9;
      const level=blendLevel(thresholds.get(`run${k}`),this.fillnessOf(clock,Math.min(span-1e-9,at))??0,{entering:true});
      if(!within||!reaches){left++;return}
      reachOf[hand]={x:string.x,at:time};
      if(level>0)notes.push({scoreTime:shiftScoreTime(scoreTime,clock.tick-(clock.tickInBar??0),{axis:'ensemble'}),pitch,letter:string.letter,hand,start:at*spt,end:(at+span/(felt.length*perBeat)*.9)*spt,level});
    });
    const level=HARP_CLODBOT.run+(HARP_CLODBOT.runTop-HARP_CLODBOT.run)*intensity;
    const {heard,claim,givenBackDb}=this.licensed(clock,notes.map(note=>({at:note.start,velocity:level*note.level})));
    for(const note of notes){
      withScoreTime(this.audio,note,()=>this.strike(note.pitch,note.end-note.start,this.softer(level*note.level,givenBackDb),note.start));
      this.quiet[note.letter]=Math.max(this.quiet[note.letter]??-Infinity,barStart+note.end);
    }
    this.runPlan={bar:clock.bar,notes:notes.map(note=>({...scoreTimeFields(note),pitch:note.pitch,hand:note.hand,start:note.start,end:note.end}))};
    this.count(clock,'run',notes.length);
    this.bars.push({bar:clock.bar,fillness:+fillness.toFixed(3),run:notes.length,of:items.length,perBeat,...(left?{unreached:left}:{}),...(solo===null?{}:{intensity:+intensity.toFixed(3)}),
      ...(heard?{attention:{claimDb:claim?+claim.claimDb.toFixed(2):null,allowanceDb:+heard.allowanceDb.toFixed(2),soloing:heard.soloing,givenBackDb:+givenBackDb.toFixed(2)}}:{})});
    if(this.bars.length>64)this.bars.shift();
  }
}

export const PerformedHarp=HearsAttention(PerformedTiming(HarpClodbot,{instrument:'comping'}));
// Seated in a percussion section (settings.seat, settings.kind 'percussion'), it rests where its section's conductor
// rests it (bots/lib/modules/section-member.js).
export const SeatedHarp=InSection(PerformedHarp);
export const harpClodbot=defineBot(
  {
    id: "harp_clodbot",orchestral:true, name: "harp_clodbot", status: "native", source: "clodbot",
    category: "harmony", midiChannel: 7, performanceType: "polyphonic", outputModes: ["synth", "samples", "midi"],
    sampleBank: HARP_BANK,
    // Its strings tuned to the band's pool before the piece unless a spec asks for twelve-tone strings (strings: 'fixed').
    pitchContract: "floating-mpe",
    specSettings: Object.freeze(["fillness", "fillOrder", "density", "strings", "seat", "size", "kind", "section", "arrival"]),
    description:
      "A harpist on a concert pedal harp whose hands and feet play only what a harpist's can, by construction: the band's harmony (its guide tones, fifth, and root where no bass is heard) in voicings four fingers a hand can pluck, voice-led from the last, each spelled on the seven pedals, a pedal changed only where a foot can set it in time and the rest moved toward the scale heard; chords rolled as the band's space asks; runs along the pedals' scale, its hands taking turns by groups of four fingers; glissandi into the form's joins, rising into more intensity and falling into less; its strings tuned to the band's pool before the piece; comp and run as one continuum, a solo's course, and the band's attention.",
  },
  (...args) => new SeatedHarp(...args),
);
