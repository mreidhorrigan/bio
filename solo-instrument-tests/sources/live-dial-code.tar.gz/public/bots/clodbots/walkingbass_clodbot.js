// walkingbass_clodbot: a fork of ae_WalkingBassBOT that states each chord's root as the chord arrives, keeps its rhythm on
// the bar, walks compound meters by their dotted-quarter beats, keeps under the chords it hears and out of octaves and
// fifths with the voices it hears (the patterns: ../lib/compound-meter.js).
// Made from the class it forks, which agents.js holds, by a function (no import cycle).
import {defineBot} from '../../framework/index.js';
import {GroupingChoice} from '../lib/modules/grouping-choice.js';
import {tactusOf,secondsPerTick} from '../../shared/meter-tactus.js';
import {HeardVoices,voicesPayload,onsetBefore} from '../../shared/sounding-voices.js';
import {parallelsAgainst} from '../../shared/voice-leading.js';
import {parseChordLabel} from '../../shared/chromatic-harmony.js';
import {compoundBassCycle} from '../lib/compound-meter.js';
import {Closure} from '../lib/modules/closure.js';
import {Phrasing} from '../lib/modules/phrasing.js';
import {transportSeconds} from '../lib/modules/timekeeping.js';
import {pitchClassDistance} from '../../shared/estimation/harmonic-levels.js';
import {PerformedTiming} from '../lib/modules/performed-timing.js';
import {bandMeter} from '../../shared/opening-time.js';
import {ScoreEvents} from '../../shared/score-time.js';
import {instrumentRange} from '../../shared/performers/instrument-ranges.js';
// (Its lowest note: the contrabass's low E, the instrument registry's.)
const LOWEST=instrumentRange('contrabass').range[0];

// The note the bot it forks plays (audio.js bass's own length).
const BASS_SECONDS=.24;

export function walkingbassClodbotClass(WalkingBassBot){
  // It phrases its line (bots/lib/modules/phrasing.js): now and then a slide into a new chord's root, from the note before
  // where they join, else from a whole step under it; its notes keep their pitch still (no vibrato).
  class WalkingBassClodbot extends Phrasing(Closure(WalkingBassBot)) {
    // Its rhythm keeps to the bar. The port turns each instance's cycle by a random phase (the framework's instancePhase),
    // so that its two notes a bar fell on off-beat sixteenths (ticks 7 and 15 of sixteen in one render, 1 and 9 in
    // another), and a chord change was stated only by chance: none of ten on a GuitarSet funk take, heard or with
    // foresight. A shared rhythm the ensemble proposes still turns it.
    constructor(...args){super(...args);this.config={...this.config,preserveDownbeat:true};}
    // It hears the voice-leading bots (voice-leading-bots.js) and says what it plays, as the bass (/broadcast/voices), so
    // that they lead their voices around its line. It keeps under the chords heard: a note within a minor third of their
    // lowest voice, or above it, goes down by octaves, to E1 at the lowest (it plays its pool an octave down, and a pool
    // voiced high puts it in the chords' register). A note that would move in octaves or fifths with a voice that has just moved gives way to
    // the note of the pool nearest it that does not. With no voices heard it plays exactly as the bot it forks.
    onMessage(message){super.onMessage(message);(this.heardVoices??=new HeardVoices()).hear(message,this.instanceId??null);}
    // Its ending (Closure): on the cadence bar's downbeat, the root of the chord the ensemble cadences from; on the last
    // bar's, the last chord's root, its own length; walking again only in between.
    // Seconds of transport time at this tick (timekeeping.js transportSeconds), kept every tick so a tempo change is
    // counted where it happens: its phrasing's clock (the audit's B14; tick * secondsPerTick ran back at a tempo change).
    elapsedSeconds(clock){return transportSeconds(this.transportClock??={},clock)}
    onTick(tick,clock){
      this.bassClock=clock;
      this.elapsedSeconds(clock);
      const closing=this.closingAt(clock),at=clock?.tickInBar??0;
      if(closing.phase==='after')return;
      if(closing.phase==='final'&&at>0)return;
      if((closing.phase==='final'||closing.phase==='cadence')&&at===0&&Number.isFinite(this.notes?.[0])){
        this.lastAttackTick=tick;
        const seconds=undefined;
        return this.play(this.notes[0]-12,1,seconds,{root:true});
      }
      if(this.statesChange(tick,clock))return;
      return super.onTick(tick,clock);
    }
    // The harmony's bass: where the leader names a chord (a performer's 'C-major'), its root; else the pool's first pitch,
    // where a pool is strongest (a listener voices a pool from its strongest pitch class up; a chord bot's lowest note,
    // its inversion; an object's own lowest, as it is given: a quartal stack's, not a chord read into it).
    chordRoot(){
      const pitches=(this.notes??[]).filter(Number.isFinite);if(!pitches.length)return null;
      return parseChordLabel(this.harmonyAuthority?.()?.payload?.label)?.root??((pitches[0]%12)+12)%12;
    }
    // A chord's arrival is the bass's to state: on the first beat at or after the harmony's bass changes, it plays it,
    // accented, whatever its rhythm would have played there, and walks on from it: under the chords heard, in the octave
    // that moves in no octaves or fifths with a voice that has just moved (contrary motion to it), else nearest where it was.
    statesChange(tick,clock){
      if(!clock?.beatStart)return false;
      const root=this.chordRoot();if(root===null||(this.statedRoot!==undefined&&Math.abs(root-this.statedRoot)<.01))return false;
      this.statedRoot=root;this.lastAttackTick=tick;
      const last=Number.isFinite(this.lastBass)?this.lastBass:43,under=this.underChords(clock),octaves=[];
      for(let note=root+24;note<=60;note+=12)if(note>=LOWEST)octaves.push(note);
      const kept=octaves.filter(note=>note<=under),options=kept.length?kept:octaves.slice(0,1);
      const predicted=note=>{if(!Number.isFinite(this.lastBass))return 0;const {from,to}=this.predictedMoves(note,clock);return from.length?parallelsAgainst([this.lastBass],[note],from,to).length:0};
      const note=options.map(note=>({note,parallels:this.parallelsTo(note,clock)+predicted(note),step:Math.abs(note-last)}))
        .sort((a,b)=>a.parallels-b.parallels||a.step-b.step)[0]?.note??root+36;
      // The pool's root, a class either side of it (a root .01 below counts as one .01 above: the audit's B14).
      const index=this.notes.findIndex(pitch=>pitchClassDistance(pitch,root,12)<.01);if(index>=0)this.noteIndex=index;
      this.play(note,1,undefined,{root:true});
      return true;
    }
    // The cadence's and the final chord's root (root) is played as it is: the voices around it move around it.
    play(note,accent,seconds,{root=false}={}){
      const clock=this.bassClock,heard=this.heardVoices,under=this.underChords(clock);
      while(note>under&&note-12>=LOWEST)note-=12;
      if(!root&&heard&&Number.isFinite(this.lastBass)&&Number.isFinite(clock.tick)){
        const {othersFrom,othersTo}=heard.pairs(clock.tick,{since:onsetBefore(clock.tick,clock.meter?tactusOf(clock.meter).ticks:4)});
        if(othersTo.length&&parallelsAgainst([this.lastBass],[note],othersFrom,othersTo).length){
          const options=this.notes.flatMap(pitch=>[pitch-24,pitch-12,pitch]).filter(pitch=>Math.abs(pitch-this.lastBass)<=9&&pitch!==note&&(pitch<=under||pitch-12<LOWEST))
            .sort((a,b)=>Math.abs(a-note)-Math.abs(b-note)||a-b);
          const clear=options.find(pitch=>!parallelsAgainst([this.lastBass],[pitch],othersFrom,othersTo).length);
          if(clear!==undefined)note=clear;
        }
      }
      // As the bot it forks plays (bass, 0.24 s) unless held longer, phrased.
      const held=seconds??BASS_SECONDS,phrase=this.phraseNote({pitch:note,seconds:held,at:this.elapsedSeconds(clock),clock,role:'bass',root,accent});
      // Its rhythm's next eligible attack bounds this cell. A newly heard root may end it earlier by composition
      // revision; the short bass release never supplies its written length.
      const closing=this.closingAt(clock),meter=clock.meter,at=clock.tickInBar;
      const minGap=Math.max(1,Math.ceil(meter.subdivision*(this.config.minimumBeatsBetweenAttacks||0)));
      const rhythm=this.rhythm(this.interpretClock(clock),this.config);
      const next=rhythm.findIndex((hit,index)=>hit&&index>=at+minGap);
      const ticks=(next<0?meter.pulsesPerBar:next)-at;
      const events=this.written??=new ScoreEvents('bass'),event=events.create(clock.tick,ticks,{replace:true});
      events.perform(this.audio,event,()=>this.audio.bass(note,accent,seconds,phrase));
      this.lastBass=note;(this.recentBass??=[]).push({tick:clock.tick,pitch:note});if(this.recentBass.length>32)this.recentBass.shift();
      this.broadcast('voices',[voicesPayload({voice:this.instanceId??'walkingbass_clodbot',role:'bass',pitches:[note],clock,style:'walking',ticks})]);
    }
    // Where its notes keep under: a minor third below the lowest voice of the chords heard (Infinity with none).
    underChords(clock){
      const heard=this.heardVoices,chords=heard&&Number.isFinite(clock?.tick)?heard.around(clock.tick).filter(voice=>voice.role==='chord'&&voice.to.length).map(voice=>voice.to[0]):[];
      return chords.length?Math.min(...chords)-3:Infinity;
    }
    // The octaves and fifths it would move in, from its last note to `note`, with a voice heard that has just moved.
    parallelsTo(note,clock){
      const heard=this.heardVoices;if(!heard||!Number.isFinite(this.lastBass)||!Number.isFinite(clock?.tick))return 0;
      const {othersFrom,othersTo}=heard.pairs(clock.tick,{since:onsetBefore(clock.tick,clock.meter?tactusOf(clock.meter).ticks:4)});
      return othersTo.length?parallelsAgainst([this.lastBass],[note],othersFrom,othersTo).length:0;
    }
    // Where the voices heard will go at this change, as the voice leaders lead them: each note to the nearest note of the
    // new harmony at or above their floor (a minor third over the highest bass of the last bar, `note` included:
    // EnsembleHearing.bassFloor), staying where it is one. Stated first on the downbeat, the root cannot hear them move,
    // so it hears where they must: a Romantic voicing held over D, with the bass moving D to F3, could only rise D to F
    // above the floor that F3 sets, in octaves with it; under F2 the same move is contrary.
    predictedMoves(note,clock){
      const heard=this.heardVoices,pool=(this.notes??[]).filter(Number.isFinite).map(pitch=>((pitch%12)+12)%12);
      if(!heard||!pool.length||!Number.isFinite(clock?.tick))return {from:[],to:[]};
      const bar=clock.meter?.pulsesPerBar||bandMeter().pulsesPerBar,recent=(this.recentBass??[]).filter(event=>event.tick>clock.tick-bar).map(event=>event.pitch);
      const floor=Math.ceil(Math.max(note,...recent))+3,from=[],to=[];
      for(const voice of heard.around(clock.tick))if(voice.role!=='bass')for(const pitch of voice.to??[]){
        let best=null;
        for(const pc of pool)for(let target=pc+12*Math.floor((floor-pc)/12);target<=pitch+12;target+=12)
          if(target>=floor-1e-9&&(best===null||Math.abs(target-pitch)<Math.abs(best-pitch)))best=target;
        if(best!==null){from.push(pitch);to.push(best);}
      }
      return {from,to};
    }
    // The ported bass chooses its notes and accents as before; only when it plays changes in a compound meter.
    rhythm(clock,config,density){
      const tactus=tactusOf(clock.meter);
      if(!tactus.compound)return super.rhythm(clock,config,density);
      const key=`${tactus.beatsPerBar}:${tactus.eighthTicks}:${config.rhythmDensity}`;
      if(this.compoundKey!==key){this.compoundKey=key;this.compoundCycle=compoundBassCycle(tactus,config.rhythmDensity??.25);}
      return this.compoundCycle;
    }
  }
  return WalkingBassClodbot;
}
export function defineWalkingbassClodbot(WalkingBassBot){
  // Under a home (meterform_clodbot), it hears the home bars in a grouping of its own, keeping the home for the others
  // most of all (bots/lib/modules/grouping-choice.js).
  // Played in the ensemble's feel, where one is set (the performance layer: docs/PERFORMANCE_TIMING.md).
  const WalkingBassClodbot=PerformedTiming(GroupingChoice(walkingbassClodbotClass(WalkingBassBot),{role:'timekeeper'}),{instrument:'bass'});
  return defineBot({
      id: "walkingbass_clodbot", name: "walkingbass_clodbot", status: "native", source: "clodbot",
      category: "bass", midiChannel: 3, outputModes: ["synth", "samples", "midi"], sampleBank: "walkingBass",
      pitchContract: "floating-mpe",
      description:
        "A fork of ae_WalkingBassBOT that states each chord's root on the beat the chord arrives, keeps its rhythm on the bar, and walks compound meters (6/8, 9/8, 12/8) by their dotted-quarter beats, with pickups on the last triplet; otherwise it walks the pool as ae_WalkingBassBOT does.",
    },(...args)=>new WalkingBassClodbot(...args));
}
