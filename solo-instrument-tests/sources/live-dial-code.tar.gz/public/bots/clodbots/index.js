// The clodbots: bots written here, one file each, over the shared library in ../lib/ (voice-leading-bot.js,
// rhythm-pattern-bot.js, compound-meter.js, fork.js) and ../../shared/. The user: "There is a difference between
// underlying shared library logics that many bots use, and the actual per-bot code, which latter should be smaller. If
// it is efficient to do so, the actual collection of bot code might be better as a DIRECTORY of javascript files."
//
// Each file exports its class and its definition (defineBot: its manifest and factory). agents.js places each of the
// bots below in the registry (BOT_REGISTRY, AGENTS) where it has always been, so ids, menus, links and builds are as
// they were; bots made later, forks of these or of any bot, are listed in ADDED_CLODBOTS or, since papperc_clodbot,
// LATER_CLODBOTS, and join the registry at its end.
//
// To add or fork a bot:
// 1. Write a file here. A fork that only changes settings: forkBot(base definition, base class, {id, description,
//    settings}) (../lib/fork.js). One that changes what a bot does: a class extending the base's, and defineBot; it may
//    override one module's methods (a voice leader is composed of the mixins in ../lib/modules/: Timekeeping,
//    HarmonyHearing, EnsembleHearing, NativeIntonation, TopContour, MemoryThemes, ConflictPolicy), or compose its own
//    class of other modules over Agent. A drum bot's strokes are the Drummer module's (voiceHit: accents by the beat, ghost
//    notes, rimshots, the hat's shank, tip and opening, as xdrum_clodbot plays them).
// 2. List its definition in LATER_CLODBOTS below (at the registry's very end, after papperc_clodbot).
// 3. Give it a number: append its id to LINK_BOT_IDS (../../shared/link-vocabulary.js); share links write bots by it.
// 4. The chores a new bot has here: the bot counts in test/agents.test.mjs, framework.test.mjs and
//    performance-curation.test.mjs; experiments/setup-phase/capabilities.js OVERRIDES where its description would
//    mislead the setup phase; ableton/devices.json's exclude until the user says to put it in the Live devices' menus;
//    a permanent public token in public/data/signal-tower-tokens.json (test/towers/bio-signal-towers.test.mjs);
//    `node scripts/build-test-impact-manifest.mjs`; `npm run wiki:build`.
export {romanticClodbot,RomanticClodbot} from './romantic_clodbot.js';
export {impressionistClodbot,ImpressionistClodbot} from './impressionist_clodbot.js';
export {jazzvoicingClodbot,JazzVoicingClodbot,jazzChord} from './jazzvoicing_clodbot.js';
export {pianoClodbot,PianoClodbot,PIANO_CLODBOT} from './piano_clodbot.js';
export {hindemithClodbot,HindemithClodbot} from './hindemith_clodbot.js';
export {interlockdrumClodbot,InterlockDrumClodbot} from './interlockdrum_clodbot.js';
export {riffClodbot,RiffClodbot} from './riff_clodbot.js';
export {motifprofilerClodbot,MotifProfilerClodbot} from './motifprofiler_clodbot.js';
// Forks of ported bots, made from the classes they fork (agents.js calls these once it holds those classes).
export {defineXdrumClodbot,xdrumClodbotClass} from './xdrum_clodbot.js';
export {defineWalkingbassClodbot,walkingbassClodbotClass} from './walkingbass_clodbot.js';
export {defineFormClodbot,formClodbotClass,cadenceFor,CADENCES} from './form_clodbot.js';
export {definePappercClodbot,pappercClodbotClass} from './papperc_clodbot.js';
// Forks of ported bots with the mathematical audit's findings (the user, 27 September 2026: "fix in forked form"),
// made from the classes they fork; agents.js places them at the registry's very end, after LATER_CLODBOTS.
export {defineMhdroneClodbot,mhdroneClodbotClass,MHDRONE_CLODBOT,smoothingSeconds} from './mhdrone_clodbot.js';
export {defineXbassClodbot,xbassClodbotClass,stepsInTick} from './xbass_clodbot.js';
export {defineNewbeatClodbot,newbeatClodbotClass,NEWBEAT_CLODBOT,barActivity} from './newbeat_clodbot.js';
export {defineChichichiClodbot,chichichiClodbotClass} from './chichichi_clodbot.js';
export {defineDroneClodbot,droneClodbotClass} from './drone_clodbot.js';
export {defineTangerinedreamClodbot,tangerinedreamClodbotClass,uniformSubset,repairedParts} from './tangerinedream_clodbot.js';
export {defineValencearousalClodbot,valencearousalClodbotClass,VALENCEAROUSAL_CLODBOT,wholeNotesPerTick,smoothingWholeNotes} from './valencearousal_clodbot.js';
import {riffmotifClodbot} from './riffmotif_clodbot.js';
import {harrisClodbot} from './harris_clodbot.js';
import {meterformClodbot} from './meterform_clodbot.js';
import {feedbackClodbot} from './feedback_clodbot.js';
import {singerBot,singerBotEn} from './clodbot_singerbot.js';
export {riffmotifClodbot,harrisClodbot,meterformClodbot,feedbackClodbot,singerBot,singerBotEn};
export {HarrisClodbot} from './harris_clodbot.js';

// Bots added after these, in the order they join the registry's end.
export {MeterFormClodbot} from './meterform_clodbot.js';
export {FeedbackClodbot} from './feedback_clodbot.js';
export const ADDED_CLODBOTS=Object.freeze([riffmotifClodbot,harrisClodbot,meterformClodbot,feedbackClodbot]);
// After papperc_clodbot (agents.js adds it, made from the class it forks), in the order they join.
export {editClodbot,EditClodbot} from './edit_clodbot.js';
export {formantClodbot,FormantClodbot} from './formant_clodbot.js';
// ManageBOT, relabeled a clodbot (the user, 26 September 2026): agents.js keeps it where mh_ManageBOT always stood in
// the registry, under its old id `manage`, so its link number and every saved ensemble are unchanged.
export {manageClodbot,ManageClodbot} from './manage_clodbot.js';
// Bots added after formant_clodbot: agents.js places them at the registry's very end, so the share links' bot numbers
// (LINK_BOT_IDS, append-only) keep their meaning.
export {SingerBot} from './clodbot_singerbot.js';
export const LATER_CLODBOTS=Object.freeze([singerBot,singerBotEn]);

// Forks of ported bots that time their bars and phrases in the transport's own beats (the mathematical audit's B04; the
// user, 27 September 2026: "Fix the ported bots in forked form."), made from the classes they fork, which agents.js
// passes in: they join the registry after the later clodbots, in this order.
import {defineOrnamentClodbot} from './ornament_clodbot.js';
import {defineMsynthClodbot} from './msynth_clodbot.js';
import {defineRsynthClodbot} from './rsynth_clodbot.js';
import {defineMultisynthClodbot} from './multisynth_clodbot.js';
import {defineReichguitarClodbot} from './reichguitar_clodbot.js';
import {defineMethenymelodyClodbot} from './methenymelody_clodbot.js';
import {defineAutechreClodbot} from './autechre_clodbot.js';
import {defineWindClodbot} from './wind_clodbot.js';
import {defineAtmosphereClodbot} from './atmosphere_clodbot.js';
import {defineTextureClodbot} from './texture_clodbot.js';
import {defineGranuClodbot} from './granu_clodbot.js';
import {defineDerivationsClodbot} from './derivations_clodbot.js';
import {defineSeasonsbrokenchordClodbot} from './seasonsbrokenchord_clodbot.js';
import {defineSeasonsdroneClodbot} from './seasonsdrone_clodbot.js';
// Clodbots that play the pitch languages (docs/PITCH_LANGUAGES.md): agents.js places them at the registry's very end, after the
// audit's forks, in this order.
import {atonalClodbot} from './atonal_clodbot.js';
import {mirrorClodbot} from './mirror_clodbot.js';
import {vivierClodbot} from './vivier_clodbot.js';
import {polyscalarClodbot} from './polyscalar_clodbot.js';
import {powerloopClodbot} from './powerloop_clodbot.js';
import {modallineClodbot} from './modalline_clodbot.js';
export {atonalClodbot,mirrorClodbot,vivierClodbot,polyscalarClodbot,powerloopClodbot,modallineClodbot};
export {AtonalClodbot} from './atonal_clodbot.js';
export {MirrorClodbot} from './mirror_clodbot.js';
export {VivierClodbot} from './vivier_clodbot.js';
export {PolyscalarClodbot} from './polyscalar_clodbot.js';
export {PowerloopClodbot} from './powerloop_clodbot.js';
export {ModallineClodbot} from './modalline_clodbot.js';
export const PITCH_LANGUAGE_CLODBOTS=Object.freeze([atonalClodbot,mirrorClodbot,vivierClodbot,polyscalarClodbot,powerloopClodbot,modallineClodbot]);
// Forks for the thematic form: a melody that restates its own theme where the form returns to it (docs/MOTIVIC_RETURN.md),
// made from the class it forks; agents.js places it at the registry's very end, after the pitch languages' clodbots.
export {definePapmelodyClodbot,papmelodyClodbotClass} from './papmelody_clodbot.js';
// A fork of ae_effectsBOT that puts another bot's audio through its effects (shared/effects-routing.js), made from the
// class it forks; agents.js places it at the registry's very end.
export {defineEffectsClodbot,effectsClodbotClass,EFFECTS_CLODBOT} from './effects_clodbot.js';
export {defineAudioanalyzerClodbot,audioanalyzerClodbotClass} from './audioanalyzer_clodbot.js';
// A fork of mh_HarmonyPulseBOT that counts its chords in felt beats, so a large meter has harmony throughout (the class it
// forks is imported from its family); agents.js places it at the registry's very end.
export {harmonypulseClodbot,HarmonyPulseClodbot} from './harmonypulse_clodbot.js';
// A fork of meterform_clodbot whose home moves through the space of meters (shared/meter-space.js) and which modulates
// parts apart (/agent/stream); agents.js places it at the registry's very end.
export {meterspaceClodbot,MeterSpaceClodbot,drawMeter,METER_SPACE} from './meterspace_clodbot.js';
// A bowed string, a violin, viola, cello or contrabass, its line's bow planned (shared/performers/bowed-line.js; the
// world-instruments atlas's F08); agents.js places it at the registry's very end.
export {defineBowedStringClodbot,BowedStringClodbot,BOWEDSTRING} from './bowedstring_clodbot.js';
// A transverse flute, its line's breaths planned (shared/performers/wind-line.js; the atlas's F16); agents.js places it at
// the registry's very end.
export {defineFluteClodbot,FluteClodbot,FLUTE} from './flute_clodbot.js';
// mh_TuneBOT's fork whose tuning moves through the space of tunings (shared/tuning-space.js); agents.js places it at the
// registry's very end.
export {tunespaceClodbot,TuneSpaceClodbot,drawRegime,interpolateRegime,TUNING_SPACE} from './tunespace_clodbot.js';
// A harmony source whose collection moves through the space of pitch collections (shared/collection-space.js); agents.js
// places it at the registry's very end.
export {harmonyspaceClodbot,HarmonySpaceClodbot,HARMONYSPACE} from './harmonyspace_clodbot.js';
export {stylespaceClodbot,StyleSpaceClodbot,STYLESPACE} from './stylespace_clodbot.js';
export {guitarClodbot,GuitarClodbot,GUITAR_CLODBOT,chordShapes,nextShape} from './guitar_clodbot.js';
// modalline_clodbot's fork, a line whose pitch language moves through the space of languages
// (shared/pitch-languages/language-space.js); agents.js places it at the registry's very end.
export {languagespaceClodbot,LanguageSpaceClodbot,drawLanguage,languageNamed,LANGUAGE_SPACE} from './languagespace_clodbot.js';
// A section of up to eight lines (micropolyphony, or glissando masses), for ensembles of Ligeti's or Xenakis's size;
// agents.js places it at the registry's very end.
export {massClodbot,MassClodbot,MASS} from './mass_clodbot.js';
export {malletsClodbot,MalletsClodbot,MALLETS_CLODBOT,malletVoicings,nextVoicing} from './mallets_clodbot.js';
export {kalimbaClodbot,KalimbaClodbot,KALIMBA_CLODBOT,kalimbaVoicings,nextKalimbaVoicing} from './kalimba_clodbot.js';
export {steelpanClodbot,defineSteelpanClodbot,SteelpanClodbot,STEELPAN,panPhrase} from './steelpan_clodbot.js';
export {timelineClodbot,TimelineClodbot,TIMELINE_CLODBOT,timelineInstrument} from './timeline_clodbot.js';
export {shakerClodbot,ShakerClodbot,SHAKER_CLODBOT,shakerInstrument} from './shaker_clodbot.js';
export {congueroClodbot,CongueroClodbot,CONGUERO_CLODBOT} from './conguero_clodbot.js';
export {timpaniClodbot,TimpaniClodbot,TIMPANI_CLODBOT} from './timpani_clodbot.js';
export {gongClodbot,GongClodbot} from './gong_clodbot.js';
export {batteryClodbot,BatteryClodbot} from './battery_clodbot.js';
export {acousmaticClodbot,AcousmaticClodbot,ACOUSMATIC,ACOUSMATIC_SOURCES} from './acousmatic_clodbot.js';
// A reed player and a brass player: the flute's player with their families' instruments (the orchestra's winds and brass).
export {defineWoodwindClodbot,WoodwindClodbot} from './woodwind_clodbot.js';
export {defineBrassClodbot,BrassClodbot} from './brass_clodbot.js';
export {talkingdrumClodbot,defineTalkingDrumClodbot,TalkingDrumClodbot,TALKING_DRUM_CLODBOT,talkingPhrase,reachFor} from './talkingdrum_clodbot.js';
export {harpClodbot,HarpClodbot,HARP_CLODBOT} from './harp_clodbot.js';
export {accordionClodbot,AccordionClodbot,ACCORDION_CLODBOT} from './accordion_clodbot.js';
export {harpsichordClodbot,HarpsichordClodbot,HARPSICHORD_CLODBOT} from './harpsichord_clodbot.js';
export {stringsClodbot,StringsClodbot,STRINGS} from './strings_clodbot.js';
export {plexClodbot,PlexClodbot,PLEX_CLODBOT} from './plex_clodbot.js';
export {profileClodbot,ProfileClodbot,PROFILE,PROFILE_ADDRESS,performerProfile} from './profile_clodbot.js';
export function defineQuarterTempoClodbots(classes){
  return [
    defineOrnamentClodbot(classes.OrnamentBot),
    defineMsynthClodbot(classes.MSynthBot),
    defineRsynthClodbot(classes.RSynthBot),
    defineMultisynthClodbot(classes.MultiSynthBot),
    defineReichguitarClodbot(classes.ReichGuitarBot),
    defineMethenymelodyClodbot(classes.MethenyMelodyBot),
    defineAutechreClodbot(classes.AutechreBot),
    defineWindClodbot(classes.WindBot),
    defineAtmosphereClodbot(classes.AtmosphereBot),
    defineTextureClodbot(classes.TextureBot),
    defineGranuClodbot(classes.GranuBot),
    defineDerivationsClodbot(classes.DerivationsBot),
    defineSeasonsbrokenchordClodbot(classes.SeasonsBrokenChordBot),
    defineSeasonsdroneClodbot(classes.SeasonsDroneBot),
  ];
}
