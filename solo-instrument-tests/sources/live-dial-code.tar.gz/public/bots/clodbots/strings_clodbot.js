// strings_clodbot: an orchestra's string section, a few seats a bot (the owner, 30 September 2026: "in a real orchestra,
// [Ligeti-esque masses] are done by a string section that can split into individuals and otherwise reorganize for other
// aesthetics within the same piece ... fully capable of rendering an orchestral composition with the massive number of
// parts that a Ligeti or Xenakis score has"). New, not a fork: mass_clodbot's two textures, micropolyphony and glissando
// masses, are two of this section's, played by players who can also be a section in unison, a divided one, or desks.
//
// The section is its seats (shared/performers/string-section.js: its size, `full` 16-14-12-10-8 unless a spec says, or
// Atmosphères' or Pithoprakta's); each bot plays the seats a spec gives it (`seats`: 'vn1.1-8', eight at most, one
// section's chairs: sectionBots lists a size's bots). The bot at the first violins' first chair leads, as a concertmaster
// does: a phrase ahead, it chooses the section's formation -- its grouping (sections, choirs, all one), its split (tutti,
// divisi a 2 ... every player a part), each pool's texture, centre, width, density and level -- a jump, a move part of the
// way from the formation it is in, or the same again; the piece's last phrase tutti in chords. It announces it on
// /broadcast/group/formation (a subconductor's message for its group, `strings:<size>`: the owner, 30 September 2026, "We
// are essentially programming a kind of section leader or subconductor for strings", toward a protocol where managers,
// conductors and subconductors each lead a group of agents), and every bot plays its seats' part of it from the part's own
// seed, so a part shared by two bots is played together. A spec may fix a grouping, split or texture (the owner's to ask for); else the choices are
// the concertmaster's, in performance.
//
// Each note names its seat as its line ('vn1.3'), so a complete score writes every player (score.js divisi), and an
// abridged one folds each section to a staff (notation/section-summary.js).
//
// **Archived, 1 October 2026.** Musebots 3.0's section is many playing bots, never one (the owner: "there can be no
// 'strings_clodbot' that acts as a section; rather, a section must consist of many playing bots"). A section is now a
// conductorbot given the section's specification (plex_clodbot, settings.section: shared/conducting/section-kinds.js)
// and one bowedstring_clodbot a seat (settings.seat: bots/lib/modules/section-seat.js). This bot is kept, unchanged, as
// a reference ("there could be circumstances where a whole-section bot could be useful later"): a spec may still name
// it, and no menu or 3.0 band offers it (its manifest's `archived`).
import {Agent,defineBot} from '../../framework/index.js';
import {secondsPerTick} from '../../shared/meter-tactus.js';
import {unitRandom} from '../../shared/stochastic.js';
import {Closure} from '../lib/modules/closure.js';
import {textureName} from '../../shared/texture-space.js';
import {stringSeats,parseSeats,formationPlan,formationBetween,seatRoles,formationSummary,seededSource,playerOffsets,GLISSANDO,arcAt,GROUPINGS,TEXTURES,STRING_VOCABULARY}
  from '../../shared/performers/string-section.js';
import {GroupTree} from '../../shared/conducting/groups.js';
import {MASS} from './mass_clodbot.js';
import {bandMeter,bandPhraseBars} from '../../shared/opening-time.js';
import {scoreTime,readScoreTime,shiftScoreTime,withScoreTime} from '../../shared/score-time.js';
import {Rational as R} from '../../transcript/rational.js';

// ---- Choices (ours) -------------------------------------------------------------------------------------------------
export const STRINGS=Object.freeze({
  // The concertmaster's moves at a phrase: the same formation again, a formation part of the way to a new one (at a tenth
  // drawn), or a jump to a new one.
  stay:.2,between:.35,
  gain:.06,velocity:.45,   // each bot's seats together about mass_clodbot's eight lines; a player's share by its seats
  bowSeconds:Object.freeze([4,7]),   // a held note re-bowed after this long, each part at its own time
  lineBeats:Object.freeze([1,2]),    // a line's notes, in beats
  pizzicatoSeconds:.16,
  shortest:.08,            // no note begun shorter than this before its phrase ends (s): the next formation's downbeat is its own
});
const clamp=(x,low,high)=>Math.max(low,Math.min(high,x));
const modulo=(x,n)=>((x%n)+n)%n;
// A normal draw (Box-Muller) from a source.
const normalFrom=random=>Math.sqrt(-2*Math.log(Math.max(1e-12,random())))*Math.cos(2*Math.PI*random());
// A part's voice: a line's whole pool one voice, else each part its own.
const voiceKey=role=>role.texture==='line'?role.pool:`${role.pool}:${role.part}`;
// A pitch into a seat's compass by octaves (a basses' octave below the cellos, as orchestras double).
// Whether a formation honours checked constraints (none: yes). (Its textures the texture space's names, an old one read as
// its location's: texture-space.js.)
const honoursConstraints=(formation,constraints={})=>{
  const {grouping,split,texture,level}=constraints??{},inRange=(value,range)=>!range||value>=range[0]-1e-9&&value<=range[1]+1e-9;
  return (!grouping||grouping.includes(formation.grouping))&&inRange(formation.split,split)
    &&formation.pools.every(pool=>(!texture||texture.map(textureName).includes(textureName(pool.texture)))&&inRange(pool.level,level));
};
const intoCompass=(pitch,seat)=>{let p=pitch;while(p<seat.low)p+=12;while(p>seat.high)p-=12;return p<seat.low?null:p};

export class StringsClodbot extends Closure(Agent){
  constructor(send,audio,settings={}){
    super(send,audio);
    this.settings={size:'full',seats:'vn1.1-8',...settings};
    this.seats=stringSeats(this.settings.size);this.mine=parseSeats(this.settings.seats,this.seats);
    for(const [key,list] of [['grouping',GROUPINGS],['texture',TEXTURES]])if(this.settings[key]!=null&&!list.includes(key==='texture'?textureName(this.settings[key]):this.settings[key]))throw new RangeError(`settings.${key} is one of ${list.join(', ')}`);
    if(this.settings.split!=null&&!(this.settings.split>=0&&this.settings.split<=1))throw new RangeError('settings.split is between 0 and 1');
    // The concertmaster: the first violins' first chair (or the size's first seat, where it has no first violins); in a
    // band that seats only some of the section, the bot its spec names (`leads: true`).
    const first=this.seats[0];this.leads=this.settings.leads===true||this.settings.leads!==false&&this.mine.some(seat=>seat.id===first.id);this.group=`strings:${this.settings.size}`;
    this.formations=new Map;this.current=null;this.voices=new Map;this.clockSeconds=0;this.lastTick=null;this.formationsChosen=[];
    // Each seat's note sounding (its identity in the engine), let go as its next begins: a player plays one note at a time.
    this.held=new Map;
    // The groups it is within, as it hears them (shared/conducting/groups.js): the section's parent (settings.parent, a
    // group whose conductor directs it: Musebots 3.0), that group's parent, and so on up; and the constraints each is
    // given from a bar on (/broadcast/group/constraints), which bind the section too. A spec's apply throughout, and a
    // conductor's narrow them.
    this.tree=new GroupTree();this.tree.set(this.group,{parent:this.settings.parent??null,members:this.seats.map(seat=>seat.id)});
  }
  onMessage(message){
    super.onMessage(message);
    // The groups above it, and the constraints from above for this group or any it is within (a conductor's, or a cue's),
    // from a bar on: what the concertmaster chooses within.
    if(message?.address==='/broadcast/group'||message?.address==='/broadcast/group/constraints'){this.tree.hear(message);return}
    if(message?.address!=='/broadcast/group/formation')return;
    const plan=message.args?.[0];
    if(plan?.group===this.group&&Number.isInteger(plan.appliesAt?.bar)&&plan.formation?.pools&&!this.formations.has(plan.appliesAt.bar))this.formations.set(plan.appliesAt.bar,{...plan,knownAt:this.lastTick??-1});
  }
  // The concertmaster's choice for the phrase from `bar`, `bars` long: the same again, part of the way to a new one, or
  // a new one; the piece's last phrase tutti in chords.
  chooseFormation(bar,bars){
    const ending=this.ending?.(),final=Boolean(ending&&ending.finalBar>=bar&&ending.finalBar<bar+bars),{grouping,split,texture}=this.settings;
    const above=this.tree.constraintsFor(this.group,bar,STRING_VOCABULARY),bound=above&&Object.keys(above.constraints).length?above:null;
    for(const refused of above?.refused??[])this.audio?.report?.('strings_constraints_refused',{group:refused.level,error:refused.error});
    const fresh=formationPlan(this.seats,{random:unitRandom,final,grouping,split,texture,constraints:above?.constraints??{}}),previous=this.current?.plan.formation;
    let formation=fresh,move='jump';
    if(previous&&!final){
      const u=unitRandom();
      // (Part of the way from a formation that already honours the constraints stays within them: the split, places and
      // levels between two within a range are within it, each pool's texture one of the two. From one that does not, a
      // formation between would not.)
      if(u<STRINGS.stay&&!bound){formation=previous;move='stay'}
      else if(u<STRINGS.stay+STRINGS.between&&previous.grouping===fresh.grouping&&honoursConstraints(previous,bound?.constraints)){const t=(1+Math.floor(unitRandom()*9))/10;formation=formationBetween(previous,fresh,t,this.seats);move=`between ${t}`}
    }
    // A new phrase's material from new seeds, whatever the formation.
    formation={...formation,pools:formation.pools.map(pool=>({...pool,seed:Math.floor(unitRandom()*2**31)}))};
    // What it honoured from above, and from whom (a parent conductor's constraints: a group within a group, at any depth).
    const plan={group:this.group,leader:this.instanceId??null,parent:this.settings.parent??bound?.from??null,members:this.seats.map(seat=>seat.id),appliesAt:{bar},bars,move,final,
      ...(bound?{constraints:bound.constraints}:{}),formation,summary:formationSummary(formation)};
    // (Known now, begun a tick later, as the others hear it: every bot begins it on one tick.)
    this.formations.set(bar,{...plan,knownAt:this.lastTick??-1});
    this.broadcast('group/formation',[plan]);
    this.formationsChosen.push({bar,move,summary:plan.summary});if(this.formationsChosen.length>64)this.formationsChosen.shift();
    this.audio?.report?.('strings',{bar,move,summary:plan.summary});this.decide?.({strings:{bar,move,summary:plan.summary}});
  }
  onTick(tick,clock){
    if(!clock?.meter||!Number.isInteger(clock.bar))return;
    const spt=secondsPerTick(clock),bars=Math.max(1,Number(clock.meter.phraseBars)||bandPhraseBars());
    if(this.lastTick!==null&&tick>this.lastTick)this.clockSeconds+=spt*(tick-this.lastTick);this.lastTick=tick;
    const closing=this.closingAt?.(clock)??{phase:'none'};
    if(closing.phase==='after')return;
    // The concertmaster chooses: the first phrase at once, each next a phrase ahead.
    if(this.leads&&(clock.tickInBar??0)===0){
      if(!this.formations.size&&!this.current)this.chooseFormation(clock.bar,bars-(clock.bar%bars));
      if(clock.bar%bars===0&&!this.formations.has(clock.bar+bars))this.chooseFormation(clock.bar+bars,bars);
    }
    // A formation that applies from this bar, known before this tick (or one that was due and missed: the latest).
    const due=[...this.formations.entries()].filter(([bar,plan])=>bar<=clock.bar&&plan.knownAt<tick).map(([bar])=>bar).sort((a,b)=>a-b).at(-1);
    if(due!==undefined){const plan=this.formations.get(due);this.formations.delete(due);for(const bar of [...this.formations.keys()])if(bar<due)this.formations.delete(bar);this.begin(plan,clock,spt)}
    if(!this.current)return;
    // Each part's notes asked once a tick (from the formation's start on the tick it begins: what fell before, at once),
    // and played by each of its seats here.
    const now=this.clockSeconds,from=this.current.catchUp?this.current.start:now,until=now+spt,position=(clock.bar-this.current.plan.appliesAt.bar+(clock.tickInBar??0)/(clock.meter.pulsesPerBar||1))/this.current.plan.bars;
    // What is left of the formation's phrase, and of the piece: its notes end there, and none begins in its last instant.
    const phraseTicks=(this.current.plan.appliesAt.bar+this.current.plan.bars-clock.bar)*(clock.meter.pulsesPerBar||1)-(clock.tickInBar??0);
    const left=Math.min(phraseTicks*spt,closing.phase==='final'&&Number.isFinite(closing.ticksLeft)?closing.ticksLeft*spt:Infinity),asked=new Map;this.current.catchUp=false;
    // (Its phrase's symbolic window, in the formation's ticks from its first -- from that first where it catches up, as its
    // notes are asked -- to what is left of the phrase or the piece: the voices compose in it, section-voices.js.)
    const elapsed=clock.tick-this.current.scoreAnchor,ticksLeft=Math.min(phraseTicks,closing.phase==='final'&&Number.isFinite(closing.ticksLeft)?closing.ticksLeft:Infinity);
    const scoreWindow={at:from===now?elapsed:0,end:elapsed+ticksLeft};
    for(const seat of this.mine){
      const role=this.current.roles.get(seat.id);if(!role)continue;
      const key=voiceKey(role);
      if(!asked.has(key))asked.set(key,this.voice(role,clock,spt).events(from,until,{position,clock,spt,left,scoreWindow}).filter(event=>event.at-now<left-STRINGS.shortest));
      for(const event of asked.get(key))this.play(seat,role,event,now);
    }
  }
  // A formation begun from its bar's first tick, however late its bot heard it (the concertmaster's own at once, the others
  // a tick later): every bot's parts from the same moment, so a part's players are together.
  begin(plan,clock,spt){
    const late=(clock.bar-plan.appliesAt.bar)*(clock.meter.pulsesPerBar||1)+(clock.tickInBar??0);
    this.current={plan,roles:seatRoles(plan.formation),start:this.clockSeconds-late*spt,startBar:plan.appliesAt.bar,subdivision:clock.meter.subdivision||bandMeter().subdivision,denominator:clock.meter.denominator||bandMeter().denominator,beatSeconds:(clock.meter.subdivision||bandMeter().subdivision)*spt,catchUp:late>0,
      scoreAnchor:clock.tick-late};this.voices.clear();
  }
  // A part's voice: its generator, made once a formation from its pool's seed and its part's number, the same in every
  // bot that plays a seat of it (a line's parts all one voice).
  voice(role,clock,spt){
    const key=voiceKey(role);
    if(!this.voices.has(key)){
      // (A stroke ended before its time by its voice: its revision onto the ensemble's axis, as its notes are.)
      const anchor=this.current.scoreAnchor;
      this.voices.set(key,makeVoice(role,{random:seededSource(role.seed,key),start:this.current.start,beatSeconds:this.current.beatSeconds,pool:()=>this.notes,tick:spt,
        subdivision:this.current.subdivision,denominator:this.current.denominator,name:`${anchor}:${key}`,onScoreRevision:revision=>this.audio.reviseScore?.({...revision,scoreTime:shiftScoreTime(revision.scoreTime,anchor,{axis:'ensemble'})})}));
    }
    return this.voices.get(key);
  }
  // A seat's note: the voice's pitch in its compass, a player's own few cents and milliseconds -- its milliseconds, and a
  // drawn time's own (the voice's `lag`), how it plays, its `lag`, which its score leaves out.
  // (Each written as its voice composed it, from the phrase's axis onto the ensemble's: the formation's first tick its
  // origin.)
  play(seat,role,event,now){
    return withScoreTime(this.audio,{...event,scoreTime:shiftScoreTime(event.scoreTime,this.current.scoreAnchor,{axis:'ensemble'})},()=>this.perform(seat,role,event,now));
  }
  perform(seat,role,event,now){
    const pitch=intoCompass(event.pitch,seat);if(pitch===null)return;
    const own=playerOffsets(seat.id),gain=STRINGS.gain*role.level/Math.sqrt(this.mine.length),offset=Math.max(0,event.at-now+own.seconds),lag=own.seconds+(Number(event.lag)||0);
    // (A note caught up late -- its formation begun a tick after its bar, as a bot that hears it then begins it -- sounds
    // what is left of it, from now to its own end, and one with less left than the shortest a player takes not at all: its
    // whole length already past, it had sounded a stub under the next note, a step away, every player of the part.)
    const seconds=event.seconds-Math.max(0,now-(event.at+own.seconds));if(seconds<STRINGS.shortest)return;
    const expression={line:seat.id,glide:false,...(Math.abs(lag)>1e-9?{lag}:{})};
    if(event.from!=null){const from=intoCompass(event.from,seat);if(from!==null){expression.glide=event.seconds;expression.glideKind='through';expression.glideFrom=from+own.cents/100}}
    const sounded=pitch+own.cents/100,velocity=STRINGS.velocity*(.6+.8*role.level);
    if(this.audio.mode==='midi'||this.audio.mode==='samples'||typeof this.audio.voice!=='function'){this.audio.pitched?.(sounded,seconds,gain,'sawtooth',event.pluck?'pluck':'pad',velocity,event.pluck?'pluck':'bowed',expression);return}
    // (The seat's last note, where it still sounds, let go as this one begins: a held chord tone ends at the change.)
    const previous=this.held.get(seat.id);
    if(previous!=null)this.audio.releaseNotes?.((_,identity)=>identity===previous,{atSeconds:this.audio.eventStart?.(offset)});
    const identity=this.audio.voice(sounded,seconds,gain,'sawtooth',offset,{instrument:event.pluck?'pluck':'bowed',profile:event.pluck?'pluck':'pad',velocity,...expression});
    if(identity!=null)this.held.set(seat.id,identity);
  }
}

// ---- Voices: a part's material, deterministic from its seed ----------------------------------------------------------
// Each: {events(now, until, {position, clock, spt, left}) -> [{at, pitch, seconds, from?, pluck?, lag?}]}: its notes
// starting in [now, until). The pool heard (`pool()`) is every bot's alike at a tick, so a part's harmony is too. A time
// drawn freely (a cloud's pluck, a glissando's entry) is timing, not rhythm: written on the clock's tick (`tick`, s) from
// the formation's start, the rest its `lag` -- left to the score to recognise, a drawn time had now and then matched an
// exact fraction of the beat by chance, a 31165th, that no tree of tuplets writes (4 October's cellos).
function ladderOf(pool){
  const heard=[...new Set((pool()??[]).map(Number).filter(Number.isFinite).map(p=>+modulo(p,12).toFixed(6)))].sort((a,b)=>a-b);
  const classes=heard.length>=5?heard:Array.from({length:12},(_,k)=>k),out=[];
  for(let octave=1;octave<=8;octave++)for(const pc of classes)out.push(12*octave+pc);
  return out.sort((a,b)=>a-b);
}
const nearestIn=(list,target)=>list.reduce((best,p)=>Math.abs(p-target)<Math.abs(best-target)?p:best,list[0]);
// (Each texture composed on its formation's ticks from its first, the phrase's axis: its notes' written times exactly
// those, its seconds how they are played -- every length drawn as a count of ticks, its physical range bounding the
// count, never a performed interval rounded back into notation.)
export function makeVoice(role,{random,start,beatSeconds,pool,tick,subdivision,denominator=4,name='strings',onScoreRevision=()=>{}}){
  const {part,parts,centre,width,density}=role,texture=textureName(role.texture),band=position=>({centre:centre+3*arcAt(position),width:width*(.6+.4*arcAt(position))});
  const sub=Number(subdivision)||Math.max(1,Math.round(beatSeconds/tick));
  const ticksIn=([least,most])=>{const low=Math.max(1,Math.ceil(least/tick-1e-9));return [low,Math.max(low,Math.floor(most/tick+1e-9))]};
  const drawTicks=([low,high])=>low+Math.floor(random()*(high-low+1)),bowTicks=ticksIn(STRINGS.bowSeconds);
  const heldTo=(at,seconds,left,now)=>Math.max(.05,Math.min(seconds,left-(at-now)));
  const written=(at,end,window)=>scoreTime(at,R.of(end).min(window.end).sub(R.of(at)),{axis:'phrase'});
  const windowOf=options=>{
    if(!options?.scoreWindow)throw new TypeError('A composing voice needs its symbolic scoreWindow');
    return {at:R.of(options.scoreWindow.at),end:R.of(options.scoreWindow.end)};
  };
  let serial=0;const id=()=>`${name}:${serial++}`;
  if(texture==='line'){
    let next=0,at=nearestIn(ladderOf(pool),centre);
    return {events(now,until,options){
      const {position,left}=options,window=windowOf(options),out=[];
      while(start+next*tick<until){
        const beats=STRINGS.lineBeats[Math.floor(random()*STRINGS.lineBeats.length)],length=beats*sub,ladder=ladderOf(pool),{centre:c,width:w}=band(position);
        const index=ladder.indexOf(nearestIn(ladder,at)),step=random()<.5?-1:1,to=ladder[clamp(index+step,0,ladder.length-1)];
        at=Math.abs(to-c)>w?ladder[clamp(index-step,0,ladder.length-1)]:to;
        const when=start+next*tick;
        if(when>=now-1e-9&&R.of(next).lt(window.end))out.push({scoreTime:written(next,next+length,window),at:when,pitch:at,seconds:heldTo(when,length*tick*.97,left,now)});
        next+=length;
      }
      return out;
    }};
  }
  if(texture==='chord'){
    // (Struck where its tone changes or its bow is drawn out: a tone changed before then ends the stroke before it there.)
    let held=null,rebow=null,authored=null;
    return {events(now,until,options){
      const {position,left}=options,window=windowOf(options);
      const tones=(pool()??[]).map(Number).filter(Number.isFinite);if(!tones.length||!window.end.gt(window.at))return [];
      const {centre:c,width:w}=band(position),span=Math.max(12,w*2),target=c-span/2+span*(part+.5)/parts;
      const classes=[...new Set(tones.map(p=>modulo(p,12)))],candidates=[];
      for(let octave=1;octave<=8;octave++)for(const pc of classes)candidates.push(12*octave+pc);
      const pitch=nearestIn(candidates,target);
      if(held!==pitch||rebow==null||window.at.ge(rebow)){
        const count=drawTicks(bowTicks);held=pitch;rebow=window.at.add(count);
        if(authored){const {at:begun,end}=readScoreTime(authored);if(end.gt(window.at)){authored={...authored,scoreTime:written(begun,window.at,window)};onScoreRevision(authored)}}
        authored={scoreId:id(),scoreTime:written(window.at,rebow,window)};
        return [{...authored,at:now,pitch,seconds:heldTo(now,count*tick,left,now)}];
      }
      return [];
    }};
  }
  if(texture==='micropolyphony'){
    // mass_clodbot's canon: one cantus from the seed of the pool (every part the same), each part in its own division of
    // the beat and a little slower than the one before, from a start a beat later.
    const cantusRandom=seededSource(role.seed,`${role.pool}:cantus`),ladder=ladderOf(pool),cantus=[];
    let index=ladder.indexOf(nearestIn(ladder,centre));
    for(let k=0;k<MASS.cantusNotes;k++){cantus.push(ladder[index]);const step=cantusRandom()<.5?-1:1,to=index+step;index=Math.abs((ladder[to]??ladder[index])-centre)<=width/2?clamp(to,0,ladder.length-1):clamp(index-step,0,ladder.length-1)}
    // (Its division mass_clodbot's: an arch over eight lines, from two to as many as its beat holds playable notes.)
    const arch=1-Math.abs(2*((part%8)+.5)/8-1),most=Math.max(2,Math.floor(beatSeconds/MASS.shortest+1e-9));
    const division=Math.round(2+arch*(most-2)),unit=beatSeconds/division,steps=Math.max(1,Math.round(MASS.cantusBeats*division*(1+MASS.drift*part)));
    const length=steps*unit,scoreLength=new R(steps*sub,division),entry=new R((part%8)*sub,2);
    let next={at:start+(part%8)*beatSeconds/2,index:0};
    return {events(now,until,options){
      const {left}=options,window=windowOf(options),out=[];
      while(next.at<until){
        const scoreAt=entry.add(scoreLength.mul(next.index));if(scoreAt.ge(window.end))break;
        if(next.at>=now-1e-9)out.push({scoreTime:written(scoreAt,scoreAt.add(scoreLength),window),at:next.at,pitch:cantus[next.index%cantus.length],seconds:heldTo(next.at,length*.98,left,now)});
        next={at:next.at+length,index:next.index+1};
      }
      return out;
    }};
  }
  if(texture==='cluster'){
    // The parts spread evenly across the band, each pitch where it falls (between the keys too), held and re-bowed.
    let rebow=null;
    return {events(now,until,options){
      const {position,left}=options,window=windowOf(options);
      if(rebow!=null&&window.at.lt(rebow)||!window.end.gt(window.at))return [];
      const {centre:c,width:w}=band(position),pitch=+(c-w/2+w*(part+.5)/parts).toFixed(4),count=drawTicks(bowTicks);rebow=window.at.add(count);
      return [{scoreTime:written(window.at,rebow,window),at:now,pitch,seconds:heldTo(now,count*tick,left,now)}];
    }};
  }
  if(texture==='glides'){
    // Xenakis's: each glissando from the last one's pitch, its speed normal about none (GLISSANDO.spread semitones a
    // second), its length drawn; kept within the band by turning back at its edge; a rest now and then as the pool is
    // sparser (density).
    const lengths=ticksIn(GLISSANDO.seconds);
    let next=Math.floor(random()*sub),from=centre+(random()*2-1)*width/2;
    return {events(now,until,options){
      const {position,left}=options,window=windowOf(options),out=[];
      while(start+next*tick<until&&R.of(next).lt(window.end)){
        const {centre:c,width:w}=band(position),count=drawTicks(lengths),seconds=count*tick,at=start+next*tick;
        let to=from+normalFrom(random)*GLISSANDO.spread*seconds;
        if(to>c+w)to=2*(c+w)-to;if(to<c-w)to=2*(c-w)-to;to=clamp(to,c-w,c+w);
        if(at>=now-1e-9)out.push({scoreTime:written(next,next+count,window),at,pitch:+to.toFixed(4),from:+from.toFixed(4),seconds:heldTo(at,seconds,left,now)});
        from=to;next+=count+(random()>clamp(density,0,1)?Math.floor(random()*count):0);
      }
      return out;
    }};
  }
  // Pizzicati: a cloud, `density` plucks a second a part, each anywhere in the band -- its gaps geometric counts of
  // ticks, the discrete counterpart of Poisson arrivals, each pluck written to the next, an eighth at most.
  const gap=()=>Math.max(1,Math.ceil(-Math.log(Math.max(1e-12,random()))/(Math.max(.05,density)*tick)));
  const pluck=Math.max(1,Math.min(sub,Math.floor(sub*(Number(denominator)||bandMeter().denominator)/8)));
  let next=gap();
  return {events(now,until,options){
    const {position,left}=options,window=windowOf(options),out=[];
    while(start+next*tick<until&&R.of(next).lt(window.end)){
      const {centre:c,width:w}=band(position),at=start+next*tick,after=next+gap();
      if(at>=now-1e-9&&left>at-now)out.push({scoreTime:written(next,Math.min(after,next+pluck),window),at,pitch:+(c+(random()*2-1)*w/2).toFixed(4),seconds:STRINGS.pizzicatoSeconds,pluck:true});
      next=after;
    }
    return out;
  }};
}

export const stringsClodbot=defineBot(
  {
    id:'strings_clodbot',name:'strings_clodbot',status:'native',source:'clodbot',
    category:'texture',midiChannel:5,performanceType:'polyphonic',outputModes:['synth','midi'],pitchContract:'floating-mpe',
    // Its seats are a section's players (each note names its seat: vn1.3), so a score writes them divisi, each a line.
    section:true,
    archived:Object.freeze({since:'2026-10-01',reason:'A section is many playing bots, never one bot (Musebots 3.0)',
      by:Object.freeze(['plex_clodbot (settings.section)','bowedstring_clodbot (settings.seat)'])}),
    specSettings:Object.freeze(['size','seats','leads','grouping','split','texture','parent']),
    description:'An orchestra\'s string section, a few seats a bot (eight at most; a full section of 16-14-12-10-8, Atmosphères\' 56 or Pithoprakta\'s 46 are a handful of them): the bot at the first violins\' first chair leads, as a concertmaster does, choosing a phrase ahead how the section is grouped (each instrument, the choirs, or all one), how far it divides (tutti, divisi, every player a part), and what each pool plays -- a line in unison, a chord a tone a part, micropolyphony, a cluster between the keys, Xenakis\'s glissandi or pizzicato clouds -- and every bot plays its seats\' parts from the parts\' own seeds, together; each player a few cents and milliseconds their own. Each note names its seat, so a score writes every player, or folds each section to a staff.',
  },
  (...args)=>new StringsClodbot(...args),
);
