// harris_clodbot: a fork of jazzvoicing_clodbot that comps with the harmonic-systems core (public/shared/harmonic-
// systems/; the report research/MUSEBOTS_HARMONIC_SYSTEMS_AND_MICROTUNING_IMPLEMENTATION_REPORT.md, its first live
// use, M4). The user: "start on the harmonic-systems report, forking bots where necessary to preserve prior
// algorithms": jazzvoicing_clodbot keeps its own; this fork adds one.
//
// Over a chord its rule package covers (the Harris sixth-diminished engineering fixture: not "the Barry Harris
// method", package-fixtures.js), it plays a scale of chords: the sixth chord of the chord's root, led from the voicing
// it last played, and at each comping hit after it a step of the eight-note scale, every voice to its neighbour, the
// sixth chord and its diminished seventh alternating (C6, B°7, C6: Harris's motion to the diminished and back). The
// generator plans the steps ahead, each plan a short run up or down toward a register it aims at (turning back before
// the ends of its voices' ranges, which it never leaves), and the validator checks them; the tuner tunes them from the
// package's role-based preferences: the sixth chord's just third, fifth and sixth, and the diminished chord's four
// equal minor thirds, its symmetry protected, each of its four 6:5 preferences tempered and logged as tempered.
//
// What the package covers is read from the package, not written here: a chord heard is in scope when every tone of it
// is a role of the package's start structure (the sixth chord: root, third, fifth, sixth) at that role's degree above
// the root, among them the roles that name its quality. So a major triad or sixth chord is in; a minor or diminished
// chord, a dominant or major seventh (whose sevenths the sixth chord has no role for), or an object no chord names is
// outside, and it comps as jazzvoicing_clodbot does and records that it did.
//
// In any meter, by one rule (meter-tactus.js feltBeats): each of a bar's felt beats struck, anticipated on the "and"
// before it, or left, the beats being whatever a listener feels at the tempo played (7/8 as 2+2+3 is three beats, the
// last longer; 4/4 very fast is felt in two). The rule was this bot's, where its parent's patterns were lists written for
// four beats that in any other meter struck about once a bar and left a scale of chords standing still; it is now the
// voice leader's comp (voice-leader.js compHits), every location's, and this bot comps by it with its own numbers
// (HARRIS_COMP). And it listens as it moves: a step that would go in octaves or fifths with a
// voice heard moving at the same moment (a walking bass) goes the other way, or holds.
import {defineBot} from '../../framework/index.js';
import {unitRandom} from '../../shared/stochastic.js';
import {parallelsAgainst} from '../../shared/voice-leading.js';
import {feltBeats} from '../../shared/meter-tactus.js';
import {JazzVoicingClodbot} from './jazzvoicing_clodbot.js';
import {COMP_TOUCH} from '../lib/voice-leader.js';
import {generate} from '../../shared/harmonic-systems/generator.js';
import {realize} from '../../shared/harmonic-systems/realization.js';
import {periodCents,degreeCents,structureOf,contextOf} from '../../shared/harmonic-systems/packages.js';
import {HARRIS_SIXTH_DIMINISHED} from '../../shared/harmonic-systems/package-fixtures.js';

// ---- Choices ---------------------------------------------------------------------------------------------------
const PACKAGE=HARRIS_SIXTH_DIMINISHED;
// Cents to a MIDI step: the bots' pitches are MIDI numbers (fractional between the keys), the package's cents.
const CENTS_PER_STEP=100;
// A plan that fails is logged with this many of the generator's explanations.
const EXPLANATIONS_LOGGED=3;
// The four voices' ranges (MIDI): the jazz voicer's own, raised over the bass it hears as the jazz voicer's are, so
// the two comp in one register and an A/B between them differs in harmony, not in height.
export const HARRIS_RANGES=Object.freeze([[48,62],[52,66],[55,70],[58,74]].map(range=>Object.freeze(range)));
// The tonic's octave, the frame the package's degrees are counted in (C3; any octave names the same pitches).
export const HARRIS_TONIC_OCTAVE_CENTS=4800;
// A chord heard is the package's when every tone of it lies within this of a role's degree above its root (a just or
// tempered third is the third; a neutral third, 50 cents from it, is not), and among its roles are these.
export const HARRIS_SCOPE=Object.freeze({toleranceCents:25,identity:Object.freeze(['root','third'])});
// Its comp, where it stands in the voice leaders' space: jazz's location with its own numbers set apart (the downbeat
// struck this often; each later felt beat struck on the beat or anticipated on the "and" before it, each the more often
// the busier the ensemble: at a density of one half, on the beat 42%, anticipated 30%, left 28%).
export const HARRIS_COMP=Object.freeze({downbeat:.85,onBeat:.35,anticipate:.25,busier:.42});
// How long a struck chord sounds, in the felt beat it is struck in, and how much softer than its voice-leading velocity
// a chord struck again is, on the "and" and on the beat: the voice leader's comping touch (voice-leader.js COMP_TOUCH);
// in the final bar as in any, its arrival its own length.

const mean=values=>values.reduce((a,b)=>a+b,0)/values.length;
const nominal=step=>step.voicing.filter(note=>Number.isFinite(note.cents)).map(note=>note.cents/CENTS_PER_STEP);
const tuned=step=>step.voicing.filter(note=>Number.isFinite(note.tunedCents)).map(note=>+(note.tunedCents/CENTS_PER_STEP).toFixed(4));
const pitchesOf=step=>Object.fromEntries(step.voicing.map(note=>[note.voice,note.cents]));
// The package's start structure (the sixth chord), its collection's mean step (an eighth of the octave for the eight-
// note scale: how far a step of the scale moves a voicing, on average), and the period.
const START=structureOf(PACKAGE,contextOf(PACKAGE,PACKAGE.start[0]).structures[0]);
const SCALE=PACKAGE.collections.find(collection=>collection.id===PACKAGE.transformations.find(item=>item.kind==='collection-translation')?.collection);
const PERIOD=periodCents(PACKAGE),STEP_CENTS=PERIOD/SCALE.degrees.length,START_CONTEXT=PACKAGE.start[0];

export class HarrisClodbot extends JazzVoicingClodbot {
  constructor(send,audio,settings={}){super(send,audio,{location:{jazz:1,...HARRIS_COMP},...settings});this.harris=null}
  // The felt beats of the bar now.
  felt(clock){return feltBeats(clock.meter,{secondsPerTick:this.secondsPerTick(clock)})}
  // Whether the package covers the chord heard: every tone a role of its start structure, the identifying roles among
  // them.
  inScope(chord){
    const heard=(chord.pitchClasses??[chord.root,chord.third,chord.fifth,chord.seventh]).filter(Number.isFinite);
    const roles=new Set;
    for(const pc of heard){
      const above=((CENTS_PER_STEP*(pc-chord.root))%PERIOD+PERIOD)%PERIOD;
      const role=START.roles.find(member=>{const d=((above-degreeCents(PACKAGE,member.degree))%PERIOD+PERIOD)%PERIOD;return Math.min(d,PERIOD-d)<=HARRIS_SCOPE.toleranceCents});
      if(!role)return false;
      roles.add(role.role);
    }
    return HARRIS_SCOPE.identity.every(role=>roles.has(role));
  }
  attack(clock,{change}){
    const chord=this.chord;
    if(!chord){super.attack(clock,{change});return}
    if(!this.inScope(chord)){
      if(change){this.harris=null;this.decide({tick:clock.tick,outside:PACKAGE.id,chord:`${chord.root}:${chord.quality}`,note:'outside the package\'s scope: comped as jazzvoicing_clodbot'})}
      super.attack(clock,{change});return;
    }
    if(change||!this.harris||this.harris.at>=this.harris.plan.length)this.harris=this.planScale(clock,chord,change);
    if(!this.harris){super.attack(clock,{change});return}
    const next=this.nextStep(clock,chord,change);
    if(!next){
      this.harris=null;this.decide({tick:clock.tick,change,note:'its scale\'s first chord moves in octaves or fifths with a voice heard: comped as jazzvoicing_clodbot, its scale planned again from it'});
      super.attack(clock,{change});return;
    }
    const {step,how}=next;
    if(how==='planned')this.harris.at++;
    else this.harris.at=this.harris.plan.length;      // turned or held: the rest of the plan is planned again from here
    this.harris.played=step;
    const pitches=tuned(step),spt=this.secondsPerTick(clock);
    const beat=this.felt(clock).find(item=>clock.tickInBar>=item.start&&clock.tickInBar<item.start+item.length),offbeat=clock.tickInBar!==beat.start;
    const seconds=(offbeat?COMP_TOUCH.offbeat:COMP_TOUCH.onBeat)*beat.length*spt;
    // (Written to its next strike in the comp, as jazzvoicing_clodbot's chords are; in the final bar, to the end.)
    const nextStrike=this.compAt(clock)?.hits.find(at=>at>clock.tickInBar)??null,span=(nextStrike??this.barTicks(clock))-clock.tickInBar;
    this.sound(clock,pitches,seconds,this.vl.velocity-(change?0:COMP_TOUCH.softer[offbeat?'offbeat':'onBeat']),this.writtenInterval(clock,span));this.announce(clock,pitches);
    this.voicing=nominal(step);
    this.decide({tick:clock.tick,change,package:`${PACKAGE.id}@${PACKAGE.version}`,context:step.context,structure:step.structure,via:step.via,how,
      pitches,roles:step.voicing.filter(note=>Number.isFinite(note.cents)).map(note=>note.role),aimCents:this.harris.aim,
      tempered:(step.tempered??[]).map(item=>({id:item.id,residualCents:+item.residualCents.toFixed(3)}))});
  }
  // The step the plan has next; or, where it would move in octaves or fifths with a voice heard moving now, a step of
  // the scale the other way from the chord sounding; or, where that would too, the chord sounding struck again. On a
  // change of chord, the new plan's first chord; or, where it would move in them from the chord sounding, a plan toward
  // the other side, where its first chord does not; or, where it does too, none (the chord comped as its parent comps
  // it, its voices led clear of them).
  nextStep(clock,chord,change){
    const planned=this.harris.plan[this.harris.at],played=this.harris.played,{othersFrom,othersTo}=this.others(clock);
    const movesWith=(from,step)=>Boolean(from)&&nominal(step).length===from.length&&parallelsAgainst(from,nominal(step),othersFrom,othersTo).length>0;
    if(change||!played){
      if(!movesWith(this.voicing,planned))return {step:planned,how:'planned'};
      const away=Math.sign(mean(this.voicing)-mean(nominal(planned)))||1,again=this.planScale(clock,chord,change,away);
      if(again&&!movesWith(this.voicing,again.plan[0])){this.harris=again;return {step:again.plan[0],how:'planned'}}
      return null;
    }
    const parallel=step=>movesWith(nominal(played),step);
    if(!parallel(planned))return {step:planned,how:'planned'};
    const away=Math.sign(mean(nominal(played))-mean(nominal(planned)))||1;
    const turned=this.stepFrom(clock,chord,played,away);
    if(turned&&!parallel(turned))return {step:turned,how:'turned'};
    return {step:played,how:'held'};
  }
  // The voices, in cents: its ranges raised over the bass heard.
  harrisVoices(clock){return this.overBass(clock,HARRIS_RANGES).map((range,index)=>({id:`v${index+1}`,range:range.map(value=>value*CENTS_PER_STEP)}))}
  // One step of the scale from a step played, toward a side (+1 up, -1 down), tuned; or null.
  stepFrom(clock,chord,from,side){
    const voices=this.harrisVoices(clock),tonicCents=HARRIS_TONIC_OCTAVE_CENTS+CENTS_PER_STEP*chord.root;
    const outcome=generate(PACKAGE,{start:{context:from.context,structure:from.structure,pitches:pitchesOf(from)},steps:[{via:'scale-step'}],voices,tonicCents,
      aim:{cents:CENTS_PER_STEP*mean(nominal(from))+side*PERIOD}});
    if(outcome.status!=='validated')return null;
    const result=realize(PACKAGE,outcome.plan);
    return result.status==='validated'?{...result.plan[1],tempered:result.tempered.filter(item=>item.id.startsWith('1:'))}:null;
  }
  // A plan from the sixth chord of the chord's root, led from the voicing sounding, as many scale steps ahead as the bar
  // has felt beats (the most hits a bar can have), toward an aim, tuned. On a change it starts again; otherwise it
  // continues from the step last played (and starts again, led from the chord sounding, when that continuation no
  // longer fits the ranges over the bass).
  planScale(clock,chord,change,side=null){
    const tonicCents=HARRIS_TONIC_OCTAVE_CENTS+CENTS_PER_STEP*chord.root,played=this.harris?.played;
    const voices=this.harrisVoices(clock),stepsAhead=Math.max(1,this.felt(clock).length);
    const after=this.voicing?.length===voices.length?Object.fromEntries(voices.map((voice,index)=>[voice.id,this.voicing[index]*CENTS_PER_STEP])):null;
    const aim=this.aimFor(voices,stepsAhead,side);
    const steps=Array.from({length:stepsAhead},()=>({via:'scale-step'}));
    let outcome=null,continued=false;
    if(!change&&played){outcome=generate(PACKAGE,{start:{context:played.context,structure:played.structure,pitches:pitchesOf(played)},steps,voices,tonicCents,aim:{cents:aim}});continued=outcome.status==='validated'}
    if(!continued)outcome=generate(PACKAGE,{start:{context:START_CONTEXT,...(after?{after}:{})},steps,voices,tonicCents,aim:{cents:aim}});
    if(outcome.status!=='validated'){this.decide({tick:clock.tick,harris:outcome.status,reason:outcome.reason??outcome.detail??null,explanations:outcome.explanations?.slice(0,EXPLANATIONS_LOGGED)});return null}
    const result=realize(PACKAGE,outcome.plan);
    if(result.status!=='validated'){this.decide({tick:clock.tick,harris:'untuned',tuning:result.status});return null}
    // Each step keeps what its tuning gave up (the realization's ids begin with the step's index).
    const plan=result.plan.map((step,index)=>({...step,tempered:result.tempered.filter(item=>item.id.startsWith(`${index}:`))}));
    // A continuing plan's first step is the chord already sounding: it is not struck again.
    return {plan:continued?plan.slice(1):plan,at:0,aim:Math.round(aim),played:played??null};
  }
  // Where the next run heads: the voicing's mean now (the register's middle before anything sounds), moved some steps of
  // the scale, up to the plan's length, up with the probability of the room left above it, and kept a step inside the
  // register the ranges allow (`side`: up +1 or down -1, where it is given).
  aimFor(voices,stepsAhead,side=null){
    const low=mean(voices.map(voice=>voice.range[0]))+STEP_CENTS,high=Math.max(low,mean(voices.map(voice=>voice.range[1]))-STEP_CENTS);
    const from=this.voicing?.length?mean(this.voicing)*CENTS_PER_STEP:(low+high)/2;
    // No room either way (a register a step wide): up and down alike.
    const room=high>low?Math.min(1,Math.max(0,(high-from)/(high-low))):1/2;
    const run=1+Math.min(stepsAhead-1,Math.floor(unitRandom()*stepsAhead));
    const aim=from+(side??(unitRandom()<room?1:-1))*run*STEP_CENTS;
    return Math.min(high,Math.max(low,aim));
  }
}

export const harrisClodbot=defineBot(
  {
    id:'harris_clodbot',name:'harris_clodbot',status:'native',source:'clodbot',forkOf:'jazzvoicing_clodbot',
    category:'harmony',midiChannel:13,performanceType:'polyphonic',outputModes:['synth','midi'],
    pitchContract:'floating-mpe',nativeTuning:true,
    description:'A fork of jazzvoicing_clodbot that comps a scale of chords over the chords its rule package covers: the sixth chord and its diminished seventh alternating a step of the eight-note scale apart, in runs up and down its register, struck on the felt beats of any meter, planned, validated and tuned by the harmonic-systems core (the sixth chord just, the diminished chord\'s symmetry kept; an engineering fixture, not the Barry Harris method as taught); anything else it comps as jazzvoicing_clodbot.',
  },
  (...args)=>new HarrisClodbot(...args),
);
