// seasonsbrokenchord_clodbot: a fork of ae_Seasons_BrokenChord that holds its chords in the transport's own beats (the mathematical audit's B04,
// ../lib/quarter-tempo.js). The port reads the transport's tempo as quarter notes; in 7/8 a chord lasts its written length, where
// the port's took half the time, and in 3/2 it no longer takes twice. The port's code is untouched: onTick is the port's
// own, given its clock with the tempo in quarter notes (it reads the tempo for nothing else). Made from the class it
// forks, which agents.js holds, by a function (no import cycle).
//
// And a plan of one chord is broken again each time the plan comes round (the audit's B06). The port sounds a chord when
// the plan's chord changes, so one chord sounded once and the plan's returns were silent. As for ae_DroneBOT's own
// renewal, it is one chord's plans that change: a chord is struck again when the plan begins again. The plan's place
// is the port's own arithmetic (bars and beats in quarter notes, or the form's progress), wrapped by the plan's length.
// As registered, its calls wait for the pulse they fall in (../lib/pulse-release.js; the audit's T01), so a tempo curve
// keeps its notes on the beat; its class here is the fork without that (the twin tests' subject).
import {defineBot} from '../../framework/index.js';
import {phrasePosition} from '../../shared/seasons.js';
import {quarterNoteClock} from '../lib/quarter-tempo.js';
import {releasedInPulse} from '../lib/pulse-release.js';
import {bandMeter} from '../../shared/opening-time.js';

// What the fork changes but its timing: one chord's renewal (B06).
export function seasonsbrokenchordCorrections(SeasonsBrokenChordBot){
  return class extends SeasonsBrokenChordBot {
    onTick(tick,clock){
      if(this.chords.length===1){
        const denominator=clock?.meter?.denominator||bandMeter().denominator,meterBeats=((clock?.meter?.numerator||bandMeter().numerator)*4)/denominator;
        const position=this.hasProgress?phrasePosition(this.progress,this.phraseBars,meterBeats):(clock?.bar||0)*meterBeats+((clock?.beat||0)*4)/denominator;
        const round=Math.floor(position/Math.max(1e-6,Number(this.durations[0])||1));
        // The plan begins again: its chord is a new chord, even the one it sounded the time before.
        if(round!==this.renewedRound){this.renewedRound=round;this.lastChord=null}
      }
      return super.onTick(tick,clock);
    }
  };
}
// The fork: those corrections, told the tempo in quarter notes (B04).
export function seasonsbrokenchordClodbotClass(SeasonsBrokenChordBot){
  return class SeasonsBrokenChordClodbot extends seasonsbrokenchordCorrections(SeasonsBrokenChordBot) {
    onTick(tick,clock){return super.onTick(tick,quarterNoteClock(clock))}
  };
}
export function defineSeasonsbrokenchordClodbot(SeasonsBrokenChordBot){
  const SeasonsBrokenChordClodbot=releasedInPulse(seasonsbrokenchordClodbotClass(SeasonsBrokenChordBot));
  return defineBot({
      id:'seasonsbrokenchord_clodbot',name:'seasonsbrokenchord_clodbot',status:'native',source:'clodbot',forkOf:'seasonsBrokenChord',category:'melody',midiChannel:14,outputModes:['synth', 'samples', 'midi'],sampleBank:'seasonsBrokenChord',pitchContract:'floating-mpe',
      description:"A fork of ae_Seasons_BrokenChord that holds its chords in the transport's own beats (the mathematical audit's B04): in 7/8 a chord lasts its written length, where the port's took half the time, and in 3/2 it no longer takes twice. And a plan of one chord is broken again each time the plan comes round, where the port's fell silent after it (B06). Under a tempo curve its notes stay on the beat: each waits for the pulse it falls in and is placed at that pulse's tempo (T01).",
    },(...args)=>new SeasonsBrokenChordClodbot(...args));
}
