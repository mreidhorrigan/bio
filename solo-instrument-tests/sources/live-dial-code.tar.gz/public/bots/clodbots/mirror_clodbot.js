// mirror_clodbot: a partner line by reflection (docs/PITCH_LANGUAGES.md, "Bots"; the alternative tonal systems report §5.4:
// reflection used "to create a partner melody", not as a one-button gimmick). It hears a melody -- the line a singer, a
// hindemith_clodbot or a riff announces, or a performer's notes (/broadcast/voices, role 'line' or 'performer') -- and
// answers each of its notes with the note's mirror about the harmony's axis, one felt beat later, in its own register: a
// canon by inversion, a partner and not an echo. Where the melody rises, it falls.
//
// The axis is halfway between the root it hears and that root's fifth (as the fifth is tuned, where the chord says; a
// fifth of 700 cents otherwise): over C the axis lies between E-flat and E, which trade places, as C and G do
// (pitch-languages/reflection.js). With no harmony heard, C. The mirror is exact in pitch class, microtones and all, and
// placed by the revoicing register policy: its class, by whole octaves nearest its own last note, inside its range.
// Each note says what it mirrors into notes.jsonl: the melody's voice, the note heard, the axis and the delay.
import {defineBot} from '../../framework/index.js';
import {VoiceLeadingBot} from '../lib/voice-leading-bot.js';
import {feltBeats} from '../../shared/meter-tactus.js';
import {strikeWith,languageOf} from '../lib/note-language.js';

// ---- Choices ---------------------------------------------------------------------------------------------------
// Its register (MIDI), the canon's distance in felt beats, how long each answer holds (a share of that distance), its
// loudness and its instrument: a wind, apart in timbre from a sung or keyboard melody.
export const MIRROR=Object.freeze({range:Object.freeze([52,76]),delayBeats:1,hold:.92,velocity:.5,gain:.06,family:'wind',
  // The melodic voices it answers.
  roles:Object.freeze(['line','performer'])});
const mod=(x,n)=>((x%n)+n)%n;

// The mirror of a pitch about the axis of a root and its fifth, placed nearest `near` by whole octaves, inside `range`.
export function mirrorPitch(heard,{root=0,fifth=null,near,range=MIRROR.range}){
  const axis=root+mod((fifth??root+7)-root,12)/2;
  let pitch=2*axis-heard;
  pitch+=12*Math.round((near-pitch)/12);
  while(pitch<range[0])pitch+=12;
  while(pitch>range[1])pitch-=12;
  return {pitch,axis:mod(axis,12)};
}

export class MirrorClodbot extends VoiceLeadingBot {
  constructor(send,audio,settings={}){super(send,audio,{style:'mirror',...settings});this.mirror={seen:new Map,last:null}}
  rearticulates(){return false}
  attack(){}
  noteLanguage(note){return languageOf(this.pendingLanguage,note)}
  // The melody's new notes since it last listened, each answered a felt beat after it was heard.
  everyTick(clock){
    if(this.closing?.phase==='after')return;
    const beats=feltBeats(clock.meter,{secondsPerTick:this.secondsPerTick(clock)});
    const beat=beats.find(item=>clock.tickInBar>=item.start&&clock.tickInBar<item.start+item.length)??beats[0];
    const delay=beat.length*MIRROR.delayBeats;
    for(const [key,entry] of this.heard.sources){
      if(!MIRROR.roles.includes(entry.role))continue;
      const seen=this.mirror.seen.get(key)??-Infinity;
      for(const event of entry.events){
        if(!(event.tick>seen)||!event.pitches.length)continue;
        this.mirror.seen.set(key,event.tick);
        this.pending.push({tick:Math.ceil(event.tick+delay),yields:false,run:at=>this.answer(at,key,event.pitches.at(-1),delay)});
      }
    }
  }
  answer(clock,voice,heard,delay){
    if(this.closing?.phase==='after')return;
    const chord=this.chord,range=MIRROR.range;
    const {pitch,axis}=mirrorPitch(heard,{root:chord?.root??this.bandOpening.root,fifth:chord?.fifth??null,near:this.mirror.last??(range[0]+range[1])/2,range});
    const seconds=Math.max(.12,delay*this.secondsPerTick(clock)*MIRROR.hold);
    const written=this.writtenInterval(clock,delay,{group:`mirror:${voice}`,replace:true});
    strikeWith(this,[{pitch,language:{reflection:{of:voice,heard:+heard.toFixed(4),axis:+axis.toFixed(4),delayTicks:delay}}}],
      ()=>this.playWritten(written,()=>this.audio.pitched(pitch,seconds,MIRROR.gain,'sine','wind',MIRROR.velocity,MIRROR.family)));
    // Announced as a partner, not a melody: another mirror does not answer it.
    this.announce(clock,[pitch],'partner');
    this.mirror.last=pitch;
    this.decide({tick:clock.tick,mirrors:voice,heard,pitch:+pitch.toFixed(4),axis:+axis.toFixed(4)});
  }
}

export const mirrorClodbot=defineBot(
  {
    id:'mirror_clodbot',name:'mirror_clodbot',status:'native',source:'clodbot',
    category:'melody',midiChannel:12,performanceType:'monophonic',outputModes:['synth','midi'],
    pitchContract:'floating-mpe',nativeTuning:true,
    // Silent until it hears a melody (test/agents.test.mjs leaves it out of the bare bar every other bot sounds in).
    requiresHeardVoices:true,
    description:'A partner line by reflection: it hears the melody a singer, a line bot or a performer plays and answers each note with its mirror about the harmony\'s axis (halfway between the root it hears and its fifth: over C, E and E-flat trade places), a felt beat later, in its own register: a canon by inversion, microtones kept.',
  },
  (...args)=>new MirrorClodbot(...args),
);
