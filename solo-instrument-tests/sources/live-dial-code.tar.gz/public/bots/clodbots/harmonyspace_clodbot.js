// harmonyspace_clodbot: a harmony source whose collection moves through the space of pitch collections
// (shared/collection-space.js). The user's stress test, 28 September 2026: "interpolate continuously between different
// harmonic/tuning/stylistic regimes"; and what interpolable means: "intermediate states exist between all the their
// possible states ... but in actual music, parameters can and should jump or have strong discontinuities sometimes".
// New, not a fork: no earlier bot offers the ensemble a collection as its harmony.
//
// It offers the ensemble's pool (/broadcast/notepool): its collection's pitches over the register from its tonic, the
// harmony every bot that hears pools plays in, a modal field rather than a progression. Where a phrase begins it may
// move: a jump to a collection drawn from anywhere in the space (moments of symmetry of any generator, the symmetric
// collections, the harmonic series, the hexany, a sieve, rast, Bohlen-Pierce's modes), or a state between the one it
// is in and one it draws, at a tenth drawn between them. Every state it reaches is a collection, so it chooses and never
// refuses. It begins in the piece's opening, its tonic and collection drawn from the seed.
import {defineBot} from '../../framework/index.js';
import {Agent} from '../../framework/agent.js';
import {unitRandom} from '../../shared/stochastic.js';
import {drawCollection,interpolateCollection,collectionPitches} from '../../shared/collection-space.js';

export const HARMONYSPACE=Object.freeze({moves:.6,between:.5,tenths:9,register:Object.freeze([43,84])});

export class HarmonySpaceClodbot extends Agent{
  constructor(send,audio,settings={}){
    super(send,audio);
    this.settings={moves:HARMONYSPACE.moves,between:HARMONYSPACE.between,...settings};
    this.collection=null;this.tonic=null;this.movedAtPhrase=null;this.collections=[];
  }
  // Its collection now, and the pool it makes: at the start the band's opening (shared/opening-harmony.js: drawn from
  // the piece's seed, the harmony every bot of the piece began from), moved where phrases begin.
  begin(){
    const {tonic,collection}=this.bandOpening;
    this.tonic=tonic;this.collection={...collection,system:[...collection.system]};this.remember(null,'start',null);
  }
  move(clock){
    const phrase=clock.phrase??0;if(this.movedAtPhrase===phrase)return false;this.movedAtPhrase=phrase;
    if(phrase===0||!(unitRandom()<this.settings.moves))return false;
    const target=drawCollection(unitRandom);
    if(unitRandom()<this.settings.between){
      const t=(1+Math.floor(unitRandom()*HARMONYSPACE.tenths))/(HARMONYSPACE.tenths+1);
      this.collection=interpolateCollection(this.collection,target,t);this.remember(clock,'between',t);
    }else{this.collection=target;this.remember(clock,'jump',null)}
    return true;
  }
  remember(clock,kind,t){
    const entry={tick:clock?.tick??0,phrase:clock?.phrase??0,move:kind,...(t!=null?{t}:{}),collection:this.collection.label,
      classes:this.collection.system.map(pc=>+pc.toFixed(3)),period:+this.collection.period.toFixed(4),tonic:this.tonic};
    this.collections.push(entry);if(this.collections.length>64)this.collections.shift();
    this.audio?.report?.('harmonyspace',entry);
  }
  offer(){
    const [low,high]=HARMONYSPACE.register;
    this.broadcast('notepool',collectionPitches(this.collection,{tonic:this.tonic,low,high}));
  }
  onTick(tick,clock){
    if(!this.collection){this.begin();this.offer();return}
    if(clock?.phraseStart&&this.move(clock))this.offer();
    // (Offered again where a phrase begins, for bots that joined since.)
    else if(clock?.phraseStart)this.offer();
  }
}

export const harmonyspaceClodbot=defineBot(
  {
    id:'harmonyspace_clodbot',name:'harmonyspace_clodbot',status:'native',source:'clodbot',
    category:'conductor',outputModes:[],pitchContract:'none',planningCapabilities:{harmony:true},
    specSettings:Object.freeze(['moves','between']),
    description:'A harmony source whose collection moves through the space of pitch collections: it offers the ensemble its collection\'s pitches as the pool, and where a phrase begins it jumps to one drawn from anywhere (moments of symmetry of any generator, the symmetric collections, the harmonic series, the hexany, a sieve, rast, Bohlen-Pierce\'s modes) or takes a state between the one it is in and one it draws, every state between existing.',
  },
  (...args)=>new HarmonySpaceClodbot(...args),
);
