// shaker_clodbot: a shaker player. Its hand swings back and forth without stopping, each reversal a stroke (the family
// atlas's F35, research/family-atlas.md: a continuous gesture, not a stroke commanded per grain), on the finest
// subdivision it can shake at the tempo, its level swelling toward the meter's strong points and the down stroke
// heavier than the up (shared/performers/shaker.js).
//
// Its instrument is the nearest of three, as their recordings measure, to the attack and brightness the band's
// character asks: the shaker's soft grain, the tambourine's jingles, the cabasa's bright beads. It keeps its
// instrument until a phrase begins, and ends on the last bar's downbeat with the band.
import {defineBot} from '../../framework/index.js';
import {Agent} from '../../framework/agent.js';
import {Closure} from '../lib/modules/closure.js';
import {PerformedTiming} from '../lib/modules/performed-timing.js';
import {GroupingChoice} from '../lib/modules/grouping-choice.js';
import {metricStrength} from '../../shared/rhythm-spaces.js';
import {onsetsPayload} from '../../shared/sounding-voices.js';
import {secondsPerTick} from '../../shared/meter-tactus.js';
import {strokeDirection,strokeLevel,strokeStride} from '../../shared/performers/shaker.js';
import {instrumentsInKit} from '../../shared/performers/kit-instruments.js';
import {bandPhraseBars} from '../../shared/opening-time.js';
import {scoreTime,withScoreTime} from '../../shared/score-time.js';

export const SHAKER_CLODBOT=Object.freeze({
  // The instruments, as the sampled drum kit (the Virtuosity kit, synths/drum-kit.js) plays them: each direction's
  // General MIDI note (the shaker's down and up strokes are recorded apart), and the recordings' attack (10% to 90% of
  // the peak envelope, ms) and brightness (the spectral centroid over the first 50 ms, Hz), each the median over the
  // first take of every dynamic layer (the shaker's over both directions), measured again by
  // test/audio/shaker-clodbot.test.mjs.
  instruments:Object.freeze({
    shaker:Object.freeze({down:70,up:82,attackMs:97.1,brightnessHz:6617}),
    tambourine:Object.freeze({down:54,up:54,attackMs:22.3,brightnessHz:7541}),
    cabasa:Object.freeze({down:69,up:69,attackMs:36.3,brightnessHz:10093}),
  }),
});

const clamp=(value,low,high)=>Math.max(low,Math.min(high,value));
// The instruments its kit has recordings of both strokes for (kit-instruments.js; audio.js sampledKit).
export const shakerInstruments=kit=>instrumentsInKit(SHAKER_CLODBOT.instruments,kit,instrument=>[instrument.down,instrument.up]);

// The instrument nearest a character's attack and brightness: its attack across the instruments' (the sharpest at 1),
// its darkness across their brightness (the darkest at 1), each in log units spanning the instruments' own range; the
// earlier on a tie; null where there is none. `instrument` names one outright.
export function shakerInstrument(character,{instrument='auto',instruments=SHAKER_CLODBOT.instruments}={}){
  if(instrument&&instrument!=='auto'&&instruments[instrument])return instrument;
  const entries=Object.entries(instruments),log=Math.log;
  const attacks=entries.map(([,one])=>-log(one.attackMs)),brights=entries.map(([,one])=>log(one.brightnessHz));
  const span=(values,value)=>{const low=Math.min(...values),high=Math.max(...values);return high>low?(value-low)/(high-low):0};
  const attack=clamp(character?.attack??.5,0,1),bright=1-clamp(character?.darkness??.5,0,1);
  let best=null,nearest=Infinity;
  for(const [index,[name]] of entries.entries()){
    const distance=Math.hypot(span(attacks,attacks[index])-attack,span(brights,brights[index])-bright);
    if(distance<nearest-1e-12){nearest=distance;best=name}
  }
  return best;
}

export class ShakerClodbot extends Closure(Agent) {
  constructor(send,audio,settings={}){
    super(send,audio);
    this.settings={velocity:.55,instrument:'auto',...settings};
    this.strokes=0;this.instrument=null;this.decisions=[];
  }
  stroke(clock,strength,ticks){
    const instrument=SHAKER_CLODBOT.instruments[this.instrument];if(!instrument)return;
    const direction=strokeDirection(this.strokes++);
    const level=strokeLevel(this.settings.velocity,strength,direction);
    withScoreTime(this.audio,scoreTime(clock.tick,ticks),()=>this.audio.drum?.('perc',level,{note:instrument[direction]}));
    this.broadcast('onsets',[onsetsPayload({voice:this.instanceId??'shaker_clodbot',role:'drums',onsets:[{tick:clock.tick,strength:level,kind:'perc'}]})]);
  }
  onTick(tick,clock){
    if(!clock?.meter)return;
    const closing=this.closingAt(clock);
    if(closing.phase==='after')return;
    const meter=clock.meter,bar=metricStrength(meter),phraseBars=meter.phraseBars||bandPhraseBars();
    // Its instrument chosen where a phrase begins (the band's character heard there), of those its kit has; with none,
    // it plays nothing and says so. Its rate on every bar.
    if(clock.tickInBar===0&&(!this.instrument||clock.bar%phraseBars===0)){
      const instrument=shakerInstrument(this.character,{instrument:this.settings.instrument,instruments:shakerInstruments(this.audio?.sampledKit?.())});
      if(instrument!==this.instrument||!this.decisions.length){this.instrument=instrument;this.decisions.push({bar:clock.bar,instrument,...(instrument?{}:{silent:'its kit has none of its instruments'})});if(this.decisions.length>128)this.decisions.shift()}
    }
    // Its ending (Closure): one down stroke on the last bar's downbeat, with the band, then nothing.
    if(closing.phase==='final'){
      if(clock.tickInBar===0){this.strokes=0;this.stroke(clock,1,closing.ticksLeft)}
      return;
    }
    const stride=strokeStride(secondsPerTick(clock),Math.max(1,meter.subdivision||1));
    if(stride===null||clock.tickInBar%stride!==0)return;
    this.stroke(clock,bar[clock.tickInBar]??0,Math.min(stride,meter.pulsesPerBar-clock.tickInBar));
  }
}

// Under a home (meterform_clodbot), it hears the home bars in a grouping of its own (bots/lib/modules/grouping-choice.js).
// Played in the ensemble's feel, where one is set (the performance layer: docs/PERFORMANCE_TIMING.md).
const GroupedShaker=PerformedTiming(GroupingChoice(ShakerClodbot,{role:'drums'}));
export const shakerClodbot=defineBot(
  {
    id:"shaker_clodbot",name:"shaker_clodbot",status:"native",source:"clodbot",
    category:"beat",midiChannel:10,outputModes:["synth","midi"],pitchContract:"fixed-percussion",
    description:
      "A shaker player whose hand swings back and forth without stopping, each reversal a stroke on the finest subdivision it can shake at the tempo, swelling toward the meter's strong points, the down stroke heavier than the up; its instrument the shaker, the tambourine or the cabasa, whichever's attack and brightness the band's character asks.",
  },
  (...args)=>new GroupedShaker(...args),
);
