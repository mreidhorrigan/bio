// atmosphere_clodbot: a fork of ae_AtmosphereBOT that times its resonances in the transport's own beats (the mathematical audit's B04,
// ../lib/quarter-tempo.js). The port reads the transport's tempo as quarter notes; in 7/8 a resonance lasts its bars, where
// the port's took half the time, and in 3/2 it no longer takes twice. The port's code is untouched: onTick is the port's
// own, given its clock with the tempo in quarter notes (it reads the tempo for nothing else). In a meter of quarters it
// plays exactly as ae_AtmosphereBOT. Made from the class it forks, which agents.js holds, by a function (no import cycle).
import {defineBot} from '../../framework/index.js';
import {quarterNoteClock} from '../lib/quarter-tempo.js';

export function atmosphereClodbotClass(AtmosphereBot){
  return class AtmosphereClodbot extends AtmosphereBot {
    onTick(tick,clock){return super.onTick(tick,quarterNoteClock(clock))}
  };
}
export function defineAtmosphereClodbot(AtmosphereBot){
  const AtmosphereClodbot=atmosphereClodbotClass(AtmosphereBot);
  return defineBot({
      id:'atmosphere_clodbot',name:'atmosphere_clodbot',status:'native',source:'clodbot',forkOf:'atmosphere',category:'texture-noise',midiChannel:15,outputModes:['synth', 'midi'],pitchContract:'floating-mpe',
      description:"A fork of ae_AtmosphereBOT that times its resonances in the transport's own beats (the mathematical audit's B04): in 7/8 a resonance lasts its bars, where the port's took half the time, and in 3/2 it no longer takes twice. In a meter of quarters it plays exactly as ae_AtmosphereBOT.",
    },(...args)=>new AtmosphereClodbot(...args));
}
