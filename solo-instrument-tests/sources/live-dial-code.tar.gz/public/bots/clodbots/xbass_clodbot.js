// xbass_clodbot: a fork of ae_xBassBOT that plays every step of its pattern once a bar, in every meter (the mathematical
// audit's B06; the user, 27 September 2026: "fix in forked form"). Made from the class it forks, which agents.js holds,
// by a function, so this file imports nothing from agents.js; ae_xBassBOT itself is unchanged.
//
// ae_xBassBOT's pattern is on its own grid of sixteen steps, and each host tick asks which step it falls on. Two things
// follow, and neither is the pattern:
//   - it remembers the last step it *played* as the event it has done, so a pattern of one step, [0], sounds in the
//     first bar and never again (every later bar's step 0 equals the step it last played);
//   - where the meter's grid is coarser than sixteen (7/8 counted in eighths has fourteen ticks), some steps are never
//     landed on, and those onsets are lost; where it is finer, a step is landed on twice.
// Here each step of the pattern belongs to the tick its time falls in, floor(step * ticks / steps), so every step is
// heard once a bar, whatever the grid. Steps that share a tick (a coarse grid) are one attack there: a bass plays one
// note at a time. Its pattern, its pitches, its velocity walk and its note lengths are the port's.
import {defineBot} from '../../framework/index.js';
import {boundedDrunk} from '../../shared/stochastic.js';
import {bandTempo,bandMeter} from '../../shared/opening-time.js';
import {scoreTime,withScoreTime} from '../../shared/score-time.js';
import {authoredFraction} from '../../shared/performers/rhythm-cell.js';

// The pattern's steps that fall in a bar's tick: those whose time, step / steps of the bar, lies in the tick's.
export function stepsInTick(pattern,tickInBar,ticksPerBar,steps){
  const ticks=Math.max(1,Math.trunc(ticksPerBar));
  return pattern.filter(step=>Math.floor(step*ticks/steps)===tickInBar);
}

export function xbassClodbotClass(XBassBot){
  class XBassClodbot extends XBassBot {
    onTick(tick,clock){
      if(!this.enabled||this.exiting)return;
      if(!stepsInTick(this.pattern,clock.tickInBar||0,clock.meter?.pulsesPerBar||bandMeter().pulsesPerBar,this.config.sourceSteps).length)return;
      this.velocityState=boundedDrunk(this.velocityState,this.config.velocityWalk.range,this.config.velocityWalk.step);
      const [low,high]=this.config.velocityWalk.output,
        velocity=low+(this.velocityState/(this.config.velocityWalk.range-1))*(high-low),
        duration=(this.config.noteDurationBeats*60)/(clock.bpm||bandTempo());
      const written=scoreTime(clock.tick,authoredFraction(this.config.noteDurationBeats).mul(clock.meter.subdivision));
      withScoreTime(this.audio,written,()=>this.audio.bass(this.choosePitch(),velocity,duration));
    }
  }
  return XBassClodbot;
}
export function defineXbassClodbot(XBassBot){
  const XBassClodbot=xbassClodbotClass(XBassBot);
  return defineBot({
      id:'xbass_clodbot',name:'xbass_clodbot',status:'native',source:'clodbot',forkOf:'xBass',
      category:'bass',midiChannel:3,outputModes:['synth','samples','midi'],sampleBank:'xBass',pitchContract:'floating-mpe',
      description:
        'A fork of ae_xBassBOT that plays every step of its tala pattern once a bar in every meter: each step at the tick its time falls in, steps sharing a coarse tick as one attack; its pattern, pitches and velocity walk are the port\'s.',
    },(...args)=>new XBassClodbot(...args));
}
