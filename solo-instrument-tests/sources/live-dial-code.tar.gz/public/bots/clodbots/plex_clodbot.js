// plex_clodbot: the conductorbot (Musebots 3.0, docs/MUSEBOTS_3.md), a fork of mh_PlexBOT. The owner, 30 September 2026:
// "the things that are currently called 'conductors' will be split between managebots (that handle the networking) and
// conductorbots (that handle tempo, et cetera, and can be nested as mentioned). How the bots currently negotiate form can
// also ... be extended over the length of an entire piece so that, if no other stimulus intervenes, the bots will simply
// decide on a plan and play it"; "we want support for planning every step of the way between phrase-ahead and
// whole-piece-ahead."
//
// mh_PlexBOT draws a form (an archetype's roles, each section's meter, grouping, phrase length, tempo and density) and
// announces each section a phrase before it, looping when the form runs out. This fork draws its sections exactly as
// mh_PlexBOT does (its generateSection, its grammar), and:
// - **plans as far ahead as its horizon** (settings.horizon, shared/conducting/horizon.js): 'phrase' decides each
//   section a phrase before it, as mh_PlexBOT does; 'piece' (the default) decides them all before the first bar; any
//   count of bars, phrases, sections or seconds, or a reach from 0 (a phrase) to 1 (the piece), decides that far ahead.
//   The archetype's roles are its sketch; a section is drawn, and committed, when it comes within the horizon. Each
//   committed section is said at once as the rhythm plan mh_PlexBOT sends for it (applying at its bar), and the whole
//   plan as a 'piece' plan (shared/conducting/piece-plan.js), so the band knows as far ahead as it is decided;
// - **plays its plan through and ends**: the meter, tempo and density go to the transport a bar before each section
//   (exact bars: a section is its phrases' bars), a ritardando into the last bar, and a commitment to stop at the plan's
//   end, a phrase before it. A render of a fixed length gets a form that fits it, the sketch's last role at its end,
//   its length shared between the sketch's sections as they were drawn; a live room gets the whole archetype. Each
//   section's draws, and each layer's, are its own (keyed to what they decide, from its seed), so that it plans the
//   same piece however far ahead it plans it;
// - **is changed only by a stimulus** (piece-plan.js classifyStimulus): the parts' answers to a section's meter (as
//   mh_PlexBOT meets them: a majority keeping their own meter or grouping, met in the section after); a performer heard
//   (a listening bot standing for a person), after which it plans a phrase ahead (settings.performerHorizon), deciding
//   as it goes with the person; a form adjusted or a grammar handed in; another's committed ending, which it adopts.
//   Whatever has been handed to the transport stays;
// - **prepares contingencies** with each section it commits (settings.contingencies; shared/conducting/contingencies.js):
//   what it will do instead if the people it plays with (their profiles: profile_clodbot) turn out otherwise than it
//   planned -- their tempo followed where they play in another, the band lighter while they play busily, the space taken
//   when they fall silent, no new meter under a cadenza -- each guarded over the profiles in the overplan guard
//   language, said in its plan, and chosen at the section's hand-over as the profiles stand then (unknown, or no
//   profile, keeps the plan). A person gone (every profile stopped a phrase, or not heard past its grace) returns it to
//   its own horizon, and their return is a performer heard again;
// - **plans canons**, where a spec names two or more parts that play a part as written (settings.canon; bots/lib/modules/
//   part-plans.js): where the form develops, a canon in the section's meter, its subject from the harmony heard a phrase
//   before it -- a layer planned at its own horizon, a phrase, within the piece's (shared/conducting/canon-plan.js);
// - **conducts a group, and nests** (shared/conducting/groups.js): it announces its group (settings.group, 'ensemble'
//   unless a spec says) on /broadcast/group, and says for each section the constraints on what the groups below it
//   choose (their level, and how far they divide: a string section's split), which flow down through every level below.
//   With a parent (settings.parent), it is a subconductor: it follows its parent's piece plan section by section (the
//   parent holds the tempo, meter and form), and passes on the parent's constraints narrowed by its own choices;
// - **leads a section, given its kind's specification** (settings.section: {kind, ...}; shared/conducting/
//   section-kinds.js; the owner, 1 October 2026: "one conductorbot type, to the extent possible, that then receives
//   different sets of per-section-type constraint as a kind of specification"): its group the section's (strings:<size>,
//   unless settings.group says), and with each section of the form, a phrase before it, the formation of every phrase
//   in it, drawn from the kind's specification within the constraints from above and its own, said compactly on
//   /broadcast/group/formation for the section's players (each seat a bot of its own: bots/lib/modules/section-seat.js),
//   and said again each phrase for whoever joins late;
// - **keeps time across a network** (the owner, 30 September 2026: "make sure integration with the various latency- and
//   interruption-handling algorithms across networks is not lost"): each section's meter and tempo handed over as far
//   ahead as a networked room needs to agree them (PLEX_CLODBOT.handoverSeconds), named for its bar ('bar:<n>',
//   shared/change-timing.js), and asked again once where it is not in force in its first bar; hand-overs, cues and the
//   ritardando taken in ranges of bars, so that skipped ticks lose none; each section's own words (its rhythm plan, its
//   constraints, its canon's parts) said again each phrase for whoever joins late; and, where several conductors share a
//   group (one on each host, or a standby), one conducts (shared/conducting/election.js: the first to have conducted,
//   then the lowest id) and the others stand by, keeping its plan, so that if it is not heard for a few bars (its host
//   dropped) the next takes over from its plan, where it was, its stop kept.
import {Rational} from '../../transcript/rational.js';
import {hearInsistence,insistOnFormation} from '../../shared/motif-insistence.js';
import {storedLine} from '../../shared/motifs.js';
import {Agent,defineBot} from '../../framework/index.js';
import {PlexBot} from '../families/planning.js';
import {STOCHASTIC_CONFIG as CONFIG} from '../../stochastic-config.js';
import {weightedChoice,unitRandom} from '../../shared/stochastic.js';
import {defaultGrammar as defaultPlexGrammar,plexGrammar} from '../../shared/plex-grammar.js';
import {formProgress} from '../../shared/form-development.js';
import {checkedHorizon,describeHorizon,affordablePlanning} from '../../shared/conducting/horizon.js';
import PLANNING_COST from '../../shared/conducting/planning-cost.json' with {type:'json'};
import {PiecePlanner,classifyStimulus} from '../../shared/conducting/piece-plan.js';
import {GroupTree,GROUP_ADDRESS} from '../../shared/conducting/groups.js';
import {checkedConstraints,narrowConstraints,chooseWithin} from '../../shared/conducting/constraints.js';
import {canonParts,subjectFrom,plannedSubject,stepInCollection} from '../../shared/conducting/canon-plan.js';
import {roundCycles} from '../../shared/conducting/round-plan.js';
import {drawnRules,blendRules,ladderOf,perfectDegrees} from '../../shared/conducting/counterpoint.js';
import {Profiles,BUSY,checkedContingency,chooseContingencies,applyContingencies} from '../../shared/conducting/contingencies.js';
import {arrangementDensity,arrangementClosingPhrase} from '../../shared/conducting/arrangement.js';
import {PROFILE_ADDRESS} from './profile_clodbot.js';
import {secondsPerTick,feltBeats} from '../../shared/meter-tactus.js';
import {FELT_TEMPO} from '../../shared/felt-tempo.js';
import {sectionHarmony,chordAt,HARMONY_PLAN} from '../../shared/conducting/harmony-plan.js';
import {REQUEST_ADDRESS,restAsks,grantRests,breadthRests,mergeRests,soloAsks,grantSolos} from '../../shared/conducting/requests.js';
import {groupMeters} from '../../shared/conducting/group-meters.js';
import {FUGUE,fugueExposition,entryInPhrase} from '../../shared/conducting/fugue-plan.js';
import {orchestrate,voicesAt,doubled,returnOrchestration,FUGUE_VOICES} from '../../shared/conducting/orchestration.js';
import {inspiredFigure,figurePayload,oneToneFigure} from '../../shared/performers/figuration.js';
import {collectionPitches} from '../../shared/collection-space.js';
import {applyTuningSystem} from '../../shared/tuning.js';
import {atBar,METER_NOTICE_SECONDS} from '../../shared/change-timing.js';
import {RUBATO_PLAN} from '../../shared/rubato-plan.js';
import {returningRise,SentClock,sentBpm} from '../../shared/conducting/returned-rubato.js';
import {soloShares,sharedHistory} from '../../shared/conducting/solo-shares.js';
import {GestureCommitments} from '../../shared/conducting/gesture-commitment.js';
import {clearedTogether} from '../../shared/conducting/solo-clearing.js';
import {viableHold} from '../../shared/conducting/coordinated-events.js';
import {Election} from '../../shared/conducting/election.js';
import {sectionOf} from '../../shared/conducting/section-kinds.js';
import {compactFormation,expandFormation,seededSource,playingCompass} from '../../shared/performers/string-section.js';
import {repetitionOf} from '../../shared/repetition.js';
import {breathHolds,givenShift} from '../../shared/performers/section-voices.js';
import {elongationCandidates} from '../../shared/conducting/exact-elongation.js';
import {fugueCadence,cadenceBudget} from '../../shared/conducting/fugue-cadence.js';
// (A range's middle; no range, all: a constraint's players.)
const middle=range=>Array.isArray(range)&&range.length===2?(Number(range[0])+Number(range[1]))/2:1;
// Durations (whole felt beats) fitted to `total`, each its share, at least one, the remainders in order.
const fitted=(durations,total)=>{const sum=durations.reduce((a,b)=>a+b,0),out=durations.map(d=>Math.max(1,Math.floor(d*total/sum)));
  for(let k=0;out.reduce((a,b)=>a+b,0)<total;k=(k+1)%out.length)out[k]++;
  for(let k=out.length-1;out.reduce((a,b)=>a+b,0)>total&&k>=0;k--)while(out[k]>1&&out.reduce((a,b)=>a+b,0)>total)out[k]--;
  return out.slice(0,Math.max(1,out.findLastIndex(d=>d>0)+1))};
import {bandPhraseBars,bandMeter,bandTempo} from '../../shared/opening-time.js';
import {SongWatch,songEndingAt} from '../../shared/song-ending.js';
import {hashSeed} from '../../random-source.js';
import {checkedPlanDocument,overlaySection,PLAN_DOCUMENT} from '../../shared/conducting/plan-document.js';

// ---- Choices (ours) -------------------------------------------------------------------------------------------------
// The roles that restore the opening's frame (mh_PlexBOT's: planning.js generateSection reads its home for them).
const RETURN_ROLES=Object.freeze(['return','complex-return']);
// A sketch's roles kept in `count` phrases: its first and its last, and those between spread evenly over it (their
// order kept). -> roles.
export function spreadRoles(roles,count){
  if(count>=roles.length)return [...roles];if(count<=1)return [roles.at(-1)];
  return Array.from({length:count},(_,k)=>roles[Math.round(k*(roles.length-1)/(count-1))]);
}
// A section's meter as its formations say it: the stream its seats count (its relation beside it, where it has one).
const streamOfMeter=({relation,...meter},from)=>({meter,id:`${meter.numerator}/${meter.denominator}${relation?` at ${relation.ratio.join(':')}`:''}`,from,...(relation?{relation}:{})});
export const PLEX_CLODBOT=Object.freeze({
  // The parameters every group below may be constrained in: its level, 0 to 1, and how far it divides (a string
  // section's split: tutti to a part a player). A group that has neither is not bound by them.
  vocabulary:Object.freeze({level:Object.freeze({low:0,high:1}),split:Object.freeze({low:0,high:1}),players:Object.freeze({low:0,high:1})}),
  // A section's constraints from its density d (mh_PlexBOT's hdensity, 0.2 to 0.85, the role's complexity): the level
  // where d lies in that range, pp at its least to ff at its most, give or take .15 (the owner, 1 October 2026, of
  // Op. 3.5: "it's all quite loud. Determine whether the dynamics are artificially narrow": they were, a level of .25 +
  // .5 d, mp to f, never pp, p or ff); the split from 1.2 d - .5 to 1.2 d (tutti where it is simple, a part a player
  // where it is most intense). And a piece's dynamics planned across the whole range, as a composer plans them: `arc` of
  // the level is where d lies among the piece's own densities (its sections decided and its sketch's roles to come), its
  // quietest section at pp and its loudest at ff, the rest where d lies in the absolute range (the owner, 2 October
  // 2026: "orchestras in reality are known to have huge dynamic ranges, which is a problem to solve at mixing but at
  // composition it's not considered a problem to mitigate"; Op. 3.8's form, all in the middle, stayed between p and mf).
  // A piece whose densities lie within `flat` of each other is placed by the absolute range alone.
  level:Object.freeze({least:.2,most:.85,spread:.15,arc:.6,flat:.1}),split:Object.freeze({scale:1.2,width:.5}),
  // And how many of its players play (the owner, 2 October 2026: "make sure orchestras can render a full variety of
  // textures, from using one instrument to using all and everything between"): a share, 0 one player to 1 all of them
  // (string-section.js playersOf), its middle `own` of a draw of the section's own (the ensemble's seed and the section's
  // index) and the rest where its density lies among the piece's (as its level's arc), give or take `spread`. The
  // orchestra's conductor rests whole sections by it too (breadthRests): of m sections, m to the share play a phrase, the
  // louder families (`loudness`, by a section's kind: ours, after orchestration's practice of keeping the brass and the
  // percussion for the loud passages) resting first where the music is quiet.
  players:Object.freeze({own:.5,spread:.15,loudness:Object.freeze({strings:0,winds:.3,brass:1,percussion:.8})}),
  // The piece's texture, as the breadths over its form are chosen: each requirement {voices, time}, at least `voices` of
  // a section's players (its breadth's least) for at least `time` of the piece's bars (the owner, 18 October 2026, after
  // a live quintet's opening of one player at a time: "constraints on texture, such as 'at least 70% of the time, 60% of
  // available voices need to play'"; their example, a spec's `texture` its own, [] none).
  texture:Object.freeze([Object.freeze({voices:.6,time:.7})]),
  // A subconductor's own choice within what it is given: a range this much of the given's width, placed at a draw.
  narrowing:.5,
  // The ritardando into the last bar: to this share of the tempo, over the last two bars (as form_clodbot asks).
  ritardando:.82,
  // A conductor's rubato (the owner, 2 October 2026: "We need orchestral rubato"): each phrase's tempo an arch, on to its
  // peak and lengthened into its end (Todd 1992, doi:10.1121/1.402843; Repp 1992, doi:10.1121/1.404425; the lengthening
  // a stopping runner's, Friberg and Sundberg 1999, doi:10.1121/1.426687): its depth a share of the section's tempo,
  // drawn with each section of the form (the square of a uniform draw over `depth`: most sections a little, some much),
  // less as the ensemble's character is mechanical or steady (a pulse kept, a groove's: aesthetic.js); its peak's place
  // in the phrase drawn within `peak`, the rise to it `rise` of the depth. Each phrase's curves sent as it comes within
  // the lead, as a section's tempo is; none while a section's own tempo curve moves it to its tempo (its first
  // phrase, mostly), or in the piece's last phrase (its ritardando). The orchestra follows its conductor, its percussion
  // with it; a conductor whose ritardando is turned off (settings.ritardando false) keeps its tempo. Where a drummer keeps
  // the time (heard on the band's onsets, not seated in a section of it), the clocks keep only a share of each arch
  // (`keep`, drawn with each section of the form, smaller as the character is mechanical: the drums' share of the rubato
  // a parameter of style), and the melodic parts take the rest over them (/broadcast/partRubato, as ManageBOT says it;
  // its depth on rubato-plan.js's scale): the owner's "drums keep time: under rubato they breathe only slightly, while
  // melodic parts take their own rubato over them". A drummer keeps time where it struck as many times as bars in the
  // last `heard` phrases (a gong's strokes at the form's joins keep none). Ours: the ranges.
  rubato:Object.freeze({depth:Object.freeze([.012,.12]),phrase:Object.freeze([.5,1.5]),peak:Object.freeze([.4,.7]),rise:.5,keep:Object.freeze([.15,.5]),heard:2}),
  // How far a performer's own time may stray from its conductor's (s), set with each formation it hands its players
  // (formation.ownTime; settings.ownTime as it is told, its parent's where narrower): an intense rubato is the whole
  // arrangement's, on its clock, never a part's apart from the others (the owner, 5 October 2026, of Op. 3.29: "An
  // orchestra cannot have per-part rubato work that way; rather, rubato that intense can only happen over the entire
  // arrangement"; "The tolerable amount of rubato must be set per-conductor and per-performer based on their situation,
  // with constraints flowing from conductor to performers"). A part leans no further from the others than a melody leads
  // them -- Palmer, C. (1996), "On the assignment of structure in music performance", Music Perception 14(1), 23-56,
  // doi:10.2307/40285708: 20 to 50 ms -- for an ensemble's players correct each beat a share of how far each is from the
  // others (Wing, A. M., Endo, S., Bradbury, A., & Vorberg, D. (2014), "Optimal feedback correction in string quartet
  // synchronization", J. R. Soc. Interface 11(93), 20131125, doi:10.1098/rsif.2013.1125: about a fifth to each partner,
  // mean asynchronies to the first violin of 3 to 12 ms). Ours: the more players it conducts, the nearer the least, from
  // `few` players' `most` to `many` players' `least`, geometrically between.
  ownTime:Object.freeze({most:.05,least:.02,few:2,many:32}),
  // Following a performer whose bar it hears (profile_clodbot's meter), the band counts its bars as theirs once it has
  // heard the same bar this many times running (ours: a profile is said each felt group, so a few seconds).
  followMeter:Object.freeze({steady:3}),
  // A section's solo, granted it on its ask (requests.js grantSolos): its soloist's level `raise` above its pool's, its
  // rubato up to `rubato` of its phrase (a share of a phrase, behind or ahead: section-voices.js), drawn half to all of
  // it; every other section's pools `recede` below their own while it plays (ours: the attention a soloist is given and
  // the others' lighter playing, docs/ATTENTION.md) -- the two together the solo's margin, shared over the piece by its
  // conductor as it grants each solo (solo-shares.js: a section that has given much of it before gives less now; where
  // none has, these). And its register, a request's answer for the sections sharing one
  // (docs/MUSEBOTS_3.md's third lack, "Registers ... still to ask for"): with each solo the conductor draws where it lies (a
  // centre within `register`), the soloing section takes the instrument whose compass holds it and plays a band `width`
  // wide about it, and every other section's pools clear that band, each moved away from it by the piece's `clear` share
  // of their overlap (drawn once a piece within its range: 0 the others where they were, 1 out of the solo's way), within
  // their own players' compass.
  solo:Object.freeze({raise:.15,recede:.2,rubato:.004,register:Object.freeze([52,82]),width:7,clear:Object.freeze([.5,1])}),
  // How far its players may improvise on their lines (improvise.js; the owner, 4 October 2026: "a conductor should be able
  // to allow performers it's conducting to improvise; and, if allowed, performers should be able to improvise on and
  // ornament melodies they have been given for contrapuntal reasons"): each section of the form's latitude drawn within
  // its role's range (ours: least where the form establishes or returns, most at its climax and where it develops; a
  // role not named takes `other`), each phrase's for a section's lines between none and twice it, a soloist's half the
  // way from it to all, those under a solo as much less as their level is told.
  latitude:Object.freeze({establish:Object.freeze([0,.35]),contrast:Object.freeze([.2,.7]),develop:Object.freeze([.3,.9]),climax:Object.freeze([.4,1]),
    return:Object.freeze([0,.4]),'complex-return':Object.freeze([.15,.6]),other:Object.freeze([0,.6])}),
  // Coordinated punctuation (research/fugue-and-coordination, MUSEBOTS_DATA_AND_COORDINATED_EVENTS.md: "coordinated
  // attacks, releases, silence and reentries"; conducting/coordinated-events.js): a section of the form ended by the
  // whole orchestra together -- a chord struck on its last bar's downbeat by every seat, held, cut off together, a
  // general pause to the bar's end, and the next section entering together -- as often as the piece's share (drawn once
  // within `share`, or settings.punctuation). Its hold the first of the bar's felt beats, as many as its share of them
  // (`hold`); its level (`level`); and how tightly its members strike and release (`spread`, s, the most between any
  // two players' own timing, tighter as the character is mechanical), while the whole may breathe with the phrase
  // (`placement`, s); and the general pause after it at least `space` (s: a wind's breath before the next entry, which had
  // otherwise been taken from the hit's end). Ours: the ranges.
  // The decisions a planner affords at which it keeps a counterpoint's contract fully (rigor 1; ours: a dozen bars of
  // three contingencies planned ahead -- horizon.js affordablePlanning).
  rigor:Object.freeze({decisions:200}),
  punctuation:Object.freeze({share:Object.freeze([0,.5]),hold:Object.freeze([.2,.7]),level:Object.freeze([.6,.95]),spread:Object.freeze([.008,.025]),placement:.04,space:.3}),
  // The orchestra imitating the tape (the owner's "continuity (as through imitation)", the other way about; research/
  // WHAT_THE_BOTS_NEVER_DO.md, 9): a section hears the tape's plan (acousmatic_clodbot: its events, their times and
  // kinds), and where one of its sounds overlaps a phrase most, its choice of texture leans toward that sound's
  // morphology (Smalley's spectromorphology: a struck onset, a held field, a granular cloud, a veiled one, a swell),
  // each leaning texture's weight times 1 + `gain` x the piece's share (`share`, drawn once a piece, or a spec's
  // settings.imitateTape) x its leaning. The kinds by the tape's events (ours, by how each is made: an impact and its
  // answers struck; its residues held; its scatter, and the band's own sound granulated, a cloud; its hidden sound
  // convolved, veiled; its swell reversed).
  imitateTape:Object.freeze({share:Object.freeze([0,1]),gain:8,
    kinds:Object.freeze({impact:'struck',answer:'struck',echo:'struck',interrupt:'struck','cut-across':'struck',return:'struck',
      residue:'held','last-residue':'held',scatter:'cloud','band-return':'cloud',hidden:'veiled',swell:'swell'}),
    leanings:Object.freeze({struck:Object.freeze({points:1,chord:.5}),held:Object.freeze({chord:1,cluster:.7}),
      cloud:Object.freeze({micropolyphony:1,points:.7,figuration:.5}),veiled:Object.freeze({cluster:1,micropolyphony:.5}),swell:Object.freeze({glides:1,cluster:.5})})}),
  // A section that returns recalls an earlier one (the owner, 2 October 2026: "The bots never recapitulate a whole formal
  // section. Ideally, they would be able to do so, and also do so in re-orchestrated or otherwise modified form"): a
  // section of these roles takes back the piece's exposition (its first establishing section, else its first), each of
  // its phrases recalled by its own draw under `share` (the square root of a uniform draw over it: most returns recall
  // much) -- its harmony that phrase's, moved to the return's region, and each of its sections' formations that phrase's,
  // whose seeds make the same material -- and `exchange` of each recalled formation's pools trading their material (the
  // square of a uniform draw: re-orchestrated a little, now and then much). Every state between none and all. Ours.
  // A recalled pool may take another section's material instead (`across`, the square of a uniform draw: the strings
  // taking back the winds' line, the winds the strings'), from what that section said for the same phrase. And a return
  // transformed, as a theme returns augmented or inverted: its lines' notes `augment` times longer (1, as they were, to
  // twice) and each of their steps turned the other way as often as `invert` (0, as they were, to 1, the line inverted),
  // and its harmony re-moded into the return's own collection as far as `remode` (0, the exposition's chords moved whole;
  // 1, each tone the nearest in the return region's mode and tuning), each drawn once a return as the cube of a uniform
  // draw (most returns as they were, some much transformed); and its recalled phrases' lines played backwards (a crab:
  // each note's time turned about its phrase) as often as `retrograde` (0, none, to 1, every one), likewise drawn; and its
  // phrases in an order of their own as far as `reorder` (0, as they were, to 1, an order drawn whole), likewise drawn.
  // Each role's share of its phrases recalled, a range drawn from (ours): a return's most of them, as above; a
  // development's, a climax's or a contrast's now and then (a phrase of the exposition returning inside another section:
  // the 'never does' list, item 4's Next), each transformed as a return's are; the exposition's none, being the source.
  recall:Object.freeze({roles:Object.freeze({return:Object.freeze([0,1]),'complex-return':Object.freeze([0,1]),develop:Object.freeze([0,.4]),climax:Object.freeze([0,.25]),
    contrast:Object.freeze([0,.15]),other:Object.freeze([0,.2])}),exchange:Object.freeze([0,1]),across:Object.freeze([0,1]),
    augment:Object.freeze([1,2]),invert:Object.freeze([0,1]),remode:Object.freeze([0,1]),retrograde:Object.freeze([0,1]),reorder:Object.freeze([0,1]),
    // (And, past its source's phrases, each time through further transformed by `vary` -- a variation set -- likewise
    // drawn: its inversion and its crabs that share more each time, its augmentation that share longer.)
    vary:Object.freeze([0,1])}),
  // Where the form develops, a canon among the parts a spec names (settings.canon): its subject at most this many bars,
  // drawn from the harmony heard a phrase before its section (the canon's own horizon), each voice a bar after the
  // last, every other voice a tonal answer (as many of the collection's degrees up as its rules count perfect:
  // counterpoint.js perfectDegrees), the rest an octave lower each.
  canonRoles:Object.freeze(['depart','develop','contrast']),canonBars:4,canonHorizon:'phrase',canonRegister:Object.freeze({low:60,high:79}),
  // And a canon's form: at the inversion (its every other voice its subject's inversion, not its answer) or by
  // augmentation (its every other voice its subject twice as slow) as often as their shares, each drawn a canon up to
  // `most` (the square of a uniform draw: most canons as they were), its subject planned against the form (ours); and a
  // round as often as its share, likewise drawn up to `round` (round-plan.js): its subject as many bars as it has
  // voices, at most `roundBars`, each voice singing it again through its section in whole cycles where the round holds
  // whole, its joins too; else sung once.
  canonForm:Object.freeze({most:.5,augmentation:2,round:.6,roundBars:6}),
  // The contingencies prepared with each section, in this order (settings.contingencies keeps the first so many, as
  // horizon.js affordablePlanning counts them less the plan itself; where two are taken, the later one's change wins):
  //   follow  the person playing more than `follow` from the section's tempo (a few just-noticeable differences): the
  //           section in their tempo (in the band's beat, within mh_PlexBOT's 40 to 220), met within its first bar
  //   room    the person playing busily (activity at least `busy`: eighths in any beat): the band lighter, the section's
  //           densities and the level of the groups below down by `room` (a soloist's share of the attention)
  //   fill    the person heard, silent `silentBars` of the section before's bars or more, and not busy: the band takes
  //           the space, up by `fill`
  //   hold    the person asking to be followed as a cadenza ('released'): no new meter or tempo under it, the section in
  //           the meter, grouping and tempo of the one before
  contingencies:Object.freeze(['follow','room','fill','hold']),follow:.06,busy:BUSY,room:.2,fill:.15,silentBars:2,
  tempoRange:Object.freeze({low:40,high:220}),
  // A section's meter and tempo are handed over this long before its bar at least, named for its bar ('bar:<n>'): a
  // networked room agrees a meter only at a bar line METER_NOTICE_SECONDS after it hears it, and the relay between hosts
  // takes some of a second more (ours: .9 s). Where its bars are longer, a bar before, as mh_PlexBOT's transport asked.
  handoverSeconds:METER_NOTICE_SECONDS+.9,
});
const round=value=>Math.round(value*1000)/1000;
const clamp01=value=>Math.max(0,Math.min(1,value));
const phraseBarsOf=clock=>Math.max(1,Number(clock?.meter?.phraseBars)||bandPhraseBars());
// A section before the first one a plan still says (its earlier ones gone by when this conductor heard it): a stand-in,
// a bar each, the last reaching the first said, so that the sections after it fall on their bars.
const standIn=(index,first,startBar)=>({role:null,standIn:true,last:false,
  bars:index<first.index-1?1:Math.max(1,first.startBar-startBar-(first.index-1))});

export class PlexClodbot extends PlexBot{
  constructor(...args){
    super(...args);
    const settings=args[2]??{};
    // (Its horizon and its contingencies afforded by a budget where it is given one and neither is said: settings.budget,
    // the ms it may spend planning before its next commitment is due, against what a decision costs it, measured once
    // in development (planning-cost.json): a small budget improvisation, a large one composition; no clock is read.)
    // (Else its deployment's: the device it runs on, as its tier declares one -- a phone's, a modest machine's;
    // shared/device-profile.js. A desktop and an offline render declare none.)
    const budget=settings.budget??(settings.horizon==null&&settings.contingencies==null?args[1]?.device?.planningMs??null:null);
    const afforded=budget!=null&&settings.horizon==null?affordablePlanning({budgetMs:Number(budget),msPerDecision:PLANNING_COST.msPerDecision,most:PLEX_CLODBOT.contingencies.length+1}):null;
    this.afforded=afforded;
    this.horizon=checkedHorizon(settings.horizon??(afforded?afforded.horizon==='piece'?'piece':`${afforded.horizon.bars} bars`:'piece'));
    // (A plan given as a document, settings.plan: its sections' roles its form, their given fields over its draws, their
    // given layers taken as decided. One it cannot read it says, and plans its own: plan-document.js.)
    this.document=null;
    if(settings.plan!=null){try{this.document=checkedPlanDocument(settings.plan)}catch(error){this.documentRefused=error.message}}
    this.performerHorizon=checkedHorizon(settings.performerHorizon??'phrase');
    // The section it leads, where its spec names one (section-kinds.js): its kind and spec, and the formations it has said
    // (by bar) and last decided.
    // (Where in the range from one player to all its breadth lies, settings.breadth [low, high]: a piece for the tutti,
    // [1, 1], or a chamber piece of an orchestra's soloists, [0, .3]; the whole range by default.)
    this.breadth=Array.isArray(settings.breadth)&&settings.breadth.length===2&&settings.breadth.every(x=>Number.isFinite(Number(x))&&x>=0&&x<=1)&&settings.breadth[0]<=settings.breadth[1]?settings.breadth.map(Number):null;
    if(settings.breadth!=null&&!this.breadth)throw new RangeError('plex_clodbot breadth is a range [low, high] within 0 to 1');
    // (The piece's texture requirements, settings.texture [{voices, time}], each within 0 to 1; else PLEX_CLODBOT's.)
    if(settings.texture!=null&&!(Array.isArray(settings.texture)&&settings.texture.every(t=>t&&[t.voices,t.time].every(x=>Number.isFinite(Number(x))&&x>=0&&x<=1))))
      throw new RangeError('plex_clodbot texture is a list of {voices, time}, each within 0 to 1');
    this.textureAsked=settings.texture!=null?settings.texture.map(t=>({voices:Number(t.voices),time:Number(t.time)})):null;
    // (How far a section it leads imitates the tape, settings.imitateTape, 0 to 1; else drawn once a piece.)
    if(settings.imitateTape!=null&&!(Number(settings.imitateTape)>=0&&Number(settings.imitateTape)<=1))throw new RangeError('plex_clodbot imitateTape is a share from 0 to 1');
    this.imitateTapeAsked=settings.imitateTape!=null?Number(settings.imitateTape):null;
    // (How much its phrases breathe, settings.rubato: a factor on each phrase's drawn depth, 0 none; 1 as drawn.)
    if(settings.rubato!=null&&!(Number(settings.rubato)>=0))throw new RangeError('plex_clodbot rubato is a factor from 0');
    this.rubatoAsked=settings.rubato!=null?Number(settings.rubato):1;
    if(settings.inspiration!=null&&!(Number(settings.inspiration)>=0&&Number(settings.inspiration)<=1))throw new RangeError('plex_clodbot inspiration is a share from 0 to 1');
    this.inspirationAsked=settings.inspiration!=null?Number(settings.inspiration):null;
    // (How often a section of the form ends in a coordinated hit and a general pause, settings.punctuation, 0 to 1; else
    // drawn once a piece.)
    if(settings.punctuation!=null&&!(Number(settings.punctuation)>=0&&Number(settings.punctuation)<=1))throw new RangeError('plex_clodbot punctuation is a share from 0 to 1');
    this.punctuationAsked=settings.punctuation!=null?Number(settings.punctuation):null;
    // (The equal steps an octave its harmony is planned in, settings.division: every region's collection and tonic that
    // division's nearest (harmony-plan.js regionFor), for a keyboard of fixed keys in it beside the band; none, as drawn.)
    if(settings.division!=null&&!(Number.isInteger(Number(settings.division))&&Number(settings.division)>=5&&Number(settings.division)<=96))throw new RangeError('plex_clodbot division is a count of equal steps an octave, 5 to 96');
    this.division=settings.division!=null?Number(settings.division):null;
    // (The scope of vibrato it gives each instrument, settings.vibrato: [low, high] shares of its players' measured widths,
    // for all, or by instrument or family (strings, winds, brass); else each instrument's drawn once a piece -- the style
    // it brings: vibrato.js vibratoScope.)
    this.vibratoAsked=settings.vibrato??null;
    // (How often a section of the form that may develop a fugue does, settings.fugues, a share from 0 to 1; else
    // FUGUE.chance. Where, and which, are its own draws.)
    if(settings.fugues!=null&&!(Number(settings.fugues)>=0&&Number(settings.fugues)<=1))throw new RangeError('plex_clodbot fugues is a share from 0 to 1');
    this.fugueShare=settings.fugues!=null?Number(settings.fugues):FUGUE.chance;
    // (How often a fugue voice played by more than one section is doubled at an interval of its own in each after its
    // first, settings.doubling, a share from 0 to 1; else drawn a fugue: orchestration.js FUGUE_VOICES.doubling.)
    if(settings.doubling!=null&&!(Number(settings.doubling)>=0&&Number(settings.doubling)<=1))throw new RangeError('plex_clodbot doubling is a share from 0 to 1');
    this.doublingAsked=settings.doubling!=null?Number(settings.doubling):null;
    // (And how often its return is re-orchestrated, settings.reorchestrate, a share; else drawn a fugue:
    // FUGUE_VOICES.reorchestrate.)
    if(settings.reorchestrate!=null&&!(Number(settings.reorchestrate)>=0&&Number(settings.reorchestrate)<=1))throw new RangeError('plex_clodbot reorchestrate is a share from 0 to 1');
    this.reorchestrateAsked=settings.reorchestrate!=null?Number(settings.reorchestrate):null;
    // (How many voices its fugues have, settings.fugueVoices: a count, a range [low, high] it draws one from, or 'seats',
    // a voice a seat; else drawn a fugue between its sections and its seats: orchestration.js.)
    const voicesAsked=settings.fugueVoices;
    if(voicesAsked!=null&&voicesAsked!=='seats'&&!(Number(voicesAsked)>=2)&&!(Array.isArray(voicesAsked)&&voicesAsked.length===2&&voicesAsked.every(n=>Number(n)>=2)&&voicesAsked[0]<=voicesAsked[1]))
      throw new RangeError('plex_clodbot fugueVoices is a count from 2, a range [low, high], or \'seats\'');
    this.fugueVoicesAsked=voicesAsked??null;
    // (How rigorously its counterpoint keeps its contract, settings.rigor: a share from 0 to 1, or 'composed', all of it;
    // else as its planning affords: rigorPolicy.)
    if(settings.rigor!=null&&settings.rigor!=='composed'&&!(Number(settings.rigor)>=0&&Number(settings.rigor)<=1))throw new RangeError('plex_clodbot rigor is a share from 0 to 1, or \'composed\'');
    this.rigorAsked=settings.rigor??null;
    // (How far its players may improvise, settings.improvisation: a share from 0 (never) to 1 (as far as each section of
    // the form's role allows, PLEX_CLODBOT.latitude), the role's range scaled by it; or a range [low, high] every section's
    // latitude is drawn in; else as its roles allow.)
    const improvisation=settings.improvisation;
    if(improvisation!=null&&!(Number(improvisation)>=0&&Number(improvisation)<=1)&&!(Array.isArray(improvisation)&&improvisation.length===2&&improvisation.every(n=>Number(n)>=0&&Number(n)<=1)&&improvisation[0]<=improvisation[1]))
      throw new RangeError('plex_clodbot improvisation is a share from 0 to 1, or a range [low, high] within it');
    this.improvisationAsked=improvisation??null;
    // (How far its harmony is a jazz player's, settings.jazz: a share from 0, its own chords, to 1, seventh chords whose
    // roots fall by fifths; harmony-plan.js jazzLanguage.)
    if(settings.jazz!=null&&!(Number(settings.jazz)>=0&&Number(settings.jazz)<=1))throw new RangeError('plex_clodbot jazz is a share from 0 to 1');
    this.jazzAsked=Number(settings.jazz)||0;
    // (How much repetition close together its listeners are projected to take, settings.repetition (repetition.js: a share
    // of its tolerances, or the tolerances themselves), handed to its sections with every formation; else its own.)
    this.repetitionAsked=settings.repetition!=null?repetitionOf(settings.repetition):null;
    // (How far its players' own time may stray from its own, settings.ownTime (s): as told; else by how many it conducts,
    // PLEX_CLODBOT.ownTime.)
    if(settings.ownTime!=null&&!(Number(settings.ownTime)>=0))throw new RangeError('plex_clodbot ownTime is seconds, 0 or more');
    this.ownTimeAsked=settings.ownTime!=null?Number(settings.ownTime):null;
    // (Following a performer, settings.follow: an orchestra playing with a recording or a player it cannot lead -- the
    // band's tempo and meter the performer's, as the transport follows them; its own form, formations and entries over
    // them, none of its tempo curves, rubato or meters handed over, its sections in the meter the band counts; and where
    // the render knows the recording ahead (foresight, render/foresight.js), the piece ending with it.)
    if(settings.follow!=null&&typeof settings.follow!=='boolean')throw new RangeError('plex_clodbot follow is true or false');
    this.followsPerformer=settings.follow===true;this.renderInputs=settings.inputs??null;
    // (Its form grammar's choices where its settings say any (settings.grammar: plex-grammar.js's, e.g. its denominators
    // and their weights), the rest its authored ones: what it draws its sections from, its drawing still its own -- a
    // recipe may ask irrational meters to come as often as it likes, the owner, 4 October 2026: "I currently don't see
    // any Ferneyhoughish irrational meters".)
    if(settings.grammar!=null){if(typeof settings.grammar!=='object'||Array.isArray(settings.grammar))throw new RangeError('plex_clodbot grammar is an object of plex-grammar.js choices');
      this.grammar=plexGrammar({...defaultPlexGrammar(CONFIG.plex),name:'asked',...settings.grammar})}
    // (Duration as an aesthetic, settings.elongation (the owner, 2 October 2026: "provision for duration-based
    // aesthetics, which elongate (sometimes extremely) the processes used in other aesthetics, while keeping the
    // performance-simulation constraints on the players"): a factor from 1 to 64, or a range [low, high] it draws one
    // from, on a log scale, once a piece; its phrases that many times longer, its chords that much slower.)
    const elongation=settings.elongation;
    if(elongation!=null){
      const range=Array.isArray(elongation)?elongation.map(Number):[Number(elongation),Number(elongation)];
      if(!(range.length===2&&range.every(x=>Number.isFinite(x)&&x>=1&&x<=64)&&range[0]<=range[1]))throw new RangeError('plex_clodbot elongation is a factor from 1 to 64, or a range [low, high] of them');
      this.elongationRange=range;
    }else this.elongationRange=[1,1];
    this.section=sectionOf(settings.section);this.formationsSaid=new Map;this.lastFormation=null;
    this.groupId=String(settings.group??(this.section?this.section.kind.group(this.section.spec):'ensemble'));this.parentGroup=settings.parent!=null?String(settings.parent):null;
    this.ends=settings.ends!==false;this.ritardando=settings.ritardando!==false;
    // Its harmony layer (settings.harmony 'plan': shared/conducting/harmony-plan.js): the piece's harmony planned with its
    // form, a section's region and progressions as it is committed, each chord said on the band's pool address as its
    // felt beat comes, so that the band needs no harmony bot of its own. Unset, the band's harmony is another bot's.
    if(settings.harmony!=null&&settings.harmony!=='plan')throw new RangeError("settings.harmony is 'plan', or unset");
    this.harmonyPlanned=settings.harmony==='plan';this.harmonySaid=null;
    // Requests up the tree (shared/conducting/requests.js): its own asks, by section of the form, and its children's,
    // heard, with the rests it has granted each.
    this.asked=new Set;this.requests=new Map;this.rested=new Map;this.requestsHeard=false;
    this.tree=new GroupTree();this.known=new Set;this.stimuliHeard=[];
    this.sketch=null;this.planner=null;this.begun=false;
    this.sectionPlanIds=new Map;   // unit index -> its rhythm plan
    this.handed=new Set;           // unit indices handed to the transport
    this.cued=new Set;             // unit indices whose section, grouping, phrase length and densities were said
    this.verified=new Set;         // unit indices whose meter was seen in force (or asked for again)
    this.constraintsHeard=new Map; // constraints heard, by group, level and bar (JSON): the same said again is no stimulus
    this.constraintsSaid=new Map;  // unit index -> the constraints said for it (JSON)
    this.piecePlan=null;this.pieceRevision=-1;this.stopSent=false;this.ritardandoSent=false;this.closingHeard=false;
    // The singers' phrases heard, and where a song set whole ends (shared/song-ending.js).
    this.songs=new SongWatch();this.songEndBar=null;
    this.parentPlan=null;          // a subconductor's parent's piece plan
    // The parts a canon is planned for (settings.canon: two or more, each a bot's id, instance or part name), its notes
    // by section, and the part plans said.
    this.canonParts=Array.isArray(settings.canon)?settings.canon.map(String).filter(Boolean):[];
    if(this.canonParts.length===1)throw new RangeError('A canon has two parts or more');
    this.canonNotes=new Map;this.canonSaid=new Map;
    // Its fugues' voices said as part plans (sayFugues), and, a section's, those said it (hearParent).
    this.fugueSaid=new Map;this.fugueParts=new Map;
    // The contingencies prepared with each section (how many, 0 to 4), the people's profiles, and its own horizon to
    // return to when they have gone.
    const count=settings.contingencies??(afforded?Math.min(PLEX_CLODBOT.contingencies.length,afforded.contingencies-1):PLEX_CLODBOT.contingencies.length);
    if(!(Number.isInteger(count)&&count>=0&&count<=PLEX_CLODBOT.contingencies.length))throw new RangeError(`contingencies is 0 to ${PLEX_CLODBOT.contingencies.length}`);
    this.contingencyCount=count;this.profiles=new Profiles();this.ownHorizon=this.horizon;this.withPerson=false;this.contingenciesTaken=[];
    // The conductors of its group (election.js), when it began conducting, whether it stands by and for whom, and what it
    // has heard of the others' plans (by author: the piece, the form, a stop committed), to take over from.
    this.peers=new Election();this.conductingSince=null;this.deputy=false;this.incumbent=null;
    this.heardPieces=new Map;this.heardForms=new Map;this.heardStops=new Map;
    this.adoptedLayers=new Map((this.document?.sections??[]).map((section,index)=>[index,section.layers]).filter(([,layers])=>layers));
  }
  get nested(){return this.parentGroup!==null}

  // ---- The sketch and the sections ----------------------------------------------------------------------------------
  // The archetype drawn as mh_PlexBOT draws it: its roles are the sketch the sections are drawn from, one by one.
  drawSketch(){
    if(this.document){this.sketch={name:this.document.archetype??'plan',roles:this.document.sections.map(section=>section.role)};return this.sketch}
    const c=this.rules(),archetype=weightedChoice(c.formArchetypes,c.formArchetypes.map(item=>item.weight));
    this.sketch={name:archetype.name,roles:[...archetype.roles]};
    return this.sketch;
  }
  // Where a render declares its length, the bar it ends on (as mh_FormBOT reads it); null in a live room.
  declaredEnd(clock){
    const end=this.audio?.renderEnd;if(!end)return null;
    const meter=clock?.meter||{},pulses=meter.pulsesPerBar||bandMeter().pulsesPerBar;
    let bar=null;
    if(Number.isInteger(end.bars))bar=end.bars;
    else if(Number.isFinite(end.ticks))bar=Math.floor(end.ticks/pulses);
    else if(Number.isFinite(end.seconds)&&clock?.bpm>0){
      const bars=end.seconds/(pulses*60/clock.bpm/(meter.subdivision||bandMeter().subdivision));
      const nearest=Math.round(bars),onBoundary=Math.abs(bars-nearest)<=8*Number.EPSILON*Math.max(1,bars);
      bar=this.renderInputs?.arrangement?(onBoundary?nearest:Math.ceil(bars)):Math.floor(bars);
    }
    return Number.isInteger(bar)&&bar>0?bar:null;
  }
  // A section drawn as mh_PlexBOT draws it (generateSection), fitted where the render declares its end: the section that
  // cannot leave a phrase after it is the last, in the sketch's last role, and ends at or before the render's end; one
  // before the last takes its share of what is left, as long against the sections still to come as it was drawn against
  // their mean (so that the sketch's sections share the render between them as they were drawn, not the last taking
  // whatever is left: Op. 3.7's return eight phrases long, a 64-bar render's return two thirds of it).
  decideSection(index,previous){
    // (Following a person whose end it cannot know -- nothing foreseen, no end in bars -- the piece goes on while they
    // play: about to draw its closing role, a middle one of its sketch first, in turn; the closing role once they have
    // gone (personGone). Its sketch run out, a 43 s play-along's band had stopped at its own bar 24, the guitarist playing
    // on alone.)
    if(this.sketch&&index===this.sketch.roles.length-1&&index>0&&this.followsPerformer&&this.withPerson&&!this.nested&&this.endDeclared==null&&this.performerEnd()==null){
      const middle=this.sketch.roles.slice(1,-1);
      if(middle.length)this.sketch={...this.sketch,roles:[...this.sketch.roles.slice(0,-1),middle[(index-1)%middle.length],this.sketch.roles.at(-1)]};
    }
    // (In a room where it is to go on -- settings.ends false, no end declared, no document -- the piece goes on as long as
    // the band is left to play: about to draw its closing role, the middle roles of an archetype drawn again first, so its
    // form keeps changing; its closing role never reached. Its sketch run out, a live quintet had stopped where its form
    // ended.)
    if(this.sketch&&index===this.sketch.roles.length-1&&index>0&&!this.ends&&!this.nested&&this.endDeclared==null&&this.endSecondsDeclared==null&&!this.document){
      const c=this.rules(),again=this.keyed(`jam:${index}`,()=>weightedChoice(c.formArchetypes,c.formArchetypes.map(item=>item.weight))),middle=again.roles.slice(1,-1);
      this.sketch={...this.sketch,roles:[...this.sketch.roles.slice(0,-1),...(middle.length?middle:again.roles.slice(0,1)),this.sketch.roles.at(-1)]};
    }
    if(!this.sketch||index>=this.sketch.roles.length)return null;
    const home=this.planner.units[0]?.value??null,start=previous?.endBar??this.planner.startBar;let end=this.endDeclared;
    // A return restores the opening's frame; before any section has been planned there is none, and the first section
    // is that frame: a return there (a sketch cut short to its last role at once, in a short render) is drawn as the
    // sketch's opening, never as a return to nothing.
    const opening=this.sketch.roles.find(each=>!RETURN_ROLES.includes(each))??this.sketch.roles[0];
    const homed=role=>home===null&&RETURN_ROLES.includes(role)?opening:role;
    let role=homed(this.sketch.roles[index]),last=index===this.sketch.roles.length-1;
    if(end!=null&&this.endSecondsDeclared==null&&start>=end)return null;
    const draw=role=>this.keyed(`section:${index}:${role}`,()=>this.generateSection(index,role,previous?.value??null,home));
    // (A document's section laid over the draw: its given fields; the document's last where the sketch is cut short.)
    // (Elongated, where a spec asks: its phrases that many times longer and its harmony that much slower, the players'
    // limits as they are within them -- settings.elongation.)
    // (Its exact elongations prepared with it, for its lines to choose from, never searched in a tick: exact-elongation.js.)
    const prepare=section=>{if(Number(section.elongation)>1)elongationCandidates({numerator:section.numerator,denominator:section.denominator,subdivision:section.subdivision,groups:section.groups});return section};
    const elongated=(drawn,given)=>this.elongation>1&&!given?.phraseBars?prepare({...drawn,phraseBars:Math.max(1,Math.min(PLAN_DOCUMENT.phraseBars[1],Math.round(drawn.phraseBars*this.elongation))),elongation:+this.elongation.toFixed(3)}):drawn;
    let given=this.document?.sections[index]??null,section=elongated(overlaySection(draw(role),given),given);
    // (Where the render ends in seconds, its end in this section's own bars, from what is left of it: a render's seconds
    // made bars once at the opening's length had carried Op. 3.31's ending -- its last section's bars more than twice as
    // long -- a fifth past its render, cut off mid-chord.)
    const endOf=section=>this.endSecondsDeclared==null?end:start+Math.floor((this.endSecondsDeclared-this.secondsTo(start))*Math.max(1,section.tempo.targetBpm)/(60*section.numerator)+1e-9);
    if(this.endSecondsDeclared!=null){
      end=endOf(section);
      if(start>=end)return null;
    }
    if(end!=null){
      let room=end-start;
      // (A section drawn again in another role -- its sketch spread or cut short -- its room measured again in its own
      // bars: Op. 3.35's return, drawn in place of a climax in 14/8, had been given the four 14/8 bars left as four of its
      // 5/8, one phrase, the piece over at 33 s of its minute.)
      const remeasured=()=>{end=Math.max(start,endOf(section));room=end-start};
      // (A render with room for fewer phrases than its sketch has roles: the sketch's arc kept in small, its first and last
      // roles and those between spread evenly over the phrases there are room for (spreadRoles), each a phrase or more --
      // never its first role alone over the whole render: Op. 3.36's minute, room for three phrases of its arch, had
      // been one section in its opening role, soft throughout, its rise and close never come. As many phrases as the
      // room holds at about their drawn length, two at least where it has two bars, its first phrase shortened to fit
      // where the drawn one is longer: a minute's render whose first phrase was drawn five bars of 11/4, 39 s, had been
      // that phrase alone, over at 40 s.)
      if(index===0&&!given&&this.sketch.roles.length>1){
        const phrases=Math.min(room,this.sketch.roles.length,Math.max(2,Math.round(room/Math.max(1,section.phraseBars))));
        if(phrases<this.sketch.roles.length){this.sketch={...this.sketch,roles:spreadRoles(this.sketch.roles,phrases).map((each,k)=>k?each:homed(each))};last=this.sketch.roles.length===1;
          if(role!==homed(this.sketch.roles[0])){role=homed(this.sketch.roles[0]);section=elongated(overlaySection(draw(role),given),given);remeasured()}}
        if(phrases>1&&phrases*section.phraseBars>room)section={...section,phraseBars:Math.max(1,Math.floor(room/phrases))};
      }
      if(!last&&room<(this.sketch.roles.length-index)*section.phraseBars){
        // The sketch cut short: its last role now, which the form closes with.
        role=homed(this.sketch.roles.at(-1));given=this.document?.sections.at(-1)??null;section=elongated(overlaySection(draw(role),given),given);last=true;this.sketch={...this.sketch,roles:[...this.sketch.roles.slice(0,index),role]};
        remeasured();
      }
      // (The closing section's phrases fitted to the room left: as many as it holds at about their drawn length, each as
      // long as whole bars allow -- never most of a phrase of the render left unplayed (a phrase it gives fixes its length).)
      if(last&&!given?.phrases){
        const fixed=Boolean(given?.phraseBars),phrases=Math.max(1,(fixed?Math.floor:Math.round)(room/section.phraseBars));
        section={...section,phrases,...(fixed?{}:{phraseBars:Math.max(1,Math.floor(room/phrases))})};
      }
      else if(!given?.phrases){
        const left=this.sketch.roles.length-index,drawn=section.phrases*section.phraseBars,others=(left-1)*this.meanPhrases()*section.phraseBars;
        // (Its share, and room left for a phrase of this length in each section after it.)
        const share=room*drawn/(drawn+others),most=Math.max(1,Math.floor((room-(left-1)*section.phraseBars)/section.phraseBars));
        section={...section,phrases:Math.max(1,Math.min(most,Math.round(share/section.phraseBars)))};
      }
      // (Longer than the render has room for -- a document's phrases -- as many of its phrases as fit, else one phrase as
      // long as the room.)
      if(section.phrases*section.phraseBars>room)section=section.phraseBars<=room?{...section,phrases:Math.floor(room/section.phraseBars)}:{...section,phraseBars:Math.max(1,room),phrases:1};
    }
    // The arrangement's trailing space belongs to the piece too. Rephrase the
    // closing section to cover it instead of dropping a remainder of a phrase.
    if(this.renderInputs?.arrangement&&last&&end!=null)section={...section,...arrangementClosingPhrase(end-start,section.phraseBars)};
    const bars=section.phrases*section.phraseBars;
    // (Following, its own opening meter kept: the band counts it until it hears the performer's bar, handOver.)
    if(index===0&&this.followsPerformer)this.ownOpening=section;
    section=this.followedMeter(section);
    return {...section,bars,barSeconds:round(section.numerator*60/Math.max(1,section.tempo.targetBpm)),last};
  }
  // A section in the meter the band counts, where it follows a performer (settings.follow): the transport's, as heard;
  // its tempo the band's. -> the section.
  followedMeter(section,clock=this.currentClock){
    const m=clock?.meter;if(!this.followsPerformer||!m?.numerator)return section;
    return {...section,numerator:m.numerator,denominator:m.denominator,subdivision:m.subdivision??section.subdivision,groups:Object.freeze([...(m.groups?.length?m.groups:[m.numerator])]),
      ...(Number(clock.bpm)>0?{tempo:{...section.tempo,targetBpm:+Number(clock.bpm).toFixed(3)}}:{})};
  }
  // Following: its sections to come, and the one under way, re-metered as the band's meter changes -- the performer's
  // heard otherwise -- and said again.
  followMeter(clock){
    const m=clock?.meter;if(!this.followsPerformer||!m?.numerator||!this.planner)return;
    const said=[m.numerator,m.denominator,m.subdivision,(m.groups??[]).join('+')].join('|');if(said===this.followedSaid)return;this.followedSaid=said;
    const bar=Number(clock.bar)||0;let changed=false;
    for(const unit of this.planner.units)if(bar<unit.endBar){unit.value=Object.freeze(this.followedMeter(unit.value,clock));changed=true}
    if(changed){this.planner.revision++;this.sayPlan(clock)}
  }
  // The bar a performer's profile says it hears (profile_clodbot meter: the band's beats it lasts, the band's tick of
  // their last downbeat), kept with how many times running it has been heard the same: its length and where in it the
  // band's beats fall, whatever bar of the band's it was heard in.
  hearMeter(profile){
    const meter=profile?.meter,sub=Number(this.currentClock?.meter?.subdivision)||0;
    if(!(Number.isInteger(meter?.beats)&&meter.beats>0&&Number.isFinite(meter.downbeatTick)&&sub>0))return;
    // (Their bar heard as 2 or as 4 is one bar at two levels -- 2/4 against 4/4 a subjective difference, 2/4 against 3/4 a
    // real one, the owner, 5 October 2026 -- so heard either way it is the same: its beats folded to their odd part, its
    // downbeat where it falls in the shortest of those bars.)
    let odd=meter.beats;while(odd%2===0)odd/=2;
    const cycle=odd*sub,key=`${odd}:${((meter.downbeatTick%cycle)+cycle)%cycle}`;
    this.meterHeard=this.meterHeard?.key===key?{...this.meterHeard,count:this.meterHeard.count+1,meter}:{key,count:1,meter};
  }
  // Following a performer, the band's bars counted as theirs (the owner, 5 October 2026: "synchronizing with existing
  // recordings"; the band had counted its seed's 31/6 against a guitarist's 4/4): once it has heard the same bar
  // PLEX_CLODBOT.followMeter.steady times running, from the first bar it can hand over, their meter -- their beat a
  // quarter -- and, where the band's bar line there would not fall on their downbeat, a bar before it just so long as
  // brings it there. Heard again otherwise (they change meter), again.
  followHeardMeter(clock){
    const heard=this.meterHeard,m=clock?.meter;
    if(!this.followsPerformer||!heard||heard.count<PLEX_CLODBOT.followMeter.steady||this.meterFollowed===heard.key||!m?.pulsesPerBar||!Number.isFinite(clock.tick))return;
    const sub=Number(m.subdivision)||1,bar=Number(clock.bar)||0,target=bar+this.leadBars(clock),N=heard.meter.beats,cycle=N*sub;
    const start=clock.tick-(clock.tickInBar??0)+(target-bar)*m.pulsesPerBar,joining=Math.round((((heard.meter.downbeatTick-start)%cycle)+cycle)%cycle/sub);
    this.meterFollowed=heard.key;
    // (Their beat the band's, written a quarter -- the follower, re-meeting the performer after a change of meter, counts
    // the meter's own note at their beat: written an eighth or a sixteenth, the band had played twice or four times as slow
    // in its written quarters -- and the band's bar theirs: a bar of theirs at another level written as their bars, never
    // 16/8 or 8/4 (the owner, 5 October 2026: "this seems like an absurd meter. Can we reduce these meters to, like, 4/2, or
    // even 2 bars of 4/4, when possible?"); its bar line brought onto their downbeat with a joining bar in its own beats.)
    const theirs=Number(heard.meter.theirs)||N,numerator=theirs,groups=[theirs],denominator=4;
    if(!joining&&m.numerator===numerator&&m.denominator===denominator)return;
    const phrase=m.phraseBars?{phraseBars:m.phraseBars}:{};
    if(joining)this.broadcast('timeSignature',[{numerator:joining,denominator:m.denominator,subdivision:sub,groups:[joining],...phrase},atBar(target)]);
    this.broadcast('timeSignature',[{numerator,denominator,subdivision:sub,groups,...phrase},atBar(target+(joining?1:0))]);
    this.decide?.({meter:{followed:true,bar:target,beats:N,theirs:heard.meter.theirs??null,numerator,denominator,...(groups?{groups}:{}),joining}});
  }
  // Foresight: where the performer's recording falls silent (render seconds), the last of the inputs', or null -- as
  // form_clodbot reads it.
  performerEnd(){
    if(this.renderInputs?.arrangement)return this.renderInputs.arrangement.endSeconds+(this.renderInputs.outputDelaySeconds??0);
    if(!this.renderInputs?.foresight)return null;
    this.foresightInputs??=this.renderInputs.list().map(input=>this.renderInputs.open(input.id)).filter(Boolean);
    const ends=this.foresightInputs.map(input=>input.foresight?.()?.audibleEnd).filter(Number.isFinite);
    return ends.length?Math.max(...ends):null;
  }
  // A subconductor's sections: its parent's, as its parent's piece plan has them.
  followSection(index){
    const units=this.parentPlan?.payload?.units??[],unit=units.find(item=>item.index===index);
    // (Before the first section its parent's plan still says -- a subconductor that joined late -- a stand-in.)
    if(!unit&&units.length&&index<units[0].index)return standIn(index,units[0],this.planner.startBar);
    // (Past the parent's last section, the piece has ended; short of it, the parent has not planned so far yet.)
    if(!unit)return this.parentPlan?.payload?.complete&&index>=(this.parentPlan.payload.units.at(-1)?.index??-1)+1?null:false;
    // (Its asks of its parent for the section: the phrases it would rest.)
    this.askRests(unit);
    return {role:unit.role??null,bars:unit.endBar-unit.startBar,phraseBars:unit.phraseBars??null,hdensity:unit.hdensity??null,
      barSeconds:unit.barSeconds??null,last:Boolean(unit.last),parentConstraints:unit.layers?.constraints??null,...(unit.elongation>1?{elongation:unit.elongation}:{})};
  }
  // The piece's length as the sketch has it (for a reach of the horizon): the sections decided, and the roles left at
  // mh_PlexBOT's mean phrases of the phrase length in force; the render's where it declares one.
  estimate(){
    if(this.endDeclared!=null)return this.endDeclared-this.planner.startBar;
    const units=this.planner.units,decided=(units.at(-1)?.endBar??this.planner.startBar)-this.planner.startBar;
    const left=Math.max(0,(this.sketch?.roles.length??units.length)-units.length);
    return decided+left*this.meanPhrases()*(units.at(-1)?.value.phraseBars??bandPhraseBars());
  }
  // How far through the piece it is (form-development.js formProgress, which MemoryBOT ranks its returns by): through the
  // render's declared length where it has one, else the piece decided or, before it has decided it all, the piece it
  // expects -- never only the sections it has decided so far (a phrase ahead, the first section's end its piece's half).
  progressOf(clock){
    const progress=formProgress(this.formPlan,clock),start=this.planner.startBar,bar=Number(clock?.bar);
    const total=this.endDeclared!=null?this.endDeclared-start:this.planner.ended?this.planner.through('form')-start:this.estimate();
    return Number.isFinite(bar)&&total>0?{...progress,overallProgress:round(Math.min(1,Math.max(0,(bar-start)/total)))}:progress;
  }
  // The seconds to a bar, its sections' bars each at its own length.
  secondsTo(bar){return this.planner.units.reduce((sum,unit)=>sum+Math.max(0,Math.min(unit.endBar,bar)-unit.startBar)*(Number(unit.value?.barSeconds)||0),0)}
  // The last bar line its plan reaches by `seconds`: the bar after the last one wholly within it.
  lastBarBy(seconds){
    let at=0,bar=this.planner.startBar;
    for(const unit of this.planner.units){const each=Number(unit.value?.barSeconds)||0;if(!(each>0))break;
      for(let b=unit.startBar;b<unit.endBar;b++){if(at+each>seconds+1e-6)return bar;at+=each;bar=b+1}}
    return bar;
  }
  // How long it expects the piece to last, in seconds: the sections decided, and the roles still to come (`sketch`) each an
  // equal share of the bars left (as it will share them out), a bar of each the numerator mh_PlexBOT's draw gives on
  // average (a return the opening's) at the role's tempo from the opening's, as generateSection sets it. Its expectation,
  // not a draw: it says nothing of the sections it has not decided.
  expectedSeconds(sketch=[]){
    const units=this.planner.units,decided=units.reduce((sum,unit)=>sum+(unit.endBar-unit.startBar)*(Number(unit.value.barSeconds)||0),0);
    const home=units[0]?.value,left=Math.max(0,this.estimate()-(this.planner.through('form')-this.planner.startBar));
    if(!home||!sketch.length||!(left>0))return decided;
    const c=this.rules(),numerator=c.numerators.reduce((sum,n,i)=>sum+n*c.numeratorWeights[i],0)/c.numeratorWeights.reduce((a,b)=>a+b,0);
    const base=home.tempo.targetBpm/(c.roleTempoMultiplier[home.role]??1);
    return decided+sketch.reduce((sum,role)=>{const back=RETURN_ROLES.includes(role);
      const bpm=back?home.tempo.targetBpm:Math.max(40,Math.min(220,base*(c.roleTempoMultiplier[role]??1)));
      return sum+left/sketch.length*(back?home.numerator:numerator)*60/bpm},0);
  }
  // mh_PlexBOT's mean phrases a section.
  meanPhrases(){const c=this.rules();return c.sectionPhrases.reduce((sum,value,i)=>sum+value*c.sectionPhraseWeights[i],0)/c.sectionPhraseWeights.reduce((a,b)=>a+b,0)}
  // `decide` with its draws keyed to `key` (a section's, a layer's decision for one): its own stream's state set from its
  // seed and the key for the call, and put back after, so that a decision draws the same whenever it is made -- a
  // phrase ahead, between the bars' other draws, or all at once before the first bar.
  keyed(key,decide){
    const stream=this.randomStream;if(!stream?.snapshot)return decide();
    const saved=stream.snapshot();stream.restore({...saved,state:hashSeed(`${saved.seed}:${key}`)});
    try{return decide()}finally{stream.restore(saved)}
  }
  // The piece's least and greatest density: its sections decided, and its sketch's roles still to come as they will be
  // drawn (the role's complexity, within PlexBOT's range of densities), `d` among them.
  pieceDensities(d){
    const c=this.rules(),{least,most}=PLEX_CLODBOT.level,units=this.planner?.units??[];
    const all=[d,...units.map(unit=>unit.value?.hdensity),...(this.sketch?.roles??[]).slice(units.length).map(role=>Math.max(least,Math.min(most,c.roleComplexity?.[role]??.5)))].filter(Number.isFinite);
    return [Math.min(...all),Math.max(...all)];
  }
  // A section of the form's breadth as its density plans it (PLEX_CLODBOT.players): where in the range from one player
  // to all (settings.breadth) its middle lies, `own` of a draw of its own and the rest where its density lies among the
  // piece's.
  breadthOf(unit,d=Number.isFinite(unit.value.hdensity)?unit.value.hdensity:.5){
    const {level,players}=PLEX_CLODBOT,[lowest,highest]=this.pieceDensities(d),[fewest,most]=this.breadth??[0,1];
    const absolute=clamp01((d-level.least)/(level.most-level.least)),relative=highest-lowest>=level.flat?clamp01((d-lowest)/(highest-lowest)):absolute;
    return fewest+(most-fewest)*clamp01((1-players.own)*relative+players.own*seededSource(Number(this.ensembleSeed)>>>0,`players:${unit.index}`)());
  }
  // The breadth at which at least `voices` (a share of a section's players, 0 to 1) play: a breadth's players are n to
  // its power, rounded (string-section.js playersOf), so the share differs with a section's size n -- three of five at
  // 0.57, six of ten at 0.74 (each its count less a half, n to it) -- the most its sections need, those it leads (its own, or its children's members), else
  // `voices` itself until it knows them.
  breadthFor(voices){
    const sizes=this.section?[this.section.kind.members(this.section.spec).length]:(this.tree?.children?.(this.groupId)??[]).map(child=>child.members?.length??0);
    const each=sizes.filter(n=>n>1).map(n=>{const k=Math.ceil(voices*n-1e-9);return k<=1?0:Math.min(1,Math.log(k-.5+1e-6)/Math.log(n))});
    return each.length?Math.max(...each):voices;
  }
  // The least breadth a section of the form takes so that the piece's texture holds (PLEX_CLODBOT.texture, or the spec's):
  // every requirement {voices, time} met -- its breadth's least, `spread` under it, at least `voices` of its players
  // (breadthFor) for at least `time` of the piece's bars -- by lifting the sections' planned breadths the least (each lift by its bars), chosen over the
  // whole form at once, those already given kept as given: an exact search over each section's levels (its own, or the
  // least each requirement asks), where its combinations are few enough; else the cheapest lifts a bar first. Where none
  // meets them all (a breadth capped below them), the one that falls least short. A cost within the choice, not a check.
  // The form it weighs is the one it knows deciding this section at any horizon: the sections before it as given (each
  // given first, in order), this one, and the sketch's roles after it as it expects them (expectedUnits) -- never a later
  // section's own decision, so that the piece is the same however far ahead it plans (test/planning-ahead.test.mjs: weighing
  // the sections it had decided, a piece planned whole had formed them otherwise than one planned a phrase ahead).
  textureFloor(unit,planned){
    const asked=this.textureAsked??PLEX_CLODBOT.texture;if(!asked.length)return 0;
    const {spread}=PLEX_CLODBOT.players,[fewest,most]=this.breadth??[0,1],given=this.textureGiven??=new Map;
    if(given.has(unit.index))return given.get(unit.index);
    const decided=(this.planner?.units??[]).filter(u=>!u.value.standIn&&u.endBar>u.startBar);
    if(!decided.includes(unit))return 0;
    const before=decided.filter(u=>u.index<unit.index).sort((a,b)=>a.index-b.index);
    for(const u of before)if(!given.has(u.index))this.textureFloor(u,this.breadthOf(u));
    const units=[...before,unit,...this.expectedUnits(unit)],total=units.reduce((sum,u)=>sum+u.endBar-u.startBar,0);if(!total)return 0;
    const least=b=>Math.max(fewest,b-spread),share=asked.map(t=>this.breadthFor?.(t.voices)??t.voices),need=k=>Math.min(most,share[k]+spread);
    const rows=units.map(u=>{const bars=u.endBar-u.startBar,own=u===unit?planned:this.breadthOf(u);
      if(given.has(u.index)&&u!==unit)return {u,bars,levels:[Math.max(own,given.get(u.index))],own};
      const levels=[...new Set([own,...asked.map((t,k)=>Math.max(own,need(k)))].map(x=>+x.toFixed(6)))].sort((a,b)=>a-b);return {u,bars,levels,own}});
    const shortfall=choice=>asked.reduce((sum,t,j)=>sum+Math.max(0,t.time*total-rows.reduce((bars,row,k)=>bars+(least(choice[k])>=share[j]-1e-6?row.bars:0),0)),0);
    const cost=choice=>rows.reduce((sum,row,k)=>sum+(choice[k]-row.own)*row.bars,0);
    let best=null;const combinations=rows.reduce((n,row)=>n*row.levels.length,1);
    if(combinations<=4096)for(let n=0;n<combinations;n++){let rest=n;const choice=rows.map(row=>{const level=row.levels[rest%row.levels.length];rest=Math.floor(rest/row.levels.length);return level});
      const score=[shortfall(choice),cost(choice)];if(!best||score[0]<best.score[0]-1e-9||Math.abs(score[0]-best.score[0])<=1e-9&&score[1]<best.score[1]-1e-9)best={choice,score}}
    else{const choice=rows.map(row=>row.levels[0]);
      for(const j of asked.keys()){const order=rows.map((row,k)=>k).filter(k=>rows[k].levels.length>1).sort((a,b)=>(need(j)-rows[a].own)-(need(j)-rows[b].own));
        for(const k of order){if(shortfall(choice)<=1e-9)break;choice[k]=Math.max(choice[k],need(j))}}
      best={choice}}
    const floor=best.choice[rows.findIndex(row=>row.u===unit)];given.set(unit.index,floor);return floor;
  }
  // The sections it expects after `unit` where it has not decided them, as it expects them at any horizon: the sketch's
  // roles after it, each its role's density (as pieceDensities draws it) and an equal share of the bars the render has
  // left after it where it declares an end, else mh_PlexBOT's mean phrases of `unit`'s phrase length (as estimate counts
  // them) -- stand-ins, never a decision.
  expectedUnits(unit){
    const roles=(this.sketch?.roles??[]).slice(unit.index+1);if(!roles.length)return [];
    const c=this.rules(),{least,most}=PLEX_CLODBOT.level;
    const each=this.endDeclared!=null?Math.max(0,this.endDeclared-unit.endBar)/roles.length:this.meanPhrases()*(unit.value.phraseBars??bandPhraseBars());
    if(!(each>0))return [];
    return roles.map((role,k)=>{const at=unit.endBar+k*each;
      return {index:unit.index+1+k,startBar:at,endBar:at+each,value:{role,hdensity:Math.max(least,Math.min(most,c.roleComplexity?.[role]??.5)),expected:true}}});
  }
  // The constraints a section sets for the groups below (PLEX_CLODBOT): from its density; a subconductor's, its parent's
  // narrowed by a choice of its own within them.
  sectionConstraints(unit){
    if(unit.value.standIn)return null;
    const {vocabulary,level,split,players,narrowing}=PLEX_CLODBOT;
    let d=Number.isFinite(unit.value.hdensity)?unit.value.hdensity:.5;
    const arrangement=this.renderInputs?.arrangement,clock=this.currentClock;
    if(arrangement&&!this.nested&&clock?.meter){
      const tickSeconds=secondsPerTick(clock),barSeconds=clock.meter.pulsesPerBar*tickSeconds;
      const from=this.renderInputs.now()+((unit.startBar-(clock.bar??0))*clock.meter.pulsesPerBar-(clock.tickInBar??0))*tickSeconds;
      const reading=arrangementDensity(d,arrangement,from,from+(unit.endBar-unit.startBar)*barSeconds,PLEX_CLODBOT);
      d=reading.density;
      (this.arrangementReadings??=new Map).set(unit.index,{section:unit.index,...reading.context,density:d,basis:'clip placements'});
      while(this.arrangementReadings.size>128)this.arrangementReadings.delete(this.arrangementReadings.keys().next().value);
    }
    const [lowest,highest]=this.pieceDensities(d);
    const absolute=clamp01((d-level.least)/(level.most-level.least)),relative=highest-lowest>=level.flat?clamp01((d-lowest)/(highest-lowest)):absolute;
    const centre=clamp01((1-level.arc)*absolute+level.arc*relative);
    const [fewest,most]=this.breadth??[0,1],planned=this.breadthOf(unit,d),breadth=Math.max(planned,this.textureFloor(unit,planned));
    const own=checkedConstraints({level:[round(clamp01(centre-level.spread)),round(clamp01(centre+level.spread))],
      split:[round(clamp01(split.scale*d-split.width)),round(clamp01(split.scale*d))],players:[round(Math.max(fewest,breadth-players.spread)),round(Math.min(most,breadth+players.spread))]},vocabulary);
    if(!this.nested)return own;
    let given;try{given=checkedConstraints(Object.fromEntries(Object.entries(unit.value.parentConstraints??{}).filter(([key])=>key in vocabulary)),vocabulary)}catch{given={}}
    const within=Object.fromEntries(Object.entries({...own,...given}).map(([key,range])=>{
      const bound=given[key]??range,width=(bound[1]-bound[0])*narrowing,low=chooseWithin([bound[0],bound[1]-width],vocabulary[key],{random:unitRandom});
      return [key,[round(low),round(low+width)]];
    }));
    return narrowConstraints(given,checkedConstraints(within,vocabulary),vocabulary).constraints;
  }

  // A section's contingencies (PLEX_CLODBOT), prepared as it is committed, each a change to it and a guard over the
  // people's profiles: its layer's decision, said in the piece plan.
  prepareContingencies(unit){
    if(unit.value.standIn)return null;
    const {follow,busy,room,fill,silentBars,tempoRange}=PLEX_CLODBOT,s=unit.value,before=this.planner.units[unit.index-1]?.value??null;
    const bpm=s.tempo.targetBpm,level=unit.layers.constraints?.level,playing={op:'eq',input:'present',value:true};
    const densities=delta=>({hdensity:round(Math.max(.2,Math.min(.85,s.hdensity+delta))),vdensity:round(Math.max(.2,Math.min(.8,s.vdensity+delta)))});
    const levels=delta=>level?{level:[round(clamp01(level[0]+delta)),round(clamp01(level[1]+delta))]}:null;
    const prepared={
      follow:()=>({id:'follow',guard:{op:'and',args:[playing,{op:'present',input:'tempo'},
          {op:'or',args:[{op:'lt',input:'tempo',value:round(bpm*(1-follow))},{op:'gt',input:'tempo',value:round(bpm*(1+follow))}]}]},
        section:{tempo:{targetBpm:{input:'tempo',...tempoRange,step:1},durationBars:1}},reason:`their tempo, where it is ${follow*100}% or more from ${bpm}`}),
      room:()=>({id:'room',guard:{op:'and',args:[playing,{op:'gte',input:'activity',value:busy}]},
        section:densities(-room),constraints:levels(-room),reason:'the band lighter while they play busily'}),
      fill:()=>({id:'fill',guard:{op:'and',args:[{op:'eq',input:'heard',value:true},{op:'lt',input:'activity',value:busy},
          {op:'gte',input:'silentSeconds',value:round(silentBars*(before?.barSeconds??s.barSeconds))}]},
        section:densities(fill),constraints:levels(fill),reason:'the band takes the space they leave'}),
      hold:()=>before&&{id:'hold',guard:{op:'and',args:[playing,{op:'eq',input:'released',value:true}]},
        previous:['numerator','denominator','subdivision','groups','rhythm','tempo'],reason:'no new meter or tempo under their cadenza'},
    };
    const alternatives=PLEX_CLODBOT.contingencies.slice(0,this.contingencyCount).map(kind=>prepared[kind]()).filter(Boolean).map(checkedContingency);
    return alternatives.length?{alternatives}:null;
  }
  // How far a player's own time may stray from its conductor's (s) among `players` (PLEX_CLODBOT.ownTime): as it is told,
  // else by how many it conducts; its parent's where that is narrower.
  ownTimeFor(players,parentUnit=null){
    const {most,least,few,many}=PLEX_CLODBOT.ownTime,n=Math.max(1,Number(players)||1);
    const own=this.ownTimeAsked??most*(least/most)**Math.max(0,Math.min(1,Math.log(Math.max(n,few)/few)/Math.log(many/few)));
    const parent=Number(parentUnit?.layers?.ownTime?.seconds);
    return +Math.min(own,Number.isFinite(parent)?parent:Infinity).toFixed(4);
  }
  // Where a section will sound, in the render's seconds, for the profiles that say what is ahead (with foresight only):
  // {from, to, beatSeconds}, or null. (Its start at the bars playing now; its own bars after, to the piece's end where
  // the recording ends it first.)
  sectionSpan(unit,clock){
    if(!this.renderInputs?.foresight||typeof this.renderInputs.now!=='function'||!clock?.meter?.pulsesPerBar)return null;
    const spt=secondsPerTick(clock),s=unit.value,from=this.renderInputs.now()+((unit.startBar-(Number(clock.bar)||0))*clock.meter.pulsesPerBar-(clock.tickInBar??0))*spt;
    const end=Math.min(unit.endBar,(this.followsPerformer?this.recordingEndBar(clock):null)??Infinity);
    return end>unit.startBar?{from,to:from+(end-unit.startBar)*s.barSeconds,beatSeconds:s.barSeconds/Math.max(1,s.numerator)}:null;
  }
  // The section's contingencies chosen as the profiles stand at its hand-over: those whose guards hold change it, said
  // again as its rhythm plan, its constraints and the piece plan. None holding, or what they read unknown, the plan stands.
  takeContingencies(unit,clock){
    const prepared=unit.layers.contingencies;if(!prepared?.alternatives?.length||prepared.chosen)return null;
    const bar=Number(clock?.bar)||0,snapshot=this.profiles.snapshot(bar,{span:this.sectionSpan(unit,clock)}),{taken}=chooseContingencies(prepared.alternatives,snapshot);
    if(!taken.length)return null;
    const chosen=prepared.alternatives.filter(item=>taken.includes(item.id)),previous=this.planner.units[unit.index-1]?.value??null;
    const {section,constraints}=applyContingencies(unit.value,chosen,{snapshot,previous,constraints:unit.layers.constraints});
    const inputs=Object.fromEntries(snapshot.inputs.filter(input=>input.state==='known').map(input=>[input.name,input.value]));
    unit.value=Object.freeze({...section,barSeconds:round(section.numerator*60/Math.max(1,section.tempo.targetBpm)),
      rationale:`${unit.value.rationale}; as they play: ${chosen.map(item=>item.reason).join('; ')}`.slice(0,240)});
    if(constraints)unit.layers.constraints=constraints;
    const ahead=snapshot.foreseen?{foreseen:snapshot.foreseen}:{};
    unit.layers.contingencies={...prepared,chosen:{bar,taken,inputs,...ahead}};
    this.contingenciesTaken.push({bar,section:unit.index,taken,inputs,...ahead});while(this.contingenciesTaken.length>32)this.contingenciesTaken.shift();
    this.announceSection(unit,clock);this.sayConstraints(unit);this.planner.revision++;
    return taken;
  }

  // ---- Planning --------------------------------------------------------------------------------------------------
  startPlanning(clock,startBar){
    if(this.planner)return;
    // (Following a performer, a render's end in seconds is not its bars: the band's bars are theirs, and its opening meter
    // is let go once it hears them -- counted at the seed's opening 31/6, fifteen seconds a bar, a 43 s play-along had
    // been planned two bars long and its band stopped there, the guitarist playing on alone. The render ends at its
    // seconds, a cutoff (render-session.js finish), and the conductor plans on to it.)
    this.endDeclared=this.nested||this.followsPerformer&&!Number.isInteger(this.audio?.renderEnd?.bars)&&!Number.isFinite(this.audio?.renderEnd?.ticks)?null:this.declaredEnd(clock);
    // (A render's end in seconds, each section fitted to what is left of it at its own bars' length: decideSection. Not
    // following a performer, whose tempo, not its plan's, is the band's, and whose recording ends the piece.)
    this.endSecondsDeclared=this.nested||this.followsPerformer||this.renderInputs?.arrangement||!Number.isFinite(this.audio?.renderEnd?.seconds)?null:Number(this.audio.renderEnd.seconds);
    if(!this.nested)this.drawSketch();
    // (A subconductor counts its sections from its parent's first, where it has heard its parent's plan.)
    if(this.nested&&Number.isInteger(this.parentPlan?.payload?.startBar))startBar=this.parentPlan.payload.startBar;
    this.planner=this.makePlanner(startBar);
    // (A plan document it could not read, said: it plans its own.)
    if(this.documentRefused){const reason=`its plan document was refused (${this.documentRefused}); it plans its own`;
      this.planner.note({kind:'document',reason,bar:startBar});this.audio?.report?.('bot_status',{state:'limited',message:reason})}
  }
  makePlanner(startBar,decide=(index,{previous})=>this.nested?this.followSection(index):this.decideSection(index,previous)){
    // (A layer decided by the conductor it took over from keeps that decision: adopt.)
    const adopted=(id,own)=>unit=>{const layers=this.adoptedLayers.get(unit.index);return layers&&Object.hasOwn(layers,id)?layers[id]:this.keyed(`${id}:${unit.index}`,()=>own(unit))};
    return new PiecePlanner({horizon:this.horizon,startBar,estimate:()=>this.estimate(),decide,
      layers:[{id:'constraints',decide:adopted('constraints',unit=>this.sectionConstraints(unit))},
        ...(this.contingencyCount&&!this.nested?[{id:'contingencies',decide:adopted('contingencies',unit=>this.prepareContingencies(unit))}]:[]),
        ...(this.canonParts.length&&!this.nested?[{id:'canon',horizon:PLEX_CLODBOT.canonHorizon,decide:adopted('canon',unit=>this.planCanon(unit))}]:[]),
        // (A section's formations, a phrase before its section: its players need them only so far ahead.)
        ...(this.section?[{id:'formation',horizon:'phrase',decide:adopted('formation',unit=>this.planFormations(unit))}]:[]),
        // (What a returning section recalls, before its harmony and its sections' formations, which take it.)
        ...(!this.nested?[{id:'recall',decide:adopted('recall',unit=>this.planRecall(unit))}]:[]),
        // (Its harmony, with the section: its region by its role, its phrases' progressions, its cadence.)
        ...(this.harmonyPlanned&&!this.nested?[{id:'harmony',decide:adopted('harmony',unit=>this.planHarmony(unit))}]:[]),
        // (How far its players may improvise in it: latitudeFor.)
        ...(!this.nested?[{id:'latitude',decide:adopted('latitude',unit=>this.latitudeFor(unit))}]:[]),
        // (The repetition its listeners are projected to take, where its settings say: a layer its sections hand on.)
        ...(!this.nested&&this.repetitionAsked?[{id:'repetition',decide:adopted('repetition',()=>({...this.repetitionAsked}))}]:[]),
        ...(!this.nested&&this.ownTimeAsked!=null?[{id:'ownTime',decide:adopted('ownTime',()=>({seconds:this.ownTimeAsked}))}]:[])]});
  }
  // Its group, said each bar: its presence to the other conductors of the group (since when it has conducted it, or that
  // it stands by), and the group to the tree.
  announceGroup(clock){
    this.broadcast('group',[{group:this.groupId,parent:this.parentGroup,conductor:this.selfId,label:this.groupId,
      parameters:Object.keys(PLEX_CLODBOT.vocabulary),appliesAt:{bar:Number(clock?.bar)||0},since:this.conductingSince,...(this.deputy?{deputy:true}:{})}]);
  }

  // ---- One conductor for a group, the others standing by ------------------------------------------------------------
  get selfId(){return this.instanceId??'plex_clodbot'}
  presence(bar){this.peers.setSelf(this.selfId);this.peers.hear({id:this.selfId,bar,since:this.conductingSince})}
  // Whether it conducts its group now: of the group's conductors heard within the grace, the first to have conducted it,
  // then the lowest id (election.js). One that is not stands by; one standing by that is elected (the conductor not
  // heard for the grace: its host dropped) takes over from its plan.
  conducts(clock){
    const bar=Number(clock?.bar)||0;this.presence(bar);
    const elected=this.peers.elected(bar)??this.selfId;
    if(elected!==this.selfId){
      if(!this.deputy)this.noteStimulus({kind:'standing-by',reason:`${elected} conducts ${this.groupId}`},clock);
      this.deputy=true;this.incumbent=elected;return false;
    }
    if(this.deputy){this.deputy=false;this.adopt(clock)}
    if(this.conductingSince===null){this.conductingSince=bar;this.peers.began(this.selfId,bar)}
    return true;
  }
  // Standing by: its presence said, the conductor's plans kept as they are heard (hearConductors), nothing else.
  standBy(clock){this.announceGroup(clock)}
  // The group's other conductors, and their plans as they say them: the piece, the form, a stop committed.
  hearConductors(message){
    const value=message?.args?.[0];
    if(message?.address===GROUP_ADDRESS&&value?.group===this.groupId&&typeof value.conductor==='string'&&value.conductor!==this.selfId)
      this.peers.hear({id:value.conductor,bar:this.lastBar??0,since:Number.isInteger(value.since)?value.since:null});
    if(message?.address!=='/broadcast/plan'||!value?.author||value.author===this.selfId)return;
    const keep=map=>{const held=map.get(value.author);if(held?.planId===value.planId&&held.revision>=value.revision)return;
      map.delete(value.author);map.set(value.author,value);while(map.size>8)map.delete(map.keys().next().value)};
    if(value.kind==='piece'&&value.payload?.group===this.groupId)keep(this.heardPieces);
    else if(value.kind==='form')keep(this.heardForms);
    else if(value.kind==='lifecycle'&&value.payload?.action==='stop'&&value.payload?.phase==='commitment')keep(this.heardStops);
  }
  // Taking over from the conductor that has gone: its plan as it said it (its form plan's sections from the first, its
  // piece plan's with their bars and layers, its stop if it committed to one), carried on from here. What has begun is
  // not handed over again, what it planned is played as it planned it, and past its plan this one decides as it would.
  // Nothing heard of its plan, this one's own from the next bar.
  adopt(clock){
    const bar=Number(clock?.bar)||0,from=this.incumbent,piece=this.heardPieces.get(from),form=this.heardForms.get(from),known=new Map;
    if(!this.nested&&Array.isArray(form?.payload?.sections)&&Number.isInteger(form.appliesAt?.bar)){
      let start=form.appliesAt.bar;
      for(const [index,section] of form.payload.sections.entries()){
        const bars=Math.max(1,Math.round(section.phrases*section.phraseBars));
        known.set(index,{startBar:start,value:{...section,bars,barSeconds:round(section.numerator*60/Math.max(1,section.tempo?.targetBpm||bandTempo())),last:false}});start+=bars;
      }
    }
    for(const unit of piece?.payload?.units??[]){const {index,startBar,endBar,layers,...value}=unit;if(!value.standIn)known.set(index,{startBar,value:{...value,bars:endBar-startBar},layers:layers??null})}
    const reason=`${from} not heard for ${this.peers.graceBars} bars: conducting ${this.groupId} ${known.size?'from its plan':'afresh'} from bar ${bar}`;
    this.noteStimulus({kind:'takeover',reason},clock);
    this.handed=new Set;this.cued=new Set;this.verified=new Set;this.sectionPlanIds=new Map;this.constraintsSaid=new Map;this.canonNotes=new Map;this.canonSaid=new Map;this.fugueSaid=new Map;
    this.piecePlan=null;this.formPlan=null;this.pieceRevision=-1;this.formSaid=null;this.stopSent=false;this.ritardandoSent=false;
    const indices=[...known.keys()].sort((a,b)=>a-b),complete=Boolean(piece?.payload?.complete),last=indices.at(-1);
    this.adoptedLayers=new Map(indices.filter(index=>known.get(index).layers).map(index=>[index,known.get(index).layers]));
    if(!indices.length){if(!this.nested)this.drawSketch();this.planner=this.makePlanner(bar+1)}
    else{
      if(!this.nested&&form?.payload)this.sketch={name:form.payload.archetype??this.sketch?.name??null,roles:[...form.payload.sections.map(section=>section.role),...(form.payload.sketch??[])]};
      const first={index:indices[0],startBar:known.get(indices[0]).startBar},startBar=Number.isInteger(piece?.payload?.startBar)?piece.payload.startBar:first.startBar;
      // (A stop it committed to, it keeps: nothing decided past it.)
      const stop=this.heardStops.get(from),stopBar=Number.isInteger(stop?.appliesAt?.bar)?stop.appliesAt.bar:null;
      if(stop){this.stopSent=true;this.stopCommitment=stop}
      this.planner=this.makePlanner(startBar,(index,{previous})=>{
        const found=known.get(index);
        if(found)return {...found.value,last:Boolean(found.value.last||complete&&index===last)};
        if(index<first.index)return standIn(index,first,startBar);
        const at=previous?.endBar??startBar;
        if(complete||stopBar!==null&&at>=stopBar)return null;
        const decided=this.nested?this.followSection(index):this.decideSection(index,previous);
        return decided&&stopBar!==null&&at+decided.bars>stopBar?{...decided,bars:stopBar-at,last:true}:decided;
      });
    }
    this.planner.note({kind:'takeover',reason,bar});
    this.plan(clock);
    for(const unit of this.planner.units)if(unit.startBar<=bar){this.handed.add(unit.index);this.cued.add(unit.index);this.verified.add(unit.index)}
    this.planner.lock(bar+1);
  }
  // Decide what has come within the horizon, and say it: each new section's rhythm plan, each section's constraints, the
  // piece plan and the form plan.
  plan(clock){
    const made=this.planner.advance({bar:Number(clock?.bar)||0,phraseBars:phraseBarsOf(clock)});
    for(const {index,layer} of made){
      const unit=this.planner.units[index];
      if(layer==='form'&&!this.nested)this.announceSection(unit,clock);
      if(layer==='constraints')this.sayConstraints(unit);
      if(layer==='canon')this.sayCanon(unit,clock);
      if(layer==='formation')this.sayFormations(unit);
    }
    this.sayPlan(clock);
    return made;
  }
  // The piece plan and the form plan, said again where the plan has changed since they were.
  sayPlan(clock){if(this.planner.revision!==this.pieceRevision){this.pieceRevision=this.planner.revision;this.sayFugues(clock);this.publishPiece(clock);if(!this.nested)this.publishForm(clock)}}
  // A committed section said as mh_PlexBOT says it, its rhythm plan applying at its bar (revised where it was said before).
  announceSection(unit,clock){
    // (Not a stand-in, nor a section a conductor taking over finds already played.)
    if(unit.value.standIn||unit.endBar<=(Number(clock?.bar)||0))return;
    const section=unit.value,meter={numerator:section.numerator,denominator:section.denominator,subdivision:section.subdivision,phraseBars:section.phraseBars,rhythm:section.rhythm};
    const payload={schemaVersion:1,meter,tala:[...section.groups],density:section.hdensity,verticalDensity:section.vdensity,tempo:{...section.tempo},formalRole:section.role};
    const appliesAt={bar:unit.startBar,phrase:Math.floor(unit.startBar/Math.max(1,section.phraseBars)),section:unit.index},expiresAt={...appliesAt,bar:unit.endBar,phrase:appliesAt.phrase+section.phrases};
    // (Positions in bars: a plan's phrase and section are labels, and the bar decides where it stands.)
    const options={createdAt:{bar:Math.min(unit.startBar,Number(clock?.bar)||0),phrase:0,section:0},
      appliesAt,expiresAt,horizon:section.phrases,confidence:.78,priority:.72,rationale:section.rationale};
    const before=this.sectionPlanIds.get(unit.index);
    const plan=before?this.plans.revise(before,payload,options):this.preparePlan('rhythm',payload,options);
    this.sectionPlanIds.set(unit.index,plan);
    this.sectionPlans.set(plan.planId,{section:unit.index,meter,answers:before?this.sectionPlans.get(before.planId)?.answers??new Map:new Map});
    while(this.sectionPlans.size>64)this.sectionPlans.delete(this.sectionPlans.keys().next().value);
    this.announcePlan(plan);
  }
  // A section's constraints for the groups below, from its first bar: addressed to this group, so they bind every group
  // within it (groups.js), and each subconductor narrows them for its own.
  sayConstraints(unit,{again=false}={}){
    const constraints=unit.layers.constraints;if(!constraints||unit.endBar<=(this.lastBar??0))return;
    const said=JSON.stringify(constraints);if(!again&&this.constraintsSaid.get(unit.index)===said)return;
    this.constraintsSaid.set(unit.index,said);
    // (A subconductor's say which of its parent's plans they narrow: authority.js.)
    const under=this.nested&&this.parentPlan?{under:{group:this.parentGroup,planId:this.parentPlan.planId,revision:this.parentPlan.revision}}:{};
    this.broadcast('group/constraints',[{group:this.groupId,from:this.groupId,appliesAt:{bar:unit.startBar},constraints:{...constraints},...under}]);
  }
  // The formations of a section of the form, phrase by phrase (the section it leads: section-kinds.js), each from the
  // last, within the constraints for its group from above (its tree) and its own for the section (the constraints layer:
  // a conductor leading players directly honours its own), and the piece's last phrase as the kind's specification has
  // it. -> the layer's decision: [{bar, bars, move, final, summary, formation (compact: string-section.js)}].
  planFormations(unit){
    if(unit.value.standIn)return null;
    const {kind,spec}=this.section,seats=kind.seatList(spec),phraseBars=Math.max(1,Number(unit.value.phraseBars)||unit.endBar-unit.startBar),out=[];
    const own=Object.fromEntries(Object.entries(unit.layers?.constraints??{}).filter(([key])=>key in kind.vocabulary));
    // (Its entry in a fugue its parent planned for the section, where it has one: fugue-plan.js -- or, where its parent
    // orchestrated the fugue's voices otherwise than a section each (orchestration.js), its voices: those its section
    // plays, each by its seats, `voiced`.)
    // (Its voices as its parent said them it, each a part plan (sayFugues: its notes, and its seats where not all of them),
    // or, from a plan that carries its fugue's entries whole -- a document's from before -- those naming its section.)
    const exposition=this.nested?this.parentPlan?.payload?.units?.find(item=>item.index===unit.index)?.layers?.fugue??null:null;
    const said=exposition?[...this.fugueParts.values()].map(plan=>plan.payload).filter(part=>part.section===unit.index&&part.voice<(exposition.voices??Infinity)).sort((a,b)=>a.voice-b.voice):[];
    const mine=said.length?said.map(part=>({entry:part,seats:part.seats??null})):(exposition?.entries??[]).filter(entry=>entry.group===this.groupId).map(entry=>({entry,seats:null}));
    const fugue=mine[0]?.entry??null,voiced=mine.length>1||mine.some(item=>item.seats)?mine:null;
    // (Each from the last of the section of the form before it, where that is decided: a section decided again starts
    // from where the one before it ended, not from its own first decision.)
    let previous=(this.formationsEnded??=new Map).get(unit.index-1)??this.lastFormation,phraseIndex=0;
    const recall=this.nested?this.parentPlan?.payload?.units?.find(item=>item.index===unit.index)?.layers?.recall??null:null;
    // (Its section of the form's coordinated punctuation, where its parent planned one: the phrase holding its bar played
    // to it, and from it every seat's hit and the general pause after, as its kind strikes it (section-kinds.js
    // punctuated); a kind that cannot rests through it.)
    const punctuation=this.nested?this.parentPlan?.payload?.units?.find(item=>item.index===unit.index)?.layers?.punctuation??null:null;
    const push=(entry,expanded)=>{
      // (Every pool given the piece's vibrato: its spec's scope, else the seed its players each draw their instrument's from.)
      expanded={...expanded,pools:expanded.pools.map(pool=>({...pool,vibrato:{asked:this.vibratoAsked,seed:Number(this.ensembleSeed)>>>0}}))};
      if(this.motifInsistences?.size&&FUGUE.kinds.test(this.groupId)){
        const result=insistOnFormation(expanded,this.motifInsistences.values(),{
          quarters:new Rational(entry.bars*unit.value.numerator*4,unit.value.denominator),
          random:seededSource(Number(this.ensembleSeed)>>>0,`motif insistence:${this.groupId}:${entry.bar}`),
          softAllowed:!fugue&&!/^recall/.test(entry.move??''),compasses:new Map(seats.map(seat=>[seat.id,seat]))});
        if(result.conflict){this.audio?.report?.('motif_insistence_conflict',{bar:entry.bar,...result.conflict});entry={...entry,motifConflict:result.conflict}}
        if(result.use){expanded=result.formation;entry={...entry,formation:compactFormation(expanded,seats),motifUse:result.use,
          move:`${entry.move??''}; ${result.use.required?'required':'preferred'} motif`,summary:kind.summary(expanded)};
          // Punctuation is another musical preference; it cannot cut a required motif.
          if(result.use.required){out.push(entry);return}}
      }
      const at=punctuation&&!entry.final?Number(punctuation.bar):NaN;
      if(!(at>=entry.bar&&at<entry.bar+entry.bars)){out.push(entry);return}
      if(at>entry.bar)out.push({...entry,bars:at-entry.bar});
      const struck=kind.punctuated?.(expanded,seats,{...punctuation,...(Number.isFinite(punctuation.arrivals?.[this.groupId])?{pitch:punctuation.arrivals[this.groupId]}:{})})??{...expanded,pools:expanded.pools.map(pool=>({...pool,texture:'tacet'}))};
      out.push({bar:at,bars:entry.bar+entry.bars-at,move:`coordinated: ${punctuation.id}`,final:false,summary:kind.summary(struck),formation:compactFormation(struck,seats),coordinated:punctuation.id});
    };
    for(let bar=unit.startBar;bar<unit.endBar;bar+=phraseBars){
      const bars=Math.min(phraseBars,unit.endBar-bar),final=Boolean(unit.value.last)&&bar+bars>=unit.endBar;
      const above=this.tree.constraintsFor(this.groupId,bar,kind.vocabulary);
      let mine;try{mine=checkedConstraints(own,kind.vocabulary)}catch{mine={}}
      const constraints=narrowConstraints(above?.constraints??{},mine,kind.vocabulary).constraints;
      // (The rest's draw shared by every section of the band: the ensemble's seed and the phrase's bar; and a rest its
      // parent granted it, its answer to an ask.)
      const shared=seededSource(Number(this.ensembleSeed)>>>0,`rest:${bar}`)();
      const granted=Boolean(this.parentPlan?.payload?.units?.find(item=>item.index===unit.index)?.layers?.rests?.[bar]?.includes(this.groupId));
      // (Whether the phrase opens a section of the form, past the piece's first, or leads into the next: the joins.)
      const opens=bar===unit.startBar&&unit.startBar>this.planner.startBar,closes=bar+bars>=unit.endBar&&!unit.value.last;
      const decided=kind.decide({bar,bars,previous,constraints,bound:Boolean(above&&Object.keys(above.constraints).length),random:unitRandom,spec,shared,granted,opens,closes,character:this.character??null,elongation:Number(unit.value.elongation)||1,
        lean:this.tapeLean(bar,bars)});
      let {formation,move}=decided;
      // (In a fugue: silent until its entry; its entry played as given, every pool a line an octave its own; its free
      // counterpoint after as given too, a phrase with none of it a rest -- or, in a fugue planned without it (a
      // document's from before), its own line.)
      const given=fugue&&!voiced?entryInPhrase(fugue,{bar,bars,meter:exposition.meter}):[];
      // (A phrase its section recalls, where the orchestra's conductor recalls an earlier section: the formation it said
      // for that section's phrase, its pools' seeds its material again, some of its pools trading theirs (exchange), as
      // the phrase's harmony is recalled with it. Not where it rests, nor in a fugue.)
      const recalled=!fugue&&recall?.phrases?.[phraseIndex]?this.recalledFormation(recall,phraseIndex,`${unit.index}:${phraseIndex}`):null;
      const resting=formation.pools.every(pool=>pool.texture==='tacet');
      // (A section's closing phrase, the piece's last, drawn as any phrase is: every part following its harmony into the
      // cadence that harmony's plan draws for the piece, its textures in their own drawn rhythm, and its lines given the
      // cadence's tonic as their goal -- an ending signified by its motif's return (line.js planLine final: its cadence on
      // the tonic, held through its last group, the motif returned as often as it draws), the band's theme where
      // MemoryBOT's motif plans carried one, heard before this section of the form began (the 'never does' list, item 6's
      // Next) -- and the conductor's stop cutting off together whatever still sounds; a recalled phrase's lines too, a
      // return's ending its own. Never a fugue's, which ends as its plan does (its stretto or its subject's return), nor a given line. The
      // phrase before had closed, and the last been laid over by a chord held to the stop, every piece's: the owner, 10
      // October 2026, "discover why compositions are so frequently ending with this one bad formula".)
      const ending=final&&!fugue?(()=>{
        const tonic=Number((this.nested?this.parentPlan?.payload?.units?.find(item=>item.index===unit.index):unit)?.layers?.harmony?.region?.tonic);
        const theme=this.bandTheme&&unit.startBar>(this.bandThemeAt??Infinity)?this.bandTheme:null;
        return {...(Number.isFinite(tonic)?{tonic}:{}),...(theme?{theme}:{})}})():null;
      const closed=formation=>ending?{...formation,pools:formation.pools.map(pool=>pool.texture==='line'&&!pool.given?{...pool,ending}:pool)}:formation;
      // (A solo its parent granted it, or another section's it recedes under: PLEX_CLODBOT.solo -- over a recalled phrase too,
      // its soloist playing the recalled material alone.)
      const parentUnit=this.nested?this.parentPlan?.payload?.units?.find(item=>item.index===unit.index):null;
      const soloist=!fugue?parentUnit?.layers?.solos?.[bar]??null:null,register=Number(parentUnit?.layers?.soloRegisters?.[bar]);
      const shares=parentUnit?.layers?.soloShares?.[bar]??PLEX_CLODBOT.solo;
      const soloed=(expanded,label)=>{
        if(!soloist||expanded.pools.every(pool=>pool.texture==='tacet'))return {formation:expanded,move:label};
        if(soloist===this.groupId){const solo=this.soloFormation(expanded,seats,bar,Number.isFinite(register)?register:null,shares.raise);return solo?{formation:solo.formation,move:`solo: ${solo.seat}${label?` (${label})`:''}`}:{formation:expanded,move:label}}
        // (Under it, lighter: its level receded, and the band's told rubato taken as much less as its level falls -- the
        // soloist's the freer, the owner's 'the others play lighter'.)
        // (Its pools out of the solo's register together where they can be, each side as a block: clearedTogether.)
        const receded=expanded.pools.map(pool=>{if(pool.texture==='tacet')return pool;const was=Number(pool.level)||.5,level=+Math.max(.02,was-shares.recede).toFixed(3);return {...pool,level,told:+(level/was).toFixed(3)}});
        const moves=this.clearingMoves(receded.filter(pool=>pool.texture!=='tacet'),seats,register);
        return {formation:{...expanded,pools:receded.map(pool=>pool.texture==='tacet'?pool:moves&&Object.hasOwn(moves,pool.id)?{...pool,centre:+(Number(pool.centre)+moves[pool.id]).toFixed(3)}:this.clearOf(pool,seats,register))},move:`${label}; under ${soloist}'s solo`};
      };
      if(recalled&&!resting){
        const label=`recall ${recall.from}${recalled.exchanged?`, ${recalled.exchanged} exchanged`:''}${recalled.augment>1.001?`, augmented ${recalled.augment}`:''}${recalled.invert>.001?`, inverted ${recalled.invert}`:''}`;
        // (Its solo from the recalled phrase, or, where the phrase recalled was a rest of it, from the phrase as decided.)
        const recalledExpanded=expandFormation(recalled.formation,seats),silent=recalledExpanded.pools.every(pool=>pool.texture==='tacet');
        const played=soloist?soloed(soloist===this.groupId&&silent?formation:recalledExpanded,label):null;
        const sounding=closed(played?.formation??recalledExpanded);
        push({bar,bars,move:played?.move??label,final,summary:kind.summary(sounding),formation:played||ending?compactFormation(sounding,seats):recalled.formation,recalled:recall.from},sounding);phraseIndex++;continue}
      if(voiced){formation=this.voicedFormation(formation,voiced,seats,{bar,bars,exposition});move=`fugue: ${voiced.length} voices`}
      else if(given.length){formation={...formation,pools:formation.pools.map(pool=>{const octave=this.voiceOctave(fugue,pool.seats??[],seats);return {...pool,texture:'line',parts:pool.parts.map(()=>0),given,...(octave!=null?{givenOctave:octave}:{})}})};move=`fugue: voice ${fugue.voice+1}'s entry${fugue.steps?', the answer':''}`}
      else if(fugue&&bar<fugue.fromBar){formation={...formation,pools:formation.pools.map(pool=>({...pool,texture:'tacet'}))};move='fugue: waits for its entry'}
      else if(fugue&&Number.isFinite(exposition.free)){formation={...formation,pools:formation.pools.map(pool=>({...pool,texture:'tacet'}))};move='fugue: rests'}
      else if(fugue){formation={...formation,pools:formation.pools.map(pool=>({...pool,texture:'line',parts:pool.parts.map(()=>0)}))};move='fugue: its own line'}
      // (Its lines imitating the tape's material where its sound overlaps the phrase, as far as its imitation share
      // (tapeMaterial): each line's register centred toward the tape's pitch in its own octave, and tilted along the
      // tape's contour over the phrase, the harmony still placing each note -- never a fugue's or a recalled line;
      // before a solo's register is cleared.)
      const material=!fugue&&!/^recall/.test(move??'')?this.tapeMaterial(bar,bars):null;
      if(material){const share=this.tapeShare,motif=material.onsets&&seededSource(Number(this.ensembleSeed)>>>0,`tape motif:${this.groupId}:${bar}`)()<share;
        // (And, as often as the same share, its motif the tape's: its rhythm of onsets and its steps -- section-voices.js.)
        formation={...formation,pools:formation.pools.map(pool=>pool.texture!=='line'||pool.given||!Number.isFinite(pool.centre)?pool:(()=>{
          const target=material.pitch+12*Math.round((pool.centre-material.pitch)/12);
          return {...pool,centre:+(pool.centre+share*(target-pool.centre)).toFixed(3),...(material.slope?{contour:+(share*material.slope).toFixed(3)}:{}),...(motif?{tapeLine:material.onsets}:{})}})())};
      }
      // (A theme's return MemoryBOT planned within the phrase: its lines' motif the theme -- the 'never does' list, item 6's
      // Next: "a theme's return planned by the form as well as heard". Never a fugue's, a given or a recalled line.)
      const returning=!fugue&&!/^recall/.test(move??'')?[...(this.themeReturns??new Map)].find(([at])=>at>=bar&&at<bar+bars)?.[1]??null:null;
      if(returning)formation={...formation,pools:formation.pools.map(pool=>pool.texture==='line'&&!pool.given?{...pool,themeLine:returning}:pool)};
      if(soloist&&!resting){const played=soloed(formation,move);formation=played.formation;move=played.move}
      formation=closed(formation);
      // (Its figurations taking after the last figure another player said, as far as its inspiration: figuration.js.)
      const heardFigure=this.heardFigure&&unit.startBar>(this.heardFigureAt??Infinity)?this.heardFigure:null;
      if(heardFigure&&this.inspiration>0&&formation.pools.some(pool=>pool.texture==='figuration'&&pool.parameters)){
        const tones=spec.specification?.parameters?.figuration?.tones??[1,5];
        formation={...formation,pools:formation.pools.map(pool=>pool.texture==='figuration'&&pool.parameters?{...pool,parameters:inspiredFigure(pool.parameters,heardFigure,this.inspiration,{tones})}:pool)};
      }
      // (No tremolo taken up from a roll or a tremolo heard: a section trembles only where it is asked to -- the owner, 3
      // October 2026: "Don't randomly insert tremolos".)
      // (Its lines' latitude, a given line's too: licensed.)
      formation=this.licensed(formation,{unit,parentUnit,bar,soloist});
      const repetition=(parentUnit??unit)?.layers?.repetition??this.repetitionAsked;if(repetition)formation={...formation,repetition:{...repetition}};
      formation={...formation,ownTime:this.ownTimeFor(seats.length,parentUnit)};
      push({bar,bars,move,final,summary:kind.summary(formation),formation:compactFormation(formation,seats)},formation);previous=decided.formation;phraseIndex++;
    }
    this.lastFormation=previous;this.formationsEnded.set(unit.index,previous);
    return out;
  }
  // A phrase of a fugue whose voices its section plays more than one of, or some of its seats one (orchestration.js): a
  // pool a voice, its seats only (`only`), each like the pool its seats were in as decided (its register, its level);
  // its given notes in the phrase a line, else silent before its entry or where its fugue rests its voices, else its
  // own line. -> the formation.
  voicedFormation(formation,voiced,seats,{bar,bars,exposition}){
    const pools=voiced.map(({entry,seats:ids})=>{
      const theirs=seats.filter(seat=>!ids||ids.includes(seat.id)).map(seat=>seat.id),given=entryInPhrase(entry,{bar,bars,meter:exposition.meter});
      const {given:_,...like}=formation.pools.find(pool=>pool.seats?.some(id=>theirs.includes(id)))??formation.pools[0];
      const texture=given.length?'line':bar<entry.fromBar||Number.isFinite(exposition.free)?'tacet':'line';
      const octave=given.length?this.voiceOctave(entry,theirs,seats):null;
      return {...like,id:`voice ${entry.voice+1}`,texture,seats:theirs,parts:theirs.map(()=>0),...(given.length?{given}:{}),...(octave!=null?{givenOctave:octave}:{}),...(ids?{only:theirs}:{})};
    });
    return {...formation,pools};
  }
  // A fugue voice's octave for some of a section's seats (section-voices.js givenShift; Astra's tracker CF32): its whole
  // material's span moved toward the middle of the compass those seats share, as far as keeps it within it -- once a
  // voice, the same in every phrase (each phrase's given notes moved alike: moved phrase by phrase, a line had leapt an
  // octave where its phrases met). -> semitones, or null where its seats share no compass.
  voiceOctave(entry,ids,seats){
    const pitches=['notes','counter','episode','final','free'].flatMap(list=>(entry[list]??[]).map(note=>Number(note.pitch))).filter(Number.isFinite);
    // (In the compass its players play a voice in: string-section.js playingCompass, its comfortable register's top.)
    const theirs=seats.filter(seat=>ids.includes(seat.id)&&Number.isFinite(seat.low)&&Number.isFinite(seat.high)).map(seat=>playingCompass(seat));
    if(!pitches.length||!theirs.length)return null;
    const compass={low:Math.max(...theirs.map(seat=>seat.low)),high:Math.min(...theirs.map(seat=>seat.high))};
    return compass.high>compass.low?givenShift([Math.min(...pitches),Math.max(...pitches)],{centre:(compass.low+compass.high)/2,compass}):null;
  }
  // A section's formations said, each from its bar, for its players: once, and again where asked (each phrase).
  sayFormations(unit,{again=false}={}){
    const {kind,spec}=this.section,decided=unit.layers?.formation;if(!Array.isArray(decided))return;
    for(const entry of decided){
      if(entry.bar+entry.bars<=(this.lastBar??0)||!entry.formation)continue;
      // (Its section's meter for this section of the form, its parent's to give: a stream its seats count, or the band's.)
      const meter=this.nested?this.parentPlan?.payload?.units?.find(item=>item.index===unit.index)?.layers?.meters?.[this.groupId]??null:undefined;
      const plan={group:this.groupId,leader:this.selfId,parent:this.parentGroup,kind:kind.id,size:spec.size,appliesAt:{bar:entry.bar},bars:entry.bars,
        move:entry.move,final:entry.final,formation:entry.formation,summary:entry.summary,
        ...(meter!==undefined?{stream:meter?streamOfMeter(meter,unit.startBar):null}:{})};
      const said=JSON.stringify(plan);if(this.formationsSaid.get(entry.bar)===said&&!again)continue;
      const first=!this.formationsSaid.has(entry.bar);this.formationsSaid.set(entry.bar,said);
      while(this.formationsSaid.size>256)this.formationsSaid.delete(this.formationsSaid.keys().next().value);
      this.broadcast('group/formation',[plan]);
      // (And a figuration of it said for the others to take after, once, as its formation is first said.)
      const figured=first&&entry.formation.pools?.find(pool=>pool.texture==='figuration'&&pool.parameters);
      if(figured)this.broadcast('figure',[figurePayload(this.groupId,figured.parameters,entry.bar)]);
      // (A bowed tremolo, its amount the share of its held notes that tremble, said as the figure's one-tone corner.)
      const trembling=first&&!figured?Math.max(0,...(entry.formation.pools??[]).map(pool=>Number(pool.tremolo)||0)):0;
      if(trembling>0)this.broadcast('figure',[figurePayload(this.groupId,oneToneFigure(trembling),entry.bar)]);
      if(first){const said={bar:entry.bar,move:entry.move,summary:entry.summary};this.audio?.report?.("formation",said);this.decide?.({formation:said})}
    }
  }
  // A canon for a section where the form develops (PLEX_CLODBOT), planned a phrase before it from the harmony heard then:
  // its subject drawn from that collection in the section's meter, its voices entering a bar apart, in its form
  // (PLEX_CLODBOT.canonForm: at the inversion, by augmentation, or subject and answer). -> the layer's
  // decision (its voices), its notes kept to be said as each part's plan; null where the section has none.
  planCanon(unit){
    const {canonRoles,canonBars,canonRegister}=PLEX_CLODBOT,s=unit.value;
    if(this.canonParts.length<2||!canonRoles.includes(s.role))return null;
    // (From the harmony heard; before any is heard -- a section in the piece's first phrase, planned before its first
    // bar -- from the piece's opening, which the band begins in.)
    const opening=this.bandOpening,heard=this.poolHeard?this.notes:collectionPitches(opening.collection,{tonic:opening.tonic,low:canonRegister.low,high:canonRegister.high});
    const collection=[...new Set(heard.map(Number).filter(Number.isFinite))];
    const classes=new Set(collection.map(p=>Math.round((((p%12)+12)%12)*1e6))).size;if(classes<3)return null;
    const bar=s.numerator*4/s.denominator,bars=Math.max(1,Math.min(canonBars,s.bars-(this.canonParts.length-1)));
    // (Every other voice its answer, as many of the collection's degrees up as its rules count perfect: counterpoint.js
    // perfectDegrees, drawn.)
    const answers=perfectDegrees(collection),answer=answers[Math.floor(unitRandom()*answers.length)]??1;
    // (Its form drawn: at the inversion, by augmentation, or subject and answer.)
    const {most,augmentation}=PLEX_CLODBOT.canonForm,inverts=most*unitRandom()**2,augments=most*unitRandom()**2;
    let form=unitRandom()<inverts?'inversion':unitRandom()<augments?'augmentation':'answer';
    const voices=this.canonParts.map((part,k)=>({part,delay:k*bar,...(k%2?form==='inversion'?{invert:true}:form==='augmentation'?{augmentation}:{steps:answer}:{transpose:-12*Math.floor(k/2)})}));
    // (A round as often as its share (canonForm.round), drawn from a stream of its own so the draws after it are as they
    // were: never by augmentation, whose voices' periods differ; its subject a bar a voice, room for two cycles each.)
    const {round:roundMost,roundBars}=PLEX_CLODBOT.canonForm,roundDraw=seededSource(Number(this.ensembleSeed)>>>0,`canon:${unit.index}:round`);
    const asRound=form!=='augmentation'&&roundDraw()<roundMost*roundDraw()**2&&voices.length<=roundBars&&2*voices.length+voices.length-1<=s.bars;
    const length=asRound?voices.length:bars;
    // (A round's voices sing its one line, in octaves, as a round's do: with its subject a bar a voice, every two of its
    // bars sound together in each voice's turn, so planning it against its later voices reads all its pairs but its joins.)
    if(asRound){form='octave';for(const [k,voice] of voices.entries()){delete voice.invert;delete voice.steps;voice.transpose=-12*Math.floor(k/2)}}
    // (Its subject planned to sound against its own later voices under a counterpoint of its own: counterpoint.js.)
    const counterpoint=drawnRules(unitRandom,{rigor:this.rigor,voices:voices.length,classes});
    let subject;try{subject=plannedSubject({collection,register:canonRegister,groups:s.groups,numerator:s.numerator,denominator:s.denominator,bars:length,random:unitRandom,voices,rules:counterpoint.rules,...(asRound?{cycle:length*bar}:{})})}catch{return null}
    // (A round sung where it is chosen, its subject planned with its joins: each voice as many whole cycles as end
    // within its section, where every voice has two or more (round-plan.js roundCycles); else its subject sung once, a
    // canon. Whether it holds whole is checked in development: round-plan.js roundHolds.)
    const total=(unit.endBar-unit.startBar)*bar,period=length*bar;
    const cycles=asRound?roundCycles({delays:voices.map(voice=>voice.delay),period,total}):null,sung=Boolean(cycles?.every(count=>count>=2));
    this.canonNotes.set(unit.index,canonParts({subject,voices,startBar:unit.startBar,endBar:unit.endBar,collection,...(sung?{period,cycles}:{}),
      units:[{startBar:unit.startBar,endBar:unit.endBar,numerator:s.numerator,denominator:s.denominator,subdivision:s.subdivision}]}));
    return {voices,bars:length,form,notes:subject.length,counterpoint:{strictness:counterpoint.strictness},rigor:this.rigorPolicy,
      ...(cycles?{round:{sung,cycles}}:{})};
  }
  // Each voice of a section's canon said as its part's plan (kind 'part'), which the part plays as written
  // (bots/lib/modules/part-plans.js); said again, revised, where the canon is planned again.
  sayCanon(unit,clock){
    const planned=this.canonNotes.get(unit.index);if(!unit.layers.canon||!planned)return;
    const bar=Number(clock?.bar)||0;
    for(const part of planned){
      if(!part.notes.length)continue;
      const key=`${unit.index}:${part.voice}`,payload={schemaVersion:1,group:this.groupId,section:unit.index,...part};
      const options={createdAt:{bar:Math.min(bar,part.fromBar),phrase:0,section:0},appliesAt:{bar:part.fromBar,phrase:0,section:0},expiresAt:{bar:Math.max(part.toBar,part.fromBar+1),phrase:0,section:0},
        horizon:1,confidence:.7,priority:.7,rationale:`Voice ${part.voice+1} of a canon of ${planned.length} in section ${unit.index} (${unit.value.role}): ${part.invert?'its inversion':part.augmentation>1?`its augmentation, ${part.augmentation} times as slow`:part.steps?`a tonal answer, ${part.steps} degrees up`:part.transpose?`${part.transpose} semitones`:'the subject'}, ${part.delay} quarters after it.`};
      const before=this.canonSaid.get(key),plan=before?this.plans.revise(before,payload,options):this.preparePlan('part',payload,options);
      this.canonSaid.set(key,plan);this.announcePlan(plan);
    }
  }
  // Its fugues' voices, each said as a part plan (kind 'part') to the section that plays it (payload.part; payload.fugue
  // the voice, payload.seats those of the section's seats that play it, where not all): said before the piece plan that
  // names them, which carries each fugue without its voices (publishPiece) -- a fugue of two hundred voices is some forty
  // thousand values, past what one plan holds (planning.js), and each of its voices a few hundred. Said again, revised,
  // where a voice changed (its cadence into a hit: fugueInto).
  sayFugues(clock){
    const bar=Number(clock?.bar)||0;
    for(const unit of this.planner.units){
      const fugue=unit.layers.fugue;if(!fugue?.entries?.length||unit.endBar<=bar)continue;
      // (A re-orchestrated return: each part's return the voice's it now plays -- the voice whose sections the return
      // turned to it: returnOrchestration.)
      const byGroup=new Map(fugue.entries.map(entry=>[String(entry.group),entry])),returnOf=group=>Object.entries(fugue.returnBy??{}).find(([,to])=>to===group)?.[0]??group;
      // (Its own free counterpoint kept only before the return it now plays begins: one line at a time.)
      const order=note=>note.bar*1e6+note.pulse,freeBefore=(free,final)=>{const from=final.length?Math.min(...final.map(order)):Infinity;return free.filter(note=>order(note)<from)};
      for(const entry of fugue.entries)for(const part of fugue.orchestration?.[entry.group]??[{group:entry.group,seats:null}]){
        const returning=byGroup.get(returnOf(String(entry.group)))??entry;
        // (A doubling section's lines its voice's moved by its interval in the fugue's collection: orchestration.js doubled.)
        const moved=list=>part.steps&&fugue.collection?.length?list.map(note=>({...note,pitch:+stepInCollection(note.pitch,part.steps,fugue.collection).toFixed(6)})):list;
        const key=`${unit.index}:${entry.group}:${part.group}`,payload={schemaVersion:1,group:this.groupId,section:unit.index,part:part.group,fugue:entry.group,
          ...(part.seats?{seats:part.seats}:{}),voice:entry.voice,steps:entry.steps??0,...(part.steps?{doubling:part.steps}:{}),fromBar:entry.fromBar,toBar:entry.toBar,
          notes:moved(entry.notes),counter:moved(entry.counter??[]),episode:moved(entry.episode??[]),final:moved(returning.final??[]),free:moved(returning===entry?entry.free??[]:freeBefore(entry.free??[],returning.final??[])),
          ...(returning!==entry?{returnOf:String(returning.group)}:{})};
        const said=JSON.stringify(payload),held=this.fugueSaid.get(key);if(held?.said===said)continue;
        const options={createdAt:{bar:Math.min(bar,unit.startBar),phrase:0,section:0},appliesAt:{bar:unit.startBar,phrase:0,section:0},expiresAt:{bar:unit.endBar,phrase:0,section:0},
          horizon:1,confidence:.7,priority:.7,rationale:`Voice ${entry.voice+1} of a fugue of ${fugue.entries.length} in section ${unit.index}, played by ${part.group}${part.seats?` (${part.seats.length} of its seats)`:''}.`};
        let plan;try{plan=held?this.plans.revise(held.plan,payload,options):this.preparePlan('part',payload,options)}
        catch(error){this.decide?.({fugueVoice:{unit:unit.index,voice:entry.group,section:part.group,refused:String(error?.message??error)}});continue}
        this.fugueSaid.set(key,{said,plan});this.announcePlan(plan);
      }
    }
  }
  publishPiece(clock){
    // (Each fugue without its voices, which are said apart: sayFugues; and a section's formations without the lines given
    // its pools, which its seats hear in the formations said them -- a pool a voice of a fugue of two hundred, each its
    // notes -- each said as how many notes it has.)
    const say=(id,value)=>{
      if(id==='fugue'&&value?.entries){const {entries,orchestration,...rest}=value;return {...rest,voices:entries.length}}
      if(id==='formation'&&Array.isArray(value))return value.map(entry=>entry.formation?.pools?.some(pool=>pool.given)?{...entry,formation:{...entry.formation,
        pools:entry.formation.pools.map(({given,...pool})=>given?{...pool,givenNotes:given.length}:pool)}}:entry);
      return value;
    };
    const bar=Number(clock?.bar)||0,payload=this.planner.payload({fromBar:bar,group:this.groupId,conductor:this.instanceId??null,say});
    const options={createdAt:{bar,phrase:0,section:0},appliesAt:{bar:Math.max(bar,this.planner.startBar),phrase:0,section:0},
      expiresAt:{bar:Math.max(bar+1,this.planner.through('form'),this.planner.endBar??0),phrase:0,section:0},horizon:Math.max(1,payload.units.length),
      confidence:.8,priority:.72,rationale:`The piece as planned ${describeHorizon(this.horizon)} ahead${payload.complete?', to its end':''}.`};
    this.piecePlan=this.piecePlan?this.plans.revise(this.piecePlan,payload,options):this.preparePlan('piece',payload,options);
    this.announcePlan(this.piecePlan);
  }
  // The form plan other bots read (ManageBOT's sections, MemoryBOT's returns, the form's progress): the sections
  // committed, in mh_PlexBOT's form.
  publishForm(clock){
    const sections=this.planner.units.filter(unit=>!unit.value.standIn).map(unit=>{const {bars,barSeconds,last,...section}=unit.value;return {...section,id:unit.index}});
    // (Said again only where its sections changed: decided, redrawn, or dropped by a stimulus.)
    const signature=JSON.stringify([sections,this.planner.ended]);if(signature===this.formSaid)return;this.formSaid=signature;
    this.form=sections;
    const grammar=this.grammar??defaultPlexGrammar(CONFIG.plex),bar=Number(clock?.bar)||0,start=this.planner.startBar;
    const payload={schemaVersion:1,archetype:this.sketch?.name??null,sections,grammar,...(this.planner.ended?{}:{sketch:this.sketch?.roles.slice(sections.length)??[]})};
    const phrases=sections.reduce((sum,section)=>sum+section.phrases,0),end=this.planner.through('form');
    const options={createdAt:{bar:Math.min(bar,start),phrase:0,section:0},appliesAt:{bar:start,phrase:0,section:0},
      expiresAt:{bar:end,phrase:phrases,section:sections.length},horizon:Math.max(1,phrases),confidence:.76,priority:.7,
      rationale:'The form as committed so far: each section\'s metric and tempo articulation.'};
    this.formPlan=this.formPlan?this.plans.revise(this.formPlan,payload,options):this.preparePlan('form',payload,options);
    // (And, while the piece is not all decided, the roles still to come and how long it expects the piece: a bot that
    // must lay out its part before the first sound -- the tape -- plans on them where the form is not yet decided.)
    const expected=this.planner.ended?{}:{sketch:payload.sketch,expected:{bars:Math.round(this.estimate()),seconds:round(this.expectedSeconds(payload.sketch))}};
    this.broadcast('form',[{version:2,archetype:payload.archetype,sections,grammar:grammar.id,...expected}]);
    this.announcePlan(this.formPlan);
  }

  // ---- Carrying it out --------------------------------------------------------------------------------------------
  // How many bars ahead a section is handed over (PLEX_CLODBOT.handoverSeconds in the bar playing): one where bars are long.
  leadBars(clock){
    const barSeconds=secondsPerTick(clock)*(Number(clock?.meter?.pulsesPerBar)||16);
    return Math.max(1,Math.ceil(PLEX_CLODBOT.handoverSeconds/Math.max(1e-3,barSeconds)-1e-9));
  }
  sectionMeter(section){
    // (Its grouping in the meter too, so the transport counts the bar as the section groups it.)
    return {numerator:section.numerator,denominator:section.denominator,subdivision:section.subdivision,groups:[...section.groups],phraseBars:section.phraseBars,rhythm:section.rhythm};
  }
  // The section's meter and tempo to the transport: at the opening before the first pulse, else for its bar, as far
  // ahead as a networked room needs (leadBars), its contingencies taken first.
  handOver(unit,when,clock=this.currentClock??{bar:unit.startBar-1}){
    if(this.handed.has(unit.index))return;
    this.handed.add(unit.index);this.planner.lock(unit.startBar+1);
    if(this.takeContingencies(unit,clock))this.sayPlan(clock);
    const section=unit.value;
    // (Following a performer, none of its own: the band's tempo and meter are the performer's -- but until it hears their
    // bar, its opening section's, a bar it can count theirs from a few seconds after it hears it (followHeardMeter), not
    // after one of a seed's long bars -- a band following a guitarist had opened in its transport's 31/6, fifteen seconds
    // a bar.)
    // (A felt bar the band already counts -- a meter it was told, a take's -- it keeps, where its beat is one the follower
    // can hold to theirs at an octave: a power of two's. In an irrational meter -- sixths, tenths -- the band's beats fall
    // at 2:3 or 4:5 against the performer's, and correcting its phase beat by beat swung its tempo a fifth each way: a
    // band following a guitarist at 68 in its seed's 31/6 had beaten between 90 and 120. Its own, its beat a power of two's.)
    const counted=clock?.meter?.pulsesPerBar?clock.meter.pulsesPerBar*secondsPerTick(clock):Infinity,binary=d=>Number.isInteger(Math.log2(Number(d)));
    // (And no longer than a bar is felt at the tempo it opens at: its opening groups, from the first, as many as fit
    // FELT_TEMPO.longestBarSeconds -- the band can hand over to their bar only at its own bar line, and following a
    // guitarist at 68 its opening 3+2+2+3+3+3/16 had run seven seconds a bar, the band counting it until 15 s into the
    // take. Its rhythm's hits in proportion. The clock's bpm counts its meter's own note.)
    if(this.followsPerformer&&when==='opening'&&!this.meterFollowed&&!(counted<=FELT_TEMPO.longestBarSeconds&&binary(clock?.meter?.denominator))){
      const own=this.sectionMeter(this.ownOpening??section),note=60/Math.max(1e-6,Number(clock?.bpm)||Number(section.tempo?.targetBpm)||bandTempo()),groups=[];
      for(const group of own.groups?.length&&own.groups.reduce((sum,g)=>sum+g,0)===own.numerator?own.groups:[own.numerator])if(!groups.length||(groups.reduce((sum,g)=>sum+g,0)+group)*note<=FELT_TEMPO.longestBarSeconds+1e-9)groups.push(group);else break;
      const numerator=groups.reduce((sum,g)=>sum+g,0),rhythm=own.rhythm&&numerator<own.numerator?{...own.rhythm,hits:Math.max(1,Math.round((Number(own.rhythm.hits)||0)*numerator/own.numerator))}:own.rhythm;
      this.broadcast('timeSignature',[{...own,numerator,groups,...(rhythm?{rhythm}:{}),denominator:binary(own.denominator)?own.denominator:2**Math.round(Math.log2(own.denominator))},when]);
    }
    if(!this.followsPerformer){
      this.broadcast('timeSignature',[this.sectionMeter(section),when]);
      this.broadcast('tempoCurve',[section.tempo,when]);this.tempoSent(section.tempo,when,clock);
    }
    if(when==='opening')this.cue(unit);
  }
  // The section's cue, the bar before it as mh_PlexBOT says it (or at its first bar, where ticks skipped past that): its
  // number, grouping, phrase length and densities, which the players take as they hear them.
  cue(unit){
    if(this.cued.has(unit.index))return;
    this.cued.add(unit.index);
    const section=unit.value;
    this.broadcast('section',[unit.index,this.planner.ended?this.planner.units.length:Math.max(this.planner.units.length,this.sketch?.roles.length??0)]);
    this.broadcast('tala',section.groups);
    this.broadcast('phraselength',[section.phraseBars]);
    this.broadcast('phrases',[section.phrases]);
    this.broadcast('hdensity',[section.hdensity]);
    this.broadcast('vdensity',[section.vdensity]);
  }
  // A section's meter as the transport keeps it, seen in its first bar: where it has not come (a networked room that
  // could not agree it in time, a window it met another's in, a primary handed over), asked for once more, for the
  // first bar the room can. (A transport refuses it where the meter is already on its way.)
  verify(clock){
    if(this.followsPerformer)return;
    const bar=Number(clock.bar)||0,unit=this.planner.unitAt(bar),meter=clock.meter;
    if(!unit||!meter||!this.handed.has(unit.index)||this.verified.has(unit.index)||bar<unit.startBar)return;
    this.verified.add(unit.index);
    const s=unit.value;
    if(Number(meter.numerator)===s.numerator&&Number(meter.denominator)===s.denominator&&(meter.groups??[]).join('+')===s.groups.join('+'))return;
    this.broadcast('timeSignature',[this.sectionMeter(s),'nextBar']);
    this.noteStimulus({kind:'meter-late',fromBar:unit.startBar,reason:`section ${unit.index}'s ${s.numerator}/${s.denominator} not in force at bar ${bar}: asked again`},clock);
  }
  // Before the first pulse: the plan begun, and its first section in force from the start.
  onPrepare(clock={bar:0,phrase:0,section:0,tick:0,meter:{phraseBars:4}}){
    if(this.begun||(clock.phrase||0)>0)return false;
    this.begun=true;this.startPlanning(clock,0);
    const conducts=this.conducts(clock);this.announceGroup(clock);
    if(!conducts)return false;
    this.plan(clock);
    if(this.nested)return false;
    // (Its harmony's first chord said as it prepares, so the band plans its first phrase in it, not in the seed's opening
    // alone: the opening settled before the first sound -- a harmony planned in another division (settings.division) had
    // the sections' first notes in the twelve.)
    if(Number.isInteger(clock.bar)&&clock.meter?.pulsesPerBar)this.sayHarmony(clock.tick??0,{...clock,tickInBar:clock.tickInBar??0});
    const first=this.planner.units[0];if(first)this.handOver(first,'opening',clock);
    return Boolean(first);
  }
  // The formation it said for the recalled section's phrase (the source's k-th phrase, its own formations again), its
  // pools' material traded where the recall's exchange draws: each pool drawn takes another's texture, seed, place and
  // material, that one its own. -> {formation (as said), exchanged (pools)}, or null where it said none.
  recalledFormation(recall,k,key){
    const source=this.planner.units.find(item=>item.index===recall.from)?.layers?.formation;
    if(!Array.isArray(source)||!source.length)return null;
    // (Its phrase the source's in turn, or, a section played backwards, from its last; in the recall's order, where it
    // drew one for as many phrases as the source said.)
    const turn=recall.backward?source.length-1-(k%source.length):k%source.length,index=recall.order?.length===source.length?recall.order[turn]:turn;
    const said=source[index]?.formation;if(!said?.pools?.length)return null;
    const draw=seededSource(Number(this.ensembleSeed)>>>0,`recall:${this.groupId}:${key}`),pools=said.pools.map(pool=>({...pool}));let exchanged=0;
    const traded=['texture','seed','centre','width','density','parameters','tremolo','material'];
    for(let i=0;i<pools.length;i++){
      if(pools.length<2||!(draw()<recall.exchange)||pools[i].texture==='tacet')continue;
      const j=(i+1+Math.floor(draw()*(pools.length-1)))%pools.length;if(pools[j].texture==='tacet')continue;
      const a=pools[i],b=pools[j],mine=Object.fromEntries(traded.map(key=>[key,key==='material'?a.material??a.id:a[key]])),theirs=Object.fromEntries(traded.map(key=>[key,key==='material'?b.material??b.id:b[key]]));
      Object.assign(a,theirs);Object.assign(b,mine);exchanged+=2;
    }
    // (And some taking another section's material for the same phrase: what it said there, kept as heard.)
    const sourceUnit=this.planner.units.find(item=>item.index===recall.from),phraseBars=Math.max(1,Number(sourceUnit?.value?.phraseBars)||bandPhraseBars());
    const bar=sourceUnit?sourceUnit.startBar+index*phraseBars:null;
    const others=bar==null?[]:[...(this.siblingFormations?.entries()??[])].map(([group,byBar])=>[group,byBar.get(bar)]).filter(([,formation])=>formation?.pools?.length);
    for(const pool of pools){
      if(!others.length||pool.texture==='tacet'||!(draw()<(recall.across??0)))continue;
      const [group,formation]=others[Math.floor(draw()*others.length)],playing=formation.pools.filter(other=>other.texture!=='tacet');if(!playing.length)continue;
      const theirs=playing[Math.floor(draw()*playing.length)];
      Object.assign(pool,Object.fromEntries(traded.map(key=>[key,key==='material'?theirs.material??theirs.id:theirs[key]])),{from:group});exchanged++;
    }
    // (Transformed as the return is: its lines augmented, inverted, and, as often as its share, the phrase's backwards --
    // each time through past its source further by its `vary`, a variation set.)
    const cycle=Math.floor(k/source.length),grow=1+cycle*Math.max(0,Number(recall.vary)||0);
    const augment=1+((Number(recall.augment)||1)-1)*grow,invert=Math.max(0,Math.min(1,(Number(recall.invert)||0)*grow)),backwards=draw()<Math.min(1,(Number(recall.retrograde)||0)*grow)||Boolean(recall.backward);
    for(const pool of pools){if(pool.texture!=='line')continue;
      if(augment>1.001)pool.elongation=+((Number(pool.elongation)||1)*augment).toFixed(3);
      if(invert>.001)pool.inversion=invert;
      if(backwards)pool.retrograde=true;}
    // (A return longer than its source, past its source's phrases: their continuation -- each phrase's formation and
    // harmony again, its pools' material made anew from their seeds and the time through (the 'never does' list, item 4's
    // Next: "a return longer than its source").)
    if(cycle>0)for(const pool of pools)if(pool.texture!=='tacet'&&pool.seed!=null)pool.seed=typeof pool.seed==='number'?pool.seed+7919*cycle:`${pool.seed}:${cycle}`;
    return {formation:{...said,pools:pools.map(pool=>Object.fromEntries(Object.entries(pool).filter(([,value])=>value!==undefined)))},exchanged,augment,invert,retrograde:backwards,...(cycle>0?{continued:cycle}:{})};
  }
  // How far the section's textures lean toward the tape's sound over the phrase at `bar`, `bars` long (PLEX_CLODBOT
  // imitateTape): the tape's event overlapping it most, by its kind's leanings and the piece's share. -> {texture: factor}
  // or null where the tape says nothing there.
  tapeLean(bar,bars){
    const {gain,kinds,leanings}=PLEX_CLODBOT.imitateTape,share=this.tapeShare;
    if(!(share>0)||!this.tapeEvents?.length)return null;
    const from=this.secondsAtBar(bar),to=this.secondsAtBar(bar+bars);if(!Number.isFinite(from)||!Number.isFinite(to)||!(to>from))return null;
    let best=null,most=0;
    for(const event of this.tapeEvents){const kind=kinds[event.id]??(String(event.material??'').startsWith('capture:')?'cloud':null);if(!kind)continue;
      const overlap=Math.min(to,event.start+event.seconds)-Math.max(from,event.start);if(overlap>most){most=overlap;best=kind}}
    if(!best)return null;
    return Object.fromEntries(Object.entries(leanings[best]).map(([texture,weight])=>[texture,+(1+gain*share*weight).toFixed(3)]));
  }
  // The tape's material over the phrase at `bar`, `bars` long (the 'never does' list, item 9's Next: "the imitation in
  // the material too (a section's pitches and contours from the tape's), not only its texture"): the pitched event
  // overlapping it most -- its pitch, and its contour's slope (its last clear pitch less its first, semitones) -- or null.
  tapeMaterial(bar,bars){
    if(!(this.tapeShare>0)||!this.tapeEvents?.length)return null;
    const from=this.secondsAtBar(bar),to=this.secondsAtBar(bar+bars);if(!Number.isFinite(from)||!Number.isFinite(to)||!(to>from))return null;
    let best=null,most=0;
    for(const event of this.tapeEvents){if(!Number.isFinite(event.pitch))continue;const overlap=Math.min(to,event.start+event.seconds)-Math.max(from,event.start);if(overlap>most){most=overlap;best=event}}
    if(!best)return null;const clear=(best.contour??[]).filter(Number.isFinite);
    // (And its onsets in the phrase, for a line's motif to take its rhythm and steps from (the 'never does' list, item 9's
    // Next: "a line's motif taken from the tape's (its rhythm of onsets too)"): each sound beginning within it, in bars
    // from the phrase's downbeat (its line reads them in its own meter), at its pitch, an unpitched one at the pitch
    // before it.)
    const bar1=(to-from)/bars;let last=best.pitch;
    const onsets=this.tapeEvents.filter(event=>event.start>=from-1e-9&&event.start<to-1e-9).sort((a,b)=>a.start-b.start)
      .map(event=>{if(Number.isFinite(event.pitch))last=event.pitch;return {at:+((event.start-from)/bar1).toFixed(5),pitch:last}});
    return {pitch:best.pitch,slope:clear.length>=2?clear.at(-1)-clear[0]:0,...(onsets.length>=2?{onsets}:{})};
  }
  // How far its section's figurations take after the others' it hears: a spec's settings.inspiration, else drawn once a
  // piece (the players' own share: figuration.js inspiredFigure).
  get inspiration(){
    const asked=this.inspirationAsked;
    return Number.isFinite(asked)?asked:this.inspirationDrawn??=+seededSource(Number(this.ensembleSeed)>>>0,`inspiration:${this.groupId}`)().toFixed(3);
  }
  // The piece's share of imitating the tape: a spec's settings.imitateTape, else drawn once a piece.
  get tapeShare(){
    const asked=this.imitateTapeAsked,[low,high]=PLEX_CLODBOT.imitateTape.share;
    return Number.isFinite(asked)?asked:this.tapeShareDrawn??=+(low+(high-low)*seededSource(Number(this.ensembleSeed)>>>0,'imitate-tape')()).toFixed(3);
  }
  // A bar's time (s) from the piece's start, by its sections' bars at their tempi (a section's own curves and rubato
  // aside): the tape's clock, as it reads the form.
  secondsAtBar(bar){
    let at=0;for(const unit of [...this.planner.units].sort((a,b)=>a.startBar-b.startBar)){
      const each=Number(unit.value?.barSeconds);if(!(each>0))return NaN;
      if(bar<unit.endBar)return at+Math.max(0,bar-unit.startBar)*each;at+=(unit.endBar-unit.startBar)*each;
    }
    return at;
  }
  // Its section's solo for the phrase at `bar`: of its pools playing, one drawn, and of its sections one drawn, whose front
  // chair plays a line alone, its level raised and its own rubato freer, the others resting through it (the attention a
  // soloist is given: docs/ATTENTION.md). -> {formation, seat} or null where nothing plays.
  soloFormation(formation,seats,bar,register=null,raised=PLEX_CLODBOT.solo.raise){
    const playing=formation.pools.filter(pool=>pool.texture!=='tacet'&&pool.seats?.length);if(!playing.length)return null;
    const draw=seededSource(Number(this.ensembleSeed)>>>0,`solo:${this.groupId}:${bar}`);
    // (Where its conductor said a register, the section whose players' compass holds it, else lies nearest it, its pool
    // too; else one drawn.)
    const away=seat=>register==null?0:Math.max(0,(seat.register?.[0]??register)-register,register-(seat.register?.[1]??register));
    const candidates=playing.flatMap(pool=>[...new Set(seats.filter(seat=>pool.seats.includes(seat.id)).map(seat=>seat.section))].map(section=>({pool,section,away:Math.min(...seats.filter(seat=>seat.section===section&&pool.seats.includes(seat.id)).map(away))})));
    const nearest=Math.min(...candidates.map(item=>item.away)),fitting=candidates.filter(item=>item.away<=nearest+1e-9);
    const {pool,section}=fitting[Math.floor(draw()*fitting.length)];
    const ofPool=seats.filter(seat=>pool.seats.includes(seat.id));
    const seat=ofPool.filter(item=>item.section===section).sort((a,b)=>(a.chair??1)-(b.chair??1))[0];if(!seat)return null;
    const {rubato,width}=PLEX_CLODBOT.solo,raise=raised,way=draw()<.5?-1:1;
    const [low,high]=seat.register??[register??pool.centre,register??pool.centre],centre=register==null?pool.centre:+Math.max(low+width/2,Math.min(high-width/2,register)).toFixed(3);
    const solo={...pool,id:`${pool.id}:solo`,seats:[seat.id],parts:[0],texture:'line',playing:1,level:+Math.min(1,(Number(pool.level)||.5)+raise).toFixed(3),centre,...(register==null?{}:{width}),
      parameters:{...(pool.parameters??{}),rubato:+(way*rubato*(.5+.5*draw())).toFixed(4)}};
    // (Its pool last: said compactly, a pool names its sections, not its seats, so the soloist's chair is also in the pool
    // resting beside it, and a seat takes the last pool that holds it: string-section.js seatRoles.)
    return {formation:{...formation,pools:[...formation.pools.map(other=>other===pool?{...other,seats:other.seats.filter(id=>id!==seat.id),parts:other.parts.filter((_,i)=>other.seats[i]!==seat.id),texture:'tacet'}:{...other,texture:'tacet'}).filter(other=>other.seats.length),solo]},seat:seat.id};
  }
  // A section's pools under another section's solo, cleared out of its register together (solo-clearing.js
  // clearedTogether: Astra's EC05/EC09): each one's own clearing as clearOf has it, the pools on each side moving as a
  // block, each within its players' compass, the least its players weigh. -> {pool id: move (semitones)}, or null where
  // they cannot (each then cleared alone).
  clearingMoves(pools,seats,register){
    if(!Number.isFinite(register)||!pools.length||!pools.every(pool=>Number.isFinite(Number(pool.centre))))return null;
    const {width,clear:[least,most]}=PLEX_CLODBOT.solo,share=this.soloClear??=+(least+(most-least)*seededSource(Number(this.ensembleSeed)>>>0,'solo-clear')()).toFixed(3);
    return clearedTogether(pools.map(pool=>{
      const centre=Number(pool.centre),half=(Number(pool.width)||width)/2,overlap=Math.min(centre+half,register+width/2)-Math.max(centre-half,register-width/2);
      const mine=seats.filter(seat=>pool.seats?.includes(seat.id)),low=Math.min(...mine.map(seat=>seat.register?.[0]??centre)),high=Math.max(...mine.map(seat=>seat.register?.[1]??centre));
      return {id:pool.id,centre,half,weight:mine.length,low:low+half,high:high-half,clear:overlap>0?(centre>=register?1:-1)*share*overlap:0};
    }),register);
  }
  // A pool under another section's solo, cleared out of its register (PLEX_CLODBOT.solo): its band moved away from the
  // solo's by the piece's clear share of their overlap, within its players' compass. -> the pool.
  clearOf(pool,seats,register){
    if(!Number.isFinite(register)||!Number.isFinite(Number(pool.centre)))return pool;
    const {width,clear:[least,most]}=PLEX_CLODBOT.solo,share=this.soloClear??=+(least+(most-least)*seededSource(Number(this.ensembleSeed)>>>0,'solo-clear')()).toFixed(3);
    const centre=Number(pool.centre),half=(Number(pool.width)||width)/2,overlap=Math.min(centre+half,register+width/2)-Math.max(centre-half,register-width/2);
    if(!(overlap>0))return pool;
    const mine=seats.filter(seat=>pool.seats?.includes(seat.id)),low=Math.min(...mine.map(seat=>seat.register?.[0]??centre)),high=Math.max(...mine.map(seat=>seat.register?.[1]??centre));
    const moved=centre+(centre>=register?1:-1)*share*overlap;
    return {...pool,centre:+Math.max(low+half,Math.min(high-half,moved)).toFixed(3)};
  }
  // A section it leads asks its parent to rest those of a section's phrases its specification's `rest.ask` draws, and to
  // solo those its `solo.ask` draws (once a section of the form: requests.js restAsks, soloAsks), on the request
  // address, where it has asks to make.
  askRests(unit){
    if(!this.section||!this.nested||this.asked.has(unit.index))return;this.asked.add(unit.index);
    // (`unit` its parent's, as its plan says it: its fields its own, not under a value.)
    const {rest,solo}=this.section.spec.specification,phraseBars=unit.value?.phraseBars??unit.phraseBars,last=Boolean(unit.value?.last??unit.last);
    const rests=(rest?.ask??0)>0?restAsks({startBar:unit.startBar,endBar:unit.endBar,phraseBars,last,ask:rest.ask,joins:rest.joins!==false,
      draw:bar=>seededSource(Number(this.ensembleSeed)>>>0,`${this.groupId}:rest:${bar}`)()}):[];
    const solos=(solo?.ask??0)>0?soloAsks({startBar:unit.startBar,endBar:unit.endBar,phraseBars,last,ask:solo.ask,
      draw:bar=>seededSource(Number(this.ensembleSeed)>>>0,`${this.groupId}:solo:${bar}`)()}):[];
    if(rests.length||solos.length)this.broadcast('group/request',[{group:this.groupId,parent:this.parentGroup,from:this.selfId,unit:unit.index,appliesAt:{bar:unit.startBar},
      ask:{...(rests.length?{rest:rests}:{}),...(solos.length?{solo:solos}:{})},why:[rests.length?'to rest these phrases, the others playing':null,solos.length?'to solo these, the others receding':null].filter(Boolean).join('; ')}]);
  }
  // Its children's asks, granted together (requests.js grantRests), so that enough of them play: a layer of the section
  // asked about (rests: {bar: [groups]}), said in its plan's next revision.
  grantRequests(){
    // (And its children's meters for the sections not yet begun, once it knows them: assignMeters; then their fugues.)
    if(this.assignMeters())this.planner.revision++;
    if(this.assignFugues())this.planner.revision++;
    if(this.assignPunctuation())this.planner.revision++;
    const sections=this.tree.children(this.groupId).map(child=>child.id);let changed=false;
    // (The sections its breadth rests, once a section of the form has its constraints and its sections are known.)
    if(!this.nested&&sections.length>1)for(const unit of this.planner.units){
      if(unit.breadthRested||!unit.layers.constraints||unit.endBar<=(this.lastBar??0))continue;unit.breadthRested=true;
      const rests=breadthRests(unit,{sections,share:middle(unit.layers.constraints.players),draw:(group,bar)=>seededSource(Number(this.ensembleSeed)>>>0,`breadth:${bar}:${group}`)(),
        level:Array.isArray(unit.layers.constraints.level)?middle(unit.layers.constraints.level):null,loudness:group=>PLEX_CLODBOT.players.loudness[String(group).split(':')[0]]??0});
      if(Object.keys(rests).length){unit.layers.rests=mergeRests(rests,unit.layers.rests,sections);changed=true}
    }
    if(this.requestsHeard){this.requestsHeard=false;
      for(const unit of this.planner.units){
        const asked=[...this.requests.values()].filter(request=>request.unit===unit.index),asks=asked.filter(request=>request.ask.rest?.length).map(request=>({group:request.group,bars:request.ask.rest}));
        if(!asked.length||unit.granted)continue;unit.granted=true;
        const restsGranted=asks.length?grantRests(asks,{sections,rested:this.rested}):{};
        if(asks.length)unit.layers.rests=mergeRests(unit.layers.rests??{},restsGranted,sections);
        // (Its solos after its rests: one a phrase, never to a section granted the rest it asked for then; a section its
        // own breadth would rest plays its solo instead, a soloist over the few: its breadth's rest of it taken back.)
        const solos=grantSolos(asked.filter(request=>request.ask.solo?.length).map(request=>({group:request.group,bars:request.ask.solo})),{sections,soloed:this.soloed??=new Map,rests:restsGranted});
        if(Object.keys(solos).length){unit.layers.solos=solos;
          const [lowest,highest]=PLEX_CLODBOT.solo.register;
          unit.layers.soloRegisters=Object.fromEntries(Object.keys(solos).map(bar=>[bar,+(lowest+(highest-lowest)*seededSource(Number(this.ensembleSeed)>>>0,`solo-register:${bar}`)()).toFixed(2)]));
          // (Each solo's margin shared: its soloist's rise and the others' recession, by what each has given before.)
          const {raise,recede}=PLEX_CLODBOT.solo,given=this.soloGiven??=new Map;
          for(const [bar,group] of Object.entries(solos).sort((a,b)=>Number(a[0])-Number(b[0]))){
            const others=sections.filter(other=>other!==group&&!(unit.layers.rests?.[bar]??[]).includes(other)),shared=soloShares({soloist:group,others,raise,recede,history:given});
            if(!shared)continue;(unit.layers.soloShares??={})[bar]={raise:shared.raise,recede:shared.recede};sharedHistory(given,{soloist:group,others,raise:shared.raise,recede:shared.recede});
          }
          for(const [bar,group] of Object.entries(solos)){const rested=(unit.layers.rests?.[bar]??[]).filter(other=>other!==group);
            if(unit.layers.rests){if(rested.length)unit.layers.rests[bar]=rested;else delete unit.layers.rests[bar]}}}
        changed=true;
      }
    }
    if(changed)this.planner.revision++;
  }
  // A section of the form's latitude (PLEX_CLODBOT.latitude): how far the players it conducts may improvise on their lines,
  // drawn from the ensemble's seed within its role's range (settings.improvisation scaling it, or naming the range); a
  // layer of the section (latitude), which its sections give their lines phrase by phrase (licensed).
  latitudeFor(unit){
    const asked=this.improvisationAsked,roles=PLEX_CLODBOT.latitude,band=roles[unit.value?.role]??roles.other;
    const [low,high]=Array.isArray(asked)?asked.map(Number):band.map(value=>value*(asked==null?1:Number(asked)));
    return +(low+(high-low)*seededSource(Number(this.ensembleSeed)>>>0,`latitude:${unit.index}`)()).toFixed(3);
  }
  // A phrase's lines given their latitude (improvise.js): the section of the form's (its parent's layer, else its own),
  // drawn for the phrase between none and twice it, the same for all its lines; a soloist's half the way from that to
  // all, those under another's solo as much less as their level is told; the formation with its section's region
  // (harmony-plan.js: its collection's steps and period, and its tonic, said once), the scale its players' figures take.
  // None where the section has none.
  licensed(formation,{unit,parentUnit,bar,soloist}){
    const layers=(parentUnit??unit)?.layers,given=Number(layers?.latitude);if(!(given>0))return formation;
    const drawn=Math.min(1,2*given*seededSource(Number(this.ensembleSeed)>>>0,`latitude:${this.groupId}:${bar}`)()),region=layers?.harmony?.region??null;
    const mine=soloist===this.groupId?drawn+(1-drawn)/2:drawn;
    return {...formation,...(Array.isArray(region?.collection?.system)?{region:{system:region.collection.system,period:region.collection.period??12,tonic:region.tonic}}:{}),
      pools:formation.pools.map(pool=>pool.texture!=='line'?pool:{...pool,latitude:+(mine*Math.min(1,Number(pool.told)||1)).toFixed(3)})};
  }
  // Its sections' meters (group-meters.js): for each section of the form not yet begun, one of its children that counts
  // its own meter (a string, wind or brass section) in a meter of its own, where the draw gives one; a layer of that
  // section (meters: {group: meter}), which the child carries in its formations and its seats take as streams. Only where
  // it leads two sections or more, and decided once a section, from the ensemble's seed.
  assignMeters(){
    const sections=this.tree.children(this.groupId).map(child=>child.id).filter(id=>/^(strings|winds|brass):/.test(id));
    if(this.nested||this.tree.children(this.groupId).length<2||!sections.length)return false;
    let changed=false;
    for(const unit of this.planner.units){
      if(unit.layers.meters!==undefined||unit.value.standIn||unit.startBar<=(this.lastBar??0))continue;
      const given=this.adoptedLayers.get(unit.index);
      unit.layers.meters=given&&Object.hasOwn(given,'meters')?given.meters:groupMeters(unit.value,{bars:unit.endBar-unit.startBar,sections:[...sections].sort(),random:seededSource(Number(this.ensembleSeed)>>>0,`meters:${unit.index}`)});changed=true;
    }
    return changed;
  }
  // Its sections' fugues (fugue-plan.js): for each section of the form not yet begun whose role develops, where none of
  // its sections counts a meter of its own, an exposition among its children that play lines (string, wind and brass
  // sections), where the draw gives one; a layer of that section (fugue: {subject, bars, entries}, or null), which each
  // child reads as it plans its formations. Only where the sections it leads have two players or more -- one section's
  // seats may share its voices (orchestrate), a string orchestra's fugue its own -- decided once a section, from the
  // ensemble's seed, its subject from the section's planned harmony (else the harmony heard).
  // Its voices are not its sections: as many as settings.fugueVoices asks, else drawn between its sections and its seats
  // (orchestration.js voicesAt), each played by sections or by some of a section's seats (orchestrate), said with the
  // fugue (orchestration: {voice: [{group, seats}]}) where they are not its sections one for one.
  assignFugues(){
    const sections=this.tree.children(this.groupId).map(child=>child.id).filter(id=>FUGUE.kinds.test(id));
    if(this.nested||!sections.length)return false;
    const seatsOf=id=>{const [kind,size]=String(id).split(':');try{const section=sectionOf({kind,size});return section.kind.seatList(section.spec).map(seat=>seat.id)}catch{return []}};
    const listed=[...sections].sort().map(id=>({id,seats:seatsOf(id)})),players=listed.reduce((sum,section)=>sum+Math.max(1,section.seats.length),0);
    if(players<2)return false;
    // (Its sections' meters decided first where it decides them -- two sections or more, assignMeters -- else none.)
    const metered=this.tree.children(this.groupId).length>=2;let changed=false;
    for(const unit of this.planner.units){
      if(unit.layers.fugue!==undefined||metered&&unit.layers.meters===undefined||unit.value.standIn||unit.startBar<=(this.lastBar??0))continue;
      const random=seededSource(Number(this.ensembleSeed)>>>0,`fugue:${unit.index}`);changed=true;
      // (A document's fugue, or its having none, as it was decided.)
      const given=this.adoptedLayers.get(unit.index);if(given&&Object.hasOwn(given,'fugue')){unit.layers.fugue=given.fugue??null;continue}
      if(Object.keys(unit.layers.meters??{}).length||unit.value.last||!FUGUE.roles.includes(unit.value.role)||!(random()<this.fugueShare)){unit.layers.fugue=null;continue}
      const region=unit.layers.harmony?.region,collection=region?collectionPitches(region.collection,{tonic:region.tonic,low:FUGUE.register.low-12,high:FUGUE.register.high+12})
        :[...new Set((this.poolHeard?this.notes:[]).map(Number).filter(Number.isFinite))];
      const orchestrated=orchestrate({sections:listed,count:this.fugueVoicesFor(unit,listed.length,players)});
      // (Its subject and countersubject searched together as far as its planning affords: offline where it plans the piece
      // whole before it sounds, else live -- joint-fugue-theme.js jointFugueBudget.)
      unit.layers.fugue=fugueExposition({section:unit.value,startBar:unit.startBar,endBar:unit.endBar,groups:orchestrated.map(voice=>voice.id),collection,random,rigor:this.rigor,tonic:Number.isFinite(Number(region?.tonic))?Number(region.tonic):null,
        planning:{mode:this.horizon?.kind==='piece'?'offline':'live'},repetition:unit.layers?.repetition??this.repetitionAsked});
      if(unit.layers.fugue)unit.layers.fugue.rigor=this.rigorPolicy;
      // (A voice played by more than one section doubled in each after its first at an interval its rules make cheapest
      // in parallel, as often as a share drawn a fugue: orchestration.js doubled. Its own draws.)
      const drawDoubling=seededSource(Number(this.ensembleSeed)>>>0,`fugue-doubling:${unit.index}`),fugue=unit.layers.fugue;
      const voices=fugue?doubled(orchestrated,{collection,rules:blendRules(fugue.counterpoint.weights,fugue.counterpoint.strictness),share:this.doublingAsked??FUGUE_VOICES.doubling*drawDoubling()**2,random:drawDoubling}):orchestrated;
      if(fugue)fugue.collection=collection;
      // (And its return re-orchestrated as often as drawn a fugue: each voice's return played by another voice's
      // sections, the voices turned round.)
      const drawReturn=seededSource(Number(this.ensembleSeed)>>>0,`fugue-return:${unit.index}`),turned=fugue?returnOrchestration(fugue.entries.map(entry=>String(entry.group)),{share:this.reorchestrateAsked??FUGUE_VOICES.reorchestrate*drawReturn()**2,random:drawReturn}):null;
      if(turned)fugue.returnBy=turned;
      if(fugue&&voices.some(voice=>voice.parts.length!==1||voice.parts[0].seats||voice.parts[0].group!==voice.id))
        fugue.orchestration=Object.fromEntries(voices.map(voice=>[voice.id,voice.parts]));
    }
    return changed;
  }
  // How many voices a section of the form's fugue has, of its `sections` and `players`: settings.fugueVoices, else drawn
  // (its own draw, the ensemble's seed and the section's: the fugue's other draws as they were).
  fugueVoicesFor(unit,sections,players){
    const asked=this.fugueVoicesAsked,random=seededSource(Number(this.ensembleSeed)>>>0,`fugue-voices:${unit.index}`);
    if(asked==='seats')return players;
    if(Array.isArray(asked))return Math.min(players,Math.round(asked[0]+(asked[1]-asked[0])*random()));
    if(asked!=null)return Math.min(players,Math.round(Number(asked)));
    return voicesAt(random()**FUGUE_VOICES.dense,sections,players);
  }
  // Its sections' coordinated punctuation (PLEX_CLODBOT.punctuation; coordinated-events.js): for each section of the form
  // not yet begun but the last and that is no fugue, a hit on its last bar's downbeat, held, cut off together and a general pause after, as
  // often as the piece's share, decided once a section from the ensemble's seed; a layer of that section
  // (punctuation: {id, bar, beats, level, spread, placement}, or null), which each child reads as it plans its formations.
  // Only where it leads sections.
  assignPunctuation(){
    if(this.nested||!this.tree.children(this.groupId).length)return false;
    const {hold:[shortest,longest],level:[softest,loudest],spread:[tightest,loosest],placement}=PLEX_CLODBOT.punctuation,c=this.character;
    let changed=false;
    for(const unit of this.planner.units){
      if(unit.layers.punctuation!==undefined||this.gesturesPending?.has(unit.index)||unit.value.standIn||unit.startBar<=(this.lastBar??0))continue;
      const given=this.adoptedLayers.get(unit.index);changed=true;
      if(given&&Object.hasOwn(given,'punctuation')){unit.layers.punctuation=given.punctuation??null;continue}
      const random=seededSource(Number(this.ensembleSeed)>>>0,`punctuation:${unit.index}`),s=unit.value;
      // (A section counting a meter of its own meets the band's downbeat as its seats schedule it -- section-seat.js
      // dispatchOf, Astra's sharedAnchor; a fugue cadences into the hit, its voices' tails chosen together -- fugueInto,
      // Astra's cadenceInto -- or, where no cadence keeps its counterpoint, the section of the form ends unpunctuated.)
      if(s.last||unit.endBar-unit.startBar<2||!(random()<this.punctuationShare)){unit.layers.punctuation=null;continue}
      // (Held through the first of the bar's felt beats, as many as its share of them, on the meter's own grid (its notated
      // beats); no longer than every member sustains it to the cutoff -- a wind's one breath at the hit's dynamic, its
      // phrase's broadening besides (DC09: a gesture its players cannot prepare is not asked of them).)
      const level=+(softest+(loudest-softest)*random()).toFixed(3),groups=Array.isArray(s.groups)&&s.groups.length?s.groups.map(Number):[Number(s.numerator)||1];
      const held=this.sustainedBy(level),seconds=60/Math.max(1,Number(s.tempo?.targetBpm)||Number(this.currentClock?.bpm)||bandTempo())*(1+PLEX_CLODBOT.rubato.depth[1]);
      const felt=Math.max(1,Math.round((shortest+(longest-shortest)*random())*groups.length));
      // (And its general pause after it, to the bar's end, at least PLEX_CLODBOT.punctuation.space: the hold chosen so the
      // next section can still enter -- Astra's CFM-009, coordinated-events.js viableHold -- among its drawn felt beats and
      // then the meter's smaller levels, its notated beats and their halves down to its tick, in that order; where none
      // leaves its players a breath for the next entry, no hit -- the smallest had been asked whatever it left.)
      const whole=groups.reduce((a,b)=>a+b,0),beat=seconds/(1+PLEX_CLODBOT.rubato.depth[1]),sub=Math.max(1,Number(s.subdivision)||1);
      const holds=[];for(let f=felt;f>=1;f--)holds.push(groups.slice(0,f).reduce((a,b)=>a+b,0));
      for(let b=groups[0]-1;b>=1;b--)holds.push(b);for(let b=1/2;b>=1/sub-1e-9;b/=2)holds.push(b);
      const chosen=viableHold({holds,breath:held,beatSeconds:seconds,pauseBeatSeconds:beat,barBeats:whole,space:PLEX_CLODBOT.punctuation.space});
      if(chosen.status!=='VIABLE'){unit.layers.punctuation=null;continue}
      const beats=chosen.beats;
      const arrivals=unit.layers.fugue?this.fugueInto(unit,{bar:unit.endBar-1,beats:+beats.toFixed(4)}):{};
      if(!arrivals){unit.layers.punctuation=null;continue}
      const record={id:`punctuation:${unit.index}`,bar:unit.endBar-1,beats:+beats.toFixed(4),level,...(Object.keys(arrivals).length?{arrivals}:{}),
        spread:+((tightest+(loosest-tightest)*random())*(c?1-.5*c.mechanism:1)).toFixed(4),placement};
      // (Committed jointly before it is in the plan (gesture-commitment.js: Astra's EC18/DC10): proposed to every section,
      // each readying it; where they have not all by the time the section of the form begins, none.)
      if(!this.proposeGesture(unit,record,{beats,breath:held,beatSeconds:seconds,pauseBeatSeconds:beat,barBeats:whole,space:PLEX_CLODBOT.punctuation.space}))unit.layers.punctuation=null;
    }
    // (Those its sections did not all ready in time let go.)
    const now=Number(this.currentClock?.tick)||0;
    for(const [index,pending] of this.gesturesPending??[])if(now>=pending.commitBy){this.gestures?.advance(now);this.gesturesPending.delete(index);if(pending.unit.layers.punctuation===undefined)pending.unit.layers.punctuation=null;changed=true}
    return changed;
  }
  // A coordinated gesture proposed to its sections (gesture-commitment.js): its record, its hold's terms (its contract,
  // judged again at its commitment). Its ticks counted from the bar playing at its meter. -> whether it was proposed.
  proposeGesture(unit,record,hold){
    const sections=this.tree.children(this.groupId).map(child=>child.id).sort(),clock=this.currentClock??{},pulses=Number(clock.meter?.pulsesPerBar)||0;
    if(!sections.length||!(pulses>0))return false;
    const now=Number(clock.tick)||0,tickOf=bar=>now+(bar-(Number(clock.bar)||0))*pulses,membership=sections.join('|');
    // (One ledger for its sections as they are; sections joining or leaving, a new one for the gestures still to come.)
    if(this.gesturesFor!==membership){this.gesturesFor=membership;
      this.gestures=new GestureCommitments({id:`${this.groupId}:gestures:${membership}`,coordinator:{id:this.groupId,incarnation:String(this.selfId??this.groupId)},
        members:sections.map(id=>({id,incarnation:id})),capacity:this.planner.units.length,at:now})}
    this.gestures.advance(now);
    const commitBy=tickOf(unit.startBar),proposed=this.gestures.propose({planId:record.id,content:{...record,hold},firstActionAt:tickOf(record.bar),commitBy,validThrough:tickOf(unit.endBar),now});
    if(!proposed)return false;
    (this.gesturesPending??=new Map).set(unit.index,{unit,record,...proposed,commitBy});
    this.broadcast('group/gesture',[{parent:this.groupId,...proposed,gesture:record}]);
    return true;
  }
  // A section's readiness heard: its gesture committed once every section has said it, and then in the plan.
  gestureReady(value){
    const pending=[...(this.gesturesPending?.values()??[])].find(item=>item.planId===value.planId&&item.planHash===value.planHash);if(!pending||!this.gestures)return;
    const now=Number(this.currentClock?.tick)||0;
    if(this.gestures.accept({planId:pending.planId,planHash:pending.planHash,member:{id:value.group,incarnation:value.group},preparation:value.preparation??{},now})!=='APPLIED')return;
    if(this.gestures.commit({planId:pending.planId,planHash:pending.planHash,now})!=='COMMITTED')return;
    const unit=pending.unit;this.gesturesPending.delete(unit.index);
    unit.layers.punctuation=pending.record;if(unit.layers.harmony)unit.layers.harmony=this.heldThrough(unit,unit.layers.harmony);
    this.decide?.({punctuation:unit.layers.punctuation,committed:{members:this.gestures.members.length}});this.planner.revision++;
  }
  // A section's harmony held through its coordinated hit's bar (a hit is one sonority: its players let go of a note the
  // next chord leaves out, and a chord said mid-hit had cut half its players off early), from that bar's first felt
  // beat to its last. -> the harmony (a new one where it holds).
  heldThrough(unit,harmony){
    const at=unit.layers.punctuation?.bar;if(!harmony||!Number.isInteger(at))return harmony;
    const per=Number(harmony.beatsPerBar)||1,from=(at-unit.startBar)*per;
    return {...harmony,holds:[...(harmony.holds??[]).filter(span=>span.from!==from),{from,to:from+per}]};
  }
  // A fugue's voices cadencing into a coordinated hit at `bar`, held `beats` notated beats (fugue-cadence.js on Astra's
  // cadenceInto): each section's lines to a beat before it, then the tail chosen for it, every voice's together under
  // the fugue's counterpoint profile, into a tone of the harmony there; the exposition's lines rewritten so. -> {group:
  // its arrival's pitch}, or null where no cadence keeps the contract (UNSAT, or UNKNOWN: a harmony not yet planned).
  // Its notes removed and shortened as the cadence's audit names them, by their places in their lists, and only where
  // its lines still stand as they were when it was chosen -- the same fugue at the same revision, its section not yet
  // begun, every note named still there -- every voice's or none (Astra's handoff: SAT is no authority to cancel).
  fugueInto(unit,{bar,beats}){
    const fugue=unit.layers.fugue,harmony=unit.layers.harmony,meter=fugue?.meter;if(!fugue?.entries?.length||!harmony||!meter)return null;
    const perBar=meter.numerator*4/meter.denominator,perQuarter=meter.subdivision*meter.denominator/4,timeOf=note=>(note.bar-unit.startBar)*perBar+note.pulse/perQuarter;
    const lists=['notes','counter','episode','final','free'],anchor=(bar-unit.startBar)*perBar,hold=beats*4/meter.denominator,revision=fugue.revision??0;
    const notesOf=entry=>lists.flatMap(list=>(entry[list]??[]).map((note,k)=>({id:`${list}:${k}`,t:timeOf(note),d:Number(note.quarters)||0,pitch:Number(note.pitch)})));
    const voices=fugue.entries.map(entry=>({id:String(entry.group),notes:notesOf(entry).sort((a,b)=>a.t-b.t)}))
      .filter(voice=>voice.notes.length).sort((a,b)=>a.notes.reduce((s,n)=>s+n.pitch,0)/a.notes.length-b.notes.reduce((s,n)=>s+n.pitch,0)/b.notes.length);
    const {chord}=chordAt(harmony,(bar-unit.startBar)*(Number(harmony.beatsPerBar)||1));
    // (Its contract the fugue's counterpoint as its regime binds where it cadences (its drawn blend, as rigorous as it was
    // drawn: fugue-plan.js regimes); its steps the harmony's collection there, else the fugue's own pitches; its tails a
    // notated beat long; its chord's tones repeating at its harmony's period, where its plan says one, else an octave.)
    const cutAt=anchor-4/meter.denominator,regime=(fugue.regimes??[]).find(span=>cutAt>=span.from-1e-9&&cutAt<span.to-1e-9)??null;
    const rules=blendRules(fugue.counterpoint?.weights??'tonal',regime?.strictness??fugue.counterpoint?.strictness??1);
    const region=harmony.region,collection=region?collectionPitches(region.collection,{tonic:region.tonic,low:0,high:127}):lists.flatMap(list=>fugue.entries.flatMap(entry=>(entry[list]??[]).map(note=>Number(note.pitch))));
    const cadence=fugueCadence({voices,anchor,hold,chord:chord??[],rules,ladder:ladderOf(collection,{low:0,high:127}),window:4/meter.denominator,
      budget:cadenceBudget(this.afforded?.decisions??null),period:Number(harmony.period)>0?Number(harmony.period):12,owner:{id:`${this.groupId}:${unit.index}`,revision}});
    // (Its lines as they stand now: the same fugue, at the revision the cadence was chosen for, its section not begun, and
    // every note it removes or shortens where it was.)
    const said=new Map(voices.map(voice=>[voice.id,new Map(voice.notes.map(note=>[note.id,note]))]));
    const stands=cadence.status==='SAT'&&unit.layers.fugue===fugue&&(fugue.revision??0)===revision&&unit.startBar>(this.lastBar??-1)&&fugue.entries.every(entry=>{
      const chosen=cadence.tails[String(entry.group)];if(!chosen)return true;
      const now=new Map(notesOf(entry).map(note=>[note.id,note])),was=said.get(String(entry.group));
      return [...chosen.removed,...chosen.shortened.map(cut=>cut.id)].every(id=>{const a=now.get(id),b=was?.get(id);return a&&b&&Math.abs(a.t-b.t)<1e-9&&Math.abs(a.d-b.d)<1e-9&&a.pitch===b.pitch});
    });
    this.decide?.({fugueCadence:{unit:unit.index,bar,status:cadence.status,...(cadence.reason?{reason:cadence.reason}:{}),...(cadence.status==='SAT'&&!stands?{applied:false}:{})}});
    if(!stands)return null;
    // (Its lines rewritten as the audit names: the notes it removes gone, those it shortens to their ends; its tail after.)
    const at=t=>{const whole=Math.floor(t/perBar+1e-9);return {bar:unit.startBar+whole,pulse:Math.round((t-whole*perBar)*perQuarter)}};
    for(const entry of fugue.entries){
      const chosen=cadence.tails[String(entry.group)];if(!chosen)continue;
      const removed=new Set(chosen.removed),ends=new Map(chosen.shortened.map(cut=>[cut.id,cut.end]));
      for(const list of lists)if(Array.isArray(entry[list]))entry[list]=entry[list].flatMap((note,k)=>{const id=`${list}:${k}`;
        return removed.has(id)?[]:ends.has(id)?[{...note,quarters:+(ends.get(id)-timeOf(note)).toFixed(6)}]:[note]});
      entry.final=[...(entry.final??[]),...chosen.tail.map(note=>({...at(note.t),quarters:+note.d.toFixed(6),pitch:note.pitch}))];
    }
    fugue.revision=revision+1;
    // (Each section's arrival its voice's -- the voice whose return it plays, where its return was re-orchestrated -- the
    // first of its voices, where its parent orchestrated more than one there.)
    const arrivals={};
    for(const [voice,chosen] of Object.entries(cadence.tails)){const playing=fugue.returnBy?.[voice]??voice;for(const part of fugue.orchestration?.[playing]??[{group:playing}])arrivals[part.group]??=chosen.arrival}
    return arrivals;
  }
  // The longest its sections' players all hold one note at `level` (s): its winds' and brass's one breath (section-voices.js
  // breathHolds), its seats read from its children's kinds; Infinity where none breathes.
  sustainedBy(level){
    let least=Infinity;
    for(const child of this.tree.children(this.groupId)){
      const [kind,size]=String(child.id).split(':');let section;try{section=sectionOf({kind,size})}catch{continue}
      for(const seat of section?.kind.seatList(section.spec)??[])least=Math.min(least,breathHolds(seat.instrument,level));
    }
    return least;
  }
  // How rigorously it keeps a counterpoint's contract (0 to 1), and by whose permission (Astra's acceptance review, EC17
  // and EC23: a compromise is a musical permission said, never taken from compute alone): asked (settings.rigor, a share
  // or 'composed'); else by the owner's standing permission (2 October 2026: "budget might also influence willingness to
  // compromise; e.g., when improvisers play fugue-like textures, they're obviously not as rigorous as fully pre-composed
  // fugues"), as far as the decisions its budget affords reach PLEX_CLODBOT.rigor.decisions (horizon.js
  // affordablePlanning), all of it planning a whole piece ahead. -> {value, policy ('asked', 'composed' or 'afforded'),
  // decisions (afforded), authority}. Said with each fugue (its layer's rigor) and each canon.
  get rigorPolicy(){
    if(this.rigorAsked==='composed')return {value:1,policy:'composed',authority:'settings.rigor'};
    if(this.rigorAsked!=null)return {value:Number(this.rigorAsked),policy:'asked',authority:'settings.rigor'};
    return {value:this.afforded?Math.max(0,Math.min(1,this.afforded.decisions/PLEX_CLODBOT.rigor.decisions)):1,policy:'afforded',...(this.afforded?{decisions:this.afforded.decisions}:{}),
      authority:'the owner, 2 October 2026: an improviser compromises as its planning time allows'};
  }
  get rigor(){return this.rigorPolicy.value}
  // The piece's share of sections ended by a coordinated punctuation: a spec's settings.punctuation, else drawn once a
  // piece within PLEX_CLODBOT.punctuation.share.
  get punctuationShare(){const [low,high]=PLEX_CLODBOT.punctuation.share;return this.punctuationAsked??(this.punctuationDrawn??=+(low+(high-low)*seededSource(Number(this.ensembleSeed)>>>0,'punctuation')()).toFixed(3))}
  // A section's harmony (harmony-plan.js sectionHarmony): from the section before's, the piece's opening region its home.
  // Its elongation, drawn once a piece from the ensemble's seed within its range (settings.elongation).
  get elongation(){const [low,high]=this.elongationRange??[1,1];return this.elongationDrawn??=low===high?low:low*(high/low)**seededSource(Number(this.ensembleSeed)>>>0,'elongation')()}
  // A returning section's recall (PLEX_CLODBOT.recall): {from (the section it takes back), phrases (whether each of its
  // own is recalled), exchange}, or null.
  planRecall(unit){
    const {roles,exchange:[least,greatest],across:[nearest,farthest]}=PLEX_CLODBOT.recall,role=unit.value.role,range=roles[role]??(role==='establish'?null:roles.other);
    if(unit.value.standIn||!range)return null;
    const earlier=this.planner.units.filter(item=>item.index<unit.index&&!item.value.standIn),source=earlier.find(item=>item.value.role==='establish')??earlier[0];
    if(!source)return null;
    // (A return draws from the bot's own stream, as it always has; a section recalling within another, from a stream of
    // its own, so the draws after it are as they were.)
    const random=['return','complex-return'].includes(role)?unitRandom:seededSource(Number(this.ensembleSeed)>>>0,`recall:${unit.index}:within`),[fewest,most]=range;
    const share=fewest+(most-fewest)*Math.sqrt(random()),exchange=+(least+(greatest-least)*random()**2).toFixed(3);
    const phrases=Array.from({length:Math.max(1,Number(unit.value.phrases)||1)},(_,k)=>!(unit.value.last&&k===Math.max(1,Number(unit.value.phrases)||1)-1)&&random()<share);
    const across=+(nearest+(farthest-nearest)*random()**2).toFixed(3);
    const {augment:[shortest,longest],invert:[upright,inverted],remode:[kept,moded]}=PLEX_CLODBOT.recall;
    const augment=+(shortest+(longest-shortest)*random()**3).toFixed(3),invert=+(upright+(inverted-upright)*random()**3).toFixed(3),remode=+(kept+(moded-kept)*random()**3).toFixed(3);
    const [forward,backward]=PLEX_CLODBOT.recall.retrograde,retrograde=+(forward+(backward-forward)*random()**3).toFixed(3);
    // (And, as often as that share, the whole section backwards: its phrases from the last to the first, each a crab, its
    // harmony with them.)
    const reversed=random()<retrograde;
    // (And its phrases in an order of their own, as far as its `reorder` (the 'never does' list, item 4's Next: "a
    // section's phrases in a drawn order"): each of the source's phrases moved by that share of the section's length at
    // random, the phrases taken in the order they land -- every state between the source's order and any other. From a
    // stream of its own, so the draws after it are as they were.)
    const draw=seededSource(Number(this.ensembleSeed)>>>0,`recall:${unit.index}:order`),[asWas,whole]=PLEX_CLODBOT.recall.reorder,reorder=+(asWas+(whole-asWas)*draw()**3).toFixed(3);
    const n=Math.max(1,Number(source.value.phrases)||1),order=Array.from({length:n},(_,k)=>({k,at:k+reorder*n*draw()})).sort((a,b)=>a.at-b.at).map(item=>item.k);
    const reordered=order.some((k,i)=>k!==i);
    const [steady,growing]=PLEX_CLODBOT.recall.vary,vary=+(steady+(growing-steady)*draw()**3).toFixed(3);
    return phrases.some(Boolean)?{from:source.index,share:+share.toFixed(3),phrases,exchange,across,augment,invert,remode,retrograde,reorder,vary,...(reversed?{backward:true}:{}),...(reordered?{order}:{})}:null;
  }
  planHarmony(unit){
    if(unit.value.standIn)return null;
    const previous=this.planner.units[unit.index-1]?.layers?.harmony??null;
    // (Its chords drawn together, conditioned on its ends, where it plans the piece whole ahead: its time for it afforded.)
    const fresh=sectionHarmony(unit.value,{previous,home:this.bandOpening,random:unitRandom,last:Boolean(unit.value.last),division:this.division,bridge:this.horizon?.kind==='piece',jazz:this.jazzAsked});
    // (Its recalled phrases its source's, each progression moved by the interval between their regions' tonics, nearer
    // way round, and fitted to its phrase where it is longer.)
    const recall=unit.layers.recall,source=recall?this.planner.units.find(item=>item.index===recall.from)?.layers?.harmony:null;
    if(!source?.phrases?.length)return this.heldThrough(unit,fresh);
    const shift=((Number(fresh.region.tonic)-Number(source.region.tonic))%12+18)%12-6;
    // (And re-moded as far as the return draws (recall.remode): each tone moved that share of the way to the nearest of
    // the return region's own collection, in its tuning -- from the exposition's harmony moved whole to its harmony in the
    // return's mode and tuning, every state between.)
    const remode=Math.max(0,Math.min(1,Number(recall.remode)||0)),[low,high]=HARMONY_PLAN.register;
    const ladder=remode>0?collectionPitches(fresh.region.collection,{tonic:Number(fresh.region.tonic),low:low-12,high:high+12}):null;
    const moded=pitch=>{if(!ladder?.length)return pitch;const near=ladder.reduce((best,p)=>Math.abs(p-pitch)<Math.abs(best-pitch)?p:best,ladder[0]);return pitch+remode*(near-pitch)};
    const phrases=fresh.phrases.map((phrase,k)=>{
      if(!recall.phrases[k])return phrase;
      // (A section played backwards: its phrases from the last, each one's chords from its last.)
      const n=source.phrases.length,turn=recall.backward?n-1-(k%n):k%n,index=recall.order?.length===n?recall.order[turn]:turn,given=source.phrases[index];
      const from=recall.backward?{durations:[...given.durations].reverse(),chords:[...given.chords].reverse()}:given,total=from.durations.reduce((a,b)=>a+b,0);
      const durations=total<=fresh.phraseBeats?[...from.durations]:fitted(from.durations,fresh.phraseBeats);
      return {durations,chords:from.chords.slice(0,durations.length).map(chord=>chord.map(pitch=>+moded(pitch+shift).toFixed(4))),recalled:index,...(recall.backward?{backward:true}:{})};
    });
    return this.heldThrough(unit,{...fresh,phrases,lastChord:phrases.at(-1).chords.at(-1)});
  }
  // Each chord of its harmony layer said as its felt beat comes (the band's pool: every bot's `notes`), once, in the band's
  // tuning.
  sayHarmony(tick,clock){
    if(!this.harmonyPlanned||!this.planner||!clock?.meter||!Number.isInteger(clock.bar))return;
    const unit=this.planner.unitAt(clock.bar),harmony=unit?.layers?.harmony;if(!harmony?.phrases?.length)return;
    const beats=feltBeats(clock.meter,{secondsPerTick:secondsPerTick(clock)}),index=beats.findIndex(beat=>beat.start===(clock.tickInBar??0));if(index<0)return;
    const {chord,step}=chordAt(harmony,(clock.bar-unit.startBar)*beats.length+index),key=`${unit.index}:${step}`;
    if(key===this.harmonySaid||!chord?.length)return;this.harmonySaid=key;
    this.broadcast('notepool',this.activeTuning?chord.map(pitch=>applyTuningSystem(pitch,this.activeTuning)):chord);
  }
  onTick(tick,clock){
    if(!this.ensembleStopped&&(!this.begun||this.conducts?.(clock)))this.sayHarmony(tick,clock);
    if(!(clock.barStart||tick===0))return;
    const bar=Number(clock.bar)||0;
    if(bar===this.lastBar)return;this.lastBar=bar;
    if(!this.begun){this.begun=true;this.startPlanning(clock,bar===0&&!(clock.tick>0)?0:bar+1)}
    if(this.ensembleStopped)return;
    if(!this.conducts(clock)){this.standBy(clock);return}
    this.followHeardMeter(clock);this.followMeter(clock);
    this.announceGroup(clock);
    this.personGone(clock);
    // (Its children's asks answered before its plan is said again.)
    this.grantRequests();
    this.plan(clock);
    // (The bar's first chord said once its section is planned: the piece's first, before its first sound.)
    this.sayHarmony(tick,clock);
    if(!this.nested){
      // Each section handed over as it comes within the lead, for its own bar; ranges, not exact bars, so that ticks
      // skipped (a network delivers the latest) never lose one.
      const lead=this.leadBars(clock);
      for(const unit of this.planner.units){
        if(this.handed.has(unit.index)||unit.startBar>bar+lead)continue;
        if(unit.startBar>bar){this.meetAnswers(unit,clock);this.handOver(unit,atBar(unit.startBar),clock)}
        // (A plan begun on the first pulse, with no opening asked before it: its first section as soon as the transport can.)
        else if(unit.index===0&&unit.startBar===bar)this.handOver(unit,'opening',clock);
        // (Its hand-over skipped past: as soon as the transport can, late rather than never.)
        else if(bar<unit.endBar)this.handOver(unit,'nextBar',clock);
        else this.handed.add(unit.index);
      }
      for(const unit of this.planner.units)if(this.handed.has(unit.index)&&!this.cued.has(unit.index)&&unit.startBar<=bar+1&&bar<unit.endBar)this.cue(unit);
      this.verify(clock);
    }
    // Whoever joins late hears the plan again at each section's phrase (as mh_PlexBOT repeats its form each phrase): the
    // piece and the form, the group, and the section's own words -- its rhythm plan and the next one's, its constraints,
    // its canon's parts -- which a relay keeps only the latest of.
    const unit=this.planner.unitAt(bar);
    if(unit&&(bar-unit.startBar)%Math.max(1,unit.value.phraseBars??phraseBarsOf(clock))===0){
      if(this.piecePlan)this.broadcast('plan',[this.piecePlan]);
      if(!this.nested&&this.formPlan){this.broadcast('plan',[this.formPlan]);this.broadcast('form/progress',[this.progressOf(clock)])}
      if(bar>unit.startBar){
        for(const index of [unit.index,unit.index+1]){const plan=this.sectionPlanIds.get(index);if(plan)this.broadcast('plan',[plan])}
        this.sayConstraints(unit,{again:true});
        for(const [key,plan] of this.canonSaid)if(key.startsWith(`${unit.index}:`))this.broadcast('plan',[plan]);
      }
    }
    // (A section's formations, this section's and the next's, each bar: its players keep the first heard for a bar. A
    // relay keeps only the latest said, the next phrase's, and a seat that joins as the piece opens -- a live player
    // loading its synth while its subconductor says the opening -- heard only that, and sat out the opening phrase, a
    // minute of long bars: the formation in force said again within a bar, it plays it from its bar, as late as it came.)
    if(this.section&&unit)for(const index of [unit.index,unit.index+1]){const next=this.planner.units[index];if(next)this.sayFormations(next,{again:true})}
    if(!this.nested){if(!this.followsPerformer)this.shapePhrases(clock);this.close(clock)}
  }
  // Its rubato for the phrase coming within its lead (PLEX_CLODBOT.rubato): the rise from the phrase's start to its peak
  // and the lengthening from its peak to its end, each a tempo curve for its bar.
  shapePhrases(clock){
    if(!this.ritardando||!this.planner?.units?.length)return;
    const bar=Number(clock.bar)||0,ahead=bar+this.leadBars(clock),unit=this.planner.units.find(item=>item.startBar<=ahead&&ahead<item.endBar);
    const section=unit?.value,bpm=Number(section?.tempo?.targetBpm),phraseBars=Math.max(1,Number(section?.phraseBars)||bandPhraseBars());
    if(!unit||section.standIn||!(bpm>0)||phraseBars<2)return;
    const start=ahead-(ahead-unit.startBar)%phraseBars,end=Math.min(unit.endBar,start+phraseBars);
    // (After its section's change of tempo, where that takes the phrase's first bars: the arch from where it ends.)
    const from=Math.max(start,unit.startBar+(Number(section.tempo.durationBars)||0));
    if(end-from<2||section.last&&end>=unit.endBar||ahead<from)return;
    // (Every phrase breathes, most a little (the owner, 2 October 2026: "we should expect small amounts of rubatoed
    // phrase-shaping in most phrases - just, often small amounts"): its section's depth drawn once, most of them small,
    // each phrase's its own share of it; less as the character is mechanical or steady.)
    const {depth:[low,high],phrase:[lightest,fullest],peak:[early,late],rise}=PLEX_CLODBOT.rubato,draw=seededSource(Number(this.ensembleSeed)>>>0,`rubato:${unit.index}`),c=this.character;
    const own=lightest+(fullest-lightest)*seededSource(Number(this.ensembleSeed)>>>0,`rubato:${unit.index}:${start}:depth`)();
    const depth=Math.min(high,(low+(high-low)*draw()**2)*own)*(c?(1-.7*c.mechanism)*(1-.4*c.continuity):1)*(this.rubatoAsked??1);if(!(depth>1e-4))return;
    const peak=from+Math.max(1,Math.min(end-from-1,Math.round((early+(late-early)*seededSource(Number(this.ensembleSeed)>>>0,`rubato:${unit.index}:${start}`)())*(end-from))));
    // (Where a drummer keeps the time, the clocks keep a share of the arch and the melodic parts take the rest.)
    const keeping=this.keepsTime(clock,phraseBars),[least,most]=PLEX_CLODBOT.rubato.keep;
    const keep=keeping?(least+(most-least)*seededSource(Number(this.ensembleSeed)>>>0,`rubato:${unit.index}:keep`)())*(c?1-.5*c.mechanism:1):1,clockDepth=depth*keep;
    // (Where a part keeps the form's clock -- a tape, its sounds placed in the form's seconds (secondsAtBar) -- the arch
    // brings the band back to the form's clock at its end, paying back what it owed at its start (every curve sent so
    // far, its sections' changes of tempo too: the clock it has sent, SentClock), its rise the one that does where one can
    // (else the nearest, said so: returned-rubato.js returningRise); where none is found, none that phrase: a tempo from
    // its first bar, what is owed still owed. The arch as sent is checked in development (certifyReturned, Astra's
    // EC06/EC16 and their review), never while it plays. Once a phrase.)
    const plans=this.archPlans??=new Map;
    if(!plans.has(start)){
      let riseTo=bpm*(1+rise*clockDepth),returned=null;
      const pulses=Number(clock?.meter?.pulsesPerBar)||0;
      if(this.formClockKept&&pulses>0){
        const units=this.formUnits(),sentClock=this.sentClock??=new SentClock({startBpm:bpm}),endBpm=bpm*(1-clockDepth);
        const chosen=returningRise({clock:sentClock,units,from,peak,end,bpm,endBpm,most:high});
        returned=chosen?{rise:+chosen.rise.toFixed(5),exact:chosen.exact}:false;
        if(returned)riseTo=bpm*(1+chosen.rise);
      }
      plans.set(start,{riseTo,returned});if(plans.size>64)plans.delete(plans.keys().next().value);
    }
    const {riseTo,returned}=plans.get(start);
    const sent=this.rubatoSent??=new Set,say=(key,at,targetBpm,durationBars)=>{
      if(sent.has(key)||!(bar<at&&ahead>=at))return;sent.add(key);
      const curve={targetBpm:sentBpm(targetBpm),durationBars,shape:'linear'};this.broadcast('tempoCurve',[curve,atBar(at)]);this.tempoSent(curve,atBar(at),clock);
    };
    if(returned===false){say(`${start}:a tempo`,from,bpm,0);return}
    say(`${start}:rise`,from,riseTo,peak-from);
    say(`${start}:lengthen`,peak,bpm*(1-clockDepth),end-peak);
    const partDepth=Math.min(1,depth*(1-keep)/RUBATO_PLAN.arch);
    if(!sent.has(`${start}:part`)&&bar<from&&ahead>=from){sent.add(`${start}:part`);
      if(keeping&&partDepth>.01)this.broadcast('partRubato',[{id:`plex:${this.instanceId??'plex'}:${start}`,bar:from,bars:end-from,depth:+partDepth.toFixed(3),closes:false,presses:false,instrument:'melody'}]);
      this.decide?.({rubato:{bar:from,bars:end-from,depth:+depth.toFixed(4),keep:+keep.toFixed(3),...(keeping?{part:+partDepth.toFixed(3)}:{}),...(returned?{returned}:{})}});}
  }
  // A tempo curve it sent, kept in the clock it has sent (returned-rubato.js SentClock): its bar the one `when` names.
  tempoSent(curve,when,clock=this.currentClock){
    const bar=when==='opening'?0:when==='nextBar'?(Number(clock?.bar)||0)+1:String(when).startsWith('bar:')?Number(String(when).slice(4)):NaN;
    if(Number.isFinite(bar))(this.sentClock??=new SentClock({startBpm:Number(clock?.bpm)||null})).send(curve,bar);
  }
  // The form's sections as its clock reads them: each one's bars, its tempo, a bar's seconds at it and its pulses.
  formUnits(){
    return this.planner.units.filter(unit=>Number(unit.value?.barSeconds)>0&&Number(unit.value?.tempo?.targetBpm)>0).map(unit=>({startBar:unit.startBar,endBar:unit.endBar,bpm:Number(unit.value.tempo.targetBpm),
      barSeconds:Number(unit.value.barSeconds),pulses:Math.max(1,(Number(unit.value.numerator)||1)*(Number(unit.value.subdivision)||1))}));
  }
  // Whether a drummer keeps the band's time: heard on the band's onsets (a time-keeper's role, not seated in a section,
  // whose players follow their conductor), as many strokes as bars within PLEX_CLODBOT.rubato.heard phrases.
  keepsTime(clock,phraseBars){
    const pulses=Number(clock?.meter?.pulsesPerBar)||0,bars=PLEX_CLODBOT.rubato.heard*phraseBars,tick=Number(clock?.tick);
    return pulses>0&&Number.isFinite(tick)&&[...(this.timekeepers?.values()??[])].some(ticks=>ticks.filter(at=>tick-at<=bars*pulses).length>=bars);
  }
  // The ending, planned: a ritardando into the last bar (unless form_clodbot says the closing), and the commitment to
  // stop at the plan's end, a phrase before it. A song set whole ends with its words instead (the user, 27 September
  // 2026: "these settings will ultimately determine the lengths of the pieces"): while a singer that sings its text once
  // has not committed its last phrase, no stop is committed (a poem is never cut); once each has, the piece ends in the
  // window after the last sung note, where its form closes there (song-ending.js songEndingAt).
  close(clock){
    if(this.songs.whole().length&&this.songEndBar==null){
      const endTick=this.songs.end();if(endTick==null)return;
      const {endsAt,why,lastBar}=songEndingAt(clock,{endTick,perTick:secondsPerTick(clock),phraseBars:this.planner.units.at(-1)?.value.phraseBars??phraseBarsOf(clock),formEnd:this.planner.endBar});
      this.songEndBar=endsAt;this.decide?.({song:{lastSungTick:endTick,lastBar,endsAt,why}});
    }
    // (A fixed medium that outlasts the form: the piece ends at the bar after its last sound, the band's form having
    // ended -- a phrase more would be silence, an elongated phrase's a minute of it; one that ends within the form
    // changes nothing.)
    if(Number.isFinite(this.mediaEndTick)&&!this.stopSent&&Number.isInteger(this.planner.endBar)&&clock?.meter?.pulsesPerBar){
      const perBar=clock.meter.pulsesPerBar,barStart=clock.tick-(clock.tickInBar??0),barsTo=Math.ceil((this.mediaEndTick-barStart)/perBar),mediaBar=(Number(clock.bar)||0)+Math.max(0,barsTo);
      this.mediaEndBar=Math.max(mediaBar,this.planner.endBar);
      if(this.mediaEndBar!==this.planner.endBar&&this.mediaSaid!==this.mediaEndBar){this.mediaSaid=this.mediaEndBar;this.decide?.({media:{endTick:this.mediaEndTick,endsAt:this.mediaEndBar}})}
    }
    // (Following a performer whose recording it knows ahead, the piece ends with it: at the bar line after its last sound,
    // its bar predicted at the tempo now, as late as a phrase ahead allows -- form_clodbot's endWithRecording.)
    const recorded=this.followsPerformer?this.recordingEndBar(clock):null;
    // (Never past the render's end: where its stop would fall after it, the last bar line its plan reaches in time, the band
    // cut off together there -- not stopped by the render wherever each player is, as Op. 3.31's had been.)
    const planned=recorded??this.songEndBar??(this.mediaEndBar!=null?Math.max(this.mediaEndBar,this.planner.endBar??0):this.planner.endBar);
    const limit=this.endSecondsDeclared!=null&&planned!=null?this.lastBarBy(this.endSecondsDeclared):null,end=limit!=null&&limit>(Number(clock?.bar)||0)?Math.min(planned,limit):planned;
    if(end==null||!this.ends)return;
    const bar=Number(clock.bar)||0,last=this.planner.units.at(-1),lead=Math.max(1,last?.value.phraseBars??phraseBarsOf(clock));
    if(!this.stopSent&&bar>=end-lead&&bar<end){
      this.stopSent=true;
      this.stopCommitment=this.preparePlan('lifecycle',{schemaVersion:1,action:'stop',phase:'commitment',decision:{planned:true,horizon:this.horizon.kind,...(recorded!=null?{foresight:true,performerEnd:+this.performerEnd().toFixed(3)}:{})},
        piecePlanId:this.piecePlan?.planId??null,formPlanId:this.formPlan?.planId??null},{
        createdAt:{bar,phrase:clock.phrase||0,section:clock.section||0},appliesAt:{bar:end,phrase:Math.floor(end/lead),section:this.planner.units.length},
        expiresAt:{bar:end+lead,phrase:Math.floor(end/lead)+1,section:this.planner.units.length},horizon:1,confidence:1,priority:1,
        rationale:recorded!=null?'The performer\'s recording ends here (foresight): the band ends with it.':this.songEndBar!=null?'The words end; the piece ends after them.':'The piece as planned ends here.'});
      this.announcePlan(this.stopCommitment);
      this.broadcast('form/decision',[{status:'accepted',planned:true,planId:this.stopCommitment.planId,appliesAt:this.stopCommitment.appliesAt}]);
    }
    // (Over the last two bars, handed over as a section is, for its bar; where ticks skipped past that, over what is
    // left of them.)
    if(this.ritardando&&!this.followsPerformer&&!this.closingHeard&&!this.ritardandoSent&&bar>=end-2-this.leadBars(clock)&&bar<end-1&&last){
      this.ritardandoSent=true;
      const from=Math.max(end-2,bar+1);
      const curve={targetBpm:Math.round(last.value.tempo.targetBpm*PLEX_CLODBOT.ritardando),durationBars:end-from,shape:'linear'};
      this.broadcast('tempoCurve',[curve,atBar(from)]);this.tempoSent(curve,atBar(from),clock);
    }
  }
  // The bar the performer's recording ends before, as the band's tempo now predicts it (foresight), else null.
  recordingEndBar(clock){
    const end=this.performerEnd();if(end===null||!clock?.meter?.pulsesPerBar||!this.renderInputs?.now)return null;
    const now=this.renderInputs.now(),barSeconds=clock.meter.pulsesPerBar*secondsPerTick(clock),bar=Number(clock.bar)||0;
    return this.recordedEnd=this.stopSent?this.recordedEnd:bar+Math.floor(Math.max(0,end-now)/barSeconds)+1;
  }
  // The parts' answers to the section before, met in this one as mh_PlexBOT meets them (its negotiate): a majority
  // keeping their own meter has this section in it, a majority counting another grouping has it grouped so. A stimulus:
  // the section is revised and said again before it is handed over.
  meetAnswers(unit,clock){
    if(unit.index===0||this.handed.has(unit.index))return;
    const plan=this.sectionPlanIds.get(unit.index-1),record=plan&&this.sectionPlans.get(plan.planId);
    if(!record?.answers?.size||['return','complex-return'].includes(unit.value.role))return;
    const saved={form:this.form,section:this.section,sectionPlans:this.sectionPlans,formPlan:this.formPlan};
    const next={...unit.value,rhythm:{...unit.value.rhythm},groups:[...unit.value.groups]};
    // (mh_PlexBOT's own negotiate, run over this section and the answers to the one before.)
    this.form=[];this.form[1]=next;this.section=1;this.sectionPlans=new Map([['previous',{section:0,meter:record.meter,answers:record.answers}]]);this.formPlan=null;
    let outcome=null;try{outcome=this.negotiate(clock)}finally{Object.assign(this,saved)}
    if(!outcome)return;
    unit.value=Object.freeze({...next,bars:unit.value.bars,barSeconds:round(next.numerator*60/Math.max(1,next.tempo.targetBpm)),last:unit.value.last});
    this.noteStimulus({kind:'answer',fromBar:unit.startBar,reason:`${outcome.count} of ${outcome.answered} parts answered ${outcome.answer} (${outcome.from} to ${outcome.to})`},clock);
    this.announceSection(unit,clock);this.planner.revision++;this.plan(clock);
  }

  // ---- Stimuli -----------------------------------------------------------------------------------------------------
  // A section in the ensemble's character (a style: aesthetic.js sectionAesthetic): its formations not yet sounding
  // decided again in it, where one is said -- a style moves where a section of the form begins (stylespace_clodbot),
  // and its formations for that section were decided a phrase before; and at the first tick, before any sound, the
  // first phrase's too. Its draws are its own (keyed), so only the character changes them.
  onCharacter(){
    if(!this.section||!this.planner?.units)return;
    const clock=this.currentClock??{},bar=Number(clock.bar)||0,fresh=!(Number(clock.tickInBar)>0);
    const unit=this.planner.units.find(item=>item.startBar>=(fresh?bar:bar+1));
    if(unit)this.planner.reopen({fromBar:unit.startBar,layers:['formation'],kind:'character',reason:'the ensemble\'s character',bar});
    if(this.begun&&!this.deputy)this.plan(clock);
  }
  // The band's theme (MemoryBOT's motif plans carry it: thematic-form.js, the home section's theme, its top line), the
  // first heard: for a section's lines to return in their closing phrase, the piece's last, from the next section of
  // the form on, its formations decided again from there (as a figure heard: the same piece at any horizon). Its notes
  // and a return's each name the stored motif they are from (motifs.js storedLine), for its players to say what of it
  // they played: else MemoryBOT never heard its themes come back.
  onPlan(plan,message){
    if(plan?.kind==='motif'&&plan.payload?.insistence){
      if(!this.section||!FUGUE.kinds.test(this.groupId))return super.onPlan(plan,message);
      try{
        const changed=hearInsistence(this.motifInsistences??=new Map,plan),bar=Number(this.currentClock?.bar)||0;
        if(changed&&this.planner?.units){const next=this.planner.units.find(unit=>unit.startBar>bar);
          if(next)this.planner.reopen({fromBar:next.startBar,layers:['formation'],kind:'theme',reason:'motif insistence changed',bar})}
        this.respondToPlan(plan,'accept',{createdAt:plan.createdAt,rationale:'Will plan this motif by its insistence; physical constraints take precedence and conflicts are reported.'});
      }catch(error){this.respondToPlan(plan,'decline',{createdAt:plan.createdAt,rationale:error.message})}
      return;
    }
    if(this.section&&!this.bandTheme&&plan?.kind==='motif'&&Array.isArray(plan.payload?.theme?.line)&&plan.payload.theme.line.length>=2){
      const bar=Number(this.currentClock?.bar)||0,next=this.planner?.units?.find(unit=>unit.startBar>bar);
      this.bandTheme=storedLine(plan.payload.theme);this.bandThemeAt=bar;
      if(next)this.planner.reopen({fromBar:next.startBar,layers:['formation'],kind:'theme',reason:'the band\'s theme heard',bar});
    }
    // (And a theme's return MemoryBOT plans (its return plans: thematic-form.js), for its lines to present in the phrase it
    // returns at -- where that section of the form has not yet begun, its formations decided again from it.)
    if(this.section&&plan?.kind==='motif'&&plan.payload?.return&&Array.isArray(plan.payload?.theme?.line)&&plan.payload.theme.line.length>=2&&Number.isInteger(plan.appliesAt?.bar)){
      const bar=Number(this.currentClock?.bar)||0,at=plan.appliesAt.bar,unit=this.planner?.units?.find(item=>item.startBar<=at&&at<item.endBar);
      if(unit&&unit.startBar>bar&&!(this.themeReturns??=new Map).has(at)){this.themeReturns.set(at,storedLine(plan.payload.theme));
        this.planner.reopen({fromBar:unit.startBar,layers:['formation'],kind:'theme',reason:'a theme\'s return planned',bar})}
    }
    return super.onPlan(plan,message);
  }
  onMessage(message){
    // A form adjusted is a stimulus to this fork, not mh_PlexBOT's revision of its looping form.
    if(message?.address==='/broadcast/form/adjust'){Agent.prototype.onMessage.call(this,message)}
    else super.onMessage(message);
    this.tree.hear(message,{bar:Number.isInteger(this.currentClock?.bar)?this.currentClock.bar:undefined});
    // (Constraints or an announcement its sender may not send are not heard: groups.js, authority.js.)
    if(this.tree.lastRefused===message)return;
    this.hearConductors(message);
    if(message?.address===PROFILE_ADDRESS&&message.source!==this.instanceId){
      this.profiles.hear(message.args?.[0],this.currentClock?.bar??this.lastBar??0);if(this.followsPerformer)this.hearMeter(message.args?.[0])}
    if(message?.address===CLOSING)this.closingHeard=this.closingHeard||message.source!==this.instanceId;
    if(message?.address==='/broadcast/vocal/plan')this.songs.hear(message.args?.[0]);
    // (The figures the others say, for its figurations to take after.)
    if(this.section&&message?.address==='/broadcast/figure'&&message.args?.[0]&&String(message.args[0].voice)!==String(this.groupId)){
      // (A player first heard figuring: its figure the one taken after, from the next section of the form on, its
      // formations decided again from there. Only a player's first: a piece is the same planned at any horizon, so what
      // it takes after changes only where its plan is reopened -- the same bar whenever it plans.)
      const voice=String(message.args[0].voice),known=(this.figuresHeardFrom??=new Set).has(voice),bar=Number(this.currentClock?.bar)||0;
      if(!known){this.heardFigure=message.args[0];this.heardFigureAt=bar}this.figuresHeardFrom.add(voice);
      const next=!known&&this.inspiration>0?this.planner?.units?.find(unit=>unit.startBar>bar):null;
      if(next)this.planner.reopen({fromBar:next.startBar,layers:['formation'],kind:'figure',reason:`${voice}'s figure heard`,bar});
    }
    // (A tape in the band, its sounds placed in the form's seconds: its conductor's phrases give back the time they take,
    // shapePhrases.)
    if(message?.address==='/broadcast/acousmatic/plan'&&Array.isArray(message.args?.[0]?.events)&&message.args[0].events.length)this.formClockKept=true;
    // (The tape's plan, for a section that imitates it: its events, and its formations decided again from the next section
    // of the form not yet begun.)
    if(this.section&&message?.address==='/broadcast/acousmatic/plan'&&Array.isArray(message.args?.[0]?.events)){
      // (Its events' times from its own start, a quarter second after the piece's: near enough a phrase's.)
      this.tapeEvents=message.args[0].events.map(event=>({id:String(event.id),material:event.material,start:Number(event.start),seconds:Number(event.seconds),
        ...(Number.isFinite(Number(event.pitch))?{pitch:Number(event.pitch)}:{}),...(Array.isArray(event.contour)?{contour:event.contour.map(p=>p==null?null:Number(p))}:{})})).filter(event=>Number.isFinite(event.start)&&event.seconds>0);
      const bar=Number(this.currentClock?.bar)||0,next=this.planner?.units?.find(unit=>unit.startBar>bar);
      if(next&&this.tapeShare>0)this.planner.reopen({fromBar:next.startBar,layers:['formation'],kind:'tape',reason:'the tape\'s plan heard',bar});
    }
    // (A drummer keeping the band's time: its onsets' role, and no section it is seated in.)
    if(message?.address==='/broadcast/onsets'){const payload=message.args?.[0];
      if(payload?.role==='drums'&&!payload.group){const key=String(payload.voice??message.source),ticks=(this.timekeepers??=new Map).get(key)??[];
        ticks.push(...(payload.onsets??[]).map(onset=>Number(onset?.tick)).filter(Number.isFinite));this.timekeepers.set(key,ticks.slice(-512))}}
    // (Its sibling sections' formations, by their bars: what a recall may take from another section.)
    if(this.section&&message?.address==='/broadcast/group/formation'){const plan=message.args?.[0];
      if(plan?.parent===this.parentGroup&&plan.group!==this.groupId&&Number.isInteger(plan.appliesAt?.bar)&&Array.isArray(plan.formation?.pools)){
        const heard=(this.siblingFormations??=new Map),group=heard.get(plan.group)??heard.set(plan.group,new Map).get(plan.group);group.set(plan.appliesAt.bar,plan.formation)}}
    // (A child's ask: kept, by its section and group, to be granted with the others at the next bar.)
    // (A gesture its parent proposes, readied: the gesture as its kind will strike it, or rest through it.)
    if(this.nested&&message?.address===GESTURE_ADDRESS){const value=message.args?.[0];
      if(value?.parent===this.parentGroup&&typeof value.planId==='string'&&typeof value.planHash==='string')
        this.broadcast('group/gesture/ready',[{parent:value.parent,group:this.groupId,planId:value.planId,planHash:value.planHash,
          preparation:{gesture:value.gesture?.id??null,strikes:Boolean(this.section?.kind?.punctuated)},at:Number(this.currentClock?.tick)||0}]);}
    if(!this.nested&&message?.address===GESTURE_READY_ADDRESS){const value=message.args?.[0];
      if(value?.parent===this.groupId&&typeof value.group==='string'&&this.tree.children(this.groupId).some(child=>child.id===value.group))this.gestureReady(value);}
    if(message?.address===REQUEST_ADDRESS){const value=message.args?.[0];
      if(value?.parent===this.groupId&&typeof value.group==='string'&&Number.isInteger(value.unit)&&(Array.isArray(value.ask?.rest)||Array.isArray(value.ask?.solo))){this.requests.set(`${value.unit}|${value.group}`,value);this.requestsHeard=true}}
    // (A fixed medium is played whole: the piece never ends before its last sound, acousmatic_clodbot's plan saying the
    // tick it ends at.)
    if(message?.address==='/broadcast/acousmatic/plan'&&Number.isFinite(message.args?.[0]?.endTick))
      this.mediaEndTick=Math.max(this.mediaEndTick??0,message.args[0].endTick);
    if(message?.address==='/broadcast/plan'&&this.nested)this.hearParent(message.args?.[0]);
    if(message?.address==='/broadcast/group/constraints'){
      const value=message.args?.[0],key=`${value?.group}|${value?.from}|${value?.appliesAt?.bar}`,said=JSON.stringify(value?.constraints??null);
      if(this.constraintsHeard.get(key)===said)return;
      this.constraintsHeard.set(key,said);while(this.constraintsHeard.size>256)this.constraintsHeard.delete(this.constraintsHeard.keys().next().value);
    }
    const stimulus=classifyStimulus(message,{self:this.instanceId,group:this.groupId,ancestors:this.tree.ancestors(this.groupId),known:this.known});
    if(stimulus&&this.planner&&this.begun)this.onStimulus(stimulus,message);
  }
  noteStimulus(stimulus,clock=this.currentClock){
    this.stimuliHeard.push({bar:Number(clock?.bar)||0,...stimulus});while(this.stimuliHeard.length>32)this.stimuliHeard.shift();
  }
  // What each stimulus reopens: from the first section not yet handed over (or the bar it names, if later).
  onStimulus(stimulus){
    // (Standing by, the conductor answers; what it decides reaches this one in its plan.)
    if(this.deputy)return;
    const clock=this.currentClock??{},bar=Number(clock.bar)||0,from=Math.max(bar+1,stimulus.fromBar??-Infinity);
    // (A player arriving or leaving is ManageBOT's to answer: this conductor casts nobody.)
    const heeds=stimulus.kind==='performer'||stimulus.kind==='ending'?!this.nested:stimulus.kind==='constraints'?this.nested:['adjust','person'].includes(stimulus.kind)&&!this.nested;
    if(!heeds)return;
    this.noteStimulus(stimulus,clock);
    if(stimulus.kind==='performer'){
      // Deciding as it goes, with the person: its horizon a phrase (or as set), from the next section -- and the section
      // playing ended at its next phrase's end it can still hand over, where it would go on longer, so that the band
      // takes the person (its contingencies) at a phrase's hand-over rather than a section's: early rather than late
      // (measured, research/PLANNING_AHEAD.md: a person entering halfway through a section waited 5 to 11 bars). Not the
      // last section, which closes the piece, nor one in canon or fugue, whose parts are written to its end.
      this.horizon=this.performerHorizon;this.planner.horizon=this.performerHorizon;this.withPerson=true;
      const unit=this.planner.unitAt(bar);let cutAt=null;
      if(unit&&!unit.value.last&&!unit.layers.canon&&!unit.layers.fugue&&!this.handed.has(unit.index+1)){
        const phrase=Math.max(1,Number(unit.value.phraseBars)||bandPhraseBars()),at=unit.startBar+Math.ceil((bar+this.leadBars(clock)+1-unit.startBar)/phrase)*phrase;
        if(at<unit.endBar){this.planner.cut(unit.index,at,{kind:stimulus.kind,reason:`${stimulus.reason??'a performer heard'}: its section ended at a phrase`,bar});if(this.planner.units[unit.index]?.endBar===at)cutAt=at}
      }
      this.planner.reopen({fromBar:cutAt??from,kind:stimulus.kind,reason:stimulus.reason,bar});
    }else if(stimulus.kind==='adjust'||stimulus.kind==='person'){
      if(stimulus.kind==='person')this.drawSketch();
      this.planner.reopen({fromBar:from,kind:stimulus.kind,reason:stimulus.reason,bar});
    }else if(stimulus.kind==='constraints'){
      this.planner.reopen({fromBar:stimulus.fromBar??from,layers:['constraints'],kind:stimulus.kind,reason:stimulus.reason,bar});
    }else if(stimulus.kind==='ending'){
      // Another's committed ending adopted: the plan ends there. (A proposal is only a proposal.)
      if(stimulus.fromBar==null||this.stopSent||!stimulus.committed)return;
      this.stopSent=true;this.planner.reopen({fromBar:stimulus.fromBar,kind:stimulus.kind,reason:stimulus.reason,bar});
      if(this.sketch)this.sketch={...this.sketch,roles:this.sketch.roles.slice(0,this.planner.units.length)};
      this.planner.advance({bar});
    }
    // What was dropped is decided again now, where it is within the horizon.
    this.plan(clock);
  }
  // The person gone: everyone whose profile was heard has stopped for a phrase of the bar playing, or has not been heard
  // past the grace (their host dropped). It plans as far ahead as its own horizon again, and their return is a
  // performer heard again. (A listener without a profile never says it has gone: the conductor keeps to the person.)
  personGone(clock){
    if(!this.withPerson||this.nested)return;
    const bar=Number(clock.bar)||0,phraseSeconds=secondsPerTick(clock)*(clock.meter?.pulsesPerBar||bandMeter().pulsesPerBar)*phraseBarsOf(clock);
    if(!this.profiles.gone(bar,{seconds:phraseSeconds}))return;
    const voices=this.profiles.voices();
    for(const voice of voices){this.known.delete(`performer:${voice}`);this.profiles.forget(voice)}
    this.withPerson=false;this.horizon=this.ownHorizon;this.planner.horizon=this.ownHorizon;
    this.noteStimulus({kind:'performer-gone',reason:`${voices.join(', ')} gone`},clock);
    this.planner.note({kind:'performer-gone',reason:`${voices.join(', ')} gone: planning ${describeHorizon(this.horizon)} ahead again`,bar});
  }
  // A voice of a fugue its parent said this section plays (sayFugues): kept, the latest revision, and accepted; and where
  // it came after its section of the form's formations were decided, before that section has begun, they are decided
  // again (a cadence into a hit rewrites a voice's last notes after the voice was first said).
  hearFugueVoice(plan){
    const conductor=this.tree.get(this.parentGroup)?.conductor;if(conductor&&plan.author!==conductor)return;
    const held=this.fugueParts.get(plan.planId);if(held&&held.revision>=plan.revision)return;
    this.fugueParts.set(plan.planId,plan);
    while(this.fugueParts.size>4096)this.fugueParts.delete(this.fugueParts.keys().next().value);
    this.respondToPlan?.(plan,'accept',{createdAt:plan.createdAt,payload:{readyAt:plan.appliesAt},rationale:'Will give this voice to its seats.'});
    const bar=Number(this.currentClock?.bar)||0,unit=this.planner?.units.find(item=>item.index===plan.payload.section);
    if(unit&&unit.startBar>bar&&unit.layers?.formation)this.planner.reopen({fromBar:unit.startBar,layers:['formation'],kind:'parent',reason:`${this.parentGroup}'s fugue voice ${plan.payload.fugue}`,bar});
  }
  // A subconductor's parent's piece plan: its sections followed, reopened where they changed.
  hearParent(plan){
    if(plan?.kind==='part'&&plan.payload?.fugue!=null&&plan.payload.part===this.groupId&&plan.payload.group===this.parentGroup){this.hearFugueVoice(plan);return}
    if(plan?.kind!=='piece'||plan.payload?.group!==this.parentGroup)return;
    // (Its parent group's conductor's, as the group says it, where several could say one: election.js.)
    const conductor=this.tree.get(this.parentGroup)?.conductor;if(conductor&&plan.author!==conductor)return;
    if(this.parentPlan&&plan.revision<=this.parentPlan.revision&&plan.planId===this.parentPlan.planId)return;
    const before=this.parentPlan?.payload?.units??[];this.parentPlan=plan;
    if(!this.planner)return;
    // (Counting its sections from its parent's first, where it had decided none.)
    if(!this.planner.units.length&&Number.isInteger(plan.payload.startBar))this.planner.startBar=plan.payload.startBar;
    const changed=plan.payload.units.find(unit=>{const old=before.find(item=>item.index===unit.index);
      return old&&(old.startBar!==unit.startBar||old.endBar!==unit.endBar||JSON.stringify(old.layers?.constraints)!==JSON.stringify(unit.layers?.constraints))});
    if(changed)this.planner.reopen({fromBar:changed.startBar,kind:'parent',reason:`${this.parentGroup}'s plan revised`,bar:Number(this.currentClock?.bar)||0});
    // (And a section's formations decided again where what its parent decided for its sections -- the rests and solos it
    // granted them, their meters, a fugue's entries -- came after them: a request's round trip, or a layer its parent decides
    // once it knows its sections, is longer than a phrase-ahead decision, so a section of the form not yet begun takes
    // it; its draws are its own, so nothing else changes. What has begun stays as it was.)
    const bar=Number(this.currentClock?.bar)||0,read=unit=>JSON.stringify(['rests','solos','meters','fugue','punctuation'].map(id=>unit?.layers?.[id]??null));
    const answered=!changed&&plan.payload.units.find(unit=>unit.startBar>bar&&read(before.find(item=>item.index===unit.index))!==read(unit));
    if(answered)this.planner.reopen({fromBar:answered.startBar,layers:['formation'],kind:'parent',reason:`${this.parentGroup}'s decisions for its sections`,bar});
    // (In the section of the form playing, its phrases still to come decided again where its parent's grants for it
    // changed -- a solo granted late, the others receding under it -- each said again only where it changed; what is
    // playing and what has played stay as they were.)
    const playing=!changed&&this.section?this.planner.units.find(unit=>unit.startBar<=bar&&bar<unit.endBar&&Array.isArray(unit.layers?.formation)):null;
    const granted=playing&&plan.payload.units.find(unit=>unit.index===playing.index);
    if(granted&&read(before.find(item=>item.index===granted.index))!==read(granted)){
      const decided=this.planFormations(playing);
      if(Array.isArray(decided)){const next=decided.filter(entry=>entry.bar>bar),kept=playing.layers.formation.filter(entry=>entry.bar<=bar);
        playing.layers.formation=[...kept,...next];this.sayFormations(playing)}
    }
    if(this.begun&&!this.deputy)this.plan(this.currentClock??{});
  }
}
const CLOSING='/broadcast/form/closing';
// A coordinated gesture proposed to a conductor's sections, and a section's readiness for it (gesture-commitment.js).
const GESTURE_ADDRESS='/broadcast/group/gesture',GESTURE_READY_ADDRESS='/broadcast/group/gesture/ready';

export const plexClodbot=defineBot({id:'plex_clodbot',name:'plex_clodbot',status:'native',source:'clodbot',category:'conductor',outputModes:[],pitchContract:'none',
  roles:Object.freeze(['conductor']),
  specSettings:Object.freeze(['horizon','performerHorizon','group','parent','ends','ritardando','canon','contingencies','section','harmony','budget','plan','breadth','texture','elongation','imitateTape','inspiration','rubato','punctuation','fugues','fugueVoices','doubling','reorchestrate','rigor','division','improvisation','jazz','repetition','grammar','follow','ownTime']),
  // (The section it leads is an object: its kind, its choices and its specification, section-kinds.js; and a plan given as
  // a document, plan-document.js.)
  // (And its grammar's choices and its listeners' repetition tolerances, objects a render's spec passes whole: dropped,
  // Op. 3.29's asked irrational meters had never reached it.)
  specObjects:Object.freeze(['section','plan','grammar','repetition']),
  description:'The conductorbot: a fork of mh_PlexBOT that plans the piece as far ahead as its horizon -- a phrase ahead as mh_PlexBOT '
    +'does, the whole piece before the first bar (its default), or any number of bars, phrases, sections or seconds between -- '
    +'and plays it through to an ending it plans: each section\'s meter, grouping, phrase length, tempo and density drawn as '
    +'mh_PlexBOT draws them, said as soon as it is decided, handed to the transport a bar before it, a ritardando into the last '
    +'bar. Only a stimulus changes what it has decided: the parts\' answers to a meter, a performer heard (then it plans a phrase '
    +'at a time, with them), a form adjusted, another\'s ending. With each section it prepares contingencies for the people it '
    +'plays with (their tempo followed, the band lighter while they play busily, the space taken when they fall silent, no new '
    +'meter under a cadenza), chosen at the hand-over as their profiles stand. Across a network it hands each section over as far '
    +'ahead as the room needs to agree it, named for its bar, and says each section\'s words again for whoever joins late; where '
    +'several conduct one group, one leads and the others stand by, taking over from its plan if its host drops. Given parts that play as written, it plans a canon where the '
    +'form develops, a phrase ahead, from the harmony it hears. It conducts a group and nests: each section\'s constraints '
    +'(level, how far a section divides) flow down to the groups within it, and with a parent it is a subconductor, '
    +'following its parent\'s plan and narrowing its constraints.'},
  (...args)=>new PlexClodbot(...args));
