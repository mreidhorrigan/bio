// steelpan_clodbot: a steelpan player, a tenor pan (the world-instruments atlas's F30, gongs, pans and resonant vessel
// sets), playing a line with its sticking planned (shared/performers/steelpan.js). A new clodbot carrying the melody's
// principles to a struck idiophone, as flute_clodbot carries them to a wind; taken by 2a from c2's "Percussion beyond
// the kit", 29 September (SESSIONS.md 07:30).
//   - Each phrase is planned whole at its downbeat, from the harmony it hears (its pool, whatever the tuning) and the
//     meter's felt beats: phrases of its own motif in the sentence's shape (line.js), its sticking planned with it by
//     construction (panPhrase): a note on its field, by the stick free for it (by turns where both are), rolled where it
//     outlasts a pan's short ring, and left out, said, where neither stick could reach it in time.
//   - Its share of the band's attention (shared/attention.js) shapes it: given the solo, its density and loudness rise
//     with the solo's arc to a climax and its long notes take fioriture; behind another's solo it plays less and softer.
//   - It plays in the ensemble's feel and rubato (the performance layer; the clocks' spans), its runs in their own time.
//   - Its cadences harmonized: a phrase's held last note a double stop, the band's pitch a third under it (a sixth where
//     the band has no third) struck by the other stick at once, where both sticks reach their fields; held longer than
//     it rings, each stick rolls its own note, by turns.
//   - Its sound: its own struck field (the bell family's sine), Surge XT's Plucks/Fantasy Bell, or MIDI. The patch was
//     chosen by c2's measure (29 September): of the four candidates that pass the pitch table, its A4's first 200 ms
//     lie nearest a tenor pan's 1:2:3 (99.4% of the energy; the octave 0.9 dB and the twelfth 4.5 dB under the
//     fundamental), where the other three lack the octave or the twelfth.
// settings.notes: 'band' (unless given: a pan tuned for the piece, a field wherever the band's pitches are) or 'fixed'
// (a tenor pan in twelve steps, C4 to E6, which leaves out a pitch between its notes, never rounded).
import {Agent,defineBot} from '../../framework/index.js';
import {withScoreTime,shiftScoreTime} from '../../shared/score-time.js';
import {secondsPerTick} from '../../shared/meter-tactus.js';
import {PAN,panInstrument,fieldFor,fieldXY,ringOf,stickReaches} from '../../shared/performers/steelpan.js';
import {transportSeconds} from '../lib/modules/timekeeping.js';
import {licenseReach,soloArc} from '../../shared/attention.js';
import {HearsAttention} from '../lib/modules/attention.js';
import {HearsPartRubato,playLagged} from '../lib/modules/part-rubato.js';
import {PlaysPickups} from '../lib/modules/line-pickups.js';
import {HearsLineMotifs,occurrenceRecords} from '../lib/modules/line-motifs.js';
import {strikeWith} from '../lib/note-language.js';
import {Closure} from '../lib/modules/closure.js';
import {GroupingChoice} from '../lib/modules/grouping-choice.js';
import {LINE,followHarmony,linePitches,meterKey,phraseBeforeEnding,phraseOffset,planLine} from '../../shared/performers/line.js';
import {PerformedTiming} from '../lib/modules/performed-timing.js';
import {makingRoom,registerAway} from '../../shared/presentation.js';
import {createRandomStream} from '../../random-source.js';
import {bandPhraseBars,bandTempo} from '../../shared/opening-time.js';

const PHRASES_KEPT=16;
// Its density and loudness among equals (a line, not a soloist), its fioriture as a soloist, and its built-in voice's
// gain (the mallet player's: the median bot voice's loudness, sample-levels.mjs, 29 September).
export const STEELPAN=Object.freeze({density:.4,loudness:.55,fioriture:.35,voiceGain:.05});

// A phrase on the pan: the line (line.js planLine) in the pan's register, its sticking planned with it in one walk: each
// note on its field (on a fixed pan, one it has no field for left out), struck by the stick that is free for it and can
// reach its field in time (stickReaches), by turns where both can; held longer than its field rings, rolled, both
// sticks on it, the roll ending in time for a stick to reach the next note's field (a note too short for that, or with
// a stick not free for it, struck once and left to ring); a note neither stick can reach left out. `sticks` are where
// the sticks are as it begins ({LH, RH, turn}, in the phrase's seconds; none given, both free), so its first note is
// left out only where the last phrase still holds both sticks. -> {status, notes (each with its `hand`, `rolled` and a
// roll's `rollSeconds`), changes: [{at, change, because}], sticks (where they are after it), motif, apex, lead,
// choice?}. `choices` are the line's (line.js LINE), `pan` the pan's (PAN).
// A double stop's second note under `pitch`: the band's pitch a third under it (2.4 to 4.6 semitones), else a sixth
// (7.4 to 9.6), the nearest a true third's or sixth's size, on a field of the pan; null where the band has neither.
export function harmonyUnder(pitch,pool,{instrument=panInstrument(),choices=PAN}={}){
  const pitches=linePitches(pool,instrument.range).filter(each=>fieldFor(instrument,each,{choices})!==null);
  for(const [low,high,size] of [[2.4,4.6,3.5],[7.4,9.6,8.5]]){
    const found=pitches.filter(each=>pitch-each>=low&&pitch-each<=high).sort((a,b)=>Math.abs(pitch-a-size)-Math.abs(pitch-b-size))[0];
    if(found!==undefined)return fieldFor(instrument,found,{choices});
  }
  return null;
}
export function panPhrase({instrument=panInstrument(),register=null,pan=PAN,sticks=null,...line}){
  const planned=planLine({...line,register:register??instrument.range});
  const choices=pan;
  if(planned.status==='declined')return {...planned,changes:[]};
  const notes=[],changes=[],hands={LH:sticks?.LH??null,RH:sticks?.RH??null};let turn=sticks?.turn??'RH';
  const placed=planned.notes.map(note=>{const field=fieldFor(instrument,note.pitch,{choices});return field===null?null:{note,field,xy:fieldXY(field,{range:instrument.range,choices})}});
  const cadence=placed.findLastIndex(entry=>entry?.note.role==='cadence');
  for(const [k,entry] of placed.entries()){
    if(!entry){changes.push({at:planned.notes[k].start,change:'a note left out',because:'the pan has no field for its pitch'});continue}
    const {note,field,xy}=entry,reaches=hand=>stickReaches(hands[hand],xy,note.start,{choices}),other=turn==='RH'?'LH':'RH';
    let rolled=note.end-note.start>ringOf(instrument,field,{choices})+1e-9,rollEnd=note.end;
    if(rolled){
      const next=placed.slice(k+1).find(Boolean);
      if(next)rollEnd=Math.min(note.end,next.note.start-Math.hypot(next.xy.x-xy.x,next.xy.y-xy.y)/choices.handMmPerSecond);
      const because=rollEnd-note.start<2/choices.rollHz?'the next note comes too soon to roll it':!(reaches('LH')&&reaches('RH'))?'a stick is not free for its roll':null;
      if(because){rolled=false;changes.push({at:note.start,change:'struck once, not rolled',because})}
    }
    // The cadence's held last note a double stop: its harmony by the other stick, where each reaches its own field
    // (held, each stick rolling its own note).
    const under=k===cadence?harmonyUnder(field,line.pool??[],{instrument,choices}):null;
    if(under!==null){
      const underXY=fieldXY(under,{range:instrument.range,choices}),way=[['LH','RH'],['RH','LH']].find(([top,low])=>reaches(top)&&stickReaches(hands[low],underXY,note.start,{choices}));
      if(way){
        const [top,low]=way,end=rolled?rollEnd:null;
        for(const [each,at] of [[top,xy],[low,underXY]])hands[each]={...at,from:rolled?end:note.start,free:rolled?end:note.start+choices.strokeSeconds};
        const roll=rolled?{rollSeconds:rollEnd-note.start}:{};
        notes.push({...note,field,hand:top,rolled,double:true,...roll},{...note,pitch:under,field:under,hand:low,rolled,double:true,harmony:true,...roll});
        continue;
      }
      changes.push({at:note.start,change:'no double stop',because:'a stick was not free for its second note'});
    }
    const hand=rolled?'both':[other,turn].find(reaches)??null;
    if(!hand){changes.push({at:note.start,change:'a note left out',because:'neither stick reaches its field in time'});continue}
    const from=rolled?rollEnd:note.start,free=rolled?rollEnd:note.start+choices.strokeSeconds;
    for(const each of hand==='both'?['LH','RH']:[hand])hands[each]={...xy,from,free};
    if(hand!=='both')turn=hand;
    notes.push({...note,field,hand,rolled,...(rolled?{rollSeconds:rollEnd-note.start}:{})});
  }
  return {status:'stuck',notes,changes,sticks:{...hands,turn},motif:planned.motif,apex:planned.apex,variation:planned.variation,lead:planned.lead,...(planned.choice?{choice:planned.choice}:{})};
}

export class SteelpanClodbot extends Agent {
  constructor(...args){
    super(...args);
    const notes=args[2]?.notes??'band';if(notes!=='band'&&notes!=='fixed')throw new RangeError('settings.notes is band or fixed');
    this.instrument=panInstrument({notes});
    this.phrase=null;this.phrases=[];
    // Where each stick is as it plays ({x, y, from, free}, s of its own time: transportSeconds), and whose turn it is.
    this.sticks={LH:null,RH:null,turn:'RH'};
    // Its motif, kept and varied phrase by phrase, and its last phrase's apex, not taken again (line.js).
    this.motif=null;this.phraseIndex=0;this.previousApex=null;this.lead=null;
  }
  // Its time now (s).
  now(clock){return transportSeconds(this.transportClock??={},clock)}
  // Its density, loudness and fioriture for a phrase beginning at `bar`, from its attention there.
  shaping(bar){
    const attention=this.attentionAt?.(bar),base=STEELPAN;
    if(!attention||!Number.isFinite(attention.typicalDb))return {density:base.density,loudness:base.loudness,fioriture:0};
    const {reach,belowDb}=licenseReach({allowance:attention.allowanceDb,typicalDb:attention.typicalDb});
    if(attention.soloing){const arc=soloArc(attention.progress??.5)*reach;return {density:base.density+(1-base.density)*arc,loudness:base.loudness+(1-base.loudness)*arc,fioriture:base.fioriture+(1-base.fioriture)*arc}}
    const scale=10**(-belowDb/10);return {density:base.density*scale,loudness:base.loudness*Math.sqrt(scale),fioriture:0};
  }
  // A field struck: its built-in voice (the bell family's sine), the synth a spec names, or MIDI.
  strike(pitch,seconds,velocity,offset,musical={}){
    if(this.audio?.mode==='midi'){this.audio.midiNote?.(pitch,seconds,velocity,undefined,offset,{instrument:'bell',profile:'bell',...musical});return}
    this.audio?.voice?.(pitch,seconds,STEELPAN.voiceGain,'sine',offset,{instrument:'bell',profile:'bell',velocity,...musical});
  }
  // A field rolled: the two sticks by turns at PAN.rollHz from its stroke for `rolling` seconds, the note ringing on to
  // its end, one note (audio.js roll); where an engine has no roll, stroke by stroke.
  // (`every`, `from`: a double stop held, each stick on its own note, a stroke in two, the second's between the first's.)
  roll(pitch,seconds,velocity,offset,rolling=seconds,{every=1/PAN.rollHz,from=0}={}){
    const length=seconds-from,step=every,strokes=Array.from({length:Math.max(1,Math.floor(Math.min(rolling-from,length)/step))},(_,k)=>k*step);
    if(!(length>0))return;
    if(typeof this.audio?.roll==='function'){this.audio.roll(pitch,length,STEELPAN.voiceGain,'sine',offset+from,{instrument:'bell',profile:'bell',velocity},{strokes,ring:2*step,later:.85});return}
    strokes.forEach((at,k)=>this.strike(pitch,k?Math.min(2*step,length-at):length,velocity*(k?.85:1),offset+from+at,
      {technique:'tremolo',...(k?{captured:false}:{})}));
  }
  // How a note is struck as it sounds, from where the sticks are then (s of its own time): its field the harmony's
  // sounding now where a stick reaches it, else its planned field; rolled where both sticks are free for it, else by
  // the stick whose turn it is that reaches it. -> {field, hand, rolled}, or null (neither reaches it: left out).
  sticking(note,fields,time){
    const other=this.sticks.turn==='RH'?'LH':'RH';
    // (A double stop's note by its own stick, the other on its partner.)
    if(note.double){
      for(const field of [...new Set(fields.filter(value=>value!==null))]){const xy=fieldXY(field,{range:this.instrument.range});if(stickReaches(this.sticks[note.hand],xy,time))return {field,xy,hand:note.hand,rolled:Boolean(note.rolled)}}
      return null;
    }
    for(const field of [...new Set(fields.filter(value=>value!==null))]){
      const xy=fieldXY(field,{range:this.instrument.range}),reaches=hand=>stickReaches(this.sticks[hand],xy,time);
      if(note.rolled&&reaches('LH')&&reaches('RH'))return {field,xy,hand:'both',rolled:true};
      const hand=(note.hand==='both'||!note.hand?[other,this.sticks.turn]:[note.hand,note.hand==='LH'?'RH':'LH']).find(reaches);
      if(hand)return {field,xy,hand,rolled:false};
    }
    return null;
  }
  onTick(tick,clock){
    super.onTick?.(tick,clock);
    const meter=clock?.meter;
    if(!meter||!Number.isInteger(clock.bar))return;
    const phraseBars=Math.max(1,Number(meter.phraseBars)||bandPhraseBars()),perTick=secondsPerTick(clock);
    // A phrase planned whole at its downbeat, its sticking with it, on its phrase grid (as the flute's: the form's where
    // it is the band's focus, half a phrase later where another's share of the band's attention is larger); it ends
    // with the piece where the ending is known, rests through an answering silence, thins under a texture and keeps out
    // of another's register (shared/presentation.js). At its entry it never waits.
    const ending=this.closingAt?.(clock)?.ending??null,endsAt=Number.isInteger(ending?.endsAt?.bar)?ending.endsAt.bar:null;
    if(endsAt!=null&&clock.bar>=endsAt||this.presentationOver?.(clock.bar,clock.bar+1)?.kind==='silence'){this.phrase=null;return}
    const offset=phraseOffset(this.attentionAt?.(clock.bar),phraseBars),current=this.phrase;
    const acting=current?makingRoom(this.presentationOver?.(clock.bar,current.endBar)).key:null;
    const due=clock.tickInBar===0&&(current?clock.bar>=current.endBar||clock.bar<current.startBar||current.meterKey!==meterKey(meter)||endsAt!=null&&current.endBar>endsAt&&!current.final||acting!=null&&acting!==current.room:true);
    if(due){
      const whole=phraseBeforeEnding(clock.bar,{phraseBars,offset,endsAt}),room=makingRoom(this.presentationOver?.(clock.bar,clock.bar+whole.bars));
      const span=phraseBeforeEnding(clock.bar,{phraseBars,offset,endsAt,breakAt:room.silentBar}),bars=span.bars;
      const random=(this.phraseRandom??=createRandomStream(`${this.randomStream?.seed??0}:steelpan`)),draw=()=>random.next();
      const shaped=this.shaping(clock.bar);shaped.density*=room.density;
      const own=this.instrument.range,register=room.awayFrom?registerAway(own,room.awayFrom)??own:own;
      const pickup=span.final?null:this.pickupAt?.(clock.bar+bars,clock,draw)??null;
      // Its sticks where the last phrase left them, in this phrase's seconds.
      const start=this.now(clock),relative=hand=>this.sticks[hand]&&{...this.sticks[hand],from:this.sticks[hand].from-start,free:this.sticks[hand].free-start};
      const planned=panPhrase({instrument:this.instrument,register,sticks:{LH:relative('LH'),RH:relative('RH'),turn:this.sticks.turn},coreOnly:room.thin,pool:this.notes,meter,bpm:Number(clock.bpm)||bandTempo(),bars,...shaped,motif:this.motif,motifDensity:STEELPAN.density,
        phraseIndex:this.phraseIndex,previousApex:this.previousApex,pickup,lead:this.lead,heard:this.motifsHeard?.()??[],climax:this.attentionAt?.(clock.bar)?.role==='climax',
        final:span.final?{tonic:ending?.tonic??null}:null,random:draw,choices:LINE});
      if(planned.motif)this.motif=planned.motif;if(planned.apex!=null)this.previousApex=planned.apex;this.lead=planned.lead??null;this.phraseIndex++;
      if(planned.choice)this.sayMotif?.(planned.motif);
      this.phrase={startTick:tick,perTick,notes:planned.notes,status:planned.status,startBar:clock.bar,endBar:clock.bar+bars,meterKey:meterKey(meter),final:span.final,room:room.key,
        records:occurrenceRecords(planned.notes,{by:this.instanceId,phrase:`${clock.bar}`,motif:this.motif})};
      this.phrases.push(this.phrase.entry={bar:clock.bar,bars,offset,pickup:pickup?.fill??null,status:planned.status,notes:planned.notes.length,rolled:planned.notes.filter(note=>note.rolled).length,
        ...(planned.choice?{choice:planned.choice}:{}),...(room.key?{room:room.key}:{}),changes:planned.changes.map(change=>change.change),leftOut:0,...shaped});
      if(this.phrases.length>PHRASES_KEPT)this.phrases.shift();
    }
    const phrase=this.phrase;
    if(!phrase?.notes?.length)return;
    // Each note as its tick comes round (as the flute's), at its part's own time where ManageBOT says one; a note is
    // never played late. Its pitch the harmony's sounding now where a stick reaches its field, else as planned; a note
    // neither stick reaches then (a changed chord's field across the pan, a rubato's hurried leap) is left out, counted.
    phrase.sounded??=new Set;
    if(Number.isFinite(phrase.lastTick)&&tick>phrase.lastTick+1)phrase.notes.forEach((note,index)=>{if(phrase.startTick+note.start/phrase.perTick<tick)phrase.sounded.add(index)});
    phrase.lastTick=tick;
    for(const [index,note] of phrase.notes.entries()){
      if(phrase.sounded.has(index))continue;
      const planned=phrase.startTick+note.start/phrase.perTick,at=Math.max(tick,this.partTick?.(planned,clock)??planned);
      if(at>=tick+1)continue;
      phrase.sounded.add(index);
      const seconds=(note.end-note.start)*.95,offsetSeconds=(at-tick)*perTick,time=this.now(clock)+offsetSeconds;
      const followed=fieldFor(this.instrument,followHarmony(note.pitch,this.notes,this.instrument.range)),struck=this.sticking(note,[followed,note.field],time);
      if(!struck){if(phrase.entry)phrase.entry.leftOut++;continue}
      const {field:pitch,xy,hand,rolled}=struck,rolling=rolled?Math.min(seconds,note.rollSeconds??seconds):0;
      for(const each of hand==='both'?['LH','RH']:[hand])this.sticks[each]={...xy,from:time+rolling,free:time+(rolled?rolling:PAN.strokeSeconds)};
      if(hand!=='both')this.sticks.turn=hand;
      const doubled=note.double?{every:2/PAN.rollHz,from:note.harmony?1/PAN.rollHz:0}:{};
      const strike=()=>rolled?this.roll(pitch,seconds,note.velocity,offsetSeconds,rolling,doubled):this.strike(pitch,seconds,note.velocity,offsetSeconds);
      // (Its rubato and its ornament's warp how it is played, not written: audio.js lagged.)
      const record=phrase.records?.[index];
      const play=()=>{if(record)strikeWith(this,[{pitch,language:record}],strike);else strike()},lag=(at-planned)*perTick+(Number(note.lag)||0);
      withScoreTime(this.audio,shiftScoreTime(note.scoreTime,phrase.startTick,{axis:'ensemble'}),()=>playLagged(this.audio,lag,play));
    }
  }
}
export function defineSteelpanClodbot(){
  const Bot=PerformedTiming(HearsAttention(PlaysPickups(HearsPartRubato(HearsLineMotifs(GroupingChoice(Closure(SteelpanClodbot),{role:'layer'}))))),{instrument:'melody'});
  return defineBot({
    id:'steelpan_clodbot',name:'steelpan_clodbot',status:'native',source:'clodbot',category:'melody',midiChannel:4,outputModes:['synth','midi'],
    pitchContract:'floating-mpe',specSettings:Object.freeze(['notes']),
    description:'A steelpan player on a tenor pan, playing phrases of its own motif (the idea, its repetition, a climb to one apex, a held cadence, a rest) with its two sticks planned with them: each note on its field of a pan laid out in fourths and fifths, by the stick free for it, rolled where it outlasts the pan\'s short ring; given the solo, busier and louder toward its climax. Its fields take the band\'s pitches, microtones included.',
  },(...args)=>new Bot(...args));
}
export const steelpanClodbot=defineSteelpanClodbot();
