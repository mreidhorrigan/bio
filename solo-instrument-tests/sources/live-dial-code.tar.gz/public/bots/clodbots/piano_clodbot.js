import {scoreTime,readScoreTime,shiftScoreTime,withScoreTime,scoreTimeFields} from '../../shared/score-time.js';
import {dividedBeats} from '../../shared/performers/rhythm-cell.js';
// piano_clodbot: a pianist, the first of the instrument clodbots (research/MUSEBOTS_WORLD_INSTRUMENTS_CONSTRAINTS_
// RESEARCH_AND_IMPLEMENTATION_REPORT.md and family-atlas.md, F01 hammer-action keyboards). New, not a fork. The user,
// 28 September 2026: "Once we're done the current drum work, we should use other instruments for testing ... a new
// instrument-based set of clodbots (piano_clodbot, et cetera), which should hopefully help us generalize on some of the
// testing we've been doing with drums."
//
// Its harmony is jazzvoicing_clodbot's: it hears the band's harmony and voice-leads its right hand's voicing. What a
// pianist adds:
// - **Two hands, playable by construction.** What it plays is chosen from what a pianist's hands can play, never drawn
//   and then checked (the user, 28 September 2026: "Checks should be used only for system development ... We are not
//   building a brute-force system"): its right hand's voicings are voice-led within the widest interval its hand spans
//   (HAND_SEMITONES, from the piano planner's own reach, shared/performers/piano.js); a run is one hand's, a step at a
//   time at no more than a finger's rate; and while its right hand runs, its left hand comps, the chord's third and
//   seventh (and its root where no bass is heard), as a jazz pianist's does under a line. Its left hand otherwise plays
//   the root, and its fifth, where no bass is heard (a pianist leaves the root to the bassist who has it). The full
//   planner is the reference in its tests (test/piano-clodbot.test.mjs), never asked while it plays.
// - **The meter's groups.** It comps on the meter's groups (in 7/8 as 2+2+3) and, the busier the room, on some of its
//   other felt beats and offbeats.
// - **A fantasy piano's keyboard.** Its keys are wherever its pitches are: a quarter tone, a just third or a maqam's
//   neutral second sounds exactly, and it takes the band's tuning plan (the user, 29 September 2026: "our fantasy piano
//   should be fully capable of microtones"). A spec may ask for a fixed keyboard (`keyboard: 'fixed'`), where a pitch
//   between its keys has no key, so it is left out, never rounded (the report's §1.4: open-world, not permissive;
//   piano.js refuses it), and a tuning plan is declined. Its keys may be another tuning's (`keys`): 31 equal steps an
//   octave, as Fokker's organ's, or a meantone's twelve -- each key in every octave, what lies between them left out.
// - **Its chords voiced** (the user, 29 September 2026: "these 'voicings' within chords should produce subtle senses of
//   melody from chord to chord as some notes receive more emphasis", and "In-chord voicing can sometimes result in subtle
//   differences of attack time among the notes in a chord"). Its right hand brings out its top voice, or the voice that
//   moves where the top holds, struck harder, as Goebl's (2001) pianists did; its keys go down together, and each
//   hammer reaches its string in its own time, so the note brought out sounds first (PIANO_CLODBOT.voicing).
// - **Comp and run as one continuum,** as the drummer's groove and fill (figure-blend.js): a run over the bar, up the
//   space's scale from its voicing's top toward the next downbeat, is its fill. settings.fillness (a number, bar
//   points or 'solo') stands it anywhere between them, its run's notes entering where the bar is weakest and its comp's
//   chords leaving there first; 'solo' is a solo's course of its own, building to a climax (soloArc), its runs denser,
//   faster and louder toward it.
// - **The band's attention** (HearsAttention; shared/attention.js). Where ManageBOT gives it the solo, it takes that
//   course over the section, its arc read from the section's progress; wherever attention is heard, a run's claim over
//   its allowance is given back as loudness (none with a soloist's share, which lets its runs be fast and loud at once).
// - **Its pedal and its left hand** (the planner's four durations: piano.js §4.4). Its left hand holds the bass to its
//   next strike, legato, as long as the note rings (articulation.js pianoRing); a run is half-pedalled (PIANO.halfPedal),
//   so each note sounds on a little after its key, and the chord its right hand leaves for the run with it.
// - **Its sustain pedal, for sustained textures** (the backlog: "the pianist's sustain pedal for sustained textures"), as
//   deep as the band's character is spacious and atmospheric (shared/aesthetic.js: its space, its attack; pedalDepth):
//   its right hand's chord sounding on toward its hands' next strike, as its left hand's bass does, and a run's notes
//   ringing on toward the bar's end, the pedal lifted at each, so each harmony rings into the next without blurring
//   them. A dry or spiky piece, or none heard: as it has played.
import {defineBot} from '../../framework/index.js';
import {JazzVoicingClodbot} from './jazzvoicing_clodbot.js';
import {PerformedTiming} from '../lib/modules/performed-timing.js';
import {HearsAttention} from '../lib/modules/attention.js';
import {InstrumentPerformer} from '../lib/modules/instrument-performer.js';
import {pianoRing} from '../../shared/articulation.js';
import {PIANO,keyX} from '../../shared/performers/piano.js';
import {secondsPerTick} from '../../shared/meter-tactus.js';
import {blendLevel,metricalWeight,rankThresholds} from '../../shared/performers/figure-blend.js';
import {modulo,near} from '../lib/pitch-helpers.js';
import {chordTones} from '../lib/voice-leading-bot.js';
import {broughtOut} from '../../shared/performers/chord-voicing.js';
import {phraseRun} from '../../shared/performers/run-phrase.js';
import {figure,inspiredFigure,figurePayload} from '../../shared/performers/figuration.js';
import {bandMeter,bandPhraseBars} from '../../shared/opening-time.js';
import {metricalGrid,pulsed} from '../../shared/performers/section-voices.js';
import {leadVoices,spreadVoices} from '../../shared/performers/compound-melody.js';
import {planLine,followHarmony} from '../../shared/performers/line.js';
import {counterLine,drawnRules} from '../../shared/conducting/counterpoint.js';
import {instrumentRange} from '../../shared/performers/instrument-ranges.js';

export {broughtOut};

export const PIANO_CLODBOT=Object.freeze({
  // Its left hand's register (MIDI), its root the lowest there; and where its left hand's comping sits over a bass heard,
  // an octave from C3 (ours: a jazz pianist's left-hand voicings sit just below middle C).
  bass:Object.freeze([36,50]),shell:48,
  // The run's notes a felt beat (4, 3 where the beat divides in three), up to twice as many at a solo's climax.
  perBeat:4,
  // Levels (velocity): the comp's, the left hand's, a run's (ours: a run a little under the comp, its top at a solo's peak).
  comp:.5,left:.46,run:.42,runTop:.85,
  // How often its left hand walks a figuration under a comp chord instead of holding its bass (figuration.js: an Alberti
  // bass, a broken chord, every state between), a share drawn once a piece (the square of a uniform draw over `share`:
  // most pianists seldom, some often), and the figure's own draws (how many tones, how often it turns, how surely its
  // root takes the strong positions, its rate a share of as many notes a second as its keys repeat). Ours.
  figuration:Object.freeze({share:Object.freeze([0,1]),tones:Object.freeze([3,4]),turn:Object.freeze([.4,1]),anchor:Object.freeze([.6,1]),rate:Object.freeze([.15,.4]),inspiration:Object.freeze([0,1])}),
  // Its texture a phrase (the owner, 3 October 2026: "the piano doesn't play a diversity of textures. Move toward
  // considering textures primarily in terms of counterpoint, and arpeggios and related textures (e.g., alberti bass ...)
  // in terms of compound melodies within that counterpoint"), drawn at each phrase's start by these weights: its right
  // hand's chords struck (`chords`), broken -- its voicing's voices walked as a compound melody, each led from chord to
  // chord as the voicing leads it (`broken`) -- or a line of its own planned over the phrase (`line`); and its left hand's
  // bass held (`bass`), walked as a compound melody of its chord's tones (`figure`: an Alberti bass and every state
  // between), or, under a line, a second line planned against it by the counterpoint's rules (`counter`: two voices, an
  // invention's). Ours.
  textures:Object.freeze({right:Object.freeze({chords:1,broken:1,line:1}),left:Object.freeze({bass:1,figure:1,counter:1}),
    // (Its right hand's line's register and its left hand's, MIDI; a line's level and its counter's.)
    lineRegister:Object.freeze([64,88]),counterRegister:Object.freeze([36,60]),line:.52,counter:.46}),
  // How far a run climbs, in scale steps, over a bar (ours: about an octave and a half).
  climb:10,
  // A run's shape (the user, 29 September 2026: "even quite fast passagework should still be subject to good contour
  // principles with respect to overall shape (and regarding preferring not repeating climaxes/apexes)"), by the line's
  // rules (line.js runContour, 0f's: one apex, a leap answered by a step back, no note three times running, never the
  // last phrase's apex) over the scale's tones from `below` steps under its voicing's top to its climb over it: a phrase's
  // runs arch to one climax, its `climax` share of the way through (the bar that holds it reaches the phrase's apex, the
  // bars before climb toward it, the bars after stay under it), never on the phrase before's apex; a scalar run may go
  // `runMost` moves one way (an octave of the scale); never a key twice running (c2's invariant, piano.js B03).
  runShape:Object.freeze({below:7,climax:.6,runMost:7}),
  // Its sampled piano's level (samples: sample-banks.json salamanderPiano, whose layers carry the velocity's dynamic):
  // the engine's level for a recording at full velocity (audio.js pitched), before the bank's trim.
  sampleLevel:.565,
  // Its keyboard: a fantasy piano's, whose keys are wherever its pitches are (microtones sounded exactly, the tuning
  // plan taken; the user, 29 September 2026: "our fantasy piano should be fully capable of microtones"), unless a spec
  // asks for a fixed one ('fixed'), where a pitch between its keys is left out: its keys `keys` an octave, a count of
  // equal steps from C (12, a piano's; 31, Fokker's organ's) or their pitch classes (semitones from C: a meantone's
  // twelve), each a key in every octave, and a pitch within `keyTolerance` of one its key (semitones: 5 cents).
  keyboard:'fantasy',keys:12,keyTolerance:.05,
  // A chord's voicing, as pianists voice one (Goebl 2001, "Melody lead in piano performance: Expressive device or
  // artifact?", JASA 110(1), 563-572, doi:10.1121/1.1376133: 22 pianists on a Bösendorfer SE290). Every one played the
  // melody loudest (Fig. 6: its final hammer velocity near 1.0-1.1 m/s, the other voices' 0.6-0.7): about 1.7 times
  // theirs (`ratio`). The keys of a chord go down together; a harder-struck hammer reaches its string sooner, so the
  // brought-out note sounds first, 20 to 30 ms before the rest (the velocity artifact, which the study's finger-key
  // onsets confirm). Its travel times, key to string (ms), at the study's seven final hammer velocities (m/s), as its
  // Fig. 5 plots them (the mean timing correction matrix): `travel`. A velocity of ours spans the hammer velocities its
  // pianists played, logarithmically (`fhv`: 0.21 to 4.26 m/s, their inverse hammer velocities of about 600 and 30:
  // footnote 6).
  voicing:Object.freeze({ratio:1.7,fhv:Object.freeze([.21,4.26]),
    travel:Object.freeze([[.32,163],[.5,125],[.8,98],[1.28,77],[2,60],[3.2,46],[5.12,33]].map(Object.freeze))}),
});

// ---- A chord's voicing -----------------------------------------------------------------------------------------------
const clamp01=value=>Math.max(0,Math.min(1,value));
// A velocity of ours (0 to 1) as a final hammer velocity (m/s), and back.
export const hammerVelocity=velocity=>{const [low,high]=PIANO_CLODBOT.voicing.fhv;return low*(high/low)**clamp01(velocity)};
export const velocityOfHammer=fhv=>{const [low,high]=PIANO_CLODBOT.voicing.fhv;return clamp01(Math.log(fhv/low)/Math.log(high/low))};
// A hammer's travel from key to string (s) at a final hammer velocity: between the study's measured points, linear in
// log-log (they lie near a power law), and along its end segments beyond them.
export function hammerTravel(fhv){
  const points=PIANO_CLODBOT.voicing.travel,x=Math.log(Math.max(1e-3,fhv));
  let k=1;while(k<points.length-1&&x>Math.log(points[k][0]))k++;
  const [[x0,y0],[x1,y1]]=[points[k-1],points[k]].map(([v,ms])=>[Math.log(v),Math.log(ms)]);
  return Math.exp(y0+(y1-y0)*(x-x0)/(x1-x0))/1000;
}
// A chord voiced: each note's velocity (the one brought out struck `ratio` times harder, as a hammer velocity: its top
// voice, or the voice that moves by step where the top holds, chord-voicing.js broughtOut) and when it sounds after the
// one brought out (s): its keys struck together, each hammer's travel its own. -> {line, notes: [{pitch, velocity,
// lag}]}; `lastLine`: the note brought out last (an inner line going on in its voice); `extra`: notes struck with it at
// their own velocities (the other hand's).
export function voiceChord(pitches,velocity,{previous=null,lastLine=null,extra=[]}={}){
  if(!pitches.length)return {line:null,notes:extra.map(note=>({...note,lag:0}))};
  const line=broughtOut(pitches,previous,lastLine),{ratio}=PIANO_CLODBOT.voicing;
  const loud=velocityOfHammer(hammerVelocity(velocity)*ratio),first=hammerTravel(hammerVelocity(loud));
  const lag=v=>Math.max(0,hammerTravel(hammerVelocity(v))-first);
  const notes=pitches.map((pitch,index)=>{const v=index===line?loud:velocity;return {pitch,velocity:v,lag:lag(v)}});
  return {line,notes:[...notes,...extra.map(note=>({...note,lag:lag(note.velocity)}))]};
}

// The widest interval one hand spans from any key of the keyboard, in semitones: the planner's reach from thumb to
// little finger (piano.js PIANO.reach), over the keys' own positions (keyX). 14, a major ninth: a fifteenth semitone is
// 212 mm from some keys, past its 200.
export const HAND_SEMITONES=(()=>{
  const reach=PIANO.reach.thumbPair.at(-1),spans=n=>{for(let key=PIANO.lowestKey;key+n<=PIANO.highestKey;key++)if(keyX(key+n)-keyX(key)>reach+1e-9)return false;return true};
  let n=0;while(spans(n+1))n++;return n;
})();

// The instrument clodbots' shared principles (instrument-performer.js): its felt beats, its comp on the meter's groups,
// comp and run as one continuum, a solo's course, its license under the band's attention.
export class PianoClodbot extends InstrumentPerformer(JazzVoicingClodbot,{name:'piano_clodbot',kinds:['comp','left','run']}) {
  // Its instrument in the registry (instrument-ranges.js): its keys' compass.
  static instrument='piano';
  constructor(send,audio,settings={}){
    super(send,audio,settings);
    const keyboard=settings.keyboard??PIANO_CLODBOT.keyboard;
    if(!['fantasy','fixed'].includes(keyboard))throw new RangeError(`A pianist's keyboard is fantasy or fixed, not ${keyboard}`);
    this.keyboard=keyboard;this.previousVoicing=null;this.previousLine=null;
    // (A fixed keyboard's keys, as pitch classes: settings.keys, a count of equal steps or the classes themselves.)
    const keys=settings.keys??PIANO_CLODBOT.keys;
    const classes=Array.isArray(keys)?keys.map(Number):Number.isInteger(Number(keys))&&Number(keys)>=1&&Number(keys)<=96?Array.from({length:Number(keys)},(_,k)=>k*12/Number(keys)):null;
    if(!classes?.length||!classes.every(pc=>Number.isFinite(pc)&&pc>=0&&pc<12))throw new RangeError('A pianist\'s keys are a count of equal steps an octave (1 to 96) or their pitch classes, each from 0 to 12');
    this.keyClasses=[...new Set(classes.map(pc=>+pc.toFixed(6)))].sort((a,b)=>a-b);
    // (How often its left hand figures, a spec's range for its share: [0, 0] never, [1, 1] under every chord.)
    const range=settings.figuration;
    if(range!=null&&!(Array.isArray(range)&&range.length===2&&range.every(x=>Number.isFinite(Number(x))&&x>=0&&x<=1)&&range[0]<=range[1]))throw new RangeError('A pianist\'s figuration is a range [low, high] within 0 to 1');
    this.figurationRange=range?range.map(Number):null;
    // (How far its figures take after the others' it hears, settings.inspiration, 0 to 1; else drawn once a piece.)
    if(settings.inspiration!=null&&!(Number(settings.inspiration)>=0&&Number(settings.inspiration)<=1))throw new RangeError('A pianist\'s inspiration is a share from 0 to 1');
    if(settings.inspiration!=null)this.inspiration=Number(settings.inspiration);
    // (Its textures' weights, settings.textures {right, left}: a spec's own, each hand's where it gives one, else ours.)
    const textures=settings.textures;
    if(textures!=null){
      const valid=(given,known)=>given==null||typeof given==='object'&&Object.entries(given).every(([name,w])=>name in known&&Number.isFinite(Number(w))&&Number(w)>=0)&&Object.values(given).some(w=>Number(w)>0);
      if(typeof textures!=='object'||!valid(textures.right,PIANO_CLODBOT.textures.right)||!valid(textures.left,PIANO_CLODBOT.textures.left))
        throw new RangeError(`A pianist's textures are weights for its right hand (${Object.keys(PIANO_CLODBOT.textures.right).join(', ')}) and its left (${Object.keys(PIANO_CLODBOT.textures.left).join(', ')})`);
    }
    this.textureWeights={right:{...(textures?.right??PIANO_CLODBOT.textures.right)},left:{...(textures?.left??PIANO_CLODBOT.textures.left)}};
    this.bars=[];this.runPlan=null;this.hands=null;
    // Its right hand's voicings within its hand's span (jazzvoicing_clodbot leads its voices within voicingSpan).
    this.voicingSpan=HAND_SEMITONES;
  }
  // A key for a pitch: on the fantasy piano, the pitch itself; on a fixed keyboard its key, or null where it has none
  // (a pitch between its keys); on either, null beyond its keys' compass (the instrument registry's, instrument-ranges.js:
  // a piano's A0 to C8, a harpsichord's F1 to F6), a pitch no key reaches left out as one between its keys is.
  keyOf(pitch){
    if(!Number.isFinite(pitch))return null;
    const [low,high]=instrumentRange(this.constructor.instrument).range,tolerance=PIANO_CLODBOT.keyTolerance+1e-9;
    return pitch<low-tolerance||pitch>high+tolerance?null:this.keyNear(pitch);
  }
  // Its nearest key to a pitch in any octave (a pitch class's: keyClass), or null where none is within keyTolerance.
  keyNear(pitch){
    if(this.keyboard==='fantasy')return pitch;
    const octave=Math.floor(pitch/12),within=pitch-12*octave;let near=null;
    for(const pc of this.keyClasses)for(const key of [pc-12,pc,pc+12])if(near===null||Math.abs(within-key)<Math.abs(within-near))near=key;
    const key=12*octave+near;return Math.abs(pitch-key)<=PIANO_CLODBOT.keyTolerance+1e-9?+key.toFixed(6):null;
  }
  // A pitch class as its keyboard has it: as the pool heard tunes it (native-intonation.js poolTuned), exact on the
  // fantasy piano, a key's on a fixed one, or null where it has none.
  keyClass(pc){const tuned=modulo(this.poolTuned(modulo(pc,12)),12);if(this.keyboard==='fantasy')return tuned;const key=this.keyNear(tuned);return key===null?null:+modulo(key,12).toFixed(6)}
  // A fixed keyboard takes no tuning plan (a pitch between its keys would be left out); the fantasy piano takes it.
  setCapabilities(value={}){super.setCapabilities?.({...value,...(this.keyboard==='fixed'?{tuning:false}:{})})}
  // The left hand's notes for a chord: its root low, and its fifth, where no bass is heard.
  leftHand(clock){
    const chord=this.chord;if(!chord||this.bassHeard(clock)!==null)return [];
    // (A root without a key: no left hand.)
    const rooted=this.keyClass(chord.root);if(rooted===null)return [];
    const [low,high]=PIANO_CLODBOT.bass,root=low+modulo(rooted-low,12);
    // Its fifth as the chord has it (a tuning's or a collection's, on the fantasy piano), else a tempered fifth.
    const fifths=chordTones(chord).map(pc=>this.keyClass(pc)).filter(pc=>pc!==null).map(pc=>root+modulo(pc-root,12)).filter(pitch=>Math.abs(pitch-root-7)<=1),fifth=fifths[0]??root+7;
    // (Each sounded as its key: a tempered fifth within a key's tolerance of one, that key's pitch.)
    return [root,...(fifth<=high+7?[fifth]:[])].map(pitch=>this.keyOf(pitch)).filter(key=>key!==null);
  }
  // Its left hand's comping while its right hand runs: two of the tones the chord's reading dearest to its taste
  // requires, the rest of its tones after (chord-readings.js: a jazz pianist's third and seventh under a line, a
  // common-practice player's third and fifth, the harmony as heard its own). Where no bass is heard, over its root, within
  // an octave of it; over a bass heard, an octave from PIANO_CLODBOT.shell. Either way within its hand's span.
  leftComp(clock){
    const chord=this.chord;if(!chord)return [];
    const read=[...this.readingsOf(clock)].sort((a,b)=>a.cost-b.cost)[0];if(!read)return [];
    const rootPc=read.roles.root??chord.root,root=this.keyClass(rootPc),others=list=>list.filter(pc=>!near(pc,rootPc));
    const guides=[...others(read.required),...others(read.pcs).filter(pc=>!read.required.includes(pc))].slice(0,2).map(pc=>this.keyClass(pc)).filter(pc=>pc!==null);
    // (A root without a key, and no bass heard: no shell under nothing.)
    if(root===null&&this.bassHeard(clock)===null)return [];
    const [low]=PIANO_CLODBOT.bass,base=low+modulo(root-low,12),shell=PIANO_CLODBOT.shell;
    const pitches=this.bassHeard(clock)===null?[base,...guides.map(pc=>base+(modulo(pc-base,12)||12))]:guides.map(pc=>shell+modulo(pc-shell,12));
    return [...new Set(pitches.map(pitch=>this.keyOf(pitch)).filter(key=>key!==null))].sort((a,b)=>a-b);
  }
  // Sounding a comp chord: its right hand's voicing (on the keys it has; within its hand's span by construction) and its
  // left hand's root and fifth; or, in a bar its right hand runs, its left hand's comping alone (leftComp).
  sound(clock,pitches,seconds,velocity=this.vl.velocity){
    const compLevel=this.compLevelAt(clock);if(!(compLevel>0))return;
    // The piece's last bar (Closure, from form_clodbot's closing): its chord held as any, to its next strike, and no run (0f, 28
    // September, on 05b: the comping piano "just seems to stop").
    const final=this.closing?.phase==='final';
    if((clock.tickInBar??0)===0&&!final)this.planRun(clock);
    const running=!final&&this.runPlan?.bar===clock.bar&&this.runPlan.notes.length>0;
    // (Its phrase's texture: a line in its right hand strikes no chord, a counter in its left no bass -- their lines are
    // played as they come, playLines.)
    const texture=final?null:this.textureFor(clock);if(texture)this.planLines(clock,texture);
    const lined=texture?.right==='line'&&this.lines?.right?.length,countered=lined&&texture.left==='counter'&&this.lines?.left?.length;
    const right=running||lined?[]:pitches.map(pitch=>this.keyOf(pitch)).filter(key=>key!==null);let left=countered?[]:running?this.leftComp(clock):this.leftHand(clock);
    if(!running&&!lined&&right.length<pitches.length)this.decide({tick:clock.tick,offKeys:pitches.filter(pitch=>this.keyOf(pitch)===null)});
    // Its hands' next strike: the bar's next comp chord that sounds, else the bar's end. A key struck again is let go and
    // reset first (piano.js, B03).
    const spt=secondsPerTick(clock),tick=clock.tickInBar??0,now=tick*spt;
    const strikes=(this.comp?.bar===clock.bar?this.comp.hits:[]).filter(at=>at>tick&&this.compLevelAt({...clock,tickInBar:at})>0);
    const until=(strikes.length?Math.min(...strikes):clock.meter.pulsesPerBar)*spt-now-PIANO.travel.resetSeconds;
    // Its right hand's chord held as written, to its next strike at most.
    const held=Math.max(PIANO.strokeSeconds,Math.min(until,seconds)),composed=this.compInterval(clock),scoreEnd=readScoreTime(composed).end.sub(clock.tick-tick);
    // Its left hand holds the bass (or its comping) to its next strike, legato, as long as the note rings; and its right
    // hand's chord sounds on toward it as deep as its pedal goes (pedalDepth), the pedal lifted at the strike.
    const bassHeld=pitch=>Math.max(held,Math.min(until,pianoRing(pitch)));
    const depth=this.pedalDepth(),pedalled=pitch=>depth>0?held+depth*(bassHeld(pitch)-held):held;
    const level=Math.max(0,Math.min(1,velocity*compLevel)),leftLevel=running?level:PIANO_CLODBOT.left*compLevel;
    // (Its left hand's figuration under the chord, where its share draws one: its bass's tones walked to its next strike.)
    const figured=!running&&!final&&left.length?this.leftFigure(clock,{now,until,scoreEnd,level:leftLevel,texture}):null;
    if(figured){this.count(clock,'left',figured);left=[]}
    // (Its right hand's chord broken, where its phrase breaks it: its voicing's voices walked to its next strike.)
    const broken=!running&&!final&&texture?.right==='broken'&&right.length>1?this.rightFigure(clock,{now,until,scoreEnd,level,voicing:[...right].sort((a,b)=>a-b)}):0;
    if(broken){this.count(clock,'broken',broken);this.previousVoicing=[...right].sort((a,b)=>a-b);right.length=0;if(!left.length){this.count(clock,'comp');return}}
    // Its right hand's chord voiced (the note that makes a line brought out, sounding first), its left hand's struck with
    // it: each key down at once, each hammer at the string in its own time.
    const sorted=[...right].sort((a,b)=>a-b),voiced=voiceChord(sorted,level,{previous:this.previousVoicing,lastLine:this.previousLine,extra:left.map(pitch=>({pitch,velocity:leftLevel,left:true}))});
    for(const note of voiced.notes)withScoreTime(this.audio,composed,()=>this.key(note.pitch,Math.max(PIANO.strokeSeconds,(note.left?bassHeld(note.pitch):pedalled(note.pitch))-note.lag),note.velocity,0,note.lag));
    if(sorted.length){this.previousVoicing=sorted;this.previousLine=voiced.line!==null?sorted[voiced.line]:null}
    this.count(clock,'comp');this.count(clock,'left',left.length);
    this.hands={tick:clock.tick,left,right:sorted,held,...(voiced.line!==null?{line:sorted[voiced.line],leadMs:+(1000*Math.max(0,...voiced.notes.map(note=>note.lag))).toFixed(1)}:{}),
      ...(left.length?{bassHeld:Math.min(...left.map(bassHeld))}:{}),...(running?{under:'run'}:{})};
  }
  // Its left hand's figuration for a comp chord (PIANO_CLODBOT.figuration): where this chord's draw falls under its share,
  // the chord's tones in its left hand's register -- its root, third, fifth and octave as the chord has them -- walked
  // over the meter's positions from `now` to its next strike (`until`). -> how many notes it struck, or 0.
  leftFigure(clock,{now,until,scoreEnd,level,texture=null}){
    const f=PIANO_CLODBOT.figuration,draw=key=>this.random(`figuration:${key}`)(),across=([a,b],u)=>a+(b-a)*u;
    this.figureShape??={share:across(this.figurationRange??f.share,draw('share')**2),tones:Math.round(across(f.tones,draw('tones'))),turn:across(f.turn,draw('turn')),anchor:across(f.anchor,draw('anchor')),rate:across(f.rate,draw('rate'))};
    // (Its figure moved toward the last another player said, as far as its inspiration: figuration.js inspiredFigure.)
    this.inspiration??=across(f.inspiration,draw('inspiration'));
    // (Its share its phrase's texture's -- under every chord where its left hand figures, none where it holds its bass --
    // unless a spec gives it a range.)
    const shape=inspiredFigure(this.figureShape,this.heardFigure,this.inspiration,{tones:f.tones}),chord=this.chord;
    const share=this.figurationRange||!texture?shape.share:texture.left==='figure'?1:0;
    if(!chord||!(this.random(`figure:${clock.bar}:${clock.tickInBar??0}`)()<share)||!(until>.15))return 0;
    const rooted=this.keyClass(chord.root);if(rooted===null)return 0;
    const [low,high]=PIANO_CLODBOT.bass,root=low+modulo(rooted-low,12);
    const chordPitches=[...new Set([root,...chordTones(chord).map(pc=>this.keyClass(pc)).filter(pc=>pc!==null).map(pc=>root+modulo(pc-root,12)),root+12])].filter(pitch=>pitch<=high+12).map(pitch=>this.keyOf(pitch)).filter(key=>key!==null).sort((a,b)=>a-b);
    if(chordPitches.length<2)return 0;
    // (A compound melody (compound-melody.js): its voices -- the root on the strong positions, the others above it -- led
    // from the last chord's by the least motion, the root its own.)
    const n=Math.max(2,Math.min(chordPitches.length,shape.tones)),upper=chordPitches.filter(pitch=>pitch>chordPitches[0]+1e-6);
    const led=this.leftVoices?.length===n&&upper.length?leadVoices(this.leftVoices.slice(1),upper):spreadVoices(upper,n-1);
    const tones=[chordPitches[0],...led].sort((a,b)=>a-b);this.leftVoices=tones;
    const spt=secondsPerTick(clock),beat=spt*(clock.meter.subdivision||bandMeter().subdivision),{positions,barSeconds}=metricalGrid(clock.meter,beat);
    const notes=figure({set:tones,positions,barSeconds,scoreEnd,start:0,seconds:scoreEnd.toNumber()*spt,rate:shape.rate/PIANO.strokeSeconds,shortest:PIANO.strokeSeconds,tones:tones.length,direction:1,turn:shape.turn,anchor:shape.anchor,random:this.random(`figure:${clock.bar}:walk`)}).filter(note=>note.at>=now-1e-9);
    for(const note of notes)withScoreTime(this.audio,shiftScoreTime(note.scoreTime,clock.tick-(clock.tickInBar??0),{axis:'ensemble'}),()=>this.key(note.pitch,Math.max(PIANO.strokeSeconds,note.seconds),Math.max(0,Math.min(1,level*(note.index===0?1:.85))),note.at-now));
    // (Said for the others, once a bar it figures in.)
    if(notes.length&&this.figureSaid!==clock.bar){this.figureSaid=clock.bar;this.broadcast?.('figure',[figurePayload(this.instanceId??'piano_clodbot',shape,clock.bar)])}
    return notes.length;
  }
  // Its phrase's texture (PIANO_CLODBOT.textures): {right, left}, drawn once a phrase from the phrase's own draw; its left
  // hand never countering a right hand that plays no line.
  textureFor(clock){
    const phraseBars=Math.max(1,Number(clock.meter?.phraseBars)||bandPhraseBars()),phrase=Math.floor((Number(clock.bar)||0)/phraseBars);
    if(this.texture?.phrase===phrase)return this.texture;
    const {right,left}=this.textureWeights,random=this.random(`texture:${phrase}`),pick=weights=>{const total=Object.values(weights).reduce((a,b)=>a+b,0);let u=random()*total;for(const [name,w] of Object.entries(weights)){u-=w;if(u<0)return name}return Object.keys(weights).at(-1)};
    const hand=pick(right),under=pick(left);
    this.texture={phrase,phraseBars,right:hand,left:hand!=='line'&&under==='counter'?'figure':under};this.lines=null;
    return this.texture;
  }
  // Its right hand's chord broken (a compound melody: compound-melody.js): its voicing's voices, as the voicing leads them,
  // walked over the meter's positions from `now` to its next strike (`until`), its lowest on the strong positions as
  // surely as its figure anchors, its top brought out. -> how many notes it struck, or 0.
  rightFigure(clock,{now,until,scoreEnd,level,voicing}){
    if(!(until>.15)||voicing.length<2)return 0;
    const f=PIANO_CLODBOT.figuration,draw=key=>this.random(`rightFigure:${key}`)(),across=([a,b],u)=>a+(b-a)*u;
    this.rightShape??={turn:across(f.turn,draw('turn')),anchor:across(f.anchor,draw('anchor')),rate:across(f.rate,draw('rate'))};
    const spt=secondsPerTick(clock),beat=spt*(clock.meter.subdivision||bandMeter().subdivision),{positions,barSeconds}=metricalGrid(clock.meter,beat);
    const notes=figure({set:voicing,positions,barSeconds,scoreEnd,start:0,seconds:scoreEnd.toNumber()*spt,rate:this.rightShape.rate/PIANO.strokeSeconds,shortest:PIANO.strokeSeconds,tones:voicing.length,direction:1,turn:this.rightShape.turn,anchor:this.rightShape.anchor,random:this.random(`rightFigure:${clock.bar}:${clock.tickInBar??0}`)})
      .filter(note=>note.at>=now-1e-9);
    const top=voicing.length-1;
    for(const note of notes)withScoreTime(this.audio,shiftScoreTime(note.scoreTime,clock.tick-(clock.tickInBar??0),{axis:'ensemble'}),()=>this.key(note.pitch,Math.max(PIANO.strokeSeconds,note.seconds+this.pedalRing(note.pitch,until-(note.at-now))),Math.max(0,Math.min(1,level*(note.index===top?1:.8))),note.at-now));
    return notes.length;
  }
  // Its phrase's lines planned, once a phrase, at the first tick it hears of it (before any strike of it): playLines.
  planLines(clock,texture=this.textureFor(clock)){
    if(this.lines||texture?.right!=='line')return;
    const spt=secondsPerTick(clock),tick=Number(clock.tick)||0,pulses=Number(clock.meter?.pulsesPerBar)||1;
    const pool=(this.poolPcs??[]).map(pc=>this.keyClass(pc)).filter(pc=>pc!==null);if(pool.length<2)return;
    // (From the bar it is in where it hears its downbeat, else from the next, to the phrase's end.)
    const late=(clock.tickInBar??0)>0,left=texture.phraseBars-(Number(clock.bar)||0)%texture.phraseBars-(late?1:0),bars=Math.max(1,left),sub=clock.meter.subdivision||bandMeter().subdivision,bpm=60/(spt*sub);
    const from=tick-(clock.tickInBar??0)+(late?pulses:0),phraseSeconds=bars*pulses*spt;
    const meter={...clock.meter,pulsesPerBar:pulses,subdivision:sub},random=this.random(`lines:${texture.phrase}`);
    // (As dense as the band it hears -- its density, the seed's and then its conductor's plans' -- and about its line's level,
    // each note at its phrase's swell there: line.js planLine. It had been a fixed .45, each note at one level.)
    const planned=planLine({register:PIANO_CLODBOT.textures.lineRegister,pool,meter,bpm,bars,density:this.density,loudness:PIANO_CLODBOT.textures.line,phraseIndex:texture.phrase,random});
    // (Each note in the tick it falls in, at its own time there: a line divided finer than the clock's ticks had struck
    // two of its notes at once.)
    const right=planned.status==='planned'?planned.notes.map(note=>{const at=Math.floor(note.start/spt+1e-9);return {scoreTime:shiftScoreTime(note.scoreTime,from,{axis:'ensemble'}),tick:from+at,offset:Math.max(0,note.start-at*spt),pitch:note.pitch,seconds:Math.max(PIANO.strokeSeconds,(note.end-note.start)*.95),velocity:note.velocity}}):[];
    let counter=[];
    if(texture.left==='counter'&&right.length){
      const {positions,barSeconds}=metricalGrid(meter,spt*sub),onsets=[];const own=this.random(`counter:${texture.phrase}`);
      for(let bar=0;bar<bars;bar++)for(const position of positions){const at=bar*barSeconds+position.at;if(at<phraseSeconds-1e-6&&(at<1e-9||pulsed(position.weight,.55,own())))onsets.push({at,scoreAt:bar*pulses+Number(position.scoreAt)})}
      const [low,high]=PIANO_CLODBOT.textures.counterRegister,steps=[];for(let octave=2;octave<=5;octave++)for(const pc of pool){const pitch=12*octave+pc;if(pitch>=low&&pitch<=high)steps.push(pitch)}
      const strong=t=>{const within=((t%barSeconds)+barSeconds)%barSeconds;return positions.some(position=>position.weight>=.75&&Math.abs(position.at-within)<1e-6)};
      const above=right.map(note=>({pitch:note.pitch,start:(note.tick-from)*spt,length:note.seconds}));
      const {line}=counterLine({against:[above],rhythm:onsets.map((point,k)=>({start:point.at,length:(onsets[k+1]?.at??phraseSeconds)-point.at,scoreTime:scoreTime(from+point.scoreAt,(onsets[k+1]?.scoreAt??bars*pulses)-point.scoreAt)})),steps:[...new Set(steps)].sort((a,b)=>a-b),
        rules:drawnRules(random,{voices:2,classes:pool.length}).rules,strong,random,above:false});
      counter=line.map(note=>({...scoreTimeFields(note),tick:from+Math.round(note.start/spt),pitch:note.pitch,seconds:Math.max(PIANO.strokeSeconds,note.length*.95),strong:strong(note.start)}));
    }
    this.lines={right,left:counter,last:{right:null,left:null}};
  }
  // Its phrase's lines, where its texture plays them: its right hand's planned at the phrase's first tick it hears (line.js
  // planLine, in its right hand's register, as a melodic player's phrase is), its left hand's, where it counters, planned
  // against it (counterpoint.js counterLine: a rhythm of its own over the meter's positions, the rules a blend drawn for
  // two voices); each note played as its tick comes, in the harmony sounding then -- the right hand's as the line's are
  // (followHarmony), the counter's on a strong position the harmony's, on a weak one its own by step.
  playLines(clock){
    const texture=this.closing?.phase==='final'?null:this.textureFor(clock);if(texture?.right!=='line')return;
    this.planLines(clock,texture);if(!this.lines)return;
    const tick=Number(clock.tick)||0;
    const pool=(this.poolPcs??[]).map(pc=>this.keyClass(pc)).filter(pc=>pc!==null);
    for(const hand of ['right','left'])for(const note of this.lines[hand]??[]){
      if(note.tick!==tick)continue;
      const near=pool.length?followHarmony(note.pitch,pool,[note.pitch-12,note.pitch+12]):note.pitch,last=this.lines.last[hand];
      const pitch=hand==='right'?near:note.strong||last==null||Math.abs(note.pitch-last)>2.5+1e-9?near:note.pitch,key=this.keyOf(pitch);this.lines.last[hand]=pitch;
      if(key!==null)withScoreTime(this.audio,note,()=>this.key(key,note.seconds,hand==='right'?note.velocity??PIANO_CLODBOT.textures.line:PIANO_CLODBOT.textures.counter,note.offset??0));
      this.count(clock,hand==='right'?'line':'counter');
    }
  }
  // How long the half-pedal keeps a note sounding after its key is let go (PIANO.halfPedal: a share of its ring), or 0
  // where the player does not half-pedal.
  halfPedal(pitch){return PIANO.halfPedal?PIANO.halfPedal.share*pianoRing(pitch):0}
  // How deep its sustain pedal goes (0 to 1): as the band's character is spacious and atmospheric; none heard, 0.
  pedalDepth(){const character=this.character;if(!character)return 0;const unit=value=>Math.max(0,Math.min(1,Number.isFinite(value)?value:.5));
    return unit(character.space)*(1-unit(character.attack))}
  // How long a run's note sounds on after its key: the half-pedal's share of its ring, and deeper as the pedal is, to
  // its whole ring at full depth, within `room` (s: the pedal lifted at the bar's end).
  pedalRing(pitch,room=Infinity){
    const half=this.halfPedal(pitch),depth=this.pedalDepth();
    return depth>0?Math.max(half,Math.min(half+depth*(pianoRing(pitch)-half),room)):half;
  }
  // The figures the others say, for its own to take after (and the conductor's planned dynamics: InstrumentPerformer).
  onMessage(message){super.onMessage?.(message);
    if(message?.address==='/broadcast/figure'&&message.args?.[0]&&String(message.args[0].voice)!==String(this.instanceId??'piano_clodbot'))this.heardFigure=message.args[0]}
  // A key struck: the synthesized hammer keys (the keys family), a sampled piano (its layer chosen by the velocity,
  // audio.js samplePitch), or MIDI to a piano outside. Struck `offset` after the tick, its hammer at the string `lag`
  // after that (a chord's keys go down together, each hammer in its own time): it sounds then, and is written with its
  // chord, the lag kept as how it sounded (the engine's expression.lag; a score writes a hammer's travel as no rhythm).
  key(pitch,seconds,asked,offset,lag=0){
    // (Moved by the conductor's planned dynamics, where it plays seated in no section: planned-dynamics.js, on the keys'
    // own velocity curve.)
    const at=offset+lag,velocity=this.plannedVelocity(asked,'keys');
    if(this.audio?.mode==='midi'){this.audio.midiNote?.(pitch,seconds,velocity,undefined,at,{instrument:'keys',profile:'keys',lag});return}
    if(this.audio?.mode==='samples'){this.audio.samplePitch?.(pitch,at,PIANO_CLODBOT.sampleLevel,seconds,velocity,{lag});return}
    this.audio?.voice?.(pitch,seconds,.07,'sawtooth',at,{instrument:'keys',profile:'keys',velocity,lag});
  }
  everyTick(clock){
    super.everyTick?.(clock);
    if((clock.tickInBar??0)===0&&this.closing?.phase!=='final')this.planRun(clock);
    this.playLines(clock);
  }
  // The run, planned once at a bar's start where the fillness asks for one (before the bar's comping, which its left
  // hand then takes): up the space's scale from its voicing's top, a step at a time in its right hand, its notes at the
  // felt beats' subdivisions (faster at a solo's climax, never quicker than a finger: PIANO.fingerSeconds), each at the
  // level the fillness gives it. Half-pedalled; where the band's attention is heard, its claim over its allowance given
  // back as loudness.
  planRun(clock){
    if(this.runPlan?.bar===clock.bar)return;
    this.runPlan={bar:clock.bar,times:[],notes:[]};
    // (None while its right hand plays a line of its own: its line is its run.)
    if(!this.chord||this.textureFor(clock).right==='line')return;
    const fillness=this.fillnessOf(clock)??0,solo=this.soloIntensity(clock);if(!(fillness>0)&&solo===null)return;
    const spt=secondsPerTick(clock),span=clock.meter.pulsesPerBar,felt=this.felt(clock),intensity=solo??0;
    const shortest=Math.min(...felt.map(beat=>beat.length))*spt,finger=Math.max(1,Math.floor(shortest/PIANO.fingerSeconds));
    const perBeat=Math.min(finger,Math.round(PIANO_CLODBOT.perBeat*(1+intensity))),positions=dividedBeats(felt,perBeat);
    const scale=[...new Set((this.scaleFor?.(this.poolPcs??[])??[]).map(pc=>this.keyClass(pc)).filter(pc=>pc!==null).map(pc=>+pc.toFixed(6)))].sort((a,b)=>a-b);
    // (Its chromatic grid its keys: a fixed keyboard's, else the twelve.)
    const grid=this.keyboard==='fixed'?this.keyClasses:Array.from({length:12},(_,k)=>+this.keyClass(k).toFixed(6));
    const steps=this.runSteps(scale,{grid,draw:this.random(`runSteps:${clock.bar}`)()});
    const top=Math.max(...(this.voicing??[60])),climb=Math.round(PIANO_CLODBOT.climb*(1+intensity/2));
    // The notes that sound, each at the level the fillness gives it: the line is shaped over them alone, since a line
    // shaped over every position and then thinned keeps none of its rules (a key twice running, its apex twice).
    const u=this.random(`run:${clock.bar}`),items=positions.map(({at,scoreTime},k)=>({id:`run${k}`,at,scoreTime,weight:metricalWeight(at,{beatStarts:felt.map(beat=>beat.start),span}),position:at/span,u:u()}));
    const thresholds=rankThresholds(items,{order:this.fillOrder});
    const sounding=items.map(item=>({id:item.id,at:item.at,scoreTime:item.scoreTime,level:blendLevel(thresholds.get(item.id),this.fillnessOf(clock,Math.min(span-1e-9,item.at))??0,{entering:true})})).filter(item=>item.level>0);
    // Its pitches shaped as a line over the phrase (runPath), never a key struck again before it is let go and reset
    // (piano.js, B03): a key comes back two notes later at the soonest, a finger's time at least after it was let go.
    const pitches=sounding.length?this.runPath(clock,{from:top,count:sounding.length,steps,climb}):[];
    if(!pitches.length)return;
    const notes=sounding.map((item,k)=>({id:item.id,scoreTime:shiftScoreTime(item.scoreTime,clock.tick-(clock.tickInBar??0),{axis:'ensemble'}),pitch:pitches[k],start:item.at*spt,end:(item.at+span/positions.length*.9)*spt,level:item.level}));
    const level=PIANO_CLODBOT.run+(PIANO_CLODBOT.runTop-PIANO_CLODBOT.run)*intensity;
    // Its license (shared/attention.js): the run's claim over its allowance given back as loudness, none where its share
    // covers it (a soloist's); the arc then only shapes the solo.
    const {heard,claim,givenBackDb}=this.licensed(clock,notes.map(note=>({at:note.start,velocity:level*note.level})));
    for(const note of notes)withScoreTime(this.audio,note,()=>this.key(note.pitch,note.end-note.start+this.pedalRing(note.pitch,span*spt-note.end),this.softer(level*note.level,givenBackDb),note.start));
    this.runPlan={bar:clock.bar,times:notes.map(note=>note.start).sort((a,b)=>a-b),notes:notes.map(note=>({...scoreTimeFields(note),pitch:note.pitch,start:note.start,end:note.end}))};
    this.count(clock,'run',notes.length);
    this.bars.push({bar:clock.bar,fillness:+fillness.toFixed(3),run:notes.length,of:items.length,perBeat,...(solo===null?{}:{intensity:+intensity.toFixed(3)}),
      ...(heard?{attention:{claimDb:claim?+claim.claimDb.toFixed(2):null,allowanceDb:+heard.allowanceDb.toFixed(2),soloing:heard.soloing,givenBackDb:+givenBackDb.toFixed(2)}}:{}),
      pedal:PIANO.halfPedal?'half':null});
    if(this.bars.length>64)this.bars.shift();
  }
  // A run's pitches over the bar: the scale's tones from `below` steps under its voicing's top to `climb` steps over it,
  // shaped by the line's rules under the phrase's plan (run-phrase.js phraseRun: the phrase's apex chosen at its first
  // run, its voicing's top climbed, never the phrase before's apex; the bar holding the phrase's climax reaching it, the
  // bars before climbing toward it a step a bar, the bars after under it). [] where no run in the range keeps the rules
  // (the bar's comp plays instead).
  runPath(clock,{from,count,steps,climb}){
    // Twice the range each way, for phraseRun to count its `below` and `climb` in pitches heard, once the band's tuning
    // has made those it rounds together one.
    const {below}=PIANO_CLODBOT.runShape,tones=[];let pitch=this.scaleStep(from,0,steps);
    for(let k=0;k<2*below;k++)pitch=this.scaleStepDown(pitch,steps);
    const ceiling=this.scaleStep(from,2*climb,steps);
    for(let guard=0;pitch<=ceiling+1e-6&&guard<400;guard++){tones.push(pitch);pitch=this.scaleStep(pitch,1,steps)}
    const {pitches,state}=phraseRun({tones,from,below,above:climb,count,bar:clock.bar,phrase:clock.phrase??0,phraseBars:clock.meter?.phraseBars,state:this.runPhrase??null,
      randomFor:reach=>this.random(`runContour:${clock.bar}:${reach}`),sound:pitch=>this.audio?.tunePitch?.(pitch),choices:PIANO_CLODBOT.runShape});
    this.runPhrase=state;
    return pitches;
  }
  // A scale step down from a pitch: the scale tone just under it.
  scaleStepDown(from,steps){
    const octave=Math.floor(from/12)*12,tones=[-24,-12,0,12].flatMap(shift=>steps.map(pc=>octave+shift+pc)).sort((a,b)=>a-b);
    let below=tones[0];for(const pitch of tones)if(pitch<from-1e-6)below=pitch;
    return +below.toFixed(6);
  }
  // A scale step up from a pitch: the n-th scale tone above it (n = 0 is the pitch itself, or the tone just above), the
  // scale's pitch classes whatever their tuning.
  scaleStep(from,n,steps){
    const octave=Math.floor(from/12)*12,tones=[-12,0,12,24].flatMap(shift=>steps.map(pc=>octave+shift+pc)).sort((a,b)=>a-b);
    const first=tones.findIndex(pitch=>pitch>=from-1e-6),index=first+n;
    while(index>=tones.length)tones.push(tones.at(-steps.length)+12);
    return +tones[index].toFixed(6);
  }
}

export const PerformedPiano=HearsAttention(PerformedTiming(PianoClodbot,{instrument:'comping'}));
export const pianoClodbot=defineBot(
  {
    id: "piano_clodbot", name: "piano_clodbot", status: "native", source: "clodbot",
    category: "harmony", midiChannel: 1, performanceType: "polyphonic", outputModes: ["synth", "samples", "midi"],
    // Two hands: its part written on a grand staff, whatever its range (notation/score.js).
    hands: 2,
    // A sampled acoustic piano where it has been fetched (scripts/download-piano-samples.mjs), its synth elsewhere.
    sampleBank: "salamanderPiano",
    // Pitched, its pitches floating: the fantasy piano takes the tuning plan (a fixed keyboard declines it: setCapabilities).
    pitchContract: "floating-mpe",
    specSettings: Object.freeze(["fillness", "fillOrder", "density", "keyboard", "keys", "chromatic", "figuration", "inspiration"]),
    description:
      "A pianist whose two hands play only what a pianist's can, by construction: its right hand voicing the band's harmony as jazzvoicing_clodbot does within its hand's span, its left the root and fifth where no bass is heard, held legato to its next strike, and comping under its right hand's runs; comping on the meter's groups (in 7/8 as 2+2+3); its chords voiced, the note that makes a line brought out and sounding first, as a hammer struck harder reaches its string sooner; a fantasy piano's keyboard, microtones exact and the tuning plan taken (or a fixed one, where a pitch between its keys is left out); comp and run as one continuum (settings.fillness), its runs half-pedalled; a solo's course building to a climax ('solo', or where the band's attention gives it one), its runs within the allowance the band's attention gives it.",
  },
  (...args) => new PerformedPiano(...args),
);
