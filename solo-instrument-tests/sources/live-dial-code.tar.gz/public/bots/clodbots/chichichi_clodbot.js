// chichichi_clodbot: a fork of Chichichi that strikes each cell of its pattern once a bar, in every meter (the
// mathematical audit's B06; the user, 27 September 2026: "fix in forked form"). Made from the class it forks, which
// agents.js holds, by a function, so this file imports nothing from agents.js; Chichichi itself is unchanged.
//
// Chichichi's patterns are sixteen cells, and each host tick asks which cell it falls on. Where the meter's grid is
// finer than sixteen (4/4 counted in thirty-seconds), a cell is struck on every tick it spans; where it is coarser (7/8
// in eighths), some cells are never landed on and never struck. Here each cell belongs to the tick its time falls in, as
// in xbass_clodbot (stepsInTick), so every cell sounds once a bar; cells that share a coarse tick are one strike there,
// the first of them, as one hand strikes once at an instant. Its patterns, its states and their changes are the port's.
import {defineBot} from '../../framework/index.js';
import {unitRandom} from '../../shared/stochastic.js';
import {stepsInTick} from './xbass_clodbot.js';
import {bandTempo,bandMeter} from '../../shared/opening-time.js';
import {writtenOnStep} from '../lib/written.js';

export function chichichiClodbotClass(ChichichiBot){
  class ChichichiClodbot extends ChichichiBot {
    onTick(tick,clock){
      if(clock.barStart&&unitRandom()<this.config.randomStateProbability)this.changeState('any');
      const pattern=this.patterns[this.state],cells=pattern.map((on,cell)=>on?cell:null).filter(cell=>cell!==null);
      const [index]=stepsInTick(cells,clock.tickInBar||0,clock.meter?.pulsesPerBar||bandMeter().pulsesPerBar,this.config.patternLength);
      // (Written on its cell of the bar's sixteen, a cell long, wherever the tick it sounds on falls.)
      const per=clock.meter?.pulsesPerBar||bandMeter().pulsesPerBar;
      if(index!==undefined)writtenOnStep(this.audio,clock.tick-(clock.tickInBar||0),per,this.config.patternLength,index,()=>this.audio.chichichi(index,this.state,60/(clock.bpm||bandTempo()),this.config));
    }
  }
  return ChichichiClodbot;
}
export function defineChichichiClodbot(ChichichiBot){
  const ChichichiClodbot=chichichiClodbotClass(ChichichiBot);
  return defineBot({
      id:'chichichi_clodbot',name:'chichichi_clodbot',status:'native',source:'clodbot',forkOf:'chichichi',
      category:'texture-noise',outputModes:['synth'],pitchContract:'none',
      description:
        'A fork of Chichichi that strikes each cell of its sixteen-cell pattern once a bar in every meter, each at the tick its time falls in, cells sharing a coarse tick as one strike; its patterns and state changes are the port\'s.',
    },(...args)=>new ChichichiClodbot(...args));
}
