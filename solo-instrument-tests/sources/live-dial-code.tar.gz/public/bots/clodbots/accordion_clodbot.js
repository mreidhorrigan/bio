// accordion_clodbot: an accordionist on a piano accordion, the sixth of the instrument clodbots (research/family-atlas.md
// F25, bellows free-reed keyboards and buttons; research/MUSEBOTS_WORLD_INSTRUMENTS_CONSTRAINTS_RESEARCH_AND_IMPLEMENTATION_REPORT.md
// §5.7, §11.5). New, not a fork. Taken by c2 at 2a's offer, 29 September (SESSIONS.md 13:27).
//
// Its harmony is the band's, as jazzvoicing_clodbot reads it; the drummer's principles are the instrument clodbots'
// (instrument-performer.js): comp and figure as one continuum, a solo's course, the band's attention, its arrival at the cadence on
// the last downbeat (Closure). What an accordionist adds (shared/performers/accordion.js):
// - **Its left hand on the Stradella basses, by the meter's own groups.** On each group's head a bass button, the
//   chord's root, and on the bar's later heads its fifth, the next column round (the alternate bass); on the group's
//   other pulses a chord button, the row that says the chord (major, minor, seventh, diminished): a waltz's
//   oom-pah-pah in a group of three, an oom-pah in a group of two, and in 7/8 or 11/8 the figure their groups make. A
//   button sounds several reeds (a bass in two octaves, a chord's three within one octave), never a voicing of its own.
//   Where the pulses come faster than a hand presses buttons (ACCORDION_CLODBOT.pressSeconds), only a group's last
//   pulse takes a chord.
// - **One bellows for both hands.** Its stroke is spent by the reeds sounding, faster when louder; it reverses at a
//   phrase's join where what is left will not carry another phrase like the last, and at a group's head where it would
//   run short before the next; each reversal is kept. (A piano accordion is unisonoric: the direction does not change a
//   pitch. The bisonoric case is the body's, tested there.)
// - **Its right hand's figure** where the fillness asks, a key at a time along the band's scale from the chord's top,
//   turning at the treble's reach, never quicker than a hand's fingers (ACCORDION_CLODBOT.noteSeconds).
// - **Its sound:** FreePats' Button Accordion HN (CC0; scripts/download-accordion-samples.mjs), its treble reeds sounding
//   the buttons' too; else the built-in reed voice (the organ family).
import {defineBot} from '../../framework/index.js';
import {withScoreTime,shiftScoreTime,scoreTimeFields} from '../../shared/score-time.js';
import {dividedBeats} from '../../shared/performers/rhythm-cell.js';
import {JazzVoicingClodbot} from './jazzvoicing_clodbot.js';
import {PerformedTiming} from '../lib/modules/performed-timing.js';
import {HearsAttention} from '../lib/modules/attention.js';
import {InstrumentPerformer} from '../lib/modules/instrument-performer.js';
import {ACCORDION,buttonNotes,chordRow,columnOf} from '../../shared/performers/accordion.js';
import {secondsPerTick} from '../../shared/meter-tactus.js';
import {blendLevel,metricalWeight,rankThresholds} from '../../shared/performers/figure-blend.js';
import {bandPhraseBars} from '../../shared/opening-time.js';

// Its recordings: FreePats' Button Accordion HN (scripts/download-accordion-samples.mjs).
export const ACCORDION_BANK='freepatsAccordion';
export const ACCORDION_CLODBOT=Object.freeze({
  // Its built-in voice's gain: the organ family's reed at about the median bot voice's loudness, as the harpist's is
  // (bot-loudness-priors.mjs, 29 September: at .02 it sat 3.2 LU under the median, -27.5 LUFS).
  voiceGain:.029,
  // How fast its left hand presses one button after another (s), and its right hand's fastest notes (s; authored).
  pressSeconds:.12,noteSeconds:1/12,
  // A bass button's level over a chord button's (the oom-pah's accent; ours), and a button held for this share of the
  // time to the next press (the chords short, the basses longer; ours).
  bassOver:1.15,chordHold:.55,bassHold:.9,
  // The right hand's reach for its figure (MIDI; within the treble, where its recordings are), and its figure's notes a
  // felt beat, up to twice as many at a solo's climax (ours).
  figure:Object.freeze([60,84]),perBeat:4,run:.45,runTop:.85,
});

const clamp=(value,low,high)=>Math.max(low,Math.min(high,value));
const modulo=(value,base)=>((value%base)+base)%base;
const DYNAMICS=Object.freeze([['pp',.2],['p',.35],['mp',.5],['mf',.65],['f',.8],['ff',1]]);
const dynamicOf=velocity=>DYNAMICS.find(([,upTo])=>velocity<=upTo+1e-9)?.[0]??'ff';

export class AccordionClodbot extends InstrumentPerformer(JazzVoicingClodbot,{name:'accordion_clodbot',kinds:['comp','run']}) {
  constructor(send,audio,settings={}){
    super(send,audio,settings);
    this.column=columnOf(0);this.presses=[];this.runPlan=null;this.bars=[];
    // Its bellows: the stroke's direction, its air (0 to 1 of a stroke), what the phrase has spent and what the last
    // spent, and every reversal ({at (s), why}).
    this.bellows={direction:'pull',air:1,phraseSpent:0,lastPhrase:0,lastAt:null,lastRate:0};this.reversals=[];
    // On samples, its recordings, where another bank was loaded for it; a render waits for them (`loading`).
    if(this.audio?.mode==='samples'&&typeof this.audio.loadSampleBank==='function'&&this.audio.samplePreset!=='accordion')
      this.loading=this.audio.loadSampleBank(ACCORDION_BANK,{preset:'accordion'}).catch(error=>this.decide({samples:{preset:'accordion',failed:String(error?.message??error)}}));
  }
  now(clock){return this.elapsedSeconds?.(clock)??(Number(clock?.tick)||0)*secondsPerTick(clock)}
  // The bar's pulses (ticks) and its groups' heads, by the meter's own groups.
  pulses(clock){
    const meter=clock.meter,unit=meter.pulsesPerBar/(meter.groups?.reduce((a,b)=>a+b,0)||meter.numerator||1);
    let at=0;const heads=(meter.groups?.length?meter.groups:[meter.numerator]).map(size=>{const start=Math.round(at);at+=size*unit;return start});
    const pulses=Array.from({length:Math.round(meter.pulsesPerBar/unit)},(_,k)=>Math.round(k*unit));
    return {unit,heads,pulses};
  }
  // Its left hand's presses in a bar: a bass on each head, a chord on the group's other pulses where the hand has time
  // (else on the group's last pulse alone): {tick: 'bass' | 'chord'}.
  presses_(clock){
    if(this.pressPlan?.bar===clock.bar)return this.pressPlan.at;
    const {unit,heads,pulses}=this.pulses(clock),spt=secondsPerTick(clock),at={};
    const fast=unit*spt<ACCORDION_CLODBOT.pressSeconds-1e-9;
    heads.forEach((head,k)=>{
      at[head]='bass';
      const end=heads[k+1]??clock.meter.pulsesPerBar,inner=pulses.filter(pulse=>pulse>head&&pulse<end);
      for(const pulse of fast?inner.slice(-1):inner)at[pulse]='chord';
    });
    this.pressPlan={bar:clock.bar,at};
    return at;
  }
  rearticulates(clock){return this.presses_(clock)[clock.tickInBar??0]!==undefined&&this.compLevelAt(clock)>0}
  // The bellows spent from its last press to `at` (s), and reversed where its rules ask, at a press on a head or a join.
  breathe(clock,at,{reeds,velocity,head}){
    const b=this.bellows,{seconds,reeds:nominal,dynamics,reserve}=ACCORDION.bellows;
    if(b.lastAt!==null){const spent=b.lastRate*Math.max(0,at-b.lastAt);b.air-=spent;b.phraseSpent+=spent}
    const rate=(Math.max(1,reeds)/nominal)*(dynamics[dynamicOf(velocity)]??1)/seconds;
    const phraseBars=Math.max(1,clock.meter.phraseBars||bandPhraseBars()),join=(clock.tickInBar??0)===0&&clock.bar%phraseBars===0;
    const reverse=why=>{this.reversals.push({at:+at.toFixed(4),bar:clock.bar,tick:clock.tickInBar??0,why,direction:b.direction==='pull'?'push':'pull'});
      if(this.reversals.length>256)this.reversals.shift();b.direction=b.direction==='pull'?'push':'pull';b.air=1};
    if(join&&b.lastAt!==null){b.lastPhrase=b.phraseSpent;b.phraseSpent=0;if(b.air-reserve<b.lastPhrase-1e-9)reverse('join')}
    // At a head: where the air would run under the reserve before the next one (a group's span, at this rate).
    else if(head){const span=this.groupSpan(clock)*secondsPerTick(clock);if(b.air-reserve<rate*span-1e-9)reverse('air')}
    b.lastAt=at;b.lastRate=rate;
  }
  // The ticks to the next group head (or the bar's end) from this tick.
  groupSpan(clock){const {heads}=this.pulses(clock),tick=clock.tickInBar??0;return (heads.find(head=>head>tick)??clock.meter.pulsesPerBar)-tick}
  // A press on the left hand: the bass button on a head (the root, the fifth on the bar's later heads), a chord button
  // on the others; the button's reeds sounding until the hand's next press. On the final bar, both at once, held. Its
  // chord button the row of the chord's reading dearest to its taste (chord-readings.js): a common-practice reading's
  // triad, a jazz reading's seventh, a power chord's fifth on the bass row beside its root.
  attack(clock,{change}){
    const chord=this.chord;if(!chord)return;
    const tick=clock.tickInBar??0,spt=secondsPerTick(clock),at=this.now(clock);
    const read=[...this.readingsOf(clock)].sort((a,b)=>a.cost-b.cost)[0]??null,root=read?.roles.root??chord.root;
    const row=read&&read.id!=='power'?chordRow({root,third:read.roles.third,fifth:read.roles.fifth,seventh:read.roles.seventh}):null;
    const final=this.closing?.phase==='final',press=final?'final':this.presses_(clock)[tick]??(change?'bass':'chord');
    const {heads}=this.pulses(clock),compLevel=this.compLevelAt(clock);if(!(compLevel>0))return;
    if(tick===0)this.planRun(clock);
    const later=Object.keys(this.presses_(clock)).map(Number).find(each=>each>tick)??clock.meter.pulsesPerBar,gap=(later-tick)*spt;
    const level=clamp(this.vl.velocity*compLevel,0,1),buttons=[];
    const rootColumn=columnOf(root,{near:this.column});
    if(press==='bass'||press==='final'){
      const index=heads.indexOf(tick),fifth=index>0&&index%2===1;
      const column=fifth?Math.min(ACCORDION.columns.length-1,rootColumn+1):rootColumn;
      buttons.push({row:'bass',column,level:clamp(level*ACCORDION_CLODBOT.bassOver,0,1),seconds:gap*ACCORDION_CLODBOT.bassHold});
    }
    if(press==='chord'||press==='final'){
      if(row)buttons.push({row,column:rootColumn,level,seconds:gap*ACCORDION_CLODBOT.chordHold});
      else buttons.push({row:'bass',column:Math.min(ACCORDION.columns.length-1,rootColumn+1),level,seconds:gap*ACCORDION_CLODBOT.chordHold});
    }
    this.column=rootColumn;
    const reeds=buttons.reduce((sum,button)=>sum+buttonNotes(button).length,0);
    this.breathe(clock,at,{reeds,velocity:level,head:heads.includes(tick)});
    withScoreTime(this.audio,this.compInterval(clock,{until:clock.tick-tick+later}),()=>{
      for(const button of buttons)for(const pitch of buttonNotes(button))this.strike(pitch,button.seconds,button.level,0);
    });
    this.count(clock,'comp');
    this.presses.push({bar:clock.bar,tick,press,buttons:buttons.map(({row,column})=>({row,column,pitches:buttonNotes({row,column})})),direction:this.bellows.direction,air:+this.bellows.air.toFixed(3)});
    if(this.presses.length>128)this.presses.shift();
    this.voicing=buttons.flatMap(button=>buttonNotes(button));this.announce(clock,this.voicing);
    if(change)this.decide({tick:clock.tick,change:true,chord:`${chord.root}:${chord.quality}`,reading:read?.id??null,row,column:rootColumn});
  }
  // A reed sounded: its recording (samples: the bank's nearest, at its pitch), the built-in reed voice, or MIDI.
  strike(pitch,seconds,asked,offset){
    const velocity=this.plannedVelocity(asked,'organ');
    if(this.audio?.mode==='midi'){this.audio.midiNote?.(pitch,seconds,velocity,undefined,offset,{instrument:'organ',profile:'organ'});return}
    if(this.audio?.mode==='samples'&&typeof this.audio.samplePitch==='function'){this.audio.samplePitch(pitch,offset,this.audio.sampleLevel?.(.565,velocity,'organ')??.565*velocity,seconds,velocity);return}
    this.audio?.voice?.(pitch,seconds,ACCORDION_CLODBOT.voiceGain,'sawtooth',offset,{instrument:'organ',profile:'organ',velocity});
  }
  everyTick(clock){
    super.everyTick?.(clock);
    if((clock.tickInBar??0)===0)this.planRun(clock);
  }
  // The right hand's figure, planned once at a bar's start where the fillness asks for one: a key at a time along the
  // band's scale from the chord's top, turning at its reach's edge, its notes at the felt beats' subdivisions (faster at
  // a solo's climax, never quicker than its fingers), each at the level the fillness gives it, within the band's
  // attention's allowance; the bellows spending for it too.
  planRun(clock){
    if(this.runPlan?.bar===clock.bar)return;
    this.runPlan={bar:clock.bar,notes:[]};
    if(!this.chord)return;
    const fillness=this.fillnessOf(clock)??0,solo=this.soloIntensity(clock);if(!(fillness>0)&&solo===null)return;
    const spt=secondsPerTick(clock),span=clock.meter.pulsesPerBar,felt=this.felt(clock),intensity=solo??0;
    const shortest=Math.min(...felt.map(beat=>beat.length))*spt,fastest=Math.max(1,Math.floor(shortest/ACCORDION_CLODBOT.noteSeconds));
    const perBeat=Math.min(fastest,Math.round(ACCORDION_CLODBOT.perBeat*(1+intensity)));
    const positions=dividedBeats(felt,perBeat);
    const tuned=pc=>this.objectTuned?.(pc)??pc;
    const scale=[...new Set((this.collection?.()??this.scaleFor?.(this.poolPcs??[])??[]).map(Number).map(tuned))];
    const steps=this.runSteps(scale,{grid:Array.from({length:12},(_,k)=>tuned(k)),collection:Boolean(this.collection?.()),draw:this.random(`runSteps:${clock.bar}`)()});
    const [low,high]=ACCORDION_CLODBOT.figure,keys=[];
    for(let octave=0;octave<=10;octave++)for(const pc of steps){const pitch=12*octave+modulo(pc,12);if(pitch>=low&&pitch<=high)keys.push(pitch)}
    keys.sort((a,b)=>a-b);if(keys.length<2)return;
    const top=Math.max(...(this.voicing??[low]))+12,start=Math.max(0,keys.findIndex(pitch=>pitch>=Math.min(top,high))),last=keys.length-1;
    const path=positions.map((_,k)=>{const period=2*last,phase=(start+k)%period;return keys[phase<=last?phase:period-phase]});
    const u=this.random(`run:${clock.bar}`),items=positions.map(({at,scoreTime},k)=>({id:`run${k}`,at,scoreTime,weight:metricalWeight(at,{beatStarts:felt.map(beat=>beat.start),span}),position:at/span,u:u()}));
    const thresholds=rankThresholds(items,{order:this.fillOrder});
    const notes=items.map((item,k)=>({scoreTime:shiftScoreTime(item.scoreTime,clock.tick-(clock.tickInBar??0),{axis:'ensemble'}),pitch:path[k],start:item.at*spt,end:(item.at+span/(felt.length*perBeat)*.9)*spt,
      level:blendLevel(thresholds.get(item.id),this.fillnessOf(clock,Math.min(span-1e-9,item.at))??0,{entering:true})})).filter(note=>note.level>0);
    const level=ACCORDION_CLODBOT.run+(ACCORDION_CLODBOT.runTop-ACCORDION_CLODBOT.run)*intensity;
    const {heard,claim,givenBackDb}=this.licensed(clock,notes.map(note=>({at:note.start,velocity:level*note.level})));
    for(const note of notes)withScoreTime(this.audio,note,()=>this.strike(note.pitch,note.end-note.start,this.softer(level*note.level,givenBackDb),note.start));
    this.runPlan={bar:clock.bar,notes:notes.map(note=>({...scoreTimeFields(note),pitch:note.pitch,start:note.start,end:note.end}))};
    this.count(clock,'run',notes.length);
    this.bars.push({bar:clock.bar,fillness:+fillness.toFixed(3),run:notes.length,of:items.length,perBeat,...(solo===null?{}:{intensity:+intensity.toFixed(3)}),
      ...(heard?{attention:{claimDb:claim?+claim.claimDb.toFixed(2):null,allowanceDb:+heard.allowanceDb.toFixed(2),soloing:heard.soloing,givenBackDb:+givenBackDb.toFixed(2)}}:{})});
    if(this.bars.length>64)this.bars.shift();
  }
}

export const PerformedAccordion=HearsAttention(PerformedTiming(AccordionClodbot,{instrument:'comping'}));
export const accordionClodbot=defineBot(
  {
    id: "accordion_clodbot", name: "accordion_clodbot", status: "native", source: "clodbot",
    category: "harmony", midiChannel: 8, performanceType: "polyphonic", outputModes: ["synth", "samples", "midi"],
    // Two hands: its part written on a grand staff, whatever its range (notation/score.js).
    hands: 2,
    sampleBank: ACCORDION_BANK,
    pitchContract: "floating-mpe",
    specSettings: Object.freeze(["fillness", "fillOrder", "density", "chromatic"]),
    description:
      "An accordionist on a piano accordion: its left hand on the Stradella basses by the meter's own groups (a bass button, the root and then its fifth, on each group's head, the chord's button on the group's other pulses: a waltz's oom-pah-pah in a group of three), each button sounding its reeds, never a voicing of its own; one bellows for both hands, reversing at a phrase's join or where its air runs short; its right hand's figure along the band's scale where the music asks; comp and figure as one continuum, a solo's course, and the band's attention.",
  },
  (...args) => new PerformedAccordion(...args),
);
