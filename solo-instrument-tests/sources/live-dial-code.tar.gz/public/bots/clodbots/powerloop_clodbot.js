// powerloop_clodbot: a nonfunctional power-chord loop by exact planing (docs/PITCH_LANGUAGES.md, "Bots"; the alternative tonal
// systems report §8, "Cobain-adjacent harmony and extensions of rock planing"). One power chord (root, fifth, octave)
// moved whole along a loop of roots that is not a functional progression -- drawn from the band's opening collection
// unless a spec names one (the report's fixture A, E5 G5 A5 C5 E5, by `loop: 'A'`; the owner, 1 October 2026: a bot "can
// have a preference for a certain key ... but not a chord progression") -- each chord an exact translation of the first (pitch-languages/planing.js: every internal interval kept to the
// cent), a chord a bar, strummed on the felt beats of any meter.
//
// Its cadence policy is scoped (P18): a dominant-to-tonic step into the first bar of a phrase is forbidden, and no other
// fifth. Where the loop would make one there, the chord before is held a bar instead, and the step made a bar later.
// It gives the band its harmony (a note pool at each change) and its root as the bass (a voice announced in the bass).
// Any division of the octave: roots in `steps` classes, and the fifth in cents (702 for just power chords). Each note says
// its loop position, root and block into notes.jsonl.
import {defineBot} from '../../framework/index.js';
import {VoiceLeadingBot} from '../lib/voice-leading-bot.js';
import {feltBeats} from '../../shared/meter-tactus.js';
import {voicesPayload} from '../../shared/sounding-voices.js';
import {LOOP_FIXTURES,planeExact,cadencePolicy} from '../../shared/pitch-languages/planing.js';
import {strikeWith,languageOf} from '../lib/note-language.js';
import {unitRandom} from '../../shared/stochastic.js';

// ---- Choices ---------------------------------------------------------------------------------------------------
// Its loop's preferred tonic (MIDI: E2, a guitar's low string; taken at most half the time, else the band's opening
// root: shared/opening-harmony.js), the fifth (cents), how many bars a chord lasts, and how it sounds: plucked, the downbeat
// stronger.
export const POWERLOOP=Object.freeze({preferredTonic:40,fifth:700,barsPerChord:1,family:'pluck',velocity:.62,downbeat:.1,gain:.07,hold:.85,
  // The scoped policy: no V-I into a phrase's first bar.
  policy:Object.freeze([{id:'no-dominant-into-a-phrase',forbid:{fromDegree:7,toDegree:0},scope:{boundary:'phrase'}}])});
const mod=(x,n)=>((x%n)+n)%n;
const words=value=>typeof value==='string'?value.trim().split(/[\s,]+/).filter(Boolean).map(Number):value;

// A loop's roots in semitones above its tonic (a fixture's name, or roots in `steps` classes).
export function loopRoots(loop,steps=12){
  if(typeof loop==='string'&&LOOP_FIXTURES[loop])return {id:LOOP_FIXTURES[loop].id,roots:[...LOOP_FIXTURES[loop].roots]};
  return {id:'loop',roots:words(loop).map(step=>12*step/steps)};
}

// A loop drawn from a collection (its classes above its tonic, in semitones): the tonic, then two to four of its other
// classes in an order drawn (ours: as long as the report's fixtures, or one shorter or longer).
export function drawnLoop(collection,random=unitRandom){
  const others=collection.system.filter(step=>step>0),roots=[0],length=Math.min(others.length,2+Math.floor(random()*3));
  for(let k=0;k<length;k++)roots.push(others.splice(Math.floor(random()*others.length),1)[0]);
  return {id:'drawn',roots};
}

export class PowerloopClodbot extends VoiceLeadingBot {
  constructor(send,audio,settings={}){
    super(send,audio,{style:'powerloop',...settings});
    // Its loop: one a spec names (a fixture's name, or roots), else drawn from the band's opening collection.
    const steps=settings.steps??12,{id,roots}=settings.loop!==undefined?loopRoots(settings.loop,steps):drawnLoop(this.bandOpening.collection);
    // The loop's last root returns to its first: the loop cycles through the others.
    this.loop={id,roots:roots.length>1&&roots.at(-1)===roots[0]?roots.slice(0,-1):roots,at:-1,held:null};
    this.fifth=settings.fifth??POWERLOOP.fifth;this.tonic=settings.tonic??this.preferredTonic(POWERLOOP.preferredTonic);this.policy=cadencePolicy(POWERLOOP.policy);
    this.block=Object.freeze([0,this.fifth,1200]);this.chordPitches=null;
  }
  rearticulates(){return false}
  attack(){}
  noteLanguage(note){return languageOf(this.pendingLanguage,note)}
  everyTick(clock){
    if(this.closing?.phase==='after'||!clock.meter)return;
    if(clock.barStart&&mod(clock.bar,POWERLOOP.barsPerChord)===0)this.change(clock);
    if(!this.chordPitches)return;
    const beats=feltBeats(clock.meter,{secondsPerTick:this.secondsPerTick(clock)}),beat=beats.find(item=>item.start===clock.tickInBar);
    if(!beat)return;
    const spt=this.secondsPerTick(clock),final=this.closing?.phase==='final';
    const seconds=beat.length*spt*POWERLOOP.hold,velocity=POWERLOOP.velocity+(clock.barStart?POWERLOOP.downbeat:0);
    const {pitches,language}=this.chordPitches;
    const written=this.writtenInterval(clock,beat.length,{group:'powerloop',replace:true});
    strikeWith(this,pitches.map((pitch,index)=>({pitch,language:{...language,member:['root','fifth','octave'][index]}})),
      ()=>this.playWritten(written,()=>{for(const pitch of pitches)this.audio.pitched(pitch,seconds,POWERLOOP.gain,'sawtooth',POWERLOOP.family,velocity,POWERLOOP.family)}));
    this.broadcast('voices',[voicesPayload({voice:`${this.instanceId??'powerloop'}:root`,role:'bass',pitches:[pitches[0]],clock,style:'powerloop'})]);
    this.announce(clock,pitches.slice(1),'chord');
    if(final)this.chordPitches=null;      // the last chord struck once, its arrival, its own length
  }
  // The loop's next chord: the block planed exactly to its root. A step the policy forbids at a phrase's first bar is
  // not taken there: the chord sounding is held a bar.
  change(clock){
    const {roots}=this.loop,next=mod(this.loop.at+1,roots.length),from=this.loop.at<0?null:roots[this.loop.at];
    const boundary=clock.phraseStart?'phrase':null;
    const violations=from===null?[]:this.policy.check([{from:Math.round(from),to:Math.round(roots[next]),boundary}]);
    if(violations.length&&this.chordPitches){this.loop.held=violations[0].rule;this.decide({tick:clock.tick,held:violations[0].rule,from,to:roots[next]});return}
    this.loop.at=next;this.loop.held=null;
    const root=roots[next],pitches=planeExact(this.block,100*(this.tonic+root)).map(cents=>cents/100);
    this.chordPitches={pitches,language:{planing:{loop:this.loop.id,index:next,root:+root.toFixed(4),block:'power',fifthCents:this.fifth,kind:'exact-translation'}}};
    this.send('/broadcast/notepool',pitches);
    this.decide({tick:clock.tick,loop:this.loop.id,index:next,root,pitches});
  }
}

export const powerloopClodbot=defineBot(
  {
    id:'powerloop_clodbot',name:'powerloop_clodbot',status:'native',source:'clodbot',
    category:'harmony',midiChannel:10,performanceType:'polyphonic',outputModes:['synth','midi'],
    pitchContract:'floating-mpe',nativeTuning:true,
    specSettings:Object.freeze(['loop','steps','fifth','tonic']),
    description:'A nonfunctional power-chord loop by exact planing: one power chord moved whole along a loop of roots (drawn from the band\'s collection, or a fixture the spec names: the report\'s E5 G5 A5 C5 is \'A\'), a chord a bar, strummed on the felt beats of any meter; no dominant-to-tonic step into a phrase\'s first bar and no other fifth forbidden; it gives the band its harmony and its root as the bass.',
  },
  (...args)=>new PowerloopClodbot(...args),
);
