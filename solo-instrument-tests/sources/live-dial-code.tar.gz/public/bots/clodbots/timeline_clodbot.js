// timeline_clodbot: a timeline player. One hand strikes a bell, an agogo, the claves, a triangle or a log drum in a
// repeating, asymmetric pattern the band can orient itself by (the family atlas's F30, F35 and F39:
// research/family-atlas.md), cycle after cycle, as the traditions' bell and clave players do.
//
// Its pattern is a maximally even one (shared/performers/timeline.js): as many onsets as the band's complexity asks,
// spread as evenly as they go over a bar or the fewest bars that hold eight pulses, rotated to strike the downbeat and
// to lie with the meter's strong points or across them as the band's complexity asks, and never quicker than one hand
// strikes again (the drummer's stroke: prepare and recover). Where the band's clock carries a tradition's clave
// (shared/rhythm-vocabulary.js withClave), it plays that clave on the claves instead, as that tradition's own.
//
// Its instrument is the nearest of those its kit has, as their recordings measure, to the ring and the brightness the
// band's character asks: its space from the driest to the longest ring, its darkness from the brightest to the darkest
// (on the Virtuosity kit, from the claves' dry click to the triangle's long ring; on VSCO 2 CE's, the log drum's two
// tongues the darkest and longest). It changes its pattern and its instrument only where a cycle begins, and ends on
// the last bar's downbeat with the band.
import {defineBot} from '../../framework/index.js';
import {Agent} from '../../framework/agent.js';
import {Closure} from '../lib/modules/closure.js';
import {PerformedTiming} from '../lib/modules/performed-timing.js';
import {GroupingChoice} from '../lib/modules/grouping-choice.js';
import {metricStrength} from '../../shared/rhythm-spaces.js';
import {onsetsPayload} from '../../shared/sounding-voices.js';
import {secondsPerTick} from '../../shared/meter-tactus.js';
import {DRUMMER} from '../../shared/performers/drummer.js';
import {chooseTimeline,cycleBars,cycleStrengths,strokeWeights} from '../../shared/performers/timeline.js';
import {instrumentsInKit} from '../../shared/performers/kit-instruments.js';
import {scoreTime,shiftScoreTime,withScoreTime} from '../../shared/score-time.js';
import {patternIntervals} from '../../shared/performers/rhythm-cell.js';

export const TIMELINE_CLODBOT=Object.freeze({
  // The instruments, as the sampled drum kit (the Virtuosity kit, synths/drum-kit.js) plays them: each stroke's General
  // MIDI note, strong and weak (an agogo's low and high bells, a triangle's open and muted strokes), and the recordings'
  // ring (ms from the peak to 30 dB under it) and brightness (the spectral centroid over the first 50 ms, Hz), each the
  // median over the first take of every dynamic layer of its open stroke (the agogo's the geometric mean of its two
  // bells' ring and the mean of their brightness), measured again by test/audio/timeline-clodbot.test.mjs.
  instruments:Object.freeze({
    claves:Object.freeze({strong:75,weak:75,ringMs:35,brightnessHz:3612}),
    cowbell:Object.freeze({strong:56,weak:56,ringMs:152,brightnessHz:4313}),
    agogo:Object.freeze({strong:68,weak:67,ringMs:305,brightnessHz:6758}),
    triangle:Object.freeze({strong:81,weak:80,ringMs:1304,brightnessHz:10169}),
  }),
  // The instruments as another sampled kit's own recordings measure them, in the same measure: VSCO 2 CE's claves and
  // cowbell (their ring the room's they were recorded in) and its log drum, struck on its low tongue (strong, General
  // MIDI's low wood block) and its high one (weak), the geometric mean of their ring and the mean of their brightness.
  kits:Object.freeze({
    'vsco-percussion':Object.freeze({
      claves:Object.freeze({strong:75,weak:75,ringMs:141,brightnessHz:3403}),
      cowbell:Object.freeze({strong:56,weak:56,ringMs:146,brightnessHz:3235}),
      logDrum:Object.freeze({strong:77,weak:76,ringMs:317,brightnessHz:1423}),
    }),
  }),
  // How far the band's complexity moves its density from its own (settings.density), either way (ours).
  complexityReach:.3,
  // A stroke's level: settings.velocity, from accentShare under it on the weakest pulses to accentShare over it on
  // the downbeat (ours: a bell player's accent, a few dB).
  accentShare:.25,
});

const clamp=(value,low,high)=>Math.max(low,Math.min(high,value));
// A meter's shape: what a cycle is laid over.
const meterKey=meter=>`${meter.pulsesPerBar}:${meter.numerator}/${meter.denominator}:${(meter.groups??[]).join('+')}:${meter.subdivision}:${(meter.rhythm?.clave??[]).join(',')}`;

// The instruments a kit plays, as its recordings measure them: a sampled kit's own where they are measured, else the
// Virtuosity kit's (which the synthesized kit and every other voice stand in for), each only where the kit has
// recordings of both its strokes. `kit` is audio.js sampledKit's: null for a voice that sounds every note.
export const timelineInstruments=kit=>
  instrumentsInKit(TIMELINE_CLODBOT.kits[kit?.kit]??TIMELINE_CLODBOT.instruments,kit,instrument=>[instrument.strong,instrument.weak]);

// The instrument nearest a character's ring and brightness: its space across the instruments' rings, its darkness
// across their brightness (each in log units, the character's 0 to 1 spanning the instruments' own range); the
// earlier on a tie; null where there is none. `instrument` names one outright.
export function timelineInstrument(character,{instrument='auto',instruments=TIMELINE_CLODBOT.instruments}={}){
  if(instrument&&instrument!=='auto'&&instruments[instrument])return instrument;
  const entries=Object.entries(instruments),log=Math.log;
  const rings=entries.map(([,one])=>log(one.ringMs)),brights=entries.map(([,one])=>log(one.brightnessHz));
  const span=(values,value)=>{const low=Math.min(...values),high=Math.max(...values);return high>low?(value-low)/(high-low):0};
  const ring=clamp(character?.space??.5,0,1),bright=1-clamp(character?.darkness??.5,0,1);
  let best=null,nearest=Infinity;
  for(const [index,[name]] of entries.entries()){
    const distance=Math.hypot(span(rings,rings[index])-ring,span(brights,brights[index])-bright);
    if(distance<nearest-1e-12){nearest=distance;best=name}
  }
  return best;
}

export class TimelineClodbot extends Closure(Agent) {
  constructor(send,audio,settings={}){
    super(send,audio);
    this.settings={density:.5,velocity:.6,instrument:'auto',syncopation:null,...settings};
    this.cycle=null;this.decisions=[];
  }
  // What the band's character asks of its pattern: its density and its syncopation, each 0 to 1.
  asks(){
    const complexity=clamp(this.character?.complexity??.5,0,1);
    return {density:clamp(this.settings.density+(complexity-.5)*2*TIMELINE_CLODBOT.complexityReach,0,1),
      syncopation:Number.isFinite(this.settings.syncopation)?clamp(this.settings.syncopation,0,1):complexity};
  }
  // A new cycle from this bar: a tradition's clave where the clock carries one (on the claves, where its kit has them),
  // else a maximally even timeline, each on an instrument its kit has.
  begin(clock){
    const meter=clock.meter,bar=metricStrength(meter),clave=meter.rhythm?.clave,here=timelineInstruments(this.audio?.sampledKit?.());
    if(Array.isArray(clave)&&clave.length){
      const onsets=[...clave].sort((a,b)=>a-b),instrument=here.claves?'claves':timelineInstrument(this.character,{instruments:here});
      this.cycle={startBar:clock.bar,bars:1,meter:meterKey(meter),pulses:bar.length,onsets,weights:strokeWeights(onsets,bar),instrument,
        notes:here[instrument]??null,vocabulary:meter.rhythm.vocabulary??null};
    }else{
      const bars=cycleBars(bar.length),strengths=cycleStrengths(bar,bars),{density,syncopation}=this.asks();
      const timeline=chooseTimeline({strengths,density,syncopation,pulseSeconds:secondsPerTick(clock),
        spacingSeconds:DRUMMER.prepareSeconds+DRUMMER.recoverSeconds});
      const instrument=timelineInstrument(this.character,{instrument:this.settings.instrument,instruments:here});
      this.cycle=timeline?{startBar:clock.bar,bars,meter:meterKey(meter),pulses:timeline.pulses,onsets:[...timeline.onsets],weights:strokeWeights(timeline.onsets,strengths),
        instrument,notes:here[instrument]??null,count:timeline.count,fit:timeline.fit,syncopation:timeline.syncopation}
        :{startBar:clock.bar,bars,meter:meterKey(meter),pulses:strengths.length,onsets:[],weights:[],instrument:null,notes:null};
    }
    const {startBar,bars,pulses,onsets,instrument,count,fit,syncopation,vocabulary}=this.cycle;
    this.cycle.intervals=patternIntervals(onsets,pulses,{axis:'cycle'});
    this.decisions.push({bar:startBar,bars,pulses,onsets:[...onsets],instrument,...(vocabulary?{vocabulary}:{count,fit,syncopation})});
    if(this.decisions.length>128)this.decisions.shift();
  }
  strike(clock,{weight,strength,scoreTime}){
    const instrument=this.cycle.notes;if(!instrument)return;
    const share=TIMELINE_CLODBOT.accentShare,level=clamp(this.settings.velocity*(1-share+2*share*strength),.05,1);
    withScoreTime(this.audio,scoreTime,()=>this.audio.drum?.('perc',level,{note:instrument[weight]}));
    this.broadcast('onsets',[onsetsPayload({voice:this.instanceId??'timeline_clodbot',role:'drums',onsets:[{tick:clock.tick,strength:level,kind:'perc'}]})]);
  }
  onTick(tick,clock){
    if(!clock?.meter)return;
    const closing=this.closingAt(clock);
    if(closing.phase==='after')return;
    const bar=metricStrength(clock.meter);
    // Its ending (Closure): the last bar's downbeat, with the band, then nothing.
    if(closing.phase==='final'){
      if(clock.tickInBar===0&&this.cycle?.notes)this.strike(clock,{weight:'strong',strength:1,scoreTime:scoreTime(clock.tick,closing.ticksLeft)});
      return;
    }
    // A cycle begins on a bar: the first, where the last one ends, or where the meter changes under it. The band's
    // character is heard where one begins, so a cycle is never cut.
    if(clock.tickInBar===0&&(!this.cycle||clock.bar-this.cycle.startBar>=this.cycle.bars||clock.bar<this.cycle.startBar
      ||this.cycle.meter!==meterKey(clock.meter)))this.begin(clock);
    if(!this.cycle)return;
    const at=(clock.bar-this.cycle.startBar)*bar.length+clock.tickInBar,index=this.cycle.onsets.indexOf(at);
    if(index<0)return;
    this.strike(clock,{weight:this.cycle.weights[index],strength:bar[clock.tickInBar]??0,
      scoreTime:shiftScoreTime(this.cycle.intervals[index],clock.tick-at,{axis:'ensemble'})});
  }
}

// Under a home (meterform_clodbot), it hears the home bars in a grouping of its own (bots/lib/modules/grouping-choice.js).
// Played in the ensemble's feel, where one is set (the performance layer: docs/PERFORMANCE_TIMING.md).
const GroupedTimeline=PerformedTiming(GroupingChoice(TimelineClodbot,{role:'drums'}));
export const timelineClodbot=defineBot(
  {
    id:"timeline_clodbot",name:"timeline_clodbot",status:"native",source:"clodbot",
    category:"beat",midiChannel:10,outputModes:["synth","midi"],pitchContract:"fixed-percussion",
    description:
      "A timeline player: one hand strikes a bell, an agogo, the claves, a triangle or a log drum in a repeating, asymmetric pattern the band can orient itself by, its onsets spread as evenly as they go and rotated to lie with the meter or across it as the band's complexity asks, its instrument the one of its kit's whose ring and brightness the band's character asks; a tradition's clave where the band's clock carries one.",
  },
  (...args)=>new GroupedTimeline(...args),
);
