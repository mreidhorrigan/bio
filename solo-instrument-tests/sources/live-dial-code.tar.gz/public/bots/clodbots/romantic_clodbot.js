// romantic_clodbot: four-part high-Romantic voice leading over the harmony it hears (the shared core:
// ../lib/voice-leading-bot.js). Its own: its style and ranges, its figures (the saving suspension, suspensions,
// appoggiaturas, neighbours, planing in the impressionist blend) and its re-articulations.
import {defineBot} from '../../framework/index.js';
import {unitRandom} from '../../shared/stochastic.js';
import {leadVoices,tendencyTones,blendStyles,pitchClassOf,parallelsAgainst} from '../../shared/voice-leading.js';
import {impressionistBlend,planeDiatonic,suspensions,appoggiaturas} from '../../shared/chromatic-harmony.js';
import {colourChord} from '../../shared/harmonic-spaces.js';
import {near,has,chordTones,VoiceLeadingBot} from '../lib/voice-leading-bot.js';

export class RomanticClodbot extends VoiceLeadingBot {
  constructor(send,audio,settings={}){super(send,audio,{style:'romantic',dissonance:.45,intonation:'just',...settings})}
  blend(){return impressionistBlend(this.functionality.value)}
  rearticulates(clock){return clock.barStart||this.onBeat(clock)&&clock.tickInBar===this.barTicks(clock)/2&&this.barTicks(clock)/this.beatTicks(clock)>=4}
  // Its space, and in the impressionist blend two of its colour tones (left unresolved).
  choose(clock,{blend,withBass}){
    const chord=this.chord,tones=chordTones(chord),{spaces,space}=this.space(clock,tones);
    // Over a bass it hears, four upper voices; alone, a bass of its own and three above it.
    const ranges=withBass?this.overBass(clock,[[52,67],[55,71],[60,76],[64,81]]):[[38,55],[50,66],[55,72],[60,79]];
    // A harmonic object no chord names is voiced whole (objectVoicing), and coloured in the blend as a chord is.
    const object=this.objectVoicing(tones,ranges.length),base=object?.pcs??tones;
    const colour=blend>.5?colourChord(space,base,{spaces,root:chord.root,count:base.length+2}).slice(base.length):[];
    const pcs=[...new Set([...base,...colour])],required=object?[...object.required,...colour.slice(0,1)].slice(0,ranges.length)
      :[chord.third??chord.root,chord.seventh,...(withBass?[]:[chord.root]),...colour.slice(0,1)].filter(pc=>pc!==null&&pc!==undefined);
    const style=blendStyles('romantic','impressionist',blend),tendencies=tendencyTones(this.previousChord,chord);
    const bass=this.bassHeard(clock),roles={third:chord.quality==='major'||chord.quality==='dominant-seventh'?chord.third:null,seventh:chord.seventh,leading:tendencies?.leading?.[0]??null,
      ...(bass!==null?{bass:pitchClassOf(bass)}:{})};
    // Its own bass: the root, or the third (an inversion); the fifth rarely. Its top voice drawn to a recalled theme.
    const bassScore=withBass?null:candidate=>{const pc=pitchClassOf(candidate[0]);return near(pc,chord.root)?0:near(pc,chord.third??-1)?1.2:near(pc,chord.fifth??-1)?3:6};
    const themeScore=this.themeScore(clock),contour=this.contourScore(clock,ranges.at(-1));
    const score=bassScore||themeScore||contour?candidate=>(bassScore?.(candidate)??0)+(themeScore?.(candidate)??0)+(contour?.(candidate)??0):null;
    const previous=this.voicing?.length===ranges.length?this.voicing:null;
    const next=leadVoices(previous,pcs,{voices:ranges.length,ranges,required,maxDoubling:object?.maxDoubling??2,style,...this.others(clock),tendencies,roles,maxStep:this.vl.maxStep,score});
    return next&&{...next,space};
  }
  attack(clock,{change}){
    const chord=this.chord;if(!chord)return;
    const hold=this.holdTicks(clock),spt=this.secondsPerTick(clock),beat=this.beatTicks(clock),seconds=hold*spt*.98;
    const blend=this.blend(),withBass=this.bassHeard(clock)!==null;
    if(!change)return this.rearticulate(clock,{hold,seconds,blend,beat,spt});
    const next=this.choose(clock,{blend,withBass});if(!next)return;
    // The appetite for figures grows with the intended dissonance, and goes with the blend.
    const appetite=Math.min(1,this.intended(clock)*1.2)*(1-blend),previous=this.voicing,before=this.tuning;
    let figure=null;
    // A voice that would move in octaves or fifths with a voice heard moving (a bass walking down through the seventh
    // as the voice holding it resolves) holds over the change and resolves a beat late: the suspension that saves the
    // parallel, as a composer's does. It does not wait on the appetite for figures.
    if(previous&&previous.length===next.voicing.length&&next.parts.against>0){
      const {othersFrom,othersTo}=this.others(clock),moving=new Set(parallelsAgainst(previous,next.voicing,othersFrom,othersTo).map(found=>found.voice));
      const saving=suspensions(previous,next.voicing,chord.pitchClasses).find(s=>moving.has(s.voice));
      if(saving)figure={kind:'suspension',voice:saving.voice,note:saving.hold,resolve:saving.resolve,saves:true};
    }
    // A suspension: a voice held over the change, a step above where it goes, resolved down on the next beat.
    if(!figure&&previous&&previous.length===next.voicing.length&&unitRandom()<appetite){
      const held=suspensions(previous,next.voicing,chord.pitchClasses).filter(s=>s.voice>0||withBass);
      if(held.length){const s=held.at(-1);figure={kind:'suspension',voice:s.voice,note:s.hold,resolve:s.resolve};}
    }
    // Else an appoggiatura on the top voice: the step above within its space (or the semitone below) struck on the
    // beat, then resolved.
    if(!figure&&unitRandom()<appetite*.6){
      // Within a collection heard, from within it both ways; else the semitone below is chromatic, as Romantic writing has it.
      const top=next.voicing.length-1,found=appoggiaturas(next.voicing,chord.pitchClasses,{collection:next.space.pitchClasses,within:Boolean(this.collection())}).find(a=>a.voice===top&&(!this.collection()||has(this.collection(),a.note)));
      // Not where the leap into it would move in octaves or fifths with a voice heard moving.
      const {othersFrom,othersTo}=this.others(clock),clear=found&&(!previous||previous.length!==next.voicing.length||!parallelsAgainst([previous[top]],[found.note],othersFrom,othersTo).length);
      if(clear)figure={kind:'appoggiatura',voice:top,note:found.note,resolve:found.resolve};
    }
    const tuned=this.tuneChord(next.voicing);
    let sounding=tuned;
    if(figure){
      // A held note keeps its pitch as it was tuned in the chord before.
      const heldAt=figure.kind==='suspension'?before?.chosen.findIndex(p=>Math.abs(p-figure.note)<.01)??-1:-1;
      const note=heldAt>=0?before.pitches[heldAt]:this.tuneOne(figure.note);
      sounding=tuned.map((pitch,i)=>i===figure.voice?note:pitch);
      const rest=tuned.filter((_,i)=>i!==figure.voice),delay=figure.kind==='suspension'?beat:Math.max(1,beat/2);
      const held=this.writtenInterval(clock,Math.min(delay,hold));
      this.sound(clock,rest,seconds,this.vl.velocity,this.writtenInterval(clock,hold));this.sound(clock,[note],delay*spt*.98,this.vl.velocity+.05,held);
      this.continueFigure(clock,delay,figure.note,figure.resolve,at=>{
        const remaining=hold-(at.tick-clock.tick);
        this.sound(at,[tuned[figure.voice]],Math.max(beat/2,remaining)*spt*.98,this.vl.velocity-.06,this.writtenInterval(at,remaining));this.announce(at,tuned);
      },{held,until:clock.tick+hold});
    }else this.sound(clock,sounding,seconds,this.vl.velocity,this.writtenInterval(clock,hold));
    this.announce(clock,sounding);
    this.voicing=next.voicing;
    const theme=this.themeAt(clock.tick,beat);
    this.decide({tick:clock.tick,change:true,chord:`${chord.root}:${chord.quality}`,voicing:next.voicing,sounding,figure:figure?.kind??null,...(figure?.saves?{saves:true}:{}),cost:+next.cost.toFixed(2),
      space:next.space.id,mode:next.space.mode,blend:+blend.toFixed(2),functionality:+this.functionality.value.toFixed(2),...(theme?{theme:theme.pitch}:{})});
  }
  // A held chord struck again at the half bar: softly, or with a neighbour in an inner voice (a sigh a step up or down
  // within its space, back on the next beat); in the impressionist blend, planed a step within its space and back.
  rearticulate(clock,{hold,seconds,blend,beat,spt}){
    const voicing=this.voicing,chord=this.chord;if(!voicing||!chord)return;
    const {space}=this.space(clock,chordTones(chord)),tuned=this.tuning?.chosen?.every((p,i)=>p===voicing[i])?this.tuning.pitches:voicing.map(p=>this.tuneOne(p));
    // A recalled theme's note begun here: the top voice takes it (the octave nearest, within its space, clear of the
    // voices heard), as a melody moves over a held chord.
    const theme=this.themeAt(clock.tick,beat),top=voicing.length-1;
    if(theme?.begins){
      // Its voicing is on the keyboard's keys, tuned afterwards (tuneOne), so a recalled pitch between two keys (a maqam's
      // quarter tone) takes the nearer key, and at exactly half way the one nearer the top voice; a key's pitch is kept
      // (the audit's B14: Math.round sent every half way up).
      const onKey=p=>{const low=Math.floor(p),high=Math.ceil(p);return p-low<high-p?low:high-p<p-low?high:Math.abs(low-voicing[top])<=Math.abs(high-voicing[top])?low:high};
      const target=[...[-12,0,12].map(octave=>theme.pitch+octave)].map(onKey).sort((a,b)=>Math.abs(a-voicing[top])-Math.abs(b-voicing[top]))[0];
      const {othersFrom,othersTo}=this.others(clock);
      if(target!==voicing[top]&&target>voicing[top-1]+1&&(has(space.pitchClasses,pitchClassOf(target))||has(chord.pitchClasses,pitchClassOf(target)))&&!parallelsAgainst([voicing[top]],[target],othersFrom,othersTo).length){
        const moved=[...voicing.slice(0,top),target],sounding=[...tuned.slice(0,top),this.tuneOne(target)];
        this.sound(clock,sounding,seconds,this.vl.velocity-.06,this.writtenInterval(clock,hold));this.announce(clock,sounding);this.voicing=moved;
        return this.decide({tick:clock.tick,change:false,figure:'theme',voicing:moved});
      }
    }
    if(blend>.5&&unitRandom()<.5){
      // Planed a step up or down, but not down onto the bass.
      const collection=space.pitchClasses.length>=5?space.pitchClasses:this.scaleFor(chordTones(chord)),down=planeDiatonic(voicing,unitRandom()<.5?1:-1,collection);
      const moved=(down[0]<this.bassFloor(clock)?planeDiatonic(voicing,1,collection):down).map(p=>this.tuneOne(p));
      this.sound(clock,moved,beat*spt*.98,this.vl.velocity-.04,this.writtenInterval(clock,Math.min(beat,hold)));this.announce(clock,moved);
      this.later(clock,beat,at=>{
        const remaining=hold-(at.tick-clock.tick);if(!(remaining>0))return;
        this.sound(at,tuned,Math.max(.2,seconds-(at.tick-clock.tick)*spt),this.vl.velocity-.08,this.writtenInterval(at,remaining));this.announce(at,tuned);
      });
      return this.decide({tick:clock.tick,change:false,figure:'planing',voicing:moved});
    }
    const inner=voicing.length>2?1+Math.floor(unitRandom()*(voicing.length-2)):null;
    if(inner!==null&&unitRandom()<Math.min(1,this.intended(clock)*1.2)*(1-blend)*.6){
      const up=unitRandom()<.5?1:-1,steps=[up,-up,2*up,-2*up],{othersFrom,othersTo}=this.others(clock);
      // A step within its space, clear of the other voices, and not moving in octaves or fifths with a voice heard.
      const note=steps.map(step=>voicing[inner]+step).find(p=>!has(chord.pitchClasses,pitchClassOf(p))&&has(space.pitchClasses,pitchClassOf(p))&&!voicing.some((q,j)=>j!==inner&&Math.abs(q-p)<1.5)
        &&!parallelsAgainst([voicing[inner]],[p],othersFrom,othersTo).length);
      if(note!==undefined){
        const sigh=this.tuneOne(note),sounding=tuned.map((p,i)=>i===inner?sigh:p);
        const held=this.writtenInterval(clock,Math.min(beat,hold));
        this.sound(clock,tuned.filter((_,i)=>i!==inner),seconds,this.vl.velocity-.1,this.writtenInterval(clock,hold));this.sound(clock,[sigh],beat*spt*.95,this.vl.velocity-.06,held);this.announce(clock,sounding);
        this.continueFigure(clock,beat,note,voicing[inner],at=>{
          this.sound(at,[tuned[inner]],Math.max(.2,seconds-(at.tick-clock.tick)*spt),this.vl.velocity-.1,this.writtenInterval(at,hold-(at.tick-clock.tick)));this.announce(at,tuned);
        },{held,until:clock.tick+hold});
        return this.decide({tick:clock.tick,change:false,figure:'neighbour',voicing:sounding});
      }
    }
    this.sound(clock,tuned,seconds,this.vl.velocity-.1,this.writtenInterval(clock,hold));this.announce(clock,tuned);
  }
}

export const romanticClodbot=defineBot(
  {
    id: "romantic_clodbot", name: "romantic_clodbot", status: "native", source: "clodbot", nativeTuning: true,
    category: "harmony", midiChannel: 11, performanceType: "polyphonic", outputModes: ["synth", "midi"],
    pitchContract: "floating-mpe",
    description:
      "Four-part high-Romantic voice leading following note pools and chord plans, in just intonation: chromatic motion and common tones, no parallel octaves or fifths with the bass it hears, suspensions and appoggiaturas resolved by step within the space its intended dissonance chooses; where the harmony stops functioning it blends toward impressionist planing.",
  },
  (...args) => new RomanticClodbot(...args),
);
