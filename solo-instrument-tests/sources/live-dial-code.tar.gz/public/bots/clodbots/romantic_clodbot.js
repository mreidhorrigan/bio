// romantic_clodbot: the voice leader (../lib/voice-leader.js) standing at the Romantic location of the voice leaders'
// style space (../../shared/voice-leader-space.js): four-part chromatic voice leading, common tones held and semitone
// motion sought, dissonance prepared and resolved, its own bass on the root, in just intonation. impressionist_clodbot,
// jazzvoicing_clodbot and hindemith_clodbot are the same voice leader at their locations; it may stand at a blend of them
// or anywhere else (`location`). Where the harmony it hears stops functioning, it moves toward the impressionist location
// as far as its `drift` says.
import {defineBot} from '../../framework/index.js';
import {VoiceLeader} from '../lib/voice-leader.js';

export class RomanticClodbot extends VoiceLeader {
  constructor(send,audio,settings={}){super(send,audio,{style:'romantic',location:'romantic',...settings})}
}

export const romanticClodbot=defineBot(
  {
    id: "romantic_clodbot", name: "romantic_clodbot", status: "native", source: "clodbot", nativeTuning: true,
    category: "harmony", midiChannel: 11, performanceType: "polyphonic", outputModes: ["synth", "midi"],
    pitchContract: "floating-mpe",
    description:
      "Four-part high-Romantic voice leading following note pools and chord plans, in just intonation: chromatic motion and common tones, no parallel octaves or fifths with the bass it hears, suspensions and appoggiaturas resolved by step within the space its intended dissonance chooses. The Romantic location in the voice leaders' style space, which it shares with impressionist_clodbot, jazzvoicing_clodbot and hindemith_clodbot: where the harmony stops functioning it moves toward the impressionist location, and it may stand anywhere between or beyond them (location).",
  },
  (...args) => new RomanticClodbot(...args),
);
