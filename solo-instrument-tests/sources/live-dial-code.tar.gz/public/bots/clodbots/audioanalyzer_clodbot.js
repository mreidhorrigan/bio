// audioanalyzer_clodbot: a fork of ae_AudioAnalyzerBOT that hears as the original did. The original analysed its input
// with Zsa.descriptors and envelope followers of its own, and sent each descriptor as the musebot message its menu chose
// (shared/estimation/audio-descriptors.js has them, read from its patch). Its browser port broadcasts five rough features
// of the microphone on each beat, and stays as it is. This fork:
//   - hears a render's input (a clip armed with hear: ['input']: its `input` setting, a clip's id, or the first), or on
//     a page the microphone;
//   - sends centroid, loudness, activity, flux and speed at most every 250 ms, as the messages its settings choose
//     (`centroidTo`, `loudnessTo`, `activityTo`, `fluxTo`, `speedTo`: the patch's "map ... to:" menus, and their
//     defaults the patch's: speed as activity, activity as arousal, flux as valence), the Bark bands each second as
//     barkenergy, and statechange "any" when the sound stops (ChichichiBot changes state on it);
//   - says what it sends, and as what, at /broadcast/descriptors (kept by the room for a bot that joins later), so
//     every bot reads a descriptor by its name, `this.descriptor('flux')` (framework/agent.js), whatever carries it;
//     and takes /agent/audio/route {routing: {flux: 'arousal', ...}} to send one as another.
// Its thresholds for an attack are settings too: `attackDb`, `releaseDb` and `gateMs` (the patch's 3, 1 and 80).
// Within a tick it sends each message's latest value: the original's every 250 ms, where a tick is longer, say nothing
// the latest does not.
import {defineBot} from '../../framework/index.js';
import {ANALYZER,AudioDescriptorAnalysis,DESCRIPTORS_ADDRESS,DESCRIPTOR_NAMES,ROUTE_ADDRESS,analyzerRouting,descriptorSchema}
  from '../../shared/estimation/audio-descriptors.js';

const WORKLET='shared/estimation/audio-capture-worklet.js';
const number=(value,fallback)=>Number.isFinite(Number(value))&&value!==''&&value!==null?Number(value):fallback;
// The routing its settings choose, the patch's defaults for the rest.
const routingFrom=settings=>analyzerRouting(Object.fromEntries(DESCRIPTOR_NAMES.filter(name=>typeof settings?.[`${name}To`]==='string')
  .map(name=>[name,settings[`${name}To`]])));

export function audioanalyzerClodbotClass(AudioAnalyzerBot){
  return class AudioAnalyzerClodbot extends AudioAnalyzerBot {
    constructor(send,audio,settings={}){
      super(send,audio,settings);
      this.routing=routingFrom(settings);
      this.inputs=settings?.inputs??null;this.inputName=typeof settings?.input==='string'&&settings.input?settings.input:null;
      this.thresholds={attackDb:number(settings?.attackDb,ANALYZER.attackDb),releaseDb:number(settings?.releaseDb,ANALYZER.releaseDb),
        gateSeconds:number(settings?.gateMs,ANALYZER.gateSeconds*1000)/1000};
      this.analysis=null;this.frames=[];this.sent=[];this.state='idle';
    }
    status(state,message){
      if(this.state===state&&this.message===message)return;
      this.state=state;this.message=message;this.audio?.report?.('bot_status',{state,message});
    }
    async start(){
      this.stopped=false;
      if(this.inputs){
        // A render's input, heard as it sounds: its clip named, or the first armed. Hearing claims nothing: a listener
        // may hear the same clip.
        const listed=this.inputs.list(),id=this.inputName?listed.find(input=>input.name===this.inputName||input.id===this.inputName)?.id:listed[0]?.id;
        this.source=id?this.inputs.open(id):null;
        if(!this.source){this.status('idle',this.inputName?`No render input ${this.inputName}.`:'No render clip is armed as an input (hear: [\'input\']).');return;}
        this.analysis=new AudioDescriptorAnalysis({sampleRate:this.source.sampleRate,routing:this.routing,...this.thresholds});
        this.nextSample=Math.round(this.inputs.now()*this.source.sampleRate);
        this.status('listening',`Analysing ${this.source.name??id}.`);
      }else await this.listenMicrophone();
      this.announce();
    }
    // A page's microphone, through the capture worklet the listener uses, frames handed back as they are read.
    async listenMicrophone(){
      const context=this.audio?.ctx,media=globalThis.navigator?.mediaDevices,Node=globalThis.AudioWorkletNode;
      if(!context?.audioWorklet||!media?.getUserMedia||!Node){this.status('unavailable','Microphone capture is unavailable in this host.');return;}
      try{
        await context.audioWorklet.addModule(new URL(WORKLET,globalThis.location?.href||'http://localhost/'));
        this.stream=await media.getUserMedia({video:false,audio:{echoCancellation:false,noiseSuppression:false,autoGainControl:false}});
        if(this.stopped){this.stream.getTracks().forEach(track=>track.stop());return;}
        this.node=new Node(context,'musebots-performer-capture',{numberOfInputs:1,numberOfOutputs:1,outputChannelCount:[1],channelCount:1,
          channelCountMode:'explicit',processorOptions:{frameSize:ANALYZER.windowSamples}});
        this.node.port.onmessage=({data})=>{
          if(data?.type!=='frame')return;
          this.frames.push(Float32Array.from(data.samples));if(this.frames.length>256)this.frames.shift();
          this.node.port.postMessage({type:'return',samples:data.samples},[data.samples.buffer]);
        };
        this.microphone=context.createMediaStreamSource(this.stream);this.mute=context.createGain();this.mute.gain.value=0;
        this.microphone.connect(this.node);this.node.connect(this.mute);this.mute.connect(context.destination);
        this.analysis=new AudioDescriptorAnalysis({sampleRate:context.sampleRate,routing:this.routing,...this.thresholds});
        this.status('listening','Analysing the microphone.');
      }catch(error){this.status('unavailable',`The microphone could not be opened: ${error.message}`);}
    }
    // What it sends, and as what (audio-descriptors.js descriptorSchema), for a bot to read by name.
    announce(){this.send(DESCRIPTORS_ADDRESS,[{...(this.instanceId?{source:this.instanceId}:{}),...descriptorSchema(this.routing)}]);}
    // What sounded since the last tick, analysed; each message's latest value sent.
    onTick(){
      if(!this.analysis)return;
      const heard=[];
      if(this.source){
        const rate=this.source.sampleRate,until=Math.round(this.inputs.now()*rate),count=until-this.nextSample;
        if(count>0){heard.push(...this.analysis.push(this.source.read(this.nextSample/rate,until/rate,count)));this.nextSample=until;}
      }else while(this.frames.length)heard.push(...this.analysis.push(this.frames.shift()));
      const latest=new Map;
      for(const message of heard)if(message.name==='statechange')this.say(message);else latest.set(message.name,message);
      for(const message of latest.values())this.say(message);
    }
    say({name,value,at,descriptor}){
      this.broadcast(name,Array.isArray(value)?value:[value]);
      this.sent.push({at,name,descriptor:descriptor??null});if(this.sent.length>256)this.sent.shift();
    }
    // Sent as another: the descriptor takes the message asked for, and the one that had it takes its old one.
    onMessage(message){
      super.onMessage?.(message);
      if(message?.address!==ROUTE_ADDRESS)return;
      const request=message.args?.[0];
      if(request?.target&&request.target!==this.instanceId)return;
      try{
        const routing={...this.routing};
        for(const [name,wanted] of Object.entries(request?.routing??{})){
          const holder=Object.keys(routing).find(other=>routing[other]===wanted&&other!==name);
          if(holder)routing[holder]=routing[name];
          routing[name]=wanted;
        }
        this.routing=analyzerRouting(routing);
      }catch(error){this.audio?.report?.('bot_status',{state:this.state,message:`Routing refused: ${error.message}`});return;}
      if(this.analysis)this.analysis.routing=this.routing;
      this.announce();
    }
    stop(){
      this.stopped=true;
      this.stream?.getTracks().forEach(track=>track.stop());
      try{this.node?.port.postMessage({type:'stop'});this.microphone?.disconnect();this.node?.disconnect();this.mute?.disconnect();}catch{}
      this.node=this.microphone=this.mute=this.stream=null;this.frames=[];
    }
  };
}

export function defineAudioanalyzerClodbot(AudioAnalyzerBot){
  const AudioAnalyzerClodbot=audioanalyzerClodbotClass(AudioAnalyzerBot);
  return defineBot({id:'audioanalyzer_clodbot',name:'audioanalyzer_clodbot',status:'native',source:'clodbot',category:'utility',outputModes:[],
    pitchContract:'none',specSettings:Object.freeze(['input','centroidTo','loudnessTo','activityTo','fluxTo','speedTo','attackDb','releaseDb','gateMs']),
    description:'A fork of ae_AudioAnalyzerBOT that hears as the original did: the spectral centroid, loudness, activity, spectral flux and speed of attacks of an input (a render clip, or the microphone), each sent as the message its setting chooses (by default speed as activity, activity as arousal and flux as valence, as the original), the 25 Bark bands each second as barkenergy, and statechange when the sound stops. It says what it sends, and as what, so a bot can read a descriptor by its name.'},
    (send,audio,options)=>new AudioAnalyzerClodbot(send,audio,options));
}
