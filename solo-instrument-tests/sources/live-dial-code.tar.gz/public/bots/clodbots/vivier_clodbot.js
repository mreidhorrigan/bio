// vivier_clodbot: a Vivier colour voice over a bass-melody dyad (docs/PITCH_LANGUAGES.md, "Bots"; the alternative tonal
// systems report §4). It hears the bass (the lowest note a 'bass' voice sounds) and the melody (the highest note a
// 'line' or 'performer' voice sounds), and whenever the dyad moves it sounds their combination tones,
// f = a f_bass + b f_melody, for the coefficient pairs Christian identifies in the first section of Vivier's Bouchara
// (pitch-languages/combination-tones.js): a quiet bowed colour above the melody, each tone at its exact frequency, on
// no grid. When the dyad moves, the colour's intervals change with it (it is generated in frequency, not a chord
// transposed in cents), and the melody's register matters. Tones outside its range are left out, never folded into
// another octave; a dyad that holds is sounded again at the next bar. Each tone's coefficients go into notes.jsonl.
import {defineBot} from '../../framework/index.js';
import {VoiceLeadingBot} from '../lib/voice-leading-bot.js';
import {combinationTones,BOUCHARA_SECTION_1} from '../../shared/pitch-languages/combination-tones.js';
import {strikeWith,languageOf} from '../lib/note-language.js';

// ---- Choices ---------------------------------------------------------------------------------------------------
// Its range (MIDI: the colour sits above a melody in the treble), how many of the recipe's tones at most (the lowest
// kept), how far the dyad must move to be a new one (cents), and how the colour sounds: bowed, quiet, one voice to a tone
// (the section texture doubles its upper notes at the octave, which would be tones the recipe never made).
export const VIVIER=Object.freeze({range:Object.freeze([60,100]),maximumTones:6,moveCents:5,velocity:.32,gain:.03,holdBars:1,
  melodyRoles:Object.freeze(['line','performer'])});
const hz=pitch=>440*2**((pitch-69)/12),pitchOf=frequency=>69+12*Math.log2(frequency/440);

// The colour of a dyad: the recipe's tones inside the range, the lowest `maximumTones`, each {pitch, hz, coefficients},
// and those left out, with why.
export function colourOf(bass,melody,{recipe=BOUCHARA_SECTION_1,range=VIVIER.range,maximumTones=VIVIER.maximumTones}={}){
  const colour=combinationTones(hz(bass),hz(melody),recipe);
  const tones=[],left=[...colour.rejected.map(tone=>({coefficients:tone.coefficients,reason:tone.reason}))];
  for(const tone of [...colour.tones].sort((a,b)=>a.hz-b.hz)){
    const pitch=pitchOf(tone.hz);
    if(pitch<range[0]||pitch>range[1])left.push({coefficients:tone.coefficients,reason:'outside its range'});
    else if(tones.length>=maximumTones)left.push({coefficients:tone.coefficients,reason:'more than it sounds'});
    else tones.push({pitch,hz:tone.hz,coefficients:tone.coefficients});
  }
  return {recipe:colour.recipe,tones,left};
}

export class VivierClodbot extends VoiceLeadingBot {
  constructor(send,audio,settings={}){super(send,audio,{style:'vivier',...settings});this.colour={dyad:null,bar:null}}
  rearticulates(){return false}
  attack(){}
  noteLanguage(note){return languageOf(this.pendingLanguage,note)}
  // The dyad heard now: the bass's lowest note and the melody's highest, or null while either is silent.
  dyad(clock){
    const bass=this.heard.lowest(clock.tick,{role:'bass'});
    let melody=null;
    for(const voice of this.heard.around(clock.tick))if(VIVIER.melodyRoles.includes(voice.role)&&voice.to.length&&(melody===null||voice.to.at(-1)>melody))melody=voice.to.at(-1);
    return bass===null||melody===null?null:{bass,melody};
  }
  everyTick(clock){
    if(this.closing?.phase==='after')return;
    const dyad=this.dyad(clock);
    if(!dyad)return;
    const moved=!this.colour.dyad||Math.abs(dyad.bass-this.colour.dyad.bass)*100>VIVIER.moveCents||Math.abs(dyad.melody-this.colour.dyad.melody)*100>VIVIER.moveCents;
    if(!moved&&!(clock.barStart&&this.colour.bar!==clock.bar))return;
    const {recipe,tones,left}=colourOf(dyad.bass,dyad.melody);
    this.colour={dyad,bar:clock.bar};
    if(!tones.length){this.decide({tick:clock.tick,colour:'none in range',bass:dyad.bass,melody:dyad.melody,left});return}
    const seconds=this.barTicks(clock)*this.secondsPerTick(clock)*VIVIER.holdBars;
    const written=this.writtenInterval(clock,this.barTicks(clock)*VIVIER.holdBars,{group:'colour',replace:true});
    const language=tone=>({colour:{recipe,coefficients:tone.coefficients,bass:+dyad.bass.toFixed(4),melody:+dyad.melody.toFixed(4)}});
    strikeWith(this,tones.map(tone=>({pitch:tone.pitch,language:language(tone)})),
      ()=>this.playWritten(written,()=>{for(const tone of tones)this.audio.pitched(tone.pitch,seconds,VIVIER.gain,'sine','pad',VIVIER.velocity,'bowed')}));
    this.announce(clock,tones.map(tone=>tone.pitch),'colour');
    this.decide({tick:clock.tick,colour:recipe,bass:dyad.bass,melody:dyad.melody,tones:tones.map(tone=>({pitch:+tone.pitch.toFixed(4),coefficients:tone.coefficients})),left});
  }
}

export const vivierClodbot=defineBot(
  {
    id:'vivier_clodbot',name:'vivier_clodbot',status:'native',source:'clodbot',
    category:'keys-pads',midiChannel:14,performanceType:'polyphonic',outputModes:['synth','midi'],
    pitchContract:'floating-mpe',nativeTuning:true,
    // Silent until it hears a bass and a melody (test/agents.test.mjs leaves it out of the bare bar).
    requiresHeardVoices:true,
    description:'A Vivier colour voice: it hears the bass and the melody and, whenever the dyad moves, sounds their combination tones (a f_bass + b f_melody, the coefficients Christian identifies in the first section of Vivier\'s Bouchara) as a quiet bowed colour above the melody, each tone at its exact frequency, none folded into another octave.',
  },
  (...args)=>new VivierClodbot(...args),
);
