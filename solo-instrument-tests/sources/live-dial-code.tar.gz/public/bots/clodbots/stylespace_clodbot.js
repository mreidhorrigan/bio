// stylespace_clodbot: the ensemble's character (the aesthetic bridge, shared/aesthetic.js) moving through the space of
// characters. The user's stress test, 28 September 2026: "interpolate continuously between different harmonic/tuning/
// stylistic regimes"; and what interpolable means: "intermediate states exist between all the their possible states
// ... but in actual music, parameters can and should jump or have strong discontinuities sometimes". New, not a fork:
// no earlier bot says the ensemble's character as the piece goes.
//
// It says the ensemble's character (/broadcast/character: nine axes, 0 to 1), which every bot projects through
// aesthetic.js: PlexBOT its meters and form and TuneBOT its tuning (through the shared configuration, which the page
// and a render apply each character to), the desk its loudness and space, ManageBOT its attention's budget. At the start
// it says its first style; where a section begins (the form's progress) it may move: a jump to a style, or a state
// between the one it is in and one it draws, at a tenth drawn between them. Every state is a character, so it chooses
// and never refuses. Its styles (settings.styles): the curators' words for each, as a spec says them ("dark spacious",
// "bright spiky mechanical"), the first its start; else each drawn from the words, one from each of two axes.
import {defineBot} from '../../framework/index.js';
import {Agent} from '../../framework/agent.js';
import {unitRandom} from '../../shared/stochastic.js';
import {AESTHETIC_WORDS,blendAesthetic,describeAesthetic,parseAesthetic} from '../../shared/aesthetic.js';
// The styles the études have demonstrated, each measured as a character from the notes it played (scripts/
// measure-etude-styles.mjs): a style named "étude:<name>" is that étude's, and "études" is every one of them (the owner, 2
// October 2026: "play in, and interpolate among, all the styles of music demonstrated thus far in the other études").
import ETUDE_STYLES from '../../shared/etude-styles.json' with {type:'json'};

export const STYLESPACE=Object.freeze({moves:.7,between:.5,tenths:9,words:2,kept:64});
// The curators' words by the axis each speaks to first, for a style drawn from two axes by construction.
const WORDS_BY_AXIS=Object.freeze(Object.entries(AESTHETIC_WORDS).reduce((groups,[word,axes])=>{
  const axis=Object.keys(axes)[0];(groups[axis]??=[]).push(word);return groups},{}));

// A spec's styles, as words: each one understood (at least one of its words known), else refused where it is given.
function checkedStyles(given){
  if(given==null)return null;
  const styles=given==='études'||given==='etudes'?Object.keys(ETUDE_STYLES.styles).map(name=>`étude:${name}`):given;
  if(!Array.isArray(styles)||!styles.length)throw new TypeError('stylespace_clodbot styles are a list of the curators\' words, such as ["dark spacious", "bright spiky"], or of études\' styles ("étude:rap-band"), or "études"');
  return Object.freeze(styles.map(words=>{
    const named=/^[ée]tude:(.+)$/u.exec(String(words));
    if(named){
      const found=ETUDE_STYLES.styles[named[1]];
      if(!found)throw new TypeError(`stylespace_clodbot knows no étude style "${named[1]}" (${Object.keys(ETUDE_STYLES.styles).join(', ')})`);
      return Object.freeze({words:String(words),vector:Object.freeze({...found.character})});
    }
    const parsed=parseAesthetic(String(words));
    if(!parsed.understood)throw new TypeError(`stylespace_clodbot does not know the words "${words}"`);
    return Object.freeze({words:String(words),vector:parsed.vector});
  }));
}

export class StyleSpaceClodbot extends Agent{
  constructor(send,audio,settings={}){
    super(send,audio);
    this.settings={moves:STYLESPACE.moves,between:STYLESPACE.between,...settings};
    this.styles=checkedStyles(settings.styles);
    this.style=null;this.section=null;this.movedAtSection=null;this.moves=[];
  }
  // A style: one of the spec's, or a word from each of two axes drawn in turn (a shuffle, never a draw refused). A move,
  // a jump or a state between, goes toward another style than the one it leaves (`from`).
  draw(from=null){
    if(this.styles){const others=this.styles.length>1&&from?this.styles.filter(style=>style.words!==from.words):this.styles;return others[Math.floor(unitRandom()*others.length)]}
    const axes=Object.keys(WORDS_BY_AXIS);
    for(let k=axes.length-1;k>0;k--){const j=Math.floor(unitRandom()*(k+1));[axes[k],axes[j]]=[axes[j],axes[k]]}
    const chosen=axes.slice(0,STYLESPACE.words).map(axis=>{const group=WORDS_BY_AXIS[axis];return {axis,index:Math.floor(unitRandom()*group.length)}});
    // The style it leaves drawn again: its last axis's next word instead, so a move always goes somewhere.
    if(from&&chosen.map(({axis,index})=>WORDS_BY_AXIS[axis][index]).join(' ')===from.words){const last=chosen.at(-1);last.index=(last.index+1)%WORDS_BY_AXIS[last.axis].length}
    const words=chosen.map(({axis,index})=>WORDS_BY_AXIS[axis][index]).join(' ');
    return {words,vector:parseAesthetic(words).vector};
  }
  begin(){this.style=this.styles?.[0]??this.draw();this.say(null,'start',null)}
  // Its first style said before the first pulse, with what else says how the piece begins (Agent.onPrepare), so that
  // the conductors plan its opening in it.
  onPrepare(clock={}){if(!this.style)this.begin();return false}
  // Where a section begins, now and then: a jump, or a state between.
  move(clock){
    if(this.section===null||this.section===this.movedAtSection)return false;
    const first=this.movedAtSection===null;this.movedAtSection=this.section;
    if(first||!(unitRandom()<this.settings.moves))return false;
    const target=this.draw(this.style);
    if(unitRandom()<this.settings.between){
      const t=(1+Math.floor(unitRandom()*STYLESPACE.tenths))/(STYLESPACE.tenths+1);
      this.style={words:`${t.toFixed(1)} of the way from ${this.style.words} to ${target.words}`,vector:blendAesthetic(this.style.vector,target.vector,t)};
      this.say(clock,'between',t);
    }else{this.style=target;this.say(clock,'jump',null)}
    return true;
  }
  say(clock,kind,t){
    const describe=`${this.style.words}: ${describeAesthetic(this.style.vector)}`;
    const entry={tick:clock?.tick??0,section:this.section,move:kind,...(t!=null?{t}:{}),words:this.style.words,vector:this.style.vector};
    this.moves.push(entry);if(this.moves.length>STYLESPACE.kept)this.moves.shift();
    this.audio?.report?.('stylespace',entry);
    this.broadcast('character',[{vector:this.style.vector,describe}]);
  }
  onMessage(message){
    super.onMessage(message);
    // The form's progress says which section the ensemble is in (mh_FormBOT, form_clodbot).
    if(message?.address==='/broadcast/form/progress'){const index=Number(message.args?.[0]?.sectionIndex);if(Number.isInteger(index))this.section=index}
  }
  onTick(tick,clock){
    if(!this.style){this.begin();return}
    if(clock?.barStart)this.move(clock);
  }
}

export const stylespaceClodbot=defineBot(
  {
    id:'stylespace_clodbot',name:'stylespace_clodbot',status:'native',source:'clodbot',
    category:'conductor',outputModes:[],pitchContract:'none',
    specSettings:Object.freeze(['styles','moves','between']),
    description:'The ensemble\'s character moving through the space of characters (the aesthetic bridge: darkness, attack, mechanism, tonality, wordlessness, complexity, variety, continuity, space): it says its first style at the start, and where a section begins it jumps to another style or moves to a state between, at a tenth drawn between them. PlexBOT, TuneBOT, the desk and ManageBOT each take the character as it goes. Its styles are the curators\' words a spec gives it ("dark spacious", "bright spiky"), else drawn from them.',
  },
  (...args)=>new StyleSpaceClodbot(...args),
);
