// motifprofiler_clodbot: the performer's phrases, gathered from their voice and stored in mh_MemoryBOT with the harmony
// under them, so that the bots recall and develop the performer's material as they do their own (a theme recalled,
// voice-leading-bots.js). The user: "Do we have any clodbot profilers that have the ability to pick up motifs by
// listening to audio and midi, then feed those motifs to memorybot?" None did: the render host stores what each bot
// plays, and nothing stored what the performer played.
//
// It hears the performer's voice (/broadcast/voices, role 'performer', performer-notes.js): a ListenerBot's notes from
// audio (a line's pitch, pitch-yin.js), a MIDI input's notes. A phrase ends at a rest of `restBeats` felt beats, or
// after `maxBars` bars; one of fewer than `minNotes` notes is not kept. Each note is stored with its onset and duration
// (to the next note, or to the rest, at most two beats), and the harmony is the pool heard as each note began
// (metadata.harmony, motif-harmony.js), so that memory can realize the phrase in another harmony. It makes no sound.
import {defineBot} from '../../framework/index.js';
import {Agent} from '../../framework/agent.js';
import {tactusOf} from '../../shared/meter-tactus.js';
import {bandMeter} from '../../shared/opening-time.js';

const TICKS_PER_QUARTER=480;

// What the mathematical audit's B13 asked of it, and it now does: a rest is a rest actually heard (a silence in the
// voice), never merely an absence of new onsets, so a held note keeps its phrase open; each performer's phrases are
// gathered apart; a chord heard in a voice is taken as its top line (the melodic-voice contract: the highest pitch
// sounding); each note is placed in quarters as it comes, in the meter then in force, so a meter change mid-phrase
// does not re-time the notes before it; and the harmony is kept only where a pool was actually heard, not the agent's
// default.
export class MotifProfilerClodbot extends Agent {
  constructor(send,audio,settings={}){
    super(send,audio);
    this.settings={restBeats:1.5,maxBars:4,minNotes:3,...settings};this.phrases=new Map();this.stored=[];
    // Quarters as a function of the transport's ticks, piecewise in the meters heard: [{tick, quarter, perTick}].
    this.timeline=[{tick:0,quarter:0,perTick:.25}];
  }
  // The phrase gathering now, if one (the first performer's): kept for callers that read it.
  get phrase(){return this.phrases.values().next().value??null}
  quarterAt(tick){
    let segment=this.timeline[0];for(const entry of this.timeline)if(entry.tick<=tick)segment=entry;
    return segment.quarter+(tick-segment.tick)*segment.perTick;
  }
  onMessage(message){
    super.onMessage(message);
    if(message.address!=='/broadcast/voices')return;
    const payload=message.args?.[0],tick=Number(payload?.tick);
    if(payload?.role!=='performer'||!Number.isFinite(tick))return;
    const source=String(payload.voice??message.source??'performer'),pitches=(Array.isArray(payload.pitches)?payload.pitches:[]).filter(Number.isFinite);
    let phrase=this.phrases.get(source);
    // A silence: the note sounding ends, and a rest begins.
    if(!pitches.length){const last=phrase?.notes.at(-1);if(last&&last.end===undefined)last.end=tick;if(phrase)phrase.restAt??=tick;return;}
    const pitch=Math.max(...pitches);
    if(!phrase){phrase={start:tick,notes:[],source};this.phrases.set(source,phrase)}
    const last=phrase.notes.at(-1);if(last&&last.end===undefined)last.end=tick;
    phrase.restAt=undefined;
    phrase.notes.push({tick,quarter:this.quarterAt(tick),pitch,pool:this.poolHeard?[...this.notes]:[]});
  }
  onTick(tick,clock){
    if(!clock?.meter)return;
    const perTick=4/((clock.meter.denominator||bandMeter().denominator)*(clock.meter.subdivision||bandMeter().subdivision)),current=this.timeline.at(-1);
    if(Number.isFinite(clock.tick)&&perTick!==current.perTick&&clock.tick>=current.tick){
      this.timeline.push({tick:clock.tick,quarter:this.quarterAt(clock.tick),perTick});
      if(this.timeline.length>64)this.timeline.shift();
    }
    const beat=tactusOf(clock.meter).ticks||clock.meter.subdivision||bandMeter().subdivision;
    for(const phrase of [...this.phrases.values()]){
      // Quiet only once a rest has been heard: a note still held is not a rest.
      const quiet=phrase.restAt===undefined?0:clock.tick-phrase.restAt,long=clock.tick-phrase.start>=this.settings.maxBars*clock.meter.pulsesPerBar;
      if(quiet>=this.settings.restBeats*beat||long)this.store(clock,beat,phrase);
    }
  }
  store(clock,beat,phrase=this.phrase){
    if(!phrase)return null;
    this.phrases.delete(phrase.source);
    if(phrase.notes.length<this.settings.minNotes)return null;
    const start=phrase.notes[0].quarter,beatQuarters=beat*4/((clock.meter.denominator||bandMeter().denominator)*(clock.meter.subdivision||bandMeter().subdivision));
    const events=phrase.notes.map((note,i)=>{
      const end=note.end??phrase.notes[i+1]?.tick??phrase.restAt??note.tick+beat;
      return {at:note.quarter-start,duration:Math.max(1/16,Math.min(this.quarterAt(end)-note.quarter,2*beatQuarters)),pitch:note.pitch,velocity:.7};
    });
    // The gate written to the motif and the duration evidence are different quantities.
    // A missing release at the maximum phrase length supplies no finite upper bound.
    const durationEvidence=phrase.notes.map((note,index)=>{
      const observed=note.end!==undefined,raw=observed?Math.max(0,this.quarterAt(note.end)-note.quarter):null;
      return {noteIndex:index,unit:'quarter-note',publishedDuration:events[index].duration,
        observedRelease:observed,lower:observed?raw:0,upper:observed?raw:null,
        estimate:events[index].duration,censored:!observed,
        policy:observed?'observed voice change/silence; published gate clipped to capture policy':'one-beat fallback without release evidence'};
    });
    // The harmony under the phrase, where it changed, in the motif's own ticks.
    const segments=[];
    for(const note of phrase.notes){
      if(!note.pool.length)continue;const key=note.pool.join(',');
      if(segments.at(-1)?.key!==key)segments.push({key,time:Math.round((note.quarter-start)*TICKS_PER_QUARTER),pool:note.pool});
    }
    const motif=this.publishMotif(events,{inputUnit:'quarters',timebase:{ticksPerQuarterNote:TICKS_PER_QUARTER},tags:['performer','captured-input'],
      metadata:{durationEvidence,...(segments.length?{harmony:{period:12,segments:segments.map(({time,pool})=>({time,pool}))}}:{}),performer:phrase.source,capturedBy:this.instanceId??'motifprofiler_clodbot'}});
    this.stored.push({motifId:motif.motifId,notes:phrase.notes.length,from:phrase.start,source:phrase.source});
    if(this.stored.length>256)this.stored.shift();
    return motif;
  }
}

export const motifprofilerClodbot=defineBot({
      id: "motifprofiler_clodbot", name: "motifprofiler_clodbot", status: "native", source: "clodbot",
      category: "utility", outputModes: [], pitchContract: "none",
      description:
        "Gathers the performer's phrases from their voice (a listener's notes heard from audio, a MIDI input's notes), each with the chords under it, and stores them in mh_MemoryBOT, so that the bots can recall and develop the performer's material as they do their own.",
    },(...args)=>new MotifProfilerClodbot(...args));
