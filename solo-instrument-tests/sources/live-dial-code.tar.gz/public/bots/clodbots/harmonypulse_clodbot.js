// harmonypulse_clodbot: a fork of mh_HarmonyPulseBOT that counts its harmonic rhythm in the beats a listener feels, and
// fills a phrase however long its bars are (RESEARCH_BACKLOG P1, "Extreme meters, made perceptible").
//
// mh_HarmonyPulseBOT counts its chords in the meter's notated beats, 2 + 2 + 4 + 2 of them from each phrase's start,
// and holds nothing after the last until the phrase ends: ten beats of the sixteen in a phrase of 4/4. Where the notated
// beat is a sixteenth or a thirty-second, or a bar is long, that is a flash and then a silence. MusebotTV season 1's
// band, played in 61/16 at a quarter of 110, struck its four chords in the phrase's first 1.4 s and nothing in the 32 s
// after; in 103/32 at a quarter of 200, 0.4 s and then 15 s; in 61/4 at 30, 20 s of a bar of two minutes.
//
// This fork plays the same chords, voiced and held as the bot it forks voices and holds them. They are counted in felt
// beats (../../shared/meter-tactus.js feltBeats: the notated beat, moved up the bar's groups and a long bar's sections
// while it is faster than a beat is felt), and the progression is played again while a whole one fits in what is left
// of the phrase. Where the notated beat is the felt one and a phrase holds one progression (4/4 at a walking tempo), its
// harmonic rhythm is exactly mh_HarmonyPulseBOT's.
//
// A piece can ask for a slower harmony (settings.leastChordSeconds): each chord lasts at least that long. Its harmonic
// rhythm is drawn with every chord at least the felt beats that last so long at the phrase's felt tempo, and held so
// long. Counted in time, not beats, as a spare piece's harmony is felt (MusebotTV season 2's p043, "sparse piano": its
// chords every two to four felt beats, some nineteen a bar of 43/4, and a pianist plays each). Unset, or 0, as before.
//
// **Its chords are drawn, not a formula** (the owner, 1 October 2026: "Don't allow such hardcoded default chords, from
// harmonypulsebot or anyone; that sort of thing needs to be seed-derived"). mh_HarmonyPulseBOT builds each phrase's four
// chords from the pool it hears, roots a fourth, a fifth and a tone from its notes, in four fixed triad shapes; it hears
// its own pools back, so after the first phrase each progression came from its own last chord, and every piece it led
// from 28 to 30 September (30 of 33 études) ran one succession from C minor, whatever its seed. This fork draws each chord
// (shared/opening-harmony.js drawChord) from the band's harmonic language, near the chord before:
// - its collection: one another bot offers (a pool of five classes or more: harmonyspace_clodbot's, a soloist's
//   scale), else its own, which begins as the piece's opening (drawn from the seed, as every bot's first pool is) and
//   may move where a section begins (settings.moves): a jump to a collection drawn from the space of collections, or a
//   state between, as harmonyspace_clodbot moves;
// - its tuning: the collection's pitches as the band's tuning plan sounds them, so no two chord tones fall together on
//   one degree;
// - its stacks: every s-th pitch of the collection, one to four of them, so its chords are the collection's own
//   (clusters, tertian and quartal stacks, a whole-tone scale's augmented triads, one pitch);
// - its harmonic rhythm: drawn each phrase, not mh_HarmonyPulseBOT's 2 + 2 + 4 + 2 (the owner, 1 October 2026: "no
//   fixed rhythm cells"): a progression whose felt beats divide the phrase's, so a whole one is played again while it
//   fits, split among one to five chords.
// Its own pools heard back are ignored. A chord another bot sounds (a pool of fewer classes) is where its next chord is
// drawn near. A chord bot that leads the harmony (a plan, as harris_clodbot's from its harmonic system) it accompanies, as
// the bot it forks does.
import {defineBot} from '../../framework/index.js';
import {HarmonyPulseBot} from '../families/harmony.js';
import {feltBeats,secondsPerTick} from '../../shared/meter-tactus.js';
import {STOCHASTIC_CONFIG as CONFIG} from '../../stochastic-config.js';
import {unitRandom} from '../../shared/stochastic.js';
import {normalizePitchPool} from '../../shared/pitch.js';
import {applyTuningSystem} from '../../shared/tuning.js';
import {drawCollection,interpolateCollection,collectionPitches} from '../../shared/collection-space.js';
import {drawChord,placeClass} from '../../shared/opening-harmony.js';
import {bandPhraseBars} from '../../shared/opening-time.js';
import {ScoreEvents} from '../../shared/score-time.js';

export const HARMONYPULSE_CLODBOT=Object.freeze({
  // A pool another bot offers is the band's collection where it holds this many classes or more; fewer, a chord (ours:
  // a pentatonic's five).
  collectionClasses:5,
  // Where a section begins, its own collection moves with this chance (settings.moves): to a state between it and one
  // drawn, at a tenth drawn between them, with this chance, else to the one drawn, on a tonic drawn (ours, as
  // harmonyspace_clodbot moves).
  moves:.5,between:.5,tenths:9,
  // Pitches nearer than this (semitones), once the band's tuning sounds them, are one (ours).
  unison:.05,
  // Its harmonic rhythm, drawn each phrase: a progression of up to this many chords (ours: one more than the bot it
  // forks plays), and its length in felt beats a divisor of the phrase's, weighted toward this many beats a chord.
  chordsAtMost:5,beatsPerChord:2.5,
});
const modulo=(value,period)=>((value%period)+period)%period;
// A bot's name from its instance id ('harmonypulse_clodbot:3'), as a message's source says it.
const nameOf=id=>{const text=String(id??''),cut=text.lastIndexOf(':');return cut>0?text.slice(0,cut):text};

export class HarmonyPulseClodbot extends HarmonyPulseBot {
  constructor(send,audio,settings={}){
    super(send,audio,settings);
    this.leastChordSeconds=settings?.leastChordSeconds??0;
    if(!(typeof this.leastChordSeconds==='number'&&Number.isFinite(this.leastChordSeconds)&&this.leastChordSeconds>=0))
      throw new RangeError('settings.leastChordSeconds is a number of seconds, 0 or more');
    this.moves=settings?.moves??HARMONYPULSE_CLODBOT.moves;
    if(!(typeof this.moves==='number'&&this.moves>=0&&this.moves<=1))throw new RangeError('settings.moves is a chance, 0 to 1');
    // Its own collection ({collection, tonic}), a collection another bot offers (a pool), a chord another bot sounds.
    this.own=null;this.offered=null;this.heardChord=null;this.languageSection=null;this.languages=[];
  }
  // A pool another bot offers: the band's collection, or a chord it sounds. Its own, heard back, is neither.
  onMessage(message){
    super.onMessage(message);
    if(!/\/notepool$/.test(message?.address??'')||message.source===nameOf(this.instanceId??this.definitionId))return;
    const pool=normalizePitchPool(message.args);if(!pool.length)return;
    const classes=new Set(pool.map(pitch=>+modulo(pitch,12).toFixed(2)));
    if(classes.size>=HARMONYPULSE_CLODBOT.collectionClasses)this.offered=pool;else this.heardChord=pool;
  }
  // Where a section begins, its own collection may move: a jump, or a state between (never at the piece's start).
  moveLanguage(clock){
    if(!this.own){this.own={collection:this.bandOpening.collection,tonic:this.bandOpening.tonic};this.languageSection=clock.section??0;this.remember(clock,'start',null);return}
    const section=clock.section??0;if(section===this.languageSection)return;this.languageSection=section;
    if(this.offered||!(unitRandom()<this.moves))return;
    const target=drawCollection(unitRandom),{tenths,between}=HARMONYPULSE_CLODBOT;
    if(unitRandom()<between){
      const t=(1+Math.floor(unitRandom()*tenths))/(tenths+1);
      this.own={...this.own,collection:interpolateCollection(this.own.collection,target,t)};this.remember(clock,'between',t);
    }else{this.own={collection:target,tonic:placeClass(Math.floor(unitRandom()*12),this.own.tonic)};this.remember(clock,'jump',null)}
  }
  remember(clock,move,t){
    const entry={tick:clock?.tick??0,section:clock?.section??0,move,...(t!=null?{t}:{}),collection:this.own.collection.label,tonic:this.own.tonic};
    this.languages.push(entry);if(this.languages.length>64)this.languages.shift();
    this.audio?.report?.('harmonypulse_language',entry);
  }
  // Its language's pitches over its register: the collection offered (over the register as it was offered where it spans
  // two octaves, else its classes in every octave), else its own; each as the band's tuning sounds it, ascending.
  languagePitches(){
    const {low,high}=CONFIG.harmonyPulse.register;
    let pitches=[];
    if(this.offered){
      const pool=this.offered,spread=Math.max(...pool)-Math.min(...pool)>=24;
      const classes=[...new Set(pool.map(pitch=>+modulo(pitch,12).toFixed(6)))];
      pitches=spread?pool.filter(pitch=>pitch>=low&&pitch<=high):classes.flatMap(pc=>Array.from({length:Math.ceil((high-low)/12)+1},(_,k)=>low+modulo(pc-low,12)+12*k)).filter(pitch=>pitch<=high);
    }
    if(!pitches.length)pitches=collectionPitches(this.own.collection,{tonic:this.own.tonic,low,high});
    if(this.activeTuning)pitches=pitches.map(pitch=>applyTuningSystem(pitch,this.activeTuning));
    const out=[];for(const pitch of [...pitches].sort((a,b)=>a-b))if(!out.length||pitch-out.at(-1)>HARMONYPULSE_CLODBOT.unison)out.push(+pitch.toFixed(6));
    return out;
  }
  // A phrase's progression: as many chords as the bot it forks plays, each drawn from the language near the one before
  // (the first near the chord last heard or played: at the start, the piece's opening chord).
  generate(clock){
    this.moveLanguage(clock);
    const config=CONFIG.harmonyPulse,pitches=this.languagePitches();
    if(!pitches.length){this.progression=[];return}
    let before=this.previousChord.length?this.previousChord:this.heardChord??this.notes;
    this.durations=this.drawRhythm(clock);
    this.progression=this.durations.map(()=>{const chord=drawChord(pitches,unitRandom,{previous:before});before=chord;return chord});
    this.previousChord=[...this.progression.at(-1)];
    this.publishProgression(clock);
  }
  // A phrase's harmonic rhythm, in felt beats: a length dividing the phrase's (its divisors weighted toward
  // beatsPerChord a chord), split at points drawn among one to chordsAtMost chords. Feasible by construction.
  drawRhythm(clock){
    const {chordsAtMost,beatsPerChord}=HARMONYPULSE_CLODBOT,perTick=clock.meter?secondsPerTick(clock):0;
    const beats=clock.meter?feltBeats(clock.meter,{secondsPerTick:perTick}):[{length:1}];
    const phrase=Math.max(1,(clock.meter?.phraseBars||this.bandTime.meter.phraseBars)*beats.length);
    // Each chord at least the felt beats that last leastChordSeconds at a felt beat's mean length (one, unset).
    const meanSeconds=beats.reduce((sum,beat)=>sum+beat.length,0)/beats.length*perTick;
    const least=this.leastChordSeconds>0&&meanSeconds>0?Math.max(1,Math.ceil(this.leastChordSeconds/meanSeconds-1e-9)):1;
    this.leastBeats=least;
    const lengths=[];for(let length=least;length<=phrase;length++)if(phrase%length===0)lengths.push(length);
    if(!lengths.length)lengths.push(Math.max(least,phrase));
    const weights=lengths.map(length=>Math.exp(-Math.abs(Math.log(length/(Math.max(beatsPerChord,least)*Math.min(chordsAtMost,Math.floor(length/least)))))));
    let draw=unitRandom()*weights.reduce((sum,weight)=>sum+weight,0),total=lengths.at(-1);
    for(const [index,length] of lengths.entries()){draw-=weights[index];if(draw<=0){total=length;break}}
    // Its chords, each `least` felt beats and a share of what is left, split at points drawn.
    const chords=1+Math.floor(unitRandom()*Math.min(chordsAtMost,Math.floor(total/least))),left=total-chords*least;
    const cuts=Array.from({length:chords-1},()=>Math.floor(unitRandom()*(left+1))).sort((a,b)=>a-b),points=[0,...cuts,left];
    return points.slice(1).map((point,index)=>least+point-points[index]);
  }
  // The felt beat beginning at this tick: {index (in the bar), beats (the bar's), seconds (its length)}, or null.
  feltBeat(clock){
    const perTick=secondsPerTick(clock),beats=feltBeats(clock.meter,{secondsPerTick:perTick}),index=beats.findIndex(beat=>beat.start===(clock.tickInBar??0));
    return index<0?null:{index,beats,seconds:beats[index].length*perTick};
  }
  // Following another leader's chords (mh_HarmonyPulseBOT's accompany), its holds are counted in felt beats too: the bot
  // it forks reads a beat's length from the tempo alone.
  accompanyFelt(clock,felt){return super.accompany({...clock,bpm:60/felt.seconds})}
  // Written in felt beats too: the ticks of as many felt beats as it holds, beat after beat from this one (unequal
  // where the bar's groups are), a new chord ending the one before.
  writtenChord(clock,beats,play){
    const felt=this.felt;if(!felt)return super.writtenChord(clock,beats,play);
    let ticks=0;for(let k=0;k<beats;k++)ticks+=felt.beats[(felt.index+k)%felt.beats.length].length;
    const events=this.written??=new ScoreEvents('harmony');
    return events.perform(this.audio,events.create(clock.tick,ticks,{group:'harmony',replace:true}),play);
  }
  onTick(tick,clock){
    if(!clock?.meter)return super.onTick(tick,clock);
    const leader=this.harmonyLeader();
    if(clock.phraseStart&&clock.phrase!==this.lastPhrase){
      this.lastPhrase=clock.phrase;
      if(leader)this.progression=[];else this.generate(clock);
      this.lastStep=-1;
    }
    const felt=this.feltBeat(clock);if(!felt)return;
    this.felt=felt;
    if(leader)return this.accompanyFelt(clock,felt);
    if(!this.progression.length){this.generate(clock);this.lastStep=-1;if(!this.progression.length)return}
    const durations=this.durations;
    // Where the phrase is, in felt beats, and which time through the progression: as many as fit whole, the last chord
    // held after them as the bot it forks holds it.
    const phraseBars=clock.meter.phraseBars||bandPhraseBars(),perBar=felt.beats.length,beat=((clock.bar||0)%phraseBars)*perBar+felt.index;
    const total=durations.reduce((sum,length)=>sum+length,0),times=Math.max(1,Math.floor(phraseBars*perBar/total));
    const time=Math.min(times-1,Math.floor(beat/total));
    let at=beat-time*total,index=0;
    while(index<durations.length-1&&at>=durations[index])at-=durations[index++];
    index%=this.progression.length;
    const step=time*this.progression.length+index;
    if(step===this.lastStep)return;
    this.lastStep=step;
    const chord=this.progression[index],beats=Math.min(Math.max(CONFIG.harmonyPulse.maximumHoldBeats,this.leastBeats??1),durations[index]),seconds=beats*felt.seconds;
    this.broadcast('notepool',chord);
    this.writtenChord(clock,beats,()=>this.audio.chord(chord,seconds,.58));
  }
}

export const harmonypulseClodbot=defineBot({
  id:'harmonypulse_clodbot',name:'harmonypulse_clodbot',status:'native',source:'clodbot',category:'harmony',midiChannel:1,
  performanceType:'polyphonic',outputModes:['synth','midi'],pitchContract:'floating-mpe',specSettings:Object.freeze(['leastChordSeconds','moves']),
  description:'A fork of mh_HarmonyPulseBOT that counts its chords in the beats a listener feels and plays its progression again while a whole one fits in the phrase, so a meter of many sixteenths, or a bar of minutes, has harmony throughout; its chords are drawn from the band\'s harmonic language (the collection another bot offers, else its own from the piece\'s seed, moving where sections begin; as the band\'s tuning sounds it), never a fixed progression.',
},(...args)=>new HarmonyPulseClodbot(...args));
