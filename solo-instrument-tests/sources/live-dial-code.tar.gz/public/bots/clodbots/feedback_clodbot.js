// feedback_clodbot: a mixbot for the desk's feedback loop. The user, 26 September 2026: "The amount of the feedback loop -
// and, eventually, multiple feedback loops - should be variable by one or more mixbots. Feedback can be varied,
// including into positive ranges driving guitar amp simulators or compressors, for musical effect." New, not a fork.
//
// It moves the mix loop (public/mix-feedback.js, by /agent/feedback: public/shared/feedback-loops.js) with the form, as
// mh_RoomBOT (experiments/feedback-room/room-bot.js) moves its room: still through a section, and blooming at a join,
// where one section gives way to the next -- the loop driven past unity through its stage for a span or two, sustaining
// itself, then released back to rest. A span is the bar, where a listener hears the bar as one; a longer bar's closing
// groups, or its closing beats, that are (gestureSpan): a bloom into a join of 7/8 at 160 rises over the bar before it,
// one into a join of 103/4 over that bar's last few beats. How far past unity and how long: by the tension of the sections the join lies
// between (form_clodbot's plan gives each section its tension, 0 to 1). A join between two quiet sections swells the loop
// through its stage and stays under unity. Its stage is the piece's own, drawn by its seed: a tube, tanh, tape, fuzz or
// a compressor, a character for the whole piece. At the end (form_clodbot's closing: Closure) it blooms no more, and
// either takes the loop back to rest before the cadence, or, in some pieces, drives it through the final bar and lets
// it ring on past the last chord, then releases it (the user's own example, TestingMPE, ends in a feedback drone
// fading out). Every rise past unity is asked for with its hold and release, so no loop is left growing.
//
// And it plays the loop as a no-input mixer is played (the user: "a feedback amount, a delay time (must be done in a
// way that doesn't crackle), and an EQ"): each bloom is tuned to the harmony, the desk setting the loop's band and delay
// so that it rings there (public/mix-feedback.js tuneTo). Its pitch is of the pool (in the pool's own tuning, whatever
// it is): of those the loop can ring, the nearest where it rings of itself, the least retuning. When the harmony changes
// under a held drone, the drone glides by its delay, over a felt beat, to the new pool's pitch nearest it: voice-led. The
// drone that outlives the piece is its tonic.
//
// And it plays each bloom at a width (mix-feedback.js MIX_FEEDBACK.widths; the user, 26 September 2026: "A variety of
// feedback EQ widths. Broadband feedback is aggressive, whereas narrowband whistling can deliver expressive melodies,
// and everything between also exists"): broader with the tension, a roar into a climax, a whistle between quiet
// sections, about a width the piece's seed draws, its character. A bloom narrow enough to whistle that is held past
// unity whistles a melody over its hold: from the join's downbeat, on each felt beat, the next of the harmony's pitches
// the loop can ring, gliding there -- rising into more tension, falling into less. (The user again: "Eventually, such
// gestures will likely need to be moved beyond the purview of mixbot": a whistle melody is a player's line.) A roar is
// for an aesthetic that takes one: past a tone's width only as far as the ensemble's character is noise-based (its
// tonality under the middle: shared/aesthetic.js), a pitched one's blooms whistles and tones, its stage never a fuzz; a
// noise-based one's roars further past unity. The user, of a roar in a jazz-leaning band: "it's not fitted well into the
// aesthetic of the composition (which is not one that would normally take aggressive feedback), and it's not very
// aggressive".
import {defineBot} from '../../framework/index.js';
import {Agent} from '../../framework/agent.js';
import {unitRandom} from '../../shared/stochastic.js';
import {secondsPerTick,feltBeats} from '../../shared/meter-tactus.js';
import {A4,SEMITONES_PER_OCTAVE,CENTS_PER_SEMITONE,midiHz} from '../../shared/pitch-course.js';
import {mixFeedbackDesign,tuneTo} from '../../mix-feedback.js';
import {Closure} from '../lib/modules/closure.js';
import {formJoins,withAnnouncement} from '../../shared/form-joins.js';

// ---- Definitions -----------------------------------------------------------------------------------------------
// A span's seconds within longestSpanSeconds, allowing for rounding.
const SPAN_TOLERANCE_SECONDS=1e-9;
// No meter at all: the four beats of four ticks a bot's timekeeping assumes then (meter-tactus.js).
const UNMETERED_BEATS=4,UNMETERED_SUBDIVISION=4;

// ---- Choices ---------------------------------------------------------------------------------------------------
export const FEEDBACK_MIX=Object.freeze({
  // A gesture's span: the bar, or as much of its end as a listener hears as one: the perceived present, a few seconds
  // (Fraisse 1984; London 2012), the longest group meterform_clodbot lays over a bar (its longestGroupSeconds).
  longestSpanSeconds:5,
  // A bloom rises over the span before its join,
  holdSpans:Object.freeze([1,2]),  // is held a span at the least tension, two at the most,
  releaseSpans:2,              // and is released over two
  overUnity:.5,                // its amount: unity and this much more at the most tension (1.5, half again past unity)
  minTension:.35,              // a join under this tension: a swell through the stage, under unity
  swell:.6,
  driveAmount:Object.freeze([.3,.8]),  // how hard the stage is driven, from the least tension to the most
  // The stage each piece is played through, its character, drawn by its seed: among the harsh ones where the ensemble's
  // aesthetic is mostly noise-based (its grit, below, half or more), else among the smooth ones.
  drives:Object.freeze({harsh:Object.freeze(['fuzz','tube']),smooth:Object.freeze(['tube','tanh','tape','compressor'])}),
  // The aesthetic's tonality under which it is noise-based (shared/aesthetic.js: 'noisy' at 0, 'pitched' at 1), and how
  // much further past unity a roar goes at full grit (to the desk's most, twice unity).
  middleTonality:.5,roarOverUnity:.5,harshGrit:.5,
  tailShare:.35,               // the share of pieces a feedback outlives: driven through the final bar's last span and let ring
  tailSpans:2,                 // this many spans past the end before its release
  // Otherwise back to rest over the last span before the cadence.
  // Its drones' pitches: candidates an octave either side of each pool pitch's place nearest the loop's own ring; a
  // drone within this of the pitch asked is left where it is (ours: about the smallest mistuning heard in a held tone).
  octavesSearched:1,
  keepCents:5,
  // Its widths: the piece's own, drawn between these by its seed, broadened by widthSpan times how far the join's tension
  // lies over the middle (0.5) and narrowed by as much under it (ours: a climax's bloom a roar in any piece, a quiet
  // join's a whistle in most).
  widthCentre:Object.freeze([.25,.75]),widthSpan:1,middleTension:.5,
  // A bloom this narrow or narrower, held past unity, whistles a melody: a note a felt beat, gliding into it over this
  // share of the beat (ours: a slide a singer or a theremin player makes, not a jump), at most melodyNotes of them.
  melodyWidth:.25,glideShare:.3,melodyNotes:6,
  // A bloom wider than a tone is a roar by as much: tuned to the harmony's pitch nearest roarHz (ours: an octave and a
  // half over the loop's low cut, the lowest it rings strongly), its stage driven towards the hardest, and its room made
  // rough (feedback-loops.js: a wide band's roughness), so the low howl growls (broadband feedback is aggressive).
  roarHz:300,
  decisionsKept:256,
});
const clamp01=value=>Math.max(0,Math.min(1,value));
const between=([low,high],share)=>low+(high-low)*clamp01(share);
const pitchOf=hz=>A4.note+SEMITONES_PER_OCTAVE*Math.log2(hz/A4.hz);
const pitchClass=pitch=>((pitch%SEMITONES_PER_OCTAVE)+SEMITONES_PER_OCTAVE)%SEMITONES_PER_OCTAVE;
// The loop the desk plays, as renders make it (48 kHz): where it rings of itself, and what it can be tuned to.
let desk=null;const loopDesign=()=>desk??=mixFeedbackDesign();
const barTicksOf=meter=>{
  const groups=Array.isArray(meter?.groups)&&meter.groups.length?meter.groups:null,subdivision=Math.max(1,Number(meter?.subdivision)||UNMETERED_SUBDIVISION);
  return Number(meter?.pulsesPerBar)||(groups?groups.reduce((a,b)=>a+b,0):Number(meter?.numerator)||UNMETERED_BEATS)*subdivision;
};

// The span a gesture is counted in, in ticks, ending on a bar line: the whole bar where it lasts at most
// longestSpanSeconds; else as many of its closing groups (the meter's own) as fit; else as many of its closing felt beats
// (meter-tactus.js feltBeats) as fit; the last felt beat at the least. No meter is named: a bar of 7/8 at 160 (2.6 s) is
// one span, one of 13/4 as 3+3+3+2+2 at 96 (8.1 s) spans its last three groups (4.4 s), one of 103/4 at 84 its last
// seven beats.
export function gestureSpan(meter,{secondsPerTick:perTick}){
  const bar=barTicksOf(meter),fits=ticks=>ticks*perTick<=FEEDBACK_MIX.longestSpanSeconds+SPAN_TOLERANCE_SECONDS;
  if(fits(bar))return bar;
  // The most of the bar's end, from one of these starts (ticks into the bar), that fits.
  const closing=starts=>{const start=starts.find(start=>start>0&&fits(bar-start));return start===undefined?null:bar-start};
  const groups=Array.isArray(meter?.groups)&&meter.groups.length>1?meter.groups:null;
  if(groups){
    const unit=bar/groups.reduce((a,b)=>a+b,0);let at=0;
    const span=closing(groups.map(size=>{const start=Math.round(at);at+=size*unit;return start}));
    if(span!==null)return span;
  }
  const beats=feltBeats(meter,{secondsPerTick:perTick});
  return closing(beats.map(beat=>beat.start))??beats.at(-1).length;
}

export class FeedbackClodbot extends Closure(Agent){
  constructor(send,audio,settings={}){
    super(send,audio);
    this.settings={...settings};this.form=null;this.bloomed=new Set;this.drive=null;this.tail=null;this.ended=false;this.decisions=[];
    // The piece's width: settings.width (0 a whistle to 1 a roar), else drawn by its seed at its first tick.
    this.drone=null;this.announcedSections=[];this.widthCentre=Number.isFinite(Number(settings?.width))?clamp01(Number(settings.width)):null;
  }
  // The harmony's pitches as heard (none before any is: framework/agent.js poolHeard): the pool, in its own tuning.
  pool(){return this.poolHeard?this.notes??[]:[]}
  // Of these pitch classes, the pitch the loop can ring nearest `near` (its own ring unless said), or null; played at a
  // width past a tone's (a roar), the one it can ring at a tone's, the band then widened about it.
  tunedPitch(pitchClasses,near=pitchOf(loopDesign().shape.ringHz),width=null){
    const octaves=FEEDBACK_MIX.octavesSearched,candidates=[...new Set(pitchClasses.filter(Number.isFinite).map(pitchClass))]
      .flatMap(pc=>{const nearest=pc+SEMITONES_PER_OCTAVE*Math.round((near-pc)/SEMITONES_PER_OCTAVE),around=[];for(let k=-octaves;k<=octaves;k++)around.push(nearest+SEMITONES_PER_OCTAVE*k);return around})
      .sort((a,b)=>Math.abs(a-near)-Math.abs(b-near));
    const checked=width!==null&&width<=loopDesign().choices.widths.tone?width:null;
    return candidates.find(pitch=>tuneTo(loopDesign(),midiHz(pitch),{width:checked}).tuned)??null;
  }
  // A felt beat's seconds, the one the clock is in (meter-tactus.js): how long a drone takes to glide.
  feltBeatSeconds(clock){
    const perTick=secondsPerTick(clock),beats=feltBeats(clock.meter,{secondsPerTick:perTick});
    const beat=beats.find(beat=>clock.tickInBar>=beat.start&&clock.tickInBar<beat.start+beat.length)??beats[0];
    return beat.length*perTick;
  }
  decide(entry){this.decisions.push(entry);if(this.decisions.length>FEEDBACK_MIX.decisionsKept)this.decisions.shift()}
  // form_clodbot's plan: its sections and where it begins.
  onPlan(plan){if(plan?.kind==='form')this.form=plan;this.announcedSections=withAnnouncement(this.announcedSections,plan);return super.onPlan?.(plan)}
  // Each join the form has, where the clock will make it (shared/form-joins.js: form_clodbot's form, or PlexBOT's as it
  // announces each section), and the tension it lies between: the greater of the two sections'.
  joins(){return formJoins(this.form,{announced:this.announcedSections}).map(join=>({...join,tension:Math.max(join.fromTension,join.toTension)}))}
  // The span a gesture is counted in at this clock: its ticks, its seconds, and where in the bar it begins.
  span(clock){
    const perTick=secondsPerTick(clock),ticks=gestureSpan(clock.meter,{secondsPerTick:perTick});
    return {ticks,seconds:ticks*perTick,startsAt:barTicksOf(clock.meter)-ticks};
  }
  // Whether the clock has reached the last span of `bar`.
  reached(clock,span,bar){return clock.bar>bar||clock.bar===bar&&clock.tickInBar>=span.startsAt}
  request(clock,request,why){
    this.send('/agent/feedback',[{loop:'mix',...request}]);
    this.decide({tick:clock.tick,bar:clock.bar,why,request});
  }
  // How noise-based the ensemble's aesthetic is, 0 to 1: how far its tonality lies under the middle (a room with no
  // character stated sits at the middle: none).
  grit(){const tonality=Number(this.character?.tonality??FEEDBACK_MIX.middleTonality);return clamp01((FEEDBACK_MIX.middleTonality-tonality)/FEEDBACK_MIX.middleTonality)}
  // How wide a bloom at this tension is played: the piece's width, broader with the tension, narrower without; past a
  // tone's only as far as the aesthetic's grit.
  widthFor(tension){
    const {tone,roar}=loopDesign().choices.widths;
    return Math.min(clamp01(this.widthCentre+FEEDBACK_MIX.widthSpan*(clamp01(tension)-FEEDBACK_MIX.middleTension)),tone+(roar-tone)*this.grit());
  }
  // A bloom into a join, rising over the span before it, by its tension, tuned to the harmony, at its width. One past
  // unity is held: its drone is kept (until its release), to follow the harmony, or, narrow enough, to whistle a melody.
  bloom(clock,span,join){
    const tension=clamp01(join.tension),hold=Math.round(between(FEEDBACK_MIX.holdSpans,tension)),past=tension>=FEEDBACK_MIX.minTension;
    const width=this.widthFor(tension),{tone,roar}=loopDesign().choices.widths,broad=Math.max(0,(width-tone)/(roar-tone));
    const amount=past?Math.min(loopDesign().maxDrivenGain,1+FEEDBACK_MIX.overUnity*tension+FEEDBACK_MIX.roarOverUnity*broad*this.grit()):FEEDBACK_MIX.swell;
    const driveAmount=between(FEEDBACK_MIX.driveAmount,Math.max(tension,broad)),release={seconds:FEEDBACK_MIX.releaseSpans*span.seconds};
    const pitch=this.tunedPitch(this.pool(),broad>0?pitchOf(FEEDBACK_MIX.roarHz):undefined,width);
    this.request(clock,{amount,drive:this.drive,driveAmount,...(pitch!==null?{pitch,width}:{}),seconds:span.seconds,hold:hold*span.seconds,release},
      `${past?'a bloom':'a swell'} into the join at bar ${join.bar} (${join.from} to ${join.to}, tension ${tension.toFixed(2)})${pitch!==null?`, tuned to ${pitch.toFixed(2)}, ${width.toFixed(2)} wide`:''}`);
    const whistles=past&&pitch!==null&&width<=FEEDBACK_MIX.melodyWidth;
    this.drone=past&&pitch!==null?{pitch,amount,driveAmount,release,width,poolKey:this.pool().join(','),until:clock.tick+Math.round((1+hold)*span.seconds/secondsPerTick(clock)),
      melody:whistles?{from:join.bar,direction:join.move>0?1:-1,notes:0}:null}:null;
  }
  // A whistled drone's melody: on each felt beat from the join's downbeat, the next of the harmony's pitches the loop
  // can ring, in its direction (turning back where the loop can ring none further), glided into over glideShare of the
  // beat and held to the drone's end.
  whistle(clock){
    const drone=this.drone,melody=drone?.melody;
    if(!melody||clock.bar<melody.from||melody.notes>=FEEDBACK_MIX.melodyNotes)return;
    const perTick=secondsPerTick(clock),beats=feltBeats(clock.meter,{secondsPerTick:perTick}),beat=beats.find(item=>item.start===clock.tickInBar);
    if(!beat||clock.bar===melody.from&&clock.tickInBar===0)return;
    // A note held at least as long as it glides (the release rings on after it).
    const beatSeconds=beat.length*perTick,glide=FEEDBACK_MIX.glideShare*beatSeconds,hold=(drone.until-clock.tick)*perTick-glide;
    if(!(hold>=glide))return;
    const pitch=this.stepFrom(drone.pitch,melody.direction,drone.width)??this.stepFrom(drone.pitch,melody.direction=-melody.direction,drone.width);
    if(pitch===null)return;
    melody.notes++;
    this.request(clock,{amount:drone.amount,drive:this.drive,driveAmount:drone.driveAmount,pitch,glide:true,width:drone.width,seconds:glide,hold,release:drone.release},
      `the whistle's melody, note ${melody.notes}: from ${drone.pitch.toFixed(2)} ${melody.direction>0?'up':'down'} to ${pitch.toFixed(2)}`);
    drone.pitch=pitch;drone.poolKey=this.pool().join(',');
  }
  // The harmony's nearest pitch past `from` in `direction` (up or down, within an octave) that the loop can ring at this
  // width, or null.
  stepFrom(from,direction,width){
    const least=FEEDBACK_MIX.keepCents/CENTS_PER_SEMITONE,pcs=[...new Set(this.pool().filter(Number.isFinite).map(pitchClass))];
    // Each pitch class's pitches about `from`, those past the least step in the direction and within an octave.
    const candidates=pcs.flatMap(pc=>{const nearest=pc+SEMITONES_PER_OCTAVE*Math.round((from-pc)/SEMITONES_PER_OCTAVE);return [-1,0,1].map(k=>nearest+SEMITONES_PER_OCTAVE*k)})
      .filter(pitch=>direction*(pitch-from)>least&&Math.abs(pitch-from)<=SEMITONES_PER_OCTAVE).sort((a,b)=>Math.abs(a-from)-Math.abs(b-from));
    return candidates.find(pitch=>tuneTo(loopDesign(),midiHz(pitch),{width}).tuned)??null;
  }
  // A held drone whose harmony has changed glides to the new pool's pitch nearest it, over a felt beat, held to its end
  // (a whistle's melody follows the harmony itself).
  followHarmony(clock){
    const drone=this.drone;if(!drone)return;
    if(clock.tick>=drone.until){this.drone=null;return}
    if(drone.melody)return;
    const key=this.pool().join(',');if(key===drone.poolKey)return;
    drone.poolKey=key;
    const pitch=this.tunedPitch(this.pool(),drone.pitch),glide=this.feltBeatSeconds(clock),hold=(drone.until-clock.tick)*secondsPerTick(clock)-glide;
    if(pitch===null||Math.abs(pitch-drone.pitch)*CENTS_PER_SEMITONE<=FEEDBACK_MIX.keepCents||!(hold>0))return;
    this.request(clock,{amount:drone.amount,drive:this.drive,driveAmount:drone.driveAmount,pitch,glide:true,width:drone.width,seconds:glide,hold,release:drone.release},
      `the drone glides from ${drone.pitch.toFixed(2)} to ${pitch.toFixed(2)}, the new harmony's nearest`);
    drone.pitch=pitch;
  }
  onTick(tick,clock){
    if(!clock?.meter)return;
    // The piece's stage and whether a feedback outlives it, drawn once, at its first tick.
    if(this.drive===null){
      const drives=this.grit()>=FEEDBACK_MIX.harshGrit?FEEDBACK_MIX.drives.harsh:FEEDBACK_MIX.drives.smooth;this.drive=drives[Math.min(drives.length-1,Math.floor(unitRandom()*drives.length))];
      this.tail=unitRandom()<FEEDBACK_MIX.tailShare;if(this.widthCentre===null)this.widthCentre=between(FEEDBACK_MIX.widthCentre,unitRandom());
      this.decide({tick,bar:clock.bar,drive:this.drive,tail:this.tail,width:+this.widthCentre.toFixed(3)});
    }
    if(this.ended)return;
    this.followHarmony({...clock,tick});
    this.whistle({...clock,tick});
    const span=this.span(clock);
    // Once the ending is known, no more blooms: only the loop's way out of the piece.
    const closing=this.closingAt({...clock,tick});
    if(closing.ending){
      const {finalBar,cadenceBar}=closing.ending;
      if(this.tail&&this.reached(clock,span,finalBar)){
        this.ended=true;this.drone=null;
        // The drone that outlives the piece is its tonic, as the loop can ring it.
        const tonic=Number(closing.ending.tonic),pitch=this.tunedPitch(Number.isFinite(tonic)?[tonic]:this.pool(),undefined,this.widthCentre);
        this.request({...clock,tick},{amount:1+FEEDBACK_MIX.overUnity,drive:this.drive,driveAmount:FEEDBACK_MIX.driveAmount[1],...(pitch!==null?{pitch,width:this.widthCentre}:{}),seconds:span.seconds,
          hold:FEEDBACK_MIX.tailSpans*span.seconds,release:{seconds:FEEDBACK_MIX.releaseSpans*span.seconds}},`the last chord outlived: driven through the final bar and let ring${pitch!==null?`, on the tonic (${pitch.toFixed(2)})`:''}`);
      }else if(!this.tail&&this.reached(clock,span,cadenceBar-1)){
        this.ended=true;this.drone=null;
        this.request({...clock,tick},{rest:true,seconds:span.seconds},'back to rest before the cadence');
      }
      return;
    }
    for(const join of this.joins()){
      if(this.bloomed.has(join.bar)||clock.bar!==join.bar-1||clock.tickInBar<span.startsAt)continue;
      this.bloomed.add(join.bar);this.bloom({...clock,tick},span,join);
    }
  }
}

export const feedbackClodbot=defineBot(
  {
    id:'feedback_clodbot',name:'feedback_clodbot',status:'native',source:'clodbot',
    category:'conductor',outputModes:[],pitchContract:'none',
    description:'A mixbot for the desk\'s feedback loop, played as a no-input mixer is: still through a section, it blooms at each join of the form -- the mix fed back into itself, driven past unity through a tube, tanh, tape, fuzz or compressor, the piece\'s own, for a bar or two (a long bar\'s last few seconds) by the tension of the sections, then rung out -- each bloom tuned to a pitch of the harmony by the loop\'s delay and EQ, and gliding to the new harmony when it changes under it; at the end it takes the loop back to rest before the cadence, or lets a drone on the tonic ring on past the last chord. Each bloom has a width by its tension about the piece\'s own: a roar into a climax (low, a band two octaves wide and nearly flat, driven hard, its room made rough so the howl growls), a whistle between quiet sections (one mode alone), which, held past unity, whistles a melody through the harmony\'s pitches, gliding a felt beat at a time.',
  },
  (...args)=>new FeedbackClodbot(...args),
);
