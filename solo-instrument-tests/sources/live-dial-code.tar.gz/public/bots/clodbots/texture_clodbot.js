// texture_clodbot: a fork of ae_TextureBOT that times its voices in the transport's own beats (the mathematical audit's B04,
// ../lib/quarter-tempo.js). The port reads the transport's tempo as quarter notes; in 7/8 a voice lasts its bars, where
// the port's took half the time, and in 3/2 it no longer takes twice. The port's code is untouched: regenerate is the port's
// own, given its clock with the tempo in quarter notes (it reads the tempo for nothing else). In a meter of quarters it
// plays exactly as ae_TextureBOT. Made from the class it forks, which agents.js holds, by a function (no import cycle).
import {defineBot} from '../../framework/index.js';
import {quarterNoteClock} from '../lib/quarter-tempo.js';

export function textureClodbotClass(TextureBot){
  return class TextureClodbot extends TextureBot {
    regenerate(clock){return super.regenerate(quarterNoteClock(clock))}
  };
}
export function defineTextureClodbot(TextureBot){
  const TextureClodbot=textureClodbotClass(TextureBot);
  return defineBot({
      id:'texture_clodbot',name:'texture_clodbot',status:'native',source:'clodbot',forkOf:'texture',category:'texture-noise',midiChannel:16,outputModes:['synth', 'midi'],pitchContract:'floating-mpe',
      description:"A fork of ae_TextureBOT that times its voices in the transport's own beats (the mathematical audit's B04): in 7/8 a voice lasts its bars, where the port's took half the time, and in 3/2 it no longer takes twice. In a meter of quarters it plays exactly as ae_TextureBOT.",
    },(...args)=>new TextureClodbot(...args));
}
