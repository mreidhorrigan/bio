// harpsichord_clodbot: a harpsichordist, the seventh of the instrument clodbots (research/family-atlas.md F02, plucked
// and tangent-action string keyboards). New, not a fork: the pianist's hands (piano_clodbot, whose planner, piano.js, is
// the keyboard's) on a harpsichord, whose body is its own. c2's, 29 September.
//
// A harpsichord's jack plucks its string however hard its key is struck, and its damper falls when the key rises, with
// no pedal to lift it. So what a pianist does with force and pedal, a harpsichordist does with time:
// - **Its level does not answer its touch.** Every note plucked at the instrument's one level (its recordings' own), a
//   run's notes as even as its chords'; where the band's attention would have it softer, it has nothing to give.
// - **No sustain pedal.** A note sounds while its key is held: a chord's to its next strike, a run's notes their own
//   length, the left hand's bass to its next.
// - **Its chords arpeggiated**, from the bass upward, a string's delay after the one under it: slower as the band's
//   character is spacious, quicker as it is spiky, never struck quite together (HARPSICHORD_CLODBOT.spread), and all of
//   it within the first half of the chord's length, so every note sounds; the note
//   it brings out (chord-voicing.js broughtOut: its top, or a voice moving under a held top) arrives last and is held
//   the longest, the others let go a little before (the voicing within a chord made of timing, not force).
// - **Its sound:** the Versilian Community Sample Library's English harpsichord, its normal stop (CC0;
//   scripts/download-harpsichord-samples.mjs), else the built-in plucked voice.
// Not modelled yet, and said: ornaments (trills, mordents, a cadence's trill), a registration change (the lute stop is
// in its bank, but a stop changed mid-piece is not yet played), and the manual's coupler.
import {defineBot} from '../../framework/index.js';
import {withScoreTime} from '../../shared/score-time.js';
import {PianoClodbot,PIANO_CLODBOT} from './piano_clodbot.js';
import {PerformedTiming} from '../lib/modules/performed-timing.js';
import {HearsAttention} from '../lib/modules/attention.js';
import {PIANO} from '../../shared/performers/piano.js';
import {broughtOut} from '../../shared/performers/chord-voicing.js';
import {secondsPerTick} from '../../shared/meter-tactus.js';

// Its recordings: VCSL's English harpsichord (scripts/download-harpsichord-samples.mjs).
export const HARPSICHORD_BANK='vcslHarpsichord';
export const HARPSICHORD_CLODBOT=Object.freeze({
  // Its one level (0 to 1: the sampler's, as the pianist's sampleLevel sets its piano's; the built-in plucked voice's
  // gain, at about the median bot voice's loudness: bot-loudness-priors.mjs, 29 September, at the harpist's .026 and
  // full touch it sat 8.7 LU over the median, -27.5 LUFS), and the velocity it tells a voice (full: a recording's own
  // brightness, never darkened as a soft note's would be).
  sampleLevel:.565,voiceGain:.0095,velocity:1,
  // An arpeggiated chord's delay from one string to the next up (s): its least (a chord never struck quite together),
  // and the most, as the character is spacious more than spiky (ours: a quick spread to a lute-like one).
  spread:Object.freeze([.012,.06]),
  // How much sooner than the note it brings out its chord's other notes are let go (s; ours), and the shortest a note
  // sounds (s: a jack's pluck and its damper's fall; ours).
  release:.08,shortest:.03,
});

const clamp01=value=>Math.max(0,Math.min(1,value));

export class HarpsichordClodbot extends PianoClodbot {
  // Its keys: a five-octave manual's, F1 to F6 (instrument-ranges.js).
  static instrument='harpsichord';
  constructor(send,audio,settings={}){
    // Its keyboard the pianist's fantasy one unless a spec asks for fixed keys (`keyboard: 'fixed'`): every instrument
    // microtonal and tunable chord by chord (the owner's standing order, 30 September 2026: "we break the constraints on
    // tuning, and assume that every instrument is microtonal and per-chord tunable"), its recordings pitched to it.
    super(send,audio,{keyboard:'fantasy',...settings});
    this.arpeggios=[];
    // On samples, its recordings, where another bank was loaded for it; a render waits for them (`loading`).
    if(this.audio?.mode==='samples'&&typeof this.audio.loadSampleBank==='function'&&this.audio.samplePreset!=='normal')
      this.loading=this.audio.loadSampleBank(HARPSICHORD_BANK,{preset:'normal'}).catch(error=>this.decide({samples:{preset:'normal',failed:String(error?.message??error)}}));
  }
  // No pedal, and no half-pedal: its dampers fall when its keys rise.
  pedalDepth(){return 0}
  halfPedal(){return 0}
  pedalRing(){return 0}
  // An arpeggio's delay from one string to the next: as the character is spacious more than spiky.
  spread(){
    const [least,most]=HARPSICHORD_CLODBOT.spread,character=this.character;
    const open=character?clamp01(.5+((character.space??.5)-(character.attack??.5))/2):.5;
    return least+(most-least)*open;
  }
  // A comp chord: its right hand's voicing and its left hand's bass (the pianist's hands, piano_clodbot), arpeggiated
  // from the lowest note up, the note brought out last and held longest, every note at the instrument's one level; held
  // as its keys are, no pedal.
  sound(clock,pitches,seconds){
    const compLevel=this.compLevelAt(clock);if(!(compLevel>0))return;
    const final=this.closing?.phase==='final';
    if((clock.tickInBar??0)===0&&!final)this.planRun(clock);
    const running=!final&&this.runPlan?.bar===clock.bar&&this.runPlan.notes.length>0;
    const right=running?[]:pitches.map(pitch=>this.keyOf(pitch)).filter(key=>key!==null),left=running?this.leftComp(clock):this.leftHand(clock);
    const spt=secondsPerTick(clock),tick=clock.tickInBar??0,now=tick*spt;
    const strikes=(this.comp?.bar===clock.bar?this.comp.hits:[]).filter(at=>at>tick&&this.compLevelAt({...clock,tickInBar:at})>0);
    const until=(strikes.length?Math.min(...strikes):clock.meter.pulsesPerBar)*spt-now-PIANO.travel.resetSeconds;
    const held=Math.max(PIANO.strokeSeconds,Math.min(until,seconds));
    const sorted=[...right].sort((a,b)=>a-b),all=[...new Set([...left,...sorted])].sort((a,b)=>a-b);
    // The note it brings out: of its right hand's, the line (broughtOut); it sounds last and is held longest.
    const lineIndex=sorted.length>1?broughtOut(sorted,this.previousVoicing,this.previousLine):sorted.length?0:null,line=lineIndex!==null?sorted[lineIndex]:null;
    // Its spread: the character's, the whole arpeggio within the first half of the chord's hold, so every note sounds;
    // each note let go with its key (the line last of all), none outlasting it.
    const order=[...all.filter(pitch=>pitch!==line),...(line!==null?[line]:[])],step=Math.min(this.spread(),order.length>1?held/2/(order.length-1):Infinity);
    withScoreTime(this.audio,this.compInterval(clock),()=>order.forEach((pitch,k)=>{
      const offset=k*step,own=left.includes(pitch)&&!sorted.includes(pitch)?Math.max(held,until):held;
      const end=pitch===line?own:Math.max(offset+HARPSICHORD_CLODBOT.shortest,own-HARPSICHORD_CLODBOT.release);
      this.key(pitch,Math.max(HARPSICHORD_CLODBOT.shortest,Math.min(own,end)-offset),HARPSICHORD_CLODBOT.velocity,offset);
    }));
    if(sorted.length){this.previousVoicing=sorted;this.previousLine=line}
    this.count(clock,'comp');this.count(clock,'left',left.length);
    this.hands={tick:clock.tick,left,right:sorted,held,...(line!==null?{line}:{}),...(running?{under:'run'}:{})};
    this.arpeggios.push({bar:clock.bar,tick,order,step:+step.toFixed(4),held:+held.toFixed(4),right:sorted,...(line!==null?{line}:{})});if(this.arpeggios.length>64)this.arpeggios.shift();
  }
  // A key: its jack plucking the string at the instrument's one level, however hard the key (a sampled harpsichord, the
  // built-in plucked voice, or MIDI to a harpsichord outside).
  key(pitch,seconds,velocity,offset){
    const touch=HARPSICHORD_CLODBOT.velocity;
    if(this.audio?.mode==='midi'){this.audio.midiNote?.(pitch,seconds,touch,undefined,offset,{instrument:'pluck',profile:'pluck'});return}
    if(this.audio?.mode==='samples'){this.audio.samplePitch?.(pitch,offset,HARPSICHORD_CLODBOT.sampleLevel,seconds,touch);return}
    this.audio?.voice?.(pitch,seconds,HARPSICHORD_CLODBOT.voiceGain,'sawtooth',offset,{instrument:'pluck',profile:'pluck',velocity:touch});
  }
}

export const PerformedHarpsichord=HearsAttention(PerformedTiming(HarpsichordClodbot,{instrument:'comping'}));
export const harpsichordClodbot=defineBot(
  {
    id: "harpsichord_clodbot", name: "harpsichord_clodbot", status: "native", source: "clodbot",
    category: "harmony", midiChannel: 3, performanceType: "polyphonic", outputModes: ["synth", "samples", "midi"],
    // Two hands: its part written on a grand staff, whatever its range (notation/score.js).
    hands: 2,
    sampleBank: HARPSICHORD_BANK,
    // Its keys wherever its pitches are, microtones exact and the tuning plan taken, unless a spec fixes them twelve to the
    // octave (`keyboard: 'fixed'`: a pitch between them left out, never rounded, and a tuning plan declined).
    pitchContract: "floating-mpe",
    specSettings: Object.freeze(["fillness", "fillOrder", "density", "keyboard", "chromatic"]),
    description:
      "A harpsichordist: the pianist's two hands on a harpsichord, whose pluck does not answer the key's force and whose dampers fall when its keys rise, with no pedal: its chords arpeggiated from the bass upward, slower as the band's character is spacious, the note that makes a line arriving last and held longest; comp and run as one continuum, a solo's course, and the band's attention, all at the instrument's one level.",
  },
  (...args) => new PerformedHarpsichord(...args),
);
