// manage_clodbot -- ManageBOT, the ensemble's casting director (research/casting.md).
//
// The user, 26 September 2026: "managebot is a clodbot (should be labeled as such), and you're free to modify its
// behaviour to make it more musical. It would be quite helpful, for example, if it were able to organize groups of bots
// in a way that led to musically interesting sections." Its id is `manage_clodbot` since Musebots 3.0 (30 September);
// `manage`, the id it had, is an alias, so links, saved ensembles and specs are as they were, and its configuration
// (stochastic-config.js `manage`) and random stream keep that name.
//
// It had chosen by counting three function groups toward a target count and rotating the longest-playing performer out
// every four phrases, listening to nobody. Now each section of the form gets a group:
//   * where sections are: where mh_PlexBOT shapes the piece, each section as it announces it a phrase ahead (its rhythm
//     plan: the bar the meter changes on, the role, meter, tempo and density) -- the clock's phrase grid moves with each
//     meter, so only the announcement says exactly when; else the accepted form plan's, placed in absolute bars
//     (sections.js compileSections), exact where the phrase length holds; else, with no form, sections of its own drawn
//     from FormBOT's archetypes and never published as a form;
//   * what each asks: the form bot's tension (or PlexBOT's density) for how many play, PlexBOT's continuity for how much
//     of the last group stays, the home group back where the home comes back;
//   * who fits: every bot's declaration (declarations.js), checked against what the room measures (evidence.js) --
//     needs met, no layer over its carry, nobody buried or heard only by burying two others, nobody metrically lost;
//   * how it changes: sudden where the form asks for contrast, gradual otherwise, sometimes the stage cleared first so a
//     new group is heard as new, sometimes the beat out for a phrase before a sudden addition; and thinned, whatever
//     the tension asks, when the ensemble has played full for long enough (the user: thinning "to reduce acoustic
//     fatigue, or set up new aesthetic topics"), its felt intensity lingering through the reduction.
// And where edit_clodbot has said it will edit a join (/broadcast/edits), the line-up changes there all at once, with
// the edit and the drummer's mark: the user, on an edit heard while the band played on unchanged, "it didn't have
// enough reinforcement from other simultaneous changes to sound intentional." The shared modules rank; this bot draws
// among the best from its own seeded stream.
//
// **Everything it decides is announced and answerable.** A section's casting is an `orchestration` plan published a
// phrase ahead; the bots it names answer from their own declarations and may decline or defer (respond.js); it honours
// them. Anyone may suggest a change on `/agent/casting/suggest` -- a person, another bot, the language model over the
// MCP bridge -- and gets a verdict with its reasons on `/agent/casting/answer`. A person's accepted suggestion is
// enacted. The lifecycle requests themselves are its as they always were, a phrase ahead: a rest is a stop (the bot
// stays loaded and can be cast again), and a leave only at the ensemble's end.
//
// **Its two halves (Musebots 3.0, docs/MUSEBOTS_3.md).** The owner, 30 September 2026: "There is already currently a
// 'managebot' that I think handles entrances and exits from the ensemble mid-piece. Its algorithms are good, but should
// be part of the reorganization." Casting is a conductor's decision (who plays each section, their attention, the feel,
// the rubato); carrying it out is a manager's (the roster, the roll call, loading, each entrance and exit and its fade,
// the stop and leave at the end). One bot holds both unless a spec splits them (settings.role): 'casting' decides and
// announces, and sends no lifecycle request; 'manager' decides nothing, and carries out the castings it hears (their
// entrances, rests and pauses, a phrase ahead, as before; an answering silence from the attention said). Together the two
// send what one sends (test/musebots3.test.mjs). 'both', the default, is ManageBOT as it was.
//
// **Several ManageBOTs, here and across a network** (Musebots 3.0; the owner, 30 September 2026: "Make sure
// manage_clodbots still coordinate with each other across networks"). They had not: each cast every bot it heard, on
// every host, and two sent contradicting requests to the same bots. Now each says it is there, once a bar
// (/broadcast/manage/presence), and all run one rule over what they hear (shared/conducting/election.js):
//   - one casts: of those that cast, the first to have cast (a ManageBOT joining later never takes over mid-piece), then
//     the lowest id; the others follow its castings, keeping its history, home and feeling as they hear them, so that
//     if it is not heard for a few bars (its host dropped) the next casts on from where it was;
//   - each manager carries out the castings for the bots on its own host (ids qualified `host::bot`), and the first of
//     them by id for a host with no manager of its own: every bot has one manager, and no request goes twice;
//   - a casting is carried out only from the one casting, only while it applies, and a revision only after an earlier;
//   - networked, it calls the roll every ROLL_BARS, and forgets another host's bots that did not answer the last call
//     (a host that dropped: nothing else tells the room).
// Alone, it casts and carries out as it always did.
//
// **The people it plays with** (Musebots 3.0; the owner, 30 September 2026: "make sure plex_clodbot (and other relevant
// bots) have contingency plans if other bots (e.g., a profile_clodbot representing a human player or ensemble) input
// new information"). A person playing busily when a section is cast, as their profile says (profile_clodbot,
// /broadcast/profile), is its soloist, the band's shares shrinking around them; a person playing quietly, or none, leaves
// the attention as it was. A profile not heard for a few bars (its host dropped) is no longer counted.
import {Agent,defineBot} from '../../framework/index.js';
import {feelName,sectionFeel} from '../../shared/performance-timing.js';
import {formJoins} from '../../shared/form-joins.js';
import {marksJoin} from '../lib/modules/form-marks.js';
import {STOCHASTIC_CONFIG as CONFIG} from '../../stochastic-config.js';
import {createRandomStream,random} from '../../random-source.js';
import {randomInt,weightedChoice} from '../../shared/stochastic.js';
import {logicalPosition} from '../../shared/planning.js';
import {recordAgentState} from '../../shared/agent-states.js';
import {capabilitiesOf} from '../../../experiments/setup-phase/capabilities.js';
import {RoomEvidence} from '../../shared/casting/evidence.js';
import {declarationOf} from '../../shared/casting/declarations.js';
import {HOME_ROLES,RETURN_ROLES,castSection,compileSections,projectedIntensity} from '../../shared/casting/sections.js';
import {FIT} from '../../shared/casting/fit.js';
import {castingOperators} from '../../shared/form-operators.js';
import {weighSuggestion} from '../../shared/casting/suggestions.js';
import {quarterBpmOf} from '../../shared/casting/measure.js';
import {secondsPerTick} from '../../shared/meter-tactus.js';
import {EDITS_ADDRESS} from '../../shared/form-joins.js';
import {attentionBudget,attentionShares,typicalClaimDb} from '../../shared/attention.js';
import {phraseSpan,sectionFermata} from '../../shared/rubato-plan.js';
import {sectionLevels} from '../../shared/metric-home/sections.js';
import {metricTree} from '../../shared/metric-home/grouping.js';
import {followRubato} from '../../shared/rubato-follower.js';
import {exactOf,floatOfExact} from '../../shared/bounded-exact.js';
import {choosePresentation} from '../../shared/presentation.js';
import {Election,hostOf} from '../../shared/conducting/election.js';
import {Profiles,BUSY} from '../../shared/conducting/contingencies.js';
import {PROFILE_ADDRESS} from './profile_clodbot.js';
import {bandPhraseBars,bandTempo,bandMeter} from '../../shared/opening-time.js';

const round=value=>Number.isFinite(value)?Math.round(value*1000)/1000:null;
// Where the form develops a performer solos (attention.js: the section's hierarchy at its most): of the section's
// performers who take solos (declarations.js `solos`: the front line and the drummer, and a part that says it builds
// one, a pianist), the one who soloed longest ago, so the solos go round the band; among those who have not yet, the
// front line's first, then the harmony's, the bass's and the drummer's (the layers in that order).
const SOLO_ROLES=Object.freeze(['develop']),SOLO_LAYERS=Object.freeze(['melody','filler','bass','beat','texture']);
// Where a theme returns (mh_MemoryBOT's plan for the return), the theme's author is featured: the attention's hierarchy
// partly toward it (ours: halfway to a soloist's share), the returning theme holding the listener's attention, so that
// its ornaments are its license and not thinned by the return's low budget. Not a solo: the section's soloist is none.
const FEATURED_HIERARCHY=.5;
// A part paused and started again (the beat withheld before an entrance, an answering silence) fades over this long each
// way (s): a step in its gain is a click (ours).
const PAUSE_SECONDS=.04;
// An entrance or an exit fades over its configured bars (CONFIG.manage.fadeBars), but never longer than this (s): about a
// bar of 4/4 at the tempo the configuration assumes (ours). A bar of a long meter lasts far longer -- 29/4 at 93, 18.7 s;
// 43/4 at 58, 44.5 s -- and a part faded in over it is all but silent through a bar its score writes at full level (the
// owner, 30 September 2026, of season 2's p029: "a piano whose notated notes correspond to no sound in bar 1").
const FADE_SECONDS=2.5;
// A fade of `bars` in the meter and tempo of the clock, no longer than FADE_SECONDS.
const fadeBarsAt=(bars,clock)=>Math.min(bars,FADE_SECONDS*(Number(clock?.bpm)||bandTempo())/(60*(Number(clock?.meter?.numerator)||bandMeter().numerator)));
// A soloist's announced request for its phrase's tempo, followed (RUB-002; rubato-follower.js): how far from the span's
// plan it may ask (relative), how closely the band follows (relative), and so how steep a change and how far its ending
// may move (both from those two, so that whatever it asks in its box can be followed).
const FOLLOW=Object.freeze({box:.2,tolerance:.05});
// Where a drummer plays, the share of the rubato the band's clock keeps (the drums breathe slightly), the rest said as
// the melodic parts' own rubato over it (the user, 28 September 2026, on kit 05: "drums should have a slightly greater
// preference toward keeping a steady rhythm even when the rest of the band wants to breathe. The drums can breathe
// slightly, but other instrumental parts should be able to have varied rubato, different from them, overtop them ...
// drums tend to have a certain rhythmic 'responsibility' and avoid seeming erratic in tempo"). Ours.
// Where a piece asks for its accompaniment to keep the time too (settings.steady: 'accompaniment'; 2a's brief for
// MusebotTV season 2's p059, "a Chopin-like rubato over a steady left hand"), the band's bass and filler layers (a
// piano's comping, its left hand) keep the clock as a drummer does, and the melody takes its rubato over them.
const DRUMS_KEEP=.3,DRUM_LAYERS=Object.freeze(['beat']),ACCOMPANIMENT_LAYERS=Object.freeze(['beat','bass','filler']);
// A bar longer than a phrase is heard as one (MusebotTV season 2's long primes: 59/4 at 60 is a bar of a minute): each
// bar is its own span, and its arches are its sections (the meter's levels where it has them, else its groups' own groups:
// metric-home), at the level whose arches come nearest a phrase heard as one. Ours: a phrase of about eight seconds.
const LONG_BAR_SECONDS=12,PHRASE_SECONDS=8;
// The arches of a long bar: its sections' shares at the level nearest a phrase's length, or null where it has no level
// between its groups and the bar.
export function barArches(meter,barSeconds){
  const numerator=Number(meter?.numerator),groups=Array.isArray(meter?.groups)?meter.groups:[];
  if(!(numerator>0)||!(barSeconds>0))return null;
  // (Its sections where it has them, so its arches nest in them; else its groups' own groups.)
  const levels=(sectionLevels(meter)??(groups.length?metricTree(groups).levels.map(level=>level.spans):[])).filter(level=>level.length>1&&level.reduce((a,b)=>a+b,0)===numerator);
  if(!levels.length)return null;
  const best=levels.reduce((a,b)=>Math.abs(Math.log(barSeconds/b.length/PHRASE_SECONDS))<Math.abs(Math.log(barSeconds/a.length/PHRASE_SECONDS))?b:a);
  return best.map(size=>size/numerator);
}
// Its halves (settings.role): both (as it was), the casting (a conductor's), or the manager's (the network's).
export const MANAGE_ROLES=Object.freeze(['both','casting','manager']);
function checkedRole(value){
  if(value==null)return 'both';
  if(!MANAGE_ROLES.includes(value))throw new RangeError(`ManageBOT's role is ${MANAGE_ROLES.join(', ')}`);
  return value;
}
function checkedRubato(value){
  if(value==null||value===false)return 0;
  if(!(Number.isFinite(value)&&value>=0&&value<=1))throw new RangeError('ManageBOT\'s rubato is a depth from 0 to 1');
  return value;
}
const phraseBarsOf=clock=>Math.max(1,Number(clock?.meter?.phraseBars)||bandPhraseBars());
// How often, networked, it calls the roll to find the hosts that have gone (bars; ours).
const ROLL_BARS=16;
// A plan's commitment named in 64 hex digits (the follower's context asks one): FNV-1a over the text, eight times salted.
const hashOf=text=>Array.from({length:8},(_,k)=>{let hash=0x811c9dc5^k;for(const c of `${k}:${text}`){hash^=c.charCodeAt(0);hash=Math.imul(hash,0x01000193)}return (hash>>>0).toString(16).padStart(8,'0')}).join('');
const position=(bar,clock,section=null)=>logicalPosition({bar:Math.max(0,bar),phrase:Math.floor(Math.max(0,bar)/phraseBarsOf(clock)),
  section:section??Math.max(0,Number(clock?.section)||0)});

export class ManageClodbot extends Agent {
  constructor(...args){
    super(...args);
    this.states=new Map();
    this.evidence=new RoomEvidence();
    this.activeOrder=[];
    this.requestedDefinitions=new Set();
    this.stopCommitment=null;
    this.lastBar=null;
    this.sections=[];            // compiled sections in bars: the form's, else its own
    this.sectionSource=null;     // the form plan's id@revision, or 'own'
    this.cast=null;              // the last section cast: {key, section, group, planId}
    this.history=[];             // [{key, index, role, group, intensity, startBar}]
    this.home=null;              // the group of the section that established the home
    this.feeling={felt:0,fatigue:0};
    this.schedule=[];            // lifecycle requests still to send
    this.castingPlans=new Map(); // planId -> {key, declined, deferred, responses}
    this.suggestions=[];         // accepted, for the next section
    this.answers=[];             // the last verdicts given
    this.loadsThisPhrase=0;
    this.nextEntranceGroup=randomInt(3);
    this.announcedUntil=null;    // while sections are being announced (PlexBOT), the bar the last announced one ends on
    this.edits=new Map();        // bar -> the edit a mixbot has said it will make at that join
    this.directed=new Map();     // id -> the last lifecycle request sent it: {action: 'start'|'stop', atBar}
    // Each section's feel (shared/performance-timing.js feelForSection): said a phrase ahead with its casting, for the
    // section's first bar, so the rhythm section changes feel on the downbeat the line-up changes on. On unless a spec
    // turns it off (settings.feels: false): the user, 27 September 2026, on the A/B of it: "The different per-section
    // feels here are quite good." The feel in force is the render's until a section changes it.
    this.choosesFeels=args[2]?.feels!==false;
    this.feelInForce=null;
    // Each section's attention (shared/attention.js; the user, 28 September 2026: "a variable overall attention budget
    // (that will change per style), and individual performers' shares of it, with a solo budgeted maximum attention"):
    // said with its casting for the section's first bar. Solos where the form develops, unless a spec turns them off
    // (settings.solos: false).
    this.givesSolos=args[2]?.solos!==false;
    // Each section's rubato (shared/rubato-plan.js), where a spec asks it: settings.rubato, 0 to 1, from none to a
    // Debussy score's (the user's stress test, 28 September 2026: "extremes of rubato—Debussy-level"). Off unless asked.
    this.rubatoDepth=checkedRubato(args[2]?.rubato);
    // Who keeps the time under the melody's rubato: a drummer (the default), or the whole accompaniment.
    this.steady=args[2]?.steady==='accompaniment'?'accompaniment':'drums';
    this.rubatoSaid=[];          // the spans and fermatas said, for inspection
    this.rubatoSpans=new Map();  // bar -> the span said for the phrase there: {id, revision, closes, presses}
    this.soloists=[];            // who soloed, oldest first
    this.attentions=[];          // the last sections' allocations, for inspection
    this.returns=[];             // the themes' returns MemoryBOT plans: {fromBar, toBar, author}
    // How the band makes room for a foreground's entrance (shared/presentation.js; the memorable-motifs report's
    // foreground contract): at a returning theme's window and a solo's first phrase, a silence through its first bar, its
    // register kept clear or a thinner texture, said with the attention. On unless a spec turns it off
    // (settings.presentations: false).
    this.presents=args[2]?.presentations!==false;
    this.presentations=[];       // the entrances presented: {key, kind, author, fromBar, toBar, register?, why, paused?}
    this.allocated=new Map();    // a section's first bar -> what its attention was allocated from, to allocate it again
    this.role=checkedRole(args[2]?.role);
    this.casts=this.role!=='manager';this.carriesOut=this.role!=='casting';
    this.carried=new Set;        // the manager's: the presentations it has carried out
    // Its peers: the other ManageBOTs it hears (shared/conducting/election.js), when it first cast, the latest revision
    // it carried out of each casting, and when each bot was last heard (for the roll calls when networked).
    this.peers=new Election();this.castingSince=null;this.revisions=new Map;this.heardAt=new Map;this.rolledAt=null;
    // Its role, said with its state (the page's agentState carries a bot's protocol capabilities), so the others know it
    // from the roster before the first pulse, before its first word.
    this.protocolCapabilities={...this.protocolCapabilities,manage:{casts:this.casts,carriesOut:this.carriesOut}};
    // The people the band plays with, as their profiles say them (profile_clodbot): one playing busily when a section is
    // cast is its soloist.
    this.profiles=new Profiles();
  }

  // ---- its peers ----------------------------------------------------------------------------------------------------
  get selfId(){return this.instanceId??'manage_clodbot'}
  // Itself, as its peers hear it, and the word it sends them.
  presence(bar=Number(this.currentClock?.bar)||0,{say=true}={}){
    const id=this.selfId;this.peers.setSelf(id);
    this.peers.hear({id,bar,since:this.castingSince,candidate:this.casts,carriesOut:this.carriesOut});
    if(this.castingSince!==null)this.peers.began(id,this.castingSince);
    if(say)this.broadcast('manage/presence',[{instanceId:id,casts:this.casts,carriesOut:this.carriesOut,castingSince:this.castingSince,bar}]);
  }
  // The one that casts now (election.js), and whether it is this one.
  caster(bar=Number(this.currentClock?.bar)||0){this.presence(bar,{say:false});return this.peers.elected(bar)}
  isCaster(bar){return this.casts&&this.caster(bar)===this.selfId}
  // Whether this manager carries out a request for `target`: the first by id of the live managers on the target's host,
  // else, where that host has none, the first of all.
  responsibleFor(target,bar=Number(this.currentClock?.bar)||0){
    if(!this.carriesOut)return false;
    this.presence(bar,{say:false});
    const managers=this.peers.live(bar,peer=>peer.carriesOut).map(peer=>peer.id).sort(),host=hostOf(target);
    return (managers.filter(id=>hostOf(id)===host)[0]??managers[0])===this.selfId;
  }
  // Networked, the roll is called every ROLL_BARS; another host's bot that did not answer the last call is forgotten
  // (its host has gone), and so are its requests.
  callRoll(bar){
    const own=hostOf(this.instanceId);if(own===null||!this.carriesOut)return;
    if(this.rolledAt!==null&&bar-this.rolledAt<ROLL_BARS)return;
    if(this.rolledAt!==null)for(const id of [...this.states.keys()]){
      if(hostOf(id)===own||(this.heardAt.get(id)??-Infinity)>=this.rolledAt)continue;
      this.states.delete(id);this.evidence.forget(id);this.activeOrder=this.activeOrder.filter(item=>item!==id);this.directed.delete(id);
      this.schedule=this.schedule.filter(item=>item.id!==id);this.peers.leave(id);
    }
    this.rolledAt=bar;this.askedRollAt=null;this.askRoll();
  }

  onMessage(message){
    super.onMessage(message);
    this.evidence.observe(message);
    if(message.address===PROFILE_ADDRESS&&message.source!==this.instanceId)this.profiles.hear(message.args?.[0],Number(this.currentClock?.bar)||0);
    if(message.address==='/broadcast/agentState'){
      const state=message.args?.[0];
      if(state?.instanceId){
        this.heardAt.set(state.instanceId,Number(this.currentClock?.bar)||0);
        if(['leaving','left'].includes(state.state))this.peers.leave(state.instanceId);
        // Another ManageBOT in the roster (its role as its state says; one that says none both casts and carries out).
        else if(['manage_clodbot','manage'].includes(state.definitionId)&&state.instanceId!==this.instanceId&&!this.peers.peers.has(state.instanceId)){
          const role=state.protocolCapabilities?.manage;
          this.peers.hear({id:String(state.instanceId),bar:Number(this.currentClock?.bar)||0,candidate:role?Boolean(role.casts):true,carriesOut:role?Boolean(role.carriesOut):true});
        }
        const previous=this.states.get(state.instanceId)?.state;
        recordAgentState(this.states,state);
        // The longest-playing first, a performer back from rest the newest arrival (as it always kept them).
        if(state.state==='performing'){
          if(previous&&previous!=='performing')this.activeOrder=this.activeOrder.filter(id=>id!==state.instanceId);
          if(!this.activeOrder.includes(state.instanceId))this.activeOrder.push(state.instanceId);
        }
        if(state.definitionId)this.requestedDefinitions.delete(state.definitionId);
      }
    }
    // Another ManageBOT, here or on another host.
    if(message.address==='/broadcast/manage/presence'){
      const value=message.args?.[0];
      if(value?.instanceId&&value.instanceId!==this.instanceId)this.peers.hear({id:String(value.instanceId),bar:Number(this.currentClock?.bar)||0,
        since:Number.isFinite(value.castingSince)?value.castingSince:null,candidate:Boolean(value.casts),carriesOut:Boolean(value.carriesOut)});
    }
    if(message.address==='/agent/casting/suggest'&&this.isCaster()&&this.targeted(message))this.weigh(message.args?.[0]||{},message);
    if(message.address==='/broadcast/rubatoRequest'&&this.isCaster())this.followRequest(message.args?.[0]);
    // A manager following another's casting: an answering silence that casting's attention presents, carried out.
    if(message.address==='/broadcast/attention'&&this.carriesOut&&!this.isCaster())this.carryOutPresentation(message.args?.[0]);
    if(message.address===EDITS_ADDRESS){
      const joins=message.args?.[0]?.joins;
      if(Array.isArray(joins))this.edits=new Map(joins.filter(join=>Number.isFinite(Number(join?.bar))).slice(0,64)
        .map(join=>[Number(join.bar),{kind:String(join.kind||'edit'),source:message.args[0].source||message.source||'a mixbot'}]));
    }
  }

  onPlan(plan){
    super.onPlan(plan);
    if(plan.kind==='rhythm'&&typeof plan.payload?.formalRole==='string'&&plan.payload.formalRole)this.announced(plan);
    // A theme's return, planned: its author featured over its window. Where the section it falls in has been cast
    // already, its attention is said again.
    const back=plan.kind==='motif'?plan.payload?.return:null,author=plan.payload?.theme?.author;
    if(back&&back.action==='present'&&typeof author==='string'&&Number.isInteger(plan.appliesAt?.bar)&&Number.isInteger(plan.expiresAt?.bar)&&plan.expiresAt.bar>plan.appliesAt.bar){
      this.returns=[...this.returns.filter(entry=>entry.fromBar!==plan.appliesAt.bar||entry.author!==author),{fromBar:plan.appliesAt.bar,toBar:plan.expiresAt.bar,author}].slice(-16);
      for(const [startBar,inputs] of this.allocated)if(plan.appliesAt.bar>=startBar&&plan.appliesAt.bar<inputs.section.endBar)this.sayAttention(inputs);
    }
    // Another's casting: its author has begun casting; a manager that does not cast now carries it out, if it is the
    // casting of the one that casts.
    if(plan.kind==='orchestration'&&plan.payload?.casting&&plan.author!==this.plans?.author){
      if(!this.peers.peers.has(plan.author))this.peers.hear({id:plan.author,bar:Number(this.currentClock?.bar)||0,candidate:true});
      this.peers.began(plan.author,Number(plan.createdAt?.bar)||0);
      if(this.carriesOut&&!this.isCaster()&&plan.author===this.caster())this.carryOut(plan);
    }
    // The ensemble's end, agreed: everyone stops at its boundary and leaves a phrase later (as it always did), each bot
    // told by its own manager.
    if(plan.kind==='lifecycle'&&plan.payload?.phase==='commitment'&&plan.payload?.action==='stop'&&!this.stopCommitment){
      this.stopCommitment=plan;
      if(!this.carriesOut)return;
      const phraseBars=phraseBarsOf(this.currentClock),leaveAt={...plan.appliesAt,bar:plan.appliesAt.bar+phraseBars,phrase:plan.appliesAt.phrase+1};
      for(const state of this.states.values())if(state.state==='performing'&&!state.messageOnly&&this.responsibleFor(state.instanceId)){
        this.directAt('stop',state.instanceId,plan.appliesAt,{functionGroup:state.functionGroup});
        this.directAt('leave',state.instanceId,leaveAt,{functionGroup:state.functionGroup});
      }
      this.schedule=[];
    }
  }
  onPlanResponse(response){
    const record=this.castingPlans.get(response.planId);if(!record)return;
    record.responses.push({responder:response.responder,disposition:response.disposition,rationale:response.rationale});
    if(response.disposition==='decline')record.declined.add(response.responder);
    if(response.disposition==='defer'){const bar=Number(response.payload?.readyAt?.bar);if(Number.isFinite(bar))record.deferred.set(response.responder,bar)}
  }

  // Before the first pulse: the opening group, so the bots it rests never sound (a render asks publishers first, so
  // PlexBOT's form is already heard). It states no opening meter or tempo.
  onPrepare(clock={}){
    this.evidence.tick(clock);this.prepareClock=clock;
    this.presence(Number(clock.bar)||0);
    if(this.carriesOut)this.askRoll();
    this.updateSections(clock);
    const now=this.sectionAt(Number(clock.bar)||0),casting=this.isCaster(Number(clock.bar)||0);
    if(casting&&now&&this.evidence.performers().length)this.castNow(now,clock,{opening:true});
    // (One that follows another's casting sends what it carries out before the first pulse too.)
    if(this.carriesOut&&!casting)this.sendDue(clock);
    return false;
  }

  onTick(tick,clock){
    this.evidence.tick(clock);
    if(this.stopCommitment)return;
    const bar=Number(clock.bar)||0;
    if(!(clock.barStart||tick===0)||bar===this.lastBar)return;
    this.lastBar=bar;
    this.presence(bar);
    if(clock.phraseStart)this.loadsThisPhrase=0;
    if(this.carriesOut&&!this.evidence.performers().length)this.askRoll();
    this.callRoll(bar);
    this.updateSections(clock);
    const next=this.sections.find(section=>section.startBar>bar);
    if(this.isCaster(bar)){
      if(!this.cast){const now=this.sectionAt(bar);if(now&&this.evidence.performers().length)this.castNow(now,clock,{opening:bar===0})}
      if(next&&next.startBar-bar<=phraseBarsOf(clock)&&!this.history.some(entry=>entry.key===next.key))this.castNow(next,clock);
    }
    if(!this.carriesOut)return;
    this.sendDue(clock);
    // (Loads are asked of the page the casting's host has: its manager asks them.)
    const caster=this.caster(bar);if(caster&&this.responsibleFor(caster,bar))this.fillPool(clock,next);
  }

  // A bot that joins after the others has heard nobody announce themselves: it asks the room to, as a conductor host
  // does (both hosts answer /system/announce with their bot's agentState). Once a phrase at most while it hears no one.
  askRoll(){
    const bar=Number(this.currentClock?.bar)||0;
    if(this.askedRollAt!=null&&bar-this.askedRollAt<phraseBarsOf(this.currentClock))return;
    this.askedRollAt=bar;
    this.send('/system/announce',[]);
  }

  // ---- where sections are ----------------------------------------------------------------------------------------
  // The form plan the room will follow: the best unexpired one heard, by the order every bot ranks forms by
  // (priority, confidence, revision, planId), whether or not it applies yet, so its first section can be cast ahead.
  formPlanHeard(){
    let best=null;const bar=Number(this.currentClock?.bar)||0;
    for(const plan of this.receivedPlans.values()){
      if(plan.kind!=='form'||!Array.isArray(plan.payload?.sections)||!plan.payload.sections.length)continue;
      if(plan.expiresAt&&Number(plan.expiresAt.bar)<=bar&&Number(plan.expiresAt.bar)>0)continue;
      if(!best||plan.priority>best.priority||plan.priority===best.priority&&(plan.confidence>best.confidence
        ||plan.confidence===best.confidence&&(plan.revision>best.revision||plan.revision===best.revision&&plan.planId<best.planId)))best=plan;
    }
    return best;
  }
  sectionAt(bar){let found=null;for(const section of this.sections)if(section.startBar<=bar)found=section;return found}
  // Whether the join a section begins on is one the band marks (form-marks.js marksJoin: the drummer's fill into it, its
  // landing, and the form's scene change on it), read from the form plan it follows (form-joins.js formJoins).
  joinMarked(section){
    const plan=this.formPlanHeard();if(!plan)return false;
    return marksJoin(formJoins(plan).find(entry=>entry.bar===section.startBar));
  }
  // A section as mh_PlexBOT announces it, a phrase before it begins: its rhythm plan applies at the bar the meter
  // changes on and carries the section's role, meter, tempo and density. It replaces whatever was forecast from there.
  announced(plan){
    const start=Number(plan.appliesAt?.bar),end=Number(plan.expiresAt?.bar),payload=plan.payload;
    if(!Number.isFinite(start))return;
    const meter=payload.meter&&typeof payload.meter==='object'?payload.meter:null,role=String(payload.formalRole);
    const phraseBars=Math.max(1,Number(meter?.phraseBars)||bandPhraseBars()),density=Number(payload.density);
    const section=Object.freeze({key:`announced:${plan.planId}`,source:'announced',index:Math.max(0,Number(plan.appliesAt.section)||0),role,
      phrases:Math.max(1,Number(plan.horizon)||1),phraseBars,startBar:start,endBar:Number.isFinite(end)&&end>start?end:start+phraseBars,
      tension:null,hdensity:Number.isFinite(density)?density:null,returnsTo:RETURN_ROLES.includes(role)?0:null,
      meter:meter?{numerator:meter.numerator,denominator:meter.denominator,groups:Array.isArray(payload.tala)?payload.tala:meter.groups,
        subdivision:meter.subdivision,phraseBars}:null,bpm:Number(payload.tempo?.targetBpm)||null});
    if(this.sections.some(existing=>existing.key===section.key))return;
    this.sections=[...this.sections.filter(existing=>existing.startBar<start),section];
    this.sectionSource='announced';this.announcedUntil=section.endBar;
  }
  updateSections(clock){
    const bar=Number(clock.bar)||0;
    // While a form bot announces its sections, the announcements are the sections; a phrase past the last one's end,
    // with nothing new heard, they have stopped and the form plan or its own sections take over.
    if(this.announcedUntil!=null&&bar<=this.announcedUntil+phraseBarsOf(clock))return;
    this.announcedUntil=null;
    const plan=this.formPlanHeard(),source=plan?`${plan.planId}@${plan.revision}`:'own';
    if(source===this.sectionSource&&this.sections.some(section=>section.startBar>bar))return;
    const past=this.sections.filter(section=>section.startBar<=bar);
    let future=[];
    if(plan){
      future=compileSections(plan,{phraseBars:phraseBarsOf(clock)}).filter(section=>section.startBar>bar||(!past.length&&section.startBar===bar))
        .map(section=>({...section,key:`form:${plan.planId}:${section.index}`,source:'form'}));
      // Before the form begins: an opening of its own, up to its first section.
      if(!past.length&&future.length&&future[0].startBar>bar)future.unshift(...this.ownSections(bar,clock,{until:future[0].startBar,count:1}));
    }else{
      // Its own sections continue from the end of the section playing, on a phrase boundary; after a form, from a fresh
      // archetype.
      const current=past.at(-1),phraseBars=phraseBarsOf(clock),after=current?Math.max(current.endBar,bar+1):bar;
      const from=current?Math.ceil(after/phraseBars)*phraseBars:bar;
      if(this.sectionSource&&this.sectionSource!=='own')this.ownRoles=[];
      future=this.ownSections(from,clock,{count:4});
    }
    this.sections=[...past,...future];
    this.sectionSource=source;
  }
  // Sections of its own, when no form bot is shaping the piece: roles from FormBOT's archetypes (drawn by their
  // weights), lengths as FormBOT draws them, the role's tension as its intensity. Casting sections only: never a form.
  ownSections(from,clock,{count=4,until=null}={}){
    const config=CONFIG.formBot,phraseBars=phraseBarsOf(clock),out=[];
    this.ownRoles??=[];
    let bar=from;
    for(let index=0;index<count;index++){
      if(!this.ownRoles.length)this.ownRoles=[...weightedChoice(config.archetypes,config.archetypes.map(item=>item.weight)).roles];
      const role=this.history.length===0&&index===0&&!this.sections.length?'establish':this.ownRoles.shift();
      let phrases=weightedChoice(config.sectionPhrases,config.sectionPhraseWeights);
      if(until!=null)phrases=Math.max(1,Math.round((until-bar)/phraseBars));
      const endBar=until!=null?until:bar+phrases*phraseBars;
      out.push(Object.freeze({key:`own:${bar}`,source:'own',index:this.sections.length+out.length,role,phrases,phraseBars,
        startBar:bar,endBar,tension:config.roleTension[role]??.5,hdensity:null,returnsTo:RETURN_ROLES.includes(role)?0:null,meter:null,bpm:null}));
      bar=endBar;if(until!=null)break;
    }
    return out;
  }

  // ---- who could play ---------------------------------------------------------------------------------------------
  poolMembers(){
    const bar=Number(this.currentClock?.bar)||0;
    return this.evidence.performers().map(entry=>{
      const declaration=declarationOf(entry.definitionId,{category:entry.category,functionGroup:entry.functionGroup,name:entry.name});
      return {id:entry.instanceId,declaration,spectrum:this.evidence.spectrum(entry.instanceId,declaration)?.shares??null,
        heard:this.evidence.measured(entry.instanceId),performing:entry.state==='performing',
        restedFor:entry.state==='performing'?0:entry.restedAt==null?null:bar-entry.restedAt};
    }).filter(member=>!member.declaration.person);
  }
  // Faculties the room has from bots that are never cast: message-only providers (by the census), and harmony a
  // message-only author (a listening bot leading, a silent chord bot) has published.
  silentFaculties(){
    const faculties=new Set;
    for(const entry of this.evidence.roster.values()){
      if(!entry.messageOnly||['leaving','left'].includes(entry.state))continue;
      for(const faculty of capabilitiesOf(entry.definitionId,{name:entry.name,description:''}).provides)faculties.add(faculty);
      if(this.evidence.harmonyAuthors.has(entry.instanceId))faculties.add('harmony');
    }
    return [...faculties];
  }

  // The faculties a group's needs are checked against: the silent ones, and those waived. A need that blocks a follower,
  // which nobody in the room can meet (no performer publishes it, nor a silent author), is waived: its followers play by
  // their own lights rather than the band falling silent around them. A 7/8 roster of drums, a walking bass, comping and
  // a melody, with nobody publishing harmony, was cast as the melody alone (c2, 28 September). The casting says so in its
  // reasons; a provider who joins meets the need again. -> {silent, waived}
  castingFaculties(pool){
    const faculties=this.silentFaculties(),roomProvides=new Set([...faculties,...pool.flatMap(member=>member.declaration.provides)]);
    const waived=[...new Set(pool.flatMap(member=>member.declaration.needs).filter(need=>FIT.blocking.includes(need)&&!roomProvides.has(need)))];
    return {silent:[...faculties,...waived],waived};
  }

  // ---- casting a section ------------------------------------------------------------------------------------------
  castNow(section,clock,{opening=false}={}){
    const pool=this.poolMembers();if(!pool.length)return;
    if(this.castingSince===null){this.castingSince=Number(clock.bar)||0;this.presence(this.castingSince)}
    // What will be playing when this section begins: the last section's group, as cast (its requests may not have
    // taken effect yet), else whoever is playing now.
    const ids=new Set(pool.map(member=>member.id));
    // At the opening nobody has been cast yet: the opening group is built from silence, so its members enter as the
    // build brings them in and everybody else is rested at once, before they sound.
    const current=this.cast?this.cast.group.filter(id=>ids.has(id)):opening?[]:pool.filter(member=>member.performing).map(member=>member.id);
    const {silent,waived}=this.castingFaculties(pool);
    const meter=section.meter||clock.meter||null,byId=new Map(pool.map(member=>[member.id,member]));
    const options={roleTension:CONFIG.formBot.roleTension,continuity:CONFIG.plex.continuity,maxSize:CONFIG.manage.maxSoundAgents,
      quarterBpm:quarterBpmOf(section.bpm||Number(clock.bpm)||bandTempo(),meter||bandMeter()),meter,bar:Number(clock.bar)||0,random,
      join:this.edits.get(section.startBar)||null,opening};
    const suggestions=this.suggestions.map(item=>({enter:item.enter,rest:item.rest,weight:item.source==='person'?CONFIG.manage.personWeight:1}));
    const declined=new Set;let result,plan,record;
    for(let revision=0;revision<=CONFIG.manage.maxRevisions;revision++){
      result=castSection({pool,current,home:this.home,history:this.history,section,state:this.feeling,silent,declined,suggestions,options});
      for(const need of waived){
        const followers=pool.filter(member=>member.declaration.needs.includes(need)&&result.group.includes(member.id)).map(member=>member.declaration.name);
        if(followers.length)result={...result,reasons:[...result.reasons,`nobody in the room publishes ${need}, so ${followers.join(', ')} ${followers.length>1?'play':'plays'} by ${followers.length>1?'their':'its'} own`]};
      }
      // Nothing could be cast (castSection's hold: every group fails a hard check), so the line-up stays as it is, which
      // at the opening is whoever is playing, not the silence an opening builds from. A roster of followers with no
      // harmony to follow, its drummer measured lost in 7/8, cast nobody in any section and rested the whole band at
      // its first bar.
      if(opening&&result.gesture?.kind==='hold')result={...result,group:pool.filter(member=>member.performing).map(member=>member.id)};
      // A song's voice (declaration.sings) is never rested: its words decide the piece (form_clodbot), and the section is
      // cast around it. It enters at the section's first bar, never later in a build (in a long prime bar a build's
      // phrases are minutes without the words).
      const voices=pool.filter(member=>member.declaration.sings).map(member=>member.id);
      if(voices.length){
        result={...result,group:[...new Set([...result.group,...voices])],rest:result.rest.filter(item=>!voices.includes(item.id)),
          enter:[...result.enter.filter(item=>!voices.includes(item.id)),...voices.filter(id=>!current.includes(id)).map(id=>({id,atBar:section.startBar}))],
          reasons:[...result.reasons,`${voices.length>1?'the voices sing':'the voice sings'} its words through, and the section is cast around ${voices.length>1?'them':'it'}`]};
      }
      const entry=id=>({id,definitionId:byId.get(id)?.declaration.id??null});
      const chosen=this.choosesFeels?sectionFeel({role:section.role,home:this.audio?.renderFeel??'straight'}):null,feel=chosen?.name??null,
        placement=chosen?.placement??null;
      // How intense the section will be, for the players who shape the join into it (sections.js projectedIntensity).
      const intensity=projectedIntensity({target:result.target,group:result.group,pool,enter:result.enter,rest:result.rest,quarterBpm:options.quarterBpm,meter});
      const casting={version:1,...(opening?{opening:true}:{}),...(feel?{feel}:{}),...(placement?{placement}:{}),intensity,
        section:{key:section.key,index:section.index,role:section.role,startBar:section.startBar,endBar:section.endBar,phrases:section.phrases,
          phraseBars:section.phraseBars,source:section.source,intensity:round(result.target?.intensity),continuity:round(result.target?.continuity),
          meter:meter?{numerator:meter.numerator,denominator:meter.denominator,groups:meter.groups,subdivision:meter.subdivision}:null},
        group:result.group.map(entry),enter:result.enter.map(item=>({...entry(item.id),atBar:item.atBar})),
        rest:result.rest.map(item=>({...entry(item.id),atBar:item.atBar})),prepare:result.prepare||[],
        gesture:result.gesture,reasons:result.reasons.slice(0,12),felt:round(result.state.felt),fatigue:round(result.state.fatigue),
        // The formal moves this casting makes (shared/form-operators.js: plateau, block collision, withholding, exposure,
        // terminal contraction), read from its gesture and from who stays.
        operators:castingOperators({gesture:result.gesture,prepare:result.prepare||[],remaining:result.group.map(id=>byId.get(id)?.declaration.layer).filter(Boolean),
          last:section.source==='form'&&this.sections.at(-1)?.startBar===section.startBar}),
        suggestions:this.suggestions.map(item=>({source:item.source,enter:item.enter,rest:item.rest,reason:item.reason}))};
      const bar=Number(clock.bar)||0,createdAt=position(bar,clock),appliesAt=position(Math.max(bar,section.startBar),clock,section.index);
      const expiresAt=position(Math.max(appliesAt.bar,section.endBar),clock,section.index);
      const payload={schemaVersion:1,casting},options2={createdAt,appliesAt,expiresAt,confidence:.7,priority:.6,rationale:result.reasons.join('; ').slice(0,2048)};
      // Stored before it is announced: on a synchronous bus the answers arrive inside the announcement.
      plan=plan?this.plans.revise(plan,payload,options2):this.preparePlan('orchestration',payload,options2);
      record={key:section.key,declined:new Set,deferred:new Map,responses:[]};
      this.castingPlans.set(plan.planId,record);
      this.announcePlan(plan);
      // A declined entrant is replaced (declining to rest needs nothing: the bot simply stays).
      const refused=casting.enter.filter(item=>record.declined.has(item.id)).map(item=>item.id);
      if(!refused.length)break;
      for(const id of refused)declined.add(id);
    }
    while(this.castingPlans.size>16)this.castingPlans.delete(this.castingPlans.keys().next().value);
    // At the opening, whoever is playing and is not to enter at the very start is stopped now (a build brings them in
    // later), before the first beat.
    if(opening&&result.gesture?.kind!=='hold'){
      const first=new Set(result.enter.filter(item=>item.atBar<=section.startBar).map(item=>item.id));
      for(const member of pool)if(member.performing&&!first.has(member.id)&&!result.rest.some(item=>item.id===member.id))
        result.rest.push({id:member.id,atBar:section.startBar});
    }
    // Requests still waiting from an earlier casting that this one contradicts are withdrawn.
    this.schedule=this.schedule.filter(item=>!(item.action==='rest'&&result.group.includes(item.id))&&!(item.action==='enter'&&!result.group.includes(item.id)));
    // Declined rests stay; deferred ones wait; the rest is scheduled a phrase ahead of its bar.
    const fade=opening?0:CONFIG.manage.fadeBars;
    for(const item of result.rest)if(!record.declined.has(item.id))this.schedule.push({action:'rest',id:item.id,atBar:Math.max(item.atBar,record.deferred.get(item.id)??-Infinity),planId:plan.planId,fade});
    for(const item of result.enter)if(!record.declined.has(item.id))this.schedule.push({action:'enter',id:item.id,atBar:item.atBar,planId:plan.planId,fade});
    for(const item of result.prepare||[])this.schedule.push({action:'pause',id:item.id,atBar:item.restAt,returnAt:item.returnAt,planId:plan.planId,fade:0});
    const group=result.group.filter(id=>!record.declined.has(id)||current.includes(id));
    this.cast={key:section.key,section,group,planId:plan.planId};
    // A new feel only where the band marks the join (form-marks.js: the drummer fills into it and crashes on it, and the
    // mix changes scene there), or where the piece begins: a feel changed at a join played through would be heard alone,
    // which the user hears as accidental. At an unmarked join the feel in force stays.
    // The feel is its name, or its location where the home is a point between the named feels (said with its name), and
    // any placement its role asks (the laid-back snare where it relaxes): either changing is a new feel.
    const feel=plan.payload.casting.feel,placement=plan.payload.casting.placement??null,said=JSON.stringify([feel,placement]);
    if(feel&&said!==(this.feelInForce??JSON.stringify([this.audio?.renderFeel??'straight',null]))&&(opening||this.joinMarked(section))){
      this.broadcast('feel',[{name:feelName(feel),...(typeof feel==='object'?{location:feel}:{}),atBar:section.startBar,section:section.key,role:section.role,...(placement?{placement}:{})}]);
      this.feelInForce=said;
    }
    // The section's attention: its budget, its soloist if it has one, a returning theme's author featured, and each
    // performer's share, said for its first bar.
    this.sayAttention({section,group,byId,meter,quarterBpm:options.quarterBpm,tension:result.target?.intensity,
      enter:result.enter.filter(item=>!record.declined.has(item.id)).map(item=>({id:item.id,atBar:item.atBar}))});
    if(this.rubatoDepth>0)this.declareRubato(section,clock,meter);
    this.history.push({key:section.key,index:section.index,role:section.role,group,intensity:round(result.target?.intensity),startBar:section.startBar,gesture:result.gesture.kind});
    while(this.history.length>64)this.history.shift();
    if(HOME_ROLES.includes(section.role)&&(section.source==='form'||!this.home))this.home=[...group];
    this.feeling=result.state;
    this.suggestions=[];
    // The casting half sends no lifecycle request: the manager carries its casting out.
    if(!this.carriesOut){this.schedule=[];return}
    if(opening)this.sendDue(clock);
  }

  // ---- the manager's half: a casting carried out ------------------------------------------------------------------
  // A casting heard, as castNow would have scheduled it for itself: its entrances and rests (a declined one not, a
  // deferred one when ready), its pauses, each sent a phrase before its bar; a revision, or a later casting, withdraws
  // what it contradicts. At the opening, whoever plays and is not to enter at the start is rested before the first beat.
  // The requests go at the manager's own opening (onPrepare) or its first pulse, after every revision the casting's
  // answers brought: a spec lists the manager after the casting, so its opening comes before the first pulse.
  carryOut(plan){
    const casting=plan.payload.casting,bar=Number(this.currentClock?.bar)||0;
    // Only while it applies (a casting replayed to a manager that joins late is over), and a revision only after an
    // earlier one (an older revision arriving late is not carried out over a newer).
    if(Number(plan.expiresAt?.bar)>0&&Number(plan.expiresAt.bar)<=bar)return;
    if((this.revisions.get(plan.planId)??0)>=plan.revision)return;
    this.revisions.set(plan.planId,plan.revision);while(this.revisions.size>64)this.revisions.delete(this.revisions.keys().next().value);
    if(!this.castingPlans.has(plan.planId))this.castingPlans.set(plan.planId,{key:casting.section?.key??null,declined:new Set,deferred:new Map,responses:[]});
    while(this.castingPlans.size>16)this.castingPlans.delete(this.castingPlans.keys().next().value);
    const record=this.castingPlans.get(plan.planId),group=(casting.group??[]).map(entry=>entry.id),opening=casting.opening===true;
    const startBar=Number(casting.section?.startBar)||0,fade=opening?0:CONFIG.manage.fadeBars;
    const rest=[...(casting.rest??[])];
    if(opening&&casting.gesture?.kind!=='hold'){
      const first=new Set((casting.enter??[]).filter(item=>item.atBar<=startBar).map(item=>item.id));
      for(const member of this.poolMembers())if(member.performing&&!first.has(member.id)&&!rest.some(item=>item.id===member.id))rest.push({id:member.id,atBar:startBar});
    }
    this.schedule=this.schedule.filter(item=>item.planId!==plan.planId&&!(item.action==='rest'&&group.includes(item.id))&&!(item.action==='enter'&&!group.includes(item.id)));
    for(const item of rest)if(!record.declined.has(item.id))this.schedule.push({action:'rest',id:item.id,atBar:Math.max(item.atBar,record.deferred.get(item.id)??-Infinity),planId:plan.planId,fade});
    for(const item of casting.enter??[])if(!record.declined.has(item.id))this.schedule.push({action:'enter',id:item.id,atBar:item.atBar,planId:plan.planId,fade});
    for(const item of casting.prepare??[])this.schedule.push({action:'pause',id:item.id,atBar:item.restAt,returnAt:item.returnAt,planId:plan.planId,fade:0});
    this.cast={key:casting.section?.key??null,section:casting.section??null,group,planId:plan.planId};
    // What it carried out, kept as the caster keeps it, so that if the caster goes it casts on from there.
    const section=casting.section??{};
    if(section.key&&!this.history.some(entry=>entry.key===section.key)){
      this.history.push({key:section.key,index:section.index,role:section.role,group,intensity:section.intensity??null,startBar:section.startBar,gesture:casting.gesture?.kind??null});
      while(this.history.length>64)this.history.shift();
    }
    if(HOME_ROLES.includes(section.role)&&(section.source==='form'||!this.home))this.home=[...group];
    if(Number.isFinite(casting.felt))this.feeling={felt:casting.felt,fatigue:Number.isFinite(casting.fatigue)?casting.fatigue:0};
  }
  // An answering silence the casting's attention presents (pauseFor), carried out once.
  carryOutPresentation(attention){
    if(attention?.caster&&attention.caster!==this.caster())return;
    const presentation=attention?.presentation;
    if(presentation?.kind!=='silence'||!Number.isInteger(presentation.fromBar))return;
    const key=`silence:${presentation.author}@${presentation.fromBar}`;if(this.carried.has(key))return;this.carried.add(key);
    const byId=new Map(this.poolMembers().map(member=>[member.id,member]));
    this.pauseFor({...presentation},{byId},Object.keys(attention.shares??{}));
  }

  // A soloist's request for its phrase's tempo (RUB-002, the band answering a performer; rubato-follower.js): {id (the
  // span), performer (who asks), from (the first knot asked), densities (seconds per quarter, one a knot from there to
  // the span's end)}, announced before the band commits them. Only the soloist of the section the span is in leads its
  // tempo. The knots from `from` on are planned by the follower from the knot before them, the band following each
  // request within its box and its ending kept in its window; a request outside its box is declined there, and the
  // prepared fallback keeps the band's obligations. Said as a revision of the span, which the clocks take only where
  // nothing of it has been committed.
  followRequest(value){
    const entry=[...this.rubatoSpans.values()].find(span=>span.id===value?.id);
    if(!entry?.knots)return;
    const section=this.attentions.find(allocation=>allocation.startBar<=entry.bar&&entry.bar<(allocation.endBar??Infinity));
    const note=(outcome,extra={})=>{this.rubatoSaid.push({followed:entry.id,performer:value.performer??null,outcome,...extra});while(this.rubatoSaid.length>32)this.rubatoSaid.shift()};
    if(!section?.soloist||value.performer!==section.soloist)return note('declined: only the section\'s soloist leads its tempo');
    const from=Number(value.from),densities=value.densities;
    if(!Number.isInteger(from)||from<1||from>=entry.knots.length||!Array.isArray(densities)||densities.length!==entry.knots.length-from||!densities.every(density=>Number.isFinite(Number(density))&&Number(density)>0))
      return note('declined: a request gives a positive density for each knot from `from` to the span\'s end');
    const knots=entry.knots.slice(from-1),quarter=knot=>knot.at[0]/knot.at[1],origin=quarter(knots[0]);
    const positions=knots.map(knot=>{const n=knot.at[0]*knots[0].at[1]-knots[0].at[0]*knot.at[1],d=knot.at[1]*knots[0].at[1];return `${n}/${d}`});
    const plan=knots.map(knot=>knot.density),q=knots.map(knot=>quarter(knot)-origin);
    let seconds=0;for(let i=1;i<plan.length;i++)seconds+=(plan[i-1]+plan[i])/2*(q[i]-q[i-1]);
    const reach=FOLLOW.box+FOLLOW.tolerance,caps=plan.slice(1).map((density,i)=>String(Math.max(density,plan[i])*reach*2/(q[i+1]-q[i])));
    let follower;
    try{
      follower=followRubato({positions,plan:plan.map(String),slopeCaps:caps,window:[String(seconds*(1-reach)),String(seconds*(1+reach))],joinTime:0,requests:'announced',
        announcedBox:String(FOLLOW.box),tolerance:String(FOLLOW.tolerance),context:{authority:this.instanceId,commitmentHash:hashOf(`${entry.id}:${entry.revision}`),mapRevision:`${entry.id}:${entry.revision}`,planId:entry.id}});
    }catch(error){return note(`declined: ${error.message}`)}
    const steps=densities.map(density=>follower.step(String(Number(density))));
    const revision=entry.revision+1,admitted=follower.revision(1).knots.map(([,density])=>({density:floatOfExact(exactOf(density,{bits:8192}))}));
    this.broadcast('rubatoRevise',[{id:entry.id,revision,from,knots:admitted}]);
    entry.revision=revision;entry.knots=[...entry.knots.slice(0,from),...admitted.map((knot,i)=>({...entry.knots[from+i],density:knot.density}))];
    note('followed',{from,accepted:steps.filter(step=>step.accepted).length,declined:steps.filter(step=>!step.accepted).map(step=>step.reason)});
  }
  // A section's attention allocated and said for its first bar among those who sound from it, and again at each bar
  // where its casting brings more in (again, where a return is planned into it after its casting: the last said for a
  // bar is the one in force). A share said for a player yet to enter has the others answer a part nobody hears: an
  // opening cast as the flute alone, the piano to join at bar 4 with the larger share, had the flute answer it half a
  // phrase late (performers/line.js phraseOffset), and the piece began with two bars of silence (the user, 28
  // September: "we need to fix the bug where some renders have silence at their beginnings").
  sayAttention(inputs){
    this.allocated.set(inputs.section.startBar,inputs);while(this.allocated.size>16)this.allocated.delete(this.allocated.keys().next().value);
    const {section}=inputs,entering=new Map((inputs.enter??[]).filter(item=>item.atBar>section.startBar).map(item=>[item.id,item.atBar]));
    const bars=[...new Set([section.startBar,...[...entering.values()].filter(bar=>bar<section.endBar)])].sort((a,b)=>a-b);
    for(const atBar of bars){
      const present=inputs.group.filter(id=>!(entering.get(id)>atBar));if(!present.length)continue;
      const attention=this.allocateAttention(inputs,present);
      this.broadcast('attention',[{atBar,endBar:section.endBar,...(atBar>section.startBar?{fromBar:section.startBar}:{}),section:section.key,role:section.role,...attention,caster:this.selfId}]);
      const presentation=this.presentations.find(entry=>entry.kind==='silence'&&!entry.paused&&entry.author===attention.presentation?.author&&entry.fromBar===attention.presentation?.fromBar);
      if(presentation)this.pauseFor(presentation,inputs,present);
      this.attentions=[...this.attentions.filter(entry=>entry.startBar!==atBar),{startBar:atBar,endBar:section.endBar,role:section.role,...attention}].slice(-16);
    }
  }
  // A section's attention (shared/attention.js). Each performer's typical claim from its measured density at the
  // section's tempo; the budget their sum, moved by the piece's character (this.character, from /broadcast/character)
  // and the form's tension; where the form develops, a soloist with the most a share may be (of those who take solos,
  // the one who soloed longest ago; SOLO_LAYERS' order among those who have not), the rest shrinking together;
  // where a theme returns in it, the theme's author featured (FEATURED_HIERARCHY toward it; the soloist none); elsewhere
  // each plays as it would.
  // `group`, those sounding at the bar it is said for (the section's group, where all of it sounds from its first bar).
  // -> {budgetDb, hierarchy, soloist, featured, shares: {id: share}, typical: {id: dB}}
  allocateAttention(inputs,group=inputs.group){
    const {section,byId,quarterBpm,tension}=inputs;
    const performers=group.map(id=>{const declaration=byId.get(id)?.declaration;
      return {id,layer:declaration?.layer??null,solos:Boolean(declaration?.solos),typicalDb:typicalClaimDb(declaration,{quarterBpm:quarterBpm||bandTempo()})}});
    // A song's voice singing here is the section's foreground: featured, and no solo over its words.
    const voice=group.find(id=>byId.get(id)?.declaration?.sings)??null;
    // The section's soloist, chosen once (a section allocated again keeps it).
    let soloist=voice?null:inputs.soloist??null;
    // A person the band plays with, playing busily as the section is cast (their profile), is its soloist wherever no
    // song's voice sings, the band lighter around them: their claim the band's loudest part's (ours: a person is heard
    // at least as well as any part), their share never sent to a part.
    if(inputs.person===undefined){const lead=voice||!performers.length?null:this.profiles.lead(Number(this.currentClock?.bar)||0);inputs.person=lead&&lead.activity>=BUSY?lead.voice:null}
    if(inputs.person){performers.push({id:inputs.person,layer:null,solos:true,typicalDb:Math.max(...performers.map(entry=>entry.typicalDb))});if(inputs.soloist===undefined)soloist=inputs.person}
    else if(inputs.soloist===undefined&&this.givesSolos&&SOLO_ROLES.includes(section.role)&&!voice){
      const rank=entry=>{const index=SOLO_LAYERS.indexOf(entry.layer);return index<0?SOLO_LAYERS.length:index};
      const last=entry=>this.soloists.lastIndexOf(entry.id);
      soloist=performers.filter(entry=>entry.solos).reduce((best,entry)=>!best||last(entry)<last(best)||last(entry)===last(best)&&rank(entry)<rank(best)?entry:best,null)?.id??null;
    }
    if(inputs.soloist===undefined){inputs.soloist=soloist;if(soloist){this.soloists.push(soloist);while(this.soloists.length>16)this.soloists.shift()}}
    // A theme returning in the section: its author, where it plays here, featured.
    const featured=soloist?null:voice??this.returns.find(entry=>entry.fromBar<section.endBar&&entry.toBar>section.startBar&&group.includes(entry.author))?.author??null;
    const hierarchy=soloist?1:featured?FEATURED_HIERARCHY:0,shares=attentionShares(performers,{soloist:soloist??featured,hierarchy});
    const budgetDb=attentionBudget({typical:performers.map(entry=>entry.typicalDb),character:this.character,tension:Number.isFinite(tension)?tension:.5});
    // How the others make room for its entrance, where one enters here: a soloist's first phrase, a returning theme's
    // window (a song's voice is its sections' foreground throughout, and has no entrance to present).
    const presentation=this.presents?this.presentationFor(inputs,{soloist,featured:voice?null:featured,group}):null;
    return {budgetDb:round(budgetDb),hierarchy,soloist,featured,
      shares:Object.fromEntries(Object.entries(shares).map(([id,share])=>[id,round(share)])),
      typical:Object.fromEntries(performers.map(entry=>[entry.id,round(entry.typicalDb)])),
      ...(presentation?{presentation:{kind:presentation.kind,author:presentation.author,fromBar:presentation.fromBar,toBar:presentation.toBar,
        ...(presentation.register?{register:[...presentation.register]}:{}),why:presentation.why}}:{})};
  }
  // The presentation of an entrance in the section (shared/presentation.js), chosen once for it: a soloist playing from
  // the section's first bar, through its first phrase; a returning theme's author, through its window. Only what those
  // playing then will carry out: a silence where anyone plays besides the author, said far enough ahead for the lines to
  // end their phrases before it; a register or a texture where a line that makes room plays (declarations.js makesRoom),
  // a register where the author's is known (what the room has heard it play, else its declaration's); never the kind
  // chosen last. -> the entry kept, or null.
  presentationFor({section,byId,meter,quarterBpm},{soloist,featured,group}){
    if(!Number.isInteger(section?.startBar)||!Number.isInteger(section?.endBar))return null;
    const phraseBars=Number(section.phraseBars)||phraseBarsOf(this.currentClock);
    const back=featured&&this.returns.find(entry=>entry.author===featured&&entry.fromBar<section.endBar&&entry.toBar>section.startBar);
    const entrance=soloist&&group.includes(soloist)?{author:soloist,fromBar:section.startBar,toBar:Math.min(section.endBar,section.startBar+phraseBars)}
      :back?{author:featured,fromBar:Math.max(back.fromBar,section.startBar),toBar:back.toBar}:null;
    if(!entrance)return null;
    const key=`${entrance.author}@${entrance.fromBar}`,known=this.presentations.find(entry=>entry.key===key);
    if(known)return known;
    const quarters=meter&&Number(meter.denominator)>0?Number(meter.numerator)*4/Number(meter.denominator):4;
    const author=byId?.get(entrance.author),register=author?.heard?.register??author?.declaration?.register;
    const random=(this.presentationRandom??=createRandomStream(`${this.randomStream?.seed??0}:presentation`));
    const besides=group.filter(id=>id!==entrance.author),lines=besides.filter(id=>byId?.get(id)?.declaration?.makesRoom).length;
    const chosen=choosePresentation({...entrance,barSeconds:quarters*60/(Number(quarterBpm)||bandTempo()),ahead:entrance.fromBar-(Number(this.currentClock?.bar)||0),
      authorRegister:Number.isFinite(register?.low)&&Number.isFinite(register?.high)?[register.low,register.high]:null,
      lines,others:besides.length-lines,last:this.presentations.at(-1)?.kind??null,random:()=>random.next()});
    if(!chosen)return null;
    const entry={key,...chosen};
    this.presentations.push(entry);while(this.presentations.length>16)this.presentations.shift();
    return entry;
  }
  // An answering silence: those playing at its bar who do not make room themselves (declarations.js makesRoom), its
  // author aside, pause through it and come back on the bar after, all at once; one to enter on it enters on the bar after.
  pauseFor(presentation,{byId},present){
    const silent=presentation.fromBar,back=silent+1;
    for(const item of this.schedule)if(item.action==='enter'&&item.atBar===silent&&item.id!==presentation.author)item.atBar=back;
    for(const id of present)if(id!==presentation.author&&!byId?.get(id)?.declaration?.makesRoom)
      this.schedule.push({action:'pause',id,atBar:silent,returnAt:back,planId:null,fade:0});
    presentation.paused=true;
  }

  // A section's rubato, said with its casting a phrase ahead (shared/rubato-plan.js; the clocks play the spans,
  // clock-rubato.js, and keep the holds, clock-hold.js). Each phrase an arch that keeps its length; the section's last
  // phrase yields (cédez) where the band marks the join after it, or where the piece ends, with a fermata on its last
  // felt beat, so the yield lands where the drummer fills and crashes; the phrase before the climax presses (serrez).
  declareRubato(section,clock,meter){
    const m=meter&&Number(meter.pulsesPerBar)>0?meter:clock.meter;
    if(!m||!(Number(m.pulsesPerBar)>0))return;
    // Where a drummer plays in the section (or, where the piece asks it, any of its accompaniment: this.steady), the clock
    // keeps DRUMS_KEEP of the depth and the melodic parts take the rest over it (/broadcast/partRubato, each phrase's
    // arch, which the performance layer plays for the melody's voice).
    const keepers=this.steady==='accompaniment'?ACCOMPANIMENT_LAYERS:DRUM_LAYERS;
    const inputs=this.allocated.get(section.startBar),drums=Boolean(inputs?.group?.some(id=>keepers.includes(inputs.byId?.get(id)?.declaration?.layer)));
    const clockDepth=drums?this.rubatoDepth*DRUMS_KEEP:this.rubatoDepth,partDepth=drums?this.rubatoDepth-clockDepth:0;
    const bpm=Number(section.bpm)||Number(clock.bpm)||bandTempo(),barSeconds=Number(m.pulsesPerBar)*60/bpm/(Number(m.subdivision)||bandMeter().subdivision);
    // A long bar: a span a bar, its sections its arches (barArches).
    const arches=barSeconds>LONG_BAR_SECONDS?barArches(m,barSeconds):null;
    const phraseBars=arches?1:Math.max(1,Number(section.phraseBars)||Number(m.phraseBars)||bandPhraseBars());
    const next=this.sections.find(entry=>entry.startBar===section.endBar)??null,ends=!next;
    const marked=ends||(next&&this.joinMarked(next)),presses=next?.role==='climax';
    for(let bar=section.startBar;bar<section.endBar;bar+=phraseBars){
      const last=bar+phraseBars>=section.endBar,bars=Math.min(phraseBars,section.endBar-bar);
      if(bar<(Number(clock.bar)||0)+1)continue;
      const closes=last&&marked,pressing=last&&presses,before=this.rubatoSpans.get(bar);
      const span=phraseSpan({id:before?.id??`rubato:${this.instanceId}:${bar}`,bar,meter:m,bpm,bars,closes,presses:pressing,depth:clockDepth,arches});
      if(partDepth>0)this.broadcast('partRubato',[{id:`part:${span.id}`,bar,bars,depth:partDepth,closes,presses:pressing,instrument:'melody',...(arches?{arches:[...arches]}:{})}]);
      if(before){
        // A section cast again with more known (the form arriving after ManageBOT's own sections): its span revised where
        // it changes, its knots after the first, while none has sounded (the clocks refuse a revision that reaches a
        // pulse they have committed); otherwise left as said.
        if(before.closes===closes&&before.presses===pressing)continue;
        const revision=before.revision+1;
        this.broadcast('rubatoRevise',[{id:before.id,revision,from:1,knots:span.knots.slice(1).map(knot=>({density:knot.density}))}]);
        this.rubatoSpans.set(bar,{id:before.id,bar,revision,closes,presses:pressing,knots:span.knots});
      }else{
        this.broadcast('rubato',[span]);
        this.rubatoSpans.set(bar,{id:span.id,bar,revision:0,closes,presses:pressing,knots:span.knots});
      }
      while(this.rubatoSpans.size>32)this.rubatoSpans.delete(this.rubatoSpans.keys().next().value);
      const said={bar,bars,closes,presses:pressing,knots:span.knots.length,clockDepth,...(partDepth>0?{partDepth}:{}),...(before?{revised:true}:{})};
      if(last&&marked&&!this.rubatoSaid.some(entry=>entry.fermataBar===section.endBar-1)){
        const fermata=sectionFermata({id:`fermata:${this.instanceId}:${section.endBar-1}`,bar:section.endBar-1,meter:m,bpm,depth:clockDepth});
        this.broadcast('hold',[fermata]);Object.assign(said,{fermata:fermata.seconds,fermataBar:section.endBar-1});
      }
      this.rubatoSaid.push(said);
    }
    while(this.rubatoSaid.length>32)this.rubatoSaid.shift();
  }

  // ---- acting ----------------------------------------------------------------------------------------------------
  // Each lifecycle request goes out a phrase before its bar (the requests have always been a phrase ahead), only if it
  // still makes sense: an entrant not already playing, a rest of a bot that is.
  sendDue(clock){
    const bar=Number(clock.bar)||0,lead=phraseBarsOf(clock),keep=[];
    for(const item of this.schedule){
      // (Another manager's bot is its to tell.)
      if(!this.responsibleFor(item.id,bar))continue;
      // (A rest deferred by its bot waits until it is ready: known here when the casting's answers came after it.)
      const record=this.castingPlans.get(item.planId),deferred=item.action==='rest'?record?.deferred.get(item.id):undefined;
      const atBar=Number.isFinite(deferred)?Math.max(item.atBar,deferred):item.atBar;
      if(atBar-lead>bar){keep.push(item);continue}
      if(record?.declined.has(item.id)&&item.action!=='pause')continue;
      // Whether the bot will be playing at that bar: the last request sent it decides, else its state now.
      const at=Math.max(bar,atBar),last=this.directed.get(item.id),state=this.states.get(item.id)?.state;
      const willPlay=last?last.action==='start':state==='performing';
      if(item.action==='enter'&&!willPlay){
        this.directAt('invite',item.id,position(at,clock),{fadeBars:fadeBarsAt(item.fade,clock)});
        this.directAt('start',item.id,position(at,clock),{fadeBars:fadeBarsAt(item.fade,clock)});
      }
      if(item.action==='rest'&&willPlay)this.directAt('stop',item.id,position(at,clock),{fadeBars:fadeBarsAt(item.fade,clock)});
      if(item.action==='pause'&&willPlay){
        const fadeBars=PAUSE_SECONDS*(Number(clock.bpm)||bandTempo())/(60*(Number(clock.meter?.numerator)||bandMeter().numerator));
        this.directAt('stop',item.id,position(at,clock),{fadeBars});
        this.directAt('start',item.id,position(Math.max(at+1,item.returnAt),clock),{fadeBars});
      }
    }
    this.schedule=keep;
  }
  directAt(action,target,appliesAt,extra={}){
    const state=this.states.get(target);
    if(action==='start'||action==='stop')this.directed.set(target,{action,atBar:appliesAt.bar});
    this.send(`/agent/${action}`,[{target,appliesAt,fadeBars:fadeBarsAt(CONFIG.manage.fadeBars,this.currentClock),coordinator:this.instanceId,
      functionGroup:state?.functionGroup,...extra}]);
  }
  // Where the next section wants more than the room holds, ask the host to load somebody (a live host can; a render
  // says it cannot): the layer the pool lacks first, from the entrance roster.
  fillPool(clock,next){
    if(!next||this.loadsThisPhrase>=CONFIG.manage.maxEntrancesPerPhrase)return;
    const pool=this.poolMembers(),wanted=Math.min(CONFIG.manage.maxSoundAgents,1+Math.round((next.tension??next.hdensity??.5)*(CONFIG.manage.maxSoundAgents-1)));
    const awaiting=[...this.requestedDefinitions].length;
    if(pool.length+awaiting>=wanted)return;
    const present=new Set(pool.map(member=>member.declaration.id)),layers=new Set(pool.map(member=>member.declaration.layer));
    const roster=CONFIG.manage.entranceRoster,groups=Object.keys(roster);
    const candidates=groups.flatMap(group=>roster[group].map(id=>({id,group}))).filter(item=>!present.has(item.id)&&!this.requestedDefinitions.has(item.id));
    if(!candidates.length)return;
    const missing=candidates.filter(item=>!layers.has(declarationOf(item.id).layer));
    const choices=missing.length?missing:candidates,choice=choices[randomInt(choices.length)];
    this.requestedDefinitions.add(choice.id);this.loadsThisPhrase++;
    this.send('/agent/load',[{target:this.instanceId,definitionId:choice.id,functionGroup:choice.group,loadOnly:true,coordinator:this.instanceId}]);
  }

  // ---- suggestions ------------------------------------------------------------------------------------------------
  weigh(payload,message){
    const pool=this.poolMembers(),current=pool.filter(member=>member.performing).map(member=>member.id);
    const clock=this.currentClock,verdict=weighSuggestion(payload,{pool,current,silent:this.castingFaculties(pool).silent,meter:clock?.meter||null,
      secondsPerTick:clock?.meter&&Number(clock.bpm)>0?secondsPerTick(clock):null});
    if(verdict.enter.length||verdict.rest.length)this.suggestions.push({source:verdict.source,enter:verdict.enter,rest:verdict.rest,reason:verdict.reason});
    while(this.suggestions.length>8)this.suggestions.shift();
    const answer={target:payload.requester??message?.source??'*',requestId:payload.requestId??null,coordinator:this.instanceId,...verdict,
      enacted:verdict.source==='person'&&(verdict.enter.length+verdict.rest.length)>0,
      next:this.sections.find(section=>section.startBar>(Number(this.currentClock?.bar)||0))?.startBar??null};
    this.answers.push(answer);while(this.answers.length>16)this.answers.shift();
    this.send('/agent/casting/answer',[answer]);
    return answer;
  }
}

export const manageClodbot=defineBot({
  // Its id manage_clodbot since Musebots 3.0 (the owner, 30 September 2026: "the managebots will need forking to be
  // manage_clodbot"); `manage`, its id before, still names it in specs, saved ensembles, links and targets, and its
  // random stream keeps that name.
  id:'manage_clodbot',aliases:Object.freeze(['manage']),randomId:'manage',name:'manage_clodbot',status:'native',source:'clodbot',category:'conductor',outputModes:[],pitchContract:'none',
  roles:Object.freeze(['conductor','manager']),
  specSettings:Object.freeze(['feels','solos','rubato','steady','presentations','role']),
  description:'ManageBOT, the casting director: gives each section of the form a group of bots -- as many as its tension asks, as much '
    +'of the last group as its continuity keeps, the home group back at the return, each bot checked against its measured '
    +'declaration -- announces it a phrase ahead as a plan the bots may decline, thins the band when it has played full too '
    +'long, and weighs line-up suggestions from people, bots and the language model. It gives each section its feel and its '
    +'attention: a budget from the style and the form, each performer\'s share of it, and a soloist where the form develops.',
},(...args)=>new ManageClodbot(...args));
