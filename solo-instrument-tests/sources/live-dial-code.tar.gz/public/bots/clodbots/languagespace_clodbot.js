// languagespace_clodbot: modalline_clodbot's fork, a line whose pitch language moves through the space of languages
// (shared/pitch-languages/language-space.js). The user's stress test, 28 September 2026: "interpolate continuously
// between different harmonic/tuning/stylistic regimes"; what interpolable means: "intermediate states exist between all
// the their possible states ... but in actual music, parameters can and should jump or have strong discontinuities
// sometimes"; and "We are not building a brute-force system".
//
// Its languages, each a cost for any pitch the line might take next (the stored rules of melodies with the language's
// own mode, and its grammar as the distance from its own pitches), on the line's tonic:
//   - maqamat and ragas (melodic-contour.js): their notes by direction, rests, dwell and path;
//   - rows (rows.js): twelve-tone, and seven classes of 31-EDO;
//   - collections drawn from collection-space.js's families (moments of symmetry, the symmetric collections, the
//     harmonic series, the hexany, a sieve, rast, Bohlen-Pierce's modes);
//   - the harmony the band sounds.
// Where a phrase begins it may move (settings.moves): a jump to a language drawn from the space, or a state between the
// mixture it is in and one it draws, at a tenth drawn between them (settings.between). Every state is one it plays: each
// note is the cheapest of the mixture's options and the points between them, so it chooses and never refuses.
//
// It keeps the base's phrasing (five to nine felt beats, a breath of one or two after each, the stored rules' weights,
// one climax a phrase and not the phrase before's), each phrase drawn toward its register in an arch of four, and its
// motif: the first phrase's opening intervals, which later phrases open with (now and then upside down), each note
// drawn toward the interval's pitch and taking the nearest the current languages offer. So the one motif is heard
// through each language the line passes through. It ends as a piece does (form_clodbot's closing, bots/lib/modules/closure.js):
// no new language once the ending approaches; in the cadence's bar a step toward the tonic; in the last bar the tonic,
// its own length; then nothing. Unlike the base it has no accompaniment: it is a line for a band. Each note says
// in notes.jsonl what it came from: the mixture's languages and weights, each language's degree, class or row
// position, and whether it lies between them.
import {defineBot} from '../../framework/index.js';
import {feltBeats} from '../../shared/meter-tactus.js';
import {voicesPayload} from '../../shared/sounding-voices.js';
import {unitRandom} from '../../shared/stochastic.js';
import {strikeWith} from '../lib/note-language.js';
import {maqamContour,ragaContour} from '../../shared/melodic-contour.js';
import {drawCollection,interpolateCollection,onOneChain} from '../../shared/collection-space.js';
import {FIXTURE_ROW_12} from '../../shared/pitch-languages/rows.js';
import {advanceStates,between,chooseNext,collectionLanguage,harmonyLanguage,mixture,modeLanguage,rowLanguage}
  from '../../shared/pitch-languages/language-space.js';
import {ModallineClodbot,MODALLINE,MODALLINE_PHRASES} from './modalline_clodbot.js';
import {placeClass} from '../../shared/opening-harmony.js';

// ---- The space (ours) -------------------------------------------------------------------------------------------
// Its families of languages, [family, weight].
export const LANGUAGE_SPACE=Object.freeze({
  families:Object.freeze([['maqam',2],['raga',2],['row',2],['collection',2],['harmony',1]].map(Object.freeze)),
  maqamat:Object.freeze(['rast','bayati','hijaz','saba','nahawand']),
  ragas:Object.freeze(['yaman','bhairav','bhupali','todi','khamaj']),
  // Seven classes of 31-EDO beside the twelve-tone fixture: a row over another domain.
  rows:Object.freeze([Object.freeze({id:'12',classes:FIXTURE_ROW_12,steps:12}),Object.freeze({id:'31',classes:Object.freeze([0,5,13,18,26,9,22]),steps:31})]),
});
export const LANGUAGESPACE_FORM=Object.freeze({
  moves:.6,between:.5,tenths:9,
  // How strongly a restated motif's note is drawn to its interval's pitch, a semitone off (ours: enough to keep its
  // contour against the rules' other costs, so that the one motif is heard in each language).
  motif:2.5,
  // At most this many languages in a mixture (a blend of blends keeps its heaviest), and none lighter than this.
  most:3,lightest:.05,
  // Its tonic: one a spec names, else the band's opening root (shared/opening-harmony.js) nearest this (ours: the
  // middle of the line's register); also where a language is placed when none is given.
  tonicNear:60,range:Object.freeze([57,79]),
  // Each phrase's register, semitones about the range's middle, in an arch of four phrases.
  arch:Object.freeze([-3,0,4,-1]),
});
const weighted=(list,random)=>{let draw=random()*list.reduce((sum,[,weight])=>sum+weight,0);for(const [value,weight] of list){draw-=weight;if(draw<=0)return value}return list.at(-1)[0]};

// A language of the space by its name ('maqam rast', 'raga yaman', 'row of 31', 'harmony', or 'collection', drawn), on
// `tonic`; null where the space has none by that name.
export function languageNamed(name,{tonic=LANGUAGESPACE_FORM.tonicNear,random=unitRandom}={}){
  const [family,...rest]=String(name).split(' '),choice=rest.join(' ');
  if(family==='maqam'&&LANGUAGE_SPACE.maqamat.includes(choice))return modeLanguage({id:name,mode:maqamContour(choice,tonic%12),tonic});
  if(family==='raga'&&LANGUAGE_SPACE.ragas.includes(choice))return modeLanguage({id:name,mode:ragaContour(choice,tonic%12),tonic});
  const row=family==='row'&&LANGUAGE_SPACE.rows.find(item=>choice===`of ${item.steps}`);
  if(row)return rowLanguage({id:name,classes:[...row.classes],steps:row.steps,tonic});
  if(family==='collection'){const collection=drawCollection(random);return collectionLanguage({id:`collection ${collection.label}`,collection,tonic})}
  if(family==='harmony')return harmonyLanguage({id:'harmony'});
  return null;
}
// A language from anywhere in the space, on `tonic`: a maqam, a raga, a row, a collection, or the harmony heard.
export function drawLanguage(random=unitRandom,{tonic=LANGUAGESPACE_FORM.tonicNear}={}){
  const family=weighted(LANGUAGE_SPACE.families,random),pick=list=>list[Math.floor(random()*list.length)];
  const name=family==='maqam'?`maqam ${pick(LANGUAGE_SPACE.maqamat)}`:family==='raga'?`raga ${pick(LANGUAGE_SPACE.ragas)}`
    :family==='row'?`row of ${pick(LANGUAGE_SPACE.rows).steps}`:family;
  return languageNamed(name,{tonic,random});
}
// A mixture kept to its heaviest languages, none lighter than `lightest`.
function pruned(mix,{most=LANGUAGESPACE_FORM.most,lightest=LANGUAGESPACE_FORM.lightest}={}){
  return mixture([...mix].sort((a,b)=>b.weight-a.weight).slice(0,most).filter(entry=>entry.weight>=lightest));
}
const describe=mix=>mix.map(({language,weight})=>`${language.id} ${weight.toFixed(2)}`).join(', ');

export class LanguageSpaceClodbot extends ModallineClodbot{
  constructor(send,audio,settings={}){
    super(send,audio,settings);
    // (The base keeps its own settings as `vl`; these are the fork's.)
    this.settings={moves:LANGUAGESPACE_FORM.moves,between:LANGUAGESPACE_FORM.between,opening:'draw',...settings,tonic:settings?.tonic??placeClass(this.bandOpening.root,LANGUAGESPACE_FORM.tonicNear)};
    this.mix=null;this.states={};this.languageMoves=[];this.apexes=[];
  }
  // Its first language: its own draw, or the one a spec names ('maqam rast', 'raga yaman', 'row of 31', 'harmony').
  openingMix(){
    const tonic=this.settings.tonic,named=this.settings.opening;
    const language=named&&named!=='draw'?languageNamed(named,{tonic}):drawLanguage(unitRandom,{tonic});
    if(!language)throw new RangeError(`languagespace_clodbot has no language named ${named}`);
    return mixture([{language,weight:1}]);
  }
  // Where a phrase begins: perhaps a new language, a jump or a state between (once a phrase; never the first).
  moveLanguage(phrase,clock){
    this.mix??=this.openingMix();
    if(phrase===0||(this.closing?.phase??'none')!=='none'||!(unitRandom()<this.settings.moves))return;
    const target=drawLanguage(unitRandom,{tonic:this.settings.tonic});let move;
    if(unitRandom()<this.settings.between){
      const t=(1+Math.floor(unitRandom()*LANGUAGESPACE_FORM.tenths))/(LANGUAGESPACE_FORM.tenths+1),from=this.mix.length===1?this.mix[0].language:null;
      // Between two collections on one chain (two modes of a scale, two pentatonic positions: collection-space.js
      // onOneChain), the collection t of the way along the chain, one note inflected, each keeping its degree; else the
      // mixture's point between.
      if(onOneChain(from?.collection,target.collection)){
        const collection=interpolateCollection(from.collection,target.collection,t);
        this.mix=mixture([{language:collectionLanguage({id:`collection ${collection.label}`,collection,tonic:this.settings.tonic}),weight:1}]);move={move:'between',path:'chain',t,toward:target.id};
      }else{this.mix=pruned(between(this.mix,target,t));move={move:'between',t,toward:target.id}}
    }else{this.mix=mixture([{language:target,weight:1}]);move={move:'jump',to:target.id}}
    const entry={tick:clock.tick,phrase,...move,mixture:describe(this.mix)};
    this.languageMoves.push(entry);if(this.languageMoves.length>64)this.languageMoves.shift();
    this.audio?.report?.('languagespace',entry);this.decide?.(entry);
  }
  // A new phrase: its length and breath (the base's), its register in the arch, and perhaps a new language.
  beginPhrase(clock={}){
    const {beats,breath}=MODALLINE_PHRASES,n=(this.line.phrases??0),[low,high]=LANGUAGESPACE_FORM.range;this.line.phrases=n+1;
    this.moveLanguage(n,clock);
    const {restate,invert}=MODALLINE_PHRASES,motif=n>0&&this.line.motif&&unitRandom()<restate?(unitRandom()<invert?this.line.motif.map(step=>-step):[...this.line.motif]):null;
    this.line.phrase={n,center:(low+high)/2+LANGUAGESPACE_FORM.arch[n%LANGUAGESPACE_FORM.arch.length],
      beats:beats[0]+Math.floor(unitRandom()*(beats[1]-beats[0]+1)),breath:breath[0]+Math.floor(unitRandom()*(breath[1]-breath[0]+1)),at:0,start:null,high:null,
      ...(motif?{motif}:{})};
  }
  // The line's next note, or null in a breath: the cheapest in the mixture, by its languages and the rules of melodies,
  // drawn toward the phrase's register.
  nextNote(clock){
    if(!this.line.phrase)this.beginPhrase(clock);
    let phrase=this.line.phrase;
    // The last bar: one note, the tonic, its own length (everyTick); nothing after it.
    const closing=this.closing?.phase??'none';
    if(closing==='final'&&this.line.finalStruck)return null;
    if(phrase.at>=phrase.beats){
      if(phrase.at<phrase.beats+phrase.breath){phrase.at++;return null}
      this.apexes=[phrase.high,...this.apexes].slice(0,2);
      this.beginPhrase(clock);phrase=this.line.phrase;
    }
    const history=this.line.history??=[],position=phrase.at/Math.max(1,phrase.beats-1),ending=phrase.at===phrase.beats-1||closing==='final';
    const context={range:LANGUAGESPACE_FORM.range,history,center:phrase.center,span:12,weights:MODALLINE_PHRASES.weights,pool:this.notes,
      phrase:{position,start:phrase.start,high:phrase.high,ending,strong:Boolean(clock.barStart),previousHigh:this.apexes[0],
        ...(closing==='cadence'?{penultimate:true}:{}),...(closing==='final'?{final:true}:{})}};
    // (The last note is the tonic, whatever the languages offer: a row has none, and a collection's pull must not keep
    // a piece from closing. Its octave is the cheapest by the languages and the rules.)
    const [low,high]=LANGUAGESPACE_FORM.range,tonics=[];
    if(closing==='final')for(let pitch=this.settings.tonic-48;pitch<=high;pitch+=12)if(pitch>=low)tonics.push(pitch);
    // A restated motif: its next interval's pitch, from the note before.
    const last=history.at(-1),step=phrase.motif&&phrase.at>0&&phrase.at<=phrase.motif.length?phrase.motif[phrase.at-1]:null;
    const target=step!==null&&Number.isFinite(last)?last+step:null;
    const chosen=chooseNext(this.mix,context,{states:this.states,random:unitRandom,noise:closing==='final'?0:MODALLINE_PHRASES.noise,...(tonics.length?{only:tonics}:{}),
      bias:pitch=>MODALLINE_PHRASES.focus*Math.max(0,Math.abs(pitch-phrase.center)-3)+(target!==null?LANGUAGESPACE_FORM.motif*Math.abs(pitch-target):0)});
    if(!chosen)return null;
    this.states=advanceStates(this.mix,this.states,chosen.pitch);
    // The first phrase's opening intervals are the motif.
    if(phrase.n===0&&phrase.at>0&&phrase.at<=MODALLINE_PHRASES.motif&&Number.isFinite(last)){(this.line.motifSteps??=[]).push(chosen.pitch-last);if(this.line.motifSteps.length===MODALLINE_PHRASES.motif-1)this.line.motif=[...this.line.motifSteps]}
    history.push(chosen.pitch);if(history.length>16)history.shift();
    phrase.start??=chosen.pitch;phrase.high=Math.max(phrase.high??-Infinity,chosen.pitch);phrase.at++;
    if(closing==='final')this.line.finalStruck=true;
    return {...chosen,phrase:phrase.n,ending,breath:ending?phrase.breath:0,final:closing==='final',...(target!==null?{motif:phrase.at-1}:{})};
  }
  everyTick(clock){
    if(this.closing?.phase==='after'||!clock.meter)return;
    const beats=feltBeats(clock.meter,{secondsPerTick:this.secondsPerTick(clock)}),beat=beats.find(item=>item.start===clock.tickInBar);
    if(!beat)return;
    const note=this.nextNote(clock);
    if(!note)return;
    // The phrase's last note held into its breath (half of it), then silence until the next phrase -- the piece's last as
    // any phrase's, its arrival its own length, the conductor's stop cutting off whatever still sounds.
    const seconds=Math.max(.15,beat.length*this.secondsPerTick(clock)*(.96+(note.ending?note.breath*.5:0)));
    const {between:isBetween,...sources}=note.sources;
    const language={languages:Object.fromEntries(this.mix.map(({language,weight})=>[language.id,+weight.toFixed(3)])),sources,...(isBetween?{between:true}:{}),
      phrase:note.phrase,...(note.ending?{cadence:true}:{}),...(note.final?{final:true}:{}),...(note.motif!=null?{motif:note.motif}:{})};
    const written=this.lineInterval(clock,beat,note);
    strikeWith(this,[{pitch:note.pitch,language:{languageSpace:language}}],()=>this.play(note.pitch,seconds,MODALLINE.melody,'lead',0,{glide:false,line:'language'},written));
    this.broadcast('voices',[voicesPayload({voice:`${this.instanceId??'languagespace'}:line`,role:'line',pitches:[note.pitch],clock,style:'languagespace'})]);
    this.line.last=note.pitch;
  }
}

export const languagespaceClodbot=defineBot(
  {
    id:'languagespace_clodbot',name:'languagespace_clodbot',status:'native',source:'clodbot',
    category:'melody',midiChannel:9,performanceType:'monophonic',outputModes:['synth','midi'],
    pitchContract:'floating-mpe',nativeTuning:true,
    specSettings:Object.freeze(['moves','between','opening','tonic']),
    description:'modalline_clodbot\'s fork, a phrased line whose pitch language moves through the space of languages: maqamat and ragas by direction, twelve-tone and 31-EDO rows, collections from moments of symmetry to Bohlen-Pierce\'s modes, and the harmony the band sounds. Where a phrase begins it jumps to a language drawn from anywhere or stops between the mixture it is in and another, at any tenth; each note is the cheapest of the languages\' own pitches and the points between them, so between two it takes pitches between theirs. A line for a band, without the base\'s accompaniment.',
  },
  (...args)=>new LanguageSpaceClodbot(...args),
);
