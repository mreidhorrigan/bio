// brass_clodbot: a brass player -- a horn, a trumpet, a trombone or a tuba (the world-instruments atlas's F19, lip-reed
// aerophones) -- for the orchestra (the owner, 2 October 2026: "include the rest of the orchestra to the extent
// possible"). Musebots 3.0's one player per instrument: the flute's player (flute_clodbot), its phrases planned with its
// breaths (shared/performers/wind-line.js) and seated in a brass section where a spec seats it (bots/lib/modules/
// wind-seat.js), playing a brass instrument's registers and breaths. On samples it plays its instrument's recordings
// (VSCO 2 CE's, scripts/download-wind-samples.mjs), else the wind family's voice on a sawtooth, which a plugin's
// synthesizer plays where it has one.
// settings.instrument: horn (unless given), trumpet, trombone or tuba.
import {defineBot} from '../../framework/index.js';
import {FluteClodbot,windPlayerBot} from './flute_clodbot.js';

export class BrassClodbot extends FluteClodbot {static family='brass';static instrument='horn'}
export function defineBrassClodbot(){
  const Bot=windPlayerBot(BrassClodbot);
  return defineBot({
    id:'brass_clodbot',orchestral:true,name:'brass_clodbot',status:'native',source:'clodbot',category:'melody',midiChannel:4,outputModes:['synth','samples','midi'],
    pitchContract:'floating-mpe',specSettings:Object.freeze(['instrument','seat','size','kind','section','arrival','compass','personality','motifs','engine']),
    // (Its compass an object where the engines that will play it say theirs, its windows by instrument: wind-section.js windSeats;
    // the engine it is linked to, what that engine says it plays: instrument-facts.js `engine`.)
    specObjects:Object.freeze(['compass','personality','engine']),
    description:'A brass player -- horn, trumpet, trombone or tuba -- playing phrases of its own motif with its breaths planned with them, as the flute does; seated in a brass section, its part of the conductor\'s formations, breathing at its own times, slurring in a line while its air lasts and tonguing a chord\'s changes.',
  },(...args)=>new Bot(...args));
}
