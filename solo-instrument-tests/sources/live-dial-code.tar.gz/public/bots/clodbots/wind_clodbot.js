// wind_clodbot: a fork of mh_WindBOT that times its wind in the transport's own beats (the mathematical audit's B04,
// ../lib/quarter-tempo.js). The port reads the transport's tempo as quarter notes; in 7/8 each bar's wind lasts the bar, where
// the port's took half the time, and in 3/2 it no longer takes twice. The port's code is untouched: onTick is the port's
// own, given its clock with the tempo in quarter notes (it reads the tempo for nothing else). In a meter of quarters it
// plays exactly as mh_WindBOT. Made from the class it forks, which agents.js holds, by a function (no import cycle).
import {defineBot} from '../../framework/index.js';
import {quarterNoteClock} from '../lib/quarter-tempo.js';

export function windClodbotClass(WindBot){
  return class WindClodbot extends WindBot {
    onTick(tick,clock){return super.onTick(tick,quarterNoteClock(clock))}
  };
}
export function defineWindClodbot(WindBot){
  const WindClodbot=windClodbotClass(WindBot);
  return defineBot({
      id:'wind_clodbot',name:'wind_clodbot',status:'native',source:'clodbot',forkOf:'wind',category:'texture-noise',outputModes:['synth'],pitchContract:'none',
      description:"A fork of mh_WindBOT that times its wind in the transport's own beats (the mathematical audit's B04): in 7/8 each bar's wind lasts the bar, where the port's took half the time, and in 3/2 it no longer takes twice. In a meter of quarters it plays exactly as mh_WindBOT.",
    },(...args)=>new WindClodbot(...args));
}
