// woodwind_clodbot: a reed player -- an oboist, a clarinettist or a bassoonist (the world-instruments atlas's F17 and
// F18, single and double reeds) -- for the orchestra (the owner, 2 October 2026: "include the rest of the orchestra to
// the extent possible"). Musebots 3.0's one player per instrument: the flute's player (flute_clodbot), its phrases
// planned with its breaths (shared/performers/wind-line.js) and seated in a woodwind section where a spec seats it
// (bots/lib/modules/wind-seat.js), playing a reed's instruments, their registers and breaths. On samples it plays its
// instrument's recordings (VSCO 2 CE's, scripts/download-wind-samples.mjs), else the wind family's voice, which a
// plugin's synthesizer plays where it has one.
// settings.instrument: oboe (unless given), clarinet or bassoon.
import {defineBot} from '../../framework/index.js';
import {FluteClodbot,windPlayerBot} from './flute_clodbot.js';

export class WoodwindClodbot extends FluteClodbot {static family='reed';static instrument='oboe'}
export function defineWoodwindClodbot(){
  const Bot=windPlayerBot(WoodwindClodbot);
  return defineBot({
    id:'woodwind_clodbot',orchestral:true,name:'woodwind_clodbot',status:'native',source:'clodbot',category:'melody',midiChannel:4,outputModes:['synth','samples','midi'],
    pitchContract:'floating-mpe',specSettings:Object.freeze(['instrument','seat','size','kind','section','arrival','compass']),
    // (Its compass an object where the engines that will play it say theirs, its windows by instrument: wind-section.js windSeats.)
    specObjects:Object.freeze(['compass']),
    description:'A reed player -- oboe, clarinet or bassoon -- playing phrases of its own motif with its breaths planned with them, as the flute does; seated in a woodwind section, its part of the conductor\'s formations, breathing at its own times, slurring in a line while its air lasts and tonguing a chord\'s changes.',
  },(...args)=>new Bot(...args));
}
