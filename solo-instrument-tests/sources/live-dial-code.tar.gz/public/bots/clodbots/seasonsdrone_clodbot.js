// seasonsdrone_clodbot: a fork of ae_Seasons_Drone that spans its drones in the transport's own beats (the mathematical audit's B04,
// ../lib/quarter-tempo.js). The port reads the transport's tempo as quarter notes; in 7/8 a drone spans its share of the phrase, where
// the port's took half the time, and in 3/2 it no longer takes twice. The port's code is untouched: onTick is the port's
// own, given its clock with the tempo in quarter notes (it reads the tempo for nothing else). Made from the class it
// forks, which agents.js holds, by a function (no import cycle).
//
// Two more corrections, each made around the port's own methods:
// - It drones on the chord tone nearest its anchor (the audit's B05). The port picks the tone whose pitch class is
//   nearest the anchor's by linear distance, so for an anchor B the C a semitone above loses to a G four below. The
//   fork measures around the circle of pitch classes, and sounds the tone at the pitch nearest the anchor's own: the C
//   above the B, not the C eleven below (the audit: a circular choice needs its nearest register to mean anything).
// - A plan of one chord drones again each phrase (the audit's B06). The port sounds a chord when the plan's chord
//   changes, so one chord sounded once, and the phrases after it were silent. As for ae_DroneBOT's own renewal, it is
//   one chord's plans that change: a chord is struck again when a new phrase begins. Where a form's progress drives it,
//   there is no phrase to repeat, and nothing changes.
// As registered, its calls wait for the pulse they fall in (../lib/pulse-release.js; the audit's T01), so a tempo curve
// keeps its notes on the beat; its class here is the fork without that (the twin tests' subject).
import {defineBot} from '../../framework/index.js';
import {pitchClass} from '../../shared/pitch.js';
import {quarterNoteClock} from '../lib/quarter-tempo.js';
import {releasedInPulse} from '../lib/pulse-release.js';

// The pitch of the chord's tone nearest the anchor (a pitch class), around the circle of pitch classes, sounded at the
// pitch nearest the anchor's own in the octave from `base`. The anchor itself, where the chord holds it. Null for a chord
// with no pitch or no anchor.
export function nearestAnchoredPitch(chord,anchor,base){
  const classes=[...new Set(chord.map(pitchClass).filter(value=>value!==null))].sort((a,b)=>a-b);
  if(!classes.length||!Number.isFinite(anchor))return null;
  const offset=value=>{const up=((value-anchor)%12+12)%12;return up>6?up-12:up};
  const nearest=classes.reduce((best,value)=>Math.abs(offset(value))<Math.abs(offset(best))?value:best);
  return base+anchor+offset(nearest);
}

// What the fork changes but its timing: the anchored tone (B05) and one chord's renewal (B06).
export function seasonsdroneCorrections(SeasonsDroneBot){
  return class extends SeasonsDroneBot {
    onTick(tick,clock){
      // A new phrase begins: its chord is a new chord, even the one the phrase before sounded.
      if(this.chords.length===1&&!this.hasProgress){
        const phrase=Math.floor((clock?.bar||0)/Math.max(1,this.phraseBars));
        if(phrase!==this.renewedPhrase){this.renewedPhrase=phrase;this.lastChord=null}
      }
      return super.onTick(tick,clock);
    }
    render(note,duration,velocity,delay){
      const chord=this.chords[this.lastChord],pitch=chord?nearestAnchoredPitch(chord,this.anchor,this.config.octave*12):null;
      return super.render(pitch??note,duration,velocity,delay);
    }
  };
}
// The fork: those corrections, told the tempo in quarter notes (B04).
export function seasonsdroneClodbotClass(SeasonsDroneBot){
  return class SeasonsDroneClodbot extends seasonsdroneCorrections(SeasonsDroneBot) {
    onTick(tick,clock){return super.onTick(tick,quarterNoteClock(clock))}
  };
}
export function defineSeasonsdroneClodbot(SeasonsDroneBot){
  const SeasonsDroneClodbot=releasedInPulse(seasonsdroneClodbotClass(SeasonsDroneBot));
  return defineBot({
      id:'seasonsdrone_clodbot',name:'seasonsdrone_clodbot',status:'native',source:'clodbot',forkOf:'seasonsDrone',category:'melody',midiChannel:16,outputModes:['synth', 'midi'],pitchContract:'floating-mpe',
      description:"A fork of ae_Seasons_Drone that spans its drones in the transport's own beats (the mathematical audit's B04): in 7/8 a drone spans its share of the phrase, where the port's took half the time, and in 3/2 it no longer takes twice. It drones on the chord tone nearest its anchor around the circle of pitch classes, at the pitch nearest the anchor (B05), and a plan of one chord drones again each phrase, where the port's fell silent after it (B06). Under a tempo curve its notes stay on the beat: each waits for the pulse it falls in and is placed at that pulse's tempo (T01).",
    },(...args)=>new SeasonsDroneClodbot(...args));
}
