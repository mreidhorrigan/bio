// tunespace_clodbot: mh_TuneBOT's fork, whose tuning moves through the space of tunings (shared/tuning-space.js). The
// user's stress test, 28 September 2026: "interpolate continuously between different harmonic/tuning/stylistic
// regimes"; and what interpolable means: "intermediate states exist between all the their possible states ... but in
// actual music, parameters can and should jump or have strong discontinuities sometimes".
//
// A tuning regime here has two coordinates, each with every state between its ends:
// - its system: a period and its degrees (equal divisions from 5 to 53, drawn toward just intonation by a purity, or
//   the tritave's thirteen steps), any two joined by tuning-space.js's states between;
// - its chords' exactness: 0, every chord tone on the system's degrees; 1, every chord in just intonation as the base
//   tunes it; anything between.
// Where a phrase begins it may move: a jump to a regime drawn from the space, or a state between the regime it is in
// and one it draws, at a tenth drawn between them. Every state it can reach is one the ensemble plays, so it chooses
// and never refuses (the user: "We are not building a brute-force system"). Otherwise it offers its tuning as the base
// does, a phrase ahead, with the base's chord-wise just intonation blended by its exactness.
import {defineBot} from '../../framework/index.js';
import {TuneBot} from '../families/planning.js';
import {unitRandom} from '../../shared/stochastic.js';
import {tuningSystem,applyTuningSystem} from '../../shared/tuning.js';
import {equalTuning,interpolateTuning} from '../../shared/tuning-space.js';

// ---- The space ------------------------------------------------------------------------------------------------------
// Where it draws regimes from (ours). [value, weight] lists.
export const TUNING_SPACE=Object.freeze({
  divisions:Object.freeze([[5,1],[7,1],[10,1],[12,2],[15,1],[17,1],[19,1],[22,1],[24,1],[31,2],[41,1],[53,1]].map(Object.freeze)),
  tritave:.08,               // the share of draws that are the tritave's thirteen steps (Bohlen-Pierce)
  purity:Object.freeze([0,3]),   // how far a system's degrees are drawn toward just intervals (shared/tuning.js)
  equal:.4,                  // the share of systems left equal (purity 0)
});
export const TUNESPACE_FORM=Object.freeze({moves:.6,between:.5,tenths:9});

const weighted=(list,random)=>{let draw=random()*list.reduce((sum,[,weight])=>sum+weight,0);for(const [value,weight] of list){draw-=weight;if(draw<=0)return value}return list.at(-1)[0]};
// A regime from anywhere in the space: {system, period, exactness, label}.
export function drawRegime(random=unitRandom){
  const exactness=random();
  if(random()<TUNING_SPACE.tritave)return {...equalTuning(13,12*Math.log2(3)),exactness,label:'13 steps of the tritave'};
  const divisions=weighted(TUNING_SPACE.divisions,random),equal=random()<TUNING_SPACE.equal;
  const purity=equal?0:TUNING_SPACE.purity[0]+random()*(TUNING_SPACE.purity[1]-TUNING_SPACE.purity[0]);
  return {system:equal?equalTuning(divisions).system:tuningSystem({divisions,purity}),period:12,exactness,label:equal?`${divisions}-EDO`:`${divisions} steps, purity ${purity.toFixed(2)}`};
}
// The regime t of the way from a to b: its system between theirs, its exactness between theirs.
export function interpolateRegime(a,b,t){
  const tuning=interpolateTuning(a,b,t);
  return {...tuning,exactness:(1-t)*a.exactness+t*b.exactness,label:t===0?a.label:t===1?b.label:`${t.toFixed(1)} from ${a.label} to ${b.label}`};
}

export class TuneSpaceClodbot extends TuneBot{
  constructor(send,audio,settings={}){
    super(send,audio,settings);
    this.settings={moves:TUNESPACE_FORM.moves,between:TUNESPACE_FORM.between,...settings};
    // It begins in the base's own regime: twelve steps drawn toward just intervals, its chords just.
    this.regime={system:tuningSystem({divisions:12,purity:3.5}),period:12,exactness:1,label:'12 steps, purity 3.50'};
    this.movedAtPhrase=null;this.regimes=[];
  }
  // Where a phrase begins: perhaps a new regime, a jump or a state between (once a phrase).
  moveRegime(clock){
    const phrase=clock.phrase??0;if(this.movedAtPhrase===phrase)return;this.movedAtPhrase=phrase;
    if(phrase===0||!(unitRandom()<this.settings.moves))return;
    const target=drawRegime(unitRandom);
    if(unitRandom()<this.settings.between){
      const t=(1+Math.floor(unitRandom()*TUNESPACE_FORM.tenths))/(TUNESPACE_FORM.tenths+1);
      this.regime=interpolateRegime(this.regime,target,t);this.remember(clock,'between',t);
    }else{this.regime=target;this.remember(clock,'jump',null)}
  }
  remember(clock,kind,t){
    const entry={tick:clock.tick,phrase:clock.phrase??0,move:kind,...(t!=null?{t}:{}),regime:this.regime.label,degrees:this.regime.system.length,
      period:+this.regime.period.toFixed(4),exactness:+this.regime.exactness.toFixed(3)};
    this.regimes.push(entry);if(this.regimes.length>64)this.regimes.shift();
    this.audio?.report?.('tunespace',entry);
  }
  onTick(tick,clock){
    if(clock?.phraseStart)this.moveRegime(clock);
    return super.onTick(tick,clock);
  }
  // The base's plan, in this regime: its system and period, and its chords the system's degrees blended toward the
  // base's just intonation by the regime's exactness.
  publishPlan(kind,payload,options){
    if(kind!=='tuning')return super.publishPlan(kind,payload,options);
    const {system,period,exactness}=this.regime,nominal=payload.nominalChords??[],just=payload.chords??[];
    const onSystem=nominal.map((chord,index)=>chord.map(pitch=>applyTuningSystem(pitch,{system,period,referencePitch:payload.chordReferencePitches?.[index]??payload.referencePitch})));
    const chords=onSystem.map((chord,index)=>chord.map((pitch,voice)=>pitch+((just[index]?.[voice]??pitch)-pitch)*exactness));
    return super.publishPlan(kind,{...payload,system:[...system],period,chords,parameters:{...payload.parameters,tuningSpace:{regime:this.regime.label,exactness}}},options);
  }
}

export const tunespaceClodbot=defineBot(
  {
    id:'tunespace_clodbot',name:'tunespace_clodbot',status:'native',source:'clodbot',
    category:'conductor',outputModes:[],pitchContract:'none',planningCapabilities:{harmony:true},
    specSettings:Object.freeze(['moves','between']),
    description:'mh_TuneBOT\'s fork whose tuning moves through the space of tunings: where a phrase begins it jumps to a regime drawn from anywhere (equal divisions from 5 to 53, drawn toward just intervals or not, the tritave\'s thirteen steps; its chords anywhere from the system\'s degrees to just intonation) or takes a state between the regime it is in and one it draws, every state between existing; it offers the tuning a phrase ahead, as the base does.',
  },
  (...args)=>new TuneSpaceClodbot(...args),
);
