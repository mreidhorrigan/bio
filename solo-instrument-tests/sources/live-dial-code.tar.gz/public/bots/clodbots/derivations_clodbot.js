// derivations_clodbot: a fork of _derivationsBOT that times its sampled lines in the transport's own beats (the mathematical audit's B04,
// ../lib/quarter-tempo.js). The port reads the transport's tempo as quarter notes; in 7/8 a line lasts as long as its bar allows, where
// the port's took half the time, and in 3/2 it no longer takes twice. The port's code is untouched: onTick is the port's
// own, given its clock with the tempo in quarter notes (it reads the tempo for nothing else). In a meter of quarters it
// plays exactly as _derivationsBOT. Made from the class it forks, which agents.js holds, by a function (no import cycle).
import {defineBot} from '../../framework/index.js';
import {quarterNoteClock} from '../lib/quarter-tempo.js';

export function derivationsClodbotClass(DerivationsBot){
  return class DerivationsClodbot extends DerivationsBot {
    onTick(tick,clock){return super.onTick(tick,quarterNoteClock(clock))}
  };
}
export function defineDerivationsClodbot(DerivationsBot){
  const DerivationsClodbot=derivationsClodbotClass(DerivationsBot);
  return defineBot({
      id:'derivations_clodbot',name:'derivations_clodbot',status:'native',source:'clodbot',forkOf:'derivations',category:'texture-noise',outputModes:['synth', 'samples'],sampleBank:'derivations',pitchContract:'none',
      description:"A fork of _derivationsBOT that times its sampled lines in the transport's own beats (the mathematical audit's B04): in 7/8 a line lasts as long as its bar allows, where the port's took half the time, and in 3/2 it no longer takes twice. In a meter of quarters it plays exactly as _derivationsBOT.",
    },(...args)=>new DerivationsClodbot(...args));
}
