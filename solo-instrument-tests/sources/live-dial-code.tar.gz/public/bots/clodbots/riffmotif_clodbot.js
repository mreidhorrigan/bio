// riffmotif_clodbot: a fork of riff_clodbot that develops the performer's figures. The user, of the riff in two
// play-along renders with one guitarist: the later one "demonstrates some new good melodic capabilities but isn't
// actually better for that particular guitar track than the previous approach because of how the previous algorithm
// developed short motifs that I think came from the guitar. Both approaches are potentially useful."
//
// Between the two, the rhythm clodbots came to hear the layers that repeat (HeardRhythm 'groove': a drum's groove under a
// part that changes every bar), and the riff's rhythm moved from the guitar's toward the drums': the share of its onset
// positions it had in common with the guitar's two bars before fell from 0.26 to 0.15 (Jaccard, 00_Funk2-108-Eb). This
// fork hears as the riff did before: everything together, the performer counting most (HeardRhythm 'whole'); and it is
// drawn more often (returns) to themes from the performer's own phrases, which motifprofiler_clodbot stores in
// mh_MemoryBOT (recallFrom 'performer'). riff_clodbot keeps the groove.
import {forkBot} from '../lib/fork.js';
import {riffClodbot,GroupedRiffClodbot} from './riff_clodbot.js';

export const riffmotifClodbot=forkBot(riffClodbot,GroupedRiffClodbot,{id:'riffmotif_clodbot',
  description:'A fork of riff_clodbot that develops the performer\'s figures: its rhythm from everything it hears together, the performer counting most, rather than from the layers that repeat, and its themes recalled from the performer\'s own phrases (stored by motifprofiler_clodbot), more often.',
  settings:{rhythmLayers:'whole',recallFrom:'performer',returns:.8}});
