import {shiftScoreTime,withScoreTime} from '../../shared/score-time.js';
// bowedstring_clodbot: a bowed string, a violin, viola, cello or contrabass (the world-instruments atlas's F08), playing a
// line with its bow planned (shared/performers/bowed-line.js, on bow.js): a new clodbot carrying the melody's principles
// to another instrument (the user, 28 September 2026: "we should use other instruments for testing ... which should
// hopefully help us generalize on some of the testing we've been doing with drums").
//   - Each phrase is planned at its downbeat, whole, from the harmony it hears (its pool, whatever the tuning) and the
//     meter's felt beats: phrases of its own motif in the sentence's shape (line.js), its bow distributed with each by
//     construction (bowed-line.js: slower where the bow is short of room, a retake in a silence, a slur divided, a bow
//     change inside a long note last).
//   - Its share of the band's attention (shared/attention.js) shapes it: given the solo, its density and loudness rise
//     with the solo's arc to a climax and its long notes take fioriture; behind another's solo it plays less and softer.
//   - It plays in the ensemble's feel and rubato (the performance layer; the clocks' spans), its runs in their own time.
//   - Seated in a section (settings.seat: 'vn1.3', of a section of settings.size; Musebots 3.0, a section is many playing
//     bots), it is that seat's player: its instrument the seat's, it plays its own part of each formation the
//     section's conductorbot says (bots/lib/modules/section-seat.js), and not phrases of its own.
// settings.instrument: violin (unless given, or a seat's), viola, cello or contrabass.
import {Agent,defineBot} from '../../framework/index.js';
import {secondsPerTick} from '../../shared/meter-tactus.js';
import {BOWED_INSTRUMENTS,BOWED_LINE,planPhrase} from '../../shared/performers/bowed-line.js';
import {instrumentNamed,namesBefore} from '../../shared/performers/instrument-ranges.js';
import {licenseReach,soloArc} from '../../shared/attention.js';
import {HearsAttention} from '../lib/modules/attention.js';
import {HearsPartRubato,playLagged} from '../lib/modules/part-rubato.js';
import {PlaysPickups} from '../lib/modules/line-pickups.js';
import {HearsLineMotifs,occurrenceRecords} from '../lib/modules/line-motifs.js';
import {strikeWith} from '../lib/note-language.js';
import {Closure} from '../lib/modules/closure.js';
import {GroupingChoice} from '../lib/modules/grouping-choice.js';
import {followHarmony,meterKey,phraseBeforeEnding,phraseOffset} from '../../shared/performers/line.js';
import {makingRoom,registerAway} from '../../shared/presentation.js';
import {PerformedTiming} from '../lib/modules/performed-timing.js';
import {createRandomStream} from '../../random-source.js';
import {SectionSeat,seatOf,sectionStream} from '../lib/modules/section-seat.js';
import {memoryReport} from '../lib/modules/memory-played.js';
import {declareMember} from '../../shared/conducting/group-routing.js';
import {bandPhraseBars,bandTempo} from '../../shared/opening-time.js';
import {PlaysItsPersonality} from '../lib/modules/personality.js';
import {playerVibrato,vibratoCurve,vibratoIntensity,AUTHORED_VIBRATO} from '../../shared/performers/vibrato.js';

const PHRASES_KEPT=16;
// The banks a bowed string's recordings may be in (scripts/download-string-samples.mjs, download-iowa-string-samples.mjs),
// in the order it takes them: the open ones first (VSCO 2 CE, CC0), then those kept to this Mac (the asset lock's
// conditional Iowa recordings). Each holds a preset an instrument, `<prefix>-<instrument>`.
export const STRING_BANKS=Object.freeze([Object.freeze({bank:'vscoStrings',prefix:'vsco'}),Object.freeze({bank:'iowaStrings',prefix:'iowa'})]);
// A section's seat first takes recordings played without vibrato, where this Mac has them (scripts/download-iowa-still-
// strings.mjs), and gives them its own (section-seat.js: shared/performers/vibrato.js), so that a section's players do
// not vibrate in lockstep; a player alone keeps the recordings with a player's vibrato in them.
export const SEAT_BANKS=Object.freeze([Object.freeze({bank:'iowaStillStrings',prefix:'iowa-still'}),...STRING_BANKS]);
// Its density and loudness among equals (a line, not a soloist), and how far the attention moves them.
export const BOWEDSTRING=Object.freeze({density:.35,loudness:.5,fioriture:.35});
// (A recipe made before the contrabass was renamed names it as it was: instrument-ranges.js NAMED_BEFORE.)
function checkedInstrument(value){
  if(value==null)return 'violin';
  const name=instrumentNamed(value);
  if(!Object.hasOwn(BOWED_INSTRUMENTS,name))throw new RangeError(`A bowed string is ${Object.keys(BOWED_INSTRUMENTS).join(', ')}`);
  return name;
}

export class BowedStringClodbot extends Agent {
  constructor(...args){
    super(...args);
    // Its seat, where a spec seats it in a section: its instrument is the seat's, and what it plays of stored material
    // said to MemoryBOT (memory-played.js).
    const seated=seatOf(args[2]??{});
    if(seated&&args[2]?.instrument!=null&&checkedInstrument(args[2].instrument)!==seated.instrument)throw new RangeError(`Seat ${seated.seat.id} is a ${seated.instrument}'s, not a ${args[2].instrument}'s`);
    this.instrument=seated?seated.instrument:checkedInstrument(args[2]?.instrument);
    this.harmonic=args[2]?.harmonic?{...args[2].harmonic}:null;
    this.seat=seated?new SectionSeat(seated,{audio:this.audio,pool:()=>this.notes,closing:clock=>this.closingAt?.(clock)??{phase:'none'},stream:sectionStream(this),streamOf:()=>this.stream??null,partTick:(at,clock)=>this.partTick?.(at,clock)??at,say:(address,args)=>this.broadcast(address,args),remember:memoryReport(this)}):null;
    // On samples, its instrument's recordings: the first bank that holds them; where none does here, its own voice, said.
    // A render waits for them (`loading`).
    if(this.audio?.mode==='samples'&&typeof this.audio.loadSampleBank==='function')this.loading=this.loadRecordings();
    this.phrase=null;this.phrases=[];
    // Its motif, kept and varied phrase by phrase, and its last phrase's apex, not taken again (line.js).
    this.motif=null;this.phraseIndex=0;this.previousApex=null;this.lead=null;
  }
  async loadRecordings(){
    const failed=[];
    // (Its recordings under its name, or under a name it had before in a bank made then: instrument-ranges.js
    // NAMED_BEFORE, the contrabass's "bass".)
    for(const {bank,prefix} of this.seat?SEAT_BANKS:STRING_BANKS)for(const name of [this.instrument,...namesBefore(this.instrument)]){
      const preset=`${prefix}-${name}`;
      try{
        await this.audio.loadSampleBank(bank,{preset});
        // (A bank without its preset gives its first: its recordings must be this instrument's.)
        if(!Object.values(this.audio.sampleMetadata??{}).some(entry=>instrumentNamed(entry?.instrument)===this.instrument)){failed.push(`${bank}: no ${this.instrument}'s recordings as ${name}`);continue}
        this.recordings={bank,preset};this.decide?.({samples:{bank,preset}});return this.recordings;
      }catch(error){failed.push(`${bank} ${preset}: ${String(error?.message??error)}`)}
    }
    this.recordings=null;this.decide?.({samples:{none:this.instrument,failed}});
    this.audio.report?.('substitution',{instrument:this.instrument,reason:`no ${this.instrument}'s recordings here: its own voice`,failed});
    return null;
  }
  // Its density, loudness and fioriture for a phrase beginning at `bar`, from its attention there.
  shaping(bar){
    // (Its own, where its personality says them: bots/lib/modules/personality.js.)
    const attention=this.attentionAt?.(bar),base=this.playing?.shaping??BOWEDSTRING;
    if(!attention||!Number.isFinite(attention.typicalDb))return {density:base.density,loudness:base.loudness,fioriture:0};
    const {reach,belowDb}=licenseReach({allowance:attention.allowanceDb,typicalDb:attention.typicalDb});
    if(attention.soloing){const arc=soloArc(attention.progress??.5)*reach;return {density:base.density+(1-base.density)*arc,loudness:base.loudness+(1-base.loudness)*arc,fioriture:base.fioriture+(1-base.fioriture)*arc}}
    const scale=10**(-belowDb/10);return {density:base.density*scale,loudness:base.loudness*Math.sqrt(scale),fioriture:0};
  }
  onMessage(message){
    super.onMessage?.(message);
    this.seat?.hear(message);
  }
  // The conductor's cutoff at the ensemble's stop (framework/agent.js cutOffAt): seated, its seat lets go what it holds,
  // its bow lifted or its breath ended, as at a cutoff it hears.
  onCutoff(clock,{atSeconds}={}){if(this.seat)this.seat.cutOff(Number.isFinite(atSeconds)?atSeconds:this.seat.clockSeconds)}
  onTick(tick,clock){
    super.onTick?.(tick,clock);
    // Seated, it plays its part of its section's formation, its group said to its room once (group-routing.js).
    if(this.seat){declareMember(this,this.seat.group);this.seat.tick(tick,clock);return}
    const meter=clock?.meter;
    if(!meter||!Number.isInteger(clock.bar))return;
    const phraseBars=Math.max(1,Number(meter.phraseBars)||bandPhraseBars()),perTick=secondsPerTick(clock);
    // A phrase planned whole at its downbeat, on its phrase grid: the form's where it is the band's
    // focus, half a phrase later where another's share of the band's attention is larger (it answers). A phrase ends at
    // the grid's next bar; a bar of another meter re-plans it from there. At its entry it never waits: its first phrase
    // runs from there to its grid's next bar (the user: "we need to fix the bug where some renders have silence at their
    // beginnings").
    // The piece's ending, where it is known (Closure: form_clodbot's closing, or the stop the ensemble committed to): its
    // last phrase ends with it, its cadence on the tonic held to the end, and nothing after. A phrase planned before the
    // ending was known that runs past it gives way, at a bar line, to a last phrase.
    // Room for another's entrance (shared/presentation.js, ManageBOT's): through an answering silence it rests, its phrase
    // ending before it; under a texture it thins, and under a register it keeps out of the author's. A phrase planned
    // before the presentation acting on its bars was said is planned again from the bar line.
    const ending=this.closingAt?.(clock)?.ending??null,endsAt=Number.isInteger(ending?.endsAt?.bar)?ending.endsAt.bar:null;
    if(endsAt!=null&&clock.bar>=endsAt||this.presentationOver?.(clock.bar,clock.bar+1)?.kind==='silence'){this.phrase=null;return}
    const offset=phraseOffset(this.attentionAt?.(clock.bar),phraseBars),current=this.phrase;
    const acting=current?makingRoom(this.presentationOver?.(clock.bar,current.endBar)).key:null;
    const due=clock.tickInBar===0&&(current?clock.bar>=current.endBar||clock.bar<current.startBar||current.meterKey!==meterKey(meter)||endsAt!=null&&current.endBar>endsAt&&!current.final||acting!=null&&acting!==current.room:true);
    if(due){
      const whole=phraseBeforeEnding(clock.bar,{phraseBars,offset,endsAt}),room=makingRoom(this.presentationOver?.(clock.bar,clock.bar+whole.bars));
      const span=phraseBeforeEnding(clock.bar,{phraseBars,offset,endsAt,breakAt:room.silentBar}),bars=span.bars;
      const random=(this.phraseRandom??=createRandomStream(`${this.randomStream?.seed??0}:bowedstring`)),draw=()=>random.next();
      const shaped=this.shaping(clock.bar);shaped.density*=room.density;
      // (Its register its personality's, where it has one: its instrument's widened toward its compass as it dares.)
      const own=this.playing?.register??BOWED_INSTRUMENTS[this.instrument].register,register=room.awayFrom?registerAway(own,room.awayFrom)??own:own;
      // Where the form marks the join its phrase ends at, a pickup into it, as the drummer's fill (line-pickups.js).
      const pickup=span.final?null:this.pickupAt?.(clock.bar+bars,clock,draw)??null;
      // The harmony it hears: the pool every bot keeps from the room's note pools and harmony plans (framework/agent.js).
      // Its motif made at its density among equals, BOWEDSTRING's, which its phrase then plays sparser or denser by its own
      // (its personality's, its share of the band's attention): made at its personality's, its phrase had played its motif
      // as made at every density but where its attention moved it.
      const planned=planPhrase({instrument:this.instrument,register,coreOnly:room.thin,pool:this.notes,meter,bpm:Number(clock.bpm)||bandTempo(),bars,...shaped,motif:this.motifToStart?.({meter,bpm:Number(clock.bpm)||bandTempo(),register})??this.motif,motifDensity:BOWEDSTRING.density,phraseIndex:this.phraseIndex,previousApex:this.previousApex,pickup,lead:this.lead,heard:this.motifsHeard?.()??[],
        climax:this.attentionAt?.(clock.bar)?.role==='climax',final:span.final?{tonic:ending?.tonic??null,...(band=>band?{motif:band}:{})(this.bandMotif?.({meter,bpm:Number(clock.bpm)||bandTempo(),pool:this.notes,register:register??null}))}:null,random:draw,...(this.playing?{choices:this.playing.choices}:{})});
      // (Its tone in the phrase, as its personality plays its instrument: personality.js phraseTone.)
      const tone=this.toneFor?.({phrase:this.phraseIndex,level:shaped.loudness})??{};
      if(planned.motif)this.motif=planned.motif;if(planned.apex!=null)this.previousApex=planned.apex;this.lead=planned.lead??null;this.phraseIndex++;
      // A motif chosen now, from a slate unlike the other lines' (line.js chooseMotif), said to them (line-motifs.js).
      if(planned.choice)this.sayMotif?.(planned.motif);
      this.phrase={startTick:tick,perTick,notes:planned.notes,status:planned.status,startBar:clock.bar,endBar:clock.bar+bars,meterKey:meterKey(meter),final:span.final,room:room.key,tone,
        // Each segment an occurrence of its motif, declared on its first note's strike (line-motifs.js).
        records:occurrenceRecords(planned.notes,{by:this.instanceId,phrase:`${clock.bar}`,motif:this.motif})};
      this.phrases.push({bar:clock.bar,bars,offset,pickup:pickup?.fill??null,status:planned.status,notes:planned.notes.length,...(planned.choice?{choice:planned.choice}:{}),...(room.key?{room:room.key}:{}),changes:planned.changes.map(r=>r.change),...shaped});
      if(this.phrases.length>PHRASES_KEPT)this.phrases.shift();
    }
    const phrase=this.phrase;
    if(!phrase?.notes?.length)return;
    // Each note as its tick comes round (the phrase's seconds counted in the ticks it was planned in). Notes under one
    // slur share a stroke, so each sounds into the next (legato); a change of bow leaves a breath of articulation.
    // Each at its part's own time where ManageBOT says one over the band's clock (part-rubato.js): a note that moved
    // earlier than the tick it was planned in sounds at once.
    // Ticks it was not given (paused, and started again) take their notes with them: a note is never played late.
    phrase.sounded??=new Set;
    if(Number.isFinite(phrase.lastTick)&&tick>phrase.lastTick+1)phrase.notes.forEach((note,index)=>{if(phrase.startTick+note.start/phrase.perTick<tick)phrase.sounded.add(index)});
    phrase.lastTick=tick;
    for(const [index,note] of phrase.notes.entries()){
      if(phrase.sounded.has(index))continue;
      const planned=phrase.startTick+note.start/phrase.perTick,at=Math.max(tick,this.partTick?.(planned,clock)??planned);
      if(at>=tick+1)continue;
      phrase.sounded.add(index);
      // Its runs keep their own subdivision: the feel does not swing them (performed-timing.js).
      const next=phrase.notes[index+1],slurred=Boolean(note.slur)&&next?.slur===note.slur;
      const seconds=slurred?(next.start-note.start)*1.08:(note.end-note.start)*.95;
      // Its instrument goes with each note, for a voice that models its body (7a's bowed string); a run keeps its own
      // subdivision, which the feel does not swing (performed-timing.js).
      // Its pitch in the harmony sounding now (the phrase was planned at its downbeat).
      const pitch=followHarmony(note.pitch,this.notes,this.playing?.register??BOWED_INSTRUMENTS[this.instrument].register);
      // (Its phrase's tone, as its synth sounds it on its instrument (audio.js instrumentLimits): a natural harmonic where
      // its strings sound one at the note, else a multiphonic measured near it -- neither slurred into -- its bow's pressure
      // and contact; and on a model, which plays a stroke's own finger, its vibrato within its range (vibrato.js's scope),
      // as intense as the note is long and near its phrase's middle.)
      const tone=phrase.tone??{},limits=this.audio.instrumentLimits?.(this.instrument)??null;
      const joined=slurred||Boolean(note.slur)&&phrase.notes[index-1]?.slur===note.slur;
      const natural=!this.harmonic&&!joined&&tone.harmonic&&limits?.harmonicNear?limits.harmonicNear(pitch,{partial:tone.harmonic.partial}):null;
      const harmonic=this.harmonic??(natural?{...tone.harmonic,...natural}:null);
      const multiphonic=!harmonic&&!joined&&tone.multiphonic&&limits?.multiphonicNear?limits.multiphonicNear(tone.multiphonic.choice,pitch,{compass:limits.range,pool:this.notes??[],dynamic:note.dynamic??'mf'}):null;
      const sounded=multiphonic?multiphonic.pitches[0]:pitch,scope=this.playing?.tone?.vibrato;
      const vibrato=limits?.engine&&scope&&!multiphonic&&!harmonic?(()=>{
        const player=this.vibratoPlayer??=playerVibrato(`${this.seedIdentity??this.instanceId??'solo'}`,this.instrument),last=phrase.notes.at(-1);
        const intensity=vibratoIntensity({position:last?.end>0?note.start/last.end:1/2,seconds,delay:player.delay});
        return {curve:Array.from(vibratoCurve(player,{seconds,pitch:sounded,velocity:note.velocity,note:`${phrase.startBar}:${index}`,expression:{intensity,scope}})),step:AUTHORED_VIBRATO.step};
      })():null;
      const strike=()=>this.audio.bowedString(sounded,seconds,note.velocity,(at-tick)*perTick,{instrument:this.instrument,...(harmonic?{harmonic}:{}),...(note.fioritura?{ownSubdivision:true}:{}),
        ...(multiphonic?{multiphonic}:{}),...(tone.contact?{contact:tone.contact}:{}),...(tone.pressure?{bowPressure:tone.pressure}:{}),...(vibrato?{stroke:{vibrato}}:{})});
      // (Its rubato and its ornament's warp how it is played, not written: audio.js lagged.)
      const record=phrase.records?.[index];
      const play=()=>{if(record)strikeWith(this,[{pitch:sounded,language:record}],strike);else strike()},lag=(at-planned)*perTick+(Number(note.lag)||0);
      withScoreTime(this.audio,shiftScoreTime(note.scoreTime,phrase.startTick,{axis:'ensemble'}),()=>playLagged(this.audio,lag,play));
      // (A note of the band's theme, MemoryBOT's, returned in its last phrase: said to it, line-motifs.js rememberPlayed.)
      this.rememberPlayed?.(note,{phrase:phrase.startBar,offset:(at-tick)*perTick+lag,seconds});
    }
    this.memoryPlayed?.report(tick);
  }
}
export function defineBowedStringClodbot(){
  // (Its personality learned of its instrument as it starts: personality.js.)
  const Bot=PerformedTiming(HearsAttention(PlaysPickups(HearsPartRubato(HearsLineMotifs(GroupingChoice(Closure(PlaysItsPersonality(BowedStringClodbot,{base:BOWED_LINE})),{role:'layer'}))))),{instrument:'melody'});
  return defineBot({
    id:'bowedstring_clodbot',orchestral:true,name:'bowedstring_clodbot',status:'native',source:'clodbot',category:'melody',midiChannel:9,outputModes:['synth','samples','midi'],
    pitchContract:'floating-mpe',specSettings:Object.freeze(['instrument','seat','size','section','players','arrival','harmonic','compass','personality','motifs','engine','rhythm']),
    // (Its compass an object where the engine that will play it says its own, by instrument -- a live dial's strings
    // (native/strings-model/soloist.mjs) -- its personality one of its levers' shares (personality.js) and the engine it
    // is linked to what that engine says it plays (instrument-facts.js `engine`).)
    specObjects:Object.freeze(['compass','personality','engine']),
    description:'A bowed string -- a violin, viola, cello or contrabass -- playing phrases of its own motif (the idea, its repetition, a climb to one apex, a held cadence, a rest), its bow distributed with each: slower where the bow is short of room, set back in a silence, a slur divided, a bow change inside a long note last; on its own phrase grid, answering a line with a larger share of the band\'s attention; given the solo it builds to a climax, fast and loud, its long notes taking fioriture, and behind another\'s it plays less and softer.',
  },(...args)=>new Bot(...args));
}
