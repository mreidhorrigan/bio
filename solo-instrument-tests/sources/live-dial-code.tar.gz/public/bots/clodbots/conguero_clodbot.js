// conguero_clodbot: a conga player on a conga and a tumba (the family atlas's F32, hand drums; research/family-atlas.md).
// Two hands, one keeping time and the other speaking, in a figure built as the tumbao is, by the meter's own structure
// (shared/performers/conga.js): the time-keeping hand rocking heel and tip, its heels on the two main beats; the other's
// slap on the backbeat and its open tones leading into the downbeat, which they leave unaccented. In 4/4 it plays the
// tumbao itself. As the band's complexity rises, an open tone leads into the middle beat too, and the tumba answers.
//
// Playable by construction: its pulse the finest two hands alternating can play at the tempo; each stroke by its own
// hand where that hand has recovered, else by the other (conga.js congaHands). The figure is chosen where a phrase
// begins, and it ends on the last bar's downbeat, a bass stroke on the tumba, with the band.
import {defineBot} from '../../framework/index.js';
import {Agent} from '../../framework/agent.js';
import {Closure} from '../lib/modules/closure.js';
import {PerformedTiming} from '../lib/modules/performed-timing.js';
import {GroupingChoice} from '../lib/modules/grouping-choice.js';
import {metricStrength} from '../../shared/rhythm-spaces.js';
import {onsetsPayload} from '../../shared/sounding-voices.js';
import {secondsPerTick} from '../../shared/meter-tactus.js';
import {strokeStride} from '../../shared/performers/shaker.js';
import {CONGA,congaFigure,congaHands} from '../../shared/performers/conga.js';
import {kitHasNotes} from '../../shared/performers/kit-instruments.js';
import {bandPhraseBars} from '../../shared/opening-time.js';
import {scoreTime,withScoreTime} from '../../shared/score-time.js';

export const CONGUERO_CLODBOT=Object.freeze({
  // Its drums' General MIDI notes (synths/drum-kit.js PERCUSSION: the conga's open, the tumba's), and the muted
  // conga's, which its heel and tip sound (percussion-expression.js MUTED_CONGA_NOTES).
  notes:Object.freeze({conga:63,tumba:64}),muted:62,
});

const clamp=(value,low,high)=>Math.max(low,Math.min(high,value));
// A meter's groups' heads, in its ticks.
const headsOf=meter=>{const heads=[];let at=0;for(const size of meter.groups?.length?meter.groups:[meter.numerator]){heads.push(at*meter.subdivision);at+=size}return heads};
const meterKey=meter=>`${meter.pulsesPerBar}:${(meter.groups??[]).join('+')}:${meter.subdivision}`;

export class CongueroClodbot extends Closure(Agent) {
  constructor(send,audio,settings={}){
    super(send,audio);
    this.settings={velocity:.6,...settings};
    this.bar=null;this.decisions=[];
  }
  // Whether its kit has its drums (kit-instruments.js; audio.js sampledKit): with none, it plays nothing and says so.
  hasDrums(){return kitHasNotes(this.audio?.sampledKit?.(),[...Object.values(CONGUERO_CLODBOT.notes),CONGUERO_CLODBOT.muted])}
  // A bar's strokes: its figure at its stroke pulse, with their hands; chosen where a phrase begins or the meter or the
  // tempo's pulse changes.
  plan(clock){
    if(!this.hasDrums()){if(!this.decisions.length)this.decisions.push({bar:clock.bar,silent:'its kit has no conga and tumba'});this.bar=null;return}
    const meter=clock.meter,seconds=secondsPerTick(clock),stride=strokeStride(seconds,Math.max(1,meter.subdivision||1));
    if(stride===null){this.bar=null;return}
    const key=`${meterKey(meter)}:${stride}`,phraseBars=meter.phraseBars||bandPhraseBars();
    if(this.bar&&this.bar.key===key&&clock.bar%phraseBars!==0)return;
    const complexity=clamp(this.character?.complexity??.5,0,1),strengths=metricStrength(meter);
    const pulses=Math.floor(meter.pulsesPerBar/stride),at=pulse=>pulse*stride;
    const figure=congaFigure(Array.from({length:pulses},(_,pulse)=>strengths[at(pulse)]??0),
      {heads:headsOf(meter).filter(tick=>tick%stride===0).map(tick=>tick/stride),complexity});
    const strokes=congaHands(figure,seconds*stride);
    if(this.bar?.key!==key||this.bar.complexity!==complexity){
      this.decisions.push({bar:clock.bar,stride,complexity,figure:strokes.map(stroke=>stroke?`${stroke.stroke}${stroke.drum==='tumba'?'(tumba)':''}:${stroke.hand}`:null)});
      if(this.decisions.length>128)this.decisions.shift();
    }
    this.bar={key,stride,complexity,strokes};
  }
  strike(clock,{stroke,drum},strength,ticks){
    const level=clamp(this.settings.velocity*(CONGA.levels[stroke]??1)*(.85+.3*strength),.03,1);
    withScoreTime(this.audio,scoreTime(clock.tick,ticks),()=>this.audio.drum?.('tom',level,{note:CONGUERO_CLODBOT.notes[drum],strike:{stroke,piece:'conga'}}));
    this.broadcast('onsets',[onsetsPayload({voice:this.instanceId??'conguero_clodbot',role:'drums',onsets:[{tick:clock.tick,strength:level,kind:'tom'}]})]);
  }
  onTick(tick,clock){
    if(!clock?.meter)return;
    const closing=this.closingAt(clock);
    if(closing.phase==='after')return;
    // Its ending (Closure): a bass stroke on the tumba on the last bar's downbeat, with the band, then nothing.
    if(closing.phase==='final'){
      if(clock.tickInBar===0&&this.hasDrums())this.strike(clock,{stroke:'bass',drum:'tumba'},1,closing.ticksLeft);
      return;
    }
    if(clock.tickInBar===0||!this.bar)this.plan(clock);
    if(!this.bar||clock.tickInBar%this.bar.stride!==0)return;
    const stroke=this.bar.strokes[clock.tickInBar/this.bar.stride];
    if(stroke)this.strike(clock,stroke,metricStrength(clock.meter)[clock.tickInBar]??0,Math.min(this.bar.stride,clock.meter.pulsesPerBar-clock.tickInBar));
  }
}

// Under a home (meterform_clodbot), it hears the home bars in a grouping of its own (bots/lib/modules/grouping-choice.js).
// Played in the ensemble's feel, where one is set (the performance layer: docs/PERFORMANCE_TIMING.md).
const GroupedConguero=PerformedTiming(GroupingChoice(CongueroClodbot,{role:'drums'}));
export const congueroClodbot=defineBot(
  {
    id:"conguero_clodbot",name:"conguero_clodbot",status:"native",source:"clodbot",
    category:"beat",midiChannel:10,outputModes:["synth","midi"],pitchContract:"fixed-percussion",
    description:
      "A conga player on a conga and a tumba, one hand rocking heel and tip to keep time and the other speaking: a slap on the backbeat and open tones leading into the downbeat, the figure built as the tumbao is by the meter's own structure (in 4/4, the tumbao itself), an open tone into the middle beat and the tumba's answer as the band's complexity rises; two hands that play only what they can.",
  },
  (...args)=>new GroupedConguero(...args),
);
