// xdrum_clodbot: a fork of ae_xDrumBOT that plays compound meters in their own triplet eighths, says when it strikes, and
// plays each stroke as a drummer does (the patterns: ../lib/compound-meter.js; the strokes: ../lib/modules/drummer.js).
// Made from the class it forks, which agents.js holds, by a function, so that this file imports nothing from agents.js
// (no import cycle).
//
// A bar longer than one of 4/4 (sixteen sixteenths) it plays group by group, the pattern in sixteenths from each group's
// start, where ae_xDrumBOT stretched its sixteen steps over the whole bar (playByGroups).
//
// Which drum sounds on which step is the ported bot's. How each is struck is the Drummer module's: ae_xDrumBOT strikes
// every hit at one accent (its density's), and ten drummers on the Groove MIDI Dataset do not -- accents by the beat,
// ghost notes, rimshots on hard backbeats, the hat's shank and tip, now and then an open hat closed by the next stroke.
// The cadence's fill moves out from the head's centre towards its rim as it rises, and ends on a rimshot; the ending's
// cymbal is a crash left to ring. With settings {expression: false} it strikes as ae_xDrumBOT does.
//
// And it marks the form's joins as a band's drummer does (../lib/modules/form-marks.js): a fill up the snare into more
// tension or a return, landed on a crash; a fill down the toms into less; each fitted to what a mixbot announces it will
// do there (a cut takes the fill's beat). With settings {formMarks: false} it plays through them, as ae_xDrumBOT does.
//
// Its fills are made playable, not checked (the user, 28 September 2026: "Checks should be used only for system
// development, but the system must not require extensive checking for its actually deployed versions ... We are not
// building a brute-force system"; ../../shared/performers/drummer.js "By construction"): each is chosen from what its
// hands can play where its contacts will sound, worked out from its limits, and the performer contract's planner holds
// them in the tests. The feel places a fill whole, as it places its first stroke, and swings it within only where its
// hands can play it swung.
//
// Played live, a fill is planned in time (../../shared/performers/live.js, the rudiments report's T38): the plain fill
// first (singles, as many as the window holds at its hands' pace), and the fill it would rather play only if the plan is
// made before the deadline. A fill under way is committed: what it has struck stands, and it plays on to its end though
// the join it led to has changed.
//
// And a dense fill is played lighter, as a drummer fitting it into the mix does (../../shared/performers/fill-loudness.js):
// many strokes in a short time sum to a louder texture, and human drummers give part of that back (measured on the Groove
// MIDI Dataset's fills), 1.07 dB of every stroke for each doubling of the strokes in the fill's busiest 400 ms against
// the groove's on the snare and toms, with the fill's shape kept. With settings {fillLoudness: false} each stroke is
// played at its place on the fill's ramp, however many there are.
//
// And each fill is a figure a drummer would play (../../shared/performers/fill-figures.js), drawn as human drummers'
// fills were measured on the Groove MIDI Dataset: at a fast rate some of its slots left out, any of them (the beat's
// head and the pickup too); in one of the rudiments its hands can play (singles, hand to hand, a counted roll, a
// paradiddle, doubles); its accents the rudiment's own or its groups' heads; and its loudness moving within it, rising,
// falling or level, with taps and ghosts under its accents. With settings {fillFigures: false} every slot is struck,
// in singles or a counted roll, on the fill's ramp.
//
// And its fills are continuous with its groove (the user, 28 September 2026: "longer serieses of fills that, in certain
// circumstances, bleed into things around them, so there is a continuity between fill and groove"; FILL_FIGURES.md
// "Continuity"): the groove bends into a coming fill as the Groove MIDI drummers' did, soft snare strokes rising over
// the two felt beats before it; a fill grouped against the meter carries its grouping into the groove after its landing,
// the hat accenting it for a bar; and a fill may develop an earlier one's grouping and cells, so its fills are a series.
// With settings {fillContinuity: false} none of the three.
//
// And each figure is shaped by the music around it (fill-figures.js context): the pattern it hears the band play in the
// fill's beat (the others' onsets: rhythm-spaces.js), catching the band's accents and leaving room where it is busy;
// the join's move in intensity; its own last figures, not played again the same way; and its loudness its groove's (a
// figure's strokes as loud on average as the groove's snare, as the drummers' fills were: FILL_LOUDNESS.md), its course
// and accents about that.
import {defineBot} from '../../framework/index.js';
import {GroupingChoice} from '../lib/modules/grouping-choice.js';
import {feltBeats,secondsPerTick,tactusOf} from '../../shared/meter-tactus.js';
import {STATUS} from '../../shared/performers/contract.js';
import {DRUMMER,drummer,gestureActions,handsAllow,lateWithin,limbFree,motionSpacing,phraseActions} from '../../shared/performers/drummer.js';
import {ContactLedger,GESTURES,dueAt,gesture,scoredGesture} from '../../shared/performers/gestures.js';
import {scoreTime,withScoreTime} from '../../shared/score-time.js';
import {dividedInterval,patternIntervals} from '../../shared/performers/rhythm-cell.js';
import {KIT,checkOrchestration,kitState,navigation,transition} from '../../shared/performers/kit.js';
import {planDeadlineMs,planLive} from '../../shared/performers/live.js';
import {onsetsPayload} from '../../shared/sounding-voices.js';
import {chooseRotation,countOf,finestPlayable,gridBetween,gridOf,gridWeights,groupStartsOf,interlock,layerTicks,meterGrids,mostEven,rotationsOf,slotWeights,syncopate,syncopations} from '../../shared/euclidean.js';
import {POSITION_REFERENCE} from '../../shared/percussion-expression.js';
import {compoundDrumPattern} from '../lib/compound-meter.js';
import {Closure} from '../lib/modules/closure.js';
import {Drummer} from '../lib/modules/drummer.js';
import {FormMarks,FORM_MARKS,fillCount} from '../lib/modules/form-marks.js';
import {tunedStrike} from '../lib/modules/drum-tuning.js';
import {PerformedTiming} from '../lib/modules/performed-timing.js';
import {HearsAttention} from '../lib/modules/attention.js';
import {claimOf,license} from '../../shared/attention.js';
import {revoicedHits} from '../../shared/performance-timing.js';
import {FILL_LOUDNESS,fillOffsetDb,softerVelocity,velocityDb} from '../../shared/performers/fill-loudness.js';
import {PlannedLevels,plannedDb,velocityAtDb} from '../../shared/planned-dynamics.js';
import {FILL_FIGURES,doublesMotion,figureEnding,figureSignature,fillDoubles,fillDynamics,fillFigure,fillGraces,fillKicks,fillRests,fillStickings,leastStrokes,louderStrokes} from '../../shared/performers/fill-figures.js';
import {FILL_PHRASE,choosePhrase,phraseContacts,phraseCount} from '../../shared/performers/fill-phrase.js';
import {Rational,gcd} from '../../transcript/rational.js';
import {FIGURE_BLEND,SOLO_COURSE,blendLevel,checkedFillness,fillnessAt,metricalWeight,rankThresholds,soloArc,soloCourse,strokeThreshold} from '../../shared/performers/figure-blend.js';
import {HeardRhythm,hearRhythmMessage,metricalLevels} from '../../shared/rhythm-spaces.js';
import {figurePayload,oneTone,oneToneFigure} from '../../shared/performers/figuration.js';
import {createRandomStream,randomAt} from '../../random-source.js';
// How its ending lands (finalHit), drawn once a piece (ours): the last downbeat's weight; below `cymbal` of its colour
// no cymbal (below half of it the kick alone, above it with the snare), from `crash` a crash, between a ride; each
// cymbal ringing from the least to the most of `ring` (s) as its colour rises.
export const XDRUM_ENDING=Object.freeze({weight:Object.freeze([.55,1]),cymbal:.3,crash:.6,ring:Object.freeze([.4,2.4])});
import {bandMeter} from '../../shared/opening-time.js';

// The Euclidean groove's measured shares (settings.groove 'euclidean': euclideanBar): onsets per felt beat on the beats'
// own layer (the downbeat's and the beats') of the kick and the snare, and the share of the kick's bars syncopated, the
// Groove MIDI drummers' (research/derived/euclidean-grooves-gmd-train-2026-11-04.json: lines.*.onsetsPerBeat, bar plus
// beat; lines.kick.syncopatedBars, its commonest 'sixteenths 3x2 +2', the tresillo's 3+3+2 in half a bar of four).
export const XDRUM_GROOVE=Object.freeze({kickPerBeat:.43,snarePerBeat:.3857,kickSyncopated:.1011});
// A bar of the Euclidean groove (docs/RHYTHM_TO_FORM.md; research/PANMETER_RHYTHM_CORE_PLAN.md, "The Euclidean basis",
// step 3), its lines on the bar's grids (shared/euclidean.js), each choice drawn from `random` (the bar's own stream):
// - the kick on the felt beats' grid, as many as the drummers' share of beats at this density, at the rotation that
//   strikes the downbeat and fits the meter's weights best -- or, where the bar is one felt beat and leaves the snare no
//   place, on the first grid below them with room for both;
// - in the drummers' share of bars, where the felt beats are even, the kick syncopated within one event of a layer
//   above them (the bar, its halves, its groups) [3, 5]: a grid finer than the beats a foot plays at the tempo, grouped
//   at a meter one from the beat's events on it (3 against 2 or 4: the hemiola generalized), repeated, then resolved by
//   the beat's own meter to that event's end, the kick's other strokes kept: drawn grid, event and syncopation in turn
//   from those the bar affords (the drummers' 3+3 +2 among them);
// - the snare beside it, its count the drummers' share, at a rotation whose aggregate with the kick's beats is most
//   even, of those the one striking with the kick as played least and, where it must, on the weakest places (the earlier
//   on a tie): on four beats, the backbeat;
// - the hats the isochronous series of a grid drawn between the felt beats' and the finest a hand plays alone at the
//   tempo (a stroke's lift and return: DRUMMER), as many of its slots as the density asks, evenly.
// -> {kick, snare, hats}: ticks in the bar; step: the hats' slot, a stroke's score duration.
export function euclideanBar(meter,{secondsPerTick:perTick,density=.5,random}){
  const level=Math.max(0,Math.min(1,Number.isFinite(density)?density:.5)),scale=.5+level;
  const grids=meterGrids(meter),weights=gridWeights(meter,grids);
  let beat=gridOf(grids,feltBeats(meter,{secondsPerTick:perTick}).map(felt=>felt.start));
  if(beat<0)beat=Math.max(0,grids.findIndex(grid=>grid.name==='units'));
  const beats=grids[beat],felt=beats.starts.length,room=felt>1?beat:grids.findIndex((grid,k)=>k>beat&&grid.starts.length>1);
  const lines=grids[room<0?beat:room],n=lines.starts.length,fits=slotWeights(lines,weights),perBar=share=>countOf(share*scale*felt/n,n,{least:1});
  const finest=finestPlayable(grids,{secondsPerTick:perTick,spacingSeconds:DRUMMER.prepareSeconds+DRUMMER.recoverSeconds,from:beat});
  const hatGrid=grids[gridBetween(beat,finest,random())],hats=layerTicks({grid:hatGrid,k:countOf(2*level,hatGrid.starts.length,{least:1})});
  const kickCount=perBar(XDRUM_GROOVE.kickPerBeat),kickSlots=chooseRotation(rotationsOf(kickCount,n,fits,{downbeat:true}),0).onsets;
  let kick=kickSlots.map(slot=>lines.starts[slot]);
  const even=grid=>grid.sizes.every(size=>size===grid.sizes[0]),pick=list=>list[Math.min(list.length-1,Math.floor(random()*list.length))];
  if(even(beats)&&random()<XDRUM_GROOVE.kickSyncopated*scale){
    const spans=[];
    for(let layer=beat+1;layer<=finest;layer++){
      const grid=grids[layer],step=grid.sizes[0],perBeat=beats.sizes[0]/step;
      if(!even(grid)||!Number.isInteger(perBeat)||perBeat<2)continue;
      const events=[];
      for(let above=0;above<beat;above++)grids[above].starts.forEach((at,slot)=>{
        const size=grids[above].sizes[slot]/step,shapes=Number.isInteger(size)?syncopations(size,perBeat).filter(shape=>Math.abs(shape.meter-perBeat)===1):[];
        if(shapes.length)events.push({at,size,shapes});
      });
      if(events.length)spans.push({step,perBeat,events});
    }
    if(spans.length){
      const {step,perBeat,events}=pick(spans),{at,size,shapes}=pick(events),end=at+size*step;
      const struck=groupStartsOf(syncopate(size,{...pick(shapes),resolution:perBeat}).groups).map(slot=>at+slot*step);
      kick=[...kick.filter(tick=>tick<at||tick>=end),...struck].sort((a,b)=>a-b);
    }
  }
  const snareCount=Math.min(n-kickCount,perBar(XDRUM_GROOVE.snarePerBeat));
  const kicked=new Set(kick),heaviest=Math.max(...fits)+1,clash=option=>option.onsets.filter(slot=>kicked.has(lines.starts[slot])).reduce((sum,slot)=>sum+1+fits[slot]/heaviest,0);
  const snare=snareCount?[...mostEven(interlock([kickSlots],snareCount,n))].sort((a,b)=>clash(a)-clash(b)||a.rotation-b.rotation)[0].onsets.map(slot=>lines.starts[slot]):[];
  return Object.freeze({kick:Object.freeze(kick),snare:Object.freeze(snare),hats,step:Math.min(...hatGrid.sizes)});
}
// ae_xDrumBOT's pattern: sixteen steps, one bar of 4/4 in sixteenths, and its drums in the order it plays them.
const PATTERN_STEPS=16,PATTERN_DRUMS=Object.freeze([['kick','kick'],['snare','snare'],['closedHat','hihat']]);
// The drum a hit's kind strikes, for tuning it (drum-tuning.js).
const KIND_PIECES=Object.freeze({kick:'kick',softKick:'kick',snare:'snare'});

// Ours: the fill's path from the centre out, as r/a.
const FILL_POSITION=Object.freeze([POSITION_REFERENCE,.7]);
// An accent as a velocity, as audio.js houseDrum makes one; and the General MIDI crash, for a voice that plays it as a
// ride's note.
const HOUSE_VELOCITY=Object.freeze({floor:.3,span:.65}),CRASH_NOTE=49;
// Between groove and fill (figure-blend.js): the feet's strokes do not leave by fillness; each other kind has its own
// draw for its threshold. A stroke at a level under 1 sounds as much softer (fill-loudness.js softerVelocity), under the
// house drum's softest if need be (an accent under 0, down to no velocity).
// A solo's arc: how many bars one runs without a known end, and the appetites its climax opens (ours: tuplets all the way,
// nesting and grouping against the meter to FILL_PHRASE's extremes' 0.6).
const SOLO_ARC_BARS=32,SOLO_APPETITE=Object.freeze({dissonance:.6,tuplets:1,nesting:.6});
const BLEND_FEET=new Set(['kick','softKick']),BLEND_KINDS=Object.freeze(['kick','softKick','snare','closedHat','openHat','hihat','ride','crash','tom']);
const accentAtLevel=(accent,level)=>(softerVelocity(HOUSE_VELOCITY.floor+HOUSE_VELOCITY.span*accent,20*Math.log10(level))-HOUSE_VELOCITY.floor)/HOUSE_VELOCITY.span;
// A stroke moved by the conductor's planned dynamics where it plays seated in no section (planned-dynamics.js: its
// level for the section of the form, `db` from the kit's own loudness at its middle), on its drums' velocity curve.
const accentAtPlanned=(accent,db)=>(velocityAtDb(HOUSE_VELOCITY.floor+HOUSE_VELOCITY.span*accent,db,FILL_LOUDNESS)-HOUSE_VELOCITY.floor)/HOUSE_VELOCITY.span;
// The fills it remembers, for its log and the tests.
const FILLS_KEPT=64;
// How it hears the band around a fill (rhythm-spaces.js HeardRhythm): over its last four bars, and a slot of a figure
// hears the band's tick it lies within a quarter of a tick of (ours).
const FILL_HEARING=Object.freeze({bars:4,nearTicks:.25});
// Its fills' continuity with its groove (ours, until listening says; the lead-in's rate and level are the drummers',
// fill-figures.js leadIn): how often a fill grouped against the meter carries its grouping into the next bar's hat, the
// hat's accent there at a group's head and elsewhere, and how often a fill develops an earlier one's grouping and cells.
const FILL_CONTINUITY=Object.freeze({tail:.5,tailHead:1.3,tailOther:.75,series:.35,kept:16});
// Its flams and drags (fill-figures.js fillGraces): how many of a figure's strokes of its kind a grace its hands cannot
// play where it was drawn is tried at, nearest first (ours: a bound on the work, a drummer placing a flam nearby).
const FILL_GRACES=Object.freeze({tries:8});
// Its answer to a hold (clock-hold.js; ours, until listening says): a pickup of this many strokes into the re-entry, a
// pulse apart and rising (the Groove MIDI drummers' busy beat before a fill held two: fill-figures.js leadIn), at these
// accents.
const HOLD_ANSWER=Object.freeze({pickupAccents:Object.freeze([.55,.8])});
// The extremes a spec names (settings.fillExtremes: {dissonance, tuplets, nesting, mostBars}), each in place of
// fill-phrase.js's: an appetite from 0 to 1, the most bars a whole number from 1. Anything else, fill-phrase.js's own.
const extremesNamed=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
export function extremesOf(value){
  if(!extremesNamed(value))return FILL_PHRASE.extremes;
  const appetite=name=>Number.isFinite(value[name])?Math.max(0,Math.min(1,value[name])):FILL_PHRASE.extremes[name];
  return Object.freeze({dissonance:appetite('dissonance'),tuplets:appetite('tuplets'),nesting:appetite('nesting'),
    mostBars:Number.isSafeInteger(value.mostBars)&&value.mostBars>=1?value.mostBars:FILL_PHRASE.extremes.mostBars});
}
// The kit its falling fills cross (shared/performers/kit.js): the voice's six toms, high to low (FORM_MARKS.toms), laid
// along the kit's arc from over the kick to the floor. Authored, as KIT's own layout is (cm from the throne).
const TOM_PLACES=Object.freeze([[-18,55],[-4,58],[10,58],[24,55],[40,32],[48,20]]);
const TOM_KIT=Object.freeze({...KIT,targets:Object.freeze({...KIT.targets,
  ...Object.fromEntries(FORM_MARKS.toms.map((note,i)=>[`tom${note}`,Object.freeze({piece:'tom',note,place:TOM_PLACES[i],limbs:['RH','LH']})]))})});
// The rubato report's stage C for a fill (§7.7, §16.5 "physical integration"; RHY-001's fourth finding), now the
// reference in the tests and no longer played through (the fills are made playable where they sound: fillStroke): the
// plan it chose, rechecked where its contacts will sound (`plays(plan, ownSubdivision)`: after the feel's swing and
// placement, a lean and its hands' travel, or with the swing left out). Played so where it can be. Where only the swing
// makes it unplayable, it plays in its own subdivision and says so; where even that cannot be played, the plain fill
// (`plain()`), swung or not as it can be; where nothing can be, none, and the pattern plays on. {plan (null for none),
// reason}, the plan carrying `ownSubdivision` (and `feelRefused`) where the recheck decided them.
export function recheckFill({chosen,plays,ownSubdivisionOf,plain}){
  const own=ownSubdivisionOf(chosen);
  if(plays(chosen,own))return {plan:chosen,reason:null};
  if(!own&&plays(chosen,true))return {plan:{...chosen,ownSubdivision:true,feelRefused:'swung, its hands could not play it: in its own subdivision'},reason:null};
  const fallback=plain(),fallbackOwn=ownSubdivisionOf(fallback),played=plays(fallback,fallbackOwn)?fallbackOwn:plays(fallback,true)?true:null;
  if(played===null)return {plan:null,reason:'no fill its hands can play where the feel places it: the pattern plays on'};
  return {plan:{...fallback,ownSubdivision:played},reason:'its hands could not play the fill it chose where the feel places it'};
}
// A fill made playable (drummer.js "By construction"): live.js planLive's `validate` for a drummer whose fills are
// never checked while they are played. The planner holds them in the tests.
const MADE_PLAYABLE=()=>({status:STATUS.witness});
// A fill's strokes' actions, in order (its graces' are their strokes'), and each contact's stroke action (a grace's, the
// action of the stroke it comes before): a grace is struck on its stroke's drum.
const strokeActions=played=>[...new Set(played.contacts.filter(contact=>!contact.of).map(contact=>contact.action))];
function strokeActionOf(played){
  const byId=new Map(played.contacts.map(contact=>[contact.id,contact]));
  return contact=>contact.role==='grace'?byId.get(contact.of)?.action??contact.action:contact.action;
}
// A phrase's strokes with graces before some (fill-figures.js fillGraces: a flam's one, a drag's two), each the other
// hand's, one action (a drag's two are one hand's bounce), `seconds` apart and before its stroke.
function withGraces(contacts,graces){
  const byIndex=new Map(graces.map(grace=>[grace.index,grace])),out=[];
  contacts.forEach((contact,k)=>{
    const grace=byIndex.get(k);
    if(grace)for(let g=grace.count;g>=1;g--)out.push({id:`${contact.id}:grace-${grace.count-g}`,slot:null,at:contact.at,before:grace.seconds*g,
      hand:contact.hand==='R'?'L':'R',action:`${contact.action}:grace`,role:'grace',of:contact.id});
    out.push(contact);
  });
  return out;
}
// A falling fill's toms: its pairs spread over as many of the toms, from the highest, as its hands can travel between at
// the tempo (§5.4: a simplification the drummer chooses, where the whole spread cannot be played). Each action (a
// rebound pair, a single) on one tom. The toms, high to low.
export function fillToms(played,{secondsPerTick:perTick,toms=FORM_MARKS.toms,hands=DRUMMER.hands,kit=TOM_KIT}={}){
  const actions=strokeActions(played),strokeOf=strokeActionOf(played);
  for(let k=Math.min(toms.length,actions.length);k>1;k--){
    const register=toms.slice(0,k),noteOf=contact=>register[Math.round(actions.indexOf(strokeOf(contact))*(k-1)/Math.max(1,actions.length-1))];
    const contacts=played.contacts.map(contact=>({id:contact.id,action:contact.action,limb:hands[contact.hand],
      at:contact.at.toNumber()*perTick-(contact.before??0),state:kitState({target:`tom${noteOf(contact)}`},{kit}).state}));
    if(checkOrchestration(contacts,{kit}).status===STATUS.witness)return register;
  }
  return toms.slice(0,1);
}
// What a fill's moves about the kit do to its strokes (kit.js navigation): each contact's lift, height, excitation and
// lateness, by id. Down the toms over the fill's register (fillToms), each action on its tom; up the snare, its strike
// moving out from the centre to the edge, a rimshot last (as it is played). The user, 27 September 2026: "there should
// be more difference of hit strength within the fill (as well, perhaps, as minor differences of timing at that speed)
// resulting from how the drummer has to navigate the kit". Each contact where it will sound (`secondsOf`, as
// gestureActions reads it: swung, where the fill swings), else at its nominal time. A double on another drum
// (doublesOf) lands as its stroke does, and is weighed only where its hand's next stroke needs the time.
export function fillNavigation(played,{fill,toms,secondsPerTick:perTick,rim=true,hands=DRUMMER.hands,kit=TOM_KIT,secondsOf=null}={}){
  const own=played.contacts.filter(contact=>contact.role!=='double');
  const actions=strokeActions(played),strokeOf=strokeActionOf(played),n=own.length;
  const contacts=own.map((contact,k)=>{
    // Where on the snare: by its action's place in the fill, so a rebound pair is struck on one spot (the kit's rule),
    // and a grace where its stroke is.
    const progress=actions.length>1?actions.indexOf(strokeOf(contact))/(actions.length-1):1;
    const wanted=fill==='down'&&toms?.length?{target:`tom${toms[Math.round(actions.indexOf(strokeOf(contact))*(toms.length-1)/Math.max(1,actions.length-1))]}`}
      :{target:'snare',zone:progress<1/3?'centre':progress<2/3?'off':'edge',stroke:rim&&k===n-1?'rim':'head'};
    return {id:contact.id,action:contact.action,limb:hands[contact.hand],at:secondsOf?secondsOf(contact):contact.at.toNumber()*perTick-(contact.before??0),state:kitState(wanted,{kit}).state};
  });
  // A hand moves its spot on the drum only where it has the time to (the kit's zone change); else it stays where it was.
  const last=new Map;
  for(const contact of [...contacts].sort((a,b)=>a.at-b.at)){
    const before=last.get(contact.limb);last.set(contact.limb,contact);
    if(!before||before.state.target!==contact.state.target||before.state.zone===contact.state.zone||before.action===contact.action)continue;
    const need=transition(before.state,contact.state,{limb:contact.limb,kit});
    if(Number.isFinite(need.seconds)&&contact.at-before.at<need.seconds-1e-9)contact.state=kitState({...contact.state,zone:before.state.zone},{kit}).state;
  }
  const moved=navigation(contacts,{kit});
  // Checked again where it will sound (T34): each contact a little late where its move asks it, the fill's transitions
  // still made. If lateness would crowd the next stroke, it lands on time instead.
  const late=new Map(moved.map(entry=>[entry.id,entry.lateSeconds]));
  if(checkOrchestration(contacts.map(contact=>({...contact,at:contact.at+late.get(contact.id)})),{kit}).status===STATUS.violates)
    return new Map(moved.map(entry=>[entry.id,{...entry,lateSeconds:0}]));
  // And never later than its hands allow (drummer.js lateWithin): a stroke landing late leaves the next on its hand (and
  // on the hand of a grace or a double landing with it) the time that one needs, so the fill stays playable as its hands
  // travel. Each stroke's is what its graces and doubles land by.
  const kept=lateWithin(played,late,{secondsPerTick:perTick,hands,secondsOf});
  return new Map(moved.map(entry=>[entry.id,kept.has(entry.id)?{...entry,lateSeconds:+kept.get(entry.id).toFixed(9)}:entry]));
}

// A phrase's contacts in their cells' stickings (fill-phrase.js phraseContacts; each cell's {sticking, hands, accents}
// from fill-figures.js fillStickings): a cell's strokes in its hands, its rebound pairs one action; a cell's nested notes,
// and a cell with no sticking of its own, in alternating singles; each cell led by the hand after the one before it
// ended (odd alternating singles hand their lead on: the rudiments report §3.2), mirrored where it would begin on it.
// Where that hand is not free yet (`fits(contacts)`: whether its hands allow the join, the last few strokes before
// the cell and the cell, drummer.js handsAllow), a cell in its own sticking is led by the other. Each cell's first
// stroke its head; a rudiment's own accents `accented`.
export function phraseSticking(contacts,cells,join,{fits=null}={}){
  const out=[],mirror=hand=>hand==='R'?'L':'R';let last=null;
  const byCell=Map.groupBy(contacts,contact=>contact.cell);
  // The strokes before a cell its hands still weigh at its join: the last eight, and the whole of an action begun there.
  const tail=()=>{let from=Math.max(0,out.length-8);while(from>0&&out[from-1].action===out[from].action)from--;return out.slice(from)};
  for(const [index,list] of [...byCell].sort((a,b)=>a[0]-b[0])){
    const cell=cells[index],struck=[...Array(cell.n).keys()].filter(k=>!(cell.rests??[]).includes(k)),hands=cell.hands;
    // Its own hands where every stroke is at the top level (no nesting); else singles.
    const plain=hands&&hands.length===struck.length&&list.every(contact=>contact.depth===0);
    const placed=flip=>list.map((contact,k)=>{
      const lead=last===null?'R':mirror(last);
      const hand=plain?(flip?mirror(hands[k].hand):hands[k].hand):k%2?mirror(lead):lead,action=plain?`c${index}:${hands[k].action}`:`c${index}:s${k}`;
      return {id:`fill:${join}:${out.length+k}`,slot:out.length+k,at:contact.at,duration:contact.duration,hand,action:`fill:${join}:${action}`,role:'principal',head:k===0,accented:plain&&(cell.accents??[]).includes(k),cell:index};
    });
    const ruled=plain&&last!==null&&hands[0].hand===last;
    let cellContacts=placed(ruled);
    if(fits&&plain&&last!==null&&!fits([...tail(),...cellContacts])){const other=placed(!ruled);if(fits([...tail(),...other]))cellContacts=other}
    out.push(...cellContacts);last=cellContacts.at(-1).hand;
  }
  return out.sort((a,b)=>a.at.cmp(b.at));
}

// A phrase's contacts in one motion throughout, where its cells' stickings joined are not playable at its tempo (by
// construction: xdrum_clodbot phraseFill): alternating singles from the right hand, or the doubles' motion, each two
// contacts in turn one hand's rebound pair. Each cell's first stroke its head; its rudiments' own accents given up.
export function phraseMotion(contacts,motion,join){
  let cell=null;
  return contacts.map((contact,k)=>{
    const head=contact.cell!==cell,index=motion==='doubles'?Math.floor(k/2):k;cell=contact.cell;
    return {id:`fill:${join}:${k}`,slot:k,at:contact.at,duration:contact.duration,hand:index%2?'L':'R',action:`fill:${join}:${motion==='doubles'?`pair-${index}`:`stroke-${k}`}`,
      role:'principal',head,accented:false,cell:contact.cell};
  });
}

export function xdrumClodbotClass(XDrumBot){
  class XDrumClodbot extends FormMarks(Drummer(Closure(XDrumBot))) {
    // It says when it strikes (/broadcast/onsets, as the drums), for the bots that listen to rhythm: each hit announced as
    // it is played, by wrapping its own audio's drum, and voiced there (voiceHit) unless the caller gave its stroke.
    // Wrapped once per audio; a bot made again on the same audio takes the wrapper over.
    constructor(send,audio,settings={}){
      super(send,audio,settings);
      // Its drums tuned to the harmony (drum-tuning.js): settings.tuneDrums true (the default), false, or the pieces to tune
      // (['kick']); settings.tuneKick false leaves the kick as it was recorded.
      this.expression=settings?.expression!==false;this.tuneKick=settings?.tuneKick!==false;this.tuneDrums=settings?.tuneDrums??true;
      // Its fills' strokes struck as its hands can move about the kit (fillNavigation): settings.navigation false plays each
      // at its place on the fill's dynamic ramp, on time.
      this.navigate=settings?.navigation!==false;
      this.formMarks=settings?.formMarks!==false;
      // Its groove (settings.groove): 'port', ae_xDrumBOT's steps as this fork plays them (the default), or 'euclidean',
      // each bar's lines Euclidean on its grids (euclideanBar; the port's archived at research/drum-algorithm-archive/
      // 2026-11-04-xdrum-groove/).
      this.groove=settings?.groove==='euclidean'?'euclidean':'port';
      // Its fills played lighter the busier they are than its groove (fill-loudness.js): the times of its snare strokes
      // in the groove of the last few bars.
      this.fillLoudness=settings?.fillLoudness!==false;this.grooveStrokes=[];this.grooveDb=[];
      // The band it hears around its fills: the others' onsets (not its own).
      this.heardAround=new HeardRhythm({bars:FILL_HEARING.bars});
      // Its fills as figures (fill-figures.js): settings.fillFigures false strikes every slot, on the fill's ramp.
      this.fillFigures=settings?.fillFigures!==false;
      // Its fills' lengths (fill-phrase.js): as many felt beats as the Groove MIDI drummers' fills ran, the bigger the
      // join's move the longer. settings.fillPhrases false keeps every fill to one felt beat; settings.fillBeats fixes a
      // length in felt beats, or [least, most]; settings.fillExtremes opens the extremes (up to sixteen bars, a grouping
      // against the meter most of the time, tuplets and nesting often), or names them: {dissonance, tuplets, nesting}
      // appetites from 0 to 1 and mostBars, each in place of fill-phrase.js's (a section's 'extreme' fills too).
      this.fillPhrases=settings?.fillPhrases!==false;this.fillBeatsSetting=settings?.fillBeats??null;
      this.fillExtremes=settings?.fillExtremes===true||extremesNamed(settings?.fillExtremes);this.extremes=extremesOf(settings?.fillExtremes);
      // Its fills continuous with its groove: a lead-in, a tail, a series (settings.fillContinuity false: none).
      this.fillContinuity=settings?.fillContinuity!==false;this.fillSeries=[];this.fillTail=null;this.leadIns=[];
      // Its fills played with hands and foot: the kick in some of the hands' rests, as the Groove MIDI drummers' was
      // (fill-figures.js fillKicks; settings.fillKicks false: the groove's kick goes on under every fill).
      this.fillKicks=settings?.fillKicks!==false;
      // Its fills taking after the figures the others say (/broadcast/figure: a section's tremolo, a pianist's or a
      // guitarist's figure), as far as its inspiration (settings.inspiration, 0 to 1; else drawn once a piece from its
      // seed): its cells rolled as often as that share of how near the figure heard is to the one-tone corner, where its
      // hands can roll them (figuration.js oneTone); and a roll it plays said as that corner's figure.
      if(settings?.inspiration!=null&&!(Number(settings.inspiration)>=0&&Number(settings.inspiration)<=1))throw new RangeError('A drummer\'s inspiration is a share from 0 to 1');
      this.inspirationAsked=settings?.inspiration!=null?Number(settings.inspiration):null;
      // Its fills' flams and drags: graces on their strokes' own drums, as the Groove MIDI drummers' were
      // (fill-figures.js fillGraces; settings.fillGraces false: none).
      this.fillGraces=settings?.fillGraces!==false;
      // Its fills' strokes doubled on another drum now and then: two drums struck together, as the drummers' were
      // (fill-figures.js fillDoubles; settings.fillDoubles false: none).
      this.fillDoubles=settings?.fillDoubles!==false;
      // Its answer to a hold (clock-hold.js): a crash over a fermata, a pickup into the re-entry (settings.holdAnswer
      // false: none).
      this.holdAnswer=settings?.holdAnswer!==false;this.hold=null;this.pendingResume=null;this.holdAnswers=[];
      // Fill and groove as one continuum (figure-blend.js): settings.fillness stands it anywhere between them, a number
      // from 0 (the groove) to 1 (a fill), or [[bar, value], ...] moving bar by bar (in a render spec, "1:0 7:1 13:0"), or
      // 'solo': a drum solo's course of its
      // own (soloCourse). settings.fillOrder says which strokes move first ('metrical', 'landing' or 'even');
      // settings.fillRestate, how often a bar's figure is the last bar's again, so that a fill restated becomes a groove of
      // its own.
      this.fillness=settings?.fillness==='solo'?'solo':checkedFillness(settings?.fillness);this.fillOrder=settings?.fillOrder??'metrical';
      if(!FIGURE_BLEND.orders.includes(this.fillOrder))throw new RangeError(`settings.fillOrder is one of ${FIGURE_BLEND.orders.join(', ')}`);
      this.fillRestate=settings?.fillRestate??FIGURE_BLEND.restate;
      if(!(this.fillRestate>=0&&this.fillRestate<=1))throw new RangeError('settings.fillRestate is from 0 to 1');
      this.blendSeed=null;this.blendBar=null;
      this.strokeName='xdrum_clodbot';this.fills=[];this.fillPlan=null;
      // Who plays (the performer contract): a drummer's four limbs, or settings.performer's profile.
      this.performer=settings?.performer??drummer({id:'xdrum_clodbot'});
      if(audio&&typeof audio.houseDrum==='function'){
        if(audio.houseDrum.announcesHits)audio.houseDrum.owner=this;
        else{
          // A hit whose strike the caller gave (the cadence's fill) is tuned as a voiced one is.
          const play=audio.houseDrum.bind(audio),wrapped=(kind,accent,strike,...rest)=>{
            const owner=wrapped.owner;if(owner?.limbGate&&!owner.limbGate(kind))return undefined;
            // Between groove and fill (figure-blend.js): the groove's hand strokes as loud as the fillness leaves them.
            const level=owner?.grooveLevel&&!owner.strikingFill?owner.grooveLevel(kind):1;
            if(!(level>0))return undefined;
            // A fill's grouping carried into the groove after its landing (its tail): the hat's accents follow it.
            accent=owner?.tailAccent?owner.tailAccent(kind,accent):accent;
            const voiced=strike===undefined&&owner?.voiceHit?owner.voiceHit(kind,accent)
              :{kind,accent,strike:strike&&owner&&KIND_PIECES[kind]?tunedStrike(owner,KIND_PIECES[kind],strike):strike};
            const leveled=level<1?accentAtLevel(voiced.accent,level):voiced.accent,sounded=owner?.planned?accentAtPlanned(leveled,owner.planned):leveled;
            owner?.announceHit(voiced.kind,Math.max(0,sounded));return play(voiced.kind,sounded,voiced.strike??null,...rest)};
          wrapped.announcesHits=true;wrapped.owner=this;audio.houseDrum=wrapped;
        }
      }
    }
    // How far its fills lean toward a roll: its inspiration (asked, else drawn once a piece from its seed) times how near
    // the last figure it heard is to the one-tone corner (figuration.js oneTone).
    rollLean(){
      if(!this.heardFigure)return 0;
      this.inspiration??=this.inspirationAsked??(()=>{const stream=createRandomStream(`${this.audio?.seed??0}:${this.seedIdentity??this.strokeName}:inspiration`);return stream.next()})();
      return this.inspiration*oneTone(this.heardFigure);
    }
    onMessage(message){
      hearRhythmMessage(this.heardAround,message,this.instanceId??null);
      if(message?.address==='/broadcast/figure'&&message.args?.[0]&&String(message.args[0].voice)!==String(this.instanceId??'xdrum_clodbot'))this.heardFigure=message.args[0];
      // (The conductor's planned dynamics, the band's piece plan's levels by section of the form.)
      (this.plannedLevels??=new PlannedLevels()).hear(message);
      // A cued hold's re-entry as the clock decided it (clock-hold.js holdResume: from the cue, the readiness said and
      // the bound, to every bot alike), from the clock alone. One heard before the held pulse reaches this bot (the
      // clock's messages in the order the bots hear them) is kept for it.
      if(message?.address==='/broadcast/holdResume'&&message.source==='clock'){const decision=message.args?.[0];
        if(decision?.id&&this.hold?.id===decision.id)this.holdResumed(decision);else if(decision?.id)this.pendingResume=decision}
      return super.onMessage(message);
    }
    // A hold (clock-hold.js, 0f's): time stopped at one pulse, the pulse sounding when it would have, none inside it.
    // The drummer answers: where it is as long as the beat it stops in or longer (a fermata; the beat a listener feels
    // there, meter-tactus.js feltBeats), a crash and the kick on the held pulse, the crash left to ring over it (held
    // the hold longer, as every note held over it is: hold-timing.js), unless the band rests through it (a cadenza's);
    // and into the re-entry a pickup, a pulse apart and rising, from here where the hold's length is known, else from
    // the clock's decision (holdResumed). The kit is silent through the hold, since no pulse comes.
    holdBegins(begins,clock){
      const perTick=secondsPerTick(clock),at=clock.tickInBar??0,seconds=Number(begins.seconds)||0;
      const felt=feltBeats(clock.meter,{secondsPerTick:perTick}).find(beat=>at>=beat.start&&at<beat.start+beat.length);
      const beat=(felt?.length??(tactusOf(clock.meter).ticks||clock.meter.subdivision||bandMeter().subdivision))*perTick;
      this.hold=begins.cued?{id:begins.id,bound:Number(begins.bound)||seconds,perTick,heardAt:this.clockNow()}:null;
      const early=begins.cued&&this.pendingResume?.id===begins.id?this.pendingResume:null;this.pendingResume=null;
      const fermata=seconds>=beat;
      if(fermata&&begins.band!=='rest'){
        const written=scoreTime(clock.tick,felt?.length??tactusOf(clock.meter).ticks??clock.meter.subdivision);
        this.landing(written);withScoreTime(this.audio,written,()=>this.audio.houseDrum('kick',FORM_MARKS.crashAccent));this.holdCrashTick=clock.tick;
      }
      this.holdAnswers.push({id:begins.id,tick:clock.tick,fermata,cued:Boolean(begins.cued),band:begins.band??'sustain'});if(this.holdAnswers.length>FILLS_KEPT)this.holdAnswers.shift();
      if(!begins.cued)this.holdPickup(seconds+perTick,'known',perTick);
      else if(early)this.holdResumed(early,0);
    }
    // The clock's decision of a cued hold's re-entry (holdResume): inSeconds from its sending, or the hold's bound where
    // the music goes on at it (a fallback; a clock settling at the bound says 0 from then). The re-entry's pulse comes
    // the held pulse's own length after it, and the pickup leads into that. Strokes placed cannot be taken back: a
    // revision (someone needing longer, before the re-entry is committed) that moves it later by the pickup's length or
    // more is given a pickup of its own, and a smaller move keeps the one placed.
    holdResumed(decision,elapsed=this.holdElapsed()){
      const hold=this.hold,answer=this.holdAnswers.at(-1);if(!hold||answer?.id!==hold.id)return;
      const resume=decision.decision==='fallback'?hold.bound:elapsed+Math.max(0,Number(decision.inSeconds)||0),reentry=resume+hold.perTick;
      (answer.decisions??=[]).push({revision:decision.revision??null,decision:decision.decision??null,reentry});
      if(answer.reentry===undefined||reentry-answer.reentry>=HOLD_ANSWER.pickupAccents.length*hold.perTick)
        this.holdPickup(reentry,answer.reentry===undefined?'decided':'revised',hold.perTick);
    }
    // A pickup into a hold's re-entry, `reentry` seconds after the held pulse: its strokes a pulse apart before it,
    // rising, each that can still sound on time (lateOffset). Placed in the hold's own time, so free of the feel
    // (performed-timing.js leaves a `free` call alone).
    holdPickup(reentry,from,perTick){
      const accents=HOLD_ANSWER.pickupAccents,n=accents.length,times=[],late=this.lateOffset();
      accents.forEach((accent,k)=>{const offset=reentry-(n-k)*perTick;if(offset<late)return;times.push(offset);
        this.audio.houseDrum('snare',accent,this.expression?{position:POSITION_REFERENCE}:null,{offset,free:true})});
      const answer=this.holdAnswers.at(-1);if(answer){(answer.pickups??=[]).push({from,reentry,times});answer.reentry=reentry}
    }
    // The audio's clock (seconds), or null where it has none running.
    clockNow(){try{const now=this.audio?.clockTime?.();return Number.isFinite(now)?now:null}catch{return null}}
    // Seconds since the held pulse reached this bot: a decision's inSeconds count from its own sending.
    holdElapsed(){const now=this.clockNow(),at=this.hold?.heardAt;return now!==null&&Number.isFinite(at)?Math.max(0,now-at):0}
    // The least offset from the held pulse's time a stroke can still sound at: 0 at the pulse, later as the hold goes by
    // (a stroke placed before the audio's clock would sound late).
    lateOffset(){const now=this.clockNow(),at=this.audio?.eventTime;return now!==null&&Number.isFinite(at)?Math.max(0,now-at):0}
    announceHit(kind,accent){
      const tick=this.currentClock?.tick;if(!Number.isFinite(tick))return;
      if(kind==='snare')this.lastSnareTick=tick;
      // Its snare strokes in the groove, when and how loud, for its fills' loudness (a fill's own strokes are not the
      // groove).
      if(kind==='snare'&&!this.strikingFill){
        const seconds=tick*secondsPerTick(this.currentClock),strokes=this.grooveStrokes;
        strokes.push(seconds);this.grooveDb.push(velocityDb(HOUSE_VELOCITY.floor+HOUSE_VELOCITY.span*Math.max(0,Math.min(1,Number(accent)||0))));
        while(strokes.length&&strokes[0]<seconds-FILL_LOUDNESS.grooveSeconds){strokes.shift();this.grooveDb.shift()}
      }
      this.broadcast('onsets',[onsetsPayload({voice:this.instanceId??'xdrum_clodbot',role:'drums',onsets:[{tick,strength:Number(accent)||.7,kind}]})]);
    }
    // Its ending (Closure): the cadence bar's last beat a fill up (a counted gesture, rising, moving out to the rim and
    // ending on a rimshot), the last bar's downbeat the kick with a cymbal struck and left to ring, then nothing.
    onTick(tick,clock){
      // (The conductor's planned dynamics where this bar lies, dB from its own loudness: none where none is planned.)
      this.planned=plannedDb(this.plannedLevels?.at(clock?.bar));
      const closing=this.closingAt(clock);
      if(closing.phase==='after')return;
      if(closing.phase==='final'){if((clock.tickInBar??0)===0&&this.enabled!==false)this.finalHit(scoreTime(clock.tick,closing.ticksLeft));return;}
      if(closing.phase==='cadence'&&clock?.meter){
        const beat=tactusOf(clock.meter).ticks||clock.meter.subdivision||bandMeter().subdivision,bar=clock.meter.pulsesPerBar,at=clock.tickInBar??0;
        // The ending's fill lands on its final crash (finalHit).
        if(at>=bar-beat){this.fillStroke({fill:'up',step:at-(bar-beat),steps:beat,join:`cadence:${clock.bar}`,crashAfter:true},clock);return this.patternBesideFill(tick,clock)}
      }
      // The form's joins (FormMarks): the fill's beat played as the fill, or rested (a break: the whole kit silent), and the
      // landing's crash, where there is one, over the pattern's downbeat.
      const mark=this.enabled===false||this.exiting?null:this.formMark(clock);
      if(clock?.held?.begins&&this.holdAnswer&&this.enabled!==false&&!this.exiting)this.holdBegins(clock.held.begins,clock);
      else{this.hold=null;this.pendingResume=null}
      if(mark?.fill==='break'){this.restBeat(mark,clock);return undefined}
      if(mark?.fill){this.fillStroke(mark,clock);return this.patternBesideFill(tick,clock)}
      // (One crash where a fermata is held on a landing: the hold's, left to ring over it.)
      if(mark?.crash&&this.holdCrashTick!==clock.tick)this.landing(scoreTime(clock.tick,tactusOf(clock.meter).ticks||clock.meter.subdivision));
      // Between groove and fill (settings.fillness): a fill planned over the bar, as much of it sounding as the fillness
      // says, and the groove beside it as much as it leaves.
      const fillness=this.enabled===false||this.exiting?null:this.fillnessOf(clock);
      if(fillness>0||this.fillPlan?.blend&&this.fillPlan.bar===clock.bar){this.fillStroke(this.blendMark(clock),clock);return this.patternBesideBlend(tick,clock)}
      const played=this.playPattern(tick,clock);
      if(this.enabled!==false&&!this.exiting)this.leadIn(tick,clock);
      return played;
    }
    // The groove bent into a coming fill, as the Groove MIDI drummers' was (fill-figures.js leadIn): each of the two felt
    // beats before its window busy with the hands (two soft strokes) as much more often than the groove's own beats were
    // as theirs were, decided once a fill (the beat just before 39% of the time, the one before 13%), on ticks drawn in
    // the beat; a tick the groove's snare takes is left to it. As far under the groove's snare as theirs were.
    leadIn(tick,clock){
      if(!this.fillContinuity||!this.fillFigures)return;
      const ahead=this.fillAhead(clock);if(!ahead)return;
      const [just,before]=ahead.beatsBefore,which=ahead.ticksUntil<=just?-1:ahead.ticksUntil<=just+before?-2:null;
      if(which===null)return;
      const {baseline,busy,strokes,levelDb}=FILL_FIGURES.data.leadIn,key=`${ahead.join}:${which}`;
      if(!this.leadInPlans?.has(key)){
        const random=this.fillRandom(`leadin:${ahead.join}:${which}`),ticks=which===-1?just:before,from=clock.tick+ahead.ticksUntil-(which===-1?just:just+before);
        const chance=Math.max(0,(busy[which]-baseline)/(1-baseline)),places=[];
        if(random()<chance){const free=[...Array(ticks).keys()];for(let k=0;k<Math.min(strokes,ticks);k++)places.push(from+free.splice(Math.floor(random()*free.length),1)[0])}
        places.sort((a,b)=>a-b);const intervals=patternIntervals(places,from+ticks,{axis:'ensemble'});
        (this.leadInPlans??=new Map).set(key,new Map(places.map((at,k)=>[at,intervals[k]])));if(this.leadInPlans.size>64)this.leadInPlans.delete(this.leadInPlans.keys().next().value);
      }
      if(!this.leadInPlans.get(key).has(tick)||this.lastSnareTick===tick)return;
      const grooveDb=this.grooveDb.length?this.grooveDb.reduce((sum,db)=>sum+db,0)/this.grooveDb.length:velocityDb(HOUSE_VELOCITY.floor+HOUSE_VELOCITY.span*.5);
      const velocity=softerVelocity(softerVelocity(1,Math.min(0,grooveDb)),levelDb),accent=Math.max(0,(velocity-HOUSE_VELOCITY.floor)/HOUSE_VELOCITY.span);
      withScoreTime(this.audio,this.leadInPlans.get(key).get(tick),()=>this.audio.houseDrum('snare',accent,this.expression?{position:POSITION_REFERENCE}:null));
      this.leadIns.push({join:ahead.join,tick,beat:which,velocity,grooveDb});if(this.leadIns.length>FILLS_KEPT)this.leadIns.shift();
    }
    // A hat's accent in a fill's tail: at the head of one of the fill's groups, carried on from its landing for a bar,
    // accented; between them, softer.
    tailAccent(kind,accent){
      const tail=this.fillTail,tick=this.currentClock?.tick;
      if(!tail||!Number.isFinite(tick)||!['closedHat','openHat','hihat','ride'].includes(kind))return accent;
      if(tick<tail.from||tick>=tail.to){if(tick>=tail.to)this.fillTail=null;return accent}
      const along=Rational.of(tick-tail.from).div(tail.group),head=along.sub(along.floor()).toNumber()*tail.group.toNumber()<.5;
      return Math.max(0,Math.min(1,accent*(head?FILL_CONTINUITY.tailHead:FILL_CONTINUITY.tailOther)));
    }
    // A fill is a counted gesture over its beat (shared/performers/gestures.js), chosen on the beat's first tick: how
    // many slots (fillCount: the beat's own ticks or an odd count, those whose figure its hands can play at the tempo,
    // by the performer contract), its figure over them (fill-figures.js: the slots it strikes, its sticking, each
    // stroke's level), each contact played at its exact time, between the ticks where it falls. Up the snare, moving
    // out to the rim, a rimshot last where it is accented; or down the toms, an action (a stroke, a rebound pair) on one
    // drum and the actions from the highest tom down over as many toms as its hands can travel between at the tempo
    // (fillToms; the snare's where the voice has none).
    fillStroke({fill,step,steps,join,move=null,crashAfter=false,beats=1,fills=null,seed=join,blend=false,intensity=null,speed=null,appetite=null},clock){
      const perTick=secondsPerTick(clock);
      // A fill under way stands (T38): what it has struck was sent, and the rest of its span is its own to finish, its
      // rests too (a figure may leave its last slots out).
      const underway=this.fillPlan&&!this.fillPlan.none&&this.fillPlan.sent>0&&clock.tick<this.fillPlan.gesture.start.add(this.fillPlan.gesture.span).toNumber();
      if(this.fillPlan?.join!==join&&!underway){
        const stickingOf=count=>count%2&&count>=3?'roll':'singles',seconds=steps*perTick,random=this.fillRandom(seed),start=clock.tick-step;
        const context=this.fillFigures?{...this.fillContext({step,steps,move},clock),crash:crashAfter,...(intensity===null?{}:{intensity})}:null;
        const plan=(count,sticking=stickingOf(count),rests=[],graces=[])=>gesture({id:`fill:${join}`,n:count,start,span:steps,sticking,rests,graces});
        // Made playable, never checked while it plays (drummer.js "By construction"): each choice below weighs its few
        // options by what its hands allow where their contacts will sound (handsAllow) and takes one of those, and the
        // counts and grids it weighs are those whose every slot its hands' fastest motion reaches (motionSpacing), so one
        // always is. A drummer without both hands plays no fill.
        const {motion,feel,quarter,swingsAt,swungAt,allows}=this.fillHands(clock);
        if(!Number.isFinite(motion.fastest)){this.fillPlan={join,none:true};return}
        // A count its hands play whatever its figure leaves out: one whose strokes its fastest motion reaches (the doubles
        // over them, fill-figures.js doublesMotion; singles where it has no rebounds), struck every slot or, on a grid
        // finer than that motion, every k-th, so long as those keep the share of its slots a figure keeps (a third:
        // fill-figures.js leastStrokes); two strokes or one, always. A plain fill (no figures) strikes every slot.
        const motionOf=struck=>Number.isFinite(motion.doubles)?doublesMotion(struck).hands:struck.map((slot,k)=>({hand:k%2?'L':'R',action:`stroke-${k}`}));
        const reaches=count=>{
          if(count<=2)return true;
          if(!this.fillFigures)return allows(plan(count));
          const stride=Math.max(1,Math.ceil(motion.fastest*count/seconds-1e-9)),struck=[...Array(count).keys()].filter(slot=>slot%stride===0);
          return struck.length>=leastStrokes(count)&&allows(plan(count,motionOf(struck),[...Array(count).keys()].filter(slot=>slot%stride)));
        };
        const planned=(played,{plain=false,figure=null,swings=false,swung=false}={})=>{
          const toms=fill==='down'&&!plain?fillToms(played,{secondsPerTick:perTick}):null;
          // A rimshot last where the last stroke is accented (a figure's may be a tap or a ghost).
          const rim=this.expression&&(!figure||figure.roles.at(-1)==='accent');
          return {join,fill,plain,figure,rim,swings,swung,gesture:played,actions:strokeActions(played),toms,sent:0,navigation:null,
            // Its hands the fill's to its landing, its silences too (a stop short of a crash is the drummer's).
            limbActions:phraseActions(gestureActions(played,{secondsPerTick:perTick}),{id:`fill:${join}`,until:played.start.add(played.span).toNumber()*perTick})};
        };
        const single=()=>{
          const count=fillCount({ticks:steps,seconds,fill,random,playable:reaches}),swings=swingsAt(count*quarter/steps);
          // Its figure (fill-figures.js): its rests, and a sticking its hands can play them in, swung with the band where
          // they can play it so.
          const figure=this.fillFigures?fillFigure({n:count,seconds,fill,random,context,fastest:motion.fastest,
            playable:({rests,hands})=>{const played=plan(count,hands,rests);return swings&&allows(played,true)?2:allows(played)?1:0}}):null;
          if(!figure){const played=plan(count);return planned(played,{swings,swung:swings&&allows(played,true)})}
          const swung=figure.way===2;
          // Its flams and drags (fill-figures.js fillGraces), each before its slot's stroke, kept where its hands can play it.
          const struck=[...Array(count).keys()].filter(slot=>!figure.rests.includes(slot));
          const onSlots=list=>list.map(grace=>({slot:struck[grace.index],count:grace.count,seconds:grace.seconds}));
          const graces=this.gracesOf(louderStrokes(figure.levelsDb),{playable:list=>allows(plan(count,figure.hands,figure.rests,onSlots(list)),swung),secondsOf:index=>struck[index]*seconds/count,random});
          return planned(plan(count,figure.hands,figure.rests,onSlots(graces)),{figure:graces.length?{...figure,graces}:figure,swings,swung});
        };
        // A fill of several felt beats is a phrase (phraseFill); one it cannot make is one figure over the window.
        const phrase=beats>1&&this.fillFigures?this.phraseFill({fill,step,steps,beats,join,move,crashAfter,extremes:this.fillExtremes||fills==='extreme',appetite,speed,intensity},clock,random):null;
        const refused=beats>1&&this.fillFigures&&!phrase?'no phrase of these beats it can make: one figure over them':null;
        const chosen=phrase?()=>planned(phrase.played,{figure:phrase.figure,swings:phrase.swings,swung:phrase.swung}):single;
        // Live, in time (live.js, T38): the plain fill first (singles on the snare, as many as the window holds at its
        // hands' pace, evenly: a single a tick where the ticks allow), then the one it would rather play, if there is
        // time. Both are made playable, so neither is checked (MADE_PLAYABLE).
        const plainCount=Math.max(1,Math.min(steps,GESTURES.mostSlots,Math.floor(seconds/motion.singles+1e-9)));
        const plainFill=()=>{const played=plan(plainCount,'singles'),swings=swingsAt(plainCount*quarter/steps);return planned(played,{plain:true,swings,swung:swings&&allows(played,true)})};
        const result=planLive({fallback:plainFill,candidates:[chosen],validate:MADE_PLAYABLE,contactsOf:()=>[],
          deadlineMs:planDeadlineMs({offline:this.audio?.offline!==false,lookaheadSeconds:this.audio?.clock?.lookahead??undefined}),now:this.planNow});
        // Two drums struck together (fill-figures.js fillDoubles), where its hands can play them where they sound.
        result.plan=this.doublesOf(result.plan,{start,perTick,join,random,allows:played=>allows(played,result.plan.swung)});
        // Its hands' moves about the kit (fillNavigation), where its contacts sound, a late stroke never crowding the next
        // on its hand.
        if(this.navigate&&!result.plan.plain)result.plan.navigation=fillNavigation(result.plan.gesture,{fill,toms:result.plan.toms,secondsPerTick:perTick,
          rim:result.plan.rim,secondsOf:result.plan.swung?swungAt(result.plan.gesture):null});
        this.fillPlan={...result.plan,gesture:scoredGesture(result.plan.gesture)};const played=this.fillPlan.gesture;
        // Between groove and fill: each stroke's level at the fillness where it falls (figure-blend.js); a grace's is its
        // stroke's. Its hands held stroke by stroke, not for the whole bar, so the groove plays between its strokes.
        if(blend){
          const u=this.fillRandom(`${join}:blend`),start=clock.tick-step,starts=this.blendBeatStarts(clock),levels=new Map;
          const strokes=played.contacts.filter(contact=>!contact.of).map(contact=>{const at=contact.at.toNumber()-start;
            return {id:contact.id,at,weight:metricalWeight(at,{beatStarts:starts,span:steps}),position:at/steps,u:u()}});
          const thresholds=rankThresholds(strokes,{order:this.fillOrder});
          for(const stroke of strokes)levels.set(stroke.id,blendLevel(thresholds.get(stroke.id),this.fillnessOf(clock,Math.min(steps-1e-9,stroke.at))??0,{entering:true}));
          const sounding=played.contacts.filter(contact=>(levels.get(contact.of??contact.id)??0)>0);
          Object.assign(this.fillPlan,{blend:true,bar:clock.bar,levels,sounding:sounding.length,limbActions:gestureActions({...played,contacts:sounding},{secondsPerTick:perTick})});
        }
        // Its kicks (fill-figures.js fillKicks): the rests its foot plays, where the performer has the foot and it is
        // free of its last kick. Where it plays one, the foot is the fill's to its landing as its hands are
        // (phraseActions), so the groove's kick waits; where it plays none, the groove's kick goes on under it.
        {const figure=result.plan.figure;let kicks=[];
          if(this.fillKicks&&!blend&&figure&&!result.plan.plain&&this.performer.resources.has(DRUMMER.pieceLimbs.kick)){
            const last=played.contacts.at(-1)?.at,start=clock.tick-step;
            const gaps=(figure.gaps??figure.rests.map(k=>({at:Rational.of(start).add(new Rational(k*steps,figure.n)),duration:new Rational(steps,figure.n),slotsPerSecond:figure.n/seconds})))
              .map(gap=>({...gap,silence:Boolean(last)&&gap.at.gt(last)}));
            // (Each where it sounds: swung with the fill's strokes where they swing.)
            const soundsAt=at=>at.toNumber()*perTick+(result.plan.swung?this.swungSeconds?.(clock,feel,at.toNumber()*perTick-clock.tick*perTick)??0:0);
            const kept=[],footOf=list=>gestureActions({contacts:list.map((kick,i)=>({id:`kick-${i}`,action:`kick-${i}`,hand:'K',at:kick.at}))},{secondsPerTick:perTick,hands:{K:DRUMMER.pieceLimbs.kick},secondsOf:contact=>soundsAt(contact.at)});
            for(const kick of fillKicks(gaps,{random,crash:crashAfter}))if(limbFree(footOf(kept),DRUMMER.pieceLimbs.kick,soundsAt(kick.at)))kept.push(kick);
            kicks=kept;this.fillPlan.gaps=gaps.length;
            if(kicks.length)this.fillPlan.limbActions=phraseActions([...gestureActions(played,{secondsPerTick:perTick}),...footOf(kicks)],{id:`fill:${join}`,until:played.start.add(played.span).toNumber()*perTick});
          }
          this.fillPlan.kicks=kicks.map(kick=>({at:kick.at,silence:kick.silence,scoreTime:scoreTime(kick.at,kick.duration)}));this.fillPlan.kickAccent=.35+.65*(Number.isFinite(this.density)?this.density:.5)}
        // In its own subdivision where it does not swing; and placed whole by the feel, as its first stroke is (fillPlacement).
        this.fillPlan.ownSubdivision=!result.plan.swung;
        this.fillPlan.placedSeconds=this.fillPlacement(played,clock,feel,fill==='down'&&this.expression&&!result.plan.plain&&typeof this.audio.drum==='function'?null:'snare');
        // A figure's loudness its groove's: its strokes as loud on average as the groove's snare strokes of the last
        // grooveSeconds, its loudest never over the ramp's top (no groove heard: the ramp's top).
        const figure=result.plan.figure,top=HOUSE_VELOCITY.floor+HOUSE_VELOCITY.span;
        if(figure){
          const grooveDb=this.grooveDb.length?this.grooveDb.reduce((sum,db)=>sum+db,0)/this.grooveDb.length:null;
          const meanDb=figure.levelsDb.reduce((sum,db)=>sum+db,0)/Math.max(1,figure.levelsDb.length);
          // (In a solo, as much nearer the ramp's top as its arc is intense: its climax at the top.)
          const matched=grooveDb===null?velocityDb(top):Math.min(velocityDb(top),grooveDb-meanDb);
          this.fillPlan.topDb=intensity===null?matched:matched+(velocityDb(top)-matched)*intensity;
          this.fillPlan.topVelocity=softerVelocity(1,this.fillPlan.topDb);this.fillPlan.grooveDb=grooveDb;
        }
        // How much lighter than planned (fill-loudness.js): its busiest 400 ms against the groove's of the last
        // grooveSeconds, each stroke where it will sound.
        const now=clock.tick*perTick;
        // (Each where it sounds: a grace its seconds before its stroke, moved about the kit as its stroke is.)
        // (In a solo, as much less as its arc is intense: none given back at its climax.)
        this.fillPlan.offsetBaseDb=this.fillLoudness?fillOffsetDb({fill:played.contacts.map(contact=>contact.at.toNumber()*perTick-(contact.before??0)+(this.fillPlan.navigation?.get(this.fillStrokeOf(contact).stroke.id)?.lateSeconds??0)),
          groove:this.grooveStrokes.filter(seconds=>seconds>now-FILL_LOUDNESS.grooveSeconds&&seconds<=now)}):0;
        // Where the band's attention is heard, the give-back is its license's instead (shared/attention.js): the fill's
        // claim over its allowance, full with a small share, none with a solo's; the arc then only shapes the solo.
        const heardAttention=this.attentionAt?.(Number(clock.bar)||0);
        if(heardAttention&&this.fillLoudness){
          const claim=claimOf(played.contacts.map(contact=>({at:contact.at.toNumber()*perTick,velocity:this.fillVelocity(contact)})));
          const given=claim?license({claimDb:claim.claimDb,allowance:heardAttention.allowanceDb}).giveBackDb:0;
          this.fillPlan.offsetBaseDb=-given;this.fillPlan.offsetDb=-given;this.fillPlan.attention={claimDb:claim?.claimDb??null,allowanceDb:heardAttention.allowanceDb,soloing:heardAttention.soloing};
        }else this.fillPlan.offsetDb=(intensity===null?1:1-intensity)*this.fillPlan.offsetBaseDb;
        this.fills.push({join,fill,bar:clock.bar,beats,...(refused?{refused}:{}),...(blend?{blend:{seed,order:this.fillOrder,sounding:this.fillPlan.sounding,...(intensity===null?{}:{intensity,givenBackDb:this.fillPlan.offsetBaseDb})}}:{}),
          ...(this.fillPlan.attention?{attention:this.fillPlan.attention}:{}),
          count:played.contacts.length,slots:played.counts.slots,
          sticking:figure?.sticking??(result.plan.plain?'singles':stickingOf(played.contacts.length)),span:steps,
          ...(figure?.phrase?{phrase:figure.phrase}:{}),
          ...(figure?{rests:figure.rests,ending:figure.ending??figureEnding(figure.n,figure.rests),crashAfter,course:figure.course.kind,courseDb:Math.round(figure.course.db*100)/100,roles:figure.roles,levelsDb:figure.levelsDb.map(db=>Math.round(db*100)/100),
            topDb:Math.round(this.fillPlan.topDb*100)/100,signature:figure.signature??figureSignature(figure),heard:Boolean(context?.hearAt),room:Math.round((context?.room??1)*100)/100}:{}),
          planned:result.source==='candidate'?'as chosen':`plain (${result.status})`,...(result.plan.swings&&!result.plan.swung?{feel:'swung, its hands could not play it: in its own subdivision'}:{}),...(result.plan.toms?{toms:result.plan.toms.length}:{}),offsetDb:this.fillPlan.offsetDb,
          ...(this.fillPlan.gaps!==undefined?{gaps:this.fillPlan.gaps,kicks:this.fillPlan.kicks.map(kick=>kick.at.toNumber()),kickInSilence:this.fillPlan.kicks.some(kick=>kick.silence)}:{}),
          ...(figure?.graces?{graces:figure.graces.map(grace=>({stroke:grace.index,count:grace.count,seconds:Math.round(grace.seconds*1e4)/1e4,db:Math.round(grace.db*100)/100}))}:{}),
          ...(figure?.doubles?{doubles:figure.doubles.map(double=>({stroke:double.index,first:double.first,seconds:Math.round(double.seconds*1e4)/1e4,db:Math.round(double.db*100)/100}))}:{})});
        if(this.fills.length>FILLS_KEPT)this.fills.shift();
      }
      if(this.fillPlan.none)return;
      // Struck as it was planned: a fill under way keeps its own direction whatever the join now asks.
      const {gesture:played,actions,fill:direction}=this.fillPlan;
      this.strikingFill=true;
      try{for(const {contact,offset} of dueAt(played,clock.tick,{secondsPerTick:perTick})){
        this.fillPlan.sent++;
        const level=this.fillPlan.blend?this.fillPlan.levels.get(contact.of??contact.id)??0:1;
        if(!(level>0))continue;
        // A grace is placed as its stroke is, on its drum (fill-figures.js fillGraces); a double on its own (fillDoubles).
        // Neither is the fill's rimshot.
        const {stroke,k,n}=this.fillStrokeOf(contact),progress=n>1?k/(n-1):1,last=k===n-1&&!contact.of,at=offset*perTick,role=contact.of?{role:contact.role}:{};
        // Anchored to its stroke's time, so the feel moves it as it moves its stroke (performed-timing.js).
        const anchor=contact.of?at+(contact.before??0):at;
        // At its place on the ramp, as its hands' moves about the kit strike it (fillNavigation: from lower, a little
        // late), under the fill's offset for its loudness against the groove.
        const moved=this.fillPlan.navigation?.get(stroke.id),when=at+(moved?.lateSeconds??0);
        // Moved by the feel as the whole fill is, and swung within it where it swings (fillPerformed).
        const performed=this.fillPerformed(anchor,clock);
        // Recorded where it sounds: its hands' travel and the feel's move of its anchor, as it is sent (RUB-001's review
        // found it recorded before the travel was added, and by its own time where a grace moves by its principal's).
        this.checkContact(contact,when,anchor,contact.role==='double'?(contact.drum==='snare'?'snare':'toms'):direction==='down'?'toms':'snare',performed);
        const velocity=softerVelocity(softerVelocity(this.fillVelocity(contact),this.fillPlan.offsetDb??0),level<1?20*Math.log10(level):0);
        withScoreTime(this.audio,contact,()=>{
        // A double on its own drum: the snare, or a tom (the kit's highest, middle or lowest, as the drummers' high, mid or floor).
        if(contact.role==='double'&&contact.drum!=='snare'){
          this.audio.drum('tom',velocity,{note:contact.note,strike:tunedStrike(this,'tom',{position:POSITION_REFERENCE}),offset:when,anchorOffset:anchor,ownSubdivision:this.fillPlan.ownSubdivision,performed,...role});return;
        }
        if(contact.role!=='double'&&direction==='down'&&this.expression&&!this.fillPlan.plain&&typeof this.audio.drum==='function'){
          const toms=this.fillPlan.toms,note=toms[Math.round(actions.indexOf(stroke.action)*(toms.length-1)/Math.max(1,actions.length-1))];
          this.audio.drum('tom',velocity,{note,strike:tunedStrike(this,'tom',{position:POSITION_REFERENCE}),offset:when,anchorOffset:anchor,ownSubdivision:this.fillPlan.ownSubdivision,performed,...role});return;
        }
        // (Between groove and fill, a stroke fading in may sound under the house snare's softest.)
        const [from,to]=FILL_POSITION,struck=level<1?(velocity-HOUSE_VELOCITY.floor)/HOUSE_VELOCITY.span:Math.max(0,(velocity-HOUSE_VELOCITY.floor)/HOUSE_VELOCITY.span);
        // Played late by its hands' travel, and moved by the ensemble's feel as the contact planned at `at` is (performed-timing.js).
        this.audio.houseDrum('snare',struck,this.expression?(direction==='up'&&last&&this.fillPlan.rim?{stroke:'rim'}:{position:from+(to-from)*progress}):null,{offset:when,anchorOffset:anchor,ownSubdivision:this.fillPlan.ownSubdivision,performed,...role});
        });
      }
      // Its kicks, each at its rest's exact time, as loud as its groove's kicks (the ensemble's kick policy holds them
      // where they are scheduled, as it does every kick: ensemble-kicks.js).
      for(const kick of this.fillPlan.kicks??[]){const at=kick.at.toNumber()-clock.tick;if(at<0||at>=1)continue;
        const offset=at*perTick;withScoreTime(this.audio,kick,()=>this.audio.houseDrum('kick',this.fillPlan.kickAccent,null,{offset,anchorOffset:offset,ownSubdivision:this.fillPlan.ownSubdivision,performed:this.fillPerformed(offset,clock)}))}
      }finally{this.strikingFill=false}
    }
    // How many felt beats its fill into `join` runs (FormMarks asks, fill-phrase.js plays): as many as the Groove MIDI
    // drummers' fills ran (FILL_FIGURES.data.lengthBeats), the bigger the join's move the longer (its place in their
    // distribution the nearer the top); never back past the landing before it (the section's first felt beat kept);
    // settings.fillBeats (a count, or [least, most]) fixes it; settings.fillExtremes draws any length up to sixteen bars,
    // as likely at each doubling; and a section may ask the same of the fill into it (form-joins.js: its `fills`, a length
    // in felt beats or 'extreme'). A break is one felt beat, whatever this says.
    fillBeatsOf(join,{mark,beats,previous}){
      if(!this.fillFigures||!this.fillPhrases)return 1;
      const extremes=this.fillExtremes||join.fills==='extreme',setting=Number.isFinite(join.fills)?join.fills:this.fillBeatsSetting;
      const perBar=beats.length,most=Math.max(1,(join.bar-previous)*perBar-(extremes?0:1));
      const clamp=value=>Math.max(1,Math.min(most,Math.round(value))),random=this.fillRandom(`length:${join.bar}`);
      if(Array.isArray(setting)&&setting.length===2&&setting.every(Number.isFinite))return clamp(setting[0]+Math.floor(random()*(setting[1]-setting[0]+1)));
      if(Number.isFinite(Number(setting))&&setting!==null)return clamp(Number(setting));
      const move=Number.isFinite(mark?.move)?Math.min(1,Math.abs(mark.move)):null,u=move===null?random():(move+random())/2;
      if(extremes)return clamp(Math.exp(u*Math.log(this.extremes.mostBars*perBar)));
      const lengths=Object.entries(FILL_FIGURES.data.lengthBeats).map(([length,share])=>[Number(length),share]).sort((a,b)=>a[0]-b[0]);
      let sum=0;for(const [length,share] of lengths){sum+=share;if(u<sum)return clamp(length)}
      return clamp(lengths.at(-1)[0]);
    }
    // What its hands allow where a fill's contacts will sound (drummer.js "By construction"), at this clock: its motions'
    // closest spacings (motionSpacing); whether a grid of `perQuarter` slots a quarter is the level the feel swings
    // (eighths in an eighth swing, sixteenths in a sixteenth one: the rubato report §7.5), where a fill swings with the
    // band if its hands can play it so; each contact's seconds swung (a grace or a double with its stroke); and whether
    // its limbs allow a gesture (handsAllow), swung or in its own subdivision. A swing shortens one gap of each pair (at
    // 0.65, by 30%). The rest of the feel (a placement, its offsets on the beat, a lean) moves the whole fill alike
    // (fillPlacement), which changes nothing its hands allow.
    fillHands(clock){
      const perTick=secondsPerTick(clock),feel=this.electronic?null:this.currentFeel?.(clock)??null,quarter=clock.meter.subdivision*clock.meter.denominator/4;
      const swingsAt=perQuarter=>{const swing=feel?.swing?.subdivision;return swing==='eighth'&&Math.abs(perQuarter-2)<1e-9||swing==='sixteenth'&&Math.abs(perQuarter-4)<1e-9};
      const swungAt=played=>{const byId=new Map(played.contacts.map(contact=>[contact.id,contact]));
        return contact=>{const stroke=contact.of?byId.get(contact.of)??contact:contact,nominal=stroke.at.toNumber()*perTick;
          return nominal-(contact.before??0)+(this.swungSeconds?.(clock,feel,nominal-clock.tick*perTick)??0)}};
      const allows=(played,swung=false)=>handsAllow(played,{who:this.performer,secondsPerTick:perTick,secondsOf:swung?swungAt(played):null});
      return {motion:motionSpacing(this.performer),feel,quarter,swingsAt,swungAt,allows};
    }
    // A fill over several felt beats as a phrase (fill-phrase.js): a grid its felt beats share (their common length,
    // divided as a beat's fill is: fillCount), grouped with the meter or against it (resolving at the landing). Each
    // cell's rests are drawn as the drummers' were at its rate, and its sticking is one its hands can play (singles, hand
    // to hand, a roll, a paradiddle, doubles: fill-figures.js fillStickings), the lead handed on from cell to cell. Each
    // group's head and each rudiment's own accent is accented, with one course over it all; into a crash it plays
    // through or stops as the drummers did. Made playable (drummer.js "By construction"): no grid, tuplet or nested
    // tuplet places two contacts closer than its hands' fastest motion, and its hands are its cells' stickings joined
    // where they can play them so, else one motion throughout (phraseMotion). A grid none of whose draws makes a phrase
    // (a bound on work, a crash's ending) gives way to a slower one. {played, figure, swings, swung}, or null.
    phraseFill({fill,step,steps,beats,join,move,crashAfter,extremes=this.fillExtremes,appetite:given=null,speed=null,intensity=null},clock,random){
      const perTick=secondsPerTick(clock),start=clock.tick-step,felt=feltBeats(clock.meter,{secondsPerTick:perTick});
      const window=[];for(let i=beats-1;i>=0;i--)window.push(felt[felt.length-1-(i%felt.length)].length);
      const unit=window.reduce((a,b)=>gcd(a,b)),appetite=given??(extremes?this.extremes:FILL_PHRASE.ordinary);
      const {motion,quarter,swingsAt,allows}=this.fillHands(clock);
      // Its grid's rate: the appetite's (a solo's climax, an extreme's), never beyond its hands' fastest motion. And a
      // phrase with an appetite for nesting leaves itself room to nest, as often as its appetite: its grid no faster
      // than lets a place hold two notes at that motion (the checks had found such grids by giving up faster ones).
      const most=Math.min(FORM_MARKS.mostContactsPerSecond*(speed??(extremes?2:1)),1/motion.fastest),lastBeat=window.at(-1);
      const roomy=appetite.nesting>0&&unit*perTick>=2*motion.fastest&&random()<appetite.nesting;
      const within=count=>count<=unit*perTick*most*(1+1e-9)&&!(roomy&&unit*perTick/count<2*motion.fastest*(1-1e-9));
      const first=fillCount({ticks:unit,seconds:unit*perTick,fill,random,playable:within});
      const {through,stop,slack}=FILL_FIGURES.data.landing,{hearAt}=this.fillContext({step,steps,move},clock);
      const caught=fraction=>(hearAt?.(fraction)?.accent??0)>=FILL_FIGURES.caught;
      // A series: now and then this fill develops the last one grouped against the meter, its grouping and its cells, on
      // its grid (its slot, where this window's unit divides into it and its hands can play it), so it is heard as that
      // figure again; then as drawn, slower and slower.
      const earlier=this.fillContinuity?this.fillSeries.filter(entry=>entry.size!==null).at(-1)??null:null,develop=earlier&&random()<FILL_CONTINUITY.series?earlier:null;
      const theirs=develop?new Rational(unit).div(develop.slot):null,grid=theirs?.isInteger()&&within(theirs.toNumber())?theirs.toNumber():null;
      const grids=[...new Set([...(grid?[grid]:[]),...Array.from({length:first},(_,k)=>first-k)])];
      for(const perUnit of grids){
        const developing=develop&&perUnit===grid;
        const slots=steps/unit*perUnit,own=window.map(ticks=>ticks/unit*perUnit),slotSeconds=unit*perTick/perUnit;
        // A grid of more slots than a phrase may hold (fill-phrase.js: a bound on work) gives way to a slower one.
        if(slots>FILL_PHRASE.mostSlots)continue;
        // A cell's figure where it is played: its rests (drawn, or a developed cell's), and a sticking its hands can play.
        const figure=(count,{size,seconds,rests:given,rolled=false})=>{
          const rests=given??fillRests(count,{slotsPerSecond:count/seconds,random}),struck=[...Array(count).keys()].filter(k=>!rests.includes(k));
          const cell=hands=>gesture({id:'cell',n:count,span:new Rational(size*unit,perUnit),rests,sticking:hands});
          const options=fillStickings(struck,{n:count}).filter(sticking=>allows(cell(sticking.hands)));
          // (Rolled as often as its lean toward the figure heard, where its hands can roll it; else drawn among what they
          // can play. None: the doubles over its strokes, as a figure's, where its hands reach them so.)
          const roll=options.find(sticking=>sticking.name==='roll'),lean=this.rollLean();
          let sticking=roll&&(rolled||lean>0&&random()<lean)?roll:options.length?options[Math.min(options.length-1,Math.floor(random()*options.length))]:null;
          if(!sticking&&struck.length){const motion=doublesMotion(struck);if(allows(cell(motion.hands)))sticking=motion}
          return {n:count,rests,sticking:sticking?.name??'singles',hands:sticking?.hands??null,accents:sticking?.accents??[]};
        };
        // (And, as often as it leans toward a roll heard, the whole fill one roll, every slot struck, swelling into what it
        // lands on -- a roll beyond its cells' (the 'never does' list, item 8's Next): its first draw, where its hands can
        // roll it; its dynamics the fill's, rising through it.)
        const lean=this.rollLean(),swell=lean>0&&random()<lean;
        for(let draw=0;draw<FILL_FIGURES.draws;draw++){
          const phrase=swell&&draw===0?{slots,groups:[slots],cells:[figure(slots,{size:slots,seconds:slots*slotSeconds,rests:[],rolled:true})],size:slots,dissonance:0,developed:[]}
            :choosePhrase({slots,own,slotSeconds,dissonance:appetite.dissonance,tuplets:appetite.tuplets,nesting:appetite.nesting,random,figure,
            prefer:developing?develop.size:null,reuse:developing?develop.cells:null,fastest:motion.fastest});
          // The band's accents it catches (fill-figures.js): never a rest there, a cell varied (in singles) where it needs to be.
          if(hearAt){let at=0;phrase.cells=phrase.cells.map((cell,i)=>{const from=at;at+=phrase.groups[i];
            const rests=(cell.rests??[]).filter(k=>!caught((from+k/cell.n*phrase.groups[i])/slots));
            return rests.length===(cell.rests??[]).length?cell:{...cell,rests,sticking:'singles',hands:null,accents:[]}})}
          // Counted before it is expanded (fill-phrase.js phraseCount, RHY-002): one of more contacts than a phrase may
          // expand to is drawn again.
          const described={start,span:steps,slots,groups:phrase.groups,cells:phrase.cells};
          if(phraseCount(described)>BigInt(FILL_PHRASE.mostContacts))continue;
          const contacts=phraseContacts(described);
          if(!contacts.length)continue;
          const played={id:`fill:${join}`,start:Rational.of(start),span:Rational.of(steps),counts:{slots,contacts:contacts.length},
            contacts:phraseSticking(contacts,phrase.cells,join,{fits:list=>allows({contacts:list})})};
          // Into a crash, through or a stop, never between (fill-figures.js landing): its last stroke's silence, in its last felt beat.
          const gap=(start+steps-contacts.at(-1).at.toNumber())/lastBeat,ending=gap<=through+slack+1e-12?'through':gap>=stop-slack-1e-12?'stop':'between';
          if(crashAfter&&ending==='between')continue;
          // Its hands: its cells' stickings joined where they can play them so (swung with the band where the phrase
          // swings: no tuplet, its grid the level the feel swings); else alternating singles throughout; else the
          // doubles' motion throughout, which they play, since no two of its contacts are closer than the doubles allow.
          const tuplets=phrase.cells.some((cell,i)=>cell.n!==phrase.groups[i]||cell.nested),swings=!tuplets&&swingsAt(slots*quarter/steps);
          const ways=[[played.contacts,'cells'],[phraseMotion(contacts,'singles',join),'singles'],[phraseMotion(contacts,'doubles',join),'doubles']]
            .flatMap(([hands,name])=>[...(swings?[{hands,name,swung:true}]:[]),{hands,name,swung:false}]);
          const way=ways.slice(0,-1).find(option=>allows({...played,contacts:option.hands},option.swung))??ways.at(-1);
          played.contacts=way.hands;
          // Accented: each group's head, each rudiment's own accent, and each stroke on a band's accent it catches.
          const progress=played.contacts.map(contact=>(contact.at.toNumber()-start)/steps);
          const dynamics=fillDynamics(played.contacts.map((_,k)=>k),{n:played.contacts.length,fill,random,context:{move,crash:crashAfter,...(intensity===null?{}:{intensity})},progress,
            accents:played.contacts.flatMap((contact,k)=>contact.head||contact.accented||caught(progress[k])?[k]:[])});
          // Its flams and drags (fill-figures.js fillGraces), each before its stroke, kept where its hands can play it.
          // Each stroke louder than its felt beat's others or not, as the drummers' were read (fill-figures.js louderStrokes).
          const bounds=[];{let at=start;for(const ticks of window){bounds.push(at);at+=ticks}}
          const beatOf=k=>{const at=played.contacts[k].at.toNumber();let beat=0;while(beat+1<bounds.length&&bounds[beat+1]<=at)beat++;return beat};
          const strokes=played.contacts,graces=this.gracesOf(louderStrokes(dynamics.levelsDb,beatOf),{playable:list=>allows({...played,contacts:withGraces(strokes,list)},way.swung),
            secondsOf:index=>(strokes[index].at.toNumber()-start)*perTick,random});
          if(graces.length){played.contacts=withGraces(strokes,graces);played.counts={...played.counts,contacts:played.contacts.length}}
          const summary={beats,extremes,groups:phrase.groups,size:phrase.size,dissonance:Math.round(phrase.dissonance*100)/100,cells:phrase.cells.map(cell=>cell.n),
            stickings:way.name==='cells'?[...new Set(phrase.cells.map(cell=>cell.sticking??'singles'))]:[way.name],rested:phrase.cells.reduce((sum,cell)=>sum+(cell.rests?.length??0),0),
            tuplets:phrase.cells.some((cell,i)=>cell.n!==phrase.groups[i]||cell.nested),nested:phrase.cells.some(cell=>cell.nested)};
          // (A roll it plays said as the one-tone corner's figure, at its rate of its hands' quickest, for the others to
          // take after: figuration.js oneToneFigure.)
          if(summary.stickings.includes('roll'))this.broadcast?.('figure',[figurePayload(this.instanceId??'xdrum_clodbot',oneToneFigure(motion.fastest*perUnit/(unit*perTick)))]);
          // Remembered, for a later fill to develop; and its tail: its grouping carried into the groove for a bar.
          if(this.fillContinuity){
            this.fillSeries.push({join,size:phrase.size,slot:new Rational(unit,perUnit),cells:new Map(phrase.groups.map((size,i)=>[size,phrase.cells[i]]))});
            if(this.fillSeries.length>FILL_CONTINUITY.kept)this.fillSeries.shift();
            if(phrase.dissonance>0&&random()<FILL_CONTINUITY.tail){const landing=start+steps;
              this.fillTail={join,from:landing,to:landing+clock.meter.pulsesPerBar,group:new Rational(phrase.size*unit,perUnit)};summary.tail=true}
          }
          if(phrase.developed.length&&develop)summary.develops={join:develop.join,size:develop.size};
          // Its rests where they fall (a cell's own, at its rate; a nested cell's own rests are its tuplet's), for its kicks.
          const gaps=[];let from=0;
          phrase.groups.forEach((size,i)=>{const cell=phrase.cells[i],span=new Rational(size*unit,perUnit),origin=Rational.of(start).add(new Rational(from*unit,perUnit));
            for(const k of new Set(cell.rests??[]))gaps.push({at:origin.add(span.mul(new Rational(k,cell.n))),duration:span.div(cell.n),slotsPerSecond:cell.n/(size*slotSeconds)});
            from+=size});
          return {swings,swung:way.swung,played,figure:{...dynamics,n:strokes.length,rests:[],gaps,...(graces.length?{graces}:{}),sticking:summary.stickings.join('+'),ending,phrase:summary,signature:`phrase|${phrase.groups.join('+')}|${summary.cells.join(',')}|${summary.stickings.join('+')}`}};
        }
      }
      return null;
    }
    // What is around the fill (fill-figures.js context), heard on its beat's first tick: the band's pattern in the beat
    // (its accent and how busy it is at each point, from the others' onsets over the last bars: nothing where no
    // pattern is heard), the room the band leaves in the beat, the join's move in intensity, and its own last figures.
    // A pulse is not an accent: where every position of a metrical level is as salient as an accent it catches (a
    // walking bass's quarters, a skank's offbeats), the band keeps time there, and none of them is caught.
    fillContext({step,steps,move},clock){
      const n=clock?.meter?.pulsesPerBar,pattern=n?this.heardAround.pattern(clock):null,heard=pattern?.heard?pattern:null,start=(clock.tickInBar??0)-step;
      const busyAt=p=>Math.min(1,heard.rate[p])*heard.confidence;
      const levels=heard?metricalLevels(clock.meter).steps:[],levelOf=p=>levels.find(level=>p%level===0)??1;
      const pulses=new Set(levels.filter(level=>{const same=[...Array(n).keys()].filter(p=>levelOf(p)===level);return same.length>1&&same.every(p=>heard.salience[p]>=FILL_FIGURES.caught)}));
      // A window reaching back into earlier bars hears them by their place in the bar: the band's pattern is a bar's.
      const inBar=x=>((x%n)+n)%n;
      const hearAt=heard?fraction=>{const x=start+fraction*steps,p=Math.round(x);
        return Math.abs(x-p)<=FILL_HEARING.nearTicks&&p<n?{accent:pulses.has(levelOf(inBar(p)))?0:heard.salience[inBar(p)],busy:busyAt(inBar(p))}:null}:null;
      let busy=0;if(heard)for(let t=0;t<steps;t++)busy+=busyAt(inBar(start+t));
      return {hearAt,room:heard?1-busy/Math.max(1,steps):1,move:Number.isFinite(move)?Math.abs(move):null,recent:this.fills.map(entry=>entry.signature).filter(Boolean)};
    }
    // The draws for the fill into `join` (its count, its figure): a stream of their own for that join, so the fill is the
    // same however many strokes the groove before it drew.
    // Where it stands between groove and fill at a tick of the bar (settings.fillness, its bars counted from 1), or null.
    fillnessOf(clock,tickInBar=clock?.tickInBar??0){
      if(!clock?.meter)return null;
      // A solo the band's attention gives it (ManageBOT's /broadcast/attention: shared/attention.js): its own course over
      // that section, its arc read from the section's progress.
      if(this.fillness===null){
        const heard=this.attentionAt?.(Number(clock.bar)||0);
        if(!heard?.soloing)return null;
        const atBar=this.attentionSaid?.findLast(entry=>entry.atBar<=(Number(clock.bar)||0))?.atBar??0;
        if(this.attentionSolo?.atBar!==atBar)this.attentionSolo={atBar,course:soloCourse(this.fillRandom(`attention-solo:${atBar}`),
          {intensityAt:bar=>soloArc(this.attentionAt?.(bar-1)?.progress??0),mostBars:SOLO_ARC_BARS/6})};
        return this.attentionSolo.course.at((Number(clock.bar)||0)+1+tickInBar/clock.meter.pulsesPerBar);
      }
      const position=(Number(clock.bar)||0)+1+tickInBar/clock.meter.pulsesPerBar;
      if(this.fillness==='solo'){
        // (Its sections are drawn as it reaches them, their arc read at the clock now.)
        this.soloClock=clock;
        this.solo??=soloCourse(this.fillRandom('solo'),{intensityAt:bar=>soloArc(this.soloShare(bar,this.soloClock)),mostBars:()=>this.soloMostBars(this.soloClock)});
        return this.solo.at(position);
      }
      return fillnessAt(this.fillness,position);
    }
    blendBeatStarts(clock){return feltBeats(clock.meter,{secondsPerTick:secondsPerTick(clock)}).map(beat=>beat.start)}
    // How far through its solo a bar position is (bars from 1), from where the render ends (audio.renderEnd): in bars or
    // ticks, by the bar; in seconds, by the seconds its clock has run, tempo changes and all (so the arc's shares are
    // taken now, as its sections are drawn). Without an end, an arc of 32 bars again and again (ours). soloBars: the
    // solo's length in bars, for its sections' lengths (in seconds, at the tempo and meter it began in).
    soloShare(bar,clock){
      const end=this.audio?.renderEnd,perBar=clock?.meter?.pulsesPerBar,barSeconds=perBar?perBar*secondsPerTick(clock):null;
      this.soloBars??=end?.bars>0?end.bars:end?.ticks>0&&perBar?end.ticks/perBar:end?.seconds>0&&barSeconds?end.seconds/barSeconds:null;
      if(end?.seconds>0&&Number.isFinite(clock?.tick)){
        // (Counted forward only: a tick seen before adds nothing.)
        if(!(this.soloTick>=clock.tick)){this.soloSeconds=(this.soloSeconds??0)+(this.soloTick===undefined?0:secondsPerTick(clock)*(clock.tick-this.soloTick));this.soloTick=clock.tick}
        return this.soloSeconds/end.seconds;
      }
      return this.soloBars?(bar-1)/this.soloBars:((bar-1)%SOLO_ARC_BARS)/SOLO_ARC_BARS;
    }
    // Its sections no longer than a sixth of its solo, so its arc is heard (ours), and never under two bars: in bars as
    // its end is given in bars or ticks; given in seconds, a sixth of them in bars at the tempo and meter now.
    soloMostBars(clock){
      this.soloShare(1,clock);
      const end=this.audio?.renderEnd,perBar=clock?.meter?.pulsesPerBar,barSeconds=perBar?perBar*secondsPerTick(clock):null;
      const bars=end?.seconds>0&&barSeconds?end.seconds/6/barSeconds:(this.soloBars??SOLO_ARC_BARS)/6;
      return Math.max(2,Math.round(bars));
    }
    // The solo's intensity at a clock (soloArc), or null outside a solo.
    soloIntensity(clock){
      if(this.fillness===null&&clock?.meter){const heard=this.attentionAt?.(Number(clock.bar)||0);return heard?.soloing?soloArc(heard.progress??0):null}
      if(this.fillness!=='solo'||!clock?.meter)return null;
      return soloArc(this.soloShare((Number(clock.bar)||0)+1+(clock.tickInBar??0)/clock.meter.pulsesPerBar,clock));
    }
    // A bar between groove and fill: a fill planned over the bar's felt beats, up the snare or down the toms. Its figure
    // is the last bar's again as often as settings.fillRestate says (the same stream, so the same figure in the same
    // meter), and a new one otherwise.
    blendMark(clock){
      const bar=Number(clock.bar)||0,join=`blend:${bar}`;
      // (A solo's section says its own: soloCourse.)
      const restate=this.fillness==='solo'&&this.solo?this.solo.restateAt(bar+1):this.fillRestate;
      if(this.blendBar!==bar){this.blendBar=bar;this.blendSeed=this.blendSeed!==null&&this.fillRandom(`restate:${bar}`)()<restate?this.blendSeed:join}
      // In a solo, its arc (the user on 42: density, speed and intensity shaping to a climax): the nearer its climax, the
      // more of a fill's tuplets, nesting and grouping against the meter, the faster its hands may go (up to twice), the
      // bigger the move its course makes, and the less a busy fill is played under the groove: fast passages loud.
      const intensity=this.soloIntensity(clock);
      return {fill:this.fillRandom(`${this.blendSeed}:direction`)()<.5?'down':'up',step:clock.tickInBar??0,steps:clock.meter.pulsesPerBar,join,
        seed:this.blendSeed,beats:this.blendBeatStarts(clock).length,blend:true,
        ...(intensity===null?{}:{intensity,move:intensity,speed:1+intensity,
          appetite:Object.freeze({dissonance:SOLO_APPETITE.dissonance*intensity,tuplets:SOLO_APPETITE.tuplets*intensity,nesting:SOLO_APPETITE.nesting*intensity})})};
    }
    // The groove beside a bar between groove and fill: its hand strokes as loud as the fillness leaves them, each by its
    // own threshold (figure-blend.js); its feet's strokes as they are, where the fill's strokes leave the foot free.
    patternBesideBlend(tick,clock){
      const span=clock.meter.pulsesPerBar,at=clock.tickInBar??0,fillness=this.fillnessOf(clock)??0;
      const weight=metricalWeight(at,{beatStarts:this.blendBeatStarts(clock),span}),key=`${this.audio?.seed??0}:${this.seedIdentity??this.strokeName}:groove:${clock.bar}:${at}`;
      this.grooveLevel=kind=>BLEND_FEET.has(kind)?1:blendLevel(strokeThreshold({weight,position:at/span,u:randomAt(key,BLEND_KINDS.indexOf(kind)+1)},{order:this.fillOrder}),fillness,{entering:false});
      try{return this.expression&&this.fillPlan?.limbActions?this.patternBesideFill(tick,clock):this.playPattern(tick,clock)}
      finally{this.grooveLevel=null}
    }
    fillRandom(join){const stream=createRandomStream(`${this.audio?.seed??0}:${this.seedIdentity??this.strokeName}:fill:${join}`);return ()=>stream.next()}
    // A break (FormMarks): the join's beat left silent, the pattern and all. Kept with the fills, for its log and the tests.
    restBeat({join},clock){
      if(this.fills.at(-1)?.join===join)return;
      this.fills.push({join,fill:'break',bar:clock.bar,count:0,offsetDb:0});
      if(this.fills.length>FILLS_KEPT)this.fills.shift();
    }
    // A fill contact's velocity as planned: a figure's stroke at its level under the fill's loudest (fill-figures.js: its
    // course and its role), else its place on the fill's ramp (rising up the snare, falling down the toms); times what
    // its hands' moves about the kit do to it.
    fillVelocity(contact){
      // A grace moves with its stroke about the kit (its level is its own against its stroke's: fillGraces).
      const {fill:direction,navigation,figure}=this.fillPlan,{stroke,k,n}=this.fillStrokeOf(contact),progress=n>1?k/(n-1):1;
      const moved=navigation?.get(stroke.id),excitation=moved?10**(moved.excitationDb/40):1;
      // A grace at its level against its stroke (fill-figures.js fillGraces): never louder than it, never under the
      // fill's lowest (a grace, like a ghost, is soft and still sounds).
      const graceDb=contact.role==='grace'?figure?.graces?.find(grace=>grace.index===k)?.db??0:contact.role==='double'?figure?.doubles?.find(double=>double.index===k)?.db??0:null;
      const levelDb=graceDb===null?figure?.levelsDb[k]:Math.max(FILL_FIGURES.lowestDb,Math.min(figure?.levelsDb[k]??0,(figure?.levelsDb[k]??0)+graceDb));
      if(figure)return softerVelocity(this.fillPlan.topVelocity??HOUSE_VELOCITY.floor+HOUSE_VELOCITY.span,levelDb)*excitation;
      const accent=Math.min(1,FORM_MARKS.fillFrom+FORM_MARKS.fillRise*(direction==='up'?progress:1-progress));
      return (HOUSE_VELOCITY.floor+HOUSE_VELOCITY.span*accent)*excitation;
    }
    // The stroke a fill's contact is (a grace's, the stroke it comes before), its place among the fill's strokes, and how
    // many there are.
    fillStrokeOf(contact){
      const played=this.fillPlan.gesture,strokes=this.fillPlan.strokes??=played.contacts.filter(entry=>!entry.of);
      const stroke=contact.of?played.contacts.find(entry=>entry.id===contact.of)??contact:contact;
      return {stroke,k:strokes.indexOf(stroke),n:strokes.length};
    }
    // Its figure's strokes doubled on another drum (fill-figures.js fillDoubles): each stroke's drum (the snare, or a
    // fill down's tom by its place among the kit's toms: the highest two the drummers' high, the lowest two their floor,
    // those between mid), a double drawn as theirs were on it, its first stroke the other hand's on the other drum a few
    // milliseconds before, as loud. Kept where it falls within the window and its hands can play it with those kept
    // (a full stroke, not a grace), where it sounds (`allows(played)`: drummer.js handsAllow); a tom only where the voice
    // has toms. The plan with them, or as it was.
    doublesOf(chosen,{start,perTick,join,random,allows}){
      if(!this.fillDoubles||chosen.plain||!chosen.figure)return chosen;
      const played=chosen.gesture,strokes=played.contacts.filter(contact=>!contact.of),toms=FORM_MARKS.toms,voiced=this.expression&&typeof this.audio.drum==='function';
      const tomClass=note=>{const place=toms.indexOf(note);return place<0?'tomMid':place<2?'tomHigh':place>=toms.length-2?'tomFloor':'tomMid'};
      const noteOf={tomHigh:toms[0],tomMid:toms[Math.floor(toms.length/2)],tomFloor:toms.at(-1)};
      const register=chosen.toms,actions=chosen.actions??strokeActions(played);
      const drumOf=stroke=>chosen.fill==='down'&&voiced&&register?.length?tomClass(register[Math.round(actions.indexOf(stroke.action)*(register.length-1)/Math.max(1,actions.length-1))]):'snare';
      // Each stroke with its companions (its graces, before it), in order, gathered once.
      const withIt=new Map;for(const contact of played.contacts){const key=contact.of??contact.id;if(!withIt.has(key))withIt.set(key,[]);withIt.get(key).push(contact)}
      const beside=(list)=>{const byIndex=new Map(list.map(double=>[double.index,double])),out=[];
        strokes.forEach((stroke,k)=>{const double=byIndex.get(k);
          if(double)out.push({id:`${stroke.id}:double`,slot:null,at:stroke.at,before:double.seconds,hand:stroke.hand==='R'?'L':'R',action:`${stroke.action}:double`,role:'double',of:stroke.id,
            drum:double.first,...(double.first==='snare'?{}:{note:noteOf[double.first]})});
          for(const contact of withIt.get(stroke.id))out.push(contact)});
        return out};
      const kept=[];
      for(const double of fillDoubles(strokes.map(drumOf),{random})){
        if(double.first!=='snare'&&!voiced)continue;
        if((strokes[double.index].at.toNumber()-start)*perTick-double.seconds<0)continue;
        const list=[...kept,double];if(allows({...played,contacts:beside(list)}))kept.push(double);
      }
      if(!kept.length)return chosen;
      const gesture=Object.freeze({...played,contacts:beside(kept),counts:Object.freeze({...played.counts,contacts:played.contacts.length+kept.length})});
      return {...chosen,gesture,figure:{...chosen.figure,doubles:kept},
        limbActions:phraseActions(gestureActions(gesture,{secondsPerTick:perTick}),{id:`fill:${join}`,until:gesture.start.add(gesture.span).toNumber()*perTick})};
    }
    // Its graces for a figure's strokes (fill-figures.js fillGraces), as many as the drummers' where its hands can play
    // them: each where it was drawn, or else at the nearest of the figure's strokes of its kind (accented or not) where
    // it can be, trying FILL_GRACES.tries of them. Where it falls within the fill's window (`secondsOf(index)`: its
    // stroke's seconds from the window's first tick, where the fill is planned), on a stroke not graced already, and
    // playable with those kept before it where they sound (`playable(list)`: drummer.js handsAllow, in closed form, never
    // the planner). [grace], in order.
    gracesOf(louder,{playable,secondsOf,random}){
      if(!this.fillGraces)return [];
      const kept=[],kind=index=>louder[index];
      for(const grace of fillGraces(louder,{random})){
        const near=[...louder.keys()].filter(index=>kind(index)===kind(grace.index)).sort((a,b)=>Math.abs(a-grace.index)-Math.abs(b-grace.index)||a-b).slice(0,FILL_GRACES.tries);
        for(const index of near){
          const moved={...grace,index};
          if(kept.some(entry=>entry.index===index)||secondsOf(index)-grace.count*grace.seconds<0)continue;
          const list=[...kept,moved].sort((a,b)=>a.index-b.index);
          if(playable(list)){kept.splice(0,kept.length,...list);break}
        }
      }
      return kept;
    }
    // The pattern under a fill, on the limbs the fill leaves free (the performer contract: shared/performers/drummer.js).
    // The fill is a phrase holding each hand it uses from its first contact to its last (phraseActions), so the snare
    // and the hat wait; the kick goes on, as a drummer's foot does. Each hit of the pattern is weighed at its own time
    // against the fill's reservations.
    patternBesideFill(tick,clock){
      if(!this.expression||!this.fillPlan?.limbActions)return undefined;
      const seconds=tick*secondsPerTick(clock),actions=this.fillPlan.limbActions;
      this.limbGate=kind=>{const limb=DRUMMER.pieceLimbs[kind];return !limb||!this.performer.resources.has(limb)||limbFree(actions,limb,seconds)};
      try{return this.playPattern(tick,clock)}finally{this.limbGate=null}
    }
    // Every contact where it is scheduled, checked at the render's boundary (gestures.js ContactLedger): two distinct
    // contacts on one drum landing on one output sample are reported in this.contactCollisions, and both still sound.
    // Where the ensemble's feel places a fill (the rubato report §7.5: "A fill needs its own gesture model"): as it places
    // the fill's first stroke, keeping the fill's own subdivision (a placement, the feel's offsets on the beat, a lean:
    // performed-timing.js performedSeconds), the whole fill alike, so the feel moves none of its strokes against another
    // and its hands play it as they would on time. Seconds; 0 with no feel in force. Placed stroke by stroke, a laid-back
    // snare's heads would land late and its strokes between on time, its rhythm bent and its hands crowded.
    fillPlacement(played,clock,feel,instrument){
      const expression=this.electronic?null:this.expressionInForce?.()??null,first=played.contacts.find(contact=>!contact.of);
      if((!feel&&!expression)||!first||typeof this.performedSeconds!=='function'||!clock?.meter)return 0;
      const perTick=secondsPerTick(clock);
      return this.performedSeconds(clock,feel,instrument,(first.at.toNumber()-clock.tick)*perTick,{ownSubdivision:true,record:false},expression);
    }
    // Where the feel moves a contact of the fill under way anchored `offset` seconds after this tick: the whole fill's
    // placement (fillPlacement), and within it the swing, where the fill swings with the band.
    fillPerformed(offset,clock){
      const plan=this.fillPlan;
      return (plan?.placedSeconds??0)+(plan?.swung?this.swungSeconds?.(clock,this.electronic?null:this.currentFeel?.(clock)??null,offset)??0:0);
    }
    checkContact(contact,offsetSeconds,anchorOffset,target,performed=null){
      const context=this.audio?.ctx,sampleRate=context?.sampleRate;
      if(!(sampleRate>0)||typeof this.audio.eventStart!=='function')return null;
      if(this.contactLedger?.sampleRate!==sampleRate)this.contactLedger=new ContactLedger({sampleRate});
      // Recorded where it sounds: moved by the ensemble's feel as its stroke is (its own subdivision kept, where it keeps it).
      return this.contactLedger.add({id:`${this.fillPlan?.join??'fill'}:${contact.id}`,seconds:this.audio.eventStart(offsetSeconds,{anchorOffset,ownSubdivision:this.fillPlan?.ownSubdivision===true,...(performed===null?{}:{performed})}),target});
    }
    get contactCollisions(){return this.contactLedger?.collisions??[]}
    // A join landed on: its crash, left to ring (an open hat where the voice has no cymbals).
    landing(written){return withScoreTime(this.audio,written,()=>{
      if(typeof this.audio.drum!=='function')this.audio.houseDrum('openHat',FORM_MARKS.crashAccent);
      else if(this.expression)this.audio.drum('crash',FORM_MARKS.crashAccent,{duration:FORM_MARKS.crashSeconds,strike:{stroke:'edge'}});
      else this.audio.drum('ride',FORM_MARKS.crashAccent,{note:CRASH_NOTE,duration:FORM_MARKS.crashSeconds});
    })}
    // Its last stroke (the owner, 2 October 2026: "for the drums, often a cymbal crash ... We must break the bots out of
    // clichés while still allowing them to signify endings"): every ending was the kick with a crash left to ring at
    // 0.95. Now how it lands is drawn once a piece (XDRUM_ENDING): its weight, how hard the last downbeat falls, and its
    // colour, from a crash left to ring, through a ride struck and let go sooner and a hat choked, to no cymbal (the kick
    // with the snare, or alone), each cymbal ringing as long as its colour's share of the longest; every state between.
    finalHit(written){return withScoreTime(this.audio,written,()=>{
      const random=this.fillRandom('ending'),[light,heavy]=XDRUM_ENDING.weight,weight=light+(heavy-light)*random(),colour=random();
      const ring=XDRUM_ENDING.ring[0]+(XDRUM_ENDING.ring[1]-XDRUM_ENDING.ring[0])*colour;
      this.audio.houseDrum('kick',weight);
      if(colour<XDRUM_ENDING.cymbal){if(colour>=XDRUM_ENDING.cymbal/2)this.audio.houseDrum('snare',weight*.9);return}
      const crash=colour>=XDRUM_ENDING.crash;
      if(typeof this.audio.drum!=='function')this.audio.houseDrum(crash?'openHat':'closedHat',weight*.95);
      else if(crash&&this.expression)this.audio.drum('crash',weight*.95,{duration:ring,strike:{stroke:'edge'}});
      else if(crash)this.audio.drum('ride',weight*.95,{note:49,duration:ring});
      else this.audio.drum('ride',weight*.85,{duration:ring});
    })}
    // A bar of sixteen sixteenths (4/4) it plays as ae_xDrumBOT does, its sixteen steps across the bar. Any other bar
    // it plays group by group (playByGroups), each group from the pattern's first step:
    // - a longer bar holds more than one of the pattern, and ae_xDrumBOT stretched its sixteen steps over it all (in
    //   97/4, a step every 3.6 s at 100 bpm; the prime series' report named the drums static);
    // - a shorter one squeezed the sixteen steps into fewer sixteenths, its kicks and snares between the groups'
    //   starts. 0f's casting measure found the drummer lost in 7/8 (2+2+3): 21% of its stroke energy on the felt beats,
    //   a metric index of 0.118 against 0.363 in 4/4, and 5/8, 13/16 and 3/4 low too.
    playPattern(tick,clock){
      if(this.groove==='euclidean')return this.playEuclidean(clock);
      const tactus=clock?.meter?tactusOf(clock.meter):null;
      if(!tactus?.compound){
        const grid=sixteenthsOf(clock?.meter);
        if(grid&&grid.perBar!==PATTERN_STEPS)return this.playByGroups(clock,grid);
        // In a feel that re-voices (a swing's own division), the port's steps played here, re-voiced; otherwise as it plays them.
        return this.currentFeel?.(clock)?.revoice?this.playSteps(clock):super.onTick(tick,clock);
      }
      if(!this.enabled||this.exiting)return;
      const tickInBar=clock.tickInBar||0;
      if(tickInBar%tactus.eighthTicks!==0)return;
      const density=Number.isFinite(this.density)?this.density:.5,key=`${tactus.beatsPerBar}:${density>=.6}`;
      if(this.compoundKey!==key){this.compoundKey=key;this.compoundPattern=compoundDrumPattern(tactus.beatsPerBar,density);}
      const eighth=tickInBar/tactus.eighthTicks,pattern=this.compoundPattern,accent=(.35+.65*density)*(eighth%3===0?1:.7);
      // The straight pattern's step memory would skip its first step on the way back to a simple meter.
      this.lastStep=-1;
      withScoreTime(this.audio,scoreTime(clock.tick,tactus.eighthTicks),()=>{
      if(pattern.kick.includes(eighth))this.audio.houseDrum('kick',accent);
      if(pattern.snare.includes(eighth))this.audio.houseDrum('snare',accent);
      if(pattern.hihat.includes(eighth))this.audio.houseDrum('closedHat',accent);
      });
    }
    // The Euclidean groove (settings.groove 'euclidean'): each bar planned as it begins (euclideanBar), from that bar's
    // own stream, so that a bar's groove is the same however the performance came to it; every meter alike, compound
    // ones by their felt beats.
    playEuclidean(clock){
      if(!this.enabled||this.exiting||!clock?.meter)return;
      // The port's step memory, begun again for the way back to it.
      this.lastStep=-1;
      const at=clock.tickInBar||0,key=`${clock.bar}:${clock.meter.label}:${clock.meter.pulsesPerBar}:${clock.bpm}`;
      if(this.grooveKey!==key){
        const stream=createRandomStream(`${this.audio?.seed??0}:${this.seedIdentity??this.strokeName}:groove:${clock.bar}`);
        this.grooveKey=key;this.grooveBar=euclideanBar(clock.meter,{secondsPerTick:secondsPerTick(clock),density:this.density,random:()=>stream.next()});
      }
      const bar=this.grooveBar,kinds=[['kick',bar.kick],['snare',bar.snare],['closedHat',bar.hats]].filter(([,ticks])=>ticks.includes(at)).map(([kind])=>kind);
      if(!kinds.length)return;
      const accent=.35+.65*(Number.isFinite(this.density)?this.density:.5);
      withScoreTime(this.audio,scoreTime(clock.tick,bar.step),()=>{for(const kind of kinds)this.audio.houseDrum(kind,accent)});
    }
    // The pattern's drums at a step: the port's kick, snare and hat, where its step lists hold the step.
    stepDrums(step){return PATTERN_DRUMS.filter(([,part])=>this.patterns[part].includes(step)).map(([kind])=>kind)}
    // The port's sixteen steps across a bar it fits, as its onTick plays them (a step at each sixteenth of the bar, at its
    // accent), re-voiced in the ensemble's feel (revoicedHits): a swing's "a" played with its "and".
    playSteps(clock){
      if(!this.enabled||this.exiting)return;
      const pulses=Math.max(1,clock.meter.pulsesPerBar),step=Math.min(PATTERN_STEPS-1,Math.floor((clock.tickInBar||0)/pulses*PATTERN_STEPS));
      if(step===this.lastStep)return;
      this.lastStep=step;
      const accent=.35+.65*this.density,stepTicks=value=>value*pulses/PATTERN_STEPS;
      // Revoicing explicitly rewrites/merges the pattern. Its resulting cell precedes the physical swing warp.
      withScoreTime(this.audio,dividedInterval(clock.tick-clock.tickInBar,pulses,PATTERN_STEPS,step),()=>{
      for(const kind of revoicedHits(this.currentFeel(clock),step,{hitsAt:value=>this.stepDrums(value),phaseOf:value=>this.feelPhase(stepTicks(value)),steps:PATTERN_STEPS}))
        this.audio.houseDrum(kind,accent);
      });
    }
    // The pattern in sixteenths at the tempo, from its first step at each group's start (the bar's groups, or the ones
    // this part hears the home bars in: grouping-choice.js), cycling through a group longer than itself; each hit at
    // ae_xDrumBOT's accent, re-voiced in the ensemble's feel. So a long bar keeps its time, and the drums say where each
    // group begins.
    playByGroups(clock,grid){
      if(!this.enabled||this.exiting)return;
      const tickInBar=clock.tickInBar||0;
      if(tickInBar%grid.perSixteenth!==0)return;
      // The straight pattern's step memory would skip its first step on the way back to a bar it fits.
      this.lastStep=-1;
      const within=Math.floor((tickInBar%clock.meter.subdivision)/grid.perSixteenth),step=((clock.groupBeat??0)*grid.perBeat+within)%PATTERN_STEPS;
      const accent=.35+.65*(Number.isFinite(this.density)?this.density:.5);
      // The step after this one is the next sixteenth of the bar.
      const hits=revoicedHits(this.currentFeel?.(clock),step,{hitsAt:value=>this.stepDrums(value),steps:PATTERN_STEPS,
        phaseOf:value=>this.feelPhase?.(tickInBar+((value-step+PATTERN_STEPS)%PATTERN_STEPS)*grid.perSixteenth)??null});
      withScoreTime(this.audio,scoreTime(clock.tick,grid.perSixteenth),()=>{
        for(const kind of hits)this.audio.houseDrum(kind,accent);
      });
    }
  }
  return XDrumClodbot;
}
// A meter's sixteenth grid: {perBeat: sixteenths in a notated beat, perSixteenth: pulses in one, perBar: sixteenths in
// the bar}, or null where its pulses do not fall on sixteenths (triplet pulses).
function sixteenthsOf(meter){
  const denominator=Number(meter?.denominator),subdivision=Number(meter?.subdivision),numerator=Number(meter?.numerator);
  if(!(denominator>0&&subdivision>0&&numerator>0)||16%denominator!==0)return null;
  const perBeat=16/denominator,perSixteenth=subdivision/perBeat;
  return Number.isInteger(perSixteenth)&&perSixteenth>0?{perBeat,perSixteenth,perBar:numerator*perBeat}:null;
}
export function defineXdrumClodbot(XDrumBot){
  // Under a home (meterform_clodbot), it hears the home bars in a grouping of its own (bots/lib/modules/grouping-choice.js).
  // Played in the ensemble's feel, where one is set (the performance layer: docs/PERFORMANCE_TIMING.md).
  // It hears the band's attention (HearsAttention: its allowance, and a solo given it).
  const XDrumClodbot=HearsAttention(PerformedTiming(GroupingChoice(xdrumClodbotClass(XDrumBot),{role:'drums'})));
  return defineBot({
      id: "xdrum_clodbot", name: "xdrum_clodbot", status: "native", source: "clodbot",
      category: "beat", midiChannel: 10, outputModes: ["synth", "samples", "midi"], sampleBank: "xDrum",
      pitchContract: "fixed-percussion",
      // The settings a render spec may give it (shared/spec-settings.js), each as described above.
      specSettings: Object.freeze(["groove", "expression", "navigation", "formMarks", "fillLoudness", "fillFigures", "fillPhrases", "fillBeats", "fillExtremes", "fillContinuity", "fillKicks", "fillGraces", "inspiration", "fillDoubles", "holdAnswer", "fillness", "fillOrder", "fillRestate"]),
      description:
        "A fork of ae_xDrumBOT (a clodbot) that, with groove 'euclidean', plays each bar's kick, snare and hats as Euclidean lines on the meter's grids, the snare interlocked with the kick and the kick syncopated and resolved in the Groove MIDI drummers' share of bars; it also plays compound meters (6/8, 9/8, 12/8) in their own triplet eighths, plays any bar but one of 4/4 group by group in sixteenths (7/8 as 2+2+3, 5/4, 13/16, a long prime home), where ae_xDrumBOT stretched or squeezed its sixteen steps over the whole bar, and strikes as drummers do: accents by the beat, ghost notes, rimshots on hard backbeats, the hat's shank and tip and an open hat closed by the next stroke; its kick and snare tuned to the harmony it hears (the snare only to its nearest note, a semitone at most); in a bar of 4/4 its patterns are ae_xDrumBOT's. It marks the form's joins as a band's drummer does: a fill up the snare into more tension or a return, landed on a crash; a fill down the toms into less; each fitted to the edits a mixbot announces there.",
    },(...args)=>new XDrumClodbot(...args));
}
