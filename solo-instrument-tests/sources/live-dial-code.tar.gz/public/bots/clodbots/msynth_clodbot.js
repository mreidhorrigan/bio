// msynth_clodbot: a fork of ae_MSynthBOT that places its phrases' notes in the transport's own beats (the mathematical audit's B04,
// ../lib/quarter-tempo.js). The port reads the transport's tempo as quarter notes; in 7/8 a phrase takes its bars, where
// the port's took half the time, and in 3/2 it no longer takes twice. The port's code is untouched: onTick is the port's
// own, given its clock with the tempo in quarter notes (it reads the tempo for nothing else). In a meter of quarters its
// timing is exactly ae_MSynthBOT's. Made from the class it forks, which agents.js holds, by a function (no import cycle).
//
// And its phrases may rest (the audit's B03; ../lib/phrase-activity.js): each plays with the port's own chance of a
// phrase playing, halved after a rest, and the form never rests throughout. The port's form helper made every phrase
// play, so its configured chance did nothing; in 4/4 this is the one thing it does differently.
// As registered, its calls wait for the pulse they fall in (../lib/pulse-release.js; the audit's T01), so a tempo curve
// keeps its notes on the beat; its class here is the fork without that (the twin tests' subject).
import {defineBot} from '../../framework/index.js';
import {quarterNoteClock} from '../lib/quarter-tempo.js';
import {releasedInPulse} from '../lib/pulse-release.js';
import {phraseActivity} from '../lib/phrase-activity.js';

// What the fork changes but its timing (B03): the form, the port's own (its phrase count, and what it resets), with its
// phrases' activity drawn as the port meant.
export function msynthCorrections(MSynthBot){
  return class extends MSynthBot {
    generateForm(){super.generateForm();this.form=phraseActivity(this.form.length,this.config.activePhraseProbability)}
    formOfLength(count){return phraseActivity(count,this.config.activePhraseProbability)}
  };
}
// The fork: those corrections, told the tempo in quarter notes (B04).
export function msynthClodbotClass(MSynthBot){
  return class MSynthClodbot extends msynthCorrections(MSynthBot) {
    onTick(tick,clock){return super.onTick(tick,quarterNoteClock(clock))}
  };
}
export function defineMsynthClodbot(MSynthBot){
  const MSynthClodbot=releasedInPulse(msynthClodbotClass(MSynthBot));
  return defineBot({
      id:'msynth_clodbot',name:'msynth_clodbot',status:'native',source:'clodbot',forkOf:'msynth',category:'melody',midiChannel:8,outputModes:['synth', 'midi'],pitchContract:'floating-mpe',
      description:"A fork of ae_MSynthBOT that places its phrases' notes in the transport's own beats (the mathematical audit's B04): in 7/8 a phrase takes its bars, where the port's took half the time, and in 3/2 it no longer takes twice. At a steady tempo in a meter of quarters it plays as ae_MSynthBOT does, but that its phrases may rest, with the port's own chance of a phrase playing, which the port's form never let happen (B03). Under a tempo curve its notes stay on the beat: each waits for the pulse it falls in and is placed at that pulse's tempo (T01).",
    },(...args)=>new MSynthClodbot(...args));
}
