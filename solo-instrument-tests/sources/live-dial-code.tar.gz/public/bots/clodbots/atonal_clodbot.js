// atonal_clodbot: a fork of harris_clodbot that comps free-atonal and serial harmony (docs/PITCH_LANGUAGES.md, "Inside the rule
// packages"; research/MUSEBOTS_ALTERNATIVE_TONAL_SYSTEMS_AND_RUDIMENTAL_DRUMMING.md §9). harris_clodbot keeps its scale of
// chords; this fork plays the cells of a motive graph, or the segments of a serial row, as chords, from a rule package
// compiled from them (harmonic-systems/grammar-sources.js) and planned, validated and tuned by the same core, struck on
// the felt beats of any meter as its parent strikes them.
//
// Free atonality is not an absence of structure (§9.1): the motive language develops one cell -- transposed so that it
// overlaps itself, widened, inverted, returned -- and moves between the cells its derivations and phrase connect. The row
// language sounds a row's forms segment by segment, in order, statement after statement, over any number of classes of
// any period (twelve is one case; seven of 31 another). It never guesses a key: the root it hears is only where its
// classes are counted from.
//
// Each note it sounds says where its pitch came from, into notes.jsonl (pitchLanguage): a row member's form, segment,
// position in the prime and statement (P12), a motive note's cell, operator, indices and derivation (P14). Its language
// 'one-off' is the listening test's control (I08): cells of the cell's size drawn at random, none recurring.
import {defineBot} from '../../framework/index.js';
import {HarrisClodbot} from './harris_clodbot.js';
import {generate} from '../../shared/harmonic-systems/generator.js';
import {realize} from '../../shared/harmonic-systems/realization.js';
import {rowPackage,motivePackage,noteSource,OCTAVE} from '../../shared/harmonic-systems/grammar-sources.js';
import {FIXTURE_ROW_12} from '../../shared/pitch-languages/rows.js';
import {motiveGraph,introduce,derive} from '../../shared/pitch-languages/motives.js';
import {strikeWith,languageOf} from '../lib/note-language.js';
import {unitRandom} from '../../shared/stochastic.js';

// ---- Choices ---------------------------------------------------------------------------------------------------
const CENTS_PER_STEP=100;
// The frame its classes are counted in: the root heard, in this octave (C3), or C where it hears none.
export const ATONAL_REFERENCE_CENTS=4800;
// The motive language's cell (the report's {0, 1, 4}, §9.2) and its development: the cell; transposed by its span, so
// that it begins where the cell ends; widened (its intervals doubled); inverted about its first note; and the phrase
// that returns to it.
export const ATONAL_CELL=Object.freeze({pitches:Object.freeze([0,1,4]),steps:12});
// The row language's defaults: the report's fixture row (§9.5), four forms, in trichords.
export const ATONAL_ROW=Object.freeze({row:FIXTURE_ROW_12,steps:12,forms:Object.freeze(['P0','I5','R3','RI8']),partition:null});

// The motive graph of a cell: its development and the phrase through it.
export function cellGraph({pitches,steps}){
  const span=pitches.at(-1)-pitches[0];
  let graph=motiveGraph();
  graph=introduce(graph,{pitches,steps},{id:'cell'});
  graph=derive(graph,'cell','transpose',{by:span||1},{id:'overlap'});
  graph=derive(graph,'cell','expand',{factor:2},{id:'wide'});
  graph=derive(graph,'cell','invert',{},{id:'inverted'});
  return {graph,phrase:['cell','overlap','wide','inverted','cell']};
}
// The report's control for its motive language (I08: "one-off free-atonal chromatic noise"): cells of the same size
// drawn at random from the chromatic classes, each introduced once and never derived from, recurring, or returned to,
// in a phrase that visits each in turn (sixty-four of them, a package's most contexts, before the cycle comes round: longer
// than a listening excerpt). Its chords are voiced, struck and tuned exactly as the motive language's are.
export function oneOffGraph({size=3,steps=12,count=64,random=unitRandom}={}){
  let graph=motiveGraph();const phrase=[];
  for(let index=0;index<count;index++){
    const pool=[...Array(steps).keys()],pitches=[];
    while(pitches.length<Math.min(size,steps))pitches.push(pool.splice(Math.floor(random()*pool.length),1)[0]);
    graph=introduce(graph,{pitches,steps},{id:`o${index}`});phrase.push(`o${index}`);
  }
  return {graph,phrase:[...phrase,phrase[0]]};
}
// The package a bot's settings ask for, and what its contexts stand for. A render spec gives lists as words (its settings
// are short strings: row '0 5 10 13 18 23 26', forms 'P0 I8', partition '4 3', cell '0 1 4'); code may give arrays.
const words=(value,parse=Number)=>typeof value==='string'?value.trim().split(/[\s,]+/).filter(Boolean).map(parse):value;
export function atonalLanguage(settings={}){
  if((settings.language??'motive')==='row'){
    const row=words(settings.row)??ATONAL_ROW.row,steps=settings.steps??(settings.row?row.length:ATONAL_ROW.steps);
    return rowPackage({id:'atonal-row',row,steps,complete:settings.complete??row.length===steps,forms:words(settings.forms,String)??ATONAL_ROW.forms,
      partition:words(settings.partition)??null,period:settings.period??OCTAVE});
  }
  const cell=words(settings.cell)??ATONAL_CELL.pitches,steps=settings.steps??ATONAL_CELL.steps;
  if(settings.language==='one-off'){const {graph,phrase}=oneOffGraph({size:cell.length,steps});return motivePackage({id:'atonal-one-off',graph,phrase,period:settings.period??OCTAVE})}
  const {graph,phrase}=cellGraph({pitches:cell,steps});
  return motivePackage({id:'atonal-motives',graph,phrase,period:settings.period??OCTAVE});
}

export class AtonalClodbot extends HarrisClodbot {
  constructor(send,audio,settings={}){
    super(send,audio,settings);
    const {package:pkg,source}=atonalLanguage(settings);
    this.language={pkg,source,statement:0,plan:null,at:0,played:null};
  }
  // Where the notes it is striking came from, for notes.jsonl (../lib/note-language.js).
  noteLanguage(note){return languageOf(this.pendingLanguage,note)}
  // It begins on a beat whether or not it hears a chord (its parent waits for one).
  everyTick(clock){if(!this.voicing&&clock.beatStart&&this.closing?.phase!=='final'&&this.closing?.phase!=='after')this.attack(clock,{change:true})}
  attack(clock,{change}){
    const language=this.language;
    // A new root heard is a new frame: the plan is made again from there, the grammar carried on.
    if(change&&language.played&&language.root!==(this.chord?.root??this.bandOpening.root))language.plan=null;
    if(!language.plan||language.at>=language.plan.length)language.plan=this.planLanguage(clock),language.at=0,language.root=this.chord?.root??this.bandOpening.root;
    if(!language.plan)return;
    const step=language.plan[language.at++],previous=language.played;
    // A row's statement is counted where its order comes round to its first segment again.
    if(previous&&language.source.kind==='row'&&step.context===language.pkg.contexts[0].id&&previous.context!==step.context)language.statement++;
    language.played=step;
    const notes=step.voicing.filter(note=>Number.isFinite(note.tunedCents)),pitches=notes.map(note=>+(note.tunedCents/CENTS_PER_STEP).toFixed(4));
    const spt=this.secondsPerTick(clock),beat=this.felt(clock).find(item=>clock.tickInBar>=item.start&&clock.tickInBar<item.start+item.length),offbeat=clock.tickInBar!==beat.start;
    const seconds=(offbeat?.6:1.4)*beat.length*spt;
    // (Written to its next strike in the comp, as jazzvoicing_clodbot's chords are; in the final bar, to the end.)
    const nextStrike=this.compAt(clock)?.hits.find(at=>at>clock.tickInBar)??null,span=(nextStrike??this.barTicks(clock))-clock.tickInBar;
    strikeWith(this,notes.map((note,index)=>({pitch:pitches[index],language:{...noteSource(language.source,step,note),
      ...(language.source.kind==='row'?{statement:language.statement}:{})}})),()=>this.sound(clock,pitches,seconds,this.vl.velocity-(offbeat?.02:.06),this.writtenInterval(clock,span)));
    this.announce(clock,pitches);this.voicing=notes.map(note=>note.cents/CENTS_PER_STEP);
    this.decide({tick:clock.tick,package:`${language.pkg.id}@${language.pkg.version}`,context:step.context,structure:step.structure,pitches,
      roles:notes.map(note=>note.role),...(language.source.kind==='row'?{statement:language.statement}:{})});
  }
  // The next few steps of the language, as many as the bar has felt beats, continued from the chord last struck (every
  // context may begin a plan: a plan is a window of the grammar, and the next one carries on where it left off), led from
  // the voicing sounding, voiced over the bass heard, tuned.
  planLanguage(clock){
    const {pkg,played}=this.language,voices=this.harrisVoices(clock),steps=Math.max(1,this.felt(clock).length);
    const tonicCents=ATONAL_REFERENCE_CENTS+CENTS_PER_STEP*(this.chord?.root??this.bandOpening.root);
    const pitchesOf=step=>Object.fromEntries(step.voicing.map(note=>[note.voice,note.cents]));
    let outcome=played?generate(pkg,{start:{context:played.context,structure:played.structure,pitches:pitchesOf(played)},steps,voices,tonicCents}):null;
    const continued=outcome?.status==='validated';
    if(!continued){
      const after=this.voicing?.length===voices.length?Object.fromEntries(voices.map((voice,index)=>[voice.id,this.voicing[index]*CENTS_PER_STEP])):null;
      outcome=generate(pkg,{start:{context:played?.context??pkg.start[0],...(after?{after}:{})},steps:steps-1,voices,tonicCents});
    }
    if(outcome.status!=='validated'){this.decide({tick:clock.tick,atonal:outcome.status,reason:outcome.reason??outcome.detail??null,explanations:outcome.explanations?.slice(0,3)});return null}
    const result=realize(pkg,outcome.plan);
    if(result.status!=='validated'){this.decide({tick:clock.tick,atonal:'untuned',tuning:result.status});return null}
    // A continuing plan's first step is the chord already sounding.
    return continued?result.plan.slice(1):result.plan;
  }
}

export const atonalClodbot=defineBot(
  {
    id:'atonal_clodbot',name:'atonal_clodbot',status:'native',source:'clodbot',forkOf:'harris_clodbot',
    category:'harmony',midiChannel:13,performanceType:'polyphonic',outputModes:['synth','midi'],
    pitchContract:'floating-mpe',nativeTuning:true,
    // The settings a render spec may give it (spec-settings.js): its language and the material it compiles.
    specSettings:Object.freeze(['language','row','steps','complete','forms','partition','cell']),
    description:'A fork of harris_clodbot that comps free-atonal and serial harmony: the cells of a motive graph (one cell developed, transposed, widened, inverted and returned) or the segments of a serial row over any number of classes, as chords planned, validated and tuned by the harmonic-systems core, struck on the felt beats of any meter; each note logs its row position or its derivation.',
  },
  (...args)=>new AtonalClodbot(...args),
);
