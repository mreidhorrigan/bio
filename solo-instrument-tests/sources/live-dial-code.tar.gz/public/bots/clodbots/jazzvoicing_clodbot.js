// jazzvoicing_clodbot: rootless jazz voicings comped in a jazz rhythm (the shared core: ../lib/voice-leading-bot.js).
import {defineBot} from '../../framework/index.js';
import {unitRandom} from '../../shared/stochastic.js';
import {leadVoices,tendencyTones,pitchClassOf} from '../../shared/voice-leading.js';
import {colourChord} from '../../shared/harmonic-spaces.js';
import {modulo,near,has,chordTones,fractional,VoiceLeadingBot} from '../lib/voice-leading-bot.js';
import {PerformedTiming} from '../lib/modules/performed-timing.js';
import {jazzChord} from '../../shared/performers/chord-readings.js';

// Jazz's seventh chord, the jazz player's reading of a chord (chord-readings.js, where every player's readings are).
export {jazzChord};
export class JazzVoicingClodbot extends VoiceLeadingBot {
  // voicingSpan: the most semitones a voicing spans (its own; an instrument's hand may take less: piano_clodbot).
  constructor(send,audio,settings={}){super(send,audio,{style:'jazz',velocity:.46,dissonance:.5,intonation:'equal',returns:.3,contourWeight:.7,...settings});this.comp=null;this.voicingSpan=15}
  // Comping: a pattern a bar (positions in beats), chosen afresh each bar; busier as the density rises.
  rearticulates(clock){
    const beat=this.beatTicks(clock),beats=this.barTicks(clock)/beat;
    if(this.comp?.bar!==clock.bar){const patterns=beats===4?[[0,1.5],[0,2.5],[1.5,3],[0,2],[0,1.5,3],[.5,2],[2.5]]:[[0],[0,beats/2],[beats>2?1.5:.5]];
      const busy=Math.max(0,Math.min(1,this.density??.5)),choice=Math.min(patterns.length-1,Math.floor(unitRandom()*(2+busy*(patterns.length-2))));
      this.comp={bar:clock.bar,hits:patterns[choice].map(position=>this.beatPosition(clock,position))};}
    return this.comp.hits.includes(clock.tickInBar);
  }
  attack(clock,{change}){
    const chord=this.chord;if(!chord)return;
    const spt=this.secondsPerTick(clock),beat=this.beatTicks(clock),offbeat=clock.tickInBar%beat!==0;
    // (In the final bar as in any, its chord as long as on its beat: its arrival, never held to the stop.)
    const seconds=(offbeat?.6:1.4)*beat*spt;
    const nextStrike=this.compAt(clock)?.hits.find(at=>at>clock.tickInBar)??null;
    const span=(nextStrike??this.barTicks(clock))-clock.tickInBar;
    // (Struck again as the pool now tunes it: a pool retuned under the same chord's name sounds its new tuning.)
    if(!change&&this.voicing){const again=this.intonation()==='equal'?this.tuneChord(this.voicing):this.tuning?.pitches??this.voicing;this.sound(clock,again,seconds,this.vl.velocity-(offbeat?.02:.06),this.writtenInterval(clock,span));this.announce(clock,again);return;}
    // Rootless where the bass heard plays the root, as a pianist leaves it to the bassist who has it; the bass heard on
    // another note (walking, or an inversion's) leaves the root to the chord.
    const jazz=jazzChord(chord,this.scaleFor(chordTones(chord)),this.poolPcs??[]),bass=this.bassHeard(clock),bassPc=bass!==null?pitchClassOf(bass):null;
    const withBass=bassPc!==null&&near(modulo(bassPc-jazz.root+6,12),6);
    // The space its tensions come from: its intended dissonance, varied a little from chord to chord (a player does not
    // voice every dominant alike). Every space holds the root, third and seventh; the fifth may give way (an altered
    // dominant's).
    const {spaces,space}=this.space(clock,[...new Set([...jazz.holding,jazz.fifth])],{holding:jazz.holding,offset:(unitRandom()-.5)*.24});
    const tensions=colourChord(space,jazz.holding,{spaces,root:jazz.root,count:jazz.holding.length+3}).slice(jazz.holding.length);
    const guide=[jazz.third??jazz.suspension,jazz.seventh].filter(pc=>pc!==null);
    let pcs=[...new Set([...guide,...tensions.slice(0,3),...(withBass?[]:[jazz.root]),...(tensions.length<2?[jazz.fifth]:[])])];
    // Four notes want four pitch classes: a narrow space (the chord's own, at a low intended dissonance) gives fewer, and
    // then the fifth and root fill in, doubled where still too few.
    if(pcs.length<4)pcs=[...new Set([...pcs,jazz.fifth,jazz.root])];
    let required=[...guide,...(withBass?[]:[jazz.root])];
    // A harmonic object no chord names keeps its own notes (the root left to the bass heard), before the tensions.
    const object=this.objectVoicing(chordTones(chord),4);
    // A tone the object holds is voiced in the object's own tuning, never beside its name on the grid as well (a fifth
    // of 6.86 and a 7 both required leave no voicing at all).
    if(object){const own=object.pcs.filter(pc=>!(withBass&&near(pc,jazz.root))),tuned=pc=>this.objectTone(pc);
      pcs=[...new Set([...own,...pcs.map(tuned)])].slice(0,Math.max(4,own.length));required=[...new Set([...own,...required.map(tuned)])].slice(0,4);}
    const ranges=this.overBass(clock,[[48,62],[52,66],[55,70],[58,74]]);
    const tendencies=tendencyTones(this.previousChord,chord);
    const previous=this.voicing?.length===ranges.length?this.voicing:null;
    const score=(themeScore=>{const contour=this.contourScore(clock,ranges.at(-1));return themeScore||contour?candidate=>(themeScore?.(candidate)??0)+(contour?.(candidate)??0):null})(this.themeScore(clock,1));
    // (An instrument's player hears the chord every way chord-readings.js reads one -- as heard, common practice's,
    // jazz's with the tensions its space gives as a colourist's, a power chord's -- each led from its last voicing, the
    // cheapest with its reading's cost to its taste: never a jazz pianist's alone. This bot, the jazz voice leader, is
    // that one reading.)
    if(typeof this.readingsOf==='function'){
      let best=null;
      // (Its tones on the grid, as this voice leader voices them, tuned as it sounds them -- and again as the pool tunes
      // them, struck again under a pool retuned.)
      for(const reading of this.readingsOf(clock,{bass:withBass,colours:tensions.slice(0,3),tuned:pc=>pc})){
        const tones=reading.pcs.length<4?[...new Set([...reading.pcs,...[reading.roles.fifth,...(withBass?[]:[reading.roles.root])].filter(pc=>pc!==null&&pc!==undefined)])]:reading.pcs;
        const led=leadVoices(previous,tones,{voices:4,ranges,required:reading.required.slice(0,4),maxDoubling:tones.length<4?2:1,style:reading.id==='jazz'||reading.id==='colour'?'jazz':'common-practice',...this.others(clock),tendencies,
          roles:{third:reading.roles.third,seventh:reading.roles.seventh,...(bassPc!==null?{bass:bassPc}:{})},maxStep:7,maxSpan:this.voicingSpan,score});
        if(led&&(!best||led.cost+reading.cost<best.cost+best.reading.cost))best={...led,reading};
      }
      if(!best)return;
      const tuned=this.tuneChord(best.voicing);
      this.sound(clock,tuned,seconds,this.vl.velocity,this.writtenInterval(clock,span));this.announce(clock,tuned);this.voicing=best.voicing;this.lastReading=best.reading.id;
      this.decide({tick:clock.tick,change:true,chord:`${chord.root}:${chord.quality}`,reading:best.reading.id,voicing:best.voicing,rootless:withBass,space:space.id,mode:space.mode,cost:+best.cost.toFixed(2)});
      return;
    }
    const next=leadVoices(previous,pcs,{voices:4,ranges,required,maxDoubling:pcs.length<4?2:1,style:'jazz',...this.others(clock),tendencies,roles:{third:jazz.third,seventh:jazz.seventh,...(bassPc!==null?{bass:bassPc}:{})},maxStep:7,maxSpan:this.voicingSpan,
      score});
    if(!next)return;
    const tuned=this.tuneChord(next.voicing);
    this.sound(clock,tuned,seconds,this.vl.velocity,this.writtenInterval(clock,span));this.announce(clock,tuned);this.voicing=next.voicing;
    this.decide({tick:clock.tick,change:true,chord:`${chord.root}:${chord.quality}`,voicing:next.voicing,rootless:withBass,space:space.id,mode:space.mode,cost:+next.cost.toFixed(2)});
  }
}

export const jazzvoicingClodbot=defineBot(
  {
    id: "jazzvoicing_clodbot", name: "jazzvoicing_clodbot", status: "native", source: "clodbot",
    category: "harmony", midiChannel: 13, performanceType: "polyphonic", outputModes: ["synth", "midi"],
    pitchContract: "floating-mpe",
    description:
      "Jazz comping following note pools and chord plans: rootless four-note voicings of the third, seventh and the tensions of the space its intended dissonance chooses (altered dominants when it is high), led smoothly by guide tones, the root left to the bass it hears.",
  },
  // Comping in the ensemble's feel, where one is set (the performance layer: docs/PERFORMANCE_TIMING.md).
  (...args) => new PerformedJazzVoicing(...args),
);
export const PerformedJazzVoicing=PerformedTiming(JazzVoicingClodbot,{instrument:'comping'});
