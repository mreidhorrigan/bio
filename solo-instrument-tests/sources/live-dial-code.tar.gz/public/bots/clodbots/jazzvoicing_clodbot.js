// jazzvoicing_clodbot: the voice leader (../lib/voice-leader.js) standing at the jazz location of the voice leaders'
// style space (../../shared/voice-leader-space.js): rootless four-note voicings, the third and seventh with three
// tensions from the space its intended dissonance chooses (altered dominants when it is high), a triad heard as its key's
// seventh chord, led smoothly within an octave and a fourth, the root left to the bass it hears; comped in every meter by
// one rule, struck short, in equal temperament. The instruments that comp (piano_clodbot, guitar_clodbot and the others)
// are players built on it, each hearing a chord every way chord-readings.js reads one, to its own taste.
import {defineBot} from '../../framework/index.js';
import {VoiceLeader} from '../lib/voice-leader.js';
import {PerformedTiming} from '../lib/modules/performed-timing.js';
import {jazzChord} from '../../shared/performers/chord-readings.js';

// Jazz's seventh chord, the jazz player's reading of a chord (chord-readings.js, where every player's readings are).
export {jazzChord};
export class JazzVoicingClodbot extends VoiceLeader {
  // voicingSpan (unset here): the most semitones a voicing spans where an instrument's hand takes less than the
  // location's span (piano_clodbot).
  constructor(send,audio,settings={}){super(send,audio,{style:'jazz',location:'jazz',...settings})}
}

export const jazzvoicingClodbot=defineBot(
  {
    id: "jazzvoicing_clodbot", name: "jazzvoicing_clodbot", status: "native", source: "clodbot",
    category: "harmony", midiChannel: 13, performanceType: "polyphonic", outputModes: ["synth", "midi"],
    pitchContract: "floating-mpe",
    description:
      "Jazz comping following note pools and chord plans: rootless four-note voicings of the third, seventh and the tensions of the space its intended dissonance chooses (altered dominants when it is high), led smoothly by guide tones, the root left to the bass it hears. The jazz location in the voice leaders' style space, which it shares with romantic_clodbot, impressionist_clodbot and hindemith_clodbot (location).",
  },
  // Comping in the ensemble's feel, where one is set (the performance layer: docs/PERFORMANCE_TIMING.md).
  (...args) => new PerformedJazzVoicing(...args),
);
export const PerformedJazzVoicing=PerformedTiming(JazzVoicingClodbot,{instrument:'comping'});
