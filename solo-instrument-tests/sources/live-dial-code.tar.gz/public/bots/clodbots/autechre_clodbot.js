// autechre_clodbot: a fork of ae_AutechreBOT that lays its patterns across the bar in the transport's own beats (the mathematical audit's B04,
// ../lib/quarter-tempo.js). The port reads the transport's tempo as quarter notes; in 7/8 its hits span the bar, where
// the port's took half the time, and in 3/2 it no longer takes twice. The port's code is untouched: scheduleBar is the port's
// own, given its clock with the tempo in quarter notes (it reads the tempo for nothing else). Made from the class it
// forks, which agents.js holds, by a function (no import cycle).
//
// And it strikes each drum once at an instant (the audit's B06). The port re-quantizes its sixteen-step patterns onto a
// grid that wanders (its drunk subdivision, now and then fewer slots than steps), so two steps can round onto one slot,
// and a step near the bar's end onto the next bar's downbeat. The port strikes both: one drum twice at once, or a hit
// sounding on the next bar's downbeat beside whatever strikes there. The fork hears what the port would strike in the bar,
// and strikes it as a drummer can (strokesOf): hits of one drum on one instant are one stroke, at the strongest of their
// accents; a hit on the bar's end is carried into the next bar's downbeat, one stroke with any there. With its grid the
// source's own sixteen steps nothing collides, and in a meter of quarters it then plays exactly as ae_AutechreBOT.
// As registered, its calls wait for the pulse they fall in (../lib/pulse-release.js; the audit's T01), so a tempo curve
// keeps its notes on the beat; its class here is the fork without that (the twin tests' subject).
import {defineBot} from '../../framework/index.js';
import {quarterNoteClock} from '../lib/quarter-tempo.js';
import {releasedInPulse} from '../lib/pulse-release.js';
import {bandTempo} from '../../shared/opening-time.js';
import {withScoreTime} from '../../shared/score-time.js';

// Two hits nearer than this (seconds) are on one instant.
const SAME_INSTANT=1e-9;

// The strokes of a bar's hits ({voice, accent, effects, offset: seconds from the bar's start}), and those carried from the
// bar before (struck at 0): one stroke a drum an instant, at the strongest accent; a hit at or past the bar's end
// (`barSeconds`) carried to the next bar's downbeat. Returns {strokes, carried}, each in the order first heard.
export function strokesOf(hits,{barSeconds,carried=[]}){
  const strokes=[],next=[];
  const strike=(list,hit,offset)=>{
    const same=list.find(stroke=>stroke.voice===hit.voice&&Math.abs(stroke.offset-offset)<=SAME_INSTANT);
    if(!same)list.push({...hit,offset});
    else if(hit.accent>same.accent)Object.assign(same,{accent:hit.accent,effects:hit.effects});
  };
  for(const hit of carried)strike(strokes,hit,0);
  for(const hit of hits){
    if(hit.offset>=barSeconds-SAME_INSTANT)strike(next,hit,0);
    else strike(strokes,hit,hit.offset);
  }
  return {strokes,carried:next};
}

// What the fork changes but its timing (B06): what the port would strike in the bar, heard before it sounds, and struck
// as a drummer can, on the clock it is given.
export function autechreCorrections(AutechreBot){
  return class extends AutechreBot {
    scheduleBar(clock){
      const audio=this.audio,hits=[];
      this.audio=new Proxy(audio,{get:(target,name)=>name==='autechreDrum'
        ?(voice,accent,effects,offset)=>{hits.push({voice,accent,effects,offset,...(audio.scoreTime&&typeof audio.scoreTime==='object'?{written:{scoreTime:audio.scoreTime,scoreId:audio.scoreId}}:{})})}
        :typeof target[name]==='function'?target[name].bind(target):target[name]});
      try{super.scheduleBar(clock)}finally{this.audio=audio}
      // The port's own bar length, as it computed it for these hits.
      const barSeconds=((60/(clock?.bpm||bandTempo()))*clock.meter.numerator*4)/clock.meter.denominator;
      const {strokes,carried}=strokesOf(hits,{barSeconds,carried:this.carriedStrokes??[]});
      this.carriedStrokes=carried;
      // (Each written as the port wrote it, the carried at the next bar's downbeat, where it fell.)
      for(const {voice,accent,effects,offset,written} of strokes){const strike=()=>audio.autechreDrum(voice,accent,effects,offset);if(written)withScoreTime(audio,written,strike);else strike()}
    }
  };
}
// The fork: those corrections, told the tempo in quarter notes (B04).
export function autechreClodbotClass(AutechreBot){
  return class AutechreClodbot extends autechreCorrections(AutechreBot) {
    scheduleBar(clock){return super.scheduleBar(quarterNoteClock(clock))}
  };
}
export function defineAutechreClodbot(AutechreBot){
  const AutechreClodbot=releasedInPulse(autechreClodbotClass(AutechreBot));
  return defineBot({
      id:'autechre_clodbot',name:'autechre_clodbot',status:'native',source:'clodbot',forkOf:'autechre',category:'beat',midiChannel:10,outputModes:['synth', 'midi'],pitchContract:'fixed-percussion',
      description:"A fork of ae_AutechreBOT that lays its patterns across the bar in the transport's own beats (the mathematical audit's B04): in 7/8 its hits span the bar, where the port's took half the time, and in 3/2 it no longer takes twice. And it strikes each drum once at an instant: steps its wandering grid rounds onto one slot are one stroke, and a step rounded onto the bar's end is struck on the next bar's downbeat, once (B06). Under a tempo curve its notes stay on the beat: each waits for the pulse it falls in and is placed at that pulse's tempo (T01).",
    },(...args)=>new AutechreClodbot(...args));
}
