// impressionist_clodbot: the voice leader (../lib/voice-leader.js) standing at the impressionist location of the voice
// leaders' style space (../../shared/voice-leader-space.js): colour chords from its space, every note sounded, moved in
// parallel and planed a step and back, in the harmonic series. One voice leader at many locations: what it does and
// what romantic_clodbot does are the same choices read at different points.
import {defineBot} from '../../framework/index.js';
import {RomanticClodbot} from './romantic_clodbot.js';

export class ImpressionistClodbot extends RomanticClodbot {
  constructor(send,audio,settings={}){super(send,audio,{style:'impressionist',location:'impressionist',...settings})}
}

export const impressionistClodbot=defineBot(
  {
    id: "impressionist_clodbot", name: "impressionist_clodbot", status: "native", source: "clodbot", nativeTuning: true,
    category: "harmony", midiChannel: 12, performanceType: "polyphonic", outputModes: ["synth", "midi"],
    pitchContract: "floating-mpe",
    description:
      "Impressionist colour chords following note pools and chord plans, in harmonic-series intonation: the notes that make its space what it is (the sharp eleventh of lydian, the ninth and sixth of a pentatonic) moved in parallel (planing), and planed a step within the space and back between changes. The impressionist location in the voice leaders' style space, which it shares with romantic_clodbot (location).",
  },
  (...args) => new ImpressionistClodbot(...args),
);
