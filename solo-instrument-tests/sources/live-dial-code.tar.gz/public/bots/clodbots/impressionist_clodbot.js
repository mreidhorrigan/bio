// impressionist_clodbot: the Romantic bot's impressionist end, always (../lib/voice-leading-bot.js; romantic_clodbot.js).
import {defineBot} from '../../framework/index.js';
import {leadVoices} from '../../shared/voice-leading.js';
import {colourChord} from '../../shared/harmonic-spaces.js';
import {chordTones} from '../lib/voice-leading-bot.js';
import {RomanticClodbot} from './romantic_clodbot.js';

// The impressionist: colour chords from its space, five voices, moved in parallel.
export class ImpressionistClodbot extends RomanticClodbot {
  constructor(send,audio,settings={}){super(send,audio,{style:'impressionist',dissonance:.55,intonation:'harmonic',contourWeight:.5,...settings})}
  blend(){return 1}
  choose(clock){
    const chord=this.chord,tones=chordTones(chord),{spaces,space}=this.space(clock,tones);
    const object=this.objectVoicing(tones,5),pcs=colourChord(space,object?.pcs??tones,{spaces,root:chord.root,count:5});
    const ranges=this.overBass(clock,[[48,64],[53,69],[57,74],[60,79],[64,84]].slice(-Math.max(3,Math.min(5,pcs.length))));
    const previous=this.voicing?.length===ranges.length?this.voicing:null;
    const themeScore=this.themeScore(clock),contour=this.contourScore(clock,ranges.at(-1)),score=themeScore||contour?candidate=>(themeScore?.(candidate)??0)+(contour?.(candidate)??0):null;
    const next=leadVoices(previous,pcs,{voices:ranges.length,ranges,required:pcs,maxDoubling:pcs.length<ranges.length?2:1,style:'impressionist',...this.others(clock),maxStep:12,maxSpan:30,score});
    return next&&{...next,space};
  }
}

export const impressionistClodbot=defineBot(
  {
    id: "impressionist_clodbot", name: "impressionist_clodbot", status: "native", source: "clodbot", nativeTuning: true,
    category: "harmony", midiChannel: 12, performanceType: "polyphonic", outputModes: ["synth", "midi"],
    pitchContract: "floating-mpe",
    description:
      "Impressionist colour chords following note pools and chord plans, in harmonic-series intonation: the notes that make its space what it is (the sharp eleventh of lydian, the ninth and sixth of a pentatonic) moved in parallel (planing), and planed a step within the space and back between changes.",
  },
  (...args) => new ImpressionistClodbot(...args),
);
