// polyscalar_clodbot: two scalar layers at once (docs/PITCH_LANGUAGES.md, "Bots"; the alternative tonal systems report §10.2).
// Two lines, each walking its own collection from its own anchor, in its own register, rhythm and instrument: by default
// the major scale on the root it hears and the major scale a tritone above it (over C, C major and F-sharp major: two
// keys at once, not one twelve-note aggregate). Each layer keeps its own state (pitch-languages/layers.js): its cursor
// through its material, whether it sounds. The upper layer falls silent for a bar now and then and resumes where it was,
// not from the start (P16). Neither layer is re-quantized into the other's rhythm: the lower walks the felt beats, the
// upper a cycle of three ticks across them.
//
// Any division of any period: `steps` classes to the octave, the scale given in them (settings: steps 31, scale
// '0 5 10 13 18 23 28', offset 15). With `shimmer` (a beat in Hz), each note of the upper layer sounds as a beating
// pair about its pitch, as a gamelan's paired instruments do (pitch-languages/texture.js beatingPair: the geometric-
// centre fixture, not a measured tuning): two notes a few Hz apart, never a unison. Each note says which layer,
// collection, anchor and position it is into notes.jsonl (and a pair's member and beat), and every bar its decisions keep
// both analyses, each layer's and the aggregate's, neither overwriting the other.
import {defineBot} from '../../framework/index.js';
import {VoiceLeadingBot} from '../lib/voice-leading-bot.js';
import {feltBeats} from '../../shared/meter-tactus.js';
import {layer,polyState,interrupt,resume,step,analyse} from '../../shared/pitch-languages/layers.js';
import {strikeWith,languageOf} from '../lib/note-language.js';
import {beatingPair} from '../../shared/pitch-languages/texture.js';

// ---- Choices ---------------------------------------------------------------------------------------------------
// The layers: their registers (MIDI), rhythms (the felt beats, or a cycle of ticks), instruments and loudness. The
// upper rests one bar in every `restEvery`.
export const POLYSCALAR=Object.freeze({
  scale:Object.freeze([0,2,4,5,7,9,11]),steps:12,offset:6,restEvery:4,
  lower:Object.freeze({id:'lower',range:Object.freeze([55,70]),family:'pluck',velocity:.55,gain:.06}),
  upper:Object.freeze({id:'upper',range:Object.freeze([72,88]),family:'bell',velocity:.42,gain:.045,cycleTicks:3}),
  // The listening test's other textures (I11; the report's §10.4: "a fused aggregate, clearly separated scalar layers, and
  // a time-interleaved version"): 'fused', both layers stepping together in one register and one instrument, a stream of
  // dyads whose union is heard as one harmony; 'interleaved', the layers taking turns a bar each, each as it is layered.
  fused:Object.freeze({range:Object.freeze([62,78]),family:'pluck',velocity:.5,gain:.055}),
  textures:Object.freeze(['layered','fused','interleaved']),
});
const mod=(x,n)=>((x%n)+n)%n;
const words=value=>typeof value==='string'?value.trim().split(/[\s,]+/).filter(Boolean).map(Number):value;

// A layer's material: its scale up and back down, as classes of the domain from its anchor (degrees 0 1 ... 6 5 ... 1).
export function scalarLayer(id,{scale,steps,anchor}){
  const up=scale.map(degree=>mod(anchor+degree,steps)),material=[...up,...up.slice(1,-1).reverse()];
  return layer({id,collection:up,anchor:mod(anchor,steps),material,steps});
}

export class PolyscalarClodbot extends VoiceLeadingBot {
  constructor(send,audio,settings={}){
    super(send,audio,{style:'polyscalar',...settings});
    this.scale=words(settings.scale)??POLYSCALAR.scale;this.steps=settings.steps??POLYSCALAR.steps;this.offset=settings.offset??POLYSCALAR.offset;
    this.shimmer=Number(settings.shimmer)>0?Number(settings.shimmer):0;
    this.texture=POLYSCALAR.textures.includes(settings.texture)?settings.texture:'layered';
    this.poly=null;this.root=null;this.last={lower:null,upper:null};this.barEvents=[];
  }
  rearticulates(){return false}
  attack(){}
  noteLanguage(note){return languageOf(this.pendingLanguage,note)}
  // The layers on the root heard (C with none; a root in semitones is counted in the domain's steps). A new root makes
  // new collections, and each layer keeps its cursor.
  layers(clock){
    const root=Math.round((this.chord?.root??this.bandOpening.root)*this.steps/12);
    if(this.poly&&root===this.root)return this.poly;
    const layers=[scalarLayer('lower',{scale:this.scale,steps:this.steps,anchor:root}),scalarLayer('upper',{scale:this.scale,steps:this.steps,anchor:root+this.offset})];
    const state=polyState(layers);
    this.poly=this.poly?{...state,cursors:this.poly.cursors,sounding:this.poly.sounding}:state;this.root=root;
    return this.poly;
  }
  everyTick(clock){
    if(this.closing?.phase==='after'||!clock.meter)return;
    let state=this.layers(clock);
    // Every bar: both analyses of what the bar sounded, and the upper layer's rest and return.
    if(clock.barStart){
      if(this.barEvents.length)this.decide({tick:clock.tick,bar:clock.bar-1,...analyse(this.barEvents,state.layers)});
      this.barEvents=[];
      if(this.texture==='interleaved')state=mod(clock.bar,2)===0?interrupt(resume(state,'lower'),'upper'):interrupt(resume(state,'upper'),'lower');
      else{
        const resting=POLYSCALAR.restEvery>0&&mod(clock.bar,POLYSCALAR.restEvery)===POLYSCALAR.restEvery-1;
        state=resting?interrupt(state,'upper'):resume(state,'upper');
      }
    }
    const beats=feltBeats(clock.meter,{secondsPerTick:this.secondsPerTick(clock)}),spt=this.secondsPerTick(clock);
    const beat=beats.find(item=>item.start===clock.tickInBar);
    const due={lower:Boolean(beat),upper:this.texture==='fused'?Boolean(beat):mod(clock.tick,POLYSCALAR.upper.cycleTicks)===0};
    // Each layer due steps on its own (a layer not due, or resting, keeps its cursor).
    const stepped=step({...state,sounding:Object.fromEntries(Object.entries(state.sounding).map(([id,on])=>[id,on&&due[id]]))});
    this.poly={...stepped.state,sounding:state.sounding};
    for(const event of stepped.events){
      const spec=this.texture==='fused'?{...POLYSCALAR[event.layer],...POLYSCALAR.fused}:POLYSCALAR[event.layer],l=state.layers.find(item=>item.id===event.layer);
      const pitch=this.place(event.class,spec.range,this.last[event.layer]);
      const ticks=event.layer==='lower'||this.texture==='fused'?beat.length:POLYSCALAR.upper.cycleTicks,seconds=Math.max(.1,ticks*spt*.9);
      const written=this.writtenInterval(clock,ticks,{group:event.layer,replace:true});
      const language={layer:event.layer,collection:l.collection,anchor:l.anchor,steps:this.steps,position:event.position,class:event.class,texture:this.texture};
      // The upper layer's shimmer: the note as a beating pair about its pitch as the room tunes it, each member a little
      // softer and sounded exactly as made (a tuning plan would otherwise pull the two to one pitch: I06).
      const centre=this.shimmer&&event.layer==='upper'?this.audio?.tunePitch?.(pitch)??pitch:pitch;
      const members=event.layer==='upper'&&this.shimmer?(pair=>[['low',pair.lowHz],['high',pair.highHz]].map(([member,frequency])=>({pitch:69+12*Math.log2(frequency/440),
        language:{...language,pair:{member,beatHz:+(pair.highHz-pair.lowHz).toFixed(6),centerPitch:+centre.toFixed(4),model:pair.model}}})))(beatingPair(440*2**((centre-69)/12),this.shimmer))
        :[{pitch,language}];
      strikeWith(this,members,()=>this.playWritten(written,()=>{for(const member of members)this.audio.pitched(member.pitch,seconds,spec.gain/Math.sqrt(members.length),'sine',spec.family,spec.velocity,spec.family,
        members.length>1?{exactPitch:true}:null)}));
      this.announce(clock,[pitch],`layer:${event.layer}`);
      this.last[event.layer]=pitch;this.barEvents.push(event);
    }
  }
  // A class of the domain as a pitch (MIDI, fractional for steps other than twelve): nearest the layer's last note, in
  // its range.
  place(cls,range,near){
    const unit=12/this.steps,target=near??(range[0]+range[1])/2;
    let pitch=cls*unit;pitch+=12*Math.round((target-pitch)/12);
    while(pitch<range[0])pitch+=12;
    while(pitch>range[1])pitch-=12;
    return pitch;
  }
}

export const polyscalarClodbot=defineBot(
  {
    id:'polyscalar_clodbot',name:'polyscalar_clodbot',status:'native',source:'clodbot',
    category:'melody',midiChannel:11,performanceType:'polyphonic',outputModes:['synth','midi'],
    pitchContract:'floating-mpe',nativeTuning:true,
    specSettings:Object.freeze(['scale','steps','offset','shimmer','texture']),
    description:'Two scalar layers at once: the major scale on the root it hears and the major scale a tritone above (over C, C and F-sharp major), each walking its own collection in its own register, rhythm and instrument, the upper resting a bar now and then and resuming where it was; any division of the octave.',
  },
  (...args)=>new PolyscalarClodbot(...args),
);
