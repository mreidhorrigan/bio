// formant_clodbot: a mixbot for expressive LFOs, a voice's formants laid over a part of the band and moved as a singer
// moves from vowel to vowel. The user, 26 September 2026: "Expressive LFOs, including vocal formant filters, are another
// such edge case - mixbot for now, but might eventually need to be split off. The purpose of a formant filter is to
// mimic vocal formants both in EQ shape and with modulation." New, not a fork.
//
// A vowel is heard as one where it is sung, and changes where a singer's would, a syllable at a time. So it sings the
// lead where there is one (a melody sung on vowels; else the chords, else the texture: FORMANT_MIX.what), at full depth,
// a vowel on each felt beat (meter-tactus.js feltBeats: the beat a listener counts, a group in an additive meter),
// glided into over a share of the beat, alternating between two vowels whose brightness follows the section's tension:
// dark (u, o) in a calm section, open (o, a) in a middling one, bright (a, e) in a tense one, so the vowels change with
// the form (the user, of an edit heard alone: "it didn't have enough reinforcement from other simultaneous changes to
// sound intentional"); a return sings the opening pair again. The voice is the desk's to fit to the part it sings
// (shared/mix-formants.js: the voice whose range suits the part's register). The first attempt, vowels swept over whole
// sections at part depth over the chords, was not heard at all (the user: "No vowels audible").
//
// It hears the form (shared/form-joins.js: form_clodbot's, or PlexBOT's where the clock makes each section) and asks
// the desk phrase by phrase (/agent/formant), each phrase carrying on the vowels from where the last left them and
// overlapping it by the desk's fade, so the voice sings on and a change of tempo moves nothing out of place. None once
// the ending's cadence begins: the close is the players'.
import {defineBot} from '../../framework/index.js';
import {Agent} from '../../framework/agent.js';
import {feltBeats,secondsPerTick} from '../../shared/meter-tactus.js';
import {DEFAULT_PHRASE_BARS,formJoins,isReturn,withAnnouncement} from '../../shared/form-joins.js';
import {MIX_FORMANTS} from '../../shared/mix-formants.js';
import {Closure} from '../lib/modules/closure.js';

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const FORMANT_MIX=Object.freeze({
  // The groups it sings, the first playing taken (ours: a melody first, the voice most like a singer's).
  what:Object.freeze(['lead','keys','texture']),
  // The pairs of vowels a section alternates between, by its tension: under the first bound dark, under the second open,
  // else bright (ours: the second formant rising from u to e).
  pairs:Object.freeze([Object.freeze(['u','o']),Object.freeze(['o','a']),Object.freeze(['a','e'])]),bounds:Object.freeze([1/3,2/3]),
  // A vowel glided into over this share of its beat (ours: a sung syllable's onset, not a jump, not a slide).
  glide:.3,
  // How much of the vowels is heard, from the least tension to the most (ours: sung, hardly any of the dry sound).
  depth:Object.freeze([.85,1]),
  decisionsKept:256,
});
const clamp01=value=>Math.max(0,Math.min(1,value));
const between=([low,high],share)=>low+(high-low)*clamp01(share);

export class FormantClodbot extends Closure(Agent){
  constructor(send,audio,settings={}){
    super(send,audio);
    this.settings={...settings};this.form=null;this.announcedSections=[];this.asked=new Set;this.first=null;this.decisions=[];this.singing=false;
  }
  decide(entry){this.decisions.push(entry);if(this.decisions.length>FORMANT_MIX.decisionsKept)this.decisions.shift()}
  onPlan(plan){if(plan?.kind==='form')this.form=plan;this.announcedSections=withAnnouncement(this.announcedSections,plan);return super.onPlan?.(plan)}
  // The form's sections where the clock makes them: {start (bar), bars, phraseBars, tension, to}.
  sections(){
    const payload=this.form?.payload,list=payload?.sections??[];if(!list.length)return [];
    const joins=formJoins(this.form,{announced:this.announcedSections}),starts=[Number(this.form.appliesAt?.bar)||0,...joins.map(join=>join.bar)];
    const phraseBarsOf=section=>Math.max(1,Number(section.phraseBars??payload.phraseBars)||DEFAULT_PHRASE_BARS);
    return list.map((section,i)=>({start:starts[i],bars:i+1<starts.length?starts[i+1]-starts[i]:Math.max(1,Number(section.phrases)||1)*phraseBarsOf(section),
      phraseBars:phraseBarsOf(section),tension:i?joins[i-1].toTension:(joins[0]?.fromTension??Number(section.tension??section.hdensity)??0),to:section.role}));
  }
  // The pair of vowels a section sings: by its tension, the opening pair again at a return.
  pairFor(section,index){
    if(index>0&&isReturn(section.to)&&this.first)return this.first;
    const level=FORMANT_MIX.bounds.filter(bound=>section.tension>=bound).length;
    return FORMANT_MIX.pairs[level];
  }
  onTick(tick,clock){
    if(!clock?.meter||(clock.tickInBar??0)!==0)return;
    const closing=this.closingAt?.({...clock,tick});
    if(closing?.ending&&clock.bar>=closing.ending.cadenceBar)return;
    const sections=this.sections(),index=sections.findLastIndex(section=>section.start<=clock.bar);
    if(index<0)return;
    const section=sections[index],into=clock.bar-section.start;
    if(into>=section.bars||into%section.phraseBars!==0||this.asked.has(clock.bar))return;
    this.asked.add(clock.bar);
    const perTick=secondsPerTick(clock),beats=feltBeats(clock.meter,{secondsPerTick:perTick}),bars=Math.min(section.phraseBars,section.bars-into);
    const path=this.pairFor(section,index);if(index===0)this.first??=path;
    // A vowel a felt beat, the bar's beats in turn, carried on from the beats the section has sung.
    const motion={kind:'steps',seconds:beats.map(beat=>+(beat.length*perTick).toFixed(6)),glide:FORMANT_MIX.glide,start:(into*beats.length)%path.length};
    const depth=+between(FORMANT_MIX.depth,section.tension).toFixed(3),fadeIn=!this.singing;this.singing=true;
    const seconds=bars*clock.meter.pulsesPerBar*perTick+MIX_FORMANTS.fadeSeconds;
    const why=`${section.to} (tension ${section.tension.toFixed(2)}), bars ${clock.bar}-${clock.bar+bars}: sung on ${path.join(' and ')}, a vowel a felt beat`;
    this.send('/agent/formant',[{what:[...FORMANT_MIX.what],path:[...path],motion,depth,seconds:+seconds.toFixed(4),inSeconds:0,fadeIn,bar:clock.bar,why}]);
    this.decide({tick,bar:clock.bar,section:index,path:[...path],motion,depth,why});
  }
}

export const formantClodbot=defineBot(
  {
    id:'formant_clodbot',name:'formant_clodbot',status:'native',source:'clodbot',
    category:'conductor',outputModes:[],pitchContract:'none',
    description:'A mixbot for expressive LFOs: a voice\'s formants laid over a part of the band (a formant filter; the lead where there is one, else the chords), sung a vowel on each felt beat, glided into, alternating between two vowels whose brightness follows the form\'s tension (dark u and o when calm, open o and a between, bright a and e when tense), the opening pair again at a return.',
  },
  (...args)=>new FormantClodbot(...args),
);
