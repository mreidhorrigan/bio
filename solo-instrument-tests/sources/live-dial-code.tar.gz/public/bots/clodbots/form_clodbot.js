// form_clodbot: a fork of mh_FormBOT that gives the ensemble an ending it can hear coming. The user: "Incorporate a
// clodbot_formbot and any other clodbot techniques you can devise to help the bots develop a sense of conclusion when
// they stop playing."
//
// mh_FormBOT proposes a form, polls the ensemble, and commits it to stop at a phrase boundary a phrase ahead; at that
// boundary every bot stops where it is. This fork proposes, polls and commits as mh_FormBOT does, and, from the
// commitment on:
// - it says where and how the ensemble closes (/broadcast/form/closing, each bar): where it stops, the cadence's bar and
//   the final bar, and the tonic and mode it hears (it hears the harmony as the voice leaders do: HarmonyHearing);
// - it proposes the cadence as harmony plans, each sent in the bar it applies to, below a performer's (a performer's
//   harmony leads the ending where one leads): the chord a mode closes from, then its tonic (V7 to I in major, V7 to i
//   in minor, IV to i in dorian, flat VII to I in mixolydian, II to I in lydian, flat II to i in phrygian; in a maqam,
//   the qarar's own chord, arrived at);
// - it asks for a ritardando into the last bar (/broadcast/tempoCurve: four-fifths of the tempo over the last two bars),
//   unless a performer leads the tempo (heard in the last two bars, or a recording whose end it knows: a band that
//   slowed into a recording's last bars fell off its beat, 88% of beats within 50 ms of the guitarist's down to 82%);
//   a tempo locked to a performer declines it.
// The bots that hear the closing (the Closure module: bots/lib/modules/closure.js) cadence and hold their last sound to
// the end: the voice leaders' top voices step down to the tonic, the bass lands on the root, the drums fill into the
// last bar and strike it together.
//
// A song ends with its words. The user, 27 September 2026: "when a setting of a full poem is intended, the piece sets the
// entire poem. These settings will ultimately determine the lengths of the pieces - which are now determined to be
// songs". A singer announces each phrase it commits (/broadcast/vocal/plan), saying whether it sings its text through
// once (once) and marking the phrase that holds the text's last syllable (textComplete). While a singer that sings its
// text once has not reached its end, the ensemble does not vote to end; once every such singer's last phrase is
// committed, it ends after it, as it ends with a performer's recording, committed at once, with no vote: the words have
// decided. Where, is the form's. The user: "The band does not need to end exactly two bars after the song's end. Give a
// target range, to allow the form computations to give a sense of conclusion." So the band ends within a window after
// the bar of the last sung note (SONG_OUTRO): never sooner than the cadence's bar and the final bar (so the ritardando of
// those two bars never pulls against a phrase the voice has already been rendered at), never later than its most bars
// or seconds; and within it where the form closes: the closure its form plans, else the end of a phrase, else as soon
// as it can (songEnding). A singer that begins its text again changes nothing: the ensemble ends by its vote, as
// before.
//
// Made from the class it forks, which agents.js holds, by a function (no import cycle).
import {SongWatch,songEnding} from '../../shared/song-ending.js';
import {defineBot} from '../../framework/index.js';
import {Timekeeping} from '../lib/modules/timekeeping.js';
import {HarmonyHearing} from '../lib/modules/harmony-hearing.js';
import {EnsembleHearing} from '../lib/modules/ensemble-hearing.js';
import {QUARTER_TONE_MAQAM_LEVELS} from '../../shared/estimation/harmonic-levels.js';
import {formProgress} from '../../shared/form-development.js';
import {MIX_INTENTION_ADDRESS,mixIntention} from '../../shared/mix-intention.js';
import {FormalState} from '../../shared/formal-state.js';
import {formJoins} from '../../shared/form-joins.js';
import {marksJoin} from '../lib/modules/form-marks.js';
import {fitSectionsToPhrases} from '../../shared/form-negotiation.js';
import {bandPhraseBars,bandTempo,bandMeter} from '../../shared/opening-time.js';

// Where the form says its state each phrase (shared/formal-state.js: the extreme-aesthetics report's §5.1).
export const FORM_STATE_ADDRESS='/broadcast/form/state';

// The mix follows the form (the extreme-aesthetics report's M3). At each section's first phrase the form says what that
// section's mix is for (/broadcast/mixIntention: shared/mix-intention.js), from the numbers it already gives the
// section, its tension and its closure. The more tension, the more mass, fusion and impact and the less dynamic contrast;
// the more closure, the more space. The Mixbot holds what its duties can (live-desk.js setIntention), as a scene change
// on the section's downbeat; a room without a desk hears nothing of it. Each axis is a straight line from its value at 0
// to its value at 1. Settings {mixIntentions: false} keep the mix to the desk's own way.
//
// The user, 27 September 2026, on moderate ranges ([.4, .65] of depth: the return's reverb 2 dB up, the drums' attack a
// little eased) reached at the duties' own pace: "The minor changes in this are not intense or synchronous enough to be
// interpreted as deliberate, to my ear." A deliberate change is several times what is just noticed (the reverb's level
// against the direct sound is noticed from 2-3 dB: Larsen, Iyer, Lund & Scharf 2008), so the ranges now span most of
// each axis (ours): the return's space comes up about 15 dB against the rest, the drums' shaping runs from a third of the
// approach's to half as much again. And the mix changes only where the band marks the join too (sayMix).
export const FORM_MIX=Object.freeze({
  byTension:Object.freeze({mass:Object.freeze([.2,.9]),intentionalFusion:Object.freeze([0,.8]),attackLegibility:Object.freeze([.15,.95]),
    dynamicContrast:Object.freeze([.85,.15])}),
  byClosure:Object.freeze({depth:Object.freeze([.15,.95])}),
});
// A section's mix intention from its tension and closure (FormBot's sections: 0 to 1 each).
export function sectionMixIntention({tension=.5,closure=.1}={},choices=FORM_MIX){
  const along=([from,to],x)=>Math.round((from+(to-from)*Math.max(0,Math.min(1,Number(x)||0)))*1000)/1000;
  return mixIntention({...Object.fromEntries(Object.entries(choices.byTension).map(([axis,ends])=>[axis,along(ends,tension)])),
    ...Object.fromEntries(Object.entries(choices.byClosure).map(([axis,ends])=>[axis,along(ends,closure)]))});
}

// The cadence a mode closes with: the chord it approaches from (degree above the tonic, quality), and the tonic's.
export const CADENCES=Object.freeze({
  ionian:{approach:[7,'dominant-seventh'],final:'major'},
  aeolian:{approach:[7,'dominant-seventh'],final:'minor'},
  dorian:{approach:[5,'major'],final:'minor'},
  mixolydian:{approach:[10,'major'],final:'major'},
  lydian:{approach:[2,'major'],final:'major'},
  phrygian:{approach:[1,'major'],final:'minor'},
  locrian:{approach:[1,'major'],final:'minor'},
});
const SHAPES=Object.freeze({major:[0,4,7],minor:[0,3,7],'dominant-seventh':[0,4,7,10]});
// (A song's ending window: shared/song-ending.js, which plex_clodbot uses too.)
export {SONG_OUTRO,songEnding} from '../../shared/song-ending.js';
const modulo=(value,period)=>((value%period)+period)%period;
// A chord as a pool: its root from G3 (55) up, its tones above it.
export function cadencePool(root,quality){const base=55+modulo(root-55,12);return SHAPES[quality].map(step=>base+step)}
// The cadence for a centre heard ({pc, mode}): [approach pool or null, final pool]. A mode not listed closes by the
// quality of its own third, from its dominant seventh.
export function cadenceFor({pc,mode},{collection=null}={}){
  const cadence=CADENCES[mode]??(collection?.some(member=>modulo(member-pc,12)===3)&&!collection.some(member=>modulo(member-pc,12)===4)
    ?{approach:[7,'dominant-seventh'],final:'minor'}:{approach:[7,'dominant-seventh'],final:'major'});
  return [cadencePool(pc+cadence.approach[0],cadence.approach[1]),cadencePool(pc,cadence.final)];
}

// A form fitted to a render's length at the tempo it began with, fitted again to the tempo the band actually plays (its
// rubato's arches and its holds counted: `playedSeconds` by `bar`, a phrase line). The user, 28 September 2026, on 0f's
// kit 05b: "instruments other than drums ... don't seem to know exactly where to end in closing bars, and rather just
// seem to stop"; the band had slowed, and the render's length ran out five bars before the ending it had committed to
// (2a's reading). Where the form would end more than half a phrase after the length runs out, it ends on the phrase line
// nearest it: the phrases played are kept, and the rest (the current section's and those to come) fitted to what remains
// (form-negotiation.js fitSectionsToPhrases: the closing section kept). Never lengthened; never ending sooner than two
// phrases from now (a phrase to propose the stop in and one to vote); and only where every section's phrase is the
// form's. -> {sections, totalPhrases, endBar, lengthBar} or null.
export function formToLength({sections,start,phraseBars,bar,playedSeconds,lengthSeconds}){
  if(!(lengthSeconds>0)||!(playedSeconds>0)||!(phraseBars>0)||!(bar>start)||!sections?.length)return null;
  if(sections.some(section=>section.phraseBars&&section.phraseBars!==phraseBars))return null;
  const phrases=sections.map(section=>Math.max(1,Math.floor(Number(section.phrases)||1))),total=phrases.reduce((sum,value)=>sum+value,0);
  const lengthBar=bar+(lengthSeconds-playedSeconds)/(playedSeconds/bar),done=Math.floor((bar-start)/phraseBars);
  const target=Math.max(done+2,Math.round((lengthBar-start)/phraseBars));
  if(start+target*phraseBars>=start+total*phraseBars-phraseBars/2)return null;
  // The section the current phrase is in, and its phrases played before it.
  let current=0,before=0;while(current<sections.length-1&&before+phrases[current]<=done){before+=phrases[current];current++}
  const leftover=phrases[current]-(done-before)-1,rest=[...(leftover>0?[{...sections[current],phrases:leftover,continued:true}]:[]),...sections.slice(current+1)];
  const fitted=rest.length?fitSectionsToPhrases(rest,target-done-1):[];
  const continued=fitted[0]?.continued?fitted.shift().phrases:0;
  const out=[...sections.slice(0,current),{...sections[current],phrases:done-before+1+continued},...fitted.map(({continued:_,...section})=>section)]
    .map((section,index)=>({...section,id:index}));
  const totalPhrases=out.reduce((sum,section)=>sum+section.phrases,0);
  return {sections:out,totalPhrases,endBar:start+totalPhrases*phraseBars,lengthBar};
}

export function formClodbotClass(FormBot){
  class FormClodbot extends EnsembleHearing(HarmonyHearing(Timekeeping(FormBot))) {
    constructor(...args){super(...args);this.vl={dissonance:.4};this.elapsed=0;this.closing=null;this.cadenceSent=new Set;this.ritardandoSent=false;this.performerHeardAt=null;
      // A render's inputs, which with foresight (render/foresight.js) say where a performer's recording ends.
      this.renderInputs=args[2]?.inputs??null;
      // Whether it says each section's mix intention (FORM_MIX), and the section it last said one for.
      this.mixIntentions=args[2]?.mixIntentions!==false;this.mixSaid=null;this.mixScene=null;
      // The formal state it keeps from what it hears (shared/formal-state.js), and what it last heard of the harmony,
      // the tempo and meter, and each part's state.
      this.formal=new FormalState();this.formalHeard={chord:null,anchor:null,section:null,states:new Map};}
    onTick(tick,clock){
      if(clock?.meter){
        const now=this.elapsedSeconds(clock);this.elapsedFrom??=now;this.elapsed=now-this.elapsedFrom;
        // A hold's seconds (a fermata the clock waited through), said on the pulse after it.
        if(clock.held?.ends?.seconds>0&&this.heldAt!==clock.tick){this.heldSeconds=(this.heldSeconds??0)+clock.held.ends.seconds;this.heldAt=clock.tick}
        if(clock.phraseStart)this.fitToLength(clock);
        this.readBass(clock);this.hearHarmony(clock);if(clock.beatStart)this.hearLevels();
        this.endWithRecording(clock);
        this.endWithSong(clock);
        this.close(clock);
      }
      const result=super.onTick(tick,clock);
      if(clock?.meter)this.hearForm(clock);
      if(this.mixIntentions&&clock?.phraseStart)this.sayMix(clock);
      if(clock?.phraseStart)this.sayState(clock);
      return result;
    }
    // Its own form fitted to a fixed render length at the tempo the band plays (formToLength), before its stop is
    // proposed; said as a revision of the form, its reasons kept.
    fitToLength(clock){
      const end=this.audio?.renderEnd,seconds=Number(end?.seconds);
      if(!(seconds>0)||end.untilEnding||Number.isInteger(end.bars)||Number.isFinite(end.ticks)||!this.formPlan||this.stopProposal||this.stopCommitment)return;
      if(this.governingForm?.()!==this.formPlan)return;
      const payload=this.formPlan.payload,phraseBars=payload.phraseBars||clock.meter?.phraseBars||bandPhraseBars(),bar=Number(clock.bar)||0;
      const fitted=formToLength({sections:payload.sections,start:this.formPlan.appliesAt?.bar??0,phraseBars,bar,playedSeconds:this.elapsed+(this.heldSeconds??0),lengthSeconds:seconds});
      if(!fitted)return;
      const ending={...payload.candidateEndpoint,bar:fitted.endBar,phrase:(this.formPlan.appliesAt?.phrase??0)+fitted.totalPhrases,section:fitted.sections.length};
      this.formPlan=this.plans.revise(this.formPlan,{...payload,sections:fitted.sections,totalPhrases:fitted.totalPhrases,candidateEndpoint:ending},{
        expiresAt:{...ending,bar:ending.bar+phraseBars,phrase:ending.phrase+1},horizon:fitted.totalPhrases+1,
        rationale:`Fitted to the render's ${seconds} s at the tempo the band plays: the length runs out near bar ${fitted.lengthBar.toFixed(1)}, so the form ends at bar ${ending.bar}.`});
      this.broadcast('plan',[this.formPlan]);this.activeFormPlan=this.formPlan;
      (this.lengthFits??=[]).push({bar,endBar:ending.bar,lengthBar:+fitted.lengthBar.toFixed(2)});
    }
    // What it hears each tick that the formal state counts: a chord changed, a tempo or meter changed.
    hearForm(clock){
      const heard=this.formalHeard,at=this.elapsed,chord=this.chord?`${this.chord.root}:${this.chord.quality}`:null;
      if(chord&&chord!==heard.chord){if(heard.chord!==null)this.formal.heard('chord',at);heard.chord=chord}
      const anchor=`${Math.round(Number(clock.bpm)||0)}|${clock.meter?.numerator}/${clock.meter?.denominator}`;
      if(anchor!==heard.anchor){if(heard.anchor!==null)this.formal.heard('anchor',at);heard.anchor=anchor}
    }
    // The formal state, said each phrase: its section's tension joins the contrast history as the section begins.
    sayState(clock){
      const progress=formProgress(this.formPlan,clock),section=this.formPlan?.payload?.sections?.[progress.sectionIndex];
      if(section&&progress.sectionIndex!==this.formalHeard.section){this.formalHeard.section=progress.sectionIndex;this.formal.section(section.tension)}
      const beatsPerBar=clock.meter?.numerator??bandMeter().numerator,phraseBars=clock.meter?.phraseBars??bandPhraseBars(),bpm=Number(clock.bpm)||bandTempo();
      const pendingArrival=section?Math.round((1-progress.sectionProgress)*(section.phrases??1)*phraseBars*beatsPerBar*60/bpm*1000)/1000:null;
      const endingState=this.closing?'closing':this.stopCommitment?'committed':'open';
      this.send(FORM_STATE_ADDRESS,[{section:section?{index:progress.sectionIndex,role:section.role}:null,...this.formal.snapshot(this.elapsed,{pendingArrival,endingState})}]);
    }
    // A section's mix intention, said once at its first phrase (a revised plan's sections said again as they begin), on
    // its downbeat, where the desk makes it as a scene change. The mix changes only at a join the band marks
    // (form-marks.js marksJoin: the drummer's fill into it, its landing), so every scene change is reinforced; across a
    // join the tension hardly moves, the scene before it is kept, as a small change on its own sounds accidental.
    sayMix(clock){
      const progress=formProgress(this.formPlan,clock),section=this.formPlan?.payload?.sections?.[progress.sectionIndex];
      const said=`${progress.formPlanId}:${progress.sectionIndex}`;
      if(!section||said===this.mixSaid)return;
      this.mixSaid=said;
      const join=progress.sectionIndex>0?formJoins(this.formPlan)[progress.sectionIndex-1]:null;
      if(this.mixScene&&join&&!marksJoin(join))return;
      this.mixScene=said;
      this.send(MIX_INTENTION_ADDRESS,[{intention:sectionMixIntention(section),section:{index:progress.sectionIndex,role:section.role}}]);
    }
    // What the ensemble says that the formal state counts: remembered material presented again (a return), a part
    // entering or leaving, onsets a voice reports, a part's grouping against the meter.
    hearFormally(message){
      const address=message?.address,payload=message?.args?.[0],at=this.elapsed??0;
      if(address==='/agent/memory/playing')this.formal.heard('return',at);
      if(address==='/broadcast/agentState'&&payload?.instanceId){
        const id=String(payload.instanceId),playing=String(payload.state||'playing')==='playing',was=this.formalHeard.states.get(id);
        if(was!==undefined&&was!==playing)this.formal.heard('entry',at);
        this.formalHeard.states.set(id,playing);if(payload.state==='left')this.formal.forgetPart(id);
      }
      if(address==='/broadcast/onsets'){const count=Array.isArray(payload?.onsets)?payload.onsets.length:1;for(let k=0;k<count;k++)this.formal.heard('onset',at)}
      // A grouping spans `bars` bars (grouping-choice.js): it agrees with the meter where it is the meter's groups, bar by bar.
      if(address==='/broadcast/grouping'&&payload&&Array.isArray(payload.groups)){
        const home=this.currentClock?.meter?.groups??[],expected=Array.from({length:Math.max(1,payload.bars||1)},()=>home).flat();
        this.formal.heardGrouping(payload.by??message.source??'?',payload.groups,expected);
      }
    }
    // A performer heard: their attacks or notes, as a listener or a MIDI input announces them (role 'performer').
    onMessage(message){
      super.onMessage(message);
      this.hearFormally(message);
      if((message?.address==='/broadcast/onsets'||message?.address==='/broadcast/voices')&&message.args?.[0]?.role==='performer')this.performerHeardAt=this.elapsed;
      if(message?.address==='/broadcast/vocal/plan')this.hearSong(message.args?.[0]);
    }
    // A singer's committed phrase (shared/song-ending.js SongWatch), and the singers that sing their text once, and where
    // their words end.
    hearSong(plan){(this.songWatch??=new SongWatch).hear(plan)}
    wholeSongs(){return this.songWatch?.whole()??[]}
    songEnd(){return this.songWatch?.end()??null}
    // With the words' last phrase committed, the ensemble ends after it, in the window songEnding gives, where its form
    // closes. The bars and seconds counted in the meter and tempo now (MusebotTV's meterform_clodbot keeps its home).
    endWithSong(clock){
      const endTick=this.songEnd();
      if(this.stopCommitment||this.ensembleStopped||!clock.barStart||endTick===null||this.performerEnd()!==null)return;
      const perBar=clock.meter.pulsesPerBar||bandMeter().pulsesPerBar,bar=clock.bar??0,barStart=clock.tick-(clock.tickInBar??0),bars=clock.meter.phraseBars||bandPhraseBars();
      const lastBar=bar+Math.max(0,Math.floor((endTick-1-barStart)/perBar)),perTick=this.secondsPerTick(clock);
      const {endsAt,window,why}=songEnding({lastBar,phraseBars:bars,formEnd:this.plannedEnd(clock),secondsToBar:at=>(barStart+(at-bar)*perBar-endTick)*perTick});
      const at={bar:endsAt,phrase:Math.floor(endsAt/bars),section:clock.section??0};
      this.stopCommitment=this.preparePlan('lifecycle',{schemaVersion:1,action:'stop',phase:'commitment',decision:{song:true,lastSungTick:endTick,window:[window[0],window.at(-1)],chosen:why},formPlanId:this.formPlan?.planId??null},{
        createdAt:{bar,phrase:clock.phrase??0,section:clock.section??0},appliesAt:at,expiresAt:{...at,bar:endsAt+bars,phrase:at.phrase+1},horizon:1,confidence:1,priority:1,
        rationale:'The song\'s words end here: the ensemble ends after them.'});
      this.announcePlan(this.stopCommitment);
      this.broadcast('form/decision',[{status:'accepted',song:true,planId:this.stopCommitment.planId,appliesAt:at}]);
    }
    // The bar the form this bot follows plans to end before (its candidate endpoint, or the end of another's), or null.
    plannedEnd(clock){
      if(!this.formPlan)return null;
      const governing=this.governingForm(),endpoint=governing===this.formPlan?this.formPlan.payload?.candidateEndpoint:this.endingOf(governing,clock);
      return Number.isInteger(endpoint?.bar)?endpoint.bar:null;
    }
    // Whether a performer leads the tempo: heard within the last two bars, or a recording whose end is known.
    performerLeads(clock){
      if(this.performerEnd()!==null)return true;
      const bars=2*(clock.meter?.pulsesPerBar||bandMeter().pulsesPerBar)*this.secondsPerTick(clock);
      return this.performerHeardAt!==null&&this.elapsed-this.performerHeardAt<=bars;
    }
    // Foresight: where the performer's recording falls silent (render seconds), the last of the inputs', or null.
    performerEnd(){
      if(!this.renderInputs?.foresight)return null;
      this.foresightInputs??=this.renderInputs.list().map(input=>this.renderInputs.open(input.id)).filter(Boolean);
      const ends=this.foresightInputs.map(input=>input.foresight?.()?.audibleEnd).filter(Number.isFinite);
      return ends.length?Math.max(...ends):null;
    }
    // With the recording's end known, the ensemble ends with it: at the bar line after its last sound, committed a
    // phrase ahead (its bar predicted at the tempo now, as late as that allows), with no vote: the performer has decided.
    endWithRecording(clock){
      if(this.stopCommitment||this.ensembleStopped||!clock.barStart)return;
      const end=this.performerEnd();if(end===null)return;
      const now=this.renderInputs.now(),barSeconds=(clock.meter.pulsesPerBar||bandMeter().pulsesPerBar)*this.secondsPerTick(clock),bar=clock.bar??0;
      const endsAt=bar+Math.floor(Math.max(0,end-now)/barSeconds)+1,bars=clock.meter.phraseBars||bandPhraseBars();
      if(endsAt-bar>bars+1)return;
      const at={bar:endsAt,phrase:Math.floor(endsAt/bars),section:clock.section??0};
      this.stopCommitment=this.preparePlan('lifecycle',{schemaVersion:1,action:'stop',phase:'commitment',decision:{foresight:true,performerEnd:+end.toFixed(3)},formPlanId:this.formPlan?.planId??null},{
        createdAt:{bar,phrase:clock.phrase??0,section:clock.section??0},appliesAt:at,expiresAt:{...at,bar:endsAt+bars,phrase:at.phrase+1},horizon:1,confidence:1,priority:1,
        rationale:'The performer\'s recording ends here (foresight): the ensemble ends with it.'});
      this.announcePlan(this.stopCommitment);
      this.broadcast('form/decision',[{status:'accepted',foresight:true,planId:this.stopCommitment.planId,appliesAt:at}]);
    }
    // With the recording's end known, the ensemble does not vote to end anywhere else.
    // Nor while a singer sings its text once: its words decide where the song ends.
    proposeStop(clock){if(this.performerEnd()===null&&!this.wholeSongs().length)return super.proposeStop(clock);}
    evaluateStop(clock){if(this.performerEnd()===null&&!this.wholeSongs().length)return super.evaluateStop(clock);}
    // The ending the ensemble committed to (its own, or another form bot's that it adopted), as a closing.
    closingFor(commitment){
      const endsAt=commitment.appliesAt,levels=this.levelsHeard(),center=levels?.center??null,maqam=this.vocabulary===QUARTER_TONE_MAQAM_LEVELS;
      const top=levels?.layers[0]?.top[0]??null,tonic=maqam?top?.root??null:center?.pc??null;
      return {endsAt,finalBar:endsAt.bar-1,cadenceBar:endsAt.bar-2,tonic,mode:maqam?top?.family??null:center?.mode??null,maqam,planId:commitment.planId,
        collection:top?.pitchClasses??null};
    }
    close(clock){
      const commitment=this.stopCommitment;if(!commitment||this.ensembleStopped)return;
      this.closing??=this.closingFor(commitment);
      const closing=this.closing,bar=clock.bar??0,last=(clock.tickInBar??0)===(clock.meter?.pulsesPerBar||bandMeter().pulsesPerBar)-1;
      if(bar>=closing.endsAt.bar)return;
      if(clock.barStart||!this.closingSent){this.closingSent=true;
        this.broadcast('form/closing',[{endsAt:closing.endsAt,finalBar:closing.finalBar,cadenceBar:closing.cadenceBar,tonic:closing.tonic,mode:closing.mode,planId:closing.planId}]);}
      // A ritardando over the last two bars, asked for in the bar before it begins, where no performer leads the tempo.
      if(!this.ritardandoSent&&bar>=closing.cadenceBar-1){
        this.ritardandoSent=true;
        if(!this.performerLeads(clock))this.broadcast('tempoCurve',[{targetBpm:+((clock.bpm||bandTempo())*.8).toFixed(2),durationBars:2,shape:'easeInOut'},'nextBar']);
      }
      // The cadence: each chord's plan sent in the last tick before its bar, so that every bot, whatever its order, takes
      // it at the bar's downbeat (plans are applied before a bot's tick); late, at once.
      if(closing.tonic===null)return;
      const [approach,final]=closing.maqam?[null,this.maqamFinal(closing)]:cadenceFor({pc:closing.tonic,mode:closing.mode},{collection:closing.collection});
      if(approach&&(bar===closing.cadenceBar-1&&last||bar>=closing.cadenceBar&&bar<closing.finalBar))this.proposeCadence('approach',approach,clock,closing,Math.max(bar+(last?1:0),closing.cadenceBar));
      if(bar===closing.finalBar-1&&last||bar>=closing.finalBar)this.proposeCadence('final',final,clock,closing,Math.max(bar+(last?1:0),closing.finalBar));
    }
    // A maqam's final: its qarar with the notes a third and a fifth above it in the maqam (its first jins's third).
    maqamFinal(closing){
      const members=(closing.collection??[]).map(pc=>modulo(pc-closing.tonic,12)).sort((a,b)=>a-b);
      const third=members.find(step=>step>2.4&&step<4.6)??4,fifth=members.find(step=>step>6.4&&step<7.6)??7;
      return [0,third,fifth].map(step=>55+modulo(closing.tonic-55,12)+step);
    }
    proposeCadence(kind,chord,clock,closing,bar){
      if(this.cadenceSent.has(kind))return;this.cadenceSent.add(kind);
      const bars=clock.meter?.phraseBars||bandPhraseBars(),createdAt={bar:clock.bar??0,phrase:clock.phrase??0,section:clock.section??0},appliesAt={bar,phrase:Math.floor(bar/bars),section:clock.section??0};
      const plan=this.preparePlan('harmony',{schemaVersion:1,chords:[chord],durations:[1],source:'form-cadence',label:kind==='final'?'cadence-final':'cadence-approach'},{
        createdAt,appliesAt,expiresAt:{...closing.endsAt,bar:closing.endsAt.bar+1},horizon:1,confidence:.9,priority:.9,
        rationale:kind==='final'?'The tonic the ensemble closes on.':'The chord the ensemble cadences from.'});
      this.announcePlan(plan);
      this.cadences=[...(this.cadences??[]),{kind,chord,bar,tick:clock.tick}];
    }
  }
  return FormClodbot;
}
export function defineFormClodbot(FormBot){
  const FormClodbot=formClodbotClass(FormBot);
  return defineBot({id:'form_clodbot',name:'form_clodbot',status:'native',source:'clodbot',category:'conductor',outputModes:[],pitchContract:'none',
    specSettings:Object.freeze(['mixIntentions']),
    description:'A fork of mh_FormBOT that gives the ensemble an ending it can hear coming: once the ensemble has committed to stopping, it says where and how it closes, proposes the cadence the mode heard closes with (below a performer\'s harmony), and asks for a ritardando into the last bar, so that the bots cadence and hold their last sound to the end. At the start of each section it also says what the section\'s mix is for, from its tension and closure, for the Mixbot to hold.'},
    (...args)=>new FormClodbot(...args));
}
