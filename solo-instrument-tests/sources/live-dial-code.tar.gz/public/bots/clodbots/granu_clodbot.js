// granu_clodbot: a fork of mh_GranuBOT that times its grain clouds in the transport's own beats (the mathematical audit's B04,
// ../lib/quarter-tempo.js). The port reads the transport's tempo as quarter notes; in 7/8 each bar's cloud lasts the bar, where
// the port's took half the time, and in 3/2 it no longer takes twice. The port's code is untouched: onTick is the port's
// own, given its clock with the tempo in quarter notes (it reads the tempo for nothing else). In a meter of quarters it
// plays exactly as mh_GranuBOT. Made from the class it forks, which agents.js holds, by a function (no import cycle).
import {defineBot} from '../../framework/index.js';
import {quarterNoteClock} from '../lib/quarter-tempo.js';

export function granuClodbotClass(GranuBot){
  return class GranuClodbot extends GranuBot {
    onTick(tick,clock){return super.onTick(tick,quarterNoteClock(clock))}
  };
}
export function defineGranuClodbot(GranuBot){
  const GranuClodbot=granuClodbotClass(GranuBot);
  return defineBot({
      id:'granu_clodbot',name:'granu_clodbot',status:'native',source:'clodbot',forkOf:'granu',category:'texture-noise',outputModes:['synth'],pitchContract:'none',
      description:"A fork of mh_GranuBOT that times its grain clouds in the transport's own beats (the mathematical audit's B04): in 7/8 each bar's cloud lasts the bar, where the port's took half the time, and in 3/2 it no longer takes twice. In a meter of quarters it plays exactly as mh_GranuBOT.",
    },(...args)=>new GranuClodbot(...args));
}
