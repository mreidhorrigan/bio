import {Agent,defineBot} from '../framework/index.js';
import {EnsembleProfile} from '../shared/estimation/ensemble-profile.js';
import {serveProfileQuery} from '../shared/estimation/profile-report.js';
import {ProtocolTrace,auditProtocolMessage} from '../shared/protocol-observability.js';
import {PlanLedger} from '../shared/estimation/plan-ledger.js';

const DISPOSITIONS=['accept','transform','counter','defer','decline','abstain'];

export class ProfilerBot extends Agent{
  constructor(send,audio,{now=()=>performance.now()/1000}={}){
    super(send,audio);this.now=now;this.trace=new ProtocolTrace(64);this.observedMessage=0;
    // Every bot's plans and answers, as their authors published them: read, never acted on.
    this.planLedger=new PlanLedger({now});
  }
  start(){this.audio?.report?.('bot_status',{state:'idle',message:'Choose sources to observe, then open Ensemble evidence and futures.'});}
  onTick(){} // The observer's maintenance pump is independent of musical ticks.
  observeSources(sources){
    const identity={id:this.instanceId,incarnation:this.incarnation};
    this.profile||=new EnsembleProfile({identity,send:this.send,now:this.now});
    this.profile.configure(sources,identity);
  }
  pump(){return this.profile?.pump();}
  onMessage(message){
    if(serveProfileQuery(this,message,{now:this.now(),project:()=>({coverage:'snapshot',profile:this.summary()})}))return;
    if(message.address.startsWith('/agent/profile/')||message.address.startsWith('/agent/estimation/')){
      this.profile?.receive(message);return;
    }
    // The shared Agent contract answers unsupported plans with an abstention.
    // It is excluded from musical quorums and from this observer's own trace.
    if(message.address==='/broadcast/plan/response'&&message.args?.[0]?.responder===this.instanceId&&message.args?.[0]?.disposition==='abstain')return;
    if(this.profile?.enabled){
      this.planLedger.receive(message);
      // Coarse/unknown messages remain traffic observations, never fabricated
      // notes. Keep source and byte counts without retaining arbitrary payloads.
      const origin=message.networkOrigin;
      this.trace.add({eventId:origin?JSON.stringify([origin.host,origin.incarnation,origin.seq]):message.eventId||`observation:${++this.observedMessage}`,
        source:String(message.source||'unknown').slice(0,256),address:message.address,args:[],
        clientTime:this.now(),audit:auditProtocolMessage(message)});
    }
    super.onMessage(message);
  }
  profileSnapshot(){return this.profile?{...this.profile.snapshot(),traffic:this.trace.report(),plans:this.planLedger.snapshot()}:null;}
  summary(){
    const view=this.profile?.snapshot();
    return {version:1,kind:'ensemble-profile-summary',role:'diagnostic',observer:{id:this.instanceId,incarnation:this.incarnation},
      enabled:view?.enabled||false,revision:view?.revision||0,coverage:view?.coverage||null,
      sources:(view?.sources||[]).map(source=>({publisher:source.publisher,kind:source.kind,coverage:source.coverage,stale:source.stale,
        reportId:source.data?.report?.reportId??null,profileSequence:source.data?.sequence??null})),
      history:(view?.history||[]).slice(-16).map(record=>({publisher:record.publisher,overplan:record.decision.overplan,
        state:record.decision.state,selectedBranch:record.decision.selection?.branchId??null,
        snapshotDigest:record.decision.snapshot?.digest??null,rendered:record.decision.rendered,acousticOutputMeasured:false})),
      plans:this.planSummary(),
      limits:{summaryHistory:16,summaryPlans:16},timeMeaning:'Each record keeps its publisher clock; receipt does not establish synchronized performance.'};
  }
  // A compact ledger for the network summary: who proposed what, and how the others answered.
  planSummary(){
    const ledger=this.planLedger.snapshot();
    return {counts:ledger.counts,plans:ledger.plans.slice(-16).map(({plan,statuses,final,cancel})=>({protocol:plan.protocol,planId:plan.planId,author:plan.author,
      kind:plan.kind,revision:plan.revision,attested:plan.attested??'instance',appliesAt:plan.appliesAt??null,startBeat:plan.startBeat,
      answers:plan.protocol==='ordinary'?Object.fromEntries(DISPOSITIONS.map(value=>[value,statuses.filter(status=>status.disposition===value).length])):
        Object.fromEntries([...new Set(statuses.map(status=>status.state))].map(state=>[state,statuses.filter(status=>status.state===state).length])),
      committed:Boolean(final),cancelled:Boolean(cancel)}))};
  }
  stop(){this.profile?.stop();}
}

export const profilerBot=defineBot({id:'profiler',name:'ProfilerBot',status:'native',category:'utility',outputModes:[],pitchContract:'none',
  description:'Read-only ensemble view of selected input evidence, independent bot policies, prepared alternatives and reported execution.',
  visualizers:[{id:'ensemble-profile',name:'Ensemble evidence and futures',module:'./ensemble-profile.js'}],
  planningCapabilities:{tuning:false,harmony:false,rhythm:false,motif:false,orchestration:false,form:false,lifecycle:false}},
  (send,audio,options)=>new ProfilerBot(send,audio,options));
