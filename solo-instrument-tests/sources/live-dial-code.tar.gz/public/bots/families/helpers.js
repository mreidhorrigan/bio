// Helpers the bots' classes share, moved with them from public/agents.js (its per-family split).
import {bandPhraseBars} from '../../shared/opening-time.js';

export const phrasePlanWindow = (clock) => {
  const phraseBars = clock.meter?.phraseBars || bandPhraseBars(),
    createdAt = {
      bar: clock.bar || 0,
      phrase: clock.phrase || 0,
      section: clock.section || 0,
    };
  return {
    createdAt,
    appliesAt: createdAt,
    expiresAt: {
      ...createdAt,
      bar: createdAt.bar + phraseBars,
      phrase: createdAt.phrase + 1,
    },
    horizon: 1,
  };
};

export const internalClamp = (value) => Math.max(0, Math.min(1, Number(value) || 0));
