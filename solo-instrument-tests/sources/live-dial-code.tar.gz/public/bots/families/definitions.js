// The registry's definitions, for a bot that looks another up by its id or name (mh_MemoryBOT): agents.js registers them
// once it has made the registry, so the families need not import agents.js, which imports them.
let definitions = {};
export function registerDefinitions(value) {
  definitions = value;
}
export function agentDefinitions() {
  return definitions;
}
