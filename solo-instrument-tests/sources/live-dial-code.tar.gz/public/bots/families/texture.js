// The texture and noise bots: vinyl, sweeper, FM texture, tonic, wind, bleeps, whines, groans, wubs, atmosphere,
// texture, granular, Chichichi, derivations, the decider, and the rungler.
// Moved verbatim from public/agents.js in its per-family split (28 September 2026; RESEARCH_BACKLOG, the second
// queue). agents.js registers them (BOT_REGISTRY) and re-exports each, so an import from it is as it was.
import { Agent } from "../../framework/index.js";
import { STOCHASTIC_CONFIG as CONFIG } from "../../stochastic-config.js";
import { StalePresenceLease, StaleValueLease } from "../../shared/control-ownership.js";
import { TEXTURE_TIMBRES } from "../../data/texture-timbres.js";
import { chooseTextureTimbre } from "../../shared/timbre.js";
import {
  cycleIndexAtPhrasePosition, parseCompoundIntent, residualActivityMask, serializeIntentFields,
} from "../../shared/intentions.js";
import { playableRegister, reflectedWalk } from "../../shared/sequencing.js";
import { randomInt, unitRandom, weightedChoice } from "../../shared/stochastic.js";
import {bandTempo,bandMeter,bandPhraseBars} from '../../shared/opening-time.js';
import {writtenOn,writtenOnStep,writtenSeconds,ticksUntil,phraseTicksLeft} from "../lib/written.js";

export class VinylBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.vinyl;
    this.lastSegment = null;
  }
  onTick(
    tick,
    clock,
  ) {
    if (!clock.barStart && this.lastSegment != null) return;
    const segment = Math.floor((clock.bar || 0) / this.config.segmentBars);
    if (segment === this.lastSegment) return;
    this.lastSegment = segment;
    const duration = Math.max(
      2,
      (this.config.segmentBars * (clock.meter?.numerator || bandMeter().numerator) * 60) /
        (clock.bpm || bandTempo()) +
        0.25,
    );
    // (Each written where it plays, as its own clock places it -- lib/written.js: here, to its segment's end.)
    const per = clock.meter?.pulsesPerBar || bandMeter().pulsesPerBar;
    writtenOn(this.audio, clock.tick, (this.config.segmentBars - ((clock.bar || 0) % this.config.segmentBars)) * per - (clock.tickInBar || 0), () => this.audio.vinylTexture(duration, this.config));
  }
}

export class SweeperBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.sweeper;
    this.lastBar = null;
    this.barsUntilSweep = 1;
  }
  reset() {
    const [low, high] = this.config.barsUntilSweepRange;
    this.barsUntilSweep = low + randomInt(high - low + 1);
  }
  onTick(
    tick,
    clock,
  ) {
    if (!clock.barStart || clock.bar === this.lastBar) return;
    this.lastBar = clock.bar;
    if (--this.barsUntilSweep > 0) return;
    const [low, high] = this.config.durationMsRange,
      duration = (low + randomInt(high - low + 1)) / 1000;
    writtenOn(this.audio, clock.tick, clock.meter?.pulsesPerBar || bandMeter().pulsesPerBar, () => this.audio.filterSweep(duration, this.config));
    this.reset();
  }
}

export class FmTextureBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.fmTexture;
    this.activityMask = [...this.config.defaultActivityMask];
    this.pitchclassPool = this.openingClasses();
    this.receivedMasks = [];
    this.lastPhrase = -1;
    this.lastCell = -1;
    this.registerIndex = 3;
    this.timbre = {};
    this.changeTimbre();
  }
  onMessage(message) {
    super.onMessage(message);
    const intent = parseCompoundIntent(message);
    if (
      intent &&
      intent.sender !== this.instanceId &&
      intent.sender !== "k_FMBOT"
    ) {
      if (intent.activityMask) this.receivedMasks.push(intent.activityMask);
      if (intent.pitchclassPool?.length)
        this.pitchclassPool = [...intent.pitchclassPool];
    }
  }
  changeTimbre() {
    const c = this.config;
    this.timbre = {
      carrierRatio: c.carrierRatios[randomInt(c.carrierRatios.length)],
      modulatorRatio: c.modulatorRatios[randomInt(c.modulatorRatios.length)],
      index:
        c.modulationIndexRange[0] +
        unitRandom() * (c.modulationIndexRange[1] - c.modulationIndexRange[0]),
      amDepth:
        c.amDepthRange[0] +
        unitRandom() * (c.amDepthRange[1] - c.amDepthRange[0]),
    };
  }
  beginPhrase(clock) {
    if (this.lastPhrase >= 0 && this.receivedMasks.length)
      this.activityMask = residualActivityMask(
        this.config.defaultActivityMask,
        this.receivedMasks,
      );
    this.receivedMasks = [];
    this.lastPhrase = clock.phrase;
    this.lastCell = -1;
    this.changeTimbre();
    this.broadcast(
      "intent",
      serializeIntentFields("k_FMBOT", {
        activityMask: this.activityMask,
        pitchclassPool: this.pitchclassPool,
      }),
    );
  }
  onTick(
    tick,
    clock,
  ) {
    clock = this.interpretClock(clock);
    if (clock.phraseStart && clock.phrase !== this.lastPhrase)
      this.beginPhrase(clock);
    const cell = cycleIndexAtPhrasePosition(clock, 16);
    if (cell === this.lastCell) return;
    this.lastCell = cell;
    const activity = this.activityMask[cell] || 0;
    if (activity <= 0 || (!clock.phraseStart && randomInt(10) >= activity))
      return;
    this.registerIndex = reflectedWalk(
      this.registerIndex,
      randomInt(this.config.registerWalkStep * 2 + 1) -
        this.config.registerWalkStep,
      this.config.registerWalkSize,
    );
    const pc = this.pitchclassPool[cell % this.pitchclassPool.length],
      note = Math.min(
        this.config.registerRange[1],
        this.config.registerRange[0] + this.registerIndex * 4 + (pc % 12),
      ),
      duration = (this.config.noteDurationBeats * 60) / (clock.bpm || bandTempo()),
      [low, high] = this.config.velocityRange,
      velocity = this.shapeVelocity(low + ((high - low) * activity) / 9, note, {
        clock,
        division: cell,
        divisions: 16,
      });
    writtenOn(this.audio, clock.tick, ticksUntil(clock, (ahead) => cycleIndexAtPhrasePosition(ahead, 16) !== cell, phraseTicksLeft(clock, clock.meter.phraseBars || bandPhraseBars())), () => this.audio.fmTexture(note, duration, velocity, this.timbre));
  }
}

export class TonicBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.tonic;
    this.density = this.config.defaultDensity;
    this.activity = this.config.defaultActivity;
    this.now = () => Date.now();
    this.poolLease = new StalePresenceLease(this.config.fallbackTimeoutMs, () =>
      this.now(),
    );
    this.densityLease = new StaleValueLease(this.config.fallbackTimeoutMs, () =>
      this.now(),
    );
    this.activityLease = new StaleValueLease(
      this.config.fallbackTimeoutMs,
      () => this.now(),
    );
    this.nextAt = 0;
    this.currentNote = null;
    this.hasPlayed = false;
  }
  onMessage(message) {
    super.onMessage(message);
    if (message.address.endsWith("/notepool"))
      this.poolLease.receive(this.notes);
    if (message.address.endsWith("/hdensity"))
      this.densityLease.receive(this.density);
    if (message.address.endsWith("/vdensity")) {
      const value = Number(message.args.at(-1));
      if (Number.isFinite(value)) {
        this.activity = Math.max(0, Math.min(1, value));
        this.activityLease.receive(this.activity);
      }
    }
  }
  generatePool() {
    const mode =
        this.config.progressions[randomInt(this.config.progressions.length)],
      root =
        randomInt(
          this.config.transposeRange[1] - this.config.transposeRange[0] + 1,
        ) + this.config.transposeRange[0];
    this.notes = mode.map(
      (value) => ((value + root) % 12) + 48 + (1 + randomInt(3)) * 12,
    );
    this.broadcast("notepool", this.notes);
  }
  updateFallback() {
    if (this.poolLease.update()) this.generatePool();
    if (this.densityLease.update()) {
      this.density = Math.max(
        0,
        Math.min(1, this.density + (unitRandom() - 0.5) * 0.2),
      );
      this.broadcast("hdensity", [this.density]);
    }
    if (this.activityLease.update()) {
      this.activity = Math.max(
        0,
        Math.min(1, this.activity + (unitRandom() - 0.5) * 0.2),
      );
      this.broadcast("vdensity", [this.activity]);
    }
  }
  onTick(tick, clock) {
    this.updateFallback();
    const now = this.now();
    if (now < this.nextAt) return;
    const [minDuration, maxDuration] = this.config.durationSecondsRange,
      duration = minDuration + unitRandom() * (maxDuration - minDuration);
    this.nextAt =
      now +
      duration * 1000 +
      this.config.breakBaseMs +
      (1 - this.activity) * this.config.breakScaleMs;
    if (this.hasPlayed && unitRandom() > this.activity) return;
    if (
      this.currentNote == null ||
      unitRandom() < this.density * this.config.noteChangeScale
    ) {
      const source = this.notes[randomInt(this.notes.length)] ?? 60,
        [low, high] = this.config.detuneSemitonesRange;
      this.currentNote = source + low + unitRandom() * (high - low);
    }
    this.hasPlayed = true;
    writtenSeconds(this.audio, clock, duration, () => this.audio.tonicWhistle(
      this.currentNote,
      duration,
      this.shapeVelocity(this.config.velocity, this.currentNote, {
        clock,
        amount: 0.7,
      }),
      this.activity,
    ));
  }
}

export class WindBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.wind;
    this.density = this.config.defaultDensity;
    this.lastBar = null;
  }
  onMessage(message) {
    super.onMessage(message);
    if (message.address.endsWith("/hdensity")) {
      const value = Number(message.args.at(-1));
      if (Number.isFinite(value))
        this.density = Math.max(0, Math.min(1, value));
    }
  }
  onTick(
    tick,
    clock,
  ) {
    if (!clock.barStart || clock.bar === this.lastBar) return;
    this.lastBar = clock.bar;
    const [low, high] = this.config.centroidRange,
      centroid =
        (low + (high - low) * this.density) *
        (this.config.frequencyScaleRange[0] +
          unitRandom() *
            (this.config.frequencyScaleRange[1] -
              this.config.frequencyScaleRange[0])),
      duration =
        ((((clock.meter?.numerator || bandMeter().numerator) * 4) /
          (clock.meter?.denominator || bandMeter().denominator)) *
          60) /
          (clock.bpm || bandTempo()) +
        0.1;
    writtenOn(this.audio, clock.tick, clock.meter?.pulsesPerBar || bandMeter().pulsesPerBar, () => this.audio.windTexture(duration, centroid, this.density, this.config));
    this.broadcast("centroid", [centroid]);
  }
}

export class BleepBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.bleep;
    this.density = this.config.defaultDensity;
    this.arousal = this.config.defaultArousal;
    this.preset = randomInt(this.config.presets.length);
    this.lastBar = null;
  }
  onMessage(message) {
    super.onMessage(message);
    if (
      message.address.endsWith("/vdensity") ||
      message.address.endsWith("/arousal")
    ) {
      const value = Number(message.args.at(-1));
      if (Number.isFinite(value))
        this.arousal = Math.max(0, Math.min(1, value));
    }
  }
  onTick(
    tick,
    clock,
  ) {
    if (clock.barStart && clock.bar !== this.lastBar) {
      this.lastBar = clock.bar;
      this.preset = randomInt(this.config.presets.length);
      this.broadcast("hdensity", [this.density]);
      this.broadcast("arousal", [this.arousal]);
    }
    if (!clock.beatStart) return;
    const [minCount, maxCount] = this.config.pulseCountRange,
      count = Math.max(
        minCount,
        Math.min(
          maxCount,
          Math.round(minCount + this.density * (maxCount - minCount)),
        ),
      ),
      beatSeconds = 60 / (clock.bpm || bandTempo()),
      preset = this.config.presets[this.preset],
      [lowDuration, highDuration] = this.config.durationMsRange,
      [lowVelocity, highVelocity] = this.config.velocityRange,
      base = lowVelocity + (highVelocity - lowVelocity) * this.arousal;
    for (let index = 0; index < count; index++) {
      const source =
          this.notes[(index + (clock.bar || 0)) % this.notes.length] ?? 60,
        octave =
          this.config.octaveOffsets[
            (index + this.preset) % this.config.octaveOffsets.length
          ],
        // Folded back if the offset pushed it out of the playable range. A guard rather than a
        // cure for anything measured: the 132.844 that was throwing came from the FM partner
        // inside `bleep()`, not from here — this bot's fundamental was 100. But adding 24
        // semitones to a note that arrived over the protocol is the shape that *can* overflow,
        // and folding preserves the pitch class the harmony sanctioned.
        note = playableRegister(source + octave) ?? source,
        duration =
          (lowDuration + (highDuration - lowDuration) * (1 - this.arousal)) /
          1000,
        velocity = this.shapeVelocity(base, note, {
          clock,
          division: index,
          divisions: count,
          voice: index % 2,
        });
      writtenOnStep(this.audio, clock.tick, clock.meter?.subdivision || 1, count, index, () => this.audio.bleep(
        note,
        duration,
        velocity,
        (index * beatSeconds) / count,
        preset,
        index % 2,
      ));
    }
  }
}

export class WhinyBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.whiny;
    this.density = this.config.defaultDensity;
    this.arousal = this.config.defaultArousal;
    this.valence = this.config.defaultValence;
    this.lastBar = null;
  }
  onMessage(message) {
    super.onMessage(message);
    if (message.address.endsWith("/arousal")) {
      const value = Number(message.args.at(-1));
      if (Number.isFinite(value))
        this.arousal = Math.max(0, Math.min(1, value));
    }
    if (message.address.endsWith("/valence")) {
      const value = Number(message.args.at(-1));
      if (Number.isFinite(value))
        this.valence = Math.max(0, Math.min(1, value));
    }
  }
  onTick(
    tick,
    clock,
  ) {
    if (clock.barStart && clock.bar !== this.lastBar) {
      this.lastBar = clock.bar;
      this.broadcast("valence", [this.valence]);
      this.broadcast("arousal", [this.arousal]);
    }
    if (
      !clock.beatStart ||
      (!clock.barStart &&
        unitRandom() >
          Math.max(this.config.triggerProbabilityFloor, this.density))
    )
      return;
    const fundamental = this.notes[(clock.bar || 0) % this.notes.length] ?? 60,
      [low, high] = this.config.durationSeconds,
      duration = low + (high - low) * (1 - this.arousal),
      velocity = this.shapeVelocity(0.25 + 0.55 * this.arousal, fundamental, {
        clock,
        amount: 0.65,
      });
    writtenOn(this.audio, clock.tick, clock.meter?.subdivision || 1, () => this.audio.whinyCluster(
      fundamental,
      duration,
      velocity,
      this.config,
      this.valence,
    ));
  }
}

export class GroanBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.groan;
    this.arousal = this.config.defaultArousal;
    this.valence = this.config.defaultValence;
    this.note = this.config.initialNote;
    this.eventIndex = 0;
    this.lastBar = null;
  }
  onMessage(message) {
    super.onMessage(message);
    if (message.address.endsWith("/notepool") && this.notes.length)
      this.note = this.notes[0];
    if (message.address.endsWith("/arousal")) {
      const value = Number(message.args.at(-1));
      if (Number.isFinite(value))
        this.arousal = Math.max(0, Math.min(1, value));
    }
    if (message.address.endsWith("/valence")) {
      const value = Number(message.args.at(-1));
      if (Number.isFinite(value))
        this.valence = Math.max(0, Math.min(1, value));
    }
  }
  nextEvent() {
    const previous = this.note,
      multiplier =
        this.config.transpositionMultiplier[0] +
        this.arousal *
          (this.config.transpositionMultiplier[1] -
            this.config.transpositionMultiplier[0]),
      transpose = weightedChoice(
        this.config.transpositions,
        this.config.transpositionWeights,
      ),
      [jitterLow, jitterHigh] = this.config.noteJitter;
    this.note =
      (((this.note % 36) + 36) % 36) +
      12 +
      ((transpose * multiplier) % 12) +
      jitterLow +
      unitRandom() * (jitterHigh - jitterLow);
    const slide =
      (Math.abs(this.note - previous) * this.config.slidePerSemitoneMs +
        unitRandom() * this.config.slideRandomMs) /
      1000;
    return { note: this.note, slide };
  }
  onTick(
    tick,
    clock,
  ) {
    if (clock.barStart && clock.bar !== this.lastBar) {
      this.lastBar = clock.bar;
      this.broadcast("valence", [this.valence]);
      this.broadcast("arousal", [this.arousal]);
    }
    if (!clock.beatStart) return;
    const beatMs = 60000 / (clock.bpm || bandTempo()),
      minimum =
        this.config.minimumDurationMs[0] +
        this.arousal *
          (this.config.minimumDurationMs[1] - this.config.minimumDurationMs[0]),
      interval =
        minimum +
        this.config.intervalRandomMs / 2 +
        (this.eventIndex * this.config.indexRandomMs) / 2,
      count = Math.max(
        1,
        Math.min(4, Math.round(beatMs / Math.max(50, interval))),
      ),
      base = 0.35 + 0.5 * this.arousal;
    for (let index = 0; index < count; index++) {
      const event = this.nextEvent(),
        voice = this.eventIndex % this.config.voiceCount,
        velocity = this.shapeVelocity(base, event.note, {
          clock,
          division: index,
          divisions: count,
          voice,
        });
      writtenOnStep(this.audio, clock.tick, clock.meter?.subdivision || 1, count, index, () => this.audio.groan(
        event.note,
        0.4 + 0.9 * this.valence,
        velocity,
        (index * beatMs) / count / 1000,
        event.slide,
        voice,
      ));
    }
    this.eventIndex = (this.eventIndex + 1) % this.config.voiceCount;
  }
}

export class WubBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.wub;
    this.density = this.config.defaultDensity;
    this.arousal = this.config.defaultArousal;
    this.valence = this.config.defaultValence;
    this.lastBar = null;
    this.voice = 0;
  }
  onMessage(message) {
    super.onMessage(message);
    for (const key of ["arousal", "valence"])
      if (message.address.endsWith(`/${key}`)) {
        const value = Number(message.args.at(-1));
        if (Number.isFinite(value)) this[key] = Math.max(0, Math.min(1, value));
      }
  }
  fundamental() {
    const lowest = Math.min(...this.notes),
      pc = ((lowest % 12) + 12) % 12,
      [low, high] = this.config.fundamentalRandom;
    return this.config.fundamentalBase + pc + low + unitRandom() * (high - low);
  }
  onTick(
    tick,
    clock,
  ) {
    if (clock.barStart && clock.bar !== this.lastBar) {
      this.lastBar = clock.bar;
      const centroid =
          440 * 2 ** ((this.fundamental() - 69) / 12) * (1 + this.arousal * 2),
        panning =
          this.config.panningRange[0] +
          unitRandom() *
            (this.config.panningRange[1] - this.config.panningRange[0]);
      this.broadcast("hdensity", [this.density]);
      this.broadcast("valence", [this.valence]);
      this.broadcast("arousal", [this.arousal]);
      this.broadcast("centroid", [centroid]);
      this.broadcast("panning", [panning]);
    }
    if (!clock.beatStart) return;
    const [minCount, maxCount] = this.config.eventCountRange,
      count = Math.max(
        minCount,
        Math.round(minCount + this.density * (maxCount - minCount)),
      ),
      beatSeconds = 60 / (clock.bpm || bandTempo()),
      [lowDuration, highDuration] = this.config.durationRange,
      base = 0.3 + 0.55 * this.arousal;
    for (let index = 0; index < count; index++) {
      const note = this.fundamental(),
        duration =
          lowDuration + (highDuration - lowDuration) * (1 - this.arousal),
        voice = (this.voice + index) % this.config.voiceCount,
        preset = this.config.presets[voice % this.config.presets.length],
        velocity = this.shapeVelocity(base, note, {
          clock,
          division: index,
          divisions: count,
          voice,
        });
      writtenOnStep(this.audio, clock.tick, clock.meter?.subdivision || 1, count, index, () => this.audio.wubPluck(
        note,
        duration,
        velocity,
        (index * beatSeconds) / count,
        preset,
        voice,
      ));
    }
    this.voice = (this.voice + count) % this.config.voiceCount;
  }
}

export class AtmosphereBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.atmosphere;
    this.pitch = this.config.defaultNote + this.config.octaveOffset;
    this.dirty = true;
    this.preset = randomInt(this.config.resonatorGainPresets.length);
    this.lastBar = null;
  }
  onMessage(message) {
    const previous = this.notes.join(",");
    super.onMessage(message);
    if (
      message.address.endsWith("/notepool") &&
      this.notes.join(",") !== previous
    ) {
      // `this.notes` arrives over the protocol, so the offset could in principle push the sum
      // past what MIDI 2 can carry. In practice it cannot: this takes the *lowest* pool member
      // and adds 12, so the fold needs a pool whose lowest note is above 116. Kept as a guard
      // and recorded as one — see research/upstream-ports/wave5-51-57.md.
      this.pitch = playableRegister(Math.min(...this.notes) + this.config.octaveOffset)
        ?? Math.min(...this.notes);
      this.dirty = true;
    }
  }
  onTick(
    tick,
    clock,
  ) {
    if (!clock.barStart || clock.bar === this.lastBar) return;
    this.lastBar = clock.bar;
    if (!this.dirty && clock.bar % 4 !== 0) return;
    this.dirty = false;
    this.preset = randomInt(this.config.resonatorGainPresets.length);
    const barSeconds =
        ((((clock.meter?.numerator || bandMeter().numerator) * 4) /
          (clock.meter?.denominator || bandMeter().denominator)) *
          60) /
        (clock.bpm || bandTempo()),
      duration = Math.max(
        this.config.minimumSegmentSeconds,
        barSeconds * 4 + 0.1,
      );
    // (Written to the next bar of its four, where it is next renewed.)
    writtenOn(this.audio, clock.tick, (4 - (clock.bar % 4)) * (clock.meter?.pulsesPerBar || bandMeter().pulsesPerBar), () => this.audio.atmosphere(
      this.pitch,
      duration,
      this.config.resonatorGainPresets[this.preset],
      this.config.resonance,
    ));
  }
}

export class TextureBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.texture;
    this.active = [];
    this.referenceSpectrum = null;
    this.lastBar = null;
  }
  pitchForVoice(index, timbre) {
    const source =
      this.notes[(index + (this.instancePhase || 0)) % this.notes.length] ?? 60;
    let pitch = source;
    while (pitch < timbre.low) pitch += 12;
    while (pitch > timbre.high) pitch -= 12;
    return pitch < timbre.low || pitch > timbre.high
      ? Math.max(timbre.low, Math.min(timbre.high, pitch))
      : pitch;
  }
  regenerate(clock) {
    const count = Math.max(
        0,
        Math.min(
          this.config.voiceCount,
          Math.round(this.density * this.config.voiceCount),
        ),
      ),
      barSeconds =
        ((((clock.meter?.numerator || bandMeter().numerator) * 4) /
          (clock.meter?.denominator || bandMeter().denominator)) *
          60) /
        (clock.bpm || bandTempo()),
      duration = Math.max(
        this.config.minimumDurationSeconds,
        barSeconds * this.config.holdBars,
      );
    this.active = [];
    for (let index = 0; index < count; index++) {
      const provisional = this.notes[index % this.notes.length] ?? 60,
        timbre = chooseTextureTimbre(
          TEXTURE_TIMBRES,
          provisional,
          this.referenceSpectrum,
          this.config.nearestTimbres,
        ),
        pitch = this.pitchForVoice(index, timbre),
        velocity = this.shapeVelocity(0.3 + 0.5 * this.density, pitch, {
          clock,
          voice: index,
          division: index,
          divisions: Math.max(1, count),
          amount: 0.55,
        });
      this.active.push({ pitch, timbre });
      // (Written to where it is held to, together: their spread of 35 ms how they are played.)
      writtenOn(this.audio, clock.tick, (this.config.holdBars - ((clock.bar || 0) % this.config.holdBars)) * (clock.meter?.pulsesPerBar || bandMeter().pulsesPerBar), () => this.audio.textureGrain(
        pitch,
        duration,
        velocity,
        index * 0.035,
        timbre,
        index,
      ));
    }
    if (this.active.length)
      this.referenceSpectrum = this.active.at(-1).timbre.spectrum;
    this.broadcast("vdensity", [count / this.config.voiceCount]);
  }
  onTick(
    tick,
    clock,
  ) {
    if (!clock.barStart || clock.bar === this.lastBar) return;
    this.lastBar = clock.bar;
    if (
      clock.bar % this.config.holdBars === 0 ||
      this.active.length !== Math.round(this.density * this.config.voiceCount)
    )
      this.regenerate(clock);
  }
}

export class GranuBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.granu;
    this.arousal = this.config.defaultArousal;
    this.valence = this.config.defaultValence;
    this.lastBar = null;
  }
  onMessage(message) {
    super.onMessage(message);
    for (const key of ["arousal", "valence"])
      if (message.address.endsWith(`/${key}`)) {
        const value = Number(message.args.at(-1));
        if (Number.isFinite(value)) this[key] = Math.max(0, Math.min(1, value));
      }
  }
  onTick(
    tick,
    clock,
  ) {
    if (!clock.barStart || clock.bar === this.lastBar) return;
    this.lastBar = clock.bar;
    const barSeconds =
        ((((clock.meter?.numerator || bandMeter().numerator) * 4) /
          (clock.meter?.denominator || bandMeter().denominator)) *
          60) /
        (clock.bpm || bandTempo()),
      duration = Math.max(1, barSeconds + 0.1),
      centroid = 50 + (3000 - 50) * this.arousal;
    writtenOn(this.audio, clock.tick, clock.meter?.pulsesPerBar || bandMeter().pulsesPerBar, () => this.audio.granularSlurp(duration, this.arousal, this.valence, this.config));
    this.broadcast("valence", [this.valence]);
    this.broadcast("arousal", [this.arousal]);
    this.broadcast("centroid", [centroid]);
  }
}

export class ChichichiBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.chichichi;
    this.patterns = Array.from({ length: 4 }, () => this.newPattern());
    this.state = 0;
  }
  newPattern() {
    const pattern = Array.from({ length: this.config.patternLength }, () =>
      unitRandom() < this.config.cellProbability ? 1 : 0,
    );
    if (!pattern.some(Boolean)) pattern[randomInt(pattern.length)] = 1;
    return pattern;
  }
  changeState(command = "any") {
    if (command === "next")
      this.state = (this.state + 1) % this.patterns.length;
    else if (command === "previous")
      this.state =
        (this.state + this.patterns.length - 1) % this.patterns.length;
    else this.state = randomInt(this.patterns.length);
    this.patterns[this.state] = this.newPattern();
  }
  onMessage(message) {
    super.onMessage(message);
    if (message.address.endsWith("/statechange")) {
      const command = String(message.args.at(-1));
      if (this.config.stateNames.includes(command)) this.changeState(command);
    }
  }
  onTick(
    tick,
    clock,
  ) {
    if (clock.barStart && unitRandom() < this.config.randomStateProbability)
      this.changeState("any");
    const steps = clock.meter?.pulsesPerBar || bandMeter().pulsesPerBar,
      index =
        Math.floor(
          ((clock.tickInBar || 0) * this.config.patternLength) / steps,
        ) % this.config.patternLength;
    if (this.patterns[this.state][index])
      writtenOn(this.audio, clock.tick, 1, () => this.audio.chichichi(
        index,
        this.state,
        60 / (clock.bpm || bandTempo()),
        this.config,
      ));
  }
}

export class DerivationsBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.derivations;
    this.lastBar = null;
  }
  onTick(
    tick,
    clock,
  ) {
    if (!clock.barStart || clock.bar === this.lastBar) return;
    this.lastBar = clock.bar;
    const [low, high] = this.config.densityRange,
      density = low + unitRandom() * (high - low),
      barSeconds =
        ((((clock.meter?.numerator || bandMeter().numerator) * 4) /
          (clock.meter?.denominator || bandMeter().denominator)) *
          60) /
        (clock.bpm || bandTempo()),
      duration = Math.max(
        0.5,
        (barSeconds * this.config.globalLengthFactor) / 2,
      );
    writtenOn(this.audio, clock.tick, clock.meter?.pulsesPerBar || bandMeter().pulsesPerBar, () => this.audio.derivations(duration, density, this.config));
  }
}

export class DeciderBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.decider;
    this.inputs = Array(this.config.numInputs).fill(0.5);
    this.state = Array(this.config.numElements).fill(
      Math.floor(this.config.numStates / 2),
    );
    this.leaf = -1;
    this.calls = 0;
  }
  async start() {
    // Microphone features are an optional enhancement, not part of autonomous
    // Decider behavior. Never prompt merely because the bot was loaded.
  }
  updateInputs() {
    const features = this.input?.features?.();
    if (!features) return;
    const hzToMidi = (hz) => 69 + 12 * Math.log2(Math.max(0.001, hz) / 440);
    this.inputs[2] = hzToMidi(features.centroid || 440) / 127;
    this.inputs[3] =
      hzToMidi(features.frequency || features.centroid || 440) / 127;
    this.inputs[4] = (features.loudness || 0) * 10;
  }
  process() {
    this.updateInputs();
    for (
      let index = this.config.numInputs;
      index < this.state.length;
      index++
    ) {
      const source = this.inputs[index % this.config.numInputs] ?? 0.5,
        delta = source > 0.5 ? 1 : -1;
      this.state[index] =
        (this.state[index] + delta + this.config.numStates) %
        this.config.numStates;
    }
    const sum = this.state
        .slice(this.config.numInputs)
        .reduce((total, value) => total + value, 0),
      next = Math.floor(
        (sum /
          Math.max(
            1,
            (this.state.length - this.config.numInputs) *
              (this.config.numStates - 1),
          )) *
          this.config.numElements,
      );
    this.leaf = Math.max(0, Math.min(this.config.numElements - 1, next));
  }
  onTick(tick) {
    const previous = this.leaf;
    this.process();
    if (
      this.calls % this.config.triggerEveryCalls === 0 &&
      this.leaf !== previous
    )
      writtenOn(this.audio, tick, Math.max(1, this.config.triggerEveryCalls), () => this.audio.deciderBreath(this.leaf, this.config));
    this.calls++;
  }
}

export class RunglerBot extends Agent {
  constructor(...args) {
    super(...args);
    this.valence = 0.5;
    this.arousal = 0.5;
  }
  onMessage(message) {
    super.onMessage(message);
    if (message.address.endsWith("/valence"))
      this.valence = this.normalizedControl(message.args.at(-1), this.valence);
    if (message.address.endsWith("/arousal"))
      this.arousal = this.normalizedControl(message.args.at(-1), this.arousal);
  }
  normalizedControl(value, fallback) {
    const number = Number(value);
    return Number.isFinite(number)
      ? Math.max(0, Math.min(1, number))
      : fallback;
  }
  onTick(tick, clock) {
    const every = Math.max(1, Math.round(8 - this.arousal * 7));
    if (tick % every === 0) {
      const config = CONFIG.rungler,
        note =
          config.pitchRange[0] +
          randomInt(config.pitchRange[1] - config.pitchRange[0] + 1),
        waveform = weightedChoice(
          ["square", "sawtooth"],
          config.waveformWeights,
        ),
        velocity = this.shapeVelocity(0.3 + (1 - this.valence) * 0.3, note, {
          clock,
        });
      writtenOn(this.audio, tick, every, () => this.audio.rungler(this.valence, this.arousal, note, waveform, velocity));
    }
  }
}
