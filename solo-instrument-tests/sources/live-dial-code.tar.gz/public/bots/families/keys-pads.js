// The keys and pads: bowed strings, the drones, the pads (the x-suite's among them) and the Rhodes.
// Moved verbatim from public/agents.js in its per-family split (28 September 2026; RESEARCH_BACKLOG, the second
// queue). agents.js registers them (BOT_REGISTRY) and re-exports each, so an import from it is as it was.
import { Agent } from "../../framework/index.js";
import { STOCHASTIC_CONFIG as CONFIG } from "../../stochastic-config.js";
import {
  complementaryActivityMask, cycleIndexAtPhrasePosition, normalizeActivityMask, parseCompoundIntent,
  serializeIntentFields,
} from "../../shared/intentions.js";
import {
  interpolateCurvePoints, randomFivePointCurve, randomInt, scramble, unitRandom, weightedChoice,
} from "../../shared/stochastic.js";
import { mostCommonPitchClass, phrasePosition } from "../../shared/seasons.js";
import { motifNotes } from "../../shared/motifs.js";
import { parseChordPlan } from "../../shared/harmony.js";
import { pitchClass } from "../../shared/pitch.js";
import {bandTempo,bandMeter,bandPhraseBars} from '../../shared/opening-time.js';
import {toNextAttack,writtenOn,beatsInTicks,ticksUntil,phraseTicksLeft} from "../lib/written.js";

// (A chord written to its plan's next chord, or its phrase's end: its plan read ahead, lib/written.js.)
function toNextChord(bot,clock,index){
  const bars=clock.meter.phraseBars||bot.phraseBars;
  return ticksUntil(clock,ahead=>ahead.bar%bars===0&&ahead.tickInBar===0||bot.currentPlan(ahead).index!==index,phraseTicksLeft(clock,bars));
}

export class BowedBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.bowed;
    this.chords = [];
    this.chordDurations = [];
    this.phraseBars = this.config.phraseBars;
    this.lastChord = -1;
    this.lastPhrase = -1;
    this.curve = [];
    this.generateCurve();
  }
  generateCurve() {
    this.curve = randomFivePointCurve({
      xRanges: this.config.phraseCurveXRanges,
      terminalWeights: this.config.phraseCurveTerminalWeights,
    });
  }
  onMessage(message) {
    super.onMessage(message);
    if (message.address.endsWith("/plan/chords")) {
      const plan = parseChordPlan(
        message.args.slice(message.args[0] === message.source ? 1 : 0),
      );
      if (plan.length) this.chords = plan;
    }
    if (message.address.endsWith("/plan/chordDuration")) {
      const values = message.args
        .map(Number)
        .filter((value) => Number.isFinite(value) && value > 0);
      if (values.length) this.chordDurations = values;
    }
    if (message.address.endsWith("/phraselength")) {
      const value = Math.round(Number(message.args.at(-1)));
      if (value > 0) this.phraseBars = Math.min(128, value);
    }
  }
  currentPlan(clock) {
    const chords = this.chords.length ? this.chords : [this.notes],
      durations =
        this.chordDurations.length === chords.length
          ? this.chordDurations
          : Array(chords.length).fill(
              (this.phraseBars * this.config.assumedBeatsPerBar) /
                chords.length,
            ),
      position =
        (clock.bar % (clock.meter.phraseBars || this.phraseBars)) *
          this.config.assumedBeatsPerBar +
        (clock.beat || 0);
    let total = 0,
      index = durations.length - 1;
    for (let i = 0; i < durations.length; i++) {
      total += durations[i];
      if (position < total) {
        index = i;
        break;
      }
    }
    return {
      index,
      chord: chords[index] || chords[0],
      position: position / (this.phraseBars * this.config.assumedBeatsPerBar),
    };
  }
  voiceChord(values) {
    const pitchClasses = values
        .map(pitchClass)
        .filter((value) => value !== null),
      unique = [...new Set(pitchClasses)].sort((a, b) => a - b);
    if (!unique.length) return [60, 67];
    const right = [];
    let previous = 59;
    for (const pc of unique) {
      let note = 60 + pc;
      while (note <= previous) note += 12;
      right.push(note);
      previous = note;
    }
    const bass = Math.max(36, Math.min(59, Math.min(...right) - 24));
    return [bass, ...right];
  }
  onTick(
    tick,
    clock,
  ) {
    if (clock.phraseStart && clock.phrase !== this.lastPhrase) {
      this.lastPhrase = clock.phrase;
      this.lastChord = -1;
      this.generateCurve();
    }
    if (!clock.beatStart && !clock.phraseStart) return;
    const plan = this.currentPlan(clock),
      curve = Math.max(
        0,
        Math.min(1, interpolateCurvePoints(this.curve, plan.position)),
      ),
      probability = Math.max(
        this.config.minimumAttackProbability,
        Math.min(1, this.density * curve),
      );
    if (
      plan.index === this.lastChord ||
      (!clock.phraseStart && !this.instanceAllows(clock, 19, probability))
    )
      return;
    this.lastChord = plan.index;
    const notes = this.voiceChord(plan.chord),
      duration =
        this.config.durationSecondsRange[0] +
        unitRandom() *
          (this.config.durationSecondsRange[1] -
            this.config.durationSecondsRange[0]);
    writtenOn(this.audio, clock.tick, toNextChord(this, clock, plan.index), () => this.audio.bowedTexture(notes, duration, 0.25 + 0.65 * curve));
  }
}

export class DroneBot extends Agent {
  constructor(...args) {
    super(...args);
    this.memoryDevelopmentEnabled = true;
    this.config = CONFIG.drone;
    this.chords = [];
    this.chordDurations = [];
    this.phraseBars = this.config.phraseBars;
    this.currentPitch = null;
    this.lastChord = -1;
    // How much of its own note is left, in beats. See `onTick` for why it renews at all.
    this.remainingBeats = 0;
  }
  onMessage(message) {
    super.onMessage(message);
    if (message.address.endsWith("/notepool")) this.lastChord = -1;
    if (message.address.endsWith("/plan/chords")) {
      const values = parseChordPlan(message.args);
      if (values.length) {
        this.chords = values;
        this.lastChord = -1;
      }
    }
    if (message.address.endsWith("/plan/chordDuration")) {
      const values = message.args
        .map(Number)
        .filter((value) => Number.isFinite(value) && value > 0);
      if (values.length) {
        this.chordDurations = values;
        this.lastChord = -1;
      }
    }
    if (message.address.endsWith("/phraselength")) {
      const value = Math.round(Number(message.args.at(-1)));
      if (value > 0) this.phraseBars = Math.min(128, value);
    }
  }
  mostCommonPitchClass() {
    const counts = new Map();
    for (const chord of this.chords)
      for (const note of chord) {
        const pc = pitchClass(note);
        if (pc !== null) counts.set(pc, (counts.get(pc) || 0) + 1);
      }
    return [...counts].sort((a, b) => b[1] - a[1] || a[0] - b[0])[0]?.[0];
  }
  onMemoryRecall(motifs=[]){
    // An answer arrives best first: MemoryBot ranked it for this bot, and the
    // first usable motif by anyone else is the one it chose. Reading the list
    // backwards meant "the newest match" while a query answered with the newest
    // matches; it would mean "the worst of them" now that the answer is chosen.
    const recalled=motifs.find(motif=>
      motif.author!==this.instanceId&&
      motifNotes(motif).some(event=>event.pitches?.some(Number.isFinite))
    );
    if(!recalled)return;
    const pitches=motifNotes(recalled).flatMap(event=>event.pitches||[])
      .map(Number).filter(Number.isFinite);
    if(pitches.length){this.notes=[...new Set(pitches)];this.chords=[];this.lastChord=-1;this.useMemoryMotif(recalled)}
  }
  currentPlan(clock) {
    const chords = this.chords.length ? this.chords : [this.notes],
      durations =
        this.chordDurations.length === chords.length
          ? this.chordDurations
          : Array(chords.length).fill(
              (this.phraseBars * this.config.assumedBeatsPerBar) /
                chords.length,
            ),
      position =
        (clock.bar % (clock.meter.phraseBars || this.phraseBars)) *
          this.config.assumedBeatsPerBar +
        (clock.beat || 0);
    let total = 0,
      index = durations.length - 1;
    for (let i = 0; i < durations.length; i++) {
      total += durations[i];
      if (position < total) {
        index = i;
        break;
      }
    }
    return { index, chord: chords[index], duration: durations[index] };
  }
  choosePitch(chord) {
    const pcs = [
        ...new Set(chord.map(pitchClass).filter((value) => value !== null)),
      ],
      common = this.mostCommonPitchClass();
    let pc = pcs.includes(common)
      ? common
      : (pcs[0] ?? pitchClass(this.notes[0]));
    if (this.currentPitch != null)
      pc = pcs.reduce(
        (best, value) =>
          Math.abs(this.config.baseMidi + value - this.currentPitch) <
          Math.abs(this.config.baseMidi + best - this.currentPitch)
            ? value
            : best,
        pc,
      );
    let note = this.config.baseMidi + pc;
    while (note > this.config.range[1]) note -= 12;
    while (note < this.config.range[0]) note += 12;
    return note;
  }
  onTick(
    tick,
    clock,
  ) {
    if(clock.phraseStart&&clock.phrase!==this.lastMemoryPhrase&&
      (clock.phrase||0)%4===0){
      this.lastMemoryPhrase=clock.phrase;
      this.consultMemory({limit:12});
    }
    if (!clock.beatStart && !clock.phraseStart) return;
    const plan = this.currentPlan(clock);
    // **A drone renews its own note, but only to cover a gap — never to pre-empt the plan.**
    //
    // It used to speak only when the chord *index* changed, and `currentPlan` derives that
    // index from the plan's own durations — so with a single chord in the plan, or none at all
    // (the fallback is `[this.notes]`, one chord spanning the phrase), the index never changes
    // and the bot sounded one pad and then nothing until a fresh plan message reset
    // `lastChord`. That is the fault this repairs.
    //
    // **The renewal applies only where the index physically cannot change**, which is the
    // narrowest form of the repair and the only one this port's record supports. With two or
    // more chords in the plan, "retriggers only when the plan chord changes" stands exactly as
    // `drone.md` states it.
    //
    // An earlier version renewed on every plan, a beat early to overlap. Against the chord
    // durations this repository's own harmony sources publish — `ModalChordBot` sends one beat
    // per chord, `MilesChordBot` `[1, 1, 2, 2]` — that gave two attacks per chord on a
    // four-beat plan and one on every beat for a one-beat plan: a quarter-note pulse, not a
    // drone. The overlap also put the first note's note-off inside the renewed note on the
    // single-channel MIDI path the record names. Both are gone with the restriction.
    //
    // What it does not touch: a multi-chord plan whose durations sum to less than the phrase.
    // `currentPlan` clamps the index at the last chord there rather than cycling the
    // progression, so the drone states the progression and then holds. That is a defensible
    // reading, `BowedBot` and `PadBot` share the same clamp, and nothing read for these ports
    // says which the patches do — so it is recorded as an open question rather than changed.
    const canAdvance = (this.chords.length ? this.chords : [this.notes]).length > 1;
    if (this.remainingBeats > 0) this.remainingBeats -= 1;
    if (plan.index === this.lastChord && (canAdvance || this.remainingBeats > 0)) return;
    this.lastChord = plan.index;
    this.currentPitch = this.choosePitch(plan.chord);
    const duration = Math.max(
      this.config.minimumSeconds,
      (plan.duration * 60) / (clock.bpm || bandTempo()),
    );
    this.remainingBeats = (duration * (clock.bpm || bandTempo())) / 60;
    writtenOn(this.audio, clock.tick, toNextChord(this, clock, plan.index), () => this.audio.dronePad(this.currentPitch, duration, this.density));
  }
}

export class PadBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.pad;
    this.chords = [];
    this.chordDurations = [];
    this.phraseBars = this.config.phraseBars;
    this.lastChord = -1;
  }
  onMessage(message) {
    super.onMessage(message);
    if (message.address.endsWith("/notepool")) this.lastChord = -1;
    if (message.address.endsWith("/plan/chords")) {
      const values = parseChordPlan(message.args);
      if (values.length) {
        this.chords = values;
        this.lastChord = -1;
      }
    }
    if (message.address.endsWith("/plan/chordDuration")) {
      const values = message.args
        .map(Number)
        .filter((value) => Number.isFinite(value) && value > 0);
      if (values.length) {
        this.chordDurations = values;
        this.lastChord = -1;
      }
    }
    if (message.address.endsWith("/phraselength")) {
      const value = Math.round(Number(message.args.at(-1)));
      if (value > 0) this.phraseBars = Math.min(128, value);
    }
  }
  currentPlan(clock) {
    const chords = this.chords.length ? this.chords : [this.notes],
      durations =
        this.chordDurations.length === chords.length
          ? this.chordDurations
          : Array(chords.length).fill(
              (this.phraseBars * this.config.assumedBeatsPerBar) /
                chords.length,
            ),
      position =
        (clock.bar % (clock.meter.phraseBars || this.phraseBars)) *
          this.config.assumedBeatsPerBar +
        (clock.beat || 0);
    let total = 0,
      index = durations.length - 1;
    for (let i = 0; i < durations.length; i++) {
      total += durations[i];
      if (position < total) {
        index = i;
        break;
      }
    }
    return {
      index,
      chord: chords[index],
      duration: durations[index],
      phrasePosition:
        position / (this.phraseBars * this.config.assumedBeatsPerBar),
    };
  }
  voiceChord(chord) {
    const pcs = [
        ...new Set(chord.map(pitchClass).filter((value) => value !== null)),
      ].sort((a, b) => a - b),
      count = Math.max(
        1,
        Math.min(pcs.length, Math.ceil(pcs.length * this.density)),
      ),
      selected = pcs.slice(0, count),
      notes = [];
    let previous = this.config.range[0] - 1;
    for (const pc of selected) {
      let note = this.config.baseMidi + pc;
      while (note <= previous) note += 12;
      if (note <= this.config.range[1]) {
        notes.push(note);
        previous = note;
      }
    }
    return notes.length ? notes : [this.config.baseMidi];
  }
  onTick(
    tick,
    clock,
  ) {
    if (!clock.beatStart && !clock.phraseStart) return;
    const plan = this.currentPlan(clock);
    if (plan.index === this.lastChord) return;
    this.lastChord = plan.index;
    const notes = this.voiceChord(plan.chord),
      duration = Math.max(
        this.config.minimumSeconds,
        (plan.duration * 60) / (clock.bpm || bandTempo()),
      ),
      openness =
        this.config.filterStart +
        (this.config.filterEnd - this.config.filterStart) *
          Math.max(0, Math.min(1, plan.phrasePosition));
    writtenOn(this.audio, clock.tick, toNextChord(this, clock, plan.index), () => this.audio.padChord(notes, duration, this.density, openness));
  }
}

export class NewDroneBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.newDrone;
    this.activityMask = [
      ...weightedChoice(this.config.sourceMasks, this.config.sourceMaskWeights),
    ];
    this.receivedMasks = [];
    this.lastPhrase = -1;
    this.lastCell = -1;
  }
  onMessage(message) {
    super.onMessage(message);
    const intent = parseCompoundIntent(message);
    if (
      intent?.activityMask &&
      intent.sender !== "ae_newDroneBOT" &&
      intent.sender !== this.instanceId
    )
      this.receivedMasks.push(intent.activityMask);
    else if (message.address === "/broadcast/intent/activityMask")
      this.receivedMasks.push(normalizeActivityMask(message.args));
  }
  beginPhrase(phrase) {
    if (this.lastPhrase >= 0 && this.receivedMasks.length) {
      const complement = complementaryActivityMask(this.receivedMasks),
        ranked = complement
          .map((value, index) => ({ value, index }))
          .sort((a, b) => b.value - a.value || a.index - b.index),
        mask = Array(16).fill(0);
      for (const item of scramble(
        ranked.slice(0, this.config.activeCells * 2),
      ).slice(0, this.config.activeCells))
        mask[item.index] = 1;
      this.activityMask = mask;
    }
    this.receivedMasks = [];
    this.lastPhrase = phrase;
    this.lastCell = -1;
    this.broadcast(
      "intent",
      serializeIntentFields("ae_newDroneBOT", {
        activityMask: this.activityMask,
      }),
    );
  }
  highNote() {
    const pcs = [
        ...new Set(
          this.notes.map(pitchClass).filter((value) => value !== null),
        ),
      ],
      pc = pcs[randomInt(pcs.length)] ?? 0;
    let note = this.config.range[0] + pc;
    while (note < this.config.range[0]) note += 12;
    while (note > this.config.range[1]) note -= 12;
    return note;
  }
  onTick(
    tick,
    clock,
  ) {
    if (clock.phraseStart && clock.phrase !== this.lastPhrase)
      this.beginPhrase(clock.phrase);
    const cell = cycleIndexAtPhrasePosition(clock, 16);
    if (cell === this.lastCell) return;
    this.lastCell = cell;
    if (!this.activityMask[cell]) return;
    const duration =
      this.config.durationSecondsRange[0] +
      randomInt(
        this.config.durationSecondsRange[1] -
          this.config.durationSecondsRange[0],
      );
    // (Written to its next cell of the phrase's sixteen.)
    const bars = clock.meter.phraseBars || bandPhraseBars();
    writtenOn(this.audio, clock.tick, ticksUntil(clock, (ahead) => cycleIndexAtPhrasePosition(ahead, 16) !== cell, phraseTicksLeft(clock, bars)), () => this.audio.highDrone(this.highNote(), duration, 0.35 + 0.5 * this.density));
  }
}

export class MhDroneBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.mhDrone;
    this.targetDensity = this.density;
    this.targetActivity = this.config.activity;
    this.activity = this.targetActivity;
    this.playing = true;
    this.stateUntilTick = null;
    this.stateStarted = false;
  }
  onMessage(message) {
    if (!message.address.endsWith("/hdensity")) super.onMessage(message);
    if (message.address.endsWith("/hdensity")) {
      const value = Number(message.args.at(-1));
      if (Number.isFinite(value))
        this.targetDensity = Math.max(0, Math.min(1, value));
    }
    if (message.address.endsWith("/vdensity")) {
      const value = Number(message.args.at(-1));
      if (Number.isFinite(value))
        this.targetActivity = Math.max(0, Math.min(1, value));
    }
  }
  smooth() {
    const amount = this.config.controlSmoothing;
    this.density += (this.targetDensity - this.density) * amount;
    this.activity += (this.targetActivity - this.activity) * amount;
  }
  durationSeconds(playing) {
    const [low, high] = this.config.durationRandomPercentRange,
      variation = (low + randomInt(high - low)) / 100;
    return playing
      ? variation * (this.config.playDurationScale * (1 - this.activity)) + 1
      : variation * (this.config.breakDurationScale * this.activity) + 1;
  }
  durationTicks(clock, playing) {
    return Math.max(
      1,
      Math.round(
        ((this.durationSeconds(playing) * (clock.bpm || bandTempo())) / 60) *
          (clock.meter?.subdivision || bandMeter().subdivision),
      ),
    );
  }
  note() {
    const pcs = [
        ...new Set(
          this.notes.map(pitchClass).filter((value) => value !== null),
        ),
      ],
      pc = pcs[randomInt(pcs.length)] ?? randomInt(12),
      octave = this.config.octaves[randomInt(this.config.octaves.length)];
    return pc + 12 * octave;
  }
  tremolo() {
    return (
      this.config.tremoloBaseRange[0] +
      unitRandom() *
        (this.config.tremoloBaseRange[1] - this.config.tremoloBaseRange[0]) +
      unitRandom() * this.density * this.config.tremoloDensityRange
    );
  }
  onTick(
    tick,
    clock,
  ) {
    if (clock.beatStart) this.smooth();
    if (this.stateUntilTick == null || tick >= this.stateUntilTick) {
      if (this.stateUntilTick != null) this.playing = !this.playing;
      this.stateUntilTick = tick + this.durationTicks(clock, this.playing);
      this.stateStarted = false;
    }
    if (this.playing && !this.stateStarted) {
      this.stateStarted = true;
      // (Written for the ticks it plays: its state's.)
      writtenOn(this.audio, clock.tick, Math.max(1, this.stateUntilTick - tick), () => this.audio.wubDrone(
        this.note(),
        this.durationSeconds(true),
        this.tremolo(),
        this.density,
      ));
    }
  }
}

export class RhodesBot extends Agent {
  constructor(...args) {
    super(...args);
    this.memoryDevelopmentEnabled = true;
  }

  onMemoryRecall(motifs=[]){
    // Best first, as DroneBot's recall explains.
    const recalled=motifs.find(motif=>
      motif.author!==this.instanceId&&
      motifNotes(motif).some(event=>event.pitches?.length)
    );
    if(recalled){
      const pitches=motifNotes(recalled).flatMap(event=>event.pitches||[])
        .map(Number).filter(Number.isFinite);
      if(pitches.length){this.notes=[...new Set(pitches)];this.useMemoryMotif(recalled)}
    }
    this.memoryVoicingShift=((this.memoryVoicingShift||0)+1)%CONFIG.rhodes.voicingOffsets.length;
  }
  onTick(
    tick,
    clock,
  ) {
    clock = this.interpretClock(clock);
    const config = CONFIG.rhodes,
      minGap = Math.max(
        1,
        Math.ceil(clock.meter.subdivision * config.minimumBeatsBetweenAttacks),
      );
    if (
      !this.rhythm(clock, config)[clock.tickInBar] ||
      (this.lastAttackTick != null && tick - this.lastAttackTick < minGap)
    )
      return;
    this.lastAttackTick = tick;
    const offsets =
        config.voicingOffsets[(clock.bar+(this.memoryVoicingShift||0)) % config.voicingOffsets.length],
      root = Math.min(...this.notes);
    const voiced = offsets.map((offset) => root + offset);
    writtenOn(this.audio, clock.tick, toNextAttack(this.rhythm(clock, config), clock.tickInBar, { ticks: clock.meter.pulsesPerBar, gap: minGap }), () => this.audio.rhodes(voiced));
  }
}

export class XPadBot extends PadBot {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.xPad;
    this.harmonicRhythm = this.config.defaultHarmonicRhythm;
    this.progress = 0;
    this.enabled = true;
    this.exiting = false;
    this.pendingChord = true;
  }
  onMessage(message) {
    super.onMessage(message);
    if (message.address.endsWith("/notepool")) this.pendingChord = true;
    if (message.address.endsWith("/harmrhythm")) {
      const value = Number(message.args.at(-1));
      if (Number.isFinite(value) && value > 0) this.harmonicRhythm = value;
    }
    if (message.address.endsWith("/progress")) {
      const value = Number(message.args.at(-1));
      if (Number.isFinite(value))
        this.progress = Math.max(0, Math.min(1, value));
    }
    if (message.address.endsWith("/density")) {
      const value = Number(message.args.at(-1));
      if (Number.isFinite(value))
        this.density = Math.max(0, Math.min(1, value));
    }
    if (message.address.endsWith("/onoff"))
      this.enabled = Number(message.args.at(-1)) !== 0;
    if (message.address.endsWith("/exiting"))
      this.exiting = Number(message.args.at(-1)) !== 0;
  }
  onTick(tick, clock) {
    if (!this.enabled || this.exiting || !this.pendingChord || !clock.beatStart)
      return;
    this.pendingChord = false;
    const notes = this.voiceChord(this.notes),
      duration = Math.max(
        this.config.minimumSeconds,
        (this.harmonicRhythm * 60) / (clock.bpm || bandTempo()),
      ),
      openness =
        this.config.filterStart +
        (this.config.filterEnd - this.config.filterStart) * this.progress;
    // (Written for its harmonic rhythm's beats.)
    writtenOn(this.audio, clock.tick, beatsInTicks(this.harmonicRhythm, clock.meter), () => this.audio.padChord(notes, duration, this.density, openness));
  }
}
