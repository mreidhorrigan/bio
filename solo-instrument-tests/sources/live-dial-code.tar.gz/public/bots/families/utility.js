// The utility bots: message monitors and routers, valence and arousal, MIDI and MIDI-guitar input, video, web and
// server bridges, the audio analyzer, the effects monitor, and the blank and template bots.
// Moved verbatim from public/agents.js in its per-family split (28 September 2026; RESEARCH_BACKLOG, the second
// queue). agents.js registers them (BOT_REGISTRY) and re-exports each, so an import from it is as it was.
import { Agent } from "../../framework/index.js";
import { STOCHASTIC_CONFIG as CONFIG } from "../../stochastic-config.js";
import { LegacyLanBridge } from "../../shared/network-bridge.js";
import { MessageRouter } from "../../shared/message-router.js";
import { MidiFeatureAnalyzer } from "../../shared/midi-analysis.js";
import { ProtocolMonitor } from "../../shared/protocol-monitor.js";
import { openVideoFeatures } from "../../shared/video-analysis.js";
import { pitchClass } from "../../shared/pitch.js";
import { randomAdditiveGrouping } from "../../shared/rhythm.js";
import { randomInt, unitRandom, weightedChoice } from "../../shared/stochastic.js";
import { subscribeMidiInputs } from "../../shared/midi-input.js";
import {bandPhraseBars,bandTempo,bandMeter} from '../../shared/opening-time.js';
import {writtenOn,writtenOnStep,beatsInTicks} from "../lib/written.js";

export class BlankBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.blank;
    this.notes = this.openingPool(this.config.openingRegister, { of: "collection" });
    this.density = this.config.defaultDensity;
    this.lastBar = null;
  }
  onTick(
    tick,
    clock,
  ) {
    if (clock.barStart && clock.bar !== this.lastBar) {
      this.lastBar = clock.bar;
      this.broadcast("hdensity", [this.density]);
    }
    if (!clock.beatStart || unitRandom() >= this.density) return;
    const note = this.notes[randomInt(this.notes.length)] ?? 60,
      duration = (this.config.noteDurationBeats * 60) / (clock.bpm || bandTempo()),
      velocity = this.shapeVelocity(this.config.velocity, note, { clock });
    writtenOn(this.audio, clock.tick, beatsInTicks(this.config.noteDurationBeats, clock.meter), () => this.audio.blankTriangle(note, duration, velocity));
  }
}

export class MonitorMessagesBot extends Agent {
  constructor(...args) {
    super(...args);
    this.monitor = new ProtocolMonitor(256);
  }
  onMessage(message) {
    this.monitor.capture(message);
  }
  onTick() {}
  snapshot() {
    return this.monitor.snapshot();
  }
  clear() {
    this.monitor.clear();
  }
}

export class ReassignMessagesBot extends Agent {
  constructor(...args) {
    super(...args);
    this.router = new MessageRouter();
  }
  onMessage(message) {
    if (message.address === "/agent/reassign/clear") {
      this.router.clear();
      return;
    }
    if (message.address === "/agent/reassign") {
      const rule = message.args?.[0];
      if (rule && typeof rule === "object") this.router.addRule(rule);
      return;
    }
    if (
      message.source === this.instanceId ||
      message.source === "ae_ReassignMessagesBOT"
    )
      return;
    for (const routed of this.router.route(message))
      this.send(routed.address, routed.args);
  }
  onTick() {}
  setRules(rules) {
    return this.router.setRules(rules);
  }
}

export class ValenceArousalBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.valenceArousal;
    this.arousal = this.config.initialArousal;
    this.valence = this.config.initialValence;
    this.arousalTarget = this.arousal;
    this.valenceTarget = this.valence;
    this.phraseBars = this.config.initialPhraseBars;
    this.lastPhrase = -1;
  }
  randomTarget() {
    const [low, high] = this.config.targetRange;
    return (low + randomInt(high - low + 1)) / this.config.targetDivisor;
  }
  choosePhraseBars() {
    const next = weightedChoice(
        this.config.phraseCandidates,
        this.config.phraseWeights,
      ),
      smoothed = Math.round((next + this.phraseBars) / 2);
    return Math.max(
      this.config.phraseCandidates[0],
      Math.min(this.config.phraseCandidates.at(-1), smoothed),
    );
  }
  chooseMeter() {
    const c = this.config,
      weights = c.meterCandidates.map(
        (_, index) =>
          c.meterLowWeights[index] * (1 - this.valenceTarget) +
          c.meterHighWeights[index] * this.valenceTarget,
      ),
      numerator = weightedChoice(c.meterCandidates, weights),
      groups = randomAdditiveGrouping(numerator, c.groupChoices);
    return {
      numerator,
      denominator: 4,
      groups,
      subdivision: 4,
      phraseBars: this.phraseBars,
      rhythm: { hits: null, rotation: 0, clave: [] },
    };
  }
  beginPhrase() {
    this.arousalTarget = this.randomTarget();
    this.valenceTarget = this.randomTarget();
    this.phraseBars = this.choosePhraseBars();
    const meter = this.chooseMeter();
    this.broadcast("timeSignature", [meter, "nextPhrase"]);
    this.broadcast("tala", meter.groups);
    this.broadcast("phraselength", [this.phraseBars]);
  }
  onMessage(message) {
    if (message.address === "/system/instance")
      this.setIdentity(message.args[0]);
  }
  onTick(
    tick,
    clock,
  ) {
    if (clock.phraseStart && clock.phrase !== this.lastPhrase) {
      this.lastPhrase = clock.phrase;
      this.beginPhrase();
    }
    const factor = this.config.smoothFactor;
    this.arousal += (this.arousalTarget - this.arousal) * factor;
    this.valence += (this.valenceTarget - this.valence) * factor;
    const bars = clock.meter?.phraseBars || this.phraseBars,
      pulses = clock.meter?.pulsesPerBar || bandMeter().pulsesPerBar,
      progress = ((clock.bar % bars) + (clock.tickInBar || 0) / pulses) / bars;
    this.broadcast("progress", [Math.max(0, Math.min(1, progress))]);
    this.broadcast("arousal", [this.arousal]);
    this.broadcast("valence", [this.valence]);
  }
}

export class MidiAnalyzerBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.midiAnalyzer;
    this.analyzer = new MidiFeatureAnalyzer({
      windowMs: this.config.windowMs,
      pitchRange: this.config.pitchRange,
      bendRange: this.config.mpeBendRange,
    });
    this.mappings = this.config.defaultMappings.map((mapping) => ({
      ...mapping,
    }));
    this.history = [];
  }
  receiveMidi(bytes, time) {
    this.analyzer.receive(bytes, time);
  }
  async start() {
    try {
      this.midiSubscription = await subscribeMidiInputs((bytes, time) =>
        this.receiveMidi(bytes, time),
      );
    } catch {}
  }
  stop() {
    this.midiSubscription?.close();
  }
  onMessage(message) {
    if (
      message.address === "/agent/midiAnalyzer/map" &&
      message.args?.[0] &&
      typeof message.args[0] === "object"
    )
      this.mappings = [{ ...message.args[0] }];
    if (message.address === "/agent/midiAnalyzer/clear") this.analyzer.clear();
  }
  onTick(tick, clock) {
    if (!clock.beatStart) return;
    const snapshot = this.analyzer.snapshot(undefined, clock.bpm || bandTempo());
    this.history.push(snapshot.normalized);
    if (this.history.length > this.config.smoothingWindows)
      this.history.shift();
    const smoothed = snapshot.normalized.map(
      (_, index) =>
        this.history.reduce((sum, row) => sum + row[index], 0) /
        this.history.length,
    );
    for (const mapping of this.mappings) {
      const value =
        smoothed[
          Math.max(
            0,
            Math.min(smoothed.length - 1, Number(mapping.feature) || 0),
          )
        ];
      this.broadcast(String(mapping.address || "feature"), [value]);
    }
    this.lastFeatures = { ...snapshot, normalized: smoothed };
  }
}

export class MidiBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.midiBot;
    // Pitch classes: the band's opening chord's.
    this.notes = this.openingClasses();
    this.density = this.config.defaultDensity;
    this.activity = this.config.defaultActivity;
    this.valence = this.config.defaultValence;
    this.arousal = this.config.defaultArousal;
    this.lastPhrase = -1;
    this.voiceNotes = Array(this.config.voiceCount).fill(null);
  }
  onMessage(message) {
    super.onMessage(message);
    for (const key of ["density", "activity", "valence", "arousal"])
      if (message.address.endsWith(`/${key}`)) {
        const value = Number(message.args.at(-1));
        if (Number.isFinite(value)) this[key] = Math.max(0, Math.min(1, value));
      }
  }
  pitchForVoice(voice) {
    const source = this.notes[randomInt(this.notes.length)] ?? 0,
      pitchClass = ((source % 12) + 12) % 12,
      octave = (voice + randomInt(this.config.octaves)) % this.config.octaves;
    return pitchClass + 12 * (this.config.baseOctave + octave);
  }
  onTick(
    tick,
    clock,
  ) {
    if (clock.phraseStart && clock.phrase !== this.lastPhrase) {
      this.lastPhrase = clock.phrase;
      this.broadcast("notepool", this.notes);
      this.broadcast("density", [this.density]);
      this.broadcast("activity", [this.activity]);
    }
    if (!clock.beatStart) return;
    const [minimum, maximum] = this.config.activeVoiceRange,
      voices = Math.max(
        minimum,
        Math.min(
          maximum,
          Math.round(minimum + this.activity * (maximum - minimum)),
        ),
      ),
      probability = Math.max(
        0.02,
        Math.min(1, this.density * (0.4 + 0.6 * this.activity)),
      );
    for (
      let voice = 0;
      voice < Math.min(this.config.voiceCount, voices);
      voice++
    )
      if (unitRandom() < probability) {
        const note = this.pitchForVoice(voice),
          [velocityLow, velocityHigh] = this.config.velocityRange,
          velocity =
            (velocityLow + randomInt(velocityHigh - velocityLow + 1)) / 127,
          [durationLow, durationHigh] = this.config.durationMsBase,
          duration =
            (durationLow +
              unitRandom() *
                (durationHigh +
                  this.config.durationMsArousalScale * this.arousal -
                  durationLow)) /
            1000;
        this.voiceNotes[voice] = note;
        this.audio.midiGeneratorVoice(note, duration, velocity, voice, {
          density: this.density,
          activity: this.activity,
          valence: this.valence,
          arousal: this.arousal,
        });
      }
  }
}

export class MidiGuitarInputBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.midiGuitarInput;
    this.bends = Array(16).fill(8192);
    this.onsets = [];
    this.pitches = [];
    this.activitySamples = [];
    this.lastBeat = -1;
  }
  receiveMidi(bytes, time = performance.now()) {
    const [status = 0, data1 = 0, data2 = 0] = bytes,
      kind = status & 0xf0,
      channel = status & 15;
    if (kind === 0xe0) {
      this.bends[channel] = (data2 << 7) | data1;
      return;
    }
    if (kind === 0x90 && data2 > 0) {
      const pitch =
        data1 +
        ((this.bends[channel] - 8192) / 8192) * this.config.mpeBendRange;
      this.onsets.push(time);
      this.pitches.push({ pitch, time });
    }
  }
  async start() {
    try {
      this.midiSubscription = await subscribeMidiInputs((bytes, time) =>
        this.receiveMidi(bytes, time),
      );
    } catch {}
    try {
      this.input = await this.audio.microphone();
    } catch {}
  }
  stop() {
    this.midiSubscription?.close();
    this.input?.stop();
  }
  onMessage(message) {
    if (
      message.address === "/agent/off" &&
      (message.args.includes(this.instanceId) ||
        message.args.includes("mh_MIDIGuitarInputBOT"))
    )
      this.stop();
  }
  onTick(tick, clock) {
    if (!clock.beatStart || clock.beat === this.lastBeat) return;
    this.lastBeat = clock.beat;
    const now = performance.now(),
      cutoff = now - this.config.noteWindowMs;
    this.onsets = this.onsets.filter((time) => time >= cutoff);
    this.pitches = this.pitches.filter((item) => item.time >= cutoff);
    const features = this.input?.features?.(),
      rawActivity = Math.max(
        0,
        Math.min(
          this.config.activityInputRange[1],
          Number(features?.loudness) || 0,
        ),
      ),
      activity = rawActivity / this.config.activityInputRange[1];
    this.activitySamples.push(activity);
    if (this.activitySamples.length > this.config.activitySmoothingSamples)
      this.activitySamples.shift();
    const smoothed =
        this.activitySamples.reduce((sum, value) => sum + value, 0) /
        this.activitySamples.length,
      density = Math.max(
        0,
        Math.min(1, this.onsets.length / this.config.densityDivisor),
      ),
      pool = [
        ...new Map(
          this.pitches.map((item) => [item.pitch.toFixed(6), item.pitch]),
        ).values(),
      ];
    this.broadcast("density", [density]);
    this.broadcast("activity", [smoothed]);
    if (pool.length) this.broadcast("notepool", pool);
  }
}

export class VideoBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.video;
    this.density = 0;
    this.activity = 0;
    this.barkEnergy = [];
    this.elapsed = 0;
    this.lastBeat = -1;
  }
  async start() {
    try {
      this.videoInput = await openVideoFeatures({
        width: this.config.frameSize[0],
        height: this.config.frameSize[1],
      });
    } catch {}
  }
  stop() {
    this.videoInput?.stop();
  }
  onMessage(message) {
    super.onMessage(message);
    if (message.address.endsWith("/density")) {
      const value = Number(message.args.at(-1));
      if (Number.isFinite(value))
        this.density = Math.max(0, Math.min(1, value));
    }
    if (message.address.endsWith("/activity")) {
      const value = Number(message.args.at(-1));
      if (Number.isFinite(value))
        this.activity = Math.max(0, Math.min(1, value));
    }
    if (message.address.endsWith("/barkenergy"))
      this.barkEnergy = message.args.map(Number).filter(Number.isFinite);
  }
  visualState() {
    const density = this.density,
      activity = this.activity,
      saturation = this.barkEnergy.length
        ? Math.max(
            0,
            Math.min(
              1,
              this.barkEnergy.reduce((sum, value) => sum + Math.abs(value), 0) /
                this.barkEnergy.length,
            ),
          )
        : activity;
    return {
      velocity: density ** 1.8 * this.config.densityVelocityRange[1],
      scrollMs:
        this.config.activityScrollMs[0] +
        activity *
          (this.config.activityScrollMs[1] - this.config.activityScrollMs[0]),
      blurMs:
        this.config.activityBlurMs[0] +
        activity *
          (this.config.activityBlurMs[1] - this.config.activityBlurMs[0]),
      saturation,
      blackout: activity > this.config.blackoutThreshold,
    };
  }
  onTick(tick, clock) {
    if (!clock.beatStart || clock.beat === this.lastBeat) return;
    this.lastBeat = clock.beat;
    this.elapsed++;
    const measured = Number(this.videoInput?.features?.().activity);
    if (Number.isFinite(measured)) {
      this.activity = Math.max(0, Math.min(1, measured));
      this.broadcast("activity", [this.activity]);
    }
    this.lastVisualState = this.visualState();
  }
}

export class WebBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.webBot;
    this.sourcePool = null;
    this.passage = this.newPassage();
    this.lastPhrase = -1;
    this.lastEvent = Array(this.config.partCount).fill(-1);
  }
  pitch() {
    const pool = this.sourcePool?.length
      ? this.sourcePool
      : this.openingPool([this.config.register, this.config.register + 11], { of: "collection" });
    return pool[randomInt(pool.length)];
  }
  newNote() {
    const c = this.config,
      [velocityLow, velocityHigh] = c.velocityRange;
    return {
      pitch: this.pitch(),
      duration:
        weightedChoice(c.durationMultipliers, c.durationWeights) *
        c.baseDurationMs,
      velocity: velocityLow + unitRandom() * (velocityHigh - velocityLow),
    };
  }
  newPassage() {
    return Array.from({ length: this.config.partCount }, () =>
      Array.from({ length: this.config.notesPerPhrase }, () => this.newNote()),
    );
  }
  ornament() {
    const [low, high] = this.config.ornamentTransposition;
    this.passage = this.passage.map((phrase) =>
      phrase.flatMap((note) => [
        {
          ...note,
          pitch: note.pitch + low + unitRandom() * (high - low),
          duration: note.duration * 0.5,
        },
        { ...note, duration: note.duration * 0.5 },
      ]),
    );
  }
  develop() {
    this.ornament();
    const durations = this.passage.flatMap((phrase) =>
        phrase.map((note) => note.duration),
      ),
      density =
        durations.reduce((sum, value) => sum + value, 0) / durations.length;
    if (density < this.config.resetDensityThresholdMs)
      this.passage = this.newPassage();
    const [low, high] = this.config.passageDurationFactor,
      factor = low + unitRandom() * (high - low);
    for (const phrase of this.passage)
      for (const note of phrase) note.duration *= factor;
    this.broadcast("density", [
      Math.max(
        0,
        Math.min(
          1,
          this.config.baseDurationMs / (density || this.config.baseDurationMs),
        ),
      ),
    ]);
    this.lastEvent.fill(-1);
  }
  onMessage(message) {
    super.onMessage(message);
    if (message.address.endsWith("/notepool") && this.notes.length)
      this.sourcePool = this.notes.slice();
  }
  onTick(
    tick,
    clock,
  ) {
    if (clock.phraseStart && clock.phrase !== this.lastPhrase) {
      this.lastPhrase = clock.phrase;
      this.develop();
    }
    const meter = clock.meter || {},
      totalTicks = (meter.phraseBars || bandPhraseBars()) * (meter.pulsesPerBar || bandMeter().pulsesPerBar),
      position =
        ((clock.bar % (meter.phraseBars || bandPhraseBars())) * (meter.pulsesPerBar || bandMeter().pulsesPerBar) +
          (clock.tickInBar || 0)) /
        totalTicks;
    for (let voice = 0; voice < this.passage.length; voice++) {
      const phrase = this.passage[voice],
        index = Math.min(
          phrase.length - 1,
          Math.floor(position * phrase.length),
        );
      if (index === this.lastEvent[voice]) continue;
      this.lastEvent[voice] = index;
      const note = phrase[index],
        duration = Math.max(0.03, note.duration / 1000);
      // (Written on its share of the phrase, wherever the tick it sounds on falls.)
      writtenOnStep(this.audio, clock.tick - Math.round(position * totalTicks), totalTicks, phrase.length, index, () => this.audio.webVoice(note.pitch, duration, note.velocity / 127, voice));
    }
  }
}

export class ServerBot extends Agent {
  constructor(...args) {
    super(...args);
    this.bridge = new LegacyLanBridge({
      origin: "ae_ServerBOT",
      transport: (message) => this.outbound?.(message),
    });
    this.transport = "shared-websocket-room";
  }
  configure(options) {
    return this.bridge.configure(options);
  }
  connectTransport(callback) {
    this.outbound = callback;
  }
  receiveRemote(message) {
    const relayed = this.bridge.receiveRemote(message);
    if (relayed) this.send(relayed.address, relayed.args);
    return Boolean(relayed);
  }
  onMessage(message) {
    if (
      message.address === "/agent/server/configure" &&
      message.args?.[0] &&
      typeof message.args[0] === "object"
    ) {
      this.configure(message.args[0]);
      return;
    }
    if (message.source === this.instanceId || message.source === "ae_ServerBOT")
      return;
    this.bridge.forwardLocal(message);
  }
  onTick() {}
}

export class TemplateBot extends Agent {
  constructor(...args) {
    super(...args);
    this.received = [];
    this.active = true;
  }
  subscribe(callback) {
    this.listener = callback;
  }
  onMessage(message) {
    if (message.address === "/system/instance") {
      this.setIdentity(message.args[0]);
      return;
    }
    if (
      message.source === this.instanceId ||
      message.source === "mh_TemplateBOT"
    )
      return;
    if (
      message.address === "/agent/off" &&
      (message.args.includes(this.instanceId) ||
        message.args.includes("mh_TemplateBOT"))
    ) {
      this.active = false;
      this.send("/agent/offed", [this.instanceId || "mh_TemplateBOT"]);
      return;
    }
    const copy = {
      ...message,
      args: Array.isArray(message.args) ? message.args.slice() : [],
    };
    this.received.push(copy);
    this.listener?.(copy);
  }
  onTick() {}
}

export class AudioAnalyzerBot extends Agent {
  async start() {
    this.input = await this.audio.microphone();
  }
  onTick(tick, clock) {
    if (!clock.beatStart || !this.input) return;
    const features = this.input.features();
    this.broadcast("loudness", [features.loudness]);
    this.broadcast("centroid", [features.centroid]);
    this.broadcast("activity", [features.activity]);
    this.broadcast("arousal", [features.arousal]);
    this.broadcast("valence", [features.valence]);
  }
  stop() {
    this.input?.stop();
  }
}

export class EffectsBot extends Agent {
  constructor(...args) {
    super(...args);
    this.valence = 0.5;
    this.arousal = 0.5;
  }
  onMessage(message) {
    const value = Math.max(0, Math.min(1, Number(message.args.at(-1))));
    if (!Number.isFinite(value)) return;
    if (message.address.endsWith("/valence")) this.valence = value;
    if (message.address.endsWith("/arousal")) this.arousal = value;
  }
  onTick(tick, clock) {
    if (clock.barStart) writtenOn(this.audio, clock.tick, clock.meter.pulsesPerBar, () => this.audio.effectMonitor(this.valence, this.arousal));
  }
}
