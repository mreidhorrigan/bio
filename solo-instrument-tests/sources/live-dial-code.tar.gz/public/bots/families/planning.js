// The native planning bots: mh_PlexBOT (forms and their grammar), mh_FormBOT, mh_CoordBOT, mh_TuneBOT, mh_SpaceBOT
// and mh_MemoryBOT.
// Moved verbatim from public/agents.js in its per-family split (28 September 2026; RESEARCH_BACKLOG, the second
// queue). agents.js registers them (BOT_REGISTRY) and re-exports each, so an import from it is as it was.
import {checkedInsistence,insistenceOf,withInsistence,insistenceInstruction,MOTIF_INSISTENCE_LIMITS} from '../../shared/motif-insistence.js';
import { Agent } from "../../framework/index.js";
import { STOCHASTIC_CONFIG as CONFIG } from "../../stochastic-config.js";
import { DurationController, compositionContract, durationPolicy } from "../../shared/composition-duration.js";
import { MotifIdentities, identityKey } from "../../shared/motif-retention.js";
import { MotifMemory, motifNotes, queryMotifs, topLine, validateMotif } from "../../shared/motifs.js";
import { PresentationHistory, familyOf, transformationOf } from "../../shared/presentation-history.js";
import { CompositeHooks, compositeOf, voiceOnset } from "../../shared/composite-hooks.js";
import { ThematicForm, owedFormAnswer } from "../../shared/thematic-form.js";
import {
  adaptiveJustIntonation, chordRatioProvenance, exactChordJustIntonation, tuningSystem,
} from "../../shared/tuning.js";
import { compareLogicalPosition, logicalPosition } from "../../shared/planning.js";
import { compileSections, sectionAt } from "../../shared/casting/sections.js";
import {
  concessionPayload, fitSectionsToPhrases, formCandidates, formEndBar, formNegotiationPolicy, formParticipants,
  formPreferences, formVariants, formWeights, slateRatings,
} from "../../shared/form-negotiation.js";
import { declarationOf } from "../../shared/casting/declarations.js";
import { defaultGrouping, rotateCycle } from "../../shared/rhythm.js";
import { defaultGrammar as defaultPlexGrammar, loadGrammar as loadPlexGrammar } from "../../shared/plex-grammar.js";
import { ensembleMixPlacements, spaceAllocation } from "../../shared/musicality.js";
import { formProgress, reviseFutureForm } from "../../shared/form-development.js";
import { motifContent, motifRankingPolicy, rankingReport } from "../../shared/motif-ranking.js";
import { normalizePitchPool } from "../../shared/pitch.js";
import { parseChordPlan } from "../../shared/harmony.js";
import { randomInt, weightedChoice } from "../../shared/stochastic.js";
import { realizeMotif } from "../../shared/motif-harmony.js";
import { recordAgentState } from "../../shared/agent-states.js";
import { selectMotifs } from "../../shared/motif-strategies.js";
import { phrasePlanWindow } from "./helpers.js";
import { agentDefinitions } from "./definitions.js";
import {bandPhraseBars,bandMeter} from '../../shared/opening-time.js';

export class PlexBot extends Agent {
  constructor(...args) {
    super(...args);
    this.form = [];
    this.section = -1;
    this.phrasesInSection = 0;
    this.lastPhrase = -1;
    // The grammar its forms are drawn from (shared/plex-grammar.js): a saved one loaded, else the authored rules
    // (CONFIG.plex), read live so a character still colours them.
    this.grammar = null;
    // Its sections' rhythm plans, by plan id, with the parts' answers to each (meter-policy.js planAnswer), and what
    // it made of them.
    this.sectionPlans = new Map();
    this.negotiations = [];
  }
  rules() {
    return this.grammar ?? CONFIG.plex;
  }
  // A saved grammar taken back (its text, or the object a form plan carries): the forms it draws from here on.
  loadGrammar(saved) {
    this.grammar = loadPlexGrammar(saved);
    this.audio?.report?.("plex_grammar", { id: this.grammar.id, name: this.grammar.name });
    return this.grammar;
  }
  // The parts' answers to a section it proposed, kept with the section.
  onPlanResponse(response) {
    const record = this.sectionPlans.get(response?.planId);
    if (!record || response.responder === this.instanceId) return;
    record.answers.set(response.responder, { disposition: response.disposition, payload: response.payload || {}, rationale: response.rationale });
  }
  // **Answered, it meets the answer.** Before it announces a section, it reads the parts' answers to the one before:
  // where most of those who answered counter its change of meter, keeping their own (meter-policy.js: the polymetric
  // answer), the section it announces next is in the meter they keep; where most count the bar in another grouping,
  // and the next section's bar is that bar, it takes their grouping. A return keeps the home it returns to. The form
  // plan is revised, and what it made of the answers is kept with its reason (`negotiations`).
  negotiate(clock) {
    const previous = [...this.sectionPlans.values()].filter((record) => record.section !== this.section).at(-1),
      next = this.form[this.section];
    if (!previous || !next || next.role === "return" || next.role === "complex-return") return null;
    const answers = [...previous.answers.values()].filter((answer) => ["accept", "transform", "counter", "decline"].includes(answer.disposition));
    if (!answers.length) return null;
    const most = (list, key) => {
      const counts = new Map();
      for (const item of list) counts.set(key(item), (counts.get(key(item)) || 0) + 1);
      return [...counts].sort((a, b) => b[1] - a[1])[0];
    };
    const counters = answers.filter((answer) => answer.disposition === "counter" && Number.isInteger(answer.payload.stream?.meter?.numerator));
    let outcome = null;
    if (counters.length * 2 > answers.length) {
      const [key, count] = most(counters, (answer) => `${answer.payload.stream.meter.numerator}/${answer.payload.stream.meter.denominator || bandMeter().denominator}`),
        [numerator, denominator] = key.split("/").map(Number),
        kept = counters.find((answer) => `${answer.payload.stream.meter.numerator}/${answer.payload.stream.meter.denominator || bandMeter().denominator}` === key).payload.stream.meter,
        groups = Array.isArray(kept.groups) && kept.groups.reduce((a, b) => a + b, 0) === numerator ? [...kept.groups] : defaultGrouping(numerator),
        density = next.rhythm.hits / (next.numerator * next.subdivision),
        from = `${next.numerator}/${next.denominator}`;
      Object.assign(next, { numerator, denominator, groups, rhythm: { ...next.rhythm, hits: Math.max(1, Math.round(numerator * next.subdivision * density)) },
        rationale: `${next.rationale}; ${count} of ${answers.length} parts kept ${key} against ${previous.meter.numerator}/${previous.meter.denominator}, so this section meets them there` });
      outcome = { section: next.id, answer: "counter", from, to: key, count, answered: answers.length };
    } else {
      const regrouped = answers.filter((answer) => answer.disposition === "transform" && Array.isArray(answer.payload.groups) && answer.payload.groups.reduce((a, b) => a + b, 0) === next.numerator);
      if (regrouped.length * 2 > answers.length) {
        const [key, count] = most(regrouped, (answer) => answer.payload.groups.join("+")), from = next.groups.join("+");
        if (key !== from) {
          next.groups = key.split("+").map(Number);
          next.rationale = `${next.rationale}; ${count} of ${answers.length} parts count the bar as ${key}, so this section takes their grouping`;
          outcome = { section: next.id, answer: "transform", from, to: key, count, answered: answers.length };
        }
      }
    }
    if (!outcome) return null;
    this.negotiations.push({ ...outcome, bar: clock?.bar ?? null });
    if (this.negotiations.length > 32) this.negotiations.shift();
    if (this.formPlan) {
      this.formPlan = this.plans.revise(this.formPlan, { ...this.formPlan.payload, sections: this.form }, { createdAt: this.formPlan.createdAt });
      this.broadcast("plan", [this.formPlan]);
    }
    return outcome;
  }
  complexity(numerator) {
    const c = CONFIG.plex,
      min = Math.min(...c.numerators),
      max = Math.max(...c.numerators),
      size = (numerator - min) / (max - min),
      odd = numerator % 2 ? 0.18 : 0,
      prime = [5, 7, 11, 13, 17].includes(numerator) ? 0.16 : 0;
    return Math.min(1, size * 0.66 + odd + prime);
  }
  chooseNumerator(role, previous, home) {
    const c = this.rules();
    if (role === "return" || role === "complex-return") return home.numerator;
    if (role === "stabilize")
      return weightedChoice(
        c.stableNumerators,
        c.stableNumerators.map(() => 1),
      );
    const target = c.roleComplexity[role] ?? 0.5,
      continuity = c.continuity[role] ?? 0.5;
    return weightedChoice(
      c.numerators,
      c.numerators.map((value, index) => {
        const targetFit = 1 - Math.abs(this.complexity(value) - target),
          distance =
            Math.abs(value - previous.numerator) /
            (Math.max(...c.numerators) - Math.min(...c.numerators)),
          continuityFit = 1 - Math.min(1, distance);
        return (
          c.numeratorWeights[index] *
          Math.max(0.01, targetFit) *
          (continuity * continuityFit +
            (1 - continuity) * Math.max(0.1, distance))
        );
      }),
    );
  }
  generateSection(index, role, previous, home) {
    const c = this.rules(),
      numerator =
        index === 0
          ? weightedChoice(c.numerators, c.numeratorWeights)
          : this.chooseNumerator(role, previous, home || previous),
      isReturn = role === "return" || role === "complex-return",
      denominator = isReturn
        ? home.denominator
        : weightedChoice(c.denominators, c.denominatorWeights),
      subdivision = isReturn
        ? home.subdivision
        : weightedChoice(c.subdivisions, c.subdivisionWeights),
      phraseBars = isReturn
        ? home.phraseBars
        : weightedChoice(c.phraseBars, c.phraseBarWeights),
      target = c.roleComplexity[role] ?? 0.5,
      density = c.hitDensities.reduce((best, value) =>
        Math.abs(value - target) < Math.abs(best - target) ? value : best,
      ),
      rotation = isReturn
        ? home.rhythm.rotation
        : weightedChoice(c.rotations, c.rotationWeights),
      baseGroups = defaultGrouping(numerator),
      groups = isReturn
        ? home.groups
        : rotateCycle(baseGroups, randomInt(baseGroups.length)),
      pulses = numerator * subdivision,
      baseTempo =
        index === 0
          ? weightedChoice(c.baseTempos, c.baseTempoWeights)
          : home.tempo.targetBpm,
      targetBpm = isReturn
        ? home.tempo.targetBpm
        : Math.round(
            Math.max(
              40,
              Math.min(220, baseTempo * (c.roleTempoMultiplier[role] ?? 1)),
            ),
          );
    return {
      id: index,
      role,
      rationale: this.rationale(role, previous, home),
      numerator,
      denominator,
      groups,
      subdivision,
      phraseBars,
      phrases: weightedChoice(c.sectionPhrases, c.sectionPhraseWeights),
      rhythm: {
        hits: Math.max(1, Math.round(pulses * density)),
        rotation,
        clave: [],
      },
      tempo: {
        targetBpm,
        durationBars: phraseBars,
        shape: weightedChoice(c.tempoShapes, c.tempoShapeWeights),
      },
      hdensity: Math.max(0.2, Math.min(0.85, target)),
      vdensity: Math.max(0.2, Math.min(0.8, target * 0.85)),
    };
  }
  rationale(role, previous, home) {
    return (
      {
        establish: "establish a metrical identity",
        "complex-frame": "open with marked metric instability",
        depart: "depart by a perceptibly related meter",
        contrast: "demarcate a new formal section by metric contrast",
        develop: "increase instability while retaining continuity",
        climax: "maximize metric and rhythmic intensity",
        relax: "reduce complexity after the high point",
        stabilize: "create a stable central field",
        return: "recall the home meter as formal resolution",
        "complex-return": "restore the opening frame",
      }[role] || "articulate form"
    );
  }
  generateForm(
    clock = { bar: 0, phrase: 0, section: 0, meter: { phraseBars: 4 } },
  ) {
    const c = this.rules(),
      archetype = weightedChoice(
        c.formArchetypes,
        c.formArchetypes.map((item) => item.weight),
      );
    this.form = [];
    let home, previous;
    for (const [index, role] of archetype.roles.entries()) {
      const section = this.generateSection(index, role, previous, home);
      home ||= section;
      this.form.push(section);
      previous = section;
    }
    // The form carries the grammar it was drawn from, so the piece keeps it (plex-grammar.js: saved with the form).
    const grammar = this.grammar ?? defaultPlexGrammar(CONFIG.plex),
      payload = {
        schemaVersion: 1,
        archetype: archetype.name,
        sections: this.form,
        grammar,
      };
    this.broadcast("form", [
      { version: 2, archetype: archetype.name, sections: this.form, grammar: grammar.id },
    ]);
    const phrases = this.form.reduce(
        (sum, section) => sum + section.phrases,
        0,
      ),
      window = phrasePlanWindow(clock);
    this.formPlan = this.preparePlan("form", payload, {
      ...window,
      expiresAt: {
        ...window.createdAt,
        bar: window.createdAt.bar + phrases * (clock.meter?.phraseBars || bandPhraseBars()),
        phrase: window.createdAt.phrase + phrases,
      },
      horizon: phrases,
      confidence: 0.76,
      priority: 0.7,
      rationale:
        "Propose a complete metric and tempo articulation of the upcoming form.",
    });
    this.announcePlan(this.formPlan);
  }
  // `when` is "nextPhrase" for every section but possibly the first. A section is
  // announced a phrase ahead so the ensemble can prepare for it, and that is
  // right everywhere except at the start, where there is no phrase before the
  // first one to announce it in -- see onPrepare.
  emitSection(
    clock = { bar: 0, phrase: 0, section: 0, meter: { phraseBars: 4 } },
    when = "nextPhrase",
  ) {
    const opening = when === "opening",
      section = this.form[this.section],
      meter = {
        numerator: section.numerator,
        denominator: section.denominator,
        subdivision: section.subdivision,
        phraseBars: section.phraseBars,
        rhythm: section.rhythm,
      };
    this.broadcast("section", [section.id, this.form.length]);
    this.broadcast("timeSignature", [meter, when]);
    this.broadcast("tempoCurve", [section.tempo, when]);
    this.broadcast("tala", section.groups);
    this.broadcast("phraselength", [section.phraseBars]);
    this.broadcast("phrases", [section.phrases]);
    this.broadcast("hdensity", [section.hdensity]);
    this.broadcast("vdensity", [section.vdensity]);
    // An opening section is in force from where the piece begins, not from the
    // phrase after it.
    const appliesAt = {
      bar: (clock.bar || 0) + (opening ? 0 : clock.meter?.phraseBars || bandPhraseBars()),
      phrase: (clock.phrase || 0) + (opening ? 0 : 1),
      section: section.id,
    };
    // Kept before it is announced: on a synchronous bus the answers arrive inside the announcement.
    const plan = this.preparePlan(
      "rhythm",
      {
        schemaVersion: 1,
        meter,
        tala: [...section.groups],
        density: section.hdensity,
        verticalDensity: section.vdensity,
        tempo: { ...section.tempo },
        formalRole: section.role,
      },
      {
        createdAt: {
          bar: clock.bar || 0,
          phrase: clock.phrase || 0,
          section: clock.section || 0,
        },
        appliesAt,
        expiresAt: {
          ...appliesAt,
          bar: appliesAt.bar + section.phrases * section.phraseBars,
          phrase: appliesAt.phrase + section.phrases,
        },
        horizon: section.phrases,
        confidence: 0.78,
        priority: 0.72,
        rationale: section.rationale,
      },
    );
    this.sectionPlans.set(plan.planId, { section: this.section, meter, answers: new Map() });
    while (this.sectionPlans.size > 16) this.sectionPlans.delete(this.sectionPlans.keys().next().value);
    this.announcePlan(plan);
  }
  // **The piece begins in its first section, not in a default it was never
  // going to keep.** Every section is announced a phrase ahead, and the first
  // one had nowhere to be announced from: it was sent on the first tick, asked
  // for "nextPhrase", and so every piece this bot shaped spent its whole first
  // phrase in the transport's 4/4 at the spec's tempo and only then became
  // itself. Before anybody plays, this states the form and asks for the first
  // section's meter and tempo as an OPENING, which a transport that has not
  // pulsed applies at once.
  //
  // Only a piece that has not begun has an opening to set, and whoever calls
  // this knows whether anybody has played: a render asks before its first
  // pulse, a live page asks while it is still holding its players back. What
  // this can see for itself is the clock, and a room past its first phrase is
  // a piece under way whoever is asking -- another page's bots may have been
  // playing for a minute. There it does what it always did and waits for a
  // phrase. Returns whether it opened, so a room waiting for an opening can
  // stop waiting for one that is not coming.
  onPrepare(
    clock = { bar: 0, phrase: 0, section: 0, tick: 0, meter: { phraseBars: 4 } },
  ) {
    if (this.form.length || (clock.phrase || 0) > 0) return false;
    this.generateForm(clock);
    this.section = 0;
    // The first section sounds from phrase 0 rather than phrase 1, so it has
    // used one of its phrases by the time the next is due to be announced.
    // Without this it would run a phrase long and push the whole form back.
    this.phrasesInSection = 1;
    this.emitSection(clock, "opening");
    return true;
  }
  onMessage(message) {
    super.onMessage(message);
    // A saved grammar sent back to it (by a person, a page, the language model or another bot): its forms from the next.
    // With no target, it is for any PlexBOT.
    if (message.address === "/agent/plex/grammar" && (message.args?.[0]?.target === undefined || this.targeted(message))) {
      try { this.loadGrammar(message.args?.[0]?.grammar); }
      catch (error) { this.audio?.report?.("plex_grammar_refused", { error: error.message }); }
    }
    if (message.address === "/broadcast/form/adjust" && this.formPlan) {
      const payload = reviseFutureForm(
        this.formPlan,
        this.currentClock || {},
        message.args?.[0] || {},
      );
      this.formPlan = this.plans.revise(this.formPlan, payload, {
        createdAt: this.formPlan.createdAt,
      });
      this.form = payload.sections;
      this.broadcast("plan", [this.formPlan]);
    }
  }
  onTick(
    tick,
    clock,
  ) {
    if (!clock.phraseStart || clock.bar === this.lastPhrase) return;
    this.lastPhrase = clock.bar;
    if (!this.form.length) this.generateForm(clock);
    // Form is an agent-authored message, not relay-owned room state. Repeating
    // the current immutable revision lets late joiners hear it naturally.
    this.broadcast("plan", [this.formPlan]);
    this.broadcast("form/progress", [formProgress(this.formPlan, clock)]);
    if (
      this.section < 0 ||
      this.phrasesInSection >= this.form[this.section].phrases
    ) {
      this.section = (this.section + 1) % this.form.length;
      this.phrasesInSection = 0;
      if (this.section === 0 && clock.bar > 0) this.generateForm(clock);
      else this.negotiate(clock);
      this.emitSection(clock);
    }
    this.phrasesInSection++;
  }
}

export class FormBot extends Agent {
  constructor(...args) {
    super(...args);
    // The voices that stand for performers: a listener or an input announcing a performer's attacks or notes.
    this.performerVoices = new Set();
    // The voices that plan the form's returns: a bot heard publishing return plans, or answering a form for the returns
    // it still owes (mh_MemoryBOT's).
    this.thematicVoices = new Set();
    this.lastPhrase = -1;
    this.formPlan = null;
    this.stopProposal = null;
    this.stopCommitment = null;
    this.formParticipants = new Map();
    this.stopVotes = new Map();
    this.extension = 0;
    // More than one FormBOT may be in the room. Each runs the same selector
    // over the same plans and responses and reaches the same agreed form; the
    // losers then yield out loud so that bots which ran no selector agree too.
    this.negotiation = formNegotiationPolicy(CONFIG.formBot?.negotiation);
    this.duration = null;
    this.agreedFormId = null;
    this.conceded = null;
  }
  // A performer heard (role 'performer'), by the voice that announces them: a listener's attacks come under its own
  // id, its notes under `<id>:performer`. That voice is weighed as a person's in the negotiation (formWeights).
  onMessage(message) {
    super.onMessage(message);
    const value = message?.args?.[0];
    if ((message?.address === "/broadcast/onsets" || message?.address === "/broadcast/voices") && value?.role === "performer" && value.voice)
      this.performerVoices.add(String(value.voice).replace(/:performer$/, ""));
    if (message?.address === "/broadcast/plan" && value?.kind === "motif" && value.payload?.return && value.author && this.thematicVoices.size < 16)
      this.thematicVoices.add(String(value.author));
  }
  // Beats, because a bar is not stable across a meter change and the ensemble's
  // timed plans already count in beats.
  beatsPerBar(clock) {
    return Math.max(1, Number(clock?.meter?.numerator) || this.negotiation.defaultBeatsPerBar);
  }
  // How far into the piece this is, in the room's own count of beats, which
  // survives a change of meter as MemoryBOT's does. Bar x numerator does not:
  // from bar 10 of a 4/4 to bar 11 of a 3/4 it went from beat 40 back to 33,
  // and the duration controller, which ignores a clock that runs backward,
  // then held its checkpoints shut until the arithmetic caught up (the
  // mathematical audit's B01). The arithmetic stays as the fallback for a
  // clock that carries no count.
  clockBeats(clock) {
    const counted = Number(clock?.ensembleBeat);
    if (clock?.ensembleBeat !== undefined && clock?.ensembleBeat !== null && Number.isFinite(counted)) return counted;
    return (Number(clock?.bar) || 0) * this.beatsPerBar(clock) + (Number(clock?.beat) || 0);
  }
  // One checkpoint of the shared decision. Returns the agreed plan, or null when
  // there is nothing to agree about.
  //
  // No message is sent to reach agreement: every FormBOT already receives every
  // form plan and every response to one, and the selector is deterministic, so
  // the same evidence produces the same winner wherever it is evaluated. What
  // IS sent is a concession -- a losing author revising its own plan's priority
  // downward -- because that is the only way a bot which never ran a selector
  // can end up following the same form.
  negotiateForm(clock) {
    // A committed ending is not reopened by a better idea about the form.
    if (!this.formPlan || this.stopCommitment || this.ensembleStopped) return null;
    const policy = this.negotiationPolicy(), beatsPerBar = this.beatsPerBar(clock);
    // A FormBOT never receives its own plan back -- PlanCoordinator.ingest
    // answers `self` -- so it has to put its own proposal on the slate. Alone,
    // it still has a slate when it offers variants of its own form, and the
    // ensemble's ratings choose among them.
    const rivals = [...this.futurePlans.values()].filter(plan => plan.kind === "form");
    if (!rivals.length && !this.formPlan.payload?.variants?.length) return null;
    // Each ending where it falls on the room's clock: the beats counted up to
    // this bar, then the bars still to come (formEndpointBeats). Each form's
    // timeline is checked against the render's end, where one is declared
    // (formFaults): a form that cannot be played through is not prepared.
    const beats = this.clockBeats(clock), declared = this.declaredEndBar(clock),
      candidates = formCandidates([this.formPlan, ...rivals], {
        beatsPerBar, policy, bar: Number(clock?.bar) || 0, beats: beats - (Number(clock?.beat) || 0),
        endBar: declared?.bar ?? null, phraseBars: clock?.meter?.phraseBars,
      });
    if (candidates.length < 2) return null;

    // The envelope is frozen from the first form the ensemble agrees on, and
    // every FormBOT agrees on that same one, so every FormBOT builds the same
    // envelope. Until a first agreement exists the canonically first form that
    // can be played stands in as the incumbent. Where a render declares its
    // length, FormBOT's proposals are fitted to it (proposeForm) and a form that
    // runs past it is not prepared, so the original length is the render's
    // (this.lengthSource says which): a length someone decided, not a draw. In
    // a live room, where nothing declares one, it is the draw. The policy is the
    // one that form's plan carries (durationPolicy), so FormBOTs configured
    // differently still weigh under one.
    if (!this.duration) {
      const opening = candidates.find(candidate => candidate.prepared);
      if (!opening) return null;
      const governing = this.planPolicy(opening.plan) ?? policy.duration;
      this.duration = new DurationController({
        contract: compositionContract({ beats: opening.endpointBeats, startedAtBeats: beats, policy: governing }),
        accepted: { ...opening }, policy: governing, clock: { beats, seconds: 0 },
      });
      this.policySource = opening.planId;
    }
    this.duration.advance({ beats });
    // A policy update travels on the plan the policy came from, in its latest
    // revision (the adoption's step 2), and changes costs and bounds, never the
    // envelope (DurationController.adjustPolicy).
    const source = this.policySource === this.formPlan.planId ? this.formPlan : this.futurePlans.get(this.policySource),
      update = source ? this.planPolicy(source) : null;
    if (update) this.duration.adjustPolicy(update, { reason: `${source.author}'s plan, revision ${source.revision}` });
    // The incumbent where the others are: the same plan ending at the same bar,
    // under the id the decision knows it by (a variant its author has since
    // adopted is its plan's own form now), measured in the meter in force now.
    const accepted = this.duration.accepted, acceptedPlan = accepted.planId ?? accepted.id;
    for (const candidate of candidates)
      if (candidate.id !== accepted.id && candidate.planId === acceptedPlan && candidate.endBar === accepted.endBar) {
        candidate.key = candidate.id;
        candidate.id = accepted.id;
      }
    const incumbent = candidates.find(candidate => candidate.id === accepted.id);
    if (incumbent) this.duration.remeasure({ id: incumbent.id, endpointBeats: incumbent.endpointBeats, reason: "the meters to come changed" });
    const preferences = formPreferences(this.planResponses, { policy }),
      participants = formParticipants(this.planResponses, candidates);
    let decision = null;
    try {
      this.duration.openRound({ id: `${this.instanceId}:form:${beats}`, participants });
      for (const candidate of candidates) {
        if (candidate.id === accepted.id) continue;
        // A source past its quota, or a full slate, loses that candidate, not the round.
        try { this.duration.propose(candidate); }
        catch (error) { this.audio?.report?.("form_candidate_refused", { id: candidate.id, error: error.message }); }
      }
      // Each bot's ratings over the slate, a variant it did not name level with its plan (slateRatings), a
      // performer's voice weighted as a person's, and the voice that plans the returns with its share (formWeights).
      for (const [bot, preference] of preferences) {
        if (!participants.includes(bot)) continue;
        this.duration.prefer({ bot, ratings: slateRatings(preference, candidates) });
      }
      decision = this.duration.seal({ weights: formWeights(participants, this.performerVoices, { policy, planners: this.thematicVoices }) });
    } catch (error) {
      // Too soon after the last decision, or a slate this round cannot hold.
      // The incumbent stands, which is the whole point of having one.
      this.audio?.report?.("form_negotiation_skipped", { error: error.message });
      if (this.duration.round) this.duration.round = null;
      return null;
    }
    const agreed = decision.selected;
    if (!agreed) return null;
    const agreedPlan = agreed.planId ?? agreed.id;
    this.agreedFormId = agreedPlan;
    if (agreed.plan) this.activeFormPlan = agreed.plan;
    if (agreedPlan === this.formPlan.planId) {
      // Its own form, as one of the variants it offered: that becomes the form.
      if (agreed.variant && this.formPlan.payload.candidateEndpoint?.bar !== agreed.endBar) this.adoptVariant(agreed, clock);
    } else if (this.conceded !== agreedPlan) {
      // Yield if the ensemble agreed on someone else's form, once per winner.
      this.conceded = agreedPlan;
      const { payload, options } = concessionPayload(this.formPlan, agreedPlan, { policy });
      this.formPlan = this.plans.revise(this.formPlan, payload, options);
      this.broadcast("plan", [this.formPlan]);
    }
    return this.activeFormPlan || null;
  }
  // The duration policy a plan carries, where it carries one this bot can read.
  planPolicy(plan) {
    const declared = plan?.payload?.durationPolicy;
    if (!declared || typeof declared !== "object") return null;
    try { return durationPolicy(declared); } catch { return null; }
  }
  // The policy this bot negotiates under: the render's, where its spec sets one
  // (length.policy, a human's setting, which reaches every bot with the render's
  // end), over its own configuration's.
  negotiationPolicy() {
    const declared = this.audio?.renderEnd?.policy ?? null;
    if (this.policyFor && this.policyFrom === declared) return this.policyFor;
    let policy = this.negotiation;
    if (declared) {
      const configured = CONFIG.formBot?.negotiation || {};
      try { policy = formNegotiationPolicy({ ...configured, duration: { ...(configured.duration || {}), ...declared } }); }
      catch (error) { this.audio?.report?.("form_policy_refused", { error: error.message }); }
    }
    this.policyFrom = declared;
    this.policyFor = policy;
    return policy;
  }
  // The ensemble chose one of the variants this bot offered: it becomes the
  // form, published as a revision of the same plan with new variants around it.
  // A stop it had proposed for the old ending is withdrawn, so that one is
  // proposed for the new ending, a phrase ahead of it as always.
  adoptVariant(agreed, clock) {
    const { variant, ...payload } = agreed.plan.payload,
      phraseBars = payload.phraseBars || clock.meter?.phraseBars || bandPhraseBars(),
      declared = this.declaredEndBar(clock),
      variants = formVariants({ sections: payload.sections, phraseBars, appliesAt: this.formPlan.appliesAt, endBar: declared?.bar ?? null }),
      ending = payload.candidateEndpoint;
    this.formPlan = this.plans.revise(this.formPlan, { ...payload, ...(variants.length ? { variants } : {}), adopted: variant }, {
      expiresAt: { ...ending, bar: ending.bar + phraseBars, phrase: ending.phrase + 1 },
      horizon: payload.totalPhrases + 1,
      rationale: `The ensemble chose this form's variant ${variant}, ending at bar ${ending.bar}.`,
    });
    this.broadcast("plan", [this.formPlan]);
    this.activeFormPlan = this.formPlan;
    if (this.stopProposal && !this.stopCommitment) this.stopProposal = null;
  }
  generateSections() {
    const config = CONFIG.formBot,
      archetype = weightedChoice(
        config.archetypes,
        config.archetypes.map((item) => item.weight),
      );
    return {
      archetype: archetype.name,
      sections: archetype.roles.map((role, index) => ({
        id: index,
        role,
        phrases: weightedChoice(
          config.sectionPhrases,
          config.sectionPhraseWeights,
        ),
        tension: config.roleTension[role] ?? 0.5,
        closure:
          index === archetype.roles.length - 1
            ? (config.roleClosure[role] ?? 0.8)
            : (config.roleClosure[role] ?? 0.1),
      })),
    };
  }
  // Where the render ends, when it says so (audio.renderEnd, a render's length, which reaches every bot): the transport
  // bar the ensemble stops at, and whether that length is the piece's (fixed) or only the most it plays (untilEnding).
  // A length in ticks or seconds is counted in the meter and tempo in force now. Null in a live room.
  declaredEndBar(clock) {
    const end = this.audio?.renderEnd;
    if (!end) return null;
    const meter = clock?.meter || {},
      pulses = meter.pulsesPerBar || bandMeter().pulsesPerBar;
    let bar = null;
    if (Number.isInteger(end.bars)) bar = end.bars;
    else if (Number.isFinite(end.ticks)) bar = Math.floor(end.ticks / pulses);
    else if (Number.isFinite(end.seconds) && clock?.bpm > 0)
      bar = Math.floor(end.seconds / ((pulses * 60) / clock.bpm / (meter.subdivision || bandMeter().subdivision)));
    return Number.isInteger(bar) && bar > 0 ? { bar, fixed: !end.untilEnding } : null;
  }
  proposeForm(clock) {
    this.formParticipants.clear();
    const phraseBars = clock.meter?.phraseBars || bandPhraseBars(),
      createdAt = {
        bar: clock.bar || 0,
        phrase: clock.phrase || 0,
        section: 0,
      },
      appliesAt = {
        bar: createdAt.bar + phraseBars,
        phrase: createdAt.phrase + 1,
        section: 0,
      };
    // The composition's length (the negotiated composition length's adoption, step 1): where the render declares its
    // length, the form fits it, its drawn sections spread over the phrases left before it (fitSectionsToPhrases), so the
    // piece ends where the render does rather than early, into silence, or past it, cut off; where the length is only
    // the most the render plays, a longer form is fitted to it. The sections are drawn first either way, so the random
    // stream is the same.
    let generated = this.generateSections();
    const drawn = generated.sections,
      declared = this.declaredEndBar(clock),
      room = declared ? Math.floor((declared.bar - appliesAt.bar) / phraseBars) : null,
      drawnPhrases = drawn.reduce((sum, section) => sum + section.phrases, 0);
    if (room >= 1 && (declared.fixed ? room !== drawnPhrases : drawnPhrases > room))
      generated = { ...generated, sections: fitSectionsToPhrases(generated.sections, room) };
    this.lengthSource = declared ? (declared.fixed ? "the render's length" : "the render's most") : "the form drawn";
    // Where the length is the ensemble's to negotiate (anything but a fixed render length), the form comes with its
    // variants, a phrase shorter and a phrase longer, each complete with its own ending (formVariants; the adoption's
    // step 3). Where a render fixes its length, that length is a decision already taken, and none is offered.
    const totalPhrases = generated.sections.reduce(
        (sum, section) => sum + section.phrases,
        0,
      ),
      endpoint = {
        bar: appliesAt.bar + totalPhrases * phraseBars,
        phrase: appliesAt.phrase + totalPhrases,
        section: generated.sections.length,
      },
      variants = declared?.fixed ? [] : formVariants({ sections: generated.sections, phraseBars, appliesAt, endBar: declared?.bar ?? null });
    this.formPlan = this.preparePlan(
      "form",
      {
        schemaVersion: 1,
        ...generated,
        phraseBars,
        totalPhrases,
        candidateEndpoint: endpoint,
        extension: this.extension,
        // The form as drawn, before any length fitted it: its provenance (the variants change the form at its end).
        ...(variants.length ? { variants, drawn } : {}),
        // The policy the length is negotiated under travels with the form (the adoption's step 2).
        durationPolicy: this.negotiationPolicy().duration,
      },
      {
        createdAt,
        appliesAt,
        expiresAt: {
          ...endpoint,
          bar: endpoint.bar + phraseBars,
          phrase: endpoint.phrase + 1,
        },
        horizon: totalPhrases + 1,
        confidence: CONFIG.formBot.confidence,
        priority: CONFIG.formBot.priority,
        rationale:
          "Shape nested tension and relaxation into sections, then ask the participating agents whether the proposed closure is musically ready.",
      },
    );
    this.announcePlan(this.formPlan);
  }
  // **An ending the room has already passed moves to the next phrase it can
  // still reach.** The ending is planned in bars, counted in the phrase length
  // in force when the form was proposed, and this bot only acts at phrase
  // starts. Beside mh_PlexBOT the phrase length changes section by section, so
  // phrase starts stop landing where the plan expected them and the first one
  // at or after the lead bar can already be PAST the planned ending. The
  // proposal then "applied before it was created", threw, and threw again at
  // every phrase after it: eight bars apart in a rendered 18-bot piece, at
  // bars 41, 49 and 57, which therefore never got the ending it had been
  // planning since bar 1. Nothing moves when the plan is still ahead.
  reachable(endpoint, clock, phrases = 1) {
    const bar = clock.bar || 0,
      ahead = phrases * (clock.meter?.phraseBars || bandPhraseBars());
    if ((endpoint.bar || 0) >= bar + ahead) return endpoint;
    return { ...endpoint, bar: bar + ahead, phrase: (clock.phrase || 0) + phrases };
  }
  proposeStop(clock, ending = this.formPlan.payload.candidateEndpoint, form = this.formPlan) {
    // A phrase ahead, so there is a phrase in which to vote.
    const config = CONFIG.formBot,
      endpoint = this.reachable(ending, clock),
      deadline = {
        bar: Math.max(
          clock.bar || 0,
          endpoint.bar - (clock.meter?.phraseBars || bandPhraseBars()),
        ),
        phrase: Math.max(clock.phrase || 0, endpoint.phrase - 1),
        section: Math.max(0, endpoint.section - 1),
      };
    this.stopVotes.clear();
    const eligibleParticipants = [...this.formParticipants.keys()].sort();
    this.stopProposal = this.preparePlan(
      "lifecycle",
      {
        schemaVersion: 1,
        action: "stop",
        phase: "proposal",
        earliestAt: endpoint,
        deadline,
        quorum: config.quorum,
        minimumVotes: config.minimumVotes,
        eligibleParticipants,
        formPlanId: form.planId,
      },
      {
        createdAt: {
          bar: clock.bar || 0,
          phrase: clock.phrase || 0,
          section: clock.section || 0,
        },
        appliesAt: endpoint,
        expiresAt: {
          ...endpoint,
          bar: endpoint.bar + (clock.meter?.phraseBars || bandPhraseBars()),
          phrase: endpoint.phrase + 1,
        },
        horizon: config.stopLeadPhrases + 1,
        parents: [form.planId],
        parentDepth: form.ancestryDepth ?? 0,
        confidence: config.confidence,
        priority: config.stopPriority,
        rationale:
          "Invite each current agent to state whether it can finish at the candidate formal closure.",
      },
    );
    this.announcePlan(this.stopProposal);
  }
  evaluateStop(clock) {
    const config = CONFIG.formBot,
      participants = new Set(
        this.stopProposal.payload.eligibleParticipants || [],
      ),
      votes = [...this.stopVotes.values()].filter(
        (response) =>
          participants.has(response.responder) &&
          response.disposition !== "abstain",
      ),
      accepts = votes.filter((response) =>
        ["accept", "transform"].includes(response.disposition),
      ),
      eligibleCount = participants.size,
      ratio = eligibleCount ? accepts.length / eligibleCount : 0;
    if (votes.length >= config.minimumVotes && ratio >= config.quorum) {
      // The vote was for ending no earlier than this. If the phrases have
      // lengthened since and that point has gone by, the ensemble ends where
      // it is: this is a phrase boundary, and it is the nearest one to what
      // was agreed.
      const endpoint = this.reachable(this.stopProposal.payload.earliestAt, clock, 0);
      this.stopCommitment = this.preparePlan(
        "lifecycle",
        {
          schemaVersion: 1,
          action: "stop",
          phase: "commitment",
          decision: {
            eligible: eligibleCount,
            votes: votes.length,
            accepts: accepts.length,
            ratio,
            quorum: config.quorum,
          },
          formPlanId: this.stopProposal.payload.formPlanId,
          proposalPlanId: this.stopProposal.planId,
        },
        {
          createdAt: {
            bar: clock.bar || 0,
            phrase: clock.phrase || 0,
            section: clock.section || 0,
          },
          appliesAt: endpoint,
          expiresAt: {
            ...endpoint,
            bar: endpoint.bar + (clock.meter?.phraseBars || bandPhraseBars()),
            phrase: endpoint.phrase + 1,
          },
          horizon: 1,
          parents: [this.stopProposal.payload.formPlanId, this.stopProposal.planId],
          parentDepth: this.stopProposal.ancestryDepth,
          confidence: 1,
          priority: 1,
          rationale:
            "Commit the ensemble to the voted stopping point at a complete phrase boundary.",
        },
      );
      this.announcePlan(this.stopCommitment);
      this.broadcast("form/decision", [
        {
          status: "accepted",
          planId: this.stopCommitment.planId,
          ...this.stopCommitment.payload.decision,
          appliesAt: endpoint,
        },
      ]);
      return;
    }
    this.extension++;
    this.broadcast("form/decision", [
      {
        status: "extended",
        eligible: eligibleCount,
        votes: votes.length,
        accepts: accepts.length,
        ratio,
        required: config.quorum,
        extension: this.extension,
      },
    ]);
    this.formPlan = null;
    this.stopProposal = null;
    this.stopCommitment = null;
  }
  // **Its own answers are evidence too.** Every FormBOT hears every OTHER
  // bot's response to a form, but the plan coordinator answers "self" to its
  // own, so each decided over a slate missing exactly its own votes: two
  // FormBOTs weighed different evidence, their margins over the hysteresis
  // differed, and a meter change that tipped one into a new form left the
  // other on the old one. Agreement by computation needs the same inputs
  // everywhere (the mathematical audit's B12).
  respondToPlan(plan, disposition, options = {}) {
    const response = super.respondToPlan(plan, disposition, options);
    if (plan?.kind === "form" && response) {
      this.planResponses.push(response);
      // Bounded as the base agent bounds what it hears (MAX_PLAN_HISTORY).
      if (this.planResponses.length > 512) this.planResponses.splice(0, this.planResponses.length - 512);
    }
    return response;
  }
  // The form this bot's decisions follow: its own until the ensemble agrees on
  // another, and then that one. A FormBOT that conceded still reported its own
  // form's progress and proposed its own ending, so the room heard two forms'
  // progress and two endings (the mathematical audit's B12 and I04).
  governingForm() {
    if (!this.agreedFormId || this.agreedFormId === this.formPlan.planId) return this.formPlan;
    const agreed = this.activeFormPlan?.planId === this.agreedFormId ? this.activeFormPlan : this.futurePlans.get(this.agreedFormId);
    return agreed ?? this.formPlan;
  }
  // Whether this bot proposes the ending of the form it follows: its own,
  // always; another FormBOT's (a form that states its ending), never, since its
  // author does; one whose author proposes no endings (mh_PlexBOT's), only the
  // FormBOT that sorts first among those in the room, so it is proposed once.
  endsForm(governing) {
    if (governing === this.formPlan) return true;
    if (governing.payload?.candidateEndpoint) return false;
    const formBots = [this.formPlan, ...this.futurePlans.values()]
      .filter(plan => plan?.kind === "form" && plan.payload?.candidateEndpoint).map(plan => String(plan.author)).sort();
    return formBots[0] === String(this.instanceId);
  }
  // Where a form this bot did not write ends, as a logical position: its last
  // bar, each section at its own phrase length (formEndBar).
  endingOf(form, clock) {
    const bar = formEndBar(form, { policy: this.negotiation, phraseBars: clock.meter?.phraseBars }) ?? (clock.bar || 0),
      phraseBars = clock.meter?.phraseBars || bandPhraseBars();
    return { bar, phrase: (clock.phrase || 0) + Math.max(0, Math.ceil((bar - (clock.bar || 0)) / phraseBars)),
      section: form.payload?.sections?.length ?? 0 };
  }
  onPlanResponse(response) {
    if (
      response.planId === this.formPlan?.planId &&
      response.disposition !== "abstain"
    )
      this.formParticipants.set(response.responder, response);
    if (Number(response.payload?.owedReturns) > 0 && response.responder && this.thematicVoices.size < 16)
      this.thematicVoices.add(String(response.responder));
    if (response.planId === this.stopProposal?.planId)
      this.stopVotes.set(response.responder, response);
  }
  onTick(
    tick,
    clock,
  ) {
    if (!clock.phraseStart || clock.bar === this.lastPhrase) return;
    this.lastPhrase = clock.bar;
    if (!this.formPlan) {
      this.proposeForm(clock);
      return;
    }
    // Reannounce the current revision for agents that joined since its first
    // publication; receivers' plan idempotency suppresses duplicate handling.
    this.broadcast("plan", [this.formPlan]);
    this.negotiateForm(clock);
    // Once the ensemble agrees on a form, that is the form this bot reports and
    // ends, not its own (governingForm). Its own ending is withdrawn if it had
    // proposed one, since its vote is for a form nobody is following.
    const governing = this.governingForm();
    this.broadcast("form/progress", [formProgress(governing, clock)]);
    if (!this.endsForm(governing)) {
      if (this.stopProposal && !this.stopCommitment) this.stopProposal = null;
      return;
    }
    const lead = CONFIG.formBot.stopLeadPhrases,
      phraseBars = governing.payload.phraseBars || governing.payload.sections?.at(-1)?.phraseBars || clock.meter?.phraseBars || bandPhraseBars(),
      endpoint = governing === this.formPlan ? this.formPlan.payload.candidateEndpoint : this.endingOf(governing, clock);
    const leadBar = endpoint.bar - lead * phraseBars;
    if (!this.stopProposal && (clock.bar || 0) >= leadBar) {
      this.proposeStop(clock, endpoint, governing);
      return;
    }
    if (
      this.stopProposal &&
      !this.stopCommitment &&
      (clock.bar || 0) >= this.stopProposal.payload.deadline.bar
    )
      this.evaluateStop(clock);
  }
}

export class CoordBot extends Agent {
  constructor(...args){
    super(...args);
    this.states=new Map();
    this.lastPhrase=-1;
  }
  onMessage(message){
    super.onMessage(message);
    if(message.address==="/broadcast/agentState")
      recordAgentState(this.states,message.args?.[0]);
  }
  onTick(tick,clock){
    if(!clock.phraseStart||clock.bar===this.lastPhrase)return;
    this.lastPhrase=clock.bar;
    const states=[...this.states.values()].filter(state=>
      state.state==="performing"&&!state.messageOnly
    ),appliesAt={bar:clock.bar||0,phrase:clock.phrase||0,section:clock.section||0};
    for(const placement of ensembleMixPlacements(states,CONFIG.coord.mix,clock.phrase||0))
      this.send("/agent/mix",[{...placement,appliesAt,coordinator:this.instanceId,
        rationale:"Balance foreground focus, accompaniment support, and ensemble-size headroom."}]);
  }
}

export class TuneBot extends Agent {
  constructor(...args) {
    super(...args);
    this.harmony = [];
    this.harmonyPlan = null;
    this.lastPhrase = -1;
    this.lastTunedHarmonyPlanId = null;
  }
  onMessage(message) {
    super.onMessage(message);
    if (
      message.address === "/broadcast/plan" &&
      message.args?.[0]?.kind === "harmony"
    ) {
      const plan = message.args[0],
        chords = plan.payload?.chords;
      if (Array.isArray(chords) && chords.length) {
        this.harmonyPlan = {
          plan,
          chords: chords
            .map((chord) => chord.map(Number).filter(Number.isFinite))
            .filter((chord) => chord.length),
        };
        if (this.currentClock && plan.planId !== this.lastTunedHarmonyPlanId) {
          this.lastTunedHarmonyPlanId = plan.planId;
          this.createTuning(this.currentClock, true);
        }
      }
    }
    if (message.address.endsWith("/plan/chords")) {
      const parsed = parseChordPlan(message.args);
      if (parsed.length) this.harmony = parsed;
    }
  }
  createTuning(clock, applyNow = false) {
    const config = CONFIG.tune,
      harmony = this.harmonyPlan?.chords?.length
        ? this.harmonyPlan.chords
        : this.harmony;
    // Nothing heard yet: the band's opening, a progression drawn from the piece's seed.
    const chords = harmony.length ? harmony : this.openingProgression(4);
    const parameters = {
      purity: config.purity,
      continuity: config.continuity,
      grounding: config.grounding,
      complexity: config.complexity,
      primeSoftness: config.primeSoftness,
      oddLimit: config.oddLimit,
      iterations: config.iterations,
      chordExactness: config.chordExactness,
      exactComplexity: config.exactComplexity,
      exactPrimeSoftness: config.exactPrimeSoftness,
      exactOddLimit: config.exactOddLimit,
      exactRatios: config.exactRatios.map((pair) => [...pair]),
    };
    const system = tuningSystem({
      divisions: config.divisions,
      period: config.period,
      purity: config.purity,
      complexity: config.complexity,
      primeSoftness: config.primeSoftness,
      oddLimit: config.oddLimit,
    });
    const compromise = adaptiveJustIntonation(chords, parameters),
      exact = exactChordJustIntonation(chords, {
        exactness: 1,
        complexity: config.exactComplexity,
        primeSoftness: config.exactPrimeSoftness,
        oddLimit: config.exactOddLimit,
        ratios: config.exactRatios,
      }),
      tunedChords = exact.map((chord, index) =>
        chord.map(
          (pitch, voice) =>
            compromise[index][voice] +
            (pitch - compromise[index][voice]) * config.chordExactness,
        ),
      ),
      phraseBars = clock.meter?.phraseBars || bandPhraseBars(),
      appliesAt = applyNow
        ? {
            bar: clock.bar || 0,
            phrase: clock.phrase || 0,
            section: clock.section || 0,
          }
        : {
            bar: (clock.bar || 0) + phraseBars,
            phrase: (clock.phrase || 0) + 1,
            section: clock.section || 0,
          };
    const durations =
      this.harmonyPlan?.plan?.payload?.durations
        ?.map(Number)
        .filter((value) => Number.isFinite(value) && value > 0) ||
      chords.map(() => 1);
    const ratios = chordRatioProvenance(chords, {
      ...parameters,
      ratios: config.exactRatios,
    });
    const chordReferencePitches = chords.map((chord) => Number(chord[0])),
      referencePitch =
        chordReferencePitches.find(Number.isFinite) ??
        this.bandOpening.tonic;
    return this.publishPlan(
      "tuning",
      {
        system,
        period: config.period,
        referencePitch,
        chordReferencePitches,
        nominalChords: chords.map((chord) => [...chord]),
        chords: tunedChords,
        ratios,
        durations:
          durations.length === chords.length ? durations : chords.map(() => 1),
        sourcePlanId: this.harmonyPlan?.plan?.planId || null,
        parameters,
      },
      {
        createdAt: {
          bar: clock.bar || 0,
          phrase: clock.phrase || 0,
          section: clock.section || 0,
        },
        appliesAt,
        expiresAt: {
          ...appliesAt,
          bar: appliesAt.bar + phraseBars,
          phrase: appliesAt.phrase + 1,
        },
        horizon: 1,
        parents: this.harmonyPlan?.plan ? [this.harmonyPlan.plan.planId] : [],
        parentDepth: this.harmonyPlan?.plan?.ancestryDepth || 0,
        confidence: config.confidence,
        priority: config.priority,
        rationale:
          "Offer a continuously parameterized tuning system and chord-root-relative just intonation for the next phrase.",
      },
    );
  }
  onTick(
    tick,
    clock,
  ) {
    if (!clock.phraseStart || clock.bar === this.lastPhrase) return;
    this.lastPhrase = clock.bar;
    if (
      !this.harmonyPlan ||
      this.harmonyPlan.plan.planId !== this.lastTunedHarmonyPlanId
    )
      this.createTuning(clock);
  }
}

export class SpaceBot extends Agent {
  constructor(...args) {
    super(...args);
    this.states = new Map();
    this.lastPhrase = -1;
  }
  onMessage(message) {
    super.onMessage(message);
    if(message.address==="/broadcast/agentState"&&message.args?.[0]?.instanceId)
      this.states.set(message.args[0].instanceId,message.args[0]);
  }
  onTick(tick,clock) {
    if(!clock.phraseStart||clock.phrase===this.lastPhrase)return;
    this.lastPhrase=clock.phrase;
    const allocations=spaceAllocation([...this.states.values()],CONFIG.space);
    if(!allocations.length)return;
    const phraseBars=clock.meter?.phraseBars||bandPhraseBars(),
      createdAt={bar:clock.bar||0,phrase:clock.phrase||0,section:clock.section||0},
      appliesAt={bar:createdAt.bar+phraseBars,phrase:createdAt.phrase+1,section:createdAt.section};
    this.publishPlan("orchestration",{schemaVersion:1,allocations},{
      createdAt,appliesAt,expiresAt:{...appliesAt,bar:appliesAt.bar+phraseBars,phrase:appliesAt.phrase+1},
      confidence:.78,priority:.66,
      rationale:"Allocate complementary density, phase, anchor, support, and response roles to reduce masking and downbeat crowding.",
    });
    for(const allocation of allocations)
      this.send("/agent/space",[{...allocation,appliesAt,coordinator:this.instanceId}]);
  }
}

export class MemoryBot extends Agent {
  constructor(...args) {
    super(...args);
    this.memory = new MotifMemory(CONFIG.memory);
    this.ranking = motifRankingPolicy(CONFIG.memory.ranking);
    this.insistencePlans = new Map();
    // A clip's content does not change once it is stored, and a query asks the
    // same questions of every candidate, so the answers are kept per record
    // rather than recomputed for each bot that asks.
    this.contents = new WeakMap();
    this.playbacks = new Map();
    this.activityRevision = 0;
    // What the form bots have said about the shape of the piece and where in it
    // the ensemble is. All of it arrives as broadcasts every bot receives.
    this.formRoles = null;
    this.formSection = -1;
    this.formProgress = null;
    // What has actually sounded, as distinct from what has been asked for.
    // The retention ledger answers a capacity question; this answers a formal
    // one, and conflating them is how activity gets mistaken for being heard.
    this.presentations = new PresentationHistory(CONFIG.memory?.presentation);
    // Composite hooks (the memorable motifs report, §6.4, §15.7): a figure several rhythm bots make together in a bar,
    // heard from the onsets they announce, kept as one family by its timing and roles, and each bar that sounds it one
    // presentation of the ensemble, not one a part.
    this.composites = new CompositeHooks();
    this.onsetsHeard = [];
    this.barHeard = null;
    // The themes, each section's material, and the returns the form owes (thematic-form.js): what sounded in which
    // section, heard as it was published or recalled, and on entering a section, what its role asks of the themes.
    this.thematic = new ThematicForm(CONFIG.memory?.thematic);
    this.returnActions = [];
    // Where each presented theme's window ends (by family), so what it still owes can be weighed against the form's
    // versions (owedFormAnswer), and what it last said of each form plan revision.
    this.returnWindows = new Map();
    this.formAnswers = new Map();
    // Whether it plans the returns (a render spec's `returns: false` keeps the record and plans none, for an A/B).
    this.planningReturns = args[2]?.returns !== false;
    // The lines of what the opening sections played, kept apart from the store's
    // capacity: a theme's clip may be culled before the form returns to it.
    this.openingLines = new Map();
    // Memory across seconds (the extreme-aesthetics report's §5.3, E20): each motive's identity, kept apart from its
    // record, and the family a record takes when it brings back a motive whose earlier record the store let go.
    this.identities = new MotifIdentities({ limit: this.memory.retention.policy.identityLimit });
    this.familyAliases = new Map();
    // The room's harmony bar by bar (the pool in force at each bar's start), so a return can bring back the harmony its
    // theme was heard in, and the return windows whose harmony this bot leads ({fromBar, toBar, pools}).
    this.harmonyByBar = new Map();
    this.returnHarmony = [];
    // Whether the room has said what its harmony is. `this.notes` holds a
    // default pool before anybody has, and a motif must not be bent to fit a
    // chord nobody played.
    this.harmonyHeard = false;
    // What was handed out in another harmony, by the id it was handed out
    // under, so that a player reporting it sounding credits the stored motif
    // it came from. Nothing handed out this way is stored.
    this.realizations = new Map();
  }
  // **A query is answered in the harmony of the moment.** A stored motif is
  // absolute pitches, and a bot that recalled one adopted them as they stood,
  // whatever the ensemble was playing by then. Measured in a rendered piece:
  // while ae_DroneBOT played recalled material 2 of its 6 notes were in the
  // chord in force (a D held against F A-flat C E-flat), against 65% the rest
  // of the time. So what is handed out is the motif realized in the current
  // harmony (shared/motif-harmony.js): each note keeps its place in the harmony
  // it was played against -- the captured phrase carries that -- and takes the
  // corresponding place in this one.
  //
  // What it is not. It is never stored: the library holds what was played, and
  // a realization is a development that names its parent. It never serializes
  // a chord, re-times anything, quantizes a pitch or touches percussion. And it
  // is not the last word: the bot that receives it may transform it further by
  // its own lights. A request that wants the motif exactly as stored says
  // `harmonize: false`, and /agent/memory/get is always exact.
  //
  // The harmony is the requester's if the query names one (`harmony`, a pool),
  // and otherwise the room's as this bot hears it -- which, because every bot
  // ranks harmony the same way, is the harmony the requester hears too.
  // The harmony an answer is for, or null when there is none to answer in: the
  // request wants its motifs exactly as stored, or nobody has said what the
  // harmony is. Asked once per query, by the choosing and by the realizing, so
  // the motifs are chosen for the harmony they are then realized in.
  // Whether to is a standing preference (`ranking.harmonize`, switched like the
  // rest of the policy by /agent/memory/policy) that a request may override
  // either way with its own `harmonize`.
  targetHarmony(payload) {
    const query = payload.query || {},
      wanted = typeof query.harmonize === "boolean" ? query.harmonize : this.ranking.harmonize;
    if (!wanted) return null;
    const asked = Array.isArray(query.harmony) ? normalizePitchPool(query.harmony) : [],
      pool = asked.length ? asked : this.harmonyHeard ? [...this.notes] : [];
    return pool.length ? { pool, from: asked.length ? "query" : "room" } : null;
  }
  inHarmony(motifs, payload) {
    const target = this.targetHarmony(payload);
    if (!target) return { motifs };
    const { pool } = target, realized = [], reports = [];
    for (const motif of motifs) {
      // A required theme keeps its pitches: harmony is a lower-priority musical preference.
      if(insistenceOf(motif)===1){realized.push(motif);reports.push({motifId:motif.motifId,as:motif.motifId,unchanged:true,required:true});continue}
      try {
        // The same shape-against-place preference the choosing used.
        const { motif: fitted, report } = realizeMotif(motif, pool, { movePenalty: this.ranking.movePenalty });
        if (fitted !== motif) {
          this.realizations.delete(fitted.motifId);
          this.realizations.set(fitted.motifId, motif.motifId);
          while (this.realizations.size > 256) this.realizations.delete(this.realizations.keys().next().value);
        }
        realized.push(fitted);
        reports.push({ motifId: motif.motifId, as: fitted.motifId, ...report });
      } catch (error) {
        // A clip this cannot re-pitch (a profile-specific note attribute) is
        // still a clip the requester asked for: it goes out as stored.
        realized.push(motif);
        reports.push({ motifId: motif.motifId, as: motif.motifId, unchanged: true, error: error.message });
      }
    }
    return { motifs: realized, harmony: { pool, from: target.from, motifs: reports } };
  }
  // The layer a bot declares (casting declarations: its stated layer, else its
  // category's, else its performance type's: beat, bass, melody, filler,
  // texture), which the casting reads too. Its performanceType had stood in as a
  // proxy; a bot the declarations cannot place still falls back to it.
  performerLayer(player) {
    const definition = this.definitionFor(player);
    if (!definition) return "";
    return declarationOf(definition.id, definition).layer || definition.performanceType || "";
  }
  // Where a bar falls in the form the ensemble follows: the plan its progress
  // reports name, placed in bars as ManageBOT places it (compileSections).
  sectionOfBar(bar) {
    const plan = this.receivedPlans.get(String(this.formProgress?.formPlanId || ""));
    if (!plan || !Number.isFinite(Number(bar))) return null;
    return sectionAt(compileSections(plan, { phraseBars: this.currentClock?.meter?.phraseBars || bandPhraseBars() }), Number(bar));
  }
  // Material that sounded, filed under the section it was played in: a phrase
  // its author published as it played it (at the bar it was made), or a stored
  // motif another bot reported sounding (now).
  // A motif's family, through the identity it brings back: a record of a motive heard before keeps that motive's family.
  familyOfMotif(motif) {
    const own = this.familyAliases.get(String(motif?.motifId ?? "")), family = familyOf(motif);
    return own ?? this.familyAliases.get(family) ?? family;
  }
  hearMaterial(motif, { player = motif?.author, bar = motif?.metadata?.createdAt?.bar, family: given = null } = {}) {
    if (!motif) return;
    const section = this.sectionOfBar(bar);
    if (!section) return;
    const notes = motifNotes(motif), pitched = notes.filter(event => event.pitches?.some(Number.isFinite)).length,
      family = given ?? this.familyOfMotif(motif);
    // A section is known by the bar it starts at (thematic-form.js), so a form drawn again or revised keeps its own.
    this.thematic.hear({ motifId: motif.motifId, family, author: motif.author, player,
      layer: this.performerLayer(player), sectionIndex: section.startBar, role: section.role, bar: Number(bar),
      notes: pitched, line: pitched >= 3 });
    const home = this.thematic.home();
    if ((home === null || section.startBar <= home) && !this.openingLines.has(family) && this.openingLines.size < 32)
      this.openingLines.set(family, { motifId: motif.motifId, author: motif.author, family, line: topLine(notes).slice(0, 64) });
    // What the form holds on to, the store holds on to (§5.3): the themes and the opening's lines rank above every tier
    // of use but a pinned record, so a dense run cannot evict a slower structural motive.
    for (const id of new Set([...this.thematic.themes().map(theme => theme.motifId), ...[...this.openingLines.values()].map(line => line.motifId)]))
      this.memory.retention.setSalient(id, "the form's material");
  }
  // On entering a section, the returns its role asks of the themes
  // (thematic-form.js returnsFor). Each theme to be presented goes out as a
  // motif plan carrying its clip and the return action, for the voices that
  // carry a line to take up in the phrase given it (MemoryThemes); the rest are
  // kept for the report. The section is the governing form's, as progress
  // reports it.
  planReturns(progress) {
    const plan = this.receivedPlans.get(String(progress?.formPlanId || ""));
    if (!plan) return;
    const sections = compileSections(plan, { phraseBars: this.currentClock?.meter?.phraseBars || bandPhraseBars() });
    this.planSectionReturns(sections[Math.trunc(Number(progress.sectionIndex))]);
  }
  // The returns a section asks for, each presented theme published as a motif plan (planReturns). Asked again where
  // the form was revised under the section, it places only what it has not placed (ThematicForm.returnsFor).
  planSectionReturns(section) {
    if (!section || !this.planningReturns) return;
    const actions = this.thematic.returnsFor({ sectionIndex: section.startBar, role: section.role,
      fromBar: section.startBar, toBar: section.endBar, phraseBars: section.phraseBars });
    for (const action of actions) {
      this.returnActions.push(action);
      if (this.returnActions.length > 64) this.returnActions.shift();
      if (action.action !== "present") continue;
      // The theme's line, not its clip: a clip can outgrow a plan's payload, and a line is what a voice takes up.
      const stored = this.memory.get(action.motifId),
        theme = stored ? { motifId: stored.motifId, author: stored.author, family: action.family, line: topLine(motifNotes(stored)).slice(0, 64) }
          : this.openingLines.get(action.family);
      if (!theme || theme.line.length < 3) continue;
      // A window already over when the section is heard (a form placed in bars that the room has run ahead of) is
      // moot; one already begun starts now.
      const now = logicalPosition(this.currentClock || {});
      if (action.window.toBar <= now.bar) continue;
      const appliesAt = action.window.fromBar > now.bar ? { bar: action.window.fromBar, phrase: now.phrase, section: section.index } : now,
        expiresAt = { bar: action.window.toBar, phrase: now.phrase + 1, section: section.index };
      try {
        this.publishPlan("motif", { schemaVersion: 1, theme, return: action }, {
          createdAt: now, appliesAt, expiresAt, confidence: .7, priority: .6, rationale: action.because,
        });
        this.returnWindows.set(action.family, action.window.toBar);
        if (this.returnWindows.size > 64) this.returnWindows.delete(this.returnWindows.keys().next().value);
        if (!action.transformation) this.planReturnHarmony(action, section, { appliesAt, expiresAt, now, theme });
      } catch (error) { this.audio?.report?.("return_plan_refused", { family: action.family, error: error.message }); }
    }
  }
  // **A return brings back the harmony its theme was heard in.** The top voices drawn to a theme alone were heard as no
  // change (the user, 27 September, on the thematic-returns A/B: "I didn't notice change worth commenting on"): the
  // harmony of the moment capped how often a top voice could land on the theme's pitches. So where the form returns (a
  // presented theme with no transformation; a development's is heard against new harmony), this bot leads the harmony
  // for the theme's window: the pools of the bars under the theme's first hearing, in order, as a harmony plan above
  // the chord players' (0.55 to 0.6) and below a performer's (1), then sent bar by bar as a chord player sends its pool
  // (onTick). Where the home's harmony is unknown for a bar, the nearest known bar before it stands. With it, a
  // constraint (pitch-constraints.js): the theme's own notes admitted to the voices' top, so that a voice taking the theme
  // up takes its notes as they were first heard over this harmony, their dissonances against it their own.
  planReturnHarmony(action, section, { appliesAt, expiresAt, now, theme = null }) {
    const first = this.thematic.firstBarOf(action.family), bars = action.window.toBar - action.window.fromBar;
    if (first === null || !(bars > 0) || !this.harmonyByBar.size) return;
    const known = [...this.harmonyByBar.keys()].sort((a, b) => a - b), poolAt = bar => {
      const before = known.filter(value => value <= bar).at(-1) ?? known[0];
      return this.harmonyByBar.get(before);
    };
    const pools = Array.from({ length: bars }, (_, index) => [...poolAt(first + index)]);
    if (pools.some(pool => !pool?.length)) return;
    const beats = Number(this.currentClock?.meter?.numerator) || bandMeter().numerator;
    this.publishPlan("harmony", { schemaVersion: 1, chords: pools.map(pool => [...pool]), durations: pools.map(() => beats),
      maximumHoldBeats: beats, source: "return",
      ...(theme?.line?.length ? { constraints: [{ voice: "top", admits: [...new Set(theme.line.map(note => +(((note.pitch % 12) + 12) % 12).toFixed(6)))], source: "return" }] } : {}) }, {
      createdAt: now, appliesAt, expiresAt: { ...expiresAt, bar: action.window.toBar }, confidence: .8, priority: .7,
      rationale: `The form returns: ${action.family} in the harmony it was first heard in, bar by bar from bar ${first}.`,
    });
    this.returnHarmony.push({ fromBar: action.window.fromBar, toBar: action.window.toBar, pools, family: action.family });
    if (this.returnHarmony.length > 16) this.returnHarmony.shift();
  }
  // The piece's length, from what this bot has set out to do (the negotiated composition length's preferences from the
  // completion of a bot's own intentions: docs/FORM_NEGOTIATION.md §4b). Where the ending comes near with a return still
  // owed, it rates the form's versions by how many of the owed returns each lets sound (owedFormAnswer). Answered when a
  // form plan arrives and at each bar where its view has changed; with no view it stays ready for every version, as the
  // framework's acceptance says. A revision of the governing form re-plans the section in force, so a phrase the
  // ensemble granted it is used.
  onPlan(plan) {
    super.onPlan(plan);
    if (plan?.kind !== "form") return;
    this.answerForm(plan, this.currentClock);
    if (String(this.formProgress?.formPlanId || "") === String(plan.planId) && this.currentClock)
      this.planSectionReturns(sectionAt(compileSections(plan, { phraseBars: this.currentClock.meter?.phraseBars || bandPhraseBars() }), Number(this.currentClock.bar)));
  }
  onTick(tick, clock) {
    if (!clock?.barStart) return;
    this.closeBar(clock);
    if(clock.phraseStart)this.refreshInsistence();
    // The pool in force as the bar begins, and, in a return's window, the one this bot leads for the bar.
    if (this.harmonyHeard && this.notes?.length) {
      this.harmonyByBar.set(clock.bar, [...this.notes]);
      if (this.harmonyByBar.size > 512) this.harmonyByBar.delete(this.harmonyByBar.keys().next().value);
    }
    this.returnHarmony = this.returnHarmony.filter(window => clock.bar < window.toBar);
    const leading = this.returnHarmony.find(window => clock.bar >= window.fromBar);
    if (leading) this.broadcast("notepool", leading.pools[clock.bar - leading.fromBar]);
    const now = logicalPosition(clock);
    for (const plan of this.futurePlans.values())
      if (plan.kind === "form" && compareLogicalPosition(now, plan.expiresAt) < 0) this.answerForm(plan, clock);
  }
  answerForm(plan, clock) {
    if (!clock) return;
    const owed = this.planningReturns ? this.thematic.owed().map(theme => theme.family) : [],
      answer = owedFormAnswer(plan, { bar: clock.bar, window: CONFIG.formBot?.stopLeadPhrases ?? 2, phraseBars: clock.meter?.phraseBars,
        owed, windows: this.returnWindows, issued: this.thematic.issued, placed: this.thematic.placed, policy: this.thematic.policy });
    const key = `${plan.planId}:${plan.revision}`, said = JSON.stringify(answer), before = this.formAnswers.get(key);
    // Nothing to add to the readiness it answered the plan with.
    if (before === said || (before === undefined && answer === null)) return;
    this.formAnswers.set(key, said);
    if (this.formAnswers.size > 64) this.formAnswers.delete(this.formAnswers.keys().next().value);
    this.respondToPlan(plan, answer?.disposition ?? "accept", { createdAt: plan.createdAt,
      payload: answer ? { variants: answer.variants, owedReturns: owed.length } : { readyAt: plan.appliesAt },
      rationale: answer?.rationale ?? "No return owed that another version of the form would change." });
  }
  thematicReport() { return { ...this.thematic.report(), actions: [...this.returnActions] } }
  // Which bot an instance id belongs to. Every transport builds the id from the
  // bot's NAME -- "ae_DroneBOT:4", or "studio::ae_DroneBOT:4" from another
  // machine -- and the catalog is keyed by definition id, so looking the first
  // segment up directly found nothing for any bot in any real room: no
  // presentation was ever filed under a layer, and no requester ever had
  // capabilities. It only ever worked for the ids the unit tests made up
  // ("drone:1"), which is how it went unnoticed until a render was looked at.
  // The definitions are those agents.js registers once it has made the registry (definitions.js): this module is one
  // agents.js imports, so it does not import agents.js back.
  definitionFor(instance) {
    const text = String(instance || ""),
      local = text.includes("::") ? text.slice(text.lastIndexOf("::") + 2) : text,
      name = local.includes(":") ? local.slice(0, local.lastIndexOf(":")) : local;
    if (!name) return null;
    if (Object.hasOwn(agentDefinitions(), name)) return agentDefinitions()[name];
    MemoryBot.byName ||= new Map(Object.values(agentDefinitions()).map(definition => [definition.name, definition]));
    return MemoryBot.byName.get(name) || null;
  }
  // How far into the piece this is, in beats. The room counts its own beats
  // and that count survives a change of meter; bar x numerator does not. Under
  // mh_PlexBOT the numerator changes section by section, so leaving an 11/8 for
  // a 4/4 moved "now" from beat 440 back to beat 160, and every gap measured
  // across the change came out negative: a motif last heard "-129 beats ago",
  // which reads as an immediate repetition forever. Measured in a render of
  // exactly that pairing. The arithmetic stays as the fallback for a clock
  // that carries no count.
  // The onsets a rhythm bot announces (/broadcast/onsets), kept for the bar they fall in.
  hearOnsets(payload) {
    if (!payload || !Array.isArray(payload.onsets)) return;
    for (const onset of payload.onsets.slice(0, 64))
      if (Number.isFinite(Number(onset?.tick))) this.onsetsHeard.push({ voice: String(payload.voice ?? ""), tick: Number(onset.tick), kind: onset.kind ?? null });
    if (this.onsetsHeard.length > 2048) this.onsetsHeard.splice(0, this.onsetsHeard.length - 2048);
  }
  // As a bar begins, the one before: its composite, if its parts made one, heard as a family and recorded once as a
  // presentation of the ensemble (a new realization, where other voices took its roles, a handoff).
  closeBar(clock) {
    const last = this.barHeard, pulses = Number(clock.meter?.pulsesPerBar);
    if (last) {
      const composite = compositeOf(this.onsetsHeard, { start: last.start, pulses: last.pulses, meter: last.meter });
      const heard = this.composites.hear(composite, { beats: last.beats });
      if (heard) this.presentations.record({ motifId: heard.family, family: heard.family, author: "ensemble", player: "ensemble", layer: "composite",
        mode: "composite", occurrence: `${heard.family}:${last.bar}`, atBeats: last.beats, role: this.formProgress?.role || "",
        progress: this.formProgress?.progress ?? null, sectionIndex: this.formSection >= 0 ? this.formSection : null,
        transformation: heard.newRealization ? "handoff" : null, notes: composite.events.length,
        indices: composite.events.map((_, index) => index), core: composite.events.map((_, index) => index) });
      this.onsetsHeard = this.onsetsHeard.filter(onset => onset.tick >= last.start + last.pulses);
    }
    this.barHeard = Number.isInteger(clock.bar) && pulses > 0 && Number.isFinite(Number(clock.tick))
      ? { bar: clock.bar, start: Number(clock.tick) - (Number(clock.tickInBar) || 0), pulses, beats: this.clockBeats(),
        meter: clock.meter?.label ?? `${clock.meter?.numerator}/${clock.meter?.denominator}` }
      : null;
  }
  compositeReport() { return this.composites.report() }
  clockBeats() {
    const clock = this.currentClock || {}, counted = Number(clock.ensembleBeat);
    if (clock.ensembleBeat !== undefined && clock.ensembleBeat !== null && Number.isFinite(counted)) return counted;
    return (Number(clock.bar) || 0) * (Number(clock.meter?.numerator) || bandMeter().numerator) + (Number(clock.beat) || 0);
  }
  // The richest of the three, and the one both form bots send: mh_FormBOT and
  // mh_PlexBOT each broadcast this once a phrase, and it names the role and how
  // far through the form the ensemble is in one message. Nothing else in the
  // protocol says how far through the piece anything is.
  observeProgress(payload) {
    if (!payload || typeof payload !== "object") return;
    const progress = Number(payload.overallProgress), role = payload.sectionRole;
    const previous = this.formProgress;
    this.formProgress = {
      role: typeof role === "string" ? role : "",
      progress: Number.isFinite(progress) ? Math.min(1, Math.max(0, progress)) : null,
      section: Number.isFinite(Number(payload.sectionProgress))
        ? Math.min(1, Math.max(0, Number(payload.sectionProgress))) : null,
      totalPhrases: Math.max(0, Math.trunc(Number(payload.totalPhrases) || 0)),
      formPlanId: payload.formPlanId ?? null,
      sectionIndex: Number.isInteger(payload.sectionIndex) ? payload.sectionIndex : null,
    };
    // A section entered: the returns it owes.
    if (this.formProgress.sectionIndex !== null &&
      (previous?.sectionIndex !== this.formProgress.sectionIndex || previous?.formPlanId !== this.formProgress.formPlanId))
      this.planReturns(this.formProgress);
  }
  // The one piece of musical context a query does not carry. FormBOT broadcasts
  // its sections with their roles, and then which section is current; a strategy
  // that cares what the music is doing can read the role from here rather than
  // from a protocol change nobody has agreed to.
  observeForm(payload) {
    const sections = Array.isArray(payload?.sections) ? payload.sections : null;
    if (sections) this.formRoles = sections.map(section => String(section?.role || ""));
  }
  observeSection(index) {
    const at = Math.trunc(Number(index));
    if (Number.isFinite(at) && at >= 0) this.formSection = at;
  }
  // How much tension a role wants is each form bot's own number, read from the
  // config that defines it rather than restated here. Two bots broadcast form,
  // and they do not share a vocabulary: FormBOT works in establish/depart/
  // climax/return, mh_PlexBOT adds complex-frame, stabilize and complex-return
  // for metric instability. A compound role falls back to its head word, so a
  // complex-return is read as a return by a build that has never met one.
  roleValue(role, tables) {
    for (const key of [role, String(role).split("-").at(-1)])
      for (const table of tables) if (Number.isFinite(table?.[key])) return table[key];
    return undefined;
  }
  formContext() {
    // form/progress first: it is the only source that both form bots send, and
    // the only one that knows how far through the piece this is. The section
    // list is a fallback for a bot that publishes sections but no progress.
    const heard = this.formProgress,
      role = heard?.role || this.formRoles?.[this.formSection] || "";
    const position = heard?.progress === null ? {} : {progress: heard?.progress};
    if (!role) return position;
    const tension = this.roleValue(role, [CONFIG.formBot?.roleTension, CONFIG.plex?.roleComplexity]),
      closure = this.roleValue(role, [CONFIG.formBot?.roleClosure]);
    return {role,...position,
      ...(Number.isFinite(tension) ? {tension} : {}),
      ...(Number.isFinite(closure) ? {closure} : {})};
  }
  content(motif) {
    let facts=this.contents.get(motif);
    if(!facts){facts=motifContent(motif);this.contents.set(motif,facts)}
    return facts;
  }
  // The one thing a request says about the bot that sent it is who it is. An
  // instance id carries its definition id, and a definition declares the pitch
  // contract, so a MemoryBot can tell whether the requester could render a
  // microtonal phrase without any new message. Everything else a ranker would
  // want -- the plan, the section, the register actually in use -- is not on
  // /agent/memory/query, and an unknown requester stays unknown rather than
  // being guessed at.
  requesterCapabilities(requester) {
    return this.definitionFor(requester)?.planningCapabilities || null;
  }
  respond(payload, operation, motifs = [], extra = {}) {
    this.send("/agent/memory/response", [{
      target: payload.requester,
      memory: this.instanceId,
      requestId: payload.requestId,
      operation,
      motifs,
      total: this.memory.motifs.size,
      ...extra,
    }]);
  }
  // Where a motif came from is the only thing known about it before anything
  // uses it, and it is what separates a hand-imported clip from the phrase
  // every bot publishes at every phrase boundary.
  classifyOrigin(payload, motif) {
    if(payload.imported===true||String(motif.metadata.author||"").startsWith("file:"))return "imported";
    if(motif.metadata.parentMotifId)return "developed";
    if((motif.metadata.tags||[]).includes("captured-performance"))return "passagework";
    return "published";
  }
  store(payload) {
    try {
      const candidate = withInsistence(validateMotif(payload.motif),payload.insistence??(payload.motif?.metadata?.parentMotifId?0:payload.motif?.metadata?.insistence??0)),
        duplicate = this.memory.recent(CONFIG.memory.deduplicationWindow)
          .find(motif=>motif.author===candidate.author&&
            JSON.stringify(motif.events)===JSON.stringify(candidate.events)&&
            JSON.stringify(motif.metadata.clipHeader)===JSON.stringify(candidate.metadata.clipHeader)&&
            motif.metadata.endTime===candidate.metadata.endTime&&motif.metadata.defaultBpm===candidate.metadata.defaultBpm&&
            JSON.stringify(motif.timebase)===JSON.stringify(candidate.timebase));
      const at = this.memory.retention.now(), beats = this.clockBeats();
      if(duplicate){
        // Restating material is weak evidence that it is still current. It is
        // never promotion: the author is the only bot that can restate.
        this.memory.retention.record(duplicate.motifId,"restated",{actor:payload.requester||candidate.author});
        this.identities.heard(identityKey(duplicate,motifNotes(duplicate)),{at,beats});
        const updated=(payload.insistence!==undefined||candidate.metadata.insistence!==undefined)
          ?this.setMotifInsistence(duplicate.motifId,insistenceOf(candidate)):duplicate;
        this.respond(payload,"store",[updated],{ok:true,stored:false,reason:"duplicate-ump",
          retention:this.memory.retention.standing(duplicate.motifId)});
        return;
      }
      // A recurrence (§5.3): its author's notes again, in the same rhythm, whatever its controllers or articulation. It is
      // the motive heard before: its identity's exposure grows and its family is the one heard before, so a drone's
      // phrases are one object heard many times, not thousands of new ones. The clip itself, if its bytes differ, is
      // stored as any clip is (a different expression is a different performance), within the admission bound.
      const key = identityKey(candidate, motifNotes(candidate)), identity = this.identities.get(key),
        held = identity && this.memory.get(identity.motifId), origin = this.classifyOrigin(payload,candidate);
      // At most so many new records an author a second of elapsed time: past it, a dense run is heard, and not stored,
      // so it cannot turn the store over faster than the bound. A motive it repeats keeps its record fresh.
      if(!this.memory.retention.admissionAllowed(candidate.author,at)){
        if(identity)this.identities.heard(key,{at,beats});
        if(held)this.memory.retention.record(held.motifId,"recurred",{actor:candidate.author,at});
        if (origin === "published" || origin === "passagework") this.hearMaterial(candidate,{family:identity?.family??null});
        this.respond(payload,"store",[],{ok:true,stored:false,reason:"admission-rate",
          ...(held?{recurrenceOf:held.motifId}:{})});
        return;
      }
      if(insistenceOf(candidate)>0){
        insistenceInstruction(candidate);
        if(!this.memory.get(candidate.motifId)&&this.memory.recent(this.memory.limit).filter(item=>insistenceOf(item)>0).length>=MOTIF_INSISTENCE_LIMITS.active)
          throw new RangeError('Too many active motif preferences');
      }
      const motif = this.memory.remember(candidate,{origin,actor:payload.requester});
      // A development names its source. That is the author of the development
      // using the parent, and it is use by another bot when the authors differ.
      if(candidate.metadata.parentMotifId)
        this.memory.retention.record(candidate.metadata.parentMotifId,"developed",{actor:candidate.author});
      if(!this.memory.get(motif.motifId)){
        // The store was full of better-evidenced material, so this capture
        // never landed. Saying so lets the author consult memory instead of
        // publishing the same passagework again.
        const culled=this.memory.retention.evictions.at(-1);
        this.respond(payload,"store",[],{ok:true,stored:false,reason:"capacity",
          retention:culled?.motifId===motif.motifId?culled:null});
        return;
      }
      // Its identity: a new one, or a motive heard before, which keeps its family whether or not its record is still held.
      this.identities.describe(motif,key,{family:identity?.family??familyOf(motif),at,beats});
      if(identity){this.familyAliases.set(motif.motifId,identity.family);
        while(this.familyAliases.size>this.memory.retention.policy.identityLimit)this.familyAliases.delete(this.familyAliases.keys().next().value)}
      if (origin === "published" || origin === "passagework") this.hearMaterial(motif);
      if(insistenceOf(motif)>0)this.setMotifInsistence(motif.motifId,insistenceOf(motif));
      this.respond(payload, "store", [motif], { ok: true, stored: true,
        retention:this.memory.retention.standing(motif.motifId) });
    } catch (error) {
      this.respond(payload, "store", [], { ok: false, error: error.message });
    }
  }
  setRetentionPolicy(payload) {
    try {
      const requested = payload.policy&&typeof payload.policy==="object"?payload.policy:null;
      // What to keep and what to answer with are separate policies on one
      // message. The ranking half is built before either is applied, so a
      // refused weight leaves the capacity it arrived with untouched: a policy
      // message is accepted whole or not at all.
      const ranking = requested?.ranking&&typeof requested.ranking==="object"
        ? motifRankingPolicy({...this.ranking,...requested.ranking,
            weights:{...this.ranking.weights,...(requested.ranking.weights||{})}})
        : this.ranking;
      const policy = requested ? this.memory.retention.configure(requested) : this.memory.retention.policy;
      this.ranking = ranking;
      const culled = this.memory.evict("policy");
      this.respond(payload,"policy",[],{ok:true,policy,ranking,
        evicted:culled.map(record=>record.motifId),summary:this.retentionSummary()});
    } catch (error) {
      this.respond(payload,"policy",[],{ok:false,error:error.message,
        policy:this.memory.retention.policy,ranking:this.ranking});
    }
  }
  // A compact answer for the protocol; retentionReport() is the full per-motif
  // surface an in-process view reads, like activePlaybacks().
  retentionSummary() {
    const report=this.memory.retention.report([...this.memory.motifs.keys()]);
    return {total:this.memory.motifs.size,capacity:this.memory.limit,eventCount:this.memory.eventCount,
      eventCapacity:this.memory.eventCapacity,tiers:report.tiers,evicted:report.evicted.length};
  }
  retentionReport() { return this.memory.retention.report([...this.memory.motifs.keys()]) }
  // Authored intent changes no usage evidence and rewrites no UMP events.
  setMotifInsistence(motifId,amount) {
    const source=this.memory.get(String(motifId));if(!source)throw new RangeError('Unknown stored motif');
    const value=checkedInsistence(amount),motif=withInsistence(source,value);
    if(value>0&&!(insistenceOf(source)>0)&&this.memory.recent(this.memory.limit).filter(item=>insistenceOf(item)>0).length>=MOTIF_INSISTENCE_LIMITS.active)
      throw new RangeError('Too many active motif preferences');
    // Validate the complete line and payload before changing the stored preference.
    const instruction=insistenceInstruction(motif),now=logicalPosition(this.currentClock||{});
    const plan=this.preparePlan('motif',{schemaVersion:1,insistence:instruction},{createdAt:now,appliesAt:now,
      expiresAt:{...now,bar:now.bar+(this.currentClock?.meter?.phraseBars||bandPhraseBars())},priority:value,
      rationale:'Standing motif insistence; 100% precedes musical preferences, physical constraints precede both.'});
    this.memory.motifs.set(motif.motifId,motif);this.memory.revision++;
    if(value>0)this.memory.retention.setSalient(motif.motifId,'authored motif insistence');
    else if(this.memory.retention.entry(motif.motifId)?.salience==='authored motif insistence')this.memory.retention.clearSalient(motif.motifId);
    this.insistencePlans.set(motif.motifId,instruction);
    this.announcePlan(plan);return motif;
  }
  onPrepare(clock={}) {this.currentClock=clock;this.refreshInsistence();return false}
  refreshInsistence() {
    for(const motif of this.memory.recent(this.memory.limit))if(insistenceOf(motif)>0&&!this.insistencePlans.has(motif.motifId))
      this.insistencePlans.set(motif.motifId,insistenceInstruction(motif));
    const now=logicalPosition(this.currentClock||{});
    for(const [id] of this.insistencePlans){
      const motif=this.memory.get(id),instruction=motif?insistenceInstruction(motif):{motifId:id,strength:0,line:[]};
      this.publishPlan('motif',{schemaVersion:1,insistence:instruction},{createdAt:now,appliesAt:now,
        expiresAt:{...now,bar:now.bar+(this.currentClock?.meter?.phraseBars||bandPhraseBars())},priority:instruction.strength,
        rationale:!motif?'Capacity took this motif; its requirement yielded to the storage limit.':'Standing motif insistence refreshed.'});
      if(!instruction.strength)this.insistencePlans.delete(id);
    }
  }
  // Answering a query: eligibility first, then a choice made over everything
  // that survived it. The ledger is read as it stands before this answer is
  // credited, so a motif is never ranked on the strength of the very offer
  // being decided, and the ranker is handed a copy of the evidence rather than
  // the ledger itself -- considering a clip must not change its standing.
  chooseMotifs(payload) {
    const {context,candidates}=this.decisionSnapshot(payload);
    const ranked=selectMotifs(candidates,context,this.ranking);
    return {motifs:ranked.results.map(entry=>entry.motif),ranking:rankingReport(ranked)};
  }
  // What a query is decided on: its context, and the population its explicit
  // filters leave, each with the evidence the ranker is handed. Reading it
  // changes nothing, so the render harness's ranking observer
  // (render/ranking-observer.mjs) reads the same snapshot the answer is chosen
  // from, and what it evaluates is what was decided.
  decisionSnapshot(payload) {
    const query=payload.query||{};
    const context={now:this.memory.retention.now(),requester:String(payload.requester||''),
      capabilities:this.requesterCapabilities(payload.requester),
      // The request id is what makes a seeded shuffle reproducible without a
      // generator, so it travels with the rest of the context.
      requestId:String(payload.requestId||''),
      strategy:query.strategy,like:query.like,
      // What has actually sounded, for the strategy that asks what an
      // appearance would do rather than how often it has been fetched.
      history:this.presentations,atBeats:this.clockBeats(),
      // A phrase in the room's beats now, so that the history judges a gap in phrases (presentation-history.js).
      phraseBeats:(Number(this.currentClock?.meter?.phraseBars)||bandPhraseBars())*(Number(this.currentClock?.meter?.numerator)||bandMeter().numerator),
      // The harmony the answer will be realized in, so that what is chosen is
      // what survives being put there: a motif already in it, or a plain
      // transposition away, before one that has to be bent out of shape.
      harmony:this.targetHarmony(payload)?.pool,movePenalty:this.ranking.movePenalty,
      ...this.formContext()};
    let population=[],limit=1;
    queryMotifs(this.memory,query,{defaultLimit:this.ranking.defaultResults,maxLimit:this.ranking.maxResults,
      choose:(eligible,bound)=>{population=eligible;limit=bound;return []}});
    return {context:{...context,limit},candidates:population.map(motif=>({motif,content:this.content(motif),
      usage:this.memory.retention.usage(motif.motifId,{self:this.instanceId})}))};
  }
  // Which stored motifs have already circulated, for the view that draws the
  // library. activePlaybacks() says what is sounding now; this says what other
  // bots have called for and been given, and it keeps saying so after the
  // sound stops. `revision` is the retention ledger's, which moves on use —
  // the store's own revision only moves when a record arrives or is culled.
  // What has sounded, where in the form, in which layer. Beside
  // retentionReport() and motifUsage(), and deliberately not merged with them.
  presentationReport() { return this.presentations.report({atBeats:this.clockBeats()}) }
  motifUsage() {
    return {revision:this.memory.retention.revision,
      motifs:[...this.memory.motifs.keys()]
        .map(id=>this.memory.retention.usage(id,{self:this.instanceId})).filter(Boolean)};
  }
  onMessage(message) {
    super.onMessage(message);
    // super has taken the pool already, and only an authoritative one reaches
    // here: an outranked source's note pool is dropped before onMessage.
    if (message.address.endsWith("/notepool") && normalizePitchPool(message.args || []).length) this.harmonyHeard = true;
    if (message.address === "/broadcast/form/progress") this.observeProgress(message.args?.[0]);
    if (message.address === "/broadcast/form") this.observeForm(message.args?.[0]);
    if (message.address === "/broadcast/section") this.observeSection(message.args?.[0]);
    if (message.address === "/broadcast/onsets") this.hearOnsets(message.args?.[0]);
    if (message.address === "/broadcast/voices") { const onset = voiceOnset(message.args?.[0]); if (onset) this.hearOnsets({ voice: onset.voice, onsets: [onset] }); }
    if (message.address === "/broadcast/motif") {
      try {
        const motif=validateMotif(message.args?.[0]),amount=insistenceOf(motif);
        if(amount>0)insistenceInstruction(motif);
        this.memory.remember(motif,{origin:"published"});
        if(amount>0&&this.memory.get(motif.motifId))this.setMotifInsistence(motif.motifId,amount);
      }
      catch (error) { this.audio?.report?.("motif_rejected",{error:error.message}); }
      return;
    }
    if (!this.targeted(message)) return;
    const payload = message.args?.[0] || {};
    if (message.address === "/agent/memory/store") this.store(payload);
    if(message.address==='/agent/memory/insistence'){
      try{const motif=this.setMotifInsistence(payload.motifId,payload.insistence);this.respond(payload,'insistence',[motif],{ok:true})}
      catch(error){this.respond(payload,'insistence',[],{ok:false,error:error.message})}
    }
    if (message.address === "/agent/memory/playing") this.recordPlayback(payload);
    if (message.address === "/agent/memory/policy") this.setRetentionPolicy(payload);
    if (message.address === "/agent/memory/query") {
      let chosen;
      try{chosen=this.chooseMotifs(payload)}catch(error){this.respond(payload,"query",[],{ok:false,error:error.message});return}
      // Being offered is not being used. It orders records inside a tier and
      // can never lift passagework out of the unused tier. It is also the
      // exposure the ranker divides by, so it is recorded for what was sent
      // and for nothing that was merely considered.
      for(const motif of chosen.motifs)this.memory.retention.record(motif.motifId,"offered",{actor:payload.requester});
      const answer = this.inHarmony(chosen.motifs, payload);
      this.respond(payload, "query", answer.motifs, { ok: true, ranking: chosen.ranking,
        ...(answer.harmony ? { harmony: answer.harmony } : {}) });
    }
    if (message.address === "/agent/memory/get") {
      const motif = this.memory.get(String(payload.motifId || ""));
      if(motif)this.memory.retention.record(motif.motifId,"retrieved",{actor:payload.requester});
      this.respond(payload, "get", motif ? [motif] : [], { ok: Boolean(motif) });
    }
  }
  recordPlayback(payload) {
    // A realization sounding is its parent sounding, in another harmony. The
    // report is filed under the stored motif, and says it was harmonized.
    const reported=String(payload.motifId||''),stored=this.realizations.get(reported),harmonized=Boolean(stored);
    if(harmonized)payload={...payload,motifId:stored};
    if(!this.memory.get(String(payload.motifId||''))||!payload.player)return;
    const key=`${payload.player}:${payload.playbackId||reported}`;
    if(['stopped','ended','error'].includes(payload.state))this.playbacks.delete(key);
    else {
      const duration=Math.max(0,Math.min(3600,Number(payload.durationSeconds)||0));
      this.playbacks.set(key,{...payload,receivedAt:Date.now(),expiresAt:Math.max(Date.now(),Number(payload.startedAt)||0)+duration*1000+250});
      while(this.playbacks.size>128)this.playbacks.delete(this.playbacks.keys().next().value);
      // Actual scheduled sound, reported by the player itself: the strongest
      // evidence the store has. `key` keeps a sustained playback's repeated
      // status reports from counting more than once.
      this.memory.retention.record(String(payload.motifId),payload.mode==='replay'?'replayed':'derived',
        {actor:payload.player,coverage:payload.sourceNoteIndices?.length||0,
          noteIndices:payload.sourceNoteIndices,token:key});
      // The same report, read as a different kind of evidence. A bot only sends
      // this when note-ons it actually scheduled matched the source notes, so
      // it is the strongest claim the protocol makes that something SOUNDED --
      // and it is stamped with where the form was when it did, because a
      // presentation without its formal position is just a timestamp.
      if(!this.presentationTokens)this.presentationTokens=new Set();
      // Every report that it is still playing says its family is still sounding (presentation-history.js sounding).
      this.presentations.sounding(this.familyOfMotif(this.memory.get(String(payload.motifId))),this.clockBeats());
      // One use of the material, however many reports it sends, is one occurrence (the memorable motifs report, tickets 1
      // and 5): a bot names it (`occurrence`), else each playback is its own. Its reports' notes are gathered into it; it
      // is complete once every note of its top line (the line a voice takes up as a theme: motifs.js topLine), or of the
      // core the clip declares (metadata.core), has sounded.
      const occurrence=typeof payload.occurrence==='string'&&payload.occurrence?`${payload.player}:${payload.occurrence}`:key;
      if(!this.presentationTokens.has(key)){
        this.presentationTokens.add(key);
        if(this.presentationTokens.size>256)this.presentationTokens.delete(this.presentationTokens.values().next().value);
        const motif=this.memory.get(String(payload.motifId)),heard=this.formProgress,notes=motif?motifNotes(motif):[];
        const declared=motif?.metadata?.core,core=Array.isArray(declared)&&declared.length?declared:topLine(notes).map(note=>note.index);
        const entry=this.presentations.record({motifId:payload.motifId,family:this.familyOfMotif(motif),author:motif?.author??null,occurrence,
          player:payload.player,layer:this.performerLayer(payload.player),mode:payload.mode,
          atBeats:this.clockBeats(),role:heard?.role||'',progress:heard?.progress??null,
          sectionIndex:this.formSection>=0?this.formSection:null,
          transformation:[transformationOf(motif),harmonized?'harmonize':null].filter(Boolean).join(' ')||null,
          notes:notes.length,indices:payload.sourceNoteIndices,core,
          coverage:payload.sourceNoteIndices?.length||0});
        // The form hears the material once an occurrence, at its first report, as it always did.
        if(entry&&!this.heardOccurrences?.has(occurrence)){
          (this.heardOccurrences??=new Set).add(occurrence);while(this.heardOccurrences.size>256)this.heardOccurrences.delete(this.heardOccurrences.values().next().value);
          this.hearMaterial(motif,{player:payload.player,bar:this.currentClock?.bar});
        }
      }
    }
    this.activityRevision++;
  }
  activePlaybacks(now=Date.now()) {
    for(const [key,playback] of this.playbacks)if(playback.expiresAt<now)this.playbacks.delete(key);
    return [...this.playbacks.values()];
  }
  broadcastMotif(motifId) {
    const motif=this.memory.get(motifId);
    if(!motif)throw new Error('Unknown stored motif');
    this.memory.retention.record(motifId,'broadcast',{actor:this.instanceId});
    this.send('/broadcast/motif',[motif]);
  }
}
