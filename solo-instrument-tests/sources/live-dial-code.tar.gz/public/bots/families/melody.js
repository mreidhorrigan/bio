// The melody bots: PAP's melodies, damp piano and counterpoint, the sequencers, the ornament and synth lines, the
// Reich guitar, Metheny's melody, and the Seasons' melodic voices.
// Moved verbatim from public/agents.js in its per-family split (28 September 2026; RESEARCH_BACKLOG, the second
// queue). agents.js registers them (BOT_REGISTRY) and re-exports each, so an import from it is as it was.
import { Agent } from "../../framework/index.js";
import { BoundaryPresenceLease, StalePresenceLease } from "../../shared/control-ownership.js";
import { STOCHASTIC_CONFIG as CONFIG } from "../../stochastic-config.js";
import {
  additiveGroupStarts, defaultGrouping, metricWeights, neighborEvolvedCycle, rotateCycle,
} from "../../shared/rhythm.js";
import {
  anchoredChordPitch, ascendingPitchClassVoicing, chordAtPosition, mostCommonPitchClass, phrasePosition, planAtProgress,
  seasonsDroneWindow, seasonsOnsetCycle, seasonsVoiceCount, staggeredHeldVoices,
} from "../../shared/seasons.js";
import { chooseContrastingPitch } from "../../shared/musicality.js";
import {
  corpusInitialShape, corpusNextChord, observedDuration, parseChordPlan, transposeChord, weightedPitchClass,
} from "../../shared/harmony.js";
import {
  cycleIndexAtPhrasePosition, normalizeActivityMask, parseCompoundIntent, residualActivityMask, serializeIntentFields,
} from "../../shared/intentions.js";
import {
  densityWeightedTuplet, expandPitchClasses, filteredTupletMembers, octaveExpandedPool, randomNormalizedOnsets,
  reflectedWalk, sourceStep,
} from "../../shared/sequencing.js";
import { distinctBinaryForm } from "../../shared/form.js";
import {
  gaussianRandom, interpolateCurvePoints, randomFivePointCurve, randomInt, scramble, unitRandom, weightedChoice,
} from "../../shared/stochastic.js";
import { generateCorpusPhrase, generateRhythmicCorpusPhrase } from "../../shared/corpus.js";
import { pitchClass } from "../../shared/pitch.js";
import { transformMotif } from "../../shared/motifs.js";
import { internalClamp } from "./helpers.js";
import {bandPhraseBars,bandTempo,bandMeter} from '../../shared/opening-time.js';
import {writtenOn,writtenOnStep,toNextOf,ticksUntil,phraseTicksLeft,writtenSeconds,portBarTicks,portQuarterTicks,exactEvents,corpusFraction,barTickOf} from "../lib/written.js";
import {withScoreTime,scoreTime} from "../../shared/score-time.js";
import {Rational} from "../../transcript/rational.js";
// A chord as the Seasons bots keep one: its pitches above the octave below its lowest.
const chordOffsets = (chord) => chord.map((pitch) => +(pitch - 12 * Math.floor(Math.min(...chord) / 12)).toFixed(6));

export class SequencerBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.sequencer;
    this.notes = this.openingPool(this.config.openingRegister);
    this.stepsPerBeat = weightedChoice(
      this.config.stepsPerBeatChoices,
      this.config.stepsPerBeatWeights,
    );
    this.pattern = [];
    this.phraseBars = this.config.phraseBars;
    this.lastStep = null;
    this.generatePattern();
  }
  onMessage(message) {
    super.onMessage(message);
    if (message.address.endsWith("/phraselength")) {
      const value = Math.round(Number(message.args.at(-1)));
      if (value > 0) this.phraseBars = Math.min(128, value);
    }
    if (message.address.endsWith("/notepool")) this.generatePattern();
  }
  generatePattern() {
    const pool = octaveExpandedPool(
        this.notes,
        this.config.octaveOffsets,
        this.config.pitchRange,
      ),
      [low, high] = this.config.patternLengthRange,
      length = low + randomInt(high - low + 1);
    let index = randomInt(Math.max(1, pool.length));
    this.pattern = Array.from({ length }, () => {
      index = reflectedWalk(
        index,
        weightedChoice(this.config.walkDeltas, this.config.walkWeights),
        pool.length,
      );
      return pool[index] ?? 60;
    });
    this.lastStep = null;
  }
  densityGate(position) {
    const [minimum, knee, , floor] = this.config.densityCurve;
    if (this.density <= minimum) return floor;
    return Math.max(
      floor,
      Math.min(1, (this.density - minimum) / Math.max(0.001, knee - minimum)),
    );
  }
  render(note, duration, velocity) {
    this.audio.sequencerNote(note, duration, velocity);
  }
  onTick(
    tick,
    clock,
  ) {
    if (clock.phraseStart && clock.phrase !== this.lastPhrase) {
      this.lastPhrase = clock.phrase;
      this.generatePattern();
    }
    const local = sourceStep(clock, this.stepsPerBeat),
      key = `${clock.bar}:${local}`;
    if (key === this.lastStep) return;
    this.lastStep = key;
    const step =
        (clock.bar % (clock.meter.phraseBars || this.phraseBars)) *
          Math.max(1, (clock.meter.numerator || bandMeter().numerator) * this.stepsPerBeat) +
        local,
      gate = this.densityGate(step);
    if (
      unitRandom() > gate ||
      !this.instanceAllows(clock, 31, Math.max(this.config.minimumGate, gate))
    )
      return;
    const note = this.pattern[step % this.pattern.length],
      duration = (this.config.noteDurationBeats * 60) / (clock.bpm || bandTempo()),
      [low, high] = this.config.velocityRange,
      velocity = this.shapeVelocity(low + (high - low) * gate, note, {
        clock,
        division: local,
        divisions: this.stepsPerBeat,
      }),
      steps = Math.max(1, Math.round(this.stepsPerBeat));
    // (Written on its step of the beat it divides, a step long, wherever its tick falls: lib/written.js.)
    writtenOnStep(this.audio, clock.tick - (clock.subdivision || 0), clock.meter.subdivision || 1, steps, local % steps, () => this.render(note, duration, velocity));
  }
}

export class PapMelody2Bot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = this.configuration();
    this.notePoolLease = new BoundaryPresenceLease(
      this.config.notePoolSilenceBars,
    );
    this.densityLease = new BoundaryPresenceLease(
      this.config.densitySilenceBars,
    );
    this.phraseBars = weightedChoice(
      this.config.phraseLengths,
      this.config.phraseLengths.map(() => 1),
    );
    this.curve = [];
    this.bag = [];
    this.lastBar = null;
    this.lastPhrase = null;
    this.generateInternalPool();
    this.generateCurve();
  }
  configuration() {
    return CONFIG.papMelody2;
  }
  generateInternalPool() {
    const [low, high] = this.config.tonicRange,
      tonic = low + randomInt(high - low + 1),
      mode = weightedChoice(
        this.config.modes,
        this.config.modes.map(() => 1),
      );
    this.internalNotes = mode.map((interval) => tonic + interval);
    if (this.notePoolLease.ownsFallback) this.notes = [...this.internalNotes];
  }
  generateCurve() {
    this.curve = randomFivePointCurve({
      xRanges: this.config.phraseCurveXRanges,
      terminalWeights: this.config.phraseCurveTerminalWeights,
    });
  }
  onMessage(message) {
    const isPool = message.address.endsWith("/notepool"),
      isDensity =
        message.address.endsWith("/density") &&
        !message.address.endsWith("/vdensity");
    super.onMessage(message);
    if (isPool) {
      const values = message.args.map(Number).filter(Number.isFinite);
      if (values.length) this.notePoolLease.receive();
    }
    if (isDensity) {
      const value = Number(message.args.at(-1));
      if (Number.isFinite(value)) {
        this.density = Math.max(0, Math.min(1, value));
        this.densityLease.receive();
      }
    }
  }
  drawNote() {
    if (!this.bag.length) this.bag = scramble([...new Set(this.notes)]);
    return this.bag.pop() ?? 60;
  }
  phraseDensity(clock) {
    if (!this.densityLease.ownsFallback) return this.density;
    const bars = clock.meter?.phraseBars || this.phraseBars,
      position =
        (((clock.bar || 0) % bars) +
          Math.max(
            0,
            Math.min(1, (clock.beat || 0) / (clock.meter?.numerator || bandMeter().numerator)),
          )) /
        bars;
    return Math.max(
      0,
      Math.min(1, interpolateCurvePoints(this.curve, position)),
    );
  }
  chooseTuplet(density) {
    return densityWeightedTuplet(density, {
      divisions: this.config.tupletDivisions,
      baseWeights: this.config.tupletBaseWeights,
      densityPowers: this.config.tupletDensityPowers,
    });
  }
  boundary(clock) {
    if (clock.bar === this.lastBar) return;
    this.lastBar = clock.bar;
    if (this.notePoolLease.advanceBoundary()) {
      this.generateInternalPool();
      this.bag = [];
    }
    this.densityLease.advanceBoundary();
  }
  renderNote(note, duration, velocity, offset) {
    this.audio.papMelody(note, duration, velocity, offset);
  }
  onTick(
    tick,
    clock,
  ) {
    this.boundary(clock);
    if (clock.phrase !== this.lastPhrase) {
      this.lastPhrase = clock.phrase;
      this.phraseBars = weightedChoice(
        this.config.phraseLengths,
        this.config.phraseLengths.map(() => 1),
      );
      this.generateCurve();
      if (this.notePoolLease.ownsFallback) this.generateInternalPool();
    }
    if (!clock.beatStart) return;
    const density = this.phraseDensity(clock),
      divisions = this.chooseTuplet(density),
      beatSeconds = 60 / (clock.bpm || bandTempo()),
      [low, high] = this.config.velocityRange,
      base = low + (high - low) * density;
    for (const index of filteredTupletMembers(
      divisions,
      density,
      this.config.memberProbabilityFloor,
    )) {
      const note = this.drawNote(),
        velocity = this.shapeVelocity(base, note, {
          clock,
          division: index,
          divisions,
          voice: 0,
        });
      // (Written on its member of the beat's tuplet, a member long.)
      writtenOnStep(this.audio, clock.tick, clock.meter.subdivision || 1, divisions, index, () => this.renderNote(
        note,
        (beatSeconds / divisions) * this.config.noteDurationFraction,
        velocity,
        (index * beatSeconds) / divisions,
      ));
    }
  }
}

export class LaverneBot extends PapMelody2Bot {
  constructor(...args) {
    super(...args);
    this.preset = randomInt(this.config.presets.length);
  }
  configuration() {
    return CONFIG.laverne;
  }
  // The original Laverne event source explicitly fixes velocity at 110/127.
  shapeVelocity(base) {
    return base;
  }
  renderNote(note, duration, velocity, offset) {
    this.audio.laverne(
      note,
      duration,
      velocity,
      offset,
      this.config.presets[this.preset],
      this.preset,
    );
  }
}

export class PapMelodyBot extends PapMelody2Bot {
  constructor(...args) {
    super(...args);
    this.familyConfig = CONFIG.papMelody;
    this.voiceBags = [[], [], []];
    this.walkIndex = 0;
  }
  fitToRange(note, range) {
    let value = Number(note);
    while (value < range[0]) value += 12;
    while (value > range[1]) value -= 12;
    return Math.max(range[0], Math.min(range[1], value));
  }
  voiceNote(index) {
    const range = this.familyConfig.voiceRanges[index],
      pool = index === 0 ? this.notes : this.internalNotes;
    if (index === 1) {
      this.walkIndex = reflectedWalk(
        this.walkIndex,
        weightedChoice(
          this.familyConfig.drunkDeltas,
          this.familyConfig.drunkWeights,
        ),
        pool.length,
      );
      return this.fitToRange(pool[this.walkIndex] ?? 60, range);
    }
    if (!this.voiceBags[index].length)
      this.voiceBags[index] = scramble([...pool]);
    return this.fitToRange(this.voiceBags[index].pop() ?? 60, range);
  }
  announceForm() {
    this.broadcast("meter", [
      this.phraseBars * this.familyConfig.legacyMeterMultiplier,
      this.familyConfig.legacyMeterDenominator,
    ]);
    this.broadcast("density", [this.density]);
  }
  onTick(
    tick,
    clock,
  ) {
    this.boundary(clock);
    if (clock.phrase !== this.lastPhrase) {
      this.lastPhrase = clock.phrase;
      this.phraseBars = weightedChoice(
        this.config.phraseLengths,
        this.config.phraseLengths.map(() => 1),
      );
      this.generateCurve();
      this.generateInternalPool();
      this.voiceBags = [[], [], []];
      this.announceForm();
    }
    if (!clock.beatStart) return;
    const density = this.phraseDensity(clock),
      divisions = this.chooseTuplet(density),
      beatSeconds = 60 / (clock.bpm || bandTempo()),
      [low, high] = this.config.velocityRange,
      base = low + (high - low) * density;
    for (const division of filteredTupletMembers(
      divisions,
      density,
      this.config.memberProbabilityFloor,
    )) {
      let voices = [0, 1, 2].filter(
        () => unitRandom() < this.familyConfig.voicePlayProbability,
      );
      if (!voices.length) voices = [division % 3];
      for (const voice of voices) {
        const note = this.voiceNote(voice),
          velocity = this.shapeVelocity(base, note, {
            clock,
            division,
            divisions,
            voice,
          });
        writtenOnStep(this.audio, clock.tick, clock.meter.subdivision || 1, divisions, division, () => this.audio.papMelodyVoice(
          note,
          (beatSeconds / divisions) * this.config.noteDurationFraction,
          velocity,
          (division * beatSeconds) / divisions,
          voice,
        ));
      }
    }
  }
}

export class PapMelody4Bot extends PapMelody2Bot {
  constructor(...args) {
    super(...args);
    this.familyConfig = CONFIG.papMelody4;
    // Its home key: the one it was built in, preferred but not always taken (shared/opening-harmony.js).
    this.tonic = this.preferredTonic(this.familyConfig.preferredTonic);
    this.scaleIndex = 6;
    this.modulation = 0;
    this.applyScale(false);
  }
  boundary(clock) {
    if (clock.bar === this.lastBar) return;
    this.lastBar = clock.bar;
    const hadPool = this.notePoolLease.ownsFallback;
    if (this.notePoolLease.advanceBoundary() && !hadPool) this.applyScale(true);
    this.densityLease.advanceBoundary();
  }
  applyScale(announce = true) {
    let scale = [...this.familyConfig.majorScales[this.scaleIndex]],
      mode = "major";
    if (unitRandom() < this.familyConfig.modalChangeProbability) {
      const table =
          this.modulation < 0
            ? this.familyConfig.minorModalInflections
            : this.familyConfig.majorModalInflections,
        inflection = weightedChoice(
          table,
          table.map(() => 1),
        );
      scale = scale.map((note, index) => note + inflection[index]);
      mode = this.modulation < 0 ? "minor-inflection" : "major-inflection";
    }
    this.internalNotes = [
      ...new Set(
        scale.slice(0, 7).map((note) => this.tonic + note),
      ),
    ];
    this.notes = [...this.internalNotes];
    this.bag = [];
    this.mode = mode;
    if (announce) this.broadcast("notepool", this.notes);
  }
  modulate() {
    if (unitRandom() < this.familyConfig.modulationProbability) {
      const span = Math.max(1, Math.min(this.familyConfig.modulationSize, 7)),
        size = 1 + randomInt(span),
        direction = unitRandom() < 0.5 ? -1 : 1;
      this.scaleIndex = Math.max(
        0,
        Math.min(
          this.familyConfig.majorScales.length - 1,
          this.scaleIndex + direction * size,
        ),
      );
      this.modulation = this.familyConfig.scaleKeys[this.scaleIndex];
    }
    this.applyScale(this.notePoolLease.ownsFallback);
  }
  onMessage(message) {
    super.onMessage(message);
    if (
      message.address.endsWith("/notepool") &&
      !this.notePoolLease.ownsFallback
    )
      this.bag = [];
  }
  onTick(
    tick,
    clock,
  ) {
    this.boundary(clock);
    if (clock.phrase !== this.lastPhrase) {
      this.lastPhrase = clock.phrase;
      this.generateCurve();
      if (this.notePoolLease.ownsFallback) this.modulate();
    }
    if (!clock.beatStart) return;
    const density = this.phraseDensity(clock),
      divisions = this.chooseTuplet(density),
      beatSeconds = 60 / (clock.bpm || bandTempo()),
      base = 0.4 + 0.48 * density;
    for (const division of filteredTupletMembers(
      divisions,
      density,
      this.config.memberProbabilityFloor,
    )) {
      const note = this.drawNote(),
        velocity = this.shapeVelocity(base, note, {
          clock,
          division,
          divisions,
          voice: 0,
        });
      writtenOnStep(this.audio, clock.tick, clock.meter.subdivision || 1, divisions, division, () => this.audio.papMelody4(
        note,
        (beatSeconds / divisions) * this.familyConfig.noteDurationFraction,
        velocity,
        (division * beatSeconds) / divisions,
        this.modulation,
      ));
    }
  }
}

export class DampPianoBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = this.configuration();
    this.densityLease = new BoundaryPresenceLease(
      this.config.densitySilenceBars || 1,
    );
    this.section = -1;
    this.sectionEndBar = 0;
    this.finished = false;
    this.lastBar = null;
    this.previousState = null;
    this.form = [];
    this.phraseBag = [];
    this.noteBags = this.config.registers.map(() => []);
    this.curve = [];
    this.generateForm();
  }
  configuration() {
    return CONFIG.dampPiano;
  }
  onMessage(message) {
    super.onMessage(message);
    if (
      message.address.endsWith("/density") &&
      !message.address.endsWith("/vdensity")
    ) {
      const value = Number(message.args.at(-1));
      if (Number.isFinite(value)) {
        this.density = Math.max(0, Math.min(1, value));
        this.densityLease.receive();
      }
    }
  }
  generateForm() {
    this.form = distinctBinaryForm(
      this.config.sectionCount,
      this.config.registers.length,
      this.config.partProbabilities,
    );
    this.previousState = null;
  }
  nextPhraseLength() {
    if (!this.phraseBag.length)
      this.phraseBag = scramble([...this.config.phraseLengths]);
    return this.phraseBag.pop();
  }
  beginSection(clock) {
    this.section++;
    if (this.section >= this.config.sectionCount) {
      this.finished = true;
      return;
    }
    const length = this.nextPhraseLength(),
      numerator = Math.max(1, clock.meter?.numerator || bandMeter().numerator),
      beats = length * this.config.legacyMeterMultiplier;
    this.sectionStartBar = clock.bar || 0;
    this.sectionEndBar =
      this.sectionStartBar + Math.max(1, Math.ceil(beats / numerator));
    this.curve = randomFivePointCurve({
      xRanges: this.config.phraseCurveXRanges,
      terminalWeights: this.config.phraseCurveTerminalWeights,
    });
    this.noteBags = this.config.registers.map(() => []);
    this.broadcast("meter", [beats, this.config.legacyMeterDenominator]);
    this.previousState = this.form[this.section];
  }
  barBoundary(clock) {
    if (clock.bar === this.lastBar) return;
    this.lastBar = clock.bar;
    this.densityLease.advanceBoundary();
    if (this.section < 0 || clock.bar >= this.sectionEndBar)
      this.beginSection(clock);
  }
  sectionDensity(clock) {
    if (!this.densityLease.ownsFallback) return this.density;
    const progress = Math.max(
      0,
      Math.min(
        1,
        ((clock.bar || 0) - this.sectionStartBar) /
          Math.max(1, this.sectionEndBar - this.sectionStartBar),
      ),
    );
    return Math.max(
      0,
      Math.min(1, interpolateCurvePoints(this.curve, progress)),
    );
  }
  drawRegister(index) {
    if (!this.noteBags[index].length)
      this.noteBags[index] = scramble([...this.config.registers[index].midi]);
    return this.noteBags[index].pop();
  }
  playNote(note, duration, velocity, offset, register) {
    this.audio.dampedPiano(note, duration, velocity, offset, register);
  }
  onTick(
    tick,
    clock,
  ) {
    if (clock.barStart || this.lastBar == null) this.barBoundary(clock);
    if (this.finished || !clock.beatStart) return;
    const cap =
        this.config.maxDensities[this.section] /
        Math.max(...this.config.maxDensities),
      density = Math.min(cap, this.sectionDensity(clock)),
      divisions = densityWeightedTuplet(density, {
        divisions: this.config.tupletDivisions,
        baseWeights: this.config.tupletBaseWeights,
        densityPowers: this.config.tupletDensityPowers,
      }),
      beatSeconds = 60 / (clock.bpm || bandTempo()),
      active = this.form[this.section],
      registers = active
        .map((value, index) => (value ? index : -1))
        .filter((index) => index >= 0);
    for (const member of filteredTupletMembers(
      divisions,
      density,
      this.config.memberProbabilityFloor,
    ))
      for (const register of registers)
        writtenOnStep(this.audio, clock.tick, clock.meter.subdivision || 1, divisions, member, () => this.playNote(
          this.drawRegister(register),
          (beatSeconds / divisions) * 0.68,
          0.38 + 0.5 * density,
          (member * beatSeconds) / divisions,
          register,
        ));
  }
}

export class CounterpointBot extends DampPianoBot {
  configuration() {
    return CONFIG.counterpoint;
  }
  constructor(...args) {
    super(...args);
    this.notePoolLease = new BoundaryPresenceLease(
      this.config.notePoolSilenceBars,
    );
    this.densityLease.ownsFallback = true;
    this.notes = this.openingPool(this.config.openingRegister, { of: "collection" });
    this.generateInternalPool(false);
  }
  generateInternalPool(adopt = true) {
    const [low, high] = this.config.tonicRange,
      tonic = low + randomInt(high - low + 1),
      mode = weightedChoice(
        this.config.modes,
        this.config.modes.map(() => 1),
      );
    this.internalNotes = mode.map((interval) => tonic + interval);
    if (adopt) {
      this.notes = [...this.internalNotes];
      this.noteBags = this.config.registers.map(() => []);
    }
  }
  onMessage(message) {
    Agent.prototype.onMessage.call(this, message);
    if (message.address.endsWith("/notepool")) {
      const values = message.args.map(Number).filter(Number.isFinite);
      if (values.length) {
        this.notePoolLease.receive();
        this.noteBags = this.config.registers.map(() => []);
      }
    }
  }
  barBoundary(clock) {
    if (clock.bar === this.lastBar) return;
    const hadFallback = this.notePoolLease.ownsFallback;
    this.notePoolLease.advanceBoundary();
    if (this.notePoolLease.ownsFallback && !hadFallback)
      this.generateInternalPool(true);
    super.barBoundary(clock);
  }
  beginSection(clock) {
    super.beginSection(clock);
    if (this.finished) {
      this.send("/agent/off", []);
      return;
    }
    if (this.notePoolLease.ownsFallback) this.generateInternalPool(true);
  }
  drawRegister(index) {
    if (!this.noteBags[index].length)
      this.noteBags[index] = scramble([...this.notes]);
    const source = this.noteBags[index].pop() ?? 60,
      { range, offset } = this.config.registers[index];
    let note = source + offset;
    while (note < range[0]) note += 12;
    while (note > range[1]) note -= 12;
    return Math.max(range[0], Math.min(range[1], note));
  }
  playNote(note, duration, velocity, offset, register) {
    this.audio.counterpointVoice(note, duration, velocity, offset, register);
  }
}

// (An onset of randomNormalizedOnsets, exactly: a point of its `resolution` grid, or its `count`'s share.)
const exactOnset=(onset,resolution,count)=>{const k=Math.round(onset*resolution);return Math.abs(k/resolution-onset)<1e-12?new Rational(k,resolution):new Rational(Math.round(onset*count),count)};

export class OrnamentBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.ornament;
    this.notes = this.openingPool(this.config.openingRegister);
    this.now = () => Date.now();
    const [low, high] = this.config.staleTimeoutRangeMs,
      timeout = low + randomInt(high - low);
    this.noteLease = new StalePresenceLease(timeout, () => this.now());
    this.densityLease = new StalePresenceLease(timeout, () => this.now());
    this.lastBar = null;
    this.curve = [];
    this.curveBars = 1;
    this.generateDensityCurve();
    this.expanded = expandPitchClasses(this.notes, {
      octaves: this.config.octaves,
      base: this.config.baseMidi,
    });
  }
  onMessage(message) {
    super.onMessage(message);
    if (message.address.endsWith("/notepool")) {
      const values = message.args.map(Number).filter(Number.isFinite);
      if (values.length) {
        this.noteLease.receive(values);
        this.expanded = expandPitchClasses(this.notes, {
          octaves: this.config.octaves,
          base: this.config.baseMidi,
        });
      }
    }
    if (message.address.endsWith("/hdensity")) {
      const value = Number(message.args.at(-1));
      if (Number.isFinite(value)) this.densityLease.receive(value);
    }
  }
  generateDensityCurve() {
    this.curve = randomFivePointCurve({
      xRanges: [
        [0.05, 0.333],
        [0.35, 0.666],
        [0.7, 0.95],
      ],
      terminalWeights: [0.5, 0.5],
    });
    const [low, high] = this.config.densityCurveLengthRange;
    this.curveBars = low + randomInt(high - low);
  }
  internalDensity(bar) {
    const position =
      (((bar % this.curveBars) + this.curveBars) % this.curveBars) /
      Math.max(1, this.curveBars - 1);
    return Math.max(
      0,
      Math.min(1, interpolateCurvePoints(this.curve, position)),
    );
  }
  generatePool() {
    const fundamental = 8 + randomInt(25),
      pitchClasses = this.config.durationRatios.map(
        (ratio) => fundamental + Math.round(12 * Math.log2(ratio)),
      );
    this.notes = [
      ...new Set(pitchClasses.map((note) => 36 + (((note % 12) + 12) % 12))),
    ];
    this.expanded = expandPitchClasses(this.notes, {
      octaves: this.config.octaves,
      base: this.config.baseMidi,
    });
  }
  scheduleBar(clock) {
    const bar = clock.bar || 0;
    this.noteLease.update();
    this.densityLease.update();
    if (this.noteLease.ownsFallback) {
      this.generatePool();
      this.broadcast("notepool", this.notes);
    }
    if (this.densityLease.ownsFallback) {
      if (bar % this.curveBars === 0) this.generateDensityCurve();
      this.density = internalClamp(this.internalDensity(bar));
      this.broadcast("hdensity", [this.density]);
    }
    const maximum = Math.min(
        this.config.sequenceLengthMaximum,
        Math.max(
          1,
          Math.round(this.density * this.config.sequenceLengthScale[1]),
        ),
      ),
      count = 1 + randomInt(maximum),
      onsets = randomNormalizedOnsets(count, {
        candidates: this.config.candidateOnsets,
        resolution: this.config.onsetResolution,
      }),
      pitches = scramble(
        Array.from(
          { length: Math.max(count, this.expanded.length) },
          (_, index) => this.expanded[index % this.expanded.length] ?? 60,
        ),
      ),
      barSeconds =
        ((60 / (clock.bpm || bandTempo())) * (clock.meter?.numerator || bandMeter().numerator) * 4) /
        (clock.meter?.denominator || bandMeter().denominator),
      [durationLow, durationHigh] = this.config.pluckDurationRange,
      [velocityLow, velocityHigh] = this.config.velocityRange,
      base = velocityLow + (velocityHigh - velocityLow) * this.density;
    for (const [index, onset] of onsets.entries()) {
      const next = onsets[index + 1] ?? 1,
        duration = Math.max(
          durationLow,
          Math.min(durationHigh, (next - onset) * barSeconds * 0.8),
        ),
        note = pitches[index % pitches.length],
        velocity = this.shapeVelocity(base, note, {
          clock,
          division: index,
          divisions: count,
        });
      // (Written where it composed it: its onset's exact share of its bar -- a point of its grid, or its count's share --
      // to the next, in the bar as it reads it: lib/written.js portBarTicks.)
      const bar = portBarTicks(clock), from = exactOnset(onset, this.config.onsetResolution, count), to = index + 1 < onsets.length ? exactOnset(next, this.config.onsetResolution, count) : Rational.ONE;
      const barTick = barTickOf(clock);
      writtenOn(this.audio, barTick == null ? null : from.mul(bar).add(barTick), to.sub(from).mul(bar), () => this.audio.ornamentPluck(
        note,
        duration,
        velocity,
        onset * barSeconds,
        index / count,
      ));
    }
  }
  onTick(
    tick,
    clock,
  ) {
    if (!clock.barStart || clock.bar === this.lastBar) return;
    this.lastBar = clock.bar;
    this.scheduleBar(clock);
  }
}

export class MSynthBot extends Agent {
  configuration() {
    return CONFIG.msynth;
  }
  constructor(...args) {
    super(...args);
    this.config = this.configuration();
    this.tala = this.openingTala;
    this.corpus = this.config.fallbackCorpus;
    this.phraseEvents = [];
    this.lastPhrase = -1;
    this.form = [];
    this.formPosition = -1;
    this.finished = false;
    this.exitSent = false;
    this.plan = [];
    this.chordDurations = [];
    this.preset = 0;
    this.generateForm();
  }
  async start() {
    const response = await fetch("./data/msynth-metheny-corpus.json"),
      corpus = await response.json();
    if (
      corpus.onsetDurations?.length !== 119 ||
      corpus.firstBeatContours?.length !== 32 ||
      corpus.continuationContours?.length !== 60
    )
      throw new Error("Invalid MSynth corpus");
    this.corpus = corpus;
  }
  generateForm() {
    const count =
        this.config.formPhraseRange[0] +
        randomInt(
          this.config.formPhraseRange[1] - this.config.formPhraseRange[0],
        ),
      active = distinctBinaryForm(count, 1, [
        this.config.activePhraseProbability,
      ]).map((state) => Boolean(state[0]));
    if (!active.some(Boolean)) active[randomInt(active.length)] = true;
    this.form = active;
    this.formPosition = -1;
    this.finished = false;
    this.exitSent = false;
  }
  // A form of a stated length, in THIS bot's shape. /phrases used to build the
  // single-voice shape inline -- one boolean per phrase -- which is right here
  // and wrong for the subclasses that inherit the handler: MultiSynthBot and
  // ReichGuitarBot keep one on/off PER VOICE per phrase. Both announce their own
  // /phrases and hear it back, so each overwrote its per-voice form with
  // booleans on its first phrase and died in beginPhrase ("active.filter is not
  // a function") before ever playing a note.
  formOfLength(count) {
    return distinctBinaryForm(count, 1, [
      this.config.activePhraseProbability,
    ]).map((state) => Boolean(state[0]));
  }
  onMessage(message) {
    super.onMessage(message);
    if (message.address.endsWith("/phraselength")) {
      const value = Number(message.args.at(-1));
      if (
        Number.isInteger(value) &&
        value > 0 &&
        value <= this.config.maximumPhraseBars
      )
        this.phraseBars = value;
    }
    if (message.address.endsWith("/phrases")) {
      const value = Number(message.args.at(-1));
      if (Number.isInteger(value) && value > 0) {
        this.form = this.formOfLength(
          Math.min(this.config.maximumPhrases, value),
        );
        this.formPosition = -1;
        this.finished = false;
        this.exitSent = false;
      }
    }
    if (message.address.endsWith("/plan/chords"))
      this.plan = message.args.flatMap((value) =>
        String(value).split(/\s+/).map(Number).filter(Number.isFinite),
      );
    if (message.address.endsWith("/plan/chordDuration"))
      this.chordDurations = message.args
        .map(Number)
        .filter((value) => Number.isFinite(value) && value > 0);
    if (
      message.address.endsWith("/exiting") &&
      String(message.args[0]) === this.config.botName
    )
      this.finished = true;
  }
  phrasePool() {
    return this.plan.length
      ? [
          ...new Set(
            this.plan
              .map((note) => 60 + pitchClass(note))
              .filter(Number.isFinite),
          ),
        ]
      : this.notes;
  }
  beginPhrase(clock) {
    this.formPosition++;
    if (this.formPosition >= this.form.length) {
      this.finished = true;
      if (!this.exitSent) {
        this.exitSent = true;
        this.broadcast("exiting", [this.config.botName, 1]);
      }
      return;
    }
    const bars =
        this.phraseBars ||
        clock.meter?.phraseBars ||
        this.config.defaultPhraseBars,
      quarterBeats =
        (bars * (clock.meter?.numerator || bandMeter().numerator) * 4) /
        (clock.meter?.denominator || bandMeter().denominator),
      pool = this.phrasePool();
    this.preset = randomInt(this.config.synthPresetCount);
    this.phraseEvents = this.form[this.formPosition]
      ? generateCorpusPhrase(this.corpus, {
          beats: quarterBeats,
          density: this.density,
          notePool: pool,
          range: this.config.midiRange,
          nearest: this.config.nearestCorpusRecords,
        })
      : [];
    this.broadcast("notepool", pool);
    this.broadcast(
      "tala",
      this.tala.length ? this.tala : this.bandTime.tala,
    );
    this.broadcast("phraselength", [bars]);
    this.broadcast("phrases", [this.form.length]);
  }
  playEvent(note, duration, velocity, offset, preset) {
    this.audio.msynthNote(note, duration, velocity, offset, preset);
  }
  onTick(
    tick,
    clock,
  ) {
    if (clock.phraseStart && clock.phrase !== this.lastPhrase) {
      this.lastPhrase = clock.phrase;
      if (this.finished) {
        if (!this.exitSent) {
          this.exitSent = true;
          this.broadcast("exiting", [this.config.botName, 1]);
        }
        return;
      }
      this.beginPhrase(clock);
      const quarterSeconds = 60 / (clock.bpm || bandTempo()),
        // (Each written where its phrase places it, exactly, in the quarters it reads -- its span the phrase's: lib/written.js.)
        bars = this.phraseBars || clock.meter?.phraseBars || this.config.defaultPhraseBars,
        places = exactEvents(this.phraseEvents, new Rational(bars * (clock.meter?.numerator || bandMeter().numerator) * 4, clock.meter?.denominator || bandMeter().denominator)),
        quarter = portQuarterTicks(clock);
      for (const [index, event] of this.phraseEvents.entries()) {
        const velocity =
            this.config.velocityCycle[index % this.config.velocityCycle.length],
          duration = Math.max(
            this.config.minimumNoteSeconds,
            event.duration * quarterSeconds * this.config.durationGate,
          );
        writtenOn(this.audio, Number.isFinite(clock.tick) ? places[index].at.mul(quarter).add(clock.tick) : null, places[index].duration.mul(quarter), () => this.playEvent(
          event.note,
          duration,
          velocity,
          event.at * quarterSeconds,
          this.preset,
          event,
        ));
      }
    }
  }
}

export class RSynthBot extends MSynthBot {
  configuration() {
    return CONFIG.rsynth;
  }
  async start() {
    const response = await fetch("./data/rsynth-breaks-corpus.json"),
      corpus = await response.json();
    if (
      corpus.onsetChains?.length !== 16 ||
      corpus.durationsByOnset?.length !== 16 ||
      corpus.pitchChains?.length !== 121 ||
      corpus.pitchFirstBeats?.length !== 1
    )
      throw new Error("Invalid RSynth corpus");
    this.corpus = corpus;
  }
  beginPhrase(clock) {
    this.formPosition++;
    if (this.formPosition >= this.form.length) {
      this.finished = true;
      if (!this.exitSent) {
        this.exitSent = true;
        this.broadcast("exiting", [this.config.botName, 1]);
      }
      return;
    }
    const bars =
        this.phraseBars ||
        clock.meter?.phraseBars ||
        this.config.defaultPhraseBars,
      quarterBeats =
        (bars * (clock.meter?.numerator || bandMeter().numerator) * 4) /
        (clock.meter?.denominator || bandMeter().denominator),
      pool = this.phrasePool();
    this.preset = randomInt(this.config.synthPresetCount);
    this.phraseEvents = this.form[this.formPosition]
      ? generateRhythmicCorpusPhrase(this.corpus, {
          beats: quarterBeats,
          density: this.density,
          notePool: pool,
          range: this.config.midiRange,
        })
      : [];
    this.broadcast("notepool", pool);
    this.broadcast("tala", this.tala);
    this.broadcast("phraselength", [bars]);
    this.broadcast("phrases", [this.form.length]);
  }
  playEvent(note, duration, velocity, offset, preset) {
    this.audio.rsynthNote(note, duration, velocity, offset, preset);
  }
}

export class MultiSynthBot extends MSynthBot {
  configuration() {
    return CONFIG.multiSynth;
  }
  async start() {}
  formOfLength(count) {
    return distinctBinaryForm(
      count,
      this.config.voiceCount,
      this.config.partProbabilities,
    );
  }
  generateForm() {
    const count =
      this.config.formPhraseRange[0] +
      randomInt(
        this.config.formPhraseRange[1] - this.config.formPhraseRange[0],
      );
    this.form = distinctBinaryForm(
      count,
      this.config.voiceCount,
      this.config.partProbabilities,
    );
    this.formPosition = -1;
    this.finished = false;
    this.exitSent = false;
  }
  beginPhrase(clock) {
    this.formPosition++;
    if (this.formPosition >= this.form.length) {
      this.finished = true;
      if (!this.exitSent) {
        this.exitSent = true;
        this.broadcast("exiting", [this.config.botName, 1]);
      }
      return;
    }
    const bars =
        this.phraseBars ||
        clock.meter?.phraseBars ||
        this.config.defaultPhraseBars,
      quarterBeats =
        (bars * (clock.meter?.numerator || bandMeter().numerator) * 4) /
        (clock.meter?.denominator || bandMeter().denominator),
      steps = Math.max(1, Math.ceil(quarterBeats * 4)),
      pool = this.phrasePool(),
      active = this.form[this.formPosition],
      events = [];
    for (let voice = 0; voice < this.config.voiceCount; voice++) {
      if (!active[voice]) continue;
      const low =
          this.config.densityLowRange[0] +
          unitRandom() *
            (this.config.densityLowRange[1] - this.config.densityLowRange[0]),
        high =
          this.config.densityHighRange[0] +
          unitRandom() *
            (this.config.densityHighRange[1] - this.config.densityHighRange[0]),
        partDensity = low + (high - low) * this.density,
        curve = randomFivePointCurve({
          xRanges: this.config.phraseCurveXRanges,
          terminalWeights: this.config.phraseCurveTerminalWeights,
        }),
        available = Array.from({ length: steps }, (_, index) => index),
        selected = [];
      while (
        available.length &&
        selected.length < this.config.onsetCandidatesPerPart
      ) {
        const weights = available.map(
            (index) =>
              this.config.metricVelocityCycle[
                index % this.config.metricVelocityCycle.length
              ] *
              Math.max(
                0.02,
                interpolateCurvePoints(curve, index / Math.max(1, steps - 1)),
              ),
          ),
          choice = weightedChoice(available, weights),
          position = available.indexOf(choice);
        available.splice(position, 1);
        if (unitRandom() <= partDensity) selected.push(choice);
      }
      if (!selected.length) selected.push(0);
      for (const onset of selected.sort((a, b) => a - b)) {
        const range = this.config.voiceRanges[voice],
          source = weightedChoice(
            pool,
            pool.map(() => 1),
          );
        let note = source;
        while (note < range[0]) note += 12;
        while (note > range[1]) note -= 12;
        events.push({
          at: onset / 4,
          duration: this.config.noteDurationQuarterBeats,
          note,
          voice,
        });
      }
    }
    this.phraseEvents = events.sort((a, b) => a.at - b.at || a.voice - b.voice);
    this.preset = randomInt(this.config.synthPresetCount);
    this.broadcast("notepool", pool);
    this.broadcast("hdensity", [this.density]);
    this.broadcast("vdensity", [
      active.filter(Boolean).length / this.config.voiceCount,
    ]);
    this.broadcast("tala", this.tala);
    this.broadcast("phraselength", [bars]);
    this.broadcast("phrases", [this.form.length]);
  }
  playEvent(note, duration, velocity, offset, preset, event) {
    this.audio.multiSynthNote(
      note,
      duration,
      velocity,
      offset,
      event?.voice || 0,
      preset,
    );
  }
}

export class ReichGuitarBot extends MultiSynthBot {
  configuration() {
    return CONFIG.reichGuitar;
  }
  phraseDensity(activeCount) {
    const [gaussLow, gaussHigh] = this.config.gaussianInputRange,
      [densityLow, densityHigh] = this.config.gaussianDensityRange,
      z = Math.max(gaussLow, Math.min(gaussHigh, gaussianRandom())),
      base =
        densityLow +
        ((densityHigh - densityLow) * (z - gaussLow)) / (gaussHigh - gaussLow),
      fraction = activeCount / this.config.voiceCount,
      [boostHigh, boostLow] = this.config.sparseVoiceMultiplierRange,
      multiplier =
        boostHigh + ((boostLow - boostHigh) * (fraction - 0.25)) / 0.75;
    return Math.max(this.config.minimumDensity, Math.min(1, base * multiplier));
  }
  beginPhrase(clock) {
    this.formPosition++;
    if (this.formPosition >= this.form.length) {
      this.finished = true;
      if (!this.exitSent) {
        this.exitSent = true;
        this.broadcast("exiting", [this.config.botName, 1]);
      }
      return;
    }
    const bars =
        this.phraseBars ||
        clock.meter?.phraseBars ||
        this.config.defaultPhraseBars,
      quarterBeats =
        (bars * (clock.meter?.numerator || bandMeter().numerator) * 4) /
        (clock.meter?.denominator || bandMeter().denominator),
      steps = Math.max(1, Math.ceil(quarterBeats * 4)),
      pool = this.phrasePool(),
      active = this.form[this.formPosition],
      activeCount = active.filter(Boolean).length,
      density = this.phraseDensity(activeCount),
      seed = Array.from(
        { length: steps },
        (_, index) =>
          this.config.initialCell[index % this.config.initialCell.length],
      ),
      events = [];
    let previous = neighborEvolvedCycle(seed, this.config.mutationsPerPhrase);
    for (let voice = 0; voice < this.config.voiceCount; voice++) {
      if (!active[voice]) continue;
      let shape;
      if (voice === 0) shape = previous;
      else if (unitRandom() < this.config.inheritShapeProbability)
        shape = rotateCycle(previous, this.config.phaseOffsets[voice]);
      else
        shape = neighborEvolvedCycle(
          previous,
          this.config.mutationsPerPhrase + voice,
        );
      previous = shape;
      const motive =
          this.config.pitchMotives[voice % this.config.pitchMotives.length],
        range = this.config.voiceRanges[voice],
        voiceEvents = [];
      for (let onset = 0; onset < steps; onset++)
        if (shape[onset] && unitRandom() <= density) {
          const source = pool[(onset + voice) % pool.length] ?? 60,
            interval = motive[(onset + this.formPosition) % motive.length],
            pitchClass = (((source + interval) % 12) + 12) % 12;
          let note = range[0] + ((((pitchClass - range[0]) % 12) + 12) % 12);
          while (note > range[1]) note -= 12;
          const event = {
            at: onset / 4,
            duration: this.config.noteDurationQuarterBeats,
            note,
            voice,
          };
          voiceEvents.push(event);
          events.push(event);
        }
      if (!voiceEvents.length) {
        const note =
          range[0] +
          (((((pool[voice % pool.length] ?? 60) - range[0]) % 12) + 12) % 12);
        events.push({
          at: (voice * this.config.phaseOffsets[voice]) / 4,
          duration: this.config.noteDurationQuarterBeats,
          note,
          voice,
        });
      }
    }
    this.density = density;
    this.phraseEvents = events
      .filter((event) => event.at < quarterBeats)
      .sort((a, b) => a.at - b.at || a.voice - b.voice);
    this.preset = randomInt(this.config.synthPresetCount);
    this.broadcast("notepool", [
      ...new Set(this.phraseEvents.map((event) => event.note)),
    ]);
    this.broadcast("hdensity", [density]);
    this.broadcast("vdensity", [activeCount / this.config.voiceCount]);
    this.broadcast("tala", this.tala);
    this.broadcast("phraselength", [bars]);
    this.broadcast("phrases", [this.form.length]);
  }
  playEvent(note, duration, velocity, offset, preset, event) {
    this.audio.reichGuitar(
      note,
      duration,
      velocity,
      offset,
      event?.voice || 0,
      preset,
    );
  }
}

export class MethenyMelodyBot extends MSynthBot {
  configuration() {
    return CONFIG.methenyMelody;
  }
  constructor(...args) {
    super(...args);
    this.phraseBars = weightedChoice(
      this.config.phraseLengths,
      this.config.phraseLengthWeights,
    );
    this.chords = [];
    this.receivedPlan = false;
    this.harmony = null;
  }
  async start() {
    const [corpus, harmony] = await Promise.all(
      ["./data/msynth-metheny-corpus.json", "./data/metheny-harmony.json"].map(
        (path) => fetch(path).then((response) => response.json()),
      ),
    );
    if (
      corpus.onsetDurations?.length !== 119 ||
      corpus.firstBeatContours?.length !== 32 ||
      corpus.continuationContours?.length !== 60
    )
      throw new Error("Invalid Metheny melody corpus");
    this.corpus = corpus;
    this.harmony = harmony;
    this.generateLocalPlan();
  }
  onMessage(message) {
    super.onMessage(message);
    if (message.address.endsWith("/plan/chords")) {
      const chords = parseChordPlan(message.args);
      if (chords.length) {
        this.chords = chords;
        this.receivedPlan = true;
      }
    }
  }
  generateLocalPlan() {
    if (!this.harmony) {
      this.chords = [this.openingChord(this.config.openingRegister, this.config.openingVoices)];
      return;
    }
    const target = Math.max(
        1,
        this.phraseBars * this.config.assumedBeatsPerBar,
      ),
      items = [];
    let shape = corpusInitialShape(this.harmony),
      root = weightedPitchClass(this.harmony[shape]?.initial),
      duration = 0;
    while (duration < target && items.length < this.config.maximumChords) {
      const beats = Math.min(
        target - duration,
        observedDuration(this.harmony[shape], 1) * this.config.harmonicRhythm,
      );
      items.push(transposeChord(shape, root, this.config.baseMidi));
      duration += beats;
      ({ shape, root } = corpusNextChord(this.harmony, shape));
    }
    this.chords = items.length
      ? items
      : [this.openingChord(this.config.openingRegister, this.config.openingVoices)];
  }
  beginPhrase(clock) {
    this.formPosition++;
    if (this.formPosition >= this.form.length) {
      this.finished = true;
      if (!this.exitSent) {
        this.exitSent = true;
        this.broadcast("exiting", [this.config.botName, 1]);
      }
      return;
    }
    if (!this.receivedPlan) this.generateLocalPlan();
    const bars =
        this.phraseBars ||
        clock.meter?.phraseBars ||
        this.config.defaultPhraseBars,
      quarterBeats =
        (bars * (clock.meter?.numerator || bandMeter().numerator) * 4) /
        (clock.meter?.denominator || bandMeter().denominator),
      pool = [...new Set(this.chords.flat())],
      density =
        this.config.phraseDensityRange[0] +
        unitRandom() *
          (this.config.phraseDensityRange[1] -
            this.config.phraseDensityRange[0]);
    this.preset = randomInt(this.config.synthPresetCount);
    this.phraseEvents = this.form[this.formPosition]
      ? generateCorpusPhrase(this.corpus, {
          beats: quarterBeats,
          density,
          notePool: pool,
          range: this.config.midiRange,
          nearest: this.config.nearestCorpusRecords,
        })
      : [];
    this.broadcast("notepool", this.chords[0] || pool);
  }
  playEvent(note, duration, velocity, offset, preset) {
    this.audio.methenyMelody(note, duration, velocity, offset, preset);
  }
}

export class SeasonsArpyBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.seasonsArpy;
    this.notes = this.openingPool(this.config.openingRegister);
    this.tala = this.openingTala;
    this.arousal = this.config.defaultArousal;
    this.progress = 0;
    this.hasProgress = false;
    this.phraseBars = this.config.defaultPhraseBars;
    this.order = [];
    this.orderMode = 0;
    this.noteIndex = 0;
    this.lastPosition = -1;
    this.finished = false;
    this.generateOrder();
  }
  onMessage(message) {
    super.onMessage(message);
    if (message.address.endsWith("/progress")) {
      const value = Number(message.args.at(-1));
      if (Number.isFinite(value)) {
        this.progress = Math.max(0, Math.min(1, value));
        this.hasProgress = true;
      }
    }
    if (message.address.endsWith("/arousal")) {
      const value = Number(message.args.at(-1));
      if (Number.isFinite(value))
        this.arousal = Math.max(0, Math.min(1, value));
    }
    if (message.address.endsWith("/phraselength")) {
      const value = Math.round(Number(message.args.at(-1)));
      if (value > 0)
        this.phraseBars = Math.min(this.config.maximumPhraseBars, value);
    }
    if (message.address.endsWith("/notepool")) this.generateOrder();
    if (
      message.address.endsWith("/tala") ||
      message.address.endsWith("/arousal")
    )
      this.cycleKey = null;
    if (message.address.endsWith("/exiting")) this.finished = true;
  }
  generateOrder() {
    const unique = [
      ...new Set(this.notes.map(Number).filter(Number.isFinite)),
    ].sort((a, b) => a - b);
    this.orderMode = randomInt(this.config.orderModes);
    if (this.orderMode === 0) this.order = unique;
    else if (this.orderMode === 1) this.order = [...unique].reverse();
    else this.order = scramble(unique);
    this.noteIndex = 0;
  }
  rhythmCycle(length) {
    const groups =
        this.tala.reduce((sum, value) => sum + value, 0) === length
          ? this.tala
          : defaultGrouping(length),
      key = JSON.stringify([groups, length, Math.round(this.arousal * 100)]);
    if (key !== this.cycleKey) {
      const starts = new Set(additiveGroupStarts(groups, length));
      this.cycle = Array.from({ length }, (_, index) =>
        starts.has(index) ||
        unitRandom() < this.arousal * this.config.additionalOnsetScale
          ? 1
          : 0,
      );
      this.cycleKey = key;
    }
    return this.cycle;
  }
  onTick(
    tick,
    clock,
  ) {
    if (this.finished) return;
    if (clock.phraseStart) this.generateOrder();
    const meterBeats = clock.meter?.numerator || bandMeter().numerator,
      length = Math.max(
        1,
        this.tala.reduce((sum, value) => sum + value, 0) || meterBeats,
      ),
      position = this.hasProgress
        ? Math.round(
            this.progress * Math.max(1, this.phraseBars) * meterBeats,
          ) % length
        : ((clock.bar || 0) * meterBeats + (clock.beat || 0)) % length;
    if (position === this.lastPosition) return;
    this.lastPosition = position;
    const cycle = this.rhythmCycle(length);
    if (!cycle[position]) return;
    const note =
        this.order[this.noteIndex % Math.max(1, this.order.length)] ??
        this.openingPool(this.config.openingRegister)[0],
      velocity =
        this.config.velocityCycle[position % this.config.velocityCycle.length];
    this.noteIndex++;
    // (A beat of its cycle, on the tick it falls on.)
    writtenOn(this.audio, clock.tick, clock.meter?.subdivision || 1, () => this.audio.seasonsArpy(note, this.config.noteDurationSeconds, velocity));
  }
}

export class SeasonsBrokenChordBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.seasonsBrokenChord;
    this.chords = [this.openingChord(this.config.openingRegister, this.config.openingVoices)];
    this.durations = [...this.config.defaultDurations];
    this.arousal = this.config.defaultArousal;
    this.progress = 0;
    this.hasProgress = false;
    this.phraseBars = this.config.defaultPhraseBars;
    this.lastChord = -1;
  }
  onMessage(message) {
    super.onMessage(message);
    if (message.address.endsWith("/progress")) {
      const value = Number(message.args.at(-1));
      if (Number.isFinite(value)) {
        const next = Math.max(0, Math.min(1, value));
        if (next < this.progress) this.lastChord = -1;
        this.progress = next;
        this.hasProgress = true;
      }
    }
    if (message.address.endsWith("/arousal")) {
      const value = Number(message.args.at(-1));
      if (Number.isFinite(value))
        this.arousal = Math.max(0, Math.min(1, value));
    }
    if (message.address.endsWith("/phraselength")) {
      const value = Math.round(Number(message.args.at(-1)));
      if (value > 0)
        this.phraseBars = Math.min(this.config.maximumPhraseBars, value);
    }
    if (message.address.endsWith("/plan/chords")) {
      const chords = parseChordPlan(message.args);
      if (chords.length) {
        this.chords = chords;
        this.lastChord = -1;
      }
    }
    if (message.address.endsWith("/plan/chordDuration")) {
      const durations = message.args
        .map(Number)
        .filter((value) => Number.isFinite(value) && value > 0);
      if (durations.length) {
        this.durations = durations;
        this.lastChord = -1;
      }
    }
  }
  voicedChord(chord) {
    let previous = 35;
    return chord.map((value) => {
      let note = Number(value);
      if (note < 36) note = 48 + pitchClass(note);
      while (note <= previous) note += 12;
      previous = note;
      return note;
    });
  }
  onTick(
    tick,
    clock,
  ) {
    if (!this.chords.length) return;
    const meterBeats =
        ((clock.meter?.numerator || bandMeter().numerator) * 4) / (clock.meter?.denominator || bandMeter().denominator),
      position = this.hasProgress
        ? phrasePosition(this.progress, this.phraseBars, meterBeats)
        : (clock.bar || 0) * meterBeats +
          ((clock.beat || 0) * 4) / (clock.meter?.denominator || bandMeter().denominator),
      current = chordAtPosition(this.chords, this.durations, position);
    if (!current || current.index === this.lastChord) return;
    this.lastChord = current.index;
    const secondsPerQuarter = 60 / Math.max(1, clock.bpm || bandTempo()),
      durationSeconds = current.duration * secondsPerQuarter,
      voiceCount = seasonsVoiceCount(
        this.arousal,
        this.config.maximumVoices,
        this.config.fullPolyphonyArousal,
      );
    // (Written as the chord it breaks, rolled -- each voice's entry how it is played -- from here to the chord's end, in the
    // quarters it reads: lib/written.js.)
    const total = this.chords.reduce((sum, _, index) => sum + Math.max(1e-6, Number(this.durations[index]) || 1), 0),
      wrapped = ((position % total) + total) % total,
      written = corpusFraction(Math.max(1 / 1024, current.start + current.duration - wrapped)).mul(portQuarterTicks(clock));
    for (const voice of staggeredHeldVoices(
      this.voicedChord(current.chord),
      durationSeconds,
      voiceCount,
    ))
      writtenOn(this.audio, clock.tick, written, () => this.audio.seasonsBrokenChord(
        voice.note,
        voice.duration,
        this.config.velocity,
        voice.delay,
      ), { scoreArpeggio: true });
  }
}

export class SeasonsChordBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.seasonsChord;
    this.chords = this.openingProgression(this.config.openingChords).map(chordOffsets);
    this.durations = [...this.config.defaultDurations];
    this.tala = this.openingTala;
    this.arousal = this.config.defaultArousal;
    this.phraseBars = this.config.defaultPhraseBars;
    this.progress = 0;
    this.hasProgress = false;
    this.lastPosition = -1;
    this.rebuildCycle();
  }
  onMessage(message) {
    super.onMessage(message);
    if (message.address.endsWith("/progress")) {
      const value = Number(message.args.at(-1));
      if (Number.isFinite(value)) {
        const next = Math.max(0, Math.min(1, value));
        if (next < this.progress) this.lastPosition = -1;
        this.progress = next;
        this.hasProgress = true;
      }
    }
    if (message.address.endsWith("/arousal")) {
      const value = Number(message.args.at(-1));
      if (Number.isFinite(value)) {
        this.arousal = Math.max(0, Math.min(1, value));
        this.rebuildCycle();
      }
    }
    if (message.address.endsWith("/phraselength")) {
      const value = Math.round(Number(message.args.at(-1)));
      if (value > 0)
        this.phraseBars = Math.min(this.config.maximumPhraseBars, value);
    }
    if (message.address.endsWith("/tala")) this.rebuildCycle();
    if (message.address.endsWith("/plan/chords")) {
      const chords = parseChordPlan(message.args);
      if (chords.length) this.chords = chords;
    }
    if (message.address.endsWith("/plan/chordDuration")) {
      const durations = message.args
        .map(Number)
        .filter((value) => Number.isFinite(value) && value > 0);
      if (durations.length) this.durations = durations;
    }
  }
  rebuildCycle() {
    this.onsetCycle = seasonsOnsetCycle(this.tala, this.arousal);
    this.lastPosition = -1;
  }
  phase(clock) {
    if (this.hasProgress) return this.progress;
    const bars = Math.max(1, this.phraseBars),
      bar = (((clock.bar || 0) % bars) + bars) % bars,
      within =
        (clock.tickInBar || 0) / Math.max(1, clock.meter?.pulsesPerBar || 1);
    return (bar + within) / bars;
  }
  onTick(
    tick,
    clock,
  ) {
    const length = this.onsetCycle.length;
    if (!length || !this.chords.length) return;
    const phase = this.phase(clock),
      position = Math.round(phase * this.phraseBars * length) % length;
    if (position === this.lastPosition) return;
    this.lastPosition = position;
    if (!this.onsetCycle[position]) return;
    const current = planAtProgress(this.chords, this.durations, phase),
      notes = ascendingPitchClassVoicing(current?.chord || [], this.arousal);
    if (!notes.length) return;
    const velocity =
      this.tala.join(",") === this.bandTime.tala.join(",")
        ? this.config.velocityContour[
            position % this.config.velocityContour.length
          ]
        : metricWeights(this.tala, 1)[position] / 7;
    // (A stab of its cycle, written one place of it long: a bar's share.)
    writtenOn(this.audio, clock.tick, new Rational(clock.meter?.pulsesPerBar || 1, length), () => this.audio.seasonsChord(
      notes,
      this.config.articulationSeconds,
      Math.max(0.08, Math.min(1, velocity)),
    ));
  }
}

export class SeasonsDroneBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = this.configuration();
    this.chords = this.openingProgression(this.config.openingChords).map(chordOffsets);
    this.durations = [...this.config.defaultDurations];
    this.tala = this.openingTala;
    this.arousal = this.config.defaultArousal;
    this.phraseBars = this.config.defaultPhraseBars;
    this.progress = 0;
    this.hasProgress = false;
    this.receivedPlan = false;
    this.lastChord = -1;
    this.updateAnchor();
  }
  configuration() {
    return CONFIG.seasonsDrone;
  }
  updateAnchor() {
    this.anchor = mostCommonPitchClass(this.chords);
  }
  onMessage(message) {
    super.onMessage(message);
    if (message.address.endsWith("/progress")) {
      const value = Number(message.args.at(-1));
      if (Number.isFinite(value)) {
        const next = Math.max(0, Math.min(1, value));
        if (next < this.progress) this.lastChord = -1;
        this.progress = next;
        this.hasProgress = true;
      }
    }
    if (message.address.endsWith("/arousal")) {
      const value = Number(message.args.at(-1));
      if (Number.isFinite(value))
        this.arousal = Math.max(0, Math.min(1, value));
    }
    if (message.address.endsWith("/phraselength")) {
      const value = Math.round(Number(message.args.at(-1)));
      if (value > 0)
        this.phraseBars = Math.min(this.config.maximumPhraseBars, value);
    }
    if (message.address.endsWith("/plan/chords")) {
      const chords = parseChordPlan(message.args);
      if (chords.length) {
        this.chords = chords;
        this.receivedPlan = true;
        this.lastChord = -1;
        this.updateAnchor();
      }
    }
    if (message.address.endsWith("/plan/chordDuration")) {
      const durations = message.args
        .map(Number)
        .filter((value) => Number.isFinite(value) && value > 0);
      if (durations.length) {
        this.durations = durations;
        this.lastChord = -1;
      }
    }
    if (message.address.endsWith("/notepool") && !this.receivedPlan) {
      this.chords = [this.notes.map((note) => note % 12)];
      this.durations = [1];
      this.lastChord = -1;
      this.updateAnchor();
    }
  }
  phase(clock) {
    if (this.hasProgress) return this.progress;
    const bars = Math.max(1, this.phraseBars),
      bar = (((clock.bar || 0) % bars) + bars) % bars,
      within =
        (clock.tickInBar || 0) / Math.max(1, clock.meter?.pulsesPerBar || 1);
    return (bar + within) / bars;
  }
  render(note, duration, velocity, delay) {
    this.audio.seasonsDrone(note, duration, velocity, delay);
  }
  onTick(
    tick,
    clock,
  ) {
    if (!this.chords.length) return;
    const phase = this.phase(clock),
      current = planAtProgress(this.chords, this.durations, phase);
    if (!current || current.index === this.lastChord) return;
    this.lastChord = current.index;
    const pc = anchoredChordPitch(current.chord, this.anchor);
    if (pc == null) return;
    const total = this.durations
        .slice(0, this.chords.length)
        .reduce((sum, value) => sum + (Number(value) || 1), 0),
      fraction = current.duration / Math.max(1e-6, total),
      quarterBeats =
        (this.phraseBars * (clock.meter?.numerator || bandMeter().numerator) * 4) /
        (clock.meter?.denominator || bandMeter().denominator),
      spanSeconds =
        (fraction * quarterBeats * 60) / Math.max(1, clock.bpm || bandTempo()),
      window = seasonsDroneWindow(spanSeconds, this.arousal);
    // (Written for its chord's share of the phrase, in the quarters it reads, its window's entry how it is played.)
    const span = corpusFraction(current.duration).div(corpusFraction(Math.max(1e-6, total))).mul(new Rational(this.phraseBars * (clock.meter?.numerator || bandMeter().numerator) * 4, clock.meter?.denominator || bandMeter().denominator));
    writtenOn(this.audio, clock.tick, span.mul(portQuarterTicks(clock)), () => this.render(
      pc + this.config.octave * 12,
      window.duration,
      this.config.velocity,
      window.delay,
    ));
  }
}

export class SeasonsSussyBot extends SeasonsDroneBot {
  configuration() {
    return CONFIG.seasonsSussy;
  }
  render(note, duration, velocity, delay) {
    this.audio.seasonsSussy(note, duration, velocity, delay);
  }
}

export class ResynthBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.resynth;
    this.activityMask = [...this.config.activityMasks[2]];
    // Its pitch-class sets are written in C: moved to a key, C preferred but not always taken (shared/opening-harmony.js).
    this.poolShift = (((this.preferredTonic(60) - 60) % 12) + 12) % 12;
    this.pitchclassPool = this.config.pitchclassPools[
      randomInt(this.config.pitchclassPools.length)
    ].map((pc) => pc + this.poolShift);
    this.contour = [
      ...this.config.contours[randomInt(this.config.contours.length)],
    ];
    this.receivedMasks = [];
    this.lastPhrase = -1;
    this.lastCell = -1;
    this.register = 60;
    this.model = randomInt(this.config.spectralModels.length);
  }
  onMessage(message) {
    super.onMessage(message);
    const intent = parseCompoundIntent(message);
    if (
      intent &&
      intent.sender !== this.instanceId &&
      intent.sender !== "bc.resynth_bot" &&
      intent.activityMask
    )
      this.receivedMasks.push(intent.activityMask);
    else if (message.address === "/broadcast/intent/activityMask")
      this.receivedMasks.push(normalizeActivityMask(message.args));
  }
  beginPhrase(clock) {
    if (this.lastPhrase >= 0) {
      this.activityMask = this.receivedMasks.length
        ? residualActivityMask(
            this.config.activityMasks[
              randomInt(this.config.activityMasks.length)
            ],
            this.receivedMasks,
          )
        : [
            ...this.config.activityMasks[
              randomInt(this.config.activityMasks.length)
            ],
          ];
      this.pitchclassPool = this.config.pitchclassPools[
        randomInt(this.config.pitchclassPools.length)
      ].map((pc) => pc + this.poolShift);
      this.contour = [
        ...this.config.contours[randomInt(this.config.contours.length)],
      ];
      this.model = randomInt(this.config.spectralModels.length);
    }
    this.receivedMasks = [];
    this.lastPhrase = clock.phrase;
    this.lastCell = -1;
    this.broadcast(
      "intent",
      serializeIntentFields("bc.resynth_bot", {
        activityMask: this.activityMask,
        contourA: this.contour,
        pitchclassPool: this.pitchclassPool,
        talaStructure: this.config.talaStructure,
      }),
    );
  }
  noteFor(cell) {
    const direction =
      this.contour[Math.min(this.contour.length - 1, Math.floor(cell / 2))];
    this.register = Math.max(
      this.config.registerRange[0],
      Math.min(
        this.config.registerRange[1],
        this.register +
          (direction === "U"
            ? randomInt(this.config.registerStep + 1)
            : -randomInt(this.config.registerStep + 1)),
      ),
    );
    const pc = this.pitchclassPool[cell % this.pitchclassPool.length],
      target = this.register + ((pc - (this.register % 12) + 12) % 12);
    return target > this.config.registerRange[1] ? target - 12 : target;
  }
  onTick(
    tick,
    clock,
  ) {
    clock = this.interpretClock(clock);
    if (clock.phraseStart && clock.phrase !== this.lastPhrase)
      this.beginPhrase(clock);
    const cell = cycleIndexAtPhrasePosition(clock, 16);
    if (cell === this.lastCell) return;
    this.lastCell = cell;
    const activity = this.activityMask[cell] || 0;
    if (activity <= 0 || (!clock.phraseStart && randomInt(10) >= activity))
      return;
    const [low, high] = this.config.noteDurationBeats,
      duration =
        ((low + unitRandom() * (high - low)) * 60) / (clock.bpm || bandTempo()),
      velocity = Math.max(
        0.15,
        Math.min(
          1,
          0.45 +
            activity / 18 +
            (unitRandom() - 0.5) * this.config.velocityVariation,
        ),
      );
    // (Written to its phrase cell's next, as the FM texture is.)
    writtenOn(this.audio, clock.tick, ticksUntil(clock, (ahead) => cycleIndexAtPhrasePosition(ahead, 16) !== cell, phraseTicksLeft(clock, clock.meter.phraseBars || bandPhraseBars())), () => this.audio.resynth(
      this.noteFor(cell),
      duration,
      velocity,
      this.config.spectralModels[this.model],
      this.model,
    ));
  }
}

export class XSequencerBot extends SequencerBot {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.xSequencer;
    this.notes = this.openingPool(this.config.openingRegister);
    this.progress = 0;
    this.enabled = true;
    this.exiting = false;
    this.preset = randomInt(this.config.presetCount);
    this.generatePattern();
  }
  async start() {
    try {
      const response = await fetch("./data/x-sequencer-presets.json");
      this.presets = await response.json();
    } catch {}
  }
  onMessage(message) {
    super.onMessage(message);
    if (message.address.endsWith("/progress")) {
      const value = Number(message.args.at(-1));
      if (Number.isFinite(value))
        this.progress = Math.max(0, Math.min(1, value));
    }
    if (message.address.endsWith("/initialize")) {
      this.preset = randomInt(this.config.presetCount);
      this.generatePattern();
    }
    if (message.address.endsWith("/onoff"))
      this.enabled = Number(message.args.at(-1)) !== 0;
    if (message.address.endsWith("/exiting"))
      this.exiting = Number(message.args.at(-1)) !== 0;
  }
  render(note, duration, velocity) {
    this.audio.xSequencerNote(
      note,
      duration,
      velocity,
      this.progress,
      this.preset,
    );
  }
  onTick(tick, clock) {
    if (this.enabled && !this.exiting) super.onTick(tick, clock);
  }
}

export class ContourBot extends Agent {
  constructor(...args) {
    super(...args);
    this.history = [];
    this.phraseEvents = [];
    this.lastPhrase = -1;
    this.lastSoundBar = -1;
  }
  planMotif(clock) {
    if (this.phraseEvents.length) {
      const motif = this.publishMotif(this.phraseEvents, {
        tags:["melody","curated","contour-balanced"],
        createdAt:{bar:clock.bar||0,phrase:Math.max(0,(clock.phrase||0)-1),section:clock.section||0},
      });
      const transformed = {
        ...transformMotif(motif, {
          transpose: weightedChoice([-5,-2,0,2,5], [.1,.2,.25,.3,.15]),
          timeScale: weightedChoice([.5,1,2], [.15,.7,.15]),
          invert: unitRandom() < .22,
          retrograde: unitRandom() < .12,
        }),
        motifId:`${this.instanceId}:planned:${clock.phrase||0}`,
        author:this.instanceId,
      };
      const phraseBars=clock.meter?.phraseBars||bandPhraseBars(),
        appliesAt={bar:(clock.bar||0)+phraseBars,phrase:(clock.phrase||0)+1,section:clock.section||0};
      this.publishPlan("motif",{schemaVersion:1,motif:transformed,development:transformed.transformation},{
        createdAt:{bar:clock.bar||0,phrase:clock.phrase||0,section:clock.section||0},
        appliesAt,expiresAt:{...appliesAt,bar:appliesAt.bar+phraseBars,phrase:appliesAt.phrase+1},
        confidence:.74,priority:.58,
        rationale:"Offer a recognizable but varied contour for another melodic agent's next phrase.",
      });
    }
    this.phraseEvents = [];
  }
  onTick(tick, clock) {
    if (clock.phraseStart && clock.phrase !== this.lastPhrase) {
      this.planMotif(clock);
      this.lastPhrase = clock.phrase;
    }
    const subdivision=clock.meter?.subdivision||bandMeter().subdivision,
      offbeat=Math.max(1,Math.floor(subdivision/2));
    if (clock.subdivision !== offbeat) return;
    const finalBeat=Math.max(0,Number(clock.meter?.numerator||bandMeter().numerator)-1),
      mustSoundThisBar=this.lastSoundBar!==clock.bar&&clock.beat>=finalBeat;
    if (!mustSoundThisBar &&
      unitRandom() > Math.min(.72, this.density * CONFIG.contour.densityScale))
      return;
    const note=chooseContrastingPitch(this.notes,this.history,{
      ...CONFIG.contour,random:unitRandom,
    });
    // No class of the pool sounds in the register: rest, never a pitch outside
    // the pool (the audit's B05).
    if(note===null)return;
    this.history.push(note);
    if(this.history.length>CONFIG.contour.history)this.history.shift();
    // Most of a beat, and a beat is 60 / bpm: the clock's bpm counts the
    // notated beat (see HarmonyPulse's accompany; the audit's B04).
    const duration=(60/(clock.bpm||bandTempo()))*.62,
      velocity=this.shapeVelocity(.62,note,{clock,amount:.7});
    // (Written to its next chance, the next beat's offbeat.)
    writtenOn(this.audio,clock.tick,subdivision,()=>this.audio.ornamentPluck(note,duration,velocity));
    this.lastSoundBar=clock.bar;
    this.phraseEvents.push({at:clock.tickInPhrase||clock.tick||0,duration:subdivision*.62,pitches:[note],velocity});
  }
}
