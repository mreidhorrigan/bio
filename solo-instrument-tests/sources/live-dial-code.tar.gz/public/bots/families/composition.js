// The composing bots: the x-suite's producer and Tangerine Dream.
// Moved verbatim from public/agents.js in its per-family split (28 September 2026; RESEARCH_BACKLOG, the second
// queue). agents.js registers them (BOT_REGISTRY) and re-exports each, so an import from it is as it was.
import { Agent } from "../../framework/index.js";
import { STOCHASTIC_CONFIG as CONFIG } from "../../stochastic-config.js";
import { corpusInitialShape, corpusNextChord, transposeChord, weightedPitchClass } from "../../shared/harmony.js";
import {
  interpolateCurvePoints, randomFivePointCurve, randomInt, unitRandom, weightedChoice,
} from "../../shared/stochastic.js";
import { octaveExpandedPool, reflectedWalk } from "../../shared/sequencing.js";
import {bandTempo} from '../../shared/opening-time.js';
import {writtenOn,toNextOf} from "../lib/written.js";
import {authoredFraction} from "../../shared/performers/rhythm-cell.js";

export class XProducerBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.xProducer;
    this.form = [];
    this.phrase = -1;
    this.section = null;
    this.initialized = false;
    this.enabled = true;
  }
  generate() {
    const c = this.config,
      first = weightedChoice(c.sections, c.formWeights);
    this.form = [first];
    for (let index = 1; index < c.phraseCount; index++) {
      const row =
        c.sectionTransitions[this.form.at(-1)] || c.sectionTransitions.A;
      this.form.push(weightedChoice(row.values, row.weights));
    }
    this.densityCurve = randomFivePointCurve({
      xRanges: c.densityPointXRanges,
      terminalWeights: c.densityTerminalWeights,
    });
    this.subpatterns = c.subpatterns.map((pattern, index) => ({
      pattern: pattern.split(" "),
      weight: c.subpatternWeights[index],
    }));
    this.initialized = true;
    this.broadcast("initialize", [1]);
  }
  onMessage(message) {
    // generate() ends by broadcasting /initialize to the band, and a broadcast
    // comes back to its sender like anyone else's. Answering its own
    // announcement made it generate again, announce again, and never stop:
    // a stack overflow on a synchronous bus (every x-bot's tick died with it,
    // at a depth that varied run to run, so renders were not even repeatable)
    // and a message storm on a networked one. Somebody else's /initialize is
    // still an instruction; its own is an echo.
    const own =
      message.source === this.instanceId ||
      message.source === "ae_xProducerBOT";
    if (message.address.endsWith("/initialize") && !own) this.generate();
    if (message.address.endsWith("/onoff"))
      this.enabled = Number(message.args.at(-1)) !== 0;
  }
  phraseState(index) {
    const c = this.config,
      progress = index / Math.max(1, c.phraseCount - 1),
      density = Math.max(
        0,
        Math.min(1, interpolateCurvePoints(this.densityCurve, progress)),
      ),
      parts = c.parts.map(() => (unitRandom() < density ? 1 : 0));
    if (!parts.some(Boolean)) parts[randomInt(parts.length)] = 1;
    return { section: this.form[index], progress, density, parts };
  }
  emit(index) {
    const state = this.phraseState(index),
      sectionStart = index === 0 || this.form[index - 1] !== state.section,
      sectionEnd = this.form.findIndex(
        (value, next) => next > index && value !== state.section,
      ),
      length = (sectionEnd < 0 ? this.form.length : sectionEnd) - index;
    if (sectionStart) {
      this.section = state.section;
      this.broadcast("section", [state.section]);
      this.broadcast("phraselength", [length]);
      this.broadcast(
        "subpattern",
        weightedChoice(
          this.subpatterns,
          this.subpatterns.map((item) => item.weight),
        ).pattern,
      );
    }
    this.broadcast("progress", [state.progress]);
    this.broadcast("density", [state.density]);
    this.broadcast("onoff", [
      {
        parts: Object.fromEntries(
          this.config.parts.map((part, i) => [part, state.parts[i]]),
        ),
      },
    ]);
  }
  onTick(tick, clock) {
    if (!this.enabled || !clock.phraseStart || clock.phrase === this.phrase)
      return;
    if (!this.initialized) this.generate();
    this.phrase = clock.phrase;
    const index = clock.phrase % this.form.length;
    if (clock.phrase > 0 && index === 0) {
      this.broadcast("exiting", [1]);
      this.generate();
    }
    this.emit(index);
  }
}

export class TangerineDreamBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.tangerineDream;
    this.tala = this.openingTala;
    this.phraseBars = 8;
    this.totalPhrases = 8;
    this.form = [];
    this.formPhrase = -1;
    this.currentChord = [...this.bandOpening.chord];
    this.harmony = [[...this.currentChord]];
    this.harmonicRhythm = 4;
    this.sequence = [];
    this.sequenceIndex = 0;
    this.generateForm();
    this.generateSequence();
  }
  async start() {
    try {
      const [harmony, presets] = await Promise.all(
        [
          "./data/metheny-harmony.json",
          "./data/tangerine-dream-presets.json",
        ].map((path) => fetch(path).then((response) => response.json())),
      );
      this.harmonyCorpus = harmony;
      this.presets = presets;
      this.generateHarmony();
    } catch {}
  }
  generateForm() {
    const c = this.config,
      [low, high] = c.phraseCountRange;
    this.totalPhrases = low + randomInt(high - low);
    this.densityCurve = randomFivePointCurve({
      xRanges: c.densityPointXRanges,
      terminalWeights: c.densityTerminalWeights,
    });
    this.form = [];
    let previous = null;
    for (let phrase = 0; phrase < this.totalPhrases; phrase++) {
      const density = Math.max(
          0.05,
          Math.min(
            1,
            interpolateCurvePoints(
              this.densityCurve,
              phrase / Math.max(1, this.totalPhrases - 1),
            ),
          ),
        ),
        limit =
          c.maximumActiveParts[
            Math.min(
              c.maximumActiveParts.length - 1,
              Math.floor(density * c.maximumActiveParts.length),
            )
          ],
        state = c.partProbabilities.map((probability, index) =>
          unitRandom() < probability * (previous?.[index] === 0 ? 0.5 : 1)
            ? 1
            : 0,
        ),
        minimum = phrase === 0 || phrase === this.totalPhrases - 1 ? 1 : 2;
      while (state.reduce((a, b) => a + b, 0) < minimum)
        state[randomInt(state.length)] = 1;
      while (state.reduce((a, b) => a + b, 0) > limit) {
        const index = randomInt(state.length);
        state[index] = 0;
      }
      this.form.push({ state, density });
      previous = state;
    }
  }
  generateHarmony() {
    if (!this.harmonyCorpus) return;
    let shape = corpusInitialShape(this.harmonyCorpus),
      root = weightedPitchClass(this.harmonyCorpus[shape]?.initial);
    this.harmony = [];
    for (let i = 0; i < 4; i++) {
      this.harmony.push(transposeChord(shape, root, this.config.baseMidi));
      ({ shape, root } = corpusNextChord(this.harmonyCorpus, shape));
    }
    if (this.harmony.length) this.currentChord = this.harmony[0];
  }
  generateSequence() {
    const pool = octaveExpandedPool(this.currentChord, [-1, 0, 1], [48, 84]);
    let index = randomInt(Math.max(1, pool.length));
    this.sequence = Array.from({ length: 16 + randomInt(45) }, () => {
      index = reflectedWalk(
        index,
        weightedChoice([-2, -1, 0, 1, 2], [0.08, 0.24, 0.36, 0.24, 0.08]),
        pool.length,
      );
      return pool[index] ?? 60;
    });
    this.sequenceIndex = 0;
    this.sequenceRate = weightedChoice(
      this.config.sequencerStepsPerBeat,
      [1, 1],
    );
  }
  onMessage(message) {
    super.onMessage(message);
    if (message.address.endsWith("/phrases")) {
      const value = Math.round(Number(message.args.at(-1)));
      if (value > 0) {
        this.totalPhrases = Math.min(128, value);
        this.generateForm();
      }
    }
    if (message.address.endsWith("/phraselength")) {
      const value = Math.round(Number(message.args.at(-1)));
      if (value > 0) this.phraseBars = Math.min(128, value);
    }
  }
  beginPhrase(clock) {
    if (clock.phrase > 0 && clock.phrase % this.totalPhrases === 0) {
      this.generateForm();
      this.generateHarmony();
    }
    this.formPhrase = clock.phrase;
    const state = this.form[clock.phrase % this.form.length];
    this.state = Object.fromEntries(
      this.config.partNames.map((name, index) => [
        name,
        Boolean(state.state[index]),
      ]),
    );
    this.density = state.density;
    this.phraseBars = weightedChoice(
      this.config.phraseLengthCandidates,
      this.config.phraseLengthWeights,
    );
    this.harmonicRhythm = weightedChoice(
      this.config.harmonicRhythmChoices,
      this.config.harmonicRhythmWeights,
    );
    this.broadcast("phraselength", [this.phraseBars]);
    this.broadcast("hdensity", [this.density]);
    this.broadcast("tala", this.tala);
  }
  chordBoundary(clock) {
    return clock.barStart && clock.bar % this.harmonicRhythm === 0;
  }
  onTick(
    tick,
    clock,
  ) {
    clock = this.interpretClock(clock);
    if (clock.phraseStart && clock.phrase !== this.formPhrase)
      this.beginPhrase(clock);
    const progress =
      ((clock.bar % (clock.meter.phraseBars || this.phraseBars)) +
        (clock.tickInBar || 0) / clock.meter.pulsesPerBar) /
      (clock.meter.phraseBars || this.phraseBars);
    if (clock.beatStart) this.broadcast("progress", [progress]);
    if (this.chordBoundary(clock) && this.harmony.length) {
      this.currentChord =
        this.harmony[
          Math.floor(clock.bar / this.harmonicRhythm) % this.harmony.length
        ];
      this.broadcast("notepool", this.currentChord);
      this.generateSequence();
      // (Each written as the piece composed it: the pad to its harmony's next chord, the bass to its next group, the
      // melody a beat, the sequencer its step, the drums a beat -- lib/written.js.)
      if (this.state?.pad)
        writtenOn(this.audio, clock.tick, this.harmonicRhythm * clock.meter.pulsesPerBar, () => this.audio.padChord(
          this.currentChord.map((note) => note + this.config.padOctaveOffset),
          (this.harmonicRhythm * 60) / (clock.bpm || bandTempo()),
          this.density,
          progress,
        ));
    }
    if (this.state?.bass && clock.groupStart) {
      const starts = [];
      let at = 0;
      for (const size of clock.meter.groups) { starts.push(at); at += size * clock.meter.subdivision; }
      writtenOn(this.audio, clock.tick, toNextOf(starts, clock.tickInBar, clock.meter.pulsesPerBar), () => this.audio.bass(
        (this.currentChord[0] ?? 60) + this.config.bassOctaveOffset,
        0.4 + 0.5 * this.density,
      ));
    }
    if (
      this.state?.melody &&
      clock.beatStart &&
      (clock.phraseStart ||
        unitRandom() < this.density * this.config.melodyProbabilityScale)
    ) {
      const note = this.currentChord[randomInt(this.currentChord.length)] ?? 60;
      writtenOn(this.audio, clock.tick, clock.meter.subdivision, () => this.audio.methenyMelody(
        note + 12,
        0.2 + (60 / (clock.bpm || bandTempo())) * 0.5,
        0.4 + 0.5 * this.density,
        0,
        0,
      ));
    }
    if (
      this.state?.sequencer &&
      clock.subdivision % (clock.meter.subdivision / this.sequenceRate || 1) ===
        0
    ) {
      const note = this.sequence[this.sequenceIndex++ % this.sequence.length];
      // (Its stride: the fewest ticks its step's length divides -- every tick where the step is shorter than one.)
      writtenOn(this.audio, clock.tick, authoredFraction(clock.meter.subdivision).div(this.sequenceRate || clock.meter.subdivision).n, () => this.audio.xSequencerNote(
        note,
        0.18,
        0.35 + 0.5 * this.density,
        progress,
        0,
      ));
    }
    if (this.state?.drums) {
      const beat = clock.meter.subdivision;
      if (clock.barStart)
        writtenOn(this.audio, clock.tick, beat, () => this.audio.houseDrum("kick", 0.45 + 0.5 * this.density));
      if (
        clock.beatStart &&
        clock.beat === Math.floor(clock.meter.numerator / 2)
      )
        writtenOn(this.audio, clock.tick, beat, () => this.audio.houseDrum("snare", 0.45 + 0.5 * this.density));
      if (clock.beatStart)
        writtenOn(this.audio, clock.tick, beat, () => this.audio.houseDrum("closedHat", 0.3 + 0.5 * this.density));
    }
  }
}
