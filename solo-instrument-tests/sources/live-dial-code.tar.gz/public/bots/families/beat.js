// The beat and percussion bots: the ae_ beat family (BeatBOT and its forms), the percussion and sample-beat
// bots, the x-suite's drummer and percussion, PAP's and mh_'s beats, Autechre and ProckRock's beads.
// Moved verbatim from public/agents.js in its per-family split (28 September 2026; RESEARCH_BACKLOG, the second
// queue). agents.js registers them (BOT_REGISTRY) and re-exports each, so an import from it is as it was.
import { Agent } from "../../framework/index.js";
import { STOCHASTIC_CONFIG as CONFIG } from "../../stochastic-config.js";
import { FallbackControlLease, StaleValueLease } from "../../shared/control-ownership.js";
import {
  additiveGroupStarts, clumpedRhythm, cyclicPattern, defaultGrouping, randomAdditiveGrouping, randomDupleOnsets,
} from "../../shared/rhythm.js";
import {
  boundedDrunk, exponentialRankIndex, interpolateControlPoints, interpolateCurvePoints, nearestRecords,
  randomFivePointCurve, randomInt, randomProductGate, scramble, unitRandom, weightedChoice,
} from "../../shared/stochastic.js";
import {
  normalizeActivityMask, normalizeRepetitionStructure, parseCompoundIntent, residualActivityMask, serializeIntentFields,
} from "../../shared/intentions.js";
import { phrasePosition } from "../../shared/seasons.js";
import { pitchClass } from "../../shared/pitch.js";
import { sourceStep } from "../../shared/sequencing.js";
import {bandPhraseBars,bandTempo} from '../../shared/opening-time.js';
import {dividedInterval} from '../../shared/performers/rhythm-cell.js';
import {withScoreTime,scoreTime} from '../../shared/score-time.js';
import {Rational} from '../../transcript/rational.js';
import {writtenOn,writtenOnStep,toNextAttack,barTickOf} from '../lib/written.js';

// (A stroke written on its tick to its next chance in its own pattern -- a flag a tick of the bar -- a beat at most:
// lib/written.js. A kick's chances its groups' heads, a backbeat's their middles.)
const stroke=(bot,clock,chances,play)=>writtenOn(bot.audio,clock.tick,Math.min(clock.meter.subdivision||1,toNextAttack(chances,clock.tickInBar||0,{ticks:clock.meter.pulsesPerBar})),play);
const groupHeads=meter=>{const out=Array(meter.pulsesPerBar).fill(false);let at=0;for(const size of meter.groups){if(at<out.length)out[at]=true;at+=size*meter.subdivision}return out};
const groupMiddles=meter=>{const out=Array(meter.pulsesPerBar).fill(false);let at=0;for(const size of meter.groups){const k=at+Math.floor(size/2)*meter.subdivision;if(k<out.length)out[k]=true;at+=size*meter.subdivision}return out};

export class BeatBot extends Agent {
  constructor(...args) {
    super(...args);
    this.lastForm = -1;
    this.config = CONFIG.beat;
  }
  onTick(
    tick,
    clock,
  ) {
    clock = this.interpretClock(clock);
    if (clock.phraseStart) {
      const form = clock.phrase;
      if (form !== this.lastForm) {
        this.lastForm = form;
        this.density =
          this.config.densityProfile[form % this.config.densityProfile.length];
        this.broadcast("phraselength", [clock.meter.phraseBars]);
        this.broadcast("phrases", [clock.meter.phraseBars]);
        if (this.tala.reduce((a, b) => a + b, 0) === clock.meter.numerator)
          this.broadcast("tala", this.tala);
        this.broadcast("hdensity", [this.density]);
        this.broadcast("vdensity", [
          this.config.densityProfile[
            (form + 4) % this.config.densityProfile.length
          ],
        ]);
      }
    }
    this.pattern(tick, clock);
  }
  pattern(tick, clock) {
    const rhythm = this.rhythm(clock, this.config, this.density),
      active = rhythm[clock.tickInBar];
    if (
      clock.groupStart &&
      (clock.barStart || this.instanceAllows(clock, 0, 0.78))
    )
      stroke(this, clock, groupHeads(clock.meter), () => this.audio.kick());
    if (
      clock.beatStart &&
      clock.groupBeat === Math.floor(clock.meter.groups[clock.group] / 2) &&
      this.instanceAllows(clock, 1, 0.82)
    )
      stroke(this, clock, groupMiddles(clock.meter), () => this.audio.snare());
    if (active) stroke(this, clock, rhythm, () => this.audio.hat());
  }
}

export class ElectronicBeatBot extends BeatBot {}

export class JazzBeatBot extends BeatBot {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.jazzBeat;
  }
  pattern(tick, clock) {
    const rhythm = this.rhythm(clock, this.config, this.density),
      active = rhythm[clock.tickInBar];
    if (
      clock.groupStart &&
      (clock.barStart || this.instanceAllows(clock, 0, 0.68))
    )
      stroke(this, clock, groupHeads(clock.meter), () => this.audio.softKick());
    if (
      clock.beatStart &&
      clock.groupBeat === Math.floor(clock.meter.groups[clock.group] / 2) &&
      this.instanceAllows(clock, 1, 0.72)
    )
      stroke(this, clock, groupMiddles(clock.meter), () => this.audio.brush());
    if (active) stroke(this, clock, rhythm, () => this.audio.ride(clock.groupStart ? 0.8 : 0.4));
  }
}

export class CleanBeatBot extends BeatBot {
  configuration() {
    return CONFIG.cleanBeat;
  }
  constructor(...args) {
    super(...args);
    this.config = this.configuration();
    this.phraseLength = weightedChoice(
      this.config.phraseLengths,
      this.config.phraseWeights,
    );
    const [low, high] = this.config.formRandomRange;
    this.formPhrases = Math.max(
      1,
      Math.round(((low + randomInt(high - low)) * 16) / this.phraseLength),
    );
    this.partState = [...this.config.initialPartState];
  }
  choosePartState(phrase) {
    if (phrase === 0) {
      this.partState = [...this.config.initialPartState];
      return;
    }
    this.partState = [
      1,
      ...this.config.percussionVoices.map((_, index) =>
        this.instanceAllows(
          { bar: phrase, group: index },
          index,
          0.25 + this.density * 0.65,
        )
          ? 1
          : 0,
      ),
    ];
    if (this.partState.slice(1).every((value) => !value))
      this.partState[1 + (phrase % 4)] = 1;
  }
  onTick(
    tick,
    clock,
  ) {
    clock = this.interpretClock(clock);
    if (clock.phraseStart && clock.phrase !== this.lastForm) {
      this.lastForm = clock.phrase;
      this.density =
        this.config.densityProfile[
          clock.phrase % this.config.densityProfile.length
        ];
      this.choosePartState(clock.phrase);
      const tala =
        this.config.sourceTala.reduce((sum, value) => sum + value, 0) ===
        clock.meter.numerator
          ? [...this.config.sourceTala]
          : defaultGrouping(clock.meter.numerator);
      this.tala = tala;
      this.broadcast("phraselength", [this.phraseLength]);
      this.broadcast("phrases", [this.formPhrases]);
      this.broadcast("tala", tala);
      this.broadcast("hdensity", [this.density]);
      this.broadcast("vdensity", [
        this.partState.reduce((sum, value) => sum + value, 0) /
          this.partState.length,
      ]);
      this.broadcast("activity", [this.partState]);
    }
    this.pattern(tick, clock);
  }
  pattern(tick, clock) {
    if (this.partState[0]) {
      const rhythm = this.rhythm(clock, this.config, this.density),
        active = rhythm[clock.tickInBar];
      if (
        clock.groupStart &&
        (clock.barStart || this.instanceAllows(clock, 0, 0.82))
      )
        stroke(this, clock, groupHeads(clock.meter), () => this.audio.kick());
      if (
        clock.beatStart &&
        clock.groupBeat === Math.floor(clock.meter.groups[clock.group] / 2) &&
        this.instanceAllows(clock, 1, 0.86)
      )
        stroke(this, clock, groupMiddles(clock.meter), () => this.audio.snare());
      if (active) stroke(this, clock, rhythm, () => this.audio.hat());
    }
    for (const [index, voice] of this.config.percussionVoices.entries()) {
      if (!this.partState[index + 1]) continue;
      const voiceConfig = { ...voice, sharedDensityRange: [0.05, 0.8] },
        rhythm = this.rhythm(clock, voiceConfig, this.density * voice.density),
        active = rhythm[clock.tickInBar];
      if (active && this.instanceAllows(clock, index + 2, 0.82))
        stroke(this, clock, rhythm, () => this.audio.cleanPercussion(index, 0.4 + this.density * 0.6));
    }
  }
}

export class ClumpyBeatBot extends CleanBeatBot {
  configuration() {
    return CONFIG.clumpyBeat;
  }
  pattern(tick, clock) {
    const steps = clock.meter.pulsesPerBar,
      hits = Math.max(1, Math.round(steps * this.density));
    if (this.partState[0]) {
      const rhythm = clumpedRhythm(
          hits,
          clock.meter.groups,
          clock.meter.subdivision,
          this.instancePhase || 0,
        ),
        active = rhythm[clock.tickInBar];
      if (clock.groupStart) stroke(this, clock, groupHeads(clock.meter), () => this.audio.kick());
      if (
        clock.beatStart &&
        clock.groupBeat === Math.floor(clock.meter.groups[clock.group] / 2) &&
        this.instanceAllows(clock, 1, 0.75)
      )
        stroke(this, clock, groupMiddles(clock.meter), () => this.audio.snare());
      if (active) stroke(this, clock, rhythm, () => this.audio.hat());
    }
    for (const [index, voice] of this.config.percussionVoices.entries()) {
      if (!this.partState[index + 1]) continue;
      const voiceHits = Math.max(
          1,
          Math.round(steps * this.density * voice.density),
        ),
        rhythm = clumpedRhythm(
          voiceHits,
          clock.meter.groups,
          clock.meter.subdivision,
          voice.rotation + (this.instancePhase || 0),
        ),
        active = rhythm[clock.tickInBar];
      if (active && this.instanceAllows(clock, index + 2, 0.82))
        stroke(this, clock, rhythm, () => this.audio.cleanPercussion(index, 0.35 + this.density * 0.6));
    }
  }
}

export class NoiseBeatBot extends CleanBeatBot {
  configuration() {
    return CONFIG.noiseBeat;
  }
  pattern(tick, clock) {
    if (this.partState[0]) {
      const rhythm = this.rhythm(clock, this.config, this.density),
        active = rhythm[clock.tickInBar];
      if (
        clock.groupStart &&
        (clock.barStart || this.instanceAllows(clock, 0, 0.8))
      )
        stroke(this, clock, groupHeads(clock.meter), () => this.audio.noiseDrum("kick"));
      if (
        clock.beatStart &&
        clock.groupBeat === Math.floor(clock.meter.groups[clock.group] / 2) &&
        this.instanceAllows(clock, 1, 0.8)
      )
        stroke(this, clock, groupMiddles(clock.meter), () => this.audio.noiseDrum("snare"));
      if (active) stroke(this, clock, rhythm, () => this.audio.noiseDrum("hat"));
    }
    for (const [index, voice] of this.config.percussionVoices.entries()) {
      if (!this.partState[index + 1]) continue;
      const voiceConfig = { ...voice, sharedDensityRange: [0.05, 0.8] },
        rhythm = this.rhythm(clock, voiceConfig, this.density * voice.density),
        active = rhythm[clock.tickInBar];
      if (active && this.instanceAllows(clock, index + 2, 0.84))
        stroke(this, clock, rhythm, () => this.audio.noisePercussion(index, 0.4 + this.density * 0.6));
    }
  }
}

export class NewBeatBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.newBeat;
    this.activityMask = [...this.config.activityMask];
    this.receivedMasks = [];
    this.lastPhrase = -1;
    this.patterns = new Map();
  }
  onMessage(message) {
    super.onMessage(message);
    const intent = parseCompoundIntent(message);
    if (
      intent &&
      intent.sender !== "ae_newBeatBOT" &&
      intent.sender !== this.instanceId &&
      intent.activityMask
    ) {
      this.receivedMasks.push(intent.activityMask);
      return;
    }
    if (message.address === "/broadcast/intent/activityMask")
      this.receivedMasks.push(normalizeActivityMask(message.args));
  }
  makeBarPattern(clock, barIndex, label, phraseStarts) {
    const steps = clock.meter.pulsesPerBar,
      offset = barIndex * steps,
      anchors = phraseStarts
        .filter((value) => value >= offset && value < offset + steps)
        .map((value) => value - offset),
      activityStart = Math.floor(
        (barIndex * this.activityMask.length) / this.config.phraseBars,
      ),
      activityEnd = Math.max(
        activityStart + 1,
        Math.floor(
          ((barIndex + 1) * this.activityMask.length) / this.config.phraseBars,
        ),
      ),
      activity = this.activityMask.slice(activityStart, activityEnd),
      level =
        activity.reduce((sum, value) => sum + value, 0) / (activity.length * 9),
      rotation = (this.instancePhase || 0) + barIndex;
    const kick = Array(steps).fill(0),
      snare = Array(steps).fill(0);
    for (const onset of anchors) kick[onset] = 1;
    kick[0] = 1;
    snare[Math.floor(steps / 2)] = 1;
    const hat = cyclicPattern({
        steps,
        hits: Math.max(1, Math.round(steps * (0.18 + level * 0.54))),
        rotation,
      }),
      percussion = this.config.percussionVoices.map((voice, index) =>
        cyclicPattern({
          steps,
          hits: Math.max(
            1,
            Math.round(steps * Math.max(0.04, level) * voice.density),
          ),
          rotation: rotation + voice.rotation + index,
        }),
      );
    return { label, kick, snare, hat, percussion, level };
  }
  beginPhrase(clock) {
    if (this.lastPhrase >= 0)
      this.activityMask = residualActivityMask(
        this.config.activityMask,
        this.receivedMasks,
      );
    this.receivedMasks = [];
    this.lastPhrase = clock.phrase;
    const bars = clock.meter.phraseBars || this.config.phraseBars,
      total = clock.meter.pulsesPerBar * bars,
      source = this.config.sourceTalaStructure,
      structure =
        source.reduce((sum, value) => sum + value, 0) === total
          ? [...source]
          : defaultGrouping(total),
      starts = additiveGroupStarts(structure, total),
      repetition = normalizeRepetitionStructure(
        this.config.repetitionStructure,
        bars,
      );
    this.talaStructure = structure;
    this.repetitionStructure = repetition;
    this.patterns = new Map();
    for (let bar = 0; bar < bars; bar++) {
      const label = repetition[bar],
        pattern =
          this.patterns.get(label) ||
          this.makeBarPattern(clock, bar, label, starts);
      this.patterns.set(label, pattern);
    }
    this.broadcast(
      "intent",
      serializeIntentFields("ae_newBeatBOT", {
        repetitionStructure: repetition,
        talaStructure: structure,
        activityMask: this.activityMask,
      }),
    );
  }
  onTick(
    tick,
    clock,
  ) {
    clock = this.interpretClock(clock);
    if (clock.phraseStart && clock.phrase !== this.lastPhrase)
      this.beginPhrase(clock);
    if (!this.patterns.size)
      this.beginPhrase({ ...clock, phrase: clock.phrase || 0 });
    const bar = clock.bar % (clock.meter.phraseBars || this.config.phraseBars),
      label = this.repetitionStructure[bar],
      pattern = this.patterns.get(label);
    if (!pattern) return;
    const step = clock.tickInBar,
      accent = 0.35 + pattern.level * 0.65;
    if (pattern.kick[step]) stroke(this, clock, pattern.kick, () => this.audio.kick());
    if (pattern.snare[step] && this.instanceAllows(clock, 1, 0.88))
      stroke(this, clock, pattern.snare, () => this.audio.snare());
    if (pattern.hat[step]) stroke(this, clock, pattern.hat, () => this.audio.hat());
    for (const [index, cycle] of pattern.percussion.entries())
      if (cycle[step] && this.instanceAllows(clock, index + 2, 0.72))
        stroke(this, clock, cycle, () => this.audio.cleanPercussion(index, accent));
  }
}

export class HouseBeatBot extends Agent {
  constructor(...args) {
    super(...args);
    this.memoryDevelopmentEnabled = true;
    this.config = CONFIG.houseBeat;
    this.section = this.config.defaultSection;
    const fallback = Array.from(
      { length: 128 },
      (_, index) => this.config.fallbackBar[index % 16],
    );
    this.corpus = {
      patterns: [fallback],
      ratings: [this.config.sectionTargets[this.section]],
    };
    this.sections = new Map();
    this.generateSection(this.section);
  }
  async start() {
    const response = await fetch("./data/house-beats.json"),
      corpus = await response.json();
    if (
      corpus.patterns?.length !== 1194 ||
      corpus.ratings?.length !== 1194 ||
      corpus.patterns.some((pattern) => pattern.length !== 128)
    )
      throw new Error("Invalid HouseBeat corpus");
    this.corpus = corpus;
    this.sections.clear();
    this.generateSection(this.section);
  }
  generateSection(section) {
    const target =
        this.config.sectionTargets[section] || this.config.sectionTargets.C,
      nearest = nearestRecords(
        this.corpus.ratings,
        target,
        this.config.nearestCount,
      ),
      rank = exponentialRankIndex(nearest.length, this.config.rankBase),
      selected = nearest[rank] || nearest[0],
      pattern = this.corpus.patterns[selected?.index || 0];
    this.sections.set(section, {
      pattern: [...pattern],
      corpusIndex: selected?.index || 0,
      target,
    });
    return this.sections.get(section);
  }
  selectSection(value) {
    let section = String(value ?? "").toUpperCase();
    const labels = Object.keys(this.config.sectionTargets);
    if (/^\d+$/.test(section))
      section =
        labels[
          ((Number(section) % labels.length) + labels.length) % labels.length
        ];
    if (!this.config.sectionTargets[section]) return;
    this.section = section;
    if (!this.sections.has(section)) this.generateSection(section);
  }
  onMemoryRecall(motifs=[]){
    const own=motifs.filter(motif=>motif.author===this.instanceId);
    if(own.length<2)return;
    const labels=Object.keys(this.config.sectionTargets),
      current=Math.max(0,labels.indexOf(this.section)),
      next=labels[(current+1+(this.instanceHash%Math.max(1,labels.length-1)))%labels.length];
    this.section=next;
    this.generateSection(next);
    this.lastSourceStep=-1;
  }
  onMessage(message) {
    super.onMessage(message);
    // /broadcast/section is [section, form length] (docs/MUSEBOT_PROTOCOL.md), and the
    // section is the FIRST argument. Reading the last one is only right for
    // ae_xProducerBOT, which sends the section alone; under mh_PlexBOT it read
    // the form's length -- a constant -- so this bot never saw a section change.
    if (message.address.endsWith("/section"))
      this.selectSection(message.args[0]);
  }
  onTick(
    tick,
    clock,
  ) {
    if (clock.phraseStart && clock.phrase !== this.lastPhrase) {
      this.lastPhrase = clock.phrase;
      this.broadcast("tala", this.config.sourceTala);
      this.broadcast("phraselength", [this.config.phraseBars]);
    }
    const sourceStep =
      (clock.bar % this.config.phraseBars) * 16 +
      Math.min(
        15,
        Math.floor((clock.tickInBar / clock.meter.pulsesPerBar) * 16),
      );
    if (sourceStep === this.lastSourceStep) return;
    this.lastSourceStep = sourceStep;
    const mask = this.sections.get(this.section)?.pattern[sourceStep] || 0,
      accent =
        this.config.velocityCycle[
          sourceStep % this.config.velocityCycle.length
        ];
    // (Written on its step of the bar's sixteen, a step long, wherever its tick falls.)
    if (mask) writtenOnStep(this.audio, clock.tick - (clock.tickInBar || 0), clock.meter.pulsesPerBar, 16, sourceStep % 16, () => {
      if (mask & 8) this.audio.houseDrum("kick", accent);
      if (mask & 4) this.audio.houseDrum("snare", accent);
      if (mask & 2) this.audio.houseDrum("closedHat", accent);
      if (mask & 1) this.audio.houseDrum("openHat", accent);
    });
  }
}

export class PercBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.percBeat;
    this.phraseBars = weightedChoice(
      this.config.phraseLengths,
      this.config.phraseWeights,
    );
    const [low, high] = this.config.formRandomRange;
    this.formPhrases = low + randomInt(high - low);
    this.amplitudes = Array.from({ length: 3 }, (_, index) =>
      Math.round(((index + 1) * this.config.amplitudeWalk.range) / 4),
    );
    this.delays = [2, 6, 10];
    this.patterns = [];
    this.lastLocalPhrase = -1;
  }
  onMessage(message) {
    super.onMessage(message);
    if (
      (message.address.endsWith("/hdensity") ||
        message.address.endsWith("/density")) &&
      !message.address.endsWith("/vdensity")
    ) {
      const value = Number(message.args.at(-1));
      if (Number.isFinite(value))
        this.density = Math.max(0, Math.min(1, value));
    }
    if (message.address.endsWith("/phraselength")) {
      const value = Number(message.args.at(-1));
      if (Number.isInteger(value) && value > 0)
        this.pendingPhraseBars = Math.min(64, value);
    }
    if (message.address.endsWith("/phrases")) {
      const value = Number(message.args.at(-1));
      if (Number.isInteger(value) && value > 0)
        this.formPhrases = Math.min(256, value);
    }
  }
  generatePatterns(clock, localPhrase) {
    if (this.pendingPhraseBars) {
      this.phraseBars = this.pendingPhraseBars;
      this.pendingPhraseBars = null;
    }
    const steps = clock.meter.pulsesPerBar * this.phraseBars,
      [minimum, maximum] = this.config.densityMaskRange,
      maskDensity = minimum + this.density * (maximum - minimum);
    this.partState = this.config.voiceDensityScale.map((_, index) =>
      this.instanceAllows(
        { bar: localPhrase, group: index },
        index,
        0.55 + this.density * 0.4,
      ),
    );
    if (!this.partState.some(Boolean)) this.partState[localPhrase % 3] = true;
    this.patterns = this.config.voiceDensityScale.map((scale) => {
      const onsets = randomDupleOnsets(steps),
        count = Math.max(1, Math.round(onsets.length * maskDensity * scale)),
        cycle = cyclicPattern({ steps, clave: onsets.slice(0, count) }),
        first = Math.min(...onsets);
      if (Number.isFinite(first)) cycle[first] = 1;
      return cycle;
    });
    this.lastSourceStep = -1;
  }
  onTick(
    tick,
    clock,
  ) {
    const localPhrase = Math.floor(clock.bar / this.phraseBars),
      boundary = clock.barStart && clock.bar % this.phraseBars === 0;
    if (
      !this.patterns.length ||
      (boundary && localPhrase !== this.lastLocalPhrase)
    ) {
      this.lastLocalPhrase = localPhrase;
      this.generatePatterns(clock, localPhrase);
    }
    const sourceStep =
      (clock.bar % this.phraseBars) * clock.meter.pulsesPerBar +
      clock.tickInBar;
    if (sourceStep === this.lastSourceStep) return;
    this.lastSourceStep = sourceStep;
    for (let index = 0; index < 3; index++) {
      if (!this.partState[index] || !this.patterns[index]?.[sourceStep])
        continue;
      const amplitudeConfig = this.config.amplitudeWalk,
        delayConfig = this.config.delayWalk;
      this.amplitudes[index] = boundedDrunk(
        this.amplitudes[index],
        amplitudeConfig.range,
        amplitudeConfig.step,
      );
      this.delays[index] = boundedDrunk(
        this.delays[index],
        delayConfig.range,
        delayConfig.step,
      );
      const accent =
          amplitudeConfig.output[0] +
          (this.amplitudes[index] / (amplitudeConfig.range - 1)) *
            (amplitudeConfig.output[1] - amplitudeConfig.output[0]),
        phase =
          (sourceStep / Math.max(1, this.patterns[index].length) + index / 3) %
          1,
        cutoff =
          this.config.filterRange[0] *
          Math.pow(
            this.config.filterRange[1] / this.config.filterRange[0],
            phase * this.config.voiceCutoffScale[index],
          ),
        delay = 60 / (clock.bpm || bandTempo()),
        feedback =
          this.config.delayGainRange[0] +
          (this.delays[index] / (delayConfig.range - 1)) *
            (this.config.delayGainRange[1] - this.config.delayGainRange[0]);
      // (Written to its next stroke in its phrase's pattern, a beat at most.)
      writtenOn(this.audio, clock.tick, Math.min(clock.meter.subdivision || 1, toNextAttack(this.patterns[index], sourceStep, { ticks: this.patterns[index].length })), () => this.audio.modulatedPercussion(index, accent, {
        cutoff,
        delay,
        feedback,
      }));
    }
  }
}

export class PapPercBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.papPerc;
    this.density = this.config.rhythmDensity;
    this.densityLease = new FallbackControlLease(this.config.silenceBars);
    this.fallbackCurve = Array.from(
      { length: this.config.fallbackCurvePoints },
      () => unitRandom(),
    );
    this.lastSourceStep = -1;
    this.lastBoundaryBar = null;
  }
  onMessage(message) {
    super.onMessage(message);
    if (
      (message.address.endsWith("/hdensity") ||
        message.address.endsWith("/density")) &&
      !message.address.endsWith("/vdensity")
    ) {
      const value = Number(message.args.at(-1));
      if (Number.isFinite(value)) {
        this.density = Math.max(0, Math.min(1, value));
        this.densityLease.receive(this.density);
      }
    }
  }
  updateOwnership(clock) {
    if (!clock.barStart || clock.bar === this.lastBoundaryBar) return;
    if (this.lastBoundaryBar != null) {
      const owned = this.densityLease.advanceBoundary();
      if (
        owned &&
        (!this.wasFallback || clock.bar % this.config.silenceBars === 0)
      )
        this.fallbackCurve = Array.from(
          { length: this.config.fallbackCurvePoints },
          () => unitRandom(),
        );
      this.wasFallback = owned;
    }
    this.lastBoundaryBar = clock.bar;
  }
  activeDensity(clock) {
    if (!this.densityLease.ownsFallback) return this.density;
    const position =
      ((clock.bar % this.config.silenceBars) +
        clock.tickInBar / clock.meter.pulsesPerBar) /
      this.config.silenceBars;
    return Math.max(
      0,
      Math.min(1, interpolateControlPoints(this.fallbackCurve, position, true)),
    );
  }
  onTick(
    tick,
    clock,
  ) {
    this.updateOwnership(clock);
    const sourceStep = Math.min(
      15,
      Math.floor((clock.tickInBar / clock.meter.pulsesPerBar) * 16),
    );
    if (sourceStep === this.lastSourceStep && !clock.barStart) return;
    this.lastSourceStep = sourceStep;
    const density = this.activeDensity(clock),
      kickScale =
        (Math.exp(density * Math.log(this.config.kickDensityBase)) - 1) /
        (this.config.kickDensityBase - 1),
      probabilities = [
        this.config.kickProb[sourceStep] * kickScale,
        this.config.midProb[sourceStep] * density,
        this.config.noiseProb[sourceStep] * density,
      ];
    // The port's source step is the composed cell; its short percussion envelope is a separate performance choice.
    withScoreTime(this.audio,dividedInterval(tick-clock.tickInBar,clock.meter.pulsesPerBar,16,sourceStep),()=>{
      if (unitRandom() < probabilities[0])
        this.audio.papPercussion("kick", 0, density);
      if (unitRandom() < probabilities[1])
        this.audio.papPercussion("mid", sourceStep % 2, density);
      if (unitRandom() < probabilities[2])
        this.audio.papPercussion(
          "noise",
          randomInt(this.config.noiseBands.length),
          density,
        );
    });
  }
}

export class MhBeatBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.mhBeat;
    this.density = this.config.rhythmDensity;
    this.activity = this.config.activity;
    this.playing = true;
    this.stateUntilTick = null;
    this.lastSourceStep = -1;
  }
  onMessage(message) {
    super.onMessage(message);
    if (message.address.endsWith("/vdensity")) {
      const value = Number(message.args.at(-1));
      if (Number.isFinite(value))
        this.activity = Math.max(0, Math.min(1, value));
    }
  }
  stateDurationTicks(clock, playing) {
    const [minimum, maximum] = this.config.randomDurationRange,
      randomSeconds = minimum + unitRandom() * (maximum - minimum),
      activitySeconds =
        this.config.durationScaleSeconds *
        (playing ? this.activity : 1 - this.activity),
      ticksPerSecond = ((clock.bpm || bandTempo()) / 60) * clock.meter.subdivision;
    return Math.max(
      1,
      Math.round((activitySeconds + randomSeconds) * ticksPerSecond),
    );
  }
  onTick(
    tick,
    clock,
  ) {
    if (this.stateUntilTick == null)
      this.stateUntilTick = tick + this.stateDurationTicks(clock, true);
    if (tick >= this.stateUntilTick) {
      this.playing = !this.playing;
      this.stateUntilTick = tick + this.stateDurationTicks(clock, this.playing);
    }
    if (!this.playing) return;
    const barPosition = clock.bar % this.config.contourBars,
      sourceStep =
        barPosition * 16 +
        Math.min(
          15,
          Math.floor((clock.tickInBar / clock.meter.pulsesPerBar) * 16),
        );
    if (sourceStep === this.lastSourceStep) return;
    this.lastSourceStep = sourceStep;
    const busyness = Math.max(
        0,
        Math.min(1, this.density * Math.sqrt(this.activity)),
      ),
      contours = [
        this.config.kickContour,
        this.config.snareContour,
        this.config.cymbalContour,
      ],
      kinds = ["kick", "snare", "cymbal"];
    for (let index = 0; index < 3; index++) {
      const probability = (contours[index][sourceStep] / 100) * busyness;
      if (unitRandom() < probability)
        writtenOnStep(this.audio, clock.tick - (clock.tickInBar || 0), clock.meter.pulsesPerBar, 16, sourceStep % 16, () => this.audio.mhBeatDrum(kinds[index], 0.35 + 0.65 * busyness));
    }
  }
}

export class MhBeatsynthBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.mhBeatsynth;
    this.density = this.config.rhythmDensity;
    this.now = () => Date.now();
    this.densityLease = new StaleValueLease(this.config.staleValueMs, () =>
      this.now(),
    );
    this.sequence = [];
    this.sequenceIndex = 0;
    this.lastBar = null;
    this.fallbackFrom = this.density;
    this.fallbackTarget = this.density;
    this.fallbackStart = 0;
    this.fallbackEnd = 0;
    this.generateSequence();
  }
  generateSequence() {
    const [low, high] = this.config.sequenceUnitRange,
      units = low + randomInt(high - low);
    this.sequence = [];
    for (let unit = 0; unit < units; unit++) {
      const row =
        this.config.patternRows[randomInt(this.config.generatedRowCount)];
      this.sequence.push(...row.map((cell) => cell && [...cell]));
    }
    const firstActive = this.sequence.findIndex(Boolean);
    if (firstActive > 0)
      this.sequence = [
        ...this.sequence.slice(firstActive),
        ...this.sequence.slice(0, firstActive),
      ];
    this.sequenceIndex = 0;
    return this.sequence;
  }
  onMessage(message) {
    super.onMessage(message);
    if (!message.address.endsWith("/hdensity")) return;
    const sender = typeof message.args[0] === "string" ? message.args[0] : "";
    if (sender === "mhBeatsynthBOT" || sender === this.instanceId) return;
    const value = Number(message.args.at(-1));
    if (this.densityLease.receive(value))
      this.density = Math.max(0, Math.min(1, value));
  }
  densityGate() {
    return randomProductGate(
      this.density,
      this.config.gateLeftRange,
      this.config.gateRightRange,
    );
  }
  updateFallback(at) {
    if (!this.densityLease.update(at)) return;
    if (at >= this.fallbackEnd) {
      this.fallbackFrom = this.density;
      const [targetLow, targetHigh] = this.config.fallbackTargetRange;
      this.fallbackTarget =
        (targetLow + randomInt(targetHigh - targetLow)) / 100;
      const [rampLow, rampHigh] = this.config.fallbackRampMsRange;
      this.fallbackStart = at;
      this.fallbackEnd = at + rampLow + randomInt(rampHigh - rampLow);
    }
    const phase = Math.max(
      0,
      Math.min(
        1,
        (at - this.fallbackStart) /
          Math.max(1, this.fallbackEnd - this.fallbackStart),
      ),
    );
    this.density =
      this.fallbackFrom + (this.fallbackTarget - this.fallbackFrom) * phase;
    this.send("/broadcast/hdensity", ["mhBeatsynthBOT", this.density]);
  }
  onTick(
    tick,
    clock,
  ) {
    this.updateFallback(this.now());
    if (
      !clock.barStart ||
      clock.bar === this.lastBar ||
      (this.lastBar != null && !this.densityGate())
    )
      return;
    this.lastBar = clock.bar;
    const cell = this.sequence[this.sequenceIndex++];
    if (cell)
      for (const voice of cell)
        writtenOn(this.audio, clock.tick, clock.meter?.pulsesPerBar, () => this.audio.mhBeatsynth(voice, 0.4 + 0.6 * this.density, this.config));
    if (this.sequenceIndex >= this.sequence.length) {
      if (randomInt(3) === 0) this.generateSequence();
      else this.sequenceIndex = 0;
    }
  }
}

export class SampleBeatBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.sampleBeat;
    this.notes = this.openingPool(this.config.openingRegister);
    this.poolKey = "";
    this.resonanceNote = 48;
    this.lastSourceStep = -1;
    this.lastBar = null;
    this.barsOnLoop = 0;
    this.chooseLoopAfter = this.nextLoopLength();
    this.resonatorPreset = randomInt(this.config.resonatorGainPresets.length);
    this.adoptNotePool(this.notes);
  }
  nextLoopLength() {
    const [low, high] = this.config.sampleChangeBarsRange;
    return low + randomInt(high - low);
  }
  resonanceCandidates(values) {
    const pitchClasses = [
      ...new Set(values.map(pitchClass).filter((value) => value !== null)),
    ].sort((a, b) => a - b);
    if (pitchClasses.length) pitchClasses.push(pitchClasses[0]);
    return pitchClasses;
  }
  adoptNotePool(values) {
    const notes = values.map(Number).filter(Number.isFinite),
      key = JSON.stringify(notes);
    if (!notes.length || key === this.poolKey) return false;
    this.poolKey = key;
    const pitchClasses = this.resonanceCandidates(notes);
    this.resonanceNote = 48 + pitchClasses[randomInt(pitchClasses.length)];
    return true;
  }
  onMessage(message) {
    super.onMessage(message);
    if (message.address.endsWith("/notepool")) this.adoptNotePool(message.args);
  }
  chooseNewLoop() {
    this.barsOnLoop = 0;
    this.chooseLoopAfter = this.nextLoopLength();
    this.resonatorPreset = randomInt(this.config.resonatorGainPresets.length);
  }
  onTick(
    tick,
    clock,
  ) {
    if (clock.barStart && clock.bar !== this.lastBar) {
      if (this.lastBar != null && ++this.barsOnLoop > this.chooseLoopAfter)
        this.chooseNewLoop();
      this.lastBar = clock.bar;
    }
    const sourceStep = Math.min(
      this.config.sourceSteps - 1,
      Math.floor(
        (clock.tickInBar / Math.max(1, clock.meter.pulsesPerBar)) *
          this.config.sourceSteps,
      ),
    );
    if (sourceStep === this.lastSourceStep && !clock.barStart) return;
    this.lastSourceStep = sourceStep;
    writtenOnStep(this.audio, clock.tick - (clock.tickInBar || 0), clock.meter.pulsesPerBar, this.config.sourceSteps, sourceStep, () => this.audio.sampleBeatLoop(
      this.resonanceNote,
      sourceStep,
      0.7,
      this.config,
      this.resonatorPreset,
    ));
  }
}

export class AutechreBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.autechre;
    this.phraseCurve = [];
    this.patterns = { kick: [], snare: [], hat: [] };
    this.voiceCurves = {};
    this.subdivision = this.config.initialSubdivision;
    this.drunkSubdivision = this.subdivision - this.config.subdivisionOffset;
    this.lastBar = null;
    this.lastPhrase = null;
    this.lastDensityBroadcastAt = null;
    this.now = () => Date.now();
    this.generateVoiceCurves();
    this.generatePhrase();
  }
  generateVoiceCurves() {
    for (const [voice, [low, high]] of Object.entries(
      this.config.voiceDensityKneeRanges,
    )) {
      const x = low + unitRandom() * (high - low),
        [yLow, yHigh] = this.config.densityKneeOutputRange,
        y = yLow + unitRandom() * (yHigh - yLow);
      this.voiceCurves[voice] = [
        { x: 0, y: 0 },
        { x, y },
        { x: 1, y: 1 },
      ];
    }
  }
  generatePhrase() {
    const config = this.config;
    this.tala = randomAdditiveGrouping(
      config.sourceSteps,
      config.additiveParts,
    );
    const starts = additiveGroupStarts(this.tala, config.sourceSteps);
    this.patterns.kick = [starts[0], ...scramble(starts.slice(1))];
    this.patterns.snare = scramble(
      starts.map((value) => (value + 1) % config.sourceSteps),
    );
    this.patterns.hat = scramble(
      Array.from({ length: config.sourceSteps }, (_, index) => index),
    );
    this.phraseCurve = randomFivePointCurve({
      xRanges: config.phraseCurveXRanges,
      terminalWeights: config.phraseCurveTerminalWeights,
    });
  }
  updateSubdivision() {
    const config = this.config;
    if (unitRandom() >= config.subdivisionChangeChance) return false;
    if (unitRandom() < config.forceSixteenthsChance) this.subdivision = 16;
    else {
      this.drunkSubdivision = boundedDrunk(
        this.drunkSubdivision,
        config.subdivisionDrunkRange,
        config.subdivisionDrunkStep,
      );
      this.subdivision = this.drunkSubdivision + config.subdivisionOffset;
    }
    this.broadcast("subdivision", [this.subdivision]);
    return true;
  }
  densityAt(position) {
    return Math.max(
      0,
      Math.min(1, interpolateCurvePoints(this.phraseCurve, position)),
    );
  }
  activeOnsets(voice, density) {
    const pattern = this.patterns[voice],
      amount = interpolateCurvePoints(this.voiceCurves[voice], density),
      count = Math.max(
        0,
        Math.min(pattern.length, Math.trunc(pattern.length * amount)),
      );
    return pattern.slice(0, count);
  }
  scheduleBar(clock) {
    const meter = clock.meter,
      barDuration =
        ((60 / (clock.bpm || bandTempo())) * meter.numerator * 4) / meter.denominator,
      phraseBar =
        ((clock.bar % (meter.phraseBars || this.config.phraseBars)) +
          (meter.phraseBars || this.config.phraseBars)) %
        (meter.phraseBars || this.config.phraseBars),
      phraseBars = meter.phraseBars || this.config.phraseBars,
      effects = {
        sampleRate:
          this.config.degradeSampleRateRange[0] +
          unitRandom() *
            (this.config.degradeSampleRateRange[1] -
              this.config.degradeSampleRateRange[0]),
        bits:
          this.config.degradeBitsRange[0] +
          unitRandom() *
            (this.config.degradeBitsRange[1] - this.config.degradeBitsRange[0]),
        wet:
          this.config.delayWetRange[0] +
          unitRandom() *
            (this.config.delayWetRange[1] - this.config.delayWetRange[0]),
        delaySeconds: barDuration / this.config.sourceSteps,
      };
    let densityForMessage = 0;
    for (const voice of ["kick", "snare", "hat"]) {
      let onsets = this.activeOnsets(
        voice,
        this.densityAt(phraseBar / phraseBars),
      );
      if (clock.bar === 0 && voice === "kick" && !onsets.includes(0))
        onsets = [0, ...onsets];
      for (const onset of onsets) {
        const raw = onset / this.config.sourceSteps,
          quantized = Math.round(raw * this.subdivision) / this.subdivision,
          phrasePosition = (phraseBar + quantized) / phraseBars,
          density = this.densityAt(phrasePosition),
          accent = 0.35 + 0.65 * density;
        densityForMessage = Math.max(densityForMessage, density);
        // (Written where it is quantized to: its share of the bar on its own grid, a cell long.)
        const cell = Math.round(raw * this.subdivision);
        const barTick = barTickOf(clock);
        writtenOn(this.audio, barTick == null ? null : new Rational(cell * meter.pulsesPerBar, this.subdivision).add(barTick), new Rational(meter.pulsesPerBar, this.subdivision), () => this.audio.autechreDrum(
          voice,
          accent,
          effects,
          Math.max(0, quantized * barDuration),
        ));
      }
    }
    const now = this.now();
    if (
      this.lastDensityBroadcastAt == null ||
      now - this.lastDensityBroadcastAt >= this.config.densityBroadcastMinMs
    ) {
      this.lastDensityBroadcastAt = now;
      this.broadcast("hdensity", [
        Math.round(densityForMessage / this.config.densityBroadcastResolution) *
          this.config.densityBroadcastResolution,
      ]);
    }
  }
  onTick(
    tick,
    clock,
  ) {
    if (!clock.barStart || clock.bar === this.lastBar) return;
    if (clock.phraseStart && clock.phrase !== this.lastPhrase) {
      this.lastPhrase = clock.phrase;
      this.generatePhrase();
    }
    this.lastBar = clock.bar;
    this.updateSubdivision();
    this.scheduleBar(clock);
  }
}

export class ProckRockBeadsBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.prockRock;
    this.current = this.initialIntent();
    this.next = null;
    this.received = new Map();
    this.lastPhrase = -1;
    this.lastSourceStep = -1;
    this.stepsSinceTala = 0;
    this.register = 0;
  }
  initialIntent() {
    const c = this.config;
    return {
      activityMask: [...c.activityMask],
      repetitionStructure: [...c.repetitionStructure],
      talaStructure: [...c.talaStructure],
      contourA: [...c.contourA],
      iFollow: null,
      synchro: c.synchro,
    };
  }
  onMessage(message) {
    super.onMessage(message);
    const intent = parseCompoundIntent(message);
    if (
      intent &&
      intent.sender &&
      intent.sender !== this.instanceId &&
      intent.sender !== "ob_prockRockBeadsBot"
    )
      this.received.set(intent.sender, intent);
  }
  publish() {
    this.broadcast(
      "intent",
      serializeIntentFields("ob_prockRockBeadsBot", this.current),
    );
  }
  plan() {
    const intents = [...this.received.values()];
    this.next = {
      ...this.current,
      activityMask: [...this.current.activityMask],
      repetitionStructure: [...this.current.repetitionStructure],
      talaStructure: [...this.current.talaStructure],
      contourA: [...this.current.contourA],
    };
    if (intents.length > 1) {
      const sync = intents
        .map((value) => value.synchro)
        .filter(Number.isFinite);
      if (sync.length)
        this.next.synchro = sync.reduce((a, b) => a + b, 0) / sync.length;
      const votes = new Map();
      for (const value of intents)
        if (value.iFollow)
          votes.set(value.iFollow, (votes.get(value.iFollow) || 0) + 1);
      const leader = [...votes].sort((a, b) => b[1] - a[1])[0];
      if (leader?.[1] >= this.config.minimumFollowVotes)
        this.next.iFollow = leader[0];
      if (unitRandom() < this.config.followChance)
        this.next.iFollow = intents[randomInt(intents.length)].sender;
      const followed = this.received.get(this.next.iFollow);
      if (followed?.contourA) this.next.contourA = [...followed.contourA];
      if (followed?.talaStructure?.length)
        this.next.talaStructure = [...followed.talaStructure];
    }
    this.received.clear();
  }
  talaStarts() {
    const starts = new Set([0]);
    let total = 0;
    for (const part of this.next?.talaStructure || []) {
      total += part;
      starts.add(total);
    }
    return starts;
  }
  onTick(
    tick,
    clock,
  ) {
    const bars = clock.meter.phraseBars || bandPhraseBars(),
      phrase = Math.floor(clock.bar / bars),
      phraseBar = ((clock.bar % bars) + bars) % bars,
      sourceStep = Math.min(
        255,
        Math.floor((clock.tickInBar / clock.meter.pulsesPerBar) * 64) +
          phraseBar * 64,
      );
    if (phrase !== this.lastPhrase) {
      if (this.next) this.current = this.next;
      this.next = null;
      this.lastPhrase = phrase;
      this.lastSourceStep = -1;
      this.stepsSinceTala = 0;
    }
    if (sourceStep === 64 && this.lastSourceStep < 64) this.publish();
    if (sourceStep === 192 && this.lastSourceStep < 192) this.plan();
    if (sourceStep % 32 === 0 && sourceStep !== this.lastSourceStep)
      this.register +=
        this.current.contourA[Math.floor(sourceStep / 32)] === "U" ? 1 : -1;
    if (sourceStep % 2 === 0 && sourceStep !== this.lastSourceStep) {
      const maskIndex = Math.floor(sourceStep / 16),
        activity = Math.trunc((this.current.activityMask[maskIndex] || 0) / 3);
      if (activity > 0) {
        const eighth = Math.floor(sourceStep / 4),
          isTala = this.talaStarts().has(eighth);
        this.stepsSinceTala = isTala ? 0 : this.stepsSinceTala + 1;
        // (Written on its step of the bar's thirty-two (its sixty-four, in twos), a step long.)
        writtenOnStep(this.audio, clock.tick - (clock.tickInBar || 0), clock.meter.pulsesPerBar, 32, (sourceStep % 64) >> 1, () => this.audio.prockRockDrum(this.stepsSinceTala, activity));
      }
    }
    this.lastSourceStep = sourceStep;
  }
}

export class XDrumBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.xDrum;
    this.enabled = true;
    this.exiting = false;
    this.section = "A";
    this.sections = new Map();
    this.lastStep = -1;
    // Its first pattern for the band's opening meter, drawn from the piece's seed (shared/opening-time.js).
    this.generate(this.bandTime.meter);
  }
  generate(meter = {}) {
    const c = this.config,
      numerator = Math.max(1, meter.numerator || this.bandTime.meter.numerator),
      // Its grouping drawn for every bar length: no cell of its own (the owner, 1 October 2026: "no fixed rhythm cells").
      tala = randomAdditiveGrouping(numerator, c.additiveParts),
      starts = additiveGroupStarts(tala, numerator),
      map = (value) =>
        Math.min(
          c.sourceSteps - 1,
          Math.floor((value / numerator) * c.sourceSteps),
        ),
      base = [...new Set(starts.map(map))],
      amount = (scale = 0.5) =>
        Math.max(
          1,
          Math.round(
            (c.voiceDensityRange[0] +
              this.density *
                (c.voiceDensityRange[1] - c.voiceDensityRange[0])) *
              c.sourceSteps *
              scale,
          ),
        );
    this.patterns = {
      kick: scramble(base).slice(0, amount(0.7)),
      snare: scramble([
        ...new Set([4, 12, ...base.map((value) => (value + 4) % 16)]),
      ]).slice(0, amount(0.55)),
      hihat: scramble([...Array(16).keys()]).slice(0, amount(1)),
    };
    if (!this.patterns.kick.includes(0)) this.patterns.kick.unshift(0);
    this.tala = tala;
    this.sections.set(this.section, {
      tala: [...tala],
      patterns: Object.fromEntries(
        Object.entries(this.patterns).map(([key, value]) => [key, [...value]]),
      ),
    });
    this.broadcast("tala", tala);
  }
  selectSection(value, meter) {
    this.section = String(value || "A");
    const cached = this.sections.get(this.section);
    if (cached) {
      this.tala = [...cached.tala];
      this.patterns = Object.fromEntries(
        Object.entries(cached.patterns).map(([key, row]) => [key, [...row]]),
      );
      this.broadcast("tala", this.tala);
    } else this.generate(meter);
  }
  // Its first pattern for the bar it plays, as the piece begins (the band's opening until then): its pulses, as the
  // original began on a bar of sixteen, at most its source steps.
  onPrepare(clock = {}) {
    const pulses = (clock.meter?.numerator || 0) * (clock.meter?.subdivision || 1);
    if (pulses) this.generate({ numerator: Math.min(this.config.sourceSteps, pulses) });
    return super.onPrepare(clock);
  }
  onMessage(message) {
    super.onMessage(message);
    if (message.address.endsWith("/density")) {
      const value = Number(message.args.at(-1));
      if (Number.isFinite(value))
        this.density = Math.max(0, Math.min(1, value));
    }
    if (message.address.endsWith("/onoff"))
      this.enabled = Number(message.args.at(-1)) !== 0;
    if (message.address.endsWith("/initialize"))
      this.generate(this.requestedMeter || this.currentClock?.meter || this.bandTime.meter);
    // /broadcast/section is [section, form length] (docs/MUSEBOT_PROTOCOL.md), and the
    // section is the FIRST argument. Reading the last one is only right for
    // ae_xProducerBOT, which sends the section alone; under mh_PlexBOT it read
    // the form's length -- a constant -- so this bot never saw a section change.
    if (message.address.endsWith("/section"))
      this.selectSection(
        message.args[0],
        this.requestedMeter || this.currentClock?.meter || this.bandTime.meter,
      );
    if (message.address.endsWith("/exiting"))
      this.exiting = Number(message.args.at(-1)) !== 0;
  }
  onTick(
    tick,
    clock,
  ) {
    if (!this.enabled || this.exiting) return;
    const step = Math.min(
      15,
      Math.floor(
        ((clock.tickInBar || 0) / Math.max(1, clock.meter.pulsesPerBar)) * 16,
      ),
    );
    if (step === this.lastStep) return;
    this.lastStep = step;
    const accent = 0.35 + 0.65 * this.density;
    withScoreTime(this.audio,dividedInterval(tick-(clock.tickInBar||0),clock.meter.pulsesPerBar,16,step),()=>{
      if (this.patterns.kick.includes(step)) this.audio.houseDrum("kick", accent);
      if (this.patterns.snare.includes(step))
        this.audio.houseDrum("snare", accent);
      if (this.patterns.hihat.includes(step))
        this.audio.houseDrum("closedHat", accent);
    });
  }
}

export class XPercBot extends PercBot {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.xPerc;
    this.phraseBars = 8;
    this.section = "A";
    this.sections = new Map();
    this.subpattern = [...this.config.defaultSubpattern];
    this.enabled = true;
    this.exiting = false;
  }
  onMessage(message) {
    super.onMessage(message);
    if (message.address.endsWith("/subpattern")) {
      const values = message.args.filter(
        (value) => typeof value === "string" && !value.includes("BOT"),
      );
      if (values.length) this.subpattern = values;
    }
    // /broadcast/section is [section, form length] (docs/MUSEBOT_PROTOCOL.md), and the
    // section is the FIRST argument. Reading the last one is only right for
    // ae_xProducerBOT, which sends the section alone; under mh_PlexBOT it read
    // the form's length -- a constant -- so this bot never saw a section change.
    if (message.address.endsWith("/section")) {
      this.section = String(message.args[0] || "A");
      const cached = this.sections.get(this.section);
      if (cached) this.patterns = cached.map((row) => [...row]);
      else this.patterns = [];
    }
    if (message.address.endsWith("/initialize")) this.patterns = [];
    if (message.address.endsWith("/onoff"))
      this.enabled = Number(message.args.at(-1)) !== 0;
    if (message.address.endsWith("/exiting"))
      this.exiting = Number(message.args.at(-1)) !== 0;
  }
  generatePatterns(clock, localPhrase) {
    if (this.sections.has(this.section)) {
      this.patterns = this.sections.get(this.section).map((row) => [...row]);
      this.lastSourceStep = -1;
      return;
    }
    super.generatePatterns(clock, localPhrase);
    const bars = this.subpattern.length,
      perBar = clock.meter.pulsesPerBar,
      source = this.patterns.map((row) => {
        const fragments = new Map();
        return Array.from({ length: bars * perBar }, (_, index) => {
          const bar = Math.floor(index / perBar),
            label = this.subpattern[bar % bars];
          if (!fragments.has(label))
            fragments.set(label, row.slice(bar * perBar, (bar + 1) * perBar));
          return fragments.get(label)[index % perBar] || 0;
        });
      });
    this.patterns = source;
    this.sections.set(
      this.section,
      source.map((row) => [...row]),
    );
  }
  onTick(tick, clock) {
    if (this.enabled && !this.exiting) super.onTick(tick, clock);
  }
}
