// The harmony bots: the modal, Miles, swing, Metheny, Mozart and x-suite chords, and HarmonyPulse.
// Moved verbatim from public/agents.js in its per-family split (28 September 2026; RESEARCH_BACKLOG, the second
// queue). agents.js registers them (BOT_REGISTRY) and re-exports each, so an import from it is as it was.
import { Agent } from "../../framework/index.js";
import { STOCHASTIC_CONFIG as CONFIG } from "../../stochastic-config.js";
import {
  corpusInitialShape, corpusNextChord, normalizeProbabilityVector, observedDuration, parseChordPlan, transposeChord,
  weightedPitchClass,
} from "../../shared/harmony.js";
import { pitchClass } from "../../shared/pitch.js";
import { randomInt, scramble, weightedChoice } from "../../shared/stochastic.js";
import { voiceLeadChord } from "../../shared/musicality.js";
import { phrasePlanWindow } from "./helpers.js";
import {bandPhraseBars,bandTempo,bandMeter} from '../../shared/opening-time.js';
import {ScoreEvents} from '../../shared/score-time.js';
import {writtenOn} from "../lib/written.js";

export class ModalChordBot extends Agent {
  constructor(...args) {
    super(...args);
    this.sections = [];
    this.phrase = -1;
    // Its mode's root: the key it was built in, preferred but not always taken (shared/opening-harmony.js).
    this.modeRoot = this.preferredTonic(CONFIG.modal.baseMidi);
    this.progression = this.generateProgression();
  }
  generateProgression() {
    const config = CONFIG.modal,
      mode = config.modePitchClasses,
      count = Math.min(
        mode.length,
        weightedChoice(config.chordCounts, config.chordCountWeights),
      ),
      progression = [],
      bassline = scramble([...mode.keys()]).slice(0, count);
    for (const degree of bassline) {
      const root = this.modeRoot + mode[degree],
        third =
          this.modeRoot +
          mode[(degree + 2) % mode.length] +
          (degree + 2 >= mode.length ? 12 : 0),
        fifth =
          this.modeRoot +
          mode[(degree + 4) % mode.length] +
          (degree + 4 >= mode.length ? 12 : 0);
      progression.push([root, third, fifth, root + config.extensionSemitones]);
    }
    if (this.sections.length < config.sectionCapacity)
      this.sections.push(progression);
    return progression;
  }
  chooseProgression() {
    const config = CONFIG.modal,
      createNew =
        this.sections.length < 2 ||
        weightedChoice([true, false], config.newVersusRecallWeights);
    this.progression = createNew
      ? this.generateProgression()
      : this.sections[randomInt(this.sections.length)];
  }
  onMessage(message) {
    super.onMessage(message);
    if (
      message.address.endsWith("/density") &&
      Number(message.args.at(-1)) > 0.82
    )
      this.chooseProgression();
  }
  onTick(
    tick,
    clock,
  ) {
    if (!clock.barStart) return;
    const phrase = clock.phrase;
    if (phrase !== this.phrase) {
      this.phrase = phrase;
      if (
        phrase > 0 &&
        phrase % CONFIG.modal.minimumPhrasesBetweenChanges === 0
      )
        this.chooseProgression();
      this.publishPlan(
        "harmony",
        {
          schemaVersion: 1,
          chords: this.progression.map((chord) => [...chord]),
          durations: this.progression.map(
            () => CONFIG.modal.chordDurationBeats,
          ),
        },
        {
          ...phrasePlanWindow(clock),
          confidence: 0.72,
          priority: 0.55,
          rationale:
            "Share the complete current modal progression atomically so other agents can plan against it.",
        },
      );
    }
    const chord = this.progression[clock.bar % this.progression.length];
    this.broadcast("notepool", chord);
    this.broadcast(
      "pcprob",
      CONFIG.modal.chordProbabilities.slice(0, chord.length),
    );
    this.broadcast(
      "plan/chords",
      this.progression.map((chord) => chord.join(" ")),
    );
    this.broadcast(
      "plan/chordDuration",
      this.progression.map(() => CONFIG.modal.chordDurationBeats),
    );
    // (Its bar's chord, written for the bar: lib/written.js.)
    writtenOn(this.audio, clock.tick, clock.meter?.pulsesPerBar, () => this.audio.chord(chord)); // optional monitor: the original is silent
  }
}

export class MilesChordBot extends Agent {
  constructor(...args) {
    super(...args);
    // Until its corpus loads: the band's opening chord, drawn from the piece's seed.
    this.progression = [[...this.bandOpening.chord]];
    this.phrase = -1;
  }
  async start() {
    const response = await fetch("./data/miles-harmony.json");
    this.corpus = await response.json();
    this.generateCorpusProgression();
  }
  chordNotes(shape, root) {
    return shape
      .split("_")
      .map(Number)
      .map((interval) => 60 + root + interval);
  }
  generateCorpusProgression() {
    if (!this.corpus) return;
    const shapes = Object.keys(this.corpus),
      initial = weightedChoice(
        shapes,
        shapes.map((shape) => this.corpus[shape].initial || 0),
      );
    let shape = initial;
    this.progression = [];
    for (let i = 0; i < 4; i++) {
      const record = this.corpus[shape],
        transitions = Object.entries(record).filter(
          ([key, value]) =>
            key.endsWith(">") && !key.startsWith(">") && Array.isArray(value),
        );
      if (!transitions.length) break;
      const [key, rootWeights] = weightedChoice(
        transitions,
        transitions.map(([, weights]) => weights.reduce((a, b) => a + b, 0)),
      );
      const root = weightedChoice([...Array(12).keys()], rootWeights);
      shape = key.slice(0, -1);
      this.progression.push(this.chordNotes(shape, root));
    }
    if (!this.progression.length)
      this.progression = [this.chordNotes(initial, this.bandOpening.root)];
  }
  onTick(
    tick,
    clock,
  ) {
    if (!clock.barStart) return;
    const phrase = clock.phrase;
    if (phrase !== this.phrase) {
      this.phrase = phrase;
      this.generateCorpusProgression();
      this.publishPlan(
        "harmony",
        {
          schemaVersion: 1,
          chords: this.progression.map((chord) => [...chord]),
          // Repeated to the progression's length rather than sliced to it. Also defensive:
          // with four chords, `slice(0, 4)` and the repeat agree exactly. `slice` would
          // shorten a longer progression's durations and leave a shorter one mismatched.
          durations: this.progression.map((_, index) => [1, 1, 2, 2][index % 4]),
        },
        {
          ...phrasePlanWindow(clock),
          confidence: 0.7,
          priority: 0.55,
          rationale:
            "Share the generated corpus progression atomically for ensemble anticipation.",
        },
      );
    }
    const chord = this.progression[clock.bar % this.progression.length];
    this.broadcast("notepool", chord);
    this.broadcast("pcprob", [0.95, 0.7, 0.85, 0.65]);
    // **Joined, not flattened.** `.flat()` published the progression as loose notes:
    // `parseChordPlan` splits each argument on spaces, so a bare number is a chord of one note.
    // The vendored corpus holds 20 shapes of three to six intervals, mean 4.65, and the
    // generator always builds exactly four chords — so consumers saw 12 to 24 single-note
    // chords, typically 19, where there were four. Each offered one pitch instead of three to
    // six, and the paired `chordDuration` list of four entries was then the wrong length, so
    // `BowedBot`, `DroneBot` and `PadBot` all discarded it on their
    // `chordDurations.length === chords.length` gate and divided the phrase evenly instead.
    // `ModalChordBot` and `SwingChordBot` both already joined; this was the only publisher
    // that did not. See research/upstream-ports/miles-chord.md.
    this.broadcast(
      "plan/chords",
      this.progression.map((chord) => chord.join(" ")),
    );
    // And a duration per chord, whatever the progression's length. Defensive rather than
    // behavioural: the generator always builds four chords, so this list and the literal
    // `[1, 1, 2, 2]` it replaces are identical today. It matters only if the progression length
    // ever changes, and then it matters a lot, because a mismatched list is discarded by exactly
    // the gate above.
    const swing = [1, 1, 2, 2];
    this.broadcast(
      "plan/chordDuration",
      this.progression.map((_, index) => swing[index % swing.length]),
    );
    // (Its bar's chord, written for the bar: lib/written.js.)
    writtenOn(this.audio, clock.tick, clock.meter?.pulsesPerBar, () => this.audio.chord(chord)); // optional monitor: the original is silent
  }
}

export class SwingChordBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = this.configuration();
    this.harmony = null;
    this.melody = null;
    this.phraseBars = this.config.initialPhraseBars;
    this.harmonicRhythm = this.config.harmonicRhythm;
    this.sections = new Map();
    this.section = "A";
    this.progression = [];
    this.lastPhrase = -1;
    this.lastChord = -1;
  }
  configuration() {
    return CONFIG.swingChord;
  }
  corpusPaths() {
    return [
      "./data/swing-standards-harmony.json",
      "./data/swing-standards-melody.json",
    ];
  }
  async start() {
    const [harmony, melody] = await Promise.all(
      this.corpusPaths().map((path) =>
        fetch(path).then((response) => response.json()),
      ),
    );
    this.harmony = harmony;
    this.melody = melody;
    this.generateProgression();
  }
  onMessage(message) {
    super.onMessage(message);
    if (message.address.endsWith("/phraselength")) {
      const value = Math.round(Number(message.args.at(-1)));
      if (value > 0) this.phraseBars = Math.min(128, value);
    }
    if (
      message.address.endsWith("/harmrhythm") ||
      message.address.endsWith("/harmonicrhythm")
    ) {
      const value = Number(message.args.at(-1));
      if (this.config.allowedHarmonicRhythms.includes(value))
        this.harmonicRhythm = value;
    }
    // /broadcast/section is [section, form length] (docs/MUSEBOT_PROTOCOL.md), and the
    // section is the FIRST argument. Reading the last one is only right for
    // ae_xProducerBOT, which sends the section alone; under mh_PlexBOT it read
    // the form's length -- a constant -- so this bot never saw a section change.
    if (message.address.endsWith("/section")) {
      const label = String(message.args[0] || "A");
      this.section = label;
      if (this.sections.has(label))
        this.progression = this.sections
          .get(label)
          .map((item) => ({
            ...item,
            chord: [...item.chord],
            probabilities: [...item.probabilities],
          }));
      else {
        this.generateProgression();
        this.sections.set(
          label,
          this.progression.map((item) => ({
            ...item,
            chord: [...item.chord],
            probabilities: [...item.probabilities],
          })),
        );
      }
      this.publishPlan();
    }
  }
  // With no corpus chord to start from: the band's opening chord, drawn from the piece's seed, its classes the melody's.
  openingItem(duration) {
    const chord = [...this.bandOpening.chord],
      classes = new Set(chord.map((pitch) => ((Math.round(pitch) % 12) + 12) % 12));
    return {
      shape: chord.map((pitch) => +(pitch - chord[0]).toFixed(3)).join("_"),
      root: this.bandOpening.root,
      chord,
      duration,
      probabilities: Array.from({ length: 12 }, (_, pc) => (classes.has(pc) ? 1 : 0)),
    };
  }
  probabilities(shape, root) {
    const record = this.melody?.[shape] || {},
      weights = record.ngram || record.initial || [];
    return normalizeProbabilityVector(
      Array.from({ length: 12 }, (_, pc) => weights[(pc - root + 12) % 12]),
    );
  }
  generateProgression() {
    if (!this.harmony) return;
    const target = Math.max(
        1,
        this.phraseBars * this.config.beatsPerAssumedBar,
      ),
      items = [];
    let shape = corpusInitialShape(this.harmony),
      root = weightedPitchClass(this.harmony[shape]?.initial),
      duration = 0;
    while (duration < target && items.length < this.config.maximumChords) {
      const observed = observedDuration(this.harmony[shape], 1),
        beats = Math.min(target - duration, observed * this.harmonicRhythm),
        chord = transposeChord(shape, root, this.config.baseMidi);
      items.push({
        shape,
        root,
        chord,
        duration: beats,
        probabilities: this.probabilities(shape, root),
      });
      duration += beats;
      ({ shape, root } = corpusNextChord(this.harmony, shape));
    }
    this.progression = items.length
      ? items
      : [this.openingItem(target)];
  }
  publishPlan(clock) {
    if (!this.progression.length) return;
    this.broadcast(
      "plan/chords",
      this.progression.map((item) => item.chord.join(" ")),
    );
    this.broadcast(
      "plan/chordDuration",
      this.progression.map((item) => item.duration),
    );
    if (clock)
      super.publishPlan(
        "harmony",
        {
          schemaVersion: 1,
          chords: this.progression.map((item) => [...item.chord]),
          durations: this.progression.map((item) => item.duration),
          section: this.section,
        },
        {
          ...phrasePlanWindow(clock),
          confidence: 0.78,
          priority: 0.6,
          rationale:
            "Publish chords and durations as one future-plan snapshot while retaining the legacy paired messages.",
        },
      );
  }
  chordIndex(clock) {
    const position =
        (clock.bar % (clock.meter.phraseBars || this.phraseBars)) *
          this.config.beatsPerAssumedBar +
        (clock.beat || 0),
      durations = this.progression.map((item) => item.duration);
    let total = 0;
    for (let index = 0; index < durations.length; index++) {
      total += durations[index];
      if (position < total) return index;
    }
    return durations.length - 1;
  }
  onTick(
    tick,
    clock,
  ) {
    if (!this.harmony) return;
    if (clock.phraseStart && clock.phrase !== this.lastPhrase) {
      this.lastPhrase = clock.phrase;
      if (!this.sections.has(this.section)) {
        this.generateProgression();
        this.sections.set(
          this.section,
          this.progression.map((item) => ({
            ...item,
            chord: [...item.chord],
            probabilities: [...item.probabilities],
          })),
        );
      }
      this.publishPlan(clock);
      this.lastChord = -1;
    }
    if (!clock.beatStart && !clock.phraseStart) return;
    const index = this.chordIndex(clock);
    if (index === this.lastChord) return;
    this.lastChord = index;
    const item = this.progression[index];
    this.broadcast("notepool", item.chord);
    this.broadcast("pcprob", item.probabilities);
  }
}

export class MethenyChordBot extends SwingChordBot {
  configuration() {
    return CONFIG.methenyChord;
  }
  corpusPaths() {
    return ["./data/metheny-harmony.json", "./data/metheny-melody.json"];
  }
}

export class XChordBot extends SwingChordBot {
  configuration() {
    return CONFIG.xChord;
  }
  corpusPaths() {
    return ["./data/metheny-harmony.json", "./data/metheny-melody.json"];
  }
  constructor(...args) {
    super(...args);
    this.enabled = true;
    this.exiting = false;
  }
  onMessage(message) {
    super.onMessage(message);
    if (message.address.endsWith("/onoff"))
      this.enabled = Number(message.args.at(-1)) !== 0;
    if (message.address.endsWith("/initialize")) {
      this.generateProgression();
      this.publishPlan();
      this.lastChord = -1;
    }
    if (message.address.endsWith("/exiting"))
      this.exiting = Number(message.args.at(-1)) !== 0;
    if (
      message.address.endsWith("/section") ||
      message.address.endsWith("/phraselength")
    )
      this.broadcast("harmrhythm", [
        this.progression.length
          ? this.phraseBars / this.progression.length
          : this.harmonicRhythm,
      ]);
  }
  onTick(tick, clock) {
    if (this.enabled && !this.exiting) super.onTick(tick, clock);
  }
}

export class MozartChordBot extends SwingChordBot {
  configuration() {
    return CONFIG.mozartChord;
  }
  corpusPaths() {
    return ["./data/mozart-harmony.json", "./data/mozart-melody.json"];
  }
  constructor(...args) {
    super(...args);
    this.enabled = true;
  }
  onMessage(message) {
    super.onMessage(message);
    if (message.address.endsWith("/onoff"))
      this.enabled = Number(message.args.at(-1)) !== 0;
    if (message.address.endsWith("/initialize")) {
      this.generateProgression();
      this.publishPlan();
      this.lastChord = -1;
    }
  }
  onTick(tick, clock) {
    if (this.enabled) super.onTick(tick, clock);
  }
}

// Native extension agents: these do not overwrite historical ports. They
// demonstrate stricter ensemble-aware algorithms that curated performances can
// prefer while the original definitions remain available in the archive.
export class HarmonyPulseBot extends Agent {
  constructor(...args) {
    super(...args);
    this.lastPhrase = -1;
    this.lastStep = -1;
    this.previousChord = [];
    this.progression = [];
    this.durations = [];
    this.accompanied = "";
    this.heldBeats = 0;
  }
  // Somebody else who leads the harmony, if anybody does.
  //
  // This bot used to claim the highest priority of any harmony source in the
  // collection (0.72 against 0.55 to 0.6), so put beside ae_ModalChordBOT it
  // overruled it, both "accepted" the other's plan, and each then played its own
  // progression: F minor seventh against F major on the first downbeat, E flat
  // seventh against C major on the next, for the whole piece. A curated harmony
  // agent is there so an ensemble is never WITHOUT harmony. It is not there to
  // argue with a chord player somebody chose. So it leads when nobody else
  // does, and otherwise it accompanies: the leader's chords, in its own voicing
  // and its own bounded holds. Another deferential source counts as a leader
  // only if it sorts before this one, so two of them settle it between
  // themselves instead of both waiting for the other.
  harmonyLeader() {
    return this.harmonyAuthority(
      (plan) =>
        plan.author !== this.instanceId &&
        !(
          plan.payload?.deferential &&
          String(plan.author) > String(this.instanceId)
        ),
    );
  }
  accompany(clock) {
    const config = CONFIG.harmonyPulse,
      chord = this.notes,
      key = chord.join(",");
    if (!chord.length) return;
    this.heldBeats++;
    // A new chord from the leader, or a hold that has run its length.
    if (key === this.accompanied && this.heldBeats < config.maximumHoldBeats)
      return;
    this.accompanied = key;
    this.heldBeats = 0;
    // A beat is 60 / bpm: the clock's bpm counts the notated beat, the eighth
    // in 7/8, as the transport's secondsPerTick does. Scaling it again by
    // 4 / denominator halved every hold in an eighth-note meter, so a
    // four-beat hold in 7/8 at 120 lasted one second of its two (the
    // mathematical audit's B04).
    const voiced = voiceLeadChord(this.previousChord, chord, config.register),
      seconds = config.maximumHoldBeats * (60 / (clock.bpm || bandTempo()));
    // A chord no ordered voicing of the register holds is not sounded, never
    // clamped out of its classes (the audit's B05).
    if (!voiced.length) return;
    this.previousChord = [...voiced];
    // Written as it is held, its beats in the meter's ticks; a new chord ends the one before (shared/score-time.js).
    this.writtenChord(clock, config.maximumHoldBeats, () => this.audio.chord(voiced, seconds, 0.58));
  }
  writtenChord(clock, beats, play) {
    const events = this.written ??= new ScoreEvents("harmony"),
      ticks = beats * (clock.meter?.subdivision || bandMeter().subdivision);
    return events.perform(this.audio, events.create(clock.tick, ticks, { group: "harmony", replace: true }), play);
  }
  generate(clock) {
    const config = CONFIG.harmonyPulse,
      roots = [...config.rootCycle],
      pool = this.notes.length ? this.notes : this.bandOpening.chord;
    // Each chord is led from the one before it in the progression, not every
    // chord from the phrase's last (the audit's B05); a chord no ordered
    // voicing of the register holds leaves no progression to offer.
    let before = this.previousChord;
    this.progression = roots.map((offset, index) => {
      const root = pitchClass(pool[index % pool.length]) + offset;
      const quality = config.qualities[index % config.qualities.length];
      const voiced = voiceLeadChord(before, quality.map(value => root + value), config.register);
      if (voiced.length) before = voiced;
      return voiced;
    });
    if (this.progression.some(chord => !chord.length)) { this.progression = []; return; }
    this.previousChord = [...this.progression.at(-1)];
    this.durations = this.progression.map((_, index) =>
      config.durationBeats[index % config.durationBeats.length],
    );
    this.publishProgression(clock);
  }
  // Its progression offered as the band's harmony, a phrase ahead.
  publishProgression(clock) {
    const config = CONFIG.harmonyPulse,
      phraseBars = clock.meter?.phraseBars || bandPhraseBars(),
      appliesAt = {bar:(clock.bar||0)+phraseBars,phrase:(clock.phrase||0)+1,section:clock.section||0};
    this.publishPlan("harmony", {
      schemaVersion: 1,
      chords: this.progression.map(chord => [...chord]),
      durations: [...this.durations],
      maximumHoldBeats: config.maximumHoldBeats,
      // Says what this plan is: harmony offered in case nobody else offers
      // any. Other deferential sources read it to settle who leads.
      deferential: true,
    }, {
      createdAt:{bar:clock.bar||0,phrase:clock.phrase||0,section:clock.section||0},
      appliesAt,
      expiresAt:{...appliesAt,bar:appliesAt.bar+phraseBars,phrase:appliesAt.phrase+1},
      // Below every chord bot in the collection (0.55 to 0.6), so that in the
      // one case where both have spoken -- a networked room where this bot
      // ticked first -- followers take the chord player at once.
      confidence:.82, priority:.4,
      rationale:"Offer audible harmonic motion, with bounded holds and parsimonious voice leading, while nobody else leads the harmony.",
    });
  }
  onTick(tick, clock) {
    // Asked on every beat, not once a phrase: in a networked room the chord
    // player's plan can arrive after this bot's phrase has started, and it
    // should stop leading then, not four bars later.
    const leader = this.harmonyLeader();
    if (clock.phraseStart && clock.phrase !== this.lastPhrase) {
      this.lastPhrase = clock.phrase;
      if (leader) this.progression = [];
      else this.generate(clock);
      this.lastStep = -1;
    }
    if (!clock.beatStart) return;
    if (leader) return this.accompany(clock);
    // **It does not wait for a phrase to begin before there is harmony.** It
    // only ever generated at a phrase start, so joining a piece under way -- or
    // losing its leader mid-phrase -- it said nothing until the next one: 8.4 s
    // into a 4/4 at 112, far longer in one of mh_PlexBOT's metres, and longer
    // than a live room waits to hear harmony before giving up on it. The
    // progression is indexed by the beat within the phrase, so it starts on the
    // chord it would have reached, not on the first.
    if (!this.progression.length) {
      this.generate(clock);
      this.lastStep = -1;
      // A register no ordered voicing fits: nothing to offer this beat.
      if (!this.progression.length) return;
    }
    const beatInPhrase =
      ((clock.bar || 0) % (clock.meter?.phraseBars || bandPhraseBars())) *
        (clock.meter?.numerator || bandMeter().numerator) +
      (clock.beat || 0);
    let span = 0, index = 0;
    while (index < this.durations.length - 1 &&
      beatInPhrase >= span + this.durations[index]) span += this.durations[index++];
    index %= this.progression.length;
    if (index === this.lastStep) return;
    this.lastStep = index;
    // Beats of 60 / bpm, as in accompany.
    const chord = this.progression[index],
      beats = Math.min(CONFIG.harmonyPulse.maximumHoldBeats, this.durations[index]),
      seconds = beats * (60 / (clock.bpm || bandTempo()));
    this.broadcast("notepool", chord);
    this.writtenChord(clock, beats, () => this.audio.chord(chord, seconds, .58));
  }
}
