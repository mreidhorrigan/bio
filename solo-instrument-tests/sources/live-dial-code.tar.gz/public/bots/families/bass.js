// The bass bots: the walking, electric, snap, synth and splatter basses, the x-suite's bass, and the two bases they
// build on (BassBot, TalaPatternBassBot).
// Moved verbatim from public/agents.js in its per-family split (28 September 2026; RESEARCH_BACKLOG, the second
// queue). agents.js registers them (BOT_REGISTRY) and re-exports each, so an import from it is as it was.
import { Agent } from "../../framework/index.js";
import { STOCHASTIC_CONFIG as CONFIG } from "../../stochastic-config.js";
import { additiveGroupStarts, metricWeights } from "../../shared/rhythm.js";
import { boundedDrunk, randomInt, scramble, weightedChoice } from "../../shared/stochastic.js";
import {
  complementaryActivityMask, cycleIndexAtPhrasePosition, normalizeActivityMask, normalizePitchclassPool,
  parseCompoundIntent, serializeCompoundIntent,
} from "../../shared/intentions.js";
import { pitchClass } from "../../shared/pitch.js";
import { playableRegister } from "../../shared/sequencing.js";
import {bandTempo} from '../../shared/opening-time.js';
import {toNextAttack,writtenOn,writtenOnStep} from "../lib/written.js";

export class BassBot extends Agent {
  constructor(...args) {
    super(...args);
    this.step = 0;
    this.noteIndex = 0;
    this.config = CONFIG.walkingBass;
  }
  onTick(
    tick,
    clock,
  ) {
    clock = this.interpretClock(clock);
    const minGap = Math.max(
      1,
      Math.ceil(
        clock.meter.subdivision * (this.config.minimumBeatsBetweenAttacks || 0),
      ),
    );
    if (
      !this.rhythm(clock, this.config)[clock.tickInBar] ||
      (this.lastAttackTick != null && tick - this.lastAttackTick < minGap)
    )
      return;
    this.lastAttackTick = tick;
    this.noteIndex =
      (this.noteIndex +
        weightedChoice(this.config.steps, this.config.stepWeights) +
        this.notes.length) %
      this.notes.length;
    const note = (this.notes[this.noteIndex] ?? 60) - 12,
      weights = metricWeights(clock.meter.groups, clock.meter.subdivision),
      accent =
        this.config.accentFloor +
        (1 - this.config.accentFloor) *
          (weights[clock.tickInBar] / Math.max(...weights));
    // (Written to its next attack in the bar's rhythm: lib/written.js.)
    writtenOn(this.audio, clock.tick, toNextAttack(this.rhythm(clock, this.config), clock.tickInBar, { ticks: clock.meter.pulsesPerBar, gap: minGap }), () => this.play(note, accent));
    this.step++;
  }
  play(note, accent) {
    this.audio.bass(note, accent);
  }
}

export class WalkingBassBot extends BassBot {}

export class EBassBot extends BassBot {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.eBass;
  }
  play(note, accent) {
    this.audio.eBass(note, accent);
  }
}

export class TalaPatternBassBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.snapBass;
    this.rootPitch = this.config.range[0];
  }
  choosePitchClass() {
    const pitchClasses = this.notes.map((note) => note % 12);
    if (this.config.pitchClassSelection === "first")
      return pitchClasses[0] ?? 0;
    const counts = new Map();
    for (const pc of pitchClasses) counts.set(pc, (counts.get(pc) || 0) + 1);
    return (
      [...counts].sort(
        (a, b) =>
          b[1] - a[1] ||
          pitchClasses.indexOf(a[0]) - pitchClasses.indexOf(b[0]),
      )[0]?.[0] ?? 0
    );
  }
  onMessage(message) {
    super.onMessage(message);
    if (message.address.endsWith("/notepool"))
      this.rootPitch = this.config.range[0] + this.choosePitchClass();
  }
  onTick(
    tick,
    clock,
  ) {
    clock = this.interpretClock(clock);
    const active = this.rhythm(clock, this.config, this.density)[
        clock.tickInBar
      ],
      minGap = Math.max(
        1,
        Math.ceil(
          clock.meter.subdivision * this.config.minimumBeatsBetweenAttacks,
        ),
      );
    if (
      !active ||
      (this.lastAttackTick != null && tick - this.lastAttackTick < minGap)
    )
      return;
    this.lastAttackTick = tick;
    const index = clock.tickInBar % this.config.octaveCycle.length,
      note = Math.min(
        this.config.range[1],
        // A guard, not a live fold: `/broadcast/notepool` is clamped to 0..127 by
        // `clampPitch`, `choosePitchClass` takes it modulo 12, and the anchor adds 36 or 48 —
        // so the largest sum reachable is under 60 against a ceiling of 127.998. Kept so a
        // later change to `range` or `octaveCycle` cannot reintroduce an unplayable pitch.
        // See research/upstream-ports/snap-bass.md.
        playableRegister(this.rootPitch + this.config.octaveCycle[index])
          ?? this.rootPitch,
      ),
      velocity =
        this.config.velocityCycle[
          clock.subdivision % this.config.velocityCycle.length
        ];
    writtenOn(this.audio, clock.tick, toNextAttack(this.rhythm(clock, this.config, this.density), clock.tickInBar, { ticks: clock.meter.pulsesPerBar, gap: minGap }), () => this.play(note, velocity));
  }
  play(note, velocity) {
    this.audio.snapBass(note, velocity);
  }
}

export class SnapBassBot extends TalaPatternBassBot {}

export class SynthBassBot extends TalaPatternBassBot {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.synthBass;
    this.rootPitch = this.config.range[0];
  }
  play(note, velocity) {
    this.audio.synthBass(note, velocity);
  }
}

export class SplatterBassBot extends Agent {
  constructor(...args) {
    super(...args);
    const config = CONFIG.splatterBass;
    this.activityMask = [...config.activityMask];
    // The band's opening chord's classes, drawn from the piece's seed.
    this.pitchclassPool = this.openingClasses();
    this.nextActivityMask = [...this.activityMask];
    this.nextPitchclassPool = [...this.pitchclassPool];
    this.receivedMasks = [];
    this.receivedPitchclasses = [];
    this.intentSent = false;
    this.lastPhrase = -1;
    this.lastCycleIndex = -1;
    this.currentPitch = config.baseMidi + this.pitchclassPool[0];
  }
  onMessage(message) {
    super.onMessage(message);
    const compound = parseCompoundIntent(message);
    if (
      compound &&
      compound.sender !== "ybot_splatterBOT" &&
      compound.sender !== this.instanceId
    ) {
      if (compound.activityMask) this.receivedMasks.push(compound.activityMask);
      if (compound.pitchclassPool)
        this.receivedPitchclasses.push(...compound.pitchclassPool);
      return;
    }
    if (message.address === "/broadcast/intent/activityMask")
      this.receivedMasks.push(normalizeActivityMask(message.args));
    if (message.address === "/broadcast/intent/pitchclassPool")
      this.receivedPitchclasses.push(...normalizePitchclassPool(message.args));
  }
  beginPhrase(phrase) {
    if (this.lastPhrase >= 0) {
      this.activityMask = [...this.nextActivityMask];
      this.pitchclassPool = this.nextPitchclassPool.length
        ? [...this.nextPitchclassPool]
        : [...this.pitchclassPool];
    }
    this.lastPhrase = phrase;
    this.receivedMasks = [];
    this.receivedPitchclasses = [];
    this.intentSent = false;
    this.lastCycleIndex = -1;
  }
  publishNextIntent() {
    this.nextActivityMask = complementaryActivityMask(this.receivedMasks);
    const pool = normalizePitchclassPool(this.receivedPitchclasses);
    this.nextPitchclassPool = pool.length ? pool : [...this.pitchclassPool];
    this.broadcast(
      "intent",
      serializeCompoundIntent(
        "ybot_splatterBOT",
        this.nextActivityMask,
        this.nextPitchclassPool,
      ),
    );
    this.intentSent = true;
  }
  onTick(
    tick,
    clock,
  ) {
    clock = this.interpretClock(clock);
    if (clock.phraseStart && clock.phrase !== this.lastPhrase)
      this.beginPhrase(clock.phrase);
    const cycleIndex = cycleIndexAtPhrasePosition(
      clock,
      this.activityMask.length,
    );
    if (!this.intentSent && cycleIndex >= CONFIG.splatterBass.intentStep)
      this.publishNextIntent();
    if (!clock.beatStart || cycleIndex === this.lastCycleIndex) return;
    this.lastCycleIndex = cycleIndex;
    if (clock.barStart || this.currentPitch == null) {
      const pool = this.pitchclassPool.length
        ? this.pitchclassPool
        : CONFIG.splatterBass.pitchclassPool;
      this.currentPitch =
        CONFIG.splatterBass.baseMidi + pool[randomInt(pool.length)];
    }
    const activity = this.activityMask[cycleIndex],
      filterValue = CONFIG.splatterBass.filterValues[activity] ?? 17,
      velocity = 0.35 + (activity / 9) * 0.55,
      duration = (CONFIG.splatterBass.noteDurationBeats * 60) / 108;
    // (A beat's note, on the beat it plays: its 0.8 of a beat is how long it sounds.)
    writtenOn(this.audio, clock.tick, clock.meter.subdivision, () => this.audio.acidBass(this.currentPitch, duration, velocity, filterValue));
  }
}

export class XBassBot extends Agent {
  constructor(...args) {
    super(...args);
    this.config = CONFIG.xBass;
    this.tala = this.openingTala;
    this.enabled = true;
    this.exiting = false;
    this.velocityState = 45;
    this.lastStep = -1;
    this.generatePattern();
  }
  generatePattern() {
    const c = this.config,
      starts = additiveGroupStarts(this.tala, c.sourceSteps),
      candidates = [...new Set([0, ...starts, ...Array(c.sourceSteps).keys()])],
      count = Math.max(
        c.minimumOnsets,
        Math.round(
          (c.densityOnsetRange[0] +
            this.density * (c.densityOnsetRange[1] - c.densityOnsetRange[0])) *
            c.sourceSteps,
        ),
      );
    this.pattern = scramble(candidates).slice(0, count);
    if (!this.pattern.includes(0)) this.pattern.unshift(0);
  }
  onMessage(message) {
    super.onMessage(message);
    if (message.address.endsWith("/density")) {
      const value = Number(message.args.at(-1));
      if (Number.isFinite(value)) {
        this.density = Math.max(0, Math.min(1, value));
        this.generatePattern();
      }
    }
    if (message.address.endsWith("/tala")) this.generatePattern();
    if (message.address.endsWith("/initialize")) this.generatePattern();
    if (message.address.endsWith("/onoff"))
      this.enabled = Number(message.args.at(-1)) !== 0;
    if (message.address.endsWith("/exiting"))
      this.exiting = Number(message.args.at(-1)) !== 0;
  }
  choosePitch() {
    const ranked = scramble(this.notes),
      source = weightedChoice(
        ranked,
        ranked.map((_, index) => this.config.pitchRankWeights[index] ?? 0.05),
      ),
      pc = pitchClass(source) ?? 0;
    return this.config.baseMidi + pc;
  }
  onTick(
    tick,
    clock,
  ) {
    if (!this.enabled || this.exiting) return;
    const step = Math.min(
      15,
      Math.floor(
        ((clock.tickInBar || 0) / Math.max(1, clock.meter.pulsesPerBar)) * 16,
      ),
    );
    if (step === this.lastStep || !this.pattern.includes(step)) return;
    this.lastStep = step;
    this.velocityState = boundedDrunk(
      this.velocityState,
      this.config.velocityWalk.range,
      this.config.velocityWalk.step,
    );
    const [low, high] = this.config.velocityWalk.output,
      velocity =
        low +
        (this.velocityState / (this.config.velocityWalk.range - 1)) *
          (high - low),
      duration = (this.config.noteDurationBeats * 60) / (clock.bpm || bandTempo());
    // (Written on its step of the sixteen, a step long, wherever its tick falls.)
    writtenOnStep(this.audio, clock.tick - (clock.tickInBar || 0), clock.meter.pulsesPerBar, 16, step, () => this.audio.bass(this.choosePitch(), velocity, duration));
  }
}
