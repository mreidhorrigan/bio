import {onsetsPayload} from '../shared/sounding-voices.js';
import {SOUND_STATES_ADDRESS,SoundStates} from '../shared/rate-contract.js';
import {secondsPerTick} from '../shared/meter-tactus.js';
import {PerformerNotes} from '../shared/performer-notes.js';
import {NoteTracker} from '../shared/estimation/pitch-yin.js';
import {Agent, defineBot} from '../framework/index.js';
import {PerformerAudioCapture} from '../shared/estimation/audio-capture.js';
import {AudioObservationSource} from '../shared/estimation/audio-observer.js';
import {HostInputCapture} from '../shared/estimation/host-input-capture.js';
import {CHROMA_PROJECTION, createChromaChordModel, observeChromaChord} from '../shared/estimation/audio-chroma.js';
import {HARMONY_LISTENINGS, DEFAULT_HARMONY_LISTENING} from '../shared/estimation/harmony-listenings.js';
import {TWELVE_TONE_TRIADS} from '../shared/estimation/harmony-model.js';
import {HarmonyFollower} from '../shared/estimation/harmony-follower.js';
import {FORECAST_ADDRESS, harmonyChangeForecast} from '../shared/estimation/forecasts.js';
import {chromaEvidence} from '../shared/estimation/harmonic-levels-filter.js';
import {LINES_ORIENTATION} from '../shared/estimation/listening-options.js';
import {beatSubdivision} from '../shared/estimation/subdivision.js';
import {POCKET_SECONDS} from '../shared/estimation/beat-sync.js';
import {COORDINATIONS} from '../shared/estimation/input-report.js';
import {expressionProfile} from '../shared/performance-timing.js';
import {serveInputQuery} from '../shared/estimation/input-report.js';
import {randomUUID} from '../shared/random-id.js';
import {identifier} from '../shared/planning-data.js';
import {performerFormAnswer} from '../shared/form-negotiation.js';
import {compareLogicalPosition, logicalPosition} from '../shared/planning.js';
import {STOCHASTIC_CONFIG} from '../stochastic-config.js';
import {bandPhraseBars,bandMeter} from '../shared/opening-time.js';

// The chord estimator the GuitarSet held-out test froze (private pre-registration,
// Amendment 10). Its chroma is the frame analysis's (FRAME_CHROMA).
export const LISTENER_CHORDS = Object.freeze({sharpness: 25, stayPerSecond: .9, confident: .5, keyStrength: 2, keyMemorySeconds: 10, dwellSeconds: 0});
// The chord model of a harmony listening by name (harmony-listenings.js): the default's is LISTENER_CHORDS'.
export function listenerChordModel(name = DEFAULT_HARMONY_LISTENING) {
  const listening = HARMONY_LISTENINGS[name];
  if (!listening) throw new TypeError(`A harmony listening is one of ${Object.keys(HARMONY_LISTENINGS).join(', ')}`);
  return createChromaChordModel({vocabulary: TWELVE_TONE_TRIADS, ...listening.model});
}

// Hears one audio input: pulse and pitch for tempo following, and chords.
//
// Live, it opens a microphone the operator chooses. In a render (or any host
// that provides `inputs`), it opens the host's input instead and hears it on the
// host's clock, frame by frame as time passes. A render's clip is such an input
// when it names the 'input' hearing, and a listener claims one as it joins.
//
// Once it listens, it leads the ensemble's harmony with the chords it hears (HarmonyFollower), as the performer's
// plan: a listening bot listens so that the ensemble can follow. leadHarmony(false) makes it observation only.
export class ListenerBot extends Agent {
  constructor(send, audio, {mediaDevices = globalThis.navigator?.mediaDevices,
    captureFactory = options => new PerformerAudioCapture(options), id = randomUUID, inputs = null} = {}) {
    super(send, audio);
    Object.assign(this, {mediaDevices, captureFactory, newId: id, inputs});
    this.state = 'idle';
    this.generation = 0;
    this.rejectedReports = 0;
    this.chords = null; this.harmonyFollower = null; this.harmonyMessages = []; this.attacks = []; this.bass = []; this.attackNoise = []; this.beats = [];
    this.forecastKey = null; this.forecastRevision = 0; this.performerLabel = null;
    this.leadsHarmony = true;
  }
  status(state, message) {
    if (this.state === state && this.message === message) return;
    this.state = state; this.message = message;
    this.audio?.report?.('bot_status', {state, message});
  }
  async start() {
    this.stopped = false;
    if (this.inputs) {
      // A render's input is claimed as the listener joins: its clip is the performer, and it cannot contain bot output.
      const deviceId = this.inputs.claim?.() ?? null, name = deviceId && this.inputs.list().find(input => input.id === deviceId)?.name;
      if (!deviceId) { this.status('idle', "No render clip is armed as an input (hear: ['input'])."); return; }
      // In a render with foresight (render/foresight.js), the whole take is known before it sounds.
      if (this.inputs.foresight) this.foresightInput = this.inputs.open(deviceId);
      await this.listenInput({deviceId, role: 'isolated', performerId: name, possibleSelfOutput: false});
      return;
    }
    this.status(this.mediaDevices?.getUserMedia ? 'idle' : 'unavailable', this.mediaDevices?.getUserMedia
      ? 'Choose an audio source and click Listen to allow microphone access.'
      : 'Microphone capture is unavailable in this host.');
  }
  // A host input is heard up to the present at each tick, before the bots that play are pulsed.
  onTick(tick, clock) {
    this.currentClock = clock ?? this.currentClock;
    this.capture?.pump?.();
    this.sendHarmony();
    this.sendForecast();
    this.sendOnsets(clock);
    this.sendNotes(clock);
    if (clock?.barStart) this.answerForms(clock);
  }
  // The piece's length, from the performer's side (the negotiated composition length's preferences: docs/COMPOSITION_DURATION.md
  // §9, docs/FORM_NEGOTIATION.md §4a). This bot stands for the person it hears, so it answers a form plan for them: once the
  // ending comes near, a performer still playing wants the piece to go on, and one who has stopped wants it to end
  // sooner (performerFormAnswer); a FormBOT weighs that voice as a person's. Answered when a plan arrives and again at
  // each bar where the view has changed; before the ending is near, it abstains.
  onPlan(plan) {
    if (plan?.kind !== 'form') return super.onPlan(plan);
    this.futurePlans.set(plan.planId, plan);
    this.answerForm(plan, this.currentClock);
  }
  answerForms(clock) {
    const now = logicalPosition(clock);
    for (const [id, plan] of this.futurePlans) {
      if (plan.kind !== 'form') continue;
      if (compareLogicalPosition(now, plan.expiresAt) >= 0) { this.futurePlans.delete(id); continue; }
      this.answerForm(plan, clock);
    }
  }
  answerForm(plan, clock) {
    const answer = performerFormAnswer(plan, {...this.performerState(clock), window: STOCHASTIC_CONFIG.formBot?.stopLeadPhrases ?? 2, phraseBars: clock?.meter?.phraseBars});
    const said = JSON.stringify(answer), answered = this.formAnswers ??= new Map(), key = `${plan.planId}:${plan.revision}`;
    if (answered.get(key) === said) return;
    answered.set(key, said);
    for (const held of answered.keys()) if (answered.size > 64) answered.delete(held);
    this.respondToPlan(plan, answer?.disposition ?? 'abstain', {createdAt: plan.createdAt, payload: answer ? {variants: answer.variants} : {},
      rationale: answer?.rationale ?? 'No view yet on how long the piece should be.'});
  }
  // Whether the performer is playing or has stopped, in their own time, which the capture keeps. A silence is a stop
  // once it is longer than this performer rests: twice the longest rest heard from them so far, at least half a phrase,
  // and never more than a phrase. So a performer who rests often is waited for, and one who never has is heard stopping
  // soon; mistaking a rest for an ending leaves them playing alone, mistaking an ending for a rest adds a phrase.
  // A quiet the ensemble has declared (an intentional silence, a decay listened to, a wait for a cue: the extreme-
  // aesthetics report's §5.4), for the performer or for all, is neither: the listener has no view on the ending then.
  performerState(clock) {
    const now = this.capture?.captureNow?.(), last = this.attacks.at(-1), meter = clock?.meter;
    if (!Number.isFinite(now) || !meter || !Number.isFinite(last)) return {bar: clock?.bar, heard: false};
    const voice = this.instanceId ?? 'listener';
    if (Number.isFinite(clock.tick) && [voice, `${voice}:performer`].some(name => this.soundStates?.meaning(name, clock.tick, {basis: 'ticks'}).declared))
      return {bar: clock.bar, heard: true, playing: false, stopped: false};
    for (let i = Math.max(1, this.restsHeardTo ?? 1); i < this.attacks.length; i++)
      this.longestRest = Math.max(this.longestRest ?? 0, this.attacks[i] - this.attacks[i - 1]);
    this.restsHeardTo = this.attacks.length;
    const phrase = secondsPerTick(clock) * (meter.pulsesPerBar || bandMeter().pulsesPerBar) * (meter.phraseBars || bandPhraseBars()),
      stopped = now - last >= Math.min(phrase, Math.max(phrase / 2, 2 * (this.longestRest ?? 0)));
    return {bar: clock.bar, heard: true, playing: !stopped, stopped};
  }
  // The performer's line, note by note (pitch-yin.js from the capture's frames), as their voice (/broadcast/voices,
  // role 'performer', performer-notes.js).
  sendNotes(clock) {
    const now = this.capture?.captureNow?.();
    if (!this.performerNotes || !Number.isFinite(now)) return;
    for (const {address, args} of this.performerNotes.flush(clock, now, this.inputs?.outputDelaySeconds ?? this.audio?.clock?.lookahead ?? .25)) this.send(address, args);
  }
  // The performer's attacks since the last tick, placed on the ensemble's ticks, for the bots that listen to rhythm
  // (/broadcast/onsets, rhythm-spaces.js). The band's notes sound one output delay after they are decided (the scheduler's
  // lookahead), and a performer plays with what sounds; so an attack heard at `at` belongs to the tick that sounds then:
  // (now + delay - at) seconds before the one being decided. Without the delay, attacks landed an eighth late at 120
  // BPM. The bass under an attack (its low rise) is passed as its strength's floor.
  sendOnsets(clock) {
    const now = this.capture?.captureNow?.(), meter = clock?.meter;
    if (!Number.isFinite(now) || !meter || !Number.isFinite(clock.tick)) return;
    const perTick = secondsPerTick(clock);
    const delay = this.inputs?.outputDelaySeconds ?? this.audio?.clock?.lookahead ?? .25, fresh = [];
    for (let i = 0; i < this.attacks.length; i++) {
      const at = this.attacks[i];
      if (!(at > (this.onsetsSentThrough ?? -Infinity)) || at > now) continue;
      fresh.push({tick: clock.tick - (now + delay - at) / perTick, strength: .6 + .4 * Math.min(1, Math.max(0, this.bass[i] ?? 0))});
    }
    if (!fresh.length) return;
    this.onsetsSentThrough = Math.max(...this.attacks.filter(at => at <= now));
    this.send('/broadcast/onsets', [onsetsPayload({voice: this.instanceId ?? 'listener', role: 'performer', onsets: fresh})]);
  }
  async listAudioInputs() {
    if (this.stopped) throw new Error('This listener has stopped.');
    if (this.inputs) return this.inputs.list().map(({id, name}) => ({id, name}));
    const inputs = await this.mediaDevices?.enumerateDevices?.();
    return (inputs || []).filter(device => device.kind === 'audioinput').map((device, index) =>
      ({id: device.deviceId, name: device.label || `Audio input ${index + 1}`}));
  }
  // listening: how the analysis hears (listening-options.js); a render's inputs bring their own.
  async listenInput({deviceId = '', role = 'isolated', performerId = 'player-1', possibleSelfOutput = true, clock = null, listening = null,
    placementSeconds = null, lean = null, coordination = 'tight', leading = null} = {}) {
    if (this.stopped || !this.instanceId) throw new Error('Wait for the listener to join the conductor.');
    if (placementSeconds !== null && !(Number.isFinite(placementSeconds) && Math.abs(placementSeconds) <= POCKET_SECONDS)) throw new RangeError(`A declared placement is within ${POCKET_SECONDS} s of the beat.`);
    const leaning = lean === null ? null : expressionProfile({lean: {instrument: 'performer', ...lean}}).lean;
    if (!COORDINATIONS.includes(coordination)) throw new RangeError(`Coordination is ${COORDINATIONS.join(', ')}.`);
    if (leading !== null && typeof leading !== 'boolean') throw new TypeError('A performer leads or does not (true or false), or has not said (null).');
    if (role === 'isolated') identifier(performerId, 'performer');
    else if (role !== 'mixture' || performerId !== null) throw new Error('Identify one isolated performer, or choose an unidentified mixture.');
    if (typeof possibleSelfOutput !== 'boolean') throw new TypeError('Declare whether this input can hear bot output.');
    if (!this.inputs && !this.audio?.ctx?.audioWorklet) throw new Error('This host does not provide microphone AudioWorklet capture.');
    this.stopListening();
    this.performerLabel = role === 'isolated' ? performerId : 'the room';
    this.placementSeconds = placementSeconds;
    this.lean = leaning && {ms: leaning.ms, shape: leaning.shape};
    this.coordination = coordination; this.leading = leading;
    const generation = this.generation, epoch = this.newId();
    this.listening = this.inputs?.listening ?? listening;
    this.chords = listenerChordModel(this.listening?.harmony);
    this.latestPitches = null; this.latestBeat = null;
    // A fresh follower for each listening, leading unless leadHarmony(false) said not to.
    this.harmonyFollower = this.leadsHarmony ? this.newHarmonyFollower() : null;
    const handlers = {
      onReport: report => {
        if (generation !== this.generation) return;
        try {
          if(this.refreshInputIdentity())return; // The frame belongs to the prior source incarnation.
          if(this.capture?.binding?.sourceIncarnation&&report.binding?.sourceIncarnation!==this.capture.binding.sourceIncarnation)return;
          this.inputSource ||= new AudioObservationSource({sessionId: clock?.sessionId || `audio-local-${epoch}`,
            observerId: this.instanceId, publisher: {id: this.instanceId, incarnation: this.incarnation || epoch},
            captureBinding: report.binding});
          this.latestObservations = this.inputSource.accept(report);
          // A learned harmony listening hears the chords itself (learned-chords.js); the templates hear the chroma.
          if (report.harmony?.chords) this.chords = report.harmony.chords;
          else if (report.harmony) this.chords = observeChromaChord(this.chords, report.harmony.chroma, {availableAt: report.when.availableAt, bass: report.harmony.bass ?? null});
          // For an orientation's levels: the pitch classes played (a chroma frame's peaks), and the performer's beat.
          this.latestPitches = report.harmony?.chroma ? chromaEvidence(report.harmony.chroma) : null;
          const forecast = report.rhythm?.status === 'tracking' ? report.rhythm.candidates?.[0]?.forecast : null;
          this.latestBeat = forecast ? {...forecast, beatsPerBar: report.rhythm.learned?.beatsPerBar ?? null, downbeatAt: report.rhythm.learned?.downbeats?.at(-1) ?? null} : null;
          // Each attack with its bass (lowRise), which a conductor that trusts its own meter groups its beat by. A second
          // detector's attacks, where the listening names one (listening-options.js attackDetector), are the ones passed on.
          const attack = 'attack' in report.features ? report.features.attack : report.features.onset;
          // The line: a note begun where a clear pitch holds, or an attack strikes it again.
          if (report.pitch) {
            this.noteTracker ??= new NoteTracker(); this.performerNotes ??= new PerformerNotes({voice: `${this.instanceId ?? 'listener'}:performer`});
            const {started, ended} = this.noteTracker.hear({at: report.pitch.at, midi: report.pitch.midi, clarity: report.pitch.clarity, attack: Boolean(attack)});
            if (started) this.performerNotes.start(started.start, started.midi); else if (ended) this.performerNotes.end(ended.end);
          }
          // Each marked if heard while the harmony was heard as noise (a listening with a no-chord class says so): the
          // performer's subdivision is read from the others. Bursts of noise at random, heard before music came back,
          // once tipped a straight guitar into triplets.
          if (attack) { this.attacks.push(attack.estimateSeconds); this.bass.push(attack.lowRise ?? 0); this.attackNoise.push(this.chords?.reason === 'noise');
            if (this.attacks.length > 96) { this.attacks.shift(); this.bass.shift(); this.attackNoise.shift(); } }
          const beat = report.rhythm?.candidates?.[0]?.forecast?.periodSeconds;
          if (beat > 0) { this.beats.push({at: report.when.availableAt, period: beat}); if (this.beats.length > 512) this.beats.shift(); }
          this.lastError = null;
          this.status('listening', role === 'isolated' ? `Listening to ${performerId}.` : 'Listening to an unidentified audio mixture.');
        } catch (error) {
          this.rejectedReports++;
          this.coverageChanged({coverage: 'invalid', reason: error.message});
        }
      },
      onCoverage: report => { if (generation === this.generation) this.coverageChanged(report); },
    };
    this.capture = this.inputs ? new HostInputCapture({inputs: this.inputs, now: this.inputs.now, ...handlers})
      : this.captureFactory({context: this.audio.ctx, mediaDevices: this.mediaDevices, ...(clock?.now ? {now: clock.now} : {}), ...handlers});
    this.inputSource = null; this.latestObservations = []; this.lastError = null;
    this.status('permission', this.inputs ? 'Opening the input.' : 'Allow microphone access to start listening.');
    try {
      const started = await this.capture.start({deviceId, role, performerId, possibleSelfOutput, mapping: clock?.mapping || null,
        ...(this.inputs?.listening ? {listening: this.inputs.listening} : listening ? {listening} : {})});
      if (generation !== this.generation) return false;
      if (started) this.status('listening', 'Waiting for the first complete audio frame.');
      return started;
    } catch (error) {
      if (generation === this.generation) { this.stopListening(); this.status('idle', error.message); }
      throw error;
    }
  }
  coverageChanged({coverage, reason}) {
    this.lastError = reason;
    const capture = this.capture;
    if (this.inputSource && capture?.mapping) {
      const now = capture.captureNow();
      this.inputSource.missing({invalid: coverage === 'invalid', reason, when: {
        eventStart: now, eventEnd: now, availableAt: now, receivedAt: now,
        lookaheadSeconds: 0, clockDomain: capture.clockDomain,
        clockMappingVersion: capture.mapping.version,
        timingVarianceSeconds2: capture.mapping.timingVarianceSeconds2,
        calibrationStatus: capture.mapping.calibrationStatus,
      }});
    }
    this.status(coverage, `Audio input unavailable: ${reason}.`);
  }
  stopListening() {
    if (this.inputSource?.coverage === 'complete') this.coverageChanged({coverage: 'missing', reason: 'listening-stopped'});
    this.generation++;
    this.capture?.stop();
    this.capture = null; this.chords = null; this.attacks = []; this.bass = []; this.attackNoise = []; this.beats = []; this.onsetsSentThrough = null;
    this.noteTracker = null; this.performerNotes?.clear();
    this.status('idle', 'Audio listening is off.');
  }
  // Whether the chords this listener hears lead the ensemble's harmony.
  leadHarmony(enabled = true) {
    this.leadsHarmony = Boolean(enabled);
    this.harmonyFollower = this.leadsHarmony ? this.harmonyFollower || this.newHarmonyFollower() : null;
    return Boolean(this.harmonyFollower);
  }
  // With an orientation (listening-options.js), the band orients to the harmony level by level; to lines, by their scale.
  newHarmonyFollower() {
    const orientation = this.listening?.orientation ?? (this.listening?.harmonyInput === 'lines' ? LINES_ORIENTATION : null);
    return new HarmonyFollower({author: this.instanceId || 'listener', vocabulary: TWELVE_TONE_TRIADS, dwellSeconds: LISTENER_CHORDS.dwellSeconds, remember: true,
      ...(orientation ? {orient: orientation, followChords: {lines: false, auto: 'auto'}[this.listening.harmonyInput] ?? true} : {})});
  }
  // A confident chord change, as the performer's harmony plan and note pool.
  // Foresight (a render's foresight: true; render/foresight.js): the claimed input's chords over the whole take, each
  // announced one output delay before it sounds, so that the band's chord sounds with the performer's, where a listener
  // that hears must announce it after the fact. Through a rest between chords the last one stays; after the take's end,
  // its harmony is let go. Before the clip is placed, the listener hears as usual.
  sendForesightHarmony() {
    if (!this.harmonyFollower || !this.foresightInput?.foresight) return false;
    const seen = this.foresightInput.foresight(); if (!seen) return false;
    const now = this.inputs.now(), delay = this.inputs.outputDelaySeconds ?? .25, clock = this.currentClock || {};
    const sounding = seen.chords.filter(chord => chord.start - delay <= now).at(-1) ?? null, ended = now >= seen.audibleEnd - delay;
    const label = ended ? null : sounding?.label ?? this.foresightLabel ?? null;
    if (label === (this.foresightLabel ?? null)) return true;
    this.foresightLabel = label;
    const messages = label ? this.harmonyFollower.announce(label, {clock, at: now, anticipated: true, score: 1})
      : this.harmonyFollower.current !== null ? this.harmonyFollower.release({clock, at: now}) : [];
    for (const {address, args} of messages) {
      this.send(address, args);
      this.harmonyMessages.push({address, at: now, label, foresight: true});
      if (this.harmonyMessages.length > 64) this.harmonyMessages.shift();
    }
    return true;
  }
  sendHarmony() {
    if (this.sendForesightHarmony()) return;
    if (!this.harmonyFollower || !this.chords) return;
    const clock = this.currentClock || {};
    for (const {address, args} of this.harmonyFollower.update(this.chords, {clock, at: this.capture?.captureNow?.() ?? null,
      pitches: this.latestPitches, beat: this.latestBeat})) {
      this.send(address, args);
      this.harmonyMessages.push({address, at: this.chords.at, label: this.chords.candidates?.[0]?.label ?? null});
      if (this.harmonyMessages.length > 64) this.harmonyMessages.shift();
    }
  }
  // What the performer is expected to play next, where the harmony memory has heard them repeat (forecasts.js): one
  // forecast for each change it expects, apart from the harmony it follows, for a videobot to show. Only where its times
  // can be placed on the session's beats: a planning timeline, and a capture on the session clock.
  sendForecast() {
    const runtime = this.futurePlanning, follower = this.harmonyFollower, capture = this.capture;
    if (!runtime?.timeline || !runtime.ready?.() || !follower || !this.latestBeat || capture?.clockDomain !== 'session-seconds') return;
    const prediction = follower.expectedChange(this.latestBeat), key = prediction ? `${prediction.label}|${prediction.beat}` : null;
    if (!prediction || key === this.forecastKey) return;
    const payload = harmonyChangeForecast({author: {id: this.instanceId || 'listener', incarnation: this.incarnation || null},
      subject: {id: `${this.instanceId ?? 'listener'}:performer`, label: this.performerLabel}, prediction, beat: this.latestBeat,
      pitches: follower.voicing(prediction.label), timeline: runtime.timeline,
      capture: {clockDomain: capture.clockDomain, now: capture.captureNow(), calibration: capture.calibration ?? null}, revision: this.forecastRevision + 1});
    if (!payload) return;
    this.forecastKey = key; this.forecastRevision++;
    this.send(FORECAST_ADDRESS, [payload]);
  }
  // The chords heard, in the shape a MIDI input's harmony takes in reports (input-report.js), and whether they lead.
  harmonySnapshot() {
    const state = this.chords;
    if (!state || state.at === null) return null;
    return {status: state.status, reason: state.reason, at: state.at, vocabularyId: TWELVE_TONE_TRIADS.vocabularyId, tuningId: TWELVE_TONE_TRIADS.tuningId,
      projection: CHROMA_PROJECTION.id, candidates: state.candidates.slice(0, 4).map(({label, score}) => ({label, score})),
      leading: Boolean(this.harmonyFollower), announced: this.harmonyFollower?.current ?? null};
  }
  // How the performer divides the beat this listener reports, from its last eight seconds of attacks. Four clear
  // attacks suffice: on a strummed blues the detector heard only four to seven off-beats in eight seconds. The beat
  // must have held (within 8%) over the whole window. Where the beam calls its level ambiguous, only near-unanimous
  // evidence counts. On a rock solo it held three quarters of the true beat, with a 4:3 ambiguity flagged
  // throughout, and straight eighths measured against that beat fall on its two-thirds: five or six "triplets" to
  // one or two straight attacks. A synthetic shuffle, also flagged (3:2), gave thirteen to none.
  // Only an ambiguity that puts the beat itself in doubt calls for that. A rival at an octave (the beat against its
  // half or double) does not move where attacks fall within the beat. Nor does one at 3:2 or 3:1: two triplets, or
  // the triplet eighths, of the beat. That relation is the beat's own division in three. The bass-accent listening,
  // with its broader tactus preference, flags a blues' beat against its 3:2 throughout. Its triplets, five to eight
  // attacks to none, were then never enough. The rock solo's 4:3 still counts as ambiguous.
  //
  // Nor has the beat changed when it has moved by an octave. A 12/8 guitarist was heard at 68 and at 136 by turns,
  // and a strict guard left no window long enough to read. Its eighths fall in threes against either.
  subdivisionSnapshot(report) {
    const forecast = report?.rhythm?.candidates?.[0]?.forecast, now = report?.when?.availableAt;
    if (!forecast || !Number.isFinite(now)) return null;
    const [fine, coarse] = report.rhythm.levelAmbiguity?.periodsSeconds ?? [];
    const kindred = fine > 0 && coarse > 0 && [2, 4, 1.5, 3].some(ratio => Math.abs(coarse / fine / ratio - 1) < .04);
    const ambiguous = Boolean(report.rhythm.metricalLevelAmbiguous) && !kindred;
    const octaveOff = ratio => {let value = ratio; while (value > Math.SQRT2) value /= 2; while (value < Math.SQRT1_2) value *= 2; return Math.abs(value - 1);};
    // The attacks go with it (capture seconds), with their bass, so a conductor can place them on its own beats
    // (tempo-influence.js).
    const window = this.beats.filter(beat => beat.at > now - 8), recent = this.attacks.map((_, i) => i).filter(i => this.attacks[i] > now - 8 && !this.attackNoise?.[i]).slice(-32);
    const attacks = recent.map(i => this.attacks[i]), bass = recent.map(i => this.bass[i] ?? 0);
    if (window.some(beat => octaveOff(beat.period / forecast.periodSeconds) > .08))
      return {parts: null, triple: 0, duple: 0, windowSeconds: 8, reason: 'beat-changed', attacks, bass};
    return {...beatSubdivision(attacks, {beatAt: forecast.expectedTime, periodSeconds: forecast.periodSeconds},
      ambiguous ? {minimum: 8, ratio: 6} : {minimum: 4}), windowSeconds: 8, ambiguous, attacks, bass};
  }
  // How closely the performer asks to be followed from now (tight, loose, or released for a cadenza), as they say it.
  declareCoordination(coordination) {
    if (!COORDINATIONS.includes(coordination)) throw new RangeError(`Coordination is ${COORDINATIONS.join(', ')}.`);
    this.coordination = coordination;
    return coordination;
  }
  // Whether the performer leads the ensemble from now (a role handoff: one says false, the next true), as they say it.
  // The conductor weighs a leader's timing as the ensemble's and the others' as followers', and stays the one authority
  // that commits (input-fusion.js); this listener only reports.
  declareLead(leading) {
    if (leading !== null && typeof leading !== 'boolean') throw new TypeError('A performer leads or does not (true or false), or has not said (null).');
    this.leading = leading;
    return leading;
  }
  inputSnapshot() {
    const source = this.inputSource?.snapshot() || null, report = source?.latest;
    return {state: this.state, message: this.message, source, audio: report?.features || null,
      rhythm: report?.rhythm || null, pulse: report?.pulse || null, harmony: this.harmonySnapshot(), subdivision: this.subdivisionSnapshot(report),
      processingMs: report?.processingMs ?? null,
      calibration: this.capture?.calibration ?? null,
      // The performer's word on where they sit against the beat (input-report.js), where they have given it.
      placementSeconds: this.capture ? this.placementSeconds : null,
      lean: this.capture ? this.lean ?? null : null, coordination: this.capture ? this.coordination ?? null : null,
      leading: this.capture ? this.leading ?? null : null,
      rejectedEvents: this.rejectedReports, lastError: this.lastError || this.lastQueryError || null,
      authority: 'observation-only', timingMeaning: 'Acoustic attacks support alternative pulse interpretations; their scores are uncalibrated.'};
  }
  onMessage(message) {
    this.refreshInputIdentity();
    // What the ensemble says its quiet means (shared/rate-contract.js): an edit's cut, a performer's declared wait.
    if (message.address === SOUND_STATES_ADDRESS) (this.soundStates ??= new SoundStates()).hear(message.args?.[0] ?? []);
    // A query is answered from everything a host input has sounded by now.
    if (message.address === '/agent/estimation/query') this.capture?.pump?.();
    if(serveInputQuery(this,message,{sourceNow:this.capture?.captureNow()??this.inputSource?.lastAvailableAt??0}))return;
    super.onMessage(message);
  }
  setIdentity(value) {super.setIdentity(value);this.refreshInputIdentity();}
  refreshInputIdentity() {
    const publisher=this.inputSource?.binding.publisher;
    if(!publisher||!this.capture||publisher.id===this.instanceId&&(!this.incarnation||publisher.incarnation===this.incarnation))return false;
    if(!this.capture.renewSourceIncarnation?.()){
      this.stopListening();
      this.status('missing','Publisher identity changed; restart this capture adapter.');
      return true;
    }
    this.inputSource=null;this.latestObservations=[];this.lastQueryError=null;
    this.status('listening','Publisher identity changed; waiting for fresh audio evidence.');
    return true;
  }
  stop() { this.stopListening(); this.stopped = true; }
}

export const listenerBot = defineBot({id: 'listener', name: 'ListenerBot', status: 'native', category: 'utility',
  outputModes: [], pitchContract: 'none', description: 'Explicitly bound audio input (a microphone, or a render clip) with pitch, energy, alternative pulse estimates and chords; it can lead the harmony, and near the ending it speaks for the performer on how long the piece goes on.',
  visualizers: [{id: 'input-estimates', name: 'Input estimates', module: './input-estimates.js'}],
  planningCapabilities: {rhythm: false, harmony: false, form: false}}, (send, audio, options) => new ListenerBot(send, audio, options));
