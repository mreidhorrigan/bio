import {Agent, defineBot} from '../framework/index.js';
import {formProgress} from '../shared/form-development.js';
import {GrainCorpusPlayer,corpusAvailability} from '../granular-player.js';
import {grainChordShift} from '../shared/granular-corpus.js';
import {ExactGrainAccumulator} from '../shared/math-support/adapters/sampling/policies.js';
import {bandPhraseBars,bandTempo} from '../shared/opening-time.js';

// mh_GranularBOT — a grain-corpus bot that listens for transitions.
//
// Other agents own the form; this one reads it. Its whole musical premise is that the
// interesting moments in an ensemble piece are the joins — the phrase where a section
// turns over, the bar a meter changes, the two phrases before an ending is voted on —
// and that a cloud of recorded grains is a good way to mark a join without competing
// with whoever owns the material on either side of it. Between transitions it is nearly
// silent; at one it swells, breaks and decays.
//
// Everything it knows about its own sound was measured offline (see docs/GRANULAR_CORPUS.md
// and docs/GRANUBOT.md): the corpus arrives with a profile that has already sorted it into
// attacks, tones, textures and air, ranked every grain for how well it carries a
// transition, and bucketed the pitched ones by pitch class. At performance time the bot
// picks from a ranked list — it never analyses, filters or scans.
const CONFIG=Object.freeze({
  corpus:'granubot',
  base:'./data/granubot',
  floor:.035,                 // what it does between transitions: almost nothing
  decayHalfLifeBeats:3,       // how long a swell takes to fall away, in beats
  anticipateFrom:.62,         // fraction of a section after which it starts leaning in
  maxGrainsPerBeat:14,
  maxDensity:30,              // grains per second at full energy
  gain:.42,
  // What a transition is worth. An arriving section is the loudest thing in the piece;
  // a bar line barely registers.
  weights:Object.freeze({
    entry:1,section:1,meter:.8,adjust:.7,decision:.65,ending:.9,phrase:.3,bar:.1,
  }),
});
const clamp=(value,low=0,high=1)=>Math.min(high,Math.max(low,value));
// An exact remainder as the accumulator states it ("n/d" or "n"), as a number.
const fraction=text=>{const [n,d]=String(text).split('/').map(Number);return d?n/d:n};
// A double as the exact rational it is (m / 2^k, doubled until whole: each doubling exact), for the exact accumulator,
// which converts no float silently.
function exactOf(value){
  if(!Number.isFinite(value))throw new RangeError('A finite rate and time are counted');
  let whole=value,power=0;
  while(!Number.isInteger(whole)){whole*=2;power++}
  return power?`${BigInt(whole)}/${2n**BigInt(power)}`:String(BigInt(whole));
}

class GranularBot extends Agent {
  constructor(...args){
    super(...args);
    this.energy=0;
    this.lastPhrase=null;this.lastBar=null;this.lastSectionIndex=null;
    this.sectionRole='';this.sectionProgress=0;
    this.pendingRole=null;this.endingAt=null;
    this.player=null;this.corpusState='idle';this.corpusError='';
    this.scheduled=0;this.firstPhraseSeen=null;
  }
  // The corpus is this bot's instrument: tens of megabytes of decoded audio served by
  // the Musebots server. Until it arrives there is nothing to play and nothing worth
  // faking, so the bot stays silent and says so on its card.
  status(state,message){
    this.corpusState=state;
    this.audio?.report?.('bot_status',{state,message});
  }
  // Deliberately not awaited by start(): the host joins the room as soon as start()
  // resolves, and tens of megabytes of packs must not hold the ensemble's clock. The bot
  // simply has nothing to play until this finishes, and says so on its card meanwhile.
  start(){
    // Say what this device can do before fetching anything, so an unplayable case is a
    // stated warning rather than a bot that looks like it is playing in silence.
    const availability=corpusAvailability(globalThis,{canDecode:Boolean(this.audio?.ctx?.decodeAudioData)});
    if(availability.state==='unavailable'){
      this.status('unavailable',availability.message);
      return;
    }
    if(availability.state==='limited')this.status('limited',availability.message);
    this.loading=this.loadCorpus(availability);
  }
  async loadCorpus(availability={state:'ready'}){
    this.status(availability.state==='limited'?'limited':'loading','Loading grain corpus…');
    try{
      const player=new GrainCorpusPlayer(this.audio,{
        name:CONFIG.corpus,base:CONFIG.base,
        // The bot's own stream, drawn explicitly: the ambient random scope does not
        // survive an await, and grain choice has to stay reproducible from the seed.
        seed:this.randomStream?.snapshot?.().seed??1,
      });
      await player.load({onProgress:({loaded,total,bytes})=>
        this.status('loading',`Loading grain corpus… ${loaded}/${total} packs · ${(bytes/1048576).toFixed(0)} MiB`)});
      this.player=player;
      const report=player.report();
      const loaded=`${report.grains} grains · ${report.packs} packs · ${report.decodedMiB} MiB decoded`;
      // Some packs did not fit: it plays, but from a smaller corpus than it was built
      // with, and the listener is told so rather than left to wonder.
      this.status(report.skipped?'limited':'ready',report.skipped
        ?`${loaded} · ${report.skipped} of ${report.packs+report.skipped} packs did not fit this device's ${report.budgetMiB} MiB audio budget`
        :loaded);
    }catch(error){
      this.player=null;
      this.status('unavailable',`Grain corpus unavailable: ${error.message}`);
    }
  }
  stop(){this.player?.dispose();this.player=null;this.corpusState='idle'}

  // ---- Reading the form ----------------------------------------------------
  onMessage(message){
    super.onMessage(message);
    const address=message?.address||'';
    if(address==='/broadcast/section')this.mark('section');
    else if(address==='/broadcast/meter')this.mark('meter');
    else if(address==='/broadcast/form/adjust')this.mark('adjust');
    else if(address==='/broadcast/form/decision')this.mark('decision');
  }
  onPlan(plan){
    // A texture plan is nobody's today, and the base policy abstains on it. Answering
    // keeps the kind alive for whoever publishes one next.
    if(plan?.kind==='texture'){
      this.respondToPlan(plan,'accept',{createdAt:plan.createdAt,
        rationale:'GranularBOT reads texture plans as a density request for its grain cloud.'});
      const density=Number(plan.payload?.density);
      if(Number.isFinite(density))this.requestedDensity=clamp(density,0,1);
      return;
    }
    const result=super.onPlan(plan);
    // A stop is the one transition the ensemble knows about two phrases ahead.
    if(plan?.kind==='lifecycle'&&plan.payload?.phase==='proposal')
      this.endingAt=Number(plan.payload?.deadline?.bar??plan.appliesAt?.bar)||null;
    // PlexBOT names the next section one phrase early; that is the anticipation cue.
    if(plan?.kind==='rhythm'&&plan.payload?.formalRole)
      this.pendingRole=String(plan.payload.formalRole);
    return result;
  }
  mark(kind,scale=1){
    this.energy=clamp(Math.max(this.energy,CONFIG.weights[kind]*scale));
    this.lastMark=kind;
  }

  // ---- Playing -------------------------------------------------------------
  onTick(tick,clock){
    const meter=clock.meter||{},bpm=clock.bpm||bandTempo(),beatSeconds=60/bpm;
    if(clock.phraseStart&&clock.phrase!==this.lastPhrase){
      this.lastPhrase=clock.phrase;
      this.readForm(clock);
    }
    if(clock.barStart&&clock.bar!==this.lastBar){
      this.lastBar=clock.bar;
      this.mark('bar');
      // The ending is announced two phrases out: lean the whole way into it.
      if(this.endingAt!=null&&clock.bar>=this.endingAt-(meter.phraseBars||bandPhraseBars()))this.mark('ending');
    }
    if(!clock.beatStart)return;
    this.emitBeat(clock,beatSeconds);
    // Decay after playing, so the beat that marks a transition is played at the energy
    // the transition actually reached. Per beat, so a swell lasts the same number of
    // beats whatever the tempo.
    this.energy=clamp(this.energy*2**(-1/CONFIG.decayHalfLifeBeats),CONFIG.floor);
  }
  readForm(clock){
    if(this.lastPhrase!=null&&this.firstPhraseSeen==null){this.firstPhraseSeen=clock.phrase;this.mark('entry')}
    const progress=this.activeFormPlan?formProgress(this.activeFormPlan,clock):null;
    if(progress){
      if(this.lastSectionIndex!=null&&progress.sectionIndex!==this.lastSectionIndex){
        this.mark('section');this.announceTexture(clock);
      }
      this.lastSectionIndex=progress.sectionIndex;
      this.sectionRole=String(progress.sectionRole||this.pendingRole||'');
      this.sectionProgress=clamp(Number(progress.sectionProgress)||0);
      // Anticipation: the closer the section is to turning over, the more it leans in.
      if(this.sectionProgress>=CONFIG.anticipateFrom){
        const lean=(this.sectionProgress-CONFIG.anticipateFrom)/(1-CONFIG.anticipateFrom);
        this.energy=clamp(Math.max(this.energy,lean*.75));
      }
    }else this.mark('phrase');
    this.pendingRole=null;
  }
  // `texture` is a declared plan kind no agent has claimed. Announcing the cloud one
  // phrase ahead lets anyone who cares about density see it coming, and keeps this bot
  // a participant in planning without ever proposing form.
  announceTexture(clock={}){
    const meter=clock.meter||{},phraseBars=meter.phraseBars||bandPhraseBars();
    this.publishPlan('texture',{
      schemaVersion:1,source:'granular-corpus',role:this.sectionRole||'transition',
      density:Number(clamp(this.grainDensity()/CONFIG.maxDensity).toFixed(3)),
      grains:this.player?.report().grains??0,
    },{
      appliesAt:{bar:(clock.bar||0)+phraseBars,phrase:(clock.phrase||0)+1,section:clock.section||0},
      confidence:.6,priority:.35,
      rationale:'Grain cloud marking the section change; density follows transition energy.',
    });
  }
  // Which part of the gesture we are in decides what kind of grain it asks for: beds
  // while leaning in, attacks at the break, tones and tails on the way down.
  gesture(){
    const rising=this.energy>(this.previousEnergy??0);
    this.previousEnergy=this.energy;
    if(this.energy>=.7)return 'accent';      // the break itself
    if(rising)return 'texture';              // leaning into one
    return this.energy>=.25?'tone':'air';    // settling, then gone
  }
  // Not `density()`: the base agent stores the ensemble's requested density in
  // `this.density`, and an instance property would shadow a method of that name.
  grainDensity(){
    const requested=[this.spacePolicy?.density,this.requestedDensity,this.density]
      .map(Number).find(Number.isFinite);
    const policy=clamp(requested??.5,0,1);
    // Energy dominates; the ensemble's density request scales what that peak is worth.
    return CONFIG.maxDensity*this.energy**1.5*(.45+.55*policy);
  }
  // A beat's grains, counted exactly (the mathematical audit's B15 and X01; ExactGrainAccumulator): the cloud's rate over
  // the beat, the fraction of a grain it leaves carried into the next. Rounding each beat to a whole number of grains
  // silenced a low rate altogether (at 120 bpm, anything under one grain a second). Each grain sounds where the carried
  // count reaches it, so the cloud keeps its spacing across the beats however they cut it (a renewal process whose
  // waiting time carries over), each drawn back by a seeded jitter within most of its own spacing: a cloud should not
  // sound quantised, and it is reproducible from the ensemble seed. The cap is a capacity, maxGrainsPerBeat in a beat:
  // a beat asking for more plays that many, spread over it, and the excess is refused, not carried on as a backlog.
  emitBeat(clock,beatSeconds){
    if(!this.player?.ready)return;
    const role=this.gesture(),rate=this.grainDensity(),before=this.grainCarry??0;
    this.grainAccumulator??=new ExactGrainAccumulator();
    const counted=this.grainAccumulator.advance(exactOf(rate),exactOf(beatSeconds),{capacity:CONFIG.maxGrainsPerBeat});
    const count=counted.ok?counted.count:CONFIG.maxGrainsPerBeat;
    if(counted.ok)this.grainCarry=fraction(counted.remainder);
    if(count<=0)return;
    const pitches=(this.notes||[]).map(Number).filter(Number.isFinite),spacing=counted.ok&&rate>0?1/rate:beatSeconds/count;
    for(let index=0;index<count;index++){
      const due=counted.ok?(index+1-before)*spacing:beatSeconds*(index+1)/count;
      const at=Math.max(0,Math.min(beatSeconds,due-this.unit()*.9*spacing));
      this.emitGrain(role,pitches,at);
    }
  }
  unit(){return this.randomStream?this.randomStream.next():.5}
  emitGrain(role,pitches,at){
    if(!this.player?.ready)return;
    const velocity=clamp(.25+this.energy*.6,.1,.95);
    // A pitched target reads from the profile's pitch-class bucket; an attack is chosen
    // for its own character. Either way the pool is a ranked list built offline.
    let pool=this.player.poolFor(role);
    if(pitches.length&&role!=='accent'){
      // Prefer a grain whose own measured pitch already sits on a wanted pitch class.
      // A corpus rarely covers all twelve, so an empty bucket falls back to the role
      // pool rather than dropping the grain: the shift can voice any pitched grain.
      const offset=Math.floor(this.unit()*pitches.length);
      for(let step=0;step<pitches.length;step++){
        const bucket=this.player.pools.pitchClass(pitches[(offset+step)%pitches.length]);
        if(bucket.length){pool=bucket;break}
      }
    }
    const shortlist=Math.min(pool.length,64);
    if(!shortlist)return;
    const grain=pool[Math.floor(this.unit()*shortlist)],
      // The grain moves onto the chord by an exact fractional shift, never a rounded key.
      shift=pitches.length?grainChordShift(grain,pitches):null;
    this.scheduled+=this.player.schedule([{grain,at,shift,gain:velocity}],{gain:CONFIG.gain});
  }
}

export const granularBot=defineBot({
  id:'granular',
  name:'mh_GranularBOT',
  status:'native',
  source:'web-suite-extension',
  category:'texture-noise',
  performanceType:'polyphonic',
  outputModes:['samples'],
  // Its instrument is a corpus the server delivers, not a bank of one-note samples and
  // not a synth: with nothing decoded it has nothing to play, so it reports its state on
  // its card rather than substituting a different sound.
  requiresCorpus:true,
  pitchContract:'floating-mpe',
  planningCapabilities:{texture:true},
  // Asked by the interface before this bot is added, so a device that cannot play it
  // says so in the menu rather than after the fact. Any bot may expose one.
  availability:()=>corpusAvailability(),
  description:'Assembles a pre-analysed corpus of recorded grains, quiet between events and most active at transitions: it leans into an approaching section end, breaks at the join, and decays after.',
},(...args)=>new GranularBot(...args));

export {GranularBot};
