import {pulseHypothesesFromForecasts} from '../shared/estimation/pulse-hypotheses.js';
import {Agent, defineBot} from '../framework/index.js';
import {subscribeMidiInputs} from '../shared/midi-input.js';
import {randomUUID} from '../shared/random-id.js';
import {MidiObservationSource} from '../shared/estimation/midi-observer.js';
import {ObservationClockMapping} from '../shared/estimation/observations.js';
import {pulsePosition} from '../shared/estimation/continuous-models.js';
import {MidiHarmonicReplay} from '../shared/estimation/midi-harmonic-replay.js';
import {createHarmonyModel,observeHarmony} from '../shared/estimation/harmony-model.js';
import {serveInputQuery} from '../shared/estimation/input-report.js';
import {validCalibration} from '../shared/estimation/latency-calibration.js';
import {POCKET_SECONDS} from '../shared/estimation/beat-sync.js';
import {COORDINATIONS} from '../shared/estimation/input-report.js';
import {expressionProfile} from '../shared/performance-timing.js';
import {MidiInputAnalysis} from '../shared/estimation/midi-input-analysis.js';
import {HarmonyFollower} from '../shared/estimation/harmony-follower.js';
import {PerformerNotes,midiNote} from '../shared/performer-notes.js';
import {wasmAsset} from '../wasm-dsp.js';

// A human input source, distinct from the historical mh_MidiBOT generator.
// Permission and performer/device assignment are explicit local actions. No
// protocol message is permitted to open a device or impersonate that assignment.
//
// Once it listens with a harmonic vocabulary, it leads the ensemble's harmony with the chords it hears, as ListenerBot
// does (HarmonyFollower): a listening bot listens so that the ensemble can follow. leadHarmony(false) stops it. The
// vocabulary may be in any tuning (harmony-model.js); with none, only pitches are heard and nothing is led.
export class MidiInputBot extends Agent {
  constructor(send, audio, {navigatorObject=globalThis.navigator, now=()=>performance.now(), id=randomUUID,
    WorkerClass=globalThis.Worker,codecBytes=null,analysisOptions={}}={}) {
    super(send,audio);this.navigatorObject=navigatorObject;this.now=now;this.newId=id;
    Object.assign(this,{codecBytes,analysisOptions});
    // The bot registry scopes callable bot properties to a seeded stream.
    // Host constructors are dependencies, not bot methods to invoke with apply.
    this.analysisHost={WorkerClass};
    this.captureEpoch=null;this.state='idle';this.stopped=false;this.generation=0;
    this.inputSource=null;this.captureOptions=null;this.rejectedEvents=0;this.latestObservation=null;
    this.leadsHarmony=true;this.harmonyFollower=null;
  }
  status(state,message) {this.state=state;this.message=message;this.audio?.report?.('bot_status',{state,message});}
  start() {this.stopped=false;if(!this.navigatorObject?.requestMIDIAccess)this.status('unavailable','Web MIDI input is unavailable in this host.');
    else this.status('idle','Choose a MIDI input and performer to begin listening.');}
  // Capture follows the input timestamp, independently of transport ticks; the chords heard are announced on them.
  onTick(tick,clock) {this.sendHarmony(clock);this.sendNotes(clock);}
  // The performer's notes as their voice (/broadcast/voices, role 'performer', performer-notes.js): the highest note
  // held, where several are.
  sendNotes(clock) {
    if(!this.performerNotes)return;
    for(const {address,args} of this.performerNotes.flush(clock,this.now()/1000,this.audio?.clock?.lookahead??.25))this.send(address,args);
  }
  hearNote(bytes,timestamp) {
    const note=midiNote(bytes);if(!note)return;
    this.performerNotes??=new PerformerNotes({voice:`${this.instanceId??'midiInput'}:performer`});this.heldNotes??=new Set;
    const at=(Number.isFinite(timestamp)?timestamp:this.now())/1000;
    if(note.on!==undefined){this.heldNotes.add(note.on);this.performerNotes.start(at,Math.max(...this.heldNotes));}
    else{this.heldNotes.delete(note.off);if(this.heldNotes.size)this.performerNotes.start(at,Math.max(...this.heldNotes));else this.performerNotes.end(at);}
  }
  // Whether the chords this input plays lead the ensemble's harmony (the default, once a vocabulary interprets them).
  leadHarmony(enabled=true) {
    this.leadsHarmony=Boolean(enabled);
    const vocabulary=this.captureOptions?.harmonicVocabulary;
    this.harmonyFollower=this.leadsHarmony&&vocabulary?this.harmonyFollower||new HarmonyFollower({author:this.instanceId||'midiInput',vocabulary}):null;
    return Boolean(this.harmonyFollower);
  }
  // The harmony model's latest state: the analysis Worker's, or this thread's.
  currentHarmony() {
    if(this.analysis)return this.inputSource?.coverage==='complete'?this.analysis.snapshot()?.harmony??null:null;
    return this.harmonicProjection?.coverage==='complete'?this.harmony:null;
  }
  sendHarmony(clock) {
    if(!this.harmonyFollower||this.state!=='listening')return;
    const state=this.currentHarmony();
    if(state)for(const {address,args} of this.harmonyFollower.update(state,{clock:clock||{},at:this.now()/1000}))this.send(address,args);
  }
  onMessage(message) {
    this.refreshInputIdentity();
    if(serveInputQuery(this,message,{sourceNow:this.inputSource?.mapping.time(this.now())??0,now:this.now()/1000}))return;
    super.onMessage(message);
  }
  setIdentity(value) {super.setIdentity(value);this.refreshInputIdentity();}
  refreshInputIdentity() {
    const publisher=this.inputSource?.binding.publisher;
    if(!publisher||!this.captureOptions||this.inputSource.coverage!=='complete'||
      publisher.id===this.instanceId&&(!this.incarnation||publisher.incarnation===this.incarnation))return false;
    this.bindInput(this.captureOptions);
    this.status('listening','Publisher identity changed; waiting for fresh MIDI evidence.');
    return true;
  }
  async listMidiInputs() {
    if(this.stopped)throw new Error('This input bot has stopped.');
    if(!this.subscription){
      const generation=this.generation;
      this.permission ||= subscribeMidiInputs((bytes,time,input)=>this.receiveMidi(bytes,time,input),
        {navigatorObject:this.navigatorObject,onState:event=>this.deviceState(event)});
      let subscription;
      try {subscription=await this.permission;} finally {this.permission=null;}
      if(this.stopped||generation!==this.generation){subscription.close();throw new Error('Input permission arrived after this bot stopped.');}
      if(!subscription.access)throw new Error('This browser does not provide Web MIDI input. Open the local conductor in a browser with Web MIDI support.');
      this.subscription=subscription;
    }
    if(this.analysisHost.WorkerClass)this.codecBytes ||= await wasmAsset('wasm/midi2.wasm');
    else this.harmonicFactory ||= await MidiHarmonicReplay.prepare();
    if(this.stopped)throw new Error('This input bot stopped while its MIDI codec loaded.');
    return this.subscription.inputs.map(input=>({id:String(input.id),name:input.name||'MIDI input',manufacturer:input.manufacturer||''}));
  }
  bindInput({deviceId,performerId,timingMode='performance',referencePulse=pulsePosition(1,4),periodSeconds=0.5,
    possibleSelfOutput=false,clock=null,harmonicVocabulary=null,calibration=null,rhythm='midi-defaults',placementSeconds=null,lean=null,coordination='tight'}) {
    if(this.stopped||!this.instanceId)throw new Error('Wait for the input bot to join the conductor.');
    if(placementSeconds!==null&&!(Number.isFinite(placementSeconds)&&Math.abs(placementSeconds)<=POCKET_SECONDS))throw new RangeError(`A declared placement is within ${POCKET_SECONDS} s of the beat.`);
    // A lean over the phrase they declare, checked as a render's is ({ms, shape}), and how closely they ask to be followed.
    const leaning=lean===null?null:expressionProfile({lean:{instrument:'performer',...lean}}).lean;
    if(!COORDINATIONS.includes(coordination))throw new RangeError(`Coordination is ${COORDINATIONS.join(', ')}.`);
    const port=this.subscription?.inputs.find(input=>String(input.id)===deviceId);
    if(!port)throw new Error('Select a connected MIDI input.');
    if(this.analysisHost.WorkerClass?!this.codecBytes:!this.harmonicFactory)throw new Error('Scan MIDI inputs before binding an input.');
    const harmony=harmonicVocabulary?createHarmonyModel(harmonicVocabulary):null;
    // A loopback calibration belongs to one input device (and one output path);
    // it can only give a beat phase once this source's clock is session time.
    if(calibration&&validCalibration(calibration).inputDeviceId!==deviceId)throw new Error('That calibration was measured on another input.');
    this.captureEpoch ||= this.newId();
    // A clock bridge may be injected by a host. Otherwise this is explicitly a
    // local browser clock, never an invented remote/session synchronization.
    const mapping=clock?.mapping||new ObservationClockMapping({version:`local-${this.captureEpoch}`,inputUnits:'milliseconds',
      calibrationStatus:'unresolved-latency'});
    const sourceId=this.captureOptions?.deviceId===deviceId?this.captureOptions.sourceId:`midi-${this.newId()}`;
    const sourceOptions={sessionId:clock?.sessionId||`local-${this.captureEpoch}`,
      sourceId,sourceIncarnation:this.newId(),observerId:this.instanceId,
      publisher:{id:this.instanceId,incarnation:this.incarnation||this.captureEpoch},performerId,
      deviceId:sourceId,endpoint:sourceId,mapping,timingMode,referencePulse,periodSeconds,possibleSelfOutput,rhythm};
    const source=new MidiObservationSource({...sourceOptions,onObservation:observation=>{this.latestObservation=observation;}});
    const analysis=this.analysisHost.WorkerClass?new MidiInputAnalysis({...this.analysisOptions,sourceOptions,codecBytes:this.codecBytes,
      harmonicVocabulary,now:this.now,WorkerClass:this.analysisHost.WorkerClass,onFailure:reason=>{
        if(this.inputSource!==source)return;
        source.coverage='invalid';this.rejectedEvents++;this.lastError=reason;
        this.status('invalid','MIDI analysis interrupted; click Listen to start with fresh input coverage.');
      }}):null;
    if(this.inputSource?.coverage==='complete')this.inputSource.disconnect(this.now());
    this.analysis?.close();this.analysis=analysis;
    this.captureOptions={deviceId,performerId,timingMode,referencePulse,periodSeconds,possibleSelfOutput,sourceId,clock,harmonicVocabulary,calibration,placementSeconds,
      lean:leaning&&{ms:leaning.ms,shape:leaning.shape},coordination};
    this.harmonicProjection=analysis?null:this.harmonicFactory();this.harmony=analysis?null:harmony;
    this.inputSource=source;this.lastError=null;this.latestObservation=null;
    this.harmonyFollower=null;this.leadHarmony(this.leadsHarmony);
    this.status('listening',`Listening to ${port.name||'MIDI input'} for ${performerId}.`);return source.binding;
  }
  receiveMidi(bytes,timestamp,input) {
    if(this.stopped||this.state!=='listening'||String(input.id)!==this.captureOptions?.deviceId)return;
    try {
      this.refreshInputIdentity();
      this.hearNote(bytes,timestamp);
      if(this.analysis){this.analysis.enqueue(bytes,timestamp,this.now());return;}
      // timeStamp describes capture; callback entry determines availability.
      const availableAt=this.now(),observations=this.inputSource.midi1(bytes,timestamp,{availableAt});
      if(this.harmonicProjection.coverage!=='complete')return;
      const result=this.harmonicProjection.observe(observations[0]);
      if(!result.accepted&&this.harmonicProjection.coverage==='invalid')throw new Error(`Pitch coverage unavailable: ${result.reason}`);
      if(result.accepted&&this.harmony)this.harmony=observeHarmony(this.harmony,result.material);
    } catch(error) {
      this.rejectedEvents++;this.lastError=error.message;
      if(this.harmonicProjection?.coverage==='invalid')this.status('listening','Timing capture continues. Pitch tracking is unavailable; click Listen to start fresh.');
    }
  }
  deviceState({input,state}) {
    if(this.stopped||String(input.id)!==this.captureOptions?.deviceId)return;
    if(state==='disconnected'&&this.state==='listening'){
      this.inputSource.disconnect(this.now());this.status('missing','MIDI input disconnected. Waiting for this device to return.');
      this.analysis?.close();
      this.harmonicProjection?.disconnect(this.inputSource.mapping.time(this.now()));
    } else if(state==='connected'&&this.state==='missing') {
      try {this.bindInput(this.captureOptions);} catch(error) {this.status('missing',error.message);}
    }
  }
  disengageInput() {
    this.analysis?.close();
    if(this.inputSource?.coverage==='complete')this.inputSource.disconnect(this.now());
    if(this.harmonicProjection?.coverage==='complete')this.harmonicProjection.disconnect(this.inputSource.mapping.time(this.now()));
    this.captureOptions=null;this.harmonyFollower=null;this.status('idle','MIDI listening is off.');
  }
  // How closely the performer asks to be followed from now (tight, loose, or released for a cadenza), as they say it.
  declareCoordination(coordination){
    if(!COORDINATIONS.includes(coordination))throw new RangeError(`Coordination is ${COORDINATIONS.join(', ')}.`);
    if(!this.captureOptions)throw new Error('Bind an input before declaring how it is followed.');
    this.captureOptions={...this.captureOptions,coordination};return coordination;
  }
  inputSnapshot() {
    const source=this.inputSource,track=source?.replay?.current;
    const next=track?pulsePosition(Math.floor(track.pulse.numerator/track.pulse.denominator)+1):null;
    const evidence=this.analysis?.snapshot();
    // An injected host mapping puts capture times in session seconds; the default is this browser's own clock.
    const clockDomain=this.captureOptions?.clock?.mapping?'session-seconds':'source-local-seconds';
    const snapshot={state:this.state,message:this.message,rejectedEvents:this.rejectedEvents,lastError:this.lastError||this.lastQueryError||null,
      source:source?{...source.snapshot(),clockDomain}:null,calibration:this.captureOptions?.calibration??null,
      // The performer's word on where they sit against the beat (input-report.js), where they have given it, their lean
      // and how closely they ask to be followed.
      placementSeconds:this.captureOptions?.placementSeconds??null,lean:this.captureOptions?.lean??null,coordination:this.captureOptions?.coordination??null,
      forecast:track&&source.coverage==='complete'?source.forecast(next):null,
      rhythm:source?.rhythmForecast(source.mapping.time(this.now()))||null,pulse:source?.pulseForecast(source.mapping.time(this.now()))||null,
      // The same, as the rate contract's pulse hypotheses (shared/estimation/pulse-hypotheses.js): the level, the other
      // levels weighed and the beam's tracks, side by side, each with its own confidence.
      pulses:[],
      harmonicMaterial:this.harmonicProjection?.snapshot()||null,
      harmony:this.harmonicProjection?.coverage==='complete'?this.harmony:null,
      lastPackets:source?.raw.at(-1)?.packets||[],lastObservation:this.latestObservation?.observationId||null,
      timingMeaning:source?.timingMode==='performance'?'Alternative pulse interpretations; candidate scores are uncalibrated.':'Conditional on the selected declared pulse grid.',
      authority:'observation-only'};
    snapshot.pulses=snapshot.rhythm?pulseHypothesesFromForecasts(snapshot.rhythm):[];
    if(evidence){
      Object.assign(snapshot,evidence,{state:this.state,message:this.message,
        rejectedEvents:this.rejectedEvents+(evidence.rejectedEvents||0),lastError:this.lastError||evidence.lastError||this.lastQueryError||null,
        source:{...(evidence.source||source.snapshot()),coverage:source.coverage,clockDomain}});
      if(source.coverage!=='complete'){
        snapshot.forecast=null;snapshot.rhythm=null;snapshot.pulse=null;snapshot.pulses=[];snapshot.harmony=null;
        if(snapshot.harmonicMaterial)snapshot.harmonicMaterial={...snapshot.harmonicMaterial,coverage:source.coverage,notes:null};
      }
    }
    return snapshot;
  }
  stop() {
    this.disengageInput();this.stopped=true;this.generation++;
    this.subscription?.close();this.subscription=null;
  }
}

export const midiInputBot=defineBot({id:'midiInput',name:'MIDIInputBot',status:'native',category:'utility',outputModes:[],pitchContract:'none',
  description:'Performer-bound MIDI input retaining original UMP, with declared-tap and MIDI-clock timing estimates.',
  visualizers:[{id:'input-estimates',name:'Input estimates',module:'./input-estimates.js'}],
  planningCapabilities:{rhythm:false,harmony:false,form:false}},(send,audio,options)=>new MidiInputBot(send,audio,options));
