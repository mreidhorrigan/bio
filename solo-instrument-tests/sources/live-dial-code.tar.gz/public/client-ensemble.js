import {authoredTempo,copyAuthoredTempo,queueAuthoredTempo,authoredBpmAt,authoredTempoFields,validateAuthoredTempo} from './shared/score-tempo.js';
import {LocalTempoFollowing,updateLocalTempo,allowLocalTempoChange,curveBars} from './shared/estimation/local-tempo-following.js';
import {randomUUID} from './shared/random-id.js';
import {clampTempo} from './shared/tempo-range.js';
import sessionApi from './shared/ensemble-session.js';
import {ENSEMBLE_CONTROLS} from './shared/ensemble-conductor.js';
import {whenBar} from './shared/change-timing.js';
import {validateProtocolArgs} from './shared/protocol-schemas.js';
import {queueLocalMeter, sealLocalMeter, resetLocalMeter, meterChangeNotice} from './shared/estimation/local-meter-changes.js';
import {queueHold, releaseHold, readyHold, selectHold, takeAnnouncements, holdAtPulse, awaitingCue, settleHold} from './shared/clock-hold.js';
import {RUBATO_ADDRESSES, rubatoControl, takeRubatoAnnouncements, rubatoPulse, rubatoOwnsTempo} from './shared/rubato-clocks.js';
import {instanceSourced} from './shared/conducting/authority.js';
import {MEMBER_ADDRESS,GroupRoutes,scopeOf} from './shared/conducting/group-routing.js';
import {DEFAULT_SEED,openingTime} from './shared/opening-time.js';
const {EnsembleSession}=sessionApi;
const OPEN=1,CLOSED=3,MAX_RETAINED_PLANS=512;
// A hold's messages, which the clock itself answers (shared/clock-hold.js).
const HOLD_ADDRESSES=new Set(['/broadcast/hold','/broadcast/holdRelease','/broadcast/holdReady','/broadcast/holdSelect']);

class LocalSocket {
  constructor(ensemble){this.ensemble=ensemble;this.readyState=OPEN;this.listeners=new Map;queueMicrotask(()=>this.emit('open',{}))}
  addEventListener(type,listener){if(!this.listeners.has(type))this.listeners.set(type,new Set);this.listeners.get(type).add(listener)}
  emit(type,event){for(const listener of this.listeners.get(type)||[])listener(event)}
  deliver(message){this.emit('message',{data:JSON.stringify(message)})}
  send(value){if(this.readyState!==OPEN)return;this.ensemble.receive(this,JSON.parse(value))}
  close(){if(this.readyState===CLOSED)return;this.readyState=CLOSED;this.ensemble.leave(this);this.emit('close',{})}
}

// The one a message is for, where it is for one (server.js keeps the same rule): a plan's response its plan's author; a
// memory's transfer its target (an instance or a definition: MemoryBOT's stores sent to 'memory'); else null, every
// member. (Not every /agent/ message's target is its one recipient -- ManageBOT's /agent/load names the coordinator,
// for whoever loads bots -- so only these.)
export const routedTo=(address,args)=>address==='/broadcast/plan/response'?args?.[0]?.planAuthor??null
  :address==='/agent/memory/transfer'&&typeof args?.[0]?.target==='string'&&args[0].target!=='*'?args[0].target:null;
export class ClientEnsemble {
  // Its time where none is given: the opening of the default seed until its session's (opening(), shared/opening-time.js).
  constructor(meterApi=globalThis.MusebotMeter,{bpm,meter,meterPolicy}={}){this.meterApi=meterApi;this.meterPolicy=meterPolicy;const time=openingTime(DEFAULT_SEED);this.bpm=bpm??time.bpm;this.meter=meterApi.normalizeMeter(meter||time.meter);if(bpm===undefined&&!meter)this.openingTime={bpm:this.bpm,meter:this.meter};this.tick=0;this.bar=0;this.tickInBar=0;this.clients=new Map;this.protocolRefused=new Map;this.protocolUnregistered=new Map;this.parameters=new Map;this.nextClient=1;this.protocolSequence=0;this.timer=null;this.nextAt=0;this.pendingMeter=null;this.pendingTempoCurve=null;this.tempoCurve=null;this.holds=[];this.holding=null;this.session=new EnsembleSession();this.outputDelaySeconds=.25;this.scoreTempo=authoredTempo(this.bpm);
    this.localTempoFollowing=new LocalTempoFollowing(this,{active:()=>this.clients.size&&!this.gateway?.ensemble?.active(),
      send:(address,args)=>this.broadcast({...this.protocol('local-conductor',address,args),sourceIncarnation:this.localTempoFollowing.identity.incarnation,routing:{scope:'lan'}}),
      onChange:()=>{if(!this.localTempoFollowing.controller.enabled)clearInterval(this.followingTimer);this.broadcast({type:'tempo-following',status:this.localTempoFollowing.status()});},
      outputDelaySeconds:()=>this.outputDelaySeconds,proposeMeter:(value,mode,publisher)=>this.queueMeter(value,mode,publisher)});
  }
  tempoFollowingAction(request={}) {
    const following=this.localTempoFollowing;
    if(request.action==='follow-tempo'){
      // One source, or several followed together (their reports fused: input-fusion.js).
      for(const wanted of [request.source,...(Array.isArray(request.sources)?request.sources:[])]){
        const source=[...this.clients.values()].find(value=>value.instanceId===wanted?.id&&value.incarnation===wanted?.incarnation);
        if(!source||!['midiInput','listener','profile_clodbot'].includes(source.definitionId))throw new Error('Choose a connected local MIDIInputBot, ListenerBot or profile_clodbot.');
      }
      following.enable(request);this.startFollowingPump();
    }else if(request.action==='stop-following-tempo')following.controller.disable();
    else if(request.action==='checkpoint')return following.snapshot();
    else if(request.action&&request.action!=='status')throw new Error('Unknown local tempo action');
    return following.status();
  }
  // Live, following is pumped on a short timer; an offline render pumps it once per step instead (render/transport.js).
  startFollowingPump(){
    const following=this.localTempoFollowing;clearInterval(this.followingTimer);
    this.followingTimer=setInterval(()=>{try{following.pump();}catch(error){following.controller.disable(error.message);}},25);
  }
  prepare(options={}){const previous=this.session.startedAt,prepared=this.session.prepare(options);if(this.gateway?.ensemble?.active()){this.applySharedSession(this.gateway.ensemble.cursor);return {...prepared,...this.session.state()};}if(previous!==prepared.startedAt){this.opening();this.localTempoFollowing.reset('ensemble-restarted');this.stop();this.tick=0;this.bar=0;this.tickInBar=0;this.pulsed=false;this.parameters.clear();resetLocalMeter(this);this.pendingTempoCurve=null;this.tempoCurve=null;this.scoreTempo=authoredTempo(this.scoreTempo?.bpm??null);this.holds=[];this.holding=null}return prepared}
  // A session begun where no one has set the time: the session's opening (its meter, tempo and phrase from its seed).
  opening(){
    if(!this.openingTime||this.meter!==this.openingTime.meter||this.bpm!==this.openingTime.bpm)return;
    const time=openingTime(this.session.seed);this.bpm=time.bpm;this.meter=this.meterApi.normalizeMeter(time.meter);this.openingTime={bpm:this.bpm,meter:this.meter};this.scoreTempo=authoredTempo(this.bpm);
  }
  applySharedSession(state){if(!state)return;Object.assign(this.session,{seed:state.seed,startedAt:state.startedAt,firstBeatAt:state.startedAt,beat:state.beat,lastBeatTick:state.tick,endedAt:null});}
  sharedState({state}){if(!state)return;validateAuthoredTempo(state.scoreTempo);this.scoreTempo=copyAuthoredTempo(state.scoreTempo);if(this.localTempoFollowing.controller.enabled||this.inputTempoCommit)this.localTempoFollowing.reset('shared-conductor-reference');resetLocalMeter(this);this.applySharedSession(state);this.bpm=state.bpm;this.meter=state.meter;this.broadcast({type:'tempo',bpm:state.bpm,meter:state.meter});if(state.pendingMeter)this.broadcast({type:'meter_queued',...state.pendingMeter});this.broadcastSession();}
  sharedPulse(clock){this.sharedClockActive=true;this.scoreTempo=copyAuthoredTempo(clock.scoreTempo);this.stop();resetLocalMeter(this);Object.assign(this,{bpm:clock.bpm,meter:clock.meter,tick:clock.tick,bar:clock.bar,tickInBar:clock.tickInBar});this.applySharedSession({seed:clock.ensembleSeed,startedAt:clock.ensembleStartedAt,beat:clock.ensembleBeat,tick:clock.tick});this.gateway?.localClock(clock);this.broadcast({type:'clock',...clock,clientTime:Date.now()});}
  broadcastSession(){this.broadcast({type:'ensemble_session',ensemble:this.session.state(),clientTime:Date.now()})}
  connect(){return new LocalSocket(this)}
  receive(socket,message){
    if(message.type==='client_hello')return;
    if(message.type==='join'&&!this.clients.has(socket)){
      const client={id:String(this.nextClient++),room:String(message.room||'main').slice(0,64),agent:String(message.agent||'unknown').slice(0,64),definitionId:message.definitionId||message.agent,observer:message.observer===true||message.agent==='web-interface'};
      if(this.gateway&&client.room!==this.gateway.options.room){socket.deliver({type:'error',error:'Choose the room in the representative settings'});socket.close();return;}
      if(!client.observer){const key=message.key||this.prepare({seed:message.seed}).key;
        client.key=this.session.join(socket,{...message,id:message.definitionId||message.agent,key}).key;}
      client.instanceId=`${this.gateway?this.gateway.options.host+'::':''}${client.agent}:${client.key||client.id}`;
      client.incarnation=randomUUID();
      this.clients.set(socket,client);
      socket.deliver({type:'welcome',room:client.room,instanceId:client.instanceId,instanceIncarnation:client.incarnation,bpm:this.bpm,...authoredTempoFields(this),tick:this.tick,bar:this.bar,meter:this.meter,parameters:Object.fromEntries(this.parameters),ensemble:this.session.state()});
      socket.deliver(this.protocol('relay','/system/instance',[client.instanceId]));
      if(this.gateway)socket.deliver({type:'multinet',status:this.gateway.status()});
      for(const [key,state]of this.parameters)socket.deliver({...this.protocol(state.source,state.address||key,state.args),sourceIncarnation:state.sourceIncarnation,networkOrigin:state.networkOrigin});
      this.broadcast({type:'presence',agent:client.agent,state:'joined',count:this.clients.size},client.room);this.broadcastSession();this.start();return;
    }
    const client=this.clients.get(socket);if(!client)return;
    if(message.type==='multinet_clock_probe'){this.gateway?.clockProbe(client.instanceId,message.probe);return;}
    if(message.type==='ensemble_bot'){this.session.update(socket,message.bot);this.broadcastSession();return}
    if(message.type==='switch'){
      this.withdraw(client);
      if(this.localTempoFollowing.controller.input?.source?.id===client.instanceId)this.localTempoFollowing.controller.disable('source-left-or-restarted');
      client.agent=String(message.agent||client.agent).slice(0,64);client.definitionId=message.definitionId||client.agent;
      client.incarnation=randomUUID();
      socket.deliver({type:'switched',agent:client.agent,instanceId:client.instanceId,instanceIncarnation:client.incarnation});return;
    }
    if(message.type==='protocol'){
      const address=String(message.address||''),args=Array.isArray(message.args)?message.args:[];
      // A malformed message is refused, and its sender told why, as the server refuses one (protocol-schemas.js).
      const checked=validateProtocolArgs(address,args);
      if(!checked.valid){this.protocolRefused.set(address,(this.protocolRefused.get(address)??0)+1);socket.deliver({type:'protocol_error',address,errors:checked.errors});return}
      if(!checked.known)this.protocolUnregistered.set(address,(this.protocolUnregistered.get(address)??0)+1);
      if(ENSEMBLE_CONTROLS.has(address)&&this.gateway?.ensemble?.active()){
        this.gateway.ensemble.propose(address,args,{id:client.instanceId,incarnation:client.incarnation});return;
      }
      // (A span playing owns the tempo until it ends: allowLocalTempoChange.)
      if(address==='/broadcast/tempo'){if(!allowLocalTempoChange(this))return;this.bpm=clampTempo(Number(args[0])||this.bpm,this.meter);this.tempoCurve=null;this.pendingTempoCurve=null;this.scoreTempo=authoredTempo(this.bpm);this.broadcast({type:'tempo',bpm:this.bpm});}
      if(address==='/broadcast/timeSignature'){
        try{this.queueMeter(args[0],args[1],{id:client.instanceId,incarnation:client.incarnation});}
        catch(error){socket.deliver({type:'error',error:error.message});return;}
      }
      if(address==='/broadcast/tempoCurve')this.queueTempoCurve(args[0],args[1]);
      // A hold refused is not relayed: the bots would plan around a hold the clock will not keep.
      if(HOLD_ADDRESSES.has(address)){
        const outcome=this.holdControl(address,args[0],client.instanceId);
        if(outcome.rejected){socket.deliver({type:'error',error:outcome.rejected,address});return;}
      }
      // So is a span or a revision refused (shared/rubato-clocks.js), and the clock says so to every bot.
      if(RUBATO_ADDRESSES.has(address)){
        const outcome=this.rubatoControl(address,args[0]);
        if(outcome.rejected){socket.deliver({type:'error',error:outcome.rejected,address});this.announceRubato();return;}
      }
      // A seated player's group, kept for its routing and not relayed (shared/conducting/group-routing.js).
      if(address===MEMBER_ADDRESS){const group=args?.[0]?.group;if(typeof group==='string'&&group)client.groups=[group.slice(0,128)];return;}
      // Evidence consumers bind one publisher incarnation, not a display name
      // shared by several instances of the same input bot.
      // (And whatever carries authority, so that two bots of one kind are told apart where it decides: conducting/authority.js.)
      const protocol=this.protocol(this.gateway||address.startsWith('/agent/estimation/')||address.startsWith('/agent/profile/')||address==='/broadcast/timeSignature'||instanceSourced(address)?client.instanceId:client.agent,address,args);
      protocol.sourceIncarnation=client.incarnation;
      if(message.routing?.scope==='lan')protocol.routing={scope:'lan'};
      // (A plan's response to the plan's author, and a message to one agent -- a store sent to MemoryBOT -- to that agent,
      // each with whoever observes, not every bot: Musebots 3.0's fifth lack, a room's traffic growing with the square of
      // its band; to every bot where none in the room is the one it is for, by its instance or its definition.)
      // (And a message scoped to a group to its players and those of the groups below it, with everyone who said no group:
      // routing by group.)
      const to=routedTo(address,args),meant=other=>other.instanceId===to||other.definitionId===to,scope=scopeOf(address,args);
      (this.routes??=new GroupRoutes).hear(address,args);
      this.remember(protocol);
      if(to&&this.some(meant))this.broadcastTo(protocol,client.room,other=>other.observer||meant(other));
      else if(scope)this.broadcastTo(protocol,client.room,other=>other.observer||this.routes.hears(other.groups,scope));
      else this.broadcast(protocol,client.room);
      this.localTempoFollowing.receive(protocol);
      this.gateway?.localMessage(protocol,client.instanceId);
      // What the clock decided of it, after the message itself.
      if(HOLD_ADDRESSES.has(address))this.announceHolds();
      if(RUBATO_ADDRESSES.has(address))this.announceRubato();
    }
  }
  remember(message){if(!message.address.startsWith('/broadcast/')||message.address==='/broadcast/plan/response')return;const plan=message.address==='/broadcast/plan'?message.args?.[0]:null,isForm=message.address==='/broadcast/form'||message.address.startsWith('/broadcast/form/')||plan?.kind==='form';if(isForm)return;const key=plan?.author&&plan?.kind?`${message.address}#${plan.author}#${plan.kind}`:message.address,store=this.parameters;store.delete(key);store.set(key,{address:message.address,args:message.args,source:message.source,sourceIncarnation:message.sourceIncarnation,networkOrigin:message.networkOrigin});if(plan)while([...store.keys()].filter(value=>value.startsWith('/broadcast/plan#')).length>MAX_RETAINED_PLANS){const oldest=[...store.keys()].find(value=>value.startsWith('/broadcast/plan#'));store.delete(oldest)}}
  protocol(source,address,args){return{type:'protocol',source,address,args,clientTime:Date.now(),eventId:`client:${++this.protocolSequence}`}}
  broadcast(message,room){for(const [socket,client]of this.clients)if(!room||client.room===room)socket.deliver(message)}
  // To the clients of a room that `wanted` chooses; and a client by its instance.
  broadcastTo(message,room,wanted){for(const [socket,client]of this.clients)if((!room||client.room===room)&&wanted(client))socket.deliver(message)}
  some(wanted){for(const client of this.clients.values())if(wanted(client))return true;return false}
  withdraw(client){
    if(client.observer)return;
    const message={...this.protocol(client.instanceId,'/broadcast/agentState',[
      {instanceId:client.instanceId,incarnation:client.incarnation,state:'leaving'}]),sourceIncarnation:client.incarnation};
    this.broadcast(message,client.room);this.gateway?.localMessage(message,client.instanceId);
  }
  leave(socket){const client=this.clients.get(socket);if(!client)return;this.clients.delete(socket);this.withdraw(client);if(this.localTempoFollowing.controller.input?.source?.id===client.instanceId)this.localTempoFollowing.controller.disable('source-left');this.session.leave(socket);this.broadcast({type:'presence',agent:client.agent,state:'left',count:this.clients.size},client.room);this.broadcastSession();if(!this.clients.size)this.stop()}
  // **"opening": the meter and tempo a piece BEGINS in.** A change could only ever be queued for the next bar or the
  // next phrase, so bar 1 was always the default -- and mh_PlexBOT, which asks for "nextPhrase", spent its whole first
  // phrase in a 4/4 at the spec's tempo that it was never going to keep. An opening is applied at once if nothing has
  // pulsed yet, which is the case a render can always arrange. A live room has usually pulsed by the time its bots
  // have loaded, so during the FIRST PHRASE the tempo steps now and the meter takes the next bar line: the room is
  // still holding its players back (experiments/setup-phase/downbeat.js), hears that as a count-in, and enters on the
  // bar line where the new meter begins. After the first phrase there is no opening left to set, and it means what
  // "nextPhrase" means. A transport that has never heard of it reads it as "nextBar", which is a reasonable way to be
  // old. server.js keeps the same rule for a room it clocks itself.
  applyMeter(meter){this.meter=meter;this.broadcast({type:'meter_changed',meter,bar:this.bar});const message=this.protocol('client-conductor','/broadcast/meter',[meter]);this.parameters.set(message.address,{args:message.args,source:message.source});this.broadcast(message)}
  queueMeter(value={},mode='nextBar',publisher){
    const pending=queueLocalMeter(this,this.meterApi.normalizeMeter,value,mode,publisher);
    if(pending.applied)this.applyMeter(pending.meter);
    if(!pending.applied||pending.resolution==='unresolved')this.broadcast({type:'meter_queued',...pending});
    return pending;
  }
  closeMeterBoundary(){
    const before=this.meterDecision,changed=sealLocalMeter(this);
    if(this.meterDecision&&this.meterDecision!==before&&this.meterDecision.mode!=='opening')
      this.broadcast({type:'meter_queued',...meterChangeNotice(this.meterDecision)});
    if(changed)this.applyMeter(changed);
  }
  queueTempoCurve(value={},mode='nextBar'){if(rubatoOwnsTempo(this))return {rejected:true,reason:'a rubato span is queued or playing: it and a curve would both be the tempo'};if(!allowLocalTempoChange(this,{composed:true}))return {rejected:true,reason:this.lastTempoRejection};if(mode==='opening'){if(!this.pulsed||this.bar<this.meter.phraseBars){this.bpm=clampTempo(Number(value.targetBpm)||this.bpm,this.meter);this.tempoCurve=null;this.pendingTempoCurve=null;this.scoreTempo=authoredTempo(this.bpm);this.broadcast({type:'tempo',bpm:this.bpm,curveActive:false});return {targetBpm:this.bpm,targetBar:this.bar,opening:true}}mode='nextPhrase'}const remaining=mode==='nextPhrase'?(this.meter.phraseBars-(this.bar%this.meter.phraseBars)||this.meter.phraseBars):1;this.pendingTempoCurve={targetBpm:clampTempo(Number(value.targetBpm)||this.bpm,this.meter),durationBars:curveBars(value.durationBars),shape:['linear','easeInOut','exponential'].includes(value.shape)?value.shape:'easeInOut',targetBar:Math.max(this.bar+remaining,whenBar(mode)??0)};queueAuthoredTempo(this,this.pendingTempoCurve)}
  // A hold declared or cued (shared/clock-hold.js), kept by this clock, the page's or a render's. A declared one voids
  // a following window still collecting, as it would span the hold. -> {queued} / {resumeAt} or {rejected}.
  // Readiness (`sender`, the instance saying it) and a cue may move the re-entry: the clock is scheduled again for it.
  // A possible hold's branch is chosen here too. What the clock decides is announced (announceHolds).
  holdControl(address,value,sender=null){
    if(address==='/broadcast/hold'){const outcome=queueHold(this,value);if(outcome.queued)this.localTempoFollowing.invalidate('hold-declared');return outcome}
    if(address==='/broadcast/holdSelect')return selectHold(this,value);
    const outcome=address==='/broadcast/holdReady'?readyHold(this,sender,value,this.clockSeconds()):releaseHold(this,value,this.clockSeconds());
    if(outcome.resumeAt!=null){this.resumeHold();if(this.timer){clearTimeout(this.timer);this.timer=null;this.schedule()}}
    return outcome;
  }
  // What the clock decided of its holds, to every bot alike: its own messages (clock-hold.js takeAnnouncements).
  announceHolds(){for(const {address,args} of takeAnnouncements(this))this.broadcast(this.protocol('clock',address,args))}
  // A rubato span declared, or a revision of one (shared/rubato-clocks.js): a declared one voids a following window
  // still collecting, as a hold does. A networked ensemble's conductor keeps none yet, so its clocks refuse them.
  rubatoControl(address,value){
    const outcome=rubatoControl(this,address,value,{networked:Boolean(this.gateway?.ensemble?.active())});
    if(outcome.queued)this.localTempoFollowing.invalidate('rubato-declared');
    return outcome;
  }
  announceRubato(){for(const {address,args} of takeRubatoAnnouncements(this))this.broadcast(this.protocol('clock',address,args))}
  // The seconds of the clock's own time at which the pulse at `at` (ms) is emitted; a render gives its exact time.
  pulseSeconds(at){return at/1000}
  // The clock's own time in seconds, the time its pulses are scheduled in (a render's is its render time).
  clockSeconds(){return performance.now()/1000}
  // The re-entry of the hold the last pulse began: the next pulse comes the held pulse's own length after it. Once
  // decided (a known length at once, a cue, or the bound), onHoldResumed({at}) hears it (the MIDI clock's paused clocks);
  // until then the next pulse is its bound's, the latest it can be (a forecast's; schedule() waits on the bound itself).
  // (onHoldResumed once the re-entry can no longer move: its last leadSeconds, from which readiness is refused.)
  resumeHold(){
    const holding=this.holding;if(!holding)return;
    this.nextAt=((holding.resumeAt??holding.startedAt+holding.bound)+this.pulseInterval)*1000;
    clearTimeout(this.holdCommitTimer);this.holdCommitTimer=null;
    if(holding.resumeAt===null||holding.resumeHeard)return;
    const commit=()=>{if(this.holding!==holding||holding.resumeHeard)return;holding.resumeHeard=true;this.onHoldResumed?.({at:holding.resumeAt*1000,id:holding.id})};
    const wait=(holding.resumeAt-holding.leadSeconds)*1000-performance.now();
    if(holding.known||wait<=0)commit();else this.holdCommitTimer=setTimeout(commit,wait);
  }
  // Beat synchronization (when following with alignPhase) chooses a beat's tempo first; a tempo curve then applies.
  updateTempo(){const steered=this.localTempoFollowing.beforePulse();if(updateLocalTempo(this)!==null||steered!==null)this.broadcast({type:'tempo',bpm:this.bpm,curveActive:Boolean(this.tempoCurve)});}
  // A pulse lasts 60/bpm/subdivision at its own tempo and in its own meter, read before the bar advances: the pulse before
  // a bar line that changes the meter is the old bar's (the networked cursor, ensemble-cursor.js, reads it so too; it
  // was read after the new meter was in force, so that pulse took the new bar's length).
  // Authored metronome instructions have their own state. Following, phase corrections and rubato update the
  // playback clock, never this plan. Both states use the same curve evaluator.
  scoreBpmAtPulse(){return authoredBpmAt(this)}
  pulse(){if(!this.pulsed)this.closeMeterBoundary();this.pulsed=true;this.updateTempo();this.pulseScoreBpm=this.scoreBpmAtPulse();this.pulseInterval=60/this.bpm/this.meter.subdivision;const at=this.nextAt||performance.now(),held=holdAtPulse(this,at/1000);if(held?.begins)this.localTempoFollowing.invalidate('hold');
    // Inside a rubato span a pulse lasts what the span's map says, and its clock message carries that pulse's tempo; the
    // pulse after one goes on at its last density (shared/rubato-clocks.js).
    const rubato=rubatoPulse(this,this.pulseSeconds(at));this.rubatoNext=rubato?.next??null;
    if(rubato?.bpm){this.bpm=rubato.bpm;this.pulseInterval=60/this.bpm/this.meter.subdivision;this.localTempoFollowing.invalidate('rubato-ended');this.broadcast({type:'tempo',bpm:this.bpm,curveActive:false})}
    else if(rubato){this.pulseInterval=rubato.seconds;this.bpm=60/rubato.seconds/this.meter.subdivision;if(rubato.field.begins){this.spanHoldSeconds=0;this.localTempoFollowing.invalidate('rubato')}}
    const now=Date.now(),clock={...this.meterApi.clockContext(this),scoreBpm:this.pulseScoreBpm,scoreTempo:copyAuthoredTempo(this.scoreTempo),...(held?{held}:{}),...(rubato?{rubato:rubato.field}:{})};this.gateway?.localClock(clock);if(this.session.observeClock(clock,now))this.broadcastSession();const session=this.session.state(now);this.broadcast({type:'clock',...clock,clientTime:now,ensembleTime:session.elapsed,ensembleBeat:session.beat,ensembleFirstBeatAt:session.firstBeatAt,ensembleStartedAt:session.startedAt,ensembleSeed:session.seed});this.announceHolds();this.announceRubato();this.onPulse?.({at,ms:this.pulseInterval*1000,meter:this.meter,tick:this.tick,held:Boolean(this.holding)});this.tick++;this.tickInBar++;if(this.tickInBar>=this.meter.pulsesPerBar){this.tickInBar=0;this.bar++;this.closeMeterBoundary()}}
  schedule(){if(!this.clients.size||this.gateway?.ensemble?.active())return;const interval=60000/this.bpm/this.meter.subdivision;this.nextAt||=performance.now()+interval;
    // A cued hold with no cue yet waits for one until its bound, where the music goes on.
    const due=awaitingCue(this)?(this.holding.startedAt+this.holding.bound)*1000:this.nextAt;
    this.timer=setTimeout(()=>{if(awaitingCue(this)){settleHold(this);this.announceHolds();this.resumeHold();this.schedule();return}this.pulse();if(this.holding)this.resumeHold();else this.nextAt+=this.pulseInterval*1000;this.schedule()},Math.max(0,due-performance.now()))}
  resumeSharedClock(){
    const continuation=this.sharedClockActive?this.gateway?.ensemble?.localContinuation?.():null;
    if(continuation){
      this.sharedClockActive=false;
      const {session,...timing}=continuation;
      this.stop();resetLocalMeter(this);Object.assign(this,timing);this.applySharedSession(session);
      if(this.holding)this.resumeHold();
    }
    this.start();
  }
  start(){if(!this.timer)this.schedule()}
  // `onPulse({at, ms, meter, tick, held})` hears each pulse as it sounds (the page's MIDI clock out: shared/midi-clock.js;
  // a held pulse's clocks after its first wait for onHoldResumed), `onStop()` the clock stopping. A hold in progress is
  // abandoned with the clock; the holds declared ahead stay with the piece.
  stop(){if(this.localTempoFollowing?.controller.enabled||this.inputTempoCommit)this.localTempoFollowing.reset('local-clock-stopped-or-replaced');clearInterval(this.followingTimer);clearTimeout(this.timer);clearTimeout(this.holdCommitTimer);if(this.timer)this.onStop?.();this.timer=null;this.nextAt=0;this.holding=null;this.rubato=null;this.rubatoNext=null}
}

export const LOCAL_SOCKET_OPEN=OPEN;
