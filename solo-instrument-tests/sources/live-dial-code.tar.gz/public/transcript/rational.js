// Exact rationals for musical time: a position or a duration is n/d of a beat, never a float.
//
// Composition retains its fractions before projecting them to performance seconds. Capture and notation carry the
// same fractions; they never recover them from the sound. Numerators and denominators are safe integers. An operation
// whose reduced answer exceeds that range throws rather than rounding; intermediates use big integers.

const gcd=(a,b)=>{a=Math.abs(a);b=Math.abs(b);while(b){[a,b]=[b,a%b]}return a};
const safe=(value,what)=>{if(!Number.isSafeInteger(value))throw new RangeError(`Rational ${what} ${value} is outside the safe integer range`);return value};
// Past the safe range, big integers: a reduced fraction comes back as a rational if it fits, and throws if not.
const MAX=BigInt(Number.MAX_SAFE_INTEGER);
const bigGcd=(a,b)=>{if(a<0n)a=-a;if(b<0n)b=-b;while(b){[a,b]=[b,a%b]}return a};
const fromBig=(numerator,denominator,what)=>{
  const divisor=bigGcd(numerator,denominator)||1n,n=numerator/divisor,d=denominator/divisor;
  if(n>MAX||-n>MAX||d>MAX||-d>MAX)throw new RangeError(`Rational ${what} ${n}/${d} is outside the safe integer range`);
  return new Rational(Number(n),Number(d));
};

export class Rational {
  constructor(numerator,denominator=1){
    safe(numerator,'numerator');safe(denominator,'denominator');
    if(denominator===0)throw new RangeError('A rational cannot have a zero denominator');
    const divisor=gcd(numerator,denominator)||1,sign=denominator<0?-1:1;
    // -0 would make equal values compare unequal through Object.is and print as "-0".
    this.n=numerator===0?0:sign*numerator/divisor;this.d=sign*denominator/divisor;
    Object.freeze(this);
  }
  static of(value,denominator){
    if(value instanceof Rational)return value;
    if(denominator!==undefined)return new Rational(value,denominator);
    if(Array.isArray(value))return new Rational(value[0],value[1]??1);
    if(typeof value==='string'){
      const match=value.trim().match(/^(-?\d+)(?:\s*\/\s*(-?\d+))?$/);
      if(!match)throw new TypeError(`"${value}" is not a rational (write it as n or n/d)`);
      return new Rational(Number(match[1]),match[2]===undefined?1:Number(match[2]));
    }
    if(typeof value==='number'){
      if(Number.isInteger(value))return new Rational(value,1);
      throw new TypeError(`${value} is not an integer; supply an exact fraction or compose it with rational operations`);
    }
    if(value&&typeof value==='object'&&'n' in value&&'d' in value)return new Rational(value.n,value.d);
    throw new TypeError(`Cannot make a rational from ${value}`);
  }
  // An observational approximation by continued fractions: the first convergent within `tolerance` whose denominator
  // is at most `maxDenominator`, or null. It cannot establish a composer's intent and is not an authored-score input.
  static approximate(value,{tolerance=1e-9,maxDenominator=1e7}={}){
    if(!Number.isFinite(value))return null;
    const sign=value<0?-1:1,x=Math.abs(value);
    let h0=0,h1=1,k0=1,k1=0,rest=x;
    for(let step=0;step<64;step++){
      const whole=Math.floor(rest),h2=whole*h1+h0,k2=whole*k1+k0;
      if(k2>maxDenominator||!Number.isSafeInteger(h2))break;
      h0=h1;h1=h2;k0=k1;k1=k2;
      if(Math.abs(x-h1/k1)<=tolerance)return new Rational(sign*h1,k1);
      const fraction=rest-whole;if(fraction<1e-15)break;rest=1/fraction;
    }
    return k1&&Math.abs(x-h1/k1)<=tolerance?new Rational(sign*h1,k1):null;
  }
  static get ZERO(){return ZERO}
  static get ONE(){return ONE}
  // A product of safe integers is exact while it is a safe integer itself, and so is a sum of two; past that the
  // float arithmetic rounds, and the rounding can cancel back into range as a wrong answer (the mathematical audit's
  // I05: 9007199254740991/3 + -6004799503160661/2 is -1/6, and came back -1/3). So a sum past it is taken in big
  // integers and reduced before it is judged: one whose reduced form fits is exact, and one that does not throws.
  add(other){
    const o=Rational.of(other),divisor=gcd(this.d,o.d),left=this.n*(o.d/divisor),right=o.n*(this.d/divisor),
      denominator=this.d/divisor*o.d;
    if(Number.isSafeInteger(left)&&Number.isSafeInteger(right)&&Number.isSafeInteger(left+right)&&Number.isSafeInteger(denominator))
      return new Rational(left+right,denominator);
    return fromBig(BigInt(this.n)*BigInt(o.d/divisor)+BigInt(o.n)*BigInt(this.d/divisor),BigInt(this.d/divisor)*BigInt(o.d),'sum');
  }
  sub(other){return this.add(Rational.of(other).neg())}
  mul(other){const o=Rational.of(other),a=gcd(this.n,o.d)||1,b=gcd(o.n,this.d)||1;return new Rational(safe((this.n/a)*(o.n/b),'product'),safe((this.d/b)*(o.d/a),'denominator'))}
  div(other){const o=Rational.of(other);if(o.n===0)throw new RangeError('Division of a rational by zero');return this.mul(new Rational(o.d,o.n))}
  neg(){return new Rational(-this.n,this.d)}
  abs(){return this.n<0?this.neg():this}
  // By cross-multiplication, in floats while both products are safe integers and in big integers past that, so
  // two values compare even where their difference could not be held (1/9007199254740991 against 1/9007199254740990).
  cmp(other){const o=Rational.of(other);if(this.d===o.d)return Math.sign(this.n-o.n);
    const left=this.n*o.d,right=o.n*this.d;
    if(Number.isSafeInteger(left)&&Number.isSafeInteger(right))return Math.sign(left-right);
    const a=BigInt(this.n)*BigInt(o.d),b=BigInt(o.n)*BigInt(this.d);return a<b?-1:a>b?1:0}
  eq(other){const o=Rational.of(other);return this.n===o.n&&this.d===o.d}
  lt(other){return this.cmp(other)<0}
  le(other){return this.cmp(other)<=0}
  gt(other){return this.cmp(other)>0}
  ge(other){return this.cmp(other)>=0}
  min(other){const o=Rational.of(other);return this.le(o)?this:o}
  max(other){const o=Rational.of(other);return this.ge(o)?this:o}
  isZero(){return this.n===0}
  isInteger(){return this.d===1}
  sign(){return Math.sign(this.n)}
  floor(){return Math.floor(this.n/this.d)}
  ceil(){return Math.ceil(this.n/this.d)}
  // The part within the unit: x - floor(x), always in [0, 1).
  fraction(){return this.sub(this.floor())}
  // How many whole `unit`s fit, and what is left: a position split into a count of spans and the place within one.
  divmod(unit){const u=Rational.of(unit),count=this.div(u).floor();return [count,this.sub(u.mul(count))]}
  toNumber(){return this.n/this.d}
  toString(){return this.d===1?String(this.n):`${this.n}/${this.d}`}
  toJSON(){return this.toString()}
  valueOf(){throw new TypeError('A Rational has no implicit number value; use toNumber() or the comparison methods')}
}

const ZERO=new Rational(0,1),ONE=new Rational(1,1);
export const rational=(value,denominator)=>Rational.of(value,denominator);
export {gcd};
export const lcm=(a,b)=>safe(Math.abs(a/gcd(a,b)*b),'least common multiple');
// The prime factors of a positive integer, smallest first, with repeats: 12 -> [2, 2, 3].
export function primeFactors(value){
  let rest=Math.abs(Math.trunc(value));const factors=[];
  for(let prime=2;prime*prime<=rest;prime++)while(rest%prime===0){factors.push(prime);rest/=prime}
  if(rest>1)factors.push(rest);return factors;
}
// The largest power of two that divides an integer, and what is left: 24 -> {twos: 8, odd: 3}.
export function splitTwos(value){let odd=Math.abs(Math.trunc(value)),twos=1;while(odd&&odd%2===0){odd/=2;twos*=2}return {twos,odd}}
