// The musical core in Rust, installed before any bot plans (shared/musical-core-installed.js).
import "./shared/musical-core-installed.js";
import { BotRegistry, defineBot } from "./framework/index.js";
import { ConductorBot } from "./bots/conductor.js";
// Bots defined in their own module are registered here; the registry stays the single
// assembly point the interface reads.
import { granularBot } from "./bots/granular-bot.js";
import { midiInputBot } from "./bots/midi-input-bot.js";
import { listenerBot } from "./bots/listener-bot.js";
import { responseBot } from "./bots/response-bot.js";
import { profilerBot } from "./bots/profiler-bot.js";
// The clodbots, one file each (bots/clodbots/index.js says how to add or fork one).
import {
  ADDED_CLODBOTS, LATER_CLODBOTS, PITCH_LANGUAGE_CLODBOTS, defineAudioanalyzerClodbot, defineChichichiClodbot,
  defineDroneClodbot, defineEffectsClodbot, defineFormClodbot, defineMhdroneClodbot, defineNewbeatClodbot,
  definePapmelodyClodbot, definePappercClodbot, defineQuarterTempoClodbots, defineTangerinedreamClodbot,
  defineValencearousalClodbot, defineWalkingbassClodbot, defineXbassClodbot, defineXdrumClodbot, editClodbot,
  formantClodbot, hindemithClodbot, impressionistClodbot, interlockdrumClodbot, jazzvoicingClodbot, manageClodbot,
  motifprofilerClodbot, riffClodbot, romanticClodbot, harmonypulseClodbot, meterspaceClodbot, defineBowedStringClodbot, defineFluteClodbot, pianoClodbot,
  tunespaceClodbot, harmonyspaceClodbot, guitarClodbot, languagespaceClodbot, massClodbot, stylespaceClodbot, malletsClodbot, kalimbaClodbot, steelpanClodbot, timelineClodbot, shakerClodbot, congueroClodbot, timpaniClodbot, gongClodbot, batteryClodbot, acousmaticClodbot, talkingdrumClodbot, harpClodbot, accordionClodbot, harpsichordClodbot, stringsClodbot, plexClodbot, profileClodbot, defineWoodwindClodbot, defineBrassClodbot,
} from "./bots/clodbots/index.js";
import { STOCHASTIC_CONFIG as CONFIG } from "./stochastic-config.js";
// The bots' classes, one module a family (bots/families/), each re-exported here as it was when they were written in
// this file; the registry below is the single assembly point the interface reads.
import {
  AutechreBot, CleanBeatBot, ClumpyBeatBot, ElectronicBeatBot, HouseBeatBot, JazzBeatBot, MhBeatBot, MhBeatsynthBot,
  NewBeatBot, NoiseBeatBot, PapPercBot, PercBot, ProckRockBeadsBot, SampleBeatBot, XDrumBot, XPercBot,
} from "./bots/families/beat.js";
import {
  EBassBot, SnapBassBot, SplatterBassBot, SynthBassBot, WalkingBassBot, XBassBot,
} from "./bots/families/bass.js";
import {
  HarmonyPulseBot, MethenyChordBot, MilesChordBot, ModalChordBot, MozartChordBot, SwingChordBot, XChordBot,
} from "./bots/families/harmony.js";
import {
  ContourBot, CounterpointBot, DampPianoBot, LaverneBot, MSynthBot, MethenyMelodyBot, MultiSynthBot, OrnamentBot,
  PapMelody2Bot, PapMelody4Bot, PapMelodyBot, RSynthBot, ReichGuitarBot, ResynthBot, SeasonsArpyBot,
  SeasonsBrokenChordBot, SeasonsChordBot, SeasonsDroneBot, SeasonsSussyBot, SequencerBot, XSequencerBot,
} from "./bots/families/melody.js";
import { BowedBot, DroneBot, MhDroneBot, NewDroneBot, PadBot, RhodesBot, XPadBot } from "./bots/families/keys-pads.js";
import {
  AtmosphereBot, BleepBot, ChichichiBot, DeciderBot, DerivationsBot, FmTextureBot, GranuBot, GroanBot, RunglerBot,
  SweeperBot, TextureBot, TonicBot, VinylBot, WhinyBot, WindBot, WubBot,
} from "./bots/families/texture.js";
import { TangerineDreamBot, XProducerBot } from "./bots/families/composition.js";
import {
  AudioAnalyzerBot, BlankBot, EffectsBot, MidiAnalyzerBot, MidiBot, MidiGuitarInputBot, MonitorMessagesBot,
  ReassignMessagesBot, ServerBot, TemplateBot, ValenceArousalBot, VideoBot, WebBot,
} from "./bots/families/utility.js";
import { CoordBot, FormBot, MemoryBot, PlexBot, SpaceBot, TuneBot } from "./bots/families/planning.js";
import { registerDefinitions } from "./bots/families/definitions.js";
export {
  ElectronicBeatBot, JazzBeatBot, CleanBeatBot, ClumpyBeatBot, NoiseBeatBot, NewBeatBot, HouseBeatBot, PercBot,
  PapPercBot, MhBeatBot, MhBeatsynthBot, SampleBeatBot, AutechreBot, ProckRockBeadsBot, XDrumBot, XPercBot,
  WalkingBassBot, EBassBot, SnapBassBot, SynthBassBot, SplatterBassBot, XBassBot, ModalChordBot, MilesChordBot,
  SwingChordBot, MethenyChordBot, XChordBot, MozartChordBot, HarmonyPulseBot, SequencerBot, PapMelody2Bot, LaverneBot,
  PapMelodyBot, PapMelody4Bot, DampPianoBot, CounterpointBot, OrnamentBot, MSynthBot, RSynthBot, MultiSynthBot,
  ReichGuitarBot, MethenyMelodyBot, SeasonsArpyBot, SeasonsBrokenChordBot, SeasonsChordBot, SeasonsDroneBot,
  SeasonsSussyBot, ResynthBot, XSequencerBot, ContourBot, BowedBot, DroneBot, PadBot, NewDroneBot, MhDroneBot,
  RhodesBot, XPadBot, VinylBot, SweeperBot, FmTextureBot, TonicBot, WindBot, BleepBot, WhinyBot, GroanBot, WubBot,
  AtmosphereBot, TextureBot, GranuBot, ChichichiBot, DerivationsBot, DeciderBot, RunglerBot, XProducerBot,
  TangerineDreamBot, BlankBot, MonitorMessagesBot, ReassignMessagesBot, ValenceArousalBot, MidiAnalyzerBot, MidiBot,
  MidiGuitarInputBot, VideoBot, WebBot, ServerBot, TemplateBot, AudioAnalyzerBot, EffectsBot, PlexBot, FormBot,
  CoordBot, TuneBot, SpaceBot, MemoryBot,
};

const fixedPercussionMidi = new Set([
  "beat",
  "jazzBeat",
  "cleanBeat",
  "clumpyBeat",
  "noiseBeat",
  "newBeat",
  "houseBeat",
  "perc",
  "papPerc",
  "mhBeat",
  "mhBeatsynth",
  "autechre",
  "prockRock",
  "xDrum",
  "xPerc",
]);
const hybridMidi = new Set(["sampleBeat", "tangerineDream"]);
const port = (manifest, Type) =>
  defineBot(
    {
      status: "behavioural-port",
      source: "local-max-collection",
      pitchContract: manifest.outputModes?.includes("midi")
        ? hybridMidi.has(manifest.id)
          ? "hybrid-mpe-percussion"
          : fixedPercussionMidi.has(manifest.id)
            ? "fixed-percussion"
            : "floating-mpe"
        : "none",
      ...manifest,
    },
    (...args) => new Type(...args),
  );
// Clodbots (bots/clodbots/): forks of ported bots, kept as new bots so the ports keep their own algorithms.
const xdrumClodbot = defineXdrumClodbot(XDrumBot), walkingbassClodbot = defineWalkingbassClodbot(WalkingBassBot);
export const BOT_REGISTRY = new BotRegistry().registerMany([
  defineBot({
    id: "conductor", name: "mh_ConductorBOT", status: "native",
    source: "web-suite-extension", category: "conductor", outputModes: [], pitchContract: "none",
    description: "Participant for future musical coordination; the local host owns the shared network connection.",
  }, (...args) => new ConductorBot(...args)),
  port(
    {
      id: "modal",
      name: "ae_ModalChordBOT",
      category: "harmony",
      midiChannel: 1,
      outputModes: ["synth", "midi"],
      description:
        "Algorithmic static-modal harmony; broadcasts note pools and plans.",
    },
    ModalChordBot,
  ),
  port(
    {
      id: "miles",
      name: "ae_MilesChordBOT",
      category: "harmony",
      midiChannel: 2,
      outputModes: ["synth", "midi"],
      description: "Corpus-inspired pre-Bitches Brew harmony and chord plans.",
    },
    MilesChordBot,
  ),
  port(
    {
      id: "swingChord",
      name: "ae_SwingChordBOT",
      category: "harmony",
      midiChannel: 10,
      outputModes: [],
      description:
        "Silent Standards-corpus harmony agent publishing current chords, pitch-class probabilities, and phrase plans with section recall.",
    },
    SwingChordBot,
  ),
  port(
    {
      id: "methenyChord",
      name: "ae_MethenyChordBOT",
      category: "harmony",
      outputModes: [],
      description:
        "Silent Pat Metheny corpus harmony agent publishing current chords, pitch-class probabilities, and phrase plans with adjustable harmonic rhythm and section recall.",
    },
    MethenyChordBot,
  ),
  port(
    {
      id: "mozartChord",
      name: "ae_MozartChordBOT",
      category: "harmony",
      outputModes: [],
      description:
        "Silent Mozart corpus harmony agent publishing current chords, pitch-class probabilities, and phrase plans with initialization, on/off, and section recall.",
    },
    MozartChordBot,
  ),
  port(
    {
      id: "bowed",
      name: "ae_BowedBOT",
      category: "keys-pads",
      midiChannel: 5,
      outputModes: ["synth", "samples", "midi"],
      sampleBank: "bowed",
      description:
        "Sustained bowed-guitar/vibraphone texture following chord plans, note pools, tala, and density with separate bass and ascending chord registers.",
    },
    BowedBot,
  ),
  port(
    {
      id: "drone",
      name: "ae_DroneBOT",
      category: "keys-pads",
      midiChannel: 6,
      outputModes: ["synth", "midi"],
      description:
        "Monophonic sustained pad following chord plans or note-pool fallback, favoring phrase-common chord tones and smooth pitch continuity.",
    },
    DroneBot,
  ),
  port(
    {
      id: "pad",
      name: "ae_PadBOT",
      category: "keys-pads",
      midiChannel: 5,
      outputModes: ["synth", "midi"],
      description:
        "Sustained chord-plan pad whose voice count follows density and whose filter trajectory opens over the phrase.",
    },
    PadBot,
  ),
  port(
    {
      id: "newDrone",
      name: "ae_newDroneBOT",
      category: "keys-pads",
      midiChannel: 6,
      outputModes: ["synth", "midi"],
      description:
        "Sparse high-register drone that shares and interprets 16-cell activity intentions while choosing pitches from note pools.",
    },
    NewDroneBot,
  ),
  port(
    {
      id: "mhDrone",
      name: "mh_DroneBOT",
      category: "keys-pads",
      midiChannel: 6,
      outputModes: ["synth", "midi"],
      description:
        "Noisy wub drone with source-derived activity-dependent play/break durations, density-dependent tremolo, and smoothed ecosystem controls.",
    },
    MhDroneBot,
  ),
  port(
    {
      id: "sequencer",
      name: "ae_SequencerBOT",
      category: "melody",
      midiChannel: 1,
      outputModes: ["synth", "midi"],
      description:
        "Monophonic eighth- or sixteenth-note sequencer that walks an octave-expanded note pool and interprets density over arbitrary meters.",
    },
    SequencerBot,
  ),
  port(
    {
      id: "papMelody2",
      name: "PAP_MelodyBot2",
      category: "melody",
      midiChannel: 2,
      outputModes: ["synth", "midi"],
      description:
        "Tuplet melody synthesizer that listens for note-pool and density controls, then generates its own mode, phrase curve, and rhythm after bounded silence.",
    },
    PapMelody2Bot,
  ),
  port(
    {
      id: "laverne",
      name: "PAP_LaverneBOT",
      category: "melody",
      midiChannel: 7,
      outputModes: ["synth", "midi"],
      description:
        "Tuplet melody agent that follows shared note pools and density, becomes autonomous after bounded silence, and selects one of five source Laverne synthesizer presets per instance.",
    },
    LaverneBot,
  ),
  port(
    {
      id: "resynth",
      name: "bc.resynth_bot",
      category: "melody",
      midiChannel: 8,
      outputModes: ["synth", "midi"],
      description:
        "Sinusoidal resynthesis melody agent that publishes four-bar activity, pitch-class, contour, and tala intentions and interprets peers’ activity plans.",
    },
    ResynthBot,
  ),
  port(
    {
      id: "papMelody",
      name: "PAP_MelodyBot",
      category: "melody",
      midiChannel: 3,
      outputModes: ["synth", "midi"],
      description:
        "Three-register probabilistic melody ensemble that publishes its legacy modulation meter and density while mixing external-pool, urn, and bounded-walk voices.",
    },
    PapMelodyBot,
  ),
  port(
    {
      id: "papMelody4",
      name: "PAP_MelodyBot4",
      category: "melody",
      midiChannel: 4,
      outputModes: ["synth", "midi"],
      description:
        "Listening-or-sending tuplet melody agent that modulates through its embedded 13-scale lattice and optional major/minor modal inflections.",
    },
    PapMelody4Bot,
  ),
  port(
    {
      id: "dampPiano",
      name: "PAP_DampPianoBot",
      category: "melody",
      midiChannel: 5,
      outputModes: ["synth", "midi"],
      description:
        "Self-terminating 15-section damped-piano form with four changing registers, density curves, within-beat tuplets, and legacy section-meter publication.",
    },
    DampPianoBot,
  ),
  port(
    {
      id: "counterpoint",
      name: "PAP_CounterpointBot",
      category: "melody",
      midiChannel: 6,
      outputModes: ["synth", "midi"],
      description:
        "Finite five-voice scale counterpoint with changing register states, note-pool listening/fallback, within-beat tuplets, legacy meter messages, and source-compatible agent-off termination.",
    },
    CounterpointBot,
  ),
  port(
    {
      id: "ornament",
      name: "mh_OrnamentBOT",
      category: "melody",
      midiChannel: 7,
      outputModes: ["synth", "midi"],
      description:
        "Monophonic plucked ornament sequences using three-octave pitch-class expansion, density-sized stochastic onset lists, and change-sensitive note-pool/density ownership.",
    },
    OrnamentBot,
  ),
  port(
    {
      id: "msynth",
      name: "ae_MSynthBOT",
      category: "melody",
      midiChannel: 8,
      outputModes: ["synth", "midi"],
      description:
        "Finite-form monophonic synth using the exact shipped Metheny onset and contour corpora, phrase-plan interpretation, uneven-meter clipping, and per-appearance synth variation.",
    },
    MSynthBot,
  ),
  port(
    {
      id: "rsynth",
      name: "ae_RSynthBOT",
      category: "melody",
      midiChannel: 9,
      outputModes: ["synth", "midi"],
      description:
        "Finite-form rhythmic monophonic synth driven by the exact embedded weighted onset and pitch Markov corpora, with plan following and arbitrary-meter clipping.",
    },
    RSynthBot,
  ),
  port(
    {
      id: "multiSynth",
      name: "ae_MultiSynthBOT",
      category: "melody",
      midiChannel: 10,
      outputModes: ["synth", "midi"],
      description:
        "Four-part finite-form synth using metric onset selection, phrase density curves, independent registers, and coordinated density/form messages.",
    },
    MultiSynthBot,
  ),
  port(
    {
      id: "reichGuitar",
      name: "ae_ReichGuitarBOT",
      category: "melody",
      midiChannel: 11,
      outputModes: ["synth", "midi"],
      description:
        "Four-part process-guitar agent with source-derived neighbor-cell mutations, phase inheritance, Gaussian phrase density, sparse-voice compensation, and finite form.",
    },
    ReichGuitarBot,
  ),
  port(
    {
      id: "methenyMelody",
      name: "ae_MethenyMelodyBOT",
      category: "melody",
      midiChannel: 12,
      outputModes: ["synth", "midi"],
      description:
        "Finite-form Pat Metheny corpus melody with source onset/contour records, local corpus harmony, received-plan precedence, and current-chord note-pool publication.",
    },
    MethenyMelodyBot,
  ),
  port(
    {
      id: "seasonsArpy",
      name: "ae_Seasons_Arpy",
      category: "melody",
      midiChannel: 13,
      outputModes: ["synth", "midi"],
      description:
        "Seasons installation plucked arpeggiator following progress as phrase phase, arousal as onset probability, additive tala, and changing note pools.",
    },
    SeasonsArpyBot,
  ),
  port(
    {
      id: "seasonsBrokenChord",
      name: "ae_Seasons_BrokenChord",
      category: "melody",
      midiChannel: 14,
      outputModes: ["synth", "samples", "midi"],
      sampleBank: "seasonsBrokenChord",
      description:
        "Seasons held broken-chord agent: progress selects planned harmony, arousal selects one to four voices, and entrances are staggered within the first half of each chord.",
    },
    SeasonsBrokenChordBot,
  ),
  port(
    {
      id: "seasonsChord",
      name: "ae_Seasons_Chord",
      category: "melody",
      midiChannel: 15,
      outputModes: ["synth", "samples", "midi"],
      sampleBank: "seasonsChord",
      description:
        "Seasons bowed-chord agent following normalized chord plans with tala-derived attacks and arousal-scaled ascending voicings.",
    },
    SeasonsChordBot,
  ),
  port(
    {
      id: "seasonsDrone",
      name: "ae_Seasons_Drone",
      category: "melody",
      midiChannel: 16,
      outputModes: ["synth", "midi"],
      description:
        "Monophonic high Seasons drone anchored to the plan-common pitch class, with proportional chord spans and arousal-shortened entrances.",
    },
    SeasonsDroneBot,
  ),
  port(
    {
      id: "seasonsSussy",
      name: "ae_Seasons_Sussy",
      category: "melody",
      midiChannel: 16,
      outputModes: ["synth", "midi"],
      description:
        "Low monophonic Seasons pad reusing DroneBOT behaviour exactly three octaves below its high-register counterpart.",
    },
    SeasonsSussyBot,
  ),
  port(
    {
      id: "vinyl",
      name: "ae_VinylBOT",
      category: "texture-noise",
      outputModes: ["synth"],
      description:
        "Autonomous continuous vinyl-noise bed with rumble and sparse surface crackle; it sends and consumes no musical protocol controls.",
    },
    VinylBot,
  ),
  port(
    {
      id: "sweeper",
      name: "Hewitt_Sweeper_bot",
      category: "texture-noise",
      outputModes: ["synth"],
      description:
        "Autonomous white-noise resonant filter sweep triggered on a randomly selected bar boundary.",
    },
    SweeperBot,
  ),
  port(
    {
      id: "fmTexture",
      name: "k_FMBOT",
      category: "texture-noise",
      midiChannel: 9,
      outputModes: ["synth", "midi"],
      description:
        "Complementary FM/AM texture whose activity recedes around peers and whose timbre ramps change at phrase boundaries.",
    },
    FmTextureBot,
  ),
  port(
    {
      id: "tonic",
      name: "mh_TonicBOT",
      category: "texture-noise",
      midiChannel: 10,
      outputModes: ["synth", "midi"],
      description:
        "Microtonal whistling drone that takes activity-shaped breaks and assumes note-pool/density/activity publication after ten seconds without external control.",
    },
    TonicBot,
  ),
  port(
    {
      id: "wind",
      name: "mh_WindBOT",
      category: "texture-noise",
      outputModes: ["synth"],
      description:
        "Density-controlled layered filtered wind whose measured/estimated spectral centroid is published to the ensemble.",
    },
    WindBot,
  ),
  port(
    {
      id: "bleep",
      name: "mh_BleepBOT",
      category: "texture-noise",
      midiChannel: 11,
      outputModes: ["synth", "midi"],
      description:
        "Two-voice high-rate FM pulse texture following floating note pools, density, activity, and arousal while publishing its control state.",
    },
    BleepBot,
  ),
  port(
    {
      id: "whiny",
      name: "mh_WhinyBOT",
      category: "texture-noise",
      midiChannel: 12,
      outputModes: ["synth", "midi"],
      description:
        "Polyphonic additive cluster generator folding twenty jittered partials into one octave around a floating fundamental.",
    },
    WhinyBot,
  ),
  port(
    {
      id: "groan",
      name: "mh_GroanBOT",
      category: "texture-noise",
      midiChannel: 13,
      outputModes: ["synth", "midi"],
      description:
        "Four-voice cracked-stick physical-model texture driven by the exact weighted transposition and microtonal glide process.",
    },
    GroanBot,
  ),
  port(
    {
      id: "wub",
      name: "mh_WubBOT",
      category: "texture-noise",
      midiChannel: 14,
      outputModes: ["synth", "midi"],
      description:
        "Six-voice cracked-stick pluck network following floating note pools and publishing density, affect, centroid, and panning features.",
    },
    WubBot,
  ),
  port(
    {
      id: "atmosphere",
      name: "ae_AtmosphereBOT",
      category: "texture-noise",
      midiChannel: 15,
      outputModes: ["synth", "midi"],
      description:
        "Continuous atmospheric resonator following the lowest floating note-pool pitch; source soundscape files are absent upstream, so Web Audio supplies its excitation.",
    },
    AtmosphereBot,
  ),
  port(
    {
      id: "texture",
      name: "ae_TextureBOT",
      category: "texture-noise",
      midiChannel: 16,
      outputModes: ["synth", "midi"],
      description:
        "Eight-voice density-controlled granular texture using the exact 67-entry Bark-spectrum timbre database and floating note-pool pitches. The very large referenced SampleBank is not present upstream.",
    },
    TextureBot,
  ),
  port(
    {
      id: "granu",
      name: "mh_GranuBOT",
      category: "texture-noise",
      outputModes: ["synth"],
      description:
        "Three-voice chaotic granular slurp controlled by valence and arousal and publishing affect plus spectral centroid. It is intentionally non-pitched, so no artificial MIDI-note output is exposed.",
    },
    GranuBot,
  ),
  port(
    {
      id: "chichichi",
      name: "Chichichi",
      category: "texture-noise",
      outputModes: ["synth"],
      description:
        "Sixteen-cell supporting noise/percussion reservoir with random binary vectors and next/previous/any state transitions. Browser audio approximates its external-input delay, exciter, and ring modulation.",
    },
    ChichichiBot,
  ),
  port(
    {
      id: "derivations",
      name: "_derivationsBOT",
      category: "texture-noise",
      outputModes: ["synth", "samples"],
      sampleBank: "derivations",
      description:
        "Autonomous and input-responsive timbral-matching texture reconstructed from its shipped analysis databases, initialization preset, and 18 original rehearsal recordings.",
    },
    DerivationsBot,
  ),
  port(
    {
      id: "decider",
      name: "ob_DeciderMusebot",
      category: "texture-noise",
      outputModes: ["synth", "samples"],
      sampleBank: "decider",
      description:
        "Audio-feature-driven serialized decision network reconstructed from Java bytecode, using its actual BreathSoundEvent behavior and seven shipped breath samples.",
    },
    DeciderBot,
  ),
  port(
    {
      id: "blank",
      name: "blank_BOT",
      category: "template",
      midiChannel: 1,
      outputModes: ["synth", "midi"],
      description:
        "Minimal conforming Musebot template: publishes horizontal density and probabilistically selects floating pitches from received note pools for a triangle-wave voice.",
    },
    BlankBot,
  ),
  port(
    {
      id: "monitorMessages",
      name: "ae_MonitorMessagesBOT",
      category: "utility",
      outputModes: [],
      description:
        "Receive-only typed protocol inspector retaining bounded mc, agent, broadcast, and other message histories. It emits neither sound nor protocol messages.",
    },
    MonitorMessagesBot,
  ),
  port(
    {
      id: "reassignMessages",
      name: "ae_ReassignMessagesBOT",
      category: "utility",
      outputModes: [],
      description:
        "Silent user-configurable message transformer with source filtering, address reassignment, fixed-value replacement, and lossless argument forwarding.",
    },
    ReassignMessagesBot,
  ),
  port(
    {
      id: "valenceArousal",
      name: "ae_ValenceArousalBOT",
      category: "utility",
      outputModes: [],
      description:
        "Silent Seasons form controller broadcasting smoothed progress, valence, arousal, source-derived phrase lengths, additive tala, and synchronized meter proposals.",
    },
    ValenceArousalBot,
  ),
  port(
    {
      id: "midiAnalyzer",
      name: "ae_MIDIanalyzerBOT",
      category: "utility",
      outputModes: [],
      description:
        "Silent ten-feature MIDI stream analyzer with five-window smoothing, configurable feature-to-protocol mapping, and MPE-aware fractional pitch measurement.",
    },
    MidiAnalyzerBot,
  ),
  port(
    {
      id: "midiBot",
      name: "mh_MidiBOT",
      category: "utility",
      midiChannel: 1,
      outputModes: ["midi"],
      description:
        "Sixteen-voice conductor-reactive external-MIDI generator retaining source affect/density controls and carrying floating note pools through per-instance MPE.",
    },
    MidiBot,
  ),
  port(
    {
      id: "midiGuitarInput",
      name: "mh_MIDIGuitarInputBOT",
      category: "utility",
      outputModes: [],
      description:
        "MPE-aware guitar MIDI and microphone bridge publishing floating note pools, note-rate density, and smoothed audio activity with complete input cleanup.",
    },
    MidiGuitarInputBot,
  ),
  port(
    {
      id: "video",
      name: "mh_VideoBOT",
      category: "utility",
      outputModes: [],
      description:
        "Camera and network-reactive visual agent preserving the source fluid-video control mappings and publishing measured frame activity without generating sound.",
    },
    VideoBot,
  ),
  port(
    {
      id: "webBot",
      name: "mh_WebBOT",
      category: "utility",
      midiChannel: 2,
      outputModes: ["synth", "midi"],
      description:
        "Four-part browser-native developing-variation agent reconstructed from its shipped Index.html, with recursive ornamentation and explicitly microtonal pitch displacement.",
    },
    WebBot,
  ),
  port(
    {
      id: "serverBot",
      name: "ae_ServerBOT",
      category: "utility",
      outputModes: [],
      description:
        "Silent legacy LAN bridge policy: broadcasts pass both ways, conductor time passes master-to-slave only, loops are suppressed, and typed arguments—including floating pitches—remain lossless. Same-server browser peers already use the shared WebSocket room.",
    },
    ServerBot,
  ),
  port(
    {
      id: "templateBot",
      name: "mh_TemplateBOT",
      category: "template",
      outputModes: [],
      description:
        "Silent developer template retaining the source identity, self-echo filtering, typed message ingress, and off acknowledgement without inventing musical behaviour.",
    },
    TemplateBot,
  ),
  port(
    {
      id: "xProducer",
      name: "ae_xProducerBOT",
      category: "composition",
      outputModes: [],
      description:
        "Silent hierarchical x-ensemble producer generating section form, density curves, subpatterns, activation maps, initialization, progress, phrase length, and exit messages from extracted source tables.",
    },
    XProducerBot,
  ),
  port(
    {
      id: "xChord",
      name: "ae_xChordBOT",
      category: "harmony",
      outputModes: [],
      description:
        "Silent x-ensemble Metheny-corpus harmony planner with section-specific progression storage/recall, pitch probabilities, harmonic rhythm, lifecycle controls, and floating-point-safe plans.",
    },
    XChordBot,
  ),
  port(
    {
      id: "xDrum",
      name: "ae_xDrumBOT",
      category: "beat",
      midiChannel: 10,
      outputModes: ["synth", "samples", "midi"],
      sampleBank: "xDrum",
      description:
        "Producer-directed three-voice drum agent with source additive 2/3 tala, density-shaped onset subsets, section recall, lifecycle controls, and all 12 shipped drum samples.",
    },
    XDrumBot,
  ),
  xdrumClodbot,
  port(
    {
      id: "xBass",
      name: "ae_xBassBOT",
      category: "bass",
      midiChannel: 3,
      outputModes: ["synth", "samples", "midi"],
      sampleBank: "xBass",
      description:
        "Producer-directed tala bass with density-shaped onset selection, weighted note-pool choice, lifecycle controls, all 58 shipped samples, and fractional pitches retained through Web Audio, sample transposition, or MPE.",
    },
    XBassBot,
  ),
  port(
    {
      id: "xPad",
      name: "ae_xPadBOT",
      category: "keys-pads",
      midiChannel: 5,
      outputModes: ["synth", "samples", "midi"],
      sampleBank: "xPad",
      description:
        "Producer-directed ascending pad whose voice count follows density, duration follows harmonic rhythm, filter follows section progress, and floating pools reach all 58 shipped samples or MPE unchanged.",
    },
    XPadBot,
  ),
  port(
    {
      id: "xPerc",
      name: "ae_xPercBOT",
      category: "beat",
      midiChannel: 10,
      outputModes: ["synth", "samples", "midi"],
      sampleBank: "xPerc",
      description:
        "Producer-directed three-part percussion with duple phrase generation, symbolic eight-bar subpattern reuse, A–E state recall, modulated filter/delay, lifecycle controls, and nine shipped samples.",
    },
    XPercBot,
  ),
  port(
    {
      id: "xSequencer",
      name: "ae_xSequencerBOT",
      category: "melody",
      midiChannel: 1,
      outputModes: ["synth", "midi"],
      description:
        "Producer-directed 1970s eighth/sixteenth sequencer reusing arbitrary-meter pool walking, density masking, progress/lifecycle controls, five exact source synth presets, and microtonal Web Audio/MPE pitch.",
    },
    XSequencerBot,
  ),
  port(
    {
      id: "tangerineDream",
      name: "ae_TangerineDreamBOT",
      category: "composition",
      midiChannel: 2,
      outputModes: ["synth", "midi"],
      description:
        "Self-contained finite Tangerine Dream-like form integrating corpus harmony, additive tala, density-shaped part orchestration, drums, bass, melody, sequencer, and pad over arbitrary meter with unified microtonal Web Audio/MPE pitch.",
    },
    TangerineDreamBot,
  ),
  port(
    {
      id: "walkingBass",
      name: "ae_WalkingBassBOT",
      category: "bass",
      midiChannel: 3,
      outputModes: ["synth", "samples", "midi"],
      sampleBank: "walkingBass",
      description:
        "Acoustic-style walking bass reacting to harmony, tala, and density.",
    },
    WalkingBassBot,
  ),
  walkingbassClodbot,
  // Voice-leading clodbots (bots/clodbots/, their shared core bots/lib/voice-leading-bot.js): each hears the others'
  // voices and the bass's, and leads its own voices by a style. They follow the harmony; they do not lead it.
  romanticClodbot,
  impressionistClodbot,
  jazzvoicingClodbot,
  hindemithClodbot,
  // Rhythm clodbots (bots/clodbots/, their shared part bots/lib/rhythm-pattern-bot.js): they hear the performer's
  // attacks and the other bots' onsets and play patterns that fit them, chosen by an intended rhythmic dissonance.
  interlockdrumClodbot,
  riffClodbot,
  // A silent clodbot (bots/clodbots/motifprofiler_clodbot.js) that gathers the performer's phrases for mh_MemoryBOT.
  motifprofilerClodbot,
  port(
    {
      id: "eBass",
      name: "ae_EBassBOT",
      category: "bass",
      midiChannel: 4,
      outputModes: ["synth", "samples", "midi"],
      sampleBank: "eBass",
      description:
        "Electric-style bass reacting to harmony, tala, and density.",
    },
    EBassBot,
  ),
  port(
    {
      id: "snapBass",
      name: "ae_SnapBassBOT",
      category: "bass",
      midiChannel: 7,
      outputModes: ["synth", "midi"],
      description:
        "Short, sample-inspired bass attacks derived from the most common received pitch class and aligned with tala.",
    },
    SnapBassBot,
  ),
  port(
    {
      id: "synthBass",
      name: "ae_SynthBassBOT",
      category: "bass",
      midiChannel: 8,
      outputModes: ["synth", "midi"],
      description:
        "Tala-aligned synth bass using the first received pitch class, density-shaped onsets, and an extracted velocity contour.",
    },
    SynthBassBot,
  ),
  port(
    {
      id: "splatterBass",
      name: "ybot_splatterBOT",
      category: "bass",
      midiChannel: 9,
      outputModes: ["synth", "midi"],
      description:
        "Acid bass that proposes complementary 16-step activity intentions and shares pitch-class pools for the next phrase.",
    },
    SplatterBassBot,
  ),
  port(
    {
      id: "rhodes",
      name: "ae_RhodesBOT",
      category: "keys-pads",
      midiChannel: 5,
      outputModes: ["synth", "samples", "midi"],
      sampleBank: "rhodes",
      visualizers:[{id:'phrase',name:'Phrase position',module:'../examples/phrase-visualizer.js'}],
      description:
        "Rhodes-style keyboard voicings aligned with tala and density.",
    },
    RhodesBot,
  ),
  port(
    {
      id: "beat",
      name: "ae_BeatBOT",
      category: "beat",
      midiChannel: 10,
      outputModes: ["synth", "samples", "midi"],
      sampleBank: "beat",
      description:
        "Form-generating drums and percussion built from additive 2/3 tala.",
    },
    ElectronicBeatBot,
  ),
  port(
    {
      id: "jazzBeat",
      name: "ae_JazzBeatBOT",
      category: "beat",
      midiChannel: 11,
      outputModes: ["synth", "samples", "midi"],
      sampleBank: "jazzBeat",
      description:
        "Form-generating jazz-brush patterns built from additive tala.",
    },
    JazzBeatBot,
  ),
  port(
    {
      id: "cleanBeat",
      name: "ae_CleanBeatBOT",
      category: "beat",
      midiChannel: 12,
      outputModes: ["synth", "midi"],
      description:
        "Form-generating clean drums plus four percussion layers, with source-derived additive tala, phrase, density, and activation data.",
    },
    CleanBeatBot,
  ),
  port(
    {
      id: "clumpyBeat",
      name: "ae_ClumpyBeatBOT",
      category: "beat",
      midiChannel: 13,
      outputModes: ["synth", "midi"],
      description:
        "Five-part beat agent whose onsets expand progressively away from additive-tala downbeats as density rises.",
    },
    ClumpyBeatBot,
  ),
  port(
    {
      id: "noiseBeat",
      name: "ae_NoiseBeatBOT",
      category: "beat",
      midiChannel: 14,
      outputModes: ["synth", "midi"],
      description:
        "CleanBeat-family form and additive tala rendered with synthesized resonant noise drums and four noise-percussion layers.",
    },
    NoiseBeatBot,
  ),
  port(
    {
      id: "newBeat",
      name: "ae_newBeatBOT",
      category: "beat",
      midiChannel: 15,
      outputModes: ["synth", "midi"],
      description:
        "Four-bar drum and percussion agent that coordinates additive-sixteenth tala, repetition, and residual ensemble-activity intentions.",
    },
    NewBeatBot,
  ),
  port(
    {
      id: "houseBeat",
      name: "ae_HouseBeatBOT",
      category: "beat",
      midiChannel: 16,
      outputModes: ["synth", "midi"],
      description:
        "Eight-bar four-voice house patterns selected from the source 1,194-pattern corpus, with section generation and exact recall.",
    },
    HouseBeatBot,
  ),
  port(
    {
      id: "perc",
      name: "ae_PercBOT",
      category: "beat",
      midiChannel: 10,
      outputModes: ["synth", "midi"],
      description:
        "Three independent phrase-wide duple percussion layers with density masking, filter motion, amplitude walks, and beat-synchronized delay.",
    },
    PercBot,
  ),
  port(
    {
      id: "papPerc",
      name: "PAP_PercBot",
      category: "beat",
      midiChannel: 10,
      outputModes: ["synth", "midi"],
      description:
        "Probability-table percussion synth that follows ensemble density and takes bounded local density ownership after four silent bars.",
    },
    PapPercBot,
  ),
  port(
    {
      id: "mhBeat",
      name: "mh_BeatBOT",
      category: "beat",
      midiChannel: 10,
      outputModes: ["synth", "midi"],
      description:
        "Three-contour drum sequencer whose busyness follows density × √activity and whose activity-dependent breaks retain the source timing equations.",
    },
    MhBeatBot,
  ),
  port(
    {
      id: "mhBeatsynth",
      name: "mh_BeatsynthBOT",
      category: "beat",
      midiChannel: 10,
      outputModes: ["synth", "midi"],
      description:
        "Sparse bar-sequenced bass, snare, and metallic cymbal synthesizer with change-sensitive density fallback ownership.",
    },
    MhBeatsynthBot,
  ),
  port(
    {
      id: "sampleBeat",
      name: "ae_SampleBeatBOT",
      category: "beat",
      midiChannel: 10,
      outputModes: ["synth", "midi"],
      description:
        "Machine-loop monitor resonated at a pitch class selected from changing note pools, retaining source loop-duration and resonator-preset data.",
    },
    SampleBeatBot,
  ),
  port(
    {
      id: "autechre",
      name: "ae_AutechreBOT",
      category: "beat",
      midiChannel: 10,
      outputModes: ["synth", "midi"],
      description:
        "Self-forming processed drum agent with regenerated additive patterns, nonlinear density curves, and independently scheduled odd subdivisions.",
    },
    AutechreBot,
  ),
  port(
    {
      id: "prockRock",
      name: "ob_prockRockBeadsBot",
      category: "beat",
      midiChannel: 10,
      outputModes: ["synth", "samples", "midi"],
      sampleBank: "prockRock",
      prockRockMidiNotes: CONFIG.prockRock.midiNotes,
      description:
        "Java intention-sharing drum agent with delayed phrase planning and its original deterministic 96-sample drum-bead bank.",
    },
    ProckRockBeadsBot,
  ),
  port(
    {
      id: "rungler",
      name: "ae_RunglerBOT",
      category: "texture",
      midiChannel: 6,
      outputModes: ["synth", "midi"],
      description:
        "Unstable rungler-inspired synth controlled by valence and arousal.",
    },
    RunglerBot,
  ),
  port(
    {
      id: "analyzer",
      name: "ae_AudioAnalyzerBOT",
      category: "utility",
      outputModes: [],
      description:
        "Microphone feature analysis broadcast as ensemble messages.",
    },
    AudioAnalyzerBot,
  ),
  defineBot(
    {
      id: "effects",
      name: "ae_effectsBOT",
      status: "native",
      source: "web-suite",
      category: "utility",
      outputModes: ["synth"],
      pitchContract: "none",
      description:
        "Control-reactive effects monitor; cross-window audio routing is not yet implemented.",
    },
    (...args) => new EffectsBot(...args),
  ),
  defineBot(
    {
      id: "memory",
      name: "mh_MemoryBOT",
      status: "native",
      source: "web-suite-extension",
      category: "conductor",
      outputModes: [],
      previewOutputModes: Object.freeze(["synth", "midi"]),
      pitchContract: "none",
      planningCapabilities: { motif: true },
      specSettings: Object.freeze(["returns"]),
      description:
        "Stores complete MIDI 2.0 motifs and clips, answers direct bot requests, and previews stored material through synthesis or a selected MIDI output; it knows the home section's themes, and plans their returns where the form returns.",
    },
    (...args) => new MemoryBot(...args),
  ),
  defineBot(
    {
      id: "harmonyPulse",
      name: "mh_HarmonyPulseBOT",
      status: "native",
      source: "web-suite-extension",
      category: "harmony",
      midiChannel: 1,
      performanceType: "polyphonic",
      outputModes: ["synth", "midi"],
      pitchContract: "floating-mpe",
      description:
        "Curated harmony agent with bounded chord holds, regular but varied harmonic rhythm, and parsimonious voice leading.",
    },
    (...args) => new HarmonyPulseBot(...args),
  ),
  defineBot(
    {
      id: "contour",
      name: "mh_ContourBOT",
      status: "native",
      source: "web-suite-extension",
      category: "melody",
      midiChannel: 2,
      performanceType: "monophonic",
      outputModes: ["synth", "midi"],
      pitchContract: "floating-mpe",
      description:
        "Offbeat-responsive melody agent that bounds repeated notes, balances contour, and publishes developed motifs in advance.",
    },
    (...args) => new ContourBot(...args),
  ),
  defineBot(
    {
      id: "space",
      name: "mh_SpaceBOT",
      status: "native",
      source: "web-suite-extension",
      category: "conductor",
      outputModes: [],
      pitchContract: "none",
      planningCapabilities: { orchestration: true },
      description:
        "Message-only ensemble listener assigning complementary density, phase, and anchor/support/response roles each phrase.",
    },
    (...args) => new SpaceBot(...args),
  ),
  defineBot(
    {
      id: "plex",
      name: "mh_PlexBOT",
      status: "native",
      source: "web-suite",
      category: "conductor",
      outputModes: [],
      pitchContract: "none",
      description:
        "Message-only form agent proposing complex signatures, independent talas, phrase structures, densities, and rhythmic cycles.",
    },
    (...args) => new PlexBot(...args),
  ),
  defineBot(
    {
      id: "form",
      name: "mh_FormBOT",
      status: "native",
      source: "web-suite",
      category: "conductor",
      outputModes: [],
      pitchContract: "none",
      description:
        "Message-only duration and ending agent: proposes a finite tension-shaped form, polls readiness, and commits the ensemble’s logical stopping point at a phrase boundary.",
    },
    (...args) => new FormBot(...args),
  ),
  defineBot(
    {
      id: "tune",
      name: "mh_TuneBOT",
      status: "native",
      source: "web-suite",
      category: "conductor",
      outputModes: [],
      pitchContract: "none",
      planningCapabilities: { harmony: true },
      description:
        "Optional message-only tuning agent offering continuous floating-point tuning systems and voice-leading-aware chord-wise just intonation. Existing bots retain ordinary tuning when it is absent.",
    },
    (...args) => new TuneBot(...args),
  ),
  defineBot(
    {
      id: "coord",
      name: "mh_CoordBOT",
      status: "native",
      source: "web-suite",
      category: "conductor",
      outputModes: [],
      pitchContract: "none",
      description:
        "Optional mix coordinator assigning sounding agents continuous foreground, support, and background placements at phrase boundaries.",
    },
    (...args) => new CoordBot(...args),
  ),
  // ManageBOT, a clodbot (bots/clodbots/manage_clodbot.js): the casting director. Its id is `manage`, as it always was.
  manageClodbot,
  granularBot,
  midiInputBot,
  listenerBot,
  responseBot,
  profilerBot,
  // Bots added in bots/clodbots/ after these, at the registry's end: form_clodbot (made from the FormBot it forks), then
  // those listed in bots/clodbots/index.js, then papperc_clodbot (made from the PapPercBot it forks), then the later ones.
  defineFormClodbot(FormBot),
  ...ADDED_CLODBOTS,
  definePappercClodbot(PapPercBot),
  editClodbot,
  formantClodbot,
  ...LATER_CLODBOTS,
  // Forks of ported bots timed in the transport's own beats (bots/clodbots/index.js; the audit's B04).
  ...defineQuarterTempoClodbots({
    OrnamentBot, MSynthBot, RSynthBot, MultiSynthBot, ReichGuitarBot, MethenyMelodyBot, AutechreBot, WindBot,
    AtmosphereBot, TextureBot, GranuBot, DerivationsBot, SeasonsBrokenChordBot, SeasonsDroneBot,
  }),
  // Forks of ported bots with the audit's other findings (bots/clodbots/index.js), each made from the class it forks, in
  // the order they joined.
  defineMhdroneClodbot(MhDroneBot),
  defineXbassClodbot(XBassBot),
  defineNewbeatClodbot(NewBeatBot),
  defineChichichiClodbot(ChichichiBot),
  defineValencearousalClodbot(ValenceArousalBot),
  defineDroneClodbot(DroneBot),
  defineTangerinedreamClodbot(TangerineDreamBot),
  // Clodbots that play the pitch languages (bots/clodbots/index.js; docs/PITCH_LANGUAGES.md).
  ...PITCH_LANGUAGE_CLODBOTS,
  // A melody that restates its own theme where the form returns to it (bots/clodbots/papmelody_clodbot.js).
  definePapmelodyClodbot(PapMelodyBot),
  // ae_effectsBOT's work done on the ensemble's parts: another bot's audio through its effects (bots/clodbots/effects_clodbot.js).
  defineEffectsClodbot(EffectsBot),
  // ae_AudioAnalyzerBOT's descriptors as its patch computed them, each sent as its menu chose (bots/clodbots/audioanalyzer_clodbot.js).
  defineAudioanalyzerClodbot(AudioAnalyzerBot),
  // mh_HarmonyPulseBOT's chords counted in felt beats, so a large meter has harmony throughout (bots/clodbots/harmonypulse_clodbot.js).
  harmonypulseClodbot,
  // meterform_clodbot's home moving through the whole space of meters, and parts modulated apart (bots/clodbots/meterspace_clodbot.js).
  meterspaceClodbot,
  // A bowed string, its line's bow planned, carrying the melody's principles to another instrument (the user, 28 September:
  // "we should use other instruments for testing"; bots/clodbots/bowedstring_clodbot.js).
  defineBowedStringClodbot(),
  // The instrument clodbots (research/family-atlas.md): a pianist first, its two hands planned (bots/clodbots/piano_clodbot.js).
  pianoClodbot,
  // A transverse flute, its line's breaths planned (bots/clodbots/flute_clodbot.js).
  defineFluteClodbot(),
  // mh_TuneBOT's tuning moving through the space of tunings, by jumps and states between (bots/clodbots/tunespace_clodbot.js).
  tunespaceClodbot,
  // A harmony source whose collection moves through the space of pitch collections (bots/clodbots/harmonyspace_clodbot.js).
  harmonyspaceClodbot,
  // A guitarist, its chord shapes ones its hand can hold (bots/clodbots/guitar_clodbot.js).
  guitarClodbot,
  // A line whose pitch language moves through the space of languages, by jumps and states between
  // (bots/clodbots/languagespace_clodbot.js).
  languagespaceClodbot,
  // A section of up to eight lines, micropolyphony or glissando masses (bots/clodbots/mass_clodbot.js).
  massClodbot,
  // The ensemble's character moving through the space of characters, by jumps and states between
  // (bots/clodbots/stylespace_clodbot.js).
  stylespaceClodbot,
  // A mallet player (marimba, vibraphone, xylophone, glockenspiel), its voicings ones two hands hold with four mallets
  // (bots/clodbots/mallets_clodbot.js).
  malletsClodbot,
  // A kalimba player, its chords ones two thumbs pluck at once and its figure a cycle they share by turns
  // (bots/clodbots/kalimba_clodbot.js).
  kalimbaClodbot,
  // A steelpan player on a tenor pan, its line's sticking planned with it, its long notes rolled
  // (bots/clodbots/steelpan_clodbot.js).
  steelpanClodbot,
  // A timeline player: a bell, an agogo, the claves or a triangle in a maximally even pattern the band orients itself
  // by (bots/clodbots/timeline_clodbot.js).
  timelineClodbot,
  // A shaker player: its hand swinging back and forth without stopping, each reversal a stroke
  // (bots/clodbots/shaker_clodbot.js).
  shakerClodbot,
  // A conga player: one hand rocking heel and tip, the other's slap and open tones, a figure built as the tumbao is
  // (bots/clodbots/conguero_clodbot.js).
  congueroClodbot,
  // A timpanist, its drums tuned by their pedals to the band's tonic and dominant in time, its two sticks by turns
  // (bots/clodbots/timpani_clodbot.js).
  timpaniClodbot,
  // A gong player: the form's joins and its cycles of phrases, each stroke as hard as the music arrives
  // (bots/clodbots/gong_clodbot.js).
  gongClodbot,
  // A talking drummer: phrases on the three tones its squeeze reaches, its one stick and its arm by construction, a note
  // its arm has not reached glided the rest of the way (bots/clodbots/talkingdrum_clodbot.js).
  talkingdrumClodbot,
  // A harpist on a concert pedal harp: voicings four fingers a hand can pluck, spelled on pedals its feet set in time,
  // rolled chords, runs along the pedals' scale (bots/clodbots/harp_clodbot.js).
  harpClodbot,
  // An accordionist: the Stradella basses by the meter's groups, one bellows for both hands
  // (bots/clodbots/accordion_clodbot.js).
  accordionClodbot,
  // A harpsichordist: the pianist's hands on a harpsichord, its chords arpeggiated, its pluck at one level, no pedal
  // (bots/clodbots/harpsichord_clodbot.js).
  harpsichordClodbot,
  // An orchestra's string section, a few seats a bot, its concertmaster choosing how it divides and what each part plays
  // (bots/clodbots/strings_clodbot.js).
  stringsClodbot,
  // The conductorbot (Musebots 3.0, docs/MUSEBOTS_3.md): mh_PlexBOT's sections planned as far ahead as its horizon, from a
  // phrase to the whole piece, played through to an ending; nestable (bots/clodbots/plex_clodbot.js).
  plexClodbot,
  // A profile of the person the band plays with (Musebots 3.0): ListenerBot's hearing, and what it hears of them said as
  // one profile that conductors plan contingencies on (bots/clodbots/profile_clodbot.js).
  profileClodbot,
  // A fixed-media performer: approved recordings made into families of transformations, set in relations in free time,
  // each event moved between the speakers (bots/clodbots/acousmatic_clodbot.js).
  acousmaticClodbot,
  // A reed player and a brass player, the flute's player with their families' instruments, for the orchestra's winds
  // and brass (bots/clodbots/woodwind_clodbot.js, brass_clodbot.js).
  defineWoodwindClodbot(),
  defineBrassClodbot(),
  // An orchestral percussionist on the battery (bass drum, cymbals, snare, suspended cymbal, tambourine, triangle), the
  // instrument its section's conductor casts it on a phrase at a time (bots/clodbots/battery_clodbot.js).
  batteryClodbot,
]);
export const AGENTS = BOT_REGISTRY.object();
// A bot's former ids (its manifest's `aliases`: ManageBOT's `manage`, now manage_clodbot) still name it wherever an id
// is looked up (a spec, a saved ensemble, a link, a page), but they are not bots of their own: not listed, not counted.
for (const definition of Object.values(AGENTS))
  for (const alias of definition.aliases || [])
    if (!Object.hasOwn(AGENTS, alias)) Object.defineProperty(AGENTS, alias, { value: definition, enumerable: false });
registerDefinitions(AGENTS);
