// A formant filter: a voice's formants laid over a sound, in their shape and in their movement. The user, 26 September
// 2026: "Expressive LFOs, including vocal formant filters, are another such edge case - mixbot for now, but might
// eventually need to be split off. The purpose of a formant filter is to mimic vocal formants both in EQ shape and with
// modulation."
//
// A parallel bank of band-pass filters, one for each of a vowel's formants (shared/vowel-formants.js), each at its
// formant's frequency, with its bandwidth (Q = frequency / bandwidth) and its level, summed, and raised to the dry
// sound's level for a pink spectrum (formantMakeup). `depth` crossfades the dry sound (0) with the formants (1). Every
// value is a ramped parameter, so a vowel moves without a click; a course of vowels is scheduled ahead, point by point,
// from the moment it is asked for, replacing whatever was scheduled from then on, and ramping on from where the course
// before it had come to (the first held where the filter stands when it is asked for).
import {formantMakeup,vowelFormants} from './shared/vowel-formants.js';

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const FORMANT_FILTER=Object.freeze({
  formants:5,          // the table's five
  rampSeconds:.02,     // a change unless asked otherwise (a 50 Hz control rate: a vowel glides, it does not step)
  lowestHz:20,         // no band under this,
  highestShare:.95,    // nor over this share of the Nyquist frequency
  voice:'tenor',vowel:'a',
});
const DB_AMPLITUDE=20,amplitude=db=>10**(db/DB_AMPLITUDE);

// Each band's settings and the two gains for a vowel's formants at a depth: {bands: [{hz, q, gain}], dry, wet}.
export function formantSettings(formants,depth,{nyquist=Infinity}={}){
  const makeup=amplitude(formantMakeup(formants)),d=Math.max(0,Math.min(1,Number(depth)||0));
  return {bands:formants.hz.map((hz,k)=>({hz:Math.max(FORMANT_FILTER.lowestHz,Math.min(hz,nyquist*FORMANT_FILTER.highestShare)),q:hz/formants.bw[k],gain:amplitude(formants.db[k])*makeup})),dry:1-d,wet:d};
}

export function createFormantFilter(context,{voice=FORMANT_FILTER.voice,vowel=FORMANT_FILTER.vowel,depth=0}={}){
  const input=context.createGain(),output=context.createGain(),dry=context.createGain(),wet=context.createGain(),nyquist=context.sampleRate/2;
  input.connect(dry);dry.connect(output);wet.connect(output);
  const bands=Array.from({length:FORMANT_FILTER.formants},()=>{
    const filter=context.createBiquadFilter(),gain=context.createGain();filter.type='bandpass';
    input.connect(filter);filter.connect(gain);gain.connect(wet);return {filter,gain};
  });
  const params=settings=>[[dry.gain,settings.dry],[wet.gain,settings.wet],...bands.flatMap(({filter,gain},k)=>{const band=settings.bands[k];
    return [[filter.frequency,band.hz],[filter.Q,band.q],[gain.gain,band.gain]]})];
  // At once, before anything is scheduled.
  for(const [param,value] of params(formantSettings(vowelFormants(voice,vowel),depth,{nyquist})))param.value=value;
  const every=()=>[dry.gain,wet.gain,...bands.flatMap(({filter,gain})=>[filter.frequency,filter.Q,gain.gain])];
  let scheduled=false;
  return {input,output,kind:'formant',name:'Formant filter',
    // One setting ({voice, vowel (a vowel or a path), position, depth}), reached over `seconds` from `atSeconds`.
    set(values={},{atSeconds=context.currentTime,seconds=FORMANT_FILTER.rampSeconds}={}){
      const settings=formantSettings(vowelFormants(values.voice??voice,values.vowel??vowel,values.position??0),values.depth??depth,{nyquist});
      for(const [param,value] of params(settings)){param.cancelScheduledValues?.(atSeconds);param.setValueAtTime(param.value,atSeconds);param.linearRampToValueAtTime(value,atSeconds+seconds)}
    },
    // A course: points [{at (seconds), formants ({hz, db, bw}), depth}], each ramped to from the one before; whatever
    // was scheduled from the first point on is replaced, its first point ramped to from the course before's last.
    schedule(points){
      if(!points.length)return;
      const from=points[0].at;
      for(const param of every()){param.cancelScheduledValues?.(from);if(!scheduled)param.setValueAtTime(param.value,from)}
      scheduled=true;
      for(const point of points)for(const [param,value] of params(formantSettings(point.formants,point.depth,{nyquist})))param.linearRampToValueAtTime(value,point.at);
    },
  };
}
