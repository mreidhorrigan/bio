// Measured levels of the WAMs this machine has, written by `node scripts/wam-kit.mjs calibrate` (docs/WAM_KIT.md); do not
// edit by hand. Keyed by the plugin's descriptor identifier, so a downloaded copy and the hosted original share one.
// trimDb is the gain the host puts after the plugin (synths/wam.js, effect-plugins.js):
// - an instrument: what brings the bots that play it to the loudness they have with the built-in voice, with its peaks
//   kept below -3 dBFS;
// - an effect: what keeps its return at least 6 dB below the dry mix it hears (never a boost).
// voices: an instrument's other roles, measured apart and keyed by the channel or program they play (synths/wam.js
// wamVoiceKey): a General MIDI synthesizer's drums on channel 9 and its bass program need their own trims.
// A plugin not listed plays at 0 dB; a render's synth or effects.plugin option trimDb overrides.
export const WAM_LEVELS=Object.freeze({
  "com.sequencerParty.drumComputer":{"trimDb":-21.7,"kind":"instrument","name":"DRM-16 DrumComputer","url":"vendor/wam-community/burns-audio/drumsampler/index.js","measured":{"botsRmsDb":-17.8,"builtInRmsDb":-14.4,"botsPeakDb":-1.2}},
  "com.sequencerParty.microverb":{"trimDb":-1.4,"kind":"effect","name":"Microverb","url":"vendor/wam-community/burns-audio/reverb/index.js","measured":{"returnDb":-4.6}},
  "com.sequencerParty.modal":{"trimDb":2.1,"kind":"instrument","name":"Spectrum: Modal","url":"vendor/wam-community/burns-audio/modal/index.js","measured":{"botsRmsDb":-38.2,"builtInRmsDb":-21.3,"botsPeakDb":-4.9}},
  "com.sequencerParty.simpleDelay":{"trimDb":-1.1,"kind":"effect","name":"Simple Delay","url":"vendor/wam-community/burns-audio/delay/index.js","measured":{"returnDb":-4.9}},
  "com.sequencerParty.simpleDistortion":{"trimDb":0,"kind":"effect","name":"Simple Distortion","url":"vendor/wam-community/burns-audio/distortion/index.js","measured":{"returnDb":-7.7}},
  "com.sequencerParty.simpleEQ":{"trimDb":-4.4,"kind":"effect","name":"Simple EQ","url":"vendor/wam-community/burns-audio/simpleEQ/index.js","measured":{"returnDb":-1.6}},
  "com.sequencerParty.soundfont":{"trimDb":1.5,"kind":"instrument","name":"Soundfont Player","url":"vendor/wam-community/burns-audio/soundfont/index.js","measured":{"botsRmsDb":-30,"builtInRmsDb":-21.3,"botsPeakDb":-3.3}},
  "com.sequencerParty.synth101":{"trimDb":-18.6,"kind":"instrument","name":"Synth-101","url":"vendor/wam-community/burns-audio/synth101/index.js","measured":{"botsRmsDb":-29.3,"builtInRmsDb":-17.2,"botsPeakDb":-5}},
  "com.webaudiomodules.wam-examples.faust-flute":{"trimDb":-13.8,"kind":"instrument","name":"Faust flute","url":"vendor/wam/faustFlute/index.js","measured":{"botsRmsDb":-24.1,"builtInRmsDb":-21.3,"botsPeakDb":-2.2}},
  "com.webaudiomodules.wam-examples.faust-pingpongdelay-default-ui":{"trimDb":-8.1,"kind":"effect","name":"Faust ping-pong delay","url":"vendor/wam/faustPingPongDelayDefaultUI/index.js","measured":{"returnDb":2.1}},
  "com.webaudiomodules.wam-examples.obxd":{"trimDb":-17.2,"kind":"instrument","name":"OB-Xd","url":"vendor/wam-community/wam-examples/obxd/index.js","measured":{"botsRmsDb":-21,"builtInRmsDb":-21.3,"botsPeakDb":-5.8}},
  "com.webaudiomodules.wam-examples.stonephaser":{"trimDb":-4.4,"kind":"effect","name":"Stone phaser (stereo)","url":"vendor/wam/StonePhaserStereo/index.js","measured":{"returnDb":-1.6}},
  "com.webaudiomodules.wam-examples.tinysynth":{"trimDb":-13,"kind":"instrument","name":"TinySynth","url":"vendor/wam-community/wam-examples/tinySynth/src/index.js","measured":{"botsRmsDb":-24.8,"builtInRmsDb":-21.3,"botsPeakDb":-5.4},"voices":{"program:33":{"trimDb":-15,"role":"mono","measured":{"botsRmsDb":-21.9,"builtInRmsDb":-17.2,"botsPeakDb":-5.4}},"channel:9":{"trimDb":-14.8,"role":"drums","measured":{"botsRmsDb":-19,"builtInRmsDb":-14.4,"botsPeakDb":-2.5}}}},
  "com.wimmics.bigmuff":{"trimDb":0,"kind":"effect","name":"Big Muff","url":"vendor/wam-community/wimmics/BigMuff/index.js","measured":{"returnDb":-10.7}},
  "com.wimmics.blipper":{"trimDb":-6.6,"kind":"effect","name":"Blipper","url":"vendor/wam-community/wimmics/blipper/index.js","measured":{"returnDb":0.6}},
  "com.wimmics.csoundpitchshifter":{"trimDb":-4.3,"kind":"effect","name":"Csound Pitch Shifter","url":"vendor/wam-community/wimmics/csoundPitchShifter/dist/index.js","measured":{"returnDb":-1.7}},
  "com.wimmics.deathgate":{"trimDb":-10.3,"kind":"effect","name":"DeathGate","url":"vendor/wam-community/wimmics/deathgate/index.js","measured":{"returnDb":4.3}},
  "com.wimmics.distomachine":{"trimDb":-8.7,"kind":"effect","name":"DistoMachine","url":"vendor/wam-community/wimmics/disto_machine/src/index.js","measured":{"returnDb":2.7}},
  "com.wimmics.dualpitchshifter":{"trimDb":-1.7,"kind":"effect","name":"DualPitchShifter","url":"vendor/wam-community/wimmics/DualPitchShifter/index.js","measured":{"returnDb":-4.3}},
  "com.wimmics.graphicequalizer":{"trimDb":-10.4,"kind":"effect","name":"GraphicEqualizer","url":"vendor/wam-community/wimmics/graphicEqualizer/index.js","measured":{"returnDb":4.4}},
  "com.wimmics.greyhole":{"trimDb":-10.3,"kind":"effect","name":"Grey Hole","url":"vendor/wam-community/wimmics/greyhole/index.js","measured":{"returnDb":4.3}},
  "com.wimmics.guitarampsim60s":{"trimDb":-13.3,"kind":"effect","name":"Vox Amp 30","url":"vendor/wam-community/wimmics/GuitarAmpSim60s/index.js","measured":{"returnDb":7.3}},
  "com.wimmics.kbverb":{"trimDb":-12,"kind":"effect","name":"KBVerb","url":"vendor/wam-community/wimmics/kbverb/index.js","measured":{"returnDb":6}},
  "com.wimmics.kppdistorder":{"trimDb":0,"kind":"effect","name":"KppDistorder","url":"vendor/wam-community/wimmics/kppdistorder/index.js","measured":{"returnDb":-16.6}},
  "com.wimmics.kppfuzz":{"trimDb":-4.5,"kind":"effect","name":"KppFuzz","url":"vendor/wam-community/wimmics/Kpp_fuzz/index.js","measured":{"returnDb":-1.5}},
  "com.wimmics.osctube":{"trimDb":-5.4,"kind":"effect","name":"OSCTube","url":"vendor/wam-community/wimmics/OscTube/index.js","measured":{"returnDb":-0.6}},
  "com.wimmics.overdriverix":{"trimDb":-4.8,"kind":"effect","name":"Overdriverix","url":"vendor/wam-community/wimmics/OverdriveRix/index.js","measured":{"returnDb":-1.2}},
  "com.wimmics.owldirty":{"trimDb":-5.6,"kind":"effect","name":"OwlDirty","url":"vendor/wam-community/wimmics/OwlDirty/index.js","measured":{"returnDb":-0.4}},
  "com.wimmics.owlshimmer":{"trimDb":-2.2,"kind":"effect","name":"OWLShimmer","url":"vendor/wam-community/wimmics/OwlShimmer/index.js","measured":{"returnDb":-3.8}},
  "com.wimmics.pingpongdelay":{"trimDb":-5.4,"kind":"effect","name":"PingPongDelay","url":"vendor/wam-community/wimmics/pingpongdelay/dist/index.js","measured":{"returnDb":-0.6}},
  "com.wimmics.quadrafuzz":{"trimDb":-14.2,"kind":"effect","name":"QuadraFuzz","url":"vendor/wam-community/wimmics/quadrafuzz/dist/index.js","measured":{"returnDb":8.2}},
  "com.wimmics.smoothdelay":{"trimDb":0,"kind":"effect","name":"SmoothDelay","url":"vendor/wam-community/wimmics/SmoothDelay/index.js","measured":{"returnDb":-6.2}},
  "com.wimmics.stereoenhancer":{"trimDb":-4.3,"kind":"effect","name":"Stereo Enhancer","url":"vendor/wam-community/wimmics/StereoEnhancer/index.js","measured":{"returnDb":-1.7}},
  "com.wimmics.stereofreqshifter":{"trimDb":0,"kind":"effect","name":"StereoFreqShifter","url":"vendor/wam-community/wimmics/StereoFreqShifter/index.js","measured":{"returnDb":-9.3}},
  "com.wimmics.stonephaser":{"trimDb":-2.8,"kind":"effect","name":"StonePhaser","url":"vendor/wam-community/wimmics/stonephaser/index.js","measured":{"returnDb":-3.2}},
  "com.wimmics.sweetwah":{"trimDb":-0.8,"kind":"effect","name":"SweetWah","url":"vendor/wam-community/wimmics/sweetWah/index.js","measured":{"returnDb":-5.2}},
  "com.wimmics.temper":{"trimDb":-17.6,"kind":"effect","name":"Temper","url":"vendor/wam-community/wimmics/temper/index.js","measured":{"returnDb":11.6}},
  "com.wimmics.thruzeroflanger":{"trimDb":-7.8,"kind":"effect","name":"ThruZeroFlanger","url":"vendor/wam-community/wimmics/ThruZeroFlanger/index.js","measured":{"returnDb":1.8}},
  "com.wimmics.ts9overdrive":{"trimDb":0,"kind":"effect","name":"TS9 Overdrive","url":"vendor/wam-community/wimmics/TS9_Overdrive/index.js","measured":{"returnDb":-10}},
  "com.wimmics.weirdphaser":{"trimDb":0,"kind":"effect","name":"WeirdPhaser","url":"vendor/wam-community/wimmics/WeirdPhaser/index.js","measured":{"returnDb":-9.3}},
});
