// The mix fed back into itself: some of the mix bus's output returned to its input, as a live room returns a band's
// sound to the microphones that are picking it up. The user, 26 September 2026: "A technique I use while mixing is to
// route some of the mix's output back into itself, so there is a feedback loop in the mix, which simulates a live room
// and can help 'glue' the mix together." It is the desk's (public/audio-mixer.js, `mixFeedback`), on the mix bus and
// so before the delivery stage (render/master.mjs), and on by default.
//
// Why it is built this way, each point measured or proved in test/audio/mix-feedback.test.mjs:
//
//   - A loop in a digital mix needs a delay, and a workstation's is its buffer: one delay, whatever the buffer happens
//     to be, and one delay fed back is a comb filter. Here the delays are a live room's: the paths from the band to
//     the listening position by the room's walls, floor and ceiling (its first-order reflections, by the image-source
//     method: Allen & Berkley 1979), each rounded to a prime number of samples of its own, so no two combs' teeth line
//     up but at DC (as a feedback delay network's lines are chosen: Jot & Chaigne 1991). They fall at 12-27 ms, among
//     the early reflections a room's sound is made of and short of where one is heard as an echo (Haas 1951).
//   - The room is heard in stereo: each side of the mix reaches each side of the listening position by six paths, 24
//     in all, weighted as sound spreads (1/r), each side giving and taking a total of one.
//   - The loop is filtered as engineers filter a room send, at 200 Hz and 5 kHz (Pestana & Reiss 2014, mix-approaches.js
//     MEASURED.sendLowCut and sendTone): nothing below the room's Schroeder frequency (128 Hz here), where a small room
//     is its modes and a loop would build up the bass, and less of the top, which a room gives back less of than it
//     is given (its surfaces, the sources' directivity, and least, its air: 0.3 dB a pass at 5 kHz, ISO 9613-1).
//   - The amount is the loop's gain at the frequency where it returns most, the one that would ring first, as a
//     delay's feedback is: at most 0.5, the 6 dB under feedback a sound system is run at "to avoid the annoying ringing
//     sound associated with a pre-feedback condition" (Frank, Shure). So the mix is at most +6 dB and at least -3.5 dB
//     changed at any frequency, and on average across frequencies not at all: a stable loop's gain in dB averages zero
//     over frequency (Bode's sensitivity integral), so the loop leaves the mix's level and balance where they were.
//   - It cannot run away, by proof and not by tuning. A loop whose gain is below one at every frequency is stable (the
//     small-gain theorem: Zames 1966). Each piece of this one is bounded: the filters are Butterworth, never above
//     unity; a delay changes no level; and a matrix whose rows and columns each sum to one in magnitude cannot amplify
//     (the Schur test). So its gain is at most its scale everywhere, whatever the phases, and the scale is kept so that
//     this bound is under 0.9 at any sample rate (0.82 and 0.79 at 44.1 and 48 kHz, at the most the amount allows).
//   - A guard behind that: the return is clamped, softly, above +12 dBFS, which no loop at these gains returns from a
//     mix at float levels, so a return that got there anyway (a fault upstream, a bug here) stays bounded. The node
//     engine watches the clamp, and reports and cuts the loop if it ever acts (render/node/node-engine.mjs).
//
// Driven, and past unity. The user, 26 September 2026: "The amount of the feedback loop - and, eventually, multiple
// feedback loops - should be variable by one or more mixbots. Feedback can be varied, including into positive ranges
// driving guitar amp simulators or compressors, for musical effect." His example (TestingMPE, 1 December 2024) is a
// guitar group through Ableton's Roar, its "Basic Feedback": two shapers and a compressor inside a feedback path,
// gated by its input, so the feedback grows until the drive holds it and dies when the playing stops. Here:
//
//   - A stage in the loop may bound it (`drive`): one of the mixer's own drive curves (mixer-parts.js driveCurve:
//     tanh, tape, tube, fuzz), whose table ends at full scale, then a ceiling; or a compressor, an envelope follower
//     setting a gain by a compression curve, then a soft ceiling. Either keeps the return under the ceiling however
//     hard it is driven, so the loop's gain may pass unity (to maxDrivenGain): it then grows until the stage holds it,
//     and sustains there. Without a stage the amount stays at maxLoopGain and everything below holds as proved.
//   - No gate: a loop driven past unity sustains itself, and what ends it is a mixbot bringing its amount down (every
//     rise past unity is asked for with its release), not the music stopping. A drone ringing on after the playing,
//     as the example ends, is a mixbot's to allow.
//   - A loop without a stage is the loop above, bit for bit: a stage is built when first asked for.
//
// Built from the Web Audio API's own nodes, so the offline renders and every page, a phone's included, run the same
// loop: two biquads, 24 delays and gains, a splitter, a merger, three gains and a wave shaper, and the stages' own
// shapers, filters and gains when asked for.

import {driveCurve,ramp as rampParam,setAt} from './mixer-parts.js';

// ---- Definitions ------------------------------------------------------------------------------------------------
// The speed of sound, m/s, at 20 °C (as reverb-design.js's air absorption uses).
export const SPEED_OF_SOUND=343.2;
// The Web Audio render quantum, in frames. A cycle is read a quantum late in Chromium, as in render/node/graph.mjs, so
// each delay line is set a quantum short and the loop's delays are the designed ones.
export const RENDER_QUANTUM=128;
// Web Audio reads a lowpass's or a highpass's Q in dB. This is Q = 1/sqrt(2), Butterworth: maximally flat and never
// above unity, which the loop's bound needs (any larger Q peaks).
export const BUTTERWORTH_Q_DB=20*Math.log10(Math.SQRT1_2);
// A ring's length is how long it takes to die away by this much (its T60: Sabine's measure of a room).
export const RING_DB=60;

// ---- Choices ----------------------------------------------------------------------------------------------------
export const MIX_FEEDBACK=Object.freeze({
  // The live room, in metres: length (front wall to back), width and height in Louden's best ratio, 1.9 : 1.4 : 1
  // (Louden 1971, a room whose modes are evenly spread), at 170 m³, a studio live room (ours). Its mean absorption for
  // reverb-design.js's studio room (0.7 s) is 0.2 by Sabine: a room with some life in it.
  room:Object.freeze({length:7.6,width:5.6,height:4}),
  // Where the mix is played: its two sides a fifth of the way in from the front wall, 2.4 m apart, at an instrument's
  // height (ours).
  stage:Object.freeze({x:1.52,spread:2.4,height:1.2}),
  // Where it is heard: a spaced pair of room microphones 0.6 m apart, three fifths of the way down the room and 0.4 m
  // off its centre line, as no one stands exactly in the middle (ours; a room symmetric about its listener gives pairs
  // of equal paths).
  listener:Object.freeze({x:4.56,offset:.4,spacing:.6,height:1.5}),
  // The loop's band, as a room send's (Pestana & Reiss 2014; mix-approaches.js MEASURED.sendLowCut, sendTone).
  lowCutHz:200,
  toneHz:5000,
  // The most the loop may return at the frequency it returns most: 6 dB under feedback, a sound system's stability
  // margin (Frank, Shure). sound-settings.js ranges `mixFeedback` to it; its default is there (docs/TIMBRE_AND_MIX.md: why).
  maxLoopGain:.5,
  // The proof's bound on the loop's gain at any frequency is kept under this, whatever the rate (ours: 1 dB under
  // unity, a margin for the proof as the amount's is for the ear).
  maxBound:.9,
  // The guard: the return passes untouched below kneePeak (+12 dBFS) and bends smoothly toward ceilingPeak (+18 dBFS)
  // above it. A wave shaper's table spans +-range, with an odd number of points so silence is a point of it.
  guard:Object.freeze({kneePeak:4,ceilingPeak:8,range:32,points:8193}),
  // Delay lines are made this long (seconds): the room's longest path is 27 ms.
  maxDelaySeconds:.1,
  // With a stage that bounds it, the most the amount may be: twice unity, where the loop is mostly its drive (ours).
  maxDrivenGain:2,
  // A driven loop returns at most this (-9 dBFS), under the mix's own peaks: the feedback is heard, and does not
  // bury the playing (ours; Roar's example held its feedback under a limiter at -1 dBFS).
  ceiling:.35,
  // The loop's EQ, played as a no-input mixer's is: a peaking band (Roar's feedback path has one, at 1 kHz), centred
  // there unless said, an octave wide (Q 1.41), cutting or boosting within these. Without a stage it only cuts, so the
  // proof stands: a boost, like an amount past maxLoopGain, needs a stage to bound it.
  band:Object.freeze({hz:1000,q:1.41,leastDb:-24,mostDb:18,lowestHz:20,mostQ:32,broadQ:.5,broadDb:3}),
  // The width a tuned loop is played at, 0 to 1. The user, 26 September 2026: "A variety of feedback EQ widths. Broadband
  // feedback is aggressive, whereas narrowband whistling can deliver expressive melodies, and everything between also
  // exists." At `tone`, the widest band that still isolates the pitch (tuneTo's own); narrower towards `whistle`, to
  // band.mostQ, the one mode alone; wider towards `roar`, to band.broadQ (ours: two octaves) and flatter, its boost falling
  // to band.broadDb, so the loop's gain spreads over the band and every mode in it comes near the amount together: the
  // whole mix ringing, and the loudest of the room's modes there howling past unity, whatever its pitch (measured on a
  // mix of noise through the loop, 26 September 2026: a whistle's return is one tone, 0.1% of it anywhere else; a roar's
  // near unity spreads over 18 bins of 5 Hz, and past it colours the mix 14 dB more than a whistle does). Between, the
  // band's Q on a log scale and its boost on a straight one.
  widths:Object.freeze({whistle:0,tone:.5,roar:1}),
  // A loop tuned to a pitch rings there: its band centred on the pitch and boosted this much unless said, raised by
  // these steps up to band.mostDb, and narrowed (its Q doubled, up to band.mostQ) until the pitch is the one that rings
  // -- the loop's modes are a pass apart (57 Hz), and a band as narrow as that isolates one, as a no-input player
  // narrows an EQ onto a tone; and its room sized (the delay) so that the loop comes back in phase there, found by these
  // many Newton steps on the phase.
  // A pitch counts as isolated once it rings isolationDb over any other mode: a drone driven past unity settles in the
  // strongest mode, and a near rival can take it. At 1 dB, 79.02 through a tube droned 129 cents flat, and through a
  // fuzz (a hard clipper) two pitches of six fell 85 cents to the next mode; at 3 dB all six held within a cent through
  // each stage (docs/TIMBRE_AND_MIX.md).
  tune:Object.freeze({db:12,stepDb:3,phaseSteps:8,phaseTolerance:1e-9,ringToleranceHz:1,isolationDb:3}),
  // A tap's phasor is turned from frequency to frequency by a multiplication, renormalized this often.
  renormalizeSteps:4096,
  // A compressor in the loop: over its threshold, its gain falls by its ratio (a limiter's, near enough, as Roar's
  // output compressor holds its feedback), its level read by the envelope follower below.
  compressor:Object.freeze({thresholdDb:-24,ratio:8}),
  // The compressor reads its level through an envelope follower: the rectified signal, averaged over the channels,
  // through a Butterworth lowpass at this frequency (125 ms to settle, a note's length, not a cycle's).
  followHz:8,
  // A rough room (the setting mixFeedbackRoughness): every delay jittered together by a smooth random course, a new value
  // every 1/hz s (ours: a growl's rate; roughness is heard most from modulation of some tens of Hz, Zwicker and Fastl),
  // by up to mostShare of its length at full roughness, from a course of `seconds` looped. Measured on a low howl through
  // a tube: at 3% its energy stays at its peak (95% within 20 Hz), at 10% it wanders (58%), at 20%, some three semitones
  // either way, it growls (29%).
  roughness:Object.freeze({hz:40,mostShare:.2,seconds:2,seed:0x9e3779b9}),
  // Its course's random values, from a linear congruential generator (Numerical Recipes' constants): unsigned 32-bit
  // integers over half their range, less one (-1..1).
  random:Object.freeze({multiplier:1664525,increment:1013904223,half:2**31}),
  // A stage comes in or goes out over this long.
  switchSeconds:.05,
  // A drive curve is driven this hard unless said: halfway (the desk's default, sound-settings.js mixFeedbackDriveAmount).
  driveAmount:.5,
  // The loop's response is searched on this grid (Hz) for the frequency it returns most, then around the best
  // candidates to within refineHz; up to searchToHz, since above it the lowpass has taken the loop 27 dB down, far
  // under where it returns most (and at 8 kHz, whose top the lowpass cannot reach, to the Nyquist frequency, where
  // every odd delay returns in step).
  searchHz:1,refineHz:.01,refineCandidates:16,searchToHz:24000,
  // Where the loop comes back in phase (its ringing mode, below) is found on the same grid and bisected this many times
  // (1 Hz / 2^30: far finer than the grid), and its phase's slope read over +-slopeHz. The last ringsKept settings'
  // modes are kept (a gliding room asks at a new size every step; ours).
  ringBisections:30,slopeHz:.01,ringsKept:256,
});

// The stages a loop may be driven through: none (the proved loop), the mixer's drive curves, or a compressor.
export const LOOP_DRIVES=Object.freeze(['none','tanh','tape','tube','fuzz','compressor']);
export const loopDrive=value=>typeof value==='number'?LOOP_DRIVES[Math.round(value)]??'none':LOOP_DRIVES.includes(value)?value:'none';
// A wave shaper's reading of its table, as Web Audio does it: x in -1..1 across the table, linearly between points,
// and the ends held beyond it.
export function shapeAt(curve,x){
  const last=curve.length-1,v=(x+1)/2*last;
  if(!(v>0))return curve[0];
  if(v>=last)return curve[last];
  const i=Math.floor(v),f=v-i;
  return curve[i]+(curve[i+1]-curve[i])*f;
}
// A table's slope through zero, as a wave shaper plays it: its small-signal gain.
const SLOPE_STEP=1e-4;
export const curveSlope=curve=>(shapeAt(curve,SLOPE_STEP)-shapeAt(curve,-SLOPE_STEP))/(2*SLOPE_STEP);
// A table over -1..1 from a function of x.
function table(f,points){const curve=new Float32Array(points);for(let i=0;i<points;i++)curve[i]=f(2*i/(points-1)-1);return curve}
const dbToAmplitude=db=>10**(db/20);
// The filters' gain, proved rather than sampled: a Butterworth high-pass and low-pass each pass at most unity (maximally
// flat, and the bilinear transform keeps the analogue prototype's range), and a peaking band at most its gain at its
// centre (the cookbook's peaking filter is A^2 = 10^(db/20) there, its greatest). The sampled greatest (shape.filters,
// 0.9985 at 44.1 kHz) measures the same thing from under it, which a proof cannot use (the mathematical audit's I12).
const filterBound=band=>band&&band.db>0?dbToAmplitude(band.db):1;
// The rectifier: |x|.
export const rectifierCurve=(points=MIX_FEEDBACK.guard.points)=>table(Math.abs,points);
// A soft ceiling: slope one through zero, and never past the ceiling.
export const ceilingCurve=(ceiling=MIX_FEEDBACK.ceiling,points=MIX_FEEDBACK.guard.points)=>table(x=>ceiling*Math.tanh(x/ceiling),points);
// The compressor's gain for a level (the follower's reading, 0..1): one up to the threshold, then (threshold/level)
// to the power 1 - 1/ratio, so each dB over it comes out 1/ratio dB over.
export function compressionCurve({thresholdDb,ratio}=MIX_FEEDBACK.compressor,points=MIX_FEEDBACK.guard.points){
  const threshold=dbToAmplitude(thresholdDb);
  return table(level=>level<=threshold?1:(threshold/level)**(1-1/ratio),points);
}
// The small-signal gain of a stage: a drive curve's slope times the ceiling; a compressor's is one under its threshold.
export function stageGain(drive,driveAmount,choices=MIX_FEEDBACK){
  const kind=loopDrive(drive);
  if(kind==='none'||kind==='compressor')return 1;
  return curveSlope(driveCurve(kind,driveAmount))*choices.ceiling;
}
const clamp=(value,low,high)=>Math.min(high,Math.max(low,value));
const isPrime=value=>{if(value<2)return false;for(let d=2;d*d<=value;d++)if(value%d===0)return false;return true};

// Every first-order reflection from the stage to the listening position: for each side of the mix (from) and each
// side of the pair (to), the six images of the source in the room's surfaces (Allen & Berkley 1979), with the path's
// length in metres and its time in seconds.
export function roomReflections({room,stage,listener}=MIX_FEEDBACK){
  const {length:L,width:W,height:H}=room,middle=W/2;
  const sources={L:[stage.x,middle-stage.spread/2,stage.height],R:[stage.x,middle+stage.spread/2,stage.height]};
  const ears={L:[listener.x,middle+listener.offset-listener.spacing/2,listener.height],R:[listener.x,middle+listener.offset+listener.spacing/2,listener.height]};
  const images=([x,y,z])=>[['front wall',[-x,y,z]],['back wall',[2*L-x,y,z]],['left wall',[x,-y,z]],['right wall',[x,2*W-y,z]],['floor',[x,y,-z]],['ceiling',[x,y,2*H-z]]];
  const paths=[];
  for(const [from,source] of Object.entries(sources))for(const [to,ear] of Object.entries(ears))
    for(const [surface,[x,y,z]] of images(source)){
      const metres=Math.hypot(x-ear[0],y-ear[1],z-ear[2]);
      paths.push({from,to,surface,metres,seconds:metres/SPEED_OF_SOUND});
    }
  return paths.sort((a,b)=>a.seconds-b.seconds);
}

// A lowpass or highpass biquad's normalized coefficients [b0, b1, b2, a1, a2], as the Web Audio API specifies them
// (Q in dB) and Chromium and render/node/graph.mjs compute them.
export function passCoefficients(type,hz,sampleRate,qDb=BUTTERWORTH_Q_DB){
  const f=clamp(hz/(sampleRate/2),0,1);
  // At the Nyquist frequency a lowpass passes everything and a highpass nothing, and at 0 the reverse: the API's limits,
  // which the formula below reaches only through a double pole on the unit circle.
  if(f===1)return type==='lowpass'?[1,0,0,0,0]:[0,0,0,0,0];
  if(f===0)return type==='lowpass'?[0,0,0,0,0]:[1,0,0,0,0];
  const theta=Math.PI*f,alpha=Math.sin(theta)/(2*10**(qDb/20)),cos=Math.cos(theta);
  const beta=(type==='lowpass'?1-cos:1+cos)/2,a0=1+alpha;
  return [beta/a0,(type==='lowpass'?2:-2)*beta/a0,beta/a0,-2*cos/a0,(1-alpha)/a0];
}
// A peaking biquad's normalized coefficients, as the Web Audio API specifies them (Q linear, the gain's amplitude
// 10^(dB/40)) and Chromium and render/node/graph.mjs compute them.
export function peakingCoefficients(hz,gainDb,q,sampleRate){
  const f=clamp(hz/(sampleRate/2),0,1),a=10**(gainDb/40);
  if(f<=0||f>=1)return [1,0,0,0,0];
  if(!(q>0))return [a*a,0,0,0,0];
  const w0=Math.PI*f,alpha=Math.sin(w0)/(2*q),cos=Math.cos(w0),a0=1+alpha/a;
  return [(1+alpha*a)/a0,-2*cos/a0,(1-alpha*a)/a0,-2*cos/a0,(1-alpha/a)/a0];
}
const response=([b0,b1,b2,a1,a2],w)=>{
  const c1=Math.cos(w),s1=Math.sin(w),c2=Math.cos(2*w),s2=Math.sin(2*w);
  const nr=b0+b1*c1+b2*c2,ni=-(b1*s1+b2*s2),dr=1+a1*c1+a2*c2,di=-(a1*s1+a2*s2),d=dr*dr+di*di;
  return [(nr*dr+ni*di)/d,(ni*dr-nr*di)/d];
};
// Complex arithmetic on [re, im] pairs.
const cabs=([re,im])=>Math.hypot(re,im);
const ctimes=([a,b],[c,d])=>[a*c-b*d,a*d+b*c];
const cover=([a,b],[c,d])=>{const n=c*c+d*d;return [(a*c+b*d)/n,(b*c-a*d)/n]};
// A 2x2 complex matrix's determinant.
const determinant=([[a,b],[c,d]])=>{const [ad,bc]=[ctimes(a,d),ctimes(b,c)];return [ad[0]-bc[0],ad[1]-bc[1]]};
// A complex square root with no cancellation: the part that would be a difference of nearly equal numbers is taken
// from the other part instead (the principal root).
export function csqrt([re,im]){
  const size=Math.hypot(re,im);
  if(size===0)return [0,0];
  if(re>=0){const t=Math.sqrt((size+re)/2);return [t,im/t/2]}
  const t=Math.sqrt((size-re)/2);
  return [Math.abs(im)/t/2,(im<0?-1:1)*t];
}
// A 2x2 complex matrix's singular values, largest first. The largest is the square root of the larger eigenvalue of
// M^H M, taken from the matrix scaled by its largest entry (so no square overflows or underflows); the smaller is
// |det M| over it, since their product is |det M|. The difference of the two eigenvalues lost it: diag(1, 1e-10) gave
// [1, 0] (the mathematical audit's I12).
export function singularValues(matrix){
  const cells=matrix.flat(),largest=Math.max(...cells.map(cabs));
  if(largest===0)return [0,0];
  const [a,b,c,d]=cells.map(([re,im])=>[re/largest,im/largest]);
  const p=a[0]**2+a[1]**2+c[0]**2+c[1]**2,s=b[0]**2+b[1]**2+d[0]**2+d[1]**2;
  const qr=a[0]*b[0]+a[1]*b[1]+c[0]*d[0]+c[1]*d[1],qi=a[0]*b[1]-a[1]*b[0]+c[0]*d[1]-c[1]*d[0];
  const most=Math.sqrt((p+s)/2+Math.sqrt(((p-s)/2)**2+qr*qr+qi*qi));
  const least=most>0?cabs(determinant([[a,b],[c,d]]))/most:0;
  return [most*largest,Math.min(most,least)*largest];
}
// A 2x2 complex matrix's eigenvalues: the half-trace plus and minus the square root of (half the difference of the
// diagonal) squared plus the off-diagonals' product. The one of larger size is taken with the root on the half-trace's
// side, and the other is the determinant over it, so neither is a difference of nearly equal numbers.
export function eigenvalues(matrix){
  const [[a,b],[c,d]]=matrix,half=[(a[0]+d[0])/2,(a[1]+d[1])/2],diff=[(a[0]-d[0])/2,(a[1]-d[1])/2];
  const square=ctimes(diff,diff),across=ctimes(b,c),root=csqrt([square[0]+across[0],square[1]+across[1]]);
  const side=half[0]*root[0]+half[1]*root[1]>=0?1:-1,first=[half[0]+side*root[0],half[1]+side*root[1]];
  return [first,cabs(first)>0?cover(determinant(matrix),first):[half[0]-side*root[0],half[1]-side*root[1]]];
}
// Of two eigenvalues, the one nearer `to`: an eigenvalue followed across frequency, as the square root's branch swaps.
const apart=(x,y)=>Math.hypot(x[0]-y[0],x[1]-y[1]);
const nearer=([first,second],to)=>apart(first,to)<=apart(second,to)?first:second;
// Two eigenvalues followed to the next two at once: the pairing nearer in sum. Followed one at a time, both could take
// the same one (the mathematical audit's I12).
const paired=([u,v],[x,y])=>apart(u,x)+apart(v,y)<=apart(u,y)+apart(v,x)?[[u,x],[v,y]]:[[u,y],[v,x]];

// The loop's 2x2 transfer matrix at a frequency, filters, delays, weights and scale together, as complex [re, im]
// cells: [[L from L, L from R], [R from L, R from R]]. `room` scales every delay (the room's size: its delay time) and
// `band` ({hz, db, q}) is its EQ; the design's own unless said.
export function loopMatrix(design,hz,scale=design.scale,{room=design.room??1,band=design.band??null}={}){
  const w=2*Math.PI*hz/design.sampleRate;
  const [hr,hi]=response(passCoefficients('highpass',design.lowCutHz,design.sampleRate),w),[lr,li]=response(passCoefficients('lowpass',design.toneHz,design.sampleRate),w);
  let fr=scale*(hr*lr-hi*li),fi=scale*(hr*li+hi*lr);
  if(band&&band.db!==0){const [br,bi]=response(peakingCoefficients(band.hz,band.db,band.q,design.sampleRate),w);[fr,fi]=[fr*br-fi*bi,fr*bi+fi*br]}
  const index={L:0,R:1},m=[[[0,0],[0,0]],[[0,0],[0,0]]];
  for(const tap of design.taps){const phase=-w*tap.samples*room,cell=m[index[tap.to]][index[tap.from]];cell[0]+=tap.weight*Math.cos(phase);cell[1]+=tap.weight*Math.sin(phase)}
  return m.map(row=>row.map(([re,im])=>[re*fr-im*fi,re*fi+im*fr]));
}
// How far the room may be scaled: its shortest path no shorter than a render quantum and a sample (a cycle's floor in
// Web Audio), its longest within the delay lines' length.
export function roomLimits(design){
  const samples=design.taps.map(tap=>tap.samples);
  return {least:(design.quantum+1)/Math.min(...samples),most:design.choices.maxDelaySeconds*design.sampleRate/Math.max(...samples)};
}
// The loop's delay, one pass (ms), at a room size, and the room size of a delay; -1 (or any delay under zero) is the
// room's own.
export const delayMsFor=(design,room)=>room*design.shape.passSeconds*1000;
export function roomFor(design,delayMs){
  if(!(Number(delayMs)>=0))return 1;
  const {least,most}=roomLimits(design);
  return clamp(Number(delayMs)/1000/design.shape.passSeconds,least,most);
}
// The loop's gain at a frequency: its matrix's largest singular value, the most it returns of any signal there. The
// loop is stable, and changes the mix there by at most 1 / (1 - it), while this stays below one everywhere.
export const loopGain=(design,hz)=>singularValues(loopMatrix(design,hz))[0];

// The loop's ringing mode at a room size and band ({room, band}): the largest eigenvalue of its matrix (at a scale of
// one) that is real and positive, where it comes back in phase, each crossing of the positive real axis bisected. A
// loop scaled by s sustains itself once s times it passes one (det(I - sM) = 0 on the unit circle); under that it dies
// away by 20 log10(s ring) dB a pass, a pass being the eigenvalue's phase slope there (its group delay). Kept per
// setting (a mixbot plays a few).
const rings=new Map();
export function ringScan(design,{room=1,band=null}={},choices=design.choices){
  const flatBand=!band||band.db===0,key=choices===MIX_FEEDBACK?`${design.sampleRate}:${design.quantum}:${room}:${flatBand?'flat':`${band.hz}:${band.db}:${band.q}`}`:null;
  if(key&&rings.has(key))return rings.get(key);
  const settings={room,band:flatBand?null:band},sr=design.sampleRate,eigenAt=(hz,to)=>nearer(eigenvalues(loopMatrix(design,hz,1,settings)),to),crossings=[];
  // The matrix on the grid as loopMatrix makes it, each tap's phasor turned by its own step rather than recomputed.
  const index={L:0,R:1},turn=2*Math.PI*choices.searchHz/sr*room,filters=[passCoefficients('highpass',design.lowCutHz,sr),passCoefficients('lowpass',design.toneHz,sr),...(settings.band?[peakingCoefficients(band.hz,band.db,band.q,sr)]:[])];
  const phasors=design.taps.map(tap=>({weight:tap.weight,to:index[tap.to],from:index[tap.from],re:Math.cos(turn*tap.samples),im:-Math.sin(turn*tap.samples),cr:Math.cos(turn*tap.samples),ci:-Math.sin(turn*tap.samples)}));
  let before=null;
  for(let n=1,hz=choices.searchHz;hz<=Math.min(sr/2,choices.searchToHz);n++,hz+=choices.searchHz){
    const w=2*Math.PI*hz/sr,cells=[[0,0],[0,0],[0,0],[0,0]];let fr=1,fi=0;
    for(const coefficients of filters){const [r,i]=response(coefficients,w);[fr,fi]=[fr*r-fi*i,fr*i+fi*r]}
    for(const p of phasors){
      const cell=cells[2*p.to+p.from];cell[0]+=p.weight*p.re;cell[1]+=p.weight*p.im;
      const re=p.re*p.cr-p.im*p.ci;p.im=p.re*p.ci+p.im*p.cr;p.re=re;
      if(n%choices.renormalizeSteps===0){const size=Math.hypot(p.re,p.im);p.re/=size;p.im/=size}
    }
    const [a,b,c,d]=cells.map(([re,im])=>[re*fr-im*fi,re*fi+im*fr]);
    // Each eigenvalue followed from the last frequency, as the square root's branch swaps.
    const values=eigenvalues([[a,b],[c,d]]);
    if(before)for(const [last,next] of paired(before,values))if(last[0]>0&&next[0]>0&&(last[1]<0)!==(next[1]<0))crossings.push({from:hz-choices.searchHz,last});
    before=values;
  }
  // The strongest crossings first, each bisected, until none left could be stronger than the ring found: in one step of
  // the grid an eigenvalue can grow by at most the phase its longest tap turns.
  const margin=1+turn*Math.max(...design.taps.map(tap=>tap.samples));
  crossings.sort((x,y)=>Math.hypot(...y.last)-Math.hypot(...x.last));
  // The strongest mode and its strongest rival elsewhere (the runner-up, a mode apart).
  let ring=0,ringHz=0,passSeconds=0,rival=0;
  for(const {from,last} of crossings){
    if(Math.hypot(...last)*margin<=rival)break;
    let low=from,high=from+choices.searchHz,at=last;
    for(let i=0;i<choices.ringBisections;i++){const mid=(low+high)/2,value=eigenAt(mid,at);if((value[1]<0)===(at[1]<0)){low=mid;at=value}else high=mid}
    const value=eigenAt((low+high)/2,at),hz=(low+high)/2,apart=Math.abs(hz-ringHz)>choices.tune.ringToleranceHz;
    if(value[0]>ring){if(apart)rival=ring;ring=value[0];ringHz=hz}
    else if(value[0]>rival&&apart)rival=value[0];
  }
  if(ring>0){
    const centre=eigenAt(ringHz,[ring,0]),phase=hz=>{const value=eigenAt(hz,centre);return Math.atan2(value[1],value[0])};
    passSeconds=-(phase(ringHz+choices.slopeHz)-phase(ringHz-choices.slopeHz))/(2*Math.PI*2*choices.slopeHz);
  }
  const found={ring,ringHz,passSeconds,rival};
  if(key){rings.set(key,found);if(rings.size>choices.ringsKept)rings.delete(rings.keys().next().value)}
  return found;
}
// The loop tuned to ring at `hz`: its band centred there (boosted `db`, raised by tune.stepDb up to band.mostDb until
// hz is where it rings), and its room sized so that its strongest eigenvalue there is real and positive: the room nearest
// `near` that does (the phase falls as the room grows, 2 pi hz a pass for each whole room; a peaking band has no phase at
// its centre, so the room does not depend on its gain). Near its own size, a new pitch is another of the loop's modes;
// near the room that carries the mode ringing now to it (glideRoom), it is that mode, bent. {room, band, ring, ringHz,
// passSeconds, rival, tuned}.
export function tuneTo(design,hz,{db=design.choices.tune.db,q=design.choices.band.q,near=1,width=null}={}){
  const choices=design.choices,{least,most}=roomLimits(design),target=clamp(Number(hz)||choices.band.hz,choices.band.lowestHz,design.sampleRate/2);
  const phaseAt=room=>{const [first,second]=eigenvalues(loopMatrix(design,target,1,{room,band:{hz:target,db:1,q}}));const strongest=Math.hypot(...first)>=Math.hypot(...second)?first:second;return Math.atan2(strongest[1],strongest[0])};
  let room=clamp(Number(near)||1,least,most);
  for(let i=0;i<choices.tune.phaseSteps;i++){
    const phase=phaseAt(room);if(Math.abs(phase)<choices.tune.phaseTolerance)break;
    room=clamp(room+phase/(2*Math.PI*target*design.shape.passSeconds),least,most);
  }
  const rings=band=>{const found=ringScan(design,{room,band});return Math.abs(found.ringHz-target)<=choices.tune.ringToleranceHz&&found.ring>=found.rival*10**(choices.tune.isolationDb/20)};
  const boost=clamp(db,0,choices.band.mostDb);
  let band={hz:target,db:boost,q:clamp(q,Number.EPSILON,choices.band.mostQ)};
  // The widest band that isolates the pitch, and at it the least boost that does.
  for(let width=band.q;!rings(band)&&width<=choices.band.mostQ;width*=2)
    for(let gain=boost;gain<=choices.band.mostDb;gain+=choices.tune.stepDb){band={hz:target,db:gain,q:width};if(rings(band))break}
  // Played at a width (MIX_FEEDBACK.widths): the isolating band narrowed towards a whistle or widened towards a roar.
  if(width!==null&&Number.isFinite(Number(width))){
    const {tone}=choices.widths,w=clamp(Number(width),choices.widths.whistle,choices.widths.roar),whistling=w<=tone;
    const share=whistling?(tone-w)/(tone-choices.widths.whistle):(w-tone)/(choices.widths.roar-tone),edge=whistling?choices.band.mostQ:choices.band.broadQ;
    band={...band,q:band.q*(edge/band.q)**share,db:whistling?band.db:band.db+(choices.band.broadDb-band.db)*share};
  }
  return {room,band,...ringScan(design,{room,band}),tuned:rings(band)};
}

// The room that carries the mode ringing now (at `settings`) to `hz`: the delays scaled by the ratio of the two, as a
// player glides a delay's time and its feedback tone bends with it.
export function glideRoom(design,hz,settings){
  const {ringHz}=ringScan(design,settings),{least,most}=roomLimits(design);
  return ringHz>0?clamp((settings.room??1)*ringHz/hz,least,most):1;
}

// What the loop's shape gives at a scale of one: its gain where it returns most (searched, then refined), the
// filters' largest gain, and the Schur test's bound on its matrix (the square root of its largest row sum times its
// largest column sum). Computed once per rate.
const shapes=new Map();
// Compile filter coefficients once for a fixed design/settings. The closure
// snapshots taps; a changed design requires a fresh preparation. Ideal phasors,
// as in loopMatrix; this does not certify completeness or the delay renderer.
export function prepareLoopMatrix(design,{room=design.room??1,band=design.band??null}={}){
  const sampleRate=design.sampleRate,defaultScale=design.scale,index={L:0,R:1};
  const filters=[passCoefficients('highpass',design.lowCutHz,sampleRate),passCoefficients('lowpass',design.toneHz,sampleRate),...(band&&band.db!==0?[peakingCoefficients(band.hz,band.db,band.q,sampleRate)]:[])];
  const taps=design.taps.map(t=>({from:index[t.from],to:index[t.to],samples:t.samples,weight:t.weight}));
  return (hz,scale=defaultScale)=>{
    const w=2*Math.PI*hz/sampleRate,[hr,hi]=response(filters[0],w),[lr,li]=response(filters[1],w);
    let fr=scale*(hr*lr-hi*li),fi=scale*(hr*li+hi*lr);
    if(filters.length>2){const [br,bi]=response(filters[2],w);[fr,fi]=[fr*br-fi*bi,fr*bi+fi*br]}
    const m=[[[0,0],[0,0]],[[0,0],[0,0]]];
    for(const tap of taps){const phase=-w*tap.samples*room,cell=m[tap.to][tap.from];cell[0]+=tap.weight*Math.cos(phase);cell[1]+=tap.weight*Math.sin(phase)}
    return m.map(row=>row.map(([re,im])=>[re*fr-im*fi,re*fi+im*fr]));
  };
}
function shapeOf(design,choices){
  const key=choices===MIX_FEEDBACK?`${design.sampleRate}:${design.quantum}`:null;
  if(key&&shapes.has(key))return shapes.get(key);
  const nyquist=design.sampleRate/2,flat={room:1,band:null},prepared=prepareLoopMatrix(design,flat),gain=hz=>singularValues(prepared(hz,1))[0],found=[];
  let filters=0;
  const high=passCoefficients('highpass',design.lowCutHz,design.sampleRate),low=passCoefficients('lowpass',design.toneHz,design.sampleRate);
  for(let hz=choices.searchHz;hz<=Math.min(nyquist,choices.searchToHz);hz+=choices.searchHz){
    const w=2*Math.PI*hz/design.sampleRate,[hr,hi]=response(high,w),[lr,li]=response(low,w);
    filters=Math.max(filters,Math.hypot(hr,hi)*Math.hypot(lr,li));
    found.push([hz,gain(hz)]);
  }
  const candidates=found.filter(([,value],i)=>(i===0||value>=found[i-1][1])&&(i===found.length-1||value>=found[i+1][1]))
    .sort((a,b)=>b[1]-a[1]).slice(0,choices.refineCandidates);
  let peak=0,peakHz=0;
  for(const [centre] of candidates)for(let hz=centre-choices.searchHz;hz<=centre+choices.searchHz;hz+=choices.refineHz){
    const value=gain(hz);if(value>peak){peak=value;peakHz=hz}
  }
  const total=(key,side)=>design.taps.filter(tap=>tap[key]===side).reduce((sum,tap)=>sum+Math.abs(tap.weight),0);
  const schur=Math.sqrt(Math.max(total('to','L'),total('to','R'))*Math.max(total('from','L'),total('from','R')));
  const shape={peak,peakHz,filters,schur,...ringScan(design,flat,choices)};
  if(key)shapes.set(key,shape);
  return shape;
}

// The loop at a sample rate and amount: its taps (each a reflection, with its prime delay in samples, the delay its
// DelayNode is set to, and its weight), its filters, its scale (the gain it is built with), and what that scale gives:
// `amount`, its gain at the frequency it returns most, and `bound`, the most its gain can be at any frequency, proved.
// Deterministic: the same rate gives the same loop.
export function mixFeedbackDesign({sampleRate=48000,amount=MIX_FEEDBACK.maxLoopGain,drive='none',driveAmount=MIX_FEEDBACK.driveAmount,room=1,band=null,quantum=RENDER_QUANTUM,choices=MIX_FEEDBACK}={}){
  const paths=roomReflections(choices),used=new Set;
  // Each path to the nearest prime not yet taken, shortest first; ties go to the shorter prime.
  const taps=paths.map(path=>{
    const exact=path.seconds*sampleRate;
    let samples=null;
    for(let step=0;samples===null;step++)for(const candidate of [Math.round(exact)-step,Math.round(exact)+step])
      if(samples===null&&isPrime(candidate)&&!used.has(candidate))samples=candidate;
    used.add(samples);
    return {...path,samples,weight:1/path.metres};
  });
  // Spread as 1/r, then scaled so the largest total any side gives or takes is one: every row and column of the loop's
  // 2x2 matrix sums to at most one in magnitude, which keeps its norm at most one at every frequency.
  const sums=[...['L','R'].map(side=>taps.filter(tap=>tap.from===side)),...['L','R'].map(side=>taps.filter(tap=>tap.to===side))]
    .map(list=>list.reduce((sum,tap)=>sum+tap.weight,0));
  const unit=1/Math.max(...sums);
  for(const tap of taps){tap.weight*=unit;tap.delaySeconds=(tap.samples-quantum)/sampleRate}
  const design={sampleRate,quantum,taps,lowCutHz:choices.lowCutHz,toneHz:choices.toneHz,maxLoopGain:choices.maxLoopGain,maxBound:choices.maxBound,guard:choices.guard,
    maxDrivenGain:choices.maxDrivenGain,choices};
  Object.assign(design,{shape:shapeOf(design,choices)});
  return setAmount(design,amount,{drive,driveAmount,room,band});
}
// A design at another amount, through a stage or none: the scale that gives it. Without a stage, the amount is the
// loop's gain where it returns most, as far as the bound allows (the proof). Through one, up to maxDrivenGain, it is the
// gain of the loop's ringing mode, where it comes back in phase (0.77 of the greatest in this room, at 2.1 kHz): past
// one it sustains itself, under one it rings for ringing seconds; the stage's small-signal gain is taken out of the
// scale, so this holds whatever the stage.
export function setAmount(design,amount,{drive=design.drive??'none',driveAmount=design.driveAmount??MIX_FEEDBACK.driveAmount,room=design.room??1,band=design.band??null}={}){
  const {peak,schur}=design.shape,kind=loopDrive(drive),{least,most}=roomLimits(design),limits=design.choices.band;
  design.drive=kind;design.driveAmount=clamp(Number(driveAmount)||0,0,1);
  design.room=clamp(Number(room)||1,least,most);
  // Without a stage the band only cuts: the filters' largest gain stays the proof's.
  design.band=band?{hz:clamp(Number(band.hz)||limits.hz,limits.lowestHz,design.sampleRate/2),db:clamp(Number(band.db)||0,limits.leastDb,kind==='none'?0:limits.mostDb),q:Number(band.q)>0?Number(band.q):limits.q}:null;
  if(kind==='none'){
    const wanted=clamp(Number(amount)||0,0,design.maxLoopGain);
    design.stage=1;design.scale=Math.min(wanted/peak,design.maxBound/(filterBound(design.band)*schur));
    design.amount=design.scale*peak;
  }else{
    // The ringing mode at this room and band: the amount is its gain, whatever the delay and the EQ.
    const {ring}=ringScan(design,{room:design.room,band:design.band});
    design.stage=stageGain(kind,design.driveAmount,design.choices);
    design.scale=clamp(Number(amount)||0,0,design.maxDrivenGain)/(ring*design.stage);
    design.amount=design.scale*ring*design.stage;
  }
  // Without a stage, a proof that the loop dies away. Through one, the loop's linear part's bound times the stage's
  // small-signal gain: a figure, not that claim, since a driven loop may be set to sustain itself.
  design.bound=design.scale*filterBound(design.band)*schur*design.stage;
  return design;
}
// The bound, from the design's pieces: the scale, times the filters' proved gain, times the Schur test's bound.
export const loopGainBound=design=>design.scale*filterBound(design.band)*design.shape.schur;

// The amount at which a loop through a stage, left alone, rings for `seconds` (dies away by RING_DB in them): its
// ringing mode's gain, which loses 20 log10(amount) dB a pass (0.97 for 4 s, 0.94 for 2, in this room at 48 kHz). A
// loop sustaining itself is taken down through it, so that it dies away over the time asked.
export const ringingAmount=(seconds,design=mixFeedbackDesign(),settings={room:1,band:null})=>seconds>0?10**(-RING_DB*ringScan(design,settings).passSeconds/(20*seconds)):0;

// The guard's curve, over +-range: the identity to the knee, then a tanh toward the ceiling, continuous in value and
// slope. In the wave shaper's own units (input and output divided by range).
export function guardCurve({kneePeak,ceilingPeak,range,points}=MIX_FEEDBACK.guard){
  const curve=new Float32Array(points),bend=ceilingPeak-kneePeak;
  for(let i=0;i<points;i++){
    const x=(2*i/(points-1)-1)*range,size=Math.abs(x);
    curve[i]=(size<=kneePeak?x:Math.sign(x)*(kneePeak+bend*Math.tanh((size-kneePeak)/bend)))/range;
  }
  return curve;
}

// The loop on a context: `input` takes the mix bus, `output` returns to it (the caller connects both). set(amount)
// ramps the loop's gain; `return` is the node the node engine watches, the return before the guard.
export function createMixFeedback(context,{amount=MIX_FEEDBACK.maxLoopGain,choices=MIX_FEEDBACK}={}){
  const quantum=Number(context.renderQuantumSize??context.blockSize)||RENDER_QUANTUM;
  const design=mixFeedbackDesign({sampleRate:context.sampleRate,amount,quantum,choices});
  // `input` takes the bus (a gain of exactly one: the loop as it was), then the loop's band.
  const input=context.createGain(),high=context.createBiquadFilter(),tone=context.createBiquadFilter();
  high.type='highpass';high.frequency.value=design.lowCutHz;high.Q.value=BUTTERWORTH_Q_DB;
  tone.type='lowpass';tone.frequency.value=design.toneHz;tone.Q.value=BUTTERWORTH_Q_DB;
  const split=context.createChannelSplitter(2),merge=context.createChannelMerger(2),channel={L:0,R:1};
  input.connect(high).connect(tone).connect(split);
  const lines=design.taps.map(tap=>{
    const weight=context.createGain(),delay=context.createDelay(choices.maxDelaySeconds);
    weight.gain.value=tap.weight;delay.delayTime.value=tap.delaySeconds;
    split.connect(weight,channel[tap.from]);weight.connect(delay).connect(merge,0,channel[tap.to]);
    return {weight,delay,tap};
  });
  // The scale, the direct path (one, the loop as it was), then the guard: into the shaper's units, the curve, and back.
  // A stage, when one is asked for, is a second path from the scale to the guard, faded in as the direct one fades out.
  const gain=context.createGain(),direct=context.createGain(),into=context.createGain(),shaper=context.createWaveShaper(),output=context.createGain();
  gain.gain.value=design.scale;direct.gain.value=1;into.gain.value=1/choices.guard.range;shaper.curve=guardCurve(choices.guard);output.gain.value=choices.guard.range;
  merge.connect(gain).connect(direct).connect(into).connect(shaper).connect(output);
  const nodes=[input,high,tone,split,merge,gain,direct,into,shaper,output,...lines.flatMap(line=>[line.weight,line.delay])];
  // As the desk ramps (mixer-parts.js ramp): from where the value is, however long ago it last moved.
  const ramp=(param,value,atSeconds,seconds,immediate)=>immediate?setAt(param,value,atSeconds):rampParam(param,value,atSeconds,seconds);
  // The stages, each built the first time it is asked for: a drive curve and its ceiling; a compressor (a follower
  // reading the loop's level, the compression curve setting a gain) and its soft ceiling.
  const stages={};
  // The band, spliced in after the tone the first time it is asked for, flat (so nothing changes but rounding), and
  // there from then on.
  let bandNode=null,rough=null;
  // The room's roughness, built the first time it is asked for (so a loop never made rough is the loop as it was): a
  // smooth random course (a new value every 1/hz s, eased between), looped, its depth a gain, into each delay line's time
  // in proportion to the line's own length.
  function ensureRough(){
    if(rough)return rough;
    const {hz,seconds,seed}=choices.roughness,length=Math.round(seconds*context.sampleRate),step=Math.max(1,Math.round(context.sampleRate/hz));
    const buffer=context.createBuffer(1,length,context.sampleRate),data=buffer.getChannelData(0);
    const {multiplier,increment,half}=choices.random;
    let state=seed>>>0;const next=()=>(state=(Math.imul(state,multiplier)+increment)>>>0)/half-1;
    const points=Array.from({length:Math.ceil(length/step)+1},next);points[points.length-1]=points[0];
    for(let i=0;i<length;i++){const k=Math.floor(i/step),f=(i%step)/step,ease=(1-Math.cos(Math.PI*f))/2;data[i]=points[k]+(points[Math.min(points.length-1,k+1)]-points[k])*ease}
    const source=context.createBufferSource(),depth=context.createGain();
    source.buffer=buffer;source.loop=true;depth.gain.value=0;source.connect(depth);
    const scales=lines.map(line=>{const scale=context.createGain();scale.gain.value=line.tap.samples/context.sampleRate;depth.connect(scale).connect(line.delay.delayTime);return scale});
    try{source.start(0)}catch{/* started */}
    nodes.push(source,depth,...scales);
    return rough={source,depth};
  }
  function ensureBand(){
    if(bandNode)return bandNode;
    bandNode=context.createBiquadFilter();bandNode.type='peaking';
    bandNode.frequency.value=choices.band.hz;bandNode.Q.value=choices.band.q;bandNode.gain.value=0;
    tone.disconnect(split);tone.connect(bandNode).connect(split);nodes.push(bandNode);
    return bandNode;
  }
  function driveStage(){
    if(stages.drive)return stages.drive;
    const curve=context.createWaveShaper(),ceiling=context.createGain(),level=context.createGain();
    ceiling.gain.value=choices.ceiling;level.gain.value=0;
    gain.connect(curve).connect(ceiling).connect(level).connect(into);
    nodes.push(curve,ceiling,level);
    return stages.drive={curve,level,kind:null,amount:null};
  }
  function compressorStage(){
    if(stages.compressor)return stages.compressor;
    const vca=context.createGain(),rectify=context.createWaveShaper(),mono=context.createGain(),follow=context.createBiquadFilter(),law=context.createWaveShaper();
    const soft=context.createWaveShaper(),level=context.createGain();
    rectify.curve=rectifierCurve(choices.guard.points);
    Object.assign(mono,{channelCount:1,channelCountMode:'explicit',channelInterpretation:'speakers'});
    follow.type='lowpass';follow.frequency.value=choices.followHz;follow.Q.value=BUTTERWORTH_Q_DB;
    law.curve=compressionCurve(choices.compressor,choices.guard.points);
    vca.gain.value=0;soft.curve=ceilingCurve(choices.ceiling,choices.guard.points);level.gain.value=0;
    gain.connect(rectify).connect(mono).connect(follow).connect(law).connect(vca.gain);
    gain.connect(vca).connect(soft).connect(level).connect(into);
    nodes.push(vca,rectify,mono,follow,law,soft,level);
    return stages.compressor={level};
  }
  return {design,input,output,return:gain,nodes,stages,
    get amount(){return design.amount},
    get drive(){return design.drive},
    get room(){return design.room??1},
    get band(){return design.band},
    // A ramp, as every other amount on the desk. Through a stage or none (`drive`, one of LOOP_DRIVES, and
    // `driveAmount` for a drive curve's): the path asked for fades in over the ramp and the others out; a gain of
    // exactly zero passes silence, so the loop off is the mix without it. `room` scales its delays (roomFor: a delay
    // in ms) and `band` ({hz, db, q}) is its EQ, both ramped: a delay line's read point glides, so the loop's pitch
    // bends and nothing clicks, and the band's filter moves sample by sample.
    set(value,{drive=design.drive,driveAmount=design.driveAmount,room=design.room??1,band=design.band??null,roughness=0,atSeconds=context.currentTime,seconds=MIX_FEEDBACK.switchSeconds,immediate=false}={}){
      const kind=loopDrive(drive),before=design.room??1;
      setAmount(design,value,{drive:kind,driveAmount,room,band});
      if(immediate||design.room!==before)for(const line of lines)ramp(line.delay.delayTime,(design.room*line.tap.samples-quantum)/context.sampleRate,atSeconds,seconds,immediate);
      if(design.band&&(design.band.db!==0||bandNode)){
        const node=ensureBand();
        ramp(node.frequency,design.band.hz,atSeconds,seconds,immediate);ramp(node.gain,design.band.db,atSeconds,seconds,immediate);ramp(node.Q,design.band.q,atSeconds,seconds,immediate);
      }
      if(kind!=='none'&&kind!=='compressor'){
        const stage=driveStage();
        if(stage.kind!==kind||stage.amount!==design.driveAmount){stage.curve.curve=driveCurve(kind,design.driveAmount);stage.kind=kind;stage.amount=design.driveAmount}
      }
      if(kind==='compressor')compressorStage();
      if(Number(roughness)>0||rough)ramp(ensureRough().depth.gain,Math.max(0,Math.min(1,Number(roughness)||0))*choices.roughness.mostShare,atSeconds,seconds,immediate);
      ramp(gain.gain,design.scale,atSeconds,seconds,immediate);
      ramp(direct.gain,kind==='none'?1:0,atSeconds,seconds,immediate);
      if(stages.drive)ramp(stages.drive.level.gain,kind!=='none'&&kind!=='compressor'?1:0,atSeconds,seconds,immediate);
      if(stages.compressor)ramp(stages.compressor.level.gain,kind==='compressor'?1:0,atSeconds,seconds,immediate);
      return design.amount;
    },
    dispose(){try{rough?.source.stop()}catch{/* not started */}for(const node of nodes)try{node.disconnect()}catch{/* already gone */}},
  };
}

// The loop in plain arithmetic, for tests and measurements: the mix bus that `dry` (planar channels, the mix without
// the loop) becomes with it. The same filters, delays, weights, scale and guard as the nodes above, in double
// precision; the node engine's loop matches it to -137 dB.
export function applyMixFeedback(dry,{sampleRate=48000,amount=MIX_FEEDBACK.maxLoopGain,drive='none',driveAmount=MIX_FEEDBACK.driveAmount,band=null,choices=MIX_FEEDBACK,guard=true}={}){
  const design=mixFeedbackDesign({sampleRate,amount,drive,driveAmount,band,choices}),length=dry[0].length,g=design.scale;
  const peaking=design.band&&design.band.db!==0?peakingCoefficients(design.band.hz,design.band.db,design.band.q,sampleRate):null;
  // The stage, as the nodes play it: a drive curve and its ceiling, or the compressor's follower, law and soft ceiling.
  const kind=design.drive,curve=kind!=='none'&&kind!=='compressor'?driveCurve(kind,design.driveAmount):null;
  const law=kind==='compressor'?compressionCurve(choices.compressor,choices.guard.points):null,soft=law?ceilingCurve(choices.ceiling,choices.guard.points):null;
  const follow=law?passCoefficients('lowpass',choices.followHz,sampleRate):null,followState=new Float64Array(4),backs=[0,0];
  const out=[0,1].map(c=>Float64Array.from(dry[Math.min(c,dry.length-1)]));
  if(!(g>0))return {channels:out,design,guarded:0};
  // What each side has sent round, as far back as the longest tap reaches: a ring, a power of two long, rather than the
  // whole render (two copies of which were kept: 230 MB for five minutes at 48 kHz; the audit's I12).
  const reach=2**Math.ceil(Math.log2(Math.max(...design.taps.map(tap=>tap.samples))+1)),wrap=reach-1;
  const filtered=[new Float64Array(reach),new Float64Array(reach)];
  const [high,low]=[passCoefficients('highpass',design.lowCutHz,sampleRate),passCoefficients('lowpass',design.toneHz,sampleRate)];
  const state=[new Float64Array(12),new Float64Array(12)];
  // Each side's taps as flat arrays: where from, how late, how much.
  const index={L:0,R:1},taps=[0,1].map(c=>design.taps.filter(tap=>index[tap.to]===c));
  const from=taps.map(list=>Int32Array.from(list,tap=>index[tap.from])),late=taps.map(list=>Int32Array.from(list,tap=>tap.samples)),weight=taps.map(list=>Float64Array.from(list,tap=>tap.weight));
  const {kneePeak,ceilingPeak}=design.guard,bend=ceilingPeak-kneePeak;
  let guarded=0;
  for(let n=0;n<length;n++){
    // Both sides' returns first: the compressor's follower reads them together.
    for(let c=0;c<2;c++){
      let back=0;
      const f=from[c],d=late[c],w=weight[c];
      for(let k=0;k<f.length;k++){const at=n-d[k];if(at>=0)back+=w[k]*filtered[f[k]][at&wrap]}
      backs[c]=back*g;
    }
    let reduction=1;
    if(law){
      const x=(Math.abs(backs[0])+Math.abs(backs[1]))/2,s=followState;
      const y=follow[0]*x+follow[1]*s[0]+follow[2]*s[1]-follow[3]*s[2]-follow[4]*s[3];s[1]=s[0];s[0]=x;s[3]=s[2];s[2]=y;
      reduction=shapeAt(law,y);
    }
    for(let c=0;c<2;c++){
      let back=backs[c];
      if(curve)back=choices.ceiling*shapeAt(curve,back);
      else if(law)back=shapeAt(soft,back*reduction);
      if(guard&&Math.abs(back)>kneePeak){guarded++;back=Math.sign(back)*(kneePeak+bend*Math.tanh((Math.abs(back)-kneePeak)/bend))}
      const x=out[c][n]+=back,s=state[c];
      const y1=high[0]*x+high[1]*s[0]+high[2]*s[1]-high[3]*s[2]-high[4]*s[3];s[1]=s[0];s[0]=x;s[3]=s[2];s[2]=y1;
      const y2=low[0]*y1+low[1]*s[4]+low[2]*s[5]-low[3]*s[6]-low[4]*s[7];s[5]=s[4];s[4]=y1;s[7]=s[6];s[6]=y2;
      let y3=y2;
      if(peaking){y3=peaking[0]*y2+peaking[1]*s[8]+peaking[2]*s[9]-peaking[3]*s[10]-peaking[4]*s[11];s[9]=s[8];s[8]=y2;s[11]=s[10];s[10]=y3}
      filtered[c][n&wrap]=y3;
    }
  }
  return {channels:out,design,guarded};
}
