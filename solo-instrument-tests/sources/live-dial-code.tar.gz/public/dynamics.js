// The dynamics processor (dynamics-worklet.js) as something a mixer can use: loaded once per
// context, made by mode, set with ramps, read for its gain reduction.
//
// Modes and the settings each starts from. The numbers are engineers' choices where a study
// measured them, and ours otherwise; research/expression-and-mixing-references.md says which:
//
//   compress  ratio 2.5, attack 10 ms, release 120 ms. Ma et al. fitted engineers' ratio choices
//             at 1.6 to 3.1:1; Giannoulis et al. measured vocal attack near 6 ms, release 100-150 ms,
//             and drum attack near 19 ms.
//   limit     a -1 dBFS ceiling at 100:1 with an instant attack and a 60 ms release: a safety, not
//             a sound. No sample passes it; an inter-sample peak can, by a fraction of a dB.
//   expand    ratio 2 below the threshold: quieter sounds made quieter, not removed.
//   gate      a gate: a steep expansion down to its range, with a hold.
//   duck      keyed by another signal: the sidechain duck and the pumping of dance music.
//   transient each hit's attack raised by up to `boost` dB and its sustain moved by up to `sustain` dB, by the shape of
//             its envelope, not its level (dynamics-worklet.js): a transient designer, for drums with punch. Given an
//             `aim`, each attack raised only as far as it takes to stand `aim` dB over its body, as the hits heard stand.
export const DYNAMICS_MODES = Object.freeze(['compress', 'limit', 'expand', 'gate', 'duck', 'transient']);
export const DYNAMICS_DEFAULTS = Object.freeze({
  compress: Object.freeze({threshold: -18, ratio: 2.5, knee: 6, attack: 0.01, release: 0.12, makeup: 0, mix: 1, range: 40, hold: 0}),
  limit: Object.freeze({threshold: -1, ratio: 100, knee: 0, attack: 0.00001, release: 0.06, makeup: 0, mix: 1, range: 24, hold: 0}),
  expand: Object.freeze({threshold: -45, ratio: 2, knee: 6, attack: 0.002, release: 0.15, makeup: 0, mix: 1, range: 18, hold: 0}),
  gate: Object.freeze({threshold: -40, ratio: 20, knee: 2, attack: 0.0005, release: 0.08, makeup: 0, mix: 1, range: 60, hold: 0.05}),
  duck: Object.freeze({threshold: -30, ratio: 8, knee: 6, attack: 0.002, release: 0.18, makeup: 0, mix: 1, range: 12, hold: 0}),
  transient: Object.freeze({threshold: -60, ratio: 1, knee: 0, attack: 0.015, release: 0.12, makeup: 0, mix: 1, range: 24, hold: 0, boost: 4, sustain: -3, aim: 0}),
});
const RANGES = Object.freeze({threshold: [-100, 12], ratio: [1, 100], knee: [0, 48], attack: [0.00001, 2],
  release: [0.001, 5], makeup: [-24, 36], mix: [0, 1], range: [0, 120], hold: [0, 2], boost: [-24, 24], sustain: [-24, 24],
  aim: [0, 48]});
export const DYNAMICS_PARAMETERS = Object.freeze(Object.keys(RANGES));

// Resolved when first asked for, not at load: in the bundled offline package every module is one
// classic script where `import.meta.url` is empty, and a `new URL` at load threw there before the
// page drew anything (the same lesson experiments/mix-desk/metering.js records).
export function dynamicsWorkletURL(base = import.meta.url) {
  try {return base ? new URL('./dynamics-worklet.js', base) : null} catch {return null}
}
const modules = new WeakMap();
export function loadDynamicsWorklet(context, {url = dynamicsWorkletURL()} = {}) {
  if (!context?.audioWorklet) return Promise.reject(new Error('Dynamics need AudioWorklet: open localhost or an HTTPS address'));
  if (!modules.has(context)) {
    const load = url ? context.audioWorklet.addModule(url.href ?? String(url))
      : Promise.reject(new Error('The dynamics worklet is not available from this bundle'));
    modules.set(context, load.catch(error => {modules.delete(context); throw error}));
  }
  return modules.get(context);
}
// The page's AudioWorkletNode, or the one a Node render's worklet runtime provides.
const nodeClass = context => {
  const Node = globalThis.AudioWorkletNode ?? context.audioWorklet?.AudioWorkletNode;
  if (typeof Node !== 'function') throw new Error('This context has no AudioWorkletNode class');
  return Node;
};
export function dynamicsSettings(mode = 'compress', values = {}) {
  const base = DYNAMICS_DEFAULTS[mode] || DYNAMICS_DEFAULTS.compress, out = {...base};
  for (const key of DYNAMICS_PARAMETERS) {
    if (values[key] === undefined) continue;
    const number = Number(values[key]);
    if (!Number.isFinite(number)) throw new Error(`Invalid dynamics setting: ${key}`);
    out[key] = Math.max(RANGES[key][0], Math.min(RANGES[key][1], number));
  }
  return out;
}

/**
 * A dynamics processor for an insert chain: {input, output, kind, name, set, key, reduction,
 * dispose}. `key(source)` feeds a sidechain; `set(values, {atSeconds, seconds})` ramps.
 */
export async function createDynamics(context, {mode = 'compress', key = false, url, ...values} = {}) {
  if (!DYNAMICS_MODES.includes(mode)) throw new Error(`No dynamics mode called ${mode}. Known: ${DYNAMICS_MODES.join(', ')}`);
  await loadDynamicsWorklet(context, url ? {url} : {});
  const Node = nodeClass(context), settings = dynamicsSettings(mode, values);
  const node = new Node(context, 'musebots-dynamics', {numberOfInputs: 2, numberOfOutputs: 1, outputChannelCount: [2],
    processorOptions: {mode, key: key === true}, parameterData: settings});
  let reduction = 0, level = -180, most = 0, height = null, keyed = null;
  node.port.onmessage = ({data}) => {
    if (data?.type !== 'reduction') return;
    reduction = data.db; level = data.level ?? -180; most = data.most ?? 0; height = Number.isFinite(data.height) ? data.height : null;
  };
  const current = {...settings};
  return {
    input: node, output: node, kind: 'dynamics', name: `Dynamics (${mode})`, mode,
    parameters: DYNAMICS_PARAMETERS.map(name => ({address: name, min: RANGES[name][0], max: RANGES[name][1], init: current[name]})),
    settings: () => ({mode, ...current}),
    // Every change is a ramp from the value being rendered, so a setting moved mid-note is heard
    // as a move, not a step. k-rate parameters take the ramp a render quantum at a time.
    set(values = {}, {atSeconds = context.currentTime, seconds = 0.05} = {}) {
      const next = dynamicsSettings(mode, {...current, ...values});
      for (const name of DYNAMICS_PARAMETERS) {
        if (next[name] === current[name]) continue;
        const param = node.parameters.get(name);
        if (param.cancelAndHoldAtTime) param.cancelAndHoldAtTime(atSeconds);
        else {param.cancelScheduledValues(atSeconds); param.setValueAtTime(param.value, atSeconds)}
        param.linearRampToValueAtTime(next[name], atSeconds + Math.max(0.005, seconds));
        current[name] = next[name];
      }
      return {...current};
    },
    // A sidechain: another signal the processor listens to instead of its programme.
    key(source) {
      if (keyed) {try {keyed.disconnect(node, 0, 1)} catch {}}
      keyed = source || null;
      if (keyed) keyed.connect(node, 0, 1);
      node.port.postMessage({type: 'mode', mode, key: Boolean(keyed) || mode === 'duck'});
      return this;
    },
    reduction: () => reduction,
    // The most a transient shaper added over the same stretch, dB (0 in the other modes).
    boost: () => most,
    // How far a transient shaper's hits' attacks stand over their bodies as they come in, dB: the median of the last
    // few hits heard (null before one is heard, and in the other modes).
    height: () => height,
    // The loudest level it detected over the same stretch, dBFS: what tells a quiet stretch (no
    // reduction because nothing is there) from a light one (no reduction because it is under).
    level: () => level,
    dispose() {
      if (keyed) {try {keyed.disconnect(node, 0, 1)} catch {}}
      try {node.disconnect()} catch {}
      node.port.onmessage = null;
    },
  };
}
