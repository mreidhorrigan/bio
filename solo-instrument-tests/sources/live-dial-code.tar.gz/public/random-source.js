// mulberry32's step: the fixed odd constant its state advances by each draw.
const MULBERRY_STEP=0x6d2b79f5;

function hashSeed(value) {
  const text=String(value),numeric=Number(text);
  if(text.trim()!==''&&Number.isFinite(numeric))return numeric>>>0;
  let hash=2166136261;
  for(const character of text){hash^=character.charCodeAt(0);hash=Math.imul(hash,16777619)}
  return hash>>>0;
}

function freshSeed() {
  return hashSeed(Date.now());
}

// mulberry32: a counter (its state steps by a fixed odd constant) and a mix of it into a draw in [0, 1).
function mulberry(state){
  let value=state;value=Math.imul(value^(value>>>15),value|1);value^=value+Math.imul(value^(value>>>7),value|61);
  return((value^(value>>>14))>>>0)/4294967296;
}

export function createRandomStream(value) {
  const seed=hashSeed(value);let state=seed;
  return {
    seed,
    next(){
      state=(state+MULBERRY_STEP)>>>0;
      return mulberry(state);
    },
    snapshot(){return {algorithm:'mulberry32',seed,state}},
    restore(saved){
      if(saved?.algorithm!=='mulberry32'||saved.seed!==seed||!Number.isInteger(saved.state)||saved.state<0||saved.state>0xffffffff)throw new Error('Invalid random stream state');
      state=saved.state;
    },
  };
}
// The `index`th draw (from 0) of the stream createRandomStream(value) makes, reached directly: its state after n draws
// is its seed plus n steps, so a draw is the same however it is reached -- in order, out of order, or after a seek.
export function randomAt(value,index){
  return mulberry((hashSeed(value)+Math.imul(Math.trunc(index)+1,MULBERRY_STEP))>>>0);
}
let seed=freshSeed(),stream=createRandomStream(seed),activeStream=null;

export function configureRandomSeed(value=freshSeed()){
  seed=hashSeed(value);stream=createRandomStream(seed);return seed;
}
export function randomSeed(){return seed}
// The piece's seed while a bot is being made (bot-registry.js sets it from the ensemble's), else the page's or the
// render's: what a bot's opening harmony is drawn from (shared/opening-harmony.js), the same for the whole band.
let activeEnsembleSeed=null;
export function ensembleSeed(){return activeEnsembleSeed??seed}
export function withEnsembleSeed(value,callback){
  const previous=activeEnsembleSeed;activeEnsembleSeed=value===undefined||value===null?previous:hashSeed(value);
  try{return callback()}finally{activeEnsembleSeed=previous}
}
export function random(){return (activeStream||stream).next()}
export function withRandomStream(selected,callback) {
  const previous=activeStream;activeStream=selected;
  try{return callback()}finally{activeStream=previous}
}
// Bind methods, including methods called after an awaited corpus load, to this
// object's stream. Never leave a global random context active across an await.
export function scopeRandomObject(object,selected) {
  const seen=new Set();
  for(let prototype=object;prototype&&prototype!==Object.prototype;prototype=Object.getPrototypeOf(prototype)){
    for(const key of Object.getOwnPropertyNames(prototype)){
      if(key==='constructor'||seen.has(key))continue;seen.add(key);
      const descriptor=Object.getOwnPropertyDescriptor(prototype,key);
      if(typeof descriptor.value!=='function')continue;
      const method=descriptor.value;
      Object.defineProperty(object,key,{configurable:true,writable:true,value:function(...args){return withRandomStream(selected,()=>method.apply(this,args))}});
    }
  }
  return object;
}
export { freshSeed, hashSeed };
