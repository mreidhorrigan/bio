import {umpPacket} from './shared/ump.js';
import {roomSocketUrl} from './shared/room-socket.js';

export async function nativeMidi2Outputs({clientOnly=false}={}) {
  if(clientOnly)throw new Error('Native MIDI 2 output requires the Musebots Node server on macOS.');
  const response=await fetch('/api/midi2/outputs');
  if(!response.ok)throw new Error(`Could not query native MIDI 2 outputs (${response.status})`);
  const result=await response.json();
  if(!result.available)throw new Error(result.error||'Native MIDI 2 output is unavailable on this server');
  return result.outputs;
}

export class NativeMidi2Output {
  constructor(port,{onError=()=>{},onPacket=()=>{}}={}) {
    Object.assign(this,port);this.protocol='midi2';this.onError=onError;this.onPacket=onPacket;
    this.requests=new Map();this.nextRequest=0;
  }
  async open() {
    this.socket=new WebSocket(roomSocketUrl());
    this.socket.addEventListener('message',({data})=>{
      let message;try{message=JSON.parse(data)}catch{return;}
      const pending=this.requests.get(message.requestId);
      if(pending){clearTimeout(pending.timer);this.requests.delete(message.requestId);message.ok?pending.resolve(message):pending.reject(new Error(message.error));}
      if(message.type==='midi2_error')this.fail(new Error(message.error));
    });
    this.socket.addEventListener('close',()=>{if(!this.closed)this.fail(new Error('Native MIDI 2 connection closed'));this.rejectPending(new Error('Native MIDI 2 connection closed'));});
    await new Promise((resolve,reject)=>{
      const timer=setTimeout(()=>{this.socket.close();reject(new Error('Native MIDI 2 connection timed out'));},5000);
      this.socket.addEventListener('open',()=>{clearTimeout(timer);resolve();},{once:true});
      this.socket.addEventListener('error',()=>{clearTimeout(timer);reject(new Error('Could not connect to native MIDI 2 output'));},{once:true});
    });
    try{await this.request('midi2_open',{port:this.id});return this;}
    catch(error){this.closed=true;this.socket.close();throw error;}
  }
  fail(error){if(this.failed||this.closed)return;this.failed=error;this.onError(error);}
  rejectPending(error){for(const pending of this.requests.values()){clearTimeout(pending.timer);pending.reject(error)}this.requests.clear();}
  request(type,values={}) {
    if(this.socket?.readyState!==WebSocket.OPEN)return Promise.reject(new Error('Native MIDI 2 connection is not open'));
    return new Promise((resolve,reject)=>{
      const requestId=String(++this.nextRequest),timer=setTimeout(()=>{
        this.requests.delete(requestId);const error=new Error('Native MIDI 2 output did not respond');reject(error);this.fail(error);this.socket.close();
      },7000);
      this.requests.set(requestId,{resolve,reject,timer});
      this.socket.send(JSON.stringify({type,requestId,...values}));
    });
  }
  sendPackets(events) {
    if(this.failed)throw this.failed;
    if(this.closed||this.socket?.readyState!==WebSocket.OPEN)throw new Error('Native MIDI 2 output is closed');
    const now=performance.now(),validated=events.map(event=>{
      const packet=Array.from(umpPacket(event.packet)),delayMs=Math.max(0,(event.time??now)-now);
      if(!Number.isFinite(delayMs)||delayMs>60000)throw new Error('Schedule native MIDI 2 events at most 60 seconds ahead');
      return {packet,delayMs};
    });
    for(let index=0;index<validated.length;index+=2048)this.socket.send(JSON.stringify({type:'midi2_send',events:validated.slice(index,index+2048)}));
    for(const event of validated)this.onPacket({packet:event.packet,scheduledAt:now+event.delayMs,port:this.name,protocol:'midi2'});
  }
  sendUMP(packet,time=performance.now()){this.sendPackets([{packet,time}]);}
  cancel(){return this.request('midi2_cancel');}
  async close() {
    if(this.closed)return;this.closed=true;
    try{if(this.socket?.readyState===WebSocket.OPEN)await this.request('midi2_close');}
    finally{this.socket?.close();}
  }
}
