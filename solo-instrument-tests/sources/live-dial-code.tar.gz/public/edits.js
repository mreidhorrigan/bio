// The edits processor (edits-worklet.js) as an insert a mixer can use: loaded once per context, and scheduled by the
// edit: {kind: 'repeat' | 'reverse' | 'tapeStop', from, until (context seconds), slice (seconds, a repeat's)}.
export const EDIT_KINDS = Object.freeze(['repeat', 'reverse', 'tapeStop']);

// Resolved when first asked for, not at load, as dynamics.js resolves its own (an empty import.meta.url in a bundle).
export function editsWorkletURL(base = import.meta.url) {
  try {return base ? new URL('./edits-worklet.js', base) : null} catch {return null}
}
const modules = new WeakMap();
export function loadEditsWorklet(context, {url = editsWorkletURL()} = {}) {
  if (!context?.audioWorklet) return Promise.reject(new Error('Edits need AudioWorklet: open localhost or an HTTPS address'));
  if (!modules.has(context)) {
    const load = url ? context.audioWorklet.addModule(url.href ?? String(url))
      : Promise.reject(new Error('The edits worklet is not available from this bundle'));
    modules.set(context, load.catch(error => {modules.delete(context); throw error}));
  }
  return modules.get(context);
}
const nodeClass = context => {
  const Node = globalThis.AudioWorkletNode ?? context.audioWorklet?.AudioWorkletNode;
  if (typeof Node !== 'function') throw new Error('This context has no AudioWorkletNode class');
  return Node;
};

/** An edits insert: {input, output, kind, name, schedule(edit), clear(), dispose}. */
export async function createEdits(context, {url} = {}) {
  await loadEditsWorklet(context, url ? {url} : {});
  const Node = nodeClass(context);
  const node = new Node(context, 'musebots-edits', {numberOfInputs: 1, numberOfOutputs: 1, outputChannelCount: [2]});
  return {
    input: node, output: node, kind: 'edits', name: 'Edits', parameters: [],
    schedule(edit) {
      if (!EDIT_KINDS.includes(edit?.kind)) throw new Error(`No edit called ${edit?.kind}. Known: ${EDIT_KINDS.join(', ')}`);
      if (!(Number.isFinite(edit.from) && Number.isFinite(edit.until) && edit.until > edit.from)) throw new RangeError('An edit ends after it begins');
      node.port.postMessage({type: 'edit', kind: edit.kind, from: edit.from, until: edit.until, slice: edit.slice});
      return this;
    },
    clear() {node.port.postMessage({type: 'clear'}); return this},
    dispose() {try {node.disconnect()} catch {} node.port.onmessage = null},
  };
}
