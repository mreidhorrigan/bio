// OpenWInD's woodwinds in WebAssembly: the engine's streaming player (native/openwind stream.rs, its page calls wasm.rs)
// built for wasm32, a part played as one simulation on its saved body (the files save_body writes: body.json, I.bin,
// D.bin, law.json, rules.json), its breath groups given as the stream binary's lines are (render/synthesis/src/
// winds-lines.mjs), its sound at 48 kHz scaled as the renders scale it; or held at the live dial's rows, swayed, its
// tract and slide moved, as the stream binary takes them (liveStream: the dial's engine in a page, native/live/site).
// The same in a page's Worker and in Node. Built two ways (scripts/build-studio.mjs): for wasm32-unknown-unknown, on
// one core; and for wasm32-wasip1-threads, its bore stepped on several (native/openwind parallel.rs), each core a Worker
// (openwind-thread.js) sharing its memory -- which a page has only where it is cross-origin isolated.
const decoder=new TextDecoder(),encoder=new TextEncoder();
// (Text from its memory: copied out first, as a browser decodes no view of shared memory.)
const textAt=(buffer,at,length)=>decoder.decode(new Uint8Array(buffer,at,length).slice());

// The system calls the threaded build makes of its host (WASI preview 1), as the engine makes them: its clock, chance
// for its hash maps, its faults' text written out; no files, no environment. `memory` the module's shared memory.
export function wasiImports(memory,{said=text=>console.error(text)}={}){
  const view=()=>new DataView(memory.buffer),BAD=8;
  let line='';
  return {
    clock_time_get(id,precision,out){view().setBigUint64(out,BigInt(Math.round(id===0?Date.now()*1e6:(performance.timeOrigin+performance.now())*1e6)),true);return 0},
    random_get(at,length){for(let k=0;k<length;k+=65536){const n=Math.min(65536,length-k),bytes=crypto.getRandomValues(new Uint8Array(n));new Uint8Array(memory.buffer,at+k,n).set(bytes)}return 0},
    environ_sizes_get(count,size){view().setUint32(count,0,true);view().setUint32(size,0,true);return 0},
    environ_get(){return 0},
    fd_write(fd,iovs,n,written){
      let total=0;
      for(let k=0;k<n;k++){const at=view().getUint32(iovs+8*k,true),length=view().getUint32(iovs+8*k+4,true);line+=textAt(memory.buffer,at,length);total+=length}
      for(let newline;(newline=line.indexOf('\n'))>=0;line=line.slice(newline+1))if(fd===1||fd===2)said(line.slice(0,newline));
      view().setUint32(written,total,true);return 0;
    },
    fd_close:()=>BAD,fd_fdstat_get:()=>BAD,fd_filestat_get:()=>BAD,fd_prestat_get:()=>BAD,fd_prestat_dir_name:()=>BAD,fd_read:()=>BAD,path_open:()=>BAD,
    proc_exit(code){throw new Error(`the winds' engine exited (${code})`)},
    sched_yield:()=>0,
  };
}
// (Its least and most memory, in pages, as its import declares them: the shared memory made for it must agree.)
function memoryLimits(bytes){
  const b=new Uint8Array(bytes.buffer??bytes,bytes.byteOffset??0,bytes.byteLength);let at=8;
  const leb=()=>{let v=0,shift=0,byte;do{byte=b[at++];v+=(byte&127)*2**shift;shift+=7}while(byte&128);return v};
  const name=()=>{const n=leb();at+=n};
  while(at<b.length){
    const id=b[at++],size=leb(),end=at+size;
    if(id!==2){at=end;continue}
    for(let k=leb();k>0;k--){
      name();name();const kind=b[at++];
      if(kind===0){leb();continue}
      if(kind===1){at++;const f=b[at++];leb();if(f&1)leb();continue}
      if(kind===3){at+=2;continue}
      const flags=b[at++],initial=leb(),maximum=flags&1?leb():undefined;return {initial,maximum,shared:Boolean(flags&2)};
    }
    at=end;
  }
  return null;
}

// The module compiled from its bytes -> an engine: open(files, {single, threads}) -> a part's player. The threaded
// build's (it imports its memory) is given `thread`, a function making one of its cores' Workers (openwind-thread.js: a
// page's `new Worker(..., {type: 'module'})`); its Workers made before a player is opened on them (prepare).
export async function openwindEngine(bytes,{thread=null,said}={}){
  const limits=memoryLimits(bytes),threaded=Boolean(limits?.shared);
  const module=await WebAssembly.compile(bytes);
  let memoryOf=null,cores=null;
  if(threaded){
    if(!thread)throw new Error('the winds\' threaded engine needs its Workers (`thread`)');
    const memory=new WebAssembly.Memory({initial:limits.initial,maximum:limits.maximum,shared:true});memoryOf=memory;
    cores=threadCores(module,memory,thread,said);
  }
  const instance=await WebAssembly.instantiate(module,threaded?{env:{memory:memoryOf},wasi_snapshot_preview1:wasiImports(memoryOf,{said}),wasi:{'thread-spawn':cores.spawn}}:{});
  const x=instance.exports,memory=()=>(memoryOf??x.memory).buffer;
  // (The threaded build's main thread set up before anything else: its thread-locals -- src/wasm.rs ow_start.)
  if(threaded)x.ow_start();
  const error=()=>textAt(memory(),x.ow_error(),x.ow_error_len());
  // (Bytes copied into its memory for one call, freed after it.)
  const holding=(views,call)=>{
    const held=views.map(view=>{const data=view instanceof Uint8Array?view:new Uint8Array(view.buffer??view,view.byteOffset??0,view.byteLength);
      const at=x.ow_alloc(data.length);new Uint8Array(memory(),at,data.length).set(data);return {at,length:data.length}});
    try{return call(held)}finally{for(const {at,length} of held)x.ow_free(at,length)}
  };
  const json=value=>encoder.encode(typeof value==='string'?value:JSON.stringify(value));
  // (A live control given as JSON: refused, said why.)
  const given=(call,stream,value)=>{if(holding([json(value)],([{at,length}])=>call(stream,at,length))!==0)throw new Error(error())};
  const answer=at=>{if(!at)throw new Error(error());return JSON.parse(textAt(memory(),at,x.ow_text_len()))};
  return {
    threaded,
    // (Its cores' Workers, `threads` - 1 of them waiting, made where they are not yet: before a player is opened on them.)
    async prepare(threads){if(threaded)await cores.made(threads-1)},
    open({header,I,D,law,rules},{single=false,threads=1}={}){
      const text=value=>typeof value==='string'?encoder.encode(value):value;
      const k=threaded?Math.min(threads,cores.idle()+1):1;
      const stream=holding([text(header),I,D,text(law),text(rules)],held=>{const at=held.flatMap(({at,length})=>[at,length]);
        return k>1?x.ow_open_threaded(...at,single?1:0,k):x.ow_open(...at,single?1:0)});
      if(!stream)throw new Error(`The winds' engine could not open its body: ${error()}`);
      let closed=false;
      return {
        nativeRate:x.ow_native_rate(stream),
        threads:x.ow_threads?x.ow_threads(stream):1,
        get late(){return Number(x.ow_late(stream))},
        // A breath group (stream.rs GroupLine), an object or its JSON.
        group(line){if(holding([json(line)],([{at,length}])=>x.ow_group(stream,at,length))!==0)throw new Error(error())},
        letGo(seconds){x.ow_let_go(stream,seconds)},
        // A breath group's controls as it would shape them, `tail` seconds past its end besides (stream.rs spec), for
        // another engine to play it from (render/synthesis/src/ness-woodwind.mjs). -> its Spec (controls.rs).
        spec(line,tail=0){return answer(holding([json(line)],([{at,length}])=>x.ow_spec(stream,at,length,tail)))},
        // The live dial's, as the stream binary takes them (src/bin/musebots-openwind-stream.rs): its controls' columns
        // (`c`), the row a group's line gives `seconds` after its start (`o`), its controls held at a row (`h`: stream.rs
        // HeldLine), a vibrato on it (`v`), its player's tract (`t`), its slide (`s`).
        columns(){return answer(x.ow_columns(stream))},
        row(line,seconds){return answer(holding([json({line,seconds})],([{at,length}])=>x.ow_row(stream,at,length)))},
        hold(row,seconds=0,floor){given(x.ow_hold,stream,{row,seconds,floor})},
        vibrato({columns,depths,cents=[],rate,seconds=0}){given(x.ow_vibrato,stream,{columns,depths,cents,rate,seconds})},
        tract(resonances,seconds=0){given(x.ow_tract,stream,{resonances,seconds})},
        slide(out,seconds=0){given(x.ow_slide,stream,{out,seconds})},
        // `frames` more of its sound. -> a Float32Array of its own.
        render(frames){
          const at=x.ow_render(stream,frames);
          if(!at)throw new Error(`The winds' engine stopped: ${error()}`);
          return new Float32Array(memory(),at,frames).slice();
        },
        close(){if(!closed){closed=true;x.ow_close(stream)}},
      };
    },
    // (Its cores' Workers let go: the engine done with.)
    end(){cores?.end()},
  };
}

// The threaded build's cores: Workers each instantiating the module on its memory and waiting, on a word of their own in
// a shared control block, to be handed a thread (wasi-threads' thread-spawn: its id and start argument), which each runs
// to its end (wasi_thread_start) and then waits again -- woken by an atomic, never by its maker's event loop, which is
// busy in the engine's call that spawned it.
const SLOT=4,IDLE=0,ASKED=1,RUNNING=2,END=3,CLAIMED=4;
function threadCores(module,memory,thread,said){
  const most=16,control=new Int32Array(new SharedArrayBuffer(4*SLOT*most)),workers=[];let next=1,making=null;
  const cores={
    get count(){return workers.length},
    // (Those waiting for a thread.)
    idle(){let n=0;for(let slot=0;slot<workers.length;slot++)if(Atomics.load(control,slot*SLOT)===IDLE)n++;return n},
    // (Made where fewer than `n` wait for a thread, each answering once it has instantiated the module.)
    made(n){
      making=(making??Promise.resolve()).then(async()=>{
        while(cores.idle()<n&&workers.length<most){
          const slot=workers.length,worker=thread();
          await new Promise((done,fail)=>{
            const told=event=>{const m=event.data??event;if(m==='ready')done();else if(m?.error)fail(new Error(m.error));else if(m?.said)said?.(m.said)};
            // (A page's Worker, or Node's worker_threads one, a test's.)
            if(typeof worker.on==='function'){worker.on('message',told);worker.on('error',fail)}
            else{worker.onmessage=told;worker.onerror=e=>fail(new Error(e.message))}
            worker.postMessage({module,memory,control,slot,SLOT});
          });
          workers.push(worker);
        }
      });
      return making;
    },
    // (wasi-threads' thread-spawn: a waiting core handed the thread. -> its id, or -1 where every core is busy.)
    spawn(start){
      for(let slot=0;slot<workers.length;slot++){
        // (Claimed, then its thread written, then asked: a core never reads a thread half written.)
        if(Atomics.compareExchange(control,slot*SLOT,IDLE,CLAIMED)!==IDLE)continue;
        const id=next++;Atomics.store(control,slot*SLOT+1,id);Atomics.store(control,slot*SLOT+2,start);
        Atomics.store(control,slot*SLOT,ASKED);Atomics.notify(control,slot*SLOT);return id;
      }
      return -1;
    },
    end(){for(let slot=0;slot<workers.length;slot++){Atomics.store(control,slot*SLOT,END);Atomics.notify(control,slot*SLOT)}for(const w of workers)w.terminate?.()},
  };
  return cores;
}
export const THREAD_STATES=Object.freeze({SLOT,IDLE,ASKED,RUNNING,END,CLAIMED});

// The cores of this machine that step a body fastest, `most` at most: timed here, as no count can be known ahead (the
// owner, 2 November 2026: "We can't predict how many cores another user will have"; "we just need to make sure correct
// number of cores is used") -- a small bore's steps on many cores cost more in their meeting than they share (the
// clarinet's, 102 % of real time on nine cores, where one steps it in real time), and a machine's cores are not alike
// (the Mac's four performance cores and six efficiency cores: a part on a slow core holds every other part back). Each
// count's player opened, blown at `row` (a body at rest takes no steps), timed over `frames` once the engine has been
// warmed on the most, and closed; in `rounds`, their order turned each time, those within PRUNE of the best timed again,
// each count's pace the median of its rounds -- one window alone was a moment's (the baritone saxophone timed at 85 % on
// three cores, the machine hot and loaded, and played at 121 %). The fewest within 3 % of the best.
// -> {threads, paces: {cores: seconds a second}}
const PRUNE=1.3;
export function fastestCores(engine,files,{single=false,most=1,row,frames=4800,rate=RATE,rounds=3}={}){
  const times={};
  const timed=(k,warm)=>{const player=engine.open(files,{single,threads:k});
    try{player.hold(row);player.render(warm);const began=performance.now();player.render(frames);
      (times[player.threads]??=[]).push((performance.now()-began)/1000/(frames/rate))}finally{player.close()}};
  const median=v=>[...v].sort((a,b)=>a-b)[v.length>>1],paces={};
  timed(most,3*frames);for(const k in times)delete times[k];
  // (Each count as the engine takes it: one asked more cores than its bore has parts takes fewer.)
  let asked=[...new Set([1,2,3,4,6,8,12,16].filter(k=>k<most).concat(most))];
  for(let round=0;round<rounds&&asked.length;round++){
    for(const k of round%2?[...asked].reverse():asked)timed(k,frames/4);
    for(const k in times)paces[k]=median(times[k]);
    if(round===0)asked=Object.keys(times).map(Number);
    const best=Math.min(...asked.map(k=>paces[k]));
    asked=asked.filter(k=>paces[k]<=PRUNE*best);
    if(asked.length===1)break;
  }
  const best=Math.min(...asked.map(k=>paces[k]));
  return {threads:asked.sort((a,b)=>a-b).find(k=>paces[k]<=1.03*best),paces};
}

// The live dial's engine on a body's files (native/openwind/dial.mjs: as winds-stream.mjs WindsStream answers the Mac's
// dial), a page's: `engine` an openwindEngine or a promise of one, `files` the body's bytes as `open` takes them or a
// promise of them; on `threads` cores, or on those of `most` found fastest here blown at `row` (fastestCores: its `paces`
// then said; `files` then with the row, as {row, ...files}).
// Each fault said to `onError` as the stream binary says it on stderr, the engine playing on.
export function liveStream(engine,files,{single=false,threads=1,most=null,onError=()=>{}}={}){
  let player=null,closed=false;
  const said=(call)=>(...a)=>{if(closed||!player)return;try{call(...a)}catch(error){onError(error.message)}};
  const stream={
    threads:1,
    ready:(async()=>{
      const [given,made]=await Promise.all([files,engine]);
      await made.prepare(most??threads);
      if(closed)throw new Error('the winds\' player has ended');
      if(most>1)({threads,paces:stream.paces}=fastestCores(made,given,{single,most,row:given.row}));
      player=made.open(given,{single,threads});stream.threads=player.threads;stream.own=player.nativeRate;return stream;
    })(),
    columns:async()=>player.columns(),
    row:async(line,seconds)=>player.row(line,seconds),
    hold:said((row,seconds,floor)=>player.hold(row,seconds,floor)),
    tract:said((resonances,seconds)=>player.tract(resonances,seconds)),
    vibrato:said(line=>player.vibrato(line)),
    slide:said((out,seconds)=>player.slide(out,seconds)),
    async render(frames){if(closed)throw new Error('the winds\' player has ended');return player.render(frames)},
    close(){if(!closed){closed=true;player?.close()}},
  };
  stream.ready.catch(()=>{});
  return stream;
}

// (A part's tail as the renders end one (openwind_passages.py simulate_passage): played on until its last 10 ms are under
// the smallest step of a 24-bit file, never trimmed or faded to get there; LONGEST_TAIL at most, said where it has not.)
export const SILENT=2**-23,LONGEST_TAIL=8,RATE=48000;

// A whole part, offline: its lines (winds-lines.mjs partLines) given, then its sound rendered to its last breath's end
// and on until it has died away. `onProgress(fraction)` as it goes. -> {samples, late, tailSeconds, undecayed (dB, where
// it had not died away)}.
export function renderPart(player,lines,{onProgress=()=>{},block=RATE}={}){
  for(const line of lines)player.group(line);
  const end=Math.max(0,...lines.map(line=>line.origin+Math.max(line.plan.end,...line.plan.notes.map(n=>n.end-line.plan.origin))));
  const breathFrames=Math.ceil(end*RATE),most=breathFrames+LONGEST_TAIL*RATE,chunks=[];
  let frames=0;
  while(frames<breathFrames){const n=Math.min(block,breathFrames-frames);chunks.push(player.render(n));frames+=n;onProgress(frames/most)}
  // (Then 10 ms at a time until one is under SILENT.)
  const step=RATE/100;let last=Infinity;
  while(frames<most){const tail=player.render(step);chunks.push(tail);frames+=step;
    last=0;for(const v of tail)last=Math.max(last,Math.abs(v));
    if(last<=SILENT)break;
    if(frames%RATE===0)onProgress(frames/most)}
  const samples=new Float32Array(frames);let at=0;for(const chunk of chunks){samples.set(chunk,at);at+=chunk.length}
  onProgress(1);
  return {samples,late:player.late,tailSeconds:+(frames/RATE-end).toFixed(3),...(last>SILENT?{undecayed:+(20*Math.log10(last)).toFixed(1)}:{})};
}
