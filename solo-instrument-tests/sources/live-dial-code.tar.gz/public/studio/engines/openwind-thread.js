// One of the threaded winds' engine's cores (openwind-stream.js threadCores), in a Worker of its own: the module
// instantiated on the engine's shared memory, then each thread it is handed run to its end (wasi-threads'
// wasi_thread_start), and the next waited for on its word of the control block.
import {THREAD_STATES,wasiImports} from './openwind-stream.js';

const {IDLE,ASKED,RUNNING,END}=THREAD_STATES;
self.onmessage=async({data:{module,memory,control,slot,SLOT}})=>{
  let instance;
  try{
    instance=await WebAssembly.instantiate(module,{env:{memory},wasi_snapshot_preview1:wasiImports(memory,{said:text=>self.postMessage({said:text})}),
      // (A thread spawns none of its own: the engine's main thread spawns them all.)
      wasi:{'thread-spawn':()=>-1}});
  }catch(error){self.postMessage({error:error.message});return}
  self.postMessage('ready');
  const at=slot*SLOT;
  for(;;){
    // (Waited on while idle, or while a thread is being written to it.)
    const state=Atomics.load(control,at);
    if(state===END)break;
    if(state!==ASKED){Atomics.wait(control,at,state);continue}
    Atomics.store(control,at,RUNNING);
    try{instance.exports.wasi_thread_start(Atomics.load(control,at+1),Atomics.load(control,at+2))}
    catch(error){self.postMessage({said:`a core of the winds' engine stopped: ${error.message}`})}
    Atomics.compareExchange(control,at,RUNNING,IDLE);
  }
  self.close?.();
};
