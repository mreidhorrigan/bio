import { createDspNode, DSP_HEADROOM } from './wasm-dsp.js';
import {crossfadeLoop,loopFade} from './shared/sample-loop.js';
import { roomSocketUrl } from './shared/room-socket.js';
import {scoreTimeFields,withScoreTime} from './shared/score-time.js';
import { later } from './shared/worker-timer.js';
import {SynthSlot} from './synths/registry.js';
import {sampleLibrary} from './sample-library.js';
import {deviceProfile,voicePool} from './shared/device-profile.js';
import { notesToUMP } from './shared/ump-events.js';
import { inspectUMP, bendSemitones, noteOn, noteOff, channelControl, perNoteController, perNoteManagement, perNoteBendRange, programChange } from './shared/ump.js';
import {BowedIdentities,bowedEvents,BOWED_BEND_RANGE} from './shared/performers/bowed-midi2.js';
import {windEvents,windRelease} from './shared/performers/wind-midi2.js';
import {articulationOfStroke} from './shared/performers/bowed-articulation.js';
import {stringsModelLimits} from './shared/performers/physical-strings.js';
import {bowedLimits} from './shared/performers/bowed-line.js';
import { GM_PROGRAMS, midiProgramSetting, programFor } from './shared/general-midi.js';
import { MidiDelivery } from './shared/midi-delivery.js';
import { NativeMidi2Output, nativeMidi2Outputs } from './native-midi2-output.js';
import { playUmpSequence } from './ump-playback.js';
import { BufferedClock } from "./timing.js";
import {
  bendRangeMessages,
  MidiRouteRegistry,
  MpeChannelAllocator,
  mpeExpressionMessages,
  mpePitch,
  mpeZoneMessages,
  normalizedMidi7,
} from "./shared/pitch.js";
import {
  FAMILIES,
  MODEL,
  WAVE_MODELS,
  articulationOf,
  bipolar32,
  bipolar7,
  bipolarFrom32,
  familyFor,
  CATEGORY_ROLES,
  FAMILY_ROLES,
  noteShape,
  rampedControls,
  unit32,
  velocityGain as familyVelocityGain,
  velocityAmplitude,
} from "./shared/articulation.js";
import { normalizeStrike, pieceForNote, pieceOf, strikeControllers, strikeGain, strikeShape, strikeTone } from "./shared/percussion-expression.js";
import { expandStream, expectedVoices } from "./shared/kernel-stream.js";
import { soundObjectControls } from "./shared/sound-object.js";
import { claimKick } from "./shared/performers/ensemble-kicks.js";
import { DRUM_PITCHES } from "./shared/drum-pitches.js";
import { KIT_CHANNEL_NAMES, KIT_HOMES, kitChannelOf, kitHitPan, kitTrackId } from "./shared/kit-channels.js";
import { kitPitch } from "./synths/drum-kit.js";
import { random, randomAt, randomSeed, hashSeed, createRandomStream, scopeRandomObject } from "./random-source.js";
import { applyTuningSystem, validateTuningPayload } from "./shared/tuning.js";
import {
  expressivePerformance,
  metricalVelocity,
  performanceTimeline,
  placedVelocity,
} from "./shared/expression.js";
import { EXPRESSION_CONFIG } from "./expression-config.js";
import { sampleTrim } from "./shared/sample-levels.js";
import { ramp, setAt } from "./mixer-parts.js";
import { layeredChoice } from "./shared/sample-layers.js";
import {pressureOf} from './shared/performers/techniques.js';
import {stemLevelDb} from './shared/performers/sound-power.js';

const midiHz = (note) => 440 * 2 ** ((note - 69) / 12);
const hzMidi = (hz) => 69 + 12 * Math.log2(Math.max(0.001, hz) / 440);
const noteNames = {
  C: 0,
  "C#": 1,
  Db: 1,
  D: 2,
  "D#": 3,
  Eb: 3,
  E: 4,
  F: 5,
  "F#": 6,
  Gb: 6,
  G: 7,
  "G#": 8,
  Ab: 8,
  A: 9,
  "A#": 10,
  Bb: 10,
  B: 11,
};
const midiRoutes = new MidiRouteRegistry();
let nextMidiRoute = 1;

// How near two pitches have to be to count as the same note played again. A tenth of a
// semitone: far enough apart that a quarter-tone inflection is its own voice, near enough that
// a bot repeating a chord tone does not stack it.
const RETRIGGER_SEMITONES=.1;

// MIDI 2's Pitch 7.9 is seven integer bits and nine fractional: 65535/512 semitones. Named
// here because `captureUMP` has to decline a note above it rather than throw out of a tick.
const PITCH_CEILING=65535/512;

// A bowed stroke's note as MIDI 2.0 (bowed-midi2.js), on a physical model (an engine's `physical`): its number its
// pitch's nearest free one (BowedIdentities), its bend range said once, first; kept with the part (physical.ump: a
// render's model reads it back), or, live, sent to the strings synth (physical.node).
function bowedNote(physical,entry,engine){
  const note=(physical.identities??=new BowedIdentities()).take(entry.note,entry.at,entry.at+entry.seconds);
  (physical.notes??=new Map()).set(entry.id,note);
  const events=[...(physical.ranged?[]:[{time:0,packet:Array.from(perNoteBendRange({range:BOWED_BEND_RANGE}))}]),...bowedEvents(entry,{note})]
    .map(({time,packet})=>({seconds:+(entry.at+time).toFixed(6),packet}));
  physical.ranged=true;bowedSend(physical,events,engine);
}
// A stroke let go before its end: its note's Note Off then.
function bowedRelease(physical,entry,at,engine){
  const note=physical?.notes?.get(entry.id);if(note==null||!(at<entry.at+entry.seconds))return;
  bowedSend(physical,[{seconds:at,packet:Array.from(noteOff({note}))}],engine);
}
function bowedSend(physical,events,engine){
  if(physical.mode==='live'){physical.node?.ump?.(events);
    // (Live, its log kept only as long as a release may still find its stroke.)
    const now=engine.clockTime();if(physical.log.length>64)physical.log=physical.log.filter(each=>each.at+each.seconds>now-1)}
  else (physical.ump??=[]).push(...events);
}
// A timeline's value at a moment: its points joined by straight lines, as the voice joins them.
function pointValue(points,at){
  if(!points?.length)return 0;
  if(at<=points[0].at)return points[0].value;
  for(let index=1;index<points.length;index++){
    const right=points[index];
    if(at<=right.at){
      const left=points[index-1],span=right.at-left.at;
      return span>0?left.value+(right.value-left.value)*(at-left.at)/span:right.value;
    }
  }
  return points.at(-1).value;
}
// A MIDI 2 packet as the voice's control: per-note bend, pressure and the registered controllers
// the voice answers -- brightness (#74), timbre (#71) and pan (#10). The articulation
// controllers (#72, #73, #75) are already in the note's shape.
function engineControl(event){
  const message=inspectUMP(event.packet);
  if(message.kind==='perNoteBend')return [{seconds:event.time,action:1,value:bendSemitones(message.data)}];
  if(message.kind==='perNotePressure')return [{seconds:event.time,action:2,value:message.data/0xffffffff}];
  if(message.kind==='perNoteController'){
    if(message.attribute===74)return [{seconds:event.time,action:3,value:message.data/0xffffffff}];
    if(message.attribute===71)return [{seconds:event.time,action:6,value:.5+bipolarFrom32(message.data)/2}];
    if(message.attribute===10)return [{seconds:event.time,action:7,value:bipolarFrom32(message.data)}];
  }
  return [];
}
// A captured note's UMP address, {group, channel, note}: its Note On's.
function umpAddressOf(batch){
  const on=batch?.events.find(event=>inspectUMP(event.packet).kind==='noteOn');
  if(!on)return null;
  const {group,channel,note}=inspectUMP(on.packet);
  return {group,channel,note};
}
// Controls as the voice hears them: see rampedControls in shared/articulation.js.
export {rampedControls};
function setLimiter(limiter){for(const [key,value] of Object.entries(BOT_LIMITER))limiter[key].value=value}
// Moves an AudioParam from the value it is producing now to `target`: over `seconds`, or at once, as the mixer moves
// its settings (mixer-parts.js ramp: a ramp under way held where it has got to, else begun at now from the value last
// given). A ramp begins at the event before it, and where nothing was scheduled after now, cancelAndHoldAtTime holds
// nothing: a bot's stop, faded twenty seconds after its start's fade in, ran from that fade's end and dropped 14 dB
// within 4 ms (measured, 29 September 2026; the user: "each section seems to have a hard cut at the end, producing a
// click").
function heldRamp(param,target,now,seconds){
  if (seconds > 0) ramp(param, target, now, seconds, 0.01);
  else setAt(param, target, now);
}
// How bright a sample plays at a velocity: open at the top, darker the softer it is.
// A chord's velocities, voice by voice: the top carries, the bass is firm, the inner voices sit
// under both, and no two are quite the same. Our constants: a few hundredths either way, which is
// the scale of a pianist's voicing within one hand, not a change of dynamic.
export function chordVelocities(notes,velocity,random=()=>.5){
  const sorted=[...notes].map((note,index)=>({note,index})).sort((a,b)=>a.note-b.note),
    out=Array(notes.length).fill(velocity),last=sorted.length-1;
  sorted.forEach(({index},rank)=>{
    const lift=rank===last&&last>0?.07:rank===0&&last>0?.03:-.04;
    out[index]=Math.max(.05,Math.min(1,velocity+lift+(random()-.5)*.04));
  });
  return out;
}
export const sampleBrightnessHz=velocity=>1400*2**(3.8*Math.max(0,Math.min(1,velocity)));
// A stroke on a recorded drum (sampleFile), ours: a shelf above 3 kHz, 6 dB per octave of the stroke's brightness within
// -12 and +9 dB; a rimshot's crack a lift of 0.4 per unit of noise over the first 8 ms, at most 1.6 times; a damped
// stroke kept to no less than 8% of its recording with a fade of at most 60 ms; a hat's ring from its closed length to
// four times it by its opening (houseDrum's closed and open hats, 35 and 140 ms).
// The most a held stroke's expression moves its recording from the level it was struck at, as a factor (authored: 26 dB
// down, 12 up).
const SAMPLE_EXPRESSION=Object.freeze([.05,4]);
// A held stroke's expression on a recording struck at `velocity`: its curve's velocities ({curve, step, law}: section-seat.js
// dynamicsOf), each as a factor on the recording's level -- its amplitude under its family's law over the struck one's.
export function expressionOf({curve,law={}},velocity){
  const struck=Math.max(1e-6,velocityAmplitude(velocity,law.rangeDb,law.exponent));
  return Float32Array.from(curve,value=>Math.max(SAMPLE_EXPRESSION[0],Math.min(SAMPLE_EXPRESSION[1],velocityAmplitude(value,law.rangeDb,law.exponent)/struck)));
}
const RECORDED_STROKE=Object.freeze({shelfHz:3000,shelfDbPerOctave:6,shelfDb:Object.freeze([-12,9]),crackPerNoise:.4,crackMost:1.6,
  crackSeconds:.008,dampedShare:.08,dampedFadeMost:.06,hatRing:4});
// A struck recording's level at the pivot velocity, as the old span had it there (0.28 + 0.5 x 0.7), and the family whose
// velocity curve each piece's recordings follow.
// A line glides into its next note (voice): within this many semitones in a family that glides of itself, and within an
// octave where the note asks for it (expression.glide), as a player's portamento may span one; an asked glide across a
// silence of up to askedGapShare of the last note (a line played a little detached is still a line).
const LINE_GLIDE=Object.freeze({familyLeap:7,askedLeap:12,askedGapShare:.25});
// A seat's note told to the score once, whole, by its first stroke (options.stroke.captured: its pitch, its seconds, its
// glide), its later strokes -- a breath's, a change of bow's -- not at all, on a voice or a MIDI note as sampleFile tells
// them: each had been written a note of its own (wind-seat.js, section-seat.js). (`by`: the semitones its tuning moved it.)
const toldBy=stroke=>stroke?.captured===false?{captured:false}:stroke?.captured&&typeof stroke.captured==='object'&&Number.isFinite(Number(stroke.captured.pitch))
  ?{told:{pitch:Number(stroke.captured.pitch),seconds:Number(stroke.captured.seconds)||0,...(stroke.captured.glide?{glide:{...stroke.captured.glide}}:{}),
    // (And where its player breathed inside it, at written places: shares of its written length, wind-seat.js breathPlaces.)
    ...(Array.isArray(stroke.captured.breaths)&&stroke.captured.breaths.length?{breaths:[...stroke.captured.breaths]}:{}),...(stroke.captured.breathAfter===true?{breathAfter:true}:{}),
    // (And its written dynamic, as its player wrote it before playing it: section-seat.js writtenAt.)
    ...(writtenOf(stroke.captured.written)?{written:writtenOf(stroke.captured.written)}:{})}}:{};
// A note's written dynamic as its player gives it ({velocity, mark}), or null.
const writtenOf=written=>written&&typeof written==='object'&&Number.isFinite(Number(written.velocity))&&typeof written.mark==='string'?{velocity:+Number(written.velocity),mark:written.mark}:null;
const toldTuned=(told,by)=>told&&by?{...told,pitch:told.pitch+by,...(told.glide?{glide:{...told.glide,from:told.glide.from+by}}:{})}:told;
const RECORDED_PIVOT_GAIN=.28+.5*.7,RECORDED_FAMILIES=Object.freeze({kick:'kick',snare:'snareBody',tom:'tom',conga:'tom',hat:'hat',ride:'hat',crash:'hat',clap:'clap',perc:'shaker'});
// The WASM core's headroom, restored where its output is read (wasm-dsp.js).
export { DSP_HEADROOM };
// The limiter on a bot's own output (with `dynamics`), and on each of a split kit's channels (splitKit): a safety,
// not a sound, so it waits at full scale (-1 dBFS, a hard knee) and catches only an over. At -8 dB with an 8 dB knee and
// 12:1 it compressed every bot from about -12 dBFS: a snare's accent peaked 0.3 dB over its normal stroke (the odd/prime
// rudiments report's T33; scripts/dynamic-hierarchy.mjs).
const BOT_LIMITER=Object.freeze({threshold:-1,knee:0,ratio:20,attack:.001,release:.1});
// A recording's held level (dBFS RMS of its first channel): from its attack's end (its metadata's, else a twentieth of a
// second) to where its player lets it go (its releaseAt, else nine tenths of it) -- its whole held part, as a modelled
// note's is measured (render/synthesis/src/ness.mjs heldGain) -- measured once a buffer, on at most HELD_POINTS of its
// samples spread over it (a Weyl sequence: no periodic tone aliases with it; within a hundredth of a decibel of every
// sample's), so that a recording's first note costs the same whatever its length, live as in a render.
const HELD_LEVELS=new WeakMap,HELD_POINTS=8192,GOLDEN=(Math.sqrt(5)-1)/2;
export function heldLevelDb(buffer,metadata=null){
  if(HELD_LEVELS.has(buffer))return HELD_LEVELS.get(buffer);
  const x=buffer.getChannelData(0),rate=buffer.sampleRate,from=Math.round(Math.max(.05,Number(metadata?.attack)||0)*rate),
    to=Math.min(x.length,Math.round((Number(metadata?.releaseAt)>0?Number(metadata.releaseAt):.9*buffer.duration)*rate)),span=to-from;
  let sum=0;const points=Math.min(span,HELD_POINTS);
  for(let k=0;k<points;k++){const v=x[from+(span<=HELD_POINTS?k:Math.floor(((k*GOLDEN)%1)*span))];sum+=v*v}
  const db=points>0?10*Math.log10(sum/points+1e-20):-200;
  HELD_LEVELS.set(buffer,db);return db;
}
// Each bot's headroom (dB): its output stands this far under the level its voices are set for, before its limiter, so
// its loudest note stays under the limiter's threshold and an accent it asks for stays louder than a normal stroke (the
// odd/prime rudiments report's T33, measured by scripts/dynamic-hierarchy.mjs and held by test/audio/dynamic-hierarchy.test.mjs).
// It is the most any family's velocity curve rises over its pivot, where each voice's level is set (articulation.js
// velocityGain at full velocity: +7.3 dB for the piano's, +4.9 for the snare's), with the limiter's threshold under full
// scale above that.
export const BOT_HEADROOM_DB=Math.max(...Object.values(FAMILIES).map(family=>20*Math.log10(familyVelocityGain(1,family.rangeDb??30,family.velocityExponent??2))))
  -BOT_LIMITER.threshold;
// Renderers a split kit does not make: a plugin's kit has one output here, and another instance of it per drum would
// load the whole plugin again (splitKit).
const UNSPLIT_BACKENDS=Object.freeze(['vst3','wam']);
// A hat struck at least this open rings until it is closed, and closing it stops the ring this fast (ours: a closed hat
// in a kit's choke group; 30 ms is about a pedal's travel).
const OPEN_HAT_RINGS=.25,HAT_CHOKE_SECONDS=.03;
// A cymbal choked by the hand that grabs it stops this fast (ours: a hand's grip damps it a little slower than a hat's
// pedal closes), and the cymbals a hand chokes.
const CYMBAL_CHOKE_SECONDS=.05,CHOKED_PIECES=Object.freeze(['crash']);
// A hit's excitation and its gain, named apart (the odd/prime rudiments report's §8.1, §9.1): how hard it is struck, a
// normalized coordinate whose force is unknown, and what answers it (recorded layers, a synthesized voice, a plugin); and
// the level it is scaled by after, in dB. A ghost stroke brought up and an accent brought down stay what they are. A hit
// turned up past its stroke is said to be hyperreal (the extreme-aesthetics report's §8.4): a produced sound, louder
// than the strike, never read as a harder one.
const excitationAndGain = (velocity, level, response) => ({
  excitation: {value: velocity, unit: "normalized", force: "unknown", response},
  gain: {db: level > 0 ? 20 * Math.log10(level) : -Infinity, evidence: "authored", hyperreal: level > 1},
});
// What the synthesized kit can and cannot do (the report's §9.2, §9.3), as drum-kit.js drumKitCapabilities says it of a
// sampled one: each piece's voices, answering excitation continuously; no takes, no microphones; hits faster than a ring
// each a new voice, until the engine's voices run out and it takes the quietest already fading, else the oldest, never a
// protected one (a held sound object: the DSP core's SHAPE_PROTECTED).
export function synthesizedKitCapabilities() {
  return {kit: "synthesized", pieces: Object.fromEntries(Object.entries(DRUM_KIT).map(([piece, {layers}]) => [piece, {voices: layers.map(layer => layer.family)}])),
    microphones: {premixed: [], oneTakeAContact: true},
    excitation: {unit: "normalized (0-1), the stroke's velocity", picks: "each voice's shape and level (articulation.js families), continuously", force: "unknown"},
    interpolation: {layers: "none needed: one voice, shaped by the velocity", crossfaded: "none"},
    repeated: {model: "each hit a new voice, the ones before ringing on", cap: "the engine's voices (maxVoices)", capPer: "engine", overflow: "the quietest voice already fading, else the oldest, never a protected one; with every voice protected, the hit is refused"},
    gain: "a hit's level scales its voices, whatever their shape: gain is not excitation"};
}
// The synthesized kit. Each piece is the voices it is made of (articulation.js families), its
// General MIDI note, where it sits, and how long it sounds. Levels are at the pivot velocity.
export const DRUM_KIT=Object.freeze({
  // Levels after the measured TR-808 contour (articulation.js), which put less of the kick where loudness
  // weighting listens and more of the closed hat's tail in: each rescaled by what the change measured on eight hits
  // (kick -2.3 dB, soft kick -2.7, closed hat +3.0, tom -0.3), so the kit's calibrated balance stands.
  kick:{note:36,duration:.45,pan:0,layers:[{family:'kick',pitch:33,level:.0915}]},
  softKick:{note:36,duration:.5,pan:0,layers:[{family:'kick',pitch:31,level:.1153}]},
  snare:{note:38,duration:.22,pan:-.08,layers:[{family:'snareBody',pitch:54,level:.07},{family:'snareWires',pitch:69,level:.085}]},
  brush:{note:38,duration:.3,pan:-.08,layers:[{family:'snareWires',pitch:69,level:.2}]},
  clap:{note:39,duration:.3,pan:.06,layers:[{family:'clap',pitch:69,level:.08}]},
  closedHat:{note:42,duration:.07,pan:.28,layers:[{family:'hat',pitch:55.8,level:.046}]},
  openHat:{note:46,duration:.45,pan:.3,layers:[{family:'hat',pitch:55.8,level:.055,variant:'open'}]},
  ride:{note:51,duration:1.4,pan:-.32,layers:[{family:'hat',pitch:61,level:.12,variant:'ride'}]},
  // A crash: the ride's metal with more wash and a longer, darker ring (ours; an acoustic crash's measured T60 was not
  // found, research/audio-expression-literature.md 7.4). Its level is the ride's.
  crash:{note:49,duration:2.2,pan:.36,layers:[{family:'hat',pitch:57,level:.12,variant:'ride',shape:{decay:2.4,cutoff:4200,noiseSustain:.7,resonance:.12}}]},
  tom:{note:45,duration:.45,pan:.15,layers:[{family:'tom',pitch:45,level:.0773}]},
  perc:{note:56,duration:.08,pan:.2,layers:[{family:'shaker',pitch:69,level:.18}]},
});
// A recording's measured loop ([start, end] s: its metadata's loop, and how well its ends match, loopMatch), where it
// lies inside the buffer with room before its start for the crossfade: [start, end, fade, match]; else none.
export function loopOf(entry, buffer) {
  const loop = entry?.loop;
  if (!Array.isArray(loop) || !(loop[1] > loop[0]) || loop[1] > buffer.duration) return null;
  const fade = loopFade(loop[0], loop[1]);
  const match = Number.isFinite(entry.loopMatch) ? Math.max(0, Math.min(1, entry.loopMatch)) : 1;
  // (Its ends on whole samples, where its crossfade is made: a source wrapping a fraction of a sample from there steps.)
  const rate = buffer.sampleRate, start = Math.round(loop[0] * rate) / rate, end = Math.round(loop[1] * rate) / rate;
  return start >= fade ? [start, end, fade, match] : null;
}
// The buffer with its loop's end crossfaded into the sound that leads to its start (shared/sample-loop.js crossfadeLoop,
// its gains held for how well the ends match). Made once a buffer and loop.
const loopedBuffers = new WeakMap();
export function loopedBuffer(context, buffer, [start, end, fade, match = 1]) {
  const key = `${start}:${end}:${fade}:${match}`, made = loopedBuffers.get(buffer) ?? loopedBuffers.set(buffer, new Map()).get(buffer);
  if (made.has(key)) return made.get(key);
  const rate = buffer.sampleRate, out = context.createBuffer(buffer.numberOfChannels, buffer.length, rate);
  for (let channel = 0; channel < buffer.numberOfChannels; channel++) {
    const copy = crossfadeLoop(buffer.getChannelData(channel), Math.round(start * rate), Math.round(end * rate), Math.round(fade * rate), match);
    if (typeof out.copyToChannel === 'function') out.copyToChannel(copy, channel); else out.getChannelData(channel).set(copy);
  }
  made.set(key, out);
  return out;
}

export class AudioEngine {
  constructor({ clientOnly = false, context = null, dynamics = true, monitorOutput = false, dspFactory = createDspNode, seed = randomSeed(), synthesizer='musebots', synthOptions={}, stackRepeats=false, levelTrimDb = 0, device = null } = {}) {
    // What the device affords (shared/device-profile.js): its decoded recordings and voices at once, named (a page's
    // ?device=phone, a render's 'unbounded') or as the browser says it.
    this.device = deviceProfile(globalThis, { tier: device });
    // Its level trim under its headroom (shared/bot-level-trims.js, given by the host for the bot it plays for).
    this.levelTrimDb = Number.isFinite(Number(levelTrimDb)) ? Number(levelTrimDb) : 0;
    this.clientOnly = clientOnly;
    this.ctx = context;
    this.dynamics = dynamics;
    // Played live until startOffline says otherwise: a bot planning while the music plays has a deadline.
    this.offline = false;
    this.monitorOutput = monitorOutput;
    this.synthesizer=synthesizer;this.synthOptions=synthOptions;
    this.dspFactory = dspFactory===createDspNode?(context,options)=>SynthSlot.create(context,{id:this.synthesizer,seed:options.seed,options:this.synthOptions}):dspFactory;
    this.activeGraphs = new Set();
    this.umpIdentities = new Map();
    this.nextDspIdentity = 1;
    // Every note the renderer is still holding, by identity. Kept because a note that has
    // begun has to be stoppable: both renderers implement an early release and, until this
    // register existed, nothing could name the note to send it to. See releaseNote().
    this.sounding = new Map();
    // A kit split into a channel per drum (splitKit): channel -> {renderer, chain, track}; null while it is one.
    this.kit = null;
    // Off by default, because stacking a note on top of itself is a fault rather than a
    // texture; a bot that genuinely wants the pile can set it.
    this.stackRepeats = stackRepeats;
    this.audioGeneration=0;
    this.midiProtocol = 'midi1';
    this.midiGroup = 0;
    this.midiTimers = new Set();
    // The program each channel of the output was last asked for (setMidiProgram, programFor), so a Program Change is
    // sent only when a note's program differs.
    this.midiProgram = 'none';
    this.programsSent = new Map();
    this.mpeEnabled = true;
    this.mpeBendRange = 48;
    this.mpeZone = "lower";
    this.mpeAllocator = new MpeChannelAllocator();
    this.midiRouteId = `audio-${nextMidiRoute++}`;
    this.seed=hashSeed(seed);this.randomStream=createRandomStream(`${this.seed}:audio`);
    // Which recording a stroke plays (randomFile) is drawn apart from the engine's other draws (noise, a voice's own
    // variation): the nth choice its own keyed draw, so that more or fewer of the others never move it (the
    // implementation dossier's A002).
    this.sampleChoices=0;
    scopeRandomObject(this,this.randomStream);
  }
  async start(resume = true) {
    this.ctx ||= new AudioContext({ latencyHint: "interactive" });
    this.clock ||= new BufferedClock();
    this.buffers ||= new Map();
    if (resume && !this.master) this.buildOutputChain();
    if (resume) this.attachSynth();
    if (resume && this.ctx.state !== "running") {
      const resumed = this.ctx.resume();
      await Promise.race([
        resumed,
        new Promise((_, reject) =>
          setTimeout(
            () =>
              reject(new Error("Browser audio did not start within 2 seconds")),
            2000,
          ),
        ),
      ]);
    }
    if (resume && this.dspInitialization) await this.dspInitialization;
    this.muted = false;
    this.report("audio_context", {
      state: this.ctx.state,
      sampleRate: this.ctx.sampleRate,
    });
    if (resume && this.ctx.state !== "running")
      throw new Error(
        `Browser audio is ${this.ctx.state}; allow audio autoplay for this page and try again`,
      );
  }
  // An OfflineAudioContext is suspended until startRendering() and cannot be
  // resumed first, so the offline path skips the autoplay checks. `destination`
  // may be a mixer track input; null leaves the output for setMixer() to route.
  async startOffline({ destination } = {}) {
    if (!this.ctx) throw new Error("Offline audio needs an audio context");
    // Rendered, not played: a bot's plans take the time they need (shared/performers/live.js), so a render does not
    // depend on the machine's speed.
    this.offline = true;
    this.clock ||= new BufferedClock();
    this.buffers ||= new Map();
    if (!this.master) this.buildOutputChain(destination);
    await this.attachSynth();
    this.muted = false;
    this.report("audio_context", {
      state: this.ctx.state,
      sampleRate: this.ctx.sampleRate,
      offline: true,
    });
  }
  buildOutputChain(destination) {
    this.master = this.ctx.createGain();
    this.headroom = this.ctx.createGain();
    this.headroom.gain.value = 10 ** ((this.levelTrimDb - BOT_HEADROOM_DB) / 20);
    this.limiter = this.dynamics ? this.ctx.createDynamicsCompressor() : null;
    this.spatialGain = this.ctx.createGain();
    this.master.gain.value = this.pendingPerformanceGain ?? 4;
    this.spatialGain.gain.value = this.pendingSpatialGain ?? 1;
    this.appliedPerformanceGain = this.master.gain.value;
    this.appliedSpatialGain = this.spatialGain.gain.value;
    this.master.connect(this.headroom);
    if (this.limiter) setLimiter(this.limiter);
    // (A distance's low-pass only where one is asked for (setSpatialAttenuation): never by default -- at 18 kHz, Q 0.55, it
    // had taken 1.8 dB off every bot's 10 kHz and 3.8 dB off its 15 kHz, in every render, though nothing asked it to (the
    // owner, 10 October 2026: "be careful with high-frequency loss ... unless that's done precisely for the room, it'll
    // sound like a low-pass filter").)
    this.spatialFilter = null;
    if (this.pendingSpatialCutoff != null) this.spatialFilter = this.spatialFilterOf(this.pendingSpatialCutoff, this.pendingSpatialQ ?? 0.55);
    (this.limiter ? this.headroom.connect(this.limiter) : this.headroom).connect(this.spatialFilter ?? this.spatialGain);
    this.spatialFilter?.connect(this.spatialGain);
    let output = this.spatialGain;
    if (this.monitorOutput) {
      this.outputAnalyser = this.ctx.createAnalyser();
      this.outputAnalyser.fftSize = 256;
      this.outputSamples = new Float32Array(this.outputAnalyser.fftSize);
      this.spatialGain.connect(this.outputAnalyser);
      output = this.outputAnalyser;
    }
    if (destination !== null) output.connect(destination ?? this.ctx.destination);
  }
  attachSynth() {
    if (this.dspFactory && !this.dspNode && !this.dspInitialization) {
      const generation=this.audioGeneration;
      this.dspInitialization = Promise.resolve(this.dspFactory(this.ctx,{seed:this.seed}))
        .then((node) => {
          if(generation!==this.audioGeneration){node.disconnect();throw new Error('Audio start was cancelled')}
          this.dspNode = node;
          node.connect(this.master);this.followSynth();
          this.report("wasm_dsp_ready", { sampleRate: this.ctx.sampleRate });
          return node;
        })
        .catch((error) => {
          if(generation===this.audioGeneration)this.dspInitialization=null;
          this.report("wasm_dsp_error", { message: String(error?.message || error) });
          throw error;
        });
    }
    return this.dspInitialization;
  }
  outputLevel() {
    if (!this.outputAnalyser || !this.outputSamples) return null;
    this.outputAnalyser.getFloatTimeDomainData(this.outputSamples);
    let sum = 0;
    for (const value of this.outputSamples) sum += value * value;
    return Math.sqrt(sum / this.outputSamples.length);
  }
  // A voice held until its source ends, and one of the device's voices (shared/device-profile.js voicePool: all the
  // page's engines together). Past the device's cap the oldest of them is shed, faded over 10 ms and stopped as a
  // replaced bank's voices are (stopSampleVoices); a voice that can shed none is silenced, its source left to end.
  retainGraph(source, nodes) {
    const graph = { source, nodes };
    this.activeGraphs.add(graph);
    const pool = this.ctx ? voicePool(this.ctx, this.device) : null;
    const release = () => {
      for (const node of nodes) {
        try { node.disconnect(); } catch { /* already disconnected */ }
      }
      this.activeGraphs.delete(graph);
      pool?.release(graph);
    };
    graph.shed = () => {
      const at = this.ctx.currentTime, gain = (graph.amp ?? graph.sampleGain ?? nodes.findLast((node) => node?.gain?.setValueAtTime))?.gain;
      if (gain) {
        if (gain.cancelAndHoldAtTime) gain.cancelAndHoldAtTime(at); else { gain.cancelScheduledValues(at); gain.setValueAtTime(gain.value, at); }
        gain.linearRampToValueAtTime(0, at + .01);
      }
      try { source.stop(at + .011); } catch { /* not started, or stopped already */ }
    };
    if (typeof source.addEventListener === "function")
      source.addEventListener("ended", release, { once: true });
    else if ("onended" in source) source.onended = release;
    if (pool && !pool.admit(graph)) { graph.refused = true; for (const node of nodes) { try { node.disconnect(); } catch { /* not connected */ } } }
    return graph;
  }
  async configure(definition, mode = "synth", midiOutputId = "") {
    if (mode !== "midi" && this.midiOutput) await this.closeMidiOutput();
    this.definition = definition;
    this.expressionProfile =
      EXPRESSION_CONFIG.categoryProfiles[definition.category] || "neutral";
    // The channel's role on a desk: the one the bot declares, where it declares one (its definition's deskRole, as a singer
    // declares itself a vocal; else by its category, articulation.js CATEGORY_ROLES).
    this.declaredRole = definition.deskRole ?? CATEGORY_ROLES[definition.category] ?? null;
    if (this.declaredRole && this.declaredRole !== this.role) { this.role = this.declaredRole; this.mixerTrack?.setRole?.(this.role); }
    this.defaultMidiChannel = definition.midiChannel
      ? definition.midiChannel - 1
      : null;
    if (mode === "samples" && definition.sampleBank && this.sampleSource!=='local')
      await this.loadSampleBank(definition.sampleBank);
    this.sampleFiles||=[];
    this.mode = mode;
    if (mode === "midi") await this.configureMidi(midiOutputId);
  }
  // A bank, as much of it as the device holds (sample-library.js), its loading said on the bot's card as it goes
  // (bot_status 'loading'), and what a device held it to said after ('limited'); failing, the card's line is cleared
  // and the caller told, as before.
  async loadSampleBank(bank,options={}) {
    if(this.sampleLease?.bank===bank&&(!options.preset||this.sampleLease.preset===options.preset))return this.sampleLease;
    const generation=this.sampleGeneration=(this.sampleGeneration||0)+1;
    const onProgress=progress=>{options.onProgress?.(progress);
      if(generation===this.sampleGeneration)this.report('bot_status',{state:'loading',message:`Loading its recordings: ${progress.loaded} of ${progress.total}`,loaded:progress.loaded,total:progress.total})};
    let lease;
    try{lease=await sampleLibrary(this.ctx,{profile:this.device}).acquire(bank,{preset:this.samplePreset,...options,onProgress})}
    catch(error){if(generation===this.sampleGeneration)this.report('bot_status',{state:'',message:null});throw error}
    if(generation!==this.sampleGeneration){lease.release();throw new Error('Sample loading was cancelled')}
    this.useSamples(lease);
    const total=lease.files.length+(lease.left?.length??0);
    this.report('bot_status',lease.complete===false?{state:'limited',loaded:lease.files.length,total,
      message:lease.pressure?`This device ran short of memory, so this bot plays ${lease.files.length} of its ${total} recordings`
        :`This device holds ${Math.round(this.device.decodedBytes/1048576)} MiB of recordings at once, so this bot plays ${lease.files.length} of its ${total}`}
      :{state:'',message:null});
    return lease;
  }
  async loadSampleFiles(files,options={}){
    const generation=this.sampleGeneration=(this.sampleGeneration||0)+1;
    const lease=await sampleLibrary(this.ctx,{profile:this.device}).importFiles(files,options);
    if(generation!==this.sampleGeneration){lease.release();throw new Error('Sample loading was cancelled')}
    this.useSamples(lease);return lease;
  }
  useSamples(lease){
    this.sampleGeneration=(this.sampleGeneration||0)+1;
    this.stopSampleVoices();
    this.sampleLease?.release();this.sampleLease=lease;this.sampleBank=lease.bank;this.samplePreset=lease.preset;
    this.sampleSource=lease.bank==='local'?'local':'original';
    this.sampleFiles=lease.files;this.sampleDesign=lease.design;this.sampleMetadata=lease.metadata;
    this._samplePitchCandidates=null; // useSamples owns bank/metadata revision changes
    this.buffers=new Map([...lease.buffers].map(([file,buffer])=>[`${lease.bank}/${file}`,Promise.resolve(buffer)]));
    // A recording its bank gave back for another bot's (sample-library.js makeRoom): no longer played (the nearest one
    // left plays its notes), its memory freed, and the card told. One taken back when there is room again (regrow):
    // played again, and the card counts it, until the bank is whole and the card is as it was.
    const held=()=>{
      this.sampleFiles=lease.files;this._samplePitchCandidates=null;
      const total=lease.files.length+(lease.left?.length??0);
      this.report('bot_status',lease.complete?{state:'',message:null}:{state:'limited',loaded:lease.files.length,total,
        message:`This device holds ${Math.round(this.device.decodedBytes/1048576)} MiB of recordings at once, so this bot plays ${lease.files.length} of its ${total}`});
    };
    lease.onShed=file=>{if(this.sampleLease!==lease)return;this.buffers.delete(`${lease.bank}/${file}`);held()};
    lease.onRegain=(file,buffer)=>{if(this.sampleLease!==lease)return;this.buffers.set(`${lease.bank}/${file}`,Promise.resolve(buffer));held()};
  }
  stopSampleVoices(){
    for(const graph of this.activeGraphs)if(graph.sampleGain){
      const at=this.ctx.currentTime,gain=graph.sampleGain.gain;
      if(gain.cancelAndHoldAtTime)gain.cancelAndHoldAtTime(at);else {gain.cancelScheduledValues(at);gain.setValueAtTime(gain.value,at)}
      gain.linearRampToValueAtTime(0,at+.01);try{graph.source.stop(at+.011)}catch{}
    }
  }
  unloadSamples(){this.sampleGeneration=(this.sampleGeneration||0)+1;this.stopSampleVoices();this.sampleLease?.release();this.sampleLease=null;this.sampleSource=undefined;this.sampleFiles=[];this.buffers?.clear()}
  async setSynthesizer(id,options={}){
    if(!this.dspNode?.replace)throw new Error('Start browser audio before changing its synthesizer');
    await this.dspNode.replace({id,options,seed:this.seed});this.stopUMP();this.synthesizer=id;this.synthOptions=options;this.followSynth();
    // A split kit's renderers change with it, unless the new synth is one a kit is not split for.
    if(this.kit&&UNSPLIT_BACKENDS.includes(this.dspNode.backend))this.unsplitKit();
    else if(this.kit)for(const [channel,part] of this.kit)await part.renderer?.replace?.({id,options,seed:hashSeed(`${this.seed}/${channel}`)});
    this.report('synth_changed',{id,backend:this.dspNode.backend});
  }
  setMixer(mixer,id,settings={}){
    this.mixerTrack?.disconnect();this.mixerTrack=mixer.track(id,settings);this.mixerTrackId=id;
    const output=this.outputAnalyser||this.spatialGain;output.disconnect();output.connect(this.mixerTrack.input);
    this.mixer=mixer;
    if(this.role)this.mixerTrack.setRole?.(this.role);
    if(this.kit)this.attachKit();
  }
  // ---- A kit's drums, each on a channel of its own ------------------------------------------------------------------
  // The user, 26 September 2026: "make sure that mixbot and the desk are able to distribute instruments - including
  // individual drums played by one drumbot - in a stereo image", and "in advanced mixing, the whole drum kit should not
  // necessarily be treated as a unit." Split, a kit is what a multi-output drum instrument gives a desk
  // (shared/kit-channels.js): each channel -- kick, snare, hats, toms, ride, crash, hand drums, percussion -- has a
  // renderer of its own (another instance of the bot's synth: another DSP bus, another sampled kit), a copy of the bot's
  // output chain (its performance gain, limiter and spatial filter, moved with it), and a mixer channel of its own,
  // routed into the bot's channel, which becomes the kit's bus: the bot's fader, sends and stem are still the whole
  // kit's, and a desk can place, balance and process each drum. Each channel starts where a drummer hears its drum
  // (kit-channels.js KIT_HOMES), and a hit is voiced in the middle of its channel, or for a channel holding several
  // drums at its drum's place within it (kitHitPan: the toms high to low), unless the bot pans it. What is not a drum (a
  // bot's other voices) stays on the bot's own chain.
  // A plugin's kit (a VST3's, a WAM's) is not split: it has one output here (UNSPLIT_BACKENDS).
  async splitKit({channels=KIT_CHANNEL_NAMES}={}){
    if(this.kit||!this.ctx||!this.master)return this.kit;
    await this.dspInitialization;
    if(UNSPLIT_BACKENDS.includes(this.dspNode?.backend))return null;
    const kit=new Map();
    for(const channel of channels){
      const chain=this.kitChain(),renderer=this.dspNode&&this.dspFactory?await this.dspFactory(this.ctx,{seed:hashSeed(`${this.seed}/${channel}`)}):null;
      renderer?.connect(chain.master);
      kit.set(channel,{renderer,chain,track:null});
    }
    // Split meanwhile by another call, or disposed: this one's parts go.
    if(this.kit||!this.master){for(const part of kit.values())this.closeKitPart(part);return this.kit}
    this.kit=kit;
    if(this.mixer&&this.mixerTrack)this.attachKit();
    this.report('kit_split',{channels:[...kit.keys()]});
    return kit;
  }
  // The kit whole again: its channels' renderers, chains and mixer channels gone, and the bot's channel a channel.
  unsplitKit(){
    if(!this.kit)return;
    for(const part of this.kit.values())this.closeKitPart(part);
    if(this.mixerTrack){this.mixerTrack.bus=false;this.mixerTrack.kit=false}
    this.kit=null;
  }
  closeKitPart(part){
    try{part.renderer?.disconnect?.()}catch{/* already gone */}
    for(const node of [part.chain.master,part.chain.headroom,part.chain.limiter,part.chain.spatialFilter,part.chain.spatialGain])try{node?.disconnect()}catch{/* already gone */}
    part.track?.disconnect?.();part.track=null;
  }
  // A distance's low-pass at `cutoff` (Hz), as setSpatialAttenuation asks.
  spatialFilterOf(cutoff,q){
    const filter=this.ctx.createBiquadFilter();filter.type='lowpass';filter.frequency.value=cutoff;filter.Q.value=q;
    this.appliedSpatialCutoff=cutoff;this.appliedSpatialQ=q;return filter;
  }
  // A copy of the bot's output chain, where it stands now.
  kitChain(){
    const master=this.ctx.createGain(),headroom=this.ctx.createGain(),limiter=this.limiter?this.ctx.createDynamicsCompressor():null,
      spatialFilter=this.spatialFilter?this.spatialFilterOf(this.appliedSpatialCutoff,this.appliedSpatialQ):null,spatialGain=this.ctx.createGain();
    master.gain.value=this.appliedPerformanceGain??this.master.gain.value;headroom.gain.value=10**((this.levelTrimDb-BOT_HEADROOM_DB)/20);master.connect(headroom);
    spatialGain.gain.value=this.appliedSpatialGain??this.spatialGain.gain.value;
    if(limiter)setLimiter(limiter);
    (limiter?headroom.connect(limiter):headroom).connect(spatialFilter??spatialGain);spatialFilter?.connect(spatialGain);
    return {master,headroom,limiter,spatialFilter,spatialGain};
  }
  // The bot's channel made the kit's bus, and each drum the kit has played given a mixer channel of its own, at its
  // drum's place in the kit, routed into the kit's bus. A drum not yet played has none: most kits play three or four of
  // their eight drums, and a channel costs a mixer strip's worth of work at every block, played or not. Its renderer
  // and chain wait unconnected (a chain nothing hears is not processed), and its channel is made, at once, with its
  // first hit (kitPart).
  attachKit(){
    const kitTrack=this.mixerTrack;
    kitTrack.bus=true;kitTrack.kit=true;
    for(const [channel,part] of this.kit){part.track?.disconnect?.();part.track=null;if(part.sounded)this.kitTrack(channel,part)}
  }
  kitTrack(channel,part){
    if(part.track||!this.mixer||!this.mixerTrack)return part.track;
    const id=this.mixerTrackId,track=part.track=this.mixer.track(kitTrackId(id,channel),{pan:KIT_HOMES[channel]??0});
    track.setRole?.('drums');track.setPiece?.(channel,id);track.setSource?.(this.kitSource());
    part.chain.spatialGain.disconnect();part.chain.spatialGain.connect(track.input);
    track.routeTo(id,{seconds:0});
    return track;
  }
  // Which kit a split kit's drums sound, where it is not the bot's built-in voice: its sample bank's while it plays its
  // samples ('samples:<bank>'), the sampled drum kit's ('drum-kit:<kit>': synths/drum-kit.js), else null. A desk sets
  // each drum from that kit's balance (shared/kit-loudness.js): the xDrum samples' hats, for one, are 17 dB louder
  // against their kick than the built-in voice's.
  kitSource(){
    if(this.sampleLease&&this.sampleBank)return `samples:${this.sampleBank}`;
    const kit=this.dspNode?.capabilities?.drumKit?.kit;
    return kit?`drum-kit:${kit}`:null;
  }
  // The sampled drum kit this bot plays, where it plays one (synths/drum-kit.js): its id and the General MIDI notes it
  // has recordings for, so the bot chooses among what it can sound. Null for any other voice, which sounds every note.
  sampledKit(){
    const kit=this.dspNode?.capabilities?.drumKit;
    return kit?{kit:kit.kit,notes:Array.isArray(kit.notes)?kit.notes:null}:null;
  }
  // What sounds this bot's drums: a sampled kit ('sampled': sampledKit says which notes it has recordings for), a plugin
  // instrument or MIDI out ('external': its instrument maps the notes), the synthesized kit ('synthesized': its own
  // pieces, and one struck voice for the rest of the hand percussion), or nothing at all (null: a notes-only render).
  percussionVoice(){
    if(this.mode==='midi')return 'external';
    const backend=this.dspNode?.backend;
    if(!backend||backend==='score')return null;
    if(this.dspNode.capabilities?.drumKit)return 'sampled';
    return backend==='wam'||backend==='vst3'?'external':'synthesized';
  }
  // The kit channel a piece is heard on, while the kit is split; asked for a hit, it is given its mixer channel if it
  // has none yet (kitTrack).
  kitPart(piece,{hit=true}={}){
    const channel=kitChannelOf(piece),part=this.kit?.get(channel)??null;
    if(part&&hit&&!part.sounded){part.sounded=true;this.kitTrack(channel,part)}
    return part;
  }
  // What this bot's channel is on a desk -- drums, bass, pad, keys, lead or texture -- from the instruments it
  // has actually played (articulation.js FAMILY_ROLES), so a desk can process it as what it is, unless the bot declares
  // its role (configure). A role changes only when another has clearly overtaken it, so a bass bot's odd fill does not
  // make it a drum channel.
  countFamily(family){
    if(this.declaredRole)return;
    const role=FAMILY_ROLES[family];if(!role)return;
    const counts=this.roleCounts??=new Map();counts.set(role,(counts.get(role)||0)+1);
    const current=counts.get(this.role)||0,count=counts.get(role);
    if(role!==this.role&&count>current*1.25+2){this.role=role;this.mixerTrack?.setRole?.(role)}
  }
  setMix(values,options={}){return this.mixerTrack?.set(values,options)}
  setEffectSend(effect,value,options={}){
    if(!['reverb','delay','compression','plugin'].includes(effect))throw new Error('Unknown effect send');
    return this.setMix({[effect]:value},options);
  }
  async midiOutputs(protocol=this.midiProtocol) {
    if(protocol==='midi2')return nativeMidi2Outputs({clientOnly:this.clientOnly});
    if (this.clientOnly) {
      if (!navigator.requestMIDIAccess)
        throw new Error("This browser does not support Web MIDI");
      this.midiAccess ||= await navigator.requestMIDIAccess({ sysex: false });
      return [...this.midiAccess.outputs.values()].map((output) => ({
        id: output.id,
        name: output.name || output.id,
        manufacturer: output.manufacturer || "Web MIDI",
        state: output.state,
        connection: output.connection,
      }));
    }
    const response = await fetch("/api/midi/outputs"),
      { outputs } = await response.json();
    return outputs.map((name) => ({
      id: name,
      name,
      manufacturer: "Musebots server / native MIDI",
      state: "connected",
      connection: "open",
    }));
  }
  async closeMidiOutput() {
    const output=this.midiOutput;
    this.stopUMP();this.clock?.reset();this.eventTime=0;
    for(const timer of this.midiTimers)timer.cancel();this.midiTimers.clear();
    clearInterval(this.midiDeliveryTimer);this.midiDeliveryTimer=null;
    if(this.midiStateListener)this.midiAccess?.removeEventListener?.('statechange',this.midiStateListener);this.midiStateListener=null;
    try {
      if(output?.protocol==='midi2')await output.close();
      else if(output){this.panicMidi();this.midiSocket?.close();this.midiSocket=null;}
    } finally {
      this.midiOutput=null;this.midiDelivery=null;this.umpIdentities.clear();this.sounding.clear();this.programsSent.clear();midiRoutes.release(this.midiRouteId);this.bridgeClaim=null;
    }
  }
  async configureMidi(outputId = "", {protocol=this.midiProtocol,group=this.midiGroup}={}) {
    if(!['midi1','midi2'].includes(protocol))throw new Error('Choose MIDI 1/MPE or native MIDI 2');
    if(!Number.isInteger(group)||group<0||group>15)throw new Error('MIDI 2 group must be 1–16');
    await this.closeMidiOutput();
    this.midiProtocol=protocol;this.midiGroup=group;
    midiRoutes.release(this.midiRouteId);
    const outputs = await this.midiOutputs();
    this.midiOutput =
      outputs.find((output) => output.id === outputId) || (!outputId?outputs[0]:null);
    if (!this.midiOutput) throw new Error(protocol==='midi2'?'No selected native MIDI 2 destination is available':'No selected MIDI output is available');
    if(protocol==='midi2'){
      const output=new NativeMidi2Output(this.midiOutput,{
        onError:error=>{this.muted=true;this.onMidiError?.(error);this.report('midi2_error',{error:error.message});},
        onPacket:event=>this.onUMPOutput?.(event),
      });
      this.midiOutput=null;
      this.midiOutput=await output.open();
      return;
    }
    // What reaches the port, and whether it is there (shared/midi-delivery.js).
    const delivery=this.midiDelivery=new MidiDelivery({port:this.midiOutput.name,onEvent:event=>this.midiDeliveryEvent(event)});
    if (this.clientOnly) {
      // Web MIDI takes the bytes at once, and says by the port's state that it has gone (its send then throws) and
      // come back, as the same port.
      const id=this.midiOutput.id,native = this.midiAccess.outputs.get(id);
      this.midiOutput.send = (bytes, time = performance.now()) => {
        if(!delivery.connected){delivery.hold();return;}
        try{native.send(bytes, time);delivery.delivered();}
        catch(error){delivery.fail(error);}
      };
      this.midiStateListener=event=>{if(event.port?.id===id&&event.port.type!=='input')delivery.setConnected(event.port.state==='connected',event.port.state);};
      this.midiAccess.addEventListener?.('statechange',this.midiStateListener);
      if(native?.state==='disconnected')delivery.setConnected(false,'disconnected');
      return;
    }
    if (!this.midiSocket || this.midiSocket.readyState > 1) {
      this.midiSocket = new WebSocket(roomSocketUrl());
      // The bridge's answers (midi-bridge.cjs), for whichever output this engine has open now.
      const socket=this.midiSocket;
      socket.addEventListener("message",({data})=>{let message;try{message=JSON.parse(data)}catch{return}this.bridgeMessage(message);});
      socket.addEventListener("open",()=>{if(this.bridgeClaim&&this.midiSocket===socket)socket.send(JSON.stringify(this.bridgeClaim))});
      socket.addEventListener("close",()=>{if(this.midiSocket===socket)this.midiDelivery?.setConnected(false,"the server's MIDI bridge closed");});
      await new Promise((resolve, reject) => {
        this.midiSocket.addEventListener("open", resolve, { once: true });
        this.midiSocket.addEventListener(
          "error",
          () =>
            reject(new Error("Could not connect to the server MIDI bridge")),
          { once: true },
        );
      });
    }
    const port=this.midiOutput.name,socket=this.midiSocket;
    this.midiOutput.send = (bytes, time = performance.now()) => {
      const delay = Math.max(0, time - performance.now()),
        send = () => {
          if (socket.readyState !== WebSocket.OPEN || !delivery.connected) {delivery.hold();return;}
          socket.send(JSON.stringify({type: "midi", port, bytes, id: delivery.number(bytes)}));
        };
      if(delay){const timer=this.midiLater(()=>{this.midiTimers.delete(timer);send();},delay);this.midiTimers.add(timer)}else send();
    };
    this.midiDeliveryTimer=setInterval(()=>delivery.check(),1000);this.midiDeliveryTimer?.unref?.();
  }
  // A change in what reaches the port. A port back after going away is set up again (its programs asked for anew, an
  // MPE zone declared again): a device unplugged or switched off has forgotten both.
  midiDeliveryEvent(event){
    if(event.kind==='reconnected'&&this.midiOutput){
      this.programsSent.clear();
      if(this.midiProtocol!=='midi2')this.configureMpe({enabled:this.mpeEnabled,zone:this.mpeZone,bendRange:this.mpeBendRange});
    }
    this.report(`midi_${event.kind}`,{port:event.port,...(event.error?{error:event.error}:{}),...(event.reason?{reason:event.reason}:{}),status:event.status});
    this.onMidiDelivery?.(event);
  }
  // What has reached the open MIDI 1 output: {port, connected, sent, acknowledged, failed, held, pending, roundTripMs,
  // lastError}, or null.
  midiDeliveryStatus(){return this.midiDelivery?.status()??null}
  configureMpe({ enabled = true, zone = "lower", bendRange = 48 } = {}) {
    this.mpeEnabled = enabled !== false;
    this.mpeZone = zone;
    this.mpeBendRange = Math.max(0.01, Math.min(96, Number(bendRange) || 48));
    if(this.midiProtocol==='midi2')return;
    const channels =
      zone === "upper"
        ? Array.from({ length: 15 }, (_, index) => 14 - index)
        : zone === "single"
          ? [this.midiChannelOverride ?? this.defaultMidiChannel ?? 0]
          : Array.from({ length: 15 }, (_, index) => index + 1);
    this.mpeAllocator.setChannels(channels);
    if (this.midiOutput) {
      // A zone owns its manager channel too (channel 1 lower, 16 upper), which carries the zone-wide messages.
      const claimed = this.mpeEnabled && zone !== "single" ? [...channels, zone === "upper" ? 15 : 0] : channels;
      const collisions = midiRoutes.claim(
        this.midiRouteId,
        this.midiOutput.id || this.midiOutput.name,
        claimed,
      );
      if (collisions.length)
        this.report("midi_route_collision", {
          port: this.midiOutput.name,
          zone,
          channels,
          collisions,
        });
      this.claimBridge(claimed, zone);
    }
    if (this.midiOutput) {
      if (this.mpeEnabled) {
        for (const bytes of mpeZoneMessages(zone, channels.length))
          this.sendMidi(bytes);
        // MPE 1.0 assigns zone-wide bend to the manager (±2 by default) and
        // per-note bends to members (±48 by default). Configure both
        // explicitly rather than relying on receiver-side defaults.
        const manager = zone === "upper" ? 15 : 0;
        for (const bytes of bendRangeMessages(manager, 2))
          this.sendMidi(bytes);
      }
      for (const channel of channels)
        for (const bytes of bendRangeMessages(channel, this.mpeBendRange))
          this.sendMidi(bytes);
    }
  }
  sendMidi(bytes, time = globalThis.performance?.now?.() ?? 0, details = {}) {
    if (!this.midiOutput) return;
    if(this.midiProtocol==='midi2')throw new Error('Use UMP packets for native MIDI 2 output');
    this.onMidiRaw?.({
      bytes: [...bytes],
      scheduledAt: Number(time),
      port: this.midiOutput.name || this.midiOutput.id || null,
      bendRange: this.mpeBendRange,
      ...details,
    });
    this.midiOutput.send(bytes, time);
  }
  sendUMP(packet,time=globalThis.performance.now()) {
    if(this.midiProtocol!=='midi2'||!this.midiOutput?.sendPackets)throw new Error('Open a native MIDI 2 route before sending UMP');
    this.midiOutput.sendPackets([{packet,time}]);
  }
  panicMidi() {
    if (!this.midiOutput) return;
    for(const timer of this.midiTimers)timer.cancel();this.midiTimers.clear();
    if(this.midiProtocol==='midi2'){
      this.umpIdentities.clear();this.sounding.clear();
      this.midiOutput.cancel?.().catch(error=>this.onMidiError?.(error));
      return;
    }
    for (let channel = 0; channel < 16; channel++) {
      // Pedal release precedes note termination so a receiving piano cannot
      // retain notes after a bot stops, switches behavior, or is deleted.
      this.sendMidi([0xb0 + channel, 64, 0]);
      this.sendMidi([0xb0 + channel, 120, 0]);
      this.sendMidi([0xb0 + channel, 123, 0]);
      this.sendMidi([0xe0 + channel, 0, 64]);
    }
    this.mpeAllocator.setChannels(this.mpeAllocator.channels);
  }
  midiDamper(duration = 0.5, channel = null, offset = 0) {
    if (this.muted || !this.midiOutput) return;
    if(this.midiProtocol==='midi2'){
      const selected=this.midiChannelOverride??this.defaultMidiChannel??channel??0,
        at=globalThis.performance.now()+Math.max(0,(this.eventStart(offset)-this.clockTime())*1000),
        seconds=Math.max(.03,Math.min(8,Number(duration)||.5));
      this.midiOutput.sendPackets([
        {packet:Array.from(channelControl({group:this.midiGroup,channel:selected,index:64,value:0xffffffff})),time:at},
        {packet:Array.from(channelControl({group:this.midiGroup,channel:selected,index:64})),time:at+seconds*1000},
      ]);
      return;
    }
    const seconds = Math.max(0.03, Math.min(8, Number(duration) || 0.5)),
      at =
        globalThis.performance.now() +
        Math.max(0, (this.eventStart(offset) - this.ctx.currentTime) * 1000),
      channels =
        channel != null
          ? [Math.max(0, Math.min(15, Number(channel) || 0))]
          : this.mpeEnabled && this.mpeZone !== "single"
            ? [this.mpeZone === "upper" ? 15 : 0]
            : [this.midiChannelOverride ?? this.defaultMidiChannel ?? 0];
    for (const target of channels) {
      this.sendMidi([0xb0 + target, 64, 127], at, {
        expression: { damper: "down", duration: seconds },
      });
      this.sendMidi([0xb0 + target, 64, 0], at + seconds * 1000, {
        expression: { damper: "up", duration: seconds },
      });
    }
  }
  // A MIDI message sent ahead, on a clock a hidden page does not slow down (shared/worker-timer.js): a handle with
  // cancel().
  midiLater(fn, delay) { return later(fn, delay); }
  releaseMidiRoute() {
    midiRoutes.release(this.midiRouteId);
    this.releaseBridge();
  }
  // The channels this bot takes on one of the server's ports, told to its bridge, so that a bot on another page (or
  // machine) given the same zone or channel is reported too, before either plays (midi-claims.cjs). A page's own bots
  // are the registry's (MidiRouteRegistry); Web MIDI in a page of its own has no bridge to tell.
  claimBridge(channels, zone) {
    if (this.clientOnly || !this.midiOutput) return;
    this.bridgeClaim = { type: "midi_claim", route: this.midiRouteId, port: this.midiOutput.name, channels, zone, agent: this.definition?.name ?? null };
    if (this.midiSocket?.readyState === 1) this.midiSocket.send(JSON.stringify(this.bridgeClaim));
  }
  // What the bridge says: a delivery's answer (midi-delivery.js), or another page's bot sharing these channels on this
  // port (midi-claims.cjs), said as the page's own collisions are.
  bridgeMessage(message) {
    if (message?.type === "midi_collision" && message.route === this.midiRouteId) {
      this.report("midi_route_collision", { port: message.port, zone: this.mpeZone, channels: this.bridgeClaim?.channels ?? [], collisions: message.collisions, shared: true });
      return;
    }
    this.midiDelivery?.receive(message);
  }
  releaseBridge() {
    if (this.bridgeClaim && this.midiSocket?.readyState === 1) this.midiSocket.send(JSON.stringify({ type: "midi_release", route: this.midiRouteId }));
    this.bridgeClaim = null;
  }
  setMidiChannel(value) {
    this.midiChannelOverride =
      value === "default" || value === ""
        ? null
        : Math.max(0, Math.min(15, Number(value) - 1));
  }
  // Which program the output is asked for (general-midi.js): 'none' leaves the receiving instrument's own, 'gm' follows
  // the instrument each note is played on, a number (0-127) is that program. Sent with the next note.
  setMidiProgram(value) {
    this.midiProgram = midiProgramSetting(value);
    this.programsSent.clear();
  }
  // A Program Change on `channel` at `at` (performance.now's milliseconds), before a note that asks for `program`, when
  // the channel was last asked for another. A drum part's channel takes none.
  sendProgram(program, channel, at) {
    if (program === null || this.programsSent.get(channel) === program) return;
    this.programsSent.set(channel, program);
    if (this.midiProtocol === 'midi2')
      this.midiOutput.sendPackets([{packet:Array.from(programChange({group:this.midiGroup,channel,program})),time:at}]);
    else this.sendMidi([0xc0 + (channel & 15), program], at, { program: GM_PROGRAMS[program] });
  }
  testMidi() {
    if (!this.midiOutput)
      throw new Error("Select and open a MIDI output first");
    const channel = this.midiChannelOverride ?? this.defaultMidiChannel ?? 0,
      at = performance.now() + 20;
    if(this.midiProtocol==='midi2'){
      const address={group:this.midiGroup,channel,note:60};
      this.midiOutput.sendPackets([
        {packet:Array.from(noteOn({...address,velocity:Math.round(100/127*65535)})),time:at},
        {packet:Array.from(noteOff(address)),time:at+1500},
      ]);
      return {port:this.midiOutput.name,note:60,channel:channel+1,group:this.midiGroup+1,protocol:'midi2',velocity:100};
    }
    this.sendMidi([0x90 + channel, 60, 100], at, { test: true });
    this.sendMidi([0x80 + channel, 60, 0], at + 1500, { test: true });
    return {
      port: this.midiOutput.name,
      note: 60,
      channel: channel + 1,
      velocity: 100,
    };
  }
  setPerformanceClock(clock = {}) {
    this.currentClock=clock;
    this.velocityGain=this.performanceVelocity(1);
  }
  setMixPlacement(value=0){this.mixPlacement=Math.max(-1,Math.min(1,Number(value)||0))}
  performanceVelocity(value){
    return placedVelocity(metricalVelocity(value,this.currentClock),this.mixPlacement||0);
  }
  beginTick(tick, bpm, subdivision = 4, clock = {}) {
    this.setPerformanceClock({...clock,tick,bpm});
    this.eventTime = this.clock.timeFor(
      tick,
      bpm,
      this.clockTime(),
      subdivision,
    );
    return Math.max(0, this.eventTime - this.clockTime());
  }
  toggle() {
    this.muted = !this.muted;
    if(this.muted&&this.mode==='midi'){this.stopUMP();this.panicMidi();}
    return this.muted;
  }
  setPerformanceGain(value, duration = 0) {
    const target = Math.max(0, Math.min(4, Number(value)));
    this.pendingPerformanceGain = target;
    if (!this.master) return;
    if (Math.abs((this.appliedPerformanceGain ?? this.master.gain.value) - target) < 1e-6)
      return;
    this.appliedPerformanceGain = target;
    // From the sounding time of the pulse being played (eventTime, a lookahead ahead of the context's clock), where a
    // lifecycle applied at a bar begins: a stop at a section's downbeat fades from that downbeat, not from when it was
    // scheduled (measured: a quarter second before it, the render's lookahead). Outside a pulse, from now.
    const now = Math.max(this.ctx.currentTime, Number.isFinite(this.eventTime) ? this.eventTime : 0),
      seconds = Math.max(0, Number(duration) || 0);
    // Holding the value already being produced is important here. Reading
    // AudioParam.value during an active ramp can return the automation's base
    // value and introduce a discontinuity at a form/lifecycle boundary.
    // A split kit's channels move with the bot's own output: each is a copy of its chain.
    for (const chain of this.chains()) heldRamp(chain.master.gain, target, now, seconds);
  }
  // The bot's output chain, and each of its kit's channels' copies of it (splitKit).
  chains() {
    const main = {master: this.master, limiter: this.limiter, spatialFilter: this.spatialFilter, spatialGain: this.spatialGain};
    return this.kit ? [main, ...[...this.kit.values()].map(part => part.chain)] : [main];
  }
  setSpatialGain(value, duration = 0.12) {
    const target = Math.max(0, Math.min(1, Number(value)));
    this.pendingSpatialGain = target;
    if (!this.spatialGain || !this.ctx) return;
    if (Math.abs((this.appliedSpatialGain ?? this.spatialGain.gain.value) - target) < 1e-6)
      return;
    this.appliedSpatialGain = target;
    const now = this.ctx.currentTime,
      seconds = Math.max(0, Number(duration) || 0);
    // Spatial controls are a live stream while the listener moves. Retarget a
    // one-pole smoothing curve instead of repeatedly cancelling overlapping
    // ramps; Chromium can silence a graph after sustained cancel/hold churn.
    for (const {spatialGain: {gain}} of this.chains()) {
      if (seconds) gain.setTargetAtTime(target, now, Math.max(0.005, seconds / 3));
      else gain.setValueAtTime(target, now);
    }
  }
  setSpatialAttenuation({ gain = 1, cutoffHz = 18000, q = 0.55 } = {}, gainDuration = 0.14, filterDuration = 0.42) {
    this.setSpatialGain(gain, gainDuration);
    const cutoff = Math.max(40, Math.min(this.ctx?.sampleRate ? this.ctx.sampleRate * 0.45 : 20000, Number(cutoffHz) || 18000));
    this.pendingSpatialCutoff = cutoff;
    this.pendingSpatialQ = Math.max(0.01, Number(q) || 0.55);
    if (!this.spatialGain || !this.ctx) return;
    // (Its low-pass put in each chain the first time a distance asks for one: before its spatial gain.)
    if (!this.spatialFilter) {
      for (const chain of this.chains()) {
        const filter = this.spatialFilterOf(cutoff, this.pendingSpatialQ), from = chain.limiter ?? chain.headroom ?? this.headroom;
        try { from.disconnect(chain.spatialGain); } catch { /* not connected */ }
        from.connect(filter).connect(chain.spatialGain);
        if (chain.master === this.master) this.spatialFilter = filter; else chain.spatialFilter = filter;
      }
      return;
    }
    const targetQ = Math.max(0.01, Number(q) || 0.55),
      cutoffUnchanged = Math.abs(Math.log((this.appliedSpatialCutoff ?? this.spatialFilter.frequency.value) / cutoff)) < 1e-6,
      qUnchanged = Math.abs((this.appliedSpatialQ ?? this.spatialFilter.Q.value) - targetQ) < 1e-6;
    if (cutoffUnchanged && qUnchanged) return;
    this.appliedSpatialCutoff = cutoff;
    this.appliedSpatialQ = targetQ;
    const now = this.ctx.currentTime, seconds = Math.max(0, Number(filterDuration) || 0);
    for (const {spatialFilter} of this.chains()) {
      const frequency = spatialFilter.frequency;
      if (!cutoffUnchanged && seconds)
        frequency.setTargetAtTime(cutoff, now, Math.max(0.005, seconds / 3));
      else if (!cutoffUnchanged)
        frequency.setValueAtTime(cutoff, now);
      if (!qUnchanged) spatialFilter.Q.setTargetAtTime(targetQ, now, 0.02);
    }
  }
  lifecycle(action, payload = {}) {
    this.onLifecycle?.(action, payload);
  }
  // The calls `fn` makes reported `lag` seconds after their written time: a part's rubato, an ornament's warp -- how it
  // is played, which its score leaves out (transcript/capture.js), so that a tuplet is written only for a rhythm.
  lagged(lag, fn) {
    const before = this.reportLag;
    this.reportLag = (Number(before) || 0) + (Number(lag) || 0);
    try { return fn(); } finally { this.reportLag = before; }
  }
  // The musical producer supplies a symbolic interval before a synchronous instrument call. Playback can move or
  // shorten it freely; note plans and delayed sample callbacks retain this immutable score interval.
  scored(scoreTime, fn) {
    return withScoreTime(this,scoreTime,fn);
  }
  reviseScore(event) {
    this.report('score_revision',event);
  }
  report(kind, details = {}) {
    if (Number(this.reportLag) && Number.isFinite(Number(details.offset)))
      details = {...details, lag: (Number(details.lag) || 0) + this.reportLag};
    if(this.visualizersEnabled&&Number.isFinite(Number(details.note??details.pitch))){
      this.visualizerActivity||=[];this.visualizerActivity.push({kind,note:details.note??details.pitch,velocity:details.velocity??.5});
      if(this.visualizerActivity.length>80)this.visualizerActivity.shift();
    }
    if (
      Number.isFinite(Number(details.velocity)) &&
      kind !== "expressive_note"
    )
      details={...details,velocity:this.performanceVelocity(details.velocity)};
    this.onAudioEvent?.({
      kind,
      ...details,
      contextState: this.ctx?.state,
      mode: this.mode,
    });
  }
  setTuningPlan(payload = null) {
    this.tuningPayload = payload ? validateTuningPayload(payload) : null;
    this.tuningChordIndex = 0;
    this.report("tuning_plan", {
      active: Boolean(this.tuningPayload),
      planId: this.tuningPayload?.planId || null,
    });
  }
  setTuningPosition(clock = {}) {
    if (!this.tuningPayload?.durations?.length) return;
    const meter = clock.meter || {},
      beatsPerBar = ((meter.numerator || 4) * 4) / (meter.denominator || 4),
      start = this.tuningPayload.appliesAt?.bar || 0,
      position = Math.max(
        0,
        ((clock.bar || 0) - start) * beatsPerBar +
          ((clock.beat || 0) * 4) / (meter.denominator || 4),
      ),
      total = this.tuningPayload.durations.reduce(
        (sum, value) => sum + value,
        0,
      ),
      phase = total ? position % total : 0;
    let cumulative = 0;
    this.tuningChordIndex = this.tuningPayload.durations.findIndex(
      (duration) => (cumulative += duration) > phase,
    );
    if (this.tuningChordIndex < 0) this.tuningChordIndex = 0;
  }
  tunePitch(note) {
    return this.tuningPayload
      ? applyTuningSystem(note, this.tuningPayload, this.tuningChordIndex)
      : note;
  }
  clockTime() {
    // External UMP needs a clock even when there is no running audio graph.
    return this.mode==='midi'&&this.midiProtocol==='midi2'?globalThis.performance.now()/1000:this.ctx.currentTime;
  }
  eventStart(offset = 0) {
    const now=this.clockTime();
    return Math.max(
      now + 0.005,
      (this.eventTime || now) + offset,
    );
  }
  captureUMP(note,duration,velocity,offset=0,performance={},address={},plan=null) {
    // **A note the format cannot carry must not take the tick down with it.**
    //
    // Measured in a real browser: five uncaught `RangeError: Pitch 132.8435871299945` in 75
    // seconds, thrown from `pitch79` through `notesToUMP` and out of `captureUMP` — which is
    // called from inside a bot's tick, so the exception discarded not just that note but
    // everything the bot had left to do on that tick. Five dropped ticks in a minute is
    // audible, and it was reported as stutters.
    //
    // MIDI 2's Pitch 7.9 spans 0..127.998 semitones and a bot asking for 132.84 has a bug of
    // its own — almost certainly an octave expansion with no ceiling. The engine's job is not
    // to guess what was meant: it declines the note, says so where the bot's own diagnostics
    // are read, and lets the rest of the tick happen. Clamping would sound a squeak nobody
    // asked for; folding by octaves would silently rewrite the music.
    if(!Number.isFinite(note)||note<0||note>PITCH_CEILING){
      this.report('pitch_unplayable',{note,duration,
        limit:PITCH_CEILING,
        says:`${Number.isFinite(note)?note.toFixed(3):String(note)} semitones is outside `
          +`MIDI 2's 0..${PITCH_CEILING.toFixed(3)}; the note was declined and the rest of `
          +`the tick continued`});
      return null;
    }
    const start=this.eventStart(offset);
    // (Where it was written, as its producer wrote it -- its plan's score time, else the one it is played under: what a
    // motif captured from it keeps of its rhythm, ump-events.js UmpMotifCapture.)
    const written=plan?.scoreTime??this.scoreTime,symbolic=written?{scoreTime:written}:{};
    const group=address.group??0,channel=address.channel??0,prefix=`${group}:${channel}:`;
    // The note's articulation -- attack, decay and release time, timbre, pan -- as the
    // Registered Per-Note Controllers that describe them (articulation.js), 32-bit and centred.
    const articulation=(plan?.articulation||[]).map(({controller,bipolar})=>({controller,value:bipolar32(bipolar)}));
    if(address.fixedPercussion){
      const identity={group,channel,note:Math.max(0,Math.min(127,Math.round(note)))};
      // A stroke's brightness (#74, shared/percussion-expression.js) beside its articulation, and a retuned drum's
      // pitch as the note's Pitch 7.9 attribute: the note says which drum, the attribute how it is tuned.
      const brightness=Number.isFinite(address.brightness)?[{controller:74,value:unit32(address.brightness)}]:[],
        tuned=Number.isFinite(address.pitch)&&address.pitch>=0&&address.pitch<=PITCH_CEILING?{attribute:3,pitch:address.pitch}:{attribute:0};
      // Management first, so a drum struck again while its last hit rings is a note of its own
      // and the articulation below is this hit's, not the last one's.
      const batch={startSeconds:start,durationSeconds:duration,...symbolic,events:[
        {time:0,packet:Array.from(perNoteManagement(identity))},
        ...[...articulation,...brightness].map(({controller,value})=>({time:0,packet:Array.from(perNoteController({...identity,index:controller,value}))})),
        {time:0,packet:Array.from(noteOn({...identity,...tuned,velocity:Math.round(velocity*65535)}))},
        {time:duration,packet:Array.from(noteOff({...identity,velocity:Math.round((performance.releaseVelocity??.5)*65535)}))},
      ]};
      this.onUMP?.(batch);return batch;
    }
    for(const [index,end] of this.umpIdentities)if(end<=start)this.umpIdentities.delete(index);
    let index=Math.max(0,Math.min(127,Math.round(note)));
    if(this.umpIdentities.has(prefix+index))index=Array.from({length:128},(_,i)=>i).find(i=>!this.umpIdentities.has(prefix+i));
    // **A full identity table must not silence a bot.** This used to throw, from inside the bot's tick, on every note
    // from then on: in a Max for Live device whose clock stood still nothing was ever released, and every bot fell
    // silent for good after exactly 128 notes. 128 notes truly sounding at once on one channel does not happen; a
    // full table means time has gone wrong somewhere. The identity that was due to end first is reused -- its note
    // is the likeliest to be over -- the music goes on, and the diagnostics say so.
    if(index===undefined){
      let soonest=Infinity;
      for(const [key,end] of this.umpIdentities)if(key.startsWith(prefix)&&end<soonest){soonest=end;index=Number(key.slice(prefix.length))}
      this.umpIdentities.delete(prefix+index);
      this.report('ump_identity_reused',{note,identity:index,channel,
        says:'all 128 MIDI 2 note identities of this channel were in use, which means notes are not being released: check the clock this engine is given'});
    }
    this.umpIdentities.set(prefix+index,start+duration);
    let cell;
    if(plan?.timeline){
      // The whole performance as timed points (expression.js performanceTimeline): pitch with its
      // drift, scoop or glide and a vibrato that waits; pressure and brightness along smooth curves.
      cell={at:0,duration,pitches:[note],velocity,points:plan.timeline,articulation,
        releaseVelocity:performance.releaseVelocity};
    }else{
      let pitchCurve=performance.pitchCurve;
      if(performance.vibratoDepth){
        const source=pitchCurve||[0,0],count=Math.max(2,Math.ceil(duration*40)+1);
        pitchCurve=Array.from({length:count},(_,i)=>{
          const phase=i/(count-1),position=phase*(source.length-1),left=Math.floor(position),right=Math.min(source.length-1,left+1);
          return source[left]+(source[right]-source[left])*(position-left)+performance.vibratoDepth*Math.sin(2*Math.PI*performance.vibratoRate*duration*phase);
        });
      }
      cell={at:0,duration,pitches:[note],velocity,pitchCurve,pressureCurve:performance.pressureCurve,
        slideCurve:performance.slideCurve,releaseVelocity:performance.releaseVelocity};
    }
    const events=notesToUMP([cell],{group,channel}).map(event=>{
        const packet=Array.from(event.packet),message=inspectUMP(packet);
        if(message.kind.startsWith('perNote')||message.kind==='noteOn'||message.kind==='noteOff')packet[0]=((packet[0]&0xffff00ff)|(index<<8))>>>0;
        return {time:event.time/9600,packet};
      });
    const batch={events,startSeconds:start,durationSeconds:duration,...symbolic};
    this.onUMP?.(batch);
    return batch;
  }
  // A captured note its player let go before its end, at `at` (the engine's clock): its Note Off then, in its part's UMP
  // as in its sound -- the earliest Note Off sent for a note its end, its batch's own at its length coming after (its
  // identity held till then: captureUMP). Without it the part's MIDI 2.0 held each such note as long as it was begun, over
  // the notes after it (the owner, 25 October 2026: a monophonic clarinet "rendering with overlapping MIDI 2.0 notes").
  captureRelease(address,at){
    if(address)this.onUMP?.({startSeconds:at,durationSeconds:0,release:true,events:[{time:0,packet:Array.from(noteOff(address))}]});
  }
  playUMP(motif,options={}) {return playUmpSequence(this,motif,options)}
  stopUMP(){for(const handle of this.umpPlaybacks||[])handle.stop();this.umpPlaybacks?.clear()}
  dispose(){
    this.audioGeneration++;
    this.closeMidiOutput().catch(error=>this.onMidiError?.(error));
    this.stopUMP();this.sounding.clear();this.muted=true;this.dspNode?.disconnect?.();this.dspNode=null;this.dspInitialization=null;
    if(this.kit){for(const part of this.kit.values())this.closeKitPart(part);this.kit=null}
    for(const graph of this.activeGraphs){try{graph.source.stop()}catch{}for(const node of graph.nodes)try{node.disconnect()}catch{}}
    this.activeGraphs.clear();
    this.unloadSamples();this.mixerTrack?.disconnect();this.mixerTrack=null;
    for(const key of ['master','limiter','spatialFilter','spatialGain','outputAnalyser']){this[key]?.disconnect?.();this[key]=null}
  }
  scheduleDsp(model, note, duration, gain, offset = 0, paramA = 0, paramB = 0, extra = {}) {
    if (!this.dspNode || this.muted || !this.master) return false;
    // `renderer`: a split kit's channel's renderer (splitKit), else the bot's own. `line`: the line the note belongs to
    // (its plan's, else given), which a restrike keeps to (retrigger).
    const {plan=null,renderer=null,line:given=null,...rest}=extra,node=renderer??this.dspNode;
    const start = extra.atSeconds??this.eventStart(offset),performance=plan?.performance||extra.performance||{},
      batch=extra.skipCapture?null:this.captureUMP(note,duration,performance.velocity??Math.min(1,gain*8),offset,performance,{},plan),
      pitch=batch?inspectUMP(batch.events.find(event=>inspectUMP(event.packet).kind==='noteOn').packet).pitch:note;
    // `captureUMP` returns null for a pitch it declined. Scheduling it anyway would render a
    // note at seventeen kilohertz that nothing asked for, and returning the identity of a note
    // that does not exist would leave the register holding a ghost.
    if(!extra.skipCapture&&batch===null)return false;
    // The voice is given the note's MIDI 2 per-note controls, each point reached in a straight
    // line from the one before, so a curve is heard as the curve it was recorded as.
    const controls=rampedControls(extra.controls||batch?.events.flatMap(engineControl)||[]);
    const events=[{
      // A shaped note may be louder than unity (see enqueue_shaped): its level carries velocity.
      model,frequency:midiHz(pitch),velocity:Math.max(0,Math.min(plan?4:1,gain*8)),duration,
      atSeconds:start,offsetSeconds:Math.max(0,start-this.ctx.currentTime),paramA,paramB,
      identity:extra.identity??this.nextDspIdentity++,...rest,controls,
      // The whole shape of the note (articulation.js): envelopes, filter, transient, pan; and the
      // same articulation as controllers, for a renderer that speaks MIDI (a WAM instrument).
      ...(plan?{shape:plan.shape.array,articulation:plan.articulation,musicalVelocity:plan.performance.velocity}:{}),
      // (Whether it is slurred to the note before, and legato-tongued there (portato), and whether its player says where its
      // slurs are: a physical model's breath joins a slurred note to the one before, its tongue dipping it where its player
      // tongues it, render/synthesis/src/breath.mjs.)
      ...(plan?.slurred===true?{slurred:true}:{}),...(plan?.portato===true?{portato:true}:{}),...(plan?.phrased===true?{phrased:true}:{}),
      // (Where it is written, its plan's else the scope it is played under: the notes log keeps it beside where it sounds,
      // render-session.js logNote.)
      ...scoreTimeFields(plan?.scoreTime?plan:this),
      performance:{...performance,vibratoDepth:0},
    }];
    if(extra.strictAdmission)return node.admit(events);
    // (Its UMP note kept for an early release: releaseNote.)
    if(batch)(this.umpNotes??=new Map).set(events[0].identity,umpAddressOf(batch));
    // (A winds synth -- capabilities.windMidi2: the woodwinds' engine live, synths/winds-bridge.js -- takes the note as
    // MIDI 2.0: its UMP as captured, with what its breath needs besides (wind-midi2.js windEvents). Any other synth, the
    // engine's event.)
    if(node.capabilities?.windMidi2&&batch)node.ump?.(windEvents(batch.events,events[0],start));
    else node.schedule(events);
    this.remember(events[0],pitch,node,plan?.line??given);
    // The identity, not a bare `true`. Callers test this for truthiness — "did the renderer
    // take it" — and an identity is always >= 1, so they read the same. What changes is that
    // the caller can now name the note afterwards, which is what releasing one needs.
    return events[0].identity;
  }
  // One note's plan: its performance, its instrument's shape, and the points and controllers
  // that carry both into MIDI. Everything that renders the note -- the Rust voice, the Web Audio
  // voice, MIDI 2, MPE, MIDI 1 -- reads the same plan, so they cannot disagree about the note.
  //
  //   expression.instrument  an articulation.js family; without one the bot's profile picks it
  //   expression.velocity    the performed velocity, 0..1
  //   expression.pan, accent, variant, filter, cutoffHz, legato, timbre: see articulation.js
  planNote(pitch, duration, expression = {}) {
    const glideKind=expression.glideKind??'into';
    if(!['into','through'].includes(glideKind))throw new TypeError('A glide is into a note or through it');
    const profile = expression.profile || (expression.instrument ? null : this.expressionProfile) || null,
      family = familyFor(expression.instrument, profile || 'neutral'), definition = FAMILIES[family],
      start = this.eventStart(expression.offset || 0);
    this.countFamily(family);
    // A line that is still sounding, or only just finished, glides into its next note: in a family that glides of itself,
    // or where the note asks for it (expression.glide, its seconds; false, never), and never between the notes of a
    // chord (expression.chord). Each line is remembered apart (expression.line: an octave doubling glides from its own).
    // expression.glideFrom names the pitch it slides from outright (a bass's slide up into a root).
    const asked = Number(expression.glide) > 0 ? Number(expression.glide) : null,
      glides = expression.glide !== false && (asked !== null || Boolean(definition.glide)), line = expression.line ?? 'main';
    let glideFrom = null;
    const last = (this.lastLines ??= new Map()).get(line);
    // An asked glide crosses a gap no longer than itself or a quarter of the last note, as a synth's portamento glides
    // from its last note held or not.
    if (glides && expression.legato !== false && last && start - last.startedAt > .04
      && start <= last.endsAt + Math.max(.02, asked ?? 0, asked !== null ? LINE_GLIDE.askedGapShare * (last.endsAt - last.startedAt) : 0)) {
      const leap = Math.abs(last.pitch - pitch);
      if (leap >= .05 && leap <= (asked !== null ? LINE_GLIDE.askedLeap : LINE_GLIDE.familyLeap)) glideFrom = last.pitch;
    }
    // Remembered where a glide could come of it: a family that glides, or a note that says whether it glides.
    if (asked !== null && Number.isFinite(Number(expression.glideFrom)) && Math.abs(Number(expression.glideFrom) - pitch) >= .05) glideFrom = Number(expression.glideFrom);
    // No faster than its player slides (expression.glideSpeed, semitones a second: a seat's instrument's): only its last
    // part slid, the rest a step -- a slur's quick change of pitch across a leap had been heard as a glissando, Op. 3.28's
    // flute's run (the owner, 4 October 2026: "clamp the max speed at which glissando can occur for each instrument").
    if (glideFrom !== null && Number(expression.glideSpeed) > 0) {
      const most = Number(expression.glideSpeed) * (asked ?? definition.glide ?? .06);
      if (Math.abs(glideFrom - pitch) > most) glideFrom = most >= .05 ? pitch + Math.sign(glideFrom - pitch) * most : null;
    }
    if (!expression.chord && (definition.glide || expression.glide !== undefined)) this.lastLines.set(line, {pitch, startedAt: start, endsAt: start + duration});
    const {instrument, type, offset, model, shape: shapeOverrides, glide: _glide, glideKind: _kind, glideFrom: _from, glideAt: _at, glideSpeed: _speed, line: _line, chord: _chord, ...performed} = expression;
    let performance = expressivePerformance({note: pitch, duration, ...performed,
      profile: profile || definition.profile});
    // The family's vibrato, if it has one and the note is long enough to reach it: deeper under
    // more pressure, arriving after a delay and fading in, as a performer's does.
    const vibrato = definition.vibrato;
    if (!Number.isFinite(Number(expression.vibratoDepth)))
      performance = {...performance,
        vibratoDepth: vibrato && duration > vibrato.delay + .08
          ? vibrato.depth * (.55 + .9 * performance.pressure) : 0,
        vibratoRate: vibrato ? vibrato.rate : performance.vibratoRate,
        vibratoDelay: vibrato ? vibrato.delay : 0, vibratoFade: vibrato ? vibrato.fade : 0};
    const shape = noteShape(family, {note: pitch, velocity: performance.velocity, duration,
      legato: Boolean(glideFrom), accent: expression.accent ?? null, pan: expression.pan ?? 0,
      variant: expression.variant ?? null, filter: expression.filter, cutoffHz: expression.cutoffHz},
    {...(Number.isFinite(Number(expression.attackSeconds)) ? {attack: Number(expression.attackSeconds)} : {}),
      ...(Number.isFinite(Number(expression.releaseSeconds)) ? {release: Number(expression.releaseSeconds)} : {}),
      ...(shapeOverrides || {})},
    // A note let go of quickly (a high release velocity) is damped faster.
    {releaseScale: 1.15 - .3 * performance.releaseVelocity});
    performance = {...performance, attackSeconds: shape.values.attack, releaseSeconds: shape.values.release, family};
    return {pitch, family, definition, model: model ?? WAVE_MODELS[type] ?? definition.model,
      performance, shape, rangeDb: definition.rangeDb, velocityExponent: definition.velocityExponent ?? 2, glideFrom,glideKind,
      timeline: performanceTimeline(performance, duration, {scoop: definition.scoop, glideFrom,
        glideSeconds: asked ?? definition.glide ?? .06, pitch, ...(asked !== null && Number(expression.glideAt) > 0 ? {glideAt: Number(expression.glideAt)} : {})}),
      articulation: articulationOf(shape, {timbre: expression.timbre ?? .5, pan: expression.pan}),
      // The line it belongs to where its bot names one (a section's lines: a score writes each on its own staff).
      ...(typeof expression.line === 'string' ? {line: expression.line} : {}),
      // How it is played, where its bot says (a bowed string's arco or pizzicato), and whether it is slurred to the note
      // before (a section's player: the score writes both).
      ...(typeof expression.technique === 'string' ? {technique: expression.technique} : {}), ...(expression.slurred === true ? {slurred: true} : {}),
      ...(expression.portato === true ? {portato: true} : {}),
      // An extended technique its player chose (shared/performers/techniques.js): a wind's hum, growl or flutter.
      ...(expression.extended && typeof expression.extended === 'object' ? {extended: {...expression.extended}} : {}),
      // (And a multiphonic in the note's place, with its fingering: techniques.js.)
      ...(expression.multiphonic && typeof expression.multiphonic === 'object' ? {multiphonic: {...expression.multiphonic}} : {}),
      ...(expression.phrased === true ? {phrased: true} : {}),
      // How much later than its written time it sounds, where its bot says (a hammer's travel to its string: a transcript
      // writes the note with the chord it was struck with, transcript/capture.js).
      ...(Number.isFinite(expression.lag) && expression.lag !== 0 ? {lag: expression.lag} : {}),
      // (Where its player knows it is written, in the shared ticks: capture.js writtenTick.)
      ...(Number.isFinite(expression.writtenTick) ? {writtenTick: expression.writtenTick, ...(expression.writtenTicks > 0 ? {writtenTicks: expression.writtenTicks} : {})} : {}),
      ...scoreTimeFields(expression.scoreTime?expression:this),
      // (A seat's note told whole by its first stroke, its later strokes not at all: toldBy.)
      ...(expression.captured === false ? {captured: false} : expression.told ? {told: {...expression.told}} : {}),
      // How much later it sounds as its chord's roll, where its bot rolls one (a harp's strings plucked low to high: a
      // transcript writes the chord together, rolled).
      ...(Number.isFinite(expression.roll) && expression.roll !== 0 ? {roll: expression.roll} : {}),
      // The glissando it is a string of, where its bot sweeps one ({id, index, of}: a score writes its first and last
      // strings joined by a line).
      ...(expression.gliss && typeof expression.gliss === 'object' ? {gliss: {...expression.gliss}} : {})};
  }
  // Keep a note in the register so it can be released later, and drop the ones whose own
  // length has already run out. Pruning here rather than on a timer means the register costs
  // nothing when nothing is playing.
  // (`line`: the line the note's bot says it belongs to, a section's player: expression.line.)
  remember(event,pitch,renderer=null,line=null){
    const release=event.performance?.releaseSeconds??.08,at=this.clockTime();
    for(const [identity,note] of this.sounding)if(note.endsAt<=at){this.sounding.delete(identity);this.umpNotes?.delete(identity)}
    this.retrigger(event,pitch,line);
    this.sounding.set(event.identity,{note:pitch,startedAt:event.atSeconds,
      endsAt:event.atSeconds+(event.duration||0)+release,release,...(renderer&&renderer!==this.dspNode?{renderer}:{}),...(line!==null?{line}:{})});
    return event.identity;
  }
  // Striking a pitch this engine is still holding releases the older one.
  //
  // **This exists because of a measurement.** Every synthesiser since the 1960s does this — a
  // note-on for a sounding note is a retrigger, not a second voice — and this engine did not,
  // so a bot played on top of itself. Over 45 seconds of the five-bot line-up: ae_PadBOT
  // restruck a pitch it was still holding on **72 of its 96 notes (75%)**, which is how one bot
  // came to be holding eight to eighteen of its own voices ninety per cent of the time. The
  // unattributed engine did it on 49% of its notes, mh_BleepBOT on 18%.
  //
  // The tolerance is tight — a tenth of a semitone — because pitch here is a floating-point
  // semitone and a quarter-tone inflection is a different note, not the same one played again.
  //
  // A restrike is the same line's: where a bot sounds several lines (a section's players, each its `line`), two of them
  // on one pitch are a unison, two players, and neither ends the other (found 1 October 2026: a string section's double
  // bass cut at its own start by a cello on its pitch, while its score held it).
  retrigger(event,pitch,line=null){
    if(this.stackRepeats)return [];
    const at=Math.max(this.clockTime(),event.atSeconds??this.clockTime());
    return this.releaseNotes(note=>Math.abs(note.note-pitch)<RETRIGGER_SEMITONES&&(note.line??null)===line,{atSeconds:at});
  }
  // The notes the renderer is still holding at a moment, pruned of the finished ones.
  soundingNotes(atSeconds=this.clockTime()){
    for(const [identity,note] of this.sounding)if(note.endsAt<=atSeconds)this.sounding.delete(identity);
    return this.sounding;
  }
  // Stop a note that has already begun.
  //
  // **This exists because of a measurement.** Both renderers already implement an early
  // release — the Rust engine as `4 => voice.duration = voice.elapsed`, the Web Audio voice as
  // a ramp to zero — and a search of the whole app found exactly one occurrence of action 4:
  // the implementation. Nothing ever sent it. So a note ran to the length it was born with and
  // could not be stopped, whatever happened afterwards. On the five-bot line-up, 45 seconds:
  // 962 notes, the longest 17.78 s, a median of 15 sounding at once and a peak of 45, with
  // ae_PadBOT alone holding 10 to 20 of its own notes 90% of the time. A pad note is 4.44 s
  // long with a 1.07 s tail and a chord is 1.11 s, so every pad note outlived four chords.
  // That is what "blurred harmony" is, and no amount of mixing fixes it.
  // `seconds`, when given, lets the note go sooner than its own release -- from the level it is at, like a key
  // lifted early -- and shortens a tail already under way. Without it the note releases as it was shaped to.
  releaseNote(identity,{atSeconds,seconds}={}){
    const note=this.sounding.get(identity);
    if(!note)return false;
    const at=Math.max(this.clockTime(),atSeconds??this.clockTime());
    if(note.endsAt<=at){this.sounding.delete(identity);this.umpNotes?.delete(identity);return false}
    const within=Number(seconds)>0?Math.min(Number(seconds),note.release):null;
    // A note already in its tail is already stopping, and asking it to stop again changes nothing -- unless it is
    // asked to be gone sooner than its tail would take, which the voice does from the level it has reached.
    if(at>=note.endsAt-note.release-1e-9&&!(within!==null&&at+within<note.endsAt-1e-9))return false;
    // (A winds synth's note let go by its Note Off then: wind-midi2.js windRelease.)
    const renderer=note.renderer??this.dspNode,address=this.umpNotes?.get(identity);
    if(renderer?.capabilities?.windMidi2&&address)renderer.ump?.(windRelease(address,at));
    else renderer?.schedule?.([{action:4,identity,value:within??0,atSeconds:at}]);
    this.captureRelease(address,at);
    this.releaseGraph(identity,at,within??note.release);
    // The note still rings for its release. Say when it will actually be gone, so a caller
    // asking "is the room clear" is not told yes while a tail is still sounding.
    note.endsAt=at+(within??note.release);
    return true;
  }
  // Release every sounding note the predicate picks out. Returns what was released, so the
  // caller can say why rather than only that something happened.
  releaseNotes(predicate=()=>true,{atSeconds}={}){
    const at=Math.max(this.clockTime(),atSeconds??this.clockTime()),released=[];
    for(const [identity,note] of this.soundingNotes(at))
      if(predicate(note,identity)&&this.releaseNote(identity,{atSeconds:at}))released.push({identity,...note});
    return released;
  }
  // The Web Audio path builds its own nodes rather than going through a renderer, so its
  // release is an envelope here rather than an action over the port.
  // The conductor's cutoff (framework/agent.js cutOffAt): everything this engine still sounds let go at `atSeconds` over
  // `seconds` -- its voices, its recordings, its physical model's strokes -- whatever each was given to hold; what its
  // player has let go already left as it was let go.
  cutOff({atSeconds,seconds=.2}={}){
    const at=Math.max(this.clockTime(),atSeconds??this.clockTime());
    this.releaseNotes(()=>true,{atSeconds:at});
    for(const graph of [...this.activeGraphs])if(graph.amp&&graph.identity!=null&&!graph.released)this.releaseGraph(graph.identity,at,seconds);
    if(this.physical)for(const entry of this.physical.log)if(!Number.isFinite(entry.released)&&entry.at+entry.seconds>at){entry.released=+at.toFixed(6);bowedRelease(this.physical,entry,entry.released,this)}
  }
  releaseGraph(identity,at,release=.05){
    for(const graph of this.activeGraphs){
      if(graph.identity!==identity||!graph.amp)continue;graph.released=true;
      const gain=graph.amp.gain,end=at+Math.max(.005,release);
      // (A ramp begins at the event before it, and a hold on a setTarget holds nothing a ramp can start from: a release
      // scheduled ahead, after a sampled note's attack long past, fell from there -- 50 dB down by the time it was asked
      // for -- and one in the note's own fading fell from nothing, each a cut and a click. A note that knows its level
      // sets it at the release's start, so the fall begins there and from there; one still in its attack is held.)
      const level=graph.levelAt?.(at);
      if(level!=null){gain.cancelScheduledValues(at);gain.setValueAtTime(Math.max(level,.0001),at)}
      else if(gain.cancelAndHoldAtTime)gain.cancelAndHoldAtTime(at);
      else {gain.cancelScheduledValues(at);gain.setValueAtTime(gain.value,at)}
      // Exponential, because the attack that opened this envelope was exponential and a
      // linear ramp from an exponential curve steps audibly at the join.
      gain.exponentialRampToValueAtTime(.0001,end);
      for(const node of graph.nodes)if(typeof node.stop==='function')try{node.stop(end+.01)}catch{}
    }
  }
  // One pitched note, through whichever renderer is attached.
  //
  // `gain` is the note's level. When the caller names an instrument (`expression.instrument`,
  // an articulation.js family) it is the level at the pivot velocity, and the family's own
  // dynamic range carries the note from there: a soft note of a piano is 36 dB of range away
  // from a hard one, a drone's only 12. A caller that names none keeps the level it computed.
  voice(note, duration, gain, type = "sine", offset = 0, expression = {}) {
    if (!this.ctx || this.muted || !this.master) return;
    // The same refusal on the path that does not go through the renderer, so a declined note
    // is declined whichever backend is in use rather than only on one of them.
    if (!Number.isFinite(note) || note < 0 || note > PITCH_CEILING) {
      this.report('pitch_unplayable',{note,duration,limit:PITCH_CEILING,
        says:`${Number.isFinite(note)?note.toFixed(3):String(note)} semitones is outside `
          +`MIDI 2's 0..${PITCH_CEILING.toFixed(3)}; the note was declined`});
      return;
    }
    // A pitch its bot has already tuned as part of a deliberate relation (a beating pair's member about a tuned centre:
    // docs/PITCH_LANGUAGES.md) is sounded as given (exactPitch), as midiNote sounds it: the room's tuning plan would pull the
    // pair's two members to one pitch.
    const nominalNote=note,sourceVelocity=Number.isFinite(Number(expression.velocity))
        ?Number(expression.velocity):Math.min(1,Math.sqrt(Math.max(0,gain)/.16)),
      velocity=this.performanceVelocity(sourceVelocity),pitch=expression.exactPitch?note:this.tunePitch(note),
      plan=this.planNote(pitch,duration,{...expression,...(expression.told?{told:toldTuned(expression.told,pitch-nominalNote)}:{}),velocity,type,offset}),
      level=Math.max(.0001,expression.instrument
        ?gain*familyVelocityGain(plan.performance.velocity,plan.rangeDb,plan.velocityExponent)
        :gain*Math.sqrt(velocity/Math.max(.04,sourceVelocity))),
      performance=plan.performance;
    if(this.dspNode){
      const identity=this.scheduleDsp(plan.model,pitch,duration,level,offset,expression.paramA??0,expression.paramB??0,
        {plan,...(expression.ratios?{ratios:expression.ratios,gains:expression.gains}:{}),...(plan.extended?{extended:plan.extended}:{})});
      this.report('rendered_pitch',{nominalNote,note:pitch,deviationCents:(pitch-nominalNote)*100,duration,scheduledAt:this.eventStart(offset)});
      this.report('expressive_note',{note:pitch,duration,profile:performance.profile,family:plan.family,velocity:performance.velocity,pressure:performance.pressure,slide:performance.slide,sustained:performance.sustained});
      return identity;
    }
    // The native Web Audio voice: the renderer when no synthesizer is attached. It follows the
    // same plan with the nodes Web Audio has -- an envelope of exponential segments, a filter
    // whose cutoff curve is the shape's filter envelope and brightness, a pitch curve that is the
    // timeline's own points (vibrato included), and a pressure curve.
    const web = EXPRESSION_CONFIG.webAudio, shape = plan.shape.values,
      now = this.eventStart(offset),
      osc = this.ctx.createOscillator(),
      filter = this.ctx.createBiquadFilter(),
      amp = this.ctx.createGain(),
      pressure = this.ctx.createGain(),
      span = Math.max(0.02, duration),
      peak = Math.max(0.0001, level),
      attackEnd = now + Math.max(0.001, Math.min(shape.attack, duration * 0.9)),
      releaseStart = Math.max(attackEnd, now + duration),
      release = Math.max(0.005, shape.release),
      held = shape.decay > 0 ? Math.max(0.0001, peak * (shape.sustain + (1 - shape.sustain) * Math.exp(-6.9 * Math.max(0, releaseStart - attackEnd) / shape.decay))) : peak;
    osc.type = type;
    osc.frequency.value = midiHz(pitch);
    filter.type = ({2: "bandpass", 3: "highpass"})[shape.filterMode] || "lowpass";
    filter.Q.value = type === "sawtooth" || type === "square"
      ? Math.max(web.softWaveQ, 0.5 + 11.5 * shape.resonance ** 2)
      : web.softWaveQ;
    // Cutoff over the note: key, velocity, the filter envelope, and brightness from the timeline.
    const points = 32, key = shape.keytrack * Math.log2(midiHz(pitch) / 261.6256),
      slideAt = at => pointValue(plan.timeline.slide, at),
      filterLevel = at => {
        const attack = Math.max(0.001, shape.filterAttack);
        if (at < attack) return at / attack;
        const decayed = shape.filterDecay > 0
          ? shape.filterSustain + (1 - shape.filterSustain) * Math.exp(-6.9 * (at - attack) / shape.filterDecay) : 1;
        return decayed;
      };
    const cutoff = Array.from({length: points}, (_, index) => {
      const at = span * index / (points - 1),
        octaves = key + shape.filterEnv * filterLevel(at) + shape.velocityCutoff * (shape.velocity - 0.5)
          + shape.brightnessRange * (slideAt(at) - 0.5) * 2;
      return Math.min(this.ctx.sampleRate * 0.42, Math.max(30, (shape.filterMode === 4 ? 20000 : shape.cutoff) * 2 ** octaves));
    });
    filter.frequency.setValueCurveAtTime(new Float32Array(cutoff), now, span);
    amp.gain.setValueAtTime(0.0001, now);
    amp.gain.exponentialRampToValueAtTime(peak, attackEnd);
    if (held < peak * 0.999) amp.gain.exponentialRampToValueAtTime(held, releaseStart);
    else amp.gain.setValueAtTime(peak, releaseStart);
    amp.gain.exponentialRampToValueAtTime(0.0001, releaseStart + release);
    pressure.gain.setValueCurveAtTime(
      new Float32Array(Array.from({length: points}, (_, index) =>
        web.gainPressureFloor + web.gainPressureScale * pointValue(plan.timeline.pressure, span * index / (points - 1)))),
      now, span);
    // The pitch curve is the timeline's points resampled evenly -- drift, onset and vibrato alike.
    const pitchSamples = Math.max(2, Math.min(2048, Math.ceil(span * 60) + 1));
    osc.detune.setValueCurveAtTime(
      new Float32Array(Array.from({length: pitchSamples}, (_, index) =>
        100 * pointValue(plan.timeline.pitch, span * index / (pitchSamples - 1)))),
      now, span);
    osc.connect(filter).connect(amp).connect(pressure);
    const nodes = [osc, filter, amp, pressure];
    if (shape.pan && typeof this.ctx.createStereoPanner === "function") {
      const place = this.ctx.createStereoPanner();
      place.pan.value = shape.pan;
      pressure.connect(place).connect(this.master);
      nodes.push(place);
    } else pressure.connect(this.master);
    // The Web Audio path gets an identity and a register entry too, so that a caller holding
    // an identity can release a note without first having to know which renderer made it.
    const identity = this.nextDspIdentity++,
      graph = this.retainGraph(osc, nodes);
    graph.identity = identity;
    graph.amp = amp;
    this.remember({identity, atSeconds: now, duration,
      performance: {releaseSeconds: release}}, pitch, null, plan.line ?? null);
    osc.start(now);
    osc.stop(releaseStart + release + 0.03);
    this.report("rendered_pitch", {
      nominalNote,
      note: pitch,
      deviationCents: (pitch - nominalNote) * 100,
      duration,
      scheduledAt: now,
      contextTime: this.ctx.currentTime,
      eventTime: this.eventTime,
      gain: peak,
    });
    this.report("expressive_note", {
      note: pitch,
      duration,
      profile: performance.profile,
      family: plan.family,
      velocity: performance.velocity,
      pressure: performance.pressure,
      slide: performance.slide,
      vibratoDepth: performance.vibratoDepth,
      sustained: performance.sustained,
    });
    return identity;
  }
  // A synthesized drum: the kit piece's own shaped voices, heard as the drum and recorded as the
  // drum -- its General MIDI note on channel 10, with its articulation -- as the sampled path
  // records it, whatever voices make up its sound.
  // `shape` overrides the family's shape for this hit: a bot whose drum was designed as something else keeps it.
  //
  // `strike` is the stroke beyond its velocity (shared/percussion-expression.js): {stroke, position, openness, damping,
  // tuning, tuneTo, pressure, piece}, any of them. It changes the hit only when given, so a bot that gives none sounds and is
  // recorded exactly as before. With one, each voice takes the stroke's tone as the overrides of its shape and its level,
  // the recorded note is the stroke's General MIDI note (a rimshot 40, a cross stick 37, an opened hat 46, a ride's bell
  // 53) with its brightness (#74), where it was struck (#71) and, for a retuned drum, its pitch (Pitch 7.9).
  drum(kind, velocity = 0.7, {note = null, pitch = null, variant = null, pan = null, duration = null, offset = 0, cutoffHz = null, level = 1, shape = null, strike = null} = {}) {
    if (!this.ctx || this.muted || !this.master) return;
    // No two performers' kicks at once (shared/performers/ensemble-kicks.js): the later to be scheduled yields.
    if (pieceOf(kind, {note: note ?? (DRUM_KIT[kind] || DRUM_KIT.perc).note, piece: strike?.piece}) === "kick" && !this.mayKick(offset)) return;
    // A choke stops the cymbal ringing (a stroke that sounds nothing: percussion-expression.js PIECES crash.choke).
    if (strike?.stroke === "choke") return this.chokeCymbal(kind, {note, offset, level});
    const kit = DRUM_KIT[kind] || DRUM_KIT.perc, v = Math.max(0, Math.min(1, velocity)),
      performed = this.performanceVelocity(v), length = duration ?? kit.duration,
      // A split kit places each drum by its channel's pan (splitKit), so the hit is voiced in the middle of it, or at its
      // drum's place among the channel's (the toms).
      place = pan ?? (this.kit ? kitHitPan(kitChannelOf(pieceOf(kind, {note: note ?? kit.note, piece: strike?.piece})), note ?? kit.note) : kit.pan), sounding = [];
    // A plugin instrument plays the drum's General MIDI note (below) with its own voice. A sampled kit's pitch is measured
    // (shared/drum-pitches.js), and the kit tunes itself to the same note (synths/drum-kit.js), so the note is recorded as
    // it sounds; a WAM's or a VST3's is not known, and it is left as it is. The synthesized voice falls to its layer's note,
    // and is tuned from there.
    const drumKit = this.dspNode?.capabilities?.drumKit, plugin = this.dspNode?.backend === "wam" || this.dspNode?.backend === "vst3" || Boolean(drumKit);
    const piece = pieceOf(kind, {note: note ?? kit.note, piece: strike?.piece}), renderer = this.kitPart(piece)?.renderer ?? null, given = normalizeStrike(piece, strike),
      ownPitch = drumKit ? kitPitch(drumKit.kit, note ?? kit.note, piece) : plugin ? null : pitch ?? kit.layers[0].pitch,
      tone = given ? strikeTone(piece, given, {note: note ?? kit.note, explicit: note !== null, openness: piece === 'hat' ? (kind === 'openHat' ? 1 : 0) : null, sounding: ownPitch}) : null,
      drumNote = tone?.note ?? note ?? kit.note,
      controllers = strikeControllers(tone),
      // Each layer's shape for this hit: the kit's own, the caller's, and the stroke's laid over them.
      layerShape = (layer, layerPitch) => {
        const fixed = layer.shape || shape ? {...(layer.shape || {}), ...(shape || {})} : null;
        if (!tone) return fixed;
        const at = {pitch: layerPitch, duration: length, velocity: performed, variant: variant ?? layer.variant ?? null, cutoffHz: cutoffHz ?? layer.cutoffHz, pan: place},
          values = this.drumLayerValues(layer.family, at, fixed),
          ends = layer.family === 'hat' && tone.openness !== null && at.variant !== 'ride'
            ? {closed: this.drumLayerValues('hat', {...at, variant: null}, fixed), open: this.drumLayerValues('hat', {...at, variant: 'open'}, fixed)} : {};
        return {...(fixed || {}), ...strikeShape(layer.family, values, tone, ends)};
      },
      firstPitch = (pitch ?? kit.layers[0].pitch) + (tone?.pitch ?? 0);
    // A plugin instrument (a WAM, the Faust flute, a VST3, a sampled kit) hears a drum as a MIDI drum module does: one
    // note, the kit piece's General MIDI number, at the hit's velocity. A drum machine plays its pad for it (DRM-16's pads
    // answer to 36 and up); the pitches of the built-in voice's layers would reach it as notes its pads do not have. The
    // stroke goes with it: its brightness as the note's brightness control (CC 74 under MPE), and the whole strike for an
    // instrument that reads one (synths/drum-kit.js).
    if (plugin) {
      const overrides = layerShape(kit.layers[0], firstPitch),
        hit = this.planNote(drumNote, length, {instrument: kit.layers[0].family, velocity: performed, pan: place, offset,
          ...(overrides ? {shape: overrides} : {}), ...(controllers.timbre !== null ? {timbre: controllers.timbre} : {})});
      const identity = this.scheduleDsp(hit.model, drumNote, length,
        level * (tone ? strikeGain(kit.layers[0].family, tone) : 1) * familyVelocityGain(hit.performance.velocity, hit.rangeDb, hit.velocityExponent), offset, 0, 0,
        {plan: hit, skipCapture: true, renderer, ...(controllers.brightness !== null ? {controls: [{seconds: 0, action: 3, value: controllers.brightness}]} : {}),
          drum: {kind, piece, note: drumNote, velocity: hit.performance.velocity, level, ...(tone ? {strike: {...given, ...tone}} : {})}});
      this.captureUMP(drumNote, length, hit.performance.velocity, offset, hit.performance,
        {fixedPercussion: true, channel: 9, brightness: controllers.brightness, pitch: tone?.pitch ? drumNote + tone.pitch : null, ...(given?.stroke === "roll" || given?.stroke === "swell" ? {rolled: true} : {})}, hit);
      this.report("drum", {kind, note: drumNote, velocity: hit.performance.velocity, pan: place, ...(tone ? {stroke: tone.stroke} : {}),
        ...excitationAndGain(hit.performance.velocity, level, drumKit ? "recorded layers" : "a plugin's velocity")});
      return identity || null;
    }
    // A hi-hat closed, by the stick or the foot, stops the open hat ringing: a stroke's own choke, so only with a strike.
    if (tone && piece === 'hat') {
      if ((tone.openness ?? 0) < OPEN_HAT_RINGS || tone.stroke === 'pedal') {
        const at = this.eventStart(offset);
        for (const identity of this.ringingHats ?? []) this.releaseNote(identity, {atSeconds: at, seconds: HAT_CHOKE_SECONDS});
        this.ringingHats = [];
      }
    }
    for (const layer of kit.layers) {
      const layerPitch = (pitch ?? layer.pitch) + (tone?.pitch ?? 0), overrides = layerShape(layer, layerPitch);
      const plan = this.planNote(layerPitch, length, {instrument: layer.family, velocity: performed,
        variant: variant ?? layer.variant ?? null, pan: place, offset, cutoffHz: cutoffHz ?? layer.cutoffHz, ...(overrides ? {shape: overrides} : {})});
      const gain = layer.level * level * (tone ? strikeGain(layer.family, tone) : 1) * familyVelocityGain(plan.performance.velocity, plan.rangeDb, plan.velocityExponent);
      if (this.dspNode) {
        const identity = this.scheduleDsp(plan.model, plan.pitch, length, gain, offset, layer.paramA ?? 0, layer.paramB ?? 0,
          {plan, skipCapture: true, renderer});
        if (identity) sounding.push(identity);
      } else if (layer.family === "snareWires" || plan.model === MODEL.noise || plan.model === MODEL.metal || plan.model === MODEL.clap)
        this.noise(Math.max(0.02, plan.shape.values.decay * 0.6), gain * 0.5, plan.shape.values.cutoff, offset);
      else this.voice(plan.pitch, length, gain, "sine", offset, {instrument: layer.family, velocity: performed, ...(overrides ? {shape: overrides} : {})});
    }
    if (tone && piece === 'hat' && (tone.openness ?? 0) >= OPEN_HAT_RINGS && tone.stroke !== 'pedal')
      (this.ringingHats ??= []).push(...sounding);
    // A cymbal a hand may choke: its voices, until they are choked.
    if (CHOKED_PIECES.includes(piece)) ((this.ringingCymbals ??= new Map()).get(piece) ?? this.ringingCymbals.set(piece, []).get(piece)).push(...sounding);
    // One drum, one note: the kit piece's number, whatever its voices are.
    const hitShape = tone ? layerShape(kit.layers[0], firstPitch) : null,
      hit = this.planNote(drumNote, length, {instrument: kit.layers[0].family, velocity: performed, pan: place, offset,
        ...(hitShape ? {shape: hitShape} : {}), ...(controllers.timbre !== null ? {timbre: controllers.timbre} : {})});
    this.captureUMP(drumNote, length, hit.performance.velocity, offset, hit.performance,
      {fixedPercussion: true, channel: 9, brightness: controllers.brightness, pitch: tone?.pitch ? drumNote + tone.pitch : null, ...(given?.stroke === "roll" || given?.stroke === "swell" ? {rolled: true} : {})}, hit);
    this.report("drum", {kind, note: drumNote, velocity: hit.performance.velocity, pan: place, ...(tone ? {stroke: tone.stroke} : {}),
      ...excitationAndGain(hit.performance.velocity, level, "a synthesized voice")});
    return sounding[0] ?? null;
  }
  // A kernel stream's window (shared/kernel-stream.js; the extreme-aesthetics report's M2): the kernels in [from, to) of
  // the stream's own clock, each at its exact time, `origin` being where the stream's 0 falls on this engine's clock
  // (eventStart when it began). An electronic source: its kicks are this performer's own, never a drummer's (§8.2), and
  // are kick contacts like any other, so the ensemble's kick policy holds for them too. A window the renderer cannot
  // take is reported as refused, or as the fused texture the stream allows, never played as something else. Returns
  // the window.
  playStream(stream, {from, to, origin = 0}) {
    const window = expandStream(stream, {from, to}), now = this.eventStart(0);
    if (window.status !== "ok") { this.report("stream", {id: stream.id, status: window.status, reason: window.reason}); return window; }
    for (const kernel of window.kernels) {
      const offset = Math.max(0, origin + kernel.seconds - now), level = 10 ** (kernel.gainDb / 20), {kind, piece, pitch, seconds, instrument = "synthPluck"} = stream.kernel;
      if (kind === "drum") this.drum(piece ?? "kick", .7, {offset, level, duration: seconds});
      else if (kind === "noise") this.noise(seconds, .1 * level, 4000, offset);
      else this.voice(pitch ?? 60, seconds, .1 * level, "sine", offset, {instrument, velocity: .7});
    }
    this.report("stream", {id: stream.id, status: "ok", kernels: window.kernels.length, from, to, expectedVoices: expectedVoices(stream).voices});
    return window;
  }
  // A sustained sound object (shared/sound-object.js): one voice for its whole duration, its trajectories as the voice's
  // own controls, ramped from point to point, and protected: a dense passage in the same engine steals around it, never
  // it (the DSP core's SHAPE_PROTECTED; the extreme-aesthetics report's E19). Returns its identity, or null.
  playSoundObject(object, {offset = 0} = {}) {
    if (!this.ctx || this.muted || !this.master || !this.dspNode) return null;
    const plan = this.planNote(object.pitch, object.duration, {instrument: object.instrument, velocity: object.velocity, offset, shape: {protected: 1}});
    const identity = this.scheduleDsp(plan.model, plan.pitch, object.duration, .1 * familyVelocityGain(plan.performance.velocity, plan.rangeDb, plan.velocityExponent),
      offset, 0, 0, {plan, controls: soundObjectControls(object)});
    this.report("soundObject", {id: object.id, identity: identity || null, seconds: object.duration, controls: soundObjectControls(object).length, state: object.state});
    return identity || null;
  }
  // A hand grabs a cymbal and stops it (T19): its ringing voices let go in CYMBAL_CHOKE_SECONDS, a sampled kit's by the
  // kit itself (synths/drum-kit.js), a plugin's not at all (it has no choke here: reported, not faked).
  chokeCymbal(kind, {note = null, offset = 0, level = 1} = {}) {
    const piece = pieceOf(kind, {note: note ?? (DRUM_KIT[kind] || DRUM_KIT.perc).note}), at = this.eventStart(offset);
    if (!CHOKED_PIECES.includes(piece)) throw new RangeError(`no choke for a ${piece}`);
    const drumKit = this.dspNode?.capabilities?.drumKit, plugin = this.dspNode?.backend === "wam" || this.dspNode?.backend === "vst3";
    if (drumKit) this.dspNode.schedule([{atSeconds: at, offsetSeconds: Math.max(0, at - this.ctx.currentTime), identity: this.nextDspIdentity++,
      drum: {kind, piece, note: note ?? DRUM_KIT[kind]?.note ?? null, velocity: 0, level, strike: {stroke: "choke"}}}]);
    else if (!plugin) {
      for (const identity of this.ringingCymbals?.get(piece) ?? []) this.releaseNote(identity, {atSeconds: at, seconds: CYMBAL_CHOKE_SECONDS});
      this.ringingCymbals?.set(piece, []);
    }
    this.report("drum", {kind, piece, choke: true, ...(plugin ? {unsupported: "a plugin's kit has no choke here"} : {})});
    return null;
  }
  // A kit layer's slots for one hit as planNote makes them (the performance's velocity and release), before a stroke is
  // laid on: what strikeShape scales. Pure: planNote itself counts the family and remembers lines.
  drumLayerValues(family, {pitch, duration, velocity, variant = null, cutoffHz = null, pan = 0}, overrides = null) {
    const definition = FAMILIES[family] || FAMILIES.shaker,
      performance = expressivePerformance({note: pitch, duration, velocity, profile: definition.profile});
    return noteShape(family, {note: pitch, velocity: performance.velocity, duration, legato: false, accent: null, pan, variant, cutoffHz},
      overrides || {}, {releaseScale: 1.15 - .3 * performance.releaseVelocity}).values;
  }
  // Filtered noise: a bed, a gust, a crackle, a brush. Shaped as the `noise` family shapes it --
  // a bandpass at `filterHz`, as the Web Audio voice has always had it, where the Rust voice used
  // to run a one-pole lowpass and so played a different sound from the same call -- faded in and
  // out over its length, or struck and decaying when `options.instrument` names a struck family.
  noise(duration, gain, filterHz = 6000, offset = 0, options = {}) {
    if (!this.ctx || this.muted) return;
    gain*=this.velocityGain||1;
    // A noise has a level rather than a velocity; read one from it, as voice() does for a caller
    // that names none, so a bed of crackles is recorded as the crackles it is -- varied -- and
    // not as one velocity struck over and over.
    const plan=this.dspNode&&this.master?this.planNote(69,duration,{instrument:options.instrument||'noise',
      velocity:options.velocity??Math.min(1,Math.sqrt(Math.max(0,gain)/.12)),cutoffHz:filterHz,pan:options.pan??0,offset,variant:options.variant??null}):null;
    if (this.scheduleDsp(1, 69, duration, gain, offset, filterHz < 180 ? 2 : filterHz < 3000 ? 1 : 0, filterHz, plan?{plan}:{})) return;
    const length = Math.ceil(this.ctx.sampleRate * duration),
      buffer = this.ctx.createBuffer(1, length, this.ctx.sampleRate),
      data = buffer.getChannelData(0);
    for (let i = 0; i < length; i++) data[i] = random() * 2 - 1;
    const source = this.ctx.createBufferSource(),
      filter = this.ctx.createBiquadFilter(),
      amp = this.ctx.createGain(),
      now = this.eventStart(offset);
    source.buffer = buffer;
    filter.type = "bandpass";
    filter.frequency.value = filterHz;
    const attack =
        duration >= 0.3
          ? Math.min(0.02, duration * 0.02)
          : Math.min(0.003, duration * 0.12),
      release =
        duration >= 0.3
          ? Math.min(0.08, duration * 0.08)
          : Math.min(0.008, duration * 0.2),
      releaseStart = Math.max(now + attack, now + duration - release);
    amp.gain.setValueAtTime(0.0001, now);
    amp.gain.exponentialRampToValueAtTime(Math.max(0.0001, gain), now + attack);
    amp.gain.setValueAtTime(Math.max(0.0001, gain), releaseStart);
    amp.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    source.connect(filter).connect(amp).connect(this.master);
    this.retainGraph(source, [source, filter, amp]);
    source.start(now);
    source.stop(now + duration + 0.03);
  }
  // The note's timeline as MIDI 1 messages on one channel. Pitch bends are relative to the
  // note-on's own note number: a point that happened to round to the next semitone used to be
  // encoded against that semitone instead, so the bend jumped by a semitone mid-note.
  midiTimeline(channel, base, pitch, at, plan, {perNotePressure = false} = {}) {
    const range = this.mpeBendRange, bendOf = semitones => {
      const value = Math.max(0, Math.min(16383, Math.round(8192 + (pitch + semitones - base) / range * 8192)));
      return [0xe0 + (channel & 15), value & 127, value >> 7];
    };
    for (const point of plan.timeline.pitch) if (point.at > 0) this.sendMidi(bendOf(point.value), at + point.at * 1000);
    for (const point of plan.timeline.slide) if (point.at > 0)
      this.sendMidi([0xb0 + (channel & 15), 74, normalizedMidi7(point.value)], at + point.at * 1000);
    for (const point of plan.timeline.pressure) if (point.at > 0)
      this.sendMidi(perNotePressure ? [0xa0 + (channel & 15), base, normalizedMidi7(point.value)]
        : [0xd0 + (channel & 15), normalizedMidi7(point.value)], at + point.at * 1000);
    return bendOf;
  }
  // MIDI 1 as fully as a receiver can take it:
  //   * 14-bit velocity, the MIDI 1.0 High Resolution Velocity Prefix (CC 88, MMA CA-031) sent
  //     immediately before the note-on, which a receiver without it ignores;
  //   * under MPE, the note's articulation on its own channel -- attack (CC 73), decay (75),
  //     release (72), timbre (71), pan (10) -- centred at 64 as MMA RP-021 has them, and its
  //     whole timeline of pitch, brightness (CC 74) and pressure;
  //   * on one channel, pressure as polyphonic key pressure, which belongs to one note, rather
  //     than channel pressure, which would press every note the channel holds.
  // Member channels are put back to rest when the note's release is over, not at its note-off:
  // resetting the bend at the note-off retuned the tail of every microtonal note as it faded.
  midiNote(
    note,
    duration = 0.25,
    velocity = 0.7,
    channel = 0,
    offset = 0,
    expression = {},
  ) {
    if (this.muted || !this.midiOutput) return;
    velocity=this.performanceVelocity(velocity);
    const nominalNote = note;
    note = expression.exactPitch ? note : this.tunePitch(note);
    // A drum bot's notes are drum numbers: they go to its channel, never through MPE's pitch bends.
    const percussion=this.definition?.pitchContract==="fixed-percussion",
      plan=this.planNote(note,duration,{...expression,...(expression.told?{told:toldTuned(expression.told,note-nominalNote)}:{}),velocity,offset}),
      performance = plan.performance,
      delay = Math.max(
        0,
        (this.eventStart(offset) - this.clockTime()) * 1000,
      ),
      at = globalThis.performance.now() + delay,
      offAt = at + duration * 1000,
      restAt = offAt + Math.max(2, plan.shape.values.release * 1000),
      velocity14 = Math.max(128, Math.min(16383, Math.round(performance.velocity * 16383))),
      midiVelocity = velocity14 >> 7,
      velocityPrefix = velocity14 & 127,
      releaseVelocity = normalizedMidi7(performance.releaseVelocity);
    const nativeChannel=this.midiChannelOverride??this.defaultMidiChannel??channel;
    const canonical=this.captureUMP(note,duration,performance.velocity,offset,performance,
      this.midiProtocol==='midi2'?{group:this.midiGroup,channel:nativeChannel,fixedPercussion:this.definition?.pitchContract==='fixed-percussion'}:{},plan);
    // `captureUMP` returns null for a pitch MIDI 2 cannot carry, and declining the note is the
    // whole point of that — but this path read the result without checking, so the
    // `TypeError: Cannot read properties of null` fell out of the caller's tick and took the
    // rest of the bot's bar with it. Exactly the fault the decline was added to end, still
    // live on the external-MIDI path for every bot. `scheduleDsp` has this guard; this did not.
    if(!canonical)return;
    note=inspectUMP(canonical.events.find(event=>inspectUMP(event.packet).kind==='noteOn').packet).pitch;
    this.report("rendered_pitch", {
      nominalNote,
      note,
      deviationCents: (note - nominalNote) * 100,
      duration,
    });
    // The program the note's instrument asks for (general-midi.js), where the setting asks for one: a drum part's
    // channel takes none, and an MPE zone's is its manager channel's.
    const program=percussion?null:programFor(this.midiProgram,plan.family);
    if(this.midiProtocol==='midi2'){
      this.sendProgram(program,nativeChannel,at);
      this.midiOutput.sendPackets(canonical.events.map(event=>({packet:event.packet,time:at+event.time*1000})));
      this.onMidiSend?.({port:this.midiOutput.name,packet:canonical.events.find(event=>inspectUMP(event.packet).kind==='noteOn').packet,
        at,pitch:note,channel:nativeChannel+1,group:this.midiGroup+1,protocol:'midi2',mpe:false,expression:performance});
      return;
    }
    const start = plan.timeline.pitch[0]?.value ?? 0,
      slide = plan.timeline.slide[0]?.value ?? performance.slide,
      pressure = plan.timeline.pressure[0]?.value ?? performance.pressure;
    if (this.mpeEnabled && this.mpeZone !== "single" && !percussion) {
      // Events for a whole phrase may be scheduled in one JavaScript turn.
      // Expire member channels at this note's scheduled onset, not at the
      // scheduler's wall-clock time, or later phrase notes are falsely
      // rejected after the first 15 allocations. A channel is held through
      // its note's release, so a new note never retunes a sounding tail.
      channel = this.mpeAllocator.acquire(restAt + 2, at);
      if (channel == null) {
        this.report("mpe_voice_limit", {
          pitch: note,
          limit: this.mpeAllocator.channels.length,
        });
        return;
      }
      const encoded = mpePitch(note, this.mpeBendRange),
        on = [0x90 + (channel & 15), encoded.note, midiVelocity],
        off = [0x80 + (channel & 15), encoded.note, releaseVelocity],
        articulation = plan.articulation;
      this.sendProgram(program, this.mpeZone === "upper" ? 15 : 0, at);
      const bendOf = this.midiTimeline(channel, encoded.note, note, at, plan);
      this.sendMidi(bendOf(start), at);
      for (const {controller, bipolar} of articulation)
        this.sendMidi([0xb0 + (channel & 15), controller, bipolar7(bipolar)], at + 0.1);
      for (const bytes of mpeExpressionMessages(channel, {slide, pressure}))
        this.sendMidi(bytes, at + 0.25);
      this.sendMidi([0xb0 + (channel & 15), 88, velocityPrefix], at + 0.4);
      this.sendMidi(on, at + 0.5, { expression: performance });
      this.sendMidi(off, offAt);
      this.sendMidi([0xd0 + (channel & 15), 0], restAt);
      this.sendMidi([0xb0 + (channel & 15), 74, 64], restAt + 0.25);
      for (const {controller} of articulation) this.sendMidi([0xb0 + (channel & 15), controller, 64], restAt + 0.25);
      this.sendMidi([0xe0 + (channel & 15), 0, 64], restAt + 0.5);
      // Browsers release eagerly with a timer. Max v8 has no browser timer
      // globals; its allocator safely releases expired channels on the next
      // acquire, using the releaseAt timestamp already stored above.
      if (typeof setTimeout === "function") {
        const timer=this.midiLater(()=>{this.midiTimers.delete(timer);this.mpeAllocator.release(channel,restAt+2);},
          Math.max(0, restAt-globalThis.performance.now()+2));
        this.midiTimers.add(timer);
      }
      this.onMidiSend?.({
        port: this.midiOutput.name,
        bytes: on,
        at,
        pitch: encoded.pitch,
        bend: encoded.bend,
        channel: channel + 1,
        mpe: true,
        expression: performance,
      });
      return;
    }
    channel = this.midiChannelOverride ?? this.defaultMidiChannel ?? channel;
    if (percussion) {
      const drumNote = Math.max(0, Math.min(127, Math.round(note))),
        status = 0x90 + (channel & 15),
        off = 0x80 + (channel & 15);
      this.sendMidi([0xb0 + (channel & 15), 88, velocityPrefix], at);
      this.sendMidi([status, drumNote, midiVelocity], at, {
        expression: performance,
      });
      this.sendMidi([off, drumNote, releaseVelocity], offAt);
      this.onMidiSend?.({
        port: this.midiOutput.name,
        bytes: [status, drumNote, midiVelocity],
        at,
        pitch: drumNote,
        bend: null,
        channel: channel + 1,
        mpe: false,
        expression: performance,
      });
      return;
    }
    const encoded = mpePitch(note, this.mpeBendRange),
      status = 0x90 + (channel & 15),
      off = 0x80 + (channel & 15);
    this.sendProgram(program, channel, at);
    const bendOf = this.midiTimeline(channel, encoded.note, note, at, plan, {perNotePressure: true});
    this.sendMidi(bendOf(start), at);
    this.sendMidi([0xb0 + (channel & 15), 74, normalizedMidi7(slide)], at + 0.25);
    this.sendMidi([0xa0 + (channel & 15), encoded.note, normalizedMidi7(pressure)], at + 0.25);
    this.sendMidi([0xb0 + (channel & 15), 88, velocityPrefix], at + 0.4);
    this.sendMidi([status, encoded.note, midiVelocity], at + 0.5, {
      expression: performance,
    });
    this.sendMidi([off, encoded.note, releaseVelocity], offAt);
    this.sendMidi([0xa0 + (channel & 15), encoded.note, 0], restAt);
    this.sendMidi([0xe0 + (channel & 15), 0, 64], restAt + 1);
    this.onMidiSend?.({
      port: this.midiOutput.name,
      bytes: [status, encoded.note, midiVelocity],
      at,
      pitch: encoded.pitch,
      bend: encoded.bend,
      channel: channel + 1,
      mpe: false,
      expression: performance,
    });
  }
  // `percussion` is {note, velocity, duration}: the drum this hit IS, for a sample that has no pitch of its own.
  //
  // A sampled hit is the same musical event as a synthesized one, so it is notated as the bot would have SENT it --
  // the drum's note on channel 10, which is what every one of these callers does in midi mode. The samples branch
  // used to play the hit and throw the note away, so a drum bot had MIDI in synth mode and none in samples mode:
  // the mode a bot that owns recordings now renders in by default. It is captured here rather than by the caller so
  // that it is notated when, and only when, the sample actually sounds -- after the buffer has resolved, unmuted,
  // in the current sample generation -- exactly as the pitched path beside it does. Unlike that path it neither
  // retunes the sample nor shapes it: a drum is not transposed to its own note number.
  sampleFile(file, rate = 1, gain = 0.7, offset = 0, duration = 0, musical = null, percussion = null) {
    if (this.muted || !file) return;
    const symbolic=scoreTimeFields(musical?.scoreTime?musical:percussion?.scoreTime?percussion:this);
    // The bank's trim to the built-in voice's loudness (shared/sample-levels.js, measured by scripts/sample-levels.mjs), so
    // a part on samples starts as loud as on the voice and a band's faders start it in balance.
    gain *= sampleTrim(this.sampleBank);
    const promise = this.buffers.get(`${this.sampleBank}/${file}`);
    const generation=this.sampleGeneration;
    if (!promise) return;
    // Its note's number, from the engine's one count of the notes it sounds (a synthesized voice's identity), returned so
    // that whatever logs the note names it as the engine does (the implementation dossier's A001).
    const noteId=this.nextDspIdentity++;
    // When the call asked for it, taken as it is made: the buffer resolves after the call returns, and the time is the
    // call's (a performance layer moves a call's notes while it runs: bots/lib/modules/performed-timing.js).
    const asked=this.eventStart(offset);
    promise.then((buffer) => {
      if(this.muted||!this.master||generation!==this.sampleGeneration)return;
      // The sound and its recorded note both start there.
      offset+=asked-this.eventStart(offset);
      // (A stroke of a note bowed in several: the note is told once, whole, by its first -- musical.captured, its pitch,
      // seconds and slide -- and its other strokes not at all.)
      const captured=musical?.captured;
      if(musical&&captured!==false){
        // (A slide its recording is played through, from musical.glideFrom over musical.glide seconds: the score's to write.)
        // (How it is played, where its player says -- a bowed string's arco or pizzicato -- and whether it is slurred to the
        // note before: the score's to write.)
        const told={...(musical.lag?{lag:musical.lag}:{}),...(Number.isFinite(musical.writtenTick)?{writtenTick:musical.writtenTick,...(musical.writtenTicks>0?{writtenTicks:musical.writtenTicks}:{})}:{}),...(musical.roll?{roll:musical.roll}:{}),...(musical.gliss?{gliss:musical.gliss}:{}),...(typeof musical.line==='string'?{line:musical.line}:{}),
          ...(typeof musical.technique==='string'?{technique:musical.technique}:{}),...(captured?.slurred===true||musical.slurred===true?{slurred:true}:{}),...(captured?.portato===true||musical.portato===true?{portato:true}:{}),...(captured?.phrased===true?{phrased:true}:{}),
          ...(captured?.glide?{glide:{...captured.glide}}:musical.glide>0&&Number.isFinite(musical.glideFrom)?{glide:{from:musical.glideFrom,seconds:musical.glide,kind:musical.glideKind??'into'}}:{}),
          ...(Array.isArray(captured?.breaths)&&captured.breaths.length?{breaths:[...captured.breaths]}:{}),...(captured?.breathAfter===true?{breathAfter:true}:{}),
          ...(writtenOf(captured?.written??musical.written)?{written:writtenOf(captured?.written??musical.written)}:{})};
        const toldPitch=Number.isFinite(captured?.pitch)?captured.pitch:musical.pitch,toldSeconds=Number(captured?.seconds)>0?captured.seconds:duration||buffer.duration/rate;
        const batch=this.captureUMP(toldPitch,toldSeconds,musical.velocity,offset,{},{},{...told,...symbolic});
        // (A note the format cannot carry declined there, said in its report (captureUMP): not sounded either, so the score
        // and the sound agree -- read as a batch, it had ended the render.)
        if(!batch)return;
        // (What it told, kept by its number: a note its player leaves early is ended there for the score, releaseSample.)
        if(captured)(this.sampleCaptures??=new Map).set(noteId,{note:toldPitch,startedAt:batch.startSeconds,ump:umpAddressOf(batch),...(typeof musical.line==='string'?{line:musical.line}:{})});
        const pitch=inspectUMP(batch.events.find(event=>inspectUMP(event.packet).kind==='noteOn').packet).pitch;
        rate*=2**((pitch-toldPitch)/12);
      }
      // A stroke on a recorded drum (percussion.tone: shared/percussion-expression.js) reshapes the recording, as a
      // sampler's per-pad controls do: its pitch by the playback rate, its level, its tone by a shelf above 3 kHz, the
      // crack of a rimshot as a lift in its first milliseconds, and a hand's damping as a fade within its ring.
      const tone=percussion?.tone??null;
      if(tone?.pitch)rate*=2**(tone.pitch/12);
      if(percussion&&!musical)this.captureUMP(percussion.note,percussion.duration??(duration||buffer.duration/rate),
        Math.max(0,Math.min(1,percussion.velocity)),offset,{},{fixedPercussion:true,channel:9,
          ...(tone?{brightness:strikeControllers(tone).brightness,pitch:tone.pitch?percussion.note+tone.pitch:null}:{})},symbolic);
      if(tone)gain*=10**((tone.levelDb+(Number.isFinite(tone.body)?.5*tone.body:0))/20);
      // (A note of an instrument whose sound power is measured: its recording's held level brought to that, whatever
      // the bank's trim and its layers' recorded levels -- samplePitch.)
      if(Number.isFinite(musical?.soundsAtDb))gain=10**((musical.soundsAtDb-heldLevelDb(buffer,this.sampleMetadata?.[file]))/20);
      const source = this.ctx.createBufferSource(),
        amp = this.ctx.createGain(),
        start = this.eventStart(offset);
      // A held stroke longer than its recording holds (musical.loop): its recording's measured middle looped, the loop's
      // end crossfaded into what leads to its start (loopedBuffer), so it sounds on with no seam until it is let go -- the
      // attack, the looped middle, then its release (the owner, 1 October 2026: "start with the attack, loop the middle
      // at zero crossings, then include a release"; "the acceptable amount of audible sampling seams is 0").
      const loop = musical?.loop ? loopOf(this.sampleMetadata?.[file], buffer) : null,
        wanted = musical?.loop && duration > 0 ? (duration + (musical?.release ?? 0)) * rate : 0;
      const looping = Boolean(loop) && wanted > buffer.duration - (Number(musical?.into) || 0);
      source.buffer = looping ? loopedBuffer(this.ctx, buffer, loop) : buffer;
      if (looping) { source.loop = true; source.loopStart = loop[0]; source.loopEnd = loop[1] }
      source.playbackRate.value = rate;
      // A bowed stroke begun past its recording's attack (musical.into, s, or 'attack': past this recording's own measured
      // attack): a change of bow or a note slurred to, not a note begun anew.
      const into = Math.max(0, Math.min(musical?.into === 'attack' ? Number(this.sampleMetadata?.[file]?.attack) || 0 : Number(musical?.into) || 0, buffer.duration / 2));
      // A note that slides into its pitch (musical.glideFrom, over musical.glide seconds): from that pitch's rate to its
      // own, evenly in pitch -- held at that pitch first for musical.glideAt seconds, where its glissando holds before it
      // slides (section-seat.js; the owner, 2 October 2026: "attack directly into glissandos").
      if (musical?.glide > 0 && Number.isFinite(musical.glideFrom)) {
        const from = rate * 2 ** ((musical.glideFrom - musical.pitch) / 12), hold = Math.max(0, Number(musical.glideAt) || 0);
        source.playbackRate.setValueAtTime(from, start);
        if (hold > 0) source.playbackRate.setValueAtTime(from, start + hold);
        source.playbackRate.exponentialRampToValueAtTime(rate, start + hold + musical.glide);
      }
      // A player's vibrato on a still recording (shared/performers/vibrato.js): its pitch moved along the curve given,
      // a factor each `step` seconds from the stroke's start.
      else if (musical?.vibrato?.curve?.length > 1 && typeof source.playbackRate.setValueCurveAtTime === 'function') {
        const {curve, step} = musical.vibrato, values = Float32Array.from(curve, factor => rate * factor);
        source.playbackRate.setValueCurveAtTime(values, start, Math.max(step, (values.length - 1) * step));
      }
      const adsr=musical&&this.sampleDesign?.adsr,
        available=looping?Infinity:(buffer.duration-into)/rate*(tone&&tone.decay<1?Math.max(RECORDED_STROKE.dampedShare,tone.decay):1),
        release=musical?.release??adsr?.[3]??(tone&&tone.decay<1?Math.min(RECORDED_STROKE.dampedFadeMost,available/3):.015),
        end=start+Math.min(available,duration>0?duration+release:available),
        attack=Math.min((musical?.attack??adsr?.[0]??.003)*(tone?.attack??1),(end-start)/4),
        decay=Math.min(adsr?.[1]??0,(end-start)/4),sustain=adsr?.[2]??1,
        releaseStart=Math.max(start+attack+decay,end-Math.min(release,(end-start)/4));
      amp.gain.setValueAtTime(0,start);amp.gain.linearRampToValueAtTime(gain,start+attack);
      // A rimshot's crack, and any stroke with more of the stick in it: its first milliseconds lifted.
      const crack=tone&&tone.noise>1&&!decay?Math.min(RECORDED_STROKE.crackMost,1+RECORDED_STROKE.crackPerNoise*(tone.noise-1)):1,
        crackEnd=Math.min(releaseStart,start+attack+RECORDED_STROKE.crackSeconds);
      if(crack>1&&crackEnd>start+attack){amp.gain.setValueAtTime(gain*crack,start+attack);amp.gain.linearRampToValueAtTime(gain,crackEnd)}
      amp.gain.linearRampToValueAtTime(gain*sustain,start+attack+decay);
      // A layered recording (a piano's string) sounds until its key is let go, then its damper stops it over its release:
      // an exponential fall, 60 dB down by the release's end, where the recording stops.
      // (Its level from its attack's end on, which a release begins from: releaseGraph.)
      let levelAt;
      const held=gain*sustain,heldFrom=Math.max(start+attack+decay,crack>1?crackEnd:0);
      if(musical?.layered){const keyUp=Math.max(start+attack+decay,Math.min(end,start+(duration>0?duration:available))),tau=Math.max(.005,(end-keyUp)/7);
        amp.gain.setValueAtTime(held,keyUp);if(end>keyUp)amp.gain.setTargetAtTime(0,keyUp,tau);
        levelAt=t=>t<heldFrom?null:t<=keyUp?held:t<end?held*Math.exp(-(t-keyUp)/tau):0}
      else{amp.gain.setValueAtTime(held,releaseStart);amp.gain.linearRampToValueAtTime(0,end);
        levelAt=t=>t<heldFrom?null:t<=releaseStart?held:t<end?held*(end-t)/(end-releaseStart):0}
      // A recording has one dynamic in it; a softer note of the same instrument is darker as well as
      // quieter. Velocity closes a gentle lowpass over the sample -- fully open at the top, about
      // two and a half octaves down at a pianissimo -- so a single recorded layer still answers to
      // how hard it was played. `test/sample-velocity.test.mjs` holds the direction and the range.
      const velocity=Math.max(0,Math.min(1,musical?.velocity??percussion?.velocity??1)),
        nodes=[source,amp];
      let head=source;
      if(velocity<.97&&!musical?.layered&&typeof this.ctx.createBiquadFilter==='function'){
        const lowpass=this.ctx.createBiquadFilter();
        lowpass.type='lowpass';lowpass.Q.value=.5;
        lowpass.frequency.value=Math.min(this.ctx.sampleRate*.45,sampleBrightnessHz(velocity));
        head=head.connect(lowpass);nodes.push(lowpass);
      }
      // The stroke's brightness as a shelf, as it brightens a synthesized voice's filter.
      if(tone?.brightness&&typeof this.ctx.createBiquadFilter==='function'){
        const shelf=this.ctx.createBiquadFilter(),[low,high]=RECORDED_STROKE.shelfDb;
        shelf.type='highshelf';shelf.frequency.value=RECORDED_STROKE.shelfHz;shelf.gain.value=Math.max(low,Math.min(high,RECORDED_STROKE.shelfDbPerOctave*tone.brightness));
        head=head.connect(shelf);nodes.push(shelf);
      }
      // A held stroke's phrase through it (section-seat.js dynamicsOf: its velocity every `step` s, in its family's law):
      // its recording's level moved along the curve from the velocity it was struck at, as a sampler's expression
      // control moves it (the owner, 5 October 2026: "Long notes are also not receiving the shaping that they should" --
      // a sampled wind's or string's held note had kept its attack's level to its end).
      const shape=musical?.dynamics,expression=shape&&typeof this.ctx.createGain==='function'?this.ctx.createGain():null;
      if(expression&&typeof expression.gain.setValueCurveAtTime==='function'){
        const values=expressionOf(shape,velocity);
        expression.gain.value=values[0];
        expression.gain.setValueCurveAtTime(values,start,Math.max(shape.step,(values.length-1)*shape.step));
        head=head.connect(expression);nodes.push(expression);
      }
      head.connect(amp);
      // A split kit's recording goes to its drum's channel (splitKit).
      amp.connect((percussion&&this.kitPart(pieceForNote(percussion.note))?.chain.master)??this.master);
      // (Named by its note's number, so that its player can let it go: releaseSample.)
      // (And its held level, which a release begins from: releaseGraph.)
      const graph=this.retainGraph(source,nodes);graph.sampleGain=amp;graph.identity=noteId;graph.amp=amp;graph.levelAt=levelAt;
      if(into>0)source.start(start,into);else source.start(start);
      source.stop(end+.001);
    });
    return noteId;
  }
  randomFile(pattern) {
    const choices = this.sampleFiles.filter((file) => pattern.test(file));
    return choices[Math.floor(randomAt(`${this.seed}:audio:sample`, this.sampleChoices++) * choices.length)];
  }
  // `articulation`: the way of playing a recording must be of, where a bank records more than one (a mallet's roll,
  // audio.js roll); a note without one plays the bank's plain recordings. `glide` (s) and `glideFrom` (a pitch): the
  // note slides into its pitch from that one, as the voice's do (a timpano's pedal moved while it rings). `lag` (s): how
  // much of `offset` is the note sounding after its written time (a hammer's travel), as the voice's expression.lag;
  // `roll` (s): how much of it is its chord's roll, as the voice's expression.roll; `gliss`: the glissando it is a string
  // of, as the voice's expression.gliss; `line`: the line it belongs to (a section's seat), as the voice's expression.line.
  samplePitch(note, offset = 0, gain = 0.65, duration = 0, velocity = null, { articulation = null, glide = null, glideKind = 'into', glideFrom = null, glideAt = 0, lag = 0, roll = 0, gliss = null, line = null, stroke = null, take = null, technique = null, slurred = false, portato = false, extended = null, multiphonic = null, instrument = null } = {}) {
    const nominalNote = note;
    note = this.tunePitch(note);
    this.report("rendered_pitch", {
      nominalNote,
      note,
      deviationCents: (note - nominalNote) * 100,
      duration,
    });
    // The velocity the note was played at, when the caller knows it; the level otherwise, which
    // is what this path always passed, and which reads as a velocity well enough to shade by.
    const played = Math.max(0, Math.min(1, velocity ?? gain));
    const sliding = Number(glide) > 0 && Number.isFinite(Number(glideFrom)) && Math.abs(Number(glideFrom) - nominalNote) >= 0.05
      ? {glide: Number(glide), glideKind, glideFrom: this.tunePitch(Number(glideFrom)), ...(Number(glideAt) > 0 ? {glideAt: Number(glideAt)} : {})} : {}, lagged = {...(Number(lag) ? {lag: Number(lag)} : {}), ...(Number(roll) ? {roll: Number(roll)} : {}), ...(gliss && typeof gliss === 'object' ? {gliss: {...gliss}} : {}),
        ...(typeof line === 'string' ? {line} : {}), ...(typeof technique === 'string' ? {technique} : {}), ...(slurred === true ? {slurred: true} : {}), ...(portato === true ? {portato: true} : {}),
        // (A technique its player chose, told to the score though the recording plays the note ordinarily: windNote.)
        ...(extended && typeof extended === 'object' ? {extended: {...extended}} : {}), ...(multiphonic && typeof multiphonic === 'object' ? {multiphonic: {...multiphonic}} : {})},
      // (A bowed stroke's own: past its recording's attack, its fades, a still recording's vibrato: bowedString.)
      stroked = stroke && typeof stroke === 'object' ? {...(stroke.into === 'attack' ? {into: 'attack'} : Number(stroke.into) > 0 ? {into: Number(stroke.into)} : {}), ...(Number(stroke.attack) > 0 ? {attack: Number(stroke.attack)} : {}),
        ...(Number(stroke.release) > 0 ? {release: Number(stroke.release)} : {}), ...(stroke.vibrato?.curve && this.sampleDesign?.still ? {vibrato: stroke.vibrato} : {}),
        ...(stroke.dynamics?.curve?.length > 1 && Number(stroke.dynamics.step) > 0 ? {dynamics: stroke.dynamics} : {}),
        ...(stroke.loop && this.sampleDesign?.still ? {loop: true} : {}),
        ...(stroke.captured === false || stroke.captured && typeof stroke.captured === 'object' ? {captured: stroke.captured} : {})} : {};
    // Bank files and metadata are owned by useSamples. Also detect replaced
    // arrays/records in legacy callers; in-place edits require useSamples.
    if(!this._samplePitchCandidates||this._samplePitchFiles!==this.sampleFiles||this._samplePitchMetadata!==this.sampleMetadata){
      this._samplePitchFiles=this.sampleFiles;this._samplePitchMetadata=this.sampleMetadata;
      this._samplePitchCandidates = this.sampleFiles
      .map((file) => {
        const entry=this.sampleMetadata?.[file],rootNote=entry?.rootNote;
        // A layered bank's file: its velocities, its attack's level and its string's release (shared/sample-layers.js).
        const played={...(typeof entry?.articulation==='string'?{articulation:entry.articulation}:{}),...(Number.isInteger(entry?.robin)?{robin:entry.robin}:{})};
        if(Number.isFinite(rootNote))return Array.isArray(entry.velocity)
          ?{file,midi:rootNote,layer:entry.layer,velocity:entry.velocity,levelDb:entry.levelDb,...(Number.isFinite(entry.release)?{release:entry.release}:{}),...played}
          :{file,midi:rootNote,...played};
        const match = file.match(/(?:^|[\s_-])([A-G](?:b|#)?)(-?\d)(?=\.|\s)/i);
        if (!match) return null;
        const name = match[1][0].toUpperCase() + match[1].slice(1),
          midi = (Number(match[2]) + 1) * 12 + noteNames[name];
        return { file, midi };
      })
      .filter(Boolean);
    }
    // (An instrument whose sound power is measured -- a seat's violin, oboe, horn -- at that level, the recording's own
    // held level taken out: sampleFile soundsAtDb. Its layer, chosen by its velocity, is its timbre alone. Its sessions'
    // levels had stood its recorded flute 33 dB under its model, its oboe 9 dB: shared/performers/sound-power.js.)
    const soundsAt = typeof instrument === "string" ? stemLevelDb(instrument, played, nominalNote) : null;
    if (soundsAt !== null) lagged.soundsAtDb = soundsAt;
    // (The recordings of the articulation asked for: a plain note never a roll's; one the bank lacks, its plain ones.)
    const all=this._samplePitchCandidates,asked=all.filter(candidate=>(candidate.articulation??null)===articulation),
      candidates=asked.length?asked:all.filter(candidate=>!candidate.articulation);
    if (!candidates.length){this.sampleFile(this.sampleFiles[0],2**((note-60)/12),gain,offset,duration,{pitch:note,velocity:played,...lagged});return}
    // A layered bank (a sampled piano): the layer its velocity chooses, at the loudness its layers measure there.
    if (this.sampleDesign?.layered) {
      // (Its round robins taken in turn, a turn a note at its root and layer, as the source's seq_position cycles them.)
      const turns = this.sampleTurns ??= new Map();
      // (Or the take a player keeps to, where its caller names one: a seat's own string among a pitch's.)
      const choice = layeredChoice(candidates, note, played, {turn: Number.isInteger(take) ? () => take : key => {const n = turns.get(key) ?? 0; turns.set(key, n + 1); return n;}});
      if (choice) {
        return this.sampleFile(choice.file, 2 ** ((note - choice.midi) / 12), gain * 10 ** (choice.gainDb / 20), offset, duration,
          {pitch: note, velocity: played, layered: true, ...(choice.release !== undefined ? {release: choice.release} : {}), ...sliding, ...lagged, ...stroked});
      }
    }
    const nearest = candidates.reduce((a, b) =>
      Math.abs(b.midi - note) < Math.abs(a.midi - note) ? b : a,
    );
    return this.sampleFile(
      nearest.file,
      2 ** ((note - nearest.midi) / 12),
      gain,
      offset,
      duration,
      {pitch:note,velocity:played,...sliding,...lagged,...stroked},
    );
  }
  // A sampled note let go at `atSeconds` (the audio clock's), faded over `seconds`: a seat's stroke ended where its part
  // moves on (section-seat.js); `note`, the number of the stroke that told the score its note, ended there too (the
  // transcript hears it: capture.js). -> {sounding, released: {note, startedAt, endsAt, release, line} | null}.
  // (`breath`: its player let it go to breathe -- a wind's catch breath, wind-seat.js: the score marks it, capture.js.)
  releaseSample(identity,{atSeconds,seconds=.05,note=null,breath=false}={}){
    if(this.physical)return this.physicalRelease(identity,{atSeconds,seconds,note,breath});
    const at=Math.max(this.clockTime(),atSeconds??this.clockTime()),sounding=[...this.activeGraphs].some(graph=>graph.identity===identity&&graph.amp);
    if(sounding)this.releaseGraph(identity,at,seconds);
    const {ump,...told}=(note!=null?this.sampleCaptures?.get(note):null)??{};
    if(ump!==undefined){this.sampleCaptures.delete(note);this.captureRelease(ump,at)}
    return {sounding,released:ump!==undefined?{...told,endsAt:at+seconds,release:seconds,...(breath?{breath:true}:{})}:null};
  }
  // A synth that takes a bowed string's notes as MIDI 2.0 (capabilities.bowedMidi2: the strings' model live,
  // synths/strings-bridge.js): its bowed strokes played as notes to it ('live'), as a render's are kept for the model;
  // another synth, none.
  followSynth(){
    const bowed=Boolean(this.dspNode?.capabilities?.bowedMidi2);
    if(bowed&&this.physical?.mode!=='live')this.physical={mode:'live',log:[],node:this.dspNode};
    else if(!bowed&&this.physical?.mode==='live')this.physical=null;
  }
  // What its synthesizer can play on a bowed instrument, its `variant` of it (a Performer knows its synth's constraints:
  // docs/MUSEBOTS_3_SPECIFICATION.md): as the synth declares (its `limits`: the live strings synth's, public/synths/strings-
  // bridge.js), or the strings model's where a render plays its strings on it, else the instrument registry's alone
  // (bowed-line.js bowedLimits).
  instrumentLimits(instrument,variant=0){
    const declared=this.physical?.limits??this.dspNode?.node?.limits;
    return declared?declared(instrument,variant):this.physical?stringsModelLimits(instrument,variant):bowedLimits(instrument);
  }
  // A bowed stroke on a physical model (this.physical: {mode 'plan' or 'play', log, buffer}, the render's:
  // render/node/physical-strings.mjs; or 'live', its synth the page's strings synth, `node`). Its stroke logged, and
  // played as MIDI 2.0 (bowedNote) -- its note as any strings synth takes it, which the model's compiler reads back
  // (shared/performers/bowed-midi2.js, physical-strings.js compileActions); the note told to the score as a recording's is
  // (sampleFile); in 'play', the model's audio of the whole part, made from the plan's notes, begins with the bot's first
  // stroke and plays to its end. -> the stroke's number.
  physicalStroke(note, duration, velocity, offset, options = {}) {
    const physical = this.physical, id = this.nextDspIdentity++, at = this.eventStart(offset), stroke = options.stroke ?? null, point = articulationOfStroke(stroke);
    const glide = Number(options.glide) > 0 && Number.isFinite(Number(options.glideFrom)) ? {glide: Number(options.glide), glideFrom: Number(options.glideFrom), ...(Number(options.glideAt) > 0 ? {glideAt: Number(options.glideAt)} : {})} : {};
    physical.log.push({id, at: +at.toFixed(6), note, seconds: duration, velocity, ...(options.plucked ? {articulation: 'pizzicato'} : {}),
      ...(options.harmonic ? {harmonic: {...options.harmonic}} : {}), ...(!options.plucked && options.multiphonic ? {multiphonic: {index: options.multiphonic.index}} : {}),
      ...(!options.plucked && Number(options.contact) ? {contact: Math.max(-1, Math.min(1, Number(options.contact)))} : {}),
      ...(!options.plucked && pressureOf(options.bowPressure) ? {bowPressure: pressureOf(options.bowPressure)} : {}),
      ...(stroke ? {stroke: {...(stroke.into != null ? {into: stroke.into} : {}), ...(Number(stroke.attack) > 0 ? {attack: Number(stroke.attack)} : {}),
        ...(stroke.captured === false ? {captured: false} : {}), ...(stroke.change === true ? {change: true} : {}), ...(stroke.tremolo === true ? {tremolo: true} : {}),
        // (Its bow left stopped on the string so long at its end, damping it: physical-strings.js MODEL.lifted.)
        ...(Number(stroke.rest) > 0 ? {rest: Number(stroke.rest)} : {}),
        // (Its bite: its bow set on the string and stopped so long before it is drawn -- a change of bow's, its player's
        // (section-seat.js STROKE), with its articulation's grip -- and its articulation's point: bowed-articulation.js.)
        ...(Number(stroke.bite) > 0 ? {bite: Number(stroke.bite)} : {}),
        ...(point ? {weight: point.weight, noise: point.noise, decay: point.decay} : {}),
        ...(stroke.vibrato?.curve ? {vibrato: {curve: Array.from(stroke.vibrato.curve), step: stroke.vibrato.step}} : {}),
        // (Its phrase's curve through it: section-seat.js levelAt.)
        ...(stroke.dynamics?.curve ? {dynamics: {curve: Array.from(stroke.dynamics.curve, velocity => +velocity.toFixed(4)), step: stroke.dynamics.step}} : {})}} : {}),
      ...glide});
    // (Live, its synth told its instrument, and which of the model's -- its seat's chair -- as a program is: once.)
    if (physical.mode === 'live') physical.node?.configure?.({instrument: options.instrument ?? 'violin', variant: Number(String(options.line ?? '').split('.')[1]) || 0, seat: typeof options.line === 'string' ? options.line : null});
    bowedNote(physical,physical.log.at(-1),this);
    if (physical.mode === 'play' && !physical.started && physical.buffer && this.ctx && this.master) {
      physical.started = true;
      // (Its audio is the part's from time 0, as its log's times are: begun now, from now into it.)
      const source = this.ctx.createBufferSource(), now = this.ctx.currentTime;source.buffer = physical.buffer;source.connect(this.master);source.start(now, now);
    }
    // (Told to the score once a note, by its first stroke, as sampleFile tells a recording's.)
    const captured = stroke?.captured;
    if (captured !== false) {
      // (Its lag -- its player's own milliseconds and its part's rubato -- how it sounded, not its written time.)
      const told = {...(typeof options.line === 'string' ? {line: options.line} : {}), technique: options.plucked ? 'pizzicato' : options.technique === 'tremolo' ? 'tremolo' : 'arco',
        ...(!options.plucked && Number(options.contact) ? {contact: +Math.max(-1, Math.min(1, Number(options.contact))).toFixed(3)} : {}),
        ...(!options.plucked && pressureOf(options.bowPressure) ? {bowPressure: +pressureOf(options.bowPressure).toFixed(3)} : {}),
        ...(options.harmonic ? {harmonic: {...options.harmonic}} : {}),
        ...(!options.plucked && options.multiphonic ? {multiphonic: {...options.multiphonic, pitches: [...options.multiphonic.pitches]}} : {}),
        ...(Number(options.lag) ? {lag: Number(options.lag)} : {}), ...(Number.isFinite(options.writtenTick) ? {writtenTick: options.writtenTick, ...(options.writtenTicks > 0 ? {writtenTicks: options.writtenTicks} : {})} : {}),
        ...(captured?.slurred === true || options.slurred === true ? {slurred: true} : {}),
        ...(writtenOf(captured?.written ?? options.written) ? {written: writtenOf(captured?.written ?? options.written)} : {}),
        ...(captured?.glide ? {glide: {...captured.glide}} : glide.glide ? {glide: {from: glide.glideFrom, seconds: glide.glide,kind:options.glideKind??'into'}} : {})};
      const toldPitch = Number.isFinite(captured?.pitch) ? captured.pitch : note, toldSeconds = Number(captured?.seconds) > 0 ? captured.seconds : duration;
      const batch = this.captureUMP(toldPitch, toldSeconds, velocity, offset, {}, {}, Object.keys(told).length ? told : null);
      if (captured) (this.sampleCaptures ??= new Map()).set(id, {note: toldPitch, startedAt: batch.startSeconds, ump: umpAddressOf(batch), ...(told.line ? {line: told.line} : {})});
    }
    return id;
  }
  physicalRelease(identity, {atSeconds, seconds = .05, note = null, breath = false} = {}) {
    const at = Math.max(this.clockTime(), atSeconds ?? this.clockTime()), entry = this.physical.log.findLast?.(each => each.id === identity);
    if (entry) {entry.released = +at.toFixed(6);bowedRelease(this.physical, entry, entry.released, this)}
    const {ump, ...told} = (note != null ? this.sampleCaptures?.get(note) : null) ?? {};
    if (ump !== undefined) {this.sampleCaptures.delete(note);this.captureRelease(ump, at)}
    return {sounding: Boolean(entry), released: ump !== undefined ? {...told, endsAt: at + seconds, release: seconds, ...(breath ? {breath: true} : {})} : null};
  }
  // The ways of playing the loaded bank records beyond its plain one (its entries' `articulation`: a mallet's roll).
  sampleArticulations() {
    const metadata = this.sampleMetadata ?? {};
    return new Set((this.sampleFiles ?? []).map((file) => metadata[file]?.articulation).filter((value) => typeof value === "string"));
  }
  // A sampled note's level: the sample's own at the pivot velocity, and the instrument's range
  // around it. A recording has one dynamic; this, and the brightness sampleFile adds, are what
  // give it the others.
  sampleLevel(level, velocity, family) {
    this.countFamily(family);
    return level * familyVelocityGain(velocity, FAMILIES[family]?.rangeDb ?? 24, FAMILIES[family]?.velocityExponent ?? 2);
  }
  pitched(note, duration, gain, type, profile = "neutral", velocity = null, family = null, expression = null, offset = 0) {
    const musicalVelocity = Math.max(
      0,
      Math.min(1, velocity ?? Math.sqrt(Math.max(0, gain) / 0.16)),
    );
    this.report("pitched", {
      note,
      duration,
      gain,
      velocity: musicalVelocity,
      profile,
      offset,
    });
    const instrument = family || familyFor(null, profile);
    if (this.mode === "midi")
      this.midiNote(note, duration, musicalVelocity, undefined, offset, {profile,instrument,...(expression||{})});
    else if (this.mode === "samples")
      this.samplePitch(note, offset, this.sampleDesign?.layered ? (this.countFamily(instrument), 0.565) : this.sampleLevel(0.565, musicalVelocity, instrument), duration, musicalVelocity,expression??{});
    else
      this.voice(note, duration, gain, type, offset, {
        instrument,
        profile,
        velocity: musicalVelocity,
        ...(expression || {}),
      });
  }
  // The acid line: one resonant saw, its filter opened by `filterValue` (0..127, as the source
  // bot's knob), an accent opening it further and closing it faster, a sub for weight, and a
  // slide that carries the pitch into the next note when the two are tied.
  expressiveAcidBass(note, duration, velocity, filterValue) {
    const filter = Math.max(0.05, Math.min(1, Number(filterValue) / 127)),
      accent = Math.max(0, Math.min(1, (velocity - 0.55) / 0.4)),
      expression = {
        instrument: "acid",
        velocity,
        filter,
        accent,
        pressure: 0.3 + 0.55 * Math.max(0, Math.min(1, velocity)),
        pitchCurve: [0, 0.012, -0.008, 0],
        vibratoDepth: 0,
        shape: {subLevel: 0.22},
      };
    if (this.mode === "midi") {
      this.midiNote(note, duration, velocity, 0, 0, expression);
      return;
    }
    this.voice(note, duration, 0.06, "sawtooth", 0, expression);
  }
  acidBass(...args) {
    return this.expressiveAcidBass(...args);
  }
  // `strike` (shared/percussion-expression.js) is the stroke beyond its velocity, for whichever mode plays it: MIDI sends
  // the stroke's own note, a recording is reshaped by it (sampleFile), and `synth` is expected to pass it to drum().
  // With a strike, a hat plays the bank's open hat's recording when opened half way or more and its closed hat's when
  // less, where the bank names them (without one, the pattern's choice is as it always was, open and ride files
  // included).
  // Whether this bot may sound a kick `offset` seconds after its tick: not when another bot's kick is scheduled for the
  // same moment on this context (the user's policy, shared/performers/ensemble-kicks.js). A yielded kick is reported.
  mayKick(offset = 0) {
    const at = this.eventStart(offset), allowed = claimKick(this.ctx, at, this);
    if (!allowed) this.report("kickYielded", { at: Math.round(at * 1000) / 1000 });
    return allowed;
  }
  percussion(note, pattern, synth, velocity = 0.75, duration = 0.1, strike = null, offset = 0) {
    offset = Math.max(0, Number(offset) || 0);
    if (pieceForNote(note) === "kick" && !this.mayKick(offset)) return;
    velocity = Math.max(0, Math.min(1, velocity));
    const piece = pieceForNote(note), given = normalizeStrike(piece, strike),
      tone = given ? strikeTone(piece, given, {note, openness: piece === 'hat' ? (note === 46 ? 1 : 0) : null}) : null,
      played = tone?.note ?? note;
    this.report("percussion", { note: played, velocity, duration, ...(tone ? {stroke: tone.stroke} : {}) });
    if (this.mode === "midi")
      this.midiNote(played, duration, velocity, 9, offset, { profile: "pluck" });
    else if (this.mode === "samples") {
      // A recorded drum is struck at its performed velocity, as the synthesized kit's and a MIDI drum's are (drum(),
      // midiNote()): the meter's accents, a long bar's section dynamics and the channel's place in the mix. It had been
      // struck at the pattern's own, and every sampled drum part played a sectioned bar's sections alike (RESEARCH_BACKLOG
      // P1, "Extreme meters, made perceptible": in 61/4 its loud section's strokes were 0.99 of its soft one's).
      const performed = this.performanceVelocity(velocity),
        kind = Number.isFinite(tone?.openness) ? (tone.openness >= .5 ? 'open' : 'closed') : null,
        named = kind ? new RegExp(`(?=.*${kind})(?:${pattern.source})`, 'i') : null,
        file = this.randomFile(named && this.sampleFiles.some(file => named.test(file)) ? named : pattern),
        // Tuned to a note: from the recording's own pitch, as measured (shared/drum-pitches.js).
        sounding = given?.tuneTo ? DRUM_PITCHES.banks[`${this.sampleBank}/${file}`]?.pitch : null,
        struck = Number.isFinite(sounding) ? strikeTone(piece, given, {note, openness: piece === 'hat' ? (note === 46 ? 1 : 0) : null, sounding}) : tone;
      this.sampleFile(
        file,
        1,
        // A struck recording's level on its drum's own velocity curve (its family's range, pivoted where bots play:
        // articulation.js), as the synthesized kit's; without a strike, the recordings' old span of about 5 dB.
        struck ? RECORDED_PIVOT_GAIN * familyVelocityGain(performed, FAMILIES[RECORDED_FAMILIES[piece] ?? 'shaker'].rangeDb, FAMILIES[RECORDED_FAMILIES[piece] ?? 'shaker'].velocityExponent ?? 2)
          : 0.28 + 0.5 * performed,
        offset,
        // A hat's opening sets how much of its ring is heard, from the closed hat's length to the open hat's.
        Number.isFinite(struck?.openness) ? duration * RECORDED_STROKE.hatRing ** (struck.openness - (note === 46 ? 1 : 0)) : duration,
        null,
        { note: played, velocity: performed, duration, ...(struck ? {tone: struck} : {}) },
      );
    }
    else synth(offset);
  }
  // Each level is the voice's at the pivot velocity; the family's range does the rest. (They were
  // `0.16 * a` and so on, which with a family's curve on top would count velocity twice.) The
  // levels are set against the voices they replace, by rendering both: see docs/TIMBRE_AND_MIX.md.
  // `expression` (optional, any call below): what a bot asks of this note beyond its pitch, length and velocity -- a glide
  // into it, a vibrato, a pressure or slide (timbre) curve (shared/expression.js) -- laid over the call's own.
  bass(n, a, duration = 0.24, expression = null) {
    this.pitched(n, duration, 0.129, "triangle", "bass", a, "bass", expression);
  }
  eBass(n, a, duration = 0.3, expression = null) {
    this.pitched(n, duration, 0.137, "sawtooth", "bass", a, "bass", expression);
  }
  snapBass(n, a, duration = 0.12, expression = null) {
    this.pitched(n, duration, 0.16, "square", "bass", a, "synthBass", expression);
  }
  synthBass(n, a, duration = 0.22, expression = null) {
    this.pitched(n, duration, 0.12, "sawtooth", "bass", a, "synthBass", expression);
  }
  sequencerNote(note, duration = 0.2, velocity = 0.65, asked = null) {
    this.report("sequencerNote", { note, duration, velocity });
    const expression = { profile: "pluck", instrument: "synthPluck", velocity, ...(asked || {}) };
    if (this.mode === "midi") {
      this.midiNote(note, duration, velocity, undefined, 0, expression);
      return;
    }
    this.voice(note, duration, 0.0565, "sawtooth", 0, expression);
    // Its octave, a line of its own: it glides as the note does, from its own last note.
    this.voice(note + 12, duration * 0.7, 0.0136, "square", 0.006, {...expression, line: "octave"});
  }
  xSequencerNote(
    note,
    duration = 0.2,
    velocity = 0.65,
    progress = 0,
    preset = 0,
  ) {
    this.report("xSequencerNote", {
      note,
      duration,
      velocity,
      progress,
      preset,
    });
    const brightness = 0.2 + 0.8 * Math.max(0, Math.min(1, progress)),
      expression = {
        profile: "pluck",
        instrument: "synthPluck",
        velocity,
        slide: 0.22 + 0.5 * brightness,
      };
    if (this.mode === "midi") {
      this.midiNote(note, duration, velocity, undefined, 0, expression);
      return;
    }
    this.voice(note, duration, 0.046 * brightness, "sawtooth", 0, expression);
    this.voice(note + 12, duration * 0.7, 0.0113 * brightness, "square", 0.006, expression);
  }
  papMelody(note, duration = 0.2, velocity = 0.65, offset = 0) {
    this.report("papMelody", { note, duration, velocity, offset });
    const expression = { profile: "lead", instrument: "lead", velocity };
    if (this.mode === "midi") {
      this.midiNote(note, duration, velocity, undefined, offset, expression);
      return;
    }
    this.voice(note, duration, 0.039, "triangle", offset, expression);
    this.voice(note + 12, duration * 0.6, 0.0101, "sine", offset + 0.004, expression);
  }
  // A struck note rolled: a mallet player's roll, where the bar would die before the note ends (mallets_clodbot). One
  // note, struck again at each of `strokes` (seconds from `offset`, its first stroke's the first), each later stroke
  // ringing `ring` at `later` of the first's velocity. Called as one event, the note is its first stroke, held to its
  // end, and the strokes after are its realization: a transcript counts one note (transcript/capture.js), and a score
  // prints one note where a roll is played.
  // On samples whose bank records rolls (a marimba's, a xylophone's), the roll is its recording, from the first stroke.
  roll(note, duration, gain, type = "sine", offset = 0, expression = {}, { strokes = [0], ring = duration, later = 0.8 } = {}) {
    this.report("roll", { note, duration, velocity: expression.velocity, offset, strokes: strokes.length });
    const velocity = Number.isFinite(Number(expression.velocity)) ? Number(expression.velocity) : 0.7;
    if (this.mode === "samples" && this.sampleArticulations().has("roll")) {
      // (A layered bank's layers are its dynamics, the velocity choosing one, as its strokes' are: its level is not also
      // scaled by the velocity, as a single recording's is.)
      const family = expression.instrument ?? "bell", level = this.sampleDesign?.layered ? (this.countFamily(family), 0.565) : this.sampleLevel(0.565, velocity, family);
      this.samplePitch(note, offset + strokes[0], level, duration - strokes[0], velocity, { articulation: "roll", technique: "tremolo" });
      return;
    }
    strokes.forEach((at, k) => {
      const length = k ? Math.min(ring, duration - at) : duration - at;
      const struck = {...expression, technique: 'tremolo', ...(k ? {velocity: velocity * later, captured: false} : {})};
      if (!(length > 0)) return;
      if (this.mode === "midi") this.midiNote(note, length, struck.velocity, undefined, offset + at, struck);
      else if (this.mode === "samples") this.samplePitch(note, offset + at, this.sampleLevel(0.565, struck.velocity, struck.instrument ?? "bell"), length, struck.velocity,
        {technique: 'tremolo', stroke: {captured: k ? false : {pitch: note, seconds: duration - at}}});
      else this.voice(note, length, gain, type, offset + at, struck);
    });
  }
  // PAP_LaverneBOT's presets carry the synth's own envelope and filter -- attack, decay and
  // release in milliseconds, sustain in percent, a resonant lowpass -- which the port had kept in
  // its config and never played. They are played now, through the shaped voice.
  laverne(
    note,
    duration = 0.2,
    velocity = 0.866142,
    offset = 0,
    preset = {},
    presetIndex = 0,
  ) {
    this.report("laverne", {
      note,
      duration,
      velocity,
      offset,
      preset: presetIndex,
    });
    const shape = {
      attack: Math.max(0.0005, (preset.attack ?? 8) / 1000),
      // adsr~ reaches its sustain in a straight line; the exponential here passes the same point
      // at about an eighth of its excess, which is where the ear hears a decay finish.
      decay: Math.max(0.01, (preset.decay ?? 100) / 1000) * 3,
      sustain: Math.max(0, Math.min(1, (preset.sustain ?? 100) / 100)),
      release: Math.max(0.01, (preset.release ?? 150) / 1000) * 1.2,
      filterMode: 1, cutoff: preset.cutoff ?? 2000, keytrack: 0,
      resonance: Math.max(0, Math.min(1, (preset.resonance ?? 0.3) * 0.8)),
      filterEnv: 0, velocityCutoff: 0.5,
    };
    const expression = {instrument: "lead", velocity, shape, vibratoDepth: 0};
    if (this.mode === "midi") {
      this.midiNote(note, duration, velocity, undefined, offset, expression);
      return;
    }
    const types = ["sine", "sawtooth", "triangle", "square"];
    for (const [index, osc] of (preset.oscillators || []).entries()) {
      const pitch = note + 12 * (osc.octave || 0) + (osc.tune || 0) / 100,
        gain = (0.0302 * (osc.level ?? 100)) / 100;
      if (pitch > PITCH_CEILING) continue;
      this.voice(
        pitch,
        duration,
        gain,
        types[osc.waveform] || "sine",
        offset + index * 0.003,
        expression,
      );
    }
  }
  resynth(note, duration = 0.5, velocity = 0.65, model = {}, modelIndex = 0) {
    this.report("resynth", { note, duration, velocity, model: modelIndex });
    if (this.mode === "midi") {
      this.midiNote(note, duration, velocity, undefined, 0, {instrument: "partials"});
      return;
    }
    const ratios = model.ratios || [1, 2, 3],
      gains = model.gains || [1, 0.3, 0.15];
    if (this.dspNode) {
      this.voice(note, duration, 0.025, "sine", 0, {instrument: "partials", velocity, model: MODEL.additive, ratios, gains});
      return;
    }
    for (let index = 0; index < ratios.length; index++)
      this.voice(
        note + 12 * Math.log2(Math.max(0.01, ratios[index])),
        duration,
        0.0126 * (gains[index] ?? 0.1),
        "sine",
        index * 0.0015,
        {instrument: "partials", velocity},
      );
  }
  vinylTexture(duration = 8, config = {}) {
    this.report("vinylTexture", { duration });
    if (!this.ctx || this.muted) return;
    this.noise(duration, config.bedGain ?? 0.022, config.bedBandHz ?? 4200);
    this.noise(
      duration,
      config.rumbleGain ?? 0.018,
      config.rumbleBandHz ?? 72,
      0.01,
    );
    const count = Math.max(
      1,
      Math.round(duration * 12 * (config.crackleDensity ?? 0.035)),
    );
    for (let index = 0; index < count; index++)
      this.noise(
        0.004 + random() * 0.018,
        (config.crackleGain ?? 0.014) * (0.3 + random() * 0.7),
        config.crackleBandHz ?? 7800,
        random() * Math.max(0, duration - 0.03),
      );
  }
  filterSweep(duration = 0.2, config = {}) {
    this.report("filterSweep", { duration });
    if (!this.ctx || this.muted) return;
    // The sweep's own filter moves inside the voice (model 8); the shape gives it the rise to its
    // middle and the fall after it that the Web Audio version has always had.
    const plan=this.dspNode&&this.master?this.planNote(69,duration,{instrument:'noise',velocity:Math.min(1,config.amplitude??.7),
      shape:{filterMode:4,attack:duration*.45,attackCurve:0,decay:0,sustain:1,release:Math.min(.08,duration*.1)}}):null;
    if(this.scheduleDsp(8,69,duration,(config.amplitude??.7)*.12,0,config.frequencyEnvelope?.[0]??100,config.frequencyEnvelope?.[1]??18000,plan?{plan}:{}))return;
    const now = this.eventStart(),
      length = Math.max(1, Math.ceil(this.ctx.sampleRate * (duration + 0.03))),
      buffer = this.ctx.createBuffer(1, length, this.ctx.sampleRate),
      data = buffer.getChannelData(0);
    for (let index = 0; index < length; index++) data[index] = random() * 2 - 1;
    const source = this.ctx.createBufferSource(),
      filter = this.ctx.createBiquadFilter(),
      amp = this.ctx.createGain(),
      [start, peak, end] = config.frequencyEnvelope || [100, 18000, 100],
      half = now + duration / 2;
    source.buffer = buffer;
    filter.type = "bandpass";
    filter.Q.value = Math.max(0.1, (config.resonance ?? 0.7) * 20);
    filter.frequency.setValueAtTime(start, now);
    filter.frequency.exponentialRampToValueAtTime(
      Math.min(this.ctx.sampleRate * 0.45, peak),
      half,
    );
    filter.frequency.exponentialRampToValueAtTime(end, now + duration);
    amp.gain.setValueAtTime(0.0001, now);
    amp.gain.linearRampToValueAtTime((config.amplitude ?? 0.7) * 0.12, half);
    amp.gain.linearRampToValueAtTime(0.0001, now + duration);
    source.connect(filter).connect(amp).connect(this.master);
    source.start(now);
    source.stop(now + duration + 0.03);
  }
  fmTexture(note, duration = 0.8, velocity = 0.65, timbre = {}) {
    this.report("fmTexture", { note, duration, velocity, timbre });
    const carrierRatio = Math.max(0.125, Number(timbre.carrierRatio) || 1),
      modulatorRatio = Math.max(0.125, Number(timbre.modulatorRatio) || 1),
      index = Math.max(0, Number(timbre.index) || 1),
      movement = Math.max(0, Math.min(1, Number(timbre.amDepth) || 0)),
      carrier = note + 12 * Math.log2(carrierRatio),
      expression = {
        instrument: "fmTexture",
        velocity,
        pressure: 0.25 + 0.55 * velocity,
        slide: 0.3 + 0.45 / (1 + index),
        slideCurve: [
          0.28 + 0.3 * velocity,
          0.38 + 0.3 * movement,
          0.22 + 0.18 * velocity,
        ],
        pitchCurve: [0, 0.012 * movement, -0.008 * movement, 0],
        vibratoDepth: 0.025 + 0.12 * movement,
        vibratoRate: 3.8 + 1.7 * movement,
      };
    if (this.mode === "midi") {
      this.midiNote(carrier, duration, velocity, undefined, 0, expression);
      return;
    }
    if (this.dspNode) {
      this.voice(carrier, duration, 0.044, "sine", 0, {...expression, model: MODEL.fm, paramA: modulatorRatio, paramB: index});
      return;
    }
    this.voice(carrier, duration, 0.0364, "sine", 0, expression);
    const sidebandGain = (0.002 + 0.006 * velocity) * Math.min(1, index / 4);
    if (sidebandGain > 0) {
      const interval = 12 * Math.log2(modulatorRatio);
      this.voice(carrier + interval, duration * 0.92, sidebandGain, "sine", 0.004,
        {...expression, instrument: undefined, pressure: 0.2 + 0.32 * velocity, slide: Math.max(0.12, expression.slide - 0.12)});
      this.voice(carrier - interval, duration * 0.86, sidebandGain * 0.62, "sine", 0.008,
        {...expression, instrument: undefined, pressure: 0.16 + 0.25 * velocity, slide: Math.max(0.08, expression.slide - 0.2)});
    }
  }
  tonicWhistle(note, duration = 2, velocity = 0.58, activity = 0.5) {
    this.report("tonicWhistle", { note, duration, velocity, activity });
    const expression = {instrument: "wind", velocity};
    if (this.mode === "midi") {
      this.midiNote(note, duration, velocity, undefined, 0, expression);
      return;
    }
    // The breath is the wind family's own; the octave above is the whistle's second partial,
    // stretched a few cents as a real one is.
    this.voice(note, duration, 0.0288, "sine", 0, expression);
    this.voice(note + 12.03, duration * 0.95, 0.002 + 0.004 * activity, "sine", 0.012,
      {...expression, shape: {noiseSustain: 0, noiseLevel: 0}});
  }
  windTexture(duration = 2, centroid = 2000, density = 0.5, config = {}) {
    this.report("windTexture", { duration, centroid, density });
    if (!this.ctx || this.muted) return;
    const frequencies = config.moduleFrequencies || [300, 700, 1200],
      gains = config.moduleGains || [0.3, 0.2, 0.15],
      count = Math.max(3, Math.round(3 + density * (frequencies.length - 3)));
    for (let index = 0; index < count; index++) {
      const base = frequencies[index % frequencies.length],
        frequency = Math.max(
          40,
          Math.min(this.ctx.sampleRate * 0.45, base * (centroid / 1800)),
        );
      this.noise(
        duration,
        0.0015 + 0.005 * (gains[index] || 0.1),
        frequency,
        index * 0.004,
      );
    }
  }
  bleep(
    note,
    duration = 0.08,
    velocity = 0.65,
    offset = 0,
    preset = {},
    voice = 0,
  ) {
    this.report("bleep", { note, duration, velocity, offset, preset, voice });
    const expression = {instrument: voice ? "synthPluck" : "bell", velocity};
    if (this.mode === "midi") {
      this.midiNote(note, duration, velocity, undefined, offset, expression);
      return;
    }
    const fm = preset.fm?.[voice] ?? (voice ? 34 : 30),
      curve = voice ? (preset.curve2 ?? 0.92) : (preset.curve1 ?? 0.92);
    this.voice(
      note,
      duration,
      0.034,
      voice ? "square" : "sine",
      offset,
      expression,
    );
    // The FM partner sits a ratio above the fundamental, and for the bright preset that ratio
    // is large: `fm` of 200 puts it 12*log2(200/30) = 32.84 semitones up, so a fundamental at
    // 100 asks for 132.84 — past what MIDI 2's Pitch 7.9 can carry, and the source of the
    // `RangeError: Pitch 132.8435871299945` measured five times in 75 seconds. (Not, as the
    // previous commit claimed, mh_BleepBOT's pool plus its octave offset: the fundamental was
    // 100 and perfectly in range. 132.8436 minus 32.8436 is exactly 100.)
    //
    // Skipped rather than folded. This voice exists to sit at that ratio; folding it down an
    // octave would put a loud partial where nothing asked for one, which is audibly wrong,
    // whereas a partner at 17.4 kHz contributes almost nothing to begin with. `voice()` would
    // decline it anyway — this is here so the reason is stated where the ratio is chosen.
    const partner = note + 12 * Math.log2(Math.max(0.01, fm) / 30);
    if (partner < 0 || partner > PITCH_CEILING) {
      this.report("bleep_partner_skipped", {note, partner, fm,
        says: `the FM partner would sound at ${partner.toFixed(2)} semitones, past MIDI 2's `
          +`ceiling; the fundamental plays and the partner does not`});
      return;
    }
    this.voice(
      partner,
      duration * Math.max(0.15, curve),
      0.0077,
      "sine",
      offset + 0.002,
      {instrument: "bell", velocity},
    );
  }
  whinyCluster(
    fundamental,
    duration = 0.4,
    velocity = 0.6,
    config = {},
    valence = 0.5,
  ) {
    const frequencies = [],
      base = midiHz(fundamental),
      [jitterLow, jitterHigh] = config.partialJitter || [-0.03, 0.03];
    for (let partial = 1; partial <= (config.partialCount || 20); partial++) {
      let frequency =
        (partial + jitterLow + random() * (jitterHigh - jitterLow)) * base;
      while (frequency > (config.foldMaximumHz || 1000)) frequency /= 2;
      frequencies.push(frequency);
    }
    const pitches = frequencies.map(hzMidi);
    this.report("whinyCluster", { fundamental, duration, velocity, pitches });
    if (this.mode === "midi") {
      for (const [index, pitch] of pitches.slice(0, 15).entries())
        this.midiNote(
          pitch,
          duration,
          velocity * 0.65,
          undefined,
          index * 0.002,
          {instrument: "texture"},
        );
      return;
    }
    // The partials spread a little across the field, so a cluster is heard as many voices.
    for (const [index, pitch] of pitches.entries())
      this.voice(
        pitch,
        duration,
        0.006,
        "sine",
        index * 0.001,
        {instrument: "texture", velocity, pan: ((index * 0.618) % 1 - 0.5) * 0.6},
      );
  }
  groan(
    note,
    duration = 0.8,
    velocity = 0.65,
    offset = 0,
    slide = 0.02,
    voice = 0,
  ) {
    this.report("groan", { note, duration, velocity, offset, slide, voice });
    if (this.mode === "midi") {
      this.midiNote(note, duration, velocity, undefined, offset, {instrument: "resonant"});
      return;
    }
    this.voice(
      note,
      duration,
      0.042,
      voice % 2 ? "sawtooth" : "triangle",
      offset,
      {
        profile: "lead",
        instrument: "resonant",
        velocity,
        // The source bot uses resonant/plucked synthesis. A separate burst of
        // filtered white noise made every browser note sound as though it
        // contained a click, so articulation now comes from the voice envelope.
        attackSeconds: 0.012,
      },
    );
  }
  wubPluck(
    note,
    duration = 0.6,
    velocity = 0.65,
    offset = 0,
    preset = {},
    voice = 0,
  ) {
    this.report("wubPluck", {
      note,
      duration,
      velocity,
      offset,
      preset,
      voice,
    });
    const expression = {instrument: "synthPluck", velocity,
      // The pluck's click is the voice's own transient now, not a second note of noise.
      shape: {noiseLevel: 0.35 * velocity, noiseDecay: 0.006, noiseCutoff: Math.min(9000, midiHz(note) * 2), noiseResonance: 0.2}};
    if (this.mode === "midi") {
      this.midiNote(note, duration, velocity, undefined, offset, expression);
      return;
    }
    const type = voice % 2 ? "triangle" : "sawtooth",
      decay = Math.max(0.1, (preset.decay ?? 70) / 100);
    this.voice(note, duration * decay, 0.037, type, offset, expression);
  }
  atmosphere(note, duration = 8, gains = [], resonance = 100) {
    this.report("atmosphere", { note, duration, gains, resonance });
    const expression = {
      profile: "texture",
      instrument: "texture",
      velocity: 0.52,
      pressure: 0.38,
      slide: 0.34,
      pressureCurve: [0.25, 0.46, 0.34],
      slideCurve: [0.28, 0.42, 0.31],
      pitchCurve: [0, 0.006, -0.004, 0],
      vibratoDepth: 0.018,
      vibratoRate: 0.16,
    };
    if (this.mode === "midi") {
      this.midiNote(note, duration, 0.52, undefined, 0, expression);
      return;
    }
    const count = Math.min(10, gains.length || 10);
    for (let index = 0; index < count; index++) {
      const ratio = 1 + index * 0.0125,
        pitch = note + 12 * Math.log2(ratio),
        gain = 1.9 * (0.0015 + 0.0045 * (gains[index] ?? 0.5));
      this.voice(
        pitch,
        duration,
        gain,
        index % 3 === 0 ? "triangle" : "sine",
        index * 0.008,
        {
          ...expression,
          vibratoDepth: 0.012 + index * 0.0006,
          vibratoRate: 0.12 + index * 0.006,
          pan: ((index % 5) - 2) * 0.12,
        },
      );
    }
    this.noise(duration, 0.005, midiHz(note), 0);
  }
  textureGrain(
    note,
    duration = 8,
    velocity = 0.6,
    offset = 0,
    timbre = {},
    voice = 0,
  ) {
    this.report("textureGrain", {
      note,
      duration,
      velocity,
      offset,
      timbre: timbre.name,
      voice,
    });
    const expression = {instrument: "texture", velocity};
    if (this.mode === "midi") {
      this.midiNote(note, duration, velocity, undefined, offset, expression);
      return;
    }
    const spectrum = timbre.spectrum || [],
      strongest = [...spectrum.keys()]
        .sort((a, b) => (spectrum[b] ?? -Infinity) - (spectrum[a] ?? -Infinity))
        .slice(0, 3);
    this.voice(
      note,
      duration,
      0.022,
      voice % 2 ? "triangle" : "sine",
      offset,
      expression,
    );
    for (const [index, band] of strongest.entries())
      this.voice(
        note + 12 * Math.log2(1 + (band + 1) / 6),
        duration * (0.65 - index * 0.12),
        0.0054,
        "sine",
        offset + 0.006 * index,
        {...expression, pan: (index - 1) * 0.25},
      );
    this.noise(
      duration,
      0.0015 + 0.003 * velocity,
      midiHz(note) * (1.5 + voice * 0.08),
      offset,
      {velocity},
    );
  }
  granularSlurp(duration = 2, arousal = 0.5, valence = 0.5, config = {}) {
    this.report("granularSlurp", { duration, arousal, valence });
    const voices = config.voiceCount || 3,
      centroid = 50 + (3000 - 50) * arousal;
    for (let voice = 0; voice < voices; voice++) {
      const offset = voice * 0.027,
        band = centroid * (0.72 + voice * 0.28) * (1 + (valence - 0.5) * 0.3);
      this.noise(duration, 1.5 * (0.006 + 0.006 * arousal), band, offset, {velocity: 0.4 + 0.5 * arousal, pan: (voice - (voices - 1) / 2) * 0.3});
      this.voice(
        24 + 36 * valence + voice * 7.03,
        duration,
        1.5 * (0.002 + 0.004 * arousal),
        voice % 2 ? "triangle" : "sine",
        offset,
        {instrument: "texture", velocity: 0.4 + 0.5 * arousal},
      );
    }
  }
  chichichi(cell = 0, state = 0, beatSeconds = 0.5, config = {}) {
    this.report("chichichi", { cell, state });
    const duration = Math.max(0.025, beatSeconds * 0.22),
      band = (config.highpassHz || 4000) * (1 + cell / 32);
    this.noise(duration, 3.4 * (0.018 + 0.006 * (state % 2)), band, 0, {instrument: "shaker", velocity: 0.55 + 0.2 * (state % 2)});
    this.voice(35 + state * 5 + cell * 0.17, duration, 0.012, "sine", 0.002, {instrument: "tom", velocity: 0.5});
  }
  derivations(duration = 4, density = 0.8, config = {}) {
    this.report("derivations", { duration, density });
    if (this.mode === "samples") {
      const file = this.randomFile(/\.(?:aif|aiff|wav)$/i),
        range = config.transposeRange ?? 0.5,
        rate = 1 - range + random() * range * 2;
      this.sampleFile(file, rate, 0.32, 0, duration);
      return;
    }
    const count = Math.max(2, Math.round(2 + density * 5));
    for (let index = 0; index < count; index++) {
      const frequency = 70 + random() * 7600;
      this.noise(duration, 0.0015 + 0.0025 / count, frequency, index * 0.013, {pan: (random() - 0.5) * 0.8});
      this.voice(
        24 + 12 * Math.log2(frequency / 55),
        duration,
        0.0015,
        "sine",
        index * 0.017,
        {instrument: "texture", velocity: 0.45 + 0.4 * density},
      );
    }
  }
  deciderBreath(leaf = 0, config = {}) {
    this.report("deciderBreath", { leaf });
    const phase = ((leaf % 200) + 200) % 200,
      rate = phase < 50 ? 0.5 : phase > 150 ? 2 : phase > 140 ? 3 : 1,
      duration = ((config.attackMs || 500) + (config.releaseMs || 1000)) / 1000;
    if (this.mode === "samples") {
      this.sampleFile(
        this.randomFile(/\.(?:aif|aiff|wav)$/i),
        rate,
        0.3,
        0,
        duration,
      );
      return;
    }
    const [low, high] = config.filterRangeHz || [1000, 11000],
      band =
        low +
        (high - low) * (leaf / Math.max(1, (config.numElements || 30) - 1));
    // The breath's own envelope: config.attackMs in, config.releaseMs out.
    const shape = {attack: (config.attackMs || 500) / 1000, release: Math.min(duration * 0.6, (config.releaseMs || 1000) / 1000)};
    this.noise(duration, 0.016, band, 0, {velocity: 0.6});
    this.voice(30 + leaf * 0.31, duration, 0.0025, "sine", 0, {instrument: "texture", velocity: 0.6, shape});
  }
  blankTriangle(note, duration = 0.5, velocity = 0.65) {
    this.report("blankTriangle", { note, duration, velocity });
    if (this.mode === "midi") {
      this.midiNote(note, duration, velocity, undefined, 0, {instrument: "organ"});
      return;
    }
    this.voice(note, duration, 0.046, "triangle", 0, {instrument: "organ", velocity});
  }
  midiGeneratorVoice(
    note,
    duration = 0.5,
    velocity = 0.65,
    voice = 0,
    controls = {},
  ) {
    this.report("midiGeneratorVoice", {
      note,
      duration,
      velocity,
      voice,
      controls,
    });
    if (this.mode === "midi") {
      this.midiNote(note, duration, velocity, undefined, 0, {instrument: "organ"});
      return;
    }
    this.voice(
      note,
      duration,
      0.026,
      voice % 2 ? "triangle" : "sine",
      0,
      {instrument: "organ", velocity},
    );
  }
  webVoice(note, duration = 0.5, velocity = 0.5, voice = 0) {
    this.report("webVoice", { note, duration, velocity, voice });
    if (this.mode === "midi") {
      this.midiNote(note, duration, velocity, undefined, 0, {instrument: "organ"});
      return;
    }
    this.voice(
      note,
      duration,
      0.0308,
      voice % 2 ? "sine" : "triangle",
      0,
      {instrument: "organ", velocity},
    );
  }
  papMelodyVoice(note, duration = 0.2, velocity = 0.65, offset = 0, voice = 0) {
    this.report("papMelodyVoice", { note, duration, velocity, offset, voice });
    const expression = {instrument: voice === 1 ? "synthPluck" : "lead", velocity};
    if (this.mode === "midi") {
      this.midiNote(note, duration, velocity, undefined, offset, expression);
      return;
    }
    const types = ["triangle", "sawtooth", "sine"];
    this.voice(
      note,
      duration,
      0.0335,
      types[voice % 3],
      offset,
      expression,
    );
    if (voice === 2)
      this.voice(
        note - 12,
        duration * 0.55,
        0.0085,
        "sine",
        offset + 0.006,
        expression,
      );
  }
  // A bowed string (bowedstring_clodbot): the bowed family's voice (shared/articulation.js: a violinist's vibrato, a bowed
  // attack, bow noise), a sawtooth drawn through it, the bow's pressure with the dynamic. A physical model of the string
  // may take its place (the world-instruments report's renderers).
  // A section's seat (bots/lib/modules/section-seat.js) names its line (options.line), may glide into its note from
  // another (options.glide, its seconds, and options.glideFrom; false, never), plucks a pizzicato
  // (options.articulation) and sounds its own few milliseconds after its part (options.lag). On recordings, a seat's
  // stroke (options.stroke: {into, attack, release, vibrato: {curve, step}, captured}: a change of bow begun past its
  // recording's attack, its fades, a still recording's vibrato, the note it tells the score) and its take (options.take:
  // its own of a pitch's recordings). -> the
  // note's identity in the engine, where it has one, so its player can let it go.
  bowedString(note, duration = 0.5, velocity = 0.65, offset = 0, options = {}) {
    if(options.harmonic&&!this.physical)this.report('substitution',{instrument:options.instrument??'bowed',reason:'Natural harmonic contact needs the Artifastring physical model; this voice plays the requested sounding pitch ordinarily'});
    if(options.multiphonic&&!this.physical)this.report('substitution',{instrument:options.instrument??'bowed',reason:'A multiphonic needs the Artifastring physical model; this voice plays its lowest pitch ordinarily'});
    if(pressureOf(options.bowPressure)&&!this.physical)this.report('substitution',{instrument:options.instrument??'bowed',reason:'Bow pressure (flautando to overpressure) needs the Artifastring physical model; this voice bows ordinarily'});
    this.report("bowedString", { note, duration, velocity, offset, instrument: options?.instrument ?? null, ...(Number(options?.lag) ? {lag: Number(options.lag)} : {}) });
    const plucked = options?.articulation === "pizzicato";
    const expression = {instrument: plucked ? "pluck" : "bowed", ...(plucked ? {profile: "pluck"} : {}), velocity, pressure: 0.3 + 0.6 * velocity,
      ...(typeof options?.line === "string" ? {line: options.line} : {}), technique: plucked ? "pizzicato" : options?.technique === "tremolo" ? "tremolo" : "arco",
      ...(options?.slurred === true ? {slurred: true} : {}), ...(writtenOf(options?.written) ? {written: writtenOf(options.written)} : {}),
      ...(Number(options?.lag) ? {lag: Number(options.lag)} : {}), ...(Number.isFinite(options?.writtenTick) ? {writtenTick: options.writtenTick, ...(options.writtenTicks > 0 ? {writtenTicks: options.writtenTicks} : {})} : {}),
      ...(Number(options?.glide) > 0 && Number.isFinite(Number(options?.glideFrom)) ? {glide: Number(options.glide),glideKind:options.glideKind??'into', glideFrom: Number(options.glideFrom)}
        : options?.glide === false ? {glide: false} : {}), ...toldBy(options?.stroke), ...(Number(options?.glideSpeed) > 0 ? {glideSpeed: Number(options.glideSpeed)} : {})};
    if (this.mode === "midi") {
      this.midiNote(note, duration, velocity, undefined, offset, expression);
      return null;
    }
    // On a physical model of its instrument, where the render plays one (render/node/physical-strings.mjs): the stroke
    // logged for the model, its audio the model's.
    if (this.physical) return this.physicalStroke(note, duration, velocity, offset, {...options, plucked});
    // On a bowed string's recordings, where its bank is loaded (bowedstring_clodbot): its pizzicati plucked, a note no
    // longer than the bank's own spiccato strokes sound (strokeSeconds) bounced, the rest held.
    if (this.mode === "samples" && this.sampleFiles?.length && this.sampleDesign?.bowed) {
      // (A stroke of a held note is held, however short.)
      // (A bowed tremolo its bank records, where its player asks for one: that recording, the whole note.)
      const articulation = plucked ? "pizzicato" : options?.articulation === "tremolo" && this.sampleArticulations().has("tremolo") ? "tremolo"
        : !options?.stroke && duration <= this.strokeSeconds("spiccato") ? "spiccato" : null;
      // (A seat's stroke -- past its recording's attack at a change of bow, its fades, its vibrato -- and its take.)
      return this.samplePitch(note, offset, this.sampleDesign.layered ? 0.565 : this.sampleLevel(0.565, velocity, "bowed"), duration, velocity,
        {articulation, ...(typeof options?.instrument === "string" ? {instrument: options.instrument} : {}), ...(typeof options?.line === "string" ? {line: options.line} : {}), ...(expression.lag ? {lag: expression.lag} : {}),
          ...(Number.isFinite(expression.writtenTick) ? {writtenTick: expression.writtenTick, ...(expression.writtenTicks > 0 ? {writtenTicks: expression.writtenTicks} : {})} : {}),
          technique: expression.technique, ...(options?.slurred === true ? {slurred: true} : {}), ...(expression.written ? {written: expression.written} : {}),
          ...(options?.multiphonic && options?.stroke?.captured !== false ? {multiphonic: options.multiphonic} : {}),
          ...(expression.glide > 0 ? {glide: expression.glide,glideKind:expression.glideKind??'into', glideFrom: expression.glideFrom, ...(Number(options?.glideAt) > 0 ? {glideAt: Number(options.glideAt)} : {})} : {}),
          ...(options?.stroke && !articulation ? {stroke: options.stroke} : {}), ...(Number.isInteger(options?.take) ? {take: options.take} : {})}) ?? null;
    }
    return this.voice(note, duration, 0.03, "sawtooth", offset, expression);
  }
  // How long the loaded recordings hold a steady tone (s): from their established attack to where the bow leaves them
  // (their bank's attack and releaseAt), the `share`-th shortest -- a stroke no longer than this never outlasts the
  // recording it plays (section-seat.js); 0 where the bank does not say.
  // How long a bowed stroke at `note` and `velocity` may hold on this bank's recordings: as long as its bow lasts
  // (Infinity) where every recording it may play -- each take of the layer its velocity chooses at the root nearest it,
  // as layeredChoice chooses (every layer where no velocity is given) -- carries a measured loop (still
  // strings: scripts/download-iowa-still-strings.mjs; musical.loop), else as long as the shortest of those that do not
  // holds a steady tone, at its playback rate; 0 where the bank does not say.
  strokeHold(note, velocity = null) {
    if (!this.sampleDesign?.still || !Number.isFinite(note)) return 0;
    const entries = (this.sampleFiles ?? []).map(file => this.sampleMetadata?.[file]).filter(entry => entry && !entry.articulation && Number.isFinite(entry.rootNote));
    if (!entries.length) return 0;
    let root = entries[0].rootNote;
    for (const entry of entries) if (Math.abs(entry.rootNote - note) < Math.abs(root - note)) root = entry.rootNote;
    const rate = 2 ** ((note - root) / 12), here = entries.filter(entry => entry.rootNote === root);
    let layer = here;
    if (Number.isFinite(velocity) && here.every(entry => Array.isArray(entry.velocity))) {
      const v = Math.max(0, Math.min(1, velocity)), middle = entry => (entry.velocity[0] + entry.velocity[1]) / 2;
      const held = here.find(entry => v >= entry.velocity[0] && v <= entry.velocity[1]) ?? here.reduce((best, entry) => Math.abs(middle(entry) - v) < Math.abs(middle(best) - v) ? entry : best);
      layer = here.filter(entry => entry.velocity[0] === held.velocity[0] && entry.velocity[1] === held.velocity[1]);
    }
    let least = Infinity;
    for (const entry of layer) if (!Array.isArray(entry.loop))
      least = Math.min(least, Number.isFinite(entry.releaseAt) ? Math.max(0, entry.releaseAt - (entry.attack ?? 0)) / rate : 0);
    return least;
  }
  sustainSeconds(share = 0.1) {
    if (this._sustainFiles !== this.sampleFiles) {
      this._sustainFiles = this.sampleFiles;
      const held = (this.sampleFiles ?? []).map(file => this.sampleMetadata?.[file]).filter(entry => Number.isFinite(entry?.releaseAt) && !entry.articulation)
        .map(entry => entry.releaseAt - (entry.attack ?? 0)).filter(seconds => seconds > 0).sort((a, b) => a - b);
      this._sustain = held.length ? held[Math.floor(share * (held.length - 1))] : 0;
    }
    return this._sustain;
  }
  // How long a bank's recordings of an articulation sound (s: their median), or 0 where it has none: a stroke as long as
  // its recordings is played as one.
  strokeSeconds(articulation) {
    if (this._strokeMetadata !== this.sampleMetadata) { this._strokeMetadata = this.sampleMetadata; this._strokes = new Map(); }
    if (!this._strokes.has(articulation)) {
      const lengths = Object.values(this.sampleMetadata ?? {}).filter(entry => entry?.articulation === articulation && Number.isFinite(entry.seconds)).map(entry => entry.seconds).sort((a, b) => a - b);
      this._strokes.set(articulation, lengths.length ? lengths[lengths.length >> 1] : 0);
    }
    return this._strokes.get(articulation);
  }
  // A transverse flute (flute_clodbot): the wind family's voice (shared/articulation.js), its breath noise its own, a
  // sine drawn through it (one voice: a partial is the timbre's, not a note of the score); options.instrument names the
  // flute, for a model to come.
  // A wind or brass player's note (flute_clodbot, woodwind_clodbot, brass_clodbot; seated: bots/lib/modules/wind-seat.js):
  // on its instrument's recordings where a wind bank is loaded (scripts/download-wind-samples.mjs) -- a seat's stroke
  // (options.stroke: {into, attack, vibrato, loop, captured}: a slur past its recording's attack, a tongued note from it,
  // its own vibrato on recordings without one, the note it tells the score) and its take; a note no longer than the
  // bank's own staccatos, one of them -- else its family's voice, which a plugin's synthesizer plays where the bot has one
  // (a flute's Surge XT "Winds/Flute 2"). -> the note's identity in the engine, where it has one.
  windNote(note, duration = 0.5, velocity = 0.65, offset = 0, options = {}) {
    // (A winds synth -- the woodwinds' engine, synths/winds-bridge.js -- told its model, its instrument, as a program is.)
    if (this.dspNode?.capabilities?.windMidi2 && typeof options?.instrument === "string") this.dspNode.configure?.({instrument: options.instrument});
    // (An extended technique -- a hum, a growl, a flutter: techniques.js -- is a physical model's, its breath forced; on
    // recordings the note is played ordinarily, said.)
    const extended = options?.extended && typeof options.extended === "object" ? {extended: {...options.extended}} : {};
    if (extended.extended && this.mode === "samples" && this.sampleFiles?.length && this.sampleDesign?.wind)
      this.report("substitution", {instrument: options?.instrument ?? "wind", reason: `A wind's ${Object.keys(extended.extended).join(", ")} needs a physical model (offline: a section's sounds' physical); on recordings this note is played ordinarily`});
    if (this.mode === "samples" && this.sampleFiles?.length && this.sampleDesign?.wind) {
      this.report("windNote", { note, duration, velocity, offset, instrument: options?.instrument ?? null, ...(Number(options?.lag) ? {lag: Number(options.lag)} : {}) });
      // (A short stroke is a staccato only where it is a note of its own: never a held note's later piece, nor a tremolo's
      // tonguing -- each of those, a staccato, had dropped its stroke and been written as a note of its own: Op. 3.22.)
      const articulation = !options?.stroke?.into && options?.stroke?.captured !== false && options?.technique !== "tremolo"
        && duration <= this.strokeSeconds("staccato") ? "staccato" : null;
      return this.samplePitch(note, offset, this.sampleDesign.layered ? 0.565 : this.sampleLevel(0.565, velocity, "wind"), duration, velocity,
        {articulation, ...(typeof options?.instrument === "string" ? {instrument: options.instrument} : {}), ...(typeof options?.line === "string" ? {line: options.line} : {}), ...(Number(options?.lag) ? {lag: Number(options.lag)} : {}), ...(Number.isFinite(options?.writtenTick) ? {writtenTick: options.writtenTick, ...(options.writtenTicks > 0 ? {writtenTicks: options.writtenTicks} : {})} : {}),
          ...(options?.stroke && !articulation ? {stroke: options.stroke} : {}), ...(Number.isInteger(options?.take) ? {take: options.take} : {}),
          ...(options?.stroke?.captured?.slurred === true ? {slurred: true} : {}), ...(options?.stroke?.captured?.portato === true ? {portato: true} : {}), ...(options?.technique === 'tremolo' ? {technique: 'tremolo'} : {}),
          ...(options?.stroke?.captured !== false ? {...extended, ...(options?.multiphonic ? {multiphonic: options.multiphonic} : {})} : {}),
          ...(Number(options?.glide) > 0 && Number.isFinite(Number(options?.glideFrom)) ? {glide: Number(options.glide),glideKind:options.glideKind??'into', glideFrom: Number(options.glideFrom), ...(Number(options?.glideAt) > 0 ? {glideAt: Number(options.glideAt)} : {})} : {})}) ?? null;
    }
    // (Elsewhere its family's voice: the flute's own, or a reed's or a brass instrument's on the wind family's.)
    if (options?.family == null || options.family === "flute") return this.flute(note, duration, velocity, offset, options) ?? null;
    this.report("windNote", { note, duration, velocity, offset, instrument: options?.instrument ?? null, ...(Number(options?.lag) ? {lag: Number(options.lag)} : {}) });
    const expression = {instrument: "wind", velocity, ...(typeof options?.line === "string" ? {line: options.line} : {}), ...(Number(options?.lag) ? {lag: Number(options.lag)} : {}), ...(Number.isFinite(options?.writtenTick) ? {writtenTick: options.writtenTick, ...(options.writtenTicks > 0 ? {writtenTicks: options.writtenTicks} : {})} : {}),
      ...(options?.glide === false || Number(options?.glide) > 0 ? {glide: options.glide === false ? false : Number(options.glide)} : {}),
      // (A glissando's: the pitch it slides from, after its hold: wind-seat.js.)
      ...(Number(options?.glide) > 0 && Number.isFinite(Number(options?.glideFrom)) ? {glideKind:options.glideKind??'into',glideFrom: Number(options.glideFrom), ...(Number(options?.glideAt) > 0 ? {glideAt: Number(options.glideAt)} : {})} : {}),
      ...(options?.stroke?.captured?.slurred === true ? {slurred: true} : {}), ...(options?.stroke?.captured?.portato === true ? {portato: true} : {}), ...(options?.stroke?.captured?.phrased === true ? {phrased: true} : {}), ...toldBy(options?.stroke),
      ...(Number(options?.glideSpeed) > 0 ? {glideSpeed: Number(options.glideSpeed)} : {}), ...extended, ...(options?.multiphonic ? {multiphonic: {...options.multiphonic}} : {})};
    if (this.mode === "midi") { this.midiNote(note, duration, velocity, undefined, offset, expression); return null; }
    return this.voice(note, duration, 0.03, options.family === "brass" ? "sawtooth" : "square", offset, expression) ?? null;
  }
  flute(note, duration = 0.5, velocity = 0.65, offset = 0, options = {}) {
    this.report("flute", { note, duration, velocity, offset, instrument: options?.instrument ?? null, ...(Number(options?.lag) ? {lag: Number(options.lag)} : {}) });
    // (Its glide the player's where it says one -- false, none; seconds, a slur's change of pitch -- else its family's.)
    const expression = {instrument: "wind", velocity, ...(typeof options?.line === "string" ? {line: options.line} : {}), ...(Number(options?.lag) ? {lag: Number(options.lag)} : {}), ...(Number.isFinite(options?.writtenTick) ? {writtenTick: options.writtenTick, ...(options.writtenTicks > 0 ? {writtenTicks: options.writtenTicks} : {})} : {}),
      ...(options?.glide === false || Number(options?.glide) > 0 ? {glide: options.glide === false ? false : Number(options.glide)} : {}),
      // (A glissando's: the pitch it slides from, after its hold: wind-seat.js.)
      ...(Number(options?.glide) > 0 && Number.isFinite(Number(options?.glideFrom)) ? {glideKind:options.glideKind??'into',glideFrom: Number(options.glideFrom), ...(Number(options?.glideAt) > 0 ? {glideAt: Number(options.glideAt)} : {})} : {}),
      ...(options?.stroke?.captured?.slurred === true ? {slurred: true} : {}), ...(options?.stroke?.captured?.portato === true ? {portato: true} : {}), ...(options?.stroke?.captured?.phrased === true ? {phrased: true} : {}), ...toldBy(options?.stroke),
      ...(Number(options?.glideSpeed) > 0 ? {glideSpeed: Number(options.glideSpeed)} : {})};
    if (this.mode === "midi") {
      this.midiNote(note, duration, velocity, undefined, offset, expression);
      return;
    }
    return this.voice(note, duration, 0.03, "sine", offset, expression);
  }
  papMelody4(
    note,
    duration = 0.2,
    velocity = 0.65,
    offset = 0,
    modulation = 0,
  ) {
    this.report("papMelody4", { note, duration, velocity, offset, modulation });
    const expression = {instrument: "synthPluck", velocity};
    if (this.mode === "midi") {
      this.midiNote(note, duration, velocity, undefined, offset, expression);
      return;
    }
    this.voice(note, duration, 0.035, "square", offset, expression);
    this.voice(
      note + 7,
      duration * 0.58,
      0.0092,
      "triangle",
      offset + 0.005,
      expression,
    );
  }
  // PAP_DampPianoBot: a piano with its dampers close to the strings. The keys family's hammer,
  // bright-when-hard strike and quick damping are the whole instrument; the octave partial and
  // the separate hammer noise it used to add are what the family's filter and transient do.
  dampedPiano(
    note,
    duration = 0.22,
    velocity = 0.65,
    offset = 0,
    register = 0,
  ) {
    this.report("dampedPiano", { note, duration, velocity, offset, register });
    const expression = {instrument: "keys", velocity, shape: {release: 0.07 + 0.05 * (1 - register)}};
    if (this.mode === "midi") {
      this.midiNote(note, duration, velocity, undefined, offset, expression);
      return;
    }
    this.voice(note, duration, 0.07, "sawtooth", offset, expression);
  }
  counterpointVoice(
    note,
    duration = 0.22,
    velocity = 0.65,
    offset = 0,
    register = 0,
  ) {
    this.report("counterpointVoice", {
      note,
      duration,
      velocity,
      offset,
      register,
    });
    // The voices of a counterpoint sit apart in the field as well as in register.
    const expression = {instrument: "keys", velocity, pan: ((register % 5) - 2) * 0.18};
    if (this.mode === "midi") {
      this.midiNote(note, duration, velocity, undefined, offset, expression);
      return;
    }
    const types = ["triangle", "sine", "square", "sawtooth", "triangle"];
    this.voice(
      note,
      duration,
      0.049,
      types[register % types.length],
      offset,
      expression,
    );
    this.voice(
      note + (register % 2 ? 12 : -12),
      duration * 0.52,
      0.0104,
      "sine",
      offset + 0.006,
      expression,
    );
  }
  ornamentPluck(note, duration = 0.16, velocity = 0.65, offset = 0, pan = 0.5) {
    this.report("ornamentPluck", { note, duration, velocity, offset, pan });
    // mh_OrnamentBOT places its ornaments: 0..1 across the field, now each note's own pan.
    const expression = {instrument: "pluck", velocity, pan: Math.max(-1, Math.min(1, (Number(pan) - 0.5) * 2))};
    if (this.mode === "midi") {
      this.midiNote(note, duration, velocity, undefined, offset, expression);
      return;
    }
    this.voice(note, duration, 0.0466, "triangle", offset, expression);
  }
  msynthNote(note, duration = 0.2, velocity = 0.65, offset = 0, preset = 0) {
    this.report("msynthNote", { note, duration, velocity, offset, preset });
    const expression = {instrument: duration >= 0.6 ? "lead" : "synthPluck", velocity};
    if (this.mode === "midi") {
      this.midiNote(note, duration, velocity, undefined, offset, expression);
      return;
    }
    const types = ["sawtooth", "triangle", "square", "sine", "sawtooth"],
      type = types[preset % types.length],
      gain = 0.034;
    this.voice(note, duration, gain, type, offset, preset === 2
      ? {...expression, shape: {noiseLevel: 0.25 * velocity, noiseDecay: 0.008, noiseCutoff: Math.min(9000, 1200 + note * 18)}}
      : expression);
    if (preset === 0 || preset === 4)
      this.voice(
        note + 12,
        duration * 0.55,
        gain * 0.2,
        "sine",
        offset + 0.004,
        expression,
      );
  }
  rsynthNote(note, duration = 0.14, velocity = 0.65, offset = 0, preset = 0) {
    this.report("rsynthNote", { note, duration, velocity, offset, preset });
    const expression = {instrument: "synthPluck", velocity,
      ...(preset % 2 === 0 ? {shape: {noiseLevel: 0.2 * velocity, noiseDecay: 0.006, noiseCutoff: Math.min(9000, 1600 + note * 20)}} : {})};
    if (this.mode === "midi") {
      this.midiNote(note, duration, velocity, undefined, offset, expression);
      return;
    }
    const types = ["square", "sawtooth", "triangle", "square", "sine"];
    this.voice(note, duration, 0.034, types[preset % types.length], offset, expression);
  }
  multiSynthNote(
    note,
    duration = 0.2,
    velocity = 0.65,
    offset = 0,
    part = 0,
    preset = 0,
  ) {
    this.report("multiSynthNote", {
      note,
      duration,
      velocity,
      offset,
      part,
      preset,
    });
    // ae_MultiSynthBOT's parts, each in its own place.
    const expression = {instrument: part === 0 ? "synthBass" : "synthPluck", velocity, pan: part === 0 ? 0 : (part % 2 ? -0.3 : 0.3)};
    if (this.mode === "midi") {
      this.midiNote(note, duration, velocity, undefined, offset, expression);
      return;
    }
    const types = ["triangle", "sawtooth", "square", "sine"],
      gain = 0.0236;
    this.voice(
      note,
      duration,
      gain,
      types[(part + preset) % types.length],
      offset,
      expression,
    );
    if (part === 0)
      this.voice(
        note - 12,
        duration * 0.62,
        gain * 0.22,
        "sine",
        offset + 0.005,
        expression,
      );
  }
  // ae_ReichGuitarBOT: interlocking guitars, played as plucked strings -- the pick is the pluck
  // family's own transient -- and each part in its own place, as the players would stand.
  reichGuitar(
    note,
    duration = 0.18,
    velocity = 0.65,
    offset = 0,
    part = 0,
    preset = 0,
  ) {
    this.report("reichGuitar", {
      note,
      duration,
      velocity,
      offset,
      part,
      preset,
    });
    const expression = {instrument: "pluck", velocity, pan: [-0.45, 0.45, -0.2, 0.2][part % 4]};
    if (this.mode === "midi") {
      this.midiNote(note, duration, velocity, undefined, offset, expression);
      return;
    }
    // -1.9 dB on 23 September 2026: the guitar's measured ring (articulation.js) is longer, so it is louder.
    const gain = 0.0281;
    this.voice(
      note,
      duration,
      gain,
      part % 2 ? "triangle" : "sawtooth",
      offset,
      expression,
    );
    if (preset % 2)
      this.voice(
        note + 12,
        duration * 0.35,
        gain * 0.12,
        "sine",
        offset + 0.004,
        expression,
      );
  }
  methenyMelody(
    note,
    duration = 0.24,
    velocity = 0.65,
    offset = 0,
    preset = 0,
  ) {
    this.report("methenyMelody", { note, duration, velocity, offset, preset });
    const expression = {instrument: "lead", velocity};
    if (this.mode === "midi") {
      this.midiNote(note, duration, velocity, undefined, offset, expression);
      return;
    }
    const types = ["sawtooth", "triangle", "square"],
      gain = 0.032;
    this.voice(note, duration, gain, types[preset % 3], offset, expression);
    if (preset === 1)
      this.voice(
        note + 12,
        duration * 0.48,
        gain * 0.16,
        "sine",
        offset + 0.006,
        expression,
      );
  }
  seasonsArpy(note, duration = 0.158318, velocity = 0.66) {
    this.report("seasonsArpy", { note, duration, velocity });
    const expression = {instrument: "pluck", velocity};
    if (this.mode === "midi") {
      this.midiNote(note, duration, velocity, undefined, 0, expression);
      return;
    }
    this.voice(note, duration, 0.0265, "triangle", 0, expression);
  }
  seasonsBrokenChord(note, duration, velocity = 0.55, offset = 0) {
    this.report("seasonsBrokenChord", { note, duration, velocity, offset });
    const expression = { profile: "pad", instrument: "keys", velocity };
    if (this.mode === "midi")
      this.midiNote(note, duration, velocity, undefined, offset, expression);
    else if (this.mode === "samples")
      this.samplePitch(note, offset, this.sampleLevel(0.595, velocity, "keys"), duration, velocity);
    else {
      // +3.1 dB on 23 September 2026: the piano's measured velocity curve (articulation.js) plays this bot's
      // below-pivot notes softer, as a piano does, and this puts its calibrated loudness back.
      this.voice(
        note,
        duration,
        0.157,
        "triangle",
        offset,
        expression,
      );
      this.voice(
        note + 12,
        duration * 0.94,
        0.0415,
        "sine",
        offset + 0.01,
        expression,
      );
    }
  }
  seasonsChord(notes, duration = 0.85, velocity = 0.6) {
    this.report("seasonsChord", { notes, duration, velocity });
    const expression = { profile: "pad", instrument: "pad", velocity };
    if (this.mode === "midi")
      notes.forEach((note, index) =>
        this.midiNote(
          note,
          duration,
          velocity,
          undefined,
          index * 0.012,
          expression,
        ),
      );
    else if (this.mode === "samples")
      notes.forEach((note, index) =>
        this.samplePitch(note, index * 0.018, this.sampleLevel(0.395, velocity, "pad"), 0, velocity),
      );
    else {
      const voiced = chordVelocities(notes, velocity, random);
      notes.forEach((note, index) => {
        const place = {...expression, velocity: voiced[index], pan: notes.length > 1 ? (index / (notes.length - 1) - 0.5) * 0.5 : 0};
        this.voice(
          note,
          duration,
          0.034,
          index % 2 ? "sine" : "triangle",
          index * 0.018,
          place,
        );
        this.voice(
          note + 12,
          duration * 0.75,
          0.0081,
          "sine",
          index * 0.018 + 0.012,
          place,
        );
      });
    }
  }
  seasonsDrone(note, duration, velocity = 0.52, offset = 0) {
    this.report("seasonsDrone", { note, duration, velocity, offset });
    const expression = { profile: "drone", instrument: "drone", velocity };
    if (this.mode === "midi") {
      this.midiNote(note, duration, velocity, undefined, offset, expression);
      return;
    }
    this.voice(
      note,
      duration,
      0.027,
      "sine",
      offset,
      expression,
    );
    this.voice(
      note - 12,
      duration * 0.96,
      0.0082,
      "triangle",
      offset + 0.02,
      expression,
    );
  }
  seasonsSussy(note, duration, velocity = 0.52, offset = 0) {
    this.report("seasonsSussy", { note, duration, velocity, offset });
    const expression = { profile: "drone", instrument: "drone", velocity };
    if (this.mode === "midi") {
      this.midiNote(note, duration, velocity, undefined, offset, expression);
      return;
    }
    this.voice(
      note,
      duration,
      0.038,
      "triangle",
      offset,
      expression,
    );
    this.voice(
      note - 12,
      duration * 0.96,
      0.0134,
      "sine",
      offset + 0.02,
      expression,
    );
  }
  // A harmony bot's chord, as an electric piano. `duration` and `velocity` were ignored until now
  // -- the callers passed them and the chord always sounded for 0.7 s at 0.55 -- and every note
  // of it was struck exactly as hard. A chord is voiced: the top note carries, the bass is
  // firm, the inner notes sit under them, and each is a hair different from the next.
  chord(ns, duration = 0.7, velocity = 0.55, asked = null) {
    this.report("chord", { notes: ns, duration, velocity });
    const voiced = chordVelocities(ns, velocity, random);
    if (this.mode === "midi") {
      // A bounded, per-chord gesture creates piano legato without leaving a
      // receiving instrument's damper latched between formal sections.
      this.midiDamper(Math.min(2, duration * 0.97));
      ns.forEach((n, i) => this.midiNote(n, duration * 0.8, voiced[i], undefined, 0, { profile: "keys", instrument: "epiano" }));
    }
    else if (this.mode === "samples") ns.forEach((n, i) => this.samplePitch(n, i * 0.012, this.sampleLevel(0.65, voiced[i], "epiano"), 0, voiced[i]));
    else
      ns.forEach((n, i) =>
        this.voice(n, duration, 0.052, "sine", i * 0.018, { profile: "keys", instrument: "epiano", velocity: voiced[i],
          model: MODEL.fm, paramA: 1, paramB: 0.8, pan: ns.length > 1 ? (i / (ns.length - 1) - 0.5) * 0.4 : 0, ...(asked || {}), chord: true }),
      );
  }
  rhodes(ns, duration = 0.48, velocity = 0.5) {
    this.report("rhodes", { notes: ns, duration, velocity });
    const voiced = chordVelocities(ns, velocity, random);
    if (this.mode === "midi")
      ns.forEach((n, i) => this.midiNote(n, duration, voiced[i], undefined, 0, { profile: "keys", instrument: "epiano" }));
    else if (this.mode === "samples") ns.forEach((n, i) => this.samplePitch(n, 0, this.sampleLevel(0.65, voiced[i], "epiano"), 0, voiced[i]));
    else
      ns.forEach((n, i) => this.voice(n, duration, 0.039, "sine", 0, { profile: "keys", instrument: "epiano", velocity: voiced[i],
        model: MODEL.fm, paramA: 1, paramB: 1.1 }));
  }
  bowedTexture(notes, duration = 0.7, accent = 0.6) {
    this.report("bowedTexture", { notes, duration, accent });
    const velocity = 0.3 + 0.45 * accent,
      expression = { profile: "pad", instrument: "bowed", velocity, pressure: 0.2 + 0.5 * accent };
    if (this.mode === "midi") {
      notes.forEach((note, index) =>
        this.midiNote(
          note,
          duration,
          velocity,
          undefined,
          index * 0.012,
          expression,
        ),
      );
      return;
    }
    if (this.mode === "samples") {
      notes.forEach((note) => this.samplePitch(note, 0, this.sampleLevel(0.65, velocity, "bowed"), duration, velocity));
      return;
    }
    // A section, seated: the lowest voice to one side, the highest to the other, the top line
    // carrying over the inner parts.
    const voiced = chordVelocities(notes, velocity, random);
    notes.forEach((note, index) => {
      const seated = {...expression, velocity: voiced[index], pan: notes.length > 1 ? (index / (notes.length - 1) - 0.5) * 0.7 : 0};
      this.voice(
        note,
        duration,
        0.042,
        index ? "triangle" : "sawtooth",
        index * 0.018,
        seated,
      );
      if (index)
        this.voice(
          note + 12,
          duration * 0.8,
          0.0067,
          "sine",
          index * 0.018 + 0.02,
          seated,
        );
    });
  }
  dronePad(note, duration = 1, density = 0.5) {
    this.report("dronePad", { note, duration, density });
    const velocity = 0.35 + 0.35 * density,
      expression = {
        profile: "drone",
        instrument: "drone",
        velocity,
        pressure: 0.22 + 0.42 * density,
      };
    if (this.mode === "midi") {
      this.midiNote(note, duration, velocity, undefined, 0, expression);
      return [];
    }
    // The identities of the voices it started, so a caller may let them go (releaseNote): a drone holding its tone
    // under a new chord (drone_clodbot) releases it only when its pitch moves.
    return [
      this.voice(note, duration, 0.068, "sawtooth", 0, expression),
      this.voice(note + 12, duration * 0.92, 0.025, "sine", 0.015, expression),
    ].filter(Boolean);
  }
  padChord(notes, duration = 1, density = 0.5, openness = 0.5) {
    this.report("padChord", { notes, duration, density, openness });
    const velocity = 0.3 + 0.35 * density,
      expression = {
        profile: "pad",
        instrument: "pad",
        velocity,
        pressure: 0.2 + 0.4 * density,
        slide: 0.18 + 0.68 * openness,
      };
    if (this.mode === "midi") {
      notes.forEach((note, index) =>
        this.midiNote(
          note,
          duration,
          velocity,
          undefined,
          index * 0.012,
          expression,
        ),
      );
      return;
    }
    // **A pad holds one chord at a time.** ae_PadBOT's own description is "holds notes for length of chord", and
    // with a chord plan each chord is exactly as long as the plan says, so the last one is over when the next
    // begins. Given only note pools it has no lengths to go by and holds each chord for a whole phrase -- 32 beats,
    // some twenty seconds -- while pools may arrive every few seconds. Every earlier chord then went on sounding
    // under the new one: heard on 19 September 2026 as a pad that "stopped clearing notes" and turned into a
    // cluster. Starting a chord now lets go of whatever this pad is still holding, so the old chord fades as the
    // new one speaks. (MIDI output is not covered: a note-off already sent with its note cannot be taken back, and
    // an early one would need care around restruck pitches.)
    //
    // **And it lets go the way a player does.** With its own release -- half a second and more, 1.5 s under a
    // phrase-long hold -- the old chord went on sounding across the new one; heard on 23 September 2026 in
    // play-along renders following a guitarist's changes as "'ugly' harmonizing": a long release bleeding across
    // chords. A keyboardist lifts the old keys as the new ones go down. So a tone the new chord drops is let go
    // within half of the new chord's swell (0.12-0.3 s), and a tone the chord keeps fades over the swell itself,
    // so the note that stays is held level while the ones that change get out of the way. The same goes for a
    // planned chord whose tail is still ringing when the next begins.
    const at = this.eventStart(0), swell = noteShape("pad", {note: notes[0] ?? 60, velocity, duration}).values.attack;
    const kept = new Set(notes.map(note => Math.round(note * 100)));
    for (const identity of this.padHeld || []) {
      const held = this.sounding.get(identity);
      if (!held || held.endsAt <= at) continue;
      const stays = kept.has(Math.round(held.note * 100)) || kept.has(Math.round((held.note - 12) * 100));
      this.releaseNote(identity, { atSeconds: at, seconds: stays
        ? Math.max(0.12, Math.min(held.release, swell))
        : Math.max(0.12, Math.min(0.3, held.release, swell / 2)) });
    }
    this.padHeld = [];
    const gain = 2.35 * (0.012 + 0.015 * density + 0.008 * openness),
      voiced = chordVelocities(notes, velocity, random);
    notes.forEach((note, index) => {
      const voice = {...expression, velocity: voiced[index],
        pan: notes.length > 1 ? (index / (notes.length - 1) - 0.5) * 0.6 : 0};
      this.padHeld.push(
        this.voice(note, duration, gain, "sawtooth", index * 0.015, voice),
        this.voice(
          note + 12,
          duration * 0.9,
          gain * 0.35,
          "sine",
          index * 0.015 + 0.01,
          voice,
        ),
      );
    });
    this.padHeld = this.padHeld.filter(Boolean);
  }
  highDrone(note, duration = 12, accent = 0.6) {
    this.report("highDrone", { note, duration, accent });
    const velocity = 0.25 + 0.4 * accent,
      expression = {
        profile: "drone",
        instrument: "drone",
        velocity,
        pressure: 0.18 + 0.42 * accent,
      };
    if (this.mode === "midi") {
      this.midiNote(note, duration, velocity, undefined, 0, expression);
      return;
    }
    this.voice(note, duration, 0.034, "sine", 0, expression);
    this.voice(
      note - 12,
      duration * 0.95,
      0.0144,
      "triangle",
      0.02,
      expression,
    );
  }
  wubDrone(note, duration = 2, tremolo = 3, density = 0.5) {
    this.report("wubDrone", { note, duration, tremolo, density });
    const velocity = 0.3 + 0.35 * density;
    if (this.mode === "midi") {
      this.midiNote(note, duration, velocity, undefined, 0, {instrument: "synthBass"});
      return;
    }
    const pulses = Math.max(
        1,
        Math.min(12, Math.round(duration * Math.max(0.2, tremolo))),
      ),
      step = duration / pulses;
    for (let index = 0; index < pulses; index++) {
      const offset = index * step;
      this.voice(
        note,
        Math.min(step * 0.72, 0.4),
        0.0246,
        index % 2 ? "sawtooth" : "square",
        offset,
        // A wobble is not even: the first pulse leads and the rest alternate strong and weak.
        {instrument: "synthBass", velocity: Math.min(1, velocity * (index === 0 ? 1.1 : index % 2 ? 0.84 : 0.97)),
          shape: {noiseLevel: 0.2 * velocity, noiseDecay: 0.01, noiseCutoff: Math.min(9000, 300 + note * 12)}},
      );
    }
  }
  kick() {
    this.percussion(36, /kick/i, () => this.drum("kick", 0.75));
  }
  softKick() {
    this.percussion(
      36,
      /kick/i,
      () => this.drum("softKick", 0.58),
      0.58,
      0.16,
    );
  }
  snare() {
    this.percussion(38, /snare/i, () => this.drum("snare", 0.76), 0.76, 0.1);
  }
  hat() {
    this.percussion(
      42,
      /hihat|click/i,
      () => this.drum("closedHat", 0.58),
      0.58,
      0.035,
    );
  }
  brush() {
    this.percussion(
      38,
      /snare|brush/i,
      () => this.drum("brush", 0.48, {duration: 0.24}),
      0.48,
      0.24,
    );
  }
  ride(a = 0.7) {
    this.percussion(
      51,
      /hihat|ride/i,
      () => this.drum("ride", 0.35 + 0.55 * a),
      0.35 + 0.55 * a,
      0.13,
    );
  }
  cleanPercussion(index, accent = 0.6) {
    // Preserve ae_PercBOT's auxiliary/cymbal-oriented orchestration rather
    // than silently turning it into another conventional kick/snare bot.
    const notes = [46, 50, 54, 56],
      filters = [3300, 4400, 5600, 7200],
      note = notes[index % notes.length],
      velocity = 0.35 + 0.55 * accent,
      duration = 0.045 + index * 0.018;
    this.percussion(
      note,
      new RegExp(`(?:perc|tom|conga|bongo|clave|${index + 1})`, "i"),
      () => this.drum("perc", velocity, {note, cutoffHz: filters[index % filters.length], duration,
        pan: [-0.35, 0.35, -0.15, 0.2][index % 4]}),
      velocity,
      duration,
    );
  }
  noiseDrum(kind) {
    const notes = { kick: 36, snare: 38, hat: 42 },
      note = notes[kind] ?? 42;
    this.percussion(note, /noise/i, () => {
      if (kind === "kick") this.drum("kick", 0.72, {pitch: 34});
      else if (kind === "snare") this.drum("snare", 0.72, {duration: 0.11});
      else this.drum("closedHat", 0.62, {duration: 0.035});
    });
  }
  noisePercussion(index, accent = 0.6) {
    const notes = [46, 48, 50, 53],
      filters = [700, 1200, 2400, 4800],
      note = notes[index % 4],
      velocity = 0.45 + 0.4 * accent;
    this.report("noisePercussion", { index, accent });
    if (this.mode === "midi") this.midiNote(note, 0.09, velocity, 9);
    else
      this.drum("perc", velocity, {note, cutoffHz: filters[index % 4], duration: 0.06 + index * 0.025,
        pan: [-0.3, 0.3, -0.12, 0.12][index % 4]});
  }
  // `offset`: seconds after the tick's time the hit sounds, for a contact between two ticks (a counted gesture's:
  // shared/performers/gestures.js).
  houseDrum(kind, accent = 0.7, strike = null, {offset = 0} = {}) {
    const notes = { kick: 36, snare: 38, closedHat: 42, openHat: 46 },
      patterns = {
        kick: /kick/i,
        snare: /snare/i,
        closedHat: /hihat|closed/i,
        openHat: /hihat|open/i,
      },
      note = notes[kind] ?? 42,
      duration =
        kind === "openHat"
          ? 0.14
          : kind === "snare"
            ? 0.09
            : kind === "kick"
              ? 0.14
              : 0.035,
      velocity = 0.3 + 0.65 * accent;
    this.percussion(
      note,
      patterns[kind] || /hihat/i,
      (at) => this.drum(DRUM_KIT[kind] ? kind : "closedHat", velocity, {...(kind === "kick" ? {pitch: 34} : {}), ...(strike ? {strike} : {}), offset: at}),
      velocity,
      duration,
      strike,
      offset,
    );
  }
  modulatedPercussion(
    index,
    accent = 0.7,
    { cutoff = 1200, delay = 0.08, feedback = 0.2 } = {},
  ) {
    const notes = [60, 62, 64],
      note = notes[index % 3];
    this.report("modulatedPercussion", {
      index,
      accent,
      cutoff,
      delay,
      feedback,
    });
    if (this.mode === "midi") {
      this.midiNote(note, 0.1, 0.35 + 0.55 * accent, 9);
      return;
    }
    if (this.mode === "samples") {
      this.sampleFile(
        this.sampleFiles[index % this.sampleFiles.length],
        1,
        0.35 + 0.55 * accent,
        0,
        0,
        null,
        { note, velocity: 0.35 + 0.55 * accent, duration: 0.1 },
      );
      return;
    }
    if (!this.ctx || this.muted) return;
    if(this.dspNode){
      // ae_PercBOT's resonant noise hit and its echoes: a bandpass whose Q rises with the index,
      // decaying to silence over the hit's length, each echo quieter by the feedback and duller
      // for being further away. Recorded once, as the drum it is.
      const duration=.055+index*.025,velocity=.35+.55*accent,q=2+index*1.5,
        shape={filterMode:2,resonance:Math.sqrt(Math.max(0,(q-.5)/11.5)),decay:duration*.8},
        hit=echo=>this.planNote(note,duration,{instrument:'shaker',velocity:velocity*(1-.12*echo),cutoffHz:cutoff*(1-.06*echo),
          offset:Math.max(0,Math.min(.75,delay))*echo,shape});
      const first=hit(0);
      this.scheduleDsp(1,note,duration,.35*accent,0,0,cutoff,{plan:first,skipCapture:true});
      for(let echo=1;echo<=6;echo++){
        const level=.35*accent*Math.max(0,Math.min(.48,feedback))**echo;
        if(level<1e-5)break;
        this.scheduleDsp(1,note,duration,level,Math.max(0,Math.min(.75,delay))*echo,0,cutoff,{plan:hit(echo),skipCapture:true});
      }
      this.captureUMP(note,duration,first.performance.velocity,0,first.performance,{fixedPercussion:true,channel:9},first);
      return;
    }
    const duration = 0.055 + index * 0.025,
      length = Math.ceil(this.ctx.sampleRate * duration),
      buffer = this.ctx.createBuffer(1, length, this.ctx.sampleRate),
      data = buffer.getChannelData(0);
    for (let i = 0; i < length; i++) data[i] = random() * 2 - 1;
    const source = this.ctx.createBufferSource(),
      filter = this.ctx.createBiquadFilter(),
      amp = this.ctx.createGain(),
      echo = this.ctx.createDelay(1),
      returnGain = this.ctx.createGain(),
      now = this.eventStart();
    source.buffer = buffer;
    filter.type = "bandpass";
    filter.frequency.value = Math.max(
      20,
      Math.min(this.ctx.sampleRate * 0.45, cutoff),
    );
    filter.Q.value = 2 + index * 1.5;
    amp.gain.setValueAtTime(0.08 * accent, now);
    amp.gain.exponentialRampToValueAtTime(0.0001, now + duration);
    echo.delayTime.value = Math.max(0, Math.min(0.75, delay));
    returnGain.gain.value = Math.max(0, Math.min(0.48, feedback));
    source.connect(filter).connect(amp);
    amp.connect(this.master);
    amp.connect(echo).connect(returnGain).connect(echo);
    returnGain.connect(this.master);
    source.start(now);
  }
  // `strike` (a tuned bot's, percussion-expression.js) goes to the kick and the tom; without one a hit is as it always was.
  papPercussion(kind, variant = 0, accent = 0.7, strike = null) {
    const notes = { kick: 36, mid: 45, noise: 42 },
      note = notes[kind] ?? 42,
      velocity = 0.4 + 0.5 * accent;
    this.report("papPercussion", { kind, variant, accent });
    if (this.mode === "midi") {
      if (kind !== "kick" || this.mayKick()) this.midiNote(note, 0.1, velocity, 9);
      return;
    }
    if (kind === "kick") {
      this.drum("kick", velocity, {pitch: 31, ...(strike ? {strike} : {})});
      return;
    }
    if (kind === "mid") {
      this.drum("tom", velocity, {pitch: 42 + variant * 3, note: 45 + (variant % 3) * 2, duration: 0.2, ...(strike ? {strike} : {})});
      return;
    }
    this.drum("perc", velocity, {note: 42, cutoffHz: [7200, 3200, 900][variant % 3], duration: 0.035 + 0.025 * variant});
  }
  mhBeatDrum(kind, accent = 0.7) {
    const notes = { kick: 36, snare: 38, cymbal: 42 },
      note = notes[kind] ?? 42,
      velocity = 0.35 + 0.55 * accent;
    this.report("mhBeatDrum", { kind, accent });
    if (this.mode === "midi") {
      this.midiNote(
        note,
        kind === "cymbal" ? 0.08 : 0.12,
        velocity,
        9,
      );
      return;
    }
    if (kind === "kick") this.drum("kick", velocity, {pitch: 34});
    else if (kind === "snare") this.drum("snare", velocity, {duration: 0.1});
    else this.drum("closedHat", velocity, {duration: 0.045});
  }
  mhBeatsynth(kind, accent = 0.7, config = {}) {
    const notes = config.midiNotes || [36, 38, 51],
      note = notes[kind] ?? 36,
      velocity = 0.35 + 0.55 * accent;
    this.report("mhBeatsynth", { kind, accent });
    if (this.mode === "midi") {
      this.midiNote(note, kind === 2 ? 0.12 : 0.2, velocity, 9);
      return;
    }
    if (kind === 0) {
      // A sub-bass thump, 15 to 26 Hz: the kick's sweep lands on it. The sweep is this bot's own, deep and long, and
      // not the TR-808's brief one, which from 20 Hz would leave nothing to hear but the thump.
      const [low, high] = config.bassFrequencyRange || [15, 26],
        frequency = low + random() * (high - low),
        midi = 69 + 12 * Math.log2(frequency / 440);
      // Its level, 0.55 of the kit's kick before that kick was raised for the 808 contour (0.07/0.0915 of it now).
      this.drum("kick", velocity, {pitch: midi, note, duration: 0.28, level: 0.4208,
        shape: {pitchEnv: 18 + 18 * velocity, pitchTime: 0.018 + 0.012 * (1 - velocity), pitchEnv2: 0, pitchTime2: 0}});
      return;
    }
    if (kind === 1) {
      this.drum("perc", velocity, {note, cutoffHz: 800 + random() * 50, duration: 0.13});
      return;
    }
    // Its cymbal is a cluster of detuned squares near 3 kHz, which is the metal model tuned up.
    const [detuneLow, detuneHigh] = config.cymbalDetuneRange || [0.99, 1.02],
      base = (config.cymbalFrequencies || [3000])[0] * (detuneLow + random() * (detuneHigh - detuneLow));
    this.drum("closedHat", velocity, {note, pitch: 69 + 12 * Math.log2(base / 440), duration: 0.075});
  }
  sampleBeatLoop(resonanceNote, step, accent = 0.7, config = {}, preset = 0) {
    const pattern = config.monitorPattern || {},
      kind = (pattern.kick || []).includes(step)
        ? "kick"
        : (pattern.snare || []).includes(step)
          ? "snare"
          : (pattern.hat || []).includes(step)
            ? "hat"
            : null,
      velocity = 0.4 + 0.45 * accent;
    this.report("sampleBeatLoop", { resonanceNote, step, kind, preset });
    if (this.mode === "midi") {
      if (kind)
        this.midiNote(
          config.midiNotes?.[kind] ?? 42,
          0.08,
          velocity,
          9,
        );
      if (step === 0) this.midiNote(resonanceNote, 0.35, 0.35, 0, 0, {instrument: "bell"});
      return;
    }
    if (kind === "kick") this.drum("kick", velocity, {pitch: 34, duration: 0.12});
    else if (kind === "snare") this.drum("snare", velocity, {duration: 0.09});
    else if (kind === "hat") this.drum("closedHat", velocity, {duration: 0.028});
    if (kind) {
      const gains = config.resonatorGainPresets?.[preset] || [0.5],
        gain = gains.reduce((sum, value) => sum + value, 0) / gains.length;
      this.voice(resonanceNote, 0.1, 0.018 * gain, "sine", 0, {instrument: "bell", velocity});
    }
  }
  autechreDrum(kind, accent = 0.7, effects = {}, offset = 0) {
    const notes = { kick: 36, snare: 38, hat: 42 },
      note = notes[kind] ?? 42,
      velocity = 0.35 + 0.55 * accent;
    this.report("autechreDrum", { kind, accent, effects, offset });
    if (this.mode === "midi") {
      this.midiNote(note, 0.07, velocity, 9, offset);
      return;
    }
    // The source bot crushes bits and sample rate: fewer bits are a quieter, grainier hit.
    const bitFactor = Math.max(0.2, Math.min(1, (effects.bits || 12) / 24)),
      cutoff = 300 + Math.max(0, Math.min(1, effects.sampleRate ?? 0.5)) * 9000,
      hit = (at, level) => {
        if (kind === "kick") this.drum("kick", velocity, {pitch: 32, offset: at, level, duration: 0.11});
        else if (kind === "snare") this.drum("snare", velocity, {offset: at, level, duration: 0.085, cutoffHz: Math.min(3200, cutoff)});
        else this.drum("closedHat", velocity, {offset: at, level, duration: 0.025});
      };
    hit(offset, bitFactor);
    if ((effects.wet || 0) > 0) hit(offset + (effects.delaySeconds || 0.1), bitFactor * Math.min(1, effects.wet) * 0.45);
  }
  prockRockDrum(index, activity = 3) {
    this.report("prockRockDrum", { index, activity });
    const notes = this.definition?.prockRockMidiNotes || [
        36, 38, 42, 46, 45, 47, 48, 50, 49, 51, 52, 53,
      ],
      velocity = 0.35 + Math.min(3, activity) * 0.18,
      note = notes[index % notes.length];
    if (this.mode === "midi") {
      this.midiNote(note, 0.1, velocity, 9);
      return;
    }
    if (this.mode === "samples") {
      this.sampleFile(
        this.sampleFiles[index % this.sampleFiles.length],
        1,
        0.7,
        0,
        0,
        null,
        { note, velocity, duration: 0.1 },
      );
      return;
    }
    if (index % 4 === 0) this.drum("kick", velocity, {pitch: 34, note});
    else if (index % 4 === 1) this.drum("snare", velocity, {note, duration: 0.09});
    else this.drum(index % 4 === 3 ? "openHat" : "closedHat", velocity, {note, duration: index % 4 === 3 ? 0.2 : 0.035});
  }
  rungler(v, a, note, waveform, velocity = 0.3 + (1 - v) * 0.3) {
    const duration = 0.08 + a * 0.22;
    if (this.mode === "midi") this.midiNote(note, duration, velocity, undefined, 0, {instrument: "synthPluck"});
    else
      this.voice(
        note,
        duration,
        (0.025 + (1 - v) * 0.035) * 1.35,
        waveform,
        0,
        { instrument: "synthPluck", velocity },
      );
  }
  effectMonitor(v, a) {
    this.report("effectMonitor", { v, a });
    this.voice(48 + v * 12, 0.15 + a * 0.25, 0.012, "sine", 0, {instrument: "organ", velocity: 0.55});
  }
  async microphone() {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true }),
      source = this.ctx.createMediaStreamSource(stream),
      analyser = this.ctx.createAnalyser(),
      samples = new Float32Array(1024),
      spectrum = new Uint8Array(512);
    analyser.fftSize = 1024;
    source.connect(analyser);
    return {
      stop() {
        stream.getTracks().forEach((track) => track.stop());
      },
      features() {
        analyser.getFloatTimeDomainData(samples);
        analyser.getByteFrequencyData(spectrum);
        let sum = 0,
          weighted = 0,
          total = 0;
        samples.forEach((x) => (sum += x * x));
        spectrum.forEach((x, i) => {
          weighted += x * i;
          total += x;
        });
        const loudness = Math.sqrt(sum / samples.length),
          centroid = total ? weighted / total / spectrum.length : 0;
        return {
          loudness,
          centroid,
          activity: Math.min(1, loudness * 12),
          arousal: Math.min(1, loudness * 8 + centroid * 0.3),
          valence: Math.max(0, Math.min(1, 0.7 - centroid * 0.35)),
        };
      },
    };
  }
}
