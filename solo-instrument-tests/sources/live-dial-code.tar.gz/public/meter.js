(function(root,factory){root.MusebotMeter=factory()})(globalThis,()=>{
  const integer=(value,fallback,min=1,max=4096)=>{const number=Number(value);return Number.isInteger(number)&&number>=min&&number<=max?number:fallback};
  function defaultGrouping(n){if(n===1)return[1];const groups=[],threes=Math.floor(n/3),remainder=n%3;if(remainder===1){for(let i=0;i<threes-1;i++)groups.push(3);groups.push(2,2)}else{for(let i=0;i<threes;i++)groups.push(3);if(remainder===2)groups.push(2)}return groups}
  // A clave keeps its direction ('3-2', '2-3') and the record it came from (shared/rhythm-vocabulary.js).
  function normalizeRhythm(value,steps){const source=value&&typeof value==='object'?value:{},hits=source.hits===''||source.hits==null?null:integer(source.hits,null,0,steps),rotation=Number.isInteger(Number(source.rotation))?Number(source.rotation):0,clave=Array.isArray(source.clave)?[...new Set(source.clave.map(Number).filter(Number.isInteger).map(item=>((item%steps)+steps)%steps))].sort((a,b)=>a-b):[];return{hits,rotation,clave,...(['3-2','2-3'].includes(source.direction)?{direction:source.direction}:{}),...(typeof source.vocabulary==='string'&&source.vocabulary&&source.vocabulary.length<=64?{vocabulary:source.vocabulary}:{})}}
  // A named cycle's record, as the clock carries it (shared/rhythm-vocabulary.js meterOfTala): its id and a gesture (and a
  // component) for each beat, null where it has none.
  function normalizeVocabulary(value,numerator){if(!value||typeof value!=='object'||typeof value.id!=='string'||!value.id||value.id.length>64)return null;const beats=list=>Array.isArray(list)&&list.length===numerator?list.map(item=>typeof item==='string'&&item&&item.length<=24?item:null):null;const out={id:value.id,gestures:beats(value.gestures)||Array(numerator).fill(null)};const components=beats(value.componentOfBeat);if(components)out.componentOfBeat=components;if(Array.isArray(value.bass)&&value.bass.length===numerator)out.bass=value.bass.map(item=>item===true);for(const key of['tradition','name','nadai'])if(typeof value[key]==='string'&&value[key].length<=64)out[key]=value[key];if(Number.isInteger(value.speed))out.speed=value.speed;return out}
  // A long bar's sections and their dynamics, as meter.cjs keeps them.
  function normalizeSections(value,numerator){if(!Array.isArray(value)||!value.length)return null;const levels=typeof value[0]==='number'?[value]:value,sum=list=>list.reduce((a,b)=>a+b,0),starts=level=>{let at=0;return level.map(size=>{const start=at;at+=size;return start})};if(!levels.every(level=>Array.isArray(level)&&level.length>=2&&level.every(size=>Number.isSafeInteger(size)&&size>0)&&sum(level)===numerator))return null;for(let i=1;i<levels.length;i++){const below=new Set(starts(levels[i]));if(!starts(levels[i-1]).every(start=>below.has(start)))return null}return levels.map(level=>[...level])}
  function normalizeSectionDynamics(value,sections){return sections&&Array.isArray(value)&&value.length===sections[0].length&&value.every(item=>Number.isFinite(item)&&item>0&&item<=2)?[...value]:null}
  // Intended beat/reference metadata; kept in parity with shared/meter-reading.js.
function normalizeMetricReading(reading,numerator,groups){
  if(!reading||reading.version!==1||typeof reading.id!=='string'||!reading.id||reading.id.length>160)return null;
  const weights=reading.beatWeights,partition=reading.beatGroups,ref=reading.reference;
  if(!Array.isArray(weights)||!weights.length||weights.length>256||!weights.every(n=>Number.isSafeInteger(n)&&n>0)||weights.reduce((a,b)=>a+b,0)!==numerator)return null;
  if(!Array.isArray(partition)||!partition.length||!partition.every(n=>Number.isSafeInteger(n)&&n>0)||partition.reduce((a,b)=>a+b,0)!==weights.length)return null;
  let at=0;const spans=partition.map(n=>{const total=weights.slice(at,at+n).reduce((a,b)=>a+b,0);at+=n;return total});
  if(spans.join()!==groups.join()||!ref||![1,2,4,8,16,32,64].includes(ref.unit)||![0,1].includes(ref.dots))return null;
  if(!['standard','grouped','specialist'].includes(reading.kind)||!['PUBLISH_STANDARD','PUBLISH_GROUPED','PUBLISH_SPECIALIST_WITH_LEGEND','KEEP_WITH_SUPPORT','PREFER_LOCAL_BARS_WITH_CYCLE_BRACKET','HOLD_FOR_REVIEW','FREE_TIME_BY_INTENT'].includes(reading.editorialAction))return null;
  return {version:1,id:reading.id,beatWeights:[...weights],beatGroups:[...partition],reference:{unit:ref.unit,dots:ref.dots},
    kind:reading.kind,editorialAction:reading.editorialAction,profile:'score-selection-v2',confidence:null,
    preserveDenominator:true,...(typeof reading.reason==='string'?{reason:reading.reason.slice(0,512)}:{})};
}
function normalizeMeter(value={}){
    const numerator=integer(value.numerator,4),denominator=integer(value.denominator,4),subdivision=integer(value.subdivision,4,1,96),phraseBars=integer(value.phraseBars,4,1,1024);
    let groups=Array.isArray(value.groups)?value.groups.map(item=>integer(item,0)).filter(Boolean):[];
    if(!groups.length||groups.reduce((sum,item)=>sum+item,0)!==numerator)groups=defaultGrouping(numerator);
    const pulsesPerBar=numerator*subdivision,vocabulary=normalizeVocabulary(value.vocabulary,numerator),tempoUnit=TEMPO_UNITS.includes(Number(value.tempoUnit))?Number(value.tempoUnit):null,sections=normalizeSections(value.sections,numerator),sectionDynamics=normalizeSectionDynamics(value.sectionDynamics,sections),metricReading=normalizeMetricReading(value.metricReading,numerator,groups);
    return{numerator,denominator,groups,subdivision,phraseBars,rhythm:normalizeRhythm(value.rhythm,pulsesPerBar),label:value.label||`${groups.join('+')}/${denominator}`,pulsesPerBar,...(vocabulary?{vocabulary}:{}),...(tempoUnit?{tempoUnit}:{}),...(sections?{sections}:{}),...(sectionDynamics?{sectionDynamics}:{}),...(metricReading?{metricReading}:{}),...(value.fixedDenominator===true?{fixedDenominator:true}:{})};
  }
  function parseMeter(signature,groups='',subdivision=4,phraseBars=4){const match=String(signature).trim().match(/^(\d+)\s*\/\s*(\d+)$/);if(!match)throw new Error('Time signature must look like 7/8');const supplied=String(groups).trim(),parsed=supplied?supplied.split(/[+,\s]+/).map(Number):[];const meter=normalizeMeter({numerator:Number(match[1]),denominator:Number(match[2]),groups:parsed,subdivision:Number(subdivision),phraseBars:Number(phraseBars)});if(supplied&&meter.groups.join(',')!==parsed.join(','))throw new Error('Positive additive groups must sum to the numerator');return meter}
  function clockContext(state){const meter=state.meter,tickInBar=state.tickInBar,beat=Math.floor(tickInBar/meter.subdivision),groupStarts=[],groups=meter.groups;let total=0;for(const size of groups){groupStarts.push(total);total+=size}let group=0;while(group+1<groupStarts.length&&beat>=groupStarts[group+1])group++;return{tick:state.tick,bpm:state.bpm,meter,bar:state.bar,phrase:Math.floor(state.bar/meter.phraseBars),tickInBar,beat,subdivision:tickInBar%meter.subdivision,group,groupBeat:beat-groupStarts[group],barStart:tickInBar===0,beatStart:tickInBar%meter.subdivision===0,groupStart:tickInBar===groupStarts[group]*meter.subdivision,phraseStart:tickInBar===0&&state.bar%meter.phraseBars===0,...(meter.vocabulary?{gesture:meter.vocabulary.gestures?.[beat]??null}:{})}}
  // The note a meter's tempo counts, where it declares one (as meter.cjs: the rate contract's score coordinate).
  const TEMPO_UNITS=Object.freeze([1,2,4,8,16,32,64]),TEMPO_LIMITS=Object.freeze({notated:Object.freeze([40,220]),coordinate:Object.freeze([30,720])});
  function unitsPerTempoBeat(meter){const unit=Number(meter&&meter.tempoUnit),denominator=Number(meter&&meter.denominator)||4;return unit>0?denominator/unit:1}
  function tempoRange(meter){const limits=meter&&meter.tempoUnit?TEMPO_LIMITS.coordinate:TEMPO_LIMITS.notated,units=unitsPerTempoBeat(meter);return[limits[0]*units,limits[1]*units]}
  function clampTempo(bpm,meter){const range=tempoRange(meter);return Math.max(range[0],Math.min(range[1],bpm))}
  function namedTempo(bpm,meter){return bpm/unitsPerTempoBeat(meter)}
  return{normalizeMeter,parseMeter,clockContext,defaultGrouping,TEMPO_LIMITS,unitsPerTempoBeat,tempoRange,clampTempo,namedTempo};
});
