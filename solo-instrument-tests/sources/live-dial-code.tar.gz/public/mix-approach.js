// A mix approach (public/shared/mix-approaches.js) put onto an ensemble mixer (audio-mixer.js):
// the effects and the bus compression, each channel's strip by the role its bot plays, the buses
// and the sidechain -- and all of it taken back off by restore(). The plan decides; this only
// builds, and keeps building as bots join and their roles become known.
//
// Two things it does over time rather than once:
//
//   * **Thresholds follow the level.** An engineer sets a compressor by the gain reduction it
//     makes, not by a number read off a page, because the right threshold depends on how loud
//     the part is. Each compressor here is steered, a decibel at a step, toward the reduction
//     its role's strip names -- only while its channel is actually sounding near the threshold,
//     so a bar's rest is not read as "not compressing enough".
//   * **Roles arrive late.** A channel's role is learned from what its bot plays (audio.js),
//     so a channel is fitted as 'other' first and refitted when its role is known.
//
// The long reverb's send is left to a desk's space duty, which shares it by how many are
// playing, and which this weights by role (see LiveDesk). Without a desk, `reverbSends` sets
// the sends itself. The short room's send is the approach's by role, unless a desk's placement
// duty stands each part in the room (`roomSends: false`), from the approach's send upward. And the
// buses are the approach's to make and route into unless a desk's submix duty groups the band
// (`routing: false`: experiments/mix-desk/submix.js): then an approach's bus strip lands on the
// desk's bus of the same name (the studio approach's bus:drums on the drums' group), and every
// other bus, whoever made it, is fitted with nothing.
export const APPROACH_APPLY = Object.freeze({
  rampSeconds: 1.5,         // a change of approach is heard as a move, not a switch
  stepDb: 1,                // how far a threshold moves in one steering step
  deadBandDb: 1.25,         // how close to its target reduction counts as there
  activeMarginDb: 18,       // a channel is sounding "near the threshold" within this of it
  thresholdRange: [-45, -3],
  soloReverbSend: 0.35,     // the long-reverb send at weight 1 when there is no desk to share it; ours
});

const EMPTY_SENDS = Object.freeze({room: 0, delay: 0, chorus: 0, drive: 0, compression: 0});

export class ApproachApplier {
  constructor(mixer, {reverbSends = false, roomSends = true, routing = true, rules = {}} = {}) {
    this.mixer = mixer;
    this.reverbSends = reverbSends;
    this.roomSends = roomSends;
    this.routing = routing;
    // Channels whose compression a desk's punch duty has taken over (experiments/mix-desk/punch.js): their strip's
    // compressor, if any, is left at 1:1.
    this.punched = new Set();
    this.rules = {...APPROACH_APPLY, ...rules};
    this.plan = null;
    this.fitted = new Map();       // channel -> {role, inserts: {eq, compress, duck, width}, before, queue}
    this.buses = new Set();        // the buses this made
    this.before = null;            // the mixer as it was found
  }
  get context() {return this.mixer.context}

  apply(plan, {atSeconds = this.context.currentTime} = {}) {
    if (!this.before) this.before = {effects: {...this.mixer.settings},
      busCompression: this.mixer.busCompression ? {...this.mixer.busCompression} : {ratio: 1, thresholdDb: 0, makeupDb: 0}};
    this.plan = plan;
    this.mixer.setEffects(plan.effects, {atSeconds, seconds: this.rules.rampSeconds});
    const bus = plan.busCompression;
    this.busThreshold = bus ? bus.thresholdDb : 0;
    this.mixer.setBusCompression(bus ? {thresholdDb: bus.thresholdDb, ratio: bus.ratio, knee: bus.knee, attack: bus.attack,
      release: bus.release, makeupDb: 0} : {ratio: 1, thresholdDb: 0, makeupDb: 0}, {atSeconds, seconds: this.rules.rampSeconds});
    this.makeBuses();
    this.refresh({force: true});
    return this;
  }
  // Buses this approach does not have go, and what fed them goes back to the master; with the routing a desk's, all of
  // this one's go.
  makeBuses() {
    const wanted = new Set(this.routing ? this.plan.buses.map(bus => bus.id) : []);
    for (const id of [...this.buses]) if (!wanted.has(id)) {this.mixer.tracks.get(id)?.disconnect(); this.buses.delete(id); this.fitted.delete(id)}
    if (this.routing) for (const spec of this.plan.buses) if (!this.mixer.tracks.has(spec.id)) {this.mixer.bus(spec.id); this.buses.add(spec.id)}
  }

  // Fit new channels and changed roles, route by role, and steer the compressors. Cheap when
  // nothing has changed; a desk calls it at every decision.
  refresh({force = false, active = null, masterLufs = null} = {}) {
    const plan = this.plan;
    if (!plan) return this;
    for (const [id, track] of this.mixer.tracks) {
      const role = this.buses.has(id) || track.bus ? `bus:${id}` : track.role || 'other', fitted = this.fitted.get(id);
      if (force || !fitted || fitted.role !== role) this.fit(id, track, role);
    }
    for (const id of [...this.fitted.keys()]) if (!this.mixer.tracks.has(id)) this.fitted.delete(id);
    this.route();
    this.steer(active, {masterLufs});
    return this;
  }

  stripFor(id, role) {
    const plan = this.plan;
    if (role.startsWith('bus:')) return plan.buses.find(bus => bus.id === id)?.strip ?? null;
    return plan.roles[role] || plan.roles.other;
  }

  fit(id, track, role) {
    const strip = this.stripFor(id, role);
    const fitted = this.fitted.get(id) || {role, inserts: {}, before: {...track.settings}, queue: Promise.resolve()};
    fitted.role = role; this.fitted.set(id, fitted);
    if (!strip) return;
    const at = this.context.currentTime, seconds = this.rules.rampSeconds;
    // Sends: this approach's, and every one it does not use closed.
    const sends = {...EMPTY_SENDS, ...(role.startsWith('bus:') ? {} : strip.sends)};
    if (this.reverbSends && !role.startsWith('bus:')) sends.reverb = Math.round(this.rules.soloReverbSend * strip.reverbWeight * 1000) / 1000;
    if (!this.roomSends && !role.startsWith('bus:')) delete sends.room;
    track.set(sends, {atSeconds: at, seconds});
    // Inserts, in the order a strip has them: filters, compressor, the sidechain's duck, width.
    // Built once each and then only set, so a change of approach moves them rather than rebuilding.
    const sidechain = this.plan.sidechain, ducked = Boolean(sidechain && sidechain.to.includes(role));
    fitted.queue = fitted.queue.then(async () => {
      const inserts = fitted.inserts;
      if (strip.hpf || strip.lpf || inserts.eq) {
        inserts.eq ??= await track.addInsert('eq', {});
        track.inserts.get(inserts.eq)?.processor.set({highpass: {hz: strip.hpf || 0, slope: 12}, lowpass: {hz: strip.lpf || 0}}, {atSeconds: at, seconds});
      }
      if (strip.dynamics && !this.punched.has(id) || inserts.compress) {
        const settings = strip.dynamics && !this.punched.has(id) ? {...strip.dynamics} : {ratio: 1};
        if (!inserts.compress) inserts.compress = await track.addInsert('dynamics', {mode: 'compress', ...settings});
        else track.inserts.get(inserts.compress)?.processor.set(settings, {atSeconds: at, seconds});
        fitted.target = this.punched.has(id) ? null : strip.dynamics?.targetDb ?? null;
        fitted.threshold = strip.dynamics?.threshold ?? fitted.threshold ?? -20;
        fitted.reduction = 0;
      }
      if (ducked || inserts.duck) {
        const from = this.keySource(sidechain?.from);
        if (ducked && !inserts.duck && from) inserts.duck = await track.addInsert('dynamics', {...sidechain.dynamics, keyFrom: from, keyFilterHz: sidechain.keyFilterHz});
        else if (inserts.duck) {
          track.inserts.get(inserts.duck)?.processor.set(ducked ? sidechain.dynamics : {range: 0}, {atSeconds: at, seconds});
          if (ducked && from) this.mixer.keyInsert(id, inserts.duck, from, {filterHz: sidechain.keyFilterHz});
        }
        fitted.keyedFrom = ducked ? from : null;
      }
      if (strip.width !== 1 || inserts.width) {
        inserts.width ??= await track.addInsert('width', {width: 1});
        track.inserts.get(inserts.width)?.processor.set({width: strip.width, seconds});
      }
    }).catch(error => {fitted.error = error.message});
    return fitted.queue;
  }

  // The channel a sidechain listens to: the first channel playing the role it names.
  keySource(role) {
    if (!role) return null;
    for (const [id, track] of this.mixer.tracks) if (track.role === role && !this.buses.has(id) && !track.bus) return id;
    return null;
  }

  // Channels into the buses their roles belong to, and out of buses they no longer belong to (unless the routing is a
  // desk's).
  route() {
    const byRole = new Map();
    if (this.routing) for (const bus of this.plan.buses) for (const role of bus.roles) byRole.set(role, bus.id);
    for (const [id, track] of this.mixer.tracks) {
      if (this.buses.has(id) || track.bus || !this.routing) continue;
      const target = byRole.get(track.role) ?? null;
      if (target !== track.route && (target !== null || this.buses.has(track.route))) {
        try {track.routeTo(target)} catch {}
      }
    }
    // A sidechain whose key channel has left, or arrived, is re-keyed at the next fit.
    const sidechain = this.plan.sidechain;
    if (sidechain) for (const [id, fitted] of this.fitted) {
      const source = this.keySource(sidechain.from);
      if (fitted.inserts.duck && source && fitted.keyedFrom !== source) {
        this.mixer.keyInsert(id, fitted.inserts.duck, source, {filterHz: sidechain.keyFilterHz});
        fitted.keyedFrom = source;
      } else if (!fitted.inserts.duck && source && sidechain.to.includes(fitted.role)) this.fit(id, this.mixer.tracks.get(id), fitted.role);
    }
  }

  // The channels whose compression a desk's punch duty has taken over: each fitted again when it joins or leaves them.
  setPunched(ids) {
    const next = new Set(ids);
    const changed = [...next].filter(id => !this.punched.has(id)).concat([...this.punched].filter(id => !next.has(id)));
    this.punched = next;
    for (const id of changed) {const track = this.mixer.tracks.get(id), fitted = this.fitted.get(id); if (track && fitted) this.fit(id, track, fitted.role)}
    return this;
  }

  // The routing handed to a desk (false: the buses this made go, and their channels back to the master) or taken back.
  setRouting(routing) {
    this.routing = Boolean(routing);
    if (this.plan) {this.makeBuses(); this.refresh({force: true})}
    return this;
  }

  // Each compressor toward its role's reduction, and the bus's toward its own.
  steer(active = null, {masterLufs = null} = {}) {
    const {stepDb, deadBandDb, activeMarginDb, thresholdRange: [low, high]} = this.rules;
    for (const [id, fitted] of this.fitted) {
      if (!fitted.inserts.compress || fitted.target === null || fitted.target === undefined) continue;
      if (active && !active.includes?.(id) && !active.has?.(id)) continue;
      const processor = this.mixer.tracks.get(id)?.inserts.get(fitted.inserts.compress)?.processor;
      if (!processor?.reduction) continue;
      const level = processor.level?.() ?? -180;
      if (level < fitted.threshold - activeMarginDb) continue;
      fitted.reduction = 0.7 * fitted.reduction + 0.3 * -processor.reduction();
      let next = fitted.threshold;
      if (fitted.reduction < fitted.target - deadBandDb) next -= stepDb;
      else if (fitted.reduction > fitted.target + deadBandDb) next += stepDb;
      next = Math.max(low, Math.min(high, next));
      if (next !== fitted.threshold) {fitted.threshold = next; processor.set({threshold: next}, {seconds: 0.5})}
    }
    const bus = this.plan.busCompression, compressor = this.mixer.busCompressor;
    if (bus?.targetReductionDb && compressor && masterLufs !== null && masterLufs > -45) {
      const reduction = -(compressor.reduction ?? 0);
      let next = this.busThreshold;
      if (reduction < bus.targetReductionDb - deadBandDb) next -= stepDb;
      else if (reduction > bus.targetReductionDb + deadBandDb) next += stepDb;
      next = Math.max(-40, Math.min(0, next));
      if (next !== this.busThreshold) {
        this.busThreshold = next;
        this.mixer.setBusCompression({...this.mixer.busCompression, thresholdDb: next}, {seconds: 0.5});
      }
    }
    return this;
  }

  // Resolves when every channel's inserts are built, and the mixer's own lazy parts with them: a
  // render waits on this before it goes on, so an insert never lands at a frame that depends on
  // how quickly a module happened to load.
  async settled() {
    await Promise.all([...this.fitted.values()].map(fitted => fitted.queue));
    await Promise.all([this.mixer.zeroLatency, this.mixer.limiter].filter(Boolean));
    return this;
  }

  // What each channel is and what it was given, for a display or a plan to carry.
  state() {
    return {approach: this.plan?.approach ?? null, describe: this.plan?.describe ?? null, wetLu: this.plan?.wetLu ?? null,
      buses: [...this.buses], busThreshold: this.busThreshold ?? null,
      channels: Object.fromEntries([...this.fitted].map(([id, fitted]) => [id, {role: fitted.role,
        inserts: Object.keys(fitted.inserts).filter(key => fitted.inserts[key]), threshold: fitted.threshold ?? null,
        reduction: fitted.reduction === undefined ? null : Math.round(fitted.reduction * 10) / 10, error: fitted.error ?? null}]))};
  }

  // Everything back: inserts out, channels to the master, their sends as found, buses gone, the
  // effects and the bus compression as they were.
  async restore({atSeconds = this.context.currentTime} = {}) {
    for (const [id, fitted] of this.fitted) {
      await fitted.queue;
      const track = this.mixer.tracks.get(id);
      if (!track || this.buses.has(id)) continue;
      for (const insert of Object.values(fitted.inserts)) if (insert) track.inserts.remove(insert);
      for (const link of [...this.mixer.keys]) if (link.trackId === id) {link.filter?.disconnect(); this.mixer.keys.delete(link)}
      const sends = Object.fromEntries(Object.keys(EMPTY_SENDS).filter(key => this.roomSends || key !== 'room').map(key => [key, fitted.before[key] ?? 0]));
      if (this.reverbSends) sends.reverb = fitted.before.reverb ?? 0;
      track.set(sends, {atSeconds, seconds: this.rules.rampSeconds});
      if (track.route && this.buses.has(track.route)) {try {track.routeTo(null)} catch {}}
    }
    for (const id of this.buses) this.mixer.tracks.get(id)?.disconnect();
    this.buses.clear(); this.fitted.clear();
    if (this.before) {
      this.mixer.setEffects(this.before.effects, {atSeconds, seconds: this.rules.rampSeconds});
      this.mixer.setBusCompression(this.before.busCompression, {atSeconds, seconds: this.rules.rampSeconds});
    }
    this.plan = null; this.before = null;
    return this;
  }
}
