import { MemoryTransfers, sendMemoryMessage } from '../shared/memory-transfer.js';
import { cyclicPattern } from '../stochastic-algorithms.js';
import { normalizePitchPool } from '../shared/pitch.js';
import { canonicalProtocolAddress } from '../shared/protocol-contract.js';
import { validateProtocolArgs } from '../shared/protocol-schemas.js';
import { compareLogicalPosition, logicalPosition, PlanCoordinator } from '../shared/planning.js';
import { validateTuningPayload } from '../shared/tuning.js';
import { parseCompoundIntent } from '../shared/intentions.js';
import { transformMotif, validateMotif, motifNotes } from '../shared/motifs.js';
import { inspectUMP } from '../shared/ump.js';
import { musicalAccent } from '../shared/expression.js';
import { unitRandom } from '../shared/stochastic.js';
import { aesthetic, AESTHETIC_AXES } from '../shared/aesthetic.js';
import { castingAnswer } from '../shared/casting/respond.js';
import { streamClock, streamOf } from '../shared/rhythm-vocabulary.js';
import { changed as changedTimeMap, glideAt, positionAt, rateAt, rational, sharedAt, ticksIn, timeMap, toNumber } from '../shared/part-time-map.js';
import { secondsPerTick } from '../shared/meter-tactus.js';
import { ExecutionLedger } from '../shared/execution-ledger.js';
import { answerMeter, answerTala, meterPolicy, planAnswer } from '../shared/meter-policy.js';
import { DESCRIPTORS_ADDRESS, DescriptorReader } from '../shared/estimation/audio-descriptor-schema.js';
import { GroupTree } from '../shared/conducting/groups.js';
import { ensembleSeed } from '../random-source.js';
import { chordOver, openingHarmony, openingProgression, poolOver, preferredTonic } from '../shared/opening-harmony.js';
import { openingClock, openingTime ,bandMeter} from '../shared/opening-time.js';
import {bandPhraseBars} from '../shared/opening-time.js';

const FOLLOW=meterPolicy('follow');
// Whether two meters count a bar differently: its beats, their note, their ticks, or its grouping.
const meterChanged=(a,b)=>a.numerator!==b.numerator||a.denominator!==b.denominator||a.subdivision!==b.subdivision||(a.groups??[]).join('+')!==(b.groups??[]).join('+');

const MAX_PLAN_HISTORY=512;
function boundMap(map,limit=MAX_PLAN_HISTORY){while(map.size>limit)map.delete(map.keys().next().value)}
function boundArray(array,limit=MAX_PLAN_HISTORY){if(array.length>limit)array.splice(0,array.length-limit)}

// Shared behavioural substrate. Bot modules subclass Agent and override only
// their distinctive message/tick/audio decisions.
export class Agent {
  constructor(send,audio){this.memoryTransfers=new MemoryTransfers();Object.defineProperty(this,'groupTree',{value:new GroupTree(),writable:true,configurable:true,enumerable:false});this.send=(address,args)=>sendMemoryMessage(send,address,args);this.audio=audio;this.ensembleSeed=ensembleSeed();this.notes=[...this.bandOpening.chord];this.density=this.bandTime.density;this.tala=this.openingTala=[...this.bandTime.tala];this.mixPlacement=0;this.synchronizeTimeSignature=true;this.capabilities={tuning:false,harmony:false,rhythm:false,motif:false,orchestration:false,form:false,lifecycle:false};this.plans=new PlanCoordinator('local');this.memoryResponses=[];this.receivedPlans=new Map;this.planResponses=[];this.futurePlans=new Map;this.tuningPlans=new Map;this.appliedPlans=new Set;this.activeTuningKey=null;const receive=this.onMessage.bind(this);this.onMessage=message=>{this.checkProtocol(message);if(message?.address==='/agent/memory/transfer'){if(!this.targeted(message))return;try{message=this.memoryTransfers.accept(message)}catch(error){this.audio?.report?.('memory_transfer_rejected',{error:error.message});return}if(!message)return}this.ingestPlanning(message);if(this.outrankedHarmony(message))return;this.ingestMemoryResponse(message);this.groupTree.hear(message,{bar:Number.isInteger(this.currentClock?.bar)?this.currentClock.bar:undefined});this.ingestDirectLifecycle(message);this.ingestMixPlacement(message);this.ingestCharacter(message);this.ingestDescriptor(message);return receive(message)};const tick=this.onTick?.bind(this);if(tick)this.onTick=(number,clock)=>{clock??=openingClock(this.ensembleSeed,number);this.observeClock(clock||{});if(this.ensembleStopped||this.silencedAt!==undefined&&this.silencedAt===clock?.tick)return;return this.tickAsPart(tick,number,clock)}}
  // A received message's shape (protocol-schemas.js). A relay refuses a malformed one, so one that arrives here came by
  // a path with no relay's check (Max's local bus, an older server): it is reported, once an address, and read as ever,
  // each agent's own robust interpretation deciding what of it to use (docs/MUSEBOT_PROTOCOL.md, "Message schemas").
  checkProtocol(message){
    if(typeof message?.address!=='string')return;
    const checked=validateProtocolArgs(message.address,message.args??[]);
    if(checked.valid)return;
    const count=((this.protocolInvalid??=new Map).get(message.address)??0)+1;this.protocolInvalid.set(message.address,count);
    if(count===1)this.audio?.report?.('protocol_invalid',{address:message.address,source:message.source??null,errors:checked.errors.slice(0,3)});
  }
  onMessage(message){
    if(message.address==='/system/instance')this.setIdentity(message.args[0]);
    // The pool heard: `poolHeard` tells it from the pool a bot starts with, which no one played.
    if(message.address.endsWith('/notepool')){const notes=normalizePitchPool(message.args);if(notes.length){this.notes=notes;this.poolHeard=true}}
    if(message.address.endsWith('/hdensity')){const density=Number(message.args.at(-1));if(Number.isFinite(density))this.density=Math.max(0,Math.min(1,density))}
    if(message.address.endsWith('/tala'))this.answerProposedTala(message.args);
    if(message.address.endsWith('/timeSignature')&&this.synchronizeTimeSignature)this.requestedMeter=message.args[0];
    // A part's own stream, from a conductor that modulates parts apart (/agent/stream, targeted: {target, stream, anchor}):
    // taken on at its anchor, the shared tick it begins on, or ended there where the stream is null (interpretClock).
    // Several parts, each told its own, modulate at once, each in its own relation to the shared tick (2a, 28 September).
    // A `relation` beside it is the part's own tempo relation to the ensemble, any ratio, held or glided to (relateStream);
    // told a relation with no stream, a part in a stream changes its relation only, its bars counted on.
    if(message.address==='/agent/stream'&&this.targeted(message)){const value=message.args?.[0]||{},relation=value.relation&&typeof value.relation==='object'?value.relation:null;(this.pendingStreams??=[]).push({stream:value.stream??null,anchor:Number.isSafeInteger(value.anchor)?value.anchor:null,relation,relationOnly:relation!==null&&!('stream' in value)});this.pendingStreams.sort((a,b)=>(a.anchor??-Infinity)-(b.anchor??-Infinity));if(this.pendingStreams.length>32)this.pendingStreams.shift()}
    if(message.address==='/agent/space'&&this.targeted(message)){const value=message.args?.[0]||{};this.spaceRequests||=[];this.spaceRequests.push({...value,appliesAt:value.appliesAt||logicalPosition(this.currentClock||{})});if(this.spaceRequests.length>32)this.spaceRequests.shift()}
  }
  ingestPlanning(message){
    let planning;try{planning=this.plans.ingest(message)}catch(error){this.planningErrors||=[];this.planningErrors.push({message,error:error.message});if(this.planningErrors.length>32)this.planningErrors.shift();this.audio?.report?.('planning_message_rejected',{address:message?.address,error:error.message});return}
    if(planning?.type==='plan'){this.receivedPlans.set(planning.plan.planId,planning.plan);boundMap(this.receivedPlans);this.onPlan(planning.plan,message)}
    if(planning?.type==='response'){this.planResponses.push(planning.response);boundArray(this.planResponses);this.onPlanResponse(planning.response,message)}
  }
  broadcast(name,args=[]){
    const address=canonicalProtocolAddress(name,{broadcastName:true}),values=Array.isArray(args)?args:[args];this.send(address,values);
    if(address==='/broadcast/intent'&&this.currentClock){
      const intent=parseCompoundIntent({address,args:values}),clock=this.currentClock,phraseBars=clock.meter?.phraseBars||bandPhraseBars(),createdAt={bar:clock.bar||0,phrase:clock.phrase||0,section:clock.section||0},appliesAt={bar:createdAt.bar+phraseBars,phrase:createdAt.phrase+1,section:createdAt.section};
      this.publishPlan('rhythm',{schemaVersion:1,intent,tala:intent?.talaStructure||[],activityMask:intent?.activityMask||[],pitchclassPool:intent?.pitchclassPool||[]},{createdAt,appliesAt,expiresAt:{...appliesAt,bar:appliesAt.bar+phraseBars,phrase:appliesAt.phrase+1},horizon:1,confidence:.62,priority:.5,rationale:'Atomic compatibility envelope for this bot’s legacy next-phrase intention.'});
    }
  }
  // The identity its own draws are keyed by: randomIdentity where a render gives one (a spec's randomKey: render/spec.js),
  // else its instance id.
  get seedIdentity(){return this.randomIdentity??this.instanceId}
  // The band's harmony before any is heard (shared/opening-harmony.js): drawn from the piece's seed, the same for every
  // bot of the piece, never a chord written here. Its pool a bot starts from is the opening's chord.
  get bandOpening(){return openingHarmony(this.ensembleSeed)}
  // The band's time before any is set (shared/opening-time.js): its meter, tempo, phrase, tala and density, drawn from
  // the piece's seed. Its tala and density are a bot's first.
  get bandTime(){return openingTime(this.ensembleSeed)}
  // The opening's chord (or, of: 'collection', its collection) over a bot's own register [low, high].
  openingPool(register,{of='chord'}={}){return poolOver(this.bandOpening,register,{of})}
  // `voices` of the opening's chord spread over [low, high].
  openingChord(register,voices){return chordOver(this.bandOpening,register,voices)}
  // The opening chord's pitch classes (semitones, any fraction), its lowest first: for a bot that keeps classes.
  openingClasses(){return [...new Set(this.bandOpening.chord.map(pitch=>+(((pitch%12)+12)%12).toFixed(6)))]}
  // `count` chords drawn from the opening's collection, the first its chord: for a bot that starts from a progression.
  openingProgression(count){return openingProgression(this.ensembleSeed,count)}
  // A tonic near `pitch` for a bot that prefers its class: the preference, at most half the time, else the band's.
  preferredTonic(pitch,{strength}={}){return preferredTonic(this.ensembleSeed,{pitch,strength,identity:this.constructor.name})}
  setIdentity(value){this.instanceId=String(value||'local');this.plans.setAuthor(this.instanceId);let hash=2166136261;for(const character of this.seedIdentity){hash^=character.charCodeAt(0);hash=Math.imul(hash,16777619)}this.instanceHash=hash>>>0;this.instancePhase=1+(this.instanceHash%11);this.instanceDensity=.9+(this.instanceHash%21)/100;this.rhythmKey=null}
  // Called once, before this bot's first tick, with the clock as it stands. Whatever a bot has to say about how the
  // piece BEGINS belongs here -- an opening meter and tempo, a form -- because by its first onTick the first bar has
  // already been issued in whatever the transport defaulted to. Most bots have nothing to say and leave it alone.
  // Returns true if it stated an opening: a live room that is waiting for one needs to know when none is coming.
  onPrepare(clock={}){return false}
  observeClock(clock={}){
    const previous=this.currentClock?.meter;this.currentClock=clock;
    // Its first tala, the band's opening's, becomes the bar's own grouping once it hears the transport's meter: a tala is
    // the bar's groups, and the opening is only where it began.
    if(this.tala===this.openingTala&&Array.isArray(clock.meter?.groups)&&clock.meter.groups.length)this.tala=[...clock.meter.groups];
    if(previous&&clock.meter&&meterChanged(previous,clock.meter))this.answerMeterChange(previous,clock.meter,clock.tick);
    this.advancePlanning(clock);this.advanceDirectLifecycle(clock);this.advanceSpace(clock)}
  // Its policy toward meter and tala proposals (shared/meter-policy.js; declared in its manifest or a spec's settings:
  // bot-registry.js). A bot that follows, as every port does, takes a proposed tala as it always did.
  answerProposedTala(args){
    const proposal=args.map(Number).filter(value=>Number.isInteger(value)&&value>0),policy=this.meterPolicy??FOLLOW;
    if(policy.answer==='follow'){this.tala=proposal;return}
    const answer=answerTala(policy,proposal,{current:this.tala,numerator:Number(this.currentClock?.meter?.numerator)||proposal.reduce((a,b)=>a+b,0)});
    this.tala=answer.groups;this.recordMeterAnswer({kind:'tala',proposal,...answer});
  }
  // A change of the ensemble's meter, at the shared tick it begins on. A bot counting a cycle of its own keeps it,
  // unless the ensemble comes to that cycle's meter, where it counts the ensemble's again.
  answerMeterChange(previous,next,tick){
    const policy=this.meterPolicy??FOLLOW;
    if(policy.answer==='follow')return;
    if(this.stream){
      if(!this.stream.timeMap&&!meterChanged(this.stream.meter,next)){this.stream=null;this.recordMeterAnswer({kind:'meter',answer:'rejoined',reason:`the ensemble came to ${next.label}, its own cycle`,tick})}
      return;
    }
    const answer=answerMeter(policy,{previous,next,tick,current:this.tala});
    if(answer.stream)this.stream=answer.stream;
    if(answer.groups)this.tala=answer.groups;
    this.recordMeterAnswer({kind:'meter',tick,from:previous.label,to:next.label,answer:answer.answer,reason:answer.reason});
  }
  recordMeterAnswer(answer){
    (this.meterAnswers??=[]).push(answer);if(this.meterAnswers.length>64)this.meterAnswers.shift();
    this.audio?.report?.('meter_answer',answer);
  }
  setCapabilities(value={}){this.capabilities={...this.capabilities,...value}}
  setFuturePlanning(runtime){
    this.futurePlanning?.stop();this.futurePlanning=runtime;
    if(!this.futurePlanningInstalled){
      const receive=this.onMessage.bind(this),stop=this.stop?.bind(this);
      this.onMessage=message=>{this.futurePlanning?.receive(message);return receive(message)};
      this.stop=()=>{this.futurePlanning?.stop();return stop?.()};
      this.futurePlanningInstalled=true;
    }
    this.protocolCapabilities={...this.protocolCapabilities,timedPlans:runtime?2:0,overplans:runtime?.publishOverplan?1:0};
    return runtime;
  }
  // Build a plan without announcing it. A bot that STORES the plan it publishes
  // has to use this pair rather than publishPlan, and the order is not a style
  // preference. On a synchronous bus -- which is what the offline renderer has,
  // where a broadcast reaches every bot before broadcast() returns -- every
  // response to a plan arrives while the publisher is still inside the call.
  // `this.plan = this.publishPlan(...)` is therefore still holding null when the
  // answers come back, and silently drops all of them. Assign, then announce.
  preparePlan(kind,payload,options={}){return this.plans.create(kind,payload,options)}
  announcePlan(plan){this.broadcast('plan',[plan]);return plan}
  publishPlan(kind,payload,options={}){return this.announcePlan(this.preparePlan(kind,payload,options))}
  respondToPlan(plan,disposition,options={}){const response=this.plans.response(plan,disposition,options);this.broadcast('plan/response',[response]);return response}
  ingestMemoryResponse(message){if(message?.address!=='/agent/memory/response'||!this.targeted(message))return;const response={...(message.args?.[0]||{})};response.motifs=(response.motifs||[]).flatMap(motif=>{try{return [validateMotif(motif)]}catch{return []}});this.lastMemoryInstance=response.memory||this.lastMemoryInstance;this.memoryResponses.push(response);boundArray(this.memoryResponses,128);if(response.operation==='store'){this.memoryDuplicateRun=response.stored===false?(this.memoryDuplicateRun||0)+1:0;if(this.memoryDevelopmentEnabled&&this.memoryDuplicateRun>=3&&!this.memoryQueryPending){this.memoryDuplicateRun=0;this.memoryQueryPending=this.consultMemory({limit:12},{requestId:`${this.instanceId}:memory-development:${Date.now()}`,limit:12})}}if(response.operation==='query'){if(response.requestId===this.memoryQueryPending)this.memoryQueryPending=null;this.onMemoryRecall(response.motifs||[],response,message)}this.onMemoryResponse(response,message)}
  onMemoryResponse(){}
  onMemoryRecall(){}
  useMemoryMotif(motif,options={}) {
    // Each use is an occurrence of its own (the memorable motifs report, tickets 1 and 5): memory gathers the notes its
    // reports name into one presentation, not one a report.
    this.memoryUses=(this.memoryUses??0)+1;
    this.memoryMaterial={motif:validateMotif(motif),memory:options.memory||this.lastMemoryInstance||'memory',mode:options.mode||'derived',notesReference:this.notes};
    this.memoryMaterial.occurrence=`${this.instanceId??'bot'}:${this.memoryMaterial.motif.motifId}:${this.memoryUses}`;
    this.memoryMaterial.sourceNotes=motifNotes(this.memoryMaterial.motif);
  }
  reportMemoryUse(batch,contextTime) {
    const material=this.memoryMaterial;
    if(material?.mode!=='derived'||this.notes!==material.notesReference)return;
    const sourceNoteIndices=new Set();
    for(const event of batch.events){const m=inspectUMP(event.packet);if(m.kind!=='noteOn')continue;
      material.sourceNotes.forEach((note,index)=>{
        const distance=Math.abs(((m.pitch-note.pitch+6)%12+12)%12-6);
        if(distance<=1/512)sourceNoteIndices.add(index);
      });
    }
    if(!sourceNoteIndices.size)return;
    this.reportMemoryPlayback({durationSeconds:batch.durationSeconds,sourceNoteIndices:[...sourceNoteIndices],
      playbackId:`use:${batch.startSeconds}`,startedAt:Date.now()+(batch.startSeconds-contextTime)*1000});
  }
  reportMemoryPlayback(details={}) {
    const material=this.memoryMaterial;
    if(!material)return;
    this.send('/agent/memory/playing',[{target:material.memory,player:this.instanceId,
      motifId:material.motif.motifId,mode:material.mode,state:'playing',...(material.occurrence?{occurrence:material.occurrence}:{}),...details}]);
  }
  replayMotif(motif,options={}) {
    const canonical=validateMotif(motif);
    if(!this.audio?.playUMP)throw new Error('This host does not support UMP replay');
    this.useMemoryMotif(canonical,{...options,mode:'replay'});
    const memory=this.memoryMaterial.memory;
    return this.audio.playUMP(canonical,{...options,onPlayback:details=>{
      this.send('/agent/memory/playing',[{target:memory,player:this.instanceId,motifId:canonical.motifId,...details}]);
      options.onPlayback?.(details);
    }});
  }
  consultMemory(query={},options={}){const requestId=options.requestId||`${this.instanceId}:memory:${Date.now()}`;this.send('/agent/memory/query',[{target:options.target||'memory',requester:this.instanceId,requestId,query:{...query,limit:options.limit??query.limit??8}}]);return requestId}
  publishMotif(events,options={}){if(!events[0]?.packet&&this.currentClock?.meter&&options.inputUnit!=='quarters'){const m=this.currentClock.meter,scale=4/((m.denominator||bandMeter().denominator)*(m.subdivision||bandMeter().subdivision));events=events.map(event=>({...event,at:event.at*scale,duration:event.duration*scale}))}const motif=validateMotif({schemaVersion:events[0]?.packet?2:1,timebase:options.timebase,metadata:options.metadata,motifId:options.motifId||`${this.instanceId}:motif:${Date.now()}`,author:this.instanceId,createdAt:options.createdAt||logicalPosition(this.currentClock||{}),events,tags:options.tags||[],parents:options.parents||[]});this.send('/agent/memory/store',[{target:options.target||'memory',requester:this.instanceId,requestId:options.requestId||`${motif.motifId}:store`,motif}]);return motif}
  developMotif(source,transformation={}){if(typeof source==='string'){this.consultMemory({motifId:source});return null}let motif;try{motif=validateMotif(source)}catch{return null}const developed=validateMotif({...transformMotif(motif,transformation),motifId:`${this.instanceId}:motif:${Date.now()}`,author:this.instanceId});this.send('/agent/memory/store',[{target:'memory',requester:this.instanceId,requestId:`${developed.motifId}:store`,motif:developed}]);return developed}
  // **Who leads the harmony.** Tuning plans and form plans were already ranked; harmony was "whoever spoke last". With
  // two chord bots in a room that is every bar: measured on the project's own twelve-bot roster, ae_ModalChordBOT said
  // F minor seventh and mh_HarmonyPulseBOT said F major on the same tick, then E flat seventh against C major, for the
  // whole piece. Each follower's note pool flipped within the tick to whichever happened to be listed later, and both
  // sources had "accepted" the other's plan. Every harmony source publishes a plan with a priority, so the information
  // to settle it was always there. The leader is the best unexpired harmony plan by priority, then confidence, then
  // revision, then planId -- the same order as tuning and form, and the last term makes it the same on every machine.
  harmonyAuthority(eligible=null){
    const now=logicalPosition(this.currentClock||{});let best=null;
    for(const plan of this.receivedPlans.values()){
      if(plan.kind!=='harmony'||plan.expiresAt&&compareLogicalPosition(now,plan.expiresAt)>=0)continue;
      if(eligible&&!eligible(plan))continue;
      if(!best||plan.priority-best.priority>0||plan.priority===best.priority&&(plan.confidence-best.confidence>0
        ||plan.confidence===best.confidence&&(plan.revision-best.revision>0||plan.revision===best.revision&&plan.planId<best.planId)))best=plan;
    }
    return best;
  }
  // The messages that carry harmony outside a plan -- the note pool above all, which is what every follower actually
  // plays from. One from an author who has a harmony plan of their own, and is not the leader, is not heard. Nor is one
  // from an author between its plans whose plans all rank below the leader: a chord bot plans a phrase at a time, and
  // its pools between two phrase plans took the band from a performer who led (heard once a listener announced its
  // harmony rarely, as one oriented to a soloist's scale does). A sender with no plan at all cannot be ranked, so it is
  // heard exactly as it always was -- except where a performer leads (a listening bot, standing for a person: its plan's
  // source is 'performer-harmony'). Then no other sender's pool moves the band: a chord bot sent its pool, and its chord
  // list, before its first plan, and the band played them against the performer's scale.
  outrankedHarmony(message){
    if(!/\/(?:notepool|pcprob|plan\/chords|plan\/chordDuration)$/.test(message?.address||'')||!message.source)return false;
    const authority=this.harmonyAuthority();if(!authority)return false;
    const nameOf=author=>{const text=String(author),cut=text.lastIndexOf(':');return cut>0?text.slice(0,cut):text};
    if(nameOf(authority.author)===message.source)return false;
    if(authority.payload?.source==='performer-harmony')return true;
    const now=logicalPosition(this.currentClock||{});
    let planned=false,below=true;
    for(const plan of this.receivedPlans.values()){
      if(plan.kind!=='harmony'||nameOf(plan.author)!==message.source)continue;
      if(!(plan.expiresAt&&compareLogicalPosition(now,plan.expiresAt)>=0))return true;
      planned=true;if(plan.priority>authority.priority||plan.priority===authority.priority&&plan.confidence>=authority.confidence)below=false;
    }
    return planned&&below;
  }
  targeted(message){const target=message?.args?.[0]?.target??message?.args?.[0];return target==='*'||target===this.instanceId||target===this.definitionId||Boolean(this.definitionAliases?.includes(target))}
  // An audio analyzer's descriptors, read by name whatever message carries each (estimation/audio-descriptor-schema.js):
  // once an analyzer has said what it sends, `this.descriptor('flux')` is its latest flux, or null.
  ingestDescriptor(message){
    if(message?.address===DESCRIPTORS_ADDRESS)this.descriptorReader??=new DescriptorReader();
    this.descriptorReader?.hear(message);
  }
  descriptor(name){return this.descriptorReader?.value(name)??null}
  // `/broadcast/character` is the ensemble's aesthetic direction: nine named axes, 0..1, in
  // words curators use. Every bot receives it and every bot projects it onto its own
  // parameters through `public/shared/aesthetic.js` -- one module, so two bots given the same
  // character cannot disagree about what it meant. A bot with nothing to say about character
  // ignores it, which is the protocol working as intended rather than a gap.
  ingestCharacter(message){
    if(message?.address!=='/broadcast/character')return;
    const payload=message.args?.[0];
    const vector=payload&&typeof payload==='object'?(payload.vector||payload):null;
    if(!vector||typeof vector!=='object')return;
    // At least one axis it recognises, with a usable number. An empty object is not a
    // neutral character -- it is a malformed message, and accepting it would silently put
    // the whole room in the middle of every axis on the strength of somebody's typo.
    if(!Object.entries(vector).some(([axis,level])=>
      axis in AESTHETIC_AXES&&Number.isFinite(Number(level))))return;
    this.character=aesthetic(vector);
    this.characterReason=typeof payload.describe==='string'?payload.describe:'';
    this.onCharacter(this.character,message);
  }
  // Overridden by bots that turn character into parameters: PlexBOT into metre and form,
  // TuneBOT into tuning weights, the desk into loudness and space.
  onCharacter(){}
  ingestMixPlacement(message){if(message?.address!=='/agent/mix'||!this.targeted(message))return;const payload=message.args?.[0]||{},placement=Number(payload.placement);if(!Number.isFinite(placement))return;this.mixPlacement=Math.max(-1,Math.min(1,placement));this.mixRole=String(payload.role||'support');this.audio?.setMixPlacement?.(this.mixPlacement)}
  ingestDirectLifecycle(message){if(!['/agent/invite','/agent/start','/agent/stop','/agent/leave'].includes(message?.address)||!this.targeted(message))return;if(!this.groupTree.lifecycle(message)){this.audio?.report?.('lifecycle_refused',{address:message.address,source:message.source??null,reason:this.groupTree.refused.at(-1)?.reason});return}const payload=message.args?.[0]||{},action=message.address.split('/').at(-1),request={action,payload,appliesAt:payload.appliesAt||logicalPosition(this.currentClock||{})};if(action==='invite')this.audio?.lifecycle?.('invited',payload);else{if(!Array.isArray(this.directLifecycle))this.directLifecycle=[];this.directLifecycle.push(request)}}
  // A stop or leave with no fade, due at this pulse, silences this pulse too: the tick it is applied in is not played
  // (its notes had gone to a muted output, and to the transcript and score as a rested part's first bar).
  advanceDirectLifecycle(clock={}){if(!Array.isArray(this.directLifecycle)||!this.directLifecycle.length)return;const now=logicalPosition(clock),due=this.directLifecycle.filter(request=>compareLogicalPosition(now,request.appliesAt)>=0);this.directLifecycle=this.directLifecycle.filter(request=>compareLogicalPosition(now,request.appliesAt)<0);for(const request of due.sort((left,right)=>compareLogicalPosition(left.appliesAt,right.appliesAt))){this.audio?.lifecycle?.(request.action,request.payload);if(request.action==='start')this.silencedAt=undefined;else if((request.action==='stop'||request.action==='leave')&&!(Number(request.payload?.fadeBars)>0)&&!(Number(request.payload?.fadeSeconds)>0))this.silencedAt=clock.tick}}
  advanceSpace(clock={}){if(!Array.isArray(this.spaceRequests)||!this.spaceRequests.length)return;const now=logicalPosition(clock),due=this.spaceRequests.filter(request=>compareLogicalPosition(now,request.appliesAt)>=0);this.spaceRequests=this.spaceRequests.filter(request=>compareLogicalPosition(now,request.appliesAt)<0);for(const value of due){const density=Number(value.density);this.spacePolicy={...value};if(Number.isFinite(density))this.density=Math.max(0,Math.min(1,density))}}
  onPlan(plan){
    // A standing preference is interpreted only by its implemented consumers.
    if(plan.kind==='motif'&&plan.payload?.insistence){this.respondToPlan(plan,'abstain',{createdAt:plan.createdAt,rationale:'This agent does not arrange insisted motifs.'});return}
    // A part plan is answered by the performer it names only (part-plans.js), as a casting plan is: a fugue of two hundred
    // voices says two hundred of them, each to the section that plays it (plex_clodbot sayFugues).
    if(plan.kind==='part'&&!this.playsPart?.(plan.payload?.part))return;
    // A casting plan (ManageBOT's, research/casting.md §7): answered from this bot's own declaration and state -- it may
    // decline or defer -- and only by the bots it names, so a section's casting costs one response per bot it moves.
    if(plan.kind==='orchestration'&&plan.payload?.casting){
      const answer=castingAnswer(this,plan);
      if(answer){if(!answer.silent)this.respondToPlan(plan,answer.disposition,{createdAt:plan.createdAt,payload:answer.payload||{},rationale:answer.rationale});return}
    }
    if(plan.kind==='tuning'){
      if(!this.capabilities.tuning){this.respondToPlan(plan,'abstain',{createdAt:plan.createdAt,rationale:'This agent does not interpret pitched tuning plans.'});return}
      try{validateTuningPayload(plan.payload);this.tuningPlans.set(plan.planId,plan);this.respondToPlan(plan,'accept',{createdAt:plan.createdAt,rationale:'Will apply this tuning at its stated logical boundary.'})}
      catch(error){this.respondToPlan(plan,'decline',{createdAt:plan.createdAt,rationale:`Invalid tuning payload: ${error.message}`})}
      return;
    }
    const capability=plan.kind==='harmony'?'harmony':plan.kind==='rhythm'?'rhythm':plan.kind==='motif'?'motif':plan.kind==='orchestration'?'orchestration':plan.kind==='form'?'form':plan.kind==='lifecycle'?'lifecycle':null;
    if(!capability||!this.capabilities[capability]){this.respondToPlan(plan,'abstain',{createdAt:plan.createdAt,rationale:`This agent has no ${plan.kind} interpretation policy.`});return}
    // A theme's line to take up where the form returns (MemoryBOT's return plans: thematic-form.js) is for the voices that
    // take themes up (MemoryThemes); it carries no motif for anyone else to interpret.
    if(plan.kind==='motif'&&plan.payload?.return&&!plan.payload.motif){this.respondToPlan(plan,'abstain',{createdAt:plan.createdAt,rationale:'This agent takes up no theme lines.'});return}
    if(plan.kind==='lifecycle'&&!['proposal','commitment'].includes(plan.payload.phase)){this.respondToPlan(plan,'decline',{createdAt:plan.createdAt,rationale:'Lifecycle plans require a proposal or commitment phase.'});return}
    this.futurePlans.set(plan.planId,plan);
    // A rhythm plan that proposes a meter or a tala is answered by the bot's declared policy (meter-policy.js planAnswer):
    // what it will make of the proposal, told to the proposer.
    if(plan.kind==='rhythm'&&(plan.payload?.meter||plan.payload?.tala)&&(this.meterPolicy??FOLLOW).answer!=='follow'){
      const answer=planAnswer(this.meterPolicy,plan.payload,{current:this.tala,currentMeter:this.currentClock?.meter??null});
      this.respondToPlan(plan,answer.disposition,{createdAt:plan.createdAt,payload:answer.payload,rationale:answer.rationale});
      return;
    }
    const rationale=plan.kind==='lifecycle'&&plan.payload.phase==='proposal'?'Ready to stop at a complete logical boundary if the ensemble reaches quorum.':`Will interpret this ${plan.kind} plan at its stated logical boundary.`;
    this.respondToPlan(plan,'accept',{createdAt:plan.createdAt,payload:{readyAt:plan.appliesAt},rationale});
  }
  onPlanResponse(){}
  // The ensemble's committed stop is the conductor's cutoff: from it the agent hears no more ticks, so what it holds is let
  // go now, whatever it was given to hold -- its own way first (onCutoff: a section's seat lifts its bow), then whatever its
  // engine still sounds (audio.js cutOff). A note held open to the end had played on past it, a bar and more, while the
  // band was silent (the owner, 5 October 2026, of a play-along's last seconds: "a single awkwardly lingering note").
  cutOffAt(clock={}){
    const at=this.audio?.eventStart?.(0);
    try{this.onCutoff?.(clock,{atSeconds:Number.isFinite(at)?at:undefined})}finally{this.audio?.cutOff?.({atSeconds:Number.isFinite(at)?at:undefined})}
  }
  advancePlanning(clock={}){
    const now=logicalPosition(clock),eligible=[];
    if(this.capabilities.tuning){
      for(const [id,plan] of this.tuningPlans){if(compareLogicalPosition(now,plan.expiresAt)>=0){this.tuningPlans.delete(id);this.receivedPlans.delete(id);this.appliedPlans.delete(id);continue}if(compareLogicalPosition(now,plan.appliesAt)>=0)eligible.push(plan)}
      eligible.sort((a,b)=>b.priority-a.priority||b.confidence-a.confidence||b.revision-a.revision||(a.planId<b.planId?-1:a.planId>b.planId?1:0));
      const chosen=eligible[0]||null,key=chosen?`${chosen.planId}@${chosen.revision}`:null;
      if(key!==this.activeTuningKey){this.activeTuningKey=key;this.activeTuning=chosen?.payload??null;this.audio?.setTuningPlan?.(chosen?{...chosen.payload,planId:chosen.planId,appliesAt:chosen.appliesAt}:null)}
      if(chosen)this.audio?.setTuningPosition?.(clock);
    }
    for(const [id,plan] of this.futurePlans){
      if(compareLogicalPosition(now,plan.expiresAt)>=0){this.futurePlans.delete(id);this.receivedPlans.delete(id);this.appliedPlans.delete(id);continue}
      if(compareLogicalPosition(now,plan.appliesAt)<0||this.appliedPlans.has(id))continue;
      this.appliedPlans.add(id);
      if(plan.kind==='rhythm'){
        const tala=(plan.payload.tala||plan.payload.groups||[]).map(Number).filter(value=>Number.isInteger(value)&&value>0);if(tala.length)this.tala=tala;
        if(plan.payload.stream!==undefined)this.setStream(plan.payload.stream);
        const density=Number(plan.payload.density);if(Number.isFinite(density))this.density=Math.max(0,Math.min(1,density));
        this.activeRhythmPlan=plan;
      }
      if(plan.kind==='harmony'){const authority=this.harmonyAuthority();if(!authority||authority.author===plan.author){this.activeHarmonyPlan=plan;const first=plan.payload.chords?.[0];if(Array.isArray(first)&&first.some(Number.isFinite)){this.notes=first.map(Number).filter(Number.isFinite);this.poolHeard=true}}}
      if(plan.kind==='motif'){try{this.activeMotifPlan={...plan,payload:{...plan.payload,motif:validateMotif(plan.payload.motif)}}}catch(error){this.audio?.report?.('motif_plan_rejected',{error:error.message})}}
      if(plan.kind==='orchestration')this.activeOrchestrationPlan=plan;
      if(plan.kind==='lifecycle'&&plan.payload.phase==='commitment'&&plan.payload.action==='stop'){this.ensembleStopped=true;this.audio?.panicMidi?.();this.cutOffAt(clock)}
    }
    // The form is the one plan several bots may each propose, and it was the one
    // resolved by arrival order -- `activeFormPlan=plan` for whichever landed
    // last. Two FormBOTs in one ensemble therefore followed different forms with
    // different endpoints, each adopting the other's. That is observed, not
    // theoretical: see test/form-negotiation.test.mjs.
    //
    // Resolved now the way tuning plans already are, and for the same reason:
    // priority, then confidence, then revision, then a canonical planId. Every
    // bot reaches the same form from the same messages, and a proposer that
    // yields by lowering its own priority is heard by every bot that never ran a
    // selector of its own. Re-resolved each tick, so a revision or a concession
    // takes effect instead of waiting for a plan to be applied once.
    const forms=[];
    for(const [,plan] of this.futurePlans)
      if(plan.kind==='form'&&compareLogicalPosition(now,plan.appliesAt)>=0)forms.push(plan);
    if(forms.length){
      forms.sort((a,b)=>b.priority-a.priority||b.confidence-a.confidence||b.revision-a.revision||
        (a.planId<b.planId?-1:a.planId>b.planId?1:0));
      this.activeFormPlan=forms[0];
    }
  }
  instanceAllows(clock,salt=0,probability=.75){const value=Math.imul((this.instanceHash||1)^(clock.bar+1)*2654435761^(clock.group+1+salt)*2246822519,3266489917)>>>0;return value/4294967296<probability}
  shapeVelocity(base,note,{division=0,divisions=1,voice=0,amount=1,clock=this.currentClock||{}}={}){this.dynamicVelocityState||=new Map;const previous=this.dynamicVelocityState.get(voice)||{note,velocity:base},bars=clock.meter?.phraseBars||bandPhraseBars(),phrasePosition=((clock.bar||0)%bars+Math.max(0,Math.min(1,(clock.beat||0)/(clock.meter?.numerator||bandMeter().numerator))))/bars,value=musicalAccent({base,clock,division,divisions,phrasePosition,note,previousNote:previous.note,previousVelocity:previous.velocity,voice,amount,random:unitRandom});this.dynamicVelocityState.set(voice,{note,velocity:value});return value}
  // A cycle of its own over the ensemble's shared tick, a stream in polymeter (shared/rhythm-vocabulary.js), as a rhythm
  // plan gives it ({stream: {meter, anchor, id}}; null ends it). The bot then counts its bars, beats and groups in its
  // own cycle (interpretClock), exactly, from the shared tick; the ensemble's clock is still the only clock.
  setStream(value){
    if(!value){this.stream=null;return}
    const source=value.meter??value,api=globalThis.MusebotMeter,meter=typeof api?.normalizeMeter==='function'?api.normalizeMeter(source):source;
    this.stream=streamOf(meter,{anchor:Number.isSafeInteger(value.anchor)?value.anchor:0,id:typeof value.id==='string'?value.id:null});
  }
  // The clock as this part counts it: the ensemble's, or its own stream's over the shared tick, a stream taken on at its
  // anchor (/agent/stream) where one is waiting. Every bot's onTick hears it (the constructor's wrapper), whether or not
  // the bot interprets its clock itself; a clock that is already its stream's is left as it is (streamClock), so a bot
  // that does (interpretClock) hears the same. The ensemble's own clock is what it observes (observeClock), so that
  // it answers the ensemble's changes of meter, not its own stream's.
  streamedClock(clock){
    this.takeStreams(clock);
    if(!this.stream||!clock?.meter||typeof globalThis.MusebotMeter?.clockContext!=='function')return clock;
    // (A related part asked its clock between its ticks hears its latest tick's; before its anchor, the ensemble's.)
    if(this.stream.timeMap)return this.isPartClock(clock)?clock:Number.isSafeInteger(clock.tick)&&clock.tick>=this.stream.anchor?this.partClock(clock,this.latestPartTick(clock.tick)):clock;
    return streamClock(clock,this.stream,globalThis.MusebotMeter.clockContext);
  }
  // The streams whose anchors this shared tick has reached, taken on in order.
  takeStreams(clock){
    while(this.pendingStreams?.length&&Number.isFinite(clock?.tick)&&(this.pendingStreams[0].anchor??-Infinity)<=clock.tick){
      const {stream,anchor,relation,relationOnly}=this.pendingStreams.shift(),at=anchor??clock.tick;
      if(relationOnly){this.relateStream(relation,at,clock);continue}
      this.setStream(stream?{...stream,anchor:anchor??stream.anchor??clock.tick}:null);
      if(stream&&relation)this.relateStream(relation,this.stream?.anchor??at,clock);
    }
  }
  // A part's own tempo relation to the ensemble, its beat's rate over the ensemble's (shared/part-time-map.js): held,
  // {ratio: [p, q]}, or glided from its relation at `at` (or from `from`) to `to` over `ticks` shared ticks (or `bars`,
  // the ensemble's there), then held. Any ratio, where a stream alone has only its subdivision's over the ensemble's.
  // Its map is in shared ticks, the ratio's times its own subdivision over the ensemble's at `at`, so the shared tick
  // stays the only clock, and the band's rubato carries the part with it. A relation the part cannot take is refused
  // and reported, never approximated.
  relateStream(relation,at,clock){
    const stream=this.stream,shared=Number(clock?.meter?.subdivision),refuse=reason=>{this.audio?.report?.('stream_relation_refused',{reason,relation,at});return false};
    if(!stream)return refuse('no stream to relate: a relation is told with a stream, or to a part in one');
    if(!(shared>0))return refuse('no ensemble subdivision at its anchor');
    const own=Number(stream.meter?.subdivision)||shared,inTicks=ratio=>Array.isArray(ratio)?[ratio[0]*own,ratio[1]*shared]:null;
    const bar=Number(clock.meter.pulsesPerBar)||Number(clock.meter.numerator)*shared,ticks=Number.isSafeInteger(relation?.ticks)?relation.ticks:Number.isSafeInteger(relation?.bars)?relation.bars*bar:null;
    try{
      const map=stream.timeMap??timeMap({anchor:stream.anchor,rate:[1,1]});
      const next=relation?.ratio?changedTimeMap(map,{at,rate:inTicks(relation.ratio)})
        :relation?.to&&ticks>0?changedTimeMap(map,{at,to:inTicks(relation.to),from:inTicks(relation.from),ticks})
        :null;
      if(!next)return refuse('a relation is {ratio} or {to, ticks|bars, from?}');
      this.stream=Object.freeze({...stream,timeMap:next});
      return true;
    }catch(error){return refuse(error.message)}
  }
  isPartClock(clock){return clock?.stream?.id===this.stream?.id&&clock.stream.anchor===this.stream.anchor&&Number.isSafeInteger(clock.stream.partTick)}
  // The part's latest tick at or before the shared tick t, where a bot asks its clock between its ticks.
  latestPartTick(t){
    const map=this.stream.timeMap,[n,d]=positionAt(map,t),tick=Number(n/d),rate=rateAt(map,t);
    return {tick,fraction:0,at:sharedAt(map,tick),rate:toNumber(rate),...(glideAt(map,t)?{}:{exact:rate})};
  }
  // The clock of the part's own tick: its bar, beat and group from its own ticks; its tempo its beats' at its rate
  // there; the shared tick it falls in, where in it (stream.fraction), and its shared position (stream.at).
  partClock(clock,part){
    const stream=this.stream,map=stream.timeMap,cycle=stream.cycleTicks,bar=Math.floor(part.tick/cycle),shared=Number(clock.meter.subdivision),own=Number(stream.meter.subdivision)||shared;
    const rate=part.rate,ratio=part.exact?rational(part.exact[0]*BigInt(shared),part.exact[1]*BigInt(own)):null,glide=glideAt(map,clock.tick);
    return {...globalThis.MusebotMeter.clockContext({tick:clock.tick,bpm:Number(clock.bpm)*rate*shared/own,meter:stream.meter,bar,tickInBar:part.tick-bar*cycle}),
      stream:{id:stream.id,cycleTicks:cycle,anchor:stream.anchor,partTick:part.tick,fraction:part.fraction,at:part.at??clock.tick+part.fraction,ratio:rate*shared/own,
        ...(ratio?{tempoRatio:[Number(ratio[0]),Number(ratio[1])]}:{}),
        ...(glide?{glide:{from:beats(glide.from),to:beats(glide.to),progress:glide.progress}}:{})},
      ensemble:{bar:clock.bar,tickInBar:clock.tickInBar,meter:clock.meter}};
    function beats([n,d]){const r=rational(n*BigInt(shared),d*BigInt(own));return [Number(r[0]),Number(r[1])]}
  }
  // The bot's tick as its part counts it. A part in a tempo relation of its own is ticked once for each of its own ticks
  // in this shared tick, and not at all where none falls, each heard with the engine's event time moved to where its tick
  // falls in the shared one: every host sets the event time for the shared tick before ticking a bot (app.js,
  // render/bot-host.js, the plug-in's worker, the Ableton devices' core), and a note's offset counts from it. Inside a shared tick the band's
  // tempo is that tick's (under rubato, the tick's own length), so the move is exact to the band's own resolution.
  tickAsPart(tick,number,clock){
    this.takeStreams(clock);
    if(!this.stream?.timeMap||!clock?.meter||typeof globalThis.MusebotMeter?.clockContext!=='function')return tick(number,this.streamedClock(clock));
    const audio=this.audio,base=Number(audio?.eventTime),seconds=secondsPerTick(clock);let result;
    for(const part of ticksIn(this.stream.timeMap,clock.tick)){
      const moved=base>0&&part.fraction>0; // (an event time a host has set)
      if(moved)audio.eventTime=base+part.fraction*seconds;
      try{result=tick(number,this.partClock(clock,part))}finally{if(moved)audio.eventTime=base}
    }
    return result;
  }
  // The notes of its motifs' occurrences that actually began, as its host reports them (render/bot-host.js; the
  // memorable-motifs report's ticket 5): kept in its ledger (shared/execution-ledger.js), a note's `occurrence` the
  // record its strike named (note-language.js). A bot that keeps its own history takes them here too.
  onExecuted(notes){
    this.executions??=new ExecutionLedger();
    for(const note of notes??[]){const record=note.language;if(record?.occurrence)this.executions.executed({occurrence:record.occurrence,event:record.event,identity:note.identity,atSeconds:note.atSeconds,tick:note.tick})}
  }
  interpretClock(clock){clock=this.streamedClock(clock);const numerator=clock.meter.numerator,groups=this.tala.reduce((a,b)=>a+b,0)===numerator?this.tala:clock.meter.groups;if(groups===clock.meter.groups)return clock;const beat=clock.beat,starts=[];let total=0;for(const size of groups){starts.push(total);total+=size}let group=0;while(group+1<starts.length&&beat>=starts[group+1])group++;return{...clock,meter:{...clock.meter,groups},group,groupBeat:beat-starts[group],groupStart:clock.tickInBar===starts[group]*clock.meter.subdivision}}
  // The meter's shared rhythm, or its own density's. A named clave (shared/rhythm-vocabulary.js: `rhythm.vocabulary`) is
  // played in its own orientation, its direction kept: a bot's own rotation and phase displace only a plain pattern.
  rhythm(clock,config,density=config.rhythmDensity){const meter=clock.meter,steps=meter.pulsesPerBar||meter.groups.reduce((a,b)=>a+b,0)*meter.subdivision,proposal=config.acceptSharedRhythm===false?{}:meter.rhythm||{},range=config.sharedDensityRange||[0,1],allocated=Number(this.spacePolicy?.density),localDensity=Number.isFinite(allocated)?allocated:density,requested=(proposal.hits??Math.round(steps*localDensity))/steps,interpreted=Math.max(range[0],Math.min(range[1],requested*(this.instanceDensity||1))),hits=Math.max(0,Math.min(steps,Math.round(steps*interpreted))),phase=Number(this.spacePolicy?.phase),instanceRotation=config.preserveDownbeat?0:(this.instancePhase||0),clave=Array.isArray(proposal.clave)&&proposal.clave.length<=Math.ceil(steps*range[1])?proposal.clave:[],rotation=clave.length&&proposal.vocabulary?Number(proposal.rotation)||0:(proposal.rotation??config.rotation??0)+instanceRotation+(Number.isFinite(phase)?Math.round(phase*steps):0),key=JSON.stringify([steps,hits,rotation,clave]);if(key!==this.rhythmKey){this.rhythmKey=key;this.rhythmCycle=cyclicPattern({steps,hits,rotation,clave})}return this.rhythmCycle}
  async start(){}
  stop(){}
}
