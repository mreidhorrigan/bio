import {createRandomStream,withRandomStream,withEnsembleSeed,scopeRandomObject,randomSeed} from '../random-source.js';
import {meterPolicy} from '../shared/meter-policy.js';
const STATUSES=new Set(['native','behavioural-port','catalogued']);
const INCOMPLETE=new Set(['effects','blank','templateBot']);
const POLYPHONIC=new Set([
  'modal','miles','bowed','pad','papMelody','dampPiano','counterpoint',
  'multiSynth','reichGuitar','seasonsBrokenChord','seasonsChord','resynth',
  'bleep','whiny','groan','wub','atmosphere','texture','midiBot','webBot',
  'xPad','tangerineDream','rhodes'
]);
export function performanceType(manifest){
  if(INCOMPLETE.has(manifest.id)||manifest.status==='catalogued')return'incomplete';
  if(!(manifest.outputModes||[]).length)return'silent';
  if(POLYPHONIC.has(manifest.id))return'polyphonic';
  if(manifest.pitchContract==='fixed-percussion'||manifest.pitchContract==='hybrid-mpe-percussion'||
    manifest.pitchContract==='none'||manifest.category==='beat')return'percussive';
  return'monophonic';
}
export function defineBot(manifest,create){
  if(!manifest||typeof manifest.id!=='string'||!manifest.id)throw new Error('Bot manifest requires a stable id');
  if(typeof manifest.name!=='string'||!manifest.name)throw new Error(`Bot ${manifest.id} requires a name`);
  if(!STATUSES.has(manifest.status))throw new Error(`Bot ${manifest.id} has invalid status`);
  if(typeof create!=='function'&&manifest.status!=='catalogued')throw new Error(`Runnable bot ${manifest.id} requires a factory`);
  if(manifest.meterPolicy!==undefined)meterPolicy(manifest.meterPolicy);
  const audible=(manifest.outputModes||[]).length>0,utility=['utility','template'].includes(manifest.category),planningCapabilities=Object.freeze({
    tuning:manifest.pitchContract==='floating-mpe',
    harmony:manifest.pitchContract==='floating-mpe'||manifest.category==='harmony',
    rhythm:audible||['beat','composition','conductor'].includes(manifest.category),
    motif:audible&&manifest.pitchContract==='floating-mpe',
    orchestration:audible,
    form:!utility,
    lifecycle:audible||['composition','conductor'].includes(manifest.category),
    ...(manifest.planningCapabilities||{})
  });
  // A bot given a new id keeps the name its random stream had (manifest.randomId), so a seeded render plays as it did,
  // and answers to its former ids (manifest.aliases) as a target, as agents.js resolves them for specs and links.
  const streamId=manifest.randomId??manifest.id;
  const factory=typeof create==='function'?((...args)=>{
    const options=args[2]||{},seed=options.seed??(Number.isInteger(args[1]?.seed)?args[1].seed:randomSeed()),key=options.randomKey??streamId,
      stream=createRandomStream(`${seed}:${key}:${streamId}:behavior`),
      bot=withEnsembleSeed(seed,()=>withRandomStream(stream,()=>create(...args)));
    if(bot){
      scopeRandomObject(bot,stream);bot.definitionId=manifest.id;bot.definitionAliases=Object.freeze([...(manifest.aliases||[])]);bot.randomStream=stream;
      bot.getRandomState=()=>stream.snapshot();bot.restoreRandomState=state=>stream.restore(state);
      bot.setCapabilities?.(planningCapabilities);
      // Its policy toward meter and tala proposals (shared/meter-policy.js): a spec's setting, else its manifest's.
      bot.meterPolicy=meterPolicy(options.meterPolicy??manifest.meterPolicy);
    }
    return bot;
  }):create;
  const midiPerformance=manifest.performanceType||performanceType(manifest);
  return Object.freeze({...manifest,performanceType:midiPerformance,polyphonic:midiPerformance==='polyphonic',outputModes:Object.freeze([...(manifest.outputModes||[])]),planningCapabilities,create:factory});
}
// The id a bot is registered under, for an id that may be one of its former ones (its manifest's `aliases`): `agents`
// any map of definitions by id (the registry's, or a copy of it with bots added, which keeps no hidden alias).
export function resolveBotId(id,agents={}){
  if(typeof id!=='string')return id;
  // (A registry that keeps its aliases as hidden keys, as agents.js does, gives the definition, whose id is the bot's.)
  if(Object.hasOwn(agents,id))return typeof agents[id]?.id==='string'?agents[id].id:id;
  return Object.values(agents).find(definition=>definition?.aliases?.includes(id))?.id??id;
}
export class BotRegistry{
  constructor(){this.entries=new Map()}
  register(definition){if(this.entries.has(definition.id))throw new Error(`Duplicate bot id: ${definition.id}`);this.entries.set(definition.id,definition);return definition}
  registerMany(definitions){for(const definition of definitions)this.register(definition);return this}
  runnable(){return[...this.entries.values()].filter(bot=>typeof bot.create==='function')}
  catalog(){return[...this.entries.values()]}
  object(){return Object.fromEntries(this.runnable().map(bot=>[bot.id,bot]))}
}
