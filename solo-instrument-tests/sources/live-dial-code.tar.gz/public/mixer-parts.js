// Parts the ensemble mixer (audio-mixer.js) and its inserts (insert-chain.js) build only when
// something asks for them: stereo width, the ping-pong and tape echoes, a safety clipper and the
// drive curves. Each is plain Web Audio nodes, so it runs wherever the mixer does, the offline
// renderer's graph included, and each takes its settings as ramps, never steps.
//
// The numbers are measurements where a measurement exists; research/expression-and-mixing-
// references.md gives each source.

// ---- ramps -----------------------------------------------------------------------------------
// A setting moved from where it is at `at` to `value`, over `seconds`, never faster than RAMP_FLOOR_SECONDS (a click,
// faster). A Web Audio ramp runs from the previous automation event, at its time and value, and cancelAndHoldAtTime()
// holds only a change still under way at `at` (the specification's algorithm, which Chrome and render/node/graph.mjs
// both follow). After an event that has passed, a new ramp ran from it, seconds back, and jumped at `at` most of the
// way: a mixbot's two-second fade became a step. So what each parameter was last given here is kept (ramp, setAt): a
// ramp under way is held where it has got to; otherwise the new ramp starts at `at` from the value last given, or, for
// a parameter given none here, from its value now (as set when it was made).
export const RAMP_FLOOR_SECONDS = 0.005;
const given = new WeakMap();
export function ramp(param, value, at, seconds = 0.03, floor = RAMP_FLOOR_SECONDS) {
  const end = at + Math.max(floor, seconds), last = given.get(param);
  if (param.cancelAndHoldAtTime && last && last.end > at) param.cancelAndHoldAtTime(at);
  else {const from = last && last.end <= at ? last.value : param.value; param.cancelScheduledValues(at); param.setValueAtTime(from, at)}
  param.linearRampToValueAtTime(value, end);
  given.set(param, {end, value});
}
// A setting set at `at`, as it is: whatever was scheduled after it cancelled.
export function setAt(param, value, at) {param.cancelScheduledValues(at); param.setValueAtTime(value, at); given.set(param, {end: at, value})}
const setOrRamp = (param, value, at, seconds) => seconds === 0 ? setAt(param, value, at) : ramp(param, value, at, seconds);

// ---- stereo width -------------------------------------------------------------------------
// Mid and side: the side scaled by the width and the pair put back, which as a matrix is four
// gains. 1 leaves the image as it is, 0 folds it to mono, 2 doubles the side.
export function widthMatrix(context, width = 1) {
  const splitter = context.createChannelSplitter(2), merger = context.createChannelMerger(2), input = context.createGain();
  input.channelCount = 2; input.channelCountMode = 'explicit'; input.channelInterpretation = 'speakers';
  const gains = [0, 1].map(() => [0, 1].map(() => context.createGain()));
  input.connect(splitter);
  for (const from of [0, 1]) for (const to of [0, 1]) splitter.connect(gains[from][to], from).connect(merger, 0, to);
  // A negative width mirrors the image, left and right swapped: -1 exactly, as a desk placing a kit from the audience's
  // side of it does (experiments/mix-desk/live-desk.js).
  const set = (value, at = context.currentTime, seconds = 0) => {
    const w = Math.max(-2, Math.min(2, Number(value))), same = (1 + w) / 2, cross = (1 - w) / 2;
    for (const from of [0, 1]) for (const to of [0, 1]) setOrRamp(gains[from][to].gain, from === to ? same : cross, at, seconds);
    return w;
  };
  set(width);
  return {input, output: merger, kind: 'width', name: 'Stereo width', set,
    dispose() {for (const node of [input, splitter, merger, ...gains.flat()]) {try {node.disconnect()} catch {}}}};
}

// ---- echoes ---------------------------------------------------------------------------------
// A ping-pong: the first echo on the left, the next on the right, each losing the feedback, so a
// repeat decays exactly as the one-line delay's does and only its place alternates.
export function pingPongDelay(context, {seconds = 0.4, feedback = 0.3, tone = 4500, lowCut = 20} = {}) {
  const input = context.createGain(), merger = context.createChannelMerger(2), output = context.createGain();
  input.channelCount = 1; input.channelCountMode = 'explicit';
  const line = () => {
    const delay = context.createDelay(8.1), toneFilter = context.createBiquadFilter(), low = context.createBiquadFilter(), gain = context.createGain();
    toneFilter.type = 'lowpass'; low.type = 'highpass'; low.Q.value = Math.SQRT1_2;
    delay.connect(toneFilter).connect(low).connect(gain);
    return {delay, toneFilter, low, gain};
  };
  const left = line(), right = line();
  input.connect(left.delay);
  left.delay.connect(merger, 0, 0); right.delay.connect(merger, 0, 1);
  left.gain.connect(right.delay); right.gain.connect(left.delay);
  merger.connect(output);
  const set = ({seconds: time, feedback: amount, tone: hz, lowCut: cut} = {}, at = context.currentTime, rampSeconds = 0) => {
    for (const side of [left, right]) {
      if (time !== undefined) setOrRamp(side.delay.delayTime, time, at, rampSeconds && 0.08);
      if (amount !== undefined) setOrRamp(side.gain.gain, amount, at, rampSeconds);
      if (hz !== undefined) setOrRamp(side.toneFilter.frequency, hz, at, rampSeconds);
      if (cut !== undefined) setOrRamp(side.low.frequency, cut, at, rampSeconds);
    }
  };
  set({seconds, feedback, tone, lowCut});
  return {input, output, kind: 'pingPong', set, lines: [left.delay, right.delay],
    dispose() {for (const side of [left, right]) for (const node of Object.values(side)) {try {node.disconnect()} catch {}}
      for (const node of [input, merger, output]) {try {node.disconnect()} catch {}}}};
}

// A tape echo, after the Roland Space Echo: the tape's transport moves the delay (the pinch
// roller's wow, 3.5 Hz, and the capstan's flutter, 22 Hz, measured at the 60 ms setting and
// scaling with tape speed, so slower tape wobbles slower), wow and flutter together about 0.2 per
// cent of pitch, inside the 0.15-0.3 per cent machines measure; and the loop saturates, so
// feedback near its top grows dense and dark instead of running away.
export const TAPE = Object.freeze({pinchHz: 3.5, capstanHz: 22, atMs: 60, slowestMs: 160, wow: 0.0014, flutter: 0.0006});
export function tapeSpeed(seconds) {
  const ms = Math.max(TAPE.atMs, Math.min(TAPE.slowestMs, seconds * 1000)), scale = TAPE.atMs / ms;
  const wowHz = TAPE.pinchHz * scale, flutterHz = TAPE.capstanHz * scale;
  // A delay moved by A sin(2 pi f t) shifts pitch by at most 2 pi f A: so A is the deviation over that.
  return {wowHz, flutterHz, wowSeconds: TAPE.wow / (2 * Math.PI * wowHz), flutterSeconds: TAPE.flutter / (2 * Math.PI * flutterHz)};
}
export function tapeEcho(context, {seconds = 0.4, feedback = 0.3, tone = 4500, lowCut = 20} = {}) {
  const input = context.createGain(), delay = context.createDelay(8.2), output = context.createGain();
  const toneFilter = context.createBiquadFilter(), low = context.createBiquadFilter(), saturate = context.createWaveShaper(), loop = context.createGain();
  toneFilter.type = 'lowpass'; low.type = 'highpass'; low.Q.value = Math.SQRT1_2;
  // Unity gain for small signals, so the feedback setting means what it does on the clean delay;
  // it bends only as a repeat gets loud.
  const curve = new Float32Array(1025);
  for (let index = 0; index < curve.length; index++) {const x = index / 512 - 1; curve[index] = 2 * Math.tanh(x / 2)}
  saturate.curve = curve; saturate.oversample = '2x';
  input.connect(delay).connect(output);
  delay.connect(toneFilter).connect(low).connect(saturate).connect(loop).connect(delay);
  // The transport. Two oscillators, built with the echo and only then: see the mixer's chorus LFO
  // for why an unused effect must not own one.
  const wow = context.createOscillator(), flutter = context.createOscillator(), wowDepth = context.createGain(), flutterDepth = context.createGain();
  wow.connect(wowDepth).connect(delay.delayTime); flutter.connect(flutterDepth).connect(delay.delayTime);
  try {wow.start(); flutter.start()} catch {}
  const set = ({seconds: time, feedback: amount, tone: hz, lowCut: cut} = {}, at = context.currentTime, rampSeconds = 0) => {
    if (time !== undefined) {
      const speed = tapeSpeed(time);
      setOrRamp(delay.delayTime, time, at, rampSeconds && 0.08);
      setOrRamp(wow.frequency, speed.wowHz, at, rampSeconds); setOrRamp(flutter.frequency, speed.flutterHz, at, rampSeconds);
      setOrRamp(wowDepth.gain, speed.wowSeconds, at, rampSeconds); setOrRamp(flutterDepth.gain, speed.flutterSeconds, at, rampSeconds);
    }
    if (amount !== undefined) setOrRamp(loop.gain, amount, at, rampSeconds);
    if (hz !== undefined) setOrRamp(toneFilter.frequency, hz, at, rampSeconds);
    if (cut !== undefined) setOrRamp(low.frequency, cut, at, rampSeconds);
  };
  set({seconds, feedback, tone, lowCut});
  return {input, output, kind: 'tape', set, lines: [delay],
    dispose() {try {wow.stop(); flutter.stop()} catch {}
      for (const node of [input, delay, output, toneFilter, low, saturate, loop, wow, flutter, wowDepth, flutterDepth]) {try {node.disconnect()} catch {}}}};
}

// ---- the master's safety ----------------------------------------------------------------------
// After the limiter: exact below 0.9 of full scale, then bending smoothly toward 1, so an
// inter-sample peak the limiter let by is rounded rather than clipped. Its input is halved and the
// curve doubled back, which lets the curve see peaks up to twice full scale.
export function softClip(context) {
  const input = context.createGain(), shaper = context.createWaveShaper(), samples = 8193, curve = new Float32Array(samples);
  input.gain.value = 0.5;
  for (let index = 0; index < samples; index++) {
    const x = 2 * (index * 2 / (samples - 1) - 1), size = Math.abs(x);
    curve[index] = Math.sign(x) * (size <= 0.9 ? size : 0.9 + 0.1 * Math.tanh((size - 0.9) / 0.1));
  }
  shaper.curve = curve; shaper.oversample = 'none';
  input.connect(shaper);
  return {input, output: shaper, kind: 'softClip', name: 'Soft clip', dispose() {try {input.disconnect(); shaper.disconnect()} catch {}}};
}

// ---- drive --------------------------------------------------------------------------------
// The shapes a saturator can have, by type: 0 the tanh the mixer always used, 1 tape (softer,
// its knee rounder than tanh's), 2 tube (asymmetric, so even harmonics: its positive side bends
// earlier than its negative), 3 fuzz (clipped hard, nearly square), 4 crush (amplitude reduced
// to fewer levels, 16 bits at amount 0 down to 3 at 1). Every curve passes through zero and is
// scaled to reach full scale at full input, so the drive's own gain stage sets how hard it works.
export const DRIVE_TYPES = Object.freeze(['tanh', 'tape', 'tube', 'fuzz', 'crush']);
export function driveCurve(type, amount, samples = 4096) {
  const kind = typeof type === 'number' ? DRIVE_TYPES[Math.round(type)] ?? 'tanh' : type;
  const a = Math.max(0, Math.min(1, Number(amount) || 0)), curve = new Float32Array(samples);
  const k = a * 40, bits = Math.round(16 - 13 * a), levels = 2 ** (bits - 1);
  const shape = {
    tanh: x => k < 1e-6 ? x : Math.tanh(k * x) / Math.tanh(k),
    // x / (1 + |kx|^p)^(1/p): p 2.5 is a gentler knee than tanh's for the same drive.
    tape: x => {const g = 1 + a * 12, y = g * x; return y / (1 + Math.abs(y) ** 2.5) ** (1 / 2.5) / (g / (1 + g ** 2.5) ** (1 / 2.5))},
    // One scale for both sides, so the curve is smooth through zero (a kink there is crossover
    // distortion on quiet signals); the positive side, biased toward saturation, bends first.
    tube: x => {const g = 1 + a * 14, bias = 0.3 * a, f = u => Math.tanh(g * u + bias) - Math.tanh(bias);
      return f(x) / Math.abs(f(-1))},
    fuzz: x => Math.max(-1, Math.min(1, (1 + a * 60) * x)),
    crush: x => Math.round(x * levels) / levels,
  }[kind] ?? (x => x);
  for (let index = 0; index < samples; index++) curve[index] = shape(index * 2 / (samples - 1) - 1);
  return curve;
}
// Whether a curve's shape leaves a DC offset on real signals, which a highpass after it removes.
export const driveIsAsymmetric = type => (typeof type === 'number' ? DRIVE_TYPES[Math.round(type)] : type) === 'tube';
