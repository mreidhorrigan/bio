// Groups of players folded to a staff each: a string section's score abridged, and the method for any reduction of a
// large ensemble (the owner, 30 September 2026: "ways to show summaries of that bot's effects ... show it in a score, both
// in abridged form and, where the right screen is available, in complete form"; "subconductors' sections should be
// nestable ad infinitum ... a method for constructing orchestral reductions from hyperlarge ensembles").
//
// foldGroups folds the notes of any grouping of lines: a group is whatever `groupOf` says a note belongs to (a desk, a
// section, a choir, a whole orchestra; a subconductor's group, at any depth), and each becomes one staff:
//   - its players in unison are one note (a part's players a few cents and milliseconds apart: their pitch's mean, the
//     longest's length), so a line, a chord and a divisi read as written;
//   - pulse by pulse (the meter's), the pitches sounding: a chord where they are SHOWN or fewer, else (a cluster, a
//     glissando mass, a pizzicato cloud) its band, its lowest and highest pitch together; a pulse like the last, nothing
//     struck again, holds on.
// Folding a fold is a fold at the next level up: the reduction of a thousand players is the same operation applied to
// its groups' groups (each folded note keeps how many players it stands for). What it leaves out (each player's own line,
// the band's inside) is the level below's.
//
// summarizeSections is its first use: strings_clodbot's seats (each note's line: 'vn1.3') folded by desk, by section (the
// default), by choir or all together, with the concertmaster's formation, phrase by phrase (/broadcast/group/formation),
// over the staff its pool begins with ("div. a 4, chord"; "a 56, glissandi").
import {Transcript} from '../transcript/transcript.js';
import {scoreTime,ENSEMBLE_SCORE_AXIS} from '../shared/score-time.js';
import {STRING_SECTIONS,SECTION_ORDER,stringSeats,expandFormation} from '../shared/performers/string-section.js';

export const SECTION_LINE=/^(vn1|vn2|va|vc|cb)\.(\d+)$/;
// Choices (ours): one note a unison within these (s, semitones); a pulse written whole up to SHOWN pitches.
export const UNISON=Object.freeze({seconds:.03,semitones:.15}),SHOWN=4;
const FORMATION=/\/group\/formation$/;

// The notes of a transcript folded by group. groupOf(note, voice) -> {id, label, order, category?} or null (left as it
// is). -> a new transcript: each group a voice ('group:<order>:<id>', labelled), its notes folded; every other voice's
// notes as they were. The same transcript where nothing is grouped.
export function foldGroups(input,groupOf){
  const transcript=input instanceof Transcript?input:Transcript.fromJSON(input),doc=transcript.toJSON();
  const groups=new Map,kept=[];
  for(const note of doc.notes){
    const group=groupOf(note,transcript.voices.get(note.voice)??{});
    if(!group){kept.push(note);continue}
    const id=`group:${String(group.order).padStart(6,'0')}:${group.id}`;
    if(!groups.has(id))groups.set(id,{...group,voice:id,source:transcript.voices.get(note.voice)??{},notes:[]});
    groups.get(id).notes.push(note);
  }
  if(!groups.size)return transcript;
  const folding=new Set([...groups.values()].flatMap(group=>group.notes.map(note=>note.voice)));
  const voices=Object.fromEntries(Object.entries(doc.voices).filter(([id])=>!folding.has(id)||kept.some(note=>note.voice===id)));
  const tickSeconds=doc.timeline.tickSeconds,folded=[];
  for(const group of groups.values()){
    voices[group.voice]={bot:{id:'group',name:group.label,category:group.category??group.source.bot?.category??'texture',pitchContract:'floating-mpe'},label:group.label,
      ...(group.source.output!==undefined?{output:group.source.output}:{})};
    const notes=[...group.notes].sort((a,b)=>a.startSeconds-b.startSeconds||a.pitch-b.pitch),merged=[];
    for(const note of notes){
      const same=merged.find(each=>Math.abs(each.startSeconds-note.startSeconds)<=UNISON.seconds&&Math.abs(each.pitch-note.pitch)<=UNISON.semitones);
      const players=note.players??1;
      if(same){same.players+=players;same.sum+=note.pitch*players;same.pitch=same.sum/same.players;same.duration=Math.max(same.duration,note.duration);continue}
      merged.push({...note,voice:group.voice,players,sum:note.pitch*players});
    }
    const sounding=(from,to)=>merged.filter(note=>note.startSeconds<to-1e-6&&note.startSeconds+note.duration>from+1e-6);
    let run=null;
    // (Each written its pulses, on the ensemble's ticks: the summary's own rhythm, never its first note's.)
    const close=()=>{if(!run)return;for(const pitch of run.pitches)folded.push({...run.base,scoreTime:scoreTime(run.base.tick,run.untilTick-run.base.tick,{axis:ENSEMBLE_SCORE_AXIS}),duration:Math.max(.05,run.until-run.base.startSeconds),pitch:+pitch.toFixed(4),players:run.players,...(run.band?{band:run.band}:{})});run=null};
    for(const [index,bar] of doc.timeline.bars.entries()){
      const per=Math.max(1,Number(bar.meter?.subdivision)||4),next=doc.timeline.bars[index+1]?.tick??tickSeconds.length-1;
      for(let tick=bar.tick;tick<next;tick+=per){
        const from=tickSeconds[tick],to=tickSeconds[Math.min(tick+per,next)]??tickSeconds.at(-1);if(!Number.isFinite(from)||!Number.isFinite(to)||to<=from)continue;
        const notes=sounding(from,to);
        if(!notes.length){close();continue}
        const pitches=[];for(const note of [...notes].sort((a,b)=>a.pitch-b.pitch))if(!pitches.some(p=>Math.abs(p-note.pitch)<=UNISON.semitones))pitches.push(note.pitch);
        const shown=pitches.length<=SHOWN?pitches:[pitches[0],pitches.at(-1)],players=notes.reduce((sum,note)=>sum+note.players,0);
        const band=pitches.length>SHOWN?{pitches:pitches.length,players}:null,struck=notes.some(note=>note.startSeconds>=from-1e-6&&note.startSeconds<to-1e-6);
        if(run&&!struck&&run.pitches.length===shown.length&&run.pitches.every((p,i)=>Math.abs(p-shown[i])<=UNISON.semitones)){run.until=to;run.untilTick=Math.min(tick+per,next);continue}
        close();
        const {sum,players:_,glide,line,scoreTime:_written,scoreId:_id,scoreArpeggio:_arpeggio,...first}=notes[0];
        run={pitches:shown,until:to,untilTick:Math.min(tick+per,next),band,players,base:{...first,tick,bar:bar.bar,tickInBar:tick-bar.tick,meter:bar.meter,offset:0,startSeconds:from,velocity:Math.max(...notes.map(note=>note.velocity??.5))}};
      }
    }
    close();
  }
  return new Transcript({...doc,voices,notes:[...kept,...folded].sort((a,b)=>a.startSeconds-b.startSeconds)});
}

// ---- A string section -------------------------------------------------------------------------------------------------
const seatOf=note=>typeof note.line==='string'?SECTION_LINE.exec(note.line):null;
// A seat's note: one naming its seat as its line, from a section's player (a bowed string seated in it: section-seat.js)
// or a bot that plays a section's seats (strings_clodbot, archived).
const seatedNote=(note,voice)=>{const seat=seatOf(note);return seat&&(voice?.bot?.section||voice?.bot?.id==='bowedstring_clodbot')?seat:null};
const CHOIRS=Object.freeze({vn1:['violins','Violins'],vn2:['violins','Violins'],va:['middle','Violas and cellos'],vc:['middle','Violas and cellos'],cb:['basses','Contrabasses']});
// The group a seat's note belongs to at a level: its desk ('Vln. I 3': chairs 5 and 6), its section, its choir, or the
// section whole.
export const SECTION_LEVELS=Object.freeze({
  desk:([,section,chair])=>{const desk=Math.ceil(Number(chair)/2);return {id:`${section}.desk${desk}`,label:`${STRING_SECTIONS[section].abbreviation} ${desk}`,order:SECTION_ORDER.indexOf(section)*100+desk}},
  section:([,section])=>({id:section,label:STRING_SECTIONS[section].name,order:SECTION_ORDER.indexOf(section)}),
  choir:([,section])=>({id:CHOIRS[section][0],label:CHOIRS[section][1],order:['violins','middle','basses'].indexOf(CHOIRS[section][0])}),
  all:()=>({id:'strings',label:'Strings',order:0}),
});
// Whether a transcript has a string section's seats in it, and how many.
export function sectionSeats(input){
  const transcript=input instanceof Transcript?input:Transcript.fromJSON(input),seats=new Set;
  for(const note of transcript.notes)if(seatedNote(note,transcript.voices.get(note.voice)))seats.add(note.line);
  return seats.size;
}
// -> {transcript (the seats folded at `level`), words: [{voice, tick, text}] (each formation's text over the staff its
// pool's first seat is folded into)}.
export function summarizeSections(input,{level='section'}={}){
  const transcript=input instanceof Transcript?input:Transcript.fromJSON(input),levelOf=SECTION_LEVELS[level];
  if(!levelOf)throw new RangeError(`A section's level is ${Object.keys(SECTION_LEVELS).join(', ')}`);
  const groupOf=(note,voice)=>{const seat=seatedNote(note,voice);return seat?levelOf(seat):null};
  const folded=foldGroups(transcript,groupOf);
  if(folded===transcript)return {transcript,words:[]};
  const voiceOf=seatId=>{const seat=SECTION_LINE.exec(seatId);if(!seat)return null;const group=levelOf(seat);return `group:${String(group.order).padStart(6,'0')}:${group.id}`};
  // (A formation as a conductorbot says it, its pools' sections in place of their seats, expanded; one said again each
  // phrase, its words written once.)
  const words=[],said=new Set;
  for(const event of transcript.events??[]){
    if(event.kind!=='message'||!FORMATION.test(event.address??''))continue;
    const plan=event.args?.[0],bar=transcript.timeline.bars.find(item=>item.bar===plan?.appliesAt?.bar);
    if(!bar||!plan?.formation?.pools||!String(plan.group??'').startsWith('strings:'))continue;
    let formation=plan.formation;
    if(formation.pools.every(pool=>Array.isArray(pool.sections))){try{formation=expandFormation(formation,stringSeats(plan.size??String(plan.group).slice('strings:'.length)))}catch{continue}}
    for(const pool of formation.pools){
      const voice=pool.seats.map(voiceOf).find(id=>id&&folded.voices.has(id));if(!voice)continue;
      const k=Math.max(...pool.parts)+1,n=pool.seats.length,name=STRING_SECTIONS[pool.id]?null:pool.id,text=`${name?`${name}: `:''}${k===1?'tutti':k===n?`a ${n}`:`div. a ${k}`}, ${pool.texture}`;
      const key=`${bar.tick}|${voice}|${text}`;if(said.has(key))continue;said.add(key);
      words.push({voice,tick:bar.tick,text});
    }
  }
  return {transcript:folded,words};
}
