// A part's own bars where it counts its own meter (the backlog's "A score of parts in their own meters": "A part in a
// stream is written in the ensemble's bars, its own bar lines lost among them"). A part is told a stream by
// /agent/stream {stream: {meter, id} | null, anchor, relation?}, and counts it from its anchor exactly as the agent
// does (framework/agent.js takeStreams, setStream, relateStream):
//   - a stream alone: its own tick is the shared tick; a bar is its meter's numerator times its subdivision of them
//     (rhythm-vocabulary.js streamOf), so its beat is its subdivision in shared ticks;
//   - with a relation: its own position is the part time map's (shared/part-time-map.js), a rate held ({ratio}) or
//     glided ({to, ticks | bars, from?}), in own ticks a shared tick: the ratio times its subdivision over the
//     ensemble's.
// The part is then re-expressed in its own time -- its own ticks one axis, the ensemble's bars before and after its
// streams, its own bars during them -- as a transcript of its own (partTranscript), which the score lays out as it lays
// out any other (notation/score.js), and whose bars the engraver scales back onto the shared timeline
// (notation/lilypond.js, per-staff timing).
import {changed,glideAt,positionAtShared,positionAtRational,rateAtRational,sharedAt,timeMap,toNumber} from '../shared/part-time-map.js';
import {Rational} from '../transcript/rational.js';
import {storedTick} from '../transcript/tempo-plan.js';
import {readScoreTime,mapScoreTime} from '../shared/score-time.js';

const cycleOf=meter=>(Number(meter.numerator)||4)*(Number(meter.subdivision)||4);
const inTicks=(ratio,own,shared)=>Array.isArray(ratio)?[ratio[0]*own,ratio[1]*shared]:null;
const small=([n,d])=>new Rational(Number(n),Number(d));
const exactPosition=(stream,t)=>stream.map?small(positionAtRational(stream.map,[BigInt(t.n),BigInt(t.d)])):t.sub(stream.anchor);

// The streams a part was told, each in effect from its anchor to the next's: [{from, to, meter, id, anchor, cycle,
// map}], `to` Infinity for the last. `at(tick)`: the ensemble's meter at a shared tick. A malformed message is left
// out, as the agent refuses it.
export function partStreams(told,{meterAt,normalizeMeter=meter=>meter}={}){
  const spans=[];let current=null;
  const close=at=>{if(current){current.to=at;if(current.to>current.from)spans.push(current);current=null}};
  for(const message of told){
    const at=message.anchor,relation=message.relation&&typeof message.relation==='object'?message.relation:null;
    if(relation!==null&&!('stream' in message)){if(current)current.map=relate(current,relation,at,meterAt);continue}
    close(at);
    const stream=message.stream;if(!stream?.meter)continue;
    const meter=normalizeMeter(stream.meter);
    current={from:at,to:Infinity,meter,id:typeof stream.id==='string'?stream.id:meter.label??`${meter.numerator}/${meter.denominator}`,anchor:at,cycle:cycleOf(meter),map:null};
    if(relation)current.map=relate(current,relation,at,meterAt);
  }
  if(current)spans.push(current);
  return spans;
}
function relate(stream,relation,at,meterAt){
  const meter=meterAt(at),shared=Number(meter?.subdivision),own=Number(stream.meter.subdivision)||shared;
  if(!(shared>0))return stream.map;
  const map=stream.map??timeMap({anchor:stream.anchor,rate:[1,1]});
  const ticks=Number.isSafeInteger(relation.ticks)?relation.ticks:Number.isSafeInteger(relation.bars)?relation.bars*(Number(meter.pulsesPerBar)||cycleOf(meter)):null;
  try{
    if(relation.ratio)return changed(map,{at,rate:inTicks(relation.ratio,own,shared)});
    if(relation.to&&ticks>0)return changed(map,{at,to:inTicks(relation.to,own,shared),from:inTicks(relation.from,own,shared),ticks});
  }catch{}
  return stream.map;
}
// A stream's own tick k (from its anchor) at its shared position, and a shared position's own position, whole or not,
// never rounded to a whole tick (numbers: the map's own answers, exact where it holds a rate; the anchor plus k where
// there is none).
export const sharedOf=(stream,k)=>stream.map?sharedAt(stream.map,k):stream.anchor+k;
export const ownOf=(stream,t)=>stream.map?toNumber(positionAtShared(stream.map,t)):t-stream.anchor;

// The part's own time: one axis of ticks, the shared tick before its first stream, its own ticks during each stream,
// and the shared tick again after, shifted by what the stream took more or less than the ensemble's time. Each segment
// {sharedFrom, sharedTo, ownFrom, ownTo, stream | null}. `endTick`: the last shared tick.
export function ownTimeline(spans,{endTick}){
  const segments=[];let shared=0,own=Rational.ZERO;
  const append=(from,to,stream)=>{
    const length=stream?exactPosition(stream,Rational.of(to)).sub(exactPosition(stream,Rational.of(from))):Rational.of(to).sub(from),end=own.add(length);
    segments.push({sharedFrom:from,sharedTo:to,ownFrom:own.toNumber(),ownTo:end.toNumber(),scoreFrom:storedTick(own),scoreTo:storedTick(end),stream});own=end;
  };
  const plain=(from,to)=>{if(to>from)append(from,to,null)};
  for(const span of spans){
    if(span.from>=endTick)break;
    plain(shared,span.from);
    const to=Math.min(span.to,endTick);append(span.from,to,span);shared=to;
  }
  plain(shared,endTick);
  return segments;
}
// A whole shared tick on the own axis, and an own position back on the shared one.
export function toOwn(segments,t){
  const segment=segments.find(each=>t<each.sharedTo)??segments.at(-1);
  if(!segment)return t;
  return segment.ownFrom+(segment.stream?ownOf(segment.stream,t):t-segment.sharedFrom);
}
export function toOwnScore(segments,value){
  const at=Rational.of(value);let own=Rational.ZERO;
  for(const [index,segment] of segments.entries()){
    const inside=at.lt(segment.sharedTo)||index===segments.length-1;
    const from=Rational.of(segment.sharedFrom),to=inside?at:Rational.of(segment.sharedTo);
    own=own.add(segment.stream?exactPosition(segment.stream,to).sub(exactPosition(segment.stream,from)):to.sub(from));
    if(inside)return own;
  }
  return at;
}
export function toShared(segments,k){
  const segment=segments.find(each=>k<each.ownTo-1e-9)??segments.at(-1);
  if(!segment)return k;
  const into=k-segment.ownFrom;
  return segment.stream?sharedOf(segment.stream,into):segment.sharedFrom+into;
}
// The part's bars on its own axis: the ensemble's bars where no stream is, its own where one is (from its anchor, every
// `cycle` own ticks; the last cut where the stream ends before its bar does, written as long as it lasted).
// `ensembleBars`: [{bar, tick, meter}] of the shared timeline. -> [{bar, tick (own), meter, stream, partial, shared:
// {from, to} (shared ticks), glide}]
export function ownBars(segments,ensembleBars,{endTick}){
  const out=[];
  for(const segment of segments){
    if(!segment.stream){
      // A stream that ended mid-bar leaves the rest of that bar: written as a bar of its own length.
      const first=ensembleBars.find(bar=>bar.tick>=segment.sharedFrom),before=[...ensembleBars].reverse().find(bar=>bar.tick<segment.sharedFrom);
      if(before&&(!first||first.tick>segment.sharedFrom)){
        const to=Math.min(first?.tick??endTick,segment.sharedTo);
        out.push({tick:segment.ownFrom,scoreTick:segment.scoreFrom,meter:before.meter,stream:null,partial:to-segment.sharedFrom,shared:{from:segment.sharedFrom,to},glide:false});
      }
      ensembleBars.forEach((bar,index)=>{
        if(bar.tick<segment.sharedFrom||bar.tick>=segment.sharedTo)return;
        const next=ensembleBars[index+1]?.tick??endTick,to=Math.min(next,segment.sharedTo);
        out.push({tick:segment.ownFrom+bar.tick-segment.sharedFrom,scoreTick:storedTick(Rational.of(segment.scoreFrom).add(bar.tick).sub(segment.sharedFrom)),meter:bar.meter,stream:null,partial:to<next?to-bar.tick:null,shared:{from:bar.tick,to},glide:false});
      });
      continue;
    }
    const stream=segment.stream,length=segment.ownTo-segment.ownFrom;
    for(let k=0;k<length-1e-9;k+=stream.cycle){
      const end=Math.min(k+stream.cycle,length),cut=end<k+stream.cycle-1e-9,from=sharedOf(stream,k),to=cut?segment.sharedTo:sharedOf(stream,end);
      out.push({tick:segment.ownFrom+k,scoreTick:storedTick(Rational.of(segment.scoreFrom).add(k)),meter:stream.meter,stream,partial:cut?end-k:null,shared:{from,to},
        glide:Boolean(stream.map&&glideAt(stream.map,Math.floor(from)))});
      if(out.length>8192)break;
    }
  }
  return out.sort((a,b)=>a.tick-b.tick).map((bar,index)=>({...bar,bar:index}));
}

// Project the written plan through the declared coordinate map. On a cell where the ensemble's authored BPM is B,
// and dx/du = r + c(u-u0), the part's BPM at x is B*r*sharedSubdivision/ownSubdivision times
// sqrt(1 + 2c(x-x0)/r²). Its boundaries are the exact forward images of authored boundaries, never inverse estimates
// at sampled physical times. The result describes this transcript's documented axis window.
export function partTempo(transcript,segments,{endTick}){
  if(transcript.timeline.scoreTempo.some(row=>row[2]))throw new TypeError('Project a part tempo from its ensemble source, not from an already projected part');
  const cuts=new Map,put=value=>{const at=Rational.of(value);if(at.ge(0)&&at.le(endTick))cuts.set(at.toString(),at)};
  put(0);put(endTick);
  for(const [tick] of transcript.timeline.scoreTempo)put(tick);
  for(const bar of transcript.timeline.bars)put(bar.tick);
  for(const segment of segments){
    put(segment.sharedFrom);put(segment.sharedTo);
    for(const p of segment.stream?.map?.pieces??[]){
      if(p.at>=segment.sharedFrom&&p.at<segment.sharedTo)put(p.at);
      if(p.at+p.ticks>segment.sharedFrom&&p.at+p.ticks<segment.sharedTo)put(p.at+p.ticks);
    }
  }
  const positions=[...cuts.values()].sort((a,b)=>a.cmp(b)),rows=[];let lastMeter=null;
  for(let i=0;i<positions.length-1;i++){
    const at=positions[i],next=positions[i+1],segment=segments.find(s=>at.lt(s.sharedTo)),shared=transcript.barAt(at)?.meter;
    if(!segment||!shared)continue;
    const own=segment.stream?.meter??shared,map=segment.stream?.map;
    const value=map?rateAtRational(map,[BigInt(at.n),BigInt(at.d)]):{rate:[1n,1n],slope:[0n,1n]},rate=small(value.rate),slope=small(value.slope);
    const from=toOwnScore(segments,at),until=toOwnScore(segments,next),base=transcript.scoreBpmAt(at),
      bpm=base==null?null:base*rate.toNumber()*shared.subdivision/own.subdivision,
      curve=bpm!=null&&!slope.isZero()?{kind:'sqrt-linear',slope:slope.mul(2).div(rate.mul(rate)).toString(),until:storedTick(until)}:null,
      meter=`${own.denominator}:${own.subdivision}:${own.tempoUnit??''}`;
    const previous=rows.at(-1);
    if(previous&&previous[1]===bpm&&!previous[2]&&!curve&&(bpm===null||meter===lastMeter))continue;
    rows.push([storedTick(from),bpm,...(curve?[curve]:[])]);lastMeter=meter;
  }
  const end=storedTick(toOwnScore(segments,endTick));
  if(rows.at(-1)?.[1]!=null)rows.push([end,null]);
  return rows;
}

// The part in its own time, as a transcript document of its own (transcript/transcript.js): its own ticks' times (each
// own tick where its shared position falls, the shared tick's time moved through that tick in proportion, as the agent
// moves a part's event time: framework/agent.js tickAsPart), its tempo (its own beats a minute there), its bars
// (ownBars), and its notes placed by their times: each on the own tick it falls in, its offset the seconds past it.
// `transcript`: the shared one; `voice`: the part's. -> {document, bars}, or null where the part is never in a stream.
export function partTranscript(transcript,voice,{normalizeMeter=meter=>meter}={}){
  const told=transcript.streamsOf?.(voice)??[];if(!told.length)return null;
  const times=transcript.timeline.tickSeconds,endTick=times.length-1;if(endTick<1)return null;
  const meterAt=tick=>transcript.barAt(Math.max(0,Math.min(endTick,Math.floor(tick))))?.meter??null;
  const spans=partStreams(told,{meterAt,normalizeMeter}).filter(span=>span.from<endTick);if(!spans.length)return null;
  const segments=ownTimeline(spans,{endTick}),ensembleBars=transcript.timeline.bars.map(bar=>({bar:bar.bar,tick:bar.tick,meter:bar.meter}));
  const bars=ownBars(segments,ensembleBars,{endTick});
  const holds=new Map(transcript.timeline.holds??[]);
  // The music time of a shared position: the tick it falls in, its hold first, then the rest of the tick in proportion.
  const secondsAt=position=>{
    const value=Math.min(endTick,Math.max(0,position)),tick=Math.min(endTick-1,Math.floor(value)),fraction=value-tick;
    if(fraction<1e-12)return times[tick];
    const hold=holds.get(tick)??0;
    return times[tick]+hold+fraction*(times[tick+1]-times[tick]-hold);
  };
  const ownEnd=Math.floor(segments.at(-1).ownTo+1e-9),ownTimes=[],ownHolds=[];
  for(let k=0;k<=ownEnd;k++){
    const value=toShared(segments,k);ownTimes.push(secondsAt(value));
    if(Math.abs(value-Math.round(value))<1e-12&&holds.has(Math.round(value)))ownHolds.push([k,holds.get(Math.round(value))]);
  }
  const barOf=k=>{let found=bars[0];for(const bar of bars){if(bar.tick<=k+1e-9)found=bar;else break}return found};
  const tempo=[];let last=null;
  for(let k=0;k<ownTimes.length-1;k++){
    const bar=barOf(k),hold=ownHolds.find(([tick])=>tick===k)?.[1]??0,interval=ownTimes[k+1]-ownTimes[k]-hold;
    if(!(interval>0))continue;
    const bpm=60/interval/(Number(bar.meter.subdivision)||4);
    if(last===null||Math.abs(bpm-last)>1e-9*bpm){tempo.push([k,bpm]);last=bpm}
  }
  const lookahead=transcript.timeline.lookahead||0,notes=[],scoreAxis=`part:${voice}`;
  for(const note of transcript.notes){
    if(note.voice!==voice)continue;
    const at=Number.isInteger(note.tick)&&times[note.tick]!=null?times[note.tick]+(Number(note.offset)||0):Number(note.startSeconds)-lookahead;
    if(!Number.isFinite(at))continue;
    let low=0,high=ownTimes.length-1;while(low<high){const middle=(low+high+1)>>1;if(ownTimes[middle]<=at+1e-9)low=middle;else high=middle-1}
    const bar=barOf(low),tick=low,offset=Math.max(0,at-ownTimes[tick]),bpm=tempo.findLast?.(([from])=>from<=tick)?.[1]??tempo.at(-1)?.[1];
    let symbolic={};
    if(note.scoreTime){
      readScoreTime(note,{axis:transcript.scoreAxis});
      symbolic={scoreTime:mapScoreTime(note.scoreTime,at=>toOwnScore(segments,at),{axis:scoreAxis})};
    }
    // Older explicitly written tick fields also belong to the original axis. While their producers are migrated,
    // map their two authored boundaries; never keep a shared duration on a part's new axis.
    const written=Number.isFinite(note.writtenTick)?toOwn(segments,note.writtenTick):null;
    const legacy=written===null?{}:{writtenTick:written,...(note.writtenTicks>0?{writtenTicks:toOwn(segments,note.writtenTick+note.writtenTicks)-written}:{})};
    notes.push({...note,...legacy,...symbolic,tick,bar:bar.bar,tickInBar:Math.round(tick-bar.tick),meter:bar.meter,bpm,offset,realizedOffset:offset});
  }
  const writtenBars=bars.map((bar,i)=>({bar:bar.bar,tick:bar.scoreTick,meter:bar.meter,
    ...(bars[i+1]?{scoreDuration:storedTick(Rational.of(bars[i+1].scoreTick).sub(bar.scoreTick))}:{})}));
  const document={format:'musebots-transcript',version:1,scoreAxis,source:transcript.source,voices:{[voice]:transcript.voices.get(voice)},
    timeline:{tickSeconds:ownTimes,tempo,scoreTempo:partTempo(transcript,segments,{endTick}),bars:writtenBars,lookahead,holds:ownHolds},
    notes,events:[]};
  return {document,bars,spans};
}
