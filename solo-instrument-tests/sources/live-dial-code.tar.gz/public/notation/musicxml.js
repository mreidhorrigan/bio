// MusicXML 4.0 (partwise) from a score (score.js). Exact: every duration is a whole number of divisions -- the
// divisions of a measure are the least common multiple of its values' denominators, restated where they change, so a
// 13:8 or a 3:2 inside a 5:4 needs no rounding -- and a nested tuplet carries its cumulative ratio in
// <time-modification> and a <tuplet> bracket of its own at each level (number 1 outermost), each with its actual and
// normal counts and types, as Dorico and Finale write them. Microtones are exact in <alter> (a decimal), the displayed
// accidental is a quarter-tone one where it applies, and the cents left over are printed above. What sounded, where it
// differs from what is written, is kept in the note's attack and release (in divisions) and its velocity in dynamics
// (per cent of forte, MIDI 90), so nothing about the performance is lost to the page. And what the engraver reads of a
// score (lilypond.js) is written for a reader to give it back (research/BROWSER_SCORING_PLAN.md, step 3): in MusicXML's
// own elements where it has them -- a desk's players, a player's part's name, a technique held over several notes, a
// string multiphonic's touched note, the voice a note's own direction belongs to -- and else in this file's own: the
// bars' meters as the score counts them (METERS_FIELD: a grouping, a reading, a signature shown simpler, which a
// <time> does not hold), a part's staff left out of the systems it rests through (CONDENSED_FIELD), its line moving
// between a grand staff's staves (ACROSS_STAVES_FIELD) and its section's lines written divisi (DIVISI_FIELD), a chord
// symbol's microtonal mark in its kind's text, and a woodwind's keys in words naming its instrument (a multiphonic's, a
// shaded fingering's).
import {CUE_SCALE} from './parts.js';
import {Rational} from '../transcript/rational.js';
import {NOTE_TYPES,defaultGrouping} from './rhythm.js';
import {chordText} from './chords.js';
import {centsLabel,ALTER_PRECISION} from './pitch.js';
import {localDate} from './score.js';

// A metronome mark's note values, by the denominator of the beat.
const BEAT_UNITS={1:'whole',2:'half',4:'quarter',8:'eighth',16:'16th',32:'32nd',64:'64th'};
// The tensions a chord kind's own name implies (a ninth chord its ninth; an eleventh its ninth and eleventh): a degree
// the kind implies is not written again.
const IMPLIED_TENSIONS=Object.freeze({'dominant-ninth':[9],'major-ninth':[9],'minor-ninth':[9],'dominant-11th':[9,11],'major-11th':[9,11],'minor-11th':[9,11],
  'dominant-13th':[9,11,13],'major-13th':[9,11,13],'minor-13th':[9,11,13]});
// Definitions: MusicXML's conventions and the file's layout, not choices.
// The file's nesting, for its indentation: a part's or the header's sections, their elements (notes, directions,
// attributes), and those elements' children.
const SECTION=2,ELEMENT=3,CHILD=4;
// Durations count quarters (a quarter note is `divisions`); a quarter's denominator; a dot adds half.
const QUARTERS_PER_WHOLE=4,QUARTER=4,DOTTED=1.5;
// MusicXML's voices to a staff (1-4 on the first, 5-8 on the second).
const VOICES_PER_STAFF=4;
// A note's dynamics are per cent of forte, which MusicXML takes as MIDI velocity 90 of 127.
const MIDI_MAX=127,FORTE_VELOCITY=90,PER_CENT=100;
// Decimals written to four places; a length within rounding of none is none.
const DECIMAL_SCALE=1e4,SAME_LENGTH=1e-9;

// Choices: the size (points) of words without one of their own, and where a note's cents stand (centsPlacement): above
// it from its staff's middle line (B4 on a treble staff, D3 on a bass staff; an octave clef's an octave from there),
// below it lower down.
const WORDS_SIZE=8,STAFF_MIDDLE=Object.freeze({G:71,F:50}),SEMITONES_PER_OCTAVE=12;
// What the bars ahead are planned to hold (their chords, their tempi) is coloured, so a player tells it from what was
// played. (A reader that drops the colour -- Verovio does a harmony's and a metronome mark's -- is given it again by the
// page showing it: public/score/view.js, the stage's score.)
export const PLANNED_COLOUR='#1F5FBF';
// A dashed line's number: a tempo's (accel. - - -) apart from a dynamic's (cresc. - - -, number 1), which may overlap it,
// and a technique's (sul pont. - - -) after them, one a voice (a desk's two may hold their own at once).
const TEMPO_DASHES=2,TECHNIQUE_DASHES=2;
// A staff the engraver leaves out of each system it rests through, its first too (score.js `condensed`: a condensed
// section's, or a desk's beside it). MusicXML hides a staff in the systems its writer lays out (<staff-details
// print-object="no">); the engraver lays out these, so the staff says so of itself, in its <score-part>'s
// <identification>.
export const CONDENSED_FIELD='musebots-condensed';
// A part's line moving between its grand staff's staves (score.js `acrossStaves`: a monophonic line on the staff that
// reads each chord with the fewer ledger lines), and its section's lines, so many, written divisi (`divisi`): as the
// staff's <staff> numbers do not say where the line keeps to one staff, nor a staff of two lines whether it is a
// section's.
export const ACROSS_STAVES_FIELD='musebots-across-staves',DIVISI_FIELD='musebots-divisi';
// The bars' meters as the score counts them (score.js measures' `meter`), in JSON: whether the score writes additive
// signatures, and each bar whose meter changes or is restated -- its number, its meter's numerator, denominator,
// groups, reading and signature shown, whether it is marked changed, and a hypermetrical cycle's bars' meters. A <time>
// holds its numerator (or its groups where they are shown), not a grouping it leaves to the beams.
export const METERS_FIELD='musebots-meters';
// A glide (score.js): MusicXML's slide, a portamento's line -- continuous, no pitch between discerned, where a glissando's
// sounds them -- numbered by its voice (a slide joins a note to its voice's next, so each voice has one at a time, and
// a reader pairing them by number never takes another voice's); and the value of the grace note a glide slides from
// where the score writes no note before it at that pitch.
const GRACE_TYPE='eighth';

const R=(n,d=1)=>new Rational(n,d);
const escape=value=>String(value).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
const lcm=(a,b)=>{let x=a,y=b;while(y){[x,y]=[y,x%y]}return a/x*b};
const typeOfLength=length=>NOTE_TYPES.find(([,value])=>value===length.toNumber())?.[0]??'quarter';
const decimal=value=>{const text=(Math.round(value*DECIMAL_SCALE)/DECIMAL_SCALE).toString();return text==='-0'?'0':text};
// (An alteration as the score holds it, to a millionth: pitch.js.)
const alterText=value=>{const text=(Math.round(value*ALTER_PRECISION)/ALTER_PRECISION).toString();return text==='-0'?'0':text};

// The divisions a measure needs: every value and offset a whole number of them (a quarter note is `divisions`).
function divisionsFor(voices,directions,measureStart,measureLength){
  let value=1;
  const add=length=>{const quarters=length.mul(QUARTERS_PER_WHOLE);value=lcm(value,quarters.d);if(!Number.isSafeInteger(value))throw new RangeError('A measure needs more divisions than MusicXML can count')};
  add(measureLength);
  for(const voice of voices)for(const element of voice.elements){add(element.end.sub(element.start));add(element.start.sub(measureStart))}
  for(const direction of directions)add(direction.start.sub(measureStart));
  return value;
}
const inDivisions=(length,divisions)=>{const value=length.mul(QUARTERS_PER_WHOLE).mul(divisions);if(!value.isInteger())throw new RangeError(`${length} is not a whole number of ${divisions} divisions`);return value.n};

// A written bar is indivisible. A declared hypermetrical cycle already comprises bars with their own signatures;
// page width cannot invent further divisions, including inside a fractionally bounded bar.
// [{from, to, first, last}]
export function measureSegments(measure){
  const end=measure.start.add(measure.length);
  // (A hypermetrical cycle, score.js cycleOf: its bars, each a measure with its signature where it changes, ordinary
  // barlines between them.)
  if(measure.cycle?.length)return measure.cycle.map((bar,index)=>({from:measure.start.add(bar.offset),to:measure.start.add(bar.offset).add(bar.length),first:index===0,last:index===measure.cycle.length-1,
    meter:bar.meter,cycle:true,meterChanged:index===0||bar.meter.numerator!==measure.cycle[index-1].meter.numerator||bar.meter.denominator!==measure.cycle[index-1].meter.denominator}));
  return [{from:measure.start,to:end,first:true,last:true}];
}

export function scoreToMusicXML(score,{encodingDate=localDate(),software='Musebots notation'}={}){
  centsCount=0;const out=[];const line=(depth,text)=>out.push(`${'  '.repeat(depth)}${text}`);
  out.push('<?xml version="1.0" encoding="UTF-8" standalone="no"?>');
  out.push('<!DOCTYPE score-partwise PUBLIC "-//Recordare//DTD MusicXML 4.0 Partwise//EN" "http://www.musicxml.org/dtds/partwise.dtd">');
  line(0,'<score-partwise version="4.0">');
  line(1,`<work><work-title>${escape(score.title)}</work-title></work>`);
  line(1,'<identification>');
  line(SECTION,`<creator type="composer">${escape(score.creator??'Musebots')}</creator>`);
  line(SECTION,'<encoding>');
  line(ELEMENT,`<software>${escape(software)}</software>`);line(ELEMENT,`<encoding-date>${encodingDate}</encoding-date>`);
  for(const [element,type] of [['accidental','yes'],['beam','yes'],['stem','no']])line(ELEMENT,`<supports element="${element}" type="${type}"/>`);
  line(SECTION,'</encoding>');
  line(SECTION,'<miscellaneous>');
  if(score.subtitle)line(ELEMENT,`<miscellaneous-field name="performance">${escape(score.subtitle)}</miscellaneous-field>`);
  line(ELEMENT,`<miscellaneous-field name="${METERS_FIELD}">${escape(JSON.stringify(metersOf(score)))}</miscellaneous-field>`);
  line(SECTION,'</miscellaneous>');
  line(1,'</identification>');
  line(1,'<credit page="1"><credit-type>title</credit-type><credit-words justify="center" halign="center" valign="top" font-size="22">'+escape(score.title)+'</credit-words></credit>');
  // (A player's part names itself (parts.js `part`), as its subtitle where that is its name: one credit, both its kinds.)
  const partName=score.part!=null?'<credit-type>part name</credit-type>':'',named=partName&&score.subtitle===score.part;
  if(score.subtitle)line(1,'<credit page="1"><credit-type>subtitle</credit-type>'+(named?partName:'')+'<credit-words justify="center" halign="center" valign="top" font-size="11" font-style="italic">'+escape(score.subtitle)+'</credit-words></credit>');
  if(partName&&!named)line(1,'<credit page="1">'+partName+'<credit-words justify="left" halign="left" valign="top" font-size="11">'+escape(score.part)+'</credit-words></credit>');
  line(1,'<credit page="1"><credit-type>composer</credit-type><credit-words justify="right" halign="right" valign="top" font-size="11">'+escape(score.creator??'Musebots')+'</credit-words></credit>');
  line(1,'<part-list>');
  for(const part of score.parts){
    line(SECTION,`<score-part id="${part.id}">`);
    const fields=[part.condensed?[CONDENSED_FIELD,'yes']:null,part.acrossStaves?[ACROSS_STAVES_FIELD,'yes']:null,part.divisi?[DIVISI_FIELD,part.divisi]:null].filter(Boolean);
    if(fields.length)line(ELEMENT,`<identification><miscellaneous>${fields.map(([name,value])=>`<miscellaneous-field name="${name}">${escape(value)}</miscellaneous-field>`).join('')}</miscellaneous></identification>`);
    line(ELEMENT,`<part-name>${escape(part.name)}</part-name>`);line(ELEMENT,`<part-abbreviation>${escape(part.abbreviation)}</part-abbreviation>`);
    if(part.kind==='percussion')for(const [note,drum] of part.instruments)line(ELEMENT,`<score-instrument id="${part.id}-I${note}"><instrument-name>${escape(drum.name)}</instrument-name></score-instrument>`);
    // A desk's players, its seats (score.js `desk`: "vn1.3", "vn1.4").
    for(const [k,seat] of (part.desk??[]).entries())line(ELEMENT,`<player id="${part.id}-M${k+1}"><player-name>${escape(seat)}</player-name></player>`);
    if(part.kind==='percussion')for(const [note] of part.instruments)line(ELEMENT,`<midi-instrument id="${part.id}-I${note}"><midi-channel>10</midi-channel><midi-unpitched>${note+1}</midi-unpitched></midi-instrument>`);
    line(SECTION,'</score-part>');
  }
  line(1,'</part-list>');
  for(const [partIndex,part] of score.parts.entries()){
    const open=new Map;
    line(1,`<part id="${part.id}">`);
    let divisions=null;
    // Each ramp's dashed line (accel. - - -) stops where the tempo arrives, in whatever measure that is -- the score's
    // end, at the last measure's.
    const dashed=[...(partIndex===0?score.tempo:[]),...part.measures.flatMap(content=>content.directions.filter(direction=>direction.kind==='tempo'))].filter(mark=>mark.words&&mark.until);
    part.measures.forEach((measureContent,index)=>{for(const [piece,segment] of measureSegments(score.measures[index]).entries()){
      const measure=score.measures[index],last=index===score.measures.length-1,from=segment.from,to=segment.to,length=to.sub(from);
      // (A direction goes where it starts: one before the bar's first piece ends in it, one at or after its last's start in that.)
      const within=start=>(segment.first||start.ge(from))&&(segment.last||start.lt(to));
      const tempo=partIndex===0?score.tempo.filter(mark=>mark.start.ge(from)&&mark.start.lt(to)):[];
      const stops=dashed.filter(mark=>mark.until.ge(from)&&(mark.until.lt(to)||last&&segment.last&&mark.until.eq(to))).map(mark=>({kind:'dashes',start:mark.until,staff:1}));
      // (A line's stop before any start at the same moment: a ramp that ends where the next begins.)
      const directions=[...stops,...measureContent.directions.filter(direction=>segment.first&&segment.last||within(direction.start)),...tempo.map(mark=>({kind:'tempo',...mark,staff:1}))];
      // (A measure rest across a cycle's bars a measure rest in each, its voice's own, its fermata over the last: none of it
      // in its first alone.)
      const voices=measureContent.voices.map(voice=>{
        if(segment.first&&segment.last)return voice;
        const elements=voice.elements.filter(element=>element.start.ge(from)&&element.start.lt(to)&&!element.measureRest),rest=voice.elements.find(element=>element.measureRest);
        return {...voice,elements:rest&&!elements.length?[{...rest,start:from,end:to,fermata:segment.last&&rest.fermata}]:elements};
      }).filter(voice=>voice.elements.length);
      // Every staff gets something: a measure rest where no voice wrote anything (a line moving between the staves writes
      // on both).
      for(let staff=1;staff<=part.staves;staff++)if(!voices.some(voice=>voice.staff===staff||voice.elements.some(element=>element.staff===staff)))
        voices.push({staff,voice:(staff-1)*VOICES_PER_STAFF+1,elements:[{start:from,end:to,rest:true,measureRest:true,tuplets:[],beams:[],tupletStarts:[],tupletStops:[]}]});
      const needed=divisionsFor(voices,directions,from,length),first=index===0&&segment.first;
      const signature=segment.meter??measure.meter,partial=!length.eq(new Rational(signature.numerator,signature.denominator));
      line(SECTION,segment.first?`<measure number="${measure.number}"${partial?' implicit="yes"':''}>`:`<measure number="${measure.number}-${piece+1}" implicit="yes">`);
      const signed=segment.cycle?segment.meterChanged:segment.first&&measure.meterChanged;
      if(first||needed!==divisions||signed){
        line(ELEMENT,'<attributes>');
        if(first||needed!==divisions)line(CHILD,`<divisions>${needed}</divisions>`);
        // A drum staff has no key: the key is kept (zero) but not printed.
        if(first)line(CHILD,part.kind==='percussion'?'<key print-object="no"><fifths>0</fifths></key>':`<key><fifths>${score.key.fifths}</fifths><mode>${score.key.mode}</mode></key>`);
        if(first||signed)line(CHILD,timeElement(segment.meter??measure.meter,score.additiveSignatures));
        if(first&&part.staves>1)line(CHILD,`<staves>${part.staves}</staves>`);
        if(first)part.clefs.forEach((clef,i)=>line(CHILD,`<clef${part.staves>1?` number="${i+1}"`:''}><sign>${clef.sign}</sign>${clef.sign==='percussion'?'':`<line>${clef.line}</line>`}${clef.octave?`<clef-octave-change>${clef.octave}</clef-octave-change>`:''}</clef>`));
        // (A drum staff's five lines; a part's cue staff small, parts.js.)
        if(first&&(part.kind==='percussion'||part.cue))line(CHILD,`<staff-details>${part.kind==='percussion'?'<staff-lines>5</staff-lines>':''}${part.cue?`<staff-size>${Math.round(100*CUE_SCALE.numerator/CUE_SCALE.denominator)}</staff-size>`:''}</staff-details>`);
        line(ELEMENT,'</attributes>');
        divisions=needed;
      }
      const measureDivisions=inDivisions(length,divisions);
      voices.sort((a,b)=>a.staff-b.staff||a.voice-b.voice);
      voices.forEach((voice,voiceIndex)=>{
        // Tuplets above the staff, where they are kept clear of the dynamics; a lower voice's below, on its stem side.
        const placement=voices.some(other=>other.staff===voice.staff&&other.voice<voice.voice)?'below':'above';
        const pending=voiceIndex===0?[...directions].sort((a,b)=>a.start.cmp(b.start)):[];
        // (A line moving between a grand staff's staves has its dynamics and hairpins under its lower staff, clear of the
        // beams crossing between the staves, a hairpin on one staff however often its notes change.)
        const markedOn=()=>part.acrossStaves?part.staves:voice.staff;
        for(const element of voice.elements){
          while(pending.length&&pending[0].start.lt(element.end)){
            const direction=pending.shift(),offset=direction.start.gt(element.start)?inDivisions(direction.start.sub(element.start),divisions):0;
            writeDirection(line,direction,offset,voice,direction.kind==='dynamics'&&part.acrossStaves?markedOn():null);
          }
          // An octave sign: its notes keep their sounding pitch; 8va is displayed down an octave (type "down"), 8vb up.
          // (A note's own directions say its voice: the next note in it takes them, an octave sign's stop the note before.)
          const own=`<voice>${voice.voice}</voice>`;
          if(element.ottavaStart)line(ELEMENT,`<direction placement="${element.ottavaStart>0?'above':'below'}"><direction-type><octave-shift type="${element.ottavaStart>0?'down':'up'}" size="8" number="1"/></direction-type>${own}<staff>${element.staff??voice.staff}</staff></direction>`);
          // A long change in words with dashes (cresc. - - -), a short one as a wedge; either stops where it arrives, on
          // the staff it began on.
          if(element.hairpinEnd){const begun=open.get(voice.staff);line(ELEMENT,`<direction placement="below"><direction-type>${begun?.dashes?'<dashes type="stop" number="1"/>':'<wedge type="stop" number="1"/>'}</direction-type>${own}<staff>${begun?.staff??markedOn()}</staff></direction>`);open.delete(voice.staff)}
          if(element.hairpin){
            const staff=markedOn();open.set(voice.staff,{dashes:Boolean(element.hairpinText),staff});
            if(element.hairpinText)line(ELEMENT,`<direction placement="below"><direction-type><words font-style="italic">${element.hairpin==='crescendo'?'cresc.':'dim.'}</words></direction-type><direction-type><dashes type="start" number="1"/></direction-type>${own}<staff>${staff}</staff></direction>`);
            else line(ELEMENT,`<direction placement="below"><direction-type><wedge type="${element.hairpin==='crescendo'?'crescendo':'diminuendo'}" number="1"/></direction-type>${own}<staff>${staff}</staff></direction>`);
          }
          writeElement(line,element,voice,part,divisions,placement);
          if(element.ottavaStop)line(ELEMENT,`<direction><direction-type><octave-shift type="stop" size="8" number="1"/></direction-type>${own}<staff>${element.staff??voice.staff}</staff></direction>`);
        }
        for(const direction of pending)writeDirection(line,direction,0,voice);
        if(voiceIndex<voices.length-1)line(ELEMENT,`<backup><duration>${measureDivisions}</duration></backup>`);
      });
      const barline=segment.last?measureContent.barline:segment.cycle?null:'dashed';
      if(barline)line(ELEMENT,`<barline location="right"><bar-style>${barline}</bar-style></barline>`);
      line(SECTION,'</measure>');
    }});
    line(1,'</part>');
  }
  line(0,'</score-partwise>');
  return `${out.join('\n')}\n`;
}
// The bars' meters as the score counts them (METERS_FIELD): the first, each marked changed, and each whose grouping,
// reading or signature shown differs from the bar before's.
function metersOf(score){
  const meterOf=meter=>({numerator:meter.numerator,denominator:meter.denominator,...(meter.groups?{groups:meter.groups}:{}),...(meter.metricReading?{metricReading:meter.metricReading}:{}),...(meter.shown?{shown:meter.shown}:{})});
  const bars=[];let before=null;
  for(const measure of score.measures){
    const meter=meterOf(measure.meter),said=JSON.stringify(meter);
    if(measure.index===0||measure.meterChanged||measure.cycle||said!==before)bars.push({measure:measure.number,meter,changed:Boolean(measure.meterChanged),...(measure.cycle?{cycle:measure.cycle.map(bar=>meterOf(bar.meter))}:{})});
    before=said;
  }
  return {additiveSignatures:Boolean(score.additiveSignatures),bars};
}
// The time signature: its numerator (7/8), the grouping left to the beams -- or, where the score writes additive
// signatures (score.js, ADDITIVE_SIGNATURES), its groups (2+2+3/8) where they are not the meter's own (groups all
// equal, or the numerator's default grouping).
function timeElement(meter,additive){
  const groups=meter.groups??[meter.numerator],standard=groups.length<=1||groups.every(size=>size===groups[0])||groups.join()===defaultGrouping(meter.numerator).join();
  // (A signature shown simpler than its bar is counted, score.js writtenMeter's `shown`: that, its groups the beams'.)
  if(meter.shown)return `<time><beats>${meter.shown.numerator}</beats><beat-type>${meter.shown.denominator}</beat-type></time>`;
  const explicit=meter.metricReading&&meter.metricReading.kind!=='standard';
  const beats=explicit?groups.join('+'):standard||!additive?String(meter.numerator):groups.join('+');
  return `<time><beats>${beats}</beats><beat-type>${meter.denominator}</beat-type></time>`;
}
// An equivalence's two values as a metronome's content.
function equivalenceXml({from,to}){
  if(!from.tuplet&&!to.tuplet){
    const unit=value=>`<beat-unit>${BEAT_UNITS[value.type]}</beat-unit>${'<beat-unit-dot/>'.repeat(value.dots)}`;
    return unit(from)+unit(to);
  }
  const note=value=>`<metronome-note><metronome-type>${BEAT_UNITS[value.type]}</metronome-type>${'<metronome-dot/>'.repeat(value.dots)}`
    +(value.tuplet?`<metronome-tuplet type="start" bracket="yes" show-number="actual"><actual-notes>${value.tuplet.actual}</actual-notes><normal-notes>${value.tuplet.normal}</normal-notes></metronome-tuplet>`:'')
    +'</metronome-note>';
  return `${note(from)}<metronome-relation>equals</metronome-relation>${note(to)}`;
}
// (`on`, where the direction is set on a staff other than its own: a moving line's dynamic, under its lower staff.)
function writeDirection(line,direction,offset,voice,on=null){
  const offsetXml=offset?`<offset>${offset}</offset>`:'';
  if(direction.kind==='tempo'){
    // An irrational meter's beat (a twelfth, a tenth) has no note value of its own: its mark is in quarter notes.
    const quarters=direction.bpm*QUARTER/direction.beatUnit*(direction.dotted?DOTTED:1),regular=BEAT_UNITS[direction.beatUnit],unit=regular??'quarter',perMinute=regular?direction.bpm:quarters,dot=regular&&direction.dotted?'<beat-unit-dot/>':'';
    const staff=`<staff>${direction.staff??voice.staff}</staff>`,colour=direction.planned?` color="${PLANNED_COLOUR}"`:'',sound=`<sound tempo="${decimal(quarters)}"/>`;
    // A tempo the page does not show (a step of an accelerando) is a sound of its own, not a direction with nothing in
    // it: musicxml2ly turned hundreds of empty directions into LilyPond it could not read. (A ramp's word printed where
    // it begins carries no sound: its first step sounds a tick later, where it was heard.)
    const soundAlone=()=>line(ELEMENT,offset?`<sound tempo="${decimal(quarters)}">${offsetXml}</sound>`:sound);
    if(!direction.words&&!(direction.visible&&unit)){if(!direction.silent)soundAlone();return}
    // A metric modulation's equivalence (the old note = the new beat), before the mark of the new tempo: two beat units
    // where each is a note or a dotted one, else notes with their triplet (metronome-note, metronome-tuplet).
    if(direction.equivalence)line(ELEMENT,`<direction placement="above"><direction-type><metronome parentheses="no"${colour}>${equivalenceXml(direction.equivalence)}</metronome></direction-type>${offsetXml}${staff}</direction>`);
    // The mark, in whole numbers as metronome marks are printed (the sound keeps the exact tempo); then a ramp's word
    // and its dashed line (accel. - - -), a direction of their own -- a reader that makes the mark and the word one
    // tempo (Verovio) drops the line.
    if(direction.visible&&unit)line(ELEMENT,`<direction placement="above"><direction-type><metronome parentheses="no"${colour}><beat-unit>${unit}</beat-unit>${dot}<per-minute>${Math.round(perMinute)}</per-minute></metronome></direction-type>${offsetXml}${staff}${direction.silent?'':sound}</direction>`);
    else if(!direction.silent)soundAlone();
    if(direction.words){
      line(ELEMENT,'<direction placement="above">');
      line(CHILD,`<direction-type><words font-weight="bold" font-style="italic"${colour}>${direction.words}</words></direction-type>`);
      if(direction.until)line(CHILD,`<direction-type><dashes type="start" number="${TEMPO_DASHES}"${colour}/></direction-type>`);
      line(CHILD,`${offsetXml}${staff}`);
      line(ELEMENT,'</direction>');
    }
  }else if(direction.kind==='dashes'){
    line(ELEMENT,`<direction placement="above"><direction-type><dashes type="stop" number="${TEMPO_DASHES}"/></direction-type>${offsetXml}<staff>${direction.staff??voice.staff}</staff></direction>`);
  }else if(direction.kind==='dynamics'){
    // (MusicXML names marks to six letters: the uncomfortable range's past them, its other dynamics.)
    const mark=String(direction.value).length>6?`<other-dynamics>${direction.value}</other-dynamics>`:`<${direction.value}/>`;
    line(ELEMENT,`<direction placement="below"><direction-type><dynamics>${mark}</dynamics></direction-type>${offsetXml}<staff>${on??direction.staff??voice.staff}</staff></direction>`);
  }else if(direction.kind==='words'){
    line(ELEMENT,`<direction placement="${direction.placement??'above'}"><direction-type><words font-size="${direction.size??WORDS_SIZE}"${direction.style?` font-style="${direction.style}"`:''}${direction.align?` halign="${direction.align}"`:''}>${escape(direction.value)}</words></direction-type>${offsetXml}<staff>${direction.staff??voice.staff}</staff></direction>`);
  }else if(direction.kind==='cadenza'||direction.kind==='divisi'||direction.kind==='formation'){
    // Over a part that played in a hold's free time: its notes are the player's (notation/score.js). And over a section
    // written divisi, how many ways ("div. a 8": score.js layDivisi).
    line(ELEMENT,`<direction placement="above"><direction-type><words font-style="italic">${escape(direction.value)}</words></direction-type>${offsetXml}<staff>${direction.staff??voice.staff}</staff></direction>`);
  }else if(direction.kind==='feel'){
    // The feel a section is played in (Swing, Straight: performance-timing.js feelDirection), and for playback its swing
    // (MusicXML 4.0's <swing>: the long note to the short, or straight).
    const swing=direction.swing,sound=!swing?'':swing.straight?'<sound><swing><straight/></swing></sound>'
      :`<sound><swing><first>${swing.first}</first><second>${swing.second}</second><swing-type>${swing.type==='sixteenth'?'16th':'eighth'}</swing-type></swing></sound>`;
    line(ELEMENT,`<direction placement="above"><direction-type><words font-weight="bold">${escape(direction.words)}</words></direction-type>${offsetXml}<staff>${direction.staff??voice.staff}</staff>${sound}</direction>`);
  }else if(direction.kind==='rehearsal'){
    line(ELEMENT,`<direction placement="above"><direction-type><rehearsal enclosure="square" font-weight="bold">${escape(direction.value)}</rehearsal></direction-type>${offsetXml}<staff>${direction.staff??voice.staff}</staff></direction>`);
  }else if(direction.kind==='harmony'){
    // A planned chord (the bars ahead) is coloured, so a player tells what is coming from what was played.
    const chord=direction.chord,alter=value=>value?`<root-alter>${value}</root-alter>`:'',bassAlter=value=>value?`<bass-alter>${value}</bass-alter>`:'';
    // A pool that is no chord is written as its notes, in words: a symbol's root would claim a harmony it does not have.
    if(chord.kind==='other'){line(ELEMENT,`<direction placement="above"><direction-type><words font-size="8"${direction.planned?` color="${PLANNED_COLOUR}"`:''}>${escape(chordText(chord))}</words></direction-type>${offsetXml}<staff>${direction.staff??voice.staff}</staff></direction>`);return}
    // (Its kind's text as the symbol reads, a microtonal chord's "~" after it: chords.js chordText.)
    const kind=`<kind text="${escape(chord.text)}${chord.microtonal?'~':''}">${chord.kind}</kind>`;
    // Each tension the kind does not imply, as a degree (hidden: the kind's text already shows it).
    const implied=IMPLIED_TENSIONS[chord.kind]??[];
    const degrees=(chord.degrees??[]).filter(degree=>degree.alter||!implied.includes(degree.value))
      .map(degree=>`<degree print-object="no"><degree-value>${degree.value}</degree-value><degree-alter>${degree.alter}</degree-alter><degree-type>add</degree-type></degree>`).join('');
    line(ELEMENT,`<harmony placement="above"${direction.planned?` color="${PLANNED_COLOUR}"`:''}><root><root-step>${chord.root.step}</root-step>${alter(chord.root.alter)}</root>${kind}${chord.bass?`<bass><bass-step>${chord.bass.step}</bass-step>${bassAlter(chord.bass.alter)}</bass>`:''}${degrees}${offsetXml}<staff>${direction.staff??voice.staff}</staff></harmony>`);
    // How the chord is tuned, small beside its symbol, where the tuning changes (after the whole symbol, bass and all).
    if(direction.tuning&&direction.tuningShown)line(ELEMENT,`<direction placement="above"><direction-type><words font-size="6.5">${escape(direction.tuning)}</words></direction-type>${offsetXml}<staff>${direction.staff??voice.staff}</staff></direction>`);
  }
}
// (An element's staff is its own where a line moves between a grand staff's staves -- its beams crossing them -- else its
// voice's.)
function writeElement(line,element,voice,part,divisions,placement='above'){
  const duration=inDivisions(element.end.sub(element.start),divisions),staff=element.staff??voice.staff;
  if(element.rest){
    // A hidden rest is time not yet known (the live score's future): it keeps the measure's count and draws nothing.
    const note=element.hidden?'<note print-object="no">':'<note>';
    // (A whole bar's rest held, its fermata over it.)
    if(element.measureRest){line(ELEMENT,`${note}<rest measure="yes"/><duration>${duration}</duration><voice>${voice.voice}</voice>${part.staves>1?`<staff>${staff}</staff>`:''}${element.fermata?'<notations><fermata type="upright"/></notations>':''}</note>`);return}
    line(ELEMENT,note);line(CHILD,'<rest/>');line(CHILD,`<duration>${duration}</duration>`);line(CHILD,`<voice>${voice.voice}</voice>`);
    writeValue(line,element);if(part.staves>1)line(CHILD,`<staff>${staff}</staff>`);
    // A rest between two notes of a group stays under their beam.
    for(const beam of element.beams??[])line(CHILD,`<beam number="${beam.number}">${beam.value}</beam>`);
    writeNotations(line,element,true,null,null,placement);line(ELEMENT,'</note>');return;
  }
  // A free onset's timing, which the page cannot show otherwise, above the chord. (Cents belong to each note: below.)
  const marks=[...new Set(element.notes.map(note=>note.timingText).filter(Boolean))];
  const own=`<voice>${voice.voice}</voice>`;
  if(marks.length)line(ELEMENT,`<direction placement="above"><direction-type><words font-size="7">${escape(marks.join(' '))}</words></direction-type>${own}<staff>${staff}</staff></direction>`);
  // Where the staff's playing changes (score.js techniqueText): pizz., arco -- under the staff where a desk's lower voice
  // takes its own (techniqueBelow). A technique held over several notes (techniqueSpan): its words and a dashed line in
  // its voice, stopping at its last note (techniqueSpanStop).
  const side=element.techniqueBelow?'below':'above',techniqueDashes=TECHNIQUE_DASHES+voice.voice;
  // (The section's lines dividing or joining again, score.js DIVISI_WORDS, as the engraving writes them: italic.)
  if(element.divisiText)line(ELEMENT,`<direction placement="above"><direction-type><words font-style="italic">${escape(element.divisiText)}</words></direction-type>${own}<staff>${staff}</staff></direction>`);
  if(element.techniqueText)line(ELEMENT,`<direction placement="${side}"><direction-type><words font-style="italic">${escape(element.techniqueText)}</words></direction-type>${own}<staff>${staff}</staff></direction>`);
  if(element.techniqueSpanStop&&!element.techniqueSpan)line(ELEMENT,`<direction placement="${side}"><direction-type><dashes type="stop" number="${techniqueDashes}"/></direction-type>${own}<staff>${staff}</staff></direction>`);
  if(element.techniqueSpan)line(ELEMENT,`<direction placement="${side}"><direction-type><words font-style="italic">${escape(element.techniqueSpan)}</words></direction-type><direction-type><dashes type="start" number="${techniqueDashes}"/></direction-type>${own}<staff>${staff}</staff></direction>`);
  const notes=[...element.notes].sort((a,b)=>b.pitch-a.pitch);
  writePedals(line,notes.flatMap(note=>note.pedal??[]),part);
  // A glide from a pitch no note was written at (a bass sliding up into a root from under it): a grace note there,
  // slid from into the note (the first note that glides so, where a chord's do).
  const glided=notes.find(note=>note.graceFrom);
  for(const grace of notes.flatMap(note=>note.gracesBefore??[]).sort((a,b)=>a.order-b.order))writeGrace(line,grace,voice,part,staff,{slide:false});
  if(glided&&!element.slash)writeGrace(line,glided.graceFrom,voice,part,staff);
  notes.forEach((note,index)=>{
    const attack=note.attackWhole?` attack="${decimal(note.attackWhole*QUARTERS_PER_WHOLE*divisions)}"`:'',release=note.releaseWhole!=null&&Math.abs(note.releaseWhole)>SAME_LENGTH?` release="${decimal(note.releaseWhole*QUARTERS_PER_WHOLE*divisions)}"`:'';
    // A note inflected by cents carries them as its own fingering, and an id an engraver's placement can find, where its
    // inflection is shown (score.js: the first time in the bar at its place, as an accidental).
    // (And a note whose tie the slice's edge cuts, an id its tie's half is drawn from: score.js sliceScore, ties-across.js.)
    const cents=!element.tieStop&&note.spelled&&note.accidentalShown?centsLabel(note.spelled.cents):null,marked=element.tieOut?'tie-out':element.tieIn?'tie-in':cents?'cents':null;
    const id=marked?` id="${marked}-${++centsCount}"`:'';
    line(ELEMENT,`<note${id}${attack}${release}${element.slash?'':` dynamics="${decimal(Math.max(0,note.velocity)*MIDI_MAX/FORTE_VELOCITY*PER_CENT)}"`}>`);
    if(index>0)line(CHILD,'<chord/>');
    if(note.unpitched)line(CHILD,`<unpitched><display-step>${note.unpitched.step}</display-step><display-octave>${note.unpitched.octave}</display-octave></unpitched>`);
    else{const s=note.spelled;line(CHILD,`<pitch><step>${s.step}</step>${s.alter?`<alter>${alterText(s.alter)}</alter>`:''}<octave>${s.octave}</octave></pitch>`)}
    line(CHILD,`<duration>${duration}</duration>`);
    if(element.tieStop)line(CHILD,'<tie type="stop"/>');if(element.tieStart)line(CHILD,'<tie type="start"/>');
    if(note.instrument!=null)line(CHILD,`<instrument id="${part.id}-I${note.instrument}"/>`);
    line(CHILD,`<voice>${voice.voice}</voice>`);
    writeValue(line,element,note);
    // (A line moving between a grand staff's staves states its stems: an engraver takes a note written on the other
    // staff for one crossing to it, its stem towards the staff it came from.)
    if(element.slash)line(CHILD,'<stem>none</stem>');else if(element.stem)line(CHILD,`<stem>${element.stem}</stem>`);
    // (What a string multiphonic sounds, its lowest, in parentheses beside where it is touched: writeTouch.)
    if(element.slash)line(CHILD,'<notehead>slash</notehead>');else if(touchOf(element,note))line(CHILD,`<notehead parentheses="yes">${note.notehead??'normal'}</notehead>`);
    else if(note.notehead)line(CHILD,`<notehead>${note.notehead}</notehead>`);
    if(part.staves>1)line(CHILD,`<staff>${staff}</staff>`);
    if(index===0)for(const beam of element.beams)line(CHILD,`<beam number="${beam.number}">${beam.value}</beam>`);
    writeNotations(line,element,index===0,note,cents,placement,cents?centsPlacement(note,part,staff):null,voice.voice);
    if(note.lyric)writeLyric(line,note.lyric);
    line(ELEMENT,'</note>');
    if(touchOf(element,note))writeTouch(line,element,note,voice,part,staff,divisions,duration);
  });
  // A glissando through the chord with a rest after: the grace note it ends on, after it.
  const ended=notes.find(note=>note.graceTo);
  if(ended&&!element.slash)writeGrace(line,ended.graceTo,voice,part,staff,{after:true});
  for(const grace of notes.flatMap(note=>note.gracesAfter??[]).sort((a,b)=>a.order-b.order))writeGrace(line,grace,voice,part,staff,{after:true,slide:false});
  // A pedal let up after the last note it holds: at the end of the chord.
  writePedals(line,notes.flatMap(note=>note.pedalAfter??[]),part);
}
// A string multiphonic's touched note (score.js touchSpelled), where it begins (not where it is tied into): a note of its
// chord, its head a diamond, MusicXML's harmonic's touching pitch, with its accidental and its cents where shown.
const touchOf=(element,note)=>!element.tieStop&&!element.slash?note.multiphonic?.touchSpelled??null:null;
function writeTouch(line,element,note,voice,part,staff,divisions,duration){
  const touch=touchOf(element,note),s=touch.spelled,shown=touch.accidentalShown!==false,cents=shown?centsLabel(s.cents):null;
  line(ELEMENT,`<note${cents?` id="cents-${++centsCount}"`:''}>`);line(CHILD,'<chord/>');
  line(CHILD,`<pitch><step>${s.step}</step>${s.alter?`<alter>${alterText(s.alter)}</alter>`:''}<octave>${s.octave}</octave></pitch>`);
  line(CHILD,`<duration>${duration}</duration>`);line(CHILD,`<voice>${voice.voice}</voice>`);
  line(CHILD,`<type>${element.type}</type>`);for(let i=0;i<element.dots;i++)line(CHILD,'<dot/>');
  if(shown&&s.accidental)line(CHILD,`<accidental>${s.accidental}</accidental>`);
  writeValue(line,element,null,{typed:false});
  line(CHILD,'<notehead>diamond</notehead>');if(part.staves>1)line(CHILD,`<staff>${staff}</staff>`);
  line(CHILD,`<notations><technical><harmonic><touching-pitch/></harmonic>${cents?`<fingering placement="${centsPlacement(touch,part,staff)}">${cents}</fingering>`:''}</technical></notations>`);
  line(ELEMENT,'</note>');
}
// A performer's pedalling (shared/performers/realization.js markedNotes), below the lowest staff, where a pianist reads it
// wherever the note it starts on is written: the sustain
// as Ped. and its release (a change where it comes up and goes down again at one note), the sostenuto as Sost. Ped.,
// the sustain half down in words (MusicXML has no sign for it), and the soft pedal as una corda and tre corde.
const PEDAL_MARKS=Object.freeze({
  sustain:Object.freeze({start:'<pedal type="start" sign="yes"/>',stop:'<pedal type="stop" sign="yes"/>',change:'<pedal type="change" sign="yes"/>'}),
  sostenuto:Object.freeze({start:'<pedal type="sostenuto" sign="yes"/>',stop:'<pedal type="stop" sign="yes"/>',change:'<pedal type="change" sign="yes"/>'}),
  'half-sustain':Object.freeze({start:'<words font-style="italic">½ Ped.</words>',stop:'<pedal type="stop" sign="yes"/>',change:'<words font-style="italic">½ Ped.</words>'}),
  soft:Object.freeze({start:'<words font-style="italic">una corda</words>',stop:'<words font-style="italic">tre corde</words>',change:'<words font-style="italic">una corda</words>'}),
});
function writePedals(line,marks,part){
  const seen=new Set;
  for(const mark of marks){
    const key=`${mark.pedal}:${mark.type}`;if(seen.has(key))continue;seen.add(key);
    const sign=PEDAL_MARKS[mark.pedal]?.[mark.type];
    if(sign)line(ELEMENT,`<direction placement="below"><direction-type>${sign}</direction-type>${part.staves>1?`<staff>${part.staves}</staff>`:''}</direction>`);
  }
}
// A sung syllable under its note (lyrics.js): its text and place in its word, and the extender a held syllable draws; a
// note a word-final syllable is held over carries the extender alone.
function writeLyric(line,lyric){
  const extend=lyric.extend?`<extend type="${lyric.extend}"/>`:'',lang=lyric.language?` xml:lang="${escape(lyric.language)}"`:'';
  if(lyric.text)line(CHILD,`<lyric number="1" placement="below"><syllabic>${lyric.syllabic}</syllabic><text${lang}>${escape(lyric.text)}</text>${extend}</lyric>`);
  else if(extend)line(CHILD,`<lyric number="1" placement="below">${extend}</lyric>`);
}
// A grace note a glide starts on: its pitch (and cents, as any note's), unmeasured, before the note it slides into.
// `after`: the grace note a glissando ends on, after its note (time taken from it), the line arriving rather than leaving.
function writeGrace(line,grace,voice,part,staff,{after=false,slide=true}={}){
  const s=grace.spelled,cents=grace.accidentalShown?centsLabel(s.cents):null;
  line(ELEMENT,`<note${cents?` id="cents-${++centsCount}"`:''}>`);line(CHILD,`<grace slash="${(grace.slash??!after)?'yes':'no'}"/>`);
  if(grace.unpitched)line(CHILD,`<unpitched><display-step>${grace.unpitched.step}</display-step><display-octave>${grace.unpitched.octave}</display-octave></unpitched>`);
  else line(CHILD,`<pitch><step>${s.step}</step>${s.alter?`<alter>${alterText(s.alter)}</alter>`:''}<octave>${s.octave}</octave></pitch>`);
  if(grace.instrument!=null)line(CHILD,`<instrument id="${part.id}-I${grace.instrument}"/>`);
  line(CHILD,`<voice>${voice.voice}</voice>`);line(CHILD,`<type>${grace.type??GRACE_TYPE}</type>`);
  for(let k=0;k<(grace.dots??0);k++)line(CHILD,'<dot/>');
  if(grace.accidentalShown&&s?.accidental)line(CHILD,`<accidental>${s.accidental}</accidental>`);
  if(grace.notehead)line(CHILD,`<notehead>${grace.notehead}</notehead>`);
  if(part.staves>1)line(CHILD,`<staff>${staff}</staff>`);
  const fingering=cents?`<technical><fingering placement="${centsPlacement(grace,part,staff)}">${cents}</fingering></technical>`:'';
  const joining=slide?(after?`<glissando type="stop" number="${voice.voice}" line-type="solid"/>`:`<slide type="start" number="${voice.voice}"/>`):'';
  if(joining||fingering)line(CHILD,`<notations>${joining}${fingering}</notations>`);
  line(ELEMENT,'</note>');
}
let centsCount=0;
// (`typed`: its type and dots written here; a touched note writes them before its own accidental.)
function writeValue(line,element,note=null,{typed=true}={}){
  if(typed){line(CHILD,`<type>${element.type}</type>`);for(let i=0;i<element.dots;i++)line(CHILD,'<dot/>')}
  if(note?.spelled&&note.accidentalShown&&note.spelled.accidental)line(CHILD,`<accidental>${note.spelled.accidental}</accidental>`);
  if(element.tuplets.length){
    const actual=element.tuplets.reduce((product,tuplet)=>product*tuplet.n,1),normal=element.tuplets.reduce((product,tuplet)=>product*tuplet.m,1),g=gcdOf(actual,normal);
    line(CHILD,`<time-modification><actual-notes>${actual/g}</actual-notes><normal-notes>${normal/g}</normal-notes><normal-type>${typeOfLength(element.tuplets.at(-1).unit)}</normal-type></time-modification>`);
  }
}
const gcdOf=(a,b)=>{while(b){[a,b]=[b,a%b]}return a};
// Where a note's cents stand: a sung line's above it (its words are below); on a grand staff, outside the pair -- over
// the upper staff and under the lower, as a pianist's fingerings stand -- never in the room between the staves, where a
// chord's cents would stack into a column that holds the staves apart (the video's line spaces every bar's staves as
// far apart as any bar's ink needs); on any other staff, by the note's place against its clef's middle line.
function centsPlacement(note,part,staff){
  if(part.sung)return 'above';
  if(part.staves>1&&!part.divisi)return staff===1?'above':'below';
  const clef=part.clefs?.[staff-1],middle=(STAFF_MIDDLE[clef?.sign]??STAFF_MIDDLE.G)+SEMITONES_PER_OCTAVE*(clef?.octave??0);
  return note.pitch>=middle?'above':'below';
}
function writeNotations(line,element,first,note=null,cents=null,placement='above',centsPlaced='above',slide=1){
  const parts=[];
  if(element.tieStop)parts.push('<tied type="stop"/>');if(element.tieStart)parts.push('<tied type="start"/>');
  if(first){
    // Bracket numbers count the drawn tuplets only (an irrational meter's implicit one is not drawn).
    const numberOf=level=>element.tuplets.slice(0,level+1).filter(tuplet=>!tuplet.implicit).length;
    for(const level of element.tupletStarts??[]){
      // (In an irrational meter's bar, its ratio alone: lilypond.js ratioOnly.)
      const tuplet=element.tuplets[level],type=typeOfLength(tuplet.unit),shown=element.tuplets.some(t=>t.implicit)?'none':'both';
      parts.push(`<tuplet type="start" number="${numberOf(level)}" bracket="yes" show-number="both" show-type="${shown}" placement="${placement}"><tuplet-actual><tuplet-number>${tuplet.n}</tuplet-number><tuplet-type>${type}</tuplet-type></tuplet-actual><tuplet-normal><tuplet-number>${tuplet.m}</tuplet-number><tuplet-type>${type}</tuplet-type></tuplet-normal></tuplet>`);
    }
    for(const level of [...(element.tupletStops??[])].reverse())parts.push(`<tuplet type="stop" number="${numberOf(level)}"/>`);
  }
  // Articulations: a note's staccato and the breath a singer takes after it; the element's accent, marcato, staccatissimo,
  // tenuto (on its first note).
  const articulations=[first&&element.accent?'<accent/>':'',first&&element.marcato?'<strong-accent type="up"/>':'',note?.staccato?'<staccato/>':'',
    first&&element.staccatissimo?'<staccatissimo/>':'',first&&element.tenuto?'<tenuto/>':'',note?.breathMark?'<breath-mark/>':''].join('');
  if(articulations)parts.push(`<articulations>${articulations}</articulations>`);
  // (A percussion roll, score.js: a tremolo of three strokes.)
  if(note?.rolled)parts.push('<ornaments><tremolo type="single">3</tremolo></ornaments>');
  if(first&&element.slurStart)parts.push('<slur type="start" number="1" placement="above"/>');
  if(first&&element.slurStop)parts.push('<slur type="stop" number="1"/>');
  if(first&&element.fermata)parts.push('<fermata type="upright"/>');
  // A glide: the slide into the note ends on it (from the note before, or its grace note); one out of it begins there. A
  // glissando's (score.js: a harp's sweep, its strings discerned) is MusicXML's glissando, drawn straight.
  const joining=note?.glissando?'glissando':'slide',style=note?.glissando?' line-type="solid"':'';
  if(note?.slideStop||note?.graceFrom)parts.push(`<${joining} type="stop" number="${slide}"${style}/>`);
  if(note?.slideStart||note?.graceTo)parts.push(`<${joining} type="start" number="${slide}"${style}/>`);
  // A performer's fingering (shared/performers/realization.js): the digit that strikes the note, then any it changes to
  // silently (substitution), above the right hand's notes and below the left's; in italics where a plan inferred it, as
  // an editor's addition is printed, so it is not read as the player's own.
  const finger=note?.fingering,fingerStyle=finger?.inferred?' font-style="italic"':'',fingerPlace=finger?.hand==='LH'?'below':'above';
  const fingering=finger?[`<fingering placement="${fingerPlace}"${fingerStyle}>${escape(String(finger.digit))}</fingering>`,
    ...(finger.substitutions??[]).map(digit=>`<fingering substitution="yes" placement="${fingerPlace}"${fingerStyle}>${escape(String(digit))}</fingering>`)].join(''):'';
  // (A natural harmonic, its sounding pitch written: MusicXML's own harmonic mark. A multiphonic: a string's string (I
  // the highest), where it is touched a note of its own (writeTouch); a wind's keys as words naming its instrument, as
  // LilyPond's woodwind diagrams name them -- MusicXML has no woodwind diagram.)
  const multi=note?.multiphonic,keyWords=diagram=>`${diagram.instrument} keys ${['cc','lh','rh'].map(group=>(diagram.keys?.[group]??[]).map(key=>`${group}:${key}`).join(' ')).filter(Boolean).join(' ')}`;
  const multiphonic=multi?[Number.isInteger(multi.string)?`<string>${4-multi.string}</string>`:'',
    `<other-technical>${escape(multi.diagram?`multiphonic, ${keyWords(multi.diagram)}`:'multiphonic')}</other-technical>`].join(''):'';
  // (Or a woodwind's pitch between its keys' notes, the fingering its player shades to it: its keys in words, as a
  // multiphonic's -- score.js, woodwind-fingering.js.)
  const fingered=!multi&&note?.fingered?`<other-technical>${escape(`fingering, ${keyWords(note.fingered)}`)}</other-technical>`:'';
  const technical=[note?.open?'<open-string/>':'',note?.harmonic?'<harmonic><natural/><sounding-pitch/></harmonic>':'',multiphonic,fingered,fingering,cents?`<fingering placement="${centsPlaced}">${cents}</fingering>`:''].join('');
  if(technical)parts.push(`<technical>${technical}</technical>`);
  if(element.arpeggiate)parts.push('<arpeggiate/>');
  if(parts.length)line(CHILD,`<notations>${parts.join('')}</notations>`);
}
