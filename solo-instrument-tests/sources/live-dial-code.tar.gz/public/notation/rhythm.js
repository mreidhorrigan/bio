// Rhythm spelling without quantizing: exact rational onsets and ends in a measure, written as note values, dots, ties
// and tuplets -- nested as deep as the rhythm needs.
//
// A measure is a tree: the bar divides into the meter's groups, a group into its beats, a beat in two, and so on. Where
// an onset or an end falls off that tree, a span is divided instead into n equal parts, a tuplet; each part may divide
// again, into halves or into another tuplet. The division of every span is chosen by search: every point must land on
// a boundary (the rhythm is kept exactly), and among the trees that do that the one with the least notational cost wins
// -- tuplets cost more the stranger their number, nesting costs, and every separate note value costs a little. So a
// quintuplet with one note split in three is written as a 3:2 inside a 5:4, while a beat divided in fifteen evenly is a
// flat 15:8; the ornament bot's hundredths of a bar come out as 25:16 where they are dense and as nested fives where
// they are sparse. A tuplet's ratio is the standard one: n notes of the next lower power-of-two value (5:4, 7:4, 13:8,
// 25:16), and in a compound or dotted span the duplet and quadruplet (2:3, 4:3).
//
// Times are Rationals in whole notes from the start of the measure. spellMeasure returns the notated elements in order:
// each with its actual span, its written value (type and dots), the path of tuplets it sits in (outermost first), ties,
// and its beams.
import {Rational,splitTwos,primeFactors,gcd} from '../transcript/rational.js';
import {NOTE_TYPES} from '../shared/note-values.js';
export {NOTE_TYPES};
const TYPE_OF=new Map(NOTE_TYPES.map(([name,value])=>[String(value),name]));
// The values longer than a half, in whole notes: a whole, a breve, a long, a maxima.
const LONG_VALUES=Object.freeze([1,2,4,8]);
// A value's beams: an eighth one, a sixteenth two, and so on.
const BEAM_LEVELS=Object.freeze({eighth:1,'16th':2,'32nd':3,'64th':4,'128th':5,'256th':6,'512th':7,'1024th':8});
// What a tuplet costs to read: a base, and for each prime of its odd part -- threes and sixes everyday, fives and
// sevens less so, a prime past seven rare (1 and a twentieth of the prime) -- with more for a tuplet of several primes
// (each of them costing this more). A bracket inside another, each element under one, each level of nesting and a
// split of a group cost these (the search's weights).
const TUPLET_BASE_COST=.7,PRIME_COST=Object.freeze({3:.35,5:.75,7:1}),RARE_PRIME_SCALE=20,COMPOUND_FACTOR_COST=.2;
const NEST_COST=.55,ELEMENT_COST=.3,LEVEL_COST=.04,SPLIT_COST=.5;
// Definitions: the shortest value written (a 1024th), halves, the conductor's groups of three and two, a meter's
// numerator and denominator when it gives none (4/4), compound meters in eighths or shorter, and a beam joining two
// notes or more.
const SHORTEST_VALUE=1024,HALVES=2,GROUP_OF_THREE=3,GROUP_OF_TWO=2,DEFAULT_NUMERATOR=4,DEFAULT_DENOMINATOR=4,COMPOUND_FROM=8,BEAMED_NOTES=2;
// Choices: a value takes up to three dots, and a merged value up to two; a tuplet's ratio is standard where n < 2m;
// the tuplets tried: those the points' own denominators ask for, of any size, whose units are no shorter than 2^-12 of
// a whole note (the shortest value written), nested up to 12 deep. No largest tuplet: 17:16, 107:64, whatever the
// rhythm is (the owner, 2 October 2026: "make sure EVERY tuplet ratio is allowed ... NO HARDCODING OF TUPLETS"; "The only
// way that notation should be able to cap tuplets is by renotating tuplets to divide them over a barline").
const MAX_DOTS=3,MAX_MERGED_DOTS=2,STANDARD_RATIO=2,SHORTEST_TUPLET_UNIT=12,DEEPEST_NESTING=12;
// (The most parts a span may have: as many as its shortest unit fits in a whole, 2^12.)
const MOST_PARTS=2**SHORTEST_TUPLET_UNIT;
const R=(n,d=1)=>new Rational(n,d);
// A bar longer than this many whole notes (mh_PlexBOT's 16/4, season 2's 31/4) may not fit a line, so a score may break
// it between its beat groups (lilypond.js); no written value crosses one of those places (spellMeasure), so a line
// broken there breaks between notes, each tie across one break at most. (A value across two left its tie's middle
// piece with no heads: LilyPond's "Tie without heads", season 2's p031, 29 September.)
export const LONG_BAR_WHOLES=2;
// Where a bar of `length` (whole notes) in `meter` may break: between its groups (its own, else the default grouping of
// its numerator), for a bar longer than LONG_BAR_WHOLES; none for a shorter one.
export function breakPoints(meter,length){
  const measureLength=Rational.of(length);
  if(!(measureLength.toNumber()>LONG_BAR_WHOLES))return [];
  const beat=R(1,meter?.denominator||DEFAULT_DENOMINATOR),groups=meter?.metricReading?.beatWeights??(meter?.groups?.length?meter.groups:defaultGrouping(meter?.numerator||DEFAULT_NUMERATOR));
  const out=[];let at=R(0);
  for(const size of groups.slice(0,-1)){at=at.add(beat.mul(size));if(at.lt(measureLength))out.push(at)}
  return out;
}
const crossing=(breaks,start,end)=>breaks.some(point=>point.gt(start)&&point.lt(end));
const typeName=value=>TYPE_OF.get(String(value.toNumber()))??null;

// A written value: {type, dots} whose length is `length` (whole notes), or null. Up to three dots.
export function noteValue(length){
  const len=Rational.of(length);if(len.sign()<=0)return null;
  for(let dots=0;dots<=MAX_DOTS;dots++){
    // type * (2 - 2^-dots) = length
    const factor=R(2**(dots+1)-1,2**dots),base=len.div(factor),{twos,odd}=splitTwos(base.d);
    if(odd===1&&base.n===1&&twos>=1&&twos<=SHORTEST_VALUE){const type=typeName(base);if(type)return {type,dots,base}}
    if(base.d===1&&LONG_VALUES.includes(base.n)){const type=typeName(base);if(type)return {type,dots,base}}
  }
  return null;
}
// The conductor's grouping of a meter that has none of its own (public/meter.js): threes, then twos -- 5 is 3+2, 7 is
// 3+2+2, 11 is 3+3+3+2.
export function defaultGrouping(n){if(n===1)return [1];const groups=[],threes=Math.floor(n/GROUP_OF_THREE),remainder=n%GROUP_OF_THREE;if(remainder===1){for(let i=0;i<threes-1;i++)groups.push(GROUP_OF_THREE);groups.push(GROUP_OF_TWO,GROUP_OF_TWO)}else{for(let i=0;i<threes;i++)groups.push(GROUP_OF_THREE);if(remainder===GROUP_OF_TWO)groups.push(GROUP_OF_TWO)}return groups}
export const beamLevels=type=>BEAM_LEVELS[type]??0;

// The tuplet for dividing a span of written length `length` into n: {n, m, unit} with m * unit = length, unit a power
// of two; m <= n < 2m where one exists (the standard ratio), else the smallest m above n (duplets in a dotted span).
// n === m is no tuplet at all.
export function tupletFor(length,n){
  const len=Rational.of(length),options=[];
  for(let k=0;k<=SHORTEST_TUPLET_UNIT;k++){
    const unit=R(1,2**k),m=len.div(unit);
    if(m.isInteger()&&m.n>=1)options.push({n,m:m.n,unit});
  }
  const standard=options.filter(option=>option.m<=n&&n<STANDARD_RATIO*option.m);
  if(standard.length)return standard.sort((a,b)=>b.m-a.m)[0];
  const above=options.filter(option=>option.m>n).sort((a,b)=>a.m-b.m);
  return above[0]??null;
}

// Cost of a tuplet of n: threes and sixes are everyday, fives and sevens less so, primes past seven rare.
export function tupletCost(n){
  const {odd}=splitTwos(n),factors=primeFactors(odd);
  return TUPLET_BASE_COST+factors.reduce((sum,prime)=>sum+(PRIME_COST[prime]??1+prime/RARE_PRIME_SCALE),0)+(factors.length>1?COMPOUND_FACTOR_COST*factors.length:0);
}

// The measure's skeleton: the bar in its groups (the meter's additive groups), a group in its beats.
//
// An irrational meter (a denominator that is not a power of two: PlexBOT's 11/10, 17/10) is written as its beats of
// the next lower power-of-two value under an implicit tuplet: a tenth is an eighth of a 5:4, a twelfth an eighth of a
// 3:2. Every value in the bar carries that ratio (in MusicXML's time-modification) without a bracket of its own, as
// such bars are written: the time signature says it.
export function implicitTuplet(meter){
  const d=meter?.denominator||DEFAULT_DENOMINATOR,unit=2**Math.floor(Math.log2(d));
  if(unit===d)return null;
  const g=gcd(d,unit);return {id:'meter',n:d/g,m:unit/g,unit:R(1,unit),implicit:true};
}
function measureNode(meter,length){
  const implicit=implicitTuplet(meter),beat=R(1,meter.denominator||DEFAULT_DENOMINATOR),writtenBeat=implicit?implicit.unit:beat,ratio=beat.div(writtenBeat);
  const groups=meter.metricReading?.beatWeights??(meter.groups?.length?meter.groups:[meter.numerator||DEFAULT_NUMERATOR]);
  let start=R(0),children=[];
  // The metric tree supplies the surrounding grid, even when the declared bar ends inside one of its cells. Making
  // a fractional ending the tree's unit (for example 21/22) left no dyadic value from which to build its tuplets.
  // Cover the bar with complete metric groups; its exact ending is a required split point, and cover() emits only
  // the authored interval. The extra tree extent creates neither written time nor rests.
  while(start.lt(length))for(const size of groups){
    const groupLength=beat.mul(size),group={start,actual:groupLength,written:writtenBeat.mul(size),ratio,kind:'group',beats:size,beat,
      ...(meter.pulse>1&&size%meter.pulse===0?{pulses:size/meter.pulse}:{})};
    if(groupLength.sign()<=0)throw new RangeError('Metric groups must have positive duration');
    children.push(group);start=start.add(groupLength);
  }
  return {start:R(0),actual:start,written:start.div(ratio),ratio,kind:'measure',fixed:children,implicit};
}
const inside=(node,points)=>points.filter(point=>point.gt(node.start)&&point.lt(node.start.add(node.actual)));

// The ways to divide a node: its fixed children (the bar into groups), its beats, halves, and tuplets drawn from the
// points' denominators. A division is offered only if it brings some point nearer a boundary: halves when a point's
// place in the span has an even denominator, n parts when it shares a factor with n.
function candidates(node,points){
  const out=[],denominators=[...new Set(points.map(point=>point.sub(node.start).div(node.actual).d))];
  const helps=n=>denominators.some(q=>gcd(q,n)>1);
  if(node.fixed){
    // (Its groups; and, where a tuplet would cross a group's boundary, its groups run together across every boundary
    // no point falls on, so a tuplet spans them whole: split only at the barline.)
    const out=[{kind:'fixed'}],runs=[];
    for(const group of node.fixed){const last=runs.at(-1);if(last&&!points.some(point=>point.eq(group.start)))last.push(group);else runs.push([group])}
    const tupled=run=>{if(run.length<2)return false;const start=run[0].start,length=run.reduce((sum,group)=>sum.add(group.actual),R(0));
      return points.some(point=>point.gt(start)&&point.lt(start.add(length))&&splitTwos(point.sub(start).div(length).d).odd>1)};
    if(runs.length<node.fixed.length&&runs.some(tupled))out.push({kind:'runs',runs});
    return out;
  }
  if(node.kind==='group'&&Number.isInteger(node.beats)&&node.beats>1)out.push({kind:'equal',n:node.beats,tuplet:null});
  else if(helps(HALVES)){const halves=tupletFor(node.written,HALVES);if(halves&&halves.m===HALVES)out.push({kind:'equal',n:HALVES,tuplet:null})}
  const ns=new Set;
  for(const q of denominators){
    if(q<=MOST_PARTS)ns.add(q);
    for(const prime of primeFactors(q))for(let k=1;prime*k<=Math.min(q,MOST_PARTS);k*=2)ns.add(prime*k);
  }
  let all=1;for(const q of denominators){all=all/gcd(all,q)*q;if(all>MOST_PARTS)break}
  if(all<=MOST_PARTS)ns.add(all);
  for(const n of ns){
    if(n<HALVES||!helps(n))continue;
    // (A group of dotted pulses divides by its pulses, never across them: 12/8's six eighths in two or six, not three
    // quarters.)
    if(node.pulses&&n%node.pulses!==0)continue;
    // (Parts that are values of their own -- a group of nine sixteenths in three dotted eighths, a dotted pulse's
    // thirds -- need no bracket: 33/16's pulses, never 3:9.)
    const plain=noteValue(node.written.div(R(n)));
    if(plain&&plain.dots<=1){if(!out.some(option=>option.kind==='equal'&&option.n===n))out.push({kind:'equal',n,tuplet:null});continue}
    const tuplet=tupletFor(node.written,n);if(!tuplet)continue;
    if(tuplet.m===n){if(!out.some(option=>option.kind==='equal'&&option.n===n))out.push({kind:'equal',n,tuplet:null});continue}
    out.push({kind:'equal',n,tuplet});
  }
  // Divided only because its length is no single value, and with no groups or beats of its own: into its units.
  if(!points.length&&!out.length&&node.written.n>1)out.push({kind:'equal',n:node.written.n,tuplet:null});
  return out;
}
function split(node,option){
  if(option.kind==='fixed')return node.fixed.map(child=>({...child,depth:node.depth??0}));
  // (Groups run together: one group as long as its run, its beats theirs.)
  if(option.kind==='runs')return option.runs.map(run=>run.length===1?{...run[0],depth:node.depth??0}:{...run[0],actual:run.reduce((sum,group)=>sum.add(group.actual),R(0)),
    written:run.reduce((sum,group)=>sum.add(group.written),R(0)),beats:run.reduce((sum,group)=>sum+group.beats,0),depth:node.depth??0,
    ...(run.every(group=>group.pulses)?{pulses:run.reduce((sum,group)=>sum+group.pulses,0)}:{})});
  const {n,tuplet}=option,actual=node.actual.div(n),written=tuplet?tuplet.unit:node.written.div(n),ratio=tuplet?node.ratio.mul(R(tuplet.m,tuplet.n)):node.ratio;
  const kind=node.kind==='group'&&!tuplet&&n===node.beats?'beat':'part';
  return Array.from({length:n},(_,i)=>({start:node.start.add(actual.mul(i)),actual,written,ratio,kind,depth:(node.depth??0)+(tuplet?1:0),beat:node.beat}));
}
// The cheapest exact tree for the points in a node, or cost Infinity where no tree places them all. A boundary that
// falls inside a note or a rest (not on a point) splits it in two, a tie or a second rest, and costs accordingly.
// Memoized on the node's span and the points it holds.
function divide(node,points,memo,depth=0){
  const own=inside(node,points);
  // A node nothing falls inside is one value, if its length has one. One without (a bar of 5/4 or 17/4 held through,
  // a group of five) is divided anyway, into its groups or beats, and the note is tied across them.
  if(!own.length&&noteValue(node.written))return {cost:ELEMENT_COST,node:{...node,leaf:true}};
  if(depth>DEEPEST_NESTING)return {cost:Infinity,node:null};
  const key=`${node.start}|${node.actual}|${node.written}|${node.depth??0}|${own.join(',')}`;
  if(memo.has(key))return memo.get(key);
  let best={cost:Infinity,node:null};
  for(const option of candidates(node,own)){
    const children=split(node,option);
    let cost=(option.tuplet?tupletCost(option.n)+NEST_COST*(node.depth??0):LEVEL_COST)
      +children.slice(1).filter(child=>!own.some(point=>point.eq(child.start))).length*SPLIT_COST;
    const built=[];
    for(const child of children){
      if(cost>=best.cost)break;
      const result=divide(child,own,memo,depth+1);cost+=result.cost;built.push(result.node);
    }
    if(built.length===children.length&&cost<best.cost)best={cost,node:{...node,division:option,children:built}};
  }
  memo.set(key,best);return best;
}

// spellMeasure({meter, length, events}) -> {elements, tree}
//   events: [{start, end, content}] sorted, non-overlapping, within [0, length] (Rationals, whole notes); gaps are rests.
//   An event whose content is null is a rest of its own, kept apart from the rests beside it; `hidden` marks it (and
//   its elements) as time nobody can see into yet -- the live score's future.
//   Each element: {start, end, content (null for a rest), rest, type, dots, tuplets: [{id, n, m, unit}], tieStart,
//   tieStop, first, last, beams: [{number, value}]}. Consecutive pieces of one event are tied.
// `measureRest` false: a measure all rest spelled as rests of its own values (a bar of a cycle beside others: score.js
// spellIn), not one measure rest.
export function spellMeasure({meter,length,events,breaks:given=null,measureRest=true}){
  const measureLength=Rational.of(length),points=new Set;
  const all=[];let cursor=R(0);
  for(const event of events){
    const start=Rational.of(event.start),end=Rational.of(event.end);
    if(start.lt(cursor)||end.le(start)||end.gt(measureLength))throw new RangeError(`Event ${start}..${end} overlaps another or leaves the measure (length ${measureLength})`);
    if(start.gt(cursor))all.push({start:cursor,end:start,content:null});
    all.push({start,end,content:event.content??null,...(event.hidden?{hidden:true}:{})});cursor=end;
  }
  if(cursor.lt(measureLength))all.push({start:cursor,end:measureLength,content:null});
  // A measure that is all rest is one measure rest.
  if(measureRest&&all.length===1&&all[0].content===null)return {elements:[{...(all[0].hidden?{hidden:true}:{}),start:R(0),end:measureLength,content:null,rest:true,measureRest:true,type:noteValue(measureLength)?.type??'whole',dots:noteValue(measureLength)?.dots??0,tuplets:[],beams:[],tupletStarts:[],tupletStops:[],tieStart:false,tieStop:false,first:true,last:true}],tree:null};
  for(const item of all){points.add(item.start.toString());points.add(item.end.toString())}
  // (A long bar's break points divide it too, so its tree has a node to end at each.)
  const breaks=given??breakPoints(meter,measureLength);for(const point of breaks)points.add(point.toString());
  const pointList=[...points].map(value=>Rational.of(value)).sort((a,b)=>a.cmp(b));
  const root=measureNode(meter,measureLength),{node:tree,cost}=divide(root,pointList,new Map);
  if(!tree||!Number.isFinite(cost))throw new RangeError(`No tree of tuplets places every onset and end of this measure: ${pointList.join(', ')}`);
  const elements=[],context={...spans(meter),breaks};
  const opening=root.implicit?[{...root.implicit,span:{start:R(0),end:measureLength}}]:[];
  for(const item of all){
    const pieces=[];cover(tree,item.start,item.end,opening,pieces,breaks);
    merge(pieces,context);
    pieces.forEach((piece,index)=>{
      elements.push({...piece,content:item.content,rest:item.content===null,tieStart:item.content!==null&&index<pieces.length-1,tieStop:item.content!==null&&index>0,
        first:index===0,last:index===pieces.length-1,...(item.hidden?{hidden:true}:{})});
    });
  }
  markTuplets(elements);beam(elements,meter);
  return {elements,tree};
}
// The pieces of [start, end): a node wholly covered is one written value if it can be; otherwise its children.
function cover(node,start,end,path,out,breaks=[]){
  const nodeEnd=node.start.add(node.actual);
  if(end.le(node.start)||start.ge(nodeEnd))return;
  const whole=start.le(node.start)&&end.ge(nodeEnd),value=whole&&!crossing(breaks,node.start,nodeEnd)?noteValue(node.written):null;
  if(whole&&(value||node.leaf)){
    if(!value)throw new RangeError(`A span of ${node.written} has no written value`);
    out.push({start:node.start,end:nodeEnd,written:node.written,type:value.type,dots:value.dots,tuplets:path});return;
  }
  if(node.leaf)throw new RangeError(`${start}..${end} cuts a leaf ${node.start}..${nodeEnd}`);
  const tuplet=node.division?.tuplet?[...path,{id:`${node.start}:${node.actual}`,n:node.division.tuplet.n,m:node.division.tuplet.m,unit:node.division.tuplet.unit,span:{start:node.start,end:nodeEnd}}]:path;
  for(const child of node.children)cover(child,start,end,tuplet,out,breaks);
}
// Pieces of one event written as fewer values: the longest run of adjacent pieces whose sum is one written value
// (up to two dots) becomes that value, where notation allows it -- inside one tuplet, or inside one beat (a group of
// three in /8 and /16), or, in a simple meter, from a beat to later in its group (3/4's half note on beat two) or from
// the barline (4/4's dotted half). A value that would hide a beat otherwise stays tied, so the beat is shown.
function merge(pieces,context){
  const sameTuplet=(a,b)=>a.tuplets.length===b.tuplets.length&&a.tuplets.every((t,k)=>t.id===b.tuplets[k].id);
  for(let i=0;i<pieces.length;i++){
    for(let j=pieces.length-1;j>i;j--){
      const run=pieces.slice(i,j+1);
      if(!run.every(piece=>sameTuplet(piece,run[0])))continue;
      const total=run.reduce((sum,piece)=>sum.add(piece.written),R(0)),value=noteValue(total);
      if(!value||value.dots>MAX_MERGED_DOTS||!allowed(run[0],run.at(-1),context))continue;
      pieces.splice(i,j-i+1,{...run[0],end:run.at(-1).end,written:total,type:value.type,dots:value.dots});break;
    }
  }
}
function allowed(first,last,{beatSpans,groupSpans,compound,pulsed=false,measureStart,breaks=[]}){
  if(crossing(breaks,first.start,last.end))return false;
  if(first.tuplets.length)return true;
  const within=spans=>spans.some(([a,b])=>first.start.ge(a)&&last.end.le(b));
  if(within(beatSpans))return true;
  const onBeat=beatSpans.some(([a])=>a.eq(first.start));
  if(!compound&&onBeat&&within(groupSpans))return true;
  // (So too a dotted pulse's group: a note from a pulse held through its group's later pulses is one value, not a chain
  // of tied dotted beats -- 33/16's -- so long as it ends on a pulse, which it would otherwise hide: a group of nine
  // sixteenths a dotted quarter and a dotted eighth, never a half and a sixteenth.)
  if(pulsed&&onBeat&&within(groupSpans)&&beatSpans.some(([,b])=>b.eq(last.end)))return true;
  if(first.start.eq(measureStart)&&beatSpans.some(([,b])=>b.eq(last.end)))return true;
  return false;
}
// A group's beats ([start, end]): each its value in a simple meter; the group in a compound one -- or, where a pulse is
// written dotted (score.js writtenMeter: 11/10 in threes is 33/16), each pulse, a dotted value.
function beatsOf(meter,size,start,beat,compound){
  const pulse=meter.metricReading?size:meter.pulse>1?meter.pulse:compound?size:1,out=[];
  for(let b=0;b<size;b+=pulse)out.push([start.add(beat.mul(b)),start.add(beat.mul(Math.min(size,b+pulse)))]);
  return out;
}
function spans(meter){
  const beat=R(1,meter.denominator||DEFAULT_DENOMINATOR),compound=(meter.denominator||DEFAULT_DENOMINATOR)>=COMPOUND_FROM,groups=meter.metricReading?.beatWeights??(meter.groups?.length?meter.groups:[meter.numerator||DEFAULT_NUMERATOR]);
  const beatSpans=[],groupSpans=[];let start=R(0);
  for(const size of groups){
    const length=beat.mul(size);groupSpans.push([start,start.add(length)]);
    beatSpans.push(...beatsOf(meter,size,start,beat,compound));
    start=start.add(length);
  }
  return {beatSpans,groupSpans,compound,pulsed:meter.pulse>1,measureStart:R(0)};
}
function markTuplets(elements){
  const open=new Map;
  elements.forEach((element,index)=>{
    element.tupletStarts=[];element.tupletStops=[];
    element.tuplets.forEach((tuplet,level)=>{
      if(tuplet.implicit)return;
      const previous=elements[index-1]?.tuplets[level],next=elements[index+1]?.tuplets[level];
      if(previous?.id!==tuplet.id)element.tupletStarts.push(level);
      if(next?.id!==tuplet.id)element.tupletStops.push(level);
    });
  });
  return open;
}
// Beams join the notes of a beat -- of a group of three in /8 and /16, of a tuplet that spans more than a beat -- as
// far as each note's value reaches; a lone short value gets a hook. A rest between two notes of the same group stays
// under the beam (with a stemlet, as complex rhythms are engraved, Ferneyhough's among them): the group reads as one
// unit and its tuplet as one division. A rest at a group's edge breaks it.
function beam(elements,meter){
  const beat=R(1,meter.denominator||DEFAULT_DENOMINATOR),compound=(meter.denominator||DEFAULT_DENOMINATOR)>=COMPOUND_FROM,groups=meter.metricReading?.beatWeights??(meter.groups?.length?meter.groups:[meter.numerator||DEFAULT_NUMERATOR]);
  const spans=[];let start=R(0);
  for(const size of groups){spans.push(...beatsOf(meter,size,start,beat,compound));start=start.add(beat.mul(size))}
  const spanOf=element=>{
    // A drawn tuplet longer than a beat is a group of its own; an irrational meter's implicit one (the whole bar) is not.
    const outer=element.tuplets.find(tuplet=>!tuplet.implicit)?.span;
    if(outer&&outer.end.sub(outer.start).gt(beat))return `t${outer.start}`;
    const index=spans.findIndex(([a,b])=>element.start.ge(a)&&element.start.lt(b));return `s${index}`;
  };
  for(const element of elements)element.beams=[];
  let run=[];
  const flush=()=>{
    const notes=run;run=[];if(notes.length<BEAMED_NOTES)return;
    const levels=notes.map(element=>beamLevels(element.type));
    notes.forEach((element,i)=>{
      for(let level=1;level<=levels[i];level++){
        const left=i>0&&levels[i-1]>=level,right=i<notes.length-1&&levels[i+1]>=level;
        const value=left&&right?'continue':right?'begin':left?'end':i===notes.length-1||levels[i+1]<level&&i>0?'backward hook':'forward hook';
        element.beams.push({number:level,value});
      }
    });
  };
  let current=null,waiting=[];
  for(const element of elements){
    const short=beamLevels(element.type)>0,span=spanOf(element);
    if(span!==current){waiting=[];flush();current=span}
    if(!short){waiting=[];flush();continue}
    if(element.rest){if(run.length)waiting.push(element);continue}
    // A note after rests in the same group: the rests join the beam.
    if(waiting.length){for(const rest of waiting){rest.beamedRest=true;run.push(rest)}waiting=[]}
    run.push(element);
  }
  flush();
}
