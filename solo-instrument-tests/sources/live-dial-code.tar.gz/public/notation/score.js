import {isFeltMeter,meterLevels,FELT_TEMPO} from '../shared/felt-tempo.js';
import {referenceTempo,readingLegend,normalizeMetricReading} from '../shared/meter-reading.js';
// A score from a transcript: parts, staves, voices and measures, every note where the bots' logic put it.
//
//   parts      one a bot, in score order (melody at the top, drums at the foot); a wide-ranging bot on a grand staff,
//              a drum bot on a percussion staff with the feet as a second voice
//   rhythm     authored rational onsets and durations, preserved through performance; no timing reconstruction
//   voices     notes struck together that end together are chords; notes that overlap otherwise are voices, up to four
//              a staff, each continuing the line nearest its pitch
//   pitch      spelled from the key the piece is in (Krumhansl-Kessler), microtones exactly (pitch.js)
// Then each voice's measures are written by rhythm.js. The result is plain data for musicxml.js (and the score view).
import {feelDirection} from '../shared/performance-timing.js';
import {Rational} from '../transcript/rational.js';
import {Transcript} from '../transcript/transcript.js';
import {tempoValue} from '../transcript/tempo-plan.js';
import {readScoreTime,scoreTime} from '../shared/score-time.js';
import {spellMeasure,defaultGrouping} from './rhythm.js';
import {spellPitch,estimateKey,centsLabel} from './pitch.js';
import {drumOf} from './percussion.js';
import {nameChord,chordTuning} from './chords.js';
import {lyricMarks} from './lyrics.js';
import {partTranscript} from './part-meters.js';
import {summarizeSections,sectionSeats} from './section-summary.js';
import {STRING_SECTIONS,SECTION_ORDER} from '../shared/performers/string-section.js';
import {WIND_KINDS} from '../shared/performers/wind-section.js';
import {PERCUSSION} from '../shared/performers/percussion-section.js';
import {BATTERY} from '../shared/performers/battery.js';
import {instrumentRange} from '../shared/performers/instrument-ranges.js';
import {pressureWords,WIND_TECHNIQUE_WORDS,MUTE_WORDS,MULTIPHONIC_WORD} from '../shared/performers/techniques.js';
import {DYNAMICS,dynamicOf,markIndex} from '../shared/dynamics.js';
// (A string's numeral, the model's strings lowest first: a four-string instrument's lowest IV.)
const STRING_NUMERALS=Object.freeze(['IV','III','II','I']);

// The denominators a time signature can have: powers of two, a whole note to a thirty-second.
const WRITTEN=[1,2,4,8,16,32];
// Score order: melody at the top, drums at the foot.
const ORDER=['melody','composition','keys-pads','harmony','texture','texture-noise','bass','beat','utility','template','conductor'];
// An orchestra's parts in an orchestra's score order, above every other part: its woodwinds, brass, timpani, percussion
// and harp, and its strings at the foot, each known by the name its section gives its players (the sections' own tables,
// in their own order); a part the orchestra has no section for (a gong placed on the stage) with the percussion.
const ORCHESTRAL_NAMES=Object.freeze([...WIND_KINDS.winds.order.map(id=>WIND_KINDS.winds.sections[id].abbreviation),...WIND_KINDS.brass.order.map(id=>WIND_KINDS.brass.sections[id].abbreviation),
  ...PERCUSSION.order.flatMap(id=>[PERCUSSION.sections[id].name,PERCUSSION.sections[id].abbreviation]),...SECTION_ORDER.map(id=>STRING_SECTIONS[id].abbreviation)]);
const PERCUSSION_PLACE=ORCHESTRAL_NAMES.indexOf(PERCUSSION.sections.bat.name);
// An orchestral percussionist's instruments by the notes they sound (battery.js; the triangle damped as well as open),
// named where the player takes one up.
const PERCUSSION_INSTRUMENTS=new Map([...Object.values(BATTERY.instruments).map(({note,abbreviation})=>[note,abbreviation]),[80,BATTERY.instruments.triangle.abbreviation]]);
// An orchestral part's place in that order (the longest name its label begins with: "Vln. II 1–2" a second violin's, not
// a first's), or null for a part that is not an orchestra's.
export function orchestralPlace(info){
  if(!info?.bot?.orchestral)return null;
  const label=String(info.label??''),named=ORCHESTRAL_NAMES.map((name,k)=>({name,k})).filter(({name})=>label===name||label.startsWith(`${name} `)).sort((a,b)=>b.name.length-a.name.length)[0];
  return named?named.k:PERCUSSION_PLACE;
}
// Dynamic levels by velocity (shared/dynamics.js).
export {DYNAMICS,dynamicOf};
// A time signature is written as its numerator (9/8, 7/8), the grouping of the bar -- 3+3+3, 2+3+2 -- left to its
// beams; or, with this (buildScore's additiveSignatures), as its groups (2+3+2/8) where they are not the numerator's own.
export const ADDITIVE_SIGNATURES=false;
// The meter a bar is in when nothing says (the conductor's own: 4/4 in sixteenths, grouped 2+2).
const COMMON_TIME=Object.freeze({numerator:4,denominator:4,subdivision:4,groups:Object.freeze([2,2])});
// Definitions: the conventions the score is written in, not choices.
const QUARTER=4,DEFAULT_SUBDIVISION=4,SECONDS_PER_MINUTE=60,MS_PER_SECOND=1000,SEMITONES_PER_OCTAVE=12,STEPS_PER_OCTAVE=7;
// MIDI: middle C (and its octave, C4, from which the staff positions count), General MIDI's acoustic snare (a drum
// note without one is written as the snare).
const MIDDLE_C=60,MIDDLE_OCTAVE=4,DEFAULT_DRUM=38;
// Staves and clefs: the lines a clef sits on, the staves of a grand staff and the lower one's number, the staff steps
// of the treble staff's lines (E4..F5, counted from middle C) and the bass staff's (G2..A3), MusicXML's voices to a
// staff (1-4 on the first, 5-8 on the second), the feet's voice on a drum staff, and the octave count of a 15ma clef.
const TREBLE_LINE=2,BASS_LINE=4,GRAND_STAVES=2,LOWER_STAFF=2,VOICES_PER_STAFF=4,FEET_VOICE=2,FIFTEENTH=2;
export const PERCUSSION_LINE=2;
// A grand staff's upper staff, where a line moving between the staves has left it for a whole bar: its bar's rest in a
// voice of its own (the line is the first).
const FILLER_VOICE=2;
// A section's lines a staff where it is written divisi: two, the upper stems up and the lower down (layDivisi).
const DIVISI_PER_STAFF=2;
// The words over a section written divisi: how many ways, and where its lines divide and join again (the MusicXML
// reader knows them by these).
export const divisiWords=lines=>`div. a ${lines}`;
export const DIVISI_WORDS=Object.freeze({divided:'div.',together:'unis.'});
const TREBLE_STAFF_STEPS=Object.freeze([2,10]),BASS_STAFF_STEPS=Object.freeze([-10,-2]);
// A section's string players read one staff in their instruments' own clefs (steps from middle C its staff spans):
// the violin's treble (an octave sign above it high), the viola's alto or treble, the cello's bass, tenor or treble, the
// contrabass's bass clef sounding an octave below what is written, as its parts are. Each part takes the one its notes
// need the fewest ledger lines in.
const STRING_CLEFS=Object.freeze({
  violin:Object.freeze([{clef:{sign:'G',line:2},steps:[2,10]},{clef:{sign:'G',line:2,octave:1},steps:[9,17]}]),
  viola:Object.freeze([{clef:{sign:'C',line:3},steps:[-4,4]},{clef:{sign:'G',line:2},steps:[2,10]}]),
  cello:Object.freeze([{clef:{sign:'F',line:4},steps:[-10,-2]},{clef:{sign:'C',line:4},steps:[-6,2]},{clef:{sign:'G',line:2},steps:[2,10]}]),
  contrabass:Object.freeze([{clef:{sign:'F',line:4,octave:instrumentRange('contrabass').writtenToSounding/12},steps:[-17,-9]}]),
});
const SEAT_INSTRUMENT=Object.freeze({vn1:'violin',vn2:'violin',va:'viola',vc:'cello',cb:'contrabass'});
// A slash of the plans staff: on the treble staff's middle line (B4).
const SLASH=Object.freeze({pitch:71,octave:4});
// Tempo: a dotted beat is three pulses; compound meters are in eighths or shorter, a group of up to three pulses one
// beat.
const DOTTED_GROUP=3,COMPOUND_FROM=8,PULSE_GROUP=3;
// Where on the string a bowed note was played, in words (its contact, capture.js: -1 at the bridge, 0 ordinario, 1 over
// the fingerboard): each band from its least contact, nearer the bridge or the fingerboard alike.
const CONTACT_WORDS=Object.freeze([[.85,'molto'],[.45,''],[.2,'poco']]);
const contactWords=contact=>{const band=CONTACT_WORDS.find(([least])=>Math.abs(contact)>=least);if(!band)return 'ord.';
  return `${band[1]?`${band[1]} `:''}sul ${contact<0?'pont.':'tasto'}`};
// Numbers the same within rounding: times in whole notes, lengths, velocities.
const SAME_TIME=1e-9,SAME_LENGTH=1e-12,SAME_LEVEL=1e-9;
// A glide's source pitch matches its declared line's written pitch within the pitch representation's tolerance.
const SAME_PITCH=1e-3;
// (A slurred note this near the pitch it follows, semitones: written portato -- the render's same pitch, ten cents.)
const PORTATO_PITCH=.1;
// A category not in ORDER goes after all that are.
const UNORDERED=99;
// A shared position that a part's time map gives as a number (exact where the map holds a rate: a whole or a simple
// fraction of a tick) as a rational: its continued fraction, to a denominator no larger than this.
const RATIONAL_DENOMINATOR=1<<16,GLIDE_GRID=64;
function rationalOf(value){
  const sign=value<0?-1:1;let x=Math.abs(value),[h0,h1,k0,k1]=[0,1,1,0];
  for(let guard=0;guard<64;guard++){
    const a=Math.floor(x),h=a*h1+h0,k=a*k1+k0;if(k>RATIONAL_DENOMINATOR)break;
    [h0,h1,k0,k1]=[h1,h,k1,k];const rest=x-a;if(rest<1e-12)break;x=1/rest;
  }
  return new Rational(sign*h1,k1);
}
// Dates as ISO writes them (yyyy-mm-dd).
const DATE_LENGTH=10;

// Choices: heuristics, named to be evaluated.
// When the transcript does not say: the tempo (the conductor's own), a note's velocity, and the voices a staff holds.
const DEFAULT_VELOCITY=.6,MAX_VOICES_PER_STAFF=4;
// The key: each note weighed by how long it rings, at least this (whole notes).
const KEY_WEIGHT_FLOOR=.05;
// Staves and clefs by a part's range (MIDI): a grand staff for a two-handed keyboard's part (its definition's `hands`:
// a pianist's, a harpsichordist's, an accordionist's), whatever its range, and for any part wider than two octaves
// reaching below A3 and above E4; else the treble or the bass clef, whichever reads its notes with the fewer ledger lines
// (weighed as the octave signs weigh them, `pain`; alike, a treble clef from a median of B-flat 3), a 15ma treble clef
// from a median of G6, an 8va from G5, an 8vb bass clef to D2.
const KEYBOARD_HANDS=2,GRAND_STAFF_RANGE=24,GRAND_STAFF_LOW=57,GRAND_STAFF_HIGH=64,TREBLE_FROM=58,FIFTEENTH_CLEF_FROM=91,EIGHTH_CLEF_FROM=79,EIGHTH_BASSO_TO=38;
// What sounded against what is written: a deviation under this (seconds) is none; from this (seconds) it may be printed
// (`timingMarks`: off unless asked, the owner, 30 September 2026: "Turn that indication off in the scores, although you
// can keep it as a possible setting").
const NO_DEVIATION=1e-6,TIMING_PRINTED=.005;
// Phrase marks below use written spacing and explicit articulation, with these beat-share and group-size thresholds.
// A desk's two players play alike where their pitches are this near (semitones): each player's own few cents of
// inflection of their part (string-section.js PLAYER), never a written difference.
const DESK_UNISON=.12;
const LEGATO_GAP=.02,FULL_LENGTH=.05,SLUR_NOTES=2;
// Accents: a note louder than the median of its neighbours (this many either side, at least this many) by this much
// and this loud is marcato; by this much and this loud, accented.
const ACCENT_NEIGHBOURS=3,ACCENT_MIN_NEIGHBOURS=2,MARCATO_LIFT=.24,MARCATO_VELOCITY=.5,ACCENT_LIFT=.12,ACCENT_VELOCITY=.42;
// Dynamics: a line's loudness smoothed by the median of this many events either side; a change of velocity under
// this is no step; a hairpin over this many steps or more, across this many events or more, changing by this much,
// and the level it reaches held over this many events; one over more than this many bars is written in words; a new
// dynamic printed where it holds for this many events.
const SMOOTHING_REACH=4,DYNAMIC_STEP=.01,HAIRPIN_STEPS=2,HAIRPIN_SPAN=2,HAIRPIN_CHANGE=.09,LEVEL_HELD_OVER=4,WORDED_OVER_BARS=2,DYNAMIC_HOLDS=4;
// Octave signs: ledger lines up to this many cost nothing; opening a sign costs this; a note under one this, and this
// for each ledger line it still needs.
const FREE_LEDGER_LINES=2,OTTAVA_OPENING=4,OTTAVA_UNDER=.3,OTTAVA_UNDER_PER_LINE=.6;
// A line on a grand staff: one voice moving between the staves, beamed across them, where it strikes one note at a
// time (this share of its onsets or fewer struck together); each note on the staff that reads it with the fewer ledger
// lines, each ledger line costing one, a change of staff this, a note off its own staff (by middle C) this -- so the line
// uses both staves: a note two ledger lines or more from one staff that the other reads without any is written there,
// and a figure crosses the staves wherever its notes do.
const MONOPHONIC_SHARE=.05,STAFF_CHANGE=1,OFF_STAFF=.1;
// Tempo marks: a tick's length changing by this share or more is a change of tempo; a jump of this share is a new
// mark; a mark differing by this many beats a minute is printed again, and a ramp gets words.
const TEMPO_CHANGE=.01,TEMPO_JUMP=.03,TEMPO_DIFFERS=.5;
// Chords' tuning: a voice striking this many pitch classes or more is a chord; at most this many inflected tones
// named; and whether it is printed beneath the chord's symbol (where it changes) -- not, for now: the cents in the
// staves carry each note's tuning. It stays with the symbol as data (buildScore's chordTunings prints it).
const CHORD_PITCH_CLASSES=2,TUNED_TONES_SHOWN=2,CHORD_TUNINGS_PRINTED=false;
// Words (a mark's text) in points; a part's short name: a name of up to this many letters kept whole, else cut to
// this many.
const WORDS_SIZE=9,ABBREVIATION_KEEPS=12,ABBREVIATION_LENGTH=10;
// The outputs a render's audience hears.
const HEARD_OUTPUTS=new Set(['synth','samples']);

const R=(n,d=1)=>new Rational(n,d);
// A spelled pitch as diatonic steps from middle C; the ledger lines it needs on a staff (its lines' [bottom, top] in
// steps); and what they cost -- nothing up to the free ones, then more the further they go (a third 1, a fourth 3, a
// fifth 6).
const STEPS='CDEFGAB',stepOf=spelled=>(spelled.octave-MIDDLE_OCTAVE)*STEPS_PER_OCTAVE+STEPS.indexOf(spelled.step);
const ledgersOn=(step,[bottom,top])=>step>top+1?Math.floor((step-top)/2):step<bottom-1?Math.floor((bottom-step)/2):0;
const pain=lines=>lines<=FREE_LEDGER_LINES?0:(lines-FREE_LEDGER_LINES)*(lines-1)/2;
// The grace note a glide slides from (buildScore's glides, sliceScore): its pitch, spelled in the key.
const graceOf=(pitch,key,accidentalShown=true)=>({pitch,spelled:spellPitch(pitch,{fifths:key?.fifths??0}),accidentalShown});
// A meter as it can be written. A denominator that is no power of two (mh_PlexBOT's 15/12, 7/10, 17/10) is written as
// itself, as Ferneyhough and Adès write such bars -- a twelfth a triplet eighth, under the bar's implicit tuplet
// (rhythm.js), its tempo marked in quarters -- where the score allows it (IRRATIONAL_METERS; buildScore's
// irrationalMeters: the owner, 4 October 2026, "Make it a configuration setting whether Ferneyhoughish meters are allowed
// to be scored, with the default being yes"). Where it does not, the bar is written as the bots show it to Ableton
// (public/shared/live-meter.js): the same pulses, each the nearest power-of-two value, the tempo keeping every pulse its
// length -- 15/12 is 15/16, 7/10 is 7/8 -- and the tempo mark says how fast they go.
// A pulse divided in three (a subdivision three divides and two does not, 3 or 9, as meter-tactus.js reads a tactus; a
// 6 holds halves as well as thirds, and keeps its brackets where it plays thirds) is a dotted beat, its thirds the next
// shorter value: 4/4 in threes is 12/8, 11/10 in threes 33/16 at a dotted eighth, each group three times as many -- not
// every pulse's thirds under a triplet's bracket (the owner on Op. 3.22's: "crazy rhythms"; its 11/8 carried 9:6, 18:12
// and 12:8 brackets over its groups). `pulse`: the written values a pulse is (3; else none, one).
// Its signature shown no finer than it needs: a dotted pulse finer than an eighth (3+3+2/8 in threes, 24/16) shown in
// quarters where its length allows (6/4), its groups left to its beams (the owner, 4 October 2026: "reduce meters like
// 24/16 to simpler forms (perhaps 6/4 or even 3/2) -- not everything about subdivision needs indicating in the meter");
// a compound meter of eighths (12/8) kept as it is. `shown`: {numerator, denominator}, the signature printed.
export const IRRATIONAL_METERS=true;
let irrationalWritten=IRRATIONAL_METERS;
// A bar in eighths or finer grouped evenly, each group a power of two of its note, shown with its group as its beat:
// 16/8 in twos as 8/4, in fours as 4/2, 16/16 in fours as 4/4, 6/8 in twos as 3/4 -- its notes as they were (the owner,
// 5 October 2026, of a 16/8: "this seems like an absurd meter. Can we reduce these meters to, like, 4/2, or even 2 bars of
// 4/4, when possible?"; a bar too long to be heard as one is still written as the bars of its cycle).
function evenlyShown(meter){
  const groups=meter.groups?.length?meter.groups:[meter.numerator],size=groups[0];
  if(meter.shown||!(meter.denominator>=8)||groups.length<2||!groups.every(group=>group===size)||!(size>1&&Number.isInteger(Math.log2(size)))||meter.denominator/size<1)return meter;
  return {...meter,shown:{numerator:groups.length,denominator:meter.denominator/size}};
}
export function writtenMeter(meter){
  if(!meter||meter.pulse||meter.fixedDenominator||meter.metricReading?.preserveDenominator)return meter;
  if(!WRITTEN.includes(meter.denominator)&&irrationalWritten)return meter;
  const subdivision=Number(meter.subdivision)||DEFAULT_SUBDIVISION,ternary=!meter.tempoUnit&&subdivision%DOTTED_GROUP===0&&subdivision%2!==0;
  if(WRITTEN.includes(meter.denominator)&&!ternary)return evenlyShown(meter);
  const denominator=[...WRITTEN].sort((a,b)=>Math.abs(Math.log2(a/meter.denominator))-Math.abs(Math.log2(b/meter.denominator))||Math.abs(Math.log2(a/QUARTER))-Math.abs(Math.log2(b/QUARTER)))[0];
  if(!ternary)return {...meter,denominator,playedDenominator:meter.denominator};
  let shown=[meter.numerator*DOTTED_GROUP,denominator*2];
  if(shown[1]>COMPOUND_FROM)while(shown[1]>QUARTER&&shown[0]%2===0)shown=[shown[0]/2,shown[1]/2];
  return {...meter,numerator:meter.numerator*DOTTED_GROUP,denominator:denominator*2,groups:(meter.groups?.length?meter.groups:[meter.numerator]).map(size=>size*DOTTED_GROUP),
    subdivision:subdivision/DOTTED_GROUP,pulse:DOTTED_GROUP,playedDenominator:meter.denominator,...(shown[1]!==denominator*2?{shown:{numerator:shown[0],denominator:shown[1]}}:{})};
}
// A bar too long to be heard as one, as the bars of its cycle: of its groups' levels (within each group, its cells and
// their groups; its groups; the groups of its groups), the coarsest each of whose spans lasts no longer than a listener
// hears as one group (felt-tempo.js), each span a bar of the written meter's note, grouped by the level below it.
// `unitSeconds`: the written note's seconds. -> [{offset (wholes from the bar's start), length (wholes), meter}].
export function hypermetricBars(meter,unitSeconds){
  const levels=meterLevels(meter).filter(level=>level.length>1).map(level=>{let at=0;return level.map(span=>{const start=at;at+=span;return {start,span}})});
  const fitting=levels.filter(level=>level.every(({span})=>span*unitSeconds<=FELT_TEMPO.longestBarSeconds+1e-9));
  const chosen=fitting.reduce((best,level)=>!best||level.length<best.length?level:best,null)??levels.reduce((best,level)=>!best||level.length>best.length?level:best,null);
  if(!chosen||chosen.length<2)return null;
  // (Each bar's groups: the finest finer level's spans inside it, where they fall within it.)
  const finer=levels.filter(level=>level.length>chosen.length).sort((a,b)=>b.length-a.length)[0];
  return chosen.map(({start,span})=>{
    const inside=finer?.filter(cell=>cell.start>=start&&cell.start+cell.span<=start+span).map(cell=>cell.span)??[];
    const groups=inside.reduce((a,b)=>a+b,0)===span&&inside.length>1?inside:[span];
    return {offset:R(start,meter.denominator),length:R(span,meter.denominator),meter:{...meter,numerator:span,groups,hypermetric:true}};
  });
}
// A played pulse of a meter, in written whole notes; and a whole's ticks of its clock.
// A transcript whose notes breathed inside are written as their pieces: each piece its share of the written interval,
// exactly, its sounding time its share of its seconds; a breath mark after each but the last; the first keeps its identity.
function breathedPieces(transcript){
  const copy=Transcript.fromJSON(transcript.toJSON());
  copy.notes=copy.notes.flatMap(note=>{
    if(!note.breaths?.length)return [note];
    const {at,duration,axis}=readScoreTime(note),cuts=[...new Set(note.breaths)].map(share=>Rational.of(share)).filter(share=>share.sign()>0&&share.lt(1)).sort((a,b)=>a.cmp(b));
    const bounds=[Rational.ZERO,...cuts,Rational.of(1)],{breaths,scoreId,...rest}=note;
    return bounds.slice(0,-1).map((share,k)=>{const from=at.add(duration.mul(share)),to=at.add(duration.mul(bounds[k+1])),last=k===bounds.length-2;
      return {...rest,...(k===0&&scoreId!=null?{scoreId}:{}),scoreTime:scoreTime(from,to.sub(from),{axis}),startSeconds:note.startSeconds+share.toNumber()*note.duration,
        duration:(bounds[k+1].sub(share)).toNumber()*note.duration,...(last?{}:{breathAfter:true}),...(k>0?{slurred:false}:{})}});
  });
  return copy;
}
export const pulseWholes=meter=>{const written=writtenMeter(meter);return R(written.pulse??1,written.denominator)};
const ticksPerWhole=meter=>{const written=writtenMeter(meter);return (written.subdivision||DEFAULT_SUBDIVISION)*written.denominator};
// Whether a part strikes one note at a time, by how many notes each of its onsets strikes: MONOPHONIC_SHARE of its onsets
// or fewer struck together.
export const oneAtATime=counts=>counts.filter(count=>count>1).length<=MONOPHONIC_SHARE*counts.length;

// A meter as a bar played in it is written, given the meter its plan gave it: grouped as the plan grouped it where it
// was played in the planned meter (the conductor's clock keeps a meter's default grouping; the bots regroup each bar
// by their plan, Agent.interpretClock), else as it was played.
export const groupedAsPlanned=(meter,planned)=>planned&&meter&&planned.numerator===meter.numerator&&planned.denominator===meter.denominator
  ?{...meter,groups:planned.groups,...(meter.metricReading||planned.metricReading?{metricReading:normalizeMetricReading(planned.metricReading??meter.metricReading,meter.numerator,planned.groups)??undefined}:{})}:meter;

// Legacy observational measurement of a sound against the performed clock. Retained for analysis callers only;
// buildScore never calls it. This value is NOT symbolic duration and must not be used to construct scoreTime.
export function clockedLength(transcript,note){
  const times=transcript.timeline.tickSeconds,last=times.length-2;if(last<0)return null;
  const start=note.replay||!Number.isInteger(note.tick)?note.startSeconds-(transcript.timeline.lookahead||0):transcript.secondsAtTick(note.tick)+(note.offset||0);
  if(!Number.isFinite(start))return null;
  const end=start+Math.max(0,note.duration||0);
  let i=0,high=last;
  while(i<high){const middle=(i+high+1)>>1;if(times[middle]<=start)i=middle;else high=middle-1}
  let length=0;
  for(let from=start;from<end;i++){
    const to=i===last?end:Math.min(end,times[i+1]),meter=transcript.barAt(i)?.meter;if(!meter)return null;
    length+=(to-from)/(ticksPerWhole(meter)*(times[i+1]-times[i]));
    from=to;
  }
  return length;
}

// A string section's seats written whole (`sections: 'complete'`: every player, a bot's seats divisi) or folded
// (`'summary'`: section-summary.js, a staff a section, or by `sectionLevel`: 'desk', 'section', 'choir', 'all'); `'auto'`,
// whole up to this many seats (a staff a desk: a page's worth), folded past it.
export const COMPLETE_SEATS=24;
// buildScore(transcript, {title, maxVoices, sections, irrationalMeters, hypermeter (false: a bar too long to be heard as
// one written whole all the same)}) -> score (see the end of buildScoreWritten for
// its shape, and its irrationalMeters: whether irrational meters were written as themselves, IRRATIONAL_METERS where
// unsaid).
export function buildScore(input,options={}){
  const before=irrationalWritten;irrationalWritten=options.irrationalMeters??IRRATIONAL_METERS;
  try{return {...buildScoreWritten(input,options),irrationalMeters:irrationalWritten}}finally{irrationalWritten=before}
}
function buildScoreWritten(input,options={}){
  let transcript=input instanceof Transcript?input:Transcript.fromJSON(input),formationWords=[];
  // (The score is what was written, the same however it was played; what was played -- each note's attack against its
  // written onset, its release, a legato read as a slur -- only where a performance's reading is asked: options.performance,
  // or its timing marks.)
  const performance=options.performance??Boolean(options.timingMarks);
  // A missing authored interval is a producer defect. The engraver never guesses rhythm from audio timing.
  for(const note of transcript.notes)readScoreTime(note,{axis:transcript.scoreAxis});
  // (A note its player breathed inside, at written places (wind-seat.js breathPlaces: exact shares of its written
  // length), written as its pieces, each tongued again, a breath mark after each but the last -- the owner, 9 October 2026:
  // "Breath marks are also not scored in a reasonable way".)
  if(transcript.notes.some(note=>note.breaths?.length))transcript=breathedPieces(transcript);
  const maxVoices=options.maxVoices??MAX_VOICES_PER_STAFF,sections=options.sections??'complete';
  if(sections==='summary'||sections==='auto'&&sectionSeats(transcript)>(options.completeSeats??COMPLETE_SEATS))({transcript,words:formationWords}=summarizeSections(transcript,{level:options.sectionLevel??'section'}));
  const bars=transcript.timeline.bars,warnings=[],plans=options.plans??null;
  // ---- the timeline: bars from the window's first (bar 0 unless a window is asked for), in whole notes ----------
  // A bar's meter is the one it was played in; past the last bar played, the one a plan gives it (a queued time
  // signature, a form's next section); else the meter of the bar before. A bar played in the meter its plan gave it is
  // grouped as the plan grouped it: the conductor's clock keeps a meter's default grouping, the bots regroup each bar
  // by their plan (plans.js, groupings) -- so its time signature is the one it was planned with.
  const asPlanned=bar=>groupedAsPlanned(bar.meter,plans?.groupings?.get(bar.bar));
  const lengthOf=meter=>R(meter.numerator,meter.denominator),known=new Map(bars.map(bar=>[bar.bar,writtenMeter(asPlanned(bar))]));
  const planned=new Map([...(plans?.meters??new Map)].map(([bar,meter])=>[bar,writtenMeter(meter)]));
  const firstBar=options.fromBar??bars[0]?.bar??0,defaultMeter=writtenMeter(bars[0]?.meter)??structuredClone(COMMON_TIME);
  const marked=[...new Set([...known.keys(),...planned.keys()])].sort((a,b)=>a-b),meterMemo=new Map;
  const meterAt=bar=>{
    if(meterMemo.has(bar))return meterMemo.get(bar);
    let meter=known.get(bar)??planned.get(bar);
    if(!meter){let before=null;for(const b of marked){if(b<bar)before=b;else break}meter=before==null?defaultMeter:(known.get(before)??planned.get(before))}
    meterMemo.set(bar,meter);return meter;
  };
  // An explicitly bounded partial bar (for example where a composed stream joins another axis) retains its exact
  // symbolic extent. The physical recording's last partial tick is not such a declaration.
  const declaredLengths=new Map(bars.filter(bar=>bar.scoreDuration!=null).map(bar=>[bar.bar,
    Rational.of(bar.scoreDuration).div(bar.meter.subdivision).mul(pulseWholes(bar.meter))]));
  const barLength=bar=>declaredLengths.get(bar)??lengthOf(meterAt(bar));
  const starts=new Map([[firstBar,R(0)]]);
  const startOf=bar=>{
    if(starts.has(bar))return starts.get(bar);
    if(bar>firstBar){let b=bar;while(!starts.has(b))b--;for(let k=b;k<bar;k++)starts.set(k+1,starts.get(k).add(barLength(k)))}
    else{let b=bar;while(!starts.has(b))b++;for(let k=b;k>bar;k--)starts.set(k-1,starts.get(k).sub(barLength(k-1)))}
    return starts.get(bar);
  };
  const lastMeter=meterAt(Math.max(firstBar,bars.at(-1)?.bar??firstBar));
  const notes=[],freeNotes=[],graceNotes=[],entryOf=new Map;
  // Stroke identity is resolved by capture at the musical-event boundary. Acoustic overlap cannot merge two
  // independently authored notes, and articulation or an early release cannot rewrite their symbolic durations.
  for(const told of transcript.notes){
    const read=readScoreTime(told,{axis:transcript.scoreAxis});
    if(read.grace){graceNotes.push(told);continue}
    // (A note played freely in a hold -- a cadenza's (score-time.js freeTime) -- has no place in the bar's rhythm: left
    // to the player, as a cadenza is, and marked where its hold is, below.)
    if(read.free){freeNotes.push({voice:told.voice,tick:told.tick});continue}
    const note=told,{start:onset,end:ends}=transcript.scoreIntervalOf(note);
    if(!onset){warnings.push(`A note of ${note.voice} has no place on the timeline and was left out`);continue}
    // A note in a hold's free time (a cadenza's: transcript.onsetOf, timing "held") has no place in the bar's rhythm:
    // left to the player, as a cadenza is, and marked where its hold is (below).
    if(onset.timing==='held'){freeNotes.push({voice:note.voice,tick:note.tick});continue}
    // A string a glissando sweeps between its first and its last (capture.js gliss: a harp's): sounded, and written as
    // the line joining those two (below).
    if(note.gliss&&note.gliss.index>0&&note.gliss.index<note.gliss.of-1)continue;
    const beat=pulseWholes(onset.meter),bpm=performance?(note.bpm??transcript.bpmAt(note.tick)):null;
    const timed=Number.isFinite(bpm)&&bpm>0;
    const start=startOf(onset.bar).add(onset.beat.mul(beat));
    const writtenLength=startOf(ends.bar).add(ends.beat.mul(pulseWholes(ends.meter))).sub(start);
    if(writtenLength.sign()<=0)throw new RangeError('An authored score interval must end after its onset');
    // (Where a performance's reading is asked, its seconds kept beside its written length: how long it sounded, read for
    // its articulation -- its release against its written end, a legato's slur -- never for its rhythm.)
    const entry={voice:note.voice,start,bar:onset.bar,
      duration:writtenLength,...(timed&&Number.isFinite(note.duration)?{sounded:note.duration}:{}),staccato:note.staccato===true,arpeggiate:note.scoreArpeggio===true,pitch:note.pitch,velocity:note.velocity??DEFAULT_VELOCITY,percussion:note.percussion??null,
      // (Its written dynamic, where its player wrote one before playing it: the marks and hairpins this score writes.)
      ...(note.written&&Number.isFinite(Number(note.written.velocity))?{written:{velocity:Number(note.written.velocity),mark:String(note.written.mark)}}:{}),
      owner:note.owner,timing:onset.timing,deviation:timed?onset.deviationSeconds:0,strum:timed?(note.realizedOffset??note.offset??0)-(note.offset??0):0,
      ...(timed?{secondsToWhole:bpm/SECONDS_PER_MINUTE*beat.toNumber()}:{}),replay:note.replay??null,...(note.lyric?{lyric:note.lyric}:{}),
      ...(typeof note.line==='string'?{line:note.line}:{}),
      // A performer's realization of it (shared/performers/realization.js markedNotes): its fingering and the pedal marks
      // it carries.
      ...(note.fingering?{fingering:note.fingering}:{}),...(note.pedalMarks?.length?{pedalMarks:note.pedalMarks}:{}),
      // And a woodwind's pitch between the notes its keys play: the fingering its player shades to it (wind-seat.js,
      // woodwind-fingering.js), its diagram drawn.
      ...(note.fingered?{fingered:note.fingered}:{}),
      // Its hammer's lag, where its bot named one (capture.js): how it sounded, no roll.
      ...(note.lag?{lag:note.lag}:{}),...(note.gliss?{gliss:note.gliss}:{}),
      // How its player played it (capture.js technique: arco or pizzicato) and whether it slurred it to the note before.
      ...(note.technique?{technique:note.technique}:{}),...(note.contact?{contact:note.contact}:{}),...(note.bowPressure?{bowPressure:note.bowPressure}:{}),...(note.harmonic?{harmonic:note.harmonic}:{}),...(note.multiphonic?{multiphonic:note.multiphonic}:{}),...(note.extended?{extended:note.extended}:{}),...(note.slurred?{slurred:true}:{}),...(note.portato?{portato:true}:{}),...(note.phrased?{phrased:true}:{}),
      // (A breath its player took after it -- a wind's catch breath, transcript.js releaseNote; a breathed note's pieces.)
      ...(note.breathAfter?{breathAfter:true}:{})};
    // Before the window: dropped if it has stopped sounding, else it arrives tied at the window's start.
    if(entry.start.sign()<0){
      const left=entry.duration.add(entry.start);
      if(left.sign()<=0)continue;
      entry.duration=left;entry.start=R(0);entry.continuedIn=true;
    }
    notes.push(entry);entryOf.set(told,entry);
  }
  // Grace groups belong to a named composed note boundary, never to a nearby sound. They consume no bar time and
  // keep their own order even when performance offsets cross. A score window carries them only with their anchor.
  const anchors=new Map;
  for(const note of transcript.notes)if(note.scoreId!=null&&!readScoreTime(note).grace&&!readScoreTime(note).free){
    const id=JSON.stringify([note.voice,String(note.scoreId)]);if(!anchors.has(id))anchors.set(id,note);
  }
  for(const note of graceNotes){
    const {grace,at}=readScoreTime(note),parent=anchors.get(JSON.stringify([note.voice,grace.anchor]));
    if(!parent)throw new RangeError(`Grace anchor ${grace.anchor} is absent from ${note.voice}`);
    const parentTime=readScoreTime(parent),boundary=grace.placement==='before'?parentTime.at:parentTime.end;
    if(parentTime.axis!==grace.axis||!at.eq(boundary))throw new RangeError('A grace must name its anchor boundary on the same score axis');
    const entry=entryOf.get(parent);if(!entry)continue;
    (entry.graces??=[]).push({...grace,pitch:note.pitch,percussion:note.percussion??null});
  }
  for(const entry of notes)entry.graces?.sort((a,b)=>a.order-b.order);
  // ---- glides ----------------------------------------------------------------------------------------------------
  // The gesture's kind is declared at its source: into a note, or through it. Connect it in the written line, using
  // exact composed order and boundaries. Acoustic onsets, releases and the glide's speed never choose its notation.
  const lines=new Map;let slides=0;
  for(const note of transcript.notes)if(!note.percussion){
    const time=readScoreTime(note);if(time.grace||time.free)continue;
    const key=JSON.stringify([note.voice,note.line??'']);
    (lines.get(key)||lines.set(key,[]).get(key)).push({note,time});
  }
  for(const line of lines.values()){
    if(!line.some(({note})=>note.glide))continue;
    line.sort((a,b)=>a.time.at.cmp(b.time.at));
    const through=new Set;
    for(const {note} of line){
      const entry=entryOf.get(note);if(!entry||!Number.isFinite(note.glide?.from))continue;
      if(note.glide.kind!=null&&!['into','through'].includes(note.glide.kind))throw new TypeError('A glide is into a note or through it');
      if(note.glide.kind==='through'){through.add(note);entry.glissTo=entry.pitch;entry.pitch=note.glide.from}
    }
    line.forEach(({note,time},index)=>{
      const entry=entryOf.get(note),from=note.glide?.from;if(!entry||!Number.isFinite(from))return;
      if(through.has(note)){
        const next=line[index+1],nextEntry=next&&entryOf.get(next.note);
        if(nextEntry&&next.time.at.eq(time.end)&&Math.abs(nextEntry.pitch-entry.glissTo)<=SAME_PITCH){
          entry.slideTo=nextEntry.slideFrom=++slides;entry.glissando=nextEntry.glissando=nextEntry.glissIn=true;
        }else entry.graceTo=entry.glissTo;
        return;
      }
      entry.glideFrom=from;
      // The preceding composed attack, including its chord tones, not the last acoustic attack to arrive.
      let k=index-1;while(k>=0&&line[k].time.at.eq(time.at))k--;
      for(const struck=line[k]?.time.at;k>=0&&line[k].time.at.eq(struck);k--){
        const source=Math.abs(line[k].note.pitch-from)<=SAME_PITCH?entryOf.get(line[k].note):null;
        if(source&&source.slideTo==null){source.slideTo=entry.slideFrom=++slides;break}
      }
    });
  }
  // A glissando: its first string held to its last, a line joining them (a harp's sweep, as a harpist reads one: the
  // strings between are the line's). One whose last string is outside the window keeps its first as it sounded.
  const sweeps=new Map;
  for(const entry of notes)if(entry.gliss){const key=`${entry.voice}|${entry.gliss.id}`;(sweeps.get(key)||sweeps.set(key,{}).get(key))[entry.gliss.index===0?'first':'last']=entry}
  for(const {first,last} of sweeps.values()){
    if(!first||!last||!last.start.gt(first.start))continue;
    first.slideTo=last.slideFrom=++slides;last.glideFrom=first.pitch;first.glissando=last.glissando=true;
    // (Its last string in its first's voice, one hand's sweep, and on its own staff: the line crossing between them.)
    last.sweptFrom=first;first.sweptTo=last;
  }
  // ---- measures ------------------------------------------------------------------------------------------------
  const ringsTo=note=>note.start.toNumber()+(typeof note.duration==='number'?note.duration:note.duration.toNumber());
  let lastBar=bars.length?bars.at(-1).bar-1:firstBar;
  if(bars.length&&transcript.timeline.tickSeconds.length-1>bars.at(-1).tick)lastBar=bars.at(-1).bar;
  if(options.toBar!=null)lastBar=options.toBar;
  else{const end=Math.max(0,...notes.map(ringsTo));while(startOf(lastBar+1).toNumber()<end-SAME_TIME)lastBar++}
  // A whole performance the bots ended (a stop commitment) closes at its last bar, if nothing begins after it: what rings
  // on past it is a tail, not a bar of music. A window can close the performance too (`closes`: its last bar is the
  // performance's last, as a scrolling line's is) -- the ending written as a whole score's is.
  const whole=options.fromBar==null&&options.toBar==null&&options.knownUntil==null,closes=whole||Boolean(options.closes);
  if(whole&&plans?.endBar!=null&&plans.endBar>=firstBar&&plans.endBar<lastBar&&!notes.some(note=>note.start.ge(startOf(plans.endBar+1))))lastBar=plans.endBar;
  lastBar=Math.max(firstBar,lastBar);
  const windowEnd=startOf(lastBar+1);
  for(let i=notes.length-1;i>=0;i--)if(notes[i].start.ge(windowEnd))notes.splice(i,1);
  // (A change of grouping alone is a new time signature only where the signature writes the groups.)
  const measures=[],additiveSignatures=options.additiveSignatures??ADDITIVE_SIGNATURES;
  // (A bar played too long to be heard as one -- longer than a listener hears as one group at its tempo, felt-tempo.js:
  // 107/4 at a quarter of 60 -- is no meter but a hypermetrical cycle (the owner, 4 October 2026): written as bars of the
  // coarsest level of its groups each of whose spans is short enough to be one, each with its own signature, the cycle
  // its measure still (cycleOf).)
  const playedBars=new Map(bars.map(bar=>[bar.bar,bar]));
  const cycleOf=(bar,written)=>{
    const played=playedBars.get(bar),bpm=played?transcript.scoreBpmAt(played.tick):null;
    if(options.hypermeter===false||!played||!(bpm>0))return null;
    const seconds=played.meter.numerator*60/bpm;if(seconds<=FELT_TEMPO.longestBarSeconds||isFeltMeter(played.meter,bpm))return null;
    const length=barLength(bar);
    return hypermetricBars(written,seconds/written.numerator)?.filter(each=>each.offset.lt(length)).map(each=>
      ({...each,length:each.offset.add(each.length).gt(length)?length.sub(each.offset):each.length}))??null;
  };
  for(let bar=firstBar;bar<=lastBar;bar++){
    let meter=meterAt(bar);const previous=measures.at(-1)?.meter,afterCycle=Boolean(measures.at(-1)?.cycle);
    // (Its places a line may break inside it: none -- a bar is never broken between systems, the owner on Op. 3.22's:
    // "bars broken over system breaks, routinely", and on 4 October 2026: "Hard rule: no breaking bars".)
    const cycle=cycleOf(bar,meter),bars=cycle?.map(each=>each.meter.numerator);
    // (A cycle's bars its groups, so that no note is written across their barlines.)
    if(cycle)meter={...meter,groups:bars};
    measures.push({index:bar-firstBar,bar,number:bar+1,start:startOf(bar),length:barLength(bar),meter,planned:!known.has(bar),...(cycle?{cycle}:{}),
      breaks:[],
      meterChanged:!previous||Boolean(cycle)||afterCycle||previous.numerator!==meter.numerator||previous.denominator!==meter.denominator||JSON.stringify(previous.metricReading)!==JSON.stringify(meter.metricReading)||(additiveSignatures&&(previous.groups||[]).join()!==(meter.groups||[]).join())});
  }
  const measureAt=time=>{let low=0,high=measures.length-1,found=0;while(low<=high){const middle=(low+high)>>1;if(measures[middle].start.le(time)){found=middle;low=middle+1}else high=middle-1}return measures[found]};
  // ---- what is known: the live score has heard the bots up to a tick (options.knownUntil, the first tick not yet
  // heard). From the pulse that tick is in, the time no note fills is left blank -- a rest there would tell a performer
  // the bots are about to fall silent, when nobody knows yet. A render of a finished performance has no horizon.
  let horizon=null;
  const heardBar=options.knownUntil!=null?transcript.barAt(options.knownUntil):null;
  if(heardBar){
    const perBeat=heardBar.meter.subdivision||DEFAULT_SUBDIVISION,into=options.knownUntil-heardBar.tick;
    const pulse=into>=heardBar.meter.numerator*perBeat?null:pulsesOf(heardBar.meter).filter(([at])=>at*perBeat<=into).at(-1)?.[0]??0;
    horizon=pulse==null?startOf(heardBar.bar+1):startOf(heardBar.bar).add(pulseWholes(heardBar.meter).mul(pulse));
  }
  // A measure spelled: a hypermetrical cycle's bars each spelled as a bar of its own -- its meter, its length -- a value
  // crossing one of their bar lines tied over it, so that no written value nor tuplet crosses them, as none crosses a
  // bar line (Op. 3.29's 13/10 at a quarter of 38: a cycle's 2/10 bar had been written a half note, the 3/10 after it
  // nothing, its tuplets nested across them); else whole. -> {elements} (their times the measure's).
  const spellIn=(measure,events)=>{
    // (A measure all rest one measure rest, cycle or not; a bar of a cycle all rest beside others, rests of its values.)
    if(!measure.cycle?.length||!events.some(event=>event.content!=null))return spellMeasure({meter:measure.meter,length:measure.length,breaks:measure.breaks,events});
    const later=(a,b)=>a.gt(b)?a:b,earlier=(a,b)=>a.lt(b)?a:b,elements=[];
    for(const bar of measure.cycle){
      const from=bar.offset,to=bar.offset.add(bar.length),shift=time=>time.add(from);
      const inside=events.filter(event=>event.end.gt(from)&&event.start.lt(to)).map(event=>{
        const start=later(event.start,from),end=earlier(event.end,to),content=event.content&&typeof event.content==='object'&&(start.gt(event.start)||end.lt(event.end))
          ?{...event.content,...(start.gt(event.start)?{continued:true}:{}),...(end.lt(event.end)?{continues:true}:{})}:event.content;
        return {...event,start:start.sub(from),end:end.sub(from),content};
      });
      for(const element of spellMeasure({meter:bar.meter,length:bar.length,breaks:[],events:inside,measureRest:false}).elements)
        elements.push({...element,start:shift(element.start),end:shift(element.end),
          tuplets:(element.tuplets??[]).map(tuplet=>({...tuplet,id:`${from}+${tuplet.id}`,...(tuplet.span?{span:{start:shift(tuplet.span.start),end:shift(tuplet.span.end)}}:{})}))});
    }
    return {elements};
  };
  const unknownIn=(events,measure)=>{
    const from=horizon.sub(measure.start);if(from.ge(measure.length))return [];
    const gaps=[];let cursor=from.sign()>0?from:R(0);
    for(const event of events){if(event.start.gt(cursor))gaps.push({start:cursor,end:event.start,content:null,hidden:true});if(event.end.gt(cursor))cursor=event.end}
    if(cursor.lt(measure.length))gaps.push({start:cursor,end:measure.length,content:null,hidden:true});
    return gaps;
  };
  // ---- the key ---------------------------------------------------------------------------------------------------
  const key=options.key??estimateKey(notes.filter(note=>!note.percussion).map(note=>({pitch:note.pitch,weight:Math.max(KEY_WEIGHT_FLOOR,ringsTo(note)-note.start.toNumber())})));
  // ---- parts -----------------------------------------------------------------------------------------------------
  // A part for each voice with notes in the window; and, for a view that follows a performance window by window (the
  // live score, the projection's lines), one for each voice in options.voices even where it is silent in the window,
  // its staves and clefs decided by options.ranges (voice -> {low, high, median, percussion}: what it has played so
  // far), so that a part keeps its staves from one window to the next.
  // A section's players by desk (`desks`: the owner, 1 October 2026: "a way ... to render two strings per staff, maybe
  // one stems up one stems down (just as two string players usually share a stand)"): each desk's two seats one part on
  // one staff, the outside player's line (the odd chair) stems up and the inside player's down, in their instrument's
  // clef -- the conductor's score at a desk's detail, between a staff a player and a section folded (sections: summary).
  const desks=new Map;
  if(options.desks)for(const note of notes){
    const seat=typeof note.line==='string'&&/^(vn1|vn2|va|vc|cb)\.(\d+)$/.exec(note.line);if(!seat)continue;
    const id=`desk:${seat[1]}.${Math.ceil(Number(seat[2])/2)}`,desk=desks.get(id)??desks.set(id,{seats:new Set,voices:new Set}).get(id);
    desk.seats.add(note.line);desk.voices.add(note.voice);note.voice=id;
  }
  for(const desk of desks.values()){
    desk.seats=[...desk.seats].sort((a,b)=>Number(a.split('.')[1])-Number(b.split('.')[1]));
    const [first]=desk.voices,info=transcript.voices.get(first)??{},chairs=desk.seats.map(seat=>seat.split('.')[1]);
    // (Named as its players are, "Vln. I 3" and "Vln. I 4" making "Vln. I 3–4".)
    desk.info={...info,label:info.label&&desk.seats.length>1?`${info.label.replace(/\s*\d+$/,'')} ${chairs[0]}–${chairs.at(-1)}`:info.label};
  }
  // Its sections condensed where they do not divide (the owner, 5 October 2026: "allow the score, when rendering
  // NON-DIVISI strings, to condense them to a smaller number of staves as per a more typical score" -- "This will vary
  // from system to system"): by desks, a section's bar in which every player of it who plays plays alike (as a desk's
  // unison is read: the same onsets, each pitch within its players' own few cents) written once, on a staff of the
  // section's own, its desks resting there; where it divides, on its desks -- each system showing the staves it needs,
  // the engraver leaving out a staff resting through a system (lilypond.js, its first system too: `condensed`).
  const condensedSections=new Map;
  if(options.desks&&options.condense!==false){
    const bars=new Map;
    for(const note of notes){const seat=typeof note.line==='string'&&/^(vn1|vn2|va|vc|cb)\.(\d+)$/.exec(note.line);if(!seat||!desks.has(note.voice))continue;
      const key=`${seat[1]}|${note.bar}`,lines=bars.get(key)??bars.set(key,new Map).get(key);(lines.get(note.line)??lines.set(note.line,[]).get(note.line)).push(note)}
    const dropped=new Set;
    for(const [key,lines] of bars){
      if(lines.size<2)continue;
      const [section]=key.split('|'),ordered=[...lines.entries()].sort(([a],[b])=>Number(a.split('.')[1])-Number(b.split('.')[1])).map(([,line])=>line.sort((x,y)=>x.start.cmp(y.start)||x.pitch-y.pitch));
      // (Only where it saves staves: its players on two desks or more; a desk alone writes its own unison, "unis.".)
      if(new Set(ordered.map(line=>line[0].voice)).size<2)continue;
      const [first,...rest]=ordered;
      if(!rest.every(line=>line.length===first.length&&line.every((note,k)=>note.start.eq(first[k].start)&&Math.abs(note.pitch-first[k].pitch)<=DESK_UNISON)))continue;
      const id=`section:${section}`;
      if(!condensedSections.has(id)){const desk=desks.get(first[0].voice),info=desk?.info??{};condensedSections.set(id,{info:{...info,label:info.label?info.label.replace(/\s*\d+[–-]?\d*$/,''):info.label},order:[...(desk?.voices??[first[0].voice])].sort((x,y)=>x.localeCompare(y,undefined,{numeric:true}))[0]})}
      for(const note of first)note.voice=id;for(const line of rest)for(const note of line)dropped.add(note);
    }
    for(let k=notes.length-1;k>=0;k--)if(dropped.has(notes[k]))notes.splice(k,1);
  }
  const byVoice=new Map;for(const note of notes)(byVoice.get(note.voice)||byVoice.set(note.voice,[]).get(note.voice)).push(note);
  for(const voice of options.voices??[])if(!byVoice.has(voice))byVoice.set(voice,[]);
  const voiceInfo=id=>desks.get(id)?.info??condensedSections.get(id)?.info??transcript.voices.get(id)??{};
  // (A desk in its first player's place among the parts; a section's condensed staff in its first desk's, above it.)
  const orderOf=id=>desks.has(id)?[...desks.get(id).voices].sort((a,b)=>a.localeCompare(b,undefined,{numeric:true}))[0]:condensedSections.has(id)?condensedSections.get(id).order:id;
  // A public render's score shows only the parts its audience hears: a bot whose output makes no sound in it (none, or
  // MIDI sent elsewhere) has no part.
  if((options.audience??transcript.source?.audience)==='public')for(const voice of [...byVoice.keys()])if(!HEARD_OUTPUTS.has(voiceInfo(voice).output))byVoice.delete(voice);
  const partIds=[...byVoice.keys()].sort((a,b)=>{
    const oa=orchestralPlace(voiceInfo(a)),ob=orchestralPlace(voiceInfo(b));
    if(oa!==null||ob!==null)return oa===null?1:ob===null?-1:oa-ob||orderOf(a).localeCompare(orderOf(b),undefined,{numeric:true})||condensedSections.has(b)-condensedSections.has(a);
    const ca=ORDER.indexOf(voiceInfo(a).bot?.category??''),cb=ORDER.indexOf(voiceInfo(b).bot?.category??'');
    return (ca<0?UNORDERED:ca)-(cb<0?UNORDERED:cb)||orderOf(a).localeCompare(orderOf(b),undefined,{numeric:true});
  });
  const names=new Map,linesOf=new Map;
  for(const note of transcript.notes)if(typeof note.line==='string')(linesOf.get(note.voice)??linesOf.set(note.voice,new Set).get(note.voice)).add(note.line);
  // A part's range where the view follows what it has played (options.ranges, by the players' voices): a desk's its
  // players' together, a condensed section's its desks' players' -- without it a desk's clef was chosen by the window's
  // notes alone, and the live line's bars, each engraved alone, changed clef from bar to bar (Op. 3.36's desks: 23
  // times in 28 s, each a bar ahead engraved again).
  const playersOf=voiceId=>desks.get(voiceId)?.voices??(condensedSections.has(voiceId)?[...desks.values()].filter(desk=>desk.seats.some(seat=>`section:${seat.split('.')[0]}`===voiceId)).flatMap(desk=>[...desk.voices]):null);
  const rangeOf=voiceId=>{
    const players=playersOf(voiceId);if(!players)return options.ranges?.get(voiceId)??null;
    const each=[...players].map(voice=>options.ranges?.get(voice)).filter(Boolean);if(!each.length)return null;
    const pitches=each.flatMap(range=>range.pitches??[]).sort((a,b)=>a-b);
    return {low:Math.min(...each.map(range=>range.low)),high:Math.max(...each.map(range=>range.high)),median:pitches[Math.floor(pitches.length/2)],pitches,
      percussion:each.every(range=>range.percussion),monophonic:each.every(range=>range.monophonic)};
  };
  const parts=partIds.map((voiceId,index)=>{
    const own=byVoice.get(voiceId).sort((a,b)=>a.start.cmp(b.start)||b.pitch-a.pitch),bot=voiceInfo(voiceId).bot??{},range=rangeOf(voiceId);
    // A public render names a part for its audience (its voice's label: what it does in the music); otherwise it is the
    // bot's name.
    const label=voiceInfo(voiceId).label??null;
    let name=label??bot.name??voiceId;const count=(names.get(name)??0)+1;names.set(name,count);if(count>1)name=`${name} ${count}`;
    const percussion=(range?range.percussion:own.length>0&&own.every(note=>note.percussion))||bot.pitchContract==='fixed-percussion';
    // (A desk's name is its players' abbreviations already, "Vln. II 11–12": kept as it is.)
    const part={id:`P${index+1}`,voice:voiceId,name,abbreviation:label&&(name.length<=ABBREVIATION_KEEPS||desks.has(voiceId)||condensedSections.has(voiceId))?name:abbreviate(name),bot,kind:percussion?'percussion':'pitched',measures:measures.map(()=>({voices:[],directions:[]})),
      // (A string section's staff or a desk's where its sections are condensed: shown in a system only where it plays.)
      ...(condensedSections.size&&(condensedSections.has(voiceId)||desks.has(voiceId))?{condensed:true}:{})};
    // (Its line, where every note of it names one: a section's seat, which a part's cues are chosen by: parts.js -- and
    // its instrument's clefs. Where the view follows what it has played, the lines its notes have named (its range's):
    // a window with none of its notes in it, a bar ahead, had read no seat, and a contrabass took a plain bass clef.)
    const seats=linesOf.get(voiceId)??(range?.lines?.length?new Set(range.lines):null);if(seats?.size===1)part.line=[...seats][0];
    const desk=desks.get(voiceId);if(desk){part.line=desk.seats[0];part.desk=desk.seats}
    // A sung line's words, syllable by syllable (lyrics.js), printed under its notes (decorate).
    if(!percussion&&own.some(note=>note.lyric)){lyricMarks(own);part.sung=true}
    // Divisi only for a bot that says its lines are a section's players (its definition's `section`): a bot's lines are
    // otherwise its own voices (modalline_clodbot's line, drone and mover), which it names so each glides apart.
    const lines=percussion||!bot.section?[]:divisiLines(own,range);
    if(percussion)layPercussion(part,own);else if(desk)layDesk(part,own,desk.seats,range);else if(lines.length)layDivisi(part,own,lines);else layPitched(part,own,range);
    return part;
  });
  // A folded section's formations, phrase by phrase, over its staff (section-summary.js).
  for(const word of formationWords){
    const part=parts.find(each=>each.voice===word.voice),bar=transcript.barAt(word.tick),index=measures.findIndex(measure=>measure.bar===bar?.bar);
    if(part&&index>=0)part.measures[index].directions.push({kind:'formation',start:measures[index].start,value:word.text,staff:1});
  }
  // A staff with nothing in a measure is blank past what is known, as a staff with notes is, not a measure rest (which
  // the MusicXML writer gives a staff with nothing at all).
  if(horizon)for(const part of parts)for(let staff=1;staff<=part.staves;staff++)measures.forEach((measure,index)=>{
    const content=part.measures[index];if(content.voices.some(voice=>voice.staff===staff))return;
    const unknown=unknownIn([],measure);if(!unknown.length)return;
    const spelled=spellIn(measure,unknown);
    content.voices.push({staff,voice:(staff-1)*VOICES_PER_STAFF+1,elements:spelled.elements.map(element=>decorate(part,element,measure))});
  });
  // ---- per part ---------------------------------------------------------------------------------------------------
  function beatOf(time){
    const measure=measureAt(time),weights=measure.meter.metricReading?.beatWeights;
    if(weights){
      // Use the declared beat for length spelling as well as beams. Beyond the last written bar, repeat its
      // geometry so a note ending at a cycle boundary does not acquire a zero-length terminal beat.
      const cycle=R(measure.meter.numerator,measure.meter.denominator),occurrence=time.sub(measure.start).div(cycle).floor();
      let start=measure.start.add(cycle.mul(occurrence));
      for(const size of weights){
        const length=R(size,measure.meter.denominator);
        if(time.lt(start.add(length)))return {start,length};
        start=start.add(length);
      }
    }
    const beat=R(measure.meter.pulse??1,measure.meter.denominator),index=time.sub(measure.start).div(beat).floor();
    return {start:measure.start.add(beat.mul(index)),length:beat};
  }
  // Written length belongs to the authored interval. Legato, ring and breath timing are performance data.
  function writtenEnd(note){return note.start.add(note.duration)}
  // Ledger lines cost as the octave signs weigh them (pain); each pitch spelled once however often it sounds.
  function ledgerCost(pitches,lines){
    const counts=new Map;for(const pitch of pitches)counts.set(pitch,(counts.get(pitch)??0)+1);
    let cost=0;for(const [pitch,count] of counts)cost+=count*pain(ledgersOn(stepOf(spellPitch(pitch,{fifths:key.fifths})),lines));
    return cost;
  }
  function layPitched(part,own,range=null){
    // (What the part has played so far where the view follows it -- else the window's notes.)
    const pitches=range?.pitches??own.map(note=>note.pitch).sort((a,b)=>a-b);
    const low=range?.low??pitches[0],high=range?.high??pitches.at(-1),median=range?.median??pitches[Math.floor(pitches.length/2)];
    // (An orchestra's single-line instrument reads one staff, a section's string player in its instrument's clefs.)
    const strings=STRING_CLEFS[SEAT_INSTRUMENT[String(part.line??'').split('.')[0]]];
    const grand=part.bot?.hands>=KEYBOARD_HANDS||!strings&&!part.bot?.orchestral&&high-low>GRAND_STAFF_RANGE&&low<GRAND_STAFF_LOW&&high>GRAND_STAFF_HIGH;
    part.staves=grand?GRAND_STAVES:1;
    // One staff for a narrow part, the clef that reads its notes with the fewer ledger lines (by the median pitch where
    // the two read them alike); an octave clef where the part lives an octave or two above the treble staff or below the
    // bass (the notes are the same; the ledger lines are fewer).
    const treble=ledgerCost(pitches,TREBLE_STAFF_STEPS),bass=ledgerCost(pitches,BASS_STAFF_STEPS),upper=treble===bass?median>=TREBLE_FROM:treble<bass;
    const octave=median>=FIFTEENTH_CLEF_FROM?FIFTEENTH:median>=EIGHTH_CLEF_FROM?1:median<=EIGHTH_BASSO_TO?-1:0;
    part.clefs=grand?[{sign:'G',line:TREBLE_LINE},{sign:'F',line:BASS_LINE}]:strings?[{...strings.reduce((best,each)=>ledgerCost(pitches,each.steps)<ledgerCost(pitches,best.steps)?each:best).clef}]
      :upper?[{sign:'G',line:TREBLE_LINE,octave:Math.max(0,octave)}]:[{sign:'F',line:BASS_LINE,octave:Math.min(0,octave)}];
    // (One note at a time, by what the part has played so far where the view follows it -- else by the window's notes.)
    const struck=new Map;for(const note of own)struck.set(note.start.toString(),(struck.get(note.start.toString())??0)+1);
    const monophonic=range?.monophonic??oneAtATime([...struck.values()]);
    if(grand&&monophonic&&own.length&&options.acrossStaves!==false){layAcrossStaves(part,own);return}
    const staffOf=note=>grand?((note.sweptFrom??note).pitch>=MIDDLE_C?1:LOWER_STAFF):1;
    for(let staff=1;staff<=part.staves;staff++){
      const staffNotes=own.filter(note=>staffOf(note)===staff);if(!staffNotes.length)continue;
      for(const note of staffNotes)note.end=writtenEnd(note);
      assignVoices(part,staff,chordsOf(staffNotes),(staff-1)*VOICES_PER_STAFF);
    }
    // A glissando's last string, in its first's voice, written on the staff its pitch is read on (element.staff).
    if(grand)for(const content of part.measures)for(const voice of content.voices)for(const element of voice.elements){
      const swept=element.chord?.notes?.find(note=>note.sweptFrom);if(!swept)continue;
      const own=swept.pitch>=MIDDLE_C?1:LOWER_STAFF;if(own!==voice.staff)element.staff=own;
    }
  }
  // A section of lines (a bot whose definition says it is a section and names each note's line: mass_clodbot's eight),
  // written divisi as an orchestral section is (the backlog's "Divisi staves for a section": eight independent voices on
  // one staff are unreadable): its lines
  // from the highest to the lowest, two to a staff, the upper stems up and the lower down, as many staves as that takes,
  // bracketed as one part and marked "div. a N". Only where it has more lines than one staff holds (two); a part whose
  // notes name one or two lines, or none, is laid as before.
  // (Where the view follows what the part has played -- `range` -- its lines are all it has named, each placed by all it
  // has played in it: a window holding none of a line's notes, a bar ahead, had read fewer lines, the part one staff
  // there and four where it played, and its lines' order among the staves the window's.)
  function divisiLines(own,range=null){
    const byLine=new Map;for(const note of own)if(typeof note.line==='string')(byLine.get(note.line)||byLine.set(note.line,[]).get(note.line)).push(note);
    const heard=range?.pitchesByLine??null;if(heard)for(const line of Object.keys(heard))if(!byLine.has(line))byLine.set(line,[]);
    if(byLine.size<=DIVISI_PER_STAFF||own.some(note=>typeof note.line!=="string"))return [];
    const pitchesOf=(line,notes)=>heard?.[line]??notes.map(note=>note.pitch).sort((a,b)=>a-b);
    return [...byLine.entries()].map(([line,notes])=>{const pitches=pitchesOf(line,notes);return {line,notes,pitches,median:pitches[Math.floor(pitches.length/2)]}})
      .sort((a,b)=>b.median-a.median||a.line.localeCompare(b.line,undefined,{numeric:true}));
  }
  function layDivisi(part,own,lines){
    const staves=Math.ceil(lines.length/DIVISI_PER_STAFF);
    part.staves=staves;part.divisi=lines.length;part.clefs=[];
    if(measures.length)part.measures[0].directions.push({kind:'divisi',start:measures[0].start,value:divisiWords(lines.length),staff:1});
    for(let staff=1;staff<=staves;staff++){
      const mine=lines.slice((staff-1)*DIVISI_PER_STAFF,staff*DIVISI_PER_STAFF),pitches=mine.flatMap(line=>line.pitches).sort((a,b)=>a-b);
      // Each staff's clef by its own lines' median, as a single staff's is (layPitched).
      const median=pitches[Math.floor(pitches.length/2)],octave=median>=FIFTEENTH_CLEF_FROM?FIFTEENTH:median>=EIGHTH_CLEF_FROM?1:median<=EIGHTH_BASSO_TO?-1:0;
      part.clefs.push(median>=TREBLE_FROM?{sign:'G',line:TREBLE_LINE,octave:Math.max(0,octave)}:{sign:'F',line:BASS_LINE,octave:Math.min(0,octave)});
      mine.forEach((line,index)=>writeLine(part,staff,(staff-1)*VOICES_PER_STAFF+index+1,line.notes));
    }
  }
  // A line as one voice: each note as long as written, but to its line's next onset at most -- a player's note held on
  // under its next (a string sounding on beside the next one stopped) written to where the next begins, as a written
  // note's length is its onset to the next, whatever the bow held -- never a chord but the notes it strikes together,
  // which end together. (Its authored lengths had run on under the next note: a voice holding two notes at once, the bar
  // not written -- Op. 3.21's first cellos' bar 7, the next bar's note tied from nothing.)
  function writeLine(part,staff,voiceNumber,lineNotes){
    const notes=[...lineNotes].sort((a,b)=>a.start.cmp(b.start));
    for(const note of notes){note.staff=staff;note.end=writtenEnd(note)}
    for(let k=0;k<notes.length;){
      let j=k;while(j<notes.length&&notes[j].start.eq(notes[k].start))j++;
      const struck=notes.slice(k,j),next=notes[j]?.start,end=struck.reduce((last,note)=>note.end.gt(last)?note.end:last,struck[0].end);
      for(const note of struck)note.end=next&&end.gt(next)?next:end;
      k=j;
    }
    const chords=chordsOf(notes);
    writeVoice(part,staff,voiceNumber,chords);
  }
  // A desk's two players on one staff (`desks`): the outside player's line the upper voice, stems up, the inside
  // player's the lower, stems down, each its own player's notes, in their instrument's clef as one player's staff is.
  // Bar by bar, where its players play alike -- the same rhythm, each pitch within their own few cents of each other --
  // one voice, as a desk's unison is written; where they differ, the two; "div." where it divides and "unis." where it
  // comes together again, over the staff (the owner, 2 October 2026: "we should probably be providing 'divisi'
  // indications when this happens in the score too").
  // (Its clef by what its players have played so far where the view follows them -- `range` -- else by the window's notes.)
  function layDesk(part,own,seats,range=null){
    const strings=STRING_CLEFS[SEAT_INSTRUMENT[seats[0].split('.')[0]]],pitches=range?.pitches??own.map(note=>note.pitch);
    part.staves=1;part.clefs=[{...strings.reduce((best,each)=>ledgerCost(pitches,each.steps)<ledgerCost(pitches,best.steps)?each:best).clef}];
    const barOf=note=>measures.findIndex(measure=>note.start.ge(measure.start)&&note.start.lt(measure.start.add(measure.length)));
    const lines=seats.map(seat=>own.filter(note=>note.line===seat)),inBar=(line,bar)=>line.filter(note=>barOf(note)===bar);
    const alike=bar=>{
      if(lines.length<2)return true;
      const [a,b]=lines.map(line=>inBar(line,bar).sort((x,y)=>x.start.cmp(y.start)||x.pitch-y.pitch));
      // (Their onsets and pitches: a written note's length is its onset to the next, whatever each player's bow held.)
      return a.length===b.length&&a.every((note,k)=>note.start.eq(b[k].start)&&Math.abs(note.pitch-b[k].pitch)<=DESK_UNISON);
    };
    const together=measures.map((_,bar)=>alike(bar));
    lines.forEach((line,index)=>{const notes=index?line.filter(note=>!together[barOf(note)]):line;if(notes.length)writeLine(part,1,index+1,notes)});
    if(lines.length<2)return;
    let divided=false;
    part.measures.forEach((content,bar)=>{
      const sounding=lines.some(line=>inBar(line,bar).length);if(!sounding)return;
      const now=!together[bar];if(now===divided)return;divided=now;
      const first=content.voices.filter(voice=>!voice.filler).flatMap(voice=>voice.elements).filter(element=>!element.rest).sort((x,y)=>x.start.cmp(y.start))[0];
      if(first)first.divisiText=now?DIVISI_WORDS.divided:DIVISI_WORDS.together;
    });
  }
  // A line of single notes on a grand staff, as an engraver writes a wide-ranging melody: one voice, written to its own
  // rhythm (each note to the next, whichever staff it is on), moving between the staves -- its beams crossing them --
  // each note on the staff placeOnStaves chooses, each rest on the staff the line is on (its last note's; before its
  // first, its first's); a staff the line does not visit in a bar has a bar's rest there (blank where the bar is not all
  // known: the line may yet come).
  function layAcrossStaves(part,own){
    part.acrossStaves=true;
    for(const note of own)note.end=writtenEnd(note);
    const chords=chordsOf(own);placeOnStaves(chords);
    assignVoices(part,1,chords,0);
    const bars=part.measures.map(content=>content.voices.flatMap(voice=>voice.elements));
    const line=part.measures.flatMap(content=>content.voices.flatMap(voice=>voice.elements));
    let staff=line.find(element=>!element.rest)?.chord.staff??1;
    for(const element of line){if(!element.rest)staff=element.chord.staff;element.staff=staff}
    // Each note's stem: in a figure beamed across the staves, towards its beam between them (the upper staff's down, the
    // lower's up); elsewhere as on a staff of one voice -- away from the note furthest from the middle line (down where
    // it stands above, or as far above as below), a beamed figure's all one way. (element.stem, 'up' or 'down'.)
    for(const elements of bars){
      const groups=beamGroups(elements),beamed=new Set(groups.flat());
      for(const group of [...groups,...elements.filter(element=>!beamed.has(element)).map(element=>[element])]){
        const notes=group.filter(element=>!element.rest&&element.notes?.length);if(!notes.length)continue;
        if(new Set(notes.map(element=>element.staff)).size>1){for(const element of notes)element.stem=element.staff===1?'down':'up';continue}
        const [bottom,top]=notes[0].staff===1?TREBLE_STAFF_STEPS:BASS_STAFF_STEPS,middle=(bottom+top)/2;
        const offsets=notes.flatMap(element=>element.notes.map(note=>stepOf(spellPitch(note.pitch,{fifths:key.fifths}))-middle));
        const stem=Math.max(...offsets)>=-Math.min(...offsets)?'down':'up';for(const element of notes)element.stem=stem;
      }
    }
    part.measures.forEach((content,index)=>{
      const measure=measures[index],elements=content.voices.flatMap(voice=>voice.elements),visited=new Set(elements.map(element=>element.staff)),unknown=elements.some(element=>element.hidden);
      for(let staff=1;staff<=GRAND_STAVES;staff++)if(!visited.has(staff))content.voices.push({staff,voice:staff===1?FILLER_VOICE:(staff-1)*VOICES_PER_STAFF+1,filler:true,
        elements:[{start:measure.start,end:measure.start.add(measure.length),rest:true,measureRest:true,hidden:unknown,staff,measure:index,tuplets:[],beams:[],tupletStarts:[],tupletStops:[]}]});
    });
  }
  // Each chord of a line moving between a grand staff's staves on the staff that reads it with the fewer ledger lines,
  // the line changing staff where that saves more than a change costs -- a change costs STAFF_CHANGE, a note off its own
  // staff (middle C and up the upper) OFF_STAFF -- the cheapest writing of the whole line (a shortest path, as octave
  // signs are chosen). (chord.staff: 1 the upper, 2 the lower.)
  function placeOnStaves(chords){
    const at=chords.map(chord=>[1,LOWER_STAFF].map(staff=>staffCost(chord,staff)));
    const cost=[at[0]],back=[[0,1]];
    for(let k=1;k<chords.length;k++){
      const previous=cost[k-1],row=[],from=[];
      for(let staff=0;staff<GRAND_STAVES;staff++){
        const stay=previous[staff],move=previous[1-staff]+STAFF_CHANGE;
        row.push(at[k][staff]+Math.min(stay,move));from.push(stay<=move?staff:1-staff);
      }
      cost.push(row);back.push(from);
    }
    let staff=cost.at(-1)[0]<=cost.at(-1)[1]?0:1;
    for(let k=chords.length-1;k>=0;k--){chords[k].staff=staff+1;staff=back[k][staff]}
  }
  // What a chord costs on a grand staff's staff (1 the upper, 2 the lower): the ledger lines its furthest note needs
  // there, and OFF_STAFF off its own staff (middle C and up the upper).
  function staffCost(chord,staff){
    const lines=staff===1?TREBLE_STAFF_STEPS:BASS_STAFF_STEPS,own=Math.max(...chord.notes.map(note=>note.pitch))>=MIDDLE_C?1:LOWER_STAFF;
    return Math.max(...chord.notes.map(note=>ledgersOn(stepOf(spellPitch(note.pitch,{fifths:key.fifths})),lines)))+(staff===own?0:OFF_STAFF);
  }
  // A voice's elements grouped by their beams: each run from the element a beam begins at to the one it ends at.
  function beamGroups(elements){
    const groups=[];let open=null;
    for(const element of elements){
      const beam=(element.beams??[]).find(each=>each.number===1)?.value;
      if(beam==='begin')open=[];
      if(open)open.push(element);
      if(beam==='end'&&open){groups.push(open);open=null}
    }
    return groups;
  }
  function layPercussion(part,own){
    part.staves=1;part.clefs=[{sign:'percussion',line:PERCUSSION_LINE}];part.instruments=new Map;
    for(const note of own){
      for(const event of [note,...(note.graces??[])]){const drum=drumOf(event.percussion?.note??DEFAULT_DRUM);event.drum=drum;part.instruments.set(event.percussion?.note??DEFAULT_DRUM,drum)}
    }
    for(const voiceNumber of [1,FEET_VOICE]){
      const lane=own.filter(note=>(note.drum.voice??1)===voiceNumber);if(!lane.length)continue;
      const starts=[...new Set(lane.map(note=>note.start.toString()))].map(value=>Rational.of(value)).sort((a,b)=>a.cmp(b));
      const scoreEnd=measures.at(-1).start.add(measures.at(-1).length);
      for(const note of lane){
        note.end=writtenEnd(note);
        if(note.percussion?.rolled)note.rolled=true;
      }
      writeVoice(part,1,voiceNumber,chordsOf(lane));
    }
  }
  function chordsOf(staffNotes){
    const chords=new Map;
    for(const note of staffNotes){const key=`${note.start}|${note.end}|${note.continuedIn?1:0}`;(chords.get(key)||chords.set(key,{start:note.start,end:note.end,notes:[],continuedIn:Boolean(note.continuedIn)}).get(key)).notes.push(note)}
    return [...chords.values()].sort((a,b)=>a.start.cmp(b.start)||Math.max(...b.notes.map(n=>n.pitch))-Math.max(...a.notes.map(n=>n.pitch)));
  }
  function assignVoices(part,staff,chords,base){
    const voices=[];
    for(const chord of chords){
      const top=Math.max(...chord.notes.map(note=>note.pitch)),free=voices.filter(voice=>voice.end.le(chord.start));
      // (A glissando's last string goes on in the voice its first is in: the line joins them.)
      const swept=chord.notes.find(note=>note.sweptFrom)?.sweptFrom;
      let voice=swept?free.find(each=>each.chords.at(-1)?.notes.includes(swept)):undefined;
      if(!voice&&free.length)voice=free.sort((a,b)=>Math.abs(a.pitch-top)-Math.abs(b.pitch-top)||a.index-b.index)[0];
      else if(!voice&&voices.length<maxVoices){voice={index:voices.length,chords:[],end:chord.start,pitch:top};voices.push(voice)}
      else if(!voice){
        // A layout capacity is not permission to shorten the composition. Retain another voice and report it.
        voice={index:voices.length,chords:[],end:chord.start,pitch:top};voices.push(voice);
        warnings.push(`${part.name}: more than ${maxVoices} overlapping lines at ${chord.start}; additional staff layout is needed`);
      }
      voice.chords.push(chord);voice.end=chord.end;voice.pitch=top;
    }
    voices.sort((a,b)=>a.index-b.index);
    for(const voice of voices){
      writeVoice(part,staff,base+voice.index+1,voice.chords);
    }
  }
  // A voice's chords, cut at the barlines and written measure by measure.
  function writeVoice(part,staff,voiceNumber,chords){
    const perMeasure=measures.map(()=>[]);
    for(const chord of chords){
      // A note sounding past the window goes on in the next, tied into it; past the performance's end (`closes`) there
      // is no next bar, so it ends at the final barline, never tied to nothing (the owner, 30 September 2026: season 2's
      // "ties into the final barline").
      if(chord.end.gt(windowEnd)){chord.end=windowEnd;if(!closes)chord.continuesOut=true}
      let from=chord.start;
      while(from.lt(chord.end)){
        const measure=measureAt(from),measureEnd=measure.start.add(measure.length),to=chord.end.lt(measureEnd)?chord.end:measureEnd;
        perMeasure[measure.index].push({start:from.sub(measure.start),end:to.sub(measure.start),
          content:{chord,continued:from.gt(chord.start)||Boolean(chord.continuedIn),continues:to.lt(chord.end)||Boolean(chord.continuesOut)&&to.eq(chord.end)}});
        if(to.le(from))break;from=to;
      }
    }
    perMeasure.forEach((events,index)=>{
      const measure=measures[index],isFirst=voiceNumber===(staff-1)*VOICES_PER_STAFF+1||part.kind==='percussion'&&voiceNumber===1;
      if(!events.length&&!isFirst)return;
      const unknown=horizon?unknownIn(events,measure):[];
      let spelled;
      try{spelled=spellIn(measure,unknown.length?[...events,...unknown].sort((a,b)=>a.start.cmp(b.start)):events)}
      catch(error){warnings.push(`${part.name}, measure ${measure.number}: ${error.message}`);return}
      part.measures[index].voices.push({staff,voice:voiceNumber,elements:spelled.elements.map(element=>decorate(part,element,measure))});
    });
  }
  function decorate(part,element,measure){
    const out={...element,start:measure.start.add(element.start),end:measure.start.add(element.end),measure:measure.index};
    if(element.rest)return out;
    const {chord,continued,continues}=element.content;out.chord=chord;
    const firstPiece=!continued&&element.first,lastPiece=!continues&&element.last;
    out.tieStart=element.tieStart||(continues&&element.last);out.tieStop=element.tieStop||(continued&&element.first);
    out.notes=chord.notes.map(note=>{
      const written={pitch:note.pitch,velocity:note.velocity,...(note.written?{dynamic:{...note.written}}:{})};
      if(part.kind==='percussion')Object.assign(written,{unpitched:{step:note.drum.step,octave:note.drum.octave},notehead:note.drum.notehead??null,open:note.drum.open??false,instrument:note.percussion?.note??DEFAULT_DRUM,...(note.rolled?{rolled:true}:{})});
      else written.spelled=spellPitch(note.pitch,{fifths:key.fifths});
      // (A pitched roll -- a timpanist's, its recorded roll: audio.js roll -- as a tremolo, as a percussion roll is.)
      if(part.kind!=='percussion'&&note.technique==='tremolo')written.rolled=true;
      const graces=placement=>(note.graces??[]).filter(grace=>grace.placement===placement).map(grace=>({...grace,
        ...(part.kind==='percussion'?{unpitched:{step:grace.drum.step,octave:grace.drum.octave},instrument:grace.percussion?.note??DEFAULT_DRUM,notehead:grace.drum.notehead}
          :graceOf(grace.pitch,key))}));
      // What sounded, against what is written: the onset's deviation (free or near timing, a strum) on the first piece,
      // the release on the last.
      if(firstPiece){
        const before=graces('before');if(before.length)written.gracesBefore=before;
        const seconds=(note.deviation||0)+(note.strum||0);
        if(Math.abs(seconds)>NO_DEVIATION)written.attackWhole=seconds*note.secondsToWhole;
        if(options.timingMarks&&Math.abs(note.deviation||0)>=TIMING_PRINTED)written.timingText=`${note.deviation>0?'+':'−'}${Math.round(Math.abs(note.deviation)*MS_PER_SECOND)} ms`;
        if(note.sung)written.lyric=note.sung;
        if(note.technique)written.technique=note.technique;if(note.contact)written.contact=note.contact;if(note.bowPressure)written.bowPressure=note.bowPressure;
        if(note.harmonic)written.harmonic={...note.harmonic};if(note.extended)written.extended={...note.extended};
        // (A string's multiphonic with where it is touched, spelled: its diamond, lilypond.js.)
        if(note.multiphonic)written.multiphonic={...note.multiphonic,...(Number.isFinite(note.multiphonic.touch)?{touchSpelled:graceOf(note.multiphonic.touch,key)}:{})};
        if(note.slurred)written.slurred=true;if(note.portato)written.portato=true;if(note.phrased)written.phrased=true;
        if(note.fingering)written.fingering=note.fingering;if(note.fingered)written.fingered=note.fingered;
        const pedal=(note.pedalMarks??[]).filter(mark=>!mark.after);if(pedal.length)written.pedal=pedal;
        // A glide into it: the pitch it slid from, and the slide from the note it slid from, which ends here.
        if(part.kind!=='percussion'&&note.glideFrom!=null){written.glideFrom=note.glideFrom;if(note.slideFrom)written.slideStop=note.slideFrom;if(note.glissando)written.glissando=true}
        // (Or the end of a glissando through the note before, which arrives here.)
        else if(part.kind!=='percussion'&&note.glissIn&&note.slideFrom){written.slideStop=note.slideFrom;written.glissando=true}
      }
      if(lastPiece){
        const ornaments=graces('after');if(ornaments.length)written.gracesAfter=ornaments;
        // (Its release, where a performance is read: how long it sounded against its written end.)
        if(Number.isFinite(note.sounded))written.releaseWhole=note.start.toNumber()+note.sounded*note.secondsToWhole-chord.end.toNumber();
        // Articulation is told independently of its duration; no acoustic gate is a written note value.
        if(note.staccato)written.staccato=true;
        if(note.breathAfter)written.breathMark=true;
        const after=(note.pedalMarks??[]).filter(mark=>mark.after);if(after.length)written.pedalAfter=after;
        // A glide out of it: the slide to the note that glided from it begins here.
        if(part.kind!=='percussion'&&note.slideTo){written.slideStart=note.slideTo;if(note.glissando)written.glissando=true;if(note.glissTo!=null)written.glissTo=note.glissTo}
        // A glissando through it with a rest after: its line to a grace note at where it ends.
        if(part.kind!=='percussion'&&note.graceTo!=null){written.graceTo=graceOf(note.graceTo,key);written.glissando=true}
      }
      return written;
    });
    // The composer asks for a rolled chord. Attack spacing, hammer travel and pedal-setting delays cannot add or
    // remove its sign, even when the performed roll compresses to simultaneous attacks.
    out.arpeggiate=part.kind!=='percussion'&&firstPiece&&chord.notes.length>1&&chord.notes.some(note=>note.arpeggiate);
    return out;
  }
  // ---- glides, as written: a slide joins two notes the score writes one after the other in one voice (a line: an
  // engraver's slide, LilyPond's glissando, reaches the voice's next note). A glide whose two notes it writes apart --
  // in two voices or staves -- and a glide from a pitch no note in the window was written at, are slid into from a grace
  // note at the pitch they slid from (graceFrom: one a chord, its highest note's).
  for(const part of parts){
    if(part.kind==='percussion')continue;
    const byVoice=new Map,joined=new Set;
    for(const content of part.measures)for(const voice of content.voices)(byVoice.get(voice.voice)||byVoice.set(voice.voice,[]).get(voice.voice)).push(...voice.elements.filter(element=>!element.rest&&!element.hidden));
    for(const elements of byVoice.values())elements.forEach((element,index)=>{
      for(const note of element.notes)if(note.slideStart!=null){
        if(elements[index+1]?.notes.some(other=>other.slideStop===note.slideStart))joined.add(note.slideStart);
        else{
          // (A glissando through the note whose next note is written apart: its line to a grace note where it ends.)
          if(note.glissando&&note.glissTo!=null)note.graceTo=graceOf(note.glissTo,key);
          delete note.slideStart;
        }
      }
    });
    for(const elements of byVoice.values())for(const element of elements){
      for(const note of element.notes)if(note.slideStop!=null&&!joined.has(note.slideStop))delete note.slideStop;
      const grace=element.notes.filter(note=>note.glideFrom!=null&&note.slideStop==null).sort((a,b)=>b.pitch-a.pitch)[0];
      if(grace)grace.graceFrom=graceOf(grace.glideFrom,key);
    }
  }
  // ---- accidentals and marks, measure by measure --------------------------------------------------------------------
  for(const part of parts){
    if(part.kind==='percussion')continue;
    part.measures.forEach(measure=>{
      for(let staff=1;staff<=part.staves;staff++){
        // (A note's staff is its own where a line moves between the staves, else its voice's.)
        const state=new Map,elements=measure.voices.flatMap(voice=>voice.elements.filter(element=>(element.staff??voice.staff)===staff)).filter(element=>!element.rest).sort((a,b)=>a.start.cmp(b.start));
        for(const element of elements)for(const note of element.notes){
          const spelled=note.spelled,where=`${spelled.step}${spelled.octave}`;
          // A note inflected by cents shows its accidental, a natural too, and its cents with it: the cents are read
          // from it. Like an accidental, the inflection holds to the barline at its place on the staff, so a note struck
          // again there with the same cents shows neither (an engraver prints neither twice: a chord repeated in quavers
          // was a column of labels each time, and the score a third longer); one with other cents, or another
          // accidental, shows its own. (A grace note slid from comes before it, and is read as any note is.)
          const inflection=s=>`${s.display}|${centsLabel(s.cents)??''}`,unmarked=step=>`${keyAlteration(step,key.fifths)}|`;
          const markGrace=grace=>{const s=grace.spelled,at=`${s.step}${s.octave}`,before=state.has(at)?state.get(at):unmarked(s.step);
            grace.accidentalShown=inflection(s)!==before;state.set(at,inflection(s))};
          for(const grace of [...(note.gracesBefore??[]),...(note.graceFrom?[note.graceFrom]:[])])markGrace(grace);
          const current=state.has(where)?state.get(where):unmarked(spelled.step);
          note.accidentalShown=!element.tieStop&&inflection(spelled)!==current;
          // (A tie carries its accidental across the barline for the tied note only: the same note struck again later in
          // the bar shows it again, its cents with it, as engravers print it; the owner, 1 October 2026: "it's ambiguous
          // here whether the second B-flat takes the cents modification".)
          if(!element.tieStop)state.set(where,inflection(spelled));
          // (A string multiphonic's touched note, at its own place on the staff, as any note there: its accidental and cents
          // the first time in the bar -- restated on each of Op. 3.34's repeated harmonics, they had widened a bar by half.)
          const touch=note.multiphonic?.touchSpelled;if(touch&&!element.tieStop)markGrace(touch);
          for(const grace of note.gracesAfter??[])markGrace(grace);
        }
      }
    });
  }
  // ---- expression, read as an engraver reads a performance: dynamics, hairpins, accents, articulation, slurs --------
  //   dynamics   at the head of each phrase (notes less than a beat of silence apart), and where the level changes
  //              and holds for three notes; the level of a note is its velocity's (DYNAMICS)
  //   hairpins   a crescendo or decrescendo where a phrase grows or fades a dynamic step or more over three notes or
  //              more, a beat or longer, ending at the dynamic it reaches
  //   accents    a note louder than the notes around it (a beat either side, not those struck with it; a drum against
  //              its own instrument) by a dynamic step: an accent; by two: a marcato
  //   staccato   explicitly authored articulation; an acoustic gate cannot supply it or its written length
  //   slurs      over a legato run (each note sounding into the next) in a line of one voice; where its player says
  //              how it bowed (a section's player: capture.js technique, slurred), over each run it slurred, in
  //              every voice, and nowhere else
  //   technique  pizz. and arco where a staff's playing changes (a staff that begins plucked says so)
  for(const part of parts){
    const percussion=part.kind==='percussion',events=[];
    part.measures.forEach((measure,index)=>{for(const voice of measure.voices)for(const element of voice.elements)
      if(!element.rest&&!element.hidden&&!element.tieStop&&element.notes?.length&&!element.slash)
        events.push({element,measure:index,voice,staff:voice.staff,velocity:Math.max(...element.notes.map(note=>note.velocity??DEFAULT_VELOCITY)),
          // (Its written dynamic's level, where every note of it was written one: the louder's, as its velocity is.)
          planned:element.notes.every(note=>note.dynamic)?Math.max(...element.notes.map(note=>note.dynamic.velocity)):null,
          plannedMark:element.notes.every(note=>note.dynamic)?element.notes.reduce((a,b)=>b.dynamic.velocity>a.dynamic.velocity?b:a).dynamic.mark:null,instrument:element.notes[0].instrument??null})});
    events.sort((a,b)=>a.element.start.cmp(b.element.start)||b.velocity-a.velocity);
    if(!events.length)continue;
    const time=event=>event.element.start.toNumber(),beatLength=event=>beatOf(event.element.start).length.toNumber();
    // Accents: against the three notes either side in its own line (a drum's own instrument), not those struck with it.
    for(const [index,event] of events.entries()){
      const line=events.filter(other=>other.staff===event.staff&&(!percussion||other.instrument===event.instrument)&&(other===event||!other.element.start.eq(event.element.start)));
      const at=line.indexOf(event),around=[...line.slice(Math.max(0,at-ACCENT_NEIGHBOURS),at),...line.slice(at+1,at+1+ACCENT_NEIGHBOURS)].map(other=>other.velocity).sort((a,b)=>a-b);
      if(around.length<ACCENT_MIN_NEIGHBOURS)continue;
      const lift=event.velocity-around[Math.floor(around.length/2)];
      if(lift>=MARCATO_LIFT&&event.velocity>=MARCATO_VELOCITY)event.element.marcato=true;else if(lift>=ACCENT_LIFT&&event.velocity>=ACCENT_VELOCITY)event.element.accent=true;
    }
    // Phrases, per staff: a beat of silence ends one.
    const byStaff=new Map;for(const event of events)(byStaff.get(event.staff)||byStaff.set(event.staff,[]).get(event.staff)).push(event);
    for(const [staff,list] of byStaff){
      // An orchestral percussionist's instrument named where it takes one up ("S. D.", "Trgl."), once, as an orchestra's
      // percussion parts name theirs; its dynamics each instrument's own, from where it is taken up.
      const taken=new Set;
      if(percussion&&part.bot?.orchestral){
        let playing=null;
        for(const event of list){const names=new Set(event.element.notes.map(note=>PERCUSSION_INSTRUMENTS.get(note.instrument)).filter(Boolean));if(names.size!==1)continue;
          const [name]=names;if(name!==playing){event.element.techniqueText=name;taken.add(event);playing=name}}
      }
      const phrases=[];let phrase=[];
      for(const event of list){
        const previous=phrase.at(-1);
        if(previous&&(taken.has(event)||time(event)-previous.element.end.toNumber()>=beatLength(event)-SAME_TIME)){phrases.push(phrase);phrase=[]}
        phrase.push(event);
      }
      if(phrase.length)phrases.push(phrase);
      // (A window of a line already printed carries the line's last dynamic in: its head is marked only if it differs.)
      let printed=options.dynamicsBefore?.get(part.voice)?.get(staff)??null;
      const mark=(event,value)=>{part.measures[event.measure].directions.push({kind:'dynamics',value,start:event.element.start,staff});printed=value};
      const level=velocity=>markIndex(dynamicOf(velocity));
      // The line's loudness: as its players wrote it, where they wrote it (each note's written dynamic, section-seat.js
      // writtenAt: its phrase's planned level and swell, a held note's own softer level) -- never read back from how loudly
      // they played (the owner, 10 October 2026: "I suspect that something is erroneously trying to construct dynamics
      // from playing, rather than the other way around"); else, for a line no player wrote dynamics for (a recording, an
      // older render), its velocities smoothed (the median of nine notes around each, across its rests; notes struck
      // together count once): an accented note is an accent, not a new dynamic, and a motif between rests is not a new
      // level.
      const line=list.filter((event,index)=>index===0||!event.element.start.eq(list[index-1].element.start));
      const stretch=[];{let k=0;for(const event of line){if(taken.has(event))k++;stretch.push(k)}}
      const written=line.length>0&&line.every(event=>event.planned!=null);
      const smooth=written?line.map(event=>event.planned):line.map((_,index)=>{const slice=line.slice(Math.max(0,index-SMOOTHING_REACH),index+SMOOTHING_REACH+1).filter((_,k)=>stretch[Math.max(0,index-SMOOTHING_REACH)+k]===stretch[index]).map(event=>event.velocity).sort((a,b)=>a-b);return slice[Math.floor(slice.length/2)]});
      const phraseStart=new Set(phrases.map(notes=>notes[0]));
      // (As written: each written mark where it changes, and a hairpin only over a run of three notes or more, a beat or
      // more long, within a phrase, where the written level moves one way all through and its mark changes -- a phrase's
      // written swell.)
      const hairpinOf=(first,last,direction)=>{
        const struck=(event,voice)=>event.voice.voice===voice?event:list.find(other=>other.voice.voice===voice&&other.element.start.eq(event.element.start));
        const ends=struck(first,last.voice.voice)?[struck(first,last.voice.voice),last]:struck(last,first.voice.voice)?[first,struck(last,first.voice.voice)]:null;
        if(!ends)return false;
        const [a,b]=ends;a.element.hairpin=direction>0?'crescendo':'decrescendo';b.element.hairpinEnd=true;
        if(b.element.start.sub(a.element.start).gt(measures[a.measure].length.mul(WORDED_OVER_BARS)))a.element.hairpinText=true;
        return true;
      };
      if(written){
        let i=0;
        while(i<line.length){
          const here=line[i].plannedMark??dynamicOf(smooth[i]);
          if(here!==printed)mark(line[i],here);
          let j=i,direction=0;
          while(j+1<line.length&&!phraseStart.has(line[j+1])){const d=Math.sign(smooth[j+1]-smooth[j]);if(!d||direction&&d!==direction)break;direction=d;j++}
          const reached=line[j].plannedMark??dynamicOf(smooth[j]);
          if(j-i>=HAIRPIN_SPAN&&reached!==here&&time(line[j])-time(line[i])>=beatLength(line[i])-SAME_TIME&&hairpinOf(line[i],line[j],direction)){if(reached!==printed)mark(line[j],reached);i=j+1;continue}
          i++;
        }
      }
      let i=written?line.length:0;
      while(i<line.length){
        if(printed===null)mark(line[0],dynamicOf(smooth[0]));
        // (An instrument taken up: its own dynamic, where it differs.)
        else if(taken.has(line[i])&&dynamicOf(smooth[i])!==printed)mark(line[i],dynamicOf(smooth[i]));
        // A hairpin where the smoothed loudness grows or fades a dynamic step over three notes and a beat or more, from
        // where it starts to move to where it last moves (a level held after is the level reached, not more of the
        // change), and gradually: in two steps or more, none more than half the change. A sudden change is a new dynamic.
        // (Its direction found once the level has moved DYNAMIC_STEP from where it began to move, its notes' steps summed
        // -- not note by note: a crescendo over seventy notes, each a little louder than the last by less than
        // DYNAMIC_STEP, had been no hairpin at all, its dynamics left at its first mark, where the same crescendo over
        // fifty-four notes was one. Each step the way it goes counts toward it; one back by DYNAMIC_STEP ends it.)
        let j=i,direction=0,began=i,moved=i,start=i;const steps=[],pending=[];
        while(j+1<line.length&&!phraseStart.has(line[j+1])){
          const step=smooth[j+1]-smooth[j];
          if(!direction){
            if(Math.abs(step)<=SAME_LEVEL){start=j+1;pending.length=0}
            else{pending.push(step);const so=smooth[j+1]-smooth[start];
              if(Math.abs(so)>DYNAMIC_STEP){direction=Math.sign(so);began=start;steps.push(...pending.filter(each=>each*direction>SAME_LEVEL).map(Math.abs))}}
          }else if(step*direction<-DYNAMIC_STEP)break;
          else if(step*direction>SAME_LEVEL)steps.push(Math.abs(step));
          j++;
          if(direction&&smooth[j]*direction>smooth[moved]*direction+SAME_LEVEL)moved=j;
        }
        const from=began,to=moved,change=Math.abs(smooth[to]-smooth[from]),gradual=steps.length>=HAIRPIN_STEPS&&Math.max(...steps)<=change/2+SAME_LEVEL;
        // The level it arrives at: the one the next notes of the phrase hold (a peak of one note is the top of the change,
        // not a dynamic of its own).
        const after=[];for(let k=to;k<line.length&&k<to+LEVEL_HELD_OVER&&(k===to||!phraseStart.has(line[k]));k++)after.push(dynamicOf(smooth[k]));
        const held=new Map;for(const value of after)held.set(value,(held.get(value)??0)+1);
        const reached=[...held].sort((a,b)=>b[1]-a[1])[0][0];
        // (Taken where it begins: a level reached before it, however long held, is marked first.)
        // (Its two ends in one voice: in a staff two players share, the louder of two notes struck together -- the one the
        // line keeps -- may be either's, and a hairpin begun in one voice and ended in the other is never ended there: Op.
        // 3.31's desks, LilyPond's "unterminated decrescendo". Its end's voice where that voice sounds at its start, else
        // its start's where that one sounds at its end.)
        const struck=(event,voice)=>event.voice.voice===voice?event:list.find(other=>other.voice.voice===voice&&other.element.start.eq(event.element.start));
        const ends=line[from]&&line[to]?(struck(line[from],line[to].voice.voice)?[struck(line[from],line[to].voice.voice),line[to]]:struck(line[to],line[from].voice.voice)?[line[from],struck(line[to],line[from].voice.voice)]:null):null;
        if(ends&&from===i&&to-from>=HAIRPIN_SPAN&&direction&&gradual&&reached!==dynamicOf(smooth[from])&&change>=HAIRPIN_CHANGE&&time(line[to])-time(line[from])>=beatLength(line[from])-SAME_TIME){
          const [first,last]=ends;
          first.element.hairpin=direction>0?'crescendo':'decrescendo';last.element.hairpinEnd=true;
          // A change over two bars or more is written in words (cresc., dim.) with a dashed line, as engravers write a
          // long one: a wedge that long says less than the word.
          if(last.element.start.sub(first.element.start).gt(measures[first.measure].length.mul(WORDED_OVER_BARS)))first.element.hairpinText=true;
          if(reached!==printed)mark(line[to],reached);
          i=to+1;continue;
        }
        // Otherwise a new dynamic where the written level's mark changes; read from the playing, only where the smoothed
        // level changes and holds for four notes.
        const here=dynamicOf(smooth[i]);
        if(here!==printed&&(written||smooth.slice(i,i+DYNAMIC_HOLDS).every(value=>dynamicOf(value)===here)))mark(line[i],here);
        i++;
      }
      // (A woodwind's fingering drawn where it begins or changes: a multiphonic's, or the one its player shades a pitch
      // between its keys' notes to (woodwind-fingering.js) -- LilyPond's woodwind diagram, lilypond.js.)
      if(!percussion){let fingered=null;
        for(const event of list){const own=event.element.notes.find(note=>note.fingered)?.fingered;
          const diagram=event.element.notes.find(note=>note.multiphonic)?.multiphonic.diagram??(own?{instrument:own.instrument,keys:own.keys}:null),shown=diagram?JSON.stringify(diagram):null;
          if(shown&&shown!==fingered)event.element.diagram=diagram;fingered=shown}}
      // Where its players say how they played (technique): pizz. and arco where the staff's playing changes, once, and
      // the slurs they bowed, voice by voice -- a note slurred to the one before it in its voice, a run of them under one
      // slur -- in place of slurs read from the sound (a change of bow sounds into its next note as a slur does).
      const played=event=>{const kinds=new Set(event.element.notes.map(note=>note.technique));return kinds.size===1?[...kinds][0]??null:null};
      const told=event=>Boolean(played(event))||event.element.notes.every(note=>note.phrased);
      if(!percussion&&list.some(told)){
        let playing='arco';
        for(const event of list){const kind=played(event);if(kind&&kind!==playing&&(kind==='pizzicato'||playing==='pizzicato')){if(!list.some(other=>other!==event&&other.element.techniqueText&&other.element.start.eq(event.element.start)))event.element.techniqueText=kind==='pizzicato'?'pizz.':'arco';playing=kind}}
        // (And where they bowed: sul ponticello or sul tasto, poco or molto, and how hard -- flaut., molto pressione,
        // overpressure -- where the staff's contact or pressure changes its band, ord. back; each band's words its contact's
        // (CONTACT_WORDS) and its pressure's (techniques.js PRESSURE_WORDS); a plucked note keeps the band it is in.)
        let muted=null;
        // (A band held, not a note's flicker across its edge: each event's words first, then a run of them only one event
        // long and shorter than a beat taken as the run before it -- Op. 3.34's strings had written "poco sul tasto molto
        // pressione" and "ord." in turn, some 230 times each, the owner: "a proliferation of certain text marks".)
        const wordsOf=new Map;
        for(const event of list){
          if(event.element.notes.every(note=>note.technique==='pizzicato'))continue;
          const mean=key=>event.element.notes.reduce((sum,note)=>sum+(Number(note[key])||0),0)/event.element.notes.length;
          const placed=contactWords(mean('contact')),pressed=pressureWords(mean('bowPressure'));
          // (A wind's extended technique, where its notes have one: hum, growl, flz. -- techniques.js.)
          // (Or a multiphonic: mult., a string's with its string's numeral -- techniques.js.)
          const kinds=[...new Set(event.element.notes.flatMap(note=>Object.keys(note.extended??{})))],multi=event.element.notes.find(note=>note.multiphonic)?.multiphonic;
          const extended=[...new Set([multi?MULTIPHONIC_WORD:null,...kinds.map(kind=>WIND_TECHNIQUE_WORDS[kind]),Number.isInteger(multi?.string)?STRING_NUMERALS[multi.string]:null].filter(Boolean))].join(' ');
          // (A brass player's mute: con sord. with its kind where it goes in, senza sord. where it comes out.)
          const mute=event.element.notes.map(note=>note.extended?.mute?.kind).find(Boolean)??null;
          if(mute!==muted){event.element.techniqueText=[event.element.techniqueText,MUTE_WORDS[mute??'off']].filter(Boolean).join(' ');muted=mute}
          const coloured=pressed?(placed==='ord.'?pressed:`${placed} ${pressed}`):placed,words=extended?(coloured==='ord.'?extended:`${coloured} ${extended}`):coloured;
          wordsOf.set(event,words);
        }
        // (Read voice by voice: a desk's two players may take a technique differently -- their appetites their own,
        // techniques.js takesUp -- and read across the staff their notes in turn had written its words and 'ord.' in turn,
        // note by note. Where the staff's voices keep one course of words, written once, over the staff; where they part,
        // each voice's own, the lower voice's under it.)
        const voiceOf=event=>event.voice?.voice??1,voiceKeys=[...new Set(list.filter(event=>wordsOf.has(event)).map(voiceOf))].sort((a,b)=>a-b);
        const courses=voiceKeys.map(key=>{
          const bowed=list.filter(event=>wordsOf.has(event)&&voiceOf(event)===key),words=new Map(bowed.map(event=>[event,wordsOf.get(event)]));
          for(let k=1;k+1<bowed.length;k++){const event=bowed[k],before=words.get(bowed[k-1]),own=words.get(event);
            if(own!==before&&words.get(bowed[k+1])!==own&&time(bowed[k+1])-time(event)<beatLength(event))words.set(event,before)}
          const changes=[];let held='ord.';
          for(const event of bowed){const said=words.get(event);if(said!==held){changes.push({event,words:said});held=said}}
          return {key,bowed,changes};
        });
        const sayingAt=(course,t)=>course.changes.filter(change=>time(change.event)<=t+1e-9).at(-1)?.words??'ord.';
        const times=[...new Set(courses.flatMap(course=>course.changes.map(change=>time(change.event))))];
        const shared=courses.length>1&&times.every(t=>courses.every(course=>sayingAt(course,t)===sayingAt(courses[0],t)));
        for(const [index,{bowed,changes}] of courses.entries()){
          if(shared&&index>0)continue;
          // (Each change's words written once, with a dashed line in its voice to the last of its notes before the next
          // change -- "sul pont. - - - -", as players read it -- where it lasts past its first note; 'ord.' alone, as it
          // is read.)
          changes.forEach(({event,words},k)=>{
            const next=changes[k+1]?.event,own=bowed.filter(other=>other.element.start.ge(event.element.start)&&(!next||other.element.start.lt(next.element.start)));
            if(!shared&&index>0)event.element.techniqueBelow=true;
            if(words!=='ord.'&&own.length>1){event.element.techniqueSpan=words;own.at(-1).element.techniqueSpanStop=true}
            else event.element.techniqueText=event.element.techniqueText?`${event.element.techniqueText} ${words}`:words;
          });
        }
        const voices=new Map;for(const event of list){const key=event.voice?.voice??1;(voices.get(key)||voices.set(key,[]).get(key)).push(event)}
        for(const notes of voices.values()){
          // (Written up to it: a slurred note's predecessor reaches it, above, so no slur spans a rest.)
          const joined=k=>k>0&&k<notes.length&&notes[k].element.notes.every(note=>note.slurred);
          for(let k=0;k<notes.length;k++){if(joined(k+1)&&!joined(k))notes[k].element.slurStart=true;if(joined(k)&&!joined(k+1))notes[k].element.slurStop=true}
          // (A note slurred to the pitch it follows written portato, a tenuto under the slur: its player half-attacks it with
          // the tongue, as the render plays it (render/synthesis/src/breath.mjs samePitch) -- a repeated pitch slurred alone
          // reads as one note held. And any its player legato-tongued, where it says so: a trombonist's across its slide,
          // wind-seat.js.)
          const pitches=k=>notes[k].element.notes.map(note=>note.pitch).sort((a,b)=>a-b);
          for(let k=1;k<notes.length;k++)if(joined(k)){const a=pitches(k-1),b=pitches(k);if(a.length===b.length&&a.every((x,i)=>Math.abs(x-b[i])<PORTATO_PITCH)||notes[k].element.notes.every(note=>note.portato))notes[k].element.tenuto=true}
        }
        if(list.every(told))continue;
      }
      // Slurs over legato runs, in a staff of one voice; a tenuto on a full note between detached ones -- read from how it
      // was played, so only where a performance is read (above): an untold note's written length had reached every next
      // note, and every run was slurred.
      if(!performance||percussion||part.measures.some(measure=>measure.voices.filter(voice=>voice.staff===staff&&!voice.filler).length>1))continue;
      const legato=(a,b)=>{const heard=a.element.notes.reduce((most,note)=>Math.max(most,a.element.end.toNumber()+(note.releaseWhole??0)),0);return heard>=b.element.start.toNumber()-LEGATO_GAP*beatLength(a)&&!a.element.notes.some(note=>note.staccato)&&!a.element.staccatissimo};
      for(const notes of phrases){
        let run=[notes[0]];
        const close=()=>{if(run.length>=SLUR_NOTES){run[0].element.slurStart=true;run.at(-1).element.slurStop=true}};
        // (Never over a note its player told: its slurs are said, not read from the sound -- read over them too, a staff
        // with a note or two untold had two slurs begun at once.)
        const untold=event=>!told(event);
        for(let k=1;k<notes.length;k++){if(untold(notes[k-1])&&untold(notes[k])&&legato(notes[k-1],notes[k]))run.push(notes[k]);else{close();run=[notes[k]]}}
        close();
        for(let k=1;k+1<notes.length;k++){
          const [a,b,c]=[notes[k-1],notes[k],notes[k+1]],detached=event=>event.element.notes.some(note=>note.staccato)||event.element.staccatissimo;
          const full=b.element.notes.every(note=>(note.releaseWhole??0)>=-FULL_LENGTH*b.element.end.sub(b.element.start).toNumber());
          if(detached(a)&&detached(c)&&full&&!b.element.slurStart&&!b.element.slurStop)b.element.tenuto=true;
        }
      }
    }
  }
  // ---- octave signs, weighed as an engraver weighs them: ledger lines past two cost more the further they go (a third
  // 1, a fourth 3, a fifth 6); an octave sign costs 4 to open, and a note under one a little, more for each ledger line
  // it still needs. Each staff's notes take the cheapest way (a shortest path), so an 8va (above a treble staff) or an
  // 8vb (below a bass staff) comes where it saves real ledger lines -- not for one note a line or two out -- and ends
  // as the music comes back to the staff. A tie keeps its octave; a measure where the staff has more than one voice,
  // or a rest of a bar, ends a sign. (Octave clefs already carry their octave.)
  for(const part of parts){
    if(part.kind!=='pitched')continue;
    for(let staff=1;staff<=(part.staves||1);staff++){
      const clef=part.clefs?.[staff-1];if(!clef||clef.octave||!['G','F'].includes(clef.sign))continue;
      // The staff's lines as diatonic steps from middle C (treble E4..F5, bass G2..A3); the sign moves notes 7 steps.
      const [bottom,top]=clef.sign==='G'?TREBLE_STAFF_STEPS:BASS_STAFF_STEPS,shift=clef.sign==='G'?-STEPS_PER_OCTAVE:STEPS_PER_OCTAVE,sign=clef.sign==='G'?1:-1;
      const ledgers=step=>ledgersOn(step,[bottom,top]);
      const runs=[];let run=[];const cut=()=>{if(run.length)runs.push(run);run=[]};
      // (A line moving between the staves: its notes on this staff, a note on the other ending a sign.)
      part.measures.forEach(measure=>{
        const voices=measure.voices.filter(voice=>!voice.filler&&voice.elements.some(element=>(element.staff??voice.staff)===staff));
        if(voices.length!==1){cut();return}
        for(const element of voices[0].elements){
          if((element.staff??voices[0].staff)!==staff){cut();continue}
          if(element.rest||element.hidden){if(element.measureRest)cut();continue}
          run.push(element);
        }
      });
      cut();
      for(const notes of runs){
        const steps=notes.map(element=>element.notes.map(note=>stepOf(note.spelled)));
        const at=steps.map(list=>Math.max(...list.map(step=>pain(ledgers(step))))),under=steps.map(list=>{const lines=Math.max(...list.map(step=>ledgers(step+shift)));return pain(lines)+OTTAVA_UNDER+OTTAVA_UNDER_PER_LINE*lines});
        // cost[k][s]: the cheapest writing of notes 0..k with note k at pitch (s 0) or under the sign (s 1).
        const cost=[[at[0],OTTAVA_OPENING+under[0]]],back=[[0,0]];
        for(let k=1;k<notes.length;k++){
          const [c0,c1]=cost[k-1],tied=notes[k].tieStop;
          const to0=tied||c0<=c1?[c0,0]:[c1,1],to1=tied||c1<=c0+OTTAVA_OPENING?[c1,1]:[c0+OTTAVA_OPENING,0];
          cost.push([at[k]+to0[0],under[k]+to1[0]]);back.push([to0[1],to1[1]]);
        }
        let state=cost.at(-1)[0]<=cost.at(-1)[1]?0:1;const states=[];
        for(let k=notes.length-1;k>=0;k--){states[k]=state;state=back[k][state]}
        notes.forEach((element,k)=>{
          if(!states[k])return;
          element.ottava=sign;
          if(!states[k-1])element.ottavaStart=sign;
          if(!states[k+1])element.ottavaStop=true;
        });
      }
    }
  }
  // A performance the bots ended closes on a fermata over each staff's last sound (form_clodbot holds the last chord).
  if(closes&&plans?.endBar!=null&&measures.length){
    const last=measures.length-1;
    for(const part of parts)for(let staff=1;staff<=(part.staves||1);staff++){
      const voice=part.measures[last].voices.filter(v=>v.staff===staff).sort((a,b)=>a.voice-b.voice)[0],element=voice?.elements.at(-1);
      if(element&&!element.hidden)element.fermata=true;
    }
  }
  // A hold the clock kept (transcript.timeline.holds; shared/clock-hold.js): a fermata over what each staff sounds as it
  // begins, and "Cadenza" over a part that played in its free time.
  for(const [tick] of transcript.timeline.holds??[]){
    const bar=transcript.barAt(tick),measure=bar&&measures[bar.bar-firstBar];if(!measure)continue;
    const at=measure.start.add(Rational.of(tick).sub(bar.tick).div(ticksPerWhole(bar.meter)));
    for(const part of parts){
      const content=part.measures[measure.index];if(!content)continue;
      for(let staff=1;staff<=(part.staves||1);staff++){
        const voice=content.voices.filter(v=>v.staff===staff).sort((a,b)=>a.voice-b.voice)[0],element=voice?.elements.find(each=>each.start.le(at)&&each.end.gt(at));
        if(element&&!element.hidden)element.fermata=true;
      }
      if(part.voice!=null&&freeNotes.some(note=>note.voice===part.voice&&note.tick===tick))
        content.directions.push({kind:'cadenza',start:at,value:'Cadenza',staff:1});
    }
  }
  // ---- tempo: marks where it changes, the exact tempo for playback at every change ---------------------------------
  //   printed   the first tempo; a tempo that holds a bar or more; the tempo at a bar that changes the meter, or that
  //             jumps (by more than 3%), where it is not the last printed; the start of a ramp, in words (accel., rit.),
  //             after its metronome mark where it starts from a tempo not printed ("♩ = 120 rit.")
  //   heard     every other step, a sound the page does not show -- and a change lasting one tick before a bar that
  //             already runs at that bar's tick: the clock taking up the next bar's tempo a tick early, no tempo of its
  //             own, whatever it would say
  //   dashed    a ramp's word, from itself to where the tempo arrives (its last step; the next tempo printed, if that is
  //             sooner), as an engraver writes "accel. - - -" up to the new tempo (until: where the dashes stop)
  const tempo=[];
  const changes=transcript.timeline.scoreTempo.map(([tick,...value])=>[Rational.of(tick),...value]),firstTick=bars.find(bar=>bar.bar===firstBar)?.tick;
  // (In written quarters: the page's note values, which keep each pulse's length -- a tenth written as an eighth.)
  const quartersOf=(bpm,meter)=>bpm*QUARTER*(writtenMeter(meter)?.pulse??1)/(writtenMeter(meter)?.denominator||QUARTER),tickSeconds=(bpm,meter)=>SECONDS_PER_MINUTE/(bpm*(meter?.subdivision||DEFAULT_SUBDIVISION));
  // Where a tick stands on the page; past the window's last bar, at its end.
  const positionOf=tick=>{const bar=transcript.barAt(tick),measure=bar&&measures[bar.bar-firstBar];if(!measure)return bar&&bar.bar>=firstBar?windowEnd:null;
    return measure.start.add(Rational.of(tick).sub(bar.tick).div(ticksPerWhole(bar.meter)))};
  let printed=null;
  // The window opens with the tempo in force, wherever it was set.
  if(firstBar>0&&firstTick!=null){const bpm=transcript.scoreBpmAt(firstTick);if(bpm&&!changes.some(([tick])=>tick.eq(firstTick))){tempo.push({start:R(0),...beatOf3(meterAt(firstBar),bpm),visible:true,words:null});printed=quartersOf(bpm,meterAt(firstBar))}}
  const real=changes.filter(([tick,bpm],index)=>{
    const next=changes[index+1],bar=transcript.barAt(tick),nextBar=next&&transcript.barAt(next[0]);
    if(changes[index][2]||!(bpm>0)||!(next?.[1]>0)||!bar||!next[0].sub(tick).eq(1)||!nextBar||!next[0].eq(nextBar.tick))return true;
    return Math.abs(tickSeconds(bpm,bar.meter)/tickSeconds(next[1],nextBar.meter)-1)>TEMPO_CHANGE;
  });
  // (Each real change's place among them by its tick -- the first, where two share one -- and its tempo in written
  // quarters, each found once: a ramp changes the tempo at every tick, and each step reads on to where it goes.)
  const realAt=new Map;real.forEach(([tick],k)=>{const at=String(tick);if(!realAt.has(at))realAt.set(at,k)});
  const quartersAt=[],q=k=>quartersAt[k]??=quartersOf(real[k][1],transcript.barAt(real[k][0])?.meter);
  changes.forEach(([tick,bpm,curve])=>{
    if(!(bpm>0)){printed=null;return}
    const bar=transcript.barAt(tick);if(!bar)return;
    const measure=measures[bar.bar-firstBar];if(!measure)return;
    const written=writtenMeter(bar.meter),at=measure.start.add(tick.sub(bar.tick).div(ticksPerWhole(bar.meter)));
    const mark={start:at,...beatOf3(written,bpm),visible:false,words:null};tempo.push(mark);
    const index=realAt.get(String(tick))??-1;if(index<0)return;
    const next=real[index+1],previous=real[index-1],subdivision=bar.meter.subdivision||DEFAULT_SUBDIVISION,perBar=bar.meter.numerator*subdivision;
    const quarters=quartersOf(bpm,bar.meter),before=previous?.[1]>0?quartersOf(previous[1],transcript.barAt(previous[0])?.meter):null;
    const ramping=Boolean(curve)||next?.[1]>0&&next[0].sub(tick).le(subdivision),steady=(next?next[0]:R(transcript.timeline.tickSeconds.length-1)).sub(tick).ge(perBar);
    // Where the ramp is going: the tempo it reaches while it keeps its direction (its steps may be too fine to tell
    // apart one by one).
    let reach=index,direction=0;
    while(real[reach+1]?.[1]>0&&real[reach+1][0].sub(real[reach][0]).le(subdivision)){
      const step=Math.sign(q(reach+1)-q(reach));
      if(step&&direction&&step!==direction)break;
      if(step)direction=step;reach++;
    }
    let goal=q(reach),rampEnd=real[reach][0];
    const continues=curve&&previous?.[2]&&Rational.of(previous[2].until).eq(tick)&&
      Rational.of(previous[2].slope).sign()===Rational.of(curve.slope).sign()&&
      Math.abs(tempoValue(previous,tick,{inclusiveEnd:true})/bpm-1)<1e-9;
    if(curve){
      let last=index;
      while(real[last+1]?.[2]&&Rational.of(real[last][2].until).eq(real[last+1][0])&&
        Rational.of(real[last+1][2].slope).sign()===Rational.of(curve.slope).sign()&&
        Math.abs(tempoValue(real[last],real[last][2].until,{inclusiveEnd:true})/real[last+1][1]-1)<1e-9)last++;
      rampEnd=Rational.of(real[last][2].until);goal=quartersOf(tempoValue(real[last],rampEnd,{inclusiveEnd:true}),transcript.barAt(real[last][0]).meter);
    }
    const startsRamp=curve?!continues:ramping&&(!(previous?.[1]>0)||tick.sub(previous[0]).gt(subdivision));
    // (A jump leaves a tempo that held more than a beat; the steps of a ramp, however steep, are not jumps.)
    const head=tick.eq(bar.tick)&&(measure.meterChanged||measure.index===0),jump=before!=null&&tick.sub(previous[0]).gt(subdivision)&&Math.abs(quarters/before-1)>TEMPO_JUMP;
    const fresh=printed==null||Math.abs(quarters-printed)>=TEMPO_DIFFERS;
    if(printed==null||(steady||head||jump||startsRamp)&&fresh){mark.visible=true;printed=quarters}
    if((startsRamp||ramping&&(head||jump)&&mark.visible)&&Math.abs(goal-quarters)>=TEMPO_DIFFERS){mark.words=goal>quarters?'accel.':'rit.';mark.until=positionOf(rampEnd)}
    // A ramp's first step is heard a tick after it begins (the tempo of the tick before is still the old one): its word
    // is printed where it begins -- at the head of the bar, where it began with the bar -- and the step keeps its sound.
    if(!curve&&mark.words&&!mark.visible&&tick.sub(1).ge(bar.tick)){
      tempo.push({start:measure.start.add(tick.sub(1).sub(bar.tick).div(ticksPerWhole(bar.meter))),...beatOf3(written,bpm),visible:false,words:mark.words,until:mark.until,silent:true});
      mark.words=null;delete mark.until;
    }
  });
  // A metric modulation's equivalence (the home time signature's; meterform_clodbot), at its first bar and at its return:
  // the old note that the new beat equals, beside the tempo mark that shows the new tempo. A modulation of ratio a/b
  // (b bars filling a home bars) makes the new beat worth a/b of the old one: at 3/2 a dotted quarter = a quarter, at
  // 2/3 a triplet quarter = a quarter; its return is the inverse. Read from the transcript's homes (Transcript.homeAt);
  // a value no note, dot or triplet writes is left to the tempo mark.
  for(const measure of measures){
    const here=transcript.homeAt(measure.bar),before=measure.bar>0?transcript.homeAt(measure.bar-1):null;
    const starts=here?.kind==='modulation'&&here.index===0&&here.ratio,
      returns=before?.kind==='modulation'&&before.index===before.bars-1&&before.ratio&&!(here?.kind==='modulation'&&here.index>0);
    if(!starts&&!returns)continue;
    const [a,b]=starts?here.ratio:[before.ratio[1],before.ratio[0]],bar=bars.find(each=>each.bar===measure.bar);
    const mark=tempo.find(each=>each.start.eq(measure.start)&&!each.silent)??(bar&&transcript.scoreBpmAt(bar.tick)
      ?(tempo.push({start:measure.start,...beatOf3(writtenMeter(measure.meter),transcript.scoreBpmAt(bar.tick)),visible:true,words:null}),tempo.at(-1)):null);
    if(!mark)continue;
    const beat=R(mark.dotted?3:1,mark.dotted?2*mark.beatUnit:mark.beatUnit),from=noteValue(beat.mul(R(a,b))),to=noteValue(beat);
    if(from&&to){mark.equivalence={from,to};mark.visible=true}
  }
  tempo.sort((a,b)=>a.start.cmp(b.start));
  // A ramp's word where a metronome mark is printed (the one a window opens with) is printed with it, after it: one mark.
  for(const mark of tempo){
    if(!mark.words||mark.visible)continue;
    const stated=tempo.find(other=>other.visible&&!other.words&&other.start.eq(mark.start));
    if(stated){Object.assign(stated,{words:mark.words,until:mark.until});mark.words=null;delete mark.until}
  }
  // A ramp's dashes stop at the next tempo printed, where that comes first; a ramp that arrives where its word stands
  // has none.
  tempo.forEach((mark,index)=>{
    if(!mark.until)return;
    const next=tempo.slice(index+1).find(other=>(other.visible||other.words)&&other.start.gt(mark.start));
    if(next&&next.start.lt(mark.until))mark.until=next.start;
    if(!mark.until.gt(mark.start))delete mark.until;
  });
  // A closed performance's last ramp arrives somewhere: still running at the last note struck, its dashes stop there
  // and the tempo that note was struck in is printed; arrived before it but not held a bar (so not printed), the tempo
  // it arrived at is printed where its dashes stop -- an accel. running into the final barline says nothing of where
  // it gets to.
  if(closes&&notes.length){
    const tickAt=time=>{const measure=measureAt(time),bar=bars.find(each=>each.bar===measure.bar);
      return bar?Rational.of(bar.tick).add(time.sub(measure.start).mul(ticksPerWhole(bar.meter))):null};
    const last=notes.reduce((latest,note)=>note.start.gt(latest)?note.start:latest,notes[0].start),ramp=tempo.findLast(mark=>mark.words&&mark.until);
    if(ramp&&ramp.start.lt(last)&&!tempo.some(mark=>mark.visible&&mark.start.gt(ramp.start))){
      if(ramp.until.gt(last))ramp.until=last;
      const began=tickAt(ramp.start),arrived=tickAt(ramp.until),from=began!=null&&transcript.barAt(began),to=arrived!=null&&transcript.barAt(arrived),bpm=to&&transcript.scoreBpmAt(arrived);
      if(from&&bpm&&Math.abs(quartersOf(bpm,to.meter)-quartersOf(transcript.scoreBpmAt(began),from.meter))>=TEMPO_DIFFERS)
        tempo.push({start:ramp.until,...beatOf3(writtenMeter(to.meter),bpm),visible:true,words:null,silent:true});
    }
  }
  // ---- the plans: the harmony, the form and the cues, on a lead-sheet staff at the top (a slash a pulse) -- or, with
  // planStaff false (a render's score, whose bars were all played), above the top part ------------------------------
  let carried=null;
  if(plans&&(options.planStaff!==false||parts.length)){
    const plansName=options.planStaffName??transcript.source?.labels?.plans??'Plans';
    const part=options.planStaff===false?null:{id:'P0',voice:null,name:plansName,abbreviation:plansName.length<=ABBREVIATION_KEEPS?plansName:abbreviate(plansName),bot:null,kind:'plans',staves:1,clefs:[{sign:'G',line:TREBLE_LINE}],
      measures:measures.map(()=>({voices:[],directions:[]}))};
    if(part)measures.forEach((measure,index)=>{
      const beat=R(1,measure.meter.denominator),events=pulsesOf(measure.meter).map(([at,length])=>({start:beat.mul(at),end:beat.mul(at+length),content:{slash:true}}));
      let elements;
      // A bar the slashes do not fill (a meter shorter or longer than its bar) is left to a measure rest.
      try{elements=spellIn(measure,events).elements}
      catch(error){warnings.push(`${part.name}, measure ${measure.number}: ${error.message}`);return}
      part.measures[index].voices.push({staff:1,voice:1,elements:elements.map(element=>({...element,start:measure.start.add(element.start),end:measure.start.add(element.end),
        slash:!element.rest,beams:[],notes:element.rest?undefined:[{pitch:SLASH.pitch,velocity:0,spelled:{step:'B',octave:SLASH.octave,alter:0,display:0,accidental:null,cents:0}}]}))});
    });
    const target=part??parts[0];
    // The last bar's final barline, through every staff.
    const endIndex=plans.endBar==null?-1:plans.endBar-firstBar;
    if(endIndex>=0&&endIndex<measures.length)for(const each of [part,...parts])if(each)each.measures[endIndex].barline='light-heavy';
    // How a chord sounded: each bot that struck two of its tones together within a beat of it (a chord, not a melody
    // passing through them), tuned as it played them; the pitches published if nobody did. Where one bot tuned it just
    // and another played it equal-tempered, the just tuning is the chord's (the cents in the staves say whose).
    const pitchClass=pitch=>((Math.round(pitch)%SEMITONES_PER_OCTAVE)+SEMITONES_PER_OCTAVE)%SEMITONES_PER_OCTAVE;
    const soundedTuning=(pitches,start)=>{
      const tones=new Set(pitches.map(pitchClass)),until=start.add(beatOf(start).length),struck=new Map;
      for(const note of notes)if(!note.percussion&&note.start.ge(start)&&note.start.lt(until)&&tones.has(pitchClass(note.pitch))){
        const key=`${note.voice}|${note.start}`;(struck.get(key)||struck.set(key,{voice:note.voice,pitches:[]}).get(key)).pitches.push(note.pitch);
      }
      const byVoice=new Map;
      for(const {voice,pitches:played} of struck.values())if(new Set(played.map(pitchClass)).size>=CHORD_PITCH_CLASSES&&!byVoice.has(voice))byVoice.set(voice,played);
      const tunings=[...new Set([...byVoice.values()].map(played=>chordTuning(played,{fifths:key.fifths})))],inflected=tunings.filter(tuning=>tuning!=='equal-tempered');
      return inflected.length?inflected.slice(0,TUNED_TONES_SHOWN).join(' / '):tunings.length?tunings[0]:chordTuning(pitches,{fifths:key.fifths});
    };
    const place=(bar,beat=R(0))=>{const measure=measures[bar-firstBar];return measure?{measure,start:measure.start.add(Rational.of(beat).mul(R(measure.meter.pulse??1,measure.meter.denominator)))}:null};
    // The tuning, where printed, is printed where it changes, as a player's instruction is (pizz. until arco): the first
    // chord's, then each that differs from the chord before (equal-tempered again after just is said, as ord. is).
    const chordTunings=options.chordTunings??CHORD_TUNINGS_PRINTED;let lastTuning=null;
    for(const chord of [...(plans.chords??[])].sort((a,b)=>a.bar-b.bar||Rational.of(a.beat??0).cmp(Rational.of(b.beat??0)))){
      const where=place(chord.bar,chord.beat),named=nameChord(chord.pitches,{fifths:key.fifths});
      // A pool that is no chord (a cluster, a scale) has no symbol a player could read: it is left off the page.
      if(!where||!named||named.kind==='other')continue;
      const tuning=chord.planned?chordTuning(chord.pitches,{fifths:key.fifths}):soundedTuning(chord.pitches,where.start);
      target.measures[where.measure.index].directions.push({kind:'harmony',start:where.start,chord:named,planned:Boolean(chord.planned),staff:1,tuning,tuningShown:chordTunings&&tuning!==lastTuning});
      lastTuning=tuning;
    }
    for(const mark of plans.marks??[]){
      // A meter's cue is for the cue list; on the page the time signature says it.
      if(mark.meter)continue;
      // A mark at the end of its bar (the ending) stands at the barline, ending there: set over the final barline, as
      // an engraver sets "Fine", it does not widen the bar.
      // (Its bar's end its length from its start: counted as its numerator in its notated beats, a 24/16 written in dotted
      // eighths had set Op. 3.27's "End" three bars late.)
      const measure=measures[mark.bar-firstBar],where=mark.atEnd&&measure?{measure,start:measure.start.add(measure.length)}:place(mark.bar,mark.beat);if(!where)continue;
      // (The form's role for the section is the bots' business, not the player's.)
      target.measures[where.measure.index].directions.push(mark.kind==='rehearsal'?{kind:'rehearsal',start:where.start,value:mark.text,staff:1}
        :{kind:'words',start:where.start,value:mark.text,staff:1,style:'italic',size:WORDS_SIZE,...(mark.atEnd?{align:'right'}:{})});
    }
    // The feel each section is played in, where it begins (plans.feels): its words ("Swing"), and its swing for playback
    // at the tempo in force there (performance-timing.js feelDirection).
    for(const feel of plans.feels??[]){
      const where=place(feel.bar),bar=bars.find(each=>each.bar===feel.bar),bpm=bar?transcript.scoreBpmAt(bar.tick):null;
      const direction=feelDirection(feel.location??feel.name,bpm?quartersOf(bpm,bar.meter):null);
      if(where&&direction)target.measures[where.measure.index].directions.push({kind:'feel',start:where.start,words:direction.words,swing:direction.swing,staff:1});
    }
    // The tempo curves ahead (plans.tempi), in bars not yet played, written as they will be played (a played bar has the
    // tempo that sounded): a curve's word (accel., rit.) at its first bar -- after the metronome mark of the tempo it
    // starts from, where its bar changes the meter's written tempo -- dashed to the bar it arrives at, and there the
    // tempo it arrives at, with the next curve's word where that one begins as it arrives. A curve the next one begins
    // before it arrives is cut there (the conductor starts the next from wherever the tempo has got to): no tempo
    // arrived at, and the next one's dashes carry on its own where it goes the same way. A curve under way where the
    // played bars end (in a live window: a closed performance has nothing after them) carries the played ramp's dashes
    // on -- and is the score's `tempoCarried` ({bar it began at, words,
    // until}), whether or not the window holds the ramp's word (a live window prints it once the ramp has moved by
    // TEMPO_DIFFERS; an eased curve moves little in its first bar). The tempo in force: the last heard, then each
    // curve's goal.
    const heard=Math.max(0,(options.knownUntil??transcript.timeline.tickSeconds.length)-1),heardBar=transcript.barAt(heard)?.bar??firstBar-1,ahead=new Map;
    const curves=(plans.tempi??[]).filter(curve=>curve.bar+curve.durationBars>heardBar);
    // (The dashes running on: a planned word's, or a curve's under way -- with the played ramp's mark, where the window
    // holds it.)
    let inForce=transcript.scoreBpmAt(heard),running=null;
    const run=(until,mark)=>{running.until=until;if(mark&&until.gt(mark.until))mark.until=until};
    curves.forEach((curve,index)=>{
      if(!inForce)return;
      const next=curves[index+1],cut=next&&next.bar<curve.bar+curve.durationBars?next.bar:null,ends=cut??curve.bar+curve.durationBars;
      const from=measures[curve.bar-firstBar],arrival=measures[ends-firstBar],meter=from?.meter??meterAt(curve.bar),until=arrival?.start??windowEnd;
      // A step (a curve of no bars: tempo-curve.js) is no accel. or rit.: its bar, where planned, is marked with the tempo
      // it steps to, and that tempo is in force from there.
      if(curve.durationBars===0){
        if(from?.planned&&!ahead.has(from.index))ahead.set(from.index,{kind:'tempo',start:from.start,...beatOf3(from.meter,curve.targetBpm),visible:true,words:null,planned:true,staff:1});
        running=null;inForce=curve.targetBpm;return;
      }
      // (A curve under way goes from the tempo it began at, where the window heard it begin: near its end the tempo in
      // force is within TEMPO_DIFFERS of its goal, but it is still a ramp, arriving there.)
      const began=curve.bar<=heardBar?bars.find(bar=>bar.bar===curve.bar):null,startBpm=began?transcript.scoreBpmAt(began.tick)??inForce:inForce;
      const words=Math.abs(quartersOf(curve.targetBpm,meter)-quartersOf(startBpm,meter))<TEMPO_DIFFERS?null:curve.targetBpm>startBpm?'accel.':'rit.';
      if(words&&running?.words===words)run(until,running.mark);
      else if(words&&from?.planned){
        // (The tempo it starts from, where the bar writes it differently from the bar before -- or it arrives there.)
        const before=measures[from.index-1],restated=!before||from.meterChanged&&Math.abs(quartersOf(inForce,from.meter)-quartersOf(inForce,before.meter))>=TEMPO_DIFFERS;
        const mark={kind:'tempo',start:from.start,...beatOf3(from.meter,inForce),visible:restated||ahead.has(from.index),words,until,planned:true,staff:1};
        ahead.set(from.index,mark);running={words,until,mark};
      }else if(words&&curve.bar<=heardBar&&!closes){
        // (A ramp not yet heard -- a live score prints its word once the tempo has moved by TEMPO_DIFFERS, and an eased
        // curve moves little in its first bar -- has its planned word where the curve began, if the window holds it.)
        const begun=from?.start??R(0),heard=tempo.findLast(each=>each.words===words&&each.until&&each.start.ge(begun))??null;
        const mark=heard??(from&&!ahead.has(from.index)?{kind:'tempo',start:from.start,...beatOf3(from.meter,startBpm),visible:false,words,until,planned:true,silent:true,staff:1}:null);
        if(mark&&!heard)ahead.set(from.index,mark);
        running=carried={bar:curve.bar,words,until,mark};run(until,mark);
      }else running=null;
      if(cut==null){
        if(words&&arrival?.planned&&!ahead.has(arrival.index))ahead.set(arrival.index,{kind:'tempo',start:arrival.start,...beatOf3(arrival.meter,curve.targetBpm),visible:true,words:null,planned:true,staff:1});
        running=null;
      }
      inForce=cut==null?curve.targetBpm:tempoOnCurve(inForce,curve,cut-curve.bar);
    });
    for(const [index,mark] of ahead)target.measures[index].directions.push(mark);
    if(part)parts.unshift(part);
  }
  // A whole performance (no window, no horizon), or a window that closes it, ends with a final barline through every
  // staff.
  if(closes&&measures.length)for(const part of parts)part.measures.at(-1).barline??='light-heavy';
  // The additive signature alone does not encode a second hierarchy. State the intended beats at each change.
  if(parts.length)for(const measure of measures){
    const legend=readingLegend(measure.meter);
    if(legend&&(measure.index===0||measure.meterChanged))parts[0].measures[measure.index].directions.push({kind:'words',start:measure.start,value:legend,staff:1,style:'italic',size:WORDS_SIZE});
  }
  // ---- parts in their own meters ----------------------------------------------------------------------------------
  // A part told a stream of its own (/agent/stream: its own meter, its own tempo relation) is laid again in its own
  // time, in its own bars (part-meters.js partTranscript), for an engraver that gives each staff its own timing
  // (lilypond.js); its measures above stay the ensemble's, for every other reader (MusicXML, the score view). Each own
  // measure knows its place on the shared timeline (shared: {start, length} in the ensemble's whole notes), so the
  // engraver can scale it there; its bar lines meet the ensemble's where their cycles meet.
  // Only where asked (options.ownMeters): a score's bars are one, every part's bar lines the ensemble's, meters changing
  // together and never disjoint from part to part (the owner, 3 October 2026: "don't use different bar lengths for
  // different instrumental parts"; "you can change meters, but don't make them disjoint from part to part") -- a part in
  // a tempo relation of its own written in the shared bars, its notes as fast as they go. Its own bars had broken lines in
  // the middle of every other part's bar (Op. 3.22: its strings at 2:1 while they rested).
  if(options.ownMeters===true)for(const part of parts){
    const own=partTranscript(transcript,part.voice);if(!own)continue;
    // (Its grand staff, where it has one, as two staves of their own: a line crossing between them would need both in
    // its own time at once.)
    const sub=buildScore(new Transcript(own.document),{key,ownMeters:false,acrossStaves:false,additiveSignatures,audience:options.audience,irrationalMeters:irrationalWritten});
    const mine=sub.parts[0];if(!mine)continue;
    // (A bar in a glide starts at no simple fraction of a tick: its start is taken to a 64th of one, so that its length,
    // the next start less its own, is a plain fraction, and the glide's bars still add up to the glide exactly.)
    const wholeAt=(tick,glide=false)=>{
      const bar=transcript.barAt(Math.max(0,Math.floor(tick+1e-9)));if(!bar)return null;
      // (A tick is the bar's written length over its ticks: the score's timeline is in written values, an irrational
      // meter's bars (23/31) in the note values they are written in.)
      const perTick=lengthOf(meterAt(bar.bar)).div(R((Number(bar.meter.numerator)||4)*(Number(bar.meter.subdivision)||4)));
      const into=tick-bar.tick;
      return startOf(bar.bar).add(perTick.mul(glide?R(Math.round(into*GLIDE_GRID),GLIDE_GRID):rationalOf(into)));
    };
    const ownMeasures=sub.measures.map(measure=>{
      const bar=own.bars[measure.bar],next=own.bars[measure.bar+1];
      const from=bar?wholeAt(bar.shared.from,bar.glide):null,to=bar?wholeAt(bar.shared.to,Boolean(bar.glide||next?.glide)):null;
      const shared=from&&to&&to.gt(from)?{start:from,length:to.sub(from)}:null;
      return {...measure,shared,scale:shared?shared.length.div(measure.length):R(1),stream:bar?.stream?.id??null,glide:Boolean(bar?.glide),
        streamStarts:Boolean(bar?.stream)&&own.bars[measure.bar-1]?.stream!==bar.stream};
    });
    part.own={measures:ownMeasures,content:mine.measures,tempo:sub.tempo,staves:mine.staves,clefs:mine.clefs,divisi:mine.divisi,acrossStaves:mine.acrossStaves,warnings:sub.warnings};
    for(const warning of sub.warnings??[])warnings.push(`${warning} (in its own meter)`);
  }
  return {title:options.title??titleOf(transcript),subtitle:options.subtitle??subtitleOf(transcript),creator:'Musebots',key,measures,parts,tempo,warnings,additiveSignatures,
    tempoCarried:carried&&{bar:carried.bar,words:carried.words,until:carried.until},source:transcript.source??null,window:{fromBar:firstBar,toBar:lastBar}};
}
// Bars `from` to `to` (measure indices) of a score, as the score prints them -- its dynamics where they change, its
// accents and articulations as the whole line reads them -- for a view that engraves a line bar by bar (the stage's
// finished line). A line crossing the cut is closed within it: a slur runs on to the last note (and on from the first,
// where it came from before), an octave sign is stated again where it goes on, a hairpin runs to the last note (its
// continuation, from nothing, would say it starts there). The score's own measures are not touched.
export function sliceScore(score,from,to=from){
  const inside=time=>time.ge(score.measures[from].start)&&time.lt(score.measures[to].start.add(score.measures[to].length));
  const parts=score.parts.map(part=>({...part,measures:part.measures.slice(from,to+1).map(content=>({...content,directions:[...content.directions],
    voices:content.voices.map(voice=>({...voice,elements:voice.elements.map(element=>({...element}))}))}))}));
  for(const part of parts){
    const lines=new Map;
    for(const content of part.measures)for(const voice of content.voices)(lines.get(`${voice.staff}|${voice.voice}`)||lines.set(`${voice.staff}|${voice.voice}`,[]).get(`${voice.staff}|${voice.voice}`)).push(...voice.elements);
    for(const elements of lines.values()){
      const notes=elements.filter(element=>!element.rest&&!element.hidden);if(!notes.length)continue;
      const first=notes[0],last=notes.at(-1);
      let slur=false,hairpin=false;
      for(const element of notes){
        if(element.slurStop&&!slur&&element!==first)first.slurStart=true;else if(element.slurStop&&!slur)element.slurStop=false;
        if(element.slurStart)slur=true;if(element.slurStop)slur=false;
        if(element.hairpinEnd&&!hairpin)element.hairpinEnd=false;
        if(element.hairpin)hairpin=true;if(element.hairpinEnd)hairpin=false;
      }
      if(slur){if(last.slurStart)last.slurStart=false;else last.slurStop=true}
      if(hairpin){if(last.hairpin){last.hairpin=null;last.hairpinText=false}else last.hairpinEnd=true}
      const signed=notes.filter(element=>element.ottava);
      if(signed.length){signed[0].ottavaStart??=signed[0].ottava;signed.at(-1).ottavaStop=true}
      // A slide the slice's edge cuts: into its first note, from a grace note at the pitch it slid from (the note it slid
      // from is left out); out of its last, none (the note it slides into is left out).
      if(first.notes.some(note=>note.slideStop!=null))first.notes=first.notes.map(({slideStop,...note})=>slideStop==null?note:{...note,graceFrom:graceOf(note.glideFrom,score.key)});
      if(last.notes.some(note=>note.slideStart!=null))last.notes=last.notes.map(({slideStart,...note})=>note);
    }
    // A tie the slice's edge cuts -- a note held over the barline into a bar left out, or from one -- is marked
    // (tieOut, tieIn): an engraving of the slice has no partner to draw it to, and draws its half (ties-across.js).
    for(const voice of part.measures.at(-1)?.voices??[]){const last=voice.elements.filter(element=>!element.rest&&!element.hidden).at(-1);if(last?.tieStart)last.tieOut=true}
    for(const voice of part.measures[0]?.voices??[]){const first=voice.elements.find(element=>!element.rest&&!element.hidden);if(first?.tieStop)first.tieIn=true}
  }
  return {...score,measures:score.measures.slice(from,to+1),parts,tempo:(score.tempo??[]).filter(mark=>inside(mark.start))};
}
// A meter's pulses, in its beats ([start, length]): a beat each in 4/4; in 7/8 or 11/8 its groups' twos and threes (a
// group of five is 3+2, as it is counted).
export function pulsesOf(meter){
  const compound=meter.denominator>=COMPOUND_FROM,groups=meter.groups?.length?meter.groups:[meter.numerator],pulses=[];let at=0;
  for(const size of groups)for(const length of compound?(size<=PULSE_GROUP?[size]:defaultGrouping(size)):Array.from({length:size},()=>1)){pulses.push([at,length]);at+=length}
  return pulses;
}
// The unit a tempo is marked in: the meter's pulse, or the dotted note of three where the bar is all threes (6/8 at a
// dotted quarter, 15/16 at a dotted eighth); bpm counts that unit. -> {bpm, beatUnit, dotted}
// A tempo of the bots' pulses as a metronome mark of the written meter: {bpm, beatUnit, dotted} (a dotted beat where the
// bar is all threes). For a page, or a cue, to print.
export const writtenTempo=(meter,bpm)=>beatOf3(writtenMeter(meter)??{numerator:COMMON_TIME.numerator,denominator:COMMON_TIME.denominator},bpm);
// Where a tempo curve has got to after `bars` of its bars, from `startBpm`, as the conductor plays it
// (public/shared/estimation/local-tempo-following.js updateLocalTempo): eased in and out, exponential, or linear.
function tempoOnCurve(startBpm,curve,bars){
  // (A curve of no bars is a step: its tempo from its bar on.)
  const x=curve.durationBars>0?Math.max(0,Math.min(1,bars/curve.durationBars)):1,mix=curve.shape==='easeInOut'?(1-Math.cos(Math.PI*x))/2:curve.shape==='exponential'?x*x:x;
  return curve.shape==='exponential'?startBpm*(curve.targetBpm/startBpm)**mix:startBpm+(curve.targetBpm-startBpm)*mix;
}
// A duration, in wholes, as one note: its type, a dot, or a triplet's (two thirds of the type); else under whatever
// tuplet makes it exact -- the power of two's note nearest it, `actual` of it in the time of `normal` (five sixteenths a
// quarter in the time of 4:5, seven a quarter at 4:7): any ratio, none refused (the owner, 2 October 2026: "The only way
// that notation should be able to cap tuplets is by renotating tuplets to divide them over a barline"). -> {type (the
// denominator: 4 a quarter), dots, tuplet ({actual, normal} or null)}; null only for no duration at all.
export function noteValue(wholes){
  const value=Rational.of(wholes);
  if(!(value.toNumber()>0))return null;
  for(let type=1;type<=64;type*=2){
    const plain=R(1,type);
    if(value.eq(plain))return {type,dots:0,tuplet:null};
    if(value.eq(plain.mul(R(3,2))))return {type,dots:1,tuplet:null};
    if(value.eq(plain.mul(R(2,3))))return {type,dots:0,tuplet:{actual:3,normal:2}};
  }
  // (The type whose share of the value is nearest one; the tuplet its share in lowest terms.)
  let type=1,share=value;
  for(let candidate=1;candidate<=1024;candidate*=2){const of=value.mul(R(candidate,1));if(Math.abs(Math.log2(of.toNumber()))<Math.abs(Math.log2(share.toNumber()))){type=candidate;share=of}}
  return {type,dots:0,tuplet:{actual:Number(share.d),normal:Number(share.n)}};
}
function beatOf3(meter,bpm){
  const reference=referenceTempo(meter,bpm);if(reference)return reference;
  // A meter that names the note its tempo counts (tempoUnit: 107/16 at a quarter of 120) is marked in that note, at its
  // tempo (the clock's bpm counts the meter's own note).
  if(meter.tempoUnit)return {bpm:bpm*meter.tempoUnit/(meter.playedDenominator??meter.denominator),beatUnit:meter.tempoUnit,dotted:false};
  // (An irrational meter written as itself: its beat no note value of its own, its mark in quarters.)
  if(!WRITTEN.includes(meter.denominator))return {bpm:bpm*QUARTER/meter.denominator,beatUnit:QUARTER,dotted:false};
  // (A pulse divided in three, written dotted: marked in its pulse, the clock's.)
  if(meter.pulse===DOTTED_GROUP)return {bpm,beatUnit:meter.denominator/2,dotted:true};
  const groups=meter.groups?.length?meter.groups:[meter.numerator];
  return meter.denominator>=QUARTER&&groups.length&&groups.every(size=>size===DOTTED_GROUP)?{bpm:bpm/DOTTED_GROUP,beatUnit:meter.denominator/2,dotted:true}:{bpm,beatUnit:meter.denominator,dotted:false};
}
const keyAlteration=(step,fifths)=>{
  const sharps='FCGDAEB',flats='BEADGCF';
  if(fifths>0&&sharps.slice(0,fifths).includes(step))return 1;
  if(fifths<0&&flats.slice(0,-fifths).includes(step))return -1;
  return 0;
};
// A part's name on the systems after the first: the bot's name without its collection's prefix and "BOT", and past ten
// letters its words but the last as initials (mh_HarmonyPulseBOT is H. Pulse, ae_WalkingBassBOT is W. Bass); one long
// word is kept to twelve.
const abbreviate=name=>{
  const [,whole,count='']=name.match(/^(.*?)((?:\s\d+)?)$/),core=whole.replace(/^(ae_|mh_|PAP_)/,'').replace(/BOT$|Bot$|_clodbot$/,'').replace(/_/g,' ').trim()||whole;
  if(core.length<=ABBREVIATION_LENGTH)return core+count;
  const words=core.split(/(?<=[a-z0-9])(?=[A-Z])|\s+/).filter(Boolean);
  return (words.length>1?[...words.slice(0,-1).map(word=>`${word[0]}.`),words.at(-1)].join(' '):core.length<=ABBREVIATION_KEEPS?core:`${core.slice(0,ABBREVIATION_LENGTH)}.`)+count;
};
function titleOf(transcript){const source=transcript.source;return source?.title??(source?.kind==='offline-render'?'An offline performance':'Musebots')}
// The day a render was made where it was made (a manifest's time is UTC: an evening render in Vancouver is dated the
// next day), as YYYY-MM-DD.
export const localDate=(time=new Date())=>{const date=new Date(time);return Number.isNaN(date.getTime())?String(time).slice(0,DATE_LENGTH):`${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`};
const MONTHS=['January','February','March','April','May','June','July','August','September','October','November','December'];
// "24 September 2026", the day where the render was made.
const longDate=time=>{const date=new Date(time);return Number.isNaN(date.getTime())?localDate(time):`${date.getDate()} ${MONTHS[date.getMonth()]} ${date.getFullYear()}`};
function subtitleOf(transcript){
  const source=transcript.source;if(!source)return null;
  // The bots are named on their staves; the subtitle says what the performance was.
  return [source.seed!=null&&`seed ${source.seed}`,source.createdAt&&longDate(source.createdAt)].filter(Boolean).join(' · ');
}
