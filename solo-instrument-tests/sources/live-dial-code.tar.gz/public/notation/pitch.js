
// Definitions: the octave's semitones and letters; a fifth's semitones, and the line of fifths repeating every twelve;
// quarter tones (two a semitone, each half of one), up to three quarters written; cents to a tenth; an alteration to a
// millionth.
const SEMITONES_PER_OCTAVE=12,LETTERS_PER_OCTAVE=7,FIFTH=7,FIFTHS_CYCLE=12,TWO_FIFTHS_CYCLES=24;
const QUARTER_TONES=2,QUARTER_TONE=.5,MAX_QUARTER_ALTERATION=1.5,TENTH_CENTS_PER_SEMITONE=1000,TENTHS=10;
export const ALTER_PRECISION=1e6;
// Choices: a pitch class is spelled from the fifths around two sharp of the key's (so a raised leading tone reads
// sharp); a pitch within this share of a semitone of one is spelled from it; cents under this are none.
const SPELLING_CENTRE=2,CENTS_TOLERANCE=.25,NO_CENTS=.05;
// Pitch spelling for a float-semitone pitch: letter, octave, accidental, and the exact alteration, microtones included.
//
// A pitch within a quarter of a semitone of a key is spelled from that key; nearer a quarter tone it takes a
// quarter-tone accidental (Stein-Zimmermann: quarter-sharp, quarter-flat, and their three-quarter forms). What is left
// over -- the 14 cents of a just third, the 31 of a seventh harmonic -- is kept exactly in MusicXML's <alter> (a
// decimal, as MusicXML 4 allows) and written beside the note in whole cents, so the score shows every pitch the bots sounded
// and a program that plays MusicXML plays it in tune. Letters come from the line of fifths around the key: the
// chromatic spelling nearest the key's diatonic centre (C sharp, E flat, F sharp, A flat, B flat in C major).

// Krumhansl and Kessler's major and minor key profiles (Krumhansl 1990, Cognitive Foundations of Musical Pitch).
const MAJOR=[6.35,2.23,3.48,2.33,4.38,4.09,2.52,5.19,2.39,3.66,2.29,2.88],MINOR=[6.33,2.68,3.52,5.38,2.60,3.53,2.54,4.75,3.98,2.69,3.34,3.17];
const LETTERS=['F','C','G','D','A','E','B'],NATURAL={C:0,D:2,E:4,F:5,G:7,A:9,B:11};
// The key signature (MusicXML fifths) of a tonic pitch class, major or minor, as keys are usually written: D flat
// and F sharp major, C sharp, E flat and G sharp minor.
const FIFTHS_OF_MAJOR=[0,-5,2,-3,4,-1,6,1,-4,3,-2,5],FIFTHS_OF_MINOR=[-3,4,-1,-6,1,-4,3,-2,5,0,-5,2];
const QUARTER_ACCIDENTALS={'-1.5':'three-quarters-flat','-1':'flat','-0.5':'quarter-flat','0':'natural','0.5':'quarter-sharp','1':'sharp','1.5':'three-quarters-sharp','-2':'flat-flat','2':'double-sharp'};
const correlate=(a,b)=>{const ma=a.reduce((s,v)=>s+v,0)/SEMITONES_PER_OCTAVE,mb=b.reduce((s,v)=>s+v,0)/SEMITONES_PER_OCTAVE;let num=0,da=0,db=0;for(let i=0;i<SEMITONES_PER_OCTAVE;i++){num+=(a[i]-ma)*(b[i]-mb);da+=(a[i]-ma)**2;db+=(b[i]-mb)**2}return da&&db?num/Math.sqrt(da*db):0};
export function keyFifths(tonic,mode='major'){return (mode==='minor'?FIFTHS_OF_MINOR:FIFTHS_OF_MAJOR)[((tonic%SEMITONES_PER_OCTAVE)+SEMITONES_PER_OCTAVE)%SEMITONES_PER_OCTAVE]}

// The key best fitting weighted pitches: {tonic, mode, fifths, confidence}; C major when nothing is pitched.
export function estimateKey(weighted){
  const histogram=new Array(SEMITONES_PER_OCTAVE).fill(0);
  for(const {pitch,weight=1} of weighted)if(Number.isFinite(pitch))histogram[((Math.round(pitch)%SEMITONES_PER_OCTAVE)+SEMITONES_PER_OCTAVE)%SEMITONES_PER_OCTAVE]+=weight;
  if(!histogram.some(Boolean))return {tonic:0,mode:'major',fifths:0,confidence:0};
  let best=null;
  for(let tonic=0;tonic<SEMITONES_PER_OCTAVE;tonic++)for(const [mode,profile] of [['major',MAJOR],['minor',MINOR]]){
    const rotated=profile.map((_,i)=>profile[(i-tonic+SEMITONES_PER_OCTAVE)%SEMITONES_PER_OCTAVE]),r=correlate(histogram,rotated);
    if(!best||r>best.confidence)best={tonic,mode,fifths:keyFifths(tonic,mode),confidence:r};
  }
  return best;
}
// A line-of-fifths position (C 0, G 1, F -1, F sharp 6, B flat -2...) as a letter and a whole-semitone alteration.
export function fifthName(f){const index=((f+1)%LETTERS_PER_OCTAVE+LETTERS_PER_OCTAVE)%LETTERS_PER_OCTAVE;return {step:LETTERS[index],alter:Math.floor((f+1)/LETTERS_PER_OCTAVE)}}
// The line-of-fifths spelling of a pitch class nearest the key's centre (fifths + 2), ties to the key's own side.
// Ties go to the spelling with fewer accidentals (B, not C flat, in E flat major), then to the key's side.
export function spellClass(pc,fifths=0){
  const base=((pc*FIFTH)%SEMITONES_PER_OCTAVE+SEMITONES_PER_OCTAVE)%SEMITONES_PER_OCTAVE,centre=fifths+SPELLING_CENTRE,accidentals=f=>Math.abs(fifthName(f).alter);let best=null;
  for(const f of [base-TWO_FIFTHS_CYCLES,base-FIFTHS_CYCLE,base,base+FIFTHS_CYCLE]){
    const d=Math.abs(f-centre);
    if(!best||d<best.d||d===best.d&&(accidentals(f)<accidentals(best.f)||accidentals(f)===accidentals(best.f)&&(fifths>0?f>best.f:f<best.f)))best={f,d};
  }
  return fifthName(best.f);
}
export const accidentalName=alter=>QUARTER_ACCIDENTALS[String(alter)]??null;

// spellPitch(pitch, {fifths}) -> {step, octave, alter (exact, may be fractional), display (the accidental's alteration:
//   whole or quarter), accidental (its MusicXML name), cents (what the accidental leaves over, rounded to 0.1)}
export function spellPitch(pitch,{fifths=0,centsTolerance=CENTS_TOLERANCE}={}){
  if(!Number.isFinite(pitch))throw new TypeError(`${pitch} is not a pitch`);
  const semitone=Math.round(pitch),offset=pitch-semitone;
  let step,display,base;
  if(Math.abs(offset)<=centsTolerance){({step,alter:display}=spellClass(((semitone%SEMITONES_PER_OCTAVE)+SEMITONES_PER_OCTAVE)%SEMITONES_PER_OCTAVE,fifths));base=semitone}
  else{
    // Nearer a quarter tone: the lower semitone raised a quarter, or the upper lowered, whichever alteration is smaller
    // (C quarter-sharp for 60.5, D quarter-flat for 61.5); a tie goes to the key's side. The shift is from each
    // semitone to the grid point itself, which is a semitone where a tolerance tighter than the default sends a pitch
    // here (60.1 at 5 cents: C, 10 cents over, not C quarter-sharp, which read back as 60.6; the mathematical audit's
    // I20, the adoption handoff's casting-memory:i20-pitch).
    const quarter=Math.round(pitch*QUARTER_TONES)/2,lower=Math.floor(quarter),upper=lower+1,options=[];
    for(const [anchor,shift] of [[lower,quarter-lower],[upper,quarter-upper]]){
      const spelled=spellClass(((anchor%SEMITONES_PER_OCTAVE)+SEMITONES_PER_OCTAVE)%SEMITONES_PER_OCTAVE,fifths),alter=spelled.alter+shift;
      if(Math.abs(alter)<=MAX_QUARTER_ALTERATION)options.push({step:spelled.step,display:alter,anchor});
    }
    options.sort((a,b)=>Math.abs(a.display)-Math.abs(b.display)||(fifths>=0?b.display-a.display:a.display-b.display));
    ({step,display}=options[0]);base=quarter;
  }
  const natural=Math.round(base-display),octave=Math.floor(natural/SEMITONES_PER_OCTAVE)-1;
  const cents=Math.round((pitch-base)*TENTH_CENTS_PER_SEMITONE)/TENTHS;
  return {step,octave,alter:Math.round((display+(pitch-base))*ALTER_PRECISION)/ALTER_PRECISION,display,accidental:accidentalName(display),cents:Math.abs(cents)<NO_CENTS?0:cents};
}
export const naturalOf=step=>NATURAL[step];
// What an accidental leaves over, as written beside the note: whole cents, signed with a true minus ("−14", "+2"); null
// under half a cent. The exact value stays in MusicXML's <alter>.
export function centsLabel(cents){const whole=Math.round(Number(cents)||0);return whole?`${whole>0?'+':'\u2212'}${Math.abs(whole)}`:null}
