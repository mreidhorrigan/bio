// A player's part from the score (the owner, 1 October 2026: "we need ability to render score vs parts, and part-scores
// in a way that have some staves quite small just for cueing"): the score's staff of one player at a part's size, and
// above it, small, the staves it is cued from -- each another player's whole staff, so that a player sees what it plays
// against, as a chamber player's small staves show it. scripts/render-score.mjs writes them (--layout parts).
//
// Which staves cue a part (cuesOf): a section's player is cued from its section's principal; a principal from the
// concertmaster (the first violins' first); the concertmaster from the principal cello, the strings' bass. Any other
// part, from the part above it in the score. Authored: an orchestra's parts carry the cues an editor chooses; these are
// where a player listens first. A caller may name its own.
//
// The cue staff's size is authored: two thirds of the part's (cue-sized notation, as engravers set it: E. Gould, Behind
// Bars, Faber 2011, would replace it with her table's figure).
export const CUE_SCALE=Object.freeze({numerator:2,denominator:3});
const SEAT=/^(vn1|vn2|va|vc|cb)\.(\d+)$/;
const CONCERTMASTER='vn1.1',PRINCIPAL_BASS_LINE='vc.1';

// The parts that cue the score's part at `index`: [indices into score.parts], in score order.
export function cuesOf(score,index){
  const parts=score.parts,own=parts[index],seat=SEAT.exec(own?.line??'');
  const at=line=>parts.findIndex(part=>part.line===line);
  let cues=[];
  if(seat){
    const principal=`${seat[1]}.1`;
    cues=own.line!==principal?[at(principal)]:own.line!==CONCERTMASTER?[at(CONCERTMASTER)]:[at(PRINCIPAL_BASS_LINE)];
  }else{
    // (The part above it, a plans staff passed over; the first part, the one below it.)
    const playing=parts.map((part,k)=>part.kind==='plans'?-1:k).filter(k=>k>=0),place=playing.indexOf(index);
    cues=place>0?[playing[place-1]]:playing.length>1?[playing[1]]:[];
  }
  return [...new Set(cues.filter(k=>k>=0&&k!==index))].sort((a,b)=>a-b);
}
// The part of the score's player at `index`, a score of its own: its cues above it, small (cue: true), then its staff;
// the score's measures, tempo and key; `chords` false, without the chord symbols the score carries (an orchestra's
// instruments read without them). -> a score (notation/score.js's form).
// (Every part its rehearsal letters, the form's words (its ending's "End") and the feels the score sets over its first
// staff alone: a player reads them in their own part -- the owner, 2 October 2026: "rehearsal letters need to appear in
// ALL parts, not just the parts derived from the tops of groups of orchestra instruments".)
const SHARED_DIRECTIONS=new Set(['rehearsal','words','feel']);
export function partScore(score,index,{cues=cuesOf(score,index),chords=true}={}){
  const found=score.parts[index];if(!found)throw new RangeError(`No part ${index} in a score of ${score.parts.length}`);
  const key=direction=>`${direction.kind}|${direction.start}|${direction.value??direction.words??''}`;
  // (In the conductor's bars, the ensemble's, never a meter of its own the conductor does not beat -- the owner, 2 October
  // 2026: "parts should generally not be written using meters different from what the conductor would see"; a part in
  // its own bars had broken them over its lines, its rests not gathered, Op. 3.9's basses'. Its own meter heard in its
  // groupings within them.)
  const own={...found,own:undefined,measures:found.measures.map((measure,m)=>{
    const have=new Set(measure.directions.map(key)),shared=score.parts.flatMap(part=>part===found?[]:part.measures[m]?.directions??[]).filter(direction=>SHARED_DIRECTIONS.has(direction.kind));
    const added=[];for(const direction of shared){const k=key(direction);if(!have.has(k)){have.add(k);added.push(direction)}}
    return added.length?{...measure,directions:[...measure.directions,...added]}:measure;
  })};
  const unchorded=part=>chords?part:{...part,measures:part.measures.map(measure=>({...measure,directions:measure.directions.filter(direction=>direction.kind!=='harmony')}))};
  return {...score,subtitle:own.name,part:own.name,parts:[...cues.filter(k=>k!==index).map(k=>unchorded({...score.parts[k],cue:true,own:undefined})),unchorded(own)],warnings:[...score.warnings]};
}
// A part's file name: its name, lower case, its words joined by hyphens, a number two digits ('Vln. I 3': vln-i-03).
export function partFile(part){
  return String(part.name).toLowerCase().replace(/\d+/g,n=>n.padStart(2,'0')).replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')||String(part.id).toLowerCase();
}
