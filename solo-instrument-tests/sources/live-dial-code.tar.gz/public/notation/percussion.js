// Where a drum is written: General MIDI percussion numbers (what the engine's drums send) on a five-line percussion
// staff, after the common drum-set key (Weinberg's, as the Percussive Arts Society published it): kick in the first
// space, snare in the third, toms around them, cymbals and hi-hat above the staff with x noteheads, the hi-hat pedal
// below; the open hi-hat is the closed one's x with the open circle above it. The feet are written as the second
// voice, stems down.
export const DRUM_KEY=Object.freeze({
  35:{name:'Acoustic bass drum',step:'E',octave:4,voice:2},36:{name:'Bass drum',step:'F',octave:4,voice:2},
  37:{name:'Side stick',step:'C',octave:5,notehead:'circle-x'},38:{name:'Snare',step:'C',octave:5},39:{name:'Hand clap',step:'D',octave:5,notehead:'x'},
  40:{name:'Electric snare',step:'C',octave:5},41:{name:'Low floor tom',step:'G',octave:4},42:{name:'Closed hi-hat',step:'G',octave:5,notehead:'x'},
  43:{name:'High floor tom',step:'A',octave:4},44:{name:'Pedal hi-hat',step:'D',octave:4,notehead:'x',voice:2},45:{name:'Low tom',step:'B',octave:4},
  46:{name:'Open hi-hat',step:'G',octave:5,notehead:'x',open:true},47:{name:'Low-mid tom',step:'D',octave:5},48:{name:'High-mid tom',step:'D',octave:5},
  49:{name:'Crash cymbal',step:'A',octave:5,notehead:'x'},50:{name:'High tom',step:'E',octave:5},51:{name:'Ride cymbal',step:'F',octave:5,notehead:'x'},
  52:{name:'China cymbal',step:'A',octave:5,notehead:'x'},53:{name:'Ride bell',step:'F',octave:5,notehead:'diamond'},54:{name:'Tambourine',step:'B',octave:5,notehead:'x'},
  55:{name:'Splash cymbal',step:'B',octave:5,notehead:'x'},56:{name:'Cowbell',step:'E',octave:5,notehead:'triangle'},57:{name:'Crash cymbal 2',step:'B',octave:5,notehead:'x'},
  59:{name:'Ride cymbal 2',step:'F',octave:5,notehead:'x'},60:{name:'High bongo',step:'E',octave:5},61:{name:'Low bongo',step:'D',octave:5},
  62:{name:'Muted high conga',step:'C',octave:5,notehead:'x'},63:{name:'Open high conga',step:'C',octave:5},64:{name:'Low conga',step:'A',octave:4},
  65:{name:'High timbale',step:'E',octave:5},66:{name:'Low timbale',step:'D',octave:5},67:{name:'High agogo',step:'G',octave:5,notehead:'triangle'},
  68:{name:'Low agogo',step:'F',octave:5,notehead:'triangle'},69:{name:'Cabasa',step:'A',octave:5,notehead:'x'},70:{name:'Maracas',step:'A',octave:5,notehead:'x'},
  75:{name:'Claves',step:'F',octave:5,notehead:'x'},76:{name:'High wood block',step:'E',octave:5,notehead:'triangle'},77:{name:'Low wood block',step:'D',octave:5,notehead:'triangle'},
  80:{name:'Muted triangle',step:'A',octave:5,notehead:'x'},81:{name:'Open triangle',step:'A',octave:5,notehead:'triangle'},
  // (Past General MIDI: the gong's 88, the suspended cymbal's 89; shared/performers/gong.js, battery.js.)
  88:{name:'Tam-tam',step:'A',octave:4,notehead:'x'},89:{name:'Suspended cymbal',step:'G',octave:5,notehead:'x'},
});
export const drumOf=note=>DRUM_KEY[note]??{name:`Percussion ${note}`,step:'B',octave:5,notehead:'x'};
