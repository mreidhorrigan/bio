// MusicXML read back into the score model (score.js buildScore's), so that the engraver (lilypond.js) writes from the
// MusicXML what it writes from the score: the specification's Engraver ingests the MusicXML the bots write
// (research/BROWSER_SCORING_PLAN.md, step 3). Written for the MusicXML this project writes (musicxml.js): each of its
// elements read as it is written; its own fields read back (METERS_FIELD, CONDENSED_FIELD, ACROSS_STAVES_FIELD,
// DIVISI_FIELD; a chord symbol's "~" in its kind's text; a woodwind's keys in words, a multiphonic's or a shaded
// fingering's); and what the score
// derives and the file does not say derived again as the score derives it -- a bar's index, a tuplet's id and an
// irrational meter's unwritten tuplet, an accidental's display, a filler voice, a woodwind's diagram where its fingering
// begins or changes. Durations exact: each a whole number of its measure's divisions, read as a fraction of a
// whole note. Tested by the round trip, score to MusicXML to score, the same LilyPond (test/musicxml-read.test.mjs).
// Besides, what a file written elsewhere says and this project's do not (they are written as they sound): a transposing
// part's <transpose>, its written pitch to its sounding (part.transpositions: [{start, semitones}]), for a Performer
// playing the file (shared/performers/musicxml-performer.js).
//
//   musicXMLToScore(text) -> score
//   parseXML(text) -> {name, attributes, children, text}: a document's root element (comments, processing
//     instructions and the DOCTYPE passed over; entities and CDATA read)
import {Rational} from '../transcript/rational.js';
import {NOTE_TYPES,noteValue,implicitTuplet} from './rhythm.js';
import {naturalOf,spellPitch} from './pitch.js';
import {PERCUSSION_LINE,DIVISI_WORDS,divisiWords} from './score.js';
import {CONDENSED_FIELD,ACROSS_STAVES_FIELD,DIVISI_FIELD,METERS_FIELD} from './musicxml.js';

// Definitions: MusicXML's conventions, as musicxml.js writes them.
// Durations count quarters; a quarter's denominator; a dot adds half. A note's dynamics are per cent of forte, MIDI
// velocity 90 of 127.
const QUARTERS_PER_WHOLE=4,QUARTER=4,DOTTED=1.5,MIDI_MAX=127,FORTE_VELOCITY=90,PER_CENT=100;
// MusicXML's voices to a staff (1-4 on the first, 5-8 on the second).
const VOICES_PER_STAFF=4;
// The octave's semitones; MIDI's octave numbering (C4 60).
const SEMITONES_PER_OCTAVE=12,OCTAVE_OFFSET=1;
// The numbers of the dashed lines (musicxml.js): a dynamic's, a tempo's, and a technique's from a voice's own on.
const HAIRPIN_DASHES=1,TEMPO_DASHES=2;
// The words' sizes that say what they are (musicxml.js): a note's timing, a chord's tuning, the words a pool that is no
// chord is written as.
const TIMING_SIZE='7',TUNING_SIZE='6.5';
const BEAT_UNITS=Object.freeze({whole:1,half:2,quarter:4,eighth:8,'16th':16,'32nd':32,'64th':64});
const ACCIDENTAL_DISPLAY=Object.freeze({'three-quarters-flat':-1.5,flat:-1,'quarter-flat':-.5,natural:0,'quarter-sharp':.5,sharp:1,'three-quarters-sharp':1.5,'flat-flat':-2,'double-sharp':2});
// A chord's note names, chords.js (a pool that is no chord written as its notes: "{C C♯ D E♭}").
const CHORD_ACCIDENTALS=Object.freeze({'𝄫':-2,'♭':-1,'♯':1,'𝄪':2});
// Cents to a tenth, none under a twentieth (pitch.js spellPitch); an alteration the same as written, within its last
// place (a millionth).
const TENTH_CENTS_PER_SEMITONE=1000,TENTHS=10,NO_CENTS=.05,SAME_ALTER=5e-7;

const R=(n,d=1)=>new Rational(n,d);
const VALUES=new Map(NOTE_TYPES.map(([type,value])=>[type,value]));
const valueOf=type=>{const value=VALUES.get(type);if(value==null)throw new RangeError(`MusicXML: no note value "${type}"`);return Rational.approximate(value)};

// ---- XML ------------------------------------------------------------------------------------------------------------
const ENTITIES=Object.freeze({amp:'&',lt:'<',gt:'>',quot:'"',apos:"'"});
const decode=text=>text.indexOf('&')<0?text:text.replace(/&(#x[0-9a-fA-F]+|#\d+|[A-Za-z]+);/g,(whole,name)=>name[0]==='#'
  ?String.fromCodePoint(name[1]==='x'||name[1]==='X'?parseInt(name.slice(2),16):Number(name.slice(1))):ENTITIES[name]??whole);
const TOKEN=/<!--[\s\S]*?-->|<\?[\s\S]*?\?>|<!\[CDATA\[([\s\S]*?)\]\]>|<!DOCTYPE(?:[^[>]|\[[\s\S]*?\])*>|<\/([^\s>]+)\s*>|<([^\s/>]+)((?:\s+[^\s=/>]+\s*=\s*(?:"[^"]*"|'[^']*'))*)\s*(\/?)>|[^<]+/y;
const ATTRIBUTE=/([^\s=]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g;
export function parseXML(text){
  const document={name:'#document',attributes:{},children:[],text:''},stack=[document];
  for(let at=0;at<text.length;){
    TOKEN.lastIndex=at;const match=TOKEN.exec(text);
    if(!match)throw new SyntaxError(`XML: cannot read at character ${at}: ${JSON.stringify(text.slice(at,at+40))}`);
    at=TOKEN.lastIndex;
    const [whole,cdata,closing,opening,attributes,empty]=match,top=stack.at(-1);
    if(opening){
      const node={name:opening,attributes:{},children:[],text:''};
      for(const [,name,double,single] of attributes.matchAll(ATTRIBUTE))node.attributes[name]=decode(double??single);
      top.children.push(node);if(!empty)stack.push(node);
    }else if(closing){if(top.name!==closing)throw new SyntaxError(`XML: </${closing}> closes <${top.name}>`);stack.pop()}
    else if(cdata!==undefined)top.text+=cdata;
    else if(whole[0]!=='<')top.text+=decode(whole);
  }
  if(stack.length>1)throw new SyntaxError(`XML: <${stack.at(-1).name}> is not closed`);
  const root=document.children[0];if(!root)throw new SyntaxError('XML: no element');
  return root;
}
const kid=(node,name)=>node?.children.find(child=>child.name===name)??null;
const kids=(node,name)=>node?node.children.filter(child=>child.name===name):[];
const textOf=(node,name)=>kid(node,name)?.text??null;
const numberOf=(node,name)=>{const text=textOf(node,name);return text==null?null:Number(text)};
// (A document's own fields, by name: <miscellaneous-field name="...">.)
const fieldsOf=identification=>new Map(kids(kid(identification,'miscellaneous'),'miscellaneous-field').map(field=>[field.attributes.name,field.text]));

// ---- pitch ----------------------------------------------------------------------------------------------------------
// A written pitch, as the score spells it (pitch.js spellPitch): its step, octave and exact alteration; its accidental's
// alteration (`display`); the cents it leaves over.
function pitchOf({step,octave,alter},display){
  const pitch=(octave+OCTAVE_OFFSET)*SEMITONES_PER_OCTAVE+naturalOf(step)+alter;
  const cents=Math.round((alter-display)*TENTH_CENTS_PER_SEMITONE)/TENTHS;
  return {pitch,spelled:{step,octave,alter,display,accidental:accidentalNameOf(display),cents:Math.abs(cents)<NO_CENTS?0:cents}};
}
const accidentalNameOf=display=>Object.entries(ACCIDENTAL_DISPLAY).find(([,value])=>value===display)?.[0]??null;
// The key's alteration of a step (its fifths: F C G D A E B sharpened, B E A D G C F flattened).
const SHARPS='FCGDAEB',FLATS='BEADGCF';
const keyAlter=(step,fifths)=>fifths>0?(SHARPS.indexOf(step)<fifths?1:0):fifths<0?(FLATS.indexOf(step)< -fifths?-1:0):0;
// A note's pitch as written, its accidental's alteration where it shows one; spelled when its bar is read (spellBar).
const WRITTEN=Symbol('written');
function writtenOf(node){
  const pitch=kid(node,'pitch'),shown=textOf(node,'accidental');
  if(shown!=null&&ACCIDENTAL_DISPLAY[shown]==null)throw new RangeError(`MusicXML: no accidental "${shown}"`);
  return {step:textOf(pitch,'step'),octave:numberOf(pitch,'octave'),alter:numberOf(pitch,'alter')??0,shown:shown==null?null:ACCIDENTAL_DISPLAY[shown]};
}
// A bar's notes spelled staff by staff, in the order they sound. A pitch as the score spells it (pitch.js spellPitch, in
// the key) where that is how it is written -- the score's own spelling, its cents too; else as a player reads it, as
// score.js marks the accidentals: what a note's accidental means where it shows none is a tied note's own, the note it
// is tied from (over a barline too, `ties`, by voice and place); else the bar's last at its step and octave on its
// staff; else the key's. Its graces before it, the note, a multiphonic's touched note, its graces after, each as a note
// at its place; the grace a glissando ends on in its own spelling, marking nothing (score.js does not mark it).
function spellBar(content,part,ties,fifths){
  if(part.kind==='percussion')return;
  for(let staff=1;staff<=part.staves;staff++){
    const marks=new Map,elements=content.voices.flatMap(voice=>voice.elements.filter(element=>(element.staff??voice.staff)===staff&&!element.rest).map(element=>({element,voice:voice.voice})))
      .sort((a,b)=>a.element.start.cmp(b.element.start));
    const spell=(target,{tieStop=false,tieStart=false,voice=null,marking=true}={})=>{
      const written=target[WRITTEN];if(!written)return;delete target[WRITTEN];
      const place=`${written.step}${written.octave}`,tied=`${voice}|${place}`;
      const read=pitchOf(written,0).pitch,spelled=spellPitch(read,{fifths});
      const own=spelled.step===written.step&&spelled.octave===written.octave&&Math.abs(spelled.alter-written.alter)<SAME_ALTER&&(written.shown==null||written.shown===spelled.display);
      const display=own?spelled.display:written.shown??(tieStop&&ties.has(tied)?ties.get(tied):marks.get(place)??keyAlter(written.step,fifths));
      Object.assign(target,own?{pitch:read,spelled}:pitchOf(written,display));
      if(!tieStop&&marking)marks.set(place,display);
      if(voice!=null){if(tieStart)ties.set(tied,display);else ties.delete(tied)}
    };
    for(const {element,voice} of elements)for(const note of element.notes){
      for(const grace of [...(note.gracesBefore??[]),...(note.graceFrom?[note.graceFrom]:[])])spell(grace);
      spell(note,{tieStop:Boolean(element.tieStop),tieStart:Boolean(element.tieStart),voice});
      if(note.multiphonic?.touchSpelled){spell(note.multiphonic.touchSpelled);note.multiphonic.touch=note.multiphonic.touchSpelled.pitch}
      for(const grace of note.gracesAfter??[])spell(grace);
      if(note.graceTo)spell(note.graceTo,{marking:false});
    }
  }
}
// A chord's note name as chords.js writes it ("C♯").
const chordNote=name=>({step:name[0],alter:CHORD_ACCIDENTALS[name.slice(1)]??0});

// ---- the score ------------------------------------------------------------------------------------------------------
export function musicXMLToScore(text){
  const root=parseXML(text);
  if(root.name!=='score-partwise')throw new Error(`MusicXML: a partwise score is read, not <${root.name}>`);
  const identification=kid(root,'identification'),fields=fieldsOf(identification);
  const credits=kids(root,'credit'),creditOf=type=>credits.find(credit=>kids(credit,'credit-type').some(each=>each.text===type));
  const meters=JSON.parse(fields.get(METERS_FIELD)??'{"bars":[]}');
  const score={title:textOf(kid(root,'work'),'work-title')??'',subtitle:fields.get('performance')??textOf(creditOf('subtitle'),'credit-words')??undefined,
    creator:kids(identification,'creator').find(creator=>creator.attributes.type==='composer')?.text??undefined,
    key:null,additiveSignatures:Boolean(meters.additiveSignatures),measures:[],parts:[],tempo:[],warnings:[]};
  const named=creditOf('part name');if(named)score.part=textOf(named,'credit-words');
  const infos=new Map(kids(kid(root,'part-list'),'score-part').map(entry=>[entry.attributes.id,partInfo(entry)]));
  for(const [index,node] of kids(root,'part').entries()){
    const info=infos.get(node.attributes.id);if(!info)throw new Error(`MusicXML: part ${node.attributes.id} is not in the part list`);
    const read=readPart(node,info,score,meters,index===0);
    score.parts.push(read);
  }
  score.key??={fifths:0,mode:'major'};
  score.tempo.sort((a,b)=>a.start.cmp(b.start));
  return score;
}
function partInfo(entry){
  const fields=fieldsOf(kid(entry,'identification')),id=entry.attributes.id;
  const instruments=new Map(kids(entry,'score-instrument').map(instrument=>[Number(instrument.attributes.id.slice(`${id}-I`.length)),{name:textOf(instrument,'instrument-name')}]));
  const desk=kids(entry,'player').map(player=>textOf(player,'player-name'));
  return {id,name:textOf(entry,'part-name')??'',abbreviation:textOf(entry,'part-abbreviation')??'',instruments,
    ...(desk.length?{desk}:{}),...(fields.get(CONDENSED_FIELD)==='yes'?{condensed:true}:{}),...(fields.get(ACROSS_STAVES_FIELD)==='yes'?{acrossStaves:true}:{}),
    ...(fields.has(DIVISI_FIELD)?{divisi:Number(fields.get(DIVISI_FIELD))}:{})};
}

// A part's measures, each read event by event; the first part's give the score its measures.
function readPart(node,info,score,meters,first){
  const part={id:info.id,name:info.name,abbreviation:info.abbreviation,kind:'pitched',staves:1,clefs:[],measures:[],
    ...(info.desk?{desk:info.desk}:{}),...(info.condensed?{condensed:true}:{}),...(info.acrossStaves?{acrossStaves:true}:{}),...(info.divisi?{divisi:info.divisi}:{})};
  const bars=new Map(meters.bars.map(bar=>[String(bar.measure),bar]));
  let divisions=1,start=R(0),meter=null,current=null,fifths=0;
  const measures=[];
  for(const measureNode of kids(node,'measure')){
    const [number,piece]=String(measureNode.attributes.number).split('-').map(Number);
    if(!piece){
      current={number,start,length:R(0),segments:[],items:[],barline:null};measures.push(current);
    }
    const segment={from:current.length,time:null},segmentStart=current.start.add(current.length);current.segments.push(segment);
    let position=R(0),reach=R(0),chordStart=R(0);
    const at=offset=>segmentStart.add(position).add(offset);
    for(const child of measureNode.children){
      if(child.name==='attributes'){
        divisions=numberOf(child,'divisions')??divisions;
        const key=kid(child,'key');if(key&&key.attributes['print-object']!=='no'){fifths=numberOf(key,'fifths');score.key??={fifths,mode:textOf(key,'mode')??'major'}}
        const time=kid(child,'time');if(time)segment.time={beats:textOf(time,'beats'),beatType:numberOf(time,'beat-type')};
        const staves=numberOf(child,'staves');if(staves)part.staves=staves;
        const transpose=kid(child,'transpose');
        if(transpose)(part.transpositions??=[]).push({start:segmentStart.add(position),semitones:(numberOf(transpose,'chromatic')??0)+SEMITONES_PER_OCTAVE*(numberOf(transpose,'octave-change')??0)});
        for(const clef of kids(child,'clef')){
          const sign=textOf(clef,'sign'),line=numberOf(clef,'line'),octave=numberOf(clef,'clef-octave-change');
          part.clefs[(Number(clef.attributes.number)||1)-1]={sign,line:sign==='percussion'?PERCUSSION_LINE:line,...(octave?{octave}:{})};
          if(sign==='percussion')part.kind='percussion';
        }
        const details=kid(child,'staff-details');if(details&&kid(details,'staff-size'))part.cue=true;
      }else if(child.name==='note'){
        const grace=Boolean(kid(child,'grace')),chord=Boolean(kid(child,'chord'));
        const duration=grace?R(0):R(numberOf(child,'duration')??0,QUARTERS_PER_WHOLE*divisions);
        const begins=chord?chordStart:position;
        current.items.push({kind:'note',node:child,start:segmentStart.add(begins),duration,grace,chord,divisions,fifths});
        if(!chord&&!grace){chordStart=position;position=position.add(duration);if(position.gt(reach))reach=position}
      }else if(child.name==='backup')position=position.sub(R(numberOf(child,'duration'),QUARTERS_PER_WHOLE*divisions));
      else if(child.name==='forward'){position=position.add(R(numberOf(child,'duration'),QUARTERS_PER_WHOLE*divisions));if(position.gt(reach))reach=position}
      else if(child.name==='direction'||child.name==='harmony'||child.name==='sound'){
        const offset=numberOf(child,'offset');current.items.push({kind:child.name,node:child,start:at(offset?R(offset,QUARTERS_PER_WHOLE*divisions):R(0))});
      }else if(child.name==='barline'){const style=textOf(child,'bar-style');if(style&&style!=='dashed')current.barline=style}
    }
    segment.length=reach;current.length=current.length.add(reach);start=start.add(reach);
  }
  // The measures: the first part's are the score's; each meter as the score counts it (METERS_FIELD), else as its
  // <time> says.
  for(const [index,measure] of measures.entries()){
    const bar=bars.get(String(measure.number)),time=measure.segments[0].time;
    if(bar)meter=bar.meter;else if(time||!meter)meter=meterOfTime(time,meter);
    const cycle=measure.segments.length>1?measure.segments.map((segment,k)=>({offset:segment.from,length:segment.length,
      meter:bar?.cycle?.[k]??meterOfTime(segment.time,null)})):null;
    if(cycle)for(let k=1;k<cycle.length;k++)if(!measure.segments[k].time&&!bar?.cycle)cycle[k].meter=cycle[k-1].meter;
    if(first)score.measures.push({index,bar:measure.number-1,number:measure.number,start:measure.start,length:measure.length,meter,
      ...(cycle?{cycle}:{}),meterChanged:bar?bar.changed:index===0||Boolean(time)});
  }
  const state={ramp:null,ties:new Map};
  part.measures=measures.map((measure,index)=>contentOf(measure,index,part,score,first,state));
  if(part.kind==='percussion')part.instruments=info.instruments;
  if(part.measures.some(content=>content.voices.some(voice=>voice.elements.some(element=>element.notes?.some(note=>note.lyric)))))part.sung=true;
  diagramsOf(part);
  return part;
}
// A meter from a <time> where the file names none of its own (a time's groups where it shows them: 2+2+3).
function meterOfTime(time,before){
  if(!time)return before;
  const groups=time.beats.split('+').map(Number),numerator=groups.reduce((sum,size)=>sum+size,0);
  return {numerator,denominator:time.beatType,...(groups.length>1?{groups}:{})};
}

// A measure's content: its voices' elements, its directions, its barline. (`state`: the part's ramp still open.)
function contentOf(measure,index,part,score,first,state){
  const voices=new Map,directions=[],pending=new Map,graces=new Map,tempo=[];
  const scoreMeasure=score.measures[index],implicit=implicitTuplet(scoreMeasure.meter);
  const brackets=new Map;  // voice -> its open tuplets, outermost first
  let fifths=0;
  const voiceOf=number=>voices.get(number)??voices.set(number,{staff:Math.min(part.staves,Math.ceil(number/VOICES_PER_STAFF)),voice:number,elements:[]}).get(number);
  const lastOf=number=>voices.get(number)?.elements.at(-1)??null;
  for(const item of measure.items){
    const node=item.node;
    if(item.kind==='note'){
      const number=numberOf(node,'voice')??1,staff=numberOf(node,'staff')??Math.min(part.staves,Math.ceil(number/VOICES_PER_STAFF));
      if(item.grace){(graces.get(number)??graces.set(number,[]).get(number)).push(graceOf(node,part));continue}
      if(item.chord){
        const element=lastOf(number);if(!element)throw new Error(`MusicXML: a chord's note with no note before it (measure ${measure.number})`);
        // (Its notes in the order written: a drum's chord in its own; a pitched chord the engraver sorts.)
        if(touching(node))touchOf(element,node);else element.notes.push(noteOf(node,item.divisions,part));
        continue;
      }
      const voice=voiceOf(number),element=elementOf(node,item,staff,voice,part);
      // (Its tuplets: the meter's unwritten one, then each bracket open at it, its own starting here.)
      const open=brackets.get(number)??brackets.set(number,[]).get(number),level=implicit?1:0,notations=kids(node,'notations').flatMap(each=>kids(each,'tuplet'));
      for(const tuplet of notations.filter(each=>each.attributes.type==='start')){
        const actual=kid(tuplet,'tuplet-actual'),normal=kid(tuplet,'tuplet-normal');
        open.push({n:numberOf(actual,'tuplet-number'),m:numberOf(normal,'tuplet-number'),unit:valueOf(textOf(actual,'tuplet-type')),span:{start:element.start.sub(scoreMeasure.start),end:null}});
        element.tupletStarts.push(open.length-1+level);
      }
      element.tuplets=[...(implicit?[implicit]:[]),...open];
      // (Its brackets' stops written innermost first, its levels outermost first.)
      for(const tuplet of notations.filter(each=>each.attributes.type==='stop')){element.tupletStops.unshift(open.length-1+level);open.pop().span.end=element.end.sub(scoreMeasure.start)}
      if(!element.rest)element.notes=[noteOf(node,item.divisions,part)];
      fifths=item.fifths;
      // (The graces before it -- after the note before, or its own -- and the directions its voice gave it.)
      element.graces=graces.get(number)??[];graces.delete(number);
      element.given=pending.get(number)??[];pending.delete(number);
      voice.elements.push(element);
    }else if(item.kind==='direction'){
      // (A dynamic or a metronome mark is the measure's, whatever voice a file gives it: this project's writes none.)
      const number=kid(kid(node,'direction-type'),'dynamics')||kid(kid(node,'direction-type'),'metronome')?null:numberOf(node,'voice');
      if(number!=null){
        const shift=kid(kid(node,'direction-type'),'octave-shift');
        if(shift?.attributes.type==='stop'){const element=lastOf(number);if(element)element.ottavaStop=true;continue}
        (pending.get(number)??pending.set(number,[]).get(number)).push(node);continue;
      }
      const read=measureDirection(node,item.start);if(!read)continue;
      if(read.kind==='tempo-part')tempo.push(read);else directions.push(read);
    }else if(item.kind==='harmony')directions.push(harmonyOf(node,item.start));
    else if(item.kind==='sound'){const quarters=Number(node.attributes.tempo);if(Number.isFinite(quarters))tempo.push({kind:'tempo-part',sound:quarters,start:item.start})}
  }
  for(const voice of voices.values()){
    voice.elements.forEach((element,k)=>{
      const before=voice.elements[k-1]??null;
      for(const read of element.graces){
        if((read.after||element.rest)&&before)addAfter(before,read);
        else if(read.joining==='slide-start'){const note=element.notes.find(each=>each.slideStop)??element.notes[0];note.graceFrom=read.grace;delete note.slideStop}
        else(element.notes[0].gracesBefore??=[]).push(read.grace);
      }
      for(const node of element.given)applyDirection(element,node);
      delete element.graces;delete element.given;
    });
    const left=graces.get(voice.voice)??[];for(const read of left)if(voice.elements.length)addAfter(voice.elements.at(-1),read);
  }
  // A chord's tuning beside its symbol.
  for(let k=directions.length-1;k>0;k--){
    if(directions[k].kind!=='tuning')continue;
    const harmony=directions.slice(0,k).reverse().find(each=>each.kind==='harmony');if(harmony){harmony.tuning=directions[k].value;harmony.tuningShown=true}
  }
  // A section's words written divisi: how many ways (DIVISI_FIELD).
  if(index===0&&part.divisi)for(const direction of directions)if(direction.kind==='formation'&&direction.value===divisiWords(part.divisi))direction.kind='divisi';
  // Tempi: the marks and their words, each ramp's line to where it arrives.
  marksOf(tempo,first?score.tempo:directions,state);
  const content={voices:[...voices.values()].sort((a,b)=>a.staff-b.staff||a.voice-b.voice),directions:directions.filter(direction=>direction.kind!=='tuning')};
  if(measure.barline)content.barline=measure.barline;
  // (A measure rest across a cycle's bars, written a measure rest in each: one.)
  if(measure.segments.length>1)for(const voice of content.voices)if(voice.elements.length===measure.segments.length&&voice.elements.every(element=>element.measureRest)){
    const [head]=voice.elements,value=noteValue(scoreMeasure.length),held=voice.elements.some(element=>element.fermata);
    voice.elements=[{...head,start:scoreMeasure.start,end:scoreMeasure.start.add(scoreMeasure.length),type:value?.type??'whole',dots:value?.dots??0,...(held?{fermata:true}:{})}];
  }
  fillersOf(content,part);
  spellBar(content,part,state.ties,fifths);
  for(const voice of content.voices)for(const element of voice.elements){
    if(part.acrossStaves)element.staff??=voice.staff;
    for(const tuplet of element.tuplets)if(!tuplet.implicit&&!tuplet.id)tuplet.id=`${tuplet.span.start}:${tuplet.span.end.sub(tuplet.span.start)}`;
  }
  return content;
}
// An element: its span, value, tuplets (by its voice), beams, ties and marks.
function elementOf(node,item,staff,voice,part){
  const rest=kid(node,'rest'),notations=kids(node,'notations');
  const element={start:item.start,end:item.start.add(item.duration),type:textOf(node,'type'),dots:kids(node,'dot').length,tuplets:[],beams:[],tupletStarts:[],tupletStops:[]};
  if(staff!==voice.staff||part.acrossStaves)element.staff=staff;
  if(rest){
    element.rest=true;
    if(rest.attributes.measure==='yes'){element.measureRest=true;const value=noteValue(item.duration);element.type=value?.type??'whole';element.dots=value?.dots??0}
    if(node.attributes['print-object']==='no')element.hidden=true;
  }
  element.beams=kids(node,'beam').map(beam=>({number:Number(beam.attributes.number),value:beam.text}));
  const ties=kids(node,'tie').map(tie=>tie.attributes.type);
  if(ties.includes('start'))element.tieStart=true;if(ties.includes('stop'))element.tieStop=true;
  const id=node.attributes.id??'';if(id.startsWith('tie-out-'))element.tieOut=true;else if(id.startsWith('tie-in-'))element.tieIn=true;
  const stem=textOf(node,'stem');
  if(textOf(node,'notehead')==='slash'&&stem==='none')element.slash=true;else if(stem)element.stem=stem;
  for(const each of notations){
    const articulations=kid(each,'articulations');
    if(kid(articulations,'accent'))element.accent=true;if(kid(articulations,'strong-accent'))element.marcato=true;
    if(kid(articulations,'staccatissimo'))element.staccatissimo=true;if(kid(articulations,'tenuto'))element.tenuto=true;
    for(const slur of kids(each,'slur')){if(slur.attributes.type==='start')element.slurStart=true;else if(slur.attributes.type==='stop')element.slurStop=true}
    if(kid(each,'fermata'))element.fermata=true;
    if(kid(each,'arpeggiate'))element.arpeggiate=true;
  }
  return element;
}
// A note: its pitch (or drum), velocity, timing against the page, and its own marks.
function noteOf(node,divisions,part){
  const note={};
  const unpitched=kid(node,'unpitched');
  if(unpitched){note.unpitched={step:textOf(unpitched,'display-step'),octave:numberOf(unpitched,'display-octave')};note.pitch=null}
  else{note[WRITTEN]=writtenOf(node);if(note[WRITTEN].shown!=null)note.accidentalShown=true}
  const dynamics=node.attributes.dynamics;if(dynamics!=null)note.velocity=Number(dynamics)/PER_CENT*FORTE_VELOCITY/MIDI_MAX;
  const attack=node.attributes.attack,release=node.attributes.release;
  if(attack!=null)note.attackWhole=Number(attack)/(QUARTERS_PER_WHOLE*divisions);
  if(release!=null)note.releaseWhole=Number(release)/(QUARTERS_PER_WHOLE*divisions);
  const instrument=kid(node,'instrument');if(instrument)note.instrument=Number(instrument.attributes.id.slice(`${part.id}-I`.length));
  const head=kid(node,'notehead');if(head&&head.text!=='slash'&&!(head.attributes.parentheses==='yes'&&head.text==='normal'))note.notehead=head.text;
  for(const each of kids(node,'notations')){
    const articulations=kid(each,'articulations');
    if(kid(articulations,'staccato'))note.staccato=true;if(kid(articulations,'breath-mark'))note.breathMark=true;
    if(kid(kid(each,'ornaments'),'tremolo'))note.rolled=true;
    for(const name of ['slide','glissando'])for(const line of kids(each,name)){
      if(line.attributes.type==='stop')note.slideStop=true;else if(line.attributes.type==='start')note.slideStart=true;
      if(name==='glissando')note.glissando=true;
    }
    const technical=kid(each,'technical');
    if(kid(technical,'open-string'))note.open=true;
    const harmonic=kid(technical,'harmonic');if(harmonic&&kid(harmonic,'natural'))note.harmonic={};
    const string=numberOf(technical,'string'),other=textOf(technical,'other-technical');
    if(other?.startsWith('multiphonic'))note.multiphonic=multiphonicOf(other,string);
    else if(other?.startsWith('fingering, '))note.fingered=diagramOf(other.slice('fingering, '.length));
    const fingerings=kids(technical,'fingering').filter(fingering=>!/^[+−-]?\d+$/.test(fingering.text)||fingering.attributes.substitution==='yes'||!note.accidentalShown);
    const digits=fingerings.filter(fingering=>/^\d$/.test(fingering.text));
    if(digits.length){const [first,...rest]=digits;note.fingering={digit:Number(first.text),hand:first.attributes.placement==='below'?'LH':'RH',...(first.attributes['font-style']==='italic'?{inferred:true}:{}),
      ...(rest.length?{substitutions:rest.map(each=>Number(each.text))}:{})}}
  }
  const lyric=kid(node,'lyric');
  if(lyric){const text=kid(lyric,'text'),extend=kid(lyric,'extend');
    note.lyric={...(text?{text:text.text,syllabic:textOf(lyric,'syllabic')}:{}),...(text?.attributes['xml:lang']?{language:text.attributes['xml:lang']}:{}),...(extend?{extend:extend.attributes.type}:{})}}
  return note;
}
// A woodwind's keys in words naming its instrument (musicxml.js: '<instrument> keys cc:one lh:thumb'), its diagram.
function diagramOf(words){
  const keys=/^(\S+) keys ?(.*)$/.exec(words);if(!keys)return null;
  const groups={cc:[],lh:[],rh:[]};for(const key of keys[2].split(' ').filter(Boolean)){const [group,name]=key.split(':');(groups[group]??=[]).push(name)}
  return {instrument:keys[1],keys:groups};
}
// A wind multiphonic's keys, in words naming its instrument (musicxml.js), or a string's on its string.
function multiphonicOf(words,string){
  const multiphonic={...(string!=null?{string:4-string}:{})};
  const diagram=words.startsWith('multiphonic, ')?diagramOf(words.slice('multiphonic, '.length)):null;
  if(diagram)multiphonic.diagram=diagram;
  return multiphonic;
}
const touching=node=>kids(node,'notations').some(each=>kid(kid(kid(each,'technical'),'harmonic'),'touching-pitch'));
// A string multiphonic's touched note, its chord's diamond: where the note before it is touched.
function touchOf(element,node){
  const note=element.notes.at(-1),written=writtenOf(node);
  note.multiphonic??={};note.multiphonic.touchSpelled={[WRITTEN]:written,accidentalShown:written.shown!=null};
}
// A grace note: before its note (and a glide's, slid from), or after the note before (a glissando's end, an ornament's).
function graceOf(node,part){
  const notations=kids(node,'notations'),slash=kid(node,'grace').attributes.slash;
  const slide=notations.some(each=>kids(each,'slide').some(line=>line.attributes.type==='start'));
  const ends=notations.some(each=>kids(each,'glissando').some(line=>line.attributes.type==='stop'));
  const grace={};
  const unpitched=kid(node,'unpitched');
  if(unpitched){grace.unpitched={step:textOf(unpitched,'display-step'),octave:numberOf(unpitched,'display-octave')}}
  else grace[WRITTEN]=writtenOf(node);
  grace.accidentalShown=textOf(node,'accidental')!=null;
  const instrument=kid(node,'instrument');if(instrument)grace.instrument=Number(instrument.attributes.id.slice(`${part.id}-I`.length));
  if(slide)return {joining:'slide-start',grace};
  if(ends)return {joining:'glissando-stop',after:true,grace};
  grace.type=textOf(node,'type');grace.dots=kids(node,'dot').length;grace.slash=slash==='yes';
  const head=textOf(node,'notehead');if(head)grace.notehead=head;
  return {after:slash==='no',grace};
}
// A grace after an element's note: a glissando's end (on the note gliding to it, where the glissando starts no note's
// slide), else an ornament after it.
function addAfter(element,{joining,grace}){
  const notes=element.notes??[];if(!notes.length)return;
  if(joining==='glissando-stop'){const note=notes.find(each=>each.slideStart)??notes[0];note.graceTo=grace;delete note.slideStart;return}
  (notes[0].gracesAfter??=[]).push(grace);
}
// A direction its voice gave the note after it: an octave sign, a hairpin, a note's timing, a section's lines dividing,
// a technique's words or its line.
function applyDirection(element,node){
  const types=kids(node,'direction-type'),placement=node.attributes.placement;
  const shift=kid(types[0],'octave-shift');
  if(shift){element.ottavaStart=shift.attributes.type==='down'?1:-1;return}
  const wedge=kid(types[0],'wedge');
  if(wedge){if(wedge.attributes.type==='stop')element.hairpinEnd=true;else element.hairpin=wedge.attributes.type==='crescendo'?'crescendo':'diminuendo';return}
  const words=kid(types[0],'words'),dashes=types.map(type=>kid(type,'dashes')).find(Boolean);
  const number=Number(dashes?.attributes.number);
  if(dashes&&number===HAIRPIN_DASHES){
    if(dashes.attributes.type==='stop'){element.hairpinEnd=true;return}
    element.hairpin=words?.text==='cresc.'?'crescendo':'diminuendo';element.hairpinText=true;return;
  }
  if(dashes&&dashes.attributes.type==='stop'){element.techniqueSpanStop=true;if(placement==='below')element.techniqueBelow=true;return}
  if(dashes){element.techniqueSpan=words.text;if(placement==='below')element.techniqueBelow=true;return}
  if(!words)return;
  if(words.attributes['font-size']===TIMING_SIZE){for(const note of element.notes??[])note.timingText=words.text;return}
  if(Object.values(DIVISI_WORDS).includes(words.text)){element.divisiText=words.text;return}
  element.techniqueText=words.text;if(placement==='below')element.techniqueBelow=true;
}
// A direction of the measure's own: a dynamic, words, a rehearsal mark, a chord's tuning, a feel, a tempo's mark, word
// or ramp, a pool that is no chord.
function measureDirection(node,start){
  const types=kids(node,'direction-type'),staff=numberOf(node,'staff')??1,placement=node.attributes.placement;
  const first=types[0];if(!first)return null;
  const dynamics=kid(first,'dynamics');
  if(dynamics){const mark=dynamics.children[0];return {kind:'dynamics',value:mark.name==='other-dynamics'?mark.text:mark.name,start,staff}}
  const rehearsal=kid(first,'rehearsal');if(rehearsal)return {kind:'rehearsal',start,value:rehearsal.text,staff};
  const metronome=kid(first,'metronome');
  if(metronome){
    const sound=kid(node,'sound'),planned=Boolean(metronome.attributes.color);
    if(numberOf(metronome,'per-minute')==null&&!kid(metronome,'per-minute'))return {kind:'tempo-part',equivalence:equivalenceOf(metronome),start,planned};
    const unit=textOf(metronome,'beat-unit');
    return {kind:'tempo-part',metronome:true,beatUnit:BEAT_UNITS[unit],dotted:Boolean(kid(metronome,'beat-unit-dot')),perMinute:numberOf(metronome,'per-minute'),
      sound:sound?Number(sound.attributes.tempo):null,start,planned};
  }
  const dashes=kid(first,'dashes');
  if(dashes&&Number(dashes.attributes.number)===TEMPO_DASHES)return {kind:'tempo-part',until:true,start};
  const words=kid(first,'words');if(!words)return null;
  const style=words.attributes['font-style'],weight=words.attributes['font-weight'],size=words.attributes['font-size'];
  if(weight==='bold'&&style==='italic')return {kind:'tempo-part',words:words.text,dashed:types.some(type=>kid(type,'dashes')),planned:Boolean(words.attributes.color),start};
  if(weight==='bold'){
    const swing=kid(kid(node,'sound'),'swing');
    return {kind:'feel',start,words:words.text,swing:swing?(kid(swing,'straight')?{straight:true}:{first:numberOf(swing,'first'),second:numberOf(swing,'second'),type:textOf(swing,'swing-type')==='16th'?'sixteenth':'eighth'}):null,staff};
  }
  if(size===TUNING_SIZE)return {kind:'tuning',value:words.text,start};
  // (A pool that is no chord, written as its notes: chords.js chordText.)
  const pool=/^\{(.*)\}(~?)$/.exec(words.text);
  if(pool&&size)return {kind:'harmony',start,chord:{kind:'other',text:'',root:chordNote(pool[1].split(' ')[0]),bass:null,degrees:[],microtonal:pool[2]==='~',notes:pool[1].split(' ').map(chordNote)},planned:Boolean(words.attributes.color),staff};
  if(size)return {kind:'words',start,value:words.text,staff,...(style?{style}:{}),size:Number(size),...(words.attributes.halign?{align:words.attributes.halign}:{}),...(placement&&placement!=='above'?{placement}:{})};
  return {kind:'formation',start,value:words.text,staff};
}
function equivalenceOf(metronome){
  const units=kids(metronome,'beat-unit');
  if(units.length===2){
    const values=[];let k=-1;
    for(const child of metronome.children){if(child.name==='beat-unit'){values.push({type:BEAT_UNITS[child.text],dots:0});k++}else if(child.name==='beat-unit-dot')values[k].dots++}
    return {from:values[0],to:values[1]};
  }
  const [from,to]=kids(metronome,'metronome-note').map(note=>{
    const tuplet=kid(note,'metronome-tuplet');
    return {type:BEAT_UNITS[textOf(note,'metronome-type')],dots:kids(note,'metronome-dot').length,...(tuplet?{tuplet:{actual:numberOf(tuplet,'actual-notes'),normal:numberOf(tuplet,'normal-notes')}}:{})};
  });
  return {from,to};
}
function harmonyOf(node,start){
  const root=kid(node,'root'),kind=kid(node,'kind'),bass=kid(node,'bass'),text=kind.attributes.text??'',microtonal=text.endsWith('~');
  return {kind:'harmony',start,chord:{root:{step:textOf(root,'root-step'),alter:numberOf(root,'root-alter')??0},kind:kind.text,text:microtonal?text.slice(0,-1):text,
    bass:bass?{step:textOf(bass,'bass-step'),alter:numberOf(bass,'bass-alter')??0}:null,
    degrees:kids(node,'degree').map(degree=>({value:numberOf(degree,'degree-value'),alter:numberOf(degree,'degree-alter')??0})),microtonal},
    planned:Boolean(node.attributes.color),staff:numberOf(node,'staff')??1};
}
// Tempo marks from their pieces, in the order written: an equivalence, the metronome mark and its sound (or a sound
// alone), then the ramp's word with its line; a line's stop where its ramp arrives, in whatever measure (`state.ramp`).
function marksOf(pieces,into,state){
  let mark=null;
  // (A mark nothing sounds for, its tempo heard from the mark before: silent.)
  const close=()=>{if(mark){if(!mark.heard)mark.silent=true;delete mark.heard;into.push(mark);mark=null}};
  const fresh=piece=>({kind:'tempo',start:piece.start,bpm:null,beatUnit:QUARTER,dotted:false,visible:false,words:null,staff:1});
  for(const piece of pieces){
    if(piece.until){close();if(state.ramp){state.ramp.until=piece.start;state.ramp=null}continue}
    if(mark&&!piece.start.eq(mark.start))close();
    if(piece.equivalence){close();mark=fresh(piece);mark.equivalence=piece.equivalence;if(piece.planned)mark.planned=true;continue}
    if(piece.metronome){
      if(mark&&(mark.visible||mark.words!=null||mark.heard))close();
      mark??=fresh(piece);mark.visible=true;mark.beatUnit=piece.beatUnit;mark.dotted=piece.dotted;if(piece.planned)mark.planned=true;
      // (Its tempo as heard, in its own beat; the whole number printed where the sound rounds to another.)
      const heard=piece.sound!=null?piece.sound*mark.beatUnit/QUARTER/(mark.dotted?DOTTED:1):null;
      mark.bpm=heard!=null&&Math.round(heard)===piece.perMinute?heard:piece.perMinute;mark.heard=piece.sound!=null;continue;
    }
    if(piece.sound!=null){if(mark&&(mark.heard||mark.words!=null))close();mark??=fresh(piece);mark.bpm=piece.sound;mark.heard=true;continue}
    if(piece.words!=null){
      if(mark&&mark.words!=null)close();mark??=fresh(piece);
      mark.words=piece.words;if(piece.planned)mark.planned=true;if(piece.dashed){mark.until=null;state.ramp=mark}continue;
    }
  }
  close();
}
// Each staff's measure rest a grand staff's line left it for (score.js layAcrossStaves): a filler voice of its own.
function fillersOf(content,part){
  if(!part.acrossStaves)return;
  const line=Math.min(...content.voices.map(voice=>voice.voice));
  for(const voice of content.voices)if(voice.voice!==line&&voice.elements.length===1&&voice.elements[0].measureRest)voice.filler=true;
}
// A woodwind's diagram over the note where its fingering begins or changes, a multiphonic's or a shaded one's (score.js).
function diagramsOf(part){
  let fingered=null;
  for(const content of part.measures)for(const voice of content.voices)for(const element of voice.elements){
    const diagram=element.notes?.find(note=>note.multiphonic?.diagram)?.multiphonic.diagram??element.notes?.find(note=>note.fingered)?.fingered??null,shown=diagram?JSON.stringify(diagram):null;
    if(shown&&shown!==fingered)element.diagram=diagram;fingered=shown;
  }
}
