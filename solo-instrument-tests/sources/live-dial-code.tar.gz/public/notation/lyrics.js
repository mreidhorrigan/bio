// Sung words as a score prints them. A sung note carries its words from its singer (a transcript note's `lyric`:
// {text, word, syllable, syllables, continues, melisma, language, after?}, from public/bots/clodbots/clodbot_singerbot.js
// through transcript/capture.js reportedNote; `before`, an opening quotation mark, where a word has one), and each is
// printed as an engraver sets lyrics:
//
//   syllables  each under the note it begins on; a tied note's later pieces carry nothing
//   hyphens    between the syllables of one word (MusicXML's syllabic begin, middle, end; LilyPond's --), across any
//              notes a syllable is held over within its word
//   extenders  a line from a word's last syllable through the notes it is held over (a melisma: its vowel sung on to
//              new pitches), to the last of them (MusicXML's extend; LilyPond's __)
//   punctuation  after its word, on the word's last syllable; an opening quotation mark before it, on its first
//
// Japanese, Chinese and Korean are printed a character (a mora, a syllable) to a note, as their scores print them: never
// hyphenated, and without the text's punctuation, which their vocal scores leave out.

// Languages whose words are neither hyphenated between their notes nor punctuated under them.
const CHARACTER_LANGUAGES=/^(?:ja|zh|yue|ko)(?:-|$)/;
export const hyphenates=language=>!CHARACTER_LANGUAGES.test(String(language??''));

// lyricMarks(notes) -> notes: each sung note of one line (in the order it is sung) given `sung`, what is printed under it:
//   {text, syllabic: 'single'|'begin'|'middle'|'end', extend: 'start'|'continue'|'stop'|null, language}
// where text is '' on a note a syllable is held over. Notes without words are left as they are.
export function lyricMarks(notes){
  // A breath the singer took before a syllable (its lyric's breathBefore, shared/performers/voice.js) is written after the
  // note before it: a breath mark.
  let before=null;
  for(const note of [...notes].sort((a,b)=>(a.start?.cmp?a.start.cmp(b.start):a.start-b.start))){if(note.lyric?.breathBefore&&before)before.breathAfter=true;if(note.lyric)before=note}
  let held=null;   // the syllable now held over further notes, and the last of them so far
  for(const note of notes){
    const lyric=note.lyric;if(!lyric||typeof lyric!=='object')continue;
    const language=lyric.language??null,melisma=Boolean(lyric.melisma)||!String(lyric.text??'').trim();
    if(melisma){
      // Held over this note: within a word the hyphen to the next syllable spans it; at a word's end, an extender.
      if(!held){note.sung={text:'',syllabic:null,extend:null,language};continue}
      if(held.extends){
        held.syllable.sung.extend??='start';
        if(held.last)held.last.sung.extend='continue';
        note.sung={text:'',syllabic:null,extend:'stop',language};
      }else note.sung={text:'',syllabic:null,extend:null,language};
      held.last=note;continue;
    }
    const words=hyphenates(language),syllables=Number(lyric.syllables)||1,index=Number(lyric.syllable)||0,continues=words&&Boolean(lyric.continues);
    const syllabic=!words||syllables<=1&&!continues?'single':index===0?(continues?'begin':'single'):(continues?'middle':'end');
    // (What stands before a word -- an opening quotation mark -- on its first syllable; what follows it, on its last.)
    const before=words&&index===0&&typeof lyric.before==='string'?lyric.before.trim():'';
    const text=`${before}${String(lyric.text).trim()}${words&&!continues&&typeof lyric.after==='string'?lyric.after.trim():''}`;
    note.sung={text,syllabic,extend:null,language};
    held={syllable:note,last:null,extends:!continues};
  }
  return notes;
}
