// Chord symbols for the harmony the bots publish, as a lead sheet names them: a pitch set (floats) named as a root, a
// base -- a triad, or a triad with its sixth or seventh -- and the tensions over it in their standard order (9, 11, 13;
// ♭9, ♯9, ♯11, ♭13), in MusicXML's vocabulary (<kind> and <degree>) and as the text a player reads: C7♯9♭13, Cmaj7♯11,
// C13♯11, C6/9, Cm(add9), C7sus4, Cm9♭5, C7alt. Every pitch class is tried as the root; the name that explains every
// note with the fewest tensions wins, a root that is the lowest note breaking ties. A name never claims a note that is
// not there (but a seventh chord's fifth). A pool with nothing chord-like (a cluster), a scale (seven notes that are no
// seventh chord without an avoid note), or eight notes or more, is named by its lowest note with the kind "other".
// Microtonal notes are named by the nearest semitone and marked.
import {spellClass} from './pitch.js';

// Definitions: the octave's semitones, half of them, its letters and its cents; intervals above a root in semitones;
// a double accidental at most; seven pitch classes a scale.
const SEMITONES_PER_OCTAVE=12,HALF_OCTAVE=6,LETTERS_PER_OCTAVE=7,CENTS_PER_SEMITONE=100,CENTS_PER_OCTAVE=1200;
const MINOR_THIRD=3,MAJOR_THIRD=4,FOURTH=5,TRITONE=6,FIFTH=7,MINOR_SIXTH=8,MAJOR_SIXTH=9,MAX_ALTERATION=2,SCALE_SIZE=7;
// Choices. A pitch more than this off its semitone is microtonal; this many pitch classes or more are no chord; a
// dominant with this many altered tensions is "7alt" (this many where its fifth is altered). Naming a chord weighs
// each reading: each tension it needs costs this, a missing fifth this, the root in the bass gains this, each of the
// kind's intervals present this, a 7♭5 or a sus2 costs this. A tone within this many cents of a just ratio is that
// ratio.
const MICROTONAL_FROM=.1,CLUSTER_FROM=8,ALTERED_FOR_ALT=3,ALTERED_FOR_ALT_WITH_FIFTH=2;
const TENSION_COST=1.2,MISSING_FIFTH_COST=.5,ROOT_IN_BASS=.8,INTERVAL_WEIGHT=.25,RARE_KIND_COST=.4,JUST_TOLERANCE=3;

// [MusicXML kind, intervals above the root, text, has a seventh]
const BASES=[
  ['major',[0,4,7],'',0],['minor',[0,3,7],'m',0],['diminished',[0,3,6],'dim',0],['augmented',[0,4,8],'+',0],
  ['suspended-fourth',[0,5,7],'sus4',0],['suspended-second',[0,2,7],'sus2',0],['power',[0,7],'5',0],
  ['major-sixth',[0,4,7,9],'6',0],['minor-sixth',[0,3,7,9],'m6',0],
  ['dominant',[0,4,7,10],'7',1],['major-seventh',[0,4,7,11],'maj7',1],['minor-seventh',[0,3,7,10],'m7',1],['major-minor',[0,3,7,11],'m(maj7)',1],
  ['diminished-seventh',[0,3,6,9],'dim7',1],['half-diminished',[0,3,6,10],'m7♭5',1],['augmented-seventh',[0,4,8,10],'7♯5',1],
  ['dominant',[0,4,6,10],'7♭5',1],['suspended-fourth',[0,5,7,10],'7sus4',1],
];
// A tension by its interval above the root: [text, MusicXML degree, alteration]. Which are tensions depends on the base.
const TENSION={1:['♭9',9,-1],2:['9',9,0],3:['♯9',9,1],5:['11',11,0],6:['♯11',11,1],8:['♭13',13,-1],9:['13',13,0]};
const ORDER=['9','11','13','♭9','♯9','♯11','♭13'];
// The letters, their natural pitch classes, and each semitone's letter step above a root (a chord spelled by its
// intervals: a third is a third letter up).
const LETTERS='CDEFGAB',NATURAL_PC={C:0,D:2,E:4,F:5,G:7,A:9,B:11},STEPS=[0,1,1,2,2,3,3,4,5,5,6,6];
// The accidentals a chord's name uses, by alteration.
const ACCIDENTAL={'-2':'𝄫','-1':'♭','0':'','1':'♯','2':'𝄪'};
// The just ratios a chord's tone is recognised as (the 13-limit, and the Pythagorean major sixth), each with its cents.
const JUST=[[1,1],[16,15],[15,14],[14,13],[13,12],[12,11],[11,10],[10,9],[9,8],[8,7],[7,6],[13,11],[6,5],[11,9],[5,4],[14,11],[9,7],[13,10],[4,3],[11,8],[7,5],[10,7],[13,9],
  [3,2],[14,9],[11,7],[8,5],[13,8],[5,3],[12,7],[7,4],[16,9],[9,5],[11,6],[13,7],[15,8],[27,16]].map(([n,d])=>({n,d,cents:CENTS_PER_OCTAVE*Math.log2(n/d)}));
const pcOf=pitch=>((Math.round(pitch)%SEMITONES_PER_OCTAVE)+SEMITONES_PER_OCTAVE)%SEMITONES_PER_OCTAVE;
// The tensions a base can carry: an interval already in the base is not one; ♯9 only over a major third; 11 not over
// sus4; ♯11 and ♭13 only where the base has its perfect fifth or a seventh; 13 over a seventh (a triad's is its sixth).
function tensionOf(interval,intervals,seventh){
  if(intervals.includes(interval)||!TENSION[interval])return null;
  if(interval===MINOR_THIRD&&!intervals.includes(MAJOR_THIRD))return null;
  if(interval===FOURTH&&intervals.includes(FOURTH))return null;
  if((interval===TRITONE||interval===MINOR_SIXTH)&&!intervals.includes(FIFTH)&&!seventh)return null;
  if(interval===MAJOR_SIXTH&&!seventh)return null;
  return TENSION[interval];
}
// The text of a base with its tensions, as lead sheets write it.
function symbol(kind,text,seventh,tensions){
  const names=tensions.map(tension=>tension[0]).sort((a,b)=>ORDER.indexOf(a)-ORDER.indexOf(b)),has=name=>names.includes(name);
  if(!names.length)return {text,kind};
  const natural=names.filter(name=>['9','11','13'].includes(name)),altered=names.filter(name=>!['9','11','13'].includes(name));
  const top=has('13')?'13':has('11')?'11':has('9')?'9':null;
  if(text==='7'){
    if(altered.length>=ALTERED_FOR_ALT)return {text:'7alt',kind:'dominant'};
    const head=top??'7';return {text:`${head}${altered.join('')}`,kind:top==='13'?'dominant-13th':top==='11'?'dominant-11th':top==='9'&&!altered.length?'dominant-ninth':'dominant'};
  }
  if(text==='7♯5'||text==='7♭5'){if(altered.length>=ALTERED_FOR_ALT_WITH_FIFTH)return {text:'7alt',kind:'dominant'};const head=top?`${top}${text.slice(1)}`:text;return {text:`${head}${altered.join('')}`,kind}}
  if(text==='maj7'){const head=top?`maj${top}`:'maj7';return {text:`${head}${altered.join('')}`,kind:!altered.length&&top?`major-${top==='9'?'ninth':`${top}th`}`:'major-seventh'}}
  if(text==='m7'){const head=top?`m${top}`:'m7';return {text:`${head}${altered.join('')}`,kind:!altered.length&&top?`minor-${top==='9'?'ninth':`${top}th`}`:'minor-seventh'}}
  if(text==='m(maj7)'&&names.join()==='9')return {text:'m(maj9)',kind};
  if(text==='m7♭5'&&natural.length&&!altered.length)return {text:`m${top}♭5`,kind};
  if(text==='7sus4'&&!altered.length&&top)return {text:`${top}sus4`,kind};
  if((text==='6'||text==='m6')&&names.join()==='9')return {text:`${text}/9`,kind};
  if(!seventh&&!text.startsWith('dim')&&!text.startsWith('+')&&!text.startsWith('sus')&&!text.startsWith('5')&&!text.endsWith('6'))return {text:`${text?`${text}(add${names.join(',')})`:`add${names.join(',')}`}`,kind};
  return {text:`${text}(${names.join(',')})`,kind};
}

// A chord's bass spelled by its interval above the root, as the chord is spelled (E♭m/G♭, not E♭m/F♯): a third is a
// third letter up. Null where that would need more than a double accidental.
function spellAbove(root,rootPc,pc){
  const step=LETTERS[(LETTERS.indexOf(root.step)+STEPS[(pc-rootPc+SEMITONES_PER_OCTAVE)%SEMITONES_PER_OCTAVE])%LETTERS_PER_OCTAVE],alter=((pc-NATURAL_PC[step])%SEMITONES_PER_OCTAVE+(SEMITONES_PER_OCTAVE+HALF_OCTAVE))%SEMITONES_PER_OCTAVE-HALF_OCTAVE;
  return Math.abs(alter)<=MAX_ALTERATION?{step,alter}:null;
}
// nameChord(pitches, {fifths}) -> {root: {step, alter}, kind, text, bass: {step, alter} | null, degrees, microtonal, pcs,
// notes?} | null; `notes` (spelled, lowest first) only for the kind "other"; `degrees` the tensions, for MusicXML.
export function nameChord(pitches,{fifths=0}={}){
  const values=pitches.map(Number).filter(Number.isFinite);if(!values.length)return null;
  const pcs=[...new Set(values.map(pcOf))],lowest=pcOf(Math.min(...values)),microtonal=values.some(pitch=>Math.abs(pitch-Math.round(pitch))>MICROTONAL_FROM);
  const spell=pc=>{const {step,alter}=spellClass(pc,fifths);return {step,alter}};
  const other=()=>({root:spell(lowest),kind:'other',text:'',bass:null,degrees:[],microtonal,pcs,notes:[...new Set([...values].sort((a,b)=>a-b).map(pcOf))].map(spell)});
  if(pcs.length>=CLUSTER_FROM)return other();
  let best=null;
  for(const root of pcs)for(const [kind,intervals,text,seventh] of BASES){
    // Every tone of the base must sound, but a seventh chord's fifth.
    if(intervals.some(interval=>!(seventh&&interval===FIFTH)&&!pcs.includes((root+interval)%SEMITONES_PER_OCTAVE)))continue;
    const rest=pcs.map(pc=>(pc-root+SEMITONES_PER_OCTAVE)%SEMITONES_PER_OCTAVE).filter(interval=>!intervals.includes(interval));
    const tensions=rest.map(interval=>tensionOf(interval,intervals,seventh));
    if(tensions.some(tension=>!tension))continue;
    const missing=seventh&&intervals.includes(FIFTH)&&!pcs.includes((root+FIFTH)%SEMITONES_PER_OCTAVE)?1:0;
    const score=-tensions.length*TENSION_COST-missing*MISSING_FIFTH_COST+(root===lowest?ROOT_IN_BASS:0)+intervals.length*INTERVAL_WEIGHT-(text==='7♭5'||text==='sus2'?RARE_KIND_COST:0);
    if(!best||score>best.score)best={root,kind,text,seventh,tensions,score};
  }
  // Seven notes are a chord only as a seventh chord with no avoid note (a natural 11 over a major third): C13♯11,
  // C7alt, Cm13; a major or mixolydian scale is not.
  if(!best||pcs.length===SCALE_SIZE&&(!best.seventh||best.tensions.some(tension=>tension[0]==='11')&&BASES.find(base=>base[2]===best.text)?.[1].includes(MAJOR_THIRD)))return other();
  const named=symbol(best.kind,best.text,best.seventh,best.tensions),root=spell(best.root);
  return {root,kind:named.kind,text:named.text,bass:best.root===lowest?null:spellAbove(root,best.root,lowest)??spell(lowest),
    degrees:best.tensions.map(([,value,alter])=>({value,alter})),microtonal,pcs};
}

// How a chord is tuned, as a player needs to know it under its symbol:
//   "equal-tempered"   every tone within a cent of equal temperament ("equal-tempered, +30¢": the whole chord shifted)
//   "just 4:5:6"       every tone a simple just interval above the root (a ratio of the 13-limit within 3 cents): the
//                      chord as a stretch of a harmonic series, root first -- 10:12:15 a just minor triad, 4:5:6:7 a
//                      harmonic seventh (the root's own deviation is its note's to show, in the staff)
//   "E −14¢, G +2¢"    otherwise, each inflected tone and its cents from equal temperament
// From the pitches that sounded (floats); the chord's symbol from nameChord.
const gcdInt=(a,b)=>{while(b){[a,b]=[b,a%b]}return a};
export function chordTuning(pitches,{fifths=0}={}){
  const values=[...new Set(pitches.map(Number).filter(Number.isFinite))].sort((a,b)=>a-b);if(!values.length)return null;
  const off=pitch=>(pitch-Math.round(pitch))*CENTS_PER_SEMITONE;
  if(values.every(pitch=>Math.abs(off(pitch))<1))return 'equal-tempered';
  // Equal-tempered intervals, the whole chord shifted: "ET, +30".
  const shift=off(values[0]);
  if(values.every(pitch=>Math.abs(off(pitch)-shift)<1)){const whole=Math.round(shift);return `equal-tempered, ${whole>0?'+':'\u2212'}${Math.abs(whole)}\u00a2`}
  const chord=nameChord(values,{fifths});
  const rootClass=chord&&chord.kind!=='other'?values.map(pcOf).find(pc=>spellClass(pc,fifths).step===chord.root.step&&spellClass(pc,fifths).alter===chord.root.alter):null;
  const root=rootClass==null?null:values.find(pitch=>pcOf(pitch)===rootClass);
  if(root!=null){
    // Each other tone as an interval above the root within an octave, matched to a just ratio.
    const tones=[...new Map(values.map(pitch=>[((pitch-root)*CENTS_PER_SEMITONE%CENTS_PER_OCTAVE+CENTS_PER_OCTAVE)%CENTS_PER_OCTAVE,pitch])).keys()].sort((a,b)=>a-b);
    const ratios=tones.map(cents=>JUST.find(ratio=>Math.abs(ratio.cents-cents)<=JUST_TOLERANCE||Math.abs(ratio.cents+CENTS_PER_OCTAVE-cents)<=JUST_TOLERANCE&&ratio.n===ratio.d));
    if(ratios.every(Boolean)){
      // Each ratio once (two tones of a class a few cents apart are one member of the chord).
      const unique=[...new Map(ratios.map(ratio=>[`${ratio.n}/${ratio.d}`,ratio])).values()];
      let lcm=1;for(const ratio of unique)lcm=lcm/gcdInt(lcm,ratio.d)*ratio.d;
      const chain=unique.map(ratio=>ratio.n*lcm/ratio.d),divisor=chain.reduce(gcdInt);
      return `just ${chain.map(value=>value/divisor).join(':')}`;
    }
  }
  // Otherwise each inflected tone, once, low to high, spelled as the chord is.
  const seen=new Set,parts=[];
  for(const pitch of values){
    const cents=Math.round(off(pitch)),pc=pcOf(pitch);if(!cents||seen.has(pc))continue;seen.add(pc);
    const {step,alter}=spellClass(pc,fifths);parts.push(`${step}${ACCIDENTAL[alter]??''} ${cents>0?'+':'\u2212'}${Math.abs(cents)}\u00a2`);
  }
  return parts.join(', ')||'equal-tempered';
}
const noteName=({step,alter})=>`${step}${ACCIDENTAL[alter]??''}`;
// The symbol as a player reads it: "Bm7♭5", "C/E", "C~" (microtonal); a pool that is no chord, its notes: "{C C♯ D E♭}".
export const chordText=chord=>{
  if(!chord)return '';
  if(chord.kind==='other')return `{${(chord.notes??[chord.root]).map(noteName).join(' ')}}${chord.microtonal?'~':''}`;
  return `${noteName(chord.root)}${chord.text}${chord.bass?`/${noteName(chord.bass)}`:''}${chord.microtonal?'~':''}`;
};
