// Which notes of a bot's motif occurrences actually began, for any host (the memorable-motifs report's ticket 5; its
// ledger, execution-ledger.js). A host shows it each batch of events it hands the bot's engine (`see`), and at each tick
// asks what has begun by the engine's clock (`begun`); it gives those to the bot (Agent.onExecuted) once each.
//   - A note is kept when the bot's strike named an occurrence for it (note-language.js strikeWith's record, found as
//     the note is taken: bot.noteLanguage).
//   - A release at or before a note's start (the engine's action 4, audio.js releaseNote) cancels it: it never begins.
//   - A note the performance ends before never begins, and is never told.
// The renderer's bot host and the page's bot card both use it, so an offline render and a live performance keep the same
// history for the same notes.
const RELEASE=4;
export function executionWatch(){
  const waiting=new Map;
  return {
    get size(){return waiting.size},
    // A batch of engine events for `bot` (as its schedule or admit takes them), and the tick they were struck on.
    see(events,bot,tick=null){
      for(const event of events||[]){
        if(event?.action===RELEASE){const note=waiting.get(event.identity);if(note&&Number(event.atSeconds)<=note.atSeconds+1e-9)waiting.delete(event.identity);continue}
        if(event?.action||!Number.isFinite(event?.atSeconds))continue;
        const frequency=Number(event.frequency),pitch=frequency>0?69+12*Math.log2(frequency/440):undefined;
        const language=bot?.noteLanguage?.({pitch,identity:event.identity});
        if(language?.occurrence)waiting.set(event.identity,{identity:event.identity,atSeconds:event.atSeconds,tick,language});
      }
    },
    // The notes that have begun by `now` (the engine's clock), in the order they began; forgotten once told.
    begun(now){
      const out=[];if(!Number.isFinite(now))return out;
      for(const [identity,note] of waiting)if(note.atSeconds<=now+1e-9){out.push(note);waiting.delete(identity)}
      return out.sort((a,b)=>a.atSeconds-b.atSeconds);
    },
  };
}
// A node's schedule and admit, wrapped so the watch sees each batch (after the node takes it: a batch it refuses
// outright is not seen). `bot` is the bot, or a function giving the bot the node now plays for. -> an unwrap function.
export function watchNode(node,watch,bot,tickOf=()=>null){
  const originals={};
  for(const method of ['schedule','admit']){
    const original=originals[method]=node?.[method];
    if(typeof original!=='function')continue;
    node[method]=(events,...rest)=>{const result=original.call(node,events,...rest);watch.see(events,typeof bot==='function'?bot():bot,tickOf());return result};
  }
  const wrappers={schedule:node?.schedule,admit:node?.admit};
  return ()=>{for(const method of ['schedule','admit'])if(node[method]===wrappers[method]&&typeof originals[method]==='function')node[method]=originals[method]};
}
