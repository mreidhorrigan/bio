// What a device can afford to play (RESEARCH_BACKLOG second queue, "Mobile loading": the phone tier of the audio
// capability tiers, desktop and plugins, browser, phone). A phone's page holds its bots' decoded recordings, its DSP core
// and the browser in far less memory than a desktop's, and its audio thread sounds far fewer voices at once. So the page
// loads its banks within a budget of decoded audio (sample-library.js), and sheds its oldest voices at a cap (audio.js),
// rather than failing or glitching.
//
// Which tier a device is in, as the browser says it (the granular player's test, granular-player.js deviceBudgetBytes):
// a phone reports a coarse pointer or itself as mobile (navigator.userAgentData.mobile); a modest machine less than
// 8 GB (navigator.deviceMemory, which browsers round and cap at 8); the rest are desktops. A page may name its tier
// (`?device=phone`), so a phone-class run is tested anywhere; an offline render names `unbounded`, so it sounds the same
// on any machine.
//
// The budgets are ours, authored until a phone is measured (the physical gate: the user's phone):
//   - decoded audio: the granular player's 48 MiB for a modest device, a phone's whole page held to it; 128 MiB for a
//     modest machine (one bank's own cap, sample-library.js); 512 MiB for a desktop, more than every bank together at
//     the seconds a bot asks of each file;
//   - voices at once: the granular player's 48 concurrent grains for a phone; 96 for a modest machine; a desktop
//     uncapped (each engine's own limits stand);
//   - one bank's own share (bankBytes): 128 MiB on any page, so no bank takes a page's whole budget; none in an offline
//     render, which holds a sampled piano's every layer (about 1.5 GiB: sample-banks.json salamanderPiano);
//   - planning (planningMs, in the milliseconds of the machine plex_clodbot's decisions were measured on:
//     shared/conducting/planning-cost.json): what a conductor may spend before its next commitment, where it is given no
//     budget or horizon of its own (Musebots 3.0's sixth lack: "a budget a deployment declares, its tier's"). A phone
//     8 ms (about 24 bars ahead, with three contingencies); a modest machine 30 ms (about 60 bars, with four); a desktop
//     and an offline render unbounded (the piece, with every contingency, as before).

// ---- Choices ---------------------------------------------------------------------------------------------------------
const MiB=1024*1024;
export const DEVICE_PROFILES=Object.freeze({
  phone:Object.freeze({tier:'phone',decodedBytes:48*MiB,voices:48,bankBytes:128*MiB,planningMs:8}),
  modest:Object.freeze({tier:'modest',decodedBytes:128*MiB,voices:96,bankBytes:128*MiB,planningMs:30}),
  desktop:Object.freeze({tier:'desktop',decodedBytes:512*MiB,voices:null,bankBytes:128*MiB,planningMs:null}),
  unbounded:Object.freeze({tier:'unbounded',decodedBytes:Infinity,voices:null,bankBytes:Infinity,planningMs:null}),
});

// The profile of the device `scope` runs on (a window, a worker's global, or a stand-in), or the one named (a tier's
// name or a profile).
export function deviceProfile(scope=globalThis,{tier=null}={}){
  if(tier!==null&&typeof tier==='object')return tier;
  if(tier!==null){const named=DEVICE_PROFILES[tier];if(!named)throw new RangeError(`a device tier is ${Object.keys(DEVICE_PROFILES).join(', ')}, not ${tier}`);return named}
  const navigator=scope?.navigator,coarse=Boolean(scope?.matchMedia?.('(pointer: coarse)')?.matches),mobile=navigator?.userAgentData?.mobile===true;
  if(coarse||mobile)return DEVICE_PROFILES.phone;
  const memory=Number(navigator?.deviceMemory);
  return Number.isFinite(memory)&&memory<8?DEVICE_PROFILES.modest:DEVICE_PROFILES.desktop;
}

// ---- Decoding a bank within a budget ---------------------------------------------------------------------------------
// The indices 0..count-1 spread: the middle first, then the ends, then the middles of the gaps between, so any prefix
// covers the whole as evenly as its count allows.
export function spreadOrder(count){
  const out=[],taken=new Set,take=index=>{if(index>=0&&index<count&&!taken.has(index)){taken.add(index);out.push(index)}};
  take(Math.floor((count-1)/2));take(0);take(count-1);
  let gaps=[[0,count-1]];
  while(gaps.length){
    const next=[];
    for(const [from,to] of gaps){if(to-from<2)continue;const middle=Math.floor((from+to)/2);take(middle);next.push([from,middle],[middle,to])}
    gaps=next;
  }
  for(let index=0;index<count;index++)take(index);
  return out;
}
// The order a bank's files are decoded in, so that whatever prefix a budget allows plays as much of the bank as it can:
//   - pitched files (a root note in the bank's metadata) spread over their range (spreadOrder), so any prefix covers the
//     range as evenly as its count allows (the engine plays the nearest sample transposed, audio.js samplePitch);
//   - a layered bank's (a velocity layer in its metadata: a piano's) a layer at a time, the layers spread as the range
//     is (the middle layer, the softest and the loudest, then between), each over the whole range, so a page that holds
//     only some of it still plays every note, soft and loud;
//   - the rest a folder at a time in turn (a kit's kicks, snares and hats before a second of any), each folder in the
//     bank's own order.
export function decodeOrder(files,metadata={}){
  const pitched=files.filter(file=>Number.isFinite(metadata?.[file]?.rootNote)).sort((a,b)=>metadata[a].rootNote-metadata[b].rootNote||a.localeCompare(b));
  const out=[];
  if(pitched.length){
    const layerOf=file=>Number.isFinite(metadata[file]?.layer)?metadata[file].layer:0,layers=[...new Set(pitched.map(layerOf))].sort((a,b)=>a-b);
    for(const layer of spreadOrder(layers.length).map(index=>layers[index])){
      const inLayer=pitched.filter(file=>layerOf(file)===layer);
      for(const index of spreadOrder(inLayer.length))out.push(inLayer[index]);
    }
  }
  const folders=new Map,isPitched=new Set(pitched);
  for(const file of files)if(!isPitched.has(file)){const folder=file.includes('/')?file.slice(0,file.lastIndexOf('/')):'';if(!folders.has(folder))folders.set(folder,[]);folders.get(folder).push(file)}
  const queues=[...folders.values()];
  for(let round=0;queues.some(queue=>round<queue.length);round++)for(const queue of queues)if(round<queue.length)out.push(queue[round]);
  return out;
}
// The fewest of a bank's files that still play all of it, as decodeOrder begins: a pitched bank's middle and ends, a
// kit one file of each folder. A bank that gives files back for another's keeps these.
export function leastKept(files,metadata={}){
  const pitched=files.filter(file=>Number.isFinite(metadata?.[file]?.rootNote)).length,folders=new Set(files.filter(file=>!Number.isFinite(metadata?.[file]?.rootNote)).map(file=>file.includes('/')?file.slice(0,file.lastIndexOf('/')):''));
  return Math.min(files.length,Math.min(3,pitched)+folders.size)||Math.min(1,files.length);
}
// A file's decoded size before it is decoded (bytes of 32-bit floats), the smaller of:
//   - its size on disk (a bank's metadata `bytes`) times DECODED_PER_BYTE: 16-bit PCM decodes to floats of twice its
//     size, resampled from 44.1 kHz to a 48 kHz context (1.09 times), so 2.25 times, which a 24-bit or 48 kHz file is
//     under;
//   - the seconds the server serves of it (a bot asks for some of each file) at the context's rate, in stereo.
// Null where neither is known: it is then decoded and counted as it is.
export const DECODED_PER_BYTE=2.25;
export function decodedEstimate(bytes,{seconds=null,sampleRate=48000}={}){
  const onDisk=Number(bytes)>0?Number(bytes)*DECODED_PER_BYTE:Infinity,served=Number(seconds)>0?Number(seconds)*sampleRate*2*4:Infinity;
  const estimate=Math.min(onDisk,served);
  return Number.isFinite(estimate)?estimate:null;
}

// ---- Voices at once --------------------------------------------------------------------------------------------------
// A device's voices, all its engines' together (one pool a context: a page's bots share one): a voice added past the
// cap sheds the oldest one not protected (its own `shed()`: faded and stopped, as a stolen voice is), and one that
// cannot shed any is refused. So the page sheds voices before it fails. No cap, and every voice is admitted.
export class VoicePool {
  constructor({cap=null}={}){this.cap=Number.isInteger(cap)&&cap>0?cap:null;this.voices=new Set;this.shed=0;this.refused=0}
  // Whether `voice` ({shed(), protected?}) may sound; the oldest it displaces shed.
  admit(voice){
    if(this.cap!==null)while(this.voices.size>=this.cap){
      let oldest=null;for(const held of this.voices)if(!held.protected){oldest=held;break}
      if(!oldest){this.refused++;return false}
      this.voices.delete(oldest);this.shed++;oldest.shed?.();
    }
    this.voices.add(voice);return true;
  }
  release(voice){this.voices.delete(voice)}
}
const pools=new WeakMap;
// A context's pool, its cap the device's voices, set the first time it is asked for (a page's engines share its one
// profile).
export function voicePool(context,profile=deviceProfile()){
  if(!pools.has(context))pools.set(context,new VoicePool({cap:profile?.voices??null}));
  return pools.get(context);
}
