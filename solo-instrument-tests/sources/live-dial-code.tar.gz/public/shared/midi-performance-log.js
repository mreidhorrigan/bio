const clamp7 = value => Math.max(0, Math.min(127, Number(value) || 0));
const clone = value => {
  if (value == null) return null;
  try {
    return JSON.parse(JSON.stringify(value));
  } catch {
    return null;
  }
};

export function decodeMidiBytes(bytes, bendRange = 48) {
  if (!Array.isArray(bytes) || bytes.length < 2) return null;
  const [status, data1, data2 = 0] = bytes.map(Number);
  if (![status, data1, data2].every(Number.isFinite)) return null;
  const command = status & 0xf0, channel = status & 0x0f;
  if (command === 0x90 && data2 > 0)
    return { type: "noteOn", channel, note: data1, value: data2 };
  if (command === 0x80 || command === 0x90)
    return { type: "noteOff", channel, note: data1, value: data2 };
  if (command === 0xe0) {
    const raw = (data1 & 0x7f) | ((data2 & 0x7f) << 7);
    return {
      type: "pitchBend",
      channel,
      raw,
      semitones: ((raw - 8192) / 8192) * bendRange,
    };
  }
  if (command === 0xd0)
    return {
      type: "pressure",
      channel,
      raw: data1,
      value: clamp7(data1) / 127,
    };
  if (command === 0xb0)
    return {
      type: data1 === 74 ? "slide" : "controlChange",
      channel,
      controller: data1,
      raw: data2,
      value: clamp7(data2) / 127,
    };
  return { type: "other", channel, data1, data2 };
}

const sourceKey = event =>
  `${event.instanceId || event.agent || "unknown"}\u0000${event.port || "unknown"}`;
const channelKey = (event, channel) => `${sourceKey(event)}\u0000${channel}`;
const activeKey = (event, channel, note) =>
  `${channelKey(event, channel)}\u0000${note}`;

// An event's time: when it was scheduled to sound, else when it was captured. Both are on the scheduler's clock
// (audio.js sendMidi sends with performance.now(), and a capture defaults to it), so they order together.
const clockNow = () => globalThis.performance?.now?.() ?? Date.now();
const timeOf = event => event.scheduledAt ?? event.capturedAt;
const eventOrder = (left, right) => timeOf(left) - timeOf(right) || left.sequence - right.sequence;

// What a replay needs at its start: each channel's controllers, the notes still sounding, and the notes already
// done. Bounded raw history is not bounded sufficient state (the mathematical audit's I19): when the oldest events
// are dropped they are folded into this, so a bend or a note-on older than every retained event still shapes the
// notes it sounds in, and a note begun before them still ends.
const freshState = () => ({ channels: new Map(), active: new Map(), activeCount: 0, notes: [], evicted: 0 });
const copyNote = note => ({ ...note, expressionEvents: [...note.expressionEvents] });
const copyState = state => ({
  channels: new Map([...state.channels].map(([key, value]) => [key, { ...value }])),
  active: new Map([...state.active].map(([key, stack]) => [key, stack.map(copyNote)])),
  activeCount: state.activeCount,
  notes: [...state.notes],
  evicted: state.evicted,
});

function replay(state, events, { maxNotes, maxActiveNotes }) {
  const { channels, active, notes } = state;
  const channelState = (event, channel) => {
    const key = channelKey(event, channel);
    if (!channels.has(key))
      channels.set(key, { bend: 0, pressure: 0, slide: 64 / 127 });
    return channels.get(key);
  };
  for (const event of events) {
    const message = event.decoded, channel = channelState(event, message.channel);
    if (message.type === "pitchBend") channel.bend = message.semitones;
    if (message.type === "pressure") channel.pressure = message.value;
    if (message.type === "slide") channel.slide = message.value;
    const timestamp = timeOf(event);
    if (message.type === "noteOn") {
      // Notes never released would otherwise be kept for ever: past the cap the longest-sounding is let go of,
      // and counted.
      if (state.activeCount >= maxActiveNotes) {
        let oldest = null;
        for (const [key, stack] of active)
          if (!oldest || stack[0].startedAt < oldest.stack[0].startedAt) oldest = { key, stack };
        oldest.stack.shift(); state.activeCount--; state.evicted++;
        if (!oldest.stack.length) active.delete(oldest.key);
      }
      const key = activeKey(event, message.channel, message.note), stack = active.get(key) || [];
      stack.push({
        schemaVersion: 1,
        id: `${sourceKey(event)}:${event.sequence}`,
        agent: event.agent,
        agentId: event.agentId,
        instanceId: event.instanceId,
        port: event.port,
        room: event.room,
        seed: event.seed,
        channel: message.channel + 1,
        midiNote: message.note,
        pitch: message.note + channel.bend,
        velocity: message.value,
        velocityNormalized: message.value / 127,
        startedAt: timestamp,
        endedAt: null,
        durationMs: null,
        releaseVelocity: null,
        startClock: clone(event.clock),
        endClock: null,
        initialExpression: {
          pitchBendSemitones: channel.bend,
          pressure: channel.pressure,
          slide: channel.slide,
        },
        intendedExpression: clone(event.expression),
        expressionEvents: [],
        active: true,
      });
      active.set(key, stack); state.activeCount++;
    } else if (message.type === "noteOff") {
      const key = activeKey(event, message.channel, message.note), stack = active.get(key);
      const note = stack?.shift();
      if (!note) continue;
      state.activeCount--;
      note.endedAt = timestamp;
      note.durationMs = Math.max(0, timestamp - note.startedAt);
      note.releaseVelocity = message.value;
      note.endClock = clone(event.clock);
      note.active = false;
      notes.push(note);
      // The latest maxNotes by start are all a report shows; trimmed in batches, not at every note.
      if (notes.length > 2 * maxNotes) {
        notes.sort((left, right) => left.startedAt - right.startedAt);
        notes.splice(0, notes.length - maxNotes);
      }
      if (!stack.length) active.delete(key);
    } else if (
      message.type === "pitchBend" ||
      message.type === "pressure" ||
      message.type === "slide"
    ) {
      for (const [key, stack] of active) {
        if (!key.startsWith(`${channelKey(event, message.channel)}\u0000`))
          continue;
        for (const note of stack)
          note.expressionEvents.push({
            offsetMs: timestamp - note.startedAt,
            type: message.type,
            value:
              message.type === "pitchBend"
                ? note.midiNote + message.semitones
                : message.value,
            raw: message.raw,
          });
      }
    }
  }
  return state;
}

export class MidiPerformanceLog {
  constructor({ maxEvents = 20000, maxNotes = 5000, maxActiveNotes = maxNotes } = {}) {
    this.maxEvents = maxEvents;
    this.maxNotes = maxNotes;
    this.limits = { maxNotes, maxActiveNotes };
    this.events = [];
    this.nextSequence = 1;
    this.observedNoteOns = 0;
    this.agents = new Set();
    this.droppedEvents = 0;
    this.refusedEvents = 0;
    this.checkpoint = freshState();
    this.checkpointAt = -Infinity;
  }
  add({
    bytes,
    scheduledAt,
    capturedAt = clockNow(),
    bendRange = 48,
    ...context
  } = {}) {
    const decoded = decodeMidiBytes(bytes, bendRange);
    if (!decoded) return null;
    // A missing scheduled time stays missing (Number(null) is 0, which would put the event at the clock's start).
    const scheduled = scheduledAt === null || scheduledAt === undefined || scheduledAt === "" ? NaN : Number(scheduledAt);
    const event = Object.freeze({
      schemaVersion: 1,
      sequence: this.nextSequence,
      capturedAt,
      scheduledAt: Number.isFinite(scheduled) ? scheduled : null,
      bendRange: Number(bendRange) || 48,
      bytes: bytes.map(value => Math.max(0, Math.min(255, Number(value) || 0))),
      decoded,
      agent: context.agent || "unknown",
      agentId: context.agentId || null,
      instanceId: context.instanceId || null,
      port: context.port || null,
      room: context.room || null,
      seed: context.seed ?? null,
      clock: clone(context.clock),
      expression: clone(context.expression),
    });
    // An event with no time, or one older than the events already folded away, cannot be placed. It is counted and
    // left out, never thrown: the log sits in the MIDI output path (audio.js sendMidi calls it before sending).
    const time = timeOf(event);
    if (!Number.isFinite(time) || time < this.checkpointAt) {
      this.refusedEvents++;
      return null;
    }
    this.nextSequence++;
    // Kept in time order. Events arrive nearly in order, so the place is found from the end.
    let at = this.events.length;
    while (at > 0 && eventOrder(this.events[at - 1], event) > 0) at--;
    this.events.splice(at, 0, event);
    if (decoded.type === "noteOn") this.observedNoteOns++;
    this.agents.add(event.agent);
    if (this.events.length > this.maxEvents) {
      const dropped = this.events.splice(0, this.events.length - this.maxEvents);
      replay(this.checkpoint, dropped, this.limits);
      this.checkpointAt = timeOf(dropped[dropped.length - 1]);
      this.droppedEvents += dropped.length;
    }
    return event;
  }
  clear() {
    this.events.length = 0;
    this.observedNoteOns = 0;
    this.agents.clear();
    this.droppedEvents = 0;
    this.refusedEvents = 0;
    this.checkpoint = freshState();
    this.checkpointAt = -Infinity;
  }
  quickSummary() {
    return {
      retainedEvents: this.events.length,
      observedNoteOns: this.observedNoteOns,
      droppedEvents: this.droppedEvents,
      refusedEvents: this.refusedEvents,
      agents: [...this.agents].filter(Boolean).sort(),
    };
  }
  // The notes, replayed from the checkpoint through the retained events (already in time order).
  replayed() {
    return replay(copyState(this.checkpoint), this.events, this.limits);
  }
  notes({ includeActive = true } = {}) {
    const state = this.replayed(), notes = [...state.notes];
    if (includeActive)
      for (const stack of state.active.values())
        for (const note of stack) notes.push(note);
    return notes
      .sort((left, right) => left.startedAt - right.startedAt)
      .slice(-this.maxNotes)
      .map(copyNote);
  }
  report(metadata = {}) {
    const state = this.replayed(), notes = this.notes(), completed = notes.filter(note => !note.active);
    return {
      schema: "musebots-midi-performance-log",
      schemaVersion: 1,
      exportedAt: new Date().toISOString(),
      metadata: clone(metadata) || {},
      summary: {
        retainedEvents: this.events.length,
        retainedNotes: notes.length,
        completedNotes: completed.length,
        activeNotes: notes.length - completed.length,
        observedNoteOns: this.observedNoteOns,
        droppedEvents: this.droppedEvents,
        refusedEvents: this.refusedEvents,
        evictedActiveNotes: state.evicted,
        truncated: this.droppedEvents > 0,
        checkpointAt: Number.isFinite(this.checkpointAt) ? this.checkpointAt : null,
        agents: [...new Set(notes.map(note => note.agent))].sort(),
        ports: [...new Set(notes.map(note => note.port).filter(Boolean))].sort(),
      },
      notes,
      events: [...this.events],
    };
  }
}
