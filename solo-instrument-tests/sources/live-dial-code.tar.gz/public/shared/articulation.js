// How a note moves between its note-on and the end of its release, for every kind of instrument
// the bots play.
//
// `expression.js` decides a note's *performance*: how hard it is struck, how pressure and
// brightness move through it, how its pitch drifts and wavers. This decides its *instrument*: a
// plucked string starts bright and darkens as it rings, a piano's note falls quickly and then
// slowly, a bowed note swells into its tone, a kick drum drops two octaves in its first thirty
// milliseconds. Until now the Rust voice had one envelope for all of them -- a line up, a flat
// top, a line down -- so the kinds of instrument differed only in waveform and length. The shape
// computed here fills every slot the voice has (wasm/dsp-core/src/lib.rs, SHAPE_*), and it is
// also what the MIDI outputs describe with the registered sound controllers, so a note sent to a
// synthesizer carries its articulation as well as its pitch and velocity.
//
// Pure functions and plain data: the Max for Live runtime imports this, and it has no browser.

// The slots of a shaped voice, in the order the engine reads them. `test/articulation.test.mjs`
// checks this list against the Rust constants, so the two cannot drift apart.
export const SHAPE = Object.freeze({
  attack: 0, attackCurve: 1, decay: 2, sustain: 3, release: 4, releaseCurve: 5,
  filterMode: 6, cutoff: 7, keytrack: 8, resonance: 9, filterEnv: 10, filterAttack: 11,
  filterDecay: 12, filterSustain: 13, velocityCutoff: 14, brightnessRange: 15,
  pressureBrightness: 16, pressureFloor: 17, pitchEnv: 18, pitchTime: 19, timbreEnv: 20,
  timbreDecay: 21, noiseLevel: 22, noiseDecay: 23, noiseSustain: 24, noiseMode: 25,
  noiseCutoff: 26, noiseResonance: 27, drive: 28, pan: 29, unisonCents: 30, unisonMix: 31,
  subLevel: 32, velocity: 33, vibratoDelay: 34, vibratoFade: 35, pulseWidth: 36, sustainDecay: 37,
  pitchEnv2: 38, pitchTime2: 39,
  // 1: a voice no other note may take while it sounds (a held sound object, a tail listened to): the engine steals around
  // it and refuses a note rather than take it (wasm/dsp-core SHAPE_PROTECTED; the extreme-aesthetics report's E19).
  protected: 40,
});
export const SHAPE_LENGTH = 41;
export const FILTER = Object.freeze({onePole: 0, lowpass: 1, bandpass: 2, highpass: 3, none: 4});
export const MODEL = Object.freeze({sine: 0, noise: 1, additive: 2, fm: 3, feedbackFm: 4,
  triangle: 5, saw: 6, square: 7, sweep: 8, noiseDecay: 9, metal: 10, clap: 11});
export const WAVE_MODELS = Object.freeze({sine: 0, triangle: 5, sawtooth: 6, square: 7});

const clamp = (value, low, high) => Math.max(low, Math.min(high, value));
const clamp01 = value => clamp(Number(value) || 0, 0, 1);
const finite = (value, fallback) => (Number.isFinite(Number(value)) ? Number(value) : fallback);

// Where a note sits, 0 at C2 and 1 at C7. Most of what changes across an instrument's compass --
// how long a string rings, how bright it is -- is a function of this.
export const registerOf = note => clamp01((finite(note, 60) - 36) / 60);

// ---- velocity to level ------------------------------------------------------------------------
//
// Roger Dannenberg measured how commercial synthesizers turn MIDI velocity into level and found a
// square law fits them: amplitude = (m·v + b)², with m and b chosen so velocity 127 is full level
// and velocity 1 is 1/r of it, r being the instrument's dynamic range ("The Interpretation of
// MIDI Velocity", ICMC 2006). That is the curve here, per family, with its own range.
//
// It is pivoted at the velocity bots most often play, 0.7, where the level is exactly what the
// bot's own voice asked for: the ensemble's balance is unchanged at a typical velocity, and a
// hard or soft note moves away from it by as much as that instrument would. Before this the
// voices mapped velocity to gain as `a + b·v` with a floor, which spans about 5 dB from the
// softest note to the loudest -- velocity was barely audible as level.
export const VELOCITY_PIVOT = 0.7;
// `exponent` 2 is Dannenberg's square law. An instrument measured to follow another power has its
// own: a piano's radiated level goes as velocity to the 2.4 (Goebl & Bresin 2003: about 65, 80, 88,
// 94 and 99 dB SPL at velocities 20 to 100, 34 dB between the two ends), which a square law over
// its range cannot give. The range is still velocity 1 against 127.
export function velocityAmplitude(velocity, rangeDb = 30, exponent = 2) {
  const p = Math.max(1, exponent), a = 10 ** (-Math.max(1, rangeDb) / (20 * p));
  return (a + (1 - a) * clamp01(velocity)) ** p;
}
// The level of a note of this velocity relative to one at the pivot.
// Bounded cache keyed by both curve parameters; no mutable family object key.
const velocityCurves = new Map();
export function velocityGain(velocity, rangeDb = 30, exponent = 2) {
  const p = Math.max(1, exponent), range = Math.max(1, rangeDb), key = range + ':' + p;
  let curve = velocityCurves.get(key);
  if (!curve) {
    const a = 10 ** (-range / (20 * p)), b = 1 - a;
    curve = {a, b, p, pivot:(a + b * VELOCITY_PIVOT) ** p};
    velocityCurves.set(key, curve);
    if (velocityCurves.size > 64) velocityCurves.delete(velocityCurves.keys().next().value);
  }
  return (curve.a + curve.b * clamp01(velocity)) ** curve.p / curve.pivot;
}

// ---- decay times across the compass -----------------------------------------------------------
// A struck or plucked string rings longer the lower it is (research/expression-and-mixing-
// references.md has the sources).
//   piano: the fundamental's T60, from measured loss fits: C2 about 28 s, C4 6.2 s, C7 0.6 s,
//     whatever the dynamic (Bensa et al. 2003; Cheng et al. 2015). 6.2 s halving every 11
//     semitones meets all three.
//   guitar: a classical guitar's 247 Hz note, from measured Q: the fundamental's T60 about 5.6 s,
//     its partials at 1.7-2.2 kHz about 1.7 s (Woodhouse 2004). The fall across the compass,
//     halving every 20 semitones, is ours.
const pluckRing = note => clamp(5.6 * 2 ** (-(finite(note, 60) - 59) / 20), 0.6, 12);
// Exported for the performers' piano planner (shared/performers/piano.js), which must agree with the voice about which
// keys ring on and for how long.
export const pianoRing = note => clamp(6.2 * 2 ** (-(finite(note, 60) - 60) / 11), 0.5, 30);
// Keys above F6 have no dampers (Askenfelt & Jansson; Lehtonen et al. 2009), so they ring on.
export const UNDAMPED = 89;

const base = () => ({
  attack: 0.008, attackCurve: 0.6, decay: 0, sustain: 1, release: 0.08, releaseCurve: 1,
  filterMode: FILTER.lowpass, cutoff: 1400, keytrack: 0.6, resonance: 0.12, filterEnv: 0,
  filterAttack: 0.002, filterDecay: 0, filterSustain: 1, velocityCutoff: 1, brightnessRange: 1,
  pressureBrightness: 0, pressureFloor: 0.5, pitchEnv: 0, pitchTime: 0, timbreEnv: 0,
  timbreDecay: 0, noiseLevel: 0, noiseDecay: 0, noiseSustain: 0, noiseMode: FILTER.bandpass,
  noiseCutoff: 3000, noiseResonance: 0.1, drive: 0, pan: 0, unisonCents: 0, unisonMix: 0,
  subLevel: 0, velocity: 0.5, vibratoDelay: 0, vibratoFade: 0, pulseWidth: 0.5, sustainDecay: 0,
  pitchEnv2: 0, pitchTime2: 0,
});

// A note's context: what every family reads.
//   note       float MIDI pitch (microtonal)
//   velocity   0..1, the performed velocity
//   duration   seconds to note-off
//   legato     true when the note is joined to the one before it
//   accent     0..1, a bot's own accent where it has one
//   pan        -1..1, where the note sits
//   variant    a family's sub-kind, e.g. 'open' for a hi-hat
function context({note = 60, velocity = 0.65, duration = 0.25, legato = false, accent = null,
  pan = 0, variant = null} = {}) {
  const v = clamp01(velocity);
  return {note: finite(note, 60), v, duration: Math.max(0.005, finite(duration, 0.25)),
    r: registerOf(note), legato: Boolean(legato), accent: accent === null ? v : clamp01(accent),
    pan: clamp(finite(pan, 0), -1, 1), variant};
}

// The families. Each is the instrument a group of bots plays, with:
//   profile   the expression.js profile its performance curves use
//   rangeDb   its dynamic range, for velocityGain()
//   model     the oscillator it plays when a caller does not name one
//   vibrato   delay, fade, rate and depth of the performer's vibrato on sustained notes, or null
//   scoop     a sung or blown onset: semitones below, and seconds to arrive, or null
//   glide     seconds a legato note takes to arrive from the one before, or null
//   shape     the engine's slots for one note
//
// The numbers are our choices unless a comment names a measurement; the measurements used are
// listed, with their sources, in research/expression-and-mixing-references.md. Cutoffs are set
// against the voice they replace: ABI 1's one-pole sat near 3 kHz at middle C at a middling
// brightness, and a two-pole at about two-thirds of that has a similar spectral centroid, so a
// family is darker or brighter than that on purpose rather than by accident.
export const FAMILIES = Object.freeze({
  // A plucked string: bright at the pick, darkening as it rings, ringing longer when low.
  pluck: {
    profile: 'pluck', rangeDb: 30, model: MODEL.saw, vibrato: null, scoop: null, glide: null,
    shape: c => ({
      attack: 0.0012 + 0.002 * (1 - c.v), attackCurve: 1,
      decay: pluckRing(c.note), sustain: 0, release: 0.05 + 0.07 * (1 - c.r),
      cutoff: 1100, keytrack: 0.8, resonance: 0.12,
      // The upper partials die in about 0.3 of the fundamental's time (1.7 s against 5.6 at 247 Hz).
      filterEnv: 1.6 + 2.2 * c.v, filterDecay: 0.3 * pluckRing(c.note), filterSustain: 0.25,
      velocityCutoff: 1.6, brightnessRange: 1.4, pressureFloor: 0.75,
      // The pick itself, and the string's pitch settling from slightly sharp as it loses tension.
      noiseLevel: 0.4 * c.v ** 1.5, noiseDecay: 0.004, noiseCutoff: 2200 + 2600 * c.v, noiseResonance: 0.2,
      pitchEnv: 0.1 * c.v, pitchTime: 0.04,
    }),
  },
  // A piano's strings: struck, a prompt sound that falls quickly and an aftersound that falls
  // slowly, much brighter when played harder, the unison strings a hair apart.
  keys: {
    profile: 'keys', rangeDb: 90, velocityExponent: 2.4, model: MODEL.saw, vibrato: null, scoop: null, glide: null,
    shape: c => ({
      attack: 0.0015 + 0.003 * (1 - c.v), attackCurve: 1,
      decay: 0.5 + 0.9 * (1 - c.r), sustain: 0.38, sustainDecay: pianoRing(c.note),
      // A damper stops the strings with a T60 of 0.3-0.7 s, the low ones slowest (Askenfelt &
      // Jansson; Lehtonen et al. 2009); above F6 there is none.
      release: c.note >= UNDAMPED ? pianoRing(c.note) : 0.3 + 0.4 * (1 - c.r),
      cutoff: 900, keytrack: 0.9, resonance: 0.05,
      filterEnv: 1.4 + 1.8 * c.v, filterDecay: 0.8 + 1.4 * (1 - c.r), filterSustain: 0.35,
      velocityCutoff: 2.6, brightnessRange: 1.2, pressureFloor: 0.8,
      noiseLevel: 0.3 * c.v ** 2, noiseDecay: 0.005, noiseCutoff: 900 + 2200 * c.r, noiseResonance: 0.1,
      unisonCents: 1.2, unisonMix: 0.3,
    }),
  },
  // An electric piano's tine, as FM: the bark of a hard note is a modulation index that falls away.
  epiano: {
    profile: 'keys', rangeDb: 32, model: MODEL.fm, vibrato: null, scoop: null, glide: null,
    // The bark grows with the square of velocity and is smaller up the compass, where a tine
    // is shorter and barks less: a mezzo-forte chord is round, a forte one bites.
    shape: c => ({
      attack: 0.0025 + 0.002 * (1 - c.v), attackCurve: 0.8, decay: 1.2 + 1.5 * (1 - c.r), sustain: 0.35,
      sustainDecay: 3 + 4 * (1 - c.r), release: 0.22,
      filterMode: FILTER.none, timbreEnv: (0.2 + 1.8 * c.v ** 2) * (1 - 0.5 * c.r),
      timbreDecay: 0.12 + 0.1 * (1 - c.v), velocityCutoff: 1, brightnessRange: 1, pressureFloor: 0.8,
    }),
  },
  // Plucked by fingers: a thump, a bright start that closes, a long even ring.
  bass: {
    profile: 'bass', rangeDb: 26, model: MODEL.saw, vibrato: null, scoop: null, glide: 0.05,
    shape: c => ({
      attack: 0.003 + 0.005 * (1 - c.v), attackCurve: 1, decay: 1.4, sustain: 0.45,
      sustainDecay: 5 + 3 * (1 - c.r), release: 0.06,
      cutoff: 500, keytrack: 0.5, resonance: 0.1,
      filterEnv: 1.1 + 1.4 * c.v, filterDecay: 0.28, filterSustain: 0.3, velocityCutoff: 1.3,
      pressureFloor: 0.7, subLevel: 0.25 * (1 - c.r),
      noiseLevel: 0.18 * c.v, noiseDecay: 0.005, noiseCutoff: 900, noiseResonance: 0.15,
      pitchEnv: 0.06, pitchTime: 0.03,
    }),
  },
  // A synthesizer bass: square or saw into a resonant filter with a snapping envelope.
  synthBass: {
    profile: 'bass', rangeDb: 22, model: MODEL.square, vibrato: null, scoop: null, glide: 0.04,
    shape: c => ({
      attack: 0.0015, attackCurve: 1, decay: 0.35, sustain: 0.55, release: 0.05,
      cutoff: 420, keytrack: 0.4, resonance: 0.32,
      filterEnv: 2 + 1.5 * c.v, filterDecay: 0.2 + 0.1 * (1 - c.v), filterSustain: 0.15,
      velocityCutoff: 1.2, drive: 0.12 + 0.22 * c.v, subLevel: 0.25, pressureFloor: 0.7,
      pulseWidth: c.variant === 'snap' ? 0.32 : 0.5,
    }),
  },
  // The TB-303 kind: a resonant filter that an accent opens further and closes faster, and a
  // slide that carries the pitch into a tied note.
  acid: {
    profile: 'bass', rangeDb: 18, model: MODEL.saw, vibrato: null, scoop: null, glide: 0.06,
    shape: c => ({
      attack: 0.002, attackCurve: 1, decay: 1, sustain: 0.7, release: 0.03,
      cutoff: 180 + 1100 * clamp01(c.filter ?? 0.4), keytrack: 0.3,
      resonance: 0.62 + 0.25 * c.accent,
      filterEnv: 2.2 + 2 * c.accent, filterDecay: 0.3 - 0.14 * c.accent, filterSustain: 0,
      velocityCutoff: 0.6, drive: 0.18 + 0.2 * c.accent, pressureFloor: 0.75,
    }),
  },
  // A synthesizer line: plucky, a filter that snaps shut, the sequenced melody of a loop.
  synthPluck: {
    profile: 'pluck', rangeDb: 24, model: MODEL.saw, vibrato: null, scoop: null, glide: null,
    shape: c => ({
      attack: 0.0015, attackCurve: 1, decay: 0.6 + 0.4 * (1 - c.r), sustain: 0.18, release: 0.08,
      cutoff: 950, keytrack: 0.6, resonance: 0.28,
      filterEnv: 2.2 + 1.8 * c.v, filterDecay: 0.14 + 0.08 * (1 - c.v), filterSustain: 0.2,
      velocityCutoff: 1.5, brightnessRange: 1.5, pressureFloor: 0.7, pulseWidth: 0.42,
    }),
  },
  // A sustained melodic voice: its tone blooms after the onset, it scoops a little into
  // expressive notes, and a held note gathers a vibrato that fades in.
  lead: {
    profile: 'lead', rangeDb: 24, model: MODEL.saw,
    vibrato: {delay: 0.24, fade: 0.36, rate: 5.6, depth: 0.16}, scoop: {semitones: 0.18, seconds: 0.05},
    glide: 0.07,
    shape: c => ({
      attack: 0.006 + 0.03 * (1 - c.v), attackCurve: 0.6, decay: 0.6, sustain: 0.82,
      release: 0.1 + 0.1 * Math.min(1, c.duration),
      cutoff: 1600, keytrack: 0.7, resonance: 0.18,
      filterEnv: 1.2 + 0.9 * c.v, filterAttack: 0.01, filterDecay: 0.5, filterSustain: 0.5,
      velocityCutoff: 1.2, brightnessRange: 1.4, pressureBrightness: 0.8, pressureFloor: 0.35,
      unisonCents: 6, unisonMix: 0.25,
    }),
  },
  // Bowed strings: the bow takes time to catch, pressure is tone, the hair adds a little noise,
  // and vibrato comes in once the note has settled.
  bowed: {
    profile: 'pad', rangeDb: 24, model: MODEL.saw,
    // Violinists' vibrato: 5.5-5.9 Hz and 34-58 cents peak to peak (students), 6.6 Hz and 63 cents
    // (soloists) (MacLeod 2008): so +-20 cents at the middle of the pressure range. A bowed
    // attack: sustained strings speak in 14-85 ms (Luce & Clark 1965).
    vibrato: {delay: 0.18, fade: 0.3, rate: 5.8, depth: 0.2}, scoop: null, glide: 0.09,
    shape: c => ({
      attack: 0.04 + 0.05 * (1 - c.v), attackCurve: 0.4, decay: 1, sustain: 0.9,
      release: 0.2 + 0.18 * (1 - c.v),
      cutoff: 1500, keytrack: 0.8, resonance: 0.12,
      filterEnv: 0.6, filterAttack: 0.08, filterDecay: 0.6, filterSustain: 0.7,
      velocityCutoff: 1, brightnessRange: 1.2, pressureBrightness: 1.5, pressureFloor: 0.25,
      noiseSustain: 0.035, noiseCutoff: 2800, noiseResonance: 0.3, unisonCents: 3, unisonMix: 0.3,
    }),
  },
  // A synthesizer pad: a slow swell, detuned voices, a filter that opens with the swell.
  pad: {
    profile: 'pad', rangeDb: 18, model: MODEL.saw, vibrato: null, scoop: null, glide: null,
    shape: c => {
      const attack = Math.min(0.45 * c.duration, 0.12 + 0.7 * (1 - c.v) + 0.06 * Math.min(8, c.duration));
      return {attack, attackCurve: 0.3, decay: 2, sustain: 0.85,
        release: 0.5 + 0.1 * Math.min(10, c.duration),
        cutoff: 1400, keytrack: 0.5, resonance: 0.14,
        filterEnv: 1, filterAttack: attack * 1.5, filterDecay: 3, filterSustain: 0.6,
        velocityCutoff: 0.8, brightnessRange: 1.5, pressureBrightness: 1.2, pressureFloor: 0.3,
        unisonCents: 9, unisonMix: 0.6};
    },
  },
  // A drone: slower still, and it drifts rather than swells.
  drone: {
    profile: 'drone', rangeDb: 12, model: MODEL.saw, vibrato: null, scoop: null, glide: null,
    shape: c => {
      const attack = Math.min(0.45 * c.duration, 0.6 + 2.4 * (1 - c.v));
      return {attack, attackCurve: 0.2, decay: 4, sustain: 0.9,
        release: 1.2 + 0.1 * Math.min(20, c.duration),
        cutoff: 1000, keytrack: 0.4, resonance: 0.22,
        filterEnv: 0.8, filterAttack: attack * 1.3, filterDecay: 6, filterSustain: 0.5,
        velocityCutoff: 0.6, brightnessRange: 1.5, pressureBrightness: 1.2, pressureFloor: 0.3,
        unisonCents: 5, unisonMix: 0.5, subLevel: 0.2 * (1 - c.r)};
    },
  },
  // An organ or a plain oscillator: on and off, with the key's click.
  organ: {
    profile: 'keys', rangeDb: 14, model: MODEL.sine, vibrato: null, scoop: null, glide: null,
    shape: c => ({
      attack: 0.005, attackCurve: 0.5, release: 0.05, filterMode: FILTER.lowpass,
      cutoff: 2600, keytrack: 0.8, resonance: 0.05, velocityCutoff: 0.6, pressureFloor: 0.6,
      noiseLevel: 0.06 * c.v, noiseDecay: 0.0015, noiseMode: FILTER.highpass, noiseCutoff: 2500,
    }),
  },
  // A bell or a struck bar, as FM: bright at the strike, the upper partials going first.
  bell: {
    profile: 'pluck', rangeDb: 30, model: MODEL.fm, vibrato: null, scoop: null, glide: null,
    shape: c => ({
      attack: 0.001, attackCurve: 1, decay: 2.6 - 1.6 * c.r, sustain: 0, release: 0.3,
      filterMode: FILTER.none, timbreEnv: 0.8 + 1.4 * c.v, timbreDecay: 0.18 + 0.2 * (1 - c.r),
      brightnessRange: 1, pressureFloor: 0.8,
    }),
  },
  // Additive partials, as bc.resynth_bot rebuilds an analysed sound: a gentle onset, the upper
  // partials brighter at the start and settling, the whole decaying toward a held level.
  partials: {
    profile: 'texture', rangeDb: 20, model: MODEL.additive, vibrato: null, scoop: null, glide: null,
    shape: c => ({
      attack: Math.min(0.45 * c.duration, 0.01 + 0.08 * (1 - c.v)), attackCurve: 0.6,
      decay: 1.5 + 1.5 * (1 - c.r), sustain: 0.6, release: 0.3, filterMode: FILTER.none,
      timbreEnv: 0.5 + 0.8 * c.v, timbreDecay: 0.35, brightnessRange: 1, velocityCutoff: 1, pressureFloor: 0.4,
    }),
  },
  // A held FM texture: an index that settles, slow amplitude motion.
  fmTexture: {
    profile: 'texture', rangeDb: 16, model: MODEL.fm, vibrato: null, scoop: null, glide: null,
    shape: c => ({
      attack: Math.min(0.45 * c.duration, 0.03 + 0.12 * Math.min(3, c.duration)), attackCurve: 0.4,
      decay: 2, sustain: 0.7, release: 0.35, filterMode: FILTER.none,
      timbreEnv: 0.4 + 0.6 * c.v, timbreDecay: 0.6, brightnessRange: 1.2, pressureFloor: 0.35,
    }),
  },
  // A whistle or a flute: breath under the tone, a chiff at the start, a vibrato that comes late.
  wind: {
    profile: 'lead', rangeDb: 20, model: MODEL.sine,
    vibrato: {delay: 0.3, fade: 0.4, rate: 5, depth: 0.09}, scoop: {semitones: 0.1, seconds: 0.04},
    glide: 0.06,
    shape: c => ({
      attack: 0.05 + 0.06 * (1 - c.v), attackCurve: 0.5, decay: 0.5, sustain: 0.9, release: 0.1,
      filterMode: FILTER.lowpass, cutoff: 3000, keytrack: 1, resonance: 0.05, pressureFloor: 0.2,
      pressureBrightness: 0.6,
      noiseSustain: 0.05 + 0.04 * (1 - c.v), noiseLevel: 0.18 * c.v, noiseDecay: 0.025,
      noiseCutoff: clamp(440 * 2 ** ((c.note - 69) / 12) * 3, 900, 9000), noiseResonance: 0.25,
    }),
  },
  // A slow, soft texture: swells and fades, nothing struck.
  texture: {
    profile: 'texture', rangeDb: 14, model: MODEL.triangle, vibrato: null, scoop: null, glide: null,
    shape: c => {
      const attack = Math.min(0.45 * c.duration, 0.15 + 0.6 * (1 - c.v));
      return {attack, attackCurve: 0.3, decay: 2, sustain: 0.8, release: 0.6 + 0.05 * Math.min(10, c.duration),
        cutoff: 1600, keytrack: 0.5, resonance: 0.18, filterEnv: 0.5, filterAttack: attack,
        filterDecay: 2, filterSustain: 0.5, brightnessRange: 1.4, pressureBrightness: 1, pressureFloor: 0.3};
    },
  },
  // A resonant plucked voice: mh_GroanBOT's source is plucked and resonant, not breathy.
  resonant: {
    profile: 'lead', rangeDb: 24, model: MODEL.triangle, vibrato: null, scoop: null, glide: null,
    shape: c => ({
      attack: 0.012, attackCurve: 0.8, decay: 0.8 + 0.6 * (1 - c.r), sustain: 0.4, release: 0.12,
      cutoff: 900, keytrack: 0.7, resonance: 0.45, filterEnv: 1.6 + 1.2 * c.v, filterDecay: 0.35,
      filterSustain: 0.35, velocityCutoff: 1.2, pressureFloor: 0.5,
    }),
  },
  // The instrument MemoryBot previews a stored clip with: a triangle through a gentle lowpass, as
  // the preview always was, now shaped by whatever articulation the clip recorded.
  preview: {
    profile: 'keys', rangeDb: 24, model: MODEL.triangle, vibrato: null, scoop: null, glide: null,
    shape: () => ({attack: 0.006, attackCurve: 0.5, release: 0.05, cutoff: 2400, keytrack: 0.7,
      resonance: 0.05, velocityCutoff: 1, pressureFloor: 0.4}),
  },
  // ---- drums: each is an instrument of its own, not a pitch --------------------------------
  // The kick: a sine that starts two to three octaves up and falls to its note in tens of
  // milliseconds, the beater's click on top, harder hits sweeping further and driving harder.
  kick: {
    profile: 'pluck', rangeDb: 28, model: MODEL.sine, vibrato: null, scoop: null, glide: null, percussion: true,
    shape: c => ({
      attack: 0.0008, attackCurve: 1, decay: 0.35 + 0.25 * c.v, sustain: 0, release: 0.04,
      filterMode: FILTER.lowpass, cutoff: 2600, keytrack: 0, resonance: 0.05, velocityCutoff: 1,
      // The TR-808's: its first 5-6 ms near 2.6 times the frequency, then a drop of 7-10 Hz that
      // settles within 80-150 ms (Roland service notes; Werner, Abel & Smith 2014). Two returns:
      // 16.5 semitones (2.6x) on a 2.2 ms time constant, and 2.6 semitones on 35 ms.
      pitchEnv: 16.5, pitchTime: 0.0022, pitchEnv2: 2.6, pitchTime2: 0.035,
      noiseLevel: 0.12 + 0.3 * c.v, noiseDecay: 0.0025, noiseMode: FILTER.highpass, noiseCutoff: 1400,
      drive: 0.08 + 0.2 * c.v, pressureFloor: 1,
    }),
  },
  // A tom: the kick's sweep, shallower and higher.
  tom: {
    profile: 'pluck', rangeDb: 28, model: MODEL.sine, vibrato: null, scoop: null, glide: null, percussion: true,
    shape: c => ({
      attack: 0.0008, attackCurve: 1, decay: 0.3 + 0.3 * c.v, sustain: 0, release: 0.05,
      filterMode: FILTER.lowpass, cutoff: 3000, keytrack: 0.5, velocityCutoff: 1,
      // A struck tom starts sharp by 7 per cent (mp) to 20-25 per cent (ff), falling back with a
      // time constant of 50-60 ms (Dahl 1997; Kirby & Sandler 2020).
      pitchEnv: 12 * Math.log2(1.07 + 0.155 * c.v), pitchTime: 0.055,
      noiseLevel: 0.2 + 0.3 * c.v, noiseDecay: 0.004, noiseMode: FILTER.bandpass, noiseCutoff: 1800,
      pressureFloor: 1,
    }),
  },
  // The snare's shell: a short, falling tone. Its wires are `snareWires`, played beside it.
  snareBody: {
    profile: 'pluck', rangeDb: 28, model: MODEL.triangle, vibrato: null, scoop: null, glide: null, percussion: true,
    shape: c => ({
      attack: 0.0006, attackCurve: 1, decay: 0.09 + 0.05 * c.v, sustain: 0, release: 0.03,
      filterMode: FILTER.lowpass, cutoff: 1800, keytrack: 0, velocityCutoff: 1.2,
      pitchEnv: 4 + 3 * c.v, pitchTime: 0.012, pressureFloor: 1,
    }),
  },
  // The wires: noise, bright, ringing longer than the shell; a harder hit rings longer.
  snareWires: {
    profile: 'pluck', rangeDb: 30, model: MODEL.noise, vibrato: null, scoop: null, glide: null, percussion: true,
    shape: c => ({
      attack: 0.0006, attackCurve: 1, decay: 0.14 + 0.14 * c.v, sustain: 0, release: 0.04,
      filterMode: FILTER.bandpass, cutoff: 3000 + 2500 * c.v, keytrack: 0, resonance: 0.08,
      velocityCutoff: 0.8, pressureFloor: 1,
    }),
  },
  // Hi-hats and cymbals: the TR-808's six square waves through a highpass (a hat) or a bandpass
  // (a ride), decaying short when closed and long when open.
  hat: {
    profile: 'pluck', rangeDb: 26, model: MODEL.metal, vibrato: null, scoop: null, glide: null, percussion: true,
    shape: c => {
      const open = c.variant === 'open', ride = c.variant === 'ride';
      return {attack: 0.0004, attackCurve: 1,
        // An 808's closed hat is 20 dB down in 50 ms (T60 about 150); its open hat 90-600 ms
        // (Werner et al. 2014). The ride is an acoustic cymbal's, longer than the 808's.
        decay: ride ? 1.2 + 0.8 * c.v : open ? 0.35 + 0.3 * c.v : 0.12 + 0.06 * c.v, sustain: 0,
        release: open || ride ? 0.1 : 0.015,
        filterMode: ride ? FILTER.bandpass : FILTER.highpass, cutoff: ride ? 5200 : 6800 + 1500 * c.v,
        keytrack: 0, resonance: ride ? 0.18 : 0.25, velocityCutoff: 0.6, pressureFloor: 1,
        // A ride's wash is broadband as well as metallic; a hat's sizzle sits higher.
        noiseSustain: ride ? 0.45 : 0.25, noiseMode: FILTER.highpass, noiseCutoff: ride ? 6000 : 8500, noiseResonance: 0.1};
    },
  },
  // A hand clap: three quick bursts and a tail, as the TR-808 makes one.
  clap: {
    profile: 'pluck', rangeDb: 26, model: MODEL.clap, vibrato: null, scoop: null, glide: null, percussion: true,
    shape: c => ({
      attack: 0.0004, attackCurve: 1, decay: 0.18 + 0.12 * c.v, sustain: 0, release: 0.04,
      filterMode: FILTER.bandpass, cutoff: 1100 + 500 * c.v, keytrack: 0, resonance: 0.22, pressureFloor: 1,
    }),
  },
  // Hand percussion and struck noise: a short, filtered noise with the ring of its filter.
  shaker: {
    profile: 'pluck', rangeDb: 24, model: MODEL.noise, vibrato: null, scoop: null, glide: null, percussion: true,
    shape: c => ({
      attack: 0.001 + 0.003 * (1 - c.v), attackCurve: 0.8, decay: Math.max(0.03, c.duration * 1.4), sustain: 0,
      release: 0.02, filterMode: FILTER.bandpass, cutoff: c.cutoffHz ?? 4000, keytrack: 0,
      resonance: 0.3, velocityCutoff: 0.8, pressureFloor: 1,
    }),
  },
  // Noise as a bed or a gust: filtered, faded in and out, nothing struck.
  noise: {
    profile: 'texture', rangeDb: 12, model: MODEL.noise, vibrato: null, scoop: null, glide: null, percussion: false,
    shape: c => {
      const long = c.duration >= 0.3;
      return {attack: long ? Math.min(0.2, c.duration * 0.12) : Math.min(0.003, c.duration * 0.12),
        attackCurve: 0.4, decay: 0, sustain: 1,
        release: long ? Math.min(0.25, c.duration * 0.15) : Math.min(0.012, c.duration * 0.25),
        filterMode: FILTER.bandpass, cutoff: c.cutoffHz ?? 3000, keytrack: 0, resonance: 0.08,
        velocityCutoff: 0, pressureFloor: 1};
    },
  },
});
export const FAMILY_NAMES = Object.freeze(Object.keys(FAMILIES));

// What each family is on a mixing desk, for a desk that processes channels by role (public/shared/
// mix-approaches.js): the kit, the bass, sustained harmony, struck or plucked harmony, a line, and
// everything that is colour rather than part. A bowed family plays both lines and held chords; it
// is mixed as held harmony, which is what it mostly is here. The preview voice has no role.
// (vocal: a singing voice, the lead the desk's measurements were read on. No category maps to it: a bot declares it, as the
// singer does, in its definition's deskRole.)
export const ROLES = Object.freeze(['drums', 'bass', 'pad', 'keys', 'lead', 'texture', 'vocal']);
export const FAMILY_ROLES = Object.freeze({
  kick: 'drums', tom: 'drums', snareBody: 'drums', snareWires: 'drums', hat: 'drums', clap: 'drums', shaker: 'drums',
  bass: 'bass', synthBass: 'bass', acid: 'bass',
  pad: 'pad', drone: 'pad', organ: 'pad', bowed: 'pad',
  keys: 'keys', epiano: 'keys', pluck: 'keys', synthPluck: 'keys',
  lead: 'lead', wind: 'lead',
  bell: 'texture', partials: 'texture', fmTexture: 'texture', texture: 'texture', resonant: 'texture', noise: 'texture',
});
// What a bot's declared category (its definition's `category`, the function it publishes: mh_CoordBOT ranks the foreground
// by it) is on a desk. A declared role is the channel's role whatever instruments it plays -- a melody bot on a pluck is
// the lead, a beat bot the drums, whose hits count no family -- and a bot that declares none (a utility, a conductor)
// takes its role from the families it plays.
export const CATEGORY_ROLES = Object.freeze({
  melody: 'lead', beat: 'drums', bass: 'bass', harmony: 'keys', 'keys-pads': 'pad', 'texture-noise': 'texture', texture: 'texture',
});

// What each expression.js profile falls back to when a caller names a profile but no family.
export const PROFILE_FAMILIES = Object.freeze({
  neutral: 'organ', bass: 'bass', pluck: 'synthPluck', lead: 'lead', keys: 'keys', pad: 'pad',
  drone: 'drone', texture: 'texture',
});
export const familyFor = (name, profile = 'neutral') =>
  FAMILIES[name] ? name : PROFILE_FAMILIES[profile] || 'organ';

/**
 * The engine's slots for one note.
 *
 * @param family  a FAMILIES key
 * @param note    see context() above for every field
 * @param overrides  slot values that win over the family's
 * @param options.releaseScale  the family's release time is multiplied by this
 * @returns {values, array, family, rangeDb}: named values, and the SHAPE_LENGTH array the
 *   engine takes, missing slots as null so the engine uses its own default
 */
export function noteShape(family, note = {}, overrides = {}, {releaseScale = 1} = {}) {
  const name = FAMILIES[family] ? family : 'organ', definition = FAMILIES[name],
    c = {...context(note), filter: note.filter, cutoffHz: note.cutoffHz};
  const shaped = {...base(), ...definition.shape(c), velocity: c.v, pan: c.pan};
  shaped.release *= clamp(finite(releaseScale, 1), 0.25, 4);
  const values = {...shaped, ...overrides};
  // Nothing may outlast the note it belongs to by less than the time it takes to begin.
  values.attack = Math.min(values.attack, Math.max(0.0005, c.duration * 0.9));
  const array = Array(SHAPE_LENGTH).fill(null);
  for (const [key, index] of Object.entries(SHAPE)) {
    const value = Number(values[key]);
    array[index] = Number.isFinite(value) ? value : null;
  }
  return {values, array, family: name, rangeDb: definition.rangeDb};
}

// How long a note sounds after its note-off.
export const releaseSeconds = shape => finite(shape?.values?.release ?? shape?.array?.[SHAPE.release], 0.08);

// ---- the same articulation as MIDI -----------------------------------------------------------
//
// MIDI's registered sound controllers describe exactly these things: Sound Controller 4 (#73)
// attack time, 6 (#75) decay time, 3 (#72) release time, 2 (#71) timbre or harmonic intensity,
// 5 (#74) brightness, and #10 pan. MIDI 2.0 carries every one of them per note, as Registered
// Per-Note Controllers (M2-104-UM v1.1.1, Appendix A, Table 22); MIDI 1.0 carries them per
// channel, which under MPE is per note too. Their values are relative to the receiving patch,
// the centre meaning "as the patch has it" (MMA RP-021), so times are sent as how far they are
// from a neutral reference, on a log scale: four octaves either way across the range. A
// receiver without them ignores them; our own replay reads them back into a shape.
export const ARTICULATION_CONTROLLERS = Object.freeze({
  attack: {controller: 73, reference: 0.01},
  decay: {controller: 75, reference: 1},
  release: {controller: 72, reference: 0.3},
});
const OCTAVES = 4;
export function timeToBipolar(seconds, reference) {
  return clamp(Math.log2(Math.max(1e-4, seconds) / reference) / OCTAVES, -1, 1);
}
export function bipolarToTime(value, reference) {
  return reference * 2 ** (clamp(value, -1, 1) * OCTAVES);
}
// -1..1 to the 32-bit per-note controller value, centred at 0x80000000 as the spec centres it.
export const bipolar32 = value => Math.round(0x80000000 + clamp(value, -1, 1) * (value < 0 ? 0x80000000 : 0x7fffffff));
export const bipolarFrom32 = value => (value - 0x80000000) / (value < 0x80000000 ? 0x80000000 : 0x7fffffff);
export const unit32 = value => Math.round(clamp01(value) * 0xffffffff);
export const bipolar7 = value => clamp(Math.round(64 + clamp(value, -1, 1) * 63), 1, 127);

// The controllers one note's shape sends. `timbre` and `pan` are the note's own controls
// (0.5 and 0 are the centre, and are not sent).
export function articulationOf(shape, {timbre = 0.5, pan = null} = {}) {
  const values = shape?.values || {};
  const sounds = [];
  for (const [key, {controller, reference}] of Object.entries(ARTICULATION_CONTROLLERS)) {
    const seconds = key === 'decay'
      ? (values.sustain >= 1 || !values.decay ? null : values.decay)
      : values[key];
    if (!Number.isFinite(seconds)) continue;
    sounds.push({controller, key, bipolar: timeToBipolar(seconds, reference)});
  }
  if (Math.abs(timbre - 0.5) > 1e-3) sounds.push({controller: 71, key: 'timbre', bipolar: clamp((timbre - 0.5) * 2, -1, 1)});
  const place = pan ?? values.pan ?? 0;
  if (Math.abs(place) > 1e-3) sounds.push({controller: 10, key: 'pan', bipolar: clamp(place, -1, 1)});
  return sounds;
}

// And back: a stored clip's registered controllers, as the overrides of a shape. What a MIDI 2
// clip says about attack, decay and release is heard when MemoryBot replays it.
export function shapeFromArticulation(controllers = {}) {
  const overrides = {};
  for (const [key, {controller, reference}] of Object.entries(ARTICULATION_CONTROLLERS)) {
    const value = controllers[controller];
    if (!Number.isFinite(value)) continue;
    overrides[key] = bipolarToTime(value, reference);
    if (key === 'decay') {overrides.sustain = 0.3}
  }
  if (Number.isFinite(controllers[10])) overrides.pan = clamp(controllers[10], -1, 1);
  return overrides;
}

// Controls as the voice should hear them: each point of a curve reached, in a straight line, at
// the moment it was recorded for. A control is given at the previous point's time with the
// distance to its own as its ramp. Before this every point was a five-millisecond step, so a
// pressure swell recorded as three points over four seconds was heard as two jumps.
export function rampedControls(controls){
  if(!controls.length)return controls;
  const byAction=new Map(),ramped=[];
  for(const control of controls){
    if(!byAction.has(control.action))byAction.set(control.action,[]);
    byAction.get(control.action).push(control);
  }
  for(const list of byAction.values()){
    list.sort((a,b)=>a.seconds-b.seconds);
    list.forEach((control,index)=>{
      if(control.action===4){ramped.push(control);return}
      if(index===0){ramped.push({...control,ramp:control.seconds<=1e-9?0:.005});return}
      const previous=list[index-1];
      ramped.push({...control,seconds:previous.seconds,ramp:Math.max(0,control.seconds-previous.seconds)});
    });
  }
  return ramped.sort((a,b)=>a.seconds-b.seconds);
}
