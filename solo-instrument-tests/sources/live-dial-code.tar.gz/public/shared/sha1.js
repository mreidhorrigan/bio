// SHA-1 (FIPS 180-4) of a string's UTF-8 bytes, as hex, at once: what Node's createHash('sha1') gives, in a page or a
// Worker too, where the browser's own digest waits on a promise. For keys kept on the Mac and read in a page alike (the
// winds' glides, native/openwind/blend.mjs Glides), never for security.
const encoder=new TextEncoder();
const rotl=(x,n)=>x<<n|x>>>32-n;

export function sha1Hex(text){
  const bytes=encoder.encode(text),n=bytes.length,blocks=(n+8>>6)+1,w=new Uint32Array(blocks*16);
  for(let i=0;i<n;i++)w[i>>2]|=bytes[i]<<24-(i&3)*8;
  w[n>>2]|=0x80<<24-(n&3)*8;
  // (Its length in bits, as two words: the high word what a 32-bit shift drops.)
  w[blocks*16-2]=Math.floor(n/0x20000000);w[blocks*16-1]=n*8>>>0;
  let h0=0x67452301,h1=0xefcdab89,h2=0x98badcfe,h3=0x10325476,h4=0xc3d2e1f0;
  const m=new Uint32Array(80);
  for(let b=0;b<blocks;b++){
    for(let t=0;t<16;t++)m[t]=w[b*16+t];
    for(let t=16;t<80;t++)m[t]=rotl(m[t-3]^m[t-8]^m[t-14]^m[t-16],1);
    let a=h0,bb=h1,c=h2,d=h3,e=h4;
    for(let t=0;t<80;t++){
      const f=t<20?bb&c|~bb&d:t<40?bb^c^d:t<60?bb&c|bb&d|c&d:bb^c^d,k=t<20?0x5a827999:t<40?0x6ed9eba1:t<60?0x8f1bbcdc:0xca62c1d6;
      const next=rotl(a,5)+f+e+k+m[t]>>>0;
      e=d;d=c;c=rotl(bb,30)>>>0;bb=a;a=next;
    }
    h0=h0+a>>>0;h1=h1+bb>>>0;h2=h2+c>>>0;h3=h3+d>>>0;h4=h4+e>>>0;
  }
  return [h0,h1,h2,h3,h4].map(h=>h.toString(16).padStart(8,'0')).join('');
}
