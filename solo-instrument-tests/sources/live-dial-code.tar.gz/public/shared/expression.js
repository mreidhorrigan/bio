import {nestedWeights,sectionAt} from './metric-home/sections.js';

const clamp01 = (value) => Math.max(0, Math.min(1, Number(value) || 0));
const finite = (value, fallback) =>
  Number.isFinite(Number(value)) ? Number(value) : fallback;
const curve = (value, fallback) =>
  Object.freeze(
    (Array.isArray(value) && value.length > 1 ? value : fallback).map(clamp01),
  );

// A long bar heard in sections (meter.sections, metric-home/sections.js; RESEARCH_BACKLOG P1, "Extreme meters, made
// perceptible"): a group's start is accented by how many levels begin there, between a group's accent and a bar's, and
// every note is played at its section's dynamic, so the sections are heard apart and every level as a level.
export function metricalVelocity(velocity, clock = {}) {
  const config=CONFIG.velocityVariation,
    base=clamp01(finite(velocity,.65));
  if(!Number.isFinite(Number(clock.tick)))return base;
  const
    phraseBars=Math.max(1,Number(clock.meter?.phraseBars)||4),
    numerator=Math.max(1,Number(clock.meter?.numerator)||4),
    phrasePosition=(
      ((Number(clock.bar)||0)%phraseBars)+
      Math.max(0,Math.min(1,(Number(clock.beat)||0)/numerator))
    )/phraseBars,
    phrase=config.phraseFloor+config.phraseArch*Math.sin(Math.PI*phrasePosition),
    nested=nestedWeights(clock.meter),
    unit=Math.floor((Number(clock.tickInBar)||0)/Math.max(1,Number(clock.meter?.subdivision)||1)),
    metric=clock.phraseStart?config.phraseAccent
      :clock.barStart?config.barAccent
      :nested&&clock.beatStart&&nested[unit]>0?config.groupAccent+(config.barAccent-config.groupAccent)*(nested[unit]-1)/Math.max(1,nested[0]-1)
      :clock.groupStart?config.groupAccent
      :clock.beatStart?config.beatAccent
      :config.subdivisionScale,
    tick=(Number(clock.tick)||0)>>>0,
    hash=Math.imul(tick+1,2654435761)>>>0,
    variation=((hash/4294967295)*2-1)*config.deterministicDepth;
  const section=nested?sectionAt(clock.meter,unit)?.dynamic??1:1;
  return Math.max(config.minimum,Math.min(1,base*phrase*metric*section*(1+variation)));
}

export function placedVelocity(velocity, placement=0){
  const config=CONFIG.mixPlacement,
    position=Math.max(config.minimum,Math.min(config.maximum,finite(placement,0))),
    scale=position<0
      ? 1+(1-config.backgroundVelocityScale)*position
      : 1+(config.foregroundVelocityScale-1)*position;
  return Math.max(CONFIG.velocityVariation.minimum,Math.min(1,clamp01(velocity)*scale));
}

export function expressivePerformance({
  note = 60,
  duration = 0.25,
  velocity = 0.65,
  profile = "neutral",
  pressure,
  slide,
  brightness,
  vibratoDepth,
  vibratoRate,
  pitchCurve,
  pressureCurve,
  slideCurve,
  releaseVelocity,
  attackSeconds,
  releaseSeconds,
  vibratoDelay,
  vibratoFade,
} = {}) {
  const shape = CONFIG.profiles[profile] || CONFIG.profiles.neutral,
    length = Math.max(0.02, finite(duration, 0.25)),
    attack = clamp01(
      finite(velocity, 0.65) * shape.velocityScale + shape.velocityBias,
    ),
    long = clamp01(
      (length - CONFIG.sustained.minimumSeconds) /
        CONFIG.sustained.fullExpressionSeconds,
    ),
    register = clamp01((finite(note, 60) - 36) / 60),
    basePressure = clamp01(
      finite(
        pressure,
        CONFIG.pressure.base +
          CONFIG.pressure.velocityScale * attack +
          shape.pressureBias,
      ),
    ),
    baseSlide = clamp01(
      finite(
        slide,
        finite(
          brightness,
          CONFIG.slide.base -
            CONFIG.slide.registerReduction * register +
            CONFIG.slide.velocityScale * attack +
            shape.slideBias,
        ),
      ),
    );
  return Object.freeze({
    profile,
    velocity: attack,
    pressure: basePressure,
    slide: baseSlide,
    brightness: baseSlide,
    releaseVelocity: clamp01(
      finite(releaseVelocity, 0.18 + 0.35 * basePressure),
    ),
    vibratoDepth: Math.max(
      0,
      Math.min(
        CONFIG.vibrato.maximumDepth,
        finite(
          vibratoDepth,
          long *
            (CONFIG.vibrato.depthBase +
              CONFIG.vibrato.pressureScale * basePressure) *
            shape.vibratoScale,
        ),
      ),
    ),
    vibratoRate: Math.max(
      0.1,
      Math.min(
        CONFIG.vibrato.maximumRate,
        finite(
          vibratoRate,
          CONFIG.vibrato.rateBase + CONFIG.vibrato.registerRateScale * register,
        ),
      ),
    ),
    pitchCurve: Object.freeze(
      (Array.isArray(pitchCurve) && pitchCurve.length > 1
        ? pitchCurve
        : [
            0,
            long * CONFIG.pitchDrift.rise * shape.motionScale,
            long * CONFIG.pitchDrift.fall * shape.motionScale,
            0,
          ]
      ).map((value) =>
        Math.max(
          -CONFIG.pitchDrift.maximumSemitones,
          Math.min(CONFIG.pitchDrift.maximumSemitones, finite(value, 0)),
        ),
      ),
    ),
    pressureCurve: curve(pressureCurve, [
      Math.max(0.05, basePressure * CONFIG.pressure.attackRatio),
      Math.min(1, basePressure * (1 + CONFIG.pressure.sustainGrowth * long)),
      Math.max(
        0.04,
        basePressure *
          (CONFIG.pressure.releaseRatio -
            CONFIG.pressure.longReleaseReduction * long),
      ),
    ]),
    slideCurve: curve(slideCurve, [
      baseSlide,
      clamp01(
        baseSlide +
          (CONFIG.slide.longRise -
            CONFIG.slide.highRegisterLongReduction * register) *
            long,
      ),
      clamp01(baseSlide - CONFIG.slide.longReleaseReduction * long),
    ]),
    attackSeconds: Math.max(
      0.001,
      Math.min(
        length * 0.45,
        finite(
          attackSeconds,
          Math.min(
            CONFIG.envelope.maximumAttack * shape.attackScale,
            Math.max(
              CONFIG.envelope.shortAttack,
              length *
                (CONFIG.envelope.attackDurationScale +
                  CONFIG.envelope.softAttackScale * (1 - attack)) *
                shape.attackScale,
            ),
          ),
        ),
      ),
    ),
    releaseSeconds: Math.max(
      0.001,
      Math.min(
        length * 0.45,
        finite(
          releaseSeconds,
          Math.min(
            CONFIG.envelope.maximumRelease * shape.releaseScale,
            Math.max(
              CONFIG.envelope.shortRelease,
              length *
                (CONFIG.envelope.releaseDurationScale +
                  CONFIG.envelope.longReleaseScale * long) *
                shape.releaseScale,
            ),
          ),
        ),
      ),
    ),
    // When vibrato begins and how long it takes to reach its depth. A performer's vibrato is
    // not there at the onset: it arrives once the note has settled (see the vibrato entry in
    // research/expression-and-mixing-references.md). Zero keeps the old behaviour, a vibrato
    // present from the first sample.
    vibratoDelay: Math.max(0, finite(vibratoDelay, 0)),
    vibratoFade: Math.max(0, finite(vibratoFade, 0)),
    sustained: long > 0,
  });
}

// ---- the performance as points in time ------------------------------------------------------
//
// A note's pitch, pressure and brightness, each as a list of {at, value}, `at` in seconds from
// the note-on. These are what MIDI 2 carries per note -- pitch bend, pressure and the brightness
// controller -- and what the Rust voice is given, each point reached in a straight line from the
// one before. So what is heard is what is recorded, point for point.
//
// Until now pressure and brightness were three points and the voice stepped between them over
// five milliseconds: a two-second swell was two steps. Now they are resampled along a smooth
// curve, densely enough that a receiver which does not interpolate still hears a curve, and the
// pitch combines the drift, a scoop or a glide into the note, and a vibrato that waits and fades in.
const smooth = (values, phase) => {
  const position = clamp01(phase) * (values.length - 1), left = Math.floor(position),
    right = Math.min(values.length - 1, left + 1), mix = position - left, eased = mix * mix * (3 - 2 * mix);
  return values[left] + (values[right] - values[left]) * eased;
};
const linear = (values, phase) => {
  const position = clamp01(phase) * (values.length - 1), left = Math.floor(position),
    right = Math.min(values.length - 1, left + 1);
  return values[left] + (values[right] - values[left]) * (position - left);
};
export const TIMELINE = Object.freeze({
  curvePointsPerSecond: 12,   // pressure and brightness on a sustained note
  maximumCurvePoints: 64,
  vibratoPointsPerSecond: 40, // eight to a cycle at five hertz
  onsetPoints: 6,             // across a scoop or a glide
});

/**
 * @param performance  what expressivePerformance returned
 * @param duration     seconds to note-off
 * @param options.scoop       {semitones, seconds}: arrive from below, as a voice or a wind does
 * @param options.glideFrom   the pitch of the note this one is joined to, for a legato glide
 * @param options.glideSeconds how long the glide takes (a time constant; it is 95% there by 3x)
 */
// `glideAt` (s): a glide held at its first pitch that long before it slides (a glissando's hold: section-seat.js).
export function performanceTimeline(performance, duration, {scoop = null, glideFrom = null,
  glideSeconds = 0.06, pitch = null, glideAt = 0} = {}) {
  const length = Math.max(0.02, Number(duration) || 0.25),
    sustained = Boolean(performance?.sustained),
    curvePoints = sustained
      ? Math.min(TIMELINE.maximumCurvePoints, Math.max(3, Math.ceil(length * TIMELINE.curvePointsPerSecond) + 1))
      : Math.max(2, Math.min(3, performance?.pressureCurve?.length || 3));
  const curve = (values, count) => Array.from({length: count}, (_, index) => {
    const phase = index / (count - 1);
    return {at: phase * length, value: clamp01(smooth(values, phase))};
  });
  const pressure = curve(performance.pressureCurve, curvePoints),
    slide = curve(performance.slideCurve, curvePoints);

  // Pitch: every moment something changes, then the sum of what is happening at each.
  const times = new Set(Array.from({length: performance.pitchCurve.length}, (_, index) =>
    index / Math.max(1, performance.pitchCurve.length - 1) * length));
  let onset = null;
  // `Number(null)` is 0, so a note with no note before it would glide in from C-1: test first.
  const from = glideFrom === null || glideFrom === undefined ? NaN : Number(glideFrom), here = Number(pitch);
  if (Number.isFinite(from) && Number.isFinite(here) && Math.abs(from - here) >= 0.05)
    onset = {offset: Math.max(-12, Math.min(12, from - here)), seconds: Math.max(0.005, glideSeconds), hold: Math.max(0, Math.min(length, Number(glideAt) || 0))};
  else if (scoop && length > 0.12 && Number(scoop.semitones))
    onset = {offset: -Math.abs(Number(scoop.semitones)), seconds: Math.max(0.005, Number(scoop.seconds) || 0.05)};
  if (onset) for (let index = 0; index <= TIMELINE.onsetPoints; index++)
    times.add(Math.min(length, (onset.hold ?? 0) + onset.seconds * 3 * (index / TIMELINE.onsetPoints) ** 1.5));
  if (onset?.hold > 0) times.add(onset.hold);
  const depth = performance.vibratoDepth || 0, rate = performance.vibratoRate || 5,
    delay = Math.min(length, performance.vibratoDelay || 0), fade = performance.vibratoFade || 0;
  if (depth > 0 && length > delay) {
    const step = 1 / TIMELINE.vibratoPointsPerSecond;
    for (let at = delay; at <= length + 1e-9; at += step) times.add(Math.min(length, at));
  }
  const pitchAt = at => {
    let value = linear(performance.pitchCurve, at / length);
    if (onset) value += onset.offset * Math.exp(-Math.max(0, at - (onset.hold ?? 0)) / onset.seconds);
    if (depth > 0 && at > delay) {
      const reach = fade > 0 ? Math.min(1, (at - delay) / fade) : 1;
      value += depth * reach * Math.sin(2 * Math.PI * rate * (at - delay));
    }
    return value;
  };
  const pitchPoints = [...times].sort((a, b) => a - b).map(at => ({at, value: pitchAt(at)}));
  return {pitch: pitchPoints, pressure, slide, onset};
}

export function expressionCurveEvents(expression, duration, steps = 8) {
  const valueAt = (values, phase) => {
    const position = phase * (values.length - 1),
      left = Math.floor(position),
      right = Math.min(values.length - 1, left + 1),
      mix = position - left;
    return values[left] + (values[right] - values[left]) * mix;
  };
  return Array.from({ length: Math.max(2, Math.trunc(steps)) }, (_, index) => {
    const phase = index / (Math.max(2, Math.trunc(steps)) - 1);
    return {
      phase,
      at: phase * Math.max(0.02, Number(duration) || 0.25),
      pressure: valueAt(expression.pressureCurve, phase),
      slide: valueAt(expression.slideCurve, phase),
      pitch: valueAt(expression.pitchCurve, phase),
    };
  });
}

export function musicalAccent({
  base = 0.65,
  clock = {},
  division = 0,
  divisions = 1,
  phrasePosition = 0.5,
  note = 60,
  previousNote = note,
  previousVelocity = base,
  voice = 0,
  random = () => 0.5,
  amount = 1,
} = {}) {
  const config = CONFIG.noteDynamics;
  let metric = 0.46;
  if (clock.beatStart) metric = 0.68;
  if (clock.groupStart) metric = 0.84;
  if (clock.barStart || clock.phraseStart) metric = 1;
  let subdivision = 0.62;
  if (division % 2) subdivision = 0.48;
  if (division === 0) subdivision = 1;
  const arch = Math.sin(Math.PI * clamp01(phrasePosition));
  const leap = clamp01(
    Math.abs(finite(note, 60) - finite(previousNote, note)) / 12,
  );
  const voiceShape = (Math.abs(Math.trunc(voice)) % 3) - 1;
  const jitter = (clamp01(random()) - 0.5) * 2;
  const target =
    finite(base, 0.65) +
    amount *
      (config.metricScale * (metric - 0.58) +
        config.subdivisionScale * (subdivision - 0.58) +
        config.phraseArchScale * (arch - 0.55) +
        config.leapScale * (leap - 0.2) +
        config.voiceScale * voiceShape +
        config.jitterScale * jitter);
  const smoothed =
    finite(previousVelocity, base) * config.inertia +
    target * (1 - config.inertia);
  return Math.max(config.minimum, Math.min(config.maximum, smoothed));
}
import { EXPRESSION_CONFIG as CONFIG } from "../expression-config.js";
