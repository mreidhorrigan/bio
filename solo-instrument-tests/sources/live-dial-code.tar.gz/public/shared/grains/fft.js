// An in-place radix-2 FFT (Cooley-Tukey, decimation in time) for the grain route's descriptors (descriptors.js). `re` and
// `im` are Float64Arrays of one power-of-two length; the transform is unnormalized, e^(-2πikn/N). The same algorithm as
// render/vocal/pitch-measure.mjs's, here because a page and a worker can import public/ and not render/.
export function fftInPlace(re,im){
  const n=re.length;
  if(n&(n-1))throw new RangeError('fftInPlace needs a power-of-two length');
  for(let i=1,j=0;i<n;i++){let bit=n>>1;for(;j&bit;bit>>=1)j^=bit;j^=bit;if(i<j){[re[i],re[j]]=[re[j],re[i]];[im[i],im[j]]=[im[j],im[i]]}}
  for(let half=1;half<n;half<<=1){
    const angle=-Math.PI/half;
    for(let k=0;k<half;k++){
      const cr=Math.cos(angle*k),ci=Math.sin(angle*k);
      for(let i=0;i<n;i+=half<<1){
        const a=i+k,b=a+half,vr=re[b]*cr-im[b]*ci,vi=re[b]*ci+im[b]*cr;
        re[b]=re[a]-vr;im[b]=im[a]-vi;re[a]+=vr;im[a]+=vi;
      }
    }
  }
}
