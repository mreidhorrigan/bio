// How an ensemble's preferences over a slate of complete endings turn into one
// number per candidate. Seven rules, switchable, from the survey in
// research/MUSEBOTS_DYNAMIC_DURATION_RESEARCH.md §4.3 and §10.
//
// Each rule sees the same sealed preferences over the same frozen slate and
// returns support in [-1,1] for each candidate: how much the ensemble wants it
// rather than what it is worth once length and churn have been paid for. Those
// costs are charged identically whichever rule is running, in
// composition-duration.js, so a comparison between two rules is a comparison of
// how they aggregate and not of what they were charged.
//
// None of them is strategy-proof, none guarantees fairness between bots, and
// none is evidence that the chosen length is musically right. `weighted` is the
// recommended first version; `majority` is the direct Musebots precedent
// (Eigenfeldt et al. 2017, end-votes with majority support) and the baseline any
// of this has to beat; `incumbent` never moves and is the control.
//
// A missing preference is an abstention. It contributes no evidence in either
// direction and is never read as assent -- coverage is reported separately so a
// decision taken by two bots out of eight cannot look unanimous.

const clamp=(value,low,high)=>value<low?low:value>high?high:value;
const round=(value,places=6)=>Number(Number(value).toFixed(places));
const byId=(left,right)=>left<right?-1:left>right?1:0;

export const DURATION_RULE_NAMES=Object.freeze([
  'weighted',    // weighted mean of bounded contextual gains          [§4.3]
  'majority',    // share of bots supporting the change: the precedent  [R01]
  'approval',    // share approving, with abstention distinguished
  'median',      // the ensemble's middle preferred endpoint            [R05]
  'nash',        // shifted geometric gains with the stated veto         [R07]
  'egalitarian', // the worst-off bot's gain                            [R07]
  'incumbent',   // never replace: the control
]);

// One bot's opinion of one candidate, relative to keeping what is already
// accepted. Bounded by the ensemble's policy rather than by the bot, so a bot
// cannot buy influence by reporting a larger number, and never rescaled to the
// slate -- an almost indifferent ensemble must not be made to look enthusiastic
// because its largest tepid rating was stretched to fill the range.
export function ratingOf(preference,candidateId,policy){
  const value=Number(preference?.ratings?.[candidateId]);
  if(!Number.isFinite(value))return null;
  return clamp(value,-policy.maxRating,policy.maxRating)/policy.maxRating;
}
// The enrolled denominator: every bot admitted to this decision, whether or not
// it answered. Fixed when the round opens, so a bot that goes quiet cannot
// change the arithmetic by going quiet.
export function coverageOf(participants,preferences,candidateId,policy){
  let heard=0;
  for(const bot of participants)
    if(ratingOf(preferences.get(bot),candidateId,policy)!==null)heard++;
  return {heard,enrolled:participants.length,
    share:participants.length?round(heard/participants.length):0};
}
const weightOf=(weights,bot)=>{
  const value=Number(weights?.[bot]);
  return Number.isFinite(value)&&value>=0?value:1;
};

export const DURATION_RULES=Object.freeze({
  // The recommended first version: a weighted mean of the gains bots report,
  // over the enrolled denominator. An abstention contributes nothing, which is
  // not the same as contributing zero enthusiasm -- the denominator is the
  // enrolled roster either way, so silence dilutes support rather than opposing
  // it, and coverage is reported beside the number.
  weighted:{
    summary:'weighted mean of the gains the enrolled bots reported',
    support:({participants,preferences,candidateId,policy,weights})=>{
      // A common positive scale cancels in the ratio. All terms after
      // scaling are bounded by one, so finite large weights cannot overflow.
      // Keep every enrolled bot in the denominator, including abstentions.
      const enrolled=participants.map(bot=>({bot,weight:weightOf(weights,bot)}));
      let scale=0;for(const {weight} of enrolled)scale=Math.max(scale,weight);
      if(scale===0)return 0;
      let total=0,enrolledMass=0;
      for(const {bot,weight} of enrolled){
        const scaled=weight/scale;
        enrolledMass+=scaled;
        const rating=ratingOf(preferences.get(bot),candidateId,policy);
        if(rating!==null)total+=scaled*rating;
      }
      return total/enrolledMass;
    },
  },
  // The direct precedent: bots vote to end, and majority support carries it.
  // Here the vote is over a whole candidate rather than a bare willingness to
  // stop, but the arithmetic is the same -- the share of the enrolled roster in
  // favour, minus the share against.
  majority:{
    summary:'share of the enrolled bots in favour, less the share against',
    support:({participants,preferences,candidateId,policy})=>{
      let favour=0,against=0;
      for(const bot of participants){
        const rating=ratingOf(preferences.get(bot),candidateId,policy);
        if(rating===null)continue;
        if(rating>policy.approvalThreshold)favour++;
        else if(rating<-policy.approvalThreshold)against++;
      }
      return participants.length?(favour-against)/participants.length:0;
    },
  },
  // Approval without the opposing half: how much of the roster would accept it.
  // Blind to intensity, and to whether the rest object or merely abstain.
  approval:{
    summary:'share of the enrolled bots that would accept it at all',
    support:({participants,preferences,candidateId,policy})=>{
      let favour=0;
      for(const bot of participants)
        if((ratingOf(preferences.get(bot),candidateId,policy)??-1)>policy.approvalThreshold)favour++;
      return participants.length?favour/participants.length:0;
    },
  },
  // The ensemble's middle preferred endpoint, and then how near this candidate
  // comes to it. A median over one dimension: its strategy-proofness results
  // need single-peaked preferences, which phrase windows do not automatically
  // give -- so this is a challenger to compare against, not a guarantee being
  // claimed. A mean would be worse still, landing between two feasible endings
  // at a point where nothing is prepared to stop.
  median:{
    summary:'nearness to the middle of the endpoints the bots asked for',
    support:({participants,preferences,candidate,candidates,policy})=>{
      const wanted=[];
      for(const bot of participants){
        const asked=Number(preferences.get(bot)?.endpointBeats);
        if(Number.isFinite(asked))wanted.push(asked);
      }
      if(!wanted.length)return 0;
      wanted.sort((left,right)=>left-right);
      const lo=wanted[Math.floor((wanted.length-1)/2)],hi=wanted[Math.floor(wanted.length/2)],sum=lo+hi;
      // Preserve the existing midpoint when representable; only avoid an
      // overflowing same-sign sum. This is still a numerical median policy.
      const middle=wanted.length%2?lo:Number.isFinite(sum)?sum/2:lo/2+hi/2;
      // Scaled by the widest disagreement on the slate, so the number means
      // "nearest of what was actually on offer" rather than a raw beat count.
      const endpoints=candidates.map(item=>item.endpointBeats),
        spread=Math.max(...endpoints)-Math.min(...endpoints);
      return spread>0?1-2*(Math.abs(candidate.endpointBeats-middle)/spread):1;
    },
  },
  // After the bargaining product over a disagreement point (keeping the
  // incumbent), but not that product: a shifted geometric mean of the gains,
  // the geometric mean of (1 + gain) less one, with a veto. A bot that rates the
  // candidate at or below minus the approval threshold blocks it outright; a
  // neutral bot does not (its factor is one), it only dilutes the others'
  // gains. Nash's axioms assume a convex utility set; a finite slate of
  // prepared endings is not one, so the original theorem's conclusions are not
  // on offer here. Computed in logs (the mean of log(1 + gain)), so it does not
  // overflow however many bots take part: the product did, and read as 1
  // (the mathematical audit's T02).
  nash:{
    summary:'shifted geometric mean of the gains; a bot clearly against it blocks it',
    support:({participants,preferences,candidateId,policy})=>{
      let logs=0,heard=0;
      for(const bot of participants){
        const rating=ratingOf(preferences.get(bot),candidateId,policy);
        if(rating===null)continue;
        if(rating<=-policy.approvalThreshold)return 0;
        logs+=Math.log1p(Math.max(0,rating));heard++;
      }
      // The geometric mean, so a slate judged by two bots is comparable with one
      // judged by eight.
      return heard?clamp(Math.expm1(logs/heard),0,1):0;
    },
  },
  // The worst-off bot decides. Protects a single dissenter at the cost of
  // ignoring how much everyone else gains.
  egalitarian:{
    summary:'the gain of the bot that likes it least',
    support:({participants,preferences,candidateId,policy})=>{
      let worst=null;
      for(const bot of participants){
        const rating=ratingOf(preferences.get(bot),candidateId,policy);
        if(rating===null)continue;
        worst=worst===null?rating:Math.min(worst,rating);
      }
      return worst===null?0:worst;
    },
  },
  // The control: whatever is already accepted stays accepted. A rule that
  // cannot beat this one is not worth the churn it causes.
  incumbent:{
    summary:'never replace what is already accepted',
    support:({candidate,incumbentId})=>candidate.id===incumbentId?1:-1,
  },
});

// Support for every feasible candidate under one rule, in canonical order.
export function supportFor(rule,{candidates,participants,preferences,policy,weights,incumbentId}){
  const chosen=DURATION_RULES[rule];
  if(!chosen)throw new RangeError(`Unknown duration rule: ${rule}`);
  return [...candidates].sort((left,right)=>byId(left.id,right.id)).map(candidate=>({
    candidate,
    support:round(clamp(chosen.support({candidate,candidateId:candidate.id,candidates,
      participants,preferences,policy,weights,incumbentId}),-1,1)),
    coverage:coverageOf(participants,preferences,candidate.id,policy),
  }));
}
