// The spaces a heard chord opens, and the one a bot's intended dissonance chooses.
//
// The user: "levels of harmony can define spaces in which other spaces fit, so that, for example, hearing a C-major
// chord opens up the possibility of harmonizing with the scales that work with C-major, et cetera, according to the
// bot's intended level of dissonance."
//
// Hearing C major, a musician may harmonize within its own tones, within the pentatonic that holds it (C D E G A), within
// a scale that holds it (C major's own, or a brighter or darker mode on C: lydian with F sharp, mixolydian with B flat,
// harmonic major with A flat), within an eight-note scale (Barry Harris's sixth-diminished), or within all twelve notes.
// The spaces nest (the pentatonic within the major scale within the eight-note scale within the chromatic) or sit side
// by side (lydian beside mixolydian). The sets are the levels vocabulary's (harmonic-levels.js), in any tuning its
// vocabulary names, so a maqam's spaces open over a chord heard in quarter tones in the same way.
//
// How dissonant a space is against the chord is measured note by note, and averaged over the space (its chord tones
// counting none): a note's distance from the chord's harmonic series (1 less its spectral affinity with the chord,
// spectral-consonance.js, in any tuning), and, where a key is heard, whether the key holds it: F sharp over C major is
// brighter in C major than in G. A larger space, or one whose added notes clash more, is more dissonant. Normalized by
// the chromatic space's, 0 is the chord alone and 1 is all twelve notes.
//
// A bot chooses the space nearest its intended dissonance; among spaces about as near, the one the heard key holds most.
import {TWELVE_TONE_BEBOP_LEVELS,setHolds,pitchClassDistance} from './estimation/harmonic-levels.js';
import {affinityField} from './estimation/spectral-consonance.js';

const modulo=(value,period)=>((value%period)+period)%period;
const clamp01=value=>Math.max(0,Math.min(1,value));

// The spaces over a chord (its pitch classes): [{id, layer, family, mode, pitchClasses, dissonance, normalized, heard}],
// least dissonant first. `holding`: the tones a space must hold (the chord's; a seventh chord's root, third and
// seventh, so that an altered or lydian-dominant scale may take the fifth's place). `root`: names each space's mode.
// `beliefs`: over the heard layer's sets ({setId: probability}); none, and no note is outside the key.
export function harmonicSpaces(chord,{vocabulary=TWELVE_TONE_BEBOP_LEVELS,holding=chord,root=chord[0],beliefs={},heardLayer='collection',
  outsideWeight=.5,roughnessWeight=0}={}){
  const period=vocabulary.periodSemitones,tolerance=vocabulary.toleranceSemitones,grid=vocabulary.grid;
  const same=(a,b)=>pitchClassDistance(a,b,period)<=tolerance,isTone=pc=>chord.some(tone=>same(tone,pc));
  // Each grid note's dissonance against the chord.
  const field=affinityField(chord.map(pc=>({pc,weight:1})),{grid,periodSemitones:period,roughnessWeight});
  const toneAffinity=Math.max(...field.filter(entry=>isTone(entry.pc)).map(entry=>entry.affinity),1e-9);
  const heardSets=vocabulary.layers.find(layer=>layer.id===heardLayer)?.sets.filter(set=>!set.chromatic)??[];
  const believed=heardSets.reduce((sum,set)=>sum+(beliefs[set.id]??0),0);
  const inKey=pc=>believed>0?heardSets.reduce((sum,set)=>sum+(beliefs[set.id]??0)*(set.pitchClasses.some(member=>same(member,pc))?1:0),0)/believed:1;
  const noteDissonance=new Map(field.map(({pc,affinity})=>[pc,isTone(pc)?0:clamp01(1-affinity/toneAffinity)+outsideWeight*(1-inKey(pc))]));
  const dissonanceOf=pc=>{let best=null,near=Infinity;for(const [key,value] of noteDissonance){const d=pitchClassDistance(key,pc,period);if(d<near){near=d;best=value}}return best??1};
  const measure=pitchClasses=>{
    const notes=[...pitchClasses,...chord.filter(tone=>!pitchClasses.some(pc=>same(pc,tone)))];
    return {dissonance:notes.reduce((sum,pc)=>sum+dissonanceOf(pc),0)/notes.length,heard:notes.reduce((sum,pc)=>sum+inKey(pc),0)/notes.length};
  };
  const spaces=[{id:'chord',layer:'chord',family:'chord',mode:null,pitchClasses:[...chord].sort((a,b)=>a-b)}];
  for(const layer of vocabulary.layers)for(const set of layer.sets){
    if(set.chromatic||!setHolds(vocabulary,set,holding))continue;
    if(spaces.some(space=>space.pitchClasses.length===set.pitchClasses.length&&space.pitchClasses.every((pc,i)=>same(pc,set.pitchClasses[i]))))continue;
    spaces.push({id:set.id,layer:layer.id,family:set.family,mode:set.modes.find(mode=>same(mode.center,root))?.name??null,pitchClasses:set.pitchClasses});
  }
  spaces.push({id:'chromatic',layer:'chromatic',family:'chromatic',mode:null,pitchClasses:[...grid]});
  const measured=spaces.map(space=>({...space,...measure(space.pitchClasses),notes:space.pitchClasses.map(pc=>({pc,dissonance:+dissonanceOf(pc).toFixed(4),heard:+inKey(pc).toFixed(4),tone:isTone(pc)}))}));
  const top=measured.at(-1).dissonance||1;
  return measured.map(space=>({...space,dissonance:+space.dissonance.toFixed(4),normalized:+clamp01(space.dissonance/top).toFixed(4),heard:+space.heard.toFixed(4)}))
    .sort((a,b)=>a.dissonance-b.dissonance||b.heard-a.heard||a.id.localeCompare(b.id));
}

// The space for an intended dissonance (0: the chord alone; 1: every note): the nearest by normalized dissonance, and
// among those within `slack` of the nearest, the one the heard key holds most.
export function spaceFor(spaces,intended,{slack=.06}={}){
  if(!spaces?.length)return null;
  const target=clamp01(intended),distance=space=>Math.abs(space.normalized-target),nearest=Math.min(...spaces.map(distance));
  return spaces.filter(space=>distance(space)<=nearest+slack).sort((a,b)=>b.heard-a.heard||distance(a)-distance(b))[0];
}

// A colour chord from a space: the chord's tones, then the notes that make the space what it is (those it adds to the
// largest of `spaces` nested within it: lydian adds F sharp and B to the pentatonic over C major, the key heard holding
// the fewest first, then the least dissonant), then the nested space's notes, least dissonant first; any a semitone
// above a chord tone (an avoid note, sustained) left out; up to `count` notes. Over C major: from the pentatonic, the sixth and ninth (C E G D A); from ionian, the major
// seventh and ninth; from lydian, the sharp eleventh and major seventh; from mixolydian, the minor seventh and ninth.
// On a dominant (`root` given, its major third and minor seventh among the tones) the flat ninth is a tension, as jazz
// voices it, not an avoid note.
export function colourChord(space,chord,{spaces=[],count=5,period=12,avoidSemitones=1.5,root=null}={}){
  const same=(a,b)=>pitchClassDistance(a,b,period)<.2,tones=[...new Set(chord)];
  const dominant=root!==null&&tones.some(tone=>same(tone,root+4))&&tones.some(tone=>same(tone,root+10));
  const avoid=pc=>!(dominant&&same(pc,root+1))&&tones.some(tone=>{const above=modulo(pc-tone,period);return above>.2&&above<avoidSemitones});
  // Nor a second seventh or third: a minor seventh beside a major one, a minor third beside a major one (on a dominant
  // that is its sharp ninth, and kept).
  const role=pc=>root===null?null:[3,4].some(step=>same(pc,root+step))?'third':[10,11].some(step=>same(pc,root+step))?'seventh':null;
  const held=new Set(tones.map(role).filter(Boolean));
  const doubled=pc=>{const r=role(pc);return r!==null&&held.has(r)&&!(r==='third'&&dominant&&same(pc,root+3))};
  const within=(inner,outer)=>inner.pitchClasses.every(pc=>outer.pitchClasses.some(member=>same(pc,member)));
  const inner=spaces.filter(other=>other!==space&&other.pitchClasses.length<space.pitchClasses.length&&within(other,space))
    .sort((a,b)=>b.pitchClasses.length-a.pitchClasses.length||a.dissonance-b.dissonance)[0]??null;
  const notes=(space.notes??space.pitchClasses.map(pc=>({pc,dissonance:0}))).filter(note=>!tones.some(tone=>same(tone,note.pc))&&!avoid(note.pc)&&!doubled(note.pc));
  const own=note=>!inner||!inner.pitchClasses.some(pc=>same(pc,note.pc));
  const rank=(a,b)=>a.dissonance-b.dissonance||a.pc-b.pc,colour=(a,b)=>(a.heard??1)-(b.heard??1)||rank(a,b);
  return [...tones,...notes.filter(own).sort(colour).map(note=>note.pc),...notes.filter(note=>!own(note)).sort(rank).map(note=>note.pc)]
    .slice(0,Math.max(tones.length,count));
}
