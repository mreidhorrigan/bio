import {clockContinuation} from './clock-continuation.js';
import {copyAuthoredTempo,queueAuthoredTempo,authoredBpmAt,authoredTempoFields,validateAuthoredTempo} from './score-tempo.js';
import {jsonBytes,readJsonBytes,WIRE_LIMITS} from './multinet-wire.js';
import {MeterChangeWindow,meterChangePolicy} from './estimation/meter-change-window.js';
import {actor,frozenJson,identifier} from './planning-data.js';
import {advanceCursor,validateCursorCurves} from './ensemble-cursor.js';
import {queueHold,releaseHold,readyHold,selectHold,takeAnnouncements,heldAt,holdTick,validateCursorHolds,holdStatus} from './clock-hold.js';
import {RUBATO_ADDRESSES,cursorRubatoControl,cursorRubatoPulse,validateCursorRubato,unpackRubatoSpan} from './rubato-clocks.js';
import {ratio,compare} from './rhythm-vocabulary.js';
import {EnsembleTempoMap,inputTempoCommit,prepareInputTempoRamp} from './ensemble-tempo-map.js';
import {RENDEZVOUS,bridgeOf,coupledState,couplingOf,proposeRendezvous,rendezvousBasis,rendezvousProblem} from './conductor-rendezvous.js';
import {clampTempo,tempoInRange} from './tempo-range.js';
import {whenBar,METER_NOTICE_SECONDS,TEMPO_NOTICE_SECONDS} from './change-timing.js';
import {GroupTree,GROUP_ADDRESS,FORMATION_ADDRESS} from './conducting/groups.js';
import {bandMeter} from './opening-time.js';
export {advanceCursor} from './ensemble-cursor.js';

const copy=value=>structuredClone(value);
export const ENSEMBLE_CONTROLS=new Set(['/broadcast/timeSignature','/broadcast/tempoCurve','/broadcast/tempo','/broadcast/hold','/broadcast/holdRelease',
  '/broadcast/holdReady','/broadcast/holdSelect','/broadcast/rubato','/broadcast/rubatoRevise']);
const HOLD_ADDRESSES=new Set(['/broadcast/hold','/broadcast/holdRelease','/broadcast/holdReady','/broadcast/holdSelect']);
// What a transport refuses from a bot that does not conduct the room, while one does (authority).
const NOT_CONDUCTING='not-the-conductors-plan';
const roomConductor=publisher=>String(publisher?.id??'').endsWith('::conductor');
// A hold is declared at least this long before its pulse, so every conductor has it before the pulse is due.
const HOLD_DISTRIBUTION_SECONDS=1;
const integer=value=>Number.isSafeInteger(value)&&value>=0;
const meterDecisionSummary=value=>value?{
  decisionId:value.decisionId||null,targetBar:value.targetBar??null,effectiveAt:value.effectiveAt??null,
  cutoff:value.cutoff??null,status:value.status,reason:value.reason||null,accepted:value.accepted===true,
  resolution:value.policy?.resolution||null,publisherCount:value.publishers?.length??value.proposal?.alternatives.length??value.alternatives?.length??0,
}:null;

// **A conductor with no bots has no opinion about tempo or time signature.**
//
// The conductors of an ensemble choose one primary, whose clock and whose tempo, meter and position everybody
// follows. They used to choose by priority alone, and the relay's own hosted conductor -- which by default has no
// bots at all -- bids ahead of a conductor that joins it. So on 20 September 2026 a local ensemble in full flight,
// PlexBOT running its meter, was connected to the relay, lost the election to a conductor with nothing playing, took
// its 4/4 at 108, and fell silent, because a conductor with no bots keeps its clock at zero.
//
// **First of all, the lead belongs to whoever has the pulse.** A conductor whose room has a bot that provides the
// pulse -- mh_PlexBOT, mh_ConductorBOT: `experiments/setup-phase/capabilities.js` says which -- is the one with an
// opinion about meter and tempo, and outranks a conductor that has none however it is configured. Without this, an
// ensemble running its form under PlexBOT joined a conductor playing sounding bots at a better configured priority,
// and that conductor's 4/4 replaced PlexBOT's meter: "the conductor overrode plexbot locally", 20 September 2026.
// Two conductors that both have a pulse are settled by what follows.
//
// Every bid also says whether the bidder has running bots (`performing`: at least one bot that is set to perform,
// not merely loaded), and a conductor that has them is chosen ahead of any that has none.
//
// **And an ensemble that is playing is not interrupted by somebody arriving.** Bids also say whether the bidder
// currently leads (`leading`), which breaks a tie that used to be broken by name. Two guests both bid priority 50,
// so when a phone joined a running performance and started a bot of its own, the lead moved to whichever random
// guest name sorted first -- a coin flip, measured at 124 times in 200. Whoever won, the change of lead began a
// fresh clock epoch, and every conductor that had to retrain its clock against the new leader stopped receiving
// ticks: on 20 September 2026 a phone with one RhodesBOT silenced the whole ensemble until it was disconnected.
// Ranking a leader above an equal an arriving conductor follows the performance instead of taking it over.
//
// The order is the same for everybody, because every part of it is in the bids: running bots first, then the
// configured priority, then whoever already leads, then the older performance (`since`, the moment the piece being
// played began), then the name. Priority still comes first among performing conductors, which is the documented
// reference model (`research/multinet-joining-and-conductors.md`); two performances meeting are settled that way, or,
// with `pieces: 'negotiate'`, negotiated (the rendezvous at the end of this class).
//
// `since` settles the one case `leading` cannot: a conductor that has just connected elects itself before it has
// heard from anybody, so for a moment two conductors both say they lead. The one whose piece began earlier keeps
// it, which is the ensemble that was already playing. A conductor that becomes primary with a
// performance under way brings the whole of it -- tempo, meter, position in the bar and the piece, the session --
// so the ensemble takes up what is being played instead of starting again, and the others follow it. A bid is made
// again whenever a conductor's first bot arrives or its last one leaves. Two conductors that both have bots are
// still settled by priority for the lead; negotiating, the other keeps its piece and meets the leader's at a
// rendezvous. A bid from an older conductor says nothing about bots and is read as having none.
const whole=value=>Number.isInteger(value)&&value>=0;
// How long the beat may be carried by this machine's own clock while a new leader's clock is trained. Long enough
// for an ordinary handover, short enough that a conductor cut off from the ensemble does not drift alone for ever.
const HANDOVER_SECONDS=8;
export class EnsembleConductor {
  // `pieces`: 'one' (the default: one piece, the leader's, which a conductor playing another takes up at a bar line) or
  // 'negotiate' (two pieces meeting are negotiated: see the rendezvous below and conductor-rendezvous.js).
  // `rendezvousPolicy`: RENDEZVOUS's values, and `acceptTarget(target, plan)`, whether this piece takes a proposed target.
  constructor({host,incarnation,sessionId,priority=10,transport,clock,meterApi,initial={},performing=()=>false,plans=()=>false,onTick=()=>{},onState=()=>{},onAnnounce=()=>{},now=()=>performance.now()/1000,wallNow=()=>Date.now(),meterPolicy={},pieces='one',rendezvousPolicy={}}) {
    Object.assign(this,{host,incarnation,sessionId,priority,transport,clock,meterApi,performing,plans,onTick,onState,onAnnounce,now,wallNow});
    this.initial=initial;this.candidates=new Map();this.primary=null;this.cursor=null;this.lastTick=-1;this.rejected=0;
    this.held=null;this.handover=null;this.continuation=null;
    this.meterPolicy=meterChangePolicy(meterPolicy);this.meterWindow=null;this.lastMeterDecision=null;
    this.pieces=pieces==='negotiate'?'negotiate':'one';
    const {acceptTarget=()=>true,...policy}=rendezvousPolicy||{};
    this.rendezvousPolicy=Object.freeze({...RENDEZVOUS,...policy});this.acceptTarget=acceptTarget;
    this.rendezvous=null;this.coupling=null;this.foreign=null;this.rendezvousLog=[];this.planSequence=0;this.refusals=0;
    // The room's groups as every bot's tree hears them (shared/conducting/groups.js), for its conductorbot (authority).
    this.groups=new GroupTree();
  }
  // **A transport realizes the conductorbot's plan; it is not another musical authority** (Musebots 3.0; Astra's
  // implementation dossier, A009). Where the room has a conductorbot -- the conductor elected for its top group, as every
  // bot's group tree elects it -- the meters and tempi the transports put in force are the ones it hands over (or the
  // room's own conductor's: a person at the controls), on whichever host the clock is elected; another bot's proposal is
  // refused, and said (NOT_CONDUCTING). Only where the room has none do the transport's own resolution of the bots'
  // proposals (meterPolicy) and the last tempo asked decide, as before: the fallback.
  //
  // What the room says of its groups, heard from the bots of every host (conductor-host.js): a name a bot gives itself
  // qualified by its host, as its messages' sources are.
  hear(message){
    if(message?.address!==GROUP_ADDRESS&&message?.address!==FORMATION_ADDRESS)return false;
    const source=String(message.source??''),cut=source.indexOf('::'),host=cut>0?source.slice(0,cut):null,value=message.args?.[0];
    if(!value||typeof value!=='object')return false;
    const qualified=name=>typeof name==='string'&&host&&!name.includes('::')?`${host}::${name}`:name;
    const named={...value,...(value.conductor!=null?{conductor:qualified(value.conductor)}:{}),...(value.leader!=null?{leader:qualified(value.leader)}:{})};
    return this.groups.hear({...message,args:[named,...message.args.slice(1)]},{bar:this.cursor?.bar});
  }
  // The room's conductorbot: the conductor elected for its top group, heard within its grace as the bars go by (a host
  // dropped, it lapses); none where no group is conducted, or several top groups are.
  authority(){
    if(Number.isInteger(this.cursor?.bar)&&this.cursor.bar>this.groups.bar)this.groups.bar=this.cursor.bar;
    const tops=new Set([...this.groups.groups.values()].filter(group=>!group.parent).map(group=>this.groups.conductorOf(group.id)).filter(Boolean));
    return tops.size===1?[...tops][0]:null;
  }
  isPerforming(){try{return Boolean(this.performing());}catch{return false;}}
  isPlanning(){try{return Boolean(this.plans());}catch{return false;}}
  bid(){return {host:this.host,incarnation:this.incarnation,priority:this.priority,plans:this.isPlanning(),performing:this.isPerforming(),
    leading:this.primary===this.host,since:Number.isInteger(this.cursor?.startedAt)?this.cursor.startedAt:Infinity};}
  // Our own bid, kept in the same map as everybody else's. Tell the others whenever it changes, and only then.
  refreshBid(){
    const bid=this.bid(),known=this.candidates.get(this.host);
    this.candidates.set(this.host,bid);
    if(known&&known.plans===bid.plans&&known.performing===bid.performing&&known.leading===bid.leading&&known.since===bid.since)return false;
    this.hello();return true;
  }
  send(value,to=[]){return this.transport.send('conductor',jsonBytes(value),{kind:'control',to,urgent:true,ttlMs:1000});}
  hello(to=[]) {
    const bid=this.bid(),value={type:'ensemble_hello',version:1,sessionId:this.sessionId,priority:bid.priority,plans:bid.plans,performing:bid.performing,leading:bid.leading};
    // A conductor playing nothing yet has no beginning to offer, and JSON has no infinity; leaving it out says so.
    if(Number.isFinite(bid.since))value.since=bid.since;
    this.send(value,to);
  }
  connected(){
    // A transport reconnect is not a conductor departure. Retain the known
    // bids of unchanged peers in the relay's new membership snapshot, so a
    // recipient does not briefly elect itself and discard its trained clock.
    for(const [id,candidate]of this.candidates){const peer=this.transport.peers.get(id);
      if(id!==this.host&&(!peer?.connected||peer.incarnation!==candidate.incarnation))this.candidates.delete(id);}
    this.candidates.set(this.host,this.bid());this.hello();
    // The relay can restart before all surviving representatives reconnect.
    // Allow their bids to arrive before replacing an established primary.
    if(this.primary!==this.host&&this.primary&&!this.candidates.has(this.primary)){
      clearTimeout(this.electionTimer);this.electionTimer=setTimeout(()=>{this.electionTimer=null;this.elect();},1000);
    }else this.elect();
  }
  peer(event) {
    if(event.connected){this.hello([event.host]);if(this.primary===this.host)this.advertise([event.host]);}
    else {
      this.candidates.delete(event.host);
      if(this.rendezvous?.with===event.host)this.abortRendezvous('party-departed',{notify:false});
      if(this.active())this.elect();
    }
  }
  elect() {
    const winner=[...this.candidates.values()].sort((a,b)=>
      Number(Boolean(b.plans))-Number(Boolean(a.plans))||
      Number(Boolean(b.performing))-Number(Boolean(a.performing))||a.priority-b.priority||
      Number(Boolean(b.leading))-Number(Boolean(a.leading))||a.since-b.since||(a.host<b.host?-1:a.host>b.host?1:0))[0];
    if(this.electionTimer&&winner?.host!==this.primary)return;
    clearTimeout(this.electionTimer);this.electionTimer=null;
    if(!winner||this.primary===winner.host&&this.primaryIncarnation===winner.incarnation)return;
    const previous=this.cursor,force=this.primary===winner.host&&this.primaryIncarnation!==winner.incarnation;
    // **A change of leader is not a change of music.** A conductor that is already playing keeps its cursor, and
    // carries the beat on this machine's own clock, until the new leader's state can be taken up (see timeFor and
    // takeUp). Only a conductor that has nothing playing starts from nothing.
    const playing=Boolean(this.cursor)&&this.lastTick>=0;
    // A rendezvous is made with a leader, in its reference: a new leader ends one not yet begun.
    if(this.rendezvous&&this.rendezvous.with!==winner.host)this.abortRendezvous('leader-changed',{notify:false});
    this.primary=winner.host;this.primaryIncarnation=winner.incarnation;this.held=null;
    this.meterWindow=null;this.lastMeterDecision=null; // A new authority never inherits an unsealed local decision.
    if(!playing){this.cursor=null;this.lastTick=-1;this.handover=null;}
    this.clock.selectReferenceHost(winner.host,{force});
    if(winner.host===this.host) {
      // What this conductor's own room is doing, asked for now rather than when the connection was set up.
      const start=this.wallNow()+500,initial=previous||(typeof this.initial==='function'?this.initial():this.initial)||{};
      const meter=this.meterApi.normalizeMeter(initial.meter||{}),placed=previous||[initial.tick,initial.bar,initial.tickInBar].every(whole)&&initial.tickInBar<meter.pulsesPerBar;
      this.cursor={version:1,epoch:this.clock.offer.reference.epoch,revision:0,at:this.now()+.5,
        tick:placed?initial.tick:0,bar:placed?initial.bar:0,tickInBar:placed?initial.tickInBar:0,beat:placed&&whole(initial.beat)?initial.beat:0,
        bpm:clampTempo(Number(initial.bpm)||108,meter),meter,scoreTempo:copyAuthoredTempo(initial.scoreTempo),
        seed:previous?.seed??(whole(initial.seed)&&initial.seed<=0xffffffff?initial.seed:start>>>0),startedAt:previous?.startedAt??(whole(initial.startedAt)?initial.startedAt:start),
        pendingMeter:copy(initial.pendingMeter||null),pendingTempo:copy(initial.pendingTempo||null),curve:copy(initial.curve||null),
        inputTempoCommit:copy(initial.inputTempoCommit||null)};
      authoredBpmAt(this.cursor);
      this.advertise();
    } else this.send({type:'ensemble_request',version:1,sessionId:this.sessionId},[winner.host]);
    // Taking or giving up the lead changes our own bid, which the others rank us by.
    this.refreshBid();
    this.onState(this.status());
  }
  active(){return this.transport.state==='ready';}
  // Is this state's clock one we can read yet? A new leader's is not, until its epoch is settled and, unless we are
  // the reference ourselves, we have exchanged at least once with it.
  readable(state){return this.clock.offer?.reference.epoch===state.epoch&&!this.clock.pendingOffer&&(this.clock.isReference||this.clock.client.rtts.length>0);}
  samePiece(state){return Boolean(this.cursor)&&this.cursor.seed===state.seed&&this.cursor.startedAt===state.startedAt;}
  // **A leader's state is taken up at a bar line, not in the middle of one.**
  //
  // The same piece continues seamlessly, which is what a change of leader within one performance is. A DIFFERENT
  // piece -- two performances meeting -- would otherwise replace this one's meter and tempo between one tick and
  // the next, wherever that fell: measured on 20 September 2026 as 5/4 at 96 becoming 7/8 at 132 mid-bar. It is now
  // held until what is playing reaches a bar line and the new leader's clock can be read, so the meter changes
  // where a bar changes and the beat never stops meanwhile.
  takeUp(state) {
    // **Negotiating, a piece that meets another keeps playing.** It asks the leader for a rendezvous (below) instead
    // of taking the leader's piece up; once they have met, it takes the leader's timing and keeps its own counts.
    if(this.pieces==='negotiate'&&this.isPerforming()&&this.cursor&&this.lastTick>=0&&!this.samePiece(state)){
      if(this.coupling&&state.seed===this.coupling.piece.seed&&state.startedAt===this.coupling.piece.startedAt){
        let mapped;try{mapped=coupledState(state,this.coupling,this.cursor);}catch{this.rejected++;return;}
        this.adopt(mapped);return;
      }
      this.foreign=state;this.requestRendezvous();this.onState(this.status());return;
    }
    if(!this.isPerforming()||!this.cursor||this.lastTick<0||this.samePiece(state)){this.adopt(state);return;}
    this.held=state;this.onState(this.status());
  }
  adopt(state) {
    const continues=this.samePiece(state);
    this.cursor=state;this.held=null;this.handover=null;
    // Another piece counts its ticks from its own beginning, so ours start again with it.
    if(!continues)this.lastTick=-1;
    this.refreshBid();this.onState(this.status());
  }
  // The time the cursor is advanced against. Normally the ensemble's reference clock. While a new leader's clock is
  // being trained -- which is every change of leader -- that clock cannot be read, and this machine's own carries
  // the beat from where the reference left off. Without this, every change of leader is a silence: measured at
  // about half a second here, and far longer over a slow link, which is long enough to stop every bot following it.
  timeFor(state) {
    if(this.readable(state)){
      let time;try{time=this.clock.referenceTime();}catch{return null;}
      this.handover={offset:time-this.now(),until:this.now()+HANDOVER_SECONDS};
      return time;
    }
    // Only a beat that was already sounding is carried on; a cursor never ticked has nothing to carry.
    if(!this.handover||this.lastTick<0||this.now()>this.handover.until)return null;
    return this.now()+this.handover.offset;
  }
  // Used after a transport disconnects. timeFor saved the reference's relation to this machine while it was
  // readable; the next cursor already includes the last pulse's rubato interval and any hold it began.
  localContinuation(){
    const known=this.continuation;if(!known)return null;
    const current=this.cursor&&this.lastTick>=0&&Number.isFinite(this.handover?.offset)
      ?{...known,cursor:this.cursor,offset:this.handover.offset}:known;
    return clockContinuation(current.cursor,-current.offset,current.session);
  }
  advertise(to=[]) {
    if(this.primary===this.host&&this.cursor){this.send({type:'ensemble_state',version:1,sessionId:this.sessionId,state:this.cursor},to);this.lastAdvertised=this.now();}
  }
  receive(record) {
    let value;try{value=readJsonBytes(record.payload);}catch{return false;}
    if(!value?.type?.startsWith('ensemble_'))return false;
    try {
      const e=record.envelope;
      if(e.bot!=='conductor'||value.version!==1||value.sessionId!==this.sessionId)throw new Error('Invalid ensemble authority');
      if(value.type==='ensemble_hello') {
        if(!Number.isInteger(value.priority)||value.priority<0||value.priority>100)throw new Error('Invalid priority');
        const known=this.candidates.has(e.host);
        this.candidates.set(e.host,{host:e.host,incarnation:e.incarnation,priority:value.priority,plans:value.plans===true,performing:value.performing===true,
          leading:value.leading===true,since:Number.isInteger(value.since)?value.since:Infinity});
        if(!known)this.hello([e.host]);this.elect();if(this.primary===this.host)this.advertise([e.host]);
      } else if(value.type==='ensemble_request') {if(this.primary===this.host)this.advertise([e.host]);}
      else if(value.type==='ensemble_change') {
        if(this.primary===this.host){
          const member=this.candidates.get(e.host);
          if(!member||member.incarnation!==e.incarnation)throw new Error('Unregistered proposal representative');
          const publisher=value.publisher?actor(value.publisher):{id:`${e.host}::conductor`,incarnation:e.incarnation};
          if(!publisher.id.startsWith(`${e.host}::`))throw new Error('Foreign meter publisher');
          this.change(value.address,value.args,{publisher,host:e.host,hostIncarnation:e.incarnation});
        }
      }
      else if(value.type.startsWith('ensemble_rendezvous_'))this.receiveRendezvous(value,e);
      else if(value.type==='ensemble_state') {
        if(e.host!==this.primary||e.incarnation!==this.primaryIncarnation)throw new Error('Only the elected primary supplies ensemble state');
        const s=copy(value.state);
        if(!s||s.version!==1||!['tick','bar','tickInBar','beat','revision'].every(k=>integer(s[k]))||
          !Number.isFinite(s.at)||!Number.isFinite(s.bpm)||
          !integer(s.seed)||s.seed>0xffffffff||!integer(s.startedAt)||typeof s.epoch!=='string')throw new Error('Invalid metrical cursor');
        s.meter=this.meterApi.normalizeMeter(s.meter);
        // (Its tempo in its meter's range: the notated beat's, or its named tempo unit's, shared/tempo-range.js.)
        if(!tempoInRange(s.bpm,s.meter))throw new Error('Invalid metrical cursor');
        if(s.tickInBar>=s.meter.pulsesPerBar)throw new Error('Invalid metrical position');
        for(const pending of [s.pendingMeter,s.pendingTempo])if(pending&&!integer(pending.targetBar))throw new Error('Invalid boundary');
        if(s.pendingMeter)s.pendingMeter.meter=this.meterApi.normalizeMeter(s.pendingMeter.meter);
        validateCursorCurves(s);validateCursorHolds(s);validateCursorRubato(s);validateAuthoredTempo(s.scoreTempo);
        s.scoreTempo=copyAuthoredTempo(s.scoreTempo);
        s.inputTempoCommit=inputTempoCommit(s.inputTempoCommit);
        if(this.cursor?.epoch===s.epoch&&(s.revision<this.cursor.revision||s.revision===this.cursor.revision&&s.tick<this.cursor.tick))return true;
        this.takeUp(s);
      } else throw new Error('Unknown ensemble message');
    }catch{this.rejected++;}
    return true;
  }
  propose(address,args=[],publisher={id:`${this.host}::conductor`,incarnation:this.incarnation}) {
    if(!ENSEMBLE_CONTROLS.has(address)||!this.active())return false;
    try{publisher=actor(publisher);if(!publisher.id.startsWith(`${this.host}::`))throw new Error('Foreign local publisher');
      if(this.primary===this.host)this.change(address,args,{publisher,host:this.host,hostIncarnation:this.incarnation});
      else if(this.primary)this.send({type:'ensemble_change',version:1,sessionId:this.sessionId,address,args,publisher},[this.primary]);
    }catch{this.rejected++;}
    return true;
  }
  timingSnapshot(){return this.cursor?new EnsembleTempoMap({sessionId:this.sessionId,cursor:this.cursor}):null;}
  tempoInfluenceReady() {
    return this.primary===this.host&&this.active()&&this.cursor&&this.readable(this.cursor)&&
      !this.cursor.pendingTempo&&!this.cursor.curve&&!this.cursor.inputTempoCommit&&!this.cursor.pendingMeter&&!this.meterWindow;
  }
  prepareTempoInfluence(now=this.now(),leadSeconds=3) {
    if(!Number.isFinite(leadSeconds)||leadSeconds<3||leadSeconds>6)throw new Error('Invalid tempo collection lead');
    if(!this.tempoInfluenceReady())return null;
    const map=this.timingSnapshot(),boundary=map.barAfter(now+leadSeconds,{minimumBar:map.cursor.bar+1});
    return {map,boundary};
  }
  acceptsTempoBasis(map) {
    return this.tempoInfluenceReady()&&map instanceof EnsembleTempoMap&&map.sessionId===this.sessionId&&
      map.epoch===this.cursor.epoch&&map.cursor.revision===this.cursor.revision;
  }
  acceptTempoInfluence({map,boundary,bpm,transitionBeats,maxBpmPerSecond,decisionId}) {
    if(!this.acceptsTempoBasis(map))throw new Error('Ensemble timing changed before selection');
    const {candidate,accepted}=prepareInputTempoRamp({sessionId:this.sessionId,cursor:this.cursor,boundary,bpm,
      transitionBeats,maxBpmPerSecond,decisionId,now:this.now()});
    // Stage validation and the full bounded trace before publishing the new
    // authoritative cursor. Acceptance never directly emits a musical tick.
    if(jsonBytes({type:'ensemble_state',version:1,sessionId:this.sessionId,state:candidate}).length>WIRE_LIMITS.controlBytes)
      throw new Error('Ensemble tempo exceeds the control-message budget');
    this.cursor=candidate;this.lastTempoRejection=null;this.advertise();this.onState(this.status());return accepted;
  }
  change(address,args=[],origin={publisher:{id:`${this.host}::conductor`,incarnation:this.incarnation},host:this.host,hostIncarnation:this.incarnation}) {
    if(!ENSEMBLE_CONTROLS.has(address)||!this.cursor||!Array.isArray(args))return;
    const holds=HOLD_ADDRESSES.has(address),spans=RUBATO_ADDRESSES.has(address);
    // A rendezvous committed owns the tempo and meter until it arrives: an ordinary proposal cannot overwrite it.
    if(['committed','bridging'].includes(this.rendezvous?.stage)){
      if(address==='/broadcast/timeSignature')this.lastMeterRejection='rendezvous-in-progress';else if(holds)this.lastHoldRejection='rendezvous-in-progress';
      else if(spans)this.lastRubatoRejection='rendezvous-in-progress';
      else this.lastTempoRejection='rendezvous-in-progress';
      this.onState(this.status());return;
    }
    this.advance();const s=this.cursor,mode=args[1],at=whenBar(mode);
    if(holds){this.changeHold(address,args[0],origin);return;}
    if(spans){this.changeRubato(address,args[0]);return;}
    // A meter or tempo from a bot that does not conduct the room, while one does: refused, said.
    const authority=this.authority();
    if(authority&&origin.publisher?.id!==authority&&!roomConductor(origin.publisher)){
      if(address==='/broadcast/timeSignature')this.lastMeterRejection=NOT_CONDUCTING;else this.lastTempoRejection=NOT_CONDUCTING;
      this.onState(this.status());return;
    }
    if(address==='/broadcast/timeSignature'){
      // One accepted future meter is already irreversible. New requests can
      // be retried after that boundary; they cannot overwrite it in transit.
      if(s.pendingMeter){this.lastMeterRejection='meter-change-already-committed';this.onState(this.status());return;}
      if(!this.meterWindow){
        const future=copy(s),threshold=this.now()+METER_NOTICE_SECONDS;let count=0;
        while((future.at<threshold||future.tickInBar!==0||s.inputTempoCommit&&future.bar<s.inputTempoCommit.endBar||at!==null&&future.bar<at||
          mode==='nextPhrase'&&future.bar%future.meter.phraseBars!==0)&&count++<100000)advanceCursor(future);
        if(count>=100000)throw new Error('Meter decision exceeds the future boundary budget');
        this.meterWindow=new MeterChangeWindow({identity:{id:`${this.host}::conductor`,incarnation:this.incarnation},
          sessionId:this.sessionId,epoch:s.epoch,members:[...this.candidates.values()],targetBar:future.bar,effectiveAt:future.at,
          cutoff:future.at-1.5,currentMeter:s.meter,policy:this.meterPolicy});
      }
      // A phrase-scoped proposal may not be pulled forward by a bar request.
      if(mode==='nextPhrase'&&this.meterWindow.targetBar%s.meter.phraseBars!==0){this.lastMeterRejection='incompatible-response-boundary';return;}
      // Nor one for a bar named pulled forward to an earlier window.
      if(at!==null&&this.meterWindow.targetBar<at){this.lastMeterRejection='incompatible-response-boundary';this.onState(this.status());return;}
      this.meterWindow.receive({...origin,meter:this.meterApi.normalizeMeter(args[0]||{}),receivedAt:this.now()});
      this.lastMeterRejection=null;this.onState(this.status());return;
    }
    if(s.inputTempoCommit){this.lastTempoRejection='input-tempo-ramp-already-committed';this.onState(this.status());return;}
    if(s.pendingMeter&&s.pendingTempo&&s.pendingTempo.targetBar<s.pendingMeter.targetBar){
      this.lastTempoRejection='earlier-tempo-is-part-of-committed-meter-timing';this.onState(this.status());return;
    }
    // Leave a full second for distribution, even when the next bar is near.
    const future=copy(s),threshold=this.now()+TEMPO_NOTICE_SECONDS;
    let count=0;while((future.at<threshold||future.tickInBar!==0||s.pendingMeter&&future.bar<s.pendingMeter.targetBar||at!==null&&future.bar<at||mode==='nextPhrase'&&future.bar%future.meter.phraseBars!==0)&&count++<100000)advanceCursor(future);
    if(count>=100000)return;
    {
      const value=address==='/broadcast/tempo'?{targetBpm:args[0],durationBars:0}:args[0]||{};
      s.pendingTempo={targetBpm:clampTempo(Number(value.targetBpm)||s.bpm,future.meter),durationBars:Math.max(0,Math.min(1024,Math.round(Number(value.durationBars)||0))),
        shape:['linear','easeInOut','exponential'].includes(value.shape)?value.shape:'easeInOut',targetBar:future.bar};
      queueAuthoredTempo(s,s.pendingTempo);
    }
    this.lastTempoRejection=null;
    s.revision++;this.advertise();this.onState(this.status());
  }
  // A hold declared, or its cue (clock-hold.js), taken by the primary into the cursor every conductor advances. A hold
  // declared less than HOLD_DISTRIBUTION_SECONDS before its pulse is refused: some conductor could emit that pulse
  // unheld. A cue moves the next pulse to its re-entry, the held pulse's own length after it.
  // (Readiness and a possible hold's choice as the primary takes them; what it decides is announced through onAnnounce.)
  changeHold(address,value,origin=null){
    const s=this.cursor,now=this.timeFor(s)??this.now();let outcome;
    if(address==='/broadcast/hold'){
      const future=copy(s),wanted=value&&typeof value==='object'?value:{};let count=0;
      const reached=state=>state.bar>wanted.bar||state.bar===wanted.bar&&state.tickInBar>=(holdTick({beat:Number(wanted.beat)||0,subdivision:Number(wanted.subdivision)||0},state.meter)??Infinity);
      while(Number.isSafeInteger(wanted.bar)&&!reached(future)&&future.bar<=wanted.bar&&count++<100000)advanceCursor(future);
      outcome=Number.isSafeInteger(wanted.bar)&&future.bar===wanted.bar&&future.at<now+HOLD_DISTRIBUTION_SECONDS?{rejected:'too-soon-to-distribute'}:queueHold(s,value);
    }else if(address==='/broadcast/holdSelect')outcome=selectHold(s,value);
    else{
      outcome=address==='/broadcast/holdReady'?readyHold(s,origin?.publisher?.id,value,now):releaseHold(s,value,now);
      if(outcome.resumeAt!=null)s.at=s.holding.resumeAt+s.holding.pulseSeconds;
    }
    this.announce(takeAnnouncements(s));
    this.lastHoldRejection=outcome.rejected??null;
    if(!outcome.rejected){s.revision++;this.advertise();}
    this.onState(this.status());
  }
  // A rubato span declared, or a revision of one (rubato-clocks.js), taken by the primary into the cursor every
  // conductor advances, on 2a's terms:
  // - a span declared less than HOLD_DISTRIBUTION_SECONDS before its downbeat is refused, as a hold is, since some
  //   conductor could emit that downbeat unbent; and one ending at a tempo outside its meter's range, since the cursor
  //   goes on at it;
  // - a revision counts its committed position at least HOLD_DISTRIBUTION_SECONDS ahead, so that every conductor has it
  //   before its pulses reach the knots it changes, and its announcement names the tick it takes effect at;
  // - a span or revision that would not fit the wire's control message is refused, never thinned;
  // - what the primary decides, taken or refused, is announced once from `clock`.
  changeRubato(address,value){
    const s=this.cursor,now=this.timeFor(s)??this.now(),before={rubatos:copy(s.rubatos??[]),rubato:copy(s.rubato??null)};
    const refuse=reason=>({outcome:{rejected:reason},announcements:[{address:address==='/broadcast/rubato'?'/broadcast/rubatoRefused':'/broadcast/rubatoRevised',
      args:[address==='/broadcast/rubato'?{id:String(value?.id??''),...(Number.isSafeInteger(value?.bar)?{bar:value.bar}:{}),reason}:
        {id:String(value?.id??''),revision:Number(value?.revision),revised:false,reason}]}]});
    let decided;
    if(address==='/broadcast/rubato'){
      const future=copy(s),bar=value?.bar,last=Array.isArray(value?.knots)?Number(value.knots.at(-1)?.density):NaN;let count=0;
      while(Number.isSafeInteger(bar)&&(future.bar<bar||future.tickInBar!==0)&&future.bar<=bar&&count++<100000)advanceCursor(future);
      const ends=60/(last*4/(s.meter.denominator??bandMeter().denominator));
      decided=Number.isSafeInteger(bar)&&future.bar===bar&&future.at<now+HOLD_DISTRIBUTION_SECONDS?refuse('too-soon-to-distribute')
        :Number.isFinite(last)&&!tempoInRange(ends,s.meter)&&!(s.pendingMeter&&tempoInRange(ends,s.pendingMeter.meter))?refuse('the span ends at a tempo outside its meter\'s range')
        :cursorRubatoControl(s,address,value);
    }else{
      // A revision of the last knot moves the tempo the cursor goes on at: in its meter's range too.
      const target=s.rubato?.span.id===value?.id?s.rubato.span:(s.rubatos??[]).find(span=>span.id===value?.id),given=Array.isArray(value?.knots)?value.knots:[];
      const last=target&&Number.isInteger(value?.from)&&value.from+given.length===target.us.length?Number(given.at(-1)?.density??given.at(-1)):NaN;
      const ends=60/(last*4/(s.meter.denominator??bandMeter().denominator));
      decided=Number.isFinite(last)&&!tempoInRange(ends,s.meter)&&!(s.pendingMeter&&tempoInRange(ends,s.pendingMeter.meter))?refuse('the span would end at a tempo outside its meter\'s range')
        :cursorRubatoControl(s,address,value,{lead:HOLD_DISTRIBUTION_SECONDS});
      // Where it takes effect: the first pulse after the knot before `from`, which it no longer reaches.
      if(decided.outcome.revised&&s.rubato?.span.id===value.id){
        const knot=unpackRubatoSpan(s.rubato.span).knots[value.from-1].at,future=copy(s);let count=0;
        while(future.rubato&&compare(ratio(future.rubato.elapsed),knot)<=0&&count++<100000)advanceCursor(future);
        for(const said of decided.announcements)if(said.address==='/broadcast/rubatoRevised')said.args[0].atTick=future.tick;
      }
    }
    if(!decided.outcome.rejected&&jsonBytes({type:'ensemble_state',version:1,sessionId:this.sessionId,state:s}).length>WIRE_LIMITS.controlBytes){
      Object.assign(s,before);decided=refuse('the span does not fit the conductor\'s control message');
    }
    this.announce(decided.announcements);
    this.lastRubatoRejection=decided.outcome.rejected??null;
    if(!decided.outcome.rejected){s.revision++;this.advertise();}
    this.onState(this.status());
  }
  advance() {
    if(!this.active())return;
    // The first bot has arrived, or the last has left: say so, and let the conductors choose again.
    if(this.candidates.has(this.host)&&this.refreshBid())this.elect();
    // A held state waits for two things: a clock we can read, and a bar line in what is still playing.
    if(this.held&&this.readable(this.held)&&(!this.cursor||this.cursor.tickInBar===0||!this.handover||this.now()>this.handover.until))this.adopt(this.held);
    if(!this.cursor)return;
    if(this.pieces==='negotiate'){this.rebaseOwnPiece();this.advanceRendezvous();if(this.foreign)this.requestRendezvous();}
    if(this.primary===this.host&&this.meterWindow){
      const future=copy(this.cursor);let steps=0;
      while(future.bar<this.meterWindow.targetBar&&steps++<100000)advanceCursor(future);
      if(future.bar===this.meterWindow.targetBar&&future.tickInBar===0)this.meterWindow.updateBoundary(future.at);
      if(this.now()>=this.meterWindow.cutoff){
        try{
          const decision=this.meterWindow.seal(this.now(),{authority:this.authority()});this.lastMeterDecision=decision;
          if(decision.accepted)this.cursor.pendingMeter={meter:decision.meter,targetBar:decision.targetBar};
        }catch(error){this.rejected++;this.lastMeterDecision={status:'unresolved',accepted:false,reason:error.message};}
        this.cursor.meterDecision=meterDecisionSummary(this.lastMeterDecision);this.cursor.revision++;this.advertise();
        this.meterWindow=null;this.onState(this.status());
      }
    }
    const s=this.cursor;
    const time=this.timeFor(s);
    if(time===null)return;
    const previous=[s.meter,s.pendingMeter,s.pendingTempo,s.curve,s.inputTempoCommit,s.holding,s.rubato?.span];
    let latest=null,count=0;const waiting=(s.rubatos??[]).map(span=>({id:span.id,bar:span.bar})),played=new Set();
    while(s.at<=time&&count++<100000){latest=copy(s);advanceCursor(s);if(s.rubato)played.add(s.rubato.span.id);}
    // A span whose downbeat passed unplayed was dropped by the cursor (the kernel, clock-rubato.js): said, as a clock
    // says it. One that began within these pulses, even one over by their end, played.
    const kept=new Set([...(s.rubatos??[]).map(span=>span.id),...played]);
    const dropped=waiting.filter(span=>!kept.has(span.id));
    if(dropped.length)this.announce(dropped.map(span=>({address:'/broadcast/rubatoRefused',args:[{...span,reason:'its downbeat passed while another span played'}]})));
    // A hold the pulse ends or begins, announced on it (clock-hold.js): a bot can tell a hold from a clock that stopped.
    const held=latest&&heldAt(latest);
    // A rubato span the pulse begins, plays in or ends (rubato-clocks.js), and inside one the pulse's own tempo.
    const rubato=latest&&(latest.rubato||latest.rubatos?.length)?cursorRubatoPulse(copy(latest),latest.at):null;
    this.announce(takeAnnouncements(s));
    if(latest&&latest.tick>this.lastTick){this.lastTick=latest.tick;
      this.continuation={cursor:s,offset:this.handover.offset,session:{seed:latest.seed,startedAt:latest.startedAt,beat:latest.beat,tick:latest.tick}};
      this.onTick({...this.meterApi.clockContext(latest),...authoredTempoFields(latest),...(held?{held}:{}),...(rubato?{rubato:rubato.field}:{}),...(rubato?.seconds?{bpm:60/rubato.seconds/latest.meter.subdivision}:rubato?.bpm?{bpm:rubato.bpm}:{}),ensembleBeat:latest.beat,ensembleSeed:latest.seed,ensembleStartedAt:latest.startedAt,ensembleFirstBeatAt:latest.startedAt,ensembleTime:Math.max(0,(this.wallNow()-latest.startedAt)/1000)});}
    // Notify the local controls when a queued change begins or completes.
    // This does not add relay traffic or publish every subdivision's BPM.
    if([s.meter,s.pendingMeter,s.pendingTempo,s.curve,s.inputTempoCommit,s.holding,s.rubato?.span].some((value,i)=>value!==previous[i]))this.onState(this.status());
    if(this.primary===this.host&&this.now()-(this.lastAdvertised||0)>=2)this.advertise();
  }
  status(){return {primary:this.primary,primaryIncarnation:this.primaryIncarnation,candidates:[...this.candidates.values()],state:this.cursor?copy(this.cursor):null,rejected:this.rejected,
    authority:this.authority(),
    meterDecision:meterDecisionSummary(this.meterWindow?.status()||this.lastMeterDecision)||this.cursor?.meterDecision||null,
    meterRejection:this.lastMeterRejection||null,tempoRejection:this.lastTempoRejection||null,
    holds:this.cursor?holdStatus(this.cursor):null,holdRejection:this.lastHoldRejection||null,
    rubato:this.cursor?{waiting:(this.cursor.rubatos??[]).map(span=>({id:span.id,bar:span.bar,revision:span.revision})),
      playing:this.cursor.rubato?{id:this.cursor.rubato.span.id,revision:this.cursor.rubato.span.revision,startedAt:this.cursor.rubato.startSeconds}:null}:null,
    rubatoRejection:this.lastRubatoRejection||null,
    ...(this.pieces==='negotiate'?{pieces:'negotiate',rendezvous:this.rendezvousSummary(),coupling:this.coupling?copy(this.coupling):null}:{})};}
  announce(messages){if(messages.length)try{this.onAnnounce(messages)}catch{this.rejected++}}
  close(){clearTimeout(this.electionTimer);}

  // ---- Negotiating two pieces (research/conductor-negotiation/IMPLEMENTER_HANDOFF.md; conductor-rendezvous.js) ----
  // The piece asked (the requester, playing its own piece beside the leader's) offers its basis; the leader (the
  // coordinator) proposes a plan from both, the leader's meter and tempo as the target; the requester checks and accepts
  // it; the leader commits before the earlier anchor; each bridges on its own cursor, from its anchor at its bridge
  // tempo, and at the arrival downbeat takes the target; the requester then takes the leader's timing with its own
  // counts. A plan is bound to the session, the reference epoch, both pieces and their revisions; anything that
  // changes under it, a late answer, a missed anchor, a party gone or a new leader ends it, said so to the other where
  // it can be. Messages are the conductor channel's, reliable and ordered while connected; a disconnect ends a plan.
  rendezvousSummary(){const r=this.rendezvous;return r?{stage:r.stage,role:r.role,with:r.with,planId:r.plan?.planId??null,reason:r.reason??null,
    bridge:r.bridge?{anchorBar:r.bridge.anchorBar,arrivalBar:r.bridge.arrivalBar,bridgeBpm:r.bridge.bridgeBpm,bars:r.bridge.bars}:null}:null;}
  sendRendezvous(type,body,to){this.send({type:`ensemble_rendezvous_${type}`,version:1,sessionId:this.sessionId,...body},[to]);}
  logRendezvous(entry){this.rendezvousLog.push({at:this.now(),...entry});if(this.rendezvousLog.length>64)this.rendezvousLog.shift();}
  // An independent piece kept through a change of leader, re-expressed in the new reference once it can be read:
  // its next pulse stays at the same moment. Every moment the piece keeps in the reference's seconds moves with it: a
  // playing rubato span's start, from which its map is laid, and a hold's start, resume, cue and members' readiness
  // (the rubato report's Stage D, a span under a mismatched epoch). Lengths and bar counts stay as they are.
  rebaseOwnPiece(){
    const epoch=this.clock.offer?.reference?.epoch,s=this.cursor;
    if(!s||!epoch||s.epoch===epoch||this.lastTick<0||!this.handover||!this.readable({epoch}))return;
    let reference;try{reference=this.clock.referenceTime();}catch{return;}
    const shift=reference-(this.now()+this.handover.offset),moved=value=>Number.isFinite(value)?value+shift:value;
    s.at+=shift;
    if(s.rubato)s.rubato.startSeconds=moved(s.rubato.startSeconds);
    if(s.holding){
      for(const key of ['startedAt','resumeAt','cueAt'])s.holding[key]=moved(s.holding[key]);
      if(s.holding.ready)s.holding.ready=Object.fromEntries(Object.entries(s.holding.ready).map(([who,at])=>[who,moved(at)]));
    }
    s.epoch=epoch;s.revision++;
    this.handover={offset:reference-this.now(),until:this.now()+HANDOVER_SECONDS};
  }
  requestRendezvous(){
    const r=this.rendezvous;
    if(r&&!['refused','declined','aborted','arrived'].includes(r.stage))return;
    if(r&&this.now()<(r.retryAfter??0))return;
    if(!this.primary||this.primary===this.host||!this.cursor||!this.foreign||!this.readable(this.cursor))return;
    let basis;
    try{basis=rendezvousBasis(this.cursor,{id:this.host,now:this.now(),advance:advanceCursor,policy:this.rendezvousPolicy});}
    catch(error){this.rendezvous={stage:'refused',role:'requester',with:this.primary,reason:error.message,retryAfter:this.now()+2};return;}
    this.rendezvous={stage:'requested',role:'requester',with:this.primary,withIncarnation:this.primaryIncarnation,requestedAt:this.now()};
    this.sendRendezvous('request',{epoch:this.cursor.epoch,piece:{seed:this.cursor.seed,startedAt:this.cursor.startedAt,revision:this.cursor.revision},basis},this.primary);
    this.logRendezvous({event:'requested',with:this.primary});
  }
  receiveRendezvous(value,e){
    const kind=value.type.slice('ensemble_rendezvous_'.length),r=this.rendezvous,from=r&&r.with===e.host&&(!r.withIncarnation||r.withIncarnation===e.incarnation);
    const planMatches=r?.plan&&value.planId===r.plan.planId&&value.digest===r.plan.digest;
    if(kind==='request'){
      const member=this.candidates.get(e.host);
      if(!member||member.incarnation!==e.incarnation)throw new Error('Unregistered rendezvous requester');
      this.coordinateRendezvous(e.host,e.incarnation,value);return;
    }
    if(kind==='propose'){
      if(e.host!==this.primary||e.incarnation!==this.primaryIncarnation)throw new Error('Only the leader proposes a rendezvous');
      const plan=value.plan;
      // The same plan again, already accepted: the answer again, nothing more.
      if(r?.plan&&plan?.planId===r.plan.planId&&plan?.digest===r.plan.digest&&['accepted','committed','bridging'].includes(r.stage)){
        this.sendRendezvous('accept',{planId:plan.planId,digest:plan.digest},e.host);return;
      }
      const problem=r?.stage!=='requested'||r.with!==e.host?'not-requested':
        rendezvousProblem(plan,{host:this.host,incarnation:this.incarnation,sessionId:this.sessionId,epoch:this.cursor?.epoch,cursor:this.cursor,now:this.now(),policy:this.rendezvousPolicy,acceptTarget:this.acceptTarget});
      if(problem){
        this.sendRendezvous('decline',{planId:plan?.planId??null,digest:plan?.digest??null,reason:problem},e.host);
        if(r?.stage==='requested')this.rendezvous={...r,stage:'declined',reason:problem,retryAfter:this.now()+2};
        this.logRendezvous({event:'declined',reason:problem});this.onState(this.status());return;
      }
      this.rendezvous={...r,stage:'accepted',plan};
      this.sendRendezvous('accept',{planId:plan.planId,digest:plan.digest},e.host);
      this.logRendezvous({event:'accepted',planId:plan.planId});this.onState(this.status());return;
    }
    // A refusal answers a request, which has no plan yet.
    if(kind==='refuse'&&from&&r.role==='requester'&&r.stage==='requested'){}
    else if(!from||!planMatches)return;// stale, reordered, or for a plan that is not this conductor's
    if(kind==='accept'&&r.role==='coordinator'){
      if(r.stage==='committed'||r.stage==='bridging'){this.sendRendezvous('commit',{planId:r.plan.planId,digest:r.plan.digest},e.host);return;}
      if(r.stage!=='proposed')return;
      const problem=this.now()>=r.plan.commitBy?'acceptance-late':
        rendezvousProblem(r.plan,{host:this.host,incarnation:this.incarnation,sessionId:this.sessionId,epoch:this.cursor?.epoch,cursor:this.cursor,now:this.now(),policy:this.rendezvousPolicy,acceptTarget:()=>true});
      if(problem){this.abortRendezvous(problem);return;}
      this.sendRendezvous('commit',{planId:r.plan.planId,digest:r.plan.digest},e.host);
      this.scheduleBridge();this.logRendezvous({event:'committed',planId:r.plan.planId});return;
    }
    if(kind==='commit'&&r.role==='requester'){
      if(r.stage==='committed'||r.stage==='bridging'){this.sendRendezvous('committed',{planId:r.plan.planId,digest:r.plan.digest},e.host);return;}
      if(r.stage!=='accepted')return;
      const anchor=r.plan.requester.anchor.at;
      if(this.now()>=anchor-this.rendezvousPolicy.commitMarginSeconds){this.abortRendezvous('anchor-missed');return;}
      this.scheduleBridge();this.sendRendezvous('committed',{planId:r.plan.planId,digest:r.plan.digest},e.host);
      this.logRendezvous({event:'committed',planId:r.plan.planId});return;
    }
    if(kind==='committed'&&r.role==='coordinator'){r.confirmed=true;return;}
    if(['abort','decline','refuse'].includes(kind)){
      this.abortRendezvous(value.reason||kind,{notify:false});
      // A leader that does not negotiate, or no rendezvous after a few tries: the leader's piece is taken up at a bar
      // line, as it is without negotiating, rather than two pieces going on out of step.
      if(r.role==='requester'&&this.foreign&&(value.reason==='not-negotiating'||++this.refusals>=this.rendezvousPolicy.attempts)){
        this.held=this.foreign;this.foreign=null;this.refusals=0;this.logRendezvous({event:'fell-back',reason:value.reason});this.onState(this.status());
      }
    }
  }
  // The leader's side: a plan from its own basis and the requester's, or a refusal with its reason.
  coordinateRendezvous(host,incarnation,request){
    const refuse=reason=>{this.sendRendezvous('refuse',{planId:null,digest:null,reason},host);this.logRendezvous({event:'refused',with:host,reason});};
    if(this.primary!==this.host)return refuse('not-the-leader');
    if(this.pieces!=='negotiate')return refuse('not-negotiating');
    if(this.rendezvous&&!['refused','declined','aborted','arrived'].includes(this.rendezvous.stage))return refuse('another-rendezvous-in-progress');
    if(!this.cursor||request.epoch!==this.cursor.epoch)return refuse('other-reference-epoch');
    const piece=request.piece||{},anchor=request.basis?.anchor||{};
    if(![piece.seed,piece.startedAt,piece.revision,anchor.bar,anchor.tick,anchor.beat,anchor.pulsesPerBar,anchor.subdivision].every(integer)||!Number.isFinite(anchor.at))return refuse('invalid-basis');
    if(piece.seed===this.cursor.seed&&piece.startedAt===this.cursor.startedAt)return refuse('same-piece');
    let own;try{own=rendezvousBasis(this.cursor,{id:this.host,now:this.now(),advance:advanceCursor,policy:this.rendezvousPolicy});}catch(error){return refuse(error.message);}
    let result;
    try{
      result=proposeRendezvous({planId:`${this.host}:${this.incarnation}:${++this.planSequence}`,sessionId:this.sessionId,epoch:this.cursor.epoch,now:this.now(),policy:this.rendezvousPolicy,
        coordinator:{host:this.host,incarnation:this.incarnation,seed:this.cursor.seed,startedAt:this.cursor.startedAt,revision:this.cursor.revision,basis:own},
        requester:{host,incarnation,seed:piece.seed,startedAt:piece.startedAt,revision:piece.revision,basis:{participant:request.basis.participant,anchor}},
        target:{meter:this.cursor.meter,bpm:this.cursor.bpm}});
    }catch(error){return refuse(`invalid-basis: ${error.message}`);}
    if(result.refused)return refuse(result.refused);
    this.rendezvous={stage:'proposed',role:'coordinator',with:host,withIncarnation:incarnation,plan:result.plan};
    this.sendRendezvous('propose',{plan:result.plan},host);
    this.logRendezvous({event:'proposed',with:host,planId:result.plan.planId});this.onState(this.status());
  }
  // The bridge on this conductor's own cursor: its bridge tempo from its anchor bar (the arrival is set once it runs).
  scheduleBridge(){
    const r=this.rendezvous,bridge=bridgeOf(r.plan,this.host);
    this.cursor.pendingTempo={targetBpm:bridge.bridgeBpm,durationBars:0,shape:'linear',targetBar:bridge.anchorBar};
    this.cursor.revision++;this.rendezvous={...r,stage:'committed',bridge};
    if(this.primary===this.host)this.advertise();this.onState(this.status());
  }
  advanceRendezvous(){
    const r=this.rendezvous,s=this.cursor;if(!r||!s)return;
    if(r.stage==='proposed'&&this.now()>=r.plan.commitBy){this.abortRendezvous('acceptance-late');return;}
    if(r.stage==='accepted'&&this.now()>=r.plan.requester.anchor.at-this.rendezvousPolicy.commitMarginSeconds){this.abortRendezvous('commit-late');return;}
    // The leader bridges only with the other's acknowledgement of the commit in hand, just before its own anchor:
    // without it, the other may never have had the commit, and the leader would bridge alone.
    if(r.role==='coordinator'&&r.stage==='committed'&&!r.confirmed&&this.now()>=r.plan.coordinator.anchor.at-this.rendezvousPolicy.commitMarginSeconds/3){this.abortRendezvous('confirmation-late');return;}
    if(r.stage==='committed'&&s.bar>=r.bridge.anchorBar&&!s.pendingTempo&&!s.curve){
      s.pendingMeter={meter:copy(r.bridge.target.meter),targetBar:r.bridge.arrivalBar};
      s.pendingTempo={targetBpm:r.bridge.target.bpm,durationBars:0,shape:'linear',targetBar:r.bridge.arrivalBar};
      s.revision++;r.stage='bridging';
      if(this.primary===this.host)this.advertise();this.onState(this.status());return;
    }
    if(r.stage==='bridging'&&s.bar>=r.bridge.arrivalBar&&!s.pendingMeter&&!s.pendingTempo){
      r.stage='arrived';r.arrivedAt=this.now();
      if(r.role==='requester'){this.coupling=couplingOf(r.plan);this.foreign=null;}
      this.logRendezvous({event:'arrived',planId:r.plan.planId,bar:s.bar});this.onState(this.status());
    }
  }
  // Ends a rendezvous: a bridge not yet begun is taken back; one already running goes on, said so.
  abortRendezvous(reason,{notify=true}={}){
    const r=this.rendezvous;if(!r||['aborted','arrived'].includes(r.stage))return;
    const s=this.cursor;let outcome='ended';
    if(r.bridge&&s){
      if(r.stage==='committed'&&s.bar<r.bridge.anchorBar&&s.pendingTempo?.targetBar===r.bridge.anchorBar){s.pendingTempo=null;s.revision++;outcome='bridge-withdrawn';}
      else if(['committed','bridging'].includes(r.stage))outcome='bridged-alone';
    }
    if(notify&&r.plan&&r.with)this.sendRendezvous('abort',{planId:r.plan.planId,digest:r.plan.digest,reason},r.with);
    this.rendezvous={...r,stage:'aborted',reason,outcome,retryAfter:this.now()+5};
    this.logRendezvous({event:'aborted',reason,outcome,planId:r.plan?.planId??null});
    if(this.primary===this.host&&outcome!=='ended')this.advertise();this.onState(this.status());
  }
}
