export async function subscribeMidiInputs(handler,{navigatorObject=globalThis.navigator,onState=()=>{}}={}){
  if(!navigatorObject?.requestMIDIAccess)return{access:null,inputs:[],close(){}};
  const access=await navigatorObject.requestMIDIAccess({sysex:false}),listeners=[];
  const attach=input=>{if(listeners.some(([port])=>port===input))return;const listener=event=>handler([...event.data],event.timeStamp,input);input.addEventListener('midimessage',listener);listeners.push([input,listener])};
  const detach=input=>{for(let i=listeners.length-1;i>=0;i--)if(listeners[i][0]===input){input.removeEventListener('midimessage',listeners[i][1]);listeners.splice(i,1)}};
  for(const input of access.inputs.values())if(input.state!=='disconnected')attach(input);
  const stateListener=event=>{const input=event.port;if(input?.type!=='input')return;if(input.state==='connected')attach(input);else if(input.state==='disconnected')detach(input);onState({input,state:input.state})};
  access.addEventListener?.('statechange',stateListener);
  return{access,get inputs(){return [...access.inputs.values()].filter(input=>input.state!=='disconnected')},close(){for(const [input,listener]of listeners)input.removeEventListener('midimessage',listener);access.removeEventListener?.('statechange',stateListener);listeners.length=0}};
}
