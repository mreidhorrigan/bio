// Several FormBOTs agreeing on one form, using only messages the protocol
// already carries.
//
// What happens today with two of them, observed rather than inferred: each
// draws its own archetype and publishes its own `kind:'form'` plan, and
// `advancePlanning` resolves them with a bare assignment in Map order. Two
// FormBOTs in one ensemble end up following different forms with different
// endpoints -- one at eight phrases, the other at nine -- and each adopts the
// other's. Nobody decides; whoever was applied last wins.
//
// The fix is not an election. Every FormBOT already receives every form plan
// and every response to it, and the duration selector in composition-duration.js
// is deterministic by construction: the same sealed inputs produce the same
// decision wherever they are evaluated. So each FormBOT can run the same
// selector over the same evidence and reach the same winner without a single
// extra message. The losers then say so out loud, by revising their own plan's
// priority downward, which is what lets every OTHER bot -- who never ran a
// selector -- converge on the same form through the ordinary plan rules.
//
// That yielding is the whole protocol: agreement is reached by computation and
// published as a concession. It assumes every FormBOT saw the same messages,
// which a network does not guarantee; a FormBOT that saw a different slate will
// concede to a different winner, and this module cannot detect that. Deciding,
// being told, and agreeing remain three different things.

import {durationPolicy} from './composition-duration.js';

const clamp=(value,low,high)=>value<low?low:value>high?high:value;
const byId=(left,right)=>left<right?-1:left>right?1:0;
const unit=(value,name)=>{
  const number=Number(value);
  if(!Number.isFinite(number)||number<-1||number>1)throw new RangeError(`${name} must be between -1 and 1`);
  return number;
};

// The protocol's six dispositions already say what a bot thinks of a plan, so a
// negotiation needs no new vocabulary and no new address. `abstain` is absent
// on purpose: it produces no rating at all, because an abstention is the one
// answer that must never be read as a quiet yes.
export const DISPOSITION_RATINGS=Object.freeze({
  accept:1,
  transform:.5,   // it would play this, differently
  counter:-.25,   // it has something else in mind
  defer:-.5,      // not now
  decline:-1,
});

export const FORM_NEGOTIATION_DEFAULTS=Object.freeze({
  ratings:DISPOSITION_RATINGS,
  // What a yielding author sets its own plan's priority to. It has to sit below
  // whatever the winner holds, or the concession says nothing to the bots that
  // resolve plans by priority.
  concessionPriority:.1,
  // A form plan proposes a whole future in bars, so the beats it implies are
  // derived rather than declared: its bars, each in the meter it will be
  // played in. Where the plan does not say, that is the meter in force now,
  // which is why a future bar is not a stable unit and why these defaults
  // stand in when a clock says nothing.
  defaultBeatsPerBar:4,
  defaultPhraseBars:4,
  // A performer's voice on the piece's length: the listener who hears them stands for a person, and a person in the
  // ensemble has a large say (formWeights). This is the share of the whole vote their voices hold together, whatever
  // the ensemble's size: at two thirds, a performer who wants one version and not another outweighs a room of bots
  // with no view, and the envelope and prices still bound what they can ask.
  performerShare:2/3,
  // The voice that plans the form's returns (mh_MemoryBOT, known by the return plans it publishes) on the piece's
  // length: this share of what the performers' voices leave. It speaks only where a return is still owed and a version
  // of the form would let it sound (thematic-form.js owedFormAnswer), and it is the one voice that knows what the form
  // owes its themes. The others' readiness is level across the versions, so as one voice among many its view would be
  // diluted by the ensemble's size, as a performer's would. At a half, it outweighs a room of bots with no view when
  // nobody performs, and a performer's voice still outweighs it four to one. Ours.
  thematicShare:1/2,
});

export function formNegotiationPolicy(overrides={}){
  const source=overrides&&typeof overrides==='object'?overrides:{};
  const ratings={...FORM_NEGOTIATION_DEFAULTS.ratings};
  for(const [name,value] of Object.entries(source.ratings||{})){
    if(!(name in ratings))throw new RangeError(`Unknown plan disposition: ${name}`);
    ratings[name]=unit(value,`ratings.${name}`);
  }
  const concession=Number(source.concessionPriority??FORM_NEGOTIATION_DEFAULTS.concessionPriority);
  if(!Number.isFinite(concession)||concession<0||concession>1)
    throw new RangeError('concessionPriority must be between 0 and 1');
  const performerShare=Number(source.performerShare??FORM_NEGOTIATION_DEFAULTS.performerShare);
  if(!Number.isFinite(performerShare)||performerShare<0||performerShare>=1)
    throw new RangeError('performerShare must be at least 0 and less than 1');
  const thematicShare=Number(source.thematicShare??FORM_NEGOTIATION_DEFAULTS.thematicShare);
  if(!Number.isFinite(thematicShare)||thematicShare<0||thematicShare>=1)
    throw new RangeError('thematicShare must be at least 0 and less than 1');
  return Object.freeze({ratings:Object.freeze(ratings),concessionPriority:concession,performerShare,thematicShare,
    defaultBeatsPerBar:FORM_NEGOTIATION_DEFAULTS.defaultBeatsPerBar,
    defaultPhraseBars:FORM_NEGOTIATION_DEFAULTS.defaultPhraseBars,
    duration:source.duration?durationPolicy(source.duration):durationPolicy()});
}

// Which of a form's declarations governs (the mathematical adoption's timeline:legacy-form-authority; the rule chosen
// 27 September). Its sections do: the music it will play, each section at its own phrase length, else the plan's, else
// the phrase in force (the clock's, given as `phraseBars`), else the policy's default. A declared total (totalPhrases)
// or ending (candidateEndpoint) is a summary of them. It governs only a plan with no sections, and a plan whose summary
// disagrees with its sections is not prepared (formFaults), so the negotiation never agrees on a form that says two
// things. The fallback is the one form progress (form-development.js) and ManageBOT's placing (compileSections) use;
// these helpers had fallen back to a fixed four bars.
function planPhraseBars(plan,policy,phraseBars){
  return Math.max(1,Number(plan?.payload?.phraseBars)||Number(phraseBars)||policy.defaultPhraseBars);
}
// The plan's own sections as spans of bars, each with the meter it proposes
// when it proposes one (mh_PlexBOT's sections carry a numerator and their own
// phrase length; mh_FormBOT's carry neither) and null otherwise.
function formSegments(plan,policy,phraseBars){
  const payload=plan?.payload||{},sections=Array.isArray(payload.sections)?payload.sections:[],
    fallback=planPhraseBars(plan,policy,phraseBars);
  return sections.map(section=>({
    bars:Math.max(1,Number(section?.phrases)||1)*Math.max(1,Number(section?.phraseBars)||fallback),
    beatsPerBar:Number(section?.numerator)>0?Number(section.numerator):null}));
}

// How long the form in this plan is, in beats: its sections' bars, each in the
// meter the section proposes, and otherwise in `beatsPerBar`, the meter in force;
// a plan with no sections, its declared phrases.
export function formBeats(plan,{beatsPerBar,phraseBars,policy=formNegotiationPolicy()}={}){
  const payload=plan?.payload||{},beats=Math.max(1,Number(beatsPerBar)||policy.defaultBeatsPerBar),
    segments=formSegments(plan,policy,phraseBars),phrases=Number(payload.totalPhrases);
  if(segments.length)return segments.reduce((total,segment)=>total+segment.bars*(segment.beatsPerBar??beats),0);
  return phrases>0?phrases*planPhraseBars(plan,policy,phraseBars)*beats:null;
}

// Where the form in this plan ends, in the room's beats, given the room's count
// at the start of bar `bar`. The count is exact up to now; the bars still to
// come are integrated through the plan's own sections, each in the meter it
// proposes, and otherwise in the meter in force now, which is as much as
// anybody knows of a future nobody has proposed. A form's length is not its
// ending: the duration controller compares endpoints with the room's clock,
// and a length measured from the plan's start put every ending a lead-in
// phrase early, and every form proposed after an extension -- or by a FormBOT
// that joined late -- behind "now" before it began. Multiplying the ending's
// bar number by today's numerator is not a conversion either: it re-measures
// every bar already played in today's meter, so leaving a 4/4 for a 3/4 moved
// every ending backward. The ending is where its sections end (formEndBar),
// which for a prepared form is the bar its author acts on (candidateEndpoint).
// Null when the plan says neither.
export function formEndpointBeats(plan,{bar,beats,beatsPerBar,phraseBars,policy=formNegotiationPolicy()}={}){
  const now=Number(bar),counted=Number(beats);
  if(!Number.isFinite(now)||!Number.isFinite(counted))return null;
  const current=Math.max(1,Number(beatsPerBar)||policy.defaultBeatsPerBar),
    starts=Number(plan?.appliesAt?.bar),start=Number.isFinite(starts)?starts:now,
    segments=formSegments(plan,policy,phraseBars),end=formEndBar({...plan,appliesAt:{...plan?.appliesAt,bar:start}},{policy,phraseBars});
  if(end===null)return null;
  if(end<=now)return counted-(now-end)*current;
  let total=counted,cursor=now,from=start;
  for(const segment of segments){
    const to=from+segment.bars,overlapFrom=Math.max(from,cursor),overlapTo=Math.min(to,end);
    from=to;
    if(overlapTo<=overlapFrom)continue;
    // Bars before the plan begins (its lead-in phrase) are in the meter in force.
    total+=(overlapFrom-cursor)*current+(overlapTo-overlapFrom)*(segment.beatsPerBar??current);
    cursor=overlapTo;
  }
  return total+Math.max(0,end-cursor)*current;
}

// The bar a form ends at: the end of its sections, each at its own phrase length; a plan with no sections, the ending
// its author declares (candidateEndpoint), else its declared phrases. Null when the plan says none of these.
export function formEndBar(plan,{phraseBars,policy=formNegotiationPolicy()}={}){
  const start=Number(plan?.appliesAt?.bar),segments=formSegments(plan,policy,phraseBars);
  if(Number.isFinite(start)&&segments.length)return start+segments.reduce((total,segment)=>total+segment.bars,0);
  const declared=Number(plan?.payload?.candidateEndpoint?.bar),phrases=Number(plan?.payload?.totalPhrases);
  if(Number.isFinite(declared))return declared;
  return Number.isFinite(start)&&phrases>0?start+phrases*planPhraseBars(plan,policy,phraseBars):null;
}

// A form plan's timeline, compiled: its sections as spans of bars from where it applies, each in the meter it proposes
// (null: the meter in force), and where they end. The ending it declares (candidateEndpoint) is kept beside it, since a
// plan whose declared ending is not where its sections end says two different things. Null when it has no bar to begin.
export function formTimeline(plan,{phraseBars,policy=formNegotiationPolicy()}={}){
  const start=Number(plan?.appliesAt?.bar);
  if(!Number.isFinite(start))return null;
  const payload=plan?.payload||{},sections=Array.isArray(payload.sections)?payload.sections:[],spans=[];
  let bar=start;
  formSegments(plan,policy,phraseBars).forEach((segment,index)=>{
    spans.push(Object.freeze({role:String(sections[index]?.role??''),from:bar,to:bar+segment.bars,beatsPerBar:segment.beatsPerBar}));
    bar+=segment.bars;
  });
  const phrases=Number(payload.totalPhrases);
  const summarised=sections.length&&phrases>0?phrases*planPhraseBars(plan,policy,phraseBars):null;
  if(!spans.length&&phrases>0){
    bar=start+phrases*planPhraseBars(plan,policy,phraseBars);
    spans.push(Object.freeze({role:'',from:start,to:bar,beatsPerBar:null}));
  }
  const declared=Number(payload.candidateEndpoint?.bar);
  return Object.freeze({start,spans:Object.freeze(spans),end:spans.length?bar:null,declared:Number.isFinite(declared)?declared:null,
    // Its declared total in bars, where it declares one beside its sections.
    summarised});
}

// Why a form cannot be played as it stands: facts about its compiled timeline and the room, never about whether anybody
// likes it (the negotiated composition length's adoption, step 4: `prepared` had been taken on trust). `endBar` is where
// the render ends, declared by whoever wrote its spec (audio.renderEnd): fixed, or the most it plays, a render stops
// there either way, so a form that runs past it is cut off before its ending. A live room declares none.
export function formFaults(plan,{endBar=null,phraseBars,policy=formNegotiationPolicy()}={}){
  const timeline=formTimeline(plan,{policy,phraseBars});
  if(!timeline)return ['it has no bar to begin at'];
  if(timeline.end===null)return ['it has no sections'];
  const faults=[],ending=timeline.end,limit=Number(endBar);
  if(timeline.declared!==null&&timeline.declared!==timeline.end)
    faults.push(`its ending (bar ${timeline.declared}) is not where its sections end (bar ${timeline.end})`);
  if(timeline.summarised!==null&&timeline.summarised!==timeline.end-timeline.start)
    faults.push(`its declared length (${timeline.summarised} bars) is not its sections' (${timeline.end-timeline.start})`);
  if(endBar!==null&&endBar!==undefined&&Number.isFinite(limit)&&ending>limit)
    faults.push(`it runs past the render's end (it ends at bar ${ending}, the render at bar ${limit})`);
  return faults;
}

// A form's author-authorized alternatives (the negotiated composition length's adoption, step 3): the same form a phrase
// shorter and a phrase longer, each complete with its own ending, so the ensemble weighs endings that finish the piece
// rather than bare numbers of bars (docs/COMPOSITION_DURATION.md §1).
// - Each changes the form at its end. The longer adds a phrase to its last section; the shorter takes one from the
//   latest section that has more than one.
// - The views that move a form's length wait until its ending is near (a FormBOT's stop lead: the performer's, the
//   returns' planner's), so a variant leaves what has been played as it was played.
// - Fitting every length afresh from the draw (fitSectionsToPhrases) had moved whichever section had the largest
//   remainder, often one long over. An extension late in the form then sent the ensemble back into a section it had
//   left, and the research asks that scheduled work stay immutable (MUSEBOTS_DYNAMIC_DURATION_RESEARCH.md §3).
// - Adopting the longer and then the shorter still returns the form as it was.
// `sections` is the form as it stands; without it, the form as drawn, `drawn`, fitted to `phrases`. No variant drops a
// section, and a longer form that would run past `endBar` (the most bars a render allows) is not offered. Each is named
// by where it ends, so one name is always one ending, whatever revision of its plan it came in.
export const MAX_FORM_VARIANTS=2;
const VARIANT_ID=/^[A-Za-z0-9_-]{1,32}$/;
export function formVariants({sections,drawn,phrases,phraseBars,appliesAt,endBar=null}={}){
  const start=Number(appliesAt?.bar),bars=Math.max(1,Number(phraseBars)||1);
  const form=Array.isArray(sections)&&sections.length?sections.map((section,index)=>({...section,id:section.id??index,phrases:Math.max(1,Math.round(Number(section.phrases)||1))}))
    :Array.isArray(drawn)&&drawn.length&&Math.floor(Number(phrases))>=1?fitSectionsToPhrases(drawn,Math.floor(Number(phrases))):[];
  if(!form.length||!Number.isFinite(start))return [];
  const count=form.reduce((sum,section)=>sum+section.phrases,0),limit=endBar===null||endBar===undefined?Infinity:Number(endBar),variants=[];
  const giving=form.findLastIndex(section=>section.phrases>1);
  for(const totalPhrases of [count-1,count+1]){
    const bar=start+totalPhrases*bars,longer=totalPhrases>count,changed=longer?form.length-1:giving;
    if(changed<0||!(bar<=limit))continue;
    variants.push(Object.freeze({id:`ends-${bar}`,totalPhrases,
      sections:form.map((section,index)=>index===changed?{...section,phrases:section.phrases+(longer?1:-1)}:{...section}),
      candidateEndpoint:{bar,phrase:(Number(appliesAt.phrase)||0)+totalPhrases,section:form.length}}));
  }
  return variants;
}

// A plan's variants as plans of their own: the plan with the variant's sections and ending in place of its own.
function variantPlans(plan){
  const variants=Array.isArray(plan?.payload?.variants)?plan.payload.variants.slice(0,MAX_FORM_VARIANTS):[];
  return variants.filter(variant=>VARIANT_ID.test(String(variant?.id??''))&&Array.isArray(variant.sections)).map(variant=>{
    const {variants:_,...payload}=plan.payload;
    return {...plan,payload:{...payload,sections:variant.sections,totalPhrases:variant.totalPhrases,
      candidateEndpoint:variant.candidateEndpoint,variant:variant.id}};
  });
}

// Every live form plan, and every variant its author offers, as a slate the duration selector can read. Given the
// room's bar and its count of beats at that bar's start, each endpoint is where the form ends on the room's clock
// (formEndpointBeats); without them, the form's length. `prepared` is what its compiled timeline says (formFaults), and
// where it is false, `unprepared` says why. A variant's id is its plan's with the variant's name (`plan#ends-36`), and
// every candidate carries the plan it belongs to (`planId`) and the bar it ends at (`endBar`).
export function formCandidates(plans,{beatsPerBar,bar,beats,endBar=null,phraseBars,policy=formNegotiationPolicy()}={}){
  const candidates=[],placed=Number.isFinite(Number(bar))&&Number.isFinite(Number(beats));
  for(const plan of plans){
    if(plan?.kind!=='form')continue;
    // A form that revises itself often is more disruptive to follow than one that settles, and the plan already counts
    // its own revisions.
    const disruption=clamp((Number(plan.revision)||1)-1,0,8)/8;
    for(const form of [plan,...variantPlans(plan)]){
      const endpointBeats=placed?formEndpointBeats(form,{bar,beats,beatsPerBar,phraseBars,policy})
        :formBeats(form,{beatsPerBar,phraseBars,policy});
      if(endpointBeats===null)continue;
      const variant=form.payload.variant??null,unprepared=formFaults(form,{endBar,phraseBars,policy});
      candidates.push({id:variant?`${plan.planId}#${variant}`:String(plan.planId),planId:String(plan.planId),variant,
        author:String(plan.author||''),endBar:formEndBar(form,{policy,phraseBars}),endpointBeats,
        prepared:!unprepared.length,...(unprepared.length?{unprepared}:{}),plan:form,disruption});
    }
  }
  return candidates.sort((left,right)=>byId(left.id,right.id));
}

// The responses the ensemble has already sent, read as preferences over that
// slate. A bot that answered `abstain`, or did not answer, contributes nothing:
// the enrolled denominator is the roster, so silence dilutes support instead of
// supplying it.
// Each responder's answers are reduced to its latest before anything is weighed: the answer to the plan's latest
// revision, and of those the answer's own latest revision. Two different answers at the same revisions: the more
// cautious (the lower rating, an abstention counting as none) stands. Reduced in arrival order, the answer that came
// last won, so two bots that received the same answers in different orders weighed different ones (the mathematical
// audit's I04); canonical sorting afterwards could not undo that.
export function formPreferences(responses,{policy=formNegotiationPolicy()}={}){
  const latest=new Map(),caution=response=>Number.isFinite(policy.ratings[response.disposition])?policy.ratings[response.disposition]:0;
  for(const response of responses){
    const bot=String(response?.responder||''),planId=String(response?.planId||'');
    if(!bot||!planId)continue;
    const key=`${bot}\u0000${planId}`,order=[Number(response.planRevision)||0,Number(response.revision)||0],held=latest.get(key);
    if(held){
      const [plan,own]=held.order;
      if(order[0]<plan||order[0]===plan&&order[1]<own)continue;
      if(order[0]===plan&&order[1]===own&&!(caution(response)<caution(held.response)))continue;
    }
    latest.set(key,{order,response});
  }
  // A response may rate the variants its plan offers too, by name, in the same six dispositions
  // (`payload.variants: {'ends-36': 'accept'}`). An unnamed variant has no rating: abstaining on it says nothing.
  const preferences=new Map();
  for(const {response} of latest.values()){
    const bot=String(response.responder),planId=String(response.planId),ratings={};
    const rating=policy.ratings[response.disposition];
    if(Number.isFinite(rating))ratings[planId]=rating;   // not for abstain, or a disposition we do not read
    const variants=response.payload?.variants;
    if(variants&&typeof variants==='object'&&!Array.isArray(variants))
      for(const [variant,disposition] of Object.entries(variants).slice(0,MAX_FORM_VARIANTS*4)){
        const value=policy.ratings[disposition];
        if(VARIANT_ID.test(variant)&&Number.isFinite(value))ratings[`${planId}#${variant}`]=value;
      }
    if(!Object.keys(ratings).length)continue;
    const held=preferences.get(bot)||{bot,ratings:{}};
    Object.assign(held.ratings,ratings);
    preferences.set(bot,held);
  }
  // Frozen in canonical order, so two FormBOTs that received the same responses
  // in different orders still evaluate identical inputs.
  return new Map([...preferences.entries()].sort((left,right)=>byId(left[0],right[0]))
    .map(([bot,value])=>[bot,Object.freeze({bot,ratings:Object.freeze(value.ratings)})]));
}

// A bot's ratings over the slate: what it said of each candidate, and of a variant it did not name, what it said of the
// variant's plan. A bot ready for a form is ready for the versions its author offers with it, so naming none leaves them
// all level with the plan, and only a bot that prefers one version moves the decision. (Read as no rating, a bot's
// readiness had counted for the form as it stood and for no other length.) `key` is the id a candidate had on the
// slate before the negotiation renamed it (an adopted variant, now its plan's own form, keeps the id it was accepted
// under).
export function slateRatings(preference,candidates){
  const given=preference?.ratings||{},ratings={};
  for(const candidate of candidates){
    const own=given[candidate.key??candidate.id],value=own??(candidate.variant?given[candidate.planId]:undefined);
    if(Number.isFinite(value))ratings[candidate.id]=value;
  }
  return ratings;
}

// The weight of each enrolled voice, whatever the ensemble's size:
// - the voices that stand for performers (a listener, heard announcing a performer's attacks) hold `performerShare` of
//   the whole between them;
// - the voices that plan the form's returns (`planners`: a bot heard publishing return plans) hold `thematicShare` of
//   what the performers leave;
// - every other voice weighs one.
// Null where there is neither kind of voice, or nobody else, to weigh against.
export function formWeights(participants,performers,{policy=formNegotiationPolicy(),planners=[]}={}){
  const heard=new Set(performers||[]),planning=new Set(planners||[]),voices=participants.filter(bot=>heard.has(bot)),
    themes=participants.filter(bot=>planning.has(bot)&&!heard.has(bot)),others=participants.length-voices.length-themes.length;
  const performerShare=voices.length?policy.performerShare:0,thematicShare=themes.length?(policy.thematicShare??0)*(1-performerShare):0;
  if(!(performerShare>0)&&!(thematicShare>0)||!others)return null;
  // The mass that makes each other voice weigh one.
  const whole=others/(1-performerShare-thematicShare);
  return Object.fromEntries([...voices.map(bot=>[bot,performerShare*whole/voices.length]),...themes.map(bot=>[bot,thematicShare*whole/themes.length])]);
}

// How a performer's voice answers a form, once its ending is near: within `window` phrases of it (a FormBOT's stop
// lead, from where it proposes to stop until it commits), while the ending can still move. Heard earlier, playing says
// nothing about playing on. A performer still playing wants the piece to go on: not this ending yet (defer), a longer
// version accepted, a shorter one declined. A performer who has stopped (the listener's judgement: a phrase with
// nothing heard) wants it to end sooner: this ending played differently (transform), a shorter version accepted, a
// longer declined. Far from the ending, or never heard, no view (null).
export function performerFormAnswer(plan,{bar,heard=false,playing=false,stopped=false,window=2,phraseBars:clockPhrase,policy=formNegotiationPolicy()}={}){
  const ending=formEndBar(plan,{policy,phraseBars:clockPhrase}),now=Number(bar),phraseBars=planPhraseBars(plan,policy,clockPhrase);
  if(!heard||!Number.isFinite(ending)||!Number.isFinite(now)||ending-now>window*phraseBars||ending<=now)return null;
  if(!playing&&!stopped)return null;
  const variants={};
  for(const variant of Array.isArray(plan.payload?.variants)?plan.payload.variants:[]){
    const at=Number(variant?.candidateEndpoint?.bar);
    if(!VARIANT_ID.test(String(variant?.id??''))||!Number.isFinite(at)||at===ending)continue;
    variants[variant.id]=(playing?at>ending:at<ending)?'accept':'decline';
  }
  return playing
    ?{disposition:'defer',variants,rationale:'The performer is still playing: not this ending yet.'}
    :{disposition:'transform',variants,rationale:'The performer has stopped: end sooner.'};
}

// Who is enrolled in this decision: every bot that has said anything about any
// form plan on the slate, plus the authors of the plans themselves. Fixed by
// the caller when the round opens; a bot that arrives later is not retrofitted
// into a decision it was not part of.
export function formParticipants(responses,candidates){
  const enrolled=new Set();
  for(const response of responses)if(response?.responder)enrolled.add(String(response.responder));
  for(const candidate of candidates)if(candidate.author)enrolled.add(candidate.author);
  return [...enrolled].sort(byId);
}

// What a FormBOT publishes when the shared selector chose somebody else's form:
// its own plan, revised to a priority that loses. This is the only thing said
// out loud, and it is what lets a bot that never ran a selector agree with one
// that did.
export function concessionPayload(plan,winnerId,{policy=formNegotiationPolicy()}={}){
  return {payload:{...plan.payload,concededTo:String(winnerId)},
    options:{priority:policy.concessionPriority,
      rationale:`Yielding to ${winnerId}, which the shared form selector chose from the same slate.`}};
}

// A form's sections fitted to a number of phrases (the negotiated composition length's adoption, step 1: where the
// original length comes from). Where a render declares its length (audio.renderEnd), that length is the composition's,
// and a form drawn from its tables would end early or run past it; so its phrases are spread over its sections in their
// drawn proportions (largest remainders, each section at least one phrase), and where there are fewer phrases than
// sections, its first sections and its last, whose closure ends the piece, are kept. Sections are returned new; each
// keeps its role, tension and closure.
export function fitSectionsToPhrases(sections,phrases){
  if(!Array.isArray(sections)||!sections.length)return [];
  const count=Math.max(1,Math.floor(Number(phrases)||0));
  const kept=count>=sections.length?sections:[...sections.slice(0,count-1),sections.at(-1)];
  const drawn=kept.map(section=>Math.max(1,Number(section.phrases)||1)),total=drawn.reduce((sum,value)=>sum+value,0);
  // Each section its share of the phrases, rounded down but never below one; then the phrases left over to the largest
  // remainders, or taken back from the longest sections where the ones made up too many. A remainder is what a section
  // is still owed, its share less what it was given: a section lifted to its one phrase is owed nothing more (measured
  // from its share alone, the closing section of 2+3+2+1 fitted to seven phrases took a second phrase, where it had
  // been drawn with one).
  const shares=drawn.map(value=>value/total*count),given=shares.map(share=>Math.max(1,Math.floor(share)));
  let left=count-given.reduce((sum,value)=>sum+value,0);
  const byRemainder=shares.map((share,index)=>({index,remainder:share-given[index]})).sort((a,b)=>b.remainder-a.remainder||a.index-b.index);
  for(const {index} of byRemainder){if(left<=0)break;given[index]++;left--}
  while(left<0){const longest=given.reduce((best,value,index)=>value>given[best]?index:best,0);if(given[longest]<=1)break;given[longest]--;left++}
  return kept.map((section,index)=>({...section,id:index,phrases:given[index]}));
}
