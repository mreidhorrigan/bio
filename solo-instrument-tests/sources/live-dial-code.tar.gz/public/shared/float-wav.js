// The bowed strings' driver's output read: a 32-bit float WAV (native/strings-model/musebots-strings.cpp), by the Mac's
// renders (render/node/physical-strings.mjs readFloatWav) and the studio page's (public/studio/engines/strings-run.js).
import {setting} from '../../registry/registry.js';

// (WAV's layout, RIFF's: a tag four letters, a size 32 bits; the file's head its tag, its size and WAVE's; a chunk's head
// its tag and its size; the fmt chunk's rate after its format and its channels, each 16 bits; the driver's samples 32-bit
// floats.)
const TAG='RIFF'.length,SIZE=Uint32Array.BYTES_PER_ELEMENT,HEAD=TAG+SIZE+'WAVE'.length,CHUNK=TAG+SIZE;
const RATE_AT=CHUNK+['format','channels'].length*Uint16Array.BYTES_PER_ELEMENT,SAMPLE=Float32Array.BYTES_PER_ELEMENT;
// (The engine's rate, where a file names none, and the full scale past which a sample is one the model could not compute:
// registry/method/strings.json `strings-probe`, native/strings-model/probe.py's the same.)
const RATE=setting('strings-probe','rate'),FULL_SCALE=setting('strings-probe','fullScale');

// A float WAV the driver wrote (its bytes) -> its samples.
export function floatWav(bytes,gain=1){
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),tag=at=>String.fromCharCode(...bytes.subarray(at,at+TAG));
  let offset=HEAD,rate=RATE,data=null;
  while(offset+CHUNK<=bytes.length){const id=tag(offset),size=view.getUint32(offset+TAG,true);if(id==='fmt ')rate=view.getUint32(offset+RATE_AT,true);if(id==='data'){data=offset+CHUNK;break}offset+=CHUNK+size+(size&1)}
  const frames=data==null?0:Math.floor(Math.min(view.getUint32(data-SIZE,true),bytes.length-data)/SAMPLE);
  // (A sample the model could not compute -- not finite, or past full scale -- silenced and counted: one such sample
  // poisons a mix's every return after it.)
  const samples=new Float32Array(frames);let broken=0,firstBroken=null;
  for(let i=0;i<frames;i++){const v=view.getFloat32(data+SAMPLE*i,true);if(Number.isFinite(v)&&Math.abs(v)<=FULL_SCALE)samples[i]=v*gain;else{samples[i]=0;broken++;firstBroken??=i}}
  return {samples,rate,broken,brokenAt:firstBroken==null?null:firstBroken/rate};
}
