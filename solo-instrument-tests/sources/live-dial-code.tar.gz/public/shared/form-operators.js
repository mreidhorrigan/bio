// Formal operators (the extreme-aesthetics report's §5.2, M4): what a formal move changes, what it keeps, and which part
// of the ensemble realizes it. No climax is mandated: a near-static section, an unresolved stop or a long decay can be
// an endpoint, and tight repetition, obvious returns and stark blocks stay available.
//
// These name what the bots already do where they do it: a section's casting (shared/casting/sections.js, by
// manage_clodbot) holds, builds, thins, switches and withholds; drone_clodbot reinterprets a held tone. They also say
// honestly which operators nothing realizes yet. A casting gesture is read as the operators it performs (castingOperators),
// so a section's plan can say which formal move it makes.

// ---- Choices ---------------------------------------------------------------------------------------------------------
// Each operator: what changes, what can remain invariant (§5.2's table), and who realizes it (null: nothing yet).
export const FORM_OPERATORS=Object.freeze({
  'surface-acceleration':Object.freeze({changes:'excitation rate and local density',keeps:'a slower accent cycle, a held pitch or the phrase length',
    realizedBy:null,note:'the engines exist (shared/kernel-stream.js; rate-contract.js withExcitation), no bot yet accelerates a surface'}),
  'gesture-to-field':Object.freeze({changes:'discrete attacks become a sustained texture',keeps:'kernel identity, spectral family, formal role',
    realizedBy:null,note:'a kernel stream may be realized as fused texture (its aggregate), not yet chosen by a bot'}),
  exposure:Object.freeze({changes:'masking or accompaniment withdraws',keeps:'a motive or pitch already present',
    realizedBy:'the casting: a reduction that leaves a lead or melody sounding'}),
  'structural-clarification':Object.freeze({changes:'a recognizable riff or grouping becomes easier to parse',keeps:'surface speed and loudness',
    realizedBy:'the form\'s returns (MemoryBot\'s themes brought back; the home group back where the home comes back)'}),
  'common-tone-reinterpretation':Object.freeze({changes:'the harmonic context under a held voice',keeps:'that voice\'s pitch and continuity',
    realizedBy:'drone_clodbot (a held tone kept under a chord that keeps it: E13)'}),
  'block-collision':Object.freeze({changes:'adjacent materials contrast sharply',keeps:'a shared duration budget or a long-range return plan',
    realizedBy:'the casting: a sudden switch of group, or the stage cleared at the join'}),
  withholding:Object.freeze({changes:'an expected arrival is delayed or weakened',keeps:'the memory of the expected object',
    realizedBy:'the casting: the beat out for the phrase before a sudden addition'}),
  plateau:Object.freeze({changes:'a field persists with bounded or negligible change',keeps:'texture, rate and pitch identities',
    realizedBy:'the casting: the group held'}),
  'terminal-contraction':Object.freeze({changes:'events or layers are removed toward closure',keeps:'a residual resonance or anchor',
    realizedBy:'the casting: a reduction in the form\'s last section'}),
  'compressed-miniature':Object.freeze({changes:'several formal functions occur in a short span',keeps:'local motive relationships and chosen cuts',
    realizedBy:null,note:'no form yet packs several functions into one short section'}),
});
export const FORM_OPERATOR_NAMES=Object.freeze(Object.keys(FORM_OPERATORS));
// The roles a casting treats as leading: a part left alone is exposed.
const LEADING=Object.freeze(['lead','melody','vocal']);

// The operators a casting gesture performs (shared/casting/sections.js: {kind, entries, exits} and its prepare), given
// what stays sounding (their layers or roles) and whether the section is the form's last. [names]
export function castingOperators({gesture,prepare=[],remaining=[],last=false}={}){
  const kind=gesture?.kind,out=[];
  if(kind==='hold')out.push('plateau');
  if(kind==='switch'||kind==='clear-then-introduce')out.push('block-collision');
  if(prepare.length)out.push('withholding');
  const reduced=kind==='thin'||kind==='sudden-reduction';
  if(reduced&&remaining.some(role=>LEADING.includes(role)))out.push('exposure');
  if(reduced&&last)out.push('terminal-contraction');
  return out;
}
