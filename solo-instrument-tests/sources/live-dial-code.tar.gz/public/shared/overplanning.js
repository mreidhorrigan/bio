import {FuturePlanningRuntime} from './future-planning.js';
import {FUTURE_LIMITS as LIMITS,actor,sameActor,checkOrigin,identifier,number,frozenJson,dataDigest,planReference,planKey,planAuthor,scope,knownFields} from './planning-data.js';
import {validateGuard,evaluateDecision} from './overplan-guards.js';
import {prioritizeRecoveryRecords} from './planning-recovery.js';

export function overplanReference(value) {return Object.freeze({author:identifier(value.author),authorIncarnation:identifier(value.authorIncarnation),
  overplanId:identifier(value.overplanId),revision:number(value.revision,'overplan revision',{min:1,integer:true}),occurrenceId:identifier(value.occurrenceId)});}
export const overplanKey=value=>JSON.stringify(Object.values(overplanReference(value)));
const decisionOccurrence=value=>JSON.stringify([value.author,value.authorIncarnation,value.occurrenceId]);
const equalData=(a,b)=>frozenJson(a).canonical===frozenJson(b).canonical;

export function validateOverplan(input) {
  const value=frozenJson(input).data;
  if(value.version!==1||value.guardVersion!==1)throw new Error('Unsupported overplan or guard version');
  knownFields(value,['version','guardVersion','author','authorIncarnation','overplanId','revision','occurrenceId','sessionId','epoch',
    'tempoId','tempoRevision','selector','delegated','startBeat','endBeat','prepareByBeat','windowStartBeat','windowEndBeat',
    'snapshotCloseBeat','selectionByBeat','commitByBeat','scope','inputs','branches','unknownOutcome','noMatchOutcome','unreadyOutcome','missingFinalOutcome'],'overplan');
  const reference=overplanReference(value),owner=planAuthor(reference),selector=actor(value.selector);
  if(!sameActor(owner,selector)&&value.delegated!==true)throw new Error('Overplan selector requires explicit delegation');
  const startBeat=number(value.startBeat,'decision target'),endBeat=number(value.endBeat,'decision end',{min:startBeat,max:startBeat+LIMITS.futureBeats});
  if(endBeat===startBeat)throw new Error('Empty decision interval');
  const prepareByBeat=number(value.prepareByBeat,'prepare deadline',{max:startBeat}),
    windowStartBeat=number(value.windowStartBeat,'observation window start',{min:prepareByBeat,max:startBeat}),
    windowEndBeat=number(value.windowEndBeat,'observation window end',{min:windowStartBeat,max:startBeat}),
    snapshotCloseBeat=number(value.snapshotCloseBeat,'snapshot close',{min:windowEndBeat,max:startBeat}),
    selectionByBeat=number(value.selectionByBeat,'selection deadline',{min:snapshotCloseBeat,max:startBeat}),
    commitByBeat=number(value.commitByBeat,'final acceptance',{min:selectionByBeat,max:startBeat});
  if(windowStartBeat===windowEndBeat||windowEndBeat===snapshotCloseBeat||snapshotCloseBeat===selectionByBeat)throw new Error('Input, delivery and selection windows must be nonempty');
  if(!Array.isArray(value.inputs)||!value.inputs.length||value.inputs.length>16)throw new Error('Overplans require 1–16 declared inputs');
  const inputs=value.inputs.map(input=>{
    knownFields(input,['name','publisher','type','units','maxAgeBeats','completeness','ordering'],'input');
    if(!['number','boolean','string'].includes(input.type)||input.completeness!=='watermark'||input.ordering!=='observed-beat-then-sequence')throw new Error('Unknown input semantics');
    return {name:identifier(input.name),publisher:actor(input.publisher),type:input.type,units:identifier(input.units),
      maxAgeBeats:number(input.maxAgeBeats,'input freshness',{max:LIMITS.futureBeats}),completeness:'watermark',ordering:'observed-beat-then-sequence'};
  });
  if(new Set(inputs.map(input=>input.name)).size!==inputs.length)throw new Error('Duplicate input name');
  if(!Array.isArray(value.branches)||value.branches.length<2||value.branches.length>LIMITS.branches)throw new Error('A flat overplan requires 2–4 alternatives');
  const branches=value.branches.map(branch=>{
    knownFields(branch,['id','priority','plan','guard'],'branch');
    return {id:identifier(branch.id),priority:number(branch.priority,'branch priority',{max:1024,integer:true}),
      plan:planReference(branch.plan),guard:validateGuard(branch.guard,inputs)};
  });
  if(branches.some(branch=>branch.id==='omit')||new Set(branches.map(branch=>branch.id)).size!==branches.length||
    new Set(branches.map(branch=>branch.priority)).size!==branches.length||new Set(branches.map(branch=>planKey(branch.plan))).size!==branches.length)throw new Error('Branches and precedence must be unambiguous');
  for(const field of ['unknownOutcome','noMatchOutcome'])if(value[field]!=='omit'&&!branches.some(branch=>branch.id===value[field]))throw new Error('Explicit unknown/no-match outcome required');
  if(value.unreadyOutcome!=='omit'||value.missingFinalOutcome!=='omit')throw new Error('Unsupported unresolved-execution policy');
  return frozenJson({...reference,version:1,guardVersion:1,sessionId:identifier(value.sessionId),epoch:identifier(value.epoch),tempoId:identifier(value.tempoId),
    tempoRevision:number(value.tempoRevision,'tempo revision',{min:1,integer:true}),selector,delegated:value.delegated===true,
    startBeat,endBeat,prepareByBeat,windowStartBeat,windowEndBeat,snapshotCloseBeat,selectionByBeat,commitByBeat,scope:scope(value.scope),inputs,branches,
    unknownOutcome:value.unknownOutcome,noMatchOutcome:value.noMatchOutcome,unreadyOutcome:'omit',missingFinalOutcome:'omit'}).data;
}

// Authoritative snapshots are sealed only at the named selector. Other
// recipients execute its immutable choice, never their private arrival order.
export class OverplanningRuntime extends FuturePlanningRuntime {
  constructor(options) {super(options);this.overplans=new Map();this.selections=new Map();this.pendingSelections=new Map();this.overplanBytes=0;}
  async receive(message,origin) {
    if(!['/broadcast/overplan','/broadcast/overplan/input','/broadcast/overplan/complete','/broadcast/overplan/selection','/broadcast/overplan/snapshot'].includes(message?.address))return super.receive(message,origin);
    try {
      const value=message.args?.[0],source=actor(origin||{id:message.source,incarnation:message.sourceIncarnation});
      if(message.address==='/broadcast/overplan')return this.ingestOverplan(value,source);
      if(message.address==='/broadcast/overplan/selection')return this.ingestSelection(value,source);
      if(message.address==='/broadcast/overplan/snapshot')return await this.ingestSnapshot(value,source);
      return this.ingestInput(value,source,{complete:message.address==='/broadcast/overplan/complete'});
    } catch(error){return this.reject(error,message.args?.[0]);}
  }
  async ingestPlan(value,origin,options) {const result=await super.ingestPlan(value,origin,options);this.replaySelections();return result;}
  ingestOverplan(input,origin) {
    const overplan=validateOverplan(input);checkOrigin(planAuthor(overplan),origin);
    if(!this.authorizeAuthor(planAuthor(overplan),overplan))throw new Error('Overplan owner is not authorized');
    const key=overplanKey(overplan),json=frozenJson(overplan),old=this.overplans.get(key);
    if(old){if(old.canonical!==json.canonical)throw new Error('Immutable overplan revision conflict');return {ok:true,duplicate:true,record:old};}
    const timeline=this.checkPlacement(overplan);
    if(this.overplans.size>=64||this.overplanBytes+json.bytes>LIMITS.totalRecordBytes)throw new Error('Overplan retention budget exhausted');
    const record={overplan,timeline,key,canonical:json.canonical,bytes:json.bytes,inputs:new Map(overplan.inputs.map(value=>[value.name,
      {events:new Map(),ids:new Map(),watermark:null,conflicts:[],invalid:false}])),eventCount:0,snapshot:null,sealing:null,selection:null,selecting:null,state:'received'};
    this.checkBranches(record,false);this.overplans.set(key,record);this.overplanBytes+=json.bytes;this.replaySelections();
    this.emit('overplan-received',{overplan:overplanReference(overplan)});return {ok:true,record};
  }
  checkBranches(record,required=true) {
    const over=record.overplan;
    for(const branch of over.branches) {
      const plan=this.records.get(planKey(branch.plan))?.plan;
      if(!plan){if(required)throw new Error('An alternative has not arrived');continue;}
      if(!plan.decision||!equalData(plan.decision,overplanReference(over))||
        !sameActor(planAuthor(plan),planAuthor(over))||!sameActor(plan.selector,over.selector)||
        !equalData(plan.scope,over.scope)||['sessionId','epoch','tempoId','tempoRevision','startBeat','endBeat','prepareByBeat','commitByBeat'].some(key=>plan[key]!==over[key]))
        throw new Error('Alternative does not grant this exact decision scope and target');
    }
    return true;
  }
  ingestInput(input,origin,{complete=false}={}) {
    const value=frozenJson(input,{bytes:4096}).data;
    if(value.version!==1)throw new Error('Unknown observation version');
    const record=this.overplans.get(overplanKey(value.overplan));if(!record)throw new Error('Unknown decision occurrence');
    const over=record.overplan,contract=over.inputs.find(input=>input.name===value.input);
    if(!contract)throw new Error('Undeclared observation input');
    checkOrigin(contract.publisher,origin);checkOrigin(actor(value.publisher),origin);
    if(!sameActor(over.selector,this.identity))return {ignored:true};
    const now=this.now(),receivedBeat=now===null?null:record.timeline.beatAtReference(now),state=record.inputs.get(contract.name);
    if(record.snapshot||record.sealing||receivedBeat===null||receivedBeat>=over.snapshotCloseBeat) {
      this.emit('late-input',{overplan:overplanReference(over),input:contract.name,receivedBeat});return {ok:false,reason:'snapshot-closed'};
    }
    if(!this.ready()){state.invalid=true;return {ok:false,reason:'selector-clock-not-ready'};}
    if(complete) {
      const throughBeat=number(value.throughBeat,'completeness watermark',{min:over.windowEndBeat,max:receivedBeat+.1}),
        maxSequence=number(value.maxSequence,'completeness sequence',{max:LIMITS.inputEvents,integer:true});
      const watermark={throughBeat,maxSequence};
      if(state.watermark&&!equalData(state.watermark.value,watermark)){state.invalid=true;return {ok:false,reason:'conflicting-watermark'};}
      state.watermark={value:watermark,receivedBeat};return {ok:true};
    }
    const observedBeat=number(value.observedBeat,'observation time',{min:over.windowStartBeat,max:Math.min(over.windowEndBeat,receivedBeat+.1)}),
      sequence=number(value.sequence,'observation sequence',{min:1,max:LIMITS.inputEvents,integer:true}),observationId=identifier(value.observationId);
    if(observedBeat>=over.windowEndBeat)throw new Error('Observation is outside its half-open window');
    if(value.units!==contract.units||typeof value.value!==contract.type||(contract.type==='number'&&!Number.isFinite(value.value))||
      (contract.type==='string'&&value.value.length>128)){state.invalid=true;throw new Error('Observation type/units mismatch');}
    const observation={observationId,sequence,observedBeat,value:value.value,units:value.units,publisher:origin};
    const canonical=frozenJson(observation).canonical,previous=state.events.get(sequence),previousId=state.ids.get(observationId);
    if((previous&&previous.canonical!==canonical)||(previousId!==undefined&&previousId!==sequence)) {
      if(state.conflicts.length<16)state.conflicts.push({sequence,observationId});return {ok:false,reason:'conflicting-observation'};
    }
    if(previous)return {ok:true,duplicate:true};
    if(record.eventCount>=LIMITS.inputEvents){state.invalid=true;throw new Error('Observation budget exhausted');}
    state.events.set(sequence,{observation,canonical,receivedBeat});state.ids.set(observationId,sequence);record.eventCount++;return {ok:true};
  }
  async seal(record) {
    if(record.snapshot)return record.snapshot;
    if(record.sealing)return record.sealing;
    const over=record.overplan,now=this.now();
    if(now===null||record.timeline.beatAtReference(now)<over.snapshotCloseBeat)throw new Error('The snapshot is not closed yet');
    const inputs=over.inputs.map(contract=>{
      const state=record.inputs.get(contract.name),events=[...state.events.values()].sort((a,b)=>
        a.observation.observedBeat-b.observation.observedBeat||a.observation.sequence-b.observation.sequence),watermark=state.watermark?.value;
      const complete=Boolean(watermark&&events.length===watermark.maxSequence&&
        Array.from({length:watermark.maxSequence},(_,i)=>i+1).every(sequence=>state.events.has(sequence)));
      const last=events.at(-1)?.observation;
      let reason=state.invalid?'invalid-input':state.conflicts.length?'conflicting-input':!complete?'incomplete-window':
        last&&over.windowEndBeat-last.observedBeat>contract.maxAgeBeats?'stale-input':null;
      return {name:contract.name,publisher:contract.publisher,units:contract.units,state:reason?'unknown':last?'known':'absent',reason,
        value:reason||!last?null:last.value,complete,watermark:state.watermark||null,conflicts:state.conflicts,
        observations:events.map(({observation,receivedBeat})=>({...observation,receivedBeat}))};
    });
    record.sealing=dataDigest({version:1,overplan:overplanReference(over),windowStartBeat:over.windowStartBeat,
      windowEndBeat:over.windowEndBeat,snapshotCloseBeat:over.snapshotCloseBeat,duplicatePolicy:'conflict-is-unknown',inputs},
      {bytes:LIMITS.recordBytes}).then(snapshot=>{record.snapshot=snapshot;record.state='sealed';return snapshot;});
    return record.sealing;
  }
  async select(reference) {
    const record=this.overplans.get(overplanKey(reference));if(!record)throw new Error('Unknown overplan');
    if(record.selection)return record.selection;if(record.selecting)return record.selecting;
    checkOrigin(record.overplan.selector,this.identity);
    record.selecting=(async()=>{
      const over=record.overplan,snapshot=await this.seal(record);
      if(!this.ready()||this.now()>record.timeline.referenceAtBeat(over.selectionByBeat))throw new Error('Selection missed its clock/deadline budget');
      this.checkBranches(record,false);
      const evaluated=evaluateDecision(over,snapshot.data);
      let branch=over.branches.find(branch=>branch.id===evaluated.outcome)||null,reason=evaluated.reason;
      if(branch&&(!this.records.has(planKey(branch.plan))||!this.allPrepared(this.records.get(planKey(branch.plan))))){branch=null;reason='unready-omit';}
      const selection=frozenJson({version:1,kind:'overplan-selection',overplan:overplanReference(over),selector:this.identity,
        branchId:branch?.id||null,plan:branch?.plan||null,snapshotDigest:snapshot.digest,startBeat:over.startBeat,
        membershipId:over.scope.membershipId,reason}).data;
      this.ingestSelection(selection,this.identity);this.send('/broadcast/overplan/selection',[selection]);return selection;
    })();
    try{return await record.selecting;}catch(error){record.state='degraded';this.emit('selection-failed',{overplan:overplanReference(record.overplan),reason:error.message});throw error;}
  }
  ingestSelection(input,origin) {
    const value=frozenJson(input).data;
    if(value.version!==1||value.kind!=='overplan-selection')throw new Error('Invalid final selection');
    const record=this.overplans.get(overplanKey(value.overplan));
    checkOrigin(actor(value.selector),origin);
    if(!record||(value.plan&&!this.records.has(planKey(value.plan)))) {
      const key=overplanKey(value.overplan),old=this.pendingSelections.get(key),canonical=frozenJson(value).canonical;
      if(old&&old.canonical!==canonical)throw new Error('Conflicting pending selection');
      if(!old&&this.pendingSelections.size>=64)throw new Error('Pending selection budget exhausted');
      number(value.startBeat,'selection target',{max:this.pendingBeatLimit(this.now())});
      this.pendingSelections.set(key,{value,origin,canonical});return {ok:false,reason:'selection-dependencies-missing'};
    }
    const over=record.overplan;checkOrigin(over.selector,origin);checkOrigin(actor(value.selector),origin);this.checkBranches(record,false);
    if(typeof value.snapshotDigest!=='string'||!/^[a-f0-9]{64}$/.test(value.snapshotDigest)||value.startBeat!==over.startBeat||value.membershipId!==over.scope.membershipId)throw new Error('Final selection target/snapshot mismatch');
    const branch=over.branches.find(branch=>branch.id===value.branchId);
    if(value.branchId!==null&&(!branch||!equalData(value.plan,branch.plan)))throw new Error('Unknown selected alternative');
    if(branch&&!this.records.has(planKey(branch.plan)))throw new Error('Selected alternative has not arrived');
    if(value.branchId===null&&value.plan!==null)throw new Error('No-op selection cannot name executable material');
    const key=decisionOccurrence(over),canonical=frozenJson(value).canonical,old=this.selections.get(key);
    if(old){if(old.canonical!==canonical)throw new Error('Conflicting immutable final branch');return {ok:true,duplicate:true};}
    if(this.selections.size>=4096)throw new Error('Selection retention budget exhausted');
    if(branch)this.ingestFinal({version:2,kind:'plan-commit',plan:branch.plan,selector:over.selector,startBeat:over.startBeat,
      membershipId:over.scope.membershipId,selection:{overplan:overplanReference(over),snapshotDigest:value.snapshotDigest,branchId:branch.id}},origin,{selectionAuthorized:true});
    this.selections.set(key,{value,canonical,endReference:record.timeline.referenceAtBeat(over.endBeat)});
    record.selection=value;record.state=branch?'selected':'omitted';
    for(const alternative of over.branches)if(alternative.id!==branch?.id) {
      const plan=this.records.get(planKey(alternative.plan));if(plan)this.transition(plan,'cancelled',{reason:'unselected-alternative'});
    }
    this.emit('final-selection',{selection:value,executionBoundary:'decision-record'});return {ok:true};
  }
  replaySelections() {
    for(const [key,entry]of this.pendingSelections)if(this.overplans.has(key)&&(!entry.value.plan||this.records.has(planKey(entry.value.plan)))) {
      this.pendingSelections.delete(key);
      try{this.ingestSelection(entry.value,entry.origin);}catch(error){this.reject(error);}
    }
  }
  async ingestSnapshot(value,origin) {
    if(value.version!==1)throw new Error('Unknown decision snapshot version');
    const record=this.overplans.get(overplanKey(value.overplan));if(!record)throw new Error('Snapshot requires its overplan');
    checkOrigin(record.overplan.selector,origin);
    const snapshot=await dataDigest(value.snapshot.data);
    if(snapshot.digest!==value.snapshot.digest||!equalData(snapshot.data.overplan,overplanReference(record.overplan)))throw new Error('Snapshot identity/digest mismatch');
    if(record.snapshot&&record.snapshot.digest!==snapshot.digest)throw new Error('Conflicting sealed snapshot');
    if(record.selection&&record.selection.snapshotDigest!==snapshot.digest)throw new Error('Snapshot does not match final selection');
    record.snapshot=snapshot;return {ok:true};
  }
  recoverySummary(){return {...super.recoverySummary(),overplans:[...this.overplans.keys()]};}
  recoveryRecords(known) {
    const ordinary=super.recoveryRecords(known),records=[],now=this.now();
    for(const record of this.overplans.values()) {
      if(now===null||record.timeline.referenceAtBeat(record.overplan.endBeat)+16<now)continue;
      if(sameActor(planAuthor(record.overplan),this.identity)&&!known.overplans.includes(record.key))records.push({address:'/broadcast/overplan',value:record.overplan});
      if(sameActor(record.overplan.selector,this.identity)) {
        if(record.snapshot)records.push({address:'/broadcast/overplan/snapshot',value:{version:1,overplan:overplanReference(record.overplan),
          snapshot:{digest:record.snapshot.digest,data:record.snapshot.data}}});
        if(record.selection)records.push({address:'/broadcast/overplan/selection',value:record.selection});
      }
    }
    return prioritizeRecoveryRecords(this,[...ordinary,...records]);
  }
  pinnedTimelines(){return [...super.pinnedTimelines(),...[...this.overplans.values()].map(record=>record.timeline)];}
  checkpoint() {return frozenJson({...super.checkpoint(),overplans:[...this.overplans.values()].map(r=>({overplan:r.overplan,
    state:r.state,snapshot:r.snapshot?{digest:r.snapshot.digest,data:r.snapshot.data}:null,selection:r.selection})),selections:[...this.selections]},
    {bytes:40*1024*1024,items:3*1024*1024,depth:24}).data;}
  pendingDeadlines() {
    const deadlines=super.pendingDeadlines();if(this.stopped)return deadlines;
    for(const record of this.overplans.values()) {
      const over=record.overplan;
      if(record.selection||record.state==='missing-final'||!sameActor(over.selector,this.identity))continue;
      const phase=record.snapshot?'selection':'snapshot-close',atBeat=record.snapshot?over.selectionByBeat:over.snapshotCloseBeat;
      deadlines.push({kind:'overplan',reference:overplanReference(over),phase,atBeat,atReference:record.timeline.referenceAtBeat(atBeat)});
    }
    return deadlines;
  }
  publishOverplan(value) {const result=this.ingestOverplan(value,this.identity);this.send('/broadcast/overplan',[result.record.overplan]);return result.record.overplan;}
  advance() {
    const now=this.now();
    if(now!==null&&!this.stopped)for(const record of this.overplans.values()) {
      const over=record.overplan;
      if(!record.selection&&!record.selecting&&sameActor(over.selector,this.identity)&&now>=record.timeline.referenceAtBeat(over.snapshotCloseBeat))
        void this.select(over).catch(()=>{});
      if(!record.selection&&now>record.timeline.referenceAtBeat(over.commitByBeat)&&record.state!=='missing-final') {
        record.state='missing-final';this.emit('missing-final',{overplan:overplanReference(over),policy:'omit',degraded:true});
        for(const branch of over.branches){const plan=this.records.get(planKey(branch.plan));if(plan&&!plan.final)this.transition(plan,'expired',{reason:'missing-shared-selection'});}
      }
    }
    super.advance();
  }
  prune(now) {
    super.prune(now);
    for(const [key,record]of this.overplans)if(record.timeline.referenceAtBeat(record.overplan.endBeat)+16<now) {
      this.overplans.delete(key);this.overplanBytes-=record.bytes;
    }
    for(const [key,record]of this.selections)if(record.endReference+LIMITS.retentionSeconds<now)this.selections.delete(key);
    for(const [key,entry]of this.pendingSelections)if(this.pendingStartReference(entry.value)<now)this.pendingSelections.delete(key);
  }
  status() {return {...super.status(),overplanBytes:this.overplanBytes,decisions:[...this.overplans.values()].map(record=>({
    overplan:overplanReference(record.overplan),state:record.state,snapshotDigest:record.snapshot?.digest||null,selection:record.selection,
    alternatives:record.overplan.branches.map(branch=>({id:branch.id,plan:branch.plan,state:this.records.get(planKey(branch.plan))?.state||'missing'}))}))};}
}
