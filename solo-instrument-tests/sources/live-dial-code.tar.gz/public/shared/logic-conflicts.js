// Where the tendencies of different musical logics conflict outright. The user: "Detect, and fork bots at points where,
// the tendencies of different musical logics outright conflict with each other in ways that can't be reconciled. I don't
// think this will happen often but it is a possibility when applying systems from many parts of the world." And: "If
// you detect any such situations, document them (as they'll likely receive later revisiting as algorithms advance)."
//
// Most of what a bot weighs can be traded (a parallel against a leap, a dissonance against a resolution), and a cost
// function trades it. A conflict here is one that cannot be traded without giving up what one of the logics is: the note
// one requires is the note the other excludes, and a compromise between them is neither. A bot meeting one follows the
// logic its default gives (`resolution`), records each meeting (ConflictLog), and, where they recur, asks for a fork
// (/agent/fork: a sibling of itself that follows the other logic), so that both are heard, as heterophony and
// polystylism let two musical logics sound at once. A fork does not fork again.
//
// Each conflict is documented here and in research/kalman-integration.md ("Conflicts between musical logics"), to be
// revisited as the algorithms advance.
export const LOGIC_CONFLICTS=Object.freeze({
  'maqam-inflection-outside-pool':Object.freeze({
    logics:['the harmonic object (a pool is its notes)','maqam practice (its notes inflected by direction)'],
    found:'24 September 2026: a Hindemith line over a pool of maqam rast (C D E half-flat F G A B half-flat) came down through B flat, as rast does descending, a note the pool does not hold (test/harmonic-objects.test.mjs).',
    description:'A pool that lists a maqam\'s notes may mean the maqam, whose practice inflects some of them by direction (rast\'s B half-flat is B flat descending; nahawand\'s B, B flat), or exactly those notes. Played one way it adds a note the harmony was not given; played the other, it is not the maqam as musicians play it.',
    resolution:'the object: the bot keeps to the pool; the fork plays the maqam\'s inflections.',
    fork:{maqamInflections:true},
  }),
  'quarter-tone-against-equal':Object.freeze({
    logics:['a quarter-tone or just line (its own tuning)','an equal-tempered harmony sounding with it'],
    found:'documented with the detection, 24 September 2026; not yet met in a test.',
    description:'A note between the keys sounding against a band\'s equal-tempered note within a quarter tone of it (a neutral third against a major or minor one): neither tuning can move without ceasing to be itself, and the two beat.',
    resolution:'detected and recorded; not forked (the fork would be the band\'s, not one bot\'s).',
    fork:null,
  }),
});

// A bot's record of the conflicts it meets: each meeting with its tick, bar and phrase and details; `recurring` once a
// conflict has been met `times` times within `phrases` phrases, and a fork asked for once.
export class ConflictLog {
  constructor({times=3,phrases=2}={}){this.times=times;this.phrases=phrases;this.met=[];this.forked=new Set;}
  record(id,{clock={},details={}}={}){
    if(!LOGIC_CONFLICTS[id])throw new TypeError(`Unknown conflict between musical logics: ${id}`);
    const entry={id,tick:clock.tick??null,bar:clock.bar??null,phrase:clock.phrase??null,details};
    this.met.push(entry);if(this.met.length>256)this.met.shift();
    return entry;
  }
  recurring(id,clock={}){
    const phrase=clock.phrase??0,within=this.met.filter(entry=>entry.id===id&&(entry.phrase??0)>phrase-this.phrases);
    return within.length>=this.times;
  }
  // Whether to ask for a fork now: recurring, one the registry says to fork, and not asked for already.
  forkDue(id,clock={}){
    if(this.forked.has(id)||!LOGIC_CONFLICTS[id]?.fork||!this.recurring(id,clock))return false;
    this.forked.add(id);return true;
  }
  counts(){const out={};for(const entry of this.met)out[entry.id]=(out[entry.id]??0)+1;return out;}
}
export const FORK_ADDRESS='/agent/fork';
// The settings a fork may be given by a host (a fork request's, a render spec's): the keys the registered conflicts'
// forks use, and forkOf, each a boolean, a finite number or a short string. Anything else is dropped, so that a request
// arriving over the network cannot set what a bot's author did not mean a fork to change.
export const FORK_SETTING_KEYS=Object.freeze([...new Set(['forkOf',...Object.values(LOGIC_CONFLICTS).flatMap(conflict=>Object.keys(conflict.fork??{}))])]);
export function forkSettings(value){
  if(!value||typeof value!=='object'||Array.isArray(value))return {};
  const out={};
  for(const key of FORK_SETTING_KEYS){
    const item=value[key];
    if(typeof item==='boolean'||typeof item==='number'&&Number.isFinite(item)||typeof item==='string'&&item.length<=64)out[key]=item;
  }
  return out;
}
