// The bridge between how people describe music and what the bots actually set.
//
// Somebody says *dark, spacious, restless* and something has to decide what `oddLimit` that
// is. This module is the only place that decision is made, so that PlexBOT, TuneBOT, the
// mixbot and a language model speaking through MCP cannot each interpret the same words
// differently and then disagree in the room.
//
// Nine axes, each 0..1, named in words curators already use. They are of two kinds and the
// difference is kept honestly, because one is measured and the other is asserted:
//
//   observed      attack, mechanism, tonality, wordless
//                 Anchored to 5,453 genres of Every Noise at Once. Ask for "dark ambient"
//                 and these four come from the corpus rather than from anyone's opinion.
//
//   compositional darkness, complexity, variety, continuity, space
//                 Not properties of a genre at all -- they are properties of a piece, and
//                 they are what PlexBOT and the desk actually control. Defined here.
//
// See research/aesthetic-parameter-bridge.md for where the corpus came from, how the last
// two observed axes were recovered from a colour column, and the traps in the parameters at
// the far end.
//
// Nothing here loads the genre corpus. `loadGenreLexicon` does, on demand, and only if
// somebody names a genre.

export const AESTHETIC_AXES = Object.freeze({
  // Observed, but only partly: measured from the FMA's spectral centroid for the genres in
  // the lexicon's `darknessMeasured`, and interpolated -- shrunk to the skill the validation
  // actually found -- for the rest. It is timbral brightness, which is what an EQ tilt moves,
  // and not the mood sense of the word: death metal reads bright here because of its cymbals
  // and distortion. The adjective "dark" still asserts the mood sense on top.
  darkness:   Object.freeze({low: 'bright',        high: 'dark',         origin: 'observed',
                             coverage: 'partial'}),
  attack:     Object.freeze({low: 'atmospheric',   high: 'spiky',        origin: 'observed'}),
  mechanism:  Object.freeze({low: 'organic',       high: 'mechanical',   origin: 'observed'}),
  tonality:   Object.freeze({low: 'noisy',         high: 'pitched',      origin: 'observed'}),
  wordless:   Object.freeze({low: 'word-forward',  high: 'instrumental', origin: 'observed'}),
  complexity: Object.freeze({low: 'plain',         high: 'intricate',    origin: 'compositional'}),
  variety:    Object.freeze({low: 'uniform',       high: 'varied',       origin: 'compositional'}),
  continuity: Object.freeze({low: 'restless',      high: 'steady',       origin: 'compositional'}),
  space:      Object.freeze({low: 'dry',           high: 'spacious',     origin: 'compositional'}),
});
export const AXIS_NAMES = Object.freeze(Object.keys(AESTHETIC_AXES));
export const OBSERVED_AXES = Object.freeze(
  AXIS_NAMES.filter(axis => AESTHETIC_AXES[axis].origin === 'observed'));

// The order the lexicon stores its values in. Always read from the file rather than assumed,
// because the two have already disagreed once: darkness was added as a fifth column while
// OBSERVED_AXES sorts it first, and indexing by the constant would have written every genre's
// darkness into its attack.
const corpusAxes = lexicon => (Array.isArray(lexicon?.axes) && lexicon.axes.length
  ? lexicon.axes.filter(axis => axis in AESTHETIC_AXES)
  : ['attack', 'mechanism', 'tonality', 'wordless']);

const clamp01 = value => Math.max(0, Math.min(1, Number(value)));
const round3 = value => Math.round(value * 1000) / 1000;

// Everything sits at the middle until something moves it. A neutral vector must be a real
// position rather than an absence, or "unspecified" and "exactly average" behave differently
// and every projection needs a null check.
export const NEUTRAL = Object.freeze(Object.fromEntries(AXIS_NAMES.map(axis => [axis, 0.5])));

export function aesthetic(partial = {}) {
  const vector = {...NEUTRAL};
  for (const [axis, value] of Object.entries(partial)) {
    if (!(axis in AESTHETIC_AXES) || !Number.isFinite(Number(value))) continue;
    vector[axis] = round3(clamp01(value));
  }
  return Object.freeze(vector);
}

export function blendAesthetic(left, right, weight = 0.5) {
  const mix = clamp01(weight), first = aesthetic(left), second = aesthetic(right);
  return aesthetic(Object.fromEntries(
    AXIS_NAMES.map(axis => [axis, first[axis] * (1 - mix) + second[axis] * mix])));
}

// How far apart two characters are, 0..1. Used to decide whether a requested change is worth
// acting on at all -- a character that has barely moved should not restage the mix.
export function aestheticDistance(left, right) {
  const first = aesthetic(left), second = aesthetic(right);
  const total = AXIS_NAMES.reduce((sum, axis) => sum + (first[axis] - second[axis]) ** 2, 0);
  return round3(Math.sqrt(total / AXIS_NAMES.length));
}

// ---------------------------------------------------------------- words ----
// The curatorial vocabulary. There is no standard taxonomy for this -- the absence of one is
// a known problem in professional curation -- so these are the words curators and artists
// actually write, mapped to the positions they imply. A word may speak to more than one axis:
// "cavernous" is spacious *and* atmospheric, and pretending otherwise would lose half of what
// was said.
export const AESTHETIC_WORDS = Object.freeze({
  // darkness
  dark: {darkness: 0.85}, darker: {darkness: 0.8}, murky: {darkness: 0.85, tonality: 0.35},
  black: {darkness: 0.95}, gloomy: {darkness: 0.8}, shadowy: {darkness: 0.8},
  sombre: {darkness: 0.8}, somber: {darkness: 0.8}, brooding: {darkness: 0.85, continuity: 0.7},
  nocturnal: {darkness: 0.8}, doomy: {darkness: 0.9, attack: 0.2},
  bright: {darkness: 0.15}, light: {darkness: 0.2}, airy: {darkness: 0.2, space: 0.7},
  sunny: {darkness: 0.1}, radiant: {darkness: 0.1}, luminous: {darkness: 0.15},
  crystalline: {darkness: 0.2, tonality: 0.9}, glassy: {darkness: 0.25, tonality: 0.85},
  warm: {darkness: 0.6, mechanism: 0.3}, cold: {darkness: 0.6, mechanism: 0.8},
  // attack
  spiky: {attack: 0.9}, punchy: {attack: 0.85}, bouncy: {attack: 0.85},
  percussive: {attack: 0.9}, jagged: {attack: 0.85, complexity: 0.7},
  driving: {attack: 0.8, continuity: 0.75}, kinetic: {attack: 0.85},
  atmospheric: {attack: 0.15, space: 0.75}, ambient: {attack: 0.15, space: 0.8, continuity: 0.8},
  dense: {attack: 0.2}, drifting: {attack: 0.1, continuity: 0.75},
  hazy: {attack: 0.2, darkness: 0.6}, washy: {attack: 0.15, space: 0.85},
  smooth: {attack: 0.25}, flowing: {attack: 0.25, continuity: 0.8},
  // mechanism
  organic: {mechanism: 0.15}, acoustic: {mechanism: 0.1}, natural: {mechanism: 0.15},
  human: {mechanism: 0.15}, handmade: {mechanism: 0.1}, breathing: {mechanism: 0.2},
  mechanical: {mechanism: 0.85}, electronic: {mechanism: 0.85}, synthetic: {mechanism: 0.9},
  digital: {mechanism: 0.85}, robotic: {mechanism: 0.95, continuity: 0.85},
  industrial: {mechanism: 0.85, darkness: 0.75, tonality: 0.3},
  // tonality
  noisy: {tonality: 0.15}, gritty: {tonality: 0.25}, harsh: {tonality: 0.15, darkness: 0.7},
  distorted: {tonality: 0.2}, abrasive: {tonality: 0.1, darkness: 0.7},
  crunchy: {tonality: 0.3}, dirty: {tonality: 0.25},
  tonal: {tonality: 0.85}, melodic: {tonality: 0.9}, consonant: {tonality: 0.9},
  harmonic: {tonality: 0.85}, pure: {tonality: 0.9}, clean: {tonality: 0.8},
  // wordless
  instrumental: {wordless: 0.9}, wordless: {wordless: 0.95},
  vocal: {wordless: 0.1}, spoken: {wordless: 0.05}, lyrical: {wordless: 0.15, tonality: 0.8},
  // complexity
  complex: {complexity: 0.85}, intricate: {complexity: 0.85}, knotty: {complexity: 0.9},
  gnarly: {complexity: 0.85, tonality: 0.35},
  elaborate: {complexity: 0.8}, ornate: {complexity: 0.85}, angular: {complexity: 0.8, attack: 0.7},
  simple: {complexity: 0.15}, plain: {complexity: 0.15}, minimal: {complexity: 0.1, variety: 0.2},
  minimalist: {complexity: 0.1, variety: 0.2}, repetitive: {variety: 0.1, continuity: 0.9},
  austere: {complexity: 0.2, darkness: 0.6}, restrained: {attack: 0.3, complexity: 0.3},
  spare: {complexity: 0.2, attack: 0.3}, direct: {complexity: 0.25}, stark: {complexity: 0.2},
  // variety and continuity -- two axes, not one. Variety is how much the piece differs from
  // itself between sections; continuity is how steady it is inside one. A piece can be both
  // very varied and very steady: it changes at the seams and not in between.
  varied: {variety: 0.85}, restless: {variety: 0.8, continuity: 0.15},
  shifting: {variety: 0.8, continuity: 0.3}, kaleidoscopic: {variety: 0.9, complexity: 0.75},
  episodic: {variety: 0.85, continuity: 0.7}, unpredictable: {variety: 0.85, continuity: 0.2},
  uniform: {variety: 0.15}, consistent: {variety: 0.2, continuity: 0.85},
  steady: {continuity: 0.9}, hypnotic: {continuity: 0.95, variety: 0.15},
  static: {continuity: 0.95, variety: 0.05}, insistent: {continuity: 0.85, attack: 0.7},
  meditative: {continuity: 0.9, variety: 0.15, attack: 0.2},
  // space
  spacious: {space: 0.85}, cavernous: {space: 0.95, attack: 0.2}, roomy: {space: 0.7},
  wet: {space: 0.85}, distant: {space: 0.85, darkness: 0.65}, vast: {space: 0.9},
  dry: {space: 0.1}, close: {space: 0.15}, intimate: {space: 0.15, darkness: 0.55},
  tight: {space: 0.2, attack: 0.7}, upfront: {space: 0.15, attack: 0.75},
  // compound moods that curators write as one word
  lush: {space: 0.8, tonality: 0.8, complexity: 0.65},
  bleak: {darkness: 0.9, tonality: 0.35, variety: 0.2},
  euphoric: {darkness: 0.2, attack: 0.8, mechanism: 0.75},
  nostalgic: {darkness: 0.6, mechanism: 0.25, tonality: 0.8},
  reflective: {darkness: 0.6, attack: 0.25, continuity: 0.75},
  aggressive: {attack: 0.9, tonality: 0.3, darkness: 0.75},
  playful: {attack: 0.8, darkness: 0.25, variety: 0.75},
  serene: {darkness: 0.3, attack: 0.15, continuity: 0.85, tonality: 0.85},
  chaotic: {variety: 0.9, continuity: 0.1, complexity: 0.85, tonality: 0.35},
  // Words a real model actually reached for that this lexicon did not have. A 0.5B model
  // asked for a lullaby answered "soft, soothing, gentle, dreamy, calming" and only two of
  // those meant anything here, so the brief arrived as neutral -- the vocabulary gap was
  // the failure, not the parsing. Collected from watching it miss.
  soft: {attack: 0.2, darkness: 0.4, tonality: 0.75},
  soothing: {continuity: 0.85, attack: 0.15, tonality: 0.85, darkness: 0.35},
  gentle: {attack: 0.2, darkness: 0.35, complexity: 0.3},
  calming: {continuity: 0.85, attack: 0.15, darkness: 0.35},
  calm: {continuity: 0.85, attack: 0.2}, peaceful: {continuity: 0.85, darkness: 0.3},
  dreamy: {space: 0.8, attack: 0.2, darkness: 0.4}, mellow: {attack: 0.25, darkness: 0.5},
  tender: {darkness: 0.4, attack: 0.25}, fragile: {darkness: 0.5, attack: 0.2, space: 0.65},
  sleepy: {continuity: 0.9, attack: 0.1}, lush_pads: {space: 0.8},
  mournful: {darkness: 0.85, tonality: 0.8, continuity: 0.75},
  melancholy: {darkness: 0.75, tonality: 0.8}, wistful: {darkness: 0.6, tonality: 0.8},
  sad: {darkness: 0.75}, solemn: {darkness: 0.75, continuity: 0.8},
  sacred: {darkness: 0.55, space: 0.85, continuity: 0.8},
  ritual: {continuity: 0.85, darkness: 0.7, variety: 0.2},
  eerie: {darkness: 0.8, tonality: 0.4, space: 0.75}, uneasy: {darkness: 0.7, tonality: 0.45},
  tense: {darkness: 0.7, continuity: 0.35}, ominous: {darkness: 0.85, attack: 0.25},
  heavy: {darkness: 0.75, attack: 0.3}, massive: {space: 0.8, attack: 0.35},
  thick: {attack: 0.25}, sparse: {complexity: 0.2, attack: 0.35},
  busy: {complexity: 0.8, attack: 0.75}, frantic: {attack: 0.9, continuity: 0.1, variety: 0.8},
  urgent: {attack: 0.85, continuity: 0.4}, relentless: {continuity: 0.9, attack: 0.85},
  pounding: {attack: 0.9, mechanism: 0.7}, banging: {attack: 0.9, mechanism: 0.8},
  energetic: {attack: 0.85}, upbeat: {attack: 0.8, darkness: 0.25},
  epic: {space: 0.8, variety: 0.7, complexity: 0.7},
  triumphant: {darkness: 0.25, tonality: 0.85, attack: 0.7},
  joyful: {darkness: 0.15, tonality: 0.85}, happy: {darkness: 0.2, tonality: 0.85},
  cinematic: {space: 0.8, variety: 0.7}, hypnotic_pulse: {continuity: 0.95},
  raw: {tonality: 0.3, space: 0.2}, lo: {tonality: 0.4}, fuzzy: {tonality: 0.3},
  glitchy: {mechanism: 0.9, continuity: 0.2, tonality: 0.4},
  danceable: {attack: 0.85, mechanism: 0.75, continuity: 0.8},
  groovy: {attack: 0.8, continuity: 0.8}, funky: {attack: 0.85, continuity: 0.75},
  improvised: {variety: 0.8, continuity: 0.3}, composed: {variety: 0.5, continuity: 0.7},
});

const INTENSIFIERS = Object.freeze({
  very: 1.4, extremely: 1.7, really: 1.3, intensely: 1.6, deeply: 1.4, totally: 1.6,
  slightly: 0.45, somewhat: 0.55, a: 1, bit: 0.45, mildly: 0.5, faintly: 0.4, quite: 1.15,
});
const NEGATIONS = new Set(['not', 'no', 'less', 'without', 'never', 'un']);

// Words that must never stand for a family of genres. Twelve genre names contain "and", so
// without this the word "and" in "spacious and restless" matched twelve genres and dragged
// every observed axis toward their average -- an instruction quietly half-answered by its
// own conjunction. Any word here is skipped for family matching; an exact genre name that
// happens to be one of them still matches, because that is a genre and this is a guess.
const NOT_A_FAMILY = new Set(['and', 'or', 'but', 'the', 'a', 'an', 'of', 'in', 'on', 'for',
  'with', 'to', 'at', 'by', 'from', 'as', 'is', 'it', 'be', 'that', 'this', 'new', 'old',
  'more', 'most', 'like', 'very', 'all', 'one', 'two', 'up', 'out', 'off', 'own', 'my',
  'so', 'then', 'now', 'just', 'some', 'any', 'kind', 'sort', 'thing', 'things', 'bit',
  'music', 'sound', 'sounds', 'style', 'vibe', 'feel', 'feels', 'want', 'make', 'made',
  'something', 'please', 'should', 'would', 'could', 'can', 'set', 'give', 'keep']);

// Pull a target away from or toward the middle. An intensifier does not push past the ends,
// and a negation reflects the target through the middle -- "not dark" is bright, and "very
// not dark" is brighter still, which is what people mean even when they say it badly.
const applyForce = (target, strength, negated) => {
  const pointed = negated ? 1 - target : target;
  return clamp01(0.5 + (pointed - 0.5) * strength);
};

export function parseAesthetic(text, {genres = null, base = null} = {}) {
  // Hyphenated compounds are split as well as kept. A model wrote "Acoustic-folk, intimate,
  // minimalist" and the whole first term matched nothing -- neither an adjective nor a
  // genre -- while both of its halves would have matched. The joined form is tried first so
  // a genuine hyphenated genre name still wins.
  const raw = String(text ?? '').toLowerCase().match(/[a-z][a-z'-]*/g) || [];
  const words = [];
  for (const word of raw) {
    words.push(word);
    if (word.includes('-')) words.push(...word.split('-').filter(Boolean));
  }
  // Two buckets, because a measured coordinate and a spoken adjective are different kinds of
  // claim and averaging them loses the difference. "dark ambient" averaged to *less* dark
  // than "ambient" alone, because ambient's measured timbre is darker than the word's 0.85 --
  // absurd, and the reason the two are combined directionally below instead.
  const pulls = Object.fromEntries(AXIS_NAMES.map(axis => [axis, []]));
  const said = Object.fromEntries(AXIS_NAMES.map(axis => [axis, []]));
  const matched = [], unknownWords = [], matchedGenres = [];

  // A matched genre supplies the four observed axes from the corpus, and its *name* is then
  // read for the five the corpus cannot supply. "dark ambient" is atmospheric and
  // instrumental because Every Noise measured it, and dark because it says so -- without
  // this second step the phrase produced a flat 0 dB tilt, which is the one thing nobody
  // asking for dark ambient wants. The corpus keeps authority over the axes it measures;
  // the name is only consulted for the others.
  const axesInFile = corpusAxes(genres);
  const takeGenre = name => {
    matchedGenres.push(name);
    const values = genres.genres[name];
    axesInFile.forEach((axis, index) => pulls[axis].push(values[index] / 100));
    for (const part of name.split(/\s+/)) {
      const entry = AESTHETIC_WORDS[part];
      if (!entry) continue;
      for (const [axis, target] of Object.entries(entry))
        // Darkness is in the corpus now but only as timbre, so the mood sense a word carries
        // is still worth hearing: "dark ambient" is both measured and said.
        if (axis in said && (!axesInFile.includes(axis) || axis === 'darkness'))
          said[axis].push(target);
    }
  };

  // Genre names first, and longest first, so "dark ambient" is one genre rather than the two
  // adjectives "dark" and "ambient" -- which would land somewhere else entirely.
  let haystack = ` ${words.join(' ')} `;
  if (genres) {
    const names = Object.keys(genres.genres || {}).filter(name => name.includes(' '))
      .sort((left, right) => right.length - left.length);
    for (const name of names) {
      if (!haystack.includes(` ${name} `)) continue;
      haystack = haystack.replace(` ${name} `, ' ');
      takeGenre(name);
    }
  }
  const remaining = haystack.trim().split(/\s+/).filter(Boolean);

  // A word that is not an adjective and not a genre may still be a *family* of genres. The
  // corpus has no genre called "piano", but it has thirty containing the word, and their
  // centroid is a better answer than nothing -- it is, in fact, what the word means here.
  // Two members minimum, so a single oddly-named genre cannot stand for a whole word.
  const family = word => {
    if (!genres?.genres || word.length < 3 || NOT_A_FAMILY.has(word)) return null;
    if (!genres._families) {
      const index = new Map();
      for (const [name, values] of Object.entries(genres.genres))
        for (const part of name.split(/\s+/)) {
          if (!index.has(part)) index.set(part, []);
          index.get(part).push(values);
        }
      Object.defineProperty(genres, '_families', {value: index, enumerable: false});
    }
    const members = genres._families.get(word);
    if (!members || members.length < 3) return null;
    return {
      size: members.length,
      centroid: axesInFile.map((_, index) =>
        members.reduce((sum, values) => sum + values[index], 0) / members.length / 100),
    };
  };

  let strength = 1, negated = false;
  for (const word of remaining) {
    if (word in INTENSIFIERS) { strength *= INTENSIFIERS[word]; continue }
    if (NEGATIONS.has(word)) { negated = true; continue }
    // A word can be both a genre and an adjective -- "ambient", "industrial", "minimal",
    // "classical" all are -- and it is worth both readings. Taking only the adjective threw
    // away the measured coordinates, so `ambient` alone came back neutral on every axis the
    // corpus had actually measured for it. Take the genre, then fall through and take the
    // adjective too.
    if (genres?.genres?.[word]) takeGenre(word);
    const entry = AESTHETIC_WORDS[word];
    if (!entry) {
      const kin = family(word);
      if (kin) {
        matchedGenres.push(`${word} (${kin.size} genres)`);
        axesInFile.forEach((axis, index) => pulls[axis].push(kin.centroid[index]));
        strength = 1; negated = false;
        continue;
      }
      if (word.length > 2) unknownWords.push(word);
      continue;
    }
    matched.push(word);
    for (const [axis, target] of Object.entries(entry))
      if (axis in said) said[axis].push(applyForce(target, strength, negated));
    strength = 1; negated = false;
  }

  // An axis nobody mentioned keeps whatever it already was. Silence is not a request for the
  // middle; it is a request to leave that alone.
  const start = base ? aesthetic(base) : NEUTRAL;
  const mean = values => values.reduce((sum, value) => sum + value, 0) / values.length;
  const vector = {};
  for (const axis of AXIS_NAMES) {
    const measured = pulls[axis].length ? mean(pulls[axis]) : null;
    const spoken = said[axis].length ? mean(said[axis]) : null;
    if (measured === null && spoken === null) { vector[axis] = start[axis]; continue }
    if (spoken === null) { vector[axis] = measured; continue }
    if (measured === null) { vector[axis] = spoken; continue }
    // Both. The adjective is a floor in the direction it names, not an average: asking for
    // dark must never make something brighter than the corpus already found it.
    vector[axis] = spoken >= 0.5 ? Math.max(measured, spoken) : Math.min(measured, spoken);
  }

  return {
    vector: aesthetic(vector),
    matched, genres: matchedGenres, unknown: unknownWords,
    understood: matched.length + matchedGenres.length,
  };
}

// The words for a vector, which is how a bot explains itself and how an LM can check that it
// was understood before anything sounds.
export function describeAesthetic(vector) {
  const value = aesthetic(vector);
  const said = [];
  for (const axis of AXIS_NAMES) {
    const level = value[axis];
    if (level > 0.62) said.push(AESTHETIC_AXES[axis].high);
    else if (level < 0.38) said.push(AESTHETIC_AXES[axis].low);
  }
  return said.length ? said.join(', ') : 'even on every axis';
}

// --------------------------------------------------------------- genres ----
let lexiconPromise = null;
// On demand, once, and never at ensemble start: 165 KB of genre table is not something an
// ensemble should load in order to make a sound.
export function loadGenreLexicon({url = 'data/aesthetic-lexicon.json', fetchImpl = null} = {}) {
  if (!lexiconPromise) {
    const get = fetchImpl || (typeof fetch === 'function' ? fetch : null);
    if (!get) return Promise.resolve(null);
    lexiconPromise = Promise.resolve(get(url))
      .then(response => (response.ok ? response.json() : null))
      .catch(() => null);
  }
  return lexiconPromise;
}
export function setGenreLexicon(lexicon) { lexiconPromise = Promise.resolve(lexicon) }

// Exact name, then the longest genre whose name is contained in the request, then the genre
// sharing the most words with it. "norwegian black metal" finds itself; "some kind of black
// metal thing" finds black metal.
export function genreAesthetic(name, lexicon) {
  if (!lexicon?.genres) return null;
  const wanted = String(name ?? '').toLowerCase().trim();
  if (!wanted) return null;
  const axesInFile = corpusAxes(lexicon);
  const build = (key, how) => {
    const values = lexicon.genres[key];
    const vector = {};
    axesInFile.forEach((axis, index) => { vector[axis] = values[index] / 100 });
    return {genre: key, match: how,
      darknessMeasured: (lexicon.darknessMeasured || []).includes(key),
      vector: aesthetic(vector)};
  };
  if (lexicon.genres[wanted]) return build(wanted, 'exact');

  let contained = null;
  for (const key of Object.keys(lexicon.genres))
    if (wanted.includes(key) && (!contained || key.length > contained.length)) contained = key;
  if (contained) return build(contained, 'contained');

  // Partial matching has to be stingy or it answers everything. "nothing like a genre at
  // all zzz" matched `a cappella`, on the strength of the word "a" being half of that
  // genre's name -- a confident wrong answer, which is worse than none. So: function words
  // never count, at least one substantial word has to match, and the bar is higher.
  const words = new Set(wanted.split(/\s+/).filter(word => !NOT_A_FAMILY.has(word)));
  let best = null, bestScore = 0;
  for (const key of Object.keys(lexicon.genres)) {
    const parts = key.split(/\s+/).filter(part => !NOT_A_FAMILY.has(part));
    if (!parts.length) continue;
    const hits = parts.filter(part => words.has(part));
    if (!hits.some(part => part.length >= 4)) continue;
    const score = hits.length / parts.length;
    if (score > bestScore) { bestScore = score; best = key }
  }
  return bestScore >= 0.6 ? build(best, 'partial') : null;
}

// ----------------------------------------------------------- projections ---
// Each consumer gets one stated projection. Two bots handed the same character must not be
// able to disagree about what it meant, which is what happens the moment a bot reads the
// axes for itself.

const lerp = (from, to, at) => from + (to - from) * clamp01(at);

// The mixbot. Returns overrides for LiveDesk's own rules plus actions in the shape
// public/shared/lm-bridge.js already emits, so this plugs into the existing message path
// rather than inventing a second one.
export function mixAesthetic(vector) {
  const value = aesthetic(vector);
  const {darkness, attack, mechanism, tonality, complexity, variety, continuity, space} = value;

  // Loudness. Mechanical and spiky music is mastered louder; atmospheric and organic music
  // is not, and forcing it there is what makes an ambient mix sound like a pop one.
  const targetLufs = Math.round(lerp(-24, -13, attack * 0.55 + mechanism * 0.45) * 10) / 10;
  // Crest. Spiky material needs room for its transients; atmospheric material has none to
  // keep. These are floors the desk protects, not levels it imposes.
  const psrDb = Math.round(lerp(8, 16, attack));
  const plrDb = Math.round(lerp(8, 15, attack * 0.6 + variety * 0.4));
  // Loudness range follows variety directly: a piece that changes between sections should be
  // allowed to change in level between them.
  const rangeLu = Math.round(lerp(5, 14, variety * 0.7 + (1 - continuity) * 0.3));
  // How willing the desk is to move at all. A steady piece wants a desk that leaves things
  // alone -- a wide dead band and small moves -- and a restless one wants a desk that keeps up.
  const deadBandCeilingDb = Math.round(lerp(1.5, 6, continuity) * 10) / 10;

  // Spectral tilt is what darkness *is* on a mix: take the top and add weight underneath, or
  // the reverse. ±9 dB is the range the existing characters already use.
  const tiltDb = Math.round((0.5 - darkness) * 18);
  const actions = [
    ['eq', {band: 'high', gainDb: tiltDb, hz: 5000}],
    ['eq', {band: 'low', gainDb: Math.round(-tiltDb * 0.5), hz: 150}],
    ['send', {bus: 'reverb', value: Math.round(lerp(0.03, 0.95, space) * 100) / 100}],
    ['width', {value: Math.round(lerp(0.6, 1.9, space * 0.7 + variety * 0.3) * 100) / 100}],
    ['target', {lufs: targetLufs}],
  ];
  // Noise-based material collides with itself in the middle, where a clean mix needs a cut
  // and a pitched one does not.
  if (tonality < 0.4) actions.push(['eq', {band: 'mid', gainDb: -4, hz: 1200, q: 1.1}]);
  // Intricate music needs the parts kept apart more than it needs to be loud.
  if (complexity > 0.65) actions.push(['duck', {depthDb: Math.round(lerp(2, 6, complexity)), holdBeats: 1}]);
  // Nonlinear. Grit is the thing `tonality` is low *for*: noisy, harsh, industrial and
  // abrasive all read as noise-based, and none of them are reachable with EQ and reverb
  // alone. Below the midpoint it comes in gradually; above it there is no drive at all,
  // because a clean pitched mix that has been quietly saturated is just a worse clean mix.
  const drive = tonality < 0.5 ? Math.round(lerp(0.55, 0, tonality * 2) * 100) / 100 : 0;
  if (drive > 0.02) {
    actions.push(['send', {bus: 'drive', value: drive}]);
    // Darker material wants the harmonics kept down where they do not turn into fizz.
    actions.push(['driveTone', {hz: Math.round(lerp(2600, 7200, 1 - darkness))}]);
  }
  // Modulation. Movement, which is what lush and dreamy mean and what a static reverb cannot
  // give: spacious material gets the delay moving, and a restless piece gets it moving faster.
  const chorus = Math.round(lerp(0, 0.5, Math.max(0, space - 0.45) * 2) * 100) / 100;
  if (chorus > 0.02) {
    actions.push(['send', {bus: 'chorus', value: chorus}]);
    actions.push(['chorusRate', {hz: Math.round(lerp(0.25, 2.2, 1 - continuity) * 100) / 100}]);
  }

  // Compression staging: the second stage, on the bus, after each channel has had its own.
  // It is asked for headroom rather than loudness -- the ratio rises with how spiky and how
  // loud the character wants to be, because that is when the tallest transient is what stops
  // the mix getting there, and the makeup spends exactly the headroom it bought. A character
  // that is neither loud nor spiky leaves it at ratio 1, which is a pass-through.
  const push = clamp01(attack * 0.6 + mechanism * 0.4);
  const busCompression = push < 0.45 ? {ratio: 1, thresholdDb: 0, makeupDb: 0}
    : {
      thresholdDb: Math.round(lerp(-6, -18, push)),
      ratio: Math.round(lerp(1.5, 4, push) * 10) / 10,
      knee: 6,
      attack: Math.round(lerp(0.02, 0.003, attack) * 1000) / 1000,
      release: Math.round(lerp(0.4, 0.12, attack) * 100) / 100,
      makeupDb: Math.round(lerp(0, 4, push) * 10) / 10,
    };

  return {
    rules: {targetLufs, psrDb, plrDb, rangeLu, deadBandCeilingDb},
    busCompression,
    actions,
    // The compositional half, in the units lm-bridge already speaks.
    density: {h: round3(lerp(0.15, 0.9, attack)), v: round3(lerp(0.15, 0.9, complexity))},
    planKind: complexity > 0.6 ? 'texture' : variety > 0.65 ? 'form' : 'dynamics',
    describe: describeAesthetic(value),
  };
}

// PlexBOT: metre and form. Its own `complexity(numerator)` already scores a time signature,
// so the aesthetic axis becomes the target that scoring aims at.
// A section of the orchestra (its string, wind and brass sections: string-section.js formationPlan), playing in a style:
// what a character asks of how its players play together. Each texture's weight a factor (never zero: a character
// narrows the field, it does not close it), each texture's leaning on the axes its own: the masses toward the intricate,
// the organic and the atmospheric, a chord toward the pitched and the mechanical, glissandi toward the noisy and the
// restless, pizzicati toward the spiky. The pulse its chords and pizzicati keep (0 held and free, 1 on every subdivision
// of the meter: section-voices.js) as the music is mechanical, a little more as it is spiky; how much of each pulsed
// chord sounds (its gate: legato at 1) as it is atmospheric; its clouds as dense as it is intricate. Ours.
const SECTION_LEANINGS = Object.freeze({
  line:           Object.freeze({tonality: 1, attack: -0.3, space: -0.2}),
  chord:          Object.freeze({tonality: 1, mechanism: 0.8, complexity: -0.6}),
  figuration:     Object.freeze({tonality: 1, mechanism: 0.7, complexity: 0.3, attack: 0.3}),
  micropolyphony: Object.freeze({complexity: 1.2, mechanism: -0.8, attack: -0.5}),
  cluster:        Object.freeze({tonality: -1, complexity: 0.5, attack: -0.3}),
  glissandi:      Object.freeze({tonality: -0.8, mechanism: -1, continuity: -0.4}),
  pizzicati:      Object.freeze({attack: 1.2, space: 0.3, mechanism: 0.3}),
});
export function sectionAesthetic(vector) {
  const value = aesthetic(vector);
  const weights = Object.fromEntries(Object.entries(SECTION_LEANINGS).map(([texture, leaning]) => [texture,
    Math.round(Math.exp(0.9 * Object.entries(leaning).reduce((sum, [axis, k]) => sum + k * 2 * (value[axis] - 0.5), 0)) * 1000) / 1000]));
  const pulse = clamp01(0.1 + 0.75 * value.mechanism + 0.15 * value.attack), gate = clamp01(0.3 + 0.7 * (1 - value.attack));
  const round = x => Math.round(x * 1000) / 1000;
  return Object.freeze({weights: Object.freeze(weights),
    pulse: Object.freeze([round(clamp01(pulse - 0.15)), round(clamp01(pulse + 0.15))]),
    gate: Object.freeze([round(Math.max(0.25, gate - 0.1)), round(Math.min(1, gate + 0.1))]),
    density: round(lerp(0.6, 1.6, value.complexity))});
}

export function formAesthetic(vector) {
  const value = aesthetic(vector);
  const {complexity, variety, continuity, attack} = value;
  return {
    // What complexity of numerator to aim for, on PlexBOT's own 0..1 scale.
    targetComplexity: round3(complexity),
    // How far a new numerator may travel from the last one. A uniform piece stays home.
    numeratorSpread: round3(lerp(0.1, 1, variety)),
    // How long a section lasts before the form moves on. Steady pieces hold.
    phrasesPerSection: Math.max(1, Math.round(lerp(1, 8, continuity))),
    // The chance that a section boundary changes anything at all.
    changeProbability: round3(lerp(0.05, 0.85, variety)),
    // Whether the downbeat is protected. Spiky music wants the one; drifting music does not.
    preserveDownbeat: attack > 0.55,
  };
}

// TuneBOT. **Read the directions.** `purity`, `complexity` and `primeSoftness` are *cost
// weights* in `public/shared/tuning.js`:
//
//     cost = purity·distance² + complexity·candidate.complexity + primeSoftness·log2(prime)
//
// and the tuner minimises it. So a *higher* weight yields a *simpler, closer* tuning. An
// aesthetic axis called complexity must therefore drive that weight downward. Getting this
// backwards produces a bridge that is confidently inverted, which is why the test asserts
// the sign rather than the value.
export function tuningAesthetic(vector) {
  const value = aesthetic(vector);
  const {complexity, tonality, mechanism, continuity, darkness} = value;
  return {
    // Mechanical music expects equal temperament; organic music tolerates the drift that
    // just intonation asks for. Higher purity holds closer to the nominal pitch.
    purity: round3(lerp(1.2, 6, mechanism)),
    // INVERTED on purpose: intricate wanted -> cheaper complex ratios -> lower weight.
    complexity: round3(lerp(0.26, 0.02, complexity)),
    // Also inverted, and pitched material additionally prefers the low primes.
    primeSoftness: round3(lerp(0.3, 0.02, complexity * 0.7 + (1 - tonality) * 0.3)),
    // Not inverted: this is a ceiling on the ratios allowed, so intricacy raises it.
    oddLimit: Math.round(lerp(9, 45, complexity)),
    // TuneBOT's own continuity: how much a tuning may move between chords.
    continuity: round3(lerp(0.35, 0.95, continuity)),
    // Dark readings sit the tuning a little lower against its reference.
    grounding: round3(lerp(0.02, 0.18, darkness)),
  };
}

// Everything at once, for a caller that has one character and several bots to brief.
export function projectAesthetic(vector) {
  const value = aesthetic(vector);
  return {
    vector: value,
    describe: describeAesthetic(value),
    mix: mixAesthetic(value),
    form: formAesthetic(value),
    tuning: tuningAesthetic(value),
  };
}
