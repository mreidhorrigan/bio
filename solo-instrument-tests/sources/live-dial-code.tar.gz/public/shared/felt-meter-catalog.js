// Authored vocabulary from research/meter/score-policy.json, not a limit on possible meters.
// Rational windows are retained for the independent exact checker. Runtime draws use these baked ranges.
const freeze=value=>{if(value&&typeof value==='object'){Object.values(value).forEach(freeze);Object.freeze(value)}return value};
export const FELT_METER_POLICY=freeze({
  "id": "score-selection-v2",
  "evidence": "authored-policy-not-human-calibration",
  "favoredBeatSeconds": [
    "2/5",
    "4/5"
  ],
  "candidateBeatSeconds": [
    "3/10",
    "1"
  ],
  "cyclePreferenceMaxSeconds": "4",
  "cycleMinimumSeconds": null,
  "catalog": [
    {"id":"2/4-in-2","numerator":2,"denominator":4,"beatWeights":[1,1],"groups":[1,1],"kind":"standard","reference":{"unit":4,"dots":0},"favoredQuarterBPM":["75","150"],"candidateQuarterBPM":["60","200"]},
    {"id":"3/4-in-3","numerator":3,"denominator":4,"beatWeights":[1,1,1],"groups":[3],"kind":"standard","reference":{"unit":4,"dots":0},"favoredQuarterBPM":["75","150"],"candidateQuarterBPM":["60","200"]},
    {"id":"4/4-in-4","numerator":4,"denominator":4,"beatWeights":[1,1,1,1],"groups":[2,2],"kind":"standard","reference":{"unit":4,"dots":0},"favoredQuarterBPM":["75","150"],"candidateQuarterBPM":["60","200"]},
    {"id":"2/2-in-2","numerator":2,"denominator":2,"beatWeights":[1,1],"groups":[1,1],"kind":"standard","reference":{"unit":2,"dots":0},"favoredQuarterBPM":["150","300"],"candidateQuarterBPM":["120","400"]},
    {"id":"3/2-in-3","numerator":3,"denominator":2,"beatWeights":[1,1,1],"groups":[3],"kind":"standard","reference":{"unit":2,"dots":0},"favoredQuarterBPM":["150","300"],"candidateQuarterBPM":["120","400"]},
    {"id":"6/8-in-2","numerator":6,"denominator":8,"beatWeights":[3,3],"groups":[3,3],"kind":"standard","reference":{"unit":4,"dots":1},"favoredQuarterBPM":["225/2","225"],"candidateQuarterBPM":["90","300"]},
    {"id":"9/8-in-3","numerator":9,"denominator":8,"beatWeights":[3,3,3],"groups":[3,3,3],"kind":"standard","reference":{"unit":4,"dots":1},"favoredQuarterBPM":["225/2","225"],"candidateQuarterBPM":["90","300"]},
    {"id":"12/8-in-4","numerator":12,"denominator":8,"beatWeights":[3,3,3,3],"groups":[3,3,3,3],"kind":"standard","reference":{"unit":4,"dots":1},"favoredQuarterBPM":["225/2","225"],"candidateQuarterBPM":["90","300"]},
    {"id":"5/4-in-5","numerator":5,"denominator":4,"beatWeights":[1,1,1,1,1],"groups":[2,3],"kind":"grouped","reference":{"unit":4,"dots":0},"favoredQuarterBPM":["75","150"],"candidateQuarterBPM":["75","200"]},
    {"id":"7/4-in-7","numerator":7,"denominator":4,"beatWeights":[1,1,1,1,1,1,1],"groups":[2,2,3],"kind":"grouped","reference":{"unit":4,"dots":0},"favoredQuarterBPM":["105","150"],"candidateQuarterBPM":["105","200"]},
    {"id":"5/4-in-2","numerator":5,"denominator":4,"beatWeights":[2,3],"groups":[2,3],"kind":"grouped","reference":{"unit":4,"dots":0},"favoredQuarterBPM":["225","300"],"candidateQuarterBPM":["180","400"]},
    {"id":"7/4-in-3","numerator":7,"denominator":4,"beatWeights":[2,2,3],"groups":[2,2,3],"kind":"grouped","reference":{"unit":4,"dots":0},"favoredQuarterBPM":["225","300"],"candidateQuarterBPM":["180","400"]},
    {"id":"5/8-in-2","numerator":5,"denominator":8,"beatWeights":[2,3],"groups":[2,3],"kind":"grouped","reference":{"unit":4,"dots":0},"favoredQuarterBPM":["225/2","150"],"candidateQuarterBPM":["90","200"]},
    {"id":"7/8-in-3","numerator":7,"denominator":8,"beatWeights":[2,2,3],"groups":[2,2,3],"kind":"grouped","reference":{"unit":4,"dots":0},"favoredQuarterBPM":["225/2","150"],"candidateQuarterBPM":["90","200"]},
    {"id":"8/8-in-3","numerator":8,"denominator":8,"beatWeights":[3,3,2],"groups":[3,3,2],"kind":"grouped","reference":{"unit":4,"dots":0},"favoredQuarterBPM":["225/2","150"],"candidateQuarterBPM":["90","200"]},
    {"id":"9/8-in-4","numerator":9,"denominator":8,"beatWeights":[2,2,2,3],"groups":[2,2,2,3],"kind":"grouped","reference":{"unit":4,"dots":0},"favoredQuarterBPM":["225/2","150"],"candidateQuarterBPM":["90","200"]},
    {"id":"11/8-in-5","numerator":11,"denominator":8,"beatWeights":[2,2,3,2,2],"groups":[2,2,3,2,2],"kind":"grouped","reference":{"unit":4,"dots":0},"favoredQuarterBPM":["225/2","150"],"candidateQuarterBPM":["90","200"]},
    {"id":"13/8-in-5","numerator":13,"denominator":8,"beatWeights":[3,3,3,2,2],"groups":[3,3,3,2,2],"kind":"grouped","reference":{"unit":4,"dots":0},"favoredQuarterBPM":["225/2","150"],"candidateQuarterBPM":["195/2","200"]},
    {"id":"17/8-in-6","numerator":17,"denominator":8,"beatWeights":[3,3,3,3,3,2],"groups":[3,3,3,3,3,2],"kind":"grouped","reference":{"unit":4,"dots":0},"favoredQuarterBPM":["255/2","150"],"candidateQuarterBPM":["255/2","200"]},
    {"id":"5/16-in-2","numerator":5,"denominator":16,"beatWeights":[2,3],"groups":[2,3],"kind":"grouped","reference":{"unit":4,"dots":0},"favoredQuarterBPM":["225/4","75"],"candidateQuarterBPM":["45","100"]},
    {"id":"7/16-in-3","numerator":7,"denominator":16,"beatWeights":[2,2,3],"groups":[2,2,3],"kind":"grouped","reference":{"unit":4,"dots":0},"favoredQuarterBPM":["225/4","75"],"candidateQuarterBPM":["45","100"]},
    {"id":"17/16-in-7","numerator":17,"denominator":16,"beatWeights":[2,2,3,2,2,3,3],"groups":[2,2,3,2,2,3,3],"kind":"grouped","reference":{"unit":4,"dots":0},"favoredQuarterBPM":["255/4","75"],"candidateQuarterBPM":["255/4","100"]},
    {"id":"17/16-in-4","numerator":17,"denominator":16,"beatWeights":[4,4,4,5],"groups":[4,4,4,5],"kind":"grouped","reference":{"unit":4,"dots":0},"favoredQuarterBPM":["375/4","150"],"candidateQuarterBPM":["75","200"]},
    {"id":"107/32-in-5","numerator":107,"denominator":32,"beatWeights":[19,19,19,25,25],"groups":[57,50],"kind":"specialist","reference":{"unit":4,"dots":0},"favoredQuarterBPM":["1875/8","1425/4"],"candidateQuarterBPM":["1605/8","475"]},
    {"id":"107/32-in-2","numerator":107,"denominator":32,"beatWeights":[57,50],"groups":[57,50],"kind":"specialist","reference":{"unit":1,"dots":0},"favoredQuarterBPM":["4275/8","1875/2"],"candidateQuarterBPM":["855/2","1250"]}
  ]
});
export const FELT_METER_CATALOG=FELT_METER_POLICY.catalog;
