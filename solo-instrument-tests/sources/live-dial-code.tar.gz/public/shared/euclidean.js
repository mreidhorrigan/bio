// The rhythm engine's core: rhythmic layers, maximally even placement on them, and syncopations with their resolutions,
// nested as deep as a span divides (docs/RHYTHM_TO_FORM.md, the owner's specification, 4 November 2026: "refactoring
// it to base it on Euclidean rhythm for more flexible complexity"; "to allow nesting of euclidean rhythms, as well as
// arbitrary subdivisions at different layers from convenional duple time all the way to extreme tuplets"; "the
// generation and resolution of syncopations, a generalization of the hemiola concept"; research/
// PANMETER_RHYTHM_CORE_PLAN.md, "The Euclidean basis"). Numbers in brackets are the specification's.
//
//   Layers [2]: an isochronous chain, each layer M events of the one below per event of its own (layerChain); X(0) the
//     one in the beat's band, 60 to 180 a minute; none shorter than the shortest period, 50 ms, where tempo becomes
//     pitch (registry/method/rhythm.json). A span divides into any number of equal parts down to it (divisions): two,
//     three, thirteen in the time of eight.
//   Spans: a span divided by a tree of weights, each node its own division or grouping, as deep as it goes, in exact
//     rationals (pulse-streams.js subdivide; meterTree, groupTree, spanEvents), each event weighed by the levels it
//     begins.
//   Placement [6]: k notes over n events as evenly as they can be -- Toussaint's Euclidean rhythms ("The Euclidean
//     algorithm generates traditional musical rhythms", Bridges 2005), the maximally even sets of Clough & Douthett
//     ("Maximally even sets", Journal of Music Theory 35, 1991, doi:10.2307/843811) -- turned to begin at one of their
//     rotations (euclid); their evenness the sum of their chords (Demaine, Gomez-Martin, Meijer, Rappaport et al., "The
//     distance geometry of music", Computational Geometry 42, 2009, doi:10.1016/j.comgeo.2008.04.005); lines laid
//     together each maximally even, their aggregate as even as their rotations let it be (interlock); two adjacent
//     notes combined (combine); each note lasting to the next onset (durations) [4].
//   Syncopation and resolution [3, 5, 7.1]: a layer grouped at a meter M(s) for a span and repeated, then the time left
//     to the next event of the layer above grouped at M(r): 3+3, then 2 (syncopate). The hemiola generalized: Krebs's
//     grouping dissonance (Fantasy Pieces: Metrical Dissonance in the Music of Robert Schumann, 1999), Cohn's complex
//     hemiolas ("Complex hemiolas, ski-hill graphs and metric spaces", Music Analysis 20, 2001,
//     doi:10.1111/1468-2249.00141), Biamonte's in rock ("Formal functions of metric dissonance in rock music", Music
//     Theory Online 20.2, 2014). A grouping of n into k as even as it can be is Euclidean (grouping: E(3,8) 3+3+2,
//     E(3,7) 2+2+3), and the syncopations of a span stand where notes would (euclid over its events) [6.3]. A displaced
//     layer (Krebs's displacement dissonance; Temperley's anticipations, "Syncopation in rock: a perceptual
//     perspective", Popular Music 18, 1999, doi:10.1017/S0261143000008710) is a rotation, or a note combined over the
//     beat.
//
// Nothing here chooses: the layers' meters, the divisions, the counts, the rotations, the syncopations and their
// resolutions are a player's, drawn from its seed or heard, in performance. Slots are whole-number indices of a layer's
// events; times are pulse-streams' Rationals, or ticks of the bar (meterGrids, for the clock's grid).
import {Rational} from '../transcript/rational.js';
import {setting} from '../../registry/registry.js';
import {euclideanRhythm} from '../stochastic-algorithms.js';
import {FELT_TEMPO,meterLevels} from './felt-tempo.js';
import {sectionLevels} from './metric-home/sections.js';
import {subdivide} from './pulse-streams.js';

const gcd=(a,b)=>{a=Math.abs(a);b=Math.abs(b);while(b)[a,b]=[b,a%b];return a};
const modulo=(value,n)=>((value%n)+n)%n;
const clamp01=value=>Math.max(0,Math.min(1,Number(value)||0));
const slotCount=(n,what='A cycle')=>{if(!Number.isSafeInteger(n)||n<1)throw new RangeError(`${what} is a positive whole number of slots, not ${n}`);return n};
const countIn=(k,n)=>{if(!Number.isSafeInteger(k)||k<0||k>n)throw new RangeError(`A count is a whole number from 0 to ${n}, not ${k}`);return k};
const whole=(m,what='A meter')=>{if(!Number.isSafeInteger(m)||m<1)throw new RangeError(`${what} is a positive whole number, not ${m}`);return m};
const sum=list=>list.reduce((a,b)=>a+b,0);

// The layers' bounds (registry/method/rhythm.json `rhythm-layers`): the beat's band, in seconds, and the shortest period.
export const RHYTHM=Object.freeze({
  beat:Object.freeze([60/setting('rhythm-layers','fastestBeat'),60/setting('rhythm-layers','slowestBeat')]),
  shortestPeriod:setting('rhythm-layers','shortestPeriod')
});

// --- Maximally even sets [6.1, 6.2] ---

// k onsets over n slots as evenly as they can be, turned `rotation` slots later: the collection's own sets
// (stochastic-algorithms.js euclideanRhythm, its first onset on slot 0 before it is turned), as slot indices in order.
// Each gap between onsets is the floor or the ceiling of n / k slots.
export function euclid(k,n,rotation=0){
  slotCount(n);countIn(k,n);
  if(!Number.isSafeInteger(rotation))throw new RangeError(`A rotation is a whole number of slots, not ${rotation}`);
  return Object.freeze(euclideanRhythm(k,n,rotation).flatMap((on,at)=>on?[at]:[]));
}
// The slots of n a set leaves empty: maximally even where the set is (Clough & Douthett 1991).
export function complement(onsets,n){
  slotCount(n);const taken=new Set(onsets.map(at=>modulo(at,n)));
  return Object.freeze(Array.from({length:n},(_,at)=>at).filter(at=>!taken.has(at)));
}
// k of the given slots (any set of them, in order), as evenly as k can be spread over their list: a layer laid within
// another's onsets or gaps -- a Euclidean rhythm of a Euclidean rhythm -- or within the slots a rule leaves it.
export function evenlyWithin(slots,k,rotation=0){
  const list=[...slots];
  if(!list.length){countIn(k,0);return Object.freeze([])}
  return Object.freeze(euclid(k,list.length,rotation).map(index=>list[index]));
}
// A count from a share of n, rounded, within [least, most].
export function countOf(share,n,{least=0,most=n}={}){
  slotCount(n);return Math.max(Math.max(0,least),Math.min(Math.min(n,most),Math.round(clamp01(share)*n)));
}
// The gaps between a cycle's onsets, from its first, the last wrapping round to it: their durations in slots [4].
export function gaps(onsets,n){
  slotCount(n);const at=[...new Set(onsets.map(slot=>modulo(slot,n)))].sort((a,b)=>a-b);
  return Object.freeze(at.map((slot,k)=>k+1<at.length?at[k+1]-slot:n-slot+at[0]));
}
// n events grouped into k groups as evenly as they can be, the groups' sizes in order from the `turn`th: E(k, n)'s gaps,
// an additive grouping (2+2+3 is E(3,7), 3+3+2+3+2 E(5,13)) or a syncopation and its resolution (3+3+2 is E(3,8)).
export function grouping(k,n,turn=0){
  whole(k,'A count of groups');if(k>slotCount(n))throw new RangeError(`${n} events make at most ${n} groups, not ${k}`);
  const sizes=gaps(euclid(k,n),n),from=modulo(turn,k);
  return Object.freeze([...sizes.slice(from),...sizes.slice(0,from)]);
}
// How evenly onsets stand round a cycle of n: the sum of the chords between every two of them on a circle of unit
// radius, coincident onsets (lines laid together) counting nothing between them. Among sets of one size, the maximally
// even ones, and they alone, have the most (Block & Douthett, "Vector products and intervallic weighting", Journal of
// Music Theory 38, 1994, doi:10.2307/843826).
export function evenness(onsets,n){
  slotCount(n);const at=onsets.map(slot=>modulo(slot,n));let total=0;
  for(let a=0;a<at.length;a++)for(let b=a+1;b<at.length;b++)total+=2*Math.sin(Math.PI*Math.abs(at[a]-at[b])/n);
  return total;
}
// Whether a set is maximally even in n: each span of d of its steps, for every d, comes in one size or two consecutive
// sizes (Clough & Douthett 1991's definition).
export function isMaximallyEven(onsets,n){
  const steps=gaps(onsets,n),k=steps.length;
  for(let d=1;d<k;d++){
    let least=Infinity,most=-Infinity;
    for(let from=0;from<k;from++){let span=0;for(let j=0;j<d;j++)span+=steps[(from+j)%k];least=Math.min(least,span);most=Math.max(most,span)}
    if(most-least>1)return false;
  }
  return true;
}

// --- Rhythmic layers [2] ---

// The layers under an event `seconds` long (a bar, a phrase, the piece: the maximum layer, one event [2.5]), top
// first, each dividing the one above it into its meter's number [2.3]: `meters` top down, each a whole number (a 2, a
// 3, a 13). Each layer {x, period, meter, count}: its index from X(0) (layers above it positive), its period in seconds,
// its meter (its events per event of the layer above) and its events in the top's one. The chain stops above the
// shortest period [2.4]: a layer under it is pitch. X(0) is the layer in the beat's band [2.2] nearest the felt beat a
// listener favours (felt-tempo.js FELT_TEMPO.favoredBeat), the coarser on a tie; where none is in the band, the one
// nearest it. -> {layers, beat: X(0)'s index among them}.
export function layerChain(seconds,meters,{shortest=RHYTHM.shortestPeriod,band=RHYTHM.beat,favored=FELT_TEMPO.favoredBeat}={}){
  if(!(seconds>0))throw new RangeError(`A layer's event lasts some time, not ${seconds} s`);
  const chain=[{period:seconds,meter:1,count:1}];
  for(const meter of meters){
    const above=chain.at(-1),period=above.period/whole(meter);
    if(period<shortest-1e-12)break;
    chain.push({period,meter,count:above.count*meter});
  }
  const away=(period,[low,high])=>period<low?Math.log(low/period):period>high?Math.log(period/high):0;
  let beat=0;
  for(let k=1;k<chain.length;k++){
    const here=[away(chain[k].period,band),away(chain[k].period,favored)],best=[away(chain[beat].period,band),away(chain[beat].period,favored)];
    if(here[0]<best[0]-1e-12||(Math.abs(here[0]-best[0])<=1e-12&&here[1]<best[1]-1e-12))beat=k;
  }
  return Object.freeze({beat,layers:Object.freeze(chain.map((layer,k)=>Object.freeze({x:beat-k,...layer})))});
}
// The most equal parts an event `seconds` long divides into, each no shorter than the shortest period: every number
// from one to it is a division the layer below may take there [2.4, 3.3] -- duple, triple, a tuplet of any size.
export function divisions(seconds,{shortest=RHYTHM.shortestPeriod}={}){
  if(!(seconds>0))throw new RangeError(`An event lasts some time, not ${seconds} s`);
  return Math.max(1,Math.floor(seconds/shortest+1e-9));
}

// --- Spans: nesting and tuplets ---

// n equal parts: a layer of meter n under one event (a tuplet where its neighbours divide otherwise).
export function parts(n){return Object.freeze(Array.from({length:whole(n,'A division')},()=>1))}
// A tree of isochronous layers, `meters` top down (each node's children its meter's number): pulse-streams.js
// subdivide's tree. [4, 2, 2] is a bar of four beats of two eighths of two sixteenths; [3, 13], three beats each in
// thirteen.
export function meterTree(meters){
  if(!meters.length)throw new RangeError('A tree of layers has a meter or more');
  const build=depth=>depth===meters.length-1?parts(meters[depth]):Array.from({length:whole(meters[depth])},()=>Object.freeze({weight:1,children:build(depth+1)}));
  return build(0);
}
// Groups of a layer's events, each group a node weighing its events, its children `inner(size, index)`: its own events
// by default, or any tree within it -- a division, a tuplet across the group, another grouping, a syncopation within it
// that crosses none of its bounds [3.4.1].
export function groupTree(sizes,inner=size=>parts(size)){
  return Object.freeze(sizes.map((size,k)=>Object.freeze({weight:whole(size,'A group'),children:inner(size,k)})));
}
// How many levels of a tree an event begins: itself, and each above whose first child it is (its path's trailing
// noughts), the span's first event beginning them all (Lerdahl & Jackendoff, A Generative Theory of Tonal Music, 1983;
// Longuet-Higgins & Lee, "The rhythmic interpretation of monophonic music", Music Perception 1, 1984,
// doi:10.2307/40285271).
export function pathWeight(path){let weight=1;for(let k=path.length-1;k>=0&&path[k]===0;k--)weight++;return weight}
// A tree's events over a span (pulse-streams.js subdivide: exact times, its spans and paths), each with its weight.
export function spanEvents(tree,span,options){
  return Object.freeze(subdivide(tree,span,options).map(event=>Object.freeze({...event,weight:pathWeight(event.path)})));
}

// --- Syncopation and resolution [3, 5, 7.1] ---

// Whether a grouping of a layer at M(s) is dissonant with its meter M: neither a multiple of it (a layer above) nor a
// factor of it (a layer below) -- Krebs's grouping dissonance; a hemiola's is 2 against 3.
export const dissonant=(groupMeter,meter)=>whole(groupMeter)%whole(meter)!==0&&meter%groupMeter!==0;
// A syncopation and its resolution within one event of the layer above, n events of the layer [3.1, 5]: the layer
// grouped at meter M(s) `repeats` times, then the n - M(s) x repeats events left -- to the next event of the layer above
// [5.2] -- grouped at M(r) as evenly as they divide (into round(left / M(r)) groups, at least one: grouping). None is
// left where the syncopation realigns by itself, a hemiola's 2+2+2 in two bars of three. -> {groups, syncopation:
// {meter, repeats, events}, resolution: {meter, events, groups}}, the groups their sizes in the layer's events.
export function syncopate(n,{meter,repeats,resolution}){
  slotCount(n,'A span');whole(meter,'A syncopation\'s meter');whole(repeats,'A syncopation\'s repeats');
  const held=meter*repeats,left=n-held;
  if(left<0)throw new RangeError(`${repeats} groups of ${meter} overrun a span of ${n}`);
  if(left&&resolution===undefined)throw new RangeError(`A syncopation leaving ${left} of ${n} events needs its resolution's meter`);
  const closing=left?grouping(Math.max(1,Math.min(left,Math.round(left/whole(resolution,'A resolution\'s meter')))),left):Object.freeze([]);
  return Object.freeze({
    groups:Object.freeze([...Array.from({length:repeats},()=>meter),...closing]),
    syncopation:Object.freeze({meter,repeats,events:held}),
    resolution:Object.freeze({meter:left?resolution:null,events:left,groups:closing})
  });
}
// The syncopations a span of n events of a layer of meter M affords: each M(s) from 2 below n dissonant with M, with the
// repeats it can take, `least` (a syncopation repeating at least once [7.1]) to as many as fit -> [{meter, repeats}].
export function syncopations(n,meter,{least=2}={}){
  slotCount(n,'A span');whole(meter);const out=[];
  for(let groupMeter=2;groupMeter<n;groupMeter++){
    if(!dissonant(groupMeter,meter))continue;
    for(let repeats=Math.max(1,least);groupMeter*repeats<=n;repeats++)out.push(Object.freeze({meter:groupMeter,repeats}));
  }
  return Object.freeze(out);
}
// Where groups begin, in the layer's events: the events of the layer the grouping makes, on which notes are placed.
export function groupStartsOf(groups){let at=0;return Object.freeze(groups.map(size=>{const start=at;at+=size;return start}))}

// --- Lines together [6.4, 6.5] ---

// The rotations of k notes over n events beside lines already placed (each a list of slots of the same n), each
// {rotation, onsets, evenness}: the evenness of every onset together, the aggregate's [6.5]. A set of k and n with a
// common factor repeats within n / gcd(k, n), and has as many rotations.
export function interlock(placed,k,n){
  slotCount(n);countIn(k,n);const others=placed.flat(),period=k?n/gcd(k,n):1,out=[];
  for(let rotation=0;rotation<period;rotation++){const onsets=euclid(k,n,rotation);out.push(Object.freeze({rotation,onsets,evenness:evenness([...others,...onsets],n)}))}
  return Object.freeze(out);
}
// One line's n events dealt among the voices it implies, a compound melody (an Alberti bass, an arpeggio, a broken
// chord): each voice in turn takes its count of the events the voices before it left, as evenly as they spread over
// them (evenlyWithin), at its own rotation, so that each voice is a Euclidean rhythm within the line and they
// interlock. Counts summing to under n leave the rest to no voice. -> each voice's slots.
export function partition(n,counts,rotations=[]){
  slotCount(n);if(sum(counts)>n)throw new RangeError(`${n} events cannot be dealt ${sum(counts)} ways`);
  let left=Array.from({length:n},(_,at)=>at);
  return Object.freeze(counts.map((k,voice)=>{
    const taken=evenlyWithin(left,countIn(k,left.length),rotations[voice]??0),gone=new Set(taken);
    left=left.filter(at=>!gone.has(at));return taken;
  }));
}
// A linear rhythm (the owner, 4 November 2026: '"linear" rhythms are often interlocked Euclidean rhythms at different
// rotations'): lines of these counts over the same n events, each E(k, n) at its own rotation, no two ever striking
// together -> every such choice, each a line's {rotation, onsets} in the counts' order (none where the counts cannot
// interlock so; `partition` then deals them, each line Euclidean within what the others leave).
export function linear(n,counts){
  slotCount(n);if(sum(counts)>n)throw new RangeError(`${n} events cannot hold ${sum(counts)} strokes apart`);
  const options=counts.map(k=>Array.from({length:k?n/gcd(countIn(k,n),n):1},(_,rotation)=>Object.freeze({rotation,onsets:euclid(k,n,rotation)}))),out=[];
  const visit=(line,taken,chosen)=>{
    if(line===counts.length){out.push(Object.freeze(chosen));return}
    for(const option of options[line])if(!option.onsets.some(at=>taken.has(at)))visit(line+1,new Set([...taken,...option.onsets]),[...chosen,option]);
  };
  visit(0,new Set,[]);
  return Object.freeze(out);
}
// The candidates whose evenness is the greatest, every one of them that ties.
export function mostEven(candidates){
  const most=Math.max(...candidates.map(c=>c.evenness));
  return Object.freeze(candidates.filter(c=>c.evenness>=most-1e-9));
}
// Two adjacent notes combined [6.4]: the note at `index` held through the next, whose onset goes.
export function combine(onsets,index){
  if(!Number.isSafeInteger(index)||index<0||index+1>=onsets.length)throw new RangeError(`Note ${index} has no next note to combine with`);
  return Object.freeze(onsets.filter((_,k)=>k!==index+1));
}
// Each onset's duration, to the next onset, the last to `end` [4.1]: whole numbers, or Rationals where any time is one.
export function durations(times,end){
  const all=[...times,end];
  if(all.every(t=>typeof t==='number'))return Object.freeze(times.map((t,k)=>all[k+1]-t));
  const exact=all.map(t=>Rational.of(t));
  return Object.freeze(exact.slice(0,-1).map((t,k)=>exact[k+1].sub(t)));
}

// --- The bar's grids on the clock's ticks ---

// The bar's grids, coarsest first, each {name, starts, sizes}: the slots' starts and lengths in ticks from the bar's
// start. The bar; the levels above its groups, its sections' among them (felt-tempo.js meterLevels, metric-home/
// sections.js); its groups; its units, `subdivision` ticks each; and each division of a unit its ticks allow (a unit of
// six ticks into two, three and six), down to the ticks. A grid two levels share is given once, by its coarser name.
export function meterGrids(meter){
  const subdivision=Math.max(1,Math.round(Number(meter?.subdivision)||1)),numerator=Math.max(1,Math.round(Number(meter?.numerator)||1));
  const bar=Math.round(Number(meter?.pulsesPerBar)||numerator*subdivision),unit=bar/numerator,grids=[],seen=new Set;
  const add=(name,starts)=>{
    const key=starts.join(',');if(seen.has(key))return;seen.add(key);
    grids.push(Object.freeze({name,starts:Object.freeze(starts),sizes:Object.freeze(starts.map((at,k)=>(starts[k+1]??bar)-at))}));
  };
  const fromSpans=spans=>{let at=0;return spans.map(size=>{const start=Math.round(at);at+=size*unit;return start})};
  const groups=Array.isArray(meter?.groups)?meter.groups.map(Number):[];
  const above=[...meterLevels(meter),...(sectionLevels(meter)??[])].filter(spans=>spans.length>1&&sum(spans)===numerator);
  add('bar',[0]);
  for(const spans of above.sort((a,b)=>a.length-b.length))add(spans.join()===groups.join()?'groups':'level',fromSpans(spans));
  if(Number.isInteger(unit))add('units',Array.from({length:numerator},(_,k)=>k*unit));
  const ticksPerUnit=Number.isInteger(unit)?unit:subdivision;
  for(let n=2;n<=ticksPerUnit;n++)if(ticksPerUnit%n===0)add(`unit/${n}`,Array.from({length:bar/(ticksPerUnit/n)},(_,k)=>k*ticksPerUnit/n));
  return Object.freeze(grids);
}
// Each tick's metrical weight in the bar: how many of its grids begin a slot there (as pathWeight), the downbeat
// beginning every one.
export function gridWeights(meter,grids=meterGrids(meter)){
  const bar=Math.round(Number(meter?.pulsesPerBar)||1),weights=new Array(bar).fill(0);
  for(const grid of grids)for(const at of grid.starts)if(at<bar)weights[at]++;
  return Object.freeze(weights);
}
// A grid's slots' weights, from the bar's (gridWeights).
export const slotWeights=(grid,weights)=>Object.freeze(grid.starts.map(at=>weights[at]??0));

// How syncopated a cycle's onsets are against its slots' weights, after Longuet-Higgins & Lee (1984): each onset followed,
// before the next, by a silent slot weightier than itself adds the difference (the weightiest such slot's), the cycle
// wrapping round. 0 where every onset stands at least as weighty as the silence after it.
export function syncopationOf(onsets,weights){
  const n=weights.length,on=new Set(onsets.map(at=>modulo(at,n)));let total=0;
  if(!on.size||on.size===n)return 0;
  for(const at of on){
    let heaviest=-Infinity;
    for(let step=1;step<n;step++){const q=(at+step)%n;if(on.has(q))break;heaviest=Math.max(heaviest,weights[q])}
    if(heaviest>weights[at])total+=heaviest-weights[at];
  }
  return total;
}
// The distinct rotations of k onsets over a grid of n slots with these weights, each {rotation, onsets, fit,
// syncopation}: its fit its onsets' mean weight, its syncopation Longuet-Higgins & Lee's (syncopationOf). `downbeat`:
// only those that strike slot 0.
export function rotationsOf(k,n,weights,{downbeat=false}={}){
  slotCount(n);countIn(k,n);
  if(weights.length!==n)throw new RangeError(`A grid of ${n} slots weighs ${n}, not ${weights.length}`);
  const period=k?n/gcd(k,n):1,out=[];
  for(let rotation=0;rotation<period;rotation++){
    const onsets=euclid(k,n,rotation);
    if(downbeat&&!onsets.includes(0))continue;
    out.push(Object.freeze({rotation,onsets,fit:k?sum(onsets.map(at=>weights[at]))/k:0,syncopation:syncopationOf(onsets,weights)}));
  }
  return Object.freeze(out);
}
// The rotation a displacement asks for, from 0 (its onsets on the strongest places: the most fitted) to 1 (the least
// fitted), the fit nearest that share of the way between them, the earlier on a tie: as the timeline chooses
// (performers/timeline.js). Null where there are none.
export function chooseRotation(rotations,asked=0){
  if(!rotations.length)return null;
  const fits=rotations.map(r=>r.fit),most=Math.max(...fits),least=Math.min(...fits),aim=most-(most-least)*clamp01(asked);
  let best=rotations[0];
  for(const rotation of rotations)if(Math.abs(rotation.fit-aim)<Math.abs(best.fit-aim)-1e-12)best=rotation;
  return best;
}
// The grid a share of the way from `from` to `to` (indices into grids, coarsest first), rounded: a layer's grid dial.
export function gridBetween(from,to,share){
  if(!Number.isSafeInteger(from)||!Number.isSafeInteger(to))throw new RangeError('A grid is an index into the bar\'s grids');
  return from+Math.round((to-from)*clamp01(share));
}
// The grid whose slots begin where these starts do (a felt beat's grid: meter-tactus.js feltBeats), or -1.
export function gridOf(grids,starts){
  const key=[...starts].join(',');return grids.findIndex(grid=>grid.starts.join(',')===key);
}
// The finest grid a stroke can be played on at a tempo: the last, coarsest first, whose shortest slot is at least
// `spacingSeconds` long at secondsPerTick, from `from` on; `from` itself where none finer is.
export function finestPlayable(grids,{secondsPerTick,spacingSeconds=0,from=0}={}){
  let finest=from;
  for(let k=from+1;k<grids.length;k++)if(Math.min(...grids[k].sizes)*secondsPerTick>=spacingSeconds-1e-9)finest=k;
  return finest;
}
// A layer's ticks in one bar: {grid, k, rotation, cycle} -- k onsets over `cycle` slots of the grid (its own slot count,
// the bar, unless given) at its rotation -- in the bar numbered `bar` from the layer's first. A cycle other than the
// bar's runs on over bar lines, its slots counted from the layer's first bar, so that bars laid end to end are the cycle
// laid end to end: the same as a pulse stream continued (pulse-streams.js pulses), where the bar's own is begun again.
export function layerTicks({grid,k,rotation=0,cycle},bar=0){
  const m=grid.starts.length,n=slotCount(cycle??m,'A layer\'s cycle'),on=new Set(euclid(k,n,modulo(rotation,n)));
  if(!Number.isSafeInteger(bar))throw new RangeError('A bar is counted in whole bars');
  const first=n===m?0:modulo(bar*m,n);
  return Object.freeze(grid.starts.filter((_,slot)=>on.has((first+slot)%n)));
}
