// The tempo a clock may run at, by its meter: meter.cjs's tempoRange, for the ES modules (the ensemble's cursor, tempo
// map and conductor, the room's client, the bots, the render spec). The notated beat's 40-220 a minute; or, where a meter
// names the note its tempo counts (tempoUnit: the rate contract's score coordinate, shared/rate-contract.js;
// RESEARCH_BACKLOG P1, "Extreme meters, made perceptible"), that note's 30-720, the rate contract's runtime range. Both
// in the meter's own notes a minute, which is what a clock's bpm counts: 107/16 at a quarter of 120 is 480.
export const TEMPO_LIMITS=Object.freeze({notated:Object.freeze([40,220]),coordinate:Object.freeze([30,720])});
// The meter's notes in one beat of its tempo (four sixteenths a quarter), 1 where it names none.
export const unitsPerTempoBeat=meter=>{const unit=Number(meter?.tempoUnit),denominator=Number(meter?.denominator)||4;return unit>0?denominator/unit:1};
export function tempoRange(meter){const [low,high]=meter?.tempoUnit?TEMPO_LIMITS.coordinate:TEMPO_LIMITS.notated,units=unitsPerTempoBeat(meter);return [low*units,high*units]}
export function clampTempo(bpm,meter){const [low,high]=tempoRange(meter);return Math.max(low,Math.min(high,bpm))}
export function tempoInRange(bpm,meter){const [low,high]=tempoRange(meter);return Number.isFinite(bpm)&&bpm>=low&&bpm<=high}
// A clock's bpm as its meter names it (480 sixteenths a minute is a quarter of 120), and back.
export const namedTempo=(bpm,meter)=>bpm/unitsPerTempoBeat(meter);
export const clockTempo=(named,meter)=>named*unitsPerTempoBeat(meter);
