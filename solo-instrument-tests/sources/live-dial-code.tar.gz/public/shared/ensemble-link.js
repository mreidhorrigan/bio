import {encodeLinkState,decodeLinkState} from './link-codec.js';
import {MIX_DEFAULTS,FX_DEFAULTS,mixSettings,effectSettings,changedSettings} from './sound-settings.js';
import pluginConfig from './plugin-config.js';
import {midiProgramSetting} from './general-midi.js';
import {specSettings} from './spec-settings.js';
const {normalizePluginConfig}=pluginConfig;
const MAX_BOTS=128,MAX_LINK=12000,keys=['e','ensemble','bots','seed','t','beat','started','setup'];
const outputs=[null,'synth','samples','midi'];
const uint32=value=>Number.isInteger(value)&&value>=0&&value<=0xffffffff;
export function readEnsembleLink(value,definitions) {
  const url=new URL(value,'http://localhost');
  if(!url.searchParams.has('bots')&&!url.searchParams.has('e'))return null;
  if(url.search.length>MAX_LINK)throw new Error('This ensemble link is too large');
  let ids,setup,seed,startedAt,effects,effectPlugin;
  if(url.searchParams.has('e')){
    const state=decodeLinkState(url.searchParams.get('e'));
    if(!Array.isArray(state?.b)||state.b.length>MAX_BOTS)throw new Error('Invalid compact ensemble roster');
    seed=state.s;startedAt=state.a;
    if(state.f)effects=effectSettings(state.f);
    effectPlugin=normalizePluginConfig(state.p);
    ids=[];setup=state.b.map((row,index)=>{
      if(!Array.isArray(row)||typeof row[0]!=='string')throw new Error('Invalid compact bot entry');
      const output=row[2]??1,options=row[3]??{};
      if(!Number.isInteger(output)||output<0||output>=outputs.length||typeof options!=='object'||Array.isArray(options))throw new Error('Invalid compact bot setup');
      ids.push(row[0]);
      return {key:row[1]??String(index+1),output:outputs[output],at:options.a,
        loadOnly:options.l===1,muted:options.m===1,midiProtocol:options.p===2?'midi2':'midi1',
        midiGroup:options.g,channel:options.c,mpeZone:options.z,bendRange:options.r,midiProgram:options.o,
        synthesizer:options.y,synthOptions:options.w,samplePreset:options.f,sampleSource:options.u===1?'local':undefined,mix:options.x,settings:options.s};
    });
  }else{
    if(url.searchParams.get('ensemble')!=='1')throw new Error('Unsupported ensemble link version');
    ids=url.searchParams.get('bots').split(',').filter(Boolean);
    seed=url.searchParams.has('seed')?Number(url.searchParams.get('seed')):null;
    startedAt=Number(url.searchParams.get('started')||0);
    setup=JSON.parse(url.searchParams.get('setup')||'[]');
  }
  if(!ids.length||ids.length>MAX_BOTS)throw new Error('The ensemble link must contain 1–128 bots');
  for(const id of ids)if(!Object.hasOwn(definitions,id))throw new Error(`Unknown musebot in link: ${id}`);
  const elapsed=Number(url.searchParams.get('t')||0);
  if(!uint32(seed))throw new Error('Invalid ensemble seed');
  if(!Number.isFinite(elapsed)||elapsed<0||elapsed>31536000)throw new Error('Invalid elapsed time');
  if(!Number.isSafeInteger(startedAt)||startedAt<0)throw new Error('Invalid ensemble start time');
  const beat=url.searchParams.has('beat')?Number(url.searchParams.get('beat')):null;
  if(beat!==null&&(!Number.isSafeInteger(beat)||beat<0))throw new Error('Invalid ensemble beat position');
  if(!Array.isArray(setup)||setup.length>ids.length)throw new Error('Invalid bot setup in link');
  const used=new Set(),bots=ids.map((id,index)=>{
    const value=setup[index]||{},key=String(value.key??index+1);
    if(!/^[A-Za-z0-9_-]{1,40}$/.test(key)||used.has(key))throw new Error('Duplicate or invalid bot identity in link');used.add(key);
    const available=definitions[id].previewOutputModes||definitions[id].outputModes;
    if(value.synthesizer!==undefined&&!/^[a-z][a-z0-9-]{0,63}$/.test(value.synthesizer))throw new Error('Invalid synthesizer id');
    if(value.samplePreset!==undefined&&(typeof value.samplePreset!=='string'||value.samplePreset.length>128))throw new Error('Invalid sample preset');
    let midiProgram;try{midiProgram=midiProgramSetting(value.midiProgram)}catch{throw new Error('Invalid MIDI program')}
    const synthOptions=normalizePluginConfig(value.synthOptions);
    if(value.output!==undefined&&value.output!==null&&!available.includes(value.output))throw new Error(`Unsupported output for ${id}`);
    // Its bot's settings, those its definition declares a spec may give it (spec-settings.js); never a fork's own.
    const {forkOf,...settings}=specSettings(value.settings,definitions[id]);
    return {id,key,output:value.output===undefined?(available[0]??null):value.output,loadOnly:value.loadOnly===true,muted:value.muted===true,
      midiProtocol:value.midiProtocol==='midi2'?'midi2':'midi1',midiGroup:Math.max(1,Math.min(16,Math.trunc(Number(value.midiGroup)||1))),
      channel:value.channel==='default'?'default':String(Math.max(1,Math.min(16,Math.trunc(Number(value.channel)||1)))),
      mpeZone:['lower','upper','single'].includes(value.mpeZone)?value.mpeZone:undefined,
      bendRange:Math.max(.01,Math.min(96,Number(value.bendRange)||48)),at:Math.max(0,Number(value.at)||0),
      ...(midiProgram!=='none'?{midiProgram}:{}),
      ...(value.synthesizer?{synthesizer:value.synthesizer}:{}),...(synthOptions?{synthOptions}:{}),...(value.samplePreset?{samplePreset:value.samplePreset}:{}),...(value.sampleSource==='local'?{sampleSource:'local'}:{}),...(value.mix?{mix:mixSettings(value.mix)}:{}),...(Object.keys(settings).length?{settings}:{})};
  });
  return {seed,elapsed,beat,startedAt,bots,...(effects?{effects}:{}),...(effectPlugin?{effectPlugin}:{})};
}
export function writeEnsembleLink(value,state) {
  // A fork is left out: the bot it forked from forks it again where its musical logics conflict (logic-conflicts.js).
  const url=new URL(value),bots=state.bots?.filter(bot=>!bot.forkOf);
  if(!bots?.length)return url;
  if(bots.length>MAX_BOTS)throw new Error('This ensemble is too large for a share link');
  for(const key of keys)url.searchParams.delete(key);
  const entries=bots.map((bot,index)=>{
    const row=[bot.id],options={},output=outputs.indexOf(bot.output);
    if(output<0)throw new Error(`Unsupported output for ${bot.id}`);
    if(String(bot.key)!==String(index+1))row[1]=String(bot.key);
    if(output!==1)row[2]=output;
    if(bot.at)options.a=Number(bot.at.toFixed(2));
    if(bot.loadOnly)options.l=1;if(bot.muted)options.m=1;
    if(bot.synthesizer&&bot.synthesizer!=='musebots')options.y=bot.synthesizer;
    const synthOptions=normalizePluginConfig(bot.synthOptions);if(synthOptions)options.w=synthOptions;
    if(bot.samplePreset)options.f=bot.samplePreset;
    if(bot.sampleSource==='local')options.u=1;
    const mix=changedSettings(bot.mix,MIX_DEFAULTS);if(Object.keys(mix).length)options.x=mix;
    if(bot.settings&&Object.keys(bot.settings).length)options.s=bot.settings;
    if(bot.output==='midi'){
      if(bot.midiProtocol==='midi2')options.p=2;
      if(bot.midiGroup&&bot.midiGroup!==1)options.g=bot.midiGroup;
      if(bot.channel!==undefined&&String(bot.channel)!=='1')options.c=bot.channel;
      if(bot.mpeZone&&bot.mpeZone!=='single')options.z=bot.mpeZone;
      if(bot.bendRange!==undefined&&bot.bendRange!==48)options.r=bot.bendRange;
      if(bot.midiProgram!==undefined&&bot.midiProgram!=='none')options.o=midiProgramSetting(bot.midiProgram);
    }
    if(Object.keys(options).length)row[3]=options;
    return row;
  });
  const effects=changedSettings(state.effects,FX_DEFAULTS);
  const effectPlugin=normalizePluginConfig(state.effectPlugin);
  url.searchParams.set('e',encodeLinkState({s:state.seed,a:state.startedAt,b:entries,...(Object.keys(effects).length?{f:effects}:{}),...(effectPlugin?{p:effectPlugin}:{})}));
  if(Number.isSafeInteger(state.beat))url.searchParams.set('beat',String(state.beat));
  if(url.searchParams.get('room')==='main')url.searchParams.delete('room');
  if(url.searchParams.get('profile')==='curated')url.searchParams.delete('profile');
  if(url.search.length>MAX_LINK)throw new Error('This ensemble is too large for a share link');
  return url;
}
export function formatElapsed(value=0) {
  const seconds=Math.floor(Math.max(0,value)),hours=Math.floor(seconds/3600),minutes=Math.floor(seconds/60)%60;
  return `${hours?`${hours}:`:''}${String(hours?minutes:Math.floor(seconds/60)).padStart(2,'0')}:${String(seconds%60).padStart(2,'0')}`;
}
export function formatBeatPosition(value=0) {
  return `${Math.max(0,Math.trunc(value))} ${value===1?'beat':'beats'}`;
}
