import {frozenJson,identifier,knownFields} from './planning-data.js';
import {advanceCursor,cursorBeat,validateCursorCurves} from './ensemble-cursor.js';
import {tempoInRange} from './tempo-range.js';
import {heldAt,validateCursorHolds} from './clock-hold.js';
import {validateCursorRubato} from './rubato-clocks.js';

const MAX_STEPS=100000;
const freeze=value=>frozenJson(value,{bytes:8192,items:2048}).data;
const finite=(value,label)=>{if(!Number.isFinite(value))throw new TypeError(`Invalid ${label}`);return value;};

export function inputTempoCommit(value) {
  if(value==null)return null;
  knownFields(value,['version','decisionId','revision','startBar','endBar','effectiveAt','completesAt','referencePulse','referenceEpoch'],'input tempo commitment');
  identifier(value.decisionId);identifier(value.referenceEpoch);const p=value.referencePulse;
  if(value.version!==1||!['revision','startBar','endBar'].every(key=>Number.isSafeInteger(value[key])&&value[key]>=0)||
    value.revision<1||value.endBar<=value.startBar||value.endBar-value.startBar>128||
    !Number.isFinite(value.effectiveAt)||!Number.isFinite(value.completesAt)||value.completesAt<=value.effectiveAt||
    p?.numerator!==1||!Number.isInteger(p.denominator)||p.denominator<1||p.denominator>4096)
    throw new TypeError('Invalid input tempo commitment');
  return freeze(value);
}

// An immutable forecast of an accepted conductor cursor, using exactly the
// same piecewise-constant subdivision periods as live advancement. The anchor
// tick is part of its identity: later anchors are new snapshots, not rewrites.
// This is the ordinary ensemble's metrical pulse coordinate, not a claim that
// its beats are quarter notes or that it is the scheduled-clip timeline.
export class EnsembleTempoMap {
  constructor({sessionId,cursor}) {
    this.sessionId=identifier(sessionId);this.cursor=freeze(cursor);
    const s=this.cursor;
    if(s.version!==1||!['tick','bar','tickInBar','beat','revision'].every(key=>Number.isSafeInteger(s[key])&&s[key]>=0)||
      !Number.isFinite(s.at)||!Number.isFinite(s.bpm)||!tempoInRange(s.bpm,s.meter)||
      !Number.isInteger(s.meter?.numerator)||s.meter.numerator<1||s.meter.numerator>4096||
      !Number.isInteger(s.meter.denominator)||s.meter.denominator<1||s.meter.denominator>4096||
      !Number.isInteger(s.meter.subdivision)||s.meter.subdivision<1||s.meter.subdivision>96||
      s.meter.pulsesPerBar!==s.meter.numerator*s.meter.subdivision||s.tickInBar>=s.meter.pulsesPerBar||s.revision>=Number.MAX_SAFE_INTEGER)
      throw new TypeError('Invalid ensemble timing anchor');
    validateCursorCurves(s);validateCursorHolds(s);validateCursorRubato(s);
    inputTempoCommit(s.inputTempoCommit);
    this.epoch=identifier(s.epoch);this.revision=s.revision+1;
    this.id=`ensemble:${s.revision}:${s.tick}`;this.originBeat=cursorBeat(s);this.originReference=s.at;
    Object.freeze(this);
  }
  reference(){return freeze({kind:'ensemble-cursor',sessionId:this.sessionId,epoch:this.epoch,id:this.id,revision:this.revision,anchorTick:this.cursor.tick});}
  snapshot(){return freeze({version:1,kind:'ensemble-cursor',sessionId:this.sessionId,cursor:this.cursor});}
  search(predicate) {
    const state=structuredClone(this.cursor);
    for(let count=0;count<MAX_STEPS;count++){
      if(predicate(state))return state;
      advanceCursor(state);
    }
    throw new RangeError('Ensemble forecast exceeds the pulse budget');
  }
  barAfter(reference,{minimumBar=this.cursor.bar}={}) {
    finite(reference,'future reference time');
    if(!Number.isSafeInteger(minimumBar)||minimumBar<this.cursor.bar)throw new TypeError('Invalid future bar');
    return freeze(this.search(state=>state.at>=reference&&state.tickInBar===0&&state.bar>=minimumBar));
  }
  atBeat(beat) {
    finite(beat,'future pulse position');
    if(beat<this.originBeat)throw new RangeError('Pulse precedes the retained ensemble anchor');
    const state=structuredClone(this.cursor);
    for(let count=0;count<MAX_STEPS;count++){
      const current=cursorBeat(state);
      // A rational subdivision (e.g. thirds) may round on either side of the
      // same tick. Resolve within floating-point precision to the tick itself.
      const tolerance=4*Number.EPSILON*Math.max(1,Math.abs(beat),Math.abs(current));
      if(beat<=current+tolerance)return freeze(state);
      // Inside a pulse: after its attack, after a hold that begins there (clock-hold.js; a cued one's bound). Inside a
      // rubato span a pulse's length is the span's (rubato-clocks.js), found by advancing a copy over it.
      const begins=heldAt(state)?.begins,hold=begins?(begins.cued?begins.bound:begins.seconds):0;
      if(beat<current+1/state.meter.subdivision-tolerance){
        const pulse=state.rubato||state.rubatos?.length?(advanceCursor(structuredClone(state)).at-state.at-hold)*state.meter.subdivision:60/state.bpm;
        return freeze({...state,at:state.at+hold+(beat-current)*pulse});
      }
      advanceCursor(state);
    }
    throw new RangeError('Ensemble forecast exceeds the pulse budget');
  }
  referenceAtBeat(beat){return this.atBeat(beat).at;}
}

// Stage the existing linear-BPM ramp without publishing it or advancing a
// live clock. Both relay and standalone conductors use this acceptance rule.
export function prepareInputTempoRamp({sessionId,cursor,boundary,bpm,transitionBeats,maxBpmPerSecond,decisionId,now}) {
  identifier(decisionId);
  if(!tempoInRange(bpm,boundary?.meter??cursor?.meter)||!Number.isInteger(transitionBeats)||transitionBeats<1||transitionBeats>128||
    !Number.isFinite(maxBpmPerSecond)||maxBpmPerSecond<=0||maxBpmPerSecond>30)throw new Error('Invalid ensemble tempo bounds');
  const future=new EnsembleTempoMap({sessionId,cursor}).search(state=>state.bar>=boundary.bar);
  if(future.tick!==boundary.tick||future.tickInBar!==0||Math.abs(future.at-boundary.at)>1e-9||
    JSON.stringify(future.meter)!==JSON.stringify(boundary.meter)||!Number.isFinite(now)||future.at-now<2)
    throw new Error('Ensemble tempo missed its future acceptance boundary');
  const beatsPerBar=future.meter.numerator;
  const durationBars=Math.max(1,Math.ceil(Math.max(transitionBeats,
    Math.abs(bpm-future.bpm)*Math.max(bpm,future.bpm)/(60*maxBpmPerSecond))/beatsPerBar));
  if(durationBars*beatsPerBar>128)throw new Error('Ensemble tempo response exceeds the transition budget');
  const candidate=structuredClone(cursor);candidate.revision++;
  candidate.pendingTempo={targetBpm:bpm,durationBars,shape:'linear',targetBar:future.bar};
  const endBar=future.bar+durationBars,completesAt=new EnsembleTempoMap({sessionId,cursor:candidate})
    .barAfter(future.at,{minimumBar:endBar}).at;
  candidate.inputTempoCommit=inputTempoCommit({version:1,decisionId,revision:candidate.revision,startBar:future.bar,endBar,
    effectiveAt:future.at,completesAt,referencePulse:{numerator:1,denominator:future.meter.denominator},referenceEpoch:candidate.epoch});
  const acceptedMap=new EnsembleTempoMap({sessionId,cursor:candidate});
  const accepted=frozenJson({kind:'ensemble-tempo',tempoId:acceptedMap.id,tempoRevision:acceptedMap.revision,
    bpm,atBeat:future.beat,targetBar:future.bar,durationBars,durationBeats:durationBars*beatsPerBar,
    effectiveAt:future.at,completesAt,referencePulse:candidate.inputTempoCommit.referencePulse,
    timing:acceptedMap.snapshot()},{bytes:16384,items:4096}).data;
  return {candidate,accepted};
}
