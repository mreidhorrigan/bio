const normalizedAddress=value=>{
  const address=String(value||'').trim();
  if(!address)return'';
  return address.startsWith('/')?address:`/broadcast/${address}`;
};

export function normalizeRouteRule(rule={}){
  const from=normalizedAddress(rule.from),to=normalizedAddress(rule.to);
  if(!from||!to)throw new TypeError('Message route rules require from and to addresses');
  return Object.freeze({
    from,to,source:rule.source==null?null:String(rule.source),
    enabled:rule.enabled!==false,valueMode:rule.valueMode==='fixed'?'fixed':'preserve',value:rule.value
  });
}

export function routeProtocolMessage(message,rule){
  const normalized=normalizeRouteRule(rule);
  if(!normalized.enabled||String(message?.address||'')!==normalized.from)return null;
  if(normalized.source!==null&&String(message?.source??'')!==normalized.source)return null;
  const args=normalized.valueMode==='fixed'
    ?(Array.isArray(normalized.value)?normalized.value.slice():[normalized.value])
    :(Array.isArray(message.args)?message.args.slice():[]);
  return{address:normalized.to,args};
}

export class MessageRouter {
  constructor(rules=[]){this.setRules(rules)}
  setRules(rules=[]){this.rules=rules.map(normalizeRouteRule);return this.rules}
  addRule(rule){const normalized=normalizeRouteRule(rule);this.rules.push(normalized);return normalized}
  clear(){this.rules.length=0}
  route(message){return this.rules.map(rule=>routeProtocolMessage(message,rule)).filter(Boolean)}
}
