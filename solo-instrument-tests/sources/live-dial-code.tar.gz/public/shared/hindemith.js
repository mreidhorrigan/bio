// Paul Hindemith's theory of harmony and melody (Unterweisung im Tonsatz, 1937; The Craft of Musical Composition,
// Book 1, 1942), as rules a bot can hear and play by.
//
// - Series 1: the twelve tones in order of their relation to a tonic (C: C G F A E E-flat A-flat D B-flat D-flat B
//   F-sharp), from the overtones. It ranks roots: how closely one chord's root relates to another's or to a centre.
// - Series 2: the intervals in order of harmonic value, from the combination tones that reinforce them: the octave, the
//   fifth, the fourth, the major third, the minor sixth, the minor third, the major sixth, the major second, the minor
//   seventh, the minor second, the major seventh, and the tritone. Melodic value runs the other way: seconds are the
//   most melodic intervals.
// - Every interval but the tritone has a root, the tone its combination tones reinforce: the lower tone of the fifth,
//   major and minor third, minor and major seventh; the upper of the fourth, minor and major sixth, major and minor
//   second.
// - A chord's root is the root of its best interval by Series 2; where that interval occurs more than once, the lowest.
//   (Chords are not inverted or built in thirds: any combination of tones has one root.)
// - Chords fall into groups by what they contain (Knod 1955 summarizes the table): A, no tritone: I without seconds or
//   sevenths, III with them; B, with a tritone: II without minor seconds or major sevenths (IIa the dominant seventh's
//   kind, a minor seventh and no major second, over its root; IIb the rest), IV with them; and the chords without a
//   definite root: V (the augmented triad, two fourths stacked) and VI (the diminished triad and seventh, the tritone
//   predominating). Each of I, III, II b and IV divides by whether the root is the bass (1) or above it (2). The
//   groups run from least tension to most: a succession of chords rises and falls through them, and that harmonic
//   fluctuation (harmonisches Gefalle) is what a composer shapes.
// - Melody: its most important tones (the high points, and the tones on the strong beats) should form a line in
//   seconds, the step progression; the two outer voices form a two-voice framework whose intervals Series 2 values.
const modulo=(value,period)=>((value%period)+period)%period;
const ic=interval=>modulo(Math.round(interval),12);

export const SERIES_ONE=Object.freeze([0,7,5,9,4,3,8,2,10,1,11,6]);
export const SERIES_TWO=Object.freeze([0,7,5,4,8,3,9,2,10,1,11,6]);
// An interval's harmonic value: its place in Series 2 (0 the octave, 11 the tritone).
const rankOne=Array.from({length:12},(_,i)=>SERIES_ONE.indexOf(i)),rankTwo=Array.from({length:12},(_,i)=>SERIES_TWO.indexOf(i));
export const harmonicRank=interval=>rankTwo[ic(interval)]??-1;
// A tone's relation to a tonic: its place in Series 1 (0 the tonic, 11 the tritone above it).
export const relationRank=(pc,tonic)=>rankOne[ic(pc-tonic)]??-1;
// The root of an interval between two pitches (low, high): the pitch, or null for the tritone.
const ROOT_BELOW=new Set([0,7,4,3,10,11]);
export function intervalRoot(low,high){
  const [a,b]=low<=high?[low,high]:[high,low],c=ic(b-a);
  return c===6?null:ROOT_BELOW.has(c)?a:b;
}

// A chord's root, by its best interval: {root (the pitch), rootPc, interval (its class), lower, upper}, or null where the
// chord has no interval but tritones (or one tone: its own root).
function rootOfTones(tones){
  if(!tones.length)return null;
  if(tones.length===1||tones.every(p=>ic(p-tones[0])===0))return {root:tones[0],rootPc:modulo(Math.round(tones[0]),12),interval:0,lower:tones[0],upper:tones[0]};
  let best=null;
  for(let i=0;i<tones.length;i++)for(let j=i+1;j<tones.length;j++){
    const c=ic(tones[j]-tones[i]);if(c===0||c===6)continue;
    const rank=rankTwo[c];
    // The best interval; among equals, the lowest lying.
    if(!best||rank<best.rank||rank===best.rank&&(tones[i]<best.lower||tones[i]===best.lower&&tones[j]<best.upper))best={rank,lower:tones[i],upper:tones[j],interval:c};
  }
  if(!best)return null;
  const root=intervalRoot(best.lower,best.upper);
  return {root,rootPc:modulo(Math.round(root),12),interval:best.interval,lower:best.lower,upper:best.upper};
}

// The groups, from least tension to most.
export const CHORD_GROUP_ORDER=Object.freeze(['I1','I2','IIa','IIb1','IIb2','III1','III2','IV1','IV2','V','VI']);
// A chord's group: {group, label, tension (0..1 by CHORD_GROUP_ORDER), root, rootPc, bass}. The intervals are those
// sounding, upper over lower, within the octave: a major second (2) and a minor seventh (10) are told apart as they
// sound, which is what tells IIa from IIb.
function groupOfTones(tones,found){
  if(!tones.length)return null;
  const classes=new Set;for(let i=0;i<tones.length;i++)for(let j=i+1;j<tones.length;j++)classes.add(ic(tones[j]-tones[i]));
  const pcs=[...new Set(tones.map(p=>modulo(Math.round(p),12)))],has=c=>classes.has(c),bass=tones[0];
  const tritone=has(6),seconds=has(1)||has(2)||has(10)||has(11),minorSeconds=has(1)||has(11);
  const setClass=pcs.length===3?pcs.map(p=>pcs.map(q=>modulo(q-p,12)).sort((a,b)=>a-b).join(',')):[];
  const rootAbove=found&&modulo(Math.round(found.root-bass),12)!==0;
  let label;
  if(!tritone){
    // Indeterminate without the tritone: the augmented triad, and two fourths stacked.
    if(pcs.length===3&&(setClass.includes('0,4,8')||isStackedFourths(tones)))label='V';
    else label=seconds?(rootAbove?'III2':'III1'):(rootAbove?'I2':'I1');
  }else{
    // Indeterminate, the tritone predominating: the diminished triad and seventh (every interval a minor third, a
    // tritone or a major sixth).
    if([...classes].every(c=>[0,3,6,9].includes(c)))label='VI';
    else if(minorSeconds)label=rootAbove?'IV2':'IV1';
    else if(has(10)&&!has(2)&&!rootAbove)label='IIa';
    else label=rootAbove?'IIb2':'IIb1';
  }
  const indeterminate=label==='V'||label==='VI';
  return {group:label.replace(/[0-9ab]+$/,''),label,tension:CHORD_GROUP_ORDER.indexOf(label)/(CHORD_GROUP_ORDER.length-1),
    root:indeterminate?null:found?.root??null,rootPc:indeterminate?null:found?.rootPc??null,bass};
}
function isStackedFourths(tones){
  const distinct=[...new Set(tones.map(p=>Math.round(p)))];
  if(distinct.length!==3)return false;
  const pcs=distinct.map(p=>modulo(p,12)),sorted=[...new Set(pcs)];
  if(sorted.length!==3)return false;
  // Pitch classes x, x + 5, x + 10: fourths stacked, in some voicing.
  return sorted.some(x=>[5,10].every(step=>sorted.includes(modulo(x+step,12))));
}
// A finer tension than the group's: within a group, a chord whose best interval is worse is tenser.
const chordAnalysisCache=new Map();
function analyseChord(pitches){
  const tones=[...pitches].filter(Number.isFinite).sort((a,b)=>a-b),key=tones.map(v=>Object.is(v,-0)?'-0':String(v)).join(',');
  if(tones.length<=64&&chordAnalysisCache.has(key))return chordAnalysisCache.get(key);
  const root=rootOfTones(tones),group=groupOfTones(tones,root),within=root?Math.max(0,rankTwo[root.interval]-1)/10:1;
  const result={root,group,tension:group?Math.min(1,group.tension+within/(CHORD_GROUP_ORDER.length-1)*.9):null};
  if(tones.length<=64){if(chordAnalysisCache.size>=256)chordAnalysisCache.delete(chordAnalysisCache.keys().next().value);chordAnalysisCache.set(key,result);}
  return result;
}
export function chordRoot(pitches){const result=analyseChord(pitches).root;return result?{...result}:null;}
export function chordGroup(pitches){const result=analyseChord(pitches).group;return result?{...result}:null;}
export function chordTension(pitches){return analyseChord(pitches).tension;}

// How closely a succession of roots relates, by Series 1: each root to the one before it, 1 for the fifth below or
// above (the closest after the unison), falling to 0 for the tritone. The degree progression's strength.
export function rootRelation(from,to){
  const rank=Math.min(relationRank(to,from),relationRank(from,to));
  return rank<=0?1:1-(rank-1)/10;
}
export function degreeProgression(roots){
  const values=[];for(let i=1;i<roots.length;i++)if(Number.isFinite(roots[i-1])&&Number.isFinite(roots[i])&&modulo(roots[i]-roots[i-1],12))values.push(rootRelation(roots[i-1],roots[i]));
  return {relations:values,mean:values.length?values.reduce((a,b)=>a+b,0)/values.length:null};
}

// A melody's step progression: its structural tones (the tones on strong beats, or the local high points where no beats
// are given) and whether each moves to the next by a second. notes: [{pitch, strong}] or pitches.
export function stepProgression(notes){
  const list=notes.map(note=>typeof note==='number'?{pitch:note}:note).filter(note=>Number.isFinite(note.pitch));
  const marked=list.some(note=>note.strong!==undefined);
  const tones=marked?list.filter(note=>note.strong).map(note=>note.pitch)
    :list.filter((note,i)=>(i===0||note.pitch>list[i-1].pitch)&&(i===list.length-1||note.pitch>=list[i+1].pitch)).map(note=>note.pitch);
  const moves=tones.slice(1).map((pitch,i)=>pitch-tones[i]),seconds=moves.filter(move=>Math.abs(move)>=.5&&Math.abs(move)<=2.5).length;
  return {tones,moves,seconds,stepwise:moves.length?seconds/moves.length:null};
}
// The melodic value of a step: seconds the most melodic, then thirds, fourths and fifths, larger leaps least; a repeated
// tone is not melodic motion. 0 (best) to 1.
export function melodicCost(step){
  const size=Math.abs(step);
  if(size<.5)return .6;
  if(size<=2.5)return 0;
  if(size<=4.5)return .25;
  if(size<=5.5)return .45;
  if(size<=7.5)return .6;
  if(size<=9.5)return .85;
  return 1;
}

// Harmonic fluctuation: a phrase's tension, from its position (0..1). It rises from `low` to `high` at `peak` and falls
// back to `low` at the cadence, the arc Hindemith asks a phrase's chords to trace.
export function fluctuationTarget(position,{low=0,high=.6,peak=.65}={}){
  const x=Math.max(0,Math.min(1,position));
  const rise=x<=peak?x/peak:(1-x)/(1-peak);
  return low+(high-low)*Math.sin(rise*Math.PI/2);
}
// How a succession of chords fluctuates: its tensions, and the mean change from chord to chord.
export function harmonicFluctuation(chords){
  const tensions=chords.map(chord=>chordTension(chord));
  const changes=tensions.slice(1).map((t,i)=>t!==null&&tensions[i]!==null?Math.abs(t-tensions[i]):null).filter(v=>v!==null);
  return {tensions,meanChange:changes.length?changes.reduce((a,b)=>a+b,0)/changes.length:null};
}
