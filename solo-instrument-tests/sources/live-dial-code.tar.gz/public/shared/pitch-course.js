// A note's pitch over its length, summarized: where it settles, how long it holds, how far it moves, how it swings,
// and a glide from the note before. The course may be heard (render/node/pitch-profile.mjs reads it from a patch played
// and tracked by YIN) or predicted (public/shared/surge-patch.js reads it from a patch's own parameters); the same
// summary of both is what lets one be checked against the other.
//
// A course is frames {t (seconds from the note-on), cents (against the reference, null where the pitch is unclear),
// clarity, levelDb, partialCents, prominenceDb, lowestCents}; a predicted course has what its parameters say and nulls
// for the rest.

// ---- Definitions -----------------------------------------------------------------------------------------------
export const A4=Object.freeze({hz:440,note:69});
export const SEMITONES_PER_OCTAVE=12;
export const CENTS_PER_SEMITONE=100;
export const CENTS_PER_OCTAVE=SEMITONES_PER_OCTAVE*CENTS_PER_SEMITONE;
// The places a figure is kept to: cents whole, seconds to the millisecond, a hold or a release to the centisecond,
// a clarity to two.
export const FIGURE_PLACES=Object.freeze({cents:0,seconds:3,holdSeconds:2,clarity:2});

// ---- Choices ---------------------------------------------------------------------------------------------------
// A swing (a vibrato) and a resonance's movement are measured between these quantiles of their values, so a stray
// frame does not set them.
export const SWING_QUANTILES=Object.freeze([.1,.9]);
export const PITCH_COURSE=Object.freeze({
  hopSeconds:.02,               // a course's frames every 20 ms once past its attack (a slide or a sweep is slower)
  clarity:.5,                   // a frame this periodic or more has a pitch
  settleSeconds:.1,             // a note has settled where its smoothed pitch then stays within holdCents this long
  holdCents:50,                 // within a quarter tone: the same pitch
  lastingSeconds:.05,           // a departure counts when it lasts 50 ms
  smoothingSeconds:.25,         // a centred moving median this long takes a vibrato of 4 Hz or faster away
  keytrackCents:50,
  prominenceDb:6,               // the loudest partial counts as a resonance where it stands this far over the next
  secondNoteCents:100,          // a resonance on a pitch class a semitone or more from the note's own is another note,
                                // heard as one where it lasts lastingSeconds and moves (secondNote): ours
  whistleDb:20,                 // ... or, held still, where it stands this far over the next: a whistle of its own (ours)
  attackDb:3,
  quietDb:30,                   // a frame this far under the note's loudest is not judged: a note fading is not moving
  settleFrames:3,               // and the stretch it settles over holds this many clear frames at least
});

export const midiHz=note=>A4.hz*2**((note-A4.note)/SEMITONES_PER_OCTAVE);
// A departure as the harmony hears it: its distance from the nearest octave (a note an octave up keeps its name).
export const pitchClassCents=cents=>cents-CENTS_PER_OCTAVE*Math.round(cents/CENTS_PER_OCTAVE);
export const median=values=>{if(!values.length)return null;const sorted=[...values].sort((a,b)=>a-b),middle=sorted.length>>1;return sorted.length&1?sorted[middle]:(sorted[middle-1]+sorted[middle])/2};
export const quantile=(values,q)=>{if(!values.length)return null;const sorted=[...values].sort((a,b)=>a-b);return sorted[Math.min(sorted.length-1,Math.max(0,Math.round(q*(sorted.length-1))))]};
export const round=(value,places=0)=>value===null||value===undefined||!Number.isFinite(value)?null:Number(value.toFixed(places));

// A centred moving median of the clear frames' pitch, over settings.smoothingSeconds.
export function smoothed(frames,settings){
  const half=settings.smoothingSeconds/2;
  return frames.map(frame=>frame.cents===null?null:median(frames.filter(other=>other.cents!==null&&Math.abs(other.t-frame.t)<=half).map(other=>other.cents)));
}

// A second note heard in one played (the user, 26 September 2026: "cases where each note is actually multiple, either
// simultaneous or sequential, in the playing synth"): the loudest partial standing out as a resonance (prominenceDb
// over the next) on a pitch class secondNoteCents or more from the note's own (`reference`, the note's sounding cents),
// for lastingSeconds or longer -- where the resonance moves. Plucks/ACME's filter envelope sweeps its resonance down
// through the harmonics, and for a quarter of a second after the attack its loudest partial is the note's sixth
// harmonic, a fifth above the note's pitch class, before it settles on the fourth: heard as a second note gliding down
// to the first (the user heard "a glide down to a lower note"). A resonance held still on one harmonic all through the
// note is its colour, a formant, fused with the note as a vowel is, and not another note (ours: a partial is heard out
// when it changes, the others staying -- Bregman's old-plus-new heuristic); unless it stands whistleDb over the next,
// a whistle heard even held (a filter at the edge of oscillating). So a stretch counts where the note's standing-out
// partial moves (two or more partials stand out in turn, each lastingSeconds) or whistles. Judged once the note has
// settled (notePitch passes its frames from there): while its pitch slides, its partials move under a still formant and
// are heard as the slide (Leads/Kilkenny's octave scoop, heard as a glide the user liked). Returns the longest such
// stretch, {cents (its pitch class over the note, to the nearest octave), at, seconds}, or null.
export function secondNote(frames,reference,settings=PITCH_COURSE){
  // The stretches in which one partial stands out, in turn: a new stretch where the partial is another (holdCents).
  const runs=[];let run=null;
  const close=end=>{if(run){run.seconds=end-run.first;runs.push(run);run=null}};
  for(const frame of frames){
    const standing=frame.partialCents!==null&&frame.partialCents!==undefined&&frame.prominenceDb>=settings.prominenceDb;
    if(!standing){close(frame.t);continue}
    if(run&&Math.abs(frame.partialCents-median(run.partials))<=settings.holdCents){run.partials.push(frame.partialCents);run.loudest=Math.max(run.loudest,frame.prominenceDb)}
    else{close(frame.t);run={first:frame.t,partials:[frame.partialCents],loudest:frame.prominenceDb}}
  }
  close(frames.length?frames.at(-1).t+settings.hopSeconds:0);
  const lasting=runs.filter(stretch=>stretch.seconds>=settings.lastingSeconds);
  const moves=new Set(lasting.map(stretch=>Math.round(median(stretch.partials)/settings.holdCents))).size>1;
  let best=null;
  for(const stretch of lasting){
    const cents=pitchClassCents(median(stretch.partials)-reference);
    if(Math.abs(cents)<settings.secondNoteCents||!moves&&stretch.loudest<settings.whistleDb)continue;
    if(!best||stretch.seconds>best.seconds)best={cents:round(cents),at:round(stretch.first,FIGURE_PLACES.seconds),seconds:round(stretch.seconds,FIGURE_PLACES.seconds)};
  }
  return best;
}

// A patch's second notes over its held notes (notePitch's secondNote each): the longest's pitch class and length, and how
// many of the notes had one. The audio measurement's (render/node/pitch-profile.mjs) and the prediction's
// (surge-patch.js), read alike.
export function secondNotes(held){
  const found=held.map(note=>note.secondNote).filter(Boolean),longest=found.reduce((a,b)=>b.seconds>a.seconds?b:a,found[0]??null);
  return {secondNoteCents:longest?.cents??null,secondNoteSeconds:longest?.seconds??0,secondNoteNotes:found.length};
}

// One held note's figures, from its frames (`holdEnd`: its note-off, in seconds from its onset).
export function notePitch(frames,{holdEnd,settings=PITCH_COURSE}={}){
  // The frames of the held note, those that have faded quietDb under its loudest taken as unclear: a pluck's tail, 30 dB
  // down, is too quiet in a mix to be heard moving (and too quiet for a tracker to read it truly).
  const loudest=Math.max(...frames.filter(frame=>frame.t<=holdEnd).map(frame=>frame.levelDb));
  const held=frames.filter(frame=>frame.t<=holdEnd).map(frame=>frame.levelDb<loudest-settings.quietDb?{...frame,cents:null}:frame);
  const course=smoothed(held,settings),clarity=median(frames.filter(frame=>frame.t<=holdEnd).map(frame=>frame.clarity));
  // Where it settles: the first frame from which its pitch stays within holdCents of its median for settleSeconds (a
  // glide or a scoop has not settled until it arrives); for a vibrato too wide for that, where its smoothed pitch does.
  const settle=values=>{
    for(let i=0;i<held.length;i++){
      if(values[i]===null||held.at(-1).t<held[i].t+settings.settleSeconds)continue;
      const span=values.filter((value,j)=>value!==null&&held[j].t>=held[i].t&&held[j].t<=held[i].t+settings.settleSeconds),middle=median(span);
      if(span.length>=settings.settleFrames&&span.every(value=>Math.abs(value-middle)<=settings.holdCents))return {index:i,reference:middle};
    }
    return null;
  };
  const settled=settle(held.map(frame=>frame.cents))??settle(course);
  if(!settled)return {offsetCents:null,clarity:round(clarity,FIGURE_PLACES.clarity),holdsSeconds:0};
  const {index:settledAt,reference}=settled,settleSeconds=held[settledAt].t,before=held.slice(0,settledAt).filter(frame=>frame.cents!==null);
  const onset=before.reduce((worst,frame)=>Math.abs(frame.cents-reference)>Math.abs(worst)?frame.cents-reference:worst,0);
  // By pitch class, frame by frame: a glide of an octave passes through every note between (a slide), a reading an
  // octave off passes through none.
  const pitchClassOnset=before.reduce((worst,frame)=>{const d=pitchClassCents(frame.cents-reference);return Math.abs(d)>Math.abs(worst)?d:worst},0);
  const after=held.slice(settledAt),smooth=course.slice(settledAt);
  // How long it holds: until the smoothed pitch leaves holdCents for lastingSeconds (an unclear stretch is not a
  // departure: a pitch that fades out is not one that moves). Twice: its pitch, and its pitch class (a move of an
  // octave, as a patch of octave-related parts reads now one octave and now the other, keeps the note's name).
  const hold=fold=>{
    let holdsUntil=null,movement=0,leftAt=null;
    after.forEach((frame,i)=>{
      const value=smooth[i];if(value===null)return;
      const departure=fold(value-reference);
      if(Math.abs(departure)>settings.holdCents){
        leftAt??=frame.t;
        if(frame.t-leftAt>=settings.lastingSeconds){holdsUntil??=leftAt;if(Math.abs(departure)>Math.abs(movement))movement=departure}
      }else leftAt=null;
    });
    return {holds:(holdsUntil??holdEnd)-settleSeconds,movement};
  };
  const register=hold(cents=>cents),pitchClass=hold(pitchClassCents);
  const swings=after.map((frame,i)=>frame.cents!==null&&smooth[i]!==null?pitchClassCents(frame.cents-smooth[i]):null).filter(value=>value!==null);
  // The register by the spectrum: the lowest strong partial's octave over the sustain.
  const lowest=median(after.map(frame=>frame.lowestCents).filter(value=>value!==null));
  const resonant=after.filter(frame=>frame.partialCents!==null&&frame.prominenceDb>=settings.prominenceDb).map(frame=>frame.partialCents);
  const peak=Math.max(...held.map(frame=>frame.levelDb)),attack=held.find(frame=>frame.levelDb>=peak-settings.attackDb)?.t??null;
  // Where it rests: the smoothed pitch's median over the sustain after settling (a glide's target, a vibrato's centre).
  const rests=median(smooth.filter(value=>value!==null));
  const [low,high]=SWING_QUANTILES,{clarity:clarityPlaces,seconds,holdSeconds}=FIGURE_PLACES;
  return {offsetCents:round(reference),restsCents:round(rests),clarity:round(clarity,clarityPlaces),onsetCents:round(onset),pitchClassOnsetCents:round(pitchClassOnset),
    settleSeconds:round(settleSeconds,seconds),spectrumOctaves:lowest===null?null:Math.round(lowest/CENTS_PER_OCTAVE),
    holdsSeconds:round(register.holds,holdSeconds),movementCents:round(register.movement),
    pitchClassHoldsSeconds:round(pitchClass.holds,holdSeconds),pitchClassMovementCents:round(pitchClass.movement),
    vibratoCents:round(swings.length?quantile(swings,high)-quantile(swings,low):0),
    resonanceCents:round(resonant.length?quantile(resonant,high)-quantile(resonant,low):0),attackSeconds:round(attack,seconds),
    secondNote:secondNote(after,reference,settings)};
}

// How long the second of a pair is heard between the two pitches: its clear frames more than holdCents from both
// (fromCents: where the first settled, toCents: where the second settles, both against the second's reference).
export function glideSeconds(frames,{fromCents,toCents,settings=PITCH_COURSE}){
  if(fromCents===null||toCents===null)return null;
  const low=Math.min(fromCents,toCents)+settings.holdCents,high=Math.max(fromCents,toCents)-settings.holdCents;
  let seconds=0;
  frames.forEach((frame,i)=>{if(frame.cents!==null&&frame.cents>low&&frame.cents<high)seconds+=(frames[i+1]?.t??frame.t+settings.hopSeconds)-frame.t});
  return round(seconds,FIGURE_PLACES.seconds);
}
