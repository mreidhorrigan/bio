// Nested groupings of a long bar: a large numerator heard in layers, so that no level is longer than a listener hears as
// one group, and so that its sections differ. The user, 27 September 2026, on MusebotTV season 1's high primes: "large
// numbers like that need to be played faster ... and grouped into larger sections with distinguishable differences
// between them at various layers (e.g., 37 vs 70)"; and "massively large-denominator prime meters probably actually
// REQUIRE hemiola-like grouping dissonances in order to become perceptible" (RESEARCH_BACKLOG P1, "Extreme meters, made
// perceptible").
//
// Vocabulary and judgment, as metric-home/grouping.js is: nothing here chooses for a bot. A bot asks for the sections a
// bar may have, weighs them by its own taste, and plays the one it chooses.
//
// - Sections: a bar longer than a listener hears as one group is first split into sections of unequal length, two by
//   default, so that they can be told apart (107 as 37 + 70, not 53 + 54). A section still too long is split again the
//   same way, while a sub-section may be near-even (70 as 35 + 35, 37 as 12 + 12 + 13).
// - Below the sections: each section's cells (most-X: groups of 2 and 3, grouping.js groupCounts) heard in groups of
//   groups while more than three remain (grouping.js metricTree), so the levels nest inside each section and every
//   section's downbeat is a downbeat of every level.
// - Dissonance at a level (Krebs's grouping dissonance, *Fantasy Pieces*, 1999): a span regrouped in equal groups whose
//   boundaries cut across its own groups (70 as ten 7s against 35 + 35: the join at 35 falls inside a 7), or in groups
//   of one length, the last whatever is left (the resolve rule, metric-home/resolve.js). Either way it ends where the
//   span ends, where the larger group begins: that is where it resolves.
import {groupCounts,metricTree,scansionFirst} from './grouping.js';

// ---- Choices ---------------------------------------------------------------------------------------------------
export const NESTING=Object.freeze({
  // The longest group a listener hears as one (seconds; meterform_clodbot's and grouping-choice.js's longestGroupSeconds,
  // ours, within the few seconds a measure can last: London 2012, Hearing in Time, 2nd ed.,
  // doi:10.1093/acprof:oso/9780199744374.001.0001).
  longestSeconds:5,
  // A split into sections is told apart by their lengths: the shorter section at least this share of the span and the
  // two sections' shares differing by at least `contrast` (37/107 against 70/107 differ by 0.31). Ours.
  shortestShare:.25,contrast:.12,
  // Candidate splits offered at most for one span, the best first. Ours.
  offered:12,
  // Groups under one at most (grouping.js MAX_GROUPS_UNDER_ONE, Scansion Maker's: four or more are grouped again).
  maxParts:3,
});

const positive=(value,label)=>{if(!Number.isSafeInteger(value)||value<1)throw new RangeError(`${label} must be a whole number of 1 or more`);return value};
const isPrime=n=>{if(n<2)return false;for(let d=2;d*d<=n;d++)if(n%d===0)return false;return true};
const divisors=n=>{const out=[];for(let d=2;d<n;d++)if(n%d===0)out.push(d);return out};
const sum=list=>list.reduce((a,b)=>a+b,0);

// The ways a span of `units` may be split into two or three sections, each [a, b] or [a, b, c] in units, the best
// first, [] for a span too short to split (fewer than four units).
// - 'contrast' (a bar's sections, two unless `parts` says otherwise): only splits whose shares differ by at least
//   `contrast`, the shortest at least `shortestShare` of the span; the more their lengths differ in kind (a prime
//   beside a composite that regroups in many ways, as 37 beside 70), the better, then the nearer the shorter to three
//   eighths of the span.
// - 'even' (a section's sub-sections): the evenest first, in the fewest parts (70 as 35 + 35, 37 as 12 + 12 + 13), then
//   the richest in divisors.
export function sectionSplits(units,{mode='contrast',contrast=NESTING.contrast,shortestShare=NESTING.shortestShare,offered=NESTING.offered,parts=mode==='contrast'?[2]:[2,3]}={}){
  positive(units,'A span');
  if(units<4)return [];
  if(!['contrast','even'].includes(mode))throw new RangeError('A split is by contrast or even');
  const out=[];
  const judge=sections=>{
    const shares=sections.map(size=>size/units),spread=Math.max(...shares)-Math.min(...shares);
    const richness=Math.max(...sections.map(size=>divisors(size).length));
    if(mode==='even'){out.push({sections:Object.freeze([...sections]),score:-spread*100-sections.length+Math.min(richness,8)/10});return}
    if(Math.min(...shares)<shortestShare-1e-9||spread<contrast-1e-9)return;
    // A prime section beside one of many divisors regroups against it in more ways (hemiolas at its level).
    const kinds=new Set(sections.map(size=>isPrime(size)?'prime':'composite')).size;
    out.push({sections:Object.freeze([...sections]),score:kinds*10+Math.min(richness,8)-Math.abs(Math.min(...shares)-.375)*10});
  };
  if(parts.includes(2))for(let a=1;a<units;a++)judge([a,units-a]);
  if(parts.includes(3))for(let a=1;a<units;a++)for(let b=1;a+b<units;b++)judge([a,b,units-a-b]);
  return out.sort((x,y)=>y.score-x.score||x.sections.length-y.sections.length).slice(0,offered).map(item=>item.sections);
}

// A bar's nested grouping: {units, sections: [node], levels}, where each node is {units, start, sections|cells} and
// `levels` lists, from the top, every level's spans and starts across the whole bar (the top level first, then each
// section's own metric tree, deepest last). `unitSeconds`: one unit's length. `choose(splits, depth)` picks a split
// from the candidates at each depth (default: the first, the best); `prefer`: the cells' X (grouping.js).
export function nestedGrouping(units,{unitSeconds,longestSeconds=NESTING.longestSeconds,choose=splits=>splits[0],prefer=3}={}){
  positive(units,'A bar');
  if(!(unitSeconds>0))throw new RangeError('A unit has a positive length in seconds');
  const build=(size,start,depth)=>{
    if(size*unitSeconds<=longestSeconds+1e-9||size<4){
      const cells=scansionFirst(groupCounts(size,{prefer}));
      return Object.freeze({units:size,start,cells:Object.freeze(cells)});
    }
    const splits=sectionSplits(size,{mode:depth===0?'contrast':'even'});
    const chosen=choose(splits,depth)??splits[0];
    if(!chosen)return Object.freeze({units:size,start,cells:Object.freeze(scansionFirst(groupCounts(size,{prefer})))});
    let at=start;
    const sections=chosen.map(part=>{const node=build(part,at,depth+1);at+=part;return node});
    return Object.freeze({units:size,start,sections:Object.freeze(sections)});
  };
  const root=build(units,0,0);
  return Object.freeze({units,root,levels:Object.freeze(levelsOf(root)),cells:Object.freeze(cellsOf(root))});
}
// The bar's cells in order (the groups a meter carries: their sum is the bar).
export function cellsOf(node){return node.cells?[...node.cells]:node.sections.flatMap(cellsOf)}
// Every level of a nested grouping, from the top: {spans, starts, kind} in units from the bar's downbeat. The sections'
// levels first (kind 'sections', one level per depth of sections: a section may be longer than a listener hears as one,
// and is then heard as its own sections), then the levels of the sections' metric trees (kind 'groups', each heard as
// one), deepest last, each section's levels side by side; a section with fewer levels repeats its deepest at the levels
// it lacks, so every level covers the bar.
export function levelsOf(root){
  const out=[];
  // Section depths: each depth's nodes (a leaf repeats itself below its depth).
  let frontier=[root];
  while(frontier.some(node=>node.sections)){
    frontier=frontier.flatMap(node=>node.sections??[node]);
    out.push(Object.freeze({spans:Object.freeze(frontier.map(node=>node.units)),starts:Object.freeze(frontier.map(node=>node.start)),kind:'sections'}));
  }
  // Each leaf section's metric tree, from its top down.
  const trees=frontier.map(node=>({start:node.start,levels:metricTree(node.cells).levels.slice().reverse()}));
  const depth=Math.max(...trees.map(tree=>tree.levels.length));
  for(let level=0;level<depth;level++){
    const spans=[],starts=[];
    for(const tree of trees){const chosen=tree.levels[Math.min(level,tree.levels.length-1)];
      chosen.spans.forEach((span,index)=>{spans.push(span);starts.push(tree.start+chosen.starts[index])})}
    // (A level identical to the one above adds nothing: a section whose tree is a single level.)
    const previous=out.at(-1);
    if(previous&&previous.spans.join()===spans.join())continue;
    out.push(Object.freeze({spans:Object.freeze(spans),starts:Object.freeze(starts),kind:'groups'}));
  }
  return out;
}

// Groupings that cut across a span's own groups and end where it ends, where the larger group begins: that is where
// they resolve. `span`: its units; `own`: its own groups there (the next level down, e.g. [35, 35]). Offered, each
// {groups, kind}:
// - 'hemiola': equal groups of a length that divides the span, whose boundaries miss at least one of its own (70 as ten
//   7s against 35 + 35);
// - 'resolved': groups of a length sharing no factor with the span, the last whatever is left (the resolve rule), when no
//   equal regrouping cuts across (a prime span). Where only one unit would be left (an odd span in groups of at most two,
//   as a bar of 2 s beats has them), the last group takes it: 2 + 2 + 2 + 2 + 3 across eleven.
// Group lengths from `shortest` (2 units, or more where a unit is very short) to `longest` (the longest a listener hears
// as one); each at least twice in the span.
export function crossGroupings(span,own,{longest=Infinity,shortest=2}={}){
  positive(span,'A span');
  if(sum(own)!==span)throw new RangeError('A span\'s own groups fill it');
  const boundaries=new Set;{let at=0;for(const group of own.slice(0,-1)){at+=group;boundaries.add(at)}}
  const crosses=groups=>{let at=0;const own=new Set;for(const group of groups.slice(0,-1)){at+=group;own.add(at)}return [...boundaries].some(b=>!own.has(b))};
  const out=[];
  const first=Math.max(2,shortest);
  for(const length of divisors(span)){
    if(length<first||length>longest||span/length<2)continue;
    const groups=Array(span/length).fill(length);
    if(crosses(groups))out.push(Object.freeze({groups:Object.freeze(groups),kind:'hemiola'}));
  }
  if(!out.length)for(let length=first;length<=Math.min(longest,Math.floor(span/2));length++){
    if(span%length===0)continue;
    const whole=Math.floor(span/length),rest=span-whole*length,groups=[...Array(whole).fill(length),...(rest?[rest]:[])];
    if(rest===1)continue;
    if(crosses(groups))out.push(Object.freeze({groups:Object.freeze(groups),kind:'resolved'}));
  }
  if(!out.length)for(let length=first;length<=Math.min(longest,Math.floor(span/2));length++){
    const whole=Math.floor(span/length);
    if(span-whole*length!==1||whole<2)continue;
    const groups=[...Array(whole-1).fill(length),length+1];
    if(crosses(groups))out.push(Object.freeze({groups:Object.freeze(groups),kind:'resolved'}));
  }
  return out;
}
