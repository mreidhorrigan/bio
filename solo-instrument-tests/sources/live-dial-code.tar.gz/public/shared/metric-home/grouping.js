// The groupings a span of units can have, and how they might be judged: vocabulary and judgment for the bots, which
// choose among them in performance (the user, 25 September 2026: "The point is to get the MUSEBOTS to do this. You're
// making bots that make the composition. You are not, yourself, trying to make the composition."). Nothing here picks a
// grouping for anyone: a bot asks for candidates, weighs them by its own taste and by what it hears, and plays the one
// it chooses (bots/lib/modules/grouping-choice.js).
//
// - Most-X (the user: "generalize most-threes to most-X-number"): as many groups of X units as the span holds, the rest
//   in the danceable 3s and 2s, most 3s first (a remainder of one gives one X back: 3s and 2s cannot make 1). X = 3 is
//   most-threes, as meter.cjs's defaultGrouping and Scansion Maker's default_home both are; X = 2 is most-twos (6 as
//   2+2+2); X = 5 or 7 are the longer prime cells Scansion Maker reaches by override (13 as 5+5+3 at X = 5). A bot
//   chooses its X.
// - Any order of one multiset is a candidate: 3+3+2, 3+2+3 and 2+3+3 are three different bars. A bot chooses its order.
// - Scansion Maker's ordering (~/CLAUDE_PROJECTS/SCANSION_MAKER, ALBUM_METHODS.md §1-2, meter.py compare_comps) is
//   offered as one judgment a bot may weigh: all-equal first, then smaller equal parts, fewer parts, the shortest
//   repeating period, larger parts earlier. Its first choice for any span is found directly (the smallest block that
//   repeats evenly, larger parts first within it), because Scansion Maker's own way, scoring every composition, cannot
//   reach 97, which has 288,627,200,960 compositions in 2s and 3s alone. For 2 to 40 units it matches Scansion Maker's
//   default_home exactly.
// - Layers: every part may hear one span in its own grouping, so 6/8 is 3+3 to one bot and 2+2+2 to another at once
//   (the user: "6/8 can be interpreted as 3+3 and 2+2+2 simultaneously by different parts or bots").

// ---- Choices ---------------------------------------------------------------------------------------------------
// The units a remainder is made of, most-threes: the danceable cells (Scansion Maker's twothree_compositions).
export const REMAINDER_UNITS=Object.freeze([3,2]);
// A span's groups are heard grouped again while there are more than this many of them (Scansion Maker: four or more).
export const MAX_GROUPS_UNDER_ONE=3;
// Candidates offered at most, per multiset, beyond the orders every multiset offers (Scansion Maker's first, the
// descending, the ascending, and each rotation of the first).
export const SAMPLED_ORDERS=16;

const positive=(value,label)=>{if(!Number.isSafeInteger(value)||value<1)throw new RangeError(`${label} must be a whole number of 1 or more`);return value};

// The multiset of group sizes most-X makes of `units`: {size: count}.
export function groupCounts(units,{prefer=3}={}){
  positive(units,'A span');
  if(!Number.isSafeInteger(prefer)||prefer<2)throw new RangeError('A preferred group is 2 units or more');
  if(units===1)return new Map([[1,1]]);
  let preferred=Math.floor(units/prefer),rest=units-preferred*prefer;
  if(rest===1&&preferred>0){preferred--;rest+=prefer}
  const counts=new Map,add=(size,count)=>{if(count>0)counts.set(size,(counts.get(size)??0)+count)};
  add(prefer,preferred);
  const [three,two]=REMAINDER_UNITS;
  let threes=Math.floor(rest/three),left=rest-threes*three;
  if(left===1){threes--;left+=three}
  add(three,threes);add(two,left/two);
  return counts;
}

// ---- Scansion Maker's judgment ---------------------------------------------------------------------------------
// The shortest block the grouping repeats whole: its shortest period (its length less its longest border, found by
// the prefix function in one pass) when that divides its length, else the whole grouping (by Fine and Wilf, no
// shorter divisor of the length can be a period then).
export const repeatingPeriod=groups=>{
  const border=new Array(groups.length).fill(0);
  for(let index=1,length=0;index<groups.length;index++){
    while(length>0&&groups[index]!==groups[length])length=border[length-1];
    if(groups[index]===groups[length])length++;
    border[index]=length;
  }
  const period=groups.length-(border.at(-1)??0);
  return groups.length%period===0?period:groups.length;
};
// Scansion Maker's comparison of two groupings (meter.py compare_comps): negative when `a` is preferred.
export function scansionCompare(a,b){
  const aEqual=new Set(a).size===1,bEqual=new Set(b).size===1;
  if(aEqual!==bEqual)return aEqual?-1:1;
  if(aEqual&&bEqual&&a[0]!==b[0])return a[0]<b[0]?-1:1;
  if(a.length!==b.length)return a.length<b.length?-1:1;
  const pa=repeatingPeriod(a),pb=repeatingPeriod(b);
  if(pa!==pb)return pa<pb?-1:1;
  for(let index=0;index<a.length;index++)if(a[index]!==b[index])return a[index]>b[index]?-1:1;
  return 0;
}
const gcd=(a,b)=>{while(b)[a,b]=[b,a%b];return a};
// How many times one multiset's shortest evenly repeating block repeats: the counts' greatest common divisor (every
// common divisor of the counts divides their total, so no divisor of the total need be tried).
const repeatsOf=counts=>[...counts.values()].reduce(gcd,0);
// Scansion Maker's first choice among one multiset's orders: the shortest repeating period, larger parts earlier.
export function scansionFirst(counts){
  const repeats=repeatsOf(counts),sizes=[...counts.keys()].sort((a,b)=>b-a);
  const block=sizes.flatMap(size=>Array(counts.get(size)/repeats).fill(size));
  return Array.from({length:repeats},()=>block).flat();
}

// ---- Candidates ------------------------------------------------------------------------------------------------
// The orders a bot may choose among for one multiset: Scansion Maker's first, the descending and the ascending, each
// rotation of the first, and up to SAMPLED_ORDERS shuffles drawn with the bot's own random source (random: () => [0,1)),
// each order once.
export function orders(counts,{random=null,sampled=SAMPLED_ORDERS}={}){
  const first=scansionFirst(counts),seen=new Set,out=[];
  const offer=groups=>{const key=groups.join('+');if(!seen.has(key)){seen.add(key);out.push(Object.freeze(groups))}};
  offer(first);
  offer([...first].sort((a,b)=>b-a));offer([...first].sort((a,b)=>a-b));
  // Its rotations repeat after one block (a block of sizes in descending order does not itself repeat), so each
  // distinct one is a shift within the first block.
  const block=first.length/Math.max(1,repeatsOf(counts));
  for(let shift=1;shift<block;shift++)offer([...first.slice(shift),...first.slice(0,shift)]);
  if(random)for(let draw=0;draw<sampled;draw++){
    const groups=[...first];
    for(let index=groups.length-1;index>0;index--){const pick=Math.floor(random()*(index+1));[groups[index],groups[pick]]=[groups[pick],groups[index]]}
    offer(groups);
  }
  return out;
}

// The candidates for a span: for each preference X given, its most-X multiset in each order `orders` offers.
// [{prefer, groups}].
export function candidates(units,{prefers=[2,3],random=null,sampled=SAMPLED_ORDERS}={}){
  const out=[],seen=new Set;
  for(const prefer of prefers)for(const groups of orders(groupCounts(units,{prefer}),{random,sampled})){
    const key=groups.join('+');if(seen.has(key))continue;seen.add(key);out.push(Object.freeze({prefer,groups}));
  }
  return out;
}

// ---- A grouping over bars --------------------------------------------------------------------------------------
// A span's groups cut at every bar line (every `barLength` units): each bar's part of them. A group crossing a bar line
// is two pieces, its tail opening the next bar (the user's decision 7: "groups of 8 over two bars of 13/4 are 8+8+8+2,
// the second 8 across the bar line", [8,5] then [3,8,2]).
export function groupsByBar(groups,barLength){
  positive(barLength,'A bar');
  const bars=[];let current=[],filled=0;
  for(const group of groups){
    let left=group;
    while(left>0){
      const piece=Math.min(left,barLength-filled);current.push(piece);filled+=piece;left-=piece;
      if(filled===barLength){bars.push(current);current=[];filled=0}
    }
  }
  if(current.length)bars.push(current);
  return bars;
}
// Where a pulse falls in a bar's groups, as a clock states it (meter.js clockContext): the group it is in, its beat in
// that group, and whether it begins it. `subdivision` pulses to a unit.
export function groupAt(groups,tickInBar,subdivision){
  const beat=Math.floor(tickInBar/subdivision);let start=0,group=0;
  for(let index=0,at=0;index<groups.length;at+=groups[index],index++)if(beat>=at){group=index;start=at}
  return {group,groupBeat:beat-start,groupStart:tickInBar===start*subdivision};
}

// ---- Hearing a chosen grouping ---------------------------------------------------------------------------------
// A grouping's metric tree, from its groups up: levels[0] the groups, each next level the one below heard in groups of
// most-threes of their count, while more than MAX_GROUPS_UNDER_ONE remain (Scansion Maker's super-groups, at every
// level). Each level: {spans, starts} in units.
export function metricTree(groups,{prefer=3}={}){
  const levels=[],withStarts=list=>{let at=0;return {spans:list,starts:list.map(span=>{const start=at;at+=span;return start})}};
  let spans=[...groups];levels.push(withStarts(spans));
  while(spans.length>MAX_GROUPS_UNDER_ONE){
    const counts=scansionFirst(groupCounts(spans.length,{prefer}));
    let index=0;
    spans=counts.map(count=>{const sum=spans.slice(index,index+count).reduce((a,b)=>a+b,0);index+=count;return sum});
    levels.push(withStarts(spans));
  }
  return {units:groups.reduce((a,b)=>a+b,0),levels};
}
// Each unit's metric weight in a grouping: how many levels it begins a group at, the downbeat above them all.
export function metricWeights(groups,options){
  const {units,levels}=metricTree(groups,options),weights=new Array(units).fill(0);
  for(const level of levels)for(const start of level.starts)weights[start]++;
  weights[0]=levels.length+1;
  return weights;
}

// ---- A bar in parts of its own ----------------------------------------------------------------------------------
// The user, 28 September 2026: "We need the ability to have multiple subdivisions of the same meter playing in sequence
// or sometimes against each other; for example, 9/8 as 3x3 and 9/8 as 5+4 simultaneous and/or in sequence", and "The
// 9/8 request is just an example. The same applies for any meter; 25/8, 107/16, et cetera." A regrouping splits the bar
// (or each of a long bar's sections) into a number of near-equal parts, and hears each part in its own cells, so that
// the parts are a level above the cells: 9 as 5+4 is cells 3+2+2+2 under the parts 5 and 4, as 9 as 3+3+3 is cells 3+3+3
// with no level between them and the bar. Nothing here chooses one: meterform_clodbot lays them in sequence, and each
// part may hear its own against the others' (bots/lib/modules/grouping-choice.js).

// `units` in `parts` parts as nearly equal as the units allow (sizes ⌊units/parts⌋ and ⌈units/parts⌉), the longer ones
// spread among the shorter as evenly as a Euclidean rhythm spreads its onsets, a longer one first: 9 in two is 5+4, in
// three 3+3+3; 25 in four is 7+6+6+6; 107 in five is 22+21+22+21+21.
export function evenParts(units,parts){
  positive(units,'A span');positive(parts,'A number of parts');
  if(parts>units)throw new RangeError(`${units} units cannot make ${parts} parts`);
  const small=Math.floor(units/parts),longer=units-small*parts,sizes=new Array(parts).fill(small);
  for(let index=0;index<longer;index++)sizes[Math.floor(index*parts/longer)]++;
  return sizes;
}
// The distinct rotations of a list of sizes, each once, the list itself first.
export function rotations(sizes){
  const seen=new Set,out=[];
  for(let shift=0;shift<sizes.length;shift++){const turned=[...sizes.slice(shift),...sizes.slice(0,shift)],key=turned.join('+');if(!seen.has(key)){seen.add(key);out.push(turned)}}
  return out;
}
// A regrouping: each of the bar's top-level sections (`sections`: their sizes, [units] for a bar without sections) in
// `parts` near-equal parts (their sizes turned by `rotation`), each part in its own cells (most-X of it in Scansion
// Maker's first order, X `prefer`: 5 as 3+2, 4 as 2+2, 7 as 3+2+2, 27 as nine 3s), and, where a part holds more cells
// than one level carries (MAX_GROUPS_UNDER_ONE), its cells' own groups under it (metricTree). -> {groups: the cells,
// levels: from the top, the sections (where more than one), the parts, and the parts' groups where any part has them,
// each level summing to the bar and nesting in the one above (as meter.sections: metric-home/sections.js), parts: the
// parts' sizes}.
export function regrouping(sections,parts,{rotation=0,prefer=3}={}){
  const tops=(Array.isArray(sections)?sections:[sections]).map(size=>positive(size,'A section'));
  const partSizes=tops.flatMap(size=>{const even=evenParts(size,Math.min(parts,size)),shift=((rotation%even.length)+even.length)%even.length;return [...even.slice(shift),...even.slice(0,shift)]});
  const cellsOf=size=>scansionFirst(groupCounts(size,{prefer}));
  const groups=partSizes.flatMap(cellsOf);
  // Each part's cells heard in groups where they are more than one level carries: the part's level of groups under it.
  const under=partSizes.flatMap(size=>{const tree=metricTree(cellsOf(size),{prefer});return tree.levels.length>1?[...tree.levels.at(-1).spans]:[size]});
  const levels=[...(tops.length>1?[tops]:[]),partSizes,...(under.length>partSizes.length&&under.length<groups.length?[under]:[])].filter(level=>level.length>1);
  return {groups,levels,parts:partSizes};
}
// The regroupings a bar offers: each of its top-level sections in 2 parts or more, every part at least `least` units and
// its cells at least two (a part of one cell is a group, not a part), at most `most` parts to a section; each distinct
// rotation of the parts once. A bar without sections offers its cells regrouped too, with no level above them (its
// most-threes and most-twos in their orders: 9 as 3+3+3 where the bar is 5+4, 2+2+2+3 where it is 3+3+3). One that is
// the bar's own grouping (`home`: its cells) is left out. [{groups, levels, parts, count (parts to a section, 0 for
// cells alone), rotation}].
export function regroupings(sections,{least=4,most=8,prefer=3,home=null,cells=true}={}){
  const tops=(Array.isArray(sections)?sections:[sections]).map(size=>positive(size,'A section'));
  const shortest=Math.min(...tops),homeKey=home?home.join('+'):null,seen=new Set,out=[];
  // (The bar's own grouping as it is heard: its cells, and its cells' groups above them where there are any.)
  const homeLevels=home?JSON.stringify([...(tops.length>1?[tops]:[]),...metricTree(home,{prefer}).levels.slice(1).map(level=>level.spans).filter(level=>level.length>1)]):null;
  const isHome=option=>option.groups.join('+')===homeKey&&(!option.levels.length||JSON.stringify(option.levels)===homeLevels);
  if(cells&&tops.length===1)for(const {groups} of candidates(tops[0],{prefers:[3,2]})){
    const key=`${groups.join('+')}|[]`;
    if(seen.has(key)||groups.join('+')===homeKey||groups.length<2)continue;
    seen.add(key);out.push(Object.freeze({groups:[...groups],levels:[],parts:[...groups],count:0,rotation:0}));
  }
  for(let count=2;count<=most&&count*Math.max(2,least)<=shortest;count++){
    const turns=rotations(evenParts(shortest,count)).length;
    for(let rotation=0;rotation<turns;rotation++){
      const option=regrouping(tops,count,{rotation,prefer}),key=`${option.groups.join('+')}|${JSON.stringify(option.levels)}`;
      if(seen.has(key)||isHome(option))continue;
      seen.add(key);out.push(Object.freeze({...option,count,rotation}));
    }
  }
  return out;
}
