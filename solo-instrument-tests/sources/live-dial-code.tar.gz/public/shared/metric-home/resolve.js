// An excursion resolved to its home (research/HOME_TIME_SIGNATURE_DESIGN.md). The user, 25 September 2026: "when a
// change wouldn't resolve, it should be used anyway, and the final bar -- a different length -- functions as the
// resolution. This is already how hemiolas work in popular music, and recently I've begun hearing superpositions of 5
// working similarly. So, don't 'repair' or 'omit' -- 'resolve'."
//
// Bars proposed over a home -- one bar repeated, or a pattern of them, at a modulation ratio -- run as proposed until
// the next home downbeat (or a given number of cycles on), and the last bar takes whatever length is left: the
// resolution. It stays in the excursion's tempo, as a hemiola's last group does; the home's tempo returns on the
// downbeat. A remainder of one unit is no bar: it joins the bar before it. So:
//
//   25/8 re-barred in 2/4:        2/4 2/4 2/4 2/4 2/4 5/8   (24 eighths leave one; 2/4 + 1/8 is 5/8: the user's example)
//   8/8 in groups of 3/8:         3/8 3/8 2/8               (the tresillo, 3+3+2)
//   16/16 in 5/16 (a 5 laid over): 5/16 5/16 6/16          (15 sixteenths leave one)
//   17/16 in 5/16:                5/16 5/16 5/16 2/16
//   25/8 in 2/4 at half time:     2/4 2/4 2/4 9/16         (each at ratio 2; three bars are 24 eighths of home time)
//
// A remainder is counted and written in the finest note value present, the home's or the excursion's (a leftover eighth
// in 25/8 is one note, too few for a bar, however the excursion is written), or finer where it must be; one that no
// power of two can write in the excursion's tempo (a modulation's triplets against the home's duplets) is written at
// home tempo, and one that none can write at all is flagged.
import {Rational} from '../../transcript/rational.js';
import {home,barLength} from './home-time.js';

// ---- Choices ---------------------------------------------------------------------------------------------------
export const RESOLUTION=Object.freeze({
  minBarUnits:2,          // a bar holds at least this many of its own notes; a remainder of fewer joins the bar before
  finestDenominator:128,  // the finest note a remainder is written in
  maxBars:4096,           // an excursion's bars, at most
});

const positive=(value,label)=>{const r=Rational.of(value);if(!(r.sign()>0))throw new RangeError(`${label} must be positive`);return r};

// A span of home time written as one bar at a ratio: in `denominator`'s notes if it is a whole number of them, else in
// the finest power of two that makes it one; null when none up to RESOLUTION.finestDenominator does.
export function writeBar(homeTime,{ratio=1,denominator}){
  const notated=Rational.of(homeTime).div(Rational.of(ratio));
  for(let d=denominator;d<=Math.max(denominator,RESOLUTION.finestDenominator);d*=2){
    const count=notated.mul(d);
    if(count.isInteger())return {numerator:count.n,denominator:d,ratio:Rational.of(ratio)};
  }
  return null;
}

// options: bars (the pattern: [{numerator, denominator}]), ratio (the excursion's modulation, 1 by default), at (the
// home time it begins at, whole notes from the piece's start), cycles (the home downbeats it runs to: 1, the next).
// Returns {bars: [{numerator, denominator, ratio, resolution?, joined?, homeTempo?}], resolution: {kind: 'exact'|'own'|
// 'joined', remainder}, from, to}.
export function resolveExcursion(homeMeter,{bars,ratio=1,at=Rational.ZERO,cycles=1}){
  const meter=home(homeMeter),start=Rational.of(at),modulation=positive(ratio,'A ratio');
  if(!Array.isArray(bars)||!bars.length)throw new TypeError('An excursion proposes one bar at least');
  if(!Number.isSafeInteger(cycles)||cycles<1)throw new RangeError('An excursion resolves one cycle on at least');
  const pattern=bars.map(bar=>({numerator:bar.numerator,denominator:bar.denominator}));
  pattern.forEach(bar=>barLength(bar));
  // The home downbeat it resolves to: the end of the cycle it begins in, and `cycles` - 1 more.
  const [cycle,phase]=start.divmod(meter.length),to=meter.length.mul(cycle+cycles-(phase.isZero()?0:0)+(phase.isZero()?0:0));
  const target=phase.isZero()?start.add(meter.length.mul(cycles)):to;
  let remaining=target.sub(start);
  const out=[];
  for(let index=0;out.length<RESOLUTION.maxBars;index++){
    const bar=pattern[index%pattern.length],length=barLength({...bar,ratio:modulation});
    if(length.gt(remaining))break;
    out.push({...bar,ratio:modulation});remaining=remaining.sub(length);
    if(remaining.isZero())break;
  }
  if(out.length>=RESOLUTION.maxBars)throw new RangeError('An excursion of more bars than RESOLUTION.maxBars');
  if(remaining.isZero())return freeze({bars:out,resolution:{kind:'exact',remainder:remaining},from:start,to:target});
  // The remainder, written as a bar of its own where it is one; else joined to the bar before it.
  const next=pattern[out.length%pattern.length],finest=Math.max(meter.denominator,next.denominator);
  const own=writeBar(remaining,{ratio:modulation,denominator:finest});
  if(own&&own.numerator>=RESOLUTION.minBarUnits||!out.length){
    const written=own??writeBar(remaining,{ratio:1,denominator:finest})??{numerator:remaining.n,denominator:remaining.d,ratio:Rational.ONE,unwritable:true};
    out.push({...written,resolution:true,...(own?{}:{homeTempo:true})});
    return freeze({bars:out,resolution:{kind:'own',remainder:remaining},from:start,to:target});
  }
  const last=out.pop(),joined=barLength(last).add(remaining),joinedFinest=Math.max(meter.denominator,last.denominator);
  const written=writeBar(joined,{ratio:last.ratio,denominator:joinedFinest})??{...(writeBar(joined,{ratio:1,denominator:joinedFinest})??{numerator:joined.n,denominator:joined.d,ratio:Rational.ONE,unwritable:true}),homeTempo:true};
  out.push({...written,resolution:true,joined:true});
  return freeze({bars:out,resolution:{kind:'joined',remainder:remaining},from:start,to:target});
}

const freeze=result=>Object.freeze({...result,bars:Object.freeze(result.bars.map(bar=>Object.freeze(bar))),resolution:Object.freeze(result.resolution)});

// Checked from the result's own bars, independently of how they were made: they fill exactly the home time from `from`
// to `to`, which ends on a home downbeat; and the resolution, the one bar the rule makes, holds RESOLUTION.minBarUnits of
// its notes unless it is all there was. The proposed bars are the proposer's, used as proposed, whatever their length.
export function validateExcursion(homeMeter,result){
  const meter=home(homeMeter),failures=[];
  const total=result.bars.reduce((sum,bar)=>sum.add(barLength(bar)),Rational.ZERO);
  if(!total.eq(result.to.sub(result.from)))failures.push(`the bars last ${total} whole notes, the span ${result.to.sub(result.from)}`);
  if(!result.to.divmod(meter.length)[1].isZero())failures.push(`it ends ${result.to.divmod(meter.length)[1]} into a cycle, not on a home downbeat`);
  const last=result.bars.at(-1);
  if(last?.resolution&&last.numerator<RESOLUTION.minBarUnits&&result.bars.length>1)failures.push(`the resolution holds ${last.numerator} note`);
  return {ok:!failures.length,failures};
}
