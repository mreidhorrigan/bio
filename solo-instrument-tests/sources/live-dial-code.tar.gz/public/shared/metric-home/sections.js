// A long bar's sections as the clock hears them (RESEARCH_BACKLOG P1, "Extreme meters, made perceptible"). The meter
// carries the form's sections (meter.sections: their lengths in the meter's notes, level by level from the top, each
// level summing to the numerator and nesting in the one above, as [[37, 70], [37, 35, 35]]; a single level may be given
// as [37, 70]; meterform_clodbot chooses them, metric-home/nested.js offers them) and each top-level section's dynamic
// (meter.sectionDynamics). A note is accented by how many levels begin a group where it falls, the sections' levels and
// each deepest section's own groups of groups, and played at its section's dynamic: so that the sections are heard as
// sections, and every level as a level. A part hearing its own grouping of the bar (grouping-choice.js puts it in
// meter.groups) is weighed by it: its dissonance is heard in its accents, while the sections and their dynamics stay the
// ensemble's.
import {metricTree} from './grouping.js';

const sum=list=>list.reduce((a,b)=>a+b,0);
const startsOf=level=>{let at=0;return level.map(size=>{const start=at;at+=size;return start})};
// A meter's section levels, from the top, or null where it has none (or they are not well formed: each level at least
// two sections of whole units summing to the numerator, every boundary of a level one of the level below's).
export function sectionLevels(meter){
  const given=meter?.sections;
  if(!Array.isArray(given)||!given.length)return null;
  const levels=typeof given[0]==='number'?[given]:given;
  if(!levels.every(level=>Array.isArray(level)&&level.length>=2&&level.every(size=>Number.isSafeInteger(size)&&size>0)&&sum(level)===meter.numerator))return null;
  for(let index=1;index<levels.length;index++){const below=new Set(startsOf(levels[index]));if(!startsOf(levels[index-1]).every(start=>below.has(start)))return null}
  return levels;
}
// A bar's groups cut where its sections begin: a group across a join is two pieces, its tail opening the next section.
export function groupsBySection(groups,sections){
  const out=[];let current=[],filled=0,index=0;
  for(const group of groups){
    let left=group;
    while(left>0&&index<sections.length){
      const piece=Math.min(left,sections[index]-filled);current.push(piece);filled+=piece;left-=piece;
      if(filled===sections[index]){out.push(current);current=[];filled=0;index++}
    }
  }
  return out;
}
// Each unit's weight in the bar: 1 for every level beginning a group there (each deepest section's metric tree, from its
// groups up, and each level of sections), and the downbeat above them all. Null for a meter without sections. Cached per
// meter's shape.
const WEIGHTS=new Map,KEPT=64;
export function nestedWeights(meter){
  const levels=sectionLevels(meter);
  if(!levels)return null;
  const groups=Array.isArray(meter.groups)&&sum(meter.groups)===meter.numerator?meter.groups:[meter.numerator];
  const key=`${JSON.stringify(levels)}|${groups.join('+')}`;
  if(WEIGHTS.has(key))return WEIGHTS.get(key);
  const weights=new Array(meter.numerator).fill(0),deepest=levels.at(-1);let start=0,depth=0;
  groupsBySection(groups,deepest).forEach((pieces,index)=>{
    const tree=metricTree(pieces).levels;depth=Math.max(depth,tree.length);
    for(const level of tree)for(const at of level.starts)weights[start+at]++;
    start+=deepest[index];
  });
  for(const level of levels)for(const at of startsOf(level))weights[at]++;
  weights[0]=depth+levels.length+1;
  const frozen=Object.freeze(weights);
  WEIGHTS.set(key,frozen);while(WEIGHTS.size>KEPT)WEIGHTS.delete(WEIGHTS.keys().next().value);
  return frozen;
}
// The top-level section a unit of the bar falls in: {index, start, length, dynamic}, or null for a meter without
// sections.
export function sectionAt(meter,unit){
  const levels=sectionLevels(meter);
  if(!levels)return null;
  let start=0;
  for(const [index,length] of levels[0].entries()){
    if(unit<start+length){const dynamic=Number(meter.sectionDynamics?.[index]);return {index,start,length,dynamic:Number.isFinite(dynamic)&&dynamic>0?dynamic:1}}
    start+=length;
  }
  return null;
}
