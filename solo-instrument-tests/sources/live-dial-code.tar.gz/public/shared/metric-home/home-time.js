// Home time (research/HOME_TIME_SIGNATURE_DESIGN.md): a home time signature is a cycle of `numerator` units of
// 1/`denominator` of a whole note, the meter a piece returns to as its harmony returns to its tonic. Everything played
// over it -- bars of other meters, bars at a modulated tempo -- is measured in its time, exactly (transcript/rational.js),
// so a piece always knows which cycle it is in and how far into it.
//
// The user's quarter-note prime series (25 September 2026: "the prime series can be based on quarter notes") is homes
// of p/4, p prime below 100.
import {Rational} from '../../transcript/rational.js';

// ---- Choices ---------------------------------------------------------------------------------------------------
// The primes below this make the user's series.
export const PRIME_SERIES_BELOW=100;
// The series' unit: the quarter note.
export const PRIME_SERIES_DENOMINATOR=4;

const whole=(value,label)=>{if(!Number.isSafeInteger(value)||value<1)throw new RangeError(`${label} must be a whole number of 1 or more`);return value};

// A home, checked: {numerator, denominator, units (its unit, 1/denominator of a whole note), length (whole notes)}.
export function home({numerator,denominator}){
  whole(numerator,'A home\'s numerator');whole(denominator,'A home\'s denominator');
  return Object.freeze({numerator,denominator,unit:new Rational(1,denominator),length:new Rational(numerator,denominator)});
}

// A bar's length in home time, in whole notes: numerator/denominator, times its modulation ratio (1 at home tempo; 2
// when each of its notes lasts twice as long, half time).
export const barLength=({numerator,denominator,ratio=1})=>new Rational(whole(numerator,'A bar\'s numerator'),whole(denominator,'A bar\'s denominator')).mul(Rational.of(ratio));

// Where each bar of a sequence begins in the home's time: [{bar, cycle, phase}] (phase in whole notes into its cycle),
// and where the sequence ends. A bar beginning at phase zero begins on a home downbeat.
export function phases(homeMeter,bars,{start=Rational.ZERO}={}){
  const meter=home(homeMeter);
  let at=Rational.of(start);
  const out=bars.map(bar=>{
    const [cycle,phase]=at.divmod(meter.length);
    const entry=Object.freeze({bar,cycle,phase,downbeat:phase.isZero()});
    at=at.add(barLength(bar));
    return entry;
  });
  const [cycle,phase]=at.divmod(meter.length);
  return {bars:out,end:Object.freeze({at,cycle,phase,downbeat:phase.isZero()})};
}

// The tempo a bar is clocked at so that its notes keep home time: the clock's bpm counts the bar's notated beat
// (meter-tactus.js secondsPerTick), so from the home's rate (its units a minute) a bar of another denominator, or at a
// modulation ratio, is clocked at (homeRate / home denominator) x bar denominator / ratio. 25/8 at 200 is 2/4 at 100,
// the eighth unchanged.
export function bpmFor(bar,{homeMeter,homeRate}){
  const meter=home(homeMeter);
  return new Rational(bar.denominator).mul(Rational.of(homeRate)).div(meter.denominator).div(Rational.of(bar.ratio??1)).toNumber();
}

// The primes below `below`: the series' numerators.
export function primesBelow(below=PRIME_SERIES_BELOW){
  const out=[];
  for(let n=2;n<below;n++){let prime=true;for(let d=2;d*d<=n;d++)if(n%d===0){prime=false;break}if(prime)out.push(n)}
  return out;
}
// The series' homes: p/4 for every prime p below 100.
export const primeSeries=({below=PRIME_SERIES_BELOW,denominator=PRIME_SERIES_DENOMINATOR}={})=>primesBelow(below).map(numerator=>home({numerator,denominator}));
