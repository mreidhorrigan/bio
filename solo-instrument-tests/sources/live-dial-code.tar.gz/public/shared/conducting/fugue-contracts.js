// A fugue's decisions made by Astra's exact planning modules (Astra's handoff, research/fugue-and-coordination/
// IMPLEMENTER_HANDOFF.md): its searches -- a countersubject invertible against its subject, a plain one repaired in its
// fewest notes, its subject chosen by what it affords, its episodes' walk back to the return -- each choosing within its
// budget under the contract below, and what it finds played as found. Their certificates and the planner's law over
// their results are checked in development (test/fugue-contracts.test.mjs), never while the music is made: the owner,
// 17 October 2026, "the musical logic itself needs to function correctly in the forward direction, in which situation
// 'the show must go on'". (The checks a piece is not made by: strettoCulmination, plannerLaw; and the solvers' own
// certificate checks, each tested beside its solver.)
//
// Its contract is the counterpoint in force (counterpoint.js: a blend of rule sets at a strictness), read as the
// counterpoint's own words have it: "a rule broken is one RULE, a preference a fraction". A predicate of the contract is
// required where its weight in the rules in force reaches a whole rule, and none is where it is only a preference --
// no interval, threshold or weight of the contract's own (the owner, 3 October 2026: "don't hardcode intervals into the
// counterpoint rules"):
//   - one note at a time a voice (always), and no move wider than the rules' leapMost (always: a bound, not a weight);
//   - no parallel motion between two voices in the intervals the rules count perfect (COUNTERPOINT.consonance's, each
//     within its width) where the rules weigh parallel perfects a whole rule -- and only where its lines give it motion
//     to judge: a required predicate never exercised is UNKNOWN to Astra's profile, not a pass;
//   - on each of the meter's strong positions, only the kinds of interval (perfect, imperfect, dissonant: the
//     consonance's own) the rules weigh less than a whole rule there; likewise on the weak ones -- each position's
//     allowed intervals as a context the profile reads where the line begins (onset-held, as Astra's pullback has it);
//   - no unison (two voices within COUNTERPOINT.unison cents) where the rules weigh it a whole rule;
//   - on a weak position, a dissonance entered only by step (a move of COUNTERPOINT.step at most, from its voice's
//     note before), where the rules weigh an unprepared dissonance a whole rule -- the intervals a leap may enter
//     there, the consonant ones, a context as its allowed intervals are. Its searches had found countersubjects that
//     leapt into a weak dissonance under strict rules, which only a check of their results after had refused;
//   - no crossing where the rules weigh crossing a whole rule (no rule set does yet; the contract follows if one will).
// Pitches are semitones, exact as their decimals (any tuning); times quarters from the line's start, exact.
import {createPitchSpace,pitchFromNumber} from './pitch-spaces.js';
import {compileCounterpointProfile} from './counterpoint-profile.js';
import {prepareConstraintPullback} from './constraint-pullback.js';
import {prepareContextualPullback,solveContextualPullback,CONTEXTUAL_PULLBACK_LIMITS} from './contextual-pullback.js';
import {stepInCollection,invertedLine} from './canon-plan.js';
import {prepareDispositionFamily} from './counterpoint-dispositions.js';
import {prepareDevelopmentAffordance,auditDevelopmentAffordance,DEVELOPMENT_AFFORDANCE_LIMITS} from './development-affordance.js';
import {ladderOf,COUNTERPOINT} from './counterpoint.js';
import {prepareProtectedRepair,solveProtectedRepair,PROTECTED_REPAIR_LIMITS} from './protected-repair.js';
import {prepareSubjectCombinations,auditSubjectCombinations,checkSubjectCombinations,SUBJECT_COMBINATION_LIMITS} from './subject-combinations.js';
import {preparePositiveWarp,solvePositiveWarp,POSITIVE_WARP_LIMITS} from './positive-warp.js';
import {solveConditionedPaths,sampleConditionedPath} from './conditioned-paths.js';
import {fractionOf} from './exact-elongation.js';
import {Q,exactSpan} from './canon-core.js';
import {add,sub,compare,exactOfNumber,exactText,floatOfExact,pythonJson,sha256} from '../bounded-exact.js';
import {auditPlannerHardRules} from './planner-law-guard.js';

const SPACE=createPitchSpace({id:'musebots-semitones',kind:'semitones'});
// (Exact as text, 'n/d': the decimal a number is written as -- its own, never rounded first (Astra's review of
// orchestra-45, OA1: a certificate of a rounded value certifies another number).)
const exact=value=>exactText(exactOfNumber(Number(value)));
// (A note's onset and duration as text, its end where its start and length put it: canon-core.js exactSpan.)
const spanText=note=>{const {t,d}=exactSpan(exact,note.start,note.length);return {t:t.toString(),d:d.toString()}};
const pitchOf=value=>pitchFromNumber(SPACE,Number(value)).pitch;
// (Times added and taken away exactly, each number as written: a note's end its start and length added -- never their
// floating-point sum, 63.6 and 0.8 making 64.39999999999999, the last sound then outside every context the splice is
// given and its audit UNKNOWN -- and a fragment's notes from its first exactly: found on a day whose fugue was in 28/10.)
const exactly=value=>exactOfNumber(Number(value));
const endOf=note=>add(exactly(note.start),exactly(note.length));
const latestEnd=notes=>notes.map(endOf).reduce((a,b)=>compare(a,b)>=0?a:b);
// (Two numbers the same exactly: as their exact text.)
const same=(a,b)=>exact(a)===exact(b);
const modulo=(x,n)=>((x%n)+n)%n;
const CLOCK=Object.freeze({id:'fugue-quarters',unit:'quarter',revision:1});
// (A weight that is a whole rule: counterpoint.js's RULE, a rule broken, against its preferences' fractions.)
const WHOLE_RULE=1-1e-9,binds=weight=>Number(weight)>=WHOLE_RULE;
// The planner's own law on the lines a decision keeps (Astra's guard, planner-law-guard.js, OA3): each line against the
// others, every term its rules weigh a whole rule replayed as counterpoint.js weighs it -- its interval classes, its
// parallels between onsets, its unprepared dissonances and unisons -- beside the profile's certificate, which reads its
// own (continuous, named) law. -> 'PASS', 'FAIL' or 'UNKNOWN'.
export function plannerLaw(lines,{rules,strong}){
  // (Each line as one voice, exactly: a note held past the next one's onset by its arithmetic's last bits ends there.)
  const plain=line=>{const sorted=[...line].sort((a,b)=>a.start-b.start);return sorted.map(({pitch,start,length},k)=>{
    const next=sorted[k+1]?.start;let held=next==null?length:Math.min(length,next-start);
    while(next!=null&&held>0&&Q(exact(start)).add(exact(held)).cmp(exact(next))>0)held-=Math.max(Number.MIN_VALUE,Math.abs(held)*Number.EPSILON);
    return {pitch,start,length:held}}).filter(note=>note.length>0)};
  let unknown=false;
  for(let k=0;k<lines.length;k++){if(!lines[k]?.length)continue;
    const out=auditPlannerHardRules({line:plain(lines[k]),against:lines.filter((line,j)=>j!==k&&line?.length).map(plain),rules,strong,above:null,bindingWeight:WHOLE_RULE});
    if(out.status==='FAIL')return 'FAIL';if(out.status!=='PASS')unknown=true}
  return unknown?'UNKNOWN':'PASS';
}
// (Cents as exact text: whole, or thousandths.)
const centsText=x=>Number.isInteger(x)?String(x):`${Math.round(x*1000)}/1000`;

// The closed bands (cents within the octave) of the kinds of interval `allowed` ('perfect', 'imperfect', 'dissonant'):
// the consonance's own centres, each within its width, and the dissonant kind everything between. -> [{from, to}], or
// null where every kind is allowed.
export function intervalBands(allowed){
  const kinds=new Set(allowed);if(['perfect','imperfect','dissonant'].every(kind=>kinds.has(kind)))return null;
  const period=1200,{width}=COUNTERPOINT.consonance;
  // (Its law, named: each consonance's centres within its width, closed; the dissonant kind the open stretches between;
  // the octave half-open at its top, 1200 cents the next octave's 0 -- each endpoint as it is, no epsilon (Astra's
  // open band endpoints, b014441f). counterpoint.js's own classifier rounds to the milli-cent first: that law the
  // planner-law guard replays, beside this one.)
  const around=centres=>centres.map(c=>modulo(c,period)).flatMap(c=>{const from=c-width,to=c+width;
    return from<0?[[0,to,true,true],[period+from,period,true,false]]:to>=period?[[from,period,true,false],[0,to-period,true,true]]:[[from,to,true,true]]});
  const perfect=around(COUNTERPOINT.consonance.perfect),imperfect=around(COUNTERPOINT.consonance.imperfect);
  // (Intervals as [from, to, fromClosed, toClosed], merged where they meet: touching ends join where either holds it.)
  const merge=list=>{const out=[];for(const band of [...list].sort((a,b)=>a[0]-b[0]||(b[2]-a[2]))){const last=out.at(-1);
    if(last&&(band[0]<last[1]||band[0]===last[1]&&(last[3]||band[2]))){if(band[1]>last[1]){last[1]=band[1];last[3]=band[3]}else if(band[1]===last[1])last[3]=last[3]||band[3]}
    else out.push([...band])}return out};
  const consonant=merge([...perfect,...imperfect]),gaps=[];let at=0,closedAt=true;
  for(const [from,to,fc,tc] of consonant){if(from>at||from===at&&!fc&&!closedAt)gaps.push([at,from,closedAt,!fc]);at=to;closedAt=!tc}
  if(at<period)gaps.push([at,period,closedAt,false]);
  const bands=merge([...(kinds.has('perfect')?perfect:[]),...(kinds.has('imperfect')?imperfect:[]),...(kinds.has('dissonant')?gaps:[])]);
  return bands.filter(([from,to,fc,tc])=>from<to||fc&&tc).map(([from,to,fc,tc])=>({from:centsText(+from.toFixed(3)),to:centsText(+to.toFixed(3)),...(fc?{}:{fromClosed:false}),...(tc?{}:{toClosed:false})}));
}
// The kinds of interval allowed on a strong position and on a weak one under `rules`: those weighed less than a rule.
export function allowedKinds(rules){
  const at=place=>['perfect','imperfect','dissonant'].filter(kind=>!binds(rules?.[place]?.[kind]));
  return {strong:at('strong'),weak:at('weak')};
}
// The contract's rules for `voices` under `rules` (above): {rules: [profile rules], vertical: whether its vertical
// intervals are read from each position's context, approach: whether the intervals a leap enters are, kinds}. Every
// term of the planner's law that reaches a whole rule (counterpoint.js noteCost): one note at a time a voice, no move
// wider than its bound, no crossing, no parallel perfect interval, the intervals each position allows, no unison, and a
// dissonance on a weak position entered by step. `moving`: whether its lines move together anywhere (a parallel
// predicate then exercised); `pairs`: the pairs its pair predicates read.
export function contractOf(rules,{voices,pairs=[voices],moving=true}){
  const out=[{id:'monophony',type:'monophony',required:true},{id:'leaps',type:'melodic-bound',required:true,maxCents:centsText(+(Number(rules.leapMost)*100).toFixed(3))}];
  if(binds(rules.crossing))out.push({id:'spacing',type:'voice-spacing',required:true,pair:pairs,minCents:0,maxCents:null});
  if(binds(rules.parallelPerfect)&&moving){
    const {width}=COUNTERPOINT.consonance,perfect=[...new Set(COUNTERPOINT.consonance.perfect.map(c=>+modulo(c,1200).toFixed(3)))];
    out.push({id:'parallels',type:'parallel-classes',required:true,pair:pairs,periodCents:1200,classes:perfect.map((center,k)=>({id:`perfect${k}`,center:centsText(center),tolerance:centsText(width)}))});
  }
  const kinds=allowedKinds(rules),vertical=Boolean(intervalBands(kinds.strong)||intervalBands(kinds.weak));
  if(vertical)out.push({id:'intervals',type:'vertical-bands',required:true,scope:'all',periodCents:1200,contextKey:'intervals'});
  if(binds(rules.unison))out.push({id:'unison',type:'vertical-apart',required:true,minCents:centsText(COUNTERPOINT.unison)});
  // (A weak position's dissonance entered by leap, where that binds and its dissonance is not already refused there.)
  const approach=binds(rules.unpreparedDissonance)&&kinds.weak.includes('dissonant');
  if(approach)out.push({id:'approach',type:'approach-bands',required:true,maxCents:centsText(COUNTERPOINT.step*100),periodCents:1200,contextKey:'approach'});
  return {rules:out,vertical,approach,kinds};
}
// A position's context for the contract's predicates that read one (`key`: 'strong' or 'weak'): the intervals it
// allows, and the intervals a leap may enter -- on a weak position the consonant ones, on a strong one any (the
// planner's law asks a dissonance be entered by step on weak positions only).
export function positionData(key,{kinds,vertical,approach}){
  const all=[{from:'0',to:'1200',toClosed:false}];
  return {...(vertical?{intervals:{id:key,revision:1,bands:intervalBands(kinds[key])??all}}:{}),
    ...(approach?{approach:{id:key,revision:1,bands:key==='weak'?intervalBands(['perfect','imperfect']):all}}:{})};
}
// The positions' contexts from 0 to `length` (quarters): a cell from each onset of `times` to the next, its allowed
// intervals its position's (strong or weak, by `strong`); every interval where the contract reads none.
// (`length` a number, or an exact end: the last cell then ends exactly there.)
function cellsOf(times,length,{strong,...contract}){
  const end=typeof length==='number'?null:length,until=end?floatOfExact(end):length;
  const bounds=[...new Map([0,...times.filter(t=>t>0&&t<until)].map(t=>[exact(t),t])).values()].sort((a,b)=>a-b);
  return bounds.map((from,k)=>{const to=bounds[k+1];
    return {id:`cell${k}`,revision:1,from:exact(from),to:to!=null?exact(to):end?exactText(end):exact(until),complete:true,data:positionData(strong(from)?'strong':'weak',contract)}});
}
const ref=(id,value)=>({id,revision:1,hash:sha256(pythonJson(value))});

// One countersubject that holds in every arrangement it is promised (Astra's CF10/CF24, CFM-029: one source shared
// across every context, never redrawn per context): `subject` and `counter` ([{pitch, start, length}], quarters from
// the subject's start) -- the countersubject its planner proposed -- heard as planned (above) and moved `invertBy` of the
// collection's degrees down (below: its subject's other side, as an invertible countersubject is written to be heard),
// each against the subject, under `rules` (counterpoint.js) on the meter's `strong` positions. Each of its notes may
// take the pitch its planner gave it or the collection's pitch next to it either way within `register` (its catalogue,
// complete: its planner's choice first, searched first); the contextual solver finds one tuple passing both whole
// arrangements, and its certificate is checked again, independently, before it is kept. `budget` {maxWork}: its
// planner's. -> {status ('SAT', 'UNSAT' or 'UNKNOWN'), line (the countersubject, where SAT), changed (how many of its
// notes moved), modelHash, reason}.
// The countersubject's original pullback model, its pitches its catalogue's (`catalogue`), against the subject in one
// arrangement (`map`: a pitch of it to the pitch it sounds there), under its contract. -> {models (id, map) -> prepared
// CFM016 snapshot, catalogue}.
function countersubjectModels({subject,counter,collection,rules,strong,register}){
  const length=Math.max(...subject.map(note=>note.start+note.length),...counter.map(note=>note.start+note.length));
  const ladder=ladderOf(collection,register),near=pitch=>ladder.reduce((best,p,k)=>Math.abs(p-pitch)<Math.abs(ladder[best]-pitch)?k:best,0);
  // (Each note's catalogue: its planned pitch, then the collection's next below and above it in the register.)
  const catalogue=counter.map(note=>{const k=near(note.pitch),own=note.pitch;
    return [own,...[ladder[k-1],ladder[k+1],ladder[k]].filter(p=>p!=null&&!same(p,own))].filter((p,i,list)=>list.findIndex(q=>same(q,p))===i)});
  const moving=counter.slice(1).some(note=>subject.some((other,k)=>k>0&&Math.abs(other.start-note.start)<1e-9));
  const {rules:contract,...reads}=contractOf(rules,{voices:['subject','counter'],moving});
  const times=[...subject.map(note=>note.start),...counter.map(note=>note.start)];
  const cells=cellsOf(times,length,{strong,...reads});
  const inputs=[...new Map(catalogue.flat().map(p=>[exact(p),p])).values()];
  const model=(id,map)=>{
    const spec={id:`countersubject:${id}`,revision:1,
      source:{pitchSpace:SPACE,clockDomain:{id:'countersubject-quarters',unit:'quarter',revision:1},length:exact(length),
        variables:catalogue.map((pitches,k)=>({id:`n${k}`,complete:true,values:pitches.map((p,j)=>({id:`n${k}p${j}`,pitch:pitchOf(p)}))})),
        events:counter.map((note,k)=>({id:`c${k}`,...spanText(note),pitch:{variableId:`n${k}`}}))},
      targetPitchSpace:SPACE,
      entries:[{id:'counter',voiceId:'counter',mapId:id,timeMap:{id:'same-time',revision:1,knots:[{source:'0',target:'0'},{source:exact(length),target:exact(length)}]}}],
      maps:[{id,revision:1,contextPolicy:'onset-held',dependencies:[],rows:cells.flatMap(cell=>inputs.map(p=>({input:pitchOf(p),contextId:cell.id,values:[],result:{status:'VALUE',pitch:pitchOf(map(p))}})))}],
      environment:{id:'subject',revision:1,complete:true,events:subject.map((note,k)=>({id:`s${k}`,voiceId:'subject',...spanText(note),pitch:pitchOf(note.pitch)})),
        contexts:cells,dependencies:[{id:'collection',revision:1,data:{pitches:collection.map(Number)}}]},
      profile:compileCounterpointProfile({id:`countersubject-${id}`,version:1,pitchSpace:SPACE,clockDomain:CLOCK,voices:['subject','counter'],rules:contract})};
    const prepared=prepareConstraintPullback(spec);
    if(prepared.status!=='PASS')throw new Error(`its ${id} arrangement: ${prepared.reason}`);
    return prepared.prepared;
  };
  return {model,catalogue};
}
export function sharedCountersubject({subject,counter,invertBy,collection,rules,strong=()=>false,register,budget}){
  const below=pitch=>stepInCollection(pitch,-invertBy,collection);
  let model,catalogue;try{({model,catalogue}=countersubjectModels({subject,counter,collection,rules,strong,register}))}catch(error){return {status:'UNKNOWN',reason:String(error?.message??error)}}
  let family;
  try{
    const arrangements=[['above',p=>p],['below',below]],binding={rules,collection,invertBy};
    family=prepareContextualPullback({id:'countersubject',revision:1,
      requiredContexts:arrangements.map(([id])=>({id,revision:1,bindings:{key:ref('collection',collection),tuning:ref('tuning',collection),tempo:ref('quarters',CLOCK),style:ref('rules',binding),
        players:[{voiceId:'subject',binding:ref('subject',id)},{voiceId:'counter',binding:ref('counter',id)}]}})),
      contexts:arrangements.map(([id,map])=>({id,pullback:model(id,map)}))});
  }catch(error){return {status:'UNKNOWN',reason:String(error?.message??error)}}
  if(family.status!=='PASS')return {status:'UNKNOWN',reason:family.reason};
  // (Its planner's budget, within what the solver admits.)
  const maxWork=Math.max(1,Math.min(CONTEXTUAL_PULLBACK_LIMITS.maxWork,Math.round(Number(budget?.maxWork)||0)));
  let found;try{found=solveContextualPullback(family.prepared,{maxWork,maxSolutions:1})}catch(error){return {status:'UNKNOWN',reason:String(error?.message??error)}}
  if(found.status!=='SAT')return {status:found.status,reason:found.reason??null,modelHash:family.prepared.modelHash};
  // (What it found, played as found.)
  const solution=found.solutions[0],chosen=new Map(solution.report.assignment.map(({variableId,candidateId})=>[variableId,candidateId]));
  const line=counter.map((note,k)=>{const j=Number(String(chosen.get(`n${k}`)).split('p').at(-1));return {...note,pitch:catalogue[k][j]}});
  return {status:'SAT',line,changed:line.filter((note,k)=>!same(note.pitch,counter[k].pitch)).length,modelHash:family.prepared.modelHash};
}

// A plain countersubject held to its contract against its subject (Astra's CF20/EC12, protected-repair.js): the fewest
// of its notes moved, each to the collection's pitch next to it (its catalogue, as above), its head kept as it is (the
// notes that begin within the share of its length a fugue counts its head, `head`: fugue-plan.js FUGUE.episode.head),
// the minimum found over the whole catalogue -- none moved where it holds as proposed. Where no repair holds, or none
// is found within `budget`, as proposed, the decision said. -> {status ('PASS': as proposed, nothing moved; 'OPTIMAL' or
// 'SAT': repaired; 'UNSAT' or 'UNKNOWN': as proposed), line, changed, modelHash, reason}.
export function repairedCountersubject({subject,counter,collection,rules,strong=()=>false,register,head,budget}){
  let model,catalogue;try{({model,catalogue}=countersubjectModels({subject,counter,collection,rules,strong,register}))}catch(error){return {status:'UNKNOWN',line:counter,reason:String(error?.message??error)}}
  const length=Math.max(...counter.map(note=>note.start+note.length)),protectedNotes=counter.flatMap((note,k)=>k===0||note.start<length*head-1e-9?[`c${k}`]:[]);
  const maxWork=Math.max(1,Math.min(PROTECTED_REPAIR_LIMITS.maxWork,Math.round(Number(budget?.maxWork)||0)));
  let prepared;try{
    const original=model('above',p=>p);
    const policy={id:'countersubject-repair',revision:1,baseline:catalogue.map((_,k)=>({variableId:`n${k}`,candidateId:`n${k}p0`})),
      editableVariables:catalogue.map((_,k)=>`n${k}`).filter((_,k)=>!protectedNotes.includes(`c${k}`)),protectedSourceIds:protectedNotes,protectedOccurrences:[],committedUntil:'0',
      // (One axis: how many of its notes move -- each move a note; no pitch of the catalogue preferred to another.)
      axes:[{id:'notes-moved',sourceChangeCost:'1',occurrenceChangeCost:'0'}],
      variableCosts:catalogue.map((pitches,k)=>({variableId:`n${k}`,candidates:pitches.map((_,j)=>({candidateId:`n${k}p${j}`,costs:['0']}))}))};
    const ready=prepareProtectedRepair(original,policy,{maxWork});if(ready.status!=='PASS')return {status:'UNKNOWN',line:counter,reason:ready.reason};prepared=ready.prepared;
  }catch(error){return {status:'UNKNOWN',line:counter,reason:String(error?.message??error)}}
  let found;try{found=solveProtectedRepair(prepared,{maxWork})}catch(error){return {status:'UNKNOWN',line:counter,reason:String(error?.message??error)}}
  if(found.status!=='OPTIMAL'&&found.status!=='SAT')return {status:found.status,line:counter,reason:found.reason??null};
  const chosen=new Map(found.report.assignment.map(({variableId,candidateId})=>[variableId,candidateId]));
  const line=counter.map((note,k)=>({...note,pitch:catalogue[k][Number(String(chosen.get(`n${k}`)).split('p').at(-1))]}));
  const changed=line.filter((note,k)=>!same(note.pitch,counter[k].pitch)).length;
  return {status:changed?found.status:'PASS',line,changed,modelHash:prepared.modelHash??null};
}

// A stretto's culmination (Astra's CF16, subject-combinations.js): every voice of it sounding its entry -- the subject,
// the answer, its inversion or augmentation, each registered as its own approved form -- at once, for at least the
// length of the subject's head (`head`, quarters: the share of the subject a fugue counts recognisable, fugue-plan.js
// FUGUE.episode.head), whole and unbroken; the whole stretto audited under its contract (`rules`) as the disposition
// family it is, and the culmination's common activity swept and checked independently. `entries` [{voice, notes:
// [{pitch, start, length}]}] (quarters from the section's start). -> {status ('PASS', 'FAIL' or 'UNKNOWN'), common
// ([[from, to]] quarters: where every voice sounds its entry together), total, longest, reason}.
export function strettoCulmination({entries,head,collection,rules,strong=()=>false,budget}){
  if(entries.length<2||!(head>0))return {status:'UNKNOWN',reason:'no stretto, or no head to culminate on'};
  const all=entries.flatMap(entry=>entry.notes),from=Math.min(...all.map(note=>note.start)),end=latestEnd(all),to=floatOfExact(end);
  const ids=entries.map((_,k)=>`v${k}`),moving=entries.some((a,i)=>entries.some((b,j)=>j>i&&a.notes.some((n,k)=>k>0&&b.notes.some((m,l)=>l>0&&Math.abs(n.start-m.start)<1e-9))));
  const {rules:contract,...reads}=contractOf(rules,{voices:ids,pairs:'all',moving});
  const cells=cellsOf(all.map(note=>note.start),end,{strong,...reads});
  const lowest=Math.min(...all.map(note=>note.pitch)),highest=Math.max(...all.map(note=>note.pitch));
  const refs=()=>['metric','tuning','timbre'].map(id=>({id,revision:1}));
  const sources=entries.map((entry,k)=>({id:`s${k}`,revision:1,pitchSpace:SPACE,clockDomain:CLOCK,length:exact(to),
    events:entry.notes.map((note,j)=>({id:`s${k}e${j}`,...spanText(note),pitch:pitchOf(note.pitch)}))}));
  const parts=entries.map((_,k)=>({id:`P${k}`,sourceId:`s${k}`,voiceId:ids[k],pitchTransform:{id:`s${k}-pitch`,revision:1,operations:[]},
    timeMap:{id:`s${k}-time`,revision:1,knots:[{source:'0',target:'0'},{source:exact(to),target:exact(to)}]},
    register:{id:`s${k}-register`,revision:1,low:pitchOf(lowest),high:pitchOf(highest)}}));
  const promise={id:'culmination',revision:1,memberId:'stretto',subjects:ids.map(id=>`form-${id}`),clockDomain:{...CLOCK},from:exact(from),to:exact(to),minCommonDuration:exact(head),minContiguousDuration:exact(head)};
  const spec={id:'stretto',revision:1,subjects:ids.map((id,k)=>({id:`form-${id}`,revision:1,sourceIds:[`s${k}`]})),
    expected:{id:'promised-culminations',revision:1,complete:true,combinations:[promise]},
    bindings:[{id:promise.id,revision:1,memberId:'stretto',participants:ids.map((id,k)=>({subjectId:`form-${id}`,partId:`P${k}`}))}],
    family:{id:'stretto-family',revision:1,sources,expected:{id:'promised-dispositions',revision:1,complete:true,members:[{id:'stretto',revision:1,parts:parts.map(p=>({id:p.id,sourceId:p.sourceId,voiceId:p.voiceId})),dependencies:refs()}]},
      dependencies:[{id:'metric',revision:1,kind:'metric',applicability:'bound',complete:true,data:{clock:CLOCK.id}},
        {id:'tuning',revision:1,kind:'tuning',applicability:'bound',complete:true,data:{collection:collection.map(Number)}},
        {id:'timbre',revision:1,kind:'timbre',applicability:'not-applicable',complete:true,data:{reason:'symbolic activity and its counterpoint only'}}],
      members:[{id:'stretto',revision:1,pitchSpace:SPACE,dependencies:refs(),parts,
        environment:{id:'stretto-alone',revision:1,complete:true,events:[],contexts:cells},
        profile:compileCounterpointProfile({id:'stretto',version:1,pitchSpace:SPACE,clockDomain:CLOCK,voices:ids,rules:contract})}]}};
  const maxWork=Math.max(1,Math.min(SUBJECT_COMBINATION_LIMITS.maxWork??Infinity,Math.round(Number(budget?.maxWork)||0)));
  const options={maxWork,maxFamilyWork:Math.min(SUBJECT_COMBINATION_LIMITS.maxFamilyWork,maxWork)};
  let prepared;try{const ready=prepareSubjectCombinations(spec,options);if(ready.status!=='PASS')return {status:'UNKNOWN',reason:ready.reason};prepared=ready.prepared}
  catch(error){return {status:'UNKNOWN',reason:String(error?.message??error)}}
  let audit;try{audit=auditSubjectCombinations(prepared,options)}catch(error){return {status:'UNKNOWN',reason:String(error?.message??error)}}
  const value=x=>{const [n,d='1']=String(x).split('/');return Number(n)/Number(d)},report=audit.results?.[0]?.report??null;
  const said={common:(report?.commonIntervals??[]).map(([a,b])=>[value(a),value(b)]),total:report?value(report.totalDuration):null,longest:report?value(report.longestContiguousDuration):null};
  if(audit.status!=='PASS'){
    // (Which failed: the stretto's counterpoint (its family) or its common activity, and the rules broken.)
    const broken=[...new Set((audit.family?.report?.members??audit.familyReport?.members??[]).flatMap(m=>(m.audit?.checks??m.report?.audit?.checks??[]).filter(row=>row.status==='FAIL').map(row=>row.rule)))];
    return {status:audit.status,...said,family:audit.familyStatus??null,...(broken.length?{failed:broken}:{}),reason:audit.reason??null};
  }
  let checked;try{checked=checkSubjectCombinations(prepared,audit.certificate,options)}catch(error){return {status:'UNKNOWN',reason:String(error?.message??error)}}
  if(checked.status!=='PASS')return {status:'UNKNOWN',reason:`its certificate: ${checked.status}${checked.reason?` (${checked.reason})`:''}`};
  const c=audit.certificate.combinations[0],law=plannerLaw(entries.map(entry=>entry.notes),{rules,strong});
  if(law!=='PASS')return {status:law,failed:['planner-law'],reason:'the planner\'s own law'};
  return {status:'PASS',common:c.commonIntervals.map(([a,b])=>[value(a),value(b)]),total:value(c.totalDuration),longest:value(c.longestContiguousDuration)};
}

// A converging tempo canon (Astra's EC07/CF28, CFM-032 positive-warp.js): one line played by several voices, each at its
// own exact speed -- its `ratio` ('p/q') times the source's lengths -- entering in turn, the slowest first, so that
// every voice strikes the source's last note at once (its convergence, as Nancarrow's canons converge), each entry at
// least `group` after the one before. Each voice's timing is a warp of the source onto the section's time: its rate its
// ratio on every span, its convergence the slowest's, its first voice from the section's start, every note within
// `length`; the warp solved exactly -- the least displacement from the times the ratios propose (none where they hold),
// a contradiction among them proved -- and the whole union of its voices audited under the contract (`rules`, as above)
// on the meter's `strong` positions, as its solver finds it (its certificate checked in development: checkPositiveWarp). `source` [{pitch, start, length}]
// (beats from its start, each an exact fraction of the beat; its last note the convergence's); `voices` [{ratio,
// transpose (semitones), or map (pitch -> pitch: a canon at a degree of the harmony)}], the slowest first; `length`, `group` beats. -> {status ('OPTIMAL', else 'UNSAT' or
// 'UNKNOWN'), entries (beats, exact text, a voice each, where OPTIMAL), at (the convergence, beats), failed (the rules
// its union broke), modelHash, reason}.
export function convergingCanon({source,voices,length,group,collection,rules,strong=()=>false,budget}){
  const beat=x=>{const f=fractionOf(+x);if(!f)throw new Error(`no exact beat for ${x}`);return Q(`${f[0]}/${f[1]}`)};
  if(voices.length<2||source.length<2)return {status:'UNKNOWN',reason:'a canon needs two voices and a line'};
  let times;try{times=source.map(note=>note.scoreTime?{start:Q(note.scoreTime.at),end:Q(note.scoreTime.at).add(Q(note.scoreTime.duration))}:{start:beat(note.start),end:beat(note.start+note.length)})}catch(error){return {status:'UNKNOWN',reason:String(error.message)}}
  const last=times.at(-1).start,end=times.at(-1).end,ratios=voices.map(voice=>Q(voice.ratio)),T=beat(length),gap=beat(group);
  // (The convergence where the slowest voice, from the section's start, strikes the last note; each other voice's entry
  // the time that ratio leaves before it.)
  const at=ratios[0].mul(last),entries=ratios.map(r=>at.sub(r.mul(last)));
  if(entries.some(e=>e.cmp(0)<0))return {status:'UNKNOWN',reason:'a voice faster than the first'};
  const ids=voices.map((_,k)=>`v${k}`),targets=voices.map((_,v)=>times.map(t=>entries[v].add(ratios[v].mul(t.start))));
  const onsets=new Map;targets.forEach((list,v)=>list.forEach((t,k)=>{if(k){const key=t.toString();(onsets.get(key)??onsets.set(key,new Set).get(key)).add(v)}}));
  const moving=[...onsets.values()].some(set=>set.size>1);
  const {rules:contract,...reads}=contractOf(rules,{voices:ids,pairs:'all',moving});
  // (Its positions' contexts, every boundary exact: an onset of any voice.)
  const bounds=[...new Map([Q(0),...targets.flat()].filter(t=>t.cmp(T)<0).map(t=>[t.toString(),t])).values()].sort((a,b)=>a.cmp(b));
  const cells=bounds.map((from,k)=>{const to=bounds[k+1]??T,[n,d='1']=from.toString().split('/'),key=strong(Number(n)/Number(d))?'strong':'weak';
    return {id:`cell${k}`,revision:1,from:from.toString(),to:to.toString(),complete:true,data:positionData(key,reads)}});
  const clock={id:'canon-source-beats',unit:'beat',revision:1},knowing=ref('canon-plan',source.map(n=>[n.pitch,n.start,n.length]));
  // (A voice's warp is linear at its ratio: its knots its start, its convergence and its end.)
  const knots=[Q(0),last,end];
  const spec={id:'converging-canon',revision:1,pitchSpace:SPACE,
    profile:compileCounterpointProfile({id:'converging-canon',version:1,pitchSpace:SPACE,clockDomain:CLOCK,voices:ids,rules:contract}),
    lines:voices.map((voice,v)=>({id:`line${v}`,revision:1,voiceId:ids[v],complete:true,sourceClock:clock,
      knots:knots.map((s,k)=>{const ideal=entries[v].add(ratios[v].mul(s)).toString(),fixed=!k&&!v||s.eq(last);
        return {source:s.toString(),ideal,lo:fixed?ideal:'0',hi:fixed?ideal:T.toString(),freeBand:{minus:'0',plus:'0'},normalizer:{minus:'1',plus:'1'}}}),
      rates:knots.slice(1).map(()=>({min:ratios[v].toString(),max:ratios[v].toString()})),
      events:source.map((note,k)=>({id:`e${k}`,t:times[k].start.toString(),d:times[k].end.sub(times[k].start).toString(),pitch:pitchOf(voice.map?voice.map(note.pitch):note.pitch+(Number(voice.transpose)||0))})),
      provenance:knowing,requiredChannels:['score'],
      // (Every voice knows the line before the first sound: the canon is planned, its parts read.)
      channels:[{id:'score',revision:1,kind:'known',clockDomain:{...CLOCK},reference:knowing,values:knots.map(()=>({availability:'0',preparation:'0'}))}]})),
    relations:voices.slice(1).map((_,k)=>({id:`entry${k+1}`,from:{lineId:`line${k}`,knotIndex:0},to:{lineId:`line${k+1}`,knotIndex:0},lo:gap.toString(),hi:T.toString()})),
    environment:{id:'canon-alone',revision:1,complete:true,events:[],contexts:cells},blend:'1/2',
    bindings:{collection:collection.map(Number)},dependencies:[{id:'canon-rules',revision:1,data:{leapMost:Number(rules.leapMost)}}]};
  const maxWork=Math.max(1,Math.min(POSITIVE_WARP_LIMITS.maxWork,Math.round(Number(budget?.maxWork)||0)));
  const options={maxWork,maxMusicalWork:Math.min(POSITIVE_WARP_LIMITS.maxMusicalWork,maxWork)};
  let prepared;try{const ready=preparePositiveWarp(spec,options);if(ready.status!=='PASS')return {status:'UNKNOWN',reason:ready.reason};prepared=ready.prepared}
  catch(error){return {status:'UNKNOWN',reason:String(error?.message??error)}}
  let solved;try{solved=solvePositiveWarp(prepared,options)}catch(error){return {status:'UNKNOWN',reason:String(error?.message??error)}}
  const failed=[...new Set((solved.proposal?.musicalReport?.audit?.checks??[]).filter(row=>row.status==='FAIL').map(row=>row.rule))];
  if(solved.status!=='OPTIMAL')return {status:solved.status,...(failed.length?{failed}:{}),reason:solved.reason??null};
  return {status:'OPTIMAL',entries:solved.certificate.targets.map(line=>line.values[0]),at:at.toString(),peak:solved.certificate.peak,modelHash:prepared.modelHash??null};
}

// A fugue's subject chosen by what it affords its development (Astra's CF08, CFM-038 development-affordance.js): each
// candidate subject its planner drew (`subjects`, [[{pitch, start, length}]], quarters, in the order drawn) probed in
// every form of stretto its fugue may take (`conditions` [{id, delay (quarters), steps (degrees of the collection: an
// answer), invert (by the collection's degrees about its first pitch), ratio (an augmentation)}]): the subject with its
// own entry so transformed and delayed, the two audited whole under the fugue's contract (`rules`, as above) on the
// meter's `strong` positions, each form weighed alike. Beside that coverage, its variety (its distinct pitches over its
// notes: a subject of one repeated pitch is trivial, Astra's "triviality" objective), measured exactly. The record keeps
// every subject no other surely betters in both; of those, the first drawn. -> {status ('PASS', else 'UNKNOWN'), index
// (the subject chosen), retained ([index]), coverage ([[low, high]] a subject: the share of its forms that hold),
// complete (every probe resolved), modelHash, reason}.
export function subjectAffordance({subjects,conditions,collection,rules,strong=()=>false,budget}){
  if(subjects.length<2||!conditions.length)return {status:'UNKNOWN',reason:'one subject, or no forms to probe'};
  const ids=['v0','v1'],refs=()=>['metric','tuning','timbre'].map(id=>({id,revision:1}));
  const moved=(subject,{steps=0,invert=false,ratio=1})=>subject.map(note=>({start:note.start*ratio,length:note.length*ratio,
    pitch:invert?invertedLine([{pitch:note.pitch}],{axis:subject[0].pitch,collection,degrees:true})[0].pitch:steps?stepInCollection(note.pitch,steps,collection):note.pitch}));
  const sourceOf=(id,notes)=>({id,revision:1,pitchSpace:SPACE,clockDomain:CLOCK,length:exact(Math.max(...notes.map(note=>note.start+note.length))),
    events:notes.map((note,k)=>({id:`${id}e${k}`,...spanText(note),pitch:pitchOf(note.pitch)}))});
  const familyOf=(i,condition)=>{
    const subject=subjects[i],entry=moved(subject,condition),delay=Number(condition.delay)||0;
    const placed=[subject,entry.map(note=>({...note,start:note.start+delay}))],all=placed.flat(),end=Math.max(...all.map(note=>note.start+note.length));
    const moving=placed[1].some((note,k)=>k>0&&subject.some((other,j)=>j>0&&Math.abs(other.start-note.start)<1e-9));
    const {rules:contract,...reads}=contractOf(rules,{voices:ids,pairs:'all',moving});
    const lowest=Math.min(...all.map(note=>note.pitch)),highest=Math.max(...all.map(note=>note.pitch));
    const sources=[sourceOf(`subject${i}`,subject),sourceOf(`subject${i}-${condition.id}`,entry)];
    const lengthOf=notes=>Math.max(...notes.map(note=>note.start+note.length));
    const parts=sources.map((source,k)=>({id:`P${k}`,sourceId:source.id,voiceId:ids[k],pitchTransform:{id:`${source.id}-pitch`,revision:1,operations:[]},
      timeMap:{id:`${source.id}-time`,revision:1,knots:[{source:'0',target:exact(k?delay:0)},{source:source.length,target:exact((k?delay:0)+lengthOf(k?entry:subject))}]},
      register:{id:`${source.id}-register`,revision:1,low:pitchOf(lowest),high:pitchOf(highest)}}));
    return {id:`stretto-${i}-${condition.id}`,revision:1,sources,
      expected:{id:`stretto-${i}-${condition.id}-promised`,revision:1,complete:true,members:[{id:'stretto',revision:1,parts:parts.map(p=>({id:p.id,sourceId:p.sourceId,voiceId:p.voiceId})),dependencies:refs()}]},
      dependencies:[{id:'metric',revision:1,kind:'metric',applicability:'bound',complete:true,data:{clock:CLOCK.id}},
        {id:'tuning',revision:1,kind:'tuning',applicability:'bound',complete:true,data:{collection:collection.map(Number)}},
        {id:'timbre',revision:1,kind:'timbre',applicability:'not-applicable',complete:true,data:{reason:'symbolic counterpoint only'}}],
      members:[{id:'stretto',revision:1,pitchSpace:SPACE,dependencies:refs(),parts,
        environment:{id:'stretto-alone',revision:1,complete:true,events:[],contexts:cellsOf(all.map(note=>note.start),end,{strong,...reads})},
        profile:compileCounterpointProfile({id:`stretto-${i}-${condition.id}`,version:1,pitchSpace:SPACE,clockDomain:CLOCK,voices:ids,rules:contract})}]};
  };
  let spec;try{
    const families=subjects.map((_,i)=>conditions.map(condition=>familyOf(i,condition)));
    // (Each subject's source as its families hold it, normalised: the record binds every probe to it.)
    const registered=subjects.map((_,i)=>{const ready=prepareDispositionFamily(families[i][0]);if(ready.status!=='PASS')throw new Error(ready.reason);
      const source=ready.prepared.definition.sources.find(item=>item.id===`subject${i}`);return {id:source.id,revision:source.revision,hash:sha256(pythonJson(source))}});
    const variety=subject=>{const distinct=new Set(subject.map(note=>exact(note.pitch))).size;return `${distinct}/${subject.length}`};
    const conditionRows=conditions.map(condition=>({id:condition.id,revision:1,hash:sha256(pythonJson(['stretto',condition.id,Number(condition.delay)||0,condition.steps??0,Boolean(condition.invert),condition.ratio??1])),kind:'stretto-form',dimensionId:'stretto',weight:'1'}));
    const probes=subjects.flatMap((_,i)=>conditions.map((condition,j)=>({id:`s${i}-${condition.id}`,subjectId:`s${i}`,conditionId:condition.id,conditionHash:conditionRows[j].hash,family:families[i][j]})));
    spec={id:'fugue-subjects',revision:1,contextHash:sha256(pythonJson({collection:collection.map(Number),leapMost:Number(rules.leapMost)})),
      design:{id:'fugue-subject-probes',revision:1,complete:true,subjects:subjects.map((_,i)=>`s${i}`),conditions:conditions.map(c=>c.id),probes:probes.map(({id,subjectId,conditionId})=>({id,subjectId,conditionId}))},
      dimensions:[{id:'stretto',kind:'probe',unit:'weighted-fraction',goal:'maximize'},{id:'variety',kind:'declared',unit:'distinct-pitches-per-note',goal:'maximize'}],
      conditions:conditionRows,
      subjects:subjects.map((subject,i)=>({id:`s${i}`,revision:1,origin:'generated',parentId:null,source:registered[i],
        annotations:{id:`s${i}-annotations`,revision:1,headEventIds:[`subject${i}e0`],rhythmicSignature:subject.map(note=>exact(note.length)),directedIntervals:subject.slice(1).map((note,k)=>exact(note.pitch-subject[k].pitch)),
          harmonicEntry:{interpretation:'its planner\'s'},harmonicExit:{interpretation:'its planner\'s'},range:{low:Math.min(...subject.map(n=>n.pitch)),high:Math.max(...subject.map(n=>n.pitch))},phraseSpan:exact(Math.max(...subject.map(n=>n.start+n.length))),permittedAlterations:['stretto forms probed']},
        metrics:[{dimensionId:'variety',low:variety(subject),high:variety(subject),evidence:ref(`s${i}-variety`,subject.map(note=>note.pitch))}]})),
      probes,probeOrder:conditions.flatMap(condition=>subjects.map((_,i)=>`s${i}-${condition.id}`))};
  }catch(error){return {status:'UNKNOWN',reason:String(error?.message??error)}}
  const options=budget?.maxWork?{maxWork:Math.max(1,Math.min(DEVELOPMENT_AFFORDANCE_LIMITS.maxWork,Math.round(budget.maxWork)))}:{};
  let prepared;try{const ready=prepareDevelopmentAffordance(spec,options);if(ready.status!=='PASS')return {status:'UNKNOWN',reason:ready.reason};prepared=ready.prepared}
  catch(error){return {status:'UNKNOWN',reason:String(error?.message??error)}}
  let audit;try{audit=auditDevelopmentAffordance(prepared,options)}catch(error){return {status:'UNKNOWN',reason:String(error?.message??error)}}
  if(audit.status!=='PASS')return {status:'UNKNOWN',reason:audit.reason??null};
  const value=text=>{const [n,d='1']=String(text).split('/');return Number(n)/Number(d)},report=audit.report;
  const retained=report.retainedIds.map(id=>Number(id.slice(1))).sort((a,b)=>a-b);
  const coverage=subjects.map((_,i)=>{const row=report.subjects.find(x=>x.subjectId===`s${i}`).metrics.find(x=>x.dimensionId==='stretto');return [value(row.low),value(row.high)]});
  return {status:'PASS',index:retained[0],retained,coverage,complete:report.coverageComplete,modelHash:prepared.hash??null};
}

// A fugue's episodes led back to its return (Astra's CF18/EC13, CFM-023 conditioned-paths.js): the levels, in the
// collection's degrees from the subject's own, at which its episodes' fragments sound in turn, drawn as a walk whose
// every move is one of the subject's own (its melodic steps between its notes, each as often as the subject takes it),
// from the level of the entry before them, conditioned exactly on arriving at the subject's own level as the return
// enters -- after exactly as many moves as it has fragments, and one -- and on reaching that level nowhere sooner (one
// arrival, a resource of one), every level within an octave of the subject's (the walk's admission). Its law solved,
// one path drawn by a single lottery over its complete law (`random`: words of [0, 1)). -> [level] a fragment each, or
// null where its law has none (the subject has no steps, or none arrives).
export function episodeLevels({subject,collection,start=0,fragments,random}){
  if(!(fragments>0)||subject.length<2)return null;
  const classes=[];for(const p of collection.map(p=>modulo(Number(p),12)).sort((a,b)=>a-b))if(!classes.some(c=>Math.abs(c-p)<1e-6))classes.push(p);
  const n=classes.length;if(n<2)return null;
  // (A pitch's degree: its octave's count of the collection's classes and its nearest class.)
  const degree=pitch=>{const octave=Math.floor(pitch/12),within=pitch-12*octave;let k=0;for(let i=1;i<n;i++)if(Math.abs(classes[i]-within)<Math.abs(classes[k]-within))k=i;
    const wrapped=Math.abs(classes[0]+12-within)<Math.abs(classes[k]-within);return (octave+(wrapped?1:0))*n+(wrapped?0:k)};
  const counts=new Map;for(let i=1;i<subject.length;i++){const d=degree(subject[i].pitch)-degree(subject[i-1].pitch);if(d)counts.set(d,(counts.get(d)??0)+1)}
  if(!counts.size)return null;
  const total=[...counts.values()].reduce((a,b)=>a+b,0),moves=[...counts.entries()].sort((a,b)=>a[0]-b[0]);
  const begin=Math.round(Number(start)||0);if(Math.abs(begin)>n)return null;
  const id=level=>`l${level}`,states=[];
  for(let level=-n;level<=n;level++)states.push({id:id(level),goal:level===0?'PASS':'FAIL',decisionsComplete:true,
    decisions:moves.map(([d,c])=>{const next=level+d,inside=Math.abs(next)<=n;
      return {id:`m${d}`,next:inside?id(next):'out',probability:`${c}/${total}`,costs:[inside&&next===0?1:0],changedEventIds:[],checks:[{id:'within-octave',status:inside?'PASS':'FAIL'}]}})});
  states.push({id:'out',goal:'FAIL',decisionsComplete:true,decisions:[]});
  const spec={id:'fugue-episodes',revision:1,start:id(begin),horizon:fragments+1,resources:[{id:'home',unit:'arrivals',remaining:1}],
    requiredPredicates:['within-octave'],lockedEventIds:[],dependencies:[{id:'subject-steps',revision:1,hash:sha256(pythonJson(moves))}],states};
  let solved;try{solved=solveConditionedPaths(spec);if(solved.status!=='CERTIFIED'||!solved.plan)return null}catch{return null}
  let drawn;try{drawn=sampleConditionedPath(solved.plan,()=>Math.floor(random()*2**32)>>>0,{})}catch{return null}
  if(drawn?.status!=='SELECTED')return null;
  const levels=drawn.path.states.slice(1).map(state=>Number(String(state).slice(1)));
  return levels.length===fragments+1&&levels.at(-1)===0?levels.slice(0,fragments):null;
}
