// CFM-021/024: finite cadence selection for explicit large voice inventories.
// Flow handles unary/cardinality factors; last-k variant states handle explicit pair bands.
// Exact symbolic preparation/reference only: resource refusal is UNKNOWN, not a scheduler deadline.
import {Q,Rational} from './canon-core.js';
import {compilePitchOperations} from './pitch-spaces.js';
import {inspectFactorizedCadenceProfile} from './factorized-cadence-profile.js';
import {solveBoundedCirculation,checkBoundedCirculation} from './cardinality-flow.js';
import {dataArray,dataRecord} from './contract-data.js';
import {Refused,EXACT_LIMITS,exactOf,pythonJson,sha256} from '../bounded-exact.js';

export const LARGE_CADENCE_DEFAULTS=Object.freeze({maxWork:2000000,maxVoices:1024,maxCandidates:256,maxTones:1024,maxRoles:256,
  maxEvents:262144,maxSourceEvents:4096,maxTailEvents:1024,maxVariants:65536,maxStates:50000,maxTransitions:500000,maxFallbackLeaves:256,
  maxFactorWork:4096,maxPredicateWork:2000000,maxTextChars:16777216,maxSnapshotNodes:1048576,maxHashChars:16777216});
const LARGE_CADENCE_SHAPE=Object.freeze({string:2048,depth:16});
const freeze=Object.freeze;
const fail=(message,kind='invalid-input')=>{throw new Refused(message,{kind})};
const scope='finite-factorized-cadence-with-cardinality-and-declared-pair-bands';
const integerBoundary=1n<<BigInt(EXACT_LIMITS.inputBits);
function integerToken(value){
  if(typeof value==='bigint'){
    if(value<=-integerBoundary||value>=integerBoundary)fail('Raw rational component exceeds its bit budget','arithmetic-budget');
  }else if(!Number.isSafeInteger(value))fail('Malformed rational components');
  return value;
}
function fields(value,keys,optional=[]){
  if(!dataRecord(value)||keys.some(key=>!Object.hasOwn(value,key))||Object.keys(value).some(key=>!keys.includes(key)&&!optional.includes(key)))fail('Unexpected or missing cadence fields');
  return value;
}
function text(value,state,limit=LARGE_CADENCE_SHAPE.string){
  if(typeof value!=='string'||!value.length||value.length>limit)fail('Invalid bounded cadence text');
  if(value.length>state.limits.maxTextChars-state.chars)fail('Cadence text budget for one snapshot frame','work-budget');
  state.chars+=value.length;
  state.usage.peakTextChars=Math.max(state.usage.peakTextChars,state.chars);
  if(state.phase==='model')state.usage.modelTextChars=state.chars;
  return value;
}
const count=(value,maximum)=>{if(!Number.isSafeInteger(value)||value<0||value>maximum)fail('Invalid cadence count');return value};
class CadenceBudget {
  constructor(limit){this.limit=count(limit,Number.MAX_SAFE_INTEGER);this.used=0}
  charge(amount=1){
    if(!Number.isSafeInteger(amount)||amount<0)fail('Invalid cadence work charge');
    if(amount>this.limit-this.used)fail('Cadence work budget exhausted','work-budget');
    this.used+=amount;
  }
}
function frame(state,phase){
  state.budget.charge();if(phase==='leaf')state.usage.leafAudits++;
  return {...state,phase,chars:0,snapshots:0};
}
function copy(value,state,depth=0,seen=new Set){
  state.budget.charge();
  if(state.snapshots>=state.limits.maxSnapshotNodes)fail('Cadence node budget for one snapshot frame','work-budget');
  state.snapshots++;state.usage.peakSnapshotNodes=Math.max(state.usage.peakSnapshotNodes,state.snapshots);
  if(state.phase==='model')state.usage.modelSnapshotNodes=state.snapshots;
  if(value===null||typeof value==='boolean')return value;
  if(typeof value==='string'){if(value==='')return value;return text(value,state)}
  if(typeof value==='number'){if(!Number.isFinite(value))fail('Nonfinite snapshot value');return Object.is(value,-0)?0:value}
  if(depth>=LARGE_CADENCE_SHAPE.depth||seen.has(value))fail('Cyclic or deep cadence data');
  seen.add(value);let out;
  if(Array.isArray(value)){
    dataArray(value,state.limits.maxEvents,'Cadence snapshot');out=[];
    for(let i=0;i<value.length;i++)out.push(copy(value[i],state,depth+1,seen));
  }else{
    if(!dataRecord(value))fail('Cadence snapshots require plain data');
    const keys=Object.keys(value);if(keys.length>256)fail('Cadence snapshot is too wide');out={};
    for(const key of keys){text(key,state);Object.defineProperty(out,key,{value:copy(value[key],state,depth+1,seen),enumerable:true})}
  }
  seen.delete(value);return freeze(out);
}
function exact(value,state){
  state.budget.charge();let input;
  if(value&&Object.getPrototypeOf(value)===Rational.prototype){
    const n=Object.getOwnPropertyDescriptor(value,'n'),d=Object.getOwnPropertyDescriptor(value,'d');
    if(!n||!d||!Object.hasOwn(n,'value')||!Object.hasOwn(d,'value'))fail('Malformed exact time');
    input={n:integerToken(n.value),d:integerToken(d.value)};
  }else if(typeof value==='string'){
    if(!value.length||value.length>160)fail('Bounded exact spelling required');
    const fraction=value.match(/^([+-]?[0-9]+)\/([+-]?[0-9]+)$/);
    if(fraction&&fraction[0].length===value.length)input={n:integerToken(BigInt(fraction[1])),d:integerToken(BigInt(fraction[2]))};
    else{
      const decimal=value.match(/^([+-]?)(?:([0-9]+)(?:\.([0-9]*))?|\.([0-9]+))(?:[eE]([+-]?[0-9]{1,3}))?$/);
      if(!decimal||decimal[0].length!==value.length)fail('Invalid rational spelling');
      const [,sign,whole='',part=decimal[4]??'',,exponent='0']=decimal;
      if(Math.abs(Number(exponent))>256)fail('Exponent cap','arithmetic-budget');
      const shift=Number(exponent)-part.length,digits=integerToken(BigInt((whole+part)||'0')*(sign==='-'?-1n:1n));
      if(shift< -77||shift>77&&digits!==0n)fail('Expanded decimal component cap','arithmetic-budget');
      input={n:integerToken(shift>0&&digits!==0n?digits*10n**BigInt(shift):digits),d:integerToken(shift<0?10n**BigInt(-shift):1n)};
    }
  }else if(Array.isArray(value)){
    dataArray(value,2,'Rational pair');if(value.length!==2)fail('A rational pair needs two components');input={n:integerToken(value[0]),d:integerToken(value[1])};
  }else if(value&&typeof value==='object'){fields(value,['n','d']);input={n:integerToken(value.n),d:integerToken(value.d)}}
  else input=integerToken(value);
  const result=Q(exactOf(input));text(String(result),state);return result;
}
function hash(value,state){
  // Emit the shared canonical format in bounded chunks. Check length BEFORE appending/joining, so an over-limit
  // model/witness is not first allocated as one huge canonical string. Primitive spellings have hard input caps.
  const chunks=[];let size=0;
  const append=part=>{
    if(part.length>state.limits.maxHashChars-size)fail('Cadence hash snapshot budget','work-budget');
    size+=part.length;chunks.push(part);
  };
  function encode(v){
    state.budget.charge();
    if(v===null||v===undefined||typeof v!=='object'||
      (typeof v.n==='bigint'&&typeof v.d==='bigint'&&v.d>0n)){append(pythonJson(v));return}
    if(Array.isArray(v)){
      append('[');for(let i=0;i<v.length;i++){if(i)append(',');encode(v[i])}append(']');return;
    }
    const keys=Object.keys(v).sort((a,b)=>{state.budget.charge();return a<b?-1:a>b?1:0});
    append('{');for(let i=0;i<keys.length;i++){if(i)append(',');append(pythonJson(keys[i]));append(':');encode(v[keys[i]])}append('}');
  }
  encode(value);state.usage.peakHashChars=Math.max(state.usage.peakHashChars,size);
  state.budget.charge(1+Math.ceil(size/64));return sha256(chunks.join(''));
}
function pitch(value,space,state,rest=false){
  if(value===null&&rest)return null;
  if(!dataRecord(value)||Object.keys(value).length!==3||!Object.hasOwn(value,'space')||!Object.hasOwn(value,'definition')||!Object.hasOwn(value,'coordinate'))fail('Typed pitch meaning is required','out-of-model');
  const saved=copy(value,state);
  if(saved.space!==space.id||saved.definition!==space.hash)fail('Pitch space or tuning revision is unresolved','out-of-model');
  const coordinate=Array.isArray(saved.coordinate)?freeze(dataArray(saved.coordinate,32,'Lattice coordinate').map(value=>String(exact(value,state)))):String(exact(saved.coordinate,state));
  return space.pitch(freeze({...saved,coordinate}));
}
function events(raw,voiceId,clock,space,state,limit){
  dataArray(raw,limit,'Cadence events');const out=[],ids=new Set;
  for(let i=0;i<raw.length;i++){
    state.budget.charge();if(++state.events>state.limits.maxEvents)fail('Cadence event-description budget','work-budget');
    const event=fields(raw[i],['id','t','d','pitch']),id=text(event.id,state,256);
    if(ids.has(id))fail('Duplicate event identity within a material list');ids.add(id);
    const t=exact(event.t,state),d=exact(event.d,state);if(t.cmp(0)<0||d.cmp(0)<=0)fail('Require nonnegative event time and positive duration');
    t.add(d);out.push(freeze({id,t,d,pitch:pitch(event.pitch,space,state,true),voiceId,clockDomain:clock}));
  }
  out.sort((a,b)=>{state.budget.charge();return a.t.cmp(b.t)||(a.id<b.id?-1:a.id>b.id?1:0)});return freeze(out);
}
function normalize(spec,state){
  fields(spec,['id','revision','pitchSpace','clockDomain','anchor','window','hitDuration','voices','chord','domainComplete','rules','dependencies']);
  const id=text(spec.id,state,256),revision=count(spec.revision,Number.MAX_SAFE_INTEGER),space=spec.pitchSpace;
  compilePitchOperations(space,[]);const c=fields(spec.clockDomain,['id','unit','revision']);
  const clock=freeze({id:text(c.id,state,256),unit:text(c.unit,state,256),revision:count(c.revision,Number.MAX_SAFE_INTEGER)});
  const anchor=exact(spec.anchor,state),hitDuration=exact(spec.hitDuration,state);
  dataArray(spec.window,2,'Cadence cut window');if(spec.window.length!==2)fail('Declare a closed two-endpoint cut window');
  const window=freeze([exact(spec.window[0],state),exact(spec.window[1],state)]);
  if(anchor.cmp(0)<0||hitDuration.cmp(0)<=0||window[0].cmp(0)<0||window[0].cmp(window[1])>0||window[1].cmp(anchor)>0)fail('Invalid anchor, hold or editing window');
  anchor.add(hitDuration);if(typeof spec.domainComplete!=='boolean')fail('Declare whether the candidate domain is complete');
  let rules=null;
  if(spec.rules!==null){
    const r=fields(spec.rules,['id','version','checkJoint'],['decomposition']);
    const decomposition=Object.hasOwn(r,'decomposition')?inspectFactorizedCadenceProfile(r.decomposition):null;
    if(r.checkJoint!==null||!decomposition)fail('Large cadence needs a complete branded factorized profile and no additional callback','out-of-model');
    rules=freeze({id:text(r.id,state,256),version:count(r.version,Number.MAX_SAFE_INTEGER),check:r.checkJoint,decomposition});
  }
  const dependencies=copy(spec.dependencies,state);if(!dataRecord(dependencies))fail('Dependencies must be a plain record');
  const chord=fields(spec.chord,['roles','tones']);dataArray(chord.roles,state.limits.maxRoles,'Chord roles');dataArray(chord.tones,state.limits.maxTones,'Chord tones');
  const roles=[],roleIds=new Set,tones=[],toneIds=new Set;
  for(let i=0;i<chord.roles.length;i++){
    state.budget.charge();const r=fields(chord.roles[i],['id','min','max']),name=text(r.id,state,256),min=count(r.min,Number.MAX_SAFE_INTEGER),max=count(r.max,Number.MAX_SAFE_INTEGER);
    if(roleIds.has(name)||min>max)fail('Duplicate role or reversed role bounds');roleIds.add(name);roles.push(freeze({id:name,min,max}));
  }
  for(let i=0;i<chord.tones.length;i++){
    state.budget.charge();const t=fields(chord.tones[i],['id','role','pitch','min','max']),name=text(t.id,state,256),role=text(t.role,state,256),min=count(t.min,Number.MAX_SAFE_INTEGER),max=count(t.max,Number.MAX_SAFE_INTEGER);
    if(toneIds.has(name)||!roleIds.has(role)||min>max)fail('Duplicate tone, undeclared role or reversed tone bounds');toneIds.add(name);
    const value=pitch(t.pitch,space,state);
    for(const other of tones){state.budget.charge();if(space.equivalent(other.pitch,value)===true)fail('Chord tone pitches must be distinct; combine multiplicity bounds explicitly')}
    tones.push(freeze({id:name,role,pitch:value,min,max}));
  }
  dataArray(spec.voices,state.limits.maxVoices,'Cadence voices');if(!spec.voices.length)fail('At least one declared voice is required');
  const voices=[],voiceIds=new Set,sourceIds=new Set;
  for(let i=0;i<spec.voices.length;i++){
    state.budget.charge();const v=fields(spec.voices[i],['id','source','immutableUntil','locked','candidates']),voiceId=text(v.id,state,256);
    if(voiceIds.has(voiceId)||typeof v.locked!=='boolean')fail('Duplicate voice or missing lock declaration');voiceIds.add(voiceId);
    const immutableUntil=exact(v.immutableUntil,state);if(immutableUntil.cmp(0)<0)fail('Negative immutable-prefix boundary');
    const source=events(v.source,voiceId,clock,space,state,state.limits.maxSourceEvents);
    for(const event of source){state.budget.charge();if(sourceIds.has(event.id))fail('Source identities must be globally unique');sourceIds.add(event.id)}
    dataArray(v.candidates,state.limits.maxCandidates,'Cadence candidates');const candidates=[],ids=new Set;
    for(let j=0;j<v.candidates.length;j++){
      state.budget.charge();const raw=fields(v.candidates[j],['id','cut','splitSourceIds','tail','arrival']),candidateId=text(raw.id,state,256);
      if(ids.has(candidateId))fail('Duplicate candidate identity');ids.add(candidateId);const cut=exact(raw.cut,state);
      dataArray(raw.splitSourceIds,state.limits.maxSourceEvents,'Explicit source splits');const splits=[],splitIds=new Set;
      for(let k=0;k<raw.splitSourceIds.length;k++){state.budget.charge();const name=text(raw.splitSourceIds[k],state,256);if(splitIds.has(name))fail('Duplicate split identity');splitIds.add(name);splits.push(name)}
      const tail=events(raw.tail,voiceId,clock,space,state,state.limits.maxTailEvents),a=fields(raw.arrival,['id','pitch']);
      if(++state.events>state.limits.maxEvents)fail('Cadence event-description budget','work-budget');
      const arrival=freeze({id:text(a.id,state,256),t:anchor,d:hitDuration,pitch:pitch(a.pitch,space,state),voiceId,clockDomain:clock});
      candidates.push(freeze({id:candidateId,cut,splitSourceIds:freeze(splits),tail,arrival}));
    }
    voices.push(freeze({id:voiceId,source,immutableUntil,locked:v.locked,candidates:freeze(candidates)}));
  }
  if(rules?.decomposition){
    const p=rules.decomposition;state.budget.charge(1+voices.length);
    if(p.pitchSpaceHash!==space.hash||p.clockDomain.id!==clock.id||p.clockDomain.unit!==clock.unit||p.clockDomain.revision!==clock.revision||
      p.voices.length!==voices.length||p.voices.some(id=>!voiceIds.has(id)))fail('Certified profile does not match cadence voices, clock and pitch space','out-of-model');
  }
  const ruleDefinition=rules?freeze({id:rules.id,version:rules.version,
    ...(rules.decomposition?{decomposition:freeze({profileHash:rules.decomposition.hash})}:{})}):null;
  const definition=freeze({id,revision,clockDomain:clock,pitchSpace:space.hash,anchor,window,hitDuration,
    voices:freeze(voices),chord:freeze({roles:freeze(roles),tones:freeze(tones)}),domainComplete:spec.domainComplete,
    rules:ruleDefinition,dependencies});
  return {definition,space,rules,sourceIds,hash:hash(definition,state)};
}
const finishAudit=(status,reason,model,extra={})=>freeze({status,reason,modelHash:model.hash,scope,...extra});
// Both the independent leaf checker and certified pruning use this exact reconstruction. In particular, a
// retained crossing event is shortened only by the original explicit split contract, never to simplify a profile.
function reconstructChoice(model,index,choice,state){
  const d=model.definition,budget=state.budget,voice=d.voices[index],candidate=voice.candidates[choice.candidate],tone=d.chord.tones[choice.tone];
  const reject=reason=>freeze({status:'FAIL',reason});budget.charge();
  if(candidate.cut.cmp(d.window[0])<0||candidate.cut.cmp(d.window[1])>0||candidate.cut.cmp(voice.immutableUntil)<0)return reject('Cut is outside its declared editable window');
  const equal=model.space.equivalent(candidate.arrival.pitch,tone.pitch);
  if(equal==='UNKNOWN')return freeze({status:'UNKNOWN',reason:'Arrival pitch equality is unresolved'});
  if(equal!==true)return reject('Assigned tone differs from the actual arrival pitch');
  const prefix=[],removed=[],shortened=[],actualSplits=new Set,permitted=new Set(candidate.splitSourceIds);
  for(const event of voice.source){
    budget.charge();const end=event.t.add(event.d);
    if(event.t.cmp(candidate.cut)>=0){if(voice.locked)return reject('A locked source event would be removed');removed.push(event.id);continue}
    if(end.cmp(candidate.cut)<=0){prefix.push(event);continue}
    if(voice.locked||event.t.cmp(voice.immutableUntil)<0||!permitted.has(event.id))return reject('A source crossing the cut cannot be shortened without explicit permission');
    actualSplits.add(event.id);prefix.push(freeze({...event,d:candidate.cut.sub(event.t)}));
    shortened.push(freeze({sourceId:event.id,previousEnd:String(end),end:String(candidate.cut)}));
  }
  if(actualSplits.size!==permitted.size)return reject('Split permission must name exactly the source events crossing the cut');
  for(const event of candidate.tail){budget.charge();if(event.t.cmp(candidate.cut)<0||event.t.add(event.d).cmp(d.anchor)>0)return reject('A tail event lies outside the cut-to-anchor interval')}
  const added=[...candidate.tail,candidate.arrival],events=[...prefix,...added],usedIds=new Set;
  for(const event of added){budget.charge();if(model.sourceIds.has(event.id))return reject('A replacement event reuses a source identity')}
  for(const event of events){budget.charge();if(usedIds.has(event.id))return reject('The actual joint material has duplicate event identities');usedIds.add(event.id)}
  return freeze({status:'PASS',tone,events:freeze(events),
    assignment:freeze({voiceId:voice.id,candidateId:candidate.id,toneId:tone.id,role:tone.role,pitch:candidate.arrival.pitch}),
    tail:freeze({voiceId:voice.id,candidateId:candidate.id,cut:String(candidate.cut),prefix:freeze(prefix),tail:candidate.tail,
      arrival:candidate.arrival,removedSourceIds:freeze(removed),shortened:freeze(shortened)})});
}
function invokePredicate(state,check,{certified=false,retain=true,local=false}={}){
  const budget=state.budget,usage=state.usage;budget.charge();
  if(certified)usage.certifiedChecks++;else usage.predicateCalls++;
  const remainingWork=budget.limit-budget.used,maxWork=Math.min(local?state.limits.maxFactorWork:state.limits.maxPredicateWork,remainingWork);
  let active=true,reported=0,hasReceipt=false,debitFailure=null,reply,threw=false,refusal=null;
  const consumeWork=amount=>{
    if(!active)fail('Cadence predicate work receipt is no longer active');
    try{
      count(amount,Number.MAX_SAFE_INTEGER);
      if(amount>maxWork-reported)fail('Cadence predicate work allowance exhausted','work-budget');
      budget.charge(amount);reported+=amount;hasReceipt=true;
      if(certified)usage.reportedCertifiedWork+=amount;else usage.reportedPredicateWork+=amount;
    }catch(error){if(error instanceof Refused)debitFailure??=error;throw error}
  };
  try{reply=check(freeze({maxWork,...(certified?{}:{remainingWork}),consumeWork}))}
  catch(error){if(certified&&error instanceof Refused)refusal=error;else threw=true}
  finally{active=false}
  if(!certified){if(hasReceipt)usage.predicateCallsWithReceipts++;else usage.predicateCallsWithoutReceipts++}
  if(debitFailure)throw debitFailure;if(refusal)throw refusal;
  if(threw)return freeze({status:'UNKNOWN',evidence:null,reason:certified?'The certified profile threw':'The whole-joint predicate refused or threw'});
  let status,evidence=null;
  if(typeof reply==='string')status=reply;
  else if(retain){evidence=copy(reply,state);status=dataRecord(evidence)?evidence.status:null}
  else status=dataRecord(reply)?reply.status:null;
  if(!(local?['PASS','FAIL','UNKNOWN','N/A']:['PASS','FAIL','UNKNOWN']).includes(status))
    return freeze({status:'UNKNOWN',evidence,reason:'A predicate did not return a supported status'});
  return freeze({status,evidence});
}
function auditChoice(model,choices,state){
  state=frame(state,'leaf');
  if(!model.rules)return finishAudit('UNKNOWN','No whole-joint rule grammar was supplied',model);
  const d=model.definition,budget=state.budget,assignment=[],tails=[],all=[],usedIds=new Set,toneCounts=new Map,roleCounts=new Map;
  const reject=reason=>finishAudit('FAIL',reason,model);
  for(let i=0;i<d.voices.length;i++){
    const material=reconstructChoice(model,i,choices[i],state);
    if(material.status!=='PASS')return finishAudit(material.status,material.reason,model);
    const tone=material.tone;
    for(const event of material.events){budget.charge();if(usedIds.has(event.id))return reject('The actual joint material has duplicate event identities');usedIds.add(event.id);all.push(event)}
    toneCounts.set(tone.id,(toneCounts.get(tone.id)??0)+1);roleCounts.set(tone.role,(roleCounts.get(tone.role)??0)+1);
    assignment.push(material.assignment);tails.push(material.tail);
  }
  for(const [items,counts] of [[d.chord.tones,toneCounts],[d.chord.roles,roleCounts]])for(const item of items){budget.charge();const n=counts.get(item.id)??0;if(n<item.min||n>item.max)return reject('Chord tone or role cardinality is outside its declared bounds')}
  all.sort((a,b)=>{budget.charge();return a.t.cmp(b.t)||(a.id<b.id?-1:a.id>b.id?1:0)});
  const joint=freeze({modelHash:model.hash,anchor:d.anchor,hitDuration:d.hitDuration,clockDomain:d.clockDomain,
    chord:d.chord,assignment:freeze(assignment),tails:freeze(tails),events:freeze(all),dependencies:d.dependencies});
  const eventHash=hash(joint.events,state),witnessHash=hash(joint,state);
  // The branded profile is a model conjunct, not a caller's claim about checkJoint. Its original full audit is
  // mandatory even when all local checks pass; applicability, domain and unsupported rules remain final gates.
  let status='PASS',evidence=null,profileEvidence=null,reason='Actual retained material, tails and arrivals were checked jointly';
  if(model.rules.decomposition){
    const checked=invokePredicate(state,info=>model.rules.decomposition.audit(joint.events,{...info,maxFactorWork:state.limits.maxFactorWork}),{certified:true});
    status=checked.status;profileEvidence=checked.evidence;if(checked.reason)reason=checked.reason;
  }
  if(model.rules.check&&status!=='FAIL'){
    // Legacy trusted callbacks remain compatible. Only explicit synchronous work receipts enter our ledger.
    const checked=invokePredicate(state,info=>model.rules.check(joint,info));evidence=checked.evidence;if(checked.reason)reason=checked.reason;
    status=checked.status==='FAIL'?'FAIL':status==='UNKNOWN'||checked.status==='UNKNOWN'?'UNKNOWN':'PASS';
  }
  return finishAudit(status,reason,model,
    {contract:freeze({id:model.rules.id,version:model.rules.version}),eventHash,witnessHash,predicateEvidence:evidence,
      ...(model.rules.decomposition?{profileHash:model.rules.decomposition.hash,profileEvidence}:{}),
      assignment:joint.assignment,tails:joint.tails,events:joint.events});
}
function readChoices(model,raw,state){
  dataArray(raw,state.limits.maxVoices,'Cadence choices');if(raw.length!==model.definition.voices.length)fail('One choice per voice is required');
  const byVoice=new Map;
  for(let i=0;i<raw.length;i++){
    state.budget.charge();const c=fields(raw[i],['voiceId','candidateId','toneId']);
    for(const key of ['voiceId','candidateId','toneId'])text(c[key],state,256);
    if(byVoice.has(c.voiceId))fail('Duplicate chosen voice');byVoice.set(c.voiceId,c);
  }
  return model.definition.voices.map(voice=>{
    const c=byVoice.get(voice.id);if(!c)fail('Choice refers to a missing or undeclared voice');
    const candidate=voice.candidates.findIndex(v=>{state.budget.charge();return v.id===c.candidateId});
    const tone=model.definition.chord.tones.findIndex(v=>{state.budget.charge();return v.id===c.toneId});
    if(candidate<0||tone<0)fail('Choice refers to an undeclared candidate or tone');return {candidate,tone};
  });
}
function run(options,body){
  let state,modelHash=null;
  try{
    if(!dataRecord(options)||Object.keys(options).some(key=>!Object.hasOwn(LARGE_CADENCE_DEFAULTS,key)))fail('Invalid large-cadence limits');
    const limits={};for(const [key,value] of Object.entries(LARGE_CADENCE_DEFAULTS))limits[key]=Object.hasOwn(options,key)?count(options[key],Number.MAX_SAFE_INTEGER):value;
    const budget=new CadenceBudget(limits.maxWork);budget.charge();
    state={budget,limits:freeze(limits),events:0,snapshots:0,chars:0,phase:'model',usage:{modelTextChars:0,modelSnapshotNodes:0,
      peakTextChars:0,peakSnapshotNodes:0,peakHashChars:0,leafAudits:0,predicateCalls:0,predicateCallsWithReceipts:0,
      predicateCallsWithoutReceipts:0,reportedPredicateWork:0,certifiedChecks:0,reportedCertifiedWork:0,
      variants:0,states:0,transitions:0,flowCalls:0,fallbackLeaves:0}};
    const out=body(state,value=>{modelHash=value});
    return freeze({...out,workUsed:budget.used,resourceLimits:state.limits,resourceUsage:freeze({...state.usage})});
  }catch(error){return freeze({status:'UNKNOWN',reason:error instanceof Refused?error.message:'Large-cadence input or processing refused',
    kind:error instanceof Refused?error.kind:'invalid-input',modelHash,scope,workUsed:state?.budget.used??0,
    resourceLimits:state?.limits??null,resourceUsage:state?freeze({...state.usage}):null})}
}
function prepare(spec,state,setHash){
  const model=normalize(spec,state);setHash(model.hash);
  if(!model.rules)fail('A complete factorized profile is required','out-of-model');
  const profile=model.rules.decomposition;
  if(model.rules.id!==profile.id||model.rules.version!==profile.version)fail('Named profile identity differs from its genuine definition','out-of-model');
  const byId=new Map(model.definition.voices.map((voice,i)=>[voice.id,i]));
  model.order=profile.order.map(id=>byId.get(id));model.position=new Map(model.order.map((index,position)=>[index,position]));
  model.roleIndex=new Map(model.definition.chord.roles.map((role,i)=>[role.id,i]));
  return model;
}
function variantsOf(model,state){
  const result=[],d=model.definition,profile=model.rules.decomposition;
  for(let i=0;i<d.voices.length;i++){
    const voice=d.voices[i],variants=[];
    for(let c=0;c<voice.candidates.length;c++)for(let t=0;t<d.chord.tones.length;t++){
      state.budget.charge();const equality=model.space.equivalent(voice.candidates[c].arrival.pitch,d.chord.tones[t].pitch);
      if(equality===false)continue;
      if(state.usage.variants>=state.limits.maxVariants)fail('Large-cadence variant allowance exhausted','work-budget');state.usage.variants++;
      const choice=freeze({candidate:c,tone:t}),material=reconstructChoice(model,i,choice,state);let status=material.status,melodicExercised=false;
      if(status==='PASS'){
        const checked=invokePredicate(frame(state,'variant'),info=>profile.unary(voice.id,material.events,{...info,maxFactorWork:state.limits.maxFactorWork}),{certified:true,local:true});
        status=checked.status==='N/A'?'PASS':checked.status;melodicExercised=checked.evidence?.melodicExercised===true;
      }
      if(status!=='FAIL')variants.push(freeze({choice,material,status,melodicExercised}));
    }
    result.push(freeze(variants));
  }
  const predecessors=model.order.map(()=>new Set),byId=new Map(d.voices.map((v,i)=>[v.id,i]));
  let bandwidth=profile.bandwidth;
  for(const pair of profile.pairScopes){
    state.budget.charge();const positions=pair.voices.map(id=>model.position.get(byId.get(id))),lo=Math.min(...positions),hi=Math.max(...positions);
    predecessors[hi].add(lo);
  }
  // Keep the original conservative admission for identity collisions. Adjacent collisions become real edges;
  // accepting a wider musical band does not silently license untracked distant occurrence-ID coupling.
  const owners=new Map;
  for(let i=0;i<result.length;i++)for(const variant of result[i])if(variant.material.status==='PASS')for(const event of variant.material.events){
    state.budget.charge();let positions=owners.get(event.id);if(!positions){positions=new Set;owners.set(event.id,positions)}positions.add(model.position.get(i));
    if(positions.size>1){const values=[...positions],lo=Math.min(...values),hi=Math.max(...values);
      if(hi-lo>1)fail('Potential event-identity collision couples non-neighbour voices','out-of-model');
      predecessors[hi].add(lo);bandwidth=Math.max(bandwidth,1);
    }
  }
  return {voices:freeze(result),chain:bandwidth>0,bandwidth,
    predecessors:predecessors.map(set=>[...set].sort((a,b)=>{state.budget.charge();return a-b})),
    hasUnknown:result.some(list=>list.some(variant=>variant.status==='UNKNOWN'))};
}
function grouped(model,catalogue,possible,state){
  const groups=[];
  for(let i=0;i<catalogue.voices.length;i++){
    const byTone=new Map;
    for(const variant of catalogue.voices[i]){
      state.budget.charge();if(!possible&&variant.status!=='PASS')continue;
      const t=variant.choice.tone,old=byTone.get(t);
      if(!old||!old.melodicExercised&&variant.melodicExercised)byTone.set(t,variant);
    }
    groups.push([...byTone].sort((a,b)=>{state.budget.charge();return a[0]-b[0]}));
  }
  return groups;
}
function graphOf(model,groups,state,forced=null){
  const d=model.definition,n=d.voices.length,nodes=['S','T'],edges=[];
  const edge=(id,from,to,lower,upper)=>{state.budget.charge();edges.push({id,from,to,lower,upper})};
  for(let i=0;i<n;i++){
    state.budget.charge();nodes.push(`v${i}`);edge(`source:${i}`,'S',`v${i}`,1,1);
    for(const [tone] of groups[i])edge(`choice:${i}:${tone}`,`v${i}`,`t${tone}`,forced?.voice===i&&forced.tone===tone?1:0,1);
  }
  for(let i=0;i<d.chord.tones.length;i++){
    const tone=d.chord.tones[i];nodes.push(`t${i}`);edge(`tone:${i}`,`t${i}`,`r${model.roleIndex.get(tone.role)}`,tone.min,tone.max);
  }
  for(let i=0;i<d.chord.roles.length;i++){
    const role=d.chord.roles[i];nodes.push(`r${i}`);edge(`role:${i}`,`r${i}`,'T',role.min,role.max);
  }
  edge('return','T','S',n,n);
  return {id:`cadence:${model.hash}`,revision:0,nodes,edges};
}
function flowOptions(graph,state){return {maxWork:state.budget.limit-state.budget.used,maxNodes:graph.nodes.length,maxEdges:graph.edges.length,
  maxCertificateEntries:Math.max(graph.nodes.length,graph.edges.length),maxTextChars:state.limits.maxTextChars,maxHashChars:state.limits.maxHashChars}}
function solveGraph(graph,state){
  state.budget.charge();state.usage.flowCalls++;
  const result=solveBoundedCirculation(graph,flowOptions(graph,state));state.budget.charge(result.workUsed);
  if(result.status==='UNKNOWN')fail(result.reason??'Bounded circulation refused',result.refusalKind??result.kind??'work-budget');return result;
}
function selectionOf(flow,groups,state){
  const values=new Map(flow.certificate.flows.map(row=>[row.edgeId,row.value])),selected=[];
  for(let i=0;i<groups.length;i++){
    state.budget.charge();const matches=groups[i].filter(([tone])=>values.get(`choice:${i}:${tone}`)==='1');
    if(matches.length!==1)fail('Circulation did not reconstruct one choice per voice','out-of-model');selected.push(matches[0][1]);
  }
  return selected;
}
function coveredSelection(model,selected){return !model.rules.decomposition.requiredMelodicCoverage||selected.some(variant=>variant.melodicExercised)}
function certifiedSelection(model,selected,state){
  const audit=auditChoice(model,selected.map(variant=>variant.choice),state);
  if(audit.status!=='PASS')return finishAudit('UNKNOWN','The selected witness did not pass its independent whole factorized audit',model,{audit});
  const choices=freeze(audit.assignment.map(({voiceId,candidateId,toneId})=>freeze({voiceId,candidateId,toneId})));
  const certificate=freeze({kind:'large-cadence-assignment-v1',modelHash:model.hash,choices,eventHash:audit.eventHash,witnessHash:audit.witnessHash});
  hash(certificate,state);
  return freeze({...audit,status:'SAT',certificate,scope});
}
function unknownResult(model,reason){return finishAudit('UNKNOWN',reason,model,{certificate:null})}
function flowSearch(model,catalogue,state){
  const known=grouped(model,catalogue,false,state),baseline=solveGraph(graphOf(model,known,state),state);
  if(baseline.status==='SAT'){
    const selection=selectionOf(baseline,known,state);if(coveredSelection(model,selection))return certifiedSelection(model,selection,state);
    // Only a SAT search: unexercised required rules remain UNKNOWN, not exclusions proving UNSAT.
    for(let i=0;i<known.length;i++)for(const [tone,variant] of known[i])if(variant.melodicExercised){
      const trial=solveGraph(graphOf(model,known,state,{voice:i,tone}),state);
      if(trial.status==='SAT')return certifiedSelection(model,selectionOf(trial,known,state),state);
    }
  }
  const possible=grouped(model,catalogue,true,state),relaxation=catalogue.hasUnknown?solveGraph(graphOf(model,possible,state),state):baseline;
  if(relaxation.status==='UNSAT'&&model.definition.domainComplete){
    const certificate=freeze({kind:'large-cadence-unsat-flow-v1',modelHash:model.hash,flow:relaxation.certificate});hash(certificate,state);
    return finishAudit('UNSAT','The complete optimistic cardinality relaxation has a checked-cut witness',model,{certificate});
  }
  return unknownResult(model,model.definition.domainComplete?'A non-refuted choice remains, with unresolved predicates or required applicability':'The finite candidate catalogue is incomplete');
}
function quotaDefinitions(model){
  const n=model.definition.voices.length,out=[];
  for(const [kind,rows] of [['tone',model.definition.chord.tones],['role',model.definition.chord.roles]])for(let i=0;i<rows.length;i++){
    const row=rows[i];if(row.min>0||row.max<n)out.push({kind,index:i,min:row.min,max:row.max,exact:row.max<n});
  }
  return out;
}
function advanceCounts(model,quotas,counts,variant,state){
  const tone=variant.choice.tone,role=model.roleIndex.get(model.definition.chord.tones[tone].role),next=[];
  for(let j=0;j<quotas.length;j++){
    state.budget.charge();const bound=quotas[j],increment=(bound.kind==='tone'?tone:role)===bound.index?1:0,value=counts[j]+increment;
    if(value>bound.max)return null;next.push(bound.exact?value:Math.min(value,bound.min));
  }
  return next;
}
const stateKey=(frontier,counts,melodic,state)=>{
  state.budget.charge(1+frontier.length+counts.length);return `${frontier.join(',')}|${melodic?1:0}|${counts.join(',')}`;
};
function completeCounts(quotas,counts,state){for(let i=0;i<quotas.length;i++){state.budget.charge();if(counts[i]<quotas[i].min)return false}return true}
function pairStatus(model,left,right,leftVoice,rightVoice,state,cache){
  const key=`${leftVoice}:${left.choice.candidate}:${left.choice.tone}|${rightVoice}:${right.choice.candidate}:${right.choice.tone}`;
  state.budget.charge();if(cache.has(key))return cache.get(key);
  let status='UNKNOWN';
  if(left.material.status==='PASS'&&right.material.status==='PASS'){
    const ids=new Set,events=[];let duplicate=false;
    for(const event of [...left.material.events,...right.material.events]){state.budget.charge();if(ids.has(event.id))duplicate=true;ids.add(event.id);events.push(event)}
    if(duplicate)status='FAIL';
    else{
      const d=model.definition,profile=model.rules.decomposition;
      const checked=invokePredicate(frame(state,'pair'),info=>profile.pair(d.voices[leftVoice].id,d.voices[rightVoice].id,events,{...info,maxFactorWork:state.limits.maxFactorWork}),{certified:true,retain:false,local:true});
      status=checked.status==='N/A'?'PASS':checked.status;
    }
  }
  cache.set(key,status);return status;
}
function transition(state){
  state.budget.charge();if(state.usage.transitions>=state.limits.maxTransitions)fail('Chain transition allowance exhausted','work-budget');state.usage.transitions++;
}
function reserveState(state){
  state.budget.charge();if(state.usage.states>=state.limits.maxStates)fail('Chain state allowance exhausted','work-budget');state.usage.states++;
}
function admissibleExtension(model,catalogue,level,previous,variant,state,cache,possible){
  if(!possible&&variant.status!=='PASS')return false;
  const voice=model.order[level],start=level-previous.frontier.length;
  for(const position of catalogue.predecessors[level]){
    state.budget.charge();const previousVoice=model.order[position],index=previous.frontier[position-start];
    const before=catalogue.voices[previousVoice][index];if(!before)fail('A required pair escaped the retained frontier','out-of-model');
    const status=pairStatus(model,before,variant,previousVoice,voice,state,cache);
    if(status==='FAIL'||!possible&&status!=='PASS')return false;
  }
  return true;
}
function nextFrontier(previous,v,width,state){
  state.budget.charge(1+previous.length);return [...previous,v].slice(-width);
}
function chainSearch(model,catalogue,state,possible,cache){
  const quotas=quotaDefinitions(model),layers=[[{frontier:[],counts:quotas.map(()=>0),melodic:false,previous:-1}]];reserveState(state);
  for(let level=0;level<model.order.length;level++){
    const voice=model.order[level],domain=catalogue.voices[voice],before=layers[level],next=[],seen=new Set;
    for(let p=0;p<before.length;p++)for(let v=0;v<domain.length;v++){
      transition(state);const variant=domain[v];if(!admissibleExtension(model,catalogue,level,before[p],variant,state,cache,possible))continue;
      const counts=advanceCounts(model,quotas,before[p].counts,variant,state);if(!counts)continue;
      const frontier=nextFrontier(before[p].frontier,v,catalogue.bandwidth,state),melodic=!possible&&(before[p].melodic||variant.melodicExercised);
      const key=stateKey(frontier,counts,melodic,state);if(seen.has(key))continue;
      reserveState(state);seen.add(key);next.push({frontier,counts,melodic,previous:p});
    }
    layers.push(next);
  }
  const final=layers.at(-1),last=final.findIndex(row=>completeCounts(quotas,row.counts,state)&&(possible||!model.rules.decomposition.requiredMelodicCoverage||row.melodic));
  if(last<0)return {found:false,layers};
  const selection=Array(model.order.length);let at=last;
  for(let level=model.order.length;level>0;level--){state.budget.charge();const row=layers[level][at],voice=model.order[level-1];selection[voice]=catalogue.voices[voice][row.frontier.at(-1)];at=row.previous}
  return {found:true,selection};
}
// No state merging here: forgotten boundaries can change required coverage of an earlier held pair.
// Every optimistic history is visited unless an explicit resource limit stops the search UNKNOWN.
function fallbackSearch(model,catalogue,state,cache,tried){
  const quotas=quotaDefinitions(model),n=model.order.length,selection=Array(n);
  const stack=[{frontier:[],counts:quotas.map(()=>0),next:0}];
  while(stack.length){
    state.budget.charge();const level=stack.length-1,row=stack[level];
    if(level===n){
      if(completeCounts(quotas,row.counts,state)){
        let repeated=tried!==null;
        if(repeated)for(let i=0;i<n;i++){state.budget.charge();if(selection[i]!==tried[i]){repeated=false;break}}
        if(!repeated){
          if(state.usage.fallbackLeaves>=state.limits.maxFallbackLeaves)fail('Whole-history fallback leaf allowance exhausted','work-budget');
          state.usage.fallbackLeaves++;const result=certifiedSelection(model,selection,state);if(result.status==='SAT')return result;
        }
      }
      stack.pop();continue;
    }
    const voice=model.order[level],domain=catalogue.voices[voice];
    if(row.next>=domain.length){stack.pop();continue}
    const v=row.next++,variant=domain[v];transition(state);
    if(!admissibleExtension(model,catalogue,level,row,variant,state,cache,true))continue;
    const counts=advanceCounts(model,quotas,row.counts,variant,state);if(!counts)continue;
    selection[voice]=variant;stack.push({frontier:nextFrontier(row.frontier,v,catalogue.bandwidth,state),counts,next:0});
  }
  return unknownResult(model,'Every optimistic history was audited without a PASS; unresolved applicability or comparisons do not certify UNSAT');
}
export function auditLargeCadenceInto(spec,choices,options={}){
  return run(options,(state,setHash)=>{const model=prepare(spec,state,setHash);return auditChoice(model,readChoices(model,choices,frame(state,'choices')),state)});
}
export function largeCadenceInto(spec,options={}){
  return run(options,(state,setHash)=>{
    const model=prepare(spec,state,setHash),catalogue=variantsOf(model,state);
    if(!catalogue.chain)return flowSearch(model,catalogue,state);
    const cache=new Map,definite=chainSearch(model,catalogue,state,false,cache);let tried=null;
    if(definite.found){
      const result=certifiedSelection(model,definite.selection,state);if(result.status==='SAT')return result;tried=definite.selection;
    }
    const possible=chainSearch(model,catalogue,state,true,cache);
    if(possible.found)return fallbackSearch(model,catalogue,state,cache,tried);
    if(!model.definition.domainComplete)return unknownResult(model,'The finite candidate catalogue is incomplete');
    const band=catalogue.bandwidth>1;
    const layers=possible.layers.map(layer=>layer.map(({frontier,counts})=>band?{frontier,counts}:{last:frontier.at(-1)??-1,counts}));
    const certificate=copy({kind:band?'large-cadence-unsat-band-v1':'large-cadence-unsat-chain-v1',modelHash:model.hash,
      ...(band?{bandwidth:catalogue.bandwidth}:{}),layers},frame(state,'certificate'));
    hash(certificate,state);return finishAudit('UNSAT','Complete optimistic band-state coverage has no quota-feasible terminal state',model,{certificate});
  });
}
function checkChainCover(model,catalogue,certificate,state){
  const band=certificate.kind==='large-cadence-unsat-band-v1';
  if(band?certificate.bandwidth!==catalogue.bandwidth||catalogue.bandwidth<2:catalogue.bandwidth>1)return false;
  dataArray(certificate.layers,model.order.length+1,'Chain cover layers');if(certificate.layers.length!==model.order.length+1)return false;
  const quotas=quotaDefinitions(model),cache=new Map,layers=[];
  for(let level=0;level<certificate.layers.length;level++){
    const raw=certificate.layers[level];dataArray(raw,state.limits.maxStates,'Chain layer');const rows=[],keys=new Set;
    for(const row of raw){
      reserveState(state);fields(row,[band?'frontier':'last','counts']);let frontier;
      if(band){dataArray(row.frontier,catalogue.bandwidth,'Band frontier');frontier=row.frontier}
      else{
        if(!Number.isSafeInteger(row.last)||row.last< -1)fail('Invalid previous variant index');
        if(level===0&&row.last!==-1)return false;frontier=level===0?[]:[row.last];
      }
      if(frontier.length!==Math.min(level,Math.max(1,catalogue.bandwidth)))return false;
      for(let j=0;j<frontier.length;j++){
        state.budget.charge();const v=frontier[j],voice=model.order[level-frontier.length+j];
        if(!Number.isSafeInteger(v)||v<0||v>=catalogue.voices[voice].length)return false;
      }
      dataArray(row.counts,quotas.length,'Quota state');if(row.counts.length!==quotas.length)fail('Quota state dimension');
      for(const value of row.counts)count(value,model.order.length);
      const key=stateKey(frontier,row.counts,false,state);if(keys.has(key))return false;keys.add(key);rows.push({frontier,counts:row.counts});
    }
    layers.push({rows,keys});
  }
  const rootKey=stateKey([],quotas.map(()=>0),false,state);if(layers[0].keys.size!==1||!layers[0].keys.has(rootKey))return false;
  for(let level=0;level<model.order.length;level++){
    const voice=model.order[level],domain=catalogue.voices[voice],expected=new Set;
    for(const previous of layers[level].rows)for(let v=0;v<domain.length;v++){
      transition(state);const variant=domain[v];
      if(!admissibleExtension(model,catalogue,level,previous,variant,state,cache,true))continue;
      const counts=advanceCounts(model,quotas,previous.counts,variant,state);
      if(counts)expected.add(stateKey(nextFrontier(previous.frontier,v,Math.max(1,catalogue.bandwidth),state),counts,false,state));
    }
    const actual=layers[level+1].keys;if(expected.size!==actual.size||[...expected].some(key=>!actual.has(key)))return false;
  }
  return !layers.at(-1).rows.some(row=>completeCounts(quotas,row.counts,state));
}
export function checkLargeCadenceCertificate(spec,raw,options={}){
  return run(options,(state,setHash)=>{
    const model=prepare(spec,state,setHash),certificate=copy(raw,frame(state,'certificate'));
    const rejected=reason=>finishAudit('FAIL',reason,model,{conclusion:null}),accepted=conclusion=>finishAudit('PASS','Original-model certificate independently checked',model,{conclusion});
    if(!dataRecord(certificate))fail('A large-cadence certificate must be data');
    if(certificate.kind==='large-cadence-assignment-v1'){
      fields(certificate,['kind','modelHash','choices','eventHash','witnessHash']);
      if(certificate.modelHash!==model.hash)return rejected('Certificate model binding differs');
      const audit=auditChoice(model,readChoices(model,certificate.choices,frame(state,'choices')),state);
      if(audit.status==='UNKNOWN')return unknownResult(model,audit.reason);
      return audit.status==='PASS'&&audit.eventHash===certificate.eventHash&&audit.witnessHash===certificate.witnessHash?accepted('SAT'):rejected('Actual chosen material or full profile differs');
    }
    if(certificate.kind==='large-cadence-unsat-flow-v1'){
      fields(certificate,['kind','modelHash','flow']);if(certificate.modelHash!==model.hash||!model.definition.domainComplete)return rejected('An infeasibility certificate needs its complete original domain');
      const catalogue=variantsOf(model,state),graph=graphOf(model,grouped(model,catalogue,true,state),state),out=checkBoundedCirculation(graph,certificate.flow,flowOptions(graph,state));state.budget.charge(out.workUsed);
      if(out.status==='UNKNOWN')fail(out.reason??'Circulation certificate check refused',out.refusalKind??out.kind??'work-budget');
      return out.status==='PASS'&&out.conclusion==='UNSAT'?accepted('UNSAT'):rejected('The optimistic cardinality cut is not a verified obstruction');
    }
    if(certificate.kind==='large-cadence-unsat-chain-v1'||certificate.kind==='large-cadence-unsat-band-v1'){
      fields(certificate,['kind','modelHash','layers',...(certificate.kind==='large-cadence-unsat-band-v1'?['bandwidth']:[])]);
      if(certificate.modelHash!==model.hash||!model.definition.domainComplete)return rejected('An infeasibility certificate needs its complete original domain');
      return checkChainCover(model,variantsOf(model,state),certificate,state)?accepted('UNSAT'):rejected('The optimistic reachable-state cover is incomplete or has a feasible terminal');
    }
    fail('Unknown large-cadence certificate schema');
  });
}
