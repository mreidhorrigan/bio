// Who may say what to whom (Musebots 3.0, slice 0's third step: the implementation dossier's A009 and A071;
// docs/MUSEBOTS_3.md, "What 3.0 still lacks", 1: "no sender is checked: anyone may send a group constraints or a bot a
// lifecycle request").
//
// **The sender.** A room stamps each message with its sender (`source`): most with the sender's name, and these with its
// instance (INSTANCE_SOURCED: server.js, client-ensemble.js), so that two bots of one kind are told apart where who sent
// a message decides whether it is taken. A message with no source, or with the room's own (ROOM_SOURCES: a render's
// timeline, the room's clock and conductor, the relay), is the room's, and always taken. This is the protocol's
// discipline among cooperating bots, not security: a room does not authenticate what a client says it is.
//
// **What a group tree takes** (groups.js GroupTree.hear, which every bot keeps through framework/agent.js):
// - A group's announcement names its sender as its conductor (or, standing by, as its deputy), and a section's formation
//   names its sender as its leader; one naming another is refused, unless it comes from a conductor above.
// - Of a group's conductors heard, one conducts: the first to have begun, as the conductorbots elect among themselves
//   (election.js, the rule plex_clodbot follows), the others standing by, the next taking over once it has not been
//   heard for ELECTION.graceBars.
// - Constraints for a group are taken from the conductor of that group or of a group above it, or from the room. From a
//   conductor of another group (wrong scope), one standing by (not conducting), or a bot that never conducted (no
//   conductor), they are refused. A group none of whose conductors, nor any above, has yet been heard takes them from
//   anyone.
// - A subconductor's constraints say which of its parent's plans they narrowed (`under`: the parent group, the plan's
//   id and revision); where the tree has heard the parent's conductor revise that plan since, or say another, they are
//   stale and refused. Constraints that say none are taken as before.
// **What a bot takes:** a lifecycle request (/agent/start, stop, leave, invite) from a ManageBOT heard (on
// /broadcast/manage/presence), from a person (the page's conductor panel: coordinator 'conductor'), or from the room;
// until a ManageBOT has been heard, from anyone (framework/agent.js ingestDirectLifecycle).
// Each refusal is said, with its reason.
export const ROOM_SOURCES=Object.freeze(['timeline','conductor','clock','relay']);
export const INSTANCE_SOURCED=Object.freeze(new Set(['/broadcast/group','/broadcast/group/constraints','/broadcast/group/formation',
  '/broadcast/manage/presence','/agent/start','/agent/stop','/agent/leave','/agent/invite']));
export const LIFECYCLE_ADDRESSES=Object.freeze(['/agent/start','/agent/stop','/agent/leave','/agent/invite']);
// The coordinator a person's request carries (conductor-controls.js lifecycleRequest).
export const PERSON_COORDINATOR='conductor';
export const instanceSourced=address=>INSTANCE_SOURCED.has(address);
// Whether a sender is the room itself (a host-qualified one too: `host::conductor`).
export function fromRoom(source){
  if(source===undefined||source===null||source==='')return true;
  return ROOM_SOURCES.includes(String(source).split('::').at(-1));
}
