// Astra's planner-law guard (research/fugue-and-coordination/candidates/orchestra45-acceptance.js, OA1-OA4/P238, their
// review of orchestra-45's adoption): every binding term of the planner's own scoring law (counterpoint.js lineCost)
// replayed on an actual proposed line, beside the exact-profile certificate it supplements, and an original line's
// numbers bound to the model's. It preserves the Number planner's stated law, not acoustic truth.
import {lineCost} from './counterpoint.js';
import {dataArray,dataRecord} from './contract-data.js';
import {exactOf,exactOfNumber,exactText,add,compare,pythonJson,sha256} from '../bounded-exact.js';

const scalarRules=['unpreparedDissonance','parallelPerfect','directPerfect','similar','unrecovered','unison','crossing','repeated'];
const kinds=['perfect','imperfect','dissonant'],keys=['pitch','start','length'];
const refuse=message=>{throw new Error(message)};
const finite=x=>{if(typeof x!=='number'||!Number.isFinite(x))refuse('Finite original Number required');return x};
const ordinary=(v,allowed)=>{if(!dataRecord(v)||Object.keys(v).some(k=>!allowed.includes(k))||allowed.some(k=>!Object.hasOwn(v,k)))refuse('Complete ordinary data fields required');return v};

// Preserve the shortest round-tripping spelling supplied by the Number planner, without a six-decimal snap.
// This is explicit Number-as-decimal semantics, not proof that a binary64 value equals that ideal real decimal.
export const exactPlannerNumber=value=>exactText(exactOfNumber(finite(value)));

export function checkPlannerLineBinding(actual,modeled){
  try{
    dataArray(actual,256);dataArray(modeled,256);if(actual.length!==modeled.length)return {status:'FAIL',reason:'Different event counts'};
    const mismatches=[];for(let i=0;i<actual.length;i++){
      ordinary(actual[i],keys);ordinary(modeled[i],keys);
      for(const key of keys){const a=exactOfNumber(finite(actual[i][key])),b=modeled[i][key];
        if(typeof b!=='string'||b.length>160||!/^[-+]?[0-9]+(?:\/[0-9]+)?$/.test(b))refuse('Modeled values must be bounded integer/fraction text');
        if(compare(a,exactOf(b)))mismatches.push({index:i,field:key,actual:exactText(a),modeled:exactText(exactOf(b))});
      }
    }
    return {status:mismatches.length?'FAIL':'PASS',scope:'original-number-spelling-to-exact-model',mismatches};
  }catch(e){return {status:'UNKNOWN',reason:e.message}}
}

// Project ALL weights of the legacy noteCost law to zero or one according to an explicit authored binding weight.
// Original leapMost stays a bound. Original interval rounding, .05 motion/leap allowances, heard-partner selection
// and soundingIn semantics stay in lineCost and must be named in any adoption claim; this does not endorse them.
export function auditPlannerHardRules({line,against,rules,strong,above,bindingWeight}){
  try{
    finite(bindingWeight);if(bindingWeight<=0)refuse('Declare a positive rule-binding weight');
    if(typeof strong!=='function'||![null,true,false].includes(above))refuse('Declare metric predicate and voice-order scope');
    ordinary(rules,['strong','weak',...scalarRules,'leapMost',...(Object.hasOwn(rules,'leaps')?['leaps']:[])]);
    const hard=value=>{finite(value);if(value<0)refuse('Nonnegative rule weights required');return value>=bindingWeight?1:0};
    const projected={},originalRules={};for(const place of ['strong','weak']){ordinary(rules[place],kinds);originalRules[place]=Object.freeze({...rules[place]});projected[place]=Object.freeze(Object.fromEntries(kinds.map(k=>[k,hard(originalRules[place][k])])))}
    for(const key of scalarRules){originalRules[key]=rules[key];projected[key]=hard(originalRules[key])}originalRules.leapMost=projected.leapMost=finite(rules.leapMost);if(rules.leaps){dataArray(rules.leaps,8);originalRules.leaps=Object.freeze(rules.leaps.map(pair=>{dataArray(pair,2);return Object.freeze(pair.map(finite))}))}if(projected.leapMost<0)refuse('Nonnegative leap bound required');Object.freeze(originalRules);
    let count=0;const notes=raw=>{dataArray(raw,256);count+=raw.length;if(count>1024)refuse('Review candidate note allowance');let previous=null;
      return raw.map(n=>{ordinary(n,keys);const note=Object.fromEntries(keys.map(k=>[k,finite(n[k])]));
        if(note.start<0||note.length<=0)refuse('Nonnegative starts and positive lengths required');
        const t=exactOfNumber(note.start),d=exactOfNumber(note.length);
        if(previous&&compare(previous,t)>0)refuse('Declare sorted monophonic lines before legacy-law replay');previous=add(t,d);return Object.freeze(note)});
    };
    const original=notes(line);dataArray(against,32);const partners=against.map(notes),binding={line:original,against:partners,rules:originalRules,bindingWeight,above};
    // Freeze the authored metric result at every note onset. Its meaning remains an external premise.
    const positions=new Map;for(const note of original){const v=strong(note.start);if(typeof v!=='boolean')refuse('Metric predicate must return a Boolean');positions.set(note.start,v)}
    const score=lineCost({line:original,against:partners,rules:projected,strong:t=>positions.get(t),above});
    if(!Number.isFinite(score)||score<0)refuse('Unexpected original hard-rule score');
    return Object.freeze({status:score===0?'PASS':'FAIL',scope:'declared-original-number-planner-hard-rules',hardCost:score,
      bindingHash:sha256(pythonJson({...binding,metric:[...positions]})),projectedRules:Object.freeze(projected),
      reason:score===0?'No binding term of the original scoring law fired':'At least one binding term of the original scoring law fired'});
  }catch(e){return Object.freeze({status:'UNKNOWN',reason:e.message,scope:'declared-original-number-planner-hard-rules'})}
}
