// CFM034 / DC05: exact fixed-study tolerance confidence, never a hard support bound.
// True full trial vectors must be IID; a fresh future trial is independent with the same law.
import {dataArray,dataRecord} from './contract-data.js';
import {Refused,EXACT_LIMITS,ZERO,ONE,add,sub,div,abs,compare,exactOf,exactText,pythonJson,sha256} from '../bounded-exact.js';

export const CALIBRATION_TOLERANCE_LIMITS=Object.freeze({maxTrials:16384,maxRoles:32,maxTrainingUnits:16384,
  maxProbabilityBits:262144,maxWork:20000000,maxDataNodes:524288,maxTextChars:16777216,maxCertificateChars:1048576});
const freeze=Object.freeze,models=new WeakMap,scope='fixed-study-iid-trial-statistical-tolerance';
const fail=(message,kind='invalid-input')=>{throw new Refused(message,{kind})};
class BadCertificate extends Error {}
const demand=(condition,message)=>{if(!condition)throw new BadCertificate(message)};
function stateOf(options){
  if(!dataRecord(options)||Object.keys(options).some(k=>!Object.hasOwn(CALIBRATION_TOLERANCE_LIMITS,k)))fail('Unknown calibration options');
  const limits={};for(const [k,cap] of Object.entries(CALIBRATION_TOLERANCE_LIMITS)){
    const n=Object.hasOwn(options,k)?options[k]:k==='maxWork'?2000000:cap;
    if(!Number.isSafeInteger(n)||n<0||n>cap)fail('Bounded nonnegative integer allowances required');limits[k]=n;
  }
  const s={limits:freeze(limits),used:0,nodes:0,chars:0,modelHash:null};
  s.charge=(n=1)=>{if(!Number.isSafeInteger(n)||n<0)throw new Error('Invalid work charge');
    if(n>limits.maxWork-s.used)fail('Calibration work allowance exhausted','work-budget');s.used+=n};
  s.visit=(n=1)=>{s.charge(n);if(n>limits.maxDataNodes-s.nodes)fail('Calibration data/output allowance','shape-budget');s.nodes+=n};
  s.m={};for(const [k,fn] of Object.entries({add,sub,div,cmp:compare}))s.m[k]=(a,b)=>{s.charge();return fn(a,b)};
  s.charge();return s;
}
function fields(v,keys,s){s.visit(keys.length+1);if(!dataRecord(v)||Object.keys(v).length!==keys.length||keys.some(k=>!Object.hasOwn(v,k)))fail('Missing or unsupported calibration fields');return v}
function list(v,cap,s,label){if(!Array.isArray(v)||v.length>cap)fail(label+' allowance','shape-budget');s.visit(v.length+1);return dataArray(v,cap,label)}
function text(v,s,cap=256){if(typeof v!=='string'||!v.length||v.length>cap)fail('Bounded nonempty text required');
  if(v.length>s.limits.maxTextChars-s.chars)fail('Calibration text allowance','work-budget');s.chars+=v.length;s.charge(1+Math.ceil(v.length/64));return v}
function revision(v){if(!Number.isSafeInteger(v)||v<0)fail('Nonnegative safe revision required');return v}
function unique(seen,id){if(seen.has(id))fail('Duplicate calibration identity or unit');seen.add(id);return id}
function digest(v,s){text(v,s,64);if(!/^[0-9a-f]{64}$/.test(v))fail('Lowercase SHA-256 reference required');return v}
function reference(v,s){fields(v,['id','revision','hash'],s);return freeze({id:text(v.id,s),revision:revision(v.revision),hash:digest(v.hash,s)})}
function rational(v,s,bits=EXACT_LIMITS.inputBits){
  s.charge();let n,d=1n;const bound=1n<<BigInt(bits);
  const integer=x=>{const q=typeof x==='bigint'?x:Number.isSafeInteger(x)?BigInt(x):null;
    if(q===null||q<=-bound||q>=bound)fail('Raw exact component allowance','arithmetic-budget');return q};
  if(typeof v==='string'){text(v,s,bits===EXACT_LIMITS.inputBits?160:6000);const m=v.match(/^([+-]?[0-9]+)(?:\/([+-]?[0-9]+))?$/);
    if(!m||m[0].length!==v.length)fail('Use exact integer or fraction text');n=integer(BigInt(m[1]));d=integer(BigInt(m[2]??'1'));
  }else if(v&&typeof v==='object'){fields(v,['n','d'],s);n=integer(v.n);d=integer(v.d)}else n=integer(v);
  if(!d)fail('Zero denominator');return exactOf({n,d},{bits});
}
function probability(v,s){const q=rational(v,s);if(q.n<=0n||q.n>=q.d)fail('Coverage and failure probability must be strictly between zero and one');return q}
function policy(v,s){fields(v,['id','revision','coverage','confidenceFailure'],s);return freeze({id:text(v.id,s),revision:revision(v.revision),coverage:probability(v.coverage,s),confidenceFailure:probability(v.confidenceFailure,s)})}
function encode(v,s,cap=s.limits.maxTextChars){const value=pythonJson(v);if(value.length>cap)fail('Canonical calibration text allowance','work-budget');s.charge(1+Math.ceil(value.length/64));return value}
function wire(v,s){s.visit();if(typeof v==='string')return v.length?text(v,s,100000):v;
  if(v&&typeof v==='object'){
    if(typeof v.n==='bigint'&&typeof v.d==='bigint')return text(exactText(v),s,6000);
    if(Array.isArray(v))return freeze(v.map(x=>wire(x,s)));
    return freeze(Object.fromEntries(Object.entries(v).map(([k,x])=>[text(k,s),wire(x,s)])));
  }return v;
}
const bits=x=>x===0n?0:x.toString(2).length;
function capped(v,s){if(v<0n||bits(v)>s.limits.maxProbabilityBits)fail('Exact probability integer allowance','arithmetic-budget');return v}
function imul(a,b,s){const x=bits(a),y=bits(b);s.charge(1+Math.ceil(x/256)*Math.ceil(y/256));
  if(a&&b&&x+y-1>s.limits.maxProbabilityBits)fail('Exact probability product allowance','arithmetic-budget');return capped(a*b,s)}
function iadd(a,b,s){s.charge(1+Math.ceil(Math.max(bits(a),bits(b))/256));return capped(a+b,s)}
function idiv(a,b,s){s.charge(2+2*Math.ceil(bits(a)/256)*Math.ceil(bits(b)/256));if(!b||a%b)throw new Error('Nonintegral binomial recurrence');return capped(a/b,s)}
function power(a,n,s,reverse=false){
  let out=capped(1n,s);a=capped(a,s);
  if(reverse){for(const digit of n.toString(2)){out=imul(out,out,s);if(digit==='1')out=imul(out,a,s)}return out}
  let k=n;while(k){s.charge();if(k%2)out=imul(out,a,s);k=Math.floor(k/2);if(k)a=imul(a,a,s)}return out;
}
function massAtMaximum(n,p,s,reverse=false){return {numerator:power(p.n,n,s,reverse),denominator:power(p.d,n,s,reverse)}}
function meets(a,delta,s){return imul(a.numerator,delta.d,s)<=imul(a.denominator,delta.n,s)}
function pair(a,s){return freeze({numerator:text(a.numerator.toString(),s,100000),denominator:text(a.denominator.toString(),s,100000)})}
function checkPair(raw,expected,s){fields(raw,['numerator','denominator'],s);text(raw.numerator,s,100000);text(raw.denominator,s,100000);
  demand(raw.numerator===expected.numerator.toString()&&raw.denominator===expected.denominator.toString(),'Probability pair differs from the original exact sum');}
function rankFor(n,p,delta,s){
  const maximum=massAtMaximum(n,p,s);if(!n||!meets(maximum,delta,s))return {rank:null,failure:maximum,previous:null};
  const d=maximum.denominator,b=p.d-p.n;let k=n,w=maximum.numerator,tail=w,chosen;
  while(k>=1){s.charge();chosen={rank:k,failure:{numerator:tail,denominator:d}};
    w=idiv(imul(imul(w,BigInt(k),s),b,s),imul(BigInt(n-k+1),p.n,s),s);tail=iadd(tail,w,s);k--;
    const previous={numerator:tail,denominator:d};if(!meets(previous,delta,s))return {...chosen,previous};
  }throw new Error('Rank zero cannot satisfy a failure probability below one');
}
function checkedTails(n,p,r,s){
  const denominator=power(p.d,n,s,true),b=p.d-p.n;let w=power(b,n,s,true),lower=0n,beforeLast=0n;
  for(let k=0;k<r;k++){s.charge();beforeLast=lower;lower=iadd(lower,w,s);
    if(k+1<r)w=idiv(imul(imul(w,BigInt(n-k),s),p.n,s),imul(BigInt(k+1),b,s),s);
  }
  return {failure:{numerator:denominator-lower,denominator},previous:{numerator:denominator-beforeLast,denominator}};
}
function result(s,status,reason,extra={}){return freeze({status,reason,scope,modelHash:s?.modelHash??null,workUsed:s?.used??0,resourceLimits:s?.limits??null,...extra})}
function run(options,body){let s;try{s=stateOf(options);return body(s)}catch(e){return result(s,e instanceof BadCertificate?'FAIL':'UNKNOWN',e.message??'Calibration refused',
  {kind:e instanceof Refused?e.kind:e instanceof BadCertificate?'invalid-certificate':'internal-error',conclusion:null,certificate:null})}}
export function planCalibrationTrials(rawPolicy,options={}){return run(options,s=>{
  const p=policy(rawPolicy,s);s.modelHash=sha256(encode(p,s));const limit=s.limits.maxTrials;let low=0,high=Math.min(1,limit),at=massAtMaximum(high,p.coverage,s);
  while(high<limit&&!meets(at,p.confidenceFailure,s)){low=high;high=Math.min(limit,high*2);at=massAtMaximum(high,p.coverage,s)}
  if(!meets(at,p.confidenceFailure,s)){
    const certificate=wire({kind:'calibration-trial-plan-v1',policyHash:s.modelHash,conclusion:'BEYOND_LIMIT',count:limit,limit,atCount:pair(at,s),previousCount:null},s);
    encode(certificate,s,s.limits.maxCertificateChars);return result(s,'INSUFFICIENT','No observed-maximum count within this ceiling meets the criterion',{conclusion:'BEYOND_LIMIT',minimumTrials:null,moreThan:limit,certificate});
  }
  while(high-low>1){const middle=Math.floor((low+high)/2);if(meets(massAtMaximum(middle,p.coverage,s),p.confidenceFailure,s))high=middle;else low=middle}
  at=massAtMaximum(high,p.coverage,s);const before=massAtMaximum(high-1,p.coverage,s);
  const certificate=wire({kind:'calibration-trial-plan-v1',policyHash:s.modelHash,conclusion:'MINIMUM_COUNT',count:high,limit,atCount:pair(at,s),previousCount:pair(before,s)},s);
  encode(certificate,s,s.limits.maxCertificateChars);return result(s,'PASS','Least fixed count for the observed-maximum criterion',{conclusion:'MINIMUM_COUNT',minimumTrials:high,certificate});
})}
export function checkCalibrationTrialPlan(rawPolicy,raw,options={}){return run(options,s=>{
  const p=policy(rawPolicy,s);s.modelHash=sha256(encode(p,s));fields(raw,['kind','policyHash','conclusion','count','limit','atCount','previousCount'],s);
  demand(raw.kind==='calibration-trial-plan-v1'&&raw.policyHash===s.modelHash,'Wrong calibration policy or plan kind');
  const count=revision(raw.count),limit=revision(raw.limit);if(limit>s.limits.maxTrials)fail('Trial-plan ceiling exceeds this allowance','shape-budget');
  demand(count<=limit,'Trial count exceeds its own ceiling');const at=massAtMaximum(count,p.coverage,s,true);checkPair(raw.atCount,at,s);
  if(raw.conclusion==='BEYOND_LIMIT')demand(count===limit&&raw.previousCount===null&&!meets(at,p.confidenceFailure,s),'Unsupported insufficient-count claim');
  else{demand(raw.conclusion==='MINIMUM_COUNT'&&count>=1,'Unsupported minimum-count claim');const before=massAtMaximum(count-1,p.coverage,s,true);
    checkPair(raw.previousCount,before,s);demand(meets(at,p.confidenceFailure,s)&&!meets(before,p.confidenceFailure,s),'Adjacent powers do not prove the minimum');}
  encode(raw,s,s.limits.maxCertificateChars);return result(s,'PASS','Original adjacent-power claim checked',{conclusion:raw.conclusion,minimumTrials:raw.conclusion==='MINIMUM_COUNT'?count:null,moreThan:raw.conclusion==='BEYOND_LIMIT'?limit:null});
})}
function normalize(raw,s){
  fields(raw,['id','revision','policy','source','clockDomain','contextHash','evidenceLayer','score','collection','roles','trials'],s);
  fields(raw.source,['id','revision','hash','known'],s);if(raw.source.known!==true)fail('Unknown sources cannot receive a calibration claim','unknown-evidence');
  const source=freeze({id:text(raw.source.id,s),revision:revision(raw.source.revision),hash:digest(raw.source.hash,s),known:true});
  fields(raw.clockDomain,['id','unit','revision'],s);const clockDomain=freeze({id:text(raw.clockDomain.id,s),unit:text(raw.clockDomain.unit,s),revision:revision(raw.clockDomain.revision)});
  const contextHash=digest(raw.contextHash,s);if(!['measured','emitted','synthetic'].includes(raw.evidenceLayer))fail('Declare an observed or synthetic evidence layer','unknown-evidence');
  fields(raw.score,['kind','definition','fixedBeforeTrials','trainingUnitIds'],s);
  if(!['max-absolute','relative-spread','absolute-mean'].includes(raw.score.kind)||raw.score.fixedBeforeTrials!==true)fail('An admitted score fixed before calibration is required','unknown-evidence');
  const training=new Set;for(const id of list(raw.score.trainingUnitIds,s.limits.maxTrainingUnits,s,'Training units'))unique(training,text(id,s));
  const score=freeze({kind:raw.score.kind,definition:reference(raw.score.definition,s),fixedBeforeTrials:true,trainingUnitIds:freeze([...training])});
  fields(raw.collection,['id','revision','hash','kind','fixedBeforeTrials','complete','sameFutureLaw','futureIndependent','trials'],s);
  const c=raw.collection;if(c.kind!=='fixed-count-iid-trials'||c.fixedBeforeTrials!==true||c.complete!==true||c.sameFutureLaw!==true||c.futureIndependent!==true)
    fail('Complete fixed-count IID trials and a fresh independent future trial under the same law are required','unknown-evidence');
  const planned=[],plannedById=new Map,ids=new Set,units=new Set;
  for(const item of list(c.trials,s.limits.maxTrials,s,'Planned trials')){fields(item,['id','unitId'],s);
    const id=unique(ids,text(item.id,s)),unitId=unique(units,text(item.unitId,s));if(training.has(unitId))fail('Training and calibration units overlap','unknown-evidence');
    const entry=freeze({id,unitId});planned.push(entry);plannedById.set(id,entry);}
  const collection=freeze({id:text(c.id,s),revision:revision(c.revision),hash:digest(c.hash,s),kind:c.kind,fixedBeforeTrials:true,complete:true,sameFutureLaw:true,futureIndependent:true,trials:freeze(planned)});
  const roles=[],roleSet=new Set;for(const id of list(raw.roles,s.limits.maxRoles,s,'Required roles'))roles.push(unique(roleSet,text(id,s)));
  if(!roles.length)fail('A nonempty independent role inventory is required');const observed=new Map;
  for(const t of list(raw.trials,s.limits.maxTrials,s,'Observed trials')){
    fields(t,['id','unitId','sourceHash','contextHash','evidenceLayer','complete','reference','bounds'],s);const id=text(t.id,s),unitId=text(t.unitId,s);
    if(observed.has(id))fail('Duplicate observed trial');if(plannedById.get(id)?.unitId!==unitId)fail('Trial does not match the independent collection inventory','unknown-evidence');
    if(t.complete!==true||t.sourceHash!==source.hash||t.contextHash!==contextHash||t.evidenceLayer!==raw.evidenceLayer)fail('Incomplete, changed-context or mixed-layer trial','unknown-evidence');
    const bounds=new Map;for(const v of list(t.bounds,s.limits.maxRoles,s,'Role enclosures')){
      fields(v,['roleId','kind','lo','hi'],s);const roleId=text(v.roleId,s);if(!roleSet.has(roleId)||bounds.has(roleId))fail('Missing, extra or duplicate required role');
      if(v.kind!=='absolute-bound'||v.lo===null||v.hi===null)fail('Genuine complete measurement enclosures required','unknown-evidence');
      const lo=rational(v.lo,s),hi=rational(v.hi,s);if(s.m.cmp(lo,hi)>0)fail('Reversed measurement enclosure');bounds.set(roleId,freeze({roleId,kind:v.kind,lo,hi}));
    }
    if(bounds.size!==roles.length)fail('Every required role must be observed in every trial','unknown-evidence');
    observed.set(id,freeze({id,unitId,sourceHash:source.hash,contextHash,evidenceLayer:raw.evidenceLayer,complete:true,reference:reference(t.reference,s),bounds:freeze(roles.map(id=>bounds.get(id)))}));
  }
  if(observed.size!==planned.length)fail('Missing trials cannot be discarded from a calibration study','unknown-evidence');
  return freeze({kind:'calibration-tolerance-study-v1',id:text(raw.id,s),revision:revision(raw.revision),policy:policy(raw.policy,s),source,clockDomain,contextHash,evidenceLayer:raw.evidenceLayer,
    score,collection,roles:freeze(roles),trials:freeze(planned.map(p=>observed.get(p.id)))});
}
export function prepareCalibrationTolerance(raw,options={}){return run(options,s=>{
  const definition=normalize(raw,s),encoded=encode(definition,s);s.modelHash=sha256(encoded);
  const prepared=freeze({kind:'prepared-calibration-tolerance-v1',id:definition.id,modelHash:s.modelHash}),size={nodes:s.nodes,text:encoded.length};
  const out=result(s,'PASS','Prepared complete declared fixed-study observations',{prepared,sampleCount:definition.trials.length,roles:definition.roles.length,evidenceLayer:definition.evidenceLayer});
  models.set(prepared,{definition,size});return out;
})}
function modelOf(prepared,s){const m=models.get(prepared);if(!m)fail('Use an authentic prepared calibration study','out-of-model');s.modelHash=prepared.modelHash;
  const d=m.definition;if(d.trials.length>s.limits.maxTrials||d.roles.length>s.limits.maxRoles||d.score.trainingUnitIds.length>s.limits.maxTrainingUnits||m.size.nodes>s.limits.maxDataNodes||m.size.text>s.limits.maxTextChars)fail('Prepared calibration exceeds current allowances','shape-budget');return d}
function scoreTrial(t,kind,s){
  const v=t.bounds;let u=ZERO;
  if(kind==='max-absolute'){for(const b of v){s.charge();for(const x of [abs(b.lo),abs(b.hi)])if(s.m.cmp(x,u)>0)u=x}return u}
  if(kind==='absolute-mean'){let lo=ZERO,hi=ZERO;for(const b of v){lo=s.m.add(lo,b.lo);hi=s.m.add(hi,b.hi)}
    lo=abs(s.m.div(lo,exactOf(v.length)));hi=abs(s.m.div(hi,exactOf(v.length)));return s.m.cmp(lo,hi)>0?lo:hi;}
  if(v.length===1)return ZERO;
  let first=0,second=1;if(s.m.cmp(v[first].lo,v[second].lo)>0)[first,second]=[second,first];
  for(let j=2;j<v.length;j++){if(s.m.cmp(v[j].lo,v[first].lo)<0){second=first;first=j}else if(s.m.cmp(v[j].lo,v[second].lo)<0)second=j}
  for(let j=0;j<v.length;j++){const difference=s.m.sub(v[j].hi,v[j===first?second:first].lo);if(s.m.cmp(difference,u)>0)u=difference}return u;
}
function scoreAll(d,s){return d.trials.map(t=>{s.charge();return scoreTrial(t,d.score.kind,s)})}
function report(d,rank,radius,s){return wire({kind:'statistical-tolerance',id:d.id,revision:d.revision,unit:d.clockDomain.unit,bound:radius,
  populationCoverage:d.policy.coverage,confidence:s.m.sub(ONE,d.policy.confidenceFailure),sampleCount:d.trials.length,rank,score:d.score.kind,
  evidenceLayer:d.evidenceLayer,source:d.source,clockDomain:d.clockDomain,contextHash:d.contextHash,registration:d.collection.hash,scope},s)}
export function certifyCalibrationTolerance(prepared,options={}){return run(options,s=>{
  const d=modelOf(prepared,s),n=d.trials.length,a=rankFor(n,d.policy.coverage,d.policy.confidenceFailure,s);let radius=null;
  if(a.rank!==null){const scores=scoreAll(d,s);scores.sort((x,y)=>s.m.cmp(x,y));radius=scores[a.rank-1]}
  const conclusion=a.rank===null?'INSUFFICIENT_SAMPLE':'STATISTICAL_TOLERANCE';
  const certificate=wire({kind:'calibration-tolerance-v1',modelHash:s.modelHash,conclusion,rank:a.rank,radius,failure:pair(a.failure,s),previousFailure:a.previous?pair(a.previous,s):null},s);
  encode(certificate,s,s.limits.maxCertificateChars);
  return result(s,a.rank===null?'INSUFFICIENT':'CERTIFIED',a.rank===null?'No order rank meets the declared confidence criterion':'Conditional population tolerance, not a hard support bound',
    {conclusion,certificate,tolerance:a.rank===null?null:report(d,a.rank,radius,s)});
})}
export function checkCalibrationTolerance(prepared,raw,options={}){return run(options,s=>{
  const d=modelOf(prepared,s),n=d.trials.length;fields(raw,['kind','modelHash','conclusion','rank','radius','failure','previousFailure'],s);
  demand(raw.kind==='calibration-tolerance-v1'&&raw.modelHash===s.modelHash,'Changed calibration study or certificate kind');let tolerance=null,canonical;
  if(raw.conclusion==='INSUFFICIENT_SAMPLE'){
    const at=massAtMaximum(n,d.policy.coverage,s,true);checkPair(raw.failure,at,s);
    demand(raw.rank===null&&raw.radius===null&&raw.previousFailure===null&&!meets(at,d.policy.confidenceFailure,s),'Unsupported insufficient-sample claim');
    canonical={...raw,failure:pair(at,s)};
  }else{
    demand(raw.conclusion==='STATISTICAL_TOLERANCE'&&Number.isSafeInteger(raw.rank)&&raw.rank>=1&&raw.rank<=n,'Unsupported calibration rank or conclusion');
    const a=checkedTails(n,d.policy.coverage,raw.rank,s);checkPair(raw.failure,a.failure,s);checkPair(raw.previousFailure,a.previous,s);
    demand(meets(a.failure,d.policy.confidenceFailure,s)&&!meets(a.previous,d.policy.confidenceFailure,s),'Adjacent tails do not certify the least supported rank');
    const radius=rational(raw.radius,s,EXACT_LIMITS.workBits);demand(radius.n>=0n,'Negative score bound');const scores=scoreAll(d,s);let less=0,atMost=0;
    for(const u of scores){const c=s.m.cmp(u,radius);if(c<0)less++;if(c<=0)atMost++}
    demand(less<raw.rank&&atMost>=raw.rank,'Claimed bound is not the original order statistic');tolerance=report(d,raw.rank,radius,s);
    canonical={...raw,radius,failure:pair(a.failure,s),previousFailure:pair(a.previous,s)};
  }
  encode(wire(canonical,s),s,s.limits.maxCertificateChars);return result(s,'PASS','Original score ranks and exact confidence claim checked',{conclusion:raw.conclusion,tolerance});
})}
