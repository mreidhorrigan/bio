// CFM032 / EC07: continuous target-knot optimization, with the original whole musical union required for admission.
import {dataArray,dataRecord} from './contract-data.js';
import {compilePitchOperations} from './pitch-spaces.js';
import {decomposeCounterpointProfile} from './counterpoint-profile.js';
import {prepareFragmentSplice,auditFragmentSplice,checkFragmentSplice} from './fragment-splice.js';
import {Refused,EXACT_LIMITS,ZERO,ONE,add,sub,mul,div,compare,exactOf,exactText,pythonJson,sha256} from '../bounded-exact.js';

export const POSITIVE_WARP_LIMITS=Object.freeze({maxLines:16,maxKnots:128,maxEvents:2048,maxChannels:64,maxRelations:128,
  maxContexts:256,maxDependencies:128,maxArcs:2048,maxPathEdges:4096,maxWork:20000000,maxMusicalWork:2000000,
  maxTextChars:4194304,maxDataNodes:65536});
const freeze=Object.freeze,models=new WeakMap,scope='original-positive-pwl-timing-and-complete-joint-profile';
const fail=(message,kind='invalid-input')=>{throw new Refused(message,{kind})};
class BadCertificate extends Error {}
const demand=(condition,message)=>{if(!condition)throw new BadCertificate(message)};
function stateOf(options){
  if(!dataRecord(options)||Object.keys(options).some(k=>!Object.hasOwn(POSITIVE_WARP_LIMITS,k)))fail('Unknown positive-warp options');
  const limits={};for(const [key,cap] of Object.entries(POSITIVE_WARP_LIMITS)){
    const value=Object.hasOwn(options,key)?options[key]:key==='maxWork'?2000000:key==='maxMusicalWork'?600000:cap;
    if(!Number.isSafeInteger(value)||value<0||value>cap)fail('Bounded nonnegative integer allowances required');limits[key]=value;
  }
  const s={limits:freeze(limits),used:0,chars:0,dataNodes:0,modelHash:null};
  s.charge=(n=1)=>{if(!Number.isSafeInteger(n)||n<0)throw new Error('Invalid warp work charge');
    if(n>limits.maxWork-s.used)fail('Positive-warp work allowance exhausted','work-budget');s.used+=n};
  s.m={};for(const [key,fn] of Object.entries({add,sub,mul,div,cmp:compare}))s.m[key]=(a,b)=>{s.charge();return fn(a,b)};
  s.charge();return s;
}
function fields(v,keys,s){s.charge();if(!dataRecord(v)||Object.keys(v).length!==keys.length||keys.some(k=>!Object.hasOwn(v,k)))fail('Missing or unsupported warp fields');s.charge(keys.length);return v}
function list(v,cap,s,label){if(!Array.isArray(v)||v.length>cap)fail(label+' allowance','shape-budget');s.charge(v.length+1);return dataArray(v,cap,label)}
function text(v,s,cap=256){if(typeof v!=='string'||!v.length||v.length>cap)fail('Bounded nonempty text required');
  if(v.length>s.limits.maxTextChars-s.chars)fail('Warp text allowance','work-budget');s.chars+=v.length;s.charge(1+Math.ceil(v.length/64));return v}
function revision(v){if(!Number.isSafeInteger(v)||v<0)fail('Nonnegative safe revision required');return v}
function boolean(v){if(typeof v!=='boolean')fail('Declare completeness explicitly');return v}
function unique(seen,id){if(seen.has(id))fail('Duplicate warp identity');seen.add(id);return id}
function rational(v,s,bits=EXACT_LIMITS.inputBits){
  s.charge();let n,d=1n;const boundary=1n<<BigInt(bits);
  const integer=x=>{const q=typeof x==='bigint'?x:Number.isSafeInteger(x)?BigInt(x):null;
    if(q===null||q<=-boundary||q>=boundary)fail('Raw exact component allowance','arithmetic-budget');return q};
  if(typeof v==='string'){
    text(v,s,bits===EXACT_LIMITS.inputBits?160:6000);const match=v.match(/^([+-]?[0-9]+)(?:\/([+-]?[0-9]+))?$/);
    if(!match||match[0].length!==v.length)fail('Use exact integer or fraction text');n=integer(BigInt(match[1]));d=integer(BigInt(match[2]??'1'));
  }else if(v&&typeof v==='object'){fields(v,['n','d'],s);n=integer(v.n);d=integer(v.d)}else n=integer(v);
  if(!d)fail('Zero denominator');return exactOf({n,d},{bits});
}
function nonnegative(v,s){const q=rational(v,s);if(q.n<0n)fail('Negative time or magnitude');return q}
function positive(v,s){const q=rational(v,s);if(q.n<=0n)fail('Strictly positive duration, rate or normalizer required');return q}
function sides(v,s,read){fields(v,['minus','plus'],s);return freeze({minus:read(v.minus,s),plus:read(v.plus,s)})}
function clock(v,s){fields(v,['id','unit','revision'],s);return freeze({id:text(v.id,s),unit:text(v.unit,s),revision:revision(v.revision)})}
const sameClock=(a,b)=>a.id===b.id&&a.unit===b.unit&&a.revision===b.revision;
function reference(v,s){fields(v,['id','revision','hash'],s);const h=text(v.hash,s,64);if(h.length!==64||!/^[0-9a-f]{64}$/.test(h))fail('Lowercase SHA-256 reference required');
  return freeze({id:text(v.id,s),revision:revision(v.revision),hash:h})}
function metadata(v,s,depth=0,seen=new Set){
  s.charge();if(++s.dataNodes>s.limits.maxDataNodes)fail('Warp metadata-node allowance','shape-budget');
  if(v===null||typeof v==='boolean')return v;
  if(typeof v==='number'){if(!Number.isFinite(v))fail('Nonfinite metadata');return Object.is(v,-0)?0:v}
  if(typeof v==='string')return v.length?text(v,s,2048):v;
  if(depth>=12||seen.has(v))fail('Cyclic or deep warp metadata');seen.add(v);let out;
  if(Array.isArray(v)){list(v,s.limits.maxDataNodes,s,'Metadata');out=[];for(const x of v)out.push(metadata(x,s,depth+1,seen))}
  else{if(!dataRecord(v)||Object.keys(v).length>256)fail('Ordinary bounded metadata required');out={};for(const key of Object.keys(v)){
    text(key,s);Object.defineProperty(out,key,{value:metadata(v[key],s,depth+1,seen),enumerable:true})}}
  seen.delete(v);return freeze(out);
}
function wire(v,s){s.charge();if(++s.dataNodes>s.limits.maxDataNodes)fail('Warp output-node allowance','shape-budget');
  if(typeof v==='string')return v.length?text(v,s,6000):v;
  if(v&&typeof v==='object'){
    if(typeof v.n==='bigint'&&typeof v.d==='bigint')return text(exactText(v),s,6000);
    if(Array.isArray(v))return freeze(v.map(x=>wire(x,s)));
    return freeze(Object.fromEntries(Object.entries(v).map(([key,value])=>[text(key,s),wire(value,s)])));
  }return v;
}
function hash(v,s){const encoded=pythonJson(v);if(encoded.length>s.limits.maxTextChars)fail('Warp canonical-text allowance','work-budget');s.charge(1+Math.ceil(encoded.length/64));return sha256(encoded)}
function typed(v,space,s){if(v===null)return null;fields(v,['space','definition','coordinate'],s);
  if(text(v.space,s)!==space.id||text(v.definition,s)!==space.hash)fail('Original pitch belongs to another space','out-of-model');
  const value=Array.isArray(v.coordinate)?list(v.coordinate,32,s,'Pitch coordinates').map(q=>rational(q,s)):rational(v.coordinate,s);
  s.charge();return space.pitch(value);
}
function normalize(raw,s){
  fields(raw,['id','revision','pitchSpace','profile','lines','relations','environment','blend','bindings','dependencies'],s);
  const id=text(raw.id,s),version=revision(raw.revision),space=raw.pitchSpace;compilePitchOperations(space,[]);
  const profile=raw.profile,info=decomposeCounterpointProfile(profile);if(info.pitchSpaceHash!==space.hash)fail('Warp profile and pitch space differ','out-of-model');
  const targetClock=info.clockDomain,voiceIds=new Set(info.voices),lines=[],lineById=new Map,nodes=[freeze({id:'anchor',A:ZERO,C:ZERO,minus:ZERO,plus:ZERO})];
  let eventCount=0,channelCount=0,complete=true;
  for(const v of list(raw.lines,s.limits.maxLines,s,'Original lines')){
    fields(v,['id','revision','voiceId','complete','sourceClock','knots','rates','events','provenance','requiredChannels','channels'],s);
    const lineId=text(v.id,s),voiceId=text(v.voiceId,s);if(lineById.has(lineId)||!voiceIds.has(voiceId))fail('Duplicate line or undeclared target voice');
    const sourceClock=clock(v.sourceClock,s),knots=[],start=nodes.length;
    for(const k of list(v.knots,s.limits.maxKnots-(nodes.length-1),s,'Original source knots')){
      fields(k,['source','ideal','lo','hi','freeBand','normalizer'],s);const source=nonnegative(k.source,s),ideal=nonnegative(k.ideal,s),lo=nonnegative(k.lo,s),hi=nonnegative(k.hi,s);
      if(s.m.cmp(lo,hi)>0)fail('Reversed hard point window');
      if(!knots.length&&source.n!==0n||knots.length&&(s.m.cmp(source,knots.at(-1).source)<=0||s.m.cmp(ideal,knots.at(-1).ideal)<=0))fail('Source and ideal grids must increase from source zero');
      const freeBand=sides(k.freeBand,s,nonnegative),normalizer=sides(k.normalizer,s,positive),node=nodes.length;
      nodes.push(freeze({id:`k:${lines.length}:${knots.length}`,A:s.m.sub(ideal,freeBand.minus),C:s.m.add(ideal,freeBand.plus),minus:normalizer.minus,plus:normalizer.plus}));
      knots.push(freeze({source,ideal,lo,hi,freeBand,normalizer,node}));
    }if(knots.length<2)fail('A positive warp needs at least two source knots');
    const rates=[];for(const r of list(v.rates,s.limits.maxKnots,s,'Rate bands')){fields(r,['min','max'],s);const min=positive(r.min,s),max=positive(r.max,s);
      if(s.m.cmp(min,max)>0)fail('Reversed rate band');rates.push(freeze({min,max}))}
    if(rates.length!==knots.length-1)fail('One rate band per source segment required');
    const events=[],eventIds=new Set;for(const e of list(v.events,s.limits.maxEvents-eventCount,s,'Original events')){
      fields(e,['id','t','d','pitch'],s);const t=nonnegative(e.t,s),d=positive(e.d,s);if(s.m.cmp(s.m.add(t,d),knots.at(-1).source)>0)fail('An original event exceeds its source domain');
      events.push(freeze({id:unique(eventIds,text(e.id,s)),t,d,pitch:typed(e.pitch,space,s)}));
    }eventCount+=events.length;
    const required=[],requiredIds=new Set;for(const name of list(v.requiredChannels,s.limits.maxChannels,s,'Required channels'))required.push(unique(requiredIds,text(name,s)));
    if(!required.length)fail('Declare a nonempty independent required information inventory','missing-evidence');
    const channels=[],channelIds=new Set;
    for(const c of list(v.channels,s.limits.maxChannels-channelCount,s,'Information channels')){
      fields(c,['id','revision','kind','clockDomain','reference','values'],s);const channelId=unique(channelIds,text(c.id,s)),domain=clock(c.clockDomain,s);
      if(!requiredIds.has(channelId)||!sameClock(domain,targetClock)||!['known','predicted','unknown'].includes(c.kind))fail('Information channel identity, status or common clock differs','out-of-model');
      let values=null;if(c.values!==null){values=[];for(const pair of list(c.values,s.limits.maxKnots,s,'Information grid')){
        fields(pair,['availability','preparation'],s);values.push(freeze({availability:rational(pair.availability,s),preparation:nonnegative(pair.preparation,s)}))}
        if(values.length!==knots.length)fail('Information functions must cover the entire original grid');values=freeze(values);
      }
      if(c.kind==='known'&&values===null)fail('Known information needs complete values','missing-evidence');complete=complete&&c.kind==='known';
      channels.push(freeze({id:channelId,revision:revision(c.revision),kind:c.kind,clockDomain:domain,reference:reference(c.reference,s),values}));
    }channelCount+=channels.length;if(channelIds.size!==requiredIds.size)fail('A required information channel is missing','missing-evidence');
    const isComplete=boolean(v.complete);complete=complete&&isComplete;
    const line=freeze({id:lineId,revision:revision(v.revision),voiceId,complete:isComplete,sourceClock,knots:freeze(knots),rates:freeze(rates),events:freeze(events),
      provenance:reference(v.provenance,s),requiredChannels:freeze(required),channels:freeze(channels),start});lines.push(line);lineById.set(lineId,line);
  }if(!lines.length)fail('Declare original lines');
  const locate=raw=>{fields(raw,['lineId','knotIndex'],s);const line=lineById.get(raw.lineId),index=raw.knotIndex;
    if(!line||!Number.isSafeInteger(index)||index<0||index>=line.knots.length)fail('Relation names an unknown original knot');return freeze({lineId:line.id,knotIndex:index,node:line.knots[index].node})};
  const relations=[],relationIds=new Set;for(const r of list(raw.relations,s.limits.maxRelations,s,'Cross-line relations')){
    fields(r,['id','from','to','lo','hi'],s);const lo=rational(r.lo,s),hi=rational(r.hi,s);if(s.m.cmp(lo,hi)>0)fail('Reversed difference relation');
    relations.push(freeze({id:unique(relationIds,text(r.id,s)),from:locate(r.from),to:locate(r.to),lo,hi}));
  }
  const env=fields(raw.environment,['id','revision','complete','events','contexts'],s),environmentEvents=[],environmentIds=new Set,contexts=[],contextIds=new Set;
  for(const e of list(env.events,s.limits.maxEvents-eventCount,s,'Environment events')){fields(e,['id','voiceId','t','d','pitch'],s);const voiceId=text(e.voiceId,s);if(!voiceIds.has(voiceId))fail('Environment voice is undeclared');
    environmentEvents.push(freeze({id:unique(environmentIds,text(e.id,s)),voiceId,t:nonnegative(e.t,s),d:positive(e.d,s),pitch:typed(e.pitch,space,s)}))}eventCount+=environmentEvents.length;
  for(const c of list(env.contexts,s.limits.maxContexts,s,'Context cells')){fields(c,['id','revision','from','to','complete','data'],s);const from=nonnegative(c.from,s),to=nonnegative(c.to,s);
    if(s.m.cmp(from,to)>=0||contexts.length&&s.m.cmp(from,contexts.at(-1).to)<0)fail('Context cells must be ordered and disjoint');if(!dataRecord(c.data))fail('Context data must be a record');
    contexts.push(freeze({id:unique(contextIds,text(c.id,s)),revision:revision(c.revision),from,to,complete:boolean(c.complete),data:metadata(c.data,s)}));
  }
  const envComplete=boolean(env.complete);complete=complete&&envComplete;
  const environment=freeze({id:text(env.id,s),revision:revision(env.revision),complete:envComplete,events:freeze(environmentEvents),contexts:freeze(contexts)});
  const blend=nonnegative(raw.blend,s);if(s.m.cmp(blend,ONE)>0)fail('Common convex blend must lie in zero through one');
  if(!dataRecord(raw.bindings))fail('Warp bindings must be a record');const bindings=metadata(raw.bindings,s),dependencies=[],dependencyIds=new Set;
  for(const d of list(raw.dependencies,s.limits.maxDependencies,s,'Dependencies')){fields(d,['id','revision','data'],s);dependencies.push(freeze({id:unique(dependencyIds,text(d.id,s)),revision:revision(d.revision),data:metadata(d.data,s)}))}
  const model={id,revision:version,space,profile,targetClock,lines:freeze(lines),relations:freeze(relations),environment,blend,bindings,dependencies:freeze(dependencies),nodes:freeze(nodes),eventCount,channelCount,complete};
  model.definition=wire({kind:'positive-warp-v1',id,revision:version,pitchSpace:space.definition,profile:profile.definition,targetClock,
    lines,relations,environment,blend,bindings,dependencies},s);s.modelHash=hash(model.definition,s);return model;
}
function arcsOf(model,s){
  const arcs=[],m=s.m,negative=q=>m.sub(ZERO,q),append=(id,from,to,bound)=>{
    s.charge();if(arcs.length>=s.limits.maxArcs)fail('Original warp arc allowance','shape-budget');arcs.push(freeze({id,from,to,bound}))};
  for(let l=0;l<model.lines.length;l++){
    const line=model.lines[l];for(let k=0;k<line.knots.length;k++){
      const p=line.knots[k];append(`window:${l}:${k}:upper`,0,p.node,p.hi);append(`window:${l}:${k}:lower`,p.node,0,negative(p.lo));
      if(k){const before=line.knots[k-1],span=m.sub(p.source,before.source),r=line.rates[k-1];
        append(`rate:${l}:${k-1}:max`,before.node,p.node,m.mul(r.max,span));append(`rate:${l}:${k-1}:min`,p.node,before.node,negative(m.mul(r.min,span)))}
      for(let c=0;c<line.channels.length;c++){const channel=line.channels[c];if(channel.kind==='known'){
        const value=channel.values[k];append(`causal:${l}:${c}:${k}`,p.node,0,negative(m.add(value.availability,value.preparation)))}}
    }
  }
  for(let i=0;i<model.relations.length;i++){const r=model.relations[i];append(`relation:${i}:upper`,r.from.node,r.to.node,r.hi);append(`relation:${i}:lower`,r.to.node,r.from.node,negative(r.lo))}
  return freeze(arcs);
}
function modelOf(prepared,s){const m=models.get(prepared);if(!m)fail('Use an authentic prepared positive-warp model','out-of-model');s.modelHash=prepared.modelHash;
  if(m.lines.length>s.limits.maxLines||m.nodes.length-1>s.limits.maxKnots||m.eventCount>s.limits.maxEvents||m.channelCount>s.limits.maxChannels||
    m.relations.length>s.limits.maxRelations||m.environment.contexts.length>s.limits.maxContexts||m.dependencies.length>s.limits.maxDependencies)fail('Prepared warp exceeds current shape allowance','shape-budget');return m}
function result(s,status,reason,extra={}){return freeze({status,reason,scope,modelHash:s?.modelHash??null,workUsed:s?.used??0,resourceLimits:s?.limits??null,...extra})}
function run(options,body){let s;try{s=stateOf(options);return body(s)}catch(e){return result(s,e instanceof BadCertificate?'FAIL':'UNKNOWN',e.message??'Positive warp refused',
  {kind:e instanceof Refused?e.kind:e instanceof BadCertificate?'invalid-certificate':'internal-error',certificate:null,conclusion:null})}}
function requireComplete(model){if(!model.complete)fail('Complete originals/environment and every required known information channel are required','missing-evidence')}
function closure(model,arcs,s){
  const n=model.nodes.length;s.charge(2*n*n);const D=Array.from({length:n},()=>Array(n).fill(null)),paths=Array.from({length:n},()=>Array(n).fill(null));
  for(let i=0;i<n;i++){D[i][i]=ZERO;paths[i][i]=[]}
  for(const a of arcs){s.charge();if(D[a.from][a.to]===null||s.m.cmp(a.bound,D[a.from][a.to])<0){D[a.from][a.to]=a.bound;paths[a.from][a.to]=[a.id];
    if(a.from===a.to&&a.bound.n<0n)return {negative:[a.id]}}}
  for(let k=0;k<n;k++)for(let i=0;i<n;i++)for(let j=0;j<n;j++){
    s.charge();if(D[i][k]===null||D[k][j]===null)continue;const candidate=s.m.add(D[i][k],D[k][j]);
    if(D[i][j]!==null&&s.m.cmp(candidate,D[i][j])>=0)continue;
    const length=paths[i][k].length+paths[k][j].length;if(length>s.limits.maxPathEdges)fail('Original path-length allowance','path-budget');s.charge(length);
    const path=[...paths[i][k],...paths[k][j]];D[i][j]=candidate;paths[i][j]=path;
    if(i===j&&candidate.n<0n)return {negative:path};
  }
  if(D.some(row=>row.some(q=>q===null)))throw new Error('Finite point windows must connect the hard graph');return {D,paths};
}
function optimum(model,closed,s){
  const n=model.nodes.length,m=s.m;let peak=ZERO,proof={kind:'nonnegative'};
  for(let i=0;i<n;i++)for(let j=0;j<n;j++){
    s.charge();const denominator=m.add(model.nodes[i].plus,model.nodes[j].minus);if(!denominator.n)continue;
    const numerator=m.sub(m.sub(model.nodes[j].A,model.nodes[i].C),closed.D[i][j]),value=m.div(numerator,denominator);
    if(m.cmp(value,peak)>0){peak=value;proof={kind:'path',from:model.nodes[i].id,to:model.nodes[j].id,arcs:closed.paths[i][j]}};
  }
  const lower=model.nodes.map(p=>m.sub(p.A,m.mul(p.minus,peak))),upper=model.nodes.map(p=>m.add(p.C,m.mul(p.plus,peak))),least=[],greatest=[];
  for(let j=0;j<n;j++){
    let low=null,high=null;for(let i=0;i<n;i++){
      const a=m.sub(lower[i],closed.D[j][i]),b=m.add(upper[i],closed.D[i][j]);
      if(low===null||m.cmp(a,low)>0)low=a;if(high===null||m.cmp(b,high)<0)high=b;
    }least.push(low);greatest.push(high);
  }
  const alpha=model.blend,other=m.sub(ONE,alpha),values=least.map((q,i)=>m.add(m.mul(other,q),m.mul(alpha,greatest[i])));
  return {peak,proof,values,least,greatest};
}
function targetsOf(model,raw,s){
  const lines=list(raw,s.limits.maxLines,s,'Target lines');if(lines.length!==model.lines.length)fail('Supply every original target line');const values=[ZERO];
  for(let i=0;i<lines.length;i++){
    const row=fields(lines[i],['lineId','values'],s),line=model.lines[i];if(row.lineId!==line.id)fail('Original line identity/order differs');
    const times=list(row.values,s.limits.maxKnots,s,'Target knots');if(times.length!==line.knots.length)fail('Supply every original target knot');
    for(const t of times)values.push(rational(t,s,EXACT_LIMITS.workBits));
  }return values;
}
function targetsWire(model,values,s){return wire(model.lines.map(line=>({lineId:line.id,values:line.knots.map(k=>values[k.node])})),s)}
function timingAudit(model,arcs,values,s){
  const violations=[];let peak=ZERO;
  for(const a of arcs){s.charge();if(s.m.cmp(s.m.sub(values[a.to],values[a.from]),a.bound)>0)violations.push(a.id)}
  for(const line of model.lines)for(const k of line.knots){
    const residual=s.m.sub(values[k.node],k.ideal),side=residual.n<0n?'minus':'plus',magnitude=residual.n<0n?s.m.sub(ZERO,residual):residual;
    const excess=s.m.sub(magnitude,k.freeBand[side]),cost=excess.n>0n?s.m.div(excess,k.normalizer[side]):ZERO;if(s.m.cmp(cost,peak)>0)peak=cost;
  }return {status:violations.length?'FAIL':'PASS',peak,violations:freeze(violations)};
}
function pathOf(model,arcs,raw,s){
  const ids=list(raw,s.limits.maxPathEdges,s,'Original path');demand(ids.length>0,'A path needs original arcs');const byId=new Map(arcs.map(a=>[a.id,a]));
  let first=null,last=null,sum=ZERO;for(const id of ids){text(id,s);demand(byId.has(id),'Unknown original path arc');const a=byId.get(id);
    if(first===null)first=a.from;else demand(last===a.from,'Original path incidence is broken');last=a.to;sum=s.m.add(sum,a.bound);
  }return {first,last,sum};
}
function verifyLowerBound(model,arcs,raw,peak,s){
  if(dataRecord(raw)&&raw.kind==='nonnegative'){fields(raw,['kind'],s);demand(!peak.n,'Nonnegativity proves only a zero optimum');return}
  fields(raw,['kind','from','to','arcs'],s);demand(raw.kind==='path','Unknown timing lower-bound proof');text(raw.from,s);text(raw.to,s);const path=pathOf(model,arcs,raw.arcs,s);
  demand(model.nodes[path.first].id===raw.from&&model.nodes[path.last].id===raw.to,'Original path endpoints differ');
  const a=model.nodes[path.first],b=model.nodes[path.last],den=s.m.add(a.plus,b.minus);demand(den.n>0n,'Lower-bound denominator is zero');
  const bound=s.m.div(s.m.sub(s.m.sub(b.A,a.C),path.sum),den);demand(bound.n>0n&&s.m.cmp(bound,peak)===0,'Original path lower bound does not meet the actual objective');
}
function verifyCycle(model,arcs,raw,s){fields(raw,['kind','arcs'],s);demand(raw.kind==='negative-cycle','A hard contradiction needs an original negative cycle');
  const path=pathOf(model,arcs,raw.arcs,s);demand(path.first===path.last&&path.sum.n<0n,'Original closed walk is not negative')}
function at(line,values,q,s,replay){
  let index;
  if(replay){index=0;while(index+1<line.knots.length&&s.m.cmp(line.knots[index+1].source,q)<=0){s.charge();index++}}
  else{let lo=0,hi=line.knots.length;while(lo<hi){s.charge();const mid=(lo+hi)>>1;if(s.m.cmp(line.knots[mid].source,q)<=0)lo=mid+1;else hi=mid}index=lo-1}
  const a=line.knots[index];if(!a)throw new Error('Original source lies outside its checked domain');if(s.m.cmp(a.source,q)===0)return values[a.node];
  const b=line.knots[index+1];if(!b)throw new Error('Original source exceeds its checked domain');const width=s.m.sub(b.source,a.source);
  if(replay)return s.m.div(s.m.add(s.m.mul(s.m.sub(b.source,q),values[a.node]),s.m.mul(s.m.sub(q,a.source),values[b.node])),width);
  return s.m.add(values[a.node],s.m.mul(s.m.div(s.m.sub(q,a.source),width),s.m.sub(values[b.node],values[a.node])));
}
function nested(s,body){
  const allowance=Math.min(2000000,s.limits.maxMusicalWork,s.limits.maxWork-s.used);if(!allowance)fail('No complete-union audit allowance remains','work-budget');
  const out=body({maxWork:allowance,maxProfileWork:allowance,maxFragments:s.limits.maxLines,maxPlacements:s.limits.maxLines,
    maxEvents:s.limits.maxEvents,maxContexts:s.limits.maxContexts,maxDependencies:s.limits.maxDependencies,
    maxTextChars:s.limits.maxTextChars,maxDataNodes:s.limits.maxDataNodes});
  if(!Number.isSafeInteger(out.workUsed)||out.workUsed<0||out.workUsed>allowance)throw new Error('Invalid nested audit receipt');s.charge(out.workUsed);return out;
}
function joint(model,values,s,replay,musicalCertificate=null){
  const fragments=[],placements=[],origins=[];
  for(let i=0;i<model.lines.length;i++){
    const line=model.lines[i],events=[];
    for(const e of line.events){
      s.charge();const a=at(line,values,e.t,s,replay),b=at(line,values,s.m.add(e.t,e.d),s,replay),duration=s.m.sub(b,a);
      events.push({id:e.id,voiceId:'source',t:a,d:duration,pitch:e.pitch});origins.push({lineId:line.id,sourceId:e.id,sourceT:e.t,sourceD:e.d,targetT:a,targetD:duration});
    }
    fragments.push({id:line.id,revision:line.revision,complete:line.complete,clockDomain:model.targetClock,length:values[line.knots.at(-1).node],
      voices:['source'],events,provenance:line.provenance});
    placements.push({id:`warp:${i}`,fragmentId:line.id,offset:0,scale:1,voices:[{sourceVoice:'source',targetVoice:line.voiceId,pitchOperations:[]}]});
  }
  const spec={id:'positive-warp-realization',revision:model.revision,pitchSpace:model.space,profile:model.profile,
    fragments:wire(fragments,s),placements,environment:wire(model.environment,s),
    bindings:{originalWarp:s.modelHash,originalBindings:model.definition.bindings},dependencies:model.definition.dependencies};
  const prepared=nested(s,options=>prepareFragmentSplice(spec,options));
  if(prepared.status!=='PASS')fail(prepared.reason,prepared.kind??'missing-evidence');
  const out=nested(s,options=>replay?checkFragmentSplice(prepared.prepared,musicalCertificate,options):auditFragmentSplice(prepared.prepared,options));
  if(replay){if(out.status==='UNKNOWN')fail(out.reason,out.kind??'missing-evidence');demand(out.status==='PASS'&&out.conclusion==='PASS','The original warped whole-profile certificate does not prove musical PASS')}
  return {status:out.status,report:out.report??null,certificate:out.certificate??musicalCertificate,origins:wire(origins,s)};
}
function makeCertificate(conclusion,targets,peak,proof,musical,s){return freeze({kind:'positive-warp-certificate-v1',modelHash:s.modelHash,conclusion,
  targets,peak:peak===null?null:text(exactText(peak),s,6000),proof:proof===null?null:wire(proof,s),musical})}
function proposal(model,values,timing,music,s){return freeze({targets:targetsWire(model,values,s),peak:text(exactText(timing.peak),s,6000),
  timing:wire({status:timing.status,violations:timing.violations},s),musicalStatus:music.status,origins:music.origins,musicalReport:music.report})}
/** Bind the full original model. Preparation establishes neither a feasible warp nor a musical admission. */
export function preparePositiveWarp(spec,options={}){
  return run(options,s=>{const model=normalize(spec,s),arcs=arcsOf(model,s),prepared=freeze({kind:'prepared-positive-warp-v1',modelHash:s.modelHash,
    definition:model.definition,nodeIds:wire(model.nodes.map(n=>n.id),s),arcs:wire(arcs,s)});models.set(prepared,model);
    return result(s,'PASS','Original continuous warp model prepared',{prepared})});
}
/** Audit arbitrary declared target knots against every hard timing condition and the complete original union. */
export function auditPositiveWarp(prepared,targets,options={}){
  return run(options,s=>{const model=modelOf(prepared,s);requireComplete(model);const values=targetsOf(model,targets,s),timing=timingAudit(model,arcsOf(model,s),values,s);
    if(timing.status!=='PASS')return result(s,'FAIL','Original hard timing constraints fail',{timing:wire(timing,s),certificate:null});
    const music=joint(model,values,s,false),out=proposal(model,values,timing,music,s);
    return result(s,music.status,'Complete original warped union audited',{proposal:out,
      certificate:music.status==='PASS'?makeCertificate('SAT',out.targets,timing.peak,null,music.certificate,s):null});
  });
}
/** Close the hard graph and minimize continuous displacement; a refuted optimal pick is not joint UNSAT. */
export function solvePositiveWarp(prepared,options={}){
  return run(options,s=>{const model=modelOf(prepared,s);requireComplete(model);const arcs=arcsOf(model,s),closed=closure(model,arcs,s);
    if(closed.negative){const proof={kind:'negative-cycle',arcs:closed.negative};verifyCycle(model,arcs,proof,s);
      return result(s,'UNSAT','An original negative closed walk contradicts the hard timing constraints',{certificate:makeCertificate('UNSAT',null,null,proof,null,s)})}
    const out=optimum(model,closed,s),timing=timingAudit(model,arcs,out.values,s);
    if(timing.status!=='PASS'||s.m.cmp(timing.peak,out.peak)!==0)throw new Error('Constructed extrema disagree with the original timing model');
    verifyLowerBound(model,arcs,out.proof,timing.peak,s);
    const music=joint(model,out.values,s,false),picked=proposal(model,out.values,timing,music,s),extrema=freeze({least:targetsWire(model,out.least,s),greatest:targetsWire(model,out.greatest,s)});
    if(music.status!=='PASS')return result(s,'UNKNOWN','The timing-optimal proposal lacks musical PASS; no joint feasibility or failure conclusion',
      {proposal:picked,timingLowerBound:text(exactText(out.peak),s,6000),timingProof:wire(out.proof,s),extrema,certificate:null});
    return result(s,'OPTIMAL','A passing original whole union attains the exact global timing lower bound',
      {proposal:picked,extrema,certificate:makeCertificate('OPTIMAL',picked.targets,timing.peak,out.proof,music.certificate,s)});
  });
}
/** Rebuild original arcs and interval endpoints, verify a short path/cycle and check the complete musical certificate. */
export function checkPositiveWarp(prepared,raw,options={}){
  return run(options,s=>{const model=modelOf(prepared,s);fields(raw,['kind','modelHash','conclusion','targets','peak','proof','musical'],s);
    demand(raw.kind==='positive-warp-certificate-v1'&&raw.modelHash===s.modelHash,'Original warp identity differs');
    demand(['SAT','OPTIMAL','UNSAT'].includes(raw.conclusion),'Unknown warp conclusion');requireComplete(model);const arcs=arcsOf(model,s);
    if(raw.conclusion==='UNSAT'){
      demand(raw.targets===null&&raw.peak===null&&raw.musical===null,'A hard contradiction carries no candidate realization');verifyCycle(model,arcs,raw.proof,s);
      return result(s,'PASS','Original negative closed walk proves the scoped timing contradiction',{conclusion:'UNSAT'});
    }
    const values=targetsOf(model,raw.targets,s),timing=timingAudit(model,arcs,values,s);demand(timing.status==='PASS','Original hard timing constraints fail');
    const peak=rational(raw.peak,s,EXACT_LIMITS.workBits);demand(s.m.cmp(peak,timing.peak)===0,'Reported displacement differs from the actual original objective');
    if(raw.conclusion==='OPTIMAL')verifyLowerBound(model,arcs,raw.proof,peak,s);else demand(raw.proof===null,'SAT does not assert an optimality proof');
    const music=joint(model,values,s,true,raw.musical),out=proposal(model,values,timing,music,s);
    return result(s,'PASS','Original timing, short proof and independently reconstructed whole union agree',{conclusion:raw.conclusion,proposal:out});
  });
}
