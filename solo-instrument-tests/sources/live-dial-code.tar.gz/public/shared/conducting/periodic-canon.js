// CFM-025 / CF07: exact fixed-material rounds, circular seams and a constructed finite performance.
// Research candidate. Named static predicates are mathematical claims, not style, authority or audio claims.
import {Q} from './canon-core.js';
import {decomposeCounterpointProfile} from './counterpoint-profile.js';
import {compilePitchOperations} from './pitch-spaces.js';
import {Refused,Budget,bitsOf,pythonJson,sha256} from '../bounded-exact.js';
import {dataRecord,dataArray} from './contract-data.js';

export const PERIODIC_CANON_LIMITS=Object.freeze({maxWork:500000,maxProfileWork:90000,maxSeries:128,
  maxSourceEvents:4096,maxOnsets:4096,maxEvents:4096,maxBoundaries:8192,maxDependencies:128,
  maxTextChars:4194304,maxCertificateChars:1024});
const freeze=Object.freeze,models=new WeakMap,scope='complete-declared-static-periodic-canon-and-finite-candidate';
const rawBound=1n<<256n,zero=Q(0),one=Q(1);
const fail=(message,kind='invalid-input')=>{throw new Refused(message,{kind})};
class BadCertificate extends Error {}
const reduce=values=>values.includes('FAIL')?'FAIL':values.includes('UNKNOWN')?'UNKNOWN':values.includes('PASS')?'PASS':'N/A';
function stateOf(options){
  if(!dataRecord(options)||Object.keys(options).some(k=>!Object.hasOwn(PERIODIC_CANON_LIMITS,k)))fail('Unknown periodic limits');
  const limits={};for(const [k,cap] of Object.entries(PERIODIC_CANON_LIMITS)){
    const v=Object.hasOwn(options,k)?options[k]:cap;
    if(!Number.isSafeInteger(v)||v<0||v>cap)fail('Periodic limits may only lower their declared safe caps');limits[k]=v;
  }
  const budget=new Budget(limits.maxWork),s={limits:freeze(limits),budget,chars:0,modelHash:null};
  s.charge=(n=1)=>budget.charge(n);
  s.math={add(a,b){s.charge();return a.add(b)},sub(a,b){s.charge();return a.sub(b)},
    mul(a,b){s.charge();return a.mul(b)},div(a,b){s.charge();return a.div(b)},cmp(a,b){s.charge();return a.cmp(b)}};
  s.charge();return s;
}
function fields(v,keys,s){
  s.charge();if(!dataRecord(v)||Object.keys(v).length!==keys.length||keys.some(k=>!Object.hasOwn(v,k)))fail('Missing or unexpected periodic fields');
  s.charge(keys.length);return v;
}
function list(v,cap,s,label){
  if(!Array.isArray(v)||v.length>cap)fail(label+' exceeds its array allowance','shape-budget');
  s.charge(v.length+1);return dataArray(v,cap,label);
}
function text(v,s,cap=256){
  if(typeof v!=='string'||!v.length||v.length>cap)fail('Bounded nonempty text required');
  if(v.length>s.limits.maxTextChars-s.chars)fail('Periodic text allowance','work-budget');
  s.chars+=v.length;s.charge(1+Math.ceil(v.length/64));return v;
}
function integer(v){
  const n=typeof v==='bigint'?v:Number.isSafeInteger(v)?BigInt(v):null;
  if(n===null||n<=-rawBound||n>=rawBound)fail('Require exact integer components of at most 256 bits','arithmetic-budget');return n;
}
function rational(v,s){
  s.charge();let n,d=1n;
  if(typeof v==='string'){
    text(v,s,160);const m=v.match(/^([+-]?[0-9]+)(?:\/([+-]?[0-9]+))?$/);
    if(!m||m[0].length!==v.length)fail('Use exact integer or fraction text');
    n=integer(BigInt(m[1]));d=integer(BigInt(m[2]??'1'));
  }else if(v&&typeof v==='object'){fields(v,['n','d'],s);n=integer(v.n);d=integer(v.d)}
  else n=integer(v);
  if(d===0n)fail('Zero denominator');return Q({n,d});
}
function nonnegative(v,s){const q=rational(v,s);if(s.math.cmp(q,zero)<0)fail('Negative time');return q}
function positive(v,s){const q=rational(v,s);if(s.math.cmp(q,zero)<=0)fail('Nonpositive period or duration');return q}
function revision(v){if(!Number.isSafeInteger(v)||v<0)fail('Explicit nonnegative safe revision required');return v}
function cycle(v,s){const q=rational(v,s);if(q.d!==1n)fail('Cycle ranges use integers');return q.n}
function clock(raw,s){fields(raw,['id','unit','revision'],s);return freeze({id:text(raw.id,s),unit:text(raw.unit,s),revision:revision(raw.revision)})}
function typedPitch(raw,space,s){
  if(raw===null)return null;fields(raw,['space','definition','coordinate'],s);
  if(text(raw.space,s)!==space.id||text(raw.definition,s)!==space.hash)fail('Pitch space/revision mismatch','out-of-model');
  const value=Array.isArray(raw.coordinate)?list(raw.coordinate,32,s,'Pitch coordinates').map(v=>rational(v,s)):rational(raw.coordinate,s);
  s.charge();return space.pitch(value);
}
// Convert an already bounded derived integer to a genuine Rational without weakening raw input admission.
function derivedInteger(n,s){
  if(bitsOf(n)>8192)fail('Derived cycle integer exceeds 8192 bits','arithmetic-budget');
  const negative=n<0n;if(negative)n=-n;const chunks=[],base=1n<<128n;
  while(n){s.charge();chunks.push(n%base);n/=base}
  let q=zero;for(let i=chunks.length-1;i>=0;i--)q=s.math.add(s.math.mul(q,Q(base)),Q(chunks[i]));
  return negative?s.math.sub(zero,q):q;
}
const floor=q=>q.n/q.d-(q.n<0n&&q.n%q.d?1n:0n);
const ceil=q=>q.n/q.d+(q.n>0n&&q.n%q.d?1n:0n);
function residue(q,p,s){s.charge();return s.math.sub(q,s.math.mul(p,derivedInteger(floor(s.math.div(q,p)),s)))}
function gcd(a,b,s){while(b){s.charge();[a,b]=[b,a%b]}return a}
function commonPeriod(series,s){
  let t=one;for(let i=0;i<series.length;i++){
    const p=series[i].period;if(!i){t=p;continue}
    const a=p.n/gcd(t.n,p.n,s),b=t.d/gcd(t.d,p.d,s);
    t=s.math.mul(s.math.mul(t,Q(a)),Q(b));
  }return t;
}
function countRange(lo,stop,remaining,s,label){
  s.charge();const n=stop-lo;if(n<0n)fail('Reversed '+label);
  if(n>BigInt(remaining))fail(label+' expansion exceeds admitted allocation','shape-budget');return Number(n);
}
function digest(value,s,cap=s.limits.maxTextChars){
  const parts=[];let size=0;
  const append=x=>{if(x.length>cap-size)fail('Canonical periodic text allowance','work-budget');size+=x.length;parts.push(x)};
  function encode(v,depth=0){
    s.charge();if(depth>20)fail('Periodic data too deep');
    if(v===null||typeof v==='boolean'||typeof v==='string'||typeof v==='number'&&Number.isSafeInteger(v)){append(pythonJson(v));return}
    if(Array.isArray(v)){
      list(v,65536,s,'Canonical array');append('[');for(let i=0;i<v.length;i++){if(i)append(',');encode(v[i],depth+1)}append(']');return;
    }
    if(!dataRecord(v))fail('Canonical data must be ordinary finite records');
    const keys=Object.keys(v);if(keys.length>64)fail('Canonical record too wide');
    keys.sort((a,b)=>{s.charge();return a<b?-1:a>b?1:0});append('{');
    for(let i=0;i<keys.length;i++){if(i)append(',');append(pythonJson(keys[i]));append(':');encode(v[keys[i]],depth+1)}append('}');
  }
  encode(value);s.charge(1+Math.ceil(size/64));return sha256(parts.join(''));
}
function deepFreeze(value){
  if(value&&typeof value==='object'&&!Object.isFrozen(value)){for(const v of Object.values(value))deepFreeze(v);freeze(value)}return value;
}
function normalize(raw,s){
  fields(raw,['id','revision','inventoryComplete','profile','pitchSpace','clockDomain','dependencies','series','performance'],s);
  if(raw.inventoryComplete!==true)fail('The declared series inventory must be explicitly complete','missing-evidence');
  const id=text(raw.id,s),rev=revision(raw.revision),profile=raw.profile,space=raw.pitchSpace;
  // These authentic compiler setup calls are separately shape bounded (32 voices / 48 rules); no supplied callback.
  const authentic=decomposeCounterpointProfile(profile);compilePitchOperations(space,[]);
  const domain=clock(raw.clockDomain,s);
  if(authentic.pitchSpaceHash!==space.hash||digest(domain,s)!==digest(authentic.clockDomain,s))fail('Profile, space and clock must agree','out-of-model');
  const rules=profile.definition.rules;
  for(const rule of rules){s.charge();if(!['monophony','melodic-bound','voice-spacing','parallel-classes','vertical-bands'].includes(rule.type)||Object.hasOwn(rule,'contextKey'))
    fail('Only the original static named predicates are admitted','out-of-model')}
  const dependencies=[],depIds=new Set;
  for(const r of list(raw.dependencies,s.limits.maxDependencies,s,'Dependencies')){
    fields(r,['id','revision','hash'],s);const name=text(r.id,s),hash=text(r.hash,s);
    if(depIds.has(name)||!/^[0-9a-f]{64}$/.test(hash)||hash.length!==64)fail('Unique dependencies with SHA-256 required');depIds.add(name);
    dependencies.push(freeze({id:name,revision:revision(r.revision),hash}));
  }
  const series=[],families=[],seriesById=new Map;
  for(const r of list(raw.series,s.limits.maxSeries,s,'Series')){
    fields(r,['id','voiceId','period','phase','events'],s);const name=text(r.id,s),voiceId=text(r.voiceId,s);
    if(seriesById.has(name)||!authentic.voices.includes(voiceId))fail('Unique series and declared voices required');
    const period=positive(r.period,s),phase=rational(r.phase,s),events=[],eventIds=new Set,index=series.length;
    for(const e of list(r.events,s.limits.maxSourceEvents-families.length,s,'Source events')){
      fields(e,['id','t','d','pitch'],s);const eventId=text(e.id,s);if(eventIds.has(eventId))fail('Duplicate source event identity');eventIds.add(eventId);
      const t=nonnegative(e.t,s),d=positive(e.d,s),pitch=typedPitch(e.pitch,space,s),a=s.math.add(phase,t);
      const family=freeze({seriesId:name,sourceId:eventId,voiceId,period,phase,t,d,pitch,a,
        a0:residue(a,period,s),baseCycle:floor(s.math.div(a,period)),prefix:`s${index}:e${events.length}:c`});
      events.push(family);families.push(family);
    }
    if(!events.length)fail('Every series needs at least one note or explicit rest');
    const entry=freeze({id:name,voiceId,period,phase,events:freeze(events)});seriesById.set(name,entry);series.push(entry);
  }
  if(!series.length)fail('At least one complete series is required');
  let performance=null;
  if(raw.performance!==null){
    const p=fields(raw.performance,['id','revision','extent','cycles','introduction','ending'],s);
    const name=text(p.id,s),version=revision(p.revision),extent=list(p.extent,2,s,'Finite extent');if(extent.length!==2)fail('Finite extent needs two endpoints');
    const begin=nonnegative(extent[0],s),end=positive(extent[1],s);if(s.math.cmp(begin,end)>=0)fail('Empty or reversed finite extent');
    const cycles=[],seen=new Set;
    for(const r of list(p.cycles,series.length,s,'Finite cycle ranges')){
      fields(r,['seriesId','first','stop'],s);const seriesId=text(r.seriesId,s);
      if(!seriesById.has(seriesId)||seen.has(seriesId))fail('Unknown or duplicate finite cycle series');seen.add(seriesId);
      const first=cycle(r.first,s),stop=cycle(r.stop,s);if(first>stop)fail('Reversed finite cycles');cycles.push(freeze({seriesId,first,stop}));
    }
    if(seen.size!==series.length)fail('One explicit finite cycle range per series is required','missing-evidence');
    function section(raw,label){
      fields(raw,['from','to','events'],s);const from=nonnegative(raw.from,s),to=nonnegative(raw.to,s);
      if(s.math.cmp(from,to)>0||s.math.cmp(from,begin)<0||s.math.cmp(to,end)>0)fail('Transient span outside finite extent');
      const events=[],ids=new Set;
      for(const e of list(raw.events,s.limits.maxEvents,s,'Transient events')){
        fields(e,['id','voiceId','t','d','pitch'],s);const sourceId=text(e.id,s),voiceId=text(e.voiceId,s);
        if(ids.has(sourceId)||!authentic.voices.includes(voiceId))fail('Unique transient IDs and declared voices required');ids.add(sourceId);
        const t=nonnegative(e.t,s),d=positive(e.d,s),pitch=typedPitch(e.pitch,space,s);
        if(s.math.cmp(t,from)<0||s.math.cmp(s.math.add(t,d),to)>0)fail('A transient must lie wholly within its labelled span');
        events.push(freeze({id:`${label}:${events.length}`,sourceId,voiceId,t,d,pitch,clockDomain:domain,section:label}));
      }return freeze({from,to,events:freeze(events)});
    }
    const introduction=section(p.introduction,'introduction'),ending=section(p.ending,'ending');
    if(s.math.cmp(introduction.to,ending.from)>0)fail('Introduction and ending spans must be ordered and disjoint');
    performance=freeze({id:name,revision:version,begin,end,cycles:freeze(cycles),introduction,ending});
  }
  const eventWire=e=>({id:e.sourceId,voiceId:e.voiceId,t:String(e.t),d:String(e.d),pitch:e.pitch});
  const sectionWire=p=>({from:String(p.from),to:String(p.to),events:p.events.map(eventWire)});
  const definition=deepFreeze({kind:'periodic-canon-v1',id,revision:rev,inventoryComplete:true,profileHash:profile.hash,
    pitchSpaceHash:space.hash,clockDomain:domain,dependencies,occurrenceOrder:'lexical-generated-series/event-prefix-before-cycle',
    series:series.map(r=>({id:r.id,voiceId:r.voiceId,period:String(r.period),phase:String(r.phase),
      events:r.events.map(e=>({id:e.sourceId,t:String(e.t),d:String(e.d),pitch:e.pitch}))})),
    performance:performance?{id:performance.id,revision:performance.revision,extent:[String(performance.begin),String(performance.end)],
      cycles:performance.cycles.map(r=>({seriesId:r.seriesId,first:String(r.first),stop:String(r.stop)})),
      introduction:sectionWire(performance.introduction),ending:sectionWire(performance.ending)}:null});
  s.modelHash=digest(definition,s);return {definition,profile,domain,space,series:freeze(series),families:freeze(families),seriesById,performance};
}
function profileAudit(model,events,boundaries,s){
  const allowance=Math.min(s.limits.maxProfileWork,Math.floor((s.limits.maxWork-s.budget.used)/3));
  s.charge(allowance);let out;
  try{out=model.profile.audit(events,{boundaries,dependencies:{periodicModel:s.modelHash},maxWork:allowance,maxPredicateWork:allowance})}
  catch(error){s.charge(2*allowance);throw error}
  s.charge(out.workUsed+out.predicateWorkUsed);return out;
}
function project(audit,rules,s,domain=true){
  const names=new Set(rules.flatMap(r=>[r.id,`$coverage:${r.id}`]));if(domain)names.add('$domains');
  const checks=[];for(const c of audit.checks){s.charge();if(names.has(c.rule))checks.push(c)}
  return deepFreeze({status:reduce(checks.map(c=>c.status)),checks});
}
function eventOf(f,k,t,d,domain,section){return freeze({id:f.prefix+String(k),voiceId:f.voiceId,sourceId:f.sourceId,
  seriesId:f.seriesId,cycle:String(k),t,d,pitch:f.pitch,clockDomain:domain,section})}
function wire(events,s){return events.map(e=>{s.charge();return {...e,t:String(e.t),d:String(e.d)}})}
function evaluate(model,s){
  if(model.series.length>s.limits.maxSeries||model.families.length>s.limits.maxSourceEvents||model.definition.dependencies.length>s.limits.maxDependencies)
    fail('Prepared model exceeds the current source shape allowance','shape-budget');
  s.modelHash=digest(model.definition,s);const m=s.math,T=commonPeriod(model.series,s),onsets=[],phases=new Map;
  const addPhase=q=>{s.charge();const key=String(q);
    if(!phases.has(key)&&phases.size+3>s.limits.maxBoundaries)fail('True boundary allowance','shape-budget');phases.set(key,q)};
  for(const f of model.families){
    const h=m.div(T,f.period);if(h.d!==1n||h.n<=0n)throw new Error('Exact common period identity');
    const count=countRange(0n,h.n,s.limits.maxOnsets-onsets.length,s,'Common-period onsets');
    for(let j=0;j<count;j++){
      s.charge();const t=m.add(f.a0,m.mul(Q(j),f.period)),k=BigInt(j)-f.baseCycle;
      onsets.push({f,k,t,h:h.n});addPhase(t);addPhase(residue(m.add(t,f.d),T,s));
    }
  }
  const endpoints=[...phases.values()].sort((a,b)=>m.cmp(a,b));
  if(endpoints.length+2>s.limits.maxBoundaries)fail('True boundary allowance','shape-budget');
  const seam=endpoints[0],guard=m.sub(endpoints.at(-1),T),end=m.add(seam,T);
  const absoluteBoundaries=[guard,...endpoints,end],boundaries=absoluteBoundaries.map(q=>m.sub(q,guard)),geometry=[],ranges=[];
  for(const f of model.families){
    s.charge();const first=floor(m.div(m.sub(m.sub(guard,f.a0),f.d),f.period))+1n,stop=ceil(m.div(m.sub(end,f.a0),f.period));
    const count=countRange(first,stop,s.limits.maxEvents-geometry.length,s,'Intersecting periodic copies');
    ranges.push({seriesId:f.seriesId,sourceId:f.sourceId,first:String(first-f.baseCycle),stop:String(stop-f.baseCycle),count});
    for(let j=0;j<count;j++){
      s.charge();const k=first+BigInt(j),start=m.add(f.a0,m.mul(derivedInteger(k,s),f.period)),finish=m.add(start,f.d);
      const left=m.cmp(start,guard)>0?start:guard,right=m.cmp(finish,end)<0?finish:end;
      geometry.push(eventOf(f,k-f.baseCycle,m.sub(left,guard),m.sub(right,left),model.domain,'geometry-audit-copy'));
    }
  }
  const rules=model.profile.definition.rules,geometryRules=rules.filter(r=>r.type!=='melodic-bound'),melodyRules=rules.filter(r=>r.type==='melodic-bound');
  // Project the authentic whole audit; unrelated melodic checks on clipped events cannot affect geometry.
  const geometryAudit=project(profileAudit(model,geometry,boundaries,s),geometryRules,s);
  const melodic=[],melodicVoices=[];
  if(melodyRules.length)for(const voice of model.profile.definition.voices){
    const notes=[];for(const o of onsets){s.charge();if(o.f.voiceId===voice&&o.f.pitch!==null)notes.push(o)}
    if(!notes.length)continue;
    notes.sort((a,b)=>{const order=m.cmp(a.t,b.t);if(order)return order;
      const x=a.f.prefix+String(a.k),y=b.f.prefix+String(b.k);return x<y?-1:x>y?1:0});
    if(notes.length+1>s.limits.maxEvents-melodic.length)fail('Melodic predecessor material allowance','shape-budget');
    const last=notes.at(-1),previous={...last,t:m.sub(last.t,T),k:last.k-last.h};
    melodicVoices.push({voiceId:voice,cycleOnsets:notes.length,predecessorId:last.f.prefix+String(previous.k),predecessorTime:String(previous.t)});
    for(const o of [previous,...notes]){s.charge();melodic.push(eventOf(o.f,o.k,o.t,o.f.d,model.domain,'melodic-audit-copy'))}
  }
  let melodyAudit={status:'N/A',checks:[]},melodicOrigin=null;
  if(melodic.length){
    let origin=melodic[0].t;for(const e of melodic)if(m.cmp(e.t,origin)<0)origin=e.t;melodicOrigin=String(origin);
    for(let i=0;i<melodic.length;i++)melodic[i]=freeze({...melodic[i],t:m.sub(melodic[i].t,origin)});
    melodyAudit=project(profileAudit(model,melodic,[],s),melodyRules,s,false);
  }else if(melodyRules.length){
    const checks=[];for(const r of melodyRules){s.charge();checks.push({rule:r.id,status:'N/A'});if(r.required)checks.push({rule:`$coverage:${r.id}`,status:'UNKNOWN'})}
    melodyAudit={status:reduce(checks.map(c=>c.status)),checks};
  }
  const steadyStatus=reduce([geometryAudit.status,melodyAudit.status]);let finite={status:'UNKNOWN',reason:'No chosen finite performance supplied'},candidateEvents=[];
  if(model.performance){
    const p=model.performance,inventory=[];
    for(const r of p.cycles){
      const series=model.seriesById.get(r.seriesId),remaining=s.limits.maxEvents-candidateEvents.length;
      const count=countRange(r.first,r.stop,Math.floor(remaining/series.events.length),s,'Finite cycles');
      inventory.push({seriesId:r.seriesId,first:String(r.first),stop:String(r.stop),eventCount:count*series.events.length});
      for(let j=0;j<count;j++)for(const f of series.events){
        s.charge();const k=r.first+BigInt(j),t=m.add(f.a,m.mul(derivedInteger(k,s),f.period));
        if(m.cmp(t,p.begin)<0||m.cmp(m.add(t,f.d),p.end)>0)fail('A full periodic tail lies outside the authored finite extent');
        candidateEvents.push(eventOf(f,k,t,f.d,model.domain,'periodic-body'));
      }
    }
    for(const part of [p.introduction,p.ending])for(const e of part.events){
      s.charge();if(candidateEvents.length>=s.limits.maxEvents)fail('Finite union event allowance','shape-budget');candidateEvents.push(e);
    }
    const out=profileAudit(model,candidateEvents,[],s);
    finite={status:out.status,inventory,events:wire(candidateEvents,s),checks:out.checks};
  }
  const report=deepFreeze({modelHash:s.modelHash,status:reduce([steadyStatus,finite.status]),
    steady:{status:steadyStatus,period:String(T),seam:String(seam),guard:String(guard),end:String(end),
      boundaries:absoluteBoundaries.map(String),ranges,geometry:geometryAudit,geometryEventCount:geometry.length,
      geometryHash:digest(wire(geometry,s),s),melody:melodyAudit,melodicOrigin,melodicVoices,melodicHash:digest(wire(melodic,s),s)},finite});
  const certificate=freeze({kind:'periodic-canon-v1',modelHash:s.modelHash,reportHash:digest(report,s)});
  digest(certificate,s,s.limits.maxCertificateChars);return {report,certificate,candidateEvents:freeze(candidateEvents)};
}
function result(s,status,reason,extra={}){return freeze({status,reason,scope,modelHash:s?.modelHash??null,
  workUsed:s?.budget.used??0,resourceLimits:s?.limits??null,...extra})}
function run(options,body){let s;try{s=stateOf(options);return body(s)}catch(e){
  return result(s,e instanceof BadCertificate?'FAIL':'UNKNOWN',e.message??'Periodic processing refused',
    {kind:e instanceof Refused?e.kind:e instanceof BadCertificate?'invalid-certificate':'internal-error',conclusion:null})}}
function modelOf(prepared){const model=models.get(prepared);if(!model)fail('Use an authentic prepared periodic model');return model}

/** Validates and snapshots complete declared inputs; does not assert that their counterpoint passes. */
export function preparePeriodicCanon(spec,options={}){
  return run(options,s=>{const model=normalize(spec,s),prepared=freeze({kind:'prepared-periodic-canon-v1',modelHash:s.modelHash,definition:model.definition});
    models.set(prepared,model);return result(s,'PASS','Complete declared periodic model prepared',{prepared})});
}
/** Reconstructs the complete circular material and the chosen finite union, without running music. */
export function auditPeriodicCanon(prepared,options={}){
  return run(options,s=>{const output=evaluate(modelOf(prepared),s);return result(s,output.report.status,'Named static predicates on exact reconstructed material',output)});
}
/** Repeats complete reconstruction against the authentic model; validity PASS is distinct from conclusion. */
export function checkPeriodicCanon(prepared,raw,options={}){
  return run(options,s=>{
    const model=modelOf(prepared);fields(raw,['kind','modelHash','reportHash'],s);
    for(const k of ['kind','modelHash','reportHash'])text(raw[k],s,64);
    const supplied=digest(raw,s,s.limits.maxCertificateChars),expected=evaluate(model,s);
    if(supplied!==digest(expected.certificate,s,s.limits.maxCertificateChars))throw new BadCertificate('Certificate does not match complete independent reconstruction');
    return result(s,'PASS','Periodic certificate checked against the original complete model',{conclusion:expected.report.status,...expected});
  });
}
