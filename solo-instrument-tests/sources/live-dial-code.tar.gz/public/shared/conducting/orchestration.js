// A few voices, orchestrated (the owner, 3 October 2026: "Computing an orchestral fugue doesn't usually mean an 80-plus
// voice fugue but rather a smaller number of voices, orchestrated (although, in principle, some pitch/constraint spaces
// should allow for fugues over the orchestra with quite large number of voices)"). A conductor's contrapuntal voices
// are not its players: a voice is played by one section or more, doubled by every seat of them (each moved by octaves
// into its own register: section-voices.js), or by some of one section's seats -- down to a voice a seat, two hundred
// voices for two hundred players. How many voices a fugue has is drawn between its sections and its seats, mostly near
// its sections (an orchestra's fugue of a few voices), now and then many more (FUGUE_VOICES.dense).
//
// The voices' order is their sections' as given and each section's seats' (its instruments together, front desks
// first), so a voice of some seats is one instrument's where it can be.
import {intervalKind} from './counterpoint.js';

// Ours: how often a fugue is dense -- its voices `sections x (seats / sections)^d`, d a uniform draw to this power (4:
// most fugues within a third of the way, in the logarithm, from their sections to their seats; one in sixteen past
// half way).
// And how often a voice played by more than one section is doubled at an interval of its own in each section after its
// first (planing), a share drawn a fugue up to `doubling` (the square of a uniform draw: most fugues doubled at the
// octave alone).
// And how often its return is re-orchestrated -- each voice's return played by the sections that played another voice,
// the voices turned round by a drawn number of places -- a share drawn a fugue up to `reorchestrate` (likewise).
export const FUGUE_VOICES=Object.freeze({dense:4,doubling:.6,reorchestrate:.5});

// How many voices between `sections` and `seats` (counts), at `d` (0 to 1) of the way in the logarithm.
export const voicesAt=(d,sections,seats)=>Math.max(Math.min(2,seats),Math.min(seats,Math.round(sections*(Math.max(sections,seats)/Math.max(1,sections))**Math.max(0,Math.min(1,d)))));

// `sections`: [{id, seats: [seat ids, in order]}] (a section with none plays as one voice); `count` voices. -> [{id,
// parts: [{group (a section's id), seats (its seat ids, or null: all of them)}]}]. As few voices as sections or fewer:
// each its sections, contiguous, as many a voice as come out even, its id its section's where it has one. More: every
// section a voice at least, the rest shared as their seats are (the largest remainders, in order), each section's
// seats in contiguous runs, as even as they divide, a voice id `section#k`.
export function orchestrate({sections,count}){
  const n=sections.length;if(!n||!(count>=1))return [];
  if(count<=n){
    const out=[];let at=0;
    for(let k=0;k<count;k++){
      const take=Math.floor((k+1)*n/count)-Math.floor(k*n/count),mine=sections.slice(at,at+take);at+=take;
      out.push({id:mine.map(section=>section.id).join('+'),parts:mine.map(section=>({group:section.id,seats:null}))});
    }
    return out;
  }
  // (Each section's voices: one, then the rest as its seats are, never more than its seats.)
  const sizes=sections.map(section=>Math.max(1,section.seats?.length??1)),total=Math.min(count,sizes.reduce((a,b)=>a+b,0));
  const counts=sizes.map(()=>1);let left=total-n;
  const exact=sizes.map(size=>(total-n)*(size-1)/Math.max(1,sizes.reduce((a,b)=>a+b-1,0)));
  for(let i=0;i<n;i++){const add=Math.min(sizes[i]-1,Math.floor(exact[i]));counts[i]+=add;left-=add}
  const order=exact.map((x,i)=>[x-Math.floor(x),i]).sort((a,b)=>b[0]-a[0]||a[1]-b[1]).map(([,i])=>i);
  for(let pass=0;left>0&&pass<total;pass++)for(const i of order){if(left<=0)break;if(counts[i]<sizes[i]){counts[i]++;left--}}
  return sections.flatMap((section,i)=>{
    const seats=section.seats??[],k=counts[i];
    if(k===1)return [{id:section.id,parts:[{group:section.id,seats:null}]}];
    return Array.from({length:k},(_,v)=>({id:`${section.id}#${v+1}`,parts:[{group:section.id,seats:seats.slice(Math.floor(v*seats.length/k),Math.floor((v+1)*seats.length/k))}]}));
  });
}

// A voice's doublings (the owner, 3 October 2026, of an orchestral fugue: "a smaller number of voices, orchestrated";
// entries.js: planing, a doubling at an interval other than the octave): each section after a voice's first, as often
// as `share`, plays it a number of the collection's degrees above or below -- drawn among the degrees whose span its
// rules make cheapest in parallel (counterpoint.js: the kind of interval it is, consonance.width, weighed by the rules'
// own costs on that kind and on moving in parallel perfect intervals -- thirds and sixths under Fux's and Bach's, any
// degree under micropolyphony's), its octave then its players' (plex_clodbot voiceOctave). `voices` orchestrate's;
// `collection` the fugue's pitches; random [0, 1). -> the voices, a doubled part {group, seats, steps}.
export function doubled(voices,{collection,rules,share,random,period=12}){
  const classes=[];for(const p of collection.map(Number).filter(Number.isFinite).map(p=>((p%period)+period)%period).sort((a,b)=>a-b))if(!classes.some(c=>Math.abs(c-p)<1e-9))classes.push(p);
  const n=classes.length;if(n<3||!(share>0))return voices;
  const span=d=>classes.reduce((sum,c,i)=>sum+(((classes[(i+d)%n]-c)%period)+period)%period,0)/n;
  const cost=d=>{const kind=intervalKind(span(d)*100);return (rules.strong?.[kind]??0)+(rules.weak?.[kind]??0)+(kind==='perfect'?Number(rules.parallelPerfect)||0:0)};
  const costs=Array.from({length:n-1},(_,k)=>[k+1,cost(k+1)]),least=Math.min(...costs.map(([,c])=>c)),cheapest=costs.filter(([,c])=>c<=least+1e-9).map(([d])=>d);
  return voices.map(voice=>({...voice,parts:voice.parts.map((part,k)=>{
    if(k===0||!(random()<share))return part;
    const d=cheapest[Math.floor(random()*cheapest.length)];return {...part,steps:random()<.5?d:-d};
  })}));
}

// A return re-orchestrated (the backlog's orchestration, open: "re-orchestration at a return"): as often as `share`,
// each voice's return played by the sections of the voice `turn` places on (drawn from 1 to the voices less one), so a
// theme first heard in the strings returns in the brass. `voices` [voice ids], in order; random [0, 1). -> {voice: the
// voice whose sections play its return}, or null (each its own).
export function returnOrchestration(voices,{share,random}){
  const n=voices.length;if(n<2||!(random()<share))return null;
  const turn=1+Math.floor(random()*(n-1));return Object.fromEntries(voices.map((voice,k)=>[voice,voices[(k+turn)%n]]));
}
