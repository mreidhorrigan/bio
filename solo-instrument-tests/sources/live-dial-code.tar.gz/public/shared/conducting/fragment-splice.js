// CFM030 / CF22: complete original fragment unions, not an inference from standalone validity.
import {Q} from './canon-core.js';
import {compilePitchOperations} from './pitch-spaces.js';
import {decomposeCounterpointProfile} from './counterpoint-profile.js';
import {dataRecord,dataArray} from './contract-data.js';
import {Refused,Budget,EXACT_LIMITS,pythonJson,sha256} from '../bounded-exact.js';

export const FRAGMENT_SPLICE_LIMITS=Object.freeze({maxFragments:64,maxPlacements:64,maxEvents:4096,maxContexts:256,
  maxDependencies:128,maxOperations:256,maxWork:2000000,maxProfileWork:2000000,maxTextChars:4194304,maxDataNodes:65536});
const freeze=Object.freeze,models=new WeakMap,admissions=new WeakMap,zero=Q(0),rawBound=1n<<256n;
const scope='complete-original-fragment-union-and-named-whole-profile';
const fail=(reason,kind='invalid-input')=>{throw new Refused(reason,{kind})};
class BadCertificate extends Error {}
const certify=(condition,reason)=>{if(!condition)throw new BadCertificate(reason)};
function stateOf(options){
  if(!dataRecord(options)||Object.keys(options).some(k=>!Object.hasOwn(FRAGMENT_SPLICE_LIMITS,k)))fail('Unknown splice options');
  const limits={};for(const [key,cap] of Object.entries(FRAGMENT_SPLICE_LIMITS)){
    const value=Object.hasOwn(options,key)?options[key]:key==='maxProfileWork'?90000:cap;
    if(!Number.isSafeInteger(value)||value<0||value>cap)fail('Splice allowances must be bounded nonnegative integers');limits[key]=value;
  }
  const s={limits:freeze(limits),used:0,chars:0,dataNodes:0,modelHash:null};
  s.charge=(n=1)=>{if(!Number.isSafeInteger(n)||n<0)throw new Error('Invalid splice work charge');
    if(n>limits.maxWork-s.used)fail('Splice work allowance exhausted','work-budget');s.used+=n};
  s.math={add(a,b){s.charge();return a.add(b)},sub(a,b){s.charge();return a.sub(b)},mul(a,b){s.charge();return a.mul(b)},cmp(a,b){s.charge();return a.cmp(b)}};
  s.charge();return s;
}
function fields(v,keys,s){s.charge();if(!dataRecord(v)||Object.keys(v).length!==keys.length||keys.some(k=>!Object.hasOwn(v,k)))fail('Missing or unsupported splice fields');s.charge(keys.length);return v}
function list(v,cap,s,label){if(!Array.isArray(v)||v.length>cap)fail(label+' exceeds its array allowance','shape-budget');s.charge(v.length+1);return dataArray(v,cap,label)}
function name(v,s,cap=256){
  if(typeof v!=='string'||!v.length||v.length>cap)fail('Bounded nonempty text required');
  if(v.length>s.limits.maxTextChars-s.chars)fail('Splice text allowance','work-budget');s.chars+=v.length;s.charge(1+Math.ceil(v.length/64));return v;
}
function revision(v){if(!Number.isSafeInteger(v)||v<0)fail('A nonnegative safe revision is required');return v}
function boolean(v){if(typeof v!=='boolean')fail('Declare completeness explicitly');return v}
function unique(seen,id){if(seen.has(id))fail('Duplicate splice identity');seen.add(id);return id}
function integer(v){const n=typeof v==='bigint'?v:Number.isSafeInteger(v)?BigInt(v):null;
  if(n===null||n<=-rawBound||n>=rawBound)fail('Raw exact components must fit256bits','arithmetic-budget');return n}
function rational(v,s){
  s.charge();let n,d=1n;
  if(typeof v==='string'){
    name(v,s,160);const m=v.match(/^([+-]?[0-9]+)(?:\/([+-]?[0-9]+))?$/);
    if(!m||m[0].length!==v.length)fail('Use exact integer or fraction text');n=integer(BigInt(m[1]));d=integer(BigInt(m[2]??'1'));
  }else if(v&&typeof v==='object'){fields(v,['n','d'],s);n=integer(v.n);d=integer(v.d)}else n=integer(v);
  if(!d)fail('Zero denominator');return Q({n,d});
}
function nonnegative(v,s){const q=rational(v,s);if(s.math.cmp(q,zero)<0)fail('Negative time');return q}
function positive(v,s){const q=rational(v,s);if(s.math.cmp(q,zero)<=0)fail('A strictly positive duration or scale is required');return q}
function clock(v,s){fields(v,['id','unit','revision'],s);return freeze({id:name(v.id,s),unit:name(v.unit,s),revision:revision(v.revision)})}
function snapshot(v,s,depth=0,seen=new Set){
  s.charge();if(++s.dataNodes>s.limits.maxDataNodes)fail('Splice metadata-node allowance','shape-budget');
  if(v===null||typeof v==='boolean')return v;
  if(typeof v==='number'){if(!Number.isFinite(v))fail('Nonfinite metadata');return Object.is(v,-0)?0:v}
  if(typeof v==='string'){if(!v.length)return v;return name(v,s,2048)}
  if(depth>=12||seen.has(v))fail('Cyclic or deep splice metadata');seen.add(v);let out;
  if(Array.isArray(v)){list(v,s.limits.maxDataNodes,s,'Metadata array');out=[];for(const x of v)out.push(snapshot(x,s,depth+1,seen))}
  else{if(!dataRecord(v)||Object.keys(v).length>256)fail('Metadata must be ordinary bounded records');out={};
    for(const key of Object.keys(v)){name(key,s);Object.defineProperty(out,key,{value:snapshot(v[key],s,depth+1,seen),enumerable:true})}}
  seen.delete(v);return freeze(out);
}
function encode(v,s){const text=pythonJson(v);if(text.length>s.limits.maxTextChars)fail('Canonical splice text allowance','work-budget');s.charge(1+Math.ceil(text.length/64));return text}
function hash(v,s){return sha256(encode(v,s))}
function freezeDeep(v){if(v&&typeof v==='object'&&!Object.isFrozen(v)){for(const x of Object.values(v))freezeDeep(x);freeze(v)}return v}
function typed(raw,space,s){
  if(raw===null)return null;fields(raw,['space','definition','coordinate'],s);
  if(name(raw.space,s)!==space.id||name(raw.definition,s)!==space.hash)fail('Typed pitch belongs to another space','out-of-model');
  const value=Array.isArray(raw.coordinate)?list(raw.coordinate,32,s,'Pitch coordinate').map(x=>rational(x,s)):rational(raw.coordinate,s);
  s.charge();return space.pitch(value);
}
function reference(raw,s){fields(raw,['id','revision','hash'],s);const id=name(raw.id,s),h=name(raw.hash,s,64);
  if(h.length!==64||!/^[0-9a-f]{64}$/.test(h))fail('A lowercase SHA-256 provenance reference is required');return freeze({id,revision:revision(raw.revision),hash:h})}
function event(raw,voices,space,s){
  fields(raw,['id','voiceId','t','d','pitch'],s);const id=name(raw.id,s),voiceId=name(raw.voiceId,s);
  if(!voices.has(voiceId))fail('Event voice is undeclared');return freeze({id,voiceId,t:nonnegative(raw.t,s),d:positive(raw.d,s),pitch:typed(raw.pitch,space,s)});
}
function operations(raw,space,s){
  const ops=[];for(const v of list(raw,s.limits.maxOperations,s,'Pitch operations')){
    if(!dataRecord(v)||!['transpose','reflect'].includes(v.type))fail('Declare supported typed pitch operations','out-of-model');
    const field=v.type==='transpose'?'by':'pivot';fields(v,['type',field],s);
    const value=Array.isArray(v[field])?list(v[field],32,s,'Pitch operand').map(x=>rational(x,s)):rational(v[field],s);
    ops.push({type:v.type,[field]:value});
  }s.charge(ops.length+1);return compilePitchOperations(space,ops);
}
function normalize(raw,s){
  fields(raw,['id','revision','pitchSpace','profile','fragments','placements','environment','bindings','dependencies'],s);
  const id=name(raw.id,s),version=revision(raw.revision),space=raw.pitchSpace;compilePitchOperations(space,[]);
  const profile=raw.profile,info=decomposeCounterpointProfile(profile);
  if(info.pitchSpaceHash!==space.hash)fail('Whole profile and fragment pitch space differ','out-of-model');
  const targetClock=info.clockDomain,targetVoices=new Set(info.voices),fragments=[],fragmentById=new Map;let sourceEvents=0;
  for(const v of list(raw.fragments,s.limits.maxFragments,s,'Original fragments')){
    fields(v,['id','revision','complete','clockDomain','length','voices','events','provenance'],s);const fragmentId=name(v.id,s);
    if(fragmentById.has(fragmentId))fail('Duplicate original fragment');const voices=[],seen=new Set;
    for(const voice of list(v.voices,32,s,'Source voices'))voices.push(unique(seen,name(voice,s)));if(!voices.length)fail('Declare source voices');
    const length=positive(v.length,s),events=[],ids=new Set;
    for(const value of list(v.events,s.limits.maxEvents-sourceEvents,s,'Source events')){
      const e=event(value,seen,space,s);unique(ids,e.id);if(s.math.cmp(s.math.add(e.t,e.d),length)>0)fail('An original event exceeds its fragment extent');events.push(e);
    }sourceEvents+=events.length;
    const fragment=freeze({id:fragmentId,revision:revision(v.revision),complete:boolean(v.complete),clockDomain:clock(v.clockDomain,s),length,
      voices:freeze(voices),events:freeze(events),provenance:reference(v.provenance,s)});fragments.push(fragment);fragmentById.set(fragmentId,fragment);
  }if(!fragments.length)fail('A nonempty original fragment library is required');
  const placements=[],placementIds=new Set;let expandedEvents=0,operationCount=0;
  for(const v of list(raw.placements,s.limits.maxPlacements,s,'Fragment placements')){
    fields(v,['id','fragmentId','offset','scale','voices'],s);const placementId=unique(placementIds,name(v.id,s)),fragmentId=name(v.fragmentId,s),fragment=fragmentById.get(fragmentId);
    if(!fragment)fail('Placement names an unknown original fragment');if(fragment.events.length>s.limits.maxEvents-expandedEvents)fail('Expanded fragment event allowance','shape-budget');expandedEvents+=fragment.events.length;
    const assigned=[],seen=new Set,byVoice=new Map;
    for(const value of list(v.voices,32,s,'Voice assignments')){
      fields(value,['sourceVoice','targetVoice','pitchOperations'],s);const from=unique(seen,name(value.sourceVoice,s)),to=name(value.targetVoice,s);
      if(!fragment.voices.includes(from)||!targetVoices.has(to))fail('Unknown source or target voice');
      const op=operations(value.pitchOperations,space,s);if(op.operations.length>s.limits.maxOperations-operationCount)fail('Total pitch-operation allowance','shape-budget');operationCount+=op.operations.length;
      const assignment=freeze({sourceVoice:from,targetVoice:to,pitchOperations:op.operations});assigned.push(assignment);byVoice.set(from,{assignment,op});
    }if(seen.size!==fragment.voices.length)fail('Assign every declared source voice exactly once');
    const definition=freeze({id:placementId,fragmentId,offset:nonnegative(v.offset,s),scale:positive(v.scale,s),voices:freeze(assigned)});
    placements.push({definition,fragment,byVoice});
  }if(!placements.length)fail('At least one placement is required');
  const env=fields(raw.environment,['id','revision','complete','events','contexts'],s),events=[],ids=new Set,contexts=[],contextIds=new Set;
  for(const v of list(env.events,s.limits.maxEvents-expandedEvents,s,'Fixed environment')){const e=event(v,targetVoices,space,s);unique(ids,e.id);events.push(e)}expandedEvents+=events.length;
  for(const v of list(env.contexts,s.limits.maxContexts,s,'Context cells')){
    fields(v,['id','revision','from','to','complete','data'],s);const from=nonnegative(v.from,s),to=nonnegative(v.to,s);
    if(s.math.cmp(from,to)>=0||contexts.length&&s.math.cmp(from,contexts.at(-1).to)<0)fail('Context cells must be ordered, disjoint and nonempty');
    if(!dataRecord(v.data))fail('Context data must be a record');contexts.push(freeze({id:unique(contextIds,name(v.id,s)),revision:revision(v.revision),from,to,complete:boolean(v.complete),data:snapshot(v.data,s)}));
  }
  const environment=freeze({id:name(env.id,s),revision:revision(env.revision),complete:boolean(env.complete),events:freeze(events),contexts:freeze(contexts)});
  if(!dataRecord(raw.bindings))fail('Context/boundary bindings must be a record');const bindings=snapshot(raw.bindings,s),dependencies=[],depIds=new Set;
  for(const v of list(raw.dependencies,s.limits.maxDependencies,s,'Dependencies')){
    fields(v,['id','revision','data'],s);dependencies.push(freeze({id:unique(depIds,name(v.id,s)),revision:revision(v.revision),data:snapshot(v.data,s)}));
  }
  const definition=freezeDeep({kind:'fragment-splice-v1',id,revision:version,pitchSpace:space.definition,profile:profile.definition,targetClock,
    fragments,placements:placements.map(p=>p.definition),environment,bindings,dependencies});
  const semanticKey=encode(definition,s);s.modelHash=sha256(semanticKey);
  return {definition,semanticKey,space,profile,targetClock,fragments,placements,environment,expandedEvents,sourceEvents,operationCount,
    complete:environment.complete&&placements.every(p=>p.fragment.complete)};
}
function modelOf(prepared,s){const m=models.get(prepared);if(!m)fail('Use an authentic prepared splice model','out-of-model');s.modelHash=prepared.modelHash;
  if(m.fragments.length>s.limits.maxFragments||m.placements.length>s.limits.maxPlacements||m.sourceEvents>s.limits.maxEvents||m.expandedEvents>s.limits.maxEvents||
    m.environment.contexts.length>s.limits.maxContexts||m.definition.dependencies.length>s.limits.maxDependencies||m.operationCount>s.limits.maxOperations)fail('Prepared splice shape allowance','shape-budget');return m}
function result(s,status,reason,extra={}){return freeze({status,reason,scope,modelHash:s?.modelHash??null,workUsed:s?.used??0,resourceLimits:s?.limits??null,...extra})}
function run(options,body){let s;try{s=stateOf(options);return body(s)}catch(e){return result(s,e instanceof BadCertificate?'FAIL':'UNKNOWN',e.message??'Splice refused',
  {kind:e instanceof Refused?e.kind:e instanceof BadCertificate?'invalid-certificate':'internal-error',conclusion:null,certificate:null,admitted:null})}}
function materialize(model,s,replay){
  const events=[],extents=[];
  for(let i=0;i<model.placements.length;i++){
    const p=model.placements[i],d=p.definition;extents.push(freeze({placementId:d.id,fragmentId:d.fragmentId,from:String(d.offset),to:String(s.math.add(d.offset,s.math.mul(d.scale,p.fragment.length)))}));
    for(let j=0;j<p.fragment.events.length;j++){
      s.charge();const source=p.fragment.events[j],binding=p.byVoice.get(source.voiceId),a=s.math.add(d.offset,s.math.mul(d.scale,source.t));let duration,pitch=source.pitch;
      if(replay){const b=s.math.add(d.offset,s.math.mul(d.scale,s.math.add(source.t,source.d)));duration=s.math.sub(b,a);
        if(pitch!==null)for(const op of binding.assignment.pitchOperations){s.charge();pitch=model.space.apply(pitch,op)}}
      else{duration=s.math.mul(d.scale,source.d);if(pitch!==null){s.charge(binding.op.operations.length+1);pitch=binding.op.apply(pitch)}}
      events.push(freeze({id:`f:${i}:${j}`,voiceId:binding.assignment.targetVoice,t:a,d:duration,pitch,clockDomain:model.targetClock,
        origin:freeze({kind:'fragment',fragmentId:d.fragmentId,fragmentRevision:p.fragment.revision,placementId:d.id,sourceId:source.id,sourceVoice:source.voiceId,provenance:p.fragment.provenance})}));
    }
  }
  for(let i=0;i<model.environment.events.length;i++){s.charge();const source=model.environment.events[i];events.push(freeze({...source,id:`e:${i}`,clockDomain:model.targetClock,
    origin:freeze({kind:'environment',sourceId:source.id,id:model.environment.id,revision:model.environment.revision})}))}
  return {events:freeze(events),extents:freeze(extents)};
}
function contextAt(model,time,budget){
  const cells=model.environment.contexts;let lo=0,hi=cells.length;
  while(lo<hi){budget.charge();const mid=(lo+hi)>>1;if(cells[mid].from.cmp(time)<=0)lo=mid+1;else hi=mid}
  const cell=cells[lo-1];budget.charge();return cell&&time.cmp(cell.to)<0?cell:null;
}
function coverage(model,events,s){
  if(!model.complete)return false;
  for(const e of events){s.charge();if(e.pitch===null)continue;let at=e.t;const end=s.math.add(e.t,e.d);
    while(s.math.cmp(at,end)<0){const cell=contextAt(model,at,s);if(!cell||!cell.complete)return false;at=s.math.cmp(cell.to,end)<0?cell.to:end}}
  return true;
}
function evaluate(model,s,replay){
  const material=materialize(model,s,replay);
  if(!coverage(model,material.events,s))return {status:'UNKNOWN',reason:'Complete placed fragments, environment and every sounding context interval are required'};
  const total=Math.min(s.limits.maxProfileWork,s.limits.maxWork-s.used),allocated=Math.min(EXACT_LIMITS.maxWork,Math.floor(total/4));
  if(!allocated)fail('No whole splice audit allowance remains','work-budget');const contextBudget=new Budget(allocated),boundaries=[];let out;
  try{
    for(const cell of model.environment.contexts){contextBudget.charge();boundaries.push(cell.from,cell.to)}
    out=model.profile.audit(material.events,{boundaries,contextAt:time=>contextAt(model,time,contextBudget)?.data??freeze({}),
      dependencies:{splice:s.modelHash,bindings:model.definition.bindings,declared:model.definition.dependencies},maxWork:allocated,maxPredicateWork:allocated});
  }catch(error){s.charge(4*allocated);throw error}
  s.charge(allocated+out.workUsed+out.predicateWorkUsed+contextBudget.used);
  const events=material.events.map(e=>{s.charge();return freeze({...e,t:String(e.t),d:String(e.d)})});
  const report=freezeDeep({scope,modelHash:s.modelHash,status:out.status,extents:material.extents,events,eventHash:hash(events,s),
    audit:snapshot({status:out.status,profileHash:out.profileHash,contextHash:out.contextHash,claim:out.claim,checks:out.checks,applicability:out.applicability,pairApplicability:out.pairApplicability},s),
    bindings:model.definition.bindings,dependencies:model.definition.dependencies});
  return {status:out.status,report,reportHash:hash(report,s)};
}
/** Preparation binds complete original material and exact placements; it grants no splice validity. */
export function prepareFragmentSplice(spec,options={}){
  return run(options,s=>{const model=normalize(spec,s),prepared=freeze({kind:'prepared-fragment-splice-v1',modelHash:s.modelHash,definition:model.definition});
    models.set(prepared,model);return result(s,'PASS','Original fragments and common-time join prepared',{prepared})});
}
/** Audit the full original union, including all sustains, cross-rest moves and every context boundary. */
export function auditFragmentSplice(prepared,options={}){
  return run(options,s=>{const model=modelOf(prepared,s),out=evaluate(model,s,false),decisive=out.status==='PASS'||out.status==='FAIL';
    const certificate=decisive?freeze({kind:'fragment-splice-certificate-v1',modelHash:s.modelHash,conclusion:out.status,reportHash:out.reportHash}):null;
    return result(s,out.status,out.reason??'Complete original union audited under the mandatory whole profile',{report:out.report??null,certificate})});
}
/** Replay both mapped endpoints and each ordered pitch operation; derive the complete audit, never trust a report. */
export function checkFragmentSplice(prepared,raw,options={}){
  return run(options,s=>{const model=modelOf(prepared,s);fields(raw,['kind','modelHash','conclusion','reportHash'],s);
    certify(raw.kind==='fragment-splice-certificate-v1'&&raw.modelHash===s.modelHash,'Original splice identity differs');
    certify(raw.conclusion==='PASS'||raw.conclusion==='FAIL','Unknown splice conclusion');name(raw.reportHash,s,64);
    certify(raw.reportHash.length===64&&/^[0-9a-f]{64}$/.test(raw.reportHash),'Invalid splice report hash');
    const out=evaluate(model,s,true);if(out.status!=='PASS'&&out.status!=='FAIL')fail('The original splice is unresolved','missing-evidence');
    certify(out.status===raw.conclusion&&out.reportHash===raw.reportHash,'Original replay or whole-profile conclusion differs');let admitted=null;
    if(out.status==='PASS'){admitted=freeze({kind:'admitted-fragment-splice-v1',modelHash:s.modelHash,report:out.report});admissions.set(admitted,{semanticKey:model.semanticKey,report:out.report})}
    return result(s,'PASS','Complete original replay confirms the stated splice conclusion',{conclusion:out.status,report:out.report,admitted});
  });
}
/** Exact-context reuse only. No new musical audit and no inference about a changed physical realization. */
export function reuseFragmentSplice(admitted,currentPrepared,options={}){
  return run(options,s=>{const model=modelOf(currentPrepared,s),receipt=admissions.get(admitted);if(!receipt)fail('A checker-issued passing splice is required','missing-evidence');
    if(model.semanticKey.length>s.limits.maxTextChars)fail('Reuse definition-text allowance','work-budget');s.charge(1+Math.ceil(model.semanticKey.length/64));
    if(receipt.semanticKey!==model.semanticKey)fail('Fragment, placement, profile or context/dependency changed; revalidate','stale-context');
    return result(s,'PASS','Reusing the same checked complete splice proposition',{conclusion:'PASS',reused:true,report:receipt.report,admitted});
  });
}
