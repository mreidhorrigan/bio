// EC04/EC09: exact weighted projection onto a declared affine set, including immutable coordinate locks.
// This is an algebraic edit proposal, not musical/physical admission. Units, affine meaning, authority and the
// protected original-theme predicates remain the owner's contract. No Number tolerance or rank estimate is used.
import {dataArray,dataRecord} from './contract-data.js';
import {Refused,Budget,EXACT_LIMITS,ZERO,ONE,add,sub,mul,div,equal,exactOf,exactText,pythonJson,sha256} from '../bounded-exact.js';

export const ELASTIC_PROJECTION_LIMITS=Object.freeze({coordinates:24,rows:64,string:256,
  text:1048576,hashChars:1048576,inputBits:256,certificateBits:8192,
  defaultWork:100000,maxWork:500000});
const freeze=Object.freeze;
const scope='exact-supplied-affine-set-and-positive-weighted-objective';
const fail=(message,kind='invalid-input')=>{throw new Refused(message,{kind})};
const inputBoundary=1n<<256n,certificateBoundary=1n<<8192n;
function fields(value,keys){
  if(!dataRecord(value)||Object.keys(value).length!==keys.length||keys.some(key=>!Object.hasOwn(value,key)))fail('Unexpected or missing affine-projection fields');
  return value;
}
function count(value,maximum){
  if(!Number.isSafeInteger(value)||value<0||value>maximum)fail('Invalid affine-projection count');
  return value;
}
function text(value,state,limit=ELASTIC_PROJECTION_LIMITS.string){
  if(typeof value!=='string'||!value.length||value.length>limit)fail('Invalid bounded affine-projection text');
  state.chars+=value.length;if(state.chars>ELASTIC_PROJECTION_LIMITS.text)fail('Affine-projection text budget','work-budget');
  return value;
}
function integerToken(value,bits){
  if(typeof value==='bigint'){
    const boundary=bits===EXACT_LIMITS.inputBits?inputBoundary:certificateBoundary;
    if(value<=-boundary||value>=boundary)fail('Raw rational component exceeds its bit budget','arithmetic-budget');
  }else if(!Number.isSafeInteger(value))fail('Use safe integer rational components');
  return value;
}
function readExact(value,state,bits=EXACT_LIMITS.inputBits){
  state.budget.charge();let input=value;
  if(typeof value==='string'){
    text(value,state,bits===EXACT_LIMITS.inputBits?160:6000);
    const quotient=value.match(/^([+-]?[0-9]+)\/([0-9]+)$/);
    if(quotient){integerToken(BigInt(quotient[1]),bits);integerToken(BigInt(quotient[2]),bits)}
  }else if(typeof value==='number'||typeof value==='bigint')integerToken(value,bits);
  else{
    fields(value,['n','d']);input={n:integerToken(value.n,bits),d:integerToken(value.d,bits)};
  }
  const result=exactOf(input,{bits});
  if(typeof value!=='string')text(exactText(result),state,bits===EXACT_LIMITS.inputBits?160:6000);
  return result;
}
const arithmetic=budget=>({
  add(a,b){budget.charge();return add(a,b)},sub(a,b){budget.charge();return sub(a,b)},
  mul(a,b){budget.charge();return mul(a,b)},div(a,b){budget.charge();return div(a,b)}
});
function dot(a,b,state){
  if(a.length!==b.length)throw new Error('Internal affine dot-product dimension');
  let result=ZERO;
  for(let i=0;i<a.length;i++){
    state.budget.charge();if(a[i].n!==0n&&b[i].n!==0n)result=state.math.add(result,state.math.mul(a[i],b[i]));
  }
  return result;
}
function hash(value,state){
  const encoded=pythonJson(value);
  if(encoded.length>ELASTIC_PROJECTION_LIMITS.hashChars)fail('Affine model hash budget','work-budget');
  state.budget.charge(1+Math.ceil(encoded.length/64));return sha256(encoded);
}
function normalize(spec,state){
  fields(spec,['id','revision','coordinates','equalities']);
  const id=text(spec.id,state),revision=count(spec.revision,Number.MAX_SAFE_INTEGER);
  dataArray(spec.coordinates,ELASTIC_PROJECTION_LIMITS.coordinates,'Affine coordinates');
  dataArray(spec.equalities,ELASTIC_PROJECTION_LIMITS.rows,'Affine equalities');
  const coordinates=[],coordinateIds=new Set;
  for(let i=0;i<spec.coordinates.length;i++){
    state.budget.charge();const c=fields(spec.coordinates[i],['id','unit','target','weight','lock']);
    const name=text(c.id,state),unit=text(c.unit,state),target=readExact(c.target,state),weight=readExact(c.weight,state);
    if(coordinateIds.has(name)||weight.n<=0n)fail('Coordinate identities must be unique and weights strictly positive');
    coordinateIds.add(name);const lock=c.lock===null?null:readExact(c.lock,state);
    coordinates.push(freeze({id:name,unit,target,weight,lock}));
  }
  const equalities=[],equalityIds=new Set,rows=[],rowIds=[],n=coordinates.length;
  for(let i=0;i<spec.equalities.length;i++){
    state.budget.charge();const e=fields(spec.equalities[i],['id','coefficients','rhs']),name=text(e.id,state);
    if(equalityIds.has(name))fail('Equality identities must be unique');equalityIds.add(name);
    dataArray(e.coefficients,ELASTIC_PROJECTION_LIMITS.coordinates,'Affine coefficients');
    if(e.coefficients.length!==n)fail('Every equality needs one coefficient per declared coordinate');
    const coefficients=[];for(let j=0;j<n;j++)coefficients.push(readExact(e.coefficients[j],state));
    const row=freeze({coefficients:freeze(coefficients),rhs:readExact(e.rhs,state)});
    equalities.push(freeze({id:name,...row}));rows.push(row);rowIds.push(freeze({kind:'equality',id:name}));
  }
  for(let i=0;i<n;i++)if(coordinates[i].lock!==null){
    state.budget.charge(n+1);
    if(rows.length===ELASTIC_PROJECTION_LIMITS.rows)fail('Equalities and locks exceed the row cap','row-budget');
    const coefficients=[];for(let j=0;j<n;j++)coefficients.push(i===j?ONE:ZERO);
    rows.push(freeze({coefficients:freeze(coefficients),rhs:coordinates[i].lock}));
    rowIds.push(freeze({kind:'lock',coordinateId:coordinates[i].id}));
  }
  const definition=freeze({id,revision,coordinates:freeze(coordinates),equalities:freeze(equalities)});
  const modelHash=hash(definition,state);state.modelHash=modelHash;
  return freeze({definition,rows:freeze(rows),rowIds:freeze(rowIds),hash:modelHash});
}

// Forward elimination keeps each transformed row's exact combination of ALL original equality/lock rows.
// The original row identities selected as pivots form an independent basis; no numerical rank tolerance exists.
function rowBasis(model,state){
  const n=model.definition.coordinates.length,m=model.rows.length,rows=[],selected=[];
  for(let i=0;i<m;i++){
    state.budget.charge(n+m+1);const combination=[];
    for(let j=0;j<m;j++)combination.push(i===j?ONE:ZERO);
    rows.push({coefficients:[...model.rows[i].coefficients],rhs:model.rows[i].rhs,combination,original:i});
  }
  let rank=0;
  for(let col=0;col<n&&rank<m;col++){
    state.budget.charge();let p=rank;
    while(p<m){state.budget.charge();if(rows[p].coefficients[col].n!==0n)break;p++}
    if(p===m)continue;
    [rows[rank],rows[p]]=[rows[p],rows[rank]];const pivot=rows[rank];selected.push(pivot.original);
    for(let i=rank+1;i<m;i++){
      state.budget.charge();const row=rows[i];if(row.coefficients[col].n===0n)continue;
      const factor=state.math.div(row.coefficients[col],pivot.coefficients[col]);
      for(let j=col+1;j<n;j++)row.coefficients[j]=state.math.sub(row.coefficients[j],state.math.mul(factor,pivot.coefficients[j]));
      row.rhs=state.math.sub(row.rhs,state.math.mul(factor,pivot.rhs));
      for(let j=0;j<m;j++)row.combination[j]=state.math.sub(row.combination[j],state.math.mul(factor,pivot.combination[j]));
      row.coefficients[col]=ZERO;
    }
    rank++;
  }
  for(let i=rank;i<m;i++){
    state.budget.charge();if(rows[i].rhs.n!==0n)return {rank,contradiction:rows[i].combination};
  }
  return {rank,selected};
}

// This system is the independent-row positive definite Gram system. Gaussian elimination and back-substitution
// use exact rationals; a singular Gram matrix would be an implementation invariant failure, never UNSAT.
function solveGram(matrix,state){
  const n=matrix.length;
  for(let col=0;col<n;col++){
    state.budget.charge();let p=col;
    while(p<n){state.budget.charge();if(matrix[p][col].n!==0n)break;p++}
    if(p===n)throw new Error('Independent affine Gram matrix lost rank');
    [matrix[col],matrix[p]]=[matrix[p],matrix[col]];
    for(let i=col+1;i<n;i++){
      state.budget.charge();if(matrix[i][col].n===0n)continue;
      const factor=state.math.div(matrix[i][col],matrix[col][col]);
      for(let j=col+1;j<=n;j++)matrix[i][j]=state.math.sub(matrix[i][j],state.math.mul(factor,matrix[col][j]));
      matrix[i][col]=ZERO;
    }
  }
  const solution=new Array(n);
  for(let i=n-1;i>=0;i--){
    state.budget.charge();let rhs=matrix[i][n];
    for(let j=i+1;j<n;j++)rhs=state.math.sub(rhs,state.math.mul(matrix[i][j],solution[j]));
    solution[i]=state.math.div(rhs,matrix[i][i]);
  }
  return solution;
}
function minimum(model,selected,state){
  const coordinates=model.definition.coordinates,n=coordinates.length,m=model.rows.length,r=selected.length;
  const target=coordinates.map(c=>c.target),basis=selected.map(i=>model.rows[i]),scaled=[],matrix=[];
  for(let i=0;i<r;i++){
    const row=[];for(let j=0;j<n;j++)row.push(state.math.div(basis[i].coefficients[j],coordinates[j].weight));
    scaled.push(row);
  }
  for(let i=0;i<r;i++){
    state.budget.charge();const row=[];
    for(let j=0;j<r;j++)row.push(dot(basis[i].coefficients,scaled[j],state));
    row.push(state.math.sub(dot(basis[i].coefficients,target,state),basis[i].rhs));matrix.push(row);
  }
  const multipliers=solveGram(matrix,state),solution=[],lifted=[];
  for(let i=0;i<m;i++){state.budget.charge();lifted.push(ZERO)}
  for(let i=0;i<r;i++){state.budget.charge();lifted[selected[i]]=multipliers[i]}
  for(let j=0;j<n;j++){
    let correction=ZERO;for(let i=0;i<r;i++)correction=state.math.add(correction,state.math.mul(scaled[i][j],multipliers[i]));
    solution.push(state.math.sub(target[j],correction));
  }
  return {solution,multipliers:lifted};
}

// Deliberately independent of rowBasis/solveGram: only the original equalities, weights and proposed certificate
// are used. W(x-q)+A^T lambda=0 is stationarity for HALF the reported objective sum w_i(x_i-q_i)^2.
function verify(model,kind,solution,multipliers,state){
  const coordinates=model.definition.coordinates,rows=model.rows,n=coordinates.length,m=rows.length;
  const reject=reason=>({status:'FAIL',reason});
  if(kind==='minimum'){
    for(let i=0;i<m;i++){
      state.budget.charge();if(!equal(dot(rows[i].coefficients,solution,state),rows[i].rhs))return reject('The certificate violates an equality or coordinate lock');
    }
    let objective=ZERO;
    for(let j=0;j<n;j++){
      state.budget.charge();const delta=state.math.sub(solution[j],coordinates[j].target);
      let stationarity=state.math.mul(coordinates[j].weight,delta);
      for(let i=0;i<m;i++){
        state.budget.charge();if(multipliers[i].n!==0n&&rows[i].coefficients[j].n!==0n)stationarity=state.math.add(stationarity,state.math.mul(rows[i].coefficients[j],multipliers[i]));
      }
      if(stationarity.n!==0n)return reject('The certificate is feasible but does not prove weighted stationarity');
      objective=state.math.add(objective,state.math.mul(coordinates[j].weight,state.math.mul(delta,delta)));
    }
    return {status:'PASS',conclusion:'SAT',reason:'Exact equality and stationarity establish the unique affine minimum',objective};
  }
  for(let j=0;j<n;j++){
    let coefficient=ZERO;
    for(let i=0;i<m;i++){
      state.budget.charge();if(multipliers[i].n!==0n&&rows[i].coefficients[j].n!==0n)coefficient=state.math.add(coefficient,state.math.mul(multipliers[i],rows[i].coefficients[j]));
    }
    if(coefficient.n!==0n)return reject('An infeasibility combination must cancel every coordinate');
  }
  const rhs=dot(multipliers,rows.map(row=>row.rhs),state);
  if(rhs.n===0n)return reject('The row combination has no nonzero contradiction');
  return {status:'PASS',conclusion:'UNSAT',reason:'An exact row combination proves 0 equals a nonzero value',contradictionRhs:rhs};
}
function exactVector(raw,length,state){
  dataArray(raw,Math.max(ELASTIC_PROJECTION_LIMITS.coordinates,ELASTIC_PROJECTION_LIMITS.rows),'Affine certificate vector');
  if(raw.length!==length)fail('Affine certificate vector has the wrong dimension');
  const out=[];for(let i=0;i<length;i++)out.push(readExact(raw[i],state,EXACT_LIMITS.workBits));return out;
}
function writeVector(values,state){
  const out=[];for(const value of values){state.budget.charge();out.push(text(exactText(value),state,6000))}return freeze(out);
}
function result(status,reason,model,state,extra={}){
  return freeze({status,reason,scope,modelHash:model.hash,...extra,workUsed:state.budget.used});
}
function run(options,body){
  let state;
  try{
    if(!dataRecord(options)||Object.keys(options).some(key=>key!=='maxWork'))fail('Only maxWork is supported in affine-projection options');
    const limit=Object.hasOwn(options,'maxWork')?count(options.maxWork,ELASTIC_PROJECTION_LIMITS.maxWork):ELASTIC_PROJECTION_LIMITS.defaultWork;
    const budget=new Budget(limit);
    state={budget,math:arithmetic(budget),chars:0,modelHash:null};budget.charge();return body(state);
  }catch(error){
    if(!(error instanceof Refused))throw error;
    return freeze({status:'UNKNOWN',reason:error.message,kind:error.kind,scope,modelHash:state?.modelHash??null,workUsed:state?.budget.used??0});
  }
}

/** Minimize sum_i weight_i*(x_i-target_i)^2 over the supplied exact affine equalities and locks. */
export function projectAffineEdits(spec,options={}){
  return run(options,state=>{
    const model=normalize(spec,state),basis=rowBasis(model,state),coordinateIds=freeze(model.definition.coordinates.map(c=>c.id));
    if(basis.contradiction){
      const checked=verify(model,'infeasible',null,basis.contradiction,state);
      if(checked.status!=='PASS')throw new Error('Elimination produced an invalid affine contradiction');
      const certificate=freeze({kind:'infeasible',modelHash:model.hash,multipliers:writeVector(basis.contradiction,state)});
      return result('UNSAT',checked.reason,model,state,{rank:basis.rank,coordinateIds,rowIds:model.rowIds,
        contradictionRhs:exactText(checked.contradictionRhs),certificate});
    }
    const proposed=minimum(model,basis.selected,state),checked=verify(model,'minimum',proposed.solution,proposed.multipliers,state);
    if(checked.status!=='PASS')throw new Error('Projection produced an invalid affine minimum');
    const solution=writeVector(proposed.solution,state),certificate=freeze({kind:'minimum',modelHash:model.hash,solution,
      multipliers:writeVector(proposed.multipliers,state)});
    return result('SAT',checked.reason,model,state,{rank:basis.rank,coordinateIds,rowIds:model.rowIds,solution,
      objective:exactText(checked.objective),certificate});
  });
}

/** PASS/FAIL/UNKNOWN checks only the certificate's affine conclusion; it never establishes musical acceptance. */
export function checkAffineProjection(spec,certificate,options={}){
  return run(options,state=>{
    const model=normalize(spec,state);
    if(!dataRecord(certificate))fail('An affine certificate must be a plain data record');
    const kind=certificate.kind;
    if(kind==='minimum')fields(certificate,['kind','modelHash','solution','multipliers']);
    else if(kind==='infeasible')fields(certificate,['kind','modelHash','multipliers']);
    else fail('Unknown affine certificate kind');
    const modelHash=text(certificate.modelHash,state,64);
    if(!/^[0-9a-f]{64}$/.test(modelHash))fail('Malformed affine model hash');
    const multipliers=exactVector(certificate.multipliers,model.rows.length,state);
    const solution=kind==='minimum'?exactVector(certificate.solution,model.definition.coordinates.length,state):null;
    if(modelHash!==model.hash)return result('FAIL','The certificate belongs to another affine model snapshot',model,state);
    const checked=verify(model,kind,solution,multipliers,state),extra={};
    if(checked.status==='PASS'){
      extra.conclusion=checked.conclusion;
      if(kind==='minimum'){extra.solution=writeVector(solution,state);extra.objective=exactText(checked.objective)}
      else extra.contradictionRhs=exactText(checked.contradictionRhs);
    }
    return result(checked.status,checked.reason,model,state,extra);
  });
}
