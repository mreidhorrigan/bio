// EC08/10/11/16: exact finite priority bands and exposure of supplied residual slices.
// A feasibility witness and a complete priority selection are different results. No candidate is installed.
// Named hard predicates are trusted synchronous planning code; charges do not bound their execution time.
import {Q,Rational} from './canon-core.js';
import {Budget,Refused,exactOf,exactOfNumber,pythonJson,sha256} from '../bounded-exact.js';
import {dataRecord,dataArray} from './contract-data.js';

export const ELASTIC_SELECTION_LIMITS=Object.freeze({candidates:128,tiers:16,terms:16,metrics:64,
  slices:2048,eventMentions:8192,eventsPerSlice:128,dataNodes:32768,dataWidth:4096,depth:16,
  id:128,string:2048,text:262144,hashChars:1000000});
const freeze=Object.freeze;
const fail=(message,kind='invalid-input')=>{throw new Refused(message,{kind})};
const scope='declared-finite-candidates-and-named-hard-contract';
function fields(value,required,optional=[]){
  if(!dataRecord(value)||required.some(key=>!Object.hasOwn(value,key))||
    Object.keys(value).some(key=>!required.includes(key)&&!optional.includes(key)))fail('Unexpected or missing elastic data fields');
  return value;
}
function text(value,state,limit=ELASTIC_SELECTION_LIMITS.id){
  if(typeof value!=='string'||!value.length||value.length>limit)fail('Invalid bounded elastic text');
  state.chars+=value.length;if(state.chars>ELASTIC_SELECTION_LIMITS.text)fail('Elastic text budget','work-budget');return value;
}
const integer=(value,limit=Number.MAX_SAFE_INTEGER)=>{
  if(!Number.isSafeInteger(value)||value<0||value>limit)fail('Expected a bounded nonnegative integer');return value;
};
function scalar(value,state){
  state.budget.charge();let result;
  if(typeof value==='string'){text(value,state,160);result=Q(exactOf(value))}
  else if(Array.isArray(value)){
    dataArray(value,2,'Exact rational');if(value.length!==2)fail('A rational pair has two integers');result=Q(exactOf(value));
  }else{
    if(dataRecord(value))fields(value,['n','d']);result=Q(value);
  }
  text(String(result),state,6000);return result;
}
const nonnegative=(value,state)=>{const q=scalar(value,state);if(q.cmp(0)<0)fail('A cost, weight, band or cap must be nonnegative');return q};
const positive=(value,state)=>{const q=scalar(value,state);if(q.cmp(0)<=0)fail('A normalizer must be positive');return q};
const abs=q=>q.cmp(0)<0?Q(0).sub(q):q;

// Copy by value. Type-tagged hash input distinguishes exact Q metadata from identically spelled text.
// Raw BigInt metadata is deliberately refused: use an authentic Q or an explicitly textual identity.
function snapshot(value,state,depth=0,seen=new Set){
  state.budget.charge();if(++state.dataNodes>ELASTIC_SELECTION_LIMITS.dataNodes)fail('Elastic snapshot budget','work-budget');
  if(value===null)return {value,encoded:['null']};
  if(typeof value==='boolean')return {value,encoded:['boolean',value]};
  if(typeof value==='number'){
    if(!Number.isFinite(value))fail('Nonfinite metadata');value=Object.is(value,-0)?0:value;return {value,encoded:['number',value]};
  }
  if(typeof value==='string'){
    if(value.length)text(value,state,ELASTIC_SELECTION_LIMITS.string);return {value,encoded:['string',value]};
  }
  if(value&&Object.getPrototypeOf(value)===Rational.prototype){
    const q=Q(value);if(q!==value)fail('Unowned rational metadata');const spelling=text(String(q),state,6000);
    return {value:q,encoded:['rational',spelling]};
  }
  if(depth>=ELASTIC_SELECTION_LIMITS.depth||seen.has(value))fail('Cyclic or deep elastic metadata');
  seen.add(value);let out,encoded;
  if(Array.isArray(value)){
    dataArray(value,ELASTIC_SELECTION_LIMITS.dataWidth,'Elastic metadata');out=[];encoded=[];
    for(const item of value){const saved=snapshot(item,state,depth+1,seen);out.push(saved.value);encoded.push(saved.encoded)}
    encoded=['array',encoded];
  }else{
    if(!dataRecord(value))fail('Elastic metadata must be ordinary finite data');
    const keys=Object.keys(value);if(keys.length>ELASTIC_SELECTION_LIMITS.dataWidth)fail('Wide elastic metadata');
    out={};const coded={};
    for(const key of keys){
      text(key,state,ELASTIC_SELECTION_LIMITS.string);const saved=snapshot(value[key],state,depth+1,seen);
      Object.defineProperty(out,key,{value:saved.value,enumerable:true});
      Object.defineProperty(coded,key,{value:saved.encoded,enumerable:true});
    }
    encoded=['object',coded];
  }
  seen.delete(value);return {value:freeze(out),encoded};
}
function hash(value,state){
  const bytes=pythonJson(value);if(bytes.length>ELASTIC_SELECTION_LIMITS.hashChars)fail('Elastic hash budget','work-budget');
  state.budget.charge(1+Math.ceil(bytes.length/64));return sha256(bytes);
}
function begin(options){
  fields(options,[],['maxWork']);const budget=new Budget(options.maxWork);budget.charge();
  return {budget,chars:0,dataNodes:0};
}

// The explicit legacy Number boundary preserves its shortest decimal spelling, not its prior computation's truth.
export function elasticFromNumber(value){
  const exact=Q(exactOfNumber(value));
  return freeze({exact,conversion:freeze({kind:'number-as-decimal',value,exact:String(exact)})});
}

function normalizeSelection(spec,state){
  fields(spec,['id','revision','domainComplete','hard','tiers','candidates','dependencies']);
  const id=text(spec.id,state),revision=integer(spec.revision);
  if(typeof spec.domainComplete!=='boolean')fail('Declare finite-domain completeness');
  let hard=null;
  if(spec.hard!==null){
    fields(spec.hard,['id','version','check']);if(typeof spec.hard.check!=='function')fail('A hard predicate must be a function');
    hard=freeze({id:text(spec.hard.id,state),version:integer(spec.hard.version),check:spec.hard.check});
  }
  dataArray(spec.tiers,ELASTIC_SELECTION_LIMITS.tiers,'Priority tiers');if(!spec.tiers.length)fail('Declare at least one priority tier');
  const tiers=[],tierIds=new Set,metrics=new Map;
  for(const raw of spec.tiers){
    state.budget.charge();fields(raw,['id','band','terms']);const name=text(raw.id,state);
    if(tierIds.has(name))fail('Duplicate tier identity');tierIds.add(name);
    const band=nonnegative(raw.band,state);dataArray(raw.terms,ELASTIC_SELECTION_LIMITS.terms,'Tier terms');
    if(!raw.terms.length)fail('A tier needs explicit terms');const terms=[],used=new Set;
    for(const term of raw.terms){
      state.budget.charge();fields(term,['metric','unit','normalizer','weight']);
      const metric=text(term.metric,state),unit=text(term.unit,state);
      if(used.has(metric))fail('Repeated metric in one tier');used.add(metric);
      if(metrics.has(metric)&&metrics.get(metric)!==unit)fail('A metric cannot silently change units across tiers');
      metrics.set(metric,unit);if(metrics.size>ELASTIC_SELECTION_LIMITS.metrics)fail('Metric-description cap','work-budget');
      terms.push(freeze({metric,unit,normalizer:positive(term.normalizer,state),weight:nonnegative(term.weight,state)}));
    }
    tiers.push(freeze({id:name,band,terms:freeze(terms)}));
  }
  dataArray(spec.candidates,ELASTIC_SELECTION_LIMITS.candidates,'Elastic candidates');
  const candidates=[],encodedCandidates=[],ids=new Set;
  for(const raw of spec.candidates){
    state.budget.charge();fields(raw,['id','complete','data','costs']);const name=text(raw.id,state);
    if(ids.has(name))fail('Duplicate candidate identity');ids.add(name);
    if(typeof raw.complete!=='boolean')fail('Declare whether each candidate is a complete plan');
    fields(raw.costs,[...metrics.keys()]);const parsed=new Map,wire={};
    for(const metric of metrics.keys()){
      state.budget.charge();const value=raw.costs[metric]===null?null:nonnegative(raw.costs[metric],state);parsed.set(metric,value);
      Object.defineProperty(wire,metric,{value:value===null?null:String(value),enumerable:true});
    }
    const saved=snapshot(raw.data,state),candidate=freeze({id:name,complete:raw.complete,data:saved.value,costs:freeze(wire)});
    candidates.push({candidate,costs:parsed});encodedCandidates.push({...candidate,data:saved.encoded});
  }
  const dependencies=snapshot(spec.dependencies,state);if(!dataRecord(dependencies.value))fail('Dependencies must be a data record');
  const definition=freeze({id,revision,domainComplete:spec.domainComplete,hard:hard?freeze({id:hard.id,version:hard.version}):null,
    tiers:freeze(tiers.map(t=>freeze({id:t.id,band:String(t.band),terms:freeze(t.terms.map(term=>freeze({...term,normalizer:String(term.normalizer),weight:String(term.weight)})))}))),
    candidates:freeze(candidates.map(row=>row.candidate)),dependencies:dependencies.value});
  const modelHash=hash({...definition,candidates:encodedCandidates,dependencies:dependencies.encoded},state);
  return {definition,hard,tiers,candidates,modelHash};
}

function evaluateHard(model,row,state){
  const candidate=row.candidate;
  if(!candidate.complete)return freeze({id:candidate.id,status:'UNKNOWN',reason:'Candidate is a partial plan',evidence:null});
  if(!model.hard)return freeze({id:candidate.id,status:'UNKNOWN',reason:'No named hard contract was supplied',evidence:null});
  state.budget.charge();let reply;
  try{reply=model.hard.check(candidate,freeze({modelHash:model.modelHash,maxWork:state.budget.limit-state.budget.used}))}
  catch{return freeze({id:candidate.id,status:'UNKNOWN',reason:'Hard predicate refused or threw',evidence:null})}
  let status,evidence=null;
  if(typeof reply==='string')status=reply;
  else{evidence=snapshot(reply,state).value;status=dataRecord(evidence)?evidence.status:null}
  if(!['PASS','FAIL','UNKNOWN'].includes(status))return freeze({id:candidate.id,status:'UNKNOWN',reason:'Unsupported hard verdict',evidence:null});
  return freeze({id:candidate.id,status,reason:'Named hard contract on the supplied complete candidate',evidence});
}
function costVector(model,row,state){
  for(const value of row.costs.values())if(value===null)return null;
  return model.tiers.map(tier=>{
    let total=Q(0);
    for(const term of tier.terms){state.budget.charge();total=total.add(row.costs.get(term.metric).div(term.normalizer).mul(term.weight))}
    return total;
  });
}

// tiers are explicitly ordered MOST protected first. No numeric rank or 2a elastic.js tier direction is inferred.
export function selectElasticCandidates(spec,options={}){
  let state,model=null;const verified=[];
  try{
    state=begin(options);model=normalizeSelection(spec,state);const evaluations=[],passing=[],unresolved=[];
    for(const row of model.candidates){
      const verdict=evaluateHard(model,row,state);evaluations.push(verdict);
      if(verdict.status==='PASS'){verified.push(row.candidate);passing.push(row)}
      else if(verdict.status==='UNKNOWN')unresolved.push(row.candidate.id);
    }
    const ranked=[],unknownCosts=[];
    for(const row of passing){
      state.budget.charge();const vector=costVector(model,row,state);
      if(vector===null)unknownCosts.push(row.candidate.id);else ranked.push({candidate:row.candidate,vector});
    }
    const decisive=model.definition.domainComplete&&model.hard!==null&&!unresolved.length;
    const feasibilityStatus=verified.length?'SAT':decisive?'UNSAT':'UNKNOWN';
    const certified=decisive&&!unknownCosts.length;
    const selectionStatus=feasibilityStatus==='UNSAT'?'INFEASIBLE':certified?'CERTIFIED':'UNKNOWN';
    const tierTrace=[];let retained=[...ranked];
    for(let tier=0;tier<model.tiers.length&&retained.length;tier++){
      let best=retained[0].vector[tier];
      for(const row of retained){state.budget.charge();if(row.vector[tier].cmp(best)<0)best=row.vector[tier]}
      const cutoff=best.add(model.tiers[tier].band),before=retained.length,next=[];
      for(const row of retained){state.budget.charge();if(row.vector[tier].cmp(cutoff)<=0)next.push(row)}
      retained=next;tierTrace.push(freeze({id:model.tiers[tier].id,best:String(best),band:String(model.tiers[tier].band),
        cutoff:String(cutoff),inputCount:before,retainedIds:freeze(retained.map(row=>row.candidate.id))}));
    }
    const frontier=[];
    for(let i=0;i<ranked.length;i++){
      state.budget.charge();let dominated=false;
      for(let j=0;j<ranked.length&&!dominated;j++){
        if(i===j)continue;let noWorse=true,strict=false;
        for(let t=0;t<model.tiers.length;t++){
          state.budget.charge();const order=ranked[j].vector[t].cmp(ranked[i].vector[t]);
          if(order>0){noWorse=false;break}if(order<0)strict=true;
        }
        if(noWorse&&strict)dominated=true;
      }
      if(!dominated)frontier.push(ranked[i].candidate.id);
    }
    const ids=freeze(retained.map(row=>row.candidate.id)),rankingScope=certified?'complete-feasible-domain':'verified-known-cost-subset';
    return freeze({feasibilityStatus,selectionStatus,scope,modelHash:model.modelHash,definition:model.definition,
      verifiedFeasible:freeze(verified),evaluations:freeze(evaluations),unknownEligibility:freeze(unresolved),unknownCosts:freeze(unknownCosts),
      alternatives:selectionStatus==='CERTIFIED'?ids:freeze([]),provisionalAlternatives:selectionStatus==='UNKNOWN'?ids:freeze([]),
      tierTrace:freeze(tierTrace),rankingScope,frontier:freeze({ids:freeze(frontier),certified,scope:rankingScope}),
      tierCosts:freeze(ranked.map(row=>freeze({id:row.candidate.id,costs:freeze(row.vector.map(String))}))),workUsed:state.budget.used});
  }catch(error){
    if(!(error instanceof Refused))throw error;
    return freeze({feasibilityStatus:verified.length?'SAT':'UNKNOWN',selectionStatus:'UNKNOWN',scope,
      modelHash:model?.modelHash??null,reason:error.message,kind:error.kind,verifiedFeasible:freeze(verified),
      alternatives:freeze([]),provisionalAlternatives:freeze([]),tierTrace:freeze([]),frontier:null,workUsed:state?.budget.used??0});
  }
}

// Slices form a possibly incomplete description of one POSITIVE-length window. Overlap/straddling is refused.
// Missing durations/residuals produce lower bounds only; observed violations remain decisive despite missing data.
// Event counts refer to the supplied stable structural IDs, never to how many slices/notation fragments were used.
export function elasticExposure(spec,options={}){
  let state,modelHash=null;
  try{
    state=begin(options);fields(spec,['id','revision','time','residualUnit','window','slices','affectedThreshold','caps']);
    const id=text(spec.id,state),revision=integer(spec.revision),clock=fields(spec.time,['id','revision','kind','unit']);
    if(!['score','wall'].includes(clock.kind))fail('Declare score or wall duration');
    const time=freeze({id:text(clock.id,state),revision:integer(clock.revision),kind:clock.kind,unit:text(clock.unit,state)});
    const residualUnit=text(spec.residualUnit,state),threshold=nonnegative(spec.affectedThreshold,state);
    dataArray(spec.window,2,'Exposure window');if(spec.window.length!==2)fail('An exposure window has two endpoints');
    const start=scalar(spec.window[0],state),end=scalar(spec.window[1],state);
    if(start.cmp(end)>=0)fail('Exposure requires a positive-length window');
    const capsRaw=fields(spec.caps,['peak','absoluteExposure','squaredExposure','affectedEvents']),caps={};
    for(const key of ['peak','absoluteExposure','squaredExposure'])caps[key]=capsRaw[key]===null?null:nonnegative(capsRaw[key],state);
    caps.affectedEvents=capsRaw.affectedEvents===null?null:integer(capsRaw.affectedEvents);
    dataArray(spec.slices,ELASTIC_SELECTION_LIMITS.slices,'Residual slices');const slices=[],ids=new Set;let mentions=0;
    for(const raw of spec.slices){
      state.budget.charge();fields(raw,['id','from','to','residual','eventIds']);const name=text(raw.id,state);
      if(ids.has(name))fail('Duplicate residual-slice identity');ids.add(name);
      const from=scalar(raw.from,state),to=scalar(raw.to,state),residual=raw.residual===null?null:scalar(raw.residual,state);
      if(from.cmp(to)>=0||from.cmp(start)<0||to.cmp(end)>0)fail('A positive residual slice must lie wholly inside its window');
      dataArray(raw.eventIds,ELASTIC_SELECTION_LIMITS.eventsPerSlice,'Structural event identities');const eventIds=[],seen=new Set;
      for(const value of raw.eventIds){
        state.budget.charge();if(++mentions>ELASTIC_SELECTION_LIMITS.eventMentions)fail('Structural event-mention cap','work-budget');
        const event=text(value,state);if(seen.has(event))fail('Duplicate event identity within one slice');seen.add(event);eventIds.push(event);
      }
      eventIds.sort((a,b)=>{state.budget.charge();return a<b?-1:a>b?1:0});
      slices.push({id:name,from,to,residual,eventIds:freeze(eventIds)});
    }
    slices.sort((a,b)=>{state.budget.charge();return a.from.cmp(b.from)||(a.id<b.id?-1:a.id>b.id?1:0)});
    let cursor=start,gap=Q(0);
    for(const row of slices){
      state.budget.charge();if(row.from.cmp(cursor)<0)fail('Residual slices overlap');gap=gap.add(row.from.sub(cursor));cursor=row.to;
    }
    gap=gap.add(end.sub(cursor));
    const definition=freeze({id,revision,time,residualUnit,window:freeze([String(start),String(end)]),affectedThreshold:String(threshold),
      caps:freeze({...Object.fromEntries(['peak','absoluteExposure','squaredExposure'].map(key=>[key,caps[key]===null?null:String(caps[key])])),affectedEvents:caps.affectedEvents}),
      slices:freeze(slices.map(row=>freeze({id:row.id,from:String(row.from),to:String(row.to),residual:row.residual===null?null:String(row.residual),eventIds:row.eventIds})))});
    modelHash=hash(definition,state);let peak=Q(0),absoluteExposure=Q(0),squaredExposure=Q(0),unknownDuration=Q(0),knownDuration=Q(0);
    const affected=new Set;
    for(const row of slices){
      state.budget.charge();const duration=row.to.sub(row.from);
      if(row.residual===null){unknownDuration=unknownDuration.add(duration);continue}
      knownDuration=knownDuration.add(duration);const magnitude=abs(row.residual);
      if(magnitude.cmp(peak)>0)peak=magnitude;
      absoluteExposure=absoluteExposure.add(duration.mul(magnitude));squaredExposure=squaredExposure.add(duration.mul(row.residual.mul(row.residual)));
      if(magnitude.cmp(threshold)>0)for(const event of row.eventIds){state.budget.charge();affected.add(event)}
    }
    const complete=gap.n===0n&&unknownDuration.n===0n;
    const bounds=freeze({peak:String(peak),absoluteExposure:String(absoluteExposure),squaredExposure:String(squaredExposure),affectedEvents:affected.size});
    const violations=[];
    for(const [key,value] of [['peak',peak],['absoluteExposure',absoluteExposure],['squaredExposure',squaredExposure]]){
      state.budget.charge();if(caps[key]!==null&&value.cmp(caps[key])>0)violations.push(freeze({metric:key,knownLowerBound:String(value),cap:String(caps[key])}));
    }
    if(caps.affectedEvents!==null&&affected.size>caps.affectedEvents)violations.push(freeze({metric:'affectedEvents',knownLowerBound:affected.size,cap:caps.affectedEvents}));
    const eventIds=[...affected].sort((a,b)=>{state.budget.charge();return a<b?-1:a>b?1:0});
    return freeze({status:violations.length?'FAIL':complete?'PASS':'UNKNOWN',scope:'supplied-residual-function-and-structural-identities',
      modelHash,definition,complete,lowerBounds:bounds,exactTotals:complete?bounds:null,violations:freeze(violations),
      knownAffectedEventIds:freeze(eventIds),affectedScope:'Union of supplied stable event IDs on known slices above the authored threshold',
      windowDuration:String(end.sub(start)),knownResidualDuration:String(knownDuration),unknownResidualDuration:String(unknownDuration),uncoveredDuration:String(gap),
      units:freeze({peak:residualUnit,absoluteExposure:`${residualUnit}*${time.unit}`,squaredExposure:`${residualUnit}^2*${time.unit}`}),workUsed:state.budget.used});
  }catch(error){
    if(!(error instanceof Refused))throw error;
    return freeze({status:'UNKNOWN',scope:'supplied-residual-function-and-structural-identities',modelHash,reason:error.message,kind:error.kind,
      complete:false,lowerBounds:null,exactTotals:null,knownAffectedEventIds:freeze([]),workUsed:state?.budget.used??0});
  }
}
