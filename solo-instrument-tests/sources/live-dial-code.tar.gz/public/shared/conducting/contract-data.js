// Data boundaries for exact planning contracts. Ordinary records/arrays, with own enumerable data fields only.
// Reject overridden traversal and getters before taking a semantic snapshot. Proxies and modified host intrinsics
// are outside this data contract; this does not sandbox code already executing inside the same JavaScript realm.
import {Refused} from '../bounded-exact.js';

export function dataRecord(value){
  if(!value||typeof value!=='object'||Array.isArray(value))return false;
  const prototype=Object.getPrototypeOf(value);if(prototype!==Object.prototype&&prototype!==null)return false;
  for(const key of Reflect.ownKeys(value)){
    if(typeof key!=='string')return false;
    const descriptor=Object.getOwnPropertyDescriptor(value,key);
    if(!descriptor.enumerable||!Object.hasOwn(descriptor,'value'))return false;
  }
  return true;
}

export function dataArray(value,limit,label='Array'){
  const fail=()=>{throw new Refused(`${label} must be a dense ordinary data array of at most ${limit} values`)};
  if(!Array.isArray(value)||Object.getPrototypeOf(value)!==Array.prototype||value.length>limit)fail();
  for(const key of Reflect.ownKeys(value)){
    if(key==='length')continue;
    if(typeof key!=='string'||!/^(0|[1-9]\d*)$/.test(key)||Number(key)>=value.length)fail();
    const descriptor=Object.getOwnPropertyDescriptor(value,key);
    if(!descriptor.enumerable||!Object.hasOwn(descriptor,'value'))fail();
  }
  for(let i=0;i<value.length;i++)if(!Object.hasOwn(value,i))fail();
  return value;
}
