// CFM-028 / CF20, EC12: bounded exact repair of the original finite forward graph.
// Times, voices, maps and context are fixed. Every admitted assignment is replayed and audited whole.
import {Refused,exactOf,exactText,add,mul,compare,pythonJson,sha256} from '../bounded-exact.js';
import {dataRecord,dataArray} from './contract-data.js';
import {materializeConstraintPullbackAssignment,checkConstraintPullback} from './constraint-pullback.js';

export const PROTECTED_REPAIR_LIMITS=Object.freeze({maxWork:4000000,maxAssignments:4096,maxAxes:8,
  maxPullbackWork:500000,maxProfileWork:2000000,maxTextChars:4194304});
const freeze=Object.freeze,models=new WeakMap,scope='finite-fixed-time-protected-forward-repair';
const rawBound=1n<<256n,zero=exactOf(0);
const fail=(reason,kind='invalid-input')=>{throw new Refused(reason,{kind})};
class BadCertificate extends Error {}
const certify=(condition,reason)=>{if(!condition)throw new BadCertificate(reason)};
function stateOf(options){
  if(!dataRecord(options)||Object.keys(options).some(k=>!Object.hasOwn(PROTECTED_REPAIR_LIMITS,k)))fail('Unknown repair options');
  const limits={};for(const [key,cap] of Object.entries(PROTECTED_REPAIR_LIMITS)){
    const value=Object.hasOwn(options,key)?options[key]:key==='maxProfileWork'?20000:cap;
    if(!Number.isSafeInteger(value)||value<0||value>cap)fail('Repair allowances must be bounded nonnegative integers');limits[key]=value;
  }
  const s={limits:freeze(limits),used:0,chars:0,modelHash:null};
  s.charge=(n=1)=>{if(!Number.isSafeInteger(n)||n<0)throw new Error('Invalid repair work charge');
    if(n>limits.maxWork-s.used)fail('Repair work allowance exhausted','work-budget');s.used+=n};s.charge();return s;
}
function fields(v,keys,s){
  s.charge();if(!dataRecord(v)||Object.keys(v).length!==keys.length||keys.some(k=>!Object.hasOwn(v,k)))fail('Missing or unsupported repair fields');
  s.charge(keys.length);return v;
}
function list(v,max,s,label){
  if(!Array.isArray(v)||v.length>max)fail(label+' exceeds its array allowance','shape-budget');
  s.charge(v.length+1);return dataArray(v,max,label);
}
function name(v,s,max=256){
  if(typeof v!=='string'||!v.length||v.length>max)fail('Bounded nonempty text required');
  if(v.length>s.limits.maxTextChars-s.chars)fail('Repair text allowance','work-budget');
  s.chars+=v.length;s.charge(1+Math.ceil(v.length/64));return v;
}
function natural(v){if(!Number.isSafeInteger(v)||v<0)fail('Invalid revision');return v}
function integer(v){
  const n=typeof v==='bigint'?v:Number.isSafeInteger(v)?BigInt(v):null;
  if(n===null||n<=-rawBound||n>=rawBound)fail('Raw exact component cap is256bits','arithmetic-budget');return n;
}
function nonnegative(v,s){
  s.charge();let n,d=1n;
  if(typeof v==='string'){
    name(v,s,160);const m=v.match(/^([+-]?[0-9]+)(?:\/([+-]?[0-9]+))?$/);
    if(!m||m[0].length!==v.length)fail('Use exact integer or fraction text');n=integer(BigInt(m[1]));d=integer(BigInt(m[2]??'1'));
  }else if(v&&typeof v==='object'){fields(v,['n','d'],s);n=integer(v.n);d=integer(v.d)}else n=integer(v);
  if(!d)fail('Zero denominator');const q=exactOf({n,d});if(q.n<0n)fail('Repair costs and commitment times must be nonnegative');return q;
}
function freezeDeep(v){if(v&&typeof v==='object'&&!Object.isFrozen(v)){for(const x of Object.values(v))freezeDeep(x);freeze(v)}return v}
function key(v,s){
  // Only authenticated original data or locally reconstructed bounded data reach this encoder.
  const text=pythonJson(v);if(text.length>s.limits.maxTextChars)fail('Canonical repair text allowance','work-budget');
  s.charge(1+Math.ceil(text.length/64));return text;
}
function hash(v,s){return sha256(key(v,s))}
function result(s,status,reason,extra={}){return freeze({status,reason,scope,modelHash:s?.modelHash??null,
  workUsed:s?.used??0,resourceLimits:s?.limits??null,...extra})}
function run(options,body){let s;try{s=stateOf(options);return body(s)}catch(e){return result(s,e instanceof BadCertificate?'FAIL':'UNKNOWN',e.message??'Repair refused',
  {kind:e instanceof Refused?e.kind:e instanceof BadCertificate?'invalid-certificate':'internal-error',conclusion:null,certificate:null})}}
function nested(prepared,assignment,s,witness=null){
  s.charge();const allowance=Math.min(s.limits.maxPullbackWork,s.limits.maxWork-s.used);
  const out=witness===null?materializeConstraintPullbackAssignment(prepared,assignment,{maxWork:allowance}):
    checkConstraintPullback(prepared,witness,{maxWork:allowance,maxProfileWork:s.limits.maxProfileWork});
  if(!Number.isSafeInteger(out.workUsed)||out.workUsed<0||out.workUsed>allowance)throw new Error('Invalid nested pullback receipt');
  s.charge(out.workUsed);
  if(out.status==='UNKNOWN'&&typeof out.kind==='string'&&out.kind.includes('budget'))fail(out.reason,out.kind);
  return out;
}
function assignmentOf(raw,variables,s){
  list(raw,16,s,'Assignment');if(raw.length!==variables.length)fail('Assign every original variable once');const chosen=new Map;
  for(const x of raw){fields(x,['variableId','candidateId'],s);const id=name(x.variableId,s),value=name(x.candidateId,s),v=variables.find(v=>v.id===id);
    s.charge(variables.length);if(!v||chosen.has(id)||!v.values.some(x=>x.id===value))fail('Unknown or repeated assignment value');chosen.set(id,value)}
  return freeze(variables.map(v=>freeze({variableId:v.id,candidateId:chosen.get(v.id)})));
}
function uniqueNames(raw,allowed,max,s,label){
  const out=[],seen=new Set;for(const value of list(raw,max,s,label)){
    const id=name(value,s);if(!allowed.has(id)||seen.has(id))fail('Unknown or repeated '+label);seen.add(id);out.push(id);
  }return out;
}
function normalize(original,raw,s){
  fields(raw,['id','revision','baseline','editableVariables','protectedSourceIds','protectedOccurrences','committedUntil','axes','variableCosts'],s);
  // Authenticate the prepared original before reading any public property. A failing old profile is allowed;
  // an undefined or unknown old forward image cannot establish an immutable baseline.
  const base=nested(original,raw.baseline,s);
  if(base.status!=='PASS'||!base.witness)fail('The baseline needs complete original forward materialization','missing-evidence');
  const def=original.definition,id=name(raw.id,s),revision=natural(raw.revision),baseline=base.witness;
  const sourceIds=new Set(def.source.events.map(e=>e.id)),variableIds=new Set(def.source.variables.map(v=>v.id));
  s.charge(sourceIds.size+variableIds.size);
  const editable=new Set(uniqueNames(raw.editableVariables,variableIds,16,s,'editable variable')),
    protectedSourceIds=uniqueNames(raw.protectedSourceIds,sourceIds,128,s,'protected source');
  for(const e of def.source.events){s.charge();if(protectedSourceIds.includes(e.id)&&e.pitch?.variableId)editable.delete(e.pitch.variableId)}
  const axes=[],axisIds=new Set;
  for(const value of list(raw.axes,s.limits.maxAxes,s,'Objective axes')){
    fields(value,['id','sourceChangeCost','occurrenceChangeCost'],s);const id=name(value.id,s);
    if(axisIds.has(id))fail('Repeated objective axis');axisIds.add(id);
    axes.push(freeze({id,sourceChangeCost:nonnegative(value.sourceChangeCost,s),occurrenceChangeCost:nonnegative(value.occurrenceChangeCost,s)}));
  }if(!axes.length)fail('Declare at least one lexicographic objective axis');freeze(axes);
  list(raw.variableCosts,16,s,'Variable costs');if(raw.variableCosts.length!==def.source.variables.length)fail('Supply costs for every variable');
  const costs=new Map;
  for(const item of raw.variableCosts){
    fields(item,['variableId','candidates'],s);const id=name(item.variableId,s),v=def.source.variables.find(v=>v.id===id);s.charge(def.source.variables.length);
    if(!v||costs.has(id))fail('Unknown or repeated cost variable');const values=new Map;
    list(item.candidates,16,s,'Candidate costs');if(item.candidates.length!==v.values.length)fail('Supply every original candidate cost');
    for(const row of item.candidates){
      fields(row,['candidateId','costs'],s);const value=name(row.candidateId,s);s.charge(v.values.length);
      if(!v.values.some(x=>x.id===value)||values.has(value))fail('Unknown or repeated cost candidate');
      list(row.costs,axes.length,s,'Cost vector');if(row.costs.length!==axes.length)fail('Cost vector width');
      values.set(value,freeze(row.costs.map(x=>nonnegative(x,s))));
    }costs.set(id,values);
  }
  const baseChoice=new Map(baseline.assignment.map(x=>[x.variableId,x.candidateId]));
  const variables=def.source.variables.map(v=>{
    s.charge(v.values.length);const values=v.values.map(x=>freeze({...x,costs:costs.get(v.id).get(x.id),pitchKey:key(x.pitch,s)}));
    return freeze({id:v.id,complete:v.complete,values:freeze(values),editable:editable.has(v.id),baseline:baseChoice.get(v.id)});
  });freeze(variables);
  const variableById=new Map(variables.map(v=>[v.id,v])),committedUntil=nonnegative(raw.committedUntil,s),protectedEvents=new Set;
  const sources=new Map(def.source.events.map(x=>[x.id,x])),entries=new Map(def.entries.map(x=>[x.id,x])),maps=new Map(def.maps.map(x=>[x.id,x]));
  const occurrences=[],byRef=new Map;
  for(const event of baseline.events){
    s.charge();if(compare(exactOf(event.t,{bits:8192}),committedUntil)<0)protectedEvents.add(event.id);
    if(event.origin.kind!=='mapped')continue;
    const {entryId,sourceId}=event.origin,source=sources.get(sourceId),entry=entries.get(entryId),dependencies=new Set;
    if(source.pitch!==null){if(source.pitch.variableId)dependencies.add(source.pitch.variableId);for(const id of maps.get(entry.mapId).dependencies){s.charge();dependencies.add(id)}}
    const ref=freeze({entryId,sourceId,eventId:event.id}),item=freeze({ref,dependencies:freeze([...dependencies])});
    byRef.set(key([entryId,sourceId],s),item);occurrences.push(item);
  }
  const protectedOccurrences=[],seenRefs=new Set;
  for(const value of list(raw.protectedOccurrences,2048,s,'Protected occurrences')){
    fields(value,['entryId','sourceId'],s);const entryId=name(value.entryId,s),sourceId=name(value.sourceId,s),k=key([entryId,sourceId],s);
    if(!byRef.has(k)||seenRefs.has(k))fail('Unknown or repeated protected occurrence');seenRefs.add(k);
    protectedEvents.add(byRef.get(k).ref.eventId);protectedOccurrences.push(freeze({entryId,sourceId}));
  }
  const domains=variables.map(v=>v.editable?v.values:v.values.filter(x=>x.id===v.baseline));
  let cardinality=1n;for(const domain of domains){s.charge();cardinality*=BigInt(domain.length)}
  const searchDomain=variables.map((v,i)=>freeze({variableId:v.id,complete:!v.editable||v.complete,candidateIds:freeze(domains[i].map(x=>x.id))}));
  const definition=freezeDeep({kind:'protected-repair-v1',id,revision,pullbackHash:base.modelHash,baseline:baseline.assignment,baselineEventHash:baseline.eventHash,
    editableVariables:[...editable],protectedSourceIds,protectedOccurrences,committedUntil:exactText(committedUntil),
    axes:axes.map(a=>({id:a.id,sourceChangeCost:exactText(a.sourceChangeCost),occurrenceChangeCost:exactText(a.occurrenceChangeCost)})),
    variableCosts:variables.map(v=>({variableId:v.id,candidates:v.values.map(x=>({candidateId:x.id,costs:x.costs.map(exactText)}))})),
    searchDomain,cardinality:String(cardinality),profile:def.profile,environmentId:def.environment.id,environmentRevision:def.environment.revision,targetClock:def.targetClock});
  s.modelHash=hash(definition,s);
  return {definition,original,baseline,variables,variableById,axes,protectedEvents,occurrences,domains,cardinality,
    complete:searchDomain.every(x=>x.complete),baselineById:new Map(baseline.events.map(e=>[e.id,e]))};
}
function modelOf(prepared,s){const m=models.get(prepared);if(!m)fail('Use an authentic prepared repair model','out-of-model');
  s.modelHash=prepared.modelHash;if(m.axes.length>s.limits.maxAxes)fail('Prepared objective-axis allowance','shape-budget');return m}

/** Preparation binds the original forward model and immutable old material; it grants no musical admission. */
export function prepareProtectedRepair(original,policy,options={}){
  return run(options,s=>{const model=normalize(original,policy,s),prepared=freeze({kind:'prepared-protected-repair-v1',modelHash:s.modelHash,definition:model.definition});
    models.set(prepared,model);return result(s,'PASS','Original finite repair scope prepared',{prepared})});
}
function evaluate(model,assignment,s){
  const chosen=new Map,changedVariables=[];
  for(let i=0;i<model.variables.length;i++){
    s.charge();const v=model.variables[i],id=assignment[i].candidateId,x=v.values.find(x=>x.id===id);
    if(!v.editable&&id!==v.baseline)return {status:'FAIL',category:'protection'};
    chosen.set(v.id,x);if(id!==v.baseline)changedVariables.push(v.id);
  }
  const original=changedVariables.length?nested(model.original,assignment,s):{status:'PASS',witness:model.baseline};
  if(original.status!=='PASS')return {status:original.status,category:'forward'};
  const witness=original.witness,changedOccurrences=[],affectedOccurrences=[],changedSourceIds=[],changedSet=new Set(changedVariables),newById=new Map;
  for(const event of witness.events){
    s.charge();newById.set(event.id,event);const old=model.baselineById.get(event.id);
    if(key(event,s)!==key(old,s)&&model.protectedEvents.has(event.id))return {status:'FAIL',category:'protection'};
  }
  for(const source of model.original.definition.source.events){
    s.charge();if(!source.pitch?.variableId)continue;const v=model.variableById.get(source.pitch.variableId),x=chosen.get(v.id),old=v.values.find(x=>x.id===v.baseline);
    if(x.pitchKey!==old.pitchKey)changedSourceIds.push(source.id);
  }
  for(const {ref,dependencies} of model.occurrences){
    s.charge(dependencies.length+1);if(dependencies.some(id=>changedSet.has(id)))affectedOccurrences.push(ref);
    if(key(newById.get(ref.eventId),s)!==key(model.baselineById.get(ref.eventId),s))changedOccurrences.push(ref);
  }
  const audited=nested(model.original,null,s,witness);
  if(audited.status!=='PASS')return {status:audited.status,category:'profile'};
  const cost=[];for(let k=0;k<model.axes.length;k++){
    s.charge(3);const a=model.axes[k];let value=add(mul(a.sourceChangeCost,exactOf(changedSourceIds.length)),mul(a.occurrenceChangeCost,exactOf(changedOccurrences.length)));
    for(const v of model.variables){s.charge();value=add(value,chosen.get(v.id).costs[k])}cost.push(value);
  }
  const def=model.original.definition;
  const report=freezeDeep({scope,modelHash:s.modelHash,pullbackHash:witness.modelHash,baselineEventHash:model.baseline.eventHash,
    assignment,witness,changedVariables,changedSourceIds,affectedOccurrences,changedOccurrences,
    cost:cost.map((x,i)=>({axis:model.axes[i].id,value:exactText(x)})),
    evidence:{status:'PASS',scope:audited.scope,profileHash:audited.audit.profileHash,environmentId:def.environment.id,
      environmentRevision:def.environment.revision,dependencies:def.environment.dependencies,targetClock:def.targetClock}});
  hash(report,s);return {status:'PASS',report,cost};
}
function better(a,b,s){for(let i=0;i<a.length;i++){s.charge();const c=compare(a[i],b[i]);if(c)return c<0}return false}
function certificate(model,conclusion,best,s){return freeze({kind:'protected-repair-certificate-v1',modelHash:s.modelHash,conclusion,
  assignment:best?.report.assignment??null,reportHash:best?hash(best.report,s):null})}
function admitEnumeration(model,s){if(model.cardinality>BigInt(s.limits.maxAssignments))fail('Complete repair-domain enumeration exceeds the assignment allowance','work-budget')}
function searchState(){return {assignments:0,unknownAssignments:0,excluded:{protection:0,forward:0,profile:0},feasible:0,exhausted:false}}
function tally(stats,out,s){s.charge();stats.assignments++;if(out.status==='PASS')stats.feasible++;
  else if(out.status==='FAIL')stats.excluded[out.category]++;else stats.unknownAssignments++}

/** This audits one candidate; PASS does not say minimum. No finite-domain completeness premise is needed. */
export function auditProtectedRepair(prepared,rawAssignment,options={}){
  return run(options,s=>{const model=modelOf(prepared,s),assignment=assignmentOf(rawAssignment,model.variables,s),out=evaluate(model,assignment,s);
    return result(s,out.status,'Original propagation, protection and mandatory whole profile audited',
      {report:out.report??null,certificate:out.status==='PASS'?certificate(model,'SAT',out,s):null,category:out.category??null})});
}
/** Exhaustive finite reference optimization. Ties keep the first original catalogue tuple; no random draw. */
export function solveProtectedRepair(prepared,options={}){
  return run(options,s=>{const model=modelOf(prepared,s);admitEnumeration(model,s);const stats=searchState(),tuple=[];let best=null;
    function visit(depth){
      s.charge();if(depth===model.variables.length){const assignment=freeze(tuple.map(x=>freeze({...x}))),out=evaluate(model,assignment,s);tally(stats,out,s);
        if(out.status==='PASS'&&(!best||better(out.cost,best.cost,s)))best=out;return}
      const variable=model.variables[depth];for(const x of model.domains[depth]){s.charge();tuple[depth]={variableId:variable.id,candidateId:x.id};visit(depth+1)}
    }visit(0);stats.exhausted=true;
    const conclusive=model.complete&&!stats.unknownAssignments,status=best?(conclusive?'OPTIMAL':'SAT'):conclusive?'UNSAT':'UNKNOWN';
    return result(s,status,best?conclusive?'Exact lexicographic minimum in the complete declared finite edit scope':'Audited repair; incomplete inventory or unresolved assignments prevent a minimum claim':
      conclusive?'Every permitted assignment in the complete finite edit scope is decisively excluded':'Incomplete inventory or unresolved assignments prevent a failure claim',
      {report:best?.report??null,certificate:status==='UNKNOWN'?null:certificate(model,status,best,s),domain:model.definition.searchDomain,
        domainCardinality:String(model.cardinality),domainComplete:model.complete,search:freezeDeep(stats)});
  });
}
/** Reconstruct the original winner and, for minimum/failure, enumerate the original product with an odometer.
 * No supplied changed set, cost, audit, visited count or solver search tree is trusted. */
export function checkProtectedRepair(prepared,raw,options={}){
  return run(options,s=>{const model=modelOf(prepared,s);fields(raw,['kind','modelHash','conclusion','assignment','reportHash'],s);
    certify(raw.kind==='protected-repair-certificate-v1'&&raw.modelHash===s.modelHash,'Certificate identity or original model differs');
    certify(['SAT','OPTIMAL','UNSAT'].includes(raw.conclusion),'Unknown repair conclusion');let claimed=null;
    if(raw.conclusion==='UNSAT')certify(raw.assignment===null&&raw.reportHash===null,'UNSAT cannot carry a selected repair');
    else{
      name(raw.reportHash,s,64);certify(/^[0-9a-f]{64}$/.test(raw.reportHash)&&raw.reportHash.length===64,'Malformed repair report hash');
      const assignment=assignmentOf(raw.assignment,model.variables,s);claimed=evaluate(model,assignment,s);
      if(claimed.status==='UNKNOWN')fail('Selected repair lacks decisive original evidence','missing-evidence');
      certify(claimed.status==='PASS','Selected repair violates the original graph, protection or whole profile');
      certify(hash(claimed.report,s)===raw.reportHash,'Recomputed propagated changes, cost or evidence differ');
      if(raw.conclusion==='SAT')return result(s,'PASS','Selected repair independently replayed and audited; no minimum claim',{conclusion:'SAT',report:claimed.report});
    }
    certify(model.complete,'An incomplete editable inventory cannot prove minimum or failure');admitEnumeration(model,s);
    const stats=searchState(),digits=Array(model.variables.length).fill(0),claimedKey=claimed?key(claimed.report.assignment,s):null;let done=false;
    // A prepared baseline supplies at least one value of every variable, including locked ones.
    while(!done){
      s.charge();const assignment=freeze(model.variables.map((v,i)=>freeze({variableId:v.id,candidateId:model.domains[i][digits[i]].id})));
      const out=claimedKey!==null&&key(assignment,s)===claimedKey?claimed:evaluate(model,assignment,s);tally(stats,out,s);
      if(out.status==='PASS'){
        certify(raw.conclusion!=='UNSAT','A feasible original assignment refutes finite-domain UNSAT');
        certify(!better(out.cost,claimed.cost,s),'A strictly cheaper original assignment refutes optimality');
      }
      let pos=digits.length-1;for(;pos>=0;pos--){s.charge();if(++digits[pos]<model.domains[pos].length)break;digits[pos]=0}done=pos<0;
    }
    stats.exhausted=true;if(stats.unknownAssignments)fail('Unresolved original assignments prevent exhaustive certification','missing-evidence');
    return result(s,'PASS','Original finite domain independently enumerated and every assignment decisively resolved',
      {conclusion:raw.conclusion,report:claimed?.report??null,domain:model.definition.searchDomain,domainCardinality:String(model.cardinality),search:freezeDeep(stats)});
  });
}
