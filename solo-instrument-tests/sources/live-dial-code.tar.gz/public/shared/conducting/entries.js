// A line shared by several sections as a canon of its entries (the owner, 2 October 2026: "is it possible to think of
// planing as itself a special case of canon (zero-delay canon ...) with entries at a variety of intervals?"; "octaves
// are still intervals, so playing a doubling at the octave is almost like a special case of planing"). Each section an
// entry: its delay (`felt`, the bar's felt beats after the line, which its voice counts in its meter) and its pitch map -- the canon's transformation (conducting/
// canon-core.js transformPhrase: a delay and a pitch map), so that
//   a doubling   is an entry at no delay and whole octaves (the basses an octave below the cellos, as orchestras double:
//                folded note by note into their compass alone, the basses had played the cellos' line at its pitch, the
//                owner's "extremely high parts written for contrabass");
//   planing      an entry at no delay and another interval: real (`semitones`, any, the line moved in parallel exactly)
//                or tonal (`steps` in the harmony sounding, every note moved that many of its tones, then `octaves`);
//   a canon      an entry with a delay;
// and every state between is one (a delay from none to a bar or more, an interval anywhere): which a pool takes is its
// own draw, as often as its shares `planing` (a section entering at an interval not an octave) and `canon` (at a delay).
// Each entry's octaves are the ones that put its line, at its interval, best in its own section's register: every
// candidate counted exactly (the line's band against the register, then its distance from the register's middle).
// (Its joint choice under the harmony's and the counterpoint's contract -- which interval each entry may take against
// the others, slice by slice -- is posted to Astra as an exact problem: SESSIONS.md, 2 October 2026.)
//
// Ours: the candidates' ranges.
import {chooseEntries,realEntryMap,tonalEntryMap} from './choose-entries.js';
import {createPitchSpace,pitchFromNumber} from './pitch-spaces.js';
import {Q} from './canon-core.js';
import {exactOfNumber} from '../bounded-exact.js';
export const ENTRIES=Object.freeze({
  // The octaves an entry may be moved by, either way; a tonal interval's steps (in a collection's tones, an octave its
  // size); a real interval's semitones (any between: drawn continuously).
  octaves:3,steps:Object.freeze([1,6]),semitones:Object.freeze([1,11]),
  // The share of planed entries that are tonal (in the harmony's tones) rather than real.
  tonal:.7,
  // A canon's delay, in the bar's felt beats (its voice's meter's): from one to `delays` of them.
  delays:2,
});
// A band of pitches [low, high] against a register [low, high]: how far outside it the band lies (semitones), then how
// far its middle is from the register's.
const misfit=([low,high],[a,b])=>[Math.max(0,a-low)+Math.max(0,high-b),Math.abs((low+high)/2-(a+b)/2)];
// The entries of a line among its sections: `sections` [{id, register: [low, high]}], `band` the line's [low, high],
// `planing` and `canon` its shares, `random` [0, 1). The section whose register's middle is nearest the band's leads (no
// delay, its own pitch); each other's interval drawn, its octaves fitted. -> {sectionId: {felt, semitones} | {felt,
// steps, octaves}}.
export function lineEntries({sections,band,planing=0,canon=0,random=Math.random}){
  if(!Array.isArray(sections)||sections.length<2)return null;
  const middle=(band[0]+band[1])/2,lead=sections.reduce((best,s)=>Math.abs((s.register[0]+s.register[1])/2-middle)<Math.abs((best.register[0]+best.register[1])/2-middle)?s:best,sections[0]);
  const out={};
  for(const section of sections){
    if(section===lead){out[section.id]=Object.freeze({felt:0,semitones:0});continue}
    // (Its interval: an octave's multiple, or as often as `planing` another, tonal as often as ENTRIES.tonal, else real.)
    const planed=random()<planing,tonal=random()<ENTRIES.tonal,[fewest,most]=ENTRIES.steps,[lowest,highest]=ENTRIES.semitones;
    const steps=planed&&tonal?fewest+Math.floor(random()*(most-fewest+1)):0,interval=planed&&!tonal?+(lowest+(highest-lowest)*random()).toFixed(3):0;
    // (A tonal interval's size, for its fit: a step about a seventh of an octave, as a collection's tones space it.)
    const size=steps?steps*12/7:interval;
    let best=null;
    for(let k=-ENTRIES.octaves;k<=ENTRIES.octaves;k++){
      const shift=size+12*k,[outside,distance]=misfit([band[0]+shift,band[1]+shift],section.register);
      if(!best||outside<best.outside-1e-9||Math.abs(outside-best.outside)<=1e-9&&(distance<best.distance-1e-9||Math.abs(distance-best.distance)<=1e-9&&Math.abs(k)<Math.abs(best.k)))best={k,outside,distance};
    }
    // (Its delay: none, or as often as `canon` one or more of the bar's felt beats.)
    const felt=random()<canon?1+Math.floor(random()*ENTRIES.delays):0;
    out[section.id]=Object.freeze(steps?{felt,steps,octaves:best.k}:{felt,semitones:+(interval+12*best.k).toFixed(3)});
  }
  return Object.freeze(out);
}
// A pitch of the line at an entry's interval: real, moved by its semitones; tonal, that many tones of `ladder` (the
// harmony sounding, in every octave, low to high) from the nearest, then its octaves.
// An entry's delay in notated beats, in `groups` (its meter's felt beats, in notated beats): its felt beats counted from
// the bar's start, whole bars past its last.
export function entryDelay(entry,groups=[1]){
  const felt=Math.max(0,Math.round(Number(entry?.felt)||0)),bar=groups.reduce((a,b)=>a+b,0);
  return Math.floor(felt/groups.length)*bar+groups.slice(0,felt%groups.length).reduce((a,b)=>a+b,0);
}
export function entryPitch(pitch,entry,ladder=[]){
  if(!entry)return pitch;
  if(!entry.steps)return pitch+(Number(entry.semitones)||0);
  if(!ladder.length)return pitch+12*(Number(entry.octaves)||0);
  const index=ladder.reduce((best,p,k)=>Math.abs(p-pitch)<Math.abs(ladder[best]-pitch)?k:best,0);
  return ladder[Math.max(0,Math.min(ladder.length-1,index+entry.steps))]+12*(Number(entry.octaves)||0);
}

// The entries of a line once the line is planned (Astra's CFM-004, choose-entries.js: the joint choice posted to Astra on
// 2 October): each section's octave chosen together with every other's, so that every note of its line -- as planned,
// at its delay and its interval -- lies in its section's register, the whole line moved as one (never note by note).
// Each section keeps its drawn interval and delay (lineEntries'); its drawn octave costs nothing, each octave away from
// it one -- every octave its interval may take (ENTRIES.octaves either way). `line` [{at (s from `start`), pitch,
// seconds}]; `entries` {section: entry} (lineEntries'); `registers` {section: [low, high]}; `delays` {section: s};
// `pool` the harmony's pitches it was planned in (a tonal interval's degrees). -> {status ('SAT', 'UNSAT' or
// 'UNKNOWN'), entries ({section: entry}, its octaves chosen, where SAT), optimal, reason}.
const SPACE=createPitchSpace({id:'musebots-semitones',kind:'semitones'});
const exactText=value=>Q(exactOfNumber(+Number(value).toFixed(6))).toString();
const pitchOf=value=>pitchFromNumber(SPACE,+Number(value).toFixed(6)).pitch;
export function jointEntries({line,entries,registers,delays,pool,length,maxNodes=null}){
  const ids=Object.keys(entries??{});
  if(ids.length<2||!line?.length)return {status:'UNKNOWN',reason:'no shared line'};
  const classes=[...new Set((pool??[]).map(Number).filter(Number.isFinite).map(p=>+(((p%12)+12)%12).toFixed(6)))].sort((a,b)=>a-b);
  const octaveOf=entry=>entry.steps?Number(entry.octaves)||0:Math.round((Number(entry.semitones)||0)/12);
  const mapOf=(id,entry,k)=>entry.steps?tonalEntryMap({id:`${id}:${k}`,pitchSpace:SPACE,steps:entry.steps,periods:k,contextKey:'collection'})
    :realEntryMap({id:`${id}:${k}`,pitchSpace:SPACE,amount:exactText((Number(entry.semitones)||0)+12*(k-octaveOf(entry))),unit:'semitones'});
  const end=Math.max(length,...line.map(note=>note.at+note.seconds),...ids.map(id=>(Number(delays[id])||0)+Math.max(...line.map(note=>note.at+note.seconds))));
  let result;
  try{
    result=chooseEntries({id:'shared-line-entries',revision:1,pitchSpace:SPACE,clockDomain:{id:'phrase-seconds',unit:'s',revision:1},length:exactText(end),
      line:line.map((note,k)=>({id:`n${k}`,t:exactText(note.at),d:exactText(note.seconds),pitch:pitchOf(note.pitch)})),
      sections:ids.map(id=>{const entry=entries[id],own=octaveOf(entry),[low,high]=registers[id];
        return {id,register:{low:pitchOf(low),high:pitchOf(high)},delays:[{id:'drawn',at:exactText(Number(delays[id])||0),cost:0}],
          maps:Array.from({length:2*ENTRIES.octaves+1},(_,j)=>j-ENTRIES.octaves).map(k=>({map:mapOf(id,entry,k),cost:Math.abs(k-own)}))}}),
      harmony:{id:'planned-harmony',revision:1,membership:'profile-only',periodCents:null,spans:[{from:0,to:exactText(end),pitches:null,
        context:{collection:{id:'pool',revision:1,origin:'0',period:'12',steps:classes.map(exactText)}}}]},
      profile:{id:'entries',version:1,rules:[{id:'monophony',type:'monophony',required:true}]},weights:{delay:1,map:1},domainComplete:true,
      joint:{id:'register-and-profile',version:1,check:()=>'PASS'}},maxNodes?{maxNodes}:{});
  }catch(error){return {status:'UNKNOWN',reason:String(error?.message??error)}}
  if(result.status!=='SAT')return {status:result.status,reason:result.reason??null};
  const chosen=Object.fromEntries(result.choices.map(choice=>[choice.sectionId??choice.id,Number(String(choice.mapId).split(':').at(-1))]));
  return {status:'SAT',optimal:Boolean(result.optimal),entries:Object.fromEntries(ids.map(id=>{const entry=entries[id],k=chosen[id];
    return [id,Object.freeze(entry.steps?{...entry,octaves:k}:{...entry,semitones:+((Number(entry.semitones)||0)+12*(k-octaveOf(entry))).toFixed(3)})]}))};
}
