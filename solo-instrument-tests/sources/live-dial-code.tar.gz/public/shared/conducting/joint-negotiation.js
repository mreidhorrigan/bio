// CFM033 / EC18: one serial authority, exact reservations and immutable complete joint proposals.
// A bounded reference, not a transport, durable consensus service or exactly-once audio executor.
import {dataArray,dataRecord} from './contract-data.js';
import {Refused,EXACT_LIMITS,ZERO,add,sub,compare,exactOf,exactText,pythonJson,sha256} from '../bounded-exact.js';

export const JOINT_NEGOTIATION_LIMITS=Object.freeze({maxParticipants:64,maxBudgets:32,maxContracts:32,
  maxPlans:128,maxMessages:1024,maxWork:2000000,maxDataNodes:65536,maxTextChars:4194304});
const freeze=Object.freeze,ledgers=new WeakMap,scope='single-authority-joint-reservation-and-commit';
const fail=(message,kind='invalid-input')=>{throw new Refused(message,{kind})};
class Rejected extends Error {}
const requireThat=(condition,message)=>{if(!condition)throw new Rejected(message)};
function stateOf(options){
  if(!dataRecord(options)||Object.keys(options).some(k=>!Object.hasOwn(JOINT_NEGOTIATION_LIMITS,k)))fail('Unknown negotiation options');
  const limits={};for(const [key,cap] of Object.entries(JOINT_NEGOTIATION_LIMITS)){
    const n=Object.hasOwn(options,key)?options[key]:cap;
    if(!Number.isSafeInteger(n)||n<0||n>cap)fail('Bounded nonnegative integer allowances required');limits[key]=n;
  }
  const s={limits:freeze(limits),used:0,nodes:0,chars:0,modelHash:null};
  s.charge=(n=1)=>{if(!Number.isSafeInteger(n)||n<0)throw new Error('Invalid work charge');
    if(n>limits.maxWork-s.used)fail('Negotiation work allowance exhausted','work-budget');s.used+=n};
  s.m={};for(const [k,fn] of Object.entries({add,sub,cmp:compare}))s.m[k]=(a,b)=>{s.charge();return fn(a,b)};
  s.charge();return s;
}
function fields(v,keys,s){s.charge();if(!dataRecord(v)||Object.keys(v).length!==keys.length||keys.some(k=>!Object.hasOwn(v,k)))fail('Missing or unsupported negotiation fields');s.charge(keys.length);return v}
function list(v,cap,s,label){if(!Array.isArray(v)||v.length>cap)fail(label+' allowance','shape-budget');s.charge(v.length+1);return dataArray(v,cap,label)}
function text(v,s,cap=256){if(typeof v!=='string'||!v.length||v.length>cap)fail('Bounded nonempty text required');
  if(v.length>s.limits.maxTextChars-s.chars)fail('Negotiation text allowance','work-budget');s.chars+=v.length;s.charge(1+Math.ceil(v.length/64));return v}
function revision(v){if(!Number.isSafeInteger(v)||v<0)fail('Nonnegative safe revision required');return v}
function unique(seen,id){if(seen.has(id))fail('Duplicate negotiation identity');seen.add(id);return id}
function digest(v,s){text(v,s,64);if(!/^[0-9a-f]{64}$/.test(v))fail('Lowercase SHA-256 reference required');return v}
function rational(v,s){
  s.charge();let n,d=1n;const bound=1n<<BigInt(EXACT_LIMITS.inputBits);
  const integer=x=>{const q=typeof x==='bigint'?x:Number.isSafeInteger(x)?BigInt(x):null;
    if(q===null||q<=-bound||q>=bound)fail('Raw rational component allowance','arithmetic-budget');return q};
  if(typeof v==='string'){text(v,s,160);const m=v.match(/^([+-]?[0-9]+)(?:\/([+-]?[0-9]+))?$/);
    if(!m||m[0].length!==v.length)fail('Use exact integer or fraction text');n=integer(BigInt(m[1]));d=integer(BigInt(m[2]??'1'));
  }else if(v&&typeof v==='object'){fields(v,['n','d'],s);n=integer(v.n);d=integer(v.d)}else n=integer(v);
  if(!d)fail('Zero denominator');const q=exactOf({n,d});if(q.n<0n)fail('Nonnegative time or allowance required');return q;
}
function actor(v,s){fields(v,['id','incarnation'],s);return freeze({id:text(v.id,s),incarnation:text(v.incarnation,s)})}
const sameActor=(a,b)=>a.id===b.id&&a.incarnation===b.incarnation;
function reference(v,s){fields(v,['id','revision','hash'],s);return freeze({id:text(v.id,s),revision:revision(v.revision),hash:digest(v.hash,s)})}
function clock(v,s){fields(v,['id','unit','revision'],s);return freeze({id:text(v.id,s),unit:text(v.unit,s),revision:revision(v.revision)})}
const sameClock=(a,b)=>a.id===b.id&&a.unit===b.unit&&a.revision===b.revision;
function base(v,s){
  fields(v,['authority','clock','parent','prefixHash','bindingsHash'],s);fields(v.authority,['id','incarnation','epoch'],s);
  return freeze({authority:freeze({id:text(v.authority.id,s),incarnation:text(v.authority.incarnation,s),epoch:revision(v.authority.epoch)}),
    clock:clock(v.clock,s),parent:reference(v.parent,s),prefixHash:digest(v.prefixHash,s),bindingsHash:digest(v.bindingsHash,s)});
}
function metadata(v,s,depth=0,seen=new Set){
  s.charge();if(++s.nodes>s.limits.maxDataNodes)fail('Negotiation data-node allowance','shape-budget');
  if(v===null||typeof v==='boolean')return v;
  if(typeof v==='number'){if(!Number.isFinite(v))fail('Nonfinite content');return Object.is(v,-0)?0:v}
  if(typeof v==='string')return v.length?text(v,s,2048):v;
  if(depth>=12||seen.has(v))fail('Cyclic or deep negotiation content');seen.add(v);let out;
  if(Array.isArray(v)){list(v,s.limits.maxDataNodes,s,'Content');out=[];for(const x of v)out.push(metadata(x,s,depth+1,seen))}
  else{if(!dataRecord(v)||Object.keys(v).length>256)fail('Ordinary bounded content required');out={};
    for(const key of Object.keys(v)){text(key,s);Object.defineProperty(out,key,{value:metadata(v[key],s,depth+1,seen),enumerable:true})}}
  seen.delete(v);return freeze(out);
}
function wire(v,s){
  s.charge();if(++s.nodes>s.limits.maxDataNodes)fail('Negotiation output-node allowance','shape-budget');
  if(typeof v==='string')return v.length?text(v,s,6000):v;
  if(v&&typeof v==='object'){
    if(typeof v.n==='bigint'&&typeof v.d==='bigint')return text(exactText(v),s,6000);
    if(Array.isArray(v))return freeze(v.map(x=>wire(x,s)));
    return freeze(Object.fromEntries(Object.entries(v).map(([key,value])=>[text(key,s),wire(value,s)])));
  }return v;
}
function encode(v,s){const value=pythonJson(v);if(value.length>s.limits.maxTextChars)fail('Canonical negotiation text allowance','work-budget');s.charge(1+Math.ceil(value.length/64));return value}
function normalizedSpec(raw,s){
  fields(raw,['id','revision','complete','at','base','participants','budgets','requiredContracts'],s);
  if(raw.complete!==true)fail('Complete original ledger history and participant/contract inventories required','unknown-evidence');
  const participants=[],budgets=[],requiredContracts=[],seen=new Set;
  for(const p of list(raw.participants,s.limits.maxParticipants,s,'Participants')){const a=actor(p,s);unique(seen,a.id);participants.push(a)}
  if(!participants.length)fail('A nonempty required participant inventory is necessary');seen.clear();
  for(const b of list(raw.budgets,s.limits.maxBudgets,s,'Budgets')){
    fields(b,['id','unit','capacity','spent','history'],s);const capacity=rational(b.capacity,s),spent=rational(b.spent,s);
    if(s.m.cmp(spent,capacity)>0)fail('Initial historical spend exceeds capacity');
    budgets.push(freeze({id:unique(seen,text(b.id,s)),unit:text(b.unit,s),capacity,spent,history:reference(b.history,s)}));
  }if(!budgets.length)fail('An explicit nonempty budget inventory is required');seen.clear();
  for(const c of list(raw.requiredContracts,s.limits.maxContracts,s,'Required contracts')){fields(c,['id','revision'],s);
    requiredContracts.push(freeze({id:unique(seen,text(c.id,s)),revision:revision(c.revision)}));}
  if(!requiredContracts.length)fail('An independent nonempty required-contract inventory is necessary');
  return freeze({kind:'joint-negotiation-v1',id:text(raw.id,s),revision:revision(raw.revision),complete:true,at:rational(raw.at,s),base:base(raw.base,s),
    participants:freeze(participants),budgets:freeze(budgets),requiredContracts:freeze(requiredContracts)});
}
function charges(raw,cfg,s){
  const values=new Map;for(const r of list(raw,s.limits.maxBudgets,s,'Budget charges')){fields(r,['budgetId','amount'],s);
    const id=text(r.budgetId,s);if(values.has(id))fail('Duplicate budget charge');values.set(id,rational(r.amount,s));}
  if(values.size!==cfg.budgets.length||cfg.budgets.some(b=>!values.has(b.id)))fail('Every budget must have one explicit charge, including zero');
  return freeze(cfg.budgets.map(b=>freeze({budgetId:b.id,amount:values.get(b.id)})));
}
function proposal(raw,cfg,s){
  fields(raw,['id','revision','base','members','commitBy','effectiveAt','validThrough','charges','content'],s);
  const b=base(raw.base,s),version=revision(raw.revision),commitBy=rational(raw.commitBy,s),effectiveAt=rational(raw.effectiveAt,s),validThrough=rational(raw.validThrough,s);
  if(version!==b.parent.revision+1||!Number.isSafeInteger(b.parent.revision+1))fail('Proposal must name the next parent revision');
  if(s.m.cmp(commitBy,effectiveAt)>0||s.m.cmp(effectiveAt,validThrough)>0)fail('Ordered commit, effective and final validity times required');
  const members=[],ids=new Set;
  for(const m of list(raw.members,s.limits.maxParticipants,s,'Proposal members')){
    fields(m,['id','incarnation','firstActionAt'],s);const a=freeze({id:unique(ids,text(m.id,s)),incarnation:text(m.incarnation,s)}),firstActionAt=rational(m.firstActionAt,s);
    if(!cfg.participants.some(p=>sameActor(p,a))||s.m.cmp(firstActionAt,commitBy)<0||s.m.cmp(firstActionAt,validThrough)>0)fail('Required member and timely first action needed');
    members.push(freeze({...a,firstActionAt}));
  }
  if(members.length!==cfg.participants.length)fail('Complete independent participant inventory required');
  if(!dataRecord(raw.content))fail('Complete joint content must be a record');
  return freeze({ledgerHash:cfg.hash,id:text(raw.id,s),revision:version,base:b,members:freeze(members),commitBy,effectiveAt,validThrough,
    charges:charges(raw.charges,cfg,s),requiredContracts:cfg.requiredContracts,content:metadata(raw.content,s)});
}
function command(raw,cfg,s){
  if(!dataRecord(raw))fail('Ordinary command required');const types={reserve:['proposal'],accept:['planId','planHash','preparedAt','validThrough','preparation'],
    commit:['planId','planHash'],abort:['planId','planHash'],advance:[],reconcile:['planId','planHash','complete','actual','outcome','report'],rebase:['base']};
  if(typeof raw.type!=='string'||!Object.hasOwn(types,raw.type))fail('Unknown negotiation command');
  fields(raw,['messageId','type',...types[raw.type]],s);const out={messageId:text(raw.messageId,s),type:raw.type};
  if(raw.type==='reserve')out.proposal=proposal(raw.proposal,cfg,s);
  if(['accept','commit','abort','reconcile'].includes(raw.type)){out.planId=text(raw.planId,s);out.planHash=digest(raw.planHash,s)}
  if(raw.type==='accept'){out.preparedAt=rational(raw.preparedAt,s);out.validThrough=rational(raw.validThrough,s);out.preparation=reference(raw.preparation,s)}
  if(raw.type==='reconcile'){
    if(raw.complete!==true)fail('Complete actual-use evidence required; unknown is not zero','unknown-evidence');
    if(!['executed','cancelled','failed'].includes(raw.outcome))fail('Explicit actual outcome required');
    Object.assign(out,{complete:true,actual:charges(raw.actual,cfg,s),outcome:raw.outcome,report:reference(raw.report,s)});
  }
  if(raw.type==='rebase')out.base=base(raw.base,s);return freeze(out);
}
function envelope(raw,s){fields(raw,['origin','epoch','clock','now'],s);return freeze({origin:actor(raw.origin,s),epoch:revision(raw.epoch),clock:clock(raw.clock,s),now:rational(raw.now,s)})}
function ledgerOf(ledger,s){
  const l=ledgers.get(ledger);if(!l)fail('Use an authentic joint-negotiation ledger','out-of-model');s.modelHash=l.cfg.hash;
  if(l.cfg.participants.length>s.limits.maxParticipants||l.cfg.budgets.length>s.limits.maxBudgets||l.cfg.requiredContracts.length>s.limits.maxContracts||
    l.state.plans.size>s.limits.maxPlans||l.state.messages.size>s.limits.maxMessages||l.state.journalChars>s.limits.maxTextChars)fail('Existing ledger exceeds requested allowances','shape-budget');
  return l;
}
function accounting(cfg,st,s){
  const spent=cfg.budgets.map(b=>b.spent),reserved=cfg.budgets.map(()=>ZERO);
  for(const p of st.plans.values()){s.charge();if(p.state==='reconciled')for(let i=0;i<spent.length;i++)spent[i]=s.m.add(spent[i],p.actual[i].amount);
    if(p.state==='pending'||p.state==='committed')for(let i=0;i<reserved.length;i++)reserved[i]=s.m.add(reserved[i],p.proposal.charges[i].amount);}
  return cfg.budgets.map((b,i)=>{const available=s.m.sub(s.m.sub(b.capacity,spent[i]),reserved[i]);
    if(st.health==='healthy'&&available.n<0n)throw new Error('Healthy accounting invariant violated');
    return {id:b.id,unit:b.unit,capacity:b.capacity,spent:spent[i],reserved:reserved[i],available};});
}
function view(cfg,st,s){return wire({ledgerHash:cfg.hash,sequence:st.sequence,base:st.base,at:st.at,health:st.health,
  budgets:accounting(cfg,st,s),plans:[...st.plans.values()],messageCount:st.messages.size},s)}
function result(s,status,reason,extra={}){return freeze({status,reason,scope,modelHash:s?.modelHash??null,workUsed:s?.used??0,resourceLimits:s?.limits??null,...extra})}
function refused(s,error){return result(s,error instanceof Rejected?'REJECTED':'UNKNOWN',error.message??'Negotiation refused',
  {kind:error instanceof Refused?error.kind:error instanceof Rejected?'protocol-rejection':'internal-error',fresh:false,effect:'NONE'})}
export function prepareJointNegotiation(raw,checkers,options={}){
  let s;try{
    s=stateOf(options);const definition=normalizedSpec(raw,s),hash=sha256(encode(definition,s));s.modelHash=hash;
    const cfg=freeze({...definition,hash}),byId=new Map;
    for(const c of list(checkers,s.limits.maxContracts,s,'Contract checkers')){fields(c,['id','revision','check'],s);
      const id=text(c.id,s),version=revision(c.revision);if(byId.has(id)||typeof c.check!=='function')fail('One trusted synchronous checker per contract required');
      byId.set(id,freeze({id,revision:version,check:c.check}));}
    if(byId.size!==cfg.requiredContracts.length||cfg.requiredContracts.some(c=>byId.get(c.id)?.revision!==c.revision))fail('Checkers must exactly match the independent contract inventory','unknown-evidence');
    const st={base:cfg.base,at:cfg.at,sequence:0,health:'healthy',plans:new Map,messages:new Map,journalChars:0};
    const ledger=freeze({kind:'joint-negotiation-ledger-v1',id:cfg.id,modelHash:hash}),snapshot=view(cfg,st,s);
    const out=result(s,'PASS','Prepared one serial negotiation authority',{ledger,snapshot});
    ledgers.set(ledger,{cfg,checks:cfg.requiredContracts.map(c=>byId.get(c.id)),state:st,busy:false});return out;
  }catch(error){return refused(s,error)}
}
export function inspectJointNegotiation(ledger,options={}){
  let s;try{s=stateOf(options);const l=ledgerOf(ledger,s);return result(s,'PASS','Immutable current ledger view',{snapshot:view(l.cfg,l.state,s)})}catch(error){return refused(s,error)}
}
function expire(st,now,s){for(const [id,p] of st.plans){s.charge();if(p.state==='pending'&&s.m.cmp(now,p.proposal.commitBy)>=0)
  st.plans.set(id,freeze({...p,state:'expired',reason:'commit-deadline'}));}}
function cancelPending(st,reason,s){for(const [id,p] of st.plans){s.charge();if(p.state==='pending')st.plans.set(id,freeze({...p,state:'aborted',reason}));}}
function getPlan(st,c){const p=st.plans.get(c.planId);requireThat(p&&p.hash===c.planHash,'Unknown plan or changed proposal hash');return p}
function assertBase(a,b,s){requireThat(encode(a,s)===encode(b,s),'Proposal base is stale; renegotiate explicitly')}
export function stepJointNegotiation(ledger,raw,received,options={}){
  let s,l,ownsBusy=false;try{
    s=stateOf(options);l=ledgerOf(ledger,s);if(l.busy)fail('Reentrant negotiation step refused','reentrant');l.busy=true;ownsBusy=true;
    const cfg=l.cfg,old=l.state,e=envelope(received,s),c=command(raw,cfg,s);
    requireThat(e.epoch===old.base.authority.epoch,'Stale authority epoch');requireThat(sameClock(e.clock,old.base.clock),'Stale receive clock');
    requireThat(s.m.cmp(e.now,old.at)>=0,'Receive time precedes the last accepted transition');
    const isAuthority=sameActor(e.origin,old.base.authority),isMember=cfg.participants.some(p=>sameActor(p,e.origin));
    requireThat(isAuthority||isMember,'Origin is not a declared actor');
    const canonical=encode({command:c,origin:e.origin,epoch:e.epoch,clock:e.clock},s),previous=old.messages.get(c.messageId);
    if(previous){requireThat(previous.canonical===canonical,'Message identity reused with different content');
      return result(s,'REPLAY','Previously accepted message; no new transition',{fresh:false,effect:'NONE',originalReceipt:previous.receipt,snapshot:view(cfg,old,s)});}
    if(old.messages.size>=s.limits.maxMessages||canonical.length>s.limits.maxTextChars-old.journalChars)fail('Retained message history allowance','shape-budget');
    if(c.type!=='accept'&&c.type!=='abort')requireThat(isAuthority,'Only the current coordinator may perform this operation');
    if(old.health==='breached'&&(c.type==='reserve'||c.type==='commit'))throw new Rejected('Ledger breached; new commitments are frozen');
    s.charge(old.plans.size+old.messages.size+1);
    const st={...old,at:e.now,sequence:old.sequence+1,plans:new Map(old.plans),messages:new Map(old.messages)};
    expire(st,e.now,s);let effect='ADVANCED',planHash=null;
    if(c.type==='reserve'){
      const p=c.proposal;assertBase(p.base,st.base,s);requireThat(!st.plans.has(p.id),'Plan identity is already retained');
      requireThat(s.m.cmp(e.now,p.commitBy)<0,'Proposal has missed its commit deadline');
      if(st.plans.size>=s.limits.maxPlans)fail('Retained plan history allowance','shape-budget');
      const available=accounting(cfg,st,s);for(let i=0;i<available.length;i++)requireThat(s.m.cmp(p.charges[i].amount,available[i].available)<=0,'Joint reservation exceeds remaining allowance');
      planHash=sha256(encode(p,s));st.plans.set(p.id,freeze({id:p.id,hash:planHash,proposal:p,state:'pending',reason:null,acceptances:freeze([]),actual:null,outcome:null,report:null,commitReceipt:null}));effect='RESERVED';
    }else if(c.type==='accept'){
      const p=getPlan(st,c);planHash=p.hash;requireThat(p.state==='pending','Only a pending proposal can receive preparation');assertBase(p.proposal.base,st.base,s);
      requireThat(isMember,'Only a required participant can accept');
      const member=p.proposal.members.find(m=>sameActor(m,e.origin));requireThat(!!member,'Origin is not this required member');
      requireThat(s.m.cmp(c.preparedAt,e.now)<=0&&s.m.cmp(c.preparedAt,member.firstActionAt)<=0,'Preparation is in the future or after first action');
      requireThat(s.m.cmp(c.validThrough,p.proposal.validThrough)>=0,'Preparation does not cover the whole plan');
      const acceptance=freeze({member:freeze({...e.origin}),preparedAt:c.preparedAt,validThrough:c.validThrough,preparation:c.preparation});
      const existing=p.acceptances.find(a=>sameActor(a.member,e.origin));
      if(existing)requireThat(encode(existing,s)===encode(acceptance,s),'Prepared consent changed; abort and renegotiate');
      else st.plans.set(p.id,freeze({...p,acceptances:freeze([...p.acceptances,acceptance])}));effect='ACCEPTED';
    }else if(c.type==='abort'){
      const p=getPlan(st,c);planHash=p.hash;requireThat(p.state==='pending','Only pending reservations can be aborted');
      requireThat(isAuthority||p.proposal.members.some(m=>sameActor(m,e.origin)),'Origin cannot withdraw this proposal');
      st.plans.set(p.id,freeze({...p,state:'aborted',reason:'explicit-withdrawal'}));effect='ABORTED';
    }else if(c.type==='commit'){
      const p=getPlan(st,c);planHash=p.hash;requireThat(p.state==='pending','Only a pending proposal can commit');assertBase(p.proposal.base,st.base,s);
      requireThat(p.acceptances.length===cfg.participants.length,'Complete prepared consent is required');
      const joint=wire(p.proposal,s);
      for(const checker of l.checks){s.charge();let checked;try{checked=checker.check(joint)}catch{fail('Required joint checker threw','unknown-evidence')}
        if(checked==='FAIL')throw new Rejected('Complete joint contract failed: '+checker.id);
        if(checked!=='PASS')fail('Complete joint contract unresolved: '+checker.id,'unknown-evidence');}
      const commitReceipt=freeze({ledgerHash:cfg.hash,messageId:c.messageId,sequence:st.sequence,epoch:e.epoch,planHash:p.hash,at:e.now});
      st.plans.set(p.id,freeze({...p,state:'committed',commitReceipt}));
      st.base=freeze({...st.base,parent:freeze({id:p.id,revision:p.proposal.revision,hash:p.hash})});cancelPending(st,'parent-advanced',s);effect='COMMITTED';
    }else if(c.type==='reconcile'){
      const p=getPlan(st,c);planHash=p.hash;requireThat(p.state==='committed','Only an unreconciled committed plan accepts actual use');
      let overrun=false;for(let i=0;i<c.actual.length;i++)if(s.m.cmp(c.actual[i].amount,p.proposal.charges[i].amount)>0)overrun=true;
      st.plans.set(p.id,freeze({...p,state:'reconciled',actual:c.actual,outcome:c.outcome,report:c.report}));effect='RECONCILED';
      if(overrun){st.health='breached';cancelPending(st,'reported-overrun',s);effect='OVERRUN_RECORDED';}
    }else if(c.type==='rebase'){
      requireThat(c.base.authority.epoch>st.base.authority.epoch,'Authority transfer requires a strictly newer epoch');
      requireThat(c.base.clock.id===st.base.clock.id&&c.base.clock.unit===st.base.clock.unit&&c.base.clock.revision>=st.base.clock.revision,'Rebase must preserve the receive clock coordinate and not reverse its revision');
      st.base=c.base;cancelPending(st,'authority-rebased',s);effect='REBASED';
    }
    const receipt=wire({messageId:c.messageId,sequence:st.sequence,command:c.type,effect,planHash,epoch:e.epoch,at:e.now,ledgerHash:cfg.hash},s);
    st.journalChars+=canonical.length;st.messages.set(c.messageId,freeze({canonical,receipt}));
    const snapshot=view(cfg,st,s),out=result(s,st.health==='breached'?'BREACH':'APPLIED','Serialized decision recorded',
      {fresh:true,effect,receipt,snapshot});l.state=st;return out;
  }catch(error){return refused(s,error)}finally{if(ownsBusy)l.busy=false}
}
