// Outward dyadic bounds for log2 of a positive rational. No Math.log/host arithmetic supplies the enclosure.
// Range reduction puts m in [1,2); ln(m)=2*sum(y^(2j+1)/(2j+1)), y=(m-1)/(m+1), with a positive geometric tail.
// This bounded fixed-scale variant complements certified-logarithm.js's full rational/reverse-Horner certificate.
import {Refused,bitsOf} from '../bounded-exact.js';
import {dataRecord} from './contract-data.js';

const fail=message=>{throw new Refused(message,{kind:'arithmetic-budget'})};
const cap=n=>{if(bitsOf(n)>8192)fail('Logarithm intermediate exceeds8192bits');return n};
const ceil=(n,d)=>n/d+(n%d?1n:0n);
const fields=(v,keys)=>{if(!dataRecord(v)||Object.keys(v).length!==keys.length||keys.some(k=>!Object.hasOwn(v,k)))fail('Complete plain logarithm fields required')};

/** lower/scale <= log2(x) <= upper/scale; bounds may be negative. Caller's work counter is required. */
export function log2PositiveDyadic(x,options){
  fields(x,['n','d']);fields(options,['precisionBits','terms','charge']);
  let {n,d}=x;const {precisionBits,terms,charge}=options;
  if(typeof n!=='bigint'||typeof d!=='bigint'||n<=0n||d<=0n)fail('Positive exact logarithm argument required');
  cap(n);cap(d);
  if(!Number.isSafeInteger(precisionBits)||precisionBits<16||precisionBits>256||!Number.isSafeInteger(terms)||terms<2||terms>128||typeof charge!=='function')fail('Declare16..256 bits,2..128 terms and a work counter');
  const scale=1n<<BigInt(precisionBits);let exponent=0;
  while(n<d){charge();n=cap(n*2n);if(--exponent< -8192)fail('Logarithm range reduction allowance')}
  while(n>=2n*d){charge();d=cap(d*2n);if(++exponent>8192)fail('Logarithm range reduction allowance')}
  const offset=BigInt(exponent)*scale;
  if(n===d)return Object.freeze({lower:offset,upper:offset,scale,exponent,terms,method:'exact-power-of-two'});
  function ln(a,b){
    const aa=cap(a*a),bb=cap(b*b);let powerLow=cap(scale*a)/b,powerHigh=ceil(cap(scale*a),b),sumLow=0n,sumHigh=0n;
    for(let j=0;j<terms;j++){
      charge(6);const divisor=BigInt(2*j+1);
      sumLow=cap(sumLow+powerLow/divisor);sumHigh=cap(sumHigh+ceil(powerHigh,divisor));
      powerLow=cap(powerLow*aa)/bb;powerHigh=ceil(cap(powerHigh*aa),bb);
    }
    charge(3);const tail=ceil(cap(2n*powerHigh*bb),cap(BigInt(2*terms+1)*(bb-aa)));
    return {lower:cap(2n*sumLow),upper:cap(2n*sumHigh+tail)};
  }
  charge(6);const numerator=ln(n-d,n+d),denominator=ln(1n,3n);
  if(denominator.lower<=0n)fail('Logarithm denominator enclosure is not positive');
  return Object.freeze({lower:offset+cap(numerator.lower*scale)/denominator.upper,
    upper:offset+ceil(cap(numerator.upper*scale),denominator.lower),scale,exponent,terms,
    method:'outward-atanh-series-geometric-tail-and-ln2-division'});
}
