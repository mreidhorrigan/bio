// CFM-023 / CF18 / EC13: exact future-conditioned finite paths and one prepared integer lottery.
// The graph declares musical evidence; this library proves its finite law, not the truth of that evidence.
import {Refused,ZERO,ONE,exactOf,exactText,add,sub,mul,div,compare,pythonJson,sha256} from '../bounded-exact.js';
import {dataRecord,dataArray} from './contract-data.js';
import {exactRankBelow} from '../math-support/adapters/sampling/policies.js';

export const CONDITIONED_PATH_LIMITS=Object.freeze({maxWork:500000,maxStates:256,maxDecisions:4096,
  maxDecisionsPerState:64,maxResources:8,maxPredicates:32,maxEventIds:8192,maxDependencies:128,
  maxHorizon:256,maxConfigurations:8192,maxTicketBits:2048,maxTextChars:4194304,maxCertificateChars:4194304});
const freeze=Object.freeze,plans=new WeakMap,scope='declared-deterministic-exact-horizon-conditioned-path-law';
const rawBound=1n<<256n,derivedBound=1n<<8192n;
const fail=(message,kind='invalid-input')=>{throw new Refused(message,{kind})};
class BadCertificate extends Error {}
const requireCertificate=(yes,message)=>{if(!yes)throw new BadCertificate(message)};
const count=v=>{if(!Number.isSafeInteger(v)||v<0)fail('Require finite nonnegative integer limits/revisions');return v};
function stateOf(options){
  if(!dataRecord(options)||Object.keys(options).some(k=>!Object.hasOwn(CONDITIONED_PATH_LIMITS,k)))fail('Unknown path limits');
  const limits={};for(const [key,value] of Object.entries(CONDITIONED_PATH_LIMITS))limits[key]=Object.hasOwn(options,key)?count(options[key]):value;
  if(limits.maxTicketBits<1||limits.maxTicketBits>2048)fail('The reused exact-rank sampler admits 1..2048 ticket bits','out-of-model');
  const s={limits:freeze(limits),used:0,chars:0,modelHash:null,ticketBound:1n<<BigInt(limits.maxTicketBits)};
  s.charge=(n=1)=>{if(!Number.isSafeInteger(n)||n<0)throw new Error('Invalid work charge');if(n>limits.maxWork-s.used)fail('Path work allowance exhausted','work-budget');s.used+=n};
  s.math={add(a,b){s.charge();return add(a,b)},sub(a,b){s.charge();return sub(a,b)},mul(a,b){s.charge();return mul(a,b)},
    div(a,b){s.charge();return div(a,b)},compare(a,b){s.charge();return compare(a,b)}};
  s.charge();return s;
}
function fields(v,keys,s){
  s.charge();if(!dataRecord(v)||Object.keys(v).length!==keys.length||keys.some(k=>!Object.hasOwn(v,k)))fail('Unexpected or missing path fields');
  s.charge(keys.length);return v;
}
function array(v,max,s,label){
  if(!Array.isArray(v)||v.length>max)fail(label+' exceeds its array allowance','shape-budget');
  s.charge(v.length+1);return dataArray(v,max,label);
}
function text(v,s,max=256){
  if(typeof v!=='string'||!v.length||v.length>max)fail('Bounded nonempty text required');
  if(v.length>s.limits.maxTextChars-s.chars)fail('Path text allowance exhausted','work-budget');
  s.chars+=v.length;s.charge(1+Math.ceil(v.length/64));return v;
}
function integer(v){
  const n=typeof v==='bigint'?v:Number.isSafeInteger(v)?BigInt(v):null;
  if(n===null)fail('Require exact integer components');
  if(n<=-rawBound||n>=rawBound)fail('Raw component exceeds 256 bits','arithmetic-budget');return n;
}
function rational(v,s){
  s.charge();let n,d=1n;
  if(typeof v==='string'){
    text(v,s,160);const f=v.match(/^([+-]?[0-9]+)(?:\/([+-]?[0-9]+))?$/);
    if(f&&f[0].length===v.length){n=integer(BigInt(f[1]));d=integer(BigInt(f[2]??'1'))}
    else{
      const t=v.match(/^([+-]?)(?:([0-9]+)(?:\.([0-9]*))?|\.([0-9]+))(?:[eE]([+-]?[0-9]{1,3}))?$/);
      if(!t||t[0].length!==v.length)fail('Invalid exact probability/resource spelling');
      const [,sign,whole='',part=t[4]??'',,exp='0']=t,power=Number(exp);
      if(Math.abs(power)>256)fail('Decimal exponent allowance','arithmetic-budget');
      n=integer(BigInt((whole+part)||'0')*(sign==='-'?-1n:1n));const shift=power-part.length;
      if(shift< -77||shift>77&&n!==0n)fail('Expanded raw component allowance','arithmetic-budget');
      if(shift>0&&n!==0n)n=integer(n*10n**BigInt(shift));else if(shift<0)d=integer(10n**BigInt(-shift));
    }
  }else if(v&&typeof v==='object'){fields(v,['n','d'],s);n=integer(v.n);d=integer(v.d)}
  else n=integer(v);
  if(d===0n)fail('Zero denominator');return exactOf({n,d});
}
function nonnegative(v,s){const q=rational(v,s);if(s.math.compare(q,ZERO)<0)fail('Probability/resource values must be nonnegative');return q}
function derived(v,s){
  text(v,s,6000);s.charge();const t=v.match(/^(0|[1-9][0-9]*)(?:\/([1-9][0-9]*))?$/);
  if(!t||t[0].length!==v.length)fail('Canonical nonnegative certificate fraction required');
  const n=BigInt(t[1]),d=BigInt(t[2]??'1');if(n>=derivedBound||d>=derivedBound)fail('Derived scalar exceeds 8192 bits','arithmetic-budget');
  const q=exactOf({n,d},{bits:8192});if(exactText(q)!==v)fail('Noncanonical certificate scalar');return q;
}
function tickets(n,s){s.charge();if(n<0n||n>=s.ticketBound)fail('Exact ticket allowance exhausted','arithmetic-budget');return n}
const qInt=n=>exactOf(n,{bits:8192});
function gcd(a,b,s){while(b){s.charge();[a,b]=[b,a%b]}return a}
function gcdQ(a,b,s){
  if(a.n===0n)return b;
  const shared=gcd(a.d,b.d,s),den=(a.d/shared)*b.d;s.charge();
  if(den>=derivedBound)fail('Rational gcd denominator allowance','arithmetic-budget');
  const n=gcd(a.n*(b.d/shared),b.n*(a.d/shared),s);
  return exactOf({n,d:den},{bits:8192});
}
function hash(v,s,certificate=false){
  const limit=certificate?s.limits.maxCertificateChars:s.limits.maxTextChars,parts=[];let size=0;
  const append=x=>{if(x.length>limit-size)fail('Canonical path text allowance','work-budget');size+=x.length;parts.push(x)};
  function encode(x){
    s.charge();if(x===null||typeof x!=='object'){append(pythonJson(x));return}
    if(Array.isArray(x)){append('[');for(let i=0;i<x.length;i++){if(i)append(',');encode(x[i])}append(']');return}
    const keys=Object.keys(x).sort((a,b)=>{s.charge();return a<b?-1:a>b?1:0});
    append('{');for(let i=0;i<keys.length;i++){if(i)append(',');append(pythonJson(keys[i]));append(':');encode(x[keys[i]])}append('}');
  }
  encode(v);s.charge(1+Math.ceil(size/64));return sha256(parts.join(''));
}
function ids(raw,max,s){
  array(raw,max,s,'Identity list');const seen=new Set,out=[];
  for(const value of raw){const id=text(value,s);if(seen.has(id))fail('Duplicate identity');seen.add(id);out.push(id)}return freeze(out);
}
function normalize(raw,s){
  fields(raw,['id','revision','start','horizon','resources','requiredPredicates','lockedEventIds','dependencies','states'],s);
  const id=text(raw.id,s),revision=count(raw.revision),start=text(raw.start,s),horizon=count(raw.horizon);
  if(horizon>s.limits.maxHorizon)fail('Horizon allowance','shape-budget');
  const required=ids(raw.requiredPredicates,s.limits.maxPredicates,s),locked=ids(raw.lockedEventIds,s.limits.maxEventIds,s);
  array(raw.resources,s.limits.maxResources,s,'Resources');const resourceIds=new Set,resources=[];
  for(const r of raw.resources){fields(r,['id','unit','remaining'],s);const name=text(r.id,s);if(resourceIds.has(name))fail('Duplicate resource');resourceIds.add(name);
    resources.push(freeze({id:name,unit:text(r.unit,s),remaining:nonnegative(r.remaining,s)}))}
  array(raw.dependencies,s.limits.maxDependencies,s,'Dependencies');const depIds=new Set,dependencies=[];
  for(const d of raw.dependencies){fields(d,['id','revision','hash'],s);const name=text(d.id,s),value=text(d.hash,s);
    if(depIds.has(name)||value.length!==64||!/^[0-9a-f]{64}$/.test(value))fail('Unique dependency ID and lowercase SHA-256 required');depIds.add(name);
    dependencies.push(freeze({id:name,revision:count(d.revision),hash:value}))}
  array(raw.states,s.limits.maxStates,s,'States');if(!raw.states.length)fail('At least one state required');
  const states=[],byId=new Map;let decisions=0,eventIds=locked.length;
  const verdict=v=>{if(!['PASS','FAIL','UNKNOWN'].includes(v))fail('Named evidence requires PASS, FAIL or UNKNOWN');return v};
  for(const r of raw.states){
    fields(r,['id','goal','decisionsComplete','decisions'],s);const name=text(r.id,s);
    if(byId.has(name)||typeof r.decisionsComplete!=='boolean')fail('Unique state ID and explicit completeness required');byId.set(name,states.length);
    array(r.decisions,s.limits.maxDecisionsPerState,s,'Decisions');decisions+=r.decisions.length;
    if(decisions>s.limits.maxDecisions)fail('Total decision allowance','shape-budget');
    const actions=[],seen=new Set;let total=ZERO;
    for(const d of r.decisions){
      fields(d,['id','next','probability','costs','changedEventIds','checks'],s);const actionId=text(d.id,s);
      if(seen.has(actionId))fail('Duplicate decision ID');seen.add(actionId);
      const probability=nonnegative(d.probability,s);if(s.math.compare(probability,ONE)>0)fail('Probability exceeds one');total=s.math.add(total,probability);
      array(d.costs,resources.length,s,'Cost vector');if(d.costs.length!==resources.length)fail('Cost/resource dimensions differ');
      const costs=freeze(d.costs.map(v=>nonnegative(v,s))),changed=ids(d.changedEventIds,s.limits.maxEventIds,s);
      eventIds+=changed.length;if(eventIds>s.limits.maxEventIds)fail('Total event-identity allowance','shape-budget');
      array(d.checks,s.limits.maxPredicates,s,'Predicate evidence');const checks=[],checkIds=new Set;
      for(const c of d.checks){fields(c,['id','status'],s);const key=text(c.id,s);if(!required.includes(key)||checkIds.has(key))fail('Undeclared or repeated predicate');
        checkIds.add(key);checks.push(freeze({id:key,status:verdict(c.status)}))}
      actions.push(freeze({id:actionId,next:text(d.next,s),probability,costs,changedEventIds:changed,checks:freeze(checks)}));
    }
    if(actions.length&&s.math.compare(total,ONE)!==0)fail('Every nonempty original prior row must sum exactly to one');
    states.push(freeze({id:name,goal:verdict(r.goal),decisionsComplete:r.decisionsComplete,decisions:freeze(actions)}));
  }
  if(!byId.has(start))fail('Unknown initial state');
  for(const n of states)for(const a of n.decisions){s.charge();if(!byId.has(a.next))fail('Unknown successor state')}
  const definition=freeze({id,revision,start,horizon,resources:freeze(resources.map(r=>freeze({...r,remaining:exactText(r.remaining)}))),
    requiredPredicates:required,lockedEventIds:locked,dependencies:freeze(dependencies),
    states:freeze(states.map(n=>freeze({...n,decisions:freeze(n.decisions.map(a=>freeze({...a,probability:exactText(a.probability),
      costs:freeze(a.costs.map(exactText))})))})))});
  s.modelHash=hash(definition,s);
  return {definition,states:freeze(states),byId,start:byId.get(start),horizon,resources:freeze(resources),required,locked:new Set(locked)};
}
function topology(model,s){
  const nodes=[],byKey=new Map,m=s.math;
  function intern(index,left,remaining){
    s.charge();const key=index+':'+left+':'+remaining.map(exactText).join(',');
    if(byKey.has(key))return byKey.get(key);
    if(nodes.length>=s.limits.maxConfigurations)fail('Reachable configuration allowance','work-budget');
    const at=nodes.length;byKey.set(key,at);
    // All eventual spend conversion is prepared before any random input is requested.
    const spent=freeze(remaining.map((value,i)=>freeze({id:model.resources[i].id,unit:model.resources[i].unit,
      value:exactText(m.sub(model.resources[i].remaining,value))})));
    nodes.push({key,index,left,remaining:freeze(remaining),spent,edges:[]});return at;
  }
  intern(model.start,model.horizon,model.resources.map(r=>r.remaining));
  for(let at=0;at<nodes.length;at++){
    s.charge();const row=nodes[at],node=model.states[row.index];
    if(row.left===0){if(node.goal==='UNKNOWN')fail('Terminal obligation is unknown','missing-evidence');continue}
    if(!node.decisionsComplete)fail('Reachable decision inventory is incomplete','missing-evidence');
    for(const a of node.decisions){
      s.charge();if(a.probability.n===0n)continue;
      let failed=false,unknown=false;
      for(const id of a.changedEventIds){s.charge();if(model.locked.has(id))failed=true}
      for(let i=0;i<row.remaining.length;i++)if(m.compare(a.costs[i],row.remaining[i])>0)failed=true;
      for(const id of model.required){s.charge();const c=a.checks.find(c=>c.id===id);if(c?.status==='FAIL')failed=true;else if(c?.status!=='PASS')unknown=true}
      if(failed)continue;if(unknown)fail('Reachable admission evidence is unknown','missing-evidence');
      const next=intern(model.byId.get(a.next),row.left-1,row.remaining.map((r,i)=>m.sub(r,a.costs[i])));
      row.edges.push({action:a,next});
    }
  }
  return nodes;
}
function liveEdges(row,nodes,s){
  const out=[];for(const e of row.edges){s.charge();const child=nodes[e.next];if(child.count>0n)out.push({...e,weight:s.math.mul(e.action.probability,child.scale)})}return out;
}
function completeRow(row,live,nodes,s){
  const m=s.math,R=row.remaining.length;row.costMoment=Array(R).fill(ZERO);row.maximum=Array(R).fill(ZERO);row.branches=[];
  let until=0n;
  for(const e of live){
    const child=nodes[e.next];until=tickets(until+tickets(e.multiplier*child.count,s),s);
    row.branches.push(freeze({action:e.action,next:e.next,multiplier:e.multiplier,until}));
    for(let j=0;j<R;j++){
      row.costMoment[j]=m.add(row.costMoment[j],m.mul(qInt(e.multiplier),m.add(m.mul(qInt(child.count),e.action.costs[j]),child.costMoment[j])));
      const peak=m.add(e.action.costs[j],child.maximum[j]);if(m.compare(peak,row.maximum[j])>0)row.maximum[j]=peak;
    }
  }
  row.branches=freeze(row.branches);row.costMoment=freeze(row.costMoment);row.maximum=freeze(row.maximum);
}
function reportOf(model,nodes,s){
  const root=nodes[0],mass=s.math.mul(root.scale,qInt(root.count)),supported=root.count>0n;
  return freeze({status:supported?'CERTIFIED':'EMPTY',mass:exactText(mass),tickets:String(root.count),
    expectedCosts:freeze(model.resources.map((r,i)=>freeze({id:r.id,unit:r.unit,value:supported?exactText(s.math.div(root.costMoment[i],qInt(root.count))):null}))),
    maximumCosts:freeze(model.resources.map((r,i)=>freeze({id:r.id,unit:r.unit,value:supported?exactText(root.maximum[i]):null})))});
}
function result(s,status,reason,extra={}){return freeze({status,reason,scope,modelHash:s?.modelHash??null,
  workUsed:s?.used??0,resourceLimits:s?.limits??null,...extra})}
function run(options,body){let s;try{s=stateOf(options);return body(s)}catch(e){
  return result(s,e instanceof BadCertificate?'FAIL':'UNKNOWN',e.message??'Path processing refused',
    {kind:e instanceof Refused?e.kind:e instanceof BadCertificate?'invalid-certificate':'internal-error',conclusion:null})}}

/** Computes a complete declared conditioned law; no random source or music is executed. */
export function solveConditionedPaths(spec,options={}){
  return run(options,s=>{
    const model=normalize(spec,s),nodes=topology(model,s);
    for(let i=nodes.length-1;i>=0;i--){
      s.charge();const row=nodes[i],live=liveEdges(row,nodes,s);
      if(row.left===0){const accepted=model.states[row.index].goal==='PASS';row.scale=accepted?ONE:ZERO;row.count=accepted?1n:0n}
      else{
        let scale=ZERO;for(const e of live)scale=gcdQ(scale,e.weight,s);row.scale=scale;row.count=0n;
        for(const e of live){const ratio=s.math.div(e.weight,scale);if(ratio.d!==1n||ratio.n<=0n)throw new Error('Rational gcd identity');
          e.multiplier=tickets(ratio.n,s);row.count=tickets(row.count+tickets(e.multiplier*nodes[e.next].count,s),s)}
      }
      completeRow(row,live,nodes,s);
    }
    const report=reportOf(model,nodes,s),certificate=freeze({kind:'conditioned-paths-v1',modelHash:s.modelHash,
      rows:freeze(nodes.map(n=>freeze({key:n.key,scale:exactText(n.scale),tickets:String(n.count)}))),reportHash:hash(report,s)});
    hash(certificate,s,true);
    // (Its law, to draw from as it is solved: a path is drawn from the solver's own law while the music is made; the
    // certificate is checked in development, checkConditionedPaths.)
    let plan=null;
    if(nodes[0].count>0n){
      plan=freeze({kind:'solved-conditioned-paths-v1',modelHash:s.modelHash,horizon:model.horizon,tickets:report.tickets,mass:report.mass,configurations:nodes.length});
      for(const row of nodes){freeze(row.edges);freeze(row)}freeze(nodes);
      plans.set(plan,freeze({model,nodes,report}));
    }
    return result(s,report.status,'Exact conditioned law on the complete declared reachable model',{report,certificate,plan});
  });
}

/** Independently checks closure, primitive ticket identities, moments and original model binding. */
export function checkConditionedPaths(spec,raw,options={}){
  return run(options,s=>{
    const model=normalize(spec,s);fields(raw,['kind','modelHash','rows','reportHash'],s);
    for(const k of ['kind','modelHash','reportHash'])text(raw[k],s);
    requireCertificate(raw.kind==='conditioned-paths-v1'&&raw.modelHash===s.modelHash,'Wrong certificate model or kind');
    array(raw.rows,s.limits.maxConfigurations,s,'Certificate rows');const saved=new Map,wire=[];
    for(const r of raw.rows){
      fields(r,['key','scale','tickets'],s);const key=text(r.key,s,s.limits.maxTextChars),scale=derived(r.scale,s),countQ=derived(r.tickets,s);
      requireCertificate(countQ.d===1n&&!saved.has(key),'Ticket count must be integral and keys unique');
      const count=tickets(countQ.n,s);saved.set(key,{scale,count});wire.push(freeze({key,scale:exactText(scale),tickets:String(count)}));
    }
    hash({kind:raw.kind,modelHash:raw.modelHash,rows:wire,reportHash:raw.reportHash},s,true);
    const nodes=topology(model,s);
    requireCertificate(saved.size===nodes.length&&nodes.every(n=>saved.has(n.key)),'Certificate omits or adds reachable configurations');
    for(let i=nodes.length-1;i>=0;i--){
      s.charge();const row=nodes[i],claim=saved.get(row.key);row.scale=claim.scale;row.count=claim.count;
      const live=liveEdges(row,nodes,s);
      if(row.left===0){
        const wanted=model.states[row.index].goal==='PASS'?1n:0n;
        requireCertificate(row.count===wanted&&row.scale.d===1n&&row.scale.n===wanted,'Wrong exact-horizon terminal tickets');
      }else if(!live.length)requireCertificate(row.count===0n&&row.scale.n===0n,'Empty support must use zero scale and zero tickets');
      else{
        requireCertificate(row.scale.n>0n&&row.count>0n,'Positive suffix support needs positive scale and tickets');
        let total=0n,common=0n;
        for(const e of live){
          const ratio=s.math.div(e.weight,row.scale);
          requireCertificate(ratio.d===1n&&ratio.n>0n,'Edge scale is not a positive integer multiple');
          e.multiplier=tickets(ratio.n,s);common=gcd(common,e.multiplier,s);
          total=tickets(total+tickets(e.multiplier*nodes[e.next].count,s),s);
        }
        requireCertificate(total===row.count&&common===1n,'Ticket recurrence or primitive common divisor fails');
      }
      completeRow(row,live,nodes,s);
    }
    const report=reportOf(model,nodes,s);requireCertificate(hash(report,s)===raw.reportHash,'Reconstructed law/cost report differs');
    let plan=null;
    if(nodes[0].count>0n){
      plan=freeze({kind:'checked-conditioned-paths-v1',modelHash:s.modelHash,horizon:model.horizon,
        tickets:report.tickets,mass:report.mass,configurations:nodes.length});
      for(const row of nodes){freeze(row.edges);freeze(row)}freeze(nodes);
      plans.set(plan,freeze({model,nodes,report}));
    }
    return result(s,'PASS','Complete reachable closure, primitive ticket equations and cost report independently checked',
      {conclusion:report.status,report,plan});
  });
}
function selected(plan,rank){
  const saved=plans.get(plan);if(!saved)fail('Require a genuine path plan, solved or checked','out-of-model');
  const root=saved.nodes[0];if(typeof rank!=='bigint'||rank<0n||rank>=root.count)fail('Root ticket rank is outside the admitted plan');
  const original=rank,states=[saved.model.states[root.index].id],decisions=[];let at=0,pathTickets=1n;
  for(let left=plan.horizon;left>0;left--){
    const row=saved.nodes[at];let low=0,high=row.branches.length;
    while(low<high){const mid=Math.floor((low+high)/2);if(rank<row.branches[mid].until)high=mid;else low=mid+1}
    const branch=row.branches[low],child=saved.nodes[branch.next],before=low?row.branches[low-1].until:0n;
    rank=(rank-before)%child.count;pathTickets*=branch.multiplier;
    decisions.push(freeze({stateId:saved.model.states[row.index].id,actionId:branch.action.id,nextStateId:saved.model.states[child.index].id}));
    states.push(saved.model.states[child.index].id);at=branch.next;
  }
  return freeze({status:'SELECTED',scope,modelHash:plan.modelHash,rank:String(original),
    path:freeze({states:freeze(states),decisions:freeze(decisions),costs:saved.nodes[at].spent,
      probability:exactText(exactOf({n:pathTickets,d:root.count},{bits:8192}))})});
}
const selectionFailure=e=>freeze({status:'UNKNOWN',scope,reason:e.message??'Path selection refused',kind:e instanceof Refused?e.kind:'selection-error'});
/** Deterministic decoding, useful for exact finite enumeration; it makes no randomness claim. */
export function unrankConditionedPath(plan,rank){
  try{return selected(plan,rank)}catch(e){return selectionFailure(e)}
}
/** Exactly one bounded root lottery, then pre-admitted deterministic decoding. RNG words must be independent/uniform. */
export function sampleConditionedPath(plan,nextWord,options={}){
  try{
    const saved=plans.get(plan);if(!saved)fail('Require a genuine path plan, solved or checked','out-of-model');
    if(!dataRecord(options)||Object.keys(options).some(k=>k!=='maxAttempts')||typeof nextWord!=='function')fail('Explicit word source and supported draw options required');
    const maxAttempts=Object.hasOwn(options,'maxAttempts')?options.maxAttempts:64;
    if(!Number.isSafeInteger(maxAttempts)||maxAttempts<1||maxAttempts>1024)fail('Draw attempts must be in 1..1024');
    const draw=exactRankBelow(saved.nodes[0].count,nextWord,{maxAttempts});
    if(!draw.ok)return freeze({status:'UNKNOWN',scope,modelHash:plan.modelHash,kind:'random-word-budget',reason:'No root rank selected before the entropy allowance ended',wordsUsed:draw.words});
    return freeze({...selected(plan,draw.rank),wordsUsed:draw.words});
  }catch(e){return selectionFailure(e)}
}
