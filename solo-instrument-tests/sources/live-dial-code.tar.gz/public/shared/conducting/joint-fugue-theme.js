// One subject AND countersubject for the conductor's declared occurrences, planned before performance.
// The finite kernel supplies pitch choices; the planner's own law and a whole disposition family keep the witness.
// Number spellings are preserved, including microtones. No score, acoustic, or historical-style claim is implicit.
import {makeModel,addConstraint,runBudgetedFinite} from './joint-theme-solver.js';
import {Q} from './canon-core.js';
import {stepInCollection,invertedLine} from './canon-plan.js';
import {answerLine,fugueAnswers} from './fugue-answer.js';
import {strongBeats} from './counterpoint.js';
import {contractOf,positionData} from './fugue-contracts.js';
import {createPitchSpace} from './pitch-spaces.js';
import {compileCounterpointProfile} from './counterpoint-profile.js';
import {prepareDispositionFamily,auditDispositionFamily,checkDispositionFamily,DISPOSITION_LIMITS} from './counterpoint-dispositions.js';
import {auditPlannerHardRules,checkPlannerLineBinding,exactPlannerNumber} from './planner-law-guard.js';
import {dataRecord,dataArray} from './contract-data.js';
import {pythonJson,sha256} from '../bounded-exact.js';

const SPACE=createPitchSpace({id:'musebots-semitones',kind:'semitones'});
const CLOCK=Object.freeze({id:'joint-fugue-quarters',unit:'quarter',revision:1});
const BINDING=1-1e-9;
export const JOINT_FUGUE_LIMITS=Object.freeze({notes:64,collection:128,requirements:16,entries:16,materialSources:32});
// The search's leap constraint, asked of every pair of pitches again and again, runs faster where a core is installed
// (shared/musical-core.js: its Rust port, the same answer; research/RUST_PORT_STATE.md). -> the core it replaced.
let core=null;
export function useJointThemeCore(given=null){const previous=core;core=given;return previous}
const fail=message=>{throw new Error(message)};
const number=value=>{
  if(typeof value!=='number'||!Number.isFinite(value)||Object.is(value,-0))fail('Use finite original Numbers, without negative zero');
  return value;
};
const exact=value=>exactPlannerNumber(number(value)),q=value=>Q(exact(value));
const positive=value=>{number(value);if(value<=0)fail('Positive number required');return value};
const natural=value=>{number(value);if(!Number.isSafeInteger(value)||value<0)fail('Nonnegative safe integer required');return value};
const id=value=>{if(typeof value!=='string'||!value.length||value.length>96||!/^[A-Za-z0-9_.-]+$/.test(value))fail('Bounded occurrence/voice identity required');return value};
const fields=(value,allowed,required=[])=>{
  if(!dataRecord(value)||Object.keys(value).some(k=>!allowed.includes(k))||required.some(k=>!Object.hasOwn(value,k)))fail('Unexpected or missing joint-fugue fields');
  return value;
};
const list=(value,cap)=>{dataArray(value,cap);return value};
const range=value=>{
  list(value,2);if(value.length!==2||number(value[0])>number(value[1]))fail('Ordered pitch register required');return [...value];
};
const modeled=line=>line.map(note=>Object.fromEntries(['pitch','start','length'].map(key=>[key,exact(note[key])])));
const endOf=line=>line.reduce((end,n)=>{const next=q(n.start).add(q(n.length));return next.cmp(end)>0?next:end},Q(0));
const root=(source,index)=>`${source}:${index}`;
const scoped=(control,value)=>{const text=pythonJson(value);control.charge(1+Math.ceil(text.length/64));return sha256(text)};

// Resource policy, not a timing calibration. An explicit smaller allowance always wins. Live callers must still
// schedule this off the tick/audio thread. The deadline is cooperative around bounded modules, not a WCET proof.
export function jointFugueBudget({mode='live',planningMs=mode==='offline'?10000:16,maxWork,maxNodes,maxChecks}={}){
  if(!['live','offline'].includes(mode))fail('Declare live or offline preplanning');
  number(planningMs);if(planningMs<0)fail('Nonnegative available preplanning time required');
  const timeMs=Math.min(planningMs,mode==='offline'?10000:50);
  const work=Math.min(mode==='offline'?8000000:200000,Math.floor(timeMs*4000));
  const smaller=(given,cap)=>given===undefined?cap:Math.min(natural(given),cap);
  return {timeMs,maxWork:smaller(maxWork,work),maxNodes:smaller(maxNodes,100000),maxChecks:smaller(maxChecks,work)};
}

function rhythm(raw,control){
  list(raw,JOINT_FUGUE_LIMITS.notes);if(raw.length<2)fail('Each theme needs at least two declared notes');let end=Q(0);
  return raw.map(note=>{
    control.charge();fields(note,['start','length'],['start','length']);
    const out={start:number(note.start),length:positive(note.length)},at=q(out.start);
    if(at.cmp(end)<0)fail('Rhythms must be nonnegative, ordered and exactly monophonic');end=at.add(q(out.length));return out;
  });
}
function ladder(collection,register,control){
  const pitches=new Set;
  for(const pitch of collection){
    const from=Math.ceil((register[0]-pitch)/12),to=Math.floor((register[1]-pitch)/12);
    if(!Number.isSafeInteger(from)||!Number.isSafeInteger(to)||to-from>128)fail('Pitch ladder exceeds admission');
    for(let octave=from;octave<=to;octave++){
      control.charge();const value=number(pitch+12*octave);
      if(value>=register[0]&&value<=register[1])pitches.add(value);
      if(pitches.size>128)fail('Pitch domain exceeds admission');
    }
  }
  return [...pitches].sort((a,b)=>a-b);
}
function rate(raw){
  if(typeof raw==='number')return positive(raw);
  if(typeof raw!=='string'||raw.length>160||!/^\d+(?:\/\d+)?$/.test(raw))fail('Ratio must be a positive Number or exact fraction');
  const value=Q(raw);if(value.cmp(0)<=0)fail('Positive ratio required');return positive(Number(value.n)/Number(value.d));
}
const entryFields=['id','source','voice','delay','steps','answer','invert','ratio','register','transpose'];
function entry(raw,index,register,extraDelay=0){
  fields(raw,entryFields,['source','voice']);if(!['S','C'].includes(raw.source))fail('Entry must refer to the common S or C');
  const out={id:id(raw.id??`part${index}`),source:raw.source,voice:id(raw.voice),delay:number((raw.delay??0)+extraDelay),
    steps:raw.steps??0,answer:raw.answer??false,invert:raw.invert??null,ratio:rate(raw.ratio??1),
    register:range(raw.register??register),transpose:number(raw.transpose??0)};
  if(!Number.isSafeInteger(out.steps)||typeof out.answer!=='boolean'||![null,'degrees','cents'].includes(out.invert))fail('Unsupported pitch operation');
  if(out.answer&&(out.steps||out.invert))fail('Answer policy replaces entry steps/inversion');
  if(out.delay<0)fail('Negative entry delay');return out;
}
function occurrences(request,base,control){
  const all=[],identities=new Set;let sources=0;
  const append=(name,entries,extra={})=>{
    control.charge();id(name);if(identities.has(name))fail('Duplicate required occurrence');identities.add(name);
    if(!entries.length||new Set(entries.map(e=>e.id)).size!==entries.length)fail('Distinct, nonempty entry inventory required');
    sources+=entries.length;if(sources>JOINT_FUGUE_LIMITS.materialSources||all.length>=JOINT_FUGUE_LIMITS.requirements)fail('Required family exceeds admission; do not truncate it');
    all.push({id:name,entries,...extra});
  };
  for(const requirement of list(request.requirements,JOINT_FUGUE_LIMITS.requirements)){
    if(!dataRecord(requirement))fail('Ordinary requirement record required');
    const own={entries:['entries'],stretto:['entries','offsets'],exchange:['placements'],'tempo-canon':['source','voices','length','group']}[requirement.kind];
    if(!own)fail('Unsupported required occurrence kind');
    fields(requirement,['id','kind','requireOverlap','voiceOrder',...own],['id','kind']);
    const name=id(requirement.id),requireOverlap=requirement.requireOverlap??true;
    if(typeof requireOverlap!=='boolean')fail('Declare overlap as a Boolean');
    const voiceOrder=requirement.voiceOrder?list(requirement.voiceOrder,16).map(id):null;
    const common={requireOverlap,voiceOrder};
    if(requirement.kind==='entries'){
      append(name,list(requirement.entries,16).map((e,i)=>entry(e,i,base.register)),common);
    }else if(requirement.kind==='stretto'){
      const offsets=list(requirement.offsets,16),entries=list(requirement.entries,16);
      if(!offsets.length||entries.length<2)fail('Stretto needs offsets and at least two entries');
      const seen=new Set;
      offsets.forEach((offset,k)=>{
        number(offset);if(offset<0||seen.has(exact(offset)))fail('Distinct nonnegative stretto offsets required');seen.add(exact(offset));
        append(`${name}.${k}`,entries.map((e,i)=>entry(e,i,base.register,number(i*offset))),{...common,offset});
      });
    }else if(requirement.kind==='exchange'){
      const placements=list(requirement.placements,16);if(!placements.length)fail('Exchange placements are missing');
      placements.forEach((placement,k)=>{
        fields(placement,['id','subject','countersubject'],['subject','countersubject']);
        for(const value of [placement.subject,placement.countersubject])fields(value,entryFields.filter(k=>k!=='source'),['voice']);
        append(`${name}.${id(placement.id??String(k))}`,[
          entry({...placement.subject,source:'S'},0,base.register),entry({...placement.countersubject,source:'C'},1,base.register)
        ],common);
      });
    }else if(requirement.kind==='tempo-canon'){
      const source=requirement.source??'S';if(!['S','C'].includes(source))fail('Tempo canon source must be S or C');
      const line=base.rhythms[source],voices=list(requirement.voices,16);
      if(voices.length<2||line[0].start!==0)fail('Tempo canon needs two voices and a source beginning at zero');
      const length=positive(requirement.length),group=number(requirement.group);if(group<0)fail('Nonnegative entry gap required');
      const ratios=voices.map(v=>{fields(v,entryFields.filter(k=>!['source','delay'].includes(k)),['voice','ratio']);return rate(v.ratio)}),at=number(ratios[0]*line.at(-1).start);
      const entries=voices.map((v,i)=>entry({...v,source,delay:number(at-ratios[i]*line.at(-1).start)},i,base.register));
      append(name,entries,{...common,tempo:{at,length,group,ratios}});
    }else fail('Unsupported required occurrence kind');
  }
  if(!all.length||!['S','C'].every(s=>all.some(o=>o.entries.some(e=>e.source===s))))fail('A complete nonempty family must use both S and C');
  for(const occurrence of all){
    const voices=[...new Set(occurrence.entries.map(e=>e.voice))],order=occurrence.voiceOrder;
    if(order&&(order.length!==voices.length||new Set(order).size!==order.length||order.some(v=>!voices.includes(v))))fail('Voice order must enumerate the actual voices once');
    if(base.rules.crossing>=BINDING&&voices.length>1&&!order)fail('A binding crossing rule needs the declared low-to-high voice order');
  }
  return all;
}

function normalize(request,control){
  fields(request,['phase','complete','collection','register','meter','subjectRhythm','counterRhythm','rules','strong','answer','requirements','domains','hints','budget','accepts'],
    ['phase','complete','collection','register','meter','subjectRhythm','counterRhythm','rules','requirements']);
  if(request.phase!=='preperformance'||request.complete!==true)fail('A complete preperformance requirement inventory is required');
  const collection=list(request.collection,128).map(number);if(!collection.length)fail('Collection is missing');
  const register=range(request.register),rhythms={S:rhythm(request.subjectRhythm,control),C:rhythm(request.counterRhythm,control)};
  if(!dataRecord(request.meter))fail('Declared meter required');
  const meter={numerator:positive(request.meter.numerator),denominator:positive(request.meter.denominator),groups:list(request.meter.groups,128).map(positive)};
  if(!Number.isSafeInteger(meter.numerator)||!Number.isSafeInteger(meter.denominator)||!meter.groups.length||meter.groups.reduce((s,v)=>s.add(q(v)),Q(0)).cmp(q(meter.numerator)))fail('Meter groups must sum exactly to its numerator');
  const strong=request.strong??strongBeats(meter);if(typeof strong!=='function')fail('Metric predicate required');
  fields(request.rules,['strong','weak','unpreparedDissonance','parallelPerfect','directPerfect','similar','unrecovered','unison','crossing','repeated','leapMost','leaps']);
  // The guard validates the entire scoring-law shape once, before any search or copying could hide a getter.
  control.charge(100);const ruleCheck=auditPlannerHardRules({line:[],against:[],rules:request.rules,strong:()=>false,above:null,bindingWeight:BINDING});
  if(ruleCheck.status!=='PASS')fail(ruleCheck.reason);
  const rules={...request.rules,strong:{...request.rules.strong},weak:{...request.rules.weak}};
  const answer=request.answer??null;
  if(answer){
    fields(answer,['policy','steps','tonic','interval'],['policy']);
    if(!['degrees','tonal-degrees','tonal-when-asked','real'].includes(answer.policy))fail('Unsupported answer policy');
    if(answer.policy==='real')number(answer.interval);else if(!Number.isSafeInteger(answer.steps))fail('Answer degree count required');
    if(answer.tonic!=null)number(answer.tonic);
    if(['tonal-degrees','tonal-when-asked'].includes(answer.policy)&&answer.tonic==null)fail('Tonal policy needs its tonic');
  }
  const base={collection,register,rhythms,meter,rules,answer:answer?{...answer}:null,strong};
  base.occurrences=occurrences(request,base,control);
  if(!answer&&base.occurrences.some(o=>o.entries.some(e=>e.answer)))fail('An answer entry needs its declared answer policy');
  const pitches=ladder(collection,register,control),domains={};
  if(request.domains)fields(request.domains,['S','C']);
  for(const source of ['S','C']){
    const supplied=request.domains?.[source];if(supplied){list(supplied,64);if(supplied.length!==rhythms[source].length)fail('One explicit domain per source note required')}
    rhythms[source].forEach((_,i)=>{
      const values=supplied?list(supplied[i],128).map(number):pitches;
      control.charge(1+values.length);if(values.some(p=>!pitches.includes(p)))fail('Committed pitches must belong to the exact collection/register ladder');
      domains[root(source,i)]=[...new Set(values)];
    });
  }
  base.domains=domains;
  // Snapshot metric decisions on the actual timed occurrences; no callback is consulted during search.
  const zero=Object.fromEntries(['S','C'].map(source=>[source,rhythms[source].map(note=>({...note,pitch:0}))]));
  const timed=materialize(base,zero,control,true),positions=new Map;
  for(const line of Object.values(rhythms))for(const note of line){const value=strong(note.start);if(typeof value!=='boolean')fail('Metric predicate must return Boolean');positions.set(note.start,value)}
  for(const occurrence of timed)for(const part of occurrence.parts)for(const note of part.line){
    control.charge();if(!positions.has(note.start)){const value=strong(note.start);if(typeof value!=='boolean')fail('Metric predicate must return Boolean');positions.set(note.start,value)}
  }
  base.strong=t=>{if(!positions.has(t))fail('Undeclared metric position');return positions.get(t)};
  base.metric=[...positions];
  base.binding=scoped(control,{collection,register,rhythms,meter,rules,answer:base.answer,occurrences:base.occurrences,domains,metric:base.metric});
  return base;
}
function pitchLine(base,line,part,subject){
  let out=line;
  if(part.answer){
    const a=base.answer;
    if(a.policy==='real')out=answerLine(out,{interval:a.interval});
    else{
      let tonal=a.policy==='tonal-degrees';
      if(a.policy==='tonal-when-asked'){
        const interval=stepInCollection(a.tonic,a.steps,base.collection)-a.tonic;
        tonal=fugueAnswers(out,{interval,steps:a.steps,collection:base.collection,tonic:a.tonic}).asks==='tonal';
      }
      out=answerLine(out,{steps:a.steps,collection:base.collection,tonic:a.tonic??null,tonal});
    }
  }else{
    if(part.invert)out=invertedLine(out,{axis:subject[0].pitch,collection:base.collection,degrees:part.invert==='degrees'});
    if(part.steps)out=out.map(note=>({...note,pitch:stepInCollection(note.pitch,part.steps,base.collection)}));
  }
  return out.map(note=>({...note,pitch:number(note.pitch+part.transpose)}));
}
function materialize(base,roots,control,timingOnly=false){
  return base.occurrences.map(occurrence=>{
    const parts=occurrence.entries.map(part=>{
      const source=roots[part.source],origin=source[0].start;
      const moved=timingOnly?source:pitchLine(base,source,part,roots.S);
      const line=moved.map((note,i)=>{
        control.charge();const start=number(origin+(note.start-origin)*part.ratio+part.delay);
        const length=number(occurrence.tempo&&i===moved.length-1?occurrence.tempo.length-start:note.length*part.ratio);
        if(start<0||length<=0)fail('A transformed event has invalid timing');
        return {pitch:note.pitch,start,length};
      });
      return {id:part.id,source:part.source,voice:part.voice,register:part.register,line};
    });
    return {id:occurrence.id,requireOverlap:occurrence.requireOverlap,voiceOrder:occurrence.voiceOrder,tempo:occurrence.tempo??null,parts};
  });
}
function linesOf(occurrence){
  const lines=new Map;
  for(const part of occurrence.parts){if(!lines.has(part.voice))lines.set(part.voice,[]);lines.get(part.voice).push(...part.line)}
  const order=occurrence.voiceOrder??[...lines.keys()];
  return order.map(voice=>({voice,line:lines.get(voice).sort((a,b)=>a.start-b.start)}));
}
function overlap(a,b){return a.some(n=>b.some(m=>q(n.start).cmp(q(m.start).add(q(m.length)))<0&&q(m.start).cmp(q(n.start).add(q(n.length)))<0))}

function familyOf(base,roots,material,control){
  const sources=[],members=[],refs=['metric','tuning','timbre','roots'].map(id=>({id,revision:1}));
  const dependency={request:base.binding,subject:modeled(roots.S),countersubject:modeled(roots.C)};
  for(const occurrence of material){
    const lines=linesOf(occurrence),voices=lines.map(l=>l.voice),parts=[];
    for(const part of occurrence.parts){
      control.charge(part.line.length);const sourceId=`${occurrence.id}.${part.id}`,length=endOf(part.line).toString();
      sources.push({id:sourceId,revision:1,pitchSpace:SPACE,clockDomain:CLOCK,length,
        events:part.line.map((n,i)=>({id:`n${i}`,t:exact(n.start),d:exact(n.length),pitch:SPACE.pitch(exact(n.pitch))}))});
      parts.push({id:part.id,sourceId,voiceId:part.voice,pitchTransform:{id:`${part.id}-pitch`,revision:1,operations:[]},
        timeMap:{id:`${part.id}-time`,revision:1,knots:[{source:'0',target:'0'},{source:length,target:length}]},
        register:{id:`${part.id}-register`,revision:1,low:SPACE.pitch(exact(part.register[0])),high:SPACE.pitch(exact(part.register[1]))}});
    }
    const {rules,...reads}=contractOf(base.rules,{voices,pairs:'all'});
    // Preserve the actual unrounded leap limit, rather than contractOf's legacy milli-cent bound.
    rules.find(r=>r.type==='melodic-bound').maxCents=q(base.rules.leapMost).mul(100).toString();
    const notes=lines.flatMap(l=>l.line),end=endOf(notes),bounds=[...new Map([Q(0),end,...notes.flatMap(n=>[q(n.start),q(n.start).add(q(n.length))])].map(t=>[t.toString(),t])).values()].sort((a,b)=>a.cmp(b));
    const pairs=[];for(let i=0;i<lines.length;i++)for(let j=i+1;j<lines.length;j++)if(overlap(lines[i].line,lines[j].line))pairs.push([voices[i],voices[j]]);
    // Structural N/A is explicit: do not ask a crossing/parallel predicate about two voices that never coexist.
    const profileRules=rules.filter(rule=>!['voice-spacing','parallel-classes','vertical-bands','vertical-apart','approach-bands'].includes(rule.type)||pairs.length);
    for(const rule of profileRules)if(['voice-spacing','parallel-classes'].includes(rule.type))rule.pair=pairs;
    let currentStrong=false;
    const contexts=bounds.slice(0,-1).map((from,i)=>{
      control.charge();const onset=notes.find(n=>q(n.start).eq(from));if(onset)currentStrong=base.strong(onset.start);
      return {id:`cell${i}`,revision:1,from:from.toString(),to:bounds[i+1].toString(),complete:true,data:positionData(currentStrong?'strong':'weak',reads)};
    });
    control.charge(1+notes.length*voices.length+profileRules.length*voices.length*voices.length);
    members.push({id:occurrence.id,revision:1,pitchSpace:SPACE,dependencies:refs,parts,
      environment:{id:`${occurrence.id}-context`,revision:1,complete:true,events:[],contexts},
      profile:compileCounterpointProfile({id:`${occurrence.id}-profile`,version:1,pitchSpace:SPACE,clockDomain:CLOCK,voices,rules:profileRules})});
  }
  return {id:'joint-fugue-family',revision:1,expected:{id:'required-joint-fugue-occurrences',revision:1,complete:true,
    members:members.map(m=>({id:m.id,revision:1,parts:m.parts.map(p=>({id:p.id,sourceId:p.sourceId,voiceId:p.voiceId})),dependencies:refs}))},sources,
    dependencies:[{id:'metric',revision:1,kind:'metric',applicability:'bound',complete:true,data:{meter:base.meter,positions:base.metric,clock:CLOCK}},
      {id:'tuning',revision:1,kind:'tuning',applicability:'bound',complete:true,data:{collection:base.collection,pitchSpace:SPACE.hash,semantics:'original-Number-decimal'}},
      {id:'timbre',revision:1,kind:'timbre',applicability:'not-applicable',complete:true,data:{reason:'This first slice certifies symbolic pitch/time and current planner hard rules only'}},
      {id:'roots',revision:1,kind:'other',applicability:'bound',complete:true,data:dependency}],members};
}

const certificateOptions=allowance=>({maxWork:allowance,maxProfileWork:20000,maxSliceWork:10000});
function auditCandidate(base,roots,control,certificate=null){
  const material=materialize(base,roots,control),guards=[];
  for(const source of ['S','C']){
    control.charge(100+8*roots[source].length*roots[source].length);
    const result=auditPlannerHardRules({line:roots[source],against:[],rules:base.rules,strong:base.strong,above:null,bindingWeight:BINDING});
    if(result.status==='FAIL')return result;if(result.status!=='PASS')control.refuse(result.reason);
    guards.push({occurrence:'source',voice:source,...result});
  }
  for(const occurrence of material){
    const lines=linesOf(occurrence),count=lines.reduce((n,l)=>n+l.line.length,0);
    // Includes the guard's repeated partner scans, sorting, exact binding and hashing; a conservative work charge.
    control.charge(100+8*count*count);
    if(occurrence.requireOverlap&&!lines.some((a,i)=>lines.slice(i+1).some(b=>overlap(a.line,b.line))))return {status:'FAIL',reason:'Required overlap is absent'};
    if(occurrence.tempo){
      const {at,length,group}=occurrence.tempo;
      if(occurrence.parts.some((part,i)=>part.line.at(-1).start!==at||!endOf(part.line).eq(q(length))||
        i&&q(part.line[0].start).sub(q(occurrence.parts[i-1].line[0].start)).cmp(q(group))<0))return {status:'FAIL',reason:'Realized tempo-canon convergence, hold or entry gap fails'};
    }
    for(const part of occurrence.parts){
      if(part.line.some(n=>n.pitch<part.register[0]||n.pitch>part.register[1]))return {status:'FAIL',reason:'Transformed register violation'};
      if(checkPlannerLineBinding(part.line,modeled(part.line)).status!=='PASS')control.refuse('Final Number binding refused');
    }
    for(const item of lines){
      const result=auditPlannerHardRules({line:item.line,against:lines.filter(other=>other!==item).map(other=>other.line),rules:base.rules,strong:base.strong,above:null,bindingWeight:BINDING});
      if(result.status==='FAIL')return result;if(result.status!=='PASS')control.refuse(result.reason);
      guards.push({occurrence:occurrence.id,voice:item.voice,...result});
    }
  }
  const spec=familyOf(base,roots,material,control);
  const ready=control.bounded(DISPOSITION_LIMITS.maxWork,maxWork=>prepareDispositionFamily(spec,{maxWork}));
  if(ready.status!=='PASS')control.refuse(ready.reason);
  // (Choosing, its family audited: the constraint the search accepts by. A certificate given -- a test replaying a found
  // pair (checkJointFugueTheme) -- checked instead; never checked again while the music is made.)
  let cert=certificate;
  if(!cert){
    const audited=control.bounded(DISPOSITION_LIMITS.maxWork,max=>auditDispositionFamily(ready.prepared,certificateOptions(max)));
    if(audited.status==='FAIL')return audited;if(audited.status!=='PASS')control.refuse(audited.reason);
    cert=audited.certificate;
  }else{
    const checked=control.bounded(DISPOSITION_LIMITS.maxWork,max=>checkDispositionFamily(ready.prepared,cert,certificateOptions(max)));
    if(checked.status==='FAIL')return checked;if(checked.status!=='PASS')control.refuse(checked.reason);
  }
  const occurrences=material.map(o=>({id:o.id,parts:o.parts.map(p=>({id:p.id,source:p.source,voice:p.voice,line:p.line,exact:modeled(p.line)}))}));
  const witness={requestHash:base.binding,rootHash:scoped(control,{S:modeled(roots.S),C:modeled(roots.C)}),
    occurrences,guards,family:{prepared:ready.prepared,certificate:cert}};
  control.charge(1+occurrences.reduce((n,o)=>n+o.parts.reduce((m,p)=>m+p.line.length,0),0));
  return {status:'PASS',witness};
}
function rootsOf(base,assignment,catalogue){
  return Object.fromEntries(['S','C'].map(s=>[s,base.rhythms[s].map((note,i)=>({...note,pitch:catalogue[assignment[root(s,i)]]}))]));
}
function buildSearch(request,control){
  const base=normalize(request,control),catalogue=[...new Set(Object.values(base.domains).flat())].sort((a,b)=>a-b);
  const model=makeModel(Object.fromEntries(Object.entries(base.domains).map(([r,values])=>[r,values.map(p=>catalogue.indexOf(p))]))),hint={};
  for(const s of ['S','C'])for(let i=1;i<base.rhythms[s].length;i++){
    control.charge();addConstraint(model,`leap-${s}-${i}`,[root(s,i-1),root(s,i)],([a,b])=>{
      if(core){const within=core.leapWithin(catalogue[a],catalogue[b],base.rules.leapMost);if(within!==null)return within}
      const d=q(catalogue[a]).sub(q(catalogue[b]));return (d.cmp(0)<0?Q(0).sub(d):d).cmp(q(base.rules.leapMost))<=0;
    });
  }
  // Unary/axis-dependent register pullbacks are cheap, sound necessary conditions. Tonal heads depend on a whole
  // prefix, so their maps stay in the residual predicate rather than causing exponential GAC tuple tables.
  for(const occurrence of base.occurrences)for(const part of occurrence.entries){
    if(part.answer&&['tonal-degrees','tonal-when-asked'].includes(base.answer.policy))continue;
    base.rhythms[part.source].forEach((_,i)=>{
      control.charge();const r=root(part.source,i),axis=root('S',0),scope=[...new Set([r,...(part.invert?[axis]:[])])];
      addConstraint(model,`register-${occurrence.id}-${part.id}-${i}`,scope,values=>{
        const pitch=catalogue[values[scope.indexOf(r)]],centre=part.invert?catalogue[values[scope.indexOf(axis)]]:pitch;
        const actual=pitchLine(base,[{pitch,start:0,length:1}],part,[{pitch:centre}])[0].pitch;
        return actual>=part.register[0]&&actual<=part.register[1];
      });
    });
  }
  if(request.hints){
    fields(request.hints,['S','C']);
    for(const s of ['S','C'])for(const line of list(request.hints[s]??[],3)){
      list(line,64);line.forEach((note,i)=>{
        control.charge();if(!dataRecord(note)||i>=base.rhythms[s].length)return;
        const pitch=number(note.pitch),r=root(s,i),value=catalogue.indexOf(pitch);
        if(base.domains[r].includes(pitch)){hint[r]??=[];if(!hint[r].includes(value))hint[r].push(value)}
      });
    }
  }
  return {base,catalogue,model,hint,accepted:null};
}

export function jointFugueTheme(request){
  let options;try{options=jointFugueBudget(request?.budget)}catch(error){return {status:'UNKNOWN',subject:null,countersubject:null,witnesses:null,reason:error.message}}
  // (How many pairs the caller's own constraint passed over: said with what it found, so that a search that finds none
  // says why.)
  let declined=0;
  const result=runBudgetedFinite({
    build:control=>buildSearch(request,control),
    accept(assignment,built,control){
      // (The caller's own constraint on a pair first, `accepts(subject, countersubject)`: its listeners' tolerance of
      // repetition, applied as the search chooses -- not a verdict on the pair it found.)
      const roots=rootsOf(built.base,assignment,built.catalogue);
      if(typeof request.accepts==='function'&&!request.accepts(roots.S,roots.C)){declined++;return false}
      const checked=auditCandidate(built.base,roots,control);
      if(checked.status!=='PASS')return false;built.accepted={roots,witnesses:checked.witness};return true;
    },
    publish(assignment,built,control){
      control.charge(1+Object.keys(assignment).length);const {roots,witnesses}=built.accepted;
      return {subject:roots.S,countersubject:roots.C,witnesses};
    }
  },options);
  const {assignment,...out}=result;
  return result.status==='SAT'?{...out,declined}:{...out,subject:null,countersubject:null,witnesses:null,declined};
}

// Reconstruct from the caller's actual requirement inventory and returned root notes. A prepared family by itself
// proves its materialized sources; this additional replay is what binds degree/tonal maps to ONE common S and C.
export function checkJointFugueTheme(request,result,{budget=request?.budget}={}){
  if(result?.status!=='SAT')return {status:'FAIL',reason:'No published joint witness'};
  if(!result.witnesses?.family?.certificate)return {status:'FAIL',reason:'Whole-family certificate is missing'};
  let options;try{options=jointFugueBudget(budget)}catch(error){return {status:'UNKNOWN',reason:error.message}}
  const checked=runBudgetedFinite({
    build(control){
      const base=normalize(request,control),roots={S:result.subject,C:result.countersubject};
      for(const s of ['S','C']){
        list(roots[s],64);if(roots[s].length!==base.rhythms[s].length)fail('Source note count changed');
        roots[s].forEach((note,i)=>{
          control.charge();fields(note,['pitch','start','length'],['pitch','start','length']);
          if(!base.domains[root(s,i)].includes(number(note.pitch))||note.start!==base.rhythms[s][i].start||note.length!==base.rhythms[s][i].length)fail('Returned root note changed domain or rhythm');
        });
      }
      return {base,roots,model:makeModel({}),accepted:null};
    },
    accept(_,built,control){
      const audited=auditCandidate(built.base,built.roots,control,result.witnesses?.family?.certificate);
      if(audited.status!=='PASS')return false;
      const original=result.witnesses,actual=audited.witness;
      control.charge(1+Math.ceil(pythonJson(actual.occurrences).length/64));
      if(!original||original.requestHash!==actual.requestHash||original.rootHash!==actual.rootHash||pythonJson(original.occurrences)!==pythonJson(actual.occurrences)||pythonJson(original.guards)!==pythonJson(actual.guards))return false;
      built.accepted=audited;return true;
    },
    publish:()=>({})
  },options);
  return {status:checked.status==='SAT'?'PASS':checked.status==='UNSAT'?'FAIL':'UNKNOWN',reason:checked.reason,stats:checked.stats};
}
