// A canon planned for performers to play as written: groundwork for the canons and fugues a conductor plans (Musebots
// 3.0, docs/MUSEBOTS_3.md; the owner, 30 September 2026: "if no other stimulus intervenes, the bots will simply decide on a
// plan and play it. (This should allow them eventually to plan and play fugues and canons.)").
//
// A canon is one line sounded by several voices, each entering after its delay, transposed, in its augmentation
// (pitch-languages/canon.js). Planned whole, each voice's notes are placed in the piece's bars, across its changes of
// meter, and sent to one performer as a plan of kind 'part' (planning.js), which it plays as written (bots/lib/modules/
// part-plans.js). A voice's answer may be real (every interval kept, in floating semitones) or tonal (moved by degrees
// of a collection, each note's own inflection kept: a fugue's answer), in any tuning: the collection is pitches, and a
// pitch between its members keeps its distance from the nearest.
//
// Time is in quarter notes from the canon's first bar, placed by each bar's meter (a bar of n/d is 4n/d quarters, and
// a quarter is subdivision x d / 4 of its pulses), so a canon runs on through a change of meter as written.
import {canon} from '../pitch-languages/canon.js';
import {bandMeter} from '../opening-time.js';
import {counterLine,ladderOf,strongBeats} from './counterpoint.js';

const fail=message=>{throw new RangeError(message)};
const modulo=(x,n)=>((x%n)+n)%n;
// stepInCollection, invertedLine and subjectFrom run faster where a core is installed (shared/musical-core.js: their
// Rust port, the same pitches from the same inputs and draws; research/RUST_PORT_STATE.md). It declines (null) what it
// does not take, before it draws anything, and they are made here as ever. -> the core it replaced.
let core=null;
export function useCanonCore(given=null){const previous=core;core=given;return previous}

// The meter in force at each bar, from a piece plan's units ({startBar, endBar, numerator, denominator, subdivision}),
// else `meter`. -> bar -> {numerator, denominator, subdivision}
export function meterOfBar(units=[],meter={numerator:4,denominator:4,subdivision:4}){
  return bar=>{
    const unit=units.find(item=>item.startBar<=bar&&bar<item.endBar);
    const source=unit&&Number.isInteger(unit.numerator)?unit:meter;
    return {numerator:source.numerator,denominator:source.denominator,subdivision:source.subdivision??bandMeter().subdivision};
  };
}
const quartersOf=m=>m.numerator*4/m.denominator,pulsesPerQuarter=m=>m.subdivision*m.denominator/4;
// Quarters from `startBar`'s downbeat -> {bar, pulse} in that bar's meter (the nearest pulse), or null past `endBar`.
export function placeQuarters(quarters,{startBar=0,endBar=Infinity,meterAt}){
  let bar=startBar,left=quarters;
  for(let guard=0;guard<100000;guard++){
    if(bar>=endBar)return null;
    const m=meterAt(bar),length=quartersOf(m);
    if(left<length-1e-9){const pulse=Math.round(left*pulsesPerQuarter(m));
      return pulse>=m.numerator*m.subdivision?{bar:bar+1,pulse:0}:{bar,pulse}}
    left-=length;bar++;
  }
  fail('A canon too long to place');
}
// A pitch moved by `steps` degrees of a collection (pitches, any tuning, repeating at `period` semitones), keeping its
// distance from the nearest member: a tonal answer.
export function stepInCollection(pitch,steps,collection,period=12){
  if(core){const moved=core.stepInCollection(pitch,steps,collection,period);if(moved!=null)return moved}
  // (Its classes as given, one of each: a pitch keeps every decimal of its tuning.)
  const classes=[];for(const p of collection.map(p=>modulo(p,period)).sort((a,b)=>a-b))if(!classes.some(c=>Math.abs(c-p)<1e-9))classes.push(p);
  const n=classes.length;
  if(!n)fail('A tonal answer needs a collection');
  // The collection's pitches from the octave below the pitch's to the octave above: degree i is octave (low + i / n).
  const low=Math.floor(pitch/period)-1,ladder=[];
  for(let octave=low;octave<=low+2;octave++)for(const c of classes)ladder.push(octave*period+c);
  let nearest=0;for(let i=1;i<ladder.length;i++)if(Math.abs(ladder[i]-pitch)<Math.abs(ladder[nearest]-pitch))nearest=i;
  const degree=nearest+steps;
  return (low+Math.floor(degree/n))*period+classes[modulo(degree,n)]+(pitch-ladder[nearest]);
}
// A line's transformations (the owner, 3 October 2026: "There are also transformations of motifs/themes; including not
// just transposition but augmentation, diminution (rhythm, possibly related to stretching and compressing but definitely
// not in the rubato layer) and inversion and retrograde"), each a line ([{pitch, start, length}], quarters) from its
// first note's start, written: an augmentation's notes are written longer, never played slower.
// Augmented by `ratio` (below 1, diminished): every start from the line's first and every length times it.
export function augmentedLine(line,ratio){
  const origin=line[0]?.start??0;
  return line.map(note=>({...note,start:origin+(note.start-origin)*ratio,length:note.length*ratio}));
}
// Inverted about `axis` (a pitch): by the collection's degrees -- each note as many degrees the other side of the axis,
// its own inflection from its degree turned with it, as a tonal answer keeps one (stepInCollection) -- or, `degrees`
// false, exactly: each interval from the axis in cents turned.
export function invertedLine(line,{axis=line[0]?.pitch,collection=null,degrees=true,period=12}={}){
  if(core){const turned=core.invertedLine(line,{axis,collection,degrees,period});if(turned)return turned}
  if(!degrees||!collection?.length)return line.map(note=>({...note,pitch:2*axis-note.pitch}));
  const classes=[];for(const p of collection.map(p=>modulo(p,period)).sort((a,b)=>a-b))if(!classes.some(c=>Math.abs(c-p)<1e-9))classes.push(p);
  const n=classes.length;
  // (A pitch's degree, counted from the octave below the axis's, and its inflection from it.)
  const low=Math.floor(axis/period)-2,degreeOf=pitch=>{
    let best=null;for(let octave=low;octave<=low+5;octave++)classes.forEach((c,i)=>{const at=octave*period+c,off=pitch-at;if(!best||Math.abs(off)<Math.abs(best.off))best={degree:(octave-low)*n+i,off}});
    return best;
  };
  const centre=degreeOf(axis);
  return line.map(note=>{const {degree,off}=degreeOf(note.pitch),turned=2*centre.degree-degree;
    return {...note,pitch:(low+Math.floor(turned/n))*period+classes[modulo(turned,n)]-off+2*centre.off}});
}
// Its retrograde: its notes from the last to the first, each ending where the one it mirrors began, from the line's start.
export function retrogradeLine(line){
  if(!line.length)return [];
  const origin=line[0].start,end=Math.max(...line.map(note=>note.start+note.length));
  return [...line].reverse().map(note=>({...note,start:origin+end-(note.start+note.length)}));
}
// A subject drawn for a canon from what the conductor has: its collection (pitches), a register, the meter's groups
// (felt beats) and a number of bars; its rhythm a note a group, now and then a group split in two; its line by step
// through the collection, now and then a leap of a third of it, from its first degree back to it -- the register's
// middle, or, given an `axis` (pitch classes: a tonal subject's tonic and dominant), one of its classes drawn, each
// nearest the middle. random: [0, 1). -> [{pitch, start, length}] in quarters.
export function subjectFrom({collection,register={low:60,high:79},groups=[3,2,2],denominator=8,bars=2,random=Math.random,split=.4,leap=.2,axis=null}={}){
  if(core){const drawn=core.subjectFrom({collection,register,groups,denominator,bars,random,split,leap,axis});if(drawn)return drawn}
  if(!Array.isArray(collection)||!collection.length)fail('A subject is drawn from a collection');
  const ladder=[];
  for(let octave=Math.floor(register.low/12)-1;octave<=Math.ceil(register.high/12)+1;octave++)
    for(const p of collection)ladder.push(octave*12+modulo(p,12));
  const steps=[...new Set(ladder.map(p=>+p.toFixed(6)))].filter(p=>p>=register.low&&p<=register.high).sort((a,b)=>a-b);
  if(steps.length<3)fail('A subject needs three of the collection\'s pitches within its register');
  const middle=(register.low+register.high)/2,nearest=indices=>indices.reduce((best,i)=>best<0||Math.abs(steps[i]-middle)<Math.abs(steps[best]-middle)?i:best,-1);
  const on=Array.isArray(axis)?axis.map(c=>nearest(steps.flatMap((p,i)=>Math.abs(modulo(p-c+.5,12)-.5)<1e-3?[i]:[]))).filter(i=>i>=0):[];
  const home=on.length?on[Math.floor(random()*on.length)]:nearest(steps.map((_,i)=>i));
  // (Its rhythm in whole units of the meter's note, each time a whole count of them times four divided by its
  // denominator once: added in floating point, a tenth's 0.4 three times had been 1.2000000000000002, and a certificate
  // reading each number as written found a note overrunning the next by 2e-16.)
  const units=[];
  for(let bar=0;bar<bars;bar++)for(const group of groups){
    if(group>1&&random()<split){const first=Math.max(1,Math.round(group/2));units.push(first,group-first)}else units.push(group);
  }
  let at=home,start=0;const line=[];
  for(const [i,count] of units.entries()){
    if(i===units.length-1)at=home;
    else if(i>0){const size=random()<leap?Math.max(2,Math.round(steps.length/3)):1,direction=random()<.5?-1:1;
      at=Math.max(0,Math.min(steps.length-1,at+direction*size))}
    line.push({pitch:steps[at],start:start*4/denominator,length:count*4/denominator});start+=count;
  }
  return line;
}
// Each voice's line as it sings the subject (canonParts' moves: a transposition, a tonal answer by the collection's
// degrees, the inversion), from its own entry. -> [[{pitch, start, length}]], one a voice.
export function voiceLines({subject,voices,collection=null}){
  const within=collection??subject.map(item=>item.pitch);
  return voices.map(voice=>subject.map(note=>{const base=note.pitch+(voice.steps?0:Number(voice.transpose)||0);
    return {start:note.start,length:note.length,pitch:voice.invert?invertedLine([{pitch:base}],{axis:subject[0].pitch,collection:within,degrees:true})[0].pitch
      :voice.steps?stepInCollection(base,voice.steps,within):base}}));
}
// A subject planned for its canon (counterpoint.js): its rhythm drawn as subjectFrom draws it, its pitches planned against
// its own later voices -- `voices` as canonParts takes them, each delayed and moved, a tonal answer by the collection's
// degrees, or any `map` of its pitches, `invert` (about its first pitch, by the collection's degrees) and `ratio` of its
// times (an augmentation) -- under `rules`, its
// first pitch the drawn subject's. -> [{pitch, start, length}] in quarters.
// `cycle` (quarters): a round's period, its subject's way back into its first note weighed against its own later voices
// there too (counterLine's toward), and each voice against the cycle before of the voices ahead of it. Every two of its
// voices are weighed together, its later voices too, each pair whose earlier voice is only transposed (counterLine's
// relations): planned against its first voice alone, a canon of three voices or more had left its later voices in
// parallels between themselves.
export function plannedSubject({collection,register={low:60,high:79},groups=[3,2,2],numerator=null,denominator=8,bars=2,random=Math.random,voices=[],rules,cycle=null,...shape}={}){
  const drawn=subjectFrom({collection,register,groups,denominator,bars,random,...shape});
  const steps=ladderOf(collection,register),strong=strongBeats({numerator:numerator??groups.reduce((a,b)=>a+b,0),denominator,groups});
  // (An inverted voice about the drawn subject's first pitch, by the collection's degrees.)
  const axis=drawn[0].pitch,inverted=pitch=>invertedLine([{pitch}],{axis,collection,degrees:true})[0].pitch;
  const self=voices.filter(voice=>voice.delay>0).map(({delay,transpose=0,steps:degrees=0,map=null,invert=false,ratio=null,augmentation=1})=>({delay,ratio:ratio??augmentation,...(map?{map}:invert?{map:inverted}:degrees?{map:pitch=>stepInCollection(pitch,degrees,collection)}:{transpose})}));
  // (Each voice's frame: its delay, its stretch, its transposition where it is only transposed, and how it moves a pitch.)
  const frames=voices.map(({delay=0,transpose=0,steps:degrees=0,map=null,invert=false,ratio=null,augmentation=1})=>({delay,ratio:ratio??augmentation,
    shift:map||invert||degrees?null:transpose,move:map??(invert?inverted:degrees?pitch=>stepInCollection(pitch,degrees,collection):pitch=>pitch+transpose)}));
  const relations=[],known=new Set(self.filter(voice=>!voice.map&&voice.ratio===1).map(voice=>`${voice.delay}:${voice.transpose}`));
  const add=relation=>{const key=relation.map?null:`${relation.delay}:${relation.transpose}`;if(key&&known.has(key))return;if(key)known.add(key);relations.push(relation)};
  for(const [i,a] of frames.entries())for(const b of frames){
    const gap=b.delay-a.delay;if(a.shift==null||a.ratio!==1||b.ratio!==1||!(gap>1e-9))continue;
    if(i>0)add(b.shift!=null?{delay:gap,transpose:b.shift-a.shift}:{delay:gap,map:pitch=>b.move(pitch)-a.shift});
    if(cycle>0&&b.shift!=null)add({delay:cycle-gap,transpose:a.shift-b.shift});
  }
  return counterLine({rhythm:drawn.map(({start,length})=>({start,length})),steps,rules,strong,random,self,relations,start:drawn[0].pitch,
    ...(cycle>0?{toward:{pitch:drawn[0].pitch,start:cycle,length:drawn[0].length,withSelf:true}}:{})}).line;
}
// The voices' part plans: `subject` ([{pitch, start, length}] in quarters), `voices` ([{part (who plays it), delay
// (quarters), transpose (semitones: a real answer), steps (degrees of `collection`: a tonal answer), invert (its
// inversion about the subject's first pitch by the collection's degrees: a canon at the inversion), augmentation}]),
// placed from `startBar` by the units' meters, and cut at `endBar`. A round (`period`, quarters, and `cycles`, how many
// whole times each voice sings it): each voice's subject again every period after its entry, that many times.
// -> [{part, voice, delay, transpose, steps, invert?, augmentation, cycles?, fromBar, toBar, notes: [{bar, pulse,
// quarters (its length), pitch, index}]}], one a voice.
export function canonParts({subject,voices,startBar=0,endBar=Infinity,units=[],meter,collection=null,velocity=.6,period=null,cycles=null}={}){
  if(!Array.isArray(voices)||voices.length<2)fail('A canon has two voices or more');
  const meterAt=meterOfBar(units,meter);
  const lines=canon(subject,voices.map(voice=>({delay:voice.delay??0,transpose:voice.steps?0:voice.transpose??0,augmentation:voice.augmentation??1})));
  return lines.map((line,v)=>{
    const voice=voices[v],notes=[],times=period>0&&Array.isArray(cycles)?Math.max(1,cycles[v]??1):1;
    for(let cycle=0;cycle<times;cycle++)for(const original of line.notes){const note=cycle?{...original,start:original.start+cycle*period}:original;
      const at=placeQuarters(note.start,{startBar,endBar,meterAt});if(!at)continue;
      const within=collection??subject.map(item=>item.pitch),pitch=voice.invert?invertedLine([{pitch:note.pitch}],{axis:subject[0].pitch,collection:within,degrees:true})[0].pitch
        :voice.steps?stepInCollection(note.pitch,voice.steps,within):note.pitch;
      notes.push({bar:at.bar,pulse:at.pulse,quarters:+note.length.toFixed(6),pitch,index:note.index,velocity});
    }
    return {part:String(voice.part),voice:v,delay:voice.delay??0,transpose:voice.transpose??0,steps:voice.steps??0,...(voice.invert?{invert:true}:{}),augmentation:voice.augmentation??1,
      ...(times>1?{cycles:times}:{}),fromBar:notes[0]?.bar??startBar,toBar:(notes.at(-1)?.bar??startBar)+1,notes};
  });
}
