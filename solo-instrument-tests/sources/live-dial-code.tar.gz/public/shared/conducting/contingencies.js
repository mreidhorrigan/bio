// A conductor's contingency plans: what it will do instead of its plan, prepared when it commits a section, if the
// people it plays with turn out otherwise than it planned for (Musebots 3.0, docs/MUSEBOTS_3.md; the owner, 30 September
// 2026: "make sure plex_clodbot (and other relevant bots) have contingency plans if other bots (e.g., a profile_clodbot
// representing a human player or ensemble) input new information").
//
// Committing a section, a conductor prepares its alternatives with it: each a change to the section as planned and a
// guard over what the people's profiles say (profile_clodbot's /broadcast/profile), in the overplan guard language
// (overplan-guards.js: and, or, not, present, comparisons; three-valued). It says them in its plan, so the band knows
// what may come as far ahead as the section. At the hand-over it reads the profiles as they stand and takes each
// alternative whose guard holds: no redrawing and no reopening, only a choice among what was prepared (CLAUDE.md,
// "Feasible by construction"). What it cannot read is unknown -- no profile heard, one gone quiet past its grace (its
// host dropped, its connection lost), a value not said -- and the unknown keeps the plan.
//
// The inputs, from the profiles live (heard within the grace), taken together as the band hears them:
//   heard          boolean  anyone heard at all
//   present        boolean  anyone playing
//   activity       number   the busiest one's activity, 0 to 1
//   silentSeconds  number   since anyone's last attack (absent before any)
//   tempo          number   the lead's tempo in the band's beat, BPM (absent where untracked): the lead is the one who
//                           says it leads, else the busiest playing
//   released       boolean  the lead asks to be followed loosely as a cadenza ('released')
//   leads          boolean  anyone's harmony leads the band's
// With foresight (a render that knows a recording before it sounds), a profile also says what the person will play
// (profile_clodbot's ahead), and a conductor choosing a section's contingencies reads them over that section: present,
// whether they play in it; activity, how busy over it; silentSeconds, the longest they rest in it (to its end, where
// their recording ends before); heard, known ahead. Planned for, a section is the person's as they will be in it, not
// as they were a moment before it (the tempo and the rest as they stand).
import {validateGuard,evaluateGuard,UNKNOWN} from '../overplan-guards.js';
import {ELECTION} from './election.js';

// Ours: a person playing eighths in any beat or more is busy (a profile's activity: attacks a beat against four).
export const BUSY=.5;
export const PROFILE_INPUTS=Object.freeze([
  {name:'heard',type:'boolean'},{name:'present',type:'boolean'},{name:'activity',type:'number'},{name:'silentSeconds',type:'number'},
  {name:'tempo',type:'number'},{name:'released',type:'boolean'},{name:'leads',type:'boolean'},
].map(Object.freeze));
const NAMES=PROFILE_INPUTS.map(input=>input.name);

// ---- The profiles heard ---------------------------------------------------------------------------------------------
export class Profiles{
  // graceBars: a profile not heard for longer has gone (a profile is said at each felt group, several a bar).
  constructor({graceBars=ELECTION.graceBars}={}){this.graceBars=graceBars;this.byVoice=new Map}
  // A profile (its payload) heard at a bar of the listener's own clock.
  hear(profile,bar){
    if(!profile||typeof profile.voice!=='string'||!profile.voice)return false;
    this.byVoice.set(profile.voice,{profile,bar:Number(bar)||0});return true;
  }
  forget(voice){this.byVoice.delete(voice)}
  get size(){return this.byVoice.size}
  voices(){return [...this.byVoice.keys()]}
  live(bar){return [...this.byVoice.values()].filter(entry=>Number(bar)-entry.bar<=this.graceBars).map(entry=>entry.profile)}
  // The one the band follows: who says they lead, else the busiest playing, else none.
  lead(bar){
    const playing=this.live(bar).filter(profile=>profile.present);
    return playing.find(profile=>profile.leading)??playing.sort((a,b)=>(b.activity??0)-(a.activity??0))[0]??null;
  }
  // The inputs as the guard language reads them: {inputs: [{name, state: 'known'|'absent'|'unknown', value}], voices};
  // over `span` ({from, to, beatSeconds}, render seconds: a section to come), each profile that says what is ahead read
  // over it (foreseen), and the span read said (foreseen: {from, to}).
  snapshot(bar,{span=null}={}){
    const live=this.live(bar).map(profile=>foreseen(profile,span)),read=live.find(profile=>profile.foreseen)?.foreseen;
    if(!live.length)return {inputs:NAMES.map(name=>({name,state:'unknown',value:null})),voices:[]};
    const heard=live.filter(profile=>profile.heard),lead=this.lead(bar);
    const silent=heard.map(profile=>profile.silentSeconds).filter(Number.isFinite);
    const tempo=Number(lead?.tempo?.beatsBpm);
    const known=(name,value)=>({name,state:'known',value}),absent=name=>({name,state:'absent',value:null});
    return {voices:live.map(profile=>profile.voice),inputs:[
      known('heard',heard.length>0),known('present',live.some(profile=>profile.present)),
      known('activity',Math.max(0,...heard.map(profile=>Number(profile.activity)||0))),
      silent.length?known('silentSeconds',Math.min(...silent)):absent('silentSeconds'),
      tempo>0?known('tempo',tempo):absent('tempo'),
      known('released',lead?.coordination==='released'),
      known('leads',live.some(profile=>profile.harmony?.leads)),
    ],...(read?{foreseen:read}:{})};
  }
  // Whether everyone heard has gone: not heard within the grace, or stopped and silent at least `seconds` (a phrase, as
  // the conductor counts it). False where nobody was heard.
  gone(bar,{seconds=0}={}){
    if(!this.byVoice.size)return false;
    const live=new Set(this.live(bar));
    return [...this.byVoice.values()].every(({profile})=>!live.has(profile)||profile.stopped&&Number(profile.silentSeconds)>=seconds);
  }
}

// A profile read over a span to come (render seconds; beatSeconds the band's beat there) from what it says is ahead:
// the attacks in it a beat against those it says are fully busy (as profile_clodbot hears activity), its longest rest between its start,
// the attacks and its end. A profile with nothing ahead, or a span past what it says, is as it stands.
export function foreseen(profile,span){
  const ahead=profile?.ahead;
  if(!span||!Array.isArray(ahead?.attacks)||!(span.beatSeconds>0))return profile;
  const from=Math.max(span.from,ahead.at),to=Math.min(span.to,ahead.through);if(!(to>from))return profile;
  const attacks=ahead.attacks.filter(at=>at>=from&&at<to),marks=[from,...attacks,to];
  let rest=0;for(let k=1;k<marks.length;k++)rest=Math.max(rest,marks[k]-marks[k-1]);
  const round=value=>Math.round(value*1000)/1000;
  return {...profile,heard:Boolean(profile.heard||ahead.attacks.length),present:attacks.length>0,
    activity:round(Math.min(1,attacks.length*span.beatSeconds/(to-from)/Math.max(1,Number(ahead.busy)||1))),silentSeconds:round(rest),foreseen:{from:round(from),to:round(to)}};
}

// ---- Contingencies ----------------------------------------------------------------------------------------------------
// An alternative as prepared: {id, guard (over PROFILE_INPUTS), section (fields changed: a value, or {input, low, high,
// step} for an input's value as it stands at the choice), previous (fields taken from the section before, as it was
// handed over), constraints (ranges replacing the section's), reason}. -> the same, checked and plain.
export function checkedContingency({id,guard,section={},previous=[],constraints=null,reason=''}){
  if(typeof id!=='string'||!/^[a-z][a-z0-9-]*$/.test(id))throw new TypeError('A contingency has an id');
  for(const value of Object.values(section))if(value&&typeof value==='object'&&!Array.isArray(value)&&'input' in value&&!NAMES.includes(value.input))
    throw new TypeError(`A contingency reads a profile's input (${NAMES.join(', ')})`);
  return {id,guard:validateGuard(guard,PROFILE_INPUTS),...(Object.keys(section).length?{section:structuredClone(section)}:{}),
    ...(previous.length?{previous:[...previous]}:{}),...(constraints?{constraints:structuredClone(constraints)}:{}),reason:String(reason).slice(0,240)};
}
// The alternatives whose guards hold over a snapshot, in the order prepared (a later one's change wins where two touch
// the same field). -> {taken: [id], results: [{id, result: true|false|'unknown'}]}
export function chooseContingencies(alternatives=[],snapshot){
  const results=alternatives.map(alternative=>({id:alternative.id,result:evaluateGuard(alternative.guard,snapshot)}));
  return {taken:results.filter(item=>item.result===true).map(item=>item.id),results};
}
const inputValue=(snapshot,name)=>snapshot.inputs.find(input=>input.name===name&&input.state==='known')?.value;
function resolved(value,snapshot){
  if(!value||typeof value!=='object'||Array.isArray(value))return value;
  if('input' in value){
    const raw=Number(inputValue(snapshot,value.input)),step=Number(value.step)||0;
    if(!Number.isFinite(raw))return undefined;
    const clamped=Math.max(Number.isFinite(value.low)?value.low:-Infinity,Math.min(Number.isFinite(value.high)?value.high:Infinity,raw));
    return step>0?Math.round(clamped/step)*step:clamped;
  }
  const out={};for(const [key,item] of Object.entries(value)){const v=resolved(item,snapshot);if(v!==undefined)out[key]=v}
  return out;
}
// A section with the alternatives taken: each one's fields from the section before, then its own (an object merged
// into the section's, one level down: a tempo's target alone). -> {section, constraints}
export function applyContingencies(section,taken=[],{snapshot,previous=null,constraints=null}={}){
  let out={...section},bounds=constraints?{...constraints}:null;
  for(const alternative of taken){
    for(const key of alternative.previous??[])if(previous&&key in previous)out[key]=structuredClone(previous[key]);
    for(const [key,value] of Object.entries(resolved(alternative.section??{},snapshot)))
      out[key]=value&&typeof value==='object'&&!Array.isArray(value)&&out[key]&&typeof out[key]==='object'&&!Array.isArray(out[key])?{...out[key],...value}:value;
    if(alternative.constraints)bounds={...(bounds??{}),...structuredClone(alternative.constraints)};
  }
  return {section:out,constraints:bounds};
}
export {UNKNOWN};
