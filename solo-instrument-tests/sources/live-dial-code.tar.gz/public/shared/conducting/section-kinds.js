// What the conductorbot decides for a section, by the section's kind: one conductor, given a specification for each kind
// of section it may lead (the owner, 1 October 2026: "we should likely have one conductorbot type, to the extent
// possible, that then receives different sets of per-section-type constraint as a kind of specification"). plex_clodbot
// leads a section where its spec names one (settings.section: {kind, ...the kind's choices, specification}): its group,
// its members, and a formation a phrase, decided within the constraints from the groups above it (groups.js
// constraintsFor, in the kind's vocabulary) and its own, drawn from the kind's specification (a spec's replacing any
// part of it), and said on /broadcast/group/formation for its players, who each play their own part of it (a bowed
// string's seat: bots/lib/modules/section-seat.js). Nothing here sounds: a section's players do.
//
// A kind: {id, group(spec) -> its group's id, members(spec) -> its seats' ids, vocabulary (the constraints it honours,
// as constraintsFor reads them), checked(value) -> its spec (fixed choices and specification checked), decide({bar,
// bars, previous, constraints, bound, random, spec}) -> {formation, move}, summary(formation) -> a line}.
import {SEATING_PLANS,seatPositions,seatImage,stageReference,farthestOf} from './seating.js';
import {techniquesOf} from '../performers/techniques.js';
// A formation's coordinated hit (plex_clodbot PLEX_CLODBOT.punctuation; coordinated-events.js): every pool, resting or
// not and every one of its players, struck together at the event's level, held its beats, its players' own timing
// within its spread. -> the formation.
const struckBy=(formation,event)=>({...formation,pools:formation.pools.map(({playing,...pool})=>({...pool,texture:'hit',level:Number(event.level),
  parameters:{beats:Number(event.beats),spread:Number(event.spread),event:String(event.id),...(Number.isFinite(event.pitch)?{pitch:Number(event.pitch)}:{})}}))});
import {stringSeats,formationPlan,formationBetween,formationSummary,specificationOf,STRING_VOCABULARY,STRING_SECTIONS,GROUPINGS,TEXTURES,inLean,withLineage} from '../performers/string-section.js';
import {WIND_INSTRUMENTS} from '../performers/wind-line.js';
import {WIND_KINDS,windSeats,windSizeOf,windSpecificationOf,windFormationPlan,windFormationSummary} from '../performers/wind-section.js';
import {PERCUSSION,percussionSeats,percussionSizeOf,percussionFormation,percussionSummary} from '../performers/percussion-section.js';

// Whether a formation honours checked constraints (none: yes).
export const honoursConstraints=(formation,constraints={})=>{
  const {grouping,split,texture,level}=constraints??{},inRange=(value,range)=>!range||value>=range[0]-1e-9&&value<=range[1]+1e-9;
  return (!grouping||grouping.includes(formation.grouping))&&inRange(formation.split,split)
    &&formation.pools.every(pool=>(!texture||texture.includes(pool.texture))&&inRange(pool.level,level));
};

// A phrase the section rests: its draw shared by the band's sections (`shared`, in [0, 1): plex_clodbot's, from the
// ensemble's seed and the phrase's bar) in the specification's rest band, the piece's last phrase as any (every section
// had played it, its final chord's). Its pools kept, their texture tacet, so the phrase after moves from them as from any.
// Or one its conductor granted it (`granted`: the parent's answer to its ask, shared/conducting/requests.js).
// A section's specification with the composition's techniques: which it allows, how much its players want them
// (techniques.js techniquesOf), its formations drawing them by them.
const withTechniques=(specification,techniques)=>techniques?Object.freeze({...specification,techniques:techniquesOf(techniques)}):specification;
const resting=(decided,{shared,specification,granted=false})=>{
  const {from,to}=specification.rest??{from:0,to:0};
  if(!(granted||Number.isFinite(shared)&&shared>=from&&shared<to))return decided;
  return {formation:{...decided.formation,pools:decided.formation.pools.map(pool=>({...pool,texture:'tacet'}))},move:'tacet'};
};
const strings=Object.freeze({
  id:'strings',
  group:spec=>`strings:${spec.size}`,
  members:spec=>stringSeats(spec.size).map(seat=>seat.id),
  vocabulary:STRING_VOCABULARY,
  // A spec's section: its size, its fixed choices (the owner's to ask for: a grouping, split or texture) and its
  // specification over the authored one (string-section.js specificationOf).
  checked(value={}){
    const size=value.size??'full';stringSeats(size);
    if(value.grouping!=null&&!GROUPINGS.includes(value.grouping))throw new RangeError(`section.grouping is one of ${GROUPINGS.join(', ')}`);
    if(value.texture!=null&&!TEXTURES.includes(value.texture))throw new RangeError(`section.texture is one of ${TEXTURES.join(', ')}`);
    if(value.split!=null&&!(value.split>=0&&value.split<=1))throw new RangeError('section.split is between 0 and 1');
    return Object.freeze({kind:'strings',size,...(value.grouping!=null?{grouping:value.grouping}:{}),...(value.texture!=null?{texture:value.texture}:{}),
      ...(value.split!=null?{split:value.split}:{}),specification:withTechniques(specificationOf(value.specification??null),value.techniques)});
  },
  // The formation for the phrase from `bar`, `bars` long: the same again, any part of the way to a new one, or a new
  // one, as the specification's moves weigh them, the piece's last phrase as any; a new phrase's material from new
  // seeds, whatever the formation, each pool going on keeping its lineage (string-section.js withLineage). `bound`:
  // constraints from above are in force (a formation is never simply kept then).
  decide({bar,bars,previous=null,constraints={},bound=false,random,spec,shared=null,granted=false,character=null,elongation=1,lean=null}){
    const seats=stringSeats(spec.size),{grouping,split,texture}=spec,specification=inLean(spec.specification,lean),{stay,between}=specification.moves;
    // (In the ensemble's character, where one has been said: aesthetic.js sectionAesthetic.)
    const fresh=formationPlan(seats,{random,grouping,split,texture,constraints,specification,character,elongation});
    let formation=fresh,move='jump';
    if(previous){
      const u=random();
      // (Part of the way from a formation that already honours the constraints stays within them: the split, places and
      // levels between two within a range are within it, each pool's texture one of the two. From one that does not, a
      // formation between would not.)
      if(u<stay&&!bound){formation=previous;move='stay'}
      else if(u<stay+between&&previous.grouping===fresh.grouping&&honoursConstraints(previous,constraints)){
        const t=+random().toFixed(3);formation=formationBetween(previous,fresh,t,seats);move=`between ${t}`;
      }
    }
    formation=withLineage(formation,previous,random);
    return resting({formation,move},{shared,specification,granted});
  },
  summary:formationSummary,
  punctuated:(formation,seats,event)=>struckBy(formation,event),
  // A seat's player: the bowed string (bowedstring_clodbot), seated (bots/lib/modules/section-seat.js), named for a score.
  player:()=>'bowedstring_clodbot',
  seatList:spec=>stringSeats(spec.size),
  seats:spec=>stringSeats(spec.size).map(seat=>({seat:seat.id,label:`${STRING_SECTIONS[seat.section].abbreviation} ${seat.chair}`})),
});

// A woodwind or brass section (wind-section.js): the strings' formations, a wind's textures and specification, each
// seat's player its instrument's (a flute flute_clodbot, a reed woodwind_clodbot, a brass instrument brass_clodbot,
// seated: bots/lib/modules/wind-seat.js).
const PLAYERS=Object.freeze({flute:'flute_clodbot',reed:'woodwind_clodbot',brass:'brass_clodbot'});
// (A compass by the engines that will play a section's instruments (windSeats): by wind instrument, its windows each
// [low, high], ascending and apart; its low, high and keyed pitches numbers.)
const pitchOf=value=>typeof value==='number'&&Number.isFinite(value);
const enginesCompass=compass=>compass!==null&&typeof compass==='object'&&compass.instruments!==null&&typeof compass.instruments==='object'
  &&Object.entries(compass.instruments).every(([instrument,given])=>WIND_INSTRUMENTS[instrument]&&given!==null&&typeof given==='object'
    &&Array.isArray(given.windows)&&given.windows.length>0&&given.windows.every((w,k)=>Array.isArray(w)&&w.length===2&&w.every(pitchOf)&&w[0]<=w[1]&&(k===0||w[0]>=given.windows[k-1][1]))
    &&(given.low==null||pitchOf(given.low))&&(given.high==null||pitchOf(given.high))&&(given.keyed==null||Array.isArray(given.keyed)&&given.keyed.every(pitchOf))
    &&(given.fixed==null||typeof given.fixed==='boolean'));
const windKind=id=>Object.freeze({
  id,
  group:spec=>`${id}:${spec.size}`,
  members:spec=>windSeats(id,spec.size,{compass:spec.compass??null}).map(seat=>seat.id),
  vocabulary:STRING_VOCABULARY,
  checked(value={}){
    const size=value.size??Object.keys(WIND_KINDS[id].sizes)[1];windSizeOf(id,size);
    const textures=['line','chord','micropolyphony','cluster'];
    if(value.grouping!=null&&!GROUPINGS.includes(value.grouping))throw new RangeError(`section.grouping is one of ${GROUPINGS.join(', ')}`);
    if(value.texture!=null&&!textures.includes(value.texture))throw new RangeError(`a ${id} section's texture is one of ${textures.join(', ')}`);
    if(value.split!=null&&!(value.split>=0&&value.split<=1))throw new RangeError('section.split is between 0 and 1');
    // (Its players' compasses its instruments' own, or, 'bodies', each woodwind's on its keyed body as measured, or the
    // engines' that will play them, by instrument: windSeats.)
    if(value.compass!=null&&value.compass!=='bodies'&&!enginesCompass(value.compass))throw new RangeError(`a ${id} section's compass is 'bodies', its engines' ({instruments: {instrument: {windows: [[low, high]], low?, high?, keyed?, fixed?}}}) or its instruments' own`);
    return Object.freeze({kind:id,size,...(value.grouping!=null?{grouping:value.grouping}:{}),...(value.texture!=null?{texture:value.texture}:{}),
      ...(value.split!=null?{split:value.split}:{}),...(value.compass!=null?{compass:value.compass}:{}),specification:withTechniques(windSpecificationOf(id,value.specification??null),value.techniques)});
  },
  decide({bar,bars,previous=null,constraints={},bound=false,random,spec,shared=null,granted=false,character=null,elongation=1,lean=null}){
    const seats=windSeats(id,spec.size,{compass:spec.compass??null}),{grouping,split,texture}=spec,specification=inLean(spec.specification,lean),{stay,between}=specification.moves;
    const fresh=windFormationPlan(id,seats,{random,grouping,split,texture,constraints,specification,character,elongation});
    let formation=fresh,move='jump';
    if(previous){
      const u=random();
      if(u<stay&&!bound){formation=previous;move='stay'}
      else if(u<stay+between&&previous.grouping===fresh.grouping&&honoursConstraints(previous,constraints)){const t=+random().toFixed(3);formation=formationBetween(previous,fresh,t,seats);move=`between ${t}`}
    }
    formation=withLineage(formation,previous,random);
    return resting({formation,move},{shared,specification,granted});
  },
  summary:windFormationSummary,
  punctuated:(formation,seats,event)=>struckBy(formation,event),
  player:seat=>PLAYERS[WIND_INSTRUMENTS_FAMILY(seat)],
  seatList:spec=>windSeats(id,spec.size,{compass:spec.compass??null}),
  seats:spec=>windSeats(id,spec.size,{compass:spec.compass??null}).map(seat=>({seat:seat.id,instrument:seat.instrument,label:`${WIND_KINDS[id].sections[seat.section].abbreviation} ${seat.chair}`})),
});
const WIND_INSTRUMENTS_FAMILY=seat=>({flute:'flute',piccolo:'flute',alto:'flute','alto-flute':'flute',oboe:'reed',clarinet:'reed',bassoon:'reed',
  'e-flat-clarinet':'reed','bass-clarinet':'reed','english-horn':'reed',contrabassoon:'reed','soprano-saxophone':'reed','alto-saxophone':'reed','tenor-saxophone':'reed','baritone-saxophone':'reed'})[seat.instrument]??'brass';

// The percussion and harp (percussion-section.js): each phrase who plays, the players playing their own parts, likelier
// where the form arrives and where it is announced; the section asking the orchestra's conductor to rest whole phrases
// as any section does (its rest.ask, ours), but never those.
const PERCUSSION_SPECIFICATION=Object.freeze({moves:Object.freeze({stay:.3,between:0}),rest:Object.freeze({from:0,to:0,ask:.25,joins:false})});
const percussion=Object.freeze({
  id:'percussion',
  group:spec=>`percussion:${spec.size}`,
  members:spec=>percussionSeats(spec.size).map(seat=>seat.id),
  vocabulary:STRING_VOCABULARY,
  checked(value={}){
    const size=value.size??'standard';percussionSizeOf(size);
    return Object.freeze({kind:'percussion',size,specification:PERCUSSION_SPECIFICATION});
  },
  decide({bar,bars,previous=null,constraints={},bound=false,random,spec,shared=null,granted=false,opens=false,closes=false,character=null,elongation=1}){
    const seats=percussionSeats(spec.size);let formation=percussionFormation(seats,{random,constraints,join:opens||closes,character,elongation}),move='jump';
    if(previous&&!bound&&!opens&&!closes&&random()<spec.specification.moves.stay){formation=previous;move='stay'}
    return resting({formation,move},{shared,specification:spec.specification,granted});
  },
  summary:percussionSummary,
  // (Its players strike as each strikes a chord alone (section-member.js punctuate), their rings let sound on.)
  punctuated:(formation,seats,event)=>struckBy(formation,event),
  player:seat=>PERCUSSION.sections[String(seat.seat??seat.id).split('.')[0]]?.player,
  seatList:spec=>percussionSeats(spec.size),
  // (Named for a score by its section, and by its chair where its section has several: "Percussion 2".)
  seats:spec=>{const seats=percussionSeats(spec.size),several=section=>seats.filter(seat=>seat.section===section).length>1;
    return seats.map(seat=>({seat:seat.id,instrument:seat.instrument,label:`${PERCUSSION.sections[seat.section].name}${several(seat.section)?` ${seat.chair}`:''}`}))},
});

export const SECTION_KINDS=Object.freeze({strings,winds:windKind('winds'),brass:windKind('brass'),saxophones:windKind('saxophones'),percussion});
// The bots a section is, for a spec: its conductorbot (plex_clodbot, given the section and `conductor`'s settings: a
// parent, a group, a horizon) and a player a seat, each named for a score. -> [{id, settings, label?}].
// `seating`: a plan of seating.js SEATING_PLANS ('american', 'european'), each seat then placed as a main pair hears it
// (its pan and its send to the hall in the mix, its sound's arrival in its own lag -- its own level untouched; the hall
// itself, seating.js HALL, is the spec's effects, its return hallReturn); none, every seat in the middle, dry.
export function sectionBand(value,{conductor={},seating=null}={}){
  const {kind,spec}=sectionOf(value),{specification,...given}=value,seats=kind.seats(spec);
  if(seating!=null&&!SEATING_PLANS[seating])throw new RangeError(`seating is ${Object.keys(SEATING_PLANS).join(' or ')}`);
  // (Heard against the stage's front desks, so that sections seated apart are one orchestra; a full string section's own
  // front desks are its nearest seats, so it is heard as it was.)
  const plan=SEATING_PLANS[seating],reference=seating?stageReference(plan,stringSeats('full').map(seat=>({id:seat.id}))):null;
  const image=seating?seatImage(seatPositions(seats.map(({seat})=>({id:seat})),plan),{reference,farthest:farthestOf(plan)}):new Map;
  return [{id:'plex_clodbot',settings:{...conductor,section:{...given,kind:kind.id,...(specification?{specification}:{})}}},
    ...seats.map(({seat,label,instrument})=>{const heard=image.get(seat);
      return {id:kind.player({seat,instrument}),settings:{seat,size:spec.size,...(value.techniques?{techniques:value.techniques}:{}),...(kind.id!=='strings'?{kind:kind.id}:{}),...(WIND_KINDS[kind.id]?{instrument}:{}),...(spec.compass?{compass:spec.compass}:{}),...(conductor.group?{section:conductor.group}:{}),...(heard?{arrival:heard.arrival}:{})},label,
        ...(heard?{mix:{pan:heard.pan,reverb:heard.reverb}}:{})}})];
}
// A spec's section: {kind, ...the kind's choices}, checked. -> {kind (the kind), spec} or null where none is named.
export function sectionOf(value){
  if(value==null)return null;
  const kind=SECTION_KINDS[value?.kind];
  if(!kind)throw new RangeError(`section.kind is one of ${Object.keys(SECTION_KINDS).join(', ')}`);
  return {kind,spec:kind.checked(value)};
}
