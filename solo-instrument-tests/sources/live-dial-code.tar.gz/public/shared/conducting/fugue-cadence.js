// A fugue cadencing into its section of the form's coordinated hit (the owner's standing order: a mathematical problem
// to Astra, never a capability excluded; Astra's cadenceInto, CFM-002): each voice's lines as they were to a cut a beat
// before the hit, then a tail of its own into a tone of the hit's chord, every voice's chosen together so that the
// whole cadence keeps the counterpoint's contract -- or, where none does, no hit (UNSAT or UNKNOWN said, the fugue
// left whole: a gesture declined, never forced).
//
// Its tails are authored, a finite set a voice may take into each chord tone in its reach (FUGUE_CADENCE.forms): its
// last note held into the tone's arrival, or a step into it from the collection's pitch below it or above it; the
// chord's tones at every period of the harmony's own pitches, each its class's role (the chord's lowest as root,
// required; the others free). Its contract is a counterpoint profile (counterpoint-profile.js) read from the rules in
// force (counterpoint.js, the fugue's blend as its regime binds there), never intervals of its own (the owner, 3 October
// 2026: "don't hardcode intervals into the counterpoint rules ... we need the constraint-processing (rule-processing)
// methods to generalize across constraint regimes"): one note at a time a voice; no move wider than the rules' leapMost,
// which is also how far a voice's arrival may lie from its last pitch; no voice crossing the next where the rules weigh
// crossing; and no parallels between any two voices in the intervals the rules count perfect (COUNTERPOINT.consonance),
// each protected within the consonance width times the rules' weight on parallel perfects -- none where they weigh none.
// Times in quarters from the section of the form's start, exact; pitches in semitones, exact as their decimals.
//
// Its source is each voice's whole relevant material (Astra's handoff: "the complete relevant source"): the note it
// sounds at the cut, or its last before it -- the note its tail moves from -- whole, and every note of its from the cut
// on, which the tails replace; a note crossing the cut shortened to it only by the permission its candidates name
// (splitSourceIds), never clipped here. The solver's choice is played as it found it -- every cadence it accepts is
// its whole profile's, audited as it searches -- and returned with what it removes and shortens, for its owner to apply
// only where its lines still stand as they were (plex_clodbot fugueInto): SAT is no authority to cancel a note. Its
// independent audit (auditCadenceInto) and certificate (checkLargeCadenceCertificate) are checked in development, never
// while the music is made (the owner, 17 October 2026: "the show must go on").
import {cadenceInto,CADENCE_LIMITS} from './cadence-into.js';
import {compileFactorizedCadenceProfile} from './factorized-cadence-profile.js';
import {largeCadenceInto} from './large-cadence.js';
import {createPitchSpace,pitchFromNumber} from './pitch-spaces.js';
import {compileCounterpointProfile,decomposeCounterpointProfile} from './counterpoint-profile.js';
import {Q,exactSpan} from './canon-core.js';
import {exactOfNumber} from '../bounded-exact.js';
import {blendRules,COUNTERPOINT} from './counterpoint.js';
import PLANNING_COST from './planning-cost.json' with {type:'json'};
import CADENCE_WORK from './cadence-work.json' with {type:'json'};

// Ours, authored: the context before the cut the contract reads (in windows: a voice silent longer before it has no
// source note), the tails' forms, the search's bounds.
// Its search's budget its planner's (the owner, 2 October 2026: "budgeting should vary with available preplanning time;
// with a full preplan (offline render), the budget can be quite large, whereas obviously a synchronous context needs
// modification"): the time it can afford -- a whole piece planned ahead `most` ms a cadence, a live planner as long as
// the decisions it affords take (horizon.js affordablePlanning; planning-cost.json's msPerDecision), at least `least` --
// as units of the solver's work at the rate measured once in development (cadence-work.json, scripts/
// measure-cadence-work.mjs). Astra's cadenceInto admits any such allowance (CADENCE_BUDGETS.md); a search node costs a
// unit at least, so its nodes are bounded by its work.
export const FUGUE_CADENCE=Object.freeze({context:2,forms:Object.freeze(['held','below','above']),most:Object.freeze({ms:10000}),least:Object.freeze({ms:4})});
// The search's budget for a planner that can afford `decisions` (null: a whole piece planned ahead, its most).
export function cadenceBudget(decisions=null){
  const {most,least}=FUGUE_CADENCE,ms=Number.isFinite(decisions)?Math.min(most.ms,Math.max(least.ms,decisions*PLANNING_COST.msPerDecision)):most.ms;
  const work=Math.round(ms*CADENCE_WORK.workPerMs);return {maxNodes:work,maxWork:work};
}
const SPACE=createPitchSpace({id:'musebots-semitones',kind:'semitones'});
const exact=value=>Q(exactOfNumber(+Number(value).toFixed(6)));
const pitchOf=value=>pitchFromNumber(SPACE,+Number(value).toFixed(6)).pitch;
const modulo=(x,n)=>((x%n)+n)%n;

// `voices`: [{id, notes: [{t (quarters from the section's start), d (quarters), pitch}]}]; `anchor` the hit's
// downbeat (quarters); `hold` its length (quarters); `chord`: the harmony's pitches at the hit. -> {status, tails:
// {voiceId: {cut, tail: [{t, d, pitch}], arrival}}, evidence (the profile's audit of the chosen cadence, as its search
// accepted it)} --
// status SAT with its tails, else UNSAT or UNKNOWN and none.
// `rules` (counterpoint.js blendRules): the counterpoint in force where it cadences -- as rigorous as its planner and its
// regime there keep it (drawnRules' strictness, fugue-plan.js regimes). `ladder`: the collection's pitches (ladderOf),
// whose neighbours of a chord tone step into it; none, its voices only hold into their arrivals. `window` (quarters):
// how long before the hit its tails begin. `period` (semitones): the interval its harmony's pitches repeat at, an
// octave unless its tuning says otherwise. `owner`: whose lines these are and at which revision ({id, revision}): the
// cadence's dependencies, its result for those lines alone. A voice's notes may carry their own `id`s (else their
// places), by which its removals and shortenings name them.
export function fugueCadence({voices,anchor,hold,chord,rules=blendRules('tonal'),ladder=null,window=1,budget=cadenceBudget(),period=12,owner={id:'fugue',revision:0}}){
  const {maxNodes,maxWork}=budget,reach=Number(rules.leapMost)||0,steps=Array.isArray(ladder)?[...ladder].map(Number).filter(Number.isFinite).sort((a,b)=>a-b):[];
  const forms=steps.length?FUGUE_CADENCE.forms:FUGUE_CADENCE.forms.filter(form=>form==='held');
  // (The pitch of the collection just below or just above a tone: its step into it.)
  const neighbour=(pitch,below)=>below?steps.findLast(p=>p<pitch-1e-6):steps.find(p=>p>pitch+1e-6);
  const pcs=[...new Set(chord.map(Number).filter(Number.isFinite).map(p=>+modulo(p,period).toFixed(4)))];
  if(voices.length<2||!pcs.length||!(anchor>window))return {status:'UNKNOWN',reason:'no voices, chord or room before the hit',tails:null};
  const cut=anchor-window,root=+modulo(Math.min(...chord.map(Number)),period).toFixed(4);
  // (Each voice's source: its note sounding at the cut, else its last begun before it where it sounds within the
  // `context` quarters before the cut, whole; and all its notes from the cut on, its tail's to replace. Its lines before
  // that note are relevant to none of the contract's rules, which read each voice's moves and each two voices' motion
  // from one sounding slice to the next: the cadence's own moves -- the step into its tail, the slice before it -- and
  // never the lines before, which its contract did not make: a fugue's voices may have crossed, or moved in parallel,
  // under the looser rules its episodes keep (fugue-plan.js), and their cadence is not refused for it.)
  // (Its voices ordered by their pitch at the cut, low to high, whatever their order asked: the order its arrivals keep.)
  const lanes=voices.map(voice=>{
    const notes=[...voice.notes].map((note,k)=>({...note,id:String(note.id??k)})).sort((a,b)=>a.t-b.t);
    const at=notes.filter(note=>note.t<cut-1e-9&&note.t+note.d>cut-FUGUE_CADENCE.context*window-1e-9).at(-1)??null;
    return {...voice,at,crossing:at&&at.t+at.d>cut+1e-9?at:null,after:notes.filter(note=>note.t>=cut-1e-9),last:at?.pitch??notes.filter(note=>note.t<cut-1e-9).at(-1)?.pitch??null};
  }).sort((a,b)=>(a.last??0)-(b.last??0)).map((lane,k)=>({...lane,key:`v${k}`}));
  if(lanes.some(lane=>lane.last==null))return {status:'UNKNOWN',reason:'a voice silent before the cut',tails:null};
  // (The chord's tones: each of its classes, at every period, within its reach of a voice's last pitch.)
  const tones=new Map;
  for(const lane of lanes)for(const pc of pcs)for(let k=Math.floor((lane.last-reach)/period)-1;k<=Math.ceil((lane.last+reach)/period)+1;k++){const pitch=period*k+pc;if(Math.abs(pitch-lane.last)<=reach+1e-9)tones.set(pitch.toFixed(4),{pitch,pc})}
  const tone=[...tones.values()].sort((a,b)=>a.pitch-b.pitch);
  const event=(id,t,d,pitch)=>({id,...exactSpan(exact,t,d),pitch:pitch===null?null:pitchOf(pitch)});
  // (A source note's identity in the cadence, its voice's and its own; and back.)
  const sourceId=(lane,note)=>`${lane.key}:${note.id}`,noteOf=new Map(lanes.flatMap(lane=>[lane.at,...lane.after].filter(Boolean).map(note=>[sourceId(lane,note),note.id])));
  // (Its prefix immutable to the note crossing the cut, which its candidates may shorten to it, by name; else to the cut.)
  const spec={id:`fugue-into-hit:${owner.id}`,revision:Math.max(0,Math.round(Number(owner.revision)||0)),pitchSpace:SPACE,clockDomain:{id:'section-quarters',unit:'quarters',revision:1},
    anchor:exact(anchor),window:[exact(cut),exact(cut)],hitDuration:exact(hold),
    voices:lanes.map(lane=>({id:lane.key,source:[lane.at,...lane.after].filter(Boolean).map(note=>event(sourceId(lane,note),note.t,note.d,note.pitch)),
      immutableUntil:exact(lane.crossing?lane.crossing.t:cut),locked:false,
      candidates:tone.filter(t=>Math.abs(t.pitch-lane.last)<=reach+1e-9).flatMap((t,j)=>forms.map((form,f)=>{
        const approach=form==='held'?lane.last:neighbour(t.pitch,form==='below'),id=`${lane.key}c${j}${f}`;
        return approach==null?null:{id,cut:exact(cut),splitSourceIds:lane.crossing?[sourceId(lane,lane.crossing)]:[],tail:[event(`${id}t`,cut,window,approach)],arrival:{id:`${id}h`,pitch:pitchOf(t.pitch)}};
      }).filter(Boolean))})),
    chord:{roles:[{id:'root',min:1,max:lanes.length},{id:'tone',min:0,max:lanes.length}],
      tones:tone.map((t,j)=>({id:`t${j}`,role:Math.abs(t.pc-root)<1e-6?'root':'tone',pitch:pitchOf(t.pitch),min:0,max:lanes.length}))},
    domainComplete:true,dependencies:{owner:String(owner.id),revision:Math.max(0,Math.round(Number(owner.revision)||0))}};
  // (Its contract from the rules in force: its spacing read between neighbours, which orders them all, where they weigh
  // crossing; its parallels between every two voices, in the kinds they count perfect, each banded by the consonance
  // width times their weight on parallels, where they weigh any -- one rule each over its pairs (Astra's pair lists).)
  const ids=lanes.map(lane=>lane.key),neighbours=ids.slice(1).map((id,k)=>[ids[k],id]),periodCents=Math.round(period*100);
  // (Cents exact: a thousandth's fraction where not whole.)
  const cents=x=>Number.isInteger(x)?x:`${Math.round(x*1000)}/1000`;
  const weight=Math.max(0,Math.min(1,Number(rules.parallelPerfect)||0)),tolerance=cents(+(COUNTERPOINT.consonance.width*weight).toFixed(3));
  const perfect=[...new Set(COUNTERPOINT.consonance.perfect.map(c=>+modulo(c,periodCents).toFixed(3)))].map(cents);
  // (More voices than the exact model admits (CADENCE_LIMITS.voices): Astra's large-voice cadence (CFM-021), which admits
  // each voice's own rules and the spacing between neighbours in their order; and its parallels between the voices each
  // is heard against (CFM-024's pair bands): those up to COUNTERPOINT.heard apart in their order at the cut, as its
  // lines are planned against the voices nearest them in pitch -- never between any two, which it does not read.)
  if(lanes.length>CADENCE_LIMITS.voices)return largeCadence({spec,lanes,ids,neighbours,reach,crossing:Number(rules.crossing)>0,parallels:weight>0?{periodCents,classes:perfect.map((center,k)=>({id:`perfect${k}`,center,tolerance}))}:null,maxWork,cents});
  // (A contract the profile cannot compile makes no cadence: UNKNOWN.)
  let profile;try{profile=compileCounterpointProfile({id:'fugue-into-hit',version:1,pitchSpace:SPACE,clockDomain:spec.clockDomain,voices:ids,rules:[
    {id:'monophony',type:'monophony',required:true},{id:'leaps',type:'melodic-bound',required:true,maxCents:cents(+(reach*100).toFixed(3))},
    ...(Number(rules.crossing)>0?[{id:'spacing',type:'voice-spacing',required:true,pair:neighbours,minCents:0,maxCents:null}]:[]),
    ...(weight>0?[{id:'parallels',type:'parallel-classes',required:true,pair:'all',periodCents,classes:perfect.map((center,k)=>({id:`perfect${k}`,center,tolerance}))}]:[])]})}
  catch(error){return {status:'UNKNOWN',reason:String(error?.message??error),tails:null}}
  // (The profile the solver's own, decomposed (Astra's CFM-011): its search pruned forward by each voice's and each
  // pair's certain failures, every cadence it returns audited whole, its work charged by its own receipts.)
  let result;try{spec.rules={id:profile.id,version:profile.version,decomposition:decomposeCounterpointProfile(profile),checkJoint:null};
    result=cadenceInto(spec,{maxNodes,maxWork,pruning:'forward'})}catch(error){return {status:'UNKNOWN',reason:String(error?.message??error),tails:null}}
  if(result.status!=='SAT')return {status:result.status,reason:result.reason??null,tails:null,workUsed:result.workUsed??null};
  // (Exact values as numbers: a rational's text, 'n/d' or 'n'; a pitch its coordinate's.)
  const value=x=>{const [n,d='1']=String(x).split('/');return Number(n)/Number(d)};
  const pitchValue=p=>value(p?.coordinate??p?.value??p);
  const idOf=new Map(lanes.map(lane=>[lane.key,lane.id]));
  // (Each voice's tail as its search built it: its cut, its tail, its arrival, and the notes it removes and shortens, by
  // their own ids.)
  const tails=Object.fromEntries(result.tails.map(tail=>[idOf.get(tail.voiceId)??tail.voiceId,{cut:value(tail.cut),
    tail:(tail.tail??[]).map(e=>({t:value(e.t),d:value(e.d),pitch:pitchValue(e.pitch)})),arrival:pitchValue(tail.arrival.pitch),
    removed:tail.removedSourceIds.map(id=>noteOf.get(id)),shortened:tail.shortened.map(cut=>({id:noteOf.get(cut.sourceId),end:value(cut.end)}))}]));
  return {status:'SAT',tails,modelHash:result.modelHash,dependencies:spec.dependencies,workUsed:result.workUsed??0,evidence:result.audit?.profileEvidence??null};
}
// A cadence of more voices than the exact model admits (Astra's CFM-021: compileFactorizedCadenceProfile in the
// voices' order, largeCadenceInto; its certificate checked in development). -> as fugueCadence.
// `parallels`: {periodCents, classes} (the parallel-classes rule's), kept between the voices up to COUNTERPOINT.heard
// apart in their order at the cut; null where the rules weigh none. (Its order the cut's, held through the cadence: a
// voice heard against others after a crossing in its tail is not reread -- Astra's caveat, CFM-024.)
function largeCadence({spec,lanes,ids,neighbours,reach,crossing,parallels,maxWork,cents}){
  const value=x=>{const [n,d='1']=String(x).split('/');return Number(n)/Number(d)},pitchValue=p=>value(p?.coordinate??p?.value??p);
  const heard=COUNTERPOINT.heard,pairs=parallels?ids.flatMap((a,i)=>ids.slice(i+1,i+1+heard).map(b=>[a,b])):[];
  let result;
  try{
    const profile=compileFactorizedCadenceProfile({id:'fugue-into-hit',version:1,pitchSpace:spec.pitchSpace,clockDomain:spec.clockDomain,voices:ids,order:[...ids],rules:[
      {id:'monophony',type:'monophony',required:true},{id:'leaps',type:'melodic-bound',required:true,maxCents:cents(+(reach*100).toFixed(3))},
      ...(crossing?[{id:'spacing',type:'voice-spacing',required:true,pair:neighbours,minCents:0,maxCents:null}]:[]),
      ...(pairs.length?[{id:'parallels',type:'parallel-classes',required:true,pair:pairs,periodCents:parallels.periodCents,classes:parallels.classes}]:[])]},{maxPairDistance:Math.max(1,Math.min(heard,ids.length-1))});
    spec.rules={id:profile.id,version:profile.version,checkJoint:null,decomposition:profile};
    result=largeCadenceInto(spec,{maxWork});
  }catch(error){return {status:'UNKNOWN',reason:String(error?.message??error),tails:null}}
  if(result.status!=='SAT')return {status:result.status,reason:result.reason??null,tails:null,workUsed:result.workUsed??null};
  const idOf=new Map(lanes.map(lane=>[lane.key,lane.id])),noteOf=new Map(lanes.flatMap(lane=>[lane.at,...lane.after].filter(Boolean).map(note=>[`${lane.key}:${note.id}`,note.id])));
  const tails=Object.fromEntries(result.tails.map(tail=>[idOf.get(tail.voiceId)??tail.voiceId,{cut:value(tail.cut),
    tail:(tail.tail??[]).map(e=>({t:value(e.t),d:value(e.d),pitch:pitchValue(e.pitch)})),arrival:pitchValue(tail.arrival.pitch),
    removed:tail.removedSourceIds.map(id=>noteOf.get(id)),shortened:tail.shortened.map(cut=>({id:noteOf.get(cut.sourceId),end:value(cut.end)}))}]));
  return {status:'SAT',tails,large:true,modelHash:result.modelHash,dependencies:spec.dependencies,workUsed:result.workUsed,evidence:result.profileEvidence??null};
}
