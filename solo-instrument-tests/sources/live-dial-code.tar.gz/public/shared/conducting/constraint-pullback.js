// CFM-016 / GC09: finite shared-source variables, substituted FORWARD into a named target profile.
// Maps select a pitch at the target onset and hold it. Context changes still split the whole target audit.
// This is a finite declared model, not an inverse map, a continuous-function solver or production admission.
import {Q} from './canon-core.js';
import {compilePitchOperations} from './pitch-spaces.js';
import {decomposeCounterpointProfile} from './counterpoint-profile.js';
import {dataArray,dataRecord} from './contract-data.js';
import {Budget,Refused,EXACT_LIMITS,exactOf,exactText,compare,pythonJson,sha256} from '../bounded-exact.js';

export const PULLBACK_LIMITS=Object.freeze({variables:16,values:16,sourceEvents:128,entries:16,maps:64,
  knots:128,environmentEvents:1024,contexts:128,dependencies:64,rows:4096,events:4096,nodes:100000,
  snapshotNodes:65536,textChars:2000000,string:2048,depth:12,hashChars:2000000,
  defaultWork:100000,maxWork:500000,defaultProfileWork:20000});
const freeze=Object.freeze,models=new WeakMap,scope='finite-contextual-forward-substitution-and-named-whole-profile';
const fail=(message,kind='invalid-input')=>{throw new Refused(message,{kind})};
function fields(value,keys,required=keys){
  if(!dataRecord(value)||Object.keys(value).some(key=>!keys.includes(key))||required.some(key=>!Object.hasOwn(value,key)))fail('Unexpected or missing pullback fields');
  return value;
}
function count(value,max){if(!Number.isSafeInteger(value)||value<0||value>max)fail('Invalid bounded pullback count');return value}
function revision(value){return count(value,Number.MAX_SAFE_INTEGER)}
function name(value){if(typeof value!=='string'||!value.length||value.length>256)fail('A bounded nonempty identity is required');return value}
function boolean(value){if(typeof value!=='boolean')fail('Declare completeness explicitly');return value}
function frame(){return {nodes:0,chars:0}}
function snapshot(value,state,f=frame(),depth=0,seen=new Set){
  state.budget.charge();if(++f.nodes>PULLBACK_LIMITS.snapshotNodes)fail('Pullback snapshot-node budget','work-budget');
  if(value===null||typeof value==='boolean')return value;
  if(typeof value==='number'){if(!Number.isFinite(value))fail('Nonfinite semantic data');return Object.is(value,-0)?0:value}
  if(typeof value==='string'){
    if(value.length>PULLBACK_LIMITS.string||value.length>PULLBACK_LIMITS.textChars-f.chars)fail('Pullback snapshot-text budget','work-budget');
    f.chars+=value.length;return value;
  }
  if(depth>=PULLBACK_LIMITS.depth||seen.has(value))fail('Cyclic or deep pullback data');seen.add(value);let out;
  if(Array.isArray(value)){
    dataArray(value,PULLBACK_LIMITS.snapshotNodes,'Pullback semantic array');out=[];
    for(let i=0;i<value.length;i++)out.push(snapshot(value[i],state,f,depth+1,seen));
  }else{
    if(!dataRecord(value)||Object.keys(value).length>256)fail('Pullback semantic data must be ordinary bounded records');out={};
    for(const key of Object.keys(value)){name(key);Object.defineProperty(out,key,{value:snapshot(value[key],state,f,depth+1,seen),enumerable:true})}
  }
  seen.delete(value);return freeze(out);
}
function integer(value,bits){
  if(typeof value==='bigint'){const bound=1n<<BigInt(bits);if(value<=-bound||value>=bound)fail('Raw rational component bit cap','arithmetic-budget');return value}
  if(!Number.isSafeInteger(value))fail('Use safe integers or exact rational spellings');return BigInt(value);
}
function rational(value,state,bits=256){
  state.budget.charge();let input=value;
  if(typeof value==='string'){
    if(!value.length||value.length>(bits===256?160:6000))fail('Rational spelling length cap');
    const pair=value.match(/^([+-]?[0-9]+)\/([0-9]+)$/);
    if(pair)input={n:integer(BigInt(pair[1]),bits),d:integer(BigInt(pair[2]),bits)};
    else{
      const decimal=value.match(/^([+-]?)(?:([0-9]+)(?:\.([0-9]*))?|\.([0-9]+))(?:[eE]([+-]?[0-9]{1,3}))?$/);
      if(!decimal)fail('Invalid exact rational spelling');
      const [,sign,whole='',part=decimal[4]??'',,exponent='0']=decimal;
      if(Math.abs(Number(exponent))>256)fail('Exponent conversion cap','arithmetic-budget');
      const shift=Number(exponent)-part.length,digits=integer(BigInt((whole+part)||'0')*(sign==='-'?-1n:1n),bits);
      if(shift<0&&-shift>=bits||shift>=bits&&digits!==0n)fail('Raw decimal component bit cap','arithmetic-budget');
      input={n:integer(shift>0&&digits!==0n?digits*10n**BigInt(shift):digits,bits),d:integer(shift<0?10n**BigInt(-shift):1n,bits)};
    }
  }else if(typeof value==='number'||typeof value==='bigint')input=integer(value,bits);
  else if(Array.isArray(value)){dataArray(value,2,'Rational pair');if(value.length!==2)fail('A rational pair needs two components');input={n:integer(value[0],bits),d:integer(value[1],bits)}}
  else{fields(value,['n','d']);input={n:integer(value.n,bits),d:integer(value.d,bits)}}
  const q=exactOf(input,{bits});return bits===256?Q(q):q;
}
function cmp(a,b,state){state.budget.charge();return compare(a,b)}
function operation(a,method,b,state){state.budget.charge();return a[method](b)}
function nonnegative(value,state){const q=rational(value,state);if(cmp(q,Q(0),state)<0)fail('Negative exact time');return q}
function positive(value,state){const q=rational(value,state);if(cmp(q,Q(0),state)<=0)fail('A positive exact value is required');return q}
function clock(raw){fields(raw,['id','unit','revision']);return freeze({id:name(raw.id),unit:name(raw.unit),revision:revision(raw.revision)})}
function keyOf(value,state){
  const encoded=pythonJson(value);if(encoded.length>PULLBACK_LIMITS.hashChars)fail('Pullback hash-text budget','work-budget');
  state.budget.charge(1+Math.ceil(encoded.length/64));return encoded;
}
function hash(value,state){return sha256(keyOf(value,state))}
function typed(space,raw,state){
  fields(raw,['space','definition','coordinate']);if(raw.space!==space.id||raw.definition!==space.hash)fail('Pitch-space definition mismatch','out-of-model');
  let coordinate;
  if(space.kind==='lattice'){
    dataArray(raw.coordinate,32,'Lattice coordinate');coordinate=[];
    for(const value of raw.coordinate)coordinate.push(String(rational(value,state)));
  }else coordinate=String(rational(raw.coordinate,state));
  state.budget.charge();return space.pitch({space:space.id,definition:space.hash,coordinate});
}
function unique(set,id){if(set.has(id))fail('Duplicate pullback identity');set.add(id);return id}
function setup(options,kind){
  const keys=kind==='solve'?['maxWork','maxNodes','maxProfileWork']:kind==='check'?['maxWork','maxProfileWork']:['maxWork'];
  fields(options,keys,[]);const maxWork=Object.hasOwn(options,'maxWork')?count(options.maxWork,PULLBACK_LIMITS.maxWork):PULLBACK_LIMITS.defaultWork;
  const state={budget:new Budget(maxWork),profileWork:PULLBACK_LIMITS.defaultProfileWork};state.budget.charge();
  if(Object.hasOwn(options,'maxProfileWork'))state.profileWork=count(options.maxProfileWork,4*EXACT_LIMITS.maxWork);
  if(kind==='solve')state.maxNodes=Object.hasOwn(options,'maxNodes')?count(options.maxNodes,PULLBACK_LIMITS.nodes):10000;
  return state;
}
function normalize(spec,state){
  fields(spec,['id','revision','source','targetPitchSpace','entries','maps','environment','profile']);
  const id=name(spec.id),version=revision(spec.revision),sourceRaw=fields(spec.source,['pitchSpace','clockDomain','length','variables','events']);
  const sourceSpace=sourceRaw.pitchSpace,targetSpace=spec.targetPitchSpace;compilePitchOperations(sourceSpace,[]);compilePitchOperations(targetSpace,[]);
  // This checks the authentic compiled-profile brand. Its bounded local-view construction is library setup.
  const profile=spec.profile,profileInfo=decomposeCounterpointProfile(profile);
  if(profileInfo.pitchSpaceHash!==targetSpace.hash)fail('The mandatory profile uses another target pitch space','out-of-model');
  const sourceClock=clock(sourceRaw.clockDomain),targetClock=profileInfo.clockDomain,length=positive(sourceRaw.length,state),voices=new Set(profileInfo.voices);
  const variables=[],variableById=new Map,variableIds=new Set;
  dataArray(sourceRaw.variables,PULLBACK_LIMITS.variables,'Source variables');
  for(const raw of sourceRaw.variables){
    state.budget.charge();fields(raw,['id','complete','values']);const variableId=unique(variableIds,name(raw.id)),values=[],valueIds=new Set;
    dataArray(raw.values,PULLBACK_LIMITS.values,'Variable values');
    for(const item of raw.values){state.budget.charge();fields(item,['id','pitch']);values.push(freeze({id:unique(valueIds,name(item.id)),pitch:typed(sourceSpace,item.pitch,state)}))}
    const variable=freeze({id:variableId,complete:boolean(raw.complete),values:freeze(values)});variableById.set(variableId,variable);variables.push(variable);
  }
  const sourceEvents=[],sourceIds=new Set;dataArray(sourceRaw.events,PULLBACK_LIMITS.sourceEvents,'Source events');
  if(!sourceRaw.events.length)fail('Declare a nonempty finite source phrase');
  for(const raw of sourceRaw.events){
    state.budget.charge();fields(raw,['id','t','d','pitch']);const eventId=unique(sourceIds,name(raw.id)),t=nonnegative(raw.t,state),d=positive(raw.d,state);
    if(cmp(operation(t,'add',d,state),length,state)>0)fail('A source interval exceeds its declared phrase');let pitch=null;
    if(raw.pitch!==null){
      if(dataRecord(raw.pitch)&&Object.hasOwn(raw.pitch,'variableId')){fields(raw.pitch,['variableId']);const variableId=name(raw.pitch.variableId);if(!variableById.has(variableId))fail('Unknown source variable');pitch=freeze({variableId})}
      else{fields(raw.pitch,['fixed']);pitch=freeze({fixed:typed(sourceSpace,raw.pitch.fixed,state)})}
    }
    sourceEvents.push(freeze({id:eventId,t,d,pitch}));
  }
  const envRaw=fields(spec.environment,['id','revision','complete','events','contexts','dependencies']);
  const envId=name(envRaw.id),envRevision=revision(envRaw.revision),envComplete=boolean(envRaw.complete),contexts=[],contextById=new Map,contextIds=new Set,metadataFrame=frame();
  dataArray(envRaw.contexts,PULLBACK_LIMITS.contexts,'Target context cells');
  for(const raw of envRaw.contexts){
    state.budget.charge();fields(raw,['id','revision','from','to','complete','data']);const contextId=unique(contextIds,name(raw.id)),from=nonnegative(raw.from,state),to=nonnegative(raw.to,state);
    if(cmp(from,to,state)>=0||contexts.length&&cmp(from,contexts.at(-1).to,state)<0)fail('Context cells must be ordered disjoint half-open intervals');
    if(!dataRecord(raw.data))fail('Context data must be a record');
    const cell=freeze({id:contextId,revision:revision(raw.revision),from,to,complete:boolean(raw.complete),data:snapshot(raw.data,state,metadataFrame)});
    contexts.push(cell);contextById.set(contextId,cell);
  }
  const environmentEvents=[],envEventIds=new Set;dataArray(envRaw.events,PULLBACK_LIMITS.environmentEvents,'Fixed environment events');
  for(const raw of envRaw.events){
    state.budget.charge();fields(raw,['id','voiceId','t','d','pitch']);const eventId=unique(envEventIds,name(raw.id)),voiceId=name(raw.voiceId);
    if(!voices.has(voiceId))fail('Environment voice missing from the mandatory profile');
    environmentEvents.push(freeze({id:eventId,voiceId,t:nonnegative(raw.t,state),d:positive(raw.d,state),pitch:raw.pitch===null?null:typed(targetSpace,raw.pitch,state)}));
  }
  const dependencies=[],dependencyIds=new Set;dataArray(envRaw.dependencies,PULLBACK_LIMITS.dependencies,'Environment dependencies');
  for(const raw of envRaw.dependencies){state.budget.charge();fields(raw,['id','revision','data']);dependencies.push(freeze({id:unique(dependencyIds,name(raw.id)),revision:revision(raw.revision),data:snapshot(raw.data,state,metadataFrame)}))}
  const maps=[],mapById=new Map,mapIds=new Set;let rowCount=0;dataArray(spec.maps,PULLBACK_LIMITS.maps,'Forward maps');
  for(const raw of spec.maps){
    state.budget.charge();fields(raw,['id','revision','contextPolicy','dependencies','rows']);const mapId=unique(mapIds,name(raw.id));
    if(raw.contextPolicy!=='onset-held')fail('Only onset-held mapping is supported; context retuning needs another material contract','out-of-model');
    const dependencies=[],depIds=new Set;dataArray(raw.dependencies,PULLBACK_LIMITS.variables,'Map source dependencies');
    for(const id of raw.dependencies){state.budget.charge();unique(depIds,name(id));if(!variableById.has(id))fail('Unknown map source dependency');dependencies.push(id)}
    dataArray(raw.rows,PULLBACK_LIMITS.rows,'Forward table rows');if(raw.rows.length>PULLBACK_LIMITS.rows-rowCount)fail('Total forward-table row cap','row-budget');rowCount+=raw.rows.length;
    const rows=[],index=new Map;
    for(const item of raw.rows){
      state.budget.charge();fields(item,['input','contextId','values','result']);const input=typed(sourceSpace,item.input,state),contextId=name(item.contextId);
      if(!contextById.has(contextId))fail('Forward row names an undeclared context cell');
      dataArray(item.values,PULLBACK_LIMITS.variables,'Forward dependency values');if(item.values.length!==dependencies.length)fail('Forward dependency tuple has the wrong width');const values=[];
      for(let i=0;i<item.values.length;i++){
        state.budget.charge();const valueId=name(item.values[i]);if(!variableById.get(dependencies[i]).values.some(value=>value.id===valueId))fail('Forward row uses an unknown dependency value');values.push(valueId);
      }
      let result;fields(item.result,['status','pitch'],['status']);
      if(item.result.status==='VALUE'){fields(item.result,['status','pitch']);result=freeze({status:'VALUE',pitch:typed(targetSpace,item.result.pitch,state)})}
      else if(item.result.status==='UNDEFINED'){fields(item.result,['status']);result=freeze({status:'UNDEFINED'})}
      else fail('A forward result is VALUE or intentionally UNDEFINED');
      const row=freeze({input,contextId,values:freeze(values),result}),key=keyOf({input,contextId,values},state);
      if(index.has(key))fail('Duplicate forward-table key');index.set(key,row);rows.push(row);
    }
    const definition=freeze({id:mapId,revision:revision(raw.revision),contextPolicy:'onset-held',dependencies:freeze(dependencies),rows:freeze(rows)});
    const map={definition,index,hash:hash({sourceSpace:sourceSpace.hash,targetSpace:targetSpace.hash,...definition},state)};maps.push(map);mapById.set(mapId,map);
  }
  const entries=[],entryIds=new Set,timeIdentities=new Map;dataArray(spec.entries,PULLBACK_LIMITS.entries,'Mapped entries');if(!spec.entries.length)fail('Declare at least one entry');
  for(const raw of spec.entries){
    state.budget.charge();fields(raw,['id','voiceId','mapId','timeMap']);const entryId=unique(entryIds,name(raw.id)),voiceId=name(raw.voiceId),mapId=name(raw.mapId);
    if(!voices.has(voiceId)||!mapById.has(mapId))fail('Entry voice/map is undeclared');fields(raw.timeMap,['id','revision','knots']);
    dataArray(raw.timeMap.knots,PULLBACK_LIMITS.knots,'Time-map knots');if(raw.timeMap.knots.length<2)fail('A time map needs at least two knots');const knots=[];let direction=0;
    for(const point of raw.timeMap.knots){
      state.budget.charge();fields(point,['source','target']);const source=nonnegative(point.source,state),target=nonnegative(point.target,state);
      if(knots.length){const last=knots.at(-1),move=cmp(target,last.target,state);if(cmp(source,last.source,state)<=0||!move||direction&&direction!==move)fail('Time maps must be continuous strictly monotone piecewise affine maps');direction=move}
      knots.push(freeze({source,target}));
    }
    if(cmp(knots[0].source,Q(0),state)||cmp(knots.at(-1).source,length,state))fail('Time-map source extent must be exactly the source phrase');
    const timeDefinition=freeze({id:name(raw.timeMap.id),revision:revision(raw.timeMap.revision),source:sourceClock,target:targetClock,knots:freeze(knots)});
    const timeKey=keyOf(timeDefinition,state);if(timeIdentities.has(timeDefinition.id)&&timeIdentities.get(timeDefinition.id)!==timeKey)fail('A time-map identity cannot name two definitions');timeIdentities.set(timeDefinition.id,timeKey);
    entries.push(freeze({id:entryId,voiceId,mapId,timeDefinition,direction,timeHash:hash(timeDefinition,state)}));
  }
  if(entries.length*sourceEvents.length+environmentEvents.length>PULLBACK_LIMITS.events)fail('Materialized event cap','row-budget');
  const environment=freeze({id:envId,revision:envRevision,complete:envComplete,events:freeze(environmentEvents),contexts:freeze(contexts),dependencies:freeze(dependencies)});
  const definition=freeze({id,revision:version,source:freeze({pitchSpace:sourceSpace.definition,clockDomain:sourceClock,length,variables:freeze(variables),events:freeze(sourceEvents)}),
    targetPitchSpace:targetSpace.definition,targetClock,entries:freeze(entries.map(entry=>freeze({id:entry.id,voiceId:entry.voiceId,mapId:entry.mapId,timeMap:entry.timeDefinition}))),
    maps:freeze(maps.map(map=>map.definition)),environment,profile:profile.definition});
  const model={definition,sourceSpace,targetSpace,sourceEvents,variables,variableById,entries,mapById,environment,profile,targetClock};
  model.hash=hash(definition,state);return model;
}
function owned(prepared){const model=models.get(prepared);if(!model)fail('Use an authentic prepared pullback snapshot');return model}
/** Authenticated immutable description; this does not claim a witness or profile validity. */
export function describeConstraintPullback(prepared){const model=owned(prepared);return freeze({modelHash:model.hash,definition:model.definition})}
function unknown(error,state,model){return freeze({status:'UNKNOWN',scope,reason:error instanceof Refused?error.message:'Pullback processing refused',kind:error instanceof Refused?error.kind:'invalid-input',modelHash:model?.hash??null,workUsed:state?.budget.used??0})}
export function prepareConstraintPullback(spec,options={}){
  let state;try{state=setup(options,'prepare');const model=normalize(spec,state),prepared=freeze({kind:'constraint-pullback-model-v1',id:model.definition.id,revision:model.definition.revision,hash:model.hash,definition:model.definition});
    models.set(prepared,model);return freeze({status:'PASS',scope,prepared,modelHash:model.hash,workUsed:state.budget.used});
  }catch(error){return unknown(error,state)}
}
function contextAt(model,time,state){
  const cells=model.environment.contexts;let lo=0,hi=cells.length;
  while(lo<hi){state.budget.charge();const mid=(lo+hi)>>1;if(cmp(cells[mid].from,time,state)<=0)lo=mid+1;else hi=mid}
  const cell=cells[lo-1];return cell&&cmp(time,cell.to,state)<0?cell:null;
}
function timeAt(entry,time,state,linear=false){
  const knots=entry.timeDefinition.knots;let lo=0,hi=knots.length-1;
  if(linear){for(let i=0;i+1<knots.length;i++){state.budget.charge();if(cmp(time,knots[i+1].source,state)<=0){lo=i;hi=i+1;break}}}
  else while(hi-lo>1){state.budget.charge();const mid=(lo+hi)>>1;if(cmp(time,knots[mid].source,state)<0)hi=mid;else lo=mid}
  const a=knots[lo],b=knots[hi],fraction=operation(operation(time,'sub',a.source,state),'div',operation(b.source,'sub',a.source,state),state);
  return operation(a.target,'add',operation(fraction,'mul',operation(b.target,'sub',a.target,state),state),state);
}
function readAssignment(model,raw,state){
  dataArray(raw,PULLBACK_LIMITS.variables,'Source assignment');if(raw.length!==model.variables.length)fail('Assign every source variable exactly once');const values=new Map;
  for(const item of raw){
    state.budget.charge();fields(item,['variableId','candidateId']);const id=name(item.variableId),candidateId=name(item.candidateId),variable=model.variableById.get(id);
    if(!variable||values.has(id))fail('Unknown or repeated assignment variable');let selected=null;
    for(const value of variable.values){state.budget.charge();if(value.id===candidateId)selected=value}if(!selected)fail('Source value is outside its declared catalogue');values.set(id,selected);
  }
  return values;
}
function assignmentWire(model,values){return freeze(model.variables.map(variable=>freeze({variableId:variable.id,candidateId:values.get(variable.id).id})))}
function forward(model,entry,source,values,onset,state,linear=false){
  if(source.pitch===null)return {status:'VALUE',pitch:null,contextId:null};
  const input=Object.hasOwn(source.pitch,'variableId')?values.get(source.pitch.variableId).pitch:source.pitch.fixed,map=model.mapById.get(entry.mapId),cell=contextAt(model,onset,state);
  if(!cell||!cell.complete)return {status:'UNKNOWN',reason:'Mapped onset lacks a complete named context'};
  const tuple=map.definition.dependencies.map(id=>{state.budget.charge();return values.get(id).id});let row;
  if(!linear)row=map.index.get(keyOf({input,contextId:cell.id,values:tuple},state));
  else{
    const wanted=pythonJson(input);
    for(const candidate of map.definition.rows){
      state.budget.charge();if(candidate.contextId!==cell.id||pythonJson(candidate.input)!==wanted||candidate.values.length!==tuple.length)continue;
      let same=true;for(let i=0;i<tuple.length;i++){state.budget.charge();if(candidate.values[i]!==tuple[i])same=false}if(same){row=candidate;break}
    }
  }
  return !row?{status:'UNKNOWN',reason:'Required forward-table row is absent'}:row.result.status==='UNDEFINED'?{status:'FAIL',reason:'The named forward map is intentionally undefined on this input'}:
    {status:'VALUE',pitch:row.result.pitch,contextId:cell.id};
}
function mappedEvent(model,entry,source,i,j,t,d,pitch,contextId){return freeze({id:`m:${i}:${j}`,voiceId:entry.voiceId,t,d,pitch,clockDomain:model.targetClock,
  origin:freeze({kind:'mapped',entryId:entry.id,sourceId:source.id,mapHash:model.mapById.get(entry.mapId).hash,timeMapHash:entry.timeHash,contextId})})}
function environmentEvent(model,event,i){return freeze({id:`e:${i}`,voiceId:event.voiceId,t:event.t,d:event.d,pitch:event.pitch,clockDomain:model.targetClock,
  origin:freeze({kind:'environment',eventId:event.id,environmentId:model.environment.id,revision:model.environment.revision})})}
function materialize(model,values,state){
  const events=[],issues=[];
  for(let i=0;i<model.entries.length;i++)for(let j=0;j<model.sourceEvents.length;j++){
    state.budget.charge();const entry=model.entries[i],source=model.sourceEvents[j],a=timeAt(entry,source.t,state),b=timeAt(entry,operation(source.t,'add',source.d,state),state);
    const t=entry.direction>0?a:b,d=entry.direction>0?operation(b,'sub',a,state):operation(a,'sub',b,state),mapped=forward(model,entry,source,values,t,state);
    if(mapped.status!=='VALUE'){issues.push(freeze({status:mapped.status,reason:mapped.reason,entryId:entry.id,sourceId:source.id}));continue}
    events.push(mappedEvent(model,entry,source,i,j,t,d,mapped.pitch,mapped.contextId));
  }
  for(let i=0;i<model.environment.events.length;i++){state.budget.charge();events.push(environmentEvent(model,model.environment.events[i],i))}
  const status=issues.some(issue=>issue.status==='FAIL')?'FAIL':issues.length?'UNKNOWN':'PASS';
  return {status,events:freeze(events),issues:freeze(issues)};
}
function coverage(model,events,state){
  if(!model.environment.complete)return false;
  for(const event of events){
    state.budget.charge();if(event.pitch===null)continue;let at=event.t;const end=operation(event.t,'add',event.d,state);
    while(cmp(at,end,state)<0){const cell=contextAt(model,at,state);if(!cell||!cell.complete)return false;at=cmp(cell.to,end,state)<0?cell.to:end}
  }
  return true;
}
function auditMaterial(model,events,state){
  if(!coverage(model,events,state))return freeze({status:'UNKNOWN',reason:'Complete environment/context coverage of every sounding sustain is required'});
  const total=Math.min(state.profileWork,state.budget.limit-state.budget.used),allocated=Math.min(EXACT_LIMITS.maxWork,Math.floor(total/4));
  if(!allocated)fail('No whole-profile audit allowance remains','work-budget');
  const contextState={budget:new Budget(allocated)},boundaries=[];
  let out;
  try{
    for(const cell of model.environment.contexts){contextState.budget.charge();boundaries.push(cell.from,cell.to)}
    out=model.profile.audit(events,{boundaries,contextAt:time=>contextAt(model,time,contextState)?.data??freeze({}),
      dependencies:{model:model.hash,environment:model.environment.id,revision:model.environment.revision,declared:model.environment.dependencies},
      maxWork:allocated,maxPredicateWork:allocated});
  }catch(error){state.budget.charge(4*allocated);throw error}
  // Reserve the unreported first normalization; debit the other three ledgers once. No callback surface is exposed.
  state.budget.charge(allocated+out.workUsed+out.predicateWorkUsed+contextState.budget.used);
  return snapshot({...out,scope:'mandatory-whole-target-profile',normalizationAllowance:allocated,contextWorkUsed:contextState.budget.used},state);
}
function eventWire(events,state){
  const out=[];for(const event of events){state.budget.charge();out.push(freeze({...event,t:String(event.t),d:String(event.d)}))}return freeze(out);
}
function witness(model,values,events,state){
  const wire=eventWire(events,state);return freeze({kind:'constraint-pullback-witness-v1',modelHash:model.hash,assignment:assignmentWire(model,values),events:wire,eventHash:hash(wire,state)});
}
/** Reconstruct one original assignment, including a baseline that fails the profile. PASS here means
 * forward materialization only. Admission still requires checkConstraintPullback's whole-profile PASS. */
export function materializeConstraintPullbackAssignment(prepared,assignment,options={}){
  let state,model;const materialScope='finite-contextual-forward-materialization-only';
  try{
    state=setup(options,'prepare');model=owned(prepared);const values=readAssignment(model,assignment,state),out=materialize(model,values,state);
    return freeze({status:out.status,scope:materialScope,modelHash:model.hash,issues:out.issues,
      witness:out.status==='PASS'?witness(model,values,out.events,state):null,workUsed:state.budget.used});
  }catch(error){return freeze({...unknown(error,state,model),scope:materialScope})}
}
export function solveConstraintPullback(prepared,options={}){
  let state,model;try{
    state=setup(options,'solve');model=owned(prepared);const values=new Map;let nodes=0,leaves=0,unknownLeaves=0,found=null,foundAudit=null;
    function visit(depth){
      if(nodes>=state.maxNodes)fail('Pullback search-node budget','work-budget');state.budget.charge();nodes++;
      if(depth===model.variables.length){
        leaves++;const material=materialize(model,values,state);
        if(material.status==='FAIL')return false;if(material.status==='UNKNOWN'){unknownLeaves++;return false}
        const audit=auditMaterial(model,material.events,state);
        if(audit.status==='PASS'){found=witness(model,values,material.events,state);foundAudit=audit;return true}
        if(audit.status!=='FAIL')unknownLeaves++;return false;
      }
      const variable=model.variables[depth];for(const value of variable.values){state.budget.charge();values.set(variable.id,value);if(visit(depth+1))return true}values.delete(variable.id);return false;
    }
    const satisfied=visit(0),domainComplete=model.variables.every(variable=>variable.complete);
    return freeze({status:satisfied?'SAT':domainComplete&&!unknownLeaves?'UNSAT':'UNKNOWN',scope,modelHash:model.hash,witness:found,audit:foundAudit,
      search:freeze({nodes,leaves,unknownLeaves,exhausted:!satisfied,domainComplete}),workUsed:state.budget.used,
      reason:satisfied?'A complete forward materialization passes the mandatory whole profile':domainComplete&&!unknownLeaves?'Every assignment in the declared complete finite domain was decisively excluded':'Incomplete source catalogues or unresolved assignments'});
  }catch(error){return unknown(error,state,model)}
}
function readWitnessEvents(model,raw,state){
  dataArray(raw,PULLBACK_LIMITS.events,'Witness material');const events=[],ids=new Set;
  for(const item of raw){
    state.budget.charge();fields(item,['id','voiceId','t','d','pitch','clockDomain','origin']);const id=unique(ids,name(item.id));
    const t=rational(item.t,state,8192),d=rational(item.d,state,8192);if(cmp(t,{n:0n,d:1n},state)<0||cmp(d,{n:0n,d:1n},state)<=0)fail('Witness intervals must have nonnegative onset and positive duration');
    const origin=snapshot(item.origin,state);if(!dataRecord(origin))fail('A witness origin must be a record');
    events.push(freeze({id,voiceId:name(item.voiceId),t:exactText(t),d:exactText(d),pitch:item.pitch===null?null:typed(model.targetSpace,item.pitch,state),clockDomain:clock(item.clockDomain),origin}));
  }
  return freeze(events);
}
export function checkConstraintPullback(prepared,raw,options={}){
  let state,model;try{
    state=setup(options,'check');model=owned(prepared);fields(raw,['kind','modelHash','assignment','events','eventHash']);
    if(raw.kind!=='constraint-pullback-witness-v1'||typeof raw.modelHash!=='string'||typeof raw.eventHash!=='string'||raw.modelHash.length!==64||raw.eventHash.length!==64)fail('Malformed witness identity');
    const values=readAssignment(model,raw.assignment,state),supplied=readWitnessEvents(model,raw.events,state);
    if(raw.modelHash!==model.hash)return freeze({status:'FAIL',scope,reason:'The witness belongs to another model',modelHash:model.hash,workUsed:state.budget.used});
    if(hash(supplied,state)!==raw.eventHash)return freeze({status:'FAIL',scope,reason:'The materialized event hash differs',modelHash:model.hash,workUsed:state.budget.used});
    const byId=new Map(supplied.map(event=>[event.id,event])),verified=[],issues=[];
    function match(expected){
      state.budget.charge();const actual=byId.get(expected.id),wire=freeze({...expected,t:String(expected.t),d:String(expected.d)});
      if(!actual||pythonJson(actual)!==pythonJson(wire))issues.push(freeze({status:'FAIL',reason:'Materialized occurrence differs from direct forward replay',eventId:expected.id}));
      byId.delete(expected.id);verified.push(expected);
    }
    // Independent replay: linear time-segment and forward-row lookup; no solver materializer or cached verdict.
    for(let i=0;i<model.entries.length;i++)for(let j=0;j<model.sourceEvents.length;j++){
      state.budget.charge();const entry=model.entries[i],source=model.sourceEvents[j],a=timeAt(entry,source.t,state,true),b=timeAt(entry,operation(source.t,'add',source.d,state),state,true);
      const lower=cmp(a,b,state)<0?a:b,upper=cmp(a,b,state)<0?b:a,mapped=forward(model,entry,source,values,lower,state,true);
      if(mapped.status!=='VALUE'){issues.push(freeze({status:mapped.status,reason:mapped.reason,entryId:entry.id,sourceId:source.id}));byId.delete(`m:${i}:${j}`);continue}
      match(mappedEvent(model,entry,source,i,j,lower,operation(upper,'sub',lower,state),mapped.pitch,mapped.contextId));
    }
    for(let i=0;i<model.environment.events.length;i++){state.budget.charge();match(environmentEvent(model,model.environment.events[i],i))}
    for(const id of byId.keys()){state.budget.charge();issues.push(freeze({status:'FAIL',reason:'Extra materialized event',eventId:id}))}
    if(issues.length)return freeze({status:issues.some(issue=>issue.status==='FAIL')?'FAIL':'UNKNOWN',scope,modelHash:model.hash,issues:freeze(issues),workUsed:state.budget.used});
    const audit=auditMaterial(model,freeze(verified),state);
    return freeze({status:audit.status,scope,modelHash:model.hash,eventHash:raw.eventHash,audit,workUsed:state.budget.used,
      reason:'Direct occurrence replay and mandatory whole materialized-profile audit'});
  }catch(error){return unknown(error,state,model)}
}
