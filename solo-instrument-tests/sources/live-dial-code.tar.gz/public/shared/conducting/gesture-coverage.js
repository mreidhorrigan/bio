// CFM-008 / DC06,09: a supplied complete gesture inventory, not roles inferred from observed notes.
// Every interval is continuous sounding in its named evidence layer; note gates do not prove acoustic sustain.
// Preparation/authority verdicts and observation completeness are explicit independent owner premises.
import {dataArray,dataRecord} from './contract-data.js';
import {Budget,Refused,EXACT_LIMITS,exactOf,exactText,compare,sub,pythonJson,sha256} from '../bounded-exact.js';

export const GESTURE_COVERAGE_LIMITS=Object.freeze({roles:64,expected:256,observed:2048,silences:128,
  exemptions:256,string:128,text:262144,hashChars:1048576,diagnostics:8192,
  inputBits:256,workBits:8192,defaultWork:100000,maxWork:500000});
const freeze=Object.freeze,rawBoundary=1n<<256n,scope='declared-gesture-coverage';
const fail=(message,kind='invalid-input')=>{throw new Refused(message,{kind})};
function fields(value,required,optional=[]){
  if(!dataRecord(value)||required.some(key=>!Object.hasOwn(value,key))||
    Object.keys(value).some(key=>!required.includes(key)&&!optional.includes(key)))fail('Unexpected or missing gesture-coverage fields');
  return value;
}
function text(value,state,limit=GESTURE_COVERAGE_LIMITS.string){
  if(typeof value!=='string'||!value.length||value.length>limit)fail('Invalid bounded gesture text');
  state.chars+=value.length;if(state.chars>GESTURE_COVERAGE_LIMITS.text)fail('Gesture text budget','work-budget');return value;
}
function revision(value){
  if(!Number.isSafeInteger(value)||value<0)fail('Revision must be a nonnegative safe integer');return value;
}
function integerToken(value){
  if(typeof value==='bigint'){
    if(value<=-rawBoundary||value>=rawBoundary)fail('Raw rational component exceeds 256 bits','arithmetic-budget');
  }else if(!Number.isSafeInteger(value))fail('Use safe integers or exact rational spellings; convert noninteger Numbers explicitly');
  return value;
}
function rational(value,state){
  state.budget.charge();let input=value;
  if(typeof value==='string'){
    text(value,state,160);const pair=value.match(/^([+-]?[0-9]+)\/([0-9]+)$/);
    if(pair){integerToken(BigInt(pair[1]));integerToken(BigInt(pair[2]))}
  }else if(typeof value==='number'||typeof value==='bigint')integerToken(value);
  else if(Array.isArray(value)){
    dataArray(value,2,'Exact pair');if(value.length!==2)fail('Exact pair needs two components');
    input={n:integerToken(value[0]),d:integerToken(value[1])};
  }else{
    fields(value,['n','d']);input={n:integerToken(value.n),d:integerToken(value.d)};
  }
  const result=exactOf(input);if(typeof value!=='string')text(exactText(result),state,160);return result;
}
const nullable=(value,state)=>value===null?(state.budget.charge(),null):rational(value,state);
const wire=value=>value===null?null:exactText(value);
function order(a,b,state){state.budget.charge();return compare(a,b)}
function interval(value,state,positive=false){
  dataArray(value,2,'Exact interval');if(value.length!==2)fail('An interval needs two endpoints');
  const out=freeze([rational(value[0],state),rational(value[1],state)]),c=order(out[0],out[1],state);
  if(c>0||positive&&c===0)fail(positive?'An interval must have positive length':'An interval must be ordered');return out;
}
const intervalWire=pair=>freeze(pair.map(exactText));
function contained(pair,window,state,strictEnd=false){
  const lower=order(pair[0],window[0],state),upper=order(pair[1],window[1],state);
  if(lower<0||(strictEnd?upper>=0:upper>0))
    fail(strictEnd?'Attack windows must lie wholly within the half-open review window':'Interval is outside the review window');
}
function names(values,state,limit,label,allowed=null){
  dataArray(values,limit,label);const out=[],seen=new Set;
  for(const raw of values){
    state.budget.charge();const name=text(raw,state);if(seen.has(name)||allowed&&!allowed.has(name))fail(`Duplicate or out-of-scope ${label}`);
    seen.add(name);out.push(name);
  }
  return freeze(out);
}
function evidence(value,state){
  fields(value,['id','revision','status']);if(!['PASS','FAIL','UNKNOWN'].includes(value.status))fail('Evidence requires an explicit PASS, FAIL or UNKNOWN');
  return freeze({id:text(value.id,state),revision:revision(value.revision),status:value.status});
}

function normalize(spec,state){
  fields(spec,['id','revision','clock','layer','window','roles','additionalEvents','expected','silences','observed','requiredEvidence']);
  const id=text(spec.id,state),version=revision(spec.revision),clockRaw=fields(spec.clock,['id','revision','kind','unit']);
  if(!['score','wall'].includes(clockRaw.kind))fail('Clock kind must be score or wall');
  if(!['planned','scheduled','executed','acoustic'].includes(spec.layer))fail('Name the evidence layer');
  if(!['allow','forbid'].includes(spec.additionalEvents))fail('Declare the additional-event policy');
  const clock=freeze({id:text(clockRaw.id,state),revision:revision(clockRaw.revision),kind:clockRaw.kind,unit:text(clockRaw.unit,state)});
  const window=interval(spec.window,state,true),roles=names(spec.roles,state,GESTURE_COVERAGE_LIMITS.roles,'roles');
  if(!roles.length)fail('Declare at least one role');const roleSet=new Set(roles),usedRoles=new Set;
  dataArray(spec.silences,GESTURE_COVERAGE_LIMITS.silences,'Silences');const silences=[],silenceIds=new Set,silenceById=new Map;
  for(const raw of spec.silences){
    state.budget.charge();fields(raw,['id','window','roles','exemptEventIds']);const name=text(raw.id,state);
    if(silenceIds.has(name))fail('Duplicate silence identity');silenceIds.add(name);
    const span=interval(raw.window,state,true);contained(span,window,state);
    const selected=names(raw.roles,state,GESTURE_COVERAGE_LIMITS.roles,'silence roles',roleSet);
    if(!selected.length)fail('A silence needs at least one scoped role');for(const role of selected)usedRoles.add(role);
    const exemptEventIds=names(raw.exemptEventIds,state,GESTURE_COVERAGE_LIMITS.exemptions,'silence exemptions');
    const row=freeze({id:name,window:span,roles:selected,exemptEventIds});silences.push(row);silenceById.set(name,row);
  }
  dataArray(spec.expected,GESTURE_COVERAGE_LIMITS.expected,'Expected events');const expected=[],expectedById=new Map;
  for(const raw of spec.expected){
    state.budget.charge();fields(raw,['id','role','kind','attackWindow','releaseWindow','hold','afterSilence']);
    const name=text(raw.id,state),role=text(raw.role,state);if(expectedById.has(name))fail('Duplicate expected event identity');
    if(!roleSet.has(role))fail('Expected role is outside the declared role inventory');usedRoles.add(role);
    if(!['attack','reentry'].includes(raw.kind))fail('An expected event is an attack or a reentry');
    const attackWindow=interval(raw.attackWindow,state),releaseWindow=interval(raw.releaseWindow,state),hold=interval(raw.hold,state);
    contained(attackWindow,window,state,true);contained(releaseWindow,window,state);
    if(hold[0].n<0n||hold[1].n<=0n)fail('Hold bounds are nonnegative with a positive maximum');
    let afterSilence=null;
    if(raw.kind==='attack'){if(raw.afterSilence!==null)fail('An ordinary attack must explicitly have no preceding-silence link')}
    else{
      afterSilence=text(raw.afterSilence,state);const previous=silenceById.get(afterSilence);
      if(!previous||!previous.roles.includes(role))fail('A reentry must name a silence scoped to its role');
    }
    const row=freeze({id:name,role,kind:raw.kind,attackWindow,releaseWindow,hold,afterSilence});expected.push(row);expectedById.set(name,row);
  }
  if(!expected.length&&!silences.length)fail('Declare an event or silence obligation');
  for(const role of roles)if(!usedRoles.has(role))fail('Every declared role needs an expected event or a silence obligation');
  const observedRaw=fields(spec.observed,['complete','events']);if(typeof observedRaw.complete!=='boolean')fail('Declare observation completeness');
  dataArray(observedRaw.events,GESTURE_COVERAGE_LIMITS.observed,'Observed events');const observed=[];
  for(const raw of observedRaw.events){
    state.budget.charge();fields(raw,['id','role','from','to']);
    // Duplicate or wrongly assigned observed IDs are audit findings, not permission to drop a record.
    observed.push(freeze({id:text(raw.id,state),role:text(raw.role,state),from:nullable(raw.from,state),to:nullable(raw.to,state)}));
  }
  fields(spec.requiredEvidence,['preparation','authority']);
  const requiredEvidence=freeze({preparation:evidence(spec.requiredEvidence.preparation,state),authority:evidence(spec.requiredEvidence.authority,state)});
  const snapshot=freeze({id,revision:version,clock,layer:spec.layer,window:intervalWire(window),roles,additionalEvents:spec.additionalEvents,
    expected:freeze(expected.map(row=>freeze({...row,attackWindow:intervalWire(row.attackWindow),releaseWindow:intervalWire(row.releaseWindow),hold:intervalWire(row.hold)}))),
    silences:freeze(silences.map(row=>freeze({...row,window:intervalWire(row.window)}))),
    observed:freeze({complete:observedRaw.complete,events:freeze(observed.map(row=>freeze({...row,from:wire(row.from),to:wire(row.to)})))}),requiredEvidence});
  const encoded=pythonJson(snapshot);if(encoded.length>GESTURE_COVERAGE_LIMITS.hashChars)fail('Gesture snapshot hash budget','work-budget');
  state.budget.charge(1+Math.ceil(encoded.length/64));state.snapshot=snapshot;state.modelHash=sha256(encoded);
  return {window,roles,roleSet,expected,expectedById,silences,silenceById,observed,complete:observedRaw.complete,
    additionalEvents:spec.additionalEvents,requiredEvidence};
}

function audit(model,state){
  const checks=[],byId=new Map,duplicateIds=[],matchedIds=[],missingIds=[],unlistedIds=[];
  const reserve=(n=1)=>{
    state.budget.charge(n);state.diagnostics+=n;if(state.diagnostics>GESTURE_COVERAGE_LIMITS.diagnostics)fail('Gesture diagnostic budget','work-budget');
  };
  const addCheck=(subject,predicate,status,detail={})=>{
    reserve();checks.push(freeze({subject,predicate,status,...detail}));
  };
  addCheck('observed','declared-complete-inventory',model.complete?'PASS':'UNKNOWN');
  for(let i=0;i<model.observed.length;i++){
    state.budget.charge();const row=model.observed[i],list=byId.get(row.id)??[];list.push(row);byId.set(row.id,list);
    addCheck(row.id,'declared-role',model.roleSet.has(row.role)?'PASS':'FAIL',{observationIndex:i,role:row.role});
    const intervalOrder=row.from===null||row.to===null?null:order(row.from,row.to,state);
    addCheck(row.id,'positive-sounding-interval',intervalOrder===null?'UNKNOWN':intervalOrder<0?'PASS':'FAIL',
      {observationIndex:i,from:wire(row.from),to:wire(row.to)});
    if(!model.expectedById.has(row.id)){
      reserve();unlistedIds.push(row.id);
      if(model.additionalEvents==='forbid'){
        const outside=row.from!==null&&order(row.from,model.window[1],state)>=0||row.to!==null&&order(row.to,model.window[0],state)<=0;
        const status=intervalOrder!==null&&intervalOrder>=0?'UNKNOWN':outside?'PASS':intervalOrder===null?'UNKNOWN':'FAIL';
        addCheck(row.id,'no-additional-scoped-event',status,{observationIndex:i});
      }
    }
  }
  for(const [id,rows] of byId){
    state.budget.charge();if(rows.length>1){reserve();duplicateIds.push(id);addCheck(id,'unique-observed-identity','FAIL',{count:rows.length})}
  }
  const inside=(subject,predicate,value,window)=>{
    const status=value===null?'UNKNOWN':order(value,window[0],state)>=0&&order(value,window[1],state)<=0?'PASS':'FAIL';
    addCheck(subject,predicate,status,{value:wire(value),window:intervalWire(window)});
  };
  for(const expected of model.expected){
    state.budget.charge();const rows=byId.get(expected.id)??[];
    if(!rows.length){
      reserve();missingIds.push(expected.id);addCheck(expected.id,'expected-event-present',model.complete?'FAIL':'UNKNOWN',{role:expected.role});continue;
    }
    if(rows.length!==1){addCheck(expected.id,'exactly-one-expected-event','FAIL',{count:rows.length});continue}
    const row=rows[0],rightRole=row.role===expected.role;
    addCheck(expected.id,'expected-role',rightRole?'PASS':'FAIL',{expectedRole:expected.role,observedRole:row.role});
    if(rightRole){reserve();matchedIds.push(expected.id)}
    inside(expected.id,'attack-window',row.from,expected.attackWindow);
    inside(expected.id,'release-window',row.to,expected.releaseWindow);
    let duration=null;if(row.from!==null&&row.to!==null){state.budget.charge();duration=sub(row.to,row.from)}
    inside(expected.id,'hold-duration',duration,expected.hold);
    if(expected.kind==='reentry'){
      const silence=model.silenceById.get(expected.afterSilence),status=row.from===null?'UNKNOWN':order(row.from,silence.window[1],state)>=0?'PASS':'FAIL';
      addCheck(expected.id,'reentry-after-silence',status,{silenceId:silence.id,at:wire(row.from),notBefore:exactText(silence.window[1])});
    }
  }
  for(const silence of model.silences){
    state.budget.charge();const selected=new Set(silence.roles),exempt=new Set(silence.exemptEventIds),overlaps=[],unknown=[];
    for(const row of model.observed){
      state.budget.charge();if(!selected.has(row.role)||exempt.has(row.id))continue;
      if(row.from===null||row.to===null||order(row.from,row.to,state)>=0){reserve();unknown.push(row.id);continue}
      if(order(row.from,silence.window[1],state)<0&&order(row.to,silence.window[0],state)>0){reserve();overlaps.push(row.id)}
    }
    addCheck(silence.id,'half-open-silence',overlaps.length?'FAIL':!model.complete||unknown.length?'UNKNOWN':'PASS',
      {window:intervalWire(silence.window),roles:silence.roles,exemptEventIds:silence.exemptEventIds,
        overlappingEventIds:freeze(overlaps),unknownEventIds:freeze(unknown)});
  }
  for(const kind of ['preparation','authority']){
    state.budget.charge();const premise=model.requiredEvidence[kind];
    addCheck(premise.id,`named-${kind}-premise`,premise.status,{revision:premise.revision});
  }
  const failed=[],unknown=[];
  for(const check of checks){state.budget.charge();if(check.status==='FAIL')failed.push(check);else if(check.status==='UNKNOWN')unknown.push(check)}
  return freeze({status:failed.length?'FAIL':unknown.length?'UNKNOWN':'PASS',scope,layer:state.snapshot.layer,
    modelHash:state.modelHash,snapshot:state.snapshot,checks:freeze(checks),failed:freeze(failed),unknown:freeze(unknown),
    inventory:freeze({declaredComplete:model.complete,requiredRoles:model.roles,expectedCount:model.expected.length,observedCount:model.observed.length,
      matchedEventIds:freeze(matchedIds),missingEventIds:freeze(missingIds),duplicateObservationIds:freeze(duplicateIds),unlistedEventIds:freeze(unlistedIds)}),
    workUsed:state.budget.used});
}

/** Audit the supplied model only. PASS does not establish its observation completeness or authority premises. */
export function auditGestureCoverage(spec,options={}){
  const state={chars:0,diagnostics:0,budget:null,snapshot:null,modelHash:null};
  try{
    fields(options,[],['maxWork']);const limit=Object.hasOwn(options,'maxWork')?options.maxWork:EXACT_LIMITS.work;
    if(!Number.isInteger(limit))fail('maxWork must be an explicit integer when supplied');
    state.budget=new Budget(limit);state.budget.charge();const model=normalize(spec,state);return audit(model,state);
  }catch(error){
    if(!(error instanceof Refused))throw error;
    return freeze({status:'UNKNOWN',scope,layer:state.snapshot?.layer??null,modelHash:state.modelHash,snapshot:state.snapshot,
      reason:freeze({kind:error.kind,message:error.message}),checks:freeze([]),failed:freeze([]),unknown:freeze([]),inventory:null,workUsed:state.budget?.used??0});
  }
}
