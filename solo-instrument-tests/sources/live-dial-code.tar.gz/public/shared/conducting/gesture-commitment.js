// A coordinated gesture committed jointly before it is played (Astra's EC18/CF31/DC10, CFM-033 joint-negotiation.js:
// "one parent-bound, epoch-fenced joint proposal/accept/commit"; DC10: "no absent role, stale event or local fallback
// silently changes a committed gesture"). A conductor proposes a gesture its sections are to play together -- a tutti hit,
// its hold, its general pause (plex_clodbot.js assignPunctuation) -- as one immutable proposal: every section a member,
// its first action the gesture's bar, a deadline before the section of the form it closes begins, the piece's allowance
// of such gestures reserved for it. Each section, hearing it, says it is ready (its preparation: the gesture as it will
// strike it); once every one has, and the proposal is whole (its hold the one its planner chose, coordinated-events.js
// viableHold, its beats said), the conductor commits it, and only then is it in the plan its sections play. Its hold is
// never judged again here: its planner chose it viable (the owner, 17 October 2026: such checks for development only). A gesture not every section readied by its deadline expires: no gesture,
// never one played by some. The conductor is the one serial authority over its ledger (Astra: "one durable fenced
// serialization point"); a section's reply is trusted as the transport delivers it.
import {prepareJointNegotiation,stepJointNegotiation,inspectJointNegotiation} from './joint-negotiation.js';
import {pythonJson,sha256} from '../bounded-exact.js';

const reference=(id,value)=>({id,revision:1,hash:sha256(pythonJson(value))});
// The gesture's contract, on its complete proposal: whole -- its hold's beats said, as its sections need them to play it.
const whole=proposal=>{const beats=proposal?.content?.hold?.beats;return typeof beats==='number'&&beats>0?'PASS':'UNKNOWN'};

export class GestureCommitments {
  // `coordinator` {id, incarnation}: the conductor; `members` [{id, incarnation}]: its sections; `capacity`: the gestures
  // its piece may take (one a section of its form); `at`: now (ticks).
  constructor({id,coordinator,members,capacity,at}){
    this.coordinator={...coordinator};this.members=members.map(member=>({...member}));this.messages=0;
    const base={authority:{...coordinator,epoch:1},clock:{id:'ticks',unit:'tick',revision:1},parent:reference(`${id}:plan`,[id,0]),
      prefixHash:sha256(pythonJson([id,'prefix'])),bindingsHash:sha256(pythonJson(members.map(m=>m.id)))};
    const out=prepareJointNegotiation({id,revision:1,complete:true,at:Math.max(0,Math.floor(at)),base,participants:this.members,
      budgets:[{id:'gestures',unit:'gesture',capacity:Math.max(0,Math.floor(capacity)),spent:0,history:reference(`${id}:gestures`,[])}],
      requiredContracts:[{id:'gesture-whole',revision:1}]},[{id:'gesture-whole',revision:1,check:whole}]);
    this.ledger=out.status==='PASS'?out.ledger:null;this.reason=out.reason??null;
  }
  view(){const out=this.ledger?inspectJointNegotiation(this.ledger):null;return out?.status==='PASS'?out.snapshot:null}
  step(command,origin,now){
    if(!this.ledger)return {status:'UNKNOWN',reason:this.reason};
    const base=this.view().base;
    return stepJointNegotiation(this.ledger,{messageId:`${command.type}:${++this.messages}`,...command},{origin,epoch:base.authority.epoch,clock:base.clock,now:Math.max(0,Math.floor(now))});
  }
  // A gesture proposed: `content` its record (its hold's terms in `hold`), `firstActionAt` its bar's tick, `commitBy`
  // the tick by which every section must have readied it, `validThrough` the tick it is played to. -> {planId, planHash}
  // or null where the ledger refuses it (its allowance spent, a stale plan).
  propose({planId,content,firstActionAt,commitBy,validThrough,now}){
    const snapshot=this.view();if(!snapshot)return null;
    const first=Math.floor(firstActionAt),by=Math.floor(commitBy),through=Math.max(first,Math.floor(validThrough));
    if(!(now<by&&by<=first))return null;
    const out=this.step({type:'reserve',proposal:{id:planId,revision:snapshot.base.parent.revision+1,base:snapshot.base,
      members:this.members.map(member=>({...member,firstActionAt:first})),commitBy:by,effectiveAt:by,validThrough:through,
      charges:[{budgetId:'gestures',amount:1}],content}},this.coordinator,now);
    if(out.status!=='APPLIED')return null;
    const plan=this.view().plans.find(item=>item.id===planId);return plan?{planId,planHash:plan.hash}:null;
  }
  // A section's readiness, as it said it (its `preparation`: the gesture as it will strike it). -> the ledger's status.
  accept({planId,planHash,member,preparation,now}){
    const plan=this.view()?.plans.find(item=>item.id===planId);if(!plan)return 'UNKNOWN';
    return this.step({type:'accept',planId,planHash,preparedAt:Math.floor(now),validThrough:plan.proposal?.validThrough??plan.validThrough,preparation:reference(`${member.id}:${planId}`,preparation)},member,now).status;
  }
  // Committed where every section readied it before its deadline and its contract holds: -> 'COMMITTED', else null.
  commit({planId,planHash,now}){
    const out=this.step({type:'commit',planId,planHash},this.coordinator,now);
    return out.status==='APPLIED'&&out.effect==='COMMITTED'?'COMMITTED':null;
  }
  // Those not readied by their deadlines let go (their allowance released).
  advance(now){return this.step({type:'advance'},this.coordinator,now).status}
}
