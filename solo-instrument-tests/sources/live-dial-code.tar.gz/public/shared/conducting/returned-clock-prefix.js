// Astra's returned-clock prefix check (research/fugue-and-coordination/candidates/returned-clock-prefix.js, RC1-RC4/P240,
// reviewed with orchestra-47): exact closure of an explicitly complete, ordered duration prefix against its original
// reference. The caller binds the actual emitted clock and its original reference. This does not observe a device.
import {dataArray,dataRecord} from './contract-data.js';
import {exactOf,exactText,add,sub,compare,pythonJson,sha256} from '../bounded-exact.js';

const scope='declared-complete-clock-prefix-boundaries';
const refuse=message=>{throw new Error(message)};
const ordinary=(value,keys)=>{
  if(!dataRecord(value)||Object.keys(value).length!==keys.length||keys.some(key=>!Object.hasOwn(value,key)))
    refuse('Complete ordinary data fields required');
  return value;
};
const name=value=>{if(typeof value!=='string'||!value.length||value.length>128)refuse('Bounded identity required');return value};
const rational=value=>{
  if(typeof value!=='string'||value.length>160||!/^[-+]?\d+(?:\/[1-9]\d*)?$/.test(value))
    refuse('Supply exact integer/fraction text; choose any approximation explicitly');
  return exactOf(value);
};

// Every segment is an elapsed duration in the SAME unit, along the SAME ordered reference prefix.
// initialOffset is actual minus reference at that prefix's start; maxOffset bounds its absolute value.
// complete is a caller assertion about source coverage, not evidence manufactured by this function.
export function auditReturnedClockPrefix(input){
  try{
    ordinary(input,['reference','complete','initialOffset','maxOffset','segments']);
    if(input.complete!==true)refuse('Complete reference prefix required');
    ordinary(input.reference,['id','revision','hash']);name(input.reference.id);
    if(!Number.isSafeInteger(input.reference.revision)||input.reference.revision<0
      ||typeof input.reference.hash!=='string'||!/^[a-f0-9]{64}$/.test(input.reference.hash))refuse('Versioned reference hash required');
    const initial=rational(input.initialOffset),cap=rational(input.maxOffset),zero=exactOf('0');
    if(compare(cap,zero)<0)refuse('Nonnegative absolute offset cap required');
    dataArray(input.segments,128,'Clock segments');const ids=new Set;
    const segments=input.segments.map(raw=>{
      ordinary(raw,['id','referenceSeconds','actualSeconds']);name(raw.id);
      if(ids.has(raw.id))refuse('Duplicate segment identity');ids.add(raw.id);
      const reference=rational(raw.referenceSeconds),actual=rational(raw.actualSeconds);
      if(compare(reference,zero)<=0||compare(actual,zero)<=0)refuse('Positive elapsed durations required');
      return Object.freeze({id:raw.id,referenceSeconds:exactText(reference),actualSeconds:exactText(actual)});
    });
    const snapshot=Object.freeze({reference:Object.freeze({...input.reference}),complete:true,
      initialOffset:exactText(initial),maxOffset:exactText(cap),segments:Object.freeze(segments)});
    const negativeCap=sub(zero,cap),violations=[],steps=[];let offset=initial;
    const check=(boundary,id)=>{
      if(compare(offset,negativeCap)<0||compare(offset,cap)>0)
        violations.push(Object.freeze({boundary,id,offset:exactText(offset)}));
    };
    check(0,null);
    for(const [index,segment] of segments.entries()){
      const delta=sub(rational(segment.actualSeconds),rational(segment.referenceSeconds));offset=add(offset,delta);
      steps.push(Object.freeze({...segment,delta:exactText(delta),offset:exactText(offset)}));check(index+1,segment.id);
    }
    return Object.freeze({status:violations.length?'FAIL':'PASS',scope,reference:snapshot.reference,
      bindingHash:sha256(pythonJson(snapshot)),initialOffset:snapshot.initialOffset,maxOffset:snapshot.maxOffset,
      finalOffset:exactText(offset),steps:Object.freeze(steps),violations:Object.freeze(violations)});
  }catch(error){return Object.freeze({status:'UNKNOWN',scope,reason:String(error?.message??error)})}
}
