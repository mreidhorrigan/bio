// A section's pools cleared out of a solo's register together (Astra's EC05/EC09, CFM-010 elastic-box-projection.js:
// an exact positive weighted affine compromise inside explicit coordinate boxes). Under another section's solo, every
// pool whose band overlaps the solo's moves away from it by the piece's clear share of their overlap (plex_clodbot.js
// clearOf), each alone -- so a pool moved down could land on the one below it, which had not moved. Here the pools on each
// side of the solo move together as a block (their spacing, the formation's voicing, kept: an equality between each two
// on one side), each pool's move the least its players weigh (its seats: a full pool reluctant, one player light), within
// the moves its players' compass permits (its box) and at least the move clearing its own share of the overlap (a bound
// on the side away from the solo): the projection solved exactly, and played as solved (its certificate checked in
// development: checkBoxAffineProjection). -> {centre: move}
// (semitones, a pool's id each), or null where it has more pools than it reads or no block fits (each then cleared
// alone).
import {projectBoxAffineEdits,BOX_PROJECTION_LIMITS} from './elastic-box-projection.js';

// (Semitones as exact text: millionths, as a pool's centre is written.)
const exact=x=>{const scale=1000000,n=Math.round(Number(x)*scale);const g=(a,b)=>{a=Math.abs(a);while(b){[a,b]=[b,a%b]}return a},d=g(n,scale)||1;return `${n/d}/${scale/d}`};
const valueOf=text=>{const [n,d='1']=String(text).split('/');return Number(n)/Number(d)};
// `pools` [{id, centre, half (its band's half-width), weight (its players), low, high (the centres its compass allows),
// clear (the move its own overlap asks: negative below the solo, positive above, 0 where it does not overlap)}];
// `register`: the solo's centre.
export function clearedTogether(pools,register){
  if(!pools.length||pools.length>BOX_PROJECTION_LIMITS.coordinates)return null;
  const below=pools.filter(pool=>pool.centre<register),above=pools.filter(pool=>pool.centre>=register);
  if(!pools.some(pool=>pool.clear))return Object.fromEntries(pools.map(pool=>[pool.id,0]));
  // (Each side's move: none toward the solo; at least its own clearing; within its compass.)
  const coordinates=pools.map(pool=>{const down=pool.centre<register,lower=Math.max(pool.low-pool.centre,down?-Infinity:Math.max(0,pool.clear)),upper=Math.min(pool.high-pool.centre,down?Math.min(0,pool.clear):Infinity);
    return {id:String(pool.id),unit:'semitones',target:'0',weight:exact(Math.max(1,pool.weight)),lock:null,lower:exact(lower),upper:exact(upper)}});
  if(coordinates.some(c=>valueOf(c.lower)>valueOf(c.upper)+1e-12))return null;
  const index=new Map(pools.map((pool,k)=>[pool.id,k])),equalities=[];
  for(const side of [below,above])for(let k=1;k<side.length;k++){const coefficients=pools.map(()=>'0');coefficients[index.get(side[0].id)]='1';coefficients[index.get(side[k].id)]='-1';
    equalities.push({id:`together:${side[0].id}:${side[k].id}`,coefficients,rhs:'0'})}
  const model={id:'solo-clearing',revision:1,coordinates,equalities};
  let out;try{out=projectBoxAffineEdits(model)}catch{return null}
  if(out.status!=='SAT'||!out.optimal)return null;
  return Object.fromEntries(pools.map((pool,k)=>[pool.id,valueOf(out.solution[k])]));
}
