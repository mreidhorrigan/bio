// Coordinated events (research/fugue-and-coordination/MUSEBOTS_DATA_AND_COORDINATED_EVENTS.md, DC06-DC08): a tutti hit,
// a cutoff held to its release, a shared silence and the reentry after it -- "A chord is not merely a zero-delay canon."
// One event joins many players at once by its anchor, each player's intended offset from it, its envelopes (how far the
// whole may yield, how tightly its players must agree), its hold and release, and the space around it.
//
// For each member i, its audible time is t_i = T + g + mu_i + e_i: T the event's anchor, g a displacement the whole
// shares (the groove's, a phrase's breath), mu_i its intended offset (a written stagger, a strum), e_i what is left
// (§6). Placement and tightness are separate promises: with the intended offsets taken away, z_i = t_i - mu_i,
//   placement = mean(z) - T      how far the whole moved
//   spread    = max(z) - min(z)  how far apart its members were
// and each is held to its own elastic contract (elastic.js): the whole may yield to a phrase while its members still
// strike together. A mean hides one late member; the spread does not.
//
// Times here are seconds of one clock (the render's). Unknown is unknown: a member whose lag or uncertainty is not known
// makes its event's certificate UNKNOWN, never as if it were 0 (§7.3).
import {elasticContract,held} from './elastic.js';
import {intersectGestureAnchors,certifyGestureSpread,gestureTimeFromNumber} from './gesture-bounds.js';
import {auditGestureCoverage} from './gesture-coverage.js';
import {continuationViability} from './continuation-viability.js';

// (Exact: each number read as the value its binary64 represents (Astra's gestureTimeFromNumber, CFM-007), never one
// missing given as 0; each member's uncertainty its own error component, a bound on its timing's support. A number not
// finite is missing.)
const exactTime=value=>value==null||!finite(Number(value))?null:gestureTimeFromNumber(Number(value));
const numberOf=x=>{if(x==null)return null;const [n,d='1']=String(x).split('/');return Number(n)/Number(d)};

export const COORDINATED_KINDS=Object.freeze(['hit','hold-cutoff','rest-reentry','unison']);
const finite=Number.isFinite;

// An event, checked and frozen (DC06). `roles`: the members it needs (seat ids, or parts); `anchor`: its time, in the
// caller's terms (a bar and beat, or seconds) and kept as given; `offsets`: {role: s} intended (0 where unsaid);
// `placement`, `spread`: elastic contracts in seconds (elasticContract's fields, or contracts); `hold`: s from the
// attack to the cutoff (a hit's or a held chord's); `silence`: s after the cutoff in which nothing of `roles` sounds
// (a general pause), `exempt`: roles whose tails may sound in it; `revision`, `parent`: its plan's.
export function coordinatedEvent({id,revision=1,parent=null,kind,roles,anchor,offsets={},placement,spread,hold=null,silence=0,exempt=[]}){
  if(typeof id!=='string'||!id)throw new TypeError('A coordinated event has an id');
  if(!COORDINATED_KINDS.includes(kind))throw new RangeError(`A coordinated event is one of ${COORDINATED_KINDS.join(', ')}`);
  if(!Array.isArray(roles)||!roles.length||new Set(roles).size!==roles.length)throw new TypeError(`Event ${id} names its members once each`);
  for(const [role,mu] of Object.entries(offsets))if(!roles.includes(role)||!finite(Number(mu)))throw new RangeError(`Event ${id}: an offset for a member it has, in seconds`);
  if(hold!=null&&!(Number(hold)>0))throw new RangeError(`Event ${id}: its hold is positive`);
  if(!(Number(silence)>=0))throw new RangeError(`Event ${id}: its silence is not negative`);
  const contract=(value,name)=>value&&Object.isFrozen(value)&&value.relation?value:elasticContract({id:`${id}:${name}`,relation:name,units:'s',...value});
  return Object.freeze({id,revision,parent,kind,roles:Object.freeze([...roles]),anchor:Object.freeze(typeof anchor==='object'?{...anchor}:{at:anchor}),
    offsets:Object.freeze(Object.fromEntries(roles.map(role=>[role,Number(offsets[role]??0)]))),
    placement:contract(placement,'placement'),spread:contract(spread,'spread'),hold:hold==null?null:Number(hold),silence:Number(silence),exempt:Object.freeze([...exempt])});
}

// Where the whole was and how far apart its members were (DC07): `times` {role: s, audible}, `T` the anchor (s).
// -> {placement, spread, z: {role: s}, missing: [roles]}; placement and spread null where a member is missing.
export function placementAndSpread(event,times,T){
  const z={},missing=[];
  for(const role of event.roles){const t=Number(times?.[role]);if(times?.[role]==null||!finite(t))missing.push(role);else z[role]=t-event.offsets[role]}
  const values=Object.values(z);
  if(missing.length||!values.length)return {placement:null,spread:null,z,missing};
  return {placement:values.reduce((a,b)=>a+b,0)/values.length-T,spread:Math.max(...values)-Math.min(...values),z,missing};
}

// An event as it sounded, held to its contracts: {status, placement, spread} each held(), and the event's status the
// worst of them (fail over unknown over pass).
export function auditAlignment(event,times,T){
  const {placement,spread,missing}=placementAndSpread(event,times,T);
  const p=held(event.placement,placement),s=held(event.spread,spread),statuses=[p.status,s.status];
  return Object.freeze({status:statuses.includes('fail')?'fail':statuses.includes('unknown')?'unknown':'pass',placement:p,spread:s,missing:Object.freeze(missing)});
}

// A common anchor its members can all reach (DC08, §7.1): member i sounds within [lo, hi] (s), with an intended offset
// mu and an uncertainty u (its timing's bound, not its standard deviation), so its anchor must keep
// lo + u - mu <= T <= hi - u - mu. Intersected over its members and the event's own `window` [a, b].
// -> {status: 'feasible' | 'empty' | 'unknown', interval: [lo, hi] | null, unknown: [roles]}.
// (Exact: no tolerance turns an empty intersection feasible. A window or an offset not a number is unknown, not open.)
// (Exact (Astra's CFM-007, intersectGestureAnchors): its intersection a closed interval of exact rationals, a contradiction
// among the members known decisive whatever another's missing; an unbounded window the members' own span.)
export function feasibleAnchor(members,window=[-Infinity,Infinity]){
  let lo=Number(window?.[0]),hi=Number(window?.[1]);
  if(Number.isNaN(lo)||Number.isNaN(hi)||lo===Infinity||hi===-Infinity)return Object.freeze({status:'unknown',interval:null,unknown:Object.freeze(['window'])});
  const known=members.filter(m=>finite(Number(m.lo))&&finite(Number(m.hi)));
  if(lo===-Infinity)lo=known.length?Math.min(...known.map(m=>Number(m.lo)-Math.abs(Number(m.mu)||0))):0;
  if(hi===Infinity)hi=known.length?Math.max(...known.map(m=>Number(m.hi)+Math.abs(Number(m.mu)||0))):0;
  const roles=members.map(({role,lo:l,hi:h,mu=0},k)=>({id:String(role),revision:1,unit:'seconds',window:{lo:exactTime(l),hi:exactTime(h)},offset:mu==null?null:exactTime(mu),coefficients:members.map((_,j)=>j===k?1:0)}));
  const components=members.map(({role,u},k)=>({id:`u${k}`,revision:1,unit:'seconds',kind:'absolute-bound',bound:u==null||!finite(Number(u))||Number(u)<0?null:exactTime(u)}));
  const out=intersectGestureAnchors({id:'coordinated-anchor',revision:1,clockDomain:{id:'render',revision:1,unit:'seconds'},roles,components,window:{lo:exactTime(lo),hi:exactTime(hi)}});
  const unknown=members.filter((m,k)=>m.u==null||!finite(Number(m.u))||Number(m.u)<0||m.lo==null||m.hi==null||!finite(Number(m.lo))||!finite(Number(m.hi))||!finite(Number(m.mu??0))).map(m=>m.role);
  if(out.status==='EMPTY')return Object.freeze({status:'empty',interval:null,unknown:Object.freeze(unknown)});
  if(out.status==='FEASIBLE')return Object.freeze({status:'feasible',interval:Object.freeze([numberOf(out.interval.lo),numberOf(out.interval.hi)]),unknown:Object.freeze([])});
  return Object.freeze({status:'unknown',interval:out.interval?Object.freeze([numberOf(out.interval.lo),numberOf(out.interval.hi)]):null,unknown:Object.freeze(unknown.length?unknown:['model'])});
}

// When each member acts so that its sound lands on its target (§7.2): command = target + mu - lag, its lag the time from
// its action to its audible landmark (a bow's catch, a breath's onset, a hammer's travel). `lags` {role: s}.
// -> {status: 'known' | 'unknown', times: {role: s}, unknown: [roles]}: a member whose lag is not known acts at its
// target, and says so.
export function commandTimes(event,T,lags){
  const times={},unknown=[];
  for(const role of event.roles){
    const lag=Number(lags?.[role]),target=T+event.offsets[role];
    if(lags?.[role]==null||!finite(lag)){unknown.push(role);times[role]=target}else times[role]=target-lag;
  }
  return Object.freeze({status:unknown.length?'unknown':'known',times:Object.freeze(times),unknown:Object.freeze(unknown)});
}

// Whether its members' spread is surely within epsilon (§7.3): their nominal times z {role: s} and independent
// uncertainty bounds u {role: s}, every pair |z_i - z_j| + u_i + u_j <= epsilon. -> 'pass' | 'fail' | 'unknown'.
// (Every nominal time and the bound finite, every uncertainty finite and not negative, else unknown: a NaN fails no
// comparison and would pass.)
// (Exact (Astra's CFM-007, certifyGestureSpread): the box's worst case, each member's own error component.)
export function robustSpread(z,u,epsilon){
  const roles=Object.keys(z??{});
  if(!finite(Number(epsilon))||Number(epsilon)<0||roles.some(role=>!finite(Number(z[role]))||u?.[role]==null||!finite(Number(u[role]))||Number(u[role])<0))return 'unknown';
  const out=certifyGestureSpread({id:'coordinated-spread',revision:1,clockDomain:{id:'render',revision:1,unit:'seconds'},
    roles:roles.map((role,k)=>({id:String(role),revision:1,unit:'seconds',nominal:exactTime(z[role]),offset:'0',coefficients:roles.map((_,j)=>j===k?1:0)})),
    components:roles.map((role,k)=>({id:`u${k}`,revision:1,unit:'seconds',kind:'absolute-bound',bound:exactTime(u[role])})),epsilon:exactTime(epsilon)});
  return out.status==='PASS'?'pass':out.status==='FAIL'?'fail':'unknown';
}

// Whether nothing of the event's members sounds in its silence (§8): `intervals` [{role, from, to}] (s, half-open,
// as sounded), `from` the silence's start; an exempt member's sound in it allowed. -> {status, sounding: [intervals]}.
// (Declared intervals, not a waveform: a hall's tail is not heard here.)
// (Exact: any overlap of a member's half-open sounding with the silence fails it; an interval whose ends are not numbers
// leaves it unknown.)
export function auditSilence(event,intervals,from){
  const to=from+event.silence,exempt=new Set(event.exempt),members=new Set(event.roles);
  if(!finite(from))return Object.freeze({status:'unknown',sounding:Object.freeze([])});
  const mine=intervals.filter(({role})=>members.has(role)&&!exempt.has(role));
  if(mine.some(({from:a,to:b})=>!finite(Number(a))||!finite(Number(b))))return Object.freeze({status:'unknown',sounding:Object.freeze([])});
  const sounding=mine.filter(({from:a,to:b})=>a<to&&b>from);
  return Object.freeze({status:sounding.length?'fail':'pass',sounding:Object.freeze(sounding)});
}

// A coordinated hit's whole gesture as planned, audited on its notes (Astra's CFM-008, gesture-coverage.js): every member
// its plan names -- not those the notes happen to show -- struck within `tolerance` of the downbeat `T`, the seated ones
// (`seated`) held and released within it of `held`, the rest (`ringing`: the percussion's rings, which the general pause
// allows) free to ring; and nothing of the seated ones through the pause from their release to `until` (the next
// downbeat), every one of their notes the review window meets checked. `hitOf(role)` its hit note ({from, to}, s) or
// null; `others` the seated players' other notes [{id, role, from, to}]; `layer` which times these are ('planned',
// 'scheduled', 'executed', 'acoustic'). A missing member a failure of a complete observation, never unknown or passed.
// -> the coverage audit ({status, checks, inventory}).
export function auditPunctuation({id,T,held,until,tolerance,seated,ringing=[],hitOf,others=[],layer='scheduled'}){
  const hits=[...seated,...ringing].map(role=>[role,hitOf(role)]),ends=hits.filter(([,note])=>note).map(([,note])=>note.to);
  const from=T-tolerance,to=Math.max(until,...ends,held+tolerance);
  const expected=[...seated.map(role=>({id:`${role}:hit`,role,kind:'attack',attackWindow:[T-tolerance,T+tolerance],releaseWindow:[held-tolerance,held+tolerance],
      hold:[Math.max(0,held-T-2*tolerance),held-T+2*tolerance],afterSilence:null})),
    ...ringing.map(role=>({id:`${role}:hit`,role,kind:'attack',attackWindow:[T-tolerance,T+tolerance],releaseWindow:[T,to],hold:[0,to-T],afterSilence:null}))];
  const observed=[...hits.filter(([,note])=>note).map(([role,note])=>({id:`${role}:hit`,role,from:note.from,to:note.to})),
    ...others.filter(note=>note.from<to&&note.to>from).map(note=>({id:String(note.id),role:note.role,from:note.from,to:note.to}))];
  const pause=until>held+tolerance?[{id:`${id}:pause`,window:[held+tolerance,until],roles:[...seated],exemptEventIds:[]}]:[];
  // (Every time exact: the value its binary64 represents.)
  const x=gestureTimeFromNumber,span=([a,b])=>[x(a),x(b)];
  return auditGestureCoverage({id:String(id),revision:1,clock:{id:'render',revision:1,kind:'wall',unit:'s'},layer,window:span([from,to]),roles:[...seated,...ringing],
    additionalEvents:'allow',expected:expected.map(e=>({...e,attackWindow:span(e.attackWindow),releaseWindow:span(e.releaseWindow),hold:span(e.hold)})),
    silences:pause.map(p=>({...p,window:span(p.window)})),observed:{complete:true,events:observed.map(o=>({...o,from:x(o.from),to:x(o.to)}))},
    requiredEvidence:{preparation:{id:'planned-sustain',revision:1,status:'PASS'},authority:{id:'conductor-plan',revision:1,status:'PASS'}}});
}

// A hit's hold chosen so that the next section can still enter (Astra's CFM-009, continuation-viability.js: an attractive
// choice must not exhaust what a required return needs): each candidate hold (`holds`, beats, in the planner's order of
// preference: its drawn felt beats first, then the meter's smaller levels) spends its players' breath (`breath`, s: what
// every member sustains at the hit's dynamic) by its length at its slowest (`beatSeconds`); and from its release the
// next section's entry is reached only where the general pause to the bar's end (`barBeats` less the hold, at
// `pauseBeatSeconds` a beat) leaves its players a catch breath (`space`, s). The first hold with a viable continuation,
// as its solver finds it (its policy audited in development: auditContinuationPolicy). -> {status ('VIABLE', 'INFEASIBLE' or 'UNKNOWN'), beats, reason}.
export function viableHold({holds,breath,beatSeconds,pauseBeatSeconds,barBeats,space}){
  const ms=x=>Math.max(0,Math.round(x*1000)),unique=[...new Set(holds.map(b=>+Number(b).toFixed(6)))].filter(b=>b>0&&b<barBeats);
  if(!unique.length)return {status:'UNKNOWN',beats:null,reason:'no hold within the bar'};
  const decision=(id,outcomes,cost)=>({id,costs:[cost],changedEventIds:[],checks:[{id:'sustained',status:'PASS'}],outcomesComplete:true,outcomes});
  const states=[{id:'struck',goal:'FAIL',decisionsComplete:true,decisions:unique.map((b,k)=>decision(`hold${k}`,[`released${k}`],Math.ceil(b*beatSeconds*1000)))},
    ...unique.map((b,k)=>({id:`released${k}`,goal:'FAIL',decisionsComplete:true,decisions:(barBeats-b)*pauseBeatSeconds>=space-1e-9?[decision(`enter${k}`,['entered'],0)]:[]})),
    {id:'entered',goal:'PASS',decisionsComplete:true,decisions:[]}];
  const model={id:'punctuation-hold',revision:1,referenceHash:'0'.repeat(64),lockedEventIds:[],goalPredicate:'next-section-enters',requiredPredicates:['sustained'],
    resources:[{id:'breath',unit:'ms',remaining:ms(breath)}],start:'struck',horizon:2,states};
  let out;try{out=continuationViability(model)}catch(error){return {status:'UNKNOWN',beats:null,reason:String(error?.message??error)}}
  if(out.status!=='VIABLE')return {status:out.status,beats:null,reason:out.reason??null};
  const first=out.policy.rows.find(row=>row.nodeId==='struck');
  const k=Number(String(first.actionId).replace('hold',''));return {status:'VIABLE',beats:unique[k]};
}
