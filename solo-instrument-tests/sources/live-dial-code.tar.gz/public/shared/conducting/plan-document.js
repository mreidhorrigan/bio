// A piece plan as a document (Musebots 3.0's eighth lack, docs/MUSEBOTS_3.md: "the composition end of the continuum for
// people: a plan saved, edited, replayed or read from a score"). A conductor's plan of a piece -- its form's sections and
// what it decided with each (their harmony, their constraints) -- written out as a person can read and edit it, and
// given back to a conductor (plex_clodbot's settings.plan), which plays it.
//
// A document need not be whole. Each section gives as much as its writer wants -- its role alone, or any of a section's
// fields -- and the conductor draws the rest as it draws any section, from its seed (keyed to the section, so a field
// changed changes nothing else), then lays the given fields over its draw. A section's layers given (harmony,
// constraints) are taken as they are, the others decided. So a saved plan plays back as it was, an edited one as edited,
// and a plan of roles alone is a form the conductor fills.
//
//   {version: 1, kind: 'piece-plan', archetype?, sections: [{role, numerator?, denominator?, groups?, subdivision?,
//    phraseBars?, phrases?, tempo?: {targetBpm, shape?, durationBars?}, hdensity?, vdensity?, rhythm?: {hits, rotation},
//    layers?: {harmony?, constraints?, ...}}]}
import {STOCHASTIC_CONFIG as CONFIG} from '../../stochastic-config.js';
import {defaultGrouping} from '../rhythm.js';

// ---- Choices (ours) ---------------------------------------------------------------------------------------------------
// A section's fields a document may give, and the bounds a given one must keep (a tempo in beats of the denominator a
// minute, as mh_PlexBOT's; a density from 0 to 1).
export const PLAN_DOCUMENT=Object.freeze({
  fields:Object.freeze(['role','numerator','denominator','groups','subdivision','phraseBars','phrases','tempo','hdensity','vdensity','rhythm','layers']),
  numerator:Object.freeze([1,128]),denominator:Object.freeze([1,64]),subdivision:Object.freeze([1,16]),phraseBars:Object.freeze([1,64]),
  phrases:Object.freeze([1,64]),bpm:Object.freeze([20,300]),sections:64,
});
// The layers a document gives back as they were decided (a canon's parts are drawn again from the harmony heard, and a
// section's formations by its own conductor).
export const PLAN_LAYERS=Object.freeze(['harmony','constraints','meters','fugue']);
// The form's roles a section may take: mh_PlexBOT's.
export const PLAN_ROLES=Object.freeze(Object.keys(CONFIG.plex.roleComplexity));

const fail=message=>{throw new RangeError(`A plan document: ${message}`)};
const whole=(value,[low,high],what)=>{if(!(Number.isInteger(value)&&value>=low&&value<=high))fail(`${what} is a whole number from ${low} to ${high}, not ${value}`);return value};
const unit=(value,what)=>{if(!(typeof value==='number'&&value>=0&&value<=1))fail(`${what} is from 0 to 1, not ${value}`);return value};

// A document checked: its sections' given fields within their bounds, a grouping summing to its numerator, a role
// mh_PlexBOT knows; fields it does not know refused (a misspelt one would be ignored silently). -> a frozen copy.
export function checkedPlanDocument(document){
  if(!document||typeof document!=='object'||!Array.isArray(document.sections))fail('it has its sections');
  if(document.version!=null&&document.version!==1)fail(`version ${document.version} is not 1`);
  if(!document.sections.length||document.sections.length>PLAN_DOCUMENT.sections)fail(`it has 1 to ${PLAN_DOCUMENT.sections} sections`);
  const sections=document.sections.map((given,k)=>{
    const what=`section ${k+1}`;
    if(!given||typeof given!=='object')fail(`${what} is an object`);
    const unknown=Object.keys(given).filter(key=>!PLAN_DOCUMENT.fields.includes(key));if(unknown.length)fail(`${what} has no field ${unknown.join(', ')}`);
    if(!PLAN_ROLES.includes(given.role))fail(`${what}'s role is one of ${PLAN_ROLES.join(', ')}, not ${given.role}`);
    const out={role:given.role};
    for(const key of ['numerator','denominator','subdivision','phraseBars','phrases'])if(given[key]!=null)out[key]=whole(given[key],PLAN_DOCUMENT[key],`${what}'s ${key}`);
    if(given.groups!=null){
      if(!Array.isArray(given.groups)||!given.groups.length||!given.groups.every(g=>Number.isInteger(g)&&g>=1))fail(`${what}'s groups are whole numbers`);
      const sum=given.groups.reduce((a,b)=>a+b,0),numerator=out.numerator??sum;
      if(sum!==numerator)fail(`${what}'s groups sum to ${sum}, not its numerator ${numerator}`);
      out.groups=[...given.groups];out.numerator=numerator;
    }
    if(given.tempo!=null){
      const bpm=given.tempo?.targetBpm;if(!(typeof bpm==='number'&&bpm>=PLAN_DOCUMENT.bpm[0]&&bpm<=PLAN_DOCUMENT.bpm[1]))fail(`${what}'s tempo is ${PLAN_DOCUMENT.bpm.join(' to ')} beats a minute, not ${bpm}`);
      out.tempo={...given.tempo};
    }
    for(const key of ['hdensity','vdensity'])if(given[key]!=null)out[key]=unit(given[key],`${what}'s ${key}`);
    if(given.rhythm!=null){if(typeof given.rhythm!=='object')fail(`${what}'s rhythm is an object`);out.rhythm={...given.rhythm}}
    if(given.layers!=null){if(typeof given.layers!=='object'||Array.isArray(given.layers))fail(`${what}'s layers are an object`);out.layers=structuredClone(given.layers)}
    return Object.freeze(out);
  });
  return Object.freeze({version:1,kind:'piece-plan',...(typeof document.archetype==='string'?{archetype:document.archetype}:{}),sections:Object.freeze(sections)});
}

// A section drawn (mh_PlexBOT's generateSection) with a document's section laid over it: each given field taken; a
// numerator given without its groups grouped as mh_PlexBOT groups one; a tempo given kept whole where it is whole, else
// its target over the draw's shape. -> the section.
export function overlaySection(drawn,given){
  if(!given)return drawn;
  const out={...drawn};
  for(const key of ['role','numerator','denominator','subdivision','phraseBars','phrases','hdensity','vdensity'])if(given[key]!=null)out[key]=given[key];
  if(given.groups)out.groups=[...given.groups];else if(given.numerator!=null&&given.numerator!==drawn.numerator)out.groups=defaultGrouping(given.numerator);
  if(given.tempo)out.tempo={...drawn.tempo,...given.tempo};
  if(given.rhythm)out.rhythm={...drawn.rhythm,...given.rhythm};
  return out;
}

// A conductor's plan as a document: its form's sections (its form plan's payload) and their layers (its piece plan's
// units), each section its fields and its layers as decided, nothing a conductor derives from them (its bars, its bar's
// seconds, whether it is the last). -> the document.
export function planDocumentOf({form,piece=null}){
  const sections=form?.sections??[];if(!sections.length)fail('the form plan has its sections');
  const layersOf=index=>piece?.units?.find(unit=>unit.index===index)?.layers??null;
  return {version:1,kind:'piece-plan',...(form.archetype?{archetype:form.archetype}:{}),
    sections:sections.map((section,index)=>{
      const out={};for(const key of PLAN_DOCUMENT.fields)if(key!=='layers'&&section[key]!=null)out[key]=structuredClone(section[key]);
      // (The layers a document can give back: what the conductor decided, not its contingencies' outcome or its
      // children's answers.)
      const layers=layersOf(section.id??index),kept=layers?Object.fromEntries(Object.entries(layers).filter(([id,value])=>value!=null&&PLAN_LAYERS.includes(id))):null;
      if(kept&&Object.keys(kept).length)out.layers=structuredClone(kept);
      return out;
    })};
}
