// CFM-027 / CF27: exact cyclic onset construction. No pitch, sustained-sound or physical certificate is implied.
import {Refused,exactOf,exactText,add,mul,pythonJson,sha256} from '../bounded-exact.js';
import {dataRecord,dataArray} from './contract-data.js';

export const RHYTHMIC_TILING_LIMITS=Object.freeze({maxPeriod:512,maxNodes:8192,maxWork:2000000,
  maxOccurrences:8192,maxDependencies:128,maxTextChars:4194304});
const freeze=Object.freeze,models=new WeakMap,rawBound=1n<<256n,scope='declared-cyclic-onset-tiling-only';
const fail=(reason,kind='invalid-input')=>{throw new Refused(reason,{kind})};
class BadCertificate extends Error {}
const requireCertificate=(yes,reason)=>{if(!yes)throw new BadCertificate(reason)};
function stateOf(options){
  if(!dataRecord(options)||Object.keys(options).some(k=>!Object.hasOwn(RHYTHMIC_TILING_LIMITS,k)))fail('Unknown tiling limits');
  const limits={};for(const [key,cap] of Object.entries(RHYTHMIC_TILING_LIMITS)){
    const value=Object.hasOwn(options,key)?options[key]:cap;
    if(!Number.isSafeInteger(value)||value<0||value>cap)fail('Tiling limits may only lower their declared caps');limits[key]=value;
  }
  const s={limits:freeze(limits),used:0,chars:0,modelHash:null};
  s.charge=(n=1)=>{if(!Number.isSafeInteger(n)||n<0)throw new Error('Invalid work charge');
    if(n>limits.maxWork-s.used)fail('Tiling work allowance exhausted','work-budget');s.used+=n};s.charge();return s;
}
function fields(v,keys,s){
  s.charge();if(!dataRecord(v)||Object.keys(v).length!==keys.length||keys.some(k=>!Object.hasOwn(v,k)))fail('Missing or unsupported tiling fields');
  s.charge(keys.length);return v;
}
function list(v,limit,s,label){
  if(!Array.isArray(v)||v.length>limit)fail(label+' exceeds array allowance','shape-budget');s.charge(v.length+1);return dataArray(v,limit,label);
}
function text(v,s,cap=256){
  if(typeof v!=='string'||!v.length||v.length>cap)fail('Bounded nonempty text required');
  if(v.length>s.limits.maxTextChars-s.chars)fail('Tiling text allowance','work-budget');s.chars+=v.length;s.charge(1+Math.ceil(v.length/64));return v;
}
function natural(v,label){if(!Number.isSafeInteger(v)||v<0)fail('Invalid '+label);return v}
function rawInteger(v){
  const n=typeof v==='bigint'?v:Number.isSafeInteger(v)?BigInt(v):null;
  if(n===null||n<=-rawBound||n>=rawBound)fail('Raw exact components need at most256bits','arithmetic-budget');return n;
}
function rational(v,s){
  s.charge();let n,d=1n;
  if(typeof v==='string'){
    text(v,s,160);const m=v.match(/^([+-]?[0-9]+)(?:\/([+-]?[0-9]+))?$/);
    if(!m||m[0].length!==v.length)fail('Use exact integer or fraction text');n=rawInteger(BigInt(m[1]));d=rawInteger(BigInt(m[2]??'1'));
  }else if(v&&typeof v==='object'){fields(v,['n','d'],s);n=rawInteger(v.n);d=rawInteger(v.d)}else n=rawInteger(v);
  if(!d)fail('Zero denominator');return exactOf({n,d});
}
function deepFreeze(v){if(v&&typeof v==='object'&&!Object.isFrozen(v)){for(const x of Object.values(v))deepFreeze(x);freeze(v)}return v}
function hash(v,s){
  // Only bounded, internally reconstructed data reach this encoder, never a raw certificate or caller callback.
  const encoded=pythonJson(v);if(encoded.length>s.limits.maxTextChars)fail('Canonical tiling text allowance','work-budget');
  s.charge(1+Math.ceil(encoded.length/64));return sha256(encoded);
}
function residue(v,N){if(!Number.isSafeInteger(v))fail('Slots must be exact safe integers');return ((v%N)+N)%N}
function offsets(v,N,s,label){
  const out=[],seen=new Set;for(const value of list(v,N,s,label)){
    s.charge();const x=residue(value,N);if(seen.has(x))fail('Duplicate cyclic offset');seen.add(x);out.push(x);
  }out.sort((a,b)=>{s.charge();return a-b});return freeze(out);
}
const bit=x=>1n<<BigInt(x);
const selectedOf=values=>values.reduce((m,x)=>m|bit(x),0n);
function valuesOf(mask,model,s){const out=[];for(const x of model.allowed){s.charge();if(mask&bit(x))out.push(x)}return out}
function primesOf(N,s){
  const out=[];let n=N;for(let p=2;p*p<=n;p++){
    s.charge();if(n%p)continue;out.push(p);do{s.charge();n/=p}while(n%p===0);
  }if(n>1)out.push(n);return freeze(out);
}
function periodicity(values,model,s){
  const set=new Set(values),tested=[];
  for(const prime of model.primes){
    const shift=model.N/prime;let brokenBy=null;
    for(const x of values){s.charge();if(!set.has((x+shift)%model.N)){brokenBy=x;break}}
    tested.push({prime,shift,brokenBy});
    if(brokenBy===null)return {periodic:true,witnessShift:shift,primeTests:tested};
  }return {periodic:false,witnessShift:null,primeTests:tested};
}
function normalize(raw,s){
  fields(raw,['id','revision','periodSlots','inner','allowedOffsets','requiredOffsets','offsetsComplete','mode','clock','dependencies'],s);
  const id=text(raw.id,s),revision=natural(raw.revision,'revision'),N=natural(raw.periodSlots,'period');
  if(N<1||N>s.limits.maxPeriod)fail('Cyclic period allowance','shape-budget');
  if(!['tiling','vuza'].includes(raw.mode)||typeof raw.offsetsComplete!=='boolean')fail('Declare tiling/vuza mode and offset inventory completeness');
  const inner=[],ids=new Set,slots=new Set;
  for(const value of list(raw.inner,N,s,'Inner pattern')){
    fields(value,['id','slot'],s);const name=text(value.id,s),slot=residue(value.slot,N);
    if(ids.has(name)||slots.has(slot))fail('Inner identities and cyclic slots must be unique');ids.add(name);slots.add(slot);inner.push(freeze({id:name,slot}));
  }
  if(!inner.length)fail('A nonempty fixed inner onset set is required');inner.sort((a,b)=>{s.charge();return a.slot-b.slot});freeze(inner);
  const allowed=offsets(raw.allowedOffsets,N,s,'Allowed offsets'),required=offsets(raw.requiredOffsets,N,s,'Required offsets'),allowedSet=new Set(allowed);
  if(required.some(x=>!allowedSet.has(x)))fail('Every required offset must be explicitly allowed');
  const c=fields(raw.clock,['id','revision','unit','phase','slotDuration'],s),phase=rational(c.phase,s),slotDuration=rational(c.slotDuration,s);
  if(slotDuration.n<=0n)fail('Slot duration must be strictly positive');
  const clock=freeze({id:text(c.id,s),revision:natural(c.revision,'clock revision'),unit:text(c.unit,s),phase,slotDuration});
  const dependencies=[],depIds=new Set;
  for(const value of list(raw.dependencies,s.limits.maxDependencies,s,'Dependencies')){
    fields(value,['id','revision','hash'],s);const name=text(value.id,s),h=text(value.hash,s);
    if(depIds.has(name)||h.length!==64||!/^[0-9a-f]{64}$/.test(h))fail('Unique dependencies and lowercase SHA-256 required');depIds.add(name);
    dependencies.push(freeze({id:name,revision:natural(value.revision,'dependency revision'),hash:h}));
  }
  const definition=deepFreeze({kind:'rhythmic-tiling-v1',id,revision,periodSlots:N,inner,allowedOffsets:allowed,requiredOffsets:required,
    offsetsComplete:raw.offsetsComplete,mode:raw.mode,clock:{...clock,phase:exactText(phase),slotDuration:exactText(slotDuration)},dependencies});
  s.modelHash=hash(definition,s);const translated=new Map;
  for(const b of allowed){let mask=0n;for(const a of inner){s.charge();mask|=bit((a.slot+b)%N)}translated.set(b,mask)}
  return {definition,N,inner,allowed,required,allowedMask:selectedOf(allowed),requiredMask:selectedOf(required),
    complete:raw.offsetsComplete,mode:raw.mode,clock,primes:primesOf(N,s),translated,full:(1n<<BigInt(N))-1n};
}
function modelOf(prepared,s){
  const model=models.get(prepared);if(!model)fail('An authentic prepared tiling model is required','out-of-model');
  s.modelHash=hash(model.definition,s);
  if(model.N>s.limits.maxPeriod||model.definition.dependencies.length>s.limits.maxDependencies)fail('Prepared tiling shape allowance','shape-budget');return model;
}
function result(s,status,reason,extra={}){return freeze({status,reason,scope,modelHash:s?.modelHash??null,workUsed:s?.used??0,resourceLimits:s?.limits??null,...extra})}
function run(options,body){let s;try{s=stateOf(options);return body(s)}catch(e){return result(s,e instanceof BadCertificate?'FAIL':'UNKNOWN',e.message??'Tiling refused',
  {kind:e instanceof Refused?e.kind:e instanceof BadCertificate?'invalid-certificate':'internal-error',conclusion:null})}}

/** Snapshots the declared finite cyclic domain. Preparation PASS is not a tiling or performance verdict. */
export function prepareRhythmicTiling(spec,options={}){
  return run(options,s=>{const model=normalize(spec,s),prepared=freeze({kind:'prepared-rhythmic-tiling-v1',modelHash:s.modelHash,definition:model.definition});
    models.set(prepared,model);return result(s,'PASS','Finite onset model prepared',{prepared})});
}
function coverageOf(model,entries,s){
  if(model.inner.length*entries.length>s.limits.maxOccurrences)fail('Expanded onset occurrence allowance','shape-budget');
  s.charge(model.N);const counts=Array(model.N).fill(0);
  for(const b of entries)for(const a of model.inner){s.charge();counts[(a.slot+b)%model.N]++}return counts;
}
function reportOf(model,entries,s){
  const allowed=new Set(model.allowed),chosen=new Set(entries),domain=entries.every(b=>allowed.has(b))&&model.required.every(b=>chosen.has(b));
  const coverage=coverageOf(model,entries,s),tiles=coverage.every(x=>x===1),innerPeriodicity=periodicity(model.inner.map(x=>x.slot),model,s),entryPeriodicity=periodicity(entries,model,s);
  const nontrivial=model.inner.length>1&&entries.length>1,vuza=tiles&&nontrivial&&!innerPeriodicity.periodic&&!entryPeriodicity.periodic;
  s.charge();const period=mul(model.clock.slotDuration,exactOf(model.N)),onsets=[];
  for(const b of entries)for(const a of model.inner){
    s.charge(3);const sum=a.slot+b,slot=sum%model.N,time=add(model.clock.phase,mul(model.clock.slotDuration,exactOf(slot)));
    onsets.push({innerId:a.id,innerSlot:a.slot,entryOffset:b,entryCycle:sum<model.N?0:-1,slot,time:exactText(time)});
  }
  onsets.sort((a,b)=>{s.charge();return a.slot-b.slot||a.entryOffset-b.entryOffset});
  return deepFreeze({status:domain&&tiles&&(model.mode==='tiling'||vuza)?'PASS':'FAIL',scope,modelHash:s.modelHash,
    entries,domain,offsetInventoryComplete:model.complete,coverage,tiles,nontrivial,vuza,innerPeriodicity,entryPeriodicity,
    clock:{...model.definition.clock,period:exactText(period)},onsets});
}

/** Direct original-pair audit: coverage, factor periodicity and exact affine onset times are separate evidence. */
export function auditRhythmicTiling(prepared,entryOffsets,options={}){
  return run(options,s=>{const model=modelOf(prepared,s),entries=offsets(entryOffsets,model.N,s,'Candidate entry offsets'),report=reportOf(model,entries,s);
    hash(report,s);return result(s,report.status,'Declared onset and factor predicates audited',{report})});
}
function obstructionOf(model,s){
  if(model.N%model.inner.length)return {kind:'cardinality',witness:null};
  if(model.mode==='vuza'){
    if(model.inner.length===1||model.inner.length===model.N)return {kind:'trivial-factor',witness:null};
    const p=periodicity(model.inner.map(x=>x.slot),model,s);if(p.periodic)return {kind:'inner-period',witness:p.witnessShift};
  }
  const counts=coverageOf(model,model.required,s),overlap=counts.findIndex(x=>x>1);
  return overlap<0?null:{kind:'required-overlap',witness:overlap};
}
function requireComplete(model){if(!model.complete)fail('No failure claim from an incomplete offset inventory','missing-evidence')}
function satResult(model,entries,visited,s){
  const report=reportOf(model,entries,s);if(report.status!=='PASS')throw new Error('Constructed tiling failed its direct audit');
  const certificate=deepFreeze({kind:'rhythmic-tiling-sat-v1',modelHash:s.modelHash,entries,reportHash:hash(report,s)});hash(certificate,s);
  return result(s,'SAT','A directly audited entry factor satisfies the declared contract',{report,certificate,visitedNodes:visited});
}

/** Bounded complete uncovered-slot branching. A refusal is UNKNOWN, never an infeasibility claim. */
export function solveRhythmicTiling(prepared,options={}){
  return run(options,s=>{
    const model=modelOf(prepared,s),obstruction=obstructionOf(model,s);
    if(obstruction){requireComplete(model);const certificate=deepFreeze({kind:'rhythmic-tiling-obstruction-v1',modelHash:s.modelHash,obstruction});hash(certificate,s);
      return result(s,'UNSAT','An exact necessary condition fails in the declared finite model',{certificate,visitedNodes:0})}
    if(s.limits.maxNodes<1)fail('Tiling search node allowance','node-budget');
    let initial=0n;for(const b of model.required){s.charge();initial|=model.translated.get(b)}
    const pending=[{selected:model.requiredMask,covered:initial}],rows=[];let admitted=1;
    while(pending.length){
      s.charge();const {selected,covered}=pending.pop();
      if(covered===model.full){
        const entries=valuesOf(selected,model,s);
        if(model.mode==='tiling'||!periodicity(entries,model,s).periodic)return satResult(model,entries,rows.length+1,s);
        rows.push({selected:selected.toString(16),pivot:null});continue;
      }
      let pivot=0;while(covered&bit(pivot)){s.charge();pivot++}s.charge();
      const children=[];for(const b of model.allowed){s.charge();const mask=model.translated.get(b);
        if(!(mask&covered)&&(mask&bit(pivot)))children.push({selected:selected|bit(b),covered:covered|mask})}
      if(children.length>s.limits.maxNodes-admitted)fail('Tiling discovered-node allowance','node-budget');admitted+=children.length;
      rows.push({selected:selected.toString(16),pivot});for(let i=children.length-1;i>=0;i--)pending.push(children[i]);
    }
    requireComplete(model);const certificate=deepFreeze({kind:'rhythmic-tiling-closed-v1',modelHash:s.modelHash,rows});hash(certificate,s);
    return result(s,'UNSAT','Complete declared search has only impossible or disallowed leaves',{certificate,visitedNodes:rows.length});
  });
}
function selectedMask(raw,model,s){
  text(raw,s,Math.ceil(model.N/4));const m=raw.match(/^(0|[1-9a-f][0-9a-f]*)$/);
  requireCertificate(m&&m[0].length===raw.length,'Noncanonical selected-offset mask');const value=BigInt('0x'+raw);
  requireCertificate(!(value&~model.allowedMask)&&(value&model.requiredMask)===model.requiredMask,'Selected offsets escape the original domain');return value;
}

/** SAT uses direct pair counting; closed UNSAT checks all original feasible successors, not the producer's masks. */
export function checkRhythmicTiling(prepared,raw,options={}){
  return run(options,s=>{
    const model=modelOf(prepared,s);if(!dataRecord(raw))fail('An ordinary certificate is required');
    text(raw.kind,s,64);text(raw.modelHash,s,64);requireCertificate(raw.modelHash===s.modelHash,'Wrong original tiling model');
    if(raw.kind==='rhythmic-tiling-sat-v1'){
      fields(raw,['kind','modelHash','entries','reportHash'],s);text(raw.reportHash,s,64);
      const entries=offsets(raw.entries,model.N,s,'Certified entry offsets');
      requireCertificate(entries.every((v,i)=>v===raw.entries[i]),'Certificate offsets must be canonical and ordered');
      const report=reportOf(model,entries,s);requireCertificate(report.status==='PASS'&&hash(report,s)===raw.reportHash,'Candidate or report fails the original contract');
      hash({kind:raw.kind,modelHash:s.modelHash,entries,reportHash:raw.reportHash},s);
      return result(s,'PASS','Direct original-pair coverage and factor predicates checked',{conclusion:'SAT',report});
    }
    requireComplete(model);
    if(raw.kind==='rhythmic-tiling-obstruction-v1'){
      fields(raw,['kind','modelHash','obstruction'],s);fields(raw.obstruction,['kind','witness'],s);text(raw.obstruction.kind,s,32);
      if(raw.obstruction.witness!==null)natural(raw.obstruction.witness,'obstruction witness');const expected=obstructionOf(model,s);
      requireCertificate(expected&&raw.obstruction.kind===expected.kind&&raw.obstruction.witness===expected.witness,'Necessary-condition obstruction is false');
      hash({kind:raw.kind,modelHash:s.modelHash,obstruction:expected},s);
      return result(s,'PASS','Original necessary-condition obstruction checked',{conclusion:'UNSAT'});
    }
    requireCertificate(raw.kind==='rhythmic-tiling-closed-v1','Unknown tiling certificate kind');fields(raw,['kind','modelHash','rows'],s);
    const rows=list(raw.rows,s.limits.maxNodes,s,'Closed proof rows'),byKey=new Map,canonical=[];
    for(const value of rows){
      fields(value,['selected','pivot'],s);const selected=selectedMask(value.selected,model,s);
      requireCertificate(!byKey.has(value.selected),'Duplicate proof state');
      if(value.pivot!==null)requireCertificate(Number.isSafeInteger(value.pivot)&&value.pivot>=0&&value.pivot<model.N,'Invalid uncovered slot');
      const row={selected,pivot:value.pivot,key:value.selected};byKey.set(row.key,row);canonical.push({selected:row.key,pivot:row.pivot});
    }
    hash({kind:raw.kind,modelHash:s.modelHash,rows:canonical},s);
    const root=model.requiredMask.toString(16);requireCertificate(byKey.has(root),'Missing original required-offset root');
    const pending=[root],queued=new Set([root]),visited=new Set;
    while(pending.length){
      s.charge();const key=pending.pop();if(visited.has(key))continue;visited.add(key);
      const row=byKey.get(key),entries=valuesOf(row.selected,model,s),counts=coverageOf(model,entries,s);
      requireCertificate(counts.every(x=>x<=1),'Proof state already contains overlapping translates');
      if(row.pivot===null){
        requireCertificate(counts.every(x=>x===1),'Non-cover cannot be a terminal periodic leaf');
        const nontrivial=model.inner.length>1&&entries.length>1;
        const invalidVuza=!nontrivial||periodicity(model.inner.map(x=>x.slot),model,s).periodic||periodicity(entries,model,s).periodic;
        requireCertificate(model.mode==='vuza'&&invalidVuza,'Closed proof discards a valid solution');continue;
      }
      requireCertificate(counts[row.pivot]===0,'Pivot is already covered');
      // Rebuild each possible next translate from original onset pairs, independently of compiled bit masks.
      for(const b of model.allowed){
        let hits=false,disjoint=true;
        for(const a of model.inner){s.charge();const x=(a.slot+b)%model.N;if(x===row.pivot)hits=true;if(counts[x])disjoint=false}
        if(!hits||!disjoint)continue;const child=(row.selected|bit(b)).toString(16);
        requireCertificate(child!==key&&byKey.has(child),'Closed proof omits a feasible original successor');
        if(!queued.has(child)){queued.add(child);pending.push(child)}
      }
    }
    requireCertificate(visited.size===byKey.size,'Unreachable extra proof states');
    return result(s,'PASS','All original successor branches terminate in checked failure',{conclusion:'UNSAT',checkedNodes:visited.size});
  });
}
