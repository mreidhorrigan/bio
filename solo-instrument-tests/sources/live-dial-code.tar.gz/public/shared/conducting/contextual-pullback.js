// CFM029 / CF10, CF24: one original source assignment across every promised context.
// Reuse is allowed only for a checker-issued admission and the same complete semantic binding.
import {Refused,pythonJson,sha256} from '../bounded-exact.js';
import {dataRecord,dataArray} from './contract-data.js';
import {describeConstraintPullback,materializeConstraintPullbackAssignment,checkConstraintPullback} from './constraint-pullback.js';

export const CONTEXTUAL_PULLBACK_LIMITS=Object.freeze({maxContexts:16,maxAssignments:4096,maxSolutions:16,
  maxEvents:16384,maxWork:4000000,maxPullbackWork:500000,maxProfileWork:2000000,maxTextChars:4194304});
const freeze=Object.freeze,models=new WeakMap,admissions=new WeakMap,scope='one-original-source-in-every-declared-context';
const fail=(reason,kind='invalid-input')=>{throw new Refused(reason,{kind})};
class BadCertificate extends Error {}
const certify=(condition,reason)=>{if(!condition)throw new BadCertificate(reason)};
function stateOf(options){
  if(!dataRecord(options)||Object.keys(options).some(k=>!Object.hasOwn(CONTEXTUAL_PULLBACK_LIMITS,k)))fail('Unknown contextual pullback options');
  const limits={};for(const [key,cap] of Object.entries(CONTEXTUAL_PULLBACK_LIMITS)){
    const value=Object.hasOwn(options,key)?options[key]:key==='maxProfileWork'?20000:key==='maxSolutions'?1:cap;
    if(!Number.isSafeInteger(value)||value<0||value>cap)fail('Contextual allowances must be bounded nonnegative integers');limits[key]=value;
  }
  const s={limits:freeze(limits),used:0,chars:0,outputChars:0,modelHash:null};
  s.charge=(n=1)=>{if(!Number.isSafeInteger(n)||n<0)throw new Error('Invalid contextual work charge');
    if(n>limits.maxWork-s.used)fail('Contextual work allowance exhausted','work-budget');s.used+=n};s.charge();return s;
}
function fields(v,keys,s){
  s.charge();if(!dataRecord(v)||Object.keys(v).length!==keys.length||keys.some(k=>!Object.hasOwn(v,k)))fail('Missing or unsupported contextual fields');s.charge(keys.length);return v;
}
function list(v,max,s,label){
  if(!Array.isArray(v)||v.length>max)fail(label+' exceeds its array allowance','shape-budget');
  s.charge(v.length+1);return dataArray(v,max,label);
}
function name(v,s,max=256){
  if(typeof v!=='string'||!v.length||v.length>max)fail('Bounded nonempty identity required');
  if(v.length>s.limits.maxTextChars-s.chars)fail('Contextual text allowance','work-budget');s.chars+=v.length;s.charge(1+Math.ceil(v.length/64));return v;
}
function natural(v){if(!Number.isSafeInteger(v)||v<0)fail('Invalid contextual revision');return v}
function digest(v,s){name(v,s,64);if(v.length!==64||!/^[0-9a-f]{64}$/.test(v))fail('A lowercase SHA-256 binding is required');return v}
function freezeDeep(v){if(v&&typeof v==='object'&&!Object.isFrozen(v)){for(const x of Object.values(v))freezeDeep(x);freeze(v)}return v}
function encode(v,s){
  // Encodes only authenticated original definitions or bounded internally reconstructed data.
  const text=pythonJson(v);if(text.length>s.limits.maxTextChars)fail('Canonical contextual text allowance','work-budget');
  s.charge(1+Math.ceil(text.length/64));return text;
}
function hash(v,s){return sha256(encode(v,s))}
function binding(raw,s){fields(raw,['id','revision','hash'],s);return freeze({id:name(raw.id,s),revision:natural(raw.revision),hash:digest(raw.hash,s)})}
function bindings(raw,voices,s){
  fields(raw,['key','tuning','tempo','style','players'],s);const players=[],seen=new Set;
  for(const value of list(raw.players,32,s,'Player assignments')){
    fields(value,['voiceId','binding'],s);const id=name(value.voiceId,s);
    if(!voices.includes(id)||seen.has(id))fail('Unknown or duplicate assigned voice');seen.add(id);players.push(freeze({voiceId:id,binding:binding(value.binding,s)}));
  }if(seen.size!==voices.length)fail('Bind a player assignment for every profile voice','missing-evidence');
  return freeze({key:binding(raw.key,s),tuning:binding(raw.tuning,s),tempo:binding(raw.tempo,s),style:binding(raw.style,s),players:freeze(players)});
}
function result(s,status,reason,extra={}){return freeze({status,reason,scope,modelHash:s?.modelHash??null,
  workUsed:s?.used??0,resourceLimits:s?.limits??null,...extra})}
function run(options,body){let s;try{s=stateOf(options);return body(s)}catch(e){return result(s,e instanceof BadCertificate?'FAIL':'UNKNOWN',e.message??'Contextual pullback refused',
  {kind:e instanceof Refused?e.kind:e instanceof BadCertificate?'invalid-certificate':'internal-error',conclusion:null,certificate:null,admitted:null})}}
function normalize(spec,s){
  fields(spec,['id','revision','requiredContexts','contexts'],s);const id=name(spec.id,s),revision=natural(spec.revision),supplied=new Map;
  for(const item of list(spec.contexts,s.limits.maxContexts,s,'Original context models')){
    fields(item,['id','pullback'],s);const id=name(item.id,s);if(supplied.has(id))fail('Duplicate original context');
    const description=describeConstraintPullback(item.pullback);s.charge();supplied.set(id,{original:item.pullback,...description});
  }
  const contexts=[],seen=new Set;let source=null,sourceKey=null,sourceHash=null,totalEvents=0;
  for(const raw of list(spec.requiredContexts,s.limits.maxContexts,s,'Required contexts')){
    fields(raw,['id','revision','bindings'],s);const id=name(raw.id,s),original=supplied.get(id);
    if(seen.has(id))fail('Duplicate required context');seen.add(id);if(!original)fail('A required original context is absent','missing-evidence');
    const def=original.definition,text=encode(def.source,s);
    if(source===null){source=def.source;sourceKey=text;sourceHash=sha256(text)}
    else if(text!==sourceKey)fail('Every context must share the exact original source identities, pitch space, clock and catalogues','out-of-model');
    const events=def.entries.length*def.source.events.length+def.environment.events.length;
    if(events>s.limits.maxEvents-totalEvents)fail('Whole contextual material allowance','shape-budget');totalEvents+=events;s.charge(events);
    const descriptor=freeze({id,revision:natural(raw.revision),bindings:bindings(raw.bindings,def.profile.voices,s),modelHash:original.modelHash,
      originalDefinition:def,profile:def.profile,targetPitchSpace:def.targetPitchSpace,targetClock:def.targetClock});
    contexts.push(freeze({descriptor,original:original.original}));
  }
  if(!contexts.length)fail('Declare a nonempty required context family');
  if(seen.size!==supplied.size)fail('Unpromised original contexts cannot be silently discarded');
  const variables=source.variables;let cardinality=1n;for(const v of variables){s.charge();cardinality*=BigInt(v.values.length)}
  const definition=freezeDeep({kind:'contextual-pullback-v1',id,revision,sourceHash,source,requiredContexts:contexts.map(c=>c.descriptor),cardinality:String(cardinality)});
  const semanticKey=encode(definition,s);s.modelHash=sha256(semanticKey);
  return {definition,semanticKey,contexts:freeze(contexts),variables,cardinality,totalEvents,complete:variables.every(v=>v.complete)};
}
function modelOf(prepared,s){const m=models.get(prepared);if(!m)fail('Use an authentic prepared contextual model','out-of-model');
  s.modelHash=prepared.modelHash;if(m.contexts.length>s.limits.maxContexts||m.totalEvents>s.limits.maxEvents)fail('Prepared contextual shape allowance','shape-budget');return m}
function assignmentOf(raw,model,s){
  list(raw,16,s,'Shared assignment');if(raw.length!==model.variables.length)fail('Assign every original source variable once');const chosen=new Map;
  for(const item of raw){
    fields(item,['variableId','candidateId'],s);const id=name(item.variableId,s),value=name(item.candidateId,s),v=model.variables.find(v=>v.id===id);s.charge(model.variables.length);
    if(!v||chosen.has(id))fail('Unknown or duplicate assigned variable');s.charge(v.values.length);
    if(!v.values.some(x=>x.id===value))fail('Assigned value is outside the original catalogue');chosen.set(id,value);
  }return freeze(model.variables.map(v=>freeze({variableId:v.id,candidateId:chosen.get(v.id)})));
}
function nested(original,assignment,s,witness=null){
  s.charge();const allowance=Math.min(s.limits.maxPullbackWork,s.limits.maxWork-s.used);
  const out=witness===null?materializeConstraintPullbackAssignment(original,assignment,{maxWork:allowance}):
    checkConstraintPullback(original,witness,{maxWork:allowance,maxProfileWork:s.limits.maxProfileWork});
  if(!Number.isSafeInteger(out.workUsed)||out.workUsed<0||out.workUsed>allowance)throw new Error('Invalid contextual nested receipt');s.charge(out.workUsed);
  if(out.status==='UNKNOWN'&&typeof out.kind==='string'&&out.kind.includes('budget'))fail(out.reason,out.kind);return out;
}
function evaluate(model,assignment,s){
  const reports=[],unresolved=[];let reportChars=0;
  for(const context of model.contexts){
    s.charge();const d=context.descriptor,material=nested(context.original,assignment,s);
    if(material.status==='FAIL')return {status:'FAIL',contextId:d.id,reason:'An original forward map excludes the shared assignment'};
    if(material.status!=='PASS'){unresolved.push(d.id);continue}
    const checked=nested(context.original,null,s,material.witness);
    if(checked.status==='FAIL')return {status:'FAIL',contextId:d.id,reason:'An original required-context whole profile excludes the shared assignment'};
    if(checked.status!=='PASS'){unresolved.push(d.id);continue}
    const item=freeze({id:d.id,revision:d.revision,bindings:d.bindings,modelHash:d.modelHash,profileHash:checked.audit.profileHash,
      profile:d.profile,targetPitchSpace:d.targetPitchSpace,targetClock:d.targetClock,witness:material.witness});
    const size=encode(item,s).length;if(size>s.limits.maxTextChars-reportChars)fail('Whole contextual report allowance','work-budget');reportChars+=size;reports.push(item);
  }
  if(unresolved.length)return {status:'UNKNOWN',unresolved:freeze(unresolved)};
  const report=freezeDeep({scope,modelHash:s.modelHash,sourceHash:model.definition.sourceHash,assignment,contexts:reports});
  return {status:'PASS',report,reportHash:hash(report,s)};
}
function certificate(conclusion,out,s){return freeze({kind:'contextual-pullback-certificate-v1',modelHash:s.modelHash,conclusion,
  assignment:out?.report.assignment??null,reportHash:out?.reportHash??null})}
function appendOutput(out,s){const size=encode(out.report,s).length;if(size>s.limits.maxTextChars-s.outputChars)fail('Combined contextual solution output allowance','work-budget');s.outputChars+=size;
  return freeze({report:out.report,certificate:certificate('SAT',out,s)})}
function statsOf(){return {assignments:0,feasibleAssignments:0,failedAssignments:0,unknownAssignments:0,exhausted:false}}
function tally(stats,out,s){s.charge();stats.assignments++;if(out.status==='PASS')stats.feasibleAssignments++;else if(out.status==='FAIL')stats.failedAssignments++;else stats.unknownAssignments++}
function admitEnumeration(model,s){if(model.cardinality>BigInt(s.limits.maxAssignments))fail('Complete original contextual enumeration exceeds the assignment allowance','work-budget')}

/** The independent required inventory is authoritative. Every original model has the identical source domain. */
export function prepareContextualPullback(spec,options={}){
  return run(options,s=>{const model=normalize(spec,s),prepared=freeze({kind:'prepared-contextual-pullback-v1',modelHash:s.modelHash,definition:model.definition});
    models.set(prepared,model);return result(s,'PASS','Shared source and every required original context bound',{prepared})});
}
/** Audit one shared assignment in every promised original context. PASS alone creates no reusable admission. */
export function auditContextualPullback(prepared,rawAssignment,options={}){
  return run(options,s=>{const model=modelOf(prepared,s),out=evaluate(model,assignmentOf(rawAssignment,model,s),s);
    return result(s,out.status,'One original source assignment audited across the required context family',
      {report:out.report??null,certificate:out.status==='PASS'?certificate('SAT',out,s):null,contextId:out.contextId??null,unresolved:out.unresolved??[]})});
}
/** Bounded joint search, with explicitly incomplete prefixes and optional multiple labelled witnesses. */
export function solveContextualPullback(prepared,options={}){
  return run(options,s=>{const model=modelOf(prepared,s),stats=statsOf(),solutions=[],tuple=[],exclusions=[];
    if(!s.limits.maxSolutions)fail('At least one solution slot is needed','work-budget');
    function visit(depth){
      s.charge();if(solutions.length>=s.limits.maxSolutions)return false;
      if(depth===model.variables.length){
        if(stats.assignments>=s.limits.maxAssignments)return false;
        const assignment=freeze(tuple.map(x=>freeze({...x}))),out=evaluate(model,assignment,s);tally(stats,out,s);
        if(out.status==='PASS')solutions.push(appendOutput(out,s));
        else if(out.status==='FAIL'&&exclusions.length<16)exclusions.push(freeze({assignment,contextId:out.contextId,reason:out.reason}));return true;
      }
      const v=model.variables[depth];for(const x of v.values){s.charge();tuple[depth]={variableId:v.id,candidateId:x.id};if(!visit(depth+1))return false}return true;
    }
    stats.exhausted=model.cardinality===0n||visit(0);const conclusive=stats.exhausted&&model.complete&&!stats.unknownAssignments;
    const status=solutions.length?'SAT':conclusive?'UNSAT':'UNKNOWN';
    return result(s,status,solutions.length?'Each returned source assignment passes every promised original context':conclusive?
      'No assignment in the complete shared finite domain passes every required context':'Incomplete search, source catalogue or required evidence prevents a failure claim',
      {solutions:freeze(solutions),solutionsComplete:conclusive,certificate:status==='UNSAT'?certificate('UNSAT',null,s):null,
        domainCardinality:String(model.cardinality),domainComplete:model.complete,search:freeze(stats),exclusions:freeze(exclusions)});
  });
}
/** SAT is fully replayed; UNSAT independently enumerates the original product. Only this checker grants reuse. */
export function checkContextualPullback(prepared,raw,options={}){
  return run(options,s=>{const model=modelOf(prepared,s);fields(raw,['kind','modelHash','conclusion','assignment','reportHash'],s);
    certify(raw.kind==='contextual-pullback-certificate-v1'&&raw.modelHash===s.modelHash,'Certificate or required-context binding differs');
    certify(raw.conclusion==='SAT'||raw.conclusion==='UNSAT','Unknown contextual conclusion');
    if(raw.conclusion==='SAT'){
      digest(raw.reportHash,s);const out=evaluate(model,assignmentOf(raw.assignment,model,s),s);
      if(out.status==='UNKNOWN')fail('A required original context remains unresolved','missing-evidence');
      certify(out.status==='PASS','A required original context refutes the shared assignment');certify(out.reportHash===raw.reportHash,'Reconstructed contextual report differs');
      const admitted=freeze({kind:'admitted-contextual-pullback-v1',modelHash:s.modelHash,report:out.report});
      admissions.set(admitted,{modelHash:s.modelHash,semanticKey:model.semanticKey,report:out.report});
      return result(s,'PASS','Every required original context independently replayed and audited',{conclusion:'SAT',report:out.report,admitted});
    }
    certify(raw.assignment===null&&raw.reportHash===null,'UNSAT cannot contain a selected witness');
    certify(model.complete,'An incomplete shared source catalogue cannot certify UNSAT');admitEnumeration(model,s);
    const stats=statsOf(),digits=Array(model.variables.length).fill(0);let done=model.cardinality===0n;
    while(!done){
      s.charge();const assignment=freeze(model.variables.map((v,i)=>freeze({variableId:v.id,candidateId:v.values[digits[i]].id}))),out=evaluate(model,assignment,s);tally(stats,out,s);
      certify(out.status!=='PASS','A source assignment passing every original context refutes UNSAT');
      let pos=digits.length-1;for(;pos>=0;pos--){s.charge();if(++digits[pos]<model.variables[pos].values.length)break;digits[pos]=0}done=pos<0;
    }
    stats.exhausted=true;if(stats.unknownAssignments)fail('Unresolved assignments prevent finite joint UNSAT','missing-evidence');
    return result(s,'PASS','Every original shared assignment has a decisive required-context exclusion',
      {conclusion:'UNSAT',admitted:null,domainCardinality:String(model.cardinality),search:freeze(stats)});
  });
}
/** Exact-context reuse, not a new audit. Changed bindings return UNKNOWN and require revalidation. */
export function reuseContextualPullback(admitted,currentPrepared,options={}){
  return run(options,s=>{const model=modelOf(currentPrepared,s),receipt=admissions.get(admitted);
    if(!receipt)fail('A checker-issued contextual admission is required','missing-evidence');
    s.charge(1+Math.ceil(model.semanticKey.length/64));
    if(receipt.modelHash!==s.modelHash||receipt.semanticKey!==model.semanticKey)fail('Source or required key/tuning/tempo/player/style/model context changed; revalidate','stale-context');
    return result(s,'PASS','Reusing a checked source in exactly the same immutable declared context family',
      {conclusion:'SAT',reused:true,report:receipt.report,admitted});
  });
}
