// Declared pitch spaces for relationships (fugue-and-coordination, GC01–GC05). No implicit period folding or snapping.
// Coordinates remain exact; frequency evaluation is an explicitly approximate renderer boundary. Integer EDP or
// scale degrees do not become fractional grid members when an acoustic compromise is requested: use a cents space.
import {Q} from './canon-core.js';
import {Refused,exactOfNumber,sha256,pythonJson} from '../bounded-exact.js';
import {dataRecord,dataArray} from './contract-data.js';

export const PITCH_SPACE_LIMITS=Object.freeze({dimensions:32,steps:1024,operations:64,id:256});
const spaces=new WeakMap;
const fail=(message,kind='invalid-input')=>{throw new Refused(message,{kind})};
const plain=dataRecord;
const named=value=>{if(typeof value!=='string'||!value.length||value.length>PITCH_SPACE_LIMITS.id)fail('A pitch space/mapping needs a bounded id');return value};
const keys=(value,allowed)=>{if(!plain(value)||Object.keys(value).some(key=>!allowed.includes(key)))fail('Unsupported pitch-space fields')};
const whole=value=>{const q=Q(value);if(q.d!==1n)fail('This space requires lifted integer coordinates');return q};
const positive=value=>{const q=Q(value);if(q.cmp(0)<=0)fail('A ratio/period must be positive');return q};
const array=dataArray;
const freeze=values=>Object.freeze(values);
const text=value=>Array.isArray(value)?freeze(value.map(String)):String(value);
const power=(value,exponent)=>{
  let n=exponent<0n?-exponent:exponent,base=exponent<0n?Q(1).div(value):value,result=Q(1);
  while(n){if(n&1n)result=result.mul(base);n>>=1n;if(n)base=base.mul(base)}return result;
};
const floor=q=>q.n/q.d-(q.n<0n&&q.n%q.d?1n:0n);
const bits=n=>n.toString(2).length;
const log2Integer=n=>{const shift=Math.max(0,bits(n)-53);return Math.log2(Number(n>>BigInt(shift)))+shift};
const log2Ratio=q=>log2Integer(q.n)-log2Integer(q.d);
const numberOf=q=>{
  const n=q.n<0n?-q.n:q.n;if(!n)return 0;
  const a=Math.max(0,bits(n)-53),b=Math.max(0,bits(q.d)-53);
  return (q.n<0n?-1:1)*Number(n>>BigInt(a))/Number(q.d>>BigInt(b))*2**(a-b);
};
const octaveCents=q=>{
  const isPower=n=>n>0n&&(n&(n-1n))===0n;
  return isPower(q.n)&&isPower(q.d)?Q(1200).mul(bits(q.n)-bits(q.d)):null;
};
const finiteOrNull=n=>Number.isFinite(n)?n:null;
const state=space=>{const s=spaces.get(space);if(!s)fail('Use a prepared pitch space');return s};

// kinds: semitones, cents, edo (equal divisions of any positive ratio period), ratio, lattice, scale-degree.
// Every definition has an id and a hash; reusing an id with another tuning cannot reuse its typed coordinates.
export function createPitchSpace(spec){
  if(!plain(spec))fail('A pitch space is a data record');const kind=spec.kind;
  if(!['semitones','cents','edo','ratio','lattice','scale-degree'].includes(kind))fail('Unsupported pitch-space semantics','out-of-model');
  const fields={semitones:[],cents:[],edo:['divisions','periodRatio'],ratio:[],lattice:['generators'],
    'scale-degree':['stepsCents','periodCents']}[kind];
  if(!fields)fail('Unsupported pitch-space semantics','out-of-model');keys(spec,['id','kind','reference',...fields]);const id=named(spec.id);
  let divisions,period,generators,steps;
  if(kind==='edo'){
    if(!Number.isSafeInteger(spec.divisions)||spec.divisions<=0)fail('Divisions must be a positive safe integer');
    divisions=spec.divisions;period=positive(spec.periodRatio);if(period.cmp(1)<=0)fail('An EDP period must exceed one');
  }
  if(kind==='lattice'){
    generators=array(spec.generators,PITCH_SPACE_LIMITS.dimensions).map(positive);
    if(!generators.length)fail('A lattice needs declared generators');
  }
  if(kind==='scale-degree'){
    period=positive(spec.periodCents);steps=array(spec.stepsCents,PITCH_SPACE_LIMITS.steps).map(Q);
    if(!steps.length||steps.some((q,i)=>q.cmp(0)<0||q.cmp(period)>=0||i&&q.cmp(steps[i-1])<=0))fail('Scale cents must increase inside the declared period');
  }
  const scalar=kind==='edo'||kind==='scale-degree'?whole:kind==='ratio'?positive:Q;
  const coordinate=value=>{
    if(kind!=='lattice')return scalar(value);
    const values=array(value,PITCH_SPACE_LIMITS.dimensions);if(values.length!==generators.length)fail('Lattice dimension mismatch');return values.map(whole);
  };
  // 69 at 440 Hz defines the existing protocol semitone unit, not a chosen musical opening or tuning default.
  const reference=Object.hasOwn(spec,'reference')?spec.reference:kind==='semitones'?{hz:440,coordinate:69}:null;
  let ref=null;
  if(reference!==null){
    keys(reference,['hz','coordinate']);
    if(typeof reference.hz!=='number'||!Number.isFinite(reference.hz)||reference.hz<=0)fail('Reference Hz must be finite and positive');
    ref={hz:reference.hz,coordinate:coordinate(reference.coordinate)};
  }
  const definition=freeze({id,kind,...(kind==='edo'?{divisions,periodRatio:String(period)}:{}),
    ...(kind==='lattice'?{generators:freeze(generators.map(String))}:{}),
    ...(kind==='scale-degree'?{stepsCents:freeze(steps.map(String)),periodCents:String(period)}:{}),
    reference:ref?freeze({hz:ref.hz,coordinate:text(ref.coordinate)}):null});
  const hash=sha256(pythonJson(definition)),values=new WeakMap;
  const valueOf=value=>{
    if(value&&values.has(value))return values.get(value);
    if(plain(value)&&Object.hasOwn(value,'coordinate')){
      keys(value,['space','definition','coordinate']);
      if(value.space!==id||value.definition!==hash)fail('Pitch belongs to a different space or tuning revision','out-of-model');
      return coordinate(value.coordinate);
    }
    return coordinate(value);
  };
  const pitch=value=>{
    const p=freeze({space:id,definition:hash,coordinate:text(value)});
    values.set(p,Array.isArray(value)?freeze([...value]):value);return p;
  };
  const scaleCents=k=>{
    const count=Q(steps.length),cycle=floor(k.div(count)),index=Number(k.n-cycle*BigInt(steps.length));
    return period.mul(cycle).add(steps[index]);
  };
  const ratioOf=values=>values.reduce((product,e,i)=>product.mul(power(generators[i],e.n)),Q(1));
  const centsBetween=(a,b)=>{
    if(kind==='semitones')return {exact:b.sub(a).mul(100)};
    if(kind==='cents')return {exact:b.sub(a)};
    if(kind==='scale-degree')return {exact:scaleCents(b).sub(scaleCents(a))};
    if(kind==='edo'){
      const span=octaveCents(period),change=b.sub(a).div(divisions);
      return span?{exact:span.mul(change)}:{approximate:1200*log2Ratio(period)*numberOf(change)};
    }
    const ratio=kind==='ratio'?b.div(a):ratioOf(b.map((q,i)=>q.sub(a[i]))),exact=octaveCents(ratio);
    return exact?{exact}:{approximate:1200*log2Ratio(ratio)};
  };
  const operand=value=>kind==='ratio'?positive(value):coordinate(value);
  const apply=(value,operation)=>{
    if(!plain(operation))fail('A typed pitch operation must be an object');
    const a=valueOf(value);
    if(operation.type==='transpose'){
      keys(operation,['type','by']);const by=operand(operation.by);
      return pitch(kind==='ratio'?a.mul(by):kind==='lattice'?a.map((q,i)=>q.add(by[i])):a.add(by));
    }
    if(operation.type==='reflect'){
      // pivot = twice the additive axis, or the product p*p' in a ratio space. A half-step additive axis is legal.
      keys(operation,['type','pivot']);const pivot=operand(operation.pivot);
      return pitch(kind==='ratio'?pivot.div(a):kind==='lattice'?a.map((q,i)=>pivot[i].sub(q)):pivot.sub(a));
    }
    fail('Unsupported typed pitch operation','out-of-model');
  };
  const api=freeze({id,kind,definition,hash,
    pitch:value=>pitch(valueOf(value)),
    apply,
    equivalent(a,b){
      try{a=valueOf(a);b=valueOf(b);return kind==='lattice'?a.every((q,i)=>q.eq(b[i])):a.eq(b)}
      catch(error){if(error instanceof Refused&&error.kind==='out-of-model')return 'UNKNOWN';throw error}
    },
    interval(a,b){
      a=valueOf(a);b=valueOf(b);
      const native=kind==='ratio'?b.div(a):kind==='lattice'?b.map((q,i)=>q.sub(a[i])):b.sub(a),cents=centsBetween(a,b);
      return freeze({space:id,definition:hash,coordinate:text(native),exactCents:cents.exact?String(cents.exact):null,
        approximateCents:finiteOrNull(cents.exact?numberOf(cents.exact):cents.approximate)});
    },
    realize(value){
      const p=pitch(valueOf(value));
      if(!ref)return freeze({status:'UNKNOWN',pitch:p,reason:'No frequency reference was declared'});
      try{
        const cents=centsBetween(ref.coordinate,valueOf(p)),amount=cents.exact?numberOf(cents.exact):cents.approximate;
        const logHz=Math.log2(ref.hz)+amount/1200,hz=2**logHz,semitones=69+12*(logHz-Math.log2(440));
        if(!Number.isFinite(hz)||hz<=0||!Number.isFinite(semitones))return freeze({status:'UNKNOWN',pitch:p,reason:'Outside finite positive renderer frequency range'});
        return freeze({status:'APPROXIMATE',pitch:p,hz,semitones,errorBoundCents:null,
          scope:'binary64 evaluation; no certified acoustic error or player feasibility'});
      }catch(error){if(!(error instanceof Refused))throw error;return freeze({status:'UNKNOWN',pitch:p,reason:error.message,kind:error.kind})}
    },
  });
  spaces.set(api,{coordinate,operand,valueOf,pitch,generators});return api;
}

// Numeric legacy pitches enter through a named conversion. This preserves the decimal the caller supplied, not a
// proof that a binary64 computation or sounding frequency equals that ideal. It never rounds an integer-grid pitch.
export function pitchFromNumber(space,value){
  state(space);if(space.kind==='lattice')fail('A lattice requires a coordinate vector');
  const q=exactOfNumber(value),pitch=space.pitch(Q(q));
  return freeze({pitch,conversion:freeze({kind:'number-as-decimal',value,exactCoordinate:Q(q).toString()})});
}

// Freeze/validate the ordered list once, then reuse it for a phrase. Reflection and translation need not commute.
export function compilePitchOperations(space,operations=[]){
  const s=state(space);array(operations,PITCH_SPACE_LIMITS.operations);
  const normalized=operations.map(operation=>{
    if(!plain(operation))fail('A typed pitch operation must be an object');
    const field=operation.type==='transpose'?'by':operation.type==='reflect'?'pivot':null;
    if(!field)fail('Unsupported typed pitch operation','out-of-model');keys(operation,['type',field]);
    return freeze({type:operation.type,[field]:text(s.operand(operation[field]))});
  });
  const ordered=freeze(normalized),hash=sha256(pythonJson({space:space.hash,operations:ordered}));
  return freeze({space:space.id,definition:space.hash,operations:ordered,hash,
    apply:value=>ordered.reduce((pitch,operation)=>space.apply(pitch,operation),space.pitch(value))});
}

// A declared integer matrix maps coordinates between lattices, including noninjective maps. Preserve its identity
// and source coordinates; a matrix alone establishes no acoustic equivalence between different generator systems.
export function mapLatticePitch(sourceSpace,value,targetSpace,{id,matrix}={}){
  const source=state(sourceSpace),target=state(targetSpace);named(id);
  if(sourceSpace.kind!=='lattice'||targetSpace.kind!=='lattice')fail('Matrix mapping requires two lattice spaces','out-of-model');
  const rows=array(matrix,PITCH_SPACE_LIMITS.dimensions);
  if(rows.length!==target.generators.length)fail('Target matrix dimension mismatch');
  const parsed=rows.map(row=>{
    array(row,PITCH_SPACE_LIMITS.dimensions);if(row.length!==source.generators.length)fail('Source matrix dimension mismatch');return row.map(whole);
  });
  const original=sourceSpace.pitch(value),coordinates=source.valueOf(original);
  const mapped=parsed.map(row=>row.reduce((sum,q,i)=>sum.add(q.mul(coordinates[i])),Q(0)));
  const mapping=freeze({id,source:sourceSpace.hash,target:targetSpace.hash,matrix:freeze(parsed.map(row=>text(row)))});
  return freeze({pitch:targetSpace.pitch(mapped),source:original,mapping,mappingHash:sha256(pythonJson(mapping)),acousticIdentity:'not-certified'});
}
