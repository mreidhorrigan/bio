// Requests up the tree (docs/MUSEBOTS_3.md, the third lack: "a request from a group to its parent (`/broadcast/group/request`),
// a stimulus to the parent's planner, answered in its plan"). A group's conductor asks its parent's for something its
// own decisions cannot settle alone; the parent weighs its children's asks together and answers in its piece plan, a
// layer of the section asked about, which the children read as they plan.
//
// The first ask is a rest, the second a solo (soloAsks, grantSolos). A rest: a section asking to rest a phrase (its specification's `rest.ask`, the chance it asks for any
// phrase, drawn from the ensemble's seed, its group and the phrase's bar). The parent grants as many as leave at least
// `playing` of its sections playing in that phrase, to those that have rested least, ties by their groups' names: so the
// orchestra never falls silent, and a section alone is never granted one (the owner, 2 October 2026, on a silent part:
// acceptable "as part of the form, but ... make sure it doesn't happen by accident").
export const REQUEST_ADDRESS='/broadcast/group/request';
// The least share of a parent's sections left playing in a phrase (ours).
export const REQUESTS=Object.freeze({playing:.5});

// A section's asks to rest, for the phrases from `startBar` to `endBar`, `phraseBars` each: those whose draw falls under
// its `ask`; never the piece's last phrase (`last`), and, for a section whose specification keeps them (`joins` false:
// the percussion's, which marks them), never a section's first phrase or its last, where the form arrives and where it
// is announced. `draw(bar)`: [0, 1), the same for the same group and bar. -> bars.
export function restAsks({startBar,endBar,phraseBars,last=false,ask=0,joins=true,draw}){
  const out=[],step=Math.max(1,phraseBars||1);
  for(let bar=startBar;bar<endBar;bar+=step)if(!(last&&bar+step>=endBar)&&(joins||bar!==startBar&&bar+step<endBar)&&draw(bar)<ask)out.push(bar);
  return out;
}
// A section's asks to solo (its specification's `solo.ask`, the chance it asks for any phrase): a phrase whose draw falls
// under it; never a section of the form's first phrase (where the form arrives: so never the piece's first), nor the
// piece's last. `draw(bar)`: [0, 1), the same for the same group and bar. -> bars.
export function soloAsks({startBar,endBar,phraseBars,last=false,ask=0,draw}){
  const out=[],step=Math.max(1,phraseBars||1);
  for(let bar=startBar+step;bar<endBar;bar+=step)if(!(last&&bar+step>=endBar)&&draw(bar)<ask)out.push(bar);
  return out;
}
// The solos a parent grants: of the sections asking to solo a phrase, one (a solo is heard over the others), the one that
// has soloed least, ties by their groups' names; never one its rests (`rests`: {bar: [groups]}) rest then. `soloed`
// counts each section's solos, moved by them. -> {[bar]: group}.
export function grantSolos(asks,{sections,soloed=new Map,rests={}}){
  const byBar=new Map,out={};
  for(const {group,bars} of asks)if(sections.includes(group))for(const bar of bars??[])(byBar.get(bar)??byBar.set(bar,[]).get(bar)).push(group);
  for(const bar of [...byBar.keys()].sort((a,b)=>a-b)){
    const chosen=[...new Set(byBar.get(bar))].filter(group=>!(rests[bar]??[]).includes(group)).sort((a,b)=>(soloed.get(a)??0)-(soloed.get(b)??0)||a.localeCompare(b))[0];
    if(chosen){soloed.set(chosen,(soloed.get(chosen)??0)+1);out[bar]=chosen}
  }
  return out;
}
// The rests a parent grants: `asks` [{group, bars}], `sections` its children's groups, `rested` how many phrases each has
// rested (counted as granted, and moved by them). -> {[bar]: [groups]}, each bar's in its groups' order.
export function grantRests(asks,{sections,rested=new Map,playing=REQUESTS.playing}){
  const n=sections.length,most=Math.max(0,n-Math.ceil(n*playing)),byBar=new Map,out={};
  for(const {group,bars} of asks)if(sections.includes(group))for(const bar of bars)(byBar.get(bar)??byBar.set(bar,[]).get(bar)).push(group);
  for(const bar of [...byBar.keys()].sort((a,b)=>a-b)){
    const chosen=[...new Set(byBar.get(bar))].sort((a,b)=>(rested.get(a)??0)-(rested.get(b)??0)||a.localeCompare(b)).slice(0,most);
    for(const group of chosen)rested.set(group,(rested.get(group)??0)+1);
    if(chosen.length)out[bar]=chosen.sort();
  }
  return out;
}

// The sections an orchestra's breadth rests (plex_clodbot PLEX_CLODBOT.players): in each phrase of a section of the form
// but the piece's last, of its m sections m to the share play (string-section.js playersOf: one at 0, all at 1), the
// rest those whose draw (`draw(group, bar)`: [0, 1), the same for the same group and bar) is highest -- each draw leaning
// by its section's `loudness(group)` (0 to 1) as far as the section of the form is quiet (`level` under 0.5), so that
// where the music is quiet the louder families rest first, and the brass and percussion are heard mostly where it is
// loud (an orchestra's dynamics coming as much from who plays as from how). A share of all, or of one section, rests
// none. -> {[bar]: [groups]}.
export const BREADTH=Object.freeze({lean:.8});
export function breadthRests(unit,{sections,share,draw,level=null,loudness=()=>0}){
  const out={},step=Math.max(1,Number(unit.value?.phraseBars)||1),m=sections.length;
  if(!(share<1)||m<2)return out;
  const playing=Math.max(1,Math.min(m,Math.round(m**Math.max(0,share))));if(playing>=m)return out;
  for(let bar=unit.startBar;bar<unit.endBar;bar+=step){
    if(unit.value?.last&&bar+step>=unit.endBar)continue;
    const lean=Number.isFinite(level)?BREADTH.lean*Math.max(0,1-2*Math.max(0,level)):0,key=group=>draw(group,bar)+lean*Math.max(0,Math.min(1,Number(loudness(group))||0));
    out[bar]=[...sections].sort((a,b)=>key(b)-key(a)).slice(0,m-playing).sort();
  }
  return out;
}
// Two layers of rests as one (bar by bar, each group once), never resting every section in a bar: where they would, the
// first's alone. -> {[bar]: [groups]}.
export function mergeRests(first={},second={},sections=[]){
  const out={};
  for(const bar of new Set([...Object.keys(first),...Object.keys(second)])){
    const both=[...new Set([...(first[bar]??[]),...(second[bar]??[])])].sort();
    out[bar]=sections.length&&sections.every(group=>both.includes(group))?[...(first[bar]??[])].sort():both;
    if(!out[bar].length)delete out[bar];
  }
  return out;
}
