// A fugue's answer as distinct operations (Astra's tracker, CF09: "Construct real and tonal answers as different
// operations"; its acceptance: "subjects for which mechanical transposition is acceptable, subjects requiring
// alteration, and ambiguous cases that should return alternatives rather than false certainty"). In any tuning: pitch
// classes compared to the thousandth of a semitone, a period of the harmony's own.
//
//   - real: every note moved by the answer's interval exactly -- the answer in the dominant's region, as Bach's real
//     answers are (the subject of the Well-Tempered Clavier I's first fugue, BWV 846, answered note for note a fifth
//     up);
//   - tonal: the real answer, but in the subject's head -- its leading notes on the axis of its tonic and its dominant,
//     up to the first of another class -- the tonic answered by the dominant and the dominant by the tonic above it
//     (the period less the interval: a fourth where the answer is a fifth), so the answer's head keeps the subject's
//     axis: the Art of Fugue's D A F D C# D E F answered A D C A G# A B C (BWV 1080), not A E C A G# A B C;
//   - by degrees: every note as many of the collection's degrees up (canon-plan.js stepInCollection), its own
//     inflection kept, the collection kept -- a modal answer; and tonal by degrees, its head's mutation likewise in
//     degrees (the degrees from the dominant to the next tonic).
//
// Which the subject asks: a tonal answer where its head reaches the dominant (it begins on it, or reaches it from the
// tonic before any other class: Gedalge, A. (1901), Traité de la fugue, Paris: Enoch, part 1, "De la réponse"; Mann, A.
// (1958), The Study of Fugue, New Brunswick: Rutgers University Press); a real one where its head is the tonic alone;
// none -- both offered -- where the tonic is not known or the subject begins on neither (an answer then the planner's
// choice, never claimed as the subject's own).
import {stepInCollection} from './canon-plan.js';

const modulo=(x,n)=>((x%n)+n)%n;
// answerLine and fugueAnswers run faster where a core is installed (shared/musical-core.js: their Rust port, the same
// answers from the same lines; research/RUST_PORT_STATE.md). It declines (null) what it does not take, and they are
// made here as ever. -> the core it replaced.
let core=null;
export function useAnswerCore(given=null){const previous=core;core=given;return previous}
const same=(a,b,period)=>{const d=modulo(a-b,period);return Math.min(d,period-d)<1e-3};

// The subject's head on its tonic-dominant axis: the indices of its leading notes whose classes are the tonic's or the
// dominant's (`interval` above it), up to the first of another class. -> {head: [indices], dominant (whether the head
// reaches it)}.
export function answerHead(line,{tonic,interval,period=12}){
  const head=[];let dominant=false;
  for(const [index,note] of line.entries()){
    const onTonic=same(note.pitch,tonic,period),onDominant=same(note.pitch,tonic+interval,period);
    if(!onTonic&&!onDominant)break;
    head.push(index);if(onDominant)dominant=true;
  }
  return {head,dominant};
}

// The answer to `line` ([{pitch, start, length}]): by its `interval` (semitones, exact) or by `steps` of `collection`
// (degrees), `tonal` its head mutated (answerHead). -> the answered line (each note's pitch moved, its time kept).
export function answerLine(line,{interval=null,steps=null,collection=null,tonic=null,tonal=false,period=12}){
  if(core){const answered=core.answerLine(line,{interval,steps,collection,tonic,tonal,period});if(answered)return answered}
  const byDegrees=steps!=null,classes=byDegrees?new Set(collection.map(p=>Math.round(modulo(Number(p),period)*1000))).size:0;
  const amount=byDegrees?steps:interval;if(!Number.isFinite(amount))throw new RangeError('An answer moves by an interval or by degrees');
  // (The interval the degrees span, from the tonic: the axis's dominant.)
  const span=byDegrees&&tonic!=null?stepInCollection(tonic,steps,collection,period)-tonic:interval;
  const mutated=new Set(tonal&&tonic!=null?answerHead(line,{tonic,interval:span,period}).head:[]);
  const move=(pitch,up)=>byDegrees?stepInCollection(pitch,up,collection,period):pitch+up;
  return line.map((note,index)=>{
    if(!mutated.has(index))return {...note,pitch:move(note.pitch,amount)};
    // (The tonic to the dominant; the dominant to the tonic above it.)
    return {...note,pitch:same(note.pitch,tonic,period)?move(note.pitch,amount):move(note.pitch,byDegrees?classes-steps:period-interval)};
  });
}

// The subject's answers and which it asks. -> {real, tonal (null where no head reaches the dominant), degrees, tonalDegrees
// (likewise), asks ('tonal', 'real' or null: ambiguous), head, reason}. `interval` the answer's (semitones); `steps` and
// `collection` its degrees in the collection, where it has one; `tonic` its tonic (a pitch or class), where known.
export function fugueAnswers(line,{interval,steps=null,collection=null,tonic=null,period=12}){
  if(core){const answers=core.fugueAnswers(line,{interval,steps,collection,tonic,period});if(answers)return answers}
  const known=Number.isFinite(tonic),{head,dominant}=known?answerHead(line,{tonic,interval,period}):{head:[],dominant:false};
  const degrees=steps!=null&&collection?.length?answerLine(line,{steps,collection,period}):null;
  const real=answerLine(line,{interval,period});
  const asks=!known?null:!head.length?null:dominant?'tonal':'real';
  return {real,tonal:dominant?answerLine(line,{interval,tonic,tonal:true,period}):null,degrees,
    tonalDegrees:dominant&&degrees?answerLine(line,{steps,collection,tonic,tonal:true,period}):null,asks,head,
    reason:!known?'its tonic is not known':!head.length?'it begins on neither its tonic nor its dominant':dominant?'its head reaches the dominant':'its head is its tonic alone'};
}
