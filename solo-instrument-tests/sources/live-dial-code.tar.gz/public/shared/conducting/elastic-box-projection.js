// CFM-010 / EC05-09: exact positive weighted affine compromise inside explicit finite coordinate boxes.
// Bounds are owner-authored permissions, never inferred from weights. This is not production/physical admission.
import {dataArray,dataRecord} from './contract-data.js';
import {projectAffineEdits,checkAffineProjection,ELASTIC_PROJECTION_LIMITS} from './elastic-projection.js';
import {Refused,EXACT_LIMITS,ZERO,add,sub,mul,compare,exactOf,exactText,pythonJson,sha256} from '../bounded-exact.js';

export const BOX_PROJECTION_LIMITS=Object.freeze({coordinates:6,equalities:16,faces:729,string:256,
  modelChars:1048576,inputBits:256,certificateBits:8192});
export const BOX_PROJECTION_DEFAULTS=Object.freeze({maxWork:100000,maxFaces:729,maxAffineWork:100000,maxCertificateChars:1048576});
const freeze=Object.freeze,scope='exact-authored-box-and-affine-positive-weighted-objective';
const fail=(message,kind='invalid-input')=>{throw new Refused(message,{kind})};
const inputBoundary=1n<<256n,certificateBoundary=1n<<8192n;
function fields(value,keys){
  if(!dataRecord(value)||Object.keys(value).length!==keys.length||keys.some(key=>!Object.hasOwn(value,key)))fail('Unexpected or missing box-projection fields');
  return value;
}
function count(value,minimum,maximum,label){
  if(!Number.isSafeInteger(value)||value<minimum||value>maximum)fail(`${label} must be an integer in ${minimum}..${maximum}`);
  return value;
}
class WorkBudget {
  constructor(limit){this.limit=count(limit,0,Number.MAX_SAFE_INTEGER,'maxWork');this.used=0}
  charge(amount=1){
    if(!Number.isSafeInteger(amount)||amount<0)throw new Error('Invalid internal box-projection charge');
    if(amount>this.limit-this.used)fail('Box-projection total work exhausted','work-budget');this.used+=amount;
  }
  get remaining(){return this.limit-this.used}
}
function optionsOf(raw){
  if(!dataRecord(raw)||Object.keys(raw).some(key=>!Object.hasOwn(BOX_PROJECTION_DEFAULTS,key)))fail('Unsupported box-projection option');
  const get=key=>Object.hasOwn(raw,key)?raw[key]:BOX_PROJECTION_DEFAULTS[key];
  return freeze({maxWork:count(get('maxWork'),0,Number.MAX_SAFE_INTEGER,'maxWork'),
    maxFaces:count(get('maxFaces'),0,Number.MAX_SAFE_INTEGER,'maxFaces'),
    maxAffineWork:count(get('maxAffineWork'),0,ELASTIC_PROJECTION_LIMITS.maxWork,'maxAffineWork'),
    maxCertificateChars:count(get('maxCertificateChars'),1,Number.MAX_SAFE_INTEGER,'maxCertificateChars')});
}
// Cumulative conservative canonical-JSON character accounting for evidence parsed or constructed in this call.
// Scalar spellings are charged at max(input spelling, canonical spelling); containers/commas are charged below.
function certificateChars(state,amount){
  if(!Number.isSafeInteger(amount)||amount<0)throw new Error('Invalid internal certificate character charge');
  if(amount>state.limits.maxCertificateChars-state.certificateChars)fail('Box certificate text exhausted','certificate-budget');
  state.budget.charge(1+Math.ceil(amount/64));state.certificateChars+=amount;
}
function text(value,state,limit=BOX_PROJECTION_LIMITS.string,certificate=false){
  if(typeof value!=='string'||value.length<1||value.length>limit)fail('Invalid bounded box-projection text');
  state.budget.charge(1+Math.ceil(value.length/64));
  if(certificate)certificateChars(state,value.length+2);
  else{
    state.modelChars+=value.length;if(state.modelChars>BOX_PROJECTION_LIMITS.modelChars)fail('Box model text exhausted','work-budget');
  }
  return value;
}
function integerToken(value,certificate){
  if(typeof value==='bigint'){
    const limit=certificate?certificateBoundary:inputBoundary;
    if(value<=-limit||value>=limit)fail('Raw exact component exceeds its bit limit','arithmetic-budget');
  }else if(!Number.isSafeInteger(value))fail('Use safe integer components or explicit exact rational spellings');
  return value;
}
function rational(value,state,certificate=false){
  state.budget.charge();let input=value;
  if(typeof value==='string'){
    text(value,state,certificate?6000:160,certificate);
    const quotient=value.match(/^([+-]?[0-9]+)\/([0-9]+)$/);
    if(quotient){integerToken(BigInt(quotient[1]),certificate);integerToken(BigInt(quotient[2]),certificate)}
  }else if(typeof value==='number'||typeof value==='bigint')integerToken(value,certificate);
  else{fields(value,['n','d']);input={n:integerToken(value.n,certificate),d:integerToken(value.d,certificate)}}
  const result=exactOf(input,{bits:certificate?EXACT_LIMITS.workBits:EXACT_LIMITS.inputBits});
  if(typeof value!=='string')text(exactText(result),state,certificate?6000:160,certificate);
  else if(certificate){
    const extra=exactText(result).length-value.length;if(extra>0)certificateChars(state,extra);
  }
  return result;
}
const arithmetic=budget=>({
  add(a,b){budget.charge();return add(a,b)},sub(a,b){budget.charge();return sub(a,b)},
  mul(a,b){budget.charge();return mul(a,b)},compare(a,b){budget.charge();return compare(a,b)}
});
function normalize(spec,state){
  fields(spec,['id','revision','coordinates','equalities']);
  const id=text(spec.id,state),revision=count(spec.revision,0,Number.MAX_SAFE_INTEGER,'Revision');
  dataArray(spec.coordinates,BOX_PROJECTION_LIMITS.coordinates,'Box coordinates');
  dataArray(spec.equalities,BOX_PROJECTION_LIMITS.equalities,'Box equalities');
  const coordinates=[],coordinateIds=new Set,equalities=[],equalityIds=new Set;
  for(let i=0;i<spec.coordinates.length;i++){
    state.budget.charge();const c=fields(spec.coordinates[i],['id','unit','target','weight','lock','lower','upper']);
    const name=text(c.id,state),unit=text(c.unit,state);
    if(coordinateIds.has(name))fail('Coordinate IDs must be unique');coordinateIds.add(name);
    const target=rational(c.target,state),weight=rational(c.weight,state),lock=c.lock===null?null:rational(c.lock,state);
    const lower=rational(c.lower,state),upper=rational(c.upper,state);
    if(weight.n<=0n)fail('Weights must be strictly positive');
    coordinates.push(freeze({id:name,unit,target,weight,lock,lower,upper}));
  }
  for(let i=0;i<spec.equalities.length;i++){
    state.budget.charge();const e=fields(spec.equalities[i],['id','coefficients','rhs']),name=text(e.id,state);
    if(equalityIds.has(name))fail('Equality IDs must be unique');equalityIds.add(name);
    dataArray(e.coefficients,BOX_PROJECTION_LIMITS.coordinates,'Box equality coefficients');
    if(e.coefficients.length!==coordinates.length)fail('Equality has the wrong coordinate dimension');
    const coefficients=[];for(let j=0;j<coordinates.length;j++)coefficients.push(rational(e.coefficients[j],state));
    equalities.push(freeze({id:name,coefficients:freeze(coefficients),rhs:rational(e.rhs,state)}));
  }
  const definition=freeze({id,revision,coordinates:freeze(coordinates.map(c=>freeze({id:c.id,unit:c.unit,target:exactText(c.target),
    weight:exactText(c.weight),lock:c.lock===null?null:exactText(c.lock),lower:exactText(c.lower),upper:exactText(c.upper)}))),
    equalities:freeze(equalities.map(e=>freeze({id:e.id,coefficients:freeze(e.coefficients.map(exactText)),rhs:exactText(e.rhs)})))});
  const encoded=pythonJson(definition);
  if(encoded.length>BOX_PROJECTION_LIMITS.modelChars)fail('Box model serialization exhausted','work-budget');
  state.budget.charge(1+coordinates.length+equalities.length+Math.ceil(encoded.length/64));
  const hash=sha256(encoded);state.modelHash=hash;state.definition=definition;
  // Deliberately after normalization of ALL rows: valid contradictions do not conceal malformed input elsewhere.
  let contradiction=null,dimensions=0;
  for(let i=0;i<coordinates.length;i++){
    state.budget.charge();const c=coordinates[i],order=state.math.compare(c.lower,c.upper);
    if(order>0&&!contradiction)contradiction=freeze({coordinate:i,reason:'reversed-bounds'});
    if(c.lock!==null&&(state.math.compare(c.lock,c.lower)<0||state.math.compare(c.lock,c.upper)>0)&&!contradiction)
      contradiction=freeze({coordinate:i,reason:'locked-outside'});
    if(c.lock===null&&order!==0)dimensions++;
  }
  let totalFaces=1;for(let i=0;i<dimensions;i++){state.budget.charge();totalFaces*=3}
  state.totalFaces=totalFaces;
  return freeze({coordinates:freeze(coordinates),equalities:freeze(equalities),definition,hash,totalFaces,contradiction});
}
function faceOf(model,index,state){
  count(index,0,model.totalFaces-1,'Face index');state.budget.charge();let remaining=index,lockRow=model.equalities.length;
  const coordinates=[],modes=[],lockRows=[];
  for(let i=0;i<model.coordinates.length;i++){
    state.budget.charge();const c=model.coordinates[i];let mode,lock;
    if(c.lock!==null){mode='locked';lock=c.lock}
    else if(state.math.compare(c.lower,c.upper)===0){mode='fixed';lock=c.lower}
    else{
      const digit=remaining%3;remaining=Math.floor(remaining/3);mode=['free','lower','upper'][digit];
      lock=digit===0?null:digit===1?c.lower:c.upper;
    }
    modes.push(mode);lockRows.push(lock===null?null:lockRow++);
    const c0=model.definition.coordinates[i];coordinates.push(freeze({id:c0.id,unit:c0.unit,target:c0.target,weight:c0.weight,lock:lock===null?null:exactText(lock)}));
  }
  const spec=freeze({id:`box-face:${model.hash}:${index}`,revision:model.definition.revision,
    coordinates:freeze(coordinates),equalities:model.definition.equalities});
  return freeze({index,spec,modes:freeze(modes),lockRows:freeze(lockRows),rows:lockRow});
}
function subcall(state,face,operation,invoke){
  state.budget.charge();const allowance=Math.min(state.limits.maxAffineWork,state.budget.remaining);
  if(allowance===0)fail('No affine subcall work allowance remains','work-budget');
  const result=invoke(allowance),used=result?.workUsed;
  if(!Number.isSafeInteger(used)||used<0||used>allowance){
    state.budget.charge(allowance);fail('Affine subcall has an invalid work receipt','subcall-receipt');
  }
  state.budget.charge(used);
  state.subcalls.push(freeze({face,operation,allowance,workUsed:used,status:result.status}));
  return result;
}
function vector(raw,length,state){
  dataArray(raw,ELASTIC_PROJECTION_LIMITS.rows,'Affine certificate vector');
  if(raw.length!==length)fail('Affine certificate vector has the wrong size');
  certificateChars(state,Math.max(length-1,0));
  const out=[];for(let i=0;i<length;i++)out.push(rational(raw[i],state,true));return freeze(out);
}
function affineCertificate(raw,face,state){
  if(!dataRecord(raw))fail('Affine evidence must be ordinary data');
  const kind=raw.kind;
  if(kind==='minimum')fields(raw,['kind','modelHash','solution','multipliers']);
  else if(kind==='infeasible')fields(raw,['kind','modelHash','multipliers']);
  else fail('Unsupported affine evidence kind');
  certificateChars(state,(kind==='minimum'?'{"kind":,"modelHash":,"multipliers":[],"solution":[]}'
    :'{"kind":,"modelHash":,"multipliers":[]}').length);
  text(kind,state,16,true);const modelHash=text(raw.modelHash,state,64,true);
  if(!/^[0-9a-f]{64}$/.test(modelHash))fail('Malformed affine model hash');
  const multipliers=vector(raw.multipliers,face.rows,state),solution=kind==='minimum'?vector(raw.solution,face.spec.coordinates.length,state):null;
  const base={kind,modelHash,multipliers:freeze(multipliers.map(exactText))};
  const certificate=freeze(kind==='minimum'?{...base,solution:freeze(solution.map(exactText))}:base);
  return {certificate,solution,multipliers};
}
function inspectFace(model,face,parsed,state){
  const checked=subcall(state,face.index,'check',maxWork=>checkAffineProjection(face.spec,parsed.certificate,{maxWork}));
  if(checked.status!=='PASS')return {status:checked.status,reason:checked.reason,kind:checked.kind};
  if(checked.conclusion==='UNSAT')return {status:'PASS',consistent:false};
  if(checked.conclusion!=='SAT'||parsed.solution===null)fail('Invalid affine checker conclusion','subcall-certificate');
  let objective=ZERO,inside=true,kkt=true;
  for(let i=0;i<model.coordinates.length;i++){
    state.budget.charge();const c=model.coordinates[i],x=parsed.solution[i],mode=face.modes[i],row=face.lockRows[i];
    if(state.math.compare(x,c.lower)<0||state.math.compare(x,c.upper)>0)inside=false;
    if(mode==='lower'&&parsed.multipliers[row].n>0n||mode==='upper'&&parsed.multipliers[row].n<0n)kkt=false;
    const delta=state.math.sub(x,c.target);objective=state.math.add(objective,state.math.mul(c.weight,state.math.mul(delta,delta)));
  }
  return {status:'PASS',consistent:true,inside,kkt:inside&&kkt,objective};
}
function boxHeader(kind,hash,extra,state){
  let schema,extraChars=0;
  if(kind==='box-contradiction'){
    count(extra.coordinate,0,BOX_PROJECTION_LIMITS.coordinates-1,'Contradiction coordinate');
    schema='{"kind":,"modelHash":,"coordinate":,"reason":}';extraChars=String(extra.coordinate).length;
    text(extra.reason,state,32,true);
  }else if(kind==='face-cover'){
    dataArray(extra.faces,BOX_PROJECTION_LIMITS.faces,'Canonical face cover');
    schema='{"kind":,"modelHash":,"faces":[]}';extraChars=Math.max(extra.faces.length-1,0);
  }else{
    count(extra.face,0,BOX_PROJECTION_LIMITS.faces-1,'Face index');
    schema='{"kind":,"modelHash":,"face":,"affine":}';extraChars=String(extra.face).length;
  }
  certificateChars(state,schema.length+extraChars);text(kind,state,32,true);text(hash,state,64,true);
}
function faceEntry(index,state){certificateChars(state,'{"face":,"affine":}'.length+String(index).length)}
function makeCertificate(kind,model,extra,state){
  boxHeader(kind,model.hash,extra,state);return freeze({kind,modelHash:model.hash,...extra});
}
function keepIncumbent(model,face,parsed,inspected,state){
  if(!inspected.inside)return;
  if(state.incumbent&&state.math.compare(inspected.objective,state.bestObjective)>=0)return;
  const certificate=makeCertificate('feasible-face',model,{face:face.index,affine:parsed.certificate},state);
  state.bestObjective=inspected.objective;
  state.incumbent=freeze({solution:parsed.certificate.solution,objective:exactText(inspected.objective),face:face.index,optimal:false,
    certificate});
}
function result(state,status,reason,extra={}){
  return freeze({status,reason,scope,modelHash:state.modelHash,definition:state.definition,
    feasibility:status==='UNSAT'?'UNSAT':state.incumbent?'SAT':'UNKNOWN',optimal:false,searchComplete:false,
    feasibleIncumbent:state.incumbent,facesVisited:state.facesVisited,totalFaces:state.totalFaces,
    unknownFaces:state.unknownFaces,workUsed:state.budget.used,certificateChars:state.certificateChars,
    resources:state.limits,subcalls:freeze([...state.subcalls]),...extra});
}
function run(options,body){
  let state;
  try{
    const limits=optionsOf(options),budget=new WorkBudget(limits.maxWork);
    state={limits,budget,math:arithmetic(budget),modelChars:0,certificateChars:0,modelHash:null,definition:null,
      totalFaces:null,facesVisited:0,unknownFaces:0,subcalls:[],incumbent:null,bestObjective:null};
    budget.charge();return body(state);
  }catch(error){
    if(!(error instanceof Refused))throw error;
    if(state)return result(state,'UNKNOWN',error.message,{kind:error.kind});
    return freeze({status:'UNKNOWN',reason:error.message,kind:error.kind,scope,modelHash:null,feasibility:'UNKNOWN',
      optimal:false,searchComplete:false,feasibleIncumbent:null,workUsed:0});
  }
}
function visit(state){
  if(state.facesVisited>=state.limits.maxFaces)fail('Box face budget exhausted','face-budget');
  state.budget.charge();state.facesVisited++;
}
function directContradiction(model,state,coordinate,reason){
  const i=count(coordinate,0,model.coordinates.length-1,'Contradiction coordinate'),c=model.coordinates[i];
  if(reason==='reversed-bounds')return state.math.compare(c.lower,c.upper)>0;
  if(reason==='locked-outside')return c.lock!==null&&(state.math.compare(c.lock,c.lower)<0||state.math.compare(c.lock,c.upper)>0);
  fail('Unknown box contradiction reason');
}
function certified(state,model,certificate,complete=false){
  return result(state,'SAT','An exact certificate proves the unique authored box minimum',{
    feasibility:'SAT',optimal:true,searchComplete:complete,solution:state.incumbent.solution,
    objective:state.incumbent.objective,certificate});
}

/** Optimization SAT means proved optimal. UNKNOWN can retain a checked feasibleIncumbent with optimal:false.
 * Only authored boxes/equalities/locks are covered; this does not infer concession authority or physical validity. */
export function projectBoxAffineEdits(spec,options={}){
  return run(options,state=>{
    const model=normalize(spec,state);
    if(model.contradiction){
      const {coordinate,reason}=model.contradiction;
      if(!directContradiction(model,state,coordinate,reason))throw new Error('Invalid internal box contradiction');
      return result(state,'UNSAT','An exact coordinate bound/lock contradiction',{searchComplete:true,
        certificate:makeCertificate('box-contradiction',model,{coordinate,reason},state)});
    }
    const faces=[];
    for(let i=0;i<model.totalFaces;i++){
      visit(state);const face=faceOf(model,i,state);
      const solved=subcall(state,i,'solve',maxWork=>projectAffineEdits(face.spec,{maxWork}));
      if(solved.status==='UNKNOWN'){state.unknownFaces++;faces.push(null);continue}
      if(!['SAT','UNSAT'].includes(solved.status))fail('Invalid affine solver conclusion','subcall-certificate');
      const parsed=affineCertificate(solved.certificate,face,state),inspected=inspectFace(model,face,parsed,state);
      if(inspected.status==='UNKNOWN'){state.unknownFaces++;faces.push(null);continue}
      if(inspected.status!=='PASS')fail('The affine solver certificate failed independent checking','subcall-certificate');
      faceEntry(i,state);faces.push(freeze({face:i,affine:parsed.certificate}));
      if(!inspected.consistent){
        if(i===0)return result(state,'UNSAT','The mandatory affine constraints are inconsistent',{searchComplete:true,
          certificate:makeCertificate('affine-infeasible',model,{face:0,affine:parsed.certificate},state)});
        continue;
      }
      keepIncumbent(model,face,parsed,inspected,state);
      if(inspected.kkt)return certified(state,model,makeCertificate('kkt',model,{face:i,affine:parsed.certificate},state));
    }
    if(state.unknownFaces)return result(state,'UNKNOWN','Some canonical faces have no checked affine conclusion',{kind:'unresolved-faces',searchComplete:false});
    const certificate=makeCertificate('face-cover',model,{faces:freeze(faces)},state);
    if(state.incumbent)return certified(state,model,certificate,true);
    return result(state,'UNSAT','Complete checked active-face coverage contains no box-feasible projection',{searchComplete:true,certificate});
  });
}

/** Independently reconstruct/check original model and every required face. Never invokes either optimizer.
 * PASS declares SAT/UNSAT and whether optimality was proved; FAIL rejects evidence, not the musical model. */
export function checkBoxAffineProjection(spec,certificate,options={}){
  return run(options,state=>{
    const model=normalize(spec,state);
    if(!dataRecord(certificate))fail('Box evidence must be ordinary data');
    const kind=certificate.kind;
    if(kind==='box-contradiction')fields(certificate,['kind','modelHash','coordinate','reason']);
    else if(kind==='face-cover')fields(certificate,['kind','modelHash','faces']);
    else if(['kkt','feasible-face','affine-infeasible'].includes(kind))fields(certificate,['kind','modelHash','face','affine']);
    else fail('Unsupported box evidence kind');
    boxHeader(kind,certificate.modelHash,certificate,state);const modelHash=certificate.modelHash;
    if(!/^[0-9a-f]{64}$/.test(modelHash))fail('Malformed box model hash');
    const reject=reason=>result(state,'FAIL',reason);
    const pass=(conclusion,optimal,reason,searchComplete=false)=>result(state,'PASS',reason,{conclusion,feasibility:conclusion,optimal,searchComplete,
      ...(state.incumbent?{solution:state.incumbent.solution,objective:state.incumbent.objective}:{})});
    if(modelHash!==model.hash)return reject('Box certificate belongs to another model snapshot');
    if(kind==='box-contradiction')return directContradiction(model,state,certificate.coordinate,certificate.reason)
      ?pass('UNSAT',false,'Exact original bound/lock contradiction',true):reject('The asserted bound/lock contradiction does not hold');
    if(kind==='face-cover'){
      dataArray(certificate.faces,BOX_PROJECTION_LIMITS.faces,'Canonical face cover');
      if(certificate.faces.length!==model.totalFaces)return reject('Face cover is incomplete');
      for(let i=0;i<model.totalFaces;i++){
        visit(state);const entry=fields(certificate.faces[i],['face','affine']);
        if(entry.face!==i)return reject('Face IDs must occur exactly once in canonical order');
        faceEntry(i,state);
        const face=faceOf(model,i,state),parsed=affineCertificate(entry.affine,face,state),inspected=inspectFace(model,face,parsed,state);
        if(inspected.status==='UNKNOWN')return result(state,'UNKNOWN',inspected.reason,{kind:inspected.kind??'affine-refusal'});
        if(inspected.status!=='PASS')return reject(inspected.reason);
        if(inspected.consistent)keepIncumbent(model,face,parsed,inspected,state);
      }
      return state.incumbent?pass('SAT',true,'Complete checked active-face coverage proves the unique box minimum',true)
        :pass('UNSAT',false,'Complete checked active-face coverage proves the box infeasible',true);
    }
    visit(state);const face=faceOf(model,certificate.face,state),parsed=affineCertificate(certificate.affine,face,state);
    const inspected=inspectFace(model,face,parsed,state);
    if(inspected.status==='UNKNOWN')return result(state,'UNKNOWN',inspected.reason,{kind:inspected.kind??'affine-refusal'});
    if(inspected.status!=='PASS')return reject(inspected.reason);
    if(kind==='affine-infeasible')return face.index===0&&!inspected.consistent
      ?pass('UNSAT',false,'The mandatory affine constraints have a checked contradiction',true):reject('Global affine infeasibility requires the inconsistent canonical face zero');
    if(!inspected.consistent||!inspected.inside)return reject('The affine point does not establish original box feasibility');
    keepIncumbent(model,face,parsed,inspected,state);
    if(kind==='feasible-face')return pass('SAT',false,'The checked point is feasible; no optimality is claimed');
    return inspected.kkt?pass('SAT',true,'Exact equality, box feasibility and signed stationarity prove the unique minimum')
      :reject('A newly imposed one-sided bound multiplier has the wrong KKT sign');
  });
}
