// Elastic contracts (research/fugue-and-coordination/MUSEBOTS_ELASTIC_CONSTRAINTS_ADDENDUM.md, EC01-EC03): a musical
// relationship that may yield, said as what may change, which way, how far, at what cost and to whom -- never one
// weight. "Replace the binary hard/soft treatment of musical relationships with elastic contracts. Each contract
// specifies what can change, in which direction, by how much, for how long, at what cost, under whose authority, and in
// response to which other objectives."
//
// A contract measures one signed residual r in its own units (seconds of a chord's spread, cents of a canon's pitch,
// beats of an entry): within its free band it costs nothing; beyond it, each side normalized by its own scale and
// raised to its power, times its stiffness; past its cap it is not allowed at all. Permission (the cap), reluctance (the
// stiffness) and rank (the tier) are separate: a stiffness of 0 never opens a cap, and a residual that cannot be
// measured is UNKNOWN, never 0 (EC01's acceptance).
//
// A compromise e from 0 to 1 moves a cap between its strict and its loose ends, a(e) = strict + e^gamma (loose -
// strict) (EC03): nested caps, so more compromise never takes away what less allowed.

const finite=Number.isFinite;
const side=(value,name)=>{
  const out={minus:Number(value?.minus??value),plus:Number(value?.plus??value)};
  if(!(out.minus>=0&&out.plus>=0))throw new RangeError(`An elastic contract's ${name} is two non-negative amounts, {minus, plus}`);
  return Object.freeze(out);
};

// A contract, checked and frozen. `relation`: what it holds (a name the caller evaluates); `units`: its residual's
// ('s', 'cents', 'beats'); `free`, `cap`, `scale`: {minus, plus} (a number for both); `stiffness` >= 0; `power` >= 1;
// `tier`: its rank (lower yields first); `yieldTo`: the reasons it may yield to; `evidence`: what must be measured.
export function elasticContract({id,revision=1,relation,units,free=0,cap=Infinity,scale=1,stiffness=1,power=2,tier=0,yieldTo=[],evidence=[]}){
  if(typeof id!=='string'||!id)throw new TypeError('An elastic contract has an id');
  if(typeof relation!=='string'||!relation||typeof units!=='string'||!units)throw new TypeError(`Contract ${id} names its relation and its residual's units`);
  const f=side(free,'free band'),c=side(cap,'cap'),s=side(scale,'scale');
  if(c.minus<f.minus||c.plus<f.plus)throw new RangeError(`Contract ${id}: its cap within its free band`);
  if(!(s.minus>0&&s.plus>0))throw new RangeError(`Contract ${id}: its scale is positive`);
  // (Finite: an infinite stiffness's cost at its free band is 0 times infinity, no number -- a cap says what may not be.)
  if(!(Number(stiffness)>=0&&finite(Number(stiffness)))||!(Number(power)>=1&&finite(Number(power))))throw new RangeError(`Contract ${id}: a finite stiffness from 0, a finite power from 1`);
  if(!Number.isInteger(revision)||revision<1)throw new RangeError(`Contract ${id}: its revision a positive integer`);
  return Object.freeze({id,revision,relation,units,free:f,cap:c,scale:s,stiffness:Number(stiffness),power:Number(power),tier:Number(tier)||0,
    yieldTo:Object.freeze([...yieldTo].map(String)),evidence:Object.freeze([...evidence].map(String))});
}

// A residual held to its contract: {status: 'pass' | 'fail' | 'unknown', residual, z (its normalized excess), cost}.
// Not measured (not a finite number): unknown, never 0. Past its cap: fail, at no cost a solver could weigh.
export function held(contract,residual){
  const r=Number(residual);
  if(residual==null||!finite(r))return Object.freeze({status:'unknown',residual:null,z:null,cost:null});
  const over=r>=0?r>contract.cap.plus:-r>contract.cap.minus;
  const z=r>=0?Math.max(0,r-contract.free.plus)/contract.scale.plus:Math.max(0,-r-contract.free.minus)/contract.scale.minus;
  return Object.freeze({status:over?'fail':'pass',residual:r,z,cost:over?Infinity:contract.stiffness*z**contract.power});
}

// A cap between its strict and loose ends at a compromise e in [0, 1]: strict + e^gamma (loose - strict).
export function envelope(strict,loose,e,gamma=1){
  const x=Math.max(0,Math.min(1,Number(e)||0));
  if(!(loose>=strict))throw new RangeError('A loose end at least its strict end');
  if(!(gamma>0&&finite(gamma)))throw new RangeError('An envelope\'s gamma is positive and finite');
  if(!finite(strict)||!finite(loose))throw new RangeError('An envelope\'s ends are finite (an unbounded cap has no interpolation here)');
  return x>=1?loose:strict+x**gamma*(loose-strict);
}

// The contract at a compromise e: its caps moved from `strict` (its own) toward `loose` ({minus, plus}), a new revision
// (a changed contract is a new one, EC01). Its free band and its stiffness stay.
export function compromised(contract,e,{loose,gamma=1}){
  const l=side(loose,'loose cap');
  return elasticContract({...contract,revision:contract.revision+1,
    cap:{minus:envelope(contract.cap.minus,Math.max(contract.cap.minus,l.minus),e,gamma),plus:envelope(contract.cap.plus,Math.max(contract.cap.plus,l.plus),e,gamma)}});
}
