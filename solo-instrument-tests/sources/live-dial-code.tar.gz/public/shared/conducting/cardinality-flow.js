// Exact circulation on one completely supplied finite graph. Musical-domain completeness is a caller premise.
// See research/fugue-and-coordination/CADENCE_FLOW_PROOF.md for the reduction, certificates and resource scope.
import {Refused, sha256} from '../bounded-exact.js';
import {dataArray, dataRecord} from './contract-data.js';

const DEFAULTS = Object.freeze({maxWork: 2000000, maxNodes: 4096, maxEdges: 65536,
  maxCertificateEntries: 65536, maxTextChars: 8388608, maxHashChars: 8388608, maxScalarDigits: 64});
const OPTION_NAMES = Object.freeze(Object.keys(DEFAULTS));
const MAX_ID_CHARS = 256, MAX_SCALAR_DIGITS = 64, MAX_ARRAY_LENGTH = 0xffffffff;
const FLOW_KIND = 'bounded-circulation-flow-v1', CUT_KIND = 'bounded-circulation-cut-v1';
const refuse = (message, kind = 'invalid-input') => { throw new Refused(message, {kind}); };
const safeNatural = value => typeof value === 'number' && Number.isSafeInteger(value) && value >= 0;

// No arbitrary callbacks, getters or custom traversal. Inert data, stable intrinsics and no proxies are assumed.
// Reflect.ownKeys itself must enumerate supplied properties before an excessive-property shape can be refused.
function record(value, names, ctx, label) {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) refuse(`${label} must be a data record`);
  const keys = Reflect.ownKeys(value);
  if (ctx) ctx.charge(keys.length + 1);
  if (keys.length !== names.length || !dataRecord(value)) refuse(`${label} has an invalid data schema`);
  for (let i = 0; i < names.length; i++) if (!Object.hasOwn(value, names[i])) refuse(`${label} has an invalid data schema`);
  return value;
}
function optionsOf(value) {
  if (value === undefined) value = {};
  if (value === null || typeof value !== 'object' || Array.isArray(value)) refuse('Options must be an ordinary data record');
  const keys = Reflect.ownKeys(value);
  if (keys.length > OPTION_NAMES.length || !dataRecord(value)) refuse('Options must be a bounded ordinary data record');
  for (let i = 0; i < keys.length; i++) if (!OPTION_NAMES.includes(keys[i])) refuse('Unknown option');
  const result = {};
  for (let i = 0; i < OPTION_NAMES.length; i++) {
    const name = OPTION_NAMES[i], limit = Object.hasOwn(value, name) ? value[name] : DEFAULTS[name];
    if (!safeNatural(limit)) refuse('Resource limits must be nonnegative safe integers');
    result[name] = limit === 0 ? 0 : limit;
  }
  if (result.maxScalarDigits > MAX_SCALAR_DIGITS) refuse('The scalar text ceiling is 64 decimal digits');
  return Object.freeze(result);
}
function context(options) {
  return {limits: optionsOf(options), used: 0, textUsed: 0,
    charge(amount = 1) {
      if (!safeNatural(amount)) refuse('Invalid work charge', 'internal-error');
      if (amount > this.limits.maxWork - this.used) refuse('Work budget exhausted', 'work-budget');
      this.used += amount;
    },
    text(value) {
      if (value.length > this.limits.maxTextChars - this.textUsed) refuse('Text budget exhausted', 'text-budget');
      this.charge(value.length); this.textUsed += value.length;
    }};
}
function array(value, limit, ctx, label) {
  if (!Array.isArray(value)) refuse(`${label} must be a data array`);
  const length = Object.getOwnPropertyDescriptor(value, 'length');
  if (!length || !safeNatural(length.value) || length.value > limit) refuse(`${label} exceeds its entry limit`, 'shape-budget');
  ctx.charge(length.value + 1);
  // Checking own-key count first also bounds dataArray's second property enumeration on successful inputs.
  if (Reflect.ownKeys(value).length !== length.value + 1) refuse(`${label} must be a dense data array`);
  return dataArray(value, limit, label);
}
function identifier(value, ctx) {
  if (typeof value !== 'string' || value.length === 0 || value.length > MAX_ID_CHARS) refuse('IDs must contain 1..256 UTF-16 code units');
  ctx.text(value); return value;
}
function scalar(value, ctx) {
  if (typeof value !== 'string' || value.length === 0 || value.length > ctx.limits.maxScalarDigits) refuse('Scalar text exceeds its decimal digit limit', 'scalar-budget');
  ctx.text(value);
  if (!/^(0|[1-9][0-9]*)$/.test(value) || /[^0-9]/.test(value)) refuse('Scalar text must be a canonical nonnegative integer');
  return BigInt(value);
}
function scalarText(value, ctx) {
  const text = value.toString();
  if (text.length > ctx.limits.maxScalarDigits) refuse('Scalar text exceeds its decimal digit limit', 'scalar-budget');
  ctx.text(text); return text;
}
function hashText(value, ctx) {
  if (typeof value !== 'string' || value.length !== 64 || !/^[0-9a-f]{64}$/.test(value)) refuse('Invalid model hash');
  ctx.text(value); return value;
}
function canonicalHash(id, revision, nodes, edges, ctx) {
  const chunks = []; let chars = 0;
  const append = text => {
    if (text.length > ctx.limits.maxHashChars - chars) refuse('Canonical hash text budget exhausted', 'hash-budget');
    ctx.charge(text.length); chars += text.length; chunks.push(text);
  };
  append('{"id":'); append(JSON.stringify(id)); append(',"revision":'); append(String(revision)); append(',"nodes":[');
  for (let i = 0; i < nodes.length; i++) { if (i) append(','); append(JSON.stringify(nodes[i])); }
  append('],"edges":[');
  for (let i = 0; i < edges.length; i++) {
    const edge = edges[i]; if (i) append(',');
    append('{"id":'); append(JSON.stringify(edge.id)); append(',"from":'); append(JSON.stringify(nodes[edge.from]));
    append(',"to":'); append(JSON.stringify(nodes[edge.to])); append(',"lower":'); append(edge.lower.toString());
    append(',"upper":'); append(edge.upper.toString()); append('}');
  }
  append(']}');
  // The charge above includes the canonical character count. UTF-8/SHA work has a constant-factor bound in it.
  return sha256(chunks.join(''));
}
function normalize(spec, ctx) {
  record(spec, ['id', 'revision', 'nodes', 'edges'], ctx, 'Graph');
  const id = identifier(spec.id, ctx);
  if (!safeNatural(spec.revision)) refuse('Revision must be a nonnegative safe integer');
  const revision = spec.revision === 0 ? 0 : spec.revision;
  const rawNodes = array(spec.nodes, ctx.limits.maxNodes, ctx, 'Nodes');
  if (rawNodes.length > MAX_ARRAY_LENGTH - 2) refuse('Auxiliary vertices exceed host array indexing', 'shape-budget');
  const nodes = [], nodeIndex = new Map();
  for (let i = 0; i < rawNodes.length; i++) {
    ctx.charge(); const name = identifier(rawNodes[i], ctx);
    if (nodeIndex.has(name)) refuse('Duplicate node ID');
    nodeIndex.set(name, i); nodes.push(name);
  }
  const rawEdges = array(spec.edges, ctx.limits.maxEdges, ctx, 'Edges'), edges = [], edgeIndex = new Map();
  for (let i = 0; i < rawEdges.length; i++) {
    const row = record(rawEdges[i], ['id', 'from', 'to', 'lower', 'upper'], ctx, 'Edge');
    const edgeId = identifier(row.id, ctx), fromId = identifier(row.from, ctx), toId = identifier(row.to, ctx);
    if (edgeIndex.has(edgeId)) refuse('Duplicate edge ID');
    if (!nodeIndex.has(fromId) || !nodeIndex.has(toId)) refuse('An edge endpoint is undeclared');
    if (!safeNatural(row.lower) || !safeNatural(row.upper) || row.lower > row.upper) refuse('Bounds must be ordered nonnegative safe integers');
    ctx.charge();
    edgeIndex.set(edgeId, i);
    edges.push(Object.freeze({id: edgeId, from: nodeIndex.get(fromId), to: nodeIndex.get(toId), lower: BigInt(row.lower), upper: BigInt(row.upper)}));
  }
  Object.freeze(nodes); Object.freeze(edges);
  const hash = canonicalHash(id, revision, nodes, edges, ctx);
  return Object.freeze({id, revision, nodes, edges, nodeIndex, edgeIndex, hash});
}
function balances(model, ctx) {
  ctx.charge(model.nodes.length);
  const values = new Array(model.nodes.length).fill(0n);
  for (let i = 0; i < model.edges.length; i++) {
    ctx.charge(); const edge = model.edges[i]; values[edge.from] -= edge.lower; values[edge.to] += edge.lower;
  }
  let required = 0n;
  for (let i = 0; i < values.length; i++) { ctx.charge(); if (values[i] > 0n) required += values[i]; }
  return {values, required};
}
function cutCapacity(model, demand, inside, ctx) {
  let result = 0n;
  for (let i = 0; i < model.edges.length; i++) {
    ctx.charge(); const edge = model.edges[i];
    if (inside[edge.from] && !inside[edge.to]) result += edge.upper - edge.lower;
  }
  for (let i = 0; i < model.nodes.length; i++) {
    ctx.charge(); const b = demand.values[i];
    if (b > 0n && !inside[i]) result += b;
    if (b < 0n && inside[i]) result -= b;
  }
  return result;
}
function originalFlowValid(model, values, ctx) {
  ctx.charge(model.nodes.length); const balance = new Array(model.nodes.length).fill(0n);
  let valid = values.length === model.edges.length;
  for (let i = 0; i < model.edges.length; i++) {
    ctx.charge(); const edge = model.edges[i], value = values[i];
    if (typeof value !== 'bigint' || value < edge.lower || value > edge.upper) { valid = false; continue; }
    balance[edge.from] -= value; balance[edge.to] += value;
  }
  for (let i = 0; i < balance.length; i++) { ctx.charge(); if (balance[i] !== 0n) valid = false; }
  return valid;
}
function emitFlow(model, values, ctx) {
  if (model.edges.length > ctx.limits.maxCertificateEntries) refuse('Flow certificate entry budget exhausted', 'certificate-budget');
  ctx.charge(model.edges.length + 1); ctx.text(model.hash);
  const flows = [];
  for (let i = 0; i < model.edges.length; i++) {
    const edgeId = model.edges[i].id; ctx.text(edgeId);
    flows.push(Object.freeze({edgeId, value: scalarText(values[i], ctx)}));
  }
  return Object.freeze({kind: FLOW_KIND, modelHash: model.hash, flows: Object.freeze(flows)});
}
function emitCut(model, inside, required, capacity, ctx) {
  let count = 0;
  for (let i = 0; i < inside.length; i++) { ctx.charge(); if (inside[i]) count++; }
  if (count > ctx.limits.maxCertificateEntries) refuse('Cut certificate entry budget exhausted', 'certificate-budget');
  ctx.charge(count + 1); ctx.text(model.hash);
  const sourceSide = [];
  for (let i = 0; i < inside.length; i++) {
    ctx.charge(); if (inside[i]) { ctx.text(model.nodes[i]); sourceSide.push(model.nodes[i]); }
  }
  return Object.freeze({kind: CUT_KIND, modelHash: model.hash, sourceSide: Object.freeze(sourceSide),
    required: scalarText(required, ctx), capacity: scalarText(capacity, ctx)});
}
function solve(model, ctx) {
  const demand = balances(model, ctx), n = model.nodes.length, m = model.edges.length;
  if (demand.required === 0n) {
    ctx.charge(m); const values = [];
    for (let i = 0; i < m; i++) values.push(model.edges[i].lower);
    if (!originalFlowValid(model, values, ctx)) refuse('Internal flow invariant failed', 'internal-error');
    return {status: 'SAT', certificate: emitFlow(model, values, ctx)};
  }
  const size = n + 2, source = n, sink = n + 1;
  ctx.charge(size + m);
  const adjacency = Array.from({length: size}, () => []), originalArcs = new Array(m).fill(null);
  const addArc = (from, to, capacity) => {
    ctx.charge(); if (capacity === 0n || from === to) return null;
    if (adjacency[from].length >= MAX_ARRAY_LENGTH || adjacency[to].length >= MAX_ARRAY_LENGTH) refuse('Residual adjacency exceeds host array indexing', 'shape-budget');
    const forward = {to, reverse: adjacency[to].length, remaining: capacity};
    const backward = {to: from, reverse: adjacency[from].length, remaining: 0n};
    adjacency[from].push(forward); adjacency[to].push(backward); return forward;
  };
  for (let i = 0; i < m; i++) {
    const edge = model.edges[i]; originalArcs[i] = addArc(edge.from, edge.to, edge.upper - edge.lower);
  }
  for (let i = 0; i < n; i++) {
    ctx.charge(); const b = demand.values[i];
    if (b > 0n) addArc(source, i, b); else if (b < 0n) addArc(i, sink, -b);
  }
  const breadthFirst = () => {
    ctx.charge(3 * size);
    const parent = new Array(size).fill(-1), arc = new Array(size).fill(-1), queue = new Array(size);
    let head = 0, tail = 1; queue[0] = source; parent[source] = source;
    while (head < tail) {
      ctx.charge(); const from = queue[head++], row = adjacency[from];
      for (let i = 0; i < row.length; i++) {
        ctx.charge(); const edge = row[i];
        if (edge.remaining === 0n || parent[edge.to] !== -1) continue;
        ctx.charge(); parent[edge.to] = from; arc[edge.to] = i; queue[tail++] = edge.to;
        if (edge.to === sink) return {parent, arc};
      }
    }
    return {parent, arc};
  };
  let value = 0n;
  while (value < demand.required) {
    ctx.charge(); const search = breadthFirst();
    if (search.parent[sink] === -1) {
      ctx.charge(n); const inside = new Array(n);
      for (let i = 0; i < n; i++) inside[i] = search.parent[i] !== -1;
      const capacity = cutCapacity(model, demand, inside, ctx);
      if (!(capacity < demand.required)) refuse('Internal cut invariant failed', 'internal-error');
      return {status: 'UNSAT', certificate: emitCut(model, inside, demand.required, capacity, ctx)};
    }
    let amount = demand.required - value;
    for (let at = sink; at !== source; at = search.parent[at]) {
      ctx.charge(); const edge = adjacency[search.parent[at]][search.arc[at]];
      if (edge.remaining < amount) amount = edge.remaining;
    }
    if (amount <= 0n) refuse('Internal augmentation invariant failed', 'internal-error');
    for (let at = sink; at !== source; at = search.parent[at]) {
      ctx.charge(); const edge = adjacency[search.parent[at]][search.arc[at]];
      edge.remaining -= amount; adjacency[edge.to][edge.reverse].remaining += amount;
    }
    ctx.charge(); value += amount;
  }
  ctx.charge(m); const values = [];
  for (let i = 0; i < m; i++) {
    const edge = model.edges[i], arc = originalArcs[i];
    values.push(edge.lower + (arc === null ? 0n : edge.upper - edge.lower - arc.remaining));
  }
  if (!originalFlowValid(model, values, ctx)) refuse('Internal flow invariant failed', 'internal-error');
  return {status: 'SAT', certificate: emitFlow(model, values, ctx)};
}
function check(model, certificate, ctx) {
  // Inspect descriptors before selecting a schema or reading any witness value.
  if (certificate === null || typeof certificate !== 'object' || Array.isArray(certificate)) refuse('Certificate must be a data record');
  const keys = Reflect.ownKeys(certificate); ctx.charge(keys.length + 1);
  if (keys.length > 5 || !dataRecord(certificate)) refuse('Certificate must be a bounded data record');
  const kind = certificate.kind;
  if (kind === FLOW_KIND) {
    record(certificate, ['kind', 'modelHash', 'flows'], ctx, 'Flow certificate');
    const hash = hashText(certificate.modelHash, ctx);
    const rows = array(certificate.flows, ctx.limits.maxCertificateEntries, ctx, 'Certificate flows');
    ctx.charge(model.edges.length); const values = new Array(model.edges.length), seen = new Set();
    let valid = hash === model.hash && rows.length === model.edges.length;
    for (let i = 0; i < rows.length; i++) {
      const row = record(rows[i], ['edgeId', 'value'], ctx, 'Certificate flow');
      const id = identifier(row.edgeId, ctx), value = scalar(row.value, ctx);
      if (seen.has(id) || !model.edgeIndex.has(id)) valid = false;
      else values[model.edgeIndex.get(id)] = value;
      seen.add(id);
    }
    const originalValid = originalFlowValid(model, values, ctx);
    return {status: valid && originalValid ? 'PASS' : 'FAIL', conclusion: valid && originalValid ? 'SAT' : null};
  }
  if (kind === CUT_KIND) {
    record(certificate, ['kind', 'modelHash', 'sourceSide', 'required', 'capacity'], ctx, 'Cut certificate');
    const hash = hashText(certificate.modelHash, ctx);
    const rows = array(certificate.sourceSide, ctx.limits.maxCertificateEntries, ctx, 'Cut source side');
    const statedRequired = scalar(certificate.required, ctx), statedCapacity = scalar(certificate.capacity, ctx);
    ctx.charge(model.nodes.length); const inside = new Array(model.nodes.length).fill(false), seen = new Set();
    let valid = hash === model.hash;
    for (let i = 0; i < rows.length; i++) {
      ctx.charge(); const id = identifier(rows[i], ctx);
      if (seen.has(id) || !model.nodeIndex.has(id)) valid = false;
      else inside[model.nodeIndex.get(id)] = true;
      seen.add(id);
    }
    const demand = balances(model, ctx), capacity = cutCapacity(model, demand, inside, ctx);
    valid = valid && statedRequired === demand.required && statedCapacity === capacity && capacity < demand.required;
    return {status: valid ? 'PASS' : 'FAIL', conclusion: valid ? 'UNSAT' : null};
  }
  refuse('Unsupported certificate kind');
}
function unknown(error, ctx, model, checker) {
  // No error-message accessor is read; unexpected host failures are not mathematical decisions.
  const descriptor = error instanceof Refused ? Object.getOwnPropertyDescriptor(error, 'kind') : null;
  const refusalKind = descriptor && typeof descriptor.value === 'string' ? descriptor.value : 'internal-error';
  return Object.freeze({status: 'UNKNOWN', ...(checker ? {conclusion: null} : {}), modelHash: model ? model.hash : null,
    workUsed: ctx ? ctx.used : 0, refusalKind});
}

/** Complete finite graph only. UNKNOWN carries no partial certificate and never asserts graph infeasibility. */
export function solveBoundedCirculation(spec, options) {
  let ctx = null, model = null;
  try {
    ctx = context(options); ctx.charge(); model = normalize(spec, ctx);
    const result = solve(model, ctx);
    return Object.freeze({...result, modelHash: model.hash, workUsed: ctx.used});
  } catch (error) { return unknown(error, ctx, model, false); }
}

/** Reconstructs the graph and checks a witness without running residual search or trusting its state. */
export function checkBoundedCirculation(spec, certificate, options) {
  let ctx = null, model = null;
  try {
    ctx = context(options); ctx.charge(); model = normalize(spec, ctx);
    const result = check(model, certificate, ctx);
    return Object.freeze({...result, modelHash: model.hash, workUsed: ctx.used});
  } catch (error) { return unknown(error, ctx, model, true); }
}
