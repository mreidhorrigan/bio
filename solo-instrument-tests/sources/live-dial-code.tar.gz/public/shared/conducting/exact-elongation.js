// An elongation written exactly (the owner, 2 October 2026: a duration's elongation is not rubato, and a mathematical
// problem goes to Astra rather than a compromise; CFM-003, conducting/elongation-ratio.js elongationRatio): a line
// elongated by E sounds every note E times longer at the band's tempo, and E is one of the ratios p/q its notation
// writes exactly -- its notes at one consistent spelling (binary divisions of the notated note, at most one tuplet
// nested once, tied units) -- the one nearest the E asked, a simpler spelling preferred by ELONGATION_NOTATION's
// tradeoff. Not the band's grid rounded and the rest made fewer notes, as before (gridElongation), nor a tempo of the
// line's own drifting off the band's beat, as before that.
//
// The candidates are prepared once for a meter and a source lattice (elongationRatio's complete enumeration under the
// notation bounds below, every exact ratio from 1 to ELONGATION_NOTATION.most), the conductor preparing its meter's
// ticks' as it plans a section of the form, a line its own lattice's as it plans its phrase; a line then chooses among
// them. Its source lattice is declared, never assumed (Astra's handoff: "an explicit source lattice"): the positions
// j/G notated notes its source's onsets and releases lie on (sourceLattice: their least common denominator).
import {elongationRatio,ELONGATION_LIMITS} from './elongation-ratio.js';

// Ours, authored: the spellings an elongated line may take (Astra's grammar: binary depth, tuplet levels and their
// labels, tied written units, each's cost), the largest ratio, and how much exactness a unit of complexity is worth.
export const ELONGATION_NOTATION=Object.freeze({
  // No largest tuplet of its own (the owner, 4 October 2026, on never having seen an eleven: "Let ... stretched lines use
  // any count ..., weighted toward small counts"): its labels as large as the grammar admits (ELONGATION_LIMITS.label),
  // each one's cost growing with its numbers (weights.label), so that over the elongations a line may ask a plain
  // spelling or a triplet comes most often and an eleven or a thirteen now and then (measured 4 October 2026 over E from
  // 1 to 4 in 7/8: none 21%, 3 9%, 5 17%, 7 16%, 9 8%, 11 9%, 13 4%, larger under 1%; the cap had been 7).
  notation:Object.freeze({maxBinaryDepth:2,maxTupletDepth:1,maxActual:ELONGATION_LIMITS.label,maxNormal:ELONGATION_LIMITS.label,maxWrittenUnits:8,
    weights:Object.freeze({binary:1,tuplet:2,label:'1/4',tie:'1/2'})}),
  maxComplexity:12,most:64,tradeoff:.01,
});
const prepared=new Map;
const meterKey=(meter,G)=>JSON.stringify([meter.numerator,meter.denominator,meter.subdivision,meter.groups,G]);
// An exact number's text ('7/2', '3') as a number.
const valueOf=text=>{const [n,d='1']=String(text).split('/');return Number(n)/Number(d)};
// The exact ratios a meter's line may be elongated by: [{ratio (a number, its value), exact ('p/q'), complexity}], by
// ratio, each with its solver's candidate (`contract`, not enumerable: for its audits, auditElongationPositions and
// elongationDrift). `meter`: {numerator, denominator (a power of two), subdivision (ticks a notated note), groups};
// `sourceDivision`: G, its source's positions j/G notated notes -- its ticks' where not said. A meter or a lattice its
// grammar cannot spell (an irrational denominator, no groups, a lattice past its bounds) has none: [] (its line is not
// elongated exactly), its refusal said (`refused`, the solver's reason) and not kept, so that a later call -- with more
// allowed -- asks again (Astra's review: only a complete answer is kept).
export function elongationCandidates(meter,{sourceDivision=null}={}){
  const groups=Array.isArray(meter?.groups)&&meter.groups.length?meter.groups.map(Number):[Number(meter?.numerator)||1];
  const plain={numerator:groups.reduce((a,b)=>a+b,0),denominator:Number(meter?.denominator)||4,subdivision:Math.max(1,Math.round(Number(meter?.subdivision)||1)),groups};
  const G=sourceDivision??plain.subdivision,key=meterKey(plain,G);if(prepared.has(key))return prepared.get(key);
  try{
    const {notation,maxComplexity,most}=ELONGATION_NOTATION;
    const result=elongationRatio({E:1,meter:plain,bpm:60,sourceDivision:G,minRatio:1,maxRatio:most,notation,maxComplexity,complexityWeight:0});
    const out=Object.freeze(result.candidates.map(candidate=>Object.freeze(Object.defineProperty({ratio:Number(candidate.p)/Number(candidate.q),exact:candidate.ratio,complexity:valueOf(candidate.complexity)},'contract',{value:candidate}))));
    prepared.set(key,out);return out;
  }catch(error){
    const none=[];Object.defineProperty(none,'refused',{value:String(error?.message??error)});return Object.freeze(none);
  }
}
// The candidate a line takes for an elongation `E` asked, no longer than `most` (its players' sustain: section-voices.js
// sustainOf), by |E - ratio| + tradeoff x complexity; none above 1 -> {ratio: 1, exact: '1', complexity: 0}.
export function nearestElongation(E,candidates,{most=Infinity}={}){
  const asked=Math.max(1,Number(E)||1),{tradeoff}=ELONGATION_NOTATION;let best=null;
  for(const candidate of candidates){
    if(candidate.ratio>most+1e-12)break;
    const cost=Math.abs(asked-candidate.ratio)+tradeoff*candidate.complexity;
    if(!best||cost<best.cost-1e-12)best={candidate,cost};
  }
  return best&&best.candidate.ratio>=1?best.candidate:Object.freeze({ratio:1,exact:'1',complexity:0});
}
// A source position's exact fraction [n, d] (notated notes, from a float the sum of its plan's ticks and its tuplets'
// fractions, its error some ulps), by continued fractions within 1e-11 of it -- every number has a fraction of
// denominator 65536 or less within about 2e-10 (Dirichlet), so one within 1e-11 is no accident, and its rounding is far
// less; null where none has a denominator up to `most`.
export function fractionOf(x,most=1<<16){
  if(!Number.isFinite(x)||x<0)return null;
  let [h0,h1,k0,k1]=[1,0,0,1],v=x;const within=1e-11*Math.max(1,x);
  for(let i=0;i<64;i++){
    const a=Math.floor(v);[h0,h1]=[a*h0+h1,h0];[k0,k1]=[a*k0+k1,k0];
    if(k0>most)return null;if(Math.abs(x-h0/k0)<within)return [h0,k0];
    const rest=v-a;if(!(rest>0))return null;v=1/rest;
  }
  return null;
}
const gcd=(a,b)=>{while(b){[a,b]=[b,a%b]}return a};
// A source's lattice G: the least common denominator of its positions (notated notes), each its exact fraction
// (fractionOf); null where one has none, or past `most`.
export function sourceLattice(positions,most=1<<16){
  let G=1;
  for(const x of positions){const f=fractionOf(x,most);if(!f)return null;G=G/gcd(G,f[1])*f[1];if(G>most)return null}
  return G;
}
