// A solo's margin shared between its soloist and the band (Astra's EC19, CFM-031 burden-sharing.js): a soloist stands
// out by a margin of level over the sections under it (plex_clodbot.js PLEX_CLODBOT.solo: its raise and the others'
// recession, the attention it is given and their lighter playing, docs/ATTENTION.md), and how much of that margin the soloist
// makes by rising and how much the others give by receding is shared over the piece: a section that has already given
// much -- receded under many solos, or risen through many of its own -- gives less this time, the others more. The
// margin is the raise and the recession together; each participant's entitlement is its role's share of them (the
// soloist's the raise's, the others' the recession's), so that where none has given before the split is the authored
// one exactly; each one's burden its level moved, normalised alike, its history its own movements so far in the piece.
// The split minimises the largest of (history + this solo's movement) / entitlement, every movement within the margin,
// solved exactly and played as solved (its certificate -- its allocation and the dual bound that proves it least --
// checked in development: checkBurdenSharing). -> {raise, recede (level shares), peak, modelHash}, or null where it has
// no optimum (its sections then as their own PLEX_CLODBOT.solo has it).
import {prepareBurdenSharing,solveBurdenSharing} from './burden-sharing.js';
import {pythonJson,sha256} from '../bounded-exact.js';

// (A level share as exact text: its decimals, as written.)
const exact=x=>{const scale=1000000,n=Math.round(Number(x)*scale);const g=(a,b)=>{a=Math.abs(a);while(b){[a,b]=[b,a%b]}return a},d=g(n,scale)||1;return `${n/d}/${scale/d}`};
const valueOf=text=>{const [n,d='1']=String(text).split('/');return Number(n)/Number(d)};
// `soloist`: its section; `others`: the sections under it; `raise`, `recede`: the authored split (level shares);
// `history`: Map section -> {raised: [share], receded: [share]}, every solo so far in the piece.
export function soloShares({soloist,others,raise,recede,history=new Map}){
  const margin=raise+recede;if(!(margin>0)||!others.length)return null;
  const entry=(id,burden)=>({id,revision:1,burden:exact(burden),reference:{id:`solo:${id}`,revision:1,hash:sha256(pythonJson([id,exact(burden)]))}});
  const past=(group,kind)=>(history.get(group)?.[kind]??[]).map((burden,k)=>entry(`${group}:${kind}:${k}`,burden));
  const metric=(id,group,role,coefficients,entitlement,entries)=>({id,playerId:group,roleId:role,dimension:'level',unit:'level-share',
    residual:{offset:'0',coefficients},freeBand:{minus:'0',plus:'0'},outerCap:{minus:'0',plus:exact(margin)},normalizer:{minus:'1',plus:'1'},
    entitlement:exact(entitlement),history:{id:`${id}:history`,revision:1,complete:true,entries}});
  const spec={id:'solo-margin',revision:1,
    variables:[{id:'raise',unit:'level-share',lo:'0',hi:exact(margin)},{id:'recede',unit:'level-share',lo:'0',hi:exact(margin)}],
    relations:[{id:'margin',coefficients:['1','1'],sense:'eq',rhs:exact(margin)}],
    metrics:[metric(`${soloist}:raise`,soloist,'soloist',['1','0'],raise/margin,past(soloist,'raised')),
      ...others.map(group=>metric(`${group}:recede`,group,'under-solo',['0','1'],recede/margin,past(group,'receded')))],
    policy:{id:'solo-margin-shared',revision:1,type:'minimax-normalized-burden'},bindings:{soloist,others:[...others]},dependencies:[]};
  let prepared;try{const ready=prepareBurdenSharing(spec);if(ready.status!=='PASS')return null;prepared=ready.prepared}catch{return null}
  let solved;try{solved=solveBurdenSharing(prepared)}catch{return null}
  if(solved.status!=='OPTIMAL'||!solved.certificate)return null;
  const values=Object.fromEntries(solved.certificate.values.map(row=>[row.id,valueOf(row.value)]));
  return {raise:+values.raise.toFixed(6),recede:+values.recede.toFixed(6),peak:valueOf(solved.certificate.peak),modelHash:prepared.modelHash??null};
}
// The history after a solo shared so: the soloist's raise and each other section's recession added to its own.
export function sharedHistory(history,{soloist,others,raise,recede}){
  const add=(group,kind,value)=>{const own=history.get(group)??{raised:[],receded:[]};history.set(group,{...own,[kind]:[...own[kind],value]})};
  add(soloist,'raised',raise);for(const group of others)add(group,'receded',recede);return history;
}
