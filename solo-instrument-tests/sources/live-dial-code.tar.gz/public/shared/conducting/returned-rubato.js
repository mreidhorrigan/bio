// A phrase's rubato that gives back the time it takes, and the time the band owes the form (Astra's EC06/EC16, CFM-022
// coherent-deformation.js, and their review of its first adoption: RC1-RC4/P240, returned-clock-prefix.js). A
// conductor's phrase arch (plex_clodbot.js shapePhrases) rises to its peak and lengthens into its end; where a part
// keeps the form's clock -- a tape, its sounds placed in the form's seconds -- every curve the conductor sends moves the
// band against that clock: its arches, and its sections' changes of tempo too. So the conductor keeps the clock it has
// actually sent (SentClock: every curve as sent, rounded as sent, realised as the clocks realise it, pulse by pulse:
// tempo-curve.js curveTempo) against the form's, and each arch's rise is the one that brings the band back to the form's
// clock at the phrase's end, whatever it owed at the phrase's start (the phrase's length falls as the rise grows: one
// rise does, where one within the most an arch moves its tempo can; else the nearest, said so). The arch as it will be
// sent, its targets rounded as they will be, is checked in development (certifyReturned), never while it plays: its
// deformation of the form's clock decomposed against that reference (a phrase-wide shift and its remainder) and the
// complete prefix audited (Astra's returned-clock-prefix.js), the offset at its end no further from the form's clock
// than at its start or than a pulse, whichever is more -- an arch never adds to what the band owes.
import {curveTempo} from '../tempo-curve.js';
import {prepareCoherentReference,decomposeCoherentResidual,checkCoherentDeformation} from './coherent-deformation.js';
import {auditReturnedClockPrefix} from './returned-clock-prefix.js';
import {exactOfNumber,exactText,pythonJson,sha256} from '../bounded-exact.js';

const exact=x=>exactText(exactOfNumber(x));
// A tempo as the conductor sends it (its curves' targets at two decimals).
export const sentBpm=bpm=>+Number(bpm).toFixed(2);

// The clock a conductor has sent: its curves, in the order sent, each at its bar ({targetBpm, durationBars, shape}),
// realised against the form's own clock over its sections (`units` [{startBar, endBar, bpm (its tempo), barSeconds (a
// bar at it), pulses (a bar's)}]): each bar's pulses at the tempo of their start along the curve then moving (from the
// tempo the clock has where it begins), a pulse at tempo t lasting the form's pulse times its tempo over t.
export class SentClock {
  constructor({startBpm=null}={}){this.startBpm=startBpm;this.curves=[]}
  send(curve,bar){
    const target=Number(curve?.targetBpm),at=Math.max(0,Math.floor(Number(bar)||0));if(!(target>0))return;
    this.startBpm??=target;this.curves.push({bar:at,targetBpm:target,durationBars:Math.max(0,Math.round(Number(curve.durationBars)||0)),shape:curve.shape??'linear'});
  }
  // From bar 0 to `toBar`, with `extra` curves as though sent after these. -> {actual, reference: [s at each bar line],
  // tempo: the clock's at `toBar`, complete: whether every bar lay in a section}.
  realize(units,toBar,extra=[]){
    const curves=[...this.curves,...extra],actual=[0],reference=[0];let tempo=this.startBpm??units[0]?.bpm,active=null,complete=true;
    const now=bar=>active?curveTempo(active,(bar-active.from)/active.bars):tempo;
    for(let bar=0;bar<toBar;bar++){
      for(const curve of curves.filter(item=>item.bar===bar)){const begin=now(bar);
        if(curve.durationBars>0)active={startBpm:begin,targetBpm:curve.targetBpm,shape:curve.shape,from:bar,bars:curve.durationBars};else{tempo=curve.targetBpm;active=null}}
      const unit=units.find(item=>item.startBar<=bar&&bar<item.endBar);if(!unit){complete=false;actual.push(actual.at(-1));reference.push(reference.at(-1));continue}
      const pulse=unit.barSeconds/unit.pulses;let seconds=0;
      for(let p=0;p<unit.pulses;p++){const t=active?curveTempo(active,(bar-active.from+p/unit.pulses)/active.bars):tempo;seconds+=pulse*unit.bpm/t}
      if(active&&bar+1>=active.from+active.bars){tempo=active.targetBpm;active=null}
      actual.push(actual.at(-1)+seconds);reference.push(reference.at(-1)+unit.barSeconds);
    }
    return {actual,reference,tempo:now(toBar),complete};
  }
  // The band's offset from the form's clock at `bar` (s: actual less reference, behind positive).
  offsetAt(units,bar){const {actual,reference}=this.realize(units,bar);return actual[bar]-reference[bar]}
}

// An arch's two curves as they will be sent: its rise from `from` to its peak at `peak`, its lengthening to `end`.
const archCurves=({from,peak,end,peakBpm,endBpm})=>[{bar:from,targetBpm:sentBpm(peakBpm),durationBars:peak-from,shape:'linear'},{bar:peak,targetBpm:sentBpm(endBpm),durationBars:end-peak,shape:'linear'}];
// The rise (its peak's tempo over `bpm`, less 1, from 0 to `most`) that brings the clock sent so far (`clock`) and
// this arch back to the form's clock at `end`: its peak at `peak`, its lengthening to `endBpm`. -> {rise, exact (whether
// one returns the time; else the nearest within its range)}.
export function returningRise({clock,units,from,peak,end,bpm,endBpm,most}){
  // (Unrounded while it searches: the rise's own law; its curves rounded only as they are sent, and checked so.)
  const exactly=rise=>{const curves=[{bar:from,targetBpm:bpm*(1+rise),durationBars:peak-from,shape:'linear'},{bar:peak,targetBpm:endBpm,durationBars:end-peak,shape:'linear'}];
    const {actual,reference}=clock.realize(units,end,curves);return actual[end]-reference[end]};
  if(!(most>=0))return null;
  const low=exactly(0),high=exactly(most);
  // (The offset at its end falls as the rise grows: where even none leaves the band ahead, none; where even the most
  // leaves it behind, the most -- each the nearest, not a return.)
  if(low<=0)return {rise:0,exact:low===0};
  if(high>=0)return {rise:most,exact:high===0};
  let a=0,b=most;for(let i=0;i<200&&b-a>1e-15*Math.max(1,b);i++){const mid=(a+b)/2;if(exactly(mid)>0)a=mid;else b=mid}
  return {rise:b,exact:true};
}
// The arch as it will be sent, checked from the offset its phrase begins with (above). -> {status ('PASS', 'FAIL',
// 'UNKNOWN'), start, end (s: the band's offset from the form's clock at the phrase's start and end), cap, shift (s: its
// mean offset over the phrase), peak (s: its largest), modelHash, reason}.
export function certifyReturned({clock,units,from,peak,end,peakBpm,endBpm,pulseSeconds}){
  const sent=archCurves({from,peak,end,peakBpm,endBpm}),{actual,reference,complete}=clock.realize(units,end,sent);
  if(!complete)return {status:'UNKNOWN',reason:'a bar outside the form'};
  const start=actual[from]-reference[from],finish=actual[end]-reference[end],cap=Math.max(Math.abs(start),pulseSeconds);
  // (The complete prefix: everything sent before the phrase as its starting offset, the phrase one segment.)
  const prefix=auditReturnedClockPrefix({reference:{id:'form-clock',revision:1,hash:sha256(pythonJson(units.map(u=>[u.startBar,u.endBar,u.bpm,u.barSeconds,u.pulses])))},complete:true,
    initialOffset:exact(start),maxOffset:exact(cap),segments:[{id:`phrase:${from}`,referenceSeconds:exact(reference[end]-reference[from]),actualSeconds:exact(actual[end]-actual[from])}]});
  if(prefix.status!=='PASS')return {status:prefix.status,start,end:finish,cap,reason:prefix.reason??'its end further from the form\'s clock than it began'};
  // (Its deformation within the phrase, bar by bar, against the form's clock, its start the offset it began with.)
  const source={id:'phrase-bars',unit:'bar',revision:1},open={peak:null,absoluteExposure:null,squaredExposure:null,startOffset:null,endOffset:null};
  const knots=(values,base)=>values.slice(from,end+1).map((value,k)=>({at:k,value:exact(value-base)}));
  let spec;try{spec={id:'returned-rubato',revision:1,
    reference:prepareCoherentReference({id:'form-clock',revision:1,source,residualUnit:'s',window:[0,end-from],knots:knots(reference,reference[from])}),
    actual:{id:'sent-clock',revision:1,source,unit:'s',knots:knots(actual,actual[from]-start)},basis:[{id:'shift',unit:'1',knots:[{at:0,value:1},{at:end-from,value:1}]}],measure:{kind:'score'},
    caps:{total:{...open,endOffset:exact(cap)},coherent:open,remainder:open,components:[{id:'shift',caps:open}]}}}
  catch(error){return {status:'UNKNOWN',reason:String(error?.message??error)}}
  let out;try{out=decomposeCoherentResidual(spec)}catch(error){return {status:'UNKNOWN',reason:String(error?.message??error)}}
  if(!out.certificate)return {status:'UNKNOWN',reason:out.reason??null};
  let checked;try{checked=checkCoherentDeformation(spec,out.certificate)}catch(error){return {status:'UNKNOWN',reason:String(error?.message??error)}}
  if(checked.status!=='PASS'||checked.conclusion!==out.status)return {status:'UNKNOWN',reason:`its certificate: ${checked.status}${checked.reason?` (${checked.reason})`:''}`};
  const value=text=>{const [n,d='1']=String(text).split('/');return Number(n)/Number(d)},total=out.report.records.find(row=>row.id==='total').summary;
  return {status:out.status,start,end:finish,cap,shift:value(out.report.coefficients[0].value),peak:value(total.peak),modelHash:out.modelHash??null};
}
