// Where an orchestra's players sit, and so where a listener hears each (the owner, 1 October 2026: "We will also need a
// stereo image that actually places the players as per a real orchestra"). A section's seats on the stage by a seating
// plan -- each section a sector of the arc round the conductor, its desks in rows going back, two players a desk, the
// outside player nearer the audience's edge -- and each seat as a main microphone pair in front of the podium hears it:
// its pan from the angle it is at, its sound arriving later the further it sits, and the hall round it all (the owner, 1
// October 2026: "there might be reverb necessary, too, to simulate position further or close to listening point";
// "virtual seating info can then be fed to mixbot to inform reverb"): a seat's distance heard in its arrival and in how
// much of it the hall carries against its direct sound, as at that distance -- never in its own level (the owner, 10
// October 2026: "The default mixing situation for orchestra should be not to intervene in the instruments' gain, as
// doing so interferes both with dynamics and with sense of space"; "distance might be rather accomplished by precise
// delay and reverb"; its high frequencies lost "in the reverb line, not as though the air were absorbing huge amounts of
// high frequency energy" -- the hall's own decay, never a filter on its direct sound). Its direct sound at its player's
// own level wherever it sits, its send to the hall growing with its distance (seatImage), the hall's return as far up as
// keeps every seat's hall against its direct sound as the hall would have it (hallReturn).
//
// **Measured or physical:** sound's speed (343 m/s in air at 20 °C); the direct sound's fall with distance (the inverse
// square law) against the hall's reverberant field, which does not fall (the distance where they are equal, the critical
// distance, is the hall's) -- kept as their ratio, the direct sound left at its level; the send at which the mixer's hall
// returns a seat's direct energy (HALL, measured).
// **Authored**, each naming what should replace it: the plans' sectors and the stage's dimensions (desks 1.3 m apart in
// depth, 1.4 m a desk wide, the first row 2 m from the podium: an orchestra's stage plan would replace them); the main
// pair 3 m in front of the podium, its recording angle ±48° (an ORTF pair's, as M. Williams's curves give it: a pair's
// own would replace it); the hall's volume and reverberation time (HALL: a measured hall's would), its critical distance
// following from them.
// The plans: the American (Stokowski's: violins on the left, violas and cellos on the right, the basses behind the
// cellos, at the back) and the European or antiphonal (first violins left, seconds right, cellos and violas between,
// the basses behind the cellos, at the back). Behind the strings, in both, the woodwinds in two rows at the middle
// (flutes and oboes, then clarinets and bassoons), the horns to the left behind them, trumpets in the middle and
// trombones and tuba to the right at the back, and the timpani and percussion behind all, the battery at the left and the
// mallets at the right of the timpani (an orchestra's usual stage; authored, its sectors and rows to be replaced by a
// stage plan's); the harp at the left by the first violins' outer desks, a keyboard at the right; a soloist at the front
// by the podium; and a tape's loudspeakers at the stage's front corners, in the hall as its players are (the owner, 2
// October 2026, of Op. 3.17: "I'm not sure all the percussion instruments are being placed in the mix as per their
// spatial position in the orchestra; am hearing some quite forward and reverb-less occasional percussion instruments" --
// the tape's recorded strokes and the piano, placed nowhere, had sounded dry at the front).
import {REVERB_TYPES} from '../../reverb-design.js';
import {FX_DEFAULTS} from '../sound-settings.js';

const BEHIND=Object.freeze({fl:Object.freeze({from:-16,to:-2,row:5}),ob:Object.freeze({from:2,to:16,row:5}),cl:Object.freeze({from:-16,to:-2,row:6}),bn:Object.freeze({from:2,to:16,row:6}),
  hn:Object.freeze({from:-44,to:-20,row:6}),tp:Object.freeze({from:-12,to:12,row:7}),tb:Object.freeze({from:16,to:36,row:7}),tu:Object.freeze({from:37,to:44,row:7}),
  timp:Object.freeze({from:-6,to:6,row:8}),bat:Object.freeze({from:-30,to:-8,row:8}),perc:Object.freeze({from:8,to:30,row:8}),harp:Object.freeze({from:-82,to:-74,row:3}),keys:Object.freeze({from:74,to:82,row:3}),
  solo:Object.freeze({from:-8,to:8,row:0}),speakers:Object.freeze({from:-70,to:70,row:0})});
// Where a player not seated in a section stands on such a stage, by its instrument (authored, an orchestra's usual: a
// stage plan would replace it); any other at the front, as a soloist.
export const STAGE_PLACES=Object.freeze({piano:'keys',harpsichord:'keys',organ:'keys',celesta:'keys',accordion:'keys',harp:'harp',timpani:'timp',drums:'bat',
  mallets:'perc','fixed media':'speakers'});
export const stagePlaceOf=instrument=>STAGE_PLACES[instrument]??'solo';
export const SEATING_PLANS=Object.freeze({
  // Each section: its sector (degrees from the conductor's axis, negative to the audience's left) and its first row.
  american:Object.freeze({vn1:Object.freeze({from:-88,to:-48,row:0}),vn2:Object.freeze({from:-46,to:-8,row:0}),va:Object.freeze({from:8,to:46,row:0}),
    vc:Object.freeze({from:48,to:88,row:0}),cb:Object.freeze({from:25,to:62,row:4}),...BEHIND}),
  european:Object.freeze({vn1:Object.freeze({from:-88,to:-48,row:0}),vc:Object.freeze({from:-46,to:-8,row:0}),va:Object.freeze({from:8,to:46,row:0}),
    vn2:Object.freeze({from:48,to:88,row:0}),cb:Object.freeze({from:-62,to:-25,row:4}),...BEHIND}),
});
// The hall a seated section plays in where its spec gives none (scripts/make-etude.mjs adds it as the spec's effects): a
// concert hall's reverberation (reverb-design.js 'hall'), its volume 15,400 m³ (authored, a mid-sized concert hall's)
// and its mid-frequency T60 1.4 s, its walls less reflective than a symphony hall's 2 s (the owner, 4 October 2026: "We
// could also reduce the overall reverberance of our simulated orchestral hall (don't need the edges of the hall to be so
// reflective)"); its critical distance from the two, Sabine's: 0.057 sqrt(V / T60) m (H. Kuttruff, Room Acoustics, 6th
// ed., CRC Press 2016, doi:10.1201/9781315372150), 6 m -- 5 m at 2 s -- so every seat sends the less to it; and the send at
// which the mixer's return of that hall carries as much energy as a seat's direct sound at fader 1 (measured: an impulse
// through each on the mixer -- 1.146, past a send's 1, so a seat nearer than the critical distance, as every seat is,
// sends its share of it; test/audio/hall-send.test.mjs measures it again).
// (The mix's own feedback through a live room (mix-feedback.js, the desk's, on by default) left out of it: the hall is its
// room, and the loop's build-up on what is held -- up to 3 dB at its resonances at its default amount, a short note never
// reaching it -- had raised a seated band's long notes over its short ones: the owner, 10 October 2026, "the mixing desk,
// or mixing otherwise, has been messing with the orchestral simulation with respect to dynamics".)
export const HALL=Object.freeze({volume:15400,effects:Object.freeze({reverbType:REVERB_TYPES.indexOf('hall'),reverbSeconds:1.4,mixFeedback:0}),equalSend:1.146});
export const STAGE=Object.freeze({firstRow:2,rowDepth:1.3,deskWidth:1.4,partner:.7,pairDistance:3,recordingAngle:48,
  criticalDistance:+(.057*Math.sqrt(HALL.volume/HALL.effects.reverbSeconds)).toFixed(3),speedOfSound:343});
const radians=degrees=>degrees*Math.PI/180;

// A seat's place on the stage (m, the conductor at the origin, y away from the audience, x to the audience's right).
// `seats`: the section's seats in order (string-section.js stringSeats: {id, section, desk?}); -> Map(seat id -> {x, y}).
export function seatPositions(seats,plan=SEATING_PLANS.american){
  const out=new Map,bySection=new Map;
  for(const seat of seats){const section=String(seat.id).split('.')[0];(bySection.get(section)??bySection.set(section,[]).get(section)).push(seat)}
  for(const [section,list] of bySection){
    const sector=plan[section];if(!sector)continue;
    // Desks in rows from the front: each row's arc holds as many desks as its length allows.
    let row=sector.row,index=0;
    const desks=Math.ceil(list.length/2);
    while(index<desks){
      const radius=STAGE.firstRow+row*STAGE.rowDepth,arc=radius*radians(sector.to-sector.from),fit=Math.max(1,Math.floor(arc/STAGE.deskWidth)),here=Math.min(fit,desks-index);
      for(let k=0;k<here;k++){
        // (The desk's middle along the row, the front desk at the sector's outer edge, nearest the audience's side.)
        const outer=Math.abs(sector.from)>Math.abs(sector.to)?sector.from:sector.to,inner=outer===sector.from?sector.to:sector.from;
        const angle=outer+(inner-outer)*(k+.5)/fit,centre={x:radius*Math.sin(radians(angle)),y:radius*Math.cos(radians(angle))};
        // (Its two players either side of it along the row: the outside one toward the sector's outer edge.)
        const along={x:Math.cos(radians(angle))*Math.sign(outer),y:-Math.sin(radians(angle))*Math.sign(outer)};
        for(const [offset,player] of [[1,list[2*(index+k)]],[-1,list[2*(index+k)+1]]])
          if(player)out.set(player.id,{x:+(centre.x+offset*along.x*STAGE.partner/2).toFixed(3),y:+(centre.y+offset*along.y*STAGE.partner/2).toFixed(3)});
      }
      index+=here;row++;
    }
  }
  return out;
}
// How the main pair hears each seat: {pan (-1 to 1), reverb (its send to the hall: its distance's share of `farthest`'s,
// whose send is 1 -- with the hall's return at hallReturn(farthest), the hall's field against its direct sound as at its
// distance, equal at the critical distance), arrival (s after the nearest), distance (m)}; its direct sound its player's
// own, wherever it sits. `reference`: the distance (m) arriving at 0 -- the nearest of `positions` unless given: the
// stage's own front desk (stageReference) where sections are seated apart, so that they are heard as one orchestra.
// `farthest`: the stage's farthest place (farthestOf), the furthest of `positions` unless given.
export function seatImage(positions,{reference=null,farthest=null}={}){
  const pair={x:0,y:-STAGE.pairDistance},out=new Map,heard=[];
  for(const [id,{x,y}] of positions){
    const dx=x-pair.x,dy=y-pair.y,distance=Math.hypot(dx,dy),azimuth=Math.atan2(dx,dy)*180/Math.PI;
    heard.push({id,distance,pan:Math.max(-1,Math.min(1,azimuth/STAGE.recordingAngle))});
  }
  const nearest=reference??Math.min(...heard.map(seat=>seat.distance)),far=Math.max(farthest??0,...heard.map(seat=>seat.distance));
  for(const seat of heard)out.set(seat.id,{pan:+seat.pan.toFixed(3),reverb:+Math.min(1,seat.distance/far).toFixed(4),arrival:+((seat.distance-nearest)/STAGE.speedOfSound).toFixed(4),distance:+seat.distance.toFixed(3)});
  return out;
}
// A plan's farthest place from the main pair (m): its deepest row's ends, every sector's (the timpani's and percussion's
// row on both plans).
export function farthestOf(plan){
  const pair={x:0,y:-STAGE.pairDistance};let far=0;
  for(const sector of Object.values(plan))for(const angle of [sector.from,sector.to]){
    const radius=STAGE.firstRow+sector.row*STAGE.rowDepth;far=Math.max(far,Math.hypot(radius*Math.sin(radians(angle))-pair.x,radius*Math.cos(radians(angle))-pair.y))}
  return far;
}
// The hall's return (the mixer's reverbReturn) at which a seat sending its distance's share of `farthest`'s hears the hall
// against its direct sound as the hall would: its field as loud as the direct sound at the critical distance. The hall's
// equal send (HALL.equalSend) was measured at the mixer's default return; its return raised in proportion.
export const hallReturn=(farthest,{equalSend=HALL.equalSend}={})=>+(FX_DEFAULTS.reverbReturn*equalSend*farthest/STAGE.criticalDistance).toFixed(4);
// The stage's nearest seat to the main pair (m): a full string section's front desks on `plan`, the reference every
// section's seats are heard against (seatImage), however many of them a spec seats.
export function stageReference(plan,frontSeats){
  const pair={x:0,y:-STAGE.pairDistance};
  return Math.min(...[...seatPositions(frontSeats,plan).values()].map(({x,y})=>Math.hypot(x-pair.x,y-pair.y)));
}
// A single player's place (the harp, the timpani, a percussionist, a keyboard: a sector of the plan), heard as a seat is.
// -> {pan, reverb, arrival, distance}, or null where the plan has no such place.
export function placeImage(place,plan,{reference,index=0,of=1,farthest=farthestOf(plan)}={}){
  const sector=plan[place];if(!sector)return null;
  const radius=STAGE.firstRow+sector.row*STAGE.rowDepth,angle=sector.from+(sector.to-sector.from)*(index+.5)/of;
  const position=new Map([[place,{x:radius*Math.sin(radians(angle)),y:radius*Math.cos(radians(angle))}]]);
  return seatImage(position,{reference,farthest}).get(place);
}
