// CFM036 / CF16: whole-profile approved-source combinations with exact symbolic co-presence.
// A listener's recognition and physical audibility are separate claims.
import {prepareDispositionFamily,auditDispositionFamily,checkDispositionFamily} from './counterpoint-dispositions.js';
import {dataArray,dataRecord} from './contract-data.js';
import {Refused,EXACT_LIMITS,ZERO,add,sub,compare,exactOf,exactText,pythonJson,sha256} from '../bounded-exact.js';

export const SUBJECT_COMBINATION_LIMITS=Object.freeze({maxSubjects:32,maxCombinations:32,maxParticipants:16,maxFamilyWork:500000,
  maxProfileWork:2000000,maxSliceWork:500000,maxWork:20000000,maxDataNodes:262144,maxTextChars:8388608,maxCertificateChars:2097152});
const freeze=Object.freeze,models=new WeakMap,scope='complete-declared-symbolic-subject-combinations';
const fail=(message,kind='invalid-input')=>{throw new Refused(message,{kind})};
class BadCertificate extends Error {}
const demand=(condition,message)=>{if(!condition)throw new BadCertificate(message)};
function stateOf(options){
  if(!dataRecord(options)||Object.keys(options).some(k=>!Object.hasOwn(SUBJECT_COMBINATION_LIMITS,k)))fail('Unknown combination options');
  const defaults={maxWork:1000000,maxProfileWork:20000,maxSliceWork:10000},limits={};
  for(const [k,cap] of Object.entries(SUBJECT_COMBINATION_LIMITS)){
    const n=Object.hasOwn(options,k)?options[k]:defaults[k]??cap;
    if(!Number.isSafeInteger(n)||n<0||n>cap)fail('Bounded nonnegative integer allowances required');limits[k]=n;
  }
  const s={limits:freeze(limits),used:0,nodes:0,chars:0,modelHash:null};
  s.charge=(n=1)=>{if(!Number.isSafeInteger(n)||n<0)throw new Error('Invalid work charge');
    if(n>limits.maxWork-s.used)fail('Combination work allowance exhausted','work-budget');s.used+=n};
  s.visit=(n=1)=>{s.charge(n);if(n>limits.maxDataNodes-s.nodes)fail('Combination data/output allowance','shape-budget');s.nodes+=n};
  s.m={};for(const [k,fn] of Object.entries({add,sub,cmp:compare}))s.m[k]=(a,b)=>{s.charge();return fn(a,b)};
  s.charge();return s;
}
function fields(v,keys,s){s.visit(keys.length+1);if(!dataRecord(v)||Object.keys(v).length!==keys.length||keys.some(k=>!Object.hasOwn(v,k)))fail('Missing or unsupported combination fields');return v}
function list(v,cap,s,label){if(!Array.isArray(v)||v.length>cap)fail(label+' allowance','shape-budget');s.visit(v.length+1);return dataArray(v,cap,label)}
function text(v,s,cap=256){if(typeof v!=='string'||!v.length||v.length>cap)fail('Bounded nonempty text required');
  if(v.length>s.limits.maxTextChars-s.chars)fail('Combination text allowance','work-budget');s.chars+=v.length;s.charge(1+Math.ceil(v.length/64));return v}
function revision(v){if(!Number.isSafeInteger(v)||v<0)fail('Nonnegative safe revision required');return v}
function unique(seen,id){if(seen.has(id))fail('Duplicate combination identity');seen.add(id);return id}
function sorted(a,s,key=x=>x){return a.sort((x,y)=>{s.charge();const u=key(x),v=key(y);return u<v?-1:u>v?1:0})}
function ids(raw,cap,s,label){const out=[],seen=new Set;for(const id of list(raw,cap,s,label))out.push(unique(seen,text(id,s)));return freeze(sorted(out,s))}
function rational(v,s,bits=EXACT_LIMITS.inputBits){
  s.charge();let n,d=1n;const bound=1n<<BigInt(bits),integer=x=>{const q=typeof x==='bigint'?x:Number.isSafeInteger(x)?BigInt(x):null;
    if(q===null||q<=-bound||q>=bound)fail('Raw rational component allowance','arithmetic-budget');return q};
  if(typeof v==='string'){text(v,s,bits===EXACT_LIMITS.inputBits?160:6000);const m=v.match(/^([+-]?[0-9]+)(?:\/([+-]?[0-9]+))?$/);
    if(!m||m[0].length!==v.length)fail('Use exact integer or fraction text');n=integer(BigInt(m[1]));d=integer(BigInt(m[2]??'1'));
  }else if(v&&typeof v==='object'){fields(v,['n','d'],s);n=integer(v.n);d=integer(v.d)}else n=integer(v);
  if(!d)fail('Zero denominator');return exactOf({n,d},{bits});
}
function clock(v,s){fields(v,['id','unit','revision'],s);return freeze({id:text(v.id,s),unit:text(v.unit,s),revision:revision(v.revision)})}
function encode(v,s,cap=s.limits.maxTextChars){const out=pythonJson(v);if(out.length>cap)fail('Canonical combination text allowance','work-budget');s.charge(1+Math.ceil(out.length/64));return out}
function wire(v,s){s.visit();if(typeof v==='string')return text(v,s,6000);
  if(v&&typeof v==='object'){
    if(typeof v.n==='bigint'&&typeof v.d==='bigint')return text(exactText(v),s,6000);
    if(Array.isArray(v))return freeze(v.map(x=>wire(x,s)));
    return freeze(Object.fromEntries(Object.entries(v).map(([k,x])=>[text(k,s),wire(x,s)])));
  }return v;
}
function snapshot(v,s,depth=0,seen=new Set){
  s.visit();if(v===null||typeof v==='boolean')return v;
  if(typeof v==='string')return text(v,s,6000);
  if(typeof v==='number'&&Number.isFinite(v))return Object.is(v,-0)?0:v;
  if(!v||typeof v!=='object'||depth>=32||seen.has(v))fail('Certificate must be bounded acyclic ordinary data');seen.add(v);let out;
  if(Array.isArray(v)){list(v,s.limits.maxDataNodes,s,'Certificate array');out=v.map(x=>snapshot(x,s,depth+1,seen))}
  else{if(!dataRecord(v)||Object.keys(v).length>256)fail('Certificate data record required');out=Object.fromEntries(Object.entries(v).map(([k,x])=>[text(k,s),snapshot(x,s,depth+1,seen)]))}
  seen.delete(v);return freeze(out);
}
function familyCall(m,s,mode,raw){
  const allowance=Math.min(s.limits.maxFamilyWork,s.limits.maxWork-s.used);if(!allowance)fail('No disposition-family allowance remains','work-budget');
  const options={maxWork:allowance,maxProfileWork:s.limits.maxProfileWork,maxSliceWork:s.limits.maxSliceWork};let out;
  if(mode==='prepare')out=prepareDispositionFamily(raw,{maxWork:allowance});
  else if(mode==='audit')out=auditDispositionFamily(m.family,options);
  else out=checkDispositionFamily(m.family,raw,options);
  s.charge(Number.isSafeInteger(out.workUsed)?out.workUsed:allowance);return out;
}
function normalize(raw,s){
  fields(raw,['id','revision','family','subjects','expected','bindings'],s);
  const family=familyCall(null,s,'prepare',raw.family);if(family.status!=='PASS')fail('Disposition preparation: '+family.reason,family.kind??'unknown-evidence');
  const fd=family.prepared.definition,sourceIds=new Set(fd.sources.map(x=>x.id)),memberIds=new Set(fd.expected.members.map(x=>x.id));
  const subjects=[],subjectById=new Map,sourceOwner=new Map;
  for(const row of list(raw.subjects,s.limits.maxSubjects,s,'Subject registry')){
    fields(row,['id','revision','sourceIds'],s);const id=text(row.id,s),sources=ids(row.sourceIds,32,s,'Approved variants');
    if(subjectById.has(id)||!sources.length)fail('Unique subjects need nonempty approved source variants');
    for(const source of sources){s.charge();if(!sourceIds.has(source)||sourceOwner.has(source))fail('Every variant must have one declared subject owner');sourceOwner.set(source,id)}
    const subject=freeze({id,revision:revision(row.revision),sourceIds:sources});subjects.push(subject);subjectById.set(id,subject);
  }
  if(!subjects.length)fail('A nonempty subject registry is required');sorted(subjects,s,x=>x.id);
  const e=fields(raw.expected,['id','revision','complete','combinations'],s);if(typeof e.complete!=='boolean')fail('Declare promise-inventory completeness');
  const promises=[],promiseIds=new Set;
  for(const p of list(e.combinations,s.limits.maxCombinations,s,'Promised combinations')){
    fields(p,['id','revision','memberId','subjects','clockDomain','from','to','minCommonDuration','minContiguousDuration'],s);
    const id=unique(promiseIds,text(p.id,s)),memberId=text(p.memberId,s),names=ids(p.subjects,s.limits.maxParticipants,s,'Promised subjects');
    if(!memberIds.has(memberId)||!names.length||names.some(id=>!subjectById.has(id)))fail('Promise requires a known family member and nonempty registered subjects');
    const from=rational(p.from,s),to=rational(p.to,s),minCommonDuration=rational(p.minCommonDuration,s),minContiguousDuration=rational(p.minContiguousDuration,s);
    if(from.n<0n||s.m.cmp(from,to)>=0||minCommonDuration.n<=0n||minContiguousDuration.n<0n)fail('Positive window/common duration and nonnegative contiguous duration required');
    promises.push(freeze({id,revision:revision(p.revision),memberId,subjects:names,clockDomain:clock(p.clockDomain,s),from,to,minCommonDuration,minContiguousDuration}));
  }
  if(!promises.length)fail('Promise at least one combination');sorted(promises,s,x=>x.id);
  const expected=freeze({id:text(e.id,s),revision:revision(e.revision),complete:e.complete,combinations:freeze(promises)}),bindings=[],bindingById=new Map;
  for(const b of list(raw.bindings,s.limits.maxCombinations,s,'Actual bindings')){
    fields(b,['id','revision','memberId','participants'],s);const id=text(b.id,s),participants=[],names=new Set,parts=new Set;
    if(bindingById.has(id))fail('Duplicate combination binding');
    for(const p of list(b.participants,s.limits.maxParticipants,s,'Bound participants')){fields(p,['subjectId','partId'],s);
      participants.push(freeze({subjectId:unique(names,text(p.subjectId,s)),partId:unique(parts,text(p.partId,s))}));}
    sorted(participants,s,x=>x.subjectId);const binding=freeze({id,revision:revision(b.revision),memberId:text(b.memberId,s),participants:freeze(participants)});bindings.push(binding);bindingById.set(id,binding);
  }sorted(bindings,s,x=>x.id);
  const definition=wire({id:text(raw.id,s),revision:revision(raw.revision),familyHash:family.prepared.hash,subjects,expected,bindings},s);
  const hash=sha256(encode(definition,s));return {definition,hash,family:family.prepared,subjects,subjectById,expected,bindings,bindingById,
    memberById:new Map(fd.members.map(x=>[x.id,x]))};
}
function result(s,status,reason,extra={}){return freeze({status,reason,scope,modelHash:s?.modelHash??null,workUsed:s?.used??0,resourceLimits:s?.limits??null,...extra})}
function refused(e,s){return result(s,e instanceof BadCertificate?'FAIL':'UNKNOWN',e.message??'Combination refused',
  {kind:e instanceof Refused?e.kind:e instanceof BadCertificate?'invalid-certificate':'internal-error',certificate:null})}
function modelOf(prepared,s){const m=models.get(prepared);if(!m)fail('Use an authentic prepared combination model');s.modelHash=m.hash;
  if(m.subjects.length>s.limits.maxSubjects||m.expected.combinations.length>s.limits.maxCombinations||m.bindings.length>s.limits.maxCombinations||m.expected.combinations.some(p=>p.subjects.length>s.limits.maxParticipants))fail('Prepared model exceeds current allowances','shape-budget');return m}
export function prepareSubjectCombinations(spec,options={}){let s;try{
  s=stateOf(options);const m=normalize(spec,s);s.modelHash=m.hash;const prepared=freeze({kind:'subject-combinations-model-v1',hash:m.hash,definition:m.definition});models.set(prepared,m);
  return result(s,'PASS','Original family and independent combination promises prepared',{prepared});
}catch(e){return refused(e,s)}}
function append(out,lo,hi,s){if(s.m.cmp(lo,hi)>=0)return;const last=out.at(-1);
  if(last&&s.m.cmp(lo,last[1])<=0){if(s.m.cmp(hi,last[1])>0)last[1]=hi}else out.push([lo,hi]);}
function union(intervals,s){const a=[...intervals];a.sort((x,y)=>s.m.cmp(x[0],y[0])||s.m.cmp(x[1],y[1]));const out=[];for(const [lo,hi] of a){s.charge();append(out,lo,hi,s)}return out}
function intersect(left,right,s){const out=[];let i=0,j=0;while(i<left.length&&j<right.length){s.charge();const a=left[i],b=right[j];
  append(out,s.m.cmp(a[0],b[0])>0?a[0]:b[0],s.m.cmp(a[1],b[1])<0?a[1]:b[1],s);const c=s.m.cmp(a[1],b[1]);if(c<=0)i++;if(c>=0)j++;}return out}
function producerCommon(intervals,s){let out=union(intervals[0],s);for(let i=1;i<intervals.length;i++)out=intersect(out,union(intervals[i],s),s);return out}
function sweptCommon(intervals,s){
  const endpoints=[];for(let i=0;i<intervals.length;i++)for(const [lo,hi] of intervals[i]){s.visit(2);endpoints.push({at:lo,subject:i,delta:1},{at:hi,subject:i,delta:-1})}
  endpoints.sort((a,b)=>s.m.cmp(a.at,b.at));const counts=intervals.map(()=>0),out=[];let i=0;
  while(i<endpoints.length){const time=endpoints[i].at;do{const e=endpoints[i++];s.charge();counts[e.subject]+=e.delta}while(i<endpoints.length&&s.m.cmp(endpoints[i].at,time)===0);
    if(i<endpoints.length&&counts.every(n=>{s.charge();return n>0}))append(out,time,endpoints[i].at,s);
  }return out;
}
function evaluate(p,m,evidence,s,replay){
  const b=m.bindingById.get(p.id),member=m.memberById.get(p.memberId),out=(status,reason)=>freeze({id:p.id,status,reason});
  if(!b||b.revision!==p.revision||b.memberId!==p.memberId)return out('UNKNOWN','Missing or stale promised binding');
  if(b.participants.length!==p.subjects.length||b.participants.some((x,i)=>x.subjectId!==p.subjects[i]))return out('UNKNOWN','Bound subjects differ from the independent promise');
  if(!member||!evidence||evidence.status!=='PASS'||!evidence.evidence)return out(evidence?.status==='FAIL'?'FAIL':'UNKNOWN','The complete member is not certified');
  if(encode(p.clockDomain,s)!==encode(member.profile.clockDomain,s))return out('UNKNOWN','Promise and whole-member clock differ');
  const partById=new Map(member.parts.map(part=>[part.id,part])),groups=[],participants=[];
  for(const entry of b.participants){s.charge();const part=partById.get(entry.partId);if(!part)return out('UNKNOWN','Named subject occurrence is missing');
    if(!m.subjectById.get(entry.subjectId).sourceIds.includes(part.sourceId))return out('FAIL','Named occurrence uses a source outside the approved subject variants');
    participants.push({subjectId:entry.subjectId,partId:part.id,sourceId:part.sourceId,sourceHash:part.sourceHash});groups.push([]);
  }
  const groupByPart=new Map(b.participants.map((entry,i)=>[entry.partId,i]));
  for(const event of evidence.evidence.events){s.charge();if(event.pitch===null||event.origin.kind!=='part')continue;const i=groupByPart.get(event.origin.partId);if(i===undefined)continue;
    const start=rational(event.t,s,8192),end=s.m.add(start,rational(event.d,s,8192)),lo=s.m.cmp(start,p.from)>0?start:p.from,hi=s.m.cmp(end,p.to)<0?end:p.to;
    if(s.m.cmp(lo,hi)<0){s.visit();groups[i].push([lo,hi])}
  }
  const common=replay?sweptCommon(groups,s):producerCommon(groups,s);let total=ZERO,longest=ZERO;
  for(const [lo,hi] of common){const d=s.m.sub(hi,lo);total=s.m.add(total,d);if(s.m.cmp(d,longest)>0)longest=d}
  const status=s.m.cmp(total,p.minCommonDuration)>=0&&s.m.cmp(longest,p.minContiguousDuration)>=0?'PASS':'FAIL';
  const report=wire({id:p.id,revision:p.revision,memberId:p.memberId,clockDomain:p.clockDomain,from:p.from,to:p.to,
    minCommonDuration:p.minCommonDuration,minContiguousDuration:p.minContiguousDuration,participants,
    commonIntervals:common,totalDuration:total,longestContiguousDuration:longest},s);
  return freeze({id:p.id,status,reason:status==='PASS'?'Named approved sources meet the common-sounding promise':'The full named combination lacks its promised common sounding duration',report});
}
function reports(m,family,s,replay){s.charge(family.results?.length??0);const byId=new Map((family.results??[]).map(r=>[r.id,r]));
  return freeze(m.expected.combinations.map(p=>{s.charge();return evaluate(p,m,byId.get(p.memberId),s,replay)}));}
function aggregate(m,family,results){if(family.status==='FAIL'||results.some(r=>r.status==='FAIL'))return 'FAIL';
  if(family.status!=='PASS'||!m.expected.complete||m.bindings.length!==m.expected.combinations.length||results.some(r=>r.status!=='PASS'))return 'UNKNOWN';return 'PASS';}
export function auditSubjectCombinations(prepared,options={}){let s;try{
  s=stateOf(options);const m=modelOf(prepared,s),family=familyCall(m,s,'audit'),results=reports(m,family,s,false),status=aggregate(m,family,results);let certificate=null;
  if(status==='PASS'){certificate=wire({kind:'subject-combinations-certificate-v1',modelHash:m.hash,family:family.certificate,combinations:results.map(r=>r.report)},s);encode(certificate,s,s.limits.maxCertificateChars)}
  return result(s,status,'Original whole-family audit and every independent combination promise',{familyStatus:family.status,results,certificate});
}catch(e){return refused(e,s)}}
export function checkSubjectCombinations(prepared,raw,options={}){let s;try{
  s=stateOf(options);const m=modelOf(prepared,s),c=snapshot(raw,s);fields(c,['kind','modelHash','family','combinations'],s);encode(c,s,s.limits.maxCertificateChars);
  demand(c.kind==='subject-combinations-certificate-v1'&&c.modelHash===m.hash,'Wrong combination model or certificate kind');
  const family=familyCall(m,s,'check',c.family);if(family.status!=='PASS')return result(s,family.status,'Original disposition-family replay did not pass',{familyStatus:family.status,certificate:null});
  const saved=new Map;for(const report of list(c.combinations,s.limits.maxCombinations,s,'Certified combinations')){
    if(!dataRecord(report))fail('Certified combination must be data');const id=text(report.id,s);demand(!saved.has(id),'Duplicate certified combination');saved.set(id,report);}
  demand(saved.size===m.expected.combinations.length,'Certified combination inventory differs');
  const results=reports(m,family,s,true),status=aggregate(m,family,results);
  if(status!=='PASS')return result(s,status,'Original promises did not all pass the independent sweep',{familyStatus:family.status,results,certificate:null});
  for(const r of results)demand(saved.has(r.id)&&encode(r.report,s)===encode(saved.get(r.id),s),'Recomputed common intervals, origins or promise differ');
  return result(s,'PASS','Whole original family replayed and every common interval independently swept',{familyStatus:'PASS',results,certificate:null});
}catch(e){return refused(e,s)}}
