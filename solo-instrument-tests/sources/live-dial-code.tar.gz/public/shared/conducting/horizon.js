// How far ahead a planner commits: its planning horizon, from a bar ahead through a phrase (where the Musebots have
// planned) and a section to the whole piece, and every step between (Musebots 3.0, docs/MUSEBOTS_3.md). The owner,
// 30 September 2026: "planning a phrase ahead is ok in many situations, but indeed, we want to extend the capabilities
// to planning arbitrarily X far ahead, not always just one phrase"; "We don't just want whole-piece form plan—we want
// support for planning every step of the way between phrase-ahead and whole-piece-ahead."
//
// A horizon is a commitment horizon. Within it a planner's decisions are made and said, and they bind the band: only a
// stimulus reopens them (piece-plan.js). Beyond it the planner keeps at most a sketch of its own, which it may redraw
// freely. The horizon is a separate thing from the lead with which a decision is carried out (a meter is handed to the
// transport a bar before it applies, a lifecycle request a phrase before): a piece planned whole is still carried out
// bar by bar.
//
// A horizon is written as:
//   'bar', 'phrase', 'section', 'piece'           one of the meter's and the form's levels
//   {bars: n}, {phrases: n}, {sections: n}         so many of them (any positive number: 2.5 phrases), or in words, as
//                                                   a render spec gives it: '8 bars', '2.5 phrases', '2 sections'
//   {seconds: s}, '30 seconds'                      so long, in the tempo planned
//   a number r from 0 to 1, or {reach: r}           the continuum between a phrase (0) and the whole piece (1), by
//                                                   ratio: the horizon is phraseBars^(1-r) x pieceBars^r bars, so each
//                                                   step of r multiplies it alike (a quarter of the way from a phrase
//                                                   of 4 to a piece of 256 bars is 11.3 bars; halfway, 32)
// A unit (a section) is committed once it begins within the horizon: at or before now + the horizon's bars, or, for
// sections, within so many sections of the one playing.
const LEVELS=Object.freeze({bar:{bars:1},phrase:{phrases:1},section:{sections:1},piece:{piece:true}});
export const HORIZON_LEVELS=Object.freeze(Object.keys(LEVELS));
const fail=message=>{throw new RangeError(message)};
const positive=value=>typeof value==='number'&&Number.isFinite(value)&&value>0;

// A horizon as written -> a frozen {kind: 'bars'|'phrases'|'sections'|'seconds'|'reach'|'piece', value}.
export function checkedHorizon(spec='phrase'){
  // (In words, as a render spec's settings give it: '8 bars', '2.5 phrases', '2 sections', '30 seconds'.)
  const counted=typeof spec==='string'?/^\s*(\d+(?:\.\d+)?)\s*(bar|phrase|section|second)s?\s*$/.exec(spec):null;
  if(counted)spec={[`${counted[2]}s`]:Number(counted[1])};
  if(typeof spec==='string'){
    if(!LEVELS[spec])fail(`A horizon is ${HORIZON_LEVELS.join(', ')}, a count of bars, phrases, sections or seconds, or a reach from 0 to 1`);
    spec=LEVELS[spec];
  }
  if(typeof spec==='number')spec={reach:spec};
  if(!spec||typeof spec!=='object')fail('A horizon is a level, a count, or a reach');
  // (A horizon already checked, as this gives it.)
  if(typeof spec.kind==='string')spec=spec.kind==='piece'?{piece:true}:{[spec.kind]:spec.value};
  if(spec.piece===true)return Object.freeze({kind:'piece',value:Infinity});
  if(spec.reach!==undefined){
    if(!(typeof spec.reach==='number'&&spec.reach>=0&&spec.reach<=1))fail('A horizon\'s reach is from 0 (a phrase) to 1 (the piece)');
    return spec.reach===1?Object.freeze({kind:'piece',value:Infinity}):Object.freeze({kind:'reach',value:spec.reach});
  }
  for(const kind of ['bars','phrases','sections','seconds'])if(spec[kind]!==undefined){
    if(!positive(spec[kind]))fail(`A horizon of ${kind} is a positive number of them`);
    return Object.freeze({kind,value:spec[kind]});
  }
  fail('A horizon is a level, a count, or a reach');
}
// A horizon in words, for a plan's rationale and a score's note.
export function describeHorizon(spec){
  const {kind,value}=checkedHorizon(spec);
  if(kind==='piece')return 'the whole piece';
  if(kind==='reach')return `${Math.round(value*100)}% of the way from a phrase to the whole piece`;
  const noun={bars:'bar',phrases:'phrase',sections:'section',seconds:'second'}[kind];
  return `${value} ${noun}${value===1?'':'s'}`;
}
// How many bars ahead a horizon reaches, where it is counted in bars: context {phraseBars (the phrase in force), barSeconds
// (the bar's length in the tempo planned), pieceBars (the whole piece's, as known or estimated)}. Infinity for the piece;
// null for a count of sections (which counts sections, not bars).
export function horizonBars(spec,{phraseBars=4,barSeconds=2,pieceBars=null}={}){
  const {kind,value}=checkedHorizon(spec);
  if(kind==='piece')return Infinity;
  if(kind==='sections')return null;
  if(kind==='bars')return value;
  if(kind==='phrases')return value*Math.max(1,phraseBars);
  if(kind==='seconds')return Math.max(1,Math.ceil(value/Math.max(1e-3,barSeconds)-1e-9));
  const phrase=Math.max(1,phraseBars),piece=Math.max(phrase,Number(pieceBars)||phrase);
  return phrase**(1-value)*piece**value;
}
// Whether a unit falls within the horizon: unit {index, startBar}; context {bar (now), current (the index of the unit
// playing, -1 before the first), phraseBars, barSeconds, pieceBars}.
export function withinHorizon(spec,unit,context={}){
  const {kind,value}=checkedHorizon(spec);
  if(kind==='piece')return true;
  if(kind==='sections')return unit.index<=(Number.isInteger(context.current)?context.current:-1)+Math.floor(value+1e-9);
  return unit.startBar<=(Number(context.bar)||0)+horizonBars(spec,context)+1e-9;
}
// ---- The continuum from improvisation to composition, set by compute -----------------------------------------------
// The owner, 30 September 2026: "a full continuum of just-in-time improvisation (choosing from among fewer
// contingencies, faster, to handle less complex problems) versus far-in-advance composition (choosing from among many
// contingencies, slower, to handle more complex problems) subject to available computing power, where hugely available
// compute would allow composition-like planning almost synchronously as the bots can afford to entertain more
// contingency plans quickly (i.e., more overplans)."
// A planner that has measured what one decision costs it (ms to decide one bar of one contingency; measured once in
// development and kept as data) and is given a budget (ms it may spend before its next commitment is due) can afford
// budget / cost decisions, d. Ours: it spends them as d^(1/3) contingencies at each decision (at most `most`, the
// overplans' branches) and a horizon of d^(2/3) bars (up to the piece), so that both grow with the budget and never
// shrink: a small budget is improvisation (a bar or two, one contingency), a large one composition (the whole piece,
// several contingencies at each decision). -> {horizon: {bars} | 'piece', contingencies, decisions}
export function affordablePlanning({budgetMs,msPerDecision,pieceBars=null,most=4}={}){
  if(!positive(budgetMs)||!positive(msPerDecision))fail('Planning is afforded from a positive budget and a positive cost a decision');
  const decisions=Math.max(1,Math.floor(budgetMs/msPerDecision+1e-9));
  const contingencies=Math.max(1,Math.min(most,Math.floor(Math.cbrt(decisions)+1e-9)));
  const bars=Math.max(1,Math.floor(decisions**(2/3)+1e-9));
  return Object.freeze({horizon:Number.isFinite(pieceBars)&&bars>=pieceBars?'piece':Object.freeze({bars}),contingencies,decisions});
}
