// Exact relationships for planned canon/fugue material (research/fugue-and-coordination, CF01–CF04).
// Adapted from the supplied reference/core.mjs. These checks name their predicates; none implies musical quality,
// a complete historical style, player feasibility or audible timing. Callbacks are trusted planning code, never
// network-supplied programs. Shape/work limits bound our work, not a callback's running time or an audio deadline.
import {Refused,Budget,EXACT_LIMITS,exactOf,add,sub,mul,div,compare,exactText,pythonJson,sha256} from '../bounded-exact.js';
import {dataRecord,dataArray} from './contract-data.js';

export const CANON_LIMITS=Object.freeze({events:4096,boundaries:8192,rules:128,candidates:256,selection:64,
  period:65536,string:2048,depth:16,checks:65536});
const fail=message=>{throw new Refused(message)};
const integer=value=>{
  if(typeof value==='bigint'||Number.isSafeInteger(value))return value;
  if(typeof value==='string'&&value.length<=160&&/^[+-]?\d+$/.test(value))return BigInt(value);
  fail('Use an exact integer, or n/d text for a fraction');
};
const rationals=new WeakSet;
const made=value=>{
  const q=Object.create(Rational.prototype);q.n=value.n;q.d=value.d;rationals.add(q);return Object.freeze(q);
};
// For the musical core (shared/musical-core.js), which writes a Rational as its text and reads one back made: n and d
// BigInts, reduced, d positive.
export const isRational=value=>rationals.has(value);
export const madeRational=(n,d)=>made({n,d});
// The reference API over the project's bounded exact arithmetic. Only values we made may bypass the raw input cap.
export class Rational {
  constructor(n,d=1){return made(exactOf([integer(n),integer(d)]))}
  static from(value){
    if(value&&rationals.has(value))return value;
    if(typeof value==='string'&&value.includes('/')){
      if(value.length>160)fail('Rational text is too long');
      const parts=value.split('/');if(parts.length!==2)fail('Malformed rational');
      return new Rational(parts[0],parts[1]);
    }
    if(dataRecord(value)&&Object.hasOwn(value,'n')&&Object.hasOwn(value,'d'))
      return new Rational(value.n,value.d);
    return new Rational(value);
  }
  add(value){return made(add(this,Q(value)))}
  sub(value){return made(sub(this,Q(value)))}
  mul(value){return made(mul(this,Q(value)))}
  div(value){return made(div(this,Q(value)))}
  cmp(value){return compare(this,Q(value))}
  eq(value){return this.cmp(value)===0}
  toString(){return exactText(this)}
  toJSON(){return this.toString()}
}
export const Q=value=>Rational.from(value);
// A note's exact onset and duration from its start and length in floating point, each read by `read` (its module's own
// reading of a float, as Q takes it): its end read where its start and length put it, at the same reading, so that notes
// monophonic in floating point stay so exactly. Read apart, a meter of thirds overran its next note -- 2.666667 and
// 2.666667 past 5.333333 at six places, every stretto's monophony failed (stretto.js, 26 October 2026's test meters).
// -> {t, d}, Rationals.
export const exactSpan=(read,start,length)=>{const t=Q(read(start));return {t,d:Q(read(Number(start)+Number(length))).sub(t)}};
const list=dataArray;
const name=(value,label)=>{if(typeof value!=='string'||!value.length||value.length>CANON_LIMITS.string)fail(`Invalid ${label}`);return value};
const plain=dataRecord;
// Snapshot semantic data before calling a rule. Bounds cover metadata too, including data the rule doesn't inspect.
function copy(value,budget,depth=0,seen=new Set){
  budget.charge();
  if(value===null||typeof value==='boolean')return value;
  if(typeof value==='number'){if(!Number.isFinite(value))fail('Nonfinite semantic value');return Object.is(value,-0)?0:value}
  if(typeof value==='string'){if(value.length>CANON_LIMITS.string)fail('Semantic text is too long');return value}
  if(value&&rationals.has(value))return value;
  if(depth>=CANON_LIMITS.depth||seen.has(value))fail('Semantic data is cyclic or too deep');
  if(!Array.isArray(value)&&!plain(value))fail('Semantic data must be plain finite values');
  const keys=Object.keys(value);if(keys.length>CANON_LIMITS.events)fail('Semantic object is too wide');
  seen.add(value);let out;
  if(Array.isArray(value)){
    list(value,CANON_LIMITS.events,'Semantic array');out=[];
    for(let i=0;i<value.length;i++){if(!Object.hasOwn(value,i))fail('Sparse semantic array');out.push(copy(value[i],budget,depth+1,seen))}
  }else{
    out={};for(const key of keys){name(key,'semantic key');Object.defineProperty(out,key,{value:copy(value[key],budget,depth+1,seen),enumerable:true})}
  }
  seen.delete(value);return Object.freeze(out);
}
function normalized(events,budget){
  list(events,CANON_LIMITS.events,'Events');const seen=new Set;
  const out=events.map(event=>{
    budget.charge();if(!plain(event))fail('An event must be a plain object');
    name(event.id,'event id');if(seen.has(event.id))fail('Duplicate event identity');seen.add(event.id);
    if(!Object.hasOwn(event,'pitch')||event.pitch===undefined)fail('pitch is required; null means rest');
    const t=Q(event.t),d=Q(event.d);if(t.cmp(0)<0||d.cmp(0)<=0)fail('Require onset >= 0 and duration > 0');
    for(const key of ['voiceId','entryId','sourceId'])if(Object.hasOwn(event,key))name(event[key],key);
    return copy({...event,t,d},budget);
  });
  return out.sort((a,b)=>{budget.charge();return a.t.cmp(b.t)||(a.id<b.id?-1:a.id>b.id?1:0)});
}
// Fresh arrays of immutable events. Ties must already have been resolved into sounding intervals.
export function normalizeEvents(events,{maxWork}={}){return normalized(events,new Budget(maxWork))}

function transformed(events,{length,delay=0,stretch=1,retrograde=false,pitchMap=p=>p,entryId='derived',voiceId}={},budget){
  const L=Q(length),delta=Q(delay),r=Q(stretch);
  if(L.cmp(0)<=0||delta.cmp(0)<0||r.cmp(0)<=0)fail('Require positive length/stretch and nonnegative output delay');
  if(typeof retrograde!=='boolean'||typeof pitchMap!=='function')fail('Invalid transformation');
  name(entryId,'entry id');if(voiceId!==undefined)name(voiceId,'voice id');
  const source=normalized(events,budget);
  // Check the whole input before any semantic map is called.
  for(const event of source){budget.charge();if(event.t.add(event.d).cmp(L)>0)fail('Event exceeds declared phrase length')}
  return source.map(event=>{
    budget.charge();const pitch=event.pitch===null?null:pitchMap(event.pitch,event);
    if(pitch===undefined)fail('pitchMap returned undefined');
    const phase=retrograde?L.sub(event.t).sub(event.d):event.t;
    const id=`${entryId}:${event.id}`;name(id,'derived event id');
    return copy({...event,id,sourceId:event.id,entryId,...(voiceId===undefined?{}:{voiceId}),
      t:delta.add(r.mul(phase)),d:r.mul(event.d),pitch},budget);
  }).sort((a,b)=>{budget.charge();return a.t.cmp(b.t)||(a.id<b.id?-1:a.id>b.id?1:0)});
}
// Transform intervals, including rests and gaps: reversal starts at L-t-d, not L-t.
export function transformPhrase(events,transform={}){return transformed(events,transform,new Budget(transform.maxWork))}

export function auditCanon(source,follower,transform,pitchEqual=null){
  if(pitchEqual!==null&&typeof pitchEqual!=='function')fail('Pitch equality must be a semantic predicate');
  const budget=new Budget(transform?.maxWork),snapshot=normalized(source,budget),actual=normalized(follower,budget);
  const expected=transformed(snapshot,transform,budget);
  const bySource=new Map,issues=[];let unknown=false;
  for(const event of actual){
    budget.charge();
    if(typeof event.sourceId!=='string'||bySource.has(event.sourceId))issues.push({rule:'SOURCE_ID',eventId:event.id});
    else bySource.set(event.sourceId,event);
  }
  for(const event of expected){
    budget.charge();const found=bySource.get(event.sourceId);
    if(!found){issues.push({rule:'MISSING_EVENT',sourceId:event.sourceId});continue}
    if(found.id!==event.id||found.entryId!==event.entryId||found.voiceId!==event.voiceId)issues.push({rule:'IDENTITY_RELATION',eventId:found.id});
    if(!found.t.eq(event.t)||!found.d.eq(event.d))issues.push({rule:'TIME_RELATION',eventId:found.id});
    const opaque=p=>p!==null&&typeof p==='object';
    const same=pitchEqual?pitchEqual(found.pitch,event.pitch):opaque(found.pitch)||opaque(event.pitch)?'UNKNOWN':Object.is(found.pitch,event.pitch);
    if(same==='UNKNOWN'){unknown=true;issues.push({rule:'PITCH_SEMANTICS',eventId:found.id,status:'UNKNOWN'})}
    else if(typeof same!=='boolean')fail('Pitch equality must return a boolean or UNKNOWN');
    else if(!same)issues.push({rule:'PITCH_RELATION',eventId:found.id});
    bySource.delete(event.sourceId);
  }
  for(const event of bySource.values())issues.push({rule:'EXTRA_EVENT',eventId:event.id});
  return {status:issues.some(issue=>issue.status!=='UNKNOWN')?'FAIL':unknown?'UNKNOWN':'PASS',scope:'exact-transformation-only',
    issues,workUsed:budget.used,sourceHash:sha256(pythonJson(snapshot)),followerHash:sha256(pythonJson(actual))};
}

function sweep(events,boundaries,budget){
  const es=normalized(events,budget);list(boundaries,CANON_LIMITS.boundaries,'Context boundaries');const points=new Map;
  const point=value=>{
    budget.charge();const t=Q(value);if(t.cmp(0)<0)fail('Negative context boundary');
    const key=t.toString();if(!points.has(key))points.set(key,{t,starts:[],ends:[]});return points.get(key);
  };
  for(const event of es){
    const from=point(event.t),to=point(event.t.add(event.d));
    if(event.pitch!==null){from.starts.push(event);to.ends.push(event)}
  }
  for(const boundary of boundaries)point(boundary);
  const ps=[...points.values()].sort((a,b)=>{budget.charge();return a.t.cmp(b.t)}),active=new Map,slices=[];
  for(let i=0;i+1<ps.length;i++){
    budget.charge();const p=ps[i];
    for(const event of p.ends){budget.charge();active.delete(event.id)}
    for(const event of p.starts){budget.charge();active.set(event.id,event)}
    // Charge materialized memberships as well as boundaries: long polyphony must not hide quadratic output.
    budget.charge(active.size);
    const sounding=[...active.values()].sort((a,b)=>{budget.charge();return a.id<b.id?-1:a.id>b.id?1:0});
    slices.push(Object.freeze({start:p.t,end:ps[i+1].t,active:Object.freeze(sounding)}));
  }
  return slices;
}
export function soundingSlices(events,boundaries=[],{maxWork}={}){return sweep(events,boundaries,new Budget(maxWork))}

// An audit calls only the supplied rules. Required UNKNOWN, N/A or unexercised rules cannot produce a global PASS.
// initial/final rules may inspect obligations at the extent's ends; slice/transition retain the reference API.
export function auditSlices(events,{boundaries=[],contextAt=()=>({}),rules=[],maxWork,profileId='supplied-rules',profileVersion=1,dependencies={}}={}){
  const budget=new Budget(maxWork);name(profileId,'profile id');
  if(!Number.isSafeInteger(profileVersion)||profileVersion<0||typeof contextAt!=='function')fail('Invalid profile/context');
  list(rules,CANON_LIMITS.rules,'Rules');const ids=new Set;
  const checkedRules=rules.map(rule=>{
    if(!plain(rule)||typeof rule.check!=='function')fail('A rule needs a check');name(rule.id,'rule id');
    if(ids.has(rule.id))fail('Duplicate rule id');ids.add(rule.id);
    if(!['slice','transition','initial','final'].includes(rule.kind))fail('Unknown rule kind');
    if(rule.required!==undefined&&typeof rule.required!=='boolean')fail('required must be boolean');
    return Object.freeze({id:rule.id,kind:rule.kind,required:rule.required??false,check:rule.check});
  });
  const snapshot=normalized(events,budget),contextDependencies=copy(dependencies,budget);
  const slices=Object.freeze(sweep(snapshot,boundaries,budget)),checks=[],contexts=new Map;
  const context=t=>{const key=t.toString();if(!contexts.has(key))contexts.set(key,copy(contextAt(t),budget));return contexts.get(key)};
  const record=(rule,status,time,detail)=>{
    if(!['PASS','FAIL','UNKNOWN','N/A'].includes(status))fail(`Invalid result for ${rule.id}`);
    if(checks.length>=CANON_LIMITS.checks)throw new Refused('Audit output limit',{kind:'work-budget'});
    if(status==='N/A'&&rule.required)status='UNKNOWN';
    checks.push({rule:rule.id,status,...(time?{time:time.toString()}:{}),...(detail===undefined?{}:{detail:copy(detail,budget)})});
  };
  for(const rule of checkedRules){
    let invoked=false;
    const indices=rule.kind==='initial'?[0]:rule.kind==='final'?[slices.length-1]:slices.map((_,i)=>i);
    for(const i of indices){
      if(!slices.length||rule.kind==='transition'&&i===0)continue;
      budget.charge();invoked=true;const slice=slices[i],time=rule.kind==='final'?slice.end:slice.start;
      const result=rule.check(Object.freeze({slice,previous:i?slices[i-1]:null,context:context(time),index:i,slices}));
      record(rule,typeof result==='string'?result:result?.status,time,typeof result==='object'&&result!==null?result.detail:undefined);
    }
    if(!invoked&&rule.required)record(rule,'UNKNOWN',null,'No applicable slices.');
  }
  const statuses=checks.map(check=>check.status),status=statuses.includes('FAIL')?'FAIL':statuses.includes('UNKNOWN')?'UNKNOWN':statuses.includes('PASS')?'PASS':'UNKNOWN';
  const contextRecord=[...contexts].map(([time,value])=>({time,value}));
  const eventHash=sha256(pythonJson(snapshot)),contextHash=sha256(pythonJson({contexts:contextRecord,dependencies:contextDependencies}));
  return {status,scope:checkedRules.map(rule=>rule.id),profileId,profileVersion,checks,eventHash,contextHash,workUsed:budget.used};
}

// Finite exact-size selection: pair constraints prune; a nonhereditary joint predicate is checked only at full leaves.
export function chooseCompatibleSet(candidates,{size,pairOK,jointOK,maxNodes=10000,maxWork}={}){
  list(candidates,CANON_LIMITS.candidates,'Candidates');
  if(!Number.isSafeInteger(size)||size<0||size>CANON_LIMITS.selection||!Number.isSafeInteger(maxNodes)||maxNodes<0||maxNodes>EXACT_LIMITS.maxWork)fail('Invalid selection size/budget');
  if(typeof pairOK!=='function'||typeof jointOK!=='function')fail('Independent pair and joint predicates required');
  const budget=new Budget(maxWork),values=candidates.map(value=>copy(value,budget)),cache=new Map;
  let nodes=0,exhausted=false,solution=null;
  const pair=(i,j)=>{
    budget.charge();const key=`${Math.min(i,j)},${Math.max(i,j)}`;
    if(!cache.has(key)){const ok=pairOK(values[Math.min(i,j)],values[Math.max(i,j)]);if(typeof ok!=='boolean')fail('pairOK must return boolean');cache.set(key,ok)}
    return cache.get(key);
  };
  function dfs(chosen,next){
    if(solution||exhausted)return;
    if(nodes>=maxNodes){exhausted=true;return}budget.charge();nodes++;
    if(chosen.length===size){
      const set=Object.freeze(chosen.map(i=>values[i])),ok=jointOK(set);if(typeof ok!=='boolean')fail('jointOK must return boolean');if(ok)solution=set;return;
    }
    for(let i=next;i<=values.length-(size-chosen.length);i++){
      budget.charge();if(chosen.every(j=>pair(i,j)))dfs([...chosen,i],i+1);if(solution||exhausted)return;
    }
  }
  try{dfs([],0)}catch(error){if(!(error instanceof Refused)||error.kind!=='work-budget')throw error;exhausted=true}
  return {status:solution?'SAT':exhausted?'UNKNOWN':'UNSAT',solution,nodes,cachedPairs:cache.size,workUsed:budget.used,scope:'supplied-candidate-set-and-validators'};
}

// Same constant wall-clock units, onset information only: L + max(0,(1-r)T). Not a gesture/readiness guarantee.
export function minimumStreamingDelay({sourceHorizon,stretch,latency}){
  const T=Q(sourceHorizon),r=Q(stretch),L=Q(latency);
  if(T.cmp(0)<0||L.cmp(0)<0||r.cmp(0)<=0)fail('Invalid streaming parameters');
  const catchUp=Q(1).sub(r).mul(T);return L.add(catchUp.cmp(0)>0?catchUp:0);
}

// Cyclic onset coverage only, not pitch counterpoint or nonoverlap of held sound.
export function tilingCoverage(A,B,N,{maxWork}={}){
  if(!Number.isSafeInteger(N)||N<=0||N>CANON_LIMITS.period)fail('Invalid cyclic period');
  const budget=new Budget(maxWork);
  const normalize=values=>{
    list(values,CANON_LIMITS.period,'Residues');const out=[];
    for(const value of values){budget.charge();if(!Number.isSafeInteger(value))fail('Residues must be exact integers');out.push(((value%N)+N)%N)}
    if(new Set(out).size!==out.length)fail('Duplicate residues are not a set');return out;
  };
  A=normalize(A);B=normalize(B);budget.charge(N);const coverage=Array(N).fill(0);
  for(const a of A)for(const b of B){budget.charge();coverage[(a+b)%N]++}
  function periods(values){
    const set=new Set(values),out=[];
    for(let p=1;p<N;p++){budget.charge();if(N%p===0&&values.every(x=>{budget.charge();return set.has((x+p)%N)}))out.push(p)}return out;
  }
  const periodsA=periods(A),periodsB=periods(B),tiles=coverage.every(count=>count===1);
  return {tiles,coverage,periodsA,periodsB,vuza:tiles&&A.length>1&&B.length>1&&!periodsA.length&&!periodsB.length,
    scope:'cyclic-onset-tiling-only',workUsed:budget.used};
}
