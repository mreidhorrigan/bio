// Counterpoint as constraint, planned ahead (the owner, 2 October 2026: "We must use the long-term planning
// capabilities to add support for canons and fugues, which require the ability to apply various sets of counterpoint
// rules to the planning process -- perhaps an extreme case of constraint"). A line is planned whole against the lines it
// sounds with, every note's choice weighed by a set of rules, by a beam search (the best few settings kept note by note,
// so an early note leaves the later ones room): a countersubject against its subject, or a canon's subject against
// itself -- each of its notes heard against the notes its other voices will be playing then, which it has already
// chosen (the comes is the dux, later). Feasible by construction where the rules can be kept: no line drawn and refused.
//
// Intervals in cents (any tuning: a 31-EDO third is a third), their kind by the nearest of the just intervals with a
// width (COUNTERPOINT.consonance). The rule sets are data, every one of them a table of costs over the same events, so
// any two blend (blendRules: every state between) and any is softened (strictness, 0 none of it to 1 all):
//   strict     Fux's species (Gradus ad Parnassum, 1725): consonance on every beat, a dissonance only passing, by step,
//              on a weak one; no parallel perfect intervals, none approached in similar motion; contrary motion
//              preferred; leaps recovered by a step the other way; no unisons but at its ends.
//   tonal      a fugue's (as Bach's): consonance on the strong beats, a dissonance on a weak one entered and left by step,
//              parallel perfects forbidden, the voices' independence by contrary motion.
//   free       post-tonal: any interval, but no doubling (unisons and octaves) and no perfect intervals in parallel, the
//              lines kept apart by their motion.
//   dissonant  Charles Seeger's dissonant counterpoint (as Ruth Crawford Seeger and Carl Ruggles wrote it): dissonance
//              the norm and consonance the exception, a consonance on a beat answered by a dissonance, no repeated tone.
//   micropolyphonic  Ligeti's micropolyphony (Atmosphères 1961, the Requiem's Kyrie 1965, Lontano 1967: canons of many
//              parts, each line heard only as the texture's) and Schnittke's canons over the orchestra: the harmonic
//              constraints abandoned, each line's melodic shape kept (its leaps recovered, few repeated tones).
// Each set leaves room for as many voices as its harmonic rules can be kept among (COUNTERPOINT.room): Fux's species
// four, Bach's fugue six (the Musical Offering's six-voice ricercar, BWV 1079), the post-tonal sets' no doubling as many
// as the tuning has pitch classes, micropolyphony any number -- and needs as many as a listener cannot follow one by one
// before its texture is one (`least`: four times the three voices a listener follows, Huron 1989). A canon's or a
// fugue's blend is drawn as its voices leave its sets room (drawnRules): two hundred voices are not a fugue in Bach's
// idiom (the owner, 3 October 2026: "his constraints don't leave space for it; depends on the set of rules being
// applied").
// A line is heard against the voices nearest it in pitch, as many as a listener follows (COUNTERPOINT.heard: three,
// Huron 1989, "Voice denumerability in polyphonic music of homogeneous timbres", Music Perception 6(4), 361-382,
// doi:10.2307/40285445: identification drops markedly from three voices to four), and its harmonic rules are kept
// against those: in four voices or fewer, every other voice; in two hundred, its neighbours.
// Voice leading derived from perception (Huron 2001, "Tone and Voice: A Derivation of the Rules of Voice-Leading from
// Perceptual Principles", Music Perception 19(1), doi:10.1525/mp.2001.19.1.1); counterpoint as constraint search
// (Ebcioğlu 1990, doi:10.1016/0743-1066(90)90055-A; Herremans and Sörensen 2013, "Composing fifth species counterpoint
// music with a variable neighborhood search algorithm", doi:10.1016/j.eswa.2013.05.071).

import {constraintsAt,constraintCost,lineSteps} from '../pitch-constraints.js';
import {styleSpace} from '../style-space.js';

const modulo=(x,n)=>((x%n)+n)%n;
export const COUNTERPOINT=Object.freeze({
  // The just intervals each kind is measured against (cents within the octave), and how near counts (cents: a
  // 12-EDO third, 14 and 16 cents from 5/4 and 6/5, a third).
  consonance:Object.freeze({perfect:Object.freeze([0,702,498,1200]),imperfect:Object.freeze([316,386,814,884]),width:35}),
  // How many settings the search keeps at each note, where its rules bind fully (fewer as they bind less: fugue-plan.js).
  beam:16,
  // How many of the voices sounding with a line it is heard against: the nearest in pitch.
  heard:3,
  // The widest move counted a step (semitones: a dissonance entered by one is prepared, a leap recovered by one), and
  // how near two voices sound in unison (cents).
  step:2.5,unison:5,
  // The voices each set leaves room for: [least, most] ('classes': the collection's pitch classes).
  room:Object.freeze({strict:Object.freeze([1,4]),tonal:Object.freeze([1,6]),free:Object.freeze([1,'classes']),dissonant:Object.freeze([1,'classes']),micropolyphonic:Object.freeze([12,Infinity])}),
  // The rule sets: each event's cost (a rule broken is one RULE, a preference a fraction of it).
  rules:Object.freeze({
    strict:Object.freeze({strong:Object.freeze({perfect:0,imperfect:0,dissonant:1}),weak:Object.freeze({perfect:0,imperfect:0,dissonant:.15}),unpreparedDissonance:1,
      parallelPerfect:1,directPerfect:.6,similar:.12,unrecovered:.6,unison:.5,crossing:.6,repeated:.2,leapMost:12}),
    tonal:Object.freeze({strong:Object.freeze({perfect:.05,imperfect:0,dissonant:.8}),weak:Object.freeze({perfect:0,imperfect:0,dissonant:.1}),unpreparedDissonance:.6,
      parallelPerfect:1,directPerfect:.3,similar:.08,unrecovered:.4,unison:.3,crossing:.4,repeated:.15,leapMost:12}),
    free:Object.freeze({strong:Object.freeze({perfect:.25,imperfect:0,dissonant:0}),weak:Object.freeze({perfect:.1,imperfect:0,dissonant:0}),unpreparedDissonance:0,
      parallelPerfect:.8,directPerfect:.1,similar:.1,unrecovered:.2,unison:.8,crossing:.2,repeated:.1,leapMost:14}),
    dissonant:Object.freeze({strong:Object.freeze({perfect:1,imperfect:.6,dissonant:0}),weak:Object.freeze({perfect:.5,imperfect:.2,dissonant:0}),unpreparedDissonance:0,
      parallelPerfect:1,directPerfect:.4,similar:.1,unrecovered:.3,unison:1,crossing:.2,repeated:.6,leapMost:14}),
    micropolyphonic:Object.freeze({strong:Object.freeze({perfect:0,imperfect:0,dissonant:0}),weak:Object.freeze({perfect:0,imperfect:0,dissonant:0}),unpreparedDissonance:0,
      parallelPerfect:0,directPerfect:0,similar:0,unrecovered:.3,unison:0,crossing:0,repeated:.15,leapMost:7}),
  }),
});
export const RULE_SETS=Object.freeze(Object.keys(COUNTERPOINT.rules));
// The counterpoint planner's style space (style-space.js; the owner, 4 November 2026: "integrate all other hardcoded
// 'styles' using our vectorization/parameterization method, adding parameters where necessary but consolidating where
// possible"): each rule's cost a dimension, an interval's cost on a strong beat and on a weak one by its kind, the rule
// sets its named locations. A line's rules stand at a set, at a blend of sets ({strict: .3, free: .7}), at either with
// any rule set apart ({tonal: 1, parallelPerfect: .5}), or anywhere else, every rule given (blendRules).
const KINDS=Object.freeze(['perfect','imperfect','dissonant']),PLACES=Object.freeze(['strong','weak']),RULE_KEYS=Object.freeze(['unpreparedDissonance','parallelPerfect','directPerfect','similar','unrecovered','unison','crossing','repeated']);
const placed=(place,kind)=>place+kind[0].toUpperCase()+kind.slice(1);
export const COUNTERPOINT_SPACE=styleSpace({name:"the counterpoint planner's",dimensions:{
  ...Object.fromEntries(PLACES.flatMap(place=>KINDS.map(kind=>[placed(place,kind),`a${kind==='imperfect'?'n':''} ${kind} interval's cost on a ${place} beat`]))),
  unpreparedDissonance:'a dissonance on a weak beat not entered by step',parallelPerfect:'perfect intervals in parallel',directPerfect:'a perfect interval approached in similar motion',
  similar:'any similar motion (contrary motion preferred)',unrecovered:'a leap of more than a major third not recovered by a step the other way',unison:'a unison',
  crossing:'a voice crossing the voice it is to stay above or below',repeated:'a repeated tone',leapMost:'the widest leap allowed (semitones): past it, a whole rule broken'},
  locations:Object.fromEntries(RULE_SETS.map(name=>{const set=COUNTERPOINT.rules[name];
    return [name,{...Object.fromEntries(PLACES.flatMap(place=>KINDS.map(kind=>[placed(place,kind),set[place][kind]]))),...Object.fromEntries(RULE_KEYS.map(key=>[key,set[key]])),leapMost:set.leapMost}]}))});
// A rule broken's cost in a line's planning (counterLine's cost: a rule broken is one RULE, a preference a fraction).
export const RULE=100;
// counterLine, lineCost and countBreaks run faster where a core is installed (shared/musical-core.js: their Rust port,
// the same choices from the same inputs and draws; research/RUST_PORT_STATE.md). It declines (null) what it does not
// take, before it draws or asks anything, and they plan that here as ever. -> the core it replaced.
let core=null;
export function useCounterpointCore(given=null){const previous=core;core=given;return previous}

// An interval's kind (`cents` between two pitches): perfect, imperfect or dissonant, by the nearest just interval of
// each kind within the width. (Each interval's kind kept once worked out: a line planned against many voices asks the
// same few intervals again and again.)
const kinds=new Map;
export function intervalKind(cents){
  const c=modulo(Math.round(cents*1000)/1000,1200),known=kinds.get(c);if(known)return known;
  const {perfect,imperfect,width}=COUNTERPOINT.consonance;
  const near=list=>{let least=Infinity;for(const target of list)least=Math.min(least,Math.abs(c-target),Math.abs(c-target+1200));return least};
  const kind=near(perfect)<=width?'perfect':near(imperfect)<=width?'imperfect':'dissonant';
  if(kinds.size>65536)kinds.clear();kinds.set(c,kind);return kind;
}
// The rules at a location in the counterpoint space (COUNTERPOINT_SPACE: a set by name, a blend of them by weight, a
// weight below 0 none, either with any rule set apart, or every rule given), softened by `strictness` (0 to 1). Weights
// summing to none, no rule binds.
export function blendRules(given='tonal',strictness=1){
  const location=typeof given==='string'?{[given]:1}:given,weights={};
  for(const [key,value] of Object.entries(location)){
    if(COUNTERPOINT.rules[key])weights[key]=Math.max(0,value);
    else if(!COUNTERPOINT_SPACE.dimensions[key])throw new RangeError(`no counterpoint rules "${key}" (${RULE_SETS.join(', ')})`);
  }
  const whole=Object.keys(location).length-Object.keys(weights).length===COUNTERPOINT_SPACE.names.length;
  if(!whole&&!Object.values(weights).some(w=>w>0))return Object.freeze({strong:Object.freeze({perfect:0,imperfect:0,dissonant:0}),weak:Object.freeze({perfect:0,imperfect:0,dissonant:0}),
    ...Object.fromEntries(RULE_KEYS.map(key=>[key,0])),leapMost:0,leaps:Object.freeze([])});
  const point=COUNTERPOINT_SPACE.locate({...location,...weights}),s=Math.max(0,Math.min(1,strictness));
  const kinds=place=>Object.freeze(Object.fromEntries(KINDS.map(kind=>[kind,s*point[placed(place,kind)]])));
  // (Its leaps as each set it stands between bounds them, each bound with its set's share: a leap costs the share of the
  // sets that forbid it, as every other rule's cost is its sets' costs blended -- never their bounds averaged, which, a
  // blend leaning a little on the micropolyphonic set's 7, had bounded every leap at 11.98 semitones and forbidden the
  // octave by two cents. Its leapMost the bound past which every set forbids a leap: where a leap's cost reaches a whole
  // rule. A location given whole, its own bound.)
  const bounds=new Map;for(const {weight,location:set} of COUNTERPOINT_SPACE.mixtureOf(point))bounds.set(set.leapMost,(bounds.get(set.leapMost)??0)+weight);
  const leaps=Object.freeze([...bounds].sort((a,b)=>a[0]-b[0]).map(([most,share])=>Object.freeze([most,share])));
  return Object.freeze({strong:kinds('strong'),weak:kinds('weak'),...Object.fromEntries(RULE_KEYS.map(key=>[key,s*point[key]])),leapMost:leaps.length?leaps.at(-1)[0]:0,leaps});
}

// What a move of `move` semitones costs under `rules`: the share of their sets that forbid it (blendRules `leaps`), or
// a whole rule past `leapMost` where the rules give no shares.
export function leapCost(move,rules){
  const width=Math.abs(move);
  if(!rules.leaps?.length)return width>rules.leapMost+.05?1:0;
  let cost=0;for(const [most,share] of rules.leaps)if(width>most+.05)cost+=share;
  return cost;
}
// What a note costs a line under `rules`: `pitch` at a note whose sounding partners are `against` ([{pitch, before (the
// partner's previous pitch, or null)}]), after `previous` (the line's last pitch, or null) and `leap` (the last move,
// semitones), on a strong beat or not.
function noteCost(pitch,{previous,leap,against,strong,rules,above=null}){
  let cost=0;const move=previous==null?0:pitch-previous;
  if(previous!=null&&Math.abs(move)<.05)cost+=rules.repeated;
  cost+=leapCost(move,rules);
  if(Math.abs(leap)>4.5&&!(Math.sign(move)===-Math.sign(leap)&&Math.abs(move)>.05&&Math.abs(move)<=COUNTERPOINT.step))cost+=rules.unrecovered;
  for(const partner of against)cost+=pairCost(pitch,{previous,partner,strong,rules,above});
  return cost;
}
// A note's cost against one partner sounding at its onset ({pitch, before: the partner's pitch at the note's
// previous onset, or null}): its interval's kind on its position, a unison, a crossing, and the motion into it.
function pairCost(pitch,{previous,partner,strong,rules,above=null}){
  let cost=0;const move=previous==null?0:pitch-previous;
  const interval=(pitch-partner.pitch)*100,kind=intervalKind(interval),place=strong?rules.strong:rules.weak;
  cost+=place[kind];
  if(Math.abs(interval)<COUNTERPOINT.unison)cost+=rules.unison;
  if(above!=null&&(above?pitch<partner.pitch-.05:pitch>partner.pitch+.05))cost+=rules.crossing;
  if(partner.before!=null&&previous!=null){
    const theirs=partner.pitch-partner.before,before=(previous-partner.before)*100,same=Math.sign(move)===Math.sign(theirs)&&Math.abs(move)>.05&&Math.abs(theirs)>.05;
    if(kind==='perfect'&&intervalKind(before)==='perfect'&&Math.abs(Math.abs(interval)%1200-Math.abs(before)%1200)<30&&Math.abs(move)>.05)cost+=rules.parallelPerfect;
    else if(kind==='perfect'&&same)cost+=rules.directPerfect;
    if(same)cost+=rules.similar;
    // (A dissonance on a weak beat not entered by step.)
    if(kind==='dissonant'&&!strong&&Math.abs(move)>COUNTERPOINT.step)cost+=rules.unpreparedDissonance;
  }
  return cost;
}

// The numbers of a collection's degrees whose span its rules count perfect (intervalKind on the collection's own spans,
// each the mean of that many steps from every degree: COUNTERPOINT.consonance's perfect kinds), the period's excepted
// -- where a fugue's answer or a canon's comes (in a diatonic collection, the fifth and the fourth); none such, the
// number nearest one. No interval of its own: the rule data decide (the owner, 3 October 2026: "don't hardcode
// intervals into the counterpoint rules"). `collection`: pitches or classes, any tuning; `period` semitones.
export function perfectDegrees(collection,period=12){
  const classes=[];for(const p of collection.map(Number).filter(Number.isFinite).map(p=>modulo(p,period)).sort((a,b)=>a-b))if(!classes.some(c=>Math.abs(c-p)<1e-9))classes.push(p);
  const n=classes.length;if(n<2)return [];
  const span=d=>classes.reduce((sum,c,i)=>sum+modulo(classes[(i+d)%n]-c,period),0)/n;
  const perfect=Array.from({length:n-1},(_,k)=>k+1).filter(d=>intervalKind(span(d)*100)==='perfect');
  if(perfect.length)return perfect;
  const {perfect:kinds}=COUNTERPOINT.consonance,away=d=>Math.min(...kinds.filter(c=>c%1200).map(c=>Math.abs(span(d)*100-c)));
  return [Array.from({length:n-1},(_,k)=>k+1).sort((a,b)=>away(a)-away(b))[0]];
}
// The pitches a line may take: `collection` (pitch classes or pitches, any tuning) in `register` {low, high}, low to high.
export function ladderOf(collection,register){
  const out=[];for(let octave=Math.floor(register.low/12)-1;octave<=Math.ceil(register.high/12)+1;octave++)for(const p of collection)out.push(octave*12+modulo(p,12));
  return [...new Set(out.map(p=>+p.toFixed(6)))].filter(p=>p>=register.low-1e-9&&p<=register.high+1e-9).sort((a,b)=>a-b);
}
// The note of `line` ([{pitch, start, length}], in order of its starts, one note at a time: a voice's) sounding at `t`:
// the last begun by `t`, if still sounding, or null.
function soundingIn(line,t){
  let a=0,b=line.length;while(a<b){const m=(a+b)>>1;if(line[m].start<=t+1e-9)a=m+1;else b=m}
  const note=line[a-1];return note&&t<note.start+note.length-1e-9?note:null;
}
// How near the COUNTERPOINT.heard-th nearest of `pitches` sounds to `pitch`, one of them at `own` (the note itself, or
// null) left out; Infinity where there are fewer. A line is heard against that note only nearer than this: as many
// others nearer and it is not.
function heardWithin(pitches,pitch,own){
  const k=COUNTERPOINT.heard,nearest=[];let skipped=own==null;
  for(const q of pitches){
    if(!skipped&&q===own){skipped=true;continue}
    const d=Math.abs(q-pitch);if(nearest.length===k&&!(d<nearest[k-1]))continue;
    let j=nearest.length<k?nearest.length:k-1;while(j>0&&nearest[j-1]>d){nearest[j]=nearest[j-1];j--}nearest[j]=d;
  }
  return nearest.length<k?Infinity:nearest[k-1];
}
// The partners a note at `pitch` is heard against: every one where there are no more than COUNTERPOINT.heard (`shared`
// as they came, then `own`), else the nearest that many in pitch, from `sorted` (`shared` by pitch) and `own`.
function heardPartners(pitch,{shared,sorted,own}){
  const k=COUNTERPOINT.heard;if(shared.length+own.length<=k)return own.length?[...shared,...own]:shared;
  let a=0,b=sorted.length;while(a<b){const m=(a+b)>>1;if(sorted[m].pitch<pitch)a=m+1;else b=m}
  let lo=a-1,hi=a;const out=[];
  while(out.length<k&&(lo>=0||hi<sorted.length))out.push(hi>=sorted.length||lo>=0&&pitch-sorted[lo].pitch<=sorted[hi].pitch-pitch?sorted[lo--]:sorted[hi++]);
  return own.length?[...out,...own].sort((x,y)=>Math.abs(x.pitch-pitch)-Math.abs(y.pitch-pitch)).slice(0,k):out;
}

// A line planned against `against` (lines: [[{pitch, start, length}]], each in order of its starts) on `rhythm` ([{start, length}], quarters), from
// `steps` (ladderOf), under `rules` (blendRules), its strong beats `strong(start)`; `random` [0, 1) the draws that make
// two settings of equal cost differ; `above` whether it keeps above its partners (true), below (false) or either (null).
// `toward` {pitch, start, rules, withSelf, length}: a note given its voice after the line, its way into it weighed as the line's
// next note would be, under the rules of what it enters (a free episode's line led back into a fugue's return), never
// sounded; `withSelf`, against its own delayed voices there too (a round's join: its subject begun again as its later
// voices go on: round-plan.js).
// `constraints` (pitch-constraints.js, the voice leaders' vocabulary): the line's own, each in its window of quarters
// (from, until): a hard one shapes the steps a note may take (lineSteps), relaxed where it would leave none; a soft one
// costs its weight in rules (1: a rule broken).
// -> {line: [{pitch, start, length}], cost}.
export function counterLine({against=[],rhythm,steps,rules=blendRules('tonal'),strong=()=>false,random=Math.random,above=null,start=null,beam=COUNTERPOINT.beam,
  // (Its partners can be the line itself, later: `self` [{delay (quarters), transpose (semitones), or map (pitch ->
  // pitch: a tonal answer's degrees, an inversion), ratio (its augmentation: each note `ratio` times later and longer,
  // from its delay)}], each the line as it will sound delayed, moved and stretched -- a canon's comes, known for every
  // note already chosen.)
  // `relations`: as `self`, two of its voices that sound together without it -- a canon's later voices, a round's
  // voice and the cycle before of one ahead of it -- each the line in the earlier voice's frame against itself delayed
  // and moved into the later's; weighed as that pair alone, from both its sides.
  self=[],relations=[],toward=null,constraints=null}){
  if(core){const planned=core.counterLine(arguments[0]);if(planned)return planned}
  if(!steps.length||!rhythm.length)return {line:[],cost:0};
  // (The note it leads into, `toward`, weighed with its last note as the search chooses it: its way in, and a round's
  // joins -- else the joins, weighed only once its line was settled, could be mended by its last few notes alone.)
  const towardCost=toward&&Number.isFinite(toward.pitch)?(()=>{
    const at=toward.start,then=rhythm.at(-1).start;
    const shared=against.map(line=>{const note=soundingIn(line,at);if(!note)return null;const was=soundingIn(line,then);return {pitch:note.pitch,before:was?.pitch??null}}).filter(Boolean);
    const sorted=shared.length>COUNTERPOINT.heard?[...shared].sort((a,b)=>a.pitch-b.pitch):shared;
    const ownAt=line=>toward.withSelf?self.flatMap(({delay,transpose=0,map=null,ratio=1})=>{const moved=pitch=>map?map(pitch):pitch+transpose,source=t=>t<delay-1e-9?null:soundingIn(line,(t-delay)/ratio),note=source(at);
      if(!note)return [];const was=source(then);return [{pitch:moved(note.pitch),before:was?moved(was.pitch):null}]}):[];
    // (A round's join, where its `length` is given, weighed as its notes are: against its relations, and from its
    // partners' side, every delayed voice's note beginning while it sounds.)
    const joining=toward.withSelf&&toward.length>0,until=at+(toward.length??0)-1e-9,law=toward.rules??rules;
    const joinCost=state=>{if(!joining)return 0;const line=state.line,previous=line.at(-1).pitch;let cost=0;
      for(const {delay,transpose=0,map=null,ratio=1} of relations){const moved=pitch=>map?map(pitch):pitch+transpose,source=t=>t<delay-1e-9?null:soundingIn(line,(t-delay)/ratio),note=source(at);
        if(note){const was=source(then);cost+=pairCost(toward.pitch,{previous,partner:{pitch:moved(note.pitch),before:was?moved(was.pitch):null},strong:strong(at),rules:law})}}
      const lineAt=t=>t>=at-1e-9?toward.pitch:soundingIn(line,t)?.pitch??null;
      for(const {delay,transpose=0,map=null,ratio=1} of [...self,...relations]){const moved=pitch=>map?map(pitch):pitch+transpose;
        for(let k=0;k<=line.length;k++){const start=k<line.length?line[k].start:at,u=delay+start*ratio;if(u<at-1e-9||u>=until)continue;
          const before=line[k-1]??null,theirs=moved(k<line.length?line[k].pitch:toward.pitch);
          cost+=pairCost(theirs,{previous:before?moved(before.pitch):null,partner:{pitch:toward.pitch,before:before?lineAt(delay+before.start*ratio):null},strong:strong(u),rules:law})}
        // (And each delayed voice's own join, every cycle after its first: its first note again, from its last, as the
        // line sounds then -- the line's note at the cycle before read round.)
        const round=t=>soundingIn(line,((t%at)+at)%at)?.pitch??null,mine=soundingIn(line,delay)?.pitch;
        if(Number.isFinite(mine))cost+=pairCost(moved(line[0].pitch),{previous:moved(previous),partner:{pitch:mine,before:round(delay+line.at(-1).start*ratio-at)},strong:strong(delay),rules:law})}
      return cost};
    return state=>noteCost(toward.pitch,{previous:state.line.at(-1).pitch,leap:state.leap,against:heardPartners(toward.pitch,{shared,sorted,own:ownAt(state.line)}),strong:strong(at),rules:law,above})+joinCost(state);
  })():null;
  let states=[{line:[],cost:0,leap:0}];
  for(const [i,{start:at,length}] of rhythm.entries()){
    const next=[],then=i?rhythm[i-1].start:null;
    // (Each partner's note now, and the one it was sounding at the line's last note, the motion the two lines made: the
    // same for every setting kept, as they share the rhythm.)
    const shared=against.map(line=>{const note=soundingIn(line,at);if(!note)return null;const was=then==null?null:soundingIn(line,then);return {pitch:note.pitch,before:was?.pitch??null}}).filter(Boolean);
    const sorted=shared.length>COUNTERPOINT.heard?[...shared].sort((a,b)=>a.pitch-b.pitch):shared;
    // (Its partners' side, as the law hears every line: each note a partner begins while this one sounds, from its onset
    // on, against it -- the partner's motion into it from its own note before, and this line's pitch at that note's
    // onset. Planned from its own side only, a canon's later voices, entering under its held notes, had been left in
    // parallels and dissonances it never weighed: a third of the canons and rounds its planner made broke its own law.
    // A crossing too, the partner kept on the other side of it (`above`, theirs the other way): heard from its own side
    // only, a section's upper part entering below a lower one's held note had cost nothing, and a lower part sat as high
    // as its own onsets let it -- a dissonant blend's tenth of its notes crossed, a sixth in some phrases.)
    // (Each partner's notes found by bisection, and how near each one's nearest others sound (heardWithin) once for every
    // setting tried, the voices sounding at each onset found once: weighed for each setting against all its partners'
    // others, two hundred voices had taken hours.)
    const until=at+length-1e-9,others=(u,except)=>against.flatMap((line,j)=>{if(j===except)return [];const note=soundingIn(line,u);return note?[note.pitch]:[]});
    const soundingAt=new Map,pitchesAt=u=>{let pitches=soundingAt.get(u);if(!pitches){pitches=[];for(const line of against){const note=soundingIn(line,u);if(note)pitches.push(note.pitch)}
      soundingAt.set(u,pitches)}return pitches};
    const entering=[];
    for(const [j,line] of against.entries()){
      let a=0,b=line.length;while(a<b){const m=(a+b)>>1;if(line[m].start<at-1e-9)a=m+1;else b=m}
      for(let k=a;k<line.length&&line[k].start<until;k++){const note=line[k],own=soundingIn(line,note.start)?.pitch??null;
        entering.push({pitch:note.pitch,start:note.start,previous:line[k-1]?.pitch??null,then:line[k-1]?.start??null,heard:heardWithin(pitchesAt(note.start),note.pitch,own)})}
    }
    for(const state of states){
      const previous=state.line.at(-1)?.pitch??null,own=[];
      // (Its own earlier notes as its delayed voices will be sounding them now.)
      for(const {delay,transpose=0,map=null,ratio=1} of self){const moved=pitch=>map?map(pitch):pitch+transpose,source=t=>t<delay-1e-9?null:soundingIn(state.line,(t-delay)/ratio),note=source(at);
        if(note){const was=then==null?null:source(then);own.push({pitch:moved(note.pitch),before:was?moved(was.pitch):null})}}
      // (And its delayed voices' notes beginning while this one sounds, this one among them where a delay is shorter
      // than it: each against this line, the others sounding then heard first where they are nearer.)
      const sides=[...entering];
      // (Its relations: the pair at this note's onset, from this side.)
      const related=[];
      for(const {delay,transpose=0,map=null,ratio=1} of relations){const moved=pitch=>map?map(pitch):pitch+transpose,source=t=>t<delay-1e-9?null:soundingIn(state.line,(t-delay)/ratio),note=source(at);
        if(note){const was=then==null?null:source(then);related.push({pitch:moved(note.pitch),before:was?moved(was.pitch):null})}}
      const voiceAt=(voice,u)=>{const note=u<voice.delay-1e-9?null:soundingIn(state.line,(u-voice.delay)/(voice.ratio??1));return note?[voice.map?voice.map(note.pitch):note.pitch+(voice.transpose??0)]:[]};
      for(const voice of self){const {delay,transpose=0,map=null,ratio=1}=voice,moved=pitch=>map?map(pitch):pitch+transpose;
        for(let k=0;k<=state.line.length;k++){const note=state.line[k],u=delay+(note?note.start:at)*ratio;if(u<at-1e-9||u>=until)continue;
          const before=k?state.line[k-1]:null;
          sides.push({pitch:note?moved(note.pitch):null,moved:note?null:moved,start:u,previous:before?moved(before.pitch):null,then:before?delay+before.start*ratio:null,
            others:[...others(u,-1),...self.flatMap(other=>other===voice?[]:voiceAt(other,u))]})}}
      for(const {delay,transpose=0,map=null,ratio=1} of relations){const moved=pitch=>map?map(pitch):pitch+transpose;
        for(let k=0;k<=state.line.length;k++){const note=state.line[k],u=delay+(note?note.start:at)*ratio;if(u<at-1e-9||u>=until)continue;
          const before=k?state.line[k-1]:null;
          sides.push({pitch:note?moved(note.pitch):null,moved:note?null:moved,start:u,previous:before?moved(before.pitch):null,then:before?delay+before.start*ratio:null,others:[]})}}
      const active=constraints?.length?constraintsAt(constraints,at):null,open=active?.length?lineSteps(steps,active).steps:steps;
      const candidates=i===0&&start!=null?open.filter(p=>Math.abs(p-start)<1e-6):open;
      // (The partners' notes from their side, each weighed only with the settings near enough to it to be heard: added for
      // each in the order they were, a crossing too, each partner on the other side of it.)
      const heardSides=new Float64Array(candidates.length),rest=sides.slice(entering.length);
      for(const event of entering){const theirs=event.pitch,reach=event.heard;
        for(let c=0;c<candidates.length;c++){const pitch=candidates[c];if(reach<Math.abs(pitch-theirs))continue;
          const before=event.then==null?null:event.then>=at-1e-9?pitch:soundingIn(state.line,event.then)?.pitch??null;
          heardSides[c]+=pairCost(theirs,{previous:event.previous,partner:{pitch,before},strong:strong(event.start),rules,above:above==null?null:!above})}}
      for(const [c,pitch] of candidates.entries()){
        // (This line's pitch at a time: this note from its onset on, else the note it sounded then.)
        const lineAt=t=>t==null?null:t>=at-1e-9?pitch:soundingIn(state.line,t)?.pitch??null;
        let side=heardSides[c];for(const event of rest){const theirs=event.moved?event.moved(pitch):event.pitch,near=Math.abs(pitch-theirs);
          if(event.others.filter(q=>Math.abs(q-theirs)<near).length>=COUNTERPOINT.heard)continue;
          side+=pairCost(theirs,{previous:event.previous,partner:{pitch,before:lineAt(event.then)},strong:strong(event.start),rules})}
        for(const partner of related)side+=pairCost(pitch,{previous,partner,strong:strong(at),rules});
        const leap=previous==null?0:pitch-previous,last=towardCost&&i===rhythm.length-1?towardCost({line:[...state.line,{...rhythm[i],pitch,start:at,length}],leap}):0;
        const wanted=active?.length?constraintCost([pitch],active,{line:true}):0;
        const cost=state.cost+RULE*(noteCost(pitch,{previous,leap:state.leap,against:heardPartners(pitch,{shared,sorted,own}),strong:strong(at),rules,above})+side+last+wanted)+random()*.5;
        next.push({state,pitch,cost,leap});
      }
    }
    // (Only the settings kept are written out.)
    states=next.sort((a,b)=>a.cost-b.cost).slice(0,beam).map(({state,pitch,cost,leap})=>({line:[...state.line,{...rhythm[i],pitch,start:at,length}],cost,leap}));
  }
  const best=states[0];return {line:best.line,cost:+best.cost.toFixed(3)};
}

// What `line` ([{pitch, start, length}], in order) costs under `rules` against `against` (lines, each in order), as
// counterLine weighs a line it plans, without its draws: a line planned one way judged another (an invertible
// countersubject heard on its subject's other side: fugue-plan.js).
export function lineCost({line,against=[],rules=blendRules('tonal'),strong=()=>false,above=null}){
  if(core){const cost=core.lineCost(arguments[0]);if(cost!=null)return cost}
  let cost=0;
  line.forEach((note,i)=>{
    const previous=line[i-1]?.pitch??null,leap=i>1?line[i-1].pitch-line[i-2].pitch:0,then=line[i-1]?.start??null;
    const shared=against.map(other=>{const at=soundingIn(other,note.start);if(!at)return null;const was=then==null?null:soundingIn(other,then);return {pitch:at.pitch,before:was?.pitch??null}}).filter(Boolean);
    const sorted=shared.length>COUNTERPOINT.heard?[...shared].sort((a,b)=>a.pitch-b.pitch):shared;
    cost+=RULE*noteCost(note.pitch,{previous,leap,against:heardPartners(note.pitch,{shared,sorted,own:[]}),strong:strong(note.start),rules,above});
  });
  return cost;
}
// The rules broken by `line` against `against` (lines), as the planner weighs them: for tests and measurement, never
// while playing. -> {strongDissonances, parallelPerfects, unrecovered, notes}.
export function countBreaks(line,against,{strong=()=>false}={}){
  if(core){const counted=core.countBreaks(line,against,arguments[2]);if(counted)return counted}
  let strongDissonances=0,parallelPerfects=0,unrecovered=0;
  // (Each partner's note as the planner hears it: the last begun by then, while it sounds (soundingIn). The first still
  // sounding had been another, where a line's lengths, rounded as a plan writes them, ran a note past the next's start:
  // a /6 meter's thirds of a quarter.)
  const others=against.map(other=>[...other].sort((a,b)=>a.start-b.start));
  line.forEach((note,i)=>{
    const previous=line[i-1],before=line[i-2];
    if(previous&&before&&Math.abs(previous.pitch-before.pitch)>4.5){const move=note.pitch-previous.pitch,leap=previous.pitch-before.pitch;if(!(Math.sign(move)===-Math.sign(leap)&&Math.abs(move)<=COUNTERPOINT.step))unrecovered++}
    for(const other of others){
      const partner=soundingIn(other,note.start);if(!partner)continue;
      const kind=intervalKind((note.pitch-partner.pitch)*100);
      if(strong(note.start)&&kind==='dissonant')strongDissonances++;
      const was=previous&&soundingIn(other,previous.start);
      if(was&&kind==='perfect'&&intervalKind((previous.pitch-was.pitch)*100)==='perfect'&&Math.abs(note.pitch-previous.pitch)>.05&&Math.abs(Math.abs(note.pitch-partner.pitch)%12-Math.abs(previous.pitch-was.pitch)%12)<.3)parallelPerfects++;
    }
  });
  return {strongDissonances,parallelPerfects,unrecovered,notes:line.length};
}

// A blend of the rule sets drawn for a canon or a fugue (each set's weight the square of a uniform draw, so one or two
// lead; its strictness from 0.6 to all, times `rigor`): every fugue its own counterpoint, between Fux's, Seeger's and
// Ligeti's. Each set's weight is its draw times how far its room fits the `voices` (COUNTERPOINT.room: below its least
// or above its most, the share they leave it), `classes` the collection's pitch classes. `rigor` (0 to 1) its planner's: a fugue planned whole ahead 1, an improvised one less as its planning time is less (the
// owner, 2 October 2026: "budget might also influence willingness to compromise; e.g., when improvisers play fugue-like
// textures, they're obviously not as rigorous as fully pre-composed fugues"). random: [0, 1).
export function drawnRules(random,{rigor=1,voices=2,classes=12}={}){
  const fit=name=>{const [least,most]=COUNTERPOINT.room[name],top=most==='classes'?classes:most;return Math.min(1,voices/least)*Math.min(1,top/voices)};
  const weights=Object.fromEntries(RULE_SETS.map(name=>[name,random()**2*fit(name)])),strictness=(.6+.4*random())*Math.max(0,Math.min(1,Number(rigor)));
  return {weights,strictness:+strictness.toFixed(3),rules:blendRules(weights,strictness)};
}
// A meter's strong beats in quarters (each group's start, the meter's groups in its notated notes), bar after bar.
export const strongBeats=({numerator,denominator,groups})=>{
  const beat=4/denominator,bar=numerator*beat,starts=[];let at=0;for(const group of (groups?.length?groups:[numerator])){starts.push(at);at+=group*beat}
  return t=>{const within=((t%bar)+bar)%bar;return starts.some(start=>Math.abs(within-start)<1e-6)};
};
