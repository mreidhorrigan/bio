// Groups within groups, to any depth (Musebots 3.0, docs/MUSEBOTS_3.md). The owner, 30 September 2026: "subconductors'
// sections should be nestable ad infinitum - subconductors able to direct sections of subconductors - which would give
// us a method for constructing orchestral reductions from hyperlarge ensembles (thousands of individual 'performer'
// bots)"; "constraints determined at a top level of conductor can flow downward through the layers of subconductors".
//
// A group is its members (performers, or other groups), its conductor, its manager, and the group it belongs to (its
// parent). Every bot keeps the tree as it hears it: a conductor announces its group on /broadcast/group (and a string
// section's concertmaster its section with each formation, /broadcast/group/formation); constraints for a group come on
// /broadcast/group/constraints, from a bar on.
//
// Constraints flow down: a constraint on a group binds everything within it, for the parameters each shares. The
// constraints in force for a group at a bar are its ancestors', root first, each narrowed by the next (a level below may
// narrow what it is given, never widen it), then its own (constraints.js narrowConstraints).
//
// Who it takes them from (authority.js): a group's conductor is the one elected among those heard announcing it (the
// first to have begun), constraints come from it or a conductor above, and an announcement or formation names its own
// sender; anything else is refused and kept (`refused`), with its reason. The ManageBOTs heard are kept too, for the
// lifecycle requests a bot takes (`lifecycle`).
import {checkedConstraints,narrowConstraints} from './constraints.js';
import {Election} from './election.js';
import {fromRoom,LIFECYCLE_ADDRESSES,PERSON_COORDINATOR} from './authority.js';

export const GROUP_ADDRESS='/broadcast/group';
export const CONSTRAINTS_ADDRESS='/broadcast/group/constraints';
export const FORMATION_ADDRESS='/broadcast/group/formation';
export const PRESENCE_ADDRESS='/broadcast/manage/presence';
// The most constraint messages kept for one group (the latest in force at any bar is all that is read).
const KEPT=64;

export class GroupTree{
  constructor(){this.groups=new Map;this.constraints=new Map;this.elections=new Map;this.managers=new Set;this.refused=[];this.lastRefused=null;this.bar=0;this.plans=new Map}
  // A group set or updated: {parent, conductor, manager, members, label, parameters}. A parent that would make a cycle
  // (the group within itself) is refused and the group stays where it was. -> the group, or null where refused.
  set(id,{parent,conductor,manager,members,label,parameters}={}){
    if(typeof id!=='string'||!id)return null;
    const known=this.groups.get(id)??{id,parent:null,conductor:null,manager:null,members:[],label:null,parameters:null};
    if(parent!==undefined&&parent!==null&&(parent===id||this.ancestors(parent).includes(id)))return null;
    const group={...known,...(parent!==undefined?{parent:parent??null}:{}),...(conductor!==undefined?{conductor}:{}),...(manager!==undefined?{manager}:{}),
      ...(Array.isArray(members)?{members:Object.freeze(members.map(String).slice(0,4096))}:{}),...(label!==undefined?{label}:{}),
      ...(Array.isArray(parameters)?{parameters:Object.freeze(parameters.map(String))}:{})};
    this.groups.set(id,Object.freeze(group));
    if(group.parent&&!this.groups.has(group.parent))this.groups.set(group.parent,Object.freeze({id:group.parent,parent:null,conductor:null,manager:null,members:[],label:null,parameters:null}));
    return group;
  }
  get(id){return this.groups.get(id)??null}
  // A group's ancestors, nearest first.
  ancestors(id){
    const out=[],seen=new Set([id]);let parent=this.groups.get(id)?.parent??null;
    while(parent&&!seen.has(parent)){out.push(parent);seen.add(parent);parent=this.groups.get(parent)?.parent??null}
    return out;
  }
  depth(id){return this.ancestors(id).length}
  children(id){return [...this.groups.values()].filter(group=>group.parent===id)}
  // Every group below `id`, depth-first.
  descendants(id){return this.children(id).flatMap(child=>[child,...this.descendants(child.id)])}
  // The innermost group a member (a bot's instance id, a seat) belongs to, or null.
  groupOf(member){
    let best=null;
    for(const group of this.groups.values())if(group.members.includes(member)&&(!best||this.depth(group.id)>this.depth(best.id)))best=group;
    return best;
  }
  // The group a member belongs to at `depth` from its root (0: the root), or its innermost where it is not so deep.
  groupAtDepth(member,depth){
    const inner=this.groupOf(member);if(!inner)return null;
    const chain=[...this.ancestors(inner.id)].reverse().concat(inner.id);
    return this.groups.get(chain[Math.min(depth,chain.length-1)])??null;
  }
  // Constraints heard for a group: {from, appliesAt: {bar}, constraints} (unchecked: each receiver checks them against
  // its own parameters).
  constrain(group,{from=null,bar=-1,constraints={}}={}){
    if(typeof group!=='string'||!group||!constraints||typeof constraints!=='object')return false;
    // (Said again from the same level for the same bar, as a conductor repeats itself for late joiners, or revised: one.)
    const list=(this.constraints.get(group)??[]).filter(entry=>!(entry.from===from&&entry.bar===(Number.isInteger(bar)?bar:-1)));
    list.push({from,bar:Number.isInteger(bar)?bar:-1,constraints});list.sort((a,b)=>a.bar-b.bar);
    while(list.length>KEPT)list.shift();
    this.constraints.set(group,list);if(!this.groups.has(group))this.set(group,{});
    return true;
  }
  // The latest constraints addressed to one group in force at a bar, as heard, or null.
  addressed(group,bar){return (this.constraints.get(group)??[]).filter(entry=>entry.bar<=bar).at(-1)??null}
  // The constraints in force for a group at a bar, for the parameters of `vocabulary`: its ancestors' (root first) and
  // its own, each narrowed by the next. A parameter the group does not have is not its concern (an ancestor's texture
  // binds a section that has textures); an invalid value is refused and said. -> {constraints, from (the nearest level
  // that set any), conflicts, refused} or null where nothing binds it.
  constraintsFor(group,bar,vocabulary={}){
    const chain=[...this.ancestors(group)].reverse().concat(group);
    let constraints={},from=null,any=false;const conflicts=[],refused=[];
    for(const level of chain){
      const entry=this.addressed(level,bar);if(!entry)continue;
      const relevant=Object.fromEntries(Object.entries(entry.constraints).filter(([key])=>key in vocabulary));
      let checked;
      try{checked=checkedConstraints(relevant,vocabulary)}catch(error){refused.push({level,error:error.message});continue}
      if(!Object.keys(checked).length)continue;
      const narrowed=narrowConstraints(constraints,checked,vocabulary);
      constraints=narrowed.constraints;conflicts.push(...narrowed.conflicts.map(conflict=>({...conflict,level})));
      from=entry.from??level;any=true;
    }
    return any||refused.length?{constraints:Object.freeze(constraints),from,conflicts,refused}:null;
  }
  // The conductors heard announcing a group, among whom one conducts (election.js), and the one that does at the tree's
  // bar (the latest it has heard said), or null.
  electionOf(group){return this.elections.get(group)??this.elections.set(group,new Election()).get(group)}
  conductorOf(group){return this.elections.get(group)?.elected(this.bar)??null}
  // Whether a sender conducts a group or one above it.
  conductsAt(source,group){return [group,...this.ancestors(group)].some(level=>this.conductorOf(level)===source)}
  // Whether a sender may constrain a group: the room; the group's conductor, or one above; anyone where no conductor of
  // the group or above has been heard. -> null where it may, else why not.
  constraintRefusal(source,group){
    if(fromRoom(source))return null;
    const chain=[group,...this.ancestors(group)];
    if(chain.every(level=>!this.elections.get(level)?.peers.size))return null;
    if(chain.some(level=>this.conductorOf(level)===source))return null;
    if(chain.some(level=>this.elections.get(level)?.peers.has(source)))return 'not conducting now (standing by, or gone)';
    if([...this.elections.values()].some(election=>election.peers.has(source)))return 'a conductor of another group';
    return 'not a conductor of the group or above';
  }
  refuse(message,reason){
    const value=message?.args?.[0]??{};
    this.refused.push({address:message?.address,source:message?.source??null,...(typeof value.group==='string'?{group:value.group}:{}),
      ...(typeof value.target==='string'?{target:value.target}:{}),bar:this.bar,reason});
    while(this.refused.length>64)this.refused.shift();
    this.lastRefused=message;return false;
  }
  // A conductor heard for a group, at the tree's bar: since it began (said, or first heard conducting), or standing by.
  heardConducting(group,id,{since=null,deputy=false}={}){
    const election=this.electionOf(group);
    election.hear({id,bar:this.bar,since:Number.isInteger(since)?since:null});
    if(!deputy&&!Number.isInteger(since))election.began(id,this.bar);
  }
  // A group's piece plan as its conductor last said it ({planId, revision}), where none of it has been heard none.
  planOf(group){return this.plans.get(group)??null}
  // Why constraints narrowed under a parent's plan are stale, or null: the parent's conductor has revised that plan since,
  // or said another.
  staleRefusal(under){
    if(!under||typeof under.group!=='string')return null;
    const known=this.plans.get(under.group);if(!known)return null;
    if(known.planId!==under.planId)return `under a plan of ${under.group} superseded by another`;
    return Number(known.revision)>Number(under.revision)?`under ${under.group}'s plan at revision ${under.revision}, revised to ${known.revision}`:null;
  }
  // Whether a lifecycle request is taken: from the room, from a person (the page's conductor panel), or from a ManageBOT
  // heard; from anyone until one has been (authority.js).
  lifecycle(message){
    if(!LIFECYCLE_ADDRESSES.includes(message?.address))return true;
    const value=message.args?.[0]??{};
    if(fromRoom(message.source)||value.coordinator===PERSON_COORDINATOR||!this.managers.size||this.managers.has(message.source))return true;
    return this.refuse(message,'not a manager');
  }
  // What a message says of the tree: a group announced, a string section's formation (its group, leader, parent and
  // members), constraints for a group, a ManageBOT's presence; at the bar it is heard, where the hearer knows it (`bar`).
  // A message its sender may not send is refused (`refused`). -> whether it said anything.
  hear(message,{bar}={}){
    if(Number.isInteger(bar)&&bar>this.bar)this.bar=bar;
    const value=message?.args?.[0];
    // A group's piece plan, from its conductor (where one is heard): its revision, against which constraints narrowed
    // under it are checked.
    if(message?.address==='/broadcast/plan'){
      const plan=value;if(plan?.kind!=='piece'||typeof plan.payload?.group!=='string'||!plan.planId)return false;
      const group=plan.payload.group,conductor=this.conductorOf(group);
      if(conductor&&plan.author!==conductor)return false;
      const known=this.plans.get(group);
      if(!known||known.planId!==plan.planId||Number(plan.revision)>Number(known.revision))this.plans.set(group,{planId:plan.planId,revision:Number(plan.revision)||0});
      return true;
    }
    if(message?.address===PRESENCE_ADDRESS){const id=fromRoom(message.source)?value?.instanceId:message.source;if(typeof id==='string'&&id)this.managers.add(id);return Boolean(id)}
    if(!value||typeof value!=='object'||typeof value.group!=='string')return false;
    const sender=fromRoom(message.source)?null:message.source;
    if(message.address===GROUP_ADDRESS){
      const named=value.conductor??sender;
      if(sender&&named&&named!==sender&&!this.conductsAt(sender,value.parent??this.groups.get(value.group)?.parent??value.group))return this.refuse(message,'names another as its conductor');
      if(Number.isInteger(value.appliesAt?.bar)&&value.appliesAt.bar>this.bar)this.bar=value.appliesAt.bar;
      if(typeof named==='string'&&named)this.heardConducting(value.group,named,{since:value.since,deputy:Boolean(value.deputy)});
      // (One standing by, as a group's other conductors do, is not its conductor: election.js.)
      return Boolean(this.set(value.group,{parent:value.parent??null,conductor:value.deputy?undefined:named??null,manager:value.manager,
        members:value.members,label:value.label,parameters:value.parameters}));
    }
    if(message.address===FORMATION_ADDRESS){
      const leader=value.leader??sender;
      if(sender&&leader&&leader!==sender&&!this.conductsAt(sender,value.parent??this.groups.get(value.group)?.parent??value.group))return this.refuse(message,'names another as its leader');
      if(Number.isInteger(value.appliesAt?.bar)&&value.appliesAt.bar>this.bar)this.bar=value.appliesAt.bar;
      if(typeof leader==='string'&&leader)this.heardConducting(value.group,leader);
      return Boolean(this.set(value.group,{...(value.parent!==undefined&&value.parent!==null?{parent:value.parent}:{}),conductor:leader??null,members:value.members}));
    }
    if(message.address===CONSTRAINTS_ADDRESS&&value.constraints){
      const refusal=this.constraintRefusal(sender,value.group)??this.staleRefusal(value.under);
      if(refusal)return this.refuse(message,refusal);
      return this.constrain(value.group,{from:value.from??null,bar:value.appliesAt?.bar,constraints:value.constraints});
    }
    return false;
  }
}

// A score's fold at a depth of the tree (notation/section-summary.js foldGroups): each note's member (its line, as a
// section's seat, else its voice) folded into its group at `depth` from the root. -> groupOf(note, voice) for foldGroups.
export function foldAtDepth(tree,depth){
  const order=new Map;
  return note=>{
    const group=tree.groupAtDepth(typeof note.line==='string'?note.line:note.voice,depth);if(!group)return null;
    if(!order.has(group.id))order.set(group.id,order.size);
    return {id:group.id,label:group.label??group.id,order:order.get(group.id)};
  };
}
