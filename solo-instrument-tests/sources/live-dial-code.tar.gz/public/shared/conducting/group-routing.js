// Routing by group (Musebots 3.0's fifth lack, docs/MUSEBOTS_3.md: "a bot hears its group, its ancestors, and what its
// conductor passes down"). A room delivered every message to every bot, so its traffic grew with the square of its band;
// a section's formations, constraints and announcements, the most of it, are for that section and the sections below it.
//
// A player seated in a section says which group it plays in, once (MEMBER_ADDRESS: {group}). A room (client-ensemble.js,
// server.js) keeps its groups' tree from the conductors' announcements (/broadcast/group: each group and its parent) and
// gives a message scoped to a group -- an announcement, a formation, constraints, a request -- to a player who said its
// group only where that group is the player's own or one above it. Everyone else hears everything as before: a
// conductor (which builds the tree and answers its sections), a service, an observer, a player that has not said its
// group, and a player whose group's chain to the top is not yet known.
export const MEMBER_ADDRESS='/agent/member';
const SCOPED=new Set(['/broadcast/group','/broadcast/group/formation','/broadcast/group/constraints','/broadcast/group/request']);
// The group a message is scoped to, or null where it is for the whole room.
export const scopeOf=(address,args)=>SCOPED.has(address)&&typeof args?.[0]?.group==='string'?args[0].group:null;

export class GroupRoutes{
  constructor(){this.parents=new Map}
  // A message heard: a group's announcement records its parent.
  hear(address,args){
    if(address!=='/broadcast/group')return;
    const {group,parent}=args?.[0]??{};if(typeof group==='string')this.parents.set(group,typeof parent==='string'&&parent!==group?parent:null);
  }
  // Whether a member of `groups` hears a message scoped to `group`: its own group's, or one above it. Where it said no
  // group, or its group's chain to the top is not yet known, it does.
  hears(groups,group){
    if(!Array.isArray(groups)||!groups.length||group==null)return true;
    return groups.some(own=>{
      const seen=new Set;
      for(let at=own;at!=null&&!seen.has(at);at=this.parents.get(at)){if(at===group)return true;seen.add(at);if(!this.parents.has(at))return true}
      return false;
    });
  }
}
// A seated player's word to its room, once: the group it plays in.
export function declareMember(bot,group){
  if(typeof group!=='string'||!group||bot.memberDeclared===group)return;
  bot.memberDeclared=group;try{bot.send?.(MEMBER_ADDRESS,[{group}])}catch{/* a host without a room */}
}
