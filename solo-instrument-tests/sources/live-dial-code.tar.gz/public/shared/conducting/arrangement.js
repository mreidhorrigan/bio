import {arrangementWindow} from '../arrangement.js';

// Subdivide a closing phrase on its existing bar boundaries so it covers all
// remaining whole bars. The common divisor fits both the old phrase and the end.
export function arrangementClosingPhrase(bars,preferred){
  if(!Number.isSafeInteger(bars)||bars<1||!Number.isSafeInteger(preferred)||preferred<1)throw new RangeError('Closing phrase needs positive integer bar counts');
  let a=bars,b=preferred;while(b){const next=a%b;a=b;b=next}
  return {phraseBars:a,phrases:bars/a};
}

// A placement is reserved space, not an estimate of musical activity. A conductor
// weighs its own density against the occupied fraction of a section, while clips
// themselves remain fixed. This is a musical preference, not a silence constraint.
export function arrangementDensity(density,arrangement,from,to,{room,fill}){
  if(!arrangement||!(to>from)||!Number.isFinite(from))return {density,context:null};
  const context=arrangementWindow(arrangement,Math.max(0,from),to);
  if(!context.seconds)return {density,context};
  return {density:Math.max(0,Math.min(1,density-room*context.occupiedFraction+fill*(1-context.occupiedFraction))),context};
}
