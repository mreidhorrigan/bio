// CFM-003: finite, authored notation choices for a duration multiplier. No choice is silently applied.
// A single spelling is used throughout the declared source lattice. Binary subdivisions are not tuplet levels;
// nesting once means at most two actual:normal levels. See ELONGATION_PROOF.md for the exact scope and units.
import {Q} from './canon-core.js';
import {Refused,exactOf,exactOfNumber,pythonJson,sha256} from '../bounded-exact.js';
import {dataRecord,dataArray} from './contract-data.js';

export const ELONGATION_LIMITS=Object.freeze({binaryDepth:16,tupletDepth:2,label:64,writtenUnits:4096,
  sourceDivision:65536,meterInteger:65536,groups:256,candidates:4096,positions:8192});
// candidates is a default storage budget. The grammar/shape values above remain hard input-scope limits.
export const ELONGATION_RESOURCE_DEFAULTS=Object.freeze({maxWork:100000,maxCandidates:4096,maxPositions:8192});
const owned=new WeakMap;
const fail=(message,kind='invalid-input')=>{throw new Refused(message,{kind})};
const freeze=Object.freeze;
// A caller may budget a larger finite offline plan without changing shared arithmetic's bit limits.
// Charged operations are not wall-clock time. The subtraction check prevents counter overflow.
class WorkBudget {
  constructor(limit=ELONGATION_RESOURCE_DEFAULTS.maxWork){
    if(!Number.isSafeInteger(limit)||limit<0)fail('maxWork must be a nonnegative safe integer');
    this.limit=limit;this.used=0;
  }
  charge(amount=1){
    if(!Number.isSafeInteger(amount)||amount<0)throw new Error('Invalid internal elongation work charge');
    if(amount>this.limit-this.used)fail('Exact work budget exhausted','work-budget');
    this.used+=amount;
  }
}
const abs=q=>q.cmp(0)<0?Q(0).sub(q):q;
const integer=(value,low,high,label)=>{
  if(!Number.isSafeInteger(value)||value<low||value>high)fail(`${label} must be an integer in ${low}..${high}`);
  return value;
};
const record=(value,keys,label)=>{
  if(!dataRecord(value)||Object.keys(value).some(key=>!keys.includes(key)))fail(`Invalid ${label} data fields`);
  return value;
};
// Decimal text is exact at its spelling. Q itself accepts only integer/fraction text. Owned Q values keep their
// derived-value privilege; arbitrary input records/arrays still pass the existing 256-bit raw-input boundary.
function scalar(value){
  if(typeof value==='string'&&!value.includes('/'))return Q(exactOf(value));
  if(Array.isArray(value)){
    dataArray(value,2,'Rational pair');if(value.length!==2)fail('A rational pair has two integers');
    return Q(exactOf(value));
  }
  return Q(value);
}
const nonnegative=(value,label)=>{const q=scalar(value);if(q.cmp(0)<0)fail(`${label} must be nonnegative`);return q};
const positive=(value,label)=>{const q=scalar(value);if(q.cmp(0)<=0)fail(`${label} must be positive`);return q};
const gcd=(a,b)=>{while(b)[a,b]=[b,a%b];return a};
const integerQ=q=>q.d===1n;
const state=candidate=>{const value=owned.get(candidate);if(!value)fail('Use a candidate returned by elongationRatio');return value};

function meterOf(value,budget){
  // Other normalized-meter data may be present, but none is interpreted or carried as a promise by this module.
  if(!dataRecord(value)||Object.keys(value).length>32)fail('Meter must be a bounded data record');
  const numerator=integer(value.numerator,1,ELONGATION_LIMITS.meterInteger,'Meter numerator');
  const denominator=integer(value.denominator,1,ELONGATION_LIMITS.meterInteger,'Notated denominator');
  if((denominator&(denominator-1))!==0)fail('This written-unit grammar requires a power-of-two notated denominator');
  const subdivision=integer(value.subdivision,1,ELONGATION_LIMITS.meterInteger,'Clock subdivision');
  dataArray(value.groups,ELONGATION_LIMITS.groups,'Meter groups');
  if(!value.groups.length)fail('Explicit positive meter groups are required');
  const groups=[];let sum=0;
  for(let i=0;i<value.groups.length;i++){
    budget.charge();const group=integer(value.groups[i],1,ELONGATION_LIMITS.meterInteger,'Meter group');
    groups.push(group);sum+=group;
  }
  if(sum!==numerator)fail('Meter groups must sum to its numerator in notated notes');
  let tempoUnit=null;
  if(Object.hasOwn(value,'tempoUnit')&&value.tempoUnit!==null){
    tempoUnit=integer(value.tempoUnit,1,ELONGATION_LIMITS.meterInteger,'Displayed tempo unit');
    if((tempoUnit&(tempoUnit-1))!==0)fail('Displayed tempo unit must be a power-of-two denominator');
  }
  return freeze({numerator,denominator,subdivision,groups:freeze(groups),tempoUnit});
}

// Explicit shortest-round-trip DECIMAL conversion, not the exact binary64 dyadic value and not an irrational oracle.
export function elongationFromNumber(value){
  const exact=Q(exactOfNumber(value));if(exact.cmp(1)<0)fail('Requested elongation must be at least one');
  return freeze({exact,conversion:freeze({kind:'number-as-decimal',value,exact:String(exact)})});
}

/**
 * All musical choices are required. Only maxWork/maxCandidates are optional computational limits.
 * bpm is internal NOTATED-NOTE BPM. sourceDivision G declares all relevant source positions to be j/G.
 * notation = {maxBinaryDepth,maxTupletDepth,maxActual,maxNormal,maxWrittenUnits,
 *             weights:{binary,tuplet,label,tie}}.
 * Return status complete/empty only after exhaustive bounded enumeration; a spent resource throws Refused.
 */
export function elongationRatio(spec){
  record(spec,['E','meter','bpm','sourceDivision','minRatio','maxRatio','notation','maxComplexity',
    'complexityWeight','maxWork','maxCandidates'],'elongation specification');
  const budget=new WorkBudget(spec.maxWork),cap=spec.maxCandidates===undefined?ELONGATION_RESOURCE_DEFAULTS.maxCandidates:
    integer(spec.maxCandidates,1,Number.MAX_SAFE_INTEGER,'Candidate cap');
  const E=positive(spec.E,'Requested elongation'),bpm=positive(spec.bpm,'Internal notated-note BPM');
  const minimum=positive(spec.minRatio,'Minimum ratio'),maximum=positive(spec.maxRatio,'Maximum ratio');
  if(E.cmp(1)<0||minimum.cmp(1)<0||minimum.cmp(maximum)>0)fail('Elongation and ratio bounds must be at least one, with minRatio <= maxRatio');
  const G=integer(spec.sourceDivision,1,ELONGATION_LIMITS.sourceDivision,'Source division'),meter=meterOf(spec.meter,budget);
  const notation=record(spec.notation,['maxBinaryDepth','maxTupletDepth','maxActual','maxNormal','maxWrittenUnits','weights'],'notation');
  const B=integer(notation.maxBinaryDepth,0,ELONGATION_LIMITS.binaryDepth,'Binary depth');
  const D=integer(notation.maxTupletDepth,0,ELONGATION_LIMITS.tupletDepth,'Tuplet depth');
  const A=integer(notation.maxActual,1,ELONGATION_LIMITS.label,'Actual-label bound');
  const N=integer(notation.maxNormal,1,ELONGATION_LIMITS.label,'Normal-label bound');
  const M=integer(notation.maxWrittenUnits,1,ELONGATION_LIMITS.writtenUnits,'Written-atom bound');
  const weights=record(notation.weights,['binary','tuplet','label','tie'],'complexity weights'),w={};
  for(const key of ['binary','tuplet','label','tie'])w[key]=nonnegative(weights[key],`${key} complexity weight`);
  const C=nonnegative(spec.maxComplexity,'Complexity cap'),lambda=nonnegative(spec.complexityWeight,'Complexity tradeoff');
  const labels=[];
  if(D)for(let actual=1;actual<=A;actual++)for(let normal=1;normal<=N;normal++){
    budget.charge();if(actual===normal||gcd(actual,normal)!==1)continue;
    labels.push(freeze({actual,normal,factor:Q(normal).div(actual),cost:w.tuplet.add(w.label.mul(actual+normal))}));
  }
  const definition=freeze({grammar:'uniform-tied-atoms-v1',E:String(E),bpm:String(bpm),meter,sourceDivision:G,
    minRatio:String(minimum),maxRatio:String(maximum),maxComplexity:String(C),complexityWeight:String(lambda),
    notation:freeze({maxBinaryDepth:B,maxTupletDepth:D,maxActual:A,maxNormal:N,maxWrittenUnits:M,
      weights:freeze({binary:String(w.binary),tuplet:String(w.tuplet),label:String(w.label),tie:String(w.tie)})})});
  const byRatio=new Map;let visitedSpellings=0;
  // Levels are ordered. Equal arithmetic products may have different written nesting order; keeping the first
  // minimum-cost witness is a deterministic representation convention, never a claim of preferred engraving.
  function visit(levels,factor,levelCost){
    budget.charge();if(levelCost.cmp(C)>0)return;
    for(let b=0;b<=B;b++){
      budget.charge();const baseCost=levelCost.add(w.binary.mul(b));if(baseCost.cmp(C)>0)continue;
      const binary=Q(1).div(1n<<BigInt(b)),quantum=binary.mul(factor),step=Q(G).mul(quantum);
      for(let m=1;m<=M;m++){
        budget.charge();visitedSpellings++;
        const complexity=baseCost.add(w.tie.mul(m-1));if(complexity.cmp(C)>0)break;
        const ratio=step.mul(m);if(ratio.cmp(maximum)>0)break;if(ratio.cmp(minimum)<0)continue;
        const key=String(ratio),previous=byRatio.get(key);
        if(previous&&previous.complexity.cmp(complexity)<=0)continue;
        if(!previous&&byRatio.size>=cap)fail('Distinct-ratio candidate cap exhausted','candidate-budget');
        const residual=E.sub(ratio),error=abs(residual),objective=error.add(lambda.mul(complexity));
        byRatio.set(key,{ratio,residual,error,complexity,objective,b,m,quantum,
          levels:freeze(levels.map(label=>freeze({actual:label.actual,normal:label.normal})))});
      }
    }
    if(levels.length<D)for(const label of labels){
      budget.charge();visit([...levels,label],factor.mul(label.factor),levelCost.add(label.cost));
    }
  }
  visit([],Q(1),Q(0));
  budget.charge(byRatio.size);const raw=[...byRatio.values()];
  raw.sort((a,b)=>{budget.charge();return a.ratio.cmp(b.ratio)});
  budget.charge(raw.length);const paretoOrder=[...raw];
  paretoOrder.sort((a,b)=>{budget.charge();return a.error.cmp(b.error)||a.complexity.cmp(b.complexity)||a.ratio.cmp(b.ratio)});
  const nondominated=new Set;let priorCost=null;
  for(let i=0;i<paretoOrder.length;){
    budget.charge();const first=paretoOrder[i];let end=i+1;
    while(end<paretoOrder.length){budget.charge();if(!paretoOrder[end].error.eq(first.error))break;end++}
    if(priorCost===null||first.complexity.cmp(priorCost)<0){
      for(let j=i;j<end;j++){budget.charge();if(!paretoOrder[j].complexity.eq(first.complexity))break;nondominated.add(paretoOrder[j])}
      priorCost=first.complexity;
    }
    i=end;
  }
  let best=null;for(const row of raw){budget.charge();if(best===null||row.objective.cmp(best)<0)best=row.objective}
  const candidates=[],optima=[],pareto=[];
  for(const row of raw){
    budget.charge();const ticksPerStep=row.quantum.mul(row.m).mul(meter.subdivision);
    const candidate=freeze({p:String(row.ratio.n),q:String(row.ratio.d),ratio:String(row.ratio),
      residual:String(row.residual),absoluteError:String(row.error),complexity:String(row.complexity),objective:String(row.objective),
      spelling:freeze({binaryDepth:row.b,binaryUnitWholeNotes:String(Q(1).div(BigInt(meter.denominator)<<BigInt(row.b))),
        levels:row.levels,writtenUnits:row.m,quantumNotatedNotes:String(row.quantum),sourceDivision:G}),
      clock:freeze({ticksPerSourceStep:String(ticksPerStep),allSourceStepsOnTicks:integerQ(ticksPerStep),
        sourceStepsToTickReturn:String(ticksPerStep.d),internalBpm:String(bpm.div(row.ratio)),
        speedRatio:freeze({p:String(row.ratio.d),q:String(row.ratio.n)}),
        sameMeterBarReturn:freeze({sourceBars:String(row.ratio.d),sharedBars:String(row.ratio.n)})})});
    owned.set(candidate,{...row,E,bpm,G,meter});candidates.push(candidate);
    if(row.objective.eq(best))optima.push(candidate);if(nondominated.has(row))pareto.push(candidate);
  }
  const encoded=pythonJson(definition);budget.charge(1+Math.ceil(encoded.length/64));
  return freeze({status:candidates.length?'complete':'empty',scope:'finite-notation-grammar',definition,
    hash:sha256(encoded),candidates:freeze(candidates),optima:freeze(optima),pareto:freeze(pareto),
    minimumObjective:best===null?null:String(best),generatedLabels:labels.length,visitedSpellings,workUsed:budget.used,
    resources:freeze({maxWork:budget.limit,maxCandidates:cap})});
}

// Check every supplied onset AND release against the common-anchor-relative contract. These finite checks do not
// discover omitted source events, bind a live clock revision, or infer a lattice from rounded seconds.
export function auditElongationPositions(spec){
  record(spec,['candidate','positions','maxWork','maxPositions'],'elongation position audit');
  const row=state(spec.candidate),budget=new WorkBudget(spec.maxWork);
  const maxPositions=spec.maxPositions===undefined?ELONGATION_RESOURCE_DEFAULTS.maxPositions:
    integer(spec.maxPositions,0,ELONGATION_LIMITS.positions,'Position cap');
  dataArray(spec.positions,ELONGATION_LIMITS.positions,'Source positions');
  if(spec.positions.length>maxPositions)fail('Source position audit cap exhausted','position-budget');
  budget.charge(spec.positions.length);
  const outsideSource=[],outsideQuantum=[],outsideTicks=[];
  for(let i=0;i<spec.positions.length;i++){
    budget.charge();const at=nonnegative(spec.positions[i],'Source position'),target=at.mul(row.ratio);
    if(!integerQ(at.mul(row.G)))outsideSource.push(i);
    if(!integerQ(target.div(row.quantum)))outsideQuantum.push(i);
    if(!integerQ(target.mul(row.meter.subdivision)))outsideTicks.push(i);
  }
  return freeze({scope:'supplied-common-anchor-relative-positions',checked:spec.positions.length,
    sourceLattice:outsideSource.length===0,writtenQuantum:outsideQuantum.length===0,baseClock:outsideTicks.length===0,
    outsideSource:freeze(outsideSource),outsideQuantum:freeze(outsideQuantum),outsideTicks:freeze(outsideTicks),workUsed:budget.used,
    resources:freeze({maxWork:budget.limit,maxPositions})});
}

// The exact signed endpoint difference at L is (r-E)L. The absolute expression bounds every prefix in [0,L].
// A common hard cut clamps both endpoints to the SAME nonnegative shared-note horizon; it cannot increase error.
// No claim is made that truncation preserves the same audible event set, full durations or notation grouping.
export function elongationDrift(spec){
  record(spec,['candidate','sourceLength','truncateAt'],'elongation drift');const row=state(spec.candidate);
  const length=nonnegative(spec.sourceLength,'Source length'),requestedEnd=row.E.mul(length),chosenEnd=row.ratio.mul(length);
  const signed=chosenEnd.sub(requestedEnd),bound=abs(signed),secondsPerNote=Q(60).div(row.bpm);
  let truncation=null;
  if(Object.hasOwn(spec,'truncateAt')){
    const cap=nonnegative(spec.truncateAt,'Shared-note truncation horizon');
    const a=requestedEnd.cmp(cap)>0?cap:requestedEnd,b=chosenEnd.cmp(cap)>0?cap:chosenEnd;
    truncation=freeze({sharedNoteHorizon:String(cap),requestedEnd:String(a),chosenEnd:String(b),
      signedNotatedNotes:String(b.sub(a)),absoluteNotatedNotes:String(abs(b.sub(a)))});
  }
  return freeze({sourceLength:String(length),requestedEnd:String(requestedEnd),chosenEnd:String(chosenEnd),
    signedNotatedNotes:String(signed),maximumPrefixNotatedNotes:String(bound),
    signedSeconds:String(signed.mul(secondsPerNote)),maximumPrefixSeconds:String(bound.mul(secondsPerNote)),
    secondsScope:'constant-internal-notated-note-BPM',truncation});
}
