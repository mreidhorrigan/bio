// EC14/DC09: finite-horizon AND/OR viability in a caller-declared symbolic model.
// This does not generate truthful goal/preparation evidence, acquire authority, or reserve resources.
import {dataArray,dataRecord} from './contract-data.js';
import {Refused,pythonJson,sha256} from '../bounded-exact.js';

export const CONTINUATION_LIMITS=Object.freeze({states:256,actions:2048,outcomes:8192,
  actionsPerState:64,outcomesPerAction:64,resources:8,predicates:32,eventIds:4096,
  horizon:256,text:1048576,hashChars:2097152,string:256,defaultNodes:10000,defaultWork:100000});
const freeze=Object.freeze,scope='declared-finite-horizon-adversarial-outcome-model';
const refuse=(message,kind='invalid-input')=>{throw new Refused(message,{kind})};
function fields(value,keys){
  if(!dataRecord(value)||Object.keys(value).length!==keys.length||keys.some(k=>!Object.hasOwn(value,k)))
    refuse('Unexpected or missing continuation fields');
  return value;
}
function integer(value,maximum=Number.MAX_SAFE_INTEGER){
  if(!Number.isSafeInteger(value)||value<0||value>maximum)refuse('Expected a bounded nonnegative safe integer');
  return value;
}
function text(value,state){
  if(typeof value!=='string'||!value.length||value.length>CONTINUATION_LIMITS.string)refuse('Invalid continuation text');
  if(value.length>CONTINUATION_LIMITS.text-state.chars)refuse('Continuation text budget','work-budget');
  state.chars+=value.length;state.charge();return value;
}
const verdict=value=>{
  if(!['PASS','FAIL','UNKNOWN'].includes(value))refuse('Declare PASS, FAIL or UNKNOWN evidence');return value;
};
const boolean=value=>{if(typeof value!=='boolean')refuse('Completeness must be explicit');return value};
function strings(raw,maximum,state){
  dataArray(raw,maximum,'Continuation identities');const out=[],seen=new Set;
  for(let i=0;i<raw.length;i++){
    const v=text(raw[i],state);if(seen.has(v))refuse('Duplicate continuation identity');seen.add(v);out.push(v);
  }
  return freeze(out);
}
function integers(raw,length,state){
  dataArray(raw,CONTINUATION_LIMITS.resources,'Continuation resource vector');
  if(raw.length!==length)refuse('Resource vector dimension');
  const out=[];for(let i=0;i<length;i++){state.charge();out.push(integer(raw[i]))}return freeze(out);
}
function normalize(spec,state){
  fields(spec,['id','revision','referenceHash','lockedEventIds','goalPredicate','requiredPredicates',
    'resources','start','horizon','states']);
  const id=text(spec.id,state),revision=integer(spec.revision),referenceHash=text(spec.referenceHash,state);
  if(!/^[0-9a-f]{64}$/.test(referenceHash))refuse('Reference hash must be SHA-256');
  const lockedEventIds=strings(spec.lockedEventIds,CONTINUATION_LIMITS.eventIds,state);
  const goalPredicate=text(spec.goalPredicate,state),requiredPredicates=strings(spec.requiredPredicates,CONTINUATION_LIMITS.predicates,state);
  const required=new Set(requiredPredicates),locked=new Set(lockedEventIds);
  dataArray(spec.resources,CONTINUATION_LIMITS.resources,'Continuation resources');
  const resources=[],resourceNames=new Set;
  for(let i=0;i<spec.resources.length;i++){
    state.charge();const row=fields(spec.resources[i],['id','unit','remaining']),name=text(row.id,state);
    if(resourceNames.has(name))refuse('Resource identities must be unique');resourceNames.add(name);
    resources.push(freeze({id:name,unit:text(row.unit,state),remaining:integer(row.remaining)}));
  }
  const start=text(spec.start,state),horizon=integer(spec.horizon,CONTINUATION_LIMITS.horizon);
  dataArray(spec.states,CONTINUATION_LIMITS.states,'Continuation states');
  if(!spec.states.length)refuse('Declare at least one continuation state');
  const nodes=[],byId=new Map;let actionCount=0,outcomeCount=0;
  for(let i=0;i<spec.states.length;i++){
    state.charge();const raw=fields(spec.states[i],['id','goal','decisionsComplete','decisions']),name=text(raw.id,state);
    if(byId.has(name))refuse('State identities must be unique');byId.set(name,i);
    dataArray(raw.decisions,CONTINUATION_LIMITS.actionsPerState,'Continuation decisions');
    const decisions=[],decisionIds=new Set;
    for(let j=0;j<raw.decisions.length;j++){
      state.charge();if(++actionCount>CONTINUATION_LIMITS.actions)refuse('Action scope limit','scope-budget');
      const d=fields(raw.decisions[j],['id','costs','changedEventIds','checks','outcomesComplete','outcomes']),did=text(d.id,state);
      if(decisionIds.has(did))refuse('Decision identities must be unique within a state');decisionIds.add(did);
      const costs=integers(d.costs,resources.length,state),changedEventIds=strings(d.changedEventIds,CONTINUATION_LIMITS.eventIds,state);
      dataArray(d.checks,CONTINUATION_LIMITS.predicates,'Continuation evidence');
      const checks=[],checked=new Set;
      for(let k=0;k<d.checks.length;k++){
        state.charge();const check=fields(d.checks[k],['id','status']),cid=text(check.id,state);
        if(!required.has(cid)||checked.has(cid))refuse('Evidence must name a unique required predicate');checked.add(cid);
        checks.push(freeze({id:cid,status:verdict(check.status)}));
      }
      const outcomes=strings(d.outcomes,CONTINUATION_LIMITS.outcomesPerAction,state);
      if(!outcomes.length)refuse('An action needs at least one declared possible outcome');
      outcomeCount+=outcomes.length;if(outcomeCount>CONTINUATION_LIMITS.outcomes)refuse('Outcome scope limit','scope-budget');
      decisions.push(freeze({id:did,costs,changedEventIds,checks:freeze(checks),outcomesComplete:boolean(d.outcomesComplete),outcomes}));
    }
    nodes.push(freeze({id:name,goal:verdict(raw.goal),decisionsComplete:boolean(raw.decisionsComplete),decisions:freeze(decisions)}));
  }
  if(!byId.has(start))refuse('Unknown starting state');
  for(const node of nodes)for(const action of node.decisions)for(const target of action.outcomes){
    state.charge();if(!byId.has(target))refuse('Unknown outcome state');
  }
  const snapshot=freeze({id,revision,referenceHash,lockedEventIds,goalPredicate,requiredPredicates,
    resources:freeze(resources),start,horizon,states:freeze(nodes)});
  const encoded=pythonJson(snapshot);
  if(encoded.length>CONTINUATION_LIMITS.hashChars)refuse('Continuation hash budget','work-budget');
  state.charge(1+Math.ceil(encoded.length/64));state.modelHash=sha256(encoded);
  return {snapshot,byId,locked,required,hash:state.modelHash};
}
function run(options,body){
  let state;
  try{
    if(!dataRecord(options)||Object.keys(options).some(k=>!['maxWork','maxNodes'].includes(k)))refuse('Only maxWork and maxNodes are supported');
    const work=Object.hasOwn(options,'maxWork')?integer(options.maxWork):CONTINUATION_LIMITS.defaultWork;
    const nodes=Object.hasOwn(options,'maxNodes')?integer(options.maxNodes):CONTINUATION_LIMITS.defaultNodes;
    state={chars:0,workUsed:0,nodesVisited:0,modelHash:null,maxNodes:nodes,
      charge(n=1){integer(n);if(n>work-this.workUsed)refuse('Continuation work budget','work-budget');this.workUsed+=n},
      node(){if(this.nodesVisited===nodes)refuse('Continuation node budget','node-budget');this.nodesVisited++;this.charge()}};
    const result=body(state);
    return freeze({...result,scope,modelHash:state.modelHash,workUsed:state.workUsed,nodesVisited:state.nodesVisited});
  }catch(error){
    if(!(error instanceof Refused))throw error;
    return freeze({status:'UNKNOWN',reason:freeze({kind:error.kind,message:error.message}),scope,
      modelHash:state?.modelHash??null,workUsed:state?.workUsed??0,nodesVisited:state?.nodesVisited??0});
  }
}
const keyOf=(index,horizon,remaining)=>`${index}:${horizon}:${remaining.join(',')}`;
function admission(model,action,remaining,state){
  let status='PASS';
  for(const id of action.changedEventIds){state.charge();if(model.locked.has(id))return 'FAIL'}
  for(let i=0;i<remaining.length;i++){state.charge();if(action.costs[i]>remaining[i])return 'FAIL'}
  const checks=new Map(action.checks.map(c=>[c.id,c.status]));
  for(const id of model.required){state.charge();const value=checks.get(id);if(value==='FAIL')return 'FAIL';if(value!=='PASS')status='UNKNOWN'}
  return status;
}

/** Does a reactive policy reach the declared goal within the horizon for every listed possible outcome?
 * VIABLE includes a checkable policy; INFEASIBLE is scoped to the complete declared finite model.
 * Search order is the caller's action order, not an implicit objective or a claim of optimality. */
export function continuationViability(spec,options={}){
  return run(options,state=>{
    const model=normalize(spec,state),{snapshot:s}=model,memo=new Map;
    function visit(index,horizon,remaining){
      state.charge();const key=keyOf(index,horizon,remaining);if(memo.has(key))return memo.get(key);
      state.node();const node=s.states[index],entry={key,index,horizon,remaining,status:'UNKNOWN',action:null,next:[]};
      if(node.goal==='PASS'){entry.status='VIABLE';memo.set(key,entry);return entry}
      if(horizon===0){entry.status=node.goal==='FAIL'?'INFEASIBLE':'UNKNOWN';memo.set(key,entry);return entry}
      let unknown=node.goal==='UNKNOWN'||!node.decisionsComplete;
      for(const action of node.decisions){
        state.charge();const allowed=admission(model,action,remaining,state);if(allowed==='FAIL')continue;
        let uncertain=allowed==='UNKNOWN'||!action.outcomesComplete,bad=false;
        const after=freeze(remaining.map((value,i)=>value-action.costs[i])),next=[];
        for(const target of action.outcomes){
          state.charge();const child=visit(model.byId.get(target),horizon-1,after);next.push(child.key);
          if(child.status==='INFEASIBLE'){bad=true;break}
          if(child.status==='UNKNOWN')uncertain=true;
        }
        if(bad)continue;
        if(uncertain){unknown=true;continue}
        entry.status='VIABLE';entry.action=action.id;entry.next=next;memo.set(key,entry);return entry;
      }
      entry.status=unknown?'UNKNOWN':'INFEASIBLE';memo.set(key,entry);return entry;
    }
    const remaining=freeze(s.resources.map(r=>r.remaining));
    const root=visit(model.byId.get(s.start),s.horizon,remaining);
    if(root.status!=='VIABLE')return {status:root.status,policy:null,snapshot:s,
      reason:root.status==='UNKNOWN'?'Unresolved goal/admission evidence or incomplete catalogues':'No policy in the declared finite model reaches the endpoint within the horizon and balances'};
    const rows=[],seen=new Set;
    function collect(key){
      state.charge();if(seen.has(key))return;seen.add(key);const row=memo.get(key);
      rows.push(freeze({key,nodeId:s.states[row.index].id,horizon:row.horizon,remaining:row.remaining,
        actionId:row.action,next:freeze([...row.next])}));
      for(const child of row.next)collect(child);
    }
    collect(root.key);
    return {status:'VIABLE',snapshot:s,policy:freeze({kind:'finite-continuation-policy',modelHash:model.hash,
      rootKey:root.key,rows:freeze(rows)}),reason:'A finite conditional policy covers every declared outcome'};
  });
}

/** Independent policy checker: validates supplied choices and complete successor coverage without searching. */
export function auditContinuationPolicy(spec,certificate,options={}){
  return run(options,state=>{
    const model=normalize(spec,state),{snapshot:s}=model;
    fields(certificate,['kind','modelHash','rootKey','rows']);
    if(certificate.kind!=='finite-continuation-policy')refuse('Unknown continuation certificate kind');
    const hash=text(certificate.modelHash,state),rootKey=text(certificate.rootKey,state),rows=new Map;
    const reject=reason=>({status:'FAIL',reason});
    dataArray(certificate.rows,state.maxNodes,'Continuation policy rows');
    for(let i=0;i<certificate.rows.length;i++){
      state.charge();const row=fields(certificate.rows[i],['key','nodeId','horizon','remaining','actionId','next']);
      const key=text(row.key,state),nodeId=text(row.nodeId,state);
      if(rows.has(key))refuse('Duplicate policy row key');
      rows.set(key,freeze({key,nodeId,horizon:integer(row.horizon,CONTINUATION_LIMITS.horizon),
        remaining:integers(row.remaining,s.resources.length,state),actionId:row.actionId===null?null:text(row.actionId,state),
        next:strings(row.next,CONTINUATION_LIMITS.outcomesPerAction,state)}));
    }
    if(hash!==model.hash)return reject('Policy belongs to another model revision');
    const remaining=s.resources.map(r=>r.remaining),expectedRoot=keyOf(model.byId.get(s.start),s.horizon,remaining);
    if(rootKey!==expectedRoot)return reject('Policy changes the initial state, horizon or resources');
    const seen=new Set;
    function check(index,horizon,balances){
      state.charge();const key=keyOf(index,horizon,balances);if(seen.has(key))return null;
      state.node();const row=rows.get(key),node=s.states[index];
      if(!row||row.nodeId!==node.id||row.horizon!==horizon||row.remaining.some((x,i)=>x!==balances[i]))return 'Missing or altered policy state';
      seen.add(key);
      if(row.actionId===null)return node.goal==='PASS'&&row.next.length===0?null:'A stopping row needs known goal evidence and no successors';
      if(horizon===0)return 'A transition exceeds the horizon';
      const action=node.decisions.find(d=>d.id===row.actionId);
      if(!action)return 'Policy selects an undeclared action';
      // Recheck the chosen action directly; do not trust planner admission or infer required roles from policy rows.
      for(const id of action.changedEventIds){state.charge();if(model.locked.has(id))return 'Policy changes a protected event'}
      for(let i=0;i<balances.length;i++){state.charge();if(action.costs[i]>balances[i])return 'Policy overspends a resource'}
      for(const id of s.requiredPredicates){
        state.charge();if(!action.checks.some(c=>c.id===id&&c.status==='PASS'))return 'Missing or failing required action evidence';
      }
      if(!action.outcomesComplete)return 'Possible outcomes are not complete';
      const after=balances.map((value,i)=>value-action.costs[i]);
      const next=action.outcomes.map(id=>keyOf(model.byId.get(id),horizon-1,after));
      if(row.next.length!==next.length||next.some((key,i)=>row.next[i]!==key))return 'Policy omits or substitutes an expected outcome';
      for(const target of action.outcomes){const failed=check(model.byId.get(target),horizon-1,after);if(failed)return failed}
      return null;
    }
    const failed=check(model.byId.get(s.start),s.horizon,remaining);
    if(failed)return reject(failed);
    if(seen.size!==rows.size)return reject('Policy contains unreachable extra rows');
    return {status:'PASS',conclusion:'VIABLE',reason:'All policy paths satisfy the declared finite model',snapshot:s};
  });
}
