// Meters by group (docs/MUSEBOTS_3.md, the fourth lack: "meter and tempo relations as per-group plan layers, the transport
// keeping the root's"): for a section of the form, a section of the orchestra in a meter of its own over the band's
// shared tick, a stream (shared/rhythm-vocabulary.js streamOf: its bars counted in its own cycle), while the transport
// keeps the band's. Its numerator is one whose bars meet the band's at the section's end -- a divisor of the section's
// beats, between half and twice the band's numerator, neither a divisor nor a multiple of it -- so that the two cross,
// and meet where the plan says (seven against four over twenty-eight beats); its denominator and subdivision the band's,
// its groups drawn as the meter space draws them, and the levels they nest in (meter-space.js drawNesting). Where the form contrasts or develops, more likely than where it establishes or
// returns (GROUP_METERS.chance, authored); one section at a time, so the cross-meter is heard against the rest.
import {drawNesting,nestingGroups,nestingLevels} from '../meter-space.js';
import {tempoRange} from '../tempo-range.js';

export const GROUP_METERS=Object.freeze({
  chance:Object.freeze({contrast:.6,develop:.6,climax:.5,'complex-return':.3,other:.25,establish:.1,return:.1}),
  // Or a tempo of its own, in the band's meter: this share of the sections given their own time take a relation instead
  // of a cross-meter (ours); its ratio p:q (p of its beats to q of the band's) any in lowest terms whose bars meet the
  // band's at the section's end (q divides its bars) and whose tempo is one a clock plays (tempo-range.js), the simpler
  // likelier (weighted by (p + q) to the -3: the larger, however many, a quarter of the draws or so): no list of ratios
  // (the owner, 2 October 2026: "NO HARDCODING OF TUPLETS").
  tempo:.4,
});
const gcd=(a,b)=>b?gcd(b,a%b):a;
// The ratios a section of `bars` bars may play at, at `bpm` in `meter`: every p:q in lowest terms, p not q, q dividing
// its bars, its tempo (bpm p/q) within the clock's range.
export function tempoRatios(bars,{bpm=null,meter=null}={}){
  const [low,high]=tempoRange(meter),out=[];
  for(let q=1;q<=bars;q++){
    if(bars%q!==0)continue;
    // (Its p from the tempo range, bpm p/q within it; where the tempo is not known, within an octave of the band's.)
    const least=bpm>0?Math.ceil(low*q/bpm-1e-9):Math.ceil(q/2),most=bpm>0?Math.floor(high*q/bpm+1e-9):2*q;
    for(let p=Math.max(1,least);p<=most;p++)if(p!==q&&gcd(p,q)===1)out.push(Object.freeze([p,q]));
  }
  return out;
}
// The numerators a section of `bars` bars of `numerator` units may be counted in instead, meeting its end.
export function crossNumerators(numerator,bars){
  const total=bars*numerator,out=[];
  // (Neither a divisor nor a multiple of the band's numerator: half or double bars are the band's own, not across it.)
  for(let n=Math.max(2,Math.ceil(numerator/2));n<=2*numerator;n++)if(numerator%n!==0&&n%numerator!==0&&total%n===0)out.push(n);
  return out;
}
// A section's meters by group: {[group]: meter} for one of `sections` (the groups that count their own meters), or {}.
// `section`: the form's ({role, numerator, denominator, subdivision, phraseBars}); random: [0, 1).
// A meter given a tempo relation carries it ({..., relation: {ratio: [p, q]}}: the stream's, framework/agent.js
// relateStream).
// (A bar's groups and the levels they nest in, as a meter carries them: drawn, or the section's own.)
const grouped=(numerator,random,given=null)=>{
  if(given?.groups)return {groups:Object.freeze([...given.groups]),...(given.sections?{sections:given.sections}:{})};
  const nesting=drawNesting(numerator,random),levels=nestingLevels(nesting);
  return {groups:Object.freeze(nestingGroups(nesting)),...(levels.length?{sections:Object.freeze(levels.map(level=>Object.freeze(level)))}:{})};
};
export function groupMeters(section,{bars,sections,random}){
  if(!sections.length||!(random()<(GROUP_METERS.chance[section.role]??GROUP_METERS.chance.other)))return {};
  const numerators=crossNumerators(section.numerator,bars),ratios=tempoRatios(bars,{bpm:section.tempo?.targetBpm,meter:section});
  const tempo=ratios.length&&(random()<GROUP_METERS.tempo||!numerators.length);if(!tempo&&!numerators.length)return {};
  const group=sections[Math.floor(random()*sections.length)],base={denominator:section.denominator,subdivision:section.subdivision,phraseBars:section.phraseBars};
  if(tempo){
    const weight=([p,q])=>(p+q)**-3;
    let draw=random()*ratios.reduce((sum,r)=>sum+weight(r),0),ratio=ratios.at(-1);for(const r of ratios){draw-=weight(r);if(draw<=0){ratio=r;break}}
    return {[group]:Object.freeze({...base,numerator:section.numerator,...grouped(section.numerator,random,section),relation:Object.freeze({ratio:Object.freeze([...ratio])})})};
  }
  const numerator=numerators[Math.floor(random()*numerators.length)];
  return {[group]:Object.freeze({...base,numerator,...grouped(numerator,random)})};
}
