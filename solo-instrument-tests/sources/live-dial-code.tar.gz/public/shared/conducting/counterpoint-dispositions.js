// CFM-019 / GC14: certify every member of a separately promised finite disposition inventory.
// Actual transformed sonorities, exact registers and a genuine whole profile are checked; no K-d crossing rule.
import {Q,soundingSlices} from './canon-core.js';
import {compilePitchOperations} from './pitch-spaces.js';
import {piecewiseTime} from './canon-time.js';
import {decomposeCounterpointProfile} from './counterpoint-profile.js';
import {dataArray,dataRecord} from './contract-data.js';
import {Budget,Refused,EXACT_LIMITS,exactOf,exactText,compare,sub,mul,div,ONE,pythonJson,sha256} from '../bounded-exact.js';

export const DISPOSITION_LIMITS=Object.freeze({members:16,parts:16,sources:32,sourceEvents:128,environmentEvents:256,
  materialEvents:4096,contexts:128,knots:128,operations:64,dependencies:64,snapshotNodes:65536,
  textChars:2000000,hashChars:2000000,depth:12,defaultWork:100000,maxWork:500000,profileWork:20000,sliceWork:10000});
const freeze=Object.freeze,owned=new WeakMap,scope='complete-declared-finite-disposition-family';
const fail=(message,kind='invalid-input')=>{throw new Refused(message,{kind})};
function fields(value,keys){if(!dataRecord(value)||Object.keys(value).length!==keys.length||keys.some(key=>!Object.hasOwn(value,key)))fail('Unexpected or missing disposition fields');return value}
function optionsOf(value,keys){if(!dataRecord(value)||Object.keys(value).some(key=>!keys.includes(key)))fail('Unknown disposition option');return value}
function name(value){if(typeof value!=='string'||!value.length||value.length>256)fail('A bounded identity is required');return value}
function count(value,max=Number.MAX_SAFE_INTEGER){if(!Number.isSafeInteger(value)||value<0||value>max)fail('Invalid bounded integer');return value}
function boolean(value){if(typeof value!=='boolean')fail('Declare completeness explicitly');return value}
function unique(seen,id){if(seen.has(id))fail('Duplicate disposition identity');seen.add(id);return id}
function snapshot(value,state,frame={nodes:0,chars:0},depth=0,seen=new Set,stringCap=2048){
  state.budget.charge();if(++frame.nodes>DISPOSITION_LIMITS.snapshotNodes)fail('Disposition snapshot-node cap','work-budget');
  if(value===null||typeof value==='boolean')return value;
  if(typeof value==='number'){if(!Number.isFinite(value))fail('Nonfinite metadata');return Object.is(value,-0)?0:value}
  if(typeof value==='string'){if(value.length>stringCap||value.length>DISPOSITION_LIMITS.textChars-frame.chars)fail('Disposition text cap','work-budget');frame.chars+=value.length;return value}
  if(depth>=DISPOSITION_LIMITS.depth||seen.has(value))fail('Cyclic or deep disposition data');seen.add(value);let out;
  if(Array.isArray(value)){dataArray(value,DISPOSITION_LIMITS.snapshotNodes,'Disposition data');out=[];for(const item of value)out.push(snapshot(item,state,frame,depth+1,seen,stringCap))}
  else{if(!dataRecord(value)||Object.keys(value).length>256)fail('Metadata must be ordinary bounded data');out={};for(const key of Object.keys(value)){name(key);Object.defineProperty(out,key,{value:snapshot(value[key],state,frame,depth+1,seen,stringCap),enumerable:true})}}
  seen.delete(value);return freeze(out);
}
function integer(value,bits){
  if(typeof value==='bigint'){const boundary=1n<<BigInt(bits);if(value<=-boundary||value>=boundary)fail('Raw rational component bit cap','arithmetic-budget');return value}
  if(!Number.isSafeInteger(value))fail('Use safe integers or exact rational spellings');return BigInt(value);
}
function rational(value,state,bits=256){
  state.budget.charge();let input;
  if(typeof value==='number'||typeof value==='bigint')input=integer(value,bits);
  else if(typeof value==='string'){
    if(!value.length||value.length>(bits===256?160:6000))fail('Rational spelling length cap');const pair=value.match(/^([+-]?[0-9]+)\/([0-9]+)$/);
    if(pair)input={n:integer(BigInt(pair[1]),bits),d:integer(BigInt(pair[2]),bits)};
    else{
      const decimal=value.match(/^([+-]?)(?:([0-9]+)(?:\.([0-9]*))?|\.([0-9]+))(?:[eE]([+-]?[0-9]{1,3}))?$/);if(!decimal)fail('Invalid rational spelling');
      const [,sign,whole='',part=decimal[4]??'',,exponent='0']=decimal;if(Math.abs(Number(exponent))>256)fail('Exponent cap','arithmetic-budget');
      const shift=Number(exponent)-part.length,digits=integer(BigInt((whole+part)||'0')*(sign==='-'?-1n:1n),bits);
      if(shift<0&&-shift>=bits||shift>=bits&&digits!==0n)fail('Expanded decimal component cap','arithmetic-budget');
      input={n:integer(shift>0&&digits!==0n?digits*10n**BigInt(shift):digits,bits),d:integer(shift<0?10n**BigInt(-shift):1n,bits)};
    }
  }else if(Array.isArray(value)){dataArray(value,2,'Rational pair');if(value.length!==2)fail('A rational pair needs two components');input={n:integer(value[0],bits),d:integer(value[1],bits)}}
  else{fields(value,['n','d']);input={n:integer(value.n,bits),d:integer(value.d,bits)}}
  return exactOf(input,{bits});
}
const q=(value,state)=>Q(rational(value,state));
function cmp(a,b,state){state.budget.charge();return compare(a,b)}
function op(a,method,b,state){state.budget.charge();return a[method](b)}
function timeValue(value,state,positive=false){const result=q(value,state);if(cmp(result,Q(0),state)<(positive?1:0))fail('Invalid exact event time');return result}
function clock(raw){fields(raw,['id','unit','revision']);return freeze({id:name(raw.id),unit:name(raw.unit),revision:count(raw.revision)})}
function encode(value,state){const text=pythonJson(value);if(text.length>DISPOSITION_LIMITS.hashChars)fail('Disposition canonical-text cap','work-budget');state.budget.charge(1+Math.ceil(text.length/64));return text}
const hash=(value,state)=>sha256(encode(value,state));
function coordinate(space,value,state,bits=256){
  if(space.kind!=='lattice')return exactText(rational(value,state,bits));dataArray(value,32,'Lattice coordinate');
  if(value.length!==space.definition.generators.length)fail('Lattice coordinate dimension');return freeze(value.map(item=>exactText(rational(item,state,bits))));
}
function pitch(space,raw,state,bits=256){
  fields(raw,['space','definition','coordinate']);if(raw.space!==space.id||raw.definition!==space.hash)fail('Pitch-space definition mismatch','out-of-model');
  const value=freeze({space:space.id,definition:space.hash,coordinate:coordinate(space,raw.coordinate,state,bits)});state.budget.charge();return bits===256?space.pitch(value):value;
}
function power(base,exponent,state){
  let n=exponent<0n?-exponent:exponent,result=ONE;if(exponent<0n){state.budget.charge();base=div(ONE,base)}
  while(n){state.budget.charge();if(n&1n)result=mul(result,base);n>>=1n;if(n)base=mul(base,base)}return result;
}
function order(space,a,b,state){
  if(space.kind!=='lattice')return cmp(rational(a.coordinate,state,8192),rational(b.coordinate,state,8192),state);
  let ratio=ONE;
  for(let i=0;i<space.definition.generators.length;i++){
    state.budget.charge();const delta=sub(rational(b.coordinate[i],state,8192),rational(a.coordinate[i],state,8192));if(delta.d!==1n)fail('Lattice exponents must be integral','out-of-model');
    ratio=mul(ratio,power(rational(space.definition.generators[i],state),delta.n,state));
  }
  return -cmp(ratio,ONE,state);
}
function setup(options,prepare=false){
  optionsOf(options,prepare?['maxWork']:['maxWork','maxProfileWork','maxSliceWork']);
  const read=(key,fallback,max)=>Object.hasOwn(options,key)?count(options[key],max):fallback;
  const state={budget:new Budget(read('maxWork',DISPOSITION_LIMITS.defaultWork,DISPOSITION_LIMITS.maxWork)),profileWork:prepare?0:read('maxProfileWork',DISPOSITION_LIMITS.profileWork,4*EXACT_LIMITS.maxWork),sliceWork:prepare?0:read('maxSliceWork',DISPOSITION_LIMITS.sliceWork,EXACT_LIMITS.maxWork)};
  state.budget.charge();return state;
}
function refs(raw,state){
  dataArray(raw,DISPOSITION_LIMITS.dependencies,'Dependency references');const out=[],seen=new Set;
  for(const item of raw){state.budget.charge();fields(item,['id','revision']);out.push(freeze({id:unique(seen,name(item.id)),revision:count(item.revision)}))}
  out.sort((a,b)=>{state.budget.charge();return a.id<b.id?-1:a.id>b.id?1:0});return freeze(out);
}
function normalize(spec,state){
  fields(spec,['id','revision','expected','sources','dependencies','members']);const id=name(spec.id),revision=count(spec.revision),metadata={nodes:0,chars:0};
  const sources=[],sourceById=new Map,sourceIds=new Set;dataArray(spec.sources,DISPOSITION_LIMITS.sources,'Source inventory');
  for(const raw of spec.sources){
    state.budget.charge();fields(raw,['id','revision','pitchSpace','clockDomain','length','events']);const sourceId=unique(sourceIds,name(raw.id)),space=raw.pitchSpace;compilePitchOperations(space,[]);
    const domain=clock(raw.clockDomain),length=timeValue(raw.length,state,true),events=[],eventIds=new Set;dataArray(raw.events,DISPOSITION_LIMITS.sourceEvents,'Source events');
    for(const event of raw.events){state.budget.charge();fields(event,['id','t','d','pitch']);const t=timeValue(event.t,state),d=timeValue(event.d,state,true);if(cmp(op(t,'add',d,state),length,state)>0)fail('Source event exceeds its phrase');events.push(freeze({id:unique(eventIds,name(event.id)),t,d,pitch:event.pitch===null?null:pitch(space,event.pitch,state)}))}
    const definition=freeze({id:sourceId,revision:count(raw.revision),pitchSpace:space.definition,clockDomain:domain,length,events:freeze(events)}),source={definition,space};source.hash=hash(definition,state);sources.push(source);sourceById.set(sourceId,source);
  }
  const dependencies=[],dependencyById=new Map,dependencyIds=new Set;dataArray(spec.dependencies,DISPOSITION_LIMITS.dependencies,'Dependency catalogue');
  for(const raw of spec.dependencies){
    state.budget.charge();fields(raw,['id','revision','kind','applicability','complete','data']);const dependencyId=unique(dependencyIds,name(raw.id));
    if(!['metric','tuning','timbre','capability','commitment','other'].includes(raw.kind)||!['bound','not-applicable'].includes(raw.applicability))fail('Declare dependency kind and applicability');
    if(raw.applicability==='not-applicable'&&(!dataRecord(raw.data)||typeof raw.data.reason!=='string'||!raw.data.reason.length))fail('Non-applicability needs an authored reason');
    const dependency=freeze({id:dependencyId,revision:count(raw.revision),kind:raw.kind,applicability:raw.applicability,complete:boolean(raw.complete),data:snapshot(raw.data,state,metadata)});dependencies.push(dependency);dependencyById.set(dependencyId,dependency);
  }
  fields(spec.expected,['id','revision','complete','members']);dataArray(spec.expected.members,DISPOSITION_LIMITS.members,'Expected disposition inventory');if(!spec.expected.members.length)fail('Promise at least one disposition');
  const promises=[],expectedIds=new Set;
  for(const raw of spec.expected.members){
    state.budget.charge();fields(raw,['id','revision','parts','dependencies']);const memberId=unique(expectedIds,name(raw.id)),parts=[],partIds=new Set;
    dataArray(raw.parts,DISPOSITION_LIMITS.parts,'Expected parts');if(!raw.parts.length)fail('An expected disposition needs parts');
    for(const part of raw.parts){state.budget.charge();fields(part,['id','sourceId','voiceId']);if(!sourceById.has(name(part.sourceId)))fail('Expected part names an unknown source');parts.push(freeze({id:unique(partIds,name(part.id)),sourceId:part.sourceId,voiceId:name(part.voiceId)}))}
    promises.push(freeze({id:memberId,revision:count(raw.revision),parts:freeze(parts),dependencies:refs(raw.dependencies,state)}));
  }
  const expected=freeze({id:name(spec.expected.id),revision:count(spec.expected.revision),complete:boolean(spec.expected.complete),members:freeze(promises)}),members=[],memberById=new Map,memberIds=new Set;
  dataArray(spec.members,DISPOSITION_LIMITS.members,'Supplied dispositions');
  for(const raw of spec.members){
    state.budget.charge();fields(raw,['id','revision','pitchSpace','dependencies','parts','environment','profile']);const memberId=unique(memberIds,name(raw.id)),space=raw.pitchSpace;compilePitchOperations(space,[]);
    const profile=raw.profile,profileInfo=decomposeCounterpointProfile(profile);if(profileInfo.pitchSpaceHash!==space.hash)fail('Whole profile and disposition space differ','out-of-model');
    const targetClock=profileInfo.clockDomain,voices=new Set(profileInfo.voices),parts=[],partById=new Map,partIds=new Set;
    dataArray(raw.parts,DISPOSITION_LIMITS.parts,'Disposition parts');
    for(const item of raw.parts){
      state.budget.charge();fields(item,['id','sourceId','voiceId','pitchTransform','timeMap','register']);const partId=unique(partIds,name(item.id)),sourceId=name(item.sourceId),voiceId=name(item.voiceId),source=sourceById.get(sourceId);
      if(!source||!voices.has(voiceId))fail('Part source/voice is undeclared');if(source.space.hash!==space.hash)fail('Cross-space operations need an explicit supported adapter','out-of-model');
      fields(item.pitchTransform,['id','revision','operations']);dataArray(item.pitchTransform.operations,DISPOSITION_LIMITS.operations,'Typed pitch operations');const operations=[];
      for(const rawOp of item.pitchTransform.operations){
        state.budget.charge();if(!dataRecord(rawOp))fail('A pitch operation must be data');const operand=rawOp.type==='transpose'?'by':rawOp.type==='reflect'?'pivot':null;
        if(!operand)fail('Unsupported typed transformation','out-of-model');fields(rawOp,['type',operand]);operations.push(freeze({type:rawOp.type,[operand]:coordinate(space,rawOp[operand],state)}));
      }
      const compiled=compilePitchOperations(space,operations),pitchDefinition=freeze({id:name(item.pitchTransform.id),revision:count(item.pitchTransform.revision),space:space.hash,operations:compiled.operations});
      fields(item.timeMap,['id','revision','knots']);dataArray(item.timeMap.knots,DISPOSITION_LIMITS.knots,'Time-map knots');if(item.timeMap.knots.length<2)fail('A time map needs two knots');const knots=[];
      for(const knot of item.timeMap.knots){state.budget.charge();fields(knot,['source','target']);knots.push(freeze({source:timeValue(knot.source,state),target:timeValue(knot.target,state)}))}
      if(cmp(knots[0].source,Q(0),state)||cmp(knots.at(-1).source,source.definition.length,state))fail('Time map must cover exactly the source phrase');
      const timeMap=piecewiseTime({id:name(item.timeMap.id),source:source.definition.clockDomain,target:targetClock,knots}),timeDefinition=freeze({...timeMap.definition,revision:count(item.timeMap.revision)});
      fields(item.register,['id','revision','low','high']);const register=freeze({id:name(item.register.id),revision:count(item.register.revision),low:pitch(space,item.register.low,state),high:pitch(space,item.register.high,state)});
      if(order(space,register.low,register.high,state)>0)fail('Reversed exact acoustic register');
      const definition=freeze({id:partId,sourceId,sourceHash:source.hash,voiceId,pitchTransform:pitchDefinition,timeMap:timeDefinition,register});
      const part={definition,source,compiled,timeMap,pitchHash:hash(pitchDefinition,state),timeHash:hash(timeDefinition,state)};parts.push(part);partById.set(partId,part);
    }
    const env=fields(raw.environment,['id','revision','complete','events','contexts']),events=[],eventIds=new Set,contexts=[],contextIds=new Set;
    dataArray(env.events,DISPOSITION_LIMITS.environmentEvents,'Environment events');
    for(const item of env.events){state.budget.charge();fields(item,['id','voiceId','t','d','pitch']);const voiceId=name(item.voiceId);if(!voices.has(voiceId))fail('Environment voice is undeclared');events.push(freeze({id:unique(eventIds,name(item.id)),voiceId,t:timeValue(item.t,state),d:timeValue(item.d,state,true),pitch:item.pitch===null?null:pitch(space,item.pitch,state)}))}
    dataArray(env.contexts,DISPOSITION_LIMITS.contexts,'Context cells');
    for(const item of env.contexts){
      state.budget.charge();fields(item,['id','revision','from','to','complete','data']);const from=timeValue(item.from,state),to=timeValue(item.to,state);
      if(cmp(from,to,state)>=0||contexts.length&&cmp(from,contexts.at(-1).to,state)<0)fail('Context cells must be ordered disjoint half-open intervals');if(!dataRecord(item.data))fail('Context must be a data record');
      contexts.push(freeze({id:unique(contextIds,name(item.id)),revision:count(item.revision),from,to,complete:boolean(item.complete),data:snapshot(item.data,state,metadata)}));
    }
    const environment=freeze({id:name(env.id),revision:count(env.revision),complete:boolean(env.complete),events:freeze(events),contexts:freeze(contexts)});
    let eventCount=events.length;for(const part of parts){state.budget.charge();eventCount+=part.source.definition.events.length}if(eventCount>DISPOSITION_LIMITS.materialEvents)fail('Disposition material event cap','row-budget');
    const definition=freeze({id:memberId,revision:count(raw.revision),pitchSpace:space.definition,dependencies:refs(raw.dependencies,state),parts:freeze(parts.map(part=>part.definition)),environment,profile:profile.definition});
    const member={definition,space,profile,targetClock,parts,partById,environment};member.hash=hash(definition,state);members.push(member);memberById.set(memberId,member);
  }
  const definition=freeze({id,revision,expected,sources:freeze(sources.map(source=>source.definition)),dependencies:freeze(dependencies),members:freeze(members.map(member=>member.definition))});
  return {definition,expected,expectedHash:hash(expected,state),dependencyById,memberById,hash:hash(definition,state)};
}
function unknown(error,state,model){return freeze({status:'UNKNOWN',scope,reason:error instanceof Refused?error.message:'Disposition processing refused',kind:error instanceof Refused?error.kind:'invalid-input',modelHash:model?.hash??null,workUsed:state?.budget.used??0})}
function modelOf(prepared){const model=owned.get(prepared);if(!model)fail('Use an authentic prepared family snapshot');return model}
export function prepareDispositionFamily(spec,options={}){
  let state;try{state=setup(options,true);const model=normalize(spec,state),prepared=freeze({kind:'counterpoint-disposition-model-v1',hash:model.hash,definition:model.definition});owned.set(prepared,model);return freeze({status:'PASS',scope,prepared,modelHash:model.hash,workUsed:state.budget.used})}
  catch(error){return unknown(error,state)}
}
function prerequisites(model,promise,member,state){
  if(!member)return 'Promised disposition is missing';if(member.definition.revision!==promise.revision)return 'Disposition revision differs from the promise';
  if(encode(member.definition.dependencies,state)!==encode(promise.dependencies,state))return 'Dependency inventory differs from the promise';
  if(member.parts.length!==promise.parts.length)return 'The actual part inventory differs';
  for(const expected of promise.parts){state.budget.charge();const actual=member.partById.get(expected.id)?.definition;if(!actual||actual.sourceId!==expected.sourceId||actual.voiceId!==expected.voiceId)return 'A promised source/voice part is missing or changed'}
  const kinds=new Set;
  for(const ref of promise.dependencies){state.budget.charge();const dependency=model.dependencyById.get(ref.id);if(!dependency||dependency.revision!==ref.revision||!dependency.complete)return 'Dependency data is absent, stale or incomplete';kinds.add(dependency.kind)}
  if(!['metric','tuning','timbre'].every(kind=>kinds.has(kind)))return 'Declare metric, tuning and timbre dependency scope, including explicit non-applicability';return null;
}
function linearTime(part,time,state){
  const knots=part.timeMap.definition.knots;
  for(let i=0;i+1<knots.length;i++){
    state.budget.charge();const a=knots[i],b=knots[i+1],from=Q(a.source),to=Q(b.source);
    if(cmp(time,to,state)>0)continue;
    const fraction=op(op(time,'sub',from,state),'div',op(to,'sub',from,state),state);
    return op(Q(a.target),'add',op(fraction,'mul',op(Q(b.target),'sub',Q(a.target),state),state),state);
  }
  fail('Replay time is outside the map','out-of-model');
}
function reconstruct(member,promise,state,replay=false){
  const events=[],registrations=[];
  for(let i=0;i<promise.parts.length;i++){
    const part=member.partById.get(promise.parts[i].id),source=part.source.definition;
    for(let j=0;j<source.events.length;j++){
      const event=source.events[j];state.budget.charge(2*(10+2*Math.ceil(Math.log2(part.timeMap.definition.knots.length)))+1+part.compiled.operations.length);
      const end=op(event.t,'add',event.d,state),a=replay?linearTime(part,event.t,state):part.timeMap.at(event.t),b=replay?linearTime(part,end,state):part.timeMap.at(end);
      const t=cmp(a,b,state)<0?a:b,d=cmp(a,b,state)<0?op(b,'sub',a,state):op(a,'sub',b,state);let mapped=event.pitch;
      if(mapped!==null){if(replay){for(const operation of part.compiled.operations){state.budget.charge();mapped=member.space.apply(mapped,operation)}}else mapped=part.compiled.apply(mapped)}
      const actual=freeze({id:`p:${i}:${j}`,voiceId:part.definition.voiceId,t,d,pitch:mapped,clockDomain:member.targetClock,
        origin:freeze({kind:'part',partId:part.definition.id,sourceId:source.id,sourceEventId:event.id,sourceHash:part.source.hash,pitchHash:part.pitchHash,timeHash:part.timeHash,registerId:part.definition.register.id,registerRevision:part.definition.register.revision})});
      events.push(actual);registrations.push({event:actual,register:part.definition.register});
    }
  }
  for(let i=0;i<member.environment.events.length;i++){state.budget.charge();const event=member.environment.events[i];events.push(freeze({...event,id:`e:${i}`,clockDomain:member.targetClock,origin:freeze({kind:'environment',eventId:event.id,environmentId:member.environment.id,revision:member.environment.revision})}))}
  return {events:freeze(events),registrations};
}
function contextAt(member,time,state){
  const cells=member.environment.contexts;let lo=0,hi=cells.length;
  while(lo<hi){state.budget.charge();const mid=(lo+hi)>>1;if(cmp(cells[mid].from,time,state)<=0)lo=mid+1;else hi=mid}
  const cell=cells[lo-1];return cell&&cmp(time,cell.to,state)<0?cell:null;
}
function covered(member,events,state){
  if(!member.environment.complete)return false;
  for(const event of events){state.budget.charge();if(event.pitch===null)continue;let at=event.t;const end=op(event.t,'add',event.d,state);
    while(cmp(at,end,state)<0){const cell=contextAt(member,at,state);if(!cell||!cell.complete)return false;at=cmp(cell.to,end,state)<0?cell.to:end}}
  return true;
}
function ordering(member,events,state){
  const allowance=Math.min(state.sliceWork,state.budget.limit-state.budget.used);if(!allowance)fail('No sounding-slice allowance remains','work-budget');
  state.budget.charge(allowance);const boundaries=member.environment.contexts.flatMap(cell=>[cell.from,cell.to]);
  const slices=soundingSlices(events,boundaries,{maxWork:allowance}),out=[];
  for(const slice of slices){
    state.budget.charge();const sorted=[...slice.active];sorted.sort((a,b)=>order(member.space,a.pitch,b.pitch,state)||(a.id<b.id?-1:a.id>b.id?1:0));const groups=[];
    for(const event of sorted){state.budget.charge();const last=groups.at(-1);if(last&&order(member.space,last[0].pitch,event.pitch,state)===0)last.push(event);else groups.push([event])}
    const ordered=freeze(groups.map(group=>freeze(group.map(event=>event.id))));out.push(freeze({from:String(slice.start),to:String(slice.end),groups:ordered,bassIds:ordered[0]??freeze([])}));
  }
  return freeze(out);
}
function profileAudit(model,member,promise,events,state){
  const total=Math.min(state.profileWork,state.budget.limit-state.budget.used),allocated=Math.min(EXACT_LIMITS.maxWork,Math.floor(total/4));if(!allocated)fail('No whole-profile allowance remains','work-budget');
  const contextState={budget:new Budget(allocated)},boundaries=[];let out;
  try{
    for(const cell of member.environment.contexts){contextState.budget.charge();boundaries.push(cell.from,cell.to)}
    out=member.profile.audit(events,{boundaries,contextAt:time=>contextAt(member,time,contextState)?.data??freeze({}),
      dependencies:{family:model.hash,expected:model.expectedHash,member:member.hash,bindings:promise.dependencies.map(ref=>model.dependencyById.get(ref.id))},maxWork:allocated,maxPredicateWork:allocated});
  }catch(error){state.budget.charge(4*allocated);throw error}
  state.budget.charge(allocated+out.workUsed+out.predicateWorkUsed+contextState.budget.used);
  return {...out,normalizationAllowance:allocated,contextWorkUsed:contextState.budget.used};
}
function wire(events,state){const out=[];for(const event of events){state.budget.charge();out.push(freeze({...event,t:String(event.t),d:String(event.d)}))}return freeze(out)}
function evaluate(model,promise,member,state,replay=false){
  let registerFailure=null,profileFailure=false;
  try{
    state.budget.charge();const missing=prerequisites(model,promise,member,state);if(missing)return freeze({id:promise.id,status:'UNKNOWN',reason:missing});
    const material=reconstruct(member,promise,state,replay);if(!covered(member,material.events,state))return freeze({id:promise.id,status:'UNKNOWN',reason:'Incomplete sounding environment or sustain context'});
    for(const {event,register} of material.registrations){
      state.budget.charge();if(event.pitch!==null&&(order(member.space,register.low,event.pitch,state)>0||order(member.space,event.pitch,register.high,state)>0)){
        registerFailure=freeze({eventId:event.id,registerId:register.id,pitch:event.pitch,low:register.low,high:register.high});break;
      }
    }
    const orderEvidence=ordering(member,material.events,state),rawAudit=profileAudit(model,member,promise,material.events,state);profileFailure=rawAudit.status==='FAIL';
    const audit=snapshot(rawAudit,state,undefined,0,undefined,6000),status=registerFailure||profileFailure?'FAIL':audit.status==='PASS'?'PASS':'UNKNOWN';
    const events=wire(material.events,state),dependencyHash=hash(promise.dependencies.map(ref=>model.dependencyById.get(ref.id)),state);
    const evidence=freeze({id:promise.id,revision:promise.revision,dependencyHash,events,eventHash:hash(events,state),ordering:orderEvidence,orderingHash:hash(orderEvidence,state)});
    return freeze({id:promise.id,status,reason:registerFailure?'A transformed event leaves its declared exact register':'Actual transformed whole-sonority profile',registerFailure,audit,evidence});
  }catch(error){return freeze({id:promise.id,status:registerFailure||profileFailure?'FAIL':'UNKNOWN',reason:registerFailure||profileFailure?'A known register/profile violation refutes this member; later processing refused':error instanceof Refused?error.message:'Member processing refused',registerFailure,profileFailure,kind:error instanceof Refused?error.kind:'invalid-input'})}
}
function aggregate(model,results){
  if(results.some(result=>result.status==='FAIL'))return 'FAIL';
  if(!model.expected.complete||model.memberById.size!==model.expected.members.length||results.some(result=>result.status!=='PASS'))return 'UNKNOWN';return 'PASS';
}
export function auditDispositionFamily(prepared,options={}){
  let state,model;try{
    state=setup(options);model=modelOf(prepared);const results=[];for(const promise of model.expected.members)results.push(evaluate(model,promise,model.memberById.get(promise.id),state));
    const status=aggregate(model,results);let certificate=null;
    if(status==='PASS')certificate=freeze({kind:'counterpoint-disposition-family-v1',modelHash:model.hash,expectedHash:model.expectedHash,members:freeze(results.map(result=>result.evidence))});
    if(certificate){certificate=snapshot(certificate,state,undefined,0,undefined,6000);encode(certificate,state)}
    return freeze({status,scope,modelHash:model.hash,expectedHash:model.expectedHash,results:freeze(results),certificate,workUsed:state.budget.used,
      reason:status==='PASS'?'Every promised disposition passes its exact register and mandatory whole profile':status==='FAIL'?'A fully bound promised member is refuted':'Incomplete inventory, dependencies, context or processing evidence'});
  }catch(error){return unknown(error,state,model)}
}
export function checkDispositionFamily(prepared,raw,options={}){
  let state,model;const results=[];try{
    state=setup(options);model=modelOf(prepared);fields(raw,['kind','modelHash','expectedHash','members']);
    const certificate=snapshot(raw,state,undefined,0,undefined,6000);dataArray(certificate.members,DISPOSITION_LIMITS.members,'Certified members');const byId=new Map;
    for(const member of certificate.members){
      state.budget.charge();fields(member,['id','revision','dependencyHash','events','eventHash','ordering','orderingHash']);name(member.id);count(member.revision);if(byId.has(member.id))fail('Duplicate certified member');
      dataArray(member.events,DISPOSITION_LIMITS.materialEvents,'Certified material');dataArray(member.ordering,8192,'Certified ordering');
      for(const event of member.events){
        state.budget.charge();fields(event,['id','voiceId','t','d','pitch','clockDomain','origin']);name(event.id);name(event.voiceId);
        const t=rational(event.t,state,8192),d=rational(event.d,state,8192);if(cmp(t,Q(0),state)<0||cmp(d,Q(0),state)<=0)fail('Invalid certified interval');
        clock(event.clockDomain);if(!dataRecord(event.origin))fail('Certified origin must be data');
        if(event.pitch!==null){fields(event.pitch,['space','definition','coordinate']);name(event.pitch.space);name(event.pitch.definition);
          if(Array.isArray(event.pitch.coordinate)){dataArray(event.pitch.coordinate,32,'Certified lattice coordinate');for(const value of event.pitch.coordinate)rational(value,state,8192)}else rational(event.pitch.coordinate,state,8192)}
      }
      for(const cell of member.ordering){
        state.budget.charge();fields(cell,['from','to','groups','bassIds']);const from=rational(cell.from,state,8192),to=rational(cell.to,state,8192);if(cmp(from,Q(0),state)<0||cmp(from,to,state)>=0)fail('Invalid certified ordering cell');
        dataArray(cell.groups,DISPOSITION_LIMITS.materialEvents,'Certified unison groups');dataArray(cell.bassIds,DISPOSITION_LIMITS.materialEvents,'Certified bass IDs');
        for(const group of cell.groups){dataArray(group,DISPOSITION_LIMITS.materialEvents,'Certified unison group');for(const id of group){state.budget.charge();name(id)}}for(const id of cell.bassIds){state.budget.charge();name(id)}
      }
      for(const key of ['dependencyHash','eventHash','orderingHash'])if(typeof member[key]!=='string'||!/^[a-f0-9]{64}$/.test(member[key]))fail('Malformed certified digest');
      byId.set(member.id,member);
    }
    if(certificate.kind!=='counterpoint-disposition-family-v1'||certificate.modelHash!==model.hash||certificate.expectedHash!==model.expectedHash||byId.size!==model.expected.members.length||model.expected.members.some(promise=>!byId.has(promise.id)))return freeze({status:'FAIL',scope,kind:'certificate-mismatch',reason:'Certificate inventory or model binding differs',workUsed:state.budget.used});
    for(const promise of model.expected.members){
      const result=evaluate(model,promise,model.memberById.get(promise.id),state,true);results.push(result);
      if(result.evidence&&encode(result.evidence,state)!==encode(byId.get(promise.id),state))return freeze({status:'FAIL',scope,kind:'certificate-mismatch',reason:'Direct reconstruction, dependencies or exact ordering differ',memberId:promise.id,workUsed:state.budget.used});
    }
    return freeze({status:aggregate(model,results),scope,modelHash:model.hash,expectedHash:model.expectedHash,results:freeze(results),workUsed:state.budget.used,
      reason:'Every expected materialization was reconstructed and its mandatory whole profile rerun'});
  }catch(error){return results.some(result=>result.status==='FAIL')?freeze({status:'FAIL',scope,kind:'family-counterexample',modelHash:model?.hash??null,results:freeze(results),workUsed:state?.budget.used??0,reason:'A fully bound member was refuted before later checking refused'}):unknown(error,state,model)}
}
