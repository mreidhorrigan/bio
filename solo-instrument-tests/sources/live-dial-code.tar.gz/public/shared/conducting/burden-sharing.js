// CFM031 / EC19: an authored continuous minimax policy, not a universal notion of musical fairness.
// Exact bounded planning reference. A certified algebraic allocation is not permission to emit changed music.
import {dataArray,dataRecord} from './contract-data.js';
import {Refused,EXACT_LIMITS,ZERO,ONE,add,sub,mul,div,compare,exactOf,exactText,pythonJson,sha256} from '../bounded-exact.js';

export const BURDEN_SHARING_LIMITS=Object.freeze({maxVariables:6,maxRelations:32,maxMetrics:32,maxHistory:1024,
  maxRows:256,maxDependencies:128,maxBases:100000,maxWork:2000000,maxTextChars:4194304,maxDataNodes:65536});
const freeze=Object.freeze,models=new WeakMap,scope='declared-bounded-continuous-minimax-normalized-burden';
const fail=(message,kind='invalid-input')=>{throw new Refused(message,{kind})};
class InvalidCertificate extends Error {}
const demand=(condition,message)=>{if(!condition)throw new InvalidCertificate(message)};
function stateOf(options){
  if(!dataRecord(options)||Object.keys(options).some(k=>!Object.hasOwn(BURDEN_SHARING_LIMITS,k)))fail('Unknown burden-sharing options');
  const limits={};for(const [key,cap] of Object.entries(BURDEN_SHARING_LIMITS)){
    const value=Object.hasOwn(options,key)?options[key]:key==='maxBases'?20000:cap;
    if(!Number.isSafeInteger(value)||value<0||value>cap)fail('Bounded nonnegative integer allowances required');limits[key]=value;
  }
  const s={limits:freeze(limits),used:0,chars:0,nodes:0,modelHash:null};
  s.charge=(n=1)=>{if(!Number.isSafeInteger(n)||n<0)throw new Error('Invalid work charge');
    if(n>limits.maxWork-s.used)fail('Burden-sharing work allowance exhausted','work-budget');s.used+=n};
  s.m={};for(const [key,fn] of Object.entries({add,sub,mul,div,cmp:compare}))s.m[key]=(a,b)=>{s.charge();return fn(a,b)};
  s.charge();return s;
}
function fields(v,keys,s){s.charge();if(!dataRecord(v)||Object.keys(v).length!==keys.length||keys.some(k=>!Object.hasOwn(v,k)))fail('Missing or unsupported burden fields');s.charge(keys.length);return v}
function list(v,cap,s,label){if(!Array.isArray(v)||v.length>cap)fail(label+' allowance','shape-budget');s.charge(v.length+1);return dataArray(v,cap,label)}
function text(v,s,cap=256){if(typeof v!=='string'||!v.length||v.length>cap)fail('Bounded nonempty text required');
  if(v.length>s.limits.maxTextChars-s.chars)fail('Burden text allowance','work-budget');s.chars+=v.length;s.charge(1+Math.ceil(v.length/64));return v}
function revision(v){if(!Number.isSafeInteger(v)||v<0)fail('Nonnegative safe revision required');return v}
function unique(seen,id){if(seen.has(id))fail('Duplicate burden identity');seen.add(id);return id}
function rational(v,s,bits=EXACT_LIMITS.inputBits){
  s.charge();let n,d=1n;const boundary=1n<<BigInt(bits);
  const integer=x=>{const q=typeof x==='bigint'?x:Number.isSafeInteger(x)?BigInt(x):null;
    if(q===null||q<=-boundary||q>=boundary)fail('Raw rational component allowance','arithmetic-budget');return q};
  if(typeof v==='string'){
    text(v,s,bits===EXACT_LIMITS.inputBits?160:6000);const match=v.match(/^([+-]?[0-9]+)(?:\/([+-]?[0-9]+))?$/);
    if(!match||match[0].length!==v.length)fail('Use exact integer or fraction text');n=integer(BigInt(match[1]));d=integer(BigInt(match[2]??'1'));
  }else if(v&&typeof v==='object'){fields(v,['n','d'],s);n=integer(v.n);d=integer(v.d)}else n=integer(v);
  if(!d)fail('Zero denominator');return exactOf({n,d},{bits});
}
function positive(v,s){const q=rational(v,s);if(q.n<=0n)fail('Strictly positive normalizer or entitlement required');return q}
function nonnegative(v,s){const q=rational(v,s);if(q.n<0n)fail('Negative burden or allowance');return q}
function vector(v,n,s){const a=list(v,s.limits.maxVariables,s,'Coefficient vector');if(a.length!==n)fail('One coefficient per original variable required');return freeze(a.map(x=>rational(x,s)))}
function sides(v,s,read=nonnegative){fields(v,['minus','plus'],s);return freeze({minus:read(v.minus,s),plus:read(v.plus,s)})}
function metadata(v,s,depth=0,seen=new Set){
  s.charge();if(++s.nodes>s.limits.maxDataNodes)fail('Burden metadata-node allowance','shape-budget');
  if(v===null||typeof v==='boolean')return v;
  if(typeof v==='number'){if(!Number.isFinite(v))fail('Nonfinite metadata');return Object.is(v,-0)?0:v}
  if(typeof v==='string')return v.length?text(v,s,2048):v;
  if(depth>=12||seen.has(v))fail('Cyclic or deep burden metadata');seen.add(v);let out;
  if(Array.isArray(v)){list(v,s.limits.maxDataNodes,s,'Metadata');out=[];for(const x of v)out.push(metadata(x,s,depth+1,seen))}
  else{if(!dataRecord(v)||Object.keys(v).length>256)fail('Ordinary bounded metadata required');out={};for(const key of Object.keys(v)){
    text(key,s);Object.defineProperty(out,key,{value:metadata(v[key],s,depth+1,seen),enumerable:true})}}
  seen.delete(v);return freeze(out);
}
function wire(v,s){s.charge();if(++s.nodes>s.limits.maxDataNodes)fail('Burden output-node allowance','shape-budget');
  if(typeof v==='string')return v.length?text(v,s,6000):v;
  if(v&&typeof v==='object'){
    if(typeof v.n==='bigint'&&typeof v.d==='bigint')return text(exactText(v),s,6000);
    if(Array.isArray(v))return freeze(v.map(x=>wire(x,s)));
    return freeze(Object.fromEntries(Object.entries(v).map(([key,value])=>[text(key,s),wire(value,s)])));
  }return v;
}
function hash(v,s){const encoded=pythonJson(v);if(encoded.length>s.limits.maxTextChars)fail('Burden canonical-text allowance','work-budget');s.charge(1+Math.ceil(encoded.length/64));return sha256(encoded)}
function dot(a,b,s){let sum=ZERO;for(let i=0;i<a.length;i++){s.charge();if(a[i].n&&b[i].n)sum=s.m.add(sum,s.m.mul(a[i],b[i]))}return sum}
function normalize(raw,s){
  fields(raw,['id','revision','variables','relations','metrics','policy','bindings','dependencies'],s);
  const id=text(raw.id,s),version=revision(raw.revision),variables=[],relations=[],metrics=[];let historyCount=0;
  const ids=new Set;for(const v of list(raw.variables,s.limits.maxVariables,s,'Variables')){
    fields(v,['id','unit','lo','hi'],s);const lo=rational(v.lo,s),hi=rational(v.hi,s);if(s.m.cmp(lo,hi)>0)fail('Reversed variable bounds');
    variables.push(freeze({id:unique(ids,text(v.id,s)),unit:text(v.unit,s),lo,hi}));
  }
  const n=variables.length,relationIds=new Set;
  for(const v of list(raw.relations,s.limits.maxRelations,s,'Relations')){
    fields(v,['id','coefficients','sense','rhs'],s);if(v.sense!=='le'&&v.sense!=='eq')fail('Use a declared linear inequality or equality');
    relations.push(freeze({id:unique(relationIds,text(v.id,s)),coefficients:vector(v.coefficients,n,s),sense:v.sense,rhs:rational(v.rhs,s)}));
  }
  const metricIds=new Set;let complete=true;
  for(const v of list(raw.metrics,s.limits.maxMetrics,s,'Burden metrics')){
    fields(v,['id','playerId','roleId','dimension','unit','residual','freeBand','outerCap','normalizer','entitlement','history'],s);
    const metricId=unique(metricIds,text(v.id,s)),res=fields(v.residual,['offset','coefficients'],s);
    const residual=freeze({offset:rational(res.offset,s),coefficients:vector(res.coefficients,n,s)}),freeBand=sides(v.freeBand,s),outerCap=sides(v.outerCap,s),normalizer=sides(v.normalizer,s,positive);
    if(s.m.cmp(freeBand.minus,outerCap.minus)>0||s.m.cmp(freeBand.plus,outerCap.plus)>0)fail('Free bands must lie inside immutable outer caps');
    const h=fields(v.history,['id','revision','complete','entries'],s);if(typeof h.complete!=='boolean')fail('Declare burden history completeness');complete=complete&&h.complete;
    const entries=[],seen=new Set;let total=ZERO;
    for(const e of list(h.entries,s.limits.maxHistory-historyCount,s,'History entries')){
      fields(e,['id','revision','burden','reference'],s);const ref=fields(e.reference,['id','revision','hash'],s),refHash=text(ref.hash,s,64);
      if(refHash.length!==64||!/^[0-9a-f]{64}$/.test(refHash))fail('Lowercase SHA-256 history reference required');const burden=nonnegative(e.burden,s);total=s.m.add(total,burden);
      entries.push(freeze({id:unique(seen,text(e.id,s)),revision:revision(e.revision),burden,reference:freeze({id:text(ref.id,s),revision:revision(ref.revision),hash:refHash})}));
    }historyCount+=entries.length;
    metrics.push(freeze({id:metricId,playerId:text(v.playerId,s),roleId:text(v.roleId,s),dimension:text(v.dimension,s),unit:text(v.unit,s),
      residual,freeBand,outerCap,normalizer,entitlement:positive(v.entitlement,s),
      history:freeze({id:text(h.id,s),revision:revision(h.revision),complete:h.complete,entries:freeze(entries)}),historyTotal:total}));
  }if(!metrics.length)fail('Declare at least one burden metric');
  const p=fields(raw.policy,['id','revision','type'],s);if(p.type!=='minimax-normalized-burden')fail('Declare the authored minimax policy','out-of-model');
  const policy=freeze({id:text(p.id,s),revision:revision(p.revision),type:p.type});
  if(!dataRecord(raw.bindings))fail('Current bindings must be a record');const bindings=metadata(raw.bindings,s),dependencies=[],depIds=new Set;
  for(const d of list(raw.dependencies,s.limits.maxDependencies,s,'Dependencies')){fields(d,['id','revision','data'],s);dependencies.push(freeze({id:unique(depIds,text(d.id,s)),revision:revision(d.revision),data:metadata(d.data,s)}))}
  const model={id,revision:version,variables:freeze(variables),relations:freeze(relations),metrics:freeze(metrics),policy,bindings,dependencies:freeze(dependencies),historyCount,complete};
  model.definition=wire({kind:'burden-sharing-v1',id,revision:version,variables,relations,metrics,policy,bindings,dependencies},s);s.modelHash=hash(model.definition,s);
  return model;
}
// Gz <= h, z=(x,t). The upper t bound is derived from outer caps, never a hidden musical allowance.
function rowsOf(model,s){
  const rows=[],n=model.variables.length,m=s.m,negative=q=>m.sub(ZERO,q),append=(id,a,b)=>{
    s.charge();if(rows.length>=s.limits.maxRows)fail('Linear row allowance','shape-budget');rows.push(freeze({id,a:freeze(a),b}))};
  const unit=i=>Array.from({length:n},(_,j)=>i===j?ONE:ZERO);
  for(let i=0;i<n;i++){const a=unit(i);append(`bound:${i}:upper`,[...a,ZERO],model.variables[i].hi);append(`bound:${i}:lower`,[...a.map(negative),ZERO],negative(model.variables[i].lo))}
  for(let i=0;i<model.relations.length;i++){const r=model.relations[i];append(`relation:${i}:forward`,[...r.coefficients,ZERO],r.rhs);
    if(r.sense==='eq')append(`relation:${i}:reverse`,[...r.coefficients.map(negative),ZERO],negative(r.rhs))}
  let top=ZERO;
  for(let i=0;i<model.metrics.length;i++){
    const r=model.metrics[i],a=r.residual.coefficients,b=r.residual.offset,E=r.entitlement,H=m.div(r.historyTotal,E),sp=m.mul(r.normalizer.plus,E),sm=m.mul(r.normalizer.minus,E);
    append(`cap:${i}:plus`,[...a,ZERO],m.sub(r.outerCap.plus,b));append(`cap:${i}:minus`,[...a.map(negative),ZERO],m.add(r.outerCap.minus,b));
    append(`burden:${i}:history`,[...Array(n).fill(ZERO),negative(ONE)],negative(H));
    append(`burden:${i}:plus`,[...a.map(q=>m.div(q,sp)),negative(ONE)],m.sub(m.div(m.sub(r.freeBand.plus,b),sp),H));
    append(`burden:${i}:minus`,[...a.map(q=>m.div(negative(q),sm)),negative(ONE)],m.sub(m.div(m.add(r.freeBand.minus,b),sm),H));
    const plus=m.div(m.sub(r.outerCap.plus,r.freeBand.plus),r.normalizer.plus),minus=m.div(m.sub(r.outerCap.minus,r.freeBand.minus),r.normalizer.minus);
    const peak=m.div(m.add(r.historyTotal,m.cmp(plus,minus)>0?plus:minus),E);if(m.cmp(peak,top)>0)top=peak;
  }
  append('peak:lower',[...Array(n).fill(ZERO),negative(ONE)],ZERO);append('peak:upper',[...Array(n).fill(ZERO),ONE],top);
  return freeze(rows);
}
function modelOf(prepared,s){const m=models.get(prepared);if(!m)fail('Use an authentic prepared burden model','out-of-model');s.modelHash=prepared.modelHash;
  if(m.variables.length>s.limits.maxVariables||m.relations.length>s.limits.maxRelations||m.metrics.length>s.limits.maxMetrics||m.historyCount>s.limits.maxHistory||
    m.dependencies.length>s.limits.maxDependencies)fail('Prepared model exceeds current shape allowance','shape-budget');return m}
function result(s,status,reason,extra={}){return freeze({status,reason,scope,modelHash:s?.modelHash??null,workUsed:s?.used??0,resourceLimits:s?.limits??null,...extra})}
function run(options,body){let s;try{s=stateOf(options);return body(s)}catch(e){return result(s,e instanceof InvalidCertificate?'FAIL':'UNKNOWN',e.message??'Burden sharing refused',
  {kind:e instanceof Refused?e.kind:e instanceof InvalidCertificate?'invalid-certificate':'internal-error',certificate:null,conclusion:null})}}
function valuesOf(model,raw,s){const rows=list(raw,s.limits.maxVariables,s,'Original variable values');if(rows.length!==model.variables.length)fail('Supply every original variable');
  return rows.map((row,i)=>{fields(row,['id','value'],s);if(row.id!==model.variables[i].id)fail('Original variable identity/order differs');return rational(row.value,s,EXACT_LIMITS.workBits)})}
function auditPoint(model,x,s){
  const m=s.m,violations=[],burdens=[];let peak=ZERO;
  for(let i=0;i<x.length;i++){s.charge();const v=model.variables[i];if(m.cmp(x[i],v.lo)<0||m.cmp(x[i],v.hi)>0)violations.push({kind:'variable-bound',id:v.id})}
  for(const r of model.relations){const c=m.cmp(dot(r.coefficients,x,s),r.rhs);if(r.sense==='eq'?c!==0:c>0)violations.push({kind:'relation',id:r.id})}
  for(const r of model.metrics){
    const residual=m.add(r.residual.offset,dot(r.residual.coefficients,x,s));
    if(m.cmp(residual,m.sub(ZERO,r.outerCap.minus))<0||m.cmp(residual,r.outerCap.plus)>0)violations.push({kind:'outer-cap',id:r.id});
    const side=residual.n<0n?'minus':'plus',magnitude=residual.n<0n?m.sub(ZERO,residual):residual,excess=m.sub(magnitude,r.freeBand[side]);
    const current=excess.n>0n?m.div(excess,r.normalizer[side]):ZERO,total=m.add(r.historyTotal,current),normalizedTotal=m.div(total,r.entitlement);
    if(m.cmp(normalizedTotal,peak)>0)peak=normalizedTotal;
    burdens.push({metricId:r.id,playerId:r.playerId,roleId:r.roleId,dimension:r.dimension,unit:r.unit,residual,history:r.historyTotal,current,total,entitlement:r.entitlement,normalizedTotal});
  }
  return {valid:!violations.length,peak,report:wire({modelHash:s.modelHash,values:model.variables.map((v,i)=>({id:v.id,value:x[i]})),peak,burdens,violations,
    policy:model.policy,bindings:model.bindings,dependencies:model.dependencies},s)};
}
function solveSquare(matrix,rhs,s){
  const n=rhs.length,m=s.m;s.charge(n*(n+1));const a=matrix.map((row,i)=>[...row,rhs[i]]);
  for(let col=0;col<n;col++){
    let pivot=col;while(pivot<n&&!a[pivot][col].n){s.charge();pivot++}if(pivot===n)return null;
    [a[pivot],a[col]]=[a[col],a[pivot]];const divisor=a[col][col];
    for(let j=col;j<=n;j++)a[col][j]=m.div(a[col][j],divisor);
    for(let i=0;i<n;i++)if(i!==col){s.charge();const factor=a[i][col];if(factor.n)for(let j=col;j<=n;j++)a[i][j]=m.sub(a[i][j],m.mul(factor,a[col][j]))}
  }return a.map(row=>row[n]);
}
function feasible(rows,z,s){for(const r of rows)if(s.m.cmp(dot(r.a,z,s),r.b)>0)return false;return true}
function nextBasis(indices,n,s){
  for(let i=indices.length-1;i>=0;i--){s.charge();if(indices[i]<n-indices.length+i){indices[i]++;for(let j=i+1;j<indices.length;j++)indices[j]=indices[j-1]+1;return true}}return false;
}
function certificate(model,conclusion,report,dual,s){return freeze({kind:'burden-sharing-certificate-v1',modelHash:s.modelHash,conclusion,
  values:report?.values??null,peak:report?.peak??null,dual:wire(dual,s)})}
function enumerate(model,rows,s){
  const d=model.variables.length+1,indices=Array.from({length:d},(_,i)=>i);let bases=0,best=null,exhausted=false;
  try{
    while(bases<s.limits.maxBases){
      s.charge();bases++;const active=indices.map(i=>rows[i]),point=solveSquare(active.map(r=>r.a),active.map(r=>r.b),s);
      if(point&&feasible(rows,point,s)){
        const x=point.slice(0,-1),out=auditPoint(model,x,s);if(!out.valid)throw new Error('Original burden audit contradicts generated rows');
        const sat=certificate(model,'SAT',out.report,[],s);if(!best||s.m.cmp(out.peak,best.peak)<0)best={peak:out.peak,report:out.report,certificate:sat};
        const target=Array.from({length:d},(_,i)=>i===d-1?s.m.sub(ZERO,ONE):ZERO);
        const dual=solveSquare(Array.from({length:d},(_,j)=>active.map(row=>row.a[j])),target,s);
        if(dual&&dual.every(q=>q.n>=0n)){
          const lower=s.m.sub(ZERO,dot(dual,active.map(r=>r.b),s));if(s.m.cmp(lower,out.peak)!==0)throw new Error('Primal/dual burden objectives disagree');
          return {optimal:true,bases,report:out.report,certificate:certificate(model,'OPTIMAL',out.report,
            dual.flatMap((q,i)=>q.n?[freeze({rowId:active[i].id,multiplier:exactText(q)})]:[]),s)};
        }
      }
      if(!nextBasis(indices,rows.length,s)){exhausted=true;break}
    }
    return {bases,best,exhausted,reason:exhausted?'Every original full-rank basis examined':'Basis allowance exhausted'};
  }catch(e){if(!(e instanceof Refused))throw e;return {bases,best,exhausted:false,reason:e.message,kind:e.kind}}
}
// Checker traversal runs from the last combination backwards, without producer best points or dual state.
function excludeVertices(model,rows,s){
  const d=model.variables.length+1,indices=Array.from({length:d},(_,i)=>rows.length-d+i);let bases=0;
  while(bases<s.limits.maxBases){
    s.charge();bases++;const active=indices.map(i=>rows[i]),point=solveSquare(active.map(r=>r.a),active.map(r=>r.b),s);
    if(point&&feasible(rows,point,s))return {counterexample:true,bases};
    let at=d-1;while(at>=0&&indices[at]===(at?indices[at-1]+1:0)){s.charge();at--}
    if(at<0)return {exhausted:true,bases};indices[at]--;for(let j=at+1;j<d;j++)indices[j]=rows.length-d+j;
  }return {exhausted:false,bases,reason:'Checker basis allowance exhausted',kind:'basis-budget'};
}
/** Preparation binds an authored model; it certifies neither fairness outcomes nor feasibility. */
export function prepareBurdenSharing(spec,options={}){
  return run(options,s=>{const model=normalize(spec,s),rows=rowsOf(model,s),prepared=freeze({kind:'prepared-burden-sharing-v1',modelHash:s.modelHash,
    definition:model.definition,dualRows:wire(rows.map(r=>({rowId:r.id,coefficients:r.a,rhs:r.b})),s)});models.set(prepared,model);
    return result(s,'PASS','Original continuous burden model prepared',{prepared})});
}
/** Exact audit of the supplied allocation against bounds, couplings, caps and separate authored burden histories. */
export function auditBurdenSharing(prepared,values,options={}){
  return run(options,s=>{const model=modelOf(prepared,s);if(!model.complete)fail('Complete normalized history is required','missing-evidence');
    const out=auditPoint(model,valuesOf(model,values,s),s);return result(s,out.valid?'PASS':'FAIL','Original algebraic allocation audited',{report:out.report})});
}
/** Enumerate exact active bases; a nonnegative dual proves the global minimum without completing the enumeration. */
export function solveBurdenSharing(prepared,options={}){
  return run(options,s=>{const model=modelOf(prepared,s);if(!model.complete)fail('Complete normalized history is required','missing-evidence');
    const out=enumerate(model,rowsOf(model,s),s),search=freeze({bases:out.bases,exhausted:out.exhausted??false});
    if(out.optimal)return result(s,'OPTIMAL','Exact feasible allocation and matching nonnegative dual lower bound',{report:out.report,certificate:out.certificate,search});
    if(out.best)return result(s,'SAT',out.reason,{report:out.best.report,certificate:out.best.certificate,search,optimal:false});
    if(out.exhausted)return result(s,'UNSAT','No vertex exists in the bounded original linear model',{certificate:certificate(model,'UNSAT',null,[],s),search});
    return result(s,'UNKNOWN',out.reason,{kind:out.kind??'basis-budget',certificate:null,search});
  });
}
/** Verify original primal semantics and the dual identity; an UNSAT certificate requires independent full enumeration. */
export function checkBurdenSharing(prepared,raw,options={}){
  return run(options,s=>{const model=modelOf(prepared,s);fields(raw,['kind','modelHash','conclusion','values','peak','dual'],s);
    demand(raw.kind==='burden-sharing-certificate-v1'&&raw.modelHash===s.modelHash,'Original burden model identity differs');
    demand(['SAT','OPTIMAL','UNSAT'].includes(raw.conclusion),'Unsupported burden conclusion');
    if(!model.complete)fail('Complete normalized history is required','missing-evidence');const rows=rowsOf(model,s);
    if(raw.conclusion==='UNSAT'){
      demand(raw.values===null&&raw.peak===null&&list(raw.dual,0,s,'UNSAT dual').length===0,'An UNSAT certificate has no allocation');
      const out=excludeVertices(model,rows,s);demand(!out.counterexample,'A feasible original vertex refutes UNSAT');
      if(!out.exhausted)fail(out.reason,out.kind??'basis-budget');
      return result(s,'PASS','Every original basis independently excludes a feasible vertex',{conclusion:'UNSAT',search:freeze({bases:out.bases,exhausted:true})});
    }
    const x=valuesOf(model,raw.values,s),out=auditPoint(model,x,s);demand(out.valid,'Original bounds, couplings or immutable caps fail');
    const peak=rational(raw.peak,s,EXACT_LIMITS.workBits);demand(s.m.cmp(peak,out.peak)===0,'Reported maximum differs from actual normalized burdens');
    const entries=list(raw.dual,s.limits.maxRows,s,'Dual certificate');
    if(raw.conclusion==='SAT')demand(!entries.length,'Feasibility does not carry an optimality dual');
    else{
      const byId=new Map(rows.map(r=>[r.id,r])),seen=new Set,combined=Array(x.length+1).fill(ZERO);let lower=ZERO;
      for(const e of entries){fields(e,['rowId','multiplier'],s);demand(typeof e.rowId==='string'&&!seen.has(e.rowId)&&byId.has(e.rowId),'Duplicate or unknown dual row');seen.add(e.rowId);
        const lambda=rational(e.multiplier,s,EXACT_LIMITS.workBits);demand(lambda.n>=0n,'A dual multiplier is negative');const row=byId.get(e.rowId);
        for(let i=0;i<combined.length;i++)combined[i]=s.m.add(combined[i],s.m.mul(lambda,row.a[i]));lower=s.m.sub(lower,s.m.mul(lambda,row.b));
      }
      for(let i=0;i<combined.length;i++)demand(s.m.cmp(combined[i],i===x.length?s.m.sub(ZERO,ONE):ZERO)===0,'Dual combination does not equal the negative peak objective');
      demand(s.m.cmp(lower,peak)===0,'Dual lower bound does not meet the original primal objective');
      demand(feasible(rows,[...x,peak],s),'Original epigraph is not feasible');
    }
    return result(s,'PASS','Original allocation and stated certificate conclusion verified',{conclusion:raw.conclusion,report:out.report});
  });
}
