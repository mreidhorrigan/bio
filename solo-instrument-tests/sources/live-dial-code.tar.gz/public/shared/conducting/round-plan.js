// A round (Astra's CFM-025, tracker CF07: periodic-canon.js): a canon whose voices each sing the subject again as soon
// as they end it, every voice the subject, its answer or its inversion, each `delay` after the last, its period the
// subject's length. Only whole cycles are sung, each voice as many as end within its section -- a round's voices
// stopping one by one, as they entered (roundCycles). A conductor sings a round where it chooses one, its subject
// planned with its joins (canon-plan.js plannedSubject's `cycle`: each voice's leap from its last note to its first, and
// every two voices' motion there).
//
// Whether a round holds whole is checked in development, never while the music is made (the owner, 17 October 2026:
// "the show must go on"): roundHolds, the complete periodic material audited (auditPeriodicCanon) and its certificate
// checked (checkPeriodicCanon). Its contract the canon's rules: one note at a time a voice, its leaps within their
// leapMost, and no parallels between any two voices in the intervals they count perfect, banded by their weight on them
// (as stretto.js and fugue-cadence.js read them).
import {preparePeriodicCanon,auditPeriodicCanon,checkPeriodicCanon} from './periodic-canon.js';
import {compileCounterpointProfile} from './counterpoint-profile.js';
import {createPitchSpace,pitchFromNumber} from './pitch-spaces.js';
import {Q} from './canon-core.js';
import {exactOfNumber} from '../bounded-exact.js';
import {COUNTERPOINT} from './counterpoint.js';
import {fractionOf} from './exact-elongation.js';

const SPACE=createPitchSpace({id:'musebots-semitones',kind:'semitones'});
const modulo=(x,n)=>((x%n)+n)%n;
// (A time exact: the rational it is a float of, where it is one of a small denominator -- a third of a quarter in a
// 14/12 bar -- else its six decimals', as {n, d}: each note's time then the sum of the ones before it, exactly.)
const exact=x=>{const f=fractionOf(Math.abs(Number(x)));if(f)return {n:BigInt(Math.sign(Number(x))*f[0]),d:BigInt(f[1])};const q=Q(exactOfNumber(+Number(x).toFixed(6)));return {n:q.n,d:q.d}};

// Each voice's whole cycles in its section: as many of its subject (`period`, quarters) as end within `total` from its
// entry (`delays`, quarters).
export const roundCycles=({delays,period,total})=>delays.map(delay=>Math.max(0,Math.floor((total-delay)/period+1e-9)));

// `lines`: each voice's line as it sings the subject, from its own entry ([{pitch, start, length}], quarters: canon-plan.js
// voiceLines); `delays` each voice's entry (quarters); `period` the subject's length; `total` the section's (quarters);
// `rules` the canon's (counterpoint.js blendRules); `periodSemitones` its harmony's period. -> {status ('PASS', 'FAIL' or
// 'UNKNOWN'), reason, cycles (each voice's whole cycles)}.
export function roundHolds({lines,delays,period,total,rules,periodSemitones=12,budget={}}){
  const cycles=roundCycles({delays,period,total});
  if(lines.length<2||cycles.some(count=>count<2))return {status:'UNKNOWN',reason:'a voice with fewer than two whole cycles in its section: no round',cycles};
  const ids=lines.map((_,k)=>`v${k}`),periodCents=Math.round(periodSemitones*100),cents=x=>Number.isInteger(x)?x:`${Math.round(x*1000)}/1000`;
  const weight=Math.max(0,Math.min(1,Number(rules?.parallelPerfect)||0)),tolerance=cents(+(COUNTERPOINT.consonance.width*weight).toFixed(3));
  const perfect=[...new Set(COUNTERPOINT.consonance.perfect.map(c=>+modulo(c,periodCents).toFixed(3)))].map(cents);
  const clockDomain={id:'section-quarters',unit:'quarters',revision:1};
  try{
    const profile=compileCounterpointProfile({id:'round',version:1,pitchSpace:SPACE,clockDomain,voices:ids,rules:[{id:'monophony',type:'monophony',required:true},
      ...(Number(rules?.leapMost)>0?[{id:'leaps',type:'melodic-bound',required:true,maxCents:cents(+(rules.leapMost*100).toFixed(3))}]:[]),
      ...(weight>0?[{id:'parallels',type:'parallel-classes',required:true,pair:'all',periodCents,classes:perfect.map((center,k)=>({id:`perfect${k}`,center,tolerance}))}]:[])]});
    const series=lines.map((line,k)=>({id:`s${k}`,voiceId:ids[k],period:exact(period),phase:exact(delays[k]),
      events:line.map((note,i)=>({id:`n${i}`,t:exact(note.start),d:exact(note.length),pitch:pitchFromNumber(SPACE,+note.pitch.toFixed(6)).pitch}))}));
    const performance={id:'round',revision:0,extent:[exact(0),exact(total)],cycles:series.map((item,k)=>({seriesId:item.id,first:0,stop:cycles[k]})),
      introduction:{from:exact(0),to:exact(0),events:[]},ending:{from:exact(total),to:exact(total),events:[]}};
    const prepared=preparePeriodicCanon({id:'round',revision:0,inventoryComplete:true,pitchSpace:SPACE,clockDomain,dependencies:[],series,performance,profile},budget);
    if(prepared.status!=='PASS')return {status:'UNKNOWN',reason:prepared.reason??'its round not admitted',cycles};
    const audit=auditPeriodicCanon(prepared.prepared,budget);
    if(audit.status!=='PASS'){
      // (Its reason the rules it breaks, where its round is steady and where it begins and ends.)
      const failing=['steady','finite'].flatMap(part=>(audit.report?.[part]?.geometry?.checks??audit.report?.[part]?.checks??[]).filter(check=>check.status==='FAIL').map(check=>({part,rule:check.rule,time:check.time})));
      const broken=[...new Set(failing.map(check=>`${check.part} ${check.rule}`))];
      return {status:audit.status==='FAIL'?'FAIL':'UNKNOWN',reason:broken.length?`its rules broken: ${broken.join(', ')}`:audit.reason??`its round: ${audit.status}`,cycles,
        ...(failing.length?{where:failing.slice(0,8).map(check=>`${check.part} ${check.rule} at ${check.time}`)}:{})};
    }
    const checked=checkPeriodicCanon(prepared.prepared,audit.certificate,budget);
    if(checked.status!=='PASS'||checked.conclusion!=='PASS')return {status:'UNKNOWN',reason:`its certificate: ${checked.status}, ${checked.conclusion}`,cycles};
    return {status:'PASS',cycles};
  }catch(error){return {status:'UNKNOWN',reason:String(error?.message??error),cycles}}
}
