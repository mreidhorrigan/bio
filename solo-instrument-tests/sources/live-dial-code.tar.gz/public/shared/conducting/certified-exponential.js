// CFM-026 internal arithmetic helper: outward rational enclosures of the real exponential.
// The required charge callback belongs to trusted planning code. No host/RNG/Math.exp is called.
import {Refused,bitsOf} from '../bounded-exact.js';
import {dataRecord} from './contract-data.js';

const fail=message=>{throw new Refused(message,{kind:'arithmetic-budget'})};
const cap=n=>{if(bitsOf(n)>8192)fail('Exponential intermediate exceeds8192bits');return n};
const divideUp=(n,d)=>n/d+(n%d?1n:0n);
function fields(value,keys){
  if(!dataRecord(value)||Object.keys(value).length!==keys.length||keys.some(k=>!Object.hasOwn(value,k)))
    throw new Refused('Exact exponential requires plain complete data fields');
}

/** Returns lower/scale <= exp(-x) <= upper/scale, with symbolic positivity for every finite x. */
export function expNegativeDyadic(x,options){
  fields(x,['n','d']);fields(options,['precisionBits','terms','charge']);
  let {n,d}=x;const {precisionBits,terms,charge}=options;
  if(typeof n!=='bigint'||typeof d!=='bigint'||n<0n||d<=0n)throw new Refused('Nonnegative exact exponent required');
  cap(n);cap(d);
  if(!Number.isSafeInteger(precisionBits)||precisionBits<16||precisionBits>256||!Number.isSafeInteger(terms)||terms<2||terms>128||terms%2)
    throw new Refused('Declare16..256 precision bits and an even degree2..128');
  if(typeof charge!=='function')throw new Refused('A trusted work counter is required');
  charge();const scale=1n<<BigInt(precisionBits),result=(lower,upper,squarings,method)=>Object.freeze({lower,upper,scale,precisionBits,terms,squarings,method});
  if(!n)return result(scale,scale,0,'exact-zero');
  // e>2 implies exp(-x) <=2^-precisionBits. Lower zero is a bound, not loss of mathematical support.
  if(n/d>=BigInt(precisionBits))return result(0n,1n,0,'large-argument-bound');
  let squarings=0;
  while(n>d){
    charge();if(++squarings>8)fail('Unexpected range-reduction allowance');
    if(n%2n===0n)n/=2n;else d=cap(d*2n);
  }
  let termLow=scale,termHigh=scale,sumLow=scale,sumHigh=scale,lower,upper;
  for(let j=1;j<=terms+1;j++){
    charge(5);const divisor=cap(d*BigInt(j));
    termLow=cap(termLow*n)/divisor;termHigh=divideUp(cap(termHigh*n),divisor);
    if(j%2){sumLow=cap(sumLow-termHigh);sumHigh=cap(sumHigh-termLow)}
    else{sumLow=cap(sumLow+termLow);sumHigh=cap(sumHigh+termHigh)}
    if(j===terms)upper=sumHigh;if(j===terms+1)lower=sumLow;
  }
  lower=lower<0n?0n:lower;upper=upper>scale?scale:upper;
  if(lower>upper||upper<0n||lower>scale)throw new Error('Exponential enclosure invariant');
  for(let i=0;i<squarings;i++){
    charge(2);lower=cap(lower*lower)/scale;upper=divideUp(cap(upper*upper),scale);
    if(upper>scale)upper=scale;
  }
  return result(lower,upper,squarings,'outward-alternating-maclaurin-and-squaring');
}
