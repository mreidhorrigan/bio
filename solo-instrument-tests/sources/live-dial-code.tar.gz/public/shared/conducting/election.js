// Who, among peers of one kind, does a shared job: one caster among the ManageBOTs of a networked ensemble, one
// conductor among the conductorbots of a group, the rest standing by (Musebots 3.0, docs/MUSEBOTS_3.md, "The network"; the
// owner, 30 September 2026: "Make sure manage_clodbots still coordinate with each other across networks").
//
// No message is sent to agree. Every peer says it is there (its presence, once a bar or so), every peer keeps what it
// has heard, and every peer runs the same rule over it, so all reach the same choice from the same evidence (as the
// form bots agree: research/MUSEBOTS_MULTINET_CONDUCTORBOT_IMPLEMENTATION_PLAN.md, "designate one selector"). The rule
// keeps the incumbent: the peer that began the job first keeps it, and a peer arriving later, from however near or far,
// never takes it over mid-piece; peers that began together are ordered by id. A peer not heard for `graceBars` has gone
// (its host dropped, its connection lost), and the job passes to the next, which carries on from what it heard of the
// work so far.
//
// Ids qualified by a host (`host::bot`, multinet-wire.js qualifyBot) say where a peer is: hostOf.
export const hostOf=id=>typeof id==='string'&&id.includes('::')?id.slice(0,id.indexOf('::')):null;
// Ours: a bar's grace is too little for a network's carried beat (up to 8 s: ensemble-conductor.js HANDOVER_SECONDS),
// four is a few seconds more in any meter a band plays.
export const ELECTION=Object.freeze({graceBars:4});

export class Election{
  constructor({self=null,graceBars=ELECTION.graceBars}={}){this.self=self;this.graceBars=graceBars;this.peers=new Map}
  setSelf(id){this.self=id;return this}
  // A peer heard: {id, bar (when heard), since (the bar it began the job, or null), candidate (it would do the job),
  // ...anything else it says}.
  hear({id,bar,since=null,candidate=true,...rest}){
    if(typeof id!=='string'||!id)return;
    const known=this.peers.get(id);
    // (A peer's beginning is its first: a later word never moves it.)
    const began=known?.since??null;
    this.peers.set(id,{...known,...rest,id,bar:Number(bar)||0,since:began??(Number.isFinite(since)?since:null),candidate:Boolean(candidate)});
  }
  // A peer's own record of having begun the job at a bar (its first casting, its first section), if it had not.
  began(id,bar){const peer=this.peers.get(id);if(peer&&peer.since===null)peer.since=bar}
  leave(id){this.peers.delete(id)}
  // The peers heard within the grace, oneself always among them.
  live(bar,filter=()=>true){
    const out=[...this.peers.values()].filter(peer=>(peer.id===this.self||Number(bar)-peer.bar<=this.graceBars)&&filter(peer));
    return out;
  }
  // The one who does the job now: of the live candidates, the first to begin it, then the lowest id.
  elected(bar,filter=()=>true){
    const order=(a,b)=>(a.since??Infinity)-(b.since??Infinity)||(a.id<b.id?-1:a.id>b.id?1:0);
    return this.live(bar,peer=>peer.candidate&&filter(peer)).sort(order)[0]?.id??null;
  }
}
