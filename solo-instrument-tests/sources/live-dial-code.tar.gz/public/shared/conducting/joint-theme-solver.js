/**
 * Joint theme finite solver, adopted from the inverse-fugue reference. 2026-10-04.
 * Dependency-free ES module: Node / browser Worker.
 * Fixed rational rhythms; finite safe-integer pitch coordinates; explicit scenarios.
 * Adapted candidate: shared end-to-end budgets, finite catalogue pitch adapter.
 * This is NOT a complete historical fugue grammar. Musical predicates are caller-owned.
 */
const integer = (x, label = 'integer') => {
  if (!Number.isSafeInteger(x)) throw new TypeError(`${label} must be a safe integer`);
  return x;
};
const checked = x => integer(x, 'arithmetic result');
const absBig = x => x < 0n ? -x : x;
const gcd = (a, b) => { a = absBig(a); b = absBig(b); while (b) [a,b] = [b,a%b]; return a; };
export class Rational {
  constructor(n, d = 1n) {
    if (typeof n === 'number') integer(n, 'rational numerator');
    if (typeof d === 'number') integer(d, 'rational denominator');
    n = BigInt(n); d = BigInt(d);
    if (!d) throw new RangeError('zero denominator');
    if (d < 0n) { n = -n; d = -d; }
    const g = gcd(n, d); this.n = n/g; this.d = d/g; Object.freeze(this);
  }
  static of(x) {
    if (x instanceof Rational) return x;
    if (typeof x === 'number') return new Rational(integer(x));
    if (typeof x === 'bigint') return new Rational(x);
    if (typeof x === 'string' && x.length > 256) throw new RangeError('rational literal exceeds admission limit');
    if (typeof x !== 'string' || !/^[+-]?\d+(\/\d+)?$/.test(x))
      throw new TypeError('time must be an integer or a rational string, e.g. "2/3"');
    const [n,d = '1'] = x.split('/'); return new Rational(n,d);
  }
  add(x) { x = Rational.of(x); return new Rational(this.n*x.d+x.n*this.d, this.d*x.d); }
  mul(x) { x = Rational.of(x); return new Rational(this.n*x.n,this.d*x.d); }
  cmp(x) { x = Rational.of(x); const d = this.n*x.d-x.n*this.d; return d < 0n ? -1 : d > 0n ? 1 : 0; }
  toString() { return this.d === 1n ? `${this.n}` : `${this.n}/${this.d}`; }
  toJSON() { return this.toString(); }
}
const Q = Rational.of;
export const mod = (x,n) => { integer(x); integer(n); if(n<=0) throw new RangeError('modulus'); const r=x%n; return r===0 ? 0 : r<0 ? r+n : r; };
const nameOK = x => typeof x === 'string' && /^[A-Za-z0-9_.-]+$/.test(x);
const now = () => globalThis.performance?.now() ?? Date.now();

/** Finite relations use positional tuples; scopes must contain distinct variable IDs. */
export function makeModel(domains) {
  const map = new Map();
  if(Object.keys(domains).length>LIMITS.variables) throw new RangeError('variable admission');
  for (const [name, values] of Object.entries(domains)) {
    if (!Array.isArray(values)) throw new TypeError(`domain ${name}`);
    if(values.length>LIMITS.domain) throw new RangeError('domain admission');
    map.set(name, [...new Set(values.map(v => integer(v, name)))]);
  }
  return { domains: map, constraints: [], costs: [] };
}
function addFactor(model, target, id, scope, evaluate, group) {
  if (new Set(scope).size !== scope.length) throw new Error('factor scope must be deduplicated');
  for (const v of scope) if (!model.domains.has(v)) throw new Error(`unknown variable ${v}`);
  if (typeof evaluate !== 'function') throw new TypeError('factor evaluator');
  if(model[target].length>=32768) throw new RangeError('factor admission');
  if (model[target].some(f => f.id === id)) throw new Error(`duplicate factor ID ${id}`);
  const factor = { id, scope: [...scope], evaluate, group: group ?? 'base' };
  model[target].push(factor); return factor;
}
export const addConstraint = (m,id,s,f,g) => addFactor(m,'constraints',id,s,f,g);
export const addCost = (m,id,s,f) => addFactor(m,'costs',id,s,f);
function bool(x) { if(typeof x !== 'boolean') throw new TypeError('predicates must return boolean'); return x; }
function tuples(scope, domains, visit) {
  const t = new Array(scope.length);
  function rec(i) {
    if (i === scope.length) { visit(t); return; }
    for (const v of domains.get(scope[i])) { t[i] = v; rec(i+1); }
  }
  rec(0);
}
class Stop extends Error { constructor(reason) { super(reason); this.reason = reason; } }
// Private token prevents callers from passing an unvalidated budget object.
const SESSION = Symbol('synthesis budget');
const newStats = () => ({nodes:0,checks:0,work:0,failures:0,removed:0,boundPrunes:0});
function budget(options = {}) {
  if(options[SESSION]) return options[SESSION];
  const stats=newStats(), started=now();
  const limits={nodes:options.maxNodes??100_000,checks:options.maxChecks??2_000_000,work:options.maxWork??2_000_000};
  for(const [name,n] of Object.entries(limits)) if(!Number.isSafeInteger(n)||n<0) throw new RangeError(name);
  const timeMs=options.timeMs??5000;
  if(!Number.isFinite(timeMs)||timeMs<0) throw new RangeError('timeMs');
  const check=kind=>{
    if(options.signal?.aborted) throw new Stop('cancelled');
    if(now()-started>=timeMs) throw new Stop('time');
    const key=kind==='node'?'nodes':kind==='evaluation'?'checks':kind;
    if(key) {
      if(stats[key]>=limits[key]) throw new Stop(key);
      if(key!=='work'&&stats.work>=limits.work) throw new Stop('work');
      stats[key]++; if(key!=='work') stats.work++;
    }
  };
  const charge=(amount=1)=>{
    check(); if(!Number.isSafeInteger(amount)||amount<0) throw new RangeError('work charge');
    if(amount>limits.work-stats.work) throw new Stop('work');
    stats.work+=amount;
  };
  return {check,charge,remaining:()=>limits.work-stats.work,stats,elapsed:()=>now()-started};
}
function evaluate(fn, args, b) {
  b?.check('evaluation'); const value=fn(...args); b?.check(); return value;
}
const summary=b=>({...b.stats,elapsedMs:b.elapsed()});
const unknown=(b,reason)=>({status:'UNKNOWN',assignment:null,reason,searchComplete:false,stats:summary(b)});
const LIMITS=Object.freeze({variables:128,domain:128,scenarios:64,events:512,boundaries:2048});
export const INVERSE_LIMITS=LIMITS;
/** Exact generalized arc consistency, implemented transparently rather than with table caches. */
function propagate(model, domains, b, stats) {
  if([...domains.values()].some(d => !d.length)) return false;
  let changed = true;
  while(changed) {
    changed = false;
    for(const f of model.constraints) {
      b.check(); const support = f.scope.map(() => new Set()); let any = false;
      tuples(f.scope, domains, t => {
        if(bool(evaluate(f.evaluate,[t],b))) { any = true; t.forEach((v,i) => support[i].add(v)); }
      });
      if(!any) { stats.failures++; return false; }
      f.scope.forEach((v,i) => {
        const old = domains.get(v), next = old.filter(x => support[i].has(x));
        if(next.length < old.length) { stats.removed += old.length-next.length; domains.set(v,next); changed = true; }
      });
    }
  }
  return true;
}
export function propagateOnly(model, options = {}) {
  const b=budget(options),stats=b.stats;
  const domains = new Map([...model.domains].map(([v,d]) => [v,[...d]]));
  try { return {status:propagate(model,domains,b,stats) ? 'CONSISTENT' : 'UNSAT', domains:Object.fromEntries(domains),stats}; }
  catch(e) { if(!(e instanceof Stop)) throw e; return {status:'UNKNOWN',reason:e.reason,domains:Object.fromEntries(domains),stats}; }
}
function independentFactorBound(model, domains, b) {
  let total = 0;
  for(const f of model.costs) {
    let best = Infinity;
    tuples(f.scope, domains, t => { best = Math.min(best,integer(evaluate(f.evaluate,[t],b),'cost')); });
    if(best === Infinity) return Infinity;
    total = checked(total+best);
  }
  return total;
}
/**
 * Fail-first finite search with GAC and optional exact factor-cost branch-and-bound.
 * Deadlines are cooperative, not hard real-time guarantees; do not run on an audio thread.
 * `enumerate` is diagnostic and cannot be combined with optimization.
 */
export function solveFinite(model, options = {}) {
  const optimize = options.optimize ?? false, enumerate = options.enumerate ?? false;
  if(optimize && enumerate) throw new Error('choose optimization or enumeration');
  const b=budget(options),stats=b.stats;
  if(enumerate && (!Number.isSafeInteger(options.maxSolutions??10_000)||(options.maxSolutions??10_000)<1)) throw new RangeError('maxSolutions');
  const degrees = new Map([...model.domains.keys()].map(v => [v,0]));
  for(const f of model.constraints) for(const v of f.scope) degrees.set(v,degrees.get(v)+1);
  let best = null, bestCost = Infinity, complete = true, reason = 'exhausted'; const solutions = [];
  function dfs(domains) {
    b.check('node');
    if(!propagate(model,domains,b,stats)) return;
    const lb = optimize ? independentFactorBound(model,domains,b) : 0;
    if(optimize && best !== null && lb >= bestCost) { stats.boundPrunes++; return; }
    let variable;
    for(const [v,d] of domains) if(d.length>1 && (variable === undefined ||
      d.length<domains.get(variable).length || (d.length===domains.get(variable).length && degrees.get(v)>degrees.get(variable)))) variable = v;
    if(variable === undefined) {
      const assignment = Object.fromEntries([...domains].map(([v,d]) => [v,d[0]]));
      // Complete assignments have just been checked against every relation by GAC.
      // A residual, complete-assignment predicate can keep expensive whole-family checks out of GAC.
      // Refusal must throw, never return false: only a fully established violation refutes an assignment.
      if(options.accept&&!bool(evaluate(options.accept,[assignment],b))) { stats.failures++; return; }
      if(!optimize || lb < bestCost) { best = assignment; bestCost = lb; }
      if(enumerate) {
        solutions.push(assignment);
        if(solutions.length >= (options.maxSolutions ?? 10_000)) throw new Stop('solutions');
      }
      if(!optimize && !enumerate) throw new Stop('first-witness');
      return;
    }
    const values = [...domains.get(variable)];
    const given = options.hint?.[variable], hints=Array.isArray(given)?given:[given];
    const rank=value=>{const i=hints.indexOf(value);return i<0?hints.length:i};
    values.sort((a,b)=>rank(a)-rank(b));
    for(const value of values) {
      const child = new Map([...domains].map(([v,d]) => [v,[...d]])); child.set(variable,[value]); dfs(child);
    }
  }
  try { dfs(new Map([...model.domains].map(([v,d]) => [v,[...d]]))); }
  catch(e) { if(!(e instanceof Stop)) throw e; complete = false; reason = e.reason; }
  return { status: best !== null ? (optimize && complete ? 'OPTIMAL' : 'FEASIBLE') : (complete ? 'UNSAT' : 'UNKNOWN'),
    assignment:best, cost:best === null || !optimize ? null : bestCost,
    searchComplete:complete, reason, ...(enumerate ? {solutions} : {}), stats:{...stats,elapsedMs:b.elapsed()} };
}
export function validateFactors(model, assignment) {
  const violations = [];
  for(const [v,d] of model.domains) if(!d.includes(assignment?.[v])) violations.push(`domain:${v}`);
  if(violations.length) return {ok:false,violations};
  for(const f of model.constraints) if(!bool(f.evaluate(f.scope.map(v => assignment[v])))) violations.push(f.id);
  return {ok:!violations.length,violations};
}

/** One session for a caller's preparation, one finite search, residual checks and publication.
 * Nested bounded modules reserve their allowance before entry. Only a valid workUsed report refunds work.
 * Unknown evidence aborts this feasibility search; no partially checked assignment is published.
 */
export function runBudgetedFinite({build,accept,publish},options={}) {
  const b=budget(options);
  const control=Object.freeze({
    charge:b.charge,check:()=>b.check(),remaining:b.remaining,
    refuse:reason=>{throw new Stop(reason)},
    bounded(cap,operation){
      if(!Number.isSafeInteger(cap)||cap<=0) throw new RangeError('nested allowance');
      const allowance=Math.min(cap,b.remaining()); if(!allowance) throw new Stop('work');
      b.charge(allowance);
      const out=operation(allowance),used=out?.workUsed;
      if(!Number.isSafeInteger(used)||used<0||used>allowance) throw new Stop('invalid nested work report');
      b.stats.work-=allowance-used; b.check(); return out;
    }
  });
  try {
    b.check(); const built=build(control); b.check();
    const result=solveFinite(built.model,{...options,[SESSION]:b,optimize:false,enumerate:false,
      hint:built.hint,accept:assignment=>accept(assignment,built,control)});
    if(!result.assignment) return {...result,stats:summary(b)};
    b.check(); const output=publish(result.assignment,built,control); b.check();
    return {...result,...output,status:'SAT',stats:summary(b)};
  } catch(error) {
    return unknown(b,error instanceof Stop?error.reason:String(error?.message??error));
  }
}

function sourceEvents(name, source, b) {
  if(!nameOK(name) || !Array.isArray(source.notes) || !source.notes.length) throw new Error('nonempty named source required');
  if(source.notes.length>LIMITS.variables) throw new RangeError('source event admission');
  let previousEnd = Q(0);
  return source.notes.map((note,i) => {
    b?.check('work');
    const onset = Q(note.onset), duration = Q(note.duration);
    if(onset.cmp(0)<0 || duration.cmp(0)<=0 || onset.cmp(previousEnd)<0) throw new Error(`invalid monophonic rhythm ${name}:${i}`);
    const end = onset.add(duration); previousEnd = end;
    return {root:`${name}:${i}`,source:name,index:i,onset,end,duration};
  });
}
/** Transform = sign*p + shift, or a deterministic caller-owned map(p,index).
 * A lookup map can represent a FIXED answer policy. It does not infer tonal answers.
 */
function expand(spec, b) {
  if(!Array.isArray(spec.scenarios)||spec.scenarios.length>LIMITS.scenarios) throw new RangeError('scenario admission');
  const sources = new Map(Object.entries(spec.sources).map(([name,s]) => [name,sourceEvents(name,s,b)]));
  const seen = new Set();
  return spec.scenarios.map(scenario => {
    b?.check('work');
    if(!nameOK(scenario.id) || seen.has(scenario.id)) throw new Error('unique scenario ID required'); seen.add(scenario.id);
    const voices = new Set(); const events = [];
    if(!Array.isArray(scenario.entries)||scenario.entries.length>LIMITS.events) throw new RangeError('entry admission');
    for(const entry of scenario.entries) {
      b?.check('work');
      if(!nameOK(entry.id) || voices.has(entry.id)) throw new Error('unique monophonic entry ID required'); voices.add(entry.id);
      const src = sources.get(entry.source); if(!src) throw new Error('unknown source');
      const rate = Q(entry.rate ?? 1), delay = Q(entry.delay ?? 0);
      if(rate.cmp(0)<=0 || delay.cmp(0)<0) throw new Error('positive rate and nonnegative delay required');
      const sign = entry.sign ?? 1, shift = entry.shift ?? 0;
      if(![1,-1].includes(sign)) throw new Error('sign must be +/-1'); integer(shift);
      if(entry.map && (entry.sign !== undefined || entry.shift !== undefined)) throw new Error('map replaces sign/shift');
      if(events.length+src.length>LIMITS.events) throw new RangeError('expanded event admission');
      for(const e of src) {
        b?.check('work');
        const transform = entry.map ? p => integer(entry.map(p,e.index),'mapped pitch') : p => checked(sign*p+shift);
        events.push({...e, voice:entry.id, onset:delay.add(rate.mul(e.onset)),end:delay.add(rate.mul(e.end)),transform,register:entry.register});
      }
    }
    if((scenario.boundaries?.length??0)>LIMITS.boundaries) throw new RangeError('boundary admission');
    const boundaryMap = new Map();
    for(const t of [...events.flatMap(e => [e.onset,e.end]),...(scenario.boundaries ?? []).map(Q)]) boundaryMap.set(t.toString(),t);
    if(boundaryMap.size>LIMITS.boundaries) throw new RangeError('boundary admission');
    const boundaries = [...boundaryMap.values()].sort((a,b) => a.cmp(b));
    const frames = [];
    for(let i=0;i+1<boundaries.length;i++) {
      b?.check('work');
      const time=boundaries[i], end=boundaries[i+1];
      frames.push({time,end,active:events.filter(e => { b?.check('work'); return e.onset.cmp(time)<=0 && e.end.cmp(time)>0; })});
    }
    return {...scenario,events,frames};
  });
}
/** Adds an occurrence relation after substitution; repeated source roots are NOT independent. */
function pullback(model,id,events,predicate,context,group) {
  const scope = [...new Set(events.map(e => e.root))]; const indices = events.map(e => scope.indexOf(e.root));
  addConstraint(model,id,scope,t => predicate(events.map((e,i) => e.transform(t[indices[i]])),context),group);
}
function sourceConstraints(model,spec,b) {
  for(const [name,source] of Object.entries(spec.sources)) {
    sourceEvents(name,source,b);
    for(let i=1;i<source.notes.length;i++) if(source.maxLeap !== undefined || source.noRepeat) {
      const cap = source.maxLeap ?? Infinity;
      if(cap!==Infinity && (!Number.isSafeInteger(cap)||cap<0)) throw new RangeError('maxLeap');
      addConstraint(model,`source:${name}:${i}`,[`${name}:${i-1}`,`${name}:${i}`],([a,b]) =>
        (cap===Infinity || absBig(BigInt(b)-BigInt(a))<=BigInt(cap)) && (!source.noRepeat || a!==b));
    }
  }
  for(const f of spec.rootConstraints ?? []) { b?.check('work'); addConstraint(model,f.id,f.scope,f.test,f.group); }
}
/**
 * Pair predicates see two pitches. Whole-sonority predicates see ALL pitches in a frame.
 * Bass-dependent harmony belongs in `sonority`, not in an allegedly pair-local rule.
 * Frame/rule contexts contain exact time, duration boundaries, voice IDs and root IDs.
 */
export function compileThemeProblem(spec, options={}) {
  const b=budget(options); b.check('work');
  if(!spec.sources || !Array.isArray(spec.scenarios)) throw new TypeError('sources and scenarios');
  const domains = Object.create(null); let count=0;
  for(const [name,s] of Object.entries(spec.sources)) {
    sourceEvents(name,s,b);
    s.notes.forEach((n,i) => {
      if(++count>LIMITS.variables||!Array.isArray(n.domain)||n.domain.length>LIMITS.domain) throw new RangeError('finite domain admission');
      domains[`${name}:${i}`] = n.domain;
    });
  }
  const model=makeModel(domains); sourceConstraints(model,spec,b);
  const scenarios=expand(spec,b), profile=spec.profile ?? {};
  for(const scenario of scenarios) {
    const group=scenario.id;
    for(const event of scenario.events) if(event.register) {
      const [lo,hi]=event.register; integer(lo); integer(hi);
      pullback(model,`${group}:register:${event.voice}:${event.index}`,[event],([p]) => p>=lo && p<=hi,{},group);
    }
    for(let f=0;f<scenario.frames.length;f++) {
      b.check('work');
      const frame=scenario.frames[f];
      const context={scenario:group,time:frame.time,end:frame.end,events:frame.active};
      for(let i=0;i<frame.active.length;i++) for(let j=i+1;j<frame.active.length;j++) if(profile.pair) {
        b.check('work');
        const pair=[frame.active[i],frame.active[j]];
        pullback(model,`${group}:pair:${f}:${i}:${j}`,pair,profile.pair,{...context,events:pair},group);
      }
      if(profile.sonority) pullback(model,`${group}:sonority:${f}`,frame.active,profile.sonority,context,group);
      if(f && profile.motion) {
        const before=scenario.frames[f-1];
        // The adjacent empty frames are retained: no fictitious parallels across a rest.
        const common=before.active.filter(e => frame.active.some(x => x.voice===e.voice));
        for(let i=0;i<common.length;i++) for(let j=i+1;j<common.length;j++) {
          b.check('work');
          const a=common[i], other=common[j], c=frame.active.find(e => e.voice===a.voice),d=frame.active.find(e => e.voice===other.voice);
          const events=[a,other,c,d];
          pullback(model,`${group}:motion:${f}:${i}:${j}`,events,profile.motion,
            {scenario:group,time:frame.time,previousTime:before.time,events},group);
        }
      }
    }
  }
  for(const c of spec.costs ?? []) { b.check('work'); addCost(model,c.id,c.scope,c.cost); }
  b.check(); return {model,scenarios,spec};
}
export function renderAssignment(spec, assignment, options={}) {
  const b=budget(options); b.check('work');
  const rendered=expand(spec,b).map(s => ({id:s.id,notes:s.events.map(e => ({voice:e.voice,source:e.source,index:e.index,
    root:e.root,onset:e.onset.toString(),end:e.end.toString(),pitch:evaluate(e.transform,[assignment[e.root]],b)}))}));
  b.check(); return rendered;
}
/** Rendering-based audit does not invoke compiled factors. Uses exact midpoints per frame.
 * Shares transformation primitives and profile predicates with compiler: NOT an independent
 * implementation of the musical rules. External brute-force tests add a separate oracle.
 */
export function auditRendered(spec, assignment, options={}) {
  const b=budget(options); b.check('work');
  const violations=[], profile=spec.profile ?? {};
  for(const [name,s] of Object.entries(spec.sources)) {
    s.notes.forEach((n,i) => { if(!n.domain.includes(assignment?.[`${name}:${i}`])) violations.push(`domain:${name}:${i}`); });
    for(let i=1;i<s.notes.length;i++) {
      const a=assignment?.[`${name}:${i-1}`],b=assignment?.[`${name}:${i}`];
      if(!Number.isSafeInteger(a)||!Number.isSafeInteger(b)) continue;
      if((s.maxLeap!==undefined && s.maxLeap!==Infinity && absBig(BigInt(b)-BigInt(a))>BigInt(s.maxLeap)) || (s.noRepeat && a===b)) violations.push(`source:${name}:${i}`);
    }
  }
  if(violations.length) return {ok:false,violations};
  for(const r of spec.rootConstraints ?? []) if(!bool(evaluate(r.test,[r.scope.map(v => assignment[v])],b))) violations.push(r.id);
  for(const scenario of expand(spec,b)) {
    for(const e of scenario.events) if(e.register) {
      const p=evaluate(e.transform,[assignment[e.root]],b); if(p<e.register[0] || p>e.register[1]) violations.push(`${scenario.id}:register`);
    }
    let prev=null;
    for(const frame of scenario.frames) {
      b.check('work');
      const mid=frame.time.add(frame.end).mul('1/2');
      const active=scenario.events.filter(e => e.onset.cmp(mid)<0 && mid.cmp(e.end)<0);
      const pitch=e => evaluate(e.transform,[assignment[e.root]],b);
      const ctx={scenario:scenario.id,time:frame.time,end:frame.end,events:active};
      for(let i=0;i<active.length;i++) for(let j=i+1;j<active.length;j++) if(profile.pair &&
        !bool(evaluate(profile.pair,[[pitch(active[i]),pitch(active[j])],{...ctx,events:[active[i],active[j]]}],b))) violations.push(`${scenario.id}:pair@${frame.time}`);
      if(profile.sonority && !bool(evaluate(profile.sonority,[active.map(pitch),ctx],b))) violations.push(`${scenario.id}:sonority@${frame.time}`);
      if(prev && profile.motion) {
        const common=prev.active.filter(e => active.some(x => x.voice===e.voice));
        for(let i=0;i<common.length;i++) for(let j=i+1;j<common.length;j++) {
          const events=[common[i],common[j],active.find(e => e.voice===common[i].voice),active.find(e => e.voice===common[j].voice)];
          if(!bool(evaluate(profile.motion,[events.map(pitch),{scenario:scenario.id,time:frame.time,previousTime:prev.time,events}],b))) violations.push(`${scenario.id}:motion@${frame.time}`);
        }
      }
      prev={active,time:frame.time};
    }
  }
  b.check(); return {ok:!violations.length,violations};
}
export function synthesize(spec, options={}) {
  const b=budget(options), shared={...options,[SESSION]:b};
  try {
    const {model}=compileThemeProblem(spec,shared), result=solveFinite(model,shared);
    if(!result.assignment) return {...result,stats:summary(b)};
    const audit=auditRendered(spec,result.assignment,shared);
    if(!audit.ok) throw new Error(`compiler/audit disagreement: ${audit.violations.join(', ')}`);
    const rendered=renderAssignment(spec,result.assignment,shared); b.check();
    return {...result,audit,rendered,variables:model.domains.size,constraints:model.constraints.length,stats:summary(b)};
  } catch(e) { if(!(e instanceof Stop)) throw e; return unknown(b,e.reason); }
}

/** Preprocessor for chosen signed-affine equalities v = sign*u + shift.
 * Keeps finite root values consistent with every path, cycle, and domain.
 * Domains alone are not the whole relation: retain equations during subsequent search.
 */
export function signedEqualityDomains(domains, equations) {
  if(!Array.isArray(equations)||equations.length>4096) throw new RangeError('equality admission');
  const model=makeModel(domains), adjacency=new Map([...model.domains.keys()].map(v => [v,[]]));
  for(const {u,v,sign=1,shift=0} of equations) {
    if(!adjacency.has(u)||!adjacency.has(v)||![1,-1].includes(sign)) throw new Error('invalid signed equality'); integer(shift);
    adjacency.get(u).push({v,sign,shift}); adjacency.get(v).push({v:u,sign,shift:checked(-sign*shift)});
  }
  const expressions=new Map(), out=Object.create(null),components=[];
  for(const root of model.domains.keys()) if(!expressions.has(root)) {
    expressions.set(root,{a:1,b:0}); const queue=[root], members=[];
    while(queue.length) {
      const u=queue.pop(); members.push(u); const e=expressions.get(u);
      for(const edge of adjacency.get(u)) if(!expressions.has(edge.v)) {
        expressions.set(edge.v,{a:edge.sign*e.a,b:checked(edge.sign*e.b+edge.shift)}); queue.push(edge.v);
      }
    }
    let roots=[...model.domains.get(root)];
    roots=roots.filter(r => members.every(v => {
      const e=expressions.get(v),x=checked(e.a*r+e.b);
      return model.domains.get(v).includes(x) && adjacency.get(v).every(edge => {
        const dest=expressions.get(edge.v); return checked(dest.a*r+dest.b)===checked(edge.sign*x+edge.shift);
      });
    }));
    if(!roots.length) return {status:'UNSAT',component:members};
    for(const v of members) { const e=expressions.get(v); out[v]=roots.map(r => checked(e.a*r+e.b)); }
    components.push({root,values:roots,members});
  }
  return {status:'CONSISTENT',domains:out,components,expressions:Object.fromEntries(expressions)};
}

/** Deletion-based subset-minimal requirement-group core. Never learns from UNKNOWN.
 * With unlimited completed subsolves, `minimal:true` means inclusion-minimal, not minimum size.
 */
export function diagnoseGroups(model, options={}) {
  const b=budget(options), shared={...options,[SESSION]:b,optimize:false,enumerate:false};
  const groups=[...new Set(model.constraints.filter(f=>f.group!=='base').map(f=>f.group))];
  const subset=gs=>({...model,costs:[],constraints:model.constraints.filter(f=>f.group==='base'||gs.includes(f.group))});
  const initial=solveFinite(subset(groups),shared);
  if(initial.status!=='UNSAT') return {status:initial.status,core:null,minimal:false,stats:summary(b)};
  const base=solveFinite(subset([]),shared);
  if(base.status==='UNSAT') return {status:'UNSAT',core:[],minimal:true,reason:'base-infeasible',stats:summary(b)};
  let core=[...groups],minimal=base.status==='FEASIBLE',reason='completed';
  for(const g of groups) {
    const trial=core.filter(x=>x!==g),r=solveFinite(subset(trial),shared);
    if(r.status==='UNSAT') core=trial;
    else if(r.status==='UNKNOWN') { minimal=false; reason=r.reason; break; }
  }
  return {status:'UNSAT',core,minimal,reason,stats:summary(b)};
}

/**
 * Lazy all-required-scenarios synthesis (finite counterexample-guided refinement).
 * Every rejected candidate adds the ENTIRE failed scenario to the next synthesis model.
 * This reference rebuilds models, rather than claiming incremental CP-SAT clause retention.
 * Only fully audited candidates may be returned as FEASIBLE / OPTIMAL.
 * No scenario-local existential completion oracle is implemented here.
 */
export function synthesizeLazy(spec, options={}) {
  if(options.enumerate) throw new Error('lazy mode does not enumerate all solutions');
  const b=budget(options),shared={...options,[SESSION]:b},learned=new Set(options.seedScenarios??[]);
  let rounds=0;
  try {
    // Validate the entire explicit family, including IDs omitted from the first relaxation.
    expand(spec,b);
    const known=new Set(spec.scenarios.map(s=>s.id));
    for(const id of learned) if(!known.has(id)) throw new Error(`unknown seed scenario ${id}`);
    while(true) {
      b.check('work');
      const partial={...spec,scenarios:spec.scenarios.filter(s=>learned.has(s.id))};
      const compiled=compileThemeProblem(partial,shared); rounds++;
      const r=solveFinite(compiled.model,shared);
      if(r.status==='UNSAT') return {...r,rounds,learnedScenarios:[...learned],stats:summary(b)};
      if(!r.assignment) return {...unknown(b,r.reason),rounds,learnedScenarios:[...learned]};
      let failure=null;
      const audits=[];
      if(!spec.scenarios.length) {
        const base=auditRendered(spec,r.assignment,shared);
        if(!base.ok) throw new Error('compiler/base audit disagreement');
        audits.push(base);
      }
      for(const scenario of spec.scenarios) {
        const audit=auditRendered({...spec,scenarios:[scenario]},r.assignment,shared);
        audits.push({scenario:scenario.id,...audit});
        if(!audit.ok) {failure=scenario.id;break;}
      }
      if(failure===null) {
        // Same objective + relaxed optimum + complete full-family audit => full optimum.
        const rendered=renderAssignment(spec,r.assignment,shared); b.check();
        return {...r,audit:{ok:true,violations:[],scenarios:audits},rendered,rounds,
          learnedScenarios:[...learned],validatedScenarios:spec.scenarios.map(s=>s.id),stats:summary(b)};
      }
      if(learned.has(failure)) throw new Error(`compiler/audit disagreement in ${failure}`);
      learned.add(failure);
    }
  } catch(e) {
    if(!(e instanceof Stop)) throw e;
    return {...unknown(b,e.reason),rounds,learnedScenarios:[...learned]};
  }
}

/**
 * Finite pitch catalogue: IDs are opaque, never musical intervals. Input/output
 * pitches are the original finite Number values; caller pitch maps are tabulated.
 * This preserves the declared Number semantics, not exact acoustic frequencies.
 */
function encodeCatalogue(spec,b) {
  const values=new Set(),tables=new Map();
  const number=p=>{if(typeof p!=='number'||!Number.isFinite(p)||Object.is(p,-0)) throw new TypeError('finite pitch with canonical positive zero required');return p;};
  const include=p=>{b.check('work');values.add(number(p));if(values.size>16384) throw new RangeError('pitch catalogue admission');return p;};
  const sourceEntries=Object.entries(spec.sources??{});
  if(sourceEntries.length>LIMITS.variables||!Array.isArray(spec.scenarios)||spec.scenarios.length>LIMITS.scenarios) throw new RangeError('catalogue admission');
  let count=0;
  for(const [name,s] of sourceEntries) {
    sourceEvents(name,s,b);
    for(const n of s.notes) {
      if(++count>LIMITS.variables||!Array.isArray(n.domain)||n.domain.length>LIMITS.domain) throw new RangeError('finite domain admission');
      n.domain.forEach(include);
    }
  }
  for(const scenario of spec.scenarios) {
    if(!Array.isArray(scenario.entries)||scenario.entries.length>LIMITS.events) throw new RangeError('entry admission');
    for(const entry of scenario.entries) {
      const source=spec.sources[entry.source]; if(!source) throw new Error('unknown source');
      if(entry.map && (entry.sign!==undefined||entry.shift!==undefined)) throw new Error('map replaces sign/shift');
      const sign=entry.sign??1,shift=number(entry.shift??0);
      if(![1,-1].includes(sign)) throw new Error('sign must be +/-1');
      if(entry.map!==undefined&&typeof entry.map!=='function') throw new TypeError('pitch map');
      const rows=source.notes.map((n,i)=>new Map(n.domain.map(p=>[
        p,include(evaluate(entry.map??(x=>sign*x+shift),[p,i],b))
      ])));
      tables.set(entry,rows);
      if(entry.register && (!Array.isArray(entry.register)||entry.register.length!==2||
        number(entry.register[0])>number(entry.register[1]))) throw new RangeError('pitch register');
    }
  }
  const catalogue=[...values].sort((a,b)=>a<b?-1:a>b?1:0),ids=new Map(catalogue.map((p,i)=>[p,i]));
  const decode=t=>t.map(id=>catalogue[id]);
  const rootConstraints=(spec.rootConstraints??[]).map(f=>({...f,test:t=>f.test(decode(t))}));
  const sources=Object.fromEntries(sourceEntries.map(([name,s])=>{
    if(s.maxLeap!==undefined) {
      const cap=s.maxLeap;if(typeof cap!=='number'||Number.isNaN(cap)||cap<0) throw new RangeError('maxLeap');
      for(let i=1;i<s.notes.length;i++) rootConstraints.push({id:`catalogue:leap:${name}:${i}`,
        scope:[`${name}:${i-1}`,`${name}:${i}`],test:([a,c])=>Math.abs(catalogue[c]-catalogue[a])<=cap});
    }
    const {maxLeap,...rest}=s;
    return [name,{...rest,notes:s.notes.map(n=>({...n,domain:n.domain.map(p=>ids.get(p))}))}];
  }));
  const scenarios=spec.scenarios.map(scenario=>({...scenario,entries:scenario.entries.map(entry=>{
    const {sign,shift,map,register,...rest}=entry,rows=tables.get(entry);
    let range;
    if(register) {
      let lo=0,hi=catalogue.length-1;
      while(lo<catalogue.length && catalogue[lo]<register[0]) { b.check('work');lo++; }
      while(hi>=0 && catalogue[hi]>register[1]) { b.check('work');hi--; }
      range=[lo,hi]; // Empty numeric registers become an impossible interval of IDs.
    }
    return {...rest,...(range?{register:range}:{}),map:(id,index)=>{
      if(!rows[index].has(catalogue[id])) throw new Error('pitch outside tabulated source domain');
      return ids.get(rows[index].get(catalogue[id]));
    }};
  })}));
  const clean=ctx=>({...ctx,events:ctx.events.map(({transform,...e})=>e)});
  const profile=Object.fromEntries(['pair','sonority','motion'].filter(k=>spec.profile?.[k]!==undefined)
    .map(k=>[k,(p,ctx)=>spec.profile[k](decode(p),clean(ctx))]));
  return {catalogue,spec:{...spec,sources,scenarios,profile,rootConstraints,
    costs:(spec.costs??[]).map(c=>({...c,cost:t=>c.cost(decode(t))}))}};
}
export function synthesizeCatalogue(spec,options={}) {
  if(options.enumerate) throw new Error('catalogue service does not enumerate decoded solutions');
  const b=budget(options),shared={...options,[SESSION]:b};
  try {
    const encoded=encodeCatalogue(spec,b);
    const hints=options.hint?Object.fromEntries(Object.entries(options.hint).map(([key,pitch])=>[key,encoded.catalogue.indexOf(pitch)])):undefined;
    const r=(options.lazy?synthesizeLazy:synthesize)(encoded.spec,{...shared,hint:hints});
    if(!r.assignment) return {...r,pitchRepresentation:'finite-number-catalogue',stats:summary(b)};
    const assignment=Object.fromEntries(Object.entries(r.assignment).map(([key,id])=>[key,encoded.catalogue[id]]));
    const rendered=r.rendered.map(s=>({...s,notes:s.notes.map(n=>({...n,pitch:encoded.catalogue[n.pitch]}))}));
    b.check(); return {...r,assignment,rendered,pitchRepresentation:'finite-number-catalogue',stats:summary(b)};
  } catch(e) { if(!(e instanceof Stop)) throw e; return {...unknown(b,e.reason),pitchRepresentation:'finite-number-catalogue'}; }
}
