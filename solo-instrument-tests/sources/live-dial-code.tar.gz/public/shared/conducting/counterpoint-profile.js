// Independently compiled, explicitly scoped predicates over actual sounding overlaps. This is not a historical
// style preset: the caller authors every band, limit and required rule. A missing grammar/calibration stays UNKNOWN.
// Planner/reference code only. The exact-cent subset declines acoustic comparisons it cannot establish exactly.
import {Q,normalizeEvents,auditSlices} from './canon-core.js';
import {compilePitchOperations} from './pitch-spaces.js';
import {Refused,Budget,EXACT_LIMITS,sha256,pythonJson} from '../bounded-exact.js';
import {dataRecord,dataArray} from './contract-data.js';

export const PROFILE_LIMITS=Object.freeze({voices:32,rules:48,pairs:992,bands:64,id:256});
// A compiled profile's audit runs faster where a core is installed (shared/musical-core.js: its Rust port, the same
// checks, hashes, work and refusals, the caller's contextAt asked at the same times; research/RUST_PORT_STATE.md).
// Compiling stays here. -> the core it replaced.
let core=null;
export function useProfileCore(given=null){const previous=core;core=given;return previous}
const profileBrands=new WeakMap,decompositionBrands=new WeakMap;
const fail=(message,kind='invalid-input')=>{throw new Refused(message,{kind})};
const plain=dataRecord;
const fields=(value,allowed)=>{if(!plain(value)||Object.keys(value).some(key=>!allowed.includes(key)))fail('Unsupported profile fields')};
const name=value=>{if(typeof value!=='string'||!value.length||value.length>PROFILE_LIMITS.id)fail('Invalid profile/rule/voice name');return value};
const list=dataArray;
const freeze=Object.freeze;
const abs=q=>q.cmp(0)<0?Q(0).sub(q):q;
const nonnegative=value=>{const q=Q(value);if(q.cmp(0)<0)fail('Negative magnitude');return q};
const period=value=>{const q=Q(value);if(q.cmp(0)<=0)fail('Interval period must be positive');return q};
const residue=(value,p)=>{const x=value.div(p),k=x.n/x.d-(x.n<0n&&x.n%x.d?1n:0n);return value.sub(p.mul(k))};
const verdict=(status,reason,extra={})=>({status,detail:{reason,...extra}});
const reduce=results=>results.includes('FAIL')?'FAIL':results.includes('UNKNOWN')?'UNKNOWN':results.includes('PASS')?'PASS':'N/A';
const clockOf=value=>{
  fields(value,['id','unit','revision']);name(value.id);name(value.unit);
  if(!Number.isSafeInteger(value.revision)||value.revision<0)fail('A profile needs an explicit clock revision');
  return freeze({id:value.id,unit:value.unit,revision:value.revision});
};
const bandsOf=(value,p)=>freeze(list(value,PROFILE_LIMITS.bands).map(band=>{
  fields(band,['from','to','fromClosed','toClosed']);const from=nonnegative(band.from),to=nonnegative(band.to);
  for(const key of ['fromClosed','toClosed'])if(Object.hasOwn(band,key)&&typeof band[key]!=='boolean')fail('Band endpoint inclusion must be Boolean');
  const fromClosed=band.fromClosed!==false,toClosed=band.toClosed!==false;
  if(from.cmp(to)>0||p&&(from.cmp(p)>=0||to.cmp(p)>0||to.cmp(p)===0&&toClosed))fail('Bands must lie inside the period, whose upper endpoint is open');
  // Omitted/explicit true keeps the original closed-band definition and hash. False marks an excluded endpoint.
  return freeze({from:String(from),to:String(to),...(!fromClosed?{fromClosed:false}:{}),...(!toClosed?{toClosed:false}:{})});
}));

const pairRule=rule=>rule.type==='voice-spacing'||rule.type==='parallel-classes';
function pairsOf(value,voices,symmetric){
  let inputs,single=false;
  if(value==='all'){
    inputs=[];for(let i=0;i<voices.length;i++)for(let j=i+1;j<voices.length;j++)inputs.push([voices[i],voices[j]]);
  }else{
    const supplied=list(value,PROFILE_LIMITS.pairs,'Profile pairs');
    single=supplied.length===2&&supplied.every(v=>typeof v==='string');inputs=single?[supplied]:supplied;
    if(!inputs.length)fail('An explicit pair list must not be empty');
  }
  const seen=new Set,pairs=[];
  for(const raw of inputs){
    const pair=list(raw,2,'Voice pair');
    if(pair.length!==2||pair[0]===pair[1]||pair.some(v=>typeof v!=='string'||!voices.includes(v)))fail('Declare two distinct profile voices');
    const a=voices.indexOf(pair[0]),b=voices.indexOf(pair[1]),key=symmetric?`${Math.min(a,b)},${Math.max(a,b)}`:`${a},${b}`;
    if(seen.has(key))fail(symmetric?'Duplicate or reversed symmetric parallel pair':'Duplicate ordered spacing pair');seen.add(key);
    pairs.push(freeze([...pair]));
  }
  const expanded=freeze(pairs);return {expanded,spelling:value==='all'?'all':single?expanded[0]:expanded};
}

// Pair rules accept one legacy pair, an explicit list, or 'all'. All-spacing follows declared voice order;
// explicit spacing pairs retain direction. Parallel pairs are symmetric, so reversed duplicates are refused.
// Rule types: monophony, melodic-bound, voice-spacing, parallel-classes,
// vertical-bands (all pairs / pairs containing a sounding bass / upper pairs), vertical-apart (every sounding pair at
// least minCents apart, unreduced), approach-bands (an event entered by a move wider than maxCents from its voice's
// preceding pitched event: its intervals, at its onset, with every other voice sounding there and at that preceding
// event's onset, within the bands), unimplemented (explicit UNKNOWN).
export function compileCounterpointProfile(spec){
  fields(spec,['id','version','pitchSpace','clockDomain','voices','rules']);name(spec.id);
  if(!Number.isSafeInteger(spec.version)||spec.version<0)fail('A profile needs an explicit version');
  const pitchSpace=spec.pitchSpace;compilePitchOperations(pitchSpace,[]); // checks the prepared-space brand
  const clockDomain=clockOf(spec.clockDomain),voices=freeze(list(spec.voices,PROFILE_LIMITS.voices).map(name));
  if(!voices.length||new Set(voices).size!==voices.length)fail('Declare unique voices');
  const ids=new Set,pairLists=new WeakMap;
  const rules=freeze(list(spec.rules,PROFILE_LIMITS.rules).map(rule=>{
    if(!plain(rule))fail('A rule is a data record');name(rule.id);if(rule.id.startsWith('$')||ids.has(rule.id))fail('Duplicate or reserved rule id');ids.add(rule.id);
    if(typeof rule.required!=='boolean')fail('Declare whether each rule is required');
    const common=['id','type','required'];let options;
    switch(rule.type){
      case 'monophony':options=[];break;
      case 'melodic-bound':options=['maxCents'];break;
      case 'voice-spacing':options=['pair','minCents','maxCents'];break;
      case 'parallel-classes':options=['pair','periodCents','classes'];break;
      case 'vertical-bands':options=['scope','periodCents','bands','contextKey'];break;
      case 'vertical-apart':options=['minCents'];break;
      case 'approach-bands':options=['maxCents','periodCents','bands','contextKey'];break;
      case 'unimplemented':options=['reason'];break;
      default:fail('Unsupported rule; declare missing grammar with type unimplemented','out-of-model');
    }
    fields(rule,[...common,...options]);const out={id:rule.id,type:rule.type,required:rule.required};
    if(rule.type==='melodic-bound')out.maxCents=String(nonnegative(rule.maxCents));
    if(pairRule(rule)){
      const parsed=pairsOf(rule.pair,voices,rule.type==='parallel-classes');out.pair=parsed.spelling;pairLists.set(out,parsed.expanded);
    }
    if(rule.type==='voice-spacing'){
      out.minCents=String(nonnegative(rule.minCents));out.maxCents=rule.maxCents===null?null:String(nonnegative(rule.maxCents));
      if(out.maxCents!==null&&Q(out.minCents).cmp(out.maxCents)>0)fail('Reversed spacing limits');
    }
    if(rule.type==='parallel-classes'){
      const p=period(rule.periodCents),labels=new Set;out.periodCents=String(p);
      out.classes=freeze(list(rule.classes,PROFILE_LIMITS.bands).map(item=>{
        fields(item,['id','center','tolerance']);name(item.id);
        if(labels.has(item.id))fail('Duplicate interval-class label');labels.add(item.id);
        const center=nonnegative(item.center),tolerance=nonnegative(item.tolerance);
        if(center.cmp(p)>=0||tolerance.mul(2).cmp(p)>=0)fail('Class centers/tolerances must lie within the period');
        return freeze({id:item.id,center:String(center),tolerance:String(tolerance)});
      }));
      if(!out.classes.length)fail('Declare protected interval classes');
    }
    if(rule.type==='vertical-bands'){
      if(!['all','bass','upper'].includes(rule.scope))fail('Declare the vertical-pair scope');out.scope=rule.scope;
      const p=rule.periodCents===null?null:period(rule.periodCents);out.periodCents=p?String(p):null;
      if(Object.hasOwn(rule,'bands')===Object.hasOwn(rule,'contextKey'))fail('Choose fixed bands or a named context field');
      if(Object.hasOwn(rule,'bands'))out.bands=bandsOf(rule.bands,p);else out.contextKey=name(rule.contextKey);
    }
    if(rule.type==='vertical-apart')out.minCents=String(nonnegative(rule.minCents));
    if(rule.type==='approach-bands'){
      out.maxCents=String(nonnegative(rule.maxCents));
      const p=rule.periodCents===null?null:period(rule.periodCents);out.periodCents=p?String(p):null;
      if(Object.hasOwn(rule,'bands')===Object.hasOwn(rule,'contextKey'))fail('Choose fixed bands or a named context field');
      if(Object.hasOwn(rule,'bands'))out.bands=bandsOf(rule.bands,p);else out.contextKey=name(rule.contextKey);
    }
    if(rule.type==='unimplemented')out.reason=name(rule.reason);
    return freeze(out);
  }));
  if(!rules.length)fail('A profile needs named musical predicates');
  const definition=freeze({id:spec.id,version:spec.version,pitchSpace: pitchSpace.hash,clockDomain,voices,rules});
  const hash=sha256(pythonJson(definition)),coreProfile=freeze({definition,hash,pitchSpace,rules,pairLists});

  function audit(events,{boundaries=[],contextAt=()=>({}),dependencies={},maxWork,maxPredicateWork}={}){
    if(core){
      const out=core.profileAudit(coreProfile,events,{boundaries,contextAt,dependencies,maxWork,maxPredicateWork});
      if(out)return report(out.result,out.predicateWorkUsed,new Map(rules.map((rule,i)=>[rule.id,out.seen[i]])),
        new Map(rules.filter(pairRule).map(rule=>[rule.id,out.pairSeen[rules.indexOf(rule)]])));
    }
    // Separate bounded preparation, sweep and predicate budgets. None bounds arbitrary caller context callbacks.
    const snapshot=normalizeEvents(events,{maxWork}),budget=new Budget(maxPredicateWork),groups=new WeakMap;
    const pairSeen=new Map(rules.filter(pairRule).map(rule=>[rule.id,pairLists.get(rule).map(()=>0)]));
    const cents=(a,b)=>{
      budget.charge();
      if(!a||!b||a.space!==pitchSpace.id||b.space!==pitchSpace.id||a.definition!==pitchSpace.hash||b.definition!==pitchSpace.hash)return null;
      try{const value=pitchSpace.interval(a,b).exactCents;return value===null?null:Q(value)}
      catch(error){if(error instanceof Refused&&error.kind==='out-of-model')return null;throw error}
    };
    const byVoice=slice=>{
      if(groups.has(slice))return groups.get(slice);const result=new Map;
      for(const event of slice.active){budget.charge();if(!result.has(event.voiceId))result.set(event.voiceId,[]);result.get(event.voiceId).push(event)}
      groups.set(slice,result);return result;
    };
    const pairAt=(slice,pair)=>{
      const grouped=byVoice(slice),a=grouped.get(pair[0])??[],b=grouped.get(pair[1])??[];
      return !a.length||!b.length?'N/A':a.length!==1||b.length!==1?'UNKNOWN':[a[0],b[0]];
    };
    // (Each pitched event's preceding pitched event in its voice, across rests.)
    const preceding=new Map;{const last=new Map;for(const event of snapshot){budget.charge();if(event.pitch===null)continue;
      const before=last.get(event.voiceId);if(before)preceding.set(event.id,before);last.set(event.voiceId,event)}}
    const soundingAt=(voiceId,t)=>snapshot.some(event=>{budget.charge();return event.voiceId===voiceId&&event.pitch!==null&&event.t.cmp(t)<=0&&event.t.add(event.d).cmp(t)>0});
    const contextBands=(rule,context,p)=>{
      if(!rule.contextKey)return rule.bands;const supplied=context[rule.contextKey];if(!supplied)return null;
      fields(supplied,['id','revision','bands']);name(supplied.id);
      if(!Number.isSafeInteger(supplied.revision)||supplied.revision<0)fail('Harmonic context needs a revision');return bandsOf(supplied.bands,p);
    };
    const inBands=(value,bands,p)=>{
      const q=p?residue(abs(value),p):abs(value);let allowed=false;
      for(const band of bands){budget.charge();const lower=q.cmp(band.from),upper=q.cmp(band.to);
        if((lower>0||lower===0&&band.fromClosed!==false)&&(upper<0||upper===0&&band.toClosed!==false))allowed=true}return allowed;
    };
    const basic=()=>{
      const results=[];
      for(const event of snapshot){
        budget.charge();
        if(!voices.includes(event.voiceId))results.push('FAIL');
        const domain=event.clockDomain;
        results.push(!domain?'UNKNOWN':domain.id===clockDomain.id&&domain.unit===clockDomain.unit&&domain.revision===clockDomain.revision?'PASS':'FAIL');
        if(event.pitch!==null){
          if(!plain(event.pitch)||event.pitch.space!==pitchSpace.id||event.pitch.definition!==pitchSpace.hash)results.push('UNKNOWN');
          else{pitchSpace.pitch(event.pitch);results.push('PASS')}
        }
      }
      return verdict(reduce(results),'Declared voice identities, pitch definitions and clock domain');
    };
    function runPair(rule,{slice,previous},voicesOfPair){
      budget.charge();
      if(rule.type==='voice-spacing'){
        const pair=pairAt(slice,voicesOfPair);if(typeof pair==='string')return pair;
        const delta=cents(pair[0].pitch,pair[1].pitch);
        return delta===null?'UNKNOWN':delta.cmp(rule.minCents)<0||rule.maxCents!==null&&delta.cmp(rule.maxCents)>0?verdict('FAIL','Ordered voice spacing outside the authored band',{cents:String(delta)}):'PASS';
      }
      const before=pairAt(previous,voicesOfPair),after=pairAt(slice,voicesOfPair);
      if(before==='UNKNOWN'||after==='UNKNOWN')return 'UNKNOWN';if(before==='N/A'||after==='N/A')return 'N/A';
      const motions=before.map((event,i)=>cents(event.pitch,after[i].pitch));
      if(motions.some(value=>value===null))return 'UNKNOWN';
      if(!motions[0].n||!motions[1].n||motions[0].cmp(0)!==motions[1].cmp(0))return 'PASS';
      const p=Q(rule.periodCents);
      const classify=pair=>{
        const span=cents(pair[0].pitch,pair[1].pitch);if(span===null)return null;const q=residue(abs(span),p),found=[];
        for(const item of rule.classes){budget.charge();const distance=abs(q.sub(item.center)),wrapped=p.sub(distance);
          if((distance.cmp(wrapped)<0?distance:wrapped).cmp(item.tolerance)<=0)found.push(item.id)}
        return found.length>1?null:found[0]??false;
      };
      const a=classify(before),b=classify(after);
      if(a===null||b===null)return 'UNKNOWN';
      return a!==false&&a===b?verdict('FAIL','Both voices move in the same direction between the same protected class',{intervalClass:a}):'PASS';
    }
    function run(rule,{slice,previous,context}){
      budget.charge();
      if(rule.type==='unimplemented')return verdict('UNKNOWN',rule.reason);
      if(rule.type==='monophony'){
        if(!slice.active.length)return 'N/A';
        for(const values of byVoice(slice).values()){budget.charge();if(values.length>1)return verdict('FAIL','Overlapping sounding events in one voice',{events:values.map(e=>e.id)})}return 'PASS';
      }
      if(rule.type==='melodic-bound'){
        const last=new Map,results=[];
        for(const event of snapshot){
          budget.charge();if(event.pitch===null)continue;const before=last.get(event.voiceId);last.set(event.voiceId,event);
          if(!before)continue;
          if(before.t.add(before.d).cmp(event.t)>0){results.push('UNKNOWN');continue}
          const delta=cents(before.pitch,event.pitch);results.push(delta===null?'UNKNOWN':abs(delta).cmp(rule.maxCents)<=0?'PASS':'FAIL');
        }
        return verdict(reduce(results),'Successive pitched events, including across rests');
      }
      if(pairRule(rule)){
        const evidence=pairLists.get(rule).map((pair,i)=>{
          const result=runPair(rule,{slice,previous},pair),status=typeof result==='string'?result:result.status;
          if(status!=='N/A')pairSeen.get(rule.id)[i]++;
          return {pair,status,...(typeof result==='object'?{detail:result.detail}:{})};
        });
        // Preserve legacy single-pair detail while adding evidence for every configured pair.
        const detail=evidence.length===1?evidence[0].detail??{}:{};
        return verdict(reduce(evidence.map(item=>item.status)),detail.reason??'Authored predicate on every configured voice pair',
          {...detail,pairs:evidence});
      }
      if(rule.type==='vertical-bands'){
        const active=slice.active;if(active.length<2)return 'N/A';
        if(rule.scope==='upper'&&active.length<3)return 'N/A';
        const pairs=[];
        for(let i=0;i<active.length;i++)for(let j=i+1;j<active.length;j++){
          budget.charge();if(active[i].voiceId!==active[j].voiceId)pairs.push([active[i],active[j]]);
        }
        if(!pairs.length)return 'N/A';
        let bass=null;
        if(rule.scope!=='all'){
          const heights=active.map(event=>cents(active[0].pitch,event.pitch));if(heights.some(h=>h===null))return 'UNKNOWN';
          const low=heights.reduce((a,b)=>a.cmp(b)<0?a:b);bass=new Set(active.filter((_,i)=>heights[i].eq(low)).map(event=>event.id));
        }
        const selected=pairs.filter(pair=>{
          budget.charge();const atBass=bass&&pair.some(event=>bass.has(event.id));
          return rule.scope==='all'||rule.scope==='bass'&&atBass||rule.scope==='upper'&&!atBass;
        });
        if(!selected.length)return 'N/A';
        let bands=rule.bands;const p=rule.periodCents===null?null:Q(rule.periodCents);
        if(rule.contextKey){
          const supplied=context[rule.contextKey];if(!supplied)return verdict('UNKNOWN','Missing named harmonic context');
          fields(supplied,['id','revision','bands']);name(supplied.id);
          if(!Number.isSafeInteger(supplied.revision)||supplied.revision<0)fail('Harmonic context needs a revision');bands=bandsOf(supplied.bands,p);
        }
        const results=selected.map(pair=>{const delta=cents(pair[0].pitch,pair[1].pitch);return delta===null?'UNKNOWN':inBands(delta,bands,p)?'PASS':'FAIL'});
        return verdict(reduce(results),bands.some(b=>b.fromClosed===false||b.toClosed===false)?
          'Authored interval bands with explicit endpoint inclusion on actual sounding pairs':
          'Authored closed interval bands on actual sounding pairs',{pairScope:rule.scope});
      }
      if(rule.type==='vertical-apart'){
        const active=slice.active.filter(event=>event.pitch!==null),results=[];
        for(let i=0;i<active.length;i++)for(let j=i+1;j<active.length;j++){
          budget.charge();if(active[i].voiceId===active[j].voiceId)continue;
          const delta=cents(active[i].pitch,active[j].pitch);results.push(delta===null?'UNKNOWN':abs(delta).cmp(rule.minCents)>=0?'PASS':'FAIL');
        }
        return results.length?verdict(reduce(results),'Sounding pairs at least the authored distance apart'):'N/A';
      }
      if(rule.type==='approach-bands'){
        const active=slice.active.filter(event=>event.pitch!==null);if(new Set(active.map(event=>event.voiceId)).size<2)return 'N/A';
        const p=rule.periodCents===null?null:Q(rule.periodCents),bands=contextBands(rule,context,p);
        if(!bands)return verdict('UNKNOWN','Missing named harmonic context');
        const results=[];
        for(const event of active){
          budget.charge();if(event.t.cmp(slice.start)!==0)continue;const before=preceding.get(event.id);if(!before)continue;
          const move=cents(before.pitch,event.pitch);if(move===null){results.push('UNKNOWN');continue}
          if(abs(move).cmp(rule.maxCents)<=0)continue;
          for(const other of active){
            budget.charge();if(other.voiceId===event.voiceId||!soundingAt(other.voiceId,before.t))continue;
            const delta=cents(event.pitch,other.pitch);results.push(delta===null?'UNKNOWN':inBands(delta,bands,p)?'PASS':'FAIL');
          }
        }
        return verdict(reduce(results.length?results:['PASS']),'Intervals entered by a move wider than the authored bound, within the bands');
      }
    }
    const seen=new Map(rules.map(rule=>[rule.id,0]));
    const compiled=[{id:'$domains',kind:'initial',required:true,check:basic}];
    for(const rule of rules)compiled.push({id:rule.id,kind:rule.type==='melodic-bound'?'initial':rule.type==='unimplemented'?'final':rule.type==='parallel-classes'?'transition':'slice',required:false,
      check:input=>{const result=run(rule,input),status=typeof result==='string'?result:result.status;if(status!=='N/A')seen.set(rule.id,seen.get(rule.id)+1);return result}});
    // N/A during an introduction is harmless; a required predicate never exercised anywhere is still UNKNOWN.
    for(const rule of rules)if(rule.required)compiled.push({id:`$coverage:${rule.id}`,kind:'final',required:true,
      check:()=>{
        if(pairRule(rule)){
          const pairs=pairLists.get(rule),missing=pairs.filter((_,i)=>!pairSeen.get(rule.id)[i]);
          return pairs.length&&!missing.length?'PASS':verdict('UNKNOWN','A required pair predicate was never exercised',{unexercisedPairs:missing});
        }
        return seen.get(rule.id)?'PASS':verdict('UNKNOWN','Required predicate was never exercised');
      }});
    const result=auditSlices(snapshot,{boundaries,contextAt,rules:compiled,maxWork,profileId:definition.id,profileVersion:definition.version,
      dependencies:{supplied:dependencies,compiledProfile:hash,pitchSpace:pitchSpace.hash}});
    return report(result,budget.used,seen,pairSeen);
  }
  const report=(result,predicateWorkUsed,seen,pairSeen)=>({...result,profileHash:hash,definition,predicateWorkUsed,
    applicability:Object.fromEntries(seen),pairApplicability:Object.fromEntries(rules.filter(pairRule).map(rule=>[rule.id,
      pairLists.get(rule).map((pair,i)=>({pair,exercised:pairSeen.get(rule.id)[i]}))])),
    claim:'Only the named predicates over the supplied finite exact-cent model'});
  const prepared=freeze({id:definition.id,version:definition.version,definition,hash,audit});
  profileBrands.set(prepared,{pitchSpace,clockDomain,voices,rules,pairLists,definition,hash,token:null});return prepared;
}

// Branded necessary-condition views. These do not replace the whole-profile domain/coverage audit.
// Removing unrelated sweep boundaries can remove zero-motion PASS transitions; only certain local FAIL is
// preserved under adding other voices. Consumers must never prune UNKNOWN/N/A or infer complete validity here.
export function decomposeCounterpointProfile(profile){
  const owned=profileBrands.get(profile);if(!owned)fail('A decomposition requires an authentic compiled profile');
  if(owned.token)return owned.token;
  const {pitchSpace,clockDomain,voices,rules,pairLists,definition,hash}=owned,voiceIndex=new Map(voices.map((voice,i)=>[voice,i]));
  const unaryRules=rules.filter(rule=>rule.type==='monophony'||rule.type==='melodic-bound');
  const unsupportedRuleIds=freeze(rules.filter(rule=>!pairRule(rule)&&!unaryRules.includes(rule)).map(rule=>rule.id));
  const localProfile=(selectedVoices,selectedRules)=>selectedRules.length?compileCounterpointProfile({id:definition.id,version:definition.version,
    pitchSpace,clockDomain,voices:[...selectedVoices],rules:selectedRules.map(rule=>({...rule,required:false}))}):null;
  const unaryProfiles=new Map(voices.map(voice=>[voice,localProfile([voice],unaryRules)]));
  const pairGroups=new Map;
  const edgeKey=(a,b)=>{
    const i=voiceIndex.get(a),j=voiceIndex.get(b);if(i===undefined||j===undefined||i===j)fail('Choose two distinct declared voices');
    return i<j?`${i},${j}`:`${j},${i}`;
  };
  for(const rule of rules)if(pairRule(rule))for(const pair of pairLists.get(rule)){
    const key=edgeKey(...pair);let group=pairGroups.get(key);
    if(!group){const indices=key.split(',').map(Number);group={voices:freeze(indices.map(i=>voices[i])),rules:new Map};pairGroups.set(key,group)}
    let entry=group.rules.get(rule.id);if(!entry){entry={rule,pairs:[]};group.rules.set(rule.id,entry)}entry.pairs.push(pair);
  }
  const pairProfiles=new Map,pairScopes=[];
  for(const [key,group] of pairGroups){
    const selected=[...group.rules.values()].map(({rule,pairs})=>({...rule,pair:pairs.length===1?pairs[0]:pairs}));
    pairProfiles.set(key,localProfile(group.voices,selected));pairScopes.push(freeze({voices:group.voices,ruleIds:freeze(selected.map(rule=>rule.id))}));
  }
  const unaryScopes=freeze(unaryRules.length?voices.map(voiceId=>freeze({voiceId,ruleIds:freeze(unaryRules.map(rule=>rule.id))})):[]);
  const wholeRuleIds=new Set(rules.map(rule=>rule.id));

  function evaluate(selected,selectedVoices,events,info,kind){
    fields(info,['maxWork','consumeWork']);
    const total=Object.hasOwn(info,'maxWork')?info.maxWork:4*EXACT_LIMITS.work;
    if(!Number.isSafeInteger(total)||total<0)fail('Decomposition maxWork must be a nonnegative safe integer');
    if(Object.hasOwn(info,'consumeWork')&&typeof info.consumeWork!=='function')fail('consumeWork must be a function');
    let preparation=0,allocated=0,started=false,settled=false;
    const charge=()=>{if(preparation===total)fail('Decomposition preparation work exhausted','work-budget');preparation++};
    const settle=amount=>{settled=true;if(info.consumeWork)info.consumeWork(amount)};
    try{
      charge();list(events,4096,'Decomposition events');const scopeVoices=new Set(selectedVoices);
      for(const event of events){
        charge();if(!plain(event)||kind!=='joint'&&!scopeVoices.has(event.voiceId))fail('Local material must contain only its declared voice scope','out-of-model');
      }
      if(!selected){settle(preparation);return freeze({status:'N/A',scope:'necessary-local-profile',profileHash:hash,checks:freeze([]),workUsed:preparation})}
      allocated=Math.min(EXACT_LIMITS.maxWork,Math.floor((total-preparation)/4));started=true;
      const out=selected.audit(events,{maxWork:allocated,maxPredicateWork:allocated});
      // The first normalizeEvents ledger does not expose its used count, so reserve its entire allocation.
      // Its raw-input sort need not cost the same as later sorted normalizations. Sweep, predicates and the
      // local named-check scan have distinct ledgers; the latter is deliberately charged even for skipped rows.
      const selectedChecks=[],statuses=[],scan=new Budget(allocated);
      if(kind!=='joint')for(const check of out.checks){
        scan.charge();if(wholeRuleIds.has(check.rule)){selectedChecks.push(check);statuses.push(check.status)}
      }
      const receipt=preparation+allocated+out.workUsed+out.predicateWorkUsed+scan.used;
      settle(receipt);
      return kind==='joint'?freeze({...out,scope:'whole-compiled-profile',auditWorkUsed:out.workUsed,workUsed:receipt}):
        freeze({status:reduce(statuses),scope:'necessary-local-profile',profileHash:hash,localProfileHash:selected.hash,
          checks:freeze(selectedChecks),workUsed:receipt});
    }catch(error){
      // Refusal work is charged before it propagates. A search must stop UNKNOWN rather than cache a resource
      // refusal as a semantic UNKNOWN and later assert exhaustive UNSAT. A throwing receipt is never retried.
      if(!settled)settle(preparation+(started?4*allocated:0));throw error;
    }
  }
  const token=freeze({id:definition.id,version:definition.version,hash,pitchSpaceHash:pitchSpace.hash,clockDomain,voices,
    unaryScopes,pairScopes:freeze(pairScopes),unsupportedRuleIds,coversAllMusicalRules:unsupportedRuleIds.length===0,
    unary(voiceId,events,info={}){
      if(!voiceIndex.has(voiceId))fail('Choose a declared unary voice');return evaluate(unaryProfiles.get(voiceId),[voiceId],events,info,'unary');
    },
    pair(a,b,events,info={}){const key=edgeKey(a,b);return evaluate(pairProfiles.get(key)??null,[a,b],events,info,'pair')},
    audit(events,info={}){return evaluate(profile,voices,events,info,'joint')}
  });
  decompositionBrands.set(token,owned);owned.token=token;return token;
}

export function inspectCounterpointDecomposition(token){
  if(!decompositionBrands.has(token))fail('A genuine compiled-profile decomposition is required');return token;
}
