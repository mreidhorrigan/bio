// Finite authored cadence alternatives, exact score geometry and typed pitch assignment.
// No historical grammar, player admission or numerical/acoustic realization is inferred.
// Callbacks are trusted synchronous planning predicates; only explicit consumeWork receipts enter our ledger.
// Work charges do not bound runtime. Large caller budgets are for explicitly authorized preplanning work.
import {Q,Rational} from './canon-core.js';
import {compilePitchOperations} from './pitch-spaces.js';
import {inspectCounterpointDecomposition} from './counterpoint-profile.js';
import {dataArray,dataRecord} from './contract-data.js';
import {Refused,EXACT_LIMITS,exactOf,pythonJson,sha256} from '../bounded-exact.js';

export const CADENCE_LIMITS=Object.freeze({voices:16,candidates:64,tones:64,roles:32,events:4096,
  tailEvents:128,sourceEvents:512,variants:4096,nodes:100000,snapshotNodes:32768,text:262144,
  string:2048,depth:16,hashChars:2000000});
// CADENCE_LIMITS.nodes retains its historical value for import compatibility; it is no longer a call ceiling.
// Existing defaults are unchanged; certified forward checking adds a separate cache-entry allowance.
// Explicit finite safe-integer allowances may be larger; shape and arithmetic caps remain.
export const CADENCE_DEFAULT_BUDGET=Object.freeze({maxWork:100000,maxNodes:10000,
  maxTextChars:CADENCE_LIMITS.text,maxSnapshotNodes:CADENCE_LIMITS.snapshotNodes,
  maxHashChars:CADENCE_LIMITS.hashChars,maxPredicateWork:EXACT_LIMITS.maxWork,maxPruningEntries:65536});
const freeze=Object.freeze;
const fail=(message,kind='invalid-input')=>{throw new Refused(message,{kind})};
const scope='supplied-finite-cadence-domain-and-whole-joint-contract';
const integerBoundary=1n<<BigInt(EXACT_LIMITS.inputBits);
function integerToken(value){
  if(typeof value==='bigint'){
    if(value<=-integerBoundary||value>=integerBoundary)fail('Raw rational component exceeds its bit budget','arithmetic-budget');
  }else if(!Number.isSafeInteger(value))fail('Malformed rational components');
  return value;
}
function fields(value,keys,optional=[]){
  if(!dataRecord(value)||keys.some(key=>!Object.hasOwn(value,key))||Object.keys(value).some(key=>!keys.includes(key)&&!optional.includes(key)))fail('Unexpected or missing cadence fields');
  return value;
}
function text(value,state,limit=CADENCE_LIMITS.string){
  if(typeof value!=='string'||!value.length||value.length>limit)fail('Invalid bounded cadence text');
  if(value.length>state.limits.maxTextChars-state.chars)fail('Cadence text budget for one snapshot frame','work-budget');
  state.chars+=value.length;
  state.usage.peakTextChars=Math.max(state.usage.peakTextChars,state.chars);
  if(state.phase==='model')state.usage.modelTextChars=state.chars;
  return value;
}
const count=(value,maximum)=>{if(!Number.isSafeInteger(value)||value<0||value>maximum)fail('Invalid cadence count');return value};
class CadenceBudget {
  constructor(limit){this.limit=count(limit,Number.MAX_SAFE_INTEGER);this.used=0}
  charge(amount=1){
    if(!Number.isSafeInteger(amount)||amount<0)fail('Invalid cadence work charge');
    if(amount>this.limit-this.used)fail('Cadence work budget exhausted','work-budget');
    this.used+=amount;
  }
}
function frame(state,phase){
  state.budget.charge();if(phase==='leaf')state.usage.leafAudits++;
  return {...state,phase,chars:0,snapshots:0};
}
function copy(value,state,depth=0,seen=new Set){
  state.budget.charge();
  if(state.snapshots>=state.limits.maxSnapshotNodes)fail('Cadence node budget for one snapshot frame','work-budget');
  state.snapshots++;state.usage.peakSnapshotNodes=Math.max(state.usage.peakSnapshotNodes,state.snapshots);
  if(state.phase==='model')state.usage.modelSnapshotNodes=state.snapshots;
  if(value===null||typeof value==='boolean')return value;
  if(typeof value==='string'){if(value==='')return value;return text(value,state)}
  if(typeof value==='number'){if(!Number.isFinite(value))fail('Nonfinite snapshot value');return Object.is(value,-0)?0:value}
  if(depth>=CADENCE_LIMITS.depth||seen.has(value))fail('Cyclic or deep cadence data');
  seen.add(value);let out;
  if(Array.isArray(value)){
    dataArray(value,CADENCE_LIMITS.events,'Cadence snapshot');out=[];
    for(let i=0;i<value.length;i++)out.push(copy(value[i],state,depth+1,seen));
  }else{
    if(!dataRecord(value))fail('Cadence snapshots require plain data');
    const keys=Object.keys(value);if(keys.length>256)fail('Cadence snapshot is too wide');out={};
    for(const key of keys){text(key,state);Object.defineProperty(out,key,{value:copy(value[key],state,depth+1,seen),enumerable:true})}
  }
  seen.delete(value);return freeze(out);
}
function exact(value,state){
  state.budget.charge();let input=value;
  if(value&&Object.getPrototypeOf(value)===Rational.prototype){
    const n=Object.getOwnPropertyDescriptor(value,'n'),d=Object.getOwnPropertyDescriptor(value,'d');
    if(!n||!d||!Object.hasOwn(n,'value')||!Object.hasOwn(d,'value')||typeof n.value!=='bigint'||typeof d.value!=='bigint')fail('Malformed exact time');
    input={n:integerToken(n.value),d:integerToken(d.value)};
  }else if(value&&typeof value==='object'){
    fields(value,['n','d']);
    input={n:integerToken(value.n),d:integerToken(value.d)};
  }
  if(typeof input==='bigint')integerToken(input);
  const result=Q(exactOf(input));text(String(result),state);return result;
}
function hash(value,state){
  // Emit the shared canonical format in bounded chunks. Check length BEFORE appending/joining, so an over-limit
  // model/witness is not first allocated as one huge canonical string. Primitive spellings have hard input caps.
  const chunks=[];let size=0;
  const append=part=>{
    if(part.length>state.limits.maxHashChars-size)fail('Cadence hash snapshot budget','work-budget');
    size+=part.length;chunks.push(part);
  };
  function encode(v){
    state.budget.charge();
    if(v===null||v===undefined||typeof v!=='object'||
      (typeof v.n==='bigint'&&typeof v.d==='bigint'&&v.d>0n)){append(pythonJson(v));return}
    if(Array.isArray(v)){
      append('[');for(let i=0;i<v.length;i++){if(i)append(',');encode(v[i])}append(']');return;
    }
    const keys=Object.keys(v).sort((a,b)=>{state.budget.charge();return a<b?-1:a>b?1:0});
    append('{');for(let i=0;i<keys.length;i++){if(i)append(',');append(pythonJson(keys[i]));append(':');encode(v[keys[i]])}append('}');
  }
  encode(value);state.usage.peakHashChars=Math.max(state.usage.peakHashChars,size);
  state.budget.charge(1+Math.ceil(size/64));return sha256(chunks.join(''));
}
function pitch(value,space,state,rest=false){
  if(value===null&&rest)return null;
  if(!dataRecord(value)||Object.keys(value).length!==3||!Object.hasOwn(value,'space')||!Object.hasOwn(value,'definition')||!Object.hasOwn(value,'coordinate'))fail('Typed pitch meaning is required','out-of-model');
  const saved=copy(value,state);
  if(saved.space!==space.id||saved.definition!==space.hash)fail('Pitch space or tuning revision is unresolved','out-of-model');
  return space.pitch(saved);
}
function events(raw,voiceId,clock,space,state,limit){
  dataArray(raw,limit,'Cadence events');const out=[],ids=new Set;
  for(let i=0;i<raw.length;i++){
    state.budget.charge();if(++state.events>CADENCE_LIMITS.events)fail('Cadence event-description budget','work-budget');
    const event=fields(raw[i],['id','t','d','pitch']),id=text(event.id,state,256);
    if(ids.has(id))fail('Duplicate event identity within a material list');ids.add(id);
    const t=exact(event.t,state),d=exact(event.d,state);if(t.cmp(0)<0||d.cmp(0)<=0)fail('Require nonnegative event time and positive duration');
    t.add(d);out.push(freeze({id,t,d,pitch:pitch(event.pitch,space,state,true),voiceId,clockDomain:clock}));
  }
  out.sort((a,b)=>{state.budget.charge();return a.t.cmp(b.t)||(a.id<b.id?-1:a.id>b.id?1:0)});return freeze(out);
}
function normalize(spec,state){
  fields(spec,['id','revision','pitchSpace','clockDomain','anchor','window','hitDuration','voices','chord','domainComplete','rules','dependencies']);
  const id=text(spec.id,state,256),revision=count(spec.revision,Number.MAX_SAFE_INTEGER),space=spec.pitchSpace;
  compilePitchOperations(space,[]);const c=fields(spec.clockDomain,['id','unit','revision']);
  const clock=freeze({id:text(c.id,state,256),unit:text(c.unit,state,256),revision:count(c.revision,Number.MAX_SAFE_INTEGER)});
  const anchor=exact(spec.anchor,state),hitDuration=exact(spec.hitDuration,state);
  dataArray(spec.window,2,'Cadence cut window');if(spec.window.length!==2)fail('Declare a closed two-endpoint cut window');
  const window=freeze([exact(spec.window[0],state),exact(spec.window[1],state)]);
  if(anchor.cmp(0)<0||hitDuration.cmp(0)<=0||window[0].cmp(0)<0||window[0].cmp(window[1])>0||window[1].cmp(anchor)>0)fail('Invalid anchor, hold or editing window');
  anchor.add(hitDuration);if(typeof spec.domainComplete!=='boolean')fail('Declare whether the candidate domain is complete');
  let rules=null;
  if(spec.rules!==null){
    const r=fields(spec.rules,['id','version','checkJoint'],['decomposition']);
    const decomposition=Object.hasOwn(r,'decomposition')?inspectCounterpointDecomposition(r.decomposition):null;
    if(typeof r.checkJoint!=='function'&&!(r.checkJoint===null&&decomposition))fail('A whole-joint rule predicate is missing','out-of-model');
    rules=freeze({id:text(r.id,state,256),version:count(r.version,Number.MAX_SAFE_INTEGER),check:r.checkJoint,decomposition});
  }
  const dependencies=copy(spec.dependencies,state);if(!dataRecord(dependencies))fail('Dependencies must be a plain record');
  const chord=fields(spec.chord,['roles','tones']);dataArray(chord.roles,CADENCE_LIMITS.roles,'Chord roles');dataArray(chord.tones,CADENCE_LIMITS.tones,'Chord tones');
  const roles=[],roleIds=new Set,tones=[],toneIds=new Set;
  for(let i=0;i<chord.roles.length;i++){
    state.budget.charge();const r=fields(chord.roles[i],['id','min','max']),name=text(r.id,state,256),min=count(r.min,CADENCE_LIMITS.voices),max=count(r.max,CADENCE_LIMITS.voices);
    if(roleIds.has(name)||min>max)fail('Duplicate role or reversed role bounds');roleIds.add(name);roles.push(freeze({id:name,min,max}));
  }
  for(let i=0;i<chord.tones.length;i++){
    state.budget.charge();const t=fields(chord.tones[i],['id','role','pitch','min','max']),name=text(t.id,state,256),role=text(t.role,state,256),min=count(t.min,CADENCE_LIMITS.voices),max=count(t.max,CADENCE_LIMITS.voices);
    if(toneIds.has(name)||!roleIds.has(role)||min>max)fail('Duplicate tone, undeclared role or reversed tone bounds');toneIds.add(name);
    const value=pitch(t.pitch,space,state);
    for(const other of tones){state.budget.charge();if(space.equivalent(other.pitch,value)===true)fail('Chord tone pitches must be distinct; combine multiplicity bounds explicitly')}
    tones.push(freeze({id:name,role,pitch:value,min,max}));
  }
  dataArray(spec.voices,CADENCE_LIMITS.voices,'Cadence voices');if(!spec.voices.length)fail('At least one declared voice is required');
  const voices=[],voiceIds=new Set,sourceIds=new Set;
  for(let i=0;i<spec.voices.length;i++){
    state.budget.charge();const v=fields(spec.voices[i],['id','source','immutableUntil','locked','candidates']),voiceId=text(v.id,state,256);
    if(voiceIds.has(voiceId)||typeof v.locked!=='boolean')fail('Duplicate voice or missing lock declaration');voiceIds.add(voiceId);
    const immutableUntil=exact(v.immutableUntil,state);if(immutableUntil.cmp(0)<0)fail('Negative immutable-prefix boundary');
    const source=events(v.source,voiceId,clock,space,state,CADENCE_LIMITS.sourceEvents);
    for(const event of source){state.budget.charge();if(sourceIds.has(event.id))fail('Source identities must be globally unique');sourceIds.add(event.id)}
    dataArray(v.candidates,CADENCE_LIMITS.candidates,'Cadence candidates');const candidates=[],ids=new Set;
    for(let j=0;j<v.candidates.length;j++){
      state.budget.charge();const raw=fields(v.candidates[j],['id','cut','splitSourceIds','tail','arrival']),candidateId=text(raw.id,state,256);
      if(ids.has(candidateId))fail('Duplicate candidate identity');ids.add(candidateId);const cut=exact(raw.cut,state);
      dataArray(raw.splitSourceIds,CADENCE_LIMITS.sourceEvents,'Explicit source splits');const splits=[],splitIds=new Set;
      for(let k=0;k<raw.splitSourceIds.length;k++){state.budget.charge();const name=text(raw.splitSourceIds[k],state,256);if(splitIds.has(name))fail('Duplicate split identity');splitIds.add(name);splits.push(name)}
      const tail=events(raw.tail,voiceId,clock,space,state,CADENCE_LIMITS.tailEvents),a=fields(raw.arrival,['id','pitch']);
      if(++state.events>CADENCE_LIMITS.events)fail('Cadence event-description budget','work-budget');
      const arrival=freeze({id:text(a.id,state,256),t:anchor,d:hitDuration,pitch:pitch(a.pitch,space,state),voiceId,clockDomain:clock});
      candidates.push(freeze({id:candidateId,cut,splitSourceIds:freeze(splits),tail,arrival}));
    }
    voices.push(freeze({id:voiceId,source,immutableUntil,locked:v.locked,candidates:freeze(candidates)}));
  }
  if(rules?.decomposition){
    const p=rules.decomposition;state.budget.charge(1+voices.length);
    if(p.pitchSpaceHash!==space.hash||p.clockDomain.id!==clock.id||p.clockDomain.unit!==clock.unit||p.clockDomain.revision!==clock.revision||
      p.voices.length!==voices.length||p.voices.some(id=>!voiceIds.has(id)))fail('Certified profile does not match cadence voices, clock and pitch space','out-of-model');
  }
  const ruleDefinition=rules?freeze({id:rules.id,version:rules.version,
    ...(rules.decomposition?{decomposition:freeze({profileHash:rules.decomposition.hash})}:{})}):null;
  const definition=freeze({id,revision,clockDomain:clock,pitchSpace:space.hash,anchor,window,hitDuration,
    voices:freeze(voices),chord:freeze({roles:freeze(roles),tones:freeze(tones)}),domainComplete:spec.domainComplete,
    rules:ruleDefinition,dependencies});
  return {definition,space,rules,sourceIds,hash:hash(definition,state)};
}
const finishAudit=(status,reason,model,extra={})=>freeze({status,reason,modelHash:model.hash,scope,...extra});
// Both the independent leaf checker and certified pruning use this exact reconstruction. In particular, a
// retained crossing event is shortened only by the original explicit split contract, never to simplify a profile.
function reconstructChoice(model,index,choice,state){
  const d=model.definition,budget=state.budget,voice=d.voices[index],candidate=voice.candidates[choice.candidate],tone=d.chord.tones[choice.tone];
  const reject=reason=>freeze({status:'FAIL',reason});budget.charge();
  if(candidate.cut.cmp(d.window[0])<0||candidate.cut.cmp(d.window[1])>0||candidate.cut.cmp(voice.immutableUntil)<0)return reject('Cut is outside its declared editable window');
  const equal=model.space.equivalent(candidate.arrival.pitch,tone.pitch);
  if(equal==='UNKNOWN')return freeze({status:'UNKNOWN',reason:'Arrival pitch equality is unresolved'});
  if(equal!==true)return reject('Assigned tone differs from the actual arrival pitch');
  const prefix=[],removed=[],shortened=[],actualSplits=new Set,permitted=new Set(candidate.splitSourceIds);
  for(const event of voice.source){
    budget.charge();const end=event.t.add(event.d);
    if(event.t.cmp(candidate.cut)>=0){if(voice.locked)return reject('A locked source event would be removed');removed.push(event.id);continue}
    if(end.cmp(candidate.cut)<=0){prefix.push(event);continue}
    if(voice.locked||event.t.cmp(voice.immutableUntil)<0||!permitted.has(event.id))return reject('A source crossing the cut cannot be shortened without explicit permission');
    actualSplits.add(event.id);prefix.push(freeze({...event,d:candidate.cut.sub(event.t)}));
    shortened.push(freeze({sourceId:event.id,previousEnd:String(end),end:String(candidate.cut)}));
  }
  if(actualSplits.size!==permitted.size)return reject('Split permission must name exactly the source events crossing the cut');
  for(const event of candidate.tail){budget.charge();if(event.t.cmp(candidate.cut)<0||event.t.add(event.d).cmp(d.anchor)>0)return reject('A tail event lies outside the cut-to-anchor interval')}
  const added=[...candidate.tail,candidate.arrival],events=[...prefix,...added],usedIds=new Set;
  for(const event of added){budget.charge();if(model.sourceIds.has(event.id))return reject('A replacement event reuses a source identity')}
  for(const event of events){budget.charge();if(usedIds.has(event.id))return reject('The actual joint material has duplicate event identities');usedIds.add(event.id)}
  return freeze({status:'PASS',tone,events:freeze(events),
    assignment:freeze({voiceId:voice.id,candidateId:candidate.id,toneId:tone.id,role:tone.role,pitch:candidate.arrival.pitch}),
    tail:freeze({voiceId:voice.id,candidateId:candidate.id,cut:String(candidate.cut),prefix:freeze(prefix),tail:candidate.tail,
      arrival:candidate.arrival,removedSourceIds:freeze(removed),shortened:freeze(shortened)})});
}
function invokePredicate(state,check,{certified=false,retain=true,local=false}={}){
  const budget=state.budget,usage=state.usage;budget.charge();
  if(certified)usage.certifiedChecks++;else usage.predicateCalls++;
  const remainingWork=budget.limit-budget.used,maxWork=Math.min(state.limits.maxPredicateWork,remainingWork);
  let active=true,reported=0,hasReceipt=false,debitFailure=null,reply,threw=false,refusal=null;
  const consumeWork=amount=>{
    if(!active)fail('Cadence predicate work receipt is no longer active');
    try{
      count(amount,Number.MAX_SAFE_INTEGER);
      if(amount>maxWork-reported)fail('Cadence predicate work allowance exhausted','work-budget');
      budget.charge(amount);reported+=amount;hasReceipt=true;
      if(certified)usage.reportedCertifiedWork+=amount;else usage.reportedPredicateWork+=amount;
    }catch(error){if(error instanceof Refused)debitFailure??=error;throw error}
  };
  try{reply=check(freeze({maxWork,...(certified?{}:{remainingWork}),consumeWork}))}
  catch(error){if(certified&&error instanceof Refused)refusal=error;else threw=true}
  finally{active=false}
  if(!certified){if(hasReceipt)usage.predicateCallsWithReceipts++;else usage.predicateCallsWithoutReceipts++}
  if(debitFailure)throw debitFailure;if(refusal)throw refusal;
  if(threw)return freeze({status:'UNKNOWN',evidence:null,reason:certified?'The certified profile threw':'The whole-joint predicate refused or threw'});
  let status,evidence=null;
  if(typeof reply==='string')status=reply;
  else if(retain){evidence=copy(reply,state);status=dataRecord(evidence)?evidence.status:null}
  else status=dataRecord(reply)?reply.status:null;
  if(!(local?['PASS','FAIL','UNKNOWN','N/A']:['PASS','FAIL','UNKNOWN']).includes(status))
    return freeze({status:'UNKNOWN',evidence,reason:'A predicate did not return a supported status'});
  return freeze({status,evidence});
}
function auditChoice(model,choices,state){
  state=frame(state,'leaf');
  if(!model.rules)return finishAudit('UNKNOWN','No whole-joint rule grammar was supplied',model);
  const d=model.definition,budget=state.budget,assignment=[],tails=[],all=[],usedIds=new Set,toneCounts=new Map,roleCounts=new Map;
  const reject=reason=>finishAudit('FAIL',reason,model);
  for(let i=0;i<d.voices.length;i++){
    const material=reconstructChoice(model,i,choices[i],state);
    if(material.status!=='PASS')return finishAudit(material.status,material.reason,model);
    const tone=material.tone;
    for(const event of material.events){budget.charge();if(usedIds.has(event.id))return reject('The actual joint material has duplicate event identities');usedIds.add(event.id);all.push(event)}
    toneCounts.set(tone.id,(toneCounts.get(tone.id)??0)+1);roleCounts.set(tone.role,(roleCounts.get(tone.role)??0)+1);
    assignment.push(material.assignment);tails.push(material.tail);
  }
  for(const [items,counts] of [[d.chord.tones,toneCounts],[d.chord.roles,roleCounts]])for(const item of items){budget.charge();const n=counts.get(item.id)??0;if(n<item.min||n>item.max)return reject('Chord tone or role cardinality is outside its declared bounds')}
  all.sort((a,b)=>{budget.charge();return a.t.cmp(b.t)||(a.id<b.id?-1:a.id>b.id?1:0)});
  const joint=freeze({modelHash:model.hash,anchor:d.anchor,hitDuration:d.hitDuration,clockDomain:d.clockDomain,
    chord:d.chord,assignment:freeze(assignment),tails:freeze(tails),events:freeze(all),dependencies:d.dependencies});
  const eventHash=hash(joint.events,state),witnessHash=hash(joint,state);
  // The branded profile is a model conjunct, not a caller's claim about checkJoint. Its original full audit is
  // mandatory even when all local checks pass; applicability, domain and unsupported rules remain final gates.
  let status='PASS',evidence=null,profileEvidence=null,reason='Actual retained material, tails and arrivals were checked jointly';
  if(model.rules.decomposition){
    const checked=invokePredicate(state,info=>model.rules.decomposition.audit(joint.events,info),{certified:true});
    status=checked.status;profileEvidence=checked.evidence;if(checked.reason)reason=checked.reason;
  }
  if(model.rules.check&&status!=='FAIL'){
    // Legacy trusted callbacks remain compatible. Only explicit synchronous work receipts enter our ledger.
    const checked=invokePredicate(state,info=>model.rules.check(joint,info));evidence=checked.evidence;if(checked.reason)reason=checked.reason;
    status=checked.status==='FAIL'?'FAIL':status==='UNKNOWN'||checked.status==='UNKNOWN'?'UNKNOWN':'PASS';
  }
  return finishAudit(status,reason,model,
    {contract:freeze({id:model.rules.id,version:model.rules.version}),eventHash,witnessHash,predicateEvidence:evidence,
      ...(model.rules.decomposition?{profileHash:model.rules.decomposition.hash,profileEvidence}:{}),
      assignment:joint.assignment,tails:joint.tails,events:joint.events});
}
function readChoices(model,raw,state){
  dataArray(raw,CADENCE_LIMITS.voices,'Cadence choices');if(raw.length!==model.definition.voices.length)fail('One choice per voice is required');
  const byVoice=new Map;
  for(let i=0;i<raw.length;i++){
    state.budget.charge();const c=fields(raw[i],['voiceId','candidateId','toneId']);
    for(const key of ['voiceId','candidateId','toneId'])text(c[key],state,256);
    if(byVoice.has(c.voiceId))fail('Duplicate chosen voice');byVoice.set(c.voiceId,c);
  }
  return model.definition.voices.map(voice=>{
    const c=byVoice.get(voice.id);if(!c)fail('Choice refers to a missing or undeclared voice');
    const candidate=voice.candidates.findIndex(v=>{state.budget.charge();return v.id===c.candidateId});
    const tone=model.definition.chord.tones.findIndex(v=>{state.budget.charge();return v.id===c.toneId});
    if(candidate<0||tone<0)fail('Choice refers to an undeclared candidate or tone');return {candidate,tone};
  });
}
function run(options,body){
  let budget,limits,state,modelHash=null;
  try{
    if(!dataRecord(options)||Object.keys(options).some(key=>key!=='pruning'&&!Object.hasOwn(CADENCE_DEFAULT_BUDGET,key)))fail('Invalid cadence limits');
    const pruning=Object.hasOwn(options,'pruning')?options.pruning:'none';
    if(!['none','forward'].includes(pruning))fail('Cadence pruning is none or forward');
    limits={};for(const key of Object.keys(CADENCE_DEFAULT_BUDGET))limits[key]=Object.hasOwn(options,key)
      ?count(options[key],key==='maxPredicateWork'?EXACT_LIMITS.maxWork:Number.MAX_SAFE_INTEGER):CADENCE_DEFAULT_BUDGET[key];
    freeze(limits);budget=new CadenceBudget(limits.maxWork);budget.charge();
    state={budget,limits,pruning,events:0,snapshots:0,chars:0,phase:'model',usage:{modelTextChars:0,modelSnapshotNodes:0,
      peakTextChars:0,peakSnapshotNodes:0,peakHashChars:0,leafAudits:0,predicateCalls:0,
      predicateCallsWithReceipts:0,predicateCallsWithoutReceipts:0,reportedPredicateWork:0,
      certifiedChecks:0,reportedCertifiedWork:0,pruningEntries:0}};
    const result=body(state,hash=>{modelHash=hash});
    return freeze({...result,resourceLimits:limits,resourceUsage:freeze({...state.usage})});
  }catch(error){
    if(!(error instanceof Refused))throw error;
    return freeze({status:'UNKNOWN',reason:error.message,kind:error.kind,modelHash,scope,workUsed:budget?.used??0,
      resourceLimits:limits?freeze({...limits}):null,resourceUsage:state?freeze({...state.usage}):null});
  }
}

// A primal checker independent of enumeration. Reconstructs what will actually be audited from immutable choices.
export function auditCadenceInto(spec,choices,options={}){
  return run(options,(state,setHash)=>{if(Object.hasOwn(options,'maxNodes')||Object.hasOwn(options,'pruning'))fail('Independent cadence audit has no search-node or pruning option');const model=normalize(spec,state);setHash(model.hash);
    const result=auditChoice(model,readChoices(model,choices,frame(state,'choices')),state);return freeze({...result,workUsed:state.budget.used});});
}

export function cadenceInto(spec,options={}){
  return run(options,(state,setHash)=>{
    const maxNodes=state.limits.maxNodes,model=normalize(spec,state);setHash(model.hash);
    if(!model.rules)return freeze({status:'UNKNOWN',reason:'No whole-joint rule grammar was supplied',modelHash:model.hash,scope,workUsed:state.budget.used});
    const decomposition=model.rules.decomposition,forward=state.pruning==='forward';
    if(forward&&!decomposition)fail('Forward pruning requires a compiler-branded mandatory profile','out-of-model');
    const variants=[];let countVariants=0;
    for(const voice of model.definition.voices){
      const choices=[];
      for(let i=0;i<voice.candidates.length;i++)for(let j=0;j<model.definition.chord.tones.length;j++){
        state.budget.charge();const equal=model.space.equivalent(voice.candidates[i].arrival.pitch,model.definition.chord.tones[j].pitch);
        if(equal==='UNKNOWN')fail('Arrival pitch equality is unresolved','out-of-model');
        if(equal){if(++countVariants>CADENCE_LIMITS.variants)fail('Cadence assignment-variant budget','work-budget');choices.push(freeze({candidate:i,tone:j}))}
      }
      variants.push(freeze(choices));
    }
    let nodes=0,leaves=0,unknownLeaves=0,pruned=0,solution=null;const chosen=[],toneCounts=new Map,roleCounts=new Map;
    const roles=new Map(model.definition.chord.roles.map(role=>[role.id,role]));
    const pruningInfo={mode:state.pruning,profileHash:decomposition?.hash??null,unaryChecks:0,pairChecks:0,
      cacheHits:0,unknownChecks:0,notApplicableChecks:0,unaryPruned:0,forwardPruned:0,countPruned:0};
    const materialCache=new WeakMap,pairCache=new Map,unaryVoices=new Set,pairVoices=new Map;
    if(forward){
      for(const row of decomposition.unaryScopes){state.budget.charge();unaryVoices.add(row.voiceId)}
      for(const row of decomposition.pairScopes){
        state.budget.charge();const [a,b]=row.voices;
        if(!pairVoices.has(a))pairVoices.set(a,new Set);if(!pairVoices.has(b))pairVoices.set(b,new Set);
        pairVoices.get(a).add(b);pairVoices.get(b).add(a);
      }
    }
    const reserveEntry=()=>{
      state.budget.charge();
      if(state.usage.pruningEntries>=state.limits.maxPruningEntries)fail('Cadence pruning-cache entry budget','work-budget');
      state.usage.pruningEntries++;
    };
    const noteStatus=status=>{if(status==='UNKNOWN')pruningInfo.unknownChecks++;else if(status==='N/A')pruningInfo.notApplicableChecks++};
    function material(index,choice){
      state.budget.charge();const cached=materialCache.get(choice);if(cached){pruningInfo.cacheHits++;return cached}
      reserveEntry();const made=reconstructChoice(model,index,choice,state);let status=made.status;
      const voiceId=model.definition.voices[index].id;
      if(status==='PASS'&&unaryVoices.has(voiceId)){
        pruningInfo.unaryChecks++;
        status=invokePredicate(state,info=>decomposition.unary(voiceId,made.events,info),{certified:true,retain:false,local:true}).status;
        noteStatus(status);
      }
      const record=freeze({material:made,status});materialCache.set(choice,record);return record;
    }
    function compatible(a,ca,b,cb){
      state.budget.charge();
      const va=model.definition.voices[a].id,vb=model.definition.voices[b].id;
      if(!pairVoices.get(va)?.has(vb))return true;
      const key=`${a}:${ca.candidate}:${ca.tone}|${b}:${cb.candidate}:${cb.tone}`;
      if(pairCache.has(key)){pruningInfo.cacheHits++;return pairCache.get(key)!=='FAIL'}
      reserveEntry();const left=material(a,ca),right=material(b,cb);let status='UNKNOWN';
      if(left.status==='FAIL'||right.status==='FAIL')status='FAIL';
      else if(left.material.status==='PASS'&&right.material.status==='PASS'){
        const events=[],ids=new Set;let duplicate=false;
        for(const event of [...left.material.events,...right.material.events]){
          state.budget.charge();if(ids.has(event.id))duplicate=true;ids.add(event.id);events.push(event);
        }
        if(duplicate)status='FAIL';
        else{
          pruningInfo.pairChecks++;
          status=invokePredicate(state,info=>decomposition.pair(va,vb,freeze(events),info),{certified:true,retain:false,local:true}).status;
          noteStatus(status);
        }
      }
      pairCache.set(key,status);return status!=='FAIL';
    }
    let domains=variants;
    if(forward){
      domains=variants.map((values,i)=>{
        const kept=[];for(const choice of values){state.budget.charge();if(material(i,choice).status==='FAIL'){pruningInfo.unaryPruned++;pruned++}else kept.push(choice)}return freeze(kept);
      });
    }
    function canMeetMinima(depth,available){
      for(const [items,counts,isRole] of [[model.definition.chord.tones,toneCounts,false],[model.definition.chord.roles,roleCounts,true]])for(const item of items){
        state.budget.charge();let possible=counts.get(item.id)??0;if(possible>=item.min)continue;
        for(let i=depth;i<available.length;i++){
          state.budget.charge();let matches=false;
          for(const choice of available[i]){state.budget.charge();const tone=model.definition.chord.tones[choice.tone];if((isRole?tone.role:tone.id)===item.id){matches=true;break}}
          if(matches)possible++;
        }
        if(possible<item.min)return false;
      }
      return true;
    }
    function search(depth,available){
      if(nodes>=maxNodes)fail('Cadence search-node budget','work-budget');state.budget.charge();nodes++;
      if(depth===variants.length){leaves++;const audit=auditChoice(model,chosen,state);if(audit.status==='PASS')solution=audit;else if(audit.status==='UNKNOWN')unknownLeaves++;return}
      if(forward&&!canMeetMinima(depth,available)){pruned++;pruningInfo.countPruned++;return}
      for(const choice of available[depth]){
        state.budget.charge();const tone=model.definition.chord.tones[choice.tone],role=roles.get(tone.role);
        const tc=toneCounts.get(tone.id)??0,rc=roleCounts.get(role.id)??0;
        // These upper bounds and the optional certified local FAILs are necessary conditions only.
        if(tc+1>tone.max||rc+1>role.max){pruned++;continue}
        toneCounts.set(tone.id,tc+1);roleCounts.set(role.id,rc+1);chosen.push(choice);
        let next=available,possible=true;
        if(forward){
          next=[...available];
          for(let i=depth+1;i<available.length;i++){
            state.budget.charge();const kept=[];
            for(const candidate of available[i]){
              state.budget.charge();const target=model.definition.chord.tones[candidate.tone];
              const capacity=(toneCounts.get(target.id)??0)<target.max&&(roleCounts.get(target.role)??0)<roles.get(target.role).max;
              if(capacity&&compatible(depth,choice,i,candidate))kept.push(candidate);
              else{pruned++;pruningInfo.forwardPruned++}
            }
            next[i]=freeze(kept);if(!kept.length){possible=false;break}
          }
        }
        if(possible)search(depth+1,next);
        chosen.pop();toneCounts.set(tone.id,tc);roleCounts.set(role.id,rc);if(solution)return;
      }
    }
    search(0,domains);
    const searchInfo=freeze({nodes,leaves,unknownLeaves,pruned,domainComplete:model.definition.domainComplete,pruning:freeze(pruningInfo)});
    if(solution)return freeze({status:'SAT',scope,modelHash:model.hash,search:searchInfo,
      tails:solution.tails,assignment:solution.assignment,events:solution.events,audit:solution,workUsed:state.budget.used});
    return freeze({status:unknownLeaves||!model.definition.domainComplete?'UNKNOWN':'UNSAT',scope,modelHash:model.hash,search:searchInfo,
      reason:unknownLeaves?'At least one complete assignment has an unresolved joint predicate':!model.definition.domainComplete?'The supplied finite candidate domain was declared incomplete':'Every assignment in the supplied complete finite domain is refuted',workUsed:state.budget.used});
  });
}
