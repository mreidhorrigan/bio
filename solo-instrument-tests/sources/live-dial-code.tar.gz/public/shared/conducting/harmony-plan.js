// The conductor's harmony layer (docs/MUSEBOTS_3.md, the second lack: "harmony and themes as layers of the PiecePlanner,
// each at its own horizon"; "mh_HarmonyPulseBOT's line of work splits two ways: the band's harmony becomes the
// conductor's harmony layer ...; its chord drawing becomes a library the players call"). The piece's harmony planned
// with its form, a section at a time as each is committed, before it sounds:
//   - its region (a collection and a tonic) by the section's role in the form: where the form establishes, the region it
//     opened in, or the region before; where it contrasts, a region drawn away, or a state between that and the region
//     before; where it develops, moving; where it returns, home (the piece's opening region, drawn from the seed);
//   - each phrase's progression, as harmonypulse_clodbot draws one (this is its drawing, as a library): a harmonic
//     rhythm in the beats a listener feels whose whole divides the phrase, of one to five chords, played again while a
//     whole one fits, each chord drawn from the region near the one before (opening-harmony.js drawChord);
//   - the section's cadence: its last phrase's last chord its region's tonic stack, and a return's first chord the same,
//     so the form's joins are heard in the harmony -- where its planner plans the piece whole ahead, the section's chords
//     drawn together, conditioned on those ends (Astra's CFM-026 harmony bridge: harmony-bridge.js), so the chords before
//     a cadence lead into it; else written over the chords drawn, as before.
// What a role does is authored (HARMONY_PLAN.roles: weights, the seed choosing among them); nothing here names a key, a
// chord or a progression: every one is drawn from the band's seed and the form.
import {drawCollection,interpolateCollection,collectionPitches,onDivision} from '../collection-space.js';
import {drawChord,placeClass,STACKS} from '../opening-harmony.js';
import {prepareHarmonyBridge,solveHarmonyBridge,sampleHarmonyBridge} from './harmony-bridge.js';
import {exactOfNumber,exactText} from '../bounded-exact.js';
import {feltBeats} from '../meter-tactus.js';

export const HARMONY_PLAN=Object.freeze({
  // Each role's moves, weighted: `stay` the region before, `home` the piece's opening region, `between` a state between
  // the region before and one drawn (at a tenth drawn), `away` one drawn on a tonic drawn (ours, as harmonyspace_clodbot
  // moves; a role not named takes `other`).
  roles:Object.freeze({
    establish:Object.freeze({stay:3,home:1}),
    contrast:Object.freeze({away:3,between:2}),
    develop:Object.freeze({between:3,away:1}),
    climax:Object.freeze({away:2,between:2}),
    return:Object.freeze({home:1}),
    'complex-return':Object.freeze({home:3,between:1}),
    other:Object.freeze({stay:2,between:2,away:1}),
  }),
  tenths:9,
  // A progression of up to this many chords, its whole a divisor of the phrase's felt beats, weighted toward this many
  // beats a chord (harmonypulse_clodbot's HARMONYPULSE_CLODBOT, as a library) at a section of `density` hdensity, and in
  // proportion slower where the section is sparer, faster where it is denser (ours: a harmonic rhythm with the music's
  // activity, as a spare passage's harmony moves slowly).
  chordsAtMost:5,beatsPerChord:2.5,density:.5,
  // The register its chords are drawn in (mh_HarmonyPulseBOT's).
  register:Object.freeze([48,76]),
  // The bridge's exact approximation of the chain's exponential root weights (harmony-bridge.js: its root tickets' bits,
  // the exponential's working precision and its series' terms), no cap on its certified distance from the real-exp chain
  // asked beyond its report (Astra's handoff: the bound, about a thousandth of a percent at the owner's 324 states and
  // forty chords, is reported, not gated); ours.
  bridge:Object.freeze({rootTicketBits:32,expPrecisionBits:80,expTerms:32}),
  // Jazz harmony, as far as its conductor asks (settings.jazz, 0 to 1; the owner, 4 October 2026: "integrate the other
  // aesthetics with the orchestral one ... some that use jazz harmony"): its chords' stacks between its own (STACKS) and
  // a jazz player's -- the collection's thirds, four of them most (a seventh chord), three now and then -- and its roots
  // drawn toward falling by a fifth (up a fourth, 4:3, in any tuning: the ii-V-I's motion; M. Levine, The Jazz Theory
  // Book, Sher Music 1995, ch. 2), as far as it is asked (ours).
  jazz:Object.freeze({steps:Object.freeze([Object.freeze([2,1])]),sizes:Object.freeze([Object.freeze([4,1]),Object.freeze([3,.25])]),
    motion:Object.freeze({interval:12*Math.log2(4/3),width:.5})}),
});
// A chord vocabulary `jazz` (0 to 1) of the way from its own stacks to jazz's (HARMONY_PLAN.jazz): each step's and size's
// weight as a share of its stacks' whole, blended, and the root motion's weight `jazz`; at 0 its own stacks as they are.
// -> drawChord's options.
export function jazzLanguage(jazz){
  const j=Math.max(0,Math.min(1,Number(jazz)||0));if(!(j>0))return {steps:STACKS.steps,sizes:STACKS.sizes};
  const blend=(own,theirs)=>{
    const total=list=>list.reduce((sum,[,w])=>sum+w,0),a=total(own),b=total(theirs),out=new Map;
    for(const [k,w] of own)out.set(k,(out.get(k)??0)+(1-j)*w/a);for(const [k,w] of theirs)out.set(k,(out.get(k)??0)+j*w/b);
    return [...out].filter(([,w])=>w>0).sort((x,y)=>x[0]-y[0]);
  };
  return {steps:blend(STACKS.steps,HARMONY_PLAN.jazz.steps),sizes:blend(STACKS.sizes,HARMONY_PLAN.jazz.sizes),...(j>0?{motion:{...HARMONY_PLAN.jazz.motion,weight:j}}:{})};
}

const weighted=(entries,random)=>{let draw=random()*entries.reduce((sum,[,w])=>sum+w,0);for(const [value,w] of entries){draw-=w;if(draw<=0)return value}return entries.at(-1)[0]};

// A section's region for its role: {collection, tonic, move}. `previous` the region before (null at the piece's start,
// which is home), `home` the piece's opening region ({collection, tonic}: openingHarmony's). `division`: the equal steps
// an octave its harmony is planned in, where its conductor plans in one -- every region's collection and tonic that
// division's nearest (collection-space.js onDivision); none, as drawn.
export function regionFor(role,options){
  const region=drawnRegion(role,options),division=Number(options?.division);
  if(!(division>=1))return region;
  const step=12/Math.round(division);
  return {...region,collection:onDivision(region.collection,division),tonic:+(Math.round(region.tonic/step)*step).toFixed(6)};
}
function drawnRegion(role,{previous=null,home,random}){
  if(!previous)return {collection:home.collection,tonic:home.tonic,move:'home'};
  const moves=Object.entries(HARMONY_PLAN.roles[role]??HARMONY_PLAN.roles.other).filter(([,w])=>w>0),move=weighted(moves,random);
  if(move==='stay')return {collection:previous.collection,tonic:previous.tonic,move};
  if(move==='home')return {collection:home.collection,tonic:home.tonic,move};
  const target=drawCollection(random);
  if(move==='between'){const t=(1+Math.floor(random()*HARMONY_PLAN.tenths))/(HARMONY_PLAN.tenths+1);return {collection:interpolateCollection(previous.collection,target,t),tonic:previous.tonic,move,t}}
  return {collection:target,tonic:placeClass(Math.floor(random()*12),previous.tonic),move:'away'};
}
// A phrase's harmonic rhythm in felt beats: a length dividing the phrase's `beats` (its divisors weighted toward
// beatsPerChord a chord), split at points drawn among one to chordsAtMost chords. Feasible by construction.
export function phraseRhythm(beats,random,{beatsPerChord=HARMONY_PLAN.beatsPerChord}={}){
  const {chordsAtMost}=HARMONY_PLAN,phrase=Math.max(1,Math.round(beats));
  const lengths=[];for(let length=1;length<=phrase;length++)if(phrase%length===0)lengths.push(length);
  const weights=lengths.map(length=>[length,Math.exp(-Math.abs(Math.log(length/(beatsPerChord*Math.min(chordsAtMost,length)))))]);
  const total=weighted(weights,random),chords=1+Math.floor(random()*Math.min(chordsAtMost,total)),left=total-chords;
  const cuts=Array.from({length:chords-1},()=>Math.floor(random()*(left+1))).sort((a,b)=>a-b),points=[0,...cuts,left];
  return points.slice(1).map((point,index)=>1+point-points[index]);
}
// A region's tonic stack: the pitch of its tonic's class nearest the register's middle, and the collection's pitches
// two steps above it each (its thirds, in a heptatonic), three at most.
export function tonicChord(pitches,tonic){
  if(!pitches.length)return [];
  const middle=(HARMONY_PLAN.register[0]+HARMONY_PLAN.register[1])/2,place=placeClass(tonic,middle);
  let root=0;for(let k=1;k<pitches.length;k++)if(Math.abs(pitches[k]-place)<Math.abs(pitches[root]-place))root=k;
  const step=pitches.length>=7?2:1;return [0,1,2].map(k=>pitches[root+k*step]).filter(Number.isFinite);
}
// A section's felt beats a bar at its tempo.
export function sectionBeats(section){
  const meter={numerator:section.numerator,denominator:section.denominator,groups:section.groups??[],subdivision:section.subdivision??4,pulsesPerBar:section.numerator*(section.subdivision??4)};
  return feltBeats(meter,{secondsPerTick:60/(Number(section.tempo?.targetBpm)||120)/(section.subdivision??4)}).length;
}
// A section's harmony: {region, beatsPerBar, phrases: [{durations (felt beats), chords}]}. `section`: the form's
// ({role, phrases, phraseBars, numerator, denominator, groups, subdivision, tempo}); `previous`: the section before's
// harmony (its region and last chord), null at the start; `home`; `last`: whether it is the piece's last section.
// The section's chords drawn together from the chain drawChord walks (its stacks, its roots near the chord before's lowest,
// a repeat the less likely) under the exact law of that chain given `constraints` ([{at (1-based), chord}]): the bridge
// (Astra's CFM-026: harmony-bridge.js, prepared, solved, one whole path drawn from its law; its certificate checked in
// development). The chain declared
// exactly -- its coordinates the register's pitches and its weights at their shortest decimals (0.4 is 2/5), a repeat a
// millionth of a semitone apart -- its draws uniform words of `random`. -> [[pitch, ...]] a chord, or null where it
// refuses (EMPTY: no path of the chain reaches the constraints; UNKNOWN: past its limits).
function bridgedChords({pitches,previous,horizon,constraints,random,language={steps:STACKS.steps,sizes:STACKS.sizes}}){
  const exact=value=>exactText(exactOfNumber(value)),byText=new Map(pitches.map(pitch=>[exact(pitch),pitch]));
  if(byText.size!==pitches.length)return null;
  // (One constraint a chord: a section of one chord its return's and its cadence's both, the same tonic.)
  const at=new Map;for(const constraint of constraints)if(!at.has(constraint.at))at.set(constraint.at,constraint);
  const prepared=prepareHarmonyBridge({id:'section-harmony',revision:1,coordinateUnit:'semitones',pitches:pitches.map(exact),previous:previous?.length?previous.map(exact):null,
    steps:language.steps.map(([step,weight])=>({step,weight:exact(weight)})),sizes:language.sizes.map(([size,weight])=>({size,weight:exact(weight)})),reach:exact(STACKS.reach),repeat:exact(STACKS.repeat),
    // (Its roots drawn toward a motion as drawChord draws them, where its language has one: the Number interval drawChord
    // uses, bound exactly as its reach is -- Astra's root-motion term, HM1-HM5.)
    ...(language.motion?{motion:{interval:exact(language.motion.interval),weight:exact(language.motion.weight),width:exact(language.motion.width),period:'12'}}:{}),
    repeatTolerance:'1/1000000',horizon,constraints:[...at.values()].map(({at,chord})=>({at,allowed:[chord.map(exact)]})),approximation:{...HARMONY_PLAN.bridge,maxConditionalTV:null},dependencies:[]});
  if(prepared.status!=='PASS')return null;
  const solved=solveHarmonyBridge(prepared.prepared);if(solved.status!=='CERTIFIED'||!solved.plan)return null;
  const drawn=sampleHarmonyBridge(solved.plan,()=>Math.floor(random()*2**32)>>>0,{});if(drawn.status!=='SELECTED')return null;
  const chords=drawn.path.chords.map(chord=>chord.map(text=>byText.get(text)));
  return chords.length===horizon&&chords.every(chord=>chord.every(Number.isFinite))?chords:null;
}
// `bridge`: whether its chords are drawn together, conditioned on its ends (its planner planning the piece whole ahead).
// `jazz`: how far its chords are a jazz player's (jazzLanguage), its roots' motion weighed by the bridge too.
export function sectionHarmony(section,{previous=null,home,random,last=false,division=null,bridge=false,jazz=0}){
  const language=jazzLanguage(jazz),draw=before=>drawChord(pitches,random,{previous:before,steps:language.steps,sizes:language.sizes,...(language.motion?{motion:language.motion}:{})});
  const region=regionFor(section.role,{previous:previous?.region??null,home,random,division}),[low,high]=HARMONY_PLAN.register;
  const pitches=collectionPitches(region.collection,{tonic:region.tonic,low,high}),beatsPerBar=sectionBeats(section);
  const phraseBeats=Math.max(1,(Number(section.phraseBars)||4)*beatsPerBar),count=Math.max(1,Number(section.phrases)||1);
  // (A chord as many felt beats as its density allows, that many times more where the conductor elongates its piece.)
  const density=Number.isFinite(section.hdensity)?Math.max(.05,section.hdensity):HARMONY_PLAN.density,beatsPerChord=HARMONY_PLAN.beatsPerChord*HARMONY_PLAN.density/density*Math.max(1,Number(section.elongation)||1);
  let before=previous?.lastChord??null;const phrases=[];
  // (A return's first chord and the section's cadence: its region's tonic stack.)
  const tonic=tonicChord(pitches,region.tonic),returning=Boolean(tonic.length&&region.move==='home'&&previous);
  // (Drawn together, its phrases' rhythms first, its chords conditioned on its ends; where the bridge refuses, as below.)
  let bridged=false;
  if(bridge&&tonic.length){
    const rhythms=Array.from({length:count},()=>phraseRhythm(phraseBeats,random,{beatsPerChord})),horizon=rhythms.reduce((sum,durations)=>sum+durations.length,0);
    const path=bridgedChords({pitches,previous:before,horizon,constraints:[...(returning?[{at:1,chord:tonic}]:[]),{at:horizon,chord:tonic}],random,language});
    let at=0;
    for(const durations of rhythms){const chords=path?path.slice(at,at+durations.length):durations.map(()=>{const chord=draw(before);before=chord;return chord});at+=durations.length;phrases.push({durations,chords})}
    bridged=Boolean(path);
  }
  else for(let k=0;k<count;k++){
    const durations=phraseRhythm(phraseBeats,random,{beatsPerChord});
    const chords=durations.map(()=>{const chord=draw(before);before=chord;return chord});
    phrases.push({durations,chords});
  }
  if(!bridged){
    if(returning)phrases[0].chords[0]=tonic;
    if(tonic.length){phrases.at(-1).chords[phrases.at(-1).chords.length-1]=tonic}
  }
  return {region:{collection:region.collection,tonic:region.tonic,move:region.move,...(region.t!=null?{t:region.t}:{})},beatsPerBar,phraseBeats,phrases,lastChord:phrases.at(-1).chords.at(-1),...(bridged?{bridged:true}:{}),...(last?{last:true}:{}),
    ...(language.motion?{jazz:+Math.max(0,Math.min(1,Number(jazz))).toFixed(3)}:{})};
}
// The chord sounding at a felt beat of a section (`beat` from its start): {chord, step (which chord of which time
// through which phrase: said once)}. A phrase's progression played again while a whole one fits, its last chord held to
// the phrase's end, as harmonypulse_clodbot plays one.
// A span of it held (`holds`: [{from, to}], felt beats: a coordinated hit's bar, plex_clodbot) sounds the chord its
// start does throughout.
export function chordAt(harmony,beat){
  const held=harmony.holds?.find(span=>beat>=span.from&&beat<span.to);if(held)beat=held.from;
  const per=harmony.phraseBeats,index=Math.min(harmony.phrases.length-1,Math.max(0,Math.floor(beat/per))),phrase=harmony.phrases[index];
  const total=phrase.durations.reduce((a,b)=>a+b,0),within=beat-index*per,times=Math.max(1,Math.floor(per/total)),time=Math.min(times-1,Math.floor(within/total));
  let at=within-time*total,k=0;while(k<phrase.durations.length-1&&at>=phrase.durations[k])at-=phrase.durations[k++];
  return {chord:phrase.chords[k],step:`${index}:${time}:${k}`};
}
