// Exact finite maps between declared time domains (fugue-and-coordination, CF02/GC01/GC07/GC17).
// Map both endpoints of a sounding interval; a local slope times its duration is wrong across a knot. These maps
// describe score/common-time geometry, not measured clocks, sample accuracy, authority or action readiness.
import {Q,normalizeEvents} from './canon-core.js';
import {Refused,sha256,pythonJson} from '../bounded-exact.js';
import {dataRecord,dataArray} from './contract-data.js';

export const CANON_TIME_LIMITS=Object.freeze({knots:1024,id:256});
const maps=new WeakMap;
const fail=(message,kind='invalid-input')=>{throw new Refused(message,{kind})};
const name=value=>{if(typeof value!=='string'||!value.length||value.length>CANON_TIME_LIMITS.id)fail('Time domains/maps require bounded names');return value};
const domain=value=>{
  if(!dataRecord(value)||Object.keys(value).some(key=>!['id','unit','revision'].includes(key)))fail('A time domain needs id, unit and optional revision');
  const revision=value.revision??0;if(!Number.isSafeInteger(revision)||revision<0)fail('Invalid clock-domain revision');
  return Object.freeze({id:name(value.id),unit:name(value.unit),revision});
};
const sameDomain=(a,b)=>a.id===b.id&&a.unit===b.unit&&a.revision===b.revision;
const prepared=map=>{const value=maps.get(map);if(!value)fail('Use a prepared time map');return value};

// Knots are {source, target}; source increases, target must strictly increase or strictly decrease throughout.
// Decreasing maps are finite reversals, not clocks that a live musician can follow causally.
export function piecewiseTime(spec={}){
  if(!dataRecord(spec))fail('A time map is a data record');let {id,source,target,knots}=spec;
  name(id);source=domain(source);target=domain(target);
  if(!Array.isArray(knots)||knots.length<2)fail('At least two time-map knots are required');
  if(knots.length>CANON_TIME_LIMITS.knots)fail('Time-map knot limit','work-budget');
  dataArray(knots,CANON_TIME_LIMITS.knots,'Time-map knots');
  const points=[];let direction=0;
  for(let i=0;i<knots.length;i++){
    if(!dataRecord(knots[i])||Object.keys(knots[i]).some(key=>!['source','target'].includes(key)))fail('Invalid time-map knot');
    const point=Object.freeze({source:Q(knots[i].source),target:Q(knots[i].target)});
    if(i){
      if(point.source.cmp(points[i-1].source)<=0)fail('Source knots must strictly increase');
      const move=point.target.cmp(points[i-1].target);
      if(!move||direction&&move!==direction)fail('Time map must be strictly monotone');direction=move;
    }
    points.push(point);
  }
  const definition=Object.freeze({id,source,target,knots:Object.freeze(points.map(p=>Object.freeze({source:String(p.source),target:String(p.target)})))});
  const hash=sha256(pythonJson(definition));
  function evaluate(value,inverse=false){
    const q=Q(value),input=inverse?'target':'source',output=inverse?'source':'target',order=inverse?direction:1;
    if(order*q.cmp(points[0][input])<0||order*q.cmp(points.at(-1)[input])>0)fail('Outside the declared finite time-map domain','out-of-model');
    let lo=0,hi=points.length-1;
    while(hi-lo>1){const mid=(lo+hi)>>1;if(order*q.cmp(points[mid][input])<0)hi=mid;else lo=mid}
    const a=points[lo],b=points[hi],fraction=q.sub(a[input]).div(b[input].sub(a[input]));
    return a[output].add(fraction.mul(b[output].sub(a[output])));
  }
  const map=Object.freeze({id,source,target,definition,hash,direction,
    at:value=>evaluate(value),inverse:value=>evaluate(value,true)});
  maps.set(map,Object.freeze(points));return map;
}

// delay and stretch have target and target/source units. For reversal, t -> delay + stretch*(length-t).
export function affineTime(spec={}){
  if(!dataRecord(spec))fail('A time map is a data record');const {id,source,target,length,delay=0,stretch=1,retrograde=false}=spec;
  const L=Q(length),offset=Q(delay),rate=Q(stretch);
  if(L.cmp(0)<=0||rate.cmp(0)<=0||typeof retrograde!=='boolean')fail('Positive length/stretch and boolean reversal required');
  const end=offset.add(rate.mul(L));
  return piecewiseTime({id,source,target,knots:[{source:0,target:retrograde?end:offset},{source:L,target:retrograde?offset:end}]});
}

// Composition retains first-map knots plus the preimages of all second-map knots inside the first's output range.
// On every resulting cell both stages are affine, so these endpoints specify the exact composed function.
export function composeTimeMaps(first,second,{id}={}){
  const a=prepared(first),b=prepared(second);name(id);
  if(!sameDomain(first.target,second.source))fail('Composed time domains or revisions differ','stale-context');
  const lower=first.direction>0?a[0].target:a.at(-1).target,upper=first.direction>0?a.at(-1).target:a[0].target;
  second.at(lower);second.at(upper);const points=new Map(a.map(p=>[String(p.source),p.source]));
  for(const p of b)if(p.source.cmp(lower)>0&&p.source.cmp(upper)<0){const q=first.inverse(p.source);points.set(String(q),q)}
  if(points.size>CANON_TIME_LIMITS.knots)fail('Composed time-map knot limit','work-budget');
  return piecewiseTime({id,source:first.source,target:second.target,
    knots:[...points.values()].sort((x,y)=>x.cmp(y)).map(q=>({source:q,target:second.at(first.at(q))}))});
}

// Fresh event snapshots, exact durations and unchanged pitch semantics. Negative relative entries must first be
// given a common nonnegative origin: we do not independently slide a voice and silently alter its relationship.
export function transformThroughTime(events,map,{entryId,voiceId,maxWork}={}){
  prepared(map);name(entryId);if(voiceId!==undefined)name(voiceId);
  const source=normalizeEvents(events,{maxWork});
  const out=source.map(event=>{
    if(event.clockDomain&&!sameDomain(domain(event.clockDomain),map.source))fail('Event clock domain or revision differs','stale-context');
    const a=map.at(event.t),b=map.at(event.t.add(event.d)),t=map.direction>0?a:b,d=map.direction>0?b.sub(a):a.sub(b);
    if(t.cmp(0)<0)fail('Assign a common nonnegative origin before realizing this entry');
    return {...event,id:`${entryId}:${event.id}`,sourceId:event.id,entryId,...(voiceId===undefined?{}:{voiceId}),
      t,d,clockDomain:map.target,timeMapHash:map.hash};
  });
  return normalizeEvents(out,{maxWork});
}

// A constant additional lead for streamed onsets over the ENTIRE requested source interval. Availability and follower
// maps share source and common-clock domains. Their difference is affine between the union of their knots, hence
// the maximum occurs at an endpoint. Unavailable releases/retrograde/gestures need stronger information contracts.
export function minimumCausalLead({availability,follower,from,to,latency=0}={}){
  const a=prepared(availability),b=prepared(follower),start=Q(from),end=Q(to),lag=Q(latency);
  if(start.cmp(end)>0||lag.cmp(0)<0)fail('Invalid causal interval or latency');
  if(availability.direction<0||follower.direction<0)fail('Live onset bound requires forward maps','out-of-model');
  if(!sameDomain(availability.source,follower.source)||!sameDomain(availability.target,follower.target))fail('Causal maps use different source/common-clock domains','stale-context');
  for(const map of [availability,follower]){map.at(start);map.at(end)}
  const points=new Map([[String(start),start],[String(end),end]]);
  for(const p of [...a,...b])if(p.source.cmp(start)>0&&p.source.cmp(end)<0)points.set(String(p.source),p.source);
  let lead=Q(0),witness=null;
  for(const q of points.values()){
    const available=availability.at(q).add(lag),scheduled=follower.at(q),needed=available.sub(scheduled);
    if(needed.cmp(lead)>0){lead=needed;witness=Object.freeze({source:String(q),availableAt:String(available),scheduledAt:String(scheduled)})}
  }
  return Object.freeze({lead:String(lead),unit:availability.target.unit,clock:availability.target,
    sourceInterval:Object.freeze([String(start),String(end)]),witness,checkedPoints:points.size,
    availabilityHash:availability.hash,followerHash:follower.hash,scope:'exact supplied maps; onset information only'});
}
