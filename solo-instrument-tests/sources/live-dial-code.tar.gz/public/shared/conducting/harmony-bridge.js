// CFM-026 / CF18: conditional harmony from a declared rational approximation to an explicit exponential chain.
// Exact means the declared finite law. The comparison bound names a real-exp model on exact caller parameters;
// it does not assert legacy binary64/seed parity, heard phrase-loop validity or authority to change future music.
import {Refused,ZERO,ONE,exactOf,exactText,add,sub,mul,div,compare,bitsOf,pythonJson,sha256} from '../bounded-exact.js';
import {dataRecord,dataArray} from './contract-data.js';
import {expNegativeDyadic} from './certified-exponential.js';
import {log2PositiveDyadic} from './certified-log2-dyadic.js';

export const HARMONY_BRIDGE_LIMITS=Object.freeze({maxWork:8000000,maxPitches:64,maxStacks:32,maxStates:512,
  maxKernels:4096,maxKernelEntries:131072,maxHorizon:128,maxMessages:65536,maxTicketBits:8192,
  maxDependencies:128,maxTextChars:33554432,maxCertificateChars:33554432});
const freeze=Object.freeze,models=new WeakMap,plans=new WeakMap,rawBound=1n<<256n;
const scope='exact-conditioned-declared-rational-harmony-chain',reference='real-exp-on-declared-exact-parameters-v1';
const fail=(message,kind='invalid-input')=>{throw new Refused(message,{kind})};
class BadCertificate extends Error {}
const requireCertificate=(v,message)=>{if(!v)throw new BadCertificate(message)};
function stateOf(options){
  if(!dataRecord(options)||Object.keys(options).some(k=>!Object.hasOwn(HARMONY_BRIDGE_LIMITS,k)))fail('Unknown harmony-bridge limits');
  const limits={};for(const [key,cap] of Object.entries(HARMONY_BRIDGE_LIMITS)){
    const value=Object.hasOwn(options,key)?options[key]:cap;
    if(!Number.isSafeInteger(value)||value<0||value>cap)fail('Limits may only lower their declared safe caps');limits[key]=value;
  }
  const s={limits:freeze(limits),used:0,chars:0,modelHash:null};
  s.charge=(n=1)=>{if(!Number.isSafeInteger(n)||n<0)throw new Error('Invalid work charge');
    if(n>limits.maxWork-s.used)fail('Harmony bridge work allowance exhausted','work-budget');s.used+=n};
  s.math={add(a,b){s.charge();return add(a,b)},sub(a,b){s.charge();return sub(a,b)},mul(a,b){s.charge();return mul(a,b)},
    div(a,b){s.charge();return div(a,b)},compare(a,b){s.charge();return compare(a,b)}};
  s.charge();return s;
}
function fields(v,keys,s){
  s.charge();if(!dataRecord(v)||Object.keys(v).length!==keys.length||keys.some(k=>!Object.hasOwn(v,k)))fail('Missing or unsupported bridge fields');s.charge(keys.length);return v;
}
function list(v,limit,s,label){
  if(!Array.isArray(v)||v.length>limit)fail(label+' exceeds array allowance','shape-budget');s.charge(v.length+1);return dataArray(v,limit,label);
}
function text(v,s,limit=256){
  if(typeof v!=='string'||!v.length||v.length>limit)fail('Bounded nonempty text required');
  if(v.length>s.limits.maxTextChars-s.chars)fail('Bridge text allowance','work-budget');s.chars+=v.length;s.charge(1+Math.ceil(v.length/64));return v;
}
function integer(v){
  const n=typeof v==='bigint'?v:Number.isSafeInteger(v)?BigInt(v):null;
  if(n===null||n<=-rawBound||n>=rawBound)fail('Exact raw components need at most256bits','arithmetic-budget');return n;
}
function rational(v,s){
  s.charge();let n,d=1n;
  if(typeof v==='string'){
    text(v,s,160);const match=v.match(/^([+-]?[0-9]+)(?:\/([+-]?[0-9]+))?$/);
    if(!match||match[0].length!==v.length)fail('Use exact integer or fraction text');n=integer(BigInt(match[1]));d=integer(BigInt(match[2]??'1'));
  }else if(v&&typeof v==='object'){fields(v,['n','d'],s);n=integer(v.n);d=integer(v.d)}else n=integer(v);
  if(!d)fail('Zero denominator');return exactOf({n,d});
}
function nonnegative(v,s){const q=rational(v,s);if(q.n<0n)fail('Negative weight/tolerance');return q}
function natural(v,limit,label){if(!Number.isSafeInteger(v)||v<0||v>limit)fail('Invalid '+label);return v}
function magnitude(q){return q.n<0n?{n:-q.n,d:q.d}:q}
function bounded(n,s){s.charge();if(bitsOf(n)>8192)fail('Derived integer exceeds8192bits','arithmetic-budget');return n}
function ticket(n,s){s.charge();if(n<0n||bitsOf(n)>s.limits.maxTicketBits)fail('Bridge ticket allowance','arithmetic-budget');return n}
function gcd(a,b,s){while(b){s.charge();[a,b]=[b,a%b]}return a}
const up=(n,d)=>n/d+(n%d?1n:0n);
const abs=n=>n<0n?-n:n;
const derived=(n,d=1n)=>exactOf({n,d},{bits:8192});
function hash(v,s,cap=s.limits.maxTextChars){
  const parts=[];let size=0;
  const append=x=>{if(x.length>cap-size)fail('Canonical bridge text allowance','work-budget');size+=x.length;parts.push(x)};
  function encode(x,depth=0){
    s.charge();if(depth>20)fail('Bridge data too deep');
    if(x===null||typeof x==='boolean'||typeof x==='string'||typeof x==='number'&&Number.isSafeInteger(x)){append(pythonJson(x));return}
    if(Array.isArray(x)){
      list(x,65536,s,'Canonical array');append('[');for(let i=0;i<x.length;i++){if(i)append(',');encode(x[i],depth+1)}append(']');return;
    }
    if(!dataRecord(x))fail('Canonical ordinary data required');const keys=Object.keys(x);if(keys.length>64)fail('Canonical record too wide');
    keys.sort((a,b)=>{s.charge();return a<b?-1:a>b?1:0});append('{');
    for(let i=0;i<keys.length;i++){if(i)append(',');append(pythonJson(keys[i]));append(':');encode(x[keys[i]],depth+1)}append('}');
  }
  encode(v);s.charge(1+Math.ceil(size/64));return sha256(parts.join(''));
}
function deepFreeze(v){if(v&&typeof v==='object'&&!Object.isFrozen(v)){for(const x of Object.values(v))deepFreeze(x);freeze(v)}return v}
const chordKey=values=>values.map(exactText).join(',');
function coordinates(v,s,label){return freeze(list(v,s.limits.maxPitches,s,label).map(value=>rational(value,s)))}
function normalize(raw,s){
  fields(raw,['id','revision','coordinateUnit','pitches','previous','steps','sizes','reach','repeat','repeatTolerance','horizon','constraints','approximation','dependencies',
    ...(dataRecord(raw)&&Object.hasOwn(raw,'motion')?['motion']:[])],s);
  const id=text(raw.id,s),revision=natural(raw.revision,Number.MAX_SAFE_INTEGER,'revision'),coordinateUnit=text(raw.coordinateUnit,s);
  const pitches=coordinates(raw.pitches,s,'Register pitches');if(!pitches.length)fail('An explicit nonempty register is required','out-of-model');
  for(let i=1;i<pitches.length;i++)if(s.math.compare(pitches[i-1],pitches[i])>=0)fail('Register coordinates must strictly increase');
  const previous=raw.previous===null?null:coordinates(raw.previous,s,'Previous chord');
  function choices(v,name){return freeze(list(v,s.limits.maxStacks,s,name).map(item=>{
    fields(item,[name,'weight'],s);const value=natural(item[name],64,name);if(!value)fail('Positive integral stack dimension required');
    return freeze({[name]:value,weight:nonnegative(item.weight,s)});
  }))}
  const steps=choices(raw.steps,'step'),sizes=choices(raw.sizes,'size'),reach=nonnegative(raw.reach,s);
  if(!reach.n)fail('Reach must be positive');const repeat=nonnegative(raw.repeat,s),repeatTolerance=nonnegative(raw.repeatTolerance,s);
  const horizon=natural(raw.horizon,s.limits.maxHorizon,'horizon'),a=fields(raw.approximation,['rootTicketBits','expPrecisionBits','expTerms','maxConditionalTV'],s);
  const rootTicketBits=natural(a.rootTicketBits,128,'root ticket bits'),expPrecisionBits=natural(a.expPrecisionBits,256,'exponential bits'),expTerms=natural(a.expTerms,128,'exponential degree');
  if(rootTicketBits<1||expPrecisionBits<16||expTerms<2||expTerms%2)fail('Declare positive root bits,16..256 exponential bits, and even degree2..128');
  const maxConditionalTV=a.maxConditionalTV===null?null:nonnegative(a.maxConditionalTV,s);
  if(maxConditionalTV&&s.math.compare(maxConditionalTV,ONE)>0)fail('TV limit exceeds one');
  const constraints=[],positions=new Set;
  for(const c of list(raw.constraints,horizon,s,'Emission constraints')){
    fields(c,['at','allowed'],s);const at=natural(c.at,horizon,'constraint position');if(!at||positions.has(at))fail('Unique1-based emission positions required');positions.add(at);
    const allowed=[],seen=new Set;
    for(const values of list(c.allowed,s.limits.maxStates,s,'Allowed chords')){
      const chord=coordinates(values,s,'Allowed chord'),key=chordKey(chord);if(seen.has(key))fail('Duplicate allowed chord');seen.add(key);allowed.push(chord);
    }constraints.push(freeze({at,allowed:freeze(allowed),keys:seen}));
  }
  const dependencies=[],depIds=new Set;
  for(const r of list(raw.dependencies,s.limits.maxDependencies,s,'Dependencies')){
    fields(r,['id','revision','hash'],s);const name=text(r.id,s),value=text(r.hash,s);
    if(depIds.has(name)||value.length!==64||!/^[0-9a-f]{64}$/.test(value))fail('Unique dependency IDs and SHA-256 required');depIds.add(name);
    dependencies.push(freeze({id:name,revision:natural(r.revision,Number.MAX_SAFE_INTEGER,'dependency revision'),hash:value}));
  }
  const motion=motionOf(raw.motion,s);
  const definition=deepFreeze({kind:'harmony-bridge-v1',reference:motion?'real-exp-on-declared-rational-or-log2-parameters-v1':reference,id,revision,coordinateUnit,pitches:pitches.map(exactText),previous:previous?.map(exactText)??null,
    steps:steps.map(x=>({step:x.step,weight:exactText(x.weight)})),sizes:sizes.map(x=>({size:x.size,weight:exactText(x.weight)})),
    reach:exactText(reach),repeat:exactText(repeat),repeatTolerance:exactText(repeatTolerance),horizon,
    constraints:constraints.map(c=>({at:c.at,allowed:c.allowed.map(chord=>chord.map(exactText))})),
    approximation:{rootTicketBits,expPrecisionBits,expTerms,maxConditionalTV:maxConditionalTV===null?null:exactText(maxConditionalTV)},dependencies,
    ...(motion?{motion:motion.definition}:{})});
  s.modelHash=hash(definition,s);return {definition,pitches,previous,steps,sizes,reach,repeat,repeatTolerance,horizon,constraints,rootTicketBits,expPrecisionBits,expTerms,maxConditionalTV,motion};
}
function motionOf(raw,s){
  if(raw===undefined||raw===null)return null;
  fields(raw,['interval','weight','width','period'],s);
  const weight=nonnegative(raw.weight,s),width=nonnegative(raw.width,s),period=nonnegative(raw.period,s);
  if(s.math.compare(weight,ONE)>0||!width.n||!period.n)fail('Motion needs weight in[0,1] and positive width/period');
  let interval,definition;
  if(dataRecord(raw.interval)&&Object.hasOwn(raw.interval,'log2')){
    fields(raw.interval,['log2','scale'],s);const ratio=nonnegative(raw.interval.log2,s),scale=nonnegative(raw.interval.scale,s);
    if(!ratio.n||!scale.n)fail('Logarithmic interval needs a positive ratio and scale');
    interval={ratio,scale};definition={log2:exactText(ratio),scale:exactText(scale)};
  }else{interval=rational(raw.interval,s);definition=exactText(interval)}
  if(!weight.n)return null; // A no-op retains the previous definition, kernels, hashes and draws exactly.
  return {interval,weight,width,period,definition:{interval:definition,weight:exactText(weight),width:exactText(width),period:exactText(period)}};
}
function residue(value,period,s){
  const divided=s.math.div(value,period),k=divided.n/divided.d-(divided.n<0n&&divided.n%divided.d?1n:0n);
  return s.math.sub(value,s.math.mul(period,derived(k)));
}
function motionCompiler(model,s,scale){
  if(!model.motion)return null;
  const {interval,weight,width,period}=model.motion,m=s.math,options={precisionBits:model.expPrecisionBits,terms:model.expTerms,charge:s.charge};
  let low=interval,high=interval;
  if(interval.ratio){
    const bounds=log2PositiveDyadic(interval.ratio,options);
    low=m.mul(derived(bounds.lower,bounds.scale),interval.scale);high=m.mul(derived(bounds.upper,bounds.scale),interval.scale);
  }
  const centre=m.div(m.add(low,high),exactOf(2)),radius=m.div(m.sub(high,low),exactOf(2)),half=m.div(period,exactOf(2));
  const cache=new Map;
  return {interval:{lower:exactText(low),upper:exactText(high)},cache,
    phase:value=>exactText(residue(value,period,s)),
    at(pitch,lowest){
      const delta=residue(m.sub(pitch,lowest),period,s),key=exactText(delta);
      if(cache.has(key))return cache.get(key);
      if(cache.size>=s.limits.maxKernelEntries)fail('Motion enclosure catalogue allowance','shape-budget');
      const off=residue(m.sub(delta,centre),period,s),other=m.sub(period,off),distance=m.compare(off,other)<0?off:other;
      let lo=m.sub(distance,radius),hi=m.add(distance,radius);if(lo.n<0n)lo=ZERO;if(m.compare(hi,half)>0)hi=half;
      // Circular distance is1-Lipschitz. Decreasing exp maps the distance enclosure with endpoints reversed.
      const lower=expNegativeDyadic(m.div(hi,width),options).lower,upper=expNegativeDyadic(m.div(lo,width),options).upper;
      const constant=bounded((weight.d-weight.n)*scale,s);
      const bound={delta:key,distance:{lower:exactText(lo),upper:exactText(hi)},
        lower:bounded(constant+weight.n*lower,s)/weight.d,upper:up(bounded(constant+weight.n*upper,s),weight.d),scale};
      cache.set(key,bound);return bound;
    }};
}
function stackIntegers(stacks,s){
  let denominator=1n;for(const a of stacks)denominator=bounded(denominator/gcd(denominator,a.weight.d,s)*a.weight.d,s);
  const values=stacks.map(a=>bounded(a.weight.n*(denominator/a.weight.d),s));let common=0n;
  for(const value of values)common=gcd(common,value,s);if(!common)fail('Positive stack mass is required','out-of-model');
  let total=0n;for(let i=0;i<stacks.length;i++){stacks[i].tickets=values[i]/common;total=bounded(total+stacks[i].tickets,s)}return total;
}
function quantize(bounds,D,scale,s){
  const positive=bounds.map((r,i)=>r.positive?i:-1).filter(i=>i>=0),count=positive.length;
  if(!count)fail('An original conditional root row has zero total mass','out-of-model');
  if(BigInt(count)>D)fail('Root denominator cannot preserve the positive support','shape-budget');
  let total=0n,totalLow=0n,totalHigh=0n;
  for(const row of bounds){s.charge();total=bounded(total+row.lower+row.upper,s);totalLow=bounded(totalLow+row.lower,s);totalHigh=bounded(totalHigh+row.upper,s)}
  if(!total)throw new Error('Positive exponential support lost');
  if(count===1){const tickets=Array(bounds.length).fill(0n);tickets[positive[0]]=D;return {tickets,tv:0n}}
  const remaining=D-BigInt(count),tickets=Array(bounds.length).fill(0n),remainders=[];let assigned=0n;
  for(const i of positive){
    const n=bounded(remaining*(bounds[i].lower+bounds[i].upper),s),amount=n/total;
    tickets[i]=amount+1n;assigned+=amount;remainders.push({i,remainder:n%total});
  }
  remainders.sort((a,b)=>{s.charge();return a.remainder>b.remainder?-1:a.remainder<b.remainder?1:a.i-b.i});
  const left=remaining-assigned;if(left<0n||left>=BigInt(count))throw new Error('Apportionment invariant');
  for(let i=0;i<Number(left);i++){s.charge();tickets[remainders[i].i]++}
  // Outward dyadic normalized bounds, then L1/2; counts and bound arithmetic are exact.
  let distance=0n;
  for(let i=0;i<bounds.length;i++){
    s.charge();const row=bounds[i],low=bounded(row.lower*scale,s)/totalHigh;
    let high=!row.positive?0n:totalLow?up(bounded(row.upper*scale,s),totalLow):scale;if(high>scale)high=scale;
    const q=bounded(tickets[i]*scale,s),a=abs(q-bounded(low*D,s)),b=abs(q-bounded(high*D,s));distance=bounded(distance+(a>b?a:b),s);
  }
  let tv=up(distance,2n*D);if(tv>scale)tv=scale;return {tickets,tv};
}
function compile(model,s){
  const {pitches}=model,m=s.math,stacks=[],states=[];let legal=0;
  for(let si=0;si<model.steps.length;si++)for(let zi=0;zi<model.sizes.length;zi++){
    s.charge();const step=model.steps[si].step,size=model.sizes[zi].size;if((size-1)*step>=pitches.length)continue;legal++;
    const weight=m.mul(model.steps[si].weight,model.sizes[zi].weight);if(!weight.n)continue;
    if(stacks.length>=s.limits.maxStacks)fail('Legal positive stack allowance','shape-budget');
    stacks.push({id:`step${si}:size${zi}`,step,size,weight,roots:[]});
  }
  if(!legal){
    if(s.limits.maxStacks<1)fail('Deterministic fallback exceeds the stack allowance','shape-budget');
    stacks.push({id:'deterministic-no-legal-stack',step:1,size:1,weight:ONE,roots:[],fallback:true});
  }
  if(!stacks.length)fail('Original stack weights have zero mass','out-of-model');
  const stackTotal=stackIntegers(stacks,s);
  for(let a=0;a<stacks.length;a++){
    const stack=stacks[a],last=stack.fallback?0:pitches.length-1-(stack.size-1)*stack.step;
    for(let root=0;root<=last;root++){
      s.charge();if(states.length>=s.limits.maxStates)fail('Latent stack/root state allowance','shape-budget');
      const indices=Array.from({length:stack.size},(_,k)=>root+k*stack.step),chord=indices.map(i=>pitches[i]);s.charge(indices.length);
      const state={id:`a${a}:r${root}`,stack:a,root,indices,chord,key:chordKey(chord)};stack.roots.push(states.length);states.push(state);
    }
  }
  const N=states.length+1;if((model.horizon+1)*N>s.limits.maxMessages)fail('Complete backward-table allowance','shape-budget');
  const masks=Array.from({length:model.horizon+1},()=>Array(N).fill(true));s.charge((model.horizon+1)*N);
  for(const c of model.constraints)for(let i=0;i<states.length;i++){s.charge();masks[c.at][i]=c.keys.has(states[i].key)}
  const exponentials=[],scale=1n<<BigInt(model.expPrecisionBits),D=1n<<BigInt(model.rootTicketBits);
  for(let distance=0;distance<pitches.length;distance++){
    const x=m.div(exactOf(distance),model.reach);exponentials.push(expNegativeDyadic(x,{precisionBits:model.expPrecisionBits,terms:model.expTerms,charge:s.charge}));
  }
  const motion=motionCompiler(model,s,scale);
  const kernels=[],byKernel=new Map,selectors=[],kernelEntries={count:0};
  function same(a,b){
    s.charge();if(a.length!==b.length)return false;
    for(let i=0;i<a.length;i++)if(m.compare(magnitude(m.sub(a[i],b[i])),model.repeatTolerance)>=0)return false;return true;
  }
  const predecessors=[...states.map(state=>state.chord),model.previous];
  for(const previous of predecessors){
    s.charge();const isNull=!previous?.length;let anchor=0,lowest=null;
    if(!isNull){
      lowest=previous[0];for(const q of previous)if(m.compare(q,lowest)<0)lowest=q;
      let distance=magnitude(m.sub(pitches[0],lowest));
      for(let i=1;i<pitches.length;i++){const candidate=magnitude(m.sub(pitches[i],lowest));if(m.compare(candidate,distance)<0){anchor=i;distance=candidate}}
    }
    const chosen=[];
    for(let a=0;a<stacks.length;a++){
      const stack=stacks[a],matches=[];
      for(let r=0;r<stack.roots.length;r++){s.charge();if(!isNull&&!stack.fallback&&same(states[stack.roots[r]].chord,previous))matches.push(r)}
      const key=`${stack.fallback?'fallback':isNull?'null':anchor}:${a}:${matches.join(',')}`+
        (motion&&!isNull&&!stack.fallback?`|motion:${motion.phase(lowest)}`:'');
      if(byKernel.has(key)){chosen.push(byKernel.get(key));continue}
      if(kernels.length>=s.limits.maxKernels||stack.roots.length>s.limits.maxKernelEntries-kernelEntries.count)fail('Shared root kernel allowance','shape-budget');
      kernelEntries.count+=stack.roots.length;const matchSet=new Set(matches),bounds=[];
      for(let r=0;r<stack.roots.length;r++){
        s.charge();const base=isNull||stack.fallback?{lower:scale,upper:scale}:exponentials[Math.abs(r-anchor)],matched=matchSet.has(r);
        const factor=matched?model.repeat.n:model.repeat.d;
        const moved=motion&&!isNull&&!stack.fallback?motion.at(pitches[r],lowest):null;
        const lower=moved?bounded(base.lower*moved.lower,s)/scale:base.lower,upper=moved?up(bounded(base.upper*moved.upper,s),scale):base.upper;
        bounds.push({lower:bounded(lower*factor,s),upper:bounded(upper*factor,s),positive:!matched||model.repeat.n>0n});
      }
      const rounded=quantize(bounds,D,scale,s),index=kernels.length;byKernel.set(key,index);chosen.push(index);
      kernels.push({key,stack:a,anchor:isNull?null:anchor,repeatRoots:matches,entries:stack.roots.map((to,r)=>({to,tickets:rounded.tickets[r]})),tv:rounded.tv});
    }
    selectors.push(chosen);
  }
  // A common divisor reduces entropy/storage without changing any declared row probability.
  let common=0n;for(const kernel of kernels)for(const e of kernel.entries)common=gcd(common,e.tickets,s);
  if(!common||D%common)throw new Error('Common root denominator invariant');
  for(const kernel of kernels)for(const e of kernel.entries){s.charge();e.tickets/=common}
  const rootTotal=D/common,C=bounded(stackTotal*rootTotal,s);let epsilon=0n;
  for(const row of selectors){let weighted=0n;for(let a=0;a<stacks.length;a++)weighted=bounded(weighted+stacks[a].tickets*kernels[row[a]].tv,s);
    const value=up(weighted,stackTotal);if(value>epsilon)epsilon=value}
  const description=deepFreeze({states:states.map(v=>({id:v.id,stack:v.stack,root:v.root,pitches:v.chord.map(exactText),indices:v.indices})),
    initialState:states.length,stacks:stacks.map(a=>({id:a.id,step:a.step,size:a.size,tickets:String(a.tickets),fallback:a.fallback??false})),
    stackTotal:String(stackTotal),requestedRootTotal:String(D),rootTotal:String(rootTotal),rootDivisor:String(common),stepTotal:String(C),
    kernels:kernels.map(k=>({key:k.key,stack:k.stack,anchor:k.anchor,repeatRoots:k.repeatRoots,
      entries:k.entries.map(e=>({to:e.to,tickets:String(e.tickets)})),tvUpper:exactText(derived(k.tv,scale))})),selectors,
    exponentialBounds:exponentials.map((e,distance)=>({distance,lower:String(e.lower),upper:String(e.upper),scale:String(e.scale),squarings:e.squarings,method:e.method})),
    masks,oneStepTVUpper:exactText(derived(epsilon,scale)),...(motion?{motionInterval:motion.interval,
      motionBounds:[...motion.cache.values()].map(b=>({delta:b.delta,distance:b.distance,lower:String(b.lower),upper:String(b.upper),scale:String(b.scale)}))}:{})});
  const kernelHash=hash(description,s);
  return {...model,states,stacks,kernels,selectors,masks,initial:states.length,N,C,epsilon,scale,kernelEntries:kernelEntries.count,description,kernelHash};
}
function preflight(model,s){
  s.modelHash=hash(model.definition,s);
  if(s.limits.maxTicketBits<1)fail('At least one ticket bit is required','arithmetic-budget');
  if(model.pitches.length>s.limits.maxPitches||model.stacks.length>s.limits.maxStacks||model.states.length>s.limits.maxStates||
    model.kernels.length>s.limits.maxKernels||model.kernelEntries>s.limits.maxKernelEntries||model.horizon>s.limits.maxHorizon||
    (model.horizon+1)*model.N>s.limits.maxMessages||model.definition.dependencies.length>s.limits.maxDependencies)
    fail('Prepared bridge exceeds current shape allowances','shape-budget');
}
function modelOf(prepared){const model=models.get(prepared);if(!model)fail('An authentic prepared harmony model is required');return model}
function result(s,status,reason,extra={}){return freeze({status,reason,scope,modelHash:s?.modelHash??null,workUsed:s?.used??0,resourceLimits:s?.limits??null,...extra})}
function run(options,body){let s;try{s=stateOf(options);return body(s)}catch(e){
  return result(s,e instanceof BadCertificate?'FAIL':'UNKNOWN',e.message??'Harmony bridge refused',
    {kind:e instanceof Refused?e.kind:e instanceof BadCertificate?'invalid-certificate':'internal-error',conclusion:null})}}

/** Snapshots exact authored parameters and constructs shared certified rational conditional root kernels. */
export function prepareHarmonyBridge(spec,options={}){
  return run(options,s=>{const model=compile(normalize(spec,s),s),prepared=freeze({kind:'prepared-harmony-bridge-v1',modelHash:s.modelHash,
    definition:model.definition,description:model.description,kernelHash:model.kernelHash});
    models.set(prepared,model);return result(s,'PASS','Declared rational prior prepared; this is not a conditioned-path verdict',{prepared})});
}

function kernelMasses(model,next,step,s){
  const out=[];
  for(const kernel of model.kernels){
    let total=0n;for(const e of kernel.entries){s.charge();if(model.masks[step][e.to]&&e.tickets)
      total=ticket(total+ticket(e.tickets*next[e.to],s),s)}out.push(total);
  }return out;
}
function stateMasses(model,kernels,s){
  const out=[];for(const row of model.selectors){let total=0n;
    for(let a=0;a<model.stacks.length;a++){s.charge();total=ticket(total+ticket(model.stacks[a].tickets*kernels[row[a]],s),s)}out.push(total);
  }return out;
}
function reportOf(model,layers,s){
  const root=layers[0][model.initial],supported=root>0n;let denominator=1n;
  if(supported)for(let i=0;i<model.horizon;i++)denominator=bounded(denominator*model.C,s);
  const mass=supported?derived(root,denominator):ZERO;
  let pathError=model.epsilon*BigInt(model.horizon);if(pathError>model.scale)pathError=model.scale;
  const delta=derived(pathError,model.scale);let conditional=null;
  if(supported){const quotient=s.math.div(delta,mass);conditional=s.math.compare(quotient,ONE)>0?ONE:quotient}
  const within=model.maxConditionalTV===null||supported&&s.math.compare(conditional,model.maxConditionalTV)<=0;
  return deepFreeze({status:!supported?'EMPTY':within?'CERTIFIED':'UNKNOWN',modelHash:s.modelHash,kernelHash:model.kernelHash,
    horizon:model.horizon,latentStates:model.states.length,stacks:model.stacks.length,kernels:model.kernels.length,
    kernelEntries:model.kernelEntries,messages:(model.horizon+1)*model.N,tickets:String(root),eventProbability:exactText(mass),
    stepTotal:String(model.C),sourceComparison:{reference:model.definition.reference,oneStepTVUpper:exactText(derived(model.epsilon,model.scale)),
      pathTVUpper:exactText(delta),conditionalTVUpper:conditional===null?null:exactText(conditional),
      maxConditionalTV:model.maxConditionalTV===null?null:exactText(model.maxConditionalTV),
      support:'Same positive latent paths; exact zeros are retained',
      scope:'Ideal real exponential on the declared exact parameters; no legacy binary64 or seeded-stream equivalence'}});
}

/** Complete backward recurrence, its law a sampler handle as it is solved: a path is drawn from the solver's own law
 * while the music is made; its certificate is checked in development (checkHarmonyBridge). */
export function solveHarmonyBridge(prepared,options={}){
  return run(options,s=>{
    const model=modelOf(prepared);preflight(model,s);const layers=Array(model.horizon+1);
    layers[model.horizon]=Array(model.N).fill(1n);s.charge(model.N);
    for(let t=model.horizon-1;t>=0;t--)layers[t]=stateMasses(model,kernelMasses(model,layers[t+1],t+1,s),s);
    const report=reportOf(model,layers,s),certificate=deepFreeze({kind:'harmony-bridge-v1',modelHash:s.modelHash,kernelHash:model.kernelHash,
      layers:layers.map(row=>row.map(String)),reportHash:hash(report,s)});
    hash(certificate,s,s.limits.maxCertificateChars);
    let plan=null;
    if(report.status==='CERTIFIED'){
      plan=freeze({kind:'solved-harmony-bridge-v1',modelHash:s.modelHash,kernelHash:model.kernelHash,horizon:model.horizon,
        tickets:report.tickets,eventProbability:report.eventProbability,conditionalTVUpper:report.sourceComparison.conditionalTVUpper});
      for(const row of layers)freeze(row);freeze(layers);plans.set(plan,freeze({model,layers,report}));
    }
    return result(s,report.status,report.status==='UNKNOWN'?'Declared rational law is exact, but the source-comparison bound exceeds the authored limit':
      report.status==='EMPTY'?'The declared finite conditioning event has no positive-prior path':'Exact declared conditional law and source comparison computed',{report,certificate,plan});
  });
}
function countOf(raw,s){
  text(raw,s,2500);const match=raw.match(/^(0|[1-9][0-9]*)$/);
  if(!match||match[0].length!==raw.length)fail('Canonical nonnegative ticket integer required');return ticket(BigInt(raw),s);
}

/** Checks every terminal and backward equation against the immutable original compiled prior. */
export function checkHarmonyBridge(prepared,raw,options={}){
  return run(options,s=>{
    const model=modelOf(prepared);preflight(model,s);fields(raw,['kind','modelHash','kernelHash','layers','reportHash'],s);
    for(const k of ['kind','modelHash','kernelHash','reportHash'])text(raw[k],s,64);
    requireCertificate(raw.kind==='harmony-bridge-v1'&&raw.modelHash===s.modelHash&&raw.kernelHash===model.kernelHash,'Wrong original model or kernel');
    list(raw.layers,model.horizon+1,s,'Certificate layers');requireCertificate(raw.layers.length===model.horizon+1,'Incomplete time layers');
    const layers=raw.layers.map(row=>{
      list(row,model.N,s,'Certificate state counts');requireCertificate(row.length===model.N,'Incomplete or extra state counts');return row.map(n=>countOf(n,s));
    });
    hash({kind:raw.kind,modelHash:raw.modelHash,kernelHash:raw.kernelHash,layers:layers.map(row=>row.map(String)),reportHash:raw.reportHash},s,s.limits.maxCertificateChars);
    for(const value of layers[model.horizon]){s.charge();requireCertificate(value===1n,'Terminal suffix must contain exactly the empty suffix')}
    for(let t=model.horizon-1;t>=0;t--){
      const expected=stateMasses(model,kernelMasses(model,layers[t+1],t+1,s),s);
      for(let i=0;i<model.N;i++){s.charge();requireCertificate(expected[i]===layers[t][i],'Backward mass recurrence does not match the complete prior')}
    }
    const report=reportOf(model,layers,s);requireCertificate(hash(report,s)===raw.reportHash,'Conditional law/source-comparison report differs');
    let plan=null;
    if(report.status==='CERTIFIED'){
      plan=freeze({kind:'checked-harmony-bridge-v1',modelHash:s.modelHash,kernelHash:model.kernelHash,horizon:model.horizon,
        tickets:report.tickets,eventProbability:report.eventProbability,conditionalTVUpper:report.sourceComparison.conditionalTVUpper});
      for(const row of layers)freeze(row);freeze(layers);plans.set(plan,freeze({model,layers,report}));
    }
    return result(s,'PASS','Every time/state equation and the original prior-bound report independently checked',{conclusion:report.status,report,plan});
  });
}
const selectionFailure=e=>freeze({status:'UNKNOWN',scope,reason:e.message??'Harmony selection refused',kind:e instanceof Refused?e.kind:'selection-error'});
function savedPlan(plan){const saved=plans.get(plan);if(!saved)fail('Only a genuine bridge plan, solved or checked, can be sampled','out-of-model');return saved}
function select(saved,rank){
  const {model,layers}=saved,total=layers[0][model.initial];
  if(typeof rank!=='bigint'||rank<0n||rank>=total)fail('Root rank outside the admitted bridge');
  const original=rank,path=[],stateIds=[],chords=[];let current=model.initial,pathTickets=1n;
  // The checked table bounds every nonnegative partial sum/product below an admitted row mass.
  // Work is at most H*(stacks*maxRoots + maxRoots) scans; no new search or random choice occurs here.
  for(let t=0;t<model.horizon;t++){
    const masses=[],selected=model.selectors[current];
    for(let a=0;a<model.stacks.length;a++){
      let mass=0n;for(const e of model.kernels[selected[a]].entries)if(model.masks[t+1][e.to])mass+=e.tickets*layers[t+1][e.to];masses.push(mass);
    }
    let chosen=-1;
    for(let a=0;a<model.stacks.length;a++){
      const mass=model.stacks[a].tickets*masses[a];if(rank<mass){chosen=a;rank%=masses[a];break}rank-=mass;
    }
    if(chosen<0)throw new Error('Checked stack decode invariant');
    let picked=null;
    for(const e of model.kernels[selected[chosen]].entries){
      if(!model.masks[t+1][e.to])continue;const mass=e.tickets*layers[t+1][e.to];
      if(rank<mass){picked=e;rank%=layers[t+1][e.to];break}rank-=mass;
    }
    if(!picked)throw new Error('Checked root decode invariant');
    pathTickets*=model.stacks[chosen].tickets*picked.tickets;current=picked.to;const state=model.states[current];
    path.push(freeze({stackId:model.stacks[chosen].id,root:state.root,stateId:state.id}));stateIds.push(state.id);chords.push(freeze(state.chord.map(exactText)));
  }
  return freeze({status:'SELECTED',scope,modelHash:saved.report.modelHash,rank:String(original),
    path:freeze({decisions:freeze(path),states:freeze(stateIds),chords:freeze(chords),
      latentPathProbability:exactText(derived(pathTickets,total)),coordinateUnit:model.definition.coordinateUnit})});
}

/** Deterministic global-rank decoding; duplicate audible paths can have several latent stack labels. */
export function unrankHarmonyBridge(plan,rank){try{return select(savedPlan(plan),rank)}catch(e){return selectionFailure(e)}}

/** One whole-path lottery, then bounded deterministic decoding. Independent uniform uint32 words are a premise. */
export function sampleHarmonyBridge(plan,nextWord,options={}){
  try{
    const saved=savedPlan(plan);
    if(!dataRecord(options)||Object.keys(options).some(k=>!['maxAttempts','maxWords'].includes(k))||typeof nextWord!=='function')fail('Explicit word source and supported entropy options required');
    const maxAttempts=Object.hasOwn(options,'maxAttempts')?natural(options.maxAttempts,1024,'draw attempts'):64;
    const maxWords=Object.hasOwn(options,'maxWords')?natural(options.maxWords,262144,'word allowance'):16384;
    if(!maxAttempts)fail('At least one allowed rank attempt required');
    const total=saved.layers[0][saved.model.initial];if(total===1n)return freeze({...select(saved,0n),wordsUsed:0});
    const bits=bitsOf(total-1n),perAttempt=Math.ceil(bits/32),mask=(1n<<BigInt(bits))-1n;let words=0;
    for(let attempt=0;attempt<maxAttempts&&perAttempt<=maxWords-words;attempt++){
      let rank=0n;for(let j=0;j<perAttempt;j++){
        const word=nextWord();if(!Number.isSafeInteger(word)||word<0||word>0xffffffff)fail('Uniform uint32 words required');
        words++;rank=(rank<<32n)|BigInt(word);
      }
      rank&=mask;if(rank<total)return freeze({...select(saved,rank),wordsUsed:words});
    }
    return freeze({status:'UNKNOWN',scope,modelHash:plan.modelHash,kind:'random-word-budget',reason:'No whole-path rank accepted within the entropy allowance',wordsUsed:words});
  }catch(e){return selectionFailure(e)}
}
