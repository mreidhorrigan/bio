// A fugue's stretto checked with all its entries together (Astra's tracker, CF15: "Precompute stretto compatibility,
// then check combinations jointly"): its subject's entries, each as the stretto's form makes it -- the subject, the
// answer by the collection's degrees, its inversion, its augmentation (fugue-plan.js) -- each a spacing after the one
// before. A fugue's subject is planned to sound against one later entry of itself, as its stretto's form has it
// (fugue-plan.js plannedSubject: the next entry half a subject later); its stretto has as many entries as voices,
// checked together here.
//
// Each spacing is checked first between two entries (its pairwise compatibility, precomputed for every spacing); those
// that pass are checked again with all the stretto's entries sounding together, jointly: the realized entries' events
// audited by Astra's compiled counterpoint profile (counterpoint-profile.js), the one the fugue's rules make
// (fugue-cadence.js's: one note at a time a voice; no parallels in the intervals the rules count perfect, banded by
// their weight on them, between every two entries that sound together) -- a spacing every pair keeps may fail with
// three entries at once. The planned spacing is kept where it passes jointly; a closer one only where its texture is
// also no costlier, note for heard note (counterpoint.js lineCost, every line against all the others), than the
// planned one's; else the closest wider one that passes and fits the room the stretto has; else none (the subject then
// returns once). Where the stretto has more entries than the profile is read for, or a pitch its exact space cannot
// read, the planned spacing, unverified, said.
import {compileCounterpointProfile} from './counterpoint-profile.js';
import {createPitchSpace,pitchFromNumber} from './pitch-spaces.js';
import {Q,exactSpan} from './canon-core.js';
import {exactOfNumber,EXACT_LIMITS} from '../bounded-exact.js';
import {lineCost,COUNTERPOINT} from './counterpoint.js';
import {selectElasticCandidates} from './elastic-selection.js';

const SPACE=createPitchSpace({id:'musebots-semitones',kind:'semitones'});
const exact=value=>Q(exactOfNumber(+Number(value).toFixed(6)));
const pitchOf=value=>pitchFromNumber(SPACE,+Number(value).toFixed(6)).pitch;
const modulo=(x,n)=>((x%n)+n)%n;
// Ours: the most entries its profile is read for (its voices' identities and each pair's rule).
export const STRETTO=Object.freeze({entries:32});

// `entryOf(k)` the stretto's k-th entry as its form makes it ([{pitch, start, length}], quarters from its own start);
// `count` its entries; `rules` the rules where it sounds (counterpoint.js blendRules); `strong` (quarters -> boolean) its
// strong beats; `spacings` the spacings it may take (quarters, a finite authored set: its meter's felt beats); `planned`
// the spacing its subject was planned for; `widest` the widest its room holds; `budget` {maxWork} each audit's. ->
// {spacing (null: none), pairwise: [{spacing, status}], joint: [{spacing, status}], chosen ('planned', 'closer',
// 'wider', 'none' or 'unverified'), reason}.
export function strettoPlan({entryOf,count,rules,strong=()=>false,spacings,planned,widest=planned,period=12,budget={maxWork:EXACT_LIMITS.maxWork}}){
  const fallback=reason=>({spacing:planned,pairwise:[],joint:[],chosen:'unverified',reason});
  if(count<2)return fallback('one entry');
  if(count>STRETTO.entries)return fallback(`${count} entries, more than its profile is read for (${STRETTO.entries})`);
  const lines=Array.from({length:count},(_,k)=>entryOf(k));
  const lengthOf=line=>Math.max(...line.map(note=>note.start+note.length));
  // (Its contract the fugue's rules, as the cadence's is: parallels in the intervals they count perfect, where they
  // weigh any, between the entries that sound together.)
  const periodCents=Math.round(period*100),cents=x=>Number.isInteger(x)?x:`${Math.round(x*1000)}/1000`;
  const weight=Math.max(0,Math.min(1,Number(rules.parallelPerfect)||0)),tolerance=cents(+(COUNTERPOINT.consonance.width*weight).toFixed(3));
  const perfect=[...new Set(COUNTERPOINT.consonance.perfect.map(c=>+modulo(c,periodCents).toFixed(3)))].map(cents);
  const clockDomain={id:'section-quarters',unit:'quarters',revision:1};
  const check=(n,spacing)=>{
    const ids=Array.from({length:n},(_,k)=>`e${k}`),pairs=[];
    for(let i=0;i<n;i++)for(let j=i+1;j<n;j++)if(j*spacing<i*spacing+lengthOf(lines[i])-1e-9)pairs.push([ids[i],ids[j]]);
    const placed=lines.slice(0,n).map((line,k)=>line.map(note=>({...note,start:note.start+k*spacing})));
    let profile;try{profile=compileCounterpointProfile({id:'stretto',version:1,pitchSpace:SPACE,clockDomain,voices:ids,rules:[{id:'monophony',type:'monophony',required:true},
      ...(weight>0&&pairs.length?[{id:'parallels',type:'parallel-classes',required:true,pair:pairs,periodCents,classes:perfect.map((center,k)=>({id:`perfect${k}`,center,tolerance}))}]:[])]})}
    catch(error){return {status:'UNKNOWN',reason:String(error?.message??error),placed}}
    const events=placed.flatMap((line,k)=>line.map((note,i)=>({id:`e${k}n${i}`,voiceId:ids[k],clockDomain,...exactSpan(exact,note.start,note.length),pitch:pitchOf(note.pitch)})));
    let audit;try{audit=profile.audit(events,{maxWork:budget.maxWork,maxPredicateWork:budget.maxWork})}catch(error){return {status:'UNKNOWN',reason:String(error?.message??error),placed}}
    return {status:audit.status==='PASS'?'SAT':audit.status==='FAIL'?'UNSAT':'UNKNOWN',placed};
  };
  // (Its texture's counterpoint per note heard against another: a closer stretto has more notes sounding together, each
  // judged as a note of the planned one is.)
  const textureCost=placed=>{let heard=0;
    const total=placed.reduce((sum,line,k)=>{const others=placed.filter((_,j)=>j!==k);
      heard+=line.filter(note=>others.some(other=>other.some(o=>o.start<=note.start+1e-9&&o.start+o.length>note.start+1e-9))).length;
      return sum+lineCost({line,against:others,rules,strong})},0);
    return total/Math.max(1,heard)};
  // (Pairwise, then jointly: a spacing's first two entries, then all of them -- each spacing once.)
  const pairwise=[],joint=[],judged=new Map;
  const holds=spacing=>{
    if(judged.has(spacing))return judged.get(spacing);
    const pair=check(2,spacing);pairwise.push({spacing,status:pair.status});
    const all=pair.status==='SAT'?check(count,spacing):null;if(all)joint.push({spacing,status:all.status});
    const out={status:!all?(pair.status==='UNSAT'?'FAIL':'UNKNOWN'):all.status==='SAT'?'PASS':all.status==='UNSAT'?'FAIL':'UNKNOWN',placed:all?.placed??null};
    judged.set(spacing,out);return out;
  };
  // (Its choice most-protected-first (Astra's EC08/EC10, CFM-006 elastic-selection.js selectElasticCandidates), over the
  // complete domain of spacings its room holds, each admitted only where its entries hold their counterpoint together
  // (its named hard contract, above): where the planned spacing holds, of it and the closer ones, those whose texture is
  // no costlier than the planned one's, then the closest; else, of the wider ones, the closest.)
  const planning=holds(planned),closer=planning.status==='PASS';
  const domain=[...new Set(spacings)].filter(s=>s>0&&(closer?s<planned-1e-9:s>planned+1e-9&&s<=widest+1e-9)).sort((a,b)=>a-b);
  if(closer)domain.push(planned);
  for(const spacing of domain)holds(spacing);
  const costOf=spacing=>{const placed=judged.get(spacing)?.placed;return placed?textureCost(placed):null};
  const allowance=closer?costOf(planned):null,passing=domain.filter(spacing=>judged.get(spacing).status==='PASS');
  const exactText=x=>Q(exactOfNumber(+Number(x).toFixed(9))).toString();
  // (The texture's band: the planned spacing's cost over the least, each as its candidate's cost is written.)
  const least=closer?passing.map(costOf).reduce((a,b)=>Math.min(a,b),Infinity):null,over=closer?Q(exactText(allowance)).sub(Q(exactText(least))):null;
  const textureBand=closer?(over.cmp(0)<0?'0':over.toString()):null;
  let selected;try{selected=selectElasticCandidates({id:'stretto-spacing',revision:1,domainComplete:true,
    hard:{id:'stretto-joint-profile',version:1,check:candidate=>judged.get(candidate.data.spacing)?.status??'UNKNOWN'},
    tiers:[...(closer?[{id:'texture',band:textureBand,terms:[{metric:'texture',unit:'cost-per-heard-note',normalizer:'1',weight:'1'}]}]:[]),
      {id:'closeness',band:'0',terms:[{metric:'spacing',unit:'quarters',normalizer:'1',weight:'1'}]}],
    candidates:domain.map(spacing=>{const cost=costOf(spacing);return {id:`spacing:${spacing}`,complete:true,data:{spacing},
      costs:{...(closer?{texture:cost==null?null:exactText(cost)}:{}),spacing:exactText(spacing)}}}),
    dependencies:{count,planned,widest}})}
  catch(error){selected=null}
  const ids=selected?.selectionStatus==='CERTIFIED'?selected.alternatives:selected?.provisionalAlternatives??[];
  const spacing=ids.length?domain.find(s=>`spacing:${s}`===ids[0]):null,selection=selected?{status:selected.selectionStatus,frontier:selected.frontier?.ids?.length??0}:null;
  if(spacing!=null&&closer&&spacing<planned-1e-9)return {spacing,pairwise,joint,chosen:'closer',reason:'closer than planned, its counterpoint no costlier',selection};
  if(spacing!=null&&closer)return {spacing:planned,pairwise,joint,chosen:'planned',reason:'as planned, its entries checked together',selection};
  if(spacing!=null)return {spacing,pairwise,joint,chosen:'wider',reason:'the planned spacing failed with all its entries together: the closest wider one that holds',selection};
  return {spacing:null,pairwise,joint,chosen:'none',reason:'no spacing its room holds kept its counterpoint with all its entries together',...(selection?{selection}:{})};
}
