// Constraints that flow down a hierarchy of conductors (Musebots 3.0, docs/MUSEBOTS_3.md; the owner, 30 September 2026:
// "constraints determined at a top level of conductor can flow downward through the layers of subconductors as bots
// handle and decide for any parameters not specified from above").
//
// A constraint binds one parameter of a group's decisions: a value (the choice made above), a list (choose among
// these), or a range (a number within [low, high]). Whatever it leaves open is the group's own to choose. A vocabulary
// says which parameters a group has and what each may be, a list of values or a range:
//   {texture: {values: ['line', 'chord', ...]}, split: {low: 0, high: 1}}
// (so a list of numbers, [7, 11], and a range, [7, 11], are told apart by the vocabulary, never by their look).
// Constraints compose downward by intersection (narrowConstraints): a conductor may narrow what it passes on, never
// widen it. Where a level below asks for what a level above has ruled out, the level above wins and the conflict is
// said. Choices are made within the constraints directly (chooseWithin), never drawn and then checked.
const fail=message=>{throw new RangeError(message)};
const numeric=value=>typeof value==='number'&&Number.isFinite(value);
const listed=entry=>Array.isArray(entry?.values);

// One parameter's constraint checked against its vocabulary entry: a list -> a frozen array of allowed values; a number
// or [low, high] -> a frozen [low, high] within the entry's own bounds.
export function checkedConstraint(key,value,entry){
  if(!entry)fail(`A constraint binds one of this group's parameters, and ${key} is not one`);
  if(listed(entry)){
    const items=Array.isArray(value)?value:[value];
    if(!items.length||items.some(item=>!entry.values.includes(item)))fail(`A constraint's ${key} is one or more of ${entry.values.join(', ')}`);
    return Object.freeze([...new Set(items)]);
  }
  const low0=entry.low??-Infinity,high0=entry.high??Infinity,[low,high]=Array.isArray(value)?value:[value,value];
  if(!(numeric(low)&&numeric(high)&&low>=low0&&high<=high0&&low<=high))
    fail(`A constraint's ${key} is a number or a range within ${low0} and ${high0}`);
  return Object.freeze([low,high]);
}
// Every parameter of `value` checked (checkedConstraint); those absent (or null) are open. -> a frozen object.
export function checkedConstraints(value={},vocabulary={}){
  if(!value||typeof value!=='object'||Array.isArray(value))fail('Constraints are an object of parameters');
  const out={};
  for(const [key,item] of Object.entries(value))if(item!=null)out[key]=checkedConstraint(key,item,vocabulary[key]);
  return Object.freeze(out);
}
// Whether a value honours a checked constraint (an open parameter is honoured by anything).
export function honours(value,constraint,entry){
  if(constraint==null)return true;
  return listed(entry)?constraint.includes(value):numeric(value)&&value>=constraint[0]-1e-9&&value<=constraint[1]+1e-9;
}
// What a level below may choose from: `outer` narrowed by `inner` where both bind a parameter (the lists' common values,
// the ranges' overlap), and each one's own elsewhere. Where the two have nothing in common, the outer's stands and the
// conflict is kept. Both checked against `vocabulary`. -> {constraints, conflicts: [{key, outer, inner}]}
export function narrowConstraints(outer={},inner={},vocabulary={}){
  const constraints={...outer},conflicts=[];
  for(const [key,value] of Object.entries(inner)){
    const above=outer[key];
    if(above==null){constraints[key]=value;continue}
    let narrowed=null;
    if(listed(vocabulary[key])){const common=value.filter(item=>above.includes(item));if(common.length)narrowed=Object.freeze(common)}
    else if(Math.max(above[0],value[0])<=Math.min(above[1],value[1]))narrowed=Object.freeze([Math.max(above[0],value[0]),Math.min(above[1],value[1])]);
    if(narrowed)constraints[key]=narrowed;else conflicts.push({key,outer:above,inner:value});
  }
  return {constraints:Object.freeze(constraints),conflicts};
}
// A choice within a parameter's constraint, feasible by construction. A list: `preferred` where it is allowed, else a
// value drawn among those allowed by `weights` (value -> weight; unlisted weigh 1). A range: `preferred` held within it,
// else a point drawn in it. An open parameter: `preferred`, else a draw from the whole vocabulary entry. random: [0, 1).
export function chooseWithin(constraint,entry,{random=Math.random,preferred=null,weights=null}={}){
  if(!entry)fail('A choice needs its vocabulary entry');
  if(!listed(entry)){
    const [low,high]=constraint??[entry.low,entry.high];
    if(numeric(preferred))return Math.max(low,Math.min(high,preferred));
    if(!(numeric(low)&&numeric(high)))fail('An open range needs a preference or bounds');
    return low+(high-low)*random();
  }
  if(constraint==null&&preferred!=null)return preferred;
  const values=constraint??entry.values;
  if(preferred!=null&&values.includes(preferred))return preferred;
  const weighed=values.map(value=>Math.max(0,Number(weights?.[value]??1))),total=weighed.reduce((a,b)=>a+b,0);
  if(!(total>0))return values[Math.floor(random()*values.length)];
  let r=random()*total;for(let i=0;i<values.length;i++){r-=weighed[i];if(r<0)return values[i]}
  return values.at(-1);
}
