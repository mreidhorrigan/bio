// CFM038 / CF08: conditional development probes and conservative multiobjective records.
// Mathematical coverage intervals are not recognition/preference probabilities. No subject is installed or rewritten.
import {prepareDispositionFamily,auditDispositionFamily,checkDispositionFamily} from './counterpoint-dispositions.js';
import {dataArray,dataRecord} from './contract-data.js';
import {Refused,EXACT_LIMITS,ZERO,ONE,add,sub,div,compare,exactOf,exactText,pythonJson,sha256} from '../bounded-exact.js';

export const DEVELOPMENT_AFFORDANCE_LIMITS=Object.freeze({maxSubjects:32,maxConditions:32,maxDimensions:16,maxProbes:128,maxProbeAudits:128,
  maxFamilyWork:500000,maxProfileWork:2000000,maxSliceWork:500000,maxWork:20000000,maxDataNodes:1048576,maxTextChars:16777216,maxCertificateChars:8388608});
const freeze=Object.freeze,models=new WeakMap,scope='declared-finite-development-probes-and-interval-pareto-report';
const fail=(message,kind='invalid-input')=>{throw new Refused(message,{kind})};
class BadCertificate extends Error {}
const demand=(condition,message)=>{if(!condition)throw new BadCertificate(message)};
function stateOf(options){
  if(!dataRecord(options)||Object.keys(options).some(k=>!Object.hasOwn(DEVELOPMENT_AFFORDANCE_LIMITS,k)))fail('Unknown affordance options');
  const defaults={maxWork:2000000,maxFamilyWork:100000,maxProfileWork:20000,maxSliceWork:10000},limits={};
  for(const [k,cap] of Object.entries(DEVELOPMENT_AFFORDANCE_LIMITS)){const n=Object.hasOwn(options,k)?options[k]:defaults[k]??cap;
    if(!Number.isSafeInteger(n)||n<0||n>cap)fail('Bounded nonnegative integer allowances required');limits[k]=n}
  const s={limits:freeze(limits),used:0,nodes:0,chars:0,calls:0,modelHash:null};
  s.charge=(n=1)=>{if(!Number.isSafeInteger(n)||n<0)throw new Error('Invalid work charge');if(n>limits.maxWork-s.used)fail('Affordance work allowance exhausted','work-budget');s.used+=n};
  s.visit=(n=1)=>{s.charge(n);if(n>limits.maxDataNodes-s.nodes)fail('Affordance data/output allowance','shape-budget');s.nodes+=n};
  s.m={};for(const [k,fn] of Object.entries({add,sub,div,cmp:compare}))s.m[k]=(a,b)=>{s.charge();return fn(a,b)};s.charge();return s;
}
function fields(v,keys,s){s.visit(keys.length+1);if(!dataRecord(v)||Object.keys(v).length!==keys.length||keys.some(k=>!Object.hasOwn(v,k)))fail('Missing or unsupported affordance fields');return v}
function list(v,cap,s,label){if(!Array.isArray(v)||v.length>cap)fail(label+' allowance','shape-budget');s.visit(v.length+1);return dataArray(v,cap,label)}
function text(v,s,cap=256){if(typeof v!=='string'||!v.length||v.length>cap)fail('Bounded nonempty text required');if(v.length>s.limits.maxTextChars-s.chars)fail('Affordance text allowance','work-budget');s.chars+=v.length;s.charge(1+Math.ceil(v.length/64));return v}
function rev(v){if(!Number.isSafeInteger(v)||v<0)fail('Nonnegative safe revision required');return v}
function unique(seen,id){if(seen.has(id))fail('Duplicate affordance identity');seen.add(id);return id}
function sorted(a,s,key=x=>x){return a.sort((a,b)=>{s.charge();const x=key(a),y=key(b);return x<y?-1:x>y?1:0})}
function ids(raw,cap,s,sort=true){const seen=new Set,out=list(raw,cap,s,'Identity list').map(id=>unique(seen,text(id,s)));return freeze(sort?sorted(out,s):out)}
function digest(v,s){text(v,s,64);if(!/^[a-f0-9]{64}$/.test(v))fail('Lowercase SHA-256 reference required');return v}
function ref(v,s){fields(v,['id','revision','hash'],s);return freeze({id:text(v.id,s),revision:rev(v.revision),hash:digest(v.hash,s)})}
function rational(v,s){
  s.charge();let n,d=1n;const bound=1n<<BigInt(EXACT_LIMITS.inputBits),integer=x=>{const q=typeof x==='bigint'?x:Number.isSafeInteger(x)?BigInt(x):null;if(q===null||q<=-bound||q>=bound)fail('Raw rational component allowance','arithmetic-budget');return q};
  if(typeof v==='string'){text(v,s,160);const m=v.match(/^([+-]?[0-9]+)(?:\/([+-]?[0-9]+))?$/);if(!m||m[0].length!==v.length)fail('Use exact integer or fraction text');n=integer(BigInt(m[1]));d=integer(BigInt(m[2]??'1'))}
  else if(v&&typeof v==='object'){fields(v,['n','d'],s);n=integer(v.n);d=integer(v.d)}else n=integer(v);
  if(!d)fail('Zero denominator');return exactOf({n,d});
}
function encode(v,s,cap=s.limits.maxTextChars){const out=pythonJson(v);if(out.length>cap)fail('Canonical affordance text allowance','work-budget');s.charge(1+Math.ceil(out.length/64));return out}
function wire(v,s){s.visit();if(typeof v==='string')return text(v,s,6000);if(v&&typeof v==='object'){
  if(typeof v.n==='bigint'&&typeof v.d==='bigint')return text(exactText(v),s,6000);if(Array.isArray(v))return freeze(v.map(x=>wire(x,s)));
  return freeze(Object.fromEntries(Object.entries(v).map(([k,x])=>[text(k,s),wire(x,s)])));}return v}
function snapshot(v,s,depth=0,seen=new Set){
  s.visit();if(v===null||typeof v==='boolean')return v;if(typeof v==='string')return text(v,s,6000);if(typeof v==='number'&&Number.isFinite(v))return Object.is(v,-0)?0:v;
  if(!v||typeof v!=='object'||depth>=32||seen.has(v))fail('Bounded acyclic ordinary data required');seen.add(v);let out;
  if(Array.isArray(v)){list(v,s.limits.maxDataNodes,s,'Ordinary array');out=v.map(x=>snapshot(x,s,depth+1,seen))}
  else{if(!dataRecord(v)||Object.keys(v).length>256)fail('Ordinary data record required');out=Object.fromEntries(Object.entries(v).map(([k,x])=>[text(k,s),snapshot(x,s,depth+1,seen)]))}
  seen.delete(v);return freeze(out);
}
function familyCall(prepared,mode,raw,s){
  const allowance=Math.min(s.limits.maxFamilyWork,s.limits.maxWork-s.used);if(!allowance)fail('No original-family allowance remains','work-budget');
  if(mode!=='prepare'){if(s.calls>=s.limits.maxProbeAudits)fail('Probe-check allowance exhausted','work-budget');s.calls++}
  const options={maxWork:allowance,maxProfileWork:s.limits.maxProfileWork,maxSliceWork:s.limits.maxSliceWork};let out;
  if(mode==='prepare')out=prepareDispositionFamily(raw,{maxWork:allowance});else if(mode==='audit')out=auditDispositionFamily(prepared,options);else out=checkDispositionFamily(prepared,raw,options);
  s.charge(Number.isSafeInteger(out.workUsed)?out.workUsed:allowance);return out;
}
function normalize(raw,s){
  fields(raw,['id','revision','contextHash','design','dimensions','conditions','subjects','probes','probeOrder'],s);
  const dimensions=[],dimensionById=new Map;
  for(const row of list(raw.dimensions,s.limits.maxDimensions,s,'Dimensions')){
    fields(row,['id','kind','unit','goal'],s);const d=freeze({id:text(row.id,s),kind:row.kind,unit:text(row.unit,s),goal:row.goal});
    if(dimensionById.has(d.id)||!['probe','declared'].includes(d.kind)||!['maximize','minimize'].includes(d.goal))fail('Unique typed dimensions with explicit goals required');
    if(d.kind==='probe'&&(d.goal!=='maximize'||d.unit!=='weighted-fraction'))fail('Probe dimensions maximize explicit weighted fractions');dimensions.push(d);dimensionById.set(d.id,d);
  }sorted(dimensions,s,d=>d.id);if(!dimensions.some(d=>d.kind==='probe')||!dimensions.some(d=>d.kind==='declared'))fail('Keep probe coverage and separate declared objectives');
  const conditions=[],conditionById=new Map;
  for(const row of list(raw.conditions,s.limits.maxConditions,s,'Conditions')){
    fields(row,['id','revision','hash','kind','dimensionId','weight'],s);const base=ref({id:row.id,revision:row.revision,hash:row.hash},s),weight=rational(row.weight,s),dimensionId=text(row.dimensionId,s);
    if(conditionById.has(base.id)||dimensionById.get(dimensionId)?.kind!=='probe'||weight.n<=0n)fail('Unique conditions need a probe dimension and positive weight');
    const c=freeze({...base,kind:text(row.kind,s),dimensionId,weight});conditions.push(c);conditionById.set(c.id,c);
  }sorted(conditions,s,c=>c.id);if(dimensions.some(d=>d.kind==='probe'&&!conditions.some(c=>c.dimensionId===d.id)))fail('Every probe dimension needs conditions');
  const subjects=[],subjectById=new Map;
  for(const row of list(raw.subjects,s.limits.maxSubjects,s,'Subjects')){
    fields(row,['id','revision','origin','parentId','source','annotations','metrics'],s);const id=text(row.id,s),origin=row.origin,parentId=row.parentId===null?null:text(row.parentId,s);
    if(subjectById.has(id)||!['user','generated','alternate'].includes(origin)||(origin==='alternate')!==(parentId!==null))fail('Unique subject origins and explicit alternate parents required');
    const a=fields(row.annotations,['id','revision','headEventIds','rhythmicSignature','directedIntervals','harmonicEntry','harmonicExit','range','phraseSpan','permittedAlterations'],s);
    const annotations={id:text(a.id,s),revision:rev(a.revision),headEventIds:ids(a.headEventIds,128,s)};if(!annotations.headEventIds.length)fail('Declare a nonempty protected head');
    for(const k of ['rhythmicSignature','directedIntervals','harmonicEntry','harmonicExit','range','phraseSpan','permittedAlterations'])annotations[k]=snapshot(a[k],s);
    const metrics=[],metricById=new Map;
    for(const r of list(row.metrics,s.limits.maxDimensions,s,'Declared metrics')){fields(r,['dimensionId','low','high','evidence'],s);const dimensionId=text(r.dimensionId,s),low=rational(r.low,s),high=rational(r.high,s);
      if(metricById.has(dimensionId)||dimensionById.get(dimensionId)?.kind!=='declared'||s.m.cmp(low,high)>0)fail('One ordered original interval per declared dimension required');
      const m=freeze({dimensionId,low,high,evidence:ref(r.evidence,s)});metrics.push(m);metricById.set(dimensionId,m)}sorted(metrics,s,m=>m.dimensionId);
    if(metrics.length!==dimensions.filter(d=>d.kind==='declared').length)fail('Incomplete declared metric inventory');
    const definition=freeze({id,revision:rev(row.revision),origin,parentId,source:ref(row.source,s),annotations:freeze(annotations),metrics:freeze(metrics)}),subject={definition,metricById,sourceDefinition:null};
    subjects.push(subject);subjectById.set(id,subject);
  }sorted(subjects,s,x=>x.definition.id);if(!subjects.length)fail('Declare at least one subject');
  for(const subject of subjects){const seen=new Set;let current=subject;while(current){s.charge();const id=current.definition.id;if(seen.has(id))fail('Alternate parent cycle');seen.add(id);const parent=current.definition.parentId;
    if(parent!==null&&!subjectById.has(parent))fail('Unregistered alternate parent');current=parent===null?null:subjectById.get(parent)}}
  const d=fields(raw.design,['id','revision','complete','subjects','conditions','probes'],s);if(d.complete!==true)fail('Complete independent probe design required','unknown-evidence');
  const expectedSubjects=ids(d.subjects,s.limits.maxSubjects,s),expectedConditions=ids(d.conditions,s.limits.maxConditions,s);
  if(encode(expectedSubjects,s)!==encode(subjects.map(x=>x.definition.id),s)||encode(expectedConditions,s)!==encode(conditions.map(c=>c.id),s))fail('Subject/condition rows differ from the independent inventory','unknown-evidence');
  const expected=[],expectedById=new Map,pairs=new Set;
  for(const row of list(d.probes,s.limits.maxProbes,s,'Expected probes')){fields(row,['id','subjectId','conditionId'],s);const e=freeze({id:text(row.id,s),subjectId:text(row.subjectId,s),conditionId:text(row.conditionId,s)}),pair=JSON.stringify([e.subjectId,e.conditionId]);
    if(expectedById.has(e.id)||pairs.has(pair)||!subjectById.has(e.subjectId)||!conditionById.has(e.conditionId))fail('One unique probe per original subject/condition required');expected.push(e);expectedById.set(e.id,e);pairs.add(pair)}
  if(pairs.size!==subjects.length*conditions.length)fail('Incomplete subject-by-condition design','unknown-evidence');sorted(expected,s,e=>e.id);
  const design=freeze({id:text(d.id,s),revision:rev(d.revision),complete:true,subjects:expectedSubjects,conditions:expectedConditions,probes:freeze(expected)});
  const probes=[],probeById=new Map;
  for(const row of list(raw.probes,s.limits.maxProbes,s,'Actual probes')){
    fields(row,['id','subjectId','conditionId','conditionHash','family'],s);const id=text(row.id,s),promise=expectedById.get(id),condition=conditionById.get(row.conditionId),subject=subjectById.get(row.subjectId);
    if(probeById.has(id)||!promise||promise.subjectId!==row.subjectId||promise.conditionId!==row.conditionId||!condition||!subject||digest(row.conditionHash,s)!==condition.hash)fail('Probe differs from its independent condition binding','unknown-evidence');
    const result=familyCall(null,'prepare',row.family,s);if(result.status!=='PASS')fail('Original probe preparation: '+result.reason,result.kind??'unknown-evidence');
    const family=result.prepared,fd=family.definition,source=fd.sources.find(x=>x.id===subject.definition.source.id),original=subject.definition.source;
    if(!source||source.revision!==original.revision||sha256(encode(source,s))!==original.hash)fail('Probe rewrites or substitutes the registered subject source','unknown-evidence');
    if(fd.expected.members.some(m=>!m.parts.some(p=>p.sourceId===original.id)))fail('Every promised probe member must include the original subject');
    const pitched=new Set(source.events.filter(e=>e.pitch!==null).map(e=>e.id));if(subject.definition.annotations.headEventIds.some(id=>!pitched.has(id)))fail('Protected head names missing or unpitched source events');
    if(!subject.sourceDefinition)subject.sourceDefinition=wire(source,s);
    const definition=freeze({id,subjectId:row.subjectId,conditionId:row.conditionId,conditionHash:condition.hash,familyHash:family.hash,familyDefinition:wire(fd,s)}),probe={definition,family};probes.push(probe);probeById.set(id,probe);
  }sorted(probes,s,p=>p.definition.id);if(probes.length!==expected.length)fail('Missing declared probe rows','unknown-evidence');
  const probeOrder=ids(raw.probeOrder,s.limits.maxProbes,s,false);if(probeOrder.length!==expected.length||probeOrder.some(id=>!probeById.has(id)))fail('Explicit probe order must be a permutation of all original probes');
  const definition=wire({id:text(raw.id,s),revision:rev(raw.revision),contextHash:digest(raw.contextHash,s),design,dimensions,conditions,
    subjects:subjects.map(x=>({...x.definition,sourceDefinition:x.sourceDefinition})),probes:probes.map(p=>p.definition),probeOrder},s);
  return {definition,hash:sha256(encode(definition,s)),dimensions,conditions,conditionById,subjects,subjectById,probes,probeById,probeOrder};
}
function result(s,status,reason,extra={}){return freeze({status,reason,scope,advisory:true,modelHash:s?.modelHash??null,workUsed:s?.used??0,probeCalls:s?.calls??0,resourceLimits:s?.limits??null,...extra})}
function refused(e,s){return result(s,e instanceof BadCertificate?'FAIL':'UNKNOWN',e.message??'Affordance refused',{kind:e instanceof Refused?e.kind:e instanceof BadCertificate?'invalid-certificate':'internal-error',report:null,certificate:null})}
function modelOf(prepared,s){const m=models.get(prepared);if(!m)fail('Use an authentic prepared affordance');s.modelHash=m.hash;
  if(m.subjects.length>s.limits.maxSubjects||m.conditions.length>s.limits.maxConditions||m.dimensions.length>s.limits.maxDimensions||m.probes.length>s.limits.maxProbes)fail('Prepared model exceeds current allowances','shape-budget');return m}
export function prepareDevelopmentAffordance(spec,options={}){let s;try{s=stateOf(options);const m=normalize(spec,s);s.modelHash=m.hash;const prepared=freeze({kind:'development-affordance-model-v1',hash:m.hash,definition:m.definition});models.set(prepared,m);return result(s,'PASS','Original subjects, full finite probe design and declared objectives prepared',{prepared});}catch(e){return refused(e,s)}}
function intervalRows(m,records,s,check){
  const byId=new Map(records.map(r=>[r.id,r])),rows=[];
  for(const subject of m.subjects){const metrics=[];for(const d of m.dimensions){s.charge();let low,high,passingWeight=null,failingWeight=null,unknownWeight=null,totalWeight=null;
    if(d.kind==='declared'){({low,high}=subject.metricById.get(d.id))}
    else{passingWeight=ZERO;failingWeight=ZERO;unknownWeight=ZERO;totalWeight=ZERO;
      for(const probe of m.probes){s.charge();const p=probe.definition,c=m.conditionById.get(p.conditionId);if(p.subjectId!==subject.definition.id||c.dimensionId!==d.id)continue;
        const status=byId.get(p.id).status;totalWeight=s.m.add(totalWeight,c.weight);if(status==='PASS')passingWeight=s.m.add(passingWeight,c.weight);else if(status==='FAIL')failingWeight=s.m.add(failingWeight,c.weight);else unknownWeight=s.m.add(unknownWeight,c.weight)}
      if(check){low=s.m.sub(ONE,s.m.div(s.m.add(failingWeight,unknownWeight),totalWeight));high=s.m.sub(ONE,s.m.div(failingWeight,totalWeight))}
      else{low=s.m.div(passingWeight,totalWeight);high=s.m.div(s.m.add(passingWeight,unknownWeight),totalWeight)}
    }metrics.push({dimensionId:d.id,low,high,passingWeight,failingWeight,unknownWeight,totalWeight});
  }rows.push({subjectId:subject.definition.id,metrics})}return rows;
}
function archiveOf(m,rows,s,check){
  const oriented=(v,d)=>d.goal==='maximize'?{low:v.low,high:v.high}:{low:s.m.sub(ZERO,v.high),high:s.m.sub(ZERO,v.low)};
  const archive=[];for(const a of rows){const dominatedBy=[],possibleDominators=[];
    for(const b of rows){if(a===b)continue;let guaranteed=true,possible=true,strictG=false,strictP=false;
      for(let k=0;k<m.dimensions.length;k++){s.charge();const d=m.dimensions[k],av=a.metrics[k],bv=b.metrics[k];let g,p;
        if(check){g=d.goal==='maximize'?s.m.cmp(bv.low,av.high):s.m.cmp(av.low,bv.high);p=d.goal==='maximize'?s.m.cmp(bv.high,av.low):s.m.cmp(av.high,bv.low)}
        else{const x=oriented(av,d),y=oriented(bv,d);g=s.m.cmp(y.low,x.high);p=s.m.cmp(y.high,x.low)}
        if(g<0)guaranteed=false;if(p<0)possible=false;if(g>0)strictG=true;if(p>0)strictP=true;
      }if(guaranteed&&strictG)dominatedBy.push(b.subjectId);if(possible&&strictP)possibleDominators.push(b.subjectId);
    }archive.push({subjectId:a.subjectId,status:dominatedBy.length?'DOMINATED':possibleDominators.length?'UNRESOLVED':'NONDOMINATED',dominatedBy,possibleDominators});
  }return archive;
}
function reportOf(m,records,s,check=false){const subjects=intervalRows(m,records,s,check),archive=archiveOf(m,subjects,s,check);return wire({coverageComplete:records.every(r=>r.status!=='UNKNOWN'),subjects,archive,retainedIds:archive.filter(a=>a.status!=='DOMINATED').map(a=>a.subjectId)},s)}
function diagnostic(id,attempted,out,s){return wire({id,attempted,reason:out?.reason??'Deferred by the explicit probe allowance',failedAudit:out?.status==='FAIL'?out:null},s)}
export function auditDevelopmentAffordance(prepared,options={}){let s;try{
  s=stateOf(options);const m=modelOf(prepared,s),byId=new Map,diagnostics=[];
  for(const id of m.probeOrder){s.charge();const p=m.probeById.get(id),attempted=s.calls<s.limits.maxProbeAudits&&s.limits.maxFamilyWork>0&&s.used<s.limits.maxWork;
    const out=attempted?familyCall(p.family,'audit',null,s):null,status=out?.status??'UNKNOWN';let refutedMemberId=null,familyCertificate=null;
    if(status==='PASS'){if(!out.certificate)throw new Error('Original PASS lacks a family certificate');familyCertificate=out.certificate}
    else if(status==='FAIL'){refutedMemberId=out.results?.find(r=>r.status==='FAIL')?.id;if(!refutedMemberId)throw new Error('Original FAIL lacks a refuted member')}
    else if(status!=='UNKNOWN')throw new Error('Unexpected original family status');
    byId.set(id,wire({id,status,refutedMemberId,familyCertificate},s));diagnostics.push(diagnostic(id,attempted,out,s));
  }
  const records=m.probes.map(p=>byId.get(p.definition.id)),report=reportOf(m,records,s),certificate=wire({kind:'development-affordance-certificate-v1',modelHash:m.hash,probes:records,report},s);encode(certificate,s,s.limits.maxCertificateChars);
  return result(s,'PASS','Complete finite report; unresolved probes retain their full possible mass',{report,certificate,diagnostics:freeze(diagnostics)});
}catch(e){return refused(e,s)}}
export function checkDevelopmentAffordance(prepared,raw,options={}){let s;try{
  s=stateOf(options);const m=modelOf(prepared,s),c=snapshot(raw,s);fields(c,['kind','modelHash','probes','report'],s);encode(c,s,s.limits.maxCertificateChars);
  demand(c.kind==='development-affordance-certificate-v1'&&c.modelHash===m.hash,'Wrong original affordance model or certificate kind');const byId=new Map;
  for(const r of list(c.probes,s.limits.maxProbes,s,'Certified probes')){fields(r,['id','status','refutedMemberId','familyCertificate'],s);const id=text(r.id,s);
    demand(!byId.has(id)&&m.probeById.has(id)&&['PASS','FAIL','UNKNOWN'].includes(r.status),'Duplicate, unpromised or invalid probe outcome');byId.set(id,r)}
  demand(byId.size===m.probes.length,'Certificate omits an original subject/condition');const records=[],diagnostics=[];
  for(const probe of m.probes){const id=probe.definition.id,r=byId.get(id);records.push(r);let out=null;
    if(r.status==='UNKNOWN')demand(r.refutedMemberId===null&&r.familyCertificate===null,'Unknown probe cannot carry a known-outcome assertion');
    else if(r.status==='PASS'){
      demand(r.refutedMemberId===null&&r.familyCertificate!==null,'A passing probe needs its full original family certificate');out=familyCall(probe.family,'check',r.familyCertificate,s);
      if(out.status==='UNKNOWN')fail('Original PASS replay unresolved: '+out.reason,'unknown-evidence');demand(out.status==='PASS','Original passing-probe certificate is invalid');
    }else{
      demand(typeof r.refutedMemberId==='string'&&r.familyCertificate===null&&probe.family.definition.expected.members.some(p=>p.id===r.refutedMemberId),'A failed probe needs an original named refutation');out=familyCall(probe.family,'audit',null,s);
      const refuted=out.results?.find(x=>x.id===r.refutedMemberId);if(out.status==='UNKNOWN'||refuted?.status==='UNKNOWN')fail('Original refutation replay unresolved','unknown-evidence');
      demand(out.status==='FAIL'&&refuted?.status==='FAIL','Named original member was not refuted');
    }diagnostics.push(diagnostic(id,r.status!=='UNKNOWN',out,s));
  }
  const report=reportOf(m,records,s,true);demand(encode(report,s)===encode(c.report,s),'Original coverage intervals or conservative archive differ');
  return result(s,'PASS','Original known outcomes, complementary mass bounds and raw-direction dominance verified',{report,certificate:null,diagnostics:freeze(diagnostics)});
}catch(e){return refused(e,s)}}
