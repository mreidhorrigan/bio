// Shared ensemble anchors inside a part's own meter. Adapts part-time-map.js's exact held-rate/linear-rate-glide
// model without flattening a glide's quadratic position. Planner code; no scheduler or physical-latency claim.
import {Q} from './canon-core.js';
import {dataRecord,dataArray} from './contract-data.js';
import {Refused,sha256,pythonJson} from '../bounded-exact.js';

export const ANCHOR_LIMITS=Object.freeze({pieces:256,groups:256,inverseIterations:512,id:256});
// The iteration count is a resource default, not a mathematical precision limit. Shape/bit caps stay unchanged.
export const ANCHOR_RESOURCE_DEFAULTS=Object.freeze({maxWork:100000,maxIterations:512});
const prepared=new WeakMap;
const fail=(message,kind='invalid-input')=>{throw new Refused(message,{kind})};
class WorkBudget {
  constructor(limit=ANCHOR_RESOURCE_DEFAULTS.maxWork){
    if(!Number.isSafeInteger(limit)||limit<0)fail('maxWork must be a nonnegative safe integer');
    this.limit=limit;this.used=0;
  }
  charge(amount=1){
    if(!Number.isSafeInteger(amount)||amount<0)throw new Error('Invalid internal shared-anchor work charge');
    if(amount>this.limit-this.used)fail('Exact work budget exhausted','work-budget');
    this.used+=amount;
  }
}
const fields=(value,allowed)=>{if(!dataRecord(value)||Object.keys(value).some(key=>!allowed.includes(key)))fail('Unsupported shared-anchor data fields')};
const name=value=>{if(typeof value!=='string'||!value.length||value.length>ANCHOR_LIMITS.id)fail('Invalid map name');return value};
const whole=value=>{const q=Q(value);if(q.d!==1n)fail('An integer coordinate is required');return q};
const nonnegative=value=>{const q=Q(value);if(q.cmp(0)<0)fail('A nonnegative value is required');return q};
const positive=value=>{const q=Q(value);if(q.cmp(0)<=0)fail('A positive value is required');return q};
const pair=value=>{dataArray(value,2,'Legacy rational');if(value.length!==2)fail('A legacy rational has two components');return Q({n:value[0],d:value[1]})};
const floor=q=>q.n/q.d-(q.n<0n&&q.n%q.d?1n:0n);
const ceil=q=>-floor(Q(0).sub(q));
const min=(a,b)=>a.cmp(b)<=0?a:b,max=(a,b)=>a.cmp(b)>=0?a:b;
const frozen=Object.freeze;
const iterationsOf=value=>{
  const limit=value===undefined?ANCHOR_RESOURCE_DEFAULTS.maxIterations:value;
  if(!Number.isSafeInteger(limit)||limit<0)fail('maxIterations must be a nonnegative safe integer');return limit;
};
const workOf=options=>{fields(options,['maxWork']);return new WorkBudget(options.maxWork)};
const hashOf=(definition,budget)=>{const encoded=pythonJson(definition);budget.charge(1+Math.ceil(encoded.length/64));return sha256(encoded)};

function meterOf(value,budget){
  budget.charge(8);
  if(!dataRecord(value))fail('A meter is a data record');
  const groups=dataArray(value.groups,ANCHOR_LIMITS.groups,'Meter groups').map(v=>{budget.charge(3);return positive(whole(v))});
  if(!groups.length)fail('A meter needs groups');
  const numerator=groups.reduce((a,b)=>{budget.charge();return a.add(b)},Q(0)),subdivision=positive(whole(value.subdivision)),denominator=positive(whole(value.denominator));
  if(value.numerator!==undefined&&!whole(value.numerator).eq(numerator))fail('Meter numerator and groups disagree');
  if(value.pulsesPerBar!==undefined&&!whole(value.pulsesPerBar).eq(numerator.mul(subdivision)))fail('Meter cycle and subdivision disagree');
  return {groups,numerator,subdivision,denominator,cycle:numerator.mul(subdivision)};
}

// Resolve a logical band anchor only inside an explicitly constant-meter finite bar span. Across meter changes the
// conductor supplies the appropriate span's fromTick; multiplying all earlier bars by the current meter is invalid.
export function sharedAnchorTick(anchor,span,options={}){
  const budget=workOf(options);budget.charge(12);
  fields(anchor,['bar','tickInBar']);fields(span,['fromBar','bars','fromTick','meter']);
  const bar=whole(anchor.bar),from=whole(span.fromBar),bars=positive(whole(span.bars)),tick=nonnegative(anchor.tickInBar),meter=meterOf(span.meter,budget);
  if(bar.cmp(from)<0||bar.cmp(from.add(bars))>=0||tick.cmp(meter.cycle)>=0)fail('Anchor outside the declared meter span','out-of-model');
  return Q(span.fromTick).add(bar.sub(from).mul(meter.cycle)).add(tick);
}

function positionIn(piece,offset,budget){
  // Fixed blocks account for bounded rational expressions; every variable-length traversal charges separately.
  budget.charge(3);
  if(piece.ticks.n===0n)return piece.start.add(piece.from.mul(offset));
  budget.charge(16);
  const D=piece.ticks,used=min(offset,D),during=piece.from.mul(used).add(piece.to.sub(piece.from).mul(used).mul(used).div(D.mul(2)));
  return piece.start.add(during).add(offset.cmp(D)>0?piece.to.mul(offset.sub(D)):0);
}

// id/revision and validThrough are the caller's frozen plan contract. A later meter/rate revision invalidates this
// certificate. Missing retained history and unpromised future extrapolation refuse explicitly.
export function prepareAnchorMap(spec){
  fields(spec,['id','revision','map','validThrough','maxWork']);const budget=new WorkBudget(spec.maxWork);budget.charge(8);name(spec.id);
  if(!Number.isSafeInteger(spec.revision)||spec.revision<0)fail('A map needs an explicit revision');
  fields(spec.map,['anchor','pieces']);const origin=whole(spec.map.anchor),through=Q(spec.validThrough);
  const input=dataArray(spec.map.pieces,ANCHOR_LIMITS.pieces,'Part-time pieces');if(!input.length)fail('No retained time-map pieces');
  const pieces=input.map(piece=>{
    budget.charge(16);
    fields(piece,['at','start','from','to','ticks']);const at=whole(piece.at),start=pair(piece.start),from=pair(piece.from),to=pair(piece.to),ticks=nonnegative(whole(piece.ticks));
    if(at.cmp(origin)<0||start.cmp(0)<0||from.cmp(0)<=0||to.cmp(0)<=0)fail('Invalid retained part-time piece');
    if(!ticks.n&&!from.eq(to))fail('A held piece cannot declare a different ending rate');
    return frozen({at,start,from,to,ticks});
  });
  if(pieces[0].at.eq(origin)&&!pieces[0].start.eq(0))fail('The part begins at its own tick zero');
  for(let i=1;i<pieces.length;i++){
    budget.charge(4);
    const before=pieces[i-1],current=pieces[i];
    if(current.at.cmp(before.at)<=0||!positionIn(before,current.at.sub(before.at),budget).eq(current.start))fail('Piece changes must increase in shared time and preserve exact own position');
  }
  if(through.cmp(pieces.at(-1).at)<0)fail('The declared horizon must cover all retained piece starts');
  budget.charge(1+pieces.length*6);
  const definition=frozen({id:spec.id,revision:spec.revision,anchor:String(origin),validFrom:String(pieces[0].at),validThrough:String(through),
    pieces:frozen(pieces.map(p=>frozen(Object.fromEntries(Object.entries(p).map(([key,value])=>[key,String(value)])))))});
  const hash=hashOf(definition,budget);
  const indexAt=(t,work)=>{
    work.charge(3);
    if(t.cmp(pieces[0].at)<0||t.cmp(through)>0)fail('Outside retained, promised clock coverage','out-of-model');
    let lo=0,hi=pieces.length;while(hi-lo>1){work.charge();const mid=(lo+hi)>>1;if(t.cmp(pieces[mid].at)<0)hi=mid;else lo=mid}return lo;
  };
  const at=(value,work)=>{work.charge(2);const t=Q(value),p=pieces[indexAt(t,work)];return positionIn(p,t.sub(p.at),work)};
  const map=frozen({id:definition.id,revision:definition.revision,hash,definition,
    at:(value,options={})=>at(value,workOf(options)),workUsed:budget.used,resources:frozen({maxWork:budget.limit})});
  prepared.set(map,{pieces,through,at});return map;
}

// A rational enclosure for an own-tick callback's shared coordinate. A held rate gives an exact rational inverse;
// a glide can have an irrational inverse, so exact endpoint inequalities certify an interval instead of a fake root.
export function locateOwnTick(map,own,options={}){
  fields(options,['maxWidth','maxWork','maxIterations']);
  const model=prepared.get(map);if(!model)fail('Use a prepared anchor map');
  const budget=new WorkBudget(options.maxWork),maxIterations=iterationsOf(options.maxIterations);budget.charge(16);
  const target=Q(own),width=positive(options.maxWidth),{pieces,through}=model,at=value=>model.at(value,budget);
  if(target.cmp(pieces[0].start)<0||target.cmp(at(through))>0)fail('Own tick outside retained, promised clock coverage','out-of-model');
  let index=0;for(let i=1;i<pieces.length;i++){budget.charge();if(pieces[i].start.cmp(target)>0)break;index=i}
  const p=pieces[index],end=index+1<pieces.length?pieces[index+1].at:through;
  let exact=null,lo=p.at,hi=min(end,p.at.add(p.ticks));
  if(!p.ticks.n||p.from.eq(p.to))exact=p.at.add(target.sub(p.start).div(p.from));
  else{
    const glideEnd=p.at.add(p.ticks),reached=positionIn(p,p.ticks,budget);
    if(glideEnd.cmp(end)<=0&&target.cmp(reached)>=0)exact=glideEnd.add(target.sub(reached).div(p.to));
  }
  let iterations=0;
  if(exact!==null)lo=hi=exact;
  else{
    if(at(lo).eq(target))hi=lo;else if(at(hi).eq(target))lo=hi;
    while(hi.sub(lo).cmp(width)>0){
      budget.charge(6);if(iterations>=maxIterations)fail('Inverse enclosure iteration cap','work-budget');iterations++;
      const middle=lo.add(hi).div(2),value=at(middle),order=value.cmp(target);
      if(order<0)lo=middle;else if(order>0)hi=middle;else lo=hi=middle;
    }
  }
  budget.charge(6);const lowerPosition=String(at(lo)),upperPosition=String(at(hi));
  return frozen({kind:lo.eq(hi)?'exact':'enclosure',own:String(target),from:String(lo),to:String(hi),
    lowerPosition,upperPosition,mapHash:map.hash,iterations,workUsed:budget.used,
    resources:frozen({maxWork:budget.limit,maxIterations}),
    claim:'Unique shared coordinate enclosed under the supplied exact map; not a binary64 audio-time error bound'});
}

// The written point in the part's own meter. Its rational notated-note offset admits a binary subdivision followed
// by a single odd:1 tuplet level. This describes the anchor point, not the complete duration/spelling of a phrase.
function writtenAnchorIn(own,meter,budget){
  budget.charge(16);
  const m=meterOf(meter,budget),position=nonnegative(own),bar=floor(position.div(m.cycle)),tick=position.sub(m.cycle.mul(bar)),notes=tick.div(m.subdivision);
  const definition=frozen({groups:frozen(m.groups.map(String)),numerator:String(m.numerator),subdivision:String(m.subdivision),denominator:String(m.denominator)});
  let denominator=notes.d,binaryDepth=0;while(denominator%2n===0n){budget.charge();denominator/=2n;binaryDepth++}
  let group=0,start=Q(0);while(group+1<m.groups.length){budget.charge(3);if(notes.cmp(start.add(m.groups[group]))<0)break;start=start.add(m.groups[group]);group++}
  return frozen({meter:definition,meterHash:hashOf(definition,budget),bar:String(bar),tickInBar:String(tick),notatedNotesInBar:String(notes),quarterOffset:String(notes.mul(4).div(m.denominator)),
    group,groupOffset:String(notes.sub(start)),grid:frozen({binaryDepth,tuplet:denominator===1n?null:frozen({actual:String(denominator),normal:'1'})}),
    scope:'Exact anchor coordinate in a fixed part meter; full event durations and engraving remain separate'});
}
export function writtenAnchor(own,meter,options={}){return writtenAnchorIn(own,meter,workOf(options))}

// availableAt is the known-information time in shared ticks; beforeTick states callback/batch ordering at equality.
// leadTicks is the required scheduling/preparation allowance, maxLookAheadTicks the host's permitted look-ahead
// (null explicitly means unbounded in this model). No default latency, look-ahead or information ordering is assumed.
// Legacy agent.js batches all own callbacks for shared tick n at n; audio.eventTime may point later inside that
// batch. Select shared-tick-batch for that host. own-time is only for a host actually dispatching at each own instant.
// In batch mode beforeTick=false means receipt after the whole batch; partial within-batch ordering is not modeled.
export function sharedAnchor(spec){
  fields(spec,['map','anchor','meter','availableAt','beforeTick','leadTicks','maxLookAheadTicks','dispatchModel','maxWork','maxIterations']);
  const map=spec.map;if(!prepared.has(map))fail('Use a prepared anchor map');
  const budget=new WorkBudget(spec.maxWork),maxIterations=iterationsOf(spec.maxIterations),model=prepared.get(map);
  const at=value=>model.at(value,budget);
  const target=Q(spec.anchor),available=Q(spec.availableAt),lead=nonnegative(spec.leadTicks);
  const lookAhead=spec.maxLookAheadTicks===null?null:nonnegative(spec.maxLookAheadTicks);
  if(typeof spec.beforeTick!=='boolean')fail('Declare information availability before/after a coincident own callback');
  if(!['own-time','shared-tick-batch'].includes(spec.dispatchModel))fail('Declare the host dispatch model');
  const upper=target.sub(lead),lower=lookAhead===null?available:max(available,target.sub(lookAhead));
  const common={mapHash:map.hash,mapRevision:map.revision,sharedTick:String(target),dispatchModel:spec.dispatchModel,
    scope:'Exact frozen map and declared callback/batch dispatch model only; revalidate after any clock/plan revision'};
  const finish=result=>frozen({...result,workUsed:budget.used,resources:frozen({maxWork:budget.limit,maxIterations})});
  try{
    budget.charge(16);
    const own=at(target),written=writtenAnchorIn(own,spec.meter,budget),partial={...common,ownTick:String(own),written};
    if(lower.cmp(upper)>0)return finish({...partial,status:'UNSAT',reason:'The information, lead and look-ahead windows have empty intersection'});
    let first,last,batch=null;
    if(spec.dispatchModel==='own-time'){
      const earliestPosition=at(lower),latestPosition=at(upper);
      first=ceil(earliestPosition);if(lower.eq(available)&&!spec.beforeTick&&earliestPosition.d===1n)first++;
      last=floor(latestPosition);
    }else{
      let from=ceil(lower);const to=floor(upper);
      if(lower.eq(available)&&!spec.beforeTick&&lower.d===1n)from++;
      if(from>to)return finish({...partial,status:'UNSAT',reason:'No shared callback batch lies inside the declared information/lead/look-ahead window'});
      first=ceil(at(Q(from)));
      const batchEnd=Q(to).add(1),end=min(target,batchEnd),atEnd=at(end);
      // Exclude the next batch at its boundary, but include the anchor if it falls inside an admitted batch.
      last=end.eq(batchEnd)?ceil(atEnd)-1n:floor(atEnd);
      if(first<=last){
        let lo=from,hi=to,iterations=0;
        while(lo<hi){
          budget.charge(5);if(iterations>=maxIterations)fail('Shared dispatch batch search cap','work-budget');iterations++;
          const middle=lo+(hi-lo+1n)/2n;
          if(at(Q(middle)).cmp(Q(last))<=0)lo=middle;else hi=middle-1n;
        }
        batch=String(lo);
      }
    }
    if(first>last)return finish({...partial,status:'UNSAT',reason:'No own-tick callback lies inside the complete declared scheduling window',firstOwnTick:String(first),lastOwnTick:String(last)});
    return finish({...partial,status:'SAT',dispatch:frozen({ownTick:String(last),firstOwnTick:String(first),sharedBatchTick:batch,sharedWindow:frozen([String(lower),String(upper)]),
      beforeTick:spec.beforeTick,leadTicks:String(lead),maxLookAheadTicks:lookAhead===null?null:String(lookAhead)}),
      boundary:'Submit the preserved shared target from this callback; do not replace it with that callback\'s eventTime'});
  }catch(error){
    if(!(error instanceof Refused)||!['out-of-model','work-budget','arithmetic-budget'].includes(error.kind))throw error;
    return finish({...common,status:'UNKNOWN',reason:error.message,kind:error.kind});
  }
}
