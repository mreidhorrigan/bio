// CFM-022 / EC06: exact continuous decomposition against an immutable authored reference.
// L2 projection is unconstrained; component/total caps are audited separately, never traded against fit.
import {Refused,EXACT_LIMITS,ZERO,ONE,exactOf,exactText,add,sub,mul,div,compare,pythonJson,sha256} from '../bounded-exact.js';
import {dataRecord,dataArray} from './contract-data.js';

export const COHERENT_DEFORMATION_DEFAULTS=Object.freeze({maxWork:500000,maxBasis:16,maxKnots:1024,
  maxGrid:32768,maxTextChars:4194304,maxCertificateChars:1048576});
const freeze=Object.freeze,refs=new WeakMap,scope='authored-continuous-L2-decomposition-and-separate-caps';
const metrics=freeze(['peak','absoluteExposure','squaredExposure','startOffset','endOffset']);
const rawBoundary=1n<<256n,derivedBoundary=1n<<8192n;
const fail=(message,kind='invalid-input')=>{throw new Refused(message,{kind})};
class InvalidCertificate extends Error {}
const requireCertificate=(condition,message)=>{if(!condition)throw new InvalidCertificate(message)};
const count=value=>{if(!Number.isSafeInteger(value)||value<0)fail('Use finite nonnegative safe-integer limits/revisions');return value};
class Work{
  constructor(limit){this.limit=count(limit);this.used=0}
  charge(n=1){if(!Number.isSafeInteger(n)||n<0)throw new Error('Invalid internal charge');if(n>this.limit-this.used)fail('Coherent-deformation work exhausted','work-budget');this.used+=n}
}
function stateOf(options){
  if(!dataRecord(options)||Object.keys(options).some(k=>!Object.hasOwn(COHERENT_DEFORMATION_DEFAULTS,k)))fail('Unsupported deformation options');
  const limits={};for(const [k,v] of Object.entries(COHERENT_DEFORMATION_DEFAULTS))limits[k]=Object.hasOwn(options,k)?count(options[k]):v;
  const work=new Work(limits.maxWork),state={limits:freeze(limits),work,chars:0,modelHash:null,referenceHash:null};work.charge();
  state.math={add(a,b){work.charge();return add(a,b)},sub(a,b){work.charge();return sub(a,b)},mul(a,b){work.charge();return mul(a,b)},
    div(a,b){work.charge();return div(a,b)},compare(a,b){work.charge();return compare(a,b)}};
  return state;
}
function fields(value,keys,state){
  state.work.charge();if(!dataRecord(value)||Object.keys(value).length!==keys.length||keys.some(k=>!Object.hasOwn(value,k)))fail('Unexpected or missing deformation data fields');
  state.work.charge(keys.length);return value;
}
function array(value,limit,state,label){
  if(!Array.isArray(value)||value.length>limit)fail(`${label} exceeds its array allowance`,'shape-budget');
  state.work.charge(value.length+1);return dataArray(value,limit,label);
}
function text(value,state,limit=256){
  if(typeof value!=='string'||!value.length||value.length>limit)fail('Require bounded nonempty text');
  if(value.length>state.limits.maxTextChars-state.chars)fail('Deformation text allowance exhausted','work-budget');
  state.chars+=value.length;state.work.charge(1+Math.ceil(value.length/64));return value;
}
function integer(value){
  const n=typeof value==='bigint'?value:Number.isSafeInteger(value)?BigInt(value):null;
  if(n===null)fail('Use exact integers, fraction/decimal text or integer components');
  if(n<=-rawBoundary||n>=rawBoundary)fail('Raw rational component exceeds 256 bits','arithmetic-budget');return n;
}
function rational(value,state){
  state.work.charge();let n,d=1n;
  if(typeof value==='string'){
    text(value,state,160);const fraction=value.match(/^([+-]?[0-9]+)(?:\/([+-]?[0-9]+))?$/);
    if(fraction&&fraction[0].length===value.length){n=integer(BigInt(fraction[1]));d=integer(BigInt(fraction[2]??'1'))}
    else{
      const token=value.match(/^([+-]?)(?:([0-9]+)(?:\.([0-9]*))?|\.([0-9]+))(?:[eE]([+-]?[0-9]{1,3}))?$/);
      if(!token||token[0].length!==value.length)fail('Invalid exact decimal/fraction text');
      const [,sign,whole='',part=token[4]??'',,exp='0']=token,power=Number(exp);
      if(Math.abs(power)>256)fail('Decimal exponent allowance','arithmetic-budget');
      n=integer(BigInt((whole+part)||'0')*(sign==='-'?-1n:1n));const shift=power-part.length;
      if(shift< -77||shift>77&&n!==0n)fail('Expanded decimal component exceeds 256 bits','arithmetic-budget');
      if(shift>0&&n!==0n)n=integer(n*10n**BigInt(shift));else if(shift<0)d=integer(10n**BigInt(-shift));
    }
  }else if(value&&typeof value==='object'){fields(value,['n','d'],state);n=integer(value.n);d=integer(value.d)}
  else n=integer(value);
  if(d===0n)fail('Zero rational denominator');return exactOf({n,d});
}
function derived(value,state){
  text(value,state,6000);state.work.charge();const token=value.match(/^(-?[0-9]+)(?:\/([0-9]+))?$/);
  if(!token||token[0].length!==value.length)fail('Certificate scalar needs canonical integer/fraction text');
  const n=BigInt(token[1]),d=BigInt(token[2]??'1');
  if(n<=-derivedBoundary||n>=derivedBoundary||d<=0n||d>=derivedBoundary)fail('Certificate scalar exceeds derived arithmetic allowance','arithmetic-budget');
  const q=exactOf({n,d},{bits:EXACT_LIMITS.workBits});if(exactText(q)!==value)fail('Noncanonical certificate scalar');return q;
}
function hash(value,state,certificate=false){
  const parts=[];let size=0;const limit=certificate?state.limits.maxCertificateChars:state.limits.maxTextChars;
  const append=s=>{if(s.length>limit-size)fail('Deformation canonical text exhausted','work-budget');size+=s.length;parts.push(s)};
  function encode(v){
    state.work.charge();if(v===null||typeof v!=='object'){append(pythonJson(v));return}
    if(Array.isArray(v)){append('[');for(let i=0;i<v.length;i++){if(i)append(',');encode(v[i])}append(']');return}
    const keys=Object.keys(v).sort((a,b)=>{state.work.charge();return a<b?-1:a>b?1:0});
    append('{');for(let i=0;i<keys.length;i++){if(i)append(',');append(pythonJson(keys[i]));append(':');encode(v[keys[i]])}append('}');
  }
  encode(value);state.work.charge(1+Math.ceil(size/64));return sha256(parts.join(''));
}
function domain(raw,state){fields(raw,['id','unit','revision'],state);return freeze({id:text(raw.id,state),unit:text(raw.unit,state),revision:count(raw.revision)})}
const sameDomain=(a,b)=>a.id===b.id&&a.unit===b.unit&&a.revision===b.revision;
function curve(raw,window,state,positive=false){
  array(raw,state.limits.maxKnots,state,'PWL knots');if(raw.length<2)fail('A PWL curve needs both window endpoints');const out=[];
  for(const row of raw){
    fields(row,['at','value'],state);const at=rational(row.at,state),value=rational(row.value,state),old=out.at(-1);
    if(old&&state.math.compare(at,old.at)<=0)fail('Knot abscissae must strictly increase');
    if(positive&&old&&state.math.compare(value,old.value)<=0)fail('Wall clock must have strictly positive segment slopes','out-of-model');
    out.push(freeze({at,value}));
  }
  if(state.math.compare(out[0].at,window[0])||state.math.compare(out.at(-1).at,window[1]))fail('Every PWL curve must cover exactly the full window','missing-evidence');
  return freeze(out);
}
const wireCurve=points=>freeze(points.map(({at,value})=>freeze({at:exactText(at),value:exactText(value)})));
function caps(raw,state){
  fields(raw,metrics,state);const out={};for(const key of metrics){const value=raw[key]===null?null:rational(raw[key],state);
    if(value!==null&&state.math.compare(value,ZERO)<0)fail('Caps must be nonnegative or explicitly null');out[key]=value}
  return freeze(out);
}
const wireCaps=raw=>freeze(Object.fromEntries(metrics.map(key=>[key,raw[key]===null?null:exactText(raw[key])])));

/** Immutable numerical reference; creating a token does not grant permission to revise a musical promise. */
export function prepareCoherentReference(spec,options={}){
  let state;
  try{
    state=stateOf(options);fields(spec,['id','revision','source','residualUnit','window','knots'],state);
    const id=text(spec.id,state),revision=count(spec.revision),source=domain(spec.source,state),residualUnit=text(spec.residualUnit,state);
    array(spec.window,2,state,'Reference window');if(spec.window.length!==2)fail('A window needs two endpoints');
    const window=freeze(spec.window.map(v=>rational(v,state)));if(state.math.compare(window[0],window[1])>=0)fail('Require a positive-length window');
    const points=curve(spec.knots,window,state),definition=freeze({id,revision,source,residualUnit,window:freeze(window.map(exactText)),knots:wireCurve(points)});
    const referenceHash=hash(definition,state),token=freeze({...definition,hash:referenceHash,setupWorkUsed:state.work.used});
    refs.set(token,freeze({definition,hash:referenceHash,window,points,source,residualUnit}));return token;
  }catch(error){if(error instanceof Refused){error.workUsed=state?.work.used??0}throw error}
}
function normalize(spec,state){
  fields(spec,['id','revision','reference','actual','basis','measure','caps'],state);
  const id=text(spec.id,state),revision=count(spec.revision),reference=refs.get(spec.reference);
  if(!reference)fail('Use a genuine immutable coherent reference','out-of-model');state.referenceHash=reference.hash;
  const a=fields(spec.actual,['id','revision','source','unit','knots'],state),actualSource=domain(a.source,state),actualUnit=text(a.unit,state);
  if(!sameDomain(actualSource,reference.source)||actualUnit!==reference.residualUnit)fail('Actual curve clock or residual units differ from the reference','out-of-model');
  const actualId=text(a.id,state),actualRevision=count(a.revision),actual=curve(a.knots,reference.window,state);
  array(spec.basis,state.limits.maxBasis,state,'Authored basis');const basis=[],ids=new Set;
  for(const raw of spec.basis){
    fields(raw,['id','unit','knots'],state);const name=text(raw.id,state);if(ids.has(name)||raw.unit!=='1')fail('Basis identities must be unique and their values dimensionless');ids.add(name);
    basis.push(freeze({id:name,points:curve(raw.knots,reference.window,state)}));
  }
  if(!dataRecord(spec.measure))fail('Explicit score or wall measure required');let measure,clockPoints=null;
  if(spec.measure.kind==='score'){fields(spec.measure,['kind'],state);measure=freeze({kind:'score',clock:reference.source})}
  else if(spec.measure.kind==='wall'){
    fields(spec.measure,['kind','clock','knots'],state);const clock=domain(spec.measure.clock,state);
    clockPoints=curve(spec.measure.knots,reference.window,state,true);measure=freeze({kind:'wall',clock,knots:wireCurve(clockPoints)});
  }else fail('No implicit or unknown exposure measure','out-of-model');
  const rawCaps=fields(spec.caps,['total','coherent','remainder','components'],state),parsedCaps={};
  for(const key of ['total','coherent','remainder'])parsedCaps[key]=caps(rawCaps[key],state);
  array(rawCaps.components,state.limits.maxBasis,state,'Component caps');if(rawCaps.components.length!==basis.length)fail('Every authored component needs its explicit cap record');
  const byId=new Map;
  for(const raw of rawCaps.components){fields(raw,['id','caps'],state);const name=text(raw.id,state);if(!ids.has(name)||byId.has(name))fail('Unknown or repeated component cap identity');byId.set(name,caps(raw.caps,state))}
  parsedCaps.components=freeze(basis.map(b=>freeze({id:b.id,caps:byId.get(b.id)})));freeze(parsedCaps);
  const definition=freeze({id,revision,referenceHash:reference.hash,
    actual:freeze({id:actualId,revision:actualRevision,source:actualSource,unit:actualUnit,knots:wireCurve(actual)}),
    basis:freeze(basis.map(b=>freeze({id:b.id,unit:'1',knots:wireCurve(b.points)}))),measure,
    caps:freeze({...Object.fromEntries(['total','coherent','remainder'].map(k=>[k,wireCaps(parsedCaps[k])])),
      components:freeze(parsedCaps.components.map(row=>freeze({id:row.id,caps:wireCaps(row.caps)})))})});
  state.modelHash=hash(definition,state);
  return freeze({definition,reference,actual,basis:freeze(basis),clockPoints,caps:parsedCaps});
}
function evaluate(points,x,state){
  let low=0,high=points.length-1;const m=state.math;
  while(low+1<high){state.work.charge();const mid=Math.floor((low+high)/2);if(m.compare(points[mid].at,x)<=0)low=mid;else high=mid}
  const a=points[low],b=points[low+1];return m.add(a.value,m.mul(m.div(m.sub(x,a.at),m.sub(b.at,a.at)),m.sub(b.value,a.value)));
}
function prepareGrid(model,state){
  const unique=new Map;
  for(const points of [model.reference.points,model.actual,...model.basis.map(b=>b.points),...(model.clockPoints?[model.clockPoints]:[])])for(const p of points){
    state.work.charge();const key=exactText(p.at);if(!unique.has(key)){if(unique.size>=state.limits.maxGrid)fail('Refined PWL grid allowance exhausted','work-budget');unique.set(key,p.at)}
  }
  const grid=[...unique.values()].sort((a,b)=>state.math.compare(a,b)),m=state.math;
  const residual=grid.map(x=>m.sub(evaluate(model.actual,x,state),evaluate(model.reference.points,x,state)));
  const basis=model.basis.map(b=>grid.map(x=>evaluate(b.points,x,state))),weights=[];
  for(let i=1;i<grid.length;i++)weights.push(model.clockPoints?m.sub(evaluate(model.clockPoints,grid[i],state),evaluate(model.clockPoints,grid[i-1],state)):m.sub(grid[i],grid[i-1]));
  return {grid,residual,basis,weights};
}
function inner(f,g,prepared,state){
  const m=state.math;let total=ZERO;
  for(let i=1;i<f.length;i++){
    state.work.charge();const a=f[i-1],b=f[i],c=g[i-1],d=g[i];
    const terms=m.add(m.add(m.mul(exactOf(2),m.mul(a,c)),m.mul(a,d)),m.add(m.mul(b,c),m.mul(exactOf(2),m.mul(b,d))));
    total=m.add(total,m.div(m.mul(prepared.weights[i-1],terms),exactOf(6)));
  }
  return total;
}
function gramOf(prepared,state){
  const n=prepared.basis.length;state.work.charge(n*n+n);
  const gram=Array.from({length:n},()=>Array(n)),rhs=[];
  for(let i=0;i<n;i++){
    rhs.push(inner(prepared.basis[i],prepared.residual,prepared,state));
    for(let j=0;j<=i;j++)gram[i][j]=gram[j][i]=inner(prepared.basis[i],prepared.basis[j],prepared,state);
  }
  return {gram,rhs};
}
function factorAndSolve(gram,rhs,state){
  const n=gram.length,m=state.math,lower=[],diagonal=[];
  for(let i=0;i<n;i++){
    const row=[];
    for(let j=0;j<i;j++){
      let value=gram[i][j];for(let k=0;k<j;k++)value=m.sub(value,m.mul(m.mul(row[k],diagonal[k]),lower[j][k]));
      row.push(m.div(value,diagonal[j]));
    }
    let pivot=gram[i][i];for(let k=0;k<i;k++)pivot=m.sub(pivot,m.mul(m.mul(row[k],row[k]),diagonal[k]));
    if(m.compare(pivot,ZERO)<=0)fail('Authored basis is dependent or has no certified positive Gram factor','out-of-model');
    lower.push(row);diagonal.push(pivot);
  }
  const forward=[];
  for(let i=0;i<n;i++){let value=rhs[i];for(let j=0;j<i;j++)value=m.sub(value,m.mul(lower[i][j],forward[j]));forward.push(value)}
  const solution=Array(n);
  for(let i=n-1;i>=0;i--){let value=m.div(forward[i],diagonal[i]);for(let j=i+1;j<n;j++)value=m.sub(value,m.mul(lower[j][i],solution[j]));solution[i]=value}
  return {lower,diagonal,solution};
}
function absolute(q,state){return state.math.compare(q,ZERO)<0?state.math.sub(ZERO,q):q}
function summarize(values,prepared,state){
  const m=state.math;let peak=ZERO,signed=ZERO,abs=ZERO,squared=ZERO;
  for(let i=0;i<values.length;i++){
    const v=absolute(values[i],state);if(m.compare(v,peak)>0)peak=v;if(!i)continue;
    const a=values[i-1],b=values[i],x=absolute(a,state),y=v,weight=prepared.weights[i-1];
    signed=m.add(signed,m.div(m.mul(weight,m.add(a,b)),exactOf(2)));
    const squares=m.add(m.mul(a,a),m.mul(b,b));
    squared=m.add(squared,m.div(m.mul(weight,m.add(squares,m.mul(a,b))),exactOf(3)));
    const crossing=m.compare(a,ZERO)*m.compare(b,ZERO)<0;
    abs=m.add(abs,crossing?m.div(m.mul(weight,squares),m.mul(exactOf(2),m.add(x,y))):m.div(m.mul(weight,m.add(x,y)),exactOf(2)));
  }
  const start=values[0],end=values.at(-1);
  return {peak,absoluteExposure:abs,squaredExposure:squared,startOffset:absolute(start,state),endOffset:absolute(end,state),
    signedStart:start,signedEnd:end,netEndpointDrift:m.sub(end,start),signedExposure:signed};
}
function reportOf(model,prepared,coefficients,state){
  const m=state.math,components=prepared.basis.map((values,j)=>values.map(v=>m.mul(v,coefficients[j])));
  const coherent=prepared.grid.map((_,i)=>{let v=ZERO;for(const c of components)v=m.add(v,c[i]);return v});
  const remainder=prepared.residual.map((v,i)=>m.sub(v,coherent[i])),violations=[];
  const records=[];
  for(const [id,values,limit] of [['total',prepared.residual,model.caps.total],['coherent',coherent,model.caps.coherent],
    ['remainder',remainder,model.caps.remainder],...components.map((v,i)=>[`component:${model.basis[i].id}`,v,model.caps.components[i].caps])]){
    const summary=summarize(values,prepared,state);
    for(const key of metrics){state.work.charge();if(limit[key]!==null&&m.compare(summary[key],limit[key])>0)
      violations.push(freeze({id,metric:key,value:exactText(summary[key]),cap:exactText(limit[key])}))}
    records.push(freeze({id,knots:freeze(prepared.grid.map((at,i)=>freeze({at:exactText(at),value:exactText(values[i])}))),
      summary:freeze(Object.fromEntries(Object.entries(summary).map(([k,v])=>[k,exactText(v)])))}));
  }
  const measureUnit=model.definition.measure.clock.unit;
  return freeze({status:violations.length?'FAIL':'PASS',projectionStatus:'CERTIFIED',referenceHash:model.reference.hash,
    coefficients:freeze(model.basis.map((b,i)=>freeze({id:b.id,value:exactText(coefficients[i])}))),
    units:freeze({residual:model.reference.residualUnit,coefficient:model.reference.residualUnit,measure:measureUnit,
      signedExposure:`${model.reference.residualUnit}*${measureUnit}`,absoluteExposure:`${model.reference.residualUnit}*${measureUnit}`,
      squaredExposure:`${model.reference.residualUnit}^2*${measureUnit}`}),
    records:freeze(records),violations:freeze(violations)});
}
function result(state,status,reason,extra={}){return freeze({status,reason,scope,modelHash:state?.modelHash??null,
  referenceHash:state?.referenceHash??null,workUsed:state?.work.used??0,resourceLimits:state?.limits??null,...extra})}
function run(options,body){let state;try{state=stateOf(options);return body(state)}catch(error){
  return result(state,error instanceof InvalidCertificate?'FAIL':'UNKNOWN',error.message??'Deformation processing refused',
    {kind:error instanceof Refused?error.kind:error instanceof InvalidCertificate?'invalid-certificate':'internal-error',conclusion:null})}}

export function decomposeCoherentResidual(spec,options={}){
  return run(options,state=>{
    const model=normalize(spec,state),prepared=prepareGrid(model,state),{gram,rhs}=gramOf(prepared,state),factor=factorAndSolve(gram,rhs,state);
    const report=reportOf(model,prepared,factor.solution,state),reportHash=hash(report,state);
    const certificate=freeze({kind:'coherent-deformation-v1',modelHash:state.modelHash,referenceHash:model.reference.hash,
      coefficients:report.coefficients,lower:freeze(factor.lower.map(row=>freeze(row.map(exactText)))),diagonal:freeze(factor.diagonal.map(exactText)),reportHash});
    hash(certificate,state,true);
    return result(state,report.status,'Unique unconstrained L2 decomposition; all authored caps independently checked',{report,certificate});
  });
}

/** Checks exact identities and original caps without rerunning coefficient optimization. */
export function checkCoherentDeformation(spec,raw,options={}){
  return run(options,state=>{
    const model=normalize(spec,state),n=model.basis.length;
    fields(raw,['kind','modelHash','referenceHash','coefficients','lower','diagonal','reportHash'],state);
    for(const key of ['kind','modelHash','referenceHash','reportHash'])text(raw[key],state);
    requireCertificate(raw.kind==='coherent-deformation-v1'&&raw.modelHash===state.modelHash&&raw.referenceHash===model.reference.hash,'Certificate binding differs');
    array(raw.coefficients,n,state,'Coefficients');array(raw.lower,n,state,'Unit-lower factor');array(raw.diagonal,n,state,'Positive diagonal');
    requireCertificate(raw.coefficients.length===n&&raw.lower.length===n&&raw.diagonal.length===n,'Certificate dimension differs');
    const coefficients=[],lower=[],diagonal=[];
    for(let i=0;i<n;i++){
      fields(raw.coefficients[i],['id','value'],state);text(raw.coefficients[i].id,state);
      requireCertificate(raw.coefficients[i].id===model.basis[i].id,'Coefficient basis identity differs');coefficients.push(derived(raw.coefficients[i].value,state));
      array(raw.lower[i],i,state,'Strict-lower row');requireCertificate(raw.lower[i].length===i,'Triangular row dimension differs');
      lower.push(raw.lower[i].map(v=>derived(v,state)));diagonal.push(derived(raw.diagonal[i],state));
      requireCertificate(state.math.compare(diagonal[i],ZERO)>0,'Gram certificate is not positive definite');
    }
    const saved=freeze({kind:raw.kind,modelHash:raw.modelHash,referenceHash:raw.referenceHash,
      coefficients:freeze(coefficients.map((v,i)=>freeze({id:model.basis[i].id,value:exactText(v)}))),
      lower:freeze(lower.map(row=>freeze(row.map(exactText)))),diagonal:freeze(diagonal.map(exactText)),reportHash:raw.reportHash});
    hash(saved,state,true);
    const prepared=prepareGrid(model,state),{gram,rhs}=gramOf(prepared,state),m=state.math;
    for(let i=0;i<n;i++)for(let j=0;j<=i;j++){
      let value=ZERO;for(let k=0;k<=j;k++)value=m.add(value,m.mul(m.mul(k===i?ONE:lower[i][k],diagonal[k]),k===j?ONE:lower[j][k]));
      requireCertificate(m.compare(value,gram[i][j])===0,'Gram factor identity fails');
    }
    for(let i=0;i<n;i++){
      let value=ZERO;for(let j=0;j<n;j++)value=m.add(value,m.mul(gram[i][j],coefficients[j]));
      requireCertificate(m.compare(value,rhs[i])===0,'Projection normal equations fail');
    }
    const report=reportOf(model,prepared,coefficients,state);requireCertificate(hash(report,state)===saved.reportHash,'Reconstructed exposure report differs');
    return result(state,'PASS','Positive Gram factor, normal equations and original-reference cap report independently checked',
      {conclusion:report.status,projectionStatus:'CERTIFIED',report});
  });
}
