// CFM-004: one jointly audited entry per section/part in a declared finite delay/map domain.
// Existence, exhaustive coverage and optimality are distinct. No policy, rounding, octave fitting or live rollout.
import {Q,Rational,auditSlices} from './canon-core.js';
import {compilePitchOperations} from './pitch-spaces.js';
import {compileCounterpointProfile} from './counterpoint-profile.js';
import {dataArray,dataRecord} from './contract-data.js';
import {Budget,Refused,exactOf,pythonJson,sha256} from '../bounded-exact.js';

export const ENTRY_LIMITS=Object.freeze({sections:16,sourceEvents:128,choices:32,variants:1024,
  harmonySpans:128,tones:128,groups:256,nodes:100000,diagnostics:16,diagnosticChecks:64,
  snapshotNodes:32768,string:2048,depth:12,hashChars:2000000});
const maps=new WeakMap,freeze=Object.freeze;
const fail=(message,kind='invalid-input')=>{throw new Refused(message,{kind})};
const fields=(value,allowed,required=allowed)=>{
  if(!dataRecord(value)||Object.keys(value).some(key=>!allowed.includes(key))||required.some(key=>!Object.hasOwn(value,key)))fail('Unexpected or missing entry fields');
  return value;
};
const name=value=>{if(typeof value!=='string'||!value.length||value.length>256)fail('A bounded nonempty identity is required');return value};
const count=(value,maximum)=>{if(!Number.isSafeInteger(value)||value<0||value>maximum)fail('Invalid finite entry count');return value};
const exact=value=>Q(typeof value==='string'&&!value.includes('/')?exactOf(value):value);
const nonnegative=value=>{const q=exact(value);if(q.cmp(0)<0)fail('A nonnegative exact value is required');return q};
const positive=value=>{const q=exact(value);if(q.cmp(0)<=0)fail('A positive exact value is required');return q};
const floor=q=>q.n/q.d-(q.n<0n&&q.n%q.d!==0n?1n:0n);
function snapshot(value,state,depth=0,seen=new Set){
  state.budget.charge();if(++state.snapshots>ENTRY_LIMITS.snapshotNodes)fail('Entry snapshot-node budget','work-budget');
  if(value===null||typeof value==='boolean')return value;
  if(typeof value==='string'){if(value.length>ENTRY_LIMITS.string)fail('Entry text limit','work-budget');return value}
  if(typeof value==='number'){if(!Number.isFinite(value))fail('Nonfinite entry data');return value}
  if(value&&Object.getPrototypeOf(value)===Rational.prototype)return String(Q(value));
  if(depth>=ENTRY_LIMITS.depth||seen.has(value))fail('Cyclic or deep entry data');seen.add(value);let out;
  if(Array.isArray(value)){
    dataArray(value,65536,'Entry snapshot array');out=[];
    for(let i=0;i<value.length;i++)out.push(snapshot(value[i],state,depth+1,seen));
  }else{
    if(!dataRecord(value)||Object.keys(value).length>256)fail('Entry metadata must be ordinary data');out={};
    for(const key of Object.keys(value)){
      if(key.length>256)fail('Metadata key limit');
      Object.defineProperty(out,key,{value:snapshot(value[key],state,depth+1,seen),enumerable:true});
    }
  }
  seen.delete(value);return freeze(out);
}
function hash(value,state){
  const text=pythonJson(value);if(text.length>ENTRY_LIMITS.hashChars)fail('Entry hash-size budget','work-budget');
  state.budget.charge(1+Math.ceil(text.length/64));return sha256(text);
}
const mapState=map=>{const state=maps.get(map);if(!state)fail('Use a prepared entry pitch map');return state};
function preparedMap(space,definition,apply){
  compilePitchOperations(space,[]);const frozen=freeze(definition),hash=sha256(pythonJson(frozen));
  const api=freeze({id:definition.id,hash,definition:frozen,apply(pitch,context={}){
    const state={budget:new Budget(),snapshots:0};return apply(space.pitch(pitch),snapshot(context,state),state);
  }});
  maps.set(api,{space,apply,definition:frozen,hash});return api;
}

// Wrap the existing typed operation compiler: native semitone/cent translations, EDP/degree translations,
// exact ratio products or lattice operations keep their declared semantics; unsupported acoustic audits stay UNKNOWN.
export function entryPitchMap(spec){
  fields(spec,['id','pitchSpace','operations']);name(spec.id);const compiled=compilePitchOperations(spec.pitchSpace,spec.operations);
  return preparedMap(spec.pitchSpace,{id:spec.id,type:'typed-operations',pitchSpace:spec.pitchSpace.hash,
    operations:compiled.operations,operationHash:compiled.hash},(pitch,context,state)=>{
    state.budget.charge(1+compiled.operations.length);return compiled.apply(pitch);
  });
}

// amount is exact; a caller with a Number must explicitly use exactOfNumber/pitchFromNumber at its own boundary.
// One semitone is exactly 100 cents here; neither coordinate is rounded to an integer or folded modulo 12.
export function realEntryMap(spec){
  fields(spec,['id','pitchSpace','amount','unit']);const space=spec.pitchSpace;compilePitchOperations(space,[]);
  if(!['semitones','cents'].includes(space.kind)||!['semitones','cents'].includes(spec.unit))fail('Real shifts require a semitone or cents space and an explicit unit','out-of-model');
  let amount=exact(spec.amount);if(space.kind!==spec.unit)amount=space.kind==='cents'?amount.mul(100):amount.div(100);
  return entryPitchMap({id:spec.id,pitchSpace:space,operations:[{type:'transpose',by:amount}]});
}

// context[contextKey] = {id,revision,origin,period,steps}; origin/period/steps use the space's coordinate units.
// Collection selection is at the TRANSFORMED onset. Input pitch must be an exact lifted collection member.
// The same steps/periods relation applies to every note; unequal physical intervals are intentional tonal motion.
export function tonalEntryMap(spec){
  fields(spec,['id','pitchSpace','steps','periods','contextKey']);name(spec.id);name(spec.contextKey);
  const space=spec.pitchSpace;compilePitchOperations(space,[]);
  if(!['semitones','cents'].includes(space.kind))fail('Contextual tonal maps require an explicitly valued semitone/cents collection','out-of-model');
  for(const key of ['steps','periods'])if(!Number.isSafeInteger(spec[key])||Math.abs(spec[key])>65536)fail('Tonal shift count limit');
  const definition={id:spec.id,type:'contextual-tonal',pitchSpace:space.hash,steps:spec.steps,periods:spec.periods,contextKey:spec.contextKey};
  return preparedMap(space,definition,(pitch,context,state)=>{
    const value=context[definition.contextKey];if(value===undefined)fail('Missing tonal collection at the transformed onset','out-of-model');
    fields(value,['id','revision','origin','period','steps']);name(value.id);count(value.revision,Number.MAX_SAFE_INTEGER);
    const origin=exact(value.origin),period=positive(value.period);dataArray(value.steps,ENTRY_LIMITS.tones,'Tonal collection');
    if(!value.steps.length)fail('An empty tonal collection has no defined degree map','out-of-model');
    const steps=[];for(let i=0;i<value.steps.length;i++){
      state.budget.charge();const step=nonnegative(value.steps[i]);
      if(step.cmp(period)>=0||i&&step.cmp(steps[i-1])<=0)fail('Tonal collection steps must strictly increase inside the period');steps.push(step);
    }
    const coordinate=exact(space.pitch(pitch).coordinate),cycle=floor(coordinate.sub(origin).div(period));
    const residue=coordinate.sub(origin).sub(period.mul(cycle));let index=-1;
    for(let i=0;i<steps.length;i++){state.budget.charge();if(residue.eq(steps[i]))index=i}
    if(index<0)fail('Source pitch is not an exact member of the onset collection','out-of-model');
    const width=BigInt(steps.length),lift=Q(BigInt(index)+BigInt(definition.steps)+BigInt(definition.periods)*width);
    const carry=floor(lift.div(width)),next=Number(lift.n-carry*width);
    return space.pitch(origin.add(period.mul(cycle+carry)).add(steps[next]));
  });
}

// Felt delays count exact integer groups from the bar origin. notatedUnit converts one notated note to source units.
export function feltEntryDelay(spec){
  fields(spec,['felt','groups','notatedUnit']);const felt=count(spec.felt,65536),unit=positive(spec.notatedUnit);
  dataArray(spec.groups,ENTRY_LIMITS.groups,'Felt groups');if(!spec.groups.length)fail('Felt groups cannot be empty');
  let total=Q(0),prefix=Q(0);for(let i=0;i<spec.groups.length;i++){
    const group=positive(spec.groups[i]);total=total.add(group);if(i<felt%spec.groups.length)prefix=prefix.add(group);
  }
  return total.mul(Math.floor(felt/spec.groups.length)).add(prefix).mul(unit);
}

function pitch(space,value){
  fields(value,['space','definition','coordinate']);if(value.space!==space.id||value.definition!==space.hash)fail('Undeclared pitch space or tuning revision','out-of-model');return space.pitch(value);
}
function rationalPower(base,exponent,state){
  if(exponent<0n){base=Q(1).div(base);exponent=-exponent}
  let result=Q(1);
  while(exponent){
    state.budget.charge();if(exponent&1n)result=result.mul(base);
    exponent>>=1n;if(exponent)base=base.mul(base);
  }
  return result;
}
function order(space,a,b,state){
  state.budget.charge();
  // Every scalar coordinate kind offered by pitch-spaces.js is strictly increasing in physical pitch.
  if(space.kind!=='lattice')return exact(a.coordinate).cmp(b.coordinate);
  // Physical order needs the sign of the rational frequency ratio, not rational-valued cents.
  // Coordinate-distinct vectors with product ratio one are physically equal without changing either identity.
  let ratio=Q(1);
  for(let i=0;i<space.definition.generators.length;i++){
    state.budget.charge();const exponent=exact(b.coordinate[i]).sub(a.coordinate[i]);
    if(exponent.d!==1n)fail('A lattice requires lifted integer coordinates','out-of-model');
    ratio=ratio.mul(rationalPower(exact(space.definition.generators[i]),exponent.n,state));
  }
  return -ratio.cmp(1);
}
function normalize(spec,state){
  fields(spec,['id','revision','line','length','pitchSpace','clockDomain','sections','harmony','profile','weights','domainComplete','joint']);
  const id=name(spec.id),revision=count(spec.revision,Number.MAX_SAFE_INTEGER),space=spec.pitchSpace;compilePitchOperations(space,[]);
  const c=fields(spec.clockDomain,['id','unit','revision']),clock=freeze({id:name(c.id),unit:name(c.unit),revision:count(c.revision,Number.MAX_SAFE_INTEGER)});
  const length=positive(spec.length);dataArray(spec.line,ENTRY_LIMITS.sourceEvents,'Source line');if(!spec.line.length)fail('Supply a finite nonempty source line');
  const line=[],sourceIds=new Set;
  for(let i=0;i<spec.line.length;i++){
    state.budget.charge();const raw=fields(spec.line[i],['id','t','d','pitch']),sourceId=name(raw.id),t=nonnegative(raw.t),d=positive(raw.d);
    if(sourceIds.has(sourceId)||t.add(d).cmp(length)>0)fail('Duplicate source identity or event beyond source length');sourceIds.add(sourceId);
    line.push(freeze({id:sourceId,t,d,pitch:raw.pitch===null?null:pitch(space,raw.pitch),clockDomain:clock}));
  }
  line.sort((a,b)=>{state.budget.charge();return a.t.cmp(b.t)||(a.id<b.id?-1:a.id>b.id?1:0)});freeze(line);
  const weightInput=fields(spec.weights,['delay','map']),weights=freeze({delay:nonnegative(weightInput.delay),map:nonnegative(weightInput.map)});
  if(typeof spec.domainComplete!=='boolean')fail('Declare whether the finite domain is complete');
  dataArray(spec.sections,ENTRY_LIMITS.sections,'Sections');if(!spec.sections.length)fail('At least one section/part is required');
  const sections=[],sectionIds=new Set;let variants=0;
  for(let i=0;i<spec.sections.length;i++){
    state.budget.charge();const raw=fields(spec.sections[i],['id','register','delays','maps']),sectionId=name(raw.id);
    if(sectionIds.has(sectionId))fail('Duplicate section identity');sectionIds.add(sectionId);
    const r=fields(raw.register,['low','high']),register=freeze({low:pitch(space,r.low),high:pitch(space,r.high)});
    const registerOrder=order(space,register.low,register.high,state);
    if(registerOrder>0)fail('Reversed whole-line register');
    dataArray(raw.delays,ENTRY_LIMITS.choices,'Delay choices');dataArray(raw.maps,ENTRY_LIMITS.choices,'Pitch-map choices');
    const delays=[],pitchMaps=[],delayIds=new Set,mapIds=new Set;
    for(let j=0;j<raw.delays.length;j++){
      state.budget.charge();const d=fields(raw.delays[j],['id','at','cost']),delayId=name(d.id);
      if(delayIds.has(delayId))fail('Duplicate delay identity');delayIds.add(delayId);delays.push(freeze({id:delayId,at:nonnegative(d.at),cost:nonnegative(d.cost)}));
    }
    for(let j=0;j<raw.maps.length;j++){
      state.budget.charge();const m=fields(raw.maps[j],['map','cost']),prepared=mapState(m.map);
      if(prepared.space.hash!==space.hash||mapIds.has(m.map.id))fail('Duplicate map identity or incompatible pitch space');mapIds.add(m.map.id);
      pitchMaps.push(freeze({map:m.map,cost:nonnegative(m.cost)}));
    }
    variants+=delays.length*pitchMaps.length;if(variants>ENTRY_LIMITS.variants)fail('Entry variant budget','work-budget');
    sections.push(freeze({id:sectionId,register,delays:freeze(delays),maps:freeze(pitchMaps)}));
  }
  freeze(sections);
  const h=fields(spec.harmony,['id','revision','membership','periodCents','spans']);name(h.id);count(h.revision,Number.MAX_SAFE_INTEGER);
  if(!['all-sounding','onset','profile-only'].includes(h.membership))fail('Declare the harmonic membership scope');
  const period=h.periodCents===null?null:positive(h.periodCents);dataArray(h.spans,ENTRY_LIMITS.harmonySpans,'Harmony spans');
  const spans=[],boundaries=[];
  for(let i=0;i<h.spans.length;i++){
    state.budget.charge();const s=fields(h.spans[i],['from','to','pitches','context']),from=nonnegative(s.from),to=positive(s.to);
    if(from.cmp(to)>=0||i&&from.cmp(spans[i-1].to)<0)fail('Harmony spans must be ordered nonoverlapping half-open intervals');
    let pitches=null;if(s.pitches!==null){dataArray(s.pitches,ENTRY_LIMITS.tones,'Harmonic pitches');pitches=[];for(let j=0;j<s.pitches.length;j++){state.budget.charge();pitches.push(pitch(space,s.pitches[j]))}freeze(pitches)}
    const context=snapshot(s.context,state);if(!dataRecord(context)||Object.hasOwn(context,'$harmony'))fail('Harmony context must be a record without reserved $harmony');
    spans.push(freeze({from,to,pitches,context}));boundaries.push(from,to);
  }
  const harmony=freeze({id:h.id,revision:h.revision,membership:h.membership,periodCents:period?String(period):null,spans:freeze(spans)});
  const p=fields(spec.profile,['id','version','rules']);
  const profile=compileCounterpointProfile({id:p.id,version:p.version,pitchSpace:space,clockDomain:clock,voices:sections.map(s=>s.id),rules:p.rules});
  let joint=null;if(spec.joint!==null){const j=fields(spec.joint,['id','version','check']);if(typeof j.check!=='function')fail('A whole-joint predicate is required');joint=freeze({id:name(j.id),version:count(j.version,Number.MAX_SAFE_INTEGER),check:j.check})}
  const definition=freeze({id,revision,line,length,clockDomain:clock,pitchSpace:space.hash,weights,domainComplete:spec.domainComplete,
    sections:freeze(sections.map(s=>freeze({id:s.id,register:s.register,delays:s.delays,maps:freeze(s.maps.map(m=>freeze({definition:m.map.definition,hash:m.map.hash,cost:m.cost})))}))),
    harmony,profile:profile.definition,joint:joint?freeze({id:joint.id,version:joint.version}):null});
  const model={definition,space,line,length,clock,sections,harmony,profile,joint,boundaries:freeze(boundaries),weights};model.hash=hash(definition,state);return model;
}
function spanAt(model,time,state){
  let lo=0,hi=model.harmony.spans.length;
  while(lo<hi){state.budget.charge();const mid=(lo+hi)>>1;if(model.harmony.spans[mid].from.cmp(time)<=0)lo=mid+1;else hi=mid}
  const span=model.harmony.spans[lo-1];return span&&time.cmp(span.to)<0?span:null;
}
function buildEntry(model,sectionIndex,delayIndex,mapIndex,state){
  const section=model.sections[sectionIndex],delay=section.delays[delayIndex],choice=section.maps[mapIndex],m=mapState(choice.map);
  const entryId=`entry:${sectionIndex}:${delayIndex}:${mapIndex}`,events=[];
  for(const source of model.line){
    state.budget.charge();const t=source.t.add(delay.at);let value=null;
    if(source.pitch!==null){
      try{value=m.apply(source.pitch,spanAt(model,t,state)?.context??freeze({}),state)}
      catch(error){if(error instanceof Refused&&error.kind==='out-of-model')return freeze({status:'UNKNOWN',reason:error.message});throw error}
      const a=order(model.space,section.register.low,value,state),b=order(model.space,value,section.register.high,state);
      if(a>0||b>0)return freeze({status:'FAIL',reason:'An actual transformed source pitch lies outside the whole register',sourceId:source.id});
    }
    events.push(freeze({id:`${entryId}:${source.id}`,sourceId:source.id,entryId,voiceId:section.id,t,d:source.d,pitch:value,clockDomain:model.clock}));
  }
  return freeze({status:'PASS',reason:'Every transformed pitch fits the whole register',
    sectionId:section.id,delayId:delay.id,mapId:choice.map.id,mapHash:choice.map.hash,delay:delay.at,events:freeze(events)});
}
const combined=values=>values.includes('FAIL')?'FAIL':values.includes('UNKNOWN')?'UNKNOWN':'PASS';
function auditQuota(state){const quota=Math.floor((state.budget.limit-state.budget.used)/4);if(quota<1)fail('No audit work remains','work-budget');return quota}
function auditChoices(model,choices,state){
  const entries=[],events=[];let cost=Q(0);
  for(let i=0;i<model.sections.length;i++){
    state.budget.charge();const selected=choices[i],section=model.sections[i],entry=buildEntry(model,i,selected.delay,selected.map,state);
    if(entry.status!=='PASS')return freeze({status:entry.status,reason:entry.reason,sectionId:section.id,sourceId:entry.sourceId??null});
    entries.push(entry);for(const event of entry.events)events.push(event);
    cost=cost.add(section.delays[selected.delay].cost.mul(model.weights.delay)).add(section.maps[selected.map].cost.mul(model.weights.map));
  }
  events.sort((a,b)=>{state.budget.charge();return a.t.cmp(b.t)||(a.id<b.id?-1:a.id>b.id?1:0)});freeze(events);freeze(entries);
  const contextAt=time=>{
    const span=spanAt(model,time,state);return span?{...span.context,$harmony:{from:span.from,to:span.to,pitches:span.pitches}}:{};
  };
  let quota=auditQuota(state);
  const profile=model.profile.audit(events,{boundaries:model.boundaries,contextAt,
    dependencies:{model:model.hash,harmony:{id:model.harmony.id,revision:model.harmony.revision}},maxWork:quota,maxPredicateWork:quota});
  // auditSlices includes an event normalization at least as large as the profile's preceding normalization.
  // Charge twice its reported work plus the separate predicate budget; callback context lookups charge directly.
  state.budget.charge(2*profile.workUsed+profile.predicateWorkUsed);
  quota=auditQuota(state);
  const harmonic=auditSlices(events,{boundaries:model.boundaries,contextAt,maxWork:quota,profileId:'entry-harmony',profileVersion:1,
    dependencies:{model:model.hash},rules:[{id:'coverage-and-membership',kind:'slice',required:true,check({slice,context}){
      if(!slice.active.length)return 'PASS';const h=context.$harmony;
      if(!h)return {status:'UNKNOWN',detail:{reason:'Sounding material extends outside the declared harmonic timeline'}};
      if(model.harmony.membership==='profile-only')return 'PASS';
      const active=model.harmony.membership==='onset'?slice.active.filter(e=>e.t.eq(slice.start)):slice.active;
      if(!active.length)return 'PASS';if(h.pitches===null)return {status:'UNKNOWN',detail:{reason:'Required harmonic pitch set is missing'}};
      const results=[];
      for(const event of active){
        let yes=false,unknown=false;
        for(const allowed of h.pitches){
          state.budget.charge();
          if(model.harmony.periodCents===null){const same=model.space.equivalent(event.pitch,allowed);if(same===true)yes=true;if(same==='UNKNOWN')unknown=true}
          else{const cents=model.space.interval(allowed,event.pitch).exactCents;if(cents===null)unknown=true;else if(exact(cents).div(model.harmony.periodCents).d===1n)yes=true}
        }
        results.push(yes?'PASS':unknown?'UNKNOWN':'FAIL');
      }
      return {status:combined(results),detail:{reason:'Actual sounding pitches against the declared harmonic set',events:active.map(e=>e.id)}};
    }}]});
  state.budget.charge(harmonic.workUsed);
  const immutableProfile=snapshot(profile,state),immutableHarmony=snapshot(harmonic,state);
  let jointEvidence=null,jointStatus='UNKNOWN';
  const choiceRecord=freeze(entries.map(e=>freeze({sectionId:e.sectionId,delayId:e.delayId,mapId:e.mapId})));
  const witness=freeze({modelHash:model.hash,choices:choiceRecord,entries,events,cost:String(cost),
    harmony:model.harmony,profileAudit:immutableProfile,harmonyAudit:immutableHarmony});
  if(model.joint){
    state.budget.charge();let reply;
    try{reply=model.joint.check(witness,freeze({maxWork:state.budget.limit-state.budget.used}))}
    catch{reply={status:'UNKNOWN',detail:{reason:'Whole-joint predicate threw or refused'}}}
    if(typeof reply==='string')jointStatus=reply;
    else{jointEvidence=snapshot(reply,state);jointStatus=jointEvidence?.status}
    if(!['PASS','FAIL','UNKNOWN'].includes(jointStatus))jointStatus='UNKNOWN';
  }
  const status=combined([profile.status,harmonic.status,jointStatus]);
  return freeze({...witness,status,reason:'Reconstructed whole entries and actual combined sounding/context audits',
    jointAudit:freeze({status:jointStatus,evidence:jointEvidence,contract:model.definition.joint}),
    eventHash:hash(events,state),witnessHash:hash({choices:choiceRecord,events,cost,modelHash:model.hash},state)});
}
function readChoices(model,raw,state){
  dataArray(raw,ENTRY_LIMITS.sections,'Entry choices');if(raw.length!==model.sections.length)fail('Choose every section exactly once');
  const bySection=new Map;
  for(let i=0;i<raw.length;i++){
    state.budget.charge();const c=fields(raw[i],['sectionId','delayId','mapId']);for(const key of ['sectionId','delayId','mapId'])name(c[key]);
    if(bySection.has(c.sectionId))fail('Duplicate chosen section');bySection.set(c.sectionId,c);
  }
  return model.sections.map(section=>{
    const c=bySection.get(section.id);if(!c)fail('Undeclared or missing chosen section');
    const delay=section.delays.findIndex(d=>{state.budget.charge();return d.id===c.delayId});
    const map=section.maps.findIndex(m=>{state.budget.charge();return m.map.id===c.mapId});
    if(delay<0||map<0)fail('Choice is outside the declared finite domain');return {delay,map};
  });
}
function setup(options){
  fields(options,['maxWork','maxNodes'],[]);const budget=new Budget(options.maxWork),state={budget,snapshots:0};
  return state;
}
const scope='declared-finite-entry-domain-and-named-joint-contract';
const unknown=(error,state,model)=>freeze({status:'UNKNOWN',scope,reason:error.message,kind:error.kind??'predicate',modelHash:model?.hash??null,workUsed:state?.budget.used??0});

// Independent primal check: choices are identifiers only; source events and transformations are rebuilt.
export function auditEntryChoices(spec,choices,options={}){
  let state,model;try{
    state=setup(options);model=normalize(spec,state);if(Object.hasOwn(options,'maxNodes'))fail('Independent audit has no search-node option');
    const audit=auditChoices(model,readChoices(model,choices,state),state);return freeze({...audit,scope,modelHash:model.hash,workUsed:state.budget.used});
  }catch(error){if(!(error instanceof Refused))throw error;return unknown(error,state,model)}
}

export function chooseEntries(spec,options={}){
  let state,model;try{
    state=setup(options);model=normalize(spec,state);const maxNodes=count(Object.hasOwn(options,'maxNodes')?options.maxNodes:10000,ENTRY_LIMITS.nodes);
    if(!model.joint)return freeze({status:'UNKNOWN',scope,reason:'Required whole-joint grammar was not supplied',modelHash:model.hash,workUsed:state.budget.used});
    const variants=[],diagnostics=[];let localRefutations=0;
    const diagnostic=(choices,audit)=>{
      if(diagnostics.length>=ENTRY_LIMITS.diagnostics)return;
      const checks=[];
      for(const part of [audit.profileAudit,audit.harmonyAudit])for(const check of part?.checks??[])
        if(check.status!=='PASS'&&check.status!=='N/A'&&checks.length<ENTRY_LIMITS.diagnosticChecks)checks.push(check);
      diagnostics.push(freeze({choices:choices?freeze(choices.map(c=>freeze({...c}))):null,status:audit.status,reason:audit.reason,
        sectionId:audit.sectionId??null,sourceId:audit.sourceId??null,checks:freeze(checks)}));
    };
    for(let i=0;i<model.sections.length;i++){
      const section=model.sections[i],list=[];
      for(let d=0;d<section.delays.length;d++)for(let m=0;m<section.maps.length;m++){
        state.budget.charge();const local=buildEntry(model,i,d,m,state);
        if(local.status==='FAIL'){localRefutations++;diagnostic(null,local);continue}
        list.push(freeze({delay:d,map:m,cost:section.delays[d].cost.mul(model.weights.delay).add(section.maps[m].cost.mul(model.weights.map))}));
      }
      list.sort((a,b)=>{state.budget.charge();return a.cost.cmp(b.cost)||a.delay-b.delay||a.map-b.map});variants.push(freeze(list));
    }
    const suffix=Array(variants.length+1);suffix[variants.length]=Q(0);
    for(let i=variants.length-1;i>=0;i--)suffix[i]=suffix[i+1].add(variants[i][0]?.cost??0);
    let nodes=0,leaves=0,unknownLeaves=0,prunedByCost=0,best=null,bestCost=null,unresolvedMinimum=null,stopped=null;
    const chosen=[];
    function search(depth,cost){
      if(nodes>=maxNodes)fail('Entry search-node budget','work-budget');state.budget.charge();nodes++;
      if(best&&cost.add(suffix[depth]).cmp(bestCost)>=0){prunedByCost++;return}
      if(depth===variants.length){
        leaves++;const audit=auditChoices(model,chosen,state);
        if(audit.status==='PASS'){if(!best||cost.cmp(bestCost)<0){best=audit;bestCost=cost}}
        else{diagnostic(audit.choices??null,audit);if(audit.status==='UNKNOWN'){unknownLeaves++;if(unresolvedMinimum===null||cost.cmp(unresolvedMinimum)<0)unresolvedMinimum=cost}}
        return;
      }
      for(const choice of variants[depth]){state.budget.charge();chosen.push(choice);search(depth+1,cost.add(choice.cost));chosen.pop()}
    }
    try{search(0,Q(0))}catch(error){if(!(error instanceof Refused))throw error;stopped=freeze({reason:error.message,kind:error.kind})}
    const complete=stopped===null,within=Boolean(best)&&complete&&(unresolvedMinimum===null||unresolvedMinimum.cmp(bestCost)>=0);
    const searchInfo=freeze({nodes,leaves,unknownLeaves,localRefutations,prunedByCost,complete,domainComplete:model.definition.domainComplete,
      unresolvedMinimum:unresolvedMinimum===null?null:String(unresolvedMinimum),stopped});
    if(best)return freeze({status:'SAT',scope,modelHash:model.hash,entries:best.entries,events:best.events,choices:best.choices,cost:best.cost,audit:best,
      optimalWithinDeclaredDomain:within,optimal:within&&model.definition.domainComplete,search:searchInfo,diagnostics:freeze(diagnostics),workUsed:state.budget.used});
    return freeze({status:complete&&!unknownLeaves&&model.definition.domainComplete?'UNSAT':'UNKNOWN',scope,modelHash:model.hash,
      reason:stopped?'Search stopped without an audited witness':unknownLeaves?'At least one candidate has unresolved semantics':!model.definition.domainComplete?'The finite domain was declared incomplete':'Every choice in the complete declared finite domain is refuted',
      optimal:false,optimalWithinDeclaredDomain:false,search:searchInfo,diagnostics:freeze(diagnostics),workUsed:state.budget.used});
  }catch(error){if(!(error instanceof Refused))throw error;return unknown(error,state,model)}
}
