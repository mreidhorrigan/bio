// A fugue's exposition across a conductor's sections (Musebots 3.0's seventh lack, docs/MUSEBOTS_3.md: "There is no fugue
// layer (exposition, answer, countersubject, episodes, stretto)"; the owner, 30 September 2026: "this should allow them
// eventually to plan and play fugues and canons"). Where the form develops, the orchestra's conductor may make a
// section of the form a fugal exposition: one subject, drawn from the section's own collection (canon-plan.js
// subjectFrom), entering in each of its sections in turn -- the subject, then the answer, as many of the collection's
// degrees up as its rules count a perfect interval (counterpoint.js perfectDegrees: in a diatonic collection the fifth or
// the fourth, drawn; a tonal answer, every note's own inflection kept: stepInCollection), then the subject again --
// each entry as its last ends where every voice fits so, else as far apart as they all fit (entries overlapping, as many
// on one pulse as fit no further apart: a fugue of two hundred voices enters in a cascade). A section waits, silent, for its entry, plays it as given (its conductor's formation a
// line given its notes: section-voices.js, each part an octave its own), then the countersubject against the next
// entry -- a second line drawn from the same collection, busier where the subject holds, moved as the entry it
// accompanies is -- and goes on in free counterpoint after, as the voices of an exposition do, planned against every
// other voice wherever it has nothing given (or resting, as often as its rests' share). Then episodes: the
// subject's head passed from section to section in a sequence, each at a level its walk by the subject's own steps
// reaches (a degree of the collection lower each time where no walk arrives home), until, as the
// section of the form ends, the subject returns: in stretto where there is room -- every voice entering half a subject
// after the one before (else as its counterpoint holds together: stretto.js), in their order, the answer's degrees on
// every other -- else once, in the section that began. A
// layer of the section planned (fugue), which each section's conductor reads.
//
// Its rules bind as a timeline (the owner, 3 October 2026: "a piece of music could be a fugue (intensely rulebound) or
// canon (most intensely rulebound) for part of its run, but a free episode (less rulebound) for other parts of it"):
// its exposition and its return keep its counterpoint's strictness, its episodes a softer one (FUGUE.episode.leeway),
// each span said (regimes). Its search spends where its rules bind: a free line's beam is COUNTERPOINT.beam times its
// span's strictness, so a voice heading into freer space does not search hard for fugal solutions there; and a free
// line ending where its voice's given material begins is planned into it, its last move weighed under the rules of
// the span it enters (counterLine's `toward`): the way back into rule-bound space.
//
// Entries need the section of the form to hold them: a subject and some room after it, two voices at least, else none.
import {subjectFrom,canonParts,placeQuarters,meterOfBar,stepInCollection,plannedSubject,augmentedLine,invertedLine,retrogradeLine} from './canon-plan.js';
import {counterLine,ladderOf,strongBeats,drawnRules,blendRules,perfectDegrees,COUNTERPOINT} from './counterpoint.js';
import {bandMeter} from '../opening-time.js';
import {fugueAnswers,answerLine} from './fugue-answer.js';
import {strettoPlan} from './stretto.js';
import {sharedCountersubject,repairedCountersubject,subjectAffordance,episodeLevels} from './fugue-contracts.js';
import {cadenceBudget} from './fugue-cadence.js';
import {jointFugueTheme} from './joint-fugue-theme.js';
import {repetitionOf,repetitionCost} from '../repetition.js';
import {add,compare,exactOfNumber} from '../bounded-exact.js';

// ---- Choices (ours) ---------------------------------------------------------------------------------------------------
// A source of draws of its own, from `text` (a fugue's other subjects', forked from its first's notes; mulberry32 on its
// FNV-1a hash).
function forkedSource(text){
  let h=2166136261;for(const c of String(text))h=Math.imul(h^c.charCodeAt(0),16777619);let a=h>>>0;
  return ()=>{a=(a+0x6D2B79F5)>>>0;let t=a;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return ((t^t>>>14)>>>0)/4294967296};
}
// A time settled: the decimal of at most six places it lies within a few of its last places of, else itself.
export const settled=x=>{const r=Math.round(x*1e6)/1e6;return Math.abs(r-x)<=64*Number.EPSILON*Math.max(1,Math.abs(x))?r:x};
// The largest float under a positive one.
const below=x=>{const bits=new Float64Array([x]),word=new BigInt64Array(bits.buffer);word[0]-=1n;return bits[0]};
// A voice's notes, each meant to end where the next begins ending there at the latest as written: its start and length
// as the decimals JavaScript writes, added exactly, never past the next's start (the exact searches read each number as
// written: fugue-contracts.js). A /6 meter's pulses, thirds of a quarter, are no decimals, and their sums had run a note
// 1e-14 past the next's start -- a voice two notes at once, its episodes refused: a day's 2+3+4+3+3+2+2+3+3+2/6 fugue left
// without any.
export function abutting(notes){
  const order=notes.map((note,k)=>k).sort((a,b)=>notes[a].start-notes[b].start),out=notes.map(note=>({...note}));
  for(let i=0;i+1<order.length;i++){
    const note=out[order[i]],next=out[order[i+1]];if(Math.abs(note.start+note.length-next.start)>1e-9)continue;
    let length=next.start-note.start;
    while(length>0&&compare(add(exactOfNumber(note.start),exactOfNumber(length)),exactOfNumber(next.start))>0)length=below(length);
    if(length>0)note.length=length;
  }
  return out;
}
export const FUGUE=Object.freeze({
  // The roles a fugue may develop, the chance it does in one, and its subject's length (bars, at most) and register
  // (where its line is drawn: each section moves it by octaves into its own).
  roles:Object.freeze(['develop','depart']),chance:.5,bars:2,register:Object.freeze({low:60,high:79}),
  // How many subjects its planner draws, each planned as its subject is, to choose among by what each affords its
  // development (fugue-contracts.js subjectAffordance: Astra's CF08): ours.
  subjects:3,
  // The countersubject's share of its groups split in two (the subject's is canon-plan.js's 0.4) and of its leaps.
  counter:Object.freeze({split:.8,leap:.1}),
  // Its countersubject invertible (double counterpoint, as a fugue's countersubject is written to be heard above its
  // subject and below it): as often as `chance`, at an interval drawn as any number of the collection's degrees, up to
  // two periods -- no interval of its own: what each arrangement allows is its rules' (the owner, 3 October 2026: "don't
  // hardcode intervals into the counterpoint rules"). Planned against the subject and against the subject moved by it,
  // which is the countersubject moved below it; then kept only where one countersubject holds in both arrangements --
  // its contract, the rules in force (fugue-contracts.js sharedCountersubject: Astra's CF10/CF24, one source shared by
  // every context, searched) -- each of its notes its planned pitch or the collection's next to it, else
  // plain; and heard so, every other entry's countersubject moved down by it. (It had been kept where each arrangement
  // cost no more than an authored half of a rule beyond the plain one.)
  invertible:Object.freeze({chance:.5}),
  // An episode's fragment: the subject's head, this share of it (its notes that begin within it, one at least); where no
  // walk of the subject's own steps leads its episodes home (fugue-contracts.js episodeLevels), each repetition this many
  // degrees lower.
  // And its free counterpoint in the episodes -- between the exposition's entries and the return -- planned under its
  // counterpoint's rules softened by a leeway drawn once a fugue within `leeway` (its strictness times one less it): the
  // themes and the cadence keep the contract, the episodes play more freely (the owner, 2 October 2026: "In those spaces,
  // the constraints of the themes can be relaxed more than those of the surrounding counterpoint environment; this is
  // part of what makes a fugue a more fully realized genre than a canon").
  episode:Object.freeze({head:.5,descend:1,leeway:Object.freeze([.3,.8])}),
  // A theme's transformations (the owner, 3 October 2026: "There are also transformations of motifs/themes; including
  // not just transposition but augmentation, diminution (rhythm, possibly related to stretching and compressing but
  // definitely not in the rubato layer) and inversion and retrograde"): how often each, a fugue's own share drawn up to
  // `most` (the square of a uniform draw: most fugues transform few, some many), of its entries after the subject and the
  // answer, its episodes' fragments and its return; augmentation and diminution by one of the `ratios` (written note
  // values: one whose notes all land on its meter's pulses and that ends before its voice's next material), inversion
  // about the subject's first pitch by the collection's degrees (as a tonal answer moves) as often as `degrees`, else
  // exactly in cents.
  transform:Object.freeze({most:.6,ratios:Object.freeze([[1,2],[2,3],[3,2],[2,1],[3,1]]),degrees:.7}),
  // A voice's free counterpoint (after its countersubject, wherever it has nothing given until the section ends): planned
  // a subject's length at a time, or rested, as often as its rests' share (drawn once a fugue, the square of a uniform
  // draw up to `rests`: most fugues' voices seldom rest, some often); never a span shorter than `least` quarters.
  free:Object.freeze({rests:.6,least:1}),
  // The sections that can take an entry: those whose players play lines.
  kinds:/^(strings|winds|brass):/,
});
const modulo=(x,n)=>((x%n)+n)%n;
// A section of the form's exposition: `section` the form's ({numerator, denominator, subdivision, groups}), from
// `startBar` to `endBar`; `groups` the sections that may enter (in any order: the draw orders them); `collection` the
// section's pitches (any tuning); random [0, 1); `tonic` its region's tonic (a pitch class), where known: its answer's
// axis. -> {subject, bars, entries: [{group, voice, steps, fromBar, toBar,
// notes: [{bar, pulse, quarters, pitch}], counter: [the countersubject's notes, likewise] (every entry but the last's
// voice), episode: [its episodes' fragments, likewise], final: [its return, likewise: every voice's in a stretto, else
// the first's], free: [its free counterpoint, likewise]}],
// meter (the section's, which its entries are placed in), episodes (how many fragments), returns (whether the subject
// returns), stretto (whether in stretto), free (its voices' rests' share), spacing (quarters between entries), answer
// ({degrees, kind ('tonal' or 'degrees'), asks ('tonal', 'real' or null), reason}: fugue-answer.js), strettoPlan
// ({form ('plain', 'mirror' or 'augmented'), ratio?, spacing, planned, chosen, reason, pairwise, joint}: stretto.js;
// where its room held a stretto), regimes:
// [{kind ('exposition', 'episodes', 'stretto' or 'return'), from, to (quarters from the section's start), strictness,
// beam}]}, or null where fewer than two voices are given, the section holds no more than its subject, or the collection
// has fewer than three pitch classes.
export function fugueExposition({section,startBar,endBar,groups,collection,random,rigor=1,tonic=null,planning={mode:'live'},repetition=null}){
  const classes=new Set((collection??[]).map(p=>Math.round(modulo(Number(p),12)*1e6))).size;
  const length=endBar-startBar,bars=Math.max(1,Math.min(FUGUE.bars,Math.floor(length/2)));
  const quarters=bars*section.numerator*4/section.denominator,total=length*section.numerator*4/section.denominator;
  // (Every voice enters: a subject's length after the one before where they all fit so, else as far apart as they fit.)
  const count=groups.length,spacing=count>1?Math.min(quarters,(total-quarters)/(count-1)):0;
  if(classes<3||count<2||!(spacing>1e-9))return null;
  // (Its counterpoint its own, a blend of the rule sets drawn (counterpoint.js), which its subject is planned under to
  // sound against itself in a stretto -- each voice half a subject after the last, every other the answer -- and its
  // countersubject against it.)
  const counterpoint=drawnRules(random,{rigor,voices:count,classes}),[loose,looser]=FUGUE.episode.leeway,leeway=loose+(looser-loose)*random(),episodeRules=blendRules(counterpoint.weights,counterpoint.strictness*(1-leeway));
  // (Its answer's degrees: one its rules count perfect in this collection, drawn.)
  const answers=perfectDegrees(collection),answer=answers[Math.floor(random()*answers.length)]??1;
  // (Its transformations' shares, drawn first, and its stretto's form among them: its every other entry inverted (a
  // mirror stretto), augmented by a whole ratio (a canon by augmentation), or the answer -- as often as its shares of
  // inversion and augmentation; its subject planned against it.)
  const {most,ratios,degrees:byDegrees}=FUGUE.transform,shares={invert:most*random()**2,retrograde:most*random()**2,augment:most*random()**2};
  const wholeRatios=ratios.filter(([p,q])=>p>q&&p%q===0),augmentBy=wholeRatios.length?(([p,q])=>p/q)(wholeRatios[Math.floor(random()*wholeRatios.length)]):null;
  const strettoForm=random()<shares.invert?'mirror':augmentBy&&random()<shares.augment?'augmented':'plain';
  // (Only the voices of its stretto that sound with the subject's first statement: the first two, half a subject apart.)
  const strettoVoices=Array.from({length:Math.min(count,2)},(_,k)=>({delay:k*quarters/2,...(k%2?strettoForm==='mirror'?{invert:true}:strettoForm==='augmented'?{ratio:augmentBy}:{steps:answer}:{})}));
  // (In a cascade -- its entries closer together than its subject is long -- the entries that overlap its first statement
  // as they will enter, each `spacing` after the last, every other the answer, as many as a line is heard against
  // (COUNTERPOINT.heard): those its subject is planned against, where its stretto's are not the ones heard first.)
  const cascade=spacing<quarters-1e-9?Array.from({length:Math.min(count,1+COUNTERPOINT.heard)},(_,k)=>({delay:k*spacing,...(k%2?{steps:answer}:{})})).filter(voice=>voice.delay<quarters-1e-9):null;
  // (Its tonal practice, where its tonic is known, as often as its rules weigh the sets that keep it (Fux's and Bach's):
  // its subject begun and ended on its tonic or its dominant, its answer tonal where the subject's head reaches the
  // dominant -- Gedalge 1901, Mann 1958: fugue-answer.js.)
  const practice=Number.isFinite(tonic)&&random()<(counterpoint.weights.strict??0)+(counterpoint.weights.tonal??0);
  const axis=practice?[tonic,stepInCollection(tonic,answer,collection)]:null;
  let subject;try{subject=plannedSubject({collection,register:FUGUE.register,groups:section.groups,numerator:section.numerator,denominator:section.denominator,bars,random,voices:cascade??strettoVoices,rules:counterpoint.rules,axis})}catch{return null}
  // (Its subject chosen among several its planner draws, each planned as the first -- the others' draws their own, forked
  // from the first's notes so its other choices are drawn as before -- by what each affords its development: every form of
  // stretto this fugue may take (its answer, its inversion, its augmentation, its cascade, each at the delay it would
  // enter at) audited under its contract, and each subject's variety; of those no other surely betters, the first drawn
  // (Astra's CF08: fugue-contracts.js subjectAffordance). Where its search ends without an answer, the first.)
  const forms=[{id:'answer',delay:quarters/2,steps:answer},{id:'mirror',delay:quarters/2,invert:true},
    ...(augmentBy?[{id:'augmented',delay:quarters/2,ratio:augmentBy}]:[]),...(cascade?[{id:'cascade',delay:spacing,steps:answer}]:[])];
  const others=[];for(let k=1;k<FUGUE.subjects;k++){try{others.push(plannedSubject({collection,register:FUGUE.register,groups:section.groups,numerator:section.numerator,denominator:section.denominator,bars,
    random:forkedSource(`${k}:${subject.map(note=>`${note.start}:${note.pitch}`).join(',')}`),voices:cascade??strettoVoices,rules:counterpoint.rules,axis}))}catch{}}
  // (Whether its countersubject is invertible, and its rhythm, drawn before its subject is chosen: the joint search
  // below needs both.)
  // (Its interval drawn among those its register holds: a countersubject heard with its answer moved up by the answer's
  // degrees and, inverted, down by this, needs both within its register's degrees -- drawn past them, 9 down and 3 up in
  // a register of twelve pitches, every joint search was unsatisfiable before it began.)
  const reach=Math.min(2*classes,ladderOf(collection,FUGUE.register).length-1-Math.max(0,answer));
  let invertBy=random()<FUGUE.invertible.chance&&reach>=1?1+Math.floor(random()*reach):0;
  let counterRhythm=null;try{counterRhythm=subjectFrom({collection,register:FUGUE.register,groups:section.groups,denominator:section.denominator,bars,random,...FUGUE.counter}).map(({start,length})=>({start,length}))}catch{counterRhythm=null}
  // (Its subject and countersubject found together, as far as its planning affords (Astra's joint search: joint-fugue-
  // theme.js, IF-002): one pair witnessing every occurrence planned before either is known -- its first entry and the
  // answer after it, its stretto in its form at half a subject, and, where its entries follow each other a subject apart
  // or more, its countersubject against the entry after its own as each is placed (moved with it by the answer's
  // degrees; invertible, below the subject by its interval in every other) -- the subjects drawn only its order of
  // values, their rhythm its subject's; the pair it finds is the pair played. Its later entries' transformations, drawn
  // after its subject, are not among them. Where it finds none within its budget, said, as before: the subject chosen
  // among those drawn and its countersubject planned after it.)
  // (Its listeners' tolerance of repetition (repetition.js: its conductor's, else its own), its seconds at the section's
  // tempo where it is known, a constraint of the search as it chooses: a joint search feasible for its counterpoint
  // alone had found Op. 3.28 a countersubject of one pitch struck nineteen times.)
  const tempo=Number(section.tempo?.targetBpm),quarter=tempo>0?(Number(section.denominator)||4)/4*60/tempo:null,tolerance=repetitionOf(repetition);
  const repeats=notes=>repetitionCost((notes??[]).map(note=>({at:Number(note.start)*(quarter??1),pitch:Number(note.pitch),seconds:Number(note.length)*(quarter??1)})),quarter?tolerance:{...tolerance,seconds:Infinity,gap:Infinity}).cost>0;
  const countering=spacing>=quarters-1e-9&&counterRhythm?.length>=2,gap=Math.max(0,spacing-quarters);
  // (Its times asked of the search in the meter's own note, each a whole count of them, its answer read back in quarters
  // as its subject's are written (canon-plan.js subjectFrom): the search reads every number exactly as written, and in
  // quarters a meter of thirds -- 2+3+2+2+1+3+2/3, 26 October's test meters -- has onsets no Number spells, a note's
  // start and length overrunning the next's by 2e-16, "not exactly monophonic". Where any of them lies off the note's
  // sixty-fourths, all asked in quarters, as before.)
  const lines=[subject,...others,...(countering?[counterRhythm]:[])],noted=x=>{const v=x*section.denominator/4,on=Math.round(v*64)/64;return Math.abs(on-v)<1e-9?on:null};
  const inNote=[spacing,gap,quarters/2,...lines.flatMap(line=>line.flatMap(note=>[note.start,note.length]))].every(x=>noted(x)!==null);
  const ask=inNote?noted:x=>x,read=inNote?x=>x*4/section.denominator:x=>x;
  const rhythmAsked=line=>line.map(({start,length})=>({start:ask(start),length:ask(length)})),inQuarters=line=>line.map(note=>({...note,start:read(note.start),length:read(note.length)}));
  const strongAt=strongBeats(section);
  const counterPlacements=countering?[{id:'after-subject',subject:{voice:'entering',answer:true,delay:ask(gap)},countersubject:{voice:'continuing',steps:answer}},
    ...(count>2?[{id:'after-answer',subject:{voice:'entering',delay:ask(gap)},countersubject:{voice:'continuing',...(invertBy?{steps:-invertBy}:{})}}]:[])]:[];
  const requestFor=lead=>({phase:'preperformance',complete:true,collection,register:[FUGUE.register.low,FUGUE.register.high],meter:{numerator:section.numerator,denominator:section.denominator,groups:section.groups??[section.numerator]},
    subjectRhythm:rhythmAsked(lead),counterRhythm:rhythmAsked(countering?counterRhythm:lead),rules:counterpoint.rules,strong:t=>strongAt(read(t)),
    // (Its answer as its planner asks one: tonal where its practice is and its subject's head asks it, else by degrees.)
    answer:practice?{policy:'tonal-when-asked',steps:answer,tonic}:{policy:'degrees',steps:answer},
    requirements:[{id:'exposition',kind:'entries',requireOverlap:spacing<quarters-1e-9,entries:[{source:'S',voice:'first'},{source:'S',voice:'second',delay:ask(spacing),answer:true}]},
      {id:'stretto',kind:'stretto',offsets:[ask(quarters/2)],entries:[{source:'S',voice:'leader'},{source:'S',voice:'follower',...(strettoForm==='mirror'?{invert:'degrees'}:strettoForm==='augmented'?{ratio:augmentBy}:{steps:answer})}]},
      ...(counterPlacements.length?[{id:'countersubject',kind:'exchange',placements:counterPlacements}]:[])],
    hints:{S:[lead,...others].map(line=>line.map(note=>({...note,start:ask(note.start),length:ask(note.length)})))},budget:planning,
    accepts:(S,C)=>!repeats(inQuarters(S))&&!repeats(inQuarters(C))});
  // (None where its entries overlap: no countersubject to find with its subject.)
  let joint=null;if(countering)try{joint=jointFugueTheme(requestFor(subject))}catch(error){joint={status:'UNKNOWN',reason:error.message}}
  const kept=joint?.status==='SAT';
  if(kept)joint={...joint,subject:inQuarters(joint.subject),countersubject:inQuarters(joint.countersubject)};
  // (Where it found none, why: the pairs its listeners' tolerance passed over said, where there were any.)
  const passedOver=!kept&&joint?.declined>0?`${joint.declined} pairs found repeat past its listeners' tolerance${joint?.reason?`; ${joint.reason}`:''}`:null;
  const jointSaid=!countering?{status:'none',reason:'its entries overlap: no countersubject to find with its subject'}
    :{status:joint?.status??'UNKNOWN',...(kept?{occurrences:joint.witnesses.occurrences.map(o=>o.id)}:{reason:passedOver??joint?.reason??null})};
  const afforded=!kept&&others.length?subjectAffordance({subjects:[subject,...others],conditions:forms,collection,rules:counterpoint.rules,strong:strongBeats(section),budget:cadenceBudget()}):null;
  if(kept)subject=joint.subject;else if(afforded?.status==='PASS')subject=[subject,...others][afforded.index];
  // (Its answer as the subject asks it (fugue-answer.js; Astra's tracker CF09), where its tonic is known: in its tonal
  // practice, tonal where its head reaches the dominant, by the collection's degrees -- its head's dominant answered by
  // the tonic above, the rest as many degrees up, the harmony planned for the section kept; else by degrees throughout.
  // An answer exact in cents, in the dominant's region, waits for a harmony that follows it there.)
  const from=Number.isFinite(tonic)?tonic:subject[0].pitch,asked=fugueAnswers(subject,{interval:stepInCollection(from,answer,collection)-from,steps:answer,collection,tonic:Number.isFinite(tonic)?tonic:null});
  const tonalAnswer=practice&&asked.asks==='tonal'?answerLine(subject,{steps:answer,collection,tonic,tonal:true}):null;
  // (The order of entry drawn; each a subject's length after the one before, where all fit so; every other the answer.)
  const pool=[...groups],order=[];while(order.length<count)order.push(pool.splice(Math.floor(random()*pool.length),1)[0]);
  const voices=order.map((group,k)=>({part:group,delay:k*spacing,...(k%2?{steps:answer}:{})}));
  const placed=canonParts({subject,voices,startBar,endBar,collection,
    units:[{startBar,endBar,numerator:section.numerator,denominator:section.denominator,subdivision:section.subdivision}]});
  const meter={numerator:section.numerator,denominator:section.denominator,subdivision:section.subdivision??bandMeter().subdivision};
  // (The countersubject, drawn after the subject from the same source, each voice's against the entry after its own --
  // where entries follow each other a subject apart, which it is planned against; overlapping entries have none.
  // Invertible as drawn: planned against the subject moved by its interval too.)
  // (Found with its subject, its countersubject as found.)
  let counter=null,countersubjectContract=null,countersubjectRepair=null;
  if(kept&&countering){counter=joint.countersubject;countersubjectContract={status:'SAT',joint:true}}
  else try{const rhythm=counterRhythm??subjectFrom({collection,register:FUGUE.register,groups:section.groups,denominator:section.denominator,bars,random,...FUGUE.counter});
    const plan=against=>counterLine({against,rhythm:rhythm.map(({start,length})=>({start,length})),steps:ladderOf(collection,FUGUE.register),rules:counterpoint.rules,strong:strongBeats(section),random});
    const other=invertBy?subject.map(note=>({...note,pitch:stepInCollection(note.pitch,invertBy,collection)})):null;
    const plain=plan([subject]),both=other?plan([subject,other]):null;
    const shared=both?sharedCountersubject({subject,counter:both.line,invertBy,collection,rules:counterpoint.rules,strong:strongBeats(section),register:FUGUE.register,budget:cadenceBudget()}):null;
    if(shared?.status==='SAT'){counter=shared.line;countersubjectContract={status:'SAT',changed:shared.changed,model:shared.modelHash}}
    else{
      // (Plain: held to its contract against its subject, its fewest notes repaired where it breaks it, its head kept --
      // Astra's CF20, fugue-contracts.js repairedCountersubject -- else as planned, the decision said.)
      if(shared)countersubjectContract={status:shared.status,reason:shared.reason??null};invertBy=0;
      const held=repairedCountersubject({subject,counter:plain.line,collection,rules:counterpoint.rules,strong:strongBeats(section),register:FUGUE.register,head:FUGUE.episode.head,budget:cadenceBudget()});
      counter=held.line;countersubjectRepair={status:held.status,changed:held.changed??0,...(held.reason?{reason:held.reason}:{})};
    }}catch{counter=null;invertBy=0}
  const countered=counter&&spacing>=quarters-1e-9?counter:null;
  // (Each transformation drawn as its shares have it: an inversion, a retrograde, an augmentation or diminution that
  // lands on its pulses and ends by `until`.)
  const pulse=4/((section.subdivision??bandMeter().subdivision)*section.denominator),onPulse=x=>Math.abs(x/pulse-Math.round(x/pulse))<1e-6;
  const transformOf=(line,delay,until=Infinity)=>{
    const t={},origin=line[0].start,end=Math.max(...line.map(note=>note.start+note.length));
    if(random()<shares.invert)t.invert=random()<byDegrees?'degrees':'cents';
    if(random()<shares.retrograde)t.retrograde=true;
    if(random()<shares.augment){const fit=ratios.filter(([p,q])=>line.every(note=>onPulse((note.start-origin)*p/q)&&onPulse(note.length*p/q))&&delay+(end-origin)*p/q<=Math.min(until,total)+1e-9);
      if(fit.length){const [p,q]=fit[Math.floor(random()*fit.length)];t.augment=`${p}/${q}`}}
    return t;
  };
  const transformed=(line,t)=>{let out=line;
    if(t.invert)out=invertedLine(out,{axis:subject[0].pitch,collection,degrees:t.invert==='degrees'});
    if(t.retrograde)out=retrogradeLine(out);
    if(t.augment){const [p,q]=t.augment.split('/').map(Number);out=augmentedLine(out,p/q)}
    return out;
  };
  const said=t=>Object.keys(t).length?t:null;
  const meterAt=meterOfBar([{startBar,endBar,...meter}],meter);
  // (A line moved by a delay: each time settled to the decimal its sums are made of, where floating point has left it
  // within a few of its last places of one -- 2 x 20.8 + 20.8 is 62.4, where it had been 62.400000000000006, and the
  // exact searches, which read each number exactly as written (fugue-contracts.js, OA1), had found a voice's notes
  // overlapping by 1e-14: a day's 28/10 fugue left without episodes. A time no such decimal is near (a cascade's
  // spacing, 112/199 of a quarter) is left as it is. What is searched is what is placed and played.)
  const moved=(line,{delay,steps})=>abutting(line.map(note=>({pitch:steps?stepInCollection(note.pitch,steps,collection):note.pitch,start:settled(note.start+delay),length:settled(note.length)})));
  const place=(line,{delay,steps})=>line.map(note=>({at:placeQuarters(settled(note.start+delay),{startBar,endBar,meterAt}),note})).filter(({at})=>at)
    .map(({at,note})=>({bar:at.bar,pulse:at.pulse,quarters:+note.length.toFixed(6),pitch:steps?stepInCollection(note.pitch,steps,collection):note.pitch}));
  // (The episodes after the exposition: the subject's head, a degree lower each time, passed from voice to voice in the
  // order they entered; the end of the section kept for its return where the episodes have room for two fragments
  // before it: a stretto's length where that fits, else the subject's.)
  const exposed=(count-1)*spacing+quarters;
  const head=subject.filter((note,i)=>i===0||note.start<quarters*FUGUE.episode.head-1e-9),headLength=Math.max(...head.map(note=>note.start+note.length));
  // (Its stretto where its room holds one at the spacing its subject was planned for, its entries checked together
  // (stretto.js; Astra's tracker CF15): that spacing kept where all its entries keep its counterpoint together, a closer
  // one on its meter's felt beats where no costlier, a wider one that holds and fits, else none -- the subject then
  // returning once.)
  // (Its stretto's entries in its form: the subject, then the answer, its inversion about its first pitch by the
  // collection's degrees, or its augmentation; and how long the stretto lasts at a spacing.)
  const strettoEntry=k=>k%2===0?subject:strettoForm==='mirror'?invertedLine(subject,{axis:subject[0].pitch,collection,degrees:true})
    :strettoForm==='augmented'?augmentedLine(subject,augmentBy):subject.map(note=>({...note,pitch:stepInCollection(note.pitch,answer,collection)}));
  const lengthOf=k=>k%2&&strettoForm==='augmented'?quarters*augmentBy:quarters,span=s=>Math.max(...[count-1,count-2].filter(k=>k>=0).map(k=>k*s+lengthOf(k)));
  const planned=quarters/2,room=total-exposed-2*headLength,barQuarters=section.numerator*4/section.denominator;
  const feltSpacings=[];for(let bar=0;bar*barQuarters<quarters;bar++){let at=bar*barQuarters;for(const g of section.groups??[section.numerator]){if(at>0&&at<quarters)feltSpacings.push(at);at+=g*4/section.denominator}}
  const widest=Math.max(planned,...feltSpacings.filter(s=>span(s)<=room+1e-9));
  const strettoChoice=count>=2&&room>=span(planned)-1e-9?strettoPlan({entryOf:strettoEntry,count,rules:counterpoint.rules,strong:strongBeats(section),spacings:feltSpacings,planned,widest}):null;
  const strettoSpacing=strettoChoice?.spacing??null,stretto=strettoSpacing!=null,strettoLength=stretto?span(strettoSpacing):0;
  const returns=stretto||total-exposed>=quarters+2*headLength-1e-9,episodesEnd=stretto?total-strettoLength:returns?total-quarters:total;
  // (Each fragment inverted or turned back as the fugue's shares draw -- by the collection's degrees, as its sequence
  // moves; never augmented: the sequence keeps its pace.)
  // (Each fragment's transformation drawn once, the episodes built with them.)
  const slots=[];for(let at=exposed;at+headLength<=episodesEnd+1e-9;at+=headLength){const {augment,...drawn}=transformOf(head,at,at+headLength);slots.push({at,t:drawn.invert?{...drawn,invert:'degrees'}:drawn})}
  // (Their levels a walk by the subject's own steps from the last entry's level, arriving at the subject's own as its
  // return enters and nowhere sooner (Astra's CF18/EC13: fugue-contracts.js episodeLevels), its draws forked from the
  // subject's notes; where none arrives, each a degree lower than the last, as before.)
  const levels=slots.length?episodeLevels({subject,collection,start:placed[count-1]?.steps??0,fragments:slots.length,random:forkedSource(`episodes:${subject.map(note=>`${note.start}:${note.pitch}`).join(',')}`)}):null;
  // (`before`, where known: each voice's notes before its episodes, its fragments each in the octave nearest the note
  // its voice last played -- the sequence's degrees kept, its voice not leaping an octave into it.)
  const episodesOf=(before=null)=>{const episodes=new Map(order.map(group=>[group,[]])),fragmented=order.map(()=>[]);let turned=0;
    slots.forEach(({at,t},k)=>{const fragment=transformed(head,t),steps=levels?levels[k]:-FUGUE.episode.descend*(k+1);if(said(t))turned++;
      let notes=moved(fragment,{delay:at,steps});const v=k%count,last=[...(before?.[v]??[]),...fragmented[v]].filter(note=>note.start<at-1e-9).sort((a,b)=>a.start-b.start).at(-1);
      const octave=last?12*Math.round((last.pitch-notes[0].pitch)/12):0;if(octave)notes=notes.map(note=>({...note,pitch:note.pitch+octave}));
      episodes.get(order[v]).push(...notes.map(note=>({at:placeQuarters(note.start,{startBar,endBar,meterAt}),note})).filter(({at})=>at).map(({at,note})=>({bar:at.bar,pulse:at.pulse,quarters:+note.length.toFixed(6),pitch:note.pitch})));
      fragmented[v].push(...notes)});
    return {episodes,fragmented,turned,fragments:slots.length};
  };
  let {episodes,fragmented,turned,fragments}=episodesOf();
  // (Its entries after the subject and the answer, each transformed as drawn -- one augmented ending before its voice's
  // next material, its countersubject then left out; and each voice's return.)
  const nextGiven=k=>Math.min(fragmented[k][0]?.start??Infinity,stretto?total-strettoLength+k*strettoSpacing:returns&&k===0?total-quarters:Infinity);
  const entryT=order.map((_,k)=>k<2?{}:transformOf(subject,k*spacing,nextGiven(k)));
  // (A stretto played in its form, as checked; a single return transformed as drawn.)
  const returnStart=k=>stretto?total-strettoLength+k*strettoSpacing:returns&&k===0?total-quarters:null;
  const returnT=order.map((_,k)=>returnStart(k)==null||stretto?{}:transformOf(subject,returnStart(k),total));
  const ratioOf=t=>{const [p,q=1]=String(t.augment??'1').split('/').map(Number);return p/q},lengthened=k=>ratioOf(entryT[k])>1;
  // (Each countersubject moved as the entry it accompanies is; an invertible one, every other, moved down by its
  // interval too: heard on the subject's other side.)
  const counterSteps=k=>(placed[k+1]?.steps??0)-(invertBy&&k%2?invertBy:0);
  const entryLine=k=>transformed(subject,entryT[k]),returnLine=k=>transformed(subject,returnT[k]);
  // (An untransformed answer the tonal one, where drawn: its pitches its own, moved no further.)
  const tonalAt=k=>tonalAnswer&&k%2===1&&!said(entryT[k]);
  // (Each voice's entry, and its countersubject after it -- moved as its entry is, and by the inversion's interval on the
  // subject's other side, then into the octave nearest the note its entry ends on: its voice going on from its entry,
  // not leaping one or two octaves into its countersubject, which the contract reads by the octave all the same.)
  const entryNotes=k=>tonalAt(k)?moved(tonalAnswer,{delay:k*spacing,steps:0}):moved(entryLine(k),{delay:k*spacing,steps:placed[k].steps});
  // (Augmented or diminished as the entry it accompanies is, its every vertical with the subject kept as it was checked,
  // and left out where its notes would not then land on the pulses: kept whole against a diminished entry, it had run a
  // bar past it into the episodes, out of the counterpoint it was planned in.)
  const counterNotes=k=>{if(!(countered&&k<count-1&&!lengthened(k)))return [];
    const ratio=ratioOf(entryT[k+1]),origin=countered[0].start,paced=ratio===1?countered:augmentedLine(countered,ratio);
    if(ratio!==1&&!paced.every(note=>onPulse(note.start-origin)&&onPulse(note.length)))return [];
    const line=moved(paced,{delay:k*spacing+quarters,steps:counterSteps(k)}),last=entryNotes(k).at(-1),octave=last?12*Math.round((last.pitch-line[0].pitch)/12):0;
    return octave?line.map(note=>({...note,pitch:note.pitch+octave})):line};
  const placedNotes=notes=>notes.map(note=>({at:placeQuarters(note.start,{startBar,endBar,meterAt}),note})).filter(({at})=>at).map(({at,note})=>({bar:at.bar,pulse:at.pulse,quarters:+note.length.toFixed(6),pitch:note.pitch}));
  // (Its episodes again with every voice's entry and countersubject before them known: each fragment in the octave
  // nearest the note its voice last played.)
  const exposition=order.map((group,k)=>({voice:group,notes:abutting([...entryNotes(k),...counterNotes(k)])}));
  ({episodes,fragmented,turned,fragments}=episodesOf(exposition.map(entry=>entry.notes)));
  // (Each voice's given lines in quarters from the section's start -- its entry, its countersubject, its fragments, its
  // return -- and then its free counterpoint: wherever it has nothing given after its countersubject, a rhythm drawn as
  // the countersubject's for each subject's length of the section (its bars' strong beats kept), its pitches planned
  // against every other voice sounding then, given or free (counterLine, under the fugue's rules), or a rest.)
  const given=order.map((group,k)=>[...(tonalAt(k)?moved(tonalAnswer,{delay:k*spacing,steps:0}):moved(entryLine(k),{delay:k*spacing,steps:placed[k].steps})),
    ...counterNotes(k),...fragmented[k],
    ...(stretto?moved(strettoEntry(k),{delay:total-strettoLength+k*strettoSpacing,steps:0}):returns&&k===0?moved(returnLine(k),{delay:total-quarters,steps:0}):[])].sort((a,b)=>a.start-b.start)).map(abutting);
  // (Its rules' timeline: the exposition's and the return's its counterpoint's, the episodes' softened; each span's beam
  // as its rules bind.)
  const regimes=[{kind:'exposition',from:0,to:exposed,strictness:counterpoint.strictness,rules:counterpoint.rules},
    {kind:'episodes',from:exposed,to:episodesEnd,strictness:+(counterpoint.strictness*(1-leeway)).toFixed(3),rules:episodeRules},
    {kind:stretto?'stretto':'return',from:episodesEnd,to:total,strictness:counterpoint.strictness,rules:counterpoint.rules}]
    .filter(span=>span.to>span.from+1e-9).map(span=>({...span,beam:Math.max(1,Math.round(COUNTERPOINT.beam*span.strictness))}));
  const regimeAt=t=>regimes.find(span=>t>=span.from-1e-9&&t<span.to-1e-9)??regimes.at(-1);
  const rests=FUGUE.free.rests*random()**2,free=order.map(()=>[]),steps=ladderOf(collection,FUGUE.register),strong=strongBeats(section);
  // (Each voice's lines as the others hear them, sorted once and again only as its free counterpoint grows.)
  const heard=[],lineOf=j=>heard[j]?.n===free[j].length?heard[j].line:(heard[j]={n:free[j].length,line:[...given[j],...free[j]].sort((a,b)=>a.start-b.start)}).line;
  // (From where its entry and its countersubject end as placed: a diminished entry, and the countersubject paced to one,
  // ends before a subject's length has passed, and its voice had waited out the rest of that length before playing on.)
  for(let k=0;k<count;k++){
    const gaps=[];let t=Math.max(...[...entryNotes(k),...counterNotes(k)].map(note=>note.start+note.length));
    for(const note of given[k].filter(note=>note.start+note.length>t+1e-9)){if(note.start>t+1e-9)gaps.push([t,note.start]);t=Math.max(t,note.start+note.length)}
    if(total>t+1e-9)gaps.push([t,total]);
    for(const [from,to] of gaps)for(let window=Math.floor(from/quarters+1e-9)*quarters;window<to-1e-9;window+=quarters){
      const low=Math.max(from,window),high=Math.min(to,window+quarters);if(high-low<FUGUE.free.least-1e-9||random()<rests)continue;
      let rhythm;try{rhythm=subjectFrom({collection,register:FUGUE.register,groups:section.groups,denominator:section.denominator,bars,random,...FUGUE.counter})}catch{continue}
      rhythm=rhythm.map(note=>({start:window+note.start,length:note.length})).filter(note=>note.start>=low-1e-9&&note.start<high-1e-9).map(note=>({start:note.start,length:Math.min(note.length,high-note.start)}));
      if(!rhythm.length)continue;
      const against=order.map((_,j)=>j===k?null:lineOf(j)).filter(Boolean),regime=regimeAt(window);
      // (Where its voice's given material begins as this ends, the move into it weighed under that span's rules.)
      const entering=high>=to-1e-9?given[k].find(note=>Math.abs(note.start-to)<1e-9):null;
      const toward=entering?{pitch:entering.pitch,start:entering.start,rules:regimeAt(entering.start).rules}:null;
      free[k].push(...counterLine({against,rhythm,steps,rules:regime.rules,strong,random,beam:regime.beam,toward}).line);
    }
  }
  return {subject,joint:jointSaid,...(afforded?.status==='PASS'?{subjects:{drawn:1+others.length,chosen:afforded.index,retained:afforded.retained,coverage:afforded.coverage,complete:afforded.complete,forms:forms.map(form=>form.id)}}:{}),bars,meter,episodes:fragments,...(levels&&fragments?{episodeLevels:levels}:{}),returns,stretto,free:+rests.toFixed(3),spacing:+spacing.toFixed(6),regimes:regimes.map(({rules,...span})=>({...span,from:+span.from.toFixed(6),to:+span.to.toFixed(6)})),counterpoint:{weights:Object.fromEntries(Object.entries(counterpoint.weights).map(([k,v])=>[k,+v.toFixed(3)])),strictness:counterpoint.strictness,episodes:+(counterpoint.strictness*(1-leeway)).toFixed(3)},
    ...(countersubjectRepair||countersubjectContract&&!invertBy?{countersubject:{...(countersubjectContract&&!invertBy?{invertibility:countersubjectContract}:{}),...(countersubjectRepair?{repair:countersubjectRepair}:{})}}:{}),
    ...(invertBy?{invertible:{degrees:invertBy,...(countersubjectContract?{contract:countersubjectContract}:{})}}:{}),answer:{degrees:answer,kind:tonalAnswer?'tonal':'degrees',asks:asked.asks,reason:asked.reason},
    ...(strettoChoice?{strettoPlan:{form:strettoForm,...(strettoForm==='augmented'?{ratio:augmentBy}:{}),spacing:strettoChoice.spacing,planned,chosen:strettoChoice.chosen,reason:strettoChoice.reason,pairwise:strettoChoice.pairwise.length,joint:strettoChoice.joint.length}}:{}),
    transforms:{shares:Object.fromEntries(Object.entries(shares).map(([k,v])=>[k,+v.toFixed(3)])),entries:entryT.filter(said).length,fragments:turned,returns:returnT.filter(said).length},
    entries:placed.map((voice,k)=>{
      // (A transformed entry placed as transformed: its notes, its bars.)
      const notes=tonalAt(k)?place(tonalAnswer,{delay:k*spacing,steps:0}):said(entryT[k])?place(entryLine(k),{delay:k*spacing,steps:voice.steps}):voice.notes.map(({bar,pulse,quarters,pitch})=>({bar,pulse,quarters,pitch}));
      return {group:voice.part,voice:k,steps:voice.steps,fromBar:notes[0]?.bar??voice.fromBar,toBar:(notes.at(-1)?.bar??voice.toBar-1)+1,notes,
        ...(said(entryT[k])?{transform:entryT[k]}:{}),...(said(returnT[k])?{returnTransform:returnT[k]}:{}),
        counter:placedNotes(counterNotes(k)),
        episode:episodes.get(voice.part)??[],
        final:stretto?place(strettoEntry(k),{delay:total-strettoLength+k*strettoSpacing,steps:0}):returns&&k===0?place(returnLine(k),{delay:total-quarters,steps:0}):[],
        free:place(free[k],{delay:0,steps:0})};
    })};
}
// An entry's notes, its countersubject's, its episodes', its return's and its free counterpoint's in a phrase from `bar`,
// `bars` long, as a line's given notes: each its quarters from the phrase's downbeat (`meter`, the exposition's: a bar of
// n/d is 4n/d quarters, a quarter subdivision x d / 4 pulses) and its length.
export function entryInPhrase(entry,{bar,bars,meter}){
  const perBar=meter.numerator*4/meter.denominator,perQuarter=meter.subdivision*meter.denominator/4;
  return [...entry.notes,...(entry.counter??[]),...(entry.episode??[]),...(entry.final??[]),...(entry.free??[])].sort((a,b)=>a.bar-b.bar||a.pulse-b.pulse).filter(note=>note.bar>=bar&&note.bar<bar+bars).map(note=>({at:+((note.bar-bar)*perBar+note.pulse/perQuarter).toFixed(6),quarters:note.quarters,pitch:note.pitch}));
}
