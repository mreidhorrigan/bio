// CFM-007 / DC07-08: exact promises about a declared Cartesian uncertainty box.
// This does not acquire physical bounds, measure sound, calibrate clocks, or schedule an event.
// All timing values share the explicit clock/unit. Coefficients are dimensionless. null means missing evidence.
import {dataArray,dataRecord} from './contract-data.js';
import {Refused,Budget,EXACT_LIMITS,ZERO,add,sub,mul,abs,compare,exactOf,exactText,
  fraction,pythonJson,sha256} from '../bounded-exact.js';

export const GESTURE_BOUNDS_LIMITS=Object.freeze({roles:32,components:32,string:256,text:262144,
  hashChars:524288,inputBits:256,workBits:8192,defaultWork:100000,maxWork:500000});
const freeze=Object.freeze,boundary=1n<<256n;
const fail=(message,kind='invalid-input')=>{throw new Refused(message,{kind})};
const scopeFor=kind=>kind==='anchor'?'declared-box-robust-common-anchor':'declared-box-residual-spread';
function fields(value,keys){
  if(!dataRecord(value)||Object.keys(value).length!==keys.length||keys.some(key=>!Object.hasOwn(value,key)))
    fail('Unexpected or missing gesture-bound fields');
  return value;
}
function text(value,state,limit=GESTURE_BOUNDS_LIMITS.string){
  if(typeof value!=='string'||value.length<1||value.length>limit)fail('Invalid bounded gesture text');
  state.chars+=value.length;if(state.chars>GESTURE_BOUNDS_LIMITS.text)fail('Gesture text budget','work-budget');
  return value;
}
function revision(value){
  if(!Number.isSafeInteger(value)||value<0)fail('Revision must be a nonnegative safe integer');
  return value;
}
function integerToken(value){
  if(typeof value==='bigint'){
    if(value<=-boundary||value>=boundary)fail('Raw rational component exceeds 256 bits','arithmetic-budget');
  }else if(!Number.isSafeInteger(value))fail('Use safe integers or exact rational spellings; convert a Number explicitly');
  return value;
}
function readExact(value,state){
  state.budget.charge();let input=value;
  if(typeof value==='string'){
    text(value,state,160);const quotient=value.match(/^([+-]?[0-9]+)\/([0-9]+)$/);
    if(quotient){integerToken(BigInt(quotient[1]));integerToken(BigInt(quotient[2]))}
  }else if(typeof value==='number'||typeof value==='bigint')integerToken(value);
  else if(Array.isArray(value)){
    dataArray(value,2,'Exact rational pair');if(value.length!==2)fail('Exact rational pair needs two components');
    input={n:integerToken(value[0]),d:integerToken(value[1])};
  }else{
    fields(value,['n','d']);input={n:integerToken(value.n),d:integerToken(value.d)};
  }
  const result=exactOf(input);
  if(typeof value!=='string')text(exactText(result),state,160);
  return result;
}
function scalar(value,state,nonnegative=false){
  if(value===null){state.budget.charge();return null}
  const q=readExact(value,state);if(nonnegative&&q.n<0n)fail('An absolute bound or tolerance must be nonnegative');
  return q;
}
const exactOrNull=q=>q===null?null:exactText(q);
const intervalText=({lo,hi})=>freeze({lo:exactOrNull(lo),hi:exactOrNull(hi)});
const math=budget=>({
  add(a,b){budget.charge();return add(a,b)},sub(a,b){budget.charge();return sub(a,b)},
  mul(a,b){budget.charge();return mul(a,b)},abs(a){budget.charge();return abs(a)},
  compare(a,b){budget.charge();return compare(a,b)}
});
function readWindow(value,state){
  fields(value,['lo','hi']);return freeze({lo:scalar(value.lo,state),hi:scalar(value.hi,state)});
}
function normalize(spec,state,kind){
  fields(spec,['id','revision','clockDomain','components','roles',kind==='anchor'?'window':'epsilon']);
  const id=text(spec.id,state),version=revision(spec.revision);
  const clock=fields(spec.clockDomain,['id','revision','unit']);
  const clockDomain=freeze({id:text(clock.id,state),revision:revision(clock.revision),unit:text(clock.unit,state)});
  dataArray(spec.components,GESTURE_BOUNDS_LIMITS.components,'Error components');
  dataArray(spec.roles,GESTURE_BOUNDS_LIMITS.roles,'Gesture roles');
  if(spec.roles.length===0)fail('Declare at least one gesture role');
  const components=[],componentIds=new Set,roles=[],roleIds=new Set;
  for(let k=0;k<spec.components.length;k++){
    state.budget.charge();const row=fields(spec.components[k],['id','revision','unit','kind','bound']);
    const name=text(row.id,state),unit=text(row.unit,state);
    if(componentIds.has(name))fail('Component identities must be unique');componentIds.add(name);
    if(unit!==clockDomain.unit||row.kind!=='absolute-bound')fail('Components require matching units and the absolute-bound kind');
    components.push(freeze({id:name,revision:revision(row.revision),unit,kind:'absolute-bound',bound:scalar(row.bound,state,true)}));
  }
  for(let i=0;i<spec.roles.length;i++){
    state.budget.charge();const row=fields(spec.roles[i],['id','revision','unit','offset','coefficients',kind==='anchor'?'window':'nominal']);
    const name=text(row.id,state),unit=text(row.unit,state);
    if(roleIds.has(name))fail('Role identities must be unique');roleIds.add(name);
    if(unit!==clockDomain.unit)fail('Role unit differs from the common clock unit');
    dataArray(row.coefficients,GESTURE_BOUNDS_LIMITS.components,'Error coefficients');
    if(row.coefficients.length!==components.length)fail('Each role needs one coefficient per declared component');
    const coefficients=[];for(let k=0;k<components.length;k++)coefficients.push(readExact(row.coefficients[k],state));
    const common={id:name,revision:revision(row.revision),unit,offset:scalar(row.offset,state),coefficients:freeze(coefficients)};
    roles.push(freeze(kind==='anchor'?{...common,window:readWindow(row.window,state)}:{...common,nominal:scalar(row.nominal,state)}));
  }
  const common={id,revision:version,clockDomain,components:freeze(components),roles:freeze(roles)};
  const model=freeze(kind==='anchor'?{...common,window:readWindow(spec.window,state)}:{...common,epsilon:scalar(spec.epsilon,state,true)});
  // Only newly owned, ordinary frozen arrays/records reach the serializer. Snapshot strings are JSON-safe.
  const componentSnapshot=freeze(components.map(c=>freeze({...c,bound:exactOrNull(c.bound)})));
  const roleSnapshot=freeze(roles.map(r=>{
    const base={id:r.id,revision:r.revision,unit:r.unit,offset:exactOrNull(r.offset),coefficients:freeze(r.coefficients.map(exactText))};
    return freeze(kind==='anchor'?{...base,window:intervalText(r.window)}:{...base,nominal:exactOrNull(r.nominal)});
  }));
  const snapshotBase={id,revision:version,clockDomain,components:componentSnapshot,roles:roleSnapshot};
  const snapshot=freeze(kind==='anchor'?{...snapshotBase,window:intervalText(model.window)}:{...snapshotBase,epsilon:exactOrNull(model.epsilon)});
  const encoded=pythonJson({operation:kind,snapshot});
  if(encoded.length>GESTURE_BOUNDS_LIMITS.hashChars)fail('Gesture model hash budget','work-budget');
  state.budget.charge(1+roles.length*(components.length+1)+Math.ceil(encoded.length/64));
  state.snapshot=snapshot;state.modelHash=sha256(encoded);
  return model;
}
function run(spec,options,kind,solve){
  const state={chars:0,budget:null,snapshot:null,modelHash:null};
  try{
    if(!dataRecord(options)||Object.keys(options).some(key=>key!=='maxWork'))fail('Only maxWork is a supported option');
    const limit=Object.hasOwn(options,'maxWork')?options.maxWork:EXACT_LIMITS.work;
    if(!Number.isInteger(limit))fail('maxWork must be an explicit integer when supplied');
    state.budget=new Budget(limit);
    state.math=math(state.budget);const model=normalize(spec,state,kind),result=solve(model,state);
    return freeze({...result,scope:scopeFor(kind),modelHash:state.modelHash,snapshot:state.snapshot,workUsed:state.budget.used});
  }catch(error){
    if(!(error instanceof Refused))throw error;
    return freeze({status:'UNKNOWN',scope:scopeFor(kind),reason:freeze({kind:error.kind,message:error.message}),
      modelHash:state.modelHash,snapshot:state.snapshot,workUsed:state.budget?.used??0});
  }
}
const missingScalar=(missing,value,path)=>{if(value===null)missing.push(path)};
function anchor(model,state){
  const {math:m}=state,missing=[],rows=[];let lo=model.window.lo,hi=model.window.hi;
  missingScalar(missing,lo,'window.lo');missingScalar(missing,hi,'window.hi');
  const result=(status,contradiction=null)=>({status,interval:status==='FEASIBLE'?intervalText({lo,hi}):null,
    necessaryInterval:intervalText({lo,hi}),rows:freeze(rows),missing:freeze(missing),contradiction});
  if(lo!==null&&hi!==null&&m.compare(lo,hi)>0)return result('EMPTY',freeze({kind:'global-window'}));
  for(let i=0;i<model.roles.length;i++){
    state.budget.charge();const role=model.roles[i],unknownComponents=[];let radius=ZERO;
    for(let k=0;k<model.components.length;k++){
      state.budget.charge();const a=role.coefficients[k],component=model.components[k];if(a.n===0n)continue;
      if(component.bound===null){unknownComponents.push(component.id);missing.push(`roles[${i}].components[${k}].bound`)}
      else radius=m.add(radius,m.mul(m.abs(a),component.bound));
    }
    const lower=role.window.lo===null?null:m.add(role.window.lo,radius);
    const upper=role.window.hi===null?null:m.sub(role.window.hi,radius);
    const roleLo=lower===null||role.offset===null?null:m.sub(lower,role.offset);
    const roleHi=upper===null||role.offset===null?null:m.sub(upper,role.offset);
    rows.push(freeze({id:role.id,knownRadius:exactText(radius),radius:unknownComponents.length?null:exactText(radius),
      unknownComponents:freeze(unknownComponents),necessaryInterval:intervalText({lo:roleLo,hi:roleHi})}));
    missingScalar(missing,role.window.lo,`roles[${i}].window.lo`);missingScalar(missing,role.window.hi,`roles[${i}].window.hi`);
    missingScalar(missing,role.offset,`roles[${i}].offset`);
    if(lower!==null&&upper!==null&&m.compare(lower,upper)>0)return result('EMPTY',freeze({kind:'role-width',roleId:role.id}));
    if(roleLo!==null&&(lo===null||m.compare(roleLo,lo)>0))lo=roleLo;
    if(roleHi!==null&&(hi===null||m.compare(roleHi,hi)<0))hi=roleHi;
    if(lo!==null&&hi!==null&&m.compare(lo,hi)>0)return result('EMPTY',freeze({kind:'necessary-intersection',throughRoleId:role.id}));
  }
  return result(missing.length?'UNKNOWN':'FEASIBLE');
}
function spread(model,state){
  const {math:m}=state,missing=[],pairs=[],adjusted=[];let maximum=ZERO,knownLower=ZERO,complete=true;
  missingScalar(missing,model.epsilon,'epsilon');
  for(let i=0;i<model.roles.length;i++){
    state.budget.charge();const role=model.roles[i];
    adjusted.push(role.nominal===null||role.offset===null?null:m.sub(role.nominal,role.offset));
  }
  const result=(status,violatingPair=null)=>({status,worstCase:complete?exactText(maximum):null,
    knownLowerBound:exactText(knownLower),pairs:freeze(pairs),missing:freeze(missing),violatingPair});
  for(let i=0;i<model.roles.length;i++)for(let j=i+1;j<model.roles.length;j++){
    state.budget.charge();const unknownComponents=[];let radius=ZERO,pairComplete=adjusted[i]!==null&&adjusted[j]!==null;
    for(let k=0;k<model.components.length;k++){
      state.budget.charge();const difference=m.sub(model.roles[i].coefficients[k],model.roles[j].coefficients[k]);
      if(difference.n===0n)continue;const component=model.components[k];
      if(component.bound===null){pairComplete=false;unknownComponents.push(component.id);missing.push(`pairs[${i},${j}].components[${k}].bound`)}
      else radius=m.add(radius,m.mul(m.abs(difference),component.bound));
    }
    if(adjusted[i]===null)missing.push(`roles[${i}].adjusted-nominal`);
    if(adjusted[j]===null)missing.push(`roles[${j}].adjusted-nominal`);
    const nominal=adjusted[i]===null||adjusted[j]===null?null:m.abs(m.sub(adjusted[i],adjusted[j]));
    const lower=nominal===null?radius:m.add(nominal,radius);
    if(m.compare(lower,knownLower)>0)knownLower=lower;
    if(pairComplete){if(m.compare(lower,maximum)>0)maximum=lower}else complete=false;
    pairs.push(freeze({roles:freeze([model.roles[i].id,model.roles[j].id]),adjustedNominalDifference:exactOrNull(nominal),
      knownRadius:exactText(radius),unknownComponents:freeze(unknownComponents),lowerBound:exactText(lower),
      worstCase:pairComplete?exactText(lower):null}));
    if(model.epsilon!==null&&m.compare(lower,model.epsilon)>0){
      // A decisive pair suffices. Other pairs have not been evaluated, so no global maximum is advertised.
      complete=false;return result('FAIL',freeze([model.roles[i].id,model.roles[j].id]));
    }
  }
  return result(model.epsilon===null||!complete?'UNKNOWN':'PASS');
}

/** Exact closed robust anchor set for every vector in the declared Cartesian uncertainty box.
 * FEASIBLE gives the exact interval. EMPTY has a known contradiction, possibly despite null evidence elsewhere.
 * UNKNOWN can carry a necessaryInterval; its nonemptiness is not a feasibility certificate. */
export function intersectGestureAnchors(spec,options={}){return run(spec,options,'anchor',anchor)}

/** Exact universal residual-spread check after subtracting intended offsets.
 * PASS is sufficient for any smaller physical support; FAIL refutes this full box promise, not measured sound.
 * An unknown component cancels from a pair when its two exact coefficients are equal. */
export function certifyGestureSpread(spec,options={}){return run(spec,options,'spread',spread)}

/** The exact rational represented by a finite binary64 Number, not its shortest decimal spelling.
 * It keeps the ordinary 256-bit input cap. It throws Refused for invalid/out-of-cap values, including subnormals.
 * Call this at the source boundary and retain conversion provenance; it cannot undo prior floating arithmetic. */
export function gestureTimeFromNumber(value){
  if(typeof value!=='number'||!Number.isFinite(value))fail('Binary64 conversion requires a finite Number');
  const buffer=new ArrayBuffer(8),view=new DataView(buffer);view.setFloat64(0,value,false);
  const high=view.getUint32(0,false),low=view.getUint32(4,false),sign=high>>>31;
  const exponent=(high>>>20)&0x7ff,significand=BigInt(high&0xfffff)*(1n<<32n)+BigInt(low);
  let numerator=exponent===0?significand:(1n<<52n)+significand;
  const shift=exponent===0?-1074:exponent-1023-52;let denominator=1n;
  if(numerator===0n)return ZERO;
  if(shift>=0)numerator<<=BigInt(shift);else denominator<<=BigInt(-shift);
  if(sign)numerator=-numerator;
  return exactOf(fraction(numerator,denominator));
}
