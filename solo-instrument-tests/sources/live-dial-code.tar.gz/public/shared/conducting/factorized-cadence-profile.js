// Exact finite unary / explicitly banded pair profiles for offline cadence planning.
// This composes authentic one/two-voice profiles; it does not relabel the global 32-voice compiler.
// Musical coverage is recombined using the ORIGINAL rule contract, not required coverage per factor.
import {Q,Rational,normalizeEvents,CANON_LIMITS} from './canon-core.js';
import {compilePitchOperations} from './pitch-spaces.js';
import {compileCounterpointProfile,decomposeCounterpointProfile,PROFILE_LIMITS} from './counterpoint-profile.js';
import {dataArray,dataRecord} from './contract-data.js';
import {Refused,EXACT_LIMITS,pythonJson,sha256} from '../bounded-exact.js';

export const FACTORIZED_PROFILE_DEFAULTS=Object.freeze({maxVoices:512,maxEvents:65536,maxPairs:4096,maxPairDistance:1,
  maxWork:2000000,maxFactorWork:4096,maxTextChars:2097152});
const brands=new WeakMap,freeze=Object.freeze;
const fail=(message,kind='invalid-input')=>{throw new Refused(message,{kind})};
const reduce=values=>values.includes('FAIL')?'FAIL':values.includes('UNKNOWN')?'UNKNOWN':values.includes('PASS')?'PASS':'N/A';
function fields(value,allowed,required=allowed){
  if(!dataRecord(value)||Object.keys(value).some(k=>!allowed.includes(k))||required.some(k=>!Object.hasOwn(value,k)))fail('Unexpected or missing factorized-profile fields');
}
function count(value){if(!Number.isSafeInteger(value)||value<0)fail('A finite nonnegative safe-integer allowance is required');return value}
class Ledger{
  constructor(limit){this.limit=count(limit);this.used=0}
  charge(n=1){if(!Number.isSafeInteger(n)||n<0)throw new Error('Invalid internal work charge');if(n>this.limit-this.used)fail('Factorized profile work exhausted','work-budget');this.used+=n}
  get remaining(){return this.limit-this.used}
}
function name(value,budget){budget.charge();if(typeof value!=='string'||!value.length||value.length>PROFILE_LIMITS.id)fail('A bounded nonempty profile identity is required');return value}
function clock(value,budget){fields(value,['id','unit','revision']);return freeze({id:name(value.id,budget),unit:name(value.unit,budget),revision:count(value.revision)})}
function boundInteger(value){
  const n=typeof value==='bigint'?value:Number.isSafeInteger(value)?BigInt(value):null;
  if(n===null)fail('Use exact integer/fraction rule bounds');
  const edge=1n<<256n;if(n<=-edge||n>=edge)fail('Raw rule-bound component exceeds 256 bits','arithmetic-budget');return n;
}
function nonnegative(value,budget){
  budget.charge();let n,d=1n;
  if(typeof value==='string'){
    if(!value.length||value.length>160)fail('Rule-bound exact text limit');
    const match=value.match(/^([+-]?[0-9]+)(?:\/([+-]?[0-9]+))?$/);
    if(!match||match[0].length!==value.length)fail('Use integer or n/d text for a rule bound');
    n=boundInteger(BigInt(match[1]));if(match[2]!==undefined)d=boundInteger(BigInt(match[2]));
  }else if(typeof value==='number'||typeof value==='bigint')n=boundInteger(value);
  else{
    if(value&&Object.getPrototypeOf(value)===Rational.prototype){if(Q(value)!==value)fail('Forged exact rule bound')}
    else fields(value,['n','d']);
    n=boundInteger(value.n);d=boundInteger(value.d);
  }
  const q=Q({n,d});if(q.cmp(0)<0)fail('A nonnegative exact bound is required');return String(q);
}
function definitionHash(value,limit,budget){
  const chunks=[];let size=0;
  const append=text=>{if(text.length>limit-size)fail('Factorized profile text allowance exhausted','work-budget');size+=text.length;chunks.push(text)};
  function encode(v){
    budget.charge();if(v===null||typeof v!=='object'){append(pythonJson(v));return}
    if(Array.isArray(v)){append('[');for(let i=0;i<v.length;i++){if(i)append(',');encode(v[i])}append(']');return}
    const keys=Object.keys(v).sort((a,b)=>{budget.charge();return a<b?-1:a>b?1:0});
    append('{');for(let i=0;i<keys.length;i++){if(i)append(',');append(pythonJson(keys[i]));append(':');encode(v[keys[i]])}append('}');
  }
  encode(value);budget.charge(1+Math.ceil(size/64));return sha256(chunks.join(''));
}
const pairKey=(a,b,index)=>`${index.get(a)},${index.get(b)}`;
const edgeKey=(a,b,index)=>{const i=index.get(a),j=index.get(b);return `${Math.min(i,j)},${Math.max(i,j)}`};
const pairRule=rule=>rule.type==='voice-spacing'||rule.type==='parallel-classes';
function limitsOf(options){
  fields(options,Object.keys(FACTORIZED_PROFILE_DEFAULTS),[]);
  const limits={};for(const key of Object.keys(FACTORIZED_PROFILE_DEFAULTS))limits[key]=Object.hasOwn(options,key)?count(options[key]):FACTORIZED_PROFILE_DEFAULTS[key];
  return freeze(limits);
}

/** Same authored profile fields, plus order: a full declared static voice permutation.
 * maxPairDistance is a resource admission bound, never permission to drop an authored pair. */
export function compileFactorizedCadenceProfile(spec,options={}){
  const limits=limitsOf(options),setup=new Ledger(limits.maxWork);setup.charge();
  fields(spec,['id','version','pitchSpace','clockDomain','voices','order','rules']);
  const id=name(spec.id,setup),version=count(spec.version),space=spec.pitchSpace;compilePitchOperations(space,[]);
  const domain=clock(spec.clockDomain,setup),voices=[],voiceIndex=new Map;
  dataArray(spec.voices,limits.maxVoices,'Factorized profile voices');if(!spec.voices.length)fail('At least one profile voice is required');
  for(const raw of spec.voices){const v=name(raw,setup);if(voiceIndex.has(v))fail('Duplicate profile voice');voiceIndex.set(v,voices.length);voices.push(v)}
  dataArray(spec.order,limits.maxVoices,'Declared neighbour order');if(spec.order.length!==voices.length)fail('Order must contain every declared voice once');
  const order=[],orderIndex=new Map;
  for(const raw of spec.order){const v=name(raw,setup);if(!voiceIndex.has(v)||orderIndex.has(v))fail('Order must be a permutation of declared voices');orderIndex.set(v,order.length);order.push(v)}
  dataArray(spec.rules,PROFILE_LIMITS.rules,'Authored factorized rules');if(!spec.rules.length)fail('Named profile predicates are required');
  const rules=[],ids=new Set,pairsByRule=new Map;let pairCount=0,bandwidth=0;
  for(const raw of spec.rules){
    setup.charge();if(!dataRecord(raw))fail('A profile rule must be a data record');
    const ruleId=name(raw.id,setup);if(ruleId.startsWith('$')||ids.has(ruleId))fail('Duplicate or reserved rule identity');ids.add(ruleId);
    if(typeof raw.required!=='boolean')fail('Declare rule applicability requirements');
    const common=['id','type','required'];let rule;
    if(raw.type==='monophony'){fields(raw,common);rule={id:ruleId,type:raw.type,required:raw.required}}
    else if(raw.type==='melodic-bound'){
      fields(raw,[...common,'maxCents']);rule={id:ruleId,type:raw.type,required:raw.required,maxCents:nonnegative(raw.maxCents,setup)};
    }else if(pairRule(raw)){
      const symmetric=raw.type==='parallel-classes';
      fields(raw,[...common,'pair',...(symmetric?['periodCents','classes']:['minCents','maxCents'])]);
      let parameters;
      if(symmetric){
        const periodCents=nonnegative(raw.periodCents,setup),period=Q(periodCents),labels=new Set;
        if(period.cmp(0)<=0)fail('A positive interval period is required');
        dataArray(raw.classes,PROFILE_LIMITS.bands,'Protected interval classes');if(!raw.classes.length)fail('Declare protected interval classes');
        const classes=raw.classes.map(item=>{
          fields(item,['id','center','tolerance']);const id=name(item.id,setup);
          if(labels.has(id))fail('Duplicate interval-class label');labels.add(id);
          const center=nonnegative(item.center,setup),tolerance=nonnegative(item.tolerance,setup);
          if(Q(center).cmp(period)>=0||Q(tolerance).mul(2).cmp(period)>=0)fail('Class centers/tolerances must lie within the period');
          return freeze({id,center,tolerance});
        });parameters={periodCents,classes:freeze(classes)};
      }else{
        const minCents=nonnegative(raw.minCents,setup),maxCents=raw.maxCents===null?null:nonnegative(raw.maxCents,setup);
        if(maxCents!==null&&Q(minCents).cmp(maxCents)>0)fail('Reversed spacing bounds');parameters={minCents,maxCents};
      }
      let supplied;
      if(raw.pair==='all'){
        // Preserve every original pair and the original spacing direction, even when order is reversed.
        if(voices.length-1>limits.maxPairDistance)fail('All-pairs scope exceeds the declared pair-distance allowance','out-of-model');
        supplied=[];
        for(let i=0;i<voices.length;i++)for(let j=i+1;j<voices.length;j++){
          setup.charge();if(supplied.length>=limits.maxPairs-pairCount)fail('Expanded pair allowance exhausted','work-budget');
          supplied.push([voices[i],voices[j]]);
        }
      }else{
        dataArray(raw.pair,Math.max(2,limits.maxPairs),'Authored pairs');
        supplied=raw.pair.length===2&&raw.pair.every(v=>typeof v==='string')?[raw.pair]:raw.pair;
        if(!supplied.length)fail('An explicit pair list must not be empty');
      }
      const seen=new Set,pairs=[];
      for(const item of supplied){
        setup.charge();dataArray(item,2,'Authored pair');if(item.length!==2)fail('A pair needs two voices');
        const a=name(item[0],setup),b=name(item[1],setup);
        if(a===b||!voiceIndex.has(a)||!voiceIndex.has(b))fail('A pair names two distinct declared voices');
        const key=symmetric?edgeKey(a,b,voiceIndex):pairKey(a,b,voiceIndex);
        if(seen.has(key))fail(symmetric?'Duplicate or reversed symmetric parallel pair':'Duplicate ordered spacing pair');seen.add(key);
        const distance=Math.abs(orderIndex.get(a)-orderIndex.get(b));
        if(distance>limits.maxPairDistance)fail('Authored pair exceeds the declared pair-distance allowance','out-of-model');
        bandwidth=Math.max(bandwidth,distance);
        if(pairCount>=limits.maxPairs)fail('Expanded pair allowance exhausted','work-budget');pairCount++;
        pairs.push(freeze([a,b]));
      }
      pairsByRule.set(ruleId,freeze(pairs));
      rule={id:ruleId,type:raw.type,required:raw.required,pair:raw.pair==='all'?'all':freeze(pairs),...parameters};
    }else fail('Only monophony, melodic-bound, voice-spacing and parallel-classes are factorized','out-of-model');
    rules.push(freeze(rule));
  }
  freeze(voices);freeze(order);freeze(rules);
  const boundaryPolicy='actual-selected-event-endpoints-v1';
  const definition=freeze({kind:'factorized-cadence-profile-v2',id,version,pitchSpace:space.hash,clockDomain:domain,voices,order,rules,boundaryPolicy});
  const hash=definitionHash(definition,limits.maxTextChars,setup);
  const unaryRules=rules.filter(r=>r.type==='monophony'||r.type==='melodic-bound'),unary=new Map,pairs=new Map;
  const hasTransitions=rules.some(r=>r.type==='parallel-classes');
  const make=(selectedVoices,selectedRules)=>{
    setup.charge(1+selectedRules.length);
    const profile=compileCounterpointProfile({id,version,pitchSpace:space,clockDomain:domain,voices:selectedVoices,
      rules:selectedRules.map(r=>({...r,required:false}))});
    return freeze({voices:freeze([...selectedVoices]),rules:freeze([...selectedRules]),profile,
      transition:selectedRules.some(r=>r.type==='parallel-classes'),token:decomposeCounterpointProfile(profile)});
  };
  if(unaryRules.length)for(const v of voices)unary.set(v,make([v],unaryRules));
  for(const rule of rules)if(pairRule(rule))for(const pair of pairsByRule.get(rule.id)){
    setup.charge();const key=edgeKey(pair[0],pair[1],orderIndex),positions=key.split(',').map(Number);
    let group=pairs.get(key);if(!group){group={voices:positions.map(i=>order[i]),rules:new Map};pairs.set(key,group)}
    let record=group.rules.get(rule.id);if(!record){record={rule,pairs:[]};group.rules.set(rule.id,record)}record.pairs.push(pair);
  }
  for(const [key,group] of pairs){
    const selected=[...group.rules.values()].map(({rule,pairs})=>freeze({...rule,pair:freeze(pairs)}));
    pairs.set(key,make(group.voices,selected));
  }
  const unaryScopes=freeze([...unary].map(([voiceId,factor])=>freeze({voiceId,ruleIds:freeze(factor.rules.map(r=>r.id))})));
  const pairScopes=freeze([...pairs.values()].map(factor=>freeze({voices:factor.voices,ruleIds:freeze(factor.rules.map(r=>r.id))})));
  const requiredMelodicCoverage=rules.some(r=>r.type==='melodic-bound'&&r.required);

  function runtime(info,body){
    fields(info,['maxWork','maxFactorWork','consumeWork'],[]);
    const maxWork=Object.hasOwn(info,'maxWork')?count(info.maxWork):limits.maxWork;
    const maxFactorWork=Object.hasOwn(info,'maxFactorWork')?count(info.maxFactorWork):limits.maxFactorWork;
    if(Object.hasOwn(info,'consumeWork')&&typeof info.consumeWork!=='function')fail('consumeWork must be a synchronous receipt function');
    const budget=new Ledger(maxWork),state={budget,maxFactorWork};let reply,error;
    try{budget.charge();reply=body(state)}catch(caught){error=caught}
    // Exactly one caller receipt, including spent/reserved work on refusal. Internal receipts are owned closures.
    if(info.consumeWork)info.consumeWork(budget.used);
    if(error){if(error instanceof Refused){const out=new Refused(error.message,{kind:error.kind});out.workUsed=budget.used;throw out}throw error}
    return freeze({...reply,workUsed:budget.used});
  }
  function snapshot(raw,state,jobs){
    dataArray(raw,limits.maxEvents,'Factorized audit events');const all=[],seen=new Set,totalChunks=Math.ceil(raw.length/64);
    for(let offset=0,chunk=0;offset<raw.length;offset+=64,chunk++){
      state.budget.charge();
      const allowance=Math.min(EXACT_LIMITS.maxWork,state.maxFactorWork,Math.floor(state.budget.remaining/(totalChunks-chunk+jobs+1)));
      state.budget.charge(allowance); // normalizeEvents does not expose its ledger: reserve the entire allowance.
      const normalized=normalizeEvents(raw.slice(offset,offset+64),{maxWork:allowance});
      for(const event of normalized){state.budget.charge();if(seen.has(event.id))fail('Duplicate event identity across profile voices');seen.add(event.id);all.push(event)}
    }
    return freeze(all);
  }
  function domains(events,state,selectedVoices=null){
    const statuses=[],buckets=new Map;
    for(const v of selectedVoices??voices){state.budget.charge();buckets.set(v,[])}
    for(const event of events){
      state.budget.charge();
      if(selectedVoices&&!selectedVoices.has(event.voiceId))fail('Local material exceeds its declared voice scope','out-of-model');
      if(!voiceIndex.has(event.voiceId))statuses.push('FAIL');else buckets.get(event.voiceId).push(event);
      const d=event.clockDomain;
      statuses.push(!d?'UNKNOWN':d.id===domain.id&&d.unit===domain.unit&&d.revision===domain.revision?'PASS':'FAIL');
      if(event.pitch!==null){
        if(!dataRecord(event.pitch)||event.pitch.space!==space.id||event.pitch.definition!==space.hash)statuses.push('UNKNOWN');
        else{space.pitch(event.pitch);statuses.push('PASS')}
      }
    }
    for(const [v,values] of buckets)buckets.set(v,freeze(values));
    return {status:events.length?reduce(statuses):'UNKNOWN',buckets};
  }
  function blank(rule){
    const selected=pairRule(rule)?(rule.pair==='all'?pairsByRule.get(rule.id):rule.pair):[];
    const pairs=selected.map(pair=>({pair,status:'N/A',exercised:false}));
    return {id:rule.id,type:rule.type,required:rule.required,status:'N/A',exercised:false,pairs,
      pairLookup:new Map(pairs.map(item=>[pairKey(item.pair[0],item.pair[1],voiceIndex),item]))};
  }
  function factorEvidence(factor,events,state,pending,boundaries=null){
    state.budget.charge();
    const allowance=Math.min(state.maxFactorWork,Math.floor(state.budget.remaining/(pending+1)));
    let out;
    if(boundaries!==null&&factor.transition){
      // The three core ledgers cover initial normalization, sweep and predicates. Reserve normalization,
      // whose used count is not exposed; failed calls reserve the other two allocations before propagating.
      // The named-check scan below is charged separately to the monotone enclosing ledger.
      const allocation=Math.min(EXACT_LIMITS.maxWork,Math.floor(allowance/3));state.budget.charge(allocation);
      let error;try{out=factor.profile.audit(events,{boundaries,maxWork:allocation,maxPredicateWork:allocation})}catch(caught){error=caught}
      if(error){state.budget.charge(2*allocation);throw error}
      state.budget.charge(out.workUsed+out.predicateWorkUsed);
    }else out=factor.token.audit(events,{maxWork:allowance,consumeWork:used=>state.budget.charge(used)});
    const byRule=new Map(factor.rules.map(r=>[r.id,{id:r.id,status:'N/A',exercised:false,pairs:new Map}]));
    let domainStatus='N/A';
    for(const check of out.checks){
      state.budget.charge();if(check.rule==='$domains')domainStatus=reduce([domainStatus,check.status]);
      const record=byRule.get(check.rule);if(!record)continue;
      record.status=reduce([record.status,check.status]);if(check.status!=='N/A')record.exercised=true;
      for(const item of check.detail?.pairs??[]){
        state.budget.charge();const key=pairKey(item.pair[0],item.pair[1],voiceIndex),old=record.pairs.get(key);
        record.pairs.set(key,{pair:item.pair,status:reduce([old?.status??'N/A',item.status]),exercised:(old?.exercised??false)||item.status!=='N/A'});
      }
    }
    return {domainStatus,rules:[...byRule.values()]};
  }
  function merge(records,evidence,state){
    for(const got of evidence.rules){
      state.budget.charge();const row=records.get(got.id);row.status=reduce([row.status,got.status]);row.exercised||=got.exercised;
      for(const [key,local] of got.pairs){
        state.budget.charge();const pair=row.pairLookup.get(key);if(!pair)throw new Error('Authentic factor escaped its declared rule scope');
        pair.status=reduce([pair.status,local.status]);pair.exercised||=local.exercised;
      }
    }
  }
  function finish(records,domainStatus,whole,eventCount,state){
    const evidence=freeze([...records.values()].map(row=>{
      state.budget.charge();
      const covered=pairRule(row)?row.pairs.length>0&&row.pairs.every(p=>p.exercised):row.exercised;
      return freeze({id:row.id,type:row.type,required:row.required,musicalStatus:row.status,exercised:row.exercised,
        coverageStatus:whole&&row.required?(covered?'PASS':'UNKNOWN'):'N/A',
        pairs:freeze(row.pairs.map(p=>{state.budget.charge();return freeze({...p})})) });
    }));
    const musicalStatus=reduce(evidence.map(r=>r.musicalStatus)),status=reduce([domainStatus,musicalStatus,...evidence.map(r=>r.coverageStatus)]);
    return {status,scope:whole?'whole-factorized-profile':'necessary-factorized-profile',profileHash:hash,domainStatus,musicalStatus,
      ruleEvidence:evidence,eventCount,melodicExercised:evidence.some(r=>r.type==='melodic-bound'&&r.exercised)};
  }
  function local(kind,a,b,events,info){
    return runtime(info,state=>{
      if(!voiceIndex.has(a)||kind==='pair'&&(!voiceIndex.has(b)||a===b))fail('Choose declared distinct local voices');
      const selected=kind==='unary'?[a]:[a,b];
      const factor=kind==='unary'?unary.get(a):pairs.get(edgeKey(a,b,orderIndex));
      const owned=snapshot(events,state,factor?1:0),checked=domains(owned,state,new Set(selected));
      const selectedRules=factor?.rules??[],records=new Map(selectedRules.map(r=>[r.id,blank(r)]));let domainStatus=checked.status;
      if(factor&&owned.length){const evidence=factorEvidence(factor,owned,state,1);merge(records,evidence,state);domainStatus=reduce([domainStatus,evidence.domainStatus])}
      return finish(records,domainStatus,false,owned.length,state);
    });
  }
  const token=freeze({id,version,hash,definition,pitchSpaceHash:space.hash,clockDomain:domain,voices,order,limits,
    setupWorkUsed:setup.used,unaryScopes,pairScopes,requiredMelodicCoverage,bandwidth,hasTransitions,boundaryPolicy,
    unsupportedRuleIds:freeze([]),coversAllMusicalRules:true,
    unary(voiceId,events,info={}){return local('unary',voiceId,null,events,info)},
    pair(a,b,events,info={}){return local('pair',a,b,events,info)},
    audit(events,info={}){
      return runtime(info,state=>{
        const owned=snapshot(events,state,unary.size+pairs.size),checked=domains(owned,state),records=new Map(rules.map(r=>[r.id,blank(r)]));
        // Only actual CHOSEN event endpoints enter the whole transition sweep, including rests. A union over
        // every candidate could manufacture coverage. Unary/spacing statuses need no such common refinement.
        let boundaries=null;
        if(hasTransitions){
          const points=new Map;
          for(const event of owned)for(const point of [event.t,event.t.add(event.d)]){
            state.budget.charge();const key=String(point);
            if(!points.has(key)){
              if(points.size>=CANON_LIMITS.boundaries)fail('Actual transition boundary allowance exhausted','work-budget');
              points.set(key,point);
            }
          }
          boundaries=freeze([...points.values()].sort((a,b)=>{state.budget.charge();return a.cmp(b)}));
        }
        let domainStatus=checked.status;const jobs=[];
        for(const [v,factor] of unary){state.budget.charge();const es=checked.buckets.get(v);if(es.length)jobs.push({factor,events:es})}
        for(const factor of pairs.values()){
          state.budget.charge();const [left,right]=factor.voices.map(v=>checked.buckets.get(v));
          if(left.length&&right.length)jobs.push({factor,events:freeze([...left,...right])});
        }
        for(let i=0;i<jobs.length;i++){
          const {factor,events:es}=jobs[i],evidence=factorEvidence(factor,es,state,jobs.length-i,boundaries);
          merge(records,evidence,state);domainStatus=reduce([domainStatus,evidence.domainStatus]);
        }
        return finish(records,domainStatus,true,owned.length,state);
      });
    }
  });
  brands.set(token,true);return token;
}

export function inspectFactorizedCadenceProfile(token){
  if(!brands.has(token))fail('Use a genuine factorized cadence profile');return token;
}
