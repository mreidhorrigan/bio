// A conductor's plan of the piece, committed as far ahead as its horizon (horizon.js), and played through unless a
// stimulus reopens it (Musebots 3.0, docs/MUSEBOTS_3.md). The owner, 30 September 2026: "How the bots currently negotiate
// form can also ... be extended over the length of an entire piece so that, if no other stimulus intervenes, the bots
// will simply decide on a plan and play it. (This should allow them eventually to plan and play fugues and canons.)";
// "we want support for planning every step of the way between phrase-ahead and whole-piece-ahead."
//
// The plan is units (the form's sections) in order, each decided when it comes within the horizon: its length and
// whatever the form decides with it (`decide`), then each layer's decision for it (`layers`: constraints for the groups
// below, a casting, a canon's parts ...), each layer at its own horizon or the plan's. A horizon of a phrase decides each
// section as it comes due (how the Musebots have played); the piece's decides them all before the first bar; anything
// between decides so far ahead. Decided, a unit is committed: the conductor says it (a plan of kind 'piece', and
// whatever each decision asks), and it binds until a stimulus reopens it from a bar on (`reopen`). What has been handed
// to the players to carry out (`lock`) is never reopened. Beyond the horizon, the conductor keeps only its sketch, its
// own to redraw.
//
// Each decision is the conductor's own function, drawn from its own seeded stream: the plan holds when and what, never
// how.
import {checkedHorizon,withinHorizon,horizonBars,describeHorizon} from './horizon.js';
import {bandPhraseBars} from '../opening-time.js';

// Ours: a plan says its last few stimuli, and a unit is at most so many bars (a unit longer than a piece of hours is a
// mistake, not a form).
const STIMULI_SAID=8,MAX_UNIT_BARS=4096,MAX_UNITS=4096;
// Under planning.js's limits on a payload (64 KB, 4096 values), with room for the envelope.
export const PIECE_PAYLOAD_BYTES=60000,PIECE_PAYLOAD_ITEMS=3800;
// The values in a payload, as planning.js counts them.
const nodes=value=>value&&typeof value==='object'?1+Object.values(value).reduce((sum,item)=>sum+nodes(item),0):1;
const encoder=new TextEncoder();

export class PiecePlanner{
  // decide(index, {previous, units}) -> a unit's decision with its length in bars ({bars, ...}); null where the piece
  // ends before it; false where it cannot be decided yet (a subconductor's parent has not planned so far). layers: [{id, horizon?, decide(unit, {previous (the layer's decision for the unit before), units})}].
  // estimate() -> the piece's length in bars as the conductor's sketch has it (for a reach, until the plan is complete).
  constructor({decide,layers=[],horizon='phrase',startBar=0,estimate=null,maxUnits=MAX_UNITS}={}){
    if(typeof decide!=='function')throw new TypeError('A piece plan decides its units');
    this.decideUnit=decide;this.horizon=checkedHorizon(horizon);this.startBar=startBar;this.estimate=estimate;this.maxUnits=maxUnits;
    this.layers=layers.map(layer=>{
      if(!layer?.id||typeof layer.decide!=='function'||layer.id==='form')throw new TypeError('A layer has an id (not form) and decides');
      return {id:String(layer.id),horizon:layer.horizon!=null?checkedHorizon(layer.horizon):null,decide:layer.decide};
    });
    this.units=[];this.ended=false;this.lockedThrough=-Infinity;this.stimuli=[];this.revision=0;
  }
  // The piece's length as known (complete), else as estimated, else as decided so far.
  pieceBars(){
    if(this.ended)return this.endBar-this.startBar;
    const estimated=Number(this.estimate?.());
    const decided=(this.units.at(-1)?.endBar??this.startBar)-this.startBar;
    return Number.isFinite(estimated)&&estimated>0?Math.max(estimated,decided):decided||null;
  }
  get endBar(){return this.ended?(this.units.at(-1)?.endBar??this.startBar):null}
  // The index of the unit playing at a bar (-1 before the first; the last decided where the bar is past them).
  indexAt(bar){
    if(!this.units.length||bar<this.units[0].startBar)return -1;
    const at=this.units.findIndex(unit=>unit.startBar<=bar&&bar<unit.endBar);
    return at>=0?at:this.units.length-1;
  }
  unitAt(bar){const index=this.indexAt(bar);return index>=0&&bar<this.units[index].endBar?this.units[index]:null}
  context(context={}){
    const bar=Number(context.bar)||0,index=this.indexAt(bar),unit=this.units[index];
    return {bar,current:index,phraseBars:context.phraseBars??unit?.value?.phraseBars??bandPhraseBars(),barSeconds:context.barSeconds??unit?.value?.barSeconds??2,
      pieceBars:context.pieceBars??this.pieceBars()};
  }
  // Decide whatever has come within the horizon by `context.bar`: units first, then each layer for the units decided.
  // -> the decisions made, [{index, layer ('form' or a layer's id)}], in order.
  advance(context={}){
    const made=[];
    while(!this.ended){
      // (A plan of more units than any form has: its decider has run away, and the piece ends there.)
      if(this.units.length>=this.maxUnits){this.ended=true;break}
      const index=this.units.length,startBar=this.units.at(-1)?.endBar??this.startBar;
      if(!withinHorizon(this.horizon,{index,startBar},this.context(context)))break;
      const value=this.decideUnit(index,{previous:this.units.at(-1)??null,units:this.units});
      if(value===false)break;
      if(value==null){this.ended=true;break}
      const bars=Math.round(Number(value.bars));
      if(!(bars>=1&&bars<=MAX_UNIT_BARS))throw new RangeError(`A unit lasts 1 to ${MAX_UNIT_BARS} bars`);
      this.units.push({index,startBar,endBar:startBar+bars,value:Object.freeze({...value,bars}),layers:{},decidedAt:Number(context.bar)||0});
      made.push({index,layer:'form'});
    }
    for(const layer of this.layers){
      const horizon=layer.horizon??this.horizon;
      for(const unit of this.units){
        if(Object.hasOwn(unit.layers,layer.id))continue;
        if(!withinHorizon(horizon,unit,this.context(context)))break;
        const previous=unit.index>0?this.units[unit.index-1].layers[layer.id]??null:null;
        unit.layers[layer.id]=layer.decide(unit,{previous,units:this.units})??null;
        made.push({index:unit.index,layer:layer.id});
      }
    }
    if(made.length)this.revision++;
    return made;
  }
  // Everything that begins before `bar` has been handed to the players: never reopened.
  lock(bar){this.lockedThrough=Math.max(this.lockedThrough,bar)}
  // A stimulus reopens the plan from a bar on (never before what is locked): the form's units from there (and so every
  // layer's decisions for them), or only the layers named. They are decided again as they come within the horizon.
  // -> the decisions dropped, [{index, layer}].
  reopen({fromBar,layers=null,kind='stimulus',reason='',bar=null}={}){
    const from=Math.max(Number.isFinite(fromBar)?fromBar:-Infinity,this.lockedThrough),dropped=[];
    const all=!layers||layers.includes('form');
    if(all){
      const kept=this.units.filter(unit=>unit.startBar<from);
      for(const unit of this.units.slice(kept.length))dropped.push({index:unit.index,layer:'form'});
      this.units=kept;if(dropped.length)this.ended=false;
      // A plan that had ended at `from` or after is open again past its end.
      if(this.ended&&(this.units.at(-1)?.endBar??this.startBar)>=from)this.ended=false;
    }else for(const unit of this.units)if(unit.startBar>=from)for(const id of layers)if(Object.hasOwn(unit.layers,id)){delete unit.layers[id];dropped.push({index:unit.index,layer:id})}
    this.stimuli.push({bar,kind,reason:String(reason).slice(0,240),fromBar:Number.isFinite(from)?from:null,layers:all?['form',...this.layers.map(layer=>layer.id)]:[...layers],dropped:dropped.length});
    while(this.stimuli.length>64)this.stimuli.shift();
    if(dropped.length)this.revision++;
    return dropped;
  }
  // A unit begun, cut short at `atBar` -- a bar within it not yet played, its phrase's end -- for a stimulus that cannot
  // wait for its end: its layers' decisions by bar kept before it, the units after it dropped to be decided again from
  // there. Never what has been played, and never a unit not yet begun (that is reopen's). -> the decisions dropped.
  cut(index,atBar,{kind='stimulus',reason='',bar=null}={}){
    const unit=this.units[index];if(!unit||!(atBar>unit.startBar&&atBar<unit.endBar)||!(atBar>(Number(bar)||-Infinity)))return [];
    const dropped=this.units.slice(index+1).map(later=>({index:later.index,layer:'form'})),bars=atBar-unit.startBar;
    const phraseBars=Math.max(1,Number(unit.value.phraseBars)||bars);
    const byBar=value=>Array.isArray(value)&&value.length&&value.every(item=>Number.isFinite(item?.bar));
    const layers=Object.fromEntries(Object.entries(unit.layers).map(([id,value])=>[id,byBar(value)?value.filter(item=>item.bar<atBar):value]));
    this.units=[...this.units.slice(0,index),{...unit,endBar:atBar,value:Object.freeze({...unit.value,bars,phrases:Math.max(1,Math.round(bars/phraseBars)),cut:true}),layers}];
    this.ended=false;
    this.stimuli.push({bar,kind,reason:String(reason).slice(0,240),fromBar:atBar,layers:['form'],dropped:dropped.length,cut:index});
    while(this.stimuli.length>64)this.stimuli.shift();
    this.revision++;
    return dropped;
  }
  // Something heard that changes no decision (a person gone, the horizon back where it was), said with the stimuli.
  note({kind='note',reason='',bar=null}={}){
    this.stimuli.push({bar,kind,reason:String(reason).slice(0,240),fromBar:null,layers:[],dropped:0});
    while(this.stimuli.length>64)this.stimuli.shift();
    this.revision++;
  }
  // The last bar decided for a layer ('form': the units' end), counted through its contiguous decisions.
  through(layer='form'){
    if(layer==='form')return this.units.at(-1)?.endBar??this.startBar;
    let end=this.startBar;for(const unit of this.units){if(!Object.hasOwn(unit.layers,layer))break;end=unit.endBar}
    return end;
  }
  // Whether the whole piece is decided: the form to its end and every layer for every unit.
  get complete(){return this.ended&&this.units.every(unit=>this.layers.every(layer=>Object.hasOwn(unit.layers,layer.id)))}
  // The plan as a 'piece' plan's payload, from the unit playing at `fromBar` on: the units, how far each layer is
  // decided, whether the piece is complete and where it ends, its horizon, the last stimuli. The farthest units are left
  // out where it would pass `bytes` (and it says so: `truncated`, and each layer's `through`).
  payload({fromBar=this.startBar,group=null,conductor=null,bytes=PIECE_PAYLOAD_BYTES,context={},say=null}={}){
    const at=Math.max(0,this.indexAt(fromBar)),ctx=this.context({...context,bar:fromBar}),bars=horizonBars(this.horizon,ctx);
    // (Each layer as `say(id, value)` says it, where given: a layer said apart in part, as a fugue's voices are.)
    const layersOf=unit=>say?Object.fromEntries(Object.entries(unit.layers).map(([id,value])=>[id,say(id,value)])):{...unit.layers};
    const units=this.units.slice(at).map(unit=>({index:unit.index,startBar:unit.startBar,endBar:unit.endBar,...unit.value,
      ...(Object.keys(unit.layers).length?{layers:layersOf(unit)}:{})}));
    const make=list=>({schemaVersion:1,...(group?{group}:{}),...(conductor?{conductor}:{}),
      horizon:{...this.horizon,value:Number.isFinite(this.horizon.value)?this.horizon.value:null,words:describeHorizon(this.horizon),
        bars:Number.isFinite(bars)?+bars.toFixed(3):null},
      startBar:this.startBar,units:list,through:Object.fromEntries([['form',this.through('form')],...this.layers.map(layer=>[layer.id,this.through(layer.id)])]),
      complete:this.complete,endBar:this.endBar,stimuli:this.stimuli.slice(-STIMULI_SAID)});
    let list=units,out=make(list);
    while(list.length>1&&(encoder.encode(JSON.stringify(out)).length>bytes||nodes(out)>PIECE_PAYLOAD_ITEMS)){list=list.slice(0,Math.max(1,Math.floor(list.length*.8)));out={...make(list),truncated:true}}
    return out;
  }
}

// ---- Stimuli -------------------------------------------------------------------------------------------------------
// What reopens a plan that is otherwise played as planned. A stimulus is something from outside the plan: a person or a
// performer the band listens to, a player arriving or leaving, the band's answers to what it was asked, a direction from
// above, a suggestion. The plan being carried out (its own meters, sections, lifecycle requests, the players' notes and
// their acceptances) is not one. -> {kind, fromBar?, reason} or null.
//   constraints  new constraints for this group or one above it, from their bar (groups.js)
//   adjust       the form adjusted (/broadcast/form/adjust), from the next section
//   performer    a performer heard: a listening bot standing for a person (its role 'performer'), a harmony it leads, or
//                a profile saying them playing (profile_clodbot); one person once, whichever of these says them first
//                (a listener's onsets are its voice, its notes '<voice>:performer', its harmony and profile its own)
//   roster       a player arrives (its first agentState) or leaves (a conductor hears the roster before the piece
//                begins as its opening, not as a stimulus)
//   person       a person's suggestion (casting) or a grammar handed in
//   ending       another's proposal or commitment to end
// `known` (a Set) holds the players heard so far, updated here; `group` and `ancestors` the conductor's own and above.
export function classifyStimulus(message,{self=null,group=null,ancestors=[],known=null}={}){
  const address=message?.address??'',value=message?.args?.[0];
  if(!address||message.source&&message.source===self||value?.author&&value.author===self)return null;
  // (A conductor's own constraints for its group come from its group: its own, however the bus names their sender.)
  if(address==='/broadcast/group/constraints'&&value&&(value.group===group||ancestors.includes(value.group))&&!(group&&value.from===group))
    return {kind:'constraints',fromBar:Number.isInteger(value.appliesAt?.bar)?value.appliesAt.bar:null,reason:`constraints for ${value.group} from ${value.from??'above'}`};
  if(address==='/broadcast/form/adjust')return {kind:'adjust',fromBar:null,reason:'the form adjusted'};
  const person=voice=>`performer:${String(voice).replace(/:performer$/,'')}`;
  if((address==='/broadcast/onsets'||address==='/broadcast/voices')&&value?.role==='performer'&&value.voice||address==='/broadcast/profile'&&value?.voice&&value.present){
    const id=person(value.voice);if(!known||known.has(id))return null;known.add(id);
    return {kind:'performer',fromBar:null,reason:`a performer heard (${String(value.voice).replace(/:performer$/,'')})`};
  }
  if(address==='/broadcast/plan'&&value?.kind==='harmony'&&value.payload?.source==='performer-harmony'){
    const id=person(value.author);if(!known||known.has(id))return null;known.add(id);
    return {kind:'performer',fromBar:null,reason:'a performer leads the harmony'};
  }
  if(address==='/broadcast/plan'&&value?.kind==='lifecycle'&&['proposal','commitment'].includes(value.payload?.phase)&&value.payload?.action==='stop')
    return {kind:'ending',fromBar:Number.isInteger(value.appliesAt?.bar)?value.appliesAt.bar:null,committed:value.payload.phase==='commitment',
      reason:`${value.author} ${value.payload.phase==='commitment'?'commits':'proposes'} to end`};
  if(address==='/broadcast/agentState'&&value?.instanceId&&known){
    const id=`agent:${value.instanceId}`,gone=['leaving','left'].includes(value.state);
    if(gone&&known.has(id)){known.delete(id);return {kind:'roster',fromBar:null,reason:`${value.name??value.instanceId} leaves`}}
    if(!gone&&!known.has(id)){known.add(id);return {kind:'roster',fromBar:null,reason:`${value.name??value.instanceId} arrives`}}
    return null;
  }
  if(address==='/agent/casting/suggest'&&value?.source==='person')return {kind:'person',fromBar:null,reason:'a person\'s casting suggestion'};
  if(address==='/agent/plex/grammar')return {kind:'person',fromBar:null,reason:'a grammar handed in'};
  return null;
}
