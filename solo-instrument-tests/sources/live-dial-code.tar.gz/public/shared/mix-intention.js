// A scene's mix intention and its masking permissions (the extreme-aesthetics report's §6.1, §6.2, M3).
//
// **Not one "clearer is better" objective.** What a section's mix is for is a vector of named aims, each 0 to 1 or
// unsaid (null: the desk's own way). A field-oriented scene lets its sources fuse. An impact-oriented one exposes the
// kick's and snare's attacks while the bodies merge. A raw one keeps each source independent. These are alternatives,
// not points on one scale from bad to good, and a mix serving one is not failing another's criterion (E16).
//
// **Masking has permissions.** Who may cover whom is a musical relation, said, not inferred by a masking estimator.
// Source A may mask B's highs, and the unmasking duty then leaves A there; C and D may fuse, with no carving between
// them. The desk's unmasking honours them (auto-mix.js unmaskingMoves).
//
// Who says it: the form, or a section's plan (a bot's composition decision), over MIX_INTENTION_ADDRESS, or a render
// spec's desk. The Mixbot acts on it and never chooses it.

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const MIX_INTENTION=Object.freeze({
  axes:Object.freeze(['mass','attackLegibility','intentionalFusion','roughness','lowEndContinuity','dynamicContrast',
    'depth','width','sourceIndependence','spectralInstability']),
  // The desk's unmasking bands (auto-mix.js: a move's band by its centre).
  bands:Object.freeze(['low','mid','high']),
  // The axes the desk acts on, and by which duty (live-desk.js setIntention). The rest are said, and reported as held
  // by nothing yet: never silently dropped.
  heldBy:Object.freeze({intentionalFusion:'frequency',attackLegibility:'punch',dynamicContrast:'dynamics',depth:'space',width:'placement'}),
  // What a masking permission may keep of the part it lets be covered: its attacks (the masker steps back as it strikes).
  keeps:Object.freeze(['attacks']),
  // The masker's step back under a kept attack, keyed from the masked part's own channel (ours, after the punch duty's
  // ducks: the bass 3 dB under the kick, back in 70 ms).
  keptAttack:Object.freeze({rangeDb:3,attack:.001,release:.08,threshold:-40,ratio:8}),
  // Width's aim for the mix's side/mid power (placement.js sideMid): the narrowest measured mixes at 0, their middle at
  // 0.5, and a field wider than they go at 1 (ours), each with the measured band's half-width about it.
  narrowestSideMid:.05,widestSideMid:.2,sideMidBand:.05,
  // Depth's reverb level against the mix at its ends (LU; ours). The middle (0.5) is the approach's own wetLu. Past the
  // -9 LU pop listeners judge too wet (mix-approaches.js MEASURED.tooWetLu) is allowed here: a scene that asks for
  // depth 1 asks for a wash.
  driestWetLu:-24,wettestWetLu:-6,
  // Attack legibility's scale on the punch duty's transient boost and ring cut: none at 0, the approach's own at 0.5,
  // half as much again at 1 (ours).
  mostPunch:1.5,
  // Dynamic contrast's range at its most stays this far under the dynamics duty's ceiling (LU; ours), so the desk has a
  // window to rest in rather than one value to hunt around.
  contrastWindowLu:2,
  // A scene change (live-desk.js sceneChange): an intention said for a moment is made there, every move together, each
  // over sceneSeconds (ours: inside the 30-50 ms within which an ensemble's onsets are heard as together; Rasch 1979), so
  // it lands with the downbeat rather than after it. The duties that hold what it moved leave it for settleSeconds: the
  // short-term meter's 3 s window, and a decision's margin, so they hear the new scene before correcting it.
  sceneSeconds:.03,settleSeconds:4,
});
export const MIX_INTENTION_ADDRESS='/broadcast/mixIntention';
const unit=(value,name)=>{
  if(value===null||value===undefined)return null;
  if(!(Number.isFinite(value)&&value>=0&&value<=1))throw new RangeError(`${name}: from 0 to 1, or unsaid`);
  return value;
};
const named=(value,name)=>{if(typeof value!=='string'||!value)throw new TypeError(`${name}: a channel`);return value};

// An intention: every axis, each 0-1 or null. An axis it does not know is refused, not ignored.
export function mixIntention(values={}){
  for(const key of Object.keys(values))if(!MIX_INTENTION.axes.includes(key))throw new RangeError(`no mix intention ${key}: ${MIX_INTENTION.axes.join(', ')}`);
  return Object.freeze(Object.fromEntries(MIX_INTENTION.axes.map(axis=>[axis,unit(values[axis],axis)])));
}
// Whether an intention says anything at all.
export const saysAnything=intention=>Boolean(intention)&&MIX_INTENTION.axes.some(axis=>intention[axis]!==null&&intention[axis]!==undefined);
// What the desk does with an intention: {held: {axis: duty}, unheld: [axes said that no duty acts on yet]}.
export function intentionReach(intention){
  const said=MIX_INTENTION.axes.filter(axis=>intention?.[axis]!==null&&intention?.[axis]!==undefined);
  return Object.freeze({held:Object.freeze(Object.fromEntries(said.filter(axis=>axis in MIX_INTENTION.heldBy).map(axis=>[axis,MIX_INTENTION.heldBy[axis]]))),
    unheld:Object.freeze(said.filter(axis=>!(axis in MIX_INTENTION.heldBy)))});
}

// A masking permission: {masker, masked, bands ('all' or a list of MIX_INTENTION.bands), keep? (['attacks']: A may
// cover B, but steps back as B strikes)}, A may cover B there; or {fuse: [channels]}, any of them may cover any other.
export function maskingPermission(permission){
  if(Array.isArray(permission?.fuse)){
    if(permission.fuse.length<2)throw new RangeError('a fusion names two channels or more');
    return Object.freeze({fuse:Object.freeze(permission.fuse.map(id=>named(id,'fuse')))});
  }
  const bands=permission?.bands??'all';
  if(bands!=='all'&&!(Array.isArray(bands)&&bands.length&&bands.every(band=>MIX_INTENTION.bands.includes(band))))
    throw new RangeError(`a permission's bands: 'all' or some of ${MIX_INTENTION.bands.join(', ')}`);
  const keep=permission?.keep??[];
  if(!(Array.isArray(keep)&&keep.every(what=>MIX_INTENTION.keeps.includes(what))))throw new RangeError(`a permission keeps some of ${MIX_INTENTION.keeps.join(', ')}`);
  return Object.freeze({masker:named(permission?.masker,'masker'),masked:named(permission?.masked,'masked'),bands:bands==='all'?'all':Object.freeze([...bands]),
    ...(keep.length?{keep:Object.freeze([...new Set(keep)])}:{})});
}
// Whether `masker` may cover `masked` in `band`, by any of the permissions.
export function maskingPermitted(permissions,masker,masked,band){
  return (permissions??[]).some(permission=>permission.fuse
    ?permission.fuse.includes(masker)&&permission.fuse.includes(masked)
    :permission.masker===masker&&permission.masked===masked&&(permission.bands==='all'||permission.bands.includes(band)));
}

// ---- What each held axis sets --------------------------------------------------------------------------------------------
// An unmasking cut under an intentional fusion: the cut the desk would make, times (1 - fusion). Fused sources are left
// to cover one another; articulated ones are carved as before.
export const fusedCutDb=(cutDb,fusion)=>fusion===null||fusion===undefined?cutDb:cutDb*(1-fusion);
// The reverb's level against the mix for a depth: the approach's own at 0.5, drier toward driestWetLu, wetter toward
// wettestWetLu, in straight lines. Null (unsaid) keeps the approach's.
export function depthWetLu(planWetLu,depth,choices=MIX_INTENTION){
  if(depth===null||depth===undefined||!Number.isFinite(planWetLu))return planWetLu;
  return depth<=.5?choices.driestWetLu+(planWetLu-choices.driestWetLu)*depth*2:planWetLu+(choices.wettestWetLu-planWetLu)*(depth-.5)*2;
}
// The loudness range the dynamics duty lets the mix keep for a dynamic contrast: the desk's floor at 0 (live-desk.js
// minRangeLu), up to contrastWindowLu under its ceiling (maxRangeLu) at 1.
export const contrastRangeLu=(contrast,{minRangeLu,maxRangeLu},choices=MIX_INTENTION)=>minRangeLu+(maxRangeLu-choices.contrastWindowLu-minRangeLu)*contrast;
// Placement's aim for the mix's width at a scene's width: {sideMid, leastSideMid, mostSideMid}, or null (unsaid: its own).
export function widthAim(width,choices=MIX_INTENTION,measuredSideMid=.1){
  if(width===null||width===undefined)return null;
  const sideMid=width<=.5?choices.narrowestSideMid+(measuredSideMid-choices.narrowestSideMid)*width*2:measuredSideMid+(choices.widestSideMid-measuredSideMid)*(width-.5)*2;
  return Object.freeze({sideMid,leastSideMid:Math.max(0,sideMid-choices.sideMidBand),mostSideMid:sideMid+choices.sideMidBand});
}
// The punch duty's transient boost and ring cut scaled for an attack legibility: none at 0 (no punch), the approach's
// own at 0.5, mostPunch times at 1. Returns the scale.
export const punchScale=(legibility,choices=MIX_INTENTION)=>legibility<=.5?legibility*2:1+(choices.mostPunch-1)*(legibility-.5)*2;
