// What reached a MIDI output, and whether the output is there (RESEARCH_BACKLOG "MIDI output completeness"). The
// server's bridge answers every numbered message (midi-bridge.cjs: `midi_ack` {through, count} for those it handed to
// the port, `midi_error` {id, error} for each it could not) and says when outputs come and go (`midi_outputs`). A
// browser's own Web MIDI port hands its bytes to the system at once, and says it is gone by its state. This keeps the
// counts, the round trip, the last error and the port's presence, and tells its owner of each change a person should
// know of (`onEvent` {kind: 'error' | 'disconnected' | 'reconnected' | 'unacknowledged' | 'acknowledged' | 'outputs',
// port, status, error?, reason?, outputs?}), a failure repeated within `repeatMs` counted and not told again.
export const MIDI_DELIVERY=Object.freeze({
  // Messages still unanswered after this long are told of, once, until answers resume. Ours: far past a local round
  // trip (a few milliseconds), short of a performer wondering why nothing sounds.
  staleMs:2000,
  // The unanswered messages kept to match answers against; past it the oldest are let go.
  pendingKept:4096,
  repeatMs:1000,
});

// Numbers are unique across the page, so an answer meant for an output closed since can match nothing of the next.
let lastNumber=0;

export class MidiDelivery {
  constructor({port,now=()=>globalThis.performance?.now?.()??Date.now(),onEvent=()=>{},choices=MIDI_DELIVERY}={}){
    Object.assign(this,{port,now,onEvent,choices});
    this.pending=new Map();       // number -> {at, bytes}, oldest first
    this.sent=0;this.acknowledged=0;this.failed=0;this.held=0;
    this.roundTripMs=null;this.lastError=null;this.connected=true;this.stale=false;
    this.toldAt=new Map();        // an error's text -> when it was last told
  }
  // A message about to go to the bridge: its number.
  number(bytes){
    const id=++lastNumber;this.sent++;
    this.pending.set(id,{at:this.now(),bytes});
    if(this.pending.size>this.choices.pendingKept)this.pending.delete(this.pending.keys().next().value);
    return id;
  }
  // A message handed straight to a port that takes it at once (Web MIDI).
  delivered(){this.sent++;this.acknowledged++}
  // A message not sent, because the port is gone.
  hold(){this.held++}
  // A reply from the bridge. -> whether it was one of its own.
  receive(message){
    if(message?.type==='midi_ack'&&Number.isSafeInteger(message.through)){
      const sentAt=this.pending.get(message.through)?.at;
      for(const id of this.pending.keys()){if(id>message.through)break;this.pending.delete(id);this.acknowledged++}
      if(sentAt!==undefined)this.roundTripMs=this.now()-sentAt;
      if(this.stale){this.stale=false;this.tell({kind:'acknowledged'})}
      return true;
    }
    if(message?.type==='midi_error'){
      if(Number.isSafeInteger(message.id)){if(!this.pending.delete(message.id))return false}
      this.fail(message.error,message.bytes);
      return true;
    }
    if(message?.type==='midi_outputs'&&Array.isArray(message.outputs)){
      const present=message.outputs.includes(this.port);
      this.setConnected(present,present?'the device is back':'the device was disconnected',{outputs:[...message.outputs]});
      return true;
    }
    return false;
  }
  fail(error,bytes=null){
    const text=String(error?.message??error??'MIDI delivery failed'),at=this.now();
    this.failed++;this.lastError=text;
    if(at-(this.toldAt.get(text)??-Infinity)<this.choices.repeatMs)return;
    this.toldAt.set(text,at);
    this.tell({kind:'error',error:text,bytes});
  }
  // `extra` rides on what is told (the bridge's list of outputs, so a device menu can follow them).
  setConnected(connected,reason='',extra={}){
    if(connected===this.connected){if(extra.outputs)this.tell({kind:'outputs',...extra});return;}
    this.connected=connected;
    // What was in flight to a port that went away will not be answered as delivered.
    if(!connected)this.pending.clear();
    this.tell({kind:connected?'reconnected':'disconnected',reason,...extra});
  }
  // Called now and then: tells, once, of messages the bridge has not answered in `staleMs`. -> whether it told.
  check(){
    if(this.stale||!this.pending.size)return false;
    const oldest=this.pending.values().next().value;
    if(this.now()-oldest.at<this.choices.staleMs)return false;
    this.stale=true;this.tell({kind:'unacknowledged'});return true;
  }
  status(){
    return {port:this.port,connected:this.connected,sent:this.sent,acknowledged:this.acknowledged,failed:this.failed,held:this.held,
      pending:this.pending.size,roundTripMs:this.roundTripMs,lastError:this.lastError};
  }
  tell(event){this.onEvent({...event,port:this.port,status:this.status()})}
}
