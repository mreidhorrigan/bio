// A bot's policy toward meter and tala proposals (RESEARCH_BACKLOG, the second queue: "each agent's policy toward
// meter and tala proposals: ignore, transform, or answer polymetrically"). A proposal is an input to interpretation
// (docs/MUSEBOT_PROTOCOL.md): a shared time signature does not imply a shared tala. A bot declares how it answers, in its
// manifest (`meterPolicy`) or a render spec's settings, as one of:
//   follow         it counts as proposed (every bot's answer unless it declares another, so the ports are unchanged);
//   ignore         the proposal's grouping is not its own: it keeps its grouping, and at a change of meter (whose bars
//                  it cannot but share: there is one clock) it counts the new bar in its own grouping if that fits,
//                  else the meter's plain twos and threes, not the proposed articulation;
//   transform:<t>  it counts the proposal transformed: its groups reversed, rotated by one (begun from their second),
//                  coarsened (adjacent pairs merged) or made fine (each group into twos and threes);
//   polymetric     it answers with a cycle of its own against the proposal: a proposed grouping gets its own grouping
//                  of the bar (its declared one, else the meter's own, turned where it would be the proposal's), and at
//                  a change of meter its previous cycle goes on as a stream begun with the new one at the change, the
//                  two re-aligning at their least common multiple (shared/rhythm-vocabulary.js realignment).
// Every answer is recorded with its reason (answerTala, answerMeter), so what a bot made of a proposal can be read. A
// policy that is none of these is refused, loudly: a manifest or spec that means something else should say so.
import {streamOf} from './rhythm-vocabulary.js';

export const METER_ANSWERS=Object.freeze(['follow','ignore','transform','polymetric']);
const sum=groups=>groups.reduce((a,b)=>a+b,0);
// Into twos and threes, threes first (meter.cjs defaultGrouping's rule): 4 is 2+2, 5 is 3+2, 7 is 3+2+2.
function twosAndThrees(n){
  if(n<=3)return [n];
  const groups=[],threes=Math.floor(n/3),remainder=n%3;
  if(remainder===1){for(let i=0;i<threes-1;i++)groups.push(3);groups.push(2,2)}else{for(let i=0;i<threes;i++)groups.push(3);if(remainder===2)groups.push(2)}
  return groups;
}
export const GROUP_TRANSFORMS=Object.freeze({
  reverse:groups=>[...groups].reverse(),
  rotate:groups=>groups.length>1?[...groups.slice(1),groups[0]]:[...groups],
  coarsen:groups=>{const out=[];for(let i=0;i<groups.length;i+=2)out.push(groups[i]+(groups[i+1]??0));return out},
  fine:groups=>groups.flatMap(twosAndThrees),
});

// A policy as a bot keeps it: {answer, transform?, grouping?}. Takes a string ('follow', 'ignore', 'polymetric',
// 'transform:reverse') or an object ({answer, transform, grouping}); nothing given is 'follow'.
export function meterPolicy(value='follow'){
  if(value===null||value===undefined)value='follow';
  const source=typeof value==='string'?(([answer,transform])=>({answer,transform}))(value.split(':')):value&&typeof value==='object'?value:{answer:String(value)};
  if(!METER_ANSWERS.includes(source.answer))throw new RangeError(`A meter policy is one of ${METER_ANSWERS.join(', ')} (transform:<${Object.keys(GROUP_TRANSFORMS).join('|')}>), not ${JSON.stringify(value)}`);
  const policy={answer:source.answer};
  if(policy.answer==='transform'){
    if(!GROUP_TRANSFORMS[source.transform])throw new RangeError(`A transform policy names one of ${Object.keys(GROUP_TRANSFORMS).join(', ')}`);
    policy.transform=source.transform;
  }
  if(policy.answer==='polymetric'&&Array.isArray(source.grouping)&&source.grouping.length&&source.grouping.every(size=>Number.isInteger(size)&&size>0))policy.grouping=[...source.grouping];
  return Object.freeze(policy);
}

// A proposed grouping (a tala of `numerator` beats), answered: {groups (what the bot counts), answer, reason}.
// `current`: the bot's own groups, if any.
export function answerTala(policy,proposal,{current=[],numerator=sum(proposal)}={}){
  const fits=groups=>Array.isArray(groups)&&groups.length&&sum(groups)===numerator;
  if(!fits(proposal))return {groups:fits(current)?[...current]:[],answer:'refused',reason:`the proposal does not add up to ${numerator}`};
  if(policy.answer==='follow')return {groups:[...proposal],answer:'follow',reason:'counts as proposed'};
  if(policy.answer==='ignore')return {groups:fits(current)?[...current]:[],answer:'ignore',reason:'counts as it did'};
  if(policy.answer==='transform'){
    const groups=GROUP_TRANSFORMS[policy.transform](proposal);
    return {groups,answer:'transform',reason:`the proposal ${policy.transform==='fine'?'made fine':policy.transform+'d'}: ${proposal.join('+')} as ${groups.join('+')}`};
  }
  // Its own grouping of the bar: its declared one fitted to the bar, else the meter's own twos and threes; one that
  // happens to be the proposal is turned to contrast with it.
  let own=policy.grouping&&sum(policy.grouping)===numerator?[...policy.grouping]:twosAndThrees(numerator);
  if(own.join('+')===proposal.join('+'))own=GROUP_TRANSFORMS.reverse(own).join('+')!==proposal.join('+')?GROUP_TRANSFORMS.reverse(own):GROUP_TRANSFORMS.rotate(own);
  return {groups:own,answer:'polymetric',reason:`its own grouping ${own.join('+')} against the proposed ${proposal.join('+')}`};
}

// A change of the ensemble's meter, answered at the shared tick `tick` where the new meter begins: {stream (the cycle
// the bot now counts, or null for the ensemble's), groups (its grouping of the new bar, or null for the meter's own),
// answer, reason}. `previous` and `next` are normalized meters; `current` the bot's own groups, if any.
export function answerMeter(policy,{previous,next,tick,current=[]}){
  const same=previous&&next&&previous.numerator===next.numerator&&previous.denominator===next.denominator&&previous.subdivision===next.subdivision;
  if(policy.answer==='follow'||!previous||!next)return {stream:null,groups:null,answer:'follow',reason:'counts the ensemble\'s meter'};
  if(policy.answer==='transform')return {stream:null,groups:GROUP_TRANSFORMS[policy.transform](next.groups),answer:'transform',reason:`the new meter's ${next.groups.join('+')} ${policy.transform==='fine'?'made fine':policy.transform+'d'}`};
  if(policy.answer==='ignore'){
    const own=Array.isArray(current)&&current.length&&sum(current)===next.numerator?[...current]:twosAndThrees(next.numerator);
    return {stream:null,groups:own,answer:'ignore',reason:`counts the new bar as ${own.join('+')}, its own, not the proposed ${next.groups.join('+')}`};
  }
  if(same)return {stream:null,groups:null,answer:'polymetric',reason:'the same bar: nothing to set against it'};
  return {stream:streamOf(previous,{anchor:tick,id:`${previous.label} against ${next.label}`}),groups:null,answer:'polymetric',reason:`keeps ${previous.label} against ${next.label}, begun together at tick ${tick}`};
}

// A rhythm plan proposing a meter or a tala (mh_PlexBOT's sections), answered in the protocol by the policy, so the
// proposer hears what each part will make of it (planning.js dispositions): follow accepts; ignore and transform answer
// `transform` with the groups the bot will count; polymetric answers a change of meter with `counter`, its own cycle
// (the meter it keeps), and a tala alone with `transform`, its own grouping. -> {disposition, payload, rationale}.
export function planAnswer(policy,payload,{current=[],currentMeter=null}={}){
  const meter=payload?.meter,tala=Array.isArray(payload?.tala)&&payload.tala.length?payload.tala.map(Number):null;
  const numerator=Number(meter?.numerator)||(tala?sum(tala):0);
  if(policy.answer==='follow'||!numerator)return {disposition:'accept',payload:{},rationale:'counts as proposed'};
  const proposed=tala??twosAndThrees(numerator);
  const changes=Boolean(currentMeter&&meter&&(Number(currentMeter.numerator)!==numerator||Number(currentMeter.denominator)!==(Number(meter.denominator)||4)));
  if(policy.answer==='polymetric'&&changes)
    return {disposition:'counter',payload:{stream:{meter:{numerator:currentMeter.numerator,denominator:currentMeter.denominator,subdivision:currentMeter.subdivision,groups:[...(currentMeter.groups??[])],...(currentMeter.tempoUnit?{tempoUnit:currentMeter.tempoUnit}:{}),...(currentMeter.metricReading?{metricReading:structuredClone(currentMeter.metricReading)}:{}),...(currentMeter.fixedDenominator?{fixedDenominator:true}:{})}}},
      rationale:`keeps its own ${currentMeter.label??`${currentMeter.numerator}/${currentMeter.denominator}`} against the proposed ${numerator}/${Number(meter.denominator)||4}`};
  if(policy.answer==='ignore'){
    const own=Array.isArray(current)&&current.length&&sum(current)===numerator?[...current]:twosAndThrees(numerator);
    return {disposition:'transform',payload:{groups:own,answer:'ignore'},rationale:`counts the proposed bar as ${own.join('+')}, its own, not ${proposed.join('+')}`};
  }
  const answer=answerTala(policy,proposed,{current,numerator});
  return {disposition:'transform',payload:{groups:answer.groups,answer:answer.answer},rationale:answer.reason};
}
