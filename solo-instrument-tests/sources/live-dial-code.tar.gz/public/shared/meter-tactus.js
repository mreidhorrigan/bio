// The tactus of a meter, the beat a listener taps, and whether it divides in three.
//
// The user asked for both kinds: "If you can get to the point where the bots can reliably accompany subdivisions
// of both 3 (e.g., 6/8, 12/8, 9/8) and 2 or 4 (4/4, et cetera), we will have accomplished something quite useful
// here."
//
// A compound meter reaches the bots in either of two forms (meter: a normalized meter, meter.cjs):
// - notated, as 12/8 is on the meter menu: eighth-note beats grouped in threes ({numerator: 12, denominator: 8,
//   groups: [3, 3, 3, 3]}). The tactus is the group, and each eighth is `subdivision` ticks;
// - counted in its tactus, as a conductor following a performer's triplets makes it. The beats are dotted quarters,
//   each divided into a multiple of three ticks ({numerator: 4, denominator: 4, subdivision: 3}). Each eighth is a
//   third of the beat. The clock's tempo is then the tactus's own, inside the ensemble's 40-220 BPM; 12/8 counted
//   in eighths would need up to 660.
//
import {sectionLevels} from './metric-home/sections.js';

// The fastest beat listeners take as the beat: 160 BPM, the fast end of the range in which a regular pulse is most
// readily heard (80-160 BPM, about a resonance near 2 Hz: van Noorden & Moelants 1999, "Resonance in the perception of
// musical pulse", Journal of New Music Research 28(1), 43-66).
export const FASTEST_BEAT_SECONDS=60/160;

// A beat's "and": its last third where it divides in three, its middle where it divides in two.
export const OFFBEAT=Object.freeze({ternary:2/3,binary:1/2});
// Two beat periods are compared to this (seconds).
const PERIOD_TOLERANCE_SECONDS=1e-9;
// No meter at all: the four beats of four ticks a bot's timekeeping assumes then (bots/lib/modules/timekeeping.js), at
// the tempo it assumes without one.
const UNMETERED_BEATS=4,UNMETERED_SUBDIVISION=4,DEFAULT_BPM=108;
// A beat of so many units divides in three when three divides it and two does not (a group of three eighths, a bar of
// nine); otherwise in two (two, four, six: a bar of 6/8 is two dotted quarters).
const dividesInThree=units=>units%TRIPLE===0&&units%DUPLE!==0,TRIPLE=3,DUPLE=2;

// Returns whether the meter is compound, the tactus beats in a bar, the ticks in a tactus and in an eighth (its
// third), and the notated beats in a tactus.
export function tactusOf(meter){
  const groups=Array.isArray(meter?.groups)?meter.groups:[],denominator=Number(meter?.denominator)||4,subdivision=Math.max(1,Number(meter?.subdivision)||4);
  if(groups.length>0&&groups.every(size=>size===3)&&denominator>=8)
    return {compound:true,form:'notated',beatsPerBar:groups.length,ticks:3*subdivision,eighthTicks:subdivision,units:3};
  if(subdivision%3===0)
    return {compound:true,form:'counted',beatsPerBar:Number(meter?.numerator)||groups.reduce((a,b)=>a+b,0),ticks:subdivision,eighthTicks:subdivision/3,units:1};
  return {compound:false,form:'simple',beatsPerBar:Number(meter?.numerator)||groups.reduce((a,b)=>a+b,0),ticks:subdivision,eighthTicks:null,units:1};
}

// The beats a listener feels in a bar, at the tempo it is played: [{start, length, offbeat}] in ticks into the bar,
// `offbeat` the beat's "and" (its last third where it divides in three, its middle otherwise). The notation's own beat
// (the quarter in 4/4, the eighth in 7/8 and 12/8, the counted beat of a compound meter counted in its tactus), moved up
// the meter's hierarchy -- to its groups, then to the whole bar -- while it is faster than FASTEST_BEAT_SECONDS. No
// meter is named: 4/4 with quarters at 100 is felt in quarters and at 200 in halves; 7/8 as 2+2+3 with eighths at 200
// in its three unequal groups and, slow, in its seven eighths; 12/8 with eighths at 200 in dotted quarters and, slow,
// in eighths; 13/16 in its groups. secondsPerTick: the clock's (secondsPerTick above).
export function feltBeats(meter,{secondsPerTick}){
  // An authored reading is a musical instruction, not a tempo-threshold inference. Do not expand its arithmetic
  // units into felt pulses or replace it with a different level when the clock changes.
  if(meter?.metricReading){
    const sub=Number(meter.subdivision)||UNMETERED_SUBDIVISION;let at=0;
    return meter.metricReading.beatWeights.map(size=>{
      const start=at,length=size*sub;at+=length;
      return Object.freeze({start,length,offbeat:start+Math.round(length*(dividesInThree(size)?OFFBEAT.ternary:OFFBEAT.binary))});
    });
  }
  const tactus=tactusOf(meter),subdivision=Math.max(1,Number(meter?.subdivision)||UNMETERED_SUBDIVISION);
  const groups=Array.isArray(meter?.groups)&&meter.groups.length?meter.groups:null;
  const units=groups?groups.reduce((a,b)=>a+b,0):Number(meter?.numerator)||tactus.beatsPerBar||UNMETERED_BEATS;
  const bar=Number(meter?.pulsesPerBar)||units*subdivision,unit=bar/units;
  // Each level of the hierarchy, from the notated beat up: beat starts, and whether each beat divides in three (a beat
  // counted in its tactus does, in its ticks).
  const levels=[];
  const beatStarts=[];for(let at=0;at<bar;at+=subdivision)beatStarts.push(at);
  levels.push(beatStarts.map(start=>({start,ternary:tactus.form==='counted'})));
  if(groups){
    let at=0;const starts=groups.map(size=>{const start=Math.round(at);at+=size*unit;return {start,ternary:dividesInThree(size)}});
    if(starts.length<levels[0].length)levels.push(starts);
  }
  // A long bar heard in sections (meter.sections: metric-home/sections.js) has levels between its groups and the bar, from
  // the deepest up, so a beat moved up from the groups is a group of groups there, not the whole bar: in 61/16 at a
  // quarter of 110 the groups (0.33 s) are too fast to be felt as the beat, and the bar is 8.3 s.
  for(const level of [...(sectionLevels(meter)??[])].reverse()){
    let at=0;const starts=level.map(size=>{const start=Math.round(at);at+=size*unit;return {start,ternary:dividesInThree(size)}});
    if(starts.length<levels.at(-1).length)levels.push(starts);
  }
  if(levels.at(-1).length>1)levels.push([{start:0,ternary:dividesInThree(units)}]);
  let chosen=levels[0];
  for(const level of levels.slice(1)){
    if(bar/chosen.length*secondsPerTick>=FASTEST_BEAT_SECONDS-PERIOD_TOLERANCE_SECONDS)break;
    chosen=level;
  }
  return chosen.map((beat,index)=>{
    const length=(chosen[index+1]?.start??bar)-beat.start;
    return Object.freeze({start:beat.start,length,offbeat:beat.start+Math.round(length*(beat.ternary?OFFBEAT.ternary:OFFBEAT.binary))});
  });
}

// A tick's length in seconds, as the clock that plays counts it (server.js, render/transport.js, timeline-clock.js):
// the tempo counts the meter's notated beat -- the quarter in 4/4, the eighth in 7/8 and 12/8, the dotted quarter in
// 12/8 counted in its tactus -- and a beat is `subdivision` ticks. The bots once counted the tempo in quarter notes
// (60 / bpm x 4 / denominator / subdivision): in eighths every note they timed was half as long as meant, and a
// performer's attacks were placed twice as far back as they were heard; in sixteenths, four times.
export function secondsPerTick(clock){return 60/(Number(clock?.bpm)||DEFAULT_BPM)/(Number(clock?.meter?.subdivision)||UNMETERED_SUBDIVISION)}

// How a counted compound meter is named: 4/4 in threes is 12/8, 3/4 is 9/8, 2/4 is 6/8.
export function compoundLabel(meter){
  const numerator=Number(meter?.numerator),denominator=Number(meter?.denominator);
  return Number.isInteger(numerator)&&Number.isInteger(denominator)?`${3*numerator}/${2*denominator}`:null;
}
