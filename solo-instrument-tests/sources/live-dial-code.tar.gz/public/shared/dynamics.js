// Dynamic levels by velocity, from the MIDI convention's centres (ppp 16, pp 33, p 49, mp 64, mf 80, f 96, ff 112, fff 127
// of 127), each level reaching halfway to the next: the marks the score writes (notation/score.js), and those an
// instrument's sound power is measured at (performers/sound-power.js). Here, apart from the notation, so that what reads
// them carries no notation with it: through sound-power.js, the notation had kept the plug-in's QuickJS decisions waiting
// a second as it started (test/audio/native-plugin.test.mjs).
//
// The system's one scale (the owner, 10 October 2026: "For our system, we should use a normal scored dynamic range from
// ppp to fff (with continuous unscored variations in velocity, of course, within that); and an expanded 'uncomfortable'
// range from pppppppp to ffffffff, subject to a diminishing-returns curve and involving excessive pressure (for extreme
// loudness) and almost-unspeaking lack of pressure (for extreme quietness)"): ppp to fff at these centres, every
// velocity between them a level between theirs; under ppp's centre, down to silence, the five marks beyond it
// (pppp to pppppppp), and over fff's, up to BEYOND.loudest, the five beyond it (ffff to ffffffff) -- what an instrument
// makes of them its own (a bowed string's under- and overpressure: physical-strings.js), each mark moving its sound less
// than the last, and the furthest reached least often (the owner, 10 October 2026: "The extended marks range from 8 ps
// to 8 fs, with the extremes of those marks rarely used and not being much different from the near-extremes").
export const DYNAMICS=Object.freeze([['ppp',.19],['pp',.32],['p',.44],['mp',.57],['mf',.69],['f',.82],['ff',.94],['fff',1.01]]);
export const DYNAMIC_VELOCITY=Object.freeze({ppp:16/127,pp:33/127,p:49/127,mp:64/127,mf:80/127,f:96/127,ff:112/127,fff:1});
// The uncomfortable range's marks each side, and how far over fff's centre its loudest velocity lies; and how much less
// each mark beyond moves an instrument's level than the one before (`shrink`: geometric, its first mark beyond `shrink`
// of its scored range's last step), so that the range is no line: however many marks are added beyond, their levels
// converge, a ppp and fff never moved by them (the owner, 16 October 2026: "the dynamic range should not have a linear
// distribution (so ever-more-extreme dynamics could be added without distorting the core pp, p ... mp ... f, ff)").
// Ours: at 0.6 the furthest mark lies 2.5 of its edge's steps beyond it.
export const BEYOND=Object.freeze({marks:5,loudest:1.5,shrink:.6});
// How many marks beyond the scored range a velocity lies (continuous): under ppp's centre, negative, to -BEYOND.marks at
// silence; over fff's, positive, to BEYOND.marks at BEYOND.loudest; 0 within it.
export function beyondOf(velocity){
  const v=Number(velocity)||0,{ppp,fff}=DYNAMIC_VELOCITY;
  if(v<ppp)return -BEYOND.marks*Math.min(1,(ppp-v)/ppp);
  if(v>fff)return BEYOND.marks*Math.min(1,(v-fff)/(BEYOND.loudest-fff));
  return 0;
}
// Every mark of the system's scale in order, quietest first -- eight p's to eight f's -- and each one's centre: the scored
// marks' DYNAMIC_VELOCITY, the uncomfortable range's where beyondOf stands at their whole numbers of marks beyond (under
// ppp toward silence, over fff toward BEYOND.loudest): a ladder to test that every mark is reached (the owner, 16 October
// 2026: "make sure that a full range of dynamics ... are accessible").
export const MARKS=Object.freeze([...Array.from({length:BEYOND.marks},(_,k)=>'p'.repeat(3+BEYOND.marks-k)),...DYNAMICS.map(([m])=>m),
  ...Array.from({length:BEYOND.marks},(_,k)=>'f'.repeat(4+k))]);
export function markVelocity(mark){
  if(mark in DYNAMIC_VELOCITY)return DYNAMIC_VELOCITY[mark];
  const k=String(mark).length-3;
  if(/^p+$/.test(mark)&&k>=1&&k<=BEYOND.marks)return DYNAMIC_VELOCITY.ppp*(1-k/BEYOND.marks);
  if(/^f+$/.test(mark)&&k>=1&&k<=BEYOND.marks)return DYNAMIC_VELOCITY.fff+(BEYOND.loudest-DYNAMIC_VELOCITY.fff)*k/BEYOND.marks;
  return NaN;
}
// A velocity's mark: within the scored range its level's; beyond it, a p or an f more for each mark begun beyond ppp's
// or fff's centre.
export const dynamicOf=velocity=>{
  const beyond=beyondOf(velocity);
  if(beyond<=-.5)return 'p'.repeat(3+Math.min(BEYOND.marks,Math.round(-beyond)));
  if(beyond>=.5)return 'f'.repeat(3+Math.min(BEYOND.marks,Math.round(beyond)));
  return scoredDynamicOf(velocity);
};
// A velocity's mark within the scored range (ppp to fff), one beyond it its end's: for a table keyed by the scored marks.
export const scoredDynamicOf=velocity=>DYNAMICS.find(([,limit])=>velocity<limit)?.[0]??'fff';
// A mark's place on the whole scale: ppp 0 to fff 7, the uncomfortable range's beyond them (pppp -1 to pppppppp -5,
// ffff 8 to ffffffff 12).
export const markIndex=mark=>{const k=DYNAMICS.findIndex(([name])=>name===mark);if(k>=0)return k;const n=String(mark).length;
  return /^p+$/.test(mark)?3-n:/^f+$/.test(mark)?4+n:NaN};
// A level's velocity beyond the scored range (a level of 0 to 1 is within it: line.js levelVelocity): under 0, from ppp's
// centre toward silence, reached at -1; over 1, from fff's toward BEYOND.loudest, reached at 2 -- each the square of how
// far beyond it lies, so that the furthest marks are the rarest (levels drawn evenly beyond, a mark of eight p's or f's
// one in twenty).
export function velocityBeyond(level){
  const x=Number(level)||0,{ppp,fff}=DYNAMIC_VELOCITY;
  return x<0?ppp*(1-Math.min(1,x*x)):fff+(BEYOND.loudest-fff)*Math.min(1,(x-1)**2);
}
