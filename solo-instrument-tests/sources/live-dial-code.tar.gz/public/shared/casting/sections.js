// Casting a section: which group plays it, and how the last group becomes this one (research/casting.md §6). The rules
// and the judgments are here; the choice is ManageBOT's, drawn from its own seeded stream among the groups these rank
// best (the shared module ranks and explains, the bot chooses).
import {hardChecks,metricallyLost,onsetRate,registerCrowding} from './fit.js';
import {tickSecondsAt} from './meters.js';
import {bandPhraseBars} from '../opening-time.js';

export const SECTIONS=Object.freeze({
  // Candidates: every group of the wanted size up to this many, a sample of this many above it.
  enumerateUpTo:20000,samples:3000,
  // The draw: among the best `topK` candidates, with probability proportional to exp(score / temperature). Ours.
  topK:10,temperature:.06,
  // The soft terms' weights (research/casting.md §6.4). Ours: overlap is what the form asked for, so it leads.
  weights:Object.freeze({overlap:1,intensity:.5,layers:.35,crowding:.35,rest:.4,streak:.4,novelty:.25,suggestion:2,lost:.6}),
  // Felt intensity lingers after a reduction: "a plateau of lingering high emotional intensity, despite the decrease
  // of other musical features" (Goodchild, Wild & McAdams 2019). λ per section, ours.
  linger:.85,
  // Fatigue: a leaky sum of intensity × phrases, decaying by `decay` each section; past `threshold` the next section
  // is thinned by at least one member whatever its tension asks (the user, 26 September: thinning "to reduce acoustic
  // fatigue"). Ours.
  fatigue:Object.freeze({decay:.6,threshold:2.4}),
  // Changes are sudden where the form asks for contrast (continuity under this) and at a return; gradual otherwise,
  // however many enter (a build is an orchestral crescendo, Goodchild's gradual addition).
  suddenBelow:.5,
  // Where the form asks for contrast, the chance ManageBOT clears the stage and brings the new group in one by one
  // instead of switching at once (the user: thinning to "set up new aesthetic topics"). Ours.
  clearThenIntroduce:.4,
  // Before a sudden addition of this many or more, the chance the beat layer drops out for the last phrase first.
  prepareJump:3,prepare:.5,
  defaultContinuity:.6,
  // The fewest a section casts, as a share of the most: a core texture, not a solo. A form bot's tension is how much
  // is at stake, not a headcount: its establish (.2) presents the piece's material, which two bots of ten cannot (the
  // first renders did exactly that for half a piece). About a third of the most, at least two. Ours.
  coreShare:.35,
  // The opening builds (a build-up introduction: the first group entering one member a phrase, harmony first), over at
  // most this many phrases, whatever the opening section's own length: the section after it keeps the group.
  openingPhrases:3,
});

// Roles that bring the home back, and roles that establish it (stochastic-config.js archetypes).
export const RETURN_ROLES=Object.freeze(['return','complex-return']);
export const HOME_ROLES=Object.freeze(['establish','complex-frame']);

const clamp01=value=>Math.max(0,Math.min(1,value));
const finiteOr=(value,fallback=null)=>Number.isFinite(Number(value))&&value!==null&&value!==''?Number(value):fallback;

// A form plan's sections placed in absolute bars: prefix sums of each section's own length (its phrases times its own
// phraseBars where it has one, else the plan's, else `phraseBars`), as formProgress now counts them too (the
// mathematical audit's B10). Not the clock's phrase count, which is floor(bar / current phraseBars) and runs backward
// when a section changes phrase length (meter.cjs).
export function compileSections(plan,{phraseBars=4}={}){
  const sections=Array.isArray(plan?.payload?.sections)?plan.payload.sections:[];
  const planBars=Math.max(1,Math.round(finiteOr(plan?.payload?.phraseBars,phraseBars)));
  let bar=Math.max(0,Math.round(finiteOr(plan?.appliesAt?.bar,0)));
  const home=Math.max(0,sections.findIndex(section=>HOME_ROLES.includes(String(section?.role))));
  return sections.map((section,index)=>{
    const phrases=Math.max(1,Math.round(finiteOr(section?.phrases,1))),bars=Math.max(1,Math.round(finiteOr(section?.phraseBars,planBars)));
    const role=String(section?.role||''),compiled={index,role,phrases,phraseBars:bars,startBar:bar,endBar:bar+phrases*bars,
      tension:finiteOr(section?.tension),hdensity:finiteOr(section?.hdensity),
      returnsTo:RETURN_ROLES.includes(role)?home:null,meter:section?.numerator?{numerator:section.numerator,
        denominator:section.denominator,groups:section.groups,subdivision:section.subdivision}:null,
      bpm:finiteOr(section?.tempo?.targetBpm)};
    bar=compiled.endBar;return Object.freeze(compiled);
  });
}
export const sectionAt=(sections,bar)=>sections.findLast?.(section=>section.startBar<=bar)??[...sections].reverse().find(section=>section.startBar<=bar)??null;

// What a section asks of the line-up: its intensity (the form bot's number: FormBOT's tension, else PlexBOT's
// hdensity, else the role's tension in `roleTension`), its continuity with what came before (`continuity`, PlexBOT's
// table), and whether it returns to the home group.
export function sectionTarget(section,{roleTension={},continuity={}}={}){
  const intensity=clamp01(section?.tension??section?.hdensity??roleTension[section?.role]??.5);
  const isReturn=section?.returnsTo!=null;
  return {intensity,continuity:clamp01(isReturn?1:continuity[section?.role]??SECTIONS.defaultContinuity),isReturn};
}

// A section's projected intensity, said outright with its casting for the players who shape a join by what comes
// (form-marks.js: whether the drummer fills up or down into it, and crashes on it). The user, 27 September 2026: "The
// decision of how to fill into a section should be made contextually based on the projected intensity (in terms of
// surface-rhythm speed and other parameters) of the approaching section." Three measures, each 0-1, weighted equally
// (ours): the section's intensity as the form asks it (sectionTarget: its tension); the share of the pool that will
// sound; and the share of the pool's surface rate those parts carry (fit.js onsetRate: what each played in its last
// phrases where the room heard it, else what it declares). A section where everyone plays as fast as they have played
// is 1. -> {value, tension, sounding, rate (the group's onsets a second), rateShare, entering, leaving}.
export function projectedIntensity({target,group=[],pool=[],enter=[],rest=[],quarterBpm=100,meter=null}){
  const members=new Map(pool.map(member=>[member.id,member])),rateOf=ids=>ids.reduce((sum,id)=>sum+(members.has(id)?onsetRate(members.get(id),{quarterBpm,meter}):0),0);
  const cast=group.filter(id=>members.has(id)),sounding=pool.length?cast.length/pool.length:0;
  const rate=rateOf(cast),whole=rateOf(pool.map(member=>member.id)),rateShare=whole>0?rate/whole:sounding;
  const tension=clamp01(target?.intensity??.5),round=value=>Math.round(value*1000)/1000;
  return {value:round((tension+sounding+rateShare)/3),tension:round(tension),sounding:round(sounding),rate:round(rate),rateShare:round(rateShare),
    entering:enter.length,leaving:rest.length};
}

// How many play: a core texture (SECTIONS.coreShare of the most, at least two) at no intensity, the most the pool and
// the cap allow at full.
export function sizeFor(intensity,most){
  const top=Math.max(1,most),core=Math.min(top,Math.max(2,Math.round(top*SECTIONS.coreShare)));
  return Math.max(1,Math.min(top,core+Math.round(clamp01(intensity)*(top-core))));
}

export const jaccard=(a,b)=>{
  const left=new Set(a),right=new Set(b);if(!left.size&&!right.size)return 1;
  let shared=0;for(const id of left)if(right.has(id))shared++;
  return shared/(left.size+right.size-shared);
};

// A draw from weights: index i with probability weights[i] / sum, a zero or negative weight never drawn (the audit's
// S01: support is exactly the positive weights). `u` in [0, 1). Null when nothing can be drawn.
export function drawIndex(weights,u){
  let total=0;for(const weight of weights)if(weight>0)total+=weight;
  if(!(total>0))return null;
  let target=Math.min(Math.max(0,u),1-Number.EPSILON)*total;
  for(let index=0;index<weights.length;index++){
    if(!(weights[index]>0))continue;
    if(target<weights[index])return index;
    target-=weights[index];
  }
  for(let index=weights.length-1;index>=0;index--)if(weights[index]>0)return index;
  return null;
}

// Groups of `size` from `pool` (ids): all of them while there are few enough, else a random sample (with `random`)
// plus the groups nearest the reference, so continuity is always on offer.
export function candidateGroups(pool,size,{random=Math.random,reference=[],samples=SECTIONS.samples,limit=SECTIONS.enumerateUpTo}={}){
  const n=pool.length;if(size<1||size>n)return [];
  let count=1;for(let k=0;k<size;k++){count=count*(n-k)/(k+1);if(count>limit)break}
  if(count<=limit){
    const out=[],chosen=[];
    const walk=start=>{if(chosen.length===size){out.push([...chosen]);return}
      for(let index=start;index<=n-(size-chosen.length);index++){chosen.push(pool[index]);walk(index+1);chosen.pop()}};
    walk(0);return out;
  }
  const seen=new Set,out=[];
  const add=group=>{const key=[...group].sort().join('|');if(group.length===size&&!seen.has(key)){seen.add(key);out.push(group)}};
  const kept=reference.filter(id=>pool.includes(id)),others=pool.filter(id=>!kept.includes(id));
  add([...kept.slice(0,size),...others.slice(0,Math.max(0,size-kept.length))]);
  for(let attempt=0;attempt<samples*2&&out.length<samples;attempt++){
    const shuffled=[...pool];
    for(let index=0;index<size;index++){const pick=index+Math.floor(random()*(n-index));[shuffled[index],shuffled[pick]]=[shuffled[pick],shuffled[index]]}
    add(shuffled.slice(0,size));
  }
  return out;
}

// The soft terms of one candidate, each 0 (best) to about 1, with the reasons worth saying.
function softTerms(group,{members,target,reference,history,suggestions,quarterBpm,bar,meter,secondsPerTick=null}){
  const chosen=group.map(id=>members.get(id));
  const overlap=Math.abs(jaccard(group,reference)-target.continuity);
  // Layers before doubling one, at every intensity: two players are better a pad and a line than two pads.
  const layers=new Set(chosen.map(member=>member.declaration.layer).filter(Boolean)).size;
  const layerTerm=1-layers/Math.min(5,group.length||1);
  const rate=chosen.reduce((sum,member)=>sum+onsetRate(member,{quarterBpm,meter}),0);
  const rest=chosen.reduce((sum,member)=>sum+(member.restedFor==null?1:Math.min(1,member.restedFor/32)),0)/Math.max(1,chosen.length);
  const recent=history.slice(-3),streak=chosen.filter(member=>recent.length>=3&&recent.every(entry=>entry.group.includes(member.id))).length/Math.max(1,chosen.length);
  // Novelty: not repeating a group from further back. Keeping the previous section's group is continuity, which the
  // overlap term weighs, and a return is meant to repeat.
  const novelty=!target.isReturn&&history.slice(0,-1).some(entry=>entry.group.length===group.length&&jaccard(entry.group,group)===1)?1:0;
  // Members off the felt beats in this meter, where that is a matter of style rather than a rule (fit.js).
  const lost=meter?metricallyLost(chosen,meter,{strict:false,secondsPerTick}).length/Math.max(1,chosen.length):0;
  let suggestion=0;
  // A suggestion counts by its weight: a person's is enacted (manage_clodbot.js weighs it far above the rest).
  for(const item of suggestions){const weight=item.weight||1;for(const id of item.enter||[])suggestion+=(group.includes(id)?-1:1)*weight;for(const id of item.rest||[])suggestion+=(group.includes(id)?1:-1)*weight}
  return {overlap,layers:layerTerm,rate,crowding:registerCrowding(chosen),rest:1-rest,streak,novelty,suggestion,lost};
}

// Cast one section. `pool`: the performers that may play, [{id, declaration, spectrum, heard, performing, restedFor}];
// `current`: the ids playing now; `home`: the group that established the home, or null; `history`: the sections cast
// so far, [{index, group, intensity}]; `section`: from compileSections (or ManageBOT's own); `state`: {felt, fatigue};
// `silent`: faculties the room has from bots never cast; `declined`: ids that refused this section; `suggestions`:
// accepted ones, [{enter:[ids], rest:[ids]}]; `options`: {roleTension, continuity, maxSize, quarterBpm, meter,
// random}. Returns the group, who enters and rests and when, the gesture, the reasons, and the new state.
export function castSection({pool,current=[],home=null,history=[],section,state={felt:0,fatigue:0},silent=[],declined=new Set,
  suggestions=[],options={}}){
  const random=options.random||Math.random,members=new Map(pool.map(member=>[member.id,member]));
  const target=sectionTarget(section,options);
  const reference=(target.isReturn&&home?.length?home:current).filter(id=>members.has(id));
  const castable=pool.filter(member=>!member.declaration.person&&!declined.has(member.id)).map(member=>member.id);
  const most=Math.max(1,Math.min(castable.length,options.maxSize??8));
  let size=sizeFor(target.intensity,most);
  const reasons=[`${section?.role||'section'}: intensity ${target.intensity.toFixed(2)}, continuity ${target.continuity.toFixed(2)}`];
  // Fatigue: past its threshold, thin by one at least, whatever the tension asks; felt intensity carries the arc.
  let thinned=null;
  if(state.fatigue>=SECTIONS.fatigue.threshold&&current.length>1&&size>=current.length){
    size=Math.max(1,current.length-1);thinned='fatigue';
    reasons.push(`thinning to ${size}: ${state.fatigue.toFixed(1)} of accumulated full playing is past ${SECTIONS.fatigue.threshold}, and the felt intensity (${state.felt.toFixed(2)}) lingers through a reduction`);
  }
  const quarterBpm=options.quarterBpm||100,bar=options.bar||0,meter=options.meter||section?.meter||null;
  // The meter as it is felt at this tempo, for who is lost in it (declarations.js lostIn).
  const secondsPerTick=meter?tickSecondsAt(quarterBpm,meter):null;
  let best=null,tried=[];
  // The wanted size first; then smaller, which the audibility test may require; then larger if nothing smaller will do.
  const sizes=[size,...Array.from({length:size-1},(_,index)=>size-1-index),...Array.from({length:most-size},(_,index)=>size+1+index)];
  for(const k of sizes){
    const candidates=candidateGroups(castable,k,{random,reference});
    const passing=[];
    for(const group of candidates){
      const chosen=group.map(id=>members.get(id));
      const checks=hardChecks(chosen,{silent,meter,declined,secondsPerTick});
      if(checks.ok)passing.push({group,terms:softTerms(group,{members,target,reference,history,suggestions,quarterBpm,bar,meter,secondsPerTick})});
      else if(tried.length<3)tried.push(checks.problems[0]?.because);
    }
    if(!passing.length)continue;
    // Normalize the unbounded terms across the passing candidates, then score (higher is better).
    const maxCrowding=Math.max(...passing.map(entry=>entry.terms.crowding),1e-9);
    const byRate=[...passing].sort((a,b)=>a.terms.rate-b.terms.rate);
    byRate.forEach((entry,index)=>{entry.rateRank=passing.length>1?index/(passing.length-1):target.intensity});
    const w=SECTIONS.weights;
    for(const entry of passing){
      const t=entry.terms;
      entry.score=-(w.overlap*t.overlap+w.intensity*Math.abs(entry.rateRank-target.intensity)+w.layers*t.layers
        +w.crowding*t.crowding/maxCrowding+w.rest*t.rest+w.streak*t.streak+w.novelty*t.novelty+w.suggestion*t.suggestion+w.lost*t.lost);
    }
    passing.sort((a,b)=>b.score-a.score||a.group.join('|').localeCompare(b.group.join('|')));
    const top=passing.slice(0,SECTIONS.topK),top0=top[0].score;
    const index=drawIndex(top.map(entry=>Math.exp((entry.score-top0)/SECTIONS.temperature)),random());
    best={...top[index??0],size:k,considered:candidates.length,passing:passing.length};
    if(k!==size)reasons.push(`${k} rather than ${size}: no group of ${size} could be cast (${tried.filter(Boolean)[0]||'no candidates'})`);
    break;
  }
  if(!best){
    reasons.push(`no group could be cast (${tried.filter(Boolean)[0]||'nobody to cast'}); the line-up stays as it is`);
    return {group:[...current],enter:[],rest:[],gesture:{kind:'hold',entries:'sudden',exits:'sudden'},reasons,state,target,size:current.length};
  }
  // Providers enter first and leave last, so a follower never plays a phrase without what it follows.
  const provides=id=>members.get(id)?.declaration.provides.length?1:0;
  const group=best.group,enteringIds=group.filter(id=>!current.includes(id)).sort((a,b)=>provides(b)-provides(a));
  const restingIds=current.filter(id=>!group.includes(id)).sort((a,b)=>provides(a)-provides(b));
  // The gesture (Goodchild 2019's time course by direction): sudden where the form asks for contrast or at a return,
  // gradual otherwise; where contrast is asked, sometimes the stage is cleared and the new group brought in one by one.
  // The opening is always at once: the bots it rests never sound.
  const contrast=target.continuity<SECTIONS.suddenBelow,join=options.join;
  // The opening: its rests at once (the bots it rests never sound), its group entering as a build.
  let entries=options.opening?'gradual':contrast||target.isReturn||thinned||join?'sudden':'gradual',exits=options.opening?'sudden':entries,kind;
  // A join a mixbot edits (options.join: edit_clodbot's cut, stutter, rewind or tape stop) is where everything changes
  // at once: the edit, the drummer's mark and the line-up reinforce one another.
  if(join)reasons.push(`at this join ${join.source} makes a ${join.kind}: the line-up changes with it, all at once`);
  else if(options.opening)kind='build';
  else if(contrast&&enteringIds.length>1&&random()<SECTIONS.clearThenIntroduce){exits='sudden';entries='gradual';kind='clear-then-introduce'}
  const phraseBars=Math.max(1,section?.phraseBars||bandPhraseBars()),start=section?.startBar??bar;
  const phrases=options.opening?SECTIONS.openingPhrases:Math.max(1,section?.phrases||1);
  // Staging: gradual changes one phrase apart (compressed if the section is short), an exit and an entry together in a
  // rotation.
  const stage=ids=>ids.map((id,index)=>({id,atBar:start+Math.min(phrases-1,index)*phraseBars}));
  let enter=entries==='gradual'?stage(enteringIds):enteringIds.map(id=>({id,atBar:start}));
  let rest=exits==='gradual'?stage(restingIds):restingIds.map(id=>({id,atBar:start}));
  // Every stage on the way must meet its needs too; if one would not, the change is made at once.
  if(entries==='gradual'||exits==='gradual'){
    const bars=[...new Set([...enter,...rest].map(item=>item.atBar))].sort((a,b)=>a-b);
    let playing=new Set(current),broken=false;
    for(const at of bars){
      for(const item of rest)if(item.atBar===at)playing.delete(item.id);
      for(const item of enter)if(item.atBar===at)playing.add(item.id);
      // Every hard check but refusals (the mathematics agent's review: endpoint feasibility does not certify the way
      // there).
      if(!hardChecks([...playing].map(id=>members.get(id)).filter(Boolean),{silent,meter,secondsPerTick}).ok){broken=true;break}
    }
    if(broken){
      entries=exits='sudden';kind=undefined;
      enter=enteringIds.map(id=>({id,atBar:start}));rest=restingIds.map(id=>({id,atBar:start}));
      reasons.push('all at once: a gradual change would have passed through a group that could not be cast');
    }
  }
  if(!kind){
    if(!enteringIds.length&&!restingIds.length)kind='hold';
    else if(!restingIds.length)kind=entries==='gradual'?'build':'sudden-addition';
    else if(!enteringIds.length)kind=exits==='gradual'?'thin':'sudden-reduction';
    else kind=entries==='sudden'?'switch':'rotate';
  }
  // Prepare a sudden addition: the beat layer out for the last phrase before it.
  let prepare=[];
  if(kind==='sudden-addition'&&enteringIds.length>=SECTIONS.prepareJump&&random()<SECTIONS.prepare){
    prepare=current.filter(id=>members.get(id)?.declaration.layer==='beat').map(id=>({id,restAt:start-phraseBars,returnAt:start}));
    if(prepare.length)reasons.push(`the beat drops out for the phrase before ${enteringIds.length} enter together`);
  }
  if(kind==='clear-then-introduce')reasons.push('the stage cleared at the join and the new group brought in one phrase apart, so what is new is heard as new');
  // The new state: felt intensity follows additions and lingers after reductions; fatigue accumulates and decays.
  const realized=group.length/Math.max(1,most);
  const felt=Math.max(realized,SECTIONS.linger*(state.felt||0));
  const fatigue=SECTIONS.fatigue.decay*(state.fatigue||0)+realized*phrases/2;
  return {group,enter,rest,prepare,gesture:{kind,entries,exits},reasons,target,size:group.length,
    considered:best.considered,passing:best.passing,state:{felt,fatigue}};
}
