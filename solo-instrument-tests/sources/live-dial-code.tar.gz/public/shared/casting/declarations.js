// What each bot says it is for, as claims that can be checked (research/casting.md §3). A declaration is built from the
// registry (category, performance type), the census (experiments/setup-phase/capabilities.js, carried in the profile)
// and the bot's measured profile (profiles.js, from scripts/casting-profiles.mjs), with the few claims measurement
// cannot see in CASTING_OVERRIDES, and whatever a bot's own manifest states under `casting`. Every claim names what
// measures it (CLAIMS), and a claim nobody measured is unknown (null), never assumed.
import {PROFILES,PROFILE_METHOD} from './profiles.js';
import {feltLabel,meterKind,meterLabel} from './meters.js';

// Moore's four functional layers of a popular-music texture (the explicit beat, the functional bass, the melody, the
// harmonic filler: Song Means, 2012), and `texture` for the noise and timbre fields his scheme was not made for.
export const LAYERS=Object.freeze(['beat','bass','melody','filler','texture']);
// The layer from the category, through the mixer's own roles (articulation.js CATEGORY_ROLES: melody lead, beat drums,
// bass bass, harmony keys, keys-pads pad, texture texture), so the desk and the casting agree about what a bot is.
export const LAYER_OF_CATEGORY=Object.freeze({beat:'beat',bass:'bass',melody:'melody',harmony:'filler','keys-pads':'filler',
  'texture-noise':'texture',texture:'texture'});
// Where the category says nothing (utility, composition): what the bot's performance type says.
export const LAYER_OF_TYPE=Object.freeze({percussive:'beat',monophonic:'melody',polyphonic:'filler'});

// How many of a layer a group can hold (research/casting.md §3.1). Melody three: for voices of similar timbre,
// listeners' accuracy counting concurrent voices "drops markedly" from three to four (Huron 1989). The rest ours: one
// explicit beat and one functional bass, two of filler and of texture. Ceilings only: the audibility test lowers them.
export const CARRY=Object.freeze({melody:3,beat:1,bass:1,filler:2,texture:2});

// The layers whose parts take a solo the band's attention gives them, unless they say otherwise: the front line, and
// the explicit beat (a drummer's solo). A part of another layer takes one where it says it builds one.
export const SOLOS_BY_LAYER=Object.freeze(['melody','beat']);

// What measurement cannot see, per bot, each with its reason.
export const CASTING_OVERRIDES=Object.freeze({
  // It answers a chosen performer's input with prepared responses; whether it plays is that performer's affair.
  response:Object.freeze({person:true}),
  // Built to interlock with another drummer: two drum parts are its point.
  interlockdrum_clodbot:Object.freeze({carry:2}),
  // A pianist builds a solo where the band's attention gives it one (HearsAttention): its runs toward a climax.
  piano_clodbot:Object.freeze({solos:true}),
  // A guitarist builds one too: its runs toward a climax.
  guitar_clodbot:Object.freeze({solos:true}),
  // A mallet player too: its runs toward a climax, faster there (never quicker than two mallets alternating).
  mallets_clodbot:Object.freeze({solos:true}),
  // A kalimba player too: its figure toward a climax, busier there (never quicker than two thumbs alternating).
  kalimba_clodbot:Object.freeze({solos:true}),
  // A timeline, a shaker and a conga player play in a percussion section: the beat is one layer played by several people, a drummer and
  // up to three hand percussionists (a timeline, a shaker, hand drums), as in a salsa or samba band; the audibility
  // test is what lowers it. Each plays its part through a drum solo rather than taking one.
  timeline_clodbot:Object.freeze({carry:4,solos:false}),
  shaker_clodbot:Object.freeze({carry:4,solos:false}),
  conguero_clodbot:Object.freeze({carry:4,solos:false}),
  // A timpanist too: its figure toward a climax, busier there, its strong beats rolled.
  timpani_clodbot:Object.freeze({solos:true}),
  // A gong player marks the form's arrivals in the percussion section (carry four, as the timeline's), and takes no solo.
  gong_clodbot:Object.freeze({carry:4,solos:false}),
  // A talking drummer plays in a percussion section too, and, a line, makes room for another's entrance itself.
  talkingdrum_clodbot:Object.freeze({carry:4,makesRoom:true}),
  // A harpist builds a solo where the band's attention gives it one: its runs toward a climax.
  harp_clodbot:Object.freeze({solos:true}),
  // An accordionist builds a solo where the band's attention gives it one: its right hand's figure toward a climax.
  accordion_clodbot:Object.freeze({solos:true}),
  // A harpsichordist builds a solo where the band's attention gives it one, as the pianist does.
  harpsichord_clodbot:Object.freeze({solos:true}),
  // A string section's seats are a texture of many, led by its concertmaster: no solos.
  strings_clodbot:Object.freeze({solos:false}),
  // A song's voice: its words decide the piece (form_clodbot), so the band is cast around it and it is never rested,
  // and while it sings, it is the section's foreground (MusebotTV season 2: every episode a song).
  clodbot_singerbot:Object.freeze({sings:true}),
  clodbot_singerbot_en:Object.freeze({sings:true}),
  // Lines that make room for a foreground's entrance themselves (shared/presentation.js): each ends its phrase before an
  // answering silence and rests through it, so ManageBOT never pauses them for one (a pause would drop a phrase midway).
  flute_clodbot:Object.freeze({makesRoom:true}),
  // A steelpan's line makes room for another's entrance too, as the flute's (shared/presentation.js).
  steelpan_clodbot:Object.freeze({makesRoom:true}),
  bowedstring_clodbot:Object.freeze({makesRoom:true}),
  papmelody_clodbot:Object.freeze({makesRoom:true}),
});

// Each claim, and what measures it (in the profile, and live in a room's evidence).
export const CLAIMS=Object.freeze({
  layer:'category, through the mixer roles; cross-checked by register and polyphony',
  register:'the register histogram of its notes (5th-95th percentile, semitones)',
  rate:'onsets per quarter note',
  density:'onsets per felt beat (meter-tactus.js feltBeats)',
  occupancy:'the share of time at least one of its notes sounds',
  polyphony:'notes sounding at once (95th percentile at its onsets)',
  metric:'per meter, energy-weighted onsets on felt beats against chance',
  periodicity:'per meter, onsets recurring one or two felt beats later against chance',
  discreteUpTo:'the quarter-note tempo at which its median inter-onset interval reaches 100 ms',
  spectrum:'energy per desk band, estimated from its notes',
  needs:'harmony: measured by taking the harmony source away (profiles.js harmony); the rest from the census',
  provides:'the census (what it publishes); in a room, the plans and pools it is heard to publish',
  carry:'Huron 1989 for melody, ours for the rest; lowered by the audibility test',
  person:'the registry: it stands for a performer and is never cast',
  solos:'its layer (SOLOS_BY_LAYER), or what it says of itself: a solo it builds where the band\'s attention gives it one',
  sings:'the registry: a song\'s voice, cast around and never rested, the foreground while it sings',
  makesRoom:'the registry: it makes room for a foreground\'s entrance itself (shared/presentation.js), never paused for one',
});

// Whether it follows harmony is measured, where it could be, by taking the harmony source away (profiles.js `harmony`:
// its notes' fit to the source's pools with the source and without it). At or above FOLLOWS it needs harmony; below it,
// not, whatever the census inferred from its description. Ours as a threshold; measured cases in research/casting.md
// §4 (the census had contour and ornament not needing harmony, which they follow at .78, and rhodes needing it, which
// it follows at .16).
export const FOLLOWS=.3;
function needsOf(census,profile){
  const inferred=[...(census?.requires??[])],follows=profile?.harmony?.follows;
  if(!Number.isFinite(follows))return inferred;
  const others=inferred.filter(need=>need!=='harmony');
  return follows>=FOLLOWS?['harmony',...others]:others;
}

// A bot that articulates the felt beats somewhere (its best measured meter at or above ARTICULATES) is metrically lost
// in a meter where its index falls under LOST_SHARE of that best, or under LOST_FLOOR. Ours; measured cases in
// research/casting.md §4: the ported walking bass is 1 in 4/4 and below chance in 5/8.
//
// Being lost rules a bot out only in the layers whose job is to articulate the beat -- the explicit beat and the
// functional bass (Moore) -- and weighs against the rest: a pad or a line off the felt beats is syncopation, a style,
// and ruling out a harmony source for it ruled out everything that follows its harmony (12/8, where the ported
// harmony bots change chords off the dotted quarters, was cast with three bots all piece long).
export const METRIC=Object.freeze({articulates:.6,lostShare:.25,lostFloor:.15,strictLayers:Object.freeze(['beat','bass'])});
export const lostRulesOut=declaration=>METRIC.strictLayers.includes(declaration?.layer);

const frozen=value=>value&&typeof value==='object'?Object.freeze(value):value;

// The declaration of one bot. `known` is what a caller knows of it where the registry is not to hand (a room's
// agentState: category, functionGroup, name; or a definition, with its own `casting`).
export function declarationOf(id,known={},{profiles=PROFILES}={}){
  const profile=profiles[id]&&!profiles[id].error?profiles[id]:null,override=CASTING_OVERRIDES[id]||{},stated=known.casting||{};
  const category=known.category??profile?.category??null,type=known.performanceType??known.functionGroup??profile?.performanceType??null;
  const layer=stated.layer??override.layer??LAYER_OF_CATEGORY[category]??LAYER_OF_TYPE[type]??null;
  const census=profile?.census;
  return Object.freeze({
    id,name:known.name??profile?.name??id,category,performanceType:type,
    measured:Boolean(profile),
    layer,
    carry:stated.carry??override.carry??(layer?CARRY[layer]:null),
    person:Boolean(stated.person??override.person),
    sings:Boolean(stated.sings??override.sings),
    makesRoom:Boolean(stated.makesRoom??override.makesRoom),
    solos:Boolean(stated.solos??override.solos??SOLOS_BY_LAYER.includes(layer)),
    register:frozen(profile?.register??null),
    rate:frozen(profile?.rate??null),
    density:frozen(profile?.density??null),
    perSecond:frozen(profile?.perSecond??null),
    perBar:frozen(profile?.perBar??null),
    // The unit it plays by, of those four (casting-profiles.mjs), by which fit.js onsetRate says what it adds at a tempo.
    pace:profile?.pace??null,
    occupancy:frozen(profile?.occupancy??null),
    polyphony:profile?.polyphony??null,
    drums:profile?.drums??(layer==='beat'),
    discreteUpTo:profile?.discreteUpTo??null,
    metric:frozen(profile?.metric??{}),
    metricFelt:frozen(profile?.metricFelt??{}),
    metricByKind:frozen(profile?.metricByKind??{}),
    periodicity:frozen(profile?.periodicity??{}),
    spectrum:frozen(profile?.spectrum??null),
    needs:Object.freeze([...(stated.needs??needsOf(census,profile))]),
    follows:profile?.harmony?.follows??null,
    provides:Object.freeze([...(stated.provides??census?.provides??[])]),
    defers:Object.freeze([...(census?.defers??[])]),
    heldOut:frozen(profile?.heldOut??{}),
    source:Object.freeze({profile:profile?'scripts/casting-profiles.mjs':null,overrides:Object.keys(override),stated:Object.keys(stated)}),
  });
}

// Every profiled bot's declaration, by id.
export function declarations({profiles=PROFILES}={}){
  return Object.freeze(Object.fromEntries(Object.keys(profiles).map(id=>[id,declarationOf(id,{},{profiles})])));
}

// Its metric index in a meter: measured in that meter as it is felt at this tempo (meters.js feltLabel; `secondsPerTick`
// the clock's tick there) if it was; else in that meter at any tempo, the mean; else the mean over the meters of its
// kind; else null.
export function metricIn(declaration,meter,{secondsPerTick=null}={}){
  if(secondsPerTick>0){
    const felt=declaration?.metricFelt?.[feltLabel(meter,{secondsPerTick})];
    if(Number.isFinite(felt))return felt;
  }
  const exact=declaration?.metric?.[meterLabel(meter)];
  if(Number.isFinite(exact))return exact;
  const byKind=declaration?.metricByKind?.[meterKind(meter)];
  return Number.isFinite(byKind)?byKind:null;
}
export function bestMetric(declaration){
  const values=Object.values(declaration?.metric||{}).filter(Number.isFinite);
  return values.length?Math.max(...values):null;
}
// Whether it is metrically lost in this meter (METRIC above), and why, or null when it cannot be said. At the tempo
// where it is known (`secondsPerTick`), as the meter is felt there.
export function lostIn(declaration,meter,{secondsPerTick=null}={}){
  const best=bestMetric(declaration),here=metricIn(declaration,meter,{secondsPerTick});
  if(!Number.isFinite(best)||!Number.isFinite(here)||best<METRIC.articulates)return null;
  const lost=here<Math.max(METRIC.lostFloor,best*METRIC.lostShare);
  return lost?{lost:true,best,here,because:`${declaration.name} places ${here.toFixed(2)} of its accents on the felt beats in `
    +`${meterLabel(meter)} against ${best.toFixed(2)} where it articulates them best`}:{lost:false,best,here};
}

// The claims as short lines, with what measures each: for the plan's reasons, the digest and a reader.
export function claimsOf(declaration){
  const lines=[];
  if(declaration.layer)lines.push(['layer',declaration.layer]);
  if(declaration.register)lines.push(['register',`${declaration.register.low}-${declaration.register.high}`]);
  if(declaration.rate)lines.push(['rate',`${declaration.rate[0]}-${declaration.rate[1]} per quarter`]);
  if(declaration.needs.length)lines.push(['needs',declaration.needs.join(', ')]);
  if(declaration.provides.length)lines.push(['provides',declaration.provides.join(', ')]);
  if(declaration.person)lines.push(['person','stands for a performer']);
  return lines.map(([claim,value])=>({claim,value,measuredBy:CLAIMS[claim]}));
}

export {PROFILE_METHOD};
