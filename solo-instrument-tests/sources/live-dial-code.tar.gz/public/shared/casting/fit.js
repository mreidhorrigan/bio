// Whether a group of bots can play together, claim by claim (research/casting.md §3, §5.3, §6.4). A group is a list of
// members {id, declaration, spectrum?, heard?}: `id` its instance, `declaration` from declarations.js, `spectrum` its
// band shares (evidence.js spectrum(): the desk's, the room's notes, or the profile's), `heard` what the room measured
// of it. Every check returns its reasons in words, so a casting decision can say what it rested on.
import {AUTO_MIX} from '../../../experiments/mix-desk/auto-mix.js';
import {feltBeats} from '../meter-tactus.js';
import {lostIn,lostRulesOut} from './declarations.js';

export const FIT=Object.freeze({
  // The miscast test uses the desk's own thresholds (auto-mix.js AUTO_MIX), so the Mixbot and the casting agree about
  // what burying means: present in a band at 5% of its energy, buried there 6 dB under the sum of the others, and
  // the dominant masker holding 40% of the band.
  presentShare:AUTO_MIX.presentShare,maskedDb:AUTO_MIX.maskedDb,dominantShare:AUTO_MIX.dominantShare,
  // "a bot that can only be heard by burying two others" (RESEARCH_BACKLOG.md, casting): two victims, each of whom X
  // buries most of (at least half its energy lies in bands where it is buried and X holds the dominant share). Burying
  // a stray corner of a part that is heard elsewhere is not burying it. The half is ours.
  buriedCount:2,victimShare:.5,
  // The needs a group must meet itself: harmony, whose absence has been measured (the census's "harmonically
  // disorganised chaos") and whose following is measured per bot (declarations.js FOLLOWS). The census's form need is
  // left as advice here: it is inferred from prose ("opens over the phrase"), and what form's absence was measured to
  // cost is a harmony source looping one section, which casting does not change. Tuning and pulse are advice there too.
  blocking:Object.freeze(['harmony']),
});

// Needs no member meets and no silent provider in the room covers. `silent`: faculties the room has from bots that are
// never cast (message-only providers, a listening bot leading the harmony).
export function unmetNeeds(members,{silent=[]}={}){
  const provided=new Set([...silent,...members.flatMap(member=>member.declaration.provides)]),unmet=[];
  for(const member of members)for(const need of member.declaration.needs)
    if(FIT.blocking.includes(need)&&!provided.has(need))
      unmet.push({id:member.id,need,because:`${member.declaration.name} follows ${need} and nobody in this group or the room publishes it`});
  return unmet;
}

// Layers holding more members than any of them allows (declarations.js CARRY; a member built to share its layer,
// like the interlocking drummer, allows more).
export function carryExceeded(members){
  const layers=new Map;
  for(const member of members){const layer=member.declaration.layer;if(layer)(layers.get(layer)||layers.set(layer,[]).get(layer)).push(member)}
  const over=[];
  for(const [layer,list] of layers){
    const allowed=Math.max(...list.map(member=>member.declaration.carry??Infinity));
    if(list.length>allowed)over.push({layer,count:list.length,allowed,ids:list.map(member=>member.id),
      because:`${list.length} in the ${layer} layer where ${allowed} ${allowed===1?'is':'are'} carried`});
  }
  return over;
}

// The audibility test (research/casting.md §5.3), on the members whose spectra are known. A spectrum is energy per
// band, as shares summing to one, whether it is an estimate from notes or a profile or the desk's measurement (the
// desk publishes its levels apart, in `levels`): so every part is weighed at the same loudness, which is what the
// Mixbot's fader balance brings parts toward (Mansbridge, Finn & Reiss 2012), and measured and estimated members
// compare alike. Returns the members buried in every band they occupy, and the miscast: members heard only where they
// bury others, burying most of two or more.
//
// Decided on exact values, with the desk's thresholds but not its rounding: the desk's report (auto-mix.js maskingOf)
// rounds presence and share to a thousandth and decibels to a hundredth for reading, and near a threshold that flips a
// decision (the mathematics agent's review, research/math-problems/casting-audible-groups.solution.md §7). The
// definitions are that answer's (its equation 9): with e the energies, L each member's total and T each band's,
//   i is present in b    when e_ib > 0 and e_ib >= p L_i                     (p: presentShare)
//   i is heard in b      when present and T_b - e_ib < mu e_ib               (mu: maskedDb as an energy ratio)
//   i buries j in b      when j is present and not heard there, and e_ib >= .4 (T_b - e_jb)   (dominantShare)
//   j is i's victim      when the bands where i buries it hold at least half of j's energy
//   i is miscast         when it has two victims or more and every band it is heard in buries one of them.
// Miscasting is possible at equal loudness: a part need not supply all of a masking sum to hold its dominant share,
// and that answer gives four normalized parts where one is miscast (test/casting-sections.test.mjs).
export const MASKING_RATIO=10**(FIT.maskedDb/10);
export function audibility(members){
  const known=members.filter(member=>Array.isArray(member.spectrum)&&member.spectrum.some(value=>value>0));
  if(known.length<2)return {buried:[],miscast:[],checked:known.length};
  const bands=Math.min(...known.map(member=>member.spectrum.length));
  const e=known.map(member=>member.spectrum.slice(0,bands).map(value=>Math.max(0,Number(value)||0)));
  const L=e.map(row=>row.reduce((sum,value)=>sum+value,0));
  const T=Array.from({length:bands},(_,band)=>e.reduce((sum,row)=>sum+row[band],0));
  const present=(i,b)=>e[i][b]>0&&e[i][b]>=FIT.presentShare*L[i];
  const heard=(i,b)=>present(i,b)&&T[b]-e[i][b]<MASKING_RATIO*e[i][b];
  // The .4 and .5 tests multiplied out (5e >= 2(T - e), 2 sum >= L), so no decimal fraction stands in a comparison.
  const buries=(i,j,b)=>present(j,b)&&!heard(j,b)&&5*e[i][b]>=2*(T[b]-e[j][b]);
  const buried=[],miscast=[];
  for(let i=0;i<known.length;i++){
    const presentBands=[],heardBands=[];
    for(let b=0;b<bands;b++){if(present(i,b))presentBands.push(b);if(heard(i,b))heardBands.push(b)}
    if(presentBands.length&&!heardBands.length){
      buried.push({id:known[i].id,because:`${known[i].declaration.name} is buried ${FIT.maskedDb} dB or more in every band it plays in`});
      continue;
    }
    if(!heardBands.length)continue;
    const victims=[];
    for(let j=0;j<known.length;j++){
      if(j===i)continue;
      let share=0;for(let b=0;b<bands;b++)if(buries(i,j,b))share+=e[j][b];
      if(2*share>=L[j]&&L[j]>0)victims.push(j);
    }
    if(victims.length<FIT.buriedCount)continue;
    if(heardBands.every(b=>victims.some(j=>buries(i,j,b))))
      miscast.push({id:known[i].id,buries:victims.map(j=>known[j].id),because:`${known[i].declaration.name} is heard only where it buries `
        +`${victims.map(j=>known[j].declaration.name).join(' and ')}: miscast rather than mismixed`});
  }
  return {buried,miscast,checked:known.length};
}

// Members metrically lost in this meter (declarations.js lostIn): articulating the felt beats elsewhere, not here.
// `strict`: only those in the layers it rules out (the beat and the bass); the rest are weighed, not refused.
// `secondsPerTick`: the clock's tick at the tempo it is played, where known, so the meter is asked as it is felt.
export function metricallyLost(members,meter,{strict=true,secondsPerTick=null}={}){
  if(!meter)return [];
  return members.filter(member=>!strict||lostRulesOut(member.declaration))
    .map(member=>({member,lost:lostIn(member.declaration,meter,{secondsPerTick})})).filter(entry=>entry.lost?.lost)
    .map(entry=>({id:entry.member.id,because:entry.lost.because}));
}

// How much the pitched members crowd each other's registers, lower registers counting more, after Huron's spacing
// principle for low voices ("Tone and voice", 2001): the sum over pairs of their shared semitones, each weighted by how
// far below middle C its middle lies. 0 for no overlap. Ours as a number; the principle is his.
export function registerCrowding(members){
  const pitched=members.map(member=>member.heard?.register??member.declaration.register).filter(Boolean);
  let crowding=0;
  for(let a=0;a<pitched.length;a++)for(let b=a+1;b<pitched.length;b++){
    const low=Math.max(pitched[a].low,pitched[b].low),high=Math.min(pitched[a].high,pitched[b].high);
    if(high<=low)continue;
    const middle=(low+high)/2;crowding+=(high-low)*(1+Math.max(0,(60-middle)/12));
  }
  return crowding;
}

// How long one unit of a pace lasts at this tempo and meter, in seconds: a quarter, a second, a bar, or a felt beat (the
// mean of the bar's, meter-tactus.js feltBeats). The units a profile's pace is measured in (casting-profiles.mjs).
export function paceSeconds(unit,{quarterBpm=100,meter}){
  const quarter=60/(Number(quarterBpm)||100);
  if(unit==='perSecond')return 1;
  if(unit==='rate')return quarter;
  const numerator=Number(meter.numerator)||1,bar=numerator*4/(Number(meter.denominator)||4)*quarter;
  if(unit==='perBar')return bar;
  const groups=Array.isArray(meter.groups)&&meter.groups.length?meter.groups.reduce((a,b)=>a+b,0):numerator;
  const ticks=Number(meter.pulsesPerBar)||groups*(Number(meter.subdivision)||4);
  return bar/Math.max(1,feltBeats(meter,{secondsPerTick:bar/ticks}).length);
}

// The expected onsets per second a member adds at this tempo and meter: what the room heard of it, else its profile's
// mid pace in the unit it plays by, over that unit's length here (a texture's onsets a second stay as they are at any
// tempo; a pad's onsets a bar thin as the bar grows). A profile naming no unit, or one by the bar or the felt beat with
// no meter to measure them by, goes by its rate a quarter.
export function onsetRate(member,{quarterBpm=100,meter=null}={}){
  const heard=member.heard?.rate;
  if(Number.isFinite(heard))return heard*quarterBpm/60;
  const declaration=member.declaration,pace=declaration.pace;
  const unit=pace&&declaration[pace]&&(meter||pace==='rate'||pace==='perSecond')?pace:'rate',range=declaration[unit];
  return range?(range[0]+range[1])/2/paceSeconds(unit,{quarterBpm,meter}):0;
}

// Every hard check at once: whether the group may be cast at all, and the reasons it may not.
export function hardChecks(members,{silent=[],meter=null,declined=new Set,secondsPerTick=null}={}){
  const unmet=unmetNeeds(members,{silent}),carry=carryExceeded(members),heard=audibility(members),lost=metricallyLost(members,meter,{secondsPerTick});
  const refusing=members.filter(member=>declined.has(member.id)).map(member=>({id:member.id,because:`${member.declaration.name} declined`}));
  const problems=[...unmet,...carry,...heard.buried,...heard.miscast,...lost,...refusing];
  return {ok:problems.length===0,unmet,carry,buried:heard.buried,miscast:heard.miscast,lost,refusing,problems};
}
