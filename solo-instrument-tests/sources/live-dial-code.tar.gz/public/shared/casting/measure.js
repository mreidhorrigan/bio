// What a bot's notes say about it, for casting (research/casting.md §3-§5): its register, how many onsets it plays
// per felt beat, how much of the time it is sounding, how many notes at once, whether its onsets carry a pulse, where
// they fall in the bar, and a spectrum estimated from them. The same arithmetic measures a bot offline, in
// scripts/casting-profiles.mjs, and live, in a room's evidence (evidence.js), so a claim made from one is checked by
// the other in the same units.
//
// A note here is {pitch, velocity, start, duration, drum}: pitch in floating semitones (MIDI numbers, 1/512 of a
// semitone where the bot bends), velocity 0..1, start and duration in seconds, drum a General MIDI percussion note or
// null for a pitched note.
import {AUTO_MIX} from '../../../experiments/mix-desk/auto-mix.js';
import {pieceForNote} from '../percussion-expression.js';
import {kitChannelOf} from '../kit-channels.js';
import {feltLabel,meterKind,meterLabel} from './meters.js';

// The desk's bands, so an estimated spectrum and the desk's masking metric speak of the same regions.
export const CASTING_BANDS=AUTO_MIX.bands;
export const BAND_COUNT=CASTING_BANDS.length-1;

export const MEASURE=Object.freeze({
  // Onsets closer than this are one event: a chord's notes, a flam's two strokes. The pulse bot's own figure
  // (experiments/pulse-coupling/pulse-bot.js chordWindowMs, 40 ms) less the 10 ms its analyzer adds for jitter.
  chordSeconds:.03,
  // The shortest inter-onset interval heard as a series of separate events rather than a flutter: about 100 ms, the
  // lower limit London gives for a period that can carry a beat (Hearing in Time, 2nd ed., 2012, ch. 2).
  discreteSeconds:.1,
  // The partials of a pitched note in the estimated spectrum: amplitude 1/k (a sawtooth's), up to this many and below
  // the top band. Ours: a patch's real spectrum is unknown here, and a desk-measured one replaces this when there is one.
  partials:32,
  // A drum stroke's energy counts for at least this long and at most this long, whatever its written duration: a drum
  // note's duration is a gate, not the ring. Ours.
  drumSeconds:[.05,.6],
  // Percentiles a range claim is made of: the middle 90% of what was measured.
  low:.05,high:.95,
});

// Each kit channel's share of energy in each band (kit-channels.js channels), ours and rough: the kick low, the snare
// and toms low-mid to presence, cymbals and hats high. Enough to say that a kick and a bass share the bottom octave
// and a hat and a lead do not.
export const DRUM_BANDS=Object.freeze({
  kick: Object.freeze([.35,.35,.15,.07,.04,.02,.01,.005,.005]),
  snare:Object.freeze([.02,.08,.18,.2,.18,.14,.1,.06,.04]),
  toms: Object.freeze([.05,.2,.3,.2,.12,.07,.04,.01,.01]),
  hats: Object.freeze([0,0,0,.01,.03,.06,.15,.35,.4]),
  ride: Object.freeze([0,0,.01,.03,.06,.12,.25,.3,.23]),
  crash:Object.freeze([0,0,.01,.03,.06,.12,.22,.3,.26]),
  hands:Object.freeze([.02,.12,.25,.25,.18,.1,.05,.02,.01]),
  perc: Object.freeze([0,.02,.05,.1,.18,.22,.2,.15,.08]),
});

const finite=value=>Number.isFinite(value);
const round=(value,places=3)=>finite(value)?Math.round(value*10**places)/10**places:null;
// The q-quantile of sorted values, linearly interpolated (the R-7 definition).
export function quantile(sorted,q){
  if(!sorted.length)return null;
  const at=(sorted.length-1)*Math.min(1,Math.max(0,q)),below=Math.floor(at),above=Math.ceil(at);
  return sorted[below]+(sorted[above]-sorted[below])*(at-below);
}

export const frequencyOf=pitch=>440*2**((pitch-69)/12);
export const bandOf=hertz=>{
  if(!(hertz>=CASTING_BANDS[0])||hertz>=CASTING_BANDS.at(-1))return -1;
  let band=0;while(band+1<BAND_COUNT&&hertz>=CASTING_BANDS[band+1])band++;return band;
};

// Register: the pitched notes' range, as percentiles and extremes. Drums have no register here.
export function registerOf(notes){
  const pitches=notes.filter(note=>note.drum==null&&finite(note.pitch)).map(note=>note.pitch).sort((a,b)=>a-b);
  if(!pitches.length)return null;
  return {low:round(quantile(pitches,MEASURE.low)),median:round(quantile(pitches,.5)),high:round(quantile(pitches,MEASURE.high)),
    min:round(pitches[0]),max:round(pitches.at(-1)),count:pitches.length};
}

// The distinct onsets, chords and flams counted once.
export function onsetsOf(notes,{chordSeconds=MEASURE.chordSeconds}={}){
  const starts=notes.map(note=>note.start).filter(finite).sort((a,b)=>a-b),onsets=[];
  for(const start of starts)if(!onsets.length||start-onsets.at(-1)>=chordSeconds)onsets.push(start);
  return onsets;
}

// The share of a span during which at least one note sounds.
export function occupancyOf(notes,span){
  if(!(span>0))return null;
  const spans=notes.filter(note=>finite(note.start)&&note.duration>0).map(note=>[note.start,note.start+note.duration]).sort((a,b)=>a[0]-b[0]);
  let covered=0,from=null,to=null;
  for(const [start,end] of spans){
    if(from===null||start>to){if(from!==null)covered+=to-from;from=start;to=end}else to=Math.max(to,end);
  }
  if(from!==null)covered+=to-from;
  return round(Math.min(1,covered/span));
}

// How many notes sound at once: the most, and the 95th percentile over the moments a note begins.
export function polyphonyOf(notes){
  const events=[];
  for(const note of notes)if(finite(note.start)&&note.duration>0)events.push([note.start,1],[note.start+note.duration,-1]);
  events.sort((a,b)=>a[0]-b[0]||a[1]-b[1]);
  let sounding=0,most=0;const atOnsets=[];
  for(const [,step] of events){sounding+=step;if(step>0){atOnsets.push(sounding);most=Math.max(most,sounding)}}
  atOnsets.sort((a,b)=>a-b);
  return {max:most,typical:atOnsets.length?Math.round(quantile(atOnsets,MEASURE.high)):0};
}

// The intervals between onsets, in seconds: the shortest usual (5th percentile) and the median.
export function intervalsOf(onsets){
  const intervals=[];for(let index=1;index<onsets.length;index++)intervals.push(onsets[index]-onsets[index-1]);
  intervals.sort((a,b)=>a-b);
  return {intervals,short:intervals.length?quantile(intervals,MEASURE.low):null,median:intervals.length?quantile(intervals,.5):null};
}

// The tempo up to which a bot's attacks stay separate, in quarter notes a minute, from its median interval: at a tempo
// where half its intervals fall under MEASURE.discreteSeconds its surface is a flutter rather than a series of events
// (the median, because a roll or a flam is an ornament, not the surface). Quarter notes, because the clock's bpm
// counts the notated beat (an eighth in 7/8), and a claim made in one meter is checked in another. A description, for
// the listening modes of research/MUSEBOTS_EXTREME_AESTHETICS...md §2, not a reason to decline. Null when it has too
// few onsets to say.
export function discreteUpTo(onsets,{quarterBpm}){
  const {median}=intervalsOf(onsets);
  if(!(median>0)||!(quarterBpm>0)||onsets.length<4)return null;
  // The interval scales as 1/tempo, so it reaches MEASURE.discreteSeconds at quarterBpm * median / discreteSeconds.
  return Math.round(quarterBpm*median/MEASURE.discreteSeconds);
}
export const quarterBpmOf=(bpm,meter)=>bpm*4/(Number(meter?.denominator)||4);
export {feltLabel,meterKind,meterLabel};


// Whether a stream of onsets carries a pulse: how often an onset recurs one or two felt beats later (within half a
// tick), against the chance that it would on the tick grid at the same rate. 1 for a stream that repeats at the beat
// or every two beats (steady beats, eighths, swing, a 3+3+2 figure), about 0 for random onsets, null where it cannot
// say (too few onsets, or every tick filled). Phase-free, since a live phrase capture has lost its offset in the bar.
//
// Not PulseCoupler's confidence, though the backlog item named it: measured on 20 seeds of random onsets its mean
// confidence over a stream reached .61 (its last reading .80), and a 3+3+2 figure that plainly carries a pulse read
// 0. It follows a player's beat-level onsets, which is what it is for; it does not say whether a pattern is pulsed
// (research/casting.md §5.1).
// The periodicity at and above which casting says a bot's onsets carry a pulse. Ours: under chance the measure spreads
// about ±.15 over the four phrases a room's evidence pools, so .5 is past three spreads.
export const PULSED=.5;
export function periodicityOf(onsets,{beatSeconds,tickSeconds}){
  const count=onsets.length;
  if(count<4||!(beatSeconds>0)||!(tickSeconds>0))return null;
  const tolerance=tickSeconds/2,end=onsets.at(-1);
  let eligible=0,recurring=0;
  for(let index=0;index<count;index++){
    if(onsets[index]+2*beatSeconds>end+tolerance)break;
    eligible++;
    for(let later=index+1;later<count&&onsets[later]<=onsets[index]+2*beatSeconds+tolerance;later++){
      const gap=onsets[later]-onsets[index];
      if(Math.abs(gap-beatSeconds)<=tolerance||Math.abs(gap-2*beatSeconds)<=tolerance){recurring++;break}
    }
  }
  if(eligible<3)return null;
  // The chance an onset has another at either of the two places, were onsets spread over the grid at this rate.
  const span=Math.max(tickSeconds,end-onsets[0]),occupied=Math.min(1,count*tickSeconds/span),chance=1-(1-occupied)**2;
  return chance>=1?null:round((recurring/eligible-chance)/(1-chance));
}

// Where onsets fall in the bar, against the felt beats: 1 when every onset is on a felt beat, 0 at chance (onsets
// spread evenly over the bar's ticks), negative when felt beats are avoided. Each onset counts by its energy (the sum
// of its notes' velocity²), so a drummer's kick on the beat outweighs the soft hats between: a kit that fills every
// tick still says where its accents are. `positions` are onsets' ticks into their bar, or {tick, weight}; `beats` the
// felt-beat starts in ticks (meter-tactus.js feltBeats); `pulses` the bar's ticks.
export function metricIndex(positions,{beats,pulses}){
  if(!positions.length||!beats?.length||!(pulses>0))return null;
  const starts=new Set(beats.map(beat=>beat.start));
  let on=0,total=0;
  for(const position of positions){
    const tick=typeof position==='number'?position:position.tick,weight=typeof position==='number'?1:Math.max(0,Number(position.weight)||0);
    total+=weight;if(starts.has(tick))on+=weight;
  }
  const chance=Math.min(1,starts.size/pulses);
  return chance>=1||!(total>0)?null:round((on/total-chance)/(1-chance));
}

// A spectrum estimated from notes: energy per band, and each band's share. Each pitched note a harmonic tone of
// velocity² × duration, partial k at k·f0 with power 1/k²; each drum stroke its kit channel's band shares at the same
// weight, its duration held within MEASURE.drumSeconds. Labelled 'notes' by its callers: it is an estimate.
export function spectrumOf(notes){
  const energy=new Array(BAND_COUNT).fill(0);
  for(const note of notes){
    const velocity=finite(note.velocity)?Math.max(0,note.velocity):.7,duration=Math.max(0,Number(note.duration)||0);
    if(note.drum!=null){
      const held=Math.min(MEASURE.drumSeconds[1],Math.max(MEASURE.drumSeconds[0],duration)),weight=velocity*velocity*held;
      const shares=DRUM_BANDS[kitChannelOf(pieceForNote(note.drum))]||DRUM_BANDS.perc;
      for(let band=0;band<BAND_COUNT;band++)energy[band]+=weight*shares[band];
      continue;
    }
    if(!finite(note.pitch)||!(duration>0))continue;
    const f0=frequencyOf(note.pitch),weight=velocity*velocity*duration;
    for(let k=1;k<=MEASURE.partials;k++){
      const band=bandOf(k*f0);if(band<0){if(k*f0>=CASTING_BANDS.at(-1))break;continue}
      energy[band]+=weight/(k*k);
    }
  }
  const total=energy.reduce((sum,value)=>sum+value,0);
  return {energy,shares:energy.map(value=>total>0?round(value/total,4):0),total};
}

// Everything above for one bot's notes over a span. `beatSeconds`: the felt beat; `tickSeconds`: the clock's tick;
// `quarterBpm`: the tempo in quarter notes; `positions`, `beats`, `pulses`: for the metric index, when the bar positions
// are known (offline they are; a live phrase capture has lost them).
export function measureNotes(notes,{span,beatSeconds,tickSeconds,quarterBpm,positions=null,beats=null,pulses=null,bars=null}={}){
  const onsets=onsetsOf(notes),feltBeats=span>0&&beatSeconds>0?span/beatSeconds:null,quarters=span>0&&quarterBpm>0?span*quarterBpm/60:null;
  return {
    notes:notes.length,onsets:onsets.length,
    register:registerOf(notes),
    // Onsets per felt beat (how busy against the pulse it is heard in) and per quarter note (a rate that a change of
    // felt-beat level at a faster tempo does not jump), per second (a pace that follows neither: a texture's, a bot that
    // plays by the clock's seconds) and per bar (a pad's or a follower's, that changes with the bar or the chord).
    density:feltBeats?round(onsets.length/feltBeats):null,
    rate:quarters?round(onsets.length/quarters):null,
    perSecond:span>0?round(onsets.length/span):null,
    perBar:bars>0?round(onsets.length/bars):null,
    // The render's length in each of those units, for how many onsets a pace expects over it.
    lengths:{density:feltBeats,rate:quarters,perSecond:span>0?span:null,perBar:bars>0?bars:null},
    occupancy:occupancyOf(notes,span),
    polyphony:polyphonyOf(notes),
    periodicity:periodicityOf(onsets,{beatSeconds,tickSeconds}),
    discreteUpTo:discreteUpTo(onsets,{quarterBpm}),
    metric:positions?metricIndex(positions,{beats,pulses}):null,
    spectrum:spectrumOf(notes).shares,
    drums:notes.some(note=>note.drum!=null),
  };
}
