// What a room measures, held for casting (research/casting.md §5). Fed every protocol message and the clock; its
// memory is bounded (a few phrases per performer, a capped roster) however long the piece.
//
// **What each performer played** comes from the room's own traffic: every sounding bot's host sends the notes of its
// last phrase to `/agent/memory/store` at each phrase start (UmpMotifCapture), and the server relays every message to
// the whole room. Large captures arrive in chunks (`/agent/memory/transfer`), reassembled here as an observer. A
// capture's times are relative to its first note -- the host drops the phrase offset -- so what is measured from it
// is phase-free: register, onsets, rates, occupancy, polyphony, periodicity, spectrum. Where a note sits in the bar is
// the profile's to say (declarations.js metricIn).
import {MemoryTransfers} from '../memory-transfer.js';
import {inspectUMP} from '../ump.js';
import {feltBeats,secondsPerTick} from '../meter-tactus.js';
import {measureNotes,quarterBpmOf} from './measure.js';

export const EVIDENCE=Object.freeze({
  phrases:4,              // the phrases kept per performer: enough for the periodicity to settle (measure.js PULSED)
  maxNotes:1024,          // per phrase, beyond which a capture is cut
  maxPerformers:64,
  percussionChannel:9,    // General MIDI's
  harmonyBars:8,          // harmony counts as published if a plan or a pool arrived within this many bars
});

const velocityOf=value=>Math.max(0,Math.min(1,(Number(value)||0)/65535));

// The notes of one phrase capture: [{pitch, velocity, start, duration, drum}] in seconds from its first note.
export function notesOfCapture(motif,{maxNotes=EVIDENCE.maxNotes}={}){
  const events=Array.isArray(motif?.events)?motif.events:[],tpq=Number(motif?.timebase?.ticksPerQuarterNote)||0;
  const quarterBpm=Number(motif?.metadata?.defaultBpm)||0;
  if(!events.length||!(tpq>0)||!(quarterBpm>0))return [];
  const secondsPerTickHere=60/quarterBpm/tpq,open=new Map,notes=[];
  for(const event of events){
    let inspected;try{inspected=inspectUMP(event.packet)}catch{continue}
    const time=(Number(event.time)||0)*secondsPerTickHere;
    if(inspected.kind==='noteOn'&&inspected.velocity>0){
      if(notes.length>=maxNotes)break;
      const note={pitch:inspected.pitch,velocity:velocityOf(inspected.velocity),start:time,duration:0,
        drum:inspected.channel===EVIDENCE.percussionChannel?inspected.note:null};
      notes.push(note);
      (open.get(inspected.key)||open.set(inspected.key,[]).get(inspected.key)).push(note);
    }else if(inspected.kind==='noteOff'||inspected.kind==='noteOn'){
      const note=open.get(inspected.key)?.shift();
      if(note)note.duration=Math.max(0,time-note.start);
    }
  }
  // A note the capture never closed rang to the end of the phrase as far as anyone can tell: give it until the last
  // event, which undercounts rather than invents.
  const last=events.length?(Number(events.at(-1).time)||0)*secondsPerTickHere:0;
  for(const pending of open.values())for(const note of pending)if(!(note.duration>0))note.duration=Math.max(0,last-note.start);
  return notes;
}

export class RoomEvidence {
  constructor({phrases=EVIDENCE.phrases}={}){
    this.phrases=phrases;
    this.roster=new Map();       // instanceId -> {instanceId, definitionId, name, category, functionGroup, state, messageOnly, since, restedAt}
    this.heard=new Map();        // instanceId -> [{notes, span, bar}], the last phrases
    this.transfers=new MemoryTransfers();
    this.harmonyAt=null;         // the bar harmony was last published
    this.harmonyAuthors=new Set();
    this.clock={};
    this.desk=null;              // the desk's last analysis carrying spectra (band shares), and its levels, if it publishes them
  }
  tick(clock={}){this.clock=clock||{}}
  get bar(){return Number(this.clock?.bar)||0}

  observe(message){
    const address=message?.address;if(typeof address!=='string')return;
    const payload=message.args?.[0];
    if(address==='/broadcast/agentState'&&payload?.instanceId)return this.state(payload);
    if(address==='/agent/memory/transfer'){
      let whole;try{whole=this.transfers.accept(message)}catch{return}
      if(whole)this.observe(whole);
      return;
    }
    if(address==='/agent/memory/store'&&payload?.motif)return this.capture(payload.motif);
    if(address==='/broadcast/plan'&&payload?.kind==='harmony'){this.harmonyAt=this.bar;if(payload.author)this.harmonyAuthors.add(String(payload.author));return}
    if(/\/(?:notepool|plan\/chords)$/.test(address)){this.harmonyAt=this.bar;return}
    // Its levels (dB under the loudest bot) are kept beside the shares but not read by the audibility test, which weighs
    // every part at the same loudness (fit.js audibility).
    if(address==='/broadcast/analysis'&&payload?.source==='mix-desk'&&payload.spectra&&typeof payload.spectra==='object')
      this.desk={at:this.bar,spectra:payload.spectra,...(payload.levels&&typeof payload.levels==='object'?{levels:payload.levels}:{})};
  }
  state(value){
    const previous=this.roster.get(value.instanceId);
    if(!previous&&this.roster.size>=EVIDENCE.maxPerformers)return;
    const performing=value.state==='performing',was=previous?.state==='performing';
    this.roster.set(value.instanceId,{...previous,instanceId:value.instanceId,definitionId:value.definitionId??previous?.definitionId,
      name:value.name??previous?.name,category:value.category??previous?.category,functionGroup:value.functionGroup??previous?.functionGroup,
      // (A bot that says it has no outputs is message-only, whether or not it says so: the network host's ConductorBot.)
      messageOnly:Boolean(value.messageOnly??(Array.isArray(value.outputModes)&&!value.outputModes.length?true:previous?.messageOnly)),state:value.state,
      since:performing&&!was?this.bar:previous?.since??null,restedAt:!performing&&was?this.bar:previous?.restedAt??null});
    if(['leaving','left'].includes(value.state))this.heard.delete(value.instanceId);
  }
  // A bot gone without a word (its host dropped from the network: ManageBOT's roll calls find it), forgotten.
  forget(instanceId){this.roster.delete(instanceId);this.heard.delete(instanceId)}
  capture(motif){
    const author=String(motif.author||'');if(!author)return;
    const notes=notesOfCapture(motif);if(!notes.length)return;
    const quarterBpm=Number(motif.metadata?.defaultBpm)||0;
    // The span a phrase covers: its phrase length at the clock's tempo, which a capture cannot say for itself.
    const meter=this.clock?.meter||{},phraseBars=Number(meter.phraseBars)||4;
    const barSeconds=(Number(meter.numerator)||4)*(Number(meter.subdivision)||4)*secondsPerTick(this.clock);
    const span=Math.max(phraseBars*barSeconds,notes.at(-1).start+notes.at(-1).duration);
    const kept=this.heard.get(author)||[];
    kept.push({notes,span,bar:Number(motif.createdAt?.bar)||this.bar,quarterBpm});
    while(kept.length>this.phrases)kept.shift();
    this.heard.set(author,kept);
  }

  // Everything measure.js says about a performer's recent phrases, at the clock's meter and tempo; null if unheard.
  measured(instanceId){
    const kept=this.heard.get(instanceId);if(!kept?.length)return null;
    let offset=0;const notes=[];
    for(const phrase of kept){for(const note of phrase.notes)notes.push({...note,start:note.start+offset});offset+=phrase.span}
    const clock=this.clock||{},meter=clock.meter||{numerator:4,denominator:4,subdivision:4},tick=secondsPerTick(clock);
    const beats=feltBeats(meter,{secondsPerTick:tick}),pulses=(Number(meter.numerator)||4)*(Number(meter.subdivision)||4);
    const beatSeconds=pulses*tick/Math.max(1,beats.length);
    return {...measureNotes(notes,{span:offset,beatSeconds,tickSeconds:tick,quarterBpm:quarterBpmOf(Number(clock.bpm)||108,meter)}),
      phrases:kept.length,source:'notes'};
  }
  // A performer's spectrum: the desk's measurement if it has published one, else the room's notes, else the profile's.
  spectrum(instanceId,declaration=null){
    const desk=this.desk?.spectra?.[instanceId];
    if(Array.isArray(desk)&&desk.length)return {shares:desk,source:'desk'};
    const heard=this.measured(instanceId);
    if(heard?.spectrum?.some(value=>value>0))return {shares:heard.spectrum,source:'notes'};
    if(declaration?.spectrum)return {shares:declaration.spectrum,source:'profile'};
    return null;
  }
  // Whether harmony has been published lately: the evidence a harmony follower needs.
  harmonyPublished(){return this.harmonyAt!==null&&this.bar-this.harmonyAt<=EVIDENCE.harmonyBars}
  // Who is here and could be cast: sounding, not leaving. A stopped bot is resting, loaded and able to start again (a
  // rest is a stop: a coordinator's leave would take it out of a live room).
  performers(){return [...this.roster.values()].filter(entry=>!entry.messageOnly&&!['leaving','left'].includes(entry.state)&&entry.functionGroup!=='incomplete')}
  performing(){return this.performers().filter(entry=>entry.state==='performing')}
}
