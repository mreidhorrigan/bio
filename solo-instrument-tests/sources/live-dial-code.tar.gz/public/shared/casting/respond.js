// A bot's answer to a casting plan, from its own declaration and its own state (research/casting.md §7). The framework's
// Agent hands it every orchestration plan carrying `casting`; a bot the plan does not name says nothing, so a section's
// casting costs a response from each bot it moves rather than from the whole room.
//
// The plan's `casting` (manage_clodbot.js): {section: {index, role, startBar, meter}, group: [{id, definitionId}],
// enter: [{id, definitionId, atBar}], rest: [{id, definitionId, atBar}], ...}. Ids are instance ids.
import {declarationOf,lostIn,lostRulesOut} from './declarations.js';
import {tickSecondsAt} from './meters.js';
import {compareLogicalPosition} from '../planning.js';

// Whether another author holds an unexpired harmony plan this bot has heard: somebody who could lead if it rested.
function otherHarmony(bot){
  const now=bot.currentClock||{};
  for(const plan of bot.receivedPlans?.values?.()||[]){
    if(plan.kind!=='harmony'||plan.author===bot.instanceId)continue;
    try{if(plan.expiresAt&&compareLogicalPosition({bar:Number(now.bar)||0,phrase:Number(now.phrase)||0,section:Number(now.section)||0},plan.expiresAt)>=0)continue}catch{continue}
    return true;
  }
  return false;
}

// {disposition, rationale, payload} for a bot the plan names, {silent: true} for one it does not, null for a plan that
// is not a casting plan.
export function castingAnswer(bot,plan){
  const casting=plan?.payload?.casting;
  if(!casting||typeof casting!=='object')return null;
  const me=String(bot?.instanceId||''),find=list=>(Array.isArray(list)?list:[]).find(entry=>entry&&String(entry.id)===me);
  const resting=find(casting.rest),entering=find(casting.enter);
  if(!resting&&!entering)return {silent:true};
  const declaration=declarationOf(bot.definitionId);
  if(resting){
    if(declaration.person)return {disposition:'decline',rationale:`${declaration.name} stands for a performer: only they decide when it rests.`};
    // The harmony its group follows: a harmony source that has heard no other harmony author (its own plans never come
    // back to it, so what it can know is that nobody else publishes any) stays if a member of the next group follows
    // harmony and nobody else in that group provides it.
    if(declaration.provides.includes('harmony')&&!otherHarmony(bot)){
      const group=(Array.isArray(casting.group)?casting.group:[]).filter(member=>String(member?.id)!==me);
      const followers=group.filter(member=>declarationOf(member.definitionId).needs.includes('harmony'));
      const providers=group.filter(member=>declarationOf(member.definitionId).provides.includes('harmony'));
      if(followers.length&&!providers.length)return {disposition:'decline',rationale:`${declaration.name} is the only harmony `
        +`here, and ${followers.length} of the next group follow harmony with nobody else in it to publish any.`};
    }
    // A motif it accepted, still running when it would rest: it rests when the motif ends.
    const motif=bot.activeMotifPlan;
    if(motif?.expiresAt&&Number.isFinite(Number(resting.atBar))&&Number(motif.expiresAt.bar)>Number(resting.atBar))
      return {disposition:'defer',rationale:`${declaration.name} is playing an accepted motif until bar ${motif.expiresAt.bar}.`,
        payload:{readyAt:{bar:Number(motif.expiresAt.bar)}}};
    return {disposition:'accept',rationale:'Will rest at the bar stated.'};
  }
  // Asked to enter: a beat or a bass declines a meter it is measured to be lost in (declarations.js METRIC), as the meter
  // is felt at the tempo its clock keeps (the quarter note's, carried into a new meter).
  const clock=bot.currentClock,meter=casting.section?.meter||clock?.meter;
  const quarterBpm=Number(clock?.bpm)>0?Number(clock.bpm)*4/(Number((clock.meter||meter)?.denominator)||4):null;
  const lost=meter&&lostRulesOut(declaration)?lostIn(declaration,meter,{secondsPerTick:quarterBpm?tickSecondsAt(quarterBpm,meter):null}):null;
  if(lost?.lost)return {disposition:'decline',rationale:`${lost.because}: it would play this meter off its felt beats.`};
  return {disposition:'accept',rationale:'Will enter at the bar stated.'};
}
