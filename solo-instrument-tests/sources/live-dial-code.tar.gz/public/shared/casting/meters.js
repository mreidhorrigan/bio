// How casting names and classes a meter: a label to look a measurement up by, and a kind (simple, compound, additive)
// for meters nobody measured a bot in. Apart from measure.js so a bot answering a casting plan (respond.js) needs only
// this and the clock's own meter-tactus.js.
import {feltBeats,secondsPerTick,tactusOf} from '../meter-tactus.js';

// A meter's kind, from its own grouping (meter-tactus.js tactusOf): compound where its beats divide in three (all
// groups of three in an eighth or shorter, or a beat counted in threes), additive where its groups are unequal, simple
// otherwise. A bot measured in some meters of a kind is expected to behave alike in the others of it.
export function meterKind(meter){
  const tactus=tactusOf(meter);
  if(tactus.compound)return 'compound';
  const groups=Array.isArray(meter?.groups)&&meter.groups.length?meter.groups:null;
  return groups&&new Set(groups).size>1?'additive':'simple';
}
// 4/4 counted in threes (its quarters divided in three) is another meter than 4/4, though its beats are the same.
const inThrees=meter=>Number(meter?.subdivision)===3&&Number(meter?.denominator)===4?' in threes':'';
export const meterLabel=meter=>`${meter?.numerator}/${meter?.denominator}${Array.isArray(meter?.groups)&&meter.groups.length>1?` (${meter.groups.join('+')})`:''}${inThrees(meter)}`;
// A meter as it is felt at a tempo: its time signature and its felt beats' lengths in its notated beats
// (meter-tactus.js feltBeats). 5/8 at 130 eighths a minute, felt in its five eighths, is "5/8 felt 1+1+1+1+1" whichever
// way it is grouped; at 200 as 3+2 it is "5/8 felt 3+2". Whether a bot articulates the felt beats is a question asked of
// the meter as felt: a walking bass articulates the first and is lost in the second.
export function feltLabel(meter,{secondsPerTick:tick}){
  const subdivision=Math.max(1,Number(meter?.subdivision)||4);
  return `${meter?.numerator}/${meter?.denominator}${inThrees(meter)} felt ${feltBeats(meter,{secondsPerTick:tick}).map(beat=>Math.round(beat.length/subdivision*100)/100).join('+')}`;
}
// A tick's length in a meter at a tempo in quarter notes a minute: the clock counts the meter's notated beat.
export const tickSecondsAt=(quarterBpm,meter)=>secondsPerTick({bpm:(Number(quarterBpm)||100)*(Number(meter?.denominator)||4)/4,meter});
