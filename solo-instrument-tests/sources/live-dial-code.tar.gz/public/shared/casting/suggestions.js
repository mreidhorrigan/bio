// A line-up suggestion weighed against the claims (research/casting.md §8). Anyone may suggest -- a bot, a person, the
// language model on the MCP bridge -- on `/agent/casting/suggest`: {target, enter: [ids], rest: [ids], reason, source,
// requestId}. Ids may be instance ids or definition ids. ManageBOT answers each on `/agent/casting/answer` with this
// verdict; an accepted suggestion weighs strongly in the next section's draw, and a person's is enacted.
import {carryExceeded,metricallyLost,unmetNeeds} from './fit.js';

export const SUGGESTION_SOURCES=Object.freeze(['person','lm','bot']);
// A layer may be named instead of a bot, as a person or a small model says it ("rest the drums"), in Moore's words or the
// usual ones.
export const LAYER_WORDS=Object.freeze({beat:'beat',drums:'beat',drum:'beat',kit:'beat',percussion:'beat',groove:'beat',
  bass:'bass',bassline:'bass',melody:'melody',melodies:'melody',lead:'melody',leads:'melody',tune:'melody',
  filler:'filler',pad:'filler',pads:'filler',chords:'filler',keys:'filler',harmony:'filler',
  texture:'texture',textures:'texture',noise:'texture',ambience:'texture'});
const listOf=value=>(Array.isArray(value)?value:value==null?[]:[value]).map(String).filter(Boolean).slice(0,16);

// Resolve the ids a suggestion names against the pool: an instance id as it is, a definition id to the first pool
// member of that definition (a playing one for a rest, a resting one for an entry), a layer to its members (every
// playing one for a rest, the longest rested for an entry).
function resolve(ids,pool,{playing}){
  const found=[],unknown=[];
  for(const id of ids){
    const layer=LAYER_WORDS[String(id).toLowerCase()];
    if(layer&&!pool.some(member=>member.id===id||member.declaration.id===id)){
      const members=pool.filter(member=>member.declaration.layer===layer&&member.performing===playing)
        .sort((a,b)=>(b.restedFor??Infinity)-(a.restedFor??Infinity));
      const chosen=playing?members:members.slice(0,1);
      if(chosen.length)for(const member of chosen){if(!found.includes(member))found.push(member)}else unknown.push(id);
      continue;
    }
    const exact=pool.find(member=>member.id===id);
    const byDefinition=pool.filter(member=>member.declaration.id===id).sort((a,b)=>(b.performing===playing)-(a.performing===playing));
    const member=exact||byDefinition[0];
    if(member&&!found.includes(member))found.push(member);else if(!member)unknown.push(id);
  }
  return {found,unknown};
}

// The verdict on one suggestion: {verdict: 'accepted'|'declined'|'partly', enter, rest, because: [...], source}.
// `pool`: castable members as sections.js takes them; `current`: ids playing now; `silent`: faculties never cast;
// `meter`: the meter now.
export function weighSuggestion(payload,{pool,current=[],silent=[],meter=null,secondsPerTick=null}){
  const source=SUGGESTION_SOURCES.includes(payload?.source)?payload.source:'bot';
  const enterIds=listOf(payload?.enter),restIds=listOf(payload?.rest),because=[];
  const entering=resolve(enterIds,pool,{playing:false}),resting=resolve(restIds,pool,{playing:true});
  for(const id of [...entering.unknown,...resting.unknown])because.push(LAYER_WORDS[String(id).toLowerCase()]
    ?`nobody in the ${LAYER_WORDS[String(id).toLowerCase()]} layer is ${resting.unknown.includes(id)?'playing':'resting'} to move`
    :`${id} is not in this room`);
  const byId=new Map(pool.map(member=>[member.id,member]));
  const after=new Set(current.filter(id=>byId.has(id)));
  const accepted={enter:[],rest:[]};
  for(const member of resting.found){
    if(member.declaration.person){because.push(`${member.declaration.name} stands for a performer and is not rested by anyone else`);continue}
    const without=[...after].filter(id=>id!==member.id).map(id=>byId.get(id));
    const unmet=unmetNeeds(without,{silent});
    if(unmet.length){because.push(`resting ${member.declaration.name} would leave ${unmet.map(entry=>byId.get(entry.id)?.declaration.name??entry.id).join(', ')} without ${unmet[0].need}`);continue}
    after.delete(member.id);accepted.rest.push(member.id);
  }
  // Providers first, so a suggestion that brings a harmony source with its followers is weighed as the group it makes.
  entering.found.sort((a,b)=>(b.declaration.provides.length?1:0)-(a.declaration.provides.length?1:0));
  for(const member of entering.found){
    if(member.declaration.person){because.push(`${member.declaration.name} stands for a performer and enters when they do`);continue}
    const withIt=[...after,member.id].map(id=>byId.get(id));
    const lost=metricallyLost([member],meter,{secondsPerTick}),carry=carryExceeded(withIt),unmet=unmetNeeds(withIt,{silent}).filter(entry=>entry.id===member.id);
    if(lost.length){because.push(lost[0].because);continue}
    if(unmet.length){because.push(unmet[0].because);continue}
    // Too many of a layer is a reason for somebody else of it to rest, which a person may want; it is said, and only a
    // person's suggestion goes ahead regardless.
    if(carry.length&&source!=='person'){because.push(`${member.declaration.name} would make ${carry[0].because}`);continue}
    after.add(member.id);accepted.enter.push(member.id);
  }
  const asked=entering.found.length+resting.found.length+entering.unknown.length+resting.unknown.length;
  const taken=accepted.enter.length+accepted.rest.length;
  const verdict=!asked?'declined':taken===asked?'accepted':taken?'partly':'declined';
  if(!asked)because.push('it named nobody to enter or rest');
  return {verdict,source,enter:accepted.enter,rest:accepted.rest,because,reason:String(payload?.reason??'').slice(0,240)};
}
