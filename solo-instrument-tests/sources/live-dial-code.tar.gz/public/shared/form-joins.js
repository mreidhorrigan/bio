// The form's joins: the bar each section after the first begins on, the sections' roles either side, their tensions and
// how far the tension moves across it. Read by every bot that acts at the joins: edit_clodbot (its edits and cuts), the
// drummers' marks (bots/lib/modules/form-marks.js), feedback_clodbot (its blooms).
//
// Two kinds of form plan reach them:
// - form_clodbot's lays its sections out in phrases of one length (payload.phraseBars), each with its tension;
// - PlexBOT's gives each section its own meter and phrase length (section.phraseBars) and no tension. The clock makes
//   its changes on its own phrase grid (a phrase begins where the bar's number is a multiple of the meter's phraseBars),
//   which drifts from a plain sum of the sections' lengths once a phrase length changes: in one render its changes fell
//   at bars 40, 44, 50 and 56 (the casting session, 26 September 2026). It announces each section a phrase ahead, as a
//   rhythm plan with the section's formal role, its id and the bar it begins on (sectionAnnouncement), and there the
//   section begins; the sections after an announced one are counted on from it, as the score reads the form
//   (public/score/plans.js).
// A section's tension is its own, else its horizontal density (PlexBOT's: its role's complexity, 0.2 to 0.85).

// ---- Choices ---------------------------------------------------------------------------------------------------------
// A section's phrase length where its plan gives none: the clock's own default (meter.cjs).
export const DEFAULT_PHRASE_BARS=4;
// The announcements a bot keeps: the most recent, enough for several forms' sections.
export const ANNOUNCEMENTS_KEPT=64;

// A section announced by a rhythm plan with a formal role: {author, section (its id), bar (where it begins), role,
// created (the bar the plan was made on)}; null for any other plan.
export function sectionAnnouncement(plan){
  if(plan?.kind!=='rhythm'||!plan.payload?.formalRole||!Number.isInteger(plan.appliesAt?.bar))return null;
  return {author:plan.author??null,section:Number.isInteger(plan.appliesAt?.section)?plan.appliesAt.section:null,bar:plan.appliesAt.bar,
    role:String(plan.payload.formalRole),created:Number(plan.createdAt?.bar??plan.appliesAt.bar)};
}
// A bot's list of announcements with one more, the oldest dropped past ANNOUNCEMENTS_KEPT.
export const withAnnouncement=(list,plan)=>{const found=sectionAnnouncement(plan);return found?[...(list??[]).slice(1-ANNOUNCEMENTS_KEPT),found]:list??[]};

export const isReturn=role=>typeof role==='string'&&/return/.test(role);
const tensionOf=section=>Number(section?.tension??section?.hdensity)||0;

// Each join the form has: {bar, from, to (the roles), fromTension, toTension, move (the tension after less before)}.
// `announced`: the sections announced so far (sectionAnnouncement); each one by this form's author, made since the form
// was, begins its section where it says.
export function formJoins(form,{announced=[]}={}){
  const payload=form?.payload,sections=payload?.sections??[];if(sections.length<=1)return [];
  const since=Number(form.createdAt?.bar??form.appliesAt?.bar)||0;
  const known=new Map((announced??[]).filter(item=>item&&item.section!==null&&(!form.author||item.author===form.author)&&item.created>=since)
    .map(item=>[item.section,item.bar]));
  const starts=[];let bar=Number(form.appliesAt?.bar)||0;
  sections.forEach((section,index)=>{
    const id=section.id??index;
    if(known.has(id))bar=known.get(id);
    starts.push(bar);
    bar+=Math.max(1,Number(section.phrases)||1)*Math.max(1,Number(section.phraseBars??payload.phraseBars)||DEFAULT_PHRASE_BARS);
  });
  return sections.slice(1).map((section,i)=>{
    const fromTension=tensionOf(sections[i]),toTension=tensionOf(section);
    // What the section asks of the fill into it, where it asks (`fills`: 'extreme', or a length in felt beats: the
    // drummer's fills, bots/lib/modules/form-marks.js).
    return {bar:starts[i+1],from:sections[i].role,to:section.role,fromTension,toTension,move:toTension-fromTension,...(section.fills!==undefined?{fills:section.fills}:{})};
  });
}

// Where a mixbot says what it will do at the form's joins, ahead of them, for the players to play into: {source, form
// (the plan's id), joins: [{bar, kind ('cut', 'repeat', 'reverse', 'tapeStop'), what, move, to}]}, sent again whenever
// that changes (edit_clodbot; heard by bots/lib/modules/form-marks.js). The user, 26 September 2026, on the edits heard
// while the band played on unchanged: "it didn't have enough reinforcement from other simultaneous changes to sound
// intentional."
export const EDITS_ADDRESS='/broadcast/edits';
