// Which of the stored motifs to answer a request with.
//
// Retention decides what survives capacity pressure. This decides which of the
// survivors are worth sending to the bot that just asked. The two read the same
// ledger and must not be confused: use evidence is read here and never written,
// and a motif that is merely considered earns nothing by being considered.
//
// What a query returned until now was "the newest eight that match". That is a
// filter with a truncation on the end, not a choice, and the thing it truncates
// to is whatever the phrase-boundary capture firehose produced most recently --
// mostly passagework nobody ever asked for again. Ranking therefore runs over
// the whole filtered population, before any limit is applied.
//
// Nothing here is a claim about musical quality. The quantity is relevance to
// one request, by one bot, at one moment: a phrase that suits this register and
// this plan is the wrong answer to the next question, and the number does not
// outlive the request it was computed for. There is deliberately no
// quality(motif), and no state: the same inputs always produce the same slate.
//
// The weights below are initial hypotheses to calibrate against real runs, not
// findings. See docs/MOTIF_RANKING.md for what has and has not been measured.

import {MEMORY_TRANSFER_LIMITS} from './motif-retention.js';
import {motifNotes} from './motifs.js';
import {HARMONY_DEFAULTS,harmonicStrain,harmonicUsage} from './motif-harmony.js';
import {PRESENTATION_RELATION_NAMES} from './presentation-history.js';

const LN2=Math.LN2;
const clamp=(value,low,high)=>value<low?low:value>high?high:value;
const round=(value,places=6)=>Number(Number(value).toFixed(places));
// Locale-independent, so a slate cannot depend on where the browser is.
const byId=(left,right)=>left<right?-1:left>right?1:0;
const positiveInteger=(value,name)=>{
  const number=Math.trunc(Number(value));
  if(!Number.isFinite(number)||number<1)throw new RangeError(`${name} must be a positive integer`);
  return number;
};
const positiveNumber=(value,name)=>{
  const number=Number(value);
  if(!Number.isFinite(number)||number<=0)throw new RangeError(`${name} must be a positive number`);
  return number;
};
const weight=(value,name)=>{
  const number=Number(value);
  if(!Number.isFinite(number)||number<0)throw new RangeError(`${name} must be a nonnegative number`);
  return number;
};
const truth=(value,name)=>{
  if(typeof value!=='boolean')throw new RangeError(`${name} must be true or false`);
  return value;
};
const unit=(value,name)=>{
  const number=Number(value);
  if(!Number.isFinite(number)||number<0||number>1)throw new RangeError(`${name} must be between 0 and 1`);
  return number;
};

// What each feature answers. Every one is bounded to [0,1] so a weight is the
// only thing that decides how much it matters, and so an explanation can say
// how close to its best a motif came on each count.
export const MOTIF_FEATURES=Object.freeze({
  // Can the bot that asked actually play this material? The one piece of
  // requester context available without a protocol change: a bot's pitch
  // contract is in its manifest, and a bot that does not hold a floating-MPE
  // contract cannot render microtones, however good the phrase is.
  fit:'the requester can render this material',
  // Independent adopters, saturating. One prolific bot cannot outweigh three
  // different ones picking the same phrase up.
  taken:'other bots have taken it up',
  // Uptake against exposure. A phrase offered repeatedly and never taken is
  // evidence of something; a phrase never offered is evidence of nothing.
  // Adopters against adopters and offers: two counts from different experiments, so a social ratio, not a rate of
  // uptake (the mathematical audit's M03), and no calibrated probability is claimed for it.
  yield:'it is taken up when it is offered (adopters against adopters and offers)',
  // Time since anything used it, so the same phrase is not handed back to the
  // whole ensemble in consecutive bars.
  rest:'it has not just been used',
  // Enough material to develop, saturating: a longer clip is not a better one.
  substance:'there is enough of it to work with',
  // Someone else's material, mildly preferred: a shared library exists so that
  // phrases cross between bots, and a bot echoing itself needs no library.
  kin:'it comes from another bot',
  // How little it has to be bent to sit in the harmony of the moment. An answer
  // is realized in that harmony whatever is chosen (shared/motif-harmony.js), so
  // every candidate can be made to fit; what differs is what the fitting costs
  // it. A motif already in the harmony, or a plain transposition away from it,
  // comes through as itself. One that has to be bent out of shape comes through
  // as something else, and a library should reach for the former first. Neutral
  // when nobody has said what the harmony is, or the request wants its motifs
  // exactly as stored.
  harmony:'it sits in the harmony of the moment without being bent far',
});
export const MOTIF_FEATURE_NAMES=Object.freeze(Object.keys(MOTIF_FEATURES));

// Every way of choosing a slate that this build can be switched between, each
// one an algorithm from the survey in research/MEMORYBOT_RANKING_RESEARCH.md.
// Implemented in motif-strategies.js; declared here because the policy has to
// be able to refuse a name, and a test holds the two lists to each other.
// Several of these are expected to be musically poor. They are here to be
// compared against, which is the only way the default earns its place.
export const MOTIF_STRATEGY_NAMES=Object.freeze([
  'relevance',     // contextual features + MMR                    [S11, S13]
  'newest',        // what a query did before any of this: the baseline
  'oldest',        // its inverse, as a control
  'shuffle',       // seeded permutation, as a control              [S11 §7.4]
  'popular',       // context-free use counts                      [S9, S10]
  'ucb',           // use counts plus an uncertainty bonus         [S16, S17]
  'ngram',         // generalized n-gram similarity to a reference [S1]
  'alignment',     // edit distance to a reference                 [S2]
  'contrast',      // least like the reference
  'compression',   // repetition structure as a description length [S6]
  'expectancy',    // variable-order Markov information content    [S7]
  'coverage',      // monotone submodular feature coverage         [S14]
  'determinantal', // greedy MAP for a determinantal point process [S15]
  'form',          // fit to the section role the ensemble is in
  'arc',           // fit to how far through the form the ensemble has got
  'formal',        // what this appearance would DO, given what has sounded
]);

export const MOTIF_RANKING_DEFAULTS=Object.freeze({
  // Which of them answers a query. A request may name another (`query.strategy`)
  // and an unknown name falls back here rather than failing the query.
  strategy:'relevance',
  // The answer size, which used to be two literals inside queryMotifs. The
  // ceiling is the one the transfer budget is derived from, so the largest
  // answer this can ask for is still an answer that fits in a message.
  defaultResults:8,
  maxResults:MEMORY_TRANSFER_LIMITS.responseLimit,
  weights:Object.freeze({fit:1.4,taken:1,yield:.8,rest:.6,substance:.5,kin:.3,harmony:1}),
  // The strain (semitones of distortion per note, plus a tenth for each semitone
  // of transposition) at which `harmony` reaches zero. One semitone: a motif a
  // fourth away from fitting exactly scores a half, one note in three moved by a
  // semitone two thirds, and a motif every note of which must move scores nothing.
  strainScale:1,
  // **Every part of this is a preference that can be switched**, like the rest of
  // the policy: here, by /agent/memory/policy, and per request.
  //   harmonize      whether an answer is realized in the harmony of the moment at
  //                  all. Off, motifs go out exactly as stored and `harmony`
  //                  separates nothing. A request's own `harmonize` overrides it
  //                  either way.
  //   weights.harmony  how much being easy to fit counts when choosing; 0 is not at all.
  //   movePenalty    shape against place, for the choosing and the realizing alike
  //                  (shared/motif-harmony.js): 0 always takes the transposition
  //                  that keeps the motif's intervals, a large value never moves
  //                  it and bends its notes where they stand.
  harmonize:true,
  movePenalty:HARMONY_DEFAULTS.movePenalty,
  // Independent adopters at which `taken` reaches one half.
  useScale:1.5,
  // What `yield` says about a motif nothing has ever been offered: unknown,
  // which is neither good nor bad. Zero here would make the firehose's newest
  // capture permanently unrankable, which is the feedback loop this is for.
  coldYield:.5,
  restHalfLifeMs:45000,
  substanceNotes:8,
  // `kin` for the requester's own material.
  selfKin:.5,
  // Maximal marginal relevance: relevance against redundancy with what has
  // already been chosen for this answer.
  lambda:.75,
  // How much of each fingerprint two motifs are compared over. Bounded, so the
  // comparison cost cannot grow with the length of a clip.
  descriptorLength:16,
  // The difference at which two intervals, or two onsets, count as half alike.
  // A tolerance for comparison only: nothing here rewrites a stored pitch.
  intervalScale:1,
  onsetScale:.1,
  intervalWeight:.65,
  onsetWeight:.35,
  // Two clips from one family are at least this alike. Provenance is evidence
  // of kinship, not proof that every derivation sounds like its parent, so it
  // raises a similarity floor rather than deciding the similarity.
  familyFloor:.5,
  // How many feature contributions a rationale names before it stops.
  explanations:3,

  // ---- knobs the switchable strategies use -----------------------------
  // Intervals are floats and must stay floats. These quantize a *copy* for
  // symbolic comparison only -- n-grams, the Markov model, the compression
  // proxy -- at a quarter-tone, which is the resolution the ensemble tunes in.
  symbolStep:.25,
  // n-grams of this length over the interval sequence.                  [S1]
  ngramLength:3,
  // Alignment: the interval difference at which a substitution costs a whole
  // edit, so a quarter-tone ornament is not the same as a leap.         [S2]
  alignmentScale:2,
  // Variable-order Markov model over interval symbols, and the smoothing that
  // keeps an unseen continuation from costing infinite information.    [S7]
  markovOrder:2,
  markovSmoothing:.5,
  // What `expectancy` aims at, in normalized information content: 1 prefers the
  // least predictable material. Raw surprise is not merit -- see docs/MOTIF_RANKING.md.
  targetInformation:1,
  // Coverage buckets: register band x density band x microtonality.    [S14] The register bands divide
  // REGISTER_RANGE of pitch centres, the density bands up to DENSITY_TOP onsets a quarter note.
  registerBands:6,
  densityBands:4,
  // The quality exponent in the DPP kernel L = q q' o S.               [S15]
  determinantalQuality:1,
  // UCB: how much an unexposed clip is worth over a proven one.        [S16]
  explorationBonus:.7,
  // `shuffle` is a control, so its order must be reproducible from the message
  // stream alone. No generator state, and nothing shared with the music bots.
  shuffleSeed:20260918,

  // What kind of appearance each section role is taken to want, for the
  // `formal` strategy. A STARTING HYPOTHESIS and nothing more: the research is
  // explicit that no universal schedule of returns has been established, and
  // nothing here has been listened to. It is policy so that it can be argued
  // with, and a role this table does not know produces no preference at all
  // rather than a guess. Both form bots' vocabularies are covered because they
  // do not share one.
  relationsForRole:Object.freeze({
    establish:['first','immediate'],
    depart:['first','transformed'],
    contrast:['first'],
    develop:['transformed','allusion'],
    climax:['returned','persistent'],
    relax:['persistent','immediate'],
    return:['returned'],
    closure:['returned','immediate'],
    'complex-frame':['first'],
    stabilize:['persistent'],
    'complex-return':['returned','transformed'],
  }),
  // How much of `formal` is the role fit and how much is ordinary relevance.
  formalWeight:.6,
  // A relation named only as a secondary truth about an appearance counts for
  // less than one that is the primary thing it would be.
  secondaryRelation:.75,
});

// The single adjustment point, in the shape motifRetentionPolicy already uses:
// STOCHASTIC_CONFIG.memory.ranking spreads these and /agent/memory/policy
// passes overrides straight through, so no weight is ever a literal at a call
// site and none of it needs a rebuild to change.
export function motifRankingPolicy(overrides={}){
  const source=overrides&&typeof overrides==='object'?overrides:{};
  const weights={...MOTIF_RANKING_DEFAULTS.weights};
  for(const [name,value] of Object.entries(source.weights||{})){
    if(!(name in weights))throw new RangeError(`Unknown motif ranking feature: ${name}`);
    weights[name]=weight(value,`weights.${name}`);
  }
  // Weighed by the weights' ratios, never their scale: each is divided by the largest before they are summed, so a
  // common factor changes nothing. The sum rounded to six places had been the divisor, and weights of 1e-8 made it zero
  // and a perfect motif score Infinity (the mathematical audit's M02).
  const largest=Math.max(...MOTIF_FEATURE_NAMES.map(name=>weights[name]));
  if(!(largest>0))throw new RangeError('At least one ranking weight must be above zero');
  const normalizedWeights=Object.fromEntries(MOTIF_FEATURE_NAMES.map(name=>[name,weights[name]/largest]));
  const total=MOTIF_FEATURE_NAMES.reduce((sum,name)=>sum+normalizedWeights[name],0);
  const maxResults=positiveInteger(source.maxResults??MOTIF_RANKING_DEFAULTS.maxResults,'maxResults');
  if(maxResults>MEMORY_TRANSFER_LIMITS.responseLimit)
    throw new RangeError(`maxResults above ${MEMORY_TRANSFER_LIMITS.responseLimit} exceeds what one response can carry`);
  const defaultResults=positiveInteger(source.defaultResults??MOTIF_RANKING_DEFAULTS.defaultResults,'defaultResults');
  if(defaultResults>maxResults)throw new RangeError('defaultResults cannot exceed maxResults');
  const strategy=String(source.strategy??MOTIF_RANKING_DEFAULTS.strategy);
  if(!MOTIF_STRATEGY_NAMES.includes(strategy))throw new RangeError(`Unknown motif strategy: ${strategy}`);
  return Object.freeze({
    strategy,defaultResults,maxResults,weights:Object.freeze(weights),normalizedWeights:Object.freeze(normalizedWeights),weightTotal:total,
    useScale:positiveNumber(source.useScale??MOTIF_RANKING_DEFAULTS.useScale,'useScale'),
    coldYield:unit(source.coldYield??MOTIF_RANKING_DEFAULTS.coldYield,'coldYield'),
    restHalfLifeMs:positiveNumber(source.restHalfLifeMs??MOTIF_RANKING_DEFAULTS.restHalfLifeMs,'restHalfLifeMs'),
    substanceNotes:positiveNumber(source.substanceNotes??MOTIF_RANKING_DEFAULTS.substanceNotes,'substanceNotes'),
    selfKin:unit(source.selfKin??MOTIF_RANKING_DEFAULTS.selfKin,'selfKin'),
    strainScale:positiveNumber(source.strainScale??MOTIF_RANKING_DEFAULTS.strainScale,'strainScale'),
    harmonize:truth(source.harmonize??MOTIF_RANKING_DEFAULTS.harmonize,'harmonize'),
    movePenalty:weight(source.movePenalty??MOTIF_RANKING_DEFAULTS.movePenalty,'movePenalty'),
    lambda:unit(source.lambda??MOTIF_RANKING_DEFAULTS.lambda,'lambda'),
    descriptorLength:positiveInteger(source.descriptorLength??MOTIF_RANKING_DEFAULTS.descriptorLength,'descriptorLength'),
    intervalScale:positiveNumber(source.intervalScale??MOTIF_RANKING_DEFAULTS.intervalScale,'intervalScale'),
    onsetScale:positiveNumber(source.onsetScale??MOTIF_RANKING_DEFAULTS.onsetScale,'onsetScale'),
    intervalWeight:weight(source.intervalWeight??MOTIF_RANKING_DEFAULTS.intervalWeight,'intervalWeight'),
    onsetWeight:weight(source.onsetWeight??MOTIF_RANKING_DEFAULTS.onsetWeight,'onsetWeight'),
    familyFloor:unit(source.familyFloor??MOTIF_RANKING_DEFAULTS.familyFloor,'familyFloor'),
    explanations:positiveInteger(source.explanations??MOTIF_RANKING_DEFAULTS.explanations,'explanations'),
    symbolStep:positiveNumber(source.symbolStep??MOTIF_RANKING_DEFAULTS.symbolStep,'symbolStep'),
    ngramLength:positiveInteger(source.ngramLength??MOTIF_RANKING_DEFAULTS.ngramLength,'ngramLength'),
    alignmentScale:positiveNumber(source.alignmentScale??MOTIF_RANKING_DEFAULTS.alignmentScale,'alignmentScale'),
    markovOrder:positiveInteger(source.markovOrder??MOTIF_RANKING_DEFAULTS.markovOrder,'markovOrder'),
    markovSmoothing:positiveNumber(source.markovSmoothing??MOTIF_RANKING_DEFAULTS.markovSmoothing,'markovSmoothing'),
    targetInformation:unit(source.targetInformation??MOTIF_RANKING_DEFAULTS.targetInformation,'targetInformation'),
    registerBands:positiveInteger(source.registerBands??MOTIF_RANKING_DEFAULTS.registerBands,'registerBands'),
    densityBands:positiveInteger(source.densityBands??MOTIF_RANKING_DEFAULTS.densityBands,'densityBands'),
    determinantalQuality:weight(source.determinantalQuality??MOTIF_RANKING_DEFAULTS.determinantalQuality,'determinantalQuality'),
    explorationBonus:weight(source.explorationBonus??MOTIF_RANKING_DEFAULTS.explorationBonus,'explorationBonus'),
    shuffleSeed:positiveInteger(source.shuffleSeed??MOTIF_RANKING_DEFAULTS.shuffleSeed,'shuffleSeed'),
    relationsForRole:Object.freeze(Object.fromEntries(
      Object.entries(source.relationsForRole??MOTIF_RANKING_DEFAULTS.relationsForRole).map(([role,names])=>{
        const wanted=[...new Set((Array.isArray(names)?names:[names]).map(String))];
        for(const name of wanted)
          if(!PRESENTATION_RELATION_NAMES.includes(name))throw new RangeError(`Unknown presentation relation: ${name}`);
        return [String(role),Object.freeze(wanted)];
      }))),
    formalWeight:unit(source.formalWeight??MOTIF_RANKING_DEFAULTS.formalWeight,'formalWeight'),
    secondaryRelation:unit(source.secondaryRelation??MOTIF_RANKING_DEFAULTS.secondaryRelation,'secondaryRelation'),
  });
}

// The few facts about a clip's content that ranking needs, separated from the
// scoring so a caller can compute them once per stored motif instead of once
// per query. Pitches stay floats the whole way: `microtonal` is the question
// the pitch contract turns on, and rounding to answer it would defeat it.
// Its register is its pitch centre (the mean of its pitches, floats), its density its onsets a quarter note over its
// length (first onset to last end, in quarter notes; null where it has none): the quantities coverage's buckets are
// named for (the mathematical audit's M03), beside the span and the note count they had stood in for.
export function motifContent(motif){
  const notes=motifNotes(motif),pitches=notes.map(note=>Number(note.pitch)).filter(Number.isFinite);
  let low=Infinity,high=-Infinity,microtonal=false,sum=0,first=Infinity,end=-Infinity;
  for(const pitch of pitches){
    if(pitch<low)low=pitch;
    if(pitch>high)high=pitch;
    sum+=pitch;
    if(!Number.isInteger(pitch))microtonal=true;
  }
  const onsets=new Set();
  for(const note of notes){
    const at=Number(note.at),length=Number(note.duration);
    if(!Number.isFinite(at))continue;
    onsets.add(at);first=Math.min(first,at);end=Math.max(end,at+(Number.isFinite(length)&&length>0?length:0));
  }
  const quarters=end>first?end-first:null;
  // What it uses of the harmony it was played against: the half of "how far must
  // this be bent" that does not depend on where it is going, so it is worked out
  // here, once per stored motif, and a query pays only for the comparison.
  let usage=[];
  try{usage=harmonicUsage(motif)}catch{usage=[]}
  return Object.freeze({notes:notes.length,microtonal,
    span:Number.isFinite(low)&&Number.isFinite(high)?round(high-low):0,
    centre:pitches.length?round(sum/pitches.length):null,
    rate:quarters?round(onsets.size/quarters):null,
    family:String(motif.metadata?.parentMotifId||motif.motifId||''),usage});
}

// How alike two clips are, for the redundancy half of MMR only -- never for
// identity, and never as grounds for discarding one of them. Read off the
// fingerprint every stored motif already carries: float intervals, and onsets
// as ratios of the clip's own span, so the comparison is indifferent to key and
// to tempo. Bounded to descriptorLength positions, so one very long clip cannot
// make a query expensive.
// The comparison reads three things off a motif, so they are lifted out once
// per candidate rather than re-derived on every pair: a slate of 32 compares
// thousands of pairs, and deriving a family string inside that loop was most of
// what one answer cost.
export function shapeOf(motif,content){
  const print=motif.fingerprint||{};
  return {intervals:print.intervals||[],onsets:print.onsetRatios||[],
    family:content?.family||String(motif.metadata?.parentMotifId||motif.motifId||'')};
}
export function motifSimilarity(left,right,policy=motifRankingPolicy()){
  if(left===right)return 1;
  return shapeSimilarity(shapeOf(left),shapeOf(right),policy);
}
// MMR's similarity, and the redundancy a slate reports. The family floor by max is a heuristic, kept for them, and it
// is no kernel: max of kernels need not be positive semidefinite (the mathematical audit's M01). The determinantal
// strategy uses dppKernel.
export function shapeSimilarity(left,right,policy){
  const depth=policy.descriptorLength;
  const compare=(a=[],b=[],scale)=>{
    const shared=Math.min(a.length,b.length,depth);
    if(!shared)return a.length===b.length?1:0;
    let total=0;
    for(let index=0;index<shared;index++)total+=Math.exp(-Math.abs(a[index]-b[index])/scale);
    // Agreeing over a prefix is not agreeing: two clips of unequal length are
    // held apart in proportion to how much of them went uncompared. Both sides
    // are capped the same way, so the measure stays symmetric -- MMR compares
    // each candidate against every choice already made, and a similarity that
    // depended on the argument order would make the slate depend on it too.
    const reach=Math.min(a.length,depth),other=Math.min(b.length,depth),
      longest=Math.max(reach,other);
    return total/shared*(longest?Math.min(reach,other)/longest:1);
  };
  const shape=compare(left.intervals,right.intervals,policy.intervalScale),
    time=compare(left.onsets,right.onsets,policy.onsetScale),
    scale=Math.max(policy.intervalWeight,policy.onsetWeight),
    a=scale?policy.intervalWeight/scale:0,b=scale?policy.onsetWeight/scale:0,
    blended=scale>0?(shape*a+time*b)/(a+b):0;
  return clamp(left.family&&left.family===right.family?Math.max(blended,policy.familyFloor):blended,0,1);
}

// The determinantal strategy's kernel, positive semidefinite by construction (Kulesza and Taskar's L as a Gram matrix,
// the audit's M01): each position of a descriptor (intervals, onsets, up to descriptorLength) compared by a Laplacian
// kernel where both have a value, as equal where neither has one, as unlike where only one has (each the inner product
// of a feature map, so a kernel), averaged over the positions; intervals and onsets mixed by their weights; and a
// family-indicator kernel (a block of ones for each family) mixed in at familyFloor. A convex combination of kernels
// with unit diagonals is a kernel with a unit diagonal.
export function dppKernel(left,right,policy){
  const depth=policy.descriptorLength;
  const positions=(a=[],b=[],scale)=>{let total=0;
    for(let index=0;index<depth;index++){const x=index<a.length,y=index<b.length;
      total+=x&&y?Math.exp(-Math.abs(a[index]-b[index])/scale):x===y?1:0}
    return total/depth};
  const scale=Math.max(policy.intervalWeight,policy.onsetWeight),
    a=scale?policy.intervalWeight/scale:0,b=scale?policy.onsetWeight/scale:0,
    musical=scale>0?(positions(left.intervals,right.intervals,policy.intervalScale)*a
      +positions(left.onsets,right.onsets,policy.onsetScale)*b)/(a+b):1;
  const family=left===right||Boolean(left.family)&&left.family===right.family?1:0;
  return (1-policy.familyFloor)*musical+policy.familyFloor*family;
}

// What is actually known about one motif at the moment of the request: the
// ledger as it stands before this query's own answer is credited, the clip's
// own content, and whatever the requester's manifest says it can play. Kept
// separate from the features so an explanation can cite a fact -- two bots came
// back for it -- rather than a number nobody can check.
//
// `renders` is null when the requester is not a bot this build knows. Unknown
// is not a verdict: it must not read as either yes or no further down.
export function motifEvidence({motif,usage,content},context={}){
  const facts=content||motifContent(motif),now=Number(context.now)||0,
    capabilities=context.capabilities,lastUseAt=Number(usage?.lastUseAt)||0,
    author=String(motif.metadata?.author||'');
  return Object.freeze({
    // An adopter counts once however loudly it adopted; several different bots
    // are the evidence that matters, and this is where that is enforced.
    adopters:(usage?.users||[]).length,
    // Every use by every other bot, which popularity wants and the feature
    // vector deliberately does not: `taken` counts adopters so one prolific
    // bot cannot outweigh three. A strategy that wants the raw count says so.
    uses:(usage?.users||[]).reduce((total,user)=>total+(Number(user.uses)||0),0),
    offered:Math.max(0,Math.trunc(Number(usage?.offered)||0)),
    idle:lastUseAt>0?Math.max(0,now-lastUseAt):null,
    notes:facts.notes,microtonal:facts.microtonal,span:facts.span,centre:facts.centre??null,rate:facts.rate??null,
    renders:!capabilities?null:!(facts.microtonal&&!capabilities.tuning),
    own:Boolean(author)&&author===String(context.requester||''),
    // What realizing it in the harmony of the moment would cost it. Null is
    // "nothing to judge" -- no harmony known, or nothing in it has a pitch --
    // and, like `renders`, must not read as either good or bad further down.
    bend:Array.isArray(context.harmony)&&context.harmony.length
      ?harmonicStrain(facts.usage,context.harmony,Number.isFinite(context.movePenalty)?{movePenalty:context.movePenalty}:{}):null,
  });
}
export function motifFeatures(evidence,policy=motifRankingPolicy()){
  return {
    fit:evidence.renders===null?.5:evidence.renders?1:0,
    taken:evidence.adopters/(evidence.adopters+policy.useScale),
    yield:evidence.offered||evidence.adopters
      ?evidence.adopters/(evidence.adopters+evidence.offered):policy.coldYield,
    rest:evidence.idle===null?1:1-Math.exp(-LN2*evidence.idle/policy.restHalfLifeMs),
    substance:clamp(evidence.notes/policy.substanceNotes,0,1),
    kin:evidence.own?policy.selfKin:1,
    harmony:evidence.bend?1-clamp(evidence.bend.strain/policy.strainScale,0,1):.5,
  };
}

// A convex combination of the features, in [0, 1] where they are. Rounded to six places as the ranking's declared
// quantization, so equal scores tie exactly and break on the motif id, on every machine.
export function motifRelevance(features,policy=motifRankingPolicy()){
  let total=0;
  for(const name of MOTIF_FEATURE_NAMES)total+=policy.normalizedWeights[name]*features[name];
  return round(total/policy.weightTotal);
}

// Why this one, in the language the retention rationale already uses: facts
// that can be checked against the ledger, not scores that cannot. Nothing here
// is stated as a likelihood -- relevance is not calibrated and is not a
// probability of anything.
function rationale({evidence,features,displaced,reason},considered,policy){
  const plural=(count,noun)=>`${count} ${noun}${count===1?'':'s'}`,good=[],bad=[];
  if(evidence.adopters)good.push(`taken up by ${plural(evidence.adopters,'other bot')}`);
  // Said early, because only so many reasons are given and this is the one a listener would hear.
  if(evidence.bend){
    const {distortion,transpose}=evidence.bend,steps=Math.round(transpose*100)/100;
    if(distortion<=.05)good.push(steps?`it fits the current harmony exactly, ${steps} semitone${steps===1?'':'s'} from where it was played`:'it is in the current harmony as it stands');
    else if(features.harmony<=.34)bad.push('it has to be bent out of shape to fit the current harmony');
  }
  if(evidence.renders===false)bad.push('the requester cannot render its microtones');
  else if(evidence.renders&&evidence.microtonal)good.push('its microtones survive this requester');
  if(evidence.offered&&!evidence.adopters)bad.push(`offered ${plural(evidence.offered,'time')} without being taken`);
  if(features.substance>=1)good.push(`${plural(evidence.notes,'note')} to work with`);
  else if(features.substance<=.34)bad.push(`only ${plural(evidence.notes,'note')} of it`);
  if(features.rest<=.34)bad.push('it was used moments ago');
  if(evidence.own)bad.push('it is the requester’s own material');
  const parts=[];
  if(reason)parts.push(reason);
  if(good.length)parts.push(good.slice(0,policy.explanations).join('; '));
  if(bad.length)parts.push(`against it: ${bad.slice(0,policy.explanations).join('; ')}`);
  if(displaced)parts.push(`kept for contrast with ${displaced}`);
  return `Chosen from ${plural(considered,'candidate')}. `
    +(parts.join('. ')||'Nothing in the ledger separates it from the rest.');
}

// The whole answer: score every candidate, then choose the slate one at a time,
// each pick the best trade between what it is worth on its own and how much it
// repeats what has already been chosen (MMR, Carbonell & Goldstein 1998). An
// explainable heuristic, not a guarantee of the best possible set of eight.
//
// `candidates` are {motif, usage, content} -- usage read from the retention
// ledger by the caller, because this module never touches it.
// One evidence pass, shared by every strategy, so a comparison between two of
// them is a comparison of how they choose and not of what they were told.
// `order` is the position in the store, oldest first: the only strategies that
// may read it are the ones whose whole claim is about arrival time.
export function prepareCandidates(candidates=[],context={},policy=motifRankingPolicy()){
  return [...candidates].filter(candidate=>candidate?.motif?.motifId).map((candidate,order)=>{
    const evidence=motifEvidence(candidate,context),features=motifFeatures(evidence,policy);
    return {motif:candidate.motif,motifId:String(candidate.motif.motifId),order,
      shape:shapeOf(candidate.motif,candidate.content),
      evidence,features,relevance:motifRelevance(features,policy),
      redundancy:0,score:0,displaced:'',reason:''};
  });
}
// Relevance first, then motifId: no strategy may inherit the order the store
// happened to hold its records in.
export const byRelevance=(left,right)=>right.relevance-left.relevance||byId(left.motifId,right.motifId);
export const bounded=(context,policy)=>
  clamp(Math.trunc(Number(context.limit)||policy.defaultResults),1,policy.maxResults);
// Ranks and explains a slate a strategy has chosen, in the order it chose it.
export function finishSlate(results,considered,policy){
  results.forEach((entry,index)=>{
    entry.rank=index+1;
    entry.rationale=rationale(entry,considered,policy);
  });
  return results;
}

export function rankMotifs(candidates=[],context={},policy=motifRankingPolicy()){
  const limit=bounded(context,policy),scored=prepareCandidates(candidates,context,policy).sort(byRelevance);
  const results=selectByRelevance(scored,context,policy);
  return {considered:scored.length,limit,strategy:'relevance',
    results:finishSlate(results,scored.length,policy)};
}
// Maximal marginal relevance (Carbonell & Goldstein 1998): each pick is the
// best trade between what a clip is worth on its own and how much it repeats
// what has already been chosen. An explainable heuristic, and not the
// monotone-submodular objective -- its approximation guarantee is not this one's.
export function selectByRelevance(scored,context,policy){
  const limit=bounded(context,policy),results=[],remaining=new Set(scored);
  while(results.length<limit&&remaining.size){
    let best=null,bestScore=-Infinity;
    for(const entry of remaining){
      const score=policy.lambda*entry.relevance-(1-policy.lambda)*entry.redundancy;
      if(score>bestScore||(score===bestScore&&best&&byId(entry.motifId,best.motifId)<0)){
        best=entry;bestScore=score;
      }
    }
    remaining.delete(best);
    best.score=round(bestScore);
    // Something was more relevant but was passed over here: this pick is the
    // one diversity bought, and the explanation should say so.
    const ahead=scored.find(entry=>remaining.has(entry)&&entry.relevance>best.relevance);
    best.displaced=ahead?ahead.motifId:'';
    results.push(best);
    // Each candidate keeps its own worst overlap with the answer so far, so one
    // pick costs one comparison per candidate rather than one per candidate per
    // choice already made. The slate is identical either way; a slate of 32 is
    // not, at ten times the cost.
    for(const entry of remaining)
      entry.redundancy=Math.max(entry.redundancy,round(shapeSimilarity(entry.shape,best.shape,policy)));
  }
  return results;
}

// What travels on /agent/memory/response beside the motifs: the same order, one
// record each, with the numbers the choice was made from. A consumer that only
// reads `motifs` is unaffected by its presence.
export function rankingReport({considered,limit,strategy,results}){
  return {considered,limit,strategy,motifs:results.map(entry=>({motifId:entry.motifId,rank:entry.rank,
    relevance:entry.relevance,redundancy:entry.redundancy,score:entry.score,
    features:{...entry.features},evidence:{...entry.evidence},rationale:entry.rationale,
    ...(entry.insistence!==undefined?{insistence:entry.insistence,required:entry.required,baselineLoss:entry.baselineLoss,insistenceLoss:entry.insistenceLoss}:{})}))};
}
