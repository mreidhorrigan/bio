// Authored preference, never evidence of use. Below 1 an omitted motif costs
// s/(1-s); at 1 omission is inadmissible. Instrument constraints still apply.
import {motifNotes,validateMotif} from './motifs.js';
import {Rational} from '../transcript/rational.js';
import {authoredFraction} from './performers/rhythm-cell.js';

export const MOTIF_INSISTENCE_LIMITS=Object.freeze({notes:512,active:32});
export const MOTIF_RULE_PRIORITY=Object.freeze(['physical/execution','required-motif','musical-preferences']);
const byId=(a,b)=>a<b?-1:a>b?1:0;
const before=(a,b)=>a<b-8*Number.EPSILON*Math.max(1,Math.abs(a),Math.abs(b));
export function checkedInsistence(value=0){
  if(typeof value!=='number'||!Number.isFinite(value)||value<0||value>1)
    throw new RangeError('Motif insistence must be a number from 0 to 1');
  return value;
}
export const insistenceOf=motif=>checkedInsistence(motif?.metadata?.insistence??0);
export const insistenceWeight=value=>{const s=checkedInsistence(value);return s===1?null:s/(1-s)};
export function withInsistence(motif,value){
  const insistence=checkedInsistence(value);
  if(insistence===insistenceOf(motif))return validateMotif(motif);
  const metadata={...motif.metadata};
  if(insistence)metadata.insistence=insistence;else delete metadata.insistence;
  return validateMotif({...motif,metadata});
}

// The chosen strategy supplies an ordinal baseline loss in [0,1). All of its
// shortlist comes first, then the remaining candidates in relevance order.
// Minimizing baseline loss minus the omission weight is the same as minimizing
// baseline loss plus the weights of all omitted motifs. Required motifs are
// taken first, outside that finite comparison. Zero leaves the old slate alone.
export function insistentSlate(scored,baseline,{limit,maxResults}){
  if(!scored.some(entry=>insistenceOf(entry.motif)>0))return baseline;
  const seen=new Set(baseline.map(entry=>entry.motifId)),ordered=[...baseline,...scored.filter(entry=>!seen.has(entry.motifId))];
  const entries=ordered.map((entry,index)=>{
    const insistence=insistenceOf(entry.motif),required=insistence===1,baselineLoss=index/ordered.length;
    return {...entry,insistence,required,baselineLoss,insistenceLoss:required?null:baselineLoss-insistenceWeight(insistence)};
  });
  const required=entries.filter(entry=>entry.required);
  if(required.length>maxResults)throw new RangeError('Required motifs exceed the memory response capacity');
  const soft=entries.filter(entry=>!entry.required).sort((a,b)=>a.insistenceLoss-b.insistenceLoss||a.baselineLoss-b.baselineLoss);
  return [...required,...soft].slice(0,Math.max(limit,required.length)).map(entry=>({...entry,
    reason:entry.required?'Required motif; other musical ranking preferences yield.':
      `Motif insistence ${entry.insistence}: baseline loss ${entry.baselineLoss}, adjusted loss ${entry.insistenceLoss}.`}));
}

// Whole melodic material, including arbitrarily close ornaments. Do not use
// topLine's perceptual onset grouping here: it merges notes less than 1/8 apart.
// At 100% a polyphonic clip needs an arrangement, not a silently reduced melody.
export function insistedLine(motif){
  const required=insistenceOf(motif)===1,notes=motifNotes(motif).map((note,index)=>({...note,index}))
    .sort((a,b)=>a.at-b.at||b.pitch-a.pitch),line=[];
  if(!notes.length)throw new RangeError('This motif has no pitched notes');
  for(const note of notes){
    if(!Number.isFinite(note.pitch)||!Number.isFinite(note.at)||!(note.duration>0))throw new RangeError('Motif has an unreadable note');
    const previous=line.at(-1);
    if(previous&&before(note.at,previous.at+previous.quarters)){
      if(required)throw new RangeError('A required polyphonic motif needs an explicit arrangement');
      if(note.at===previous.at)continue;
      previous.quarters=note.at-previous.at;
      if(previous.written!=null&&note.written!=null)previous.writtenQuarters=Rational.of(note.written).sub(Rational.of(previous.written)).toString();
    }
    line.push({at:note.at,pitch:note.pitch,quarters:note.duration,index:note.index,...(note.written!=null?{written:note.written,writtenQuarters:note.writtenQuarters}:{})});
  }
  if(line.length>MOTIF_INSISTENCE_LIMITS.notes)throw new RangeError('Motif exceeds the thematic plan note capacity; supply a shorter motif');
  // (Its notes where its players wrote them, where its clip says for every one (motifs.js motifNotes): exact quarters
  // from its first. A line some of whose notes were not written carries none.)
  const first=line[0].at,exact=line.every(note=>note.written!=null),origin=exact?Rational.of(line[0].written):null;
  return line.map(({written,writtenQuarters,...note})=>({...note,at:note.at-first,...(exact?{written:Rational.of(written).sub(origin).toString(),writtenQuarters}:{})}));
}
export function insistenceInstruction(motif){
  const strength=insistenceOf(motif);
  return {motifId:motif.motifId,strength,line:strength?insistedLine(motif):[]};
}
export function checkedInstruction(value){
  if(!value||typeof value.motifId!=='string'||!value.motifId)throw new TypeError('A motif instruction needs its stored ID');
  const strength=checkedInsistence(value.strength),line=value.line;
  if(!Array.isArray(line)||line.length>MOTIF_INSISTENCE_LIMITS.notes||strength>0&&!line.length)
    throw new RangeError('Motif instruction needs a bounded, nonempty line');
  let end=0;
  for(const note of line){
    if(!Number.isFinite(note?.at)||before(note.at,end)||!Number.isFinite(note.pitch)||!Number.isFinite(note.quarters)||note.quarters<=0)
      throw new RangeError('Motif instruction must be a finite monophonic line');
    end=note.at+note.quarters;
  }
  return {motifId:value.motifId,strength,line:line.map(note=>({...note}))};
}
// A standing preference carried by a motif plan, refreshed by MemoryBOT.
// Revision tombstones prevent an older plan from undoing a cleared setting.
export function hearInsistence(state,plan){
  if(plan?.kind!=='motif'||!plan.payload?.insistence)return false;
  const instruction=checkedInstruction(plan.payload.insistence),key=JSON.stringify([plan.author,instruction.motifId]),previous=state.get(key);
  if(previous&&plan.revision<=previous.revision)return false;
  if(!previous&&state.size>=512)throw new RangeError('Motif instruction history is full');
  if(instruction.strength>0&&!(previous?.strength>0)&&[...state.values()].filter(entry=>entry.strength>0).length>=MOTIF_INSISTENCE_LIMITS.active)
    throw new RangeError('Too many active motif instructions');
  const changed=!previous||JSON.stringify([previous.strength,previous.line])!==JSON.stringify([instruction.strength,instruction.line]);
  state.set(key,{...instruction,memory:plan.author,revision:plan.revision});
  return changed;
}

// A phrase offers ordinary material (weight 1) and each preferred motif with
// odds s/(1-s). One isolated preference is consequently taken with probability s.
// At the endpoint every required motif is retained, in a stable sequence.
export function chooseInsistence(instructions,random){
  const active=[...instructions].filter(entry=>entry.strength>0).sort((a,b)=>
    byId(String(a.memory??''),String(b.memory??''))||byId(a.motifId,b.motifId));
  const required=active.filter(entry=>entry.strength===1);if(required.length)return required;
  if(!active.length)return [];
  const weights=active.map(entry=>insistenceWeight(entry.strength)),largest=Math.max(1,...weights),
    ordinary=1/largest,total=ordinary+weights.reduce((sum,w)=>sum+w/largest,0);
  let draw=random()*total;if(draw<ordinary)return [];draw-=ordinary;
  for(let i=0;i<active.length;i++){draw-=weights[i]/largest;if(draw<0)return [active[i]]}
  return [active.at(-1)];
}
// `quarters`: the phrase's length, a number or a Rational (its bars' quarters, exact). Where every note of every line is
// written (insistedLine), their written onsets and lengths go on with them, exactly: each line after the one before,
// all scaled by the same ratio of the phrase's quarters to theirs where they are longer.
export function fitInsistedLines(instructions,quarters){
  const phrase=quarters instanceof Rational?quarters:Number.isFinite(quarters)&&quarters>0?authoredFraction(quarters):null;
  if(!phrase||phrase.sign()<=0)throw new RangeError('A motif needs a positive phrase length');
  let end=0,writtenEnd=Rational.ZERO;const notes=[],checked=instructions.map(checkedInstruction);
  const exact=checked.every(item=>item.line.every(note=>typeof note.written==='string'&&typeof note.writtenQuarters==='string'));
  for(const item of checked){
    for(const note of item.line)notes.push({...note,at:end+note.at,motifId:item.motifId,...(exact?{written:writtenEnd.add(Rational.of(note.written))}:{})});
    end+=Math.max(...item.line.map(note=>note.at+note.quarters));
    if(exact)writtenEnd=writtenEnd.add(item.line.reduce((last,note)=>last.max(Rational.of(note.written).add(Rational.of(note.writtenQuarters))),Rational.ZERO));
  }
  if(notes.length>MOTIF_INSISTENCE_LIMITS.notes)throw new RangeError('Required material exceeds the phrase note capacity');
  const length=phrase.toNumber(),scale=Math.min(1,length/end),ratio=exact?phrase.div(writtenEnd).min(1):null;
  return {scale,notes:notes.map(({written,writtenQuarters,...note})=>({...note,at:note.at*scale,quarters:note.quarters*scale,
    ...(exact?{written:written.mul(ratio).toString(),writtenQuarters:Rational.of(writtenQuarters).mul(ratio).toString()}:{})}))};
}

// Whole-octave placement of each motif preserves its intervals and tuning.
// An impossible compass has no placement; never fold individual notes into it.
export function requiredMotifPitches(notes,{centre,compass=null,octave=null}={}){
  const groups=new Map;
  notes.forEach((note,index)=>{const id=note.motifId??'';if(!groups.has(id))groups.set(id,[]);groups.get(id).push(index)});
  const pitches=new Array(notes.length);
  for(const indices of groups.values()){
    const values=indices.map(index=>notes[index].pitch),low=Math.min(...values),high=Math.max(...values),
      mean=values.reduce((a,b)=>a+b,0)/values.length,target=Number.isFinite(centre)?centre:mean;
    let k=Number.isFinite(octave)?octave/12:Math.round((target-mean)/12);
    if(compass){
      if(!Number.isFinite(compass.low)||!Number.isFinite(compass.high)||compass.low>compass.high)return null;
      const from=Math.ceil((compass.low-low)/12),to=Math.floor((compass.high-high)/12);
      if(from>to)return null;
      if(Number.isFinite(octave)){if(k<from||k>to)return null}else k=Math.max(from,Math.min(to,k));
    }
    for(const index of indices)pitches[index]=notes[index].pitch+12*k;
  }
  return pitches;
}

// A conductor's feasible musical proposals are decided first. A soft preference
// can claim an available melodic pool; a requirement supersedes texture, rest,
// cadence and counterpoint preferences. The player checks its physical compass.
export function insistOnFormation(formation,instructions,{quarters,random,softAllowed=true,compasses=null}){
  const chosen=chooseInsistence(instructions,random);if(!chosen.length)return {formation};
  const required=chosen.some(entry=>entry.strength===1);
  if(!required&&!softAllowed)return {formation};
  const conflict=reason=>({formation,conflict:{motifIds:chosen.map(entry=>entry.motifId),reason,
    winner:'physical/execution',compromised:'required-motif',resolution:'ordinary formation',priority:[...MOTIF_RULE_PRIORITY]}});
  let fitted;
  try{fitted=fitInsistedLines(chosen,quarters)}catch(error){return required?conflict(error.message):{formation}}
  const candidates=formation.pools.filter(pool=>pool.seats?.length&&(required||pool.texture==='line'&&!pool.given)&&
    (!required||!compasses||pool.seats.every(id=>requiredMotifPitches(fitted.notes,{centre:pool.centre,compass:compasses.get(id)}))));
  const carrier=candidates.sort((a,b)=>Number(b.centre)-Number(a.centre)||byId(String(a.id),String(b.id)))[0];
  if(!carrier)return required?conflict('No available melodic pool can fit every required motif in its physical compass'):{formation};
  const use={motifIds:chosen.map(entry=>entry.motifId),strength:Math.max(...chosen.map(entry=>entry.strength)),
    required,timeScale:fitted.scale,status:'planned',
    compromised:required?['texture','rest','cadence','harmony','counterpoint','improvisation']:[]};
  return {use,formation:{...formation,pools:formation.pools.map(pool=>{
    if(pool!==carrier)return pool;
    if(!required)return {...pool,themeLine:fitted.notes,motifUse:use};
    const {entries,entryRegisters,ending,tapeLine,themeLine,lineage,parameters,givenOctave,...kept}=pool;
    return {...kept,texture:'line',only:[...pool.seats],parts:pool.parts.map(()=>0),given:fitted.notes,motifUse:use,motifFallback:pool,
      latitude:0,tremolo:0,elongation:1,inversion:0,retrograde:false};
  })}};
}
