// Two pieces meeting, negotiated rather than replaced (RESEARCH_BACKLOG "Conductors that negotiate, not elect";
// research/conductor-negotiation/IMPLEMENTER_HANDOFF.md). The pure parts of EnsembleConductor's negotiating mode:
// what a piece offers (its next downbeat after a lead, its tempo and its bounds, the bar counts that end on its phrase
// boundaries), the plan the leading conductor proposes from both (conductor-rendezvous-solver.js's bridge: a constant
// tempo each from its anchor, all arriving together at T, where the leader's meter and tempo begin for both), its digest,
// its validation by the piece asked, each piece's bridge, and the coupling after arrival: the joined piece takes the
// leader's timing from then on while keeping its own bar, beat and tick counts, seed and beginning.
//
// Ours, and the conductor's policy (`RENDEZVOUS`): how far ahead a plan may begin, how long it may take, how far a bridge
// may bend a tempo, how many phrases a piece may play before it arrives.
import {solveRendezvous,checkRendezvousWitness} from './conductor-rendezvous-solver.js';

export const RENDEZVOUS=Object.freeze({
  // A bridge begins no sooner than this after a plan is made (seconds): time for the answer, the commit and its
  // acknowledgement, with the clock and scheduling margin.
  leadSeconds:3,
  // The commit must be in hand this long before a piece's own anchor, or it does not bridge.
  commitMarginSeconds:.75,
  // The latest a piece may arrive, after the lead (seconds).
  windowSeconds:90,
  // A bridge tempo at most this ratio from a piece's own, either way, and within the clock's 40-220.
  maxTempoRatio:1.25,
  // A piece arrives at one of its own phrase boundaries ('phrase'), or at any bar line ('bar'), within this many phrases.
  arriveOn:'phrase',phrases:8,
  // After this many refused or failed rendezvous, a piece asking takes the leader's piece up instead.
  attempts:3,
});
const MIN_BPM=40,MAX_BPM=220;
const toRational=seconds=>`${Math.round(seconds*1e6)}/1000000`;
const copy=value=>structuredClone(value);
function fnv(text){let hash=0x811c9dc5;for(let i=0;i<text.length;i++){hash^=text.charCodeAt(i);hash=Math.imul(hash,0x01000193)>>>0}return hash.toString(16).padStart(8,'0')}
const canonical=value=>Array.isArray(value)?`[${value.map(canonical).join(',')}]`:value&&typeof value==='object'?`{${Object.keys(value).sort().map(key=>`${JSON.stringify(key)}:${canonical(value[key])}`).join(',')}}`:JSON.stringify(value);
export const planDigest=plan=>`rendezvous:${fnv(canonical({...plan,digest:undefined}))}`;

// Why a cursor cannot offer a basis now, or null: a change already pending would move its downbeats under the plan.
export function frozenBasisProblem(cursor){
  if(!cursor)return 'no-piece';
  for(const [key,reason] of [['pendingMeter','meter-change-pending'],['pendingTempo','tempo-change-pending'],['curve','tempo-curve-running'],['inputTempoCommit','input-tempo-committed']])
    if(cursor[key])return reason;
  return null;
}
// What a piece offers: its first downbeat at least `leadSeconds` after `now` (the anchor), its tempo and bounds, and the
// bar counts from the anchor that end on its phrase boundaries. `advance` is the cursor recurrence (ensemble-cursor.js).
export function rendezvousBasis(cursor,{id,now,advance,policy=RENDEZVOUS}){
  const problem=frozenBasisProblem(cursor);if(problem)throw new Error(problem);
  const future=copy(cursor);let steps=0;
  while((future.tickInBar!==0||future.at<now+policy.leadSeconds)&&steps++<200000)advance(future);
  if(steps>=200000)throw new Error('anchor-beyond-budget');
  const meter=future.meter,phraseBars=Math.max(1,Number(meter.phraseBars)||4),bars=[];
  for(let k=1;k<=policy.phrases*phraseBars&&bars.length<64;k++)if(policy.arriveOn==='bar'||(future.bar+k)%phraseBars===0)bars.push(k);
  const low=Math.max(MIN_BPM,future.bpm/policy.maxTempoRatio),high=Math.min(MAX_BPM,future.bpm*policy.maxTempoRatio);
  return {participant:{id,anchor:toRational(future.at),beatsPerBar:meter.numerator,bpm:toRational(future.bpm),minBpm:toRational(low),maxBpm:toRational(high),bars},
    anchor:{at:future.at,bar:future.bar,tick:future.tick,beat:future.beat,pulsesPerBar:meter.pulsesPerBar,subdivision:meter.subdivision}};
}
// The plan the leading conductor proposes: both bases, the solver's witness, the leader's meter and tempo as the target
// from T, and the time by which it must be committed. -> {plan} or {refused: reason}.
// The pieces meet as soon as they can within the bounds: the solver's least distortion is sought among each piece's
// first allowed count (its next phrase boundary, or bar), then its first two, four, and so on to all of them, and the
// first horizon that holds a rendezvous is taken (the least distortion over the whole horizon would put the meeting as
// late as it could be).
export function proposeRendezvous({planId,sessionId,epoch,coordinator,requester,target,now,policy=RENDEZVOUS,options}){
  let input,result;
  const most=Math.max(coordinator.basis.participant.bars.length,requester.basis.participant.bars.length);
  for(let count=1;;count=Math.min(most,count*2)){
    const cut=participant=>({...participant,bars:participant.bars.slice(0,Math.max(1,count))});
    input={referenceEpoch:epoch,earliest:toRational(now+policy.leadSeconds),deadline:toRational(now+policy.leadSeconds+policy.windowSeconds),
      participants:[cut(coordinator.basis.participant),cut(requester.basis.participant)]};
    result=solveRendezvous(input,options);
    if(['optimal','optimality-bracket'].includes(result.status)||count>=most)break;
  }
  if(!['optimal','optimality-bracket'].includes(result.status))return {refused:result.status==='infeasible'?'no-common-downbeat-within-bounds':result.status,result};
  const commitBy=Math.min(coordinator.basis.anchor.at,requester.basis.anchor.at)-policy.commitMarginSeconds;
  if(commitBy<=now)return {refused:'no-time-to-commit'};
  const side=party=>({host:party.host,incarnation:party.incarnation,seed:party.seed,startedAt:party.startedAt,revision:party.revision,anchor:party.basis.anchor});
  const plan={version:1,planId,sessionId,epoch,createdAt:now,commitBy,coordinator:side(coordinator),requester:side(requester),input,witness:result.witness,
    target:{meter:copy(target.meter),bpm:target.bpm},status:result.status};
  plan.digest=planDigest(plan);
  return {plan};
}
// Whether the piece asked may accept: the plan is intact, for this session, reference and piece as they are now, its
// witness holds, it can still be committed before this piece's anchor, and its target is one this piece takes.
// -> null, or the reason it may not.
export function rendezvousProblem(plan,{host,incarnation,sessionId,epoch,cursor,now,policy=RENDEZVOUS,acceptTarget=()=>true,options}){
  if(!plan||plan.version!==1||plan.digest!==planDigest(plan))return 'altered-plan';
  if(plan.sessionId!==sessionId)return 'other-session';
  if(plan.epoch!==epoch)return 'other-reference-epoch';
  const own=plan.requester.host===host?plan.requester:plan.coordinator.host===host?plan.coordinator:null;
  if(!own||own.incarnation!==incarnation)return 'not-a-party';
  if(!cursor||cursor.seed!==own.seed||cursor.startedAt!==own.startedAt)return 'other-piece';
  if(cursor.revision!==own.revision)return 'piece-changed';
  const problem=frozenBasisProblem(cursor);if(problem)return problem;
  if(now>=own.anchor.at-policy.commitMarginSeconds)return 'anchor-missed';
  const checked=checkRendezvousWitness(plan.input,plan.witness,options);
  if(checked.status!=='verified-feasible')return `witness-${checked.status}`;
  const bpm=Number(plan.target?.bpm);
  if(!(bpm>=MIN_BPM&&bpm<=MAX_BPM)||!Number.isInteger(plan.target?.meter?.numerator))return 'target-invalid';
  if(!acceptTarget(plan.target,plan))return 'target-declined';
  return null;
}
// A party's bridge: from its anchor bar, its constant bridge tempo; at its arrival bar, the target.
export function bridgeOf(plan,host){
  const side=plan.coordinator.host===host?'coordinator':'requester',own=plan[side],choice=plan.witness.participants[side==='coordinator'?0:1];
  const [n,d]=String(choice.bridgeBpm).split('/').map(Number);
  return {side,anchorBar:own.anchor.bar,arrivalBar:own.anchor.bar+choice.bars,bridgeBpm:d?n/d:n,bars:choice.bars,target:plan.target,planId:plan.planId};
}
// At arrival, where the joined piece's counts stand against the leader's: its bar, tick and beat minus the leader's.
export function couplingOf(plan){
  const at=(side,index)=>{const own=plan[side],bars=plan.witness.participants[index].bars;
    return {bar:own.anchor.bar+bars,tick:own.anchor.tick+bars*own.anchor.pulsesPerBar,beat:own.anchor.beat+bars*own.anchor.pulsesPerBar/own.anchor.subdivision}};
  const joined=at('requester',1),leader=at('coordinator',0);
  return {piece:{seed:plan.coordinator.seed,startedAt:plan.coordinator.startedAt},planId:plan.planId,
    offsets:{bar:joined.bar-leader.bar,tick:joined.tick-leader.tick,beat:joined.beat-leader.beat}};
}
// The leader's state as the joined piece plays it: the leader's timing, meter and changes, its own counts (the leader's
// plus the offsets, every bar a change names moved with them), seed and beginning.
export function coupledState(state,coupling,own){
  const s=copy(state),{bar,tick,beat}=coupling.offsets;
  s.bar+=bar;s.tick+=tick;s.beat+=beat;s.seed=own.seed;s.startedAt=own.startedAt;
  if(s.pendingMeter)s.pendingMeter.targetBar+=bar;
  if(s.pendingTempo)s.pendingTempo.targetBar+=bar;
  if(s.curve)s.curve.startBar+=bar;
  if(s.scoreTempo?.pendingTempoCurve)s.scoreTempo.pendingTempoCurve.targetBar+=bar;
  if(s.scoreTempo?.tempoCurve){s.scoreTempo.tempoCurve.startBar+=bar;s.scoreTempo.tempoCurve.targetBar+=bar;}
  if(s.inputTempoCommit){s.inputTempoCommit.startBar+=bar;s.inputTempoCommit.endBar+=bar;}
  if(s.bar<0||s.tick<0||s.beat<0)throw new Error('coupled-counts-negative');
  return s;
}
