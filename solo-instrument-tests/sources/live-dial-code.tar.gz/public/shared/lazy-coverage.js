// Exact greedy order for the declared floating coverage-plus-modular objective.
// Nonnegative finite weights make previously evaluated marginal gains upper bounds.
export function selectLazyCoverage(entries,{limit,categories,weights,modular=()=>0}){
  if(!Number.isSafeInteger(limit)||limit<0||entries.length>65536)throw new RangeError('coverage bounds');
  const seenIds=new Set(),covered=new Set(),heap=[],out=[];
  const compare=(a,b)=>b.gain-a.gain||(a.entry.motifId<b.entry.motifId?-1:a.entry.motifId>b.entry.motifId?1:0);
  const push=x=>{heap.push(x);let i=heap.length-1;while(i){const p=(i-1)>>1;if(compare(heap[i],heap[p])>=0)break;[heap[i],heap[p]]=[heap[p],heap[i]];i=p}};
  const pop=()=>{const first=heap[0],last=heap.pop();if(heap.length){heap[0]=last;let i=0;for(;;){let c=i*2+1;if(c>=heap.length)break;
    if(c+1<heap.length&&compare(heap[c+1],heap[c])<0)c++;if(compare(heap[c],heap[i])>=0)break;[heap[c],heap[i]]=[heap[i],heap[c]];i=c}}return first};
  const gain=x=>{let v=0;for(const c of x.categories)if(!covered.has(c))v+=weights.get(c);v+=x.modular;if(!Number.isFinite(v))throw new RangeError('gain overflow');return v};
  for(const entry of entries){if(typeof entry.motifId!=='string'||seenIds.has(entry.motifId))throw new RangeError('unique motif identity');seenIds.add(entry.motifId);
    const cs=Array.from(categories(entry));if(cs.length>4096||new Set(cs).size!==cs.length)throw new RangeError('distinct bounded categories');
    for(const c of cs)if(!Number.isFinite(weights.get(c))||weights.get(c)<0)throw new RangeError('finite nonnegative category weight');
    const m=modular(entry);if(!Number.isFinite(m)||m<0)throw new RangeError('nonnegative modular term');
    const x={entry,categories:cs,modular:m,stamp:0};x.gain=gain(x);push(x)}
  while(out.length<limit&&heap.length){const x=pop();if(x.stamp!==out.length){x.gain=gain(x);x.stamp=out.length;push(x);continue}
    const fresh=x.categories.filter(c=>!covered.has(c));for(const c of fresh)covered.add(c);
    x.entry.score=Number(x.gain.toFixed(6));x.entry.reason=fresh.length?`covers ${fresh.join(', ')}`:'adds no region the answer did not already hold';out.push(x.entry)}
  return out;
}

// Optional bounded content cache. The caller supplies an immutable content/policy key; dynamic usage is excluded.
export function memoizeContentPairs(compare,{maxEntries=4096}={}){
  if(!Number.isSafeInteger(maxEntries)||maxEntries<1||maxEntries>1000000)throw new RangeError('cache bound');const cache=new Map();
  return (leftKey,rightKey,policyKey,left,right,policy)=>{
    if([leftKey,rightKey,policyKey].some(x=>typeof x!=='string'))throw new TypeError('canonical string keys');
    const key=JSON.stringify([leftKey,rightKey,policyKey]);if(cache.has(key)){const v=cache.get(key);cache.delete(key);cache.set(key,v);return v}
    const value=compare(left,right,policy);if(cache.size===maxEntries)cache.delete(cache.keys().next().value);cache.set(key,value);return value;
  };
}
