// A meter as a felt meter, by its tempo (the owner, 4 October 2026: "Don't restrict *which meters* can be used, but do
// restrict *at what tempo* they can be used, so that a pattern that should be a hypermeter (e.g., 107/4 at 60bpm) is not
// given as a meter although it can still be used as a hypermetrical cycle"; "107/32 could still appear *if its tempo is
// fast enough to make it feelable*"). A bar is a meter at a tempo where
//   - it lasts no longer than a listener hears as one group (metric-home/nested.js NESTING.longestSeconds: "within the
//     few seconds a measure can last", London 2012, Hearing in Time, doi:10.1093/acprof:oso/9780199744374.001.0001), and
//   - some level of its grouping -- its notes, its groups, the groups of its groups (grouping.js metricTree), its
//     intended beats where it has a reading -- moves at a beat a listener takes as one: the score policy's candidate
//     beat, its favored one within it (research/meter/score-policy.json, felt-meter-catalog.js FELT_METER_POLICY: from
//     pulse-salience experiments, Parncutt 1994, doi:10.2307/40285633).
// At a tempo outside that, the same pattern is no meter but a hypermetrical cycle: bars of its groups, its whole length
// their cycle (feltBars). Tempi are a clock's: its bpm counts the meter's own notes (tempo-display.js).
import {FELT_METER_POLICY} from './felt-meter-catalog.js';
import {NESTING} from './metric-home/nested.js';
import {metricTree,groupCounts} from './metric-home/grouping.js';
import {tempoRange} from './tempo-range.js';

const value=text=>{const [n,d='1']=String(text).split('/');return Number(n)/Number(d)};
const band=list=>[value(list[0]),value(list[1])];
export const FELT_TEMPO=Object.freeze({beat:Object.freeze(band(FELT_METER_POLICY.candidateBeatSeconds)),favoredBeat:Object.freeze(band(FELT_METER_POLICY.favoredBeatSeconds)),
  longestBarSeconds:NESTING.longestSeconds});

// A span's cells, in order: groups of three and two (grouping.js groupCounts, its own preference first).
const cellsOf=units=>[...groupCounts(units)].flatMap(([size,count])=>Array(count).fill(size));
// A meter's levels, each its spans in its own notes: its notes; within each group, its cells and the groups of its
// cells, level by level (a group with fewer levels whole at the deeper ones); its groups and the groups of its groups;
// its intended beats.
export function meterLevels(meter){
  const n=Math.max(1,Math.round(Number(meter?.numerator)||1)),groups=Array.isArray(meter?.groups)&&meter.groups.reduce((a,b)=>a+b,0)===n?meter.groups.map(Number):[n];
  const within=groups.map(group=>metricTree(cellsOf(group)).levels.map(level=>level.spans)),depth=Math.max(...within.map(list=>list.length));
  const levels=[[1],...Array.from({length:depth},(_,d)=>within.flatMap((list,k)=>list[d]??[groups[k]])),...metricTree(groups).levels.map(level=>level.spans)];
  const beats=meter?.metricReading?.beatWeights;if(Array.isArray(beats)&&beats.length&&beats.every(w=>w>0))levels.push(beats.map(Number));
  return levels.filter((spans,k,all)=>all.findIndex(other=>other.join()===spans.join())===k);
}
// The clock tempi (bpm of the meter's notes) at which `meter` is a felt meter: [[low, high], ...] in order, merged, within
// `range` (the clock's: tempo-range.js); `beat` the beat band (s). Empty where none is.
export function feltTempi(meter,{beat=FELT_TEMPO.beat,longest=FELT_TEMPO.longestBarSeconds,range=tempoRange(meter)}={}){
  const n=Math.max(1,Number(meter?.numerator)||1),[shortestBeat,longestBeat]=beat,least=Math.max(range[0],60*n/longest),most=range[1];
  const spans=meterLevels(meter).map(level=>[60*Math.max(...level)/longestBeat,60*Math.min(...level)/shortestBeat]).map(([a,b])=>[Math.max(a,least),Math.min(b,most)]).filter(([a,b])=>a<=b);
  const merged=[];for(const [a,b] of spans.sort((x,y)=>x[0]-y[0])){const last=merged.at(-1);if(last&&a<=last[1])last[1]=Math.max(last[1],b);else merged.push([a,b])}
  return merged;
}
// Whether `meter` at `bpm` is a felt meter.
export const isFeltMeter=(meter,bpm,options)=>feltTempi(meter,options).some(([a,b])=>bpm>=a-1e-9&&bpm<=b+1e-9);
// A tempo for `meter` drawn log-uniform over where it is felt, its favored beats where they can be (`random`: [0, 1)).
// -> bpm, or null where it is felt at none.
export function feltTempo(meter,random,options={}){
  const favored=feltTempi(meter,{...options,beat:FELT_TEMPO.favoredBeat}),windows=favored.length?favored:feltTempi(meter,options);if(!windows.length)return null;
  const widths=windows.map(([a,b])=>Math.log(b/a)),total=widths.reduce((s,w)=>s+w,0);
  if(!(total>0))return +windows[0][0].toFixed(3);
  let u=random()*total;for(const [k,[a,b]] of windows.entries()){if(u<=widths[k]||k===windows.length-1)return +(a*(b/a)**Math.min(1,u/widths[k])).toFixed(3);u-=widths[k]}
  return null;
}
