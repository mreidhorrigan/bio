// Intended beats and the score's reference note, independent of the transport's denominator-note clock.
// Selection ranges are authored policy. Nothing here estimates a listener's confidence or a player's capability.
import {FELT_METER_CATALOG,FELT_METER_POLICY} from './felt-meter-catalog.js';
import {tempoRange} from './tempo-range.js';

export const EDITORIAL_ACTIONS=Object.freeze(['PUBLISH_STANDARD','PUBLISH_GROUPED','PUBLISH_SPECIALIST_WITH_LEGEND',
  'KEEP_WITH_SUPPORT','PREFER_LOCAL_BARS_WITH_CYCLE_BRACKET','HOLD_FOR_REVIEW','FREE_TIME_BY_INTENT']);
const sum=xs=>xs.reduce((a,b)=>a+b,0),value=text=>{const [n,d=1]=text.split('/').map(Number);return n/d};
const freeze=value=>{if(value&&typeof value==='object'){Object.values(value).forEach(freeze);Object.freeze(value)}return value};

// Also embedded in meter.cjs and public/meter.js, which must load without ESM. Parity is tested.
export function normalizeMetricReading(reading,numerator,groups){
  if(!reading||reading.version!==1||typeof reading.id!=='string'||!reading.id||reading.id.length>160)return null;
  const weights=reading.beatWeights,partition=reading.beatGroups,ref=reading.reference;
  if(!Array.isArray(weights)||!weights.length||weights.length>256||!weights.every(n=>Number.isSafeInteger(n)&&n>0)||weights.reduce((a,b)=>a+b,0)!==numerator)return null;
  if(!Array.isArray(partition)||!partition.length||!partition.every(n=>Number.isSafeInteger(n)&&n>0)||partition.reduce((a,b)=>a+b,0)!==weights.length)return null;
  let at=0;const spans=partition.map(n=>{const total=weights.slice(at,at+n).reduce((a,b)=>a+b,0);at+=n;return total});
  if(spans.join()!==groups.join()||!ref||![1,2,4,8,16,32,64].includes(ref.unit)||![0,1].includes(ref.dots))return null;
  if(!['standard','grouped','specialist'].includes(reading.kind)||!['PUBLISH_STANDARD','PUBLISH_GROUPED','PUBLISH_SPECIALIST_WITH_LEGEND','KEEP_WITH_SUPPORT','PREFER_LOCAL_BARS_WITH_CYCLE_BRACKET','HOLD_FOR_REVIEW','FREE_TIME_BY_INTENT'].includes(reading.editorialAction))return null;
  return {version:1,id:reading.id,beatWeights:[...weights],beatGroups:[...partition],reference:{unit:ref.unit,dots:ref.dots},
    kind:reading.kind,editorialAction:reading.editorialAction,profile:'score-selection-v2',confidence:null,
    preserveDenominator:true,...(typeof reading.reason==='string'?{reason:reading.reason.slice(0,512)}:{})};
}

export function metricReadingFor(meter,{id='authored-grouping',beatWeights=meter.groups,kind='grouped',
  reference={unit:4,dots:0},editorialAction='HOLD_FOR_REVIEW',reason='Authored grouping; human validation is separate.'}={}){
  let at=0;const beatGroups=[];
  for(const span of meter.groups){
    let used=0,count=0;
    while(at<beatWeights.length&&used<span){used+=beatWeights[at++];count++}
    if(used!==span)throw new RangeError('Notation groups must be unions of whole intended beats');
    beatGroups.push(count);
  }
  const reading=normalizeMetricReading({version:1,id,beatWeights,beatGroups,reference,kind,editorialAction,reason},meter.numerator,meter.groups);
  if(!reading)throw new RangeError('Invalid intended meter reading');
  return freeze(reading);
}

export function meterFromReading(row,{subdivision=2}={}){
  const meter={numerator:row.numerator,denominator:row.denominator,groups:[...row.groups],subdivision,tempoUnit:4};
  const editorialAction=row.kind==='standard'?'PUBLISH_STANDARD':row.kind==='specialist'?'PUBLISH_SPECIALIST_WITH_LEGEND':'PUBLISH_GROUPED';
  meter.metricReading=metricReadingFor(meter,{...row,editorialAction,reason:'Chosen within the authored duration profile for new material.'});
  meter.label=`${meter.groups.join('+')}/${meter.denominator} · in ${row.beatWeights.length}`;
  return meter;
}

// No minimum cycle duration. This inexpensive construction is for newly authored readings; exact review is in
// felt-meter.js. Existing music is never retimed because it misses this preference.
export function readingTempoWindow(meter,{candidate=false}={}){
  const weights=meter.metricReading?.beatWeights??meter.groups;
  if(!weights?.length)return null;
  const [least,most]=candidate?FELT_METER_POLICY.candidateBeatSeconds:FELT_METER_POLICY.favoredBeatSeconds;
  const low=Math.max(240*Math.max(...weights)/(meter.denominator*value(most)),60*meter.numerator/meter.denominator);
  const high=240*Math.min(...weights)/(meter.denominator*value(least));
  return low<=high?[low,high]:null;
}
export function readingClockWindow(meter,options){
  const range=readingTempoWindow(meter,options);if(!range)return null;
  const transport=tempoRange(meter),unit=meter.denominator/4;
  const low=Math.max(transport[0],range[0]*unit),high=Math.min(transport[1],range[1]*unit);
  return low<=high?[low,high]:null;
}

// A direct draw from precomputed feasible intervals. No draw-and-reject and no search in the audio callback.
// For a move, prefer preserving quarter duration; octave changes are explicit metric modulations.
export function drawScoreMeter(random,{quarterBPM=null,exclude=null,subdivision=null}={}){
  const choices=[];
  for(const row of FELT_METER_CATALOG){
    if(row.id===exclude)continue;
    const [low,top]=row.favoredQuarterBPM.map(value),high=Math.min(720,top);if(low>high)continue;
    let q=null,octaves=0;
    if(quarterBPM!==null){
      if(!(Number.isFinite(quarterBPM)&&quarterBPM>0))throw new RangeError('Quarter tempo must be positive');
      const from=Math.ceil(Math.log2(low/quarterBPM)),to=Math.floor(Math.log2(high/quarterBPM));
      if(from>to)continue;
      octaves=Math.max(from,Math.min(to,0));q=quarterBPM*2**octaves;
    }
    choices.push({row,low,high,q,octaves});
  }
  if(!choices.length)return null;
  const leastChange=Math.min(...choices.map(x=>Math.abs(x.octaves))),available=choices.filter(x=>Math.abs(x.octaves)===leastChange);
  const chosen=available[Math.min(available.length-1,Math.floor(random()*available.length))];
  const quarter=chosen.q??chosen.low*(chosen.high/chosen.low)**random();
  const meter=meterFromReading(chosen.row,{subdivision:subdivision??[1,2,3,4,5,6][Math.min(5,Math.floor(random()*6))]});
  return {meter,bpm:quarter*meter.denominator/4,octaves:chosen.octaves};
}

export function readingLegend(meter){
  const reading=meter?.metricReading;if(!reading)return null;
  let at=0;
  const groups=reading.beatGroups.map(n=>{const text=reading.beatWeights.slice(at,at+n).join('+');at+=n;return text});
  return `in ${reading.beatWeights.length}: ${groups.join(' | ')} (units of 1/${meter.denominator})`;
}
export function referenceTempo(meter,clockBPM){
  const ref=meter.metricReading?.reference;
  if(!ref)return null;
  return {bpm:clockBPM*ref.unit/(meter.playedDenominator??meter.denominator)/(ref.dots?1.5:1),
    beatUnit:ref.unit,dotted:ref.dots===1};
}
