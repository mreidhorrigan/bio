// FNV-1a, the 32-bit string hash (G. Fowler, L. C. Noll, K.-P. Vo; D. Eastlake et al., "The FNV Non-Cryptographic Hash
// Algorithm", IETF draft-eastlake-fnv): its offset basis and prime, a text's hash, and the hashes' span -- what a
// deterministic draw keyed by a name reads (a share in [0, 1) is its hash over FNV_SPAN). `start` another basis -- a
// seed folded into it, as a seeded source keys its draws by a seed and a name.
export const FNV_OFFSET=2166136261,FNV_PRIME=16777619,FNV_SPAN=2**32;
export function fnv1a(text,start=FNV_OFFSET){
  let h=start;
  for(const c of text){h^=c.charCodeAt(0);h=Math.imul(h,FNV_PRIME)>>>0}
  return h;
}
