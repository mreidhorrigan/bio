// A drum kit on a desk, a channel per drum: which of a kit's pieces (percussion-expression.js PIECES) share a channel,
// what each channel is called, and where on the stereo image each starts.
//
// The user, 26 September 2026: "Many mixing styles aim for particularly punchy snare and kick; so, in advanced mixing,
// the whole drum kit should not necessarily be treated as a unit", and "make sure that mixbot and the desk are able to
// distribute instruments - including individual drums played by one drumbot - in a stereo image."
//
// A kit split this way is what a multi-output drum instrument gives a studio desk: a channel each for the kick, the
// snare, the hats, the toms, the cymbals and the percussion, each with its own fader, pan and inserts, all summed into
// the kit's own channel (audio.js splitKit; the bot's channel becomes the kit's bus). Ride and crash have a channel each
// because a kit's cymbals stand on either side of it, and a channel is placed as one thing; a clap shares the snare's,
// since the two are played as one backbeat (ours).
//
// Where each stands: a kit is voiced from the drummer's seat (a right-handed kit: hats and crash to the left, ride and
// floor tom to the right, the toms high to low from left to right), which is where a desk places a kit's drums when
// nothing else decides. The user, 26 September 2026: "If all other things are equal, the mixbot should favour placing
// individual drums from the drummer's perspective (with the option to influence and change this preference depending
// on intended aesthetics; e.g., a 'wall of sound' is usually from an audience perspective, a certain distance away, I
// think)". The audience's view is the same kit mirrored (KIT_PERSPECTIVES), which a desk makes by mirroring each
// channel (live-desk.js). How far from the middle: where practitioners put them (De Man 2017 Table 2.4, on a pan pot's
// travel from 7:00 to 17:00: hi-hat 14:30-15:30, 0.5-0.7; ride 15:00, 0.6; crashes 9:00 and 14:00, 0.6 and 0.4; toms
// 10:00, 13:00 and 14:00, -0.4 to 0.4), the snare a little toward its hats, and the hand drums and percussion on the
// ride's side, where a kit leaves room (ours). A channel holding several drums (the toms, the hand drums) spreads them
// within itself, each hit placed by its note (kitHitPan): a tom by where it sits among the General MIDI toms.

// ---- Definitions -------------------------------------------------------------------------------------------------------
export const KIT_CHANNELS=Object.freeze({
  kick:Object.freeze(['kick']),
  snare:Object.freeze(['snare','clap']),
  hats:Object.freeze(['hat']),
  toms:Object.freeze(['tom']),
  ride:Object.freeze(['ride']),
  crash:Object.freeze(['crash']),
  hands:Object.freeze(['conga']),
  perc:Object.freeze(['perc']),
});
export const KIT_CHANNEL_NAMES=Object.freeze(Object.keys(KIT_CHANNELS));
// Each channel's place, from the drummer's seat: -1 left, 1 right.
export const KIT_HOMES=Object.freeze({kick:0,snare:-.1,hats:-.6,toms:0,ride:.6,crash:-.5,hands:.4,perc:.5});
// The views a kit is heard from, as the sign its drummer's-seat places take.
export const KIT_PERSPECTIVES=Object.freeze({drummer:1,audience:-1});
// A drum's place within a channel holding several: the General MIDI toms from high (50) on the left to the floor tom
// (41) on the right, as the practitioners' toms (above); the hand drums (60 to 64) from the high bongo to the tumba,
// less far apart (ours).
export const KIT_SPREADS=Object.freeze({
  toms:Object.freeze({high:50,low:41,from:-.4,to:.4}),
  hands:Object.freeze({high:60,low:64,from:-.2,to:.2}),
});
// A kit channel's mixer track: the kit's own track id and the channel's name.
export const KIT_SEPARATOR='/';

// ---- Arithmetic --------------------------------------------------------------------------------------------------------
// The channel a piece is heard on ('perc' for one no channel names).
export function kitChannelOf(piece){
  for(const [channel,pieces] of Object.entries(KIT_CHANNELS))if(pieces.includes(piece))return channel;
  return 'perc';
}
export const kitTrackId=(trackId,channel)=>`${trackId}${KIT_SEPARATOR}${channel}`;
// Where within its channel a hit is placed, from the drummer's seat: by its note in a channel that spreads its drums,
// else in the middle.
export function kitHitPan(channel,note){
  const spread=KIT_SPREADS[channel];
  if(!spread||!Number.isFinite(Number(note)))return 0;
  const at=(Number(note)-spread.high)/(spread.low-spread.high);
  return spread.from+(spread.to-spread.from)*Math.max(0,Math.min(1,at));
}
// The sign of a perspective's places (drummer's: 1, audience's: -1); an unknown one is the drummer's.
export const perspectiveSign=perspective=>KIT_PERSPECTIVES[perspective]??(Number(perspective)<0?-1:1);
// The kit's track id and the channel's name, from a kit channel's track id; null for any other track.
export function kitTrackOf(id){
  const text=String(id),at=text.lastIndexOf(KIT_SEPARATOR),channel=text.slice(at+1);
  return at>0&&KIT_CHANNELS[channel]?{track:text.slice(0,at),channel}:null;
}
