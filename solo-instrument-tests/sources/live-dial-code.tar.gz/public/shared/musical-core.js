// The bots' musical core in Rust, from JavaScript (research/RUST_PORT_STATE.md; the owner, 17 October 2026: the
// counterpoint, and whatever else dominates a performance's run time, ported to Rust so that musical performance can be
// tested much faster): the WASM module wasm/musical-core builds (public/wasm/musical-core/musical_core.wasm), and the
// same calls as the modules it ports, each making the same decisions from the same inputs and draws. The JavaScript
// stays the reference: test/musical-core-*.test.mjs hold the two together.
//
// A call takes what the Rust takes -- numbers, finite -- and declines anything else (null) before it draws or calls
// anything, so the module it stands in for plans that itself, as it always has: a malformed input fails there as it
// failed before. What the JavaScript passes as a function arrives as data: a strong beat's test asked once for each
// note, a delayed voice's map once for each of the ladder's steps, and counterLine's `random` drawn as many times as
// its search would draw, in its order, before the search (the count is known from the sizes alone).
//
// A call whose draws depend on what it draws (subjectFrom) asks the caller's `random` one draw at a time instead, as the
// JavaScript would: the module imports env.mc_host_random.
//
// Wherever the bots are loaded it is installed already (musical-core-installed.js, which agents.js imports); by hand:
//   const core=await loadMusicalCore();   // Node: read from the repository; a page: fetched
//   installMusicalCore(core);             // counterpoint.js's counterLine, lineCost and countBreaks, canon-plan.js's
//                                         // stepInCollection, invertedLine and subjectFrom, fugue-answer.js's
//                                         // answerLine and fugueAnswers, counterpoint-profile.js's audit, and
//                                         // bounded-exact.js's sha256 run in Rust
//
// The exact layer's calls (a profile's audit) take and answer data as the exact layer holds it -- null, booleans,
// numbers, strings, BigInts, Rationals, ordinary arrays and data records -- written here as wasm/musical-core/src/
// value.rs reads it (encodeValue), with what the layer would refuse marked where it stands, so that the Rust refuses it
// at the same place, after the same work. A caller's contextAt is asked from the Rust as the audit reaches each time
// (env.mc_host_context); what it throws is thrown again here, once the Rust has stopped.
import {COUNTERPOINT,RULE_SETS,blendRules,useCounterpointCore} from './conducting/counterpoint.js';
import {useCanonCore} from './conducting/canon-plan.js';
import {useAnswerCore} from './conducting/fugue-answer.js';
import {useProfileCore} from './conducting/counterpoint-profile.js';
import {useJointThemeCore} from './conducting/joint-fugue-theme.js';
import {isRational,madeRational} from './conducting/canon-core.js';
import {dataRecord,dataArray} from './conducting/contract-data.js';
import {Refused,useExactCore} from './bounded-exact.js';

// The C interface's version this file speaks (wasm/musical-core/src/lib.rs ABI_VERSION).
export const MUSICAL_CORE_ABI=3;
// A rule set's fields in the order the Rust reads them (counterpoint.rs Rules::read), its leaps after them: how many,
// then each [bound, share] (blendRules `leaps`; none where a rule set has none).
export const RULE_FIELDS=Object.freeze(['strong.perfect','strong.imperfect','strong.dissonant','weak.perfect','weak.imperfect','weak.dissonant',
  'unpreparedDissonance','parallelPerfect','directPerfect','similar','unrecovered','unison','crossing','repeated','leapMost']);
const KINDS=Object.freeze(['perfect','imperfect','dissonant']);

const finite=value=>typeof value==='number'&&Number.isFinite(value);
// A rule set's numbers -- its 15 fields, its leaps' count and each [bound, share] -- or null where one is not a finite
// number, or its leaps are not as blendRules makes them.
const ruleNumbers=rules=>{
  if(!rules||typeof rules!=='object')return null;
  const out=RULE_FIELDS.map(field=>{const [a,b]=field.split('.');return b?rules[a]?.[b]:rules[a]});
  if(!out.every(finite))return null;
  const leaps=rules.leaps??[];
  if(!Array.isArray(leaps)||leaps.length>RULE_SETS.length||!leaps.every(pair=>Array.isArray(pair)&&pair.length===2&&finite(pair[0])&&finite(pair[1])))return null;
  out.push(leaps.length);for(const [most,share] of leaps)out.push(most,share);
  return out;
};
// A line's notes as [pitch, start, length] each, or null where one is not finite (`lengths`: whether they must be).
const noteNumbers=(line,lengths=true)=>{
  if(!Array.isArray(line))return null;const out=[];
  for(const note of line){if(!note||!finite(note.pitch)||!finite(note.start)||lengths&&!finite(note.length))return null;out.push(note.pitch,note.start,lengths?note.length:0)}
  return out;
};
const linesNumbers=lines=>{
  if(!Array.isArray(lines))return null;const out=[];
  for(const line of lines){const notes=noteNumbers(line);if(!notes)return null;out.push(line.length);append(out,notes)}
  return out;
};
// (Pushed one by one: a spread of a long list overflows the call stack.)
const append=(out,values)=>{for(const value of values)out.push(value);return out};
// `above` as the Rust reads it: -1 either side (null or undefined), else 1 truthy or 0.
const aboveCode=above=>above==null?-1:above?1:0;

// A collection's pitches as numbers (the JavaScript's modulo takes them so), or null where one is not finite or none is
// given.
const collectionNumbers=collection=>{
  if(!Array.isArray(collection)||!collection.length)return null;
  const out=collection.map(Number);return out.every(Number.isFinite)?out:null;
};
const pitchesOf=line=>{if(!Array.isArray(line))return null;const out=line.map(note=>note?.pitch);return out.every(finite)?out:null};
const REASONS=Object.freeze(['its tonic is not known','it begins on neither its tonic nor its dominant','its head reaches the dominant','its head is its tonic alone']);

// ---- the exact layer's data, as value.rs reads and writes it ----------------------------------------------------------
// Little-endian: a tag, then 0 null, 1 false, 2 true, 9 undefined: nothing; 3 a number: its f64; 4 a string, 5 a BigInt
// (its decimal), 6 a Rational ("n" or "n/d"): a text; 7 an array, 8 a record: a u32 count, then the items (a record's
// each its key, a text, then its value); 10 anything no data record (a function, a class's instance); 11 an array not
// dense and ordinary: the count of its own keys; 12 a value met again inside itself, or past any depth the layer
// reads. A text: a u32 count of UTF-16 units and the units, numbered as met within one top-level value; or 0xFFFFFFFF
// and the number of the same text met before (an event's keys, voices and pitch space are sent once).
const AGAIN=0xffffffff;
class Writer{
  constructor(size=1<<12){this.bytes=new Uint8Array(size);this.view=new DataView(this.bytes.buffer);this.at=0;this.texts=new Map}
  room(n){
    if(this.at+n<=this.bytes.length)return;
    let size=2*this.bytes.length;while(size<this.at+n)size*=2;
    const bytes=new Uint8Array(size);bytes.set(this.bytes.subarray(0,this.at));this.bytes=bytes;this.view=new DataView(bytes.buffer);
  }
  tag(t){this.room(1);this.bytes[this.at++]=t}
  u32(n){this.room(4);this.view.setUint32(this.at,n,true);this.at+=4}
  units(text){
    const seen=this.texts.get(text);if(seen!==undefined){this.u32(AGAIN);this.u32(seen);return}
    this.texts.set(text,this.texts.size);
    const n=text.length;this.u32(n);this.room(2*n);for(let i=0;i<n;i++){this.view.setUint16(this.at,text.charCodeAt(i),true);this.at+=2}
  }
  raw(bytes){this.room(bytes.length);this.bytes.set(bytes,this.at);this.at+=bytes.length}
  // A top-level value: its texts numbered afresh.
  value(value){this.texts.clear();encodeValue(this,value)}
}
// (Deeper than any snapshot reads: canon-core's copy refuses past 16.)
const DEPTH=32;
const ordinaryArray=value=>{try{dataArray(value,2**32);return true}catch{return false}};
function encodeValue(w,value,within=new Set,depth=0){
  if(value===null)return w.tag(0);
  switch(typeof value){
    case 'boolean':return w.tag(value?2:1);
    case 'undefined':return w.tag(9);
    case 'number':w.tag(3);w.room(8);w.view.setFloat64(w.at,value,true);w.at+=8;return;
    case 'string':w.tag(4);return w.units(value);
    case 'bigint':w.tag(5);return w.units(value.toString());
    case 'object':break;
    default:return w.tag(10);
  }
  if(isRational(value)){w.tag(6);return w.units(value.toString())}
  if(depth>=DEPTH||within.has(value))return w.tag(12);
  if(Array.isArray(value)){
    if(!ordinaryArray(value)){w.tag(11);return w.u32(Object.keys(value).length)}
    within.add(value);w.tag(7);w.u32(value.length);
    for(let i=0;i<value.length;i++)encodeValue(w,value[i],within,depth+1);
    within.delete(value);return;
  }
  if(!dataRecord(value))return w.tag(10);
  const keys=Object.keys(value);within.add(value);w.tag(8);w.u32(keys.length);
  for(const key of keys){w.units(key);encodeValue(w,value[key],within,depth+1)}
  within.delete(value);
}
// A value the Rust wrote: arrays and records frozen, as canon-core's copy freezes its snapshots.
// (Its UTF-16 decoder made when first needed, not as the module loads: the plug-in's and Max's hosts load this module
// with the bots and their TextDecoder reads UTF-8 only (ableton/src/max-environment.mjs), which had stopped the plug-in's
// bundle loading at all. A host without one reads each text unit by unit, the same text.)
let utf16;
const utf16Decoder=()=>{if(utf16===undefined)try{utf16=new TextDecoder('utf-16le')}catch{utf16=null}return utf16};
const ascii=new TextDecoder();
function decodeValue(bytes){
  const view=new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength),texts=[];let at=0;
  const u32=()=>{const n=view.getUint32(at,true);at+=4;return n};
  // (A long text decoded whole; a lone surrogate, which the decoder would replace, read unit by unit.)
  const units=()=>{
    const n=u32();if(n===AGAIN)return texts[u32()];
    let text='';
    if(n>8&&utf16Decoder()){text=utf16.decode(bytes.subarray(at,at+2*n));if(text.length!==n||text.includes('�'))text=''}
    if(!text||text.length!==n){text='';for(let i=0;i<n;i++)text+=String.fromCharCode(view.getUint16(at+2*i,true))}
    at+=2*n;texts.push(text);return text;
  };
  const value=()=>{
    switch(bytes[at++]){
      case 0:return null;case 1:return false;case 2:return true;case 9:return undefined;
      case 3:{const x=view.getFloat64(at,true);at+=8;return x}
      case 4:return units();
      case 5:return BigInt(units());
      case 6:{const [n,d='1']=units().split('/');return madeRational(BigInt(n),BigInt(d))}
      case 7:{const n=u32(),out=[];for(let i=0;i<n;i++)out.push(value());return Object.freeze(out)}
      case 8:{const n=u32(),out={};for(let i=0;i<n;i++){const key=units();Object.defineProperty(out,key,{value:value(),enumerable:true})}return Object.freeze(out)}
      default:throw new Error('musical_core.wasm wrote a value this file cannot read');
    }
  };
  return value();
}
// pythonJson's input (bounded-exact.js): what it writes as it would read it -- an exact {n, d} or Rational as its text,
// a record's keys sorted and each value read in that order -- or DECLINED where the JavaScript should write it itself
// (an array with holes, an object not a plain record nor an array, a function, a symbol, past any usual depth).
const DECLINED=Symbol('declined'),JSON_DEPTH=512;
function encodeJson(w,value,depth=0){
  if(value===null||value===undefined)return w.tag(0);
  switch(typeof value){
    case 'boolean':return w.tag(value?2:1);
    case 'number':w.tag(3);w.room(8);w.view.setFloat64(w.at,value,true);w.at+=8;return;
    case 'string':w.tag(4);return w.units(value);
    // (A BigInt has no keys: "{}".)
    case 'bigint':w.tag(8);return w.u32(0);
    case 'object':break;
    default:throw DECLINED;
  }
  if(depth>=JSON_DEPTH)throw DECLINED;
  if(isRational(value)){w.tag(4);return w.units(value.toString())}
  const prototype=Object.getPrototypeOf(value),array=Array.isArray(value);
  if(array?prototype!==Array.prototype:prototype!==Object.prototype&&prototype!==null)throw DECLINED;
  if(typeof value.n==='bigint'&&typeof value.d==='bigint'&&value.d>0n){w.tag(4);return w.units(value.d===1n?`${value.n}`:`${value.n}/${value.d}`)}
  if(array){w.tag(7);w.u32(value.length);for(let i=0;i<value.length;i++){if(!(i in value))throw DECLINED;encodeJson(w,value[i],depth+1)}return}
  const keys=Object.keys(value).sort();w.tag(8);w.u32(keys.length);
  for(const key of keys){w.units(key);encodeJson(w,value[key],depth+1)}
}
// Whether `key`, read from the snapshot of `value`, comes from its prototype (an Array's, a record's Object.prototype).
const inherited=(value,key)=>{
  if(value===null||value===undefined)return false;
  const prototype=Array.isArray(value)?Array.prototype:dataRecord(value)?Object.prototype:Object.getPrototypeOf(Object(value));
  return !Object.hasOwn(Object(value),key)&&prototype!==null&&key in prototype;
};

// The module's calls, over its instance's exports; `host` the draws it asks for (env.mc_host_random).
function coreOf(exports,host){
  if(exports.mc_abi_version()!==MUSICAL_CORE_ABI)throw new Error(`musical_core.wasm speaks ABI ${exports.mc_abi_version()}, this file ${MUSICAL_CORE_ABI}: rebuild it (node scripts/build-musical-core.mjs)`);
  const write=values=>{const at=exports.mc_input(values.length);new Float64Array(exports.memory.buffer,at,values.length).set(values);return values.length};
  const read=()=>Array.from(new Float64Array(exports.memory.buffer,exports.mc_output(),exports.mc_output_len()));
  const encoder=new TextEncoder();
  const core={
    exports,
    // -- the seeded random source (random-source.js) --
    // (A u32 comes back from WASM as an i32: >>> 0 reads it unsigned.)
    hashSeed(value){
      if(typeof value==='number')return exports.mc_hash_seed_number(value)>>>0;
      const bytes=encoder.encode(String(value)),at=exports.mc_text(bytes.length);new Uint8Array(exports.memory.buffer,at,bytes.length).set(bytes);
      return exports.mc_hash_seed_text()>>>0;
    },
    randomAt(value,index){return exports.mc_random_at(core.hashSeed(value),index)},
    stream(value,count){exports.mc_stream(core.hashSeed(value),count);return read()},
    // -- V8's sort, as the exact layer's budgets count it (timsort.rs): numbers sorted as (a, b) => a - b sorts them.
    sortNumbers(values){write(values);exports.mc_sort_numbers(values.length);const [comparisons,...order]=read();return {comparisons,order}},
    // -- bounded-exact.js --
    // (Its UTF-8 bytes written straight into the module, as many as three a UTF-16 unit at most.)
    sha256(text){
      const most=3*text.length,at=exports.mc_text(most),{written}=encoder.encodeInto(text,new Uint8Array(exports.memory.buffer,at,most));
      exports.mc_sha256(written);
      let hex='';for(const word of new Float64Array(exports.memory.buffer,exports.mc_output(),8))hex+=word.toString(16).padStart(8,'0');
      return hex;
    },
    // pythonJson of a record or an array (bounded-exact.js), or null where the JavaScript writes it itself.
    pythonJson(value){
      // (One writer, reused: a getter that asked for a text while it is busy is answered by the JavaScript.)
      if(json.busy)return null;
      const w=json;w.at=0;w.texts.clear();w.busy=true;
      try{encodeJson(w,value)}catch(error){if(error===DECLINED)return null;throw error}finally{w.busy=false}
      const at=exports.mc_text(w.at);new Uint8Array(exports.memory.buffer,at,w.at).set(w.bytes.subarray(0,w.at));
      if(exports.mc_python_json(w.at)!==0)throw new Error('musical_core.wasm could not read a value it had been sent whole');
      return ascii.decode(new Uint8Array(exports.memory.buffer,exports.mc_bytes(),exports.mc_bytes_len()));
    },
    // -- canon-plan.js --
    stepInCollection(pitch,steps,collection,period=12){
      const values=collectionNumbers(collection);
      if(!values||!finite(pitch)||!Number.isInteger(steps)||!finite(period)||period<=0)return null;
      write(values);return exports.mc_step_in_collection(pitch,steps,values.length,period);
    },
    invertedLine(line,{axis=line?.[0]?.pitch,collection=null,degrees=true,period=12}={}){
      const pitches=pitchesOf(line);if(!pitches||!pitches.length||!finite(axis)||!finite(period)||period<=0)return null;
      const byDegrees=Boolean(degrees&&collection?.length),values=byDegrees?collectionNumbers(collection):[];if(!values)return null;
      write(append([...pitches],values));exports.mc_inverted_line(pitches.length,values.length,axis,byDegrees?1:0,period);
      const out=read();return line.map((note,i)=>({...note,pitch:out[i]}));
    },
    subjectFrom({collection,register={low:60,high:79},groups=[3,2,2],denominator=8,bars=2,random=Math.random,split=.4,leap=.2,axis=null}={}){
      const values=collectionNumbers(collection),axisValues=Array.isArray(axis)?axis.map(Number):null;
      if(!values||!register||!finite(register.low)||!finite(register.high)||!Array.isArray(groups)||!groups.every(finite)||!finite(denominator)||!finite(bars)
        ||!finite(split)||!finite(leap)||axisValues&&!axisValues.every(Number.isFinite)||typeof random!=='function')return null;
      write(append(append([...values],groups),axisValues??[]));
      const previous=host.random;host.random=random;
      let status;try{status=exports.mc_subject_from(values.length,groups.length,axisValues?.length??0,register.low,register.high,denominator,bars,split,leap,axisValues?1:0)}finally{host.random=previous}
      if(status!==0)return null;
      const out=read(),line=[];for(let k=0;k<out.length;k+=3)line.push({pitch:out[k],start:out[k+1],length:out[k+2]});return line;
    },
    // -- fugue-answer.js --
    answerLine(line,{interval=null,steps=null,collection=null,tonic=null,tonal=false,period=12}){
      const pitches=pitchesOf(line),byDegrees=steps!=null,values=byDegrees?collectionNumbers(collection):[];
      if(!pitches||!values||!finite(period)||period<=0||(byDegrees?!Number.isInteger(steps):!finite(interval))||tonic!=null&&!finite(tonic))return null;
      write(append([...pitches],values));
      if(exports.mc_answer_line(pitches.length,values.length,byDegrees?NaN:interval,byDegrees?steps:NaN,tonic??NaN,tonal?1:0,period)!==0)return null;
      const out=read();return line.map((note,i)=>({...note,pitch:out[i]}));
    },
    fugueAnswers(line,{interval,steps=null,collection=null,tonic=null,period=12}){
      const pitches=pitchesOf(line),degrees=Boolean(steps!=null&&collection?.length),values=degrees?collectionNumbers(collection):[];
      if(!pitches||!values||!finite(interval)||!finite(period)||period<=0||degrees&&!Number.isInteger(steps))return null;
      write(append([...pitches],values));
      if(exports.mc_fugue_answers(pitches.length,values.length,interval,degrees?steps:NaN,Number.isFinite(tonic)?tonic:NaN,period)!==0)return null;
      const out=read(),n=pitches.length;let at=0;
      const take=()=>{const part=out.slice(at,at+n);at+=n;return line.map((note,i)=>({...note,pitch:part[i]}))},optional=()=>out[at++]?take():null;
      const real=take(),tonal=optional(),degreesLine=optional(),tonalDegrees=optional(),asks=[null,'tonal','real'][out[at++]],head=out.slice(at+1,at+1+out[at]);
      at+=1+head.length;
      return {real,tonal,degrees:degreesLine,tonalDegrees,asks,head,reason:REASONS[out[at]]};
    },
    // -- pitch-languages/canon.js --
    // micropolyphony's voices ({delay, augmentation, transpose} each), its transpositions chosen as it chooses them.
    micropolyphonyVoices(seed,{voices,maxDelay,spread,choices}){
      if(!Number.isSafeInteger(voices)||voices<1||!finite(maxDelay)||!finite(spread)||!Array.isArray(choices)||!choices.length||!choices.every(finite))return null;
      const bytes=encoder.encode(String(seed)),at=exports.mc_text(bytes.length);new Uint8Array(exports.memory.buffer,at,bytes.length).set(bytes);
      write(choices);if(exports.mc_micropolyphony(bytes.length,voices,choices.length,maxDelay,spread)!==0)return null;
      const out=read(),specs=[];for(let k=0;k<out.length;k+=3)specs.push({delay:out[k],augmentation:out[k+2],transpose:out[k+1]});return specs;
    },
    // -- counterpoint.js --
    intervalKind(cents){return KINDS[exports.mc_interval_kind(cents)]},
    perfectDegrees(collection,period=12){const values=collection.map(Number);write(values);exports.mc_perfect_degrees(values.length,period);return read()},
    ladderOf(collection,register){const values=collection.map(Number);if(!values.every(finite))return null;write(values);exports.mc_ladder_of(values.length,register.low,register.high);return read()},
    blendRules(given='tonal',strictness=1){
      const weights=typeof given==='string'?{[given]:1}:given,pairs=[];
      for(const [name,w] of Object.entries(weights)){const index=RULE_SETS.indexOf(name);if(index<0||typeof w!=='number')return null;pairs.push(index,w)}
      write(pairs);exports.mc_blend_rules(pairs.length/2,strictness);return rulesOf(read());
    },
    drawnRules(random,{rigor=1,voices=2,classes=12}={}){
      const draws=Array.from({length:6},()=>random());write(draws);exports.mc_drawn_rules(Number(rigor),voices,classes);const out=read();
      return {weights:Object.fromEntries(RULE_SETS.map((name,i)=>[name,out[i]])),strictness:out[5],rules:rulesOf(out.slice(6))};
    },
    strongBeat({numerator,denominator,groups},t){const given=groups?.length?groups:[];write(given);return exports.mc_strong_beat(numerator,denominator,given.length,t)===1},
    counterLine(args){
      const packed=core.counterLineInput(args);if(!packed)return null;
      if(exports.mc_counter_line(write(packed.input))!==0)throw new Error('musical_core.wasm refused a counterLine it had been sent whole');
      const [cost,...indices]=read(),{rhythm,steps}=packed;
      return {line:indices.map((k,i)=>{const {start:at,length}=rhythm[i];return {...rhythm[i],pitch:steps[k],start:at,length}}),cost:+cost.toFixed(3)};
    },
    // counterLine's input buffer (its draws taken), or null where it declines: {input, rhythm, steps}.
    counterLineInput(args){
      const {against=[],rhythm,steps,rules=blendRules('tonal'),strong=()=>false,random=Math.random,above=null,start=null,beam=COUNTERPOINT.beam,self=[],relations=[],toward=null}=args;
      if(!Array.isArray(rhythm)||!Array.isArray(steps)||!steps.length||!rhythm.length||!steps.every(finite))return null;
      if(!rhythm.every(item=>item&&finite(item.start)&&finite(item.length))||!Number.isInteger(beam)||beam<1||start!=null&&!finite(start))return null;
      const ruleList=ruleNumbers(rules),againstList=linesNumbers(against);if(!ruleList||!againstList||!Array.isArray(self)||!Array.isArray(relations))return null;
      const voicesOf=list=>{const out=[];
        for(const voice of list){
          if(!voice||typeof voice!=='object')return null;
          const {delay,transpose=0,map=null,ratio=1}=voice;
          if(!finite(delay)||!(transpose==null||finite(transpose))||!finite(ratio)||map&&typeof map!=='function')return null;
          out.push({delay,transpose:transpose??0,ratio,map:map||null});
        }
        return out};
      const voices=voicesOf(self),related=voicesOf(relations);if(!voices||!related)return null;
      // (The draws its search takes: each setting kept times each candidate, note by note.)
      let states=1,total=0;
      for(let i=0;i<rhythm.length;i++){
        const candidates=i===0&&start!=null?steps.filter(p=>Math.abs(p-start)<1e-6).length:steps.length;
        if(!candidates)return null;total+=states*candidates;states=Math.min(beam,states*candidates);
      }
      const towardGiven=Boolean(toward&&Number.isFinite(toward.pitch));
      const towardRules=towardGiven&&toward.rules!=null?ruleNumbers(toward.rules):null;
      if(towardGiven&&(!finite(toward.start)||toward.rules!=null&&!towardRules||toward.length!=null&&typeof toward.length!=='number'))return null;
      // (The functions asked, then the draws: none of them was asked before this point. A map at every step, and at the
      // note it leads into; the strong beats at every time the search asks -- the rhythm's notes, every partner's onset,
      // each delayed voice's and relation's onset at each note, and the way into `toward` -- each time worked out as the
      // search works it out, so the Rust finds it.)
      const tables=list=>{const out=[];for(const voice of list)if(voice.map){const table=steps.map(p=>voice.map(p)),at=towardGiven?voice.map(toward.pitch):NaN;
        if(!table.every(finite)||towardGiven&&!finite(at))return null;out.push({table,at})}else out.push(null);return out};
      const maps=tables(voices),relationMaps=tables(related);if(!maps||!relationMaps)return null;
      const asked=new Map,ask=t=>{const key=Object.is(t,-0)?0:t;if(!asked.has(key))asked.set(key,strong(t)?1:0)};
      for(const item of rhythm)ask(item.start);
      for(const line of against)for(const note of line)ask(note.start);
      const starts=rhythm.map(item=>item.start);if(towardGiven)starts.push(toward.start);
      for(const {delay,ratio} of [...voices,...related]){for(const at of starts)ask(delay+at*ratio);ask(delay)}
      if(towardGiven)ask(toward.start);
      const draws=new Array(total);for(let k=0;k<total;k++)draws[k]=random();
      const input=[rhythm.length,steps.length,against.length,beam,start==null?NaN:start,aboveCode(above),voices.length,related.length,
        towardGiven?1:0,towardGiven?toward.pitch:0,towardGiven?toward.start:0,towardGiven&&toward.length!=null?toward.length:NaN,towardGiven&&toward.withSelf?1:0,towardRules?1:0];
      append(input,ruleList);append(input,towardRules??ruleList);
      for(const item of rhythm)input.push(item.start,item.length);
      input.push(asked.size);for(const [t,flag] of asked)input.push(t,flag);
      append(input,steps);append(input,againstList);
      const write=(list,tablesOf)=>list.forEach((voice,v)=>{input.push(voice.delay,voice.transpose,voice.ratio,tablesOf[v]?1:0);if(tablesOf[v]){append(input,tablesOf[v].table);input.push(tablesOf[v].at)}});
      write(voices,maps);write(related,relationMaps);
      input.push(total);append(input,draws);
      return {input,rhythm,steps};
    },
    lineCost({line,against=[],rules=blendRules('tonal'),strong=()=>false,above=null}){
      const notes=noteNumbers(line,false),ruleList=ruleNumbers(rules),againstList=linesNumbers(against);
      if(!notes||!ruleList||!againstList)return null;
      const input=append(append(append([line.length,against.length,aboveCode(above),...ruleList],notes),line.map(note=>strong(note.start)?1:0)),againstList);
      if(exports.mc_line_cost(write(input))!==0)throw new Error('musical_core.wasm refused a lineCost it had been sent whole');
      return read()[0];
    },
    countBreaks(line,against,{strong=()=>false}={}){
      const notes=noteNumbers(line,false),againstList=linesNumbers(against);if(!notes||!againstList)return null;
      const input=append(append(append([line.length,against.length],notes),line.map(note=>strong(note.start)?1:0)),againstList);
      if(exports.mc_count_breaks(write(input))!==0)throw new Error('musical_core.wasm refused a countBreaks it had been sent whole');
      const [strongDissonances,parallelPerfects,unrecovered,notesCount]=read();return {strongDissonances,parallelPerfects,unrecovered,notes:notesCount};
    },
    // -- joint-fugue-theme.js --
    // Its leap constraint, |a - b| <= most with each Number at its decimal word, exactly; null where the Rust declines
    // (a Number whose spelling has an exponent, -0, or not a number: the JavaScript decides, or refuses, as ever).
    leapWithin(a,b,most){
      if(typeof a!=='number'||typeof b!=='number'||typeof most!=='number')return null;
      const within=exports.mc_leap_within(a,b,most);return within<0?null:within===1;
    },
    // String(x), as the Rust writes a number into an identity's JSON.
    numberText(x){exports.mc_number_text(x);return String.fromCharCode(...new Uint8Array(exports.memory.buffer,exports.mc_bytes(),exports.mc_bytes_len()))},
    // -- counterpoint-profile.js --
    // A compiled profile's audit: {result (auditSlices' report), predicateWorkUsed, seen and pairSeen (each rule's
    // counts, by index)}. Refusals and failures are thrown as the JavaScript throws them; so is what contextAt throws.
    profileAudit({definition,hash,pitchSpace,rules,pairLists},events,{boundaries,contextAt,dependencies,maxWork,maxPredicateWork}){
      let profile=profiles.get(definition);
      if(!profile){
        const w=new Writer;
        w.value({hash,space:{...pitchSpace.definition,hash:pitchSpace.hash},voices:definition.voices,clock:definition.clockDomain,rules,
          pairs:rules.map(rule=>pairLists.get(rule)??null)});
        profile={bytes:w.bytes.slice(0,w.at),keys:[...new Set(rules.filter(rule=>Object.hasOwn(rule,'contextKey')).map(rule=>rule.contextKey))]};
        profiles.set(definition,profile);
      }
      const w=new Writer(profile.bytes.length+(1<<12));w.raw(profile.bytes);
      for(const value of [events,boundaries,dependencies,maxWork,maxPredicateWork,typeof contextAt==='function'])w.value(value);
      // (The module's memory may grow while it makes room: its buffer read after.)
      const at=exports.mc_text(w.at);new Uint8Array(exports.memory.buffer,at,w.at).set(w.bytes.subarray(0,w.at));
      let thrown=null;
      const previous=host.context;
      host.context=(pointer,length)=>{
        try{
          const [n,d='1']=String.fromCharCode(...new Uint8Array(exports.memory.buffer,pointer,length)).split('/');
          const value=contextAt(madeRational(BigInt(n),BigInt(d))),answer=new Writer;
          answer.value(value);for(const key of profile.keys)answer.tag(inherited(value,key)?1:0);
          const at=exports.mc_host_buffer(answer.at);new Uint8Array(exports.memory.buffer,at,answer.at).set(answer.bytes.subarray(0,answer.at));
          return 0;
        }catch(error){thrown=error;return 1}
      };
      let status;try{status=exports.mc_profile_audit(w.at)}finally{host.context=previous}
      const out=decodeValue(new Uint8Array(exports.memory.buffer,exports.mc_bytes(),exports.mc_bytes_len()));
      if(status!==0){
        if(out.name==='Host')throw thrown;
        if(out.name==='Refused')throw new Refused(out.message,{kind:out.kind});
        throw new (globalThis[out.name]??Error)(out.message);
      }
      return {result:{status:out.status,scope:[...out.scope],profileId:definition.id,profileVersion:definition.version,checks:out.checks.map(check=>({...check})),
        eventHash:out.eventHash,contextHash:out.contextHash,workUsed:out.workUsed},predicateWorkUsed:out.predicateWorkUsed,seen:out.seen,pairSeen:out.pairSeen.map(counts=>[...counts])};
    },
  };
  // (A compiled profile's encoding, made once; pythonJson's writer, reused.)
  const profiles=new WeakMap,json=new Writer(1<<16);
  return core;
}
// A blend from its numbers (Rules::read's), frozen as blendRules freezes one, its leaps with it.
function rulesOf(values){
  const kinds=offset=>Object.freeze(Object.fromEntries(KINDS.map((kind,i)=>[kind,values[offset+i]])));
  const leaps=Object.freeze(Array.from({length:values[15]},(_,k)=>Object.freeze([values[16+2*k],values[17+2*k]])));
  return Object.freeze({strong:kinds(0),weak:kinds(3),...Object.fromEntries(RULE_FIELDS.slice(6).map((field,i)=>[field,values[6+i]])),leaps});
}

// The module, compiled from its bytes (given, or read: in Node from the repository, in a page fetched from `url`).
export async function loadMusicalCore({bytes=null,url=null}={}){
  if(!bytes){
    // (Its address only where its bytes are not given: a bundle's module has none.)
    url??=new URL('../wasm/musical-core/musical_core.wasm',import.meta.url);
    if(typeof process!=='undefined'&&process.versions?.node&&url.protocol==='file:'){const {readFile}=await import('node:fs/promises');bytes=await readFile(url)}
    else{const response=await fetch(url);if(!response.ok)throw new Error(`musical_core.wasm HTTP ${response.status}`);bytes=await response.arrayBuffer()}
  }
  const host=hostOf(),{instance}=await WebAssembly.instantiate(bytes,host.imports);
  return coreOf(instance.exports,host);
}
// The core from its module's bytes, compiled at once (Node; a page's main thread compiles only small modules so).
export function musicalCoreFrom(bytes){
  const host=hostOf(),instance=new WebAssembly.Instance(new WebAssembly.Module(bytes),host.imports);
  return coreOf(instance.exports,host);
}
// (A call that asks the caller's draws one by one sets host.random for its length; one that asks the caller's
// contextAt sets host.context.)
function hostOf(){
  const host={random:null,context:null};
  host.imports={env:{mc_host_random:()=>host.random(),mc_host_context:(pointer,length)=>host.context(pointer,length)}};
  return host;
}
// The core put in place of the modules it ports (null: the JavaScript again).
export function installMusicalCore(core){useCounterpointCore(core);useCanonCore(core);useAnswerCore(core);useProfileCore(core);useJointThemeCore(core);useExactCore(core)}
