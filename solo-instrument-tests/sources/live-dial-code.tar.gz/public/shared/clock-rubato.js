// A rubato span the clocks play (RUB-002; docs/PERFORMANCE_TIMING.md §14), in the pattern of clock-hold.js: a clock keeps
// its spans in its state and asks, at each pulse, how long until the next. Inside a span a pulse falls where the span's
// timing map puts it: the density (seconds per quarter) linear between knots at exact score positions, counted from the
// span's bar's downbeat, so a pulse's length is T(q + its quarters) - T(q), the map's own. A meter change inside the span
// is just the next pulses' lengths in quarters. At the span's end the clock goes on at the last knot's density, so the
// join has no corner. A hold inside a span stops score time, as it stops the clock: the span resumes after it.
//   - A revision (the conductor's, the one committing authority) replaces the knots from an index on, only where no
//     scheduled pulse can hear them: the knot before the first one changed must lie at or after the position the clock
//     has committed (its next pulse, plus leadSeconds of the span's time). Each decision is said, for the clock to
//     announce to every bot.
// The clocks call it through rubato-clocks.js (7a, 28 September, on 2a's terms): the room's, a render's and the
// server's; the networked conductor's refuses a span until its cursor keeps one.
import {TimingMap, positionKey} from './timing-map.js';
import {ratio, add, sub, compare, toNumber} from './rhythm-vocabulary.js';
import {bandMeter} from './opening-time.js';

export const RUBATO_SPAN_LIMITS = Object.freeze({knots: 129, leadSeconds: 10, spans: 8});
const positive = value => Number.isFinite(value) && value > 0;

// {id, bar, knots: [{at, density}] (at exact quarters from the bar's downbeat, the first 0, increasing; density seconds
// per quarter), leadSeconds}.
export function normalizeRubato(value) {
  if (!value || typeof value.id !== 'string' || !value.id) throw new RangeError('A rubato span has an id');
  if (!Number.isInteger(value.bar) || value.bar < 0) throw new RangeError('A rubato span begins at a bar\'s downbeat');
  const knots = value.knots;
  if (!Array.isArray(knots) || knots.length < 2 || knots.length > RUBATO_SPAN_LIMITS.knots) throw new RangeError(`A rubato span has 2..${RUBATO_SPAN_LIMITS.knots} knots`);
  const parsed = knots.map(knot => ({at: ratio(knot.at), density: Number(knot.density)}));
  if (compare(parsed[0].at, ratio(0)) !== 0) throw new RangeError('A rubato span\'s first knot is at its downbeat');
  parsed.forEach((knot, i) => {
    if (!positive(knot.density)) throw new RangeError('A knot\'s density is positive seconds per quarter');
    if (i && compare(knot.at, parsed[i - 1].at) <= 0) throw new RangeError('A rubato span\'s knots are in order');
  });
  const leadSeconds = value.leadSeconds ?? 0.25;
  if (!(leadSeconds >= 0 && leadSeconds <= RUBATO_SPAN_LIMITS.leadSeconds)) throw new RangeError(`A span's lead is 0..${RUBATO_SPAN_LIMITS.leadSeconds} s`);
  return Object.freeze({id: value.id, bar: value.bar, knots: Object.freeze(parsed), leadSeconds, revision: value.revision ?? 0});
}
const mapOf = (knots, startSeconds = 0) => new TimingMap({start: 0, startSeconds, segments: knots.slice(1).map((knot, i) => ({kind: 'linear', from: knots[i].at, to: knot.at, seconds: [knots[i].density, knot.density]}))});
// A span's map, for a bot that places what it renders whole by the span ahead of the clock (clodbot_singerbot).
export const rubatoMap = mapOf;

// Queue a span in a clock's state; one span at a time may play, and none may begin before the bar now playing.
export function queueRubato(state, value) {
  let span;
  try { span = normalizeRubato(value); } catch (error) { return {rejected: error.message}; }
  state.rubatos ??= [];
  if (state.rubatos.length >= RUBATO_SPAN_LIMITS.spans) return {rejected: 'too many spans queued'};
  if (state.rubatos.some(queued => queued.id === span.id) || state.rubato?.span.id === span.id) return {rejected: `span ${span.id} is already declared`};
  if (span.bar < (state.bar ?? 0) || (span.bar === state.bar && (state.tickInBar ?? 0) > 0)) return {rejected: 'a span begins at a downbeat still to come'};
  state.rubatos.push(span); state.rubatos.sort((a, b) => a.bar - b.bar);
  return {queued: span.id};
}

// At a pulse (the clock's bar, tickInBar and meter, at clock time `at`): a span beginning at this downbeat, running, or
// ending here, and the seconds until the next pulse inside it. -> null outside any span, else {seconds, begins?, ends?,
// ended?}: `ends` carries the tempo to go on at (the meter's beats a minute at the last knot's density). A span queued
// for the downbeat where the one playing ends begins there at once (back-to-back spans chain, as one phrase's follows
// the last), and the pulse is the new span's, `ended` naming the one before. A queued span whose downbeat passed while
// another played can never begin: it is dropped, and said so (/broadcast/rubatoRefused), so those after it still can.
export function rubatoAtPulse(state, at) {
  const meter = state.meter, pulseQuarters = ratio(4, (meter.denominator ?? bandMeter().denominator) * meter.subdivision);
  while (state.rubatos?.length && (state.rubatos[0].bar < state.bar || (state.rubatos[0].bar === state.bar && (state.tickInBar ?? 0) > 0))) {
    const passed = state.rubatos.shift();
    (state.rubatoAnnouncements ??= []).push({address: '/broadcast/rubatoRefused', args: [{id: passed.id, bar: passed.bar, reason: 'its downbeat passed while another span played'}]});
  }
  let begins = null, ended = null;
  const due = () => state.rubatos?.length && state.rubatos[0].bar === state.bar && state.tickInBar === 0;
  const begin = () => {
    const span = state.rubatos.shift();
    state.rubato = {span, map: mapOf(span.knots, at), elapsed: ratio(0), startSeconds: at};
    begins = {id: span.id, revision: span.revision};
  };
  if (!state.rubato && due()) begin();
  let active = state.rubato;
  if (!active) return null;
  if (compare(active.elapsed, active.map.end) >= 0) {
    // The span is over at this pulse: the clock goes on at its last density, unless the next begins here.
    const density = active.span.knots.at(-1).density, bpm = 60 / (density * 4 / (meter.denominator ?? bandMeter().denominator));
    state.rubato = null;
    ended = {id: active.span.id, bpm};
    if (!due()) return {ends: ended, seconds: null};
    begin();
    active = state.rubato;
  }
  const end = active.map.end;
  const from = active.elapsed, to = add(from, pulseQuarters), last = compare(to, end) > 0 ? end : to;
  // A pulse running past the span's end takes the rest at the last density.
  const inside = active.map.timeAt(last) - active.map.timeAt(from), beyond = compare(to, end) > 0 ? toNumber(sub(to, end)) * active.span.knots.at(-1).density : 0;
  active.elapsed = to;
  return {seconds: inside + beyond, ...(begins ? {begins} : {}), ...(ended ? {ended} : {}), position: positionKey(from)};
}

// The score position (quarters into the span, a number) a clock has committed: its next pulse's, and `leadSeconds` of
// the span's own time after it. Counted in the span's time, so a hold within the lead only makes it more cautious.
export function committedPosition(state) {
  const active = state.rubato;
  if (!active) return null;
  const seconds = active.map.timeAt(active.elapsed) + active.span.leadSeconds;
  return seconds >= active.map.endSeconds ? toNumber(active.map.end) : active.map.positionAt(seconds);
}

// A revision {id, revision, from, knots}: the knots from index `from` on replaced (their positions kept: the grid is the
// span's), if the knot before `from` lies at or after the committed position. -> {revised} | {rejected}.
export function reviseRubato(state, value) {
  const active = state.rubato, queued = state.rubatos?.find(span => span.id === value.id);
  const target = active?.span.id === value.id ? active.span : queued;
  if (!target) return {rejected: `no span ${value.id}`};
  if (!Number.isInteger(value.revision) || value.revision <= target.revision) return {rejected: 'a revision comes after the one standing'};
  const from = value.from, knots = value.knots;
  if (!Number.isInteger(from) || from < 1 || from >= target.knots.length) return {rejected: 'a revision replaces knots after the first'};
  if (!Array.isArray(knots) || knots.length !== target.knots.length - from) return {rejected: 'a revision gives each knot from `from` on'};
  const replaced = [...target.knots.slice(0, from), ...knots.map((knot, i) => ({at: target.knots[from + i].at, density: Number(knot.density ?? knot)}))];
  if (replaced.some(knot => !positive(knot.density))) return {rejected: 'a knot\'s density is positive'};
  if (active?.span === target) {
    if (toNumber(target.knots[from - 1].at) < committedPosition(state) - 1e-12) return {rejected: 'the revision reaches into what the clock has committed'};
  }
  const span = Object.freeze({...target, knots: Object.freeze(replaced), revision: value.revision});
  if (active?.span === target) {
    // The same start, the new knots: every committed pulse is unchanged, since the map agrees up to the knot before `from`.
    state.rubato = {...active, span, map: mapOf(span.knots, active.startSeconds)};
  } else state.rubatos[state.rubatos.indexOf(queued)] = span;
  return {revised: span.id, revision: span.revision};
}
