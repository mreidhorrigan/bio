// An ensemble's state in a share link's `e` parameter.
//
// Version 3 (`3` and base64url; `4` where the bytes are deflated): the state written field by field against a schema
// of its own, as a protocol buffer writes a message: integers as varints (seven bits a byte), a bot, a mixer setting or
// an effect setting as its number in link-vocabulary.js rather than its name, a flag as a bit, a number as a decimal
// mantissa and exponent. Nothing is named that the schema already knows. Where anything is left to compress (plugin
// settings, many bots), the bytes are also deflated, and the shorter kept. A five-bot ensemble whose bots entered one
// after another took 180 characters in version 2, and takes 41.
//
// Version 2 (`2.`, the size in base 36, `.` and base64url) is the state as JSON, deflated. Links made with it open as
// they always did, and a state the schema cannot hold (another object, a value outside its fields) is still written in
// it.
import {deflateSync,inflateSync} from '../vendor/fflate.js';
import {LINK_BOT_IDS,LINK_MIX_KEYS,LINK_EFFECT_KEYS} from './link-vocabulary.js';

const MAX_BYTES=65536,MAX_CHARS=12000;
let lastJSON=null,lastEncoded=null;
export function encodeLinkState(value){
  const json=JSON.stringify(value);
  if(json===lastJSON)return lastEncoded;
  const bytes=new TextEncoder().encode(json);
  if(bytes.length>MAX_BYTES)throw new Error('This ensemble state is too large for a share link');
  let encoded;
  try{encoded=encodeSchema(value)}catch(error){if(!(error instanceof OutsideSchema))throw error;encoded=encodeJson(bytes)}
  lastJSON=json;lastEncoded=encoded;
  return encoded;
}
export function decodeLinkState(value){
  if(typeof value!=='string'||value.length>MAX_CHARS)throw new Error('This ensemble state is too large');
  if(value.startsWith('2.'))return decodeJson(value);
  const parts=/^([34])([A-Za-z0-9_-]+)$/.exec(value);
  if(!parts)throw new Error('Unsupported or invalid compact ensemble link');
  try{return decodeSchema(fromBase64Url(parts[2]),parts[1]==='4')}catch{throw new Error('Invalid compact ensemble data')}
}

// ---- version 2: JSON, deflated
function encodeJson(bytes){return `2.${bytes.length.toString(36)}.${toBase64Url(deflateSync(bytes,{level:9}))}`}
function decodeJson(value){
  const parts=/^2\.([0-9a-z]{1,4})\.([A-Za-z0-9_-]+)$/.exec(value);
  if(!parts)throw new Error('Unsupported or invalid compact ensemble link');
  const size=parseInt(parts[1],36);
  if(!size||size>MAX_BYTES)throw new Error('This ensemble state is too large');
  try{
    // A supplied output buffer bounds decompression. The extra byte detects
    // a stream expanding beyond its declared size, including truncation.
    const bytes=inflateSync(fromBase64Url(parts[2]),{out:new Uint8Array(size+1)});
    if(bytes.length!==size)throw new Error('State size mismatch');
    return JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));
  }catch{throw new Error('Invalid compact ensemble data')}
}

// ---- version 3: the schema
// A state: {s: seed (uint32), a: started at (ms), b: bots, f: effect settings changed, p: an effect plugin's settings}.
// A bot: [id, key (where not its place in the list, from 1), output (0 none, 1 synth, 2 samples, 3 MIDI; 1 unless
// given), options]. Options: a (entered at, seconds to the hundredth), l (load only), m (muted), y (synthesizer), w
// (synthesizer settings), f (sample preset), u (local samples), x (mixer settings changed), p (2: MIDI 2.0), g (MIDI
// group), c (channel, or 'default'), z (MPE zone), r (bend range), o (MIDI program: 'gm', or a program 0-127), s (its
// bot's settings: spec-settings.js).
//
// Bytes: the seed (four), the start (a varint), which of f and p follow, the number of bots, each bot, then f and p.
// A bot: its id's number (or 0 and its id), a varint of flags (bits 0-1 the output, 2 a key, 3 an entry time, 4 load
// only, 5 muted, 6 other options), its key (a whole number plus one, or 0 and the key), its entry time in hundredths of
// a second, and the other options: a varint saying which (bit k: OTHER[k]) and their values in that order.
class OutsideSchema extends Error {}
const outside=()=>{throw new OutsideSchema('outside the version 3 schema')};
const OPTIONS=['a','l','m','y','w','f','u','x','p','g','c','z','r','o','s'],OTHER=['y','w','f','u','x','p','g','c','z','r','o','s'],FLAG={l:1,m:1,u:1,p:2};
const ZONES=['lower','upper'];
const plainObject=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);

class Writer {
  constructor(){this.bytes=[]}
  varint(value){
    if(!Number.isSafeInteger(value)||value<0)outside();
    while(value>=128){this.bytes.push(value%128+128);value=Math.floor(value/128);}
    this.bytes.push(value);
  }
  uint32(value){if(!Number.isInteger(value)||value<0||value>0xffffffff)outside();for(let i=0;i<4;i++){this.bytes.push(value&255);value=Math.floor(value/256);}}
  text(value){if(typeof value!=='string')outside();const bytes=new TextEncoder().encode(value);this.varint(bytes.length);for(const byte of bytes)this.bytes.push(byte);}
  // A number as mantissa × 10^-exponent (exponent 0 to 6), which gives back exactly the number JSON would; else its
  // 64-bit float.
  decimal(value){
    if(typeof value!=='number'||!Number.isFinite(value))outside();
    for(let exponent=0;exponent<=6;exponent++){
      const mantissa=Math.round(value*10**exponent);
      if(Math.abs(mantissa)<2**45&&mantissa/10**exponent===value){this.varint((mantissa<0?-2*mantissa-1:2*mantissa)*8+exponent);return;}
    }
    this.varint(7);const view=new DataView(new ArrayBuffer(8));view.setFloat64(0,value,true);for(const byte of new Uint8Array(view.buffer))this.bytes.push(byte);
  }
  // A name by its number in a list (plus one), else 0 and the name spelt out.
  named(value,list){const index=list.indexOf(value);if(index>=0)this.varint(index+1);else{this.varint(0);this.text(value);}}
  settings(value,list){
    if(!plainObject(value))outside();
    const entries=Object.entries(value);this.varint(entries.length);
    for(const [key,number] of entries){this.named(key,list);this.decimal(number);}
  }
}
class Reader {
  constructor(bytes){this.bytes=bytes;this.at=0}
  byte(){if(this.at>=this.bytes.length)throw new Error('truncated');return this.bytes[this.at++]}
  varint(){
    let value=0,scale=1;
    for(let i=0;i<8;i++){const byte=this.byte();value+=(byte&127)*scale;if(byte<128){if(!Number.isSafeInteger(value))break;return value;}scale*=128;}
    throw new Error('varint');
  }
  uint32(){let value=0;for(let i=0;i<4;i++)value+=this.byte()*256**i;return value}
  text(){
    const length=this.varint();if(length>MAX_BYTES||this.at+length>this.bytes.length)throw new Error('text');
    const value=new TextDecoder('utf-8',{fatal:true}).decode(this.bytes.subarray(this.at,this.at+length));this.at+=length;return value;
  }
  decimal(){
    const code=this.varint(),exponent=code%8,zigzag=Math.floor(code/8);
    if(exponent<7)return (zigzag%2?-(zigzag+1)/2:zigzag/2)/10**exponent;
    if(this.at+8>this.bytes.length)throw new Error('float');
    const value=new DataView(this.bytes.buffer,this.bytes.byteOffset+this.at,8).getFloat64(0,true);this.at+=8;
    if(!Number.isFinite(value))throw new Error('float');return value;
  }
  named(list){const index=this.varint();if(index===0)return this.text();if(index>list.length)throw new Error('name');return list[index-1]}
  settings(list){
    const count=this.varint();if(count>256)throw new Error('settings');
    const out={};for(let i=0;i<count;i++){const key=this.named(list);if(key==='__proto__')throw new Error('name');out[key]=this.decimal();}
    return out;
  }
}

function encodeSchema(state){
  if(!plainObject(state)||Object.keys(state).some(key=>!['s','a','b','f','p'].includes(key))||!Array.isArray(state.b))outside();
  const w=new Writer();
  w.uint32(state.s);w.varint(state.a);
  const effects=state.f!==undefined,plugin=state.p!==undefined&&state.p!==null;
  w.varint((effects?1:0)|(plugin?2:0));
  w.varint(state.b.length);
  state.b.forEach((row,index)=>{
    if(!Array.isArray(row)||row.length<1||row.length>4||typeof row[0]!=='string')outside();
    const [id,key,output,options={}]=row,hasKey=key!==undefined&&key!==null;
    const code=output===undefined||output===null?1:output;
    if(!Number.isInteger(code)||code<0||code>3)outside();
    if(!plainObject(options??{})||Object.keys(options??{}).some(name=>!OPTIONS.includes(name)))outside();
    const given=options??{},at=given.a,other=OTHER.filter(name=>given[name]!==undefined);
    for(const name of ['l','m','u','p'])if(given[name]!==undefined&&given[name]!==FLAG[name])outside();
    if(at!==undefined&&!(typeof at==='number'&&at>=0&&Math.round(at*100)/100===at))outside();
    w.named(id,LINK_BOT_IDS);
    w.varint(code|(hasKey?4:0)|(at!==undefined?8:0)|(given.l!==undefined?16:0)|(given.m!==undefined?32:0)|(other.length?64:0));
    if(hasKey){
      if(typeof key!=='string')outside();
      // A key that is a whole number (as the room gives them, 1, 2, 3...) as that number; else spelt out.
      if(/^(0|[1-9][0-9]{0,14})$/.test(key))w.varint(Number(key)+1);else{w.varint(0);w.text(key);}
    }
    if(at!==undefined)w.varint(Math.round(at*100));
    if(!other.length)return;
    let mask=0;OTHER.forEach((name,bit)=>{if(given[name]!==undefined)mask+=2**bit});
    w.varint(mask);
    for(const name of other){
      const value=given[name];
      if(FLAG[name]!==undefined)continue;
      if(name==='r')w.decimal(value);
      else if(name==='y'||name==='f')w.text(value);
      else if(name==='w'||name==='s'){if(!plainObject(value))outside();w.text(JSON.stringify(value));}
      else if(name==='x')w.settings(value,LINK_MIX_KEYS);
      else if(name==='g')w.varint(value);
      else if(name==='c'){if(value==='default')w.varint(0);else if(/^[0-9]{1,2}$/.test(String(value)))w.varint(Number(value)+1);else outside();}
      else if(name==='z'){const zone=ZONES.indexOf(value);if(zone<0)outside();w.varint(zone);}
      else if(name==='o'){if(value==='gm')w.varint(0);else if(Number.isInteger(value)&&value>=0&&value<=127)w.varint(value+1);else outside();}
    }
  });
  if(effects)w.settings(state.f,LINK_EFFECT_KEYS);
  if(plugin){if(!plainObject(state.p))outside();w.text(JSON.stringify(state.p));}
  // Raw (`3`), or deflated after its size (`4`) where that is shorter.
  const body=Uint8Array.from(w.bytes),raw=`3${toBase64Url(body)}`;
  if(body.length<=24)return raw;
  const size=new Writer();size.varint(body.length);
  const deflated=deflateSync(body,{level:9}),packed=new Uint8Array(size.bytes.length+deflated.length);
  packed.set(size.bytes);packed.set(deflated,size.bytes.length);
  const text=`4${toBase64Url(packed)}`;
  return text.length<raw.length?text:raw;
}
function decodeSchema(payload,deflated){
  let body=payload;
  if(deflated){
    const header=new Reader(payload),size=header.varint();
    if(!size||size>MAX_BYTES)throw new Error('size');
    body=inflateSync(payload.subarray(header.at),{out:new Uint8Array(size+1)});
    if(body.length!==size)throw new Error('size');
  }
  const r=new Reader(body),state={s:r.uint32(),a:r.varint()};
  const present=r.varint();if(present>3)throw new Error('fields');
  const count=r.varint();if(count>1024)throw new Error('bots');
  state.b=[];
  for(let index=0;index<count;index++){
    const id=r.named(LINK_BOT_IDS),flags=r.varint();if(flags>127)throw new Error('flags');
    const row=[id,undefined,flags&3,undefined],options={};
    if(flags&4){const key=r.varint();row[1]=key?String(key-1):r.text();}
    if(flags&8)options.a=r.varint()/100;
    if(flags&16)options.l=1;
    if(flags&32)options.m=1;
    if(flags&64){
      const mask=r.varint();if(!mask||mask>=2**OTHER.length)throw new Error('options');
      OTHER.forEach((name,bit)=>{
        if(!(Math.floor(mask/2**bit)%2))return;
        if(FLAG[name]!==undefined)options[name]=FLAG[name];
        else if(name==='r')options[name]=r.decimal();
        else if(name==='y'||name==='f')options[name]=r.text();
        else if(name==='w'||name==='s')options[name]=JSON.parse(r.text());
        else if(name==='x')options[name]=r.settings(LINK_MIX_KEYS);
        else if(name==='g')options[name]=r.varint();
        else if(name==='c'){const channel=r.varint();options[name]=channel?String(channel-1):'default';}
        else if(name==='z'){const zone=r.varint();if(zone>=ZONES.length)throw new Error('zone');options[name]=ZONES[zone];}
        else if(name==='o'){const program=r.varint();if(program>128)throw new Error('program');options[name]=program?program-1:'gm';}
      });
    }
    if(Object.keys(options).length)row[3]=options;
    state.b.push(row);
  }
  if(present&1)state.f=r.settings(LINK_EFFECT_KEYS);
  if(present&2)state.p=JSON.parse(r.text());
  if(r.at!==body.length)throw new Error('trailing bytes');
  return state;
}

function toBase64Url(bytes){
  let binary='';for(const byte of bytes)binary+=String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
}
function fromBase64Url(text){
  if(text.length%4===1)throw new Error('base64');
  const binary=atob(text.replace(/-/g,'+').replace(/_/g,'/'));
  return Uint8Array.from(binary,character=>character.charCodeAt(0));
}
