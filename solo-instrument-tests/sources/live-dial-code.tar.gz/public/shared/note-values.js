// Written glyph values, in whole notes. A grace has one of these values without consuming metrical time.
export const NOTE_TYPES=Object.freeze([['maxima',8],['long',4],['breve',2],['whole',1],['half',1/2],['quarter',1/4],['eighth',1/8],['16th',1/16],['32nd',1/32],['64th',1/64],
  ['128th',1/128],['256th',1/256],['512th',1/512],['1024th',1/1024]].map(Object.freeze));
