// A cursor names the next pulse. Resume that state on the recipient's monotonic clock, translating physical seconds
// by its known reference offset. Musical positions, authored tempo, curve boundaries and rubato progress stay intact.
import {localRubatoState,cursorRubatoState} from './rubato-clocks.js';

// The inverse boundary for a local clock: retain only musical/performance state, not timers, clients or kernel maps.
// The returned cursor is plain JSON, in seconds on the producer's monotonic clock, and names its NEXT pulse.
export function continuationCursor(state){
  const holding=state.holding?{...state.holding,pulseSeconds:state.holding.pulseSeconds??state.holding.pulseMs/1000}:null;
  if(holding){delete holding.pulseMs;delete holding.resumeHeard;}
  return structuredClone({at:state.nextAt===0?null:state.nextAt/1000,tick:state.tick,bar:state.bar,tickInBar:state.tickInBar,
    bpm:state.bpm,meter:state.meter,pendingMeter:state.pendingMeter?.provisional?null:state.pendingMeter??null,
    pendingTempo:state.pendingTempoCurve??null,curve:state.tempoCurve??null,inputTempoCommit:state.inputTempoCommit??null,
    scoreTempo:state.scoreTempo??null,holds:state.holds??[],holding,holdEndedBar:state.holdEndedBar,lastPulse:state.lastPulse,
    ...cursorRubatoState(state)});
}

export function clockContinuation(cursor,offset,session=null){
  if(!Number.isFinite(offset))throw new TypeError('A continuation needs its reference-to-local time offset');
  const s=structuredClone(cursor);
  const nextAt=s.at===null?0:(s.at+offset)*1000;
  if(s.rubato)s.rubato.startSeconds+=offset;
  if(s.holding){
    for(const key of ['startedAt','resumeAt','cueAt'])if(Number.isFinite(s.holding[key]))s.holding[key]+=offset;
    for(const key of Object.keys(s.holding.ready??{}))s.holding.ready[key]+=offset;
    s.holding.pulseMs=s.holding.pulseSeconds*1000;
  }
  if(s.inputTempoCommit)for(const key of ['effectiveAt','completesAt'])s.inputTempoCommit[key]+=offset;
  return {session:session?{...session}:null,tick:s.tick,bar:s.bar,tickInBar:s.tickInBar,bpm:s.bpm,meter:s.meter,nextAt,
    pendingMeter:s.pendingMeter??null,pendingTempoCurve:s.pendingTempo??null,tempoCurve:s.curve??null,
    inputTempoCommit:s.inputTempoCommit??null,scoreTempo:s.scoreTempo??null,
    holds:s.holds??[],holding:s.holding??null,holdEndedBar:s.holdEndedBar,lastPulse:s.lastPulse,
    pulseInterval:s.holding?.pulseSeconds??null,pulsed:s.tick>0,...localRubatoState(s)};
}
