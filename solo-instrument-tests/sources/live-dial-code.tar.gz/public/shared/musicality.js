import {registerDomain,orderedRegister} from './pitch-domain.js';
const clamp=(value,low=0,high=1)=>Math.max(low,Math.min(high,Number(value)||0));

export function chooseContrastingPitch(pool,history=[],{
  maximumRepeats=2,minimum=48,maximum=84,maximumLeap=9,
  registerCenter=(minimum+maximum)/2,edgePenalty=.45,random=()=>.5,period=12
}={}){
  const notes=[...new Set(pool.map(Number).filter(Number.isFinite))]
    .flatMap(pc=>registerDomain(pc,{low:minimum,high:maximum,period}));
  if(!notes.length)return null;
  const last=history.at(-1),run=history.slice().reverse().findIndex(note=>note!==last);
  const repeats=run<0?history.length:run;
  const previousDirection=history.length>1?Math.sign(last-history.at(-2)):0;
  const hasStepwiseChoice=last!=null&&notes.some(note=>Math.abs(note-last)<=maximumLeap);
  const weighted=notes.map(note=>{
    const interval=last==null?0:note-last;
    let weight=1/(1+Math.abs(interval)/5);
    if(note===last&&repeats>=maximumRepeats)weight=0;
    if(previousDirection&&Math.sign(interval)===-previousDirection)weight*=1.7;
    if(hasStepwiseChoice&&Math.abs(interval)>maximumLeap)weight=0;
    const halfRange=Math.max(1,(maximum-minimum)/2),
      edgeDistance=Math.abs(note-registerCenter)/halfRange;
    weight*=Math.max(.08,1-edgePenalty*edgeDistance*edgeDistance);
    return weight;
  });
  let target=random()*weighted.reduce((sum,value)=>sum+value,0);
  for(let index=0;index<notes.length;index++){
    if(weighted[index]<=0)continue;
    if((target-=weighted[index])<=0)return notes[index];
  }
  return notes.find(note=>note!==last)??notes[0];
}

export function voiceLeadChord(previous,pitchClasses,{low=48,high=76,period=12}={}){
  if(!Number.isFinite(period)||period<=0)throw new RangeError('A positive pitch period is required');
  const pcs=[...new Set(pitchClasses.map(Number).filter(Number.isFinite).map(value=>((value%period)+period)%period))],
    domains=pcs.map(pc=>registerDomain(pc,{low,high,period})),targets=pcs.map((_,i)=>previous?.[i]??low+i*4);
  return orderedRegister(domains,targets)?.pitches??[];
}

export function spaceAllocation(states,{targetDensity=.55}={}){
  const sounding=states.filter(state=>state.state==="performing"&&!state.messageOnly);
  const count=Math.max(1,sounding.length);
  return sounding.map((state,index)=>({
    target:state.instanceId,
    density:clamp(targetDensity/count*.9+.08,.08,.72),
    phase:(index+.5)/count,
    downbeatProbability:index===0?.45:.12,
    role:index===0?"anchor":index%2?"response":"support",
  }));
}

export function ensembleMixPlacements(states,{maximumForeground=3,crowdingScale=.055}={},phrase=0){
  const sounding=states.filter(state=>state.state==="performing"&&!state.messageOnly),
    priority=state=>{
      const category=String(state.category||"").toLowerCase();
      if(category.includes("melody")||category.includes("ornament"))return 4;
      if(category.includes("bass"))return 3;
      if(category.includes("harmony"))return 2.4;
      if(category.includes("keys"))return 1.8;
      if(category.includes("beat")||category.includes("percussion"))return 1.2;
      if(category.includes("drone")||category.includes("texture"))return .4;
      return 1;
    },
    ordered=sounding.slice().sort((left,right)=>
      priority(right)-priority(left)||
      String(left.instanceId).localeCompare(String(right.instanceId))
    ),
    foregroundCount=Math.min(
      maximumForeground,
      ordered.length,
      Math.max(1,Math.ceil((ordered.length-2)/3)),
    ),
    crowding=-Math.min(.38,Math.max(0,ordered.length-3)*crowdingScale),
    rotated=ordered.length
      ? ordered.slice(phrase%ordered.length).concat(ordered.slice(0,phrase%ordered.length))
      : [],
    foreground=new Set(
      rotated.slice().sort((left,right)=>priority(right)-priority(left))
        .slice(0,foregroundCount).map(state=>state.instanceId)
    );
  return ordered.map(state=>{
    const score=priority(state),isForeground=foreground.has(state.instanceId),
      role=isForeground?"foreground":score<=.5?"background":"support",
      rolePlacement=isForeground?.42:role==="background"?-.5:score<=1.2?-.25:-.08,
      placement=Math.max(-1,Math.min(1,rolePlacement+crowding));
    return{target:state.instanceId,placement,role,category:state.category,ensembleSize:ordered.length};
  });
}
