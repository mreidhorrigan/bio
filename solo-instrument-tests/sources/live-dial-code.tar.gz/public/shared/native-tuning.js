// Microtonal harmony played by a bot itself, without a tuning bot to supply it (the user: "In the clodbots, we are also
// now free to build microtonal harmony into the bots natively instead of relying on tunebot to supply it").
//
// A voicing chosen in equal temperament is sounded in just intonation: each note tuned to the harmonic series of the
// chord's root, the ratio of its interval above the root (Sethares 2005: a chord of harmonic partials beats least). Three
// intonations:
// - 'equal': as chosen.
// - 'just': five-limit ratios, the major third 5/4 (14 cents below equal), the minor third 6/5 (16 above), the fifth 3/2,
//   the minor seventh 9/5 (a minor third above the fifth).
// - 'harmonic': the same, but a chord with a major third takes its minor seventh as the seventh harmonic (7/4, 31 cents
//   below equal: the barbershop seventh) and its sharp eleventh as the eleventh (11/8): the overtone chord, the colour
//   spectral and impressionist writing draws on.
//
// Pure intervals within each chord would drift from chord to chord (the syntonic comma: a note held as a common tone
// moves 22 cents when its role changes). So a voice held from the chord before keeps its pitch: the new chord's root is
// moved by as much as the held voices need, spread among them, pulled back toward equal temperament (`pull`) and never
// further than `maxDrift` semitones from it, so the band stays in tune with a performer who plays in equal temperament.
// Pitches already between the keys (a maqam's quarter tones, heard) are left as they are.
const modulo=(value,period)=>((value%period)+period)%period;
const cents=ratio=>1200*Math.log2(ratio);

export const JUST_RATIOS=Object.freeze({
  just:Object.freeze([1,16/15,9/8,6/5,5/4,4/3,45/32,3/2,8/5,5/3,9/5,15/8]),
});
export const INTONATIONS=Object.freeze(['equal','just','harmonic']);

// The offset, in semitones from equal temperament, of an interval above a chord's root in an intonation. `major`: the
// chord has a major third (the harmonic intonation's seventh and eleventh apply to it).
export function justOffset(interval,{intonation='just',major=false}={}){
  if(intonation==='equal')return 0;
  const step=modulo(Math.round(interval),12);
  let ratio=JUST_RATIOS.just[step];
  if(intonation==='harmonic'&&major){if(step===10)ratio=7/4;if(step===6)ratio=11/8;}
  return (cents(ratio)-100*step)/100;
}

// A voicing (pitches low to high, as chosen) tuned: {pitches, drift}. root: the chord's root pitch class; major: whether
// the chord has a major third. previous: the last voicing tuned, {chosen, pitches, drift}, for the common tones it holds.
export function tuneVoicing(voicing,{root,major=false,intonation='just',previous=null,pull=1,maxDrift=.15}={}){
  if(intonation==='equal'||!Number.isFinite(root))return {pitches:[...voicing],drift:0};
  const nearKey=pitch=>Math.abs(pitch-Math.round(pitch))<.08;
  const offsets=voicing.map(pitch=>nearKey(pitch)?justOffset(pitch-root,{intonation,major}):null);
  // The root's drift that keeps held voices where they were: the mean of what each needs, pulled toward none.
  let need=0,held=0;
  if(previous)for(let i=0;i<voicing.length;i++){
    if(offsets[i]===null)continue;
    const at=previous.chosen?.findIndex(pitch=>Math.abs(pitch-voicing[i])<.01)??-1;
    if(at>=0){need+=previous.pitches[at]-previous.chosen[at]-offsets[i];held++;}
  }
  const drift=Math.max(-maxDrift,Math.min(maxDrift,held?need/(held+pull):0));
  // From the key a pitch is near: a pitch given a few cents off it (a just fifth, 67.02) is tuned, not tuned twice.
  return {pitches:voicing.map((pitch,i)=>offsets[i]===null?pitch:+(Math.round(pitch)+offsets[i]+drift).toFixed(4)),drift:+drift.toFixed(4)};
}
// One note (a figure's, a line's) in the intonation of the chord sounding: its interval above the root, and the chord's
// drift.
export function tuneNote(pitch,{root,major=false,intonation='just',drift=0}={}){
  if(intonation==='equal'||!Number.isFinite(root)||Math.abs(pitch-Math.round(pitch))>=.08)return pitch;
  return +(Math.round(pitch)+justOffset(pitch-root,{intonation,major})+drift).toFixed(4);
}
