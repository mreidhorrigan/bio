// Harmony in levels, as meter has levels. A performer's harmony is heard at several time scales at once: the chord of
// the moment, the scale it is drawn from (the jazz 13th chord, stacked in thirds from its root, is that whole
// seven-note scale), the scale's centre (its mode), and sets inside the scale, such as a pentatonic within a diatonic
// collection. Lerdahl's tonal pitch space nests them as a metrical grid nests beats: chromatic, diatonic, triadic,
// fifth and root levels (Lerdahl 2001). A band that cannot know the next chord before it is played, as a person
// cannot, can still know the scale, and play the notes that will sound well against whatever chord comes.
//
// Levels are data, not built in (the user: "extensible where given bespoke layers of possible pitch classes which,
// in some cases, might include microtuning"). A levels vocabulary names its tuning and period, in semitones, which
// need be neither 12 nor an octave. Its layers run from the widest sets to the narrowest, each a family of pitch-class
// sets given by steps or pitch classes, in any fractions of a semitone, transposed as the family says. Nothing reads
// a pitch class's name; sets contain one another, and evidence matches a pitch class, within the vocabulary's
// tolerance. TWELVE_TONE_LEVELS is one vocabulary, and QUARTER_TONE_MAQAM_LEVELS another, in 24-EDO.
//
// This module holds the vocabularies and what follows from them: which sets hold which, the notes certain at each
// layer given beliefs over its sets, a chord's scale within a collection, and how consonant each pitch class is
// expected to be against chords not yet heard. The beliefs themselves are filtered over time in
// harmonic-levels-filter.js.
import {frozenJson,identifier} from '../planning-data.js';

const freeze=value=>frozenJson(value,{bytes:1<<20,items:1<<16}).data;
const modulo=(value,period)=>((value%period)+period)%period;
// The distance between two pitch classes around the period.
export const pitchClassDistance=(a,b,period)=>{const d=modulo(a-b,period);return Math.min(d,period-d)};
const round=value=>Math.round(value*1e6)/1e6;

// A levels vocabulary, validated and expanded: every set of every layer, with its members, the sets of the layer
// above that hold it, and its modes (its rotations, each centred on one of its members).
//   spec: {vocabularyId, tuningId, periodSemitones = 12, toleranceSemitones = 0.2, layers: [{id, families}],
//     chromaticWeight = 1}
// The widest layer also holds the chromatic set, every pitch class the vocabulary names (Lerdahl's chromatic level),
// weighted `chromaticWeight` among its families (0 leaves it out): music in no particular scale, as noise is. Without
// it, pitch classes heard at random would be believed to be the largest scale.
//   family: {id, steps: [...] (intervals in semitones, summing to the period) or pitchClasses: [...] (from its root),
//     modes: [names, one for each rotation] (optional), modePriors: [one for each rotation] (how often each is the
//     centre, default all alike), transpositions: a step in semitones (default 1) or a list of roots, weight: its prior
//     among the layer's families (default 1)}
export function levelsVocabulary(spec){
  const {vocabularyId,tuningId,periodSemitones=12,toleranceSemitones=.2,layers,chromaticWeight=1}=spec??{};
  if(!(chromaticWeight>=0))throw new TypeError('Invalid chromatic weight');
  identifier(vocabularyId);identifier(tuningId);
  if(!(Number.isFinite(periodSemitones)&&periodSemitones>0&&periodSemitones<=48))throw new TypeError('A levels vocabulary needs a period of up to 48 semitones');
  if(!(toleranceSemitones>0&&toleranceSemitones<periodSemitones/4))throw new TypeError('Invalid levels tolerance');
  if(!Array.isArray(layers)||!layers.length||layers.length>8)throw new TypeError('A levels vocabulary has one to eight layers');
  const period=periodSemitones,same=(a,b)=>pitchClassDistance(a,b,period)<=toleranceSemitones;
  const expanded=layers.map((layer,index)=>{
    identifier(layer.id);
    if(!Array.isArray(layer.families)||!layer.families.length)throw new TypeError(`Layer ${layer.id} has no families`);
    const sets=[],seen=[];
    for(const family of layer.families){
      identifier(family.id);
      let shape;
      if(Array.isArray(family.steps)){
        if(!family.steps.length||family.steps.some(step=>!(step>0)))throw new TypeError(`Family ${family.id}: steps must be positive`);
        const total=family.steps.reduce((sum,step)=>sum+step,0);
        if(Math.abs(total-period)>toleranceSemitones)throw new TypeError(`Family ${family.id}: its steps sum to ${total}, not the period ${period}`);
        shape=family.steps.slice(0,-1).reduce((pcs,step)=>[...pcs,pcs.at(-1)+step],[0]);
      }else if(Array.isArray(family.pitchClasses)&&family.pitchClasses.length){
        if(family.pitchClasses.some(pc=>!Number.isFinite(pc)))throw new TypeError(`Family ${family.id}: invalid pitch classes`);
        shape=[...new Set(family.pitchClasses.map(pc=>round(modulo(pc,period))))].sort((a,b)=>a-b);
      }else throw new TypeError(`Family ${family.id} needs steps or pitch classes`);
      if(shape.length>64)throw new TypeError(`Family ${family.id} has too many pitch classes`);
      const modes=family.modes??null,modePriors=family.modePriors??null;
      if(modes&&(!Array.isArray(modes)||modes.length!==shape.length))throw new TypeError(`Family ${family.id}: one mode name for each of its ${shape.length} rotations`);
      if(modePriors&&(!Array.isArray(modePriors)||modePriors.length!==shape.length||modePriors.some(p=>!(p>0))))throw new TypeError(`Family ${family.id}: one positive mode prior for each rotation`);
      const weight=family.weight??1;if(!(weight>0))throw new TypeError(`Family ${family.id}: its weight must be positive`);
      const roots=Array.isArray(family.transpositions)?family.transpositions:
        Array.from({length:Math.max(1,Math.round(period/(family.transpositions??1)))},(_,k)=>k*(family.transpositions??1));
      for(const root of roots){
        if(!Number.isFinite(root))throw new TypeError(`Family ${family.id}: invalid transposition`);
        const pitchClasses=shape.map(pc=>round(modulo(pc+root,period))).sort((a,b)=>a-b);
        // A symmetric family repeats under transposition (whole-tone twice in 12): each set once.
        if(seen.some(other=>other.length===pitchClasses.length&&other.every((pc,i)=>same(pc,pitchClasses[i]))))continue;
        seen.push(pitchClasses);
        sets.push({id:`${family.id}@${round(modulo(root,period))}`,family:family.id,root:round(modulo(root,period)),pitchClasses,weight,
          modes:shape.map((_,k)=>({center:round(modulo(shape[k]+root,period)),name:modes?.[k]??`${family.id}-${k+1}`,degree:k,prior:modePriors?.[k]??1}))});
      }
    }
    return {id:layer.id,index,sets};
  });
  // The grid of pitch classes the vocabulary speaks of, each once, and the chromatic set of all of them.
  const grid=[];for(const layer of expanded)for(const set of layer.sets)for(const pc of set.pitchClasses)if(!grid.some(other=>same(other,pc)))grid.push(pc);
  grid.sort((a,b)=>a-b);
  if(chromaticWeight>0)expanded[0].sets.push({id:'chromatic@0',family:'chromatic',root:0,pitchClasses:[...grid],weight:chromaticWeight,chromatic:true,
    modes:grid.map((pc,k)=>({center:pc,name:`chromatic-${k+1}`,degree:k,prior:1}))});
  // Priors: each family's weight shared among its sets.
  for(const layer of expanded){
    const byFamily=new Map;for(const set of layer.sets)byFamily.set(set.family,(byFamily.get(set.family)??0)+1);
    const total=layer.sets.reduce((sum,set)=>sum+set.weight/byFamily.get(set.family),0);
    for(const set of layer.sets)set.prior=set.weight/byFamily.get(set.family)/total;
  }
  const contains=(outer,inner)=>inner.every(pc=>outer.some(other=>same(pc,other)));
  for(let k=1;k<expanded.length;k++)for(const set of expanded[k].sets)set.parents=expanded[k-1].sets.filter(parent=>contains(parent.pitchClasses,set.pitchClasses)).map(parent=>parent.id);
  return freeze({vocabularyId,tuningId,periodSemitones:period,toleranceSemitones,grid,layers:expanded});
}

// The layer named, or the first.
export const levelsLayer=(vocabulary,id=null)=>id===null?vocabulary.layers[0]:vocabulary.layers.find(layer=>layer.id===id)??null;
export function setHolds(vocabulary,set,pitchClasses){
  const {periodSemitones:period,toleranceSemitones:tolerance}=vocabulary;
  return pitchClasses.every(pc=>set.pitchClasses.some(member=>pitchClassDistance(pc,member,period)<=tolerance));
}

// The notes certain at a layer: each grid pitch class's probability of belonging to the set sounding, given beliefs
// over the layer's sets ({setId: probability}), and those at `threshold` or more. Where the beliefs spread over
// collections that share notes, the notes they share are certain and the others not: over C, F and G major, the
// certain notes are C, D, E, G and A, the pentatonic the three hold in common.
export function layerMembership(vocabulary,layerId,beliefs,{threshold=.9}={}){
  const layer=levelsLayer(vocabulary,layerId);
  if(!layer)throw new TypeError(`No layer ${layerId}`);
  const {periodSemitones:period,toleranceSemitones:tolerance}=vocabulary;
  const membership=vocabulary.grid.map(pc=>({pc,probability:layer.sets.reduce((sum,set)=>sum+(beliefs[set.id]??0)*
    (set.pitchClasses.some(member=>pitchClassDistance(pc,member,period)<=tolerance)?1:0),0)}));
  return {layer:layer.id,membership,certain:membership.filter(entry=>entry.probability>=threshold).map(entry=>entry.pc)};
}

// A chord's scale: the set of a layer that holds the chord and is likeliest given beliefs over the layer (a chord of
// the key takes the key's collection, rotated to its root: the 13th chord), else, where none holds it, the one
// holding most of it. Returns {set, holds} or null.
export function chordScale(vocabulary,chordPitchClasses,beliefs,{layerId=null}={}){
  const layer=levelsLayer(vocabulary,layerId);let best=null;
  for(const set of layer.sets){
    const held=chordPitchClasses.filter(pc=>setHolds(vocabulary,set,[pc])).length,score=held*10+(beliefs[set.id]??0)+set.prior*1e-3;
    if(!best||score>best.score)best={set,holds:held===chordPitchClasses.length,score};
  }
  return best?{set:best.set,holds:best.holds}:null;
}

// How a pitch class sounds against a chord, in the chord's scale, as jazz theory classes a note (Levine 1995): a chord
// tone; a tension, a scale tone that does not sit just above
// a chord tone; an avoid note, a scale tone within `avoidSemitones` above a chord tone (a minor ninth against it); or
// outside the scale. Where the scale is only the chromatic set (no scale is heard), no note but the chord's is trusted:
// the rest are outside. `weights` rates each as the band hears it against an unknown chord: a named, hand-set model.
export const CONSONANCE_MODEL=Object.freeze({modelId:'chord-scale-consonance-v1',avoidSemitones:1.5,
  weights:Object.freeze({chord:1,tension:.75,avoid:.15,outside:.05}),
  fittedOn:'hand-set from chord-scale theory (Levine 1995): no data'});
export function noteClass(vocabulary,pc,chordPitchClasses,scalePitchClasses,{avoidSemitones=CONSONANCE_MODEL.avoidSemitones,chromatic=false}={}){
  const {periodSemitones:period,toleranceSemitones:tolerance}=vocabulary;
  if(chordPitchClasses.some(tone=>pitchClassDistance(pc,tone,period)<=tolerance))return 'chord';
  if(chromatic||!scalePitchClasses.some(member=>pitchClassDistance(pc,member,period)<=tolerance))return 'outside';
  return chordPitchClasses.some(tone=>{const above=modulo(pc-tone,period);return above>tolerance&&above<avoidSemitones})?'avoid':'tension';
}

// The consonance each grid pitch class is expected to have against the chord to come, given a distribution over
// chords ([{pitchClasses, probability}]) and beliefs over the scale layer's sets: {pc, consonance} for each, and the
// hedge, those at `threshold` or more. A band sure of the chord plays its tones and tensions; one that knows only the
// key plays the notes that will sound against most of its chords.
export function expectedConsonance(vocabulary,chords,beliefs,{layerId=null,threshold=.75,model=CONSONANCE_MODEL}={}){
  const total=chords.reduce((sum,chord)=>sum+chord.probability,0)||1;
  const scales=chords.map(chord=>chordScale(vocabulary,chord.pitchClasses,beliefs,{layerId})?.set??{pitchClasses:chord.pitchClasses});
  const consonance=vocabulary.grid.map(pc=>({pc,consonance:chords.reduce((sum,chord,i)=>
    sum+chord.probability/total*model.weights[noteClass(vocabulary,pc,chord.pitchClasses,scales[i].pitchClasses,{...model,chromatic:Boolean(scales[i].chromatic)})],0)}));
  return {consonance,hedge:consonance.filter(entry=>entry.consonance>=threshold).sort((a,b)=>b.consonance-a.consonance).map(entry=>entry.pc)};
}

// Twelve-tone equal temperament: the seven-note collections of tonal and jazz harmony (the diatonic, the melodic and
// harmonic minors, the harmonic major: Tymoczko 2011's scales of minimal voice leading), the symmetric scales, and the
// pentatonic within them. Each family's modes are its rotations, named as jazz theory names them. Their priors, how
// often each is the centre, are hand-set from common practice (major and minor most, dorian and mixolydian next,
// phrygian and lydian less, locrian least; a harmonic minor's own mode, then its phrygian dominant): no data.
const TWELVE_TONE_COLLECTIONS=Object.freeze({id:'collection',families:[
  {id:'diatonic',steps:[2,2,1,2,2,2,1],modes:['ionian','dorian','phrygian','lydian','mixolydian','aeolian','locrian'],modePriors:[1,.5,.15,.15,.5,.9,.03],weight:4},
  {id:'melodic-minor',steps:[2,1,2,2,2,2,1],modes:['melodic-minor','dorian-flat-2','lydian-augmented','lydian-dominant','mixolydian-flat-6','locrian-natural-2','altered'],modePriors:[1,.1,.1,.3,.1,.1,.2],weight:1},
  {id:'harmonic-minor',steps:[2,1,2,2,1,3,1],modes:['harmonic-minor','locrian-natural-6','ionian-augmented','dorian-sharp-4','phrygian-dominant','lydian-sharp-2','ultralocrian'],modePriors:[1,.05,.05,.1,.3,.05,.02],weight:1},
  {id:'harmonic-major',steps:[2,2,1,2,1,3,1],weight:.3},
  {id:'whole-tone',steps:[2,2,2,2,2,2],weight:.1},
  {id:'octatonic',steps:[1,2,1,2,1,2,1,2],modes:['half-whole','whole-half','half-whole','whole-half','half-whole','whole-half','half-whole','whole-half'],weight:.1},
  {id:'hexatonic',steps:[1,3,1,3,1,3],weight:.1},
]});
const TWELVE_TONE_PENTATONICS=Object.freeze({id:'pentatonic',families:[
  {id:'pentatonic',steps:[2,2,3,2,3],modes:['major-pentatonic','suspended-pentatonic','blues-minor-pentatonic','blues-major-pentatonic','minor-pentatonic'],modePriors:[1,.3,.3,.3,.9]},
]});
export const TWELVE_TONE_LEVELS=levelsVocabulary({vocabularyId:'twelve-tone-levels-v1',tuningId:'12-equal',periodSemitones:12,toleranceSemitones:.2,
  layers:[TWELVE_TONE_COLLECTIONS,TWELVE_TONE_PENTATONICS]});

// The same with a wider layer above the collections, listened for only where it is chosen (a jazz session): the eight-
// note scales of bebop, a seven-note mode with one note added, which put a half step where the mode has a whole one.
// Barry Harris's sixth-diminished scales interleave a sixth chord with a diminished seventh (C E G A with D F G-sharp
// B); Baker's bebop dominant adds the major seventh to the mixolydian. Heard as a bag of pitch classes, an eight-note
// set spreads its probability over one more note, so it is believed only where the added note keeps sounding. Against a
// chord, the added note, a half step above a chord tone, classes as an avoid note: passing, not held.
export const TWELVE_TONE_BEBOP_LEVELS=levelsVocabulary({vocabularyId:'twelve-tone-bebop-levels-v1',tuningId:'12-equal',periodSemitones:12,toleranceSemitones:.2,
  layers:[
    {id:'eight-note',families:[
      {id:'sixth-diminished',steps:[2,2,1,2,1,1,2,1]},
      {id:'minor-sixth-diminished',steps:[2,1,2,2,1,1,2,1]},
      {id:'dominant-bebop',steps:[2,2,1,2,2,1,1,1]},
    ]},
    TWELVE_TONE_COLLECTIONS,TWELVE_TONE_PENTATONICS,
  ]});

// The blues, listened for where it is chosen: a nine-note layer above the collections. A 12-bar blues's three dominant
// chords (I7, IV7, V7) hold nine notes between them, the mixolydian of the tonic with its minor third and major
// seventh added; no seven-note collection holds them, so a listener without this layer never settles on one. The
// composite blues scale (the major and minor blues together: 1 2 b3 3 4 b5 5 6 b7) is its melodic neighbour.
export const TWELVE_TONE_BLUES_LEVELS=levelsVocabulary({vocabularyId:'twelve-tone-blues-levels-v1',tuningId:'12-equal',periodSemitones:12,toleranceSemitones:.2,
  layers:[
    {id:'nine-note',families:[
      {id:'dominant-blues',steps:[2,1,1,1,2,2,1,1,1]},
      {id:'composite-blues',steps:[2,1,1,1,1,1,2,1,2]},
    ]},
    TWELVE_TONE_COLLECTIONS,TWELVE_TONE_PENTATONICS,
  ]});

// A bespoke vocabulary in quarter tones (24-EDO), as Arabic maqam theory writes its scales in Western notation: an
// approximation (the neutral intervals vary by region and player), and an example of layers given as data. The upper
// layer is the maqam; the lower its ajnas, the tri- and tetrachords maqamat are built from. Steps in semitones.
export const QUARTER_TONE_MAQAM_LEVELS=levelsVocabulary({vocabularyId:'quarter-tone-maqam-levels-v1',tuningId:'24-equal',periodSemitones:12,toleranceSemitones:.2,
  layers:[
    {id:'maqam',families:[
      {id:'rast',steps:[2,1.5,1.5,2,2,1.5,1.5],transpositions:.5},
      {id:'bayati',steps:[1.5,1.5,2,2,1,2,2],transpositions:.5},
      {id:'hijaz',steps:[1,3,1,2,1,2,2],transpositions:.5},
      {id:'nahawand',steps:[2,1,2,2,1,3,1],transpositions:.5},
      {id:'kurd',steps:[1,2,2,2,1,2,2],transpositions:.5},
      {id:'ajam',steps:[2,2,1,2,2,2,1],transpositions:.5},
      {id:'saba',steps:[1.5,1.5,1,3,1,2,2],transpositions:.5},
    ]},
    {id:'jins',families:[
      {id:'jins-rast',pitchClasses:[0,2,3.5,5],transpositions:.5},
      {id:'jins-bayati',pitchClasses:[0,1.5,3,5],transpositions:.5},
      {id:'jins-hijaz',pitchClasses:[0,1,4,5],transpositions:.5},
      {id:'jins-nahawand',pitchClasses:[0,2,3,5],transpositions:.5},
      {id:'jins-kurd',pitchClasses:[0,1,3,5],transpositions:.5},
      {id:'jins-ajam',pitchClasses:[0,2,4,5],transpositions:.5},
      {id:'jins-saba',pitchClasses:[0,1.5,3,4],transpositions:.5},
    ]},
  ]});
