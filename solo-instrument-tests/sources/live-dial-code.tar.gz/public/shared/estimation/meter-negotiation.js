import {actor,actorKey,checkOrigin,frozenJson,identifier,scope as executionScope} from '../planning-data.js';
import {metricalState} from './metrical-state.js';

const freeze=value=>frozenJson(value,{bytes:65536,items:8192}).data;
const finite=(value,label)=>{if(!Number.isFinite(value))throw new TypeError(`Invalid ${label}`);return value;};
// Labels and accent groupings stay categorical. Phase stays on its existing
// rational pulse coordinate; neither this resolver nor a report resets a clock.
const musicalKey=m=>JSON.stringify([m.numerator,m.denominator,m.groups,m.referencePulse,m.phase]);

export class MeterNegotiation {
  constructor({identity,scope,sessionId,policyVersion,resolution='agreement',publishers,leader=null,reportLimit=64,snapshotLimit=32}) {
    this.identity=actor(identity);this.scope=executionScope(scope);this.sessionId=identifier(sessionId);
    this.policyVersion=identifier(policyVersion);
    if(!this.scope.participants.some(member=>actorKey(member)===actorKey(this.identity)))throw new Error('Meter selector must belong to its declared scope');
    if(!['agreement','priority','follow-leader','maintain','polymeter'].includes(resolution))throw new TypeError('Unknown meter policy');
    if(!Array.isArray(publishers)||publishers.length>64||!Number.isInteger(reportLimit)||reportLimit<1||reportLimit>256||
      !Number.isInteger(snapshotLimit)||snapshotLimit<1||snapshotLimit>128)throw new TypeError('Invalid meter negotiation budget');
    this.publishers=new Map();
    for(const input of publishers){const publisher=actor(input.publisher),key=actorKey(publisher);
      if(this.publishers.has(key)||!Number.isFinite(input.priority)||input.priority<0||input.priority>100)throw new TypeError('Invalid/duplicate metrical publisher');
      this.publishers.set(key,{publisher,priority:input.priority});}
    this.leader=leader?actor(leader):null;
    if(resolution==='follow-leader'&&(!this.leader||!this.publishers.has(actorKey(this.leader))))throw new Error('Name an authorized parameter-specific meter leader');
    Object.assign(this,{resolution,reportLimit,snapshotLimit});this.reports=new Map();this.sealed=new Map();
  }
  receive(input,{origin,receivedAt}) {
    input=freeze(input);checkOrigin(input.publisher,origin);
    const publisher=actor(input.publisher),key=actorKey(publisher);identifier(input.reportId);
    if(!this.publishers.has(key)||input.sessionId!==this.sessionId||input.version!==1)throw new Error('Unregistered metrical publisher or session');
    if(!Number.isSafeInteger(input.sequence)||input.sequence<0||!['declaration','proposal','estimate'].includes(input.kind))throw new TypeError('Invalid meter report');
    for(const field of ['availableAt','validFrom','validUntil'])finite(input[field],field);finite(receivedAt,'local receipt');
    if(input.availableAt>receivedAt||input.validFrom>=input.validUntil)throw new TypeError('Noncausal or empty meter interval');
    if(input.kind==='estimate'&&(!input.inputSnapshotRef||!['tracking','ambiguous','unknown','stale'].includes(input.trackingState)))throw new Error('Meter estimates require their evidence snapshot and ambiguity');
    const meter=metricalState(input.meter),report=freeze({...input,publisher,meter}),canonical=JSON.stringify(report);
    const old=this.reports.get(input.reportId);
    if(old){if(old.canonical!==canonical)throw new Error('Meter report IDs are immutable');return false;}
    if([...this.reports.values()].some(entry=>actorKey(entry.report.publisher)===key&&entry.report.sequence===input.sequence))throw new Error('Conflicting metrical report sequence');
    if(this.reports.size>=this.reportLimit)throw new Error('Meter report budget exhausted; retire expired reports before accepting more');
    this.reports.set(input.reportId,{report,canonical,receivedAt});return true;
  }
  retireBefore(time) {
    finite(time,'meter retention time');
    for(const [id,{report}] of this.reports)if(report.validUntil<=time)this.reports.delete(id);
  }
  seal({decisionId,cutoff,effectiveAt,expiresAt,currentMeter}) {
    identifier(decisionId);for(const [key,value] of Object.entries({cutoff,effectiveAt,expiresAt}))finite(value,key);
    const current=metricalState(currentMeter);
    if(effectiveAt<cutoff||expiresAt<=effectiveAt)throw new Error('Meter changes require a future effective interval');
    const request=JSON.stringify({cutoff,effectiveAt,expiresAt,current});
    const existing=this.sealed.get(decisionId);
    if(existing){if(existing.request!==request)throw new Error('A sealed meter decision cannot be revised');return existing.proposal;}
    if(this.sealed.size>=this.snapshotLimit)throw new Error('Meter decision retention budget exhausted');
    const latest=new Map(),excluded=[];
    for(const {report,receivedAt} of this.reports.values()){
      if(report.availableAt>cutoff||receivedAt>cutoff)continue;
      const reason=report.validFrom>effectiveAt||report.validUntil<expiresAt?'outside-validity':
        JSON.stringify(report.meter.referencePulse)!==JSON.stringify(current.referencePulse)?'incompatible-reference-pulse':
        report.kind==='estimate'&&report.trackingState!=='tracking'?'unresolved-estimate':null;
      if(reason){excluded.push({reportId:report.reportId,reason});continue;}
      const key=actorKey(report.publisher),old=latest.get(key);
      if(!old||report.sequence>old.sequence)latest.set(key,report);
    }
    const eligible=[...latest.values()].sort((a,b)=>a.reportId<b.reportId?-1:1);
    let selected=eligible,status='resolved',reason=this.resolution,meter=current;
    if(this.resolution==='follow-leader')selected=eligible.filter(report=>actorKey(report.publisher)===actorKey(this.leader));
    if(this.resolution==='priority'&&eligible.length){
      const best=Math.min(...eligible.map(report=>this.publishers.get(actorKey(report.publisher)).priority));
      selected=eligible.filter(report=>this.publishers.get(actorKey(report.publisher)).priority===best);
    }
    if(this.resolution==='maintain')selected=[];
    else if(this.resolution==='polymeter'){status='independent';reason='retain-source-specific-meters';}
    else if(!selected.length){status='unresolved';reason='no-eligible-report-hold-current';}
    else if(new Set(selected.map(report=>musicalKey(report.meter))).size>1){status='unresolved';reason='conflicting-meters-hold-current';}
    else meter=selected[0].meter;
    const proposal=freeze({version:1,kind:'meter-influence-proposal',proposalId:decisionId,sessionId:this.sessionId,
      botId:this.identity.id,selector:this.identity,policyVersion:this.policyVersion,authorityScope:this.scope,
      status,reason,cutoff,result:{meter,effectiveInterval:{start:effectiveAt,end:expiresAt},
        sourceMeters:this.resolution==='polymeter'?eligible.map(report=>({publisher:report.publisher,meter:report.meter})):[]},
      basis:{reports:eligible.map(report=>report.reportId),selected:selected.map(report=>report.reportId),excluded},
      alternatives:eligible.map(report=>({reportId:report.reportId,publisher:report.publisher,meter:report.meter,kind:report.kind})),
      execution:'proposal-only',unknownInputPolicy:'hold-current'});
    this.sealed.set(decisionId,{request,proposal});return proposal;
  }
}
