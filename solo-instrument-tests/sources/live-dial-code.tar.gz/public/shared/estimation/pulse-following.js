import {PulseCoupler} from './pulse-coupler.js';

// The free-performance follower. The held-out tempo comparison kept PulseCoupler
// for following (the occurrence beam, rhythm-beam-v5, reports alternatives and
// ambiguity beside it), so this adapts the coupler unchanged to observation
// replay: a pure step from a plain snapshot, so a late onset can be replayed from
// any checkpoint. The forecast is scored as the comparison scored it: the next
// grid beat at or after the horizon.
const DYNAMIC=['strategy','beatsPerBar','referencePeriod','period','expected','last','errors','intervals','misses','observations',
  'state','divergent','acquired','explained','reanchored','unheard'];
const copy=value=>Array.isArray(value)?value.map(entry=>Array.isArray(entry)?[...entry]:entry):value;

function couplerOf(state){
  const coupler=new PulseCoupler({bpm:60/state.referencePeriod,beatsPerBar:state.beatsPerBar,strategy:state.strategy});
  // A snapshot from before a field existed keeps the coupler's own default for it.
  for(const key of DYNAMIC)if(state[key]!==undefined)coupler[key]=copy(state[key]);
  return coupler;
}
function stateOf(coupler){return {version:1,model:'pulse-coupler-antescofo-v1',...Object.fromEntries(DYNAMIC.map(key=>[key,copy(coupler[key])]))};}

export function createPulseFollower({bpm=120,beatsPerBar=4,strategy=0}={}){
  if(!(bpm>=20&&bpm<=300))throw new TypeError('Invalid follower reference tempo');
  return stateOf(new PulseCoupler({bpm,beatsPerBar,strategy}));
}

export function observePulseFollower(state,eventTime){
  if(state?.model!=='pulse-coupler-antescofo-v1'||!Number.isFinite(eventTime))throw new TypeError('Invalid pulse follower step');
  const coupler=couplerOf(state);coupler.observe(eventTime);
  return stateOf(coupler);
}

// Beats of one metre relate by duple and triple multiples, and by 3:2 (a dotted
// beat). The coupler chooses its level from inter-onset intervals and the room's
// tempo alone, so a player in semiquavers a little slower than the room is
// acquired at three semiquavers, a dotted quaver, and followed at 4/3 of their
// tempo. The beam chooses its level from where the accents fall. When the beam
// tracks, and the follower's beat stands in no such relation to any level the
// beam still holds in contention (its level, and the rival an ambiguous level is
// weighed against), the evidence contradicts the follower. The Groove MIDI
// held-out comparison confirmed that holding such a follower helps. The beam has
// since replaced the coupler as the follower, so the guard now serves the
// comparison rows (experiments/input-influence/level-guard.mjs), not the report.
export const LEVEL_RELATIONS=Object.freeze([1/4,1/3,1/2,2/3,1,3/2,2,3,4]);
export function contendingLevels(rhythm){
  const leading=rhythm?.candidates?.[0]?.forecast?.periodSeconds,pair=rhythm?.metricalLevelAmbiguous?rhythm.levelAmbiguity?.periodsSeconds:null;
  if(!(leading>0))return [];
  return Array.isArray(pair)&&pair.every(period=>period>0)?[...new Set([leading,...pair])]:[leading];
}
export function levelConflict({followerStatus,followerPeriod,beamStatus,beamPeriods},{relations=LEVEL_RELATIONS,tolerance=.05}={}){
  if(followerStatus!=='tracking'||beamStatus!=='tracking'||!(followerPeriod>0)||!beamPeriods?.length)return false;
  return beamPeriods.every(period=>!relations.some(relation=>Math.abs(period/followerPeriod/relation-1)<tolerance));
}

// Status in the rhythm report's vocabulary: only an onset-corrected grid is
// 'tracking'. Its spread: the phase's, from the coupler's own kappa (twice the mean
// absolute phase error in beats), read as a normal spread (1.25 x mean absolute error);
// and the period's, as far as the forecast reaches past the last onset heard (the
// mathematical audit's I08). The phase errors' drift over the window has a standard
// error of its own (a least-squares slope's, sd sqrt(12 / (n (n^2 - 1))) of the phase's
// over n errors; with fewer than three, as large as the phase's), which a beat k periods
// ahead multiplies by k. So a far forecast, or one from few onsets, is the less sure.
export function pulseFollowerForecast(state,{now,horizonSeconds=1}={}){
  if(state?.model!=='pulse-coupler-antescofo-v1'||!Number.isFinite(now))throw new TypeError('Invalid pulse follower forecast');
  const coupler=couplerOf(state);coupler.advance(now);
  const status=coupler.state==='tracking'?'tracking':coupler.state==='paused'?'ambiguous':coupler.state==='reset'?'stale':'initializing';
  const kappa=coupler.kappa(coupler.last??now),confidence=coupler.confidence(coupler.last??now);
  if(status!=='tracking'||coupler.expected===null)return {status,kappa,confidence,forecast:null};
  const target=now+horizonSeconds,expectedTime=coupler.expected+Math.max(0,Math.ceil((target-coupler.expected)/coupler.period-1e-12))*coupler.period;
  const phase=1.25*kappa*coupler.period/2,n=coupler.errors.length,period=n>=3?phase*Math.sqrt(12/(n*(n*n-1))):phase;
  const ahead=Math.max(0,(expectedTime-(coupler.last??now))/coupler.period);
  return {status,kappa,confidence,forecast:{expectedTime,periodSeconds:coupler.period,bpm:60/coupler.period,
    latentTimeVariance:phase*phase+(ahead*period)**2,conditionalOn:'pulse-coupler-grid'}};
}
