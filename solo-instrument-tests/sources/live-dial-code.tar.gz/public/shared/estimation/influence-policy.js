import {frozenJson, identifier, scope} from '../planning-data.js';
import {finite, EstimationError} from './linear-filter.js';

const reject = message => { throw new EstimationError('influence-policy', message); };
const freeze = value => frozenJson(value, {bytes: 16384, items: 2048}).data;
const clamp = (x, low, high) => Math.max(low, Math.min(high, x));

// This maps beliefs to ARTISTIC targets. It does not fuse their covariances,
// change observation noise, grant authority, or touch any transport/scheduler.
export function continuousInfluence({policy, beliefs, current, now, previousProposalAt, effectiveAt,
  decisionDeadline, expiresAt, proposalId, currentPlanRef = null, tempoMapRevision = 1}) {
  policy = freeze(policy); identifier(policy.botId); identifier(policy.version); identifier(policy.parameter); identifier(proposalId);
  const authorityScope = scope(policy.authorityScope);
  if (!['follow', 'lead', 'maintain', 'contrast'].includes(policy.mode)) reject('Unknown artistic response mode');
  if (!['hold', 'fallback'].includes(policy.unknownInputPolicy)) reject('An explicit missing-input policy is required');
  if (typeof policy.units !== 'string' || !policy.units.length) reject('Target units must be explicit');
  for (const [name, value] of Object.entries({current, now, previousProposalAt, effectiveAt, decisionDeadline, expiresAt})) finite(value, name);
  if (previousProposalAt > now || decisionDeadline < now || effectiveAt < decisionDeadline || expiresAt < effectiveAt) reject('Invalid proposal deadline or target interval');
  if (!Number.isInteger(tempoMapRevision) || tempoMapRevision < 1) reject('An existing tempo-map revision is required');
  const {minimum, maximum, maxRatePerSecond, gain, maxAgeSeconds} = policy;
  for (const [name, value] of Object.entries({minimum, maximum, maxRatePerSecond, gain, maxAgeSeconds})) finite(value, name);
  if (minimum > maximum || maxRatePerSecond < 0 || gain < 0 || gain > 1 || maxAgeSeconds <= 0) reject('Invalid influence bounds');
  if (current < minimum || current > maximum) reject('Current target is outside the configured range; both range and rate limits cannot be met');
  if (!Array.isArray(policy.sources) || policy.sources.length > 32 || !Array.isArray(beliefs) || beliefs.length > 64) reject('Influence source budget exceeded');
  const weights = new Map();
  for (const source of policy.sources) {
    identifier(source.sourceId); finite(source.artisticWeight, 'artistic weight');
    if (source.artisticWeight < 0 || source.artisticWeight > 1 || weights.has(source.sourceId)) reject('Invalid or duplicate artistic source weight');
    weights.set(source.sourceId, source.artisticWeight);
  }
  const eligible = new Map(), excluded = [];
  for (const input of beliefs) {
    const belief = freeze(input), weight = weights.get(belief.sourceId);
    if (weight === undefined || weight === 0) continue;
    identifier(belief.beliefId); identifier(belief.sourceIncarnation);
    for (const name of ['value', 'lastEvidenceAt', 'availableAt', 'receivedAt', 'revision']) finite(belief[name], name);
    if (!Number.isSafeInteger(belief.revision) || belief.revision < 1) reject('Invalid belief revision');
    const reason = belief.units !== policy.units ? 'incompatible-units' : belief.stateSchema !== policy.parameter ? 'incompatible-schema' :
      belief.possibleSelfOutput && policy.allowSelfOutput !== true ? 'possible-self-output' :
      belief.availableAt > now || belief.receivedAt > now || belief.lastEvidenceAt > now ? 'unavailable-evidence' :
      now - belief.lastEvidenceAt > maxAgeSeconds ? 'stale-evidence' : belief.trackingState !== 'tracking' ? 'unresolved-belief' :
      policy.requireCalibration === true && belief.calibrationStatus !== 'calibrated' ? 'uncalibrated-evidence' : null;
    if (reason) { excluded.push({beliefId: belief.beliefId, reason}); continue; }
    const old = eligible.get(belief.sourceId);
    if (old && old.belief.sourceIncarnation !== belief.sourceIncarnation) reject('Choose one current source incarnation before applying influence');
    if (old && old.belief.revision === belief.revision && frozenJson(old.belief).canonical !== frozenJson(belief).canonical) reject('Conflicting belief revision');
    if (!old || belief.revision > old.belief.revision) eligible.set(belief.sourceId, {belief, weight});
  }
  const selected = [...eligible.values()].sort((a, b) => a.belief.sourceId < b.belief.sourceId ? -1 : 1);
  const sumWeight = selected.reduce((sum, item) => sum + item.weight, 0);
  let desired = current, reason = 'maintain';
  if (policy.mode === 'lead') { desired = finite(policy.ownTarget, 'own target'); reason = 'configured-lead'; }
  else if (policy.mode !== 'maintain' && sumWeight > 0) {
    const musicalTarget = selected.reduce((sum, item) => sum + item.belief.value * item.weight, 0) / sumWeight;
    desired = current + gain * (policy.mode === 'contrast' ? current - musicalTarget : musicalTarget - current);
    reason = policy.mode;
  } else if (policy.mode !== 'maintain') {
    reason = 'unknown-hold';
    if (policy.unknownInputPolicy === 'fallback') { desired = finite(policy.fallback, 'fallback target'); reason = 'unknown-fallback'; }
  }
  const bounded = clamp(desired, minimum, maximum), delta = maxRatePerSecond * (now - previousProposalAt);
  const target = clamp(bounded, current - delta, current + delta);
  return freeze({version: 1, kind: 'influence-proposal', botId: policy.botId, policyVersion: policy.version, proposalId, authorityScope,
    basis: {beliefSnapshotRefs: selected.map(({belief}) => belief.beliefId),
      selectedSources: selected.map(({belief}) => ({sourceId: belief.sourceId, sourceIncarnation: belief.sourceIncarnation})),
      artisticWeights: selected.map(({belief, weight}) => ({sourceId: belief.sourceId, weight})), excluded},
    result: {parameter: policy.parameter, units: policy.units, target, effectiveInterval: {start: effectiveAt, end: expiresAt}},
    constraints: {minimum, maximum, maxRatePerSecond, decisionDeadline, requiredReadiness: true},
    lifecycle: {currentPlanRef, tempoMapRevision, expiry: expiresAt, unknownInputPolicy: policy.unknownInputPolicy},
    explanation: {reason, desired, rangeLimited: desired !== bounded, rateLimited: bounded !== target}, execution: 'proposal-only'});
}
