import {actor,actorKey,frozenJson,knownFields,scope} from '../planning-data.js';
import {InputReportClient} from './input-report.js';
import {FusedInputClient} from './input-fusion.js';
import {continuousInfluence} from './influence-policy.js';
import {OCTAVE_TOLERANCE,compoundGrid,compoundTactus,foldOctave,gridSpacing,octaveWithin} from './metrical-octave.js';
import {POCKET_SECONDS,SYNC_DEFAULTS,bassGroups,heldPeriod,reactivityOf} from './beat-sync.js';
import {PlacementEstimator,placedBeatStep} from './placement.js';
import {leanSeconds} from '../performance-timing.js';
import {SubdivisionEvidence} from './subdivision-evidence.js';
import {bandMeter,playableTempi} from '../opening-time.js';
import {tempoRange,unitsPerTempoBeat} from '../tempo-range.js';

export {OCTAVE_TOLERANCE,foldOctave};

const freeze=value=>frozenJson(value,{bytes:65536,items:8192}).data;
// A phase heard from a report, with the performer's placement where their input declares it, and the calibration their
// beat was mapped by (placement.js). A lean they declare adds its displacement at the band's place in the phrase: the
// third of the rubato report's three controls (§7.3: placement, tempo, and phrase-relative displacement), which a band
// correcting all asynchrony would erase while it chased it as tempo.
const reportedPlacement=(report,phase,cursor)=>{
  if(!phase)return phase;
  const placed=Number.isFinite(report.timing.placementSeconds)?report.timing.placementSeconds:null,lean=report.timing.lean;
  const leaned=lean?leanSeconds(lean,{phrasePosition:cursor?.phrasePosition??0,phase:0}):null,placement=leaned===null?placed:(placed??0)+leaned;
  return {...phase,calibrationVersion:report.timing.phase?.calibrationVersion??null,...(placement===null?{}:{placementSeconds:placement})};
};
// How much a performer's timing counts, by how closely they ask to be followed (input-report.js COORDINATIONS; the
// rubato report's §11: observations weighted by context): loosely, half as much, both for correcting the phase and
// for taking a change of tempo; released (a cadenza), not at all. The half is ours.
export const COORDINATION_WEIGHT=Object.freeze({tight:1,loose:.5,released:0});
const periodAt=(map,beat)=>map.periodAtBeat?.(beat)??60/map.bpm;
const referenceKey=clock=>JSON.stringify(clock.offer?.reference??null);
const retain=(list,value,limit)=>{list.push(value);if(list.length>limit)list.shift();};
const membershipKey=participants=>participants.map(actor).map(actorKey).sort().join('|');

export function tempoFollowingOptions(value={}) {
  knownFields(value,['gain','minimumBpm','maximumBpm','maxBpmPerSecond','transitionBeats','maxAgeSeconds','deadbandBpm',
    'alignPhase','maxPhaseAdjust','phaseDeadbandSeconds','maxPhaseUncertainty','foldOctaves','acquisitionGain','acquisitionThreshold',
    'placementSource',...Object.keys(SYNC_DEFAULTS)],'tempo following');
  // acquisitionGain (off by default): while the ensemble is more than
  // acquisitionThreshold (a fraction) from the performer's reading, move with this
  // gain instead, to target the performer's tempo rather than approach it by
  // halves. Near it, the configured gain makes the small corrections.
  // alignPhase on a local playing ensemble synchronizes it beat by beat (beat-sync.js), with SYNC_DEFAULTS'
  // phaseGain, slowBeatSeconds, linearPhaseRange, maxBeatChange, phaseWindow, anticipationSeconds and
  // acquireWhileQuiet.
  const options={gain:.5,minimumBpm:60,maximumBpm:180,maxBpmPerSecond:8,transitionBeats:4,maxAgeSeconds:3,deadbandBpm:.5,
    alignPhase:false,maxPhaseAdjust:.04,phaseDeadbandSeconds:.01,maxPhaseUncertainty:.1,foldOctaves:true,acquisitionGain:null,acquisitionThreshold:.08,
    // Where the performer's placement comes from (placement.js): 'given' (the report's own, else
    // performerPlacementSeconds) or 'measured' (the report's own, else the band listens before it corrects).
    placementSource:'given',
    ...SYNC_DEFAULTS,...value};
  const {gain,minimumBpm,maximumBpm,maxBpmPerSecond,transitionBeats,maxAgeSeconds,deadbandBpm,alignPhase,maxPhaseAdjust,
    phaseDeadbandSeconds,maxPhaseUncertainty}=options;
  if(options.acquisitionGain!==null&&!(options.acquisitionGain>0&&options.acquisitionGain<=1&&options.acquisitionThreshold>0&&options.acquisitionThreshold<1))
    throw new TypeError('Invalid tempo acquisition');
  if(!(options.phaseGain>0&&options.phaseGain<=1&&options.slowBeatSeconds>.5&&options.slowBeatSeconds<=4&&options.linearPhaseRange>0&&options.linearPhaseRange<=.5&&
    options.maxBeatChange>0&&options.maxBeatChange<=.25&&options.phaseWindow>0&&options.phaseWindow<=.5&&
    Math.abs(options.anticipationSeconds)<=.1&&Math.abs(options.entryAnticipationSeconds)<=.1&&Math.abs(options.performerPlacementSeconds)<=.1&&options.lagCorrection>=1&&options.lagCorrection<=2))
    throw new TypeError('Invalid beat synchronization');
  if(!(options.reactivity==='auto'||Number.isFinite(options.reactivity)&&options.reactivity>=0&&options.reactivity<=1)||
    !(options.changeTolerance>0&&options.changeTolerance<=.5)||!(Number.isInteger(options.maxChangeBeats)&&options.maxChangeBeats>=0&&options.maxChangeBeats<=128))
    throw new TypeError('Invalid reactivity');
  if(!(Number.isInteger(options.estimateBeats)&&options.estimateBeats>=0&&options.estimateBeats<=64))throw new TypeError('Invalid estimate hold');
  if(!(options.subdivisionAlarm>1))throw new TypeError('Invalid subdivision alarm');
  if(!Object.entries(options).every(([key,v])=>['alignPhase','foldOctaves','acquireWhileQuiet','followSubdivision','startsFromEstimate','alignToAttacks','groupByBass','correctPersistent'].includes(key)?typeof v==='boolean':key==='acquisitionGain'&&v===null||key==='reactivity'||key==='placementSource'&&['given','measured'].includes(v)||key==='subdivisionEvidence'&&['sequential','hold'].includes(v)||Number.isFinite(v))||gain<=0||gain>1||minimumBpm<20||maximumBpm>300||minimumBpm>=maximumBpm||
    maxBpmPerSecond<=0||maxBpmPerSecond>30||!Number.isInteger(transitionBeats)||transitionBeats<1||transitionBeats>128||
    maxAgeSeconds<=0||maxAgeSeconds>3||deadbandBpm<.1||deadbandBpm>10||!(maxPhaseAdjust>0&&maxPhaseAdjust<=.1)||
    !(phaseDeadbandSeconds>=0&&phaseDeadbandSeconds<=.1)||!(maxPhaseUncertainty>0&&maxPhaseUncertainty<=.5)||typeof alignPhase!=='boolean')
    throw new TypeError('Invalid tempo following bounds');
  return freeze(options);
}

// A playing ensemble's following in its clock's own notes a minute (its cursor's bpm: a seeded 20/12's twelfths). Its
// bounds, deadband and rate are named in the beat its meter's tempo counts (tempo-range.js unitsPerTempoBeat: a 20/12's
// quarter, three twelfths); its bounds, where none is given, that beat's 60-180 widened to the tempi its meter is played
// at (opening-time.js playableTempi), which its opening is drawn from, within its clock's (tempoRange). At 60-180 in the
// clock's notes, a band opening its seeded 20/12 at 548 twelfths a minute (a quarter of 183) refused to follow anyone,
// and a seeded 32/8 at a quarter of 714 could be followed in no named window; on the meter's playable tempi alone, a
// performer at 80 eighths a minute in 7/8 was folded an octave up, under its 84. Beat counts stay its pulses'. Fixed
// as the following starts.
function inClockNotes(config,given,meter){
  const units=unitsPerTempoBeat(meter),[low,high]=playableTempi(meter),[lowest,highest]=tempoRange(meter);
  return freeze({...config,
    minimumBpm:given.minimumBpm===undefined?Math.max(lowest,Math.min(config.minimumBpm*units,low)):config.minimumBpm*units,
    maximumBpm:given.maximumBpm===undefined?Math.min(highest,Math.max(config.maximumBpm*units,high)):config.maximumBpm*units,
    deadbandBpm:config.deadbandBpm*units,maxBpmPerSecond:config.maxBpmPerSecond*units});
}

// A future tempo path that also lands the ensemble's beat on the performer's. A
// period ramp over D beats lasts D(p0+p1)/2 seconds; passing through an
// intermediate period at half way adds exactly the chosen phase shift. The detour
// is bounded (maxPhaseAdjust of the target period) and so is its tempo rate;
// whatever remains is corrected at the next window. beatAt is the ensemble time
// the performer's beat aligns with (their onset less the loopback round trip).
export function phaseCorrection({beatAt,varianceSeconds2,performerPeriod,fromPeriod,toPeriod,effectiveAt,durationBeats,
  maxPhaseAdjust,phaseDeadbandSeconds,maxPhaseUncertainty,maxBpmPerSecond}) {
  const sd=Math.sqrt(varianceSeconds2);
  if(!(performerPeriod>0)||!(sd<=maxPhaseUncertainty*performerPeriod))return {applied:false,reason:'phase-too-uncertain',sdSeconds:sd};
  const rate=(a,b,beats)=>60*Math.abs(b-a)/(beats*Math.min(a,b)**3);
  for(let beats=durationBeats+durationBeats%2;beats<=128;beats*=2){
    const end=effectiveAt+beats*(fromPeriod+toPeriod)/2,error=beatAt+Math.round((end-beatAt)/performerPeriod)*performerPeriod-end;
    if(Math.abs(error)<phaseDeadbandSeconds)return {applied:false,reason:'within-phase-deadband',errorSeconds:error};
    const limit=maxPhaseAdjust*toPeriod*beats/2,shift=Math.max(-limit,Math.min(limit,error)),midPeriod=(fromPeriod+toPeriod)/2+2*shift/beats;
    if(Math.max(rate(fromPeriod,midPeriod,beats/2),rate(midPeriod,toPeriod,beats/2))<=maxBpmPerSecond+1e-9)
      return {applied:true,errorSeconds:error,appliedSeconds:shift,residualSeconds:error-shift,midPeriod,durationBeats:beats};
  }
  return {applied:false,reason:'phase-correction-exceeds-rate'};
}

// Why a report cannot steer the tempo, or null when it can.
function evidenceProblem(report,timingAge,config) {
  return !report?'missing-input':report.coverage!=='complete'?'missing-source-coverage':
    report.possibleSelfOutput||report.role==='mixture'?'possible-self-output':
    report.timing?.state!=='tracking'?'unresolved-pulse':timingAge===null||timingAge>config.maxAgeSeconds?'stale-evidence':null;
}

// An opt-in policy owned by the existing reference conductor. Reports supply
// durations, not a new clock or authority. Receipt only updates evidence; the
// maintenance pump seals a future decision before using the existing ensemble
// curve or scheduled-clip map acceptance path. No musical event executes here.
export class TempoInfluenceController {
  constructor({identity,clock,ensemble=null,send,ready=()=>true,members=()=>[identity],onChange=()=>{},scopeMode='shared'}) {
    if(!['shared','local'].includes(scopeMode))throw new TypeError('Invalid tempo authority scope');
    this.identity=actor(identity);Object.assign(this,{clock,ensemble,send,ready,members,onChange,scopeMode});
    this.enabled=false;this.state='disabled';this.reason=null;this.sequence=0;
    this.history=[];this.decisions=[];this.pending=null;
  }
  now() {try{return this.clock.status().ready?this.clock.referenceTime():null;}catch{return null;}}
  // `sources` (two or more): follow them together, their reports fused (input-fusion.js: a common event counted once,
  // estimates of one performer by covariance intersection, independent performers' tightening each other).
  enable({source,sources=null,fusion={},options={},destination='clips'}) {
    const clock=this.clock,now=this.now(),meter=destination==='ensemble'?this.ensemble?.cursor?.meter:null,
      config=meter?inClockNotes(tempoFollowingOptions(options),options,meter):tempoFollowingOptions(options);
    this.followedPeriod=null;this.changePending=null;this.bandBeats=[];this.subdivisionEvidence=null;this.grouping=null;this.bassGroups=null;
    this.subdivisionSequence=config.subdivisionEvidence==='sequential'?new SubdivisionEvidence({alarm:config.subdivisionAlarm}):null;this.subdivisionReading=null;
    if(!['ensemble','clips'].includes(destination))throw new Error('Choose ensemble or scheduled clips for tempo following');
    if(!clock.isReference||!Number.isFinite(now)||destination==='clips'&&(!clock.timeline||clock.offer.stopBeat!==null)||
      destination==='ensemble'&&(!this.ensemble?.cursor||this.ensemble.primary!==this.ensemble.host||!this.ensemble.active()))
      throw new Error('Start the primary conductor timeline before following an input');
    const [lowest,highest]=meter?tempoRange(meter):[];
    if(destination==='ensemble'&&(config.minimumBpm<lowest-1e-9||config.maximumBpm>highest+1e-9))
      throw new Error(`Playing-ensemble bounds must stay within the meter's ${lowest}–${highest} BPM`);
    const current=destination==='ensemble'?this.ensemble.cursor.bpm:
      60/periodAt(clock.timeline,Math.max(clock.timeline.originBeat,clock.timeline.beatAtReference(now)));
    if(current<config.minimumBpm||current>config.maximumBpm)throw new Error('Current tempo is outside the following bounds');
    this.makeInput=Array.isArray(sources)&&sources.length>1?()=>new FusedInputClient({identity:this.identity,sources,send:this.send,now:()=>this.now(),fusion})
      :()=>new InputReportClient({identity:this.identity,source,send:this.send,now:()=>this.now()});
    const input=this.makeInput();
    this.input=input;this.config=config;this.destination=destination;this.reference=referenceKey(clock);this.enabled=true;
    this.history=[];this.pending=null;this.lastDecision=null;this.nextWindowAfter=now;this.previousProposalAt=now;this.followed=[];
    // A local playing ensemble that can be steered beat by beat is synchronized instead of following in windows.
    this.syncing=destination==='ensemble'&&config.alignPhase&&typeof this.ensemble?.beatCursor==='function'&&typeof this.ensemble?.steerBeat==='function';
    this.steered=null;
    // A placement measured by listening first (placement.js), for a playing ensemble synchronized beat by beat.
    this.placement=this.syncing&&config.placementSource==='measured'?new PlacementEstimator():null;
    this.setState('waiting','collecting-input');return this.status();
  }
  disable(reason='operator-disengaged') {
    this.enabled=false;this.input=null;this.pending=null;this.history=[];this.setState('disabled',reason);
    return this.status();
  }
  setState(state,reason=null) {
    if(this.state===state&&this.reason===reason)return;
    this.state=state;this.reason=reason;this.onChange();
  }
  receive(message) {
    if(!this.enabled||!this.ready()||message.address!=='/agent/estimation/response')return false;
    try{
      if(!this.input.receive(message))return false;
      // Retain receipt-time ages; future cutoffs may exclude a newer reply.
      retain(this.history,this.input.snapshot(),32);return true;
    }catch{return false;}
  }
  openWindow(now) {
    let map,atBeat,effectiveAt,current,referencePulse,boundary=null;
    // Reserve collection time for the recently measured request/response
    // trip plus one query interval. A slow reply can inform the next window;
    // it never moves a sealed cutoff or becomes fresh by changing this lead.
    const replySeconds=Math.max(0,...this.history.map(value=>value.receivedAt-value.sentAt));
    const leadSeconds=Math.max(3,2.5+replySeconds+.25);
    if(this.destination==='ensemble'){
      let prepared;
      try{prepared=this.ensemble.prepareTempoInfluence(now,leadSeconds);}catch(error){this.nextWindowAfter=now+1;this.setState('holding',error.message);return;}
      if(!prepared){this.nextWindowAfter=now+.1;this.setState('holding','existing-ensemble-change');return;}
      ({map,boundary}=prepared);atBeat=boundary.beat;effectiveAt=boundary.at;current=boundary.bpm;
      referencePulse={numerator:1,denominator:boundary.meter.denominator};
    }else{
      map=this.clock.timeline;const lastEnd=map.segments?.at(-1).startBeat??map.originBeat;
      atBeat=Math.ceil(Math.max(map.originBeat+map.beatsPerBar,lastEnd,map.beatAtReference(now+leadSeconds))/map.beatsPerBar)*map.beatsPerBar;
      effectiveAt=map.referenceAtBeat(atBeat);current=60/periodAt(map,atBeat);referencePulse={numerator:1,denominator:4};
    }
    const id=`tempo-follow:${++this.sequence}`;
    const participants=this.members().map(actor);
    this.pending={id,map,boundary,current,referencePulse,atBeat,effectiveAt,cutoff:effectiveAt-2.5,deadline:effectiveAt-2,
      scope:scope({mode:this.scopeMode,membershipId:`${map.epoch}:${id}`,participants})};
    this.setState('collecting');this.onChange();
  }
  // The report's beat phase, when it can be trusted here: a calibrated input in
  // session seconds (this conductor's reference time), converted to this pulse.
  alignment({report,window,from,to,durationBeats,config}) {
    const phase=report.timing?.phase;
    if(!phase)return {applied:false,reason:report.timing?.phaseStatus||'no-phase'};
    if(report.clock?.domain!=='session-seconds')return {applied:false,reason:'unmapped-clock'};
    const unit=window.referencePulse,pulse=report.timing.referencePulse;
    return phaseCorrection({beatAt:phase.beatAt,varianceSeconds2:phase.varianceSeconds2,
      performerPeriod:phase.periodSeconds*unit.numerator*pulse.denominator/(unit.denominator*pulse.numerator),
      fromPeriod:from,toPeriod:to,effectiveAt:window.effectiveAt,durationBeats,maxPhaseAdjust:config.maxPhaseAdjust,
      phaseDeadbandSeconds:config.phaseDeadbandSeconds,maxPhaseUncertainty:config.maxPhaseUncertainty,maxBpmPerSecond:config.maxBpmPerSecond});
  }
  sameTiming(window){return this.destination==='ensemble'?this.ensemble.acceptsTempoBasis(window.map):this.clock.timeline===window.map;}
  decide(now) {
    const window=this.pending,clock=this.clock,config=this.config;
    this.pending=null;this.nextWindowAfter=window.effectiveAt;
    const evidence=this.history.findLast(value=>value.receivedAt<=window.cutoff)??null,report=evidence?.report;
    const timingAge=evidence?.timingAgeSeconds==null?null:evidence.timingAgeSeconds+now-evidence.receivedAt;
    let reason=now>window.deadline?'missed-selection-deadline':!this.sameTiming(window)?'tempo-map-changed':
      membershipKey(this.members())!==membershipKey(window.scope.participants)?'membership-changed':evidenceProblem(report,timingAge,config);
    let proposal=null,accepted=null;
    if(!reason){
      try{
        const unit=window.referencePulse,parameter=this.destination==='ensemble'?'metrical-pulse-tempo':'quarter-tempo',
          units=this.destination==='ensemble'?`1/${unit.denominator}-notes-per-minute`:'quarter-notes-per-minute';
        const current=window.current,pulse=report.timing.referencePulse;
        // In this window's unit: seconds of its reference note.
        const heard=report.timing.periodSeconds*unit.numerator*pulse.denominator/(unit.denominator*pulse.numerator);
        const toWindow=value=>value.periodSeconds*unit.numerator*value.denominator/(unit.denominator*value.numerator);
        const within=value=>octaveWithin(value,{shortest:60/config.maximumBpm,longest:60/config.minimumBpm,near:60/current});
        const period=config.foldOctaves?within(foldOctave(heard,this.followed.map(toWindow).reverse())):heard,folded=Math.abs(period/heard-1)>1e-9;
        // Recent readings, in their own reference unit, since a metre change can change the window's.
        retain(this.followed,{periodSeconds:period*unit.denominator*pulse.numerator/(unit.numerator*pulse.denominator),
          numerator:pulse.numerator,denominator:pulse.denominator},4);
        proposal=continuousInfluence({policy:{botId:this.identity.id,version:this.destination==='ensemble'?'conductor-ensemble-tempo-follow-v1':'conductor-tempo-follow-v1',
          authorityScope:window.scope,parameter,units,referencePulse:unit,mode:'follow',unknownInputPolicy:'hold',
          gain:config.acquisitionGain!==null&&Math.abs(60/period/current-1)>config.acquisitionThreshold?config.acquisitionGain:config.gain,
          minimum:config.minimumBpm,maximum:config.maximumBpm,maxRatePerSecond:config.maxBpmPerSecond,
          maxAgeSeconds:config.maxAgeSeconds,sources:[{sourceId:report.sourceId,artisticWeight:1}]},
          beliefs:[{beliefId:report.reportId,sourceId:report.sourceId,sourceIncarnation:report.sourceIncarnation,revision:Math.max(1,report.sequence),
            stateSchema:parameter,units,value:60/period,
            lastEvidenceAt:now-timingAge,availableAt:evidence.receivedAt,receivedAt:evidence.receivedAt,trackingState:'tracking',
            possibleSelfOutput:report.possibleSelfOutput,calibrationStatus:report.clock.calibrationStatus}],
          current,now,previousProposalAt:this.previousProposalAt,effectiveAt:window.effectiveAt,decisionDeadline:window.deadline,
          expiresAt:window.effectiveAt+1,proposalId:window.id,tempoMapRevision:window.map.revision});
        const proposed=proposal.result.target,settled=Math.abs(proposed-current)<config.deadbandBpm;
        // Within the tempo deadband the tempo stays; a calibrated phase error can
        // still be corrected there, as a detour that returns to the same tempo.
        const target=settled?current:proposed;
        // Maps ramp period over beats. Bound physical BPM acceleration too:
        // |d(BPM)/dt| = 60*|deltaPeriod|/(beats*period^3).
        const from=60/current,to=60/target;
        let durationBeats=Math.max(config.transitionBeats,Math.ceil(60*Math.abs(to-from)/(config.maxBpmPerSecond*Math.min(from,to)**3)));
        // A folded reading's phase is at the other level, and cannot say which of its beats is the ensemble's.
        const phase=config.alignPhase?this.destination==='ensemble'?{applied:false,reason:'phase-alignment-needs-scheduled-clips'}:
          folded?{applied:false,reason:'phase-at-another-level'}:this.alignment({report,window,from,to,durationBeats,config}):null;
        if(settled&&!phase?.applied)reason='within-tempo-deadband';
        else if(this.destination==='ensemble'){
          accepted=this.ensemble.acceptTempoInfluence({map:window.map,boundary:window.boundary,bpm:target,
            transitionBeats:config.transitionBeats,maxBpmPerSecond:config.maxBpmPerSecond,decisionId:window.id});
        }else{
          if(durationBeats>128)throw new Error('Tempo response exceeds the transition budget');
          if(phase?.applied){
            durationBeats=phase.durationBeats;
            clock.scheduleTempoPath([{bpm:60/phase.midPeriod,atBeat:window.atBeat,durationBeats:durationBeats/2},
              {bpm:target,atBeat:window.atBeat+durationBeats/2,durationBeats:durationBeats/2}]);
          }else clock.scheduleTempo({bpm:target,atBeat:window.atBeat,durationBeats});
          accepted={tempoId:clock.timeline.id,tempoRevision:clock.timeline.revision,bpm:target,atBeat:window.atBeat,durationBeats,
            completesAt:clock.timeline.referenceAtBeat(window.atBeat+durationBeats),...(phase?{phase}:{})};
        }
        if(accepted){this.nextWindowAfter=accepted.completesAt;this.previousProposalAt=now;}
      }catch(error){reason=error.message;}
    }
    const decision=freeze({version:1,decisionId:window.id,authority:this.identity,sessionId:window.map.sessionId,epoch:window.map.epoch,
      cutoff:window.cutoff,decidedAt:now,effectiveAt:window.effectiveAt,source:this.input.source,
      destination:this.destination,referencePulse:window.referencePulse,
      timingBasis:this.destination==='ensemble'?window.map.snapshot():{tempoId:window.map.id,tempoRevision:window.map.revision},
      status:accepted?'accepted':'held',reason,evidence,proposal,accepted});
    retain(this.decisions,decision,16);this.lastDecision=decision;
    this.setState(accepted?'following':'holding',reason);this.onChange();
  }
  pump() {
    if(!this.enabled)return;
    if(!this.clock.isReference||referenceKey(this.clock)!==this.reference)return this.disable('reference-changed');
    if(this.destination==='clips'&&this.clock.offer.stopBeat!==null)return this.disable('shared-stop');
    const now=this.now();
    if(!Number.isFinite(now)||!this.ready()){
      if(this.state!=='holding'||this.reason!=='clock-or-connection-unavailable'){
        this.input=this.makeInput();
        this.pending=null;this.history=[];this.setState('holding','clock-or-connection-unavailable');
      }
      return;
    }
    // Synchronizing, the pump only keeps the evidence fresh; beforePulse() steers.
    if(this.syncing){this.input.query();return;}
    if(this.pending&&!this.sameTiming(this.pending)){this.pending=null;this.setState('holding','tempo-map-changed');}
    if(this.pending&&now>=this.pending.cutoff)this.decide(now);
    if(!this.pending&&now>=this.nextWindowAfter)this.openWindow(now);
    // No new decision can be made during an already accepted ramp. Avoid
    // polling its source across the relay until the next collection window.
    if(this.pending)this.input.query();
  }
  // Beat synchronization's step, run just before the ensemble works out a pulse's tempo: on a beat pulse, the tempo
  // of the coming beat, from the freshest report (beat-sync.js). Returns the tempo it set, or null.
  beforePulse() {
    if(!this.enabled||!this.syncing||!this.ready())return null;
    const now=this.now(),cursor=this.ensemble.beatCursor();
    if(!Number.isFinite(now)||!cursor)return null;
    // A pulse worked out again (a message replaced its curve) keeps the tempo already chosen for it.
    if(cursor.tick===this.steered?.tick)return this.steered.bpm===null?null:this.ensemble.steerBeat(this.steered.bpm);
    if(!cursor.isBeat)return null;
    const config=this.config,evidence=this.history.at(-1)??null,report=evidence?.report;
    const timingAge=evidence?.timingAgeSeconds==null?null:evidence.timingAgeSeconds+now-evidence.receivedAt;
    let reason=cursor.free?evidenceProblem(report,timingAge,config):'existing-ensemble-change',step=null;
    // A composed curve moves the band's time: afterwards the performer's is taken afresh.
    if(reason==='existing-ensemble-change'){this.followedPeriod=null;this.changePending=null;}
    // Released from coordination: the band keeps its own time, and takes nothing of the performer's, until they return.
    if(!reason&&report.timing.coordination==='released'){
      step={...placedBeatStep({estimator:null,cursor,base:this.steered?.base??null,persistent:null,period:this.steered?.base??cursor.beatSeconds,phase:null,config}),
        reactivity:null,freeness:null,reason:'released'};
      this.ensemble.steerBeat(step.bpm);
    }else if(!reason){
      const weight=COORDINATION_WEIGHT[report.timing.coordination]??1,stepConfig=weight===1?config:{...config,phaseGain:config.phaseGain*weight};
      const unit=cursor.referencePulse,pulse=report.timing.referencePulse;
      // In the ensemble's beat unit: seconds of its reference note.
      const toUnit=seconds=>seconds*unit.numerator*pulse.denominator/(unit.denominator*pulse.numerator);
      const toBeat=value=>value.periodSeconds*unit.numerator*value.denominator/(unit.denominator*value.numerator);
      // A band starting from an estimate has followed it already: it is the first reference to fold toward.
      if(config.startsFromEstimate&&!(this.followedPeriod>0)){this.followedPeriod=cursor.beatSeconds;
        this.followed=[{periodSeconds:cursor.beatSeconds,numerator:unit.numerator,denominator:unit.denominator}];}
      // Folded to a level followed recently, then into the following bounds by octaves, and only then remembered.
      // A band counting a compound meter takes a pulse of one, two, four or eight of its eighths as its tactus
      // (metrical-octave.js compoundTactus): a forewarned 12/8 is heard in threes.
      const heard=toUnit(report.timing.periodSeconds),folded=config.foldOctaves?foldOctave(heard,this.followed.map(toBeat).reverse()):heard;
      const bounds={shortest:60/config.maximumBpm,longest:60/config.minimumBpm,near:cursor.beatSeconds};
      const octaved=config.foldOctaves?octaveWithin(folded,bounds):folded;
      // A band that starts from an estimate trusts its tempo in any meter: a pulse of two thirds of its beat is two of
      // the beat's thirds, and the attacks on its beats then say whether the beat divides in three.
      const tactus=config.foldOctaves&&(cursor.subdivision%3===0||config.startsFromEstimate)?compoundTactus(octaved,cursor.beatSeconds):null;
      const period=tactus===null?octaved:octaveWithin(tactus,bounds);
      retain(this.followed,{periodSeconds:period*unit.denominator*pulse.numerator/(unit.numerator*pulse.denominator),numerator:pulse.numerator,denominator:pulse.denominator},4);
      // With the age of its evidence, which discounts a correction made on it (beat-sync.js beatStep).
      const heardPhase=report.timing.phase&&report.clock?.domain==='session-seconds'?{beatAt:report.timing.phase.beatAt,
        periodSeconds:toUnit(report.timing.phase.periodSeconds),varianceSeconds2:report.timing.phase.varianceSeconds2,
        ...(Number.isFinite(timingAge)?{ageSeconds:timingAge}:{})}:null;
      // A band that trusts its own meter finds the performer's phase in their attacks (attackPhase).
      const aligned=config.startsFromEstimate&&config.alignToAttacks?this.attackPhase(report,cursor,now)??heardPhase:heardPhase;
      const phase=reportedPlacement(report,config.groupByBass?this.bassGrouping(report,aligned,cursor,now):aligned,cursor);
      // The tempo path continues from the last steered beat; after a pause it starts again from the beat as it is.
      // A sounding band takes a change of tempo as readily as its reactivity says (beat-sync.js heldPeriod).
      // A change is judged against the tempo the band has taken as the performer's (followedPeriod), not its path
      // toward it: a band still ramping from the room's tempo is not holding a time of its own.
      const acquiring=Boolean(config.acquireWhileQuiet&&cursor.quiet)||!(this.followedPeriod>0),own=reactivityOf(this.decisions,config),freeness=own.freeness;
      const reactivity=own.reactivity*weight;
      const held=heldPeriod({period,current:this.followedPeriod??null,pending:this.changePending??null,reactivity,acquiring,config});
      this.changePending=held.pending;this.followedPeriod=held.period;
      step={...placedBeatStep({estimator:this.placement,cursor,base:this.steered?.base??null,persistent:this.steered?.persistent??null,period:held.period,phase:held.waiting?null:phase,config:stepConfig}),
        reactivity,freeness,...(held.waiting?{waitingChange:held.pending}:{})};
      if(held.waiting)step.reason='holding-own-time';
      this.ensemble.steerBeat(step.bpm);
      // The band's own beats hold the performer's pulse at its level, or its eighths in a compound band: there the
      // performer's attacks on them say how its beat divides. Only the conductor's reading of them does, in a compound
      // band: the listener's own is of its pulse of two eighths, not the band's beat.
      // A band waiting on a tempo it has not taken plays at another tempo than the performer's: the thirds of their
      // beat fall near the quarters of its own. A band told 12/8 at 10% too fast counted them as twos, and left 12/8.
      if(config.followSubdivision&&!held.waiting){const sameLevel=Math.abs(period/heard-1)<1e-9,aligned=sameLevel||tactus!==null;
        this.placeAttacks(report,aligned,now);this.followSubdivision(report,cursor,aligned,now,{ownReadingOnly:tactus!==null});}
    }else if(config.startsFromEstimate&&config.alignToAttacks&&report&&(reason==='unresolved-pulse'||reason==='stale-evidence')){
      // A band that trusts its own meter keeps its own time where the listener resolves no pulse, aligned to the
      // performer's attacks: on GuitarSet's 12/8 the listener resolved none for seconds on end, and a band that held
      // meanwhile drifted off the guitarist.
      const phase=reportedPlacement(report,this.attackPhase(report,cursor,now),cursor);
      if(phase){
        step={...placedBeatStep({estimator:this.placement,cursor,base:this.steered?.base??null,persistent:this.steered?.persistent??null,period:this.followedPeriod??cursor.beatSeconds,phase,config}),reactivity:null,freeness:null,ownTime:reason};
        this.ensemble.steerBeat(step.bpm);reason=null;
        if(config.followSubdivision){this.placeAttacks(report,true,now);this.followSubdivision(report,cursor,true,now,{ownReadingOnly:true});}
      }
    }
    // The band's own beats, where they sound and whether in the performer's phase: the grid the performer's attacks
    // are placed on to tell how they divide the beat (placeAttacks).
    // A band placing a performer holds their tempo and its own phase, as one keeping their placement does, and is in
    // their phase while they are within the pocket.
    if(step)retain(this.bandBeats??=[],{at:cursor.soundAt,period:step.interval,
      inPhase:step.reason==null||step.reason==='within-phase-deadband'||step.reason==='placing'&&Math.abs(step.asynchrony)<=POCKET_SECONDS},64);
    this.steered={tick:cursor.tick,bpm:step?.bpm??null,base:step?.base??null,persistent:step?.persistent??null};
    const decision=freeze({version:1,decisionId:`beat-sync:${this.sequence}:${cursor.tick}`,decidedAt:now,tick:cursor.tick,soundAt:cursor.soundAt,
      source:this.input.source,destination:this.destination,status:step?'accepted':'held',reason:reason??step.reason,
      evidence:report?{reportId:report.reportId,timingAgeSeconds:timingAge}:null,
      accepted:step?{bpm:step.bpm,targetBpm:60/step.target,asynchronySeconds:step.asynchrony,corrected:step.corrected,mode:step.mode,
        reactivity:step.reactivity,freeness:step.freeness,...(step.waitingChange?{waitingChange:{bpm:60/step.waitingChange.period,
          beats:step.waitingChange.beats,required:step.waitingChange.required}}:{})}:null});
    retain(this.decisions,decision,64);this.lastDecision=decision;
    this.setState(step?step.mode:'holding',reason??step.reason);
    return step?.bpm??null;
  }
  // Where the performer's beat is, from their attacks, for a band that trusts its own meter (startsFromEstimate): as a
  // drummer finds a guitarist's beat in the strums, with the tempo and meter already in mind. The listener's beat
  // phase is often missing there: on GuitarSet's 12/8 its level flickers, and a band that waited for it held its
  // own time and drifted.
  // - The grid is the band's eighths: a third of its beat in a compound meter, a half in a simple one, counted from
  //   the beat it is about to play.
  // - The fine phase is where the attacks of the last four beats fall on that grid (their circular mean).
  // - The grouping is where the bass falls: which of the grid's positions in a beat carries the most of the attacks'
  //   bass (lowRise) over the last 12 s. Low sounds carry the beat (Hove et al. 2014; Lenc et al. 2018). A position
  //   other than the beat's own, with 1.5 times its bass over eight attacks or more, moves the band's beat there. A
  //   quiet band moves at once. A playing band needs twice the bass and sixteen attacks, and then moves in one beat,
  //   rather than sliding across its bar.
  // Returns a phase for beatStep ({beatAt, periodSeconds, varianceSeconds2, jump?}), or null.
  attackPhase(report,cursor,now) {
    const attacks=report?.timing?.subdivision?.attacks,bass=report?.timing?.subdivision?.bass;
    if(!Array.isArray(attacks)||!(cursor.beatSeconds>0)||!Number.isFinite(cursor.soundAt))return null;
    const parts=cursor.subdivision%3===0?3:2,beat=cursor.beatSeconds,step=beat/parts,from=cursor.soundAt-4*beat;
    let grouping=this.grouping;
    if(grouping?.parts!==parts)grouping=this.grouping={parts,bass:Array(parts).fill(0),count:0,at:now,last:-Infinity};
    const decay=.5**(Math.max(0,now-grouping.at)/12);grouping.bass=grouping.bass.map(value=>value*decay);grouping.count*=decay;grouping.at=now;
    let cos=0,sin=0,n=0;
    attacks.forEach((time,i)=>{
      if(!(time>=from&&time<=now))return;
      const units=(time-cursor.soundAt)/step,index=Math.round(units),angle=2*Math.PI*(units-index);
      cos+=Math.cos(angle);sin+=Math.sin(angle);n++;
      if(time>grouping.last){grouping.last=time;grouping.bass[((index%parts)+parts)%parts]+=Number.isFinite(bass?.[i])?bass[i]:0;grouping.count++;}
    });
    const resultant=n?Math.max(0,Math.min(1,Math.hypot(cos,sin)/n)):0;
    if(n<4||resultant<.5)return null;
    const offset=Math.atan2(sin,cos)/(2*Math.PI)*step,spread=step/(2*Math.PI)*Math.sqrt(-2*Math.log(resultant));
    const quiet=Boolean(cursor.quiet),ratio=quiet?1.5:3,needed=quiet?8:16;
    const top=grouping.bass.indexOf(Math.max(...grouping.bass));
    if(top>0&&grouping.count>=needed&&grouping.bass[top]>=ratio*Math.max(grouping.bass[0],1e-12)){
      this.grouping={parts,bass:Array(parts).fill(0),count:0,at:now,last:grouping.last};
      return {beatAt:cursor.soundAt+offset+top*step,periodSeconds:beat,varianceSeconds2:spread**2/n,jump:true};
    }
    return {beatAt:cursor.soundAt+offset,periodSeconds:step,varianceSeconds2:spread**2/n};
  }
  // The phase a band grouping its beat by the bass aligns to (groupByBass, beat-sync.js bassGroups). Its first alignment
  // takes the listener's beat as it is. After that the listener's phase aligns the band on the grid of its beat's
  // divisions, so the band keeps the position it has, and a listener flipping between the beat and the "and" no
  // longer pulls it along; where the bass says so, the band moves its beat, in one beat.
  bassGrouping(report,phase,cursor,now) {
    if(!phase||!(cursor.beatSeconds>0)||!Number.isFinite(cursor.soundAt))return phase;
    const beat=cursor.beatSeconds,parts=cursor.subdivision%3===0?3:2,step=beat/parts;
    const grid=gridSpacing(phase.periodSeconds,beat)??(cursor.subdivision%3===0||this.config.startsFromEstimate?compoundGrid(phase.periodSeconds,beat):null);
    if(!grid)return phase;
    const fine=grid<step*1.5?grid:step,first=!this.bassGroups;
    const {state,move}=bassGroups(this.bassGroups,{attacks:report?.timing?.subdivision?.attacks,bass:report?.timing?.subdivision?.bass,
      soundAt:cursor.soundAt,beatSeconds:beat,parts,now,quiet:Boolean(cursor.quiet)});
    this.bassGroups=state;
    if(first)return phase;
    if(move){const target=cursor.soundAt+move*step;
      return {beatAt:phase.beatAt+Math.round((target-phase.beatAt)/fine)*fine,periodSeconds:beat,varianceSeconds2:phase.varianceSeconds2,jump:true};}
    return {...phase,periodSeconds:fine};
  }
  // The performer's subdivision of the beat the ensemble follows: in threes (triplets, swing, 12/8) or straight. Once
  // the same reading has held for four seconds, and the ensemble's beat is the performer's own (no octave folded
  // between them), a subdivision the ensemble does not have is proposed for the next bar.
  // A window with too few attacks to tell is no evidence either way: it keeps the reading that is holding, and only
  // the contrary reading starts the four seconds again.
  // The performer's attacks on the band's own beats, once the band plays in the performer's phase at their beat. A
  // listener reads its own beat forecast, which a swing take flips between the beat, its half and a 4:3 by turns.
  // The band's beat, locked to the performer, holds still. Each attack goes to the nearest position in its beat, as
  // in subdivision.js: thirds and sixths for threes, halves and quarters for twos, none on the beat. The counts
  // forget with a 12-s half-life.
  placeAttacks(report,sameLevel,now) {
    const attacks=report?.timing?.subdivision?.attacks,beats=this.bandBeats??[];
    if(!Array.isArray(attacks)||!sameLevel||!Number.isFinite(now))return;
    const evidence=this.subdivisionEvidence??={triple:0,duple:0,at:now,last:-Infinity},decay=.5**(Math.max(0,now-evidence.at)/12);
    evidence.triple*=decay;evidence.duple*=decay;evidence.at=now;
    const near=(phase,positions)=>Math.min(...positions.map(position=>Math.abs(phase-position)));
    for(const time of attacks){
      if(!(time>evidence.last))continue;
      evidence.last=time;
      let k=beats.length-1;while(k>=0&&beats[k].at>time)k--;
      if(k<0||!beats[k].inPhase)continue;
      const phase=(time-beats[k].at)/beats[k].period;
      if(!(phase>=0&&phase<1))continue;
      // Weighed attack by attack across the session, every attack (on the beat too): a reading once its evidence is
      // enough (subdivision-evidence.js).
      const read=this.subdivisionSequence?.observe(phase)??null;if(read!==null)this.subdivisionReading={parts:read,at:time};
      const duple=near(phase,[1/4,1/2,3/4]),triple=near(phase,[1/6,1/3,2/3,5/6]);
      if(Math.min(phase,1-phase)<=Math.min(duple,triple))continue;
      if(triple<duple)evidence.triple++;else evidence.duple++;
    }
  }
  // The conductor's reading, where it has one: threes or twos. Sequential (the default): the last reading its evidence
  // reached and no proposal has used. Held: over six attacks at least and by 2.5 to 1.
  subdivisionEstimate() {
    if(this.subdivisionSequence)return this.subdivisionReading?.parts??null;
    const {triple=0,duple=0}=this.subdivisionEvidence??{};
    return triple>=6&&triple>=2.5*duple?3:duple>=6&&duple>=2.5*triple?2:null;
  }
  followSubdivision(report,cursor,sameLevel,now,{ownReadingOnly=false}={}) {
    // Sequential: a reading proposes once, on its own evidence, and is used; the band already dividing the beat so uses
    // it too. The listener's window-by-window reading is not taken (it takes a feel from random rhythm).
    if(this.subdivisionSequence){
      const reading=this.subdivisionReading;
      if(!sameLevel||!reading)return;
      const wanted=reading.parts===3?3:4;
      if((wanted===3)===(cursor.subdivision%3===0)){this.subdivisionReading=null;return}
      if(typeof this.ensemble.proposeSubdivision==='function'&&this.ensemble.proposeSubdivision(wanted)){
        this.subdivisionHeard={wanted,since:reading.at,proposedAt:now};this.subdivisionReading=null}
      return;
    }
    const parts=this.subdivisionEstimate()??(ownReadingOnly?null:report?.timing?.subdivision?.parts),wanted=parts===3?3:parts===2?4:null;
    // A reading of a beat an octave from the band's says nothing about how the band's beat divides; it is skipped,
    // and the reading being held goes on. A swing take read at its beat and its half by turns reset the hold on
    // every flip, and never switched.
    if(!sameLevel)return;
    if(!wanted)return;
    if(this.subdivisionHeard?.wanted!==wanted)this.subdivisionHeard={wanted,since:now};
    const triple=cursor.subdivision%3===0;
    if((wanted===3)===triple||now-this.subdivisionHeard.since<4||typeof this.ensemble.proposeSubdivision!=='function')return;
    if(this.ensemble.proposeSubdivision(wanted))this.subdivisionHeard={wanted,since:now,proposedAt:now};
  }
  status() {
    const decision=this.lastDecision,report=this.input?.latest?.report;
    // Measured, not assumed. In held-out guitar recordings (GuitarSet) following
    // helped, but in held-out sung takes every tracker was wrong more often than
    // right while claiming to track. So following a voice can mislead.
    const caution=report?.modality==='audio'&&report.role==='performer'?
      'Acoustic performer input: held-out guitar recordings were followed well, but held-out sung takes misled every tracker. Judge by ear before relying on it.':null;
    return freeze({enabled:this.enabled,state:this.state,reason:this.reason,caution,source:this.input?.source??null,
      destination:this.destination??'clips',referencePulse:this.destination==='ensemble'?{numerator:1,denominator:this.ensemble?.cursor?.meter.denominator??bandMeter().denominator}:{numerator:1,denominator:4},
      options:this.config??null,placement:this.placement?.status()??null,pending:this.pending?{decisionId:this.pending.id,cutoff:this.pending.cutoff,effectiveAt:this.pending.effectiveAt}:null,
      lastDecision:decision?{decisionId:decision.decisionId,cutoff:decision.cutoff??null,status:decision.status,reason:decision.reason,
        evidenceRef:decision.evidence?.report?.reportId??decision.evidence?.reportId??null,accepted:decision.accepted}:null,
      meaning:this.syncing?'current-meter beats synchronized one by one: the performer\'s period, and their phase when the input is calibrated':
        `${this.destination==='ensemble'?'current-meter pulse':'quarter-note'} duration following; `+
        (this.config?.alignPhase&&this.destination!=='ensemble'?'beat phase aligned when the input is calibrated':'input phase is not synchronized')});
  }
  snapshot() {return frozenJson({status:this.status(),decisions:this.decisions},{bytes:2*1024*1024,items:262144}).data;}
}
