// Small, runtime-neutral linear-Gaussian operations. Models declare units and
// clocks outside this module. No mutable singleton, timer, transport or effects.
export const MAX_FILTER_DIMENSION = 8;

export class EstimationError extends Error {
  constructor(code, message) { super(message); this.name = 'EstimationError'; this.code = code; }
}
const fail = (code, message) => { throw new EstimationError(code, message); };
export function finite(value, name) {
  if (typeof value !== 'number' || !Number.isFinite(value)) fail('non-finite', `${name} must be finite`);
  return value;
}
function dimension(n) {
  if (!Number.isInteger(n) || n < 1 || n > MAX_FILTER_DIMENSION) fail('dimension', 'Unsupported filter dimension');
  return n;
}
// (The helpers below are loops rather than map and reduce: the filter runs for every hypothesis at every onset, and at
// two or three dimensions the closures cost more than the arithmetic. Each sum is taken in the same order as before, so
// every result is the same number.)
function vector(value, n, name) {
  if (!Array.isArray(value) || value.length !== n) fail('dimension', `${name} has the wrong dimension`);
  const out = new Array(n);
  for (let i = 0; i < n; i++) out[i] = finite(value[i], name);
  return out;
}
function matrix(value, rows, columns, name) {
  if (!Array.isArray(value) || value.length !== rows) fail('dimension', `${name} has the wrong shape`);
  const out = new Array(rows);
  for (let i = 0; i < rows; i++) out[i] = vector(value[i], columns, name);
  return out;
}
const zeros = (rows, columns = rows) => { const out = new Array(rows); for (let i = 0; i < rows; i++) out[i] = new Array(columns).fill(0); return out; };
const transpose = a => {
  const rows = a.length, columns = a[0].length, out = new Array(columns);
  for (let j = 0; j < columns; j++) { const row = new Array(rows); for (let i = 0; i < rows; i++) row[i] = a[i][j]; out[j] = row; }
  return out;
};
const multiply = (a, b) => {
  const columns = b[0].length, out = new Array(a.length);
  for (let i = 0; i < a.length; i++) {
    const left = a[i], row = new Array(columns);
    for (let j = 0; j < columns; j++) { let sum = 0; for (let k = 0; k < left.length; k++) sum = sum + left[k] * b[k][j]; row[j] = sum; }
    out[i] = row;
  }
  return out;
};
const add = (a, b) => {
  const out = new Array(a.length);
  for (let i = 0; i < a.length; i++) { const left = a[i], right = b[i], row = new Array(left.length); for (let j = 0; j < left.length; j++) row[j] = left[j] + right[j]; out[i] = row; }
  return out;
};
const dot = (a, b) => { let sum = 0; for (let i = 0; i < a.length; i++) sum = sum + a[i] * b[i]; return sum; };
const matvec = (a, b) => { const out = new Array(a.length); for (let i = 0; i < a.length; i++) out[i] = dot(a[i], b); return out; };
const identity = n => { const out = zeros(n); for (let i = 0; i < n; i++) out[i][i] = 1; return out; };
const immutable = a => { const out = new Array(a.length); for (let i = 0; i < a.length; i++) out[i] = Object.freeze(a[i].slice()); return Object.freeze(out); };

// Scale by standard deviations before checking PSD or solving, so a valid
// 1e-24 measurement variance is not rounded away next to a unit-sized state.
function correlation(covariance) {
  const n = covariance.length, scales = new Array(n), normalized = new Array(n);
  for (let i = 0; i < n; i++) scales[i] = Math.sqrt(covariance[i][i]);
  for (let i = 0; i < n; i++) {
    const source = covariance[i], row = new Array(source.length);
    for (let j = 0; j < source.length; j++) {
      const value = source[j];
      if (!scales[i] || !scales[j]) {
        if (value !== 0) fail('covariance-psd', 'Zero variance cannot have nonzero covariance');
        row[j] = 0;
      } else row[j] = value / scales[i] / scales[j];
    }
    normalized[i] = row;
  }
  return {scales, normalized};
}
function factor(a, {semidefinite = false} = {}) {
  const lower = zeros(a.length), tolerance = 256 * Number.EPSILON;
  for (let i = 0; i < a.length; i++) {
    for (let j = 0; j <= i; j++) {
      let value = a[i][j];
      for (let k = 0; k < j; k++) value -= lower[i][k] * lower[j][k];
      if (i === j) {
        if (!Number.isFinite(value) || value < -tolerance) fail('covariance-psd', 'Covariance is not positive semidefinite');
        if (value <= 0 && !semidefinite) fail('singular-innovation', 'Innovation covariance is singular');
        lower[i][j] = Math.sqrt(Math.max(0, value));
      } else if (lower[j][j] > 0) lower[i][j] = value / lower[j][j];
      else if (Math.abs(value) > tolerance) fail('covariance-psd', 'Covariance is not positive semidefinite');
    }
  }
  return lower;
}
export function validateCovariance(value, n = value?.length, name = 'covariance') {
  dimension(n);
  const a = matrix(value, n, n, name);
  for (let i = 0; i < n; i++) {
    if (a[i][i] < 0) fail('covariance-psd', `${name} has negative variance`);
    for (let j = 0; j < i; j++) {
      const scale = Math.max(Math.abs(a[i][j]), Math.abs(a[j][i]), Number.MIN_VALUE);
      if (Math.abs(a[i][j] - a[j][i]) > 64 * Number.EPSILON * scale) fail('covariance-symmetry', `${name} is asymmetric`);
    }
  }
  factor(correlation(a).normalized, {semidefinite: true});
  return a;
}
function symmetric(a) {
  const out = new Array(a.length);
  for (let i = 0; i < a.length; i++) { const source = a[i], row = new Array(source.length); for (let j = 0; j < source.length; j++) row[j] = i === j ? source[j] : source[j] / 2 + a[j][i] / 2; out[i] = row; }
  return out;
}
// The states filterState made: validated when made and frozen, so a state that comes back as it was needs no second
// check. (validateCovariance only refuses; it changes no value, so taking the state as it is gives the same numbers.)
const validated = new WeakSet();
export function filterState({mean, covariance}) {
  const n = dimension(mean?.length);
  const state = Object.freeze({mean: Object.freeze(vector(mean, n, 'mean')), covariance: immutable(validateCovariance(covariance, n))});
  validated.add(state);
  return state;
}
const stateOf = state => validated.has(state) ? state : filterState(state);
function solve(covariance, rhs) {
  const {scales, normalized} = correlation(covariance);
  if (scales.some(scale => scale === 0)) fail('singular-innovation', 'Innovation covariance is singular');
  const l = factor(normalized), n = l.length;
  const solveVector = b => {
    const y = Array(n), x = Array(n);
    for (let i = 0; i < n; i++) {
      let value = b[i] / scales[i];
      for (let j = 0; j < i; j++) value -= l[i][j] * y[j];
      y[i] = value / l[i][i];
    }
    for (let i = n - 1; i >= 0; i--) {
      let value = y[i];
      for (let j = i + 1; j < n; j++) value -= l[j][i] * x[j];
      x[i] = value / l[i][i];
    }
    return x.map((value, i) => finite(value / scales[i], 'solution'));
  };
  return {columns: rhs.map(solveVector), logDeterminant: 2 * scales.reduce((sum, scale, i) => sum + Math.log(scale) + Math.log(l[i][i]), 0)};
}

export function predict(state, {transition, processNoise, control = null}) {
  state = stateOf(state);
  const n = state.mean.length, f = matrix(transition, n, n, 'transition'), q = validateCovariance(processNoise, n, 'process noise');
  const u = control === null ? Array(n).fill(0) : vector(control, n, 'modeled control');
  return filterState({mean: matvec(f, state.mean).map((x, i) => x + u[i]),
    covariance: symmetric(add(multiply(multiply(f, state.covariance), transpose(f)), q))});
}

export function correct(state, {measurement, projection, measurementNoise, varianceFloors = null, gate = Infinity}) {
  state = stateOf(state);
  const n = state.mean.length, count = dimension(measurement?.length);
  if (!Array.isArray(measurement)) fail('dimension', 'Measurement must be an array');
  const hAll = matrix(projection, count, n, 'projection'), rAll = validateCovariance(measurementNoise, count, 'measurement noise');
  const floors = varianceFloors === null ? Array(count).fill(0) : vector(varianceFloors, count, 'variance floors');
  if (floors.some(x => x < 0) || !(gate > 0)) fail('configuration', 'Invalid variance floor or innovation gate');
  const selected = [];
  measurement.forEach((value, i) => { if (value !== null) { finite(value, 'measurement'); selected.push(i); } });
  if (!selected.length) return Object.freeze({state, accepted: false, reason: 'missing-measurement', regularizations: Object.freeze([])});
  const h = selected.map(i => hAll[i]), r = selected.map(i => selected.map(j => rAll[i][j])), regularizations = [];
  selected.forEach((original, i) => {
    if (r[i][i] < floors[original]) {
      regularizations.push(Object.freeze({kind: 'measurement-variance-floor', dimension: original, from: r[i][i], to: floors[original]}));
      r[i][i] = floors[original];
    }
  });
  const innovation = selected.map((i, j) => measurement[i] - dot(h[j], state.mean));
  const pht = multiply(state.covariance, transpose(h));
  const innovationCovariance = validateCovariance(symmetric(add(multiply(h, pht), r)), selected.length, 'innovation covariance');
  // Solve S K' = H P, and S e = innovation. Never form a general inverse.
  const solution = solve(innovationCovariance, [...pht, innovation]);
  const gain = solution.columns.slice(0, n), nis = Math.max(0, dot(innovation, solution.columns[n]));
  finite(nis, 'normalized innovation');
  const diagnostics = {innovation: Object.freeze(innovation), innovationCovariance: immutable(innovationCovariance), nis,
    logLikelihood: -0.5 * (selected.length * Math.log(2 * Math.PI) + solution.logDeterminant + nis),
    regularizations: Object.freeze(regularizations)};
  if (nis > gate) return Object.freeze({...diagnostics, state, accepted: false, reason: 'innovation-gate'});
  const ikh = add(identity(n), multiply(gain, h).map(row => row.map(x => -x)));
  // Joseph form preserves covariance under rounding much better than (I-KH)P.
  const covariance = symmetric(add(multiply(multiply(ikh, state.covariance), transpose(ikh)), multiply(multiply(gain, r), transpose(gain))));
  const mean = state.mean.map((value, i) => value + dot(gain[i], innovation));
  return Object.freeze({...diagnostics, state: filterState({mean, covariance}), accepted: true, reason: null});
}
