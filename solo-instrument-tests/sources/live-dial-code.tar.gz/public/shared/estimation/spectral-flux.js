// Onsets from the spectrum's new energy (spectral flux), decided hop by hop as the sound arrives.
//
// The RMS detector (audio-features.js, rms-attack-v2) hears an onset when a frame's energy jumps 1.8 times. A strummed
// guitar rings on between strums, so most strums raise the energy far less. On GuitarSet comping it heard about half
// the annotated attacks, and a third on the strummed rock, singer-songwriter and 12/8 takes. The listener then read a
// 12/8 strum from a third of its eighths.
//
// Spectral flux sums, over frequency, how much each bin's log magnitude rose from the spectrum two hops before
// (Bello et al. 2005; Dixon 2006). Each bin is compared with the largest of itself and its neighbours then, so a
// note's vibrato or slide is not a new note (Böck & Widmer 2013). The magnitudes are scaled by the capture's level
// over the last two seconds, so a quiet capture is heard as a loud one is. An onset is a hop whose flux is the
// largest of the last 30 ms and at least 1.25 times the mean of the last 100 ms, decided as it arrives: online peak
// picking (Böck, Krebs & Schedl 2012), with a relative threshold. Stationary noise varies by a few percent from hop to
// hop, and a threshold of the mean alone heard eight onsets a second in noise at -60 dBFS.
//
// A window is about 46 ms (2048 samples at 44.1 and 48 kHz), and hops are a quarter of it. The attack is placed at
// the start of the hop that heard it, a quarter window before its end, where the flux first rises. Nothing is decided
// until the two windows compared hold only sound heard since the start or the last reset, so a sound already playing
// when listening begins is not an onset.
//
// On 60 GuitarSet comping takes (development) it heard 88% of the attacks, 84% of what it heard real, against 56%
// and 95%, and the same at -20 and -30 dB. It is not the default: the beam's level got no better with it. Hearing
// every eighth of a 12/8, the beam groups them in twos (research/kalman-integration.md, "Hearing every strum").
export const SPECTRAL_FLUX=Object.freeze({compression:1.5,levelSeconds:2,levelFloor:1e-3,lowHz:30,highHz:11000,lagHops:2,neighbourBins:1,
  peakSeconds:.03,averageSeconds:.1,ratio:1.25,floor:.001});

export class SpectralFluxOnsets {
  constructor({sampleRate,...config}={}){
    if(!(Number.isFinite(sampleRate)&&sampleRate>=8000&&sampleRate<=192000))throw new TypeError('Invalid spectral flux sample rate');
    const c={...SPECTRAL_FLUX,...config};
    for(const key of Object.keys(SPECTRAL_FLUX))if(!Number.isFinite(c[key]))throw new TypeError(`Invalid spectral flux ${key}`);
    if(c.compression<=0||c.levelSeconds<=0||c.levelFloor<=0||c.lowHz<0||c.highHz<=c.lowHz||!Number.isInteger(c.lagHops)||c.lagHops<1||
      !Number.isInteger(c.neighbourBins)||c.neighbourBins<0||c.peakSeconds<=0||c.averageSeconds<=0||c.ratio<1||c.floor<0)throw new TypeError('Invalid spectral flux configuration');
    const size=2048*2**Math.max(-2,Math.min(2,Math.round(Math.log2(sampleRate/44100)))),hop=size/4,bits=Math.log2(size);
    const hopSeconds=hop/sampleRate;
    Object.assign(this,{sampleRate,config:c,size,hop,
      low:Math.max(1,Math.round(c.lowHz*size/sampleRate)),high:Math.min(size/2-1,Math.round(c.highHz*size/sampleRate)),
      peakHops:Math.max(1,Math.round(c.peakSeconds/hopSeconds)),averageHops:Math.max(1,Math.round(c.averageSeconds/hopSeconds)),
      levelHops:Math.max(1,Math.round(c.levelSeconds/hopSeconds)),
      window:new Float64Array(size),reversed:new Uint32Array(size),cos:new Float64Array(size/2),sin:new Float64Array(size/2),
      real:new Float64Array(size),imag:new Float64Array(size)});
    for(let i=0;i<size;i++){this.window[i]=.5-.5*Math.cos(2*Math.PI*i/size);let r=0;for(let b=0,v=i;b<bits;b++,v>>=1)r=r<<1|v&1;this.reversed[i]=r;}
    for(let i=0;i<size/2;i++){this.cos[i]=Math.cos(2*Math.PI*i/size);this.sin[i]=Math.sin(2*Math.PI*i/size);}
    this.reset();
  }
  reset(){
    this.recent=new Float32Array(this.size);this.spectra=[];this.flux=[];this.squares=[];this.squareSum=0;this.heard=0;
  }
  // The level-scaled log magnitudes of the latest window.
  spectrum(level){
    const {size,real,imag,window,reversed,cos,sin,recent}=this,gain=this.config.compression*2/size/level,out=new Float64Array(size/2);
    for(let i=0;i<size;i++){real[reversed[i]]=recent[i]*window[i];imag[i]=0;}
    for(let span=2;span<=size;span*=2){
      const half=span/2,step=size/span;
      for(let start=0;start<size;start+=span)for(let k=0;k<half;k++){
        const c=cos[k*step],s=sin[k*step],a=start+k,b=a+half,re=real[b]*c+imag[b]*s,im=imag[b]*c-real[b]*s;
        real[b]=real[a]-re;imag[b]=imag[a]-im;real[a]+=re;imag[a]+=im;
      }
    }
    for(let k=0;k<size/2;k++)out[k]=Math.log1p(gain*Math.hypot(real[k],imag[k]));
    return out;
  }
  // Hears `samples`, a whole number of hops. Returns the onsets decided in them, each as the attack's index in
  // `samples` and its flux.
  process(samples){
    if(!(samples instanceof Float32Array)||samples.length%this.hop)throw new TypeError(`Spectral flux hears whole hops of ${this.hop} samples`);
    const {hop,size,low,high,config}=this,found=[];
    for(let from=0;from<samples.length;from+=hop){
      const chunk=samples.subarray(from,from+hop);
      this.recent.copyWithin(0,hop);this.recent.set(chunk,size-hop);this.heard+=hop;
      let square=0;for(let i=0;i<hop;i++)square+=chunk[i]*chunk[i];square/=hop;
      this.squares.push(square);this.squareSum+=square;if(this.squares.length>this.levelHops)this.squareSum-=this.squares.shift();
      const level=Math.max(config.levelFloor,Math.sqrt(Math.max(0,this.squareSum)/this.squares.length)),spectrum=this.spectrum(level);
      this.spectra.push(spectrum);if(this.spectra.length>config.lagHops+1)this.spectra.shift();
      if(this.heard<size+config.lagHops*hop)continue;
      const before=this.spectra[0],reach=config.neighbourBins;let flux=0;
      for(let k=low;k<=high;k++){
        let reference=before[k];for(let j=1;j<=reach;j++)reference=Math.max(reference,before[Math.max(0,k-j)],before[Math.min(size/2-1,k+j)]);
        const rise=spectrum[k]-reference;if(rise>0)flux+=rise;
      }
      flux/=high-low+1;
      const history=this.flux,peak=history.slice(-this.peakHops).reduce((a,b)=>Math.max(a,b),-Infinity);
      const recent=[...history.slice(-this.averageHops),flux],mean=recent.reduce((a,b)=>a+b,0)/recent.length;
      if(history.length&&flux>=peak&&flux>=config.ratio*mean+config.floor)found.push({index:from,flux});
      history.push(flux);if(history.length>Math.max(this.peakHops,this.averageHops))history.shift();
    }
    return found;
  }
}
