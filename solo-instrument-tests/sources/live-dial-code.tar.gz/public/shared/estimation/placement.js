// A performer's placement, from somewhere (RESEARCH_BACKLOG "A source for a performer's placement"; the Kalman plan's
// §4.4, "expressive timing and source-specific offsets"). A band following a performer keeps the placement it knows
// (beat-sync.js: the report's placementSeconds, else performerPlacementSeconds) and corrects only what differs from
// it. Where nobody says what it is, a placement shows up as tempo in a loop where both correct
// (test/offset-aware-sync.test.mjs). Three sources:
//   declared    the performer's word: their input's (input-report.js: the report's phase.placementSeconds), or the
//               band's setting (beat-sync.js performerPlacementSeconds). Taken as it is;
//   measured    the band listens before it corrects. It holds the performer's tempo and its own phase, and a performer
//               who listens, as people do, settles at their own placement against it. The median of their offsets
//               from the band's beats, once steady, is the estimate;
//   calibrated  measured against a beat whose acquisition latency was calibrated apart (latency-calibration.js: a
//               loopback, or a tap-along, which also takes off the anticipation people tap with). What is left is
//               what the performer adds while playing: their placement, which "stays theirs".
// Measured against an uncalibrated beat, a constant latency and a constant placement cannot be told apart (§4.4: "a
// constant latency and a constant musical phase offset can be observationally indistinguishable"), so the estimate is
// the two together, and says so (`combined`). For the band, that is what should not be corrected either way. Every
// beat phase an input reports is calibrated (input-report.js), so a band following one hears a calibrated placement.
import {POCKET_SECONDS,beatStep} from './beat-sync.js';

export const PLACEMENT=Object.freeze({
  // Offsets passed over while the performer adapts to a band that has stopped correcting (beats; ours).
  settleBeats:6,
  // Offsets the estimate is taken over, and the most it will listen for while they are not steady.
  listenBeats:16,mostBeats:48,
  // Steady: the offsets' median absolute deviation at most this (seconds; ours: about a sixteenth at 240 BPM's tenth).
  steadySeconds:.012,
  // A placement is within the musical pocket (as beat-sync's performerPlacementSeconds is): beyond it, the band is
  // hearing another beat, not a placement, and the estimate is refused.
  mostSeconds:POCKET_SECONDS,
});
const median=values=>{const sorted=[...values].sort((a,b)=>a-b),middle=sorted.length>>1;return sorted.length%2?sorted[middle]:(sorted[middle-1]+sorted[middle])/2};

export class PlacementEstimator {
  constructor({declared=null,choices=PLACEMENT}={}){
    this.choices=choices;this.offsets=[];this.calibrations=new Set();this.value=null;this.refused=null;
    if(declared!==null)this.declare(declared,{by:'setting'});
  }
  // The performer's word, which ends any listening: `by` the band's setting, or their input.
  declare(seconds,{by='input'}={}){
    if(!Number.isFinite(seconds)||Math.abs(seconds)>this.choices.mostSeconds)throw new RangeError(`A declared placement is within ${this.choices.mostSeconds} s`);
    this.value={seconds,source:'declared',by,combined:false,beats:0,spread:0};this.refused=null;
  }
  // Whether the band should listen (hold its phase) rather than correct.
  get listening(){return this.value===null&&this.refused===null}
  // One beat's offset: the performer's beat less the band's (seconds; + behind), heard while listening, and the
  // calibration of the performer's beat (its calibrationVersion), or null.
  observe(offsetSeconds,{calibrationVersion=null}={}){
    if(!this.listening||!Number.isFinite(offsetSeconds))return;
    this.offsets.push(offsetSeconds);this.calibrations.add(calibrationVersion);
    const {settleBeats,listenBeats,mostBeats,steadySeconds,mostSeconds}=this.choices,heard=this.offsets.length-settleBeats;
    if(heard<listenBeats)return;
    const recent=this.offsets.slice(-listenBeats),middle=median(recent),spread=median(recent.map(value=>Math.abs(value-middle)));
    if(spread>steadySeconds&&heard<mostBeats)return;
    if(Math.abs(middle)>mostSeconds){this.refused={reason:'beyond-the-pocket',seconds:middle};return;}
    // Calibrated only where every beat heard was, by one calibration: a recalibration midway measures against another
    // beat.
    const [calibration]=this.calibrations,calibrated=this.calibrations.size===1&&calibration!==null;
    this.value={seconds:middle,source:calibrated?'calibrated':'measured',combined:!calibrated,calibration:calibrated?calibration:null,
      beats:recent.length,spread,...(spread>steadySeconds?{loose:true}:{})};
  }
  placement(){return this.value}
  status(){return {listening:this.listening,heard:this.offsets.length,placement:this.value,refused:this.refused}}
}

// beat-sync's step with a placement's source. Once the estimator has one, the performer's beat is corrected against
// less it. A placement the performer's input declares (the report's own) comes first, and needs no listening.
//
// While it listens, the band first finds the performer's tempo as it always does, best while it is quiet and the
// performer plays alone (acquireWhileQuiet), when their beats are their own tempo and nothing else. Once it sounds, that
// tempo is near and the band is in the performer's phase (within its deadband), it holds the tempo, and its phase, and
// hears where the performer settles against it. In phase first: a performer who does not answer (a recording) stays
// where the band held, and a band holding just after it entered 15 ms early would take its own earliness for their
// placement. So a band placing a performer enters on their beat, not ahead of it (entryAnticipationSeconds), and holds
// from its first beat; one already sounding holds once it is in their phase. It holds the
// tempo too, the one it heard while the performer played alone where it did: a performer correcting their phase looks,
// beat by beat, like a change of tempo, and a band following it chases them part of the way (it heard 8 ms of a 20-ms
// placement so; and it took 119.8 BPM from a performer at 120 who had begun correcting toward a band entering early). A performer who corrects toward their placement
// against a steady band settles at it plus the difference of their tempo from the band's over their share of
// correction: a band that took its tempo from beats the performer had already begun correcting (0.51 s for 0.5, 2%)
// heard nothing of a 20-ms placement. That is §4.4's ambiguity again, in tempo: the performer heard alone first is what
// separates them. The offset heard is the step's asynchrony turned round: the band's aim (its beat plus any
// anticipation) less the performer's grid.
export function placedBeatStep({estimator,cursor,base=null,period,phase,config,persistent=null}){
  if(phase&&Number.isFinite(phase.placementSeconds)){
    if(estimator&&estimator.value?.seconds!==phase.placementSeconds)estimator.declare(phase.placementSeconds);
    return beatStep({cursor,base,period,phase,config,persistent});
  }
  const unplaced=phase&&{...phase,placementSeconds:0};
  if(!estimator||!estimator.listening){
    const placed=estimator?.placement()?.seconds;
    return beatStep({cursor,base,period,config,persistent,
      phase:phase&&Number.isFinite(placed)&&!Number.isFinite(phase.placementSeconds)?{...phase,placementSeconds:placed}:phase});
  }
  if(estimator.heldPeriod===undefined){
    const finding=beatStep({cursor,base,period,phase:unplaced,persistent,config:{...config,entryAnticipationSeconds:config.anticipationSeconds}});
    if(finding.mode==='acquiring')estimator.alonePeriod=finding.base;
    if(cursor.quiet||finding.mode!=='tracking'||finding.reason!=='within-phase-deadband')return {...finding,placing:true};
    estimator.heldPeriod=estimator.alonePeriod??finding.base;
  }
  const held=estimator.heldPeriod;
  const step=beatStep({cursor,base:held,period:held,phase:unplaced,persistent:null,config:{...config,phaseDeadbandSeconds:Infinity,correctPersistent:false}});
  if(step.reason==='within-phase-deadband')estimator.observe((config.anticipationSeconds??0)-step.asynchrony,{calibrationVersion:phase.calibrationVersion??null});
  return {...step,persistent:null,reason:step.reason==='within-phase-deadband'?'placing':step.reason,placing:true};
}
