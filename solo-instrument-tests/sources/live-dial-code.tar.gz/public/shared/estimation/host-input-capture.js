// Audio capture from an input the host itself provides, heard synchronously:
// frames up to the host's present, analysed in process by the same code the
// microphone Worker runs (audio-frame-analysis.js). An offline render provides
// its clips as such inputs, so ListenerBot hears a recording the way it hears a
// microphone, causally, frame by frame as render time passes, and never ahead of
// it.
//
// The interface is PerformerAudioCapture's: start, stop, captureNow, binding,
// mapping, clockDomain and renewSourceIncarnation. The host's clock is the
// session's (a render's music seconds), so the mapping is the identity and the
// domain is session seconds. pump() takes the frames that have become available.
//
// inputs: {list() -> [{id, name}], open(id) -> {sampleRate, latencySeconds?, read(fromSeconds, toSeconds) -> Float32Array}}
//
// A host that knows its input's latency declares it (latencySeconds): from a note
// scheduled on the host clock to that note captured. A render's is exactly zero.
// The capture is then calibrated, as a measured loopback calibrates a MIDI input,
// and its reports can state the performer's beat phase. An input that declares
// none stays uncalibrated, and following it matches tempo only.
import {ObservationClockMapping} from './observations.js';
import {randomUUID} from '../random-id.js';
import {createFrameAnalysis} from './audio-frame-analysis.js';
import {captureReport} from './audio-capture.js';
import {listeningOptions} from './listening-options.js';

export class HostInputCapture {
  constructor({inputs,now,onReport=()=>{},onCoverage=()=>{}}={}){
    if(typeof inputs?.open!=='function'||typeof now!=='function')throw new TypeError('A host input capture needs host inputs and the host clock');
    Object.assign(this,{inputs,now,onReport,onCoverage});this.state='idle';
  }
  // listening: how the frame analysis hears (listening-options.js), or null for its defaults.
  async start({deviceId,performerId=null,role='mixture',possibleSelfOutput=true,frameSize=2048,listening=null}={}) {
    if(this.state!=='idle')throw new Error('Stop the existing capture before starting a new one');
    if(!['isolated','mixture'].includes(role)||role==='mixture'&&performerId!==null||role==='isolated'&&(!performerId||typeof performerId!=='string'))throw new Error('Identify an isolated performer, or explicitly select an unidentified mixture');
    if(typeof possibleSelfOutput!=='boolean')throw new TypeError('Declare whether this input may contain bot output');
    if(!Number.isInteger(frameSize)||frameSize<256||frameSize>8192||(frameSize&(frameSize-1)))throw new TypeError('Invalid capture frame size');
    const heard=listening===null?{}:listeningOptions(listening),input=this.inputs.open(deviceId);
    if(!input)throw new Error(`No host input ${deviceId}`);
    const incarnation=randomUUID();
    this.input=input;this.frameSize=frameSize;this.clockDomain='session-seconds';this.captureNow=this.now;
    this.mapping=new ObservationClockMapping({version:`host-input-${incarnation}`,inputUnits:'seconds',
      timingVarianceSeconds2:(1/input.sampleRate)**2,calibrationStatus:'uncalibrated'});
    this.binding=Object.freeze({sourceId:`audio-${incarnation}`,sourceIncarnation:incarnation,performerId,role,possibleSelfOutput,
      sampleRate:input.sampleRate,frameSize,clockDomain:this.clockDomain,clockMappingVersion:this.mapping.version,deviceSettings:{host:deviceId}});
    this.calibration=Number.isFinite(input.latencySeconds)?Object.freeze({offsetSeconds:input.latencySeconds,varianceSeconds2:0,
      calibrationVersion:`${this.mapping.version}:host-declared-latency`}):null;
    this.analysis=createFrameAnalysis({sampleRate:input.sampleRate,frameSize,...heard});this.listening=Object.freeze({...heard});
    // Frames are counted from the moment listening starts: nothing before it is heard.
    this.origin=this.now();this.sequence=0;this.state='listening';
    return true;
  }
  // Analyse every whole frame that has sounded by now.
  pump() {
    if(this.state!=='listening')return 0;
    const now=this.now(),seconds=this.frameSize/this.input.sampleRate;let heard=0;
    while(this.origin+(this.sequence+1)*seconds<=now+1e-9){
      const start=this.origin+this.sequence*seconds,end=start+seconds,samples=this.input.read(start,end,this.frameSize);
      const started=globalThis.performance?.now?.()??0,result=this.analysis.analyze(samples,{start,end,sequence:this.sequence});
      const report=captureReport({binding:this.binding,mapping:this.mapping,clockDomain:this.clockDomain,availableAt:now,receipt:now,
        captureDomain:this.clockDomain,data:{...result,sequence:this.sequence,processingMs:(globalThis.performance?.now?.()??0)-started}});
      this.sequence++;heard++;
      if(report)this.onReport(report);
    }
    return heard;
  }
  renewSourceIncarnation(reason='publisher-identity-changed') {
    if(this.state!=='listening')return false;
    this.onCoverage({coverage:'missing',reason,binding:this.binding});
    this.binding=Object.freeze({...this.binding,sourceIncarnation:randomUUID()});
    return this.binding;
  }
  stop() {this.state='idle';this.input=null;}
}
