// The conductor's evidence that a performer divides the beat in threes (swing, triplets, a compound feel) or in twos,
// gathered attack by attack across the session rather than decided window by window (the mathematical audit's I08).
//
// Counting where attacks fall, window by window, takes a feel from random rhythm: up to 40% of noise windows gave one,
// and the conductor's four-second hold turned one false "threes" into a proposal in every one of 200 noise runs
// (research/mathematical-audit/runs/2026-09-27-audit-subdivision). Elapsed time is not evidence. So each attack's
// phase in its beat is weighed against how swing and straight playing fall in the beat (templates measured on
// GuitarSet: scripts/measure-subdivision-templates.mjs, research/subdivision-templates-guitarset.json) and against
// uniform phase (random attacks). The evidence for each feel is a Shiryaev–Roberts statistic,
// R <- (1 + R) * LR, LR = the template's share of the attack's bin over the uniform share. It grows while the attacks
// fall as the feel's do, and fades while they fall at random. A feel is read when its statistic reaches `alarm`. Under
// random attacks at uniform phase, false alarms come at most once per `alarm` attacks on average (Pollak 1985).
//
// A reading once made is history. After it, both statistics start again, so the next reading needs evidence of its own
// (the ACC-001 handoff's condition on freshness). What it cannot do (P149 there): tell a loosely timed swing from
// random rhythm with no delay at all. On GuitarSet's held-out players, the delay is the measurement's
// (research/subdivision-templates-guitarset.json heldOut), and the alarm level is the trade.
export const SUBDIVISION_EVIDENCE=Object.freeze({
  bins:24,
  // The alarm level: under random attacks, a false reading at most once per 10,000 attacks on average, some forty
  // minutes at four a second (ours, by the user's rule for trackers: "no false lock"). On GuitarSet's held-out players,
  // swing read at 6.6 to 20 s and straight playing at 4 to 9 s, where the rule it replaces proposed about 4 s after its
  // first read and took a feel in every noise run.
  alarm:1e4,
});

// GuitarSet v1.1.0's players (all six), each attack's phase in its beat, in 24 bins: the share of their swung
// progressions' attacks (threes: 9449 in 108 takes) and of their straight ones' (twos: 21631 in 228) in each,
// peaking on the beat, at its two thirds (threes) or its half (twos), and just before the next
// (research/subdivision-templates-guitarset.json; test/subdivision-evidence.test.mjs keeps them equal). Swappable: any
// templates of this shape.
export const GUITARSET_SUBDIVISION=Object.freeze({
  source:'GuitarSet v1.1.0 (CC BY 4.0): annotated attacks against the click; scripts/measure-subdivision-templates.mjs',
  threes:Object.freeze([.1258,.1002,.0482,.0202,.0115,.0089,.0099,.0165,.0352,.0355,.0225,.0204,.035,.0463,.0628,.0696,.0826,.0488,.0219,.0134,.0147,.0194,.0462,.0847]),
  twos:Object.freeze([.1439,.079,.0245,.0079,.0095,.0195,.0334,.0256,.0142,.0149,.035,.0947,.129,.0807,.0284,.0124,.0113,.0227,.0386,.0279,.0118,.0114,.0326,.0912]),
});

function checkedTemplate(shares,bins,name){
  if(!Array.isArray(shares)&&!ArrayBuffer.isView(shares)||shares.length!==bins||![...shares].every(share=>share>0&&Number.isFinite(share)))
    throw new RangeError(`the ${name} template is ${bins} positive shares`);
  const total=[...shares].reduce((a,b)=>a+b,0);
  if(Math.abs(total-1)>1e-3)throw new RangeError(`the ${name} template's shares sum to 1, not ${total}`);
  return Float64Array.from(shares,share=>share/total);
}

export class SubdivisionEvidence{
  // templates: {threes, twos}, each `bins` shares summing to 1; alarm: the level a reading needs (more than 1).
  constructor({templates=GUITARSET_SUBDIVISION,alarm=SUBDIVISION_EVIDENCE.alarm}={}){
    const bins=templates.threes?.length;
    if(!Number.isSafeInteger(bins)||bins<2)throw new RangeError('a subdivision template has two bins or more');
    if(!(alarm>1&&Number.isFinite(alarm)))throw new RangeError(`the alarm level is more than 1, not ${alarm}`);
    this.bins=bins;this.alarm=alarm;
    this.templates={3:checkedTemplate(templates.threes,bins,'threes'),2:checkedTemplate(templates.twos,bins,'twos')};
    this.reset();
  }
  reset(){this.statistics={3:0,2:0};this.attacks=0}
  // One attack's phase in its beat (0 to 1). The reading it completes (3 or 2; both begin again), or null.
  observe(phase){
    if(!Number.isFinite(phase))return null;
    const wrapped=((phase%1)+1)%1,bin=Math.min(this.bins-1,Math.floor(wrapped*this.bins));
    for(const parts of [3,2])this.statistics[parts]=(1+this.statistics[parts])*this.bins*this.templates[parts][bin];
    this.attacks++;
    const threes=this.statistics[3],twos=this.statistics[2];
    if(threes<this.alarm&&twos<this.alarm)return null;
    const parts=threes>=twos?3:2;this.reset();return parts;
  }
  // Each feel's evidence so far, as a share of the alarm (0 to 1), and the attacks it has weighed.
  get evidence(){return {threes:Math.min(1,this.statistics[3]/this.alarm),twos:Math.min(1,this.statistics[2]/this.alarm),attacks:this.attacks}}
}
