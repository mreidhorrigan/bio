// Phase/period coupling: how far a human player is from the ensemble's beat.
//
// This is an implementation of the tempo-inference model Antescofo documents, adapted to
// an ensemble that already owns a clock. Antescofo has to find the beat; we do not. The
// room clock (and across machines, the reference conductor's timeline) states where the
// beat is, so the only question is the *deviation* of a live player from it — a phase
// error and a period error per onset, which is arithmetic rather than a tracker.
//
// What comes from the source, and what is ours, stated plainly because the source does not
// publish its constants:
//
//   FROM ANTESCOFO (antescofo-doc.ircam.fr/Reference/tempo_inference/, and Cont, IEEE
//   TPAMI 32(6), 2010):
//     * the model class — Large & Jones attention dynamics, correcting from the error
//       between a predicted and an actual event time;
//     * two dimensionless coupling factors, period 0 < ηp < 1 and phase 0 < ηφ < 2, where
//       larger converges faster and follows noise sooner;
//     * that the factors are not fixed but adapt to a measure (κ) of how random the
//       playing is, with named strategies trading reactivity against inertia;
//     * that events shorter than 0.3 s get smaller coupling, because a player's own
//       precision is worse there;
//     * the failure policy, which is the part usually left out: after 8 consecutive
//       undetected expected events the inferred tempo resets, and when detections are
//       non-consecutive inference *pauses* rather than correcting from bad data;
//     * convergence holds only within half to double the real tempo.
//
//   OURS, because the source describes them without numbers, or because it has a score
//   where we have none:
//     * the κ estimator — mean absolute phase error over a sliding window, scaled so that
//       half a beat of average error reads as fully random;
//     * the four strategies' base factors, and the 0.5 scale applied under 0.3 s;
//     * `beatWindow`. Antescofo knows which event belongs to which beat because it is
//       reading a score. We are not, so an onset more than a quarter of a beat from the
//       grid is treated as a subdivision or an ornament: not a missed beat, and not
//       evidence about the beat either. Without this a player in semiquavers reads as a
//       player at four times the tempo.
//     * which beat an onset is judged against: the expected one, unless the onset is
//       nearer the beat just heard. A chord's other notes, a flam, a grace note's main
//       note, a quintuplet's second note all fall in the half-beat after a heard beat;
//       wrapped against the expected beat they read as that beat played on time, and each
//       moved the grid on a whole beat (a three-note chord spread over 12 ms read as 201
//       bpm against a player at 120). They are the beat already heard, so not evidence.
//     * that the two coupling factors are stable together, not only apart: linearized
//       about tracking a steady player, a phase error e and relative period error v go
//       to [[1-ηp-ηφ, -1], [ηp, 1]]·[e, v], whose eigenvalues lie inside the unit
//       circle exactly when ηp > 0, 0 < ηφ < 2 and ηp + 2ηφ < 4 (the mathematical
//       audit's I08). The published ranges alone allow ηp + 2ηφ up to 5.
//     * acquisition. A steady onset rate *is* the player's pulse at some metrical
//       multiple, so when the last few inter-onset intervals agree, the smallest multiple
//       of their median that lands inside the convergence band is adopted. That is what
//       lets a player at 90 against a room at 120 be tracked at all, since every one of
//       their onsets would otherwise look like a skipped beat. It runs only while the grid
//       is failing to place the playing, and both of those conditions — when it runs and
//       which multiple it takes — were set by measurement rather than by taste; the
//       reasons are at `acquire` below.
//
// No randomness, no I/O, no DOM: every number here is a function of the onset times it was
// given, so a test can replay a performance exactly.

const clamp=(value,low=0,high=1)=>Math.min(high,Math.max(low,value));
const mean=values=>values.length?values.reduce((total,value)=>total+value,0)/values.length:0;
const median=values=>{const sorted=[...values].sort((left,right)=>left-right);return sorted[Math.floor(sorted.length/2)]};
// A late attack and an early one are the same small error, so errors live in (-0.5, 0.5]
// beats rather than growing without bound.
const wrapBeats=error=>{const wrapped=error-Math.round(error);return wrapped===-.5?.5:wrapped};

// Reactivity against stability. Antescofo names four strategies and says strategy 0 suits
// broad musical contexts, 1 tracks more reactively, 2 carries more inertia and 3 handles
// random performances; these factors are ours, chosen to sit inside its published ranges.
export const COUPLING_STRATEGIES=Object.freeze([
  Object.freeze({name:'balanced',period:.35,phase:.55}),
  Object.freeze({name:'reactive',period:.6,phase:1.1}),
  Object.freeze({name:'inertial',period:.18,phase:.3}),
  Object.freeze({name:'random-tolerant',period:.12,phase:.22}),
]);

export const COUPLING_RULES=Object.freeze({
  shortEventSeconds:.3,     // Antescofo: under this, couple less
  shortEventScale:.5,       // ours
  resetAfterMisses:8,       // Antescofo: 8 consecutive undetected events reset the tempo
  convergenceLow:.5,        // Antescofo: valid within half…
  convergenceHigh:2,        //            …to double the real tempo
  windowSeconds:6,          // ours: how much playing κ is measured over
  beatWindow:.25,           // ours: beats from the grid within which an onset is evidence
  acquireOnsets:3,          // ours: consecutive intervals that must agree
  acquireTolerance:.12,     // ours: how closely they must agree
  // ours: the metrical multiples a steady run may be read at, up to nine notes a beat (the tuplets the band itself
  // plays: fills of 3, 5, 7 and 9; the audit's I08 found continuous quintuplets and septuplets read at four a beat)
  acquireMultiples:Object.freeze([1,2,3,4,5,6,7,8,9]),
  acquireWhileExplained:3,  // ours: on-beat onsets in a row that stop it re-acquiring
  acquireMargin:.15,        // ours: how much nearer the room a slower multiple must be…
  acquireMarginOfSpacing:.5,//      …and no more than this of the spacing between neighbouring readings
  settledObservations:4,    // ours: corrections before confidence is allowed to reach 1
});

// ηp + 2ηφ stays under 4, by the inset the phase range keeps under 2 (1.999).
const JOINT_BOUND=2*1.999;

// 'new' — nothing heard yet. 'tracking' — correcting from consecutive on-beat onsets.
// 'paused' — beats went by unheard, so the prediction was never tested and nothing was
// corrected. 'reset' — too many expected onsets never came; the estimate is withdrawn
// rather than extrapolated.
export const COUPLER_STATES=Object.freeze(['new','tracking','paused','reset']);

export class PulseCoupler {
  constructor({bpm=120,beatsPerBar=4,strategy=0,rules={},strategies=COUPLING_STRATEGIES}={}){
    this.rules={...COUPLING_RULES,...rules};
    if(!Array.isArray(strategies)||!strategies.length||Array.from(strategies).some(s=>!s||!Number.isFinite(s.period)||!Number.isFinite(s.phase)||!(s.period>0&&s.phase>0)))
      throw new TypeError('Coupling strategies require finite positive period and phase gains');
    if(this.rules.resetAfterMisses!==Infinity&&(!Number.isSafeInteger(this.rules.resetAfterMisses)||this.rules.resetAfterMisses<1||this.rules.resetAfterMisses>1024))
      throw new TypeError('resetAfterMisses must be in 1..1024 or explicit Infinity');
    if(!Number.isFinite(this.rules.shortEventScale)||this.rules.shortEventScale<=0||this.rules.shortEventScale>1)
      throw new TypeError('shortEventScale must be in (0,1]');
    this.strategies=strategies;
    this.strategy=Number.isInteger(strategy)&&strategies[strategy]?strategy:0;
    this.beatsPerBar=beatsPerBar>0?beatsPerBar:4;
    this.referencePeriod=60/(bpm>0?bpm:120);
    this.period=this.referencePeriod;
    this.expected=null;          // when the next beat is predicted, in seconds
    this.last=null;              // the last onset actually heard
    this.errors=[];              // [time, |error in beats|] inside the window
    this.intervals=[];           // [time, inter-onset interval] inside the window
    this.misses=0;
    this.observations=0;
    this.state='new';
    this.divergent=false;
    this.acquired=false;
    this.explained=0;            // consecutive onsets the grid placed on a beat
    this.reanchored=false;       // whether the last onset moved the grid
    this.unheard=0;              // beats `advance` passed since the last onset, not yet misses
  }

  // The ensemble's own clock, which is the thing a deviation is measured against. Adopting
  // a new reference never moves the player's estimate: that is the measurement.
  reference({bpm,meter}={}){
    const value=Number(bpm);
    if(Number.isFinite(value)&&value>0)this.referencePeriod=60/value;
    const numerator=Number(meter?.numerator);
    if(Number.isInteger(numerator)&&numerator>0)this.beatsPerBar=numerator;
    if(this.state==='new'||this.state==='reset'){this.period=this.referencePeriod;this.acquired=false}
    return this;
  }

  setStrategy(index){if(Number.isInteger(index)&&this.strategies[index])this.strategy=index;return this}

  // κ: how random this playing is, over the window. 0 is metronomic, 1 is noise. Half a
  // beat of average absolute error is the most a wrapped error can average, so that reads
  // as 1. (Ours; Antescofo publishes the principle and not the formula.)
  kappa(time=this.last??0){
    this.forget(time);
    return this.errors.length<2?0:clamp(2*mean(this.errors.map(entry=>entry[1])));
  }

  // The two coupling factors as they stand now: the strategy's base, narrowed by κ, and
  // narrowed again for events too short for a player to place precisely. Each stays inside
  // its published range, and the two inside their joint bound (ηp + 2ηφ < 4, above): a
  // strategy past it is narrowed to it, both factors alike, as κ narrows them. The shipped
  // strategies sit well inside (the reactive one at 2.8).
  couplings(time=this.last??0,interval=null){
    const base=this.strategies[this.strategy],slack=1-this.kappa(time);
    const short=Number.isFinite(interval)&&interval<this.rules.shortEventSeconds,
      scale=slack*(short?this.rules.shortEventScale:1);
    let period=clamp(base.period*scale,0,.999),phase=clamp(base.phase*scale,0,1.999);
    const joint=(period+2*phase)/JOINT_BOUND;
    if(joint>1){period/=joint;phase/=joint}
    return {period,phase,kappa:1-slack,short,strategy:base.name};
  }

  // How sure the reading is: steady playing that has been heard for a few beats, nothing
  // while paused or reset. This is the number a published plan carries as its confidence.
  confidence(time=this.last??0){
    if(this.state!=='tracking')return 0;
    return clamp((1-this.kappa(time))*Math.min(1,this.observations/this.rules.settledObservations));
  }

  forget(time){
    const cutoff=time-this.rules.windowSeconds;
    while(this.errors.length&&this.errors[0][0]<cutoff)this.errors.shift();
    while(this.intervals.length&&this.intervals[0][0]<cutoff)this.intervals.shift();
    return this;
  }

  // A steady onset rate is the player's own pulse at some metrical multiple. When the last
  // few intervals agree, take a multiple of their median that lands inside the convergence
  // band, and re-anchor the grid to this onset.
  //
  // Both halves of that — when it runs, and which multiple it takes — were changed by a
  // measurement, `scripts/measure-tempo-tracking.mjs`, and the reasons are below because
  // neither is obvious from the outside.
  acquire(time){
    // Never twice running. A re-anchor is a claim that the grid is now right, and the way to
    // find out is to let the next onset be judged against it. Without this, a player whose
    // intervals alternate — swing, or any pair of notes leaning into each other — had the
    // three-interval median flip either side of their rate and re-acquired on *every* onset,
    // so the grid was never once tested and the coupler reported no tempo at all. Measured on
    // a player at 150 with 6 ms of alternation: fourteen onsets, fourteen re-anchors, and a
    // reading of null throughout.
    if(this.reanchored){this.reanchored=false;return false}
    // **When.** Only while the grid is failing to place some of the playing. Re-anchoring
    // whenever three intervals happen to agree meant re-anchoring on beats it was already
    // tracking correctly: in the trace of a 100 → 150 change it re-acquired on nine of the
    // thirty onsets after the change, several of them dead on the beat, discarding the phase
    // it had just earned each time. Held off while the grid is working, the same tracker
    // holds a steady 180 bpm to 2.4% instead of 3.1% and re-locks a tempo change in 7 beats
    // instead of 24.
    //
    // The condition is a run of onsets the grid *did* place, not a run it failed to. A player
    // in quavers alternates on-beat and off-beat forever and so never accumulates a run of
    // failures to trigger on; gated that way round they stayed tracked at the wrong tempo.
    // Three on the beat in a row is the grid working.
    if(this.explained>=this.rules.acquireWhileExplained)return false;
    const recent=this.intervals.slice(-this.rules.acquireOnsets).map(entry=>entry[1]);
    if(recent.length<this.rules.acquireOnsets)return false;
    const centre=median(recent);
    if(!(centre>0))return false;
    if(!recent.every(value=>Math.abs(value-centre)<=centre*this.rules.acquireTolerance))return false;
    const low=this.referencePeriod*this.rules.convergenceLow,
      high=this.referencePeriod*this.rules.convergenceHigh;
    // **Which.** Still the multiple nearest the room's beat — a player in semiquavers at 120
    // is playing 120, and nearness to the room is what says so — but a slower multiple now
    // has to be nearer by a margin before it wins.
    //
    // Without the margin the rule is decided by noise exactly where it matters. A player at
    // 150 against a room at 100 puts the 1× candidate (0.4 s) and the 2× candidate (0.8 s)
    // the *same* distance from the room's 0.6 s, so a few milliseconds of the player's own
    // jitter decided which side of the tie the median fell on: measured, 148 bpm on one onset
    // and 75 on the next and back again, averaging 33 bpm out — not a slow lock but a coin
    // flip once a beat. A 3:2 relationship has no nearest multiple, and pretending it has one
    // is what produced the flapping.
    //
    // The margin resolves it by asking the slower reading to earn the claim it makes. Every
    // multiple above 1 says the player is subdividing the beat rather than playing it, and
    // that is a real claim about the music; when it is true, as it is for quavers or
    // semiquavers, the slower candidate sits far nearer the room than the player's raw rate
    // and clears the margin easily. When it is a tie, nothing is claimed and the player's own
    // rate stands — which at least does not change its mind twice a bar.
    //
    // The margin is at most half the spacing between neighbouring readings (the run's own interval): a run of seven
    // notes a beat puts its readings a seventh of a beat apart, closer than the room's margin, so the reading on the
    // room's beat could never earn it and the run was read at six. A tie between two readings still keeps the margin
    // (at 150 against 100 the readings are 0.4 s apart and the margin 0.09 s).
    let best=null,bestDistance=Infinity;
    const margin=Math.min(this.referencePeriod*this.rules.acquireMargin,centre*(this.rules.acquireMarginOfSpacing??.5));
    for(const multiple of this.rules.acquireMultiples){
      const candidate=centre*multiple;
      if(candidate<low||candidate>high)continue;
      const distance=Math.abs(candidate-this.referencePeriod);
      // Ascending multiples, so `best` is always the faster reading and a slower one has to
      // beat it by the margin rather than by a hair.
      if(best===null||distance<bestDistance-margin){best=candidate;bestDistance=distance}
    }
    // Nothing plausible: a player four times the room's speed has no beat in the band, so
    // the grid stays where it is and their onsets are read as subdivisions.
    if(best===null)return false;
    if(Math.abs(best-this.period)<=this.period*.02)return false;
    this.period=best;this.expected=time+best;this.acquired=true;this.explained=0;
    this.reanchored=true;
    return true;
  }

  // One onset from the player, in seconds on the same monotonic scale throughout. An onset
  // at or before the last one heard is that onset again, or one out of order: nothing is
  // learned from it and nothing changes.
  observe(time){
    if(!Number.isFinite(time)||(this.last!==null&&time<=this.last))return this.reading({error:null,interval:null});
    if(this.last===null||this.state==='reset'){
      // Nothing to compare against yet: adopt the onset as the grid's origin and wait.
      this.last=time;this.expected=time+this.period;this.misses=0;this.observations=0;
      this.errors.length=0;this.intervals.length=0;this.state='new';this.divergent=false;
      this.explained=0;this.reanchored=false;this.unheard=0;
      return this.reading({error:null,interval:null});
    }
    const interval=time-this.last;
    this.last=time;
    this.intervals.push([time,interval]);this.forget(time);
    // A re-anchor says the grid was wrong, so the beats it expected in the meantime were
    // not missed, whether or not `advance` had counted them yet.
    const reanchored=this.acquire(time);
    if(reanchored){this.unheard=0;return this.reading({error:0,interval,acquired:true})}

    // Walk the grid to the beat nearest this onset. Anything skipped is a beat that was
    // expected and never heard, here or already passed by `advance`: an onset reads the
    // same whether or not time was advanced before it.
    const skipped=this.pass(time)+this.unheard;
    this.unheard=0;

    if(skipped>0){
      this.misses+=skipped;
      this.explained=0;
      if(this.misses>=this.rules.resetAfterMisses)return this.withdraw(time,interval);
      this.state='paused';
      // An onset on its beat is that beat heard, though not evidence: the grid moves on to
      // the next, uncorrected, so the next onset is consecutive and corrects. Left on this
      // beat, every onset after a held note found it skipped again, and one held note ran
      // up misses to a reset.
      if(Math.abs(wrapBeats((time-this.expected)/this.period))<this.rules.beatWindow)this.expected+=this.period;
      return this.reading({error:null,interval});
    }
    // Nearer the beat just heard than the one expected: a chord's other notes, a flam, a
    // grace note's main note, a quintuplet's second note. That beat was heard and placed
    // already, so this is neither a miss nor evidence, and it leaves the grid alone.
    const offset=(time-this.expected)/this.period;
    if(offset<-.5)return this.reading({error:null,interval,sameBeat:true});
    const error=wrapBeats(offset);
    // Off the grid: a subdivision, an ornament, a grace note. Not a miss, and not evidence.
    // It is, though, an onset the grid could not account for, and a run of them is the
    // signal that the grid rather than the player is what has gone wrong.
    if(Math.abs(error)>=this.rules.beatWindow){
      this.explained=0;
      return this.reading({error,interval,offBeat:true});
    }

    const coupling=this.couplings(time,interval);
    this.misses=0;this.observations++;this.explained++;
    this.errors.push([time,Math.abs(error)]);this.forget(time);

    // Period correction, then the phase correction expressed as where the next beat is
    // expected: at ηφ = 1 the grid snaps to this onset, at 0 it ignores its timing, and
    // above 1 it overshoots — which is why Antescofo allows ηφ up to 2.
    this.period=this.converge(this.period*(1+coupling.period*error));
    this.expected=this.expected+this.period+coupling.phase*error*this.period;
    this.state='tracking';
    return this.reading({error,interval,coupling});
  }

  // Time passing with no onset. Every beat-width that goes by unheard is a missed expected
  // event: the reading pauses at the first, as inference does when an onset finds beats
  // skipped, and the eighth in a row withdraws the estimate instead of extrapolating a
  // tempo from a player who has stopped. The beats passed are held until the next onset
  // (`unheard`), which counts them as its own skipped beats.
  advance(time){
    if(!Number.isFinite(time)||this.expected===null||this.state==='reset')
      return this.reading({error:null,interval:null});
    const missed=this.pass(time);
    if(!missed)return this.reading({error:null,interval:null});
    this.unheard+=missed;
    if(this.misses+this.unheard>=this.rules.resetAfterMisses)return this.withdraw(time,null);
    this.state='paused';
    return this.reading({error:null,interval:null});
  }

  // Walk the grid on to the beat nearest `time`, and count the beats whose half-beat
  // boundary `time` has passed. Beat by beat while the count stays under the reset; once
  // the reset is certain the count is all that matters (the estimate is withdrawn, and the
  // grid with it), so a long silence costs no more than a short one. With no finite reset,
  // all but the last few beats pass in one step.
  pass(time){
    const limit=this.rules.resetAfterMisses-this.misses-this.unheard,
      // Beats certainly passed: one fewer than the boundaries crossed, whatever the rounding.
      far=Math.floor((time-this.expected)/this.period-.5)-1;
    if(far>0&&far>=limit)return far;
    let passed=0;
    if(far>0&&!Number.isFinite(limit)){this.expected+=far*this.period;passed=far}
    while(time>this.expected+this.period/2){this.expected+=this.period;passed++}
    return passed;
  }

  // Antescofo resets the inferred tempo to zero here, so that an accompaniment stops
  // rather than guesses. The equivalent for us is to report no tempo and no confidence:
  // the ensemble keeps its own clock, and simply stops being told about the player.
  withdraw(time,interval){
    this.state='reset';this.observations=0;this.errors.length=0;this.intervals.length=0;
    this.misses=0;this.acquired=false;this.divergent=false;this.explained=0;
    this.reanchored=false;this.unheard=0;
    this.period=this.referencePeriod;this.expected=null;this.last=time;
    return this.reading({error:null,interval});
  }

  // Convergence is only guaranteed within half to double the real tempo, so an estimate
  // that leaves that band is clamped and the reading says it happened.
  converge(period){
    const low=this.referencePeriod*this.rules.convergenceLow,
      high=this.referencePeriod*this.rules.convergenceHigh;
    this.divergent=period<low||period>high;
    return Math.min(high,Math.max(low,period));
  }

  reading({error,interval,coupling=null,offBeat=false,sameBeat=false,acquired=false}){
    const tracking=this.state==='tracking',time=this.last??0;
    return {
      state:this.state,
      bpm:tracking?60/this.period:null,
      period:tracking?this.period:null,
      referenceBpm:60/this.referencePeriod,
      // The two numbers a musician would recognise: are they ahead or behind, and by how
      // much are they pulling the tempo.
      phaseErrorBeats:error===null?null:error,
      phaseErrorMs:error===null?null:error*this.period*1000,
      bpmDelta:tracking?60/this.period-60/this.referencePeriod:null,
      intervalSeconds:interval,
      kappa:this.kappa(time),
      confidence:this.confidence(time),
      coupling:coupling||this.couplings(time,interval),
      misses:this.misses+this.unheard,
      observations:this.observations,
      divergent:this.divergent,
      offBeat,sameBeat,acquired,
    };
  }
}

// Whether a reading is worth telling the ensemble about: confident enough, far enough from
// the room's own tempo that following it would be an audible decision, and inside the band
// where the model is valid at all. A clamped estimate is a measurement of its own limit,
// not a tempo to propose.
export function worthProposing(reading,{minConfidence=.55,minBpmDelta=.75}={}){
  return Boolean(reading&&reading.state==='tracking'&&!reading.divergent&&!reading.offBeat&&!reading.sameBeat
    &&reading.confidence>=minConfidence&&Math.abs(reading.bpmDelta??0)>=minBpmDelta);
}
