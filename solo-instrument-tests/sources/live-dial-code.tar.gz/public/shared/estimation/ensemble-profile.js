import {actor,actorKey,sameActor,frozenJson} from '../planning-data.js';
import {InputReportClient} from './input-report.js';
import {ProfileReportClient,PROFILE_LIMITS} from './profile-report.js';

const freeze=value=>frozenJson(value,{bytes:PROFILE_LIMITS.totalBytes,items:131072,depth:24}).data;
const sourceKinds=new Set(['midiInput','listener','response','profile_clodbot']);
const reportIdentity=message=>actor({id:message.source,incarnation:message.sourceIncarnation});

// A bounded read model of existing source and response reports. Receipt time
// indexes retention only: it never aligns two source clocks or schedules sound.
export class EnsembleProfile{
  constructor({identity,send,now=()=>performance.now()/1000}){
    this.identity=actor(identity);Object.assign(this,{send,now});this.sources=new Map();this.records=new Map();
    this.bytes=0;this.revision=0;this.nextQueryAt=-Infinity;this.cursor=0;this.enabled=true;
    this.metrics={queries:0,replies:0,invalid:0,duplicates:0,evicted:0,conflicts:0};
  }
  configure(sources,identity=this.identity){
    identity=actor(identity);
    if(!Array.isArray(sources)||sources.length>PROFILE_LIMITS.sources)throw new RangeError('Choose at most eight profiler sources');
    const values=sources.map(value=>{
      if(!sourceKinds.has(value.kind)||typeof value.key!=='string'||!value.key||value.key.length>1024||
        typeof value.available!=='boolean'||value.routeVersion!==null&&(typeof value.routeVersion!=='string'||value.routeVersion.length>2048))throw new TypeError('Invalid profiler source');
      return {key:value.key,source:actor(value.source),kind:value.kind,available:value.available,
        routeVersion:value.routeVersion,label:String(value.label||value.kind).slice(0,256)};
    });
    if(new Set(values.map(value=>value.key)).size!==values.length||new Set(values.map(value=>actorKey(value.source))).size!==values.length)
      throw new TypeError('A profiler source can be selected once');
    const identityChanged=!sameActor(identity,this.identity),next=new Map();
    for(const value of values){
      const previous=this.sources.get(value.key),continued=previous&&sameActor(previous.source,value.source)&&previous.kind===value.kind;
      const reset=!continued||identityChanged||previous.available!==value.available||previous.routeVersion!==value.routeVersion;
      const Client=value.kind==='response'?ProfileReportClient:InputReportClient;
      const client=reset?new Client({identity,source:value.source,send:this.send,now:this.now}):previous.client;
      next.set(value.key,{...value,client,last:continued?previous.last:null,lastSeen:continued?previous.lastSeen:null,
        coverage:value.available?reset?'awaiting-fresh-report':previous.coverage:'unavailable'});
    }
    const signature=JSON.stringify([identity,values]);
    if(this.signature!==signature||!this.enabled)this.revision++;
    this.signature=signature;this.identity=identity;this.sources=next;this.enabled=true;
  }
  pump(){
    if(!this.enabled)return false;
    this.prune();const now=this.now(),available=[...this.sources.values()].filter(source=>source.available);
    if(!Number.isFinite(now)||now<this.nextQueryAt||!available.length)return false;
    // Two queries per second across the whole profiler, not per source. A
    // single source is additionally limited by its report client/serving bot.
    this.nextQueryAt=now+.5;
    const source=available[this.cursor++%available.length],queried=source.client.query();
    if(queried)this.metrics.queries++;return queried;
  }
  receive(message){
    if(!this.enabled||!['/agent/estimation/response','/agent/profile/response','/agent/profile/transfer'].includes(message.address))return false;
    try{
      const publisher=reportIdentity(message),source=[...this.sources.values()].find(value=>value.available&&sameActor(value.source,publisher));
      if(!source)return false;
      if(!source.client.receive(message))return false;
      const snapshot=source.client.snapshot();
      if(source.kind==='response'&&snapshot.profile?.decisions.some(decision=>this.conflicting(source,decision))){
        this.metrics.conflicts++;source.coverage='conflicting-report';this.revision++;return false;
      }
      source.last=snapshot;source.lastSeen=this.now();source.coverage=snapshot.coverage==='oversize'?'oversize':'snapshot';
      this.metrics.replies++;this.revision++;
      if(source.kind==='response'&&snapshot.profile)for(const decision of snapshot.profile.decisions)this.retain(source,decision);
      this.prune();return true;
    }catch{this.metrics.invalid++;return false;}
  }
  conflicting(source,decision){
    const key=JSON.stringify([actorKey(source.source),decision.id]),old=this.records.get(key)?.decision;
    return Boolean(old&&(JSON.stringify(old.timing)!==JSON.stringify(decision.timing)||
      old.snapshot&&decision.snapshot&&old.snapshot.digest!==decision.snapshot.digest||
      old.selection&&decision.selection&&JSON.stringify(old.selection)!==JSON.stringify(decision.selection)||
      decision.state!=='outside-retained-runtime'&&(old.snapshot&&!decision.snapshot||old.selection&&!decision.selection)));
  }
  retain(source,decision){
    if(typeof decision.id!=='string'||decision.id.length>2048||!decision.overplan||!decision.timing)return;
    decision=freeze(decision);
    const key=JSON.stringify([actorKey(source.source),decision.id]),old=this.records.get(key);
    if(this.conflicting(source,decision)){
      this.metrics.conflicts++;return;
    }
    // History expiry at the publisher does not retract its previously reported
    // final choice. Mark the loss of current coverage while retaining evidence.
    const missing=decision.state==='outside-retained-runtime';
    let retained=old&&missing?{...old.decision,state:'outside-retained-runtime'}:decision;
    if(old&&!missing){
      // A smaller publisher snapshot must not erase an execution already
      // observed here. Facts still carry their original recipient and clock.
      const facts=[...new Map([...(old.decision.facts||[]),...(decision.facts||[])].map(fact=>[JSON.stringify(fact),fact])).values()];
      retained={...decision,facts:facts.slice(-32),rendered:Boolean(old.decision.rendered||decision.rendered)};
    }
    const value=freeze({publisher:source.source,decision:retained});
    const bytes=new TextEncoder().encode(JSON.stringify(value)).length;
    if(bytes>PROFILE_LIMITS.historyBytes){this.metrics.evicted++;return;}
    if(old)this.bytes-=old.bytes;
    if(old&&JSON.stringify(old.decision)===JSON.stringify(value.decision))this.metrics.duplicates++;
    this.records.delete(key);this.records.set(key,{...value,bytes,receivedAt:this.now()});this.bytes+=bytes;
    this.prune();
  }
  prune(){
    const now=this.now(),evicted=this.metrics.evicted;
    for(const [key,record]of this.records)if(now-record.receivedAt>PROFILE_LIMITS.historySeconds){this.records.delete(key);this.bytes-=record.bytes;this.metrics.evicted++;}
    while(this.records.size>PROFILE_LIMITS.records||this.bytes>PROFILE_LIMITS.historyBytes){
      const [key,record]=this.records.entries().next().value;this.records.delete(key);this.bytes-=record.bytes;this.metrics.evicted++;
    }
    if(this.metrics.evicted!==evicted)this.revision++;
  }
  snapshot(){
    this.prune();const now=this.now();
    return freeze({version:1,kind:'ensemble-profile',observer:this.identity,revision:this.revision,enabled:this.enabled,
      capturedAt:now,timeDomain:'profiler-local-receipt-seconds',metrics:{...this.metrics},retainedBytes:this.bytes,
      sources:[...this.sources.values()].map(source=>{
        const data=source.coverage==='snapshot'&&source.available?source.client.snapshot():source.last;
        return {key:source.key,publisher:source.source,kind:source.kind,label:source.label,
          available:source.available,coverage:source.coverage,lastSeen:source.lastSeen,
          stale:!source.available||source.coverage!=='snapshot'||source.lastSeen===null||Boolean(data?.stale)||now-source.lastSeen>PROFILE_LIMITS.sourceTimeoutSeconds,
          data};
      }),
      history:[...this.records.values()].map(({publisher,decision,receivedAt})=>({publisher,decision,receivedAt})),
      limits:PROFILE_LIMITS,coverage:{scope:'selected publishers; current snapshots and bounded observed history',
        synchronizedSourceClocks:false,completeEventTrace:false,acousticOutputMeasured:false,
        missingMeaning:'Unobserved or unavailable is not musical silence.',futureMeaning:'Alternatives are mutually exclusive, not simultaneous notes.'}});
  }
  stop(){if(this.enabled)this.revision++;this.enabled=false;for(const source of this.sources.values()){source.available=false;source.coverage='stopped';}}
}
