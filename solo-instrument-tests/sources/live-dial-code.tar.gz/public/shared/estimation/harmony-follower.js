// The proposal stage for a performer's harmony: an opt-in policy that makes a
// performer's interpreted chord the ensemble's harmony.
//
// The plan keeps apart what pitch material is present (audio-chroma.js), which
// harmony explains it (the chord model), and which harmony a bot proposes (this).
// The ensemble already ranks harmony: every source publishes a harmony plan with
// a priority, the best unexpired plan leads, and followers ignore note pools from
// outranked sources (framework/agent.js, harmonyAuthority). So a performer leads
// by publishing a plan above the chord bots' priorities, revised at each confident
// change, with the chord as /broadcast/notepool.
//
// It proposes only on an interpreted chord. Ambiguity, unknown material and
// silence keep the last chord announced; it never broadcasts guesses. The
// GuitarSet held-out test adopted the estimator for input that carries the
// harmony, such as comping, and found it below a key-only guess on solo lines.
// Enable it for a source that plays the chords.
import {PlanCoordinator} from '../planning.js';
import {createHarmonicMemory,observeHarmony,predictChange,beatPosition,beatStart} from './harmonic-memory.js';
import {createHarmonicRhythm,assessChange,observeChange} from './harmonic-rhythm.js';
import {harmonyOrientation,orient as orientTo,chordsInCollection} from './harmony-orientation.js';
import {createLevelsFilter,observeLevels,levelsReport,chordEvidence} from './harmonic-levels-filter.js';

export const PERFORMER_HARMONY_PRIORITY=1;

export class HarmonyFollower {
  // dwellSeconds: a new chord must lead this long before it is announced, so a
  // passing neighbour at a change is not broadcast and then withdrawn.
  // anticipate (opt-in, in development): announce a change before it is heard, once the performer repeats themselves
  // (harmonic-memory.js): `lead` seconds before it is due, so a bot deciding a lookahead ahead plays it on time. The
  // chord being left is not announced again until `guardSeconds` after the change was due: the chord model hears the
  // new chord only once it has sounded. A different chord heard meanwhile is announced as usual. With
  // `labelAmbiguous`, the memory also hears the chord leading an ambiguous frame (not only an interpreted one): a
  // learned recognizer's leader is usually right before it is sure, and each beat's label is a vote over its frames.
  // pace (opt-in, in development): the harmonic rhythm sets how soon a change is believed. A switching Kalman filter
  // learns which of the performer's beats their chords change on (harmonic-rhythm.js), following a change of meter,
  // from the changes of root between their beats' labels (harmonic-memory.js: the chord that led each beat, to a chord
  // that held two beats), which a passing voicing rarely makes. A new chord heard `latencySeconds` after a point likelier
  // than `onGrid` to lie on that grid is announced at once; one likelier to be clutter (a passing voicing taken for
  // another chord) must lead for `dwellBeats` of the performer's beat first. Until `minChanges` changes have been
  // learned, dwellSeconds applies. Roots come from the vocabulary's pitch classes, in its own tuning.
  // remember: keep the harmonic memory without acting on it, for the forecasts a listening bot publishes (expectedChange,
  // forecasts.js). What the band hears is unchanged.
  // onBeats (opt-in, in development): chords change on the performer's beats, as a hidden Markov model over beats. Each
  // beat's evidence for a chord is the chord model's probability for it, averaged over the beat's frames. Between beats
  // a chord stays with a probability set by where the beat is: likely to change at a bar line (stay `bar`), less so at
  // a half bar (`half`), hardly at all within them (`beat`); `unknown` where the performer's bars are not known. The
  // belief is filtered forward beat by beat, and a new chord is announced as a beat ends once it is `confident`. So
  // changes come on the beat, mostly on bar lines, and a voicing that leads a frame or two does not move the band.
  // Beat-synchronous chord estimation with a metrical transition prior is how chord recognizers make harmonic rhythm
  // consistent (Mauch & Dixon 2010; Papadopoulos & Peeters 2011). Without a beat followed, dwellSeconds applies.
  // releaseSeconds: once the performer has been heard as no chord this long (silent, or noise to a listening that hears
  // it as none), their plan is withdrawn and the band's own harmony leads again, until their next chord leads once
  // more. A listening bot stands for a person who plays with the band; while they are silent it need not steer it.
  // orient (opt-in, in development): the band orients to the performer's harmony level by level (harmony-orientation.js
  // names the orientations, each a listener's tendency). A levels filter (harmonic-levels-filter.js) hears the scale,
  // from the chords heard or from the pitches given to update(). Between chords (the recognizer leads with another chord
  // than the one announced, and is not yet sure of it), the band plays the notes safe against the chords it may be,
  // rather than holding one it has heard contradicted; whichever chord is then sure is announced. With no chord heard
  // for `modeAfterSeconds` and scales heard, it plays their safe notes; a scale is a slow level, so a new set of them is
  // announced only once it has held `modeHoldSeconds` and differs from the one sounding by `modeChange` notes or more.
  // Each announcement carries the
  // orientation's graded weights as /broadcast/pcprob (where the tuning is 12-EDO). followChords false is for input
  // that carries lines, not chords (a soloist): a chord model's readings of a single line are guesses (the GuitarSet
  // held-out harmony test found them below a key-only guess on solos), so the band orients to the scale alone, and
  // announces its safe notes whenever the scale heard changes. Until the scale is heard, the chords guessed lead, rather
  // than none (the band's own harmony, in a key of its own).
  // followChords 'auto' (in development) tells lines from chords as it listens: over the last `windowSeconds` of
  // `autoLines`, the chord model's confident changes a second, less the pitch classes a chroma frame holds (its peaks, the
  // pitches given). A line makes a chord model change its mind often and sounds few pitch classes at once; chords, the
  // reverse. It starts with chords, turns to lines above `toLines` and back below `toChords`, once `minimumSeconds` have
  // been heard. On twenty GuitarSet development takes, whole, the comping scored -2.04 to -0.96 and the solos -0.74 to
  // 0.27 (fitted on those takes: not a held-out claim).
  // hedgeAt 'bar' hedges where chords change, not where the recognizer wavers: `hedgeLeadSeconds` before each bar line
  // of the performer's (the beat forecast's downbeats), the band plays the notes safe against staying on the chord held
  // (probability 1 - `changeProbability`) and moving to another chord of the scale; the chord then heard is announced,
  // the one held again if it stayed. A recognizer's wavering within the bar moves nothing. 'contradiction' hedges when
  // the recognizer leads with another chord than the one announced, not yet sure of it. 'none', the default, does not
  // hedge: on ten development comps, hedging on contradictions doubled the announcements (97 to 199) and before bar
  // lines more than doubled them (233), for three points less clash just after a change.
  constructor({author,vocabulary,register=48,priority=PERFORMER_HARMONY_PRIORITY,horizonPhrases=64,dwellSeconds=0,anticipate=null,pace=null,remember=false,onBeats=null,releaseSeconds=4,
    orient=null,modeAfterSeconds=1.5,modeHoldSeconds=2,modeChange=2,followChords=true,hedgeAt='none',hedgeLeadSeconds=.35,changeProbability=.5,
    autoLines={}}={}){
    if(typeof author!=='string'||!author||!vocabulary?.labels?.length)throw new TypeError('A harmony follower needs an author and a vocabulary');
    if(!(releaseSeconds>0))throw new TypeError('A harmony follower releases after a positive number of seconds');
    this.releaseSeconds=releaseSeconds;this.quietSince=null;this.released=null;
    this.coordinator=new PlanCoordinator(author);this.priority=priority;this.horizonPhrases=horizonPhrases;this.register=register;
    this.labels=new Map(vocabulary.labels.map(label=>[label.id,label.pitchClasses]));
    this.plan=null;this.current=null;this.announced=[];this.dwellSeconds=dwellSeconds;this.candidate=null;
    // A label's root: its first pitch class, in the vocabulary's own tuning.
    const rootOf=label=>this.labels.get(label)?.[0]??null;
    const {lead=.35,guardSeconds=.9,matchRoots=false,labelAmbiguous=false,...memory}=anticipate&&anticipate!==true?anticipate:{};
    if(!(lead>=0&&guardSeconds>=0))throw new TypeError('Invalid harmony anticipation');
    this.anticipation=anticipate?{lead,guardSeconds,forBeat:null,guard:null}:null;this.labelAmbiguous=Boolean(labelAmbiguous);
    const {dwellBeats=.75,onGrid=.5,minChanges=3,latencySeconds=.4,...rhythm}=pace&&pace!==true?pace:{};
    if(pace&&!(dwellBeats>=0&&onGrid>0&&onGrid<1&&Number.isInteger(minChanges)&&minChanges>=1&&latencySeconds>=0))throw new TypeError('Invalid harmony pace');
    this.pace=pace?{dwellBeats,onGrid,minChanges,latencySeconds,rhythm:createHarmonicRhythm(rhythm),learned:0}:null;
    this.memory=anticipate||pace||remember?createHarmonicMemory({...memory,...(matchRoots?{rootOf}:{})}):null;
    const {bar=.6,half=.8,beat=.97,unknown=.85,sharpness=3,confident=.6}=onBeats&&onBeats!==true?onBeats:{};
    if(onBeats&&![bar,half,beat,unknown].every(p=>p>0&&p<1)||onBeats&&!(sharpness>0&&confident>0&&confident<1))throw new TypeError('Invalid beat-synchronous harmony');
    this.onBeats=onBeats?{stay:{bar,half,beat,unknown},sharpness,confident,start:null,lastAt:null,held:null,evidence:new Map,weight:0,heard:0,belief:null}:null;
    this.rootOf=rootOf;this.lastAnticipated=null;this.chordVocabulary=vocabulary;
    if(orient!==null&&!(modeAfterSeconds>=0))throw new TypeError('Invalid harmony orientation timing');
    const orientation=orient?harmonyOrientation(orient):null;
    if(followChords!==true&&!orientation)throw new TypeError('A follower that does not follow chords orients to the scale: give it an orientation');
    if(![true,false,'auto'].includes(followChords))throw new TypeError('followChords is true, false or auto');
    const auto={windowSeconds:8,toLines:-.7,toChords:-1,minimumSeconds:6,...autoLines};
    if(!['none','contradiction','bar'].includes(hedgeAt)||!(hedgeLeadSeconds>=0&&changeProbability>=0&&changeProbability<=1))throw new TypeError('Invalid harmony hedging');
    this.orientation=orientation?{config:orientation,levels:createLevelsFilter(orientation.vocabulary),modeAfterSeconds,lastChordAt:null,hedgedFrom:null,mode:null,
      followChords:followChords!==false,auto:followChords==='auto'?{...auto,changes:0,peaks:0,frames:0,heard:0,at:null,leader:null}:null,
      hedgeAt,hedgeLeadSeconds,changeProbability,hedgedFor:null,modeHoldSeconds,modeChange,modeCandidate:null,modePool:null}:null;
    this.lastOrientation=null;
  }
  // The orientation's side of a tick: the levels heard, and what the band orients to. Returns messages to send, or null.
  // Lines or chords, as heard (followChords 'auto'): decayed counts over the window, and the switch between them.
  hearTexture(state,leader,now,pitches){
    const a=this.orientation.auto;if(!a||!Number.isFinite(now))return;
    const dt=a.at===null?0:Math.max(0,now-a.at),keep=Math.exp(-dt/a.windowSeconds);a.at=now;
    a.changes*=keep;a.peaks*=keep;a.frames*=keep;a.heard+=dt;
    const confident=state?.status==='interpreted'&&leader?leader.label:null;
    if(confident&&confident!==a.leader){if(a.leader!==null)a.changes++;a.leader=confident;}
    if(pitches?.length){a.peaks+=pitches.length;a.frames++;}
    if(a.heard<a.minimumSeconds||!a.frames)return;
    const rate=a.changes/a.windowSeconds,score=rate-a.peaks/a.frames;this.textureScore=score;
    if(this.orientation.followChords&&score>a.toLines){this.orientation.followChords=false;this.orientation.modePool=null;this.orientation.mode=null;}
    else if(!this.orientation.followChords&&score<a.toChords)this.orientation.followChords=true;
  }
  orientationStep(state,leader,now,{clock,at,pitches,beat=null}){
    const o=this.orientation,vocabulary=o.config.vocabulary;
    this.hearTexture(state,leader,now,pitches);
    if(Number.isFinite(now)&&(o.levels.at===null||now>=o.levels.at))
      o.levels=observeLevels(o.levels,vocabulary,pitches??chordEvidence(state,this.chordVocabulary),{at:now});
    const heard=o.followChords&&['interpreted','ambiguous'].includes(state?.status)?(state.candidates??[]).filter(c=>this.labels.has(c.label)&&c.score>0):[];
    if(heard.length)o.lastChordAt=now;
    const levels=levelsReport(o.levels,vocabulary);
    // The chords' whole mass (all of them, the ones a model's top-K leaves out included), so a truncated posterior does
    // not become a sure one (harmony-orientation.js orient, the audit's I09).
    const chordMass=Math.max(0,1-(Number(state?.noChord)||0));
    const decision=orientTo(o.config,{levels,chords:heard.map(c=>({label:c.label,pitchClasses:this.labels.get(c.label),probability:c.score})),chordVocabulary:this.chordVocabulary,chordMass});
    this.lastOrientation={...decision,at:now,levels};
    // At a bar line to come: between staying and moving to another chord of the scale.
    if(o.hedgeAt==='bar'&&o.followChords&&this.labels.has(this.current)&&beat?.periodSeconds>0&&Number.isFinite(beat?.downbeatAt)&&beat.beatsPerBar>1&&decision.scale){
      const bar=beat.beatsPerBar*beat.periodSeconds,next=beat.downbeatAt+Math.ceil((now-beat.downbeatAt)/bar-1e-9)*bar,key=Math.round(next*20);
      if(next-now<=o.hedgeLeadSeconds&&o.hedgedFor!==key){
        o.hedgedFor=key;
        const scale=vocabulary.layers.flatMap(layer=>layer.sets).find(set=>set.id===decision.scale);
        const others=chordsInCollection(o.config,scale,this.chordVocabulary).filter(label=>label.id!==this.current);
        const distribution=[{label:this.current,pitchClasses:this.labels.get(this.current),probability:1-o.changeProbability},
          ...others.map(label=>({label:label.id,pitchClasses:label.pitchClasses,probability:o.changeProbability/others.length}))];
        const ahead=orientTo(o.config,{levels,chords:distribution,chordVocabulary:this.chordVocabulary});
        if(ahead.pool.length){o.hedgedFrom=this.current;return this.announcePool(ahead.pool,{kind:'hedge',weights:ahead.weights,clock,at});}
      }
    }
    // Between chords: the chord announced contradicted, its successor not yet sure.
    if(o.hedgeAt==='contradiction'&&decision.level==='hedge'&&leader&&this.current!==null&&this.current!=='hedge'&&this.current!=='mode'&&leader.label!==this.current&&decision.pool.length){
      o.hedgedFrom=this.current;return this.announcePool(decision.pool,{kind:'hedge',weights:decision.weights,clock,at});}
    // No chord for a while, scales heard: their safe notes, once they have held and differ enough from those sounding.
    if(decision.level==='mode'&&decision.pool.length&&(o.lastChordAt===null||now-o.lastChordAt>=o.modeAfterSeconds)){
      if(o.modeCandidate?.scale!==decision.scale)o.modeCandidate={scale:decision.scale,since:now};
      const sounding=o.modePool??[],differ=decision.pool.filter(pc=>!sounding.includes(pc)).length+sounding.filter(pc=>!decision.pool.includes(pc)).length;
      if(now-o.modeCandidate.since>=o.modeHoldSeconds&&(this.current!=='mode'||differ>=o.modeChange)){
        o.mode=decision.scale;o.modePool=[...decision.pool];return this.announcePool(decision.pool,{kind:'mode',weights:decision.weights,clock,at});}
    }
    // Not following chords: nothing more, once the scale is oriented to; before, the chords guessed.
    return o.followChords||o.modePool===null?null:[];
  }
  // The next change the memory expects, for a forecast (forecasts.js): what the performer did one cycle ago. Nothing here
  // acts on it; null without a memory (anticipate, pace or remember).
  expectedChange(beat){return this.memory?predictChange(this.memory,{beat}):null}
  // Anticipation's side of a tick: a change the memory predicts within the lead is returned as the chord to announce
  // now. Returns {label} to announce, {hold: true} to keep the anticipated chord against the one being left, or null.
  anticipationStep(state,leader,now,beat){
    const a=this.anticipation;
    if(a.guard){
      if(now>a.guard.until)a.guard=null;
      else if(leader?.label===a.guard.from)return {hold:true};
    }
    const prediction=predictChange(this.memory,{beat});
    if(!prediction||prediction.beat===a.forBeat||prediction.label===this.current||prediction.from!==this.current)return null;
    if(!(now>=prediction.changeAt-a.lead&&now<prediction.changeAt))return null;
    a.forBeat=prediction.beat;a.guard={from:this.current,until:prediction.changeAt+a.guardSeconds};
    return {label:prediction.label,prediction};
  }
  // A chord named in twelve classes, voiced in the tuning heard: where the chroma (in quarter tones) peaks between the
  // keys within a quarter tone of one of its tones, more strongly than on the tone itself, the tone is the one heard. A
  // drone's neutral third is named minor or major by the chord model, and voiced as it sounds. With twelve classes,
  // nothing lies between the keys, and the voicing is the chord's.
  tunedVoicing(label){
    const pitches=this.voicing(label),heard=this.heardPitches??[],between=value=>Math.abs(value-Math.round(value))>=.25;
    if(!heard.some(p=>between(p.pc)))return pitches;
    const offset=(a,b)=>{const d=((a-b)%12+12)%12;return d>6?d-12:d};
    return pitches.map(pitch=>{
      const onKey=heard.find(p=>Math.abs(offset(p.pc,pitch))<.1),near=heard.filter(p=>between(p.pc)&&Math.abs(offset(p.pc,pitch))<=.5).sort((a,b)=>b.weight-a.weight)[0];
      return near&&(!onKey||near.weight>onKey.weight)?pitch+offset(near.pc,pitch):pitch;
    });
  }
  // A close voicing from the register up: the root, the other chord tones above
  // it within the octave, and the root again an octave higher.
  voicing(label){
    const [root,...rest]=this.labels.get(label),base=this.register+root;
    return [base,...rest.map(pc=>base+((pc-root+12)%12)),base+12].sort((a,b)=>a-b);
  }
  // The messages to send before this tick: none, or a revised plan and the chord in the forms a chord bot sends it --
  // the chord list and its duration (a phrase), the note pool and the pitch-class weights. Followers play from
  // different ones: PadBot plays the chord list and only re-voices on a pool, so a performer who sent only a pool
  // left the pad on a chord bot's progression.
  // beat: the performer's beat forecast ({expectedTime, periodSeconds}), which anticipation places changes on.
  update(state,{clock={},at=null,beat=null,pitches=null}={}){
    const leader=state?.candidates?.[0];
    if(pitches)this.heardPitches=pitches;
    // The evidence time, when the model states one; otherwise the caller's clock.
    const now=Number.isFinite(state?.at)?state.at:at;
    // Silence is timed on the caller's clock: a MIDI model states no new time while no note is played.
    const quietAt=Number.isFinite(at)?at:now;
    if(state?.status==='nonchordal/no-chord'){
      this.quietSince??=quietAt;
      if(this.current!==null&&this.plan&&quietAt-this.quietSince>=this.releaseSeconds){this.candidate=null;return this.release({clock,at:quietAt});}
    }else if(state)this.quietSince=null;
    // The chord the model hears is remembered on the performer's beats, in time order: a recognizer that answers
    // behind the audio states its chords at their own (earlier) times.
    const heard=state?.status==='interpreted'||this.labelAmbiguous&&state?.status==='ambiguous';
    if(this.memory&&Number.isFinite(now)&&(this.memory.at===null||now>=this.memory.at)){this.memory=observeHarmony(this.memory,{at:now,beat,
      label:heard&&leader&&this.labels.has(leader.label)?leader.label:null});if(this.pace)this.learnRhythm();}
    if(this.orientation){const messages=this.orientationStep(state,leader,now,{clock,at,pitches,beat});if(messages){this.candidate=null;return messages;}}
    if(this.anticipation&&Number.isFinite(now)){
      const step=this.anticipationStep(state,leader,now,beat);
      if(step?.hold){this.candidate=null;return [];}
      if(step?.label){this.candidate=null;this.lastAnticipated={at,label:step.label,changeAt:step.prediction.changeAt,cycle:step.prediction.cycle,agreement:step.prediction.agreement};
        return this.announce(step.label,{clock,at,anticipated:true});}
    }
    if(this.onBeats&&beat?.periodSeconds>0&&Number.isFinite(beat.expectedTime)&&Number.isFinite(now))return this.beatStep(state,now,beat,clock,at);
    if(state?.status!=='interpreted'||!leader||!this.labels.has(leader.label)||leader.label===this.current){this.candidate=null;return [];}
    if(this.candidate?.label!==leader.label)this.candidate={label:leader.label,since:now,dwell:this.dwellFor(now,beat)};
    if(!(now-this.candidate.since>=this.candidate.dwell-1e-9))return [];
    this.candidate=null;
    return this.announce(leader.label,{clock,at,score:leader.score});
  }
  // Beat-synchronous changes (onBeats): this frame's chord probabilities added to its beat's evidence; when a beat ends,
  // the belief filtered one beat on, and its chord announced if new and confident.
  // beat: {expectedTime, periodSeconds, beatsPerBar?, downbeatAt?}.
  // A beat is known by where it starts on the forecast's grid (harmonic-memory.js beatStart), which is the same
  // whichever of the grid's beats the forecast is stated from. It was known by floor((now - expectedTime) / period),
  // and a forecast stated from the next beat (as trackers state it) kept that at -1 however many beats went by, so
  // the belief never moved (the mathematical audit's E11). A beat ends once the grid has moved on half a beat past
  // its start. The transition a beat's evidence meets is the one into that beat, by where it starts in the bar; the
  // transition into the next beat had been used, a beat late, so a change on a downbeat met a within-bar prior.
  beatStep(state,now,beat,clock,at){
    const sync=this.onBeats,period=beat.periodSeconds,labels=[...this.labels.keys()],started=beatStart(now,beat);
    let announce=null;
    if(sync.start===null)sync.start=started;
    // The frame before this one stands until this one, at most a beat: its chord probabilities (none, where it heard no
    // chord) for the seconds it stood, in the beat it stood in. So a beat is weighed by time, not by how often it was
    // polled, and a frame repeated at the same moment adds nothing (the audit's E11, "weight frame evidence by
    // duration"). A beat's evidence for a chord is its probability averaged over the time chords were heard in the
    // beat, weighed by the share of the beat that was (below): a frame or two flickering to a chord in a beat of noise
    // is a little evidence, not the whole beat's. Beats skipped between two frames, beyond the frame's beat of
    // standing, are not heard.
    const from=sync.lastAt,to=from===null?null:Math.min(now,from+period);
    const hear=(a,b)=>{if(!(b>a))return;sync.heard+=b-a;if(!sync.held)return;
      for(const [label,score] of sync.held)sync.evidence.set(label,(sync.evidence.get(label)??0)+score*(b-a));sync.weight+=b-a;};
    if(started>sync.start+period/2){
      if(from!==null)hear(from,Math.min(to,Math.min(started,sync.start+period)));
      // A beat with no chord heard (silence, noise heard as no chord, a gap) leaves the belief as it was.
      if(sync.weight>0){
        const barLength=beat.beatsPerBar>1&&Number.isFinite(beat.downbeatAt)?beat.beatsPerBar:null;
        // Where the beat that ended began in the bar: a chord is likelier to change on a bar line, or a half bar.
        let stay=sync.stay.unknown;
        if(barLength){const position=((((sync.start-beat.downbeatAt)/period)%barLength)+barLength)%barLength,near=target=>Math.min(Math.abs(position-target),barLength-Math.abs(position-target))<.25;
          stay=near(0)?sync.stay.bar:barLength>=4&&barLength%2===0&&near(barLength/2)?sync.stay.half:sync.stay.beat;}
        // Normalized in log space, and one label persisting as itself (the audit's E11). The evidence is tempered by the
        // share of the beat heard as chords at all: a beat heard as chords throughout counts in full, one heard as noise
        // but for a flicker counts that much, so noise cannot walk the belief to a chord a flicker at a time. Measured
        // (test/audit-estimation.test.mjs): with 15% of noise frames flickering to a random chord, no false announcement
        // in forty noise sections over twenty seeds, and every chord announced a beat after it began; with 20%, one.
        // A no-chord state that tells noise (evidence of no chord) from silence (no evidence) would close that, at the
        // cost of care for sparse playing, which looks like silence between its chords.
        const n=labels.length,belief=sync.belief??new Map(labels.map(label=>[label,1/n])),share=Math.min(1,sync.weight/sync.heard);
        const logs=labels.map(label=>{
          const was=belief.get(label)??0,prior=n>1?stay*was+(1-stay)*(1-was)/(n-1):was,evidence=(sync.evidence.get(label)??0)/sync.weight;
          return Math.log(prior)+share*sync.sharpness*Math.log(evidence+.02);
        });
        const top=Math.max(...logs),weights=logs.map(log=>Number.isFinite(top)?Math.exp(log-top):1),total=weights.reduce((a,b)=>a+b,0);
        const next=new Map(labels.map((label,i)=>[label,weights[i]/total]));
        sync.belief=next;
        let best=null,most=0;for(const [label,value] of next)if(value>most){most=value;best=label}
        if(best!==this.current&&most>=sync.confident)announce=best;
      }
      sync.evidence.clear();sync.weight=0;sync.heard=0;sync.start=started;
      if(from!==null)hear(Math.max(from,started),to);
    }else if(from!==null)hear(from,to);
    // This frame stands from now: the chords it heard, with their probabilities, or none.
    const heard=state?.status==='interpreted'||state?.status==='ambiguous'?(state.candidates??[]).filter(candidate=>this.labels.has(candidate.label)):[];
    sync.held=heard.length?new Map(heard.map(candidate=>[candidate.label,candidate.score])):null;
    sync.lastAt=from===null?now:Math.max(now,from);
    this.candidate=null;
    return announce?this.announce(announce,{clock,at}):[];
  }
  // How long a new chord must lead before it is announced: dwellSeconds, or, pacing on a known harmonic rhythm,
  // nothing when it is likely on the rhythm's grid and dwellBeats of the performer's beat when it is likely clutter.
  dwellFor(now,beat){
    const pace=this.pace;
    if(!pace||!(beat?.periodSeconds>0)||!Number.isFinite(now))return this.dwellSeconds;
    const position=beatPosition(this.memory,now-pace.latencySeconds,beat);
    if(position===null||pace.rhythm.changes<pace.minChanges)return this.dwellSeconds;
    return assessChange(pace.rhythm,position).onGrid>=pace.onGrid?0:pace.dwellBeats*beat.periodSeconds;
  }
  // The harmonic rhythm learns from each beat label newly held two beats: a change of root there is a change heard on
  // that beat.
  learnRhythm(){
    const pace=this.pace,{labels,first}=this.memory;
    if(pace.learned<first)pace.learned=first;
    for(;pace.learned+1<first+labels.length;pace.learned++){
      const i=pace.learned-first;
      if(i<1||labels[i]===null||labels[i-1]===null||labels[i+1]!==labels[i])continue;
      const root=this.rootOf(labels[i]);
      if(root!==null&&root!==this.rootOf(labels[i-1])&&(pace.rhythm.at===null||pace.learned>pace.rhythm.at))pace.rhythm=observeChange(pace.rhythm,pace.learned).rhythm;
    }
  }
  // The performer's plan withdrawn: revised to expire where it stands, so the band's own harmony leads again.
  release({clock={},at=null}={}){
    const position={bar:clock.bar??0,phrase:clock.phrase??0,section:0};
    this.plan=this.coordinator.revise(this.plan,this.plan.payload,{createdAt:position,appliesAt:position,expiresAt:position,confidence:.01,
      rationale:'The performer is silent: their harmony no longer leads.'});
    this.released={at,label:this.current,revision:this.plan.revision};this.current=null;
    return [{address:'/broadcast/plan',args:[this.plan]}];
  }
  // Notes the band orients to without a chord (a hedge between chords, or a scale's safe notes), as the performer's
  // plan: voiced from the strongest up, within an octave, with the orientation's weights.
  announcePool(pitchClasses,{kind,weights=[],clock={},at=null}={}){
    const base=this.register+pitchClasses[0],pitches=[base,...pitchClasses.slice(1).map(pc=>base+((pc-pitchClasses[0])%12+12)%12)].sort((a,b)=>a-b);
    const position={bar:clock.bar??0,phrase:clock.phrase??0,section:0},phraseBars=clock.meter?.phraseBars||8;
    const payload={schemaVersion:1,chords:[pitches],durations:[1],source:'performer-harmony',label:kind,pitchClasses:[...pitchClasses]};
    const options={createdAt:position,appliesAt:position,expiresAt:{bar:position.bar+this.horizonPhrases*phraseBars,phrase:position.phrase+this.horizonPhrases,section:0},
      horizon:this.horizonPhrases,confidence:.5,priority:this.priority,rationale:kind==='hedge'?'Between the performer\'s chords: notes safe against the chords it may be.':'The performer\'s scale, with no chord heard: its safe notes.'};
    this.plan=this.plan?this.coordinator.revise(this.plan,payload,options):this.coordinator.create('harmony',payload,options);
    this.current=kind;this.announced.push({at,label:kind,pitchClasses:[...pitchClasses],revision:this.plan.revision});
    if(this.announced.length>256)this.announced.shift();
    const beats=(clock.meter?.pulsesPerBar&&clock.meter?.subdivision?clock.meter.pulsesPerBar/clock.meter.subdivision:4)*phraseBars;
    return [{address:'/broadcast/plan',args:[this.plan]},{address:'/broadcast/plan/chords',args:[pitches.join(' ')]},
      {address:'/broadcast/plan/chordDuration',args:[beats]},{address:'/broadcast/notepool',args:pitches},...this.weightsMessage(weights)];
  }
  // The orientation's graded weights as /broadcast/pcprob, where they are twelve pitch classes of 12-EDO.
  weightsMessage(weights){
    if(!weights.length||weights.length!==12||weights.some((w,i)=>Math.abs(w.pc-i)>1e-6))return [];
    const top=Math.max(...weights.map(w=>w.weight),1e-9);return [{address:'/broadcast/pcprob',args:weights.map(w=>Math.max(0,w.weight)/top)}];
  }
  // A chord as the performer's plan: the revised plan, the chord list and its duration, the note pool and weights.
  announce(label,{clock={},at=null,anticipated=false,score=.5}={}){
    const leader={label,score},pitches=this.tunedVoicing(label),position={bar:clock.bar??0,phrase:clock.phrase??0,section:0};
    const payload={schemaVersion:1,chords:[pitches],durations:[1],source:'performer-harmony',label,...(anticipated?{anticipated:true}:{})};
    // Positions compare by absolute bar first (planning.js), so the expiry advances the bar too. It once advanced
    // only the phrase: every performer plan expired a bar after it was made, and a chord bot's plan led instead.
    const phraseBars=clock.meter?.phraseBars||8,expiresAt={bar:position.bar+this.horizonPhrases*phraseBars,phrase:position.phrase+this.horizonPhrases,section:0};
    const options={createdAt:position,appliesAt:position,expiresAt,horizon:this.horizonPhrases,
      confidence:Math.max(.01,Math.min(1,leader.score)),priority:this.priority,
      rationale:anticipated?'A performer chord, anticipated from the progression they repeat.':'A performer chord, heard and interpreted from their playing.'};
    this.plan=this.plan?this.coordinator.revise(this.plan,payload,options):this.coordinator.create('harmony',payload,options);
    this.current=leader.label;this.announced.push({at,label:leader.label,revision:this.plan.revision});
    if(this.orientation){this.orientation.hedgedFrom=null;this.orientation.mode=null;}
    if(this.announced.length>256)this.announced.shift();
    const beats=(clock.meter?.pulsesPerBar&&clock.meter?.subdivision?clock.meter.pulsesPerBar/clock.meter.subdivision:4)*phraseBars;
    const classes=new Set(this.labels.get(leader.label)),weights=Array.from({length:12},(_,pc)=>classes.has(pc)?1:0);
    const graded=this.orientation&&this.lastOrientation?.level==='chord'?this.weightsMessage(this.lastOrientation.weights):[];
    return [{address:'/broadcast/plan',args:[this.plan]},{address:'/broadcast/plan/chords',args:[pitches.join(' ')]},
      {address:'/broadcast/plan/chordDuration',args:[beats]},{address:'/broadcast/notepool',args:pitches},...(graded.length?graded:[{address:'/broadcast/pcprob',args:weights}])];
  }
}
