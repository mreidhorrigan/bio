// ae_AudioAnalyzerBOT's descriptors, as its patch computes them, for a page and a render (RESEARCH_BACKLOG, the second
// queue's "`ae_AudioAnalyzerBOT`'s descriptors"): their analysis from samples, sent under the routing's names. Their
// schema, the routing and the reader a bot reads them by name with are audio-descriptor-schema.js's, re-exported here. From the patch (Archive/pre-LLM-era/Musebots/ae_AudioAnalyzerBOT/
// ae_AudioAnalyzerBOT.maxpat; Arne Eigenfeldt, July 2016), which "analyses an incoming audio signal for specific
// features. Allows redirecting features as musebot messages":
//   centroid  zsa.easy_centroid~ 1024 8, read every 100 ms (number~), the median of its last 10 readings, placed in the
//             range of its last block of 512 (20 to 4000 Hz until the first) -- p smoothing;
//   loudness  meter~'s peak every 50 ms, the median of its last 5, on a log curve, placed in the range of its last block
//             of 256 -- p smoothing. The curve (myLogCurve) is not in the archive: decibels here, ours;
//   activity  every 50 ms the sound is active once its loudness passes its own mean of the last 5 s (0.1 until it has
//             one), and until it falls under 0.01; activity is the share of the last 2 s it was -- p sparse/active.
//             Falling to none, the patch says /broadcast/statechange "any": the player has stopped;
//   flux      zsa.easy_flux~ 1024 4, read every 100 ms, the median of its last 10 -- p smoothing. Zsa's scaling is not
//             recorded; here Peeters' spectral variation (1 less the cosine between successive spectra, 0 to 1), ours;
//   speed     an attack is a fast envelope (slide~ 10 4410 of |x|) rising above a slow one (slide~ 1000 1 of it) by the
//             attack and release thresholds together (3 + 1 dB), and ending when it falls back under the attack
//             threshold, at most one in 80 ms: so the patch wires its three settings. Each second, 1 less the mean time
//             between attacks, in seconds, clipped to 0-1, ramped to over the next second -- p slow/fast;
//   bark      zsa.easy_bark~ 1024 8, its 25 bands averaged each second -- p bark_analysis_averaging. Each band here in
//             decibels under the loudest, over 60 dB (Zsa's own scaling is its), ours.
// The five go out clipped to 0-1 at most every 250 ms (p gather's speedlim 250), each under the name its "map ... to:"
// menu chooses: centroid, loudness, activity, flux, speed, arousal or valence. The patch's own choices (its loadmess
// defaults): centroid and loudness as themselves, speed as activity, activity as arousal, flux as valence. The Bark bands
// go out each second as barkenergy. Lengths in samples are the patch's, at whatever rate the input has.
import {fftInPlace} from '../grains/fft.js';
import {DEFAULT_ROUTING,DESCRIPTOR_NAMES,analyzerRouting} from './audio-descriptor-schema.js';

export * from './audio-descriptor-schema.js';

// The patch's lengths and its settings' values.
export const ANALYZER=Object.freeze({
  windowSamples:1024,centroidHopSamples:128,fluxHopSamples:256,barkHopSamples:128,
  readSeconds:.1,meterSeconds:.05,sendSeconds:.25,barkSeconds:1,
  centroidMedian:10,centroidBlock:512,centroidHz:Object.freeze([20,4000]),
  loudnessMedian:5,loudnessBlock:256,loudnessFloorDb:-60,
  activitySeconds:.05,activityWindow:40,activityMeanSeconds:5,activityStart:.1,activityFloor:.01,
  fluxMedian:10,
  fastSlide:Object.freeze([10,4410]),slowSlide:Object.freeze([1000,1]),attackDb:3,releaseDb:1,gateSeconds:.08,speedSeconds:1,
  barkRangeDb:60,
});
// Zwicker's critical bands, 25 as Zsa's bark~ reports them: each band's upper edge in Hz, the last to the Nyquist.
export const BARK_EDGES=Object.freeze([100,200,300,400,510,630,770,920,1080,1270,1480,1720,2000,2320,2700,3150,3700,4400,5300,
  6400,7700,9500,12000,15500,Infinity]);

const median=values=>{const sorted=[...values].sort((a,b)=>a-b),middle=sorted.length>>1;return sorted.length%2?sorted[middle]:(sorted[middle-1]+sorted[middle])/2};
const clip=value=>Math.max(0,Math.min(1,value));
const toDb=value=>20*Math.log10(Math.max(value,1e-9));
// Placed in a range taken from blocks of values (the patch's zl group -> statlist): until the first block, the initial.
class BlockRange {
  constructor(size,[low,high]){Object.assign(this,{size,low,high,block:[]});}
  place(value){
    this.block.push(value);
    if(this.block.length>=this.size){this.low=Math.min(...this.block);this.high=Math.max(...this.block);this.block=[];}
    return this.high>this.low?clip((value-this.low)/(this.high-this.low)):0;
  }
}
// slide~: each sample moves 1/up of the way toward a rising input, 1/down toward a falling one.
const slide=(y,x,[up,down])=>y+(x-y)/(x>y?up:down);

// The analysis: samples in, in order, at the input's rate; out, the messages that came due in them, each {at, name,
// value} (at: seconds from the first sample), under the routing's names.
export class AudioDescriptorAnalysis {
  constructor({sampleRate,routing=DEFAULT_ROUTING,attackDb=ANALYZER.attackDb,releaseDb=ANALYZER.releaseDb,gateSeconds=ANALYZER.gateSeconds,choices=ANALYZER}={}){
    if(!(sampleRate>0))throw new TypeError('An analysis needs its input\'s sample rate');
    for(const [label,value,low,high] of [['attack threshold',attackDb,0,24],['release threshold',releaseDb,0,24],['gate',gateSeconds,0,2]])
      if(!(Number.isFinite(value)&&value>=low&&value<=high))throw new RangeError(`The ${label} is ${low} to ${high}`);
    Object.assign(this,{sampleRate,choices,attackDb,releaseDb,gateSeconds});this.routing=analyzerRouting(routing);
    const size=choices.windowSamples;
    this.ring=new Float64Array(size);this.filled=0;this.written=0;this.n=0;
    this.hann=Float64Array.from({length:size},(_,i)=>.5-.5*Math.cos(2*Math.PI*i/size));
    this.re=new Float64Array(size);this.im=new Float64Array(size);this.previousSpectrum=null;
    const binHz=sampleRate/size;
    this.bands=Array.from({length:size/2},(_,k)=>BARK_EDGES.findIndex(edge=>k*binHz<edge));
    // The latest of each, read by the patch's clocks; their smoothings; its sends' clock.
    this.centroidHz=0;this.fluxNow=0;this.centroidReadings=[];this.fluxReadings=[];this.loudnessReadings=[];
    this.centroidRange=new BlockRange(choices.centroidBlock,choices.centroidHz);this.loudnessRange=new BlockRange(choices.loudnessBlock,[0,1]);
    this.values={centroid:0,loudness:0,activity:0,flux:0,speed:0};this.bark=new Array(BARK_EDGES.length).fill(0);
    this.barkSum=new Float64Array(BARK_EDGES.length);this.barkFrames=0;
    // Activity: its state, its last 2 s, its threshold from the loudness's means of the last seconds.
    this.active=0;this.states=[];this.second={loudness:[]};this.loudnessMeans=[];this.upper=choices.activityStart;
    // Speed: the envelopes, the attack state, the times between attacks this second, and the ramp.
    this.fast=0;this.slow=0;this.attacking=false;this.lastAttack=null;this.gateUntil=-Infinity;this.spacings=[];this.attacks=0;
    this.ramp={from:0,to:0,at:0};this.meterPeak=0;
    this.next={read:choices.readSeconds,meter:choices.meterSeconds,activity:choices.activitySeconds,send:choices.sendSeconds,bark:choices.barkSeconds,second:1};
  }
  // The time of the sample being read, in seconds from the first.
  get time(){return this.n/this.sampleRate}
  push(samples){
    const out=[],{choices}=this;
    for(let i=0;i<samples.length;i++){
      const x=Number.isFinite(samples[i])?samples[i]:0;
      this.ring[this.written]=x;this.written=(this.written+1)%this.ring.length;if(this.filled<this.ring.length)this.filled++;
      this.n++;
      this.envelope(x);
      this.meterPeak=Math.max(this.meterPeak,Math.abs(x));
      if(this.n%choices.centroidHopSamples===0)this.spectrum();
      this.clocks(out);
    }
    return out;
  }
  // The fast and slow envelopes and their difference in decibels: an attack, gated.
  envelope(x){
    const {choices}=this,time=this.time;
    this.fast=slide(this.fast,Math.abs(x),choices.fastSlide);this.slow=slide(this.slow,this.fast,choices.slowSlide);
    const difference=toDb(this.fast)-toDb(this.slow),high=this.attackDb+this.releaseDb,low=this.attackDb;
    if(!this.attacking&&difference>high){
      this.attacking=true;
      if(time>=this.gateUntil){
        if(this.lastAttack!==null)this.spacings.push(time-this.lastAttack);
        this.lastAttack=time;this.gateUntil=time+this.gateSeconds;this.attacks++;
      }
    }else if(this.attacking&&difference<low)this.attacking=false;
  }
  // Every hop: the centroid and the Bark bands from one windowed spectrum; every other, the flux against the spectrum a
  // flux hop before.
  spectrum(){
    const {choices,ring,re,im,hann}=this,size=ring.length;
    if(this.filled<size)return;
    for(let i=0;i<size;i++){re[i]=ring[(this.written+i)%size]*hann[i];im[i]=0;}
    fftInPlace(re,im);
    const half=size/2,amplitude=new Float64Array(half),binHz=this.sampleRate/size;
    let weighted=0,total=0;
    for(let k=0;k<half;k++){
      const a=Math.hypot(re[k],im[k]);amplitude[k]=a;weighted+=a*k*binHz;total+=a;
      const band=this.bands[k];if(band>=0)this.barkSum[band]+=a*a;
    }
    this.barkFrames++;
    if(total>0)this.centroidHz=weighted/total;
    if(this.n%choices.fluxHopSamples===0){
      if(this.previousSpectrum){
        let dot=0,a2=0,b2=0;
        for(let k=0;k<half;k++){dot+=amplitude[k]*this.previousSpectrum[k];a2+=amplitude[k]**2;b2+=this.previousSpectrum[k]**2;}
        this.fluxNow=a2>0&&b2>0?clip(1-dot/Math.sqrt(a2*b2)):a2>0||b2>0?1:0;
      }
      this.previousSpectrum=amplitude;
    }
  }
  // The patch's clocks, at their times: readings, the meter, activity, the sends, the Bark average, each second.
  clocks(out){
    const {choices,next}=this,time=this.time;
    if(time>=next.meter){
      next.meter+=choices.meterSeconds;
      const peak=this.meterPeak;this.meterPeak=0;
      this.loudnessReadings.push(peak);if(this.loudnessReadings.length>choices.loudnessMedian)this.loudnessReadings.shift();
      const curved=clip((toDb(median(this.loudnessReadings))-choices.loudnessFloorDb)/-choices.loudnessFloorDb);
      this.values.loudness=this.loudnessRange.place(curved);
    }
    if(time>=next.activity){
      next.activity+=choices.activitySeconds;
      const loudness=this.values.loudness;
      if(loudness>this.upper)this.active=1;else if(loudness<choices.activityFloor)this.active=0;
      this.states.push(this.active);if(this.states.length>choices.activityWindow)this.states.shift();
      const was=this.values.activity;
      this.values.activity=this.states.reduce((sum,value)=>sum+value,0)/choices.activityWindow;
      if(was>0&&this.values.activity===0)out.push({at:time,name:'statechange',value:'any'});
    }
    if(time>=next.read){
      next.read+=choices.readSeconds;
      this.centroidReadings.push(this.centroidHz);if(this.centroidReadings.length>choices.centroidMedian)this.centroidReadings.shift();
      this.values.centroid=this.centroidRange.place(median(this.centroidReadings));
      this.fluxReadings.push(this.fluxNow);if(this.fluxReadings.length>choices.fluxMedian)this.fluxReadings.shift();
      this.values.flux=clip(median(this.fluxReadings));
      this.second.loudness.push(this.values.loudness);
    }
    if(time>=next.second){
      next.second+=1;
      // The loudness's mean this second, and over the last 5: where activity begins.
      if(this.second.loudness.length){
        this.loudnessMeans.push(this.second.loudness.reduce((a,b)=>a+b,0)/this.second.loudness.length);
        if(this.loudnessMeans.length>choices.activityMeanSeconds)this.loudnessMeans.shift();
        this.upper=this.loudnessMeans.reduce((a,b)=>a+b,0)/this.loudnessMeans.length;
      }
      this.second.loudness=[];
      // Speed: this second's spacings, if any, set the next ramp.
      if(this.spacings.length){
        const mean=this.spacings.reduce((a,b)=>a+b,0)/this.spacings.length;
        this.ramp={from:this.speedAt(time),to:1-clip(mean),at:time};this.spacings=[];
      }
    }
    this.values.speed=this.speedAt(time);
    if(time>=next.send){
      next.send+=choices.sendSeconds;
      for(const name of DESCRIPTOR_NAMES)out.push({at:time,name:this.routing[name],value:clip(this.values[name]),descriptor:name});
    }
    if(time>=next.bark){
      next.bark+=choices.barkSeconds;
      if(this.barkFrames){
        const energy=Array.from(this.barkSum,value=>value/this.barkFrames),loudest=Math.max(...energy);
        this.bark=energy.map(value=>loudest>0?clip(1+(10*Math.log10(Math.max(value,1e-30)/loudest))/choices.barkRangeDb):0);
        out.push({at:time,name:'barkenergy',value:[...this.bark],descriptor:'bark'});
      }
      this.barkSum.fill(0);this.barkFrames=0;
    }
  }
  speedAt(time){const {from,to,at}=this.ramp,share=clip((time-at)/this.choices.speedSeconds);return from+(to-from)*share}
  // Where each stands now, by descriptor name.
  read(){return {...this.values,bark:[...this.bark]}}
}
