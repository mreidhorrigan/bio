import {frozenJson,identifier,knownFields} from '../planning-data.js';
import {createRandomStream} from '../../random-source.js';
import {planCalibrationTrials,prepareCalibrationTolerance,certifyCalibrationTolerance,checkCalibrationTolerance} from '../conducting/calibration-tolerance.js';
import {sha256} from '../bounded-exact.js';

// Loopback calibration of the one constant a performer's phase cannot reveal by
// itself (plan: "a constant latency and a constant musical phase offset can be
// observationally indistinguishable").
//
// A performer hears the ensemble through its output path and plays along; the
// input path then delays their onsets again. Aligning the ensemble's scheduled
// beats with the performer's needs that whole offset: scheduled output to
// captured input. Two measurements give it:
//   loopback / acoustic-loopback  clicks go out through the ensemble's output path
//                                 and return through the input path (a cable, an
//                                 IAC bus, speaker to microphone): the technical
//                                 round trip, never negative;
//   tap-along                     the performer taps with clicks heard through the
//                                 real output: the round trip plus their own
//                                 anticipation (people tap 20-50 ms early), which
//                                 is the offset alignment needs, and may be negative.
// What the performer adds deliberately while playing stays theirs; following keeps it.
//
// Pure functions: a device runner schedules the clicks and supplies both sides.

const freeze=value=>frozenJson(value,{bytes:65536,items:8192}).data;
// Device ids are whatever the platform reports (Web MIDI ids may contain spaces).
const deviceName=(value,label)=>{if(typeof value!=='string'||!value.trim()||value.length>256)throw new TypeError(`Invalid ${label}`);return value;};
export const CALIBRATION_LIMITS=Object.freeze({clicks:256,minimumPairs:8,maximumOffsetSeconds:1,earliestTapSeconds:.3,maximumSpreadSeconds:.02,
  maximumTapSpreadSeconds:.04,
  // The statement a run's clicks are planned to support (Astra's DC05, calibration-tolerance.js): that `coverage` of a
  // device's round trips lie within the largest residual the run observed, with a confidence one less
  // `confidenceFailure` -- a statistical criterion, authored as one is (the conventional nine in ten with nineteen in
  // twenty), from which the clicks a run sends follow exactly (CALIBRATION_CLICKS).
  tolerance:Object.freeze({coverage:'9/10',confidenceFailure:'1/20'})});
// The fewest clicks a run sends that can support its tolerance statement (planCalibrationTrials: the observed maximum's
// exact binomial criterion, its plan checked). It had been a fixed 24, which supports none at that criterion.
export const CALIBRATION_CLICKS=(()=>{const out=planCalibrationTrials({id:'latency-round-trip',revision:1,...CALIBRATION_LIMITS.tolerance});
  if(out.status!=='PASS'||!Number.isInteger(out.minimumTrials))throw new Error(`No click count supports the calibration's tolerance: ${out.reason}`);
  return Math.max(CALIBRATION_LIMITS.minimumPairs,out.minimumTrials)})();
export const CALIBRATION_METHODS=Object.freeze(['loopback','acoustic-loopback','tap-along']);

// Click times with seeded jitter, so a latency that repeats with the output
// buffer cannot alias with a strictly periodic schedule.
export function calibrationSchedule({count=CALIBRATION_CLICKS,startSeconds=0,intervalSeconds=.5,jitterSeconds=.12,seed=1}={}) {
  if(!Number.isInteger(count)||count<CALIBRATION_LIMITS.minimumPairs||count>CALIBRATION_LIMITS.clicks||!Number.isFinite(startSeconds)||
    !(intervalSeconds>=.2&&intervalSeconds<=4)||!(jitterSeconds>=0&&jitterSeconds<intervalSeconds/3))throw new TypeError('Invalid calibration schedule');
  const random=createRandomStream(seed);
  return Object.freeze(Array.from({length:count},(_,i)=>startSeconds+i*intervalSeconds+(random.next()*2-1)*jitterSeconds));
}

// Each click pairs with the one capture inside [minimum, maximum] of it (a tap may
// come before its click: minimum can be negative, down to -0.3 s). The window
// must be shorter than the closest two clicks (0.26 s for the default schedule);
// a longer round trip (a Bluetooth speaker) needs a slower schedule. A capture
// two clicks could claim, or a click with two captures, is ambiguous and left
// out, never guessed.
export function pairLoopback(sent,received,{minimumSeconds=0,maximumSeconds=.25}={}) {
  const times=(values,label)=>{if(!Array.isArray(values)||values.length>CALIBRATION_LIMITS.clicks*4||values.some(v=>!Number.isFinite(v)))throw new TypeError(`Invalid ${label}`);return [...values].sort((a,b)=>a-b);};
  const out=times(sent,'sent clicks'),back=times(received,'captured onsets');
  if(!(minimumSeconds>=-CALIBRATION_LIMITS.earliestTapSeconds&&maximumSeconds>minimumSeconds&&maximumSeconds<=CALIBRATION_LIMITS.maximumOffsetSeconds))throw new TypeError('Invalid loopback window');
  const windows=[],difference=new Int32Array(back.length+1),degrees=new Int32Array(back.length);
  let left=0,right=0,unanswered=0,ambiguous=0;
  for(const at of out){
    while(left<back.length&&back[left]-at<minimumSeconds)left++;
    right=Math.max(right,left);
    while(right<back.length&&back[right]-at<=maximumSeconds)right++;
    windows.push([left,right]);if(left<right){difference[left]++;difference[right]--;}
  }
  let count=0;for(let j=0;j<back.length;j++){count+=difference[j];degrees[j]=count;}
  const pairs=[],singleClaims=new Set;
  windows.forEach(([lo,hi],i)=>{if(hi-lo===1)singleClaims.add(lo);if(lo===hi)unanswered++;else if(hi-lo===1&&degrees[lo]===1)pairs.push({sentAt:out[i],receivedAt:back[lo]});else ambiguous++;});
  // Preserve the existing spurious count: captures claimed by no single-return
  // click, including captures belonging only to an ambiguous multi-return click.
  return freeze({pairs,unanswered,ambiguous,spurious:back.length-singleClaims.size});
}

// Median offset and a robust spread (1.4826 x median absolute deviation).
// Refused when too few clicks came back cleanly or the spread shows the path is
// not one constant (a drifting clock, a click detector misfiring).
// A run's tolerance (Astra's DC05): where every click it sent came back once and cleanly -- a whole fixed study, none of
// its trials discarded -- that CALIBRATION_LIMITS.tolerance's coverage of round trips lie within the bound of their
// residuals from the offset (s, the observed residuals' exact order statistic), at its confidence; certified and checked
// independently. Else null, and why: a run missing clicks supports no such statement. (Its residuals are the detected
// onsets', to the microsecond: no detector's own error is known here.)
function toleranceOf(delays,center,{sent=delays.length,complete=false}){
  if(!complete||delays.length!==sent)return {tolerance:null,why:'incomplete-run'};
  const micro=x=>String(Math.round(x*1e6))+'/1000000',source={id:'loopback-run',revision:1,hash:sha256(JSON.stringify(delays)),known:true},context=sha256(String(center));
  const trials=delays.map((_,i)=>({id:`click-${i}`,unitId:`click-${i}`}));
  const study={id:'latency-round-trip',revision:1,policy:{id:'latency-round-trip',revision:1,...CALIBRATION_LIMITS.tolerance},source,clockDomain:{id:'run',unit:'second',revision:1},contextHash:context,evidenceLayer:'measured',
    score:{kind:'max-absolute',definition:{id:'residual-from-median',revision:1,hash:sha256('residual-from-median')},fixedBeforeTrials:true,trainingUnitIds:[]},
    collection:{id:'loopback-clicks',revision:1,hash:sha256(`clicks:${sent}`),kind:'fixed-count-iid-trials',fixedBeforeTrials:true,complete:true,sameFutureLaw:true,futureIndependent:true,trials},
    roles:['round-trip'],trials:delays.map((d,i)=>({...trials[i],sourceHash:source.hash,contextHash:context,evidenceLayer:'measured',complete:true,reference:{id:`click-${i}`,revision:1,hash:sha256(`click-${i}:${d}`)},
      bounds:[{roleId:'round-trip',kind:'absolute-bound',lo:micro(d-center),hi:micro(d-center)}]}))};
  try{
    const prepared=prepareCalibrationTolerance(study);if(prepared.status!=='PASS')return {tolerance:null,why:prepared.reason};
    const out=certifyCalibrationTolerance(prepared.prepared);if(out.status!=='CERTIFIED')return {tolerance:null,why:out.reason};
    const checked=checkCalibrationTolerance(prepared.prepared,out.certificate);if(checked.status!=='PASS'||checked.conclusion!=='STATISTICAL_TOLERANCE')return {tolerance:null,why:'its certificate did not check'};
    const [n,d='1']=String(out.tolerance.bound).split('/');
    return {tolerance:{kind:'statistical-tolerance',boundSeconds:Number(n)/Number(d),coverage:CALIBRATION_LIMITS.tolerance.coverage,confidenceFailure:CALIBRATION_LIMITS.tolerance.confidenceFailure,rank:out.tolerance.rank,clicks:sent}};
  }catch(error){return {tolerance:null,why:String(error?.message??error)}}
}
export function estimateRoundTrip({pairs,unanswered=null,ambiguous=null,sent=null},{minimumPairs=CALIBRATION_LIMITS.minimumPairs,maximumSpreadSeconds=CALIBRATION_LIMITS.maximumSpreadSeconds}={}) {
  if(!Array.isArray(pairs))throw new TypeError('Pair the loopback first');
  const delays=pairs.map(p=>p.receivedAt-p.sentAt).sort((a,b)=>a-b);
  const median=values=>values.length%2?values[(values.length-1)/2]:(values[values.length/2-1]+values[values.length/2])/2;
  if(delays.length<minimumPairs)return freeze({accepted:false,reason:'too-few-clean-returns',pairs:delays.length});
  const center=median(delays),mad=values=>1.4826*median(values.map(Math.abs).sort((a,b)=>a-b));
  // Drift: a slope across the run means two clocks, not one delay. It is judged
  // against the scatter left once the trend is removed, since drift inflates
  // the plain spread and would hide behind it.
  const n=pairs.length,mx=pairs.reduce((s,p)=>s+p.sentAt,0)/n,my=delays.reduce((s,d)=>s+d,0)/n;
  const slope=pairs.reduce((s,p)=>s+(p.sentAt-mx)*(p.receivedAt-p.sentAt-my),0)/Math.max(1e-12,pairs.reduce((s,p)=>s+(p.sentAt-mx)**2,0));
  const span=Math.max(...pairs.map(p=>p.sentAt))-Math.min(...pairs.map(p=>p.sentAt)),drift=Math.abs(slope)*span;
  const residual=mad(pairs.map(p=>p.receivedAt-p.sentAt-my-slope*(p.sentAt-mx))),spread=mad(delays.map(d=>d-center));
  if(drift>Math.max(.005,3*residual))return freeze({accepted:false,reason:'clock-drift',pairs:delays.length,offsetSeconds:center,driftSeconds:drift});
  if(spread>maximumSpreadSeconds)return freeze({accepted:false,reason:'inconsistent-round-trip',pairs:delays.length,offsetSeconds:center,spreadSeconds:spread});
  // Variance of the median estimate for a location spread s: about (1.2533 s)^2 / n.
  const complete=unanswered===0&&ambiguous===0,{tolerance,why}=toleranceOf(delays,center,{sent:sent??delays.length,complete});
  return freeze({accepted:true,pairs:delays.length,offsetSeconds:center,spreadSeconds:spread,
    varianceSeconds2:(1.2533*spread)**2/delays.length+spread*spread,driftSeconds:drift,...(tolerance?{tolerance}:{toleranceWithheld:why})});
}

// A versioned record for one output path, one input path and one method. It is
// valid only for that pair of devices and settings; any change needs a new run.
export function calibrationRecord({estimate,modality,inputDeviceId,outputPath,measuredAt,method='loopback'}) {
  if(!estimate?.accepted)throw new Error('Only an accepted offset estimate becomes a calibration');
  if(!['midi','audio'].includes(modality)||!CALIBRATION_METHODS.includes(method)||!Number.isFinite(measuredAt))throw new TypeError('Invalid calibration context');
  if(method!=='tap-along'&&estimate.offsetSeconds<0)throw new RangeError('A device loopback cannot return before its click');
  deviceName(inputDeviceId,'input device');deviceName(outputPath,'output path');
  const version=`${method}:${modality}:${Math.round(estimate.offsetSeconds*1e6)}us:${Math.round(measuredAt)}`;
  return freeze({version:2,calibrationVersion:version,method,modality,inputDeviceId,outputPath,measuredAt,
    offsetSeconds:estimate.offsetSeconds,varianceSeconds2:estimate.varianceSeconds2,pairs:estimate.pairs,...(estimate.tolerance?{tolerance:estimate.tolerance}:{}),
    meaning:method==='tap-along'?'Scheduled ensemble click to this performer\'s captured tap: the round trip plus their anticipation. Subtracting it maps their onset to the ensemble beat they meant.':
      'Scheduled ensemble output to captured input, including any acoustic path. Subtracting it maps a captured onset to the ensemble time the performer was hearing; a performer\'s own offset is not removed.'});
}

export function validCalibration(value) {
  knownFields(value,['version','calibrationVersion','method','modality','inputDeviceId','outputPath','measuredAt','offsetSeconds',
    'varianceSeconds2','pairs','meaning','tolerance'],'latency calibration');
  if(value.version!==2||!CALIBRATION_METHODS.includes(value.method)||!(Math.abs(value.offsetSeconds)<=CALIBRATION_LIMITS.maximumOffsetSeconds)||
    value.method!=='tap-along'&&value.offsetSeconds<0||
    !(value.varianceSeconds2>=0)||!Number.isInteger(value.pairs)||value.pairs<CALIBRATION_LIMITS.minimumPairs)
    throw new TypeError('Invalid latency calibration');
  identifier(value.calibrationVersion,'calibration version');deviceName(value.inputDeviceId,'input device');deviceName(value.outputPath,'output path');
  return freeze(value);
}
