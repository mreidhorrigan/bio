import {actor, checkOrigin, identifier, number, frozenJson, knownFields} from '../planning-data.js';
import {finite, EstimationError} from './linear-filter.js';

const freeze = value => frozenJson(value, {bytes: 16384, items: 2048}).data;
const reject = message => { throw new EstimationError('observation-contract', message); };
const identityFields = ['sessionId', 'sourceId', 'sourceIncarnation', 'observerId', 'publisherId', 'bindingVersion'];
export const OBSERVATION_LIMITS = Object.freeze({sources: 64, schemas: 32, ancestors: 32, recordBytes: 16384});

// This is an injected calibration, not another clock synchronizer. The host's
// existing machine-clock mapper supplies these coefficients and their version.
export class ObservationClockMapping {
  constructor({version, inputUnits = 'milliseconds', originLocalSeconds = 0, originSessionSeconds = 0,
    rate = 1, timingVarianceSeconds2 = 0, latencySeconds = 0, calibrationStatus = 'uncalibrated'}) {
    identifier(version, 'clock mapping version');
    if (!['milliseconds', 'seconds'].includes(inputUnits)) reject('Unsupported input clock units');
    if (!['calibrated', 'uncalibrated', 'unresolved-latency'].includes(calibrationStatus)) reject('Unknown clock calibration status');
    finite(originLocalSeconds, 'clock origin'); finite(originSessionSeconds, 'session origin');
    finite(rate, 'clock rate'); finite(timingVarianceSeconds2, 'clock variance'); finite(latencySeconds, 'input latency');
    if (rate <= 0 || timingVarianceSeconds2 < 0 || latencySeconds < 0) reject('Invalid clock calibration');
    Object.assign(this, {version, inputUnits, originLocalSeconds, originSessionSeconds, rate, timingVarianceSeconds2, latencySeconds, calibrationStatus});
    Object.freeze(this);
  }
  time(value, {event = false} = {}) {
    const local = finite(value, 'capture timestamp') / (this.inputUnits === 'milliseconds' ? 1000 : 1);
    return this.originSessionSeconds + (local - this.originLocalSeconds) * this.rate - (event ? this.latencySeconds : 0);
  }
  window({start, end = start, availableAt, lookaheadSeconds = 0}) {
    const eventStart = this.time(start, {event: true}), eventEnd = this.time(end, {event: true}), available = this.time(availableAt);
    if (eventStart > eventEnd || eventEnd > available || !Number.isFinite(lookaheadSeconds) || lookaheadSeconds < 0) reject('Invalid capture window or availability');
    return freeze({eventStart, eventEnd, availableAt: available, clockMappingVersion: this.version, lookaheadSeconds,
      timingVarianceSeconds2: this.timingVarianceSeconds2, calibrationStatus: this.calibrationStatus});
  }
}

export function sourceBinding(value) {
  knownFields(value, ['version', ...identityFields, 'publisher', 'performerId', 'deviceId', 'endpoint', 'modality', 'role',
    'parameters', 'kinds', 'clockMappingVersion', 'calibrationVersion', 'possibleSelfOutput'], 'source binding');
  if (value.version !== 1) reject('Unknown source-binding version');
  for (const field of identityFields) identifier(value[field], field);
  identifier(value.clockMappingVersion); identifier(value.calibrationVersion);
  const publisher = actor(value.publisher);
  if (publisher.id !== value.publisherId) reject('Publisher identity does not match binding');
  if (!['midi', 'audio', 'control', 'transport', 'dataset', 'derived'].includes(value.modality)) reject('Unknown observation modality');
  if (!['performer', 'mixture', 'bot', 'declared-control', 'device'].includes(value.role)) reject('Unknown source role');
  if (value.role === 'mixture' && value.performerId !== null) reject('A mixture cannot claim an identified performer');
  if (value.performerId !== null) identifier(value.performerId, 'performer');
  identifier(value.deviceId, 'device'); identifier(value.endpoint, 'endpoint');
  if (typeof value.possibleSelfOutput !== 'boolean') reject('Self-output coverage must be explicit');
  if (!Array.isArray(value.parameters) || !value.parameters.length || value.parameters.length > OBSERVATION_LIMITS.schemas) reject('Invalid parameter budget');
  const parameters = value.parameters.map(parameter => {
    knownFields(parameter, ['schema', 'units'], 'observation parameter'); identifier(parameter.schema);
    if (typeof parameter.units !== 'string' || !parameter.units.length || parameter.units.length > 128) reject('Observation units must be explicit');
    return {schema: parameter.schema, units: parameter.units};
  });
  if (new Set(parameters.map(p => p.schema)).size !== parameters.length) reject('Duplicate parameter schema');
  if (!Array.isArray(value.kinds) || !value.kinds.length || value.kinds.some(k => !['measurement', 'declaration', 'coverage', 'estimate'].includes(k))) reject('Unknown observation kind');
  return freeze({...value, publisher, parameters});
}

export class SourceRegistry {
  constructor({limit = OBSERVATION_LIMITS.sources} = {}) {
    if (!Number.isInteger(limit) || limit < 1 || limit > OBSERVATION_LIMITS.sources) reject('Invalid source budget');
    this.limit = limit; this.bindings = new Map();
  }
  key(value) { return JSON.stringify([value.sessionId, value.sourceId, value.sourceIncarnation, value.bindingVersion]); }
  register(input, origin) {
    const binding = sourceBinding(input); checkOrigin(binding.publisher, origin);
    const key = this.key(binding), old = this.bindings.get(key);
    if (old && frozenJson(old).canonical !== frozenJson(binding).canonical) reject('Source binding revisions are immutable');
    if (!old && this.bindings.size >= this.limit) reject('Source registry budget exhausted');
    this.bindings.set(key, binding); return binding;
  }
  observation(input, {origin, receivedAt}) {
    knownFields(input, ['version', ...identityFields, 'observationId', 'sequence', 'parameterSchema', 'units', 'kind',
      'when', 'value', 'quality', 'coverage', 'rawEventRefs', 'correlationGroup', 'ancestry', 'extractorVersion',
      'calibrationVersion', 'validInterval'], 'observation');
    const value = freeze(input), binding = this.bindings.get(this.key(value));
    if (!binding || value.version !== 1) reject('Unregistered source or observation version');
    checkOrigin(binding.publisher, origin);
    for (const field of identityFields) if (binding[field] !== value[field]) reject(`Conflicting ${field}`);
    identifier(value.observationId); number(value.sequence, 'observation sequence', {integer: true});
    const parameter = binding.parameters.find(p => p.schema === value.parameterSchema);
    if (!parameter || parameter.units !== value.units) reject('Unregistered or incompatible parameter/units');
    if (!binding.kinds.includes(value.kind)) reject('Source cannot publish this kind of evidence');
    if (value.calibrationVersion !== binding.calibrationVersion || value.when.clockMappingVersion !== binding.clockMappingVersion) reject('Observation calibration changed; register a new binding revision');
    const when = value.when;
    for (const key of ['eventStart', 'eventEnd', 'availableAt', 'lookaheadSeconds', 'timingVarianceSeconds2']) finite(when[key], key);
    finite(receivedAt, 'local receipt time');
    if (when.eventStart > when.eventEnd || when.eventEnd > when.availableAt || when.availableAt > receivedAt ||
      when.lookaheadSeconds < 0 || when.timingVarianceSeconds2 < 0) reject('Noncausal observation times or negative uncertainty');
    if (!['complete', 'partial', 'missing', 'invalid'].includes(value.coverage)) reject('Unknown input coverage');
    if (['missing', 'invalid'].includes(value.coverage) && value.value !== null) reject('Missing evidence must not claim a measured value');
    for (const field of ['rawEventRefs', 'ancestry']) {
      if (!Array.isArray(value[field]) || value[field].length > OBSERVATION_LIMITS.ancestors) reject('Observation ancestry budget exceeded');
      value[field].forEach(ref => identifier(ref, field));
    }
    if (value.correlationGroup !== null) identifier(value.correlationGroup, 'correlation group');
    identifier(value.extractorVersion);
    const interval = value.validInterval;
    if (interval !== null && (!interval || !Number.isFinite(interval.start) || !Number.isFinite(interval.end) || interval.end < interval.start)) reject('Invalid evidence interval');
    if (value.kind === 'declaration' && interval === null) reject('A declaration needs an explicit validity interval');
    return freeze({...value, receivedAt, sourceRole: binding.role, performerId: binding.performerId, deviceId: binding.deviceId,
      possibleSelfOutput: binding.possibleSelfOutput});
  }
}
