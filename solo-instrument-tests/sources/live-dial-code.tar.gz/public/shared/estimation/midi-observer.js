import {JZZ, deserializeUMP, umpPacket, inspectUMP} from '../ump.js';
import {decodeMidiBytes} from '../midi-performance-log.js';
import {SourceRegistry, ObservationClockMapping} from './observations.js';
import {ObservationReplay} from './observation-replay.js';
import {createPulseState, observePulse, forecastPulse, pulsePosition} from './continuous-models.js';
// Free performance is followed by the occurrence beam (rhythm-beam-v5): held-out
// comparisons under rules fixed beforehand decided it (see the Kalman-influence
// handoff). PulseCoupler still runs beside it, for comparison. `percussion` below
// describes whether the recent note-ons are all on the GM percussion channel.
import {createRhythmBank,observeRhythm,rhythmForecasts} from './rhythm-occurrence.js';
import {createPulseFollower,observePulseFollower,pulseFollowerForecast} from './pulse-following.js';
import {frozenJson} from '../planning-data.js';

const freeze = value => frozenJson(value, {bytes: 16384, items: 2048}).data;
const PERCUSSION_CHANNEL = 9, PERCUSSION_WINDOW = 32, PERCUSSION_MINIMUM = 8;
const SCHEMAS = Object.freeze([
  {schema: 'midi.raw.v1', units: 'UMP-and-original-bytes'},
  {schema: 'timing.onset.v1', units: 'seconds'},
  {schema: 'timing.declared-pulse.v2', units: 'seconds'},
]);

// The beam's configurations a MIDI source may name. midi-velocity-v1 is in development: velocity heard as the
// accent (learned per position, as the audio listening learns its bass), which on Groove MIDI development trials put
// a following band on the performer's beat far more often (research/kalman-integration.md).
// midi-free-timing-v1 is in development too: the beam holds back while its performer's tempo wanders (fit.wander over
// 0.04, octaves folded out) or its level's evidence is under 0.7, so rubato is not followed. On development (60 spent
// ASAP performances and 44 Groove MIDI validation takes) it took expressive piano from misleading (net -0.134) to
// abstaining (+0.016), and kept drums followed (+0.705 against +0.778). Its held-out test waits on a piano corpus not yet
// heard (research/kalman-integration.md, "Following expressive piano and singing").
export const MIDI_RHYTHM_LISTENINGS=Object.freeze({'midi-defaults':Object.freeze({}),
  'midi-velocity-v1':Object.freeze({accentModel:Object.freeze({id:'learned-velocity-v1',variance:.06,priorVariance:.05})}),
  'midi-free-timing-v1':Object.freeze({trackingFit:Object.freeze({maxClutter:.3,maxInnovation:2,minEvidence:.7,maxWander:.04})})});

// One explicitly bound endpoint/incarnation. Web MIDI bytes are retained in
// addition to their JZZ UMP container. Native UMP is never flattened to bytes.
// Free-performance onsets remain observations until a rhythm adapter assigns
// competing positions. Only explicitly declared taps or MIDI clock feed M1.
export class MidiObservationSource {
  constructor({sessionId, sourceId, sourceIncarnation, observerId, publisher, performerId, deviceId, endpoint,
    mapping, timingMode = 'performance', referencePulse = pulsePosition(1, 4), periodSeconds = 0.5,
    onsetVarianceSeconds2 = 0.0001, chordWindowSeconds = 0.012, eventLimit = 512,
    possibleSelfOutput = false, rhythm = 'midi-defaults', onObservation = () => {}}) {
    if (!Object.hasOwn(MIDI_RHYTHM_LISTENINGS, rhythm)) throw new TypeError(`A MIDI rhythm listening is one of ${Object.keys(MIDI_RHYTHM_LISTENINGS).join(', ')}`);
    this.rhythm = rhythm;
    if (!(mapping instanceof ObservationClockMapping)) throw new TypeError('MIDI observation requires an injected calibrated clock mapping');
    if (!['performance', 'declared-taps', 'midi-clock'].includes(timingMode)) throw new TypeError('Unknown MIDI timing mode');
    if (!Number.isFinite(onsetVarianceSeconds2) || onsetVarianceSeconds2 <= 0 || !Number.isFinite(chordWindowSeconds) || chordWindowSeconds < 0 || chordWindowSeconds > 0.1 ||
      !Number.isInteger(eventLimit) || eventLimit < 2 || eventLimit > 2048) throw new TypeError('Invalid MIDI observation budget/noise');
    Object.assign(this, {mapping, timingMode, referencePulse, periodSeconds, onsetVarianceSeconds2, chordWindowSeconds, eventLimit, onObservation});
    this.registry = new SourceRegistry(); this.publisher = publisher;
    this.binding = this.registry.register({version: 1, sessionId, sourceId, sourceIncarnation, observerId,
      publisherId: publisher.id, publisher, bindingVersion: 'midi-binding-v1', performerId, deviceId, endpoint,
      modality: 'midi', role: performerId === null ? 'device' : 'performer', parameters: SCHEMAS,
      kinds: ['measurement', 'coverage'], clockMappingVersion: mapping.version, calibrationVersion: mapping.version, possibleSelfOutput}, publisher);
    this.sequence = 0; this.pulseIndex = 0; this.raw = []; this.lastOnset = null; this.coverage = 'complete';
    this.droppedRawEvents = 0; this.replay = null; this.rhythmReplay = null; this.pulseReplay = null; this.conversion = [];
    this.converter = JZZ.M1M2().connect(message => this.conversion.push(Array.from(deserializeUMP(Uint8Array.from(message)))));
  }
  observation(schema, {when, value, rawEventRefs, correlationGroup, coverage = 'complete'}) {
    const source = this.binding, sequence = this.sequence++;
    const observation = this.registry.observation({version: 1, sessionId: source.sessionId, sourceId: source.sourceId,
      sourceIncarnation: source.sourceIncarnation, observerId: source.observerId, publisherId: source.publisherId,
      bindingVersion: source.bindingVersion, observationId: `${source.sourceId}:${source.sourceIncarnation}:${sequence}`, sequence,
      parameterSchema: schema, units: SCHEMAS.find(item => item.schema === schema).units, kind: coverage === 'complete' ? 'measurement' : 'coverage',
      when, value, quality: {model: 'declared-timing-variance', varianceSeconds2: this.onsetVarianceSeconds2,
        calibrationStatus: when.calibrationStatus}, coverage, rawEventRefs, correlationGroup, ancestry: rawEventRefs,
      extractorVersion: 'midi-observer-v1', calibrationVersion: source.calibrationVersion, validInterval: null},
    {origin: this.publisher, receivedAt: when.availableAt});
    this.onObservation(observation); return observation;
  }
  midi1(bytes, timestamp, {availableAt = timestamp, deviceId = this.binding.deviceId} = {}) {
    if (!Array.isArray(bytes) && !(bytes instanceof Uint8Array)) throw new TypeError('MIDI input requires bytes');
    bytes = [...bytes];
    if (!bytes.length || bytes.length > 1024 || bytes.some(x => !Number.isInteger(x) || x < 0 || x > 255)) throw new TypeError('Invalid MIDI byte message');
    const message = new JZZ.MIDI(bytes); this.conversion = []; this.converter.send(message);
    const decoded = decodeMidiBytes(bytes), noteOn = decoded?.type === 'noteOn';
    return this.ingest({bytes, packets: this.conversion, timestamp, availableAt, deviceId,
      noteOn, velocity: noteOn ? decoded.value / 127 : null, channel: noteOn ? bytes[0] & 15 : null, midiClock: bytes.length === 1 && bytes[0] === 0xf8});
  }
  ump(packet, timestamp, {availableAt = timestamp, deviceId = this.binding.deviceId} = {}) {
    const words = Array.from(umpPacket(packet)), message = inspectUMP(words);
    const type = words[0] >>> 28, status = (words[0] >>> 16) & 255;
    const legacy = type === 2 ? decodeMidiBytes([status, (words[0] >>> 8) & 127, words[0] & 127]) : null;
    const noteOn = message.kind === 'noteOn' || legacy?.type === 'noteOn';
    return this.ingest({bytes: null, packets: [words], timestamp, availableAt, deviceId, noteOn,
      velocity: !noteOn ? null : message.kind === 'noteOn' ? (words[1] >>> 16) / 65535 : legacy.value / 127,
      // MIDI 1 (type 2) and MIDI 2 (type 4) channel voice carry the channel beside the status.
      channel: noteOn && (type === 2 || type === 4) ? status & 15 : null, midiClock: type === 1 && status === 0xf8});
  }
  ingest({bytes, packets, timestamp, availableAt, deviceId, noteOn, velocity = null, channel = null, midiClock}) {
    if (this.coverage !== 'complete') throw new Error('Disconnected inputs require a new source incarnation');
    if (deviceId !== this.binding.deviceId) throw new Error('MIDI device does not match the performer binding');
    const when = this.mapping.window({start: timestamp, availableAt}), rawId = `${this.binding.sourceId}:${this.binding.sourceIncarnation}:raw-${this.sequence}`;
    const raw = freeze({rawId, timestamp, clockUnits: this.mapping.inputUnits, eventTime: when.eventStart, bytes,
      packets, sourceId: this.binding.sourceId, sourceIncarnation: this.binding.sourceIncarnation, deviceId});
    this.raw.push(raw);
    if (this.raw.length > this.eventLimit) { this.raw.shift(); this.droppedRawEvents++; }
    const outputs = [this.observation('midi.raw.v1', {when, value: raw, rawEventRefs: [rawId], correlationGroup: rawId})];
    if (noteOn) {
      (this.noteOnChannels ||= []).push(channel);
      if (this.noteOnChannels.length > PERCUSSION_WINDOW) this.noteOnChannels.shift();
      // These are candidate note attacks. Chord membership and pulse ordinals
      // belong to the event-time projection below, not an arrival-time label
      // that would become false when an earlier note arrives late.
      // Velocity travels as accent: a performer's dynamics, not a detected metrical accent.
      const onset=this.observation('timing.onset.v1', {when, value: {candidateOnset: true,chordWindowSeconds:this.chordWindowSeconds,
        ...(velocity===null?{}:{velocity})}, rawEventRefs: [rawId], correlationGroup: rawId });
      outputs.push(onset);
      if(this.timingMode==='performance'){
        // A v5 bank is a few hundred learned position probabilities per hypothesis.
        this.rhythmReplay ||= new ObservationReplay({eventLimit:Math.min(128,this.eventLimit),historySeconds:8,
          stateBytes:1024*1024,stateItems:262144,initial:createRhythmBank({...MIDI_RHYTHM_LISTENINGS[this.rhythm],referencePulse:this.referencePulse}),
          reduce:(bank,evidence)=>{
            if(bank.lastEventAt!==null&&evidence.when.eventStart-bank.lastEventAt<=this.chordWindowSeconds)return bank;
            return observeRhythm(bank,{eventTime:evidence.when.eventStart,availableAt:evidence.when.availableAt,
              varianceSeconds2:evidence.quality.varianceSeconds2+evidence.when.timingVarianceSeconds2,accent:evidence.value.velocity??null});
          }});
        this.pulseReplay ||= new ObservationReplay({eventLimit:Math.min(128,this.eventLimit),historySeconds:8,
          initial:createPulseFollower({bpm:60/this.periodSeconds}),
          reduce:(state,evidence)=>state.last!==null&&evidence.when.eventStart-state.last<=this.chordWindowSeconds?state:
            observePulseFollower(state,evidence.when.eventStart)});
        this.rhythmReplay.insert(onset);this.pulseReplay.insert(onset);
        this.lastOnset=this.rhythmReplay.current.lastEventAt;
      }
    }
    if ((this.timingMode === 'declared-taps' && noteOn) || (this.timingMode === 'midi-clock' && midiClock)) {
      const observation = this.observation('timing.declared-pulse.v2', {when, value: {referencePulse: this.referencePulse,
        association: this.timingMode}, rawEventRefs: [rawId], correlationGroup: rawId});
      if (!this.replay) this.replay = new ObservationReplay({eventLimit: this.eventLimit,
        // The empty checkpoint contains no future observation. First evidence
        // initializes phase once; it is not both an independent prior and z.
        initial: null,
        reduce: (track, evidence) => {
          const eventTime=evidence.when.eventStart;
          if(this.timingMode==='declared-taps'&&track&&eventTime-track.lastClusterAt<=this.chordWindowSeconds)return track;
          const index=track?.nextPulseIndex||0;
          // MIDI clock is 24 clocks per quarter, regardless of the tactus.
          // Ordinals are assigned by the pure replay, including after a late
          // attack changes the tentative event order. Sealed states stay fixed.
          const pulse=this.timingMode==='midi-clock'?pulsePosition(index*this.referencePulse.denominator,96*this.referencePulse.numerator):pulsePosition(index);
          const variance=evidence.quality.varianceSeconds2+evidence.when.timingVarianceSeconds2;
          const next=track?observePulse(track,{pulse,eventTime,availableAt:evidence.when.availableAt,varianceSeconds2:variance}).track:
            {...createPulseState({eventTime,pulse,
            referencePulse:this.referencePulse,periodSeconds:this.periodSeconds,covariance:[[variance,0],[0,0.01]]}),
            accepted:1,lastEvidenceAt:eventTime,lastAvailableAt:evidence.when.availableAt};
          return {...next,nextPulseIndex:index+1,lastClusterAt:eventTime};
        }});
      this.replay.insert(observation); outputs.push(observation);
      this.pulseIndex=this.replay.current.nextPulseIndex;
      this.lastOnset=this.replay.current.lastClusterAt;
    }
    return Object.freeze(outputs);
  }
  forecast(pulse) {
    if (!this.replay) return null;
    return forecastPulse(this.replay.current, pulse, {performanceVarianceSeconds2: this.onsetVarianceSeconds2});
  }
  rhythmForecast(now) {
    return this.rhythmReplay?rhythmForecasts(this.rhythmReplay.current,{now,performanceVarianceSeconds2:this.onsetVarianceSeconds2}):null;
  }
  pulseForecast(now) {
    return this.pulseReplay?pulseFollowerForecast(this.pulseReplay.current,{now}):null;
  }
  disconnect(timestamp) {
    if (this.coverage !== 'complete') return null;
    this.coverage = 'missing';
    return this.observation('midi.raw.v1', {when: this.mapping.window({start: timestamp, availableAt: timestamp}), value: null,
      rawEventRefs: [], correlationGroup: null, coverage: 'missing'});
  }
  snapshot() {
    return freeze({binding: this.binding, timingMode: this.timingMode, coverage: this.coverage,
      retainedRawEvents: this.raw.length, droppedRawEvents: this.droppedRawEvents,
      lastTimingEvidenceAt: this.replay?.current?.lastEvidenceAt ?? this.rhythmReplay?.current?.lastAcceptedAt ?? null,
      timing: this.replay?.current || null, calibrationStatus: this.mapping.calibrationStatus, percussion: this.percussion()});
  }
  // Whether this input is percussion, from its recent note-ons: every one of at
  // least eight on the GM percussion channel. A split or layered keyboard that
  // also sends there is not.
  percussion() {
    const channels = this.noteOnChannels || [], onChannel = channels.filter(channel => channel === PERCUSSION_CHANNEL).length;
    return {noteOns: channels.length, onPercussionChannel: onChannel, percussion: channels.length >= PERCUSSION_MINIMUM && onChannel === channels.length};
  }
}
