import {actor, sameActor, actorKey, identifier, frozenJson} from '../planning-data.js';
import {MemoryTransfers, sendMemoryMessage} from '../memory-transfer.js';
import {randomUUID} from '../random-id.js';
import {responseProfile} from './response-profile.js';

export const PROFILE_LIMITS=Object.freeze({reportBytes:32768, sources:8, pending:2, requestSeconds:1,
  requestExpirySeconds:8, sourceTimeoutSeconds:12, historySeconds:120, records:64, historyBytes:524288,totalBytes:1048576});
const prefix='/agent/profile/';
const freeze=(value,bytes=PROFILE_LIMITS.reportBytes)=>frozenJson(value,{bytes,items:8192}).data;
const pointNames=new Set(['prepareByBeat','windowStartBeat','windowEndBeat','snapshotCloseBeat','selectionByBeat','commitByBeat','startBeat','endBeat']);
const evidence=value=>value===null||Boolean(value&&Array.isArray(value.pitches)&&value.pitches.length<=16&&
  value.pitches.every(Number.isFinite)&&value.clock&&typeof value.clock.calibrationStatus==='string'&&
  (!value.timing||Number.isFinite(value.timing.periodSeconds)&&value.timing.periodSeconds>0&&
    value.timing.referencePulse?.numerator>0&&value.timing.referencePulse?.denominator>0));
function validResponseProfile(profile){
  return typeof profile.enabled==='boolean'&&evidence(profile.source)&&
    Array.isArray(profile.decisions)&&profile.decisions.length<=2&&
    new Set(profile.decisions.map(decision=>decision.id)).size===profile.decisions.length&&profile.decisions.every(decision=>
      typeof decision.id==='string'&&decision.id.length<=2048&&decision.overplan&&decision.timing&&
      Array.isArray(decision.timing.points)&&decision.timing.points.length===8&&
      new Set(decision.timing.points.map(point=>point.name)).size===8&&
      decision.timing.points.every(point=>pointNames.has(point.name)&&Number.isFinite(point.beat)&&Number.isFinite(point.atReference))&&
      decision.timing.points.find(point=>point.name==='endBeat').atReference>decision.timing.points.find(point=>point.name==='prepareByBeat').atReference&&
      ['period','register'].every(key=>Number.isFinite(decision.proposals?.[key]?.result?.target)&&
        typeof decision.proposals[key].explanation?.reason==='string')&&decision.previousTargets&&
      Number.isFinite(decision.previousTargets.periodSeconds)&&Number.isFinite(decision.previousTargets.register)&&
      evidence(decision.preparationEvidence)&&(!decision.snapshot||Array.isArray(decision.snapshot.inputs)&&decision.snapshot.inputs.length<=4&&
        decision.snapshot.inputs.every(input=>evidence(input.sourceEvidence)))&&
      Array.isArray(decision.alternatives)&&decision.alternatives.length<=4&&decision.alternatives.every(value=>
        typeof value.id==='string'&&Array.isArray(value.pitches)&&value.pitches.length<=128&&value.pitches.every(Number.isFinite))&&
      Array.isArray(decision.facts)&&decision.facts.length<=8&&decision.facts.every(fact=>fact.plan&&typeof fact.plan.planId==='string'&&
        (fact.atReference===null||Number.isFinite(fact.atReference))));
}

// Reuse the response projection. Limit display history, not the planner's
// records, and explicitly report any detail that will not fit this channel.
export function compactResponseProfile(bot){
  const profile=responseProfile(bot);
  const decisions=profile.decisions.slice(-2).map(value=>({...value,facts:value.facts.slice(-8)}));
  const limits={responses:2,factsPerResponse:8,omittedResponses:profile.decisions.length-decisions.length};
  while(true){
    try{return {coverage:'snapshot',profile:freeze({...profile,decisions,displayRetention:limits},PROFILE_LIMITS.reportBytes-2048)};}
    catch(error){
      if(!(error instanceof RangeError))throw error;
      if(!decisions.length)return {coverage:'oversize',profile:null};
      decisions.shift();limits.omittedResponses++;
    }
  }
}

// A query inspects existing records. It never pumps a response, polls its input,
// selects a branch or changes a clock. Multipart transport is the existing
// bounded direct-transfer helper, with much smaller diagnostic budgets.
export function serveProfileQuery(bot,message,{now=performance.now()/1000,project=compactResponseProfile}={}){
  if(message.address!=='/agent/profile/query')return false;
  const query=message.args?.[0];
  if(query?.target!==bot.instanceId||query?.incarnation!==bot.incarnation||query?.version!==1)return true;
  if(!Number.isFinite(now))return true;
  try{
    identifier(query.requestId);const requester=actor({id:message.source,incarnation:message.sourceIncarnation});
    const publisher=actor({id:bot.instanceId,incarnation:bot.incarnation}),key=actorKey(requester);
    bot.profileQueryTimes||=new Map();
    if(now-(bot.profileQueryTimes.get(key)??-Infinity)<PROFILE_LIMITS.requestSeconds)return true;
    // Bound total profiling work even when there are many observers.
    if(now-(bot.lastProfileQueryAt??-Infinity)<.25)return true;
    bot.profileQueryTimes.set(key,now);bot.lastProfileQueryAt=now;
    while(bot.profileQueryTimes.size>16)bot.profileQueryTimes.delete(bot.profileQueryTimes.keys().next().value);
    const header={version:1,role:'diagnostic',target:requester.id,requestId:query.requestId,publisher,
      sequence:bot.profileSequence=(bot.profileSequence||0)+1};
    let reply;
    try{reply=freeze({...header,...project(bot)});}
    catch(error){
      if(!(error instanceof RangeError))throw error;
      reply=freeze({...header,coverage:'oversize',profile:null});
    }
    sendMemoryMessage(bot.send,'/agent/profile/response',[reply],{prefix,maxBytes:PROFILE_LIMITS.reportBytes+1024});
    bot.lastProfileError=null;
  }catch(error){bot.lastProfileError=error.message;}
  return true;
}

export class ProfileReportClient{
  constructor({identity,source,send,now,kind='response-profile'}){
    if(!['response-profile','ensemble-profile-summary'].includes(kind))throw new TypeError('Unknown diagnostic profile');
    this.identity=actor(identity);this.source=actor(source);Object.assign(this,{send,now});
    this.kind=kind;
    this.epoch=randomUUID();this.sequence=0;this.pending=new Map();this.lastQueryAt=-Infinity;this.latest=null;
    this.transfers=new MemoryTransfers({prefix,maxBytes:PROFILE_LIMITS.reportBytes+1024,maxChunks:6,maxTransfers:2});
  }
  query(){
    const now=this.now();
    if(!Number.isFinite(now)||now-this.lastQueryAt<PROFILE_LIMITS.requestSeconds)return false;
    for(const [id,at]of this.pending)if(now-at>PROFILE_LIMITS.requestExpirySeconds)this.pending.delete(id);
    if(this.pending.size>=PROFILE_LIMITS.pending)return false;
    const requestId=`profile:${this.epoch}:${++this.sequence}`;
    this.pending.set(requestId,now);this.lastQueryAt=now;
    this.send('/agent/profile/query',[{version:1,target:this.source.id,incarnation:this.source.incarnation,requestId}]);
    return true;
  }
  receive(message){
    if(!['/agent/profile/response','/agent/profile/transfer'].includes(message.address)||
      message.source!==this.source.id||message.sourceIncarnation!==this.source.incarnation||message.args?.[0]?.target!==this.identity.id)return false;
    if(message.address==='/agent/profile/transfer'){
      message=this.transfers.accept(message);if(!message)return false;
      if(message.address!=='/agent/profile/response')return false;
    }
    const value=freeze(message.args?.[0]),now=this.now(),sentAt=this.pending.get(value.requestId);
    if(value.version!==1||value.role!=='diagnostic'||value.target!==this.identity.id||!sameActor(value.publisher,this.source)||
      sentAt===undefined||!Number.isFinite(now)||now<sentAt||now-sentAt>PROFILE_LIMITS.requestExpirySeconds||
      !Number.isSafeInteger(value.sequence)||value.sequence<1||!['snapshot','oversize'].includes(value.coverage))return false;
    if(this.latest&&(value.sequence<=this.latest.sequence||sentAt<this.latest.sentAt))return false;
    if(value.coverage==='snapshot'&&(value.profile?.version!==1||value.profile?.kind!==this.kind))return false;
    if(value.profile&&this.kind==='response-profile'&&!validResponseProfile(value.profile))return false;
    if(value.profile&&this.kind==='ensemble-profile-summary'&&(!Array.isArray(value.profile.sources)||
      value.profile.sources.length>PROFILE_LIMITS.sources||!Array.isArray(value.profile.history)||value.profile.history.length>PROFILE_LIMITS.records))return false;
    if(value.coverage==='oversize'&&value.profile!==null)return false;
    this.pending.delete(value.requestId);
    this.latest=freeze({...value,sentAt,receivedAt:now});return true;
  }
  snapshot(){
    if(!this.latest)return null;
    return freeze({...this.latest,stale:this.now()-this.latest.receivedAt>PROFILE_LIMITS.sourceTimeoutSeconds,
      timeMeaning:'publisher-local response clock; not synchronized by profile receipt'});
  }
}
