// How a performer divides the beat: in twos (straight) or in threes (triplets,
// swing, a compound 12/8 feel), from where their recent attacks fall inside the
// beat they are heard to keep.
//
// Following the beat's tempo and phase leaves the ensemble in its own
// subdivision. On a GuitarSet blues the guitarist's attacks fell on the beat and
// on its thirds, almost never on the straight "and", while the band played
// straight eighths. The rhythm beam's grid can say "three per beat" (it did on
// that blues). But on a 12/8 take it read a dotted-eighth pulse with no grid at
// all, and on a bossa its "three" divided a beat three eighths long. So the
// subdivision is read from the attacks themselves, against the beat the
// listener reports.
//
// Each attack goes to the nearest position in the beat:
// - on the beat (0) says nothing;
// - a quarter, a half or three quarters count for twos;
// - a sixth, a third, two thirds or five sixths count for threes.
// The positions for threes cover more of the beat, so threes must win clearly (by
// `ratio`), and over `minimum` attacks.
const DUPLE=[1/4,1/2,3/4],TRIPLE=[1/6,1/3,2/3,5/6];

// onsets: attack times (seconds); beat: {beatAt, periodSeconds} in the same clock. Returns {parts: 3, 2 or null,
// triple, duple} with the counts.
export function beatSubdivision(onsets,beat,{minimum=8,ratio=2.5}={}) {
  if(!(beat?.periodSeconds>0)||!Number.isFinite(beat.beatAt))return {parts:null,triple:0,duple:0};
  let triple=0,duple=0;
  for(const time of onsets){
    const phase=(((time-beat.beatAt)/beat.periodSeconds)%1+1)%1;
    const distance=position=>Math.abs(phase-position),onBeat=Math.min(phase,1-phase);
    const nearestDuple=Math.min(...DUPLE.map(distance)),nearestTriple=Math.min(...TRIPLE.map(distance));
    if(onBeat<=Math.min(nearestDuple,nearestTriple))continue;
    if(nearestTriple<nearestDuple)triple++;else duple++;
  }
  const parts=triple>=minimum&&triple>=ratio*duple?3:duple>=minimum&&duple>=ratio*triple?2:null;
  return {parts,triple,duple};
}
