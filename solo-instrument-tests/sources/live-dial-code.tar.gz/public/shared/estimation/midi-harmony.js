import {createUmpNoteTracker} from '../ump-notes.js';
import {midi1StreamConverter} from '../midi-files.js';
import {JZZ,umpPacket,initializeMidi2} from '../ump.js';
import {frozenJson,knownFields} from '../planning-data.js';

export const HARMONIC_STATE_BUDGET=Object.freeze({bytes:1024*1024,items:131072});
const freeze=value=>frozenJson(value,HARMONIC_STATE_BUDGET).data;

// A derived active-note view, not a replacement for the source's original UMP.
// MIDI 1 conversion reuses the file adapter's RPN/NRPN/bank state machine.
export class MidiHarmonicProjection {
  static async create({codecOptions,...options}={}) {
    return (await this.prepare({codecOptions,...options}))();
  }
  static async prepare({codecOptions,...options}={}) {
    const codec=await initializeMidi2(codecOptions);
    return (checkpoint=null)=>new MidiHarmonicProjection({...options,convertMidi1:midi1StreamConverter(codec),checkpoint});
  }
  constructor({convertMidi1=null,includePedalHeld=true,maxActiveNotes=256,checkpoint=null}={}) {
    this.convertMidi1=convertMidi1;this.includePedalHeld=includePedalHeld;
    this.tracker=createUmpNoteTracker({ticksPerQuarterNote:1,maxActiveNotes,retainHistory:false});
    this.coverage='complete';this.lastEventAt=null;this.availableAt=null;this.revision=0;this.unknownPackets=0;
    // Restoration constructs a new projection. A failed converter or note
    // restore cannot partially change the caller's current projection.
    if(checkpoint!==null){
      const value=freeze(checkpoint);
      knownFields(value,['version','kind','includePedalHeld','tracker','midi1','lastEventAt','availableAt','revision','unknownPackets'],'harmonic checkpoint');
      if(value.version!==1||value.kind!=='midi-harmonic-projection'||value.includePedalHeld!==includePedalHeld||
        !(value.lastEventAt===null||Number.isFinite(value.lastEventAt))||
        !(value.availableAt===null||Number.isFinite(value.availableAt))||
        (value.lastEventAt===null)!==(value.availableAt===null)||value.availableAt<value.lastEventAt||
        !Number.isSafeInteger(value.revision)||value.revision<0||!Number.isSafeInteger(value.unknownPackets)||value.unknownPackets<0||
        (value.midi1===null)!==(convertMidi1===null))throw new TypeError('Invalid harmonic checkpoint');
      this.tracker.restore(value.tracker);
      if(value.midi1!==null)this.convertMidi1.restoreChannelCheckpoint(value.midi1);
      for(const key of ['lastEventAt','availableAt','revision','unknownPackets'])this[key]=value[key];
    }
  }
  checkpoint() {
    if(this.coverage!=='complete')throw new Error('Only a complete harmonic projection can be checkpointed');
    return freeze({version:1,kind:'midi-harmonic-projection',includePedalHeld:this.includePedalHeld,
      tracker:this.tracker.checkpoint(),midi1:this.convertMidi1?.channelCheckpoint()??null,
      lastEventAt:this.lastEventAt,availableAt:this.availableAt,revision:this.revision,unknownPackets:this.unknownPackets});
  }
  observe(input) {this.consume(input);return this.snapshot();}
  consume({bytes=null,packets=[],eventTime,availableAt=eventTime}) {
    if(this.coverage!=='complete')throw new Error('A disconnected projection needs a new source incarnation');
    if(!Number.isFinite(eventTime)||!Number.isFinite(availableAt)||availableAt<eventTime)
      throw new TypeError('Invalid harmonic event time/availability');
    if(this.lastEventAt!==null&&eventTime<this.lastEventAt){
      // This primitive consumes event order. MidiHarmonicReplay restores a
      // checkpoint and orders raw evidence before calling it.
      this.coverage='invalid';this.availableAt=Math.max(this.availableAt??-Infinity,availableAt);this.revision++;
      throw new TypeError('Delayed MIDI invalidated the live pitch history; start a new source incarnation');
    }
    const converted=bytes!==null?this.convertMidi1?.(new JZZ.MIDI(bytes),eventTime):null;
    if(bytes!==null&&!this.convertMidi1)throw new Error('Initialize the existing MIDI 1 codec before projecting MIDI 1');
    const events=bytes!==null?[...converted,...this.convertMidi1.flush()]:packets.map(packet=>({time:eventTime,packet:umpPacket(packet)}));
    for(const event of events){
      const type=event.packet[0]>>>28;
      if(type!==2&&type!==4)this.unknownPackets++;
      try{this.tracker.consume(event);}catch(error){this.coverage='invalid';throw error;}
    }
    this.lastEventAt=eventTime;this.availableAt=availableAt;this.revision++;
  }
  disconnect(availableAt) {
    if(!Number.isFinite(availableAt)||this.availableAt!==null&&availableAt<this.availableAt)throw new TypeError('Invalid disconnection time');
    this.coverage='missing';this.availableAt=availableAt;return this.snapshot();
  }
  snapshot() {
    const notes=this.tracker.snapshot().filter(note=>this.includePedalHeld||note.keyDown);
    return freeze({version:1,revision:this.revision,coverage:this.coverage,eventTime:this.lastEventAt,availableAt:this.availableAt,
      pitchUnits:'MIDI-note-semitones',meaning:'active-MIDI-note-intentions',includePedalHeld:this.includePedalHeld,
      notes:this.coverage==='complete'?notes:null,retainedUnreleasedNotes:notes.length,unknownPackets:this.unknownPackets,
      // MIDI alone does not reveal the acoustic decay of a held instrument.
      acousticAmplitudeKnown:false});
  }
}
