import {actor, actorKey, frozenJson, identifier} from '../planning-data.js';
import {randomUUID} from '../random-id.js';
import {meterChangePolicy, meterInterpretation, meterRealization, resolveMeterChange} from './meter-change-window.js';
import {metricalState} from './metrical-state.js';
import {whenBar} from '../change-timing.js';
import {clampTempo} from '../tempo-range.js';
export {whenBar} from '../change-timing.js';

const freeze = value => frozenJson(value, {bytes: 262144, items: 32768}).data;
const validBar = bar => Number.isSafeInteger(bar) && bar >= 0;

// These are logical bar requests, not promises of a future wall-clock time.
// The local clock closes a window when it advances to that bar. Tempo changes
// can move that boundary until then. A shared conductor has its own future
// commitment/delivery contract in MeterChangeWindow.
export class LocalMeterChanges {
  constructor({identity = {id: 'local-conductor', incarnation: randomUUID()}, sessionId = randomUUID(),
    policy, now = () => performance.now() / 1000, timeDomain = 'local-monotonic-seconds', windowLimit = 8} = {}) {
    this.identity = actor(identity); this.sessionId = identifier(sessionId);
    this.policy = meterChangePolicy(policy);
    if (typeof now !== 'function' || !Number.isInteger(windowLimit) || windowLimit < 1 || windowLimit > 16)
      throw new TypeError('Invalid local meter window budget');
    Object.assign(this, {now, windowLimit, timeDomain: identifier(timeDomain)});
    this.windows = new Map(); this.sequence = 0; this.closedBar = -1; this.lastAt = -Infinity;
  }
  time() {
    const now = this.now();
    if (!Number.isFinite(now) || now < this.lastAt) throw new Error('Local meter time must be monotonic');
    return now;
  }
  resolve(window, currentMeter, now, provisional) {
    const decisionId = `${this.sessionId}:meter:${window.targetBar}`;
    const base = {decisionId, targetBar: window.targetBar, mode: window.mode,
      cutoff: now, effectiveAt: now,
      effectiveBoundary: {bar: window.targetBar}, provisional, policy: this.policy,
      inputKind: 'artistic-proposal', authority: this.identity};
    const result = resolveMeterChange({base, records: [...window.records.values()], identity: this.identity,
      sessionId: this.sessionId, scope: {mode: 'local', membershipId: this.sessionId, participants: [this.identity]},
      policy: this.policy, currentMeter: window.mode === 'opening' ? window.openingMeter : currentMeter});
    // Only agreement is evaluated at `now`. The first pulse of the target
    // bar has not necessarily sounded yet, and its seconds are not committed.
    // Do not expose the resolver's evaluation interval as a scheduled output.
    const {effectiveAt, ...logicalBase} = base;
    return freeze({...logicalBase, decisionTime: now, timeDomain: this.timeDomain, timing: 'logical-bar-only',
      status: result.status, reason: result.reason, accepted: result.accepted, meter: result.meter,
      basis: result.proposal?.basis || {reports: [], selected: [], excluded: []},
      alternatives: result.proposal?.alternatives || result.alternatives || []});
  }
  offer({meter, targetBar, mode = 'nextBar', currentMeter, publisher = this.identity}) {
    if (!validBar(targetBar) || targetBar <= this.closedBar || !['opening', 'nextBar', 'nextPhrase'].includes(mode))
      throw new Error('Local meter boundary is invalid or already closed');
    publisher = actor(publisher); meter = freeze(meter); currentMeter = freeze(currentMeter);
    metricalState(meterInterpretation(meter)); metricalState(meterInterpretation(currentMeter));
    const now = this.time(), old = this.windows.get(targetBar);
    if (!old && this.windows.size >= this.windowLimit) throw new Error('Local meter window budget exhausted');
    const records = new Map(old?.records);
    const previous = records.get(publisher.id);
    if (!previous && records.size >= 64) throw new Error('Meter publisher budget exhausted');
    const changed = !previous || actorKey(previous.publisher) !== actorKey(publisher) || meterRealization(previous.meter) !== meterRealization(meter);
    const sequence = this.sequence + Number(changed);
    if (changed) records.set(publisher.id, {publisher, meter, receivedAt: now, sequence, priority: 0});
    const window = {targetBar, mode: old?.mode || mode, records, openingMeter: old?.openingMeter || currentMeter};
    const preview = this.resolve(window, currentMeter, now, true); // Validate the complete bounded decision before mutation.
    this.windows.set(targetBar, window); this.sequence = sequence; this.lastAt = now;
    return {...preview, status: 'collecting', resolution: preview.status};
  }
  seal(bar, currentMeter) {
    if (!validBar(bar)) throw new TypeError('Invalid local meter bar');
    const now = this.time(), window = this.windows.get(bar);
    const decision = window ? this.resolve(window, currentMeter, now, false) : null;
    // A jump never applies a missed request retrospectively. A clock handover
    // discards the whole collector; a normal local advance visits every bar.
    for (const target of this.windows.keys()) if (target <= bar) this.windows.delete(target);
    this.closedBar = Math.max(this.closedBar, bar); this.lastAt = now;
    return decision;
  }
  pending(currentMeter) {
    const window = [...this.windows.values()].filter(value => value.mode !== 'opening').sort((a, b) => a.targetBar - b.targetBar)[0];
    if (!window) return null;
    const preview = this.resolve(window, currentMeter, this.time(), true);
    return meterChangeNotice({...preview, status: 'collecting', resolution: preview.status});
  }
}

// The wire/UI summary is deliberately small. The collector retains the full
// attributed result locally; it does not broadcast the whole evidence graph.
export function meterChangeNotice(decision) {
  if (!decision) return null;
  const alternatives = decision.proposal?.alternatives || decision.alternatives || [];
  return {meter: decision.meter, targetBar: decision.targetBar, mode: decision.mode,
    status: decision.status, resolution: decision.resolution || decision.status,
    reason: decision.reason, provisional: decision.provisional, publishers: alternatives.map(item => item.publisher)};
}

export function resetLocalMeter(state) {
  state.localMeterChanges = null; state.meterDecision = null; state.pendingMeter = null;
}

export function queueLocalMeter(state, normalizeMeter, value = {}, mode = 'nextBar', publisher) {
  // (A bar named, 'bar:<n>': that bar's window, or the next bar's where it has been reached.)
  const at = whenBar(mode);
  const opening = mode === 'opening' && !(state.pulsed ?? state.tick > 0);
  if (mode === 'opening' && !opening) mode = state.bar < state.meter.phraseBars ? 'nextBar' : 'nextPhrase';
  mode = opening ? 'opening' : mode === 'nextPhrase' ? 'nextPhrase' : 'nextBar';
  const remaining = opening ? 0 : mode === 'nextPhrase' ? state.meter.phraseBars - state.bar % state.meter.phraseBars : 1;
  // A local interval is scheduled after bar advancement. Leave the first
  // complete bar after an accepted input ramp before changing its subdivision.
  let targetBar = Math.max(at ?? state.bar + remaining, state.bar + remaining, state.inputTempoCommit ? state.inputTempoCommit.endBar + 1 : 0);
  if(mode==='nextPhrase'&&targetBar%state.meter.phraseBars)targetBar+=state.meter.phraseBars-targetBar%state.meter.phraseBars;
  let changes = state.localMeterChanges;
  // The first opening replaces earlier queued defaults. Later opening
  // proposals compete against the original meter until the first pulse.
  if (!changes || (opening && changes.windows.get(targetBar)?.mode !== 'opening'))
    changes = new LocalMeterChanges({policy: state.meterPolicy, now: state.meterNow, timeDomain: state.meterTimeDomain});
  const result = changes.offer({meter: normalizeMeter({...value, groups: Array.isArray(value?.groups) ? value.groups : []}),
    targetBar, mode, currentMeter: state.meter, publisher});
  state.localTempoFollowing?.invalidate('meter-proposal');
  state.localMeterChanges = changes;
  // (A meter applied keeps the tempo within its own range: a room opened in any meter at a tempo where it is felt --
  // 960 in a /24 -- may meet one whose notes that tempo cannot count, which every timing anchor refuses.)
  if (opening) {state.meter = result.meter; if (Number.isFinite(state.bpm)) state.bpm = clampTempo(state.bpm, state.meter);}
  state.pendingMeter = changes.pending(state.meter);
  return {...meterChangeNotice(result), ...(opening ? {opening: true, applied: true} : {})};
}

export function sealLocalMeter(state) {
  const changes = state.localMeterChanges;
  if (!changes) {
    const pending=state.pendingMeter;
    if(!pending||pending.provisional||state.bar<pending.targetBar)return null;
    state.pendingMeter=null;state.meter=pending.meter;return state.meter;
  }
  const decision = changes.seal(state.bar, state.meter);
  let changed = null;
  if (decision) {
    state.meterDecision = decision;
    if (meterRealization(state.meter) !== meterRealization(decision.meter)) changed = decision.meter;
    state.meter = decision.meter;
    if (Number.isFinite(state.bpm)) state.bpm = clampTempo(state.bpm, state.meter);
  }
  state.pendingMeter = changes.pending(state.meter);
  return changed;
}
