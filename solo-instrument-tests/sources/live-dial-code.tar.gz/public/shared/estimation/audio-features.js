import {rms,PitchDetector} from '../../vendor/input-analysis/features.js';
import {createScalarState,observeScalar} from './continuous-models.js';
import {SpectralFluxOnsets} from './spectral-flux.js';
import {ONSET_DETECTORS} from './listening-options.js';

// Causal frame features, intended for a Worker. Capture start/end and availability
// are separate, and a gap resets the comparison rather than inventing silence.
//
// An onset is detected when a frame's energy jumps (rms-attack), and is then
// placed where its attack began within the two frames that saw it (v2): the first
// crossing of 30% of the energy envelope's rise to the frame's peak, in 16-sample
// hops. v1 placed every onset at its frame's midpoint, up to half a frame (21 ms at
// 48 kHz) from the attack, and an attack late in a frame was often flagged in the
// next one, later still. Tempo following did not mind; aligning the ensemble's
// beats with the performer's (beat-sync.js) needs the attack itself.
//
// The variance an onset declares stays v1's, a frame's uniform spread. The rhythm
// models were validated with it, and it stands for more than the detector: a
// performer's onsets sit off any pulse by about as much. Declaring the attack's
// own precision (a few ms) instead let the occurrence beam resolve grids too
// fine for the playing, and closed-loop renders of GuitarSet guitarists then lost
// the metrical level (scripts/evaluate-sync.mjs). The attack's precision is
// reported beside it, as attackVarianceSeconds2.
//
// Each onset also carries how hard it was struck (strength, the envelope's peak) and how much of it was bass
// (lowRise, the rise of the energy below lowBandHz across the attack). Low sounds carry the beat for listeners
// (Hove et al. 2014; Lenc et al. 2018), and in GuitarSet comping the low strings' attacks fall on the beat more
// often than the high strings', which in bossa lean to the "and".
// The low band is measured over LOW_WINDOW_SECONDS either side of the attack: about two periods of a guitar's low E.
//
// onsetDetector 'spectral-flux' hears onsets from the spectrum's new energy instead (spectral-flux.js, in
// development). It hears most strums that ring on into the next, which the energy's jump misses.
const ENVELOPE_WINDOW=64,ENVELOPE_HOP=16,ATTACK_RISE=.3,ATTACK_FLOOR_SECONDS=.002,LOW_WINDOW_SECONDS=.023;
// A fourth-order Butterworth low-pass as two biquads (their Q), continuous across frames.
const BUTTERWORTH_Q=[0.5411961,1.3065630];
function lowPassSections(sampleRate,hz){
  return BUTTERWORTH_Q.map(q=>{const w=2*Math.PI*hz/sampleRate,cos=Math.cos(w),alpha=Math.sin(w)/(2*q),a0=1+alpha;
    return {b0:(1-cos)/2/a0,b1:(1-cos)/a0,b2:(1-cos)/2/a0,a1:-2*cos/a0,a2:(1-alpha)/a0,x1:0,x2:0,y1:0,y2:0};});
}
function envelopeOf(previous,samples){
  const before=previous?.length??0,total=before+samples.length,at=i=>i<before?previous[i]:samples[i-before],envelope=[];
  const squares=Float64Array.from({length:total},(_,i)=>{const v=at(i);return v*v;});
  for(let from=0;from+ENVELOPE_WINDOW<=total;from+=ENVELOPE_HOP){let sum=0;for(let i=from;i<from+ENVELOPE_WINDOW;i++)sum+=squares[i];envelope.push(Math.sqrt(sum/ENVELOPE_WINDOW));}
  return envelope;
}
export class AudioFeatureSource {
  // onsetHop: null decides onsets frame by frame, as rms-attack-v2 always has. A number of samples (a power of two
  // dividing the frame) decides them hop by hop instead (rms-attack-v3, in development): each hop's energy against
  // the frame's length of sound before it. A frame-by-frame decision depends on where an attack falls in its frame:
  // shifting a bossa by 6 to 30 ms flipped which of its attacks were heard, and with them the listener's beat.
  constructor({sampleRate,frameSize=2048,minimumRms=0.008,onsetRatio=1.8,refractorySeconds=0.06,
    minimumPitchClarity=0.9,minimumPitchHz=45,maximumPitchHz=2200,lowBandHz=150,onsetHop=null,lowOnsetRms=null,onsetDetector='rms-attack',attackDetector=null}={}) {
    if(!Number.isFinite(sampleRate)||sampleRate<8000||sampleRate>192000||!Number.isInteger(frameSize)||frameSize<256||frameSize>8192||(frameSize&(frameSize-1)))
      throw new TypeError('Invalid audio analysis sample rate/frame size');
    for(const value of [minimumRms,onsetRatio,refractorySeconds,minimumPitchClarity,minimumPitchHz,maximumPitchHz,lowBandHz])if(!Number.isFinite(value))throw new TypeError('Invalid audio feature configuration');
    if(lowBandHz<=0||lowBandHz>=sampleRate/4)throw new TypeError('Invalid low band');
    if(onsetHop!==null&&(!Number.isInteger(onsetHop)||onsetHop<128||onsetHop>frameSize||frameSize%onsetHop||(onsetHop&(onsetHop-1))))
      throw new TypeError('An onset hop is a power of two of at least 128 samples dividing the frame');
    this.onsetHop=onsetHop;
    // lowOnsetRms: null hears onsets in the full band only. A level (linear RMS) also hears them below lowBandHz, where
    // a thumb's bass note under a ringing chord rises clearly although the full band barely moves (in development).
    if(lowOnsetRms!==null&&!(Number.isFinite(lowOnsetRms)&&lowOnsetRms>0))throw new TypeError('Invalid low-band onset level');
    this.lowOnsetRms=lowOnsetRms;
    if(!ONSET_DETECTORS.includes(onsetDetector))throw new TypeError(`An onset detector is one of ${ONSET_DETECTORS.join(', ')}`);
    this.flux=null;
    if(onsetDetector==='spectral-flux'){
      if(onsetHop!==null||lowOnsetRms!==null)throw new TypeError('An onset hop and low-band onsets belong to the RMS detector');
      this.flux=new SpectralFluxOnsets({sampleRate});
      if(frameSize%this.flux.hop)throw new TypeError(`Spectral flux onsets need frames of whole ${this.flux.hop}-sample hops`);
    }
    // attackDetector: a second detector, whose onsets are reported as `attack` (listening-options.js). Only spectral
    // flux beside the RMS detector is a second one; otherwise `attack` is the onset.
    if(attackDetector!==null&&!ONSET_DETECTORS.includes(attackDetector))throw new TypeError(`An onset detector is one of ${ONSET_DETECTORS.join(', ')}`);
    this.attackFlux=attackDetector==='spectral-flux'&&!this.flux?new SpectralFluxOnsets({sampleRate}):null;
    if(this.attackFlux&&frameSize%this.attackFlux.hop)throw new TypeError(`Spectral flux onsets need frames of whole ${this.attackFlux.hop}-sample hops`);
    if(minimumRms<=0||onsetRatio<=1||refractorySeconds<=0||minimumPitchClarity<=0||minimumPitchClarity>1||minimumPitchHz<=0||maximumPitchHz<=minimumPitchHz)
      throw new TypeError('Invalid audio feature limits');
    Object.assign(this,{sampleRate,frameSize,minimumRms,onsetRatio,refractorySeconds,minimumPitchClarity,minimumPitchHz,maximumPitchHz,lowBandHz});
    this.detector=PitchDetector.forFloat32Array(frameSize);this.detector.minVolumeAbsolute=minimumRms;
    this.sequence=0;this.reset();
  }
  reset(){this.lastEnd=null;this.lastRms=null;this.lastLowRms=null;this.lastOnset=null;this.energyTrack=null;this.previous=null;this.previousLow=null;this.hopEnergy=[];
    this.sections=lowPassSections(this.sampleRate,this.lowBandHz);this.flux?.reset();this.attackFlux?.reset();this.lastAttack=null;}
  lowPass(samples){
    const out=new Float32Array(samples.length);
    for(let i=0;i<samples.length;i++){let v=samples[i];
      for(const s of this.sections){const y=s.b0*v+s.b1*s.x1+s.b2*s.x2-s.a1*s.y1-s.a2*s.y2;s.x2=s.x1;s.x1=v;s.y2=s.y1;s.y1=y;v=y;}out[i]=v;}
    return out;
  }
  // Seconds from `start` (this frame's) to the attack, searched from the previous frame's start to this frame's end;
  // the attack's strength; and the low band's rise, its energy after the attack over its energy before.
  attackOffset(samples,low,previous=this.previous) {
    const before=previous?.length??0,envelope=envelopeOf(previous,samples);
    const centre=k=>k*ENVELOPE_HOP+ENVELOPE_WINDOW/2;
    let peakAt=-1;for(let k=0;k<envelope.length;k++)if(centre(k)>=before&&(peakAt<0||envelope[k]>envelope[peakAt]))peakAt=k;
    // The quietest point in the frame's length before the peak is where the rise starts from.
    let baseAt=peakAt;for(let k=Math.max(0,peakAt-Math.round(samples.length/ENVELOPE_HOP));k<peakAt;k++)if(envelope[k]<envelope[baseAt])baseAt=k;
    const threshold=envelope[baseAt]+ATTACK_RISE*(envelope[peakAt]-envelope[baseAt]);
    let k=baseAt;while(k<peakAt&&envelope[k+1]<threshold)k++;
    const a=envelope[k],b=envelope[Math.min(k+1,peakAt)],fraction=b>a?Math.max(0,Math.min(1,(threshold-a)/(b-a))):0;
    const attackAt=(k+fraction)*ENVELOPE_HOP+ENVELOPE_WINDOW/2;
    // The attack's strength is its envelope's peak: how hard the note or strum was struck.
    return {offset:(attackAt-before)/this.sampleRate,strength:envelope[peakAt],lowRise:this.lowRiseAt(low,Math.round(attackAt),previous)};
  }
  // The low band's rise across an attack `at` samples from the previous frame's start: its energy after over before.
  lowRiseAt(low,at,previous=this.previous){
    const before=previous?.length??0,span=Math.round(LOW_WINDOW_SECONDS*this.sampleRate);
    const lowAt=i=>i<before?this.previousLow[i]:low[i-before],lowRms=(from,to)=>{let sum=0,n=0;for(let i=Math.max(0,from);i<Math.min(before+low.length,to);i++){sum+=lowAt(i)**2;n++;}return n?Math.sqrt(sum/n):0;};
    return Math.max(0,lowRms(at,at+span)-lowRms(at-span,at));
  }
  // An attack already placed (by spectral flux), `index` samples into this frame: its strength, the envelope's peak
  // from the attack on, and its bass.
  measureAttack(samples,low,index){
    const before=this.previous?.length??0,envelope=envelopeOf(this.previous,samples),at=before+index;
    let strength=0;for(let k=0;k<envelope.length;k++)if(k*ENVELOPE_HOP+ENVELOPE_WINDOW/2>=at)strength=Math.max(strength,envelope[k]);
    return {offset:index/this.sampleRate,strength,lowRise:this.lowRiseAt(low,at)};
  }
  process(samples,{start,end,availableAt,coverage='complete'}) {
    if(!Number.isFinite(start)||!Number.isFinite(end)||!Number.isFinite(availableAt)||start>=end||availableAt<end)throw new TypeError('Noncausal audio frame');
    if(!['complete','missing','invalid'].includes(coverage))throw new TypeError('Unknown audio coverage');
    if(coverage!=='complete'){this.reset();return Object.freeze({sequence:this.sequence++,coverage,when:{start,end,availableAt},value:null});}
    if(!(samples instanceof Float32Array)||samples.length!==this.frameSize||samples.some(value=>!Number.isFinite(value)))throw new TypeError('Invalid audio samples');
    if(Math.abs((end-start)-this.frameSize/this.sampleRate)>1/this.sampleRate)throw new TypeError('Frame duration does not match its sample rate');
    if(this.lastEnd!==null&&start<this.lastEnd-1/this.sampleRate)throw new TypeError('Overlapping audio windows need an explicit correlation model');
    const discontinuity=this.lastEnd!==null&&start-this.lastEnd>1/this.sampleRate;
    if(discontinuity)this.reset();
    const energy=rms({signal:samples}),[frequency,clarity]=this.detector.findPitch(samples,this.sampleRate);
    const ready=time=>this.lastOnset===null||time-this.lastOnset>=this.refractorySeconds;
    let onset=false,onsetAt=start,fluxAt=null;
    if(this.flux){
      // The first onset the flux heard in this frame that the refractory allows.
      for(const {index} of this.flux.process(samples)){const time=start+index/this.sampleRate;if(ready(time)){onset=true;onsetAt=time;fluxAt=index;break;}}
    }else if(this.onsetHop===null){
      onset=this.lastRms!==null&&energy>=this.minimumRms&&energy>Math.max(this.minimumRms,this.lastRms)*this.onsetRatio&&ready(start);
    }else{
      // Each hop's mean square against the mean over the frame's length before it.
      const hops=this.frameSize/this.onsetHop,span=hops;
      for(let j=0;j<hops;j++){
        let sum=0;for(let i=j*this.onsetHop;i<(j+1)*this.onsetHop;i++)sum+=samples[i]*samples[i];
        const square=sum/this.onsetHop,history=this.hopEnergy,hopStart=start+j*this.onsetHop/this.sampleRate;
        if(!onset&&history.length>=span){
          const reference=Math.sqrt(history.reduce((a,b)=>a+b,0)/span),value=Math.sqrt(square);
          if(value>=this.minimumRms&&value>Math.max(this.minimumRms,reference)*this.onsetRatio&&ready(hopStart)){onset=true;onsetAt=hopStart;}
        }
        history.push(square);if(history.length>span)history.shift();
      }
    }
    const low=this.lowPass(samples),lowEnergy=rms({signal:low});
    let band=onset?'full':null;
    if(!onset&&this.lowOnsetRms!==null&&this.lastLowRms!==null&&lowEnergy>=this.lowOnsetRms&&
      lowEnergy>Math.max(this.lowOnsetRms,this.lastLowRms)*this.onsetRatio&&ready(start)){onset=true;onsetAt=start;band='low';}
    this.lastLowRms=lowEnergy;
    // A low-band onset is placed on the low band's own envelope.
    const located=!onset?null:fluxAt!==null?this.measureAttack(samples,low,fluxAt):band==='low'?this.attackOffset(low,low,this.previousLow):this.attackOffset(samples,low);
    // The second detector's attack, with its own refractory.
    let heardAttack=null;
    if(this.attackFlux){
      for(const {index} of this.attackFlux.process(samples)){const time=start+index/this.sampleRate;
        if(this.lastAttack===null||time-this.lastAttack>=this.refractorySeconds){const measured=this.measureAttack(samples,low,index);this.lastAttack=time;
          heardAttack={estimateSeconds:time,varianceSeconds2:(end-start)**2/12,attackVarianceSeconds2:(this.attackFlux.hop/this.sampleRate)**2/12+ATTACK_FLOOR_SECONDS**2,
            strength:measured.strength,lowRise:measured.lowRise,method:'spectral-flux-v1',calibrationStatus:'uncalibrated'};break;}}
    }
    const attack=onset?Math.max(-(this.previous?.length??0)/this.sampleRate,Math.min(end-start,located.offset)):null;
    if(onset)this.lastOnset=onsetAt;
    this.previous=Float32Array.from(samples);this.previousLow=low;
    const pitch=energy>=this.minimumRms&&clarity>=this.minimumPitchClarity&&frequency>=this.minimumPitchHz&&frequency<=this.maximumPitchHz?frequency:null;
    this.energyTrack=this.energyTrack
      ? observeScalar(this.energyTrack,{time:end,value:energy,variance:0.001,units:'linear-rms'}).track
      : {...createScalarState({value:energy,variance:0.001,time:end,units:'linear-rms',processVariancePerSecond:0.01}),lastEvidenceAt:end};
    this.lastRms=energy;this.lastEnd=end;
    return Object.freeze({sequence:this.sequence++,coverage,discontinuity,when:{start,end,availableAt,lookaheadSeconds:0},
      rms:energy,smoothedRms:this.energyTrack.state.mean[0],energyVariance:this.energyTrack.state.covariance[0][0],
      pitchHz:pitch,pitchStatus:pitch===null?'unknown':'monophonic-candidate',pitchClarity:clarity,
      // The window is the span searched. The attack's own precision is the envelope's step with a floor for an
      // attack spread over strings or a bow.
      onset:onset?{windowStart:start+Math.min(0,attack),windowEnd:end,estimateSeconds:start+attack,varianceSeconds2:(end-start)**2/12,
        attackVarianceSeconds2:((this.flux?this.flux.hop:ENVELOPE_HOP)/this.sampleRate)**2/12+ATTACK_FLOOR_SECONDS**2,strength:located.strength,lowRise:located.lowRise,band,
        method:this.flux?'spectral-flux-v1':this.onsetHop===null&&this.lowOnsetRms===null?'rms-attack-v2':'rms-attack-v3',calibrationStatus:'uncalibrated'}:null,
      ...(this.attackFlux?{attack:heardAttack}:{}),
      extractorVersion:'meyda-rms-5.6.3-pitchy-4.1.0',calibrationStatus:'uncalibrated',vocabulary:'single-pitch-hz'});
  }
}
