import {SourceRegistry} from './observations.js';
import {frozenJson} from '../planning-data.js';

const freeze = value => frozenJson(value, {bytes: 131072, items: 16384}).data;
const parameters = [
  {schema: 'audio.features.v1', units: 'rms-and-monophonic-hz'},
  {schema: 'audio.energy.v1', units: 'linear-rms'},
  {schema: 'timing.onset.v1', units: 'seconds'},
];

// This binds Worker results to the same provenance contract as MIDI. It does
// not run DSP on the UI thread or call an uncalibrated microphone clock a
// session clock. Features, estimates and coverage are separate records.
export class AudioObservationSource {
  constructor({sessionId, observerId, publisher, captureBinding, historyLimit = 128}) {
    if (!Number.isInteger(historyLimit) || historyLimit < 1 || historyLimit > 512) throw new TypeError('Invalid audio history budget');
    const capture = captureBinding;
    if (!capture || !['audio-context-seconds', 'session-seconds'].includes(capture.clockDomain)) throw new TypeError('Audio capture needs an explicit clock domain');
    if (!['isolated','mixture'].includes(capture.role)) throw new TypeError('Unknown audio source role');
    this.registry = new SourceRegistry();
    this.publisher = publisher;
    this.binding = this.registry.register({version: 1, sessionId,
      sourceId: capture.sourceId, sourceIncarnation: capture.sourceIncarnation, observerId,
      publisherId: publisher.id, publisher, bindingVersion: 'audio-binding-v1',
      performerId: capture.performerId, deviceId: capture.sourceId, endpoint: capture.sourceId,
      modality: 'audio', role: capture.role === 'isolated' ? 'performer' : 'mixture',
      parameters, kinds: ['measurement', 'estimate', 'coverage'],
      clockMappingVersion: capture.clockMappingVersion, calibrationVersion: capture.clockMappingVersion,
      possibleSelfOutput: capture.possibleSelfOutput}, publisher);
    this.clockDomain = capture.clockDomain;
    this.historyLimit = historyLimit;
    this.records = [];
    this.sequence = 0;
    this.lastFrameSequence = -1;
    this.coverage = 'missing';
    this.latest = null;
    this.lastAvailableAt = null;
    this.droppedRecords = 0;
  }

  record(schema, kind, when, value, frameSequence, coverage = 'complete', sequence = this.sequence) {
    const b = this.binding;
    const frameId = frameSequence === null ? null : `${b.sourceId}:${b.sourceIncarnation}:frame-${frameSequence}`;
    const observation = this.registry.observation({version: 1, sessionId: b.sessionId,
      sourceId: b.sourceId, sourceIncarnation: b.sourceIncarnation, observerId: b.observerId,
      publisherId: b.publisherId, bindingVersion: b.bindingVersion,
      observationId: `${b.sourceId}:${b.sourceIncarnation}:${sequence}`, sequence,
      parameterSchema: schema, units: parameters.find(p => p.schema === schema).units,
      kind, when, value, coverage, quality: {calibrationStatus: 'uncalibrated'},
      // Audio samples are recycled by the bounded handoff, not retained here.
      rawEventRefs: [], ancestry: frameId ? [frameId] : [], correlationGroup: frameId,
      extractorVersion: 'meyda-rms-5.6.3-pitchy-4.1.0',
      calibrationVersion: b.calibrationVersion, validInterval: null},
    {origin: this.publisher, receivedAt: when.receivedAt});
    return observation;
  }

  commit(records) {
    this.sequence += records.length;
    this.records.push(...records);
    const excess = this.records.length - this.historyLimit;
    if (excess > 0) { this.records.splice(0, excess); this.droppedRecords += excess; }
  }

  accept(input) {
    const report = freeze(input), {binding, when, features, sequence} = report;
    if (binding.sourceId !== this.binding.sourceId || binding.sourceIncarnation !== this.binding.sourceIncarnation ||
      binding.clockMappingVersion !== this.binding.clockMappingVersion || when.clockDomain !== this.clockDomain)
      throw new Error('Audio source or clock changed; start a new observation binding');
    if (!Number.isSafeInteger(sequence) || sequence <= this.lastFrameSequence) throw new Error('Duplicate or reordered audio feature frame');
    if (!when || when.availableAt < (this.lastAvailableAt ?? -Infinity) || when.eventEnd > when.availableAt ||
      when.eventStart > when.eventEnd || when.receivedAt < when.availableAt) throw new Error('Noncausal audio feature availability');
    for (const key of ['rms', 'smoothedRms', 'energyVariance', 'pitchClarity']) {
      if (!Number.isFinite(features[key]) || features[key] < 0) throw new TypeError(`Invalid audio ${key}`);
    }
    if (features.pitchHz !== null && (!Number.isFinite(features.pitchHz) || features.pitchHz <= 0)) throw new TypeError('Invalid audio pitch');
    if (features.coverage !== 'complete') throw new Error('Missing audio is a coverage record, not a measured frame');
    // An onset lies in the window it was searched in: this frame, or from the start of the frame before, where
    // an attack heard in this frame began.
    const onset = features.onset, from = onset?.windowStart ?? when.eventStart, to = onset?.windowEnd ?? when.eventEnd;
    if (onset && (!Number.isFinite(onset.estimateSeconds) || !Number.isFinite(onset.varianceSeconds2) || onset.varianceSeconds2 < 0 ||
      !Number.isFinite(from) || !Number.isFinite(to) || from > to || to > when.eventEnd ||
      from < when.eventStart - (when.eventEnd - when.eventStart) - 1e-9 || onset.estimateSeconds < from || onset.estimateSeconds > to))
      throw new TypeError('Invalid acoustic onset window');
    const outputs = [this.record('audio.features.v1', 'measurement', when, {
      rms: features.rms, pitchHz: features.pitchHz, pitchClarity: features.pitchClarity,
      pitchStatus: features.pitchStatus, vocabulary: features.vocabulary,
    }, sequence)];
    outputs.push(this.record('audio.energy.v1', 'estimate', when, {
      mean: features.smoothedRms, variance: features.energyVariance, modelId: 'scalar-walk-v1',
      calibrationStatus: features.calibrationStatus,
    }, sequence, 'complete', this.sequence + 1));
    if (onset) outputs.push(this.record('timing.onset.v1', 'measurement', {...when, eventStart: from}, onset, sequence, 'complete', this.sequence + 2));
    this.commit(outputs);
    this.lastFrameSequence = sequence;
    this.lastAvailableAt = when.availableAt;
    this.latest = report;
    this.coverage = 'complete';
    return outputs;
  }

  missing({when, reason, invalid = false}) {
    const coverage = invalid ? 'invalid' : 'missing';
    if (when.availableAt < (this.lastAvailableAt ?? -Infinity)) throw new Error('Coverage cannot precede available audio evidence');
    const observation = this.record('audio.features.v1', 'coverage', when, null, null, coverage);
    this.commit([observation]);
    this.lastAvailableAt = when.availableAt;
    this.coverage = coverage;
    this.coverageReason = reason;
    this.latest = null;
    return observation;
  }

  snapshot() {
    return freeze({binding: this.binding, coverage: this.coverage, clockDomain: this.clockDomain,
      coverageReason: this.coverage === 'complete' ? null : this.coverageReason || 'waiting-for-audio',
      retainedFeatureRecords: this.records.length, droppedFeatureRecords: this.droppedRecords,
      rawAudioRetained: false, revision: this.sequence, latest: this.latest});
  }
}
