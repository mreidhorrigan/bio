// Where a listener's learned beat tracker runs (learned-pulse.js), installed by the host: a render installs its helper
// process (render/node/beats-host.mjs), a desktop page's analysis worker the desktop bridge. A tracker is
// {stream({sampleRate, windowSeconds}) -> {append(samples, {frames}), close()}}. Without one, a learned listening
// cannot be heard, and says so.
let installed=null;
// Returns a function that puts back what was installed before.
export function installBeatTracker(tracker){
  if(tracker!==null&&typeof tracker?.stream!=='function')throw new TypeError('A beat tracker opens streams: {stream({sampleRate, windowSeconds})}');
  const previous=installed;installed=tracker;
  return ()=>{if(installed===tracker)installed=previous};
}
export const beatTracker=()=>installed;
