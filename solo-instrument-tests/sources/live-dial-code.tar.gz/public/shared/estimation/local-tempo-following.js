import {compoundLabel} from '../meter-tactus.js';
import {actor,frozenJson} from '../planning-data.js';
import {randomUUID} from '../random-id.js';
import {EnsembleTempoMap,prepareInputTempoRamp} from '../ensemble-tempo-map.js';
import {TempoInfluenceController} from './tempo-influence.js';
import {curveBars,updateTempoCurve as updateLocalTempo} from '../tempo-curve.js';
import {holdQuiet,holdAhead} from '../clock-hold.js';
import {rubatoQuiet,rubatoAhead} from '../rubato-clocks.js';

export {curveBars,updateLocalTempo};
// The clocks' holds (clock-hold.js), for the server's clock, which reads this module's build (local-tempo-following.cjs).
export {queueHold,releaseHold,readyHold,selectHold,takeAnnouncements,holdAtPulse,awaitingCue,settleHold,holdSeconds,holdStatus} from '../clock-hold.js';
// And their rubato spans (rubato-clocks.js).
export {RUBATO_ADDRESSES,rubatoControl,takeRubatoAnnouncements,rubatoPulse,rubatoOwnsTempo,rubatoStatus} from '../rubato-clocks.js';

// A manual tempo switches following off: someone has taken the tempo by hand. A
// composed curve (a bot's /broadcast/tempoCurve, as mh_PlexBOT sends one with
// every section) is part of the piece: it voids a window still collecting, and
// following pauses while the curve is pending or playing (readyForWindow) and
// resumes after it, as the networked conductor already does.
export function allowLocalTempoChange(state,{composed=false}={}) {
  if(state.inputTempoCommit){state.lastTempoRejection='input-tempo-ramp-already-committed';return false;}
  // A rubato span playing owns the tempo until it ends (rubato-clocks.js): a hand's tempo or a curve waits for it.
  if(state.rubato){state.lastTempoRejection='rubato-span-playing';return false;}
  state.lastTempoRejection=null;state.localTempoFollowing?.invalidate(composed?'composed-tempo-curve':'manual-tempo',!composed);return true;
}

export class LocalTempoFollowing {
  // outputDelaySeconds: from a pulse's emission to its sound, the bots' scheduling lookahead (a render knows it exactly).
  // proposeMeter(value, mode, publisher): how this clock takes a meter request, for the performer's subdivision.
  constructor(state,{identity={id:'local-conductor',incarnation:randomUUID()},now=()=>performance.now()/1000,
    active,send,onChange=()=>{},outputDelaySeconds=()=>.25,proposeMeter=null}) {
    this.state=state;this.identity=actor(identity);this.now=now;this.localActive=active;this.epoch=randomUUID();this.outputDelaySeconds=outputDelaySeconds;
    this.proposeMeter=proposeMeter;
    this.sessionId=randomUUID();this.revision=0;this.events=[];this.host=this.identity.id;
    const self=this;
    // This is an adapter for the existing local clock, not a second clock or
    // a new reference-election participant. Source phase is never imported.
    this.clock={get isReference(){return self.active();},get offer(){return {reference:{epoch:self.epoch}};},
      status:()=>({ready:this.active()}),referenceTime:now};
    this.controller=new TempoInfluenceController({identity:this.identity,clock:this.clock,ensemble:this,scopeMode:'local',
      send,ready:()=>this.active(),onChange});
    this.controller.destination='ensemble';
  }
  active(){return Boolean(this.localActive()&&this.state.nextAt>0);}
  get primary(){return this.active()?this.host:null;}
  get cursor(){return this.active()?this.timingSnapshot().cursor:null;}
  timingSnapshot() {
    const s=this.state,projection={bpm:s.bpm,bar:s.bar,tickInBar:s.tickInBar,meter:s.meter,
      pendingTempoCurve:s.pendingTempoCurve,tempoCurve:s.tempoCurve,inputTempoCommit:s.inputTempoCommit??null};
    updateLocalTempo(projection);
    const beat=s.session.beat+Number(s.session.firstBeatAt!==null&&s.tick>s.session.lastBeatTick&&s.tickInBar%s.meter.subdivision===0);
    return new EnsembleTempoMap({sessionId:this.sessionId,cursor:{version:1,epoch:this.epoch,revision:this.revision,
      tick:s.tick,bar:s.bar,tickInBar:s.tickInBar,beat,at:s.nextAt/1000,bpm:projection.bpm,meter:s.meter,
      pendingMeter:null,pendingTempo:projection.pendingTempoCurve,curve:projection.tempoCurve,inputTempoCommit:projection.inputTempoCommit,
      holds:s.holds??[],holding:s.holding??null}});
  }
  readyForWindow(){return this.active()&&this.free();}
  // No composed or manual tempo curve, input ramp or meter change is pending or playing, no hold is held or just
  // re-entered (clock-hold.js holdQuiet), and no rubato span plays or has just ended (rubato-clocks.js rubatoQuiet).
  free(){const s=this.state;return !s.pendingTempoCurve&&!s.tempoCurve&&!s.inputTempoCommit&&!s.pendingMeter&&!s.localMeterChanges?.windows.size&&!holdQuiet(s)&&!rubatoQuiet(s);}
  // Beat synchronization's view of the clock (beat-sync.js): the pulse about to be emitted, when it sounds, whether
  // it starts a beat, the beat's duration now, whether the clock may be steered, and whether any bot is sounding; and
  // where the pulse is in its phrase (0 at the phrase's downbeat), for a performer's declared lean (tempo-influence.js).
  beatCursor(){
    const s=this.state;if(!this.active())return null;
    const emitAt=s.nextAt/1000,phraseBars=Math.max(1,Number(s.meter.phraseBars)||4);
    return {tick:s.tick,isBeat:s.tickInBar%s.meter.subdivision===0,emitAt,soundAt:emitAt+this.outputDelaySeconds(),beatSeconds:60/s.bpm,
      subdivision:s.meter.subdivision,referencePulse:{numerator:1,denominator:s.meter.denominator},free:this.free(),quiet:!this.sounding(),
      phrasePosition:((((Number(s.bar)||0)%phraseBars)+phraseBars)%phraseBars+s.tickInBar/s.meter.pulsesPerBar)/phraseBars};
  }
  // The same meter with the performer's subdivision, from the next bar. False when this clock takes no requests.
  proposeSubdivision(parts){
    if(typeof this.proposeMeter!=='function'||!this.free())return false;
    // Threes count the same beats in thirds, a compound meter in its tactus, and name it so: 4/4 in threes is 12/8
    // (meter-tactus.js). The bots play it as one.
    const m=this.state.meter,label=parts%3===0?compoundLabel(m):null;
    this.proposeMeter({numerator:m.numerator,denominator:m.denominator,subdivision:parts,phraseBars:m.phraseBars,...(label?{label}:{})},'nextBar',this.identity);
    return true;
  }
  sounding(){const bots=this.state.session?.bots;return Boolean(bots&&[...bots.values()].some(bot=>bot.output&&!bot.loadOnly&&!bot.muted));}
  // The coming beat's tempo; a tempo curve still overrides it (a steered beat is never taken while one plays).
  steerBeat(bpm){this.state.bpm=bpm;return bpm;}
  // Run by the local clock just before it works out each pulse's tempo.
  beforePulse(){return this.controller.beforePulse();}
  prepareTempoInfluence(now=this.now(),leadSeconds=3) {
    if(!Number.isFinite(leadSeconds)||leadSeconds<3||leadSeconds>6)throw new Error('Invalid tempo collection lead');
    if(!this.readyForWindow())return null;
    // A window never reaches past a hold or into a rubato span: its evidence would read either as a tempo change.
    const map=this.timingSnapshot(),boundary=map.barAfter(now+leadSeconds,{minimumBar:map.cursor.bar+1});
    return holdAhead(this.state,boundary.bar)||rubatoAhead(this.state,boundary.bar)?null:{map,boundary};
  }
  acceptsTempoBasis(map){return this.readyForWindow()&&map instanceof EnsembleTempoMap&&map.sessionId===this.sessionId&&map.epoch===this.epoch&&map.cursor.revision===this.revision;}
  acceptTempoInfluence(request) {
    if(!this.acceptsTempoBasis(request.map))throw new Error('Local ensemble timing changed before selection');
    const {candidate,accepted}=prepareInputTempoRamp({...request,sessionId:this.sessionId,cursor:this.timingSnapshot().cursor,now:this.now()});
    this.state.pendingTempoCurve=candidate.pendingTempo;this.state.inputTempoCommit=candidate.inputTempoCommit;
    this.revision=candidate.revision;return accepted;
  }
  enable(request){
    if(request.destination&&request.destination!=='ensemble')throw new Error('Local following controls the playing ensemble.');
    return this.controller.enable({...request,destination:'ensemble'});
  }
  receive(message){return this.controller.receive(message);}
  pump(){this.controller.pump();}
  invalidate(reason,disable=false){this.revision++;if(disable)this.controller.disable(reason);}
  reset(reason) {
    if(this.controller.enabled||this.state.inputTempoCommit){
      this.events.push({reason,atReference:this.now(),epoch:this.epoch,decisionId:this.state.inputTempoCommit?.decisionId??null});
      if(this.events.length>16)this.events.shift();
    }
    this.controller.disable(reason);
    if(this.state.inputTempoCommit){this.state.pendingTempoCurve=null;this.state.tempoCurve=null;this.state.inputTempoCommit=null;}
    this.epoch=randomUUID();this.revision=0;
  }
  status(){return {available:this.active(),bpm:this.state.bpm,meter:this.state.meter,
    tempoRejection:this.state.inputTempoCommit?this.state.lastTempoRejection??null:null,...this.controller.status()};}
  snapshot(){return frozenJson({version:1,timeDomain:'local-monotonic-seconds',tempoFollowing:this.controller.snapshot(),events:this.events},
    {bytes:3*1024*1024,items:393216}).data;}
}
