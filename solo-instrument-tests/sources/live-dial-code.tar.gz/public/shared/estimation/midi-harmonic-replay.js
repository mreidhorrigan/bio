import {MidiHarmonicProjection,HARMONIC_STATE_BUDGET} from './midi-harmony.js';
import {ObservationReplay} from './observation-replay.js';
import {frozenJson} from '../planning-data.js';

const freeze=value=>frozenJson(value,HARMONIC_STATE_BUDGET).data;
const benignRejections=new Set(['duplicate-evidence','incompatible-source-or-model-scope']);

// Replays original events through the existing converter and note lifecycle.
// No output is scheduled here. Categorical label beliefs consume the repaired
// material once, at its current availability, rather than replaying arrivals as
// though their later information had been known at the earlier event time.
export class MidiHarmonicReplay {
  static async prepare(options={}) {
    const {eventLimit,historySeconds,snapshotLimit,...projectionOptions}=options;
    const projectionFactory=await MidiHarmonicProjection.prepare(projectionOptions);
    return ()=>new MidiHarmonicReplay({projectionFactory,eventLimit,historySeconds,snapshotLimit});
  }
  constructor({projectionFactory=checkpoint=>new MidiHarmonicProjection({checkpoint}),
    eventLimit=128,historySeconds=8,snapshotLimit=8}={}) {
    this.projectionFactory=projectionFactory;
    this.coverage='complete';this.loss=null;this.availableAt=null;this.lastRejection=null;this.sealed=new Map();
    const initial=projectionFactory();
    const reduceBatch=(state,observations)=>{
      const projection=projectionFactory(state.checkpoint);
      for(const observation of observations)projection.consume({bytes:observation.value.bytes,packets:observation.value.packets,
        eventTime:observation.when.eventStart,
        availableAt:Math.max(projection.availableAt??-Infinity,observation.when.availableAt,observation.receivedAt)});
      return {checkpoint:projection.checkpoint(),material:projection.snapshot()};
    };
    this.replay=new ObservationReplay({initial:{checkpoint:initial.checkpoint(),material:initial.snapshot()},eventLimit,historySeconds,snapshotLimit,
      stateBytes:HARMONIC_STATE_BUDGET.bytes,stateItems:HARMONIC_STATE_BUDGET.items,
      reduceBatch,reduce:(state,observation)=>reduceBatch(state,[observation])});
    this.material=this.replay.current.material;
  }
  observe(observation) { return this.observeMany([observation]); }
  observeMany(observations) {
    if(this.coverage!=='complete')throw new Error('Unavailable harmonic coverage needs a new source incarnation');
    if(!Array.isArray(observations)||!observations.length||observations.length>128)throw new TypeError('Invalid harmonic batch budget');
    for(const observation of observations){
    const raw=observation?.value;
    if(observation?.parameterSchema!=='midi.raw.v1'||observation.units!=='UMP-and-original-bytes'||
      observation.kind!=='measurement'||observation.coverage!=='complete'||!raw||
      raw.eventTime!==observation.when?.eventStart||raw.sourceId!==observation.sourceId||
      raw.sourceIncarnation!==observation.sourceIncarnation||!Array.isArray(raw.packets)||
      !(raw.bytes===null||Array.isArray(raw.bytes)))throw new TypeError('A canonical raw MIDI observation is required');
    }
    const availableAt=Math.max(...observations.map(observation=>observation.receivedAt));
    let result;
    try {result=this.replay.insertMany(observations);}
    catch(error){this.invalidate('harmonic-replay-failed',availableAt);throw error;}
    if(!result.accepted){
      this.lastRejection=result.reason;
      // A dropped release or pedal message can invalidate every later held
      // note. A foreign source or an exact forwarded duplicate cannot.
      if(!benignRejections.has(result.reason))this.invalidate(result.reason,availableAt);
      return {...result,material:this.snapshot()};
    }
    this.lastRejection=null;
    this.material=result.state.material;
    this.availableAt=this.material.availableAt;
    return {accepted:true,late:result.late,revision:result.revision,material:this.snapshot()};
  }
  invalidate(reason,availableAt) {
    this.coverage='invalid';this.lastRejection=reason;
    this.availableAt=Math.max(this.availableAt??-Infinity,Number.isFinite(availableAt)?availableAt:this.availableAt??0);
    this.loss??={reason,availableAt:this.availableAt};
  }
  disconnect(availableAt) {
    if(!Number.isFinite(availableAt)||this.availableAt!==null&&availableAt<this.availableAt)throw new TypeError('Invalid disconnection time');
    this.coverage='missing';this.availableAt=availableAt;this.loss??={reason:'missing-source-coverage',availableAt};
    return this.snapshot();
  }
  snapshot() {
    const replay=this.replay;
    return freeze({...this.material,coverage:this.coverage,availableAt:this.availableAt,
      notes:this.coverage==='complete'?this.material.notes:null,
      replay:{revision:replay.revision,eventLimit:replay.eventLimit,historySeconds:replay.historySeconds,
        retainedEvents:replay.events.length,replayedEvents:replay.replayedEvents,lastRejection:this.lastRejection,
        checkpointEventTime:Number.isFinite(replay.checkpointEventTime)?replay.checkpointEventTime:null}});
  }
  seal(id,cutoff) {
    const previous=this.sealed.get(id);
    if(previous){if(previous.cutoff!==cutoff)throw new TypeError('Snapshot IDs cannot change cutoff');return previous;}
    const evidence=this.replay.seal(id,cutoff),loss=this.loss&&this.loss.availableAt<=cutoff;
    const known=evidence.status==='known'&&!loss;
    const snapshot=freeze({version:1,beliefId:id,revision:evidence.revision,cutoff,scope:evidence.scope,
      status:known?'known':'unknown',reason:loss?this.loss.reason:evidence.reason,
      material:known?evidence.state.material:null,
      inputObservationIds:evidence.inputObservationIds,checkpointEventTime:evidence.checkpointEventTime,
      checkpointCursor:evidence.checkpointCursor,
      checkpointAvailableAt:evidence.checkpointAvailableAt});
    this.sealed.set(id,snapshot);return snapshot;
  }
}
