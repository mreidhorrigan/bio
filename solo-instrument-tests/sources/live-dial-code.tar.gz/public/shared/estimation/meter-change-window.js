import {actor, actorKey, frozenJson, identifier} from '../planning-data.js';
import {MeterNegotiation} from './meter-negotiation.js';
import {metricalState} from './metrical-state.js';

const freeze = value => frozenJson(value, {bytes: 262144, items: 32768}).data;
export const meterInterpretation = meter => ({id: 'declared-meter', numerator: meter.numerator, denominator: meter.denominator,
  groups: meter.groups, referencePulse: {numerator: 1, denominator: 4}, phase: {numerator: 0, denominator: 1}});
export const meterRealization = meter => JSON.stringify([meter.numerator, meter.denominator, meter.groups,
  meter.subdivision, meter.phraseBars, meter.rhythm?.hits ?? null, meter.rhythm?.rotation ?? 0, meter.rhythm?.clave || []]);

export function meterChangePolicy(value = {}) {
  const resolution = value.resolution || 'agreement';
  if (!['agreement', 'priority', 'follow-leader', 'maintain', 'polymeter'].includes(resolution)) throw new TypeError('Unknown meter change policy');
  const leader = value.leader || null;
  if (leader !== null) identifier(leader, 'meter leader');
  if (resolution === 'follow-leader' && !leader) throw new Error('Name the meter-specific leader');
  return Object.freeze({resolution, leader});
}

// The transport supplies authenticated records and the decision boundary.
// Local bar changes and future shared changes use the same categorical policy.
export function resolveMeterChange({base, records, identity, sessionId, scope, policy, currentMeter}) {
  const {decisionId, cutoff, effectiveAt} = base;
  const leader = records.find(record => record.publisher.id === policy.leader)?.publisher;
  const hold = reason => freeze({...base, status: 'unresolved', reason, meter: currentMeter,
    alternatives: records.map(record => ({publisher: record.publisher, meter: record.meter})), accepted: false});
  if (policy.resolution === 'follow-leader' && !leader) return hold('meter-leader-has-no-proposal');
  const resolver = new MeterNegotiation({identity, scope, sessionId,
    policyVersion: 'conductor-meter-v1', resolution: policy.resolution, leader,
    publishers: records.map(record => ({publisher: record.publisher, priority: record.priority}))});
  const expiresAt = effectiveAt + 1;
  for (const record of records) resolver.receive({version: 1, sessionId, reportId: `${decisionId}:${record.sequence}`,
    sequence: record.sequence, publisher: record.publisher, kind: 'proposal', availableAt: record.receivedAt,
    validFrom: effectiveAt, validUntil: expiresAt, meter: meterInterpretation(record.meter)},
  {origin: record.publisher, receivedAt: record.receivedAt});
  const proposal = resolver.seal({decisionId, cutoff, effectiveAt, expiresAt,
    currentMeter: meterInterpretation(currentMeter)});
  const selected = records.filter(record => proposal.basis.selected.includes(`${decisionId}:${record.sequence}`));
  if (proposal.status === 'resolved' && new Set(selected.map(record => meterRealization(record.meter))).size > 1)
    return hold('conflicting-meter-realizations');
  const accepted = proposal.status === 'resolved' && policy.resolution !== 'maintain' && selected.length > 0;
  return freeze({...base, status: proposal.status, reason: proposal.reason, accepted,
    meter: accepted ? selected[0].meter : currentMeter, proposal});
}

// The primary collects proposals for one future boundary, then seals once.
// A representative may attest only bots on its own LAN. Being the clock
// primary does not make its own meter proposal a zero-noise measurement.
export class MeterChangeWindow {
  constructor({identity, sessionId, epoch, members, targetBar, effectiveAt, cutoff, currentMeter, policy}) {
    this.identity = actor(identity); this.sessionId = identifier(sessionId); this.epoch = identifier(epoch);
    if (!Number.isSafeInteger(targetBar) || targetBar < 0 || !Number.isFinite(effectiveAt) || !Number.isFinite(cutoff) || cutoff >= effectiveAt)
      throw new TypeError('Invalid meter decision boundary');
    this.policy = meterChangePolicy(policy);
    this.members = new Map(members.map(member => [identifier(member.host), {incarnation: identifier(member.incarnation), priority: member.priority}]));
    if (!this.members.size || this.members.size > 64 || [...this.members.values()].some(member => !Number.isInteger(member.priority) || member.priority < 0 || member.priority > 100))
      throw new TypeError('Invalid conductor membership');
    Object.assign(this, {targetBar, effectiveAt, cutoff, currentMeter: freeze(currentMeter)});
    this.proposals = new Map(); this.sequence = 0; this.sealed = null;
  }
  receive({publisher, host, hostIncarnation, meter, receivedAt}) {
    publisher = actor(publisher);
    const member = this.members.get(host);
    if (!member || member.incarnation !== hostIncarnation || !publisher.id.startsWith(`${host}::`))
      throw new Error('Meter publisher is outside the authenticated representative');
    if (!Number.isFinite(receivedAt) || receivedAt >= this.cutoff || this.sealed) throw new Error('Meter decision cutoff has closed');
    meter = freeze(meter); metricalState(meterInterpretation(meter)); // Normalization belongs to the existing meter API.
    const previous = this.proposals.get(publisher.id);
    if (previous && actorKey(previous.publisher) === actorKey(publisher) && meterRealization(previous.meter) === meterRealization(meter)) return false;
    if (!previous && this.proposals.size >= 64) throw new Error('Meter publisher budget exhausted');
    this.proposals.set(publisher.id, {publisher, host, hostIncarnation, meter, receivedAt, sequence: ++this.sequence, priority: member.priority});
    return true;
  }
  // `authority`: the room's conductorbot, where one conducts it (ensemble-conductor.js authority). Its proposal decides,
  // or the room's own conductor's before it (a person at the controls); where neither proposed, the meter stays: a
  // transport selects no meter of its own while a conductorbot plans the piece. Without one, the policy resolves the
  // proposals, the fallback.
  seal(now, {minimumDeliverySeconds = 1, authority = null} = {}) {
    if (this.sealed) return this.sealed;
    if (!Number.isFinite(now) || now < this.cutoff || !Number.isFinite(minimumDeliverySeconds) || minimumDeliverySeconds < 0)
      throw new Error('Meter selection cannot precede its cutoff');
    const records = [...this.proposals.values()];
    const decisionId = `${this.epoch}:meter:${this.targetBar}`;
    const leading = authority ? records.find(record => record.publisher.id.endsWith('::conductor')) ??
      records.find(record => record.publisher.id === authority) : null;
    const policy = leading ? meterChangePolicy({resolution: 'follow-leader', leader: leading.publisher.id}) : this.policy;
    const base = {decisionId, targetBar: this.targetBar, cutoff: this.cutoff, effectiveAt: this.effectiveAt,
      policy, inputKind: 'artistic-proposal', authority: this.identity, ...(authority ? {conductor: authority} : {})};
    const hold = reason => this.sealed = freeze({...base, status: 'unresolved', reason, meter: this.currentMeter,
      alternatives: records.map(record => ({publisher: record.publisher, meter: record.meter})), accepted: false});
    if (now > this.effectiveAt - minimumDeliverySeconds) return hold('insufficient-delivery-time');
    if (authority && !leading) return hold('not-in-the-conductors-plan');
    const scope = {mode: 'shared', membershipId: decisionId, participants: [...this.members].map(([host, member]) =>
      ({id: `${host}::conductor`, incarnation: member.incarnation}))};
    return this.sealed = resolveMeterChange({base, records, identity: this.identity, sessionId: this.sessionId,
      scope, policy, currentMeter: this.currentMeter});
  }
  updateBoundary(effectiveAt) {
    if (this.sealed || !Number.isFinite(effectiveAt)) throw new Error('Only an unsealed meter boundary can follow a tempo revision');
    // The bar is unchanged. Its predicted wall time may move with an accepted
    // tempo curve before the meter decision is sealed.
    this.effectiveAt = effectiveAt; this.cutoff = effectiveAt - 1.5;
  }
  status() {
    return this.sealed || {targetBar: this.targetBar, cutoff: this.cutoff, effectiveAt: this.effectiveAt,
      policy: this.policy, status: 'collecting', publishers: [...this.proposals.values()].map(record => record.publisher)};
  }
}
