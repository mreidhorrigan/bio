import {ObservationClockMapping} from './observations.js';
import {randomUUID} from '../random-id.js';
import {listeningOptions} from './listening-options.js';
import {LEARNED_RHYTHM_DEFAULT,LEARNED_RHYTHM_LISTENINGS} from './audio-frame-analysis.js';
import {HARMONY_LISTENINGS} from './harmony-listenings.js';
import {vst3BridgeUrl as bridgeUrl} from '../../synths/vst3-bridge.js';
import {bridgeAnswers} from './bridge-trackers.js';

// One analysed frame as a source report, its times mapped from the capture's
// clock into the source's declared domain. Onsets, the pulse follower's
// predicted beat, the beam's forecasts and the chroma window all go through the same mapping, so
// every time in the report is in one domain; a forecast's period and tempo go through its rate (below). Returns
// null when the mapping would put the frame after it became available. An onset
// keeps the window it was searched in, which can begin in the frame before
// (audio-features.js places an attack where it began).
export function captureReport({binding,mapping,clockDomain,availableAt,receipt,captureDomain,data}) {
  const features=data.features,time=value=>mapping.time(value,{event:true}),variance=value=>value*mapping.rate**2+mapping.timingVarianceSeconds2;
  const eventStart=time(features.when.start),eventEnd=time(features.when.end);
  if(eventEnd>availableAt)return null;
  const onset=features.onset?{...features.onset,windowStart:time(features.onset.windowStart??features.when.start),
    windowEnd:time(features.onset.windowEnd??features.when.end),estimateSeconds:time(features.onset.estimateSeconds),
    varianceSeconds2:variance(features.onset.varianceSeconds2)}:null;
  const when={eventStart,eventEnd,availableAt,receivedAt:availableAt,receiptMonotonicSeconds:receipt,lookaheadSeconds:0,
    clockDomain,clockMappingVersion:mapping.version,timingVarianceSeconds2:mapping.timingVarianceSeconds2,calibrationStatus:mapping.calibrationStatus};
  // Every dimensioned field through the mapping: times as times, variances by rate², and a period by rate (its tempo by
  // 1/rate). A period had been left in the capture clock: at rate 2, time 2 went to 4 and its variance .01 to .04 while
  // its period stayed .5 and its bpm 120, where they are 1 and 60 (the mathematical audit's I10). A clock conversion is
  // not a change of tempo: at rate 1, nothing changes.
  const forecast=value=>value?{...value,expectedTime:time(value.expectedTime),
    ...(Number.isFinite(value.periodSeconds)?{periodSeconds:value.periodSeconds*mapping.rate}:{}),
    ...(Number.isFinite(value.bpm)?{bpm:value.bpm/mapping.rate}:{}),
    ...(Number.isFinite(value.lastEvidenceAt)?{lastEvidenceAt:time(value.lastEvidenceAt)}:{}),
    ...(Number.isFinite(value.latentTimeVariance)?{latentTimeVariance:variance(value.latentTimeVariance)}:{}),
    ...(Number.isFinite(value.performedTimeVariance)?{performedTimeVariance:variance(value.performedTimeVariance)}:{})}:value;
  return {binding,sequence:data.sequence,features:{...features,when,onset},when,
    captureWindow:{clockDomain:captureDomain,start:features.when.start,end:features.when.end},
    rhythm:data.rhythm?{...data.rhythm,clockDomain,clockMappingVersion:mapping.version,
      candidates:(data.rhythm.candidates||[]).map(candidate=>({...candidate,forecast:forecast(candidate.forecast)}))}:null,
    pulse:data.pulse?{...data.pulse,clockDomain,clockMappingVersion:mapping.version,forecast:forecast(data.pulse.forecast)}:null,
    // The chroma of the spectrum that ended with this frame.
    harmony:data.harmony?{...data.harmony,clockDomain,clockMappingVersion:mapping.version,
      windowStart:time(features.when.end-data.harmony.windowSeconds),windowEnd:eventEnd,
      // A learned recognizer's chords (learned-chords.js) are stated at their frame's time, mapped as the rest.
      ...(data.harmony.chords?{chords:{...data.harmony.chords,at:time(data.harmony.chords.at)}}:{})}:null,
    // A monophonic pitch, at the frame's middle.
    pitch:data.pitch?{...data.pitch,at:time((features.when.start+features.when.end)/2)}:null,
    processingMs:data.processingMs};
}

// A reusable host adapter. Its caller supplies the local permission gesture and
// performer/mixture assignment. It never publishes to a relay or changes music.
export class PerformerAudioCapture {
  constructor({context,mediaDevices=globalThis.navigator?.mediaDevices,now=()=>performance.now()/1000,
    onReport=()=>{},onCoverage=()=>{},WorkerClass=globalThis.Worker,WorkletNodeClass=globalThis.AudioWorkletNode,
    assetURLs=globalThis.MUSEBOTS_INPUT_ASSET_URLS||{worklet:'shared/estimation/audio-capture-worklet.js',worker:'shared/estimation/audio-analysis-worker.js'}}={}) {
    Object.assign(this,{context,mediaDevices,now,onReport,onCoverage,WorkerClass,WorkletNodeClass,assetURLs});this.generation=0;this.state='idle';
  }
  // listening: how the frame analysis hears (listening-options.js), or null for its defaults. The beat's default is
  // the learned tracker where the desktop's bridge answers (bridge-trackers.js), else the beam's bass accent.
  async start({deviceId,performerId=null,role='mixture',possibleSelfOutput=true,frameSize=2048,mapping=null,listening=null}={}) {
    if(this.state!=='idle')throw new Error('Stop the existing microphone capture before starting a new one');
    let heard=listening===null?{}:listeningOptions(listening);
    if(!['isolated','mixture'].includes(role)||role==='mixture'&&performerId!==null||role==='isolated'&&(!performerId||typeof performerId!=='string'))throw new Error('Identify an isolated performer, or explicitly select an unidentified mixture');
    if(typeof possibleSelfOutput!=='boolean')throw new TypeError('Declare whether microphone capture may contain bot output');
    if(!Number.isInteger(frameSize)||frameSize<256||frameSize>8192||(frameSize&(frameSize-1)))throw new TypeError('Invalid capture frame size');
    if(!this.mediaDevices?.getUserMedia||!this.context?.audioWorklet)throw new Error('This host does not provide microphone AudioWorklet capture');
    this.state='permission';const generation=++this.generation;
    // A listening left to its default hears the beat with the learned tracker where the desktop's bridge answers: asked
    // while the microphone is, which is requested at once (a browser may want that within the user's gesture).
    const bridged=heard.rhythm===undefined&&typeof globalThis.WebSocket==='function'?bridgeAnswers(bridgeUrl()):Promise.resolve(false);
    try {
      const stream=await this.mediaDevices.getUserMedia({video:false,audio:{...(deviceId?{deviceId:{exact:deviceId}}:{}),echoCancellation:false,noiseSuppression:false,autoGainControl:false}});
      if(generation!==this.generation){stream.getTracks().forEach(track=>track.stop());return false;}
      this.stream=stream;
      if(await bridged)heard=Object.freeze({...heard,rhythm:LEARNED_RHYTHM_DEFAULT});
      if(generation!==this.generation)return false;
      await this.context.audioWorklet.addModule(new URL(this.assetURLs.worklet,globalThis.location?.href||'http://localhost/'));
      if(generation!==this.generation)return false;
      await this.context.resume();if(generation!==this.generation)return false;
      const incarnation=randomUUID();
      // AudioContext tags processing frames; it is not a calibrated microphone
      // acquisition clock. Retain that domain until the host injects a mapping.
      this.clockDomain=mapping?'session-seconds':'audio-context-seconds';
      this.captureNow=mapping?this.now:()=>this.context.currentTime;
      this.mapping=mapping||new ObservationClockMapping({version:`audio-${incarnation}`,inputUnits:'seconds',
        timingVarianceSeconds2:(128/this.context.sampleRate)**2,calibrationStatus:'unresolved-latency'});
      this.binding=Object.freeze({sourceId:`audio-${incarnation}`,sourceIncarnation:incarnation,performerId,role,possibleSelfOutput,
        sampleRate:this.context.sampleRate,frameSize,clockDomain:this.clockDomain,clockMappingVersion:this.mapping.version,deviceSettings:stream.getAudioTracks()[0]?.getSettings()||{}});
      this.worker=new this.WorkerClass(new URL(this.assetURLs.worker,globalThis.location?.href||'http://localhost/'),{type:'module'});
      this.analysisEpoch=0;this.inputMissing=false;
      // A learned listening (a learned beat or chords) hears through the desktop's bridge, named here for the worker.
      const learned=LEARNED_RHYTHM_LISTENINGS[heard.rhythm]||HARMONY_LISTENINGS[heard.harmony]?.learned;
      // How the band orients to the harmony (orientation, harmonyInput) is the listener's, not the analysis's.
      const {orientation:_orientation,harmonyInput:_harmonyInput,...analysis}=heard;
      const configure=this.configureAnalysis=()=>this.worker.postMessage({type:'configure',epoch:this.analysisEpoch,options:{sampleRate:this.context.sampleRate,frameSize,...analysis},
        ...(learned?{bridge:bridgeUrl()}:{})});
      configure();
      this.node=new this.WorkletNodeClass(this.context,'musebots-performer-capture',{numberOfInputs:1,numberOfOutputs:1,
        outputChannelCount:[1],channelCount:1,channelCountMode:'explicit',processorOptions:{frameSize}});
      this.node.port.onmessage=({data})=>{
        if(generation!==this.generation||data.type!=='frame')return;
        if(this.inputMissing||data.epoch!==this.analysisEpoch)this.node.port.postMessage({type:'return',samples:data.samples},[data.samples.buffer]);
        else this.worker.postMessage({...data,epoch:this.analysisEpoch},[data.samples.buffer]);
      };
      this.worker.onmessage=({data})=>{
        if(generation!==this.generation)return;
        try {
          if(data.epoch!==this.analysisEpoch||this.inputMissing)return;
          if(data.type==='invalid'){this.onCoverage({coverage:'invalid',reason:data.error,binding:this.binding});return;}
          if(data.type!=='features')return;
          if(data.gap)this.onCoverage({coverage:'missing',reason:'bounded-capture-handoff-gap',binding:this.binding});
          const report=captureReport({binding:this.binding,mapping:this.mapping,clockDomain:this.clockDomain,availableAt:this.captureNow(),
            receipt:this.now(),captureDomain:'audio-context-seconds',data});
          if(!report){this.onCoverage({coverage:'invalid',reason:'audio-clock-mapping-ahead-of-availability',binding:this.binding});return;}
          this.onReport(report);
        } finally {
          if(data.samples?.buffer.byteLength)this.node.port.postMessage({type:'return',samples:data.samples},[data.samples.buffer]);
        }
      };
      this.worker.onerror=event=>{this.onCoverage({coverage:'invalid',reason:event.message||'audio-worker-error',binding:this.binding});this.stop();};
      this.source=this.context.createMediaStreamSource(stream);this.mute=this.context.createGain();this.mute.gain.value=0;
      this.source.connect(this.node);this.node.connect(this.mute);this.mute.connect(this.context.destination);
      const refreshCoverage=()=>{
        if(generation!==this.generation)return;
        const missing=this.context.state!=='running'||stream.getAudioTracks().some(track=>track.muted);
        if(missing===this.inputMissing)return;
        this.inputMissing=missing;this.analysisEpoch++;
        this.node.port.postMessage({type:'reset',epoch:this.analysisEpoch});
        if(missing)this.onCoverage({coverage:'missing',reason:this.context.state!=='running'?'audio-context-suspended':'microphone-muted',binding:this.binding});
        else configure(); // A resumed stream begins fresh extraction/association.
      };
      this.contextStateListener=refreshCoverage;
      this.context.addEventListener?.('statechange',refreshCoverage);
      for(const track of stream.getAudioTracks())for(const name of ['mute','unmute'])track.addEventListener(name,refreshCoverage);
      this.trackStateListener=refreshCoverage;
      for(const track of stream.getTracks())track.addEventListener('ended',()=>{if(generation===this.generation){this.onCoverage({coverage:'missing',reason:'microphone-ended',binding:this.binding});this.stop();}},{once:true});
      refreshCoverage();
      this.state='listening';return true;
    }catch(error){if(generation===this.generation)this.stop();throw error;}
  }
  renewSourceIncarnation(reason='publisher-identity-changed') {
    if(!this.binding||!this.worker||!this.node) return false;
    this.onCoverage({coverage:'missing',reason,binding:this.binding});
    this.binding=Object.freeze({...this.binding,sourceIncarnation:randomUUID()});
    this.analysisEpoch++;
    this.node.port.postMessage({type:'reset',epoch:this.analysisEpoch});
    if(!this.inputMissing)this.configureAnalysis();
    return this.binding;
  }
  stop(){
    this.generation++;this.state='idle';this.node?.port.postMessage({type:'stop'});
    this.context?.removeEventListener?.('statechange',this.contextStateListener);
    for(const track of this.stream?.getAudioTracks()||[])for(const name of ['mute','unmute'])track.removeEventListener?.(name,this.trackStateListener);
    this.contextStateListener=this.trackStateListener=null;
    this.node?.disconnect();this.source?.disconnect();this.mute?.disconnect();this.worker?.terminate();
    this.stream?.getTracks().forEach(track=>track.stop());
    this.node=this.source=this.mute=this.worker=this.stream=this.configureAnalysis=null;
  }
}
