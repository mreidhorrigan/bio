// Where a listener's learned chord recognizer runs (learned-chords.js), installed by the host, as beat trackers are
// (beat-trackers.js): a render installs its helper process (render/node/chords-host.mjs). A recognizer is
// {stream({sampleRate, windowSeconds, lagSeconds}) -> {append(samples, {frames}), close()}}.
let installed=null;
export function installChordTracker(tracker){
  if(tracker!==null&&typeof tracker?.stream!=='function')throw new TypeError('A chord recognizer opens streams: {stream({sampleRate, windowSeconds})}');
  const previous=installed;installed=tracker;
  return ()=>{if(installed===tracker)installed=previous};
}
export const chordTracker=()=>installed;
