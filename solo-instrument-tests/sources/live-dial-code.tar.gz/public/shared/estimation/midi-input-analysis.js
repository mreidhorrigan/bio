import {frozenJson} from '../planning-data.js';

const freeze=value=>frozenJson(value,{bytes:2*1024*1024,items:262144}).data;
export const MIDI_ANALYSIS_LIMITS=Object.freeze({events:512,bytes:128*1024,batch:64,coalesceMs:4,replyMs:5000,startMs:15000});

// Exactly one bounded batch is in flight. No controller coalescing, note
// dropping, or unbounded Worker message queue. Losing any event invalidates
// this incarnation, since it might have been a note-off or pedal release.
export class MidiInputAnalysis {
  constructor({sourceOptions,codecBytes,harmonicVocabulary=null,now=()=>performance.now(),
    WorkerClass=globalThis.Worker,onFailure=()=>{},
    workerURL=globalThis.MUSEBOTS_INPUT_ASSET_URLS?.midiWorker||'shared/estimation/midi-analysis-worker.js',
    schedule=(fn,ms)=>setTimeout(fn,ms),cancel=timer=>clearTimeout(timer)}={}) {
    Object.assign(this,{now,mapping:sourceOptions.mapping,onFailure,schedule,cancel});
    this.queue=[];this.pendingBytes=0;this.sequence=0;this.completed=0;this.batches=0;
    this.highWaterEvents=0;this.highWaterBytes=0;this.processingMs=0;
    this.state='starting';this.cached=null;this.active=null;this.error=null;this.closed=false;
    this.worker=new WorkerClass(new URL(workerURL,globalThis.location?.href||'http://localhost/'),{type:'module'});
    this.worker.onmessage=event=>{if(!this.closed)this.receive(event.data);};
    this.worker.onerror=event=>this.fail(event.message||'MIDI analysis Worker failed');
    this.worker.onmessageerror=()=>this.fail('MIDI analysis reply could not be decoded');
    this.deadline=schedule(()=>this.fail('MIDI analysis did not start'),MIDI_ANALYSIS_LIMITS.startMs);
    try{this.worker.postMessage({type:'configure',options:{sourceOptions:{...sourceOptions,mapping:{...sourceOptions.mapping}},codecBytes,harmonicVocabulary}});}
    catch(error){this.close();throw error;}
  }
  pendingEvents(){return this.queue.length+(this.active?.events.length||0);}
  enqueue(bytes,timestamp,availableAt=this.now()) {
    if(this.closed)return false;
    try{
      if((!Array.isArray(bytes)&&!(bytes instanceof Uint8Array))||!bytes.length||bytes.length>1024||
        Array.from(bytes).some(byte=>!Number.isInteger(byte)||byte<0||byte>255))throw new TypeError('Invalid MIDI byte message');
      this.mapping.window({start:timestamp,availableAt});
      if(this.pendingEvents()>=MIDI_ANALYSIS_LIMITS.events||this.pendingBytes+bytes.length>MIDI_ANALYSIS_LIMITS.bytes)
        throw new Error('MIDI analysis input budget exceeded; start listening again for fresh note coverage');
      this.queue.push({sequence:++this.sequence,bytes:Array.from(bytes),timestamp,availableAt});this.pendingBytes+=bytes.length;
      this.highWaterEvents=Math.max(this.highWaterEvents,this.pendingEvents());this.highWaterBytes=Math.max(this.highWaterBytes,this.pendingBytes);
      this.scheduleBatch();return true;
    }catch(error){this.fail(error.message);return false;}
  }
  scheduleBatch() {
    if(this.closed||this.state!=='ready'||this.active||!this.queue.length)return;
    if(this.queue.length>=MIDI_ANALYSIS_LIMITS.batch){this.flush();return;}
    if(this.flushTimer===undefined)this.flushTimer=this.schedule(()=>{this.flushTimer=undefined;this.flush();},MIDI_ANALYSIS_LIMITS.coalesceMs);
  }
  flush() {
    if(this.closed||this.state!=='ready'||this.active||!this.queue.length)return;
    this.cancel(this.flushTimer);this.flushTimer=undefined;
    const events=this.queue.splice(0,MIDI_ANALYSIS_LIMITS.batch);
    this.active={events,dispatchedAt:this.now()};
    this.deadline=this.schedule(()=>this.fail('MIDI analysis reply timed out; start listening again'),MIDI_ANALYSIS_LIMITS.replyMs);
    try{this.worker.postMessage({type:'events',events});}catch(error){this.fail(error.message);}
  }
  receive(data) {
    if(this.closed)return;
    try{
      if(data.type==='invalid')throw new Error(data.error||'MIDI analysis failed');
      if(data.type==='ready'){
        if(this.state!=='starting')throw new Error('Unexpected MIDI analysis startup reply');
        this.cancel(this.deadline);this.state='ready';
      }else if(data.type==='result'){
        if(!this.active||data.sequence!==this.active.events.at(-1).sequence||!Number.isFinite(data.processingMs)||data.processingMs<0)
          throw new Error('MIDI analysis reply does not match its input batch');
        this.cancel(this.deadline);
        const availableAt=this.now(),first=this.active.events[0];
        this.lastDeliveryMs=availableAt-first.availableAt;this.lastRoundTripMs=availableAt-this.active.dispatchedAt;
        this.completed=data.sequence;this.batches++;this.processingMs+=data.processingMs;
        this.lastProcessingMs=data.processingMs;
        for(const event of this.active.events)this.pendingBytes-=event.bytes.length;
        this.active=null;
      }else throw new Error('Unknown MIDI analysis reply');
      this.availableAt=this.mapping.time(this.now());
      // Raw event availability remains its capture callback. The derived
      // state only becomes usable here, after the Worker reply is delivered.
      this.cached=freeze({...data.snapshot,harmonicMaterial:data.snapshot.harmonicMaterial?
        {...data.snapshot.harmonicMaterial,availableAt:this.availableAt}:null});
      this.scheduleBatch();
    }catch(error){this.fail(error.message);}
  }
  snapshot() {
    const pendingEvents=this.pendingEvents(),pending=this.active?.events[0]||this.queue[0];
    const coverage=this.error?'invalid':pendingEvents||this.state==='starting'?'partial':this.closed?'missing':'complete';
    const material=this.cached?.harmonicMaterial??null;
    return {...(this.cached||{source:null,forecast:null,rhythm:null,lastPackets:[],lastObservation:null,rejectedEvents:0,lastError:null}),
      harmonicMaterial:material&&coverage!=='complete'?{...material,coverage,notes:null}:material,
      harmony:coverage==='complete'?this.cached?.harmony??null:null,
      analysis:{mode:'worker',state:this.state,pendingEvents,pendingBytes:this.pendingBytes,
        pendingAgeSeconds:pending?Math.max(0,this.mapping.time(this.now())-this.mapping.time(pending.availableAt)):0,
        receivedEvents:this.sequence,completedEvents:this.completed,batches:this.batches,
        highWaterEvents:this.highWaterEvents,highWaterBytes:this.highWaterBytes,limits:MIDI_ANALYSIS_LIMITS,
        availableAt:this.availableAt??null,lastDeliveryMs:this.lastDeliveryMs??null,lastRoundTripMs:this.lastRoundTripMs??null,
        lastProcessingMs:this.lastProcessingMs??null,totalProcessingMs:this.processingMs,error:this.error}};
  }
  fail(reason) {
    if(this.closed)return;
    this.error=reason;this.close();this.state='invalid';this.onFailure(reason);
  }
  close() {
    if(this.closed)return;
    this.closed=true;this.state='closed';this.cancel(this.deadline);this.cancel(this.flushTimer);
    this.worker.terminate();this.queue=[];this.active=null;this.pendingBytes=0;
  }
}
