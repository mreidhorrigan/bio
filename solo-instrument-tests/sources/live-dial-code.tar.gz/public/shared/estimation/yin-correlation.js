// Optional large-window YIN kernel. Exact-real identity for fixed support W:
// d(t) = sum_{j<W} x[j]^2 + sum_{j<W} x[j+t]^2 - 2 sum_{j<W} x[j]x[j+t].
// The final correlation is linear convolution of reversed x[0:W] and x,
// at index W-1+t. Float64 transforms are approximate; no universal error bound
// or crossover claim is made. Very small differences use direct accumulation.
const plans=new Map;
function plan(size){
  if(plans.has(size))return plans.get(size);
  const bits=Math.log2(size),reverse=new Uint32Array(size),cos=new Float64Array(size/2),sin=new Float64Array(size/2);
  for(let i=0;i<size;i++){let v=i,r=0;for(let j=0;j<bits;j++){r=(r<<1)|(v&1);v>>>=1;}reverse[i]=r;}
  for(let i=0;i<size/2;i++){cos[i]=Math.cos(2*Math.PI*i/size);sin[i]=Math.sin(2*Math.PI*i/size);}
  const answer={size,reverse,cos,sin};if(plans.size>=4)plans.delete(plans.keys().next().value);plans.set(size,answer);return answer;
}
function fft(real,imag,p,inverse=false){
  const n=p.size;for(let i=0;i<n;i++){const j=p.reverse[i];if(i<j){[real[i],real[j]]=[real[j],real[i]];[imag[i],imag[j]]=[imag[j],imag[i]];}}
  for(let span=2;span<=n;span*=2){const half=span/2,step=n/span;for(let start=0;start<n;start+=span)for(let j=0;j<half;j++){
    const c=p.cos[j*step],s=(inverse?1:-1)*p.sin[j*step],a=start+j,b=a+half,r=c*real[b]-s*imag[b],im=s*real[b]+c*imag[b];
    real[b]=real[a]-r;imag[b]=imag[a]-im;real[a]+=r;imag[a]+=im;
  }}
  if(inverse)for(let i=0;i<n;i++){real[i]/=n;imag[i]/=n;}
}
export function yinFixedDifferences(samples,width,maxLag,{maxTransform=131072}={}){
  if(!samples||!Number.isSafeInteger(samples.length)||!Number.isSafeInteger(width)||width<1||!Number.isSafeInteger(maxLag)||maxLag<0||width+maxLag>samples.length||
    !Number.isSafeInteger(maxTransform)||maxTransform<2||maxTransform>262144)throw new RangeError('Invalid YIN correlation support/budget');
  let size=2;while(size<width+samples.length-1){size*=2;if(size>maxTransform)throw new RangeError('YIN transform budget exceeded');}
  if(Array.from(samples).some(x=>!Number.isFinite(x)))throw new TypeError('Finite YIN samples required');
  const p=plan(size),a=new Float64Array(size),ai=new Float64Array(size),b=new Float64Array(size),bi=new Float64Array(size),prefix=new Float64Array(samples.length+1);
  for(let i=0;i<samples.length;i++){b[i]=samples[i];prefix[i+1]=prefix[i]+samples[i]*samples[i];if(i<width)a[width-1-i]=samples[i];}
  if(!Number.isFinite(prefix.at(-1)))throw new RangeError('YIN sample energy overflow');
  fft(a,ai,p);fft(b,bi,p);for(let i=0;i<size;i++){const r=a[i]*b[i]-ai[i]*bi[i];ai[i]=a[i]*bi[i]+ai[i]*b[i];a[i]=r;}fft(a,ai,p,true);
  const differences=new Float64Array(maxLag+1);let directFallbacks=0;
  for(let lag=1;lag<=maxLag;lag++){
    const scale=prefix[width]+prefix[width+lag]-prefix[lag];let value=scale-2*a[width-1+lag];
    if(value<=1e-10*scale){value=0;for(let j=0;j<width;j++){const d=samples[j]-samples[j+lag];value+=d*d;}directFallbacks++;}
    if(!Number.isFinite(value))throw new RangeError('Nonfinite YIN transform result');differences[lag]=value;
  }
  return {differences,transformSize:size,directFallbacks,kind:'floating-point-approximation'};
}
