// A performer's harmony, remembered beat by beat as they play it, to anticipate their next chord. A chord heard only
// once it has sounded is heard late: the chroma model is sure of a new chord about 0.4 s after it starts, and a bot
// plays what it decided a lookahead earlier. A musician who has heard the form once plays its changes on time.
//
// Korzeniowski and Widmer (2018) improve chord recognition with a duration model and a harmonic language model. Here
// both come from the performer, online, with no corpus: the form they repeat. Each of the performer's beats (the
// listener's beat forecast) is labelled with the chord that led the model through most of it, `delaySeconds` after it
// sounded, which outvotes the flicker of a voicing that passes for another chord. The cycle is the number of beats
// over which those labels repeat best, over the last cycle or `windowBeats`, whichever is shorter, and it is trusted
// once they agree on `minAgreement` of those beats, among which the chord changed at least twice. With `rootOf` (a
// label's root, from its vocabulary: a pitch class in that vocabulary's tuning, so any tuning will do) labels agree
// when their roots do: the model hears a guitarist's E minor as E major one time in some voicings, and the form is the
// same. Only a change of root is then predicted. Labels are otherwise opaque: nothing here reads a chord's name. A change is predicted where the chord changed one
// cycle earlier, to a chord that held there for `minHoldBeats`. The memory predicts what the chord model will hear,
// right or wrong, only sooner.
export const HARMONIC_MEMORY_DEFAULTS=Object.freeze({delaySeconds:.35,minAgreement:.8,rootOf:null,minHoldBeats:1,minWindowBeats:8,
  windowBeats:32,minCycle:4,maxCycle:64,maxBeats:256});

export function createHarmonicMemory(options={}){
  const config=Object.freeze({...HARMONIC_MEMORY_DEFAULTS,...options});
  if(!(config.delaySeconds>=0&&config.minAgreement>0&&config.minAgreement<=1&&Number.isInteger(config.minWindowBeats)&&config.minWindowBeats>=2&&
    Number.isInteger(config.windowBeats)&&config.windowBeats>=config.minWindowBeats&&Number.isInteger(config.minCycle)&&config.minCycle>=2&&
    Number.isInteger(config.maxCycle)&&config.maxCycle>=config.minCycle&&Number.isInteger(config.maxBeats)&&config.maxBeats>=2*config.maxCycle+2&&
    (config.rootOf===null||typeof config.rootOf==='function')&&Number.isInteger(config.minHoldBeats)&&config.minHoldBeats>=1&&config.minHoldBeats<config.minCycle))
    throw new TypeError('Invalid harmonic memory');
  // beats: each beat's start (seconds) and the seconds each label led through it; labels: the label of each completed
  // beat (labels[i] is beats[i]'s); first: the index of beats[0] since the first beat heard; cycle: harmonicCycle().
  return {config,beats:[],labels:[],first:0,at:null,cycle:null};
}

const usable=beat=>Number.isFinite(beat?.expectedTime)&&beat?.periodSeconds>0;
// A completed beat's label: the one that led longest through it, or null where no chord led for half of it.
function labelOf(entry,length){
  let best=null,most=0;for(const [label,seconds] of Object.entries(entry.led))if(seconds>most){best=label;most=seconds}
  return most>=length/2?best:null;
}

// The cycle the labels repeat over: {cycle, agreement, window}, the best agreement over its window, or null.
export function harmonicCycle(labels,config){
  const n=labels.length,rootOf=config.rootOf,same=rootOf?(a,b)=>rootOf(a)===rootOf(b):(a,b)=>a===b;let best=null;
  for(let cycle=config.minCycle;cycle<=Math.min(config.maxCycle,n-config.minWindowBeats);cycle++){
    const window=Math.min(cycle,config.windowBeats,n-cycle);
    if(window<config.minWindowBeats)continue;
    let agree=0,counted=0,changes=0;
    for(let k=n-window;k<n;k++){
      if(labels[k]===null||labels[k-cycle]===null)continue;
      counted++;if(same(labels[k],labels[k-cycle]))agree++;
      if(k>n-window&&labels[k-1]!==null&&labels[k]!==labels[k-1])changes++;
    }
    if(counted<config.minWindowBeats||changes<2)continue;
    const agreement=agree/counted;
    if(!best||agreement>best.agreement+1e-9)best={cycle,agreement,window};
  }
  return best;
}

// The start of the performer's beat in progress at `at`, on the grid of the forecast `beat`, whose expectedTime can be
// any of its beats (the beam's forecast can lie a few beats ahead).
export const beatStart=(at,beat)=>beat.expectedTime+Math.floor((at-beat.expectedTime)/beat.periodSeconds+1e-9)*beat.periodSeconds;

// A frame of the chord model: `label`, the chord leading it at `at` (null when none is interpreted), with the
// performer's beat forecast `beat` ({expectedTime, periodSeconds}). Returns the memory with it.
export function observeHarmony(memory,{at,label=null,beat}){
  if(!Number.isFinite(at)||memory.at!==null&&at<memory.at)throw new TypeError('Harmony must be observed in order');
  if(!usable(beat))return {...memory,at};
  const {config}=memory,beats=[...memory.beats];
  // The beat in progress is added once it has begun.
  const passed=beatStart(at,beat),last=beats.at(-1);
  if(!last)beats.push({start:passed,led:{}});
  else if(passed>last.start+beat.periodSeconds/2){
    const count=Math.max(1,Math.round((passed-last.start)/beat.periodSeconds));
    for(let k=1;k<=count;k++)beats.push({start:last.start+k*(passed-last.start)/count,led:{}});
  }
  // The label leads from the last frame to this one, as heard delaySeconds earlier.
  if(label!==null&&memory.at!==null){
    const from=memory.at-config.delaySeconds,to=at-config.delaySeconds;
    for(let i=beats.length-1;i>=0;i--){
      if(beats[i].start>=to)continue;
      const end=i+1<beats.length?beats[i+1].start:Infinity,overlap=Math.min(to,end)-Math.max(from,beats[i].start);
      if(overlap>0)beats[i]={...beats[i],led:{...beats[i].led,[label]:(beats[i].led[label]??0)+overlap}};
      if(from>=beats[i].start)break;
    }
  }
  // Beats heard to the end are labelled, and the cycle is found again.
  let labels=memory.labels,cycle=memory.cycle,first=memory.first;
  if(labels.length+1<beats.length&&beats[labels.length+1].start+config.delaySeconds<=at){
    labels=[...labels];
    for(let i=labels.length;i+1<beats.length&&beats[i+1].start+config.delaySeconds<=at;i++)labels.push(labelOf(beats[i],beats[i+1].start-beats[i].start));
    cycle=harmonicCycle(labels,config);
  }
  if(beats.length>config.maxBeats){const drop=beats.length-config.maxBeats;beats.splice(0,drop);labels=labels.slice(drop);first+=drop}
  return {...memory,beats,labels,first,at,cycle};
}

// The next change, where the chord changed one cycle ago: {label, from, changeAt, cycle, agreement, beat} (beat: the
// index of the beat it starts), or null. `beat` is the performer's current beat forecast.
export function predictChange(memory,{beat}){
  const found=memory.cycle;
  if(!usable(beat)||!found||found.agreement<memory.config.minAgreement)return null;
  const {labels,beats,first}=memory,{cycle}=found;
  // The beat after the one in progress, which starts a period after it.
  const next=first+beats.length,at=next-cycle-first,label=labels[at],previous=labels[at-1];
  const rootOf=memory.config.rootOf;
  if(label==null||previous==null||label===previous||rootOf&&rootOf(label)===rootOf(previous))return null;
  for(let k=1;k<memory.config.minHoldBeats;k++)if(labels[at+k]!==label)return null;
  return {label,from:previous,changeAt:beatStart(memory.at,beat)+beat.periodSeconds,cycle,agreement:found.agreement,beat:next};
}

// A time's position on the performer's beats, as the memory counts them (beat index since the first heard, and the
// fraction of its beat): where a change heard at a time fell, for the harmonic rhythm (harmonic-rhythm.js). `beat` is
// the performer's forecast, for a time after the last beat begun. Null before the first beat.
export function beatPosition(memory,time,beat){
  const {beats,first}=memory;
  if(!beats.length||!Number.isFinite(time))return null;
  for(let i=beats.length-1;i>=0;i--){
    if(beats[i].start>time&&i>0)continue;
    const end=i+1<beats.length?beats[i+1].start:beats[i].start+(usable(beat)?beat.periodSeconds:1);
    return first+i+(time-beats[i].start)/(end-beats[i].start);
  }
  return null;
}
