// The harmonic rhythm as a switching Kalman filter: which of the performer's beats their chords change on, and so,
// where their chords change on the bar line, where their bars begin.
//
// Each regime is a harmonic period of P beats (2, 3, 4, 6 or 8: a bar or half of one in several meters), with a
// Kalman filter of the phase of its changes, in beats. The regimes switch, as a meter or a harmonic rhythm changes,
// with probability 1 - `stay` at each change heard (Murphy 1998, switching Kalman filters, plan R04). A change the chord
// model hears is either on a regime's grid or clutter, a passing voicing taken for another chord. Probabilistic data
// association weighs the two (Shiu et al. 2008 track beats so, plan R03). The changes heard are a Poisson process: a
// grid point carries a change with probability `pDetect`, heard `measurementBeats` either side of it as the filter's
// uncertainty allows, and clutter arrives at `clutterPerBeat` anywhere. Between changes, each regime pays for the
// changes it expected and did not hear (pDetect for every grid point passed), which is what tells four beats from two
// when every change falls on a bar line, whatever clutter lands on the half bar. The phase diffuses by
// `processBeats2PerBeat` between changes, so a regime that has had no change on its grid for a while takes the next
// one almost at face value. A regime the filter gives less than `forgetBelow` of its weight forgets its phase (it
// tracks nothing), so after a change of meter the new regime's phase is found within a change or two. `prior` weighs
// the periods before anything is heard, and is where a switch goes: a chord a bar, in simple or compound time, before
// one every half bar or every two bars.
// Silence (the mathematical audit's E12, declared here): the changes a regime expected and did not hear are counted over
// at most `silenceBeats` of a gap; a longer gap is silence, not a run of missed changes, and the phases' uncertainty has
// grown to a uniform phase by then, so the rhythm is found again from what follows. The survival term is the
// constant-rate Poisson one (pDetect per grid point passed, as a rate), not a Bernoulli trial at each grid position:
// the two are different models, and this is the one chosen. The weights are normalized in logs: after a legal gap of
// ten thousand beats, exp(-expected) had made every weight zero.
export const HARMONIC_RHYTHM_DEFAULTS=Object.freeze({periods:[2,3,4,6,8],prior:[.1,.2,.35,.15,.2],stay:.9,pDetect:.7,
  clutterPerBeat:.1,measurementBeats:.35,processBeats2PerBeat:.003,forgetBelow:.02,silenceBeats:32});

const TAU=2*Math.PI,wrap=(value,period)=>{const x=((value%period)+period)%period;return x>period/2?x-period:x};

export function createHarmonicRhythm(options={}){
  const config=Object.freeze({...HARMONIC_RHYTHM_DEFAULTS,...options});
  if(!(config.periods.length>=1&&config.periods.every(p=>Number.isInteger(p)&&p>=2)&&config.prior.length===config.periods.length&&
    config.prior.every(w=>w>0)&&config.stay>0&&config.stay<=1&&config.pDetect>0&&config.pDetect<1&&config.clutterPerBeat>0&&
    config.measurementBeats>0&&config.processBeats2PerBeat>=0&&config.forgetBelow>=0&&config.forgetBelow<1&&
    Number.isFinite(config.silenceBeats)&&config.silenceBeats>0))throw new TypeError('Invalid harmonic rhythm');
  const total=config.prior.reduce((a,b)=>a+b,0);
  return {config,regimes:config.periods.map(period=>({period,phase:null,variance:period*period/12})),weights:config.prior.map(w=>w/total),at:null,changes:0};
}

// A phase's density on its circle of `period` beats: the Gaussian's images round the circle summed (a wrapped
// Gaussian), so it integrates to one over the period however broad the uncertainty. The nearest image alone lost the
// tails: a ninth of the mass for a phase as unsure as a uniform one.
function wrappedGauss(innovation,S,period){
  const images=Math.ceil(6*Math.sqrt(S)/period);let density=0;
  for(let k=-images;k<=images;k++){const x=innovation+k*period;density+=Math.exp(-x*x/(2*S))}
  return density/Math.sqrt(TAU*S);
}

// How a change heard at beat position `beat` (in beats, continuous) fits each regime, without learning from it:
// {onGrid, weights, fits: [{period, onGrid, innovation}]} (onGrid: the probability it lies on the harmonic rhythm's grid).
export function assessChange(rhythm,beat){
  const {config}=rhythm,R=config.measurementBeats**2,n=rhythm.regimes.length;
  const fits=rhythm.regimes.map((regime,i)=>{
    const {period}=regime;
    // The changes this regime expected since the last one heard: pDetect for every grid point passed, over at most
    // silenceBeats (a longer gap is silence).
    const elapsed=rhythm.at===null?0:Math.max(0,beat-rhythm.at),expected=config.pDetect*Math.min(elapsed,config.silenceBeats)/period;
    if(regime.phase===null)return {period,likelihood:config.pDetect/period+config.clutterPerBeat,expected,onGrid:.5,innovation:0,variance:regime.variance};
    const variance=Math.min(period*period/12,regime.variance+config.processBeats2PerBeat*elapsed);
    const innovation=wrap(beat-regime.phase,period),S=variance+R,gauss=wrappedGauss(innovation,S,period);
    const onGridDensity=config.pDetect*gauss,likelihood=onGridDensity+config.clutterPerBeat;
    return {period,likelihood,expected,onGrid:onGridDensity/likelihood,innovation,variance,S,index:i};
  });
  // A switch goes where the prior says, from wherever the weight is. Normalized in logs (log-sum-exp).
  const priorTotal=config.prior.reduce((a,b)=>a+b,0),prior=rhythm.weights.map((w,i)=>config.stay*w+(1-config.stay)*config.prior[i]/priorTotal);
  const logs=fits.map((fit,i)=>Math.log(prior[i])+Math.log(fit.likelihood)-fit.expected),top=Math.max(...logs);
  const raw=logs.map(log=>Number.isFinite(top)?Math.exp(log-top):1),total=raw.reduce((a,b)=>a+b,0);
  const weights=raw.map(value=>value/total);
  return {onGrid:fits.reduce((sum,fit,i)=>sum+weights[i]*fit.onGrid,0),weights,fits};
}

// Learns from a change heard at beat position `beat`: the regimes' weights, and each phase by its probability of
// having produced it. Returns {rhythm, onGrid}.
export function observeChange(rhythm,beat){
  if(!Number.isFinite(beat)||rhythm.at!==null&&beat<rhythm.at)throw new TypeError('Harmonic changes must be observed in order, in beats');
  const {config}=rhythm,R=config.measurementBeats**2,assessed=assessChange(rhythm,beat);
  const regimes=rhythm.regimes.map((regime,i)=>{
    const fit=assessed.fits[i],{period}=regime;
    if(regime.phase===null)return {period,phase:((beat%period)+period)%period,variance:R};
    // PDA: the update weighted by the probability the change is on this grid, with the spread that uncertainty adds.
    const w=fit.onGrid,K=fit.variance/fit.S,shift=w*K*fit.innovation;
    const variance=assessed.weights[i]<config.forgetBelow?period*period/12:Math.max(1e-6,fit.variance-w*K*fit.variance+w*(1-w)*(K*fit.innovation)**2);
    return {period,phase:((regime.phase+shift)%period+period)%period,variance};
  });
  return {rhythm:{...rhythm,regimes,weights:assessed.weights,at:beat,changes:rhythm.changes+1},onGrid:assessed.onGrid};
}

// The most probable regime: {period, phase, weight}, or null before any change.
export function likeliestRegime(rhythm){
  let best=0;for(let i=1;i<rhythm.weights.length;i++)if(rhythm.weights[i]>rhythm.weights[best])best=i;
  const regime=rhythm.regimes[best];
  return regime.phase===null?null:{period:regime.period,phase:regime.phase,weight:rhythm.weights[best]};
}
