import {HARMONY_LISTENING_NAMES} from './harmony-listenings.js';
import {HARMONY_ORIENTATIONS} from './harmony-orientation.js';
export const HARMONY_ORIENTATION_NAMES=Object.freeze(Object.keys(HARMONY_ORIENTATIONS));
// The orientation a listener to lines takes where none is named (pre-registration Question 9).
export const LINES_ORIENTATION='chord-scale-v1';
// How a listener hears audio, where a host may choose: the options a render's follow.listening and a capture's
// start() pass to the frame analysis (audio-frame-analysis.js). Only development comparisons choose; everything else
// hears with the defaults.
//
// onsetDetector: 'rms-attack', an onset when a frame's energy jumps (the default), or 'spectral-flux', one when the
// spectrum gains new energy (spectral-flux.js). The rhythm beam hears these onsets.
// attackDetector (in development): the detector whose attacks a listener passes on to a conductor, which places
// them on its own beats to count how the performer divides the beat (tempo-influence.js); the onset detector's when
// left out. Spectral flux hears most strums, while the beam keeps the onsets it was validated with. On GuitarSet the
// conductor then read threes and twos more often correctly in every case measured, told the meter or not; a band
// finding its beat in them did worse than one taking the listener's (research/kalman-integration.md, "Told the
// meter").
export const ONSET_DETECTORS=Object.freeze(['rms-attack','spectral-flux']);
// rhythm: how the beat is heard, by name. 'beat-this-v2' hears it with a learned tracker (learned-pulse.js), where the
// host has one (beat-trackers.js: a render on the desktop, or a desktop page with the VST3 bridge), and is the default
// there (pre-registration Amendments 14-18); 'beat-this-v1' is the same without letting go of a level that no longer
// passes for one (learned-pulse.js releaseLapsed); 'beat-this-v3' (in development) is v2 abstaining while its grid
// scores under 0.92 (the free-timing gate, trackingScore), and 'beat-this-v4' (in development) the same under 0.96.
// 'bass-accent-v1', the beam (audio-frame-analysis.js
// RHYTHM_LISTENINGS), is the default elsewhere; 'metrical-persistence-v1' adds metrical persistence to it (in
// development, research/kalman-integration.md).
export const RHYTHM_LISTENING_NAMES=Object.freeze(['bass-accent-v1','metrical-persistence-v1','beat-this-v1','beat-this-v2','beat-this-v3','beat-this-v4']);
// harmony (in development): how chords are heard, by name (harmony-listenings.js): its chroma and its chord model. The
// default is 'chroma-templates-v1'; 'chroma-no-chord-v1' hears noise as no chord.
// orientation (in development): how the band orients to the harmony heard, level by level: a listener's tendency, by
// name (harmony-orientation.js HARMONY_ORIENTATIONS). Without one, the band follows the chords alone.
// harmonyInput: what the performer plays, 'chords' (the default) or 'lines' (a soloist, whose line a chord model can
// only guess at: the band orients to the scale alone, with LINES_ORIENTATION unless an orientation is named), or 'auto'
// (in development), heard as they play (harmony-follower.js followChords 'auto'), which needs an orientation named.
// Pre-registration Question 9 (Amendments 19 and 20): on 431 held-out jazz solos, a band oriented to the scale clashed
// with the soloist's chords 18.9% of the time against 21.7% following a chord model's guesses (lower on 274, higher on
// 75), playing as much.
const KEYS=['onsetDetector','attackDetector','rhythm','harmony','orientation','harmonyInput'];

// A listening's options, checked; throws a TypeError naming what is wrong.
export function listeningOptions(value){
  if(value===null||typeof value!=='object'||Array.isArray(value))throw new TypeError('A listening is an object of options');
  const unknown=Object.keys(value).filter(key=>!KEYS.includes(key));
  if(unknown.length)throw new TypeError(`Unknown listening option ${unknown.join(', ')}: known are ${KEYS.join(', ')}`);
  for(const key of ['onsetDetector','attackDetector'])if(value[key]!==undefined&&!ONSET_DETECTORS.includes(value[key]))throw new TypeError(`An onset detector is one of ${ONSET_DETECTORS.join(', ')}`);
  if(value.rhythm!==undefined&&!RHYTHM_LISTENING_NAMES.includes(value.rhythm))throw new TypeError(`A rhythm listening is one of ${RHYTHM_LISTENING_NAMES.join(', ')}`);
  if(value.harmony!==undefined&&!HARMONY_LISTENING_NAMES.includes(value.harmony))throw new TypeError(`A harmony listening is one of ${HARMONY_LISTENING_NAMES.join(', ')}`);
  if(value.orientation!==undefined&&!HARMONY_ORIENTATION_NAMES.includes(value.orientation))throw new TypeError(`A harmony orientation is one of ${HARMONY_ORIENTATION_NAMES.join(', ')}`);
  if(value.harmonyInput!==undefined&&!['chords','lines','auto'].includes(value.harmonyInput))throw new TypeError('A harmony input is chords, lines or auto');
  if(value.harmonyInput==='auto'&&value.orientation===undefined)throw new TypeError('A listener telling lines from chords orients to their scale: name an orientation');
  return Object.freeze({...value});
}
