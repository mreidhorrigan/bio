// ae_AudioAnalyzerBOT's descriptors as a bot reads them: their names and meanings, the messages that carry them, and a
// reader that takes a descriptor by its name whatever message carries it (audio-descriptors.js computes them; the
// framework's Agent reads them, agent.js descriptor()). Kept apart from the analysis, so every bot can read them
// without carrying the signal processing.
export const AUDIO_DESCRIPTORS_VERSION='ae-audio-analyzer-1';
// Where an analyzer says what it sends, and as what: a broadcast, so the room keeps its latest for a bot that joins
// later (server.js rememberProtocol). And where it is asked to send one as another.
export const DESCRIPTORS_ADDRESS='/broadcast/descriptors';
export const ROUTE_ADDRESS='/agent/audio/route';
// The five the patch sends, in its order, and the names its menus offer.
export const DESCRIPTOR_NAMES=Object.freeze(['centroid','loudness','activity','flux','speed']);
export const DESCRIPTOR_MESSAGES=Object.freeze(['centroid','loudness','activity','flux','speed','arousal','valence']);
export const DEFAULT_ROUTING=Object.freeze({centroid:'centroid',loudness:'loudness',activity:'arousal',flux:'valence',speed:'activity'});
// What a bot reads: each descriptor's meaning and range, and how often it comes.
export const AUDIO_DESCRIPTORS=Object.freeze({
  centroid:Object.freeze({range:Object.freeze([0,1]),everySeconds:.25,
    meaning:'where the spectrum\'s weight lies, its centroid, placed in its own recent range: 0 the darkest it has been, 1 the brightest'}),
  loudness:Object.freeze({range:Object.freeze([0,1]),everySeconds:.25,
    meaning:'the peak level in decibels, placed in its own recent range: 0 the quietest it has been, 1 the loudest'}),
  activity:Object.freeze({range:Object.freeze([0,1]),everySeconds:.25,
    meaning:'the share of the last 2 s the sound was active: louder than its mean of the last 5 s, and not yet fallen silent'}),
  flux:Object.freeze({range:Object.freeze([0,1]),everySeconds:.25,
    meaning:'how much the spectrum changes from one moment to the next: 0 a steady sound, 1 a new one each time'}),
  speed:Object.freeze({range:Object.freeze([0,1]),everySeconds:.25,
    meaning:'how close together its attacks come: 1 less their mean spacing in seconds (0 at a second or more apart)'}),
  bark:Object.freeze({range:Object.freeze([0,1]),length:25,everySeconds:1,message:'barkenergy',
    meaning:'the energy in each of 25 critical (Bark) bands over the last second, low to high: 1 the loudest band, 0 at 60 dB under it'}),
});
// A routing: each of the five sent under one of the menus' names, the patch's defaults for any not given, no name
// carrying two (the patch would allow it, and a reader could not tell them apart).
export function analyzerRouting(value={}){
  if(value==null)value={};
  if(typeof value!=='object'||Array.isArray(value))throw new TypeError('A routing names a message for each descriptor');
  for(const key of Object.keys(value))if(!DESCRIPTOR_NAMES.includes(key))throw new RangeError(`No descriptor ${key}: ${DESCRIPTOR_NAMES.join(', ')}`);
  const routing={...DEFAULT_ROUTING,...value};
  for(const [name,message] of Object.entries(routing))if(!DESCRIPTOR_MESSAGES.includes(message))
    throw new RangeError(`${name} goes out as one of ${DESCRIPTOR_MESSAGES.join(', ')}, not ${message}`);
  const names=Object.values(routing);
  if(new Set(names).size!==names.length)throw new RangeError('Each message carries one descriptor');
  return Object.freeze(routing);
}
// What an analyzer publishes at DESCRIPTORS_ADDRESS: the descriptors, each with the message it goes out as.
export function descriptorSchema(routing=DEFAULT_ROUTING){
  const routes=analyzerRouting(routing);
  return {version:AUDIO_DESCRIPTORS_VERSION,
    descriptors:Object.fromEntries(Object.entries(AUDIO_DESCRIPTORS).map(([name,record])=>[name,{...record,message:record.message??routes[name]}])),
    statechange:{message:'statechange',value:'any',meaning:'the sound has stopped: its activity fell to none'}};
}

// A bot reads a descriptor by its name, whatever it goes out as: from an analyzer's schema, the message that carries it,
// then that message's value, from that analyzer (the sender the room names) and no other. Before a schema, nothing:
// valence, say, is also ValenceArousalBot's, and would be misread as a flux. With two analyzers, the latest to say.
export class DescriptorReader {
  constructor(){this.routes=null;this.source=null;this.values={};}
  hear(message){
    const address=message?.address??'';
    if(address===DESCRIPTORS_ADDRESS){
      const descriptors=message.args?.[0]?.descriptors;
      if(!descriptors||typeof descriptors!=='object')return null;
      this.routes=new Map(Object.entries(descriptors).map(([name,record])=>[record?.message,name]).filter(([key])=>typeof key==='string'));
      this.source=message.source??null;this.values={};
      return null;
    }
    if(!this.routes||!address.startsWith('/broadcast/'))return null;
    if(this.source!==null&&message.source!=null&&message.source!==this.source)return null;
    const name=this.routes.get(address.slice('/broadcast/'.length));
    if(!name)return null;
    const args=(message.args??[]).map(Number).filter(Number.isFinite);
    if(!args.length)return null;
    this.values[name]=name==='bark'?args:args.at(-1);
    return name;
  }
  value(name){return this.values[name]??null}
}
