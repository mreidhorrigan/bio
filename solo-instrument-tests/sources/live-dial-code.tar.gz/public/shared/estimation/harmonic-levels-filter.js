// The levels of a performer's harmony, heard over time (harmonic-levels.js holds the vocabularies). Each layer of a
// levels vocabulary is a hidden state, filtered forward as a chord is, but on its own time scale: a collection changes
// when the music modulates, a pentatonic within it more often, a chord at every change of harmony. What is heard is a
// bag of pitch classes (a chroma frame, MIDI notes, or the pitch classes of the chords a chord model holds), each
// weighted, in the vocabulary's own tuning.
//
// For each layer:
// - it persists, making no move within a second with probability `stayPerSecond`, and otherwise moves to sets a few
//   notes away (the probability falling by `moveDecay` for each note that differs), as a modulation moves to a near
//   key. This is a continuous-time process (persist() below), so ten one-second frames and one ten-second frame move
//   the beliefs alike, and a minute's gap is a minute (the mathematical audit's E02 and E04);
// - a set is believed by how well the pitch classes heard fall inside it: each heard with probability (1 - outside)
//   spread over the set's members, and `outside` over the rest of the grid. A larger set spreads its probability
//   thinner, so a pentatonic is believed over a diatonic collection only where the other two notes stay silent, and an
//   eight-note scale only where its added note keeps sounding. Evidence counts by the seconds it covers
//   (`evidencePerSecond`), once, so the frame rate does not change how sure the filter becomes: a frame covers the time
//   since the last one (at most `maxEvidenceSeconds`, since a long gap is not sound held through it) unless it says
//   how long it covers (observeLevels' `covers`), a frame at the same moment as the last covers none, and the first
//   covers `initialEvidenceSeconds` unless it says;
// - a layer below is held by the layer above: where a set moves, it moves toward sets held by the likely sets above
//   (as a prior acts, through the moves, not frame by frame as evidence would).
//
// The centre of the likeliest collection (its mode) is read from the pitch classes heard over `centerMemorySeconds`,
// weighed by a profile over the mode's degrees: its own triad most (the centre, then the degree a fifth above, then
// the one a third above), the other scale degrees less, notes outside the collection least, in about the proportions of
// the Krumhansl-Kessler profiles (tonic 6.3, fifth 5.2, third 4.4-5.4, other scale degrees 2.9-4.1, chromatic
// 2.2-2.5). The triad is what tells a minor key from its relative major, which share a collection. Each mode's prior
// (its family's modePriors) weighs it too. Chord roots count twice (chordEvidence), since the centre is where chords
// are rooted and resolve. A tendency, reported with its probability.
import {levelsLayer,layerMembership,pitchClassDistance} from './harmonic-levels.js';

// noScaleRestart (opt-in, off by default): where music in no scale is believed (the chromatic set above one half) and
// the evidence of the last seconds (`recentSeconds`, an exponentially fading sum of each frame's log likelihood) favours
// some scale over no scale by `restartMargin`, the layer starts again: from its prior with that recent evidence, as it
// would stand had it heard the new music from silence. Without it, after long noise heard as notes (random notes: music
// in no scale) a key takes about twelve seconds to be heard, against five from silence: the belief in no scale has
// grown so sure that the key's evidence takes that long to overturn it. Random notes kept the margin below -0.4 over
// ten seeds; music crossed 0.4 within about two seconds.
export const LEVELS_FILTER_DEFAULTS=Object.freeze({stayPerSecond:.98,moveDecay:1.5,outside:.1,evidencePerSecond:1.2,
  initialEvidenceSeconds:.02,maxEvidenceSeconds:2,
  noScaleRestart:false,recentSeconds:1.5,restartMargin:.4,
  layers:Object.freeze({}),certainty:.9,centerMemorySeconds:12,centerProfile:Object.freeze({center:1,fifth:.82,third:.75,other:.55,outside:.37}),centerSharpness:40,
  maximumReported:4});

export function createLevelsFilter(vocabulary,options={}){
  const config={...LEVELS_FILTER_DEFAULTS,...options,centerProfile:{...LEVELS_FILTER_DEFAULTS.centerProfile,...options.centerProfile}};
  if(!(config.stayPerSecond>0&&config.stayPerSecond<1&&config.moveDecay>0&&config.outside>0&&config.outside<1&&config.evidencePerSecond>0&&
    config.certainty>.5&&config.certainty<=1&&config.centerMemorySeconds>0&&
    Number.isFinite(config.initialEvidenceSeconds)&&config.initialEvidenceSeconds>=0&&Number.isFinite(config.maxEvidenceSeconds)&&config.maxEvidenceSeconds>0))
    throw new TypeError('Invalid levels filter');
  const {periodSemitones:period,toleranceSemitones:tolerance}=vocabulary;
  // Per layer: its sets' priors, how each set's members cover the grid, and the moves between sets.
  const layers=vocabulary.layers.map(layer=>{
    const own={...config,...config.layers[layer.id]};
    const covers=layer.sets.map(set=>vocabulary.grid.map(pc=>set.pitchClasses.some(member=>pitchClassDistance(pc,member,period)<=tolerance)));
    const differ=(a,b)=>covers[a].reduce((count,held,k)=>count+(held!==covers[b][k]?1:0),0)/2;
    const moves=layer.sets.map((_,i)=>{const row=layer.sets.map((_,j)=>i===j?0:Math.exp(-own.moveDecay*differ(i,j)));
      const total=row.reduce((a,b)=>a+b,0)||1;return row.map(value=>value/total);});
    return {id:layer.id,own,covers,moves,prior:layer.sets.map(set=>set.prior)};
  });
  return {modelId:'harmonic-levels-v1',vocabularyId:vocabulary.vocabularyId,config,layers,at:null,revision:0,
    beliefs:layers.map(layer=>[...layer.prior]),recent:layers.map(layer=>layer.prior.map(()=>0)),restarts:0,profile:null,heardSeconds:0};
}

// A layer's persistence over `seconds`: no move within a second with probability `stay` (a rate of -ln stay), each
// move by the row `moves` of the set it leaves, as exp(rate t (moves - I)) applied to the belief. Computed by
// uniformization, the sum over k of Poisson(k; rate t) belief moves^k, in pieces of rate t at most 16 so that nothing
// underflows, to within 1e-12 of its mass. The old stay^t belief + (1 - stay^t) moved(belief) does not compose, since
// moving twice is not moving once; this does, so a gap is as long as it is.
function persist(belief,moves,stay,seconds){
  let remaining=-Math.log(stay)*seconds,current=belief;
  while(remaining>0){
    const piece=Math.min(remaining,16),n=current.length;remaining-=piece;
    let term=current,weight=Math.exp(-piece),mass=weight;const out=term.map(value=>value*weight);
    for(let k=1;1-mass>1e-12&&k<256;k++){
      const next=new Array(n).fill(0);
      for(let i=0;i<n;i++){const from=term[i];if(!from)continue;const row=moves[i];for(let j=0;j<n;j++)next[j]+=from*row[j]}
      term=next;weight*=piece/k;mass+=weight;
      for(let j=0;j<n;j++)out[j]+=weight*term[j];
    }
    const total=out.reduce((a,b)=>a+b,0)||1;current=out.map(value=>value/total);
  }
  return current;
}

// A frame of evidence: `pitches`, [{pc, weight}] in the vocabulary's period (weights of any scale; they are made to
// sum to one), heard at `at`, covering `covers` seconds of sound when the caller knows (see above). An empty frame
// (silence) moves the beliefs on in time, and adds nothing.
export function observeLevels(state,vocabulary,pitches,{at,covers}={}){
  if(!Number.isFinite(at)||state.at!==null&&at<state.at)throw new TypeError('Levels evidence must arrive in order');
  if(covers!==undefined&&!(Number.isFinite(covers)&&covers>=0))throw new TypeError('A frame covers a finite, non-negative time');
  const {config}=state,{periodSemitones:period,toleranceSemitones:tolerance}=vocabulary,grid=vocabulary.grid;
  // Two times: how long the beliefs move on, and how much sound this frame's evidence stands for. The old
  // max(dt, .02) counted a hundred frames at one moment as two seconds of sound (a belief of .26 went to .70), and
  // min(2, elapsed) made a minute's gap two seconds of persistence.
  const dt=state.at===null?0:at-state.at,
    heardFor=covers!==undefined?covers:state.at===null?config.initialEvidenceSeconds:Math.min(dt,config.maxEvidenceSeconds);
  // The evidence on the grid: each pitch to the grid pitch class it matches.
  const heard=new Float64Array(grid.length);let total=0;
  for(const {pc,weight} of pitches??[]){
    if(!(weight>0)||!Number.isFinite(pc))continue;
    let best=-1,near=Infinity;for(let k=0;k<grid.length;k++){const d=pitchClassDistance(pc,grid[k],period);if(d<near){near=d;best=k}}
    if(best>=0&&near<=Math.max(tolerance,.5))heard[best]+=weight,total+=weight;
  }
  if(total>0)for(let k=0;k<grid.length;k++)heard[k]/=total;
  let restarts=state.restarts??0;
  const recents=[];
  const beliefs=state.layers.map((layer,index)=>{
    const own=layer.own,n=state.beliefs[index].length;
    // The evidence of the last seconds, per set: each frame's log likelihood, fading over recentSeconds.
    const frameLogs=total>0?layer.covers.map(covers=>{const members=covers.reduce((count,held)=>count+(held?1:0),0),outsideShare=own.outside/Math.max(1,grid.length);
      let log=0;for(let k=0;k<grid.length;k++)if(heard[k]>0)log+=heard[k]*Math.log((covers[k]?(1-own.outside)/members:0)+outsideShare);return log}):null;
    const fade=Math.exp(-dt/own.recentSeconds),recent=(state.recent?.[index]??Array(n).fill(0)).map((value,j)=>fade*value+(frameLogs?own.evidencePerSecond*heardFor*frameLogs[j]:0));
    recents.push(recent);
    let previous=state.beliefs[index];
    const noScale=vocabulary.layers[index].sets.findIndex(set=>set.chromatic);
    if(own.noScaleRestart&&noScale>=0&&previous[noScale]>.5&&frameLogs){
      const best=Math.max(...recent.filter((_,j)=>j!==noScale));
      if(best-recent[noScale]>=own.restartMargin){
        const top=Math.max(...recent),restarted=layer.prior.map((p,j)=>p*Math.exp(recent[j]-top)),sum=restarted.reduce((a,b)=>a+b,0)||1;
        previous=restarted.map(p=>p/sum);restarts++;
      }
    }
    // Persistence, and moves: toward sets held by the likely sets of the layer above, as that layer stood when the
    // interval began (the rule that makes a layer's moves, which depend on the layer above, a process in time: the
    // layer above is held for the interval). Each set's moves are weighed by what the layer above holds and made a
    // distribution again, so a move is a move; a set with nowhere to move stays.
    let held=null;
    if(index>0){const above=vocabulary.layers[index-1],parentBelief=new Map(above.sets.map((set,i)=>[set.id,state.beliefs[index-1][i]]));
      held=vocabulary.layers[index].sets.map(set=>.05+set.parents.reduce((sum,id)=>sum+(parentBelief.get(id)??0),0));}
    const moves=layer.moves.map((row,i)=>{const weighed=held?row.map((value,j)=>value*held[j]):row,rowTotal=weighed.reduce((a,b)=>a+b,0);
      return rowTotal>0?weighed.map(value=>value/rowTotal):row.map((_,j)=>j===i?1:0)});
    let belief=persist(previous,moves,own.stayPerSecond,dt);
    // The evidence, over the seconds it covers.
    if(total>0&&heardFor>0){
      const weightOfFrame=own.evidencePerSecond*heardFor;
      const logs=belief.map((p,j)=>Math.log(Math.max(p,1e-300))+weightOfFrame*frameLogs[j]);
      const top=Math.max(...logs);belief=logs.map(log=>Math.exp(log-top));
    }
    // Floored, so no set is ever ruled out for good, and then made a distribution again (flooring after normalizing
    // let the beliefs sum past one).
    const sum=belief.reduce((a,b)=>a+b,0)||1,floored=belief.map(p=>Math.max(p/sum,1e-12)),flooredSum=floored.reduce((a,b)=>a+b,0);
    return floored.map(p=>p/flooredSum);
  });
  // The pitch classes heard over the centre's memory, which is a memory of the sound heard, in the seconds it covers.
  const keep=state.profile?Math.exp(-heardFor/config.centerMemorySeconds):0;
  const profile=total>0?grid.map((_,k)=>keep*(state.profile?.[k]??0)+(1-keep)*heard[k]):state.profile;
  return {...state,at,revision:state.revision+1,beliefs,recent:recents,restarts,profile,heardSeconds:state.heardSeconds+(total>0?heardFor:0)};
}

// What the levels are heard as: for each layer its likeliest sets, the pitch classes certain at it (each held, with
// probability `certainty` or more, by the set sounding), and the centre of the likeliest top-layer set.
export function levelsReport(state,vocabulary){
  const {config}=state,{periodSemitones:period}=vocabulary;
  const layers=vocabulary.layers.map((layer,index)=>{
    const belief=state.beliefs[index],byId=Object.fromEntries(layer.sets.map((set,i)=>[set.id,belief[i]]));
    const ranked=layer.sets.map((set,i)=>({id:set.id,family:set.family,root:set.root,pitchClasses:set.pitchClasses,probability:belief[i]}))
      .sort((a,b)=>b.probability-a.probability);
    const {certain}=layerMembership(vocabulary,layer.id,byId,{threshold:config.certainty});
    return {id:layer.id,top:ranked.slice(0,config.maximumReported),certain,beliefs:byId};
  });
  // The centre: of the likeliest top-layer set's modes, the one whose profile best matches what was heard.
  let center=null;
  const top=vocabulary.layers[0].sets.find(set=>set.id===layers[0].top[0].id);
  if(state.profile&&top){
    const grid=vocabulary.grid,profile=config.centerProfile,tolerance=vocabulary.toleranceSemitones,members=top.pitchClasses,n=members.length;
    const scores=top.modes.map(mode=>{
      // The mode's own triad: its centre, the member nearest a fifth above, and the one two scale steps above it.
      const fifth=members.reduce((best,pc)=>Math.abs(((pc-mode.center)%period+period)%period-7)<Math.abs(((best-mode.center)%period+period)%period-7)?pc:best,members[0]);
      const at=members.findIndex(pc=>pitchClassDistance(pc,mode.center,period)<=tolerance),third=n>=5?members[(at+2)%n]:null;
      let score=0;for(let k=0;k<grid.length;k++){if(!state.profile[k])continue;const pc=grid[k],is=target=>target!==null&&pitchClassDistance(pc,target,period)<=tolerance;
        const weight=is(mode.center)?profile.center:is(fifth)?profile.fifth:is(third)?profile.third:members.some(m=>is(m))?profile.other:profile.outside;
        score+=state.profile[k]*weight;}
      return score;});
    const best=Math.max(...scores),weights=scores.map((score,i)=>(top.modes[i].prior??1)*Math.exp(config.centerSharpness*(score-best))),sum=weights.reduce((a,b)=>a+b,0);
    const i=weights.indexOf(Math.max(...weights));center={set:top.id,pc:top.modes[i].center,mode:top.modes[i].name,probability:weights[i]/sum};
  }
  return {modelId:state.modelId,vocabularyId:vocabulary.vocabularyId,at:state.at,heardSeconds:state.heardSeconds,layers,center};
}

// Pitch evidence from a chord model's state: each candidate chord's pitch classes, weighted by its score, its root (the
// vocabulary's first pitch class for the label) counted `rootWeight` times. Any chord model will do (chroma templates,
// a learned recognizer, MIDI), in any tuning its vocabulary names.
export function chordEvidence(chords,chordVocabulary,{rootWeight=2}={}){
  if(!chords||!['interpreted','ambiguous'].includes(chords.status))return [];
  const byLabel=new Map(chordVocabulary.labels.map(label=>[label.id,label.pitchClasses])),pitches=[];
  for(const {label,score} of chords.candidates??[]){const pcs=byLabel.get(label);if(!pcs||!(score>0))continue;
    const share=score/(pcs.length-1+rootWeight);pcs.forEach((pc,i)=>pitches.push({pc,weight:share*(i===0?rootWeight:1)}));}
  return pitches;
}

// Pitch evidence from a chroma frame (12 values, audio-chroma.js): the classes within `threshold` of the strongest,
// each weighted by its share of it. A chroma's partials and noise spread energy over every class, which heard whole
// reads as music in no scale; a pitch-class projection keeps what is played (as audio-chroma.js harmonyProjection
// does for the chord model). On GuitarSet solo lines, whole chroma was heard as the chromatic set (0.94-0.97); within
// half to seven tenths of the strongest, as the collection played.
// A chroma of more classes than twelve (audio-chroma.js ChromaFrames classes) gives its classes' pitch classes, class k
// at k * 12 / classes semitones: quarter tones for a 24-class chroma.
export function chromaEvidence(chroma,{threshold=.6}={}){
  if(!chroma?.length)return [];
  const values=Array.from(chroma),top=Math.max(...values),step=12/values.length;
  return top>0?values.flatMap((value,k)=>value>=threshold*top?[{pc:k*step,weight:value/top}]:[]):[];
}

export {levelsLayer};
