// Forecasts: what a listening bot expects of the player it hears (the foresight plan, research/MUSEBOTS_LIVE_LISTENING_
// AND_PERFORMER_FORESIGHT_PLAN.md 7.5). A forecast is not a plan, and travels on its own address, /broadcast/forecast.
// Its author (the bot, and the module that made the forecast, with a version) is kept apart from its subject (the player
// it is about). It carries the evidence it rests on, where it applies and when it lapses, all in the session's beats, and
// how sure it is. No plan lane receives it: a view draws it as what someone expects, never as what the player declared.
//
// One kind so far: the next chord change the harmonic memory expects, where the performer changed chord one cycle ago
// (harmonic-memory.js, predictChange).
export const FORECAST_ADDRESS='/broadcast/forecast',FORECAST_VERSION=1;
// Bounds a reader holds a forecast to: identities and labels, and the chord's pitches.
const MAX_ID=96,MAX_LABEL=48,MAX_PITCHES=12;
// A forecast lapses this many session beats after the change it expects: by then the change has come or has not.
export const FORECAST_LAPSE_BEATS=1;

// A forecast of the performer's next chord change, or null where it cannot be placed on the session's beats. The capture
// must be on the session clock (an audio context's own seconds are not), and the timeline known.
//   author      {id, incarnation}: the listening bot
//   subject     {id, label}: the player it hears
//   prediction  predictChange's {label, from, changeAt, cycle, agreement}, in capture seconds
//   beat        the performer's beat forecast ({periodSeconds}): the cycle's length, for the evidence window
//   pitches     the chord, as the follower voices it
//   timeline    the session's tempo map: beatAtReference(seconds), and its sessionId, epoch, id and revision
//   capture     {clockDomain, now, calibration}: a calibration's offsetSeconds moves capture times to when they were
//               played; without one the forecast says it is uncalibrated
export function harmonyChangeForecast({author,subject,prediction,beat,pitches=[],timeline,capture,revision=1}){
  if(!prediction||typeof timeline?.beatAtReference!=='function'||capture?.clockDomain!=='session-seconds'||!(beat?.periodSeconds>0))return null;
  const offset=Number.isFinite(capture.calibration?.offsetSeconds)?capture.calibration.offsetSeconds:0;
  const beatAt=seconds=>timeline.beatAtReference(seconds-offset);
  const appliesAtBeat=beatAt(prediction.changeAt),createdAtBeat=beatAt(capture.now),fromBeat=beatAt(prediction.changeAt-prediction.cycle*beat.periodSeconds);
  // A change already past is no forecast.
  if(![appliesAtBeat,createdAtBeat,fromBeat].every(Number.isFinite)||appliesAtBeat<=createdAtBeat)return null;
  return {v:FORECAST_VERSION,kind:'harmony-change',forecastId:`${author.id}:${subject.id}:harmony-change`,revision,
    author:{id:author.id,incarnation:author.incarnation??null,module:'harmonic-memory',version:1},
    subject:{id:subject.id,label:subject.label??null},
    sessionId:timeline.sessionId??null,epoch:timeline.epoch??null,tempoId:timeline.id??null,tempoRevision:timeline.revision??null,
    createdAtBeat,appliesAtBeat,expiresAtBeat:appliesAtBeat+FORECAST_LAPSE_BEATS,
    evidence:{fromBeat,toBeat:createdAtBeat,cycleBeats:prediction.cycle},
    value:{label:prediction.label,from:prediction.from??null,pitches:[...pitches]},
    uncertainty:{agreement:prediction.agreement,calibrationStatus:Number.isFinite(capture.calibration?.offsetSeconds)?'calibrated':'uncalibrated'}};
}

// A forecast as a reader may trust it, whoever sent it: every field checked and bounded, or null.
export function readForecast(value){
  if(!value||typeof value!=='object'||value.v!==FORECAST_VERSION||value.kind!=='harmony-change')return null;
  const text=(item,max)=>typeof item==='string'&&item.length>0&&item.length<=max?item:null;
  const beatOf=item=>Number.isFinite(item)&&item>=0?item:null;
  const forecastId=text(value.forecastId,MAX_ID),authorId=text(value.author?.id,MAX_ID),subjectId=text(value.subject?.id,MAX_ID);
  const createdAtBeat=beatOf(value.createdAtBeat),appliesAtBeat=beatOf(value.appliesAtBeat),expiresAtBeat=beatOf(value.expiresAtBeat);
  const agreement=Number.isFinite(value.uncertainty?.agreement)?Math.max(0,Math.min(1,value.uncertainty.agreement)):null,label=text(value.value?.label,MAX_LABEL);
  if(!forecastId||!authorId||!subjectId||appliesAtBeat===null||expiresAtBeat===null||expiresAtBeat<appliesAtBeat||agreement===null||!label||
    !Number.isSafeInteger(value.revision)||value.revision<1)return null;
  return {v:FORECAST_VERSION,kind:'harmony-change',forecastId,revision:value.revision,
    author:{id:authorId,module:text(value.author.module,MAX_LABEL),version:Number.isSafeInteger(value.author.version)?value.author.version:null},
    subject:{id:subjectId,label:text(value.subject.label,MAX_LABEL)},
    createdAtBeat,appliesAtBeat,expiresAtBeat,
    evidence:{fromBeat:beatOf(value.evidence?.fromBeat),toBeat:beatOf(value.evidence?.toBeat),
      cycleBeats:Number.isSafeInteger(value.evidence?.cycleBeats)&&value.evidence.cycleBeats>0?value.evidence.cycleBeats:null},
    value:{label,from:text(value.value.from,MAX_LABEL),
      pitches:(Array.isArray(value.value.pitches)?value.value.pitches:[]).filter(pitch=>Number.isFinite(pitch)&&pitch>=0&&pitch<=127).slice(0,MAX_PITCHES)},
    uncertainty:{agreement,calibrationStatus:value.uncertainty.calibrationStatus==='calibrated'?'calibrated':'uncalibrated'}};
}
