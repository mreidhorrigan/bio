import {frozenJson,identifier} from '../planning-data.js';
import {pulsePosition,pulseDistance} from './continuous-models.js';

// Meter labels are discrete. The cycle, grouping and phase carry its musical
// meaning; a numerator by itself cannot distinguish the groupings of 7/8.
export function metricalState({id,numerator,denominator,groups,referencePulse=pulsePosition(1,4),phase=pulsePosition(0),
  effectiveInterval=null}) {
  identifier(id,'metrical hypothesis');
  if(!Number.isSafeInteger(numerator)||numerator<1||numerator>4096||!Number.isSafeInteger(denominator)||denominator<1||denominator>4096||
    !Array.isArray(groups)||!groups.length||groups.length>4096||groups.some(x=>!Number.isSafeInteger(x)||x<1)||groups.reduce((a,b)=>a+b,0)!==numerator)
    throw new TypeError('Meter needs a positive cycle and groups that partition it');
  referencePulse=pulsePosition(referencePulse.numerator,referencePulse.denominator);phase=pulsePosition(phase.numerator,phase.denominator);
  if(referencePulse.numerator<=0)throw new TypeError('Positive metrical reference pulse required');
  if(effectiveInterval!==null&&(!Number.isFinite(effectiveInterval.start)||!Number.isFinite(effectiveInterval.end)||effectiveInterval.end<=effectiveInterval.start))
    throw new TypeError('Invalid metrical effective interval');
  return frozenJson({id,label:`${numerator}/${denominator}`,numerator,denominator,groups,referencePulse,phase,effectiveInterval,
    cycle:pulsePosition(numerator*referencePulse.denominator,denominator*referencePulse.numerator),
    cell:pulsePosition(referencePulse.denominator,denominator*referencePulse.numerator)}).data;
}

export function metricalPosition(meter,pulse) {
  const cycle=meter.cycle.numerator/meter.cycle.denominator,cell=meter.cell.numerator/meter.cell.denominator;
  const position=((pulseDistance(pulse,meter.phase)%cycle)+cycle)%cycle;
  const grid=position/cell,nearest=Math.round(grid),onCell=Math.abs(grid-nearest)<1e-7;
  let offset=0,groupStart=false;
  for(const size of meter.groups){if(onCell&&nearest===offset)groupStart=true;offset+=size;}
  return {position,cell:nearest,onCell,downbeat:onCell&&nearest===0,groupStart};
}
