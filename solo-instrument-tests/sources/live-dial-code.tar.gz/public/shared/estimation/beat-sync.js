// Beat synchronization of a local playing ensemble with a performer it hears.
//
// Tempo following matches the performer's period and leaves the beats wherever
// they happened to fall. Closed-loop renders with GuitarSet guitarists measured
// what that sounds like (scripts/evaluate-sync.mjs): once the tempo settled, the
// ensemble sat at a steady offset of up to a quarter of a beat (190-225 ms
// behind a rock guitarist at 85 BPM), and the half-BPM error a tempo deadband
// leaves drifted the beats 150 ms over half a minute.
//
// Synchronization steers the conductor's own clock beat by beat. Before each
// beat pulse it finds that beat's asynchrony: when the ensemble will sound it
// (one output delay after the pulse) against the nearest beat of the
// performer's grid, which is the input report's calibrated phase and period.
// Then it sets the coming beat's duration to its tempo path less a correction:
// linear phase correction, the model of human sensorimotor synchronization
// (Vorberg & Wing 1996; Repp 2005). Sources, with DOIs, are listed in
// research/kalman-references.md.
//
// How much a beat corrects follows what people do (phaseCorrection below). The
// share grows with the beat's length: about half at a 500 ms beat (Wright et al.
// 2014, after Repp), and all of it once a beat lasts a second (Repp 2008;
// Repp 2011 found overcorrection there, which a machine need not copy). It is
// proportional up to about 15% of the beat (Repp 2002). Beyond that people's
// deliberate corrections still grow, only more slowly, and here the rest is
// corrected at half the rate. No other ceiling applies. An earlier version capped
// every correction at 6% of the beat. Humans correct far more than that, and a
// quarter-beat error then took several bars to close.
//
// The tempo path and the correction are kept apart. The path ramps toward the
// performer's period by a bounded step per beat (maxBeatChange, 6%): that is
// period correction, and the step is this design's choice. Studies of tempo
// adaptation show it depends on intention and awareness (Repp & Keller 2004) but
// give no rate to copy. Phase is corrected only once the path is near the
// performer's tempo; until then the beats slide across the performer's grid and
// their asynchrony means nothing. "Near" is judged by the path, not by the
// corrected beat. A correction that slows the beats must not itself switch the
// correction off: that loop never converged on half a beat of error after a
// composed tempo curve.
//
// While no bot is sounding, as with a band that has yet to enter, nothing can be
// heard to jump. So the tempo is taken as heard and the whole asynchrony is
// corrected at once, and a band that joins after the performer starts enters on
// the performer's beat.
//
// Phase is used only when the report states it: a calibrated input in session
// seconds. Otherwise only the period is matched.
//
// A performer's deliberate placement is theirs to keep (the rhythm performance
// layer's stage C: research/rhythmic_humanization_state_of_the_art.md §7.5, §3.8;
// docs/PERFORMANCE_TIMING.md). A player who sits behind the beat by intent, and hears
// the band, moves back each time the band moves to meet them. Measured with an
// adaptive virtual performer (test/offset-aware-sync.test.mjs), a player 20 ms
// laid back pulled the band from 120 to 118 BPM and still lost the pocket, and one
// pushing 15 ms ahead made it rush. So the band corrects only what differs from
// the placement it knows (performerPlacementSeconds, or the report's own
// placementSeconds; + behind). Nothing here estimates a placement: the band sees
// only asynchrony, and in a loop where both correct, a placement shows up as tempo
// drift, not as offset. Without a reference, a constant latency and a constant
// musical offset look the same (the Kalman influence plan, §4.4). placement.js
// supplies one, declared, or measured by listening first. Unknown, it is 0, as
// before.
import {compoundGrid,gridSpacing} from './metrical-octave.js';
import {SUBDIVISION_EVIDENCE} from './subdivision-evidence.js';

// phaseGain: the share of an asynchrony corrected at a 500 ms beat. People correct
// about half at that tempo (Wright et al. 2014, after Repp 2001, 2008), and in
// closed-loop renders with five GuitarSet guitarists fixed shares from 0.4 to 0.85
// changed the lag little, lower ones being smoother. slowBeatSeconds: the beat from
// which the whole asynchrony is corrected (Repp 2008, 2011). linearPhaseRange: the
// share of the beat up to which correction is proportional (Repp 2002).
// followSubdivision: take the performer's subdivision too (triplets or straight), as a meter change at a bar line.
// Early rather than late. The user: "for a drummer entering, being slightly early is better than being slightly
// late ... audiences HATE lagging in a way they don't hate rushing." Players synchronizing land a little ahead of
// the beat, too: the negative mean asynchrony (Repp 2005).
//
// So a quiet band, which is how a band enters, aims entryAnticipationSeconds (15 ms) ahead of the performer. Two
// more options stay off by default:
// - aiming ahead while it plays (anticipationSeconds);
// - taking back more of a lag than of a rush (lagCorrection, a multiple, never more than the whole lag).
//
// In closed loop on 178 GuitarSet takes (the band entering at 8 s) the band already sat 3 ms early at the level,
// from the detector's attack placement. Aiming 8 ms ahead, with or without a 1.3x lag correction, made twice as
// many takes early by over 15 ms (18 to 33-40). It left the late ones late (16 to 20) and cost 2% of beats within
// 50 ms. The late entries were mostly bands half a beat out, on the "and", which no aim moves. The entry aim alone
// moved entries 2 ms earlier at no measurable cost.
// startsFromEstimate: the band's tempo and meter at the start are an estimate of the performer's, as a band told "a
// 12/8, around 68" has one. Off by default: the room's tempo is arbitrary, and the first reading is taken as heard.
// With it, readings are folded toward the band's own beat from the first (octaves, and the relations of a compound
// meter, metrical-octave.js), and a quiet band too keeps the estimate until a reading more than changeTolerance
// from it has held for estimateBeats beats (twice as long at 3:2, 2:3, 4:3 or 3:4). A transient misreading does not
// move it; a performer who really plays elsewhere does, after a few seconds. Taking readings within 20% of the
// estimate at once, until the band had held the performer's beat for eight beats, made no consistent difference on
// GuitarSet with estimates 10% off, so the simpler rule stays.
// alignToAttacks (in development, with startsFromEstimate): the band finds the performer's phase in their attacks
// (tempo-influence.js attackPhase), and keeps its own time aligned to them where the listener resolves no pulse.
// groupByBass (in development): the band's beat is where the bass falls (bassGroups below).
// The musical pocket: the most a performer's placement may be from the beat (seconds). Beyond it the band is hearing
// another beat, not a placement (performerPlacementSeconds; placement.js).
export const POCKET_SECONDS=.1;
export const SYNC_DEFAULTS=Object.freeze({phaseGain:.5,slowBeatSeconds:1,linearPhaseRange:.15,maxBeatChange:.06,phaseWindow:.1,
  anticipationSeconds:0,entryAnticipationSeconds:.015,lagCorrection:1,performerPlacementSeconds:0,correctPersistent:false,acquireWhileQuiet:true,followSubdivision:true,
  // How the conductor takes a performer's subdivision (tempo-influence.js followSubdivision): 'sequential', on evidence
  // gathered attack by attack to subdivisionAlarm (subdivision-evidence.js; the audit's I08), or 'hold', a window's
  // reading held four seconds (as before 28 September 2026).
  subdivisionEvidence:'sequential',subdivisionAlarm:SUBDIVISION_EVIDENCE.alarm,
  reactivity:'auto',changeTolerance:.08,maxChangeBeats:24,startsFromEstimate:false,estimateBeats:8,alignToAttacks:false,groupByBass:false});

// How readily a sounding band takes a new tempo from the performer. The user asked for this:
//   "we want the bots to be capable of being sensitive and reactive (in some situations) but in other situations,
//   we want them to pick the most solid rhythm and stick with it, especially if someone is freely soloing (or
//   singing) overtop ; in those cases, the bots would be more confident in themselves as rhythmic authorities"
//
// Small drifts, within changeTolerance of the band's tempo, and octaves of it are followed as they come. Any other
// change must hold for (1 - reactivity) * maxChangeBeats beats first. A band that is quiet, or has followed nothing
// yet, is acquiring and takes the performer's time at once.
//
// A change at a simple ratio to the band's tempo (3:2, 2:3, 4:3, 3:4) must hold twice as long. After a band has
// followed a performer, such a reading is more often a cross-rhythm or another level of the same beat than a new
// tempo. Performers' tempo changes arrive as drifts, which are followed as they come.
//
// reactivity 'auto' reads it from the performer's rhythm over the last 32 beat steps (tempo-influence.js
// decisions). The share of steps without a usable phase of the performer's is their freeness:
// - a phase withheld as ambiguous or too uncertain;
// - a phase at a level the band's tempo is not an octave of;
// - a pulse not resolved at all.
// A comping guitarist leaves few such steps, so the band stays reactive. A free solo or a voice leaves many, and
// the band keeps its own time. Under a GuitarSet rock solo a band had held 85 BPM for 30 s when a reading of 4:3
// took it to 113. Its previous 16 beats happened to be clean, so the window is 32 beats: one clean stretch of a solo
// does not make the band fully reactive again.
const CROSS_RHYTHMS=[3/2,2/3,4/3,3/4];
const FREE_REASONS=new Set(['no-phase','phase-at-another-level','phase-too-uncertain','unresolved-pulse','stale-evidence']);
export function reactivityOf(decisions,{reactivity='auto',window=32}={}){
  if(reactivity!=='auto')return {reactivity,freeness:null};
  const steps=(decisions??[]).filter(decision=>decision?.decisionId?.startsWith('beat-sync:')).slice(-window);
  if(steps.length<window/2)return {reactivity:1,freeness:null};
  const free=steps.filter(step=>FREE_REASONS.has(step.reason)).length/steps.length;
  return {reactivity:Math.max(.1,Math.min(1,1-1.5*free)),freeness:free};
}
// The period the band steers toward this beat: the performer's, or its own while a change waits. pending: the change
// waiting from the last beat ({period, beats}) or null. Returns {period, pending, waiting}. A band that starts from
// an estimate is never acquiring here, and waits at least estimateBeats.
export function heldPeriod({period,current,pending=null,reactivity,acquiring,config}){
  const estimated=Boolean(config.startsFromEstimate);
  if(acquiring&&!estimated||!(current>0)||Math.abs(period/current-1)<=config.changeTolerance)return {period,pending:null,waiting:false};
  const ratio=period/current,crossRhythm=CROSS_RHYTHMS.some(value=>Math.abs(ratio/value-1)<.03);
  const beats=pending&&Math.abs(period/pending.period-1)<=config.changeTolerance/2?pending.beats+1:1,
    required=Math.max(Math.round((1-reactivity)*config.maxChangeBeats*(crossRhythm?2:1)),estimated?config.estimateBeats*(crossRhythm?2:1):0);
  return beats>required?{period,pending:null,waiting:false}:{period:current,pending:{period,beats,required},waiting:true};
}

// The correction a beat of `beatSeconds` makes for `asynchrony` (seconds, + late): its share
// grows with the beat's length (half an octave of tempo below 120 BPM halves it no further than
// phaseGain / 2), proportional to about 15% of the beat and at half the rate beyond.
export function phaseCorrection(asynchrony,beatSeconds,{phaseGain,slowBeatSeconds,linearPhaseRange,lagCorrection=1}) {
  const share=Math.max(phaseGain/2,Math.min(1,phaseGain+(1-phaseGain)*(beatSeconds-.5)/(slowBeatSeconds-.5)));
  const size=Math.abs(asynchrony),linear=linearPhaseRange*beatSeconds,shaped=size<=linear?size:linear+(size-linear)/2;
  // A late band (asynchrony > 0) takes back more of it than an early one.
  return Math.sign(asynchrony)*Math.min(size,share*shaped*(asynchrony>0?lagCorrection:1));
}

// One beat's step. cursor: the beat pulse about to be emitted ({soundAt,
// beatSeconds, quiet}); base: the tempo path's beat (seconds) from the last step,
// or null to start it from the current beat; period: the performer's beat in the
// ensemble's beat unit (seconds), already folded to its level; phase: {beatAt,
// periodSeconds (also in the ensemble's unit), varianceSeconds2, placementSeconds?, ageSeconds?} in the same
// clock as soundAt, or null. config: SYNC_DEFAULTS plus minimumBpm, maximumBpm,
// maxPhaseUncertainty and phaseDeadbandSeconds. Returns the coming beat's
// interval and tempo, the path's beat for the next step, and why. However large
// the correction, a beat stays between half and one and a half of the
// performer's.
// persistent: the asynchrony that has persisted (from the last step, or null). A partner who corrects in proportion, as
// people do (Repp 2000, even below awareness), turns an error the band leaves inside its deadband into tempo: in
// closed loop, a performer on the beat who started 8 ms off moved band and performer together to 120.6 BPM, and a
// placement the band knew still drifted (test/offset-aware-sync.test.mjs). With correctPersistent the band corrects
// the running mean of the asynchrony there, however small, and a beat's own error only beyond the deadband. It is off:
// on GuitarSet's recordings, which do not answer the band, it cost about a point of beats within 50 ms among the takes
// the band locked to (88.4% to 87.5%), took back half the band's few milliseconds of earliness, and slowed a new tempo
// taken after noise (docs/PERFORMANCE_TIMING.md §6). Which matters more is for a session with a player who does answer.
export function beatStep({cursor,base=null,period,phase,config,persistent=null}) {
  const target=Math.min(60/config.minimumBpm,Math.max(60/config.maximumBpm,period)),step=config.maxBeatChange;
  const acquiring=Boolean(config.acquireWhileQuiet&&cursor.quiet),from=base>0?base:cursor.beatSeconds;
  const path=acquiring?target:Math.min(from*(1+step),Math.max(from*(1-step),target)),near=Math.abs(path/target-1)<=config.phaseWindow;
  let asynchrony=null,reason=null;
  if(!phase)reason='no-phase';
  else{
    // A band counting a compound meter aligns to the eighths of a pulse it hears through that meter.
    const grid=gridSpacing(phase.periodSeconds,target)??(cursor.subdivision%3===0||config.startsFromEstimate?compoundGrid(phase.periodSeconds,target):null);
    if(!grid)reason='phase-at-another-level';
    else if(!(Math.sqrt(phase.varianceSeconds2)<=config.maxPhaseUncertainty*target))reason='phase-too-uncertain';
    else{
      // + late. Aiming a little early (anticipationSeconds > 0) puts the ensemble ahead of the performer. Against the
      // performer's beat less their placement: what they intend is not the band's error.
      const aim=cursor.soundAt+(acquiring?config.entryAnticipationSeconds??config.anticipationSeconds:config.anticipationSeconds),
        anchor=phase.beatAt-(Number.isFinite(phase.placementSeconds)?phase.placementSeconds:config.performerPlacementSeconds??0);
      asynchrony=aim-(anchor+Math.round((aim-anchor)/grid)*grid);
      if(!acquiring&&!near)reason='tempo-not-yet-near';
      else if(Math.abs(asynchrony)<config.phaseDeadbandSeconds)reason='within-phase-deadband';
    }
  }
  // What persists: the asynchrony's running mean while the band tracks the performer's phase; forgotten otherwise.
  const tracking=asynchrony!==null&&(reason===null||reason==='within-phase-deadband'),
    persisting=!tracking?null:(Number.isFinite(persistent)?persistent:0)+PERSISTENCE*(asynchrony-(Number.isFinite(persistent)?persistent:0));
  const corrected=asynchrony!==null&&reason===null,settling=config.correctPersistent!==false&&reason==='within-phase-deadband'&&!acquiring&&!phase.jump;
  // While nobody sounds the whole asynchrony goes at once; otherwise what a player would correct. A band moving its
  // beat to another position of its grid (tempo-influence.js attackPhase, jump) moves in one beat too. Inside the
  // deadband, what persists, at the same share.
  //
  // Evidence beats old (phase.ageSeconds: its last onset's age) says where the performer was, not how they answered
  // the band's last corrections. Corrected at a player's share, it swings against a partner who corrects too: in
  // closed loop, reports three beats old swung the band 80 ms either way, and four beats old dragged it to 114 BPM
  // (test/offset-aware-sync.test.mjs). A delayed loop stays stable at a gain about inversely proportional to its delay,
  // so the share is divided by the evidence's age in beats, beyond the one a report of the last beat has (the rhythm
  // performance layer's §7.5: "tune gains for the actual observation delay; discount uncertain observations").
  const discount=Number.isFinite(phase?.ageSeconds)&&phase.ageSeconds>path?path/phase.ageSeconds:1;
  const correction=settling?discount*phaseCorrection(persisting,path,config):!corrected?0:acquiring||phase.jump?asynchrony:discount*phaseCorrection(asynchrony,path,config);
  // A beat never shrinks below half the performer's or grows past one and a half.
  const interval=Math.min(1.5*target,Math.max(.5*target,path-correction));
  const bpm=Math.min(config.maximumBpm,Math.max(config.minimumBpm,60/interval));
  return {interval:60/bpm,bpm,base:path,target,asynchrony,corrected,persistent:persisting,mode:acquiring?'acquiring':near?'tracking':'approaching',reason};
}
// The share of each beat's asynchrony the running mean takes, from nothing: about four beats' memory, over which a
// tracker's noise averages down to about two-fifths of a beat's. (A tenth, a longer memory, did worse on GuitarSet.)
const PERSISTENCE=.25;

// Which position of the band's grid is its beat, from where the bass falls (groupByBass, in development). On guitar
// the beat and its "and" can be a near-tie for the listener: of 100 GuitarSet takes a band followed at the level, 19
// sat a third to half a beat out. The low strings fall on the beat (Hove et al. 2014; the bass-accent listening).
// The attacks' bass (lowRise) is tallied by position of the band's own beat: halves, or thirds in a compound meter,
// counted from soundAt, the beat it is about to play. The tally forgets with a 12-s half-life. A position other than
// the beat's own, with 1.5 times its bass over eight attacks while the band is quiet, or twice over sixteen while it
// plays, is where the beat should move.
// state: the tally from the last beat, or null. Returns {state, move}: move, the position to move the beat to
// (1 .. parts - 1), or 0 to stay. After a move the tally starts again, its positions having moved.
export function bassGroups(state,{attacks,bass,soundAt,beatSeconds,parts,now,quiet=false}){
  const s=state?.parts===parts?{...state,bass:[...state.bass]}:{parts,bass:Array(parts).fill(0),count:0,at:now,last:-Infinity};
  const decay=.5**(Math.max(0,now-s.at)/12),step=beatSeconds/parts;
  s.bass=s.bass.map(value=>value*decay);s.count*=decay;s.at=now;
  (attacks??[]).forEach((time,i)=>{
    if(!(time>s.last)||time>now)return;s.last=time;
    const units=(time-soundAt)/step,index=Math.round(units);
    if(Math.abs(units-index)>.25||!(bass?.[i]>0))return;
    s.bass[((index%parts)+parts)%parts]+=bass[i];s.count++;
  });
  const ratio=quiet?1.5:2,needed=quiet?8:16,top=s.bass.indexOf(Math.max(...s.bass));
  if(top>0&&s.count>=needed&&s.bass[top]>=ratio*Math.max(s.bass[0],1e-12))return {state:{...s,bass:Array(parts).fill(0),count:0},move:top};
  return {state:s,move:0};
}

// Whether synchronization holds the performer's beat: over the last `beats` beat steps (tempo-influence.js
// decisions), each found the performer's phase and was in it or correcting toward it, or held it while it placed them
// within the pocket (placement.js), at tempos within `tolerance` of their median. A band that listens first enters
// once it does (render bots joining {when: 'following'}).
export function beatLock(decisions,{beats=4,tolerance=.04}={}){
  const steps=(decisions??[]).filter(decision=>decision?.decisionId?.startsWith('beat-sync:')).slice(-beats);
  if(steps.length<beats)return {locked:false,reason:'too-few-beats'};
  const held=step=>step.reason==null||step.reason==='within-phase-deadband'||step.reason==='placing'&&Math.abs(step.accepted.asynchronySeconds)<=POCKET_SECONDS;
  if(steps.some(step=>step.status!=='accepted'||!held(step)))return {locked:false,reason:'phase-not-held'};
  const tempos=steps.map(step=>step.accepted.targetBpm).sort((a,b)=>a-b),median=tempos[tempos.length>>1];
  if(tempos.some(bpm=>Math.abs(bpm/median-1)>tolerance))return {locked:false,reason:'tempo-unsettled'};
  return {locked:true,bpm:median,since:steps[0].decidedAt};
}
