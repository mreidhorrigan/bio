// A listener's pulse from a learned beat tracker: the rhythm report the beam gives (rhythm-occurrence.js
// rhythmForecasts), made from a trained model's beats instead of from the beam's onsets. The model is Beat This!
// (Foscarin, Schlüter & Widmer, ISMIR 2024; render/beats/models.json names the checkpoint and what it learned from). It
// hears the whole spectrogram of an excerpt at once, before and after each frame, and marks every frame with how much
// it is a beat, and a downbeat.
//
// Two ways to hear with it:
// - as the audio arrives (live, and a recording heard as it plays): every hopSeconds the model hears the last
//   windowSeconds, so it hears nothing of what is to come. Its last frames, which have nothing after them, are left
//   aside (edgeSeconds). The beat grid is fitted to the window's beats and carried forward to forecast the next ones;
//   the model's own offline postprocessing, a peak picker over the whole piece, has no future here.
// - knowing the recording (a studio render around a clip): the model hears all of it once (lookahead), and the beats
//   ahead are the ones it heard, not a forecast.
//
// The report states a beat phase only where the model tells the beat from its "and": phaseMargin is how much more the
// beats sound as beats than the points between them do (input-report.js gives no phase below 0.1). Where the model
// hears no beats (noise, silence) the reading goes stale and the band holds its own time.
import {pulsePosition} from './continuous-models.js';

// windowSeconds, hopSeconds, edgeSeconds: what the model hears, how often, and how much of its latest to leave aside.
// spanSeconds, halfLifeSeconds: the stretch of the window the grid is fitted to, weighted toward the present.
// minimumPeriod, maximumPeriod: the beats a grid may have (up to 1.25 s: sparser peaks than that are beats the model
// missed, as in a vocal take, not a beat of 40 BPM). minimumScore: the mean beat probability at a grid's points
// for it to be followed; minimumMargin, its lead over the grid's "ands". levelSwitchRatio, switchHops: how much better a
// grid at another level must fit, on how many hops running, to replace the one followed (the band does not jump levels
// on one window's say). settleSeconds, settleHops: a passage is not followed until the model has heard this much of it
// and its grid has kept its period this many hops running (with a few seconds of context the model marks the "ands"
// as well as the beats, and settles after about five). nestedSwitchRatio and nestedSwitchHops, for a level that shares the followed one's beats (twice
// or three times it, or a half or a third, on the same beats), which the model's windows often alternate between and
// which the band can keep playing against. releaseLapsed (opt-in, in development): a level followed that is no longer
// followable (below minimumScore or minimumMargin) challenged as by a better one by a level that is, so that it is let go
// on the same hops running. Without it, a half-time reading adopted in the first seconds of a bossa (00_BN2-131) held
// off the beat's own grid, which agreed with every beat the model marked, for thirteen seconds: its agreement with the
// model's beats (0.67) left no room to be bettered by half again, while its beats sounded no more like beats than its
// "ands" did, so the band followed nothing.
export const LEARNED_PULSE_DEFAULTS=Object.freeze({windowSeconds:12,hopSeconds:.5,edgeSeconds:.1,threshold:0,peakRadius:3,
  spanSeconds:8,halfLifeSeconds:4,minimumPeriod:.25,maximumPeriod:1.25,minimumScore:.55,minimumMargin:.2,levelSwitchRatio:1.2,switchHops:2,
  nestedSwitchRatio:1.5,nestedSwitchHops:4,releaseLapsed:false,settleSeconds:4,settleHops:3,
  fitBeats:12,minimumBeats:4,maximumSpread:.08,staleBeats:3,staleSeconds:2,horizonSeconds:1,trackingScore:null});

const sigmoid=x=>1/(1+Math.exp(-x));
const median=values=>{const sorted=[...values].sort((a,b)=>a-b);return sorted.length?sorted[sorted.length>>1]:null};

// Beat times from logits: frames above the threshold that are the largest within `radius` frames either side (Beat
// This!'s minimal postprocessing), a run of equal frames counted once. Frames from `until` on are left aside.
export function activationPeaks(logits,{fps,startSeconds=0,threshold=0,radius=3,until=logits.length}={}){
  const peaks=[];
  for(let i=0;i<Math.min(until,logits.length);i++){
    const value=logits[i];if(!(value>threshold))continue;
    let top=true;for(let j=Math.max(0,i-radius);j<=Math.min(logits.length-1,i+radius)&&top;j++)if(logits[j]>value||logits[j]===value&&j<i)top=false;
    if(top)peaks.push(startSeconds+i/fps);
  }
  return peaks;
}

// The beat grid through beats: a period from their median interval; each beat numbered by how many periods it follows
// the one before (a missed beat is skipped over, not averaged in); the least-squares line through the numbered beats.
// spread is the residuals' RMS as a share of the period.
export function fitBeatGrid(beats){
  if(beats.length<2)return null;
  const intervals=beats.slice(1).map((time,i)=>time-beats[i]),rough=median(intervals);
  if(!(rough>0))return null;
  const numbers=[0];for(const interval of intervals)numbers.push(numbers.at(-1)+Math.max(1,Math.round(interval/rough)));
  const n=beats.length,meanN=numbers.reduce((a,b)=>a+b,0)/n,meanT=beats.reduce((a,b)=>a+b,0)/n;
  let sxx=0,sxy=0;for(let i=0;i<n;i++){sxx+=(numbers[i]-meanN)**2;sxy+=(numbers[i]-meanN)*(beats[i]-meanT)}
  const period=sxx>0?sxy/sxx:rough,origin=meanT-period*meanN;
  const residuals=beats.map((time,i)=>time-(origin+period*numbers[i])),rms=Math.sqrt(residuals.reduce((a,b)=>a+b*b,0)/n);
  return {period,lastBeat:origin+period*numbers.at(-1),spread:rms/period,count:n,missed:numbers.at(-1)+1-n,varianceSeconds2:rms**2/n,regression:{origin,meanQ:meanN,Sqq:sxx,count:n,residualSumSquares:rms*rms*n}};
}

// How much more the grid's beats sound as beats than the points halfway between them, in the activation's
// probabilities (each read at its frame's neighbourhood): near 1 for a clear beat, near 0 where the "ands" sound alike.
function phaseMargin(logits,{fps,startSeconds},grid,from,to){
  const at=time=>{const i=Math.round((time-startSeconds)*fps);let best=0;for(let j=i-2;j<=i+2;j++)if(j>=0&&j<logits.length)best=Math.max(best,sigmoid(logits[j]));return best};
  let on=0,off=0,count=0;
  for(let time=grid.lastBeat;time>=from;time-=grid.period){if(time>to)continue;on+=at(time);off+=at(time-grid.period/2);count++}
  return count?(on-off)/count:0;
}

// The beat grid through beat probabilities (0..1 at fps frames, the first at startSeconds): for each period and phase,
// the recency-weighted mean of the probability at the grid's points over the last spanSeconds (each point read at its
// frame's neighbourhood, so a beat a frame off still counts); and the same at the points between them. A missed beat
// lowers a grid's score a little; it does not break it.
// The level is the model's own: it was trained on people's beats. Of the grids that fit at least half as well as the
// best, the one followed is the one whose points best match the beats the model marks (peaks, in seconds): the most of
// its points on a marked beat and of the marked beats on its points (the F-measure, within 60 ms). A model that marks
// every beat is followed at that level, even where its downbeats sound stronger than its other beats; one that marks
// every other beat, at half of it. Without peaks, the best fit.
// Returns {period, lastBeat, score, margin, agreement, candidates, at(candidate)} in seconds, or null.
export function combGrid(probabilities,{fps,startSeconds,until=probabilities.length,spanSeconds=8,halfLifeSeconds=4,minimumPeriod=.25,maximumPeriod=2,peaks=[]}={}){
  const end=Math.min(until,probabilities.length),first=Math.max(0,end-Math.round(spanSeconds*fps));
  if(end-first<fps)return null;
  const near=i=>{const k=Math.round(i);let best=0;for(let j=k-1;j<=k+1;j++)if(j>=first&&j<end)best=Math.max(best,probabilities[j]);return best};
  const weight=i=>.5**((end-1-i)/(halfLifeSeconds*fps));
  const score=(period,phase)=>{let sum=0,total=0;for(let i=end-1-phase;i>=first;i-=period){const w=weight(i);sum+=w*near(i);total+=w}return total?sum/total:0};
  const candidates=[];
  for(let period=Math.min(maximumPeriod*fps,(end-first)/2);period>=minimumPeriod*fps;period-=period>40?.5:.25){
    let best=-1,bestPhase=0;
    for(let phase=0;phase<period;phase+=.5){const value=score(period,phase);if(value>best){best=value;bestPhase=phase}}
    if(best<=0)continue;
    for(const phase of [bestPhase-.25,bestPhase+.25]){const value=score(period,phase);if(value>best){best=value;bestPhase=phase}}
    candidates.push({period,phase:bestPhase,score:best,off:score(period,(bestPhase+period/2)%period)});
  }
  if(!candidates.length)return null;
  const top=Math.max(...candidates.map(c=>c.score));
  // lastHeard: the grid's latest point the model marked as a beat (a probability of at least a half there).
  const heardAt=candidate=>{for(let i=end-1-candidate.phase;i>=first;i-=candidate.period)if(near(i)>=.5)return startSeconds+i/fps;return null};
  const at=candidate=>({period:candidate.period/fps,lastBeat:startSeconds+(end-1-candidate.phase)/fps,score:candidate.score,margin:candidate.score-candidate.off,
    lastHeard:heardAt(candidate)});
  const from=startSeconds+first/fps,marked=peaks.filter(time=>time>=from);
  const agreement=candidate=>{
    if(!marked.length)return candidate.score;
    const {period,lastBeat}=at(candidate),points=[];for(let time=lastBeat;time>=from;time-=period)points.push(time);
    const hit=points.filter(time=>marked.some(peak=>Math.abs(peak-time)<=.06)).length,caught=marked.filter(peak=>points.some(time=>Math.abs(peak-time)<=.06)).length;
    const precision=points.length?hit/points.length:0,recall=caught/marked.length;
    return precision+recall>0?2*precision*recall/(precision+recall):0;
  };
  // Agreement chooses the level; the comb, the period and phase within it (a grid a frame out that happens to catch a
  // stray peak agrees as well, and fits worse).
  for(const candidate of candidates)candidate.agreement=candidate.score>=.5*top?agreement(candidate):0;
  const level=[...candidates].sort((a,b)=>b.agreement-a.agreement||b.score-a.score)[0];
  const chosen=candidates.filter(c=>c.agreement>=level.agreement-.05&&Math.abs(c.period/level.period-1)<.06).sort((a,b)=>b.score-a.score)[0];
  return {...at(chosen),agreement:chosen.agreement,candidates,at};
}

// Beats in a bar, from the downbeats among the beats: the median count between consecutive downbeats, if the
// downbeats agree (two thirds of the bars), else null.
function barLength(downbeats,period){
  if(downbeats.length<3)return null;
  const counts=downbeats.slice(1).map((time,i)=>Math.round((time-downbeats[i])/period)).filter(count=>count>=2&&count<=16),typical=median(counts);
  return typical&&counts.filter(count=>count===typical).length>=counts.length*2/3?typical:null;
}

// provider: a stream of the learned tracker, {append(samples, {frames}) -> {fps, beat, downbeat} (the window's
// logits, its last frame at the end of what it has heard) or a Promise of it, close()}. Synchronous in a render
// (render/node/beats-host.mjs), asynchronous live. lookahead: the whole recording's logits, {fps, beat, downbeat,
// startSeconds}, for a studio render that knows it.
export function createLearnedPulse({provider=null,lookahead=null,model='beat-this-final0',...options}={}){
  const config={...LEARNED_PULSE_DEFAULTS,...options};
  if(config.forecastUncertainty!==undefined&&!['legacy','iid-regression'].includes(config.forecastUncertainty))throw new TypeError('Unknown forecast uncertainty model');
  if(config.forecastUncertainty==='iid-regression'&&!lookahead)throw new TypeError('IID regression forecasts require the fitted lookahead grid, not live comb scores');
  if(!provider&&!lookahead)throw new TypeError('A learned pulse needs the tracker, or the recording\'s activations');
  let heardTo=null,lastHop=-Infinity,pending=false,revision=0,window=null,beats=[],downbeats=[],grid=null,margin=0,meter=null,lastEvidenceAt=null,
    followed=null,challenger=null,heardFrom=null,settled=0,established=false;
  const allBeats=lookahead?activationPeaks(lookahead.beat,{fps:lookahead.fps,startSeconds:lookahead.startSeconds??0,threshold:config.threshold,radius:config.peakRadius}):null;
  const allDownbeats=lookahead?activationPeaks(lookahead.downbeat,{fps:lookahead.fps,startSeconds:lookahead.startSeconds??0,threshold:config.threshold,radius:config.peakRadius}):null;
  // A window's logits, ending at `end`: its beats (all but the last edgeSeconds'), the grid through the latest of them.
  function update(result,end){
    pending=false;
    if(!result?.beat?.length)return;
    // Frame i is at the window's start plus i/fps; the window is the `seconds` before `end`.
    const startSeconds=end-(result.seconds??result.beat.length/result.fps),until=result.beat.length-Math.round(config.edgeSeconds*result.fps);
    window={fps:result.fps,startSeconds,beat:result.beat,end};
    const peaks=activationPeaks(result.beat,{fps:result.fps,startSeconds,threshold:config.threshold,radius:config.peakRadius,until});
    beats=peaks.slice(-config.fitBeats);
    downbeats=activationPeaks(result.downbeat,{fps:result.fps,startSeconds,threshold:config.threshold,radius:config.peakRadius,until});
    revision++;
    // The comb grid through the window's beat probabilities; the level followed is kept unless another fits clearly
    // better on switchHops hops running.
    const comb=combGrid(Float32Array.from(result.beat,sigmoid),{fps:result.fps,startSeconds,until,spanSeconds:config.spanSeconds,
      halfLifeSeconds:config.halfLifeSeconds,minimumPeriod:config.minimumPeriod,maximumPeriod:config.maximumPeriod,
      peaks});
    if(!comb){settled=0;return}
    let chosen=comb;
    if(followed){
      // Levels are compared by their agreement with the model's beats: a grid of every other beat fits the comb as
      // well as the beat's own.
      const same=comb.candidates.filter(c=>Math.abs(c.period/result.fps/followed.period-1)<.08).sort((a,b)=>b.agreement-a.agreement||b.score-a.score)[0];
      const kept=same?{...comb.at(same),agreement:same.agreement}:null,differs=Math.abs(comb.period/followed.period-1)>=.08;
      if(differs&&kept){
        const ratio=Math.max(comb.period,kept.period)/Math.min(comb.period,kept.period),whole=Math.round(ratio);
        const nested=[2,3,4].includes(whole)&&Math.abs(ratio/whole-1)<.06&&
          Math.abs(((((comb.lastBeat-kept.lastBeat)/Math.min(comb.period,kept.period)+.5)%1)+1)%1-.5)<.15;
        const followable=reading=>reading.score>=config.minimumScore&&reading.margin>=config.minimumMargin;
        const better=comb.agreement>=(nested?config.nestedSwitchRatio:config.levelSwitchRatio)*kept.agreement||
          config.releaseLapsed&&!followable(kept)&&followable(comb);
        challenger=!better?null:challenger&&Math.abs(challenger.period/comb.period-1)<.08?{...challenger,hops:challenger.hops+1}:{period:comb.period,hops:1};
        if(!challenger||challenger.hops<(nested?config.nestedSwitchHops:config.switchHops))chosen=kept;
      }else challenger=null;
    }
    // A window that fits well moves the grid followed; one that does not leaves the last good one, which is followed
    // until the beat has gone quiet (stale). A passage is followed once the model has heard settleSeconds of it and
    // its grid has kept its period settleHops hops running, and again so after a stale spell.
    const candidate={period:chosen.period,lastBeat:chosen.lastBeat,lastHeard:chosen.lastHeard,score:chosen.score,margin:chosen.margin,spread:1-chosen.score,
      count:Math.round(config.spanSeconds/chosen.period),missed:0,varianceSeconds2:(chosen.period*.02)**2};
    if(lastEvidenceAt!==null&&grid&&end-lastEvidenceAt>Math.max(config.staleSeconds,config.staleBeats*grid.period))established=false;
    if(candidate.score>=config.minimumScore&&candidate.margin>=config.minimumMargin){
      settled=grid&&Math.abs(candidate.period/grid.period-1)<.08?settled+1:1;
      grid=candidate;margin=candidate.margin;followed={period:grid.period};
      // The evidence is the last beat the model marked on the grid, not the grid's own latest point.
      if(grid.lastHeard!==null)lastEvidenceAt=Math.max(lastEvidenceAt??-Infinity,grid.lastHeard);
      if(settled>=config.settleHops&&end-heardFrom>=config.settleSeconds)established=true;
    }else settled=0;
    if(grid)meter=barLength(downbeats.filter(time=>time>=end-config.spanSeconds),grid.period);
  }
  function fit(logits,frames,from,to){
    revision++;
    grid=beats.length>=2?fitBeatGrid(beats):null;
    lastEvidenceAt=beats.length?beats.at(-1):lastEvidenceAt;
    margin=grid?phaseMargin(logits,frames,grid,Math.max(from,beats[0]),to):0;
    meter=grid?barLength(downbeats.filter(time=>time>=beats[0]-grid.period/2),grid.period):null;
  }
  // Knowing the recording: the grid through the beats around `now`, the last fitBeats up to it and those just after.
  function look(now){
    const split=boundIndex(allBeats,now,true),before=allBeats.slice(Math.max(0,split-config.fitBeats),split),after=allBeats.slice(split,split+2);
    beats=[...before,...after];downbeats=allDownbeats;
    const start=lookahead.startSeconds??0;
    fit(lookahead.beat,{fps:lookahead.fps,startSeconds:start},beats[0]??now,now);
  }
  // trackingScore (null: off): the free-timing gate, in development. A grid is followed only while it scores at least
  // this (its score is 1 - fit.innovation in the report); under it the reading stands, 'ambiguous', as the beam reports
  // one too poor to follow. Singing in free time scores lower than a band's beat (kalman-integration.md, "Following
  // expressive piano and singing").
  function status(now){
    if(!grid)return 'initializing';
    if(lookahead&&(grid.count<config.minimumBeats||grid.spread>config.maximumSpread))return 'initializing';
    if(now-(lastEvidenceAt??-Infinity)>Math.max(config.staleSeconds,config.staleBeats*grid.period))return 'stale';
    if(!lookahead&&!established)return 'initializing';
    return config.trackingScore!==null&&1-grid.spread<config.trackingScore?'ambiguous':'tracking';
  }
  return {
    // Hear the next frame of the input.
    hear(samples,{start,end}){
      heardTo=end;heardFrom??=start;
      if(lookahead){look(end);return}
      const due=end-lastHop>=config.hopSeconds-1e-9&&!pending;
      const answer=provider.append(samples,{frames:due});
      if(!due)return;
      lastHop=end;
      if(answer&&typeof answer.then==='function'){pending=true;answer.then(result=>update(result,end),()=>{pending=false})}
      else update(answer,end);
    },
    // The rhythm report at `now`, as rhythm-occurrence.js gives it, or null before the model has heard beats.
    report(now=heardTo){
      if(!grid)return null;
      let state=status(now);const period=grid.period,future=now+config.horizonSeconds;
      // The next beat at or after the horizon: the heard one where the recording is known, else the grid's.
      const candidate=lookahead?allBeats[boundIndex(allBeats,future-period/4)]:null,heard=candidate!==undefined&&candidate!==null&&candidate<future+period*.75?candidate:null;
      const useRegression=config.forecastUncertainty==='iid-regression',expectedTime=(!useRegression?heard:null)??grid.lastBeat+Math.max(0,Math.ceil((future-grid.lastBeat)/period))*period;
      const uncertainty=useRegression?regressionTimingVariance(grid,(expectedTime-grid.regression.origin)/period,config):null;
      if(useRegression&&!uncertainty.available)state='initializing';
      const forecast={modelId:'learned-pulse-v1',pulse:null,referencePulse:pulsePosition(1,4),expectedTime,periodSeconds:period,bpm:60/period,
        bpmUnit:pulsePosition(1,4),latentTimeVariance:useRegression?(uncertainty.available?uncertainty.latentTimeVariance:null):grid.varianceSeconds2,performedTimeVariance:useRegression?(uncertainty.available?uncertainty.performedTimeVariance:null):grid.varianceSeconds2,uncertaintyModel:useRegression?uncertainty:null,
        conditionalOn:`learned:${model}`,calibrationStatus:'uncalibrated',lastEvidenceAt,status:state};
      const level={candidateId:'learned',grouping:1,grid:1,phase:0,periodSeconds:period,evidence:Math.max(0,margin),phaseMargin:margin,
        beatAt:grid.lastBeat,held:false,phaseRatio:null,explaining:true,confirmation:0,certainty:state==='tracking'?1:0,alternatives:[],
        meter:meter?{beatsPerBar:meter}:null};
      return {modelId:'learned-pulse-v1',modelVersion:1,revision,status:state,calibrationStatus:'uncalibrated',conditionalTimingUncertainty:true,
        metricalLevelAmbiguous:false,levelAmbiguity:null,familyWeight:1,level,
        fit:{clutter:0,innovation:grid.spread},referencePulse:pulsePosition(1,4),
        learned:{model,lookahead:Boolean(lookahead),beats:beats.slice(-8),downbeats:downbeats.slice(-4),beatsPerBar:meter,spread:grid.spread,missed:grid.missed,
          window:window?{startSeconds:window.startSeconds,endSeconds:window.end}:null},
        candidates:[{id:'learned',meter:null,grid:1,score:1,association:'metrical-level',level:{grouping:1,phase:0,evidence:Math.max(0,margin),certainty:level.certainty},forecast}]};
    },
    close(){provider?.close?.()},
  };
}

function boundIndex(values,x,upper=false){let lo=0,hi=values.length;while(lo<hi){const mid=(lo+hi)>>>1;if(values[mid]<x||upper&&values[mid]===x)lo=mid+1;else hi=mid;}return lo;}
// Optional IID timing-error model. This says what the model computes; it does
// not establish independence or calibrate overlapping/quantized model peaks.
export function regressionTimingVariance(grid,beatIndex,{varianceFloorSeconds2=0,observationVarianceSeconds2=0}={}){
  if(!Number.isFinite(beatIndex)||!Number.isFinite(varianceFloorSeconds2)||varianceFloorSeconds2<0||!Number.isFinite(observationVarianceSeconds2)||observationVarianceSeconds2<0)
    throw new TypeError('Invalid forecast variance inputs');
  const r=grid?.regression;
  if(!r||r.count<=2||!(r.Sqq>0))return {available:false,reason:'insufficient-regression-degrees-of-freedom',calibrationStatus:'uncalibrated'};
  const residualVariance=r.residualSumSquares/(r.count-2),latent=Math.max(varianceFloorSeconds2,residualVariance*(1/r.count+(beatIndex-r.meanQ)**2/r.Sqq));
  if(!Number.isFinite(latent+observationVarianceSeconds2))return {available:false,reason:'non-finite-variance',calibrationStatus:'uncalibrated'};
  return {available:true,latentTimeVariance:latent,performedTimeVariance:latent+observationVarianceSeconds2,calibrationStatus:'uncalibrated',assumption:'independent-homoscedastic-timing-errors'};
}
