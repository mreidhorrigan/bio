// Consonance as a continuous field over pitch, from the harmonic series. The user: "It's likely possible to map a
// pitch space as a continuous space of contextually consonant and dissonant notes, from a core octave all the way up
// through pentatonic scales, Harris's 8-note modes, and 9, 10, 11-note extensions, with microtones continuously between
// based on the harmonic-series structure of the tonic and other notes of the scale."
//
// A pitch is heard with its partials, the nth at n times its frequency, weighted n^-rolloff and smeared by a Gaussian
// of `sigmaCents` (the pitch uncertainty of hearing): its spectral pitch-class vector, folded into the period (Milne,
// Sethares, Laney & Sharp 2011). A pitch's affinity with a context (a tonic, a chord, the chords likely next, each
// weighted) is the cosine of their vectors: how much of their harmonic series they share. Affinity with a harmonic tone
// is greatest at its octave, then at its fifth and fourth, then its thirds and sixths, and peaks at just intervals
// (386 cents for the major third), with every microtone between. Gill and Purves (2009) find the scales most used
// worldwide among those whose intervals best share the tonic's harmonics.
//
// Levels are then thresholds on one field: its strongest peaks are a core (the tonic, its fifth), more of them a
// pentatonic-like set, more a heptatonic, then the eight-note and more chromatic sets. A listener's tendency is how far
// down it goes. Sampled at a tuning's pitch classes (12-EDO, 24-EDO, any grid), the field ranks them; sampled finely,
// it finds the peaks between them. With a C major chord as the context, its levels in 12-EDO run: the triad; C major;
// with A-flat added, Barry Harris's sixth-diminished scale; then B-flat, E-flat and F-sharp.
//
// Affinity is harmonicity: it does not hear the roughness of partials a semitone apart, which is what makes jazz avoid
// a minor ninth against a chord tone. `roughnessWeight` subtracts Sethares's (1993) roughness of each candidate's
// partials against the context's (Plomp and Levelt's curve), scaled to the field's largest, with the context voiced
// from `registerMidi` and the candidate in its octave and those either side. Harmonicity and roughness are the two
// main parts of consonance in composite models (Harrison and Pearce 2020).
import {dissonance} from '../harmonic-systems/spectral.js';

const modulo=(value,period)=>((value%period)+period)%period;

export const SPECTRAL_DEFAULTS=Object.freeze({modelId:'spectral-affinity-v1',partials:12,rolloff:.75,sigmaCents:12,binCents:5,roughnessWeight:0,
  registerMidi:60,roughnessPartials:8,
  fittedOn:'hand-set within the ranges Milne et al. (2011) fit to listeners (rolloff about 0.4-0.8, smoothing about 10-12 cents): no data here'});

// The spectral pitch-class vector of weighted pitches ([{pc, weight}], pc in semitones), over `period` semitones in
// bins of `binCents`.
export function spectralVector(pitches,{periodSemitones=12,partials=SPECTRAL_DEFAULTS.partials,rolloff=SPECTRAL_DEFAULTS.rolloff,
  sigmaCents=SPECTRAL_DEFAULTS.sigmaCents,binCents=SPECTRAL_DEFAULTS.binCents}={}){
  const periodCents=periodSemitones*100,bins=Math.round(periodCents/binCents),vector=new Float64Array(bins),reach=Math.ceil(3*sigmaCents/binCents);
  for(const {pc,weight} of pitches){
    if(!(weight>0)||!Number.isFinite(pc))continue;
    for(let n=1;n<=partials;n++){
      const cents=modulo(pc*100+1200*Math.log2(n),periodCents),center=cents/binCents,strength=weight*n**-rolloff;
      for(let k=Math.floor(center)-reach;k<=Math.ceil(center)+reach;k++){
        const d=(k-center)*binCents;vector[modulo(k,bins)]+=strength*Math.exp(-d*d/(2*sigmaCents*sigmaCents));
      }
    }
  }
  return vector;
}
const cosine=(a,b)=>{let dot=0,na=0,nb=0;for(let i=0;i<a.length;i++){dot+=a[i]*b[i];na+=a[i]*a[i];nb+=b[i]*b[i]}return na&&nb?dot/Math.sqrt(na*nb):0};

// Sethares's roughness between two partials ({f, a}): his dissonance curve (harmonic-systems/spectral.js `dissonance`,
// registry/perception/roughness.json), the pair weighted by the softer partial's amplitude.
function partialRoughness(p,q){const [low,high]=p.f<q.f?[p,q]:[q,p];return Math.min(p.a,q.a)*dissonance(low.f,high.f);}
function partialsOf(midi,count,rolloff){const f0=440*2**((midi-69)/12);return Array.from({length:count},(_,i)=>({f:f0*(i+1),a:(i+1)**-rolloff}));}
// The roughness of each candidate pitch class against a context, the candidate voiced in the context's octave and the
// ones either side.
export function roughnessField(context,candidates,{periodSemitones=12,registerMidi=SPECTRAL_DEFAULTS.registerMidi,roughnessPartials=SPECTRAL_DEFAULTS.roughnessPartials,
  rolloff=SPECTRAL_DEFAULTS.rolloff,preparedRoughness=false,maxPairTerms=4194304}={}){
  if(preparedRoughness)return preparedRoughnessFor(context,candidates,{periodSemitones,registerMidi,roughnessPartials,rolloff,maxPairTerms});
  const voiced=context.filter(({weight,pc})=>weight>0&&Number.isFinite(pc)).map(({pc,weight})=>({weight,partials:partialsOf(registerMidi+modulo(pc,periodSemitones),roughnessPartials,rolloff)}));
  return candidates.map(pc=>{let total=0;
    for(const shift of [-periodSemitones,0,periodSemitones]){const own=partialsOf(registerMidi+modulo(pc,periodSemitones)+shift,roughnessPartials,rolloff);
      for(const {weight,partials} of voiced)for(const p of own)for(const q of partials)total+=weight*partialRoughness(p,q)/3;}
    return total;});
}

// The affinity of each candidate pitch class with a context: [{pc, affinity}], for `grid` (pitch classes in semitones)
// or, without one, every `stepCents` around the period; less roughnessWeight times its roughness, measured against the
// roughest pitch of the context's period on a fixed 5-cent reference grid. Normalized over the candidates asked about,
// a pitch's score changed when an unrelated candidate was added (the mathematical audit's H05); the reference is the
// same whatever is asked, and is the old normalizer for the default 5-cent field.
const REFERENCE_STEP_CENTS=5,referenceTops=new Map;
function roughnessReference(context,periodSemitones,options){
  const key=JSON.stringify([context,periodSemitones,options]);
  if(referenceTops.has(key))return referenceTops.get(key);
  const grid=Array.from({length:Math.round(periodSemitones*100/REFERENCE_STEP_CENTS)},(_,k)=>k*REFERENCE_STEP_CENTS/100);
  const top=Math.max(...roughnessField(context,grid,{periodSemitones,...options}))||1;
  referenceTops.set(key,top);if(referenceTops.size>64)referenceTops.delete(referenceTops.keys().next().value);
  return top;
}
export function affinityField(context,{grid=null,stepCents=5,periodSemitones=12,roughnessWeight=SPECTRAL_DEFAULTS.roughnessWeight,roughnessNormalizer=null,...options}={}){
  const target=spectralVector(context,{periodSemitones,...options});
  const candidates=grid??Array.from({length:Math.round(periodSemitones*100/stepCents)},(_,k)=>k*stepCents/100);
  const affinity=alignedAffinity(target,candidates,{periodSemitones,...options})??
    candidates.map(pc=>cosine(spectralVector([{pc,weight:1}],{periodSemitones,...options}),target));
  if(!(roughnessWeight>0))return candidates.map((pc,i)=>({pc,affinity:affinity[i]}));
  if(roughnessNormalizer!==null&&(!Number.isFinite(roughnessNormalizer)||roughnessNormalizer<=0))throw new RangeError('A fixed roughness normalizer must be positive and finite');
  const rough=roughnessField(context,candidates,{periodSemitones,...options}),top=roughnessNormalizer??roughnessReference(context,periodSemitones,options);
  return candidates.map((pc,i)=>({pc,affinity:affinity[i]-roughnessWeight*rough[i]/top}));
}

// The peaks of a field sampled around the period, strongest first: [{pc, affinity}], at most `count`.
export function fieldPeaks(field,{count=Infinity}={}){
  const n=field.length,peaks=[];
  for(let i=0;i<n;i++){const here=field[i].affinity;if(here>=field[(i-1+n)%n].affinity&&here>field[(i+1)%n].affinity)peaks.push(field[i]);}
  return peaks.sort((a,b)=>b.affinity-a.affinity).slice(0,count);
}

// Nested levels from a field over a tuning's pitch classes: for each size asked, that many pitch classes, the
// strongest first, each level holding the one before. sizes: e.g. [1, 2, 3, 5, 7, 8, 9, 10, 11].
export function spectralLevels(field,{sizes=[1,2,3,5,7,8,9,10,11]}={}){
  const ranked=[...field].sort((a,b)=>b.affinity-a.affinity||a.pc-b.pc);
  return sizes.filter(size=>size<=ranked.length).map(size=>({size,pitchClasses:ranked.slice(0,size).map(entry=>entry.pc).sort((a,b)=>a-b),
    weakest:ranked[size-1].affinity}));
}

const spectralBasisCache=new Map();
function alignedAffinity(target,candidates,{periodSemitones=12,partials=SPECTRAL_DEFAULTS.partials,rolloff=SPECTRAL_DEFAULTS.rolloff,
  sigmaCents=SPECTRAL_DEFAULTS.sigmaCents,binCents=SPECTRAL_DEFAULTS.binCents}={}){
  const bins=periodSemitones*100/binCents;
  if(!Number.isSafeInteger(bins)||bins<1||bins>65536)return null;
  const shifts=candidates.map(pc=>pc*100/binCents);
  if(shifts.some(shift=>!Number.isSafeInteger(shift)))return null;
  const key=JSON.stringify([periodSemitones,partials,rolloff,sigmaCents,binCents]);
  let basis=spectralBasisCache.get(key);
  if(!basis){basis=spectralVector([{pc:0,weight:1}],{periodSemitones,partials,rolloff,sigmaCents,binCents});
    if(spectralBasisCache.size>=8)spectralBasisCache.delete(spectralBasisCache.keys().next().value);spectralBasisCache.set(key,basis);}
  let a=0,b=0;for(let i=0;i<bins;i++){a+=basis[i]*basis[i];b+=target[i]*target[i];}
  const norm=Math.sqrt(a*b);
  return shifts.map(shift=>{let dot=0;const k=modulo(shift,bins);for(let i=0;i<bins;i++)dot+=basis[modulo(i-k,bins)]*target[i];return norm?dot/norm:0;});
}
// Prepared bilinear roughness for repeated queries on a fixed declared domain.
// This is opt-in: the fixed reference-grid normalization remains the default.
export function prepareRoughnessField(classes,candidates,options={}){
  if(!Array.isArray(classes)||!Array.isArray(candidates))throw new TypeError('Prepared roughness requires arrays');
  classes=Array.from(classes);candidates=Array.from(candidates);
  if(classes.length>65536||candidates.length>65536||classes.length*candidates.length>65536||
    !classes.every(Number.isFinite)||!candidates.every(Number.isFinite))throw new RangeError('Invalid or oversized roughness domain');
  const partials=options.roughnessPartials??SPECTRAL_DEFAULTS.roughnessPartials,maxPairTerms=options.maxPairTerms??4194304;
  if(!Number.isSafeInteger(partials)||partials<1||partials>64||!Number.isSafeInteger(maxPairTerms)||maxPairTerms<1||maxPairTerms>16777216||
    classes.length*candidates.length*3*partials*partials>maxPairTerms)throw new RangeError('Prepared roughness work budget exceeded');
  const rows=classes.map(pc=>roughnessField([{pc,weight:1}],candidates,{...options,preparedRoughness:false}));
  if(rows.some(row=>row.some(x=>!Number.isFinite(x))))throw new RangeError('Nonfinite prepared roughness kernel');
  return weights=>{
    if(Array.isArray(weights))weights=Array.from(weights);
    if(!Array.isArray(weights)||weights.length!==classes.length||!weights.every(w=>Number.isFinite(w)&&w>=0))throw new TypeError('Roughness weights must match the prepared context');
    return candidates.map((_,j)=>{let total=0;for(let i=0;i<weights.length;i++)total+=weights[i]*rows[i][j];return total;});
  };
}
const roughnessPlans=new Map;
function preparedRoughnessFor(context,candidates,options){
  const voiced=context.filter(({pc,weight})=>Number.isFinite(pc)&&weight>0),classes=voiced.map(x=>x.pc),weights=voiced.map(x=>x.weight);
  const key=JSON.stringify([classes,candidates,options]);let kernel=roughnessPlans.get(key);
  if(!kernel){kernel=prepareRoughnessField(classes,candidates,options);if(roughnessPlans.size>=8)roughnessPlans.delete(roughnessPlans.keys().next().value);roughnessPlans.set(key,kernel);}
  return kernel(weights);
}
