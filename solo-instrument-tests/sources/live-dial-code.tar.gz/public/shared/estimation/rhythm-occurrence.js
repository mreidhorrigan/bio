import {frozenJson,knownFields} from '../planning-data.js';
import {createPulseState,observePulseTrusted,forecastPulseTrusted,pulsePosition,pulseDistance,restorePulseState} from './continuous-models.js';
import {metricalState,metricalPosition} from './metrical-state.js';

// rhythm-beam-v5 keeps v4's bounded beam of pulse hypotheses (a Kalman pulse
// filter each), but scores them with a generative model of where onsets occur.
//
// A hypothesis is a beat period and phase with an active subdivision grid. Between
// two associated onsets, every grid position that passed in silence is evidence
// too: an onset occurs at a position class (its place within the cycle) with a
// probability the hypothesis learns online (Beta-Bernoulli), so the probability
// of the next onset is spread over the grid and sums to at most one. v4 chose the
// wrong metrical level in two ways this removes: a whole-pulse association paid
// nothing for its single branch, and a double-time pulse was never charged for
// the beats it predicted and did not hear.
//
// Grids are chosen, not enumerated: an onset the active grid cannot place proposes
// the rational positions (continued-fraction convergents) that can, down to the
// finest grid whose spacing timing noise can still resolve. Tuplets such as 7:11
// across bar lines or 21:16 become grids of 7 or 21 only when the timing
// resolves them, at a declared complexity cost.
//
// The beam settles a tempo family: a lattice, tempo and phase. 'Tracking' means
// that family is settled. The metrical level is read off the strongest hypothesis's
// learned pattern (after Parncutt's pulse salience): each grouping of its grid is
// weighed by how reliably its positions sound, times a declared tempo-preference
// curve. Every hypothesis learns over the same span (cycleSeconds, in whole beats),
// so groupings slower than that span gain no evidence while the preference keeps
// falling: certainty fades into the bar and hypermeter, and the level relation is
// reported as ambiguous while a rival is within levelAmbiguityRatio.
const MODEL_ID='rhythm-beam-v5',MODEL_VERSION=5;
const freeze=value=>frozenJson(value,{bytes:524288,items:65536,depth:24}).data;
const logSum=values=>{const top=Math.max(...values);return top===-Infinity?-Infinity:top+Math.log(values.reduce((sum,x)=>sum+Math.exp(x-top),0));};
const finite=(value,label)=>{if(!Number.isFinite(value))throw new TypeError(`Invalid ${label}`);return value;};
const fraction=pulse=>pulse.numerator/pulse.denominator;
const gcd=(a,b)=>{while(b)[a,b]=[b,a%b];return a;};
const lcm=(a,b)=>a/gcd(a,b)*b;
const requireModel=bank=>{if(bank?.modelId!==MODEL_ID||bank.modelVersion!==MODEL_VERSION)throw new TypeError('Unknown rhythm model; replay original observations to change models');};
// Declared alias matching for tempo families and level reports, as in v4.
const LEVEL_RATIO_TOLERANCE=.025,LEVEL_TERMS=[1,2,3,4];

function configuration(input={}) {
  knownFields(input,['referencePulse','periodsSeconds','grids','maxGrid','gridResolutionSigmas','timingFloorSeconds','gridSwitchProbability',
    'gridComplexity','occurrencePrior','occurrenceMemory','occurrenceMemorySeconds','cycleSeconds','tactus','levelAmbiguityRatio','trackingFit','meters','maxCandidates','clutterProbability','clutterWindowSeconds',
    'maximumGapPulses','changeAfter','staleAfterSeconds','minimumOnsets','trackingWeight','minimumPeriod','maximumPeriod','periodWalk',
    'innovationGate','cadenceTolerance','cadenceChangeRatio','reacquisitionShare','accentModel','levelPersistenceRatio'],'rhythm configuration');
  const config={referencePulse:pulsePosition(1,4),periodsSeconds:[0.25,0.5,1],grids:[1,2,3,4],maxGrid:32,
    // A grid must be falsifiable: an onset halfway between two of its positions is
    // 2 sd off both. Finer grids would place any onset within noise.
    gridResolutionSigmas:4,timingFloorSeconds:0.008,gridSwitchProbability:0.01,gridComplexity:2,
    // Pseudo-counts (onsets, silences): a beat usually sounds, a subdivision usually does not.
    occurrencePrior:{beat:[2,1],subdivision:[1,2]},cycleSeconds:2,
    // Visits each position class remembers. Without forgetting, a pattern heard for
    // minutes makes a new section less likely than clutter under every hypothesis.
    occurrenceMemory:32,
    // Or the memory as a time: each position forgets over this many seconds whatever the cycle's length. Metrical
    // evidence is integrated over the perceived present, a few seconds (Fraisse 1984; London 2012). null keeps visits.
    occurrenceMemorySeconds:null,
    // A declared preference for a moderate beat, used only to choose among levels of one tempo.
    tactus:{centerSeconds:0.55,logSpread:0.5},levelAmbiguityRatio:3,
    // 'Tracking' also requires a fitting interpretation: at most about one recent onset
    // in three unexplained (grace notes are common), timing surprise (mean NIS) within
    // about 2 sd of its expected 1, and a level whose positions sound at least 30% of
    // the time. Fixed on development recordings only (plan 6.1), before any held-out
    // trial was scored.
    trackingFit:{maxClutter:0.3,maxInnovation:2,minEvidence:0.3},
    meters:[],maxCandidates:48,clutterProbability:0.04,clutterWindowSeconds:8,maximumGapPulses:32,
    changeAfter:3,staleAfterSeconds:4,minimumOnsets:5,trackingWeight:0.8,minimumPeriod:0.08,maximumPeriod:4,
    periodWalk:1e-5,innovationGate:25,cadenceTolerance:0.12,cadenceChangeRatio:0.25,reacquisitionShare:0.1,accentModel:null,
    // How many times more salient a reading must be to displace one whose beats continue the last level's
    // (metrical persistence). 1 is none: each onset chooses afresh.
    levelPersistenceRatio:1,...input};
  config.referencePulse=pulsePosition(config.referencePulse.numerator,config.referencePulse.denominator);
  if(config.referencePulse.numerator<=0||!Array.isArray(config.periodsSeconds)||!config.periodsSeconds.length||config.periodsSeconds.length>8||
    !Array.isArray(config.grids)||!config.grids.length||config.grids.length>8||new Set(config.grids).size!==config.grids.length||
    !Number.isInteger(config.maxGrid)||config.maxGrid<1||config.maxGrid>96||
    config.grids.some(n=>!Number.isInteger(n)||n<1||n>config.maxGrid)||!Array.isArray(config.meters)||config.meters.length>8)
    throw new TypeError('Invalid rhythm vocabulary');
  for(const field of ['gridResolutionSigmas','timingFloorSeconds','gridSwitchProbability','gridComplexity','levelAmbiguityRatio','cycleSeconds','occurrenceMemory',
    'clutterProbability','clutterWindowSeconds','maximumGapPulses','staleAfterSeconds','trackingWeight','minimumPeriod','maximumPeriod',
    'periodWalk','innovationGate','cadenceTolerance','cadenceChangeRatio','reacquisitionShare','levelPersistenceRatio'])finite(config[field],field);
  const prior=config.occurrencePrior,tactus=config.tactus;
  if(!prior||['beat','subdivision'].some(key=>!Array.isArray(prior[key])||prior[key].length!==2||prior[key].some(x=>!Number.isFinite(x)||x<=0))||
    !tactus||!Number.isFinite(tactus.centerSeconds)||tactus.centerSeconds<=0||!Number.isFinite(tactus.logSpread)||tactus.logSpread<=0)
    throw new TypeError('Invalid occurrence or tactus prior');
  const fit=config.trackingFit;
  if(!fit||!(fit.maxClutter>=0&&fit.maxClutter<=1)||!(fit.maxInnovation>0)||!(fit.minEvidence>=0&&fit.minEvidence<1)||
    fit.maxWander!==undefined&&!(fit.maxWander>=0)||fit.wanderSeconds!==undefined&&!(fit.wanderSeconds>0))
    throw new TypeError('Invalid tracking fit requirement');
  if(config.minimumPeriod<=0||config.maximumPeriod<=config.minimumPeriod||config.periodsSeconds.some(p=>!Number.isFinite(p)||p<config.minimumPeriod||p>config.maximumPeriod)||
    config.clutterProbability<=0||config.clutterProbability>=1||config.clutterWindowSeconds<=0||config.maximumGapPulses<1||config.maximumGapPulses>128||
    config.staleAfterSeconds<=0||config.trackingWeight<=0.5||config.trackingWeight>=1||config.periodWalk<0||config.innovationGate<=0||
    config.cadenceTolerance<=0||config.cadenceTolerance>=0.5||config.cadenceChangeRatio<=config.cadenceTolerance||config.cadenceChangeRatio>=1||
    config.reacquisitionShare<=0||config.reacquisitionShare>=0.5||config.gridResolutionSigmas<1||config.timingFloorSeconds<=0||
    config.gridSwitchProbability<=0||config.gridSwitchProbability>=0.5||config.gridComplexity<0||config.levelAmbiguityRatio<=1||
    config.cycleSeconds<config.minimumPeriod||config.cycleSeconds>16||config.occurrenceMemory<2||config.occurrenceMemory>4096||
    config.levelPersistenceRatio<1||config.levelPersistenceRatio>1000||
    config.occurrenceMemorySeconds!==null&&!(config.occurrenceMemorySeconds>=0.5&&config.occurrenceMemorySeconds<=600))
    throw new TypeError('Invalid rhythm model bounds');
  for(const field of ['maxCandidates','changeAfter','minimumOnsets'])if(!Number.isInteger(config[field])||config[field]<1)throw new TypeError('Invalid rhythm budget');
  if(config.maxCandidates>128||config.changeAfter>32||config.minimumOnsets>256)throw new TypeError('Rhythm budget exceeded');
  config.meters=config.meters.map(meter=>metricalState({...meter,referencePulse:config.referencePulse}));
  if(new Set(config.meters.map(m=>m.id)).size!==config.meters.length)throw new TypeError('Duplicate meter hypothesis');
  if(config.maxCandidates<config.grids.length*config.periodsSeconds.length*Math.max(1,config.meters.length)+1)
    throw new TypeError('Reserve capacity for each configured grid/level/meter and reacquisition');
  const accent=config.accentModel;
  if(accent!==null&&(!['conditional-velocity-v1','learned-velocity-v1'].includes(accent.id)||!Number.isFinite(accent.variance)||accent.variance<=0||
    accent.id==='learned-velocity-v1'&&(!Number.isFinite(accent.priorVariance)||accent.priorVariance<=0)))
    throw new TypeError('Unknown conditional accent likelihood');
  return freeze(config);
}

// ---------------------------------------------------------------------------
// Scores

// Binary subdivision depth costs nothing here (the occurrence model's own Occam
// factor charges for unused positions); a tuplet costs by its odd factor.
const oddPart=grid=>{while(grid%2===0)grid/=2;return grid;};
const gridPrior=(grid,config)=>-config.gridComplexity*Math.log(oddPart(grid));
function tactusPrior(period,config){
  const x=Math.log(period/config.tactus.centerSeconds)/config.tactus.logSpread;
  return -0.5*x*x;
}
const score=(candidate,config)=>candidate.logLikelihood+gridPrior(candidate.grid,config)+tactusPrior(candidate.track.state.mean[1],config);

// The class of a grid position is its place within the hypothesis's cycle of whole
// beats. A class on a beat uses the beat prior.
const classOf=(index,candidate)=>{const size=candidate.cycle*candidate.grid;return ((index%size)+size)%size;};
function occurrenceProbability(candidate,cls,config){
  const [a,b]=cls%candidate.grid===0?config.occurrencePrior.beat:config.occurrencePrior.subdivision;
  return (candidate.hits[cls]+a)/(candidate.trials[cls]+a+b);
}

// Visits a position class remembers: fixed, or the memory time over the time one cycle takes.
function memoryVisits(candidate,config){
  if(config.occurrenceMemorySeconds===null)return config.occurrenceMemory;
  return Math.max(2,Math.min(4096,config.occurrenceMemorySeconds/(candidate.cycle*candidate.track.state.mean[1])));
}

// Log-probability that the grid positions strictly between the last associated
// position and `index` (both in grid steps) passed in silence and `index` sounded,
// with the counts that result. Long silences are the stale/gap machinery's business;
// maximumGapPulses bounds the walk.
function occurrence(candidate,fromIndex,toIndex,config){
  const hits=[...candidate.hits],trials=[...candidate.trials],keep=1-1/memoryVisits(candidate,config);let log=0;
  const probe={hits,trials,grid:candidate.grid,cycle:candidate.cycle};
  const visit=(cls,sounded)=>{hits[cls]=hits[cls]*keep+Number(sounded);trials[cls]=trials[cls]*keep+1;};
  for(let index=fromIndex+1;index<toIndex;index++){
    const cls=classOf(index,candidate),p=occurrenceProbability(probe,cls,config);
    log+=Math.log1p(-p);visit(cls,false);
  }
  const cls=classOf(toIndex,candidate),p=occurrenceProbability(probe,cls,config);
  log+=Math.log(p);visit(cls,true);
  return {log,hits,trials,cls};
}

function accentLikelihood(candidate,meter,pulse,cls,accent,config){
  const model=config.accentModel;
  if(accent===null||!model)return {log:0,sums:candidate.accentSums,counts:candidate.accentCounts};
  if(model.id==='conditional-velocity-v1'){
    if(!meter)return {log:0,sums:candidate.accentSums,counts:candidate.accentCounts};
    const position=metricalPosition(meter,pulse),mean=position.downbeat?0.95:position.groupStart?0.7:position.onCell?0.45:0.2;
    return {log:-0.5*(Math.log(2*Math.PI*model.variance)+(accent-mean)**2/model.variance),sums:candidate.accentSums,counts:candidate.accentCounts};
  }
  // learned-velocity-v1: each position class has its own mean velocity, learned
  // with a conjugate normal prior around the overall middle. Predictive density.
  const n=candidate.accentCounts[cls],prior=model.priorVariance,noise=model.variance;
  const posteriorVariance=1/(1/prior+n/noise),mean=posteriorVariance*(0.5/prior+candidate.accentSums[cls]/noise);
  const variance=noise+posteriorVariance;
  const keep=1-1/memoryVisits(candidate,config),sums=[...candidate.accentSums],counts=[...candidate.accentCounts];
  sums[cls]=sums[cls]*keep+accent;counts[cls]=counts[cls]*keep+1;
  return {log:-0.5*(Math.log(2*Math.PI*variance)+(accent-mean)**2/variance),sums,counts};
}

// ---------------------------------------------------------------------------
// Hypotheses

// A family is a level: the current period, in 5% bins, and meter. The beam
// reserves a share for each, so a level survives while grids compete within it.
function familyKey(period,meter){return `period-${Math.round(Math.log(period)/Math.log(1.05))}:${meter||'unknown'}`;}

function blank(size){return {hits:Array(size).fill(0),trials:Array(size).fill(0),accentSums:Array(size).fill(0),accentCounts:Array(size).fill(0)};}
// Cycles with rich divisors, so the pattern a hypothesis learns can be grouped into
// the half, quarter or dotted levels around it. Odd bar lengths (7, 11, 13) are a
// meter's business; a prime cycle would hide the beat itself.
const CYCLES=Object.freeze([1,2,3,4,6,8,12,16]);
const cycleOf=(period,config)=>CYCLES.reduce((best,c)=>
  Math.abs(Math.log(c*period/config.cycleSeconds))<Math.abs(Math.log(best*period/config.cycleSeconds))?c:best);

function seed(config,time,period,grid,meter,revision,index){
  const pulseConfig={minimumPeriod:config.minimumPeriod,maximumPeriod:config.maximumPeriod,periodWalk:config.periodWalk*(period/0.5)**3,innovationGate:config.innovationGate};
  return {id:`seed-${revision}-${index}-${grid}-${meter?.id||'unknown'}`,family:familyKey(period,meter?.id),seedPeriodSeconds:period,seedRevision:revision,
    meter:meter?.id||null,grid,gridSince:revision,cycle:cycleOf(period,config),...blank(grid*cycleOf(period,config)),
    track:Object.freeze({...createPulseState({eventTime:time,periodSeconds:period,referencePulse:config.referencePulse,
      covariance:[[0.0025,0],[0,0.01*(period/0.5)**2]],config:pulseConfig}),accepted:1,lastEvidenceAt:time}),
    logLikelihood:0,association:'initial',lastInnovation:null,lastGap:null,previousGap:null};
}

function seeds(config,time,periods,revision){
  const out=[];
  for(const [index,period] of periods.entries())for(const grid of config.grids)
    for(const meter of config.meters.length?config.meters:[null])out.push(seed(config,time,period,grid,meter,revision,index));
  const prior=-Math.log(out.length);
  return out.map(candidate=>({...candidate,logLikelihood:prior}));
}

// The finest grid whose spacing the declared timing noise can still resolve.
function resolvableGrid(period,varianceSeconds2,config){
  const sigma=Math.max(Math.sqrt(varianceSeconds2),config.timingFloorSeconds);
  return Math.max(1,Math.min(config.maxGrid,Math.floor(period/(config.gridResolutionSigmas*sigma))));
}

// Denominators of the continued-fraction convergents of x, finest last.
function convergentDenominators(x,limit){
  const out=[];let h0=1,k0=0,h1=Math.floor(x),k1=1,rest=x-Math.floor(x);
  out.push(1);
  for(let step=0;step<16&&rest>1e-9;step++){
    const inverse=1/rest,a=Math.floor(inverse);rest=inverse-a;
    const h=a*h1+h0,k=a*k1+k0;
    if(k>limit)break;
    out.push(k);[h0,k0,h1,k1]=[h1,k1,h,k];
  }
  return out;
}

function remap(candidate,grid){
  // Counts carry over for positions both grids share (always the beats themselves).
  const next=blank(grid*candidate.cycle);
  for(let cls=0;cls<candidate.grid*candidate.cycle;cls++){
    const scaled=cls*grid/candidate.grid;
    if(Number.isInteger(scaled)){for(const key of ['hits','trials','accentSums','accentCounts'])next[key][scaled]=candidate[key][cls];}
  }
  return next;
}

// Placements beyond four standard deviations are not explored: their weight is
// below e^-8 of the nearest, and each explored one costs a full filter update.
const BRANCH_NIS=16;
function quickNis(track,position,eventTime,varianceSeconds2){
  // The prediction observePulse would make (pulse-linear-v1), without building it.
  const dq=position-fraction(track.pulse),[t,d]=track.state.mean,P=track.state.covariance;
  const Ptt=P[0][0]+2*dq*P[0][1]+dq*dq*P[1][1]+track.config.periodWalk*dq**3/3;
  const innovation=eventTime-track.originSeconds-(t+dq*d);
  return innovation*innovation/(Ptt+Math.max(varianceSeconds2,track.config.varianceFloor));
}

function associate(parent,grid,counts,eventTime,availableAt,varianceSeconds2,accent,meter,config,association,updates=new Map()){
  // A young hypothesis whose tempo is still settling re-sizes its cycle, forgetting
  // the little it learned; an established one keeps its pattern through ramps.
  const period=parent.track.state.mean[1],cycle=parent.track.accepted<2*config.minimumOnsets?cycleOf(period,config):parent.cycle;
  if(cycle!==parent.cycle){parent={...parent,cycle};counts=blank(grid*cycle);}
  // Positions on `grid` around the expected one: in grid steps of the beat.
  const current=fraction(parent.track.pulse);
  const expected=current+(eventTime-parent.track.originSeconds-parent.track.state.mean[0])/period;
  const from=Math.round(current*grid),center=Math.round(expected*grid),out=[];
  if(Math.abs(current*grid-from)>1e-9)return out; // the last position must lie on this grid
  const probe={...parent,grid,...counts};
  for(const index of [center-1,center,center+1]){
    if(index<=from||(index-from)/grid>config.maximumGapPulses||quickNis(parent.track,index/grid,eventTime,varianceSeconds2)>BRANCH_NIS)continue;
    // The parent's track is this bank's own frozen state, validated when made or restored.
    // One parent's update at one pulse position is the same whichever meter or grid alternative asks for it.
    const pulse=pulsePosition(index,grid),key=`${pulse.numerator}/${pulse.denominator}`;let update=updates.get(key);
    if(!update){update=observePulseTrusted(parent.track,{pulse,eventTime,availableAt,varianceSeconds2});updates.set(key,update);}
    if(!update.accepted)continue;
    const occur=occurrence(probe,from,index,config),accented=accentLikelihood(probe,meter,pulse,occur.cls,accent,config);
    out.push({candidate:{...parent,grid,family:familyKey(update.track.state.mean[1],meter?.id??parent.meter),meter:meter?.id??parent.meter,
      hits:occur.hits,trials:occur.trials,accentSums:accented.sums,accentCounts:accented.counts,track:update.track,association,
      previousGap:parent.lastGap,lastGap:pulseDistance(pulse,parent.track.pulse),lastInnovation:update.diagnostics.nis,
      logLikelihood:parent.logLikelihood+Math.log(1-config.clutterProbability)+update.diagnostics.logLikelihood+occur.log+accented.log},
      nis:update.diagnostics.nis,index});
  }
  return out;
}

function branches(parent,event,config,revision){
  const {eventTime,availableAt,varianceSeconds2,accent}=event,out=[],updates=new Map;
  const meters=parent.meter&&config.meters.length>1?config.meters:[config.meters.find(m=>m.id===parent.meter)||null];
  for(const meter of meters){
    const switched=meter!==null&&meter.id!==parent.meter;
    const transition=config.meters.length>1?Math.log(switched?0.01/(config.meters.length-1):0.99):0;
    const kept=associate(parent,parent.grid,parent,eventTime,availableAt,varianceSeconds2,accent,meter,config,switched?'meter-transition':'onset',updates);
    out.push(...kept.map(item=>({...item.candidate,logLikelihood:item.candidate.logLikelihood+transition})));
    // A poorly placed onset proposes the grids that place it: a new tuplet, or a finer one.
    if(!kept.some(item=>item.nis<=9)){
      const period=parent.track.state.mean[1],current=fraction(parent.track.pulse);
      const expected=current+(eventTime-parent.track.originSeconds-parent.track.state.mean[0])/period;
      const limit=resolvableGrid(period,varianceSeconds2,config),grids=new Set();
      for(const q of convergentDenominators(expected-Math.floor(expected),limit)){
        if(q===parent.grid)continue;
        const joined=lcm(parent.grid,q);
        grids.add(joined<=limit?joined:q);
      }
      for(const grid of grids){
        const counts=remap(parent,grid),cost=Math.log(config.gridSwitchProbability);
        for(const item of associate(parent,grid,counts,eventTime,availableAt,varianceSeconds2,accent,meter,config,'grid-change',updates))
          out.push({...item.candidate,gridSince:revision,logLikelihood:item.candidate.logLikelihood+transition+cost});
      }
    }
  }
  out.push({...parent,association:'clutter',lastInnovation:null,
    logLikelihood:parent.logLikelihood+Math.log(config.clutterProbability/config.clutterWindowSeconds)});
  return out.map((candidate,index)=>({...candidate,id:`${revision}:${candidate.family}:${fraction(candidate.track.pulse)}:${index}:${parent.id.split(':')[0]}`}));
}

// A new grid starts with a switch cost and an unlearned pattern; left to the plain
// beam it is pruned before its first bar. The best few recent grid changes (one per
// family and grid) keep a slot for PROBATION_ONSETS onsets to earn their keep.
const PROBATION_ONSETS=12,PROBATION_SLOTS=6;
function compact(candidates,config,revision){
  const scored=candidates.map(candidate=>({candidate,score:score(candidate,config)})).sort((a,b)=>b.score-a.score||(a.candidate.id<b.candidate.id?-1:1));
  const distinct=new Map();
  for(const item of scored){
    const track=item.candidate.track;
    const key=`${item.candidate.family}:${item.candidate.grid}:${fraction(track.pulse)}:${Math.round(track.state.mean[1]*1000)}:${Math.round((track.originSeconds+track.state.mean[0])*1000)}`;
    if(!distinct.has(key))distinct.set(key,item); // near duplicates are pruning, never extra evidence
  }
  const available=[...distinct.values()],chosen=[],families=new Set(available.map(item=>item.candidate.family)),counts=new Map(),trial=new Set();
  for(const item of available){
    const key=`${item.candidate.family}:${item.candidate.grid}`;
    if(chosen.length>=Math.min(PROBATION_SLOTS,config.maxCandidates)||trial.has(key)||revision-item.candidate.gridSince>PROBATION_ONSETS||item.candidate.seedRevision===item.candidate.gridSince)continue;
    trial.add(key);chosen.push(item);
  }
  const quota=Math.max(1,Math.floor((config.maxCandidates-chosen.length)/families.size));
  for(const item of available)if(!chosen.includes(item)&&(counts.get(item.candidate.family)||0)<quota&&chosen.length<config.maxCandidates){chosen.push(item);counts.set(item.candidate.family,(counts.get(item.candidate.family)||0)+1);}
  for(const item of available)if(chosen.length<config.maxCandidates&&!chosen.includes(item))chosen.push(item);
  chosen.sort((a,b)=>b.score-a.score||(a.candidate.id<b.candidate.id?-1:1));
  const all=logSum(scored.map(item=>item.score)),retained=logSum(chosen.map(item=>item.score));
  return {candidates:chosen.map(item=>({...item.candidate,logWeight:item.score-retained})),pruned:candidates.length-chosen.length,
    discardedBeamMass:Math.max(0,Math.min(1,1-Math.exp(retained-all)))};
}

// The simplest ratio n:d (terms up to 4) relating two periods, or null.
function levelRatio(a,b){
  const ratio=b/a;let best=null;
  for(const n of LEVEL_TERMS)for(const d of LEVEL_TERMS){
    const error=Math.abs(ratio/(n/d)-1);
    if(error<LEVEL_RATIO_TOLERANCE&&(!best||n+d<best.n+best.d||n+d===best.n+best.d&&error<best.error))best={n,d,error};
  }
  return best;
}

const supportedAt=(candidate,config,eventTime)=>candidate.track.accepted>=config.minimumOnsets&&candidate.track.lastEvidenceAt!==null&&
  eventTime-candidate.track.lastEvidenceAt<=config.staleAfterSeconds;
const strongestOf=candidates=>candidates.reduce((best,c)=>c.logWeight>best.logWeight?c:best);

// Groupings of a hypothesis's grid that divide its learned cycle, each at the phase
// whose positions sound most reliably, weighed by the tempo preference. With a
// learned velocity model, a position's evidence is also weighed by its mean
// velocity relative to the pattern's (a phenomenal accent, after Parncutt).
function accentWeights(candidate,config){
  const size=candidate.cycle*candidate.grid;
  if(config.accentModel?.id!=='learned-velocity-v1'||!candidate.accentCounts.some(n=>n>0))return Array(size).fill(1);
  const total=candidate.accentCounts.reduce((a,b)=>a+b,0),overall=candidate.accentSums.reduce((a,b)=>a+b,0)/total;
  return candidate.accentCounts.map((n,k)=>n>0&&overall>0?(candidate.accentSums[k]/n)/overall:1);
}
// Metrical persistence: a reading whose beats fall on the prior reading's beats (the last level's, or, at the
// start and after a silence, the onset that began the passage: the first note is heard as a beat, after
// Longuet-Higgins & Lee 1982) keeps it unless a rival is levelPersistenceRatio times more salient. The beat is the
// one phase evidence cannot choose in a syncopation, whose silent beats are forgotten while its off-beats sound,
// or in swing, whose beats and swung eighths sound equally often.
// A near tie between phases goes to the one on the passage's first onset, for its first ENTRANCE_BEATS beats: weak
// enough that a piece beginning on a pickup is still heard from the beats that sound most.
// A phase confirms its reading only by sounding clearly more reliably than its rival: only the excess over
// CONFIRMING_RATIO earns persistence. Steady comping, whose beats and "ands" sound about as often, earns none.
const CONFIRMING_RATIO=1.5,PHASE_RATIO_LIMIT=1e6;
const PERSISTENCE_PHASE=.15,PASSAGE_BEATS=4,ENTRANCE_TIE=Math.log(1.2),ENTRANCE_BEATS=16;
// Beats align within PERSISTENCE_PHASE of the period, and at most PERSISTENCE_SECONDS: a bar-long reading's tolerance
// would otherwise hold a return to a new phase.
const PERSISTENCE_SECONDS=.06;
const aligned=(beatAt,periodSeconds,at)=>{
  const cycles=(beatAt-at)/periodSeconds,off=Math.abs(cycles-Math.round(cycles))*periodSeconds;
  return off<Math.min(PERSISTENCE_PHASE*periodSeconds,PERSISTENCE_SECONDS);
};
function continues(beatAt,periodSeconds,prior){
  // A reading continues one of the same period, or of a nested one (half, double, the bar), whose beats it shares.
  // Across a 3:2 or 4:3 its beats would fall between the old ones. A passage's first onset only breaks ties.
  if(!prior||prior.periodSeconds===null)return false;
  {
    const ratio=Math.max(periodSeconds,prior.periodSeconds)/Math.min(periodSeconds,prior.periodSeconds),n=Math.round(ratio);
    if(n>LEVEL_TERMS.at(-1)||Math.abs(ratio/n-1)>=.03)return false;
  }
  return aligned(beatAt,periodSeconds,prior.beatAt);
}
const onEntrance=(beatAt,periodSeconds,prior)=>Number.isFinite(prior?.entranceAt)&&beatAt-prior.entranceAt<=ENTRANCE_BEATS*periodSeconds&&
  aligned(beatAt,periodSeconds,prior.entranceAt);
const explains=candidate=>candidate.association!=='clutter'&&!(candidate.lastInnovation>9);
function levelSalience(candidate,config,prior=null,now=null){
  const size=candidate.cycle*candidate.grid,step=candidate.track.state.mean[1]/candidate.grid,out=[],weight=accentWeights(candidate,config);
  const p=Array.from({length:size},(_,k)=>occurrenceProbability(candidate,k,config)*weight[k]);
  // A beat time for any phase: the filter's current position, moved on to that phase.
  const track=candidate.track,at=track.originSeconds+track.state.mean[0],current=classOf(Math.round(fraction(track.pulse)*candidate.grid),candidate);
  // Only a hypothesis that still places the onsets holds its reading: a syncopation's off-beats are placed, a
  // performer's return to a new phase is not.
  const explaining=explains(candidate);
  // Persistence is earned: the strongest confirmation the held reading has had (its phase's evidence over the best
  // rival's, in nats), at most levelPersistenceRatio. A beat a count-in established resists a syncopation; an
  // early reading never confirmed yields as soon as the evidence turns.
  const persistence=explaining&&config.levelPersistenceRatio>1?Math.min(Math.log(config.levelPersistenceRatio),prior?.confirmation??0):0;
  for(let grouping=1;grouping<=size;grouping++){
    const period=grouping*step;
    if(size%grouping||period<config.minimumPeriod||period>config.maximumPeriod)continue;
    const phases=[];
    for(let phase=0;phase<grouping;phase++){let sum=0,n=0;for(let k=phase;k<size;k+=grouping){sum+=p[k];n++;}phases.push(sum/n);}
    const readings=phases.map((evidence,phase)=>{
      const first=at+(((phase-current)%grouping+grouping)%grouping)*step;
      // The beat of this reading nearest the present, as the filter projects it.
      const beatAt=now===null?first:first+Math.round((now-first)/period)*period,held=explaining&&config.levelPersistenceRatio>1&&continues(beatAt,period,prior);
      const entrance=config.levelPersistenceRatio>1&&!held&&onEntrance(beatAt,period,prior);
      return {evidence,phase,beatAt,held,logHeld:Math.log(evidence)+(held?persistence:entrance?ENTRANCE_TIE:0)};
    });
    const order=[...readings].sort((a,b)=>b.evidence-a.evidence||a.phase-b.phase);
    const chosen=[...readings].sort((a,b)=>b.logHeld-a.logHeld||a.phase-b.phase)[0],rival=order.find(r=>r!==chosen);
    // Persistence chooses among a period's phases only; periods are weighed by their evidence alone.
    const logSalience=Math.log(chosen.evidence)+tactusPrior(period,config),bonus=chosen.logHeld-Math.log(chosen.evidence);
    out.push({grouping,phase:chosen.phase,periodSeconds:period,evidence:chosen.evidence,beatAt:chosen.beatAt,held:chosen.held,
      phaseMargin:order.length>1?order[0].evidence-order[1].evidence:1,
      // How much more reliably the chosen phase sounds than its best rival: below 1 when persistence holds it. A rival
      // that never sounds (its onsets all unaccented, so weighted 0) leaves it unbounded: PHASE_RATIO_LIMIT.
      phaseRatio:rival?rival.evidence>0?chosen.evidence/rival.evidence:chosen.evidence>0?PHASE_RATIO_LIMIT:1:null,logSalience,logHeld:logSalience+bonus});
  }
  return out.sort((a,b)=>b.logSalience-a.logSalience||a.grouping-b.grouping);
}

// Levels come from every strong hypothesis of the tempo family, not the strongest
// alone: a tatum-level hypothesis groups only into its own cycle's divisors, and a
// quintuplet beat needs the hypothesis whose grid holds it. Groupings closer than
// 3% are one level, kept at their best salience.
const LEVEL_SOURCES=Math.log(20);
function assess(candidates,config,eventTime,prior=null,previousChallenge=null,recentTimes=[],recentFit=null){
  const top=strongestOf(candidates);
  let familyWeight=0;const sources=[];
  // With persistence, hypotheses nested with the held reading stay in contention even when a hedge of another tempo
  // family leads: a new division of the old beat and a modulation to a new beat are weighed against each other.
  const nestsPrior=candidate=>config.levelPersistenceRatio>1&&prior?.periodSeconds&&
    continues(prior.beatAt,candidate.track.state.mean[1],{beatAt:prior.beatAt,periodSeconds:prior.periodSeconds});
  for(const candidate of candidates){
    const related=levelRatio(top.track.state.mean[1],candidate.track.state.mean[1]);
    if(related)familyWeight+=Math.exp(candidate.logWeight);
    if(!related&&!nestsPrior(candidate))continue;
    if(candidate===top||top.logWeight-candidate.logWeight<LEVEL_SOURCES&&supportedAt(candidate,config,eventTime))sources.push(candidate);
  }
  const levels=[],readings=[];
  for(const candidate of sources)for(const level of levelSalience(candidate,config,prior,eventTime)){
    readings.push(level);
    // One reading per period: between hypotheses, a reading that continues the last one keeps it.
    const same=levels.find(other=>Math.abs(Math.log(other.periodSeconds/level.periodSeconds))<.03);
    if(same&&same.logHeld>=level.logHeld)continue;
    if(same)levels.splice(levels.indexOf(same),1);
    levels.push({...level,candidate});
  }
  levels.sort((a,b)=>b.logSalience-a.logSalience||a.periodSeconds-b.periodSeconds);
  // A reading that breaks with the last one is believed once it has led changeAfter onsets running; until then the
  // reading that continues the last one is reported (a momentary half time, say, does not move the beat).
  let chosen=levels[0],challenge=null;
  const holding=config.levelPersistenceRatio>1&&!chosen.held&&levels.find(l=>l.held);
  if(holding){
    const again=previousChallenge&&continues(chosen.beatAt,chosen.periodSeconds,previousChallenge)&&
      Math.abs(Math.log(chosen.periodSeconds/previousChallenge.periodSeconds))<.03;
    challenge={beatAt:chosen.beatAt,periodSeconds:chosen.periodSeconds,count:again?previousChallenge.count+1:1};
    if(challenge.count<config.changeAfter)chosen=holding;
  }
  const runner=levels.find(l=>l!==chosen),total=logSum(levels.map(l=>l.logSalience)),certainty=l=>Math.exp(l.logSalience-total);
  const level={candidateId:chosen.candidate.id,grouping:chosen.grouping,grid:chosen.candidate.grid,phase:chosen.phase,periodSeconds:chosen.periodSeconds,
    evidence:chosen.evidence,phaseMargin:chosen.phaseMargin,beatAt:chosen.beatAt,held:chosen.held,phaseRatio:chosen.phaseRatio,
    explaining:explains(chosen.candidate),
    // How strongly this reading is confirmed: the most its phase has out-sounded its rival while it was held.
    confirmation:Math.min(Math.log(config.levelPersistenceRatio),Math.max(chosen.held?prior?.confirmation??0:0,
      Math.log(Math.max(1,phaseDominance(chosen,readings,recentFit)/CONFIRMING_RATIO)))),
    certainty:certainty(chosen),
    // Graded alternatives: certainty fades toward the bar and hypermeter.
    alternatives:levels.filter(l=>l!==chosen).slice(0,5).map(l=>({periodSeconds:l.periodSeconds,evidence:l.evidence,certainty:certainty(l)}))};
  let levelAmbiguity=null;
  if(runner&&chosen.logSalience-runner.logSalience<Math.log(config.levelAmbiguityRatio)){
    const [fine,coarse]=[chosen,runner].sort((a,b)=>a.periodSeconds-b.periodSeconds),ratio=coarse.periodSeconds/fine.periodSeconds;
    levelAmbiguity={pulseRatio:pulsePosition(Math.round(ratio*12),12),relativeError:Math.abs(Math.round(ratio*12)/12/ratio-1),
      periodsSeconds:[fine.periodSeconds,coarse.periodSeconds],lastEvidenceAt:[fine.candidate.track.lastEvidenceAt,coarse.candidate.track.lastEvidenceAt],
      salienceRatio:Math.exp(chosen.logSalience-runner.logSalience)};
  }
  return {familyWeight,supported:supportedAt(chosen.candidate,config,eventTime),level,levelAmbiguity,challenge};
}

// How clearly the chosen beat's phase out-sounds its rival in any hypothesis that reads the same beat: a hypothesis
// on the beat alone has no rival phase, one on a finer grid hears the silent "ands" of a count-in.
// A beat heard alone (a count-in: a hypothesis without subdivision, its beats sounding, nothing recent between them)
// has no rival phase at all.
function phaseDominance(chosen,readings,recentFit=null){
  if(chosen.candidate.grid===1&&chosen.grouping===1&&chosen.evidence>=.7&&recentFit&&recentFit.clutter<.05)return Infinity;
  let best=chosen.phaseRatio??1;
  for(const r of readings)if(r.phaseRatio!==null&&Math.abs(Math.log(r.periodSeconds/chosen.periodSeconds))<.03&&
    aligned(r.beatAt,chosen.periodSeconds,chosen.beatAt))best=Math.max(best,r.phaseRatio);
  return best;
}

// The reported level's next beat after the horizon, from the strongest hypothesis's filter.
function levelForecast(bank,now,horizonSeconds,performanceVarianceSeconds2){
  const level=bank.level,candidate=level&&bank.candidates.find(c=>c.id===level.candidateId);
  if(!candidate)return null;
  const track=candidate.track,grid=candidate.grid,position=fraction(track.pulse)*grid,at=track.originSeconds+track.state.mean[0];
  let index=Math.max(Math.ceil(position),Math.ceil(position+(now+horizonSeconds-at)/track.state.mean[1]*grid));
  index+=((level.phase-index)%level.grouping+level.grouping)%level.grouping;
  // (The bank's own tracks, frozen with it: forecast as they are, the reading canonicalized whole below.)
  const forecast=forecastPulseTrusted(track,pulsePosition(index,grid),{performanceVarianceSeconds2}),periodSeconds=forecast.periodSeconds*level.grouping/grid;
  return {id:`${candidate.id}@${level.grouping}/${grid}`,meter:candidate.meter,grid,score:Math.exp(candidate.logWeight),association:'metrical-level',
    level:{grouping:level.grouping,phase:level.phase,evidence:level.evidence,certainty:level.certainty},
    forecast:{...forecast,periodSeconds,bpm:60/periodSeconds,conditionalOn:`level:${level.grouping}/${grid}:candidate:${candidate.id}`}};
}

// ---------------------------------------------------------------------------
// Cadence changes (as v4): a sustained change of sounded interval opens fresh alternatives.

function cadenceChange(intervals,config,varianceSeconds2){
  if(intervals.length<2*config.changeAfter)return null;
  const center=values=>[...values].sort((a,b)=>a-b)[Math.floor(values.length/2)];
  const before=intervals.slice(0,config.changeAfter),after=intervals.slice(config.changeAfter),previous=center(before),current=center(after);
  if(before.some(value=>Math.abs(value-previous)>previous*config.cadenceTolerance)||
    after.some(value=>Math.abs(value-current)>current*config.cadenceTolerance)||
    Math.abs(current-previous)<=Math.max(previous*config.cadenceChangeRatio,3*Math.sqrt(2*varianceSeconds2)))return null;
  return {previousIntervalSeconds:previous,currentIntervalSeconds:current};
}

// With persistence, the same for mixed rhythms: a sustained change of the smallest interval, in windows whose every
// interval is one to four of it. Heard locally, a change of tempo and a metric modulation are the same onsets: 100 to
// 120 BPM reads as a 6:5 grid on the old beat, and a beat that goes from threes to fives reads as a new tempo. So the
// hedge proposed is the modulated beat (as many of the new tatum as the beat held of the old), beside the old beat,
// which is still in the beam; whether the old beat goes on sounding decides between them.
function tatumChange(intervals,config,varianceSeconds2){
  if(config.levelPersistenceRatio<=1||intervals.length<2*config.changeAfter)return null;
  const tatum=values=>{
    const unit=Math.min(...values);
    return values.every(v=>{const n=Math.round(v/unit);return n>=1&&n<=4&&Math.abs(v/(n*unit)-1)<=config.cadenceTolerance;})?unit:null;
  };
  const previous=tatum(intervals.slice(0,config.changeAfter)),current=tatum(intervals.slice(config.changeAfter));
  if(!previous||!current)return null;
  const ratio=Math.max(previous,current)/Math.min(previous,current);
  // Not a doubling or halving of the tatum (a new division of the same beat), and beyond the timing noise.
  if(ratio<1+config.cadenceTolerance||Math.abs(ratio-Math.round(ratio))<config.cadenceTolerance*Math.round(ratio)||
    Math.abs(current-previous)<=3*Math.sqrt(2*varianceSeconds2))return null;
  return {previousIntervalSeconds:previous,currentIntervalSeconds:current,tatum:true};
}

function replaySeeds(config,onsets,periods,revision,availableAt){
  // Each new alternative replays the short coherent regime once, taking its best
  // placement of every onset. Old and new interpretations stay alternatives.
  const first=onsets[0];
  return seeds(config,first.eventTime,periods,revision).flatMap(start=>{
    let candidate=start;
    for(const onset of onsets.slice(1)){
      const meter=config.meters.find(m=>m.id===candidate.meter)||null;
      const options=associate(candidate,candidate.grid,candidate,onset.eventTime,availableAt,onset.varianceSeconds2,onset.accent??null,meter,config,'cadence-reinitialization');
      if(!options.length)return [];
      candidate=options.reduce((best,item)=>item.candidate.logLikelihood>best.candidate.logLikelihood?item:best).candidate;
    }
    return [candidate];
  });
}

// ---------------------------------------------------------------------------
// API (the v4 contract)

export function createRhythmBank(options={}) {
  return freeze({modelId:MODEL_ID,modelVersion:MODEL_VERSION,config:configuration(options),candidates:[],revision:0,recentOnsets:[],lastReinitialization:null,
    lastEventAt:null,lastAvailableAt:null,lastAcceptedAt:null,surpriseRun:0,status:'initializing',familyWeight:0,level:null,
    fit:{clutter:0,innovation:0,wander:null},levelPeriods:[],
    metricalLevelAmbiguous:false,levelAmbiguity:null,lastMetricalEvidenceAt:null,levelPrior:null,levelChallenge:null,
    diagnostics:{generated:0,pruned:0,reinitialized:0,discardedBeamMass:0},calibrationStatus:'uncalibrated-beam-scores'});
}

export function restoreRhythmBank(value) {
  requireModel(value);
  const config=configuration(value.config);
  if(!Array.isArray(value.candidates)||value.candidates.length>config.maxCandidates||!Number.isSafeInteger(value.revision)||value.revision<0||
    !Array.isArray(value.recentOnsets)||value.recentOnsets.length>2*config.changeAfter+1||
    value.recentOnsets.some((n,i)=>!Number.isFinite(n.eventTime)||!Number.isFinite(n.varianceSeconds2)||n.varianceSeconds2<=0||i>0&&n.eventTime<=value.recentOnsets[i-1].eventTime))
    throw new TypeError('Invalid rhythm snapshot');
  for(const candidate of value.candidates){
    restorePulseState(candidate.track);finite(candidate.logWeight,'candidate score');finite(candidate.logLikelihood,'candidate likelihood');
    if(!Number.isInteger(candidate.grid)||candidate.grid<1||candidate.grid>config.maxGrid||!CYCLES.includes(candidate.cycle)||
      ['hits','trials','accentSums','accentCounts'].some(key=>!Array.isArray(candidate[key])||candidate[key].length!==candidate.grid*candidate.cycle)||
      candidate.hits.some((hit,i)=>!Number.isFinite(hit)||hit<0||hit>candidate.trials[i]+1e-9)||
      Math.abs(fraction(candidate.track.pulse)*candidate.grid-Math.round(fraction(candidate.track.pulse)*candidate.grid))>1e-9)
      throw new TypeError('Invalid rhythm grid state');
    finite(candidate.seedPeriodSeconds,'seed period');
    if(!Number.isSafeInteger(candidate.gridSince)||candidate.gridSince<candidate.seedRevision||candidate.gridSince>value.revision)throw new TypeError('Invalid rhythm grid state');
    if(candidate.family!==familyKey(candidate.track.state.mean[1],candidate.meter))throw new TypeError('Invalid rhythm family');
  }
  for(const field of ['lastEventAt','lastMetricalEvidenceAt'])if(value[field]!==null)finite(value[field],field);
  const prior=value.levelPrior??null;
  if(prior!==null&&(!Number.isFinite(prior.beatAt)||prior.periodSeconds!==null&&!(prior.periodSeconds>0)||
    prior.entranceAt!==undefined&&!Number.isFinite(prior.entranceAt)))throw new TypeError('Invalid rhythm level prior');
  const challenge=value.levelChallenge??null,before=value.levelChallengeBefore??null;
  for(const item of [challenge,before])if(item!==null&&(!Number.isFinite(item.beatAt)||!(item.periodSeconds>0)||!Number.isInteger(item.count)||item.count<1))
    throw new TypeError('Invalid rhythm level challenge');
  if(value.candidates.length&&value.lastEventAt===null||value.lastMetricalEvidenceAt!==null&&value.lastMetricalEvidenceAt>value.lastEventAt)
    throw new TypeError('Invalid rhythm evidence time');
  if(value.revision>1&&value.candidates.length){
    const {level,levelAmbiguity}=assess(value.candidates,config,value.lastEventAt,prior,value.levelChallengeBefore??null,value.recentOnsets.map(o=>o.eventTime),value.fitBefore??null);
    if(value.metricalLevelAmbiguous!==Boolean(levelAmbiguity)||JSON.stringify(freeze(value.levelAmbiguity))!==JSON.stringify(freeze(levelAmbiguity))||
      JSON.stringify(freeze(value.level))!==JSON.stringify(freeze(level)))
      throw new TypeError('Rhythm ambiguity snapshot disagrees with its retained evidence');
  }
  return freeze({...value,config});
}

export function observeRhythm(bank,{eventTime,availableAt=eventTime,varianceSeconds2,accent=null}) {
  requireModel(bank);
  finite(eventTime,'onset time');finite(availableAt,'availability');finite(varianceSeconds2,'onset variance');
  if(availableAt<eventTime||varianceSeconds2<=0||bank.lastEventAt!==null&&eventTime<=bank.lastEventAt||
    accent!==null&&(!Number.isFinite(accent)||accent<0||accent>1))throw new TypeError('Noncausal or invalid onset; reorder through the observation replay before inference');
  const config=bank.config,revision=bank.revision+1;
  const metrical=accent!==null&&config.accentModel&&(config.accentModel.id==='learned-velocity-v1'||config.meters.length);
  const lastMetricalEvidenceAt=metrical?eventTime:bank.lastMetricalEvidenceAt;
  const onsetGap=bank.lastEventAt!==null&&eventTime-bank.lastEventAt>config.staleAfterSeconds;
  const recentOnsets=[...(onsetGap?[]:bank.recentOnsets),{eventTime,varianceSeconds2,...(accent===null?{}:{accent})}].slice(-2*config.changeAfter-1);
  if(!bank.candidates.length)return freeze({...bank,revision,lastEventAt:eventTime,lastAvailableAt:availableAt,lastAcceptedAt:eventTime,
    recentOnsets,lastMetricalEvidenceAt,candidates:seeds(config,eventTime,config.periodsSeconds,revision).map(c=>({...c,logWeight:c.logLikelihood}))});
  const event={eventTime,availableAt,varianceSeconds2,accent};
  let parents=bank.candidates;
  if(bank.revision===1){
    // The first interval supplies tentative tempo seeds, never a declared beat.
    const interval=eventTime-bank.lastEventAt,limit=Math.max(1,Math.floor((config.maxCandidates-1)/(config.grids.length*Math.max(1,config.meters.length))));
    const periods=[...new Set([...config.periodsSeconds,interval/2,interval,interval*2])].filter(p=>p>=config.minimumPeriod&&p<=config.maximumPeriod).slice(0,limit);
    parents=seeds(config,bank.lastEventAt,periods,1);
  }
  const candidates=[];let accepted=0;
  for(const parent of parents){
    const next=branches(parent,event,config,revision);
    accepted+=next.filter(c=>c.association!=='clutter').length;
    candidates.push(...next);
  }
  // Surprise: the strongest interpretation could place this onset only as clutter.
  let strongest=candidates[0],strongestScore=score(strongest,config);
  for(let i=1;i<candidates.length;i++){const value=score(candidates[i],config);if(value>strongestScore){strongest=candidates[i];strongestScore=value;}}
  let surpriseRun=accepted&&strongest.association!=='clutter'?0:bank.surpriseRun+1,reinitialized=0,lastReinitialization=bank.lastReinitialization;
  const onsetIntervals=recentOnsets.slice(1).map((onset,i)=>onset.eventTime-recentOnsets[i].eventTime);
  const noise=Math.max(...recentOnsets.map(onset=>onset.varianceSeconds2));
  // A modulated beat is proposed only once the current beat has stopped sounding: its latest beat had no onset.
  const held=bank.level,beatSounded=held?.beatAt!==undefined&&recentOnsets.some(o=>{
    const cycles=(o.eventTime-held.beatAt)/held.periodSeconds,k=Math.round(cycles);
    return eventTime-o.eventTime<held.periodSeconds&&Math.abs(cycles-k)*held.periodSeconds<Math.min(PERSISTENCE_PHASE*held.periodSeconds,PERSISTENCE_SECONDS);});
  const changed=cadenceChange(onsetIntervals,config,noise)??(beatSounded?null:tatumChange(onsetIntervals,config,noise));
  const afterGap=!onsetGap&&['onset-gap','reentry'].includes(lastReinitialization?.reason)&&lastReinitialization.revision===revision-1;
  // With persistence, a return after more than PASSAGE_BEATS of silence that the leading reading cannot place is a new
  // passage, as a long silence is: its onset seeds fresh hypotheses, since the old ones' learned patterns are stale.
  const reentry=config.levelPersistenceRatio>1&&!onsetGap&&bank.level&&eventTime-bank.lastEventAt>PASSAGE_BEATS*bank.level.periodSeconds&&
    strongest.association==='clutter';
  if(surpriseRun>=config.changeAfter||changed||onsetGap||afterGap||reentry){
    const interval=changed?.currentIntervalSeconds??eventTime-bank.lastEventAt;
    const periods=onsetGap?config.periodsSeconds:reentry&&!changed&&!afterGap?[...new Set([bank.level.periodSeconds,...config.periodsSeconds])].slice(0,8):
      (changed?.tatum?[Math.max(1,Math.round((bank.level?.periodSeconds??changed.previousIntervalSeconds)/changed.previousIntervalSeconds))*interval]:
        [interval/2,interval,interval*2]).filter(p=>p>=config.minimumPeriod&&p<=config.maximumPeriod);
    const proposed=changed||afterGap?replaySeeds(config,recentOnsets.slice(-config.changeAfter-1),periods,revision,availableAt):seeds(config,eventTime,periods,revision);
    if(proposed.length){
      // An explicit proposal share of the current beam, independent of the
      // units of its likelihood densities. A search score, not a probability.
      const mass=logSum(candidates.map(c=>score(c,config)))+Math.log(config.reacquisitionShare/(1-config.reacquisitionShare));
      const prior=logSum(proposed.map(c=>score(c,config)));
      candidates.push(...proposed.map(c=>({...c,logLikelihood:c.logLikelihood-prior+mass})));
      reinitialized=1;
      lastReinitialization={revision,eventTime,reason:onsetGap?'onset-gap':afterGap?'post-gap-interval':reentry&&!changed&&surpriseRun<config.changeAfter?'reentry':changed?.tatum?'tatum-change':changed?'coherent-interval-change':'repeated-innovation-rejection',periodSeeds:periods,...changed};
    }
    surpriseRun=0;
  }
  const retained=compact(candidates,config,revision);
  // Keep likelihoods bounded: only differences between hypotheses carry meaning.
  const offset=Math.max(...retained.candidates.map(c=>c.logLikelihood));
  const kept=retained.candidates.map(c=>({...c,logLikelihood:c.logLikelihood-offset}));
  // The reading this onset's level continues: the last level, or after a silence (and at the start) the onset that
  // begins the passage.
  // A silence of more than PASSAGE_BEATS of the level's beats makes this onset an entrance.
  const entrance=onsetGap||bank.level&&eventTime-bank.lastEventAt>PASSAGE_BEATS*bank.level.periodSeconds;
  const entranceAt=entrance?eventTime:bank.levelPrior?.entranceAt??bank.lastEventAt;
  // A reported level becomes the reading to continue only while its hypothesis explains the onsets.
  const levelPrior=entrance?{beatAt:eventTime,periodSeconds:null,entranceAt}:bank.level?.beatAt!==undefined&&bank.level.explaining?
    {beatAt:bank.level.beatAt,periodSeconds:bank.level.periodSeconds,entranceAt,confirmation:bank.level.confirmation??0}:bank.levelPrior?{...bank.levelPrior,entranceAt}:
    {beatAt:entranceAt,periodSeconds:null,entranceAt};
  const levelChallengeBefore=entrance?null:bank.levelChallenge??null;
  const {familyWeight,supported,level,levelAmbiguity,challenge:levelChallenge}=assess(kept,config,eventTime,levelPrior,levelChallengeBefore,recentOnsets.map(o=>o.eventTime),bank.fit);
  // How well the leading interpretation fits recent onsets: the share it could place
  // only as clutter, and its timing surprise (NIS) where it placed them. Running
  // means over about eight onsets; diagnostics beside the status, not evidence. One
  // outlier counts as a 2-sd surprise at most: the mean detects systematic misfit,
  // and occasional extra notes are the clutter share's business.
  const lead=strongestOf(kept),rate=1/8,placed=lead.association!=='clutter'&&lead.lastInnovation!==null;
  // How much the reported level's tempo has wandered over the last `wanderSeconds` (8) of onsets: the RMS of each period's
  // log against the current one, octaves taken out, so a change of level is not counted as wander. A performer who keeps a
  // tempo (to a click, or a drummer's own) wanders a little; rubato and free singing wander far more, and following them
  // misleads (the expressive-following development: research/kalman-integration.md). Only a listening that sets
  // `trackingFit.maxWander` holds back while it exceeds it; otherwise it is a diagnostic.
  const window=config.trackingFit.wanderSeconds??8,levelPeriods=[...(bank.levelPeriods??[]),...(level.periodSeconds>0?[{at:eventTime,period:level.periodSeconds}]:[])]
    .filter(entry=>entry.at>=eventTime-window).slice(-256);
  const folded=level.periodSeconds>0?levelPeriods.map(entry=>{const octaves=Math.log2(entry.period/level.periodSeconds);return (octaves-Math.round(octaves))*Math.LN2}):[];
  const fit={clutter:bank.fit.clutter+rate*(Number(!placed)-bank.fit.clutter),
    innovation:placed?bank.fit.innovation+rate*(Math.min(lead.lastInnovation,4)-bank.fit.innovation):bank.fit.innovation,
    wander:folded.length>4?Math.sqrt(folded.reduce((sum,value)=>sum+value*value,0)/folded.length):null};
  // A hedge that has not taken the lead leaves the established interpretation standing.
  const renewed=reinitialized&&strongestOf(kept).seedRevision===revision;
  const steady=config.trackingFit.maxWander===undefined||fit.wander!==null&&fit.wander<=config.trackingFit.maxWander;
  const fits=fit.clutter<=config.trackingFit.maxClutter&&fit.innovation<=config.trackingFit.maxInnovation&&level.evidence>=config.trackingFit.minEvidence&&steady;
  const status=renewed?'reacquiring':revision<config.minimumOnsets?'initializing':familyWeight>=config.trackingWeight&&supported&&fits?'tracking':'ambiguous';
  return freeze({...bank,revision,candidates:kept,recentOnsets,lastReinitialization,lastEventAt:eventTime,lastAvailableAt:availableAt,
    lastAcceptedAt:accepted?eventTime:bank.lastAcceptedAt,surpriseRun,status,familyWeight,level,levelPrior,levelChallengeBefore,levelChallenge,fitBefore:bank.fit,fit,levelPeriods,metricalLevelAmbiguous:Boolean(levelAmbiguity),levelAmbiguity,
    lastMetricalEvidenceAt,diagnostics:{generated:candidates.length,pruned:retained.pruned,reinitialized:bank.diagnostics.reinitialized+reinitialized,
      discardedBeamMass:retained.discardedBeamMass}});
}

export function rhythmForecasts(bank,{now,horizonSeconds=1,performanceVarianceSeconds2=0}={}) {
  requireModel(bank);
  finite(now,'forecast time');finite(horizonSeconds,'forecast horizon');
  if(horizonSeconds<0||horizonSeconds>30||bank.lastEventAt!==null&&now<bank.lastEventAt)throw new TypeError('Invalid future rhythm horizon');
  const stale=bank.lastAcceptedAt===null||now-bank.lastAcceptedAt>bank.config.staleAfterSeconds;
  return freeze({modelId:bank.modelId,modelVersion:bank.modelVersion,revision:bank.revision,status:stale?'stale':bank.status,
    calibrationStatus:bank.calibrationStatus,conditionalTimingUncertainty:true,metricalLevelAmbiguous:bank.metricalLevelAmbiguous,
    levelAmbiguity:bank.levelAmbiguity,familyWeight:bank.familyWeight,level:bank.level,fit:bank.fit,referencePulse:bank.config.referencePulse,
    coverage:{periodSeeds:[...new Set(bank.candidates.map(c=>c.seedPeriodSeconds))],configuredPeriodSeeds:bank.config.periodsSeconds,
      lastReinitialization:bank.lastReinitialization,grids:[...new Set(bank.candidates.map(c=>c.grid))].sort((a,b)=>a-b),configuredGrids:bank.config.grids,
      maxGrid:bank.config.maxGrid,meterVocabulary:bank.config.meters.map(m=>m.id),
      levelAliasMatching:{terms:LEVEL_TERMS,relativeTolerance:LEVEL_RATIO_TOLERANCE,supportWindowSeconds:bank.config.staleAfterSeconds,
        usesBeamScores:false,basis:'pulse-salience-of-learned-occurrence',ambiguityRatio:bank.config.levelAmbiguityRatio},
      tactus:bank.config.tactus,retained:bank.candidates.length,budget:bank.config.maxCandidates,pruning:bank.diagnostics},
    // The reported level first, then the beam's own hypotheses at their own beats.
    candidates:[levelForecast(bank,now,horizonSeconds,performanceVarianceSeconds2),...bank.candidates.map(candidate=>{
      const track=candidate.track,target=now+horizonSeconds,position=fraction(track.pulse),at=track.originSeconds+track.state.mean[0];
      const pulse=pulsePosition(Math.max(Math.ceil(position),Math.ceil(position+(target-at)/track.state.mean[1])));
      return {id:candidate.id,meter:candidate.meter,grid:candidate.grid,score:Math.exp(candidate.logWeight),association:candidate.association,
        forecast:{...forecastPulseTrusted(track,pulse,{performanceVarianceSeconds2}),conditionalOn:`candidate:${candidate.id}`}};
    })].filter(Boolean)});
}
