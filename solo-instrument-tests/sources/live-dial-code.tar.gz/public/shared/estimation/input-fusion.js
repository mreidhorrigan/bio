// Following more than one input without counting the same evidence twice (MUSEBOTS_KALMAN_INFLUENCE_IMPLEMENTATION_PLAN.md
// §6.2, "Same evidence is not several votes"; RESEARCH_BACKLOG "P2 — Kalman influence", fusion).
//
// Two levels, as the plan separates them:
// - Observations. Onsets of a common event heard by more than one source (a keyboard's MIDI and a microphone on it, two
//   microphones on one drum) become one onset, placed where the sources' variances put it, under one correlation group.
//   Counted twice, a common onset looks like a second attack, and it misled both trackers in the ablations
//   (experiments/input-influence/ablations.mjs merges onsets heard within 30 ms; that is the rule here).
// - Estimates. Reports from several listeners, each an estimate of the performer's period and beat:
//   - with independent errors (different performers, or sensors known independent): information fusion, which tightens
//     the estimate;
//   - where the cross-correlation is unknown (one performer heard twice, forwarded or overlapping analyses): covariance
//     intersection (Julier and Uhlmann 1997), never tighter than the tighter of the two. It is consistent whatever the
//     correlation, and it claims no precision the evidence cannot support.
//   Estimates of different states (another metrical level, another reference pulse) are not averaged: covariance
//   intersection "cannot reconcile incompatible state definitions" (the plan), so the authoritative one stands.

import {actor} from '../planning-data.js';
import {InputReportClient} from './input-report.js';

const finite=Number.isFinite;
// A role handoff (the rubato report's stage D, §11.4: "A musical handoff can alter this graph while the existing
// conductor remains the sole authority that commits shared changes"): a performer who says they lead is the report that
// stands, and the others' timing is weighed as followers', their variance this many times theirs (ours: a follower counts
// a quarter, so a dense part does not take the lead by its number of onsets). A new leader's claim holds this long before
// the lead passes, and a leader heard from no longer, or never tracking, keeps it this long (ours: hysteresis, so a
// moment's uncertainty does not switch leaders).
export const FUSION_DEFAULTS=Object.freeze({commonEventSeconds:.03,levelTolerance:.03,followerVarianceScale:4,leadHoldSeconds:1,leadGraceSeconds:3});

// Onsets from several sources as one stream. `streams`: {sourceId: [{eventTime, availableAt, varianceSeconds2, id,
// accent?, correlationGroup?}], ...}, each in time order. An onset within `commonEventSeconds` of another source's onset
// is the same event: one onset, at the inverse-variance mean of its sources' times (their errors independent, so its
// variance is the harmonic combination), available when its last source's was, its correlation group naming them all.
// Onsets of one source are never merged with each other: its own chord window has already decided what is one attack.
export function mergeCommonOnsets(streams,{commonEventSeconds=FUSION_DEFAULTS.commonEventSeconds}={}){
  const all=[];
  for(const [source,onsets] of Object.entries(streams))for(const onset of onsets){
    if(!finite(onset.eventTime)||!finite(onset.availableAt)||!(onset.varianceSeconds2>0))throw new TypeError('An onset needs a time, an availability and a positive variance');
    all.push({...onset,source});
  }
  all.sort((a,b)=>a.eventTime-b.eventTime||(a.source<b.source?-1:a.source>b.source?1:0));
  const merged=[];
  for(const onset of all){
    const last=merged.at(-1);
    if(last&&onset.eventTime-last.members.at(-1).eventTime<=commonEventSeconds&&!last.members.some(member=>member.source===onset.source)){last.members.push(onset);continue}
    merged.push({members:[onset]});
  }
  return merged.map(({members})=>{
    const weights=members.map(member=>1/member.varianceSeconds2),total=weights.reduce((sum,weight)=>sum+weight,0);
    const eventTime=members.reduce((sum,member,i)=>sum+weights[i]*member.eventTime,0)/total;
    const accents=members.map(member=>member.accent).filter(finite);
    return Object.freeze({id:members.map(member=>`${member.source}:${member.id}`).join('+'),eventTime,
      availableAt:Math.max(...members.map(member=>member.availableAt)),varianceSeconds2:1/total,
      ...(accents.length?{accent:Math.max(...accents)}:{}),
      correlationGroup:members.length>1?`common:${members.map(member=>`${member.source}:${member.correlationGroup??member.id}`).join('+')}`:members[0].correlationGroup??`${members[0].source}:${members[0].id}`,
      sources:Object.freeze(members.map(member=>member.source))});
  });
}

// Gaussian estimates of one state, each {mean: [..], variance: [..]} with a diagonal covariance (the reports carry no
// cross-terms), fused:
// - 'independent': information fusion, the variances' harmonic combination;
// - 'unknown': covariance intersection, P⁻¹ = Σ ωᵢ Pᵢ⁻¹ with Σ ωᵢ = 1, the weights chosen to minimize the fused
//   covariance's determinant (by coordinate search on the simplex; for two estimates, a golden-section search on ω).
export function fuseEstimates(estimates,{correlation='unknown'}={}){
  if(!Array.isArray(estimates)||!estimates.length)throw new TypeError('Fuse at least one estimate');
  const size=estimates[0].mean.length;
  for(const estimate of estimates)
    if(estimate.mean.length!==size||estimate.variance.length!==size||estimate.mean.some(value=>!finite(value))||estimate.variance.some(value=>!(value>0)))
      throw new TypeError('Estimates of one state need finite means and positive variances of one size');
  if(estimates.length===1)return Object.freeze({mean:[...estimates[0].mean],variance:[...estimates[0].variance],weights:[1],correlation});
  const fuse=weights=>{
    const information=Array.from({length:size},(_,k)=>estimates.reduce((sum,estimate,i)=>sum+weights[i]/estimate.variance[k],0));
    const variance=information.map(value=>1/value);
    const mean=variance.map((v,k)=>v*estimates.reduce((sum,estimate,i)=>sum+weights[i]*estimate.mean[k]/estimate.variance[k],0));
    return {mean,variance};
  };
  if(correlation==='independent'){const result=fuse(estimates.map(()=>1));return Object.freeze({...result,weights:estimates.map(()=>1),correlation})}
  if(correlation!=='unknown')throw new TypeError('Correlation is independent or unknown');
  const determinant=weights=>fuse(weights).variance.reduce((product,value)=>product*value,1);
  let weights=estimates.map(()=>1/estimates.length);
  if(estimates.length===2){
    // Golden-section search on ω in [0, 1]: the determinant is convex in ω for covariance intersection.
    let low=0,high=1;const ratio=(Math.sqrt(5)-1)/2;
    for(let step=0;step<80;step++){
      const a=high-ratio*(high-low),b=low+ratio*(high-low);
      if(determinant([a,1-a])<=determinant([b,1-b]))high=b;else low=a;
    }
    const omega=(low+high)/2,ends=[[1,0],[0,1],[omega,1-omega]];
    weights=ends.reduce((best,candidate)=>determinant(candidate)<determinant(best)?candidate:best);
  }else{
    for(let pass=0;pass<40;pass++)for(let i=0;i<weights.length;i++)for(let j=0;j<weights.length;j++){
      if(i===j)continue;
      for(const shift of [.1,.01,.001]){
        const moved=[...weights];const amount=Math.min(shift,moved[j]);moved[i]+=amount;moved[j]-=amount;
        if(amount>0&&determinant(moved)<determinant(weights))weights=moved;
      }
    }
  }
  return Object.freeze({...fuse(weights),weights,correlation});
}

// Whether two reports estimate one state: the same reference pulse, and periods within the level tolerance.
function sameState(a,b,tolerance){
  const pulse=report=>report?.timing?.referencePulse,left=pulse(a),right=pulse(b);
  if(!left||!right||left.numerator!==right.numerator||left.denominator!==right.denominator)return false;
  return Math.abs(a.timing.periodSeconds/b.timing.periodSeconds-1)<=tolerance;
}
// The report that stands where estimates cannot be fused: tracking, then the least uncertain period, then the freshest.
function authoritative(reports){
  const rank=report=>[report.timing?.state==='tracking'?0:1,report.timing?.variance??Infinity,report.timing?.ageSeconds??Infinity];
  return [...reports].sort((a,b)=>{const x=rank(a),y=rank(b);for(let i=0;i<x.length;i++)if(x[i]!==y[i])return x[i]-y[i];return 0})[0];
}

// Several listeners' reports of performers as one report the conductor can follow (tempo-influence.js reads the timing
// and the phase). `correlationOf(a, b)`: 'independent' or 'unknown' for a pair; by default, reports of one performer
// (the same performerId, or none declared) share their events and are 'unknown', and reports of different performers
// are 'independent'. Where the tracking reports do not all estimate one state, or a period's variance is not given, the
// authoritative report stands alone: nothing is averaged that cannot be fused.
// `leader` (a source id): the performer leading now (FusedInputClient decides who, from what each says); where their
// report is in the pool it stands, and the others' variances are scaled by `followerVarianceScale` before they are fused.
export function fuseTimingReports(reports,{correlationOf=defaultCorrelation,levelTolerance=FUSION_DEFAULTS.levelTolerance,
  leader=null,followerVarianceScale=FUSION_DEFAULTS.followerVarianceScale}={}){
  const usable=reports.filter(report=>report?.coverage==='complete'&&report.timing&&finite(report.timing.periodSeconds));
  if(!usable.length)return null;
  const tracking=usable.filter(report=>report.timing.state==='tracking'),pool=tracking.length?tracking:usable;
  const led=leader===null?null:pool.find(report=>sourceOf(report)===leader)??null,lead=led??authoritative(pool);
  // A follower's timing counts for less: its variance scaled (its phase's too), the leader's as it is.
  const weighed=report=>!led||report===led?report:Object.freeze({...report,timing:Object.freeze({...report.timing,variance:report.timing.variance*followerVarianceScale}),
    ...(report.phase?{phase:Object.freeze({...report.phase,varianceSeconds2:report.phase.varianceSeconds2*followerVarianceScale})}:{})});
  const fusable=pool.filter(report=>sameState(report,lead,levelTolerance)&&report.timing.variance>0).map(weighed);
  const agreeing=pool.every(report=>sameState(report,lead,levelTolerance));
  const leading=led?{led:sourceOf(led)}:{};
  if(fusable.length<2||!agreeing||!(lead.timing.variance>0))
    return Object.freeze({...lead,fusion:Object.freeze({method:'authoritative',sources:pool.map(sourceOf),standing:sourceOf(lead),...leading,
      reason:!agreeing?'the reports estimate different states (another level or reference pulse)':'a period without a stated variance cannot be fused'})});
  const pairs=[];for(let i=0;i<fusable.length;i++)for(let j=i+1;j<fusable.length;j++)pairs.push(correlationOf(fusable[i],fusable[j]));
  const correlation=pairs.every(value=>value==='independent')?'independent':'unknown';
  const period=fuseEstimates(fusable.map(report=>({mean:[report.timing.periodSeconds],variance:[report.timing.variance]})),{correlation});
  const phased=fusable.filter(report=>report.phase&&finite(report.phase.beatAt)&&report.phase.varianceSeconds2>0);
  // Beats are aligned to the lead's before they are averaged: the nearest of each report's beats, a period apart.
  const phase=phased.length>=2?fuseEstimates(phased.map(report=>{
    const beatAt=report.phase.beatAt+Math.round(((lead.phase?.beatAt??phased[0].phase.beatAt)-report.phase.beatAt)/period.mean[0])*period.mean[0];
    return {mean:[beatAt],variance:[report.phase.varianceSeconds2]};
  }),{correlation}):null;
  return Object.freeze({...lead,
    timing:Object.freeze({...lead.timing,periodSeconds:period.mean[0],variance:period.variance[0],
      ageSeconds:Math.min(...fusable.map(report=>report.timing.ageSeconds??Infinity))}),
    ...(phase?{phase:Object.freeze({...lead.phase??phased[0].phase,beatAt:phase.mean[0],varianceSeconds2:phase.variance[0],periodSeconds:period.mean[0]})}:{}),
    fusion:Object.freeze({method:correlation==='independent'?'information':'covariance-intersection',sources:fusable.map(sourceOf),
      weights:Object.freeze([...period.weights]),standing:sourceOf(lead),...leading})});
}
// Who leads, from what each performer says (report.timing.leading): the handoff's state machine, with its hysteresis
// (FUSION_DEFAULTS). `heard`: each source's latest report and when it was heard, [{report, heardAt}]; `state`: {leader,
// claim: {source, since}}; returns the next state. A leader who says they do not lead gives it up, and one not heard
// from for leadGraceSeconds loses it. One claimant, with no leader still claiming, takes the lead once their claim has
// held leadHoldSeconds (the handoff: one says false, the next true). Two or more claiming at once leave it where it is
// (`contested`). The conductor this informs stays the only authority that commits anything.
export function nextLeader(state,heard,now,{leadHoldSeconds=FUSION_DEFAULTS.leadHoldSeconds,leadGraceSeconds=FUSION_DEFAULTS.leadGraceSeconds}={}){
  const latest=new Map(heard.filter(entry=>entry?.report).map(entry=>[sourceOf(entry.report),entry]));
  const says=source=>latest.get(source)?.report?.timing?.leading;
  let leader=state?.leader??null;
  if(leader!==null&&(says(leader)===false||!(now-(latest.get(leader)?.heardAt??-Infinity)<=leadGraceSeconds)))leader=null;
  const leaderClaims=leader!==null&&says(leader)===true;
  const claimants=[...latest.keys()].filter(source=>source!==leader&&says(source)===true);
  let claim=null;
  if(claimants.length===1&&!leaderClaims){
    claim=state?.claim?.source===claimants[0]?state.claim:{source:claimants[0],since:now};
    if(now-claim.since>=leadHoldSeconds){leader=claim.source;claim=null}
  }
  return Object.freeze({leader,claim:claim&&Object.freeze(claim),contested:claimants.length>1||claimants.length===1&&leaderClaims});
}

const sourceOf=report=>report?.publisher?.id??report?.sourceId??null;
function defaultCorrelation(a,b){
  const performer=report=>report?.performerId??null,left=performer(a),right=performer(b);
  return left!==null&&right!==null&&left!==right?'independent':'unknown';
}

// A conductor's input made of several sources (tempo-influence.js reads one client): each source is queried and
// answered as its own InputReportClient would be, and the report the conductor follows is their fusion
// (fuseTimingReports). The fused source is named for its members.
export class FusedInputClient {
  constructor({identity,sources,send,now,fusion={}}){
    if(!Array.isArray(sources)||sources.length<2)throw new TypeError('A fused input needs two sources or more');
    this.members=sources.map(source=>actor(source));
    if(new Set(this.members.map(member=>member.id)).size!==this.members.length)throw new TypeError('A fused input\'s sources must differ');
    this.clients=this.members.map(source=>new InputReportClient({identity,source,send,now}));
    this.source=actor({id:`fused:${this.members.map(member=>member.id).join('/')}`.slice(0,256),incarnation:'fused'});
    this.identity=identity;this.send=send;this.now=now;this.fusion=fusion;this.latest=null;
    this.lead=Object.freeze({leader:null,claim:null,contested:false});
  }
  query(){let asked=false;for(const client of this.clients)asked=client.query()||asked;return asked}
  receive(message){
    const client=this.clients.find(candidate=>candidate.receive(message));
    if(!client)return false;
    const answered=this.clients.filter(candidate=>candidate.latest),reports=answered.map(candidate=>candidate.latest.report).filter(Boolean);
    // Who leads now, from what the performers say (a role handoff), then their reports fused under that lead.
    this.lead=nextLeader(this.lead,answered.map(candidate=>({report:candidate.latest.report,heardAt:candidate.latest.receivedAt})),this.now(),this.fusion);
    const report=fuseTimingReports(reports,{...this.fusion,leader:this.lead.leader});
    // Ages are worst-case: the fused report is as old as the oldest request behind it.
    this.latest=Object.freeze({report,sentAt:Math.min(...answered.map(candidate=>candidate.latest.sentAt)),receivedAt:this.now(),requestId:client.latest.requestId,
      timingMeaning:report?.timing?.phase?'durations, and a calibrated beat phase in session seconds, fused across sources':'durations only, fused across sources'});
    return true;
  }
  snapshot(){
    const latest=this.latest,now=this.now();
    if(!latest||!finite(now))return null;
    const elapsed=Math.max(0,now-latest.sentAt),report=latest.report;
    return Object.freeze({...latest,timingAgeSeconds:report?.timing?.ageSeconds==null?null:report.timing.ageSeconds+elapsed,
      pitchAgeSeconds:report?.pitchAgeSeconds==null?null:report.pitchAgeSeconds+elapsed,stale:now-latest.receivedAt>3});
  }
}
