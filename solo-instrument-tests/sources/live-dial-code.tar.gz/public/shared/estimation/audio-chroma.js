// Harmonic evidence from audio: a declared 12-class chroma projection.
//
// The implementation plan (section 5) keeps monophonic pitch following separate
// from polyphonic harmony. It allows "a 12-class chroma view ... for appropriate
// material", which "must remain a declared projection". This is that view. Each
// frame is a spectrum of the most recent samples only, so the evidence is
// causal. Its energy is gathered onto 12-EDO pitch classes against a declared
// reference A, and harmonyProjection() hands the strongest classes to the
// categorical harmony model as weighted pitch material, the same interface MIDI
// uses. A silent frame is no evidence, not a chord.
//
// With `classes` other than 12 (24 for quarter tones), the energy is gathered onto that many classes to the octave,
// class k at k * 12 / classes semitones above C: a projection a levels vocabulary in that tuning can hear
// (harmonic-levels-filter.js chromaEvidence). The chord model below hears twelve classes only.
export const CHROMA_PROJECTION=Object.freeze({id:'chroma-12edo-v1',periodSemitones:12,tuning:'12-equal',
  meaning:'Spectral energy gathered onto 12-EDO pitch classes against a reference A; octave and register are discarded.'});

export class ChromaFrames {
  // smoothing: the share of the previous chroma kept at each frame (an exponential
  // average over frames); 0 is each frame alone. Silence resets it.
  // whiten (opt-in, in development): divide each class by the spectrum's bins that fall to it, so that white noise
  // gives a flat chroma. The bins are linear in frequency and the classes are not: at 48 kHz and 8192 points, B takes
  // 19.2 bins' weight and C-sharp 10.6, and noise, with that tilt, reads as a chord.
  // bass (opt-in, in development): {minHz, maxHz}, a second chroma of twelve classes from the spectrum's bass register
  // (bassChroma, after each chroma()), for a chord model that hears the bass as naming the chord.
  constructor({sampleRate,fftSize=8192,minHz=65,maxHz=2100,referenceHz=440,compression=1,silenceDb=-60,smoothing=0,whiten=false,classes=12,bass=null}={}){
    if(!(sampleRate>=8000&&sampleRate<=192000))throw new RangeError('Invalid chroma sample rate');
    if(!(Number.isInteger(fftSize)&&fftSize>=512&&fftSize<=32768&&!(fftSize&fftSize-1)))throw new RangeError('fftSize must be a power of two from 512 to 32768');
    if(!(minHz>0&&maxHz>minHz&&maxHz<sampleRate/2&&referenceHz>0&&compression>0&&silenceDb<0&&smoothing>=0&&smoothing<1))throw new RangeError('Invalid chroma range, reference, compression or smoothing');
    if(!(Number.isInteger(classes)&&classes>=12&&classes<=120))throw new RangeError('A chroma has from 12 to 120 classes to the octave');
    const n=fftSize,half=n/2,bits=Math.log2(n);
    Object.assign(this,{sampleRate,fftSize,minHz,maxHz,referenceHz,compression,silenceDb,smoothing,whiten,classes,previous:null,real:new Float64Array(n),imag:new Float64Array(n),
      window:new Float64Array(n),reversed:new Uint32Array(n),cos:new Float64Array(half),sin:new Float64Array(half),bins:[]});
    for(let i=0;i<n;i++)this.window[i]=.5-.5*Math.cos(2*Math.PI*i/n);
    for(let i=0;i<n;i++){let r=0;for(let b=0,v=i;b<bits;b++,v>>=1)r=r<<1|v&1;this.reversed[i]=r;}
    for(let i=0;i<half;i++){this.cos[i]=Math.cos(2*Math.PI*i/n);this.sin[i]=Math.sin(2*Math.PI*i/n);}
    // Each bin in range goes to its nearest class, weighted by a raised cosine of
    // its distance from that class's centre (zero half a class off).
    for(let bin=1;bin<half;bin++){
      const hz=bin*sampleRate/n;if(hz<minHz||hz>maxHz)continue;
      const step=(69+12*Math.log2(hz/referenceHz))*classes/12,nearest=Math.round(step),weight=.5+.5*Math.cos(Math.PI*Math.min(1,2*Math.abs(step-nearest)));
      if(weight>1e-6)this.bins.push({bin,pitchClass:((nearest%classes)+classes)%classes,weight});
    }
    this.classWeights=new Float64Array(classes);for(const {pitchClass,weight} of this.bins)this.classWeights[pitchClass]+=weight;
    this.bassChroma=null;this.bassBins=null;
    if(bass){
      if(!(bass.minHz>0&&bass.maxHz>bass.minHz&&bass.maxHz<sampleRate/2))throw new RangeError('Invalid bass range');
      this.bassBins=[];this.previousBass=null;
      for(let bin=1;bin<half;bin++){
        const hz=bin*sampleRate/n;if(hz<bass.minHz||hz>bass.maxHz)continue;
        const step=69+12*Math.log2(hz/referenceHz),nearest=Math.round(step),weight=.5+.5*Math.cos(Math.PI*Math.min(1,2*Math.abs(step-nearest)));
        if(weight>1e-6)this.bassBins.push({bin,pitchClass:((nearest%12)+12)%12,weight});
      }
    }
  }
  // The chroma of the latest fftSize samples: `classes` values summing to 1, or null for a silent frame.
  chroma(samples){
    const {fftSize:n,real,imag,window,reversed,cos,sin}=this;
    if(!samples||samples.length!==n)throw new RangeError(`Expected ${n} samples`);
    let energy=0;
    for(let i=0;i<n;i++){const value=samples[i];energy+=value*value;real[reversed[i]]=value*window[i];imag[i]=0;}
    if(10*Math.log10(energy/n+1e-30)<this.silenceDb){this.previous=null;this.bassChroma=null;this.previousBass=null;return null;}
    for(let size=2;size<=n;size*=2){
      const half=size/2,step=n/size;
      for(let start=0;start<n;start+=size)for(let k=0;k<half;k++){
        const c=cos[k*step],s=sin[k*step],a=start+k,b=a+half,re=real[b]*c+imag[b]*s,im=imag[b]*c-real[b]*s;
        real[b]=real[a]-re;imag[b]=imag[a]-im;real[a]+=re;imag[a]+=im;
      }
    }
    const classes=this.classes,chroma=new Float64Array(classes);
    for(const {bin,pitchClass,weight} of this.bins)chroma[pitchClass]+=weight*Math.hypot(real[bin],imag[bin])**this.compression;
    if(this.bassBins){
      const bass=new Float64Array(12);for(const {bin,pitchClass,weight} of this.bassBins)bass[pitchClass]+=weight*Math.hypot(real[bin],imag[bin])**this.compression;
      const sum=bass.reduce((a,b)=>a+b,0);
      if(sum>0){for(let i=0;i<12;i++)bass[i]/=sum;if(this.previousBass&&this.smoothing>0)for(let i=0;i<12;i++)bass[i]=this.smoothing*this.previousBass[i]+(1-this.smoothing)*bass[i];this.previousBass=bass;this.bassChroma=bass;}
      else{this.previousBass=null;this.bassChroma=null;}
    }
    if(this.whiten)for(let i=0;i<classes;i++)chroma[i]/=this.classWeights[i]||1;
    const total=chroma.reduce((sum,value)=>sum+value,0);
    if(!(total>0)){this.previous=null;return null;}
    for(let i=0;i<classes;i++)chroma[i]/=total;
    if(this.previous&&this.smoothing>0)for(let i=0;i<classes;i++)chroma[i]=this.smoothing*this.previous[i]+(1-this.smoothing)*chroma[i];
    this.previous=chroma;
    return chroma;
  }
}

// Chroma as pitch material for observeHarmony(): the pitch classes holding at
// least `threshold` of the strongest class's energy, as notes whose strength is
// that share. No chroma (silence) is material with no notes, which the model
// reads as nonchordal, distinct from unknown.
export function harmonyProjection(chroma,{availableAt,threshold=.35,pitchBase=60}={}) {
  if(!Number.isFinite(availableAt))throw new TypeError('A chroma projection needs its availability time');
  const notes=[];
  if(chroma){
    const top=Math.max(...chroma);
    for(let pc=0;pc<12;pc++)if(top>0&&chroma[pc]>=threshold*top)notes.push({pitch:pitchBase+pc,velocity:chroma[pc]/top,gain:1,keyDown:true,pedalHeld:false});
  }
  return {version:1,pitchUnits:'MIDI-note-semitones',availableAt,coverage:'complete',notes,projection:CHROMA_PROJECTION.id};
}

// Which harmony explains a chroma frame: a categorical model for audio, beside
// the MIDI one (harmony-model.js). Chroma always carries overtone energy on the
// fifth and third of every sounding note. So instead of thresholding material,
// each label is scored by how closely the chroma matches its template (cosine
// similarity, scaled by `sharpness`). Labels persist through a categorical
// transition model: the leader stays with probability `stay` per second, and
// changes are shared evenly. This is persistence, not progression prediction
// (plan R07).
//
// The output matches the MIDI model's: status is `interpreted`, `ambiguous`
// (leader's posterior below `confident`), `unknown`, or `nonchordal/no-chord`
// for silence.
// keyPrior (optional): a running key estimate, from chroma averaged over about
// `memorySeconds` and matched to the Krumhansl-Kessler profiles, multiplies the
// prior of that key's diatonic triads by 1 + `strength`. It is causal, and it is
// a tendency, not a veto: a chromatic chord still wins on clear evidence.
const KEY_PROFILES={major:[6.35,2.23,3.48,2.33,4.38,4.09,2.52,5.19,2.39,3.66,2.29,2.88],minor:[6.33,2.68,3.52,5.38,2.60,3.53,2.54,4.75,3.98,2.69,3.34,3.17]};
const DIATONIC={major:[[0,'major'],[2,'minor'],[4,'minor'],[5,'major'],[7,'major'],[9,'minor']],minor:[[0,'minor'],[3,'major'],[5,'minor'],[7,'minor'],[7,'major'],[8,'major'],[10,'major']]};
function estimateKey(profile){
  let best=null;
  for(const mode of ['major','minor'])for(let tonic=0;tonic<12;tonic++){
    const shape=KEY_PROFILES[mode],mean=shape.reduce((a,b)=>a+b,0)/12,pm=profile.reduce((a,b)=>a+b,0)/12;let num=0,da=0,db=0;
    for(let i=0;i<12;i++){const a=profile[(tonic+i)%12]-pm,b=shape[i]-mean;num+=a*b;da+=a*a;db+=b*b;}
    const r=da&&db?num/Math.sqrt(da*db):0;if(!best||r>best.r)best={tonic,mode,r};
  }
  return best;
}
// noChord (optional, in development): a hypothesis of no chord, N, whose template is the flat chroma of white noise
// (with a whitened chroma, ChromaFrames whiten), weighed against every chord as they are weighed against each other,
// its evidence scaled by `weight`. It is the standard no-chord class of chord recognition. Where it leads with
// confidence, the status is 'nonchordal/no-chord' (reason 'noise'), which a harmony follower does not announce, and
// its posterior is how little harmonic structure the model hears: noise obliges no one to follow it.
// metricalPrior (optional, in development): changes are likelier just after the performer's beats, where chords
// change (every GuitarSet comping change is on a downbeat), and less likely between them, where a passing voicing
// makes the model flicker. Mauch and Dixon (2010) estimate chords with their metrical position; here, causally, the
// chance of a change in a frame is multiplied by `onBeat` while the frame's evidence (the middle of its window,
// `windowSeconds` long) lies within `window` beats after a beat of the performer's (observeChromaChord's `beat`, the
// listener's forecast), and by `offBeat` elsewhere. Without a beat, the model is as before.
export const NO_CHORD='N';
// bass (optional, in development): the bass heard as naming the chord (the user: "the bass note is usually perceived as
// carrying the most harmonic information, even in contrapuntal (intensively voice-leading) textures"). Each chord is
// scored also by how its bass template (its root most, `third` and `fifth` nearly as much: an inversion) matches the bass
// register's chroma (observeChromaChord's `bass`), `weight` times as much as the chroma's match: Mauch and Dixon's
// (2010) bass given the chord, as a second cosine. Without a bass chroma, the model is as before.
// Every number the model is given must be a finite one: an infinite sharpness or a NaN stay made every posterior NaN
// (the mathematical audit's E01). Its templates are twelve pitch classes, so a label's classes are whole numbers from
// 0 to 11; a vocabulary in another tuning is heard by a levels vocabulary (harmonic-levels.js), not here.
const finite=Number.isFinite;
export function createChromaChordModel({vocabulary,stayPerSecond=.9,sharpness=12,confident=.5,maximumCandidates=8,keyPrior=null,metricalPrior=null,noChord=null,bass=null}={}) {
  if(!vocabulary?.labels?.length||!(finite(stayPerSecond)&&stayPerSecond>0&&stayPerSecond<1)||!(finite(sharpness)&&sharpness>0)||
    !(finite(confident)&&confident>0&&confident<1)||!(Number.isInteger(maximumCandidates)&&maximumCandidates>=1)||
    keyPrior&&!(finite(keyPrior.strength)&&keyPrior.strength>=0&&finite(keyPrior.memorySeconds)&&keyPrior.memorySeconds>0)||
    metricalPrior&&!([metricalPrior.onBeat,metricalPrior.offBeat,metricalPrior.window,metricalPrior.windowSeconds].every(finite)&&
      metricalPrior.onBeat>0&&metricalPrior.offBeat>0&&metricalPrior.window>0&&metricalPrior.window<1&&metricalPrior.windowSeconds>=0)||
    noChord&&!(finite(noChord.weight)&&noChord.weight>0)||bass&&!(finite(bass.weight)&&bass.weight>=0&&
      (bass.third===undefined||finite(bass.third)&&bass.third>=0)&&(bass.fifth===undefined||finite(bass.fifth)&&bass.fifth>=0)))
    throw new TypeError('Invalid chroma chord model');
  if(vocabulary.labels.some(label=>label.id===NO_CHORD))throw new TypeError(`A vocabulary label cannot be ${NO_CHORD}, the no-chord hypothesis`);
  if(vocabulary.labels.some(label=>!Array.isArray(label.pitchClasses)||!label.pitchClasses.length||
    label.pitchClasses.some(pc=>!Number.isInteger(pc)||pc<0||pc>11)))
    throw new TypeError('A chroma chord label is one or more of the twelve pitch classes, 0 to 11');
  const labels=vocabulary.labels.map(label=>{const template=new Float64Array(12);for(const pc of label.pitchClasses)template[pc]=1;
    const norm=Math.hypot(...template);return {id:label.id,template:template.map(v=>v/norm)};});
  if(noChord)labels.push({id:NO_CHORD,template:new Float64Array(12).fill(1/Math.sqrt(12)),scale:noChord.weight});
  // Each label's root and quality, read from its pitch classes, for the key prior.
  const shapes=vocabulary.labels.map(label=>{const set=new Set(label.pitchClasses);
    for(const root of set){if(set.has((root+4)%12)&&set.has((root+7)%12))return {root,quality:'major'};if(set.has((root+3)%12)&&set.has((root+7)%12))return {root,quality:'minor'};}
    return null;});
  // Each label's bass template: its root, and less its third and fifth; no chord's is flat.
  const bassShape={third:.7,fifth:.6,...(bass??{})};
  labels.forEach((label,i)=>{
    const template=new Float64Array(12),shape=shapes[i];
    if(shape){template[shape.root]=1;template[(shape.root+(shape.quality==='minor'?3:4))%12]=bassShape.third;template[(shape.root+7)%12]=bassShape.fifth;}
    else template.fill(1);
    const norm=Math.hypot(...template);label.bassTemplate=template.map(v=>v/norm);
  });
  // at: the latest frame's time, silent or not; posteriorAt: the time the posterior stands for, the last frame heard.
  return {modelId:'chroma-chord-persistence-v1',vocabularyId:vocabulary.vocabularyId,labels,shapes,config:{stayPerSecond,sharpness,confident,maximumCandidates,keyPrior,metricalPrior,noChord,bass},
    posterior:labels.map(()=>1/labels.length),at:null,posteriorAt:null,status:'unknown',reason:'no-evidence',candidates:[],longChroma:null,key:null};
}
// **Persistence over time, as a continuous-time process** (the mathematical audit's E02). A label persists, and a change
// goes to any other label alike, so the posterior relaxes toward uniform: p(t) = u + m^t (p(0) - u), where
// m = (n stayPerSecond - 1)/(n - 1) makes stayPerSecond what it always meant, the chance of the same label a second
// later from certainty, and ten one-second steps are one ten-second step. The old s^t I + (1 - s^t)(J - I)/(n - 1) is
// not: from [.9, .1] with neutral evidence, one ten-second step gave [.379, .621], reversing the favoured label, where
// ten one-second steps gave [.543, .457]. Where stayPerSecond is 1/n or less, no such process keeps it (it would have to
// oscillate), and the posterior resets fully. One label persists as itself. `exposure` is the interval's seconds, each
// weighed by the metrical prior's chance of change there.
function persisting(n,stayPerSecond,exposure){
  if(n<2||!(exposure>0))return 1;
  const m=(n*stayPerSecond-1)/(n-1);
  return m>0?Math.pow(m,exposure):0;
}
// The seconds from `from` to `to`, each weighed by the metrical prior: `onBeat` within `window` of a beat after the
// performer's beats (the evidence of a frame lying windowSeconds/2 before its time), `offBeat` elsewhere, integrated over
// the interval rather than read at its end, so that the chance of change composes as time does.
function metricalExposure(metrical,beat,from,to){
  const period=beat.periodSeconds,shift=metrical.windowSeconds/2,unit=time=>(time-shift-beat.expectedTime)/period;
  const onBeatUnits=u=>Math.floor(u)*metrical.window+Math.min(u-Math.floor(u),metrical.window);
  const on=(onBeatUnits(unit(to))-onBeatUnits(unit(from)))*period;
  return metrical.offBeat*(to-from)+(metrical.onBeat-metrical.offBeat)*on;
}
// A chroma of more than twelve classes, folded to twelve: each class to its nearest semitone, a class between two shared.
export function foldChroma(chroma){
  if(!chroma||chroma.length===12)return chroma;
  const folded=new Float64Array(12),per=chroma.length/12;
  for(let k=0;k<chroma.length;k++){const at=k/per,low=Math.floor(at+1e-9),share=at-low;
    if(share<1e-9)folded[low%12]+=chroma[k];else if(Math.abs(share-.5)<1e-9){folded[low%12]+=chroma[k]/2;folded[(low+1)%12]+=chroma[k]/2;}else folded[Math.round(at)%12]+=chroma[k];}
  return folded;
}
export function observeChromaChord(state,chroma,{availableAt,beat=null,bass=null}) {
  if(!Number.isFinite(availableAt)||state.at!==null&&availableAt<state.at)throw new TypeError('Chroma chord evidence must arrive in order');
  chroma=foldChroma(chroma);
  const {labels,config}=state;
  // Silence moves the time on but not the posterior, which still stands for its own time: the next frame heard
  // relaxes it over the whole interval, silence included (as the MIDI model's unchanged polls, the audit's E03).
  if(!chroma)return {...state,at:availableAt,status:'nonchordal/no-chord',reason:'silence',candidates:[]};
  const posteriorAt=state.posteriorAt??state.at;
  // The same frame heard again is not new evidence: its likelihood was already counted (the audit's E04).
  if(posteriorAt!==null&&availableAt===posteriorAt)return {...state,at:availableAt};
  const dt=state.at===null?1:Math.max(0,availableAt-state.at),n=labels.length,metrical=config.metricalPrior,
    from=posteriorAt===null?availableAt:posteriorAt,
    exposure=metrical&&Number.isFinite(beat?.expectedTime)&&beat?.periodSeconds>0?metricalExposure(metrical,beat,from,availableAt):availableAt-from,
    kept=persisting(n,config.stayPerSecond,exposure),uniform=1/n;
  const norm=Math.hypot(...chroma)||1,prior=state.posterior.map(p=>uniform+kept*(p-uniform));
  let longChroma=state.longChroma,key=state.key;
  if(config.keyPrior){
    const keep=state.longChroma?Math.exp(-dt/config.keyPrior.memorySeconds):0;
    longChroma=Array.from({length:12},(_,i)=>keep*(state.longChroma?.[i]??0)+(1-keep)*chroma[i]);
    key=estimateKey(longChroma);
    const diatonic=new Set(DIATONIC[key.mode].map(([step,quality])=>`${(key.tonic+step)%12}:${quality}`));
    for(let i=0;i<n;i++){const shape=state.shapes[i];if(shape&&diatonic.has(`${shape.root}:${shape.quality}`))prior[i]*=1+config.keyPrior.strength;}
  }
  const bassWeight=config.bass&&bass?.length===12?config.bass.weight:0,bassNorm=bassWeight?Math.hypot(...bass)||1:1;
  // Normalized in log space: prior x exp(sharpness x similarity) overflowed at a sharpness of 1000 (the audit's E01).
  const logs=labels.map((label,i)=>{let dot=0,low=0;for(let pc=0;pc<12;pc++){dot+=label.template[pc]*chroma[pc];if(bassWeight)low+=label.bassTemplate[pc]*bass[pc];}
    return Math.log(prior[i])+config.sharpness*(dot/norm+bassWeight*low/bassNorm)+Math.log(label.scale??1);});
  const top=Math.max(...logs);
  // No label possible (every prior zero): nothing is known, which a uniform posterior says.
  if(!Number.isFinite(top))return {...state,posterior:labels.map(()=>uniform),longChroma,key,at:availableAt,posteriorAt:availableAt,status:'unknown',reason:'no-possible-label',candidates:[]};
  const weights=logs.map(log=>Math.exp(log-top)),total=weights.reduce((a,b)=>a+b,0),posterior=weights.map(w=>w/total);
  const ranked=labels.map((label,i)=>({label:label.id,score:posterior[i]})).sort((a,b)=>b.score-a.score||(a.label<b.label?-1:1));
  if(ranked[0].label===NO_CHORD&&ranked[0].score>=config.confident)
    return {...state,posterior,longChroma,key,at:availableAt,posteriorAt:availableAt,status:'nonchordal/no-chord',reason:'noise',noChord:ranked[0].score,candidates:ranked.filter(c=>c.label!==NO_CHORD).slice(0,config.maximumCandidates)};
  const chords=ranked.filter(c=>c.label!==NO_CHORD),status=chords[0].score>=config.confident?'interpreted':'ambiguous';
  return {...state,posterior,longChroma,key,at:availableAt,posteriorAt:availableAt,status,reason:status==='interpreted'?'one-label-dominates':'several-labels-compete',
    ...(config.noChord?{noChord:posterior[labels.length-1]}:{}),candidates:chords.slice(0,config.maximumCandidates)};
}
