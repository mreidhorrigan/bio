// What the rhythm tracker hears, as the rate contract's pulse hypotheses (shared/rate-contract.js; the extreme-aesthetics
// report's §9.4 and E03): the metrical level it reports, the other levels it weighs, and the pulse tracks its beam
// holds, each with its own period, confidence and evidence. A fast surface and a slower anchor stay side by side,
// instead of the strongest standing for all. It is information: nothing here changes a clock (only the conductor's
// declared channels do).
import {pulseHypothesis} from '../rate-contract.js';

// ---- Choices ---------------------------------------------------------------------------------------------------------
// Periods within this ratio of the reported level's are the tactus's; the rest are subdivisions (faster) or accent
// cycles (slower). A beam track holding less than `leastShare` of the beam's weight, or a level weighed at less than
// `leastCertainty`, is left out as noise. Ours.
export const PULSES=Object.freeze({sameRatio:.05,leastShare:.01,leastCertainty:.01});

// rhythmForecasts(bank, {now}) -> [pulseHypothesis]: the reported level first (the tactus, at its certainty), then the
// other metrical levels the tracker weighs (at theirs), then the beam's pulse tracks (at their share of the beam). And,
// where the tracker was told a meter and its leading candidate holds it (`meters`: the bank's config.meters), the bar:
// an accent cycle of the meter's notes at the unit it hears (its level's period over the level's grouping of units), at
// the level's certainty, inferred from the told meter and the measured pulse (RESEARCH_BACKLOG P1, "Extreme meters, made
// perceptible": a large prime's bar, which no regular grouping of the tactus gives). (Not from the forecast's
// quarter-note tempo: blind to which pulse is the notated quarter, a tracker may count its tactus as one.)
export function pulseHypothesesFromForecasts(forecasts,{choices=PULSES,meters=[]}={}){
  const level=forecasts?.level,[reported,...beam]=forecasts?.candidates??[];
  if(!level||!reported)return [];
  const period=level.periodSeconds,role=seconds=>Math.abs(seconds/period-1)<=choices.sameRatio?'tactus':seconds<period?'subdivision':'accent-cycle';
  const clamp=value=>Math.max(0,Math.min(1,value));
  const out=[pulseHypothesis({id:`level:${reported.id}`,periodSeconds:period,confidence:clamp(level.certainty),evidence:'measured',sourceIds:[level.candidateId],role:'tactus'})];
  (level.alternatives??[]).forEach((other,index)=>{
    if(other.periodSeconds>0&&other.certainty>=choices.leastCertainty)
      out.push(pulseHypothesis({id:`level:${reported.id}:alternative-${index}`,periodSeconds:other.periodSeconds,confidence:clamp(other.certainty),evidence:'measured',sourceIds:[level.candidateId],role:role(other.periodSeconds)}));
  });
  const meter=meters.find(item=>item?.id===reported.meter);
  if(Number.isSafeInteger(meter?.numerator)&&level.grouping>0){
    const seconds=meter.numerator*period/level.grouping;
    if(seconds>0)out.push(pulseHypothesis({id:`meter:${meter.id}`,periodSeconds:seconds,confidence:clamp(level.certainty),evidence:'inferred',sourceIds:[level.candidateId],role:'accent-cycle'}));
  }
  const total=beam.reduce((sum,candidate)=>sum+candidate.score,0)||1;
  for(const candidate of beam){
    const seconds=candidate.forecast.periodSeconds,share=candidate.score/total;
    if(seconds>0&&share>=choices.leastShare)out.push(pulseHypothesis({id:`track:${candidate.id}`,periodSeconds:seconds,confidence:share,evidence:'measured',sourceIds:[candidate.id],role:role(seconds)}));
  }
  return out;
}
