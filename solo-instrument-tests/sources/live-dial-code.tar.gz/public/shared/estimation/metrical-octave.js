// Metrical octaves: the same pulse heard at twice, four times, half or a
// quarter of its period.
// A tracker that changes metrical level reports the same pulse at twice or half
// its period, almost exactly. The performer has not doubled or halved the tempo.
// So a reading within 6% of an exact octave (x2, x4, x1/2, x1/4) of a reading
// followed recently is folded back to that octave.
//
// The first reading is followed as heard. The room's starting tempo is arbitrary,
// and a performer at half of it is simply slower. A real tempo change is not an
// octave: a performer moving from 120 to 80 or 160 is followed.
//
// A closed-loop render found the need. A drummer's readings moved to the quavers
// and took the ensemble from 96 to the 180-BPM ceiling. Wider rules failed:
// folding everything beyond sqrt 2 of the ensemble's beat would not follow a
// deliberate 120-to-80, and folding within sqrt 2 of the last reading let one odd
// reading set the level.
export const OCTAVE_TOLERANCE=.06;
export function foldOctave(period,references,{tolerance=OCTAVE_TOLERANCE}={}) {
  for(const reference of references){
    if(!(period>0)||!(reference>0))continue;
    const octave=Math.round(Math.log2(period/reference));
    if(octave!==0&&Math.abs(octave)<=2&&Math.abs(period/(reference*2**octave)-1)<tolerance)return period/2**octave;
  }
  return period;
}

// A period brought within [shortest, longest] by octaves. The in-range octave nearest `near` (the ensemble's beat)
// wins, so the ensemble moves as little as it can. A period already within is kept.
//
// A level outside the following bounds is still the performer's pulse, an octave or more away. A 12/8 bar at
// 17 BPM is an example. Clamping it to a bound gives a tempo unrelated to the performer's. A render did that: it
// took a band to 60 BPM against a 68-BPM guitarist, and held it there.
export function octaveWithin(period,{shortest,longest,near=null}){
  if(!(period>0)||!(shortest>0)||!(longest>shortest)||period>=shortest&&period<=longest)return period;
  const options=[];for(let k=-8;k<=8;k++){const value=period*2**k;if(value>=shortest&&value<=longest)options.push(value);}
  if(!options.length)return Math.min(longest,Math.max(shortest,period));
  const reference=near>0?near:Math.sqrt(shortest*longest);
  return options.reduce((best,value)=>Math.abs(Math.log(value/reference))<Math.abs(Math.log(best/reference))?value:best);
}

// The spacing of a performer's grid at the ensemble's beat: the ensemble's beat
// when the performer's pulse is an octave (or two) coarser, the performer's pulse
// when it is finer, and null when the two are not an octave apart.
export function gridSpacing(performerPeriod,beatPeriod,{tolerance=OCTAVE_TOLERANCE}={}) {
  if(!(performerPeriod>0)||!(beatPeriod>0))return null;
  const ratio=performerPeriod/beatPeriod,octave=Math.round(Math.log2(ratio));
  if(Math.abs(octave)>2||Math.abs(ratio/2**octave-1)>=tolerance)return null;
  return octave>=0?beatPeriod:performerPeriod;
}

// A band counting a compound meter in its tactus (dotted quarters, three eighths each; meter-tactus.js) hears the
// performer's pulse through that meter. A listener reads a 12/8's eighths grouped in twos, fours or ones as readily as
// in threes: on GuitarSet's 12/8 it chose two eighths, because every grouping of the eighths sounded as reliably and
// its tempo preference favours half a second (research/kalman-integration.md, "Hearing every strum"). A musician told
// "this is a 12/8" hears those eighths in threes. So in such a band a pulse of one, two, four or eight eighths of its
// beat is its tactus: three eighths of the pulse. The tolerance is wide (15%) because the band's tempo is its own
// estimate until it has followed the performer; the octave fold keeps its 6%.
// Returns the tactus the pulse implies, or null when it is not one of those pulses.
export const COMPOUND_TOLERANCE=.15,COMPOUND_EIGHTHS=Object.freeze([1,2,4,8]);
export function compoundTactus(period,beatPeriod,{tolerance=COMPOUND_TOLERANCE}={}) {
  if(!(period>0)||!(beatPeriod>0))return null;
  const eighths=3*period/beatPeriod;
  for(const count of COMPOUND_EIGHTHS)if(Math.abs(eighths/count-1)<tolerance)return 3*period/count;
  return null;
}
// The grid such a band aligns its beat to when the performer's pulse is one of those: the performer's eighth. The
// band's beat keeps the grouping of eighths it has. null otherwise.
export function compoundGrid(performerPeriod,beatPeriod,options) {
  const tactus=compoundTactus(performerPeriod,beatPeriod,options);
  return tactus===null?null:tactus/3;
}
