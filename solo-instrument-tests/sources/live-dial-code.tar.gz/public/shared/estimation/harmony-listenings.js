// How a listener hears harmony, by name, as rhythm listenings are named (listening-options.js). Each says how its chroma
// is made (audio-frame-analysis.js FRAME_CHROMA's fields to change), how its chord model weighs it (audio-chroma.js
// createChromaChordModel), the tunings it can hear, and the data it was fitted to. A listening's data can be swapped,
// and listenings are not reconciled into one: several may be run and compared, as they hear harmony differently.
//
// The first two listenings here are not trained: both are cosine templates of the vocabulary's chords, with a key prior from
// Krumhansl and Kessler's probe-tone profiles (1982). Their few constants were chosen on data, which is said beside them.
// Both hear only 12-equal tuning: their chroma folds the spectrum onto 12 equal classes, and a performer in another
// tuning must not be followed with them.
export const DEFAULT_HARMONY_LISTENING='chroma-templates-v1';

const TEMPLATES_MODEL=Object.freeze({sharpness:25,stayPerSecond:.9,confident:.5,keyPrior:Object.freeze({strength:2,memorySeconds:10})});

export const HARMONY_LISTENINGS=Object.freeze({
  // The listener's chords since the GuitarSet held-out test (private pre-registration, Amendments 9 and 10).
  'chroma-templates-v1':Object.freeze({chroma:Object.freeze({}),model:TEMPLATES_MODEL,tunings:Object.freeze(['12-equal']),
    fittedOn:'GuitarSet v1.1.0 comping and solos, progressions 1 and 2 of each style (development); held out once on progression 3'}),
  // In development: the chroma whitened (each class divided by the spectrum's bins that fall to it), and a no-chord
  // class N whose template is white noise's flat chroma, its evidence weighed at a thousandth of a chord's. Noise,
  // hiss and unpitched sound are heard as no chord, not as a confident one, and the chord model's N posterior says how
  // little harmonic structure it hears. On the default's chroma, N at a thousandth heard no chord in hiss at -50 dBFS,
  // but at a ten-thousandth let three chords through in 18 s; whitened, it let none through at either. On ten GuitarSet
  // development excerpts the band's chord matched the lead sheet 44.0% of the time against the default's 44.8%, and
  // reached a new chord 110 ms sooner.
  'chroma-no-chord-v1':Object.freeze({chroma:Object.freeze({whiten:true}),model:Object.freeze({...TEMPLATES_MODEL,noChord:Object.freeze({weight:1e-3})}),
    tunings:Object.freeze(['12-equal']),
    fittedOn:'as chroma-templates-v1; the no-chord weight on seeded white noise, and checked on ten GuitarSet development comping excerpts (23 September 2026)'}),
  // In development: a learned recognizer (learned-chords.js), madmom's deep chroma and chord CRF, run where the host has
  // it (chord-trackers.js: a render on the desktop, or a desktop page whose VST3 bridge answers). On ten GuitarSet
  // development comping excerpts, decoding each whole take, it matched the lead sheet 75.2% of the time (the templates'
  // model about 60%) and changed chord about as often as the lead sheet. Its data and model are named in
  // render/chords/models.json. `hears` is how a stream of it hears (render/chords/host.py): what it takes the audio it has
  // not heard yet to be, how far behind the audio it answers, and how often.
  // v1 answers each frame once 0.35 s of what follows has sounded, the rest taken as silence: the band reached a new
  // chord in a median 1.1 s.
  'deep-chroma-crf-v1':Object.freeze({learned:Object.freeze({model:'madmom-deepchroma-crf-2016',hears:Object.freeze({future:'silence',lagSeconds:.35,hopSeconds:.25})}),
    tunings:Object.freeze(['12-equal']),
    fittedOn:'madmom\'s deep chroma extractor and chord CRF (Korzeniowski & Widmer 2016): pop and rock chord annotations (Isophonics, RWC Popular, Robbie Williams), not GuitarSet'}),
  // Quarter tones: the chroma in 24 classes (audio-chroma.js), which an orientation in quarter tones hears (the maqam
  // layers: harmony-orientation.js maqam-24-v1); the chord model hears it folded to twelve.
  'chroma-quarter-tones-v1':Object.freeze({chroma:Object.freeze({classes:24}),model:TEMPLATES_MODEL,tunings:Object.freeze(['12-equal','24-equal']),
    fittedOn:'as chroma-templates-v1, its chroma in 24 classes to the octave'}),
  // In development: the bass heard as naming the chord (the user: "the bass note is usually perceived as carrying the
  // most harmonic information"). As chroma-no-chord-v1, from a longer spectrum (16384 points, for the bass's low notes),
  // with a second chroma of the bass register (40 to 200 Hz), and each chord scored also by how the bass fits it: its
  // root most, its third and fifth less (Mauch and Dixon 2010, the bass given the chord). A C major triad held over A in
  // the bass is heard as A minor, over F as F major, over C or E (an inversion) as C major; the default hears C major
  // over every bass.
  'chroma-bass-v1':Object.freeze({chroma:Object.freeze({whiten:true,fftSize:16384,bass:Object.freeze({minHz:40,maxHz:200})}),
    model:Object.freeze({...TEMPLATES_MODEL,noChord:Object.freeze({weight:1e-3}),bass:Object.freeze({weight:.5})}),tunings:Object.freeze(['12-equal']),
    fittedOn:'as chroma-no-chord-v1; the bass weight chosen on synthetic triads held over six basses (development, 24 September 2026)'}),
  // v2 answers each frame as soon as it has sounded, taking what follows to be the latest frame heard (the chord heard
  // last goes on), every 0.1 s. The recognizer's own chord was right 69.5% of the time live against v1's 56.9%, and
  // reached a new chord in a median 0.3 s against 0.84 s (ten development excerpts).
  'deep-chroma-crf-v2':Object.freeze({learned:Object.freeze({model:'madmom-deepchroma-crf-2016',hears:Object.freeze({future:'latest',lagSeconds:0,hopSeconds:.1})}),
    tunings:Object.freeze(['12-equal']),
    fittedOn:'as deep-chroma-crf-v1: madmom\'s models, trained on pop and rock chord annotations (Isophonics, RWC Popular, Robbie Williams), not GuitarSet'}),
});
export const HARMONY_LISTENING_NAMES=Object.freeze(Object.keys(HARMONY_LISTENINGS));
