import {frozenJson,planKey} from '../planning-data.js';
import {overplanKey} from '../overplanning.js';

const freeze=value=>frozenJson(value,{bytes:262144,items:32768}).data;
const last=(values,count)=>values.slice(-count);
const points=['prepareByBeat','windowStartBeat','windowEndBeat','snapshotCloseBeat','selectionByBeat','commitByBeat','startBeat','endBeat'];

export function responseTiming(over,map) {
  return freeze({sessionId:map.sessionId,epoch:map.epoch,tempoId:map.id,tempoRevision:map.revision,
    timeDomain:'local-renderer-reference-seconds',
    points:points.map(name=>({name,beat:over[name],atReference:map.referenceAtBeat(over[name])}))});
}

function inputView(evidence) {
  const report=evidence?.report;
  if(!report)return null;
  return {reportId:report.reportId,sourceId:report.sourceId,sourceIncarnation:report.sourceIncarnation,
    publisher:report.publisher,performerId:report.performerId??null,role:report.role,modality:report.modality,
    coverage:report.coverage,possibleSelfOutput:report.possibleSelfOutput,clock:report.clock,
    timing:report.timing??null,pitches:report.pitches,harmony:report.harmony??null,
    sentAt:evidence.sentAt,receivedAt:evidence.receivedAt,stale:evidence.stale,
    timingAgeSeconds:evidence.timingAgeSeconds,pitchAgeSeconds:evidence.pitchAgeSeconds};
}

// Read-only projection of existing evidence, accepted plans and renderer facts.
// It never queries a source, fuses beliefs, advances a clock or selects a branch.
// Source-local phase stays separate from the local renderer's future lane.
export function responseProfile(bot) {
  const runtime=bot.futurePlanning;
  const decisions=last(bot.decisions,4).filter(value=>value.overplan&&value.timing).map(preparation=>{
    const candidate=runtime?.overplans.get(overplanKey(preparation.overplan));
    // Re-enabling can reuse occurrence names, but never the same clock epoch.
    const record=candidate?.overplan.epoch===preparation.timing.epoch?candidate:null;
    const over=record?.overplan,selection=record?.selection??null;
    const planKeys=new Set(over?.branches.map(branch=>planKey(branch.plan))||[]);
    const facts=record?last(runtime.facts.filter(fact=>fact.type==='recipient'&&planKeys.has(planKey(fact.plan))),32):[];
    const sealed=record?.snapshot;
    const inputs=(sealed?.data.inputs||[]).map(input=>{
      const observation=input.observations.at(-1);
      const evidence=observation?bot.evidence.findLast(value=>value.observationId===observation.observationId&&
        value.epoch===preparation.timing.epoch&&value.overplan&&overplanKey(value.overplan)===overplanKey(preparation.overplan)):null;
      return {name:input.name,state:input.state,reason:input.reason,value:input.value,complete:input.complete,
        observationCount:input.observations.length,observationId:observation?.observationId??null,
        sourceEvidence:inputView(evidence?.evidence)};
    });
    return {id:JSON.stringify([preparation.timing.epoch,overplanKey(preparation.overplan)]),
      overplan:preparation.overplan,mode:preparation.mode,timing:preparation.timing,
      authority:preparation.proposals.period.authorityScope,previousTargets:preparation.previousTargets,
      preparationEvidence:inputView(preparation.preparationEvidence),proposals:preparation.proposals,
      state:record?.state??'outside-retained-runtime',snapshot:sealed?{digest:sealed.digest,inputs}:null,selection,
      alternatives:preparation.alternatives.map(variant=>{
        const branch=over?.branches.find(branch=>branch.id===variant.id),plan=branch&&runtime.records.get(planKey(branch.plan));
        return {id:variant.id,pitches:variant.pitches,state:plan?.state??'unavailable',selected:selection?.branchId===variant.id};
      }),
      // An accepted plan, an audio-queue receipt and a rendered-frame receipt
      // are distinct evidence. No inference from wall time or plan end time.
      facts,rendered: facts.some(fact=>fact.state==='executed'&&fact.executionBoundary==='wasm-rendered-frame'),
      acousticOutputMeasured:false};
  });
  return freeze({version:1,kind:'response-profile',authority:bot.identity??null,enabled:bot.enabled,
    nowReference:runtime?.now()??null,clockEpoch:runtime?.timeline.epoch??null,source:inputView(bot.input?.snapshot()),decisions,
    limitations:{sourcePhaseMapped:false,uncertaintyCalibrated:false,acousticOutputMeasured:false,
      retention:'4 responses; 32 recipient facts per response; older source evidence may be unavailable'}});
}
