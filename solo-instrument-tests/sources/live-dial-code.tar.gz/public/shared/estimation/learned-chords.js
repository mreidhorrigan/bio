// A listener's chords from a learned chord recognizer (render/chords/models.json: madmom's deep chroma and chord CRF,
// Korzeniowski & Widmer 2016): the chord model's state (audio-chroma.js observeChromaChord), made from the recognizer's
// probabilities instead of the chroma templates. The recognizer answers each frame's probabilities for 24 major and
// minor triads and no chord, filtered forward through the transitions it learned, a lag behind the audio; its labels
// are mapped to the vocabulary's by root and quality. A frame whose no-chord probability leads is no chord, as the
// no-chord listening hears noise.
//
// provider: a stream of the recognizer, {append(samples, {frames}) -> {frames: [[seconds, p0 .. p24], ...]} (seconds
// from the stream's start) or a Promise of it, close()}. Synchronous in a render (render/node/chords-host.mjs),
// asynchronous live (bridge-trackers.js).
// hopSeconds and lagSeconds: how often the recognizer answers, and how far behind the audio (a listening sets both:
// harmony-listenings.js). On ten GuitarSet development excerpts: a quarter second each way, filling what had not been
// heard with silence (deep-chroma-crf-v1), right 42.6% of the time and reaching a new chord in 1.12 s; every 0.1 s with
// no lag, taking what follows to be the latest frame (deep-chroma-crf-v2), right 55.3% in 0.84 s. Both change chord
// about as often as the lead sheets do (90 and 97 announcements against 80 changes; the chroma templates 220).
export const LEARNED_CHORDS_DEFAULTS=Object.freeze({hopSeconds:.25,confident:.5,windowSeconds:4,lagSeconds:.35,maximumCandidates:4});

// madmom's labels: A..G# major, then A..G# minor, then N.
const MADMOM_ROOTS=[9,10,11,0,1,2,3,4,5,6,7,8];
export function madmomLabels(vocabulary){
  const byRoot=new Map;
  for(const label of vocabulary.labels){
    const [root,...rest]=label.pitchClasses,intervals=rest.map(pc=>(pc-root+12)%12);
    const quality=intervals.includes(4)&&intervals.includes(7)?'major':intervals.includes(3)&&intervals.includes(7)?'minor':null;
    if(quality&&intervals.length===2)byRoot.set(`${root}:${quality}`,label.id);
  }
  return [...MADMOM_ROOTS.map(root=>byRoot.get(`${root}:major`)??null),...MADMOM_ROOTS.map(root=>byRoot.get(`${root}:minor`)??null),null];
}

export function createLearnedChords({provider,vocabulary,model='madmom-deepchroma-crf-2016',...options}){
  const config={...LEARNED_CHORDS_DEFAULTS,...options},labels=madmomLabels(vocabulary);
  if(!provider)throw new TypeError('Learned chords need the recognizer');
  let origin=null,lastHop=-Infinity,state=null,revision=0,pending=false;
  // The chord model's state from one frame's probabilities, at its time on the listener's clock.
  function frame([seconds,...posterior]){
    const at=origin+seconds,noChord=posterior[24]??0;
    const candidates=posterior.slice(0,24).map((score,i)=>({label:labels[i],score})).filter(c=>c.label).sort((a,b)=>b.score-a.score);
    const status=noChord>=config.confident&&noChord>=candidates[0].score?'nonchordal/no-chord':candidates[0].score>=config.confident?'interpreted':'ambiguous';
    revision++;
    state={model,revision,at,status,reason:status==='interpreted'?'one-label-dominates':status==='ambiguous'?'several-labels-compete':'no-chord',noChord,
      vocabularyId:vocabulary.vocabularyId,candidates:candidates.slice(0,config.maximumCandidates)};
  }
  return {
    hear(samples,{start,end}){
      origin??=start;
      const due=end-lastHop>=config.hopSeconds-1e-9&&!pending;
      const answer=provider.append(samples,{frames:due});
      if(!due)return;
      lastHop=end;
      if(answer&&typeof answer.then==='function'){pending=true;answer.then(result=>{pending=false;for(const value of result?.frames??[])frame(value)},()=>{pending=false})}
      else for(const value of answer?.frames??[])frame(value);
    },
    // The latest frame's chords, or null before the first.
    state:()=>state,
    close(){provider.close?.()},
  };
}
