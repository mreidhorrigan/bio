import {yinFixedDifferences} from './yin-correlation.js';
// A monophonic pitch, frame by frame, and the notes of a line from those frames.
//
// yinPitch is YIN (de Cheveigné & Kawahara 2002): the cumulative-mean-normalized difference function of the frame, its
// first dip below a threshold (the period, before its multiples), refined by a parabola. It runs on the frame decimated
// by `decimate` (averaged, a box low-pass), so that it costs little in a browser: a 2048-sample frame at 48 kHz is 512
// samples at 12 kHz, and 60 Hz to 1.2 kHz is lags of 10 to 200 samples. Its clarity (one less the dip's depth) says how
// periodic the frame is: a tone near 1, noise and chords far below, silence nothing.
//
// A NoteTracker makes notes of pitched frames: a note begins where a clear pitch holds for `stableFrames` frames (or an
// attack re-strikes the pitch), and ends where the pitch goes unclear for `releaseFrames` frames or moves by more than
// `changeSemitones`. Pitch is kept fractional: a performer's microtones are notes of their own
// (harmony-hears-microtunings).
export const YIN_DEFAULTS=Object.freeze({minHz:60,maxHz:1200,threshold:.15,decimate:4,silenceRms:.002});

export function yinPitch(samples,sampleRate,options={}){
  const {minHz,maxHz,threshold,decimate,silenceRms}={...YIN_DEFAULTS,...options};
  const d=Math.max(1,Math.floor(decimate)),n=Math.floor(samples.length/d),x=new Float32Array(n);
  let energy=0;
  for(let i=0;i<n;i++){let sum=0;for(let k=0;k<d;k++)sum+=samples[i*d+k];x[i]=sum/d;energy+=x[i]*x[i];}
  const rms=Math.sqrt(energy/Math.max(1,n)),rate=sampleRate/d;
  if(!(rms>silenceRms))return {hz:null,midi:null,clarity:0,rms};
  // Every lag to tauMax + 1 (the parabola's right neighbour) over the same window.
  const tauMin=Math.max(2,Math.floor(rate/maxHz)),tauMax=Math.min(Math.floor(n/2)-1,Math.ceil(rate/minHz)),width=n-tauMax-1;
  if(tauMax<=tauMin+2||width<tauMax/2)return {hz:null,midi:null,clarity:0,rms};
  const method=options.differenceMethod??'direct';if(!['direct','fft'].includes(method))throw new TypeError('Unknown YIN difference method');
  const differences=method==='fft'?yinFixedDifferences(x,width,tauMax+1,{maxTransform:options.maxTransform}).differences:null;
  const normalized=new Float64Array(tauMax+2);normalized[0]=1;let running=0;
  for(let tau=1;tau<=tauMax+1;tau++){
    let sum=differences?.[tau]??0;if(!differences)for(let j=0;j<width;j++){const v=x[j]-x[j+tau];sum+=v*v;}
    running+=sum;normalized[tau]=running>0?sum*tau/running:1;
  }
  // The first dip below the threshold, then the bottom of it; else the deepest dip, reported as unclear.
  let tau=-1;
  for(let t=tauMin;t<=tauMax;t++)if(normalized[t]<threshold){while(t+1<=tauMax&&normalized[t+1]<normalized[t])t++;tau=t;break;}
  if(tau<0){tau=tauMin;for(let t=tauMin;t<=tauMax;t++)if(normalized[t]<normalized[tau])tau=t;}
  const a=normalized[tau-1],b=normalized[tau],c=normalized[tau+1]??b,den=a-2*b+c,shift=den>0?Math.max(-1,Math.min(1,.5*(a-c)/den)):0;
  const hz=rate/(tau+shift);
  return {hz,midi:69+12*Math.log2(hz/440),clarity:Math.max(0,Math.min(1,1-b)),rms};
}

export const NOTE_DEFAULTS=Object.freeze({clarity:.8,stableFrames:2,releaseFrames:2,changeSemitones:.6});
// The lower max heap and upper min heap keep the upper middle at upper[0].
// The heaps retain every pitch; the public pitch array remains for compatibility.
// Storage is O(T), and each accepted frame takes O(log T) heap work.
class UpperMedian {
  constructor(values=[]){this.lower=[];this.upper=[];for(const x of values)this.add(x);}
  push(heap,x,sign){let i=heap.length;heap.push(x);while(i){const p=(i-1)>>1;if(sign*heap[p]<=sign*x)break;heap[i]=heap[p];i=p;}heap[i]=x;}
  pop(heap,sign){const result=heap[0],x=heap.pop();if(heap.length){let i=0;while(2*i+1<heap.length){let c=2*i+1;if(c+1<heap.length&&sign*heap[c+1]<sign*heap[c])c++;if(sign*x<=sign*heap[c])break;heap[i]=heap[c];i=c;}heap[i]=x;}return result;}
  add(x){if(!this.upper.length||x>=this.upper[0])this.push(this.upper,x,1);else this.push(this.lower,x,-1);
    if(this.upper.length>this.lower.length+1)this.push(this.lower,this.pop(this.upper,1),-1);
    else if(this.lower.length>this.upper.length)this.push(this.upper,this.pop(this.lower,-1),1);}
  value(){return this.upper[0];}
}
const series=(start,pitches)=>({start,pitches,median:new UpperMedian(pitches)});
const appendPitch=(note,pitch)=>{note.pitches.push(pitch);note.median.add(pitch);};

export class NoteTracker {
  constructor(options={}){this.options={...NOTE_DEFAULTS,...options};this.current=null;this.candidate=null;this.unclear=0;}
  // A frame: {at (seconds), midi, clarity, attack (an attack heard in it)}. Returns {started, ended}: a note begun (with
  // its start and pitch, the median of its frames so far) and one ended ({start, end, midi}), or nulls.
  hear({at,midi,clarity,attack=false}){
    const o=this.options,clear=Number.isFinite(midi)&&clarity>=o.clarity;let started=null,ended=null;
    const end=(boundary=at)=>{if(this.current){ended={start:this.current.start,end:boundary,midi:this.current.median.value()};this.current=null;}};
    if(!clear){this.candidate=null;if(this.current&&++this.unclear>=o.releaseFrames)end();return {started,ended};}
    this.unclear=0;
    if(this.current&&Math.abs(midi-this.current.median.value())<=o.changeSemitones&&!attack){appendPitch(this.current,midi);return {started,ended};}
    // A new pitch (or the same one struck again): held for stableFrames frames, it begins a note where it began.
    if(this.candidate&&Math.abs(midi-this.candidate.median.value())<=o.changeSemitones&&!attack)appendPitch(this.candidate,midi);
    else this.candidate=series(at,[midi]);
    if(this.candidate.pitches.length>=o.stableFrames){
      end(this.candidate.start);this.current=this.candidate;this.candidate=null;
      started={start:this.current.start,midi:this.current.median.value()};
    }
    return {started,ended};
  }
}
