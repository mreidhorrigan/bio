import {fftInPlace} from '../grains/fft.js';
// A wind's sound heard as the one harmonic series that explains its spectrum's peaks: its pitch that series'
// fundamental, read where its upper partials are strong and its fundamental weak, as YIN (pitch-yin.js) does not -- YIN
// read the oboe's C#4, G4, G#4 and C#5 a twelfth or an octave down at its players' mf, each a full harmonic series on its
// note (native/openwind/fingering-map.mjs rehearsed, 2 November 2026; the speaking maps' survey, 4 November). The ear the
// winds' tools and the dial's page share: the fingering map, the neutral-note search, the speaking map's survey, the
// glides' book and the page's reading.
//
// heardAs reads a blow's last samples as a tone, unsteady, a multiphonic, rough or silent: a tone one harmonic series
// that explains SERIES.series of the spectrum's peaks' power, held within SERIES.steady c between two readings
// SERIES.apart s apart; a multiphonic two frequencies not in a simple ratio whose sums and differences explain
// SERIES.lattice of it. seriesPitch reads one stretch's pitch alone.
export const SERIES=Object.freeze({window:16384,reading:8192,apart:.4,floor:-45,peaks:12,cents:30,series:.95,lowest:3,lattice:.9,steady:30,simplest:4,silent:-60});

const cents=(a,b)=>1200*Math.log2(a/b);
// (The spectrum's peaks over a stretch of samples, Hann-windowed: each local maximum within SERIES.floor dB of the
// highest, its frequency drawn between bins by the parabola, those within SERIES.cents/2 of a stronger one one peak with
// it, the SERIES.peaks strongest, by power.)
export function spectralPeaks(w,rate){
  const n=w.length,re=new Float64Array(n),im=new Float64Array(n);
  for(let i=0;i<n;i++)re[i]=w[i]*(.5-.5*Math.cos(2*Math.PI*i/(n-1)));
  fftInPlace(re,im);
  const db=new Float64Array(n/2);for(let k=0;k<n/2;k++)db[k]=10*Math.log10(re[k]*re[k]+im[k]*im[k]+1e-30);
  const top=Math.max(...db.subarray(2)),found=[];
  for(let k=2;k<n/2-1;k++)if(db[k]>top+SERIES.floor&&db[k]>db[k-1]&&db[k]>=db[k+1]){
    const shift=.5*(db[k-1]-db[k+1])/(db[k-1]-2*db[k]+db[k+1]);
    found.push({hz:(k+shift)*rate/n,db:db[k]-.25*(db[k-1]-db[k+1])*shift});
  }
  const kept=[];for(const p of found.sort((a,b)=>b.db-a.db))if(!kept.some(q=>Math.abs(cents(p.hz,q.hz))<=SERIES.cents/2))kept.push(p);
  return kept.slice(0,SERIES.peaks).map(p=>({hz:p.hz,db:p.db,power:10**(p.db/10)}));
}
// (The share of the peaks' power within SERIES.cents of a frequency `on` returns true for.)
const explained=(peaks,on)=>peaks.reduce((a,p)=>a+(on(p.hz)?p.power:0),0)/peaks.reduce((a,p)=>a+p.power,0);
// (The one harmonic series that explains most of the peaks' power -- its fundamental the highest that explains within a
// hundredth of the most -- from each of the strongest four peaks over 1 to 8; a series whose lowest peak is among its
// first SERIES.lowest harmonics, so that two frequencies not in a simple ratio are not read as the far harmonics of a low
// fundamental between them -- or one peak alone where it holds that share of the power, a tone all but a sine.)
export function seriesOf(peaks){
  if(!peaks.length)return {f0:null,share:0};
  const alone=explained(peaks,hz=>hz===peaks[0].hz);
  if(alone>=SERIES.series)return {f0:peaks[0].hz,share:alone};
  const at=(f0,hz)=>{const n=Math.round(hz/f0);return n>=1&&Math.abs(cents(hz,n*f0))<=SERIES.cents?n:0};
  const tried=peaks.slice(0,4).flatMap(p=>Array.from({length:8},(_,j)=>p.hz/(j+1))).filter(f0=>f0>=20)
    .filter(f0=>peaks.some(p=>{const n=at(f0,p.hz);return n>=1&&n<=SERIES.lowest})).map(f0=>({f0,share:explained(peaks,hz=>at(f0,hz)>0)}));
  if(!tried.length)return {f0:null,share:0};
  const most=Math.max(...tried.map(t=>t.share));
  return tried.filter(t=>t.share>=most-.01).sort((a,b)=>b.f0-a.f0)[0];
}
// (Two frequencies among the strongest five peaks, not in a ratio p/q of whole numbers, q to SERIES.simplest, whose sums
// and differences m f1 + n f2 (|m|, |n| to 6) explain most of the peaks' power.)
export function latticeOf(peaks){
  const simple=r=>{for(let q=1;q<=SERIES.simplest;q++){const p=Math.round(r*q);if(p>=1&&Math.abs(cents(r,p/q))<=SERIES.cents)return true}return false};
  let best=null;
  for(let i=0;i<Math.min(5,peaks.length);i++)for(let j=i+1;j<Math.min(5,peaks.length);j++){
    const [f1,f2]=[peaks[i].hz,peaks[j].hz].sort((a,b)=>a-b);if(simple(f2/f1))continue;
    const on=hz=>{for(let m=-6;m<=6;m++)for(let n=-6;n<=6;n++){const f=Math.abs(m*f1+n*f2);if(f>0&&Math.abs(cents(hz,f))<=SERIES.cents)return true}return false};
    const share=explained(peaks,on);if(!best||share>best.share)best={f1,f2,share};
  }
  return best;
}
const levelOf=w=>{let sum=0;for(const v of w)sum+=v*v;const rms=Math.sqrt(sum/Math.max(1,w.length));return rms>0?20*Math.log10(rms):-Infinity};
// One stretch's pitch: its last power-of-two samples, SERIES.reading at most, read as their harmonic series -> {hz (its
// fundamental, null where the series explains under SERIES.series of the peaks' power or the stretch is under `silent`
// dBFS), share, db}.
export function seriesPitch(samples,rate,{silent=SERIES.silent}={}){
  const n=2**Math.floor(Math.log2(Math.min(samples.length,SERIES.reading)));
  const w=samples.subarray(samples.length-n),db=levelOf(w);
  if(!(db>=silent))return {hz:null,share:0,db};
  const got=seriesOf(spectralPeaks(w,rate));
  return {hz:got.share>=SERIES.series?got.f0:null,share:got.share,db};
}
// A blow's last samples heard: {as: 'silent' | 'tone' | 'unsteady' | 'multiphonic' | 'rough', db, hz (its series'
// fundamental over its last SERIES.reading samples), early (the same SERIES.apart s before), its share there (series),
// f1, f2 and their share (the lattice, over its last SERIES.window), peaks}.
export function heardAs(samples,rate,{silent=SERIES.silent}={}){
  const end=samples.length,ago=Math.round(SERIES.apart*rate),late=samples.subarray(end-SERIES.reading),early=samples.subarray(end-SERIES.reading-ago,end-ago);
  const db=levelOf(late);
  if(!(db>=silent))return {as:'silent',db:+db.toFixed(1)};
  const [a,b]=[early,late].map(w=>seriesOf(spectralPeaks(w,rate))),peaks=spectralPeaks(samples.subarray(end-SERIES.window),rate);
  const out={db:+db.toFixed(1),hz:b.f0&&+b.f0.toFixed(2),early:a.f0&&+a.f0.toFixed(2),series:+b.share.toFixed(3),peaks:peaks.slice(0,6).map(p=>[+p.hz.toFixed(1),+p.db.toFixed(1)])};
  if(b.share>=SERIES.series)return {as:a.share>=SERIES.series&&Math.abs(cents(a.f0,b.f0))<=SERIES.steady?'tone':'unsteady',...out};
  const lattice=latticeOf(peaks);
  if(lattice&&lattice.share>=SERIES.lattice)return {as:'multiphonic',...out,hz:null,f1:+lattice.f1.toFixed(2),f2:+lattice.f2.toFixed(2),lattice:+lattice.share.toFixed(3)};
  return {as:'rough',...out,hz:null};
}
