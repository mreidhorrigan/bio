import {validateTimedPlan,planReference,planKey,planAuthor,actor,actorKey,sameActor,frozenJson,number} from '../planning-data.js';
import {validatePlan,validatePlanResponse} from '../planning.js';

// A read-only view of the ensemble's plans, built from broadcasts every
// participant already receives. Two protocols share the address:
//   ordinary plans (version 1): what every musical bot proposes for coming
//     phrases -- mh_PlexBOT's form and metre, a drummer's rhythm -- with each
//     other bot's disposition (accept, transform, counter, defer, decline or abstain);
//   timed plans (version 2): the shared-clip scheduler's plans, each recipient's
//     reported state, the selector's final commit and any cancellation.
// It authorizes, prepares and executes nothing. Claims are kept only from the
// actor entitled to make them, so a forged response or status cannot appear here
// as another bot's fact.
export const PLAN_LEDGER_LIMITS=Object.freeze({plans:64,statusesPerPlan:16,retentionSeconds:120,payloadBytes:8192,snapshotBytes:196608});
const RECIPIENT_STATES=Object.freeze(['received','waiting','prepared','accepted','admitting','scheduled','executed','completed','expired',
  'cancelling','cancelled','degraded']);
const originOf=message=>actor({id:message.source,incarnation:message.sourceIncarnation});
const freeze=value=>frozenJson(value,{bytes:262144,items:32768}).data;

export class PlanLedger {
  constructor({now=()=>performance.now()/1000,limits=PLAN_LEDGER_LIMITS}={}){
    this.now=now;this.limits=limits;this.plans=new Map();this.counts={received:0,rejected:0,conflicts:0,evicted:0,expired:0};
  }
  receive(message){
    const value=message?.args?.[0];
    if(!['/broadcast/plan','/broadcast/plan/response','/broadcast/plan/status','/broadcast/plan/commit','/broadcast/plan/cancel'].includes(message?.address))return false;
    if(value?.version===undefined||value?.version===1){
      if(message.address==='/broadcast/plan')return this.guard(()=>this.ordinary(value,message));
      if(message.address==='/broadcast/plan/response')return this.guard(()=>this.disposition(value,message));
      return false;
    }
    if(value?.version!==2)return false;
    try{
      const origin=originOf(message);this.expire();
      const accepted=message.address==='/broadcast/plan'?this.plan(value,origin):message.address==='/broadcast/plan/status'?this.status(value,origin):
        message.address==='/broadcast/plan/commit'?this.final(value,origin):this.cancel(value,origin);
      if(accepted)this.counts.received++;
      return accepted;
    }catch{this.counts.rejected++;return false;}
  }
  guard(action){
    try{this.expire();const accepted=action();if(accepted)this.counts.received++;return accepted;}catch{this.counts.rejected++;return false;}
  }
  // How far the bus vouches for the name an ordinary plan or response claims
  // ('mh_PlexBOT:1'). A networked room stamps the instance itself, and a render
  // names the track ('bot:plex:1') beside the agent, so the instance is exact. A
  // plain local room stamps only the agent ('mh_PlexBOT'): an instance of it is
  // then the bot's own claim, and is recorded as vouched for by agent only.
  static attestation(message,claimed){
    const source=String(message?.source??''),claim=String(claimed??''),key=typeof message?.bot==='string'?message.bot.split(':').slice(2).join(':'):'';
    if(!source||!claim)return null;
    if(claim===source||key&&claim===`${source}:${key}`)return 'instance';
    return !key&&!source.includes('::')&&claim.startsWith(`${source}:`)&&!claim.slice(source.length+1).includes('::')?'agent':null;
  }
  ordinary(input,message){
    const plan=validatePlan(input),attested=PlanLedger.attestation(message,plan.author);
    if(!attested)throw new Error('An ordinary plan comes from its author');
    const key=`ordinary:${plan.planId}@${plan.revision}`,json=frozenJson(plan),old=this.plans.get(key),now=this.now();
    if(old){if(old.canonical!==json.canonical){this.counts.conflicts++;return false;}old.lastSeenAt=now;return true;}
    this.makeRoom();
    const payload=json.bytes<=this.limits.payloadBytes?plan.payload:{omittedBytes:json.bytes};
    this.plans.set(key,{canonical:json.canonical,firstSeenAt:now,lastSeenAt:now,statuses:new Map(),final:null,cancel:null,protocol:'ordinary',
      plan:{protocol:'ordinary',planId:plan.planId,author:plan.author,attested,revision:plan.revision,kind:plan.kind,createdAt:plan.createdAt,appliesAt:plan.appliesAt,
        expiresAt:plan.expiresAt,horizon:plan.horizon,parents:plan.parents.length,confidence:plan.confidence,priority:plan.priority,rationale:plan.rationale,payload,
        startBeat:null}});
    return true;
  }
  disposition(input,message){
    const response=validatePlanResponse(input),attested=PlanLedger.attestation(message,response.responder);
    if(!attested)throw new Error('A response comes from its responder');
    const record=this.plans.get(`ordinary:${response.planId}@${response.planRevision}`);
    if(!record)return false;
    const previous=record.statuses.get(response.responder);
    if(previous&&response.revision<=previous.revision)return response.revision===previous.revision&&response.disposition===previous.disposition;
    if(!previous&&record.statuses.size>=this.limits.statusesPerPlan)return false;
    record.statuses.set(response.responder,{responder:response.responder,attested,disposition:response.disposition,revision:response.revision,
      createdAt:response.createdAt,rationale:response.rationale.slice(0,256)});
    record.lastSeenAt=this.now();return true;
  }
  makeRoom(){
    if(this.plans.size<this.limits.plans)return;
    const [oldest]=[...this.plans.entries()].sort((a,b)=>a[1].lastSeenAt-b[1].lastSeenAt);this.plans.delete(oldest[0]);this.counts.evicted++;
  }
  plan(input,origin){
    const plan=validateTimedPlan(input),key=planKey(plan),json=frozenJson(plan);
    if(!sameActor(planAuthor(plan),origin))throw new Error('A plan comes from its author');
    const old=this.plans.get(key);
    if(old){if(old.canonical!==json.canonical){this.counts.conflicts++;return false;}old.lastSeenAt=this.now();return true;}
    this.makeRoom(); // the least recently heard plan makes room
    const now=this.now();
    this.plans.set(key,{canonical:json.canonical,firstSeenAt:now,lastSeenAt:now,statuses:new Map(),final:null,cancel:null,
      plan:{protocol:'timed',author:plan.author,authorIncarnation:plan.authorIncarnation,planId:plan.planId,revision:plan.revision,occurrenceId:plan.occurrenceId,
        kind:plan.kind,sessionId:plan.sessionId,epoch:plan.epoch,tempoId:plan.tempoId,tempoRevision:plan.tempoRevision,
        startBeat:plan.startBeat,endBeat:plan.endBeat,prepareByBeat:plan.prepareByBeat,commitByBeat:plan.commitByBeat,
        scope:{mode:plan.scope.mode,participants:plan.scope.participants.map(p=>({id:p.id,incarnation:p.incarnation}))},
        selector:plan.selector,delegated:plan.delegated,dependencies:plan.dependencies.length,decision:plan.decision??null,
        contentFormat:plan.content.format,rationale:plan.rationale}});
    return true;
  }
  record(reference){return this.plans.get(planKey(planReference(reference)));}
  status(input,origin){
    const value=freeze(input),recipient=actor(value.recipient),record=this.record(value.plan);
    if(!record||!sameActor(recipient,origin)||!record.plan.scope.participants.some(p=>sameActor(p,recipient))||
      !RECIPIENT_STATES.includes(value.state))return false;
    number(value.sequence,'recipient status sequence',{min:1,integer:true});
    const key=actorKey(recipient),previous=record.statuses.get(key);
    if(previous&&value.sequence<=previous.sequence)return value.sequence===previous.sequence&&value.state===previous.state;
    if(!previous&&record.statuses.size>=this.limits.statusesPerPlan)return false;
    record.statuses.set(key,{recipient,state:value.state,sequence:value.sequence,atReference:Number.isFinite(value.atReference)?value.atReference:null,
      ...(typeof value.reason==='string'?{reason:value.reason.slice(0,256)}:{})});
    record.lastSeenAt=this.now();return true;
  }
  final(input,origin){
    const value=freeze(input),record=this.record(value.plan);
    if(value.kind!=='plan-commit'||!record||!sameActor(actor(value.selector),origin)||!sameActor(record.plan.selector,origin))return false;
    if(record.final&&JSON.stringify(record.final)!==JSON.stringify(value)){this.counts.conflicts++;return false;}
    record.final=value;record.lastSeenAt=this.now();return true;
  }
  cancel(input,origin){
    const value=freeze(input),record=this.record(value.plan);
    if(value.kind!=='plan-cancel'||!record||!(sameActor(origin,{id:record.plan.author,incarnation:record.plan.authorIncarnation})||sameActor(origin,record.plan.selector)))return false;
    number(value.atBeat,'cancellation beat',{min:0,max:record.plan.endBeat});
    record.cancel={atBeat:value.atBeat,by:origin};record.lastSeenAt=this.now();return true;
  }
  expire(){
    const cutoff=this.now()-this.limits.retentionSeconds;
    for(const [key,record]of this.plans)if(record.lastSeenAt<cutoff){this.plans.delete(key);this.counts.expired++;}
  }
  // A whole ensemble's traffic can retain more than one snapshot should carry.
  // The most recently heard plans are shown first within the byte budget: a
  // plan's payload goes before the plan does, and whatever is left out is counted.
  snapshot(){
    this.expire();
    const bytes=value=>new TextEncoder().encode(JSON.stringify(value)).length,budget=this.limits.snapshotBytes??PLAN_LEDGER_LIMITS.snapshotBytes;
    const shown=[];let used=0,omittedPlans=0,omittedPayloads=0;
    for(const record of [...this.plans.values()].sort((a,b)=>b.lastSeenAt-a.lastSeenAt||b.firstSeenAt-a.firstSeenAt)){
      let view={plan:record.plan,statuses:[...record.statuses.values()],final:record.final?{selector:record.final.selector,startBeat:record.final.startBeat??null}:null,
        cancel:record.cancel,firstSeenAt:record.firstSeenAt,lastSeenAt:record.lastSeenAt},size=bytes(view);
      if(used+size>budget&&record.plan.payload&&record.plan.payload.omittedBytes===undefined){
        view={...view,plan:{...view.plan,payload:{omittedBytes:bytes(record.plan.payload)}}};size=bytes(view);omittedPayloads++;
      }
      if(used+size>budget){omittedPlans++;continue;}
      shown.push(view);used+=size;
    }
    return freeze({version:1,kind:'shared-plan-ledger',counts:{...this.counts,retained:this.plans.size,shown:shown.length,omittedPlans,omittedPayloads},limits:this.limits,
      meaning:'Plans as their authors published them, with each other bot\'s disposition (ordinary plans) or reported state (timed plans). Positions are each plan\'s own; nothing here executed anything.',
      plans:shown.sort((a,b)=>(a.plan.startBeat??Infinity)-(b.plan.startBeat??Infinity)||a.firstSeenAt-b.firstSeenAt||a.plan.planId.localeCompare(b.plan.planId))});
  }
}
