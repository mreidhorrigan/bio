// How a band orients to a performer's harmony, level by level: which notes it plays when it is sure of the chord, when
// it is sure only of the scale, and when it is sure of neither. A person accompanying a tune they do not know cannot
// play its next chord before it is played; they can play the scale, and the notes of it that will sound well against
// whatever chord comes.
//
// An orientation is a named listener tendency (the user: "a variety of different listener algorithms with different
// tendencies to support a variety of styles of play"). It chooses a consonance field and how far down it goes:
// - 'sets': chord-scale theory over a levels vocabulary (harmonic-levels.js): each note's expected consonance against
//   the chords to come, in the scale believed; a note is played at `threshold` or more. Unsure of the chord within a
//   key, what survives is a pentatonic.
// - 'spectral': affinity with the harmonic series of the centre and the chords to come (spectral-consonance.js); the
//   `size` strongest notes are played. From the triad to the heptatonic to Barry Harris's eight-note scales.
//
// orient() says, from what is heard, which of four levels the band is at, and what to play there:
// - 'chord': the chord is sure; its tones, and its tensions where the orientation plays them (`tensions`), else graded
//   lower in the weights only;
// - 'hedge': the chord is not sure (the recognizer is between chords, or a change is due); the notes safe against the
//   chords it may be;
// - 'mode': no chord is heard, but scales are (a solo line, a drone); the notes safe against their chords, each scale
//   weighed by how likely it is, so that where two alternate (a minor key's relative major and harmonic minor) the
//   notes they share lead. Within a scale the chords are weighed around its centre, where the centre is heard: the chord
//   on it (`modeChordWeights.tonic`), the one on the degree a fifth above (`.dominant`), the rest (`.other`), as a
//   musician orients to a key by its tonic and dominant;
// - 'none': neither is heard (silence, noise, music in no scale): nothing, and the band keeps its own harmony.
import {TWELVE_TONE_LEVELS,TWELVE_TONE_BEBOP_LEVELS,TWELVE_TONE_BLUES_LEVELS,QUARTER_TONE_MAQAM_LEVELS,expectedConsonance,setHolds} from './harmonic-levels.js';
import {affinityField} from './spectral-consonance.js';

export const LEVELS_VOCABULARIES=Object.freeze(Object.fromEntries([TWELVE_TONE_LEVELS,TWELVE_TONE_BEBOP_LEVELS,TWELVE_TONE_BLUES_LEVELS,QUARTER_TONE_MAQAM_LEVELS].map(v=>[v.vocabularyId,v])));

// sure: the chord's probability at which it is sure. modeSure: the likeliest collection's at which the scale is.
export const HARMONY_ORIENTATIONS=Object.freeze({
  // Conservative: tones and tensions of a sure chord; a pentatonic-like hedge.
  'chord-scale-v1':Object.freeze({field:'sets',vocabulary:'twelve-tone-levels-v1',threshold:.75,sure:.8,modeSure:.6,tensions:false,
    tendency:'chord tones when sure; unsure, the notes safe against every chord it may be: a pentatonic within the key'}),
  // Jazz: the eight-note layer listened for, and a lower threshold, so more of the scale is played.
  'chord-scale-bebop-v1':Object.freeze({field:'sets',vocabulary:'twelve-tone-bebop-levels-v1',layer:'collection',threshold:.6,sure:.8,modeSure:.6,tensions:true,
    tendency:'wider: the whole chord-scale when sure, most of the key when unsure; Barry Harris\'s eight-note scales heard where they sound'}),
  // The blues: the nine-note layer of I7, IV7 and V7 listened for, and chord tones when sure.
  'chord-scale-blues-v1':Object.freeze({field:'sets',vocabulary:'twelve-tone-blues-levels-v1',threshold:.75,sure:.8,modeSure:.6,tensions:false,
    tendency:'a blues: the nine notes of its three dominant chords heard as one scale, and the notes safe against them played'}),
  // Maqam in quarter tones.
  'maqam-24-v1':Object.freeze({field:'sets',vocabulary:'quarter-tone-maqam-levels-v1',threshold:.75,sure:.8,modeSure:.6,tensions:false,
    tendency:'the notes of the maqam heard, with its neutral intervals'}),
  // The harmonic series: a core of five with roughness heard, the heptatonic, the eight-note, and a near-chromatic ten.
  // Its tendency is modal: it hears the fourth above the centre as close kin (as quartal and modal playing do), where
  // chord-scale theory calls it an avoid note over a major chord. So where the chord is sure, the core and the
  // heptatonic play only its tones, and the field shapes their hedges and modes.
  'spectral-core-v1':Object.freeze({field:'spectral',vocabulary:'twelve-tone-levels-v1',tensions:false,size:5,roughnessWeight:.3,sure:.8,modeSure:.6,
    tendency:'modal: the five notes nearest the harmonic series of the centre and chords, their roughness heard (the centre, its fifth and fourth, the chord\'s third)'}),
  'spectral-tonal-v1':Object.freeze({field:'spectral',vocabulary:'twelve-tone-levels-v1',tensions:false,size:7,roughnessWeight:0,sure:.8,modeSure:.6,
    tendency:'the seven notes nearest the harmonic series of the centre and chords; a sure chord\'s tones only'}),
  'spectral-bebop-v1':Object.freeze({field:'spectral',vocabulary:'twelve-tone-levels-v1',tensions:true,size:8,roughnessWeight:0,sure:.8,modeSure:.6,
    tendency:'eight: over a major tonic chord, Barry Harris\'s sixth-diminished scale'}),
  'spectral-chromatic-v1':Object.freeze({field:'spectral',vocabulary:'twelve-tone-levels-v1',tensions:true,size:10,roughnessWeight:0,sure:.8,modeSure:.6,
    tendency:'ten: all but the two notes least like the harmony'}),
});

export function harmonyOrientation(orientation){
  const config=typeof orientation==='string'?HARMONY_ORIENTATIONS[orientation]:orientation;
  if(!config)throw new TypeError(`A harmony orientation is one of ${Object.keys(HARMONY_ORIENTATIONS).join(', ')}, or its settings`);
  const vocabulary=typeof config.vocabulary==='string'?LEVELS_VOCABULARIES[config.vocabulary]:config.vocabulary;
  if(!vocabulary?.layers)throw new TypeError('A harmony orientation names a levels vocabulary');
  if(!['sets','spectral'].includes(config.field))throw new TypeError('A harmony orientation\'s field is sets or spectral');
  return {scaleFloor:.02,noScale:.5,minimumPool:3,certainCore:5,centerSure:.5,modeChordWeights:{tonic:3,dominant:2,other:1},...config,vocabulary,name:typeof orientation==='string'?orientation:config.name??'custom'};
}

// The chords a collection holds, from a chord vocabulary: [{label, pitchClasses}].
export function chordsInCollection(orientationConfig,collection,chordVocabulary){
  return chordVocabulary.labels.filter(label=>setHolds(orientationConfig.vocabulary,collection,label.pitchClasses));
}

// The level and the notes to play. `levels` is a levels filter's report (harmonic-levels-filter.js levelsReport), or
// null; `chords` the chord distribution to come, [{label, pitchClasses, probability}] (empty where no chord is heard);
// `chordVocabulary` the chord model's vocabulary, for the chords of the scale when no chord is heard.
// Returns {level, pool: pitch classes strongest first, weights: [{pc, weight}] over the vocabulary's grid, sure, scale}.
// `chords` carry their absolute probabilities, and whatever they leave out is mass omitted, not mass absent: a recognizer
// that keeps its four strongest of twenty-four chords made a chord at .35 among the rest at .65/23 sure at .805 once
// those four were renormalized (the mathematical audit's I09). Top-K is a presentation budget, not evidence. So whether
// to follow the leader is decided against `chordMass`, the probability of all the chords the model holds (1 less its
// no-chord probability; 1 where not given). The notes' field is still weighed among the chords given, conditionally on
// them.
export function orient(config,{levels=null,chords=[],chordVocabulary=null,chordMass=null}={}){
  const vocabulary=config.vocabulary,layerId=config.layer??vocabulary.layers.find(layer=>layer.sets.some(set=>set.chromatic))?.id??vocabulary.layers[0].id;
  const layer=levels?.layers.find(entry=>entry.id===layerId)??null,top=layer?.top[0]??null;
  const collection=top?vocabulary.layers.find(l=>l.id===layerId).sets.find(set=>set.id===top.id):null;
  const scaleSure=Boolean(collection&&!collection.chromatic&&top.probability>=config.modeSure);
  const total=chords.reduce((sum,chord)=>sum+chord.probability,0),leader=chords.reduce((best,chord)=>!best||chord.probability>best.probability?chord:best,null);
  const mass=Math.max(total,Number.isFinite(chordMass)&&chordMass>0?chordMass:1);
  let level,distribution;
  if(leader&&total>0&&leader.probability/mass>=config.sure){level='chord';distribution=chords;}
  else if(leader&&total>0){level='hedge';distribution=chords;}
  else if(layer&&chordVocabulary){
    // No chord heard: the chords of the scales believed, each scale's belief shared among its chords. Music heard in no
    // scale (the chromatic set likelier than `noScale`) gives nothing.
    const sets=vocabulary.layers.find(l=>l.id===layerId).sets,chromatic=sets.find(set=>set.chromatic);
    const likely=sets.filter(set=>!set.chromatic&&(layer.beliefs[set.id]??0)>=config.scaleFloor);
    // Oriented once a core of `certainCore` notes is certain (held by every likely scale): at least a pentatonic's worth.
    if((chromatic?layer.beliefs[chromatic.id]??0:0)>=config.noScale||!likely.length||(layer.certain?.length??0)<config.certainCore)level='none';
    else{
      const weights=new Map,center=levels?.center&&levels.center.probability>=config.centerSure?levels.center.pc:null,period=vocabulary.periodSemitones;
      const near=(a,b)=>Math.abs(((a-b)%period+period+period/2)%period-period/2)<=vocabulary.toleranceSemitones;
      const role=label=>center===null?1:near(label.pitchClasses[0],center)?config.modeChordWeights.tonic:near(label.pitchClasses[0],center+7)?config.modeChordWeights.dominant:config.modeChordWeights.other;
      for(const set of likely){const held=chordsInCollection(config,set,chordVocabulary),total=held.reduce((sum,label)=>sum+role(label),0)||1;
        for(const label of held)weights.set(label.id,{label:label.id,pitchClasses:label.pitchClasses,probability:(weights.get(label.id)?.probability??0)+layer.beliefs[set.id]*role(label)/total});}
      distribution=[...weights.values()];level=distribution.length?'mode':'none';
    }
  }else level='none';
  if(level==='none')return {level,pool:[],weights:[],sure:0,scale:scaleSure?collection.id:null};
  if(level==='mode'&&!distribution.length)return {level:'none',pool:[],weights:[],sure:0,scale:null};
  const beliefs=layer?.beliefs??{};
  let field;
  if(config.field==='sets'){
    const {consonance}=expectedConsonance(vocabulary,distribution,beliefs,{layerId,threshold:config.threshold});
    field=consonance.map(({pc,consonance:value})=>({pc,weight:value}));
  }else{
    const center=levels?.center&&scaleSure?[{pc:levels.center.pc,weight:2}]:[];
    const context=[...center,...distribution.flatMap(chord=>chord.pitchClasses.map(pc=>({pc,weight:chord.probability/(total||1)/chord.pitchClasses.length*3})))];
    field=affinityField(context,{grid:vocabulary.grid,periodSemitones:vocabulary.periodSemitones,roughnessWeight:config.roughnessWeight??0}).map(({pc,affinity})=>({pc,weight:affinity}));
  }
  const ranked=[...field].sort((a,b)=>b.weight-a.weight||a.pc-b.pc);
  // At the chord level, the chord's tones lead: they are what the band voices; the field grades the rest.
  let pool=config.field==='sets'?ranked.filter(entry=>entry.weight>=config.threshold).map(entry=>entry.pc):ranked.slice(0,config.size).map(entry=>entry.pc);
  if(level==='chord'){const tones=leader.pitchClasses;pool=config.tensions?[...tones,...pool.filter(pc=>!tones.some(tone=>Math.abs(tone-pc)<1e-6))]:[...tones];}
  // Too few safe notes to orient to: nothing.
  if(level==='mode'&&pool.length<config.minimumPool)return {level:'none',pool:[],weights:[],sure:0,scale:null};
  return {level,pool,weights:field,sure:leader&&total>0?leader.probability/mass:0,
    scale:level==='mode'?[...pool].sort((a,b)=>a-b).join(' '):scaleSure?collection.id:null};
}
