import {correct, predict, filterState, finite, EstimationError} from './linear-filter.js';
import {frozenJson} from '../planning-data.js';

const freeze = value => frozenJson(value, {bytes: 16384, items: 2048}).data;
const requireValue = (condition, code, message) => { if (!condition) throw new EstimationError(code, message); };
const nonnegative = (value, name) => { finite(value, name); requireValue(value >= 0, 'configuration', `${name} must be nonnegative`); return value; };
const positive = (value, name) => { finite(value, name); requireValue(value > 0, 'configuration', `${name} must be positive`); return value; };

export function pulsePosition(numerator, denominator = 1) {
  requireValue(Number.isSafeInteger(numerator) && Number.isSafeInteger(denominator) && denominator > 0 && denominator <= 9600,
    'pulse-unit', 'Pulse positions require a safe rational numerator and denominator in 1..9600');
  let a = Math.abs(numerator), b = denominator;
  while (b) [a, b] = [b, a % b];
  const divisor = a || 1;
  return Object.freeze({numerator: numerator / divisor, denominator: denominator / divisor});
}
function rational(value) { return pulsePosition(value?.numerator, value?.denominator); }
export function pulseDistance(a, b) {
  a = rational(a); b = rational(b);
  return Number(BigInt(a.numerator) * BigInt(b.denominator) - BigInt(b.numerator) * BigInt(a.denominator)) /
    Number(BigInt(a.denominator) * BigInt(b.denominator));
}
function timingConfig(config = {}) {
  const result = {
    // q_d has units seconds² / reference-pulse³, not seconds² / wall second.
    periodWalk: nonnegative(config.periodWalk ?? 1e-6, 'period walk'),
    minimumPeriod: positive(config.minimumPeriod ?? 0.08, 'minimum period'),
    maximumPeriod: positive(config.maximumPeriod ?? 4, 'maximum period'),
    varianceFloor: positive(config.varianceFloor ?? 1e-12, 'onset variance floor'),
    innovationGate: positive(config.innovationGate ?? 25, 'innovation gate'),
    reanchorSeconds: positive(config.reanchorSeconds ?? 3600, 're-anchor interval'),
  };
  requireValue(result.minimumPeriod < result.maximumPeriod, 'configuration', 'Invalid period range');
  return result;
}
function periodValid(period, config) { return Number.isFinite(period) && period >= config.minimumPeriod && period <= config.maximumPeriod; }
export function createPulseState({eventTime = 0, pulse = pulsePosition(0), periodSeconds = 0.5,
  covariance = [[0.0025, 0], [0, 0.01]], referencePulse = pulsePosition(1, 4), config = {}} = {}) {
  const settings = timingConfig(config), unit = rational(referencePulse);
  requireValue(unit.numerator > 0, 'pulse-unit', 'Reference pulse must be a positive whole-note fraction');
  requireValue(periodValid(periodSeconds, settings), 'period-domain', 'Period is outside the declared model range');
  return freeze({modelId: 'pulse-linear-v1', modelVersion: 1, units: ['seconds', 'seconds/reference-pulse'],
    referencePulse: unit, pulse: rational(pulse), originSeconds: finite(eventTime, 'event time'),
    state: filterState({mean: [0, periodSeconds], covariance}), config: settings,
    lastEvidenceAt: null, lastAvailableAt: null, accepted: 0, rejected: 0, status: 'initializing', reanchors: 0});
}
export function restorePulseState(value) {
  requireValue(value?.modelId === 'pulse-linear-v1' && value.modelVersion === 1 &&
    JSON.stringify(value.units) === JSON.stringify(['seconds', 'seconds/reference-pulse']), 'model-schema', 'Unknown pulse model or units');
  const config = timingConfig(value.config), state = filterState(value.state), pulse = rational(value.pulse), referencePulse = rational(value.referencePulse);
  requireValue(state.mean.length === 2 && periodValid(state.mean[1], config) && referencePulse.numerator > 0, 'period-domain', 'Invalid pulse state');
  for (const field of ['accepted', 'rejected', 'reanchors']) requireValue(Number.isSafeInteger(value[field]) && value[field] >= 0, 'model-schema', `Invalid ${field} count`);
  requireValue(['initializing', 'tracking', 'reacquiring', 'stale', 'ambiguous'].includes(value.status), 'model-schema', 'Unknown tracking state');
  for (const field of ['lastEvidenceAt', 'lastAvailableAt']) if (value[field] !== null) finite(value[field], field);
  return freeze({...value, originSeconds: finite(value.originSeconds, 'time origin'), state, config, pulse, referencePulse});
}
export function reanchorPulse(track) {
  track = restorePulseState(track);
  const shift = track.state.mean[0];
  return freeze({...track, originSeconds: track.originSeconds + shift,
    state: filterState({mean: [0, track.state.mean[1]], covariance: track.state.covariance}), reanchors: track.reanchors + 1});
}
export function predictPulse(track, atPulse) {
  track = restorePulseState(track);
  const pulse = rational(atPulse), dq = pulseDistance(pulse, track.pulse);
  requireValue(dq >= 0 && dq <= 1e6, 'time-order', 'Prediction requires a bounded nonnegative pulse interval');
  const q = track.config.periodWalk;
  let result = freeze({...track, pulse, state: predict(track.state, {
    transition: [[1, dq], [0, 1]], processNoise: [[q * dq ** 3 / 3, q * dq ** 2 / 2], [q * dq ** 2 / 2, q * dq]],
  })});
  if (Math.abs(result.state.mean[0]) >= result.config.reanchorSeconds) result = reanchorPulse(result);
  return result;
}
export function observePulse(track, {pulse, eventTime, availableAt = eventTime, varianceSeconds2}) {
  finite(eventTime, 'event time'); finite(availableAt, 'availability time'); nonnegative(varianceSeconds2, 'onset variance');
  requireValue(availableAt >= eventTime, 'causality', 'Onset evidence cannot be available before its event');
  const prior = predictPulse(track, pulse);
  const update = correct(prior.state, {measurement: [eventTime - prior.originSeconds], projection: [[1, 0]],
    measurementNoise: [[varianceSeconds2]], varianceFloors: [prior.config.varianceFloor], gate: prior.config.innovationGate});
  const accepted = update.accepted && periodValid(update.state.mean[1], prior.config);
  // An invalid period is rejected, never silently clamped with unchanged P.
  const reason = update.reason || (accepted ? null : 'period-domain');
  return Object.freeze({accepted, reason, diagnostics: update, track: freeze({...prior,
    state: accepted ? update.state : prior.state,
    lastEvidenceAt: accepted ? eventTime : prior.lastEvidenceAt, lastAvailableAt: accepted ? availableAt : prior.lastAvailableAt,
    accepted: prior.accepted + Number(accepted), rejected: prior.rejected + Number(!accepted),
    status: accepted ? prior.accepted >= 2 ? 'tracking' : 'initializing' : 'reacquiring'})});
}
// For a caller holding a track this module produced (frozen and validated when it
// was made), observePulse's prediction and correction through the same predict and
// correct arithmetic, without re-validating that input or canonicalizing each
// intermediate copy. A beam updating hundreds of branches per onset spends most of
// its time there otherwise. The values are identical; key order is not canonical,
// so the caller canonicalizes what it keeps.
const deepFreeze = value => {
  if (value && typeof value === 'object' && !Object.isFrozen(value)) { Object.freeze(value); for (const key of Object.keys(value)) deepFreeze(value[key]); }
  return value;
};
export function observePulseTrusted(track, {pulse, eventTime, availableAt = eventTime, varianceSeconds2}) {
  requireValue(track?.modelId === 'pulse-linear-v1' && Object.isFrozen(track), 'model-schema', 'A trusted update needs a frozen pulse state');
  finite(eventTime, 'event time'); finite(availableAt, 'availability time'); nonnegative(varianceSeconds2, 'onset variance');
  requireValue(availableAt >= eventTime, 'causality', 'Onset evidence cannot be available before its event');
  const position = rational(pulse), dq = pulseDistance(position, track.pulse);
  requireValue(dq >= 0 && dq <= 1e6, 'time-order', 'Prediction requires a bounded nonnegative pulse interval');
  const q = track.config.periodWalk;
  let prior = {...track, pulse: position, state: predict(track.state, {
    transition: [[1, dq], [0, 1]], processNoise: [[q * dq ** 3 / 3, q * dq ** 2 / 2], [q * dq ** 2 / 2, q * dq]],
  })};
  if (Math.abs(prior.state.mean[0]) >= prior.config.reanchorSeconds) prior = {...prior, originSeconds: prior.originSeconds + prior.state.mean[0],
    state: filterState({mean: [0, prior.state.mean[1]], covariance: prior.state.covariance}), reanchors: prior.reanchors + 1};
  const update = correct(prior.state, {measurement: [eventTime - prior.originSeconds], projection: [[1, 0]],
    measurementNoise: [[varianceSeconds2]], varianceFloors: [prior.config.varianceFloor], gate: prior.config.innovationGate});
  const accepted = update.accepted && periodValid(update.state.mean[1], prior.config);
  const reason = update.reason || (accepted ? null : 'period-domain');
  return Object.freeze({accepted, reason, diagnostics: update, track: deepFreeze({...prior,
    state: accepted ? update.state : prior.state,
    lastEvidenceAt: accepted ? eventTime : prior.lastEvidenceAt, lastAvailableAt: accepted ? availableAt : prior.lastAvailableAt,
    accepted: prior.accepted + Number(accepted), rejected: prior.rejected + Number(!accepted),
    status: accepted ? prior.accepted >= 2 ? 'tracking' : 'initializing' : 'reacquiring'})});
}
const forecastOf = (future, performanceVarianceSeconds2) => ({modelId: future.modelId, pulse: future.pulse, referencePulse: future.referencePulse,
  expectedTime: future.originSeconds + future.state.mean[0], periodSeconds: future.state.mean[1],
  bpm: 60 / future.state.mean[1], bpmUnit: future.referencePulse,
  latentTimeVariance: future.state.covariance[0][0],
  performedTimeVariance: future.state.covariance[0][0] + performanceVarianceSeconds2,
  conditionalOn: 'declared-pulse-association', calibrationStatus: 'uncalibrated',
  lastEvidenceAt: future.lastEvidenceAt, status: future.status});
export function forecastPulse(track, pulse, {performanceVarianceSeconds2 = 0} = {}) {
  nonnegative(performanceVarianceSeconds2, 'performance variance');
  return freeze(forecastOf(predictPulse(track, pulse), performanceVarianceSeconds2));
}
// forecastPulse for a caller holding a track this module produced, as observePulseTrusted is: the same prediction, by the
// same arithmetic, without re-validating the track or canonicalizing the prediction and the forecast on the way. A
// beam forecasts every one of its hypotheses at each reading. The numbers are identical (a re-anchor, which moves the
// origin by the offset, leaves the expected time origin + offset as it was, and is not needed here); the caller
// canonicalizes what it keeps.
export function forecastPulseTrusted(track, pulse, {performanceVarianceSeconds2 = 0} = {}) {
  requireValue(track?.modelId === 'pulse-linear-v1' && Object.isFrozen(track), 'model-schema', 'A trusted forecast needs a frozen pulse state');
  nonnegative(performanceVarianceSeconds2, 'performance variance');
  const position = rational(pulse), dq = pulseDistance(position, track.pulse);
  requireValue(dq >= 0 && dq <= 1e6, 'time-order', 'Prediction requires a bounded nonnegative pulse interval');
  const q = track.config.periodWalk;
  const state = predict(track.state, {transition: [[1, dq], [0, 1]], processNoise: [[q * dq ** 3 / 3, q * dq ** 2 / 2], [q * dq ** 2 / 2, q * dq]]});
  return forecastOf({...track, pulse: position, state}, performanceVarianceSeconds2);
}

export function createScalarState({value, variance, time, units, processVariancePerSecond = 0, varianceFloor = 0}) {
  requireValue(typeof units === 'string' && units.length > 0 && units.length <= 128, 'units', 'Feature units must be explicit');
  nonnegative(variance, 'feature variance'); nonnegative(processVariancePerSecond, 'feature process variance'); nonnegative(varianceFloor, 'feature variance floor');
  return freeze({modelId: 'scalar-walk-v1', modelVersion: 1, units, at: finite(time, 'feature time'),
    state: filterState({mean: [value], covariance: [[variance]]}), processVariancePerSecond, varianceFloor, lastEvidenceAt: null});
}
export function predictScalar(track, time) {
  requireValue(track?.modelId === 'scalar-walk-v1' && track.modelVersion === 1 && track.state?.mean.length === 1, 'model-schema', 'Unknown scalar model');
  requireValue(typeof track.units === 'string' && track.units.length > 0, 'units', 'Feature units must be explicit');
  const dt = finite(time, 'feature time') - finite(track.at, 'feature timestamp');
  nonnegative(dt, 'feature elapsed time'); nonnegative(track.processVariancePerSecond, 'feature process variance');
  nonnegative(track.varianceFloor, 'feature variance floor');
  return freeze({...track, at: time, state: predict(track.state, {transition: [[1]], processNoise: [[track.processVariancePerSecond * dt]]})});
}
export function observeScalar(track, {value, variance, time, units}) {
  requireValue(units === track.units, 'units', 'Feature units do not match the model'); nonnegative(variance, 'feature variance');
  const prior = predictScalar(track, time), update = correct(prior.state, {measurement: [value], projection: [[1]],
    measurementNoise: [[variance]], varianceFloors: [prior.varianceFloor]});
  return Object.freeze({track: freeze({...prior, state: update.state, lastEvidenceAt: value === null ? prior.lastEvidenceAt : time}), diagnostics: update});
}
