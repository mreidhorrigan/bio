import {actor, sameActor, identifier, frozenJson} from '../planning-data.js';
import {randomUUID} from '../random-id.js';
import {POCKET_SECONDS} from './beat-sync.js';
import {LEAN_SHAPES, EXPRESSION_LIMITS} from '../performance-timing.js';

// How closely the performer asks to be followed (the rubato report's stage D, §11): tightly, loosely (their timing
// counts for less), or released from coordination (a cadenza: the band keeps its own time until they return).
export const COORDINATIONS = Object.freeze(['tight', 'loose', 'released']);

const freeze = value => frozenJson(value, {bytes: 8192, items: 1024}).data;
const age = (now, event) => Number.isFinite(event) ? Math.max(0, now - event) : null;

// Compact, read-only evidence. No raw MIDI/audio, permissions or executable
// recipes cross this boundary. A pulse duration can be used without claiming
// that an uncalibrated source's absolute phase is the receiver's clock.
//
// A beat phase is reported only when it can mean something to the receiver: the
// source's clock is mapped to session seconds, and a calibration of the offset
// from ensemble output to this input (a loopback or a tap-along) is bound to it.
// The phase is then the ensemble time the performer's next predicted beat aligns
// with. Otherwise phaseStatus says which is missing.
// A free-performance level whose best beat phase is barely better than the next
// (onsets sounding on and off the beat alike) has no phase to give either.
export const PHASE_STATUSES = Object.freeze(['calibrated', 'unmapped-clock', 'unresolved-latency', 'no-tracking-forecast', 'ambiguous-phase']);
const PHASE_MARGIN = .1;
function beatPhase({timing, domain, calibration, forecast, level}) {
  if (!timing) return {phase: null, phaseStatus: null};
  // A forecast that states its own clock must be in session time too.
  const phaseStatus = domain !== 'session-seconds' || forecast?.clockDomain && forecast.clockDomain !== 'session-seconds' ? 'unmapped-clock' :
    !calibration ? 'unresolved-latency' :
    timing.state !== 'tracking' || !Number.isFinite(forecast?.expectedTime) || !(forecast?.periodSeconds > 0) ? 'no-tracking-forecast' :
    level && !(level.phaseMargin >= PHASE_MARGIN) ? 'ambiguous-phase' : 'calibrated';
  return {phaseStatus, phase: phaseStatus !== 'calibrated' ? null : {beatAt: forecast.expectedTime - calibration.offsetSeconds,
    varianceSeconds2: (forecast.latentTimeVariance ?? 0) + calibration.varianceSeconds2, periodSeconds: forecast.periodSeconds,
    calibrationVersion: calibration.calibrationVersion}};
}
export function inputReport(snapshot, {sourceNow, publisher}) {
  const source = snapshot?.source, binding = source?.binding;
  if (!binding || !Number.isFinite(sourceNow)) return null;
  if (!sameActor(binding.publisher, actor(publisher))) {
    // A stopped/disconnected source may retain its old binding for inspection.
    // The new publisher reports no current input; it must not relabel archived
    // evidence, reopen capture, or let an old query error hide missing coverage.
    if(source.coverage!=='complete')return null;
    throw new Error('Input publisher incarnation changed');
  }
  const complete = source.coverage === 'complete', track = source.timing;
  // Free performance follows the beam's reported level (rhythm-beam-v5). Fresh
  // held-out comparisons under rules fixed beforehand decided it: Groove MIDI
  // drums, ASAP piano and GuitarSet guitar audio (see the Kalman-influence
  // handoff). The pulse follower (PulseCoupler) still runs in the snapshot for
  // comparison, and follows nothing.
  const rhythm = snapshot.rhythm, candidate = rhythm?.candidates?.[0];
  const latest = source.latest, material = snapshot.harmonicMaterial;
  const timingAt = source.lastTimingEvidenceAt ?? track?.lastEvidenceAt ?? latest?.when?.eventEnd ?? null;
  const referencePulse = track?.referencePulse || rhythm?.referencePulse || null;
  const period = track?.state?.mean?.[1] ?? candidate?.forecast?.periodSeconds ?? null;
  const timing = complete && period !== null ? {
    periodSeconds: period, referencePulse, ageSeconds: age(sourceNow, timingAt),
    state: track ? track.accepted >= 3 ? 'tracking' : 'initializing' : rhythm.status,
    variance: track?.state?.covariance?.[1]?.[1] ?? null,
    alternatives: (rhythm?.candidates || []).slice(0, 4).map(value => ({
      periodSeconds: value.forecast.periodSeconds, score: value.score, meter: value.meter,
    })), interpretation: track ? 'declared-pulse-grid' : 'beam-level-follower',
    ...(track ? {} : {ambiguity: {metricalLevelAmbiguous: Boolean(rhythm?.metricalLevelAmbiguous),
      pulseRatio: rhythm?.levelAmbiguity?.pulseRatio ?? null, beamStatus: rhythm?.status ?? null}}),
    // How the performer divides this beat, where the source measures it (ListenerBot, subdivision.js). A calibrated
    // capture in session seconds also gives its recent attacks, latency removed, as its beat phase is: a conductor
    // places them on its own beats.
    ...(snapshot.subdivision ? {subdivision: {parts: snapshot.subdivision.parts, triple: snapshot.subdivision.triple,
      duple: snapshot.subdivision.duple, windowSeconds: snapshot.subdivision.windowSeconds,
      ...(snapshot.calibration && (source.clockDomain || 'source-local-seconds') === 'session-seconds' && Array.isArray(snapshot.subdivision.attacks) ?
        {attacks: snapshot.subdivision.attacks.slice(-32).map(time => time - snapshot.calibration.offsetSeconds),
          ...(Array.isArray(snapshot.subdivision.bass) && snapshot.subdivision.bass.length === snapshot.subdivision.attacks.length ?
            {bass: snapshot.subdivision.bass.slice(-32)} : {})} : {})}} : {}),
    // Where the performer says they sit against the beat (+ behind, seconds), where they have said: a band keeps it
    // rather than correcting it (beat-sync.js, placement.js). And a lean over the phrase they declare (as a render's
    // transport.expression lean: {ms, shape}), and how closely they ask to be followed (COORDINATIONS).
    ...(Number.isFinite(snapshot.placementSeconds) ? {placementSeconds: snapshot.placementSeconds} : {}),
    ...(snapshot.lean ? {lean: {ms: snapshot.lean.ms, shape: snapshot.lean.shape ?? 'arch'}} : {}),
    ...(COORDINATIONS.includes(snapshot.coordination) ? {coordination: snapshot.coordination} : {}),
    // Whether they say they lead the ensemble now (a role handoff, the rubato report's stage D: input-fusion.js), where
    // they have said.
    ...(typeof snapshot.leading === 'boolean' ? {leading: snapshot.leading} : {}),
  } : null;
  const domain = source.clockDomain || 'source-local-seconds';
  const phased = timing ? {...timing, ...beatPhase({timing, domain, calibration: snapshot.calibration ?? null,
    forecast: track ? snapshot.forecast : candidate?.forecast, level: track ? null : rhythm?.level ?? null})} : null;
  const pitches = complete ? material?.notes?.map(note => note.pitch) ||
    (snapshot.audio?.pitchHz ? [69 + 12 * Math.log2(snapshot.audio.pitchHz / 440)] : []) : [];
  const harmony = complete && snapshot.harmony ? {status: snapshot.harmony.status,
    vocabularyId: snapshot.harmony.vocabularyId, tuningId: snapshot.harmony.tuningId,
    candidates: (snapshot.harmony.candidates || []).slice(0, 4)} : null;
  const sequence = material?.revision ?? source.revision ?? rhythm?.revision ?? track?.accepted ?? 0;
  return freeze({version: 1, reportId: `${binding.sourceId}:${binding.sourceIncarnation}:${sequence}`,
    publisher, sourceId: binding.sourceId, sourceIncarnation: binding.sourceIncarnation,
    performerId: binding.performerId, role: binding.role, modality: binding.modality,
    possibleSelfOutput: binding.possibleSelfOutput, coverage: source.coverage, sequence,
    clock: {domain, mappingVersion: binding.clockMappingVersion,
      calibrationStatus: source.calibrationStatus || latest?.when?.calibrationStatus || 'unresolved-latency'},
    timing: phased, pitches: pitches.slice(0, 16), pitchAgeSeconds: material ? material.coverage==='complete'?0:null : age(sourceNow, latest?.when?.eventEnd),
    pitchMeaning: material ? 'active-MIDI-note-intentions' : 'monophonic-acoustic-candidate', harmony,
    evidenceRefs: snapshot.lastObservation ? [snapshot.lastObservation] : latest ?
      [`${binding.sourceId}:${binding.sourceIncarnation}:frame-${latest.sequence}`] : [],
    sourceNow, authority: 'observation-only'});
}

export function serveInputQuery(bot, message, {sourceNow, now = performance.now() / 1000}) {
  if (message.address !== '/agent/estimation/query') return false;
  const query = message.args?.[0];
  if (query?.target !== bot.instanceId || query?.version !== 1 || query.incarnation !== bot.incarnation) return true;
  try {
    identifier(query.requestId); const requester = actor({id: message.source, incarnation: message.sourceIncarnation});
    const key = JSON.stringify(requester); bot.inputQueryTimes ||= new Map();
    if (now - (bot.inputQueryTimes.get(key) ?? -Infinity) < .1) return true;
    bot.inputQueryTimes.set(key, now);
    while (bot.inputQueryTimes.size > 32) bot.inputQueryTimes.delete(bot.inputQueryTimes.keys().next().value);
    const publisher = actor({id: bot.instanceId, incarnation: bot.incarnation});
    const report = inputReport(bot.inputSnapshot(), {sourceNow, publisher});
    bot.lastQueryError = null;
    bot.send('/agent/estimation/response', [freeze({version: 1, target: requester.id,
      requestId: query.requestId, publisher, report})]);
  } catch (error) { bot.lastQueryError = error.message; }
  return true;
}

export class InputReportClient {
  constructor({identity, source, send, now}) {
    this.identity = actor(identity); this.source = actor(source); this.send = send; this.now = now;
    this.requestEpoch = randomUUID(); // A re-enabled consumer must not accept an earlier connection's reply.
    this.pending = new Map(); this.sequence = 0; this.latest = null; this.lastQueryAt = -Infinity;
  }
  query() {
    const now = this.now();
    if (!Number.isFinite(now) || now - this.lastQueryAt < .2) return false;
    // Leave room for replies on a slow link. Evicting a live request every
    // 200 ms otherwise discards it before a valid two-second reply arrives.
    for(const [id,sentAt]of this.pending)if(now-sentAt>3)this.pending.delete(id);
    if(this.pending.size>=8)return false;
    this.lastQueryAt = now;
    const requestId = `evidence:${this.requestEpoch}:${++this.sequence}`;
    this.pending.set(requestId, now);
    this.send('/agent/estimation/query', [{version: 1, target: this.source.id,
      incarnation: this.source.incarnation, requestId}]);
    return true;
  }
  receive(message) {
    if (message.address !== '/agent/estimation/response') return false;
    const value = freeze(message.args?.[0]), now = this.now(), sentAt = this.pending.get(value.requestId);
    if (value.version !== 1 || value.target !== this.identity.id || sentAt === undefined || !Number.isFinite(now) ||
      now < sentAt || now - sentAt > 3 || !sameActor(value.publisher, this.source) ||
      message.source !== this.source.id || message.sourceIncarnation !== this.source.incarnation) return false;
    this.pending.delete(value.requestId);
    if (this.latest && sentAt < this.latest.sentAt) return false;
    const report = value.report;
    if (report && (!sameActor(report.publisher, this.source) || report.version !== 1 || report.authority !== 'observation-only')) return false;
    if (report) {
      identifier(report.reportId); identifier(report.sourceId); identifier(report.sourceIncarnation);
      identifier(report.clock?.mappingVersion);
      if (!Number.isSafeInteger(report.sequence) || report.sequence < 0 || !Number.isFinite(report.sourceNow) ||
        !['midi', 'audio'].includes(report.modality) || !['performer', 'device', 'mixture'].includes(report.role) ||
        !Array.isArray(report.pitches) || report.pitches.length > 16 || report.pitches.some(p => !Number.isFinite(p) || p < 0 || p >= 128) ||
        !['complete', 'partial', 'missing', 'invalid'].includes(report.coverage) || typeof report.possibleSelfOutput !== 'boolean') return false;
      for (const seconds of [report.pitchAgeSeconds, report.timing?.ageSeconds]) if (seconds != null && (!Number.isFinite(seconds) || seconds < 0)) return false;
      const placement = report.timing?.placementSeconds, lean = report.timing?.lean, coordination = report.timing?.coordination;
      if (placement !== undefined && !(Number.isFinite(placement) && Math.abs(placement) <= POCKET_SECONDS)) return false;
      if (lean !== undefined && !(lean && Number.isFinite(lean.ms) && Math.abs(lean.ms) <= EXPRESSION_LIMITS.leanMs && LEAN_SHAPES.includes(lean.shape))) return false;
      if (coordination !== undefined && !COORDINATIONS.includes(coordination)) return false;
      if (report.timing?.leading !== undefined && typeof report.timing.leading !== 'boolean') return false;
      if (report.timing && (!Number.isFinite(report.timing.periodSeconds) || report.timing.periodSeconds <= 0 ||
        !Number.isInteger(report.timing.referencePulse?.numerator) || report.timing.referencePulse.numerator <= 0 ||
        !Number.isInteger(report.timing.referencePulse?.denominator) || report.timing.referencePulse.denominator <= 0)) return false;
      const phase = report.timing?.phase, attacks = report.timing?.subdivision?.attacks;
      if (attacks !== undefined && (!Array.isArray(attacks) || attacks.length > 32 || attacks.some(time => !Number.isFinite(time)))) return false;
      const bass = report.timing?.subdivision?.bass;
      if (bass !== undefined && (!Array.isArray(attacks) || !Array.isArray(bass) || bass.length !== attacks.length || bass.some(value => !Number.isFinite(value) || value < 0))) return false;
      if (report.timing?.phaseStatus != null && !PHASE_STATUSES.includes(report.timing.phaseStatus)) return false;
      if (phase != null) {
        if (report.timing.phaseStatus !== 'calibrated' || report.clock.domain !== 'session-seconds' || !Number.isFinite(phase.beatAt) ||
          !Number.isFinite(phase.varianceSeconds2) || phase.varianceSeconds2 < 0 || !(phase.periodSeconds > 0)) return false;
        identifier(phase.calibrationVersion);
      }
    }
    this.latest = freeze({report, sentAt, receivedAt: now, requestId: value.requestId,
      timingMeaning: report?.timing?.phase ? 'durations, and a calibrated beat phase in session seconds' :
        'durations only; source phase is not mapped to this clock'});
    return true;
  }
  snapshot() {
    const latest = this.latest, now = this.now();
    if (!latest || !Number.isFinite(now)) return null;
    // Worst-case age includes the whole request/response trip, plus source
    // age and time since receipt. This never backdates local availability.
    const elapsed = Math.max(0, now - latest.sentAt), report = latest.report;
    return freeze({...latest, timingAgeSeconds: report?.timing?.ageSeconds == null ? null : report.timing.ageSeconds + elapsed,
      pitchAgeSeconds: report?.pitchAgeSeconds == null ? null : report.pitchAgeSeconds + elapsed,
      stale: now - latest.receivedAt > 3});
  }
}
