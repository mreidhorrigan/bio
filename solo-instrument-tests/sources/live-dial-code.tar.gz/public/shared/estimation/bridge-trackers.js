// The learned beat tracker and chord recognizer for a listener on the desktop (tier 1), through the desktop's VST3
// bridge (render/node/vst3-bridge.mjs), which runs them in their helper processes (render/beats, render/chords). The
// analysis worker (audio-analysis-worker.js) installs these where a learned listening is chosen (beat-trackers.js,
// chord-trackers.js): each stream's audio goes to the bridge as it is heard, and an ask is answered when the model has
// heard it, so the learned pulse and chords follow it asynchronously, a window behind.
//
// url: the bridge (ws://127.0.0.1:8091/vst3 by default, or the page's ?vst3=).

// Whether the bridge answers at url within timeoutMs: a desktop page then hears the beat with the learned tracker.
export function bridgeAnswers(url,timeoutMs=600){
  return new Promise(resolve=>{
    let socket;const done=value=>{clearTimeout(timer);try{socket?.close()}catch{/* closing */}resolve(value)};
    const timer=setTimeout(()=>done(false),timeoutMs);
    try{socket=new WebSocket(url)}catch{done(false);return}
    socket.onopen=()=>done(true);socket.onerror=()=>done(false);
  });
}
export function bridgeTrackers(url){
  let socket=null,opening=null,nextId=1000;const asks=new Map,opened=new Map;
  const connect=()=>opening??=new Promise((resolve,reject)=>{
    socket=new WebSocket(url);socket.binaryType='arraybuffer';
    socket.onopen=()=>resolve(socket);
    socket.onerror=()=>reject(new Error(`No VST3 bridge at ${url}: learned listenings run on the desktop, with npm run vst3-bridge`));
    socket.onmessage=({data})=>{
      if(typeof data!=='string')return;
      const message=JSON.parse(data);
      if(message.op==='opened')opened.get(message.id)?.resolve();
      else if(message.op==='learned')asks.get(message.id)?.shift()?.resolve(message.result);
      else if(message.op==='error'){for(const waiting of asks.get(message.id)??[])waiting.reject(new Error(message.message));asks.set(message.id,[])}
    };
  });
  const stream=kind=>({sampleRate,windowSeconds,lagSeconds,future})=>{
    const id=nextId++;asks.set(id,[]);
    const ready=connect().then(open=>new Promise(resolve=>{opened.set(id,{resolve});
      open.send(JSON.stringify({op:'openLearned',id,kind,sampleRate,...(windowSeconds?{windowSeconds}:{}),...(Number.isFinite(lagSeconds)?{lagSeconds}:{}),...(future?{future}:{})}))}));
    let queue=Promise.resolve();
    return {
      // The audio, in order; with frames, a Promise of the model's answer (learned-pulse.js, learned-chords.js).
      append(samples,{frames=false}={}){
        const buffer=new ArrayBuffer(24+samples.length*4),view=new DataView(buffer);
        view.setUint32(0,id,true);view.setUint32(4,1,true);view.setFloat64(8,0,true);view.setUint32(16,samples.length,true);view.setUint32(20,frames?2:1,true);
        new Float32Array(buffer,24,samples.length).set(samples);
        const answer=frames?new Promise((resolve,reject)=>asks.get(id).push({resolve,reject})):undefined;
        queue=queue.then(()=>ready).then(()=>socket.send(buffer));
        return answer;
      },
      close(){queue.then(()=>ready).then(()=>socket.send(JSON.stringify({op:'close',id}))).catch(()=>{})},
    };
  };
  return {beats:{stream:stream('beats')},chords:{stream:stream('chords')}};
}
