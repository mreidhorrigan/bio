// One capture frame through the production acoustic analysis: features (onset,
// pitch, energy), the occurrence beam, the pulse follower and harmonic material
// (chroma). The browser Worker (audio-analysis-worker.js) and the synchronous
// host capture (host-input-capture.js) both run this, so a live microphone and a
// render's input are heard by the same code.
import {yinPitch} from './pitch-yin.js';
import {AudioFeatureSource} from './audio-features.js';
import {createRhythmBank,observeRhythm,rhythmForecasts} from './rhythm-occurrence.js';
import {createPulseFollower,observePulseFollower,pulseFollowerForecast} from './pulse-following.js';
import {CHROMA_PROJECTION,ChromaFrames} from './audio-chroma.js';
import {HARMONY_LISTENINGS} from './harmony-listenings.js';
import {createLearnedPulse,LEARNED_PULSE_DEFAULTS} from './learned-pulse.js';
import {beatTracker} from './beat-trackers.js';
import {createLearnedChords} from './learned-chords.js';
import {chordTracker} from './chord-trackers.js';
import {TWELVE_TONE_TRIADS} from './harmony-model.js';

// The chroma the GuitarSet held-out test froze for the chord estimator (private
// pre-registration, Amendment 10): 8192-sample spectra up to 800 Hz, smoothed
// over frames. Each frame's chroma is of the latest fftSize samples heard.
export const FRAME_CHROMA=Object.freeze({fftSize:8192,minHz:65,maxHz:800,compression:1,smoothing:.85});

// The listening for audio (bass-accent-v1):
// - the beam learns over a four-second cycle;
// - its tactus preference is centred on 0.5 s and broader than MIDI's;
// - each onset's accent is its bass (lowRise), scored per position class (learned-velocity-v1).
// Low sounds carry the beat (Hove et al. 2014; Lenc et al. 2018). In GuitarSet comping the low strings fall on the
// beat, while bossa chords lean to the "and".
//
// It was chosen on GuitarSet comping (scripts/diagnose-levels.mjs), then held out once under rules fixed first
// (private pre-registration, Amendments 12 and 13), against the beam's defaults:
// - On 35 Candombe drum recordings, a following band would be against the drummers 39% of the time rather than
//   62%. It was better on 26 recordings and worse on 9 (p = 0.006).
// - It was no less robust in the user's songs in odd meters.
// The beam's defaults stay available as rhythm: {}.
export const BASS_ACCENT_LISTENING=Object.freeze({accent:'lowRise',rhythm:Object.freeze({cycleSeconds:4,
  tactus:Object.freeze({centerSeconds:.5,logSpread:.7}),accentModel:Object.freeze({id:'learned-velocity-v1',variance:.06,priorVariance:.05})})});

// chroma: FRAME_CHROMA's fields to change, or false for none. rhythm: the occurrence beam's configuration, and
// accent: which of an onset's measures is its accent ('strength' or 'lowRise'). Both default to the listening above;
// development comparisons (scripts/diagnose-levels.mjs, scripts/evaluate-listening.mjs) pass others.
// lowShare (in development): the bass's share of the attack, lowRise over strength. A loud off-beat strum raises the
// low band too; a bass note is the attack that is mostly bass.
const ACCENT_SOURCES=['strength','lowRise','lowShare'];
// The beam's configurations a listening may name (listening-options.js). metrical-persistence-v1 is in development:
// the default's beam, with metrical persistence (rhythm-occurrence.js levelPersistenceRatio).
export const RHYTHM_LISTENINGS=Object.freeze({'bass-accent-v1':BASS_ACCENT_LISTENING.rhythm,
  'metrical-persistence-v1':Object.freeze({...BASS_ACCENT_LISTENING.rhythm,levelPersistenceRatio:3})});
// Learned listenings: the rhythm report comes from a learned beat tracker (learned-pulse.js), by the model named
// (render/beats/models.json). The beam still hears the onsets, for the pulse follower and the subdivision.
// A learned rhythm listening: the tracker's model, and how its beats are followed (learned-pulse.js options). beat-this-v2
// lets go of a level followed that no longer passes for one (pre-registration Question 8).
// beat-this-v3, in development and named only: beat-this-v2 with the free-timing gate, following a grid only while it
// scores at least 0.92 (learned-pulse.js trackingScore). On development (spent ChoirSet, the user's spent sung takes,
// GTZAN's development excerpts) it took singing from misleading to abstaining at under 0.01 of a band's beat; its
// held-out test on song not yet heard is pre-registered (research/preregistrations/2026-09-27-free-timing-gate.md).
// beat-this-v4, in development and named only: the same gate at 0.96, chosen on development by a rule fixed before any
// result (research/kalman-integration.md, "The stricter song gate, developed"). On the spent ChoirSet and Winterreise
// it abstains rather than misleads (+0.033 and +0.006), and on GTZAN's development excerpts it keeps 93% of v3's net.
// Its held-out test waits on a sung corpus not yet heard.
export const LEARNED_RHYTHM_LISTENINGS=Object.freeze({'beat-this-v1':Object.freeze({model:'beat-this-final0'}),
  'beat-this-v2':Object.freeze({model:'beat-this-final0',pulse:Object.freeze({releaseLapsed:true})}),
  'beat-this-v3':Object.freeze({model:'beat-this-final0',pulse:Object.freeze({releaseLapsed:true,trackingScore:.92})}),
  'beat-this-v4':Object.freeze({model:'beat-this-final0',pulse:Object.freeze({releaseLapsed:true,trackingScore:.96})})});
// The rhythm listening wherever a learned tracker runs, unless one is named. Amendments 14 and 15 made the learned
// tracker the default; Amendments 16-18 made it beat-this-v2. On 992 held-out GTZAN excerpts a band following it was at
// the performer's beat 74.6% of the time, against beat-this-v1's 73.5%, and followed nothing 5.5% against 7.6%.
export const LEARNED_RHYTHM_DEFAULT='beat-this-v2';
// harmony: a harmony listening's name (harmony-listenings.js), whose chroma fields apply under `chroma`'s.
// beatTracker: the learned tracker a learned listening hears with (beat-trackers.js), else the one the host installed.
// chordTracker: the learned recognizer a learned harmony listening hears with (chord-trackers.js), else the installed one.
// rhythm left out: LEARNED_RHYTHM_DEFAULT where the host has a learned beat tracker, else bass-accent-v1
// (pre-registration Amendments 14 and 15: on 93 held-out BRID recordings a band following the learned tracker was
// against the performer 3.3% of the time, against 9.2%).
export function createFrameAnalysis({chroma={},harmony=null,rhythm:given=undefined,accent:accentFrom=BASS_ACCENT_LISTENING.accent,beatTracker:givenTracker=null,learnedPulse:learnedOptions={},
  chordTracker:givenChords=null,pitch:pitchOptions={},...options}) {
  const named=given??((givenTracker??beatTracker())?LEARNED_RHYTHM_DEFAULT:BASS_ACCENT_LISTENING.rhythm);
  const learnedListening=typeof named==='string'?LEARNED_RHYTHM_LISTENINGS[named]:null;
  const rhythm=learnedListening?BASS_ACCENT_LISTENING.rhythm:typeof named==='string'?RHYTHM_LISTENINGS[named]:named;
  if(!rhythm)throw new TypeError(`A rhythm listening is one of ${[...Object.keys(RHYTHM_LISTENINGS),...Object.keys(LEARNED_RHYTHM_LISTENINGS)].join(', ')}`);
  const tracker=learnedListening?givenTracker??beatTracker():null;
  if(learnedListening&&!tracker)throw new Error(`The listening "${named}" needs a learned beat tracker, which this host does not have: a render on the desktop, or a desktop page, with render/beats installed`);
  if(!ACCENT_SOURCES.includes(accentFrom))throw new TypeError(`An accent is one of ${ACCENT_SOURCES.join(', ')}`);
  if(harmony!==null&&!HARMONY_LISTENINGS[harmony])throw new TypeError(`A harmony listening is one of ${Object.keys(HARMONY_LISTENINGS).join(', ')}`);
  // A learned harmony listening hears chords with its recognizer, not the chroma templates.
  const learnedHarmony=harmony?HARMONY_LISTENINGS[harmony].learned??null:null,chords=learnedHarmony&&chroma!==false?givenChords??chordTracker():null;
  if(learnedHarmony&&chroma!==false&&!chords)throw new Error(`The harmony listening "${harmony}" needs a learned chord recognizer, which this host does not have: a render on the desktop, with render/chords installed`);
  const chromaConfig=chroma===false||learnedHarmony?null:{...FRAME_CHROMA,...(harmony?HARMONY_LISTENINGS[harmony].chroma:{}),...chroma},frameSize=options.frameSize;
  if(chromaConfig&&!(Number.isInteger(frameSize)&&frameSize>0&&frameSize<=chromaConfig.fftSize))throw new RangeError('Chroma needs frames no longer than its spectrum');
  let source,bank,follower,frames,recent,filled,strengths,lastSequence=-1,learned=null,learnedChords=null;
  const reset=()=>{source=new AudioFeatureSource(options);bank=createRhythmBank(rhythm);follower=createPulseFollower();strengths=[];
    frames=chromaConfig&&new ChromaFrames({sampleRate:options.sampleRate,...chromaConfig});recent=chromaConfig&&new Float32Array(chromaConfig.fftSize);filled=0;
    // A gap restarts the learned tracker's window too: audio either side of it is not one performance.
    learned?.close();
    learned=learnedListening?createLearnedPulse({provider:tracker.stream({sampleRate:options.sampleRate,windowSeconds:learnedOptions.windowSeconds??LEARNED_PULSE_DEFAULTS.windowSeconds}),
      model:learnedListening.model,...learnedListening.pulse,...learnedOptions}):null;
    learnedChords?.close();
    // The recognizer hears as the listening says (its future, lag and hop), which a host may change (chords.options, for
    // experiments: hopSeconds, lagSeconds, transitionScale, future).
    const hears={...learnedHarmony?.hears,...chords?.options};
    learnedChords=chords?createLearnedChords({provider:chords.stream({sampleRate:options.sampleRate,...hears}),vocabulary:TWELVE_TONE_TRIADS,model:learnedHarmony.model,
      ...(hears.hopSeconds?{hopSeconds:hears.hopSeconds}:{})}):null;};
  reset();
  return {
    // A frame that does not follow the last one restarts the analysis: a gap in
    // capture is not continuous evidence.
    analyze(samples,{start,end,sequence}) {
      const gap=lastSequence>=0&&sequence!==lastSequence+1;
      if(gap)reset();
      lastSequence=sequence;
      const features=source.process(samples,{start,end,availableAt:end});
      if(features.onset){
        // An attack's accent, as a velocity is for MIDI: its measure against the median of the last 32, on a log
        // scale around 0.5 (twice as much is 0.75, a sixteenth or less is 0). Only a beam configured with an accent
        // model reads it.
        const value=accentFrom==='lowShare'?(features.onset.strength>0?features.onset.lowRise/features.onset.strength:0):features.onset[accentFrom],typical=strengths.length?[...strengths].sort((a,b)=>a-b)[strengths.length>>1]:value;
        const accent=typical>0?Math.max(0,Math.min(1,.5+.25*Math.log2(Math.max(value,typical/16)/typical))):null;
        if(value>=0){strengths.push(value);if(strengths.length>32)strengths.shift();}
        // An attack heard again in the next frame, placed no later than where it was first heard, is not observed twice:
        // the beam takes onsets in time order, and refused it (GTZAN blues.00024 at 10.1 s stopped an evaluation).
        const time=features.onset.estimateSeconds;
        if(Number.isFinite(time)&&(bank.lastEventAt===null||time>bank.lastEventAt)&&(accent===null||Number.isFinite(accent))){
          bank=observeRhythm(bank,{eventTime:time,availableAt:end,varianceSeconds2:features.onset.varianceSeconds2,accent});
          follower=observePulseFollower(follower,time);
        }
      }
      let rhythm=bank.candidates.length?rhythmForecasts(bank,{now:end}):null;const pulse=follower.last===null?null:pulseFollowerForecast(follower,{now:end});
      if(learned){learned.hear(samples,{start,end});rhythm=learned.report(end);}
      let harmony=null;
      if(learnedChords){learnedChords.hear(samples,{start,end});const state=learnedChords.state();
        // The observation spans the latest frame's context (the recognizer hears 0.7 s before it) to now.
        if(state)harmony={projection:`learned:${learnedHarmony.model}`,chroma:null,chords:state,windowSeconds:Math.max(0,end-state.at)+.7};}
      if(frames){
        recent.copyWithin(0,samples.length);recent.set(samples,recent.length-samples.length);filled=Math.min(recent.length,filled+samples.length);
        // Until a whole spectrum has been heard there is no chroma, which is not silence.
        if(filled===recent.length){const value=frames.chroma(recent);
          harmony={projection:(chromaConfig.classes??12)===12?CHROMA_PROJECTION.id:`chroma-${chromaConfig.classes}-classes-v1`,chroma:value?[...value]:null,windowSeconds:recent.length/options.sampleRate,
            ...(frames.bassChroma?{bass:[...frames.bassChroma]}:{})};}
      }
      // A monophonic pitch (pitch-yin.js), for the notes of a line; pitch: false leaves it out.
      const pitch=pitchOptions===false||!(options.sampleRate>0)?null:yinPitch(samples,options.sampleRate,pitchOptions);
      return {features,gap,rhythm,pulse,harmony,pitch};
    },
  };
}
