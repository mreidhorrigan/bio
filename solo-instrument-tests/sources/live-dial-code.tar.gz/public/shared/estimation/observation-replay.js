import {frozenJson, identifier} from '../planning-data.js';
import {finite, EstimationError} from './linear-filter.js';
import {OBSERVATION_LIMITS} from './observations.js';

const freeze = value => frozenJson(value, {bytes: 65536, items: 8192}).data;
const reject = message => { throw new EstimationError('replay-contract', message); };
const order = (a, b) => a.when.eventStart - b.when.eventStart || a.sequence - b.sequence || (a.observationId < b.observationId ? -1 : a.observationId > b.observationId ? 1 : 0);
const canonicalEvidence = value => { const {receivedAt, ...evidence} = value; return frozenJson(evidence).canonical; };
const cursor = event => freeze({when:{eventStart:event.when.eventStart},sequence:event.sequence,observationId:event.observationId});
const windowEnd = event => event.when.eventEnd === undefined ? event.when.eventStart : event.when.eventEnd;
function evidenceKeys(event) {
  const keys=new Set([event.observationId]);
  for(const field of ['rawEventRefs','ancestry']){
    const values=event[field]===undefined?[]:event[field];
    if(!Array.isArray(values)||values.length>OBSERVATION_LIMITS.ancestors)reject('Observation ancestry budget exceeded');
    for(const value of values){identifier(value,field);keys.add(value);}
  }
  return [...keys];
}
function overlaps(a,b) {
  const a0=a.when.eventStart,a1=windowEnd(a),b0=b.when.eventStart,b1=windowEnd(b);
  // Analysis windows are half-open; raw point events can share a timestamp.
  // A point inside a window is already represented by that window's input.
  if(a0===a1)return b1>b0&&a0>=b0&&a0<b1;
  if(b0===b1)return b0>=a0&&b0<a1;
  return a0<b1&&b0<a1;
}
function trim(map,limit,protectedKeys) {
  for(const key of map.keys()){
    if(map.size<=limit)break;
    if(!protectedKeys.has(key))map.delete(key);
  }
}

// One explicitly scoped model per instance. Reducers are locally registered,
// deterministic pure functions. Replay has no transport, selection or scheduler.
export class ObservationReplay {
  constructor({initial, reduce, reduceBatch = null, eventLimit = 512, historySeconds = 30, snapshotLimit = 64,
    stateBytes = 65536, stateItems = 8192}) {
    if (typeof reduce !== 'function' || reduceBatch!==null&&typeof reduceBatch!=='function' || !Number.isInteger(eventLimit) || eventLimit < 2 || eventLimit > 2048 ||
      !Number.isInteger(snapshotLimit) || snapshotLimit < 1 || snapshotLimit > 128 || !Number.isFinite(historySeconds) || historySeconds <= 0 || historySeconds > 600 ||
      !Number.isInteger(stateBytes) || stateBytes < 1024 || stateBytes > 8*1024*1024 ||
      !Number.isInteger(stateItems) || stateItems < 128 || stateItems > 1024*1024) reject('Invalid replay configuration');
    Object.assign(this, {reduce, reduceBatch, eventLimit, historySeconds, snapshotLimit});
    // Model state may include a bounded live note/controller graph. Larger
    // local checkpoints never enlarge the per-observation/wire budget.
    this.stateBudget = Object.freeze({bytes:stateBytes,items:stateItems});
    this.base = this.freezeState(initial); this.current = this.base; this.events = []; this.sealed = new Map(); this.scope = null;
    this.checkpointEventTime = -Infinity; this.checkpointAvailableAt = -Infinity; this.latestEventTime = -Infinity;
    this.checkpointCursor = null; this.checkpointWindowEnd = -Infinity; this.windowedEvents = [];
    this.diagnostics = []; this.revision = 0; this.replayedEvents = 0;
    this.seen = new Map(); this.groups = new Map(); this.sequenceIds = new Map(); this.evidenceRefs = new Map();
  }
  record(reason, observationId) {
    this.diagnostics.push({reason, observationId}); if (this.diagnostics.length > 128) this.diagnostics.shift();
    return {accepted: false, reason};
  }
  freezeState(value) { return frozenJson(value,this.stateBudget).data; }
  apply(state, observation) { return this.freezeState(this.reduce(state, observation)); }
  applyMany(state, observations) {
    if(!observations.length)return state;
    // A locally registered batch reducer must be equivalent to the ordered
    // single-event fold. It can restore an expensive note graph just once.
    if(this.reduceBatch)return this.freezeState(this.reduceBatch(state,observations));
    for(const observation of observations)state=this.apply(state,observation);
    return state;
  }
  insert(input) { return this.insertOne(input); }
  insertMany(inputs) {
    if(!Array.isArray(inputs)||!inputs.length||inputs.length>128)reject('Invalid replay batch budget');
    if(inputs.length===1)return this.insert(inputs[0]);
    // Validate in arrival order, with the same retention/deduplication rules
    // as individual inserts. No model state is copied or changed per event.
    // A rejected batch commits nothing, including its earlier valid events.
    const staged=Object.assign(Object.create(Object.getPrototypeOf(this)),this);
    for(const name of ['seen','groups','sequenceIds','evidenceRefs'])staged[name]=new Map(this[name]);
    staged.diagnostics=[...this.diagnostics];
    const deferred={observations:[],expired:[],late:false};
    for(const input of inputs){
      const result=staged.insertOne(input,deferred);
      if(!result.accepted)return this.record(result.reason,input.observationId);
    }
    const ordered=deferred.late?[...this.events,...deferred.observations].sort(order):deferred.observations;
    staged.current=this.applyMany(deferred.late?this.base:this.current,ordered);
    staged.base=this.applyMany(this.base,deferred.expired);
    staged.replayedEvents=this.replayedEvents+(deferred.late?ordered.length:0);
    Object.assign(this,staged);
    return {accepted:true,late:deferred.late,revision:this.revision,state:this.current};
  }
  insertOne(input,deferred=null) {
    const observation = freeze(input); identifier(observation.observationId);
    for (const key of ['sessionId', 'sourceId', 'sourceIncarnation', 'parameterSchema', 'bindingVersion']) identifier(observation[key], key);
    identifier(observation.when?.clockMappingVersion);
    if (typeof observation.units !== 'string' || !observation.units.length || !Number.isSafeInteger(observation.sequence) || observation.sequence < 0) reject('Invalid observation units or sequence');
    for (const value of [observation.when?.eventStart, observation.when?.availableAt, observation.receivedAt]) finite(value, 'observation time');
    const end=finite(windowEnd(observation),'observation window end'),references=evidenceKeys(observation);
    for(const name of ['observerId','publisherId','extractorVersion','calibrationVersion'])if(observation[name]!==undefined)identifier(observation[name],name);
    if(end<observation.when.eventStart||observation.when.availableAt<end)reject('Evidence availability precedes its event/window');
    if (observation.receivedAt < observation.when.availableAt) reject('Receipt precedes evidence availability');
    const scope = JSON.stringify([observation.sessionId, observation.sourceId, observation.sourceIncarnation,
      observation.parameterSchema, observation.units, observation.bindingVersion, observation.when.clockMappingVersion,
      observation.observerId??null,observation.publisherId??null,observation.extractorVersion??null,observation.calibrationVersion??null]);
    if (this.scope !== null && scope !== this.scope) return this.record('incompatible-source-or-model-scope', observation.observationId);
    const canonical = canonicalEvidence(observation), previous = this.seen.get(observation.observationId);
    if (previous) return this.record(previous === canonical ? 'duplicate-evidence' : 'conflicting-observation-id', observation.observationId);
    if (this.sequenceIds.has(observation.sequence)) return this.record('conflicting-observation-sequence', observation.observationId);
    if ((this.checkpointCursor&&order(observation,this.checkpointCursor)<=0) || observation.when.eventStart < this.latestEventTime - this.historySeconds)
      return this.record('outside-replay-window', observation.observationId);
    // Unknown correlation never becomes two independent updates. Separate
    // justified independent sensors use an explicit fusion adapter/observation R.
    if (observation.correlationGroup && this.groups.has(observation.correlationGroup)) return this.record('correlated-evidence', observation.observationId);
    if(references.some(ref=>this.evidenceRefs.has(ref)))return this.record('overlapping-evidence-ancestry',observation.observationId);
    if(observation.when.eventStart<this.checkpointWindowEnd||
      end>observation.when.eventStart&&observation.when.eventStart===this.checkpointEventTime||
      (end>observation.when.eventStart?this.events:this.windowedEvents).some(event=>overlaps(event,observation)))
      return this.record('overlapping-analysis-window',observation.observationId);
    const late = this.events.length > 0 && order(observation, this.events.at(-1)) < 0;
    const events=[...this.events];
    if(!late)events.push(observation);
    else {let lo=0,hi=events.length;while(lo<hi){const mid=(lo+hi)>>>1;if(order(events[mid],observation)<=0)lo=mid+1;else hi=mid;}events.splice(lo,0,observation);}
    let next = this.current;
    // Compute before changing retained state: rejected reducers are atomic.
    if(!deferred){
      if (late) next = this.applyMany(this.base,events);
      else next = this.applyMany(next,[observation]);
    }
    // Checkpoint advancement can also fail (model or serialization errors).
    // Stage it before committing the accepted event, its deduplication keys,
    // the current estimate, or any retention boundary.
    const retained=[...events],latestEventTime=Math.max(this.latestEventTime,observation.when.eventStart);
    let base=this.base,checkpointEventTime=this.checkpointEventTime,checkpointAvailableAt=this.checkpointAvailableAt,checkpointCursor=this.checkpointCursor,
      checkpointWindowEnd=this.checkpointWindowEnd;
    const expired=[];
    while (retained.length > this.eventLimit || retained[0].when.eventStart < latestEventTime - this.historySeconds) {
      const removed = retained.shift(); expired.push(removed);
      checkpointCursor=cursor(removed);
      checkpointEventTime = removed.when.eventStart;
      checkpointWindowEnd=Math.max(checkpointWindowEnd,windowEnd(removed));
      checkpointAvailableAt = Math.max(checkpointAvailableAt, removed.when.availableAt, removed.receivedAt);
    }
    if(deferred){deferred.observations.push(observation);deferred.expired.push(...expired);deferred.late ||= late;}
    else base=this.applyMany(base,expired);
    this.scope=scope;this.events=retained;this.current=next;this.base=base;this.revision++;
    this.latestEventTime=latestEventTime;this.checkpointEventTime=checkpointEventTime;this.checkpointAvailableAt=checkpointAvailableAt;
    this.checkpointCursor=checkpointCursor;this.checkpointWindowEnd=checkpointWindowEnd;
    if(this.windowedEvents.length||end>observation.when.eventStart)this.windowedEvents=retained.filter(event=>windowEnd(event)>event.when.eventStart);
    if (late) this.replayedEvents += events.length;
    this.seen.set(observation.observationId, canonical); this.sequenceIds.set(observation.sequence, observation.observationId);
    if (observation.correlationGroup) this.groups.set(observation.correlationGroup, observation.when.eventStart);
    for(const ref of references)this.evidenceRefs.set(ref,observation.when.eventStart);
    // Arrival order can differ from event order. Never evict deduplication
    // keys for an event still retained merely because it arrived first.
    trim(this.seen,this.eventLimit*2,new Set(retained.map(event=>event.observationId)));
    trim(this.sequenceIds,this.eventLimit*2,new Set(retained.map(event=>event.sequence)));
    for (const [key, time] of this.groups) if (time < this.checkpointEventTime) this.groups.delete(key);
    trim(this.groups,this.eventLimit*2,new Set(retained.map(event=>event.correlationGroup)));
    for(const [key,time]of this.evidenceRefs)if(time<this.checkpointEventTime)this.evidenceRefs.delete(key);
    const referenceLimit=this.eventLimit*2*(2*OBSERVATION_LIMITS.ancestors+1);
    if(this.evidenceRefs.size>referenceLimit)trim(this.evidenceRefs,referenceLimit,new Set(retained.flatMap(evidenceKeys)));
    return {accepted: true, late, revision: this.revision, state: this.current};
  }
  seal(id, cutoff) {
    identifier(id, 'belief snapshot'); finite(cutoff, 'belief cutoff');
    const existing = this.sealed.get(id);
    if (existing) { if (existing.cutoff !== cutoff) reject('Snapshot IDs cannot change cutoff'); return existing; }
    if (this.sealed.size >= this.snapshotLimit) reject('Snapshot retention budget exhausted');
    let state = this.base, inputs = [], eligible = [];
    const status = this.checkpointAvailableAt > cutoff ? 'unknown' : 'known';
    if (status === 'known') for (const event of this.events) {
      if (event.when.availableAt <= cutoff && event.receivedAt <= cutoff && event.when.eventStart <= cutoff) {
        eligible.push(event); inputs.push(event.observationId);
      }
    }
    state=this.applyMany(state,eligible);
    const snapshot = this.freezeState({version: 1, beliefId: id, revision: this.revision, cutoff, scope: this.scope,
      status, reason: status === 'unknown' ? 'historical-checkpoint-unavailable-at-cutoff' : null,
      state: status === 'known' ? state : null, inputObservationIds: inputs,
      checkpointEventTime: Number.isFinite(this.checkpointEventTime) ? this.checkpointEventTime : null,
      checkpointCursor:this.checkpointCursor,
      checkpointWindowEnd:Number.isFinite(this.checkpointWindowEnd)?this.checkpointWindowEnd:null,
      checkpointAvailableAt: Number.isFinite(this.checkpointAvailableAt) ? this.checkpointAvailableAt : null});
    this.sealed.set(id, snapshot); return snapshot;
  }
}
