import {frozenJson,identifier} from '../planning-data.js';

const freeze=value=>frozenJson(value,{bytes:131072,items:16384}).data;
const modulo=(value,period)=>((value%period)+period)%period;
const distance=(a,b,period)=>Math.min(modulo(a-b,period),modulo(b-a,period));
const logSum=values=>{const top=Math.max(...values);return top+Math.log(values.reduce((sum,value)=>sum+Math.exp(value-top),0));};

export const TWELVE_TONE_TRIADS=freeze({vocabularyId:'major-minor-triads-12',tuningId:'12-equal',periodSemitones:12,
  labels:['C','Cs','D','Eb','E','F','Fs','G','Ab','A','Bb','B'].flatMap((name,root)=>[
    {id:`${name}-major`,pitchClasses:[root,(root+4)%12,(root+7)%12]},
    {id:`${name}-minor`,pitchClasses:[root,(root+3)%12,(root+7)%12]},
  ])});

// A bounded categorical persistence model over an explicitly named vocabulary.
// It predicts persistence, not a harmonic progression. Fast pitch material is
// always returned independently of the slower label state.
export function createHarmonyModel({vocabularyId,tuningId,periodSemitones=12,labels,
  toleranceSemitones=0.15,minimumSupport=0.85,changeRatePerSecond=0.7,maximumCandidates=8}={}) {
  identifier(vocabularyId);identifier(tuningId);
  if(!Number.isFinite(periodSemitones)||periodSemitones<=0||periodSemitones>128||!Number.isFinite(toleranceSemitones)||toleranceSemitones<=0||
    toleranceSemitones>periodSemitones/2||!Number.isFinite(minimumSupport)||minimumSupport<=0.5||minimumSupport>1||
    !Number.isFinite(changeRatePerSecond)||changeRatePerSecond<=0||!Number.isInteger(maximumCandidates)||maximumCandidates<1||maximumCandidates>32||
    !Array.isArray(labels)||!labels.length||labels.length>64)throw new TypeError('Invalid harmonic vocabulary/configuration');
  const vocabulary=labels.map(label=>{
    identifier(label.id);
    if(!Array.isArray(label.pitchClasses)||!label.pitchClasses.length||label.pitchClasses.length>32||label.pitchClasses.some(p=>!Number.isFinite(p)||p<0||p>=periodSemitones))throw new TypeError('Invalid vocabulary pitch classes');
    return {id:label.id,pitchClasses:[...new Set(label.pitchClasses)].sort((a,b)=>a-b)};
  });
  if(new Set(vocabulary.map(label=>label.id)).size!==vocabulary.length)throw new TypeError('Duplicate harmonic label');
  // at: the latest observation's time, whatever it held; posteriorAt: the time the hypotheses stand for, the last
  // observation that changed them. Persistence runs from posteriorAt, so how often unchanged material is polled
  // changes nothing (the mathematical audit's E03).
  return freeze({modelId:'harmonic-persistence-v1',modelVersion:1,vocabularyId,tuningId,periodSemitones,vocabulary,
    config:{toleranceSemitones,minimumSupport,changeRatePerSecond,maximumCandidates},revision:0,at:null,posteriorAt:null,material:null,signature:null,
    hypotheses:vocabulary.map(label=>({label:label.id,score:1/vocabulary.length})),status:'unknown',reason:'no-evidence',
    calibrationStatus:'uncalibrated-categorical-scores'});
}

export function observeHarmony(state,projection) {
  if(projection?.version!==1||projection.pitchUnits!=='MIDI-note-semitones'||!Number.isFinite(projection.availableAt)||
    state.at!==null&&projection.availableAt<state.at)throw new TypeError('Invalid harmonic projection or availability order');
  const at=projection.availableAt,revision=state.revision+1;
  if(projection.coverage!=='complete')return freeze({...state,revision,at,status:'unknown',reason:'missing-source-coverage',material:null,signature:null,candidates:[],changeBoundary:false});
  if(!Array.isArray(projection.notes)||projection.notes.length>2048)throw new TypeError('Invalid active-note budget');
  for(const note of projection.notes)if(!Number.isFinite(note.pitch)||!Number.isFinite(note.velocity)||!Number.isFinite(note.gain)||note.velocity<0||note.velocity>1||note.gain<0||note.gain>1)throw new TypeError('Invalid pitch/strength evidence');
  const material=projection.notes.filter(note=>note.velocity*note.gain>0).map(note=>({pitch:note.pitch,strength:note.velocity*note.gain,
    keyDown:note.keyDown,pedalHeld:note.pedalHeld}));
  if(!material.length)return freeze({...state,revision,at,posteriorAt:at,status:'nonchordal/no-chord',reason:'no-active-MIDI-note-intentions',material,signature:'empty',candidates:[],changeBoundary:false,
    hypotheses:state.vocabulary.map(label=>({label:label.id,score:1/state.vocabulary.length}))});
  const signature=JSON.stringify(material.map(note=>note.pitch).sort((a,b)=>a-b));
  // Holding a note, or repeating an analysis window, is not new independent
  // pitch evidence. Expression remains visible through the fast material view.
  // Nor does it move the hypotheses' time: the next change is persisted over
  // everything since they last changed, not since the last poll. After ten
  // seconds of C major, taking away G left C major at .50 with no poll between
  // and at .95 with nine.
  if(signature===state.signature)return freeze({...state,revision,at,material,reason:'unchanged-pitch-material'});
  const total=material.reduce((sum,note)=>sum+note.strength,0),period=state.periodSemitones,config=state.config;
  const since=state.posteriorAt??state.at,dt=since===null?Infinity:at-since,retain=Number.isFinite(dt)?Math.exp(-config.changeRatePerSecond*dt):0;
  const old=new Map(state.hypotheses.map(candidate=>[candidate.label,candidate.score]));
  const scored=state.vocabulary.map(label=>{
    const costs=material.map(note=>Math.min(...label.pitchClasses.map(pc=>distance(modulo(note.pitch,period),pc,period))));
    const support=material.reduce((sum,note,index)=>sum+(costs[index]<=config.toleranceSemitones?note.strength:0),0)/total;
    // A new incompatible pitch set bypasses persistence. This preserves fast
    // transitions without interpreting a single passing pitch as certainty.
    const prior=retain*(old.get(label.id)||0)+(1-retain)/state.vocabulary.length;
    const fit=costs.reduce((sum,cost,index)=>sum+Math.min(25,(cost/config.toleranceSemitones)**2)*material[index].strength/total,0);
    return {label:label.id,support,fit,logWeight:Math.log(Math.max(prior,1e-12))-0.5*fit};
  });
  const supported=scored.filter(candidate=>candidate.support>=config.minimumSupport);
  const priorLeader=state.hypotheses.reduce((best,candidate)=>!best||candidate.score>best.score?candidate:best,null);
  const boundary=Boolean(supported.length&&priorLeader&&scored.find(candidate=>candidate.label===priorLeader.label).support<config.minimumSupport);
  if(boundary)for(const candidate of scored)candidate.logWeight=-Math.log(state.vocabulary.length)-0.5*candidate.fit;
  const normalize=logSum(scored.map(candidate=>candidate.logWeight));
  const hypotheses=scored.map(({label,support,logWeight})=>({label,support,score:Math.exp(logWeight-normalize)}))
    .sort((a,b)=>b.score-a.score||(a.label<b.label?-1:1));
  const distinct=[];
  for(const note of material)if(!distinct.some(pc=>distance(pc,modulo(note.pitch,period),period)<=config.toleranceSemitones))distinct.push(modulo(note.pitch,period));
  const status=!supported.length?'unknown':distinct.length<3||supported.length>1||hypotheses[0].support<config.minimumSupport?'ambiguous':'interpreted';
  return freeze({...state,revision,at,posteriorAt:at,material,signature,hypotheses,
    candidates:hypotheses.slice(0,config.maximumCandidates),status,changeBoundary:boundary,reason:!supported.length?'outside-declared-vocabulary':status==='ambiguous'?'multiple-compatible-interpretations':'one-supported-vocabulary-label',
    coverage:{vocabularySize:state.vocabulary.length,shown:Math.min(config.maximumCandidates,hypotheses.length),unknownIsNotNoChord:true}});
}
