// Large clips travel as bounded direct Musebots messages. This keeps whole
// files compatible with existing transports instead of enlarging UDP packets.
const CHUNK_CHARS=6000,MAX_CHUNKS=12000,MAX_BYTES=32*1024*1024;
let nextTransfer=1;
export function sendMemoryMessage(send,address,args,{prefix='/agent/memory/',maxBytes=MAX_BYTES}={}) {
  if(!address.startsWith(prefix)||address===`${prefix}transfer`)return send(address,args);
  const text=JSON.stringify(args);
  if(text.length<CHUNK_CHARS)return send(address,args);
  if(text.length>maxBytes)throw new RangeError('Direct transfer exceeds its byte budget');
  const transferId=globalThis.crypto?.randomUUID?.()||`${Date.now()}:${nextTransfer++}`,
    count=Math.ceil(text.length/CHUNK_CHARS),target=args[0]?.target;
  for(let index=0;index<count;index++)send(`${prefix}transfer`,[{
    target,transferId,address,index,count,chunk:text.slice(index*CHUNK_CHARS,(index+1)*CHUNK_CHARS),
  }]);
}
export class MemoryTransfers {
  constructor({prefix='/agent/memory/',maxBytes=MAX_BYTES,maxChunks=MAX_CHUNKS,maxTransfers=16}={}){
    this.pending=new Map();Object.assign(this,{prefix,maxBytes,maxChunks,maxTransfers});
  }
  accept(message) {
    const p=message.args?.[0]||{},now=Date.now();
    for(const [key,state] of this.pending)if(state.expiresAt<now)this.pending.delete(key);
    if(!p.address?.startsWith(this.prefix)||p.address===`${this.prefix}transfer`||typeof p.transferId!=='string'||p.transferId.length>128||!p.transferId||
      !Number.isInteger(p.count)||p.count<1||p.count>this.maxChunks||!Number.isInteger(p.index)||p.index<0||p.index>=p.count||
      typeof p.chunk!=='string'||p.chunk.length>CHUNK_CHARS)throw new Error('Invalid direct memory transfer chunk');
    const key=JSON.stringify([message.source||'',message.sourceIncarnation||'',p.transferId]);
    let state=this.pending.get(key);
    if(!state){if(this.pending.size>=this.maxTransfers)throw new Error('Too many simultaneous direct transfers');
      state={parts:new Map(),size:0,count:p.count,address:p.address,target:p.target,expiresAt:now+30000};this.pending.set(key,state)}
    if(state.count!==p.count||state.address!==p.address||state.target!==p.target)throw new Error('Inconsistent direct memory transfer');
    if(state.parts.has(p.index)){if(state.parts.get(p.index)!==p.chunk)throw new Error('Conflicting memory transfer chunk');return null}
    state.size+=p.chunk.length;
    if(state.size>this.maxBytes){this.pending.delete(key);throw new RangeError('Direct transfer exceeds its byte budget')}
    state.parts.set(p.index,p.chunk);
    if(state.parts.size!==state.count)return null;
    this.pending.delete(key);
    const args=JSON.parse(Array.from({length:state.count},(_,i)=>state.parts.get(i)).join(''));
    if(!Array.isArray(args)||args[0]?.target!==state.target)throw new Error('Memory transfer target mismatch');
    return {...message,address:state.address,args};
  }
}
