// mulberry32, a 32-bit generator (T. Ettinger, 2017, public domain: its increment and shifts as published): from a
// 32-bit seed, a source of numbers in [0, 1) -- what a deterministic draw keyed by a name reads, its seed the name's
// hash (fnv1a.js).
export function mulberry32(seed){
  let state=seed>>>0;
  return ()=>{state=(state+0x6D2B79F5)>>>0;let t=state;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return ((t^t>>>14)>>>0)/2**32};
}
