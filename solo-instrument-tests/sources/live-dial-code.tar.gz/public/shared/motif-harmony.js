import {registerDomain,orderedRegister} from './pitch-domain.js';
// A motif, relative to the harmony it was played against -- and realized again in another.
//
// **This exists because recall ignored harmony.** A stored motif is absolute pitches. A bot that recalled one adopted
// those pitches as they stood, whatever the ensemble was playing by then: measured in a rendered piece, while
// ae_DroneBOT was playing recalled material 2 of its 6 notes were in the chord in force (D held against F A-flat C
// E-flat), against 65% the rest of the time. Nothing in the store said what harmony a motif had been played over, and
// nothing anywhere could re-express it in a different one.
//
// So, three things. `abstractMotif` says what each note WAS: which step of the harmony in force at its onset, and how
// far off it. `realizeMotif` says what those notes ARE in another harmony. `harmonicFit` measures how much of a motif
// sits on a harmony, which is how the first two are checked.
//
// What this will not do, because the material is not ours to standardize:
//
//   * **It never serializes a chord.** Every note is mapped by itself. Notes that sound together still sound together,
//     in the same vertical order, at the same times; nothing is re-timed, merged, split or reordered. A chord motif
//     comes back as a chord motif.
//   * **It never quantizes pitch.** Pitch is continuous throughout (a pool may hold 64.1 and a note 61.37). An
//     inflection of a chord tone is kept as an inflection of the corresponding chord tone. Only a caller that asks for a
//     `grid` gets one.
//   * **It never touches the original.** A realization is a development, with `parentMotifId` naming what it came from
//     and `transformation.harmonize` saying exactly what was done, so it stays in the same family and can be undone by
//     asking for the parent. Percussion (MIDI channel 10) is returned as it was: a snare is not a pitch.
//   * **It is not the last word.** A bot that receives a realization is free to transform it further by its own lights.
//
// The harmony is a POOL: the pitches of `/broadcast/notepool`, or one chord of a harmony plan. No root is assumed,
// because a voice-led chord arrives inverted and its lowest note is not its root. The alignment between two pools is
// found instead: the transposition that puts the steps the motif actually uses onto steps of the target, the smallest
// one that does it best. Between two transpositions of the same chord that is exactly the transposition.
import {inspectUMP,noteOn,perNoteController} from './ump.js';
import {motifNotes,validateMotif} from './motifs.js';

export const HARMONY_DEFAULTS=Object.freeze({
  // Pitch classes repeat at this interval. Twelve semitones; a tuning with another period says so.
  period:12,
  // Two pitch classes closer than this are one step, and a note this close to a step is ON it. 1/512 of a semitone is
  // the resolution of a MIDI 2 pitch 7.9 attribute, and what the framework already uses to say two pitches are the same.
  tolerance:1/512,
  // A note further than this from every step is not an inflection of a chord tone, it is a note BETWEEN chord tones.
  inflection:.5,
  // The MIDI channel whose notes are instruments rather than pitches.
  percussionChannel:9,
  // What a semitone of transposition costs, in semitones of distortion per note. Small: the alignment is chosen for how
  // little it bends the motif, and this only settles it between alignments that bend it about equally -- so C major
  // seventh to C minor seventh keeps its root and lowers its third and seventh (0.5 of distortion, no move) rather than
  // climbing a minor third to sit on the E-flat triad inside it (0.25 of distortion, three semitones of move).
  movePenalty:.1,
});

const finite=value=>typeof value==='number'&&Number.isFinite(value);
const modulo=(value,period)=>((value%period)+period)%period;
// Signed circular distance from `from` to `to`, in (-period/2, period/2].
const circular=(from,to,period)=>{const distance=modulo(to-from,period);return distance>period/2?distance-period:distance};

// A pool as a ladder: its distinct pitch classes, ascending, repeated in every period. `rung` numbers the steps of the
// whole ladder, so rung r is class r mod n, floor(r/n) periods up. An empty or unusable pool has no ladder.
export function harmonyLadder(pool,{period=HARMONY_DEFAULTS.period,tolerance=HARMONY_DEFAULTS.tolerance}={}){
  if(!(finite(period)&&period>0))throw new RangeError('A harmony needs a positive period');
  const classes=[];
  for(const value of Array.isArray(pool)?pool:[]){
    const pitch=Number(value);if(!Number.isFinite(pitch))continue;
    const pitchClass=modulo(pitch,period);
    if(!classes.some(existing=>Math.abs(circular(existing,pitchClass,period))<=tolerance))classes.push(pitchClass);
  }
  classes.sort((left,right)=>left-right);
  if(!classes.length)return null;
  const count=classes.length,
    pitchOf=rung=>classes[modulo(rung,count)]+period*Math.floor(rung/count),
    // The rung nearest a pitch; exactly between two, the lower, so the answer never depends on rounding luck.
    nearest=pitch=>{
      const base=Math.floor(pitch/period)*count;let best=null;
      for(let rung=base-1;rung<=base+count;rung++){const distance=Math.abs(pitchOf(rung)-pitch);if(best===null||distance<best.distance-1e-12)best={rung,distance}}
      return best.rung;
    };
  return Object.freeze({classes:Object.freeze(classes),period,count,pitchOf,nearest,
    // How far it is from a rung to its neighbour above or below: what an offset is measured within.
    gapAbove:rung=>pitchOf(rung+1)-pitchOf(rung),gapBelow:rung=>pitchOf(rung)-pitchOf(rung-1)});
}

// The harmony a motif was played against, as the motif carries it: `metadata.harmony.segments`, each a pool and the
// motif tick it took effect. A single pool, or a list of segments, given by the caller is read the same way.
export function harmonySegments(value){
  const source=Array.isArray(value)?(value.every(item=>typeof item==='number')?[{time:0,pool:value}]:value):value?.segments||(value?.pool?[{time:0,pool:value.pool}]:[]);
  return source.map(segment=>({time:Math.max(0,Math.round(Number(segment?.time)||0)),pool:(segment?.pool||[]).map(Number).filter(Number.isFinite)}))
    .filter(segment=>segment.pool.length).sort((left,right)=>left.time-right.time);
}
const segmentAt=(segments,time)=>{let lo=0,hi=segments.length;while(lo<hi){const mid=(lo+hi)>>>1;if(segments[mid].time<=time)lo=mid+1;else hi=mid;}return segments[Math.max(0,lo-1)]||null};

const isPercussion=(note,channel)=>note.channel===channel;

// What each note of a motif IS in the harmony it was played against.
//
// The result keeps the motif's own shape: `slices`, one per onset, each holding the notes that begin together, low to
// high. A note is `{index, rung, offset, inflected}`: `index` is its place in motifNotes(), `rung` the nearest step of
// the harmony in force at its onset, `offset` how far above (+) or below (-) that step it is in semitones. A note on a
// step has offset 0 to within tolerance; `inflected` marks one that is near a step but not on it. Percussion and notes
// with no harmony under them carry `rung: null` and are left alone by realizeMotif.
export function abstractMotif(value,harmony,options={}){
  const settings={...HARMONY_DEFAULTS,...options},motif=validateMotif(value),notes=motifNotes(motif),
    segments=harmonySegments(harmony??motif.metadata?.harmony),ladders=new Map;
  const ladderFor=segment=>{if(!segment)return null;if(!ladders.has(segment))ladders.set(segment,harmonyLadder(segment.pool,settings));return ladders.get(segment)};
  const entries=notes.map((note,index)=>{
    const time=note.on?.time??Math.round(note.at*motif.timebase.ticksPerQuarterNote),segment=segmentAt(segments,time),ladder=ladderFor(segment);
    if(!ladder||!Number.isFinite(note.pitch)||isPercussion(note,settings.percussionChannel))return {index,time,pitch:note.pitch,duration:note.duration||0,rung:null,offset:0,inflected:false,segment:null};
    const rung=ladder.nearest(note.pitch),offset=note.pitch-ladder.pitchOf(rung);
    return {index,time,pitch:note.pitch,duration:note.duration||0,rung,offset:Math.abs(offset)<=settings.tolerance?0:offset,
      inflected:Math.abs(offset)>settings.tolerance&&Math.abs(offset)<settings.inflection,segment:segments.indexOf(segment)};
  });
  const slices=[];
  for(const entry of [...entries].sort((left,right)=>left.time-right.time||left.pitch-right.pitch||left.index-right.index)){
    const last=slices.at(-1);
    if(last&&last.time===entry.time)last.notes.push(entry);else slices.push({time:entry.time,notes:[entry]});
  }
  return {motifId:motif.motifId,period:settings.period,segments,slices,notes:entries,fit:fitOf(entries,settings)};
}

// Duration-weighted onset compatibility: each note is judged against the harmony
// at its onset. This does not integrate subsequent harmony changes under a held
// note. `null` when nothing in it has a pitch and harmony to judge.
function fitOf(entries,settings){
  let on=0,total=0;
  for(const entry of entries){if(entry.rung===null)continue;const weight=Math.max(entry.duration,1e-6);total+=weight;if(Math.abs(entry.offset)<=settings.tolerance)on+=weight}
  return total?on/total:null;
}
export function harmonicFit(value,harmony,options={}){return options.fitMode==='time'?harmonicTimeFit(value,harmony,options).fit:abstractMotif(value,harmony,options).fit}

// The transposition that carries the steps a motif uses onto steps of a target harmony. The candidates are every
// difference between a used source class and a target class (and none at all). The cost of one is the DISTORTION it
// leaves -- how far the used classes then sit from the target's, averaged over the time the motif spends on each --
// plus `movePenalty` for each semitone of the transposition itself. Ties go to the smaller move and then to the upward
// one. No root is needed and none is guessed.
export function alignHarmony(used,target,{period=HARMONY_DEFAULTS.period,movePenalty=HARMONY_DEFAULTS.movePenalty}={}){
  if(!used.length||!target)return {transpose:0,cost:0};
  const whole=used.reduce((sum,{weight})=>sum+weight,0)||1;
  const candidates=new Set([0]);
  for(const {pitchClass} of used)for(const targetClass of target.classes)candidates.add(Number(circular(pitchClass,targetClass,period).toFixed(9)));
  let best=null;
  for(const transpose of candidates){
    let cost=0;
    for(const {pitchClass,weight} of used){
      let nearest=Infinity;
      for(const targetClass of target.classes)nearest=Math.min(nearest,Math.abs(circular(modulo(pitchClass+transpose,period),targetClass,period)));
      cost+=nearest*weight/whole;
    }
    cost+=movePenalty*Math.abs(transpose);
    if(!best||cost<best.cost-1e-9||Math.abs(cost-best.cost)<=1e-9&&(Math.abs(transpose)<Math.abs(best.transpose)-1e-9||Math.abs(Math.abs(transpose)-Math.abs(best.transpose))<=1e-9&&transpose>best.transpose))
      best={transpose,cost};
  }
  return best;
}

// **Choosing with harmony in mind.** Realizing makes any motif sit in any harmony, so fit cannot separate candidates --
// but how far each has to be BENT to get there can, and a library should prefer what survives the move. That is asked
// of every stored motif on every query, so it is split in two. `harmonicUsage` is everything that does not depend on
// the target: per stretch of the harmony the motif was played against, which steps it sits on and for how long. It is
// worked out once per stored motif. `harmonicStrain` is the rest, and is a handful of comparisons: the alignment
// realizeMotif would choose, and what it costs -- semitones of distortion per note, plus the small charge for the
// transposition itself. Zero is a motif that is in the harmony already; a motif a fourth away from fitting exactly
// costs half a semitone; one that has to be bent out of shape costs more than either.
export function harmonicUsage(value,options={}){
  const settings={...HARMONY_DEFAULTS,...options},motif=validateMotif(value),
    own=motifNotes(motif).filter(note=>Number.isFinite(note.pitch)&&!isPercussion(note,settings.percussionChannel)).map(note=>note.pitch),
    carried=harmonySegments(settings.source??motif.metadata?.harmony),
    abstraction=abstractMotif(motif,carried.length?carried:own.length?[{time:0,pool:own}]:[],settings),
    ladders=abstraction.segments.map(segment=>harmonyLadder(segment.pool,settings)),stretches=new Map;
  for(const entry of abstraction.notes){
    if(entry.rung===null)continue;
    const ladder=ladders[entry.segment],pitchClass=ladder.classes[modulo(entry.rung,ladder.count)],weight=Math.max(entry.duration,1e-6);
    if(!stretches.has(entry.segment))stretches.set(entry.segment,new Map);
    const used=stretches.get(entry.segment);used.set(pitchClass,(used.get(pitchClass)||0)+weight);
  }
  return [...stretches.values()].map(used=>({weight:[...used.values()].reduce((sum,weight)=>sum+weight,0),
    used:[...used].map(([pitchClass,weight])=>({pitchClass,weight}))}));
}
// `null` when there is nothing to judge: no pitched notes, or no harmony.
export function harmonicStrain(usage,pool,options={}){
  const settings={...HARMONY_DEFAULTS,...options},ladder=harmonyLadder(pool,settings);
  if(!ladder||!usage?.length)return null;
  const whole=usage.reduce((sum,stretch)=>sum+stretch.weight,0)||1;let strain=0,distortion=0,move=0;
  for(const stretch of usage){
    const {transpose,cost}=alignHarmony(stretch.used,ladder,settings),share=stretch.weight/whole;
    strain+=cost*share;distortion+=(cost-settings.movePenalty*Math.abs(transpose))*share;move+=Math.abs(transpose)*share;
  }
  const tidy=number=>Number(number.toFixed(6));
  return {strain:tidy(strain),distortion:tidy(Math.max(0,distortion)),transpose:tidy(move)};
}

// A motif realized in another harmony.
//
//   target      the harmony to realize it in: a pool, or segments [{time, pool}] in motif ticks for one that changes
//               under the motif (a harmony plan's chords)
//   source      the harmony it was played against; defaults to what the motif carries (metadata.harmony). Without
//               either, the motif's own pitches stand in for it: every note is taken as a step of itself, which still
//               moves it onto the target but cannot tell a chord tone from a passing tone
//   transpose   a fixed transposition in semitones instead of the one alignHarmony finds (a caller that knows the
//               root motion can say so)
//   center      keep the realization's middle as near this pitch as whole periods allow (default: where the motif was)
//   contour     true (default): where two successive single notes were different pitches and the new harmony would
//               make them the same, the later one takes the next step in the direction it was going -- by one step at
//               most, so a run over a sparse chord becomes an arpeggio and does not climb out of its register
//   grid        round realized pitches to a multiple of this (1 for twelve-tone); default none, pitch stays continuous
//
// Returns `{motif, report}`. The motif is a development of the original. The report says what was done: the
// transposition, how many notes moved and how far, and the fit before and after.
export function realizeMotif(value,target,options={}){
  const settings={...HARMONY_DEFAULTS,contour:true,grid:null,...options},motif=validateMotif(value),notes=motifNotes(motif);
  const targets=harmonySegments(target);
  if(!targets.length)throw new TypeError('realizeMotif needs a harmony to realize the motif in: a pool or segments');
  const carried=harmonySegments(settings.source??motif.metadata?.harmony);
  // With no record of what it was played against, the motif's own pitches are the only harmony it has.
  const assumed=!carried.length,own=notes.filter(note=>Number.isFinite(note.pitch)&&!isPercussion(note,settings.percussionChannel)).map(note=>note.pitch),
    sources=assumed?(own.length?[{time:0,pool:own}]:[]):carried;
  const abstraction=abstractMotif(motif,sources,settings),targetLadders=new Map,
    ladderFor=segment=>{if(!targetLadders.has(segment))targetLadders.set(segment,harmonyLadder(segment.pool,settings));return targetLadders.get(segment)};
  // One alignment per pairing of a source harmony with a target harmony, from the classes the motif uses there.
  const alignments=new Map,sourceLadders=abstraction.segments.map(segment=>harmonyLadder(segment.pool,settings));
  const targetIndices=new Map(targets.map((segment,i)=>[segment,i])),usageByPair=new Map;
  for(const entry of abstraction.notes)if(entry.rung!==null){
    const key=`${entry.segment}:${targetIndices.get(segmentAt(targets,entry.time))}`,ladder=sourceLadders[entry.segment],pitchClass=ladder.classes[modulo(entry.rung,ladder.count)];
    if(!usageByPair.has(key))usageByPair.set(key,new Map);const usage=usageByPair.get(key);usage.set(pitchClass,(usage.get(pitchClass)||0)+Math.max(entry.duration,1e-6));
  }
  const alignmentFor=(sourceIndex,targetSegment)=>{
    const key=`${sourceIndex}:${targetIndices.get(targetSegment)}`;
    if(!alignments.has(key)){
      if(finite(settings.transpose))alignments.set(key,{transpose:settings.transpose,cost:null});
      else{
        const usage=usageByPair.get(key)??new Map;
        alignments.set(key,alignHarmony([...usage].map(([pitchClass,weight])=>({pitchClass,weight})),ladderFor(targetSegment),settings));
      }
    }
    return alignments.get(key);
  };
  const realized=new Map;
  for(const entry of abstraction.notes){
    if(entry.rung===null)continue;
    const targetSegment=segmentAt(targets,entry.time),ladder=ladderFor(targetSegment),source=sourceLadders[entry.segment];
    if(!ladder)continue;
    const {transpose}=alignmentFor(entry.segment,targetSegment),rung=ladder.nearest(source.pitchOf(entry.rung)+transpose);
    // An offset stays what it was -- a semitone under a chord tone is a semitone under the corresponding one, and
    // nothing is scaled, so twelve-tone material stays twelve-tone. It may reach the neighbouring step where the new
    // harmony is closer-spaced than the old, and it never passes it.
    const room=(entry.offset>0?ladder.gapAbove(rung):ladder.gapBelow(rung)),
      offset=Math.sign(entry.offset)*Math.min(Math.abs(entry.offset),room);
    realized.set(entry.index,{rung,offset,ladder});
  }
  // Contour, between successive SINGLE notes only. A chord is not a melody and its members are never ordered in time.
  // A note that rose still rises: landing on the step before it, it takes the next one; landing under it -- because
  // the note before was itself moved up -- it repeats that step rather than turn the line around. A repeated note
  // stays a repeated note. Nothing here moves a note further than one step past where some note of the motif landed
  // by itself, so a scale over a triad becomes an arpeggio of about its own span and does not climb out of its register.
  if(settings.contour){
    let previous=null;
    for(const slice of abstraction.slices){
      const entry=slice.notes.length===1?slice.notes[0]:null,now=entry&&realized.get(entry.index);
      if(!now){previous=null;continue}
      if(previous&&now.ladder===previous.now.ladder&&!now.offset&&!previous.now.offset){
        const was=Math.sign(entry.pitch-previous.entry.pitch),step=now.rung-previous.now.rung;
        if(!was)now.rung=previous.now.rung;
        else if(Math.sign(step)!==was)now.rung=previous.now.rung+(step===0?was:0);
      }
      previous={entry,now};
    }
  }
  // Within a chord the voices keep their order: two that would land on one pitch are moved apart by a step, upward.
  for(const slice of abstraction.slices){
    if(slice.notes.length<2)continue;
    let below=null;                       // slice.notes is low to high, as the chord was
    for(const entry of slice.notes){
      const now=realized.get(entry.index);if(!now)continue;
      const sounding=()=>now.ladder.pitchOf(now.rung)+now.offset;
      // Voices that were a unison may stay one; voices that were apart stay apart.
      if(below&&entry.pitch>below.was+settings.tolerance)for(let guard=0;sounding()<=below.is+settings.tolerance&&guard<now.ladder.count*2;guard++)now.rung++;
      below={was:entry.pitch,is:sounding()};
    }
  }
  // The register: whole periods only, so nothing about the harmony changes, toward where the motif was (or `center`).
  const pitched=abstraction.notes.filter(entry=>realized.has(entry.index)),
    weightOf=entry=>Math.max(entry.duration,1e-6),total=pitched.reduce((sum,entry)=>sum+weightOf(entry),0)||1,
    was=pitched.reduce((sum,entry)=>sum+entry.pitch*weightOf(entry),0)/total,
    is=pitched.reduce((sum,entry)=>{const now=realized.get(entry.index);return sum+(now.ladder.pitchOf(now.rung)+now.offset)*weightOf(entry)},0)/total,
    // A transposition that was asked for is the register that was asked for.
    shift=pitched.length&&(finite(settings.center)||!finite(settings.transpose))?Math.round(((finite(settings.center)?settings.center:was)-is)/settings.period)*settings.period:0;
  if(settings.grid!==null&&(!Number.isFinite(settings.grid)||settings.grid<=0))throw new RangeError('A pitch grid must be positive and finite');
  const feasible=new Map;
  for(const slice of abstraction.slices){
    const entries=slice.notes.filter(entry=>realized.has(entry.index));if(!entries.length)continue;
    const targets=entries.map(entry=>{const now=realized.get(entry.index);let value=now.ladder.pitchOf(now.rung)+now.offset+shift;return settings.grid?Math.round(value/settings.grid)*settings.grid:value;});
    const domains=entries.map(entry=>{
      const now=realized.get(entry.index),values=[];
      for(let i=0;i<now.ladder.classes.length;i++){
        const room=now.offset>0?now.ladder.gapAbove(i):now.ladder.gapBelow(i),offset=Math.sign(now.offset)*Math.min(Math.abs(now.offset),room);
        for(let pitch of registerDomain(now.ladder.classes[i]+offset+shift,{low:0,high:127.99,period:settings.period,maxCandidates:4096})){
          if(settings.grid)pitch=Math.round(pitch/settings.grid)*settings.grid;if(pitch>=0&&pitch<=127.99)values.push(pitch);
          if(values.length>65536)throw new RangeError('Motif register domain budget exceeded');
        }
      }
      return [...new Set(values)].sort((a,b)=>a-b);
    });
    const strictEdges=entries.slice(1).map((entry,i)=>entry.pitch>entries[i].pitch+settings.tolerance),
      separationEdges=strictEdges.map(strict=>strict?settings.tolerance:0),
      solution=orderedRegister(domains,targets,{strictEdges,separationEdges,maxStates:65536});
    if(!solution)throw new RangeError('No ordered motif realization exists within the declared MIDI register');
    entries.forEach((entry,i)=>feasible.set(entry.index,solution.pitches[i]));
  }
  const pitchOf=index=>feasible.get(index)??null;
  // The same rewrite transformMotif makes, note by note, and nothing else: times, velocities, bends, pressure, every
  // other message, and every percussion note are the original's.
  const changes=new Map;let moved=0,distance=0;
  for(const entry of abstraction.notes){
    const pitch=pitchOf(entry.index),note=notes[entry.index];if(pitch===null||!note.on)continue;
    const delta=pitch-entry.pitch;if(Math.abs(delta)>settings.tolerance){moved++;distance+=Math.abs(delta)}
    changes.set(note.on,{pitch,delta,key:note.key,from:note.on.time,to:note.off?.time??Infinity});
  }
  const spans=[...changes.values()];
  const events=motif.events.map(event=>{
    const change=changes.get(event);
    if(change){
      if(Math.abs(change.delta)<=settings.tolerance)return event;
      const m=inspectUMP(event.packet);
      if(![0,3].includes(m.attribute))throw new Error('Cannot retune a manufacturer/profile-specific Note On attribute without interpreting it');
      return {time:event.time,packet:noteOn({group:m.group,channel:m.channel,note:m.note,velocity:m.velocity,pitch:change.pitch})};
    }
    const m=inspectUMP(event.packet);
    // A per-note pitch controller states an absolute pitch for the note it belongs to, so it moves with that note.
    if(m.kind==='perNoteController'&&m.attribute===3){
      const owner=spans.find(span=>span.key===m.key&&event.time>=span.from&&event.time<=span.to);
      if(owner&&Math.abs(owner.delta)>settings.tolerance){
        const pitch=Math.max(0,Math.min(127.99,m.data/0x2000000+owner.delta));
        return {time:event.time,packet:perNoteController({group:m.group,channel:m.channel,note:m.note,index:3,value:Math.round(pitch*0x2000000)})};
      }
    }
    return event;
  });
  const used=[...alignments.values()];
  // Already there -- or nothing in it has a pitch. The original is the answer; a development that changes nothing
  // would only be a second name for it.
  if(!moved){
    const fit=harmonicFit(motif,targets,settings);
    return {motif:value,report:{unchanged:true,transpose:0,register:0,assumedSource:assumed,notes:pitched.length,moved:0,meanMove:0,fitBefore:fit,fitAfter:fit}};
  }
  const harmonize={
    from:assumed?null:abstraction.segments.map(segment=>({time:segment.time,pool:segment.pool})),
    to:targets.map(segment=>({time:segment.time,pool:segment.pool})),
    transpose:used.length===1?used[0].transpose:used.map(item=>item.transpose),register:shift,assumedSource:assumed,
  };
  // Named for the harmony it is in, so two realizations of one motif are told apart in a log.
  const named=harmonyLadder(targets[0].pool,settings).classes.map(value=>Number(value.toFixed(2))).join('.');
  const result=validateMotif({...motif,motifId:`${motif.motifId}:in:${named}`,events,
    metadata:{...motif.metadata,harmony:{period:settings.period,segments:harmonize.to},parentMotifId:motif.motifId,transformation:{harmonize}}});
  return {motif:result,report:{transpose:harmonize.transpose,register:shift,assumedSource:assumed,notes:pitched.length,moved,
    meanMove:moved?distance/moved:0,fitBefore:harmonicFit(motif,targets,settings),fitAfter:harmonicFit(result,targets,settings)}};
}

export {HarmonyCapture} from './harmony-capture.js';
// Integrate note-time against every harmony change and, when requested, the
// piecewise-constant MIDI pitch controls. This is a declared hold interpolation
// law, not a claim about an instrument's glide. The first harmony extends back
// exactly as in harmonicFit. Unknown harmony contributes no judged note-time.
export function harmonicTimeFit(value,harmony,options={}){
  const settings={...HARMONY_DEFAULTS,pitchModel:'held-controls',maxPieces:1000000,...options};
  if(!['held-controls','onset'].includes(settings.pitchModel)||!Number.isSafeInteger(settings.maxPieces)||settings.maxPieces<1||settings.maxPieces>10000000)throw new TypeError('Invalid harmonic time-fit model/budget');
  const motif=validateMotif(value),segments=harmonySegments(harmony??motif.metadata?.harmony),ladders=new Map;
  let on=0,total=0,pieces=0;
  for(const note of motifNotes(motif)){
    if(!Number.isFinite(note.pitch)||isPercussion(note,settings.percussionChannel)||!(note.duration>0))continue;
    const start=note.on.time,end=note.endTime??start+note.duration*motif.timebase.ticksPerQuarterNote;
    const controls=settings.pitchModel==='held-controls'?note.controls.filter(c=>c.action===1&&c.time<end):[],cuts=[start,end];
    let lo=0,hi=segments.length;while(lo<hi){const mid=(lo+hi)>>>1;if(segments[mid].time<=start)lo=mid+1;else hi=mid;}
    for(let i=lo;i<segments.length&&segments[i].time<end;i++){if(++pieces>settings.maxPieces)throw new RangeError('Harmonic time-fit budget exceeded');cuts.push(segments[i].time);}
    for(const c of controls)if(c.time>start){if(++pieces>settings.maxPieces)throw new RangeError('Harmonic time-fit budget exceeded');cuts.push(c.time);}
    cuts.sort((a,b)=>a-b);let control=0,offset=0;
    for(let i=0;i+1<cuts.length;i++){
      const at=cuts[i],duration=cuts[i+1]-at;if(!duration)continue;
      if(++pieces>settings.maxPieces)throw new RangeError('Harmonic time-fit budget exceeded');
      while(control<controls.length&&controls[control].time<=at)offset=controls[control++].value;
      const segment=segmentAt(segments,at);if(!segment)continue;
      if(!ladders.has(segment))ladders.set(segment,harmonyLadder(segment.pool,settings));const ladder=ladders.get(segment);if(!ladder)continue;
      const pitch=note.pitch+offset,rung=ladder.nearest(pitch);total+=duration;if(Math.abs(pitch-ladder.pitchOf(rung))<=settings.tolerance)on+=duration;
    }
  }
  return {fit:total?on/total:null,judgedNoteTicks:total,compatibleNoteTicks:on,pieces,pitchModel:settings.pitchModel,kind:'integrated-harmonic-note-time'};
}
