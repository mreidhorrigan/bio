// The band's harmony before anyone has offered one, the chords a harmony source draws from a collection, and a bot's
// preference for a key.
//
// The owner, 1 October 2026: "Don't allow such hardcoded default chords, from harmonypulsebot or anyone; that sort of
// thing needs to be seed-derived." And: "A bot can have a preference for a certain key (especially with regard to
// instrument constraints), but not a chord progression, and the key preference cannot prevail every time." Every bot
// began from C, E flat, G and B flat (framework/agent.js), and mh_HarmonyPulseBOT built each progression from that pool
// and then from its own last chord, so 30 of the 33 études rendered from 28 to 30 September ran one chord succession
// whatever their seed, and the other 3 closed in C minor.
//
// - The opening (openingHarmony): a tonic, a collection and a chord drawn from the piece's seed alone, so every bot of
//   a piece starts in one harmony before any is heard, and two pieces start apart. The tonic is any of the twelve
//   classes; the collection comes from the whole space of collections (collection-space.js: moments of symmetry of any
//   generator, the symmetric collections, the harmonic series, the hexany, a sieve, rast, Bohlen-Pierce's modes); the
//   chord from the collection (drawChord).
// - A chord from a collection (drawChord): every s-th pitch of the collection as it lies over a register, k of them,
//   from a root drawn near the chord before. Counted in the collection's own steps, so it holds in any period and
//   tuning: one pitch, a dyad, a cluster (s = 1), a heptatonic collection's tertian stacks (s = 2), its quartal ones
//   (s = 3), a whole-tone scale's augmented triads, an octatonic's diminished sevenths. Drawn from the stacks the
//   collection has room for, never drawn and refused.
// - A key preference (preferredTonic): a bot whose instrument favours a key (a fixed kalimba's tines, a mode a bot was
//   built in) takes it at most KEY_PREFERENCE.most of the time, drawn from the seed; otherwise the band's opening tonic.
import {createRandomStream,randomAt} from '../random-source.js';
import {drawCollection,collectionPitches} from './collection-space.js';

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const OPENING=Object.freeze({
  // The opening's tonic: its class drawn, any of twelve, placed at or above this pitch (ours).
  tonicFrom:54,
  // The register its collection is laid over and its chord drawn in (ours: mh_HarmonyPulseBOT's).
  register:Object.freeze([48,76]),
  // Its chord's sizes, [notes, weight]: two to four, so a bot that arpeggiates the pool it starts with has more than one
  // pitch, and every bot hears it as a chord (five classes or more are heard as a collection: harmony-hearing.js) (ours).
  sizes:Object.freeze([[2,1],[3,3],[4,3]].map(Object.freeze)),
});
export const STACKS=Object.freeze({
  // [collection steps between a stack's neighbours, weight]: clusters, a heptatonic's thirds, its fourths (ours).
  steps:Object.freeze([[1,1],[2,4],[3,2]].map(Object.freeze)),
  // [notes, weight]: one pitch to four; five classes or more are heard as a collection, not a chord (harmony-hearing.js)
  // (ours).
  sizes:Object.freeze([[1,.4],[2,1],[3,3],[4,3]].map(Object.freeze)),
  // A root's weight falls by e for each this many of the register's pitches it lies from the chord before's lowest
  // (ours: near, as a voice-leading player moves, and never certain).
  reach:4,
  // The weight left to the chord before itself, drawn again (ours).
  repeat:.2,
});
// A preferred key's share of the draws at most (ours, below 1: "the key preference cannot prevail every time").
export const KEY_PREFERENCE=Object.freeze({most:.5});
const CACHED=64;

const modulo=(value,period)=>((value%period)+period)%period;
const weighted=(items,random)=>{let draw=random()*items.reduce((sum,item)=>sum+item.weight,0);for(const item of items){draw-=item.weight;if(draw<=0)return item}return items.at(-1)};
// The pitch of class `pc` (in semitones, any fraction) nearest `near`.
export const placeClass=(pc,near)=>{const up=modulo(pc-near,12);return +(near+(up>6?up-12:up)).toFixed(6)};

// A chord drawn from `pitches` (a collection laid over a register, ascending): {steps, sizes} as STACKS, `previous` the
// chord before (its lowest pitch draws the root near). `motion` ({interval, weight, width}, or null): a root moving by
// `interval` (semitones, any fraction) from the chord before's lowest pitch, in any octave, the likelier by `weight` (0
// to 1), its weight falling by e each `width` semitones off it -- as a jazz progression's roots fall by fifths
// (harmony-plan.js HARMONY_PLAN.jazz). Returns its pitches, ascending; [] from no pitches.
export function drawChord(pitches,random,{previous=null,steps=STACKS.steps,sizes=STACKS.sizes,reach=STACKS.reach,repeat=STACKS.repeat,motion=null}={}){
  const count=pitches.length;if(!count)return [];
  const stacks=[];
  for(const [step,stepWeight] of steps)for(const [size,sizeWeight] of sizes)if((size-1)*step<count)stacks.push({step,size,weight:stepWeight*sizeWeight});
  // A collection of one pitch has only that pitch, whatever was asked.
  if(!stacks.length)return [pitches[0]];
  const {step,size}=weighted(stacks,random),last=count-1-(size-1)*step,stackAt=root=>Array.from({length:size},(_,k)=>pitches[root+k*step]);
  const lowest=previous?.length?Math.min(...previous):null;
  let anchor=0;if(lowest!==null)for(let index=1;index<count;index++)if(Math.abs(pitches[index]-lowest)<Math.abs(pitches[anchor]-lowest))anchor=index;
  const same=chord=>previous?.length===chord.length&&chord.every((pitch,index)=>Math.abs(pitch-previous[index])<1e-6);
  const moved=root=>{if(lowest===null||!(motion?.weight>0))return 1;const off=modulo(pitches[root]-lowest-motion.interval,12),d=Math.min(off,12-off);return 1-motion.weight+motion.weight*Math.exp(-d/motion.width)};
  const roots=Array.from({length:last+1},(_,root)=>({root,weight:(lowest===null?1:Math.exp(-Math.abs(root-anchor)/reach))*(same(stackAt(root))?repeat:1)*moved(root)}));
  return stackAt(weighted(roots,random).root);
}

const openings=new Map;
// The piece's opening from its seed: {tonic, root (its class), collection, pitches (the collection over the register),
// chord}. The same seed gives the same opening to every bot that asks.
export function openingHarmony(seed){
  const key=String(seed);if(openings.has(key))return openings.get(key);
  const stream=createRandomStream(`${key}:opening-harmony`),random=()=>stream.next();
  const tonic=OPENING.tonicFrom+Math.floor(random()*12),collection=drawCollection(random),[low,high]=OPENING.register;
  const pitches=collectionPitches(collection,{tonic,low,high}),chord=drawChord(pitches,random,{sizes:OPENING.sizes});
  const opening=Object.freeze({tonic,root:modulo(tonic,12),collection:Object.freeze({...collection,system:Object.freeze([...collection.system])}),
    pitches:Object.freeze(pitches),chord:Object.freeze(chord)});
  openings.set(key,opening);if(openings.size>CACHED)openings.delete(openings.keys().next().value);
  return opening;
}

// The opening's chord (of: 'chord') or collection (of: 'collection') over [low, high]: every pitch of its classes there,
// in its collection's period. Where none falls in a narrow register, the chord's pitch nearest its middle.
export function poolOver(opening,[low,high],{of='chord'}={}){
  if(of==='collection')return collectionPitches(opening.collection,{tonic:opening.tonic,low,high});
  const period=opening.collection.period??12,out=new Set;
  for(const pitch of opening.chord)for(let at=pitch+Math.floor((low-pitch)/period)*period;at<=high+1e-9;at+=period)if(at>=low-1e-9)out.add(+at.toFixed(6));
  if(!out.size){const middle=(low+high)/2;let best=null;for(const pitch of opening.chord){const at=pitch+Math.round((middle-pitch)/period)*period;if(best===null||Math.abs(at-middle)<Math.abs(best-middle))best=at}out.add(+best.toFixed(6))}
  return [...out].sort((a,b)=>a-b);
}
// `voices` of poolOver's chord over [low, high], spread evenly across it (all of them where there are no more).
export function chordOver(opening,register,voices){
  const pool=poolOver(opening,register);if(pool.length<=voices||voices<2)return voices<2?pool.slice(0,Math.max(0,voices)):pool;
  return Array.from({length:voices},(_,index)=>pool[Math.round(index*(pool.length-1)/(voices-1))]);
}
// `count` chords from the opening's collection, the first its chord, each drawn near the one before: a progression for a
// bot that starts from one, the same for the whole band.
export function openingProgression(seed,count){
  const opening=openingHarmony(seed),stream=createRandomStream(`${seed}:opening-progression`),random=()=>stream.next(),chords=[[...opening.chord]];
  while(chords.length<count)chords.push(drawChord(opening.pitches,random,{previous:chords.at(-1)}));
  return chords.slice(0,Math.max(0,count));
}
// A tonic near `pitch` for a bot that prefers `pitch`'s class (`identity` names the bot): that class with probability
// `strength` (at most KEY_PREFERENCE.most), drawn from the seed; otherwise the band's opening root, placed nearest
// `pitch`.
export function preferredTonic(seed,{pitch,strength=KEY_PREFERENCE.most,identity=''}){
  const share=Math.max(0,Math.min(KEY_PREFERENCE.most,strength));
  if(randomAt(`${seed}:key-preference:${identity}`,0)<share)return pitch;
  return placeClass(openingHarmony(seed).root,pitch);
}
