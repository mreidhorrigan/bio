import { unitRandom } from './stochastic.js';

const finitePositive=values=>values.map(Number).filter(value=>Number.isFinite(value)&&value>0);

export function corpusDensity(record){
  const values=finitePositive(record?.values||record||[]),span=values.reduce((sum,value)=>sum+value,0);
  return span?values.length/span:0;
}

export function nearestCorpusRecords(records,target,limit=10,measure=corpusDensity){
  return records.map(record=>({record,distance:Math.abs(measure(record)-target)})).sort((a,b)=>a.distance-b.distance||a.record.key-b.record.key).slice(0,Math.max(1,limit)).map(item=>item.record);
}

export function chooseCorpusRecord(records,target,limit=10,measure=corpusDensity,random=unitRandom){
  const nearest=nearestCorpusRecords(records,target,limit,measure);
  return nearest[Math.min(nearest.length-1,Math.floor(random()*nearest.length))];
}

// A class's octaves inside a range are derived, not searched: for pitch p they are p + 12k for k from
// ceil((low - p)/12) to floor((high - p)/12), and the one nearest a target is that k clamped. Loops of +/-12 and fixed
// shifts of -8 to 8 octaves had reached only so far (the mathematical audit's H08).
const octaveNearest=(pitch,target,[low,high])=>{
  const least=Math.ceil((low-pitch)/12),most=Math.floor((high-pitch)/12);
  return least>most?null:pitch+12*Math.max(least,Math.min(most,Math.round((target-pitch)/12)));
};
// A note in the range, in its own class, as near the note as its octaves allow (for a note already in range, itself).
// A class that cannot sound in the range at all (a range narrower than an octave that misses it) is given the range's
// edge nearest the note, which changes its class: declared, not silent.
export function fitMidi(note,range=[48,84]){
  let value=Number(note);if(!Number.isFinite(value))value=60;
  if(value>=range[0]&&value<=range[1])return value;
  return octaveNearest(value,value,range)??Math.max(range[0],Math.min(range[1],value));
}

export function nearestPitchClass(note,pool,range=[48,84]){
  const pitches=pool.map(Number).filter(Number.isFinite);if(!pitches.length)return fitMidi(note,range);
  let best=fitMidi(pitches[0],range),distance=Math.abs(best-note);
  for(const pitch of pitches){const candidate=octaveNearest(pitch,note,range);if(candidate===null)continue;const next=Math.abs(candidate-note);if(next<distance){best=candidate;distance=next}}
  return best;
}

// Reconstruct a monophonic corpus phrase from the source duration and contour
// tables. Durations remain in quarter-note units, and the final event is clipped
// exactly at the requested boundary (the source patch's uneven-meter safeguard). Its `notePool` is the caller's harmony:
// there is no default chord (shared/opening-harmony.js).
export function generateCorpusPhrase(corpus,{beats=12,density=.55,notePool,range=[48,84],nearest=10,random=unitRandom}={}){
  const span=Math.max(.0625,Number(beats)||12),target=.3+Math.max(0,Math.min(1,Number(density)||0))*.5,durations=chooseCorpusRecord(corpus.onsetDurations,target,nearest,corpusDensity,random)?.values||[1],first=chooseCorpusRecord(corpus.firstBeatContours,target,nearest,record=>(record.values?.length||0)/Math.max(1,span),random)?.values||[0],continuation=chooseCorpusRecord(corpus.continuationContours,target,nearest,record=>(record.values?.length||0)/Math.max(1,span),random)?.values||[0],anchor=nearestPitchClass(60,notePool,range),events=[];let at=0,index=0;
  while(at<span&&index<4096){const duration=Math.min(span-at,Math.max(.0625,Number(durations[index%durations.length])||.5)),contour=index<first.length?first[index]:continuation[(index-first.length)%continuation.length],raw=anchor+(Number(contour)||0),note=nearestPitchClass(raw,notePool,range);events.push({at,duration,note,corpusDurationKey:durations.key});at+=duration;index++}
  return events;
}

export function weightedCorpusChoice(choices,random=unitRandom){const positive=choices.filter(choice=>choice.weight>0),source=positive.length?positive:choices,total=source.reduce((sum,choice)=>sum+Math.max(0,choice.weight),0);if(!source.length)return null;if(!total)return source[Math.min(source.length-1,Math.floor(random()*source.length))];let target=random()*total;for(const choice of source){target-=Math.max(0,choice.weight);if(target<=0)return choice}return source.at(-1)}

const parseNumbers=value=>String(value).trim().split(/\s+/).map(Number).filter(Number.isFinite);

export function generateRhythmicCorpusPhrase(corpus,{beats=16,density=.66,notePool,range=[48,84],random=unitRandom}={}){
  const sixteenths=Math.max(1,Math.ceil((Number(beats)||16)*4)),onsets=new Map(corpus.onsetChains.map(row=>[row.key,row.choices])),pitches=new Map(corpus.pitchChains.map(row=>[row.key,row.choices])),first=weightedCorpusChoice(corpus.pitchFirstBeats[0]?.choices||[],random),events=[];let onset='0 0 0 0',contour=first?.value||'0',anchor=nearestPitchClass(60,notePool,range),step=0;
  while(step<sixteenths){const onsetChoices=onsets.get(onset)||corpus.onsetChains[0]?.choices||[],proposal=weightedCorpusChoice(onsetChoices,random)?.value||onset;const cells=parseNumbers(proposal).slice(0,4);for(let index=0;index<4&&step+index<sixteenths;index++)if(cells[index]&&random()<=Math.max(.12,Math.min(1,density))){const offsets=parseNumbers(contour),raw=anchor+(offsets[index%Math.max(1,offsets.length)]||0),note=nearestPitchClass(raw,notePool,range);events.push({at:(step+index)/4,duration:.22,note,onsetState:proposal})}const pitchChoices=pitches.get(contour)||pitches.get(String(parseNumbers(contour).at(-1)??0))||corpus.pitchChains[0]?.choices||[];contour=weightedCorpusChoice(pitchChoices,random)?.value||contour;onset=proposal;step+=4}
  if(!events.length)events.push({at:0,duration:.22,note:anchor,onsetState:'musical-silence-guard'});
  return events;
}
