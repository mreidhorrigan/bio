// A sound's family (the supplement's S007): a graph round a source, each edge a transformation and what it keeps,
// weakens or replaces -- its attack spacing, its envelope, its inharmonic ratios, its context, its trajectory, its grain
// density, an association with an earlier event -- and the relation it is meant to make: authored hypotheses a listener
// may or may not hear, never measured recognition. A transformation is both a process (stretch by twelve) and a role
// (turn an impact into the field the next impact comes out of). The original and every stage are kept, so a later
// return can reveal the source: recovery after a lossy operation is replaying what was kept, never inverting the loss.
export const FEATURES=Object.freeze(['attack','envelope','spectrum','pitch','context','trajectory','density','association']);
export class SoundFamily{
  constructor(root){this.root=root.id;this.nodes=new Map([[root.id,{material:root,depth:0}]]);this.edges=[]}
  // A stage made from `parent` (an id) by `transform` (its id and parameters): what it keeps and changes (FEATURES),
  // and the relation intended.
  add(child,{parent,transform,parameters={},retained=[],changed=[],relation}){
    if(!this.nodes.has(parent))throw new RangeError(`${child.id}: its parent ${parent} is not in the family`);
    for(const feature of [...retained,...changed])if(!FEATURES.includes(feature))throw new RangeError(`no feature "${feature}" (${FEATURES.join(', ')})`);
    this.nodes.set(child.id,{material:child,depth:this.nodes.get(parent).depth+1});
    this.edges.push(Object.freeze({from:parent,to:child.id,transform,parameters:Object.freeze({...parameters}),retained:Object.freeze([...retained]),changed:Object.freeze([...changed]),relation,confidence:'authored'}));
    return this;
  }
  // The features a stage keeps of the source, through every edge from the root to it.
  kept(id){
    let features=new Set(FEATURES),at=id;
    while(at!==this.root){const edge=this.edges.find(e=>e.to===at);for(const feature of edge.changed)features.delete(feature);at=edge.from}
    return [...features];
  }
  // A stage to return to for a goal: 'recognizable' (the most kept, the nearest the source: the source itself where it
  // is in the family) or 'abstract' (the fewest kept, the furthest), ties by id.
  returnCandidate(goal='recognizable'){
    const ranked=[...this.nodes.entries()].map(([id,{depth}])=>({id,depth,kept:this.kept(id).length}));
    ranked.sort(goal==='abstract'?(a,b)=>a.kept-b.kept||b.depth-a.depth||a.id.localeCompare(b.id):(a,b)=>b.kept-a.kept||a.depth-b.depth||a.id.localeCompare(b.id));
    return ranked[0].id;
  }
}
