// Acousmatic material: whole recordings, their regions, and everything made from them, with where each came from (the
// rap and acousmatic supplement's S001 and S003; the owner, 1 October 2026: "the items regarding ... challenging
// aesthetics (acousmatic, rap)").
//
// A SoundMaterial is a recording (or a sealed capture, capture.js) at its root, with optional regions beneath it: a long
// ambience is not a badly segmented note, and slicing never throws its context away, so a sound can return as a place,
// an abstract timbre, or anything between, without losing its history. What an author says a sound is (its source tags)
// is kept apart from what is measured of it, and an inferred label never overwrites either.
//
// Its rights travel with it. A recording enters only under terms that allow the use asked (ingest): owner-recorded or
// consented material and individually approved open recordings (CC0, CC BY), or a source this Mac may use and never
// ship (`local`: the Iowa recordings' terms). A material made from others (derive) keeps every parent, the operation and
// its version, its parameters and its seed, and may be used only as all its parents may: a deeply processed sound still
// traces to every source, and is no more distributable than the least of them.
export const USES=Object.freeze(['analysis','render-local','distribute']);
// What each licence allows: `distribute` (into a shipped pack or build), `render` (heard in this Mac's renders), and
// whether credit is owed.
export const LICENCES=Object.freeze({
  'CC0-1.0':Object.freeze({distribute:true,render:true,attribution:false}),
  'CC-BY-4.0':Object.freeze({distribute:true,render:true,attribution:true}),
  'owner-recorded':Object.freeze({distribute:true,render:true,attribution:false}),
  // A custom permission or a free but closed source (CLAUDE.md): this Mac's renders only, never shipped.
  'local':Object.freeze({distribute:false,render:true,attribution:true}),
});
export class MaterialError extends RangeError{constructor(message){super(message);this.name='MaterialError'}}
const fail=message=>{throw new MaterialError(message)};

// FNV-1a over a material's samples (as float32 bytes) and its rate: a content hash for identity and cache keys
// (cache.js adds SHA-256 over descriptors). Deterministic on every host that holds the same samples.
export function contentHash(channels,sampleRate){
  let h1=0x811c9dc5,h2=0x01000193;
  const mix=byte=>{h1=Math.imul(h1^byte,16777619)>>>0;h2=Math.imul(h2^byte^(h1>>>7),2246822519)>>>0};
  for(const byte of new Uint8Array(new Float64Array([sampleRate,channels.length]).buffer))mix(byte);
  for(const channel of channels)for(const byte of new Uint8Array(channel.buffer,channel.byteOffset,channel.byteLength))mix(byte);
  return `fnv:${h1.toString(16).padStart(8,'0')}${h2.toString(16).padStart(8,'0')}`;
}
const rightsOf=licence=>{const terms=LICENCES[licence];if(!terms)fail(`no terms known for the licence "${licence}"`);return terms};

// A recording's material. `channels`: Float32Arrays (mono for transformation: spatial encoding comes after, the
// handoff's rule); `source`: {kind ('recording', 'capture', 'derived'), title, creator?, url?, licence, attribution?,
// captureStart?, captureEnd?, channelConvention?}; `tags`: what an author says it is; `measured`: what was measured.
export function material({id,channels,sampleRate,source,tags=[],measured={},parents=null,operation=null}){
  if(typeof id!=='string'||!id)fail('a material needs an id');
  if(!Array.isArray(channels)||!channels.length||!channels.every(c=>c instanceof Float32Array&&c.length===channels[0].length))fail(`${id}: channels are Float32Arrays of one length`);
  if(!(sampleRate>0))fail(`${id}: a sample rate`);
  const terms=parents?parents.reduce((all,parent)=>({distribute:all.distribute&&parent.rights.distribute,render:all.render&&parent.rights.render,attribution:all.attribution||parent.rights.attribution}),{distribute:true,render:true,attribution:false})
    :rightsOf(source?.licence);
  return Object.freeze({id,channels,sampleRate,frames:channels[0].length,seconds:channels[0].length/sampleRate,source:Object.freeze({...source}),
    tags:Object.freeze([...tags]),measured:Object.freeze({...measured}),inferred:Object.freeze([]),rights:Object.freeze({...terms}),
    hash:contentHash(channels,sampleRate),regions:Object.freeze([]),parents:parents?Object.freeze(parents.map(parent=>Object.freeze({id:parent.id,hash:parent.hash,...(parent.region?{region:parent.region}:{})}))):null,
    operation:operation?Object.freeze({...operation}):null});
}
// A region of a material: frames [start, end) inside it, its parent region if any, how sure its bounds are. The whole
// recording stays whole: a region only names part of it.
export function makeRegion(source,{id,start,end,parent=null,confidence=1,label=null}){
  if(!(Number.isInteger(start)&&Number.isInteger(end)&&start>=0&&end>start&&end<=source.frames))fail(`${source.id}: region ${start}..${end} is not inside its ${source.frames} frames`);
  if(parent&&!(start>=parent.start&&end<=parent.end))fail(`${source.id}: region ${id} leaves its parent ${parent.id}`);
  return Object.freeze({id,materialId:source.id,start,end,parent:parent?.id??null,confidence,label});
}
// A material's frames for a region (a view, never a copy): the samples a transformation reads.
export const regionSamples=(source,region,channel=0)=>source.channels[channel].subarray(region?.start??0,region?.end??source.frames);
// A label inferred from analysis, with its evidence, beside the author's tags and the measures, never over them.
export const withInferred=(source,label,evidence)=>Object.freeze({...source,inferred:Object.freeze([...source.inferred,Object.freeze({label,evidence})])});

// A recording admitted for a use, or quarantined with the reason: its terms must allow the use, and its origin be known.
// -> {approved: true, material} | {approved: false, reason}.
export function ingest(asset,use){
  if(!USES.includes(use))fail(`a use is ${USES.join(', ')}`);
  const terms=LICENCES[asset.source?.licence];
  if(!terms)return {approved:false,reason:`its licence (${asset.source?.licence??'none'}) is not one whose terms are known`};
  if(!asset.source?.title||!(asset.source?.url||asset.source?.creator))return {approved:false,reason:'its origin (title, and creator or source) is not recorded'};
  if(terms.attribution&&!asset.source.attribution)return {approved:false,reason:'its licence asks for credit and no attribution is recorded'};
  if(use==='distribute'&&!terms.distribute)return {approved:false,reason:`${asset.source.licence} material may not be distributed`};
  if(use==='render-local'&&!terms.render)return {approved:false,reason:`${asset.source.licence} material may not be rendered`};
  return {approved:true,material:material(asset)};
}
// A material made from others by an operation: its parents (each {material, region?}), the operation {id, version},
// its parameters and seed, kept whole; its rights the parents' least.
export function derive({id,channels,sampleRate,parents,operation,parameters={},seed=null,tags=[]}){
  if(!parents?.length)fail(`${id}: a derived material needs its parents`);
  if(!operation?.id||operation.version==null)fail(`${id}: an operation names its id and version`);
  const made=material({id,channels,sampleRate,source:{kind:'derived',title:id},tags,parents:parents.map(({material:parent,region})=>({id:parent.id,hash:parent.hash,rights:parent.rights,region:region?{start:region.start,end:region.end}:null})),
    operation:{...operation,parameters:Object.freeze({...parameters}),seed}});
  return made;
}
// Every recording a material comes from, through all its ancestors (`library`: id -> material).
export function provenanceOf(source,library){
  if(!source.parents)return [source.id];
  const roots=new Set;
  for(const parent of source.parents){const known=library.get(parent.id);if(!known)fail(`${source.id}: its parent ${parent.id} is not in the library`);for(const root of provenanceOf(known,library))roots.add(root)}
  return [...roots];
}
