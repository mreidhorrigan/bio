// A gesture's trajectory in its own time (the supplement's S011): level, density, spectral spread, motion and identity
// (how much of one material against another) as curves over the gesture's progress, its clock its own -- seconds (free
// time, which a section's tempo change does not touch), a beat clock (a tempo map's), or progress from a condition
// ("after the texture before has decayed"). The downbeat-marked gesture of the dance-music policy stays where it is
// wanted; this is the acousmatic one: gradual, unmetered, asynchronous, anchored to what is heard. Layers keep their own
// clocks; a landmark may bring them together without one subdivision for all.
export const CLOCKS=Object.freeze(['seconds','beats']);
export const CONTROLS=Object.freeze(['level','density','spread','pan','identity']);
const curveAt=(points,u)=>{if(!points?.length)return null;let k=0;while(k+1<points.length&&points[k+1][0]<=u)k++;const [u0,v0]=points[k],[u1,v1]=points[k+1]??points[k];return u1>u0?v0+(v1-v0)*(u-u0)/(u1-u0):v0};
// A gesture: {clock, start (in its clock's units), length (likewise), curves: {control: [[progress, value], ...]}}.
export function gesture({clock='seconds',start,length,curves}){
  if(!CLOCKS.includes(clock))throw new RangeError(`a gesture's clock is ${CLOCKS.join(' or ')}`);
  if(!(Number.isFinite(start)&&length>0))throw new RangeError('a gesture needs its start and a length');
  for(const name of Object.keys(curves))if(!CONTROLS.includes(name))throw new RangeError(`no control "${name}"`);
  return Object.freeze({clock,start,length,curves:Object.freeze({...curves})});
}
// Its progress (0 to 1, else null outside it) at a time: seconds of its own clock, or a beat clock's position from
// `beatsAt(seconds)` (a tempo map). A free-time gesture's progress is the same whatever a tempo does.
export function progressAt(g,seconds,{beatsAt=null}={}){
  const t=g.clock==='seconds'?seconds:beatsAt?.(seconds);
  if(!Number.isFinite(t))return null;
  const u=(t-g.start)/g.length;return u<0||u>1?null:u;
}
// Its controls at a progress: each curve's value there.
export function controlsAt(g,u){return Object.fromEntries(Object.entries(g.curves).map(([name,points])=>[name,curveAt(points,u)]))}
