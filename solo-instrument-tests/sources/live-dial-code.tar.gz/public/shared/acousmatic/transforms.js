// Acousmatic transformations, typed (the supplement's S014-S017 and S024): each a TransformSpec saying what it reads
// and makes, what of its source it needs (`context`: 'causal', a sound so far, or 'whole', its whole region -- a reverse
// cannot begin before its source has ended), how it changes duration and how its output's time maps to its source's,
// its tail, and whether it is seeded. A transformation is applied only through its spec (apply), which checks its
// inputs and parameters (finite, in range) before anything is computed. Mono throughout: spatial placement comes after
// (gesture.js), as the handoff's rule has it, until a multichannel behaviour is qualified.
//
// The edits (S015): cut, reverse, repeat and join, their boundaries exact to the sample; a join crossfades for the
// correlation of its two sides (the gains hold the level for any correlation; shared/sample-loop.js's law), and a hard
// cut stays a cut, a designed edge rather than a glitch. Granulation (S016): grains each keyed to their own number,
// so the same gesture and seed give the same cloud whatever the block size, density, grain length, position in the
// source and rate each its own control, their sum kept at the source's level for uncorrelated grains. Stretching
// (S017): the attack kept as it was, the body stretched by WSOLA (each output frame the input frame nearest its place
// whose waveform best continues the last); a stretch never claims a playback-rate change keeps pitch
// (time-transformations.js). Convolution (S024): a room's or another sound's response, by FFT overlap-add, its output
// N + M - 1 frames long, the whole tail kept.
import {fftInPlace} from '../grains/fft.js';

export class TransformError extends RangeError{constructor(message){super(message);this.name='TransformError'}}
const fail=message=>{throw new TransformError(message)};
const clamp=(x,lo,hi)=>Math.min(hi,Math.max(lo,x));

// A seeded random source keyed to a string: the same key, the same numbers, on every host.
export function keyedRandom(key){
  let h=2166136261;for(const c of String(key)){h^=c.charCodeAt(0);h=Math.imul(h,16777619)>>>0}
  let s=h||1;return ()=>{s^=s<<13;s>>>=0;s^=s>>>17;s^=s<<5;s>>>=0;return s/4294967296};
}
const hann=n=>{const w=new Float32Array(n);for(let i=0;i<n;i++)w[i]=.5-.5*Math.cos(2*Math.PI*(i+.5)/n);return w};

// The correlation of two equal-length stretches (-1 to 1).
export function correlation(a,b){let ab=0,aa=0,bb=0;for(let i=0;i<a.length;i++){ab+=a[i]*b[i];aa+=a[i]*a[i];bb+=b[i]*b[i]}return aa>0&&bb>0?ab/Math.sqrt(aa*bb):0}
// A crossfade's gains at t (0 to 1) holding the level for sides that correlate by `rho` (equal gain at 1, equal power at
// 0); near -1 no gains can (the sides cancel), and an equal-power fade is used and said.
export function joinGains(t,rho){const level=Math.sqrt((1-t)**2+t**2+2*rho*t*(1-t));return [(1-t)/level,t/level]}

const SPECS={
  cut:{version:1,context:'causal',params:{start:'frames',end:'frames'},duration:(p)=>p.end-p.start,
    run:([x],p)=>({samples:x.slice(p.start,p.end),map:[{out:[0,p.end-p.start],source:[p.start,p.end],direction:1}]})},
  reverse:{version:1,context:'whole',params:{},duration:(p,n)=>n,
    run:([x])=>{const y=new Float32Array(x.length);for(let i=0;i<x.length;i++)y[i]=x[x.length-1-i];return {samples:y,map:[{out:[0,x.length],source:[0,x.length],direction:-1}]}}},
  repeat:{version:1,context:'whole',params:{times:'count'},duration:(p,n)=>n*p.times,
    run:([x],p)=>{const y=new Float32Array(x.length*p.times);for(let k=0;k<p.times;k++)y.set(x,k*x.length);return {samples:y,map:Array.from({length:p.times},(_,k)=>({out:[k*x.length,(k+1)*x.length],source:[0,x.length],direction:1}))}}},
  // Two sounds joined: `fade` frames of the first's end over the second's start, at the gains for their measured
  // correlation; `fade` 0 a hard cut, kept as designed.
  join:{version:1,context:'whole',inputs:2,params:{fade:'frames'},duration:(p,n,m)=>n+m-p.fade,
    run:([a,b],p)=>{
      const fade=p.fade,y=new Float32Array(a.length+b.length-fade);y.set(a.subarray(0,a.length-fade),0);
      const rho=fade?correlation(a.subarray(a.length-fade),b.subarray(0,fade)):0,cancelled=rho<-.9;
      for(let i=0;i<fade;i++){const t=(i+1)/(fade+1),[ga,gb]=cancelled?[Math.cos(t*Math.PI/2),Math.sin(t*Math.PI/2)]:joinGains(t,rho);y[a.length-fade+i]=a[a.length-fade+i]*ga+b[i]*gb}
      y.set(b.subarray(fade),a.length);
      return {samples:y,map:[{out:[0,a.length],source:[0,a.length],input:0,direction:1},{out:[a.length-fade,y.length],source:[0,b.length],input:1,direction:1}],
        notes:{correlation:+rho.toFixed(4),...(cancelled?{cancelled:'the sides nearly cancel: an equal-power fade'}:{}),...(fade?{}:{edge:'a hard cut, designed'})}};
    }},
  // A level over the sound: [[share of the sound (0 to 1), gain], ...], joined linearly.
  envelope:{version:1,context:'causal',params:{points:'points'},duration:(p,n)=>n,
    run:([x],p)=>{const pts=p.points,y=new Float32Array(x.length);let k=0;
      for(let i=0;i<x.length;i++){const u=i/Math.max(1,x.length-1);while(k+1<pts.length&&pts[k+1][0]<=u)k++;const [u0,g0]=pts[k],[u1,g1]=pts[k+1]??pts[k];y[i]=x[i]*(u1>u0?g0+(g1-g0)*(u-u0)/(u1-u0):g0)}
      return {samples:y,map:[{out:[0,x.length],source:[0,x.length],direction:1}]}}},
  // The playback rate changed: time and pitch together, by `rate` (2 an octave up and half as long); never said to
  // keep pitch (time-transformations.js 'playback-rate').
  rate:{version:1,context:'whole',params:{rate:'ratio'},duration:(p,n)=>Math.floor(n/p.rate),
    run:([x],p)=>{const n=Math.floor(x.length/p.rate),y=new Float32Array(n);for(let i=0;i<n;i++){const s=i*p.rate,k=Math.floor(s),f=s-k;y[i]=(x[k]??0)*(1-f)+(x[k+1]??x[k]??0)*f}
      return {samples:y,map:[{out:[0,n],source:[0,x.length],direction:1,rate:p.rate}],notes:{pitch:`${(12*Math.log2(p.rate)).toFixed(2)} semitones, with time`}}}},
  // A grain cloud, `seconds` long, from its source: `density` grains a second, each `grainSeconds` long (a Hann window),
  // read from where `position` (a share of the source, 0 to 1, over the cloud's progress: [[progress, position], ...])
  // says plus or minus `spread`, at `rate` (its own playback rate, time and pitch together) times 2^(±jitter/12).
  // Grain k is drawn from keyedRandom(`${seed}:${k}`), so its place, read point and rate are its own. Their sum is kept
  // at the source's level for uncorrelated grains: divided by the root of their mean overlap.
  granulate:{version:1,context:'whole',seeded:true,params:{seconds:'seconds',density:'rate',grainSeconds:'seconds',position:'points',spread:'share',rate:'ratio',jitter:'semitones'},
    duration:(p,n,m,sr)=>Math.round(p.seconds*sr),
    run:([x],p,{seed,sampleRate})=>{
      const n=Math.round(p.seconds*sampleRate),y=new Float32Array(n),g=Math.max(16,Math.round(p.grainSeconds*sampleRate)),w=hann(g);
      const count=Math.max(1,Math.round(p.density*p.seconds)),overlap=Math.max(1,p.density*p.grainSeconds),gain=1/Math.sqrt(overlap);
      const positionAt=u=>{const pts=p.position;let k=0;while(k+1<pts.length&&pts[k+1][0]<=u)k++;const [u0,v0]=pts[k],[u1,v1]=pts[k+1]??pts[k];return u1>u0?v0+(v1-v0)*(u-u0)/(u1-u0):v0};
      for(let k=0;k<count;k++){
        const random=keyedRandom(`${seed}:${k}`),at=Math.floor(random()*Math.max(1,n-g)),u=at/Math.max(1,n);
        const rate=p.rate*2**(((random()*2-1)*p.jitter)/12),read=clamp(positionAt(u)+(random()*2-1)*p.spread,0,1)*Math.max(0,x.length-g*rate-1);
        for(let i=0;i<g&&at+i<n;i++){const s=read+i*rate,j=Math.floor(s),f=s-j;y[at+i]+=gain*w[i]*((x[j]??0)*(1-f)+(x[j+1]??0)*f)}
      }
      return {samples:y,map:[{out:[0,n],source:[0,x.length],direction:0,note:'grains'}],notes:{grains:count,overlap:+overlap.toFixed(2)}};
    }},
  // The sound stretched by `ratio` (2 twice as long), its attack (`attackSeconds`, else measured: where it first comes
  // within 3 dB of its peak, at most a third of a second) kept as it was, the rest by WSOLA: 40 ms windows at half
  // overlap, each placed where its waveform best continues the output, within 10 ms of its nominal place.
  stretch:{version:1,context:'whole',params:{ratio:'ratio'},optional:{attackSeconds:'seconds'},duration:(p,n)=>Math.round(n*p.ratio),
    run:([x],p,{sampleRate})=>{
      const attack=attackOf(x,sampleRate,p.attackSeconds),win=Math.round(.04*sampleRate),hop=win>>1,search=Math.round(.01*sampleRate),w=hann(win);
      const body=x.subarray(attack),out=Math.round(body.length*p.ratio),y=new Float32Array(attack+out+win),norm=new Float32Array(y.length);
      y.set(x.subarray(0,attack));for(let i=0;i<attack;i++)norm[i]=1;
      let previous=-hop;
      for(let o=0;o<out;o+=hop){
        const nominal=Math.round(o/p.ratio);let best=clamp(nominal,0,Math.max(0,body.length-win)),bestScore=-Infinity;
        if(o>0)for(let d=-search;d<=search;d+=2){const s=clamp(nominal+d,0,Math.max(0,body.length-win));let score=0;for(let i=0;i<hop;i+=2)score+=(body[s+i]??0)*(body[previous+hop+i]??0);if(score>bestScore){bestScore=score;best=s}}
        for(let i=0;i<win;i++){y[attack+o+i]+=w[i]*(body[best+i]??0);norm[attack+o+i]+=w[i]}
        previous=best;
      }
      const n=attack+out;for(let i=attack;i<n;i++)if(norm[i]>1e-3)y[i]/=norm[i];
      return {samples:y.subarray(0,n).slice(),map:[{out:[0,attack],source:[0,attack],direction:1},{out:[attack,n],source:[attack,x.length],direction:1,rate:1/p.ratio}],notes:{attackFrames:attack,method:'wsola'}};
    }},
  // The first sound convolved with the second (a room's response, or another sound: cross-synthesis), by FFT
  // overlap-add; its output the full N + M - 1 frames, the tail whole. `normalize`: the response scaled to unit energy.
  convolve:{version:1,context:'whole',inputs:2,params:{},optional:{normalize:'flag'},duration:(p,n,m)=>n+m-1,tail:(p,n,m)=>m-1,
    run:([x,h],p)=>{
      let response=h;if(p.normalize){let e=0;for(const v of h)e+=v*v;const s=e>0?1/Math.sqrt(e):1;response=Float32Array.from(h,v=>v*s)}
      return {samples:convolve(x,response),map:[{out:[0,x.length+h.length-1],source:[0,x.length],direction:1,note:'every output frame from every earlier input frame'}],notes:{tailFrames:h.length-1}};
    }},
};
function attackOf(x,sampleRate,given){
  if(Number.isFinite(given))return clamp(Math.round(given*sampleRate),0,x.length);
  const frame=Math.round(.005*sampleRate),levels=[];for(let i=0;i+frame<=x.length;i+=frame){let s=0;for(let j=i;j<i+frame;j++)s+=x[j]*x[j];levels.push(s/frame)}
  const peak=Math.max(0,...levels),k=levels.findIndex(level=>level>=peak/2);
  return clamp((k<0?0:k)*frame,0,Math.min(x.length,Math.round(sampleRate/3)));
}
// Linear convolution by FFT overlap-add.
export function convolve(x,h){
  const n=x.length,m=h.length;if(!n||!m)return new Float32Array(0);const out=new Float32Array(n+m-1);
  let size=1;while(size<2*m)size<<=1;const block=size-m+1;
  const hr=new Float64Array(size),hi=new Float64Array(size);hr.set(h);fftInPlace(hr,hi);
  const re=new Float64Array(size),im=new Float64Array(size);
  for(let start=0;start<n;start+=block){
    re.fill(0);im.fill(0);for(let i=0;i<block&&start+i<n;i++)re[i]=x[start+i];
    fftInPlace(re,im);
    for(let k=0;k<size;k++){const a=re[k],b=im[k],c=hr[k],d=hi[k];re[k]=a*c-b*d;im[k]=-(a*d+b*c)}
    // (The inverse by the forward transform of the conjugate, conjugated back and scaled.)
    fftInPlace(re,im);
    for(let i=0;i<size&&start+i<out.length;i++)out[start+i]+=re[i]/size;
  }
  return out;
}

// The registry's specs, frozen, each with its id: what a planner reads to know what a transformation needs and does.
// (`duration(parameters, frames, framesOfSecond, sampleRate)`: its output's length; a stretch's, its attack aside.)
export const TRANSFORMS=Object.freeze(Object.fromEntries(Object.entries(SPECS).map(([id,spec])=>[id,Object.freeze({id,version:spec.version,context:spec.context,inputs:spec.inputs??1,duration:spec.duration,
  params:Object.freeze({...spec.params}),optional:Object.freeze({...(spec.optional??{})}),seeded:Boolean(spec.seeded),deterministic:true,channels:'mono'})])));

const KINDS={frames:v=>Number.isInteger(v)&&v>=0,count:v=>Number.isInteger(v)&&v>=1,ratio:v=>Number.isFinite(v)&&v>0,seconds:v=>Number.isFinite(v)&&v>0,rate:v=>Number.isFinite(v)&&v>0,
  share:v=>Number.isFinite(v)&&v>=0&&v<=1,semitones:v=>Number.isFinite(v)&&v>=0,flag:v=>typeof v==='boolean',
  points:v=>Array.isArray(v)&&v.length>0&&v.every(p=>Array.isArray(p)&&p.length===2&&p.every(Number.isFinite))};
// A transformation applied: its inputs (Float32Arrays, mono) checked against its spec, its parameters each of its kind
// and present, a seeded one given its seed. -> {samples, map (output time to source time), notes, spec}.
export function apply(id,inputs,parameters={},{seed=null,sampleRate=48000}={}){
  const spec=SPECS[id];if(!spec)fail(`there is no transformation "${id}"`);
  const wanted=spec.inputs??1;if(!Array.isArray(inputs)||inputs.length!==wanted||!inputs.every(x=>x instanceof Float32Array))fail(`${id} takes ${wanted} mono input${wanted>1?'s':''} (Float32Array)`);
  for(const [name,kind] of Object.entries(spec.params))if(!KINDS[kind](parameters[name]))fail(`${id}: ${name} must be ${kind}, not ${JSON.stringify(parameters[name])}`);
  for(const [name,kind] of Object.entries(spec.optional??{}))if(parameters[name]!==undefined&&!KINDS[kind](parameters[name]))fail(`${id}: ${name} must be ${kind}`);
  if(spec.seeded&&seed==null)fail(`${id} is seeded: give it its seed`);
  if(id==='cut'&&parameters.end>inputs[0].length)fail('cut: past the end of its source');
  if(id==='join'&&parameters.fade>Math.min(inputs[0].length,inputs[1].length))fail('join: a fade longer than a side');
  const result=spec.run(inputs,parameters,{seed,sampleRate});
  for(const v of result.samples)if(!Number.isFinite(v))fail(`${id} made a sample that is not finite`);
  return {...result,spec:TRANSFORMS[id]};
}
