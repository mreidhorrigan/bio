// An acousmatic piece's three graphs, kept apart (the supplement's S009, X001-X003): the musical one (relations between
// events: an answer, a residue, a concealment, a return, an accumulation, an interruption), the transformation one
// (typed operations and the materials they read: acyclic, a feedback process only as one atomic node), and the
// execution one (those operations on workers, against deadlines). Musical succession is not computational order: a
// late sound may have to be made before an early one.
//
// The musical graph's times are a simple temporal network (X001): each relation a bound on the time between two events
// (lower <= t_to - t_from <= upper), solved by Bellman-Ford; inconsistent bounds are refused, and the times returned
// satisfy every bound. It is not a schedule of resources, and an event of uncertain length (a human breath, a capture
// not yet closed) is not made controllable by it.
export class GraphError extends RangeError{constructor(message){super(message);this.name='GraphError'}}
const fail=message=>{throw new GraphError(message)};

// The relations an acousmatic plan uses, each with its default bounds (seconds from the first event's start to the
// second's), authored: what each relation means for when the second may come.
export const RELATIONS=Object.freeze({
  answer:Object.freeze({lower:.5,upper:6}),          // the second follows the first, soon after
  residue:Object.freeze({lower:.2,upper:3}),         // the second is what the first leaves: within its decay
  conceal:Object.freeze({lower:0,upper:1}),          // the second enters under the first, hidden by it
  return:Object.freeze({lower:20,upper:Infinity}),   // the second brings the first back, much later
  accumulate:Object.freeze({lower:0,upper:4}),       // the second adds to the first, overlapping
  interrupt:Object.freeze({lower:.05,upper:2}),      // the second cuts across the first
});

// The times of `events` (ids) satisfying every bound [{from, to, lower, upper}] (seconds; upper may be Infinity), the
// earliest such, the first event at 0. -> {times: Map(id -> s)} or {inconsistent: true, cycle: [ids]}.
export function solveTemporal(events,bounds){
  const index=new Map(events.map((id,k)=>[id,k])),n=events.length,edges=[];
  for(const {from,to,lower=-Infinity,upper=Infinity} of bounds){
    if(!index.has(from)||!index.has(to))fail(`a bound between ${from} and ${to} names an event not planned`);
    if(!(lower<=upper))fail(`a bound from ${from} to ${to} whose lower (${lower}) is over its upper (${upper})`);
    if(Number.isFinite(upper))edges.push([index.get(from),index.get(to),upper]);
    if(Number.isFinite(lower))edges.push([index.get(to),index.get(from),-lower]);
  }
  // (The earliest times: shortest distances in the reversed network from a source joined to every event at 0, negated;
  // each edge u -> v of weight w, t_v - t_u <= w, is relaxed as v -> u.)
  const dist=new Float64Array(n),pred=new Int32Array(n).fill(-1),earliest=()=>{const low=Math.min(...dist.map(d=>-d));return {times:new Map(events.map((id,k)=>[id,+(-dist[k]-low).toFixed(9)]))}};
  for(let pass=0;pass<n;pass++){
    let changed=false;
    for(const [u,v,w] of edges)if(dist[v]+w<dist[u]-1e-12){dist[u]=dist[v]+w;pred[u]=v;changed=true}
    if(!changed)return earliest();
  }
  for(const [u,v,w] of edges)if(dist[v]+w<dist[u]-1e-12){
    let k=u;for(let i=0;i<n;i++)k=pred[k];const cycle=[];let x=k;do{cycle.push(events[x]);x=pred[x]}while(x!==k&&cycle.length<=n);
    return {inconsistent:true,cycle};
  }
  return earliest();
}
// A plan's relations as bounds: each relation's own (RELATIONS) unless it gives its own lower or upper.
export function relationBounds(relations){
  return relations.map(({from,to,kind,lower,upper})=>{const known=RELATIONS[kind];if(!known)fail(`no relation "${kind}"`);return {from,to,lower:lower??known.lower,upper:upper??known.upper,kind}});
}

// The transformation graph's nodes {id, inputs: [ids], cost (s), deadline? (s), available? (s, a source's: when it
// exists), feedback? (true for an atomic stateful process)}: in an order every node follows its inputs. A cycle among
// them is refused; a feedback process is one node, never a loop of nodes.
export function topologicalOrder(nodes){
  const byId=new Map(nodes.map(node=>[node.id,node])),state=new Map,order=[];
  const visit=(id,path)=>{
    if(state.get(id)===2)return;if(state.get(id)===1)fail(`the transformations form a cycle: ${[...path,id].join(' -> ')} (a feedback process must be one node)`);
    const node=byId.get(id);if(!node)fail(`${path.at(-1)} reads ${id}, which is not in the graph`);
    state.set(id,1);for(const input of node.inputs??[])visit(input,[...path,id]);state.set(id,2);order.push(node);
  };
  for(const node of [...nodes].sort((a,b)=>String(a.id).localeCompare(String(b.id))))visit(node.id,[]);
  return order;
}
// The latest each node may start and finish to meet every deadline downstream, and the earliest it can, given when its
// sources exist (X002): {latestStart, latestFinish, earliestStart, earliestFinish} by id, and those that cannot meet
// their deadlines however many workers there are. `transfer(from, to)`: seconds between them.
export function deadlines(nodes,{transfer=()=>0}={}){
  const order=topologicalOrder(nodes),children=new Map(nodes.map(node=>[node.id,[]]));
  for(const node of nodes)for(const input of node.inputs??[])children.get(input).push(node.id);
  const out=new Map(nodes.map(node=>[node.id,{latestFinish:node.deadline??Infinity,earliestStart:node.available??0}]));
  for(const node of [...order].reverse()){
    const entry=out.get(node.id);
    for(const child of children.get(node.id))entry.latestFinish=Math.min(entry.latestFinish,out.get(child).latestStart-transfer(node.id,child));
    entry.latestStart=entry.latestFinish-(node.cost??0);
  }
  for(const node of order){
    const entry=out.get(node.id);
    for(const input of node.inputs??[])entry.earliestStart=Math.max(entry.earliestStart,out.get(input).earliestFinish+transfer(input,node.id));
    entry.earliestFinish=entry.earliestStart+(node.cost??0);
  }
  return {times:out,late:nodes.filter(node=>out.get(node.id).earliestFinish>out.get(node.id).latestFinish+1e-9).map(node=>node.id)};
}
// The nodes on `workers` workers, non-preemptive, the ready one with least slack first, ties by id (X003): {id ->
// {worker, start, finish}}, and those that missed their deadline. A schedule the critical path alone would pass may
// still miss here, where jobs compete.
export function listSchedule(nodes,{workers=1,transfer=()=>0}={}){
  const {times}=deadlines(nodes,{transfer}),byId=new Map(nodes.map(node=>[node.id,node])),done=new Map,free=Array(workers).fill(0),placed=new Map;
  const remaining=new Set(nodes.map(node=>node.id));
  while(remaining.size){
    const ready=[...remaining].filter(id=>(byId.get(id).inputs??[]).every(input=>done.has(input)));
    ready.sort((a,b)=>times.get(a).latestStart-times.get(b).latestStart||a.localeCompare(b));
    const id=ready[0],node=byId.get(id),worker=free.indexOf(Math.min(...free));
    const start=Math.max(free[worker],node.available??0,...(node.inputs??[]).map(input=>done.get(input)+transfer(input,id))),finish=start+(node.cost??0);
    free[worker]=finish;done.set(id,finish);placed.set(id,{worker,start,finish});remaining.delete(id);
  }
  return {placed,missed:nodes.filter(node=>placed.get(node.id).finish>(times.get(node.id).latestFinish)+1e-9).map(node=>node.id)};
}
