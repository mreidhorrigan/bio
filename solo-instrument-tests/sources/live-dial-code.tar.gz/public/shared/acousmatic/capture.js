// Live capture for later, transformed returns (the supplement's S029): incoming audio into a bounded buffer, on its own
// clock; a region becomes a material -- immutable, hashed -- only once its interval has closed and is still held. A
// region still being recorded is not reversed, normalized or stretched whole; a region the buffer has already let go
// says so, never handed over partly.
import {material} from './material.js';
export class CaptureBuffer{
  // `seconds`: how much it holds; `licence`/`title`/`creator`: the capture's terms (an owner's recording by default).
  constructor({sampleRate,seconds,licence='owner-recorded',title='live capture',creator='the performers'}){
    this.sampleRate=sampleRate;this.capacity=Math.round(seconds*sampleRate);this.ring=new Float32Array(this.capacity);this.written=0;this.terms={licence,title,creator};this.sealed=0;
  }
  // Samples arriving, in order: the frames from `written` on.
  write(samples){for(let i=0;i<samples.length;i++)this.ring[(this.written+i)%this.capacity]=samples[i];this.written+=samples.length}
  // What [from, to) seconds is: 'held', 'open' (not all recorded yet), or 'lost' (let go).
  status(from,to){const a=Math.round(from*this.sampleRate),b=Math.round(to*this.sampleRate);return b>this.written?'open':a<this.written-this.capacity?'lost':'held'}
  // Its last `seconds` as heard (a copy), or null where it has not yet heard so much.
  recent(seconds){
    const n=Math.round(seconds*this.sampleRate);if(!(n>0)||n>this.capacity||this.written<n)return null;
    const out=new Float32Array(n);for(let i=0;i<n;i++)out[i]=this.ring[(this.written-n+i)%this.capacity];
    return out;
  }
  // A closed, held region as a material; else {refused: why}.
  seal(from,to){
    const state=this.status(from,to);if(state!=='held')return {refused:state==='open'?'it is still being recorded':'the buffer has let it go'};
    const a=Math.round(from*this.sampleRate),b=Math.round(to*this.sampleRate),out=new Float32Array(b-a);
    for(let i=a;i<b;i++)out[i-a]=this.ring[i%this.capacity];
    return {material:material({id:`capture-${++this.sealed}-${a}`,channels:[out],sampleRate:this.sampleRate,source:{kind:'capture',...this.terms,captureStart:from,captureEnd:to}})};
  }
}
