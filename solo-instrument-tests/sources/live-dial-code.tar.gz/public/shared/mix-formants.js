// Formant filters moved by bots: a voice's vowels laid over a part of the band and moved through, as a singer moves from
// vowel to vowel. The user, 26 September 2026: "Expressive LFOs, including vocal formant filters, are another such edge
// case - mixbot for now, but might eventually need to be split off. The purpose of a formant filter is to mimic vocal
// formants both in EQ shape and with modulation."
//
// A bot asks with /agent/formant {what, voice, pitch, path, motion, depth, seconds, inSeconds, fadeIn, bar, why}:
//   what       a group of the band (experiments/mix-desk/submix.js SUBMIX.groups), or a list of them, the first one
//              playing taken: its bus where the desk has grouped it, else each of its channels
//   voice      bass, tenor, countertenor, alto or soprano (shared/vowel-formants.js); unless said, the voice whose range
//              suits `pitch`, the part's middle (MIDI), else the register its group's role is played in
//              (shared/role-registers.js: a lead's is an alto's, the chords' a tenor's)
//   path       the vowels it moves through, in order ('a', 'e', 'i', 'o', 'u'); one vowel holds still
//   motion     how it moves along the path (formantPosition):
//                {kind: 'sweep', from, to}   once, from one place on the path to another (0 its first vowel, 1 its last)
//                {kind: 'lfo', seconds, shape, phase}   back and forth over the whole path, a cycle every `seconds`
//                                            (sine or triangle), starting `phase` cycles in
//                {kind: 'steps', seconds, glide, start}   vowel by vowel, each held `seconds` (or a list of lengths, taken
//                                            in turn: a bar's felt beats), glided into over `glide` of it, from the
//                                            path's `start`th vowel, round again at its end
//   depth      how much of the formants is heard against the part's own sound, 0 to 1
//   seconds    how long (MIX_FORMANTS.shortestSeconds to longestSeconds); inSeconds, from how long after the tick it is
//              sent on; fadeIn false for a course that carries on from the last (no fade in: a phrase's course that
//              overlaps the one before by fadeSeconds replaces its fade out, and the voice sings on); bar and why, for the
//              log
// The desk's side (MixFormants) schedules the course on the mixer (EnsembleMixer.formant): a point every stepSeconds,
// the depth faded in and out over fadeSeconds at its ends, from the moment the host gives (a render the tick's own time as
// it is heard, a page its clock's). A later request for the same channel replaces the course from where it begins.
import {SUBMIX,submixBus,submixGroup} from '../../experiments/mix-desk/submix.js';
import {VOICE_REGISTERS,VOWELS,formantVoice,vowelFormants,widenedFormants} from './vowel-formants.js';
import {GROUP_ROLES,ROLE_REGISTERS} from './role-registers.js';
import {median,midiHz} from './pitch-course.js';

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const MIX_FORMANTS=Object.freeze({
  // The shortest and longest course, and how far ahead one may be asked for (ours: a phrase or two at the longest; as a
  // cut's furthest).
  shortestSeconds:.25,longestSeconds:64,furthestSeconds:16,
  // A point every 20 ms (a control rate of 50 Hz: an LFO of a few hertz is drawn smoothly), the depth faded in and out
  // over a quarter of a second at the course's ends (ours).
  stepSeconds:.02,fadeSeconds:.25,
  motions:Object.freeze(['sweep','lfo','steps']),shapes:Object.freeze(['sine','triangle']),
  // Each formant at least as wide as this share of the part's fundamental (at the middle of its register, or its
  // `pitch`), the gap between its harmonics. The user heard the vowels "break down where vowels filtering intersects
  // with pitch glide"; measured, a sawtooth gliding 330 to 440 Hz through the alto's a flickers 8.4 dB (10 ms levels,
  // 10th to 90th percentile) through the table's own widths, 1.6 dB through formants as wide as its fundamental.
  harmonicShare:1,
});

// Where on the path (0 its first vowel, count - 1 its last) a motion stands `t` seconds into a course `seconds` long.
export function formantPosition(motion,t,seconds,count){
  const last=Math.max(0,count-1),kind=motion?.kind??'sweep';
  if(kind==='lfo'){
    const cycles=t/Math.max(Number.EPSILON,Number(motion.seconds)||seconds)+(Number(motion.phase)||0),turn=cycles-Math.floor(cycles);
    // Out and back over a cycle: a triangle's straight, a sine's eased (a raised cosine).
    const up=motion.shape==='triangle'?1-Math.abs(1-turn-turn):(1-Math.cos(2*Math.PI*turn))/2;
    return last*up;
  }
  if(kind==='steps'){
    // The step `t` falls in, and how far into it, the steps' lengths taken in turn.
    const lengths=(Array.isArray(motion.seconds)?motion.seconds:[motion.seconds]).map(value=>Math.max(Number.EPSILON,Number(value)||seconds));
    const cycle=lengths.reduce((a,b)=>a+b,0),cycles=Math.floor(t/cycle);let k=cycles*lengths.length,into=t-cycles*cycle;
    for(const length of lengths){if(into<length)break;into-=length;k++}
    const step=lengths[k%lengths.length],glide=Math.max(0,Math.min(1,Number(motion.glide)||0))*step;
    const at=index=>((index%count)+count)%count,start=Number(motion.start)||0,now=at(start+k),before=at(start+k-1);
    return k===0||glide===0||into>=glide?now:before+(now-before)*into/glide;
  }
  const from=Number(motion?.from??0),to=Number(motion?.to??1),share=seconds>0?Math.max(0,Math.min(1,t/seconds)):1;
  return last*(from+(to-from)*share);
}

// The course's points: [{at (context seconds), formants, depth}], every stepSeconds from `from` for `seconds`, and a last
// at its end, the depth faded out at its end and, unless it carries on from the last, in at its start; each formant at
// least `widestHz` wide (widenedFormants).
export function formantCourse({voice,path,motion,depth,from,seconds,fadeIn=true,widestHz=0,choices=MIX_FORMANTS}){
  const points=[],fade=Math.min(choices.fadeSeconds,seconds/2);
  for(let t=0;;t=Math.min(seconds,t+choices.stepSeconds)){
    const edge=Math.min(fadeIn?t:Infinity,seconds-t),heard=depth*(fade>0?Math.min(1,edge/fade):1);
    points.push({at:from+t,formants:widenedFormants(vowelFormants(voice,path,formantPosition(motion,t,seconds,path.length)),widestHz),depth:heard});
    if(t>=seconds)break;
  }
  return points;
}

export class MixFormants {
  constructor(mixer,{log=null,choices=MIX_FORMANTS}={}){
    if(!mixer||typeof mixer.formant!=='function')throw new TypeError('MixFormants needs the mixer (EnsembleMixer)');
    this.mixer=mixer;this.log=log;this.choices=choices;this.courses=[];
  }
  // The channels a group's formants go on: its bus where the desk has grouped it, else each of its channels; the first
  // group named that has any.
  targets(what){
    for(const group of (Array.isArray(what)?what:[what]).map(String).filter(name=>SUBMIX.groups[name])){
      const bus=submixBus(group);
      if(this.mixer.tracks.get(bus)?.bus)return {group,ids:[bus]};
      const ids=[...this.mixer.tracks].filter(([,track])=>!track.bus&&submixGroup(track.role)===group).map(([id])=>id);
      if(ids.length)return {group,ids};
    }
    return null;
  }
  // A request, at `start` (context seconds: when the tick it was sent on is heard). Returns what was scheduled, or why
  // not.
  request(request,{start,source=null}={}){
    const choices=this.choices,refuse=why=>{const record={kind:'formant',refused:why,source,request};this.log?.(record);return record};
    if(!request||typeof request!=='object')return refuse('a formant course is {what, path, motion, seconds}');
    const seconds=Number(request.seconds),inSeconds=Number(request.inSeconds??0),depth=Number(request.depth??1);
    if(!Number.isFinite(seconds)||seconds<choices.shortestSeconds||seconds>choices.longestSeconds)
      return refuse(`a formant course lasts ${choices.shortestSeconds} to ${choices.longestSeconds} seconds, not ${request.seconds}`);
    if(!Number.isFinite(inSeconds)||inSeconds<0||inSeconds>choices.furthestSeconds)return refuse(`a formant course begins 0 to ${choices.furthestSeconds} seconds ahead`);
    if(!(depth>=0&&depth<=1))return refuse('depth is 0 to 1');
    const path=Array.isArray(request.path)?request.path:[request.path];
    if(!path.length||path.some(vowel=>!VOWELS.includes(vowel)))return refuse(`a path is vowels (${VOWELS.join(', ')})`);
    const motion=request.motion??{kind:'sweep'};
    if(!choices.motions.includes(motion.kind))return refuse(`a motion is ${choices.motions.join(', ')}`);
    if(motion.kind==='lfo'&&motion.shape!==undefined&&!choices.shapes.includes(motion.shape))return refuse(`an LFO's shape is ${choices.shapes.join(', ')}`);
    if(request.voice!==undefined&&!VOICE_REGISTERS[request.voice])return refuse(`a voice is ${Object.keys(VOICE_REGISTERS).join(', ')}`);
    if(!Number.isFinite(start))return refuse('the host has no time for it');
    const found=this.targets(request.what);
    if(!found)return refuse(`nothing of ${JSON.stringify(request.what)} is playing`);
    const register=ROLE_REGISTERS[GROUP_ROLES[found.group]];
    const middle=Number.isFinite(Number(request.pitch))?Number(request.pitch):register?median(register):VOICE_REGISTERS.tenor;
    const voice=request.voice??formantVoice(middle),widestHz=choices.harmonicShare*midiHz(middle);
    const from=start+inSeconds,course=formantCourse({voice,path,motion,depth,from,seconds,fadeIn:request.fadeIn!==false,widestHz,choices});
    for(const id of found.ids)this.mixer.formant(id,course,{voice,vowel:path[0]}).catch(error=>refuse(error.message));
    const record={kind:'formant',group:found.group,channels:found.ids,voice,widestHz:Math.round(widestHz),path,motion,depth,from:+from.toFixed(4),until:+(from+seconds).toFixed(4),source,
      ...(Number.isFinite(Number(request.bar))?{bar:Number(request.bar)}:{}),...(request.why?{why:String(request.why)}:{})};
    this.courses.push(record);this.log?.(record);
    return record;
  }
}
