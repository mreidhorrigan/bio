// The Musebot Protocol over JSON-RPC 2.0 (RESEARCH_BACKLOG "P2 — the second queue", Protocol evolution: "The JSON-RPC
// 2.0 mapping of commands, notifications, errors, discovery and lifecycle, with ACP evaluated before anything is named
// ACP"; research/protocol-transport-evolution.md). One internal message model, the server's JSON envelopes
// (docs/MUSEBOT_PROTOCOL.md, "Transport envelope"), and this mapping to and from JSON-RPC, so a client that speaks JSON-RPC
// jams with the browser's bots and Max's through the same room. It is the Musebot Protocol, not ACP: ACP is for coding
// agents and their clients (sessions, prompts, tool calls, files), none of which a musical agent has (the design's
// evaluation, protocol-transport-evolution.md), so nothing here is named after it.
//
// Musical broadcasts are notifications (musebot.event), as the protocol's are: information each agent interprets, never
// a command, so they get no answer. An event sent as a request (with an id) is checked and answered: accepted, or the
// schema's errors (protocol-schemas.js). Requests are the operations that need an answer: initialize (joining a room),
// musebot.discover, musebot.subscribe, musebot.snapshot, musebot.diagnostics, and lifecycle (musebot.switch,
// musebot.leave, musebot.tempo). Everything the room sends a member arrives as a notification: musebot.event,
// musebot.clock, musebot.presence, musebot.protocolError and the rest, named for the envelope's type.
import {validateProtocolArgs,capabilityOf,MESSAGE_SCHEMAS,PROTOCOL_CAPABILITIES} from './protocol-schemas.js';

export const JSONRPC_VERSION='2.0',PROTOCOL_VERSION='2.0';
// JSON-RPC 2.0's own codes, and the server-defined ones this mapping adds (-32000 to -32099).
export const RPC_ERRORS=Object.freeze({parse:-32700,invalidRequest:-32600,methodNotFound:-32601,invalidParams:-32602,internal:-32603,
  notInitialized:-32002,alreadyInitialized:-32003,refused:-32004});
export const RPC_METHODS=Object.freeze(['initialize','musebot.event','musebot.discover','musebot.subscribe','musebot.snapshot','musebot.diagnostics',
  'musebot.switch','musebot.tempo','musebot.leave']);

export const rpcError=(id,code,message,data)=>({jsonrpc:JSONRPC_VERSION,id:id??null,error:{code,message,...(data!==undefined?{data}:{})}});
export const rpcResult=(id,result)=>({jsonrpc:JSONRPC_VERSION,id,result});
export const rpcNotification=(method,params)=>({jsonrpc:JSONRPC_VERSION,method,params});

// A request or notification's form (JSON-RPC 2.0 §4): an error for the sender, or null.
export function requestProblem(value){
  if(!value||typeof value!=='object'||Array.isArray(value))return 'a request is an object';
  if(value.jsonrpc!==JSONRPC_VERSION)return 'jsonrpc must be "2.0"';
  if(typeof value.method!=='string'||!value.method)return 'method must be a string';
  if(value.params!==undefined&&(typeof value.params!=='object'||value.params===null))return 'params must be an object or an array';
  if(value.id!==undefined&&value.id!==null&&typeof value.id!=='string'&&!Number.isFinite(value.id))return 'id must be a string, a number or null';
  return null;
}
const isRequest=value=>Object.hasOwn(value,'id');
// snake_case envelope types as camelCase method names: meter_changed is musebot.meterChanged.
const methodFor=type=>`musebot.${String(type).replace(/_([a-z0-9])/g,(_,letter)=>letter.toUpperCase())}`;

// An envelope the room sends, as JSON-RPC: a musical event, the clock, and the rest as notifications of their type.
export function envelopeToRpc(envelope,{room=null}={}){
  if(envelope?.type==='protocol')return rpcNotification('musebot.event',{protocolVersion:PROTOCOL_VERSION,...(room?{sessionId:room}:{}),
    ...(envelope.eventId?{eventId:envelope.eventId}:{}),source:{agentId:envelope.source??null,...(envelope.sourceIncarnation?{incarnation:envelope.sourceIncarnation}:{})},
    address:envelope.address,args:Array.isArray(envelope.args)?envelope.args:[],capability:capabilityOf(envelope.address),
    ...(Number.isFinite(envelope.serverTime)?{createdAt:envelope.serverTime}:Number.isFinite(envelope.clientTime)?{createdAt:envelope.clientTime}:{}),
    ...(envelope.routing?{routing:envelope.routing}:{})});
  const {type,...rest}=envelope??{};
  return rpcNotification(methodFor(type??'unknown'),rest);
}

// A musical event's params as the envelope the room reads.
export function eventToEnvelope(params){
  return {type:'protocol',address:String(params?.address??''),args:Array.isArray(params?.args)?params.args:[],...(params?.routing?.scope==='lan'?{routing:{scope:'lan'}}:{})};
}

// What the room can say it holds: every address's capability and evidence, by capability.
export function discovery(){
  const byCapability=Object.fromEntries(PROTOCOL_CAPABILITIES.map(capability=>[capability,[]]));
  for(const [address,schema] of Object.entries(MESSAGE_SCHEMAS))byCapability[schema.capability].push(address);
  return {protocolVersion:PROTOCOL_VERSION,methods:[...RPC_METHODS],capabilities:byCapability};
}

// A member's subscription: the capabilities and addresses it hears (all, where it names neither).
export function subscription(params={}){
  const capabilities=Array.isArray(params.capabilities)?params.capabilities.filter(item=>PROTOCOL_CAPABILITIES.includes(item)):null;
  const addresses=Array.isArray(params.addresses)?params.addresses.filter(item=>typeof item==='string'):null;
  const unknown=Array.isArray(params.capabilities)?params.capabilities.filter(item=>!PROTOCOL_CAPABILITIES.includes(item)):[];
  return {capabilities,addresses,unknown,hears:address=>(!capabilities&&!addresses)||Boolean(capabilities?.includes(capabilityOf(address)))||Boolean(addresses?.includes(address))};
}

// The last value of each broadcast the room keeps for a member joining late (as the server's rememberProtocol keeps
// them: every /broadcast/ address but plan responses, the last value each), from the welcome and what followed.
export class RetainedState {
  constructor(){this.clock=null;this.parameters=new Map}
  welcome(message){
    this.clock={bpm:message.bpm,tick:message.tick,bar:message.bar,meter:message.meter};
    for(const [address,state] of Object.entries(message.parameters??{}))this.parameters.set(address,{source:state.source??null,address:state.address??address,args:state.args??[]});
  }
  observe(envelope){
    if(envelope.type==='clock')this.clock={...this.clock,bpm:envelope.bpm,tick:envelope.tick,bar:envelope.bar,...(envelope.meter?{meter:envelope.meter}:{})};
    if(envelope.type==='tempo')this.clock={...this.clock,bpm:envelope.bpm};
    if(envelope.type==='meter_changed')this.clock={...this.clock,meter:envelope.meter};
    if(envelope.type==='protocol'&&envelope.address.startsWith('/broadcast/')&&envelope.address!=='/broadcast/plan/response')
      this.parameters.set(envelope.address,{source:envelope.source??null,address:envelope.address,args:envelope.args??[]});
  }
  snapshot(){return {clock:this.clock,parameters:Object.fromEntries(this.parameters)}}
}

// A JSON-RPC member of a room: requests and notifications in, as the envelopes the room reads (toRoom), and the room's
// envelopes out, as JSON-RPC (toClient). Transport-free: the server's /rpc adapter and tests drive it the same way.
//   toRoom(envelope): an envelope for the room's handler
//   toClient(value): a JSON-RPC response or notification for the member
export class JsonRpcMember {
  constructor({toRoom,toClient}){
    Object.assign(this,{toRoom,toClient,initialize:null,joined:false,room:null,subscribed:subscription(),retained:new RetainedState,diagnostics:[]});
  }
  // One frame from the member: a request, a notification, or a batch of them (JSON-RPC 2.0 §6).
  receive(text){
    let value;try{value=JSON.parse(text)}catch{return this.toClient(rpcError(null,RPC_ERRORS.parse,'Parse error'))}
    if(Array.isArray(value)){
      if(!value.length)return this.toClient(rpcError(null,RPC_ERRORS.invalidRequest,'An empty batch'));
      const answers=value.map(item=>this.handle(item)).filter(Boolean);
      if(answers.length)this.toClient(answers);
      return;
    }
    const answer=this.handle(value);if(answer)this.toClient(answer);
  }
  // A request's answer (null for a notification, or where the answer comes when the room replies).
  handle(value){
    const problem=requestProblem(value),id=value&&typeof value==='object'?value.id:null;
    if(problem)return rpcError(id??null,RPC_ERRORS.invalidRequest,problem);
    const request=isRequest(value),params=value.params??{},answer=(result)=>request?rpcResult(id,result):null,fail=(code,message,data)=>request?rpcError(id,code,message,data):null;
    if(value.method==='initialize'){
      if(this.joined||this.initialize)return fail(RPC_ERRORS.alreadyInitialized,'Already initialized');
      if(typeof params.agent!=='string'||!params.agent)return fail(RPC_ERRORS.invalidParams,'initialize needs params.agent');
      this.initialize={id:request?id:null};this.room=String(params.room||'main').slice(0,64);
      this.toRoom({type:'join',room:this.room,agent:params.agent,...(params.definitionId?{definitionId:params.definitionId}:{}),...(params.key?{key:params.key}:{}),
        ...(params.seed!==undefined?{seed:params.seed}:{}),...(params.observer===true?{observer:true}:{}),...(typeof params.token==='string'?{token:params.token}:{}),
        ...(params.protocolVersions!==undefined?{protocolVersions:params.protocolVersions}:{}),...(params.protocolVersion!==undefined?{protocolVersion:params.protocolVersion}:{}),
        ...(typeof params.resume==='string'?{resume:params.resume}:{})});
      return null;
    }
    if(!RPC_METHODS.includes(value.method))return fail(RPC_ERRORS.methodNotFound,`No method ${value.method}`);
    if(!this.joined)return fail(RPC_ERRORS.notInitialized,'Initialize first');
    switch(value.method){
      case 'musebot.event':{
        const envelope=eventToEnvelope(params),checked=validateProtocolArgs(envelope.address,envelope.args);
        if(!checked.valid)return fail(RPC_ERRORS.invalidParams,`${envelope.address} is malformed`,{errors:checked.errors});
        this.toRoom(envelope);
        return answer({accepted:true,registered:checked.known,capability:checked.capability});
      }
      case 'musebot.subscribe':{
        const next=subscription(params);
        if(next.unknown.length)return fail(RPC_ERRORS.invalidParams,`Unknown capabilities: ${next.unknown.join(', ')}`,{capabilities:PROTOCOL_CAPABILITIES});
        this.subscribed=next;return answer({capabilities:next.capabilities,addresses:next.addresses});
      }
      case 'musebot.discover':return answer({...discovery(),room:this.room,ensemble:this.ensemble??null});
      case 'musebot.snapshot':return answer(this.retained.snapshot());
      case 'musebot.diagnostics':this.diagnostics.push(request?id:null);this.toRoom({type:'protocol_diagnostics'});return null;
      case 'musebot.switch':
        if(typeof params.agent!=='string'||!params.agent)return fail(RPC_ERRORS.invalidParams,'musebot.switch needs params.agent');
        this.toRoom({type:'switch',agent:params.agent,...(params.definitionId?{definitionId:params.definitionId}:{})});return answer({agent:params.agent});
      case 'musebot.tempo':
        if(!Number.isFinite(params.bpm))return fail(RPC_ERRORS.invalidParams,'musebot.tempo needs a finite params.bpm');
        this.toRoom({type:'tempo',bpm:params.bpm});return answer({bpm:params.bpm});
      case 'musebot.leave':this.toRoom({type:'leave'});return answer({left:true});
      default:return fail(RPC_ERRORS.methodNotFound,`No method ${value.method}`);
    }
  }
  // One envelope from the room, for the member.
  send(envelope){
    if(envelope?.type==='welcome'){
      this.joined=true;this.retained.welcome(envelope);this.ensemble=envelope.ensemble??null;
      const pending=this.initialize;this.initialize=null;
      if(pending?.id!==null&&pending?.id!==undefined)this.toClient(rpcResult(pending.id,{...envelope,type:undefined,protocolVersion:envelope.protocolVersion??PROTOCOL_VERSION,
        capabilities:PROTOCOL_CAPABILITIES,methods:RPC_METHODS}));
      return;
    }
    if(envelope?.type==='error'&&this.initialize){
      const pending=this.initialize;this.initialize=null;
      if(pending.id!==null&&pending.id!==undefined)this.toClient(rpcError(pending.id,RPC_ERRORS.refused,String(envelope.error||'The room refused this member'),
        envelope.code?{code:envelope.code,...(envelope.supported?{supported:envelope.supported}:{})}:undefined));
      return;
    }
    if(envelope?.type==='protocol_diagnostics'){
      const id=this.diagnostics.shift();
      if(id!==null&&id!==undefined)this.toClient(rpcResult(id,{refused:envelope.refused??{},unregistered:envelope.unregistered??{},traced:envelope.traced??0}));
      return;
    }
    if(envelope?.type==='ensemble_session')this.ensemble=envelope.ensemble??this.ensemble;
    this.retained.observe(envelope);
    if(envelope?.type==='protocol'&&!this.subscribed.hears(envelope.address))return;
    this.toClient(envelopeToRpc(envelope,{room:this.room}));
  }
}
