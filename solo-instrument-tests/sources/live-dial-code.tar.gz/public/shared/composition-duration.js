// Negotiating how long the piece is, without letting it run away.
//
// The mechanism from research/MUSEBOTS_DYNAMIC_DURATION_RESEARCH.md. mh_FormBOT
// uses it to choose among rival forms (docs/FORM_NEGOTIATION.md); nothing else in
// the running ensemble does yet. See docs/COMPOSITION_DURATION.md for what a wider
// adoption would require.
//
// Its numbers are kept exact; rounding is for reading them. A cap rounded to
// six places before it was checked let an ending past the exact cap through
// (the mathematical audit's T02).
//
// The shape of it: bots propose complete alternatives -- a continuation and the
// ending that finishes it -- rather than bare numbers of extra bars. One
// authorized selector resolves a finite round against a sealed slate. Every
// accepted endpoint must fit an envelope computed once from the original
// composition and never recomputed, so extending can never buy the right to
// extend again. Ending eventually becomes irreversible.
//
// What this module does not do, and must not be read as doing: it takes
// `prepared` as an attestation from whatever prepared the material (for a form,
// what its compiled timeline says: formFaults in form-negotiation.js, with its
// reasons in `unprepared`), and checks no musical feasibility itself. It verifies no tempo map, no renderer
// readiness, and no delivery. A decision here is a record of a decision, not
// evidence that anything was heard. Deciding, being ready, being told, and
// actually sounding are four different achievements and this only reaches the
// first.
//
// One finding worth stating plainly, from reading the branch this sits on:
// **there was no L0 in this codebase.** Nothing computed a total composition
// duration, in seconds or in bars. mh_FormBOT drew `totalPhrases` from a
// weighted table, and a render's `length` never reached a bot. So the original
// duration this anchors to is supplied by whoever adopts this. Since 27
// September a render's declared length reaches every bot and mh_FormBOT fits its
// form to it (docs/COMPOSITION_DURATION.md §8, step 1).

import {DURATION_RULES, DURATION_RULE_NAMES, supportFor} from './duration-rules.js';

const clamp=(value,low,high)=>value<low?low:value>high?high:value;
const round=(value,places=6)=>Number(Number(value).toFixed(places));
const byId=(left,right)=>left<right?-1:left>right?1:0;
const positiveNumber=(value,name)=>{
  const number=Number(value);
  if(!Number.isFinite(number)||number<=0)throw new RangeError(`${name} must be a positive number`);
  return number;
};
const nonNegative=(value,name)=>{
  const number=Number(value);
  if(!Number.isFinite(number)||number<0)throw new RangeError(`${name} must be a nonnegative number`);
  return number;
};
const positiveInteger=(value,name)=>{
  const number=Math.trunc(Number(value));
  if(!Number.isFinite(number)||number<1)throw new RangeError(`${name} must be a positive integer`);
  return number;
};
const unit=(value,name)=>{
  const number=Number(value);
  if(!Number.isFinite(number)||number<0||number>1)throw new RangeError(`${name} must be between 0 and 1`);
  return number;
};
const identifier=(value,name)=>{
  const text=String(value??'');
  if(!text||text.length>128)throw new RangeError(`${name} must be a short non-empty id`);
  return text;
};

// Every number here is illustrative. The research memo is explicit that none of
// it is an empirically tuned musical default, and nothing has been listened to.
export const DURATION_DEFAULTS=Object.freeze({
  rule:'weighted',
  // The envelope, computed once: min(ratio of the original, an absolute cap).
  // Beats, because that is the unit the ensemble's timed plans already use and
  // a bar is not stable across a meter change.
  maxExtensionRatio:.125,
  maxExtensionAbsolute:64,
  // How much shorter the piece may become. An early ending should be limited by
  // what is still playable rather than by arithmetic, so this is generous.
  minRatio:.5,
  // Elapsed seconds are capped independently: a beat cap is defeated by slowing
  // down, and a piece that runs to time in beats can still overrun the room.
  maxElapsedRatio:.125,
  maxElapsedAbsoluteSeconds:60,
  // Churn, which a length cap does not bound. Travel is the sum of every
  // endpoint move, in beats, shortening included; returning to an endpoint used
  // before does not refund the journey.
  maxRevisionTravel:96,
  maxRevisions:8,
  maxEndpointStep:32,
  minCheckpointBeats:16,
  // A candidate must leave this much room to prepare what it promises.
  minPreparationBeats:8,
  // Prices, all in the same units as support, which is bounded to [-1,1].
  extensionPrice:.5,
  shorteningPrice:.25,
  changePrice:.15,
  disruptionPrice:.3,
  // Extending late costs more than extending early, measured against the
  // ORIGINAL duration: an earlier extension must never make the next one look
  // cheaper by moving the denominator.
  latePriceRise:.5,
  // How much better a replacement must be before the incumbent is disturbed.
  hysteresis:.05,
  // What one bot may say, and how loudly. Ratings are clamped to this and then
  // normalized, so a bot cannot gain influence by reporting a bigger number.
  maxRating:1,
  approvalThreshold:.05,
  // Bounds on one round.
  maxCandidates:16,
  // A form and the two duration variants its author offers with it (form-negotiation.js formVariants).
  maxProposalsPerSource:3,
  maxParticipants:64,
  historyLimit:64,
});

export function durationPolicy(overrides={}){
  const source=overrides&&typeof overrides==='object'?overrides:{};
  const rule=String(source.rule??DURATION_DEFAULTS.rule);
  if(!DURATION_RULE_NAMES.includes(rule))throw new RangeError(`Unknown duration rule: ${rule}`);
  return Object.freeze({
    rule,
    maxExtensionRatio:nonNegative(source.maxExtensionRatio??DURATION_DEFAULTS.maxExtensionRatio,'maxExtensionRatio'),
    maxExtensionAbsolute:nonNegative(source.maxExtensionAbsolute??DURATION_DEFAULTS.maxExtensionAbsolute,'maxExtensionAbsolute'),
    minRatio:unit(source.minRatio??DURATION_DEFAULTS.minRatio,'minRatio'),
    maxElapsedRatio:nonNegative(source.maxElapsedRatio??DURATION_DEFAULTS.maxElapsedRatio,'maxElapsedRatio'),
    maxElapsedAbsoluteSeconds:nonNegative(source.maxElapsedAbsoluteSeconds??DURATION_DEFAULTS.maxElapsedAbsoluteSeconds,'maxElapsedAbsoluteSeconds'),
    maxRevisionTravel:nonNegative(source.maxRevisionTravel??DURATION_DEFAULTS.maxRevisionTravel,'maxRevisionTravel'),
    maxRevisions:positiveInteger(source.maxRevisions??DURATION_DEFAULTS.maxRevisions,'maxRevisions'),
    maxEndpointStep:positiveNumber(source.maxEndpointStep??DURATION_DEFAULTS.maxEndpointStep,'maxEndpointStep'),
    minCheckpointBeats:nonNegative(source.minCheckpointBeats??DURATION_DEFAULTS.minCheckpointBeats,'minCheckpointBeats'),
    minPreparationBeats:nonNegative(source.minPreparationBeats??DURATION_DEFAULTS.minPreparationBeats,'minPreparationBeats'),
    extensionPrice:nonNegative(source.extensionPrice??DURATION_DEFAULTS.extensionPrice,'extensionPrice'),
    shorteningPrice:nonNegative(source.shorteningPrice??DURATION_DEFAULTS.shorteningPrice,'shorteningPrice'),
    changePrice:nonNegative(source.changePrice??DURATION_DEFAULTS.changePrice,'changePrice'),
    disruptionPrice:nonNegative(source.disruptionPrice??DURATION_DEFAULTS.disruptionPrice,'disruptionPrice'),
    latePriceRise:nonNegative(source.latePriceRise??DURATION_DEFAULTS.latePriceRise,'latePriceRise'),
    hysteresis:nonNegative(source.hysteresis??DURATION_DEFAULTS.hysteresis,'hysteresis'),
    maxRating:positiveNumber(source.maxRating??DURATION_DEFAULTS.maxRating,'maxRating'),
    approvalThreshold:unit(source.approvalThreshold??DURATION_DEFAULTS.approvalThreshold,'approvalThreshold'),
    maxCandidates:positiveInteger(source.maxCandidates??DURATION_DEFAULTS.maxCandidates,'maxCandidates'),
    maxProposalsPerSource:positiveInteger(source.maxProposalsPerSource??DURATION_DEFAULTS.maxProposalsPerSource,'maxProposalsPerSource'),
    maxParticipants:positiveInteger(source.maxParticipants??DURATION_DEFAULTS.maxParticipants,'maxParticipants'),
    historyLimit:positiveInteger(source.historyLimit??DURATION_DEFAULTS.historyLimit,'historyLimit'),
  });
}

// The envelope, computed ONCE from the original composition and then frozen.
//
// This is the whole discipline in one function. The allowance is a share of the
// ORIGINAL duration, never of the latest revised one, so a piece that has been
// extended to 136 does not thereby earn 12.5% of 136. It is not recomputed at a
// section boundary, when a bot rejoins, when the tempo map changes, or when
// policy is adjusted -- a policy update can change what it costs to move within
// the envelope and can never move the envelope. Ending early and extending
// again does not enlarge it either, because the cap is an absolute endpoint and
// not a remaining allowance that refills.
export function compositionContract({beats,seconds,startedAtBeats=0,policy=durationPolicy()}={}){
  const original=positiveNumber(beats,'beats');
  const allowance=Math.min(policy.maxExtensionRatio*original,policy.maxExtensionAbsolute);
  const elapsed=seconds===undefined||seconds===null?null:positiveNumber(seconds,'seconds');
  return Object.freeze({
    originalBeats:original,
    maxBeats:original+allowance,
    minBeats:original*policy.minRatio,
    allowanceBeats:allowance,
    originalSeconds:elapsed,
    maxSeconds:elapsed===null?null
      :elapsed+Math.min(policy.maxElapsedRatio*elapsed,policy.maxElapsedAbsoluteSeconds),
    startedAtBeats:nonNegative(startedAtBeats,'startedAtBeats'),
    // Frozen with the contract, so the numbers above can always be re-derived
    // from what made them and a later policy cannot rewrite their history.
    basis:Object.freeze({maxExtensionRatio:policy.maxExtensionRatio,
      maxExtensionAbsolute:policy.maxExtensionAbsolute,minRatio:policy.minRatio,
      maxElapsedRatio:policy.maxElapsedRatio,maxElapsedAbsoluteSeconds:policy.maxElapsedAbsoluteSeconds}),
  });
}

// A new contract is a human decision, not something the ensemble can reach by
// agreeing hard enough. It must name who authorized it and why, and it records
// what it replaced: a fresh envelope has to be visible as an intervention in
// the report rather than appearing as a suspiciously roomy original.
export function authorizeContract(previous,{beats,seconds,authority,reason,policy=durationPolicy()}){
  const who=identifier(authority,'authority');
  const next=compositionContract({beats,seconds,startedAtBeats:previous?.startedAtBeats??0,policy});
  return Object.freeze({...next,
    supersedes:previous?Object.freeze({originalBeats:previous.originalBeats,maxBeats:previous.maxBeats}):null,
    authority:who,reason:String(reason??'').slice(0,240)});
}

// How much ensemble time a set of requests actually needs.
//
// Two bots asking for eight bars each do not need sixteen if their parts can
// sound at once; they do need sixteen if one must follow the other. The blind
// sum and the blind maximum are both wrong, and both are returned beside the
// answer so a caller can see what the overlap was worth. This is the longest
// path through the precedence graph: O(V+E), no search, with one predecessor
// kept for each request and the path read back once (a copied path at every
// request had held O(V^2) entries on a chain), and finishes accumulated exactly,
// rounded only in the answer (rounding each finish made the answer depend on how
// the work was divided: three thirds read 0.999999 where one whole read 1; the
// mathematical audit's I03).
export function ensembleDemand(requests=[]){
  const nodes=new Map();
  for(const request of requests){
    const id=identifier(request?.id,'request id');
    if(nodes.has(id))throw new RangeError(`Duplicate request: ${id}`);
    nodes.set(id,{id,beats:nonNegative(request.beats,`beats for ${id}`),
      after:[...new Set((request.after||[]).map(value=>String(value)))].sort(byId)});
  }
  for(const node of nodes.values())
    for(const dependency of node.after)
      if(!nodes.has(dependency))throw new RangeError(`${node.id} follows an unknown request: ${dependency}`);
  const finish=new Map(),predecessor=new Map(),active=new Set();
  const ids=[...nodes.keys()].sort(byId);
  for(const root of ids){
    if(finish.has(root))continue;
    const stack=[{id:root,next:0,start:0,through:null}];active.add(root);
    while(stack.length){
      const frame=stack.at(-1),node=nodes.get(frame.id);
      if(frame.next<node.after.length){
        const dependency=node.after[frame.next];
        if(active.has(dependency))throw new RangeError(`Requests cannot depend on themselves: ${dependency}`);
        if(!finish.has(dependency)){active.add(dependency);stack.push({id:dependency,next:0,start:0,through:null});continue;}
        const end=finish.get(dependency);
        if(end>frame.start||(end===frame.start&&byId(dependency,frame.through??'')<0)){frame.start=end;frame.through=dependency;}
        frame.next++;continue;
      }
      const end=frame.start+node.beats;
      if(!Number.isFinite(end))throw new RangeError('Ensemble duration overflow');
      finish.set(frame.id,end);predecessor.set(frame.id,frame.through);active.delete(frame.id);stack.pop();
    }
  }
  let critical=0,last=null;
  for(const id of ids)if(finish.get(id)>critical){critical=finish.get(id);last=id;}
  const path=[];for(let id=last;id!==null;id=predecessor.get(id))path.push(id);path.reverse();
  const sum=round([...nodes.values()].reduce((total,node)=>total+node.beats,0)),
    longest=round([...nodes.values()].reduce((most,node)=>Math.max(most,node.beats),0));
  return Object.freeze({beats:round(critical),sum,longest,path:Object.freeze(path),
    saved:round(sum-critical)});
}

// Why a candidate cannot be accepted. Each is a fact about the candidate and
// the contract, never about whether anybody liked it.
export function candidateFaults(candidate,{contract,state,policy,clock}){
  const faults=[];
  const endpoint=Number(candidate?.endpointBeats);
  if(!Number.isFinite(endpoint))return ['no endpoint'];
  // Why it is not, when whatever checked it says (a form's compiled timeline: formFaults in form-negotiation.js).
  if(candidate.prepared!==true){
    const reasons=Array.isArray(candidate.unprepared)?candidate.unprepared.slice(0,4).map(reason=>String(reason).slice(0,240)):[];
    faults.push(reasons.length?`not prepared: ${reasons.join('; ')}`:'not prepared');
  }
  if(endpoint>contract.maxBeats)faults.push(`beyond the envelope (${contract.maxBeats})`);
  if(endpoint<contract.minBeats)faults.push(`shorter than the floor (${contract.minBeats})`);
  const seconds=Number(candidate.endpointSeconds);
  if(contract.maxSeconds!==null&&Number.isFinite(seconds)&&seconds>contract.maxSeconds)
    faults.push(`beyond the elapsed cap (${contract.maxSeconds}s)`);
  if(endpoint<clock.beats+policy.minPreparationBeats)faults.push('too close to prepare');
  const cutoff=Number(candidate.acceptByBeats);
  if(Number.isFinite(cutoff)&&clock.beats>cutoff)faults.push('its acceptance cutoff has passed');
  const move=Math.abs(endpoint-state.endpointBeats);
  if(move>policy.maxEndpointStep)faults.push(`moves more than ${policy.maxEndpointStep} beats at once`);
  if(state.travel+move>policy.maxRevisionTravel)faults.push('the revision travel budget is spent');
  if(state.revisions>=policy.maxRevisions)faults.push('no revisions left');
  return faults;
}

// What a candidate costs, whichever rule is aggregating the preferences. The
// price of length is measured against the ORIGINAL duration and rises with how
// far through the original the music has got -- never with how far through the
// current target, which an earlier extension would have made flatter.
export function candidateCost(candidate,{contract,state,policy,clock}){
  const endpoint=Number(candidate.endpointBeats),
    allowance=Math.max(contract.allowanceBeats,1e-9),
    progress=clamp(clock.beats/contract.originalBeats,0,1);
  const length=endpoint>=contract.originalBeats
    ?policy.extensionPrice*((endpoint-contract.originalBeats)/allowance)*(1+policy.latePriceRise*progress)
    :policy.shorteningPrice*((contract.originalBeats-endpoint)/contract.originalBeats);
  const change=candidate.id===state.incumbentId?0
    :policy.changePrice*(Math.abs(endpoint-state.endpointBeats)/allowance);
  const disruption=policy.disruptionPrice*clamp(Number(candidate.disruption)||0,0,1);
  return {length:round(length),change:round(change),disruption:round(disruption),
    total:round(length+change+disruption)};
}

// One sealed round resolved: every candidate scored the same way, the incumbent
// kept unless something clears it by more than the hysteresis, ties broken on
// the candidate id and never on the order anything arrived in.
export function evaluateSlate({contract,state,candidates=[],participants=[],
  preferences=new Map(),policy=durationPolicy(),clock={beats:0,seconds:0},weights=null,rule=null}){
  const using=rule??policy.rule;
  if(!DURATION_RULES[using])throw new RangeError(`Unknown duration rule: ${using}`);
  const enrolled=[...participants].map(String).sort(byId);
  const incumbent=candidates.find(candidate=>candidate.id===state.incumbentId)||null;
  const eligible=[],rejected=[];
  for(const candidate of [...candidates].sort((left,right)=>byId(left.id,right.id))){
    // The incumbent is feasible by construction: it was admitted under this same
    // envelope and keeping it cannot enlarge anything.
    const faults=candidate===incumbent?[]:candidateFaults(candidate,{contract,state,policy,clock});
    if(faults.length)rejected.push({id:candidate.id,faults});
    else eligible.push(candidate);
  }
  const supported=supportFor(using,{candidates:eligible,participants:enrolled,preferences,
    policy,weights,incumbentId:state.incumbentId});
  const scored=supported.map(entry=>{
    const cost=candidateCost(entry.candidate,{contract,state,policy,clock});
    return {...entry,cost,score:round(entry.support-cost.total)};
  });
  const held=scored.find(entry=>entry.candidate.id===state.incumbentId)||null;
  const base=held?held.score:-Infinity;
  let best=null;
  for(const entry of scored){
    if(entry.candidate.id===state.incumbentId)continue;
    if(!best||entry.score>best.score||(entry.score===best.score&&byId(entry.candidate.id,best.candidate.id)<0))
      best=entry;
  }
  const delta=best?round(best.score-base):null;
  const replaces=Boolean(best)&&(held===null||delta>policy.hysteresis);
  const chosen=replaces?best:held;
  return Object.freeze({
    rule:using,
    selected:chosen?chosen.candidate:null,
    kept:!replaces&&Boolean(held),
    delta,
    hysteresis:policy.hysteresis,
    scored:Object.freeze(scored.map(entry=>Object.freeze({id:entry.candidate.id,
      endpointBeats:entry.candidate.endpointBeats,support:entry.support,
      cost:entry.cost,score:entry.score,coverage:entry.coverage}))),
    rejected:Object.freeze(rejected.map(entry=>Object.freeze({...entry,faults:Object.freeze(entry.faults)}))),
    rationale:explain({chosen,held,best,delta,replaces,enrolled,rejected,policy,using}),
  });
}
function explain({chosen,held,best,delta,replaces,enrolled,rejected,policy,using}){
  if(!chosen)return `No feasible candidate under ${using}; ${rejected.length} rejected, and nothing is accepted.`;
  const coverage=chosen.coverage;
  const heard=`${coverage.heard} of ${enrolled.length} enrolled ${enrolled.length===1?'bot':'bots'} rated it`;
  if(replaces)return `Replaced the accepted ending with ${chosen.candidate.id} at `
    +`${chosen.candidate.endpointBeats} beats: ${delta} better than keeping it, over a hysteresis of `
    +`${policy.hysteresis}. ${heard}.`;
  if(!best)return `Kept the accepted ending: nothing else was feasible. ${heard}.`;
  return `Kept the accepted ending: the best alternative (${best.candidate.id}) was `
    +`${delta} better, which does not clear the hysteresis of ${policy.hysteresis}. ${heard}.`;
}

// The ending is a one-way street, and the phases say how far down it the piece
// has gone. Once committed, no ordinary proposal reopens the composition; a
// late good idea is kept for another piece rather than quietly overrunning this
// one. Nothing here makes a sound: CLOSING and ENDED are records of decisions,
// and what actually stops is the scheduler's business.
export const DURATION_PHASES=Object.freeze(['open','committed','closing','ended']);

export class DurationController{
  constructor({contract,accepted,policy=durationPolicy(),clock={beats:0,seconds:0}}={}){
    if(!contract?.maxBeats)throw new RangeError('A duration controller needs a composition contract');
    const endpoint=Number(accepted?.endpointBeats);
    if(!Number.isFinite(endpoint))throw new RangeError('A duration controller needs an accepted ending to keep');
    if(endpoint>contract.maxBeats)throw new RangeError('The accepted ending does not fit its own envelope');
    this.contract=contract;this.policy=policy;
    this.phase='open';
    this.accepted=Object.freeze({...accepted,id:identifier(accepted.id,'accepted id')});
    this.clock=Object.freeze({beats:nonNegative(clock.beats,'clock.beats'),
      seconds:nonNegative(clock.seconds??0,'clock.seconds')});
    this.travel=0;this.revisions=0;this.lastDecisionBeats=-Infinity;
    this.round=null;this.history=[];this.backwardClocks=0;this.superseded=[];
  }
  get endpointBeats(){return Number(this.accepted.endpointBeats)}
  get state(){return {incumbentId:this.accepted.id,endpointBeats:this.endpointBeats,
    travel:this.travel,revisions:this.revisions}}
  record(event){
    this.history.push(Object.freeze({...event,atBeats:this.clock.beats}));
    while(this.history.length>this.policy.historyLimit)this.history.shift();
    return event;
  }
  // A clock that goes backwards is a rejoin or a bug, never a reason to replay
  // the piece: it is counted and ignored rather than obeyed.
  advance({beats,seconds}={}){
    const nextBeats=Number(beats),nextSeconds=Number(seconds);
    if(Number.isFinite(nextBeats)&&nextBeats<this.clock.beats){this.backwardClocks++;return this.phase}
    this.clock=Object.freeze({
      beats:Number.isFinite(nextBeats)?nextBeats:this.clock.beats,
      seconds:Number.isFinite(nextSeconds)&&nextSeconds>=this.clock.seconds?nextSeconds:this.clock.seconds});
    if(this.phase==='committed'&&this.clock.beats>=this.closingStartBeats())this.enter('closing');
    if(this.phase==='closing'&&this.clock.beats>=this.endpointBeats)this.enter('ended');
    return this.phase;
  }
  // The same accepted ending, measured again on the room's clock. An ending
  // is decided in its author's bars, and where a bar falls in beats depends on
  // the meters between here and there: when the meter changes, the ending
  // moves in beats without anybody revising it. Keeping the old figure would
  // weigh every rival, measured in the new meter, against an incumbent still
  // measured in the old one. So this is not a revision: no travel, no count,
  // no check against the envelope (the room chose its meter), only a record.
  remeasure({id,endpointBeats,reason=''}={}){
    const next=Number(endpointBeats);
    if(String(id)!==this.accepted.id||!Number.isFinite(next)||next===this.endpointBeats)return false;
    this.record({type:'remeasure',from:this.endpointBeats,to:next,reason:String(reason).slice(0,240)});
    this.accepted=Object.freeze({...this.accepted,endpointBeats:next});
    return true;
  }
  closingStartBeats(){
    const declared=Number(this.accepted.closingStartBeats);
    return Number.isFinite(declared)?declared:this.endpointBeats-this.policy.minPreparationBeats;
  }
  enter(phase){
    const from=DURATION_PHASES.indexOf(this.phase),to=DURATION_PHASES.indexOf(phase);
    if(to<0)throw new RangeError(`Unknown phase: ${phase}`);
    // Monotonic: a piece that has begun to close does not reopen.
    if(to<=from)return this.phase;
    this.phase=phase;this.record({type:'phase',phase});
    return this.phase;
  }
  // A policy update, carried on the plans that already travel (the negotiated composition length's adoption, step 2).
  // It changes what moving inside the envelope costs and how often and how far the ending may move, never the envelope:
  // the contract was frozen with its own basis, and the new policy keeps that basis. Not while a round is open, since
  // sealing freezes what a decision is made from; the change is recorded, so a decision can be read against the policy
  // it was made under.
  adjustPolicy(policy,{reason=''}={}){
    if(this.round)throw new RangeError('A round is open; a policy update belongs between rounds');
    const next=durationPolicy({...policy,...this.contract.basis});
    const changed=Object.keys(next).filter(key=>next[key]!==this.policy[key]);
    if(!changed.length)return false;
    this.policy=next;
    this.record({type:'policy',changed:Object.freeze(changed),reason:String(reason).slice(0,240)});
    return true;
  }
  // Ending becomes irreversible here, and this is the only way in.
  commitEnding({reason=''}={}){
    if(this.phase!=='open')return this.phase;
    this.record({type:'commit',reason:String(reason).slice(0,240),endpointBeats:this.endpointBeats});
    return this.enter('committed');
  }
  openRound({id,participants=[],baseRevision=0}={}){
    if(this.phase!=='open')throw new RangeError('The ending is committed; no round may open');
    if(this.round)throw new RangeError('A round is already open');
    if(this.clock.beats-this.lastDecisionBeats<this.policy.minCheckpointBeats)
      throw new RangeError('Too soon after the last decision for another checkpoint');
    const enrolled=[...new Set(participants.map(String))].sort(byId);
    if(enrolled.length>this.policy.maxParticipants)throw new RangeError('Too many participants for one decision');
    // Membership is fixed when the round opens. A bot that joins afterwards
    // does not get a vote in a decision it was not enrolled for, and a bot that
    // leaves does not shrink the denominator by leaving.
    this.round=Object.seal({id:identifier(id,'round id'),participants:Object.freeze(enrolled),
      baseRevision:Number(baseRevision)||0,sealed:false,
      candidates:new Map([[this.accepted.id,this.accepted]]),preferences:new Map(),
      sources:new Map(),openedAtBeats:this.clock.beats});
    this.record({type:'round',round:this.round.id,participants:enrolled.length});
    return this.round.id;
  }
  propose(candidate){
    const open=this.openRound_();
    const id=identifier(candidate?.id,'candidate id'),author=identifier(candidate?.author,'candidate author');
    if(open.candidates.has(id))throw new RangeError(`Duplicate candidate: ${id}`);
    const used=open.sources.get(author)||0;
    if(used>=this.policy.maxProposalsPerSource)throw new RangeError(`${author} has used its proposals for this round`);
    if(open.candidates.size>=this.policy.maxCandidates)throw new RangeError('The slate is full');
    if(!Number.isFinite(Number(candidate.endpointBeats)))throw new RangeError('A candidate needs an endpoint in beats');
    open.sources.set(author,used+1);
    open.candidates.set(id,Object.freeze({...candidate,id,author}));
    return id;
  }
  // Readiness is not willingness: a bot may dislike a candidate it can play and
  // prefer one it cannot. Both facts travel, and neither is inferred from the
  // other. A bot that says nothing has abstained.
  prefer({bot,ratings={},endpointBeats}={}){
    const open=this.openRound_(),who=identifier(bot,'bot');
    if(!open.participants.includes(who))throw new RangeError(`${who} is not enrolled in this round`);
    const clean={};
    for(const [id,value] of Object.entries(ratings||{})){
      if(!open.candidates.has(id))continue;
      const number=Number(value);
      if(Number.isFinite(number))clean[id]=clamp(number,-this.policy.maxRating,this.policy.maxRating);
    }
    open.preferences.set(who,Object.freeze({bot:who,ratings:Object.freeze(clean),
      ...(Number.isFinite(Number(endpointBeats))?{endpointBeats:Number(endpointBeats)}:{})}));
    return who;
  }
  openRound_(){
    if(!this.round)throw new RangeError('No round is open');
    if(this.round.sealed)throw new RangeError('This round is sealed; late information belongs to the next one');
    return this.round;
  }
  // Sealing freezes what the decision is made from. Everything after this point
  // is arithmetic over a fixed input, so the same messages in the same order
  // always reach the same decision however fast the machine running it is.
  seal({rule=null,weights=null}={}){
    const open=this.openRound_();
    open.sealed=true;
    const decision=evaluateSlate({contract:this.contract,state:this.state,
      candidates:[...open.candidates.values()],participants:open.participants,
      preferences:open.preferences,policy:this.policy,clock:this.clock,weights,rule});
    const selected=decision.selected;
    if(selected&&selected.id!==this.accepted.id){
      this.travel+=Math.abs(Number(selected.endpointBeats)-this.endpointBeats);
      this.revisions++;
      this.accepted=Object.freeze({...selected});
    }
    this.lastDecisionBeats=this.clock.beats;
    this.record({type:'decision',round:open.id,rule:decision.rule,
      selected:selected?selected.id:null,endpointBeats:this.endpointBeats,
      kept:decision.kept,delta:decision.delta,rejected:decision.rejected.length});
    this.round=null;
    return decision;
  }
  // Everything a later evaluation needs, including what was refused. A rejected
  // alternative that vanishes from the record cannot be argued with afterwards.
  report(){
    return Object.freeze({
      contract:this.contract,policy:this.policy,phase:this.phase,
      clock:this.clock,accepted:this.accepted,
      originalBeats:this.contract.originalBeats,
      currentBeats:this.endpointBeats,
      remainingBeats:round(this.endpointBeats-this.clock.beats),
      headroomBeats:round(this.contract.maxBeats-this.endpointBeats),
      travel:this.travel,travelBudget:this.policy.maxRevisionTravel,
      revisions:this.revisions,revisionLimit:this.policy.maxRevisions,
      backwardClocks:this.backwardClocks,
      openRound:this.round?this.round.id:null,
      history:Object.freeze([...this.history]),
    });
  }
}
