// The desk's feedback loops, moved by bots. The user, 26 September 2026: "The amount of the feedback loop - and,
// eventually, multiple feedback loops - should be variable by one or more mixbots. Feedback can be varied, including
// into positive ranges driving guitar amp simulators or compressors, for musical effect."
//
// The user, again: "'playing the no-input mixer' (working with a feedback loop) usually involves changing all of: a
// feedback amount, a delay time (must be done in a way that doesn't crackle), and an EQ."
//
// A bot moves a loop with /agent/feedback {loop, amount, drive, driveAmount, pitch, delayMs, band, seconds, hold,
// release}; what it leaves out stays as it is:
//   loop          the loop's name; the desk has one, 'mix', the mix bus fed back into itself (public/mix-feedback.js)
//   amount        how strongly it feeds back, 0 to 2. Without a stage, its gain where it returns most (0.5 at most);
//                 through one, the gain of its ringing mode, where it comes back in phase: past 1 it sustains itself
//   drive         what it runs through: 'none', 'tanh', 'tape', 'tube', 'fuzz' or 'compressor' (LOOP_DRIVES);
//                 driveAmount, how hard, 0 to 1
//   pitch         a pitch (MIDI, fractional in any tuning) or `hz`: the loop tuned to ring there, as a player tunes a
//                 no-input mixer: its band centred on it, boosted and narrowed until that is the pitch that rings, and
//                 its delay set so that it comes back in phase there (mix-feedback.js tuneTo). Through a stage only.
//                 With `glide: true` the pitch ringing now is bent there, over `seconds`, by its delay (a portamento);
//                 without, the band moves to another of the loop's modes, and the pitch steps there as the band sweeps
//   delayMs       its delay, one pass through the room in ms (-1 the room's own, 17.5), glided, so it never crackles
//   band          {hz, db, q}: its EQ, a peaking band; a boost only through a stage
//   width         with a pitch, how wide its band is played, 0 to 1 (mix-feedback.js MIX_FEEDBACK.widths): 0 a whistle,
//                 the one mode alone; 0.5 a tone, the widest band that isolates it (the default); 1 a roar, its
//                 neighbouring modes ringing with it (the user: "Broadband feedback is aggressive, whereas narrowband
//                 whistling can deliver expressive melodies, and everything between also exists"); past a tone, its
//                 room made rough by as much as it is wider (below), so a roar growls
//   roughness     how rough its room is, 0 to 1 (mix-feedback.js MIX_FEEDBACK.roughness: its delays jittered together at a
//                 growl's rate, a howl's pitch wandering); unless said, 0, or a wide band's own (width past a tone)
//   seconds       how long the change takes (a ramp: never a jump, never under 5 ms)
//   hold          how long it stays there before its release, in seconds
//   release       {amount, drive, driveAmount, pitch, delayMs, band, seconds}: where it goes after the hold, the loop's
//                 resting setting unless said
//   rest          true: back to the loop's resting setting over `seconds`: what the mix had before any bot moved it,
//                 or what a person set it to since
// A rise past unity sustains itself, so it is refused without its hold: the release is asked for with the rise, and no
// message lost later can leave a loop growing (mh_RoomBOT's rule: experiments/feedback-room/room-bot.js). A loop
// sustaining itself that is taken under unity over some seconds rings out over them: a ramp through unity would end it
// at once (under unity it dies by 20 log10(amount) dB a pass, 17.5 ms), so it goes first to the amount that rings that
// long (mix-feedback.js ringingAmount), through its own stage, at its own pitch, and then, rung out, where it was asked. A later
// request for the same loop replaces an earlier one's pending release, carrying its own if it needs one. Several bots
// may move one loop: the latest request holds, and each is logged with who sent it.
//
// FeedbackLoops is the desk's side: it takes requests, applies them to the mixer (setEffects, ramped), and applies each
// release when the desk's clock reaches it (tick, every tickMs: a page's interval, a render's timers, which run on
// through the tail), so a render and a page play the same sequence.
import {LOOP_DRIVES,loopDrive,MIX_FEEDBACK,ringingAmount,mixFeedbackDesign,tuneTo,glideRoom,roomFor,delayMsFor} from '../mix-feedback.js';
import {RAMP_FLOOR_SECONDS} from '../mixer-parts.js';
import {midiHz} from './pitch-course.js';
import {FX_DEFAULTS} from './sound-settings.js';

// ---- Definitions -----------------------------------------------------------------------------------------------
// The loops a desk has, and the settings each is made of.
export const FEEDBACK_LOOPS=Object.freeze({mix:Object.freeze({amount:'mixFeedback',drive:'mixFeedbackDrive',driveAmount:'mixFeedbackDriveAmount',
  delayMs:'mixFeedbackDelayMs',bandHz:'mixFeedbackBandHz',bandDb:'mixFeedbackBandDb',bandQ:'mixFeedbackBandQ',roughness:'mixFeedbackRoughness'})});

// ---- Choices ---------------------------------------------------------------------------------------------------
export const FEEDBACK_REQUESTS=Object.freeze({
  minRampSeconds:RAMP_FLOOR_SECONDS,  // no change faster than the ensemble's mixer ramps (5 ms: a click, faster)
  rampSeconds:.5,          // a change unless the request says
  maxAmount:2,             // twice unity (public/mix-feedback.js MIX_FEEDBACK.maxDrivenGain)
  unity:1,                 // past this, a loop sustains itself: its hold is required
  maxHoldSeconds:60,       // the longest a loop may be held past unity at one request (ours: a minute)
  tickMs:100,              // how often a desk looks for a release due: a page on its interval, a render on its timers
});

const finite=(value,fallback)=>Number.isFinite(Number(value))?Number(value):fallback;
// A band played wider than a tone is as rough as it is wider: 0 at a tone, 1 at a roar.
const wideRoughness=(width,design)=>{const {tone,roar}=design.choices.widths;return Math.max(0,Math.min(1,(width-tone)/(roar-tone)))};
const clamp=(value,low,high)=>Math.min(high,Math.max(low,value));

// A loop's settings as the desk holds them ({amount, drive, driveAmount, delayMs, bandHz, bandDb, bandQ}), from the
// mixer's; the desk's defaults for any it has not got.
export function loopSettings(settings={},keys=FEEDBACK_LOOPS.mix){
  const value=name=>settings[keys[name]]??FX_DEFAULTS[keys[name]];
  return {amount:value('amount')??0,drive:loopDrive(value('drive')??0),driveAmount:value('driveAmount')??MIX_FEEDBACK.driveAmount,
    delayMs:value('delayMs'),bandHz:value('bandHz'),bandDb:value('bandDb'),bandQ:value('bandQ'),roughness:value('roughness')??0};
}

// A request checked and made into steps: {ok: true, loop, steps: [{atSeconds, seconds, values}], tuning} or {ok: false,
// reason}. `now` is the clock's time; `current` the loop's settings now (loopSettings); `resting` where it goes back to
// when a release does not say; `design` the loop's (mix-feedback.js), for how it tunes and how long it rings.
export function feedbackSteps(request,{now,current,resting,design=mixFeedbackDesign(),choices=FEEDBACK_REQUESTS}={}){
  if(!request||typeof request!=='object')return {ok:false,reason:'a feedback request is an object'};
  const loop=String(request.loop??'mix');
  if(!FEEDBACK_LOOPS[loop])return {ok:false,reason:`no feedback loop called ${JSON.stringify(loop)} (${Object.keys(FEEDBACK_LOOPS).join(', ')})`};
  const tunings=[];
  const setting=(from,base)=>{
    const drive=from.drive===undefined?base.drive:loopDrive(from.drive);
    if(from.drive!==undefined&&typeof from.drive==='string'&&!LOOP_DRIVES.includes(from.drive))return {error:`no drive called ${JSON.stringify(from.drive)} (${LOOP_DRIVES.join(', ')})`};
    if(from.band!==undefined&&(from.band===null||typeof from.band!=='object'))return {error:'band is {hz, db, q}'};
    if(from.width!==undefined&&!(Number(from.width)>=0&&Number(from.width)<=1))return {error:`width is 0 (a whistle) to 1 (a roar), not ${JSON.stringify(from.width)}`};
    if(from.roughness!==undefined&&!(Number(from.roughness)>=0&&Number(from.roughness)<=1))return {error:`roughness is 0 to 1, not ${JSON.stringify(from.roughness)}`};
    const values={amount:clamp(finite(from.amount,base.amount),0,choices.maxAmount),drive,driveAmount:clamp(finite(from.driveAmount,base.driveAmount),0,1),
      delayMs:finite(from.delayMs,base.delayMs),bandHz:finite(from.band?.hz,base.bandHz),bandDb:finite(from.band?.db,base.bandDb),bandQ:finite(from.band?.q,base.bandQ),
      roughness:finite(from.roughness,from.width!==undefined?wideRoughness(Number(from.width),design):base.roughness??0)};
    // Tuned to a pitch: the band and the delay that make it ring there.
    const hz=from.hz!==undefined?Number(from.hz):from.pitch!==undefined?midiHz(Number(from.pitch)):null;
    if(hz!==null){
      if(!(hz>0&&Number.isFinite(hz)))return {error:'pitch is a MIDI number, hz a frequency'};
      if(drive==='none')return {error:'a loop tuned to a pitch rings, and its band boosts: it needs a stage (drive)'};
      const now={room:roomFor(design,base.delayMs),band:{hz:base.bandHz,db:base.bandDb,q:base.bandQ}};
      const tuned=tuneTo(design,hz,{db:from.band?.db,q:from.band?.q,near:from.glide===true?glideRoom(design,hz,now):1,width:from.width??null});
      Object.assign(values,{delayMs:delayMsFor(design,tuned.room),bandHz:tuned.band.hz,bandDb:tuned.band.db,bandQ:tuned.band.q});
      tunings.push({hz,tuned:tuned.tuned,ringHz:tuned.ringHz,...(from.width!==undefined?{width:Number(from.width),q:tuned.band.q}:{})});
    }
    if(drive==='none'&&values.bandDb>0)return {error:'a boost in the loop\'s band needs a stage (drive): without one it only cuts, so its proof stands'};
    return values;
  };
  const target=request.rest===true?{...resting}:setting(request,current);
  if(target.error)return {ok:false,reason:target.error};
  const seconds=Math.max(choices.minRampSeconds,finite(request.seconds,choices.rampSeconds));
  const hold=request.hold===undefined?null:finite(request.hold,NaN);
  if(hold!==null&&!(hold>=0))return {ok:false,reason:'hold is a number of seconds'};
  const sustains=values=>values.amount>choices.unity&&values.drive!=='none',past=sustains(target);
  if(past&&hold===null)return {ok:false,reason:`a rise past unity (${target.amount}) sustains itself: it is asked for with its hold, and its release`};
  if(past&&hold>choices.maxHoldSeconds)return {ok:false,reason:`held ${hold} s past unity: at most ${choices.maxHoldSeconds} s at one request`};
  // From one setting to another over `over` seconds from `at`: rung out first when it takes a sustaining loop under unity.
  const move=(from,to,at,over)=>{
    const ring=ringingAmount(over,design,{room:roomFor(design,from.delayMs),band:{hz:from.bandHz,db:from.bandDb,q:from.bandQ}});
    if(!sustains(from)||sustains(to)||to.amount>=ring)return [{atSeconds:at,seconds:over,values:to}];
    return [{atSeconds:at,seconds:Math.min(over,choices.rampSeconds),values:{...from,amount:ring}},{atSeconds:at+over,seconds:choices.rampSeconds,values:to}];
  };
  const steps=move(current,target,now,seconds);
  if(hold!==null){
    const back=setting(request.release??{},resting);
    if(back.error)return {ok:false,reason:back.error};
    if(sustains(back))return {ok:false,reason:'a release goes back under unity'};
    steps.push(...move(target,back,now+seconds+hold,Math.max(choices.minRampSeconds,finite(request.release?.seconds,seconds))));
  }
  return {ok:true,loop,steps,...(tunings.length?{tuning:tunings}:{})};
}

// The desk's loops: requests in, the mixer moved, releases kept until their time. `log(record)` hears every request
// and step ({kind: 'feedback', ...}).
export class FeedbackLoops {
  constructor(mixer,{log=null,choices=FEEDBACK_REQUESTS}={}){
    if(!mixer||typeof mixer.setEffects!=='function')throw new TypeError('FeedbackLoops needs the mixer (EnsembleMixer)');
    this.mixer=mixer;this.log=log;this.choices=choices;this.pending=new Map();this.applied=new Map();
    // Each loop's resting setting: what the mix had before any bot moved it.
    this.resting=Object.fromEntries(Object.keys(FEEDBACK_LOOPS).map(loop=>[loop,this.current(loop)]));
  }
  // A loop not as this desk last set it was set by a person (the desk's sliders, a link): that is its rest now, and a
  // release pending goes there.
  settle(loop){
    const last=this.applied.get(loop),now=this.current(loop);
    if(!last||Object.keys(now).every(key=>now[key]===last[key]))return;
    this.resting[loop]=now;this.applied.delete(loop);
    for(const step of this.pending.get(loop)??[])step.values={...now};
  }
  current(loop){return loopSettings(this.mixer.settings??{},FEEDBACK_LOOPS[loop])}
  // The loop's design: the mixer's, or, before it has built one, the design at its rate.
  design(){return this.mixer.mixLoop?.design??mixFeedbackDesign({sampleRate:this.mixer.context?.sampleRate})}
  apply(loop,{atSeconds,seconds,values}){
    const keys=FEEDBACK_LOOPS[loop];
    this.mixer.setEffects({[keys.amount]:values.amount,[keys.drive]:LOOP_DRIVES.indexOf(values.drive),[keys.driveAmount]:values.driveAmount,
      [keys.delayMs]:values.delayMs,[keys.bandHz]:values.bandHz,[keys.bandDb]:values.bandDb,[keys.bandQ]:values.bandQ,[keys.roughness]:values.roughness??0},{atSeconds,seconds});
    this.applied.set(loop,this.current(loop));
  }
  // A bot's request at `now` (the clock's seconds): {ok, reason} and, when taken, its steps.
  request(request,{now,source=null}={}){
    const loop=String(request?.loop??'mix');
    if(FEEDBACK_LOOPS[loop])this.settle(loop);
    const made=feedbackSteps(request,{now,current:FEEDBACK_LOOPS[loop]?this.current(loop):{},resting:this.resting[loop]??{},design:this.design(),choices:this.choices});
    this.log?.({kind:'feedback',source,request,...(made.ok?{steps:made.steps,...(made.tuning?{tuning:made.tuning}:{})}:{refused:made.reason})});
    if(!made.ok)return made;
    const [first,...later]=made.steps;
    this.apply(loop,first);
    // A request replaces the loop's pending release; its own, if it has one, waits for its time.
    if(later.length)this.pending.set(loop,later);else this.pending.delete(loop);
    return made;
  }
  // The clock at `now`: every release due, applied.
  tick(now){
    for(const [loop,steps] of this.pending){
      this.settle(loop);
      // Due now or a little before (the clock ticks): ramped from now, never from the past.
      while(steps.length&&steps[0].atSeconds<=now){const step={...steps.shift(),atSeconds:now};this.apply(loop,step);this.log?.({kind:'feedback',source:'release',loop,step})}
      if(!steps.length)this.pending.delete(loop);
    }
  }
}
