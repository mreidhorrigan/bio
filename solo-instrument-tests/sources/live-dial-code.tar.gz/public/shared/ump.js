// Toolkit-neutral UMP boundary. Word arrays are authoritative; decoded fields
// are transient views. Network/persistence encoding uses arrays of uint32s.
import JZZ from '../vendor/jzz.js';

export const UMP_VERSION = '1.1.2';
export const DEFAULT_TPQ = 9600;
export const WORD_COUNTS = Object.freeze([1,1,1,2,2,4,1,1,2,2,2,3,3,4,4,4]);
export const integer = (value, max, name) => {
  if (!Number.isInteger(value) || value < 0 || value > max) throw new RangeError(`${name} must be an integer in 0..${max}`);
  return value;
};
export function umpPacket(words) {
  if (!Array.isArray(words) && !(words instanceof Uint32Array)) throw new TypeError('UMP requires an array of uint32 words');
  if (!words.length || words.length !== WORD_COUNTS[words[0] >>> 28]) throw new RangeError('UMP packet length does not match its message type');
  return Uint32Array.from(words, word => integer(word, 0xffffffff, 'UMP word'));
}
// A Set Tempo (UMP Flex Data, group 0's: status bank 0, status 0) at `bpm` quarters a minute: its word the quarter's
// length in tens of nanoseconds.
export const setTempo = bpm => [0xD0100000, Math.round(6e9/bpm)>>>0, 0, 0];
// A Set Tempo's quarters a minute, or null for any other packet.
export const tempoOf = packet => (packet[0]>>>0) === 0xD0100000 && packet[1] > 0 ? 6e9/(packet[1]>>>0) : null;
export function serializeUMP(words) {
  const packet = umpPacket(words), bytes = new Uint8Array(packet.length * 4), view = new DataView(bytes.buffer);
  packet.forEach((word,index) => view.setUint32(index*4,word,false));
  return bytes;
}
export function deserializeUMP(bytes) {
  bytes = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  if (!bytes.length || bytes.length % 4) throw new RangeError('UMP byte length must be a nonzero multiple of four');
  const view = new DataView(bytes.buffer,bytes.byteOffset,bytes.byteLength);
  return umpPacket(Array.from({length:bytes.length/4}, (_,i) => view.getUint32(i*4,false)));
}
export function pitch79(pitch) {
  // Name the value. "Pitch 7.9" is the MIDI 2 fixed-point format, not the offending number,
  // and an error that does not say what it rejected sends whoever reads it looking for a note
  // at 7.9 semitones — which is where this one was found, in a page log, unreportable.
  if (!Number.isFinite(pitch) || pitch < 0 || pitch > 65535/512)
    throw new RangeError(`Pitch ${pitch} cannot be encoded as MIDI 2 Pitch 7.9, `
      +`which spans 0..127.998046875 semitones`);
  return Math.round(pitch * 512);
}
export function bend32(semitones, range=48) {
  if (!Number.isFinite(semitones) || !Number.isFinite(range) || range <= 0 || Math.abs(semitones) > range) throw new RangeError('Per-note bend exceeds its specified range');
  return Math.round(0x80000000 + semitones / range * (semitones < 0 ? 0x80000000 : 0x7fffffff));
}
export function bendSemitones(value, range=48) {
  return (value-0x80000000)/(value < 0x80000000 ? 0x80000000 : 0x7fffffff)*range;
}
const fromJzz = packet => deserializeUMP(Uint8Array.from(packet));
const checkAddress = (group,channel,note) => [integer(group,15,'group'),integer(channel,15,'channel'),integer(note,127,'note index')];

export function createJzzCodec() {
  return {
    name:'jzz',
    noteOn: (g,c,n,v,a,p) => fromJzz(JZZ.UMP.umpNoteOn(g,c,n,v,a,p)),
    noteOff: (g,c,n,v,a,p) => fromJzz(JZZ.UMP.umpNoteOff(g,c,n,v,a,p)),
    bend: (g,c,n,v) => fromJzz(JZZ.UMP.umpPnPitchBend(g,c,n,v)),
    pressure: (g,c,n,v) => fromJzz(JZZ.UMP.umpAftertouch(g,c,n,v)),
    controller: (g,c,n,i,v) => fromJzz(JZZ.UMP.umpPnRPN(g,c,n,i,v)),
    inspect(words) {
      const p=umpPacket(words), message=JZZ.UMP(Array.from(serializeUMP(p)));
      return {type:message[0]>>4, group:message[0]&15, status:message[1], channel:message[1]&15,
        note:message[2], velocity:((message[4]||0)<<8)|(message[5]||0), data:p[1]||0};
    },
  };
}

export async function createWasmCodec(bytes) {
  const result = await WebAssembly.instantiate(bytes, {}), api=result.instance?.exports || result.exports;
  const buffer = new Uint32Array(api.memory.buffer,api.ump_buffer(),4);
  const call=(name,args)=>{api[name](...args);return buffer.slice(0,2)};
  return {
    name:'midi2-c99-wasm',
    noteOn:(...args)=>call('ump_note_on',args), noteOff:(...args)=>call('ump_note_off',args),
    bend:(...args)=>call('ump_bend',args), pressure:(...args)=>call('ump_pressure',args),
    controller:(...args)=>call('ump_controller',args),
    inspect(words) {
      buffer.fill(0); buffer.set(umpPacket(words));
      const [type,group,status,channel,note,velocity,data]=Array.from({length:7},(_,i)=>api.ump_field(i)>>>0);
      return {type,group,status,channel,note,velocity,data};
    },
    preserve(words) {buffer.fill(0);buffer.set(umpPacket(words));return buffer.slice(0,api.ump_words(buffer[0]>>>28))},
    fromMidi1(word) {return api.ump_from_midi1(integer(word,0xffffffff,'MIDI 1 UMP')) ? buffer.slice(0,2) : null},
  };
}
let codec=createJzzCodec(), initialization;
export const midi2Backend = () => codec.name;
export const upgradeMidi1Channel = word => codec.fromMidi1?.(word) || null;
export async function initializeMidi2({bytes,url='wasm/midi2.wasm'}={}) {
  if (!initialization) initialization=(async()=>{
    if (!bytes) {const response=await fetch(url);if(!response.ok)throw new Error(`MIDI 2 WASM HTTP ${response.status}`);bytes=await response.arrayBuffer()}
    codec=await createWasmCodec(bytes);return codec;
  })().catch(error=>{initialization=null;throw error});
  return initialization;
}
export function noteOn({group=0,channel=0,note,pitch=note,velocity=0xffff,attribute=3,attributeData}={}, backend=codec) {
  checkAddress(group,channel,note);integer(velocity,65535,'velocity');integer(attribute,255,'attribute');
  return backend.noteOn(group,channel,note,velocity,attribute,integer(attributeData??(attribute===3?pitch79(pitch):0),65535,'attribute data'));
}
export function noteOff({group=0,channel=0,note,velocity=0,attribute=0,attributeData=0}={}, backend=codec) {
  checkAddress(group,channel,note);integer(velocity,65535,'release velocity');integer(attribute,255,'attribute');integer(attributeData,65535,'attribute data');
  return backend.noteOff(group,channel,note,velocity,attribute,attributeData);
}
export function perNoteBend({group=0,channel=0,note,value=0x80000000}={},backend=codec) {
  checkAddress(group,channel,note);return backend.bend(group,channel,note,integer(value,0xffffffff,'bend'));
}
export function perNotePressure({group=0,channel=0,note,value=0}={},backend=codec) {
  checkAddress(group,channel,note);return backend.pressure(group,channel,note,integer(value,0xffffffff,'pressure'));
}
export function perNoteController({group=0,channel=0,note,index=74,value=0}={},backend=codec) {
  checkAddress(group,channel,note);return backend.controller(group,channel,note,integer(index,255,'controller'),integer(value,0xffffffff,'controller value'));
}
// An Assignable Per-Note Controller (status 0x1): one its receiver defines, as a family's table names it
// (docs/MIDI2_SYNTH_INPUT.md: only where no registered controller or profile names the thing).
export function assignablePerNoteController({group=0,channel=0,note,index=0,value=0}={}) {
  checkAddress(group,channel,note);integer(index,255,'controller');integer(value,0xffffffff,'controller value');
  return fromJzz(JZZ.UMP.umpPnNRPN(group,channel,note,index,value));
}
export function perNoteManagement({group=0,channel=0,note,detach=true,reset=true}={}) {
  checkAddress(group,channel,note);
  return fromJzz(JZZ.UMP.umpPnManagement(group,channel,note,(detach?2:0)|(reset?1:0)));
}
export function perNoteBendRange({group=0,channel=0,range=48}={}) {
  checkAddress(group,channel,0);
  if(!Number.isFinite(range)||range<0||range>=128)throw new RangeError('Per-note bend sensitivity must be in 0..128 semitones');
  return fromJzz(JZZ.UMP.umpRPN(group,channel,0,7,Math.round(range*0x2000000)));
}
export function channelControl({group=0,channel=0,index,value=0}={}) {
  checkAddress(group,channel,0);integer(index,127,'controller');integer(value,0xffffffff,'controller value');
  return fromJzz(JZZ.UMP.umpControl(group,channel,index,value));
}
// A MIDI 2 Program Change, no bank (the channel's bank stays as it is).
export function programChange({group=0,channel=0,program}={}) {
  checkAddress(group,channel,0);integer(program,127,'program');
  return fromJzz(JZZ.UMP.umpProgram(group,channel,program));
}
export function inspectUMP(words,backend=codec) {
  const packet=umpPacket(words), fields=backend.inspect(packet);
  const result={...fields,packet,statusNibble:fields.status>>4,kind:'unknown'};
  if(fields.type===4) {
    result.attribute=packet[0]&255;result.attributeData=packet[1]&65535;
    result.key=`${fields.group}:${fields.channel}:${fields.note}`;
    result.kind=({0:'perNoteController',1:'assignablePerNoteController',2:'registeredController',3:'assignableController',4:'relativeRegisteredController',5:'relativeAssignableController',6:'perNoteBend',8:'noteOff',9:'noteOn',10:'perNotePressure',11:'control',12:'program',13:'channelPressure',14:'channelBend',15:'perNoteManagement'})[result.statusNibble]||'unknown';
    if(result.kind==='noteOn') result.pitch=result.attribute===3?result.attributeData/512:fields.note;
  }
  return result;
}
export function timedUMP(events,{maxEvents=131072}={}) {
  if(!Array.isArray(events)||events.length>maxEvents)throw new RangeError(`UMP sequence needs 0..${maxEvents} events`);
  let previous=-Infinity;
  return events.map(event=>{
    if(!Number.isFinite(event.time)||event.time<0||event.time<previous)throw new RangeError('UMP event times must be finite, nonnegative and ordered');
    previous=event.time;
    return Object.freeze({time:event.time,packet:Object.freeze(Array.from(umpPacket(event.packet)))});
  });
}
export {JZZ};
