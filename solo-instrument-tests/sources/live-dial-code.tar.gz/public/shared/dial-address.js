// A live dial's page in its address (the owner, 5 November 2026: "we also need a way to store and indicate page/Musebot
// state (including seed) on the soloist page concisely with URL queries"): the instrument, its musebot's seed, and what
// else is set, so that a link opens the page as it was. As the owner's website keeps its own (tower-address.js, the
// signal towers' ?signals=; engine.js ?slime=, ?theme=): readable keys for what is read most, one packed for the rest,
// written in place (history.replaceState), each key only where it says something, and an address that cannot be read
// said and left, never a page refused.
//   ?instrument=flute&seed=20260916&seconds=90&personality=(daring:.62,ranges:(register:!(.2,.8)))&dial=(dynamic:f)
//   - instrument   the instrument taken up;
//   - seed         its musebot's seed, always: what the piece is drawn from;
//   - seconds      the most its musebot plays, where it is not the page's own;
//   - personality  its musebot's levers, motif grammars and tone ranges set (ticked) on the page, each a share;
//   - dial         the dial's settings that differ from the instrument as the page took it up -- the same settings a
//                  settings file holds (dial-settings.js), less what the dial derives from them.
// The packed values are JSON written for an address, after Rison: an object (key:value,...), a list !(value,...), a
// string bare where it reads as a name and else 'quoted' (! escaping ' and !), !t !f !n for true, false and null, and a
// number as JavaScript writes it, its leading 0 left off (.62) -- none of which an address need escape. A number not
// whole is kept to six significant figures: a hundredth of a cent on a pitch in semitones.
// A link is read back as settings on the instrument as the page takes it up (settingsFromAddress), loaded as a settings
// file is (each family's load), so the page and a file say the same things the same way.

// (What each family's settings derive from the rest: not carried, as a settings file's loader does not read them -- a
// string's finger and bow place from its pitch and the bow's share of the length it sounds.)
const DERIVED=Object.freeze({winds:Object.freeze(['family','model','body','plays']),strings:Object.freeze(['family','model','openHz','dampingNsPerM','finger','pos'])});
// (The musebot's, carried by keys of their own.)
const PLAYER='player';
const SIGNIFICANT=6;

// ---- the packed notation ----
const rounded=v=>Number.isInteger(v)?v:Number(v.toPrecision(SIGNIFICANT));
const numberText=v=>{const t=String(rounded(v));return t.replace(/^(-?)0\./,'$1.')};
// (A string written bare: a name, never a number's start, never one of the notation's own characters.)
const BARE=/^[A-Za-z_][A-Za-z0-9_.\-~]*$/;
export function encodeValue(v){
  if(v===null||v===undefined)return '!n';
  if(v===true)return '!t';
  if(v===false)return '!f';
  if(typeof v==='number'){if(!Number.isFinite(v))throw new Error(`no number ${v} in an address`);return numberText(v)}
  if(typeof v==='string')return BARE.test(v)?v:`'${v.replace(/[!']/g,c=>`!${c}`)}'`;
  if(Array.isArray(v))return `!(${v.map(encodeValue).join(',')})`;
  if(typeof v==='object')return `(${Object.entries(v).filter(([,x])=>x!==undefined).map(([k,x])=>`${encodeValue(String(k))}:${encodeValue(x)}`).join(',')})`;
  throw new Error(`no ${typeof v} in an address`);
}
export function decodeValue(text){
  let at=0;
  const fail=what=>{throw new Error(`${what} at ${at} of ${JSON.stringify(text)}`)};
  const peek=()=>text[at];
  function value(){
    const c=peek();
    if(c===undefined)fail('a value ends early');
    if(c==='('){at++;const out={};if(peek()===')'){at++;return out}
      for(;;){const k=value();if(typeof k!=='string')fail('a key not a name');if(text[at++]!==':')fail('no ":" after a key');out[k]=value();
        const n=text[at++];if(n===')')return out;if(n!==',')fail('no "," or ")" in an object')}}
    if(c==='!'){const n=text[at+1];at+=2;
      if(n==='t')return true;if(n==='f')return false;if(n==='n')return null;
      if(n!=='(')fail(`no !${n}`);
      const out=[];if(peek()===')'){at++;return out}
      for(;;){out.push(value());const m=text[at++];if(m===')')return out;if(m!==',')fail('no "," or ")" in a list')}}
    if(c==='\''){at++;let s='';
      for(;;){const d=text[at++];if(d===undefined)fail('a quoted string not closed');if(d==='\'')return s;
        if(d==='!'){const e=text[at++];if(e!=='!'&&e!=='\'')fail(`no !${e} in a string`);s+=e}else s+=d}}
    const number=/^-?(?:\d+\.?\d*|\.\d+)(?:e[+-]?\d+)?/i.exec(text.slice(at));
    if(number){at+=number[0].length;return Number(number[0])}
    const bare=/^[A-Za-z_][A-Za-z0-9_.\-~]*/.exec(text.slice(at));
    if(bare){at+=bare[0].length;return bare[0]}
    return fail(`no value from "${c}"`);
  }
  const out=value();
  if(at!==text.length)fail('more after a value');
  return out;
}
// (In the address: escaped as a query's value needs, the notation's own characters left as they are.)
const escaped=text=>encodeURIComponent(text).replace(/%(3A|2C|40|24|2F)/g,c=>decodeURIComponent(c));

// ---- settings against the instrument as taken up ----
const same=(a,b)=>JSON.stringify(normal(a))===JSON.stringify(normal(b));
const normal=v=>typeof v==='number'?rounded(v):Array.isArray(v)?v.map(normal):v&&typeof v==='object'?Object.fromEntries(Object.entries(v).map(([k,x])=>[k,normal(x)])):v;
const isObject=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
// What differs in `now` from `before`: an object's keys that differ, each object within compared so too, any other value
// whole. -> the difference, or undefined where there is none.
export function difference(before,now){
  if(isObject(before)&&isObject(now)){
    const out={};
    for(const [k,v] of Object.entries(now)){if(v===undefined)continue;const d=Object.hasOwn(before,k)?difference(before[k],v):normal(v);if(d!==undefined)out[k]=d}
    return Object.keys(out).length?out:undefined;
  }
  return same(before,now)?undefined:normal(now);
}
// `before` with a difference made on it: each object within merged so too, any other value replaced.
export function merged(before,diff){
  if(!isObject(before)||!isObject(diff))return diff===undefined?before:diff;
  const out={...before};
  for(const [k,v] of Object.entries(diff))out[k]=merged(before[k],v);
  return out;
}

// ---- the address ----
// The page's address for its settings: `model` the instrument; `settings` its family's (dial-settings.js), with its
// musebot's under `player` ({seed, seconds, personality}); `before`, the settings as the page took the instrument up.
// -> the query, '?instrument=...'.
export function addressOf({model,settings,before=null}){
  const family=settings?.family,player=settings?.[PLAYER]??null,skip=new Set([...(DERIVED[family]??[]),PLAYER]);
  const own=s=>s&&Object.fromEntries(Object.entries(s).filter(([k])=>!skip.has(k)));
  const keys=[['instrument',model]];
  if(player){
    if(Number.isFinite(player.seed))keys.push(['seed',String(player.seed)]);
    const was=before?.[PLAYER];
    if(Number.isFinite(player.seconds)&&!(was&&same(was.seconds,player.seconds)))keys.push(['seconds',numberText(player.seconds).replace(/^\./,'0.')]);
    if(player.personality&&Object.keys(player.personality).length)keys.push(['personality',encodeValue(normal(player.personality))]);
  }
  const dial=before?difference(own(before),own(settings)):undefined;
  if(dial!==undefined)keys.push(['dial',encodeValue(dial)]);
  return `?${keys.map(([k,v])=>`${k}=${escaped(v)}`).join('&')}`;
}
// An address read: -> {instrument, seed, seconds, personality, dial, unread: [what could not be read, and why]}, each
// absent where the address does not say it.
export function readAddress(search){
  const q=new URLSearchParams(search),out={unread:[]};
  const instrument=q.get('instrument');if(instrument)out.instrument=instrument;
  for(const k of ['seed','seconds']){
    if(!q.has(k))continue;
    const v=Number(q.get(k));
    if(Number.isFinite(v)&&(k!=='seed'||Number.isInteger(v)&&v>=0)&&(k!=='seconds'||v>0))out[k]=v;else out.unread.push(`${k}: ${JSON.stringify(q.get(k))} is no ${k==='seed'?'seed':'length'}`);
  }
  for(const k of ['personality','dial']){
    if(!q.has(k))continue;
    try{const v=decodeValue(q.get(k));if(!isObject(v))throw new Error('not an object');out[k]=v}
    catch(error){out.unread.push(`${k}: ${error.message}`)}
  }
  return out;
}
// Whether an address asks for more than its instrument: a musebot or dial settings to make.
export const asksSettings=read=>['seed','seconds','personality','dial'].some(k=>read[k]!==undefined);
// The settings an address asks for, on the instrument as the page took it up (`before`, its family's settings): its
// dial's made on them, and its musebot's on theirs -- the seed and length where it gives them, its personality as given
// (none set where it gives none).
export function settingsFromAddress(read,before){
  const out=merged(before,read.dial);
  const player={...(before?.[PLAYER]??{})};
  if(read.seed!==undefined)player.seed=read.seed;
  if(read.seconds!==undefined)player.seconds=read.seconds;
  player.personality=read.personality??{};
  return {...out,family:before.family,model:before.model,[PLAYER]:player};
}
