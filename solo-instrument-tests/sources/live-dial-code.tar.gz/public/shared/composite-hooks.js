// Composite hooks (the memorable motifs report, §6.4 and §15.7): a figure several parts make together that none of them
// plays alone, "a low attack, a dry higher response and a pitched or noisy accent". Kept as one family by its combined
// relative timing and its timbral roles, never by who plays them: the same figure from other players is another
// realization of it, not another family. Each bar that sounds it is one occurrence of the family, however many parts
// share it ("A literal repetition across the same ensemble should create one composite occurrence, not three independent
// exposures").
//
// Heard from the onsets the rhythm bots announce (/broadcast/onsets: {voice, role, onsets: [{tick, strength, kind}]}),
// placed on the ensemble's ticks: the role-combined event stream, with each event's owner. A riff's or a bass line's
// notes join it from the voices they announce (/broadcast/voices, role line or bass: voiceOnset), a comp's chords not. The bar is the cycle compared
// (§6.4: bounded windows, never a least common multiple of every part's cycle). The fast stream (a closed hat, a shaker)
// is left out: at its rate the figure is in the slower events around it (§6.6).

export const COMPOSITE=Object.freeze({
  // The roles, by the kind a stroke is announced with.
  roles:Object.freeze({kick:'low',softKick:'low',snare:'high',rim:'high',clap:'high',tom:'mid',crash:'accent',ride:'accent',
    openHat:'accent',perc:'accent',bell:'accent',closedHat:'tick',hihat:'tick',shaker:'tick',bassNote:'low',lineNote:'pitched'}),
  // A line's note below this pitch is a low attack (a bass's); at or above it, a pitched accent (E3; ours).
  lowPitch:52,
  // What makes a composite: at least this many parts, and this many events, besides the fast stream.
  leastParts:2,leastEvents:3,
});

// A stroke's role from its announced kind: low, high, mid, accent, pitched, or tick (the fast stream); unknown kinds are
// mid.
export const roleOf=kind=>COMPOSITE.roles[String(kind??'')]??'mid';
// A riff's or a bass line's note as an onset, from the voices it announces ({voice, role, pitches, tick}): role line or
// bass, its lowest pitch below lowPitch a low attack, else a pitched accent. A comp's chords (role chord) are no onset of
// a figure here. -> {voice, tick, kind} or null.
export function voiceOnset(payload,{choices=COMPOSITE}={}){
  if(!payload||!['line','bass'].includes(payload.role)||!Number.isFinite(Number(payload.tick)))return null;
  const pitches=(payload.pitches??[]).map(Number).filter(Number.isFinite);if(!pitches.length)return null;
  return {voice:String(payload.voice??''),tick:Number(payload.tick),kind:Math.min(...pitches)<choices.lowPitch||payload.role==='bass'?'bassNote':'lineNote'};
}

// The composite a bar holds: `onsets` [{voice, tick, kind, strength}] on the ensemble's ticks, the bar from `start` for
// `pulses` ticks, in `meter` (its label names the cycle). -> {key (the family's identity: the meter, and each event's
// place in the bar and role), realization (which voice took each role), events [{at, role, voice}], parts} or null
// where fewer than leastParts parts, or fewer than leastEvents events, sound in it besides the fast stream.
export function compositeOf(onsets,{start,pulses,meter='',choices=COMPOSITE}={}){
  if(!(pulses>0)||!Number.isFinite(start))return null;
  const events=[];
  for(const onset of onsets??[]){
    const tick=Number(onset?.tick);if(!Number.isFinite(tick)||tick<start||tick>=start+pulses)continue;
    const role=roleOf(onset.kind);if(role==='tick')continue;
    events.push({at:Math.round(tick-start),role,voice:String(onset.voice??'')});
  }
  // One event a place and role (two voices striking together in one role are the one event, both its owners).
  const byPlace=new Map;
  for(const event of events.sort((a,b)=>a.at-b.at||(a.role<b.role?-1:a.role>b.role?1:0)||(a.voice<b.voice?-1:1))){
    const key=`${event.at}:${event.role}`,known=byPlace.get(key);
    if(known){if(!known.voices.includes(event.voice))known.voices.push(event.voice)}else byPlace.set(key,{at:event.at,role:event.role,voices:[event.voice]});
  }
  const merged=[...byPlace.values()],parts=new Set(merged.flatMap(event=>event.voices));
  if(parts.size<choices.leastParts||merged.length<choices.leastEvents)return null;
  const key=`${meter}|${pulses}|${merged.map(event=>`${event.at}:${event.role}`).join(',')}`;
  const realization=[...new Set(merged.flatMap(event=>event.voices.map(voice=>`${event.role}:${voice}`)))].sort().join(',');
  return Object.freeze({key,realization,parts:parts.size,events:Object.freeze(merged.map(event=>Object.freeze({at:event.at,role:event.role,voices:Object.freeze([...event.voices])})))});
}

// The composites heard, as families: each identity (key) its family, how often heard, and its realizations (the voices
// that took its roles). Bounded: past `limit`, the least heard go first.
export class CompositeHooks{
  constructor({limit=64}={}){this.limit=limit;this.families=new Map;this.count=0}
  // A bar's composite heard at `beats` (score beats): its family (a new one, or the one it restates) and whether its
  // realization is new -> {family, key, exposure, realization, newRealization, first}.
  hear(composite,{beats=null}={}){
    if(!composite)return null;
    let family=this.families.get(composite.key);const first=!family;
    if(first){family={family:`composite:${++this.count}`,key:composite.key,exposure:0,realizations:new Set,firstBeats:beats,lastBeats:beats,events:composite.events.length};this.families.set(composite.key,family)}
    family.exposure++;family.lastBeats=beats;
    const newRealization=!family.realizations.has(composite.realization);if(newRealization&&family.realizations.size<16)family.realizations.add(composite.realization);
    while(this.families.size>this.limit){const least=[...this.families.values()].sort((a,b)=>a.exposure-b.exposure||a.lastBeats-b.lastBeats)[0];this.families.delete(least.key)}
    return Object.freeze({family:family.family,key:family.key,exposure:family.exposure,realization:composite.realization,newRealization:newRealization&&!first,first});
  }
  report(){return [...this.families.values()].sort((a,b)=>b.exposure-a.exposure||(a.family<b.family?-1:1)).map(family=>({family:family.family,exposure:family.exposure,events:family.events,realizations:[...family.realizations].sort()}))}
}
