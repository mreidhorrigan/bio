import { pitchClass } from './pitch.js';
import {bandPhraseBars} from './opening-time.js';

const clamp=(value,min,max)=>Math.max(min,Math.min(max,value));

export function normalizeActivityMask(values,length=16){
  const input=Array.isArray(values)?values:String(values??'').split('_');
  return Array.from({length},(_,index)=>clamp(Number.isFinite(Number(input[index]))?Math.round(Number(input[index])):0,0,9));
}

export function complementaryActivityMask(masks,length=16){
  const cumulative=Array(length).fill(0);
  for(const mask of masks){const normalized=normalizeActivityMask(mask,length);for(let index=0;index<length;index++)cumulative[index]=clamp(cumulative[index]+normalized[index],0,9)}
  return cumulative.map(value=>9-value);
}

export function residualActivityMask(desired,masks,length=16){
  const target=normalizeActivityMask(desired,length);if(!masks.length)return target;
  const normalized=masks.map(mask=>normalizeActivityMask(mask,length));
  return target.map((value,index)=>clamp(Math.round(value-normalized.reduce((sum,mask)=>sum+mask[index],0)/normalized.length),0,9));
}

export function normalizeRepetitionStructure(values,length=4){
  const input=Array.isArray(values)?values:String(values??'').split('_');
  return Array.from({length},(_,index)=>String(input[index]??String.fromCharCode(65+index)).slice(0,16));
}

export function normalizeTalaStructure(values,total=null){
  const input=(Array.isArray(values)?values:String(values??'').split('_')).map(Number).filter(value=>Number.isInteger(value)&&value>0);
  return total==null||input.reduce((sum,value)=>sum+value,0)===total?input:[];
}

export function normalizePitchclassPool(values){
  const input=Array.isArray(values)?values:String(values??'').split('_');
  return[...new Set(input.map(pitchClass).filter(value=>value!==null))];
}

export function normalizeContour(values,length=8){
  const input=Array.isArray(values)?values:String(values??'').replace(/^"|"$/g,'').split('_');
  return Array.from({length},(_,index)=>String(input[index]??(index<length/2?'U':'D')).toUpperCase()==='U'?'U':'D');
}

export function parseCompoundIntent(message){
  if(message?.address!=='/broadcast/intent')return null;const args=[...(message.args||[])];if(args[0]==='/intent')args.shift();const sender=String(args.shift()??''),fields={};for(const argument of args){const [name,...parts]=String(argument).split('=');if(name&&parts.length)fields[name]=parts.join('=')}
  return{sender,fields,activityMask:fields.activityMask==null?null:normalizeActivityMask(fields.activityMask),pitchclassPool:fields.pitchclassPool==null?null:normalizePitchclassPool(fields.pitchclassPool),repetitionStructure:fields.repetitionStructure==null?null:normalizeRepetitionStructure(fields.repetitionStructure),talaStructure:fields.talaStructure==null?null:normalizeTalaStructure(fields.talaStructure),contourA:fields.contourA==null?null:normalizeContour(fields.contourA),iFollow:fields.iFollow==null?null:String(fields.iFollow),synchro:fields.synchro==null?null:Number(fields.synchro)};
}

export function serializeCompoundIntent(sender,activityMask,pitchclassPool){return[sender,`activityMask=${normalizeActivityMask(activityMask).join('_')}`,`pitchclassPool=${normalizePitchclassPool(pitchclassPool).join('_')}`]}

export function serializeIntentFields(sender,fields){return[sender,...Object.entries(fields).filter(([,value])=>value!=null).map(([name,value])=>`${name}=${(Array.isArray(value)?value:[value]).join('_')}`)]}

export function cycleIndexAtPhrasePosition(clock,length=16){
  const beatsPerBar=clock.meter.numerator,bars=clock.meter.phraseBars||bandPhraseBars(),beatProgress=(clock.bar%bars)*beatsPerBar+clock.beat+(clock.subdivision||0)/clock.meter.subdivision,total=beatsPerBar*bars;return Math.max(0,Math.min(length-1,Math.floor(beatProgress/total*length)));
}
