import { unitRandom } from './stochastic.js';

export function distinctBinaryForm(sectionCount,voiceCount,probabilities){
  const form=[];let previous=null;
  for(let section=0;section<sectionCount;section++){
    let state=Array.from({length:voiceCount},(_,index)=>unitRandom()<(probabilities[index]??.5)*(previous?.[index]===0?.5:1)?1:0);
    if(!state.some(Boolean))state[section%voiceCount]=1;
    if(previous&&state.every((value,index)=>value===previous[index]))state[(section+1)%voiceCount]^=1;
    if(!state.some(Boolean))state[section%voiceCount]=1;
    form.push(state);previous=state;
  }
  return form;
}
