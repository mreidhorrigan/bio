// The rhythm performance layer's core (research/rhythmic_humanization_state_of_the_art.md; docs/TODO.md "a performance
// layer for rhythm", stages A and B): deterministic, inspectable timing on top of the score. Never a "humanize amount"
// knob and never random jitter around a grid: every offset has a named cause, a size and a source.
//
// Score time stays apart from performed time (§7.1). A note keeps its score position; the layer says how far from it the
// note is played, and why, in separate terms that add: the warp of its subdivision (swing, W_metric, which keeps the
// beat's anchors where they are), its role's offset for its beat class ("behind" is relative to which notes and which
// partner, §3), and, later, a phrase's. Tempo changes belong to the tempo plan, not here.
//
// Where it meets others' layers (agreed with the mix-pro session, 27 September):
// - the offsets add to a kit's physical lateness (kit.js navigation), and a fill is checked again where it sounds;
// - a contact already committed (live.js planLive) is never moved;
// - a grace note keeps its technique's seconds before its principal: the warp moves principals only;
// - an electronic part (a kernel stream, a part claimed electronic, a rate contract's own-rate grid) gets no human timing.
//
// Stage B's profiles are measured, each with its provenance (MEASURED_TIMING below), from the Groove MIDI Dataset's
// train split (scripts/measure-drum-timing.mjs). Its validation split checks them; its test split is left alone.

import {tactusOf} from './meter-tactus.js';
import {defaultGrouping} from '../stochastic-algorithms.js';
import {randomAt} from '../random-source.js';
import {styleSpace} from './style-space.js';

const finite=(value,name)=>{if(typeof value!=='number'||!Number.isFinite(value))throw new TypeError(`${name} must be a finite number`);return value};

// ---- Stage A primitives (§7.8) ---------------------------------------------------------------------------------------

// A swing ratio (long to short) as the long note's share of the pair: 2:1 is 2/3, 1:1 is 1/2.
export function swingFraction(ratio){
  finite(ratio,'ratio');
  if(ratio<=0)throw new RangeError('a swing ratio must be positive');
  const s=1/(1+1/ratio);
  if(s<=0||s>=1)throw new RangeError('a swing ratio beyond float precision');
  return s;
}
// How late a swung pair's second note is, in seconds, at a tempo of `bpm` quarter notes and a pair of so many quarters.
export function swingDelay(bpm,fraction,quartersPerPair=1){
  finite(bpm,'bpm');finite(fraction,'fraction');finite(quartersPerPair,'quartersPerPair');
  if(bpm<=0||quartersPerPair<=0)throw new RangeError('tempo and pair length must be positive');
  if(fraction<=0||fraction>=1)throw new RangeError('a swing fraction lies strictly between 0 and 1');
  return (fraction-.5)*60/bpm*quartersPerPair;
}
// A beat's subdivision boundaries from positive weights, 0 to 1: [1, 1] the even pair, [2, 1] a triplet swing, [3, 2]
// a five of three and two. Unequal subdivisions are structure, not error (§6).
export function boundaries(weights){
  if(!Array.isArray(weights)||!weights.length)throw new TypeError('weights must be a nonempty array');
  for(const weight of weights){finite(weight,'weight');if(weight<=0)throw new RangeError('weights must be positive')}
  const scale=Math.max(...weights),scaled=weights.map(weight=>weight/scale),total=scaled.reduce((a,b)=>a+b,0),out=[0];
  let at=0;for(const weight of scaled){at+=weight;out.push(at/total)}
  out[out.length-1]=1;
  for(let i=1;i<out.length;i++)if(out[i]<=out[i-1])throw new RangeError('a collapsed boundary');
  return out;
}
// A phase in [0, 1] moved from nominal boundaries to performed ones, piecewise linearly: the boundaries' own anchors
// (0 and 1, the beat) stay where they are, and the order of events is kept (every interval stays positive).
export function warpPhase(x,nominal,performed){
  finite(x,'phase');
  if(x<0||x>1)throw new RangeError('a phase lies in [0, 1]');
  if(!Array.isArray(nominal)||!Array.isArray(performed)||nominal.length!==performed.length||nominal.length<2)
    throw new TypeError('boundary arrays must have equal lengths of at least two');
  for(const list of [nominal,performed]){
    if(list[0]!==0||list.at(-1)!==1)throw new RangeError('boundaries begin at 0 and end at 1');
    for(let j=1;j<list.length;j++){finite(list[j],'boundary');if(list[j]<=list[j-1])throw new RangeError('unordered boundaries')}
  }
  if(x===1)return 1;
  let j=0;while(j<nominal.length-2&&x>=nominal[j+1])j++;
  return performed[j]+(x-nominal[j])/(nominal[j+1]-nominal[j])*(performed[j+1]-performed[j]);
}
// Offset-aware phase correction (§7.5, stage C): the next anchor predicted from the player's own time and its peers',
// each less its intended offset, so a deliberate offset is kept and only error is corrected, by at most `maxCorrection`.
export function nextAlignedAnchor(own,peers,period,maxCorrection){
  finite(period,'period');finite(maxCorrection,'maxCorrection');
  if(period<=0||maxCorrection<0)throw new RangeError('invalid correction limits');
  if(!Array.isArray(peers))throw new TypeError('peers must be an array');
  const u=finite(own.time,'time')-finite(own.intendedOffset,'offset');
  let correction=0;
  for(const peer of peers){
    const gain=finite(peer.gain,'gain');if(gain<0)throw new RangeError('a gain is nonnegative');
    correction+=gain*(u-(finite(peer.time,'peer time')-finite(peer.intendedOffset,'peer offset')));
  }
  correction=Math.max(-maxCorrection,Math.min(maxCorrection,finite(correction,'summed correction')));
  return u+period-correction;
}

// ---- Swing profiles (§2.3) -------------------------------------------------------------------------------------------

// A profile: which pair it swings ('eighth' a beat's two halves, 'sixteenth' each half's), its fraction at tempos (knots
// of {bpm, fraction}, in the click's quarter notes), the tempo range it was measured over, and where it came from.
// Between knots, linear; outside the range, the nearest end, flagged as extrapolated.
export function swingAt(profile,bpm){
  finite(bpm,'bpm');
  const knots=[...(profile?.knots??[])].sort((a,b)=>a.bpm-b.bpm);
  if(!knots.length)return {fraction:.5,extrapolated:false};
  const [low,high]=profile.range??[knots[0].bpm,knots.at(-1).bpm],extrapolated=bpm<low||bpm>high;
  if(bpm<=knots[0].bpm)return {fraction:knots[0].fraction,extrapolated};
  if(bpm>=knots.at(-1).bpm)return {fraction:knots.at(-1).fraction,extrapolated};
  const j=knots.findIndex(knot=>knot.bpm>bpm),a=knots[j-1],b=knots[j];
  return {fraction:a.fraction+(bpm-a.bpm)/(b.bpm-a.bpm)*(b.fraction-a.fraction),extrapolated};
}

// ---- Stage B: measured profiles ---------------------------------------------------------------------------------------

// From the Groove MIDI Dataset v1.0.0's train split (research/derived/drum-timing-gmd-train-2026-09-27.json; checked on
// the validation split, -validation-2026-09-27.json). Swing from the hi-hat's and ride's pairs; offsets in milliseconds
// against each take's own lead on the click, by instrument and beat of the bar, the medians of the takes' medians.
// - jazz: its eighth pairs swing, a median .65 over 21 takes of 5 drummers (quartiles .52 and .70); on the validation
//   split .69 (2 takes). Its tempo bands (.52 at 100-115, .67 at 115-130, .66 above) are few takes each and confound
//   drummers, so the profile is its median over the tempos measured, not a curve: this corpus does not show the fall of
//   swing with tempo that Friberg and Sundström measured on ride cymbals ([R01]), and nothing here claims it.
// - funk, hip-hop, rock, latin, soul, New Orleans, afrobeat, pop: straight within a hundredth (.49-.51) at the eighth,
//   and near it at the sixteenth, so no swing is applied to them.
// - the kick ahead of the beat in funk (5 ms on 1 and 3, 9 on validation) and hip-hop (4 to 10 ms; 19 on validation's
//   few takes): the one offset whose sign held across both splits. The others were a few milliseconds either way and did
//   not hold, and are not applied.
export const MEASURED_TIMING=Object.freeze({
  source:'Groove MIDI Dataset v1.0.0, train split (Gillick et al. 2019, CC BY 4.0); scripts/measure-drum-timing.mjs',
  swing:Object.freeze({
    jazz:Object.freeze({subdivision:'eighth',knots:Object.freeze([Object.freeze({bpm:124.5,fraction:.65})]),range:Object.freeze([85,160]),
      provenance:'GMD train, jazz, 21 takes of 5 drummers, median of eighth-pair fractions (IQR .52-.70); validation .69 (2 takes)'}),
  }),
  offsetsMs:Object.freeze({
    funk:Object.freeze({kick:Object.freeze({1:-5,3:-5})}),
    hiphop:Object.freeze({kick:Object.freeze({1:-4,3:-8})}),
  }),
});

// Feels made from the measured ones, each a design choice and named as one (nothing measured it):
// - warped: jazz's swing drawn through every subdivision, the drummers playing their sixteenths where the warp puts them.
//   A straight sixteenth part plays long-long-short-short. It was the first jazz feel. The user, 27 September, heard it
//   as "a completely different drum part, different rhythm (interesting)", and in 7/8: "valid musical choices for
//   different situations. The second has a slightly 'hesitant' vibe." Its character is that word, for a bot choosing it.
export const DESIGNED_FEELS=Object.freeze({
  warped:Object.freeze({from:'jazz',revoice:false,character:'hesitant',
    provenance:'jazz\'s measured swing through every subdivision; named for the user\'s hearing of it, 27 September 2026'}),
});
// ---- The feels' space -------------------------------------------------------------------------------------------------
// The owner, 4 November 2026: ""Feels are currently selected by name only, with none of them having in-between states,"
// - needs parameterization". A feel is a point in a space (style-space.js): one value for each thing a feel does to the
// performance, the named feels its locations, and every point between two of them a feel too (CLAUDE.md: "Everything is
// interpolable"):
//   swing     how far its eighth pairs depart from even, as a share of jazz's measured departure at the tempo (0 even, 1
//             jazz's: .65 of the pair; a half, .575: lighter). Continuous: a feel between jazz and straight swings
//             between them.
//   revoice   the chance a bar's drummers play their patterns in the swing's own long-short division (a jazz drummer's
//             swung eighths and triplets, revoicedHits) rather than their straight sixteenths where the warp puts them
//             (warped's long-long-short-short). A choice made whole, a bar at a time, alike for every drummer (feelInBar):
//             halfway between jazz and warped, half the bars are jazz's and half warped's, never a bar half of each.
//   kick:1 ...  an instrument's offset on a beat of the bar (ms; ahead below 0), one dimension for each measured
//             (MEASURED_TIMING.offsetsMs): funk's and hip-hop's kick ahead on 1 and 3.
// A feel is written as it is played (notation/score.js, MusicXML's <swing>: the musebots compose symbolic music as
// MusicXML before it becomes MIDI 2.0 and sound): its swing at the tempo as a ratio of small whole numbers, under the
// words of the named feel it is nearest (feelDirection).
const SWING_REFERENCE=MEASURED_TIMING.swing.jazz;
// A profile's departure from even, against the reference's, at its first measured tempo.
const departure=profile=>swingAt(profile,profile.knots[0].bpm).fraction-.5;
const OFFSET_KEYS=Object.freeze([...new Set(Object.values(MEASURED_TIMING.offsetsMs).flatMap(offsets=>Object.entries(offsets).flatMap(([instrument,beats])=>Object.keys(beats).map(beat=>`${instrument}:${beat}`))))]);
const offsetsIn=offsets=>Object.fromEntries(OFFSET_KEYS.map(key=>{const [instrument,beat]=key.split(':');return [key,offsets?.[instrument]?.[beat]??0]}));
export const FEEL_SPACE=styleSpace({name:'the feels\'',dimensions:{
  swing:"how far its eighth pairs depart from even, as a share of jazz's measured departure at the tempo (0 even, 1 jazz's)",
  revoice:"the chance a bar's drummers play their patterns in the swing's own long-short division rather than their straight sixteenths where the warp puts them",
  ...Object.fromEntries(OFFSET_KEYS.map(key=>{const [instrument,beat]=key.split(':');return [key,`the ${instrument}'s offset on beat ${beat} of the bar (ms; ahead below 0)`]})),
},locations:{
  straight:{swing:0,revoice:0,...offsetsIn(null)},
  ...Object.fromEntries(Object.entries(MEASURED_TIMING.swing).map(([name,profile])=>[name,{swing:departure(profile)/departure(SWING_REFERENCE),revoice:profile.subdivision==='eighth'?1:0,...offsetsIn(MEASURED_TIMING.offsetsMs[name])}])),
  ...Object.fromEntries(Object.entries(MEASURED_TIMING.offsetsMs).filter(([name])=>!MEASURED_TIMING.swing[name]).map(([name,offsets])=>[name,{swing:0,revoice:0,...offsetsIn(offsets)}])),
  ...Object.fromEntries(Object.entries(DESIGNED_FEELS).map(([name,designed])=>{const from=MEASURED_TIMING.swing[designed.from];
    return [name,{swing:from?departure(from)/departure(SWING_REFERENCE):0,revoice:designed.revoice?1:0,...offsetsIn(MEASURED_TIMING.offsetsMs[designed.from])}]})),
}});
// The feels an ensemble can be given by name: a measured profile's name, a designed feel's, or 'straight' (every note on
// its score time). Any point of FEEL_SPACE is one too.
export const FEELS=Object.freeze(Object.keys(FEEL_SPACE.locations));
// The feel's location, or null where it is none: a name from FEELS, a blend of them by weight ({jazz: .5, straight: .5}),
// either with any dimension set apart ({jazz: 1, swing: .6}), or every dimension given -- its swing keeping the pair's
// first note inside the pair at every tempo measured.
export function feelLocation(given){
  if(given==null)return null;
  let point;try{point=FEEL_SPACE.locate(given)}catch{return null}
  return SWING_REFERENCE.knots.every(knot=>{const fraction=.5+point.swing*(knot.fraction-.5);return fraction>0&&fraction<1})?point:null;
}
// A feel's name: its own, or a blend's parts by weight ("jazz 0.6, straight 0.4"), its dimensions set apart after them.
export function feelName(given){
  if(typeof given==='string')return given;
  return Object.entries(given??{}).map(([key,value])=>`${key} ${typeof value==='number'?+value.toFixed(3):value}`).join(', ');
}
// The named feel a point stands nearest, each dimension measured against its spread over the named feels: the one whose
// words it is written under.
function nearestFeel(point,among=FEELS){
  const spread=FEEL_SPACE.names.map(key=>{const values=FEELS.map(name=>FEEL_SPACE.locations[name][key]);return Math.max(...values)-Math.min(...values)||1});
  const distance=name=>FEEL_SPACE.names.reduce((sum,key,k)=>sum+((point[key]-FEEL_SPACE.locations[name][key])/spread[k])**2,0);
  return among.reduce((best,name)=>distance(name)<distance(best)?name:best);
}
// The named feel a point is written under and has the character of: the one it was given as; else, among the named feels
// that swing as it does (or, where it does not swing, that move as it does), the one its blend weighs most (a light jazz,
// {jazz: .25, straight: .75}, is a swing, not straight and not warped), else the one it stands nearest.
function namedAs(given,location){
  if(typeof given==='string')return given;
  const swung=Boolean(swungBy(location.swing)),moves=!FEEL_SPACE.names.every(key=>location[key]===0);
  const among=FEELS.filter(name=>Boolean(swungBy(FEEL_SPACE.locations[name].swing))===swung&&(swung||(name!=='straight')===moves));
  const weighed=among.filter(name=>Number(given?.[name])>0);
  return weighed.length?weighed.reduce((best,name)=>given[name]>given[best]?name:best):nearestFeel(location,among);
}
// Its swing profile: the reference's, its departure from even at each tempo scaled by `share`; none where it is even.
const swungBy=share=>!share?null:share===1?SWING_REFERENCE:Object.freeze({subdivision:SWING_REFERENCE.subdivision,
  knots:Object.freeze(SWING_REFERENCE.knots.map(knot=>Object.freeze({bpm:knot.bpm,fraction:.5+share*(knot.fraction-.5)}))),range:SWING_REFERENCE.range,
  provenance:`${+share.toFixed(3)} of jazz's measured departure from even (${SWING_REFERENCE.provenance})`});
// A feel: {name, location, swing, offsets, revoicing (its chance a bar), revoice (whether it re-voices: every bar where
// its chance is whole; a bar's own, feelInBar, where it is not), character}; null for
// 'straight' and every point that moves nothing, and for what is no feel. A feel that swings eighths asks its drummers to
// re-voice: a jazz drummer plays swung eighths and triplets, not straight sixteenths stretched through a swing
// (revoicedHits below).
const FEEL_CHARACTER=Object.freeze(Object.fromEntries(FEELS.map(name=>[name,DESIGNED_FEELS[name]?.character??(name==='straight'?'straight':MEASURED_TIMING.swing[name]?'swing':'measured placement')])));
export function feelOf(given){
  const location=feelLocation(given??'straight');
  if(!location||FEEL_SPACE.names.every(key=>location[key]===0))return null;
  // Its offsets: a measured profile's own where it stands at one (as its swing is jazz's own at jazz's share), else the
  // point's.
  const offsets={};
  for(const key of OFFSET_KEYS)if(location[key]){const [instrument,beat]=key.split(':');(offsets[instrument]??={})[beat]=location[key]}
  const measured=Object.keys(offsets).length?Object.values(MEASURED_TIMING.offsetsMs).find(profile=>{const at=offsetsIn(profile);return OFFSET_KEYS.every(key=>at[key]===location[key])}):null;
  const swing=swungBy(location.swing);
  return Object.freeze({name:feelName(given),location,swing,offsets:measured??(Object.keys(offsets).length?Object.freeze(Object.fromEntries(Object.entries(offsets).map(([k,v])=>[k,Object.freeze(v)]))):null),
    ...(()=>{const revoicing=swing?.subdivision==='eighth'?location.revoice:0;return {revoicing,revoice:revoicing>=1}})(),character:FEEL_CHARACTER[namedAs(given,location)]});
}
// A feel in bar `bar` of an ensemble seeded `seed`: its re-voicing made whole for the bar (the named feel the bar's draw
// falls in, as often as the feel stands nearer it, and that feel's chance), the same for every part that asks.
export function feelInBar(feel,{bar=0,seed=0}={}){
  if(!feel)return null;
  const {location,draw}=FEEL_SPACE.drawn(feel.location,randomAt(`${seed}:feel:revoice`,Math.max(0,Math.floor(Number(bar)||0))));
  return Object.freeze({...feel,revoice:feel.revoicing>0&&draw<location.revoice});
}
// A feel as a player reads it on the page (notation/score.js; the rhythm-decomposition handoff's finding 5: carry the
// feel into notation): its words, and, for a swing, its long-to-short ratio at the tempo (quarter notes a minute) in
// small whole numbers, as MusicXML's <swing> says it; `{straight: true}` for straight. Null for what is no feel. A feel
// between the named ones is written under the words of the one it is named as (namedAs), its own swing in the ratio.
const FEEL_WORDS=Object.freeze({straight:'Straight',jazz:'Swing',warped:'Warped swing',funk:'Funk feel',hiphop:'Hip-hop feel'});
export function feelDirection(given,bpm=null){
  const location=feelLocation(given??null);
  if(!location)return null;
  const feel=feelOf(given),swung=Boolean(feel?.swing),moves=Boolean(feel);
  const named=namedAs(given,location),words=FEEL_WORDS[named]??`${named} feel`,name=feelName(given);
  if(!swung)return Object.freeze({name,words,swing:moves?null:{straight:true}});
  const {fraction}=swingAt(feel.swing,Number.isFinite(bpm)?bpm:feel.swing.knots[0].bpm),[first,second]=smallRatio(fraction/(1-fraction));
  return Object.freeze({name,words,swing:{first,second,type:feel.swing.subdivision}});
}
// The nearest ratio of whole numbers, neither above `most` (continued fractions): 1.857 is 13:7.
function smallRatio(value,most=16){
  let [h0,h1,k0,k1]=[0,1,1,0],x=value;
  for(let step=0;step<32;step++){
    const a=Math.floor(x),h=a*h1+h0,k=a*k1+k0;
    if(h>most||k>most)break;
    [h0,h1,k0,k1]=[h1,h,k1,k];
    if(Math.abs(x-a)<1e-9)break;
    x=1/(x-a);
  }
  return [h1,k1];
}

// ---- Stage D: learned enrichment --------------------------------------------------------------------------------------
// How a drummer's strokes move about their own placement, learned from the Groove MIDI Dataset (scripts/measure-drum-
// groove.mjs; research/rhythmic_humanization_state_of_the_art.md §12.2). Stage B's profile holds the placement that
// carries from drummer to drummer; finer placement did not carry (docs/PERFORMANCE_TIMING.md §4.1). This holds how the strokes
// move about it, which did carry: the validation split's drummers show the same figures.
//   shared  the kit moving together, beat by beat: an AR(1) (its lag-one correlation and spread), the drift against the
//           click taken off, since a band on one clock does not share a drummer's drift
//   ownSd   each instrument's own spread about that shared motion
// The accent's coupling to timing measured negligible (-0.08 ms per ten velocity steps), so it is left out.
export const LEARNED_GROOVE=Object.freeze({
  source:'Groove MIDI Dataset v1.0.0 (Gillick et al. 2019, CC BY 4.0): train split, 261 4/4 takes of 10 drummers; scripts/measure-drum-groove.mjs',
  shared:Object.freeze({sd:9.9,lagOne:.39}),
  ownSd:Object.freeze({kick:9.8,snare:11.7,hatClosed:7.4,ride:7.8}),
  heldOut:Object.freeze({split:'validation, 39 takes of 7 drummers',shared:Object.freeze({sd:9.5,lagOne:.39}),ownSd:Object.freeze({kick:9.7,snare:11.5,hatClosed:7.7,ride:7.3})}),
});
// A standard normal draw, the `index`th of the stream `key` names, reached directly (random-source.js randomAt).
const gaussAt=(key,index)=>Math.sqrt(-2*Math.log(Math.max(randomAt(key,2*index),1e-12)))*Math.cos(2*Math.PI*randomAt(key,2*index+1));
const AR_TERMS=16;
// The kit's shared motion at beat `beat`, in ms: the AR(1)'s value there as the sum of its innovations, so any part that
// asks with the same key hears the same motion, in any order. Its lag-one and spread are the model's (the sum's first
// AR_TERMS terms: the rest is below a millionth of it at 0.39).
export function grooveShared(key,beat,{sd=LEARNED_GROOVE.shared.sd,lagOne=LEARNED_GROOVE.shared.lagOne}={}){
  let value=0;for(let j=0;j<AR_TERMS;j++)value+=lagOne**j*gaussAt(`${key}:shared`,beat-j);
  return sd*Math.sqrt(1-lagOne**2)*value;
}
// An instrument's own motion about the shared one, for its stroke at `index` (its place, in twelfths of a tick), in ms.
export function grooveOwn(key,instrument,index){const sd=LEARNED_GROOVE.ownSd[instrument];return sd?sd*gaussAt(`${key}:${instrument}`,index):0}

// ---- The feel a section takes -------------------------------------------------------------------------------------------

// Which feel each role of the form asks for, as a starting hypothesis (like thematic-form.js roleActions), not a finding.
// The user heard straight, jazz and warped as "valid musical choices for different situations" (27 September), warped
// as "slightly 'hesitant'", and 7/8's straight 2+2+3 as the most "rhythmically dissonant". So: the home's own feel in the
// home, at the peak and at the close; a swing where the form develops; the opposite of the home in a contrast; the
// hesitant one where it relaxes or departs. A role the table does not know keeps the home's.
export const FEEL_FOR_ROLE=Object.freeze({
  establish:'home','complex-frame':'home',return:'home','complex-return':'home',climax:'home',closure:'home',stabilize:'home',
  develop:'swing',contrast:'opposite',depart:'hesitant',relax:'hesitant',
});
// Where a role also asks an instrument to sit off the beat, over whatever feel is in force: a placement in the expression
// profile's shape (instrument: ms behind, on every beat). The laid-back snare in a swung groove (the rubato report's §7.3,
// stage B's D) is the relaxed section's, 15 ms behind, over its hesitant swing: the user, 28 September 2026, on D: "This
// is OK for laid-back snare, yes." A hypothesis like the table above, and a choice ManageBOT makes by section.
export const PLACEMENT_FOR_ROLE=Object.freeze({relax:Object.freeze({snare:15})});
// A section's feel: its role's ask (its own, else its head word, as the thematic form reads roles), resolved against the
// home's feel (the ensemble's: a render's transport.feel, else straight). -> a name from FEELS, or the home's location.
export function feelForSection({role='',home='straight'}={}){
  const base=feelLocation(home)?home:'straight',plain=!feelOf(base);
  const ask=[String(role||''),String(role||'').split('-').at(-1)].map(key=>FEEL_FOR_ROLE[key]).find(Boolean)??'home';
  if(ask==='swing')return plain?'jazz':base;
  if(ask==='opposite')return plain?'jazz':'straight';
  if(ask==='hesitant')return 'warped';
  return base;
}
// A section's feel with the placement its role asks for: {name, placement} (placement null where the role asks none).
export function sectionFeel({role='',home='straight'}={}){
  const placement=[String(role||''),String(role||'').split('-').at(-1)].map(key=>PLACEMENT_FOR_ROLE[key]).find(Boolean)??null;
  return Object.freeze({name:feelForSection({role,home}),placement});
}

// A step-sequenced part's hits at `step` as a feel asks them played. Where the feel re-voices an eighth-note swing, a
// hit on a pair's last sixteenth (its "a", three quarters of the way through the pair) is played with the pair's second
// note (its "and"), which the swing places late; the "e" keeps its place, which the warp puts near the middle triplet.
// So the part keeps its hits and its accents, in the swing's own long-short division, as a jazz drummer would play
// the figure. Elsewhere, and in any group the meter does not pair, the hits are as written.
// hitsAt(step) -> the step's hits; phaseOf(step) -> its phase in its quarter (placeInMeter), or null; steps: the cycle;
// next(step) -> the step a sixteenth later, or null where the steps are not sixteenths (by default the next step).
// This is a rewrite of the pattern, not a warp of its times (RHY-001's answer: rhythm-decomposition/IMPLEMENTER_HANDOFF.md,
// finding 3): it can merge two written hits of one kind into one stroke, which no warp does. So it says what it did:
// onRewrite({from, to, moved, merged}) for each "a" played with its "and", its hits and those of them already there.
// A merged hit is the rewrite's, never a rest chosen.
export function revoicedHits(feel,step,{hitsAt,phaseOf,steps,next=value=>(value+1)%steps,onRewrite=null}){
  if(!feel?.revoice||feel.swing?.subdivision!=='eighth')return hitsAt(step);
  const phase=phaseOf(step),at=(value,target)=>value!==null&&value!==undefined&&Math.abs(value-target)<1e-6;
  if(at(phase,.75))return [];
  if(at(phase,.5)){
    const after=next(step);
    if(after===null||!at(phaseOf(after),.75))return hitsAt(step);
    const own=hitsAt(step),moved=hitsAt(after);
    if(moved.length)onRewrite?.({from:after,to:step,moved:[...moved],merged:moved.filter(hit=>own.includes(hit))});
    return [...new Set([...own,...moved])];
  }
  return hitsAt(step);
}

// ---- A moment's place in a meter --------------------------------------------------------------------------------------

const TICK_EPSILON=1e-6;
// Where a moment of a bar sits for the profiles, from the meter's hierarchy (no meter is named). `meter` is a normalized
// meter (meter.js: numerator, denominator, groups, subdivision ticks to its notated beat, pulsesPerBar); `ticks` the
// moment's place in its bar, in ticks, fractions allowed (a note between ticks), wrapped into the bar.
// - Its phase in its quarter note, where the meter pairs eighths there (a sixteenth profile: pairs sixteenths in each
//   eighth). A beat that divides in three holds no pairs (a compound meter, notated or counted: meter-tactus.js), and a
//   group of the meter pairs only where it is a whole number of pairs long: a group of three eighths is not an eighth
//   pair and a half, and its unequal subdivision is its structure (§6). Elsewhere the phase is null: nothing to swing.
// - Whether it starts a group at the level above the beat a listener taps: the meter's groups, or, where those groups
//   are the tapped beats (a compound meter notated in its threes), those beats grouped as a bar of so many (4/4's two
//   and two, whose beats 1 and 3 are where the corpus measured the kick's offsets). The bar's first such start is read
//   as beat 1 of the measure, the others as its beat 3 (beatInBar); in any meter but 4/4 heard as 2 + 2 that is a
//   reading of the measure by metrical position, and is flagged (extrapolated).
// -> {phase|null, quarterTicks, beatInBar: 1|3|null, beat (the notated beat, from 1), extrapolated}
export function placeInMeter(meter,ticks,{subdivision='eighth'}={}){
  finite(ticks,'ticks');
  const ticksPerBeat=Math.max(1,Number(meter?.subdivision)||4),denominator=Number(meter?.denominator)||4;
  const groups=Array.isArray(meter?.groups)&&meter.groups.length?meter.groups.map(Number):[Number(meter?.numerator)||4];
  const bar=Number(meter?.pulsesPerBar)||groups.reduce((a,b)=>a+b,0)*ticksPerBeat;
  let at=((ticks%bar)+bar)%bar;if(bar-at<TICK_EPSILON)at=0;
  let start=0;const spans=groups.map(size=>{const span={start,length:size*ticksPerBeat};start+=span.length;return span});
  const span=spans.findLast(candidate=>at>=candidate.start-TICK_EPSILON)??spans[0];
  const tactus=tactusOf(meter),quarterTicks=ticksPerBeat*denominator/4,pairTicks=subdivision==='sixteenth'?quarterTicks/2:quarterTicks;
  const pairs=pairTicks>0&&Math.abs(span.length/pairTicks-Math.round(span.length/pairTicks))<TICK_EPSILON;
  let phase=null;
  if(!tactus.compound&&pairs){
    const into=(at-span.start)/quarterTicks;phase=into-Math.floor(into+TICK_EPSILON);
    if(phase<TICK_EPSILON/quarterTicks)phase=0;
  }
  let strong=0;
  const strongStarts=tactus.form==='notated'
    ?defaultGrouping(tactus.beatsPerBar).map(size=>{const x=strong;strong+=size*tactus.ticks;return x})
    :spans.map(candidate=>candidate.start);
  const index=strongStarts.findIndex(x=>Math.abs(at-x)<TICK_EPSILON);
  const measured=Number(meter?.numerator)===4&&denominator===4&&groups.join('+')==='2+2'&&!tactus.compound;
  return Object.freeze({phase,quarterTicks,beatInBar:index<0?null:index===0?1:3,beat:Math.floor(at/ticksPerBeat+TICK_EPSILON)+1,extrapolated:!measured});
}

// ---- A note's performed offset ----------------------------------------------------------------------------------------

// Where a note at `phase` of its beat (0 to 1) is played, in seconds from its score time, under a profile: its pair's
// warp (the second note of a pair moved to the profile's fraction, the pair's ends fixed) plus its role's offset for its
// beat of the bar (a downbeat's), each reported. `grace` and `committed` notes, and electronic parts, are not moved.
// `beatName` names the beat in the reason where it is not the measure's own (placeInMeter's reading of another meter).
// -> {seconds, swing, offset, reason}
export function performedOffset({phase,bpm,beatInBar=1,swing=null,offsets=null,instrument=null,grace=false,committed=false,electronic=false,beatName=null}={}){
  finite(phase,'phase');finite(bpm,'bpm');
  if(phase<0||phase>=1)throw new RangeError('a phase lies in [0, 1)');
  if(grace||committed||electronic)return {seconds:0,swing:0,offset:0,reason:grace?'a grace keeps its technique\'s seconds':committed?'committed: never moved':'electronic: no human timing'};
  const beat=60/finite(bpm,'bpm');let warped=phase,swingSeconds=0,beyond=false;
  if(swing){
    const {fraction,extrapolated}=swingAt(swing,bpm);beyond=extrapolated;
    if(swing.subdivision==='eighth')warped=warpPhase(phase,[0,.5,1],[0,fraction,1]);
    else if(swing.subdivision==='sixteenth'){const half=phase<.5?0:.5,within=(phase-half)*2;warped=half+warpPhase(within,[0,.5,1],[0,fraction,1])/2}
    swingSeconds=(warped-phase)*beat;
  }
  const onBeat=phase<1e-9,offsetSeconds=onBeat&&instrument&&offsets?.[instrument]?.[beatInBar]!=null?offsets[instrument][beatInBar]/1000:0;
  const reason=[swingSeconds?`swung to ${(warped).toFixed(3)} of the beat${beyond?` (at ${Math.round(bpm)} BPM, beyond the tempos measured)`:''}`:null,
    offsetSeconds?`${instrument} ${offsetSeconds<0?'ahead':'behind'} ${Math.abs(offsetSeconds*1000).toFixed(1)} ms on ${beatName??`beat ${beatInBar}`}`:null].filter(Boolean).join('; ')||'on its score time';
  return {seconds:swingSeconds+offsetSeconds,swing:swingSeconds,offset:offsetSeconds,reason};
}

// ---- The rubato report's baseline profiles (its stage B; docs/PERFORMANCE_TIMING.md §9) ----------------------------------
// Each by itself, on or off from one spec (a render's transport.expression), beside the feel and apart from it:
//   lean       a voice's displacement against a band that does not move (the voice layer, the report's §9.2:
//              T_v(q) = T(q) + delta_v(q)), `ms` behind (+) or ahead (-). 'arch' reaches it at the phrase's middle and
//              rejoins the band at the phrase's ends, whose downbeats are its rendezvous anchors (§3.2: "a melody
//              reaches 40 ms behind, then rejoins"). 'onBeats' moves the voice's beat onsets and leaves its offbeats
//              with the band (§7.4, §15.2: "a selected solo on-beat event occurs 25 ms after the supporting beat,
//              while its offbeat coincides").
//   breath     a broadened phrase ending, the whole band together, its total kept (§15.1: a phrase's beats at 495, 495,
//              500 and 510 ms): a ritard over the phrase's last part (`over`, a half unless given) on Friberg and
//              Sundberg's final-ritard curve, from a tempo a little ahead that repays it, so the phrase ends where it
//              would have and comes back a tempo on the next downbeat. Its size is the tempo it slows to (`slowest`,
//              against the tempo it slows from) or the time it takes (`broaden`, in beats). Every interval grows a
//              little from the last, which drums play as a ritardando; a phrase's last beat stretched alone was heard
//              as a stumble (c2, 28 September, rubato E: 8-15% slow for one beat, then back at once). Shared, so it
//              moves every bot's sound, not only the performance layer's (a render's bot host: bot-host.js breathe).
//   placement  an instrument's own place against the beat in ms (+ behind), on every beat or by beat in the bar, where
//              it stands in for the feel's measured offset for that instrument (§7.3: a laid-back snare, its placement
//              kept apart from tempo drift). Like the feel's offsets it moves beat onsets, by the same amount every
//              time: it never accumulates into tempo.
// The limits are ours: the report's own fixtures reach 40 ms of leaning and a 150-ms delayed entry, and a placement past
// 60 ms is another beat, not a placement (beat-sync.js POCKET_SECONDS is 0.1 s). A breath slows to half its tempo at
// most, and takes at most two beats; past that an ending is the clocks' (a rubato span, clock-rubato.js).
export const LEAN_SHAPES=Object.freeze(['arch','onBeats']);
export const EXPRESSION_LIMITS=Object.freeze({leanMs:150,placementMs:60,broaden:2,slowest:.5,cadenzaSeconds:60,grooveAmount:1.5});
export function expressionProfile(value){
  if(value==null)return null;
  if(typeof value!=='object'||Array.isArray(value))throw new TypeError('an expression is {lean?, placement?, breath?, cadenza?, groove?}');
  const unknown=Object.keys(value).filter(key=>!['lean','placement','breath','cadenza','groove'].includes(key));
  if(unknown.length)throw new RangeError(`no expression profile ${unknown.join(', ')}: lean, placement, breath, cadenza, groove`);
  const out={};
  if(value.lean!=null){
    const {instrument,ms,shape='arch'}=value.lean;
    if(typeof instrument!=='string'||!instrument)throw new RangeError('a lean names the voice it moves (its instrument: melody, comping, bass, or a drum)');
    finite(ms,'a lean\'s ms');
    if(Math.abs(ms)>EXPRESSION_LIMITS.leanMs)throw new RangeError(`a lean is within ${EXPRESSION_LIMITS.leanMs} ms`);
    if(!LEAN_SHAPES.includes(shape))throw new RangeError(`a lean's shape is ${LEAN_SHAPES.join(' or ')}`);
    out.lean=Object.freeze({instrument,ms,shape});
  }
  // A free cadenza before a tutti (bots/lib/modules/cadenza.js): the voice that takes it, the bar whose last beat it holds
  // (from 1), the hold's bound and the re-entry's lead, in seconds.
  if(value.cadenza!=null){
    const {instrument,bar=null,bound=null,leadSeconds=null}=value.cadenza;
    if(typeof instrument!=='string'||!instrument)throw new RangeError('a cadenza names the voice that takes it (its instrument: melody)');
    if(bar!=null&&!(Number.isSafeInteger(bar)&&bar>=2))throw new RangeError('a cadenza\'s bar counts from 1, and is past the first');
    if(bound!=null&&!(Number.isFinite(bound)&&bound>0&&bound<=EXPRESSION_LIMITS.cadenzaSeconds))throw new RangeError(`a cadenza's bound is at most ${EXPRESSION_LIMITS.cadenzaSeconds} s`);
    if(leadSeconds!=null&&!(Number.isFinite(leadSeconds)&&leadSeconds>=0&&leadSeconds<=(bound??EXPRESSION_LIMITS.cadenzaSeconds)))throw new RangeError('a cadenza\'s lead is within its bound');
    out.cadenza=Object.freeze({instrument,...(bar!=null?{bar}:{}),...(bound!=null?{bound}:{}),...(leadSeconds!=null?{leadSeconds}:{})});
  }
  if(value.breath!=null){
    const breath=value.breath;
    if(typeof breath!=='object'||Array.isArray(breath))throw new TypeError('a breath is {broaden or slowest, over?}');
    const unknown=Object.keys(breath).filter(key=>!['broaden','slowest','over'].includes(key));
    if(unknown.length)throw new RangeError(`a breath has no ${unknown.join(', ')}: broaden or slowest, and over`);
    const {broaden,slowest,over}=breath;
    if((broaden==null)===(slowest==null))throw new RangeError('a breath says how much it broadens, or how slow it ends: broaden or slowest, one of them');
    if(broaden!=null){
      finite(broaden,'a breath\'s broadening');
      if(!(broaden>0&&broaden<=EXPRESSION_LIMITS.broaden))throw new RangeError(`a breath broadens a phrase by more than 0 and at most ${EXPRESSION_LIMITS.broaden} beats`);
    }
    if(slowest!=null){
      finite(slowest,'a breath\'s slowest tempo');
      if(!(slowest>=EXPRESSION_LIMITS.slowest&&slowest<1))throw new RangeError(`a breath slows to at least ${EXPRESSION_LIMITS.slowest} of its tempo, and below it`);
    }
    if(over!=null&&!(Number.isFinite(over)&&over>0&&over<1))throw new RangeError('a breath\'s ritard is over part of its phrase: more than 0 and less than 1');
    out.breath=Object.freeze({...(broaden!=null?{broaden}:{slowest}),...(over!=null?{over}:{})});
  }
  // The kit's learned motion about its placement (stage D, LEARNED_GROOVE): its amount, 1 the drummers' own.
  if(value.groove!=null){
    const {model='gmd',amount=1}=value.groove;
    if(model!=='gmd')throw new RangeError('a groove\'s model is gmd (the Groove MIDI Dataset\'s drummers)');
    finite(amount,'a groove\'s amount');
    if(!(amount>0&&amount<=EXPRESSION_LIMITS.grooveAmount))throw new RangeError(`a groove's amount is above 0 and at most ${EXPRESSION_LIMITS.grooveAmount}`);
    out.groove=Object.freeze({model,amount});
  }
  if(value.placement!=null){
    if(typeof value.placement!=='object'||Array.isArray(value.placement))throw new TypeError('a placement is {instrument: ms, or {beat: ms}}');
    const placement={};
    for(const [instrument,given] of Object.entries(value.placement)){
      const byBeat=typeof given==='number'?{'*':given}:given;
      if(!byBeat||typeof byBeat!=='object'||Array.isArray(byBeat))throw new TypeError(`${instrument}'s placement is ms, or ms by beat`);
      for(const [beat,ms] of Object.entries(byBeat)){
        if(beat!=='*'&&!(Number.isInteger(Number(beat))&&Number(beat)>=1))throw new RangeError(`${instrument}'s placement: beats count from 1`);
        finite(ms,`${instrument}'s placement`);
        if(Math.abs(ms)>EXPRESSION_LIMITS.placementMs)throw new RangeError(`a placement is within ${EXPRESSION_LIMITS.placementMs} ms`);
      }
      placement[instrument]=Object.freeze({...byBeat});
    }
    out.placement=Object.freeze(placement);
  }
  return Object.freeze(out);
}
// The seconds a lean moves a note at `phrasePosition` (0 to 1 through its phrase, 1 the next phrase's downbeat) and
// `phase` within its beat.
export function leanSeconds({shape,ms},{phrasePosition,phase}){
  finite(phrasePosition,'a phrase position');finite(phase,'a phase');
  if(shape==='onBeats')return phase<1e-9?ms/1000:0;
  return ms/1000*Math.sin(Math.PI*Math.max(0,Math.min(1,phrasePosition)));
}
// An instrument's placement in ms on a beat of the bar, or null where it has none.
export function placementMs(placement,instrument,beatInBar){
  const byBeat=placement?.[instrument];
  if(!byBeat)return null;
  return byBeat[beatInBar]??byBeat['*']??null;
}
// The breath's ritard: Friberg and Sundberg's final ritard (1999; as broadening.js), the tempo
// v(u) = (1 + (w^q - 1) u)^(1/q) over the ritard's score position u from 0 to 1, slowing to w, with q = 2.
export const BREATH=Object.freeze({q:2,over:.5});
// Its time from u = 0 to u, in units of its length at the tempo it slows from: the integral of 1 / v.
const ritardTime=(u,w,q=BREATH.q)=>{const k=w**q-1;return Math.abs(k)<1e-12?u:((1+k*u)**(1-1/q)-1)/(k*(1-1/q))};
// A breath's shape in a phrase of `beatsPerPhrase` beats: where its ritard starts (x0, a share of the phrase), the tempo
// it slows to (w, against the tempo it slows from) and the phrase's density before it (c, below 1: the time it repays).
// Asked by `broaden`, the time it takes in beats, w is what takes that time, and no slower than half.
export function breathShape({broaden,slowest,over=BREATH.over},{beatsPerPhrase}={}){
  const x0=1-over;let w=slowest;
  if(w==null){
    const n=Number(beatsPerPhrase),c=1-broaden/(n*x0),total=(1/c-x0)/over;
    // The ritard's time grows as w falls: the w whose time is `total`, by bisection.
    let low=EXPRESSION_LIMITS.slowest,high=1;
    if(!(c>0)||ritardTime(1,low)<=total)w=low;
    else for(let i=0;i<60;i++){const mid=(low+high)/2;if(ritardTime(1,mid)>total)low=mid;else high=mid;w=(low+high)/2}
  }
  w=Math.max(EXPRESSION_LIMITS.slowest,Math.min(w,1));
  return Object.freeze({x0,w,c:1/(x0+over*ritardTime(1,w))});
}
// The seconds a breath moves the band's sound from its grid at `phrasePosition` (0 to 1 through the phrase), in a
// phrase of `beatsPerPhrase` beats of `beatSeconds`: nothing at the phrase's ends. Before the ritard the phrase runs at
// c of its grid's density; through it, c / v.
export function breathSeconds(breath,{phrasePosition,beatsPerPhrase,beatSeconds}){
  finite(phrasePosition,'a phrase position');finite(beatSeconds,'a beat\'s seconds');
  const n=Math.round(beatsPerPhrase);
  if(!(n>=2)||!(beatSeconds>0))return 0;
  const {x0,w,c}=breathShape(breath,{beatsPerPhrase:n}),x=Math.max(0,Math.min(1,phrasePosition));
  if(x>=1)return 0;
  const tau=x<=x0?c*x:c*x0+c*(1-x0)*ritardTime((x-x0)/(1-x0),w);
  return n*beatSeconds*(tau-x);
}
