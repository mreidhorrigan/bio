import {parseGranularCorpus,indexGranularCorpus,pitchClassOf} from './granular-corpus.js';

// A corpus profile is what a bot knows about its own material before it plays a note.
// The offline analyser measures each grain; this measures the *corpus*: where its
// thresholds actually fall, which grains behave as attacks, tones, textures or air, and
// which ones are worth spending on a transition. Every threshold is a percentile of this
// corpus rather than a constant, so a corpus of breaking glass and a corpus of breath
// each get sensible cut points instead of one arbitrary pair.
//
// It is computed offline (scripts/build-granubot-corpus.mjs writes it beside the
// manifest) precisely so the runtime never analyses anything: playing a grain is a
// lookup in a ranked list, never a scan or a measurement.
export const GRANULAR_PROFILE_SCHEMA=1;
export const GRAIN_ROLES=Object.freeze(['accent','tone','texture','air']);

const finite=(value,fallback=0)=>{const number=Number(value);return Number.isFinite(number)?number:fallback};
// Nearest-rank percentile over a pre-sorted array: no interpolation, so the value is
// always one an actual grain has, and two builds agree exactly.
export function percentile(sorted,fraction){
  if(!sorted.length)return 0;
  const position=Math.min(sorted.length-1,Math.max(0,Math.round(fraction*(sorted.length-1))));
  return sorted[position];
}
const sortedValues=(grains,read)=>grains.map(read).map(value=>finite(value)).sort((a,b)=>a-b);

// Loudness in dB is not a mixing gain. Normalising toward the corpus median keeps a
// -6 dB glass hit from burying a -40 dB room tone when both are asked for at once.
const gainFor=(rmsDb,medianDb)=>Math.min(4,Math.max(.25,10**((medianDb-finite(rmsDb,medianDb))/40)));

export function computeGranularProfile(source,{
  // Percentile cut points. Named so the reasoning survives: an "accent" is short and
  // punchy *for this corpus*, not shorter than some absolute number of milliseconds.
  shortDuration=.4,longDuration=.55,highCrest=.55,highNoise=.6,lowNoise=.5,
  quietRms=.25,confident=.45,
}={}){
  const index=source?.corpus?indexGranularCorpus(source.corpus):indexGranularCorpus(source),
    grains=index.foreground.length?index.foreground:index.grains;
  if(!grains.length)throw new TypeError('A corpus profile needs at least one foreground grain');

  const durations=sortedValues(grains,grain=>grain.durationSeconds),
    crests=sortedValues(grains,grain=>grain.crestDb),
    noises=sortedValues(grains,grain=>grain.noiseScore),
    levels=sortedValues(grains,grain=>grain.rmsDb),
    centroids=sortedValues(grains.filter(grain=>grain.centroidHz!=null),grain=>grain.centroidHz),
    confidences=sortedValues(grains,grain=>grain.confidence);
  const thresholds=Object.freeze({
    shortSeconds:percentile(durations,shortDuration),
    longSeconds:percentile(durations,longDuration),
    crestDb:percentile(crests,highCrest),
    noisy:percentile(noises,highNoise),
    clean:percentile(noises,lowNoise),
    quietDb:percentile(levels,quietRms),
    medianDb:percentile(levels,.5),
    brightHz:percentile(centroids,.6)||0,
    confident:percentile(confidences,confident),
  });

  const role=grain=>{
    const short=grain.durationSeconds<=thresholds.shortSeconds,
      long=grain.durationSeconds>=thresholds.longSeconds,
      noisy=grain.noiseScore>=thresholds.noisy,
      quiet=grain.rmsDb<=thresholds.quietDb;
    // Order matters: the first description that fits wins, so the pools partition the
    // corpus and a runtime pool is never a filtered scan.
    if(short&&(grain.crestDb>=thresholds.crestDb||noisy))return 'accent';
    if(grain.pitchSemitones!=null&&grain.confidence>=thresholds.confident&&grain.noiseScore<=thresholds.clean)return 'tone';
    if(noisy&&long)return 'texture';
    if(quiet||long)return 'air';
    return grain.pitchSemitones!=null?'tone':'texture';
  };

  // How much a grain is worth at the peak of a transition: loud, salient, bright and
  // short — the qualities that read as an event rather than as a continuation.
  const brightness=grain=>thresholds.brightHz?Math.min(1,finite(grain.centroidHz,0)/thresholds.brightHz):.5;
  const transitionScore=grain=>{
    const punch=Math.min(1,Math.max(0,(grain.crestDb-percentile(crests,.1))/Math.max(1,thresholds.crestDb-percentile(crests,.1)+1e-9))),
      brevity=1-Math.min(1,grain.durationSeconds/Math.max(1e-9,percentile(durations,.9)));
    return Number((grain.salience*.4+punch*.25+brightness(grain)*.2+brevity*.15).toFixed(6));
  };

  // Thresholds and playable roles use the existing selection domain. Metadata
  // must cover every corpus grain, including background continuations.
  const entries=index.grains.map(grain=>({
    id:grain.id,role:role(grain),
    transition:transitionScore(grain),
    gain:Number(gainFor(grain.rmsDb,thresholds.medianDb).toFixed(4)),
    pitchClass:pitchClassOf(grain.pitchSemitones),
  }));
  const byId=new Map(entries.map(entry=>[entry.id,entry]));
  const rank=(pool,read)=>pool.slice()
    .sort((a,b)=>read(b)-read(a)||(a.id<b.id?-1:1))
    .map(grain=>grain.id);
  const roles=Object.fromEntries(GRAIN_ROLES.map(name=>{
    const pool=grains.filter(grain=>byId.get(grain.id).role===name);
    return [name,rank(pool,grain=>grain.salience)];
  }));
  // Pitch-class buckets turn "find me a G a quarter-tone flat" into a short walk down a
  // ranked list instead of a pass over the whole corpus.
  const pitchClasses=Array.from({length:12},()=>[]);
  for(const grain of grains){
    const pitchClass=byId.get(grain.id).pitchClass;
    if(pitchClass!=null)pitchClasses[Math.round(pitchClass)%12].push(grain);
  }
  return Object.freeze({
    schemaVersion:GRANULAR_PROFILE_SCHEMA,
    corpus:index.corpus.name,grainCount:grains.length,thresholds,
    counts:Object.freeze(Object.fromEntries(GRAIN_ROLES.map(name=>[name,roles[name].length]))),
    roles:Object.freeze(Object.fromEntries(GRAIN_ROLES.map(name=>[name,Object.freeze(roles[name])]))),
    transitions:Object.freeze(rank(grains,grain=>byId.get(grain.id).transition)),
    pitchClasses:Object.freeze(pitchClasses.map(pool=>Object.freeze(rank(pool,grain=>grain.salience)))),
    grains:Object.freeze(entries.slice().sort((a,b)=>a.id<b.id?-1:1).map(entry=>Object.freeze(entry))),
  });
}

export function parseGranularProfile(value,index){
  if(!value||typeof value!=='object')throw new TypeError('A granular profile must be an object');
  if(value.schemaVersion!==GRANULAR_PROFILE_SCHEMA)throw new TypeError(`Unsupported granular profile schema ${value.schemaVersion}`);
  const resolve=ids=>Object.freeze((ids||[]).map(id=>{
    const grain=index.byId.get(id);
    if(!grain)throw new TypeError(`Profile references unknown grain ${id}`);
    return grain;
  }));
  const details=new Map((value.grains||[]).map(entry=>[entry.id,Object.freeze({
    role:String(entry.role),transition:finite(entry.transition),gain:finite(entry.gain,1),
  })]));
  for(const grain of index.grains)
    if(!details.has(grain.id))throw new TypeError(`Profile is missing grain ${grain.id}`);
  return Object.freeze({
    schemaVersion:GRANULAR_PROFILE_SCHEMA,thresholds:Object.freeze({...value.thresholds}),
    counts:Object.freeze({...value.counts}),
    roles:Object.freeze(Object.fromEntries(GRAIN_ROLES.map(name=>[name,resolve(value.roles?.[name])]))),
    transitions:resolve(value.transitions),
    pitchClasses:Object.freeze((value.pitchClasses||[]).map(resolve)),
    detail:grain=>details.get(typeof grain==='string'?grain:grain?.id)||null,
  });
}

// Runtime pools, assembled once when the corpus loads. A gesture asks for a role and
// gets a ready list; the only per-grain work left at performance time is the selector's
// tournament over a handful of draws.
export function grainPools(profile,{decoded=null}={}){
  const playable=list=>decoded?list.filter(grain=>decoded.has(grain.source)):list;
  return Object.freeze({
    accent:playable(profile.roles.accent),
    tone:playable(profile.roles.tone),
    texture:playable(profile.roles.texture),
    air:playable(profile.roles.air),
    transitions:playable(profile.transitions),
    pitchClass:pitch=>{
      const wanted=pitchClassOf(pitch);
      return wanted==null?[]:playable(profile.pitchClasses[Math.round(wanted)%12]||[]);
    },
  });
}
