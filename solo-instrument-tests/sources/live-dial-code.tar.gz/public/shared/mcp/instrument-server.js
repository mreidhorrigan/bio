// An instrument's MCP server, in the page beside its player (the owner, 3 November 2026: "develop and push an in-page MCP
// server implementation by which a playerbot retrieves parameter information about its instrument and determines how to
// play it"): what the player knows of its instrument (shared/performers/instrument-facts.js) as resources, read at its
// startup, and what it would ask of one pitch as a tool; the motifs it was given as MusicXML as their lines
// (musicxml-motifs.js). The same server answers any client: an LLM's, later, through the same transport.
//   musebots://instrument/<id>                 everything its facts hold
//   musebots://instrument/<id>/<part>          one part of them: compass, registers, dynamics, breath (a wind's) or bow
//                                              (a bowed instrument's), articulation, vibrato, techniques, reed (where
//                                              published), engine (the engine it is linked to, where one is), idiom
//                                              (its relations: idiom.js)
//   musebots://instrument/<id>/motifs          the motifs it was given: [{id, name, part, notes: [{at, pitch, written}]}]
//   musebots://instruments                     the instruments a player may be told of
//   musebots://instruments/{instrument}        another instrument's facts (a template)
//   tool at_pitch {pitch}                      factsAt: its register, comfort, dynamics, sound power and pressure there
//   tool move {from, to, seconds}              a move's time on it and its share of the time it has (idiom.js)
//   tool together {pitches}                    whether it plays them together, and how: a double stop, a multiphonic
import {McpServer} from './server.js';
import {instrumentFacts,factsAt,FACTS_INSTRUMENTS} from '../performers/instrument-facts.js';
import {idiomOf} from '../performers/idiom.js';
import {motifLine} from '../performers/musicxml-motifs.js';

export const instrumentUri=(id,part=null)=>`musebots://instrument/${id}${part?`/${part}`:''}`;
const PARTS=Object.freeze(['compass','registers','dynamics','breath','bow','articulation','vibrato','techniques','reed','engine','idiom']);

// instrument: a bot's name or an engine's; compass: an engine's [low, high], where one plays it; engine: the engine it
// is linked to, as it says itself ({name, techniques?, mutes?, quickest?}: instrument-facts.js); motifs: [{musicxml,
// id?, name?, part?}].
export function instrumentServer({instrument,compass=null,engine=null,motifs=[]}){
  const facts=instrumentFacts(instrument,{compass,engine}),id=facts.instrument;
  const lines=(motifs??[]).map((given,k)=>({id:given.id??`motif-${k+1}`,name:given.name??null,...motifLine(given.musicxml,{part:given.part??null})}));
  const server=new McpServer({name:'musebots-instrument',version:'0.1.0',
    instructions:`The ${facts.compass.name} (${id}): its compass, register, dynamics, ${facts.breath?'breath and pressure':'bow'}, articulation, vibrato and techniques${facts.engine?`, and the engine it is linked to (${facts.engine.name})`:''} and its idiom as resources under ${instrumentUri(id)}; at_pitch for one pitch${facts.idiom?.moves?', move for a move between two':''}${facts.idiom?.together?', together for notes played at once':''}; its given motifs under ${instrumentUri(id,'motifs')}.`});
  server.resource({uri:instrumentUri(id),name:`${id}: its facts`,description:'Everything the player knows of its instrument, each with its source.',read:()=>facts});
  for(const part of PARTS)if(facts[part]!=null)server.resource({uri:instrumentUri(id,part),name:`${id}: its ${part}`,read:()=>facts[part]});
  server.resource({uri:instrumentUri(id,'motifs'),name:`${id}: the motifs it was given`,description:'Each MusicXML motif\'s line: onsets in exact quarters, sounding pitches.',read:()=>lines});
  server.resource({uri:'musebots://instruments',name:'The instruments',read:()=>[...FACTS_INSTRUMENTS]});
  server.template({uriTemplate:'musebots://instruments/{instrument}',name:'Another instrument\'s facts',read:({instrument:other})=>instrumentFacts(other)});
  server.tool({name:'at_pitch',description:'What its facts say at one sounding pitch (MIDI, fractional allowed): in its compass and register, which third, the dynamics comfortable there, its sound power and its mouth\'s pressure pp to ff.',
    inputSchema:{type:'object',properties:{pitch:{type:'number'}},required:['pitch']},
    call:({pitch})=>{if(!Number.isFinite(pitch))throw new RangeError('at_pitch: a finite pitch');return factsAt(facts,pitch)}});
  const idiom=idiomOf(facts.idiom);
  if(idiom?.move&&facts.idiom.moves)server.tool({name:'move',description:'A move on it from one sounding pitch to another, the first held `seconds` (s): the time it needs (a wind\'s fingers and registers crossed, a bowed instrument\'s shift), its share of those seconds, and whether it needs more than it has.',
    inputSchema:{type:'object',properties:{from:{type:'number'},to:{type:'number'},seconds:{type:'number'}},required:['from','to','seconds']},
    call:({from,to,seconds})=>{if(![from,to,seconds].every(Number.isFinite))throw new RangeError('move: finite pitches and seconds');return idiom.move(from,to,seconds)}});
  if(idiom&&facts.idiom.together)server.tool({name:'together',description:'Whether it plays these sounding pitches together, and how: on adjacent strings within its hand\'s frame (a double stop, a chord), or a multiphonic measured on it.',
    inputSchema:{type:'object',properties:{pitches:{type:'array',items:{type:'number'}}},required:['pitches']},
    call:({pitches})=>{if(!Array.isArray(pitches)||!pitches.every(Number.isFinite))throw new RangeError('together: finite pitches');return idiom.together(pitches)}});
  return server;
}
