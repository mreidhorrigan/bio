// An instrument's MCP server, in the page beside its player (the owner, 3 November 2026: "develop and push an in-page MCP
// server implementation by which a playerbot retrieves parameter information about its instrument and determines how to
// play it"): what the player knows of its instrument (shared/performers/instrument-facts.js) as resources, read at its
// startup, and what it would ask of one pitch as a tool; the motifs it was given as MusicXML as their lines
// (musicxml-motifs.js). The same server answers any client: an LLM's, later, through the same transport.
//   musebots://instrument/<id>                 everything its facts hold
//   musebots://instrument/<id>/<part>          one part of them: compass, registers, dynamics, breath (a wind's) or bow
//                                              (a bowed instrument's), articulation, vibrato, techniques, reed (where
//                                              published), engine (the engine it is linked to, where one is)
//   musebots://instrument/<id>/motifs          the motifs it was given: [{id, name, part, notes: [{at, pitch, written}]}]
//   musebots://instruments                     the instruments a player may be told of
//   musebots://instruments/{instrument}        another instrument's facts (a template)
//   tool at_pitch {pitch}                      factsAt: its register, comfort, dynamics, sound power and pressure there
import {McpServer} from './server.js';
import {instrumentFacts,factsAt,FACTS_INSTRUMENTS} from '../performers/instrument-facts.js';
import {motifLine} from '../performers/musicxml-motifs.js';

export const instrumentUri=(id,part=null)=>`musebots://instrument/${id}${part?`/${part}`:''}`;
const PARTS=Object.freeze(['compass','registers','dynamics','breath','bow','articulation','vibrato','techniques','reed','engine']);

// instrument: a bot's name or an engine's; compass: an engine's [low, high], where one plays it; engine: the engine it
// is linked to, as it says itself ({name, techniques?, mutes?, quickest?}: instrument-facts.js); motifs: [{musicxml,
// id?, name?, part?}].
export function instrumentServer({instrument,compass=null,engine=null,motifs=[]}){
  const facts=instrumentFacts(instrument,{compass,engine}),id=facts.instrument;
  const lines=(motifs??[]).map((given,k)=>({id:given.id??`motif-${k+1}`,name:given.name??null,...motifLine(given.musicxml,{part:given.part??null})}));
  const server=new McpServer({name:'musebots-instrument',version:'0.1.0',
    instructions:`The ${facts.compass.name} (${id}): its compass, register, dynamics, ${facts.breath?'breath and pressure':'bow'}, articulation, vibrato and techniques${facts.engine?`, and the engine it is linked to (${facts.engine.name})`:''} as resources under ${instrumentUri(id)}; at_pitch for one pitch; its given motifs under ${instrumentUri(id,'motifs')}.`});
  server.resource({uri:instrumentUri(id),name:`${id}: its facts`,description:'Everything the player knows of its instrument, each with its source.',read:()=>facts});
  for(const part of PARTS)if(facts[part]!=null)server.resource({uri:instrumentUri(id,part),name:`${id}: its ${part}`,read:()=>facts[part]});
  server.resource({uri:instrumentUri(id,'motifs'),name:`${id}: the motifs it was given`,description:'Each MusicXML motif\'s line: onsets in exact quarters, sounding pitches.',read:()=>lines});
  server.resource({uri:'musebots://instruments',name:'The instruments',read:()=>[...FACTS_INSTRUMENTS]});
  server.template({uriTemplate:'musebots://instruments/{instrument}',name:'Another instrument\'s facts',read:({instrument:other})=>instrumentFacts(other)});
  server.tool({name:'at_pitch',description:'What its facts say at one sounding pitch (MIDI, fractional allowed): in its compass and register, which third, the dynamics comfortable there, its sound power and its mouth\'s pressure pp to ff.',
    inputSchema:{type:'object',properties:{pitch:{type:'number'}},required:['pitch']},
    call:({pitch})=>{if(!Number.isFinite(pitch))throw new RangeError('at_pitch: a finite pitch');return factsAt(facts,pitch)}});
  return server;
}
