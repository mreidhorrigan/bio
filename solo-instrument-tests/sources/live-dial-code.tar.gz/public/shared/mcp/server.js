// A Model Context Protocol server that runs in the page (or in Node, or a Worker): JSON-RPC 2.0 (shared/jsonrpc.js) over
// any transport (shared/mcp/transport.js), with the protocol's lifecycle (initialize, then notifications/initialized),
// its resources (resources/list, resources/read, resources/templates/list) and its tools (tools/list, tools/call), and
// ping. The protocol's revision is the one integrations/mcp-musebots.mjs speaks, a client's own echoed where it names
// one. No model is needed on either side: a musebot reads its instrument's facts through it at startup
// (instrument-server.js), and an LLM's client, later, the same way (the owner, 3 November 2026: "we will add
// LLM-player-writing later").
//   const server=new McpServer({name, version, instructions});
//   server.resource({uri, name, description, mimeType, read: () => text or value});
//   server.tool({name, description, inputSchema, call: async (args) => value});
//   server.connect(transport)  or  await server.handle(message) -> its answer, or null for a notification
import {rpcError,rpcResult,requestProblem,RPC_ERRORS} from '../jsonrpc.js';

export const MCP_PROTOCOL_VERSION='2025-06-18';
const JSON_TYPE='application/json';
// (A resource's contents as the protocol carries them: its text, a value as JSON.)
const contentsOf=(resource,value)=>({uri:resource.uri,mimeType:resource.mimeType,text:typeof value==='string'?value:JSON.stringify(value)});
// (A tool's answer: its value as text and as structured content, or the error it met, said as a tool's error.)
const toolResult=value=>({content:[{type:'text',text:typeof value==='string'?value:JSON.stringify(value)}],...(value&&typeof value==='object'?{structuredContent:value}:{}),isError:false});
const toolError=error=>({content:[{type:'text',text:String(error?.message??error)}],isError:true});

export class McpServer {
  constructor({name,version,instructions=''}){
    this.info={name,version};this.instructions=instructions;
    this.resources=new Map;this.templates=[];this.tools=new Map;this.initialized=false;this.ready=false;this.transport=null;
  }
  resource({uri,name,description='',mimeType=JSON_TYPE,read}){
    if(this.resources.has(uri))throw new Error(`mcp: a resource ${uri} already`);
    this.resources.set(uri,{uri,name,description,mimeType,read});return this;
  }
  // A family of resources by a URI template (RFC 6570's simplest: `{name}` stands for one path segment), read with its
  // values: read({name: value}).
  template({uriTemplate,name,description='',mimeType=JSON_TYPE,read}){
    const names=[],pattern=new RegExp(`^${uriTemplate.replace(/[.*+?^$()|[\]\\]/g,'\\$&').replace(/\{(\w+)\}/g,(_,key)=>{names.push(key);return '([^/]+)'})}$`);
    this.templates.push({uriTemplate,name,description,mimeType,read,match:uri=>{const m=pattern.exec(uri);return m?Object.fromEntries(names.map((key,k)=>[key,decodeURIComponent(m[k+1])])):null}});
    return this;
  }
  tool({name,description='',inputSchema={type:'object',properties:{}},call}){
    if(this.tools.has(name))throw new Error(`mcp: a tool ${name} already`);
    this.tools.set(name,{name,description,inputSchema,call});return this;
  }
  connect(transport){
    this.transport=transport;
    transport.onmessage=message=>{Promise.resolve(this.receive(message)).then(answer=>{if(answer&&!transport.closed)transport.send(answer)})};
    return this;
  }
  close(){this.transport?.close()}
  // One message, or a batch of them (JSON-RPC 2.0 §6): their answers.
  async receive(message){
    if(Array.isArray(message)){const answers=(await Promise.all(message.map(item=>this.handle(item)))).filter(Boolean);return answers.length?answers:null}
    return this.handle(message);
  }
  async handle(message){
    const problem=requestProblem(message),id=message&&typeof message==='object'?message.id:undefined,request=id!==undefined;
    if(problem)return rpcError(id??null,RPC_ERRORS.invalidRequest,problem);
    const params=message.params??{},answer=result=>request?rpcResult(id,result):null,fail=(code,text,data)=>request?rpcError(id,code,text,data):null;
    switch(message.method){
      case 'initialize':
        if(this.initialized)return fail(RPC_ERRORS.alreadyInitialized,'Already initialized');
        this.initialized=true;this.client=params.clientInfo??null;
        return answer({protocolVersion:String(params.protocolVersion||MCP_PROTOCOL_VERSION),
          capabilities:{resources:{},tools:{}},serverInfo:{...this.info},...(this.instructions?{instructions:this.instructions}:{})});
      case 'notifications/initialized':this.ready=true;return null;
      case 'notifications/cancelled':return null;
      case 'ping':return answer({});
    }
    if(!this.initialized)return fail(RPC_ERRORS.notInitialized,'Initialize first');
    switch(message.method){
      case 'resources/list':return answer({resources:[...this.resources.values()].map(({uri,name,description,mimeType})=>({uri,name,description,mimeType}))});
      case 'resources/templates/list':return answer({resourceTemplates:this.templates.map(({uriTemplate,name,description,mimeType})=>({uriTemplate,name,description,mimeType}))});
      case 'resources/read':{
        const uri=String(params.uri??''),own=this.resources.get(uri);
        try{
          if(own)return answer({contents:[contentsOf(own,await own.read())]});
          for(const template of this.templates){const values=template.match(uri);if(values)return answer({contents:[contentsOf({uri,mimeType:template.mimeType},await template.read(values))]})}
        }catch(error){return fail(RPC_ERRORS.invalidParams,`${uri}: ${error.message}`)}
        return fail(RPC_ERRORS.invalidParams,`No resource ${uri}`);
      }
      case 'tools/list':return answer({tools:[...this.tools.values()].map(({name,description,inputSchema})=>({name,description,inputSchema}))});
      case 'tools/call':{
        const tool=this.tools.get(String(params.name??''));
        if(!tool)return fail(RPC_ERRORS.invalidParams,`No tool ${params.name}`);
        try{return answer(toolResult(await tool.call(params.arguments??{})))}catch(error){return answer(toolError(error))}
      }
      default:return fail(RPC_ERRORS.methodNotFound,`No method ${message.method}`);
    }
  }
}
