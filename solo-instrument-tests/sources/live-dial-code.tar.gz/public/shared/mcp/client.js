// A Model Context Protocol client for the page (shared/mcp/server.js's other end): it initializes, says it is
// initialized, and then lists and reads resources and lists and calls tools, each request answered by its id.
//   const client=await new McpClient({name, version}).connect(transport);
//   await client.read(uri)        -> the resource's value (JSON parsed where its type is JSON)
//   await client.call(name, args) -> the tool's structured value, or its text; a tool's error thrown
import {MCP_PROTOCOL_VERSION} from './server.js';

export class McpClient {
  constructor({name,version}){this.info={name,version};this.pending=new Map;this.next=1;this.transport=null;this.server=null}
  async connect(transport){
    this.transport=transport;
    transport.onmessage=message=>{for(const answer of Array.isArray(message)?message:[message])this.hear(answer)};
    transport.onclose=()=>{for(const {fail} of this.pending.values())fail(new Error('mcp: the server closed'));this.pending.clear()};
    const started=await this.request('initialize',{protocolVersion:MCP_PROTOCOL_VERSION,capabilities:{},clientInfo:{...this.info}});
    this.server=started;transport.send({jsonrpc:'2.0',method:'notifications/initialized'});
    return this;
  }
  hear(message){
    const waiting=this.pending.get(message?.id);if(!waiting)return;
    this.pending.delete(message.id);
    if(message.error)waiting.fail(Object.assign(new Error(message.error.message),{code:message.error.code,data:message.error.data}));
    else waiting.done(message.result);
  }
  request(method,params={}){
    const id=this.next++;
    return new Promise((done,fail)=>{this.pending.set(id,{done,fail});this.transport.send({jsonrpc:'2.0',id,method,params})});
  }
  resources(){return this.request('resources/list').then(r=>r.resources)}
  templates(){return this.request('resources/templates/list').then(r=>r.resourceTemplates)}
  tools(){return this.request('tools/list').then(r=>r.tools)}
  async read(uri){
    const {contents:[content]}=await this.request('resources/read',{uri});
    return /json/.test(content.mimeType??'')?JSON.parse(content.text):content.text;
  }
  async call(name,args={}){
    const result=await this.request('tools/call',{name,arguments:args});
    if(result.isError)throw new Error(`mcp tool ${name}: ${result.content?.[0]?.text??'failed'}`);
    return result.structuredContent??result.content?.[0]?.text;
  }
  close(){this.transport?.close()}
}
