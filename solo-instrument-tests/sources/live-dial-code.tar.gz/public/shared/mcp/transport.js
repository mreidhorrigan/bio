// The Model Context Protocol's transports in a page (shared/mcp/server.js, client.js): each end sends JSON-RPC 2.0
// messages and hears the other's through `onmessage`, every message copied as it crosses (structuredClone), so that
// neither end holds the other's objects -- as over stdio or a socket.
//   inPagePair()        -> {client, server}: two ends in one page or process, each message delivered on a microtask
//   portTransport(port) -> an end over a MessagePort (a Worker's, an iframe's, a MessageChannel's)
// An end: send(message), close(), onmessage(message) and onclose() set by whoever listens.
const copied=message=>typeof structuredClone==='function'?structuredClone(message):JSON.parse(JSON.stringify(message));

export function inPagePair(){
  const end=()=>({onmessage:null,onclose:null,closed:false,peer:null,
    send(message){
      if(this.closed||this.peer.closed)throw new Error('mcp transport: closed');
      const peer=this.peer,sent=copied(message);
      queueMicrotask(()=>{if(!peer.closed)peer.onmessage?.(sent)});
    },
    close(){if(this.closed)return;this.closed=true;this.onclose?.();this.peer.close()}});
  const client=end(),server=end();client.peer=server;server.peer=client;
  return {client,server};
}

export function portTransport(port){
  const end={onmessage:null,onclose:null,closed:false,
    send(message){if(this.closed)throw new Error('mcp transport: closed');port.postMessage(message)},
    close(){if(this.closed)return;this.closed=true;port.close?.();this.onclose?.()}};
  port.onmessage=event=>{if(!end.closed)end.onmessage?.(event.data)};
  port.start?.();
  return end;
}
