// DAW-neutral placements. Seconds are on the project's clock, with zero at its start.
// Clips occupy half-open intervals; a clip ending as another starts leaves no gap.
export const ARRANGEMENT_FORMAT='musebots-arrangement';
const plain=value=>value!==null&&typeof value==='object'&&!Array.isArray(value);
const freeze=value=>{if(value&&typeof value==='object'){Object.values(value).forEach(freeze);Object.freeze(value)}return value};
const number=(value,name,min=0)=>{if(typeof value!=='number'||!Number.isFinite(value)||value<min)throw new TypeError(`${name} must be a finite number >= ${min}`);return value};
const id=(value,name)=>{if(typeof value!=='string'||!value.length||value.length>200)throw new TypeError(`${name} needs an identifier (1..200 characters)`);return value};
function fields(value,allowed,name){
  if(!plain(value))throw new TypeError(`${name} must be an object`);
  for(const key of Object.keys(value))if(!allowed.includes(key)&&!key.startsWith('$')&&!key.startsWith('//'))throw new TypeError(`${name}.${key} is not supported`);
}

export function normalizeArrangement(value){
  fields(value,['format','version','title','endSeconds','anchors','tracks','clips','provenance'],'arrangement');
  if(value.format!==ARRANGEMENT_FORMAT||value.version!==1)throw new TypeError(`Expected ${ARRANGEMENT_FORMAT} version 1`);
  if(!Array.isArray(value.tracks)||!Array.isArray(value.clips)||value.clips.length>10000)throw new TypeError('Arrangement needs tracks and at most 10000 clips');
  const tracks=new Map(value.tracks.map((track,index)=>{
    fields(track,['id','name'],'track');const key=id(track.id,`tracks[${index}].id`);return [key,{id:key,name:String(track.name??key)}];
  }));
  if(tracks.size!==value.tracks.length)throw new Error('Duplicate track id');
  const source=new Map;
  for(const clip of value.clips){
    fields(clip,['id','track','at','durationSeconds','enabled','name','source','provenance'],'clip');
    const key=id(clip.id,'clip.id');if(source.has(key))throw new Error(`Duplicate clip id: ${key}`);
    if(!tracks.has(clip.track))throw new Error(`Clip ${key}: unknown track ${clip.track}`);
    if(!(number(clip.durationSeconds,`clip ${key} durationSeconds`)>0))throw new RangeError(`Clip ${key} needs positive durationSeconds`);
    if(clip.enabled!==undefined&&typeof clip.enabled!=='boolean')throw new TypeError(`Clip ${key}: enabled must be boolean`);
    if(clip.source!=null){
      fields(clip.source,['file','offsetSeconds','gain','fadeIn','fadeOut'],'clip.source');
      if(typeof clip.source.file!=='string'||!clip.source.file.length||clip.source.file.length>4096||clip.source.file.includes('\0'))throw new TypeError('clip.source.file must be a path (1..4096 characters)');
      for(const field of ['offsetSeconds','gain','fadeIn','fadeOut'])if(clip.source[field]!=null)number(clip.source[field],`clip ${key} source.${field}`);
    }
    source.set(key,clip);
  }
  const anchors=value.anchors??{};if(!plain(anchors)||Object.keys(anchors).length>10000)throw new TypeError('anchors must be an object with at most 10000 entries');
  const cache=new Map,visiting=new Set;
  const resolve=(key,position)=>{
    if(cache.has(key))return cache.get(key);
    if(visiting.has(key))throw new Error(`Cyclic placement dependency at ${key}`);
    if(visiting.size>512)throw new Error('Placement dependencies exceed 512 levels');
    visiting.add(key);
    fields(position,['seconds','anchor','clip','edge','offsetSeconds'],key);
    if(['seconds','anchor','clip'].filter(field=>Object.hasOwn(position,field)).length!==1)throw new TypeError(`${key} needs exactly one of seconds, anchor, clip`);
    let at;
    if('seconds' in position){
      if('edge' in position||'offsetSeconds' in position)throw new TypeError(`${key}: absolute seconds cannot have edge or offsetSeconds`);
      at=number(position.seconds,`${key}.seconds`);
    }else{
      const offset=number(position.offsetSeconds??0,`${key}.offsetSeconds`,-Infinity);
      if('anchor' in position){
        if('edge' in position)throw new TypeError(`${key}: edge belongs to a clip reference`);
        if(!Object.hasOwn(anchors,position.anchor))throw new Error(`Unknown anchor: ${position.anchor}`);
        at=resolve(`anchor:${position.anchor}`,anchors[position.anchor])+offset;
      }else{
        const other=source.get(position.clip);if(!other)throw new Error(`Unknown clip: ${position.clip}`);
        if(!['start','end'].includes(position.edge))throw new TypeError(`${key}: clip edge must be start or end`);
        at=resolve(`clip:${other.id}`,other.at)+(position.edge==='end'?other.durationSeconds:0)+offset;
      }
    }
    number(at,`${key} resolved seconds`);visiting.delete(key);cache.set(key,at);return at;
  };
  for(const [key,at] of Object.entries(anchors))resolve(`anchor:${key}`,at);
  const clips=[...source.values()].map(clip=>{
    const startSeconds=resolve(`clip:${clip.id}`,clip.at),endSeconds=number(startSeconds+clip.durationSeconds,`clip ${clip.id} end`);
    return {...structuredClone(clip),startSeconds,endSeconds,enabled:clip.enabled!==false};
  });
  const last=clips.reduce((end,clip)=>Math.max(end,clip.endSeconds),0),endSeconds=number(value.endSeconds??last,'endSeconds');
  if(!(endSeconds>0)||endSeconds<last)throw new RangeError('endSeconds must be positive and include every clip');
  return freeze({format:ARRANGEMENT_FORMAT,version:1,title:String(value.title??''),endSeconds,tracks:[...tracks.values()],
    anchors:structuredClone(anchors),clips,
    ...(value.provenance?{provenance:structuredClone(value.provenance)}:{})});
}

// Convert a normalized document back to interchange JSON, without cached positions.
export function arrangementDocument(arrangement){
  return {...structuredClone(arrangement),clips:arrangement.clips.map(({startSeconds,endSeconds,...clip})=>structuredClone(clip))};
}

export function arrangementCoverage(arrangement,{track=null}={}){
  if(track!==null&&!arrangement.tracks.some(item=>item.id===track))throw new Error(`Unknown track ${track}`);
  const events=new Map([[0,{start:[],end:[]}],[arrangement.endSeconds,{start:[],end:[]}]]);
  const event=at=>{if(!events.has(at))events.set(at,{start:[],end:[]});return events.get(at)};
  for(const clip of arrangement.clips)if(clip.enabled&&(track===null||clip.track===track)){
    event(clip.startSeconds).start.push(clip.id);event(clip.endSeconds).end.push(clip.id);
  }
  const times=[...events.keys()].sort((a,b)=>a-b),active=new Set,out=[];let memberships=0;
  for(let i=0;i<times.length-1;i++){
    const startSeconds=times[i],next=events.get(startSeconds);
    next.end.forEach(key=>active.delete(key));next.start.forEach(key=>active.add(key));
    memberships+=active.size;if(memberships>1000000)throw new RangeError('Arrangement coverage exceeds one million interval/clip memberships; split the preparation into smaller regions');
    out.push({startSeconds,endSeconds:times[i+1],clipIds:[...active].sort()});
  }
  return out;
}

export function arrangementGaps(arrangement,options){
  const gaps=[];
  for(const span of arrangementCoverage(arrangement,options))if(!span.clipIds.length){
    const last=gaps.at(-1);if(last?.endSeconds===span.startSeconds)last.endSeconds=span.endSeconds;
    else gaps.push({startSeconds:span.startSeconds,endSeconds:span.endSeconds});
  }
  return gaps;
}

// The union is counted once, even when many clips overlap. No claim about attacks,
// loudness or silence inside a clip is inferred from its rectangular placement.
export function arrangementWindow(arrangement,from,to){
  number(from,'window start');number(to,'window end');if(!(to>from))throw new RangeError('Window must have positive length');
  const startSeconds=Math.min(arrangement.endSeconds,from),endSeconds=Math.min(arrangement.endSeconds,to),ids=new Set;
  let occupiedSeconds=0;
  for(const span of arrangement.coverage??arrangementCoverage(arrangement)){
    const seconds=Math.min(endSeconds,span.endSeconds)-Math.max(startSeconds,span.startSeconds);
    if(seconds>0&&span.clipIds.length){occupiedSeconds+=seconds;span.clipIds.forEach(key=>ids.add(key))}
  }
  const seconds=Math.max(0,endSeconds-startSeconds);
  return {startSeconds,endSeconds,seconds,occupiedSeconds,gapSeconds:Math.max(0,seconds-occupiedSeconds),
    occupiedFraction:seconds?Math.min(1,occupiedSeconds/seconds):0,clipIds:[...ids].sort()};
}
