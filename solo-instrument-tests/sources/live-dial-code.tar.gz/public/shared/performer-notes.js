// The performer's notes, as a listening bot announces them to the ensemble: /broadcast/voices with role 'performer', so
// that the performer's line is heard as the bots' lines are (sounding-voices.js): a voice leader keeps out of octaves
// with it, a rhythm bot hears its onsets, and a motif profiler (motif-profiler-bot.js) gathers its phrases for
// mh_MemoryBOT. A listener hears notes from audio (pitch-yin.js); a MIDI input from the notes played.
//
// Notes are queued with their times on the input's clock and announced at the next tick, each placed on the tick that
// sounded when it was played. The band sounds one output delay after it decides (the scheduler's lookahead), and a
// performer plays with what sounds: a note heard at `at` is (now + delay - at) seconds before the tick being decided.
import {voicesPayload} from './sounding-voices.js';
import {secondsPerTick} from './meter-tactus.js';

export class PerformerNotes {
  constructor({voice='performer'}={}){this.voice=voice;this.queue=[];}
  // A note begun at `at` (seconds on the input's clock) at a fractional MIDI pitch; a silence where one ended.
  start(at,midi){if(Number.isFinite(at)&&Number.isFinite(midi))this.queue.push({at,pitches:[+midi.toFixed(3)]})}
  end(at){if(Number.isFinite(at))this.queue.push({at,pitches:[]})}
  clear(){this.queue=[]}
  // The notes heard by `now`, as /broadcast/voices messages on the ensemble's ticks.
  flush(clock,now,delay=.25){
    if(!this.queue.length||!clock?.meter||!Number.isFinite(clock.tick)||!Number.isFinite(now))return [];
    const perTick=secondsPerTick(clock);
    const due=this.queue.filter(event=>event.at<=now);this.queue=this.queue.filter(event=>event.at>now);
    return due.map(event=>({address:'/broadcast/voices',args:[{...voicesPayload({voice:this.voice,role:'performer',pitches:event.pitches,clock}),
      tick:+(clock.tick-(now+delay-event.at)/perTick).toFixed(3)}]}));
  }
}

// Note on and note off from MIDI 1 bytes: {on: pitch} or {off: pitch}, or null.
export function midiNote(bytes){
  const status=bytes?.[0]&0xf0,pitch=bytes?.[1],velocity=bytes?.[2];
  if(!Number.isInteger(pitch))return null;
  if(status===0x90&&velocity>0)return {on:pitch,velocity};
  if(status===0x80||status===0x90&&velocity===0)return {off:pitch};
  return null;
}
