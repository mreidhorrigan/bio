// The space of meters and tempo relations, interpolable. The user, 28 September 2026: "A parameter or set of parameters
// is interpolable when intermediate states exist between all the their possible states ... but in actual music,
// parameters can and should jump or have strong discontinuities sometimes." So this is about the space, not about
// moving slowly: between any two meters the system plays there is a meter at any fraction t between them, and between
// any two tempo relations a relation between. A bot may jump from one to another, or stop anywhere between.
//
// A meter's state here is its bar's duration (a whole note's rational fraction) and its groups' boundaries (fractions
// of the bar). Between meters a and b, at t (0 is a exactly, 1 is b exactly):
//   - the bar's duration lies t of the way between theirs, as the nearest rational of bounded denominator (an
//     irrational meter where it has to be: docs/NOTATION.md writes those as the real meter nearest them, with a tempo);
//   - each boundary moves from its place in a to its place in b. Where one meter has more groups, the other's
//     boundaries are doubled to match: a monotone matching of least total motion, so a group grows from nothing or
//     shrinks to nothing, and at the ends the doubled boundaries coincide;
//   - the bar is laid on the finest grid its boundaries need, within the meter's bounds (4096), and its tick grid keeps
//     about as many pulses a bar as the two meters have between them.
// Tempo relations are ratios, and between two there is a ratio t of the way, the nearest of bounded denominator.
import {RHYTHM_VOCABULARY,meterOfTala} from './rhythm-vocabulary.js';
import {unitRandom} from './stochastic.js';
const LIMIT=4096;
const gcd=(a,b)=>{a=Math.abs(a);b=Math.abs(b);while(b)[a,b]=[b,a%b];return a};
const reduced=(p,q)=>{const g=gcd(p,q)||1;return [p/g,q/g]};

// The best rational approximation of x > 0 with a denominator at most `limit` (continued fractions, their last term
// semiconvergent where that is nearer).
export function nearestRational(x,limit=64){
  if(!(x>0)||!Number.isFinite(x))throw new RangeError('A positive, finite value');
  let [p0,q0,p1,q1]=[0,1,1,0],value=x;
  for(let step=0;step<64;step++){
    const a=Math.floor(value),p2=a*p1+p0,q2=a*q1+q0;
    if(q2>limit){
      const k=Math.floor((limit-q0)/q1),ps=k*p1+p0,qs=k*q1+q0;
      return Math.abs(ps/qs-x)<Math.abs(p1/q1-x)?reduced(ps,qs):reduced(p1,q1);
    }
    [p0,q0,p1,q1]=[p1,q1,p2,q2];
    const fraction=value-a;
    if(fraction<1e-12)break;
    value=1/fraction;
  }
  return reduced(p1,q1);
}
// A bar's duration, in whole notes, reduced.
export const barDuration=meter=>reduced(Number(meter.numerator),Number(meter.denominator));
// A grouping's interior boundaries, as fractions of its bar, in order.
export function boundaries(groups){
  const total=groups.reduce((sum,size)=>sum+size,0);let at=0;
  return groups.slice(0,-1).map(size=>(at+=size)/total);
}
// Two sorted boundary lists made one length: the shorter's boundaries doubled so that each of the longer's has a partner,
// in order, with the least total motion (dynamic programming over a monotone matching). Returns [a, b] of equal length.
export function matchedBoundaries(a,b){
  if(a.length===b.length)return [[...a],[...b]];
  const [long,short,flip]=a.length>b.length?[a,b,false]:[b,a,true];
  // (A bar of one group has no boundary: the other's grow from the bar line nearest each.)
  if(!short.length){const from=long.map(x=>x<.5?0:1);return flip?[from,[...long]]:[[...long],from]}
  // cost[i][j]: long's first i matched to short's first j, each of short's at least once, in order.
  const n=long.length,m=short.length,INF=Infinity,cost=Array.from({length:n+1},()=>Array(m+1).fill(INF)),from=Array.from({length:n+1},()=>Array(m+1).fill(null));
  cost[0][0]=0;
  for(let i=1;i<=n;i++)for(let j=1;j<=m;j++){
    const here=Math.abs(long[i-1]-short[j-1]),same=cost[i-1][j],next=cost[i-1][j-1];
    if(same<=next){cost[i][j]=same+here;from[i][j]=j}else{cost[i][j]=next+here;from[i][j]=j-1}
  }
  const partner=Array(n);let j=m;
  for(let i=n;i>=1;i--){partner[i-1]=short[j-1];j=from[i][j]}
  return flip?[partner,[...long]]:[[...long],partner];
}

const copy=meter=>({...((meter.metricReading)?{metricReading:structuredClone(meter.metricReading)}:{}),...(meter.tempoUnit?{tempoUnit:meter.tempoUnit}:{}),...(meter.fixedDenominator?{fixedDenominator:true}:{}),numerator:meter.numerator,denominator:meter.denominator,groups:[...meter.groups],subdivision:meter.subdivision??4,
  ...(meter.phraseBars?{phraseBars:meter.phraseBars}:{}),...(meter.label?{label:meter.label}:{}),...(meter.sections?{sections:meter.sections.map(level=>[...level])}:{}),
  ...(meter.sectionDynamics?{sectionDynamics:[...meter.sectionDynamics]}:{})});
const groupsOf=meter=>Array.isArray(meter.groups)&&meter.groups.length&&meter.groups.reduce((a,b)=>a+b,0)===meter.numerator?meter.groups:[meter.numerator];

// The meter t of the way from a to b (0 < t < 1; a and b themselves at the ends). `maxDenominator` bounds the bar's
// duration's denominator before its grid is refined for its groups.
export function interpolateMeter(a,b,t,{maxDenominator=64}={}){
  if(!(t>=0&&t<=1))throw new RangeError('t is between 0 and 1');
  if(t===0)return copy({...a,groups:groupsOf(a)});
  if(t===1)return copy({...b,groups:groupsOf(b)});
  const [pa,qa]=barDuration(a),[pb,qb]=barDuration(b);
  const [p,q]=nearestRational((1-t)*pa/qa+t*pb/qb,maxDenominator);
  const [ma,mb]=matchedBoundaries(boundaries(groupsOf(a)),boundaries(groupsOf(b)));
  const positions=ma.map((x,index)=>(1-t)*x+t*mb[index]).sort((x,y)=>x-y);
  // The grid: the bar's p units refined by k until the nearest two boundaries (and the bar lines) are a unit apart.
  const marks=[0,...positions,1],gaps=marks.slice(1).map((x,index)=>x-marks[index]).filter(gap=>gap>1e-9);
  const smallest=gaps.length?Math.min(...gaps):1;
  const k=Math.max(1,Math.min(Math.ceil(1/(p*smallest)-1e-9),Math.floor(LIMIT/p),Math.floor(LIMIT/q)));
  const units=p*k,cuts=[...new Set(positions.map(x=>Math.round(x*units)).filter(u=>u>0&&u<units))].sort((x,y)=>x-y);
  const groups=[];let previous=0;for(const cut of [...cuts,units]){groups.push(cut-previous);previous=cut}
  // About as many pulses a bar as the two meters have between them, at least one a unit.
  const pulses=(1-t)*a.numerator*(a.subdivision??4)+t*b.numerator*(b.subdivision??4);
  const subdivision=Math.max(1,Math.min(96,Math.round(pulses/units)));
  return {numerator:units,denominator:q*k,groups,subdivision,...(a.phraseBars??b.phraseBars?{phraseBars:a.phraseBars??b.phraseBars}:{}),label:`${groups.join('+')}/${q*k}`,
    between:{from:a.label??`${a.numerator}/${a.denominator}`,to:b.label??`${b.numerator}/${b.denominator}`,t}};
}

// The tempo relation t of the way from one ratio to another ([p, q]: the new beat's rate over the old one's), the nearest
// of bounded denominator; each ratio itself at its end.
export function interpolateRatio(from,to,t,{maxDenominator=16}={}){
  if(!(t>=0&&t<=1))throw new RangeError('t is between 0 and 1');
  if(t===0)return reduced(from[0],from[1]);
  if(t===1)return reduced(to[0],to[1]);
  return nearestRational((1-t)*from[0]/from[1]+t*to[0]/to[1],maxDenominator);
}

// ---- The space of meters drawn from --------------------------------------------------------------------------------
// Where meterspace_clodbot draws its homes, and the piece's opening its meter (shared/opening-time.js) (ours). Weighted
// lists are [value, weight].
export const METER_SPACE=Object.freeze({
  numerators:Object.freeze([1,40]),
  // Power-of-two denominators mostly; the irrational ones besides (docs/NOTATION.md writes those as the real meter nearest,
  // with a tempo).
  denominators:Object.freeze([[2,1],[3,1],[4,4],[5,1],[6,1],[8,4],[10,1],[12,2],[16,3],[24,1],[32,1]].map(Object.freeze)),
  // A bar's groups: 2s and 3s mostly, now and then a 1 or a 4.
  groupSizes:Object.freeze([[2,4],[3,4],[1,.3],[4,1]].map(Object.freeze)),
  // The share of draws grouped as they draw, rather than as the meter's most-threes.
  ownGrouping:.7,
  // Pulses a unit.
  subdivisions:Object.freeze([[1,1],[2,3],[3,2],[4,3],[5,1],[6,1]].map(Object.freeze)),
  // The share of draws that are a named cycle (the rhythm vocabulary's talas).
  talas:.12,
  // A bar the band plays, in seconds at its tempo (longer bars: meterform's sections).
  barSeconds:Object.freeze([.5,10]),
});
const weighted=(list,random)=>{let draw=random()*list.reduce((sum,[,weight])=>sum+weight,0);for(const [value,weight] of list){draw-=weight;if(draw<=0)return value}return list.at(-1)[0]};
export const TALAS=Object.freeze(Object.keys(RHYTHM_VOCABULARY).filter(id=>RHYTHM_VOCABULARY[id].kind==='tala').sort());
// Most-threes of n units: 3s, with a 2 or two 2s at the end where n needs them.
function mostThrees(n){if(n<=3)return [n];const groups=[];let left=n;while(left>4){groups.push(3);left-=3}if(left===4)groups.push(2,2);else groups.push(left);return groups}

// A meter from anywhere in the space: {numerator, denominator, groups, subdivision, label}, and a tala's `tala` id
// where it is one. `random` a source of [0, 1); `numerators` [low, high]; `subdivision` a fixed one, where given.
// A bar of `numerator` units grouped as the space groups its meters: its own groups drawn, else its most-threes.
export function drawGrouping(numerator,random=unitRandom){
  if(!(random()<METER_SPACE.ownGrouping))return mostThrees(numerator);
  const groups=[];let left=numerator;while(left>0){const size=Math.min(left,weighted(METER_SPACE.groupSizes,random));groups.push(size);left-=size}
  return groups;
}
export function drawMeter(random=unitRandom,{numerators=METER_SPACE.numerators,subdivision=null,talas=true,denominator:fixed=null}={}){
  if(talas&&random()<METER_SPACE.talas){
    const id=TALAS[Math.floor(random()*TALAS.length)],made=meterOfTala(RHYTHM_VOCABULARY[id]);
    if((fixed===null||made.denominator===fixed)&&made.numerator>=numerators[0]&&made.numerator<=numerators[1]){
      const own=subdivision??made.subdivision;
      return {numerator:made.numerator,denominator:made.denominator,groups:[...made.groups],subdivision:own,tala:id,
        label:`${RHYTHM_VOCABULARY[id].name}, ${made.groups.join('+')}/${made.denominator}`};
    }
  }
  const numerator=numerators[0]+Math.floor(random()*(numerators[1]-numerators[0]+1)),denominator=fixed??weighted(METER_SPACE.denominators,random);
  const groups=drawGrouping(numerator,random);
  return {numerator,denominator,groups,subdivision:subdivision??weighted(METER_SPACE.subdivisions,random),label:`${groups.join('+')}/${denominator}`};
}
