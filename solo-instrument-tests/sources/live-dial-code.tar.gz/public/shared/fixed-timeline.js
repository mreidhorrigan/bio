// Musical-time arithmetic has no clock-estimator, browser or transport dependency.
const finite=(value,name)=>{if(typeof value!=='number'||!Number.isFinite(value))throw new TypeError(`Invalid ${name}`);return value;};

export class FixedTimeline {
  constructor({sessionId,epoch,id='fixed',revision=1,bpm=120,originBeat=0,originReference,beatsPerBar=4}) {
    for(const [name,value]of Object.entries({bpm,originBeat,originReference,beatsPerBar}))finite(value,name);
    if(bpm<20||bpm>300||originBeat<0||!Number.isInteger(beatsPerBar)||beatsPerBar<1||beatsPerBar>32||revision!==1)
      throw new TypeError('Invalid fixed tempo map');
    if(![sessionId,epoch,id].every(x=>typeof x==='string'&&x.length&&x.length<=128))throw new TypeError('Tempo map identities required');
    Object.assign(this,{sessionId,epoch,id,revision,bpm,originBeat,originReference,beatsPerBar});Object.freeze(this);
  }
  check({sessionId,epoch,tempoId,tempoRevision}) {
    if(sessionId!==this.sessionId||epoch!==this.epoch||tempoId!==this.id||tempoRevision!==this.revision)throw new Error('Unknown session or tempo-map revision');
  }
  referenceAtBeat(beat){return this.originReference+(finite(beat,'beat')-this.originBeat)*60/this.bpm;}
  beatAtReference(time){return this.originBeat+(finite(time,'reference time')-this.originReference)*this.bpm/60;}
  futureBoundary(now,leadBars=2){return Math.ceil((this.beatAtReference(now)+Math.max(1,leadBars)*this.beatsPerBar)/this.beatsPerBar)*this.beatsPerBar;}
}
