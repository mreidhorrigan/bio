export class FallbackControlLease {
  constructor(silenceBoundaries=4){this.silenceBoundaries=Math.max(1,Math.trunc(Number(silenceBoundaries)||1));this.missed=0;this.received=false;this.ownsFallback=false;this.value=null}
  receive(value){const number=Number(value);if(!Number.isFinite(number))return false;this.value=number;this.received=true;this.missed=0;this.ownsFallback=false;return true}
  advanceBoundary(){if(this.received){this.received=false;this.missed=0;this.ownsFallback=false}else{this.missed++;if(this.missed>=this.silenceBoundaries)this.ownsFallback=true}return this.ownsFallback}
}

// Tracks the presence of any valid ecosystem value (including lists) across
// musical boundaries, without forcing that value into a numeric control.
export class BoundaryPresenceLease {
  constructor(silenceBoundaries=4){this.silenceBoundaries=Math.max(1,Math.trunc(Number(silenceBoundaries)||1));this.missed=0;this.received=false;this.ownsFallback=false}
  receive(){this.received=true;this.missed=0;this.ownsFallback=false}
  advanceBoundary(){if(this.received){this.received=false;this.missed=0;this.ownsFallback=false}else if(++this.missed>=this.silenceBoundaries)this.ownsFallback=true;return this.ownsFallback}
}

// Repeated copies of a stuck value do not count as useful external control.
export class StaleValueLease {
  constructor(timeoutMs=3000,now=()=>Date.now()){this.timeoutMs=Math.max(1,Number(timeoutMs)||3000);this.now=now;this.value=null;this.lastChangeAt=this.now();this.ownsFallback=false}
  receive(value,at=this.now()){const number=Number(value);if(!Number.isFinite(number))return false;const changed=!Object.is(number,this.value);this.value=number;if(changed){this.lastChangeAt=at;this.ownsFallback=false}return changed}
  update(at=this.now()){if(at-this.lastChangeAt>=this.timeoutMs)this.ownsFallback=true;return this.ownsFallback}
}

export class StalePresenceLease {
  constructor(timeoutMs=3000,now=()=>Date.now()){this.timeoutMs=Math.max(1,Number(timeoutMs)||3000);this.now=now;this.valueKey=null;this.lastChangeAt=this.now();this.ownsFallback=false}
  receive(value,at=this.now()){const key=JSON.stringify(value),changed=key!==this.valueKey;this.valueKey=key;if(changed){this.lastChangeAt=at;this.ownsFallback=false}return changed}
  update(at=this.now()){if(at-this.lastChangeAt>=this.timeoutMs)this.ownsFallback=true;return this.ownsFallback}
}
