const copyArgs=args=>Array.isArray(args)?args.slice():[];
const isTime=address=>String(address)==='/mc/time'||String(address).startsWith('/mc/time/');
const isBroadcast=address=>String(address).startsWith('/broadcast/');

export class LegacyLanBridge {
  constructor({role='slave',origin='local',transport=()=>{}}={}){
    this.role=role==='master'?'master':'slave';this.origin=String(origin);this.transport=transport;this.targets=[];
  }
  configure({role=this.role,targets=this.targets}={}){
    this.role=role==='master'?'master':'slave';this.targets=[...new Set((targets||[]).map(String).filter(Boolean))];return this.snapshot();
  }
  snapshot(){return{role:this.role,origin:this.origin,targets:this.targets.slice()}}
  forwardLocal(message){
    const address=String(message?.address||'');
    if(message?.bridge?.origins?.includes(this.origin)||(!isBroadcast(address)&&!(this.role==='master'&&isTime(address))))return false;
    this.transport({address,args:copyArgs(message.args),bridge:{origins:[...(message.bridge?.origins||[]),this.origin],targets:this.targets.slice()}});
    return true;
  }
  receiveRemote(message){
    const address=String(message?.address||'');
    if(message?.bridge?.origins?.includes(this.origin)||(!isBroadcast(address)&&!(this.role==='slave'&&isTime(address))))return null;
    return{address,args:copyArgs(message.args),bridge:{origins:[...(message.bridge?.origins||[]),this.origin]}};
  }
}
