// The contour of a melody, above all a texture's top voice, as a cost for each pitch it might take next, given the line
// so far and where it stands in its phrase. The user: "You might also be aware of a variety of preference rules for
// desirable melodic contours, especially important for uppermost voices", and "there might also be maqam- and
// raga-based contour models, integrating pitch chroma and contour, that could be useful now that we have microtones
// involved."
//
// The rules of melodies in general (research/kalman-references.md):
// - Proximity: small intervals over large (Schellenberg 1997's simplification of Narmour 1990: pitch proximity and
//   pitch reversal carry what the implication-realization model predicts).
// - Reversal after a leap: a leap is followed by a turn the other way (Meyer 1956's gap fill), which von Hippel and
//   Huron (2000) show is mostly regression toward the middle of the line's range: the further a note is from the
//   middle, the likelier the next goes back toward it.
// - Step inertia, weakly: after a step, another the same way (Huron 2006).
// - Step declination: descending steps are commoner than ascending ones, and large intervals more often ascend (Vos
//   and Troost 1989).
// - The arch: a phrase rises and then falls (Huron 1996), and falls toward its end (late-phrase declination, Huron 2006).
// - One climax: the phrase's highest note reached once, and not at its very end (species counterpoint: Jeppesen 1939).
// - No tritone, leapt or outlined by two leaps the same way, nor a seventh outlined (Jeppesen 1939).
// - Few repeated notes on top: a top voice held for a chord is a common tone, held on and on it is no line.
// - Closure: a phrase's end reached by step, downward, onto a stable tone, the tonic most (at the piece's end, the tonic
//   only): the tonic arrival Narmour calls closure.
// Two more a caller may ask for (the user, 28 September 2026, on a maqam line that ran up and down its scale: "Usual
// well-formed melody rules - e.g., avoiding repeating apexes, etc; whatever you have stored - also apply in a maqam
// context"), off unless asked, so that the lines already tuned to the rules above are as they were:
// - A new climax: a phrase's highest note not the phrase before's (phrase.previousHigh), so successive phrases peak
//   on different notes.
// - No long runs: more than `runSteps` steps the same way cost (weights.runSteps, none by default; weights.run each),
//   so a line does not become a scale.
//
// Modes whose melodic path is part of what they are (`mode`, from maqamContour or ragaContour): the pitch classes a
// line takes going up and going down (a maqam's notes inflected by direction, a raga's aroha and avaroha), where its
// phrases rest (a maqam's qarar and ghammaz, a raga's nyas), which notes it dwells on (a raga's vadi and samvadi), and
// its path through the register (a maqam's seyir from the qarar up toward the ghammaz and back; the arch otherwise).
// These integrate pitch and contour: the same pitch class is right going up and wrong going down.
const modulo=(value,period)=>((value%period)+period)%period;
const pcDistance=(a,b)=>{const d=modulo(a-b,12);return Math.min(d,12-d)};
const among=(pc,list,tolerance=.2)=>(list??[]).some(member=>pcDistance(pc,member)<=tolerance);

export const CONTOUR_WEIGHTS=Object.freeze({proximity:.25,reversal:1.2,regression:.5,inertia:.3,declination:.2,arch:.12,climax:1.5,outline:1.5,
  repeat:.4,closure:2.5,direction:2.5,rest:1.5,dwell:.3,newClimax:1.2,run:.8,runSteps:Infinity});

// The cost of `pitch` as the line's next note. history: its notes so far (the latest last). phrase: {position (0 to 1
// through the phrase), start (its first note: the arch rises from where the phrase began), high (its highest note so
// far), ending (this note ends it), penultimate (it is in the piece's cadence bar), final (it ends the piece), strong (on
// a strong beat)}. center, span: the middle of the line's range and its width (from history where not given).
// tonic, stable: the key's centre and its stable tones (pitch classes). mode: maqamContour or ragaContour's. holds: the
// line is a chord's top voice, whose note held into the next chord is a common tone, not a note struck again (neither a
// repeat nor its climax reached again).
export function contourCost(pitch,{history=[],phrase={},center=null,span=null,tonic=null,stable=null,mode=null,holds=false,weights={}}={}){
  const w={...CONTOUR_WEIGHTS,...weights},parts={},last=history.at(-1),held=holds&&Number.isFinite(last)&&Math.abs(pitch-last)<.1;
  const middle=center??(history.length?history.reduce((a,b)=>a+b,0)/history.length:pitch),range=span??12;
  if(Number.isFinite(last)){
    const step=pitch-last,size=Math.abs(step),before=history.length>1?last-history.at(-2):null;
    parts.proximity=w.proximity*size;
    // After a leap (a fourth or more), the way on is the other way; the larger the leap, the more.
    if(before!==null&&Math.abs(before)>=5&&size>.1&&Math.sign(step)===Math.sign(before))parts.reversal=w.reversal*(Math.abs(before)-4)/3;
    // Far from the middle, further away costs (von Hippel and Huron's regression).
    const away=Math.abs(last-middle);
    if(away>6&&size>.1&&Math.sign(step)===Math.sign(last-middle))parts.regression=w.regression*(away-6)/3;
    if(before!==null&&Math.abs(before)>.5&&Math.abs(before)<=2.5&&size>.1&&Math.sign(step)!==Math.sign(before))parts.inertia=w.inertia;
    if(step>.5&&step<=2.5||step<-2.5)parts.declination=w.declination;
    // A tritone leapt, or two leaps the same way outlining a tritone or a seventh.
    const outlined=before!==null&&Math.sign(step)===Math.sign(before)&&Math.abs(before)>2.5&&size>2.5?Math.abs(step+before):null;
    if(Math.abs(size-6)<.3||outlined!==null&&[6,10,11].some(bad=>Math.abs(outlined-bad)<.3))parts.outline=w.outline;
    if(size<.1&&!held){const run=[...history].reverse().findIndex(p=>Math.abs(p-pitch)>=.1);parts.repeat=w.repeat*(run<0?history.length:run);}
    // Direction: the mode's notes going up and going down.
    if(mode&&size>.1){const allowed=step>0?mode.ascending:mode.descending;if(allowed&&!among(pitch-mode.tonic,allowed))parts.direction=w.direction;}
    // A run: the steps the same way this note would make, past runSteps (asked for by weights.runSteps).
    if(Number.isFinite(w.runSteps)&&size>.1&&size<=2.5){
      let run=1;for(let k=history.length-1;k>0;k--){const d=history[k]-history[k-1];if(Math.abs(d)>.1&&Math.abs(d)<=2.5&&Math.sign(d)===Math.sign(step))run++;else break}
      if(run>w.runSteps)parts.run=w.run*(run-w.runSteps);
    }
  }
  // The arch (or the mode's path): the register the phrase is at, by where it stands in it. A line's first note has no
  // phrase yet to arch within: where it begins is its own.
  if(Number.isFinite(phrase.position)&&(history.length||Number.isFinite(phrase.start))){
    const from=Number.isFinite(phrase.start)?phrase.start:middle;
    const target=mode?.path?pathTarget(mode,phrase.position,middle,range):from+Math.min(5,range/2)*(Math.sin(Math.PI*phrase.position)-.35*phrase.position);
    parts.arch=w.arch*Math.abs(pitch-target);
    // And by direction: rising in the phrase's first part, falling in its last (its arch as motion).
    if(Number.isFinite(last)&&Math.abs(pitch-last)>.1){const rising=pitch>last;if(phrase.position<.4&&!rising||phrase.position>.6&&rising)parts.arch+=w.arch*3;}
  }
  // One climax: the phrase's highest note not reached again, nor passed near its end.
  if(Number.isFinite(phrase.high)&&!held){
    if(Math.abs(pitch-phrase.high)<.1)parts.climax=w.climax*.6;
    else if(pitch>phrase.high&&(phrase.position??0)>.8)parts.climax=w.climax;
  }
  // A new climax: this phrase's highest note not the phrase before's.
  if(Number.isFinite(phrase.previousHigh)&&Math.abs(pitch-phrase.previousHigh)<.1&&!(pitch<(phrase.high??-Infinity)-.1))parts.newClimax=w.newClimax;
  // Before the close (the piece's cadence bar), a step from the tonic (its second or leading tone), from which the
  // last note arrives on it: the soprano's 2 to 1 or 7 to 1 of a perfect cadence.
  if(phrase.penultimate&&!phrase.final){
    const home=mode?modulo(mode.tonic,12):tonic;
    if(home!==null&&![1,2,10,11].some(step=>pcDistance(pitch-home,step)<.3))parts.closure=w.closure;
  }
  // Closure: a phrase's end by step down onto a stable tone (a mode's resting tones), the tonic at the piece's end.
  if(phrase.ending||phrase.final){
    const rests=mode?.rests?.map(pc=>modulo(mode.tonic+pc,12))??stable??(tonic!==null?[tonic]:null),home=mode?modulo(mode.tonic,12):tonic;
    if(rests&&!among(pitch,phrase.final&&home!==null?[home]:rests))parts.closure=w.closure*(phrase.final?3:1);
    else if(rests&&home!==null&&!among(pitch,[home]))parts.closure=w.closure*.3;
    if(Number.isFinite(last)&&!(pitch<last-.5&&pitch>=last-2.5))parts.closure=(parts.closure??0)+w.closure*.4;
  }
  // A raga's vadi and samvadi, a maqam's ghammaz: dwelt on, above all on a strong beat.
  if(mode?.dwell?.length&&among(pitch-mode.tonic,mode.dwell))parts.dwell=-w.dwell*(phrase.strong?2:1);
  return {cost:Object.values(parts).reduce((a,b)=>a+b,0),parts};
}
// A mode's path through the register: from the tonic (qarar) up toward the ghammaz by the middle of the phrase, above it
// at the peak, and back to the tonic by the end ('arch'); down from the upper tonic ('descending'); or up from the tonic
// to rest on the ghammaz ('ascending', the seyir's first rise, where a phrase ends on its ghammaz).
function pathTarget(mode,position,middle,range){
  const tonic=middle-modulo(middle-mode.tonic,12)+(modulo(middle-mode.tonic,12)>6?12:0),ghammaz=tonic+(mode.ghammaz??7);
  if(mode.path==='descending')return tonic+12*(1-position)**1.5;
  if(mode.path==='ascending')return tonic+(ghammaz-tonic)*Math.sin(Math.PI/2*Math.min(1,position/.8));
  const peak=ghammaz+2,rise=position<.6?position/.6:1-(position-.6)/.4;
  return tonic+(peak-tonic)*Math.sin(Math.PI/2*rise);
}

// Maqamat (the quarter-tone vocabulary's, harmonic-levels.js QUARTER_TONE_MAQAM_LEVELS), their notes above the qarar in
// semitones: the ghammaz (the note the upper jins begins on, the phrase's first resting place above the qarar), the
// notes inflected going down (rast's B half-flat is B flat descending, as its upper jins turns nahawand; nahawand's B
// natural, its upper hijaz, is B flat descending, its upper kurd), and where phrases rest, as commonly taught (maqam
// practice: Marcus 1992; Touma 1996). The path is the seyir's commonest shape, from the qarar up to the ghammaz and
// back; saba descends toward its qarar.
export const MAQAM_CONTOURS=Object.freeze({
  rast:{scale:[0,2,3.5,5,7,9,10.5],ghammaz:7,down:{10.5:10},rests:[0,7]},
  bayati:{scale:[0,1.5,3,5,7,8,10],ghammaz:5,rests:[0,5]},
  hijaz:{scale:[0,1,4,5,7,8,10],ghammaz:5,rests:[0,5]},
  nahawand:{scale:[0,2,3,5,7,8,11],ghammaz:7,down:{11:10},rests:[0,7]},
  kurd:{scale:[0,1,3,5,7,8,10],ghammaz:5,rests:[0,5]},
  ajam:{scale:[0,2,4,5,7,9,11],ghammaz:7,rests:[0,4,7]},
  saba:{scale:[0,1.5,3,4,7,8,10],ghammaz:3,rests:[0,3],path:'descending'},
});
// A maqam's contour on a tonic (pitch class): its notes going up, going down (inflected), where it rests, what it dwells
// on (the ghammaz), and its path.
export function maqamContour(name,tonic){
  const maqam=MAQAM_CONTOURS[name];if(!maqam)return null;
  const down=maqam.down??{},descending=maqam.scale.map(pc=>down[pc]??pc);
  return {kind:'maqam',name,tonic:modulo(tonic,12),ascending:[...maqam.scale],descending,rests:maqam.rests,ghammaz:maqam.ghammaz,dwell:[maqam.ghammaz],path:maqam.path??'arch'};
}

// Hindustani ragas, above Sa in semitones: the aroha (the notes going up) and avaroha (going down), which differ where
// a note is left out one way (Yaman's Pa and Sa going up, Khamaj's Re) or inflected (Khamaj's Ni, natural going up and
// komal going down), the vadi and samvadi (the notes dwelt on most), and the nyas (where phrases rest), as Bhatkhande's
// system commonly gives them (Jairazbhoy 1971; Bor 1999); traditions differ on some. In equal temperament: a raga's own
// intonation (Bhairav's komal re and dha, lower than equal; Darbari's oscillating ga and dha) is left to measured data.
export const RAGA_CONTOURS=Object.freeze({
  yaman:{aroha:[11,2,4,6,9,11,0],avaroha:[0,11,9,7,6,4,2],vadi:4,samvadi:11,nyas:[4,7,2]},
  bhairav:{aroha:[0,1,4,5,7,8,11],avaroha:[0,11,8,7,5,4,1],vadi:8,samvadi:1,nyas:[8,1,0]},
  bhairavi:{aroha:[0,1,3,5,7,8,10],avaroha:[0,10,8,7,5,3,1],vadi:5,samvadi:0,nyas:[5,0,7]},
  todi:{aroha:[0,1,3,6,8,11],avaroha:[0,11,8,7,6,3,1],vadi:8,samvadi:3,nyas:[8,3,1]},
  kafi:{aroha:[0,2,3,5,7,9,10],avaroha:[0,10,9,7,5,3,2],vadi:7,samvadi:0,nyas:[7,5,0]},
  bhupali:{aroha:[0,2,4,7,9],avaroha:[0,9,7,4,2],vadi:4,samvadi:9,nyas:[4,7,0]},
  khamaj:{aroha:[0,4,5,7,9,11],avaroha:[0,10,9,7,5,4,2],vadi:4,samvadi:10,nyas:[4,7,0]},
  darbari:{aroha:[0,2,3,5,7,8,10],avaroha:[0,8,10,7,5,3,2],vadi:2,samvadi:7,nyas:[2,7,0]},
});
export function ragaContour(name,tonic){
  const raga=RAGA_CONTOURS[name];if(!raga)return null;
  return {kind:'raga',name,tonic:modulo(tonic,12),ascending:[...raga.aroha],descending:[...raga.avaroha],rests:raga.nyas,dwell:[raga.vadi,raga.samvadi],ghammaz:raga.samvadi,path:'arch'};
}
// The raga whose notes (aroha and avaroha together) best match a collection heard (pitch classes), on the tonic that
// matches: {name, tonic}, or null where none holds the collection with at most two of its own notes unheard.
export function ragaFor(collection,{tonic=null}={}){
  let best=null;
  for(const [name,raga] of Object.entries(RAGA_CONTOURS))for(let root=0;root<12;root++){
    if(tonic!==null&&root!==modulo(tonic,12))continue;
    const notes=[...new Set([...raga.aroha,...raga.avaroha])].map(pc=>modulo(root+pc,12));
    const missing=collection.filter(pc=>!among(pc,notes)).length,extra=notes.filter(pc=>!among(pc,collection)).length;
    if(missing||extra>2)continue;
    if(!best||extra<best.extra)best={name,tonic:root,extra};
  }
  return best&&{name:best.name,tonic:best.tonic};
}
