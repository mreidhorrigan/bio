// Cuts in the mix, asked for by bots: the whole mix, or groups of the band, silenced for a span and whole again on the
// beat, reverb and all. The user, 26 September 2026: "6. Submix and whole-mix cuts -- for example, heavy rock mixes
// (think Linkin Park) sometimes cut whole sections of a mix, reverb and all, at drastic section transitions."
//
// A bot asks with /agent/cut {what, seconds, inSeconds, returns, why}:
//   what       'all', the whole mix; 'band', every group but the lead (the band drops out under the voice: a singer where
//              one sings, else the instrumental lead); or a list of groups (experiments/mix-desk/submix.js SUBMIX.groups:
//              drums, bass, keys, lead, texture, vocal)
//   seconds    how long (MIX_CUTS.shortestSeconds to longestSeconds)
//   inSeconds  from how long after the tick it is sent on (0: that tick, as its notes are heard)
//   returns    true (the default): every shared effect's return cut with it, the reverbs' and echoes' tails and all;
//              false, only the channels (their sends with them, so nothing new rings)
//   bar, why   the bar it ends on and the bot's reason, for the log
// The desk's side (MixCuts) finds the channels of what is named by the roles their bots play -- a split kit's drums among
// the drums -- and cuts them at their heads (audio-mixer.js cut), so neither they nor their sends sound, as if their audio
// were edited out: silent from the moment asked, whole again when the cut ends, each edge the mixer's shortest ramp. The
// host gives the moment: a render the tick's own time (render time plus its lookahead, where the tick's notes land), a
// page its clock's.
import {SUBMIX,submixGroup} from '../../experiments/mix-desk/submix.js';

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const MIX_CUTS=Object.freeze({
  // The shortest and the longest cut (ours: under a sixteenth at 300 bpm is a click, not a cut; a cut longer than a
  // long bar is a rest, the players' to take).
  shortestSeconds:.05,longestSeconds:8,
  // The furthest ahead a cut may be asked for (ours: two long bars).
  furthestSeconds:16,
  // The groups a lead can be, the voice first: what 'band' leaves playing is the first of them the band has (a singer
  // where one sings, the instrumental lead dropping out with the band under it; else the instrumental lead).
  leadGroups:Object.freeze(['vocal','lead']),
});

// ---- Arithmetic ------------------------------------------------------------------------------------------------------
// The lead a mixer's band has: the first of the lead groups any of its channels plays, else none.
export function leadOf(mixer,{submix=SUBMIX,choices=MIX_CUTS}={}){
  const played=new Set;for(const track of mixer?.tracks?.values?.()??[])if(!track.bus)played.add(submixGroup(track.role,submix));
  return choices.leadGroups.find(group=>played.has(group))??null;
}
// The groups a request names, or null when it names none that exist. The band is every group but its lead (`leader`,
// where the band is known: leadOf), or, not knowing it, but every group a lead can be.
export function cutGroups(what,{groups=SUBMIX.groups,choices=MIX_CUTS,leader}={}){
  const all=Object.keys(groups);
  if(what==='all')return all;
  if(what==='band')return all.filter(group=>leader===undefined?!choices.leadGroups.includes(group):group!==leader);
  const named=(Array.isArray(what)?what:[what]).map(String).filter(group=>all.includes(group));
  return named.length?[...new Set(named)]:null;
}
// The mixer's channels a request names (buses aside: they hold the channels). The whole mix is every channel, whatever
// it plays or whether its role is known yet (a clip, a bot just joined); the band, every channel but the lead's; groups,
// the channels whose bots play their roles.
export function cutChannels(mixer,what,{submix=SUBMIX,choices=MIX_CUTS}={}){
  const leader=leadOf(mixer,{submix,choices}),groups=cutGroups(what,{groups:submix.groups,choices,leader});
  if(!groups)return [];
  const wanted=new Set(groups),ids=[];
  for(const [id,track] of mixer.tracks){
    if(track.bus)continue;
    const group=submixGroup(track.role,submix);
    if(what==='all'||what==='band'&&group!==leader||group!==null&&wanted.has(group))ids.push(id);
  }
  return ids;
}

// ---- The desk's side -------------------------------------------------------------------------------------------------
export class MixCuts {
  constructor(mixer,{log=null,choices=MIX_CUTS}={}){
    if(!mixer||typeof mixer.cut!=='function')throw new TypeError('MixCuts needs the mixer (EnsembleMixer)');
    this.mixer=mixer;this.log=log;this.choices=choices;this.cuts=[];
  }
  // A request, at `start` (context seconds: when the tick it was sent on is heard). Returns what was cut, or why not.
  request(request,{start,source=null}={}){
    const choices=this.choices,refuse=why=>{const record={kind:'cut',refused:why,source,request};this.log?.(record);return record};
    if(!request||typeof request!=='object')return refuse('a cut is {what, seconds}');
    const seconds=Number(request.seconds),inSeconds=Number(request.inSeconds??0);
    if(!Number.isFinite(seconds)||seconds<choices.shortestSeconds||seconds>choices.longestSeconds)
      return refuse(`a cut lasts ${choices.shortestSeconds} to ${choices.longestSeconds} seconds, not ${request.seconds}`);
    if(!Number.isFinite(inSeconds)||inSeconds<0||inSeconds>choices.furthestSeconds)return refuse(`a cut begins 0 to ${choices.furthestSeconds} seconds ahead`);
    if(!Number.isFinite(start))return refuse('the host has no time for it');
    const what=request.what??'all',groups=cutGroups(what,{choices,leader:leadOf(this.mixer,{choices})});
    if(!groups)return refuse(`nothing called ${JSON.stringify(request.what)} to cut`);
    const channels=cutChannels(this.mixer,what,{choices}),returns=request.returns!==false;
    const from=start+inSeconds,until=from+seconds;
    if(!channels.length&&!returns)return refuse('no channel of those groups is playing');
    this.mixer.cut(channels,{from,until,returns});
    const record={kind:'cut',what,groups,channels,from:+from.toFixed(4),until:+until.toFixed(4),returns,source,
      ...(Number.isFinite(Number(request.bar))?{bar:Number(request.bar)}:{}),...(request.why?{why:String(request.why)}:{})};
    this.cuts.push(record);this.log?.(record);
    return record;
  }
}
