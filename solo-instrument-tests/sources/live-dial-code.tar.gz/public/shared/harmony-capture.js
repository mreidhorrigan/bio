// The pools a bot believed in while it played, kept beside the capture of what it played, in the same clock. A host
// tells it the bot's pool with every batch of notes it captures, stamped with THAT BATCH's time: notes are scheduled
// ahead of the moment they are chosen, so stamping a change of harmony with the moment a message arrived would file
// the last notes chosen under the old chord as the first notes of the new one. It is cheap -- nothing is recorded
// unless the pool changed. At the phrase boundary `flush` takes the same start and scale UmpMotifCapture used for the
// notes, so a note and the harmony under it cannot drift apart.
export class HarmonyCapture {
  constructor(limit=256){this.limit=Math.max(8,Math.trunc(limit));this.changes=[];this.current=null}
  observe(pool,seconds){
    const values=(Array.isArray(pool)?pool:[]).map(Number).filter(Number.isFinite);
    if(!values.length||!Number.isFinite(seconds))return false;
    const key=values.join(',');if(key===this.current)return false;
    this.current=key;this.changes.push({seconds,pool:values});
    if(this.changes.length>this.limit)this.changes.shift();
    return true;
  }
  // Segments for a capture that began at `startSeconds`, at `ticksPerSecond`. The harmony already in force when the
  // capture began is its first segment, at tick 0. What comes after the capture stays for the next one.
  flush(startSeconds,ticksPerSecond,endSeconds=Infinity){
    if(!Number.isFinite(startSeconds)||!(ticksPerSecond>0))return [];
    const segments=[];
    for(const change of this.changes){
      if(change.seconds>endSeconds)break;
      const time=Math.max(0,Math.round((change.seconds-startSeconds)*ticksPerSecond));
      if(segments.length&&segments.at(-1).time===time)segments[segments.length-1]={time,pool:change.pool};
      else if(!segments.length||segments.at(-1).pool.join(',')!==change.pool.join(','))segments.push({time,pool:change.pool});
    }
    // Keep only the harmony still in force: the next capture begins under it.
    const last=this.changes.at(-1);this.changes=last?[last]:[];
    return segments;
  }
}
