// A timpanist's drums, pedals and sticks (the family atlas's F31, orchestral and kit membranes: the timpani; a kit's drums
// are the drummer's), planned through the performer contract's one solver (contract.js searchGroups), as the mallets, the
// kalimba, the steelpan and the piano are. Taken by 2a at c2's word, 29 September (SESSIONS.md 10:32).
//
// **Drums tuned by their pedals.** A set of drums, each with its range (a fifth to a sixth), tuned to any pitch within it
// by its pedal, so a pitch between two keys is the instrument's own; a pitch outside every drum's range is refused,
// never moved an octave. A retune takes time (TIMPANI.pedal: a settling time, and a time a semitone), is made by one of
// the player's two feet, on a drum that has stopped sounding (its note's end: the player muffles it, or it has rung
// out; a glissando, the pedal moved while it rings, is not modelled yet), and the drum is not struck until it is done.
//
// **Two sticks.** One in each hand; a stick strikes again once its stroke has recovered (TIMPANI.strokeSeconds), and a
// hand moves between the drums' beating spots at TIMPANI.handMmPerSecond from where its stick left (its stroke; a roll's
// end, the sticks on the drum till then). Two drums may be struck at once, a stick each (a double stop). A note held
// longer than its drum rings is rolled, the two sticks alternating on it at TIMPANI.rollHz to its end.
//
// **Glissandi.** A note may be struck at one pitch and slide to its own as a foot moves the drum's pedal while it rings
// (`glideFrom`, over `glide` seconds): the drum stands at the first pitch when it is struck, reaches both, and its
// pedal moves no faster than its travel allows (TIMPANI.pedal.perSemitone, without the settling a retune takes); the
// drum ends at the note's pitch.
//
// **What is not modelled yet**, and says so: muffling as a motion of its own, the hands crossing over one another, the
// beating spot's place on the head (its timbre), and the kinds of stick.
import {action,checkReservations,profile,searchGroups,STATUS,witness} from './contract.js';
import {instrumentRange} from './instrument-ranges.js';

const drum=(inches,x)=>Object.freeze({id:`T${inches}`,inches,range:instrumentRange(`timpani-yamaha-${inches}`).range,x});

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const TIMPANI=Object.freeze({
  // The drums, low to high: each one's pedal range (MIDI: the instrument registry's, instrument-ranges.js, from a maker's
  // manual) and where its beating spot lies (mm from the player's middle, the low drums to the left as the American setup
  // has them; authored, the spots a hand's reach apart along the arc). The common set's four, the 32", 29", 26" and 23"
  // drums, a fifth to a sixth each and overlapping, and the 20" piccolo drum a spec may add (`drums: 'five'`).
  drums:Object.freeze([
    drum(32,-675),drum(29,-225),drum(26,225),drum(23,675),
  ]),
  piccolo:drum(20,1100),
  // A pedal's retune: settleSeconds, and perSemitone for each semitone it moves (authored).
  pedal:Object.freeze({settleSeconds:.3,perSemitone:.06}),
  // A stick's stroke (s: about ten a second from one hand), a hand's travel between the beating spots (mm a second), and
  // a roll's strokes a second between both sticks (authored).
  strokeSeconds:1/10,handMmPerSecond:3000,rollHz:12,
  // How long a drum rings (s) at the lowest drum and at the highest (ours, from the recordings' audible lengths at mf to f,
  // 2 to 5 s, download-timpani-samples.mjs).
  ringSeconds:Object.freeze([4,2.5]),
  // A drum sounds a pitch within this (semitones); notes starting within `together` of each other are one group (s).
  tolerance:.05,together:.005,
  // Costs, authored: each millimetre a hand travels, each semitone a pedal moves.
  cost:Object.freeze({travelPerMm:.001,retunePerSemitone:.05}),
  // The search's states: its drums' and hands' times make nearly every path a state of its own, so past maxStates a
  // group keeps its `beam` cheapest (contract.js searchGroups: a path found so is a witness, marked pruned).
  maxStates:4096,beam:1024,
});

// ---- The instrument --------------------------------------------------------------------------------------------------
// A set of drums: 'four' (the common set), 'five' (with the piccolo drum), or a list of drums ({id, range, x}).
export function timpaniSet({drums='four',choices=TIMPANI}={}){
  const list=Array.isArray(drums)?drums:drums==='four'?choices.drums:drums==='five'?[...choices.drums,choices.piccolo]:null;
  if(!list?.length)throw new RangeError('a timpani set is four, five or a list of drums');
  return Object.freeze(list.map(drum=>Object.freeze({id:String(drum.id),range:Object.freeze([Number(drum.range[0]),Number(drum.range[1])]),x:Number(drum.x)||0,...(drum.inches?{inches:drum.inches}:{})})));
}
// The drums that can sound a pitch (its range holds it), low to high.
export const drumsFor=(set,pitch,{choices=TIMPANI}={})=>set.filter(drum=>pitch>=drum.range[0]-choices.tolerance&&pitch<=drum.range[1]+choices.tolerance);
// A pedal's retune from one pitch to another (s); none where the drum is at it already, or has not yet been tuned.
export function retuneSeconds(from,to,{choices=TIMPANI}={}){
  if(from===null||from===undefined||Math.abs(from-to)<=choices.tolerance)return 0;
  return choices.pedal.settleSeconds+choices.pedal.perSemitone*Math.abs(to-from);
}
// How long a drum rings (s), by where it stands in the set.
export const ringOf=(set,drum,{choices=TIMPANI}={})=>{
  const [low,high]=choices.ringSeconds,index=set.findIndex(each=>each.id===(drum.id??drum)),t=set.length>1?Math.max(0,index)/(set.length-1):0;
  return low+(high-low)*t;
};
// Whether a stick reaches a drum's spot (x, mm) to strike it at `at` (s): recovered by then, and its hand across in
// time from when the stick left its last drum. `last` is {x, from, free}, or null (a stick not yet used).
export const stickReaches=(last,x,at,{choices=TIMPANI}={})=>!last||at>=last.free-1e-9&&Math.abs(x-last.x)<=choices.handMmPerSecond*Math.max(0,at-last.from)+1e-9;

// ---- The player ------------------------------------------------------------------------------------------------------
// A timpanist's profile: two hands (LH, RH), a stick each (LH.1, RH.1), and two feet (LF, RF) for the pedals, each drum's
// pedal a mechanism of its own (P.<drum>). `unavailable` names any of them.
export function timpanist({id='timpanist',performer='timpanist',set=timpaniSet(),unavailable=[],evidence='authored'}={}){
  const state=name=>unavailable.includes(name)?'unavailable':'available',resources=[];
  for(const hand of ['LH','RH']){
    resources.push({id:hand,kind:'body',availability:state(hand),evidence});
    resources.push({id:`${hand}.1`,kind:'effector',parents:[hand],availability:unavailable.includes(hand)?'unavailable':state(`${hand}.1`),evidence});
  }
  for(const foot of ['LF','RF'])resources.push({id:foot,kind:'effector',availability:state(foot),evidence});
  for(const drum of set)resources.push({id:`P.${drum.id}`,kind:'mechanism',availability:'available',evidence});
  return profile({id,performer,resources});
}
const sticksOf=who=>['LH','RH'].filter(hand=>who.resources.get(`${hand}.1`)?.availability==='available');
const feetOf=who=>['LF','RF'].filter(foot=>who.resources.get(foot)?.availability==='available');

// ---- Passages --------------------------------------------------------------------------------------------------------
// Plan a passage [{pitch, start, end, rolled?, glideFrom?, glide?}] on a set of drums: which drum sounds each note,
// tuned by its pedal in time (a foot free for it, after the drum's last note ends; a glissando's drum at its first pitch,
// a foot moving its pedal through the glide), which stick strikes it (both, rolled, where it outlasts its drum's ring
// or says `rolled`), never faster than a stick recovers or a hand crosses the arc. `tuning` is where the
// drums stand as it begins ({drum id: pitch}; a drum not named is tuned for its first note before the passage).
// -> {status, path?, cost?, witness?, reason?}; refused (unknown) where a pitch lies outside every drum's range.
export function planTimpani(input,{set=timpaniSet(),who=timpanist({set}),tuning={},choices=TIMPANI}={}){
  if(!input.length)return {status:STATUS.witness,path:[],cost:0};
  const notes=input.map((note,index)=>({...note,id:note.id??`n${index}`}));
  for(const note of notes){
    if(!(note.end>note.start))throw new RangeError(`note ${note.id}: a positive duration`);
    note.sliding=Number(note.glide)>0&&Number.isFinite(Number(note.glideFrom))&&Math.abs(note.glideFrom-note.pitch)>choices.tolerance;
    // (A glissando's drum reaches both its pitches, its pedal moving no faster than its travel.)
    note.drums=drumsFor(set,note.pitch,{choices}).filter(drum=>!note.sliding||drumsFor([drum],note.glideFrom,{choices}).length);
    if(!note.drums.length)return {status:STATUS.unknown,reason:`pitch ${note.pitch}${note.sliding?` from ${note.glideFrom}`:''} lies outside every drum's range`};
    if(note.sliding&&note.glide<choices.pedal.perSemitone*Math.abs(note.pitch-note.glideFrom)-1e-9)return {status:STATUS.unknown,reason:`a glide of ${note.glide} s is faster than a pedal moves from ${note.glideFrom} to ${note.pitch}`};
  }
  const groups=[];
  for(const note of [...notes].sort((a,b)=>a.start-b.start||a.pitch-b.pitch)){const last=groups.at(-1);if(last&&note.start-last.at<=choices.together)last.notes.push(note);else groups.push({at:note.start,notes:[note]})}
  const hands=sticksOf(who),feet=feetOf(who);
  // The state: each drum's pitch, when it can be struck (a retune's end) and when its last note ends; each stick's place
  // and times; each foot's free time.
  const initial={drums:Object.fromEntries(set.map(drum=>[drum.id,{pitch:Number.isFinite(tuning[drum.id])?tuning[drum.id]:null,ready:-Infinity,end:-Infinity}])),sticks:{LH:null,RH:null},feet:{LF:-Infinity,RF:-Infinity}};
  const round=value=>Number.isFinite(value)?Math.round(value*1000)/1000:null;
  const stateKey=state=>JSON.stringify([set.map(drum=>{const d=state.drums[drum.id];return [round(d.pitch),round(d.ready),round(d.end)]}),
    ['LH','RH'].map(hand=>state.sticks[hand]?[Math.round(state.sticks[hand].x),round(state.sticks[hand].from),round(state.sticks[hand].free)]:null),[round(state.feet.LF),round(state.feet.RF)]]);
  // Each way to give a group's notes to distinct drums.
  const assignments=list=>{const out=[];const walk=(k,chosen)=>{if(k===list.length){out.push([...chosen]);return}for(const drum of list[k].drums)if(!chosen.some(each=>each.id===drum.id)){chosen.push(drum);walk(k+1,chosen);chosen.pop()}};walk(0,[]);return out};
  const expand=(group,state)=>{
    const moves=[],count=group.notes.length;
    if(count>2)return moves;
    for(const drums of assignments(group.notes)){
      const rolled=group.notes.some((note,k)=>note.rolled??note.end-note.start>ringOf(set,drums[k],{choices})+1e-9);
      let ok=true,cost=0;const next={drums:{...state.drums},sticks:{...state.sticks},feet:{...state.feet}},retunes=[];
      // Each drum tuned to its note in time: a foot free for the pedal after the drum's last note ends.
      for(const [k,note] of group.notes.entries()){
        // (A glissando is struck at its first pitch: its drum tuned there first.)
        const drum=drums[k],d=state.drums[drum.id],struck=note.sliding?note.glideFrom:note.pitch,seconds=retuneSeconds(d.pitch,struck,{choices});let ready=d.ready;
        if(d.ready>group.at+1e-9){ok=false;break}
        if(seconds>0){
          const foot=feet.map(each=>({foot:each,start:Math.max(next.feet[each],d.end,d.ready)})).sort((a,b)=>a.start-b.start)[0];
          if(!foot||foot.start+seconds>group.at+1e-9){ok=false;break}
          next.feet[foot.foot]=foot.start+seconds;ready=foot.start+seconds;retunes.push({drum:drum.id,foot:foot.foot,from:d.pitch,to:struck,start:foot.start,end:ready});
          cost+=choices.cost.retunePerSemitone*Math.abs(struck-d.pitch);
        }
        // A glissando's pedal moved by a foot free at the stroke, through the glide.
        if(note.sliding){
          const foot=feet.find(each=>next.feet[each]<=group.at+1e-9);
          if(!foot){ok=false;break}
          next.feet[foot]=group.at+note.glide;retunes.push({drum:drum.id,foot,from:note.glideFrom,to:note.pitch,start:group.at,end:group.at+note.glide,glissando:true});
        }
        next.drums[drum.id]={pitch:note.pitch,ready,end:note.end};
      }
      if(!ok)continue;
      // Its sticks: a single note by either stick, or (rolled) by both; a double stop a stick each, both ways.
      const ways=count===1?(rolled?(hands.length===2?[{LH:0,RH:0}]:[]):hands.map(hand=>({[hand]:0})))
        :hands.length===2?[{LH:0,RH:1},{LH:1,RH:0}]:[];
      for(const way of ways){
        let fine=true,travel=0;const sticks={...next.sticks},strokes=[];
        for(const hand of ['LH','RH']){
          if(way[hand]===undefined)continue;
          const note=group.notes[way[hand]],drum=drums[way[hand]],before=sticks[hand];
          if(!stickReaches(before,drum.x,group.at,{choices})){fine=false;break}
          travel+=before?Math.abs(drum.x-before.x):0;
          const end=rolled?Math.max(...group.notes.map(each=>each.end)):group.at+choices.strokeSeconds;
          sticks[hand]={x:drum.x,from:rolled?end:group.at,free:end};
          strokes.push({note:note.id,pitch:note.pitch,drum:drum.id,hand,rolled});
        }
        if(fine)moves.push({status:'supported',cost:cost+travel*choices.cost.travelPerMm,state:{...next,sticks},step:{at:group.at,strokes,retunes}});
      }
    }
    return moves;
  };
  const found=searchGroups(groups,{initial,expand,stateKey,maxStates:choices.maxStates,beam:choices.beam});
  if(found.status!==STATUS.witness)return {status:found.status,reason:found.group?`no drum and stick play the group at ${found.group.at} s (${found.group.notes.map(note=>note.pitch).join(', ')})`:null};
  return {status:STATUS.witness,path:found.path,cost:+found.cost.toFixed(6),...(found.pruned?{pruned:true}:{}),witness:timpaniWitness(who,notes,found.path,{choices})};
}
// The witness: each stroke its stick's reservation for its recovery (a roll's for its note), at its drum; each retune its
// foot's and its pedal's, checked by the contract.
function timpaniWitness(who,notes,path,{choices=TIMPANI}={}){
  const actions=[],byId=new Map(notes.map(note=>[note.id,note]));
  for(const [k,step] of path.entries()){
    for(const [r,retune] of step.retunes.entries())actions.push(action({id:`${retune.glissando?'glissando':'retune'}:${k}:${r}`,technique:retune.glissando?'glissando':'retune',contacts:[],
      reservations:[{resource:retune.foot,phase:'prepare',start:retune.start,end:retune.end,configuration:`pedal:${retune.drum}`},
        {resource:`P.${retune.drum}`,phase:'prepare',start:retune.start,end:retune.end,configuration:`to:${retune.to}`}]}));
    for(const stroke of step.strokes){
      const note=byId.get(stroke.note),end=stroke.rolled?Math.max(...step.strokes.map(each=>byId.get(each.note).end)):note.start+choices.strokeSeconds;
      actions.push(action({id:`${stroke.rolled?'roll':'stroke'}:${k}:${stroke.hand}`,technique:stroke.rolled?'roll':'stroke',contacts:[stroke.note],contactSeconds:[note.start],
        reservations:[{resource:`${stroke.hand}.1`,phase:stroke.rolled?'hold':'excite',start:note.start,end,configuration:`${stroke.hand}@${stroke.drum}`}]}));
    }
  }
  return witness({who,actions,checks:[{id:'timpani-sticks-and-pedals',evidence:'authored',...checkReservations(who,actions)},{id:'muffling',status:STATUS.unknown}]});
}
