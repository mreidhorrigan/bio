// A wind player's Performer for a written part: MusicXML in, MIDI 2.0 out (docs/MUSEBOTS_3_SPECIFICATION.md, "Function
// classes": "Performer functions ingest MusicXML and generate MIDI 2.0"), so that a musebot plays existing music -- on
// the winds' dial (native/openwind/dial-midi2.mjs, which plays any wind player's MIDI 2.0) or on any winds synth. The
// file is read as the Engraver reads it (notation/musicxml-read.js), and each choice it leaves open is the player's,
// drawn from its seed where nothing else decides it (CLAUDE.md, "No musical default written"):
//   - its time: the score's tempo marks as heard (a mark's sound, else its metronome; a metric modulation's equivalence
//     where it shows no tempo; a ramp's word and line, accel. or rit., moving evenly in seconds a quarter to the tempo
//     it arrives at, where the file gives no steps of its own), as a timing map (timing-map.js); with none at its
//     start, a tempo for its first meter drawn from the seed as the band's opening's is (opening-time.js tempoFor). A
//     fermata holds its note RUBATO_PLAN.fermataBeats felt beats longer (rubato-plan.js, the conductor's fermata; the
//     felt beat meter-tactus.js's), one hold for every part's fermatas at a place. A note's own timing against the page
//     (its attack and release attributes) moves its ends;
//   - its notes: one line, as one player plays it -- its voices' notes in the order they begin, a chord's top note, a
//     note begun ending the one before; tied notes one note; a transposing part sounding as its <transpose> says;
//   - its articulation, its tongue's: a note slurred to the note before under a slur; a staccato's, tenuto's or
//     staccatissimo's under a slur legato-tongued (portato); a staccato note held its written length less the silence
//     players leave between staccato notes at its length (Pàmies-Vilà, Hofmann and Chatziioannou 2018: the registry's
//     tongue.staccato.silence, at the measured lengths, and held at the same share of the note beyond them); a breath
//     mark's note giving up a breath at its end (WIND_LINE.breathRest, no more than WIND_LINE.shortenMost of it); its
//     tongue's attack the wind seat's (wind-seat.js BREATH: tongued by its dynamic, a slur's, a legato tongue's);
//   - its dynamics: a note's own (its dynamics attribute: the performance the file was written from) else the mark it
//     falls under, an accent a mark louder, a marcato two; a hairpin its notes' dynamics moving evenly in time to the
//     mark it arrives at, or a mark on from where it began, each note's swell through it as it moves; sf, sfz, fz, rf,
//     sffz on the note they stand at, fp and its kin loud on it and soft after (ours); with no mark before its first
//     note, a dynamic drawn from the seed among the scored marks;
//   - its technique: the words that name one -- flz., hum or sing, growl -- held until words return it (ord., nat.) or,
//     written with a line, through the line's last note; each one's parameters drawn as a pool's are (techniques.js
//     windTechniqueOf), as far as its first note's dynamic reaches from the middle.
// What it does not play is said in `warnings`: grace notes, glissandi, multiphonics, a mute's words, a chord's lower
// notes, notes outside the compass given, voices sounding at once. Its breathing is the score's (its rests and breath
// marks): a phrase that outlasts a breath is not broken by one of its own yet.
//
//   performMusicXML(text or score, {part, seed, compass, instrument, group, channel})
//     -> {notes, events, warnings, seconds, map, drawn}: each note {at, note, seconds, velocity, slurred?, portato?,
//        phrased, performance: {attackSeconds, pressureCurve?}, extended?, measure, events}, its events its MIDI 2.0
//        (wind-midi2.js windNoteEvents) at their seconds from the piece's start; events, all of them in order; map, its
//        time (scoreTiming's); drawn, what its seed chose where the file wrote nothing: {tempo, dynamic}, each or null
//   scoreTiming(score, {seed}) -> {map (TimingMap, in quarters), drawn: the tempo drawn where none was written, or null}
//   PerformanceFeed(notes, {start, lead}): due(now) -> the events of each note whose onset falls within `lead` s of `now`
//     on its synthesizer's clock, whole, as a musebot sends its line ahead (dial-midi2.js DialMidi2.take)
import {musicXMLToScore} from '../../notation/musicxml-read.js';
import {Rational} from '../../transcript/rational.js';
import {TimingMap,secondsPerQuarter,positionKey} from '../timing-map.js';
import {ratio} from '../rhythm-vocabulary.js';
import {tempoFor,DEFAULT_SEED} from '../opening-time.js';
import {DYNAMICS,MARKS,markVelocity,dynamicOf,scoredDynamicOf} from '../dynamics.js';
import {createRandomStream} from '../../random-source.js';
import {feltBeats} from '../meter-tactus.js';
import {RUBATO_PLAN} from '../rubato-plan.js';
import {WIND_LINE} from './wind-line.js';
import {windTechniqueOf,windTechniqueAt} from './techniques.js';
import {windNoteEvents} from './wind-midi2.js';
import {BowedIdentities} from './bowed-midi2.js';
import {BREATH} from '../../bots/lib/modules/wind-seat.js';
import {player} from '../../../registry/registry.js';

// Definitions.
// Quarters in a whole note; a dot's worth.
const QUARTERS=4,DOTTED=1.5;
// The words that name a wind technique (techniques.js WIND_TECHNIQUE_WORDS among them, and as wind writing names them),
// those that return a player to its ordinary playing, and a mute's (ours).
const TECHNIQUE_WORDS=Object.freeze([['flutter',/\bflz\b|flatterz|flutter|frull/i],['hum',/\bhum|\bsing\b|\bsung\b/i],['growl',/growl/i]]);
const ORDINARY=/\bord\b|ordinario|\bnat\b|naturale|\bnorm\b|normale/i,MUTED=/\bsord\b|sordin|\bmute/i;
// The dynamics a note takes as its own (ours): sforzando and its kin at least their mark, rinforzando a mark over the
// part's; fp and its kin loud on the note and soft after it; niente the bottom of the scale.
const OWN_DYNAMICS=Object.freeze({sf:{least:'f'},sfz:{least:'f'},fz:{least:'f'},sffz:{least:'ff'},rf:{up:1},rfz:{up:1},
  fp:{least:'f',then:'p'},sfp:{least:'f',then:'p'},sfpp:{least:'f',then:'pp'},sfzp:{least:'f',then:'p'},pf:{least:'p',then:'f'},n:{then:MARKS[0]}});
// Marks louder an accent and a marcato make a note (ours).
const ACCENT_MARKS=1,MARCATO_MARKS=2;
// The player whose measured staccato is borrowed where an instrument has none of its own (registry/players/winds.json).
const MEASURED_TONGUE='reed-woodwind';
// (Two times this near are one: the engine's capture's tick.)
const TICK=1/9600;

const R0=new Rational(0);
const quartersOf=whole=>ratio(QUARTERS*whole.n,whole.d);
const numberOf=whole=>whole.n/whole.d;
const lerp=(a,b,x)=>a+(b-a)*x;
// A note value's worth in quarters ({type: 4 a quarter, dots, tuplet?}: an equivalence's, musicxml-read.js).
const worth=({type,dots=0,tuplet=null})=>QUARTERS/type*(2-2**-dots)*(tuplet?tuplet.normal/tuplet.actual:1);
const markStep=(velocity,steps)=>{const k=MARKS.indexOf(dynamicOf(velocity));return markVelocity(MARKS[Math.max(0,Math.min(MARKS.length-1,k+steps))])};

// ---- time -------------------------------------------------------------------------------------------------------------
// The score's time as heard, a timing map in quarters from its start to its last measure's end: its tempo marks', its
// ramps', its fermatas' holds (see the head of the file).
export function scoreTiming(score,{seed=DEFAULT_SEED,warn=()=>{}}={}){
  const measures=score.measures,last=measures.at(-1);
  if(!last)throw new Error('musicxml-performer: a score with no measures');
  const end=last.start.add(last.length),marks=[...score.tempo].sort((a,b)=>a.start.cmp(b.start));
  // (Each change of seconds a quarter, where it is written.)
  const changes=[];let h=null;
  for(const mark of marks){
    let next=h;
    if(mark.bpm!=null)next=secondsPerQuarter(mark.bpm*(mark.dotted?DOTTED:1),mark.beatUnit);
    else if(mark.equivalence&&h!=null)next=h*worth(mark.equivalence.from)/worth(mark.equivalence.to);
    if(next!==h){changes.push({at:mark.start,h:next});h=next}
  }
  let drawn=null;
  if(!changes.length||changes[0].at.gt(R0)){
    const meter=measures[0].meter,bpm=tempoFor(meter,seed);
    drawn={bpm,denominator:meter.denominator};changes.unshift({at:R0,h:secondsPerQuarter(bpm,meter.denominator)});
  }
  const hAt=at=>changes.filter(c=>c.at.le(at)).at(-1).h;
  // (A ramp: from its word to where its line stops, to the tempo it arrives at -- the next written at or after it --
  // where the file wrote no steps between.)
  const ramps=[];
  for(const mark of marks){
    if(mark.until===undefined)continue;
    if(mark.until===null){warn(`a ${mark.words} whose line never stops: its tempo held`);continue}
    if(changes.some(c=>c.at.gt(mark.start)&&c.at.lt(mark.until)))continue;
    const target=changes.find(c=>c.at.ge(mark.until));
    if(!target){warn(`a ${mark.words} arriving at no tempo written: its tempo held`);continue}
    ramps.push({from:mark.start,to:mark.until,h0:hAt(mark.start),h1:target.h});
  }
  const rampAt=(a,b)=>ramps.find(r=>r.from.le(a)&&b.le(r.to));
  const hIn=(ramp,at)=>lerp(ramp.h0,ramp.h1,numberOf(at.sub(ramp.from))/numberOf(ramp.to.sub(ramp.from)));
  // (Every part's fermatas, one hold at a place.)
  const held=new Map;
  for(const part of score.parts)for(const content of part.measures)for(const voice of content.voices)for(const element of voice.elements)
    if(element.fermata&&element.start.lt(end))held.set(positionKey(quartersOf(element.start)),element.start);
  const cuts=[R0,end,...changes.map(c=>c.at),...ramps.flatMap(r=>[r.from,r.to]),...held.values()].filter(at=>at.ge(R0)&&at.le(end))
    .sort((a,b)=>a.cmp(b)).filter((at,k,all)=>k===0||!at.eq(all[k-1]));
  const segments=[];
  for(let k=0;k<cuts.length-1;k++){
    const [a,b]=[cuts[k],cuts[k+1]],ramp=rampAt(a,b),seconds=ramp?[hIn(ramp,a),hIn(ramp,b)]:hAt(a);
    if(held.has(positionKey(quartersOf(a))))segments.push({kind:'hold',from:quartersOf(a),id:`fermata ${positionKey(quartersOf(a))}`,seconds:fermataSeconds(score,a,Array.isArray(seconds)?seconds[0]:seconds)});
    segments.push(ramp?{kind:'linear',from:quartersOf(a),to:quartersOf(b),seconds}:{kind:'constant',from:quartersOf(a),to:quartersOf(b),seconds});
  }
  return {map:new TimingMap({start:[0,1],segments}),drawn};
}
// A fermata's hold, s: RUBATO_PLAN.fermataBeats of the felt beat its note begins in, at `h` seconds a quarter.
function fermataSeconds(score,at,h){
  const measure=score.measures.filter(m=>m.start.le(at)).at(-1),meter=measure.meter,secondsPerTick=h*QUARTERS/meter.denominator;
  const into=numberOf(at.sub(measure.start))*meter.denominator,beats=feltBeats({...meter,subdivision:1,pulsesPerBar:undefined},{secondsPerTick});
  const beat=beats.filter(b=>b.start<=into+1e-9).at(-1)??beats[0];
  return RUBATO_PLAN.fermataBeats*beat.length*secondsPerTick;
}

// ---- notes ------------------------------------------------------------------------------------------------------------
// The part to play: by its id, its name or its index, else the first pitched part with notes.
function partOf(score,which){
  const pitched=score.parts.filter(p=>p.kind!=='percussion');
  const found=which==null?pitched.find(p=>p.measures.some(c=>c.voices.some(v=>v.elements.some(e=>!e.rest)))):
    typeof which==='number'?score.parts[which]:score.parts.find(p=>p.id===which||p.name===which);
  if(!found)throw new Error(`musicxml-performer: no part ${which??'with notes to play'}`);
  if(found.kind==='percussion')throw new Error(`musicxml-performer: part ${found.id} is a percussion part: a wind player plays a pitched one`);
  return found;
}

// A part's notes as its player plays them (see the head of the file). -> notes, each without its events.
export function partNotes(score,part,{timing,seed=DEFAULT_SEED,compass=null,instrument=null,warn=()=>{}}){
  const map=timing.map,first=numberOf(R0),last=map.end[0]/map.end[1];
  const timeOf=(whole,offset)=>offset?map.timeAt(Math.max(first,Math.min(last,QUARTERS*(numberOf(whole)+offset)))):map.timeAt(quartersOf(whole));
  const transpositions=part.transpositions??[],sounding=(pitch,at)=>pitch+(transpositions.filter(t=>t.start.le(at)).at(-1)?.semitones??0);
  const told=new Map,tell=what=>told.set(what,(told.get(what)??0)+1);
  // Each voice's notes, its ties one note, its slurs and marks read; and its hairpins and technique words.
  const raw=[],hairpins=[],words=[];
  for(const content of part.measures)for(const d of content.directions)if((d.kind==='formation'||d.kind==='words')&&typeof d.value==='string')words.push({at:d.start,text:d.value});
  const voices=new Map;
  part.measures.forEach((content,index)=>{for(const voice of content.voices){if(voice.filler)continue;
    const list=voices.get(voice.voice)??voices.set(voice.voice,[]).get(voice.voice);
    for(const element of voice.elements)list.push({element,measure:score.measures[index]?.number??index+1})}});
  for(const [key,list] of voices){
    let open=0,tied=null,hairpin=null,before=null;
    for(const {element,measure} of list){
      if(element.hairpin){if(hairpin)hairpins.push({...hairpin,to:element.start});hairpin={kind:element.hairpin,from:element.start,to:null}}
      if(element.hairpinEnd&&hairpin){hairpins.push({...hairpin,to:element.start});hairpin=null}
      if(element.techniqueSpan)words.push({at:element.start,text:element.techniqueSpan,span:true});
      if(element.techniqueText)words.push({at:element.start,text:element.techniqueText});
      if(element.techniqueSpanStop)words.push({at:element.end,stop:true});
      const slurred=open>0;
      if(element.slurStop)open=Math.max(0,open-1);
      if(element.slurStart)open++;
      if(element.rest){before=null;tied=null;continue}
      const notes=element.notes.filter(n=>n.pitch!=null);
      if(!notes.length)continue;
      if(notes.length>1)tell('a chord played as its top note');
      const note=notes.reduce((a,b)=>b.pitch>a.pitch?b:a);
      for(const n of element.notes){
        if(n.gracesBefore?.length||n.gracesAfter?.length||n.graceFrom||n.graceTo)tell('grace notes not played');
        if(n.glissando||n.slideStart||n.slideStop)tell('a glissando played as its notes');
        if(n.multiphonic)tell('a multiphonic played as its written note');
      }
      const pitch=sounding(note.pitch,element.start);
      // (Tied from the note before, at its pitch: that note held on.)
      if(tied&&element.tieStop&&Math.abs(tied.pitch-pitch)<1e-6){
        tied.end=element.end;tied.releaseWhole=note.releaseWhole??0;tied.fermata||=Boolean(element.fermata);tied.breathMark=Boolean(note.breathMark);
        tied=element.tieStart?tied:null;continue;
      }
      const marked=Boolean(note.staccato||element.staccatissimo||element.tenuto),under=slurred||Boolean(element.slurStart);
      const made={voice:key,measure,start:element.start,end:element.end,pitch,attackWhole:note.attackWhole??0,releaseWhole:note.releaseWhole??0,
        own:note.velocity??null,joined:slurred&&before!=null,portato:under&&marked,staccato:!under&&Boolean(note.staccato||element.staccatissimo),
        accent:element.marcato?MARCATO_MARKS:element.accent?ACCENT_MARKS:0,breathMark:Boolean(note.breathMark)};
      if(element.staccatissimo&&!under)tell('staccatissimo played as staccato (no measurement of its own)');
      raw.push(made);before=made;tied=element.tieStart?made:null;
    }
    if(hairpin)hairpins.push(hairpin);
  }
  // One line: in the order they begin, the higher first; one at a place, a note begun ending the one before.
  raw.sort((a,b)=>a.start.cmp(b.start)||b.pitch-a.pitch);
  const line=[];
  for(const n of raw){
    const previous=line.at(-1);
    if(previous&&n.start.eq(previous.start)){tell('voices at once played as their top note');continue}
    if(previous&&n.start.lt(previous.end)){
      if(n.voice!==previous.voice)tell('voices at once played as one line');
      previous.end=n.start;previous.releaseWhole=0;
    }
    line.push(n);
  }
  for(const n of line){n.at=timeOf(n.start,n.attackWhole);n.written=Math.max(TICK,timeOf(n.end,n.releaseWhole)-n.at)}
  // Dynamics: the marks, each hairpin's arrival among them, and each note's.
  const marks=[];
  for(const content of part.measures)for(const d of content.directions)if(d.kind==='dynamics')marks.push({at:d.start,value:d.value});
  marks.sort((a,b)=>a.at.cmp(b.at));
  const levels=[],own=[];
  for(const {at,value} of marks){
    const velocity=markVelocity(value),kin=OWN_DYNAMICS[value];
    if(Number.isFinite(velocity))levels.push({at,velocity});
    else if(kin){if(kin.least||kin.up)own.push({at,...kin});if(kin.then)levels.push({at,velocity:markVelocity(kin.then),after:true})}
    else warn(`a dynamic "${value}" not read`);
  }
  let drawn=null;
  const opening=line[0]?.start??R0;
  if(!levels.some(l=>l.at.le(opening)&&!l.after)){
    const stream=createRandomStream(`${seed}:performer-dynamic`),[mark]=DYNAMICS[Math.min(DYNAMICS.length-1,Math.floor(stream.next()*DYNAMICS.length))];
    drawn=mark;levels.unshift({at:R0,velocity:markVelocity(mark)});
  }
  const sortLevels=()=>levels.sort((a,b)=>a.at.cmp(b.at)||Number(Boolean(a.after))-Number(Boolean(b.after)));
  sortLevels();
  // (The level at a place: the last mark at or before it; one that comes after its note, `after`, only past the place.)
  const levelAt=(at,{past=false}={})=>levels.filter(l=>l.after?(past?l.at.le(at):l.at.lt(at)):l.at.le(at)).at(-1).velocity;
  const swells=[];
  for(const hairpin of hairpins.sort((a,b)=>a.from.cmp(b.from))){
    const v0=levelAt(hairpin.from),to=hairpin.to??line.at(-1)?.end??hairpin.from;
    const written=hairpin.to?levels.find(l=>!l.after&&l.at.eq(hairpin.to)):null;
    const v1=written?written.velocity:markStep(v0,hairpin.kind==='crescendo'?1:-1);
    if(!written&&hairpin.to){levels.push({at:hairpin.to,velocity:v1});sortLevels()}
    swells.push({t0:timeOf(hairpin.from),t1:Math.max(timeOf(hairpin.from)+TICK,timeOf(to)),v0,v1});
  }
  const swellAt=(s,t)=>lerp(s.v0,s.v1,Math.max(0,Math.min(1,(t-s.t0)/(s.t1-s.t0))));
  for(const n of line){
    if(n.own!=null){n.velocity=n.own;continue}
    const swell=swells.find(s=>n.at>=s.t0-1e-9&&n.at<s.t1);
    let velocity=swell?swellAt(swell,n.at):levelAt(n.start);
    if(swell){const ends=Math.min(n.at+n.written,swell.t1);n.pressureCurve=[+swellAt(swell,n.at).toFixed(6),+swellAt(swell,ends).toFixed(6)]}
    const kin=own.find(o=>o.at.le(n.start)&&!line.some(m=>m!==n&&m.start.ge(o.at)&&m.start.lt(n.start)));
    if(kin)velocity=kin.up?markStep(velocity,kin.up):Math.max(velocity,markVelocity(kin.least));
    if(n.accent)velocity=markStep(velocity,n.accent);
    n.velocity=+velocity.toFixed(6);
  }
  // Lengths: a staccato's, at its length's measured silence; a breath mark's breath.
  const silence=staccatoSilence(instrument,warn);
  for(const n of line){
    n.seconds=n.written;
    if(n.staccato)n.seconds=n.written-silence(n.written);
    if(n.breathMark)n.seconds-=Math.min(WIND_LINE.breathRest,WIND_LINE.shortenMost*n.seconds);
  }
  // Techniques: each named in words drawn once, held until words return it, or through its line.
  words.sort((a,b)=>a.at.cmp(b.at)||Number(Boolean(b.stop))-Number(Boolean(a.stop)));
  const draw=(stream=>()=>stream.next())(createRandomStream(`${seed}:performer-technique`));
  let held=null,span=null,w=0;
  for(const n of line){
    while(w<words.length&&words[w].at.le(n.start)){
      const said=words[w++];
      if(said.stop){span=null;continue}
      const kind=TECHNIQUE_WORDS.find(([,pattern])=>pattern.test(said.text))?.[0]??null;
      if(MUTED.test(said.text)){if(!/senza/i.test(said.text))warn(`a mute named ("${said.text}"): played without one`);continue}
      if(!kind){if(!said.span&&ORDINARY.test(said.text))held=null;continue}
      const technique=windTechniqueOf(kind,Math.abs(2*Math.min(1,n.velocity)-1)*draw(),draw);
      if(said.span)span=technique;else held=technique;
    }
    const technique=span??held,extended=technique?windTechniqueAt(technique,n.pitch):null;
    if(extended)n.extended=extended;
  }
  // Within its compass.
  const played=compass?line.filter(n=>n.pitch>=compass[0]&&n.pitch<=compass[1]):line;
  if(played.length<line.length)warn(`${line.length-played.length} note${line.length-played.length===1?'':'s'} outside the compass [${compass}] left out`);
  for(const [what,count] of told)warn(`${what} (${count})`);
  return {drawn,notes:played.map((n,k)=>{
    const slurred=n.joined&&played[k-1]?.voice===n.voice,portato=slurred&&n.portato;
    const attackSeconds=portato?BREATH.legatoTongue:slurred?BREATH.legato:BREATH.tongue[scoredDynamicOf(n.velocity)];
    return {at:+n.at.toFixed(9),note:n.pitch,seconds:+n.seconds.toFixed(9),velocity:n.velocity,...(slurred?{slurred:true}:{}),...(portato?{portato:true}:{}),
      phrased:true,performance:{attackSeconds,...(n.pressureCurve?{pressureCurve:n.pressureCurve}:{})},...(n.extended?{extended:n.extended}:{}),measure:n.measure};
  })};
}
// The silence players leave after a staccato note `ioi` s long (to the next note's onset; here its written length):
// the registry's measured points (tongue.staccato.silence, [length, silence]) between them, and beyond them the same share
// of the note as at the nearest. An instrument with none of its own borrows the clarinettists' (MEASURED_TONGUE).
function staccatoSilence(instrument,warn){
  const measured=id=>{try{return player(id,PATH)}catch{return null}},PATH='tongue.staccato.silence',own=instrument?measured(instrument):null;
  if(instrument&&!own)warn(`the staccato's silence ${MEASURED_TONGUE}'s, measured of clarinettists: none measured for ${instrument}`);
  const points=[...(own??player(MEASURED_TONGUE,PATH))].sort((a,b)=>a[0]-b[0]);
  return ioi=>{
    if(ioi<=points[0][0])return ioi*points[0][1]/points[0][0];
    if(ioi>=points.at(-1)[0])return ioi*points.at(-1)[1]/points.at(-1)[0];
    const k=points.findIndex(p=>p[0]>ioi),[a,b]=[points[k-1],points[k]];
    return lerp(a[1],b[1],(ioi-a[0])/(b[0]-a[0]));
  };
}

// ---- the performance ----------------------------------------------------------------------------------------------------
export function performMusicXML(text,{part=null,seed=DEFAULT_SEED,compass=null,instrument=null,group=0,channel=0}={}){
  const score=typeof text==='string'?musicXMLToScore(text):text,warnings=[],warn=what=>{if(!warnings.includes(what))warnings.push(what)};
  const timing=scoreTiming(score,{seed,warn}),{notes,drawn}=partNotes(score,partOf(score,part),{timing,seed,compass,instrument,warn});
  const identities=new BowedIdentities(),events=[];
  for(const n of notes){
    const note=identities.take(n.note,n.at,n.at+n.seconds);
    n.events=windNoteEvents(n,{group,channel,note}).map(({time,packet})=>({seconds:+(n.at+time).toFixed(9),packet}));
    events.push(...n.events);
  }
  events.sort((a,b)=>a.seconds-b.seconds);
  return {notes,events,warnings,seconds:timing.map.endSeconds,map:timing.map,drawn:{tempo:timing.drawn,dynamic:drawn}};
}

// A performance sent to its synthesizer a little ahead of its time, each note whole -- its Per-Note Management to its
// Note Off -- as a musebot sends its line (dial-midi2.js). `start`: the piece's start on the synthesizer's clock; `lead`:
// how far ahead of a note's onset it is sent (s; on the winds' dial no less than its stroke: its /state strokeLeast).
export class PerformanceFeed{
  constructor(notes,{start=0,lead}){
    if(!(lead>=0))throw new RangeError('PerformanceFeed: a lead, s, to send each note ahead');
    Object.assign(this,{notes,start,lead,next:0});
  }
  due(now){
    const out=[];
    while(this.next<this.notes.length&&this.start+this.notes[this.next].at<=now+this.lead){
      for(const {seconds,packet} of this.notes[this.next++].events)out.push({seconds:+(this.start+seconds).toFixed(9),packet});
    }
    return out;
  }
  get done(){return this.next>=this.notes.length}
}
