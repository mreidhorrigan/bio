// A bowed string's phrase, planned with its bow (the world-instruments report's §5.3: "coordinate stopping with the
// bow's remaining future"; §8.1: "generate musical candidates together with their possible realizations"). The line is
// the melody's, carried to a violin, viola, cello or contrabass (the atlas's F08):
//   - its line the shared one (line.js): phrases made of the instrument's motif, in the sentence's shape (the idea, its
//     repetition, a continuation climbing to one apex, a held cadence, a rest), keeping the melody rules, in the voice's
//     own pitches (its pool, in every octave of the instrument's range, whatever the tuning), as densely as its
//     attention share allows (shared/attention.js: a soloist's license, fast and loud together at its top);
//   - its bowing: quick notes slurred in twos to fours, long notes separate, a soloist's long notes ornamented with
//     fioriture (shared/performers/fioritura.js), each run under one slur;
//   - its bow distributed with it, by construction, stroke by stroke (the user, 28 September 2026: "Checks should be
//     used only for system development"): down and up in turn from where the bow is, each stroke at its dynamic's speed
//     where the bow has room; slower where it hasn't, as players draw a long note (its speed set by the bow's length, the
//     dynamic made nearer the bridge: Schoonderwaldt 2009, doi:10.1121/1.3203209, relayed by 7a), never slower than a
//     tone holds; set back at the frog or the tip in a silence long enough for a retake; a slur the slowest bow cannot
//     draw from where the bow is divided at its middle; a single note longer than the whole bow at the slowest changing
//     bow inside itself last (an articulation, said so). The bow planner (bow.js planBowing), given each note's speed, is
//     the reference in the tests, never called while playing.
// Nothing here names a meter or a scale.
import {BOW} from './bow.js';
import {LINE,linePitches,planLine} from './line.js';
import {instrumentRange} from './instrument-ranges.js';
import {GIVEN_BOWED,bySize} from './bowed-instruments.js';
import {group,player,setting,value} from '../../../registry/registry.js';

// (Its planning's settings the registry's, each with its reason: registry/method/strings.json `bowed-line`.)
const LINE_SETTING=name=>setting('bowed-line',name);
const SAME=LINE_SETTING('same'),JOIN_WITHIN=LINE_SETTING('joinWithin'),MARGIN_GRAINS=LINE_SETTING('marginGrains'),BISECTIONS=LINE_SETTING('bisections');
const REPAIRS_PER_NOTE=LINE_SETTING('repairsPerNote'),REPAIRS_MORE=LINE_SETTING('repairsMore');

export {linePitches};

// The instruments: open strings (standard tunings), how far up the highest is played (semitones: to the top of the
// compass), the bow (cm, as commonly made: registry/objects/bowed.json, each instrument's `bow.length`), and the register
// the line keeps to -- the strings, compass and register the instrument registry's (instrument-ranges.js); an instrument
// given as data (bowed-instruments.js) its bow read between theirs by size.
const bowed=(instrument,lengthCm)=>{const {strings,range,register}=instrumentRange(instrument);
  return Object.freeze({strings,reach:range[1]-strings.at(-1),lengthCm,register,range})};
const BOW_CM=Object.freeze(Object.fromEntries(['violin','viola','cello','contrabass'].map(name=>[name,value(name,'bow.length')])));
export const BOWED_INSTRUMENTS=Object.freeze({
  ...Object.fromEntries(Object.entries(BOW_CM).map(([name,cm])=>[name,bowed(name,cm)])),
  ...Object.fromEntries(GIVEN_BOWED.map(i=>[i.name,bowed(i.name,bySize(BOW_CM,i.name))])),
});
// What a bowed instrument's player may play on a synth that says no more (a Performer knows its synth's constraints:
// docs/MUSEBOTS_3_SPECIFICATION.md; audio.js instrumentLimits asks the synth first): the registry's compass, register and open
// strings, its bow pressed and its contact moved as any synth takes them (bowed-midi2.js), and no technique only a
// model sounds -- no natural harmonic or multiphonic it has not measured. A synth that sounds more says so with its own
// (physical-strings.js stringsModelLimits).
export function bowedLimits(instrument){
  const {range,register,strings}=BOWED_INSTRUMENTS[instrument];
  return Object.freeze({instrument,engine:null,range,register,strings,harmonicNear:null,multiphonicNear:null,evidence:'authored'});
}
// How fast a finger slides along its string at most (semitones a second): a glissando faster than this is no slide but a
// shift (the owner, 4 October 2026: "clamp the max speed at which glissando can occur for each instrument"); the longer
// the string, the slower, its semitones further apart -- the registry's players' `slide.most` (registry/players/
// bowed.json: ours, unmeasured, to be replaced by players' measured glissandi).
const SLIDE=Object.freeze(Object.fromEntries(['violin','viola','cello','contrabass'].map(name=>[name,player(name,'slide.most')])));
export const BOWED_SLIDE_SPEED=Object.freeze({...SLIDE,...Object.fromEntries(GIVEN_BOWED.map(i=>[i.name,bySize(SLIDE,i.name)]))});
export const BOWED_LINE=Object.freeze({...LINE,
  // How slowly a note may be drawn. A dynamic needs a string amplitude of about the bow's speed over its contact point
  // (beta, its distance from the bridge as a share of the string), and the contact point can come only so near the
  // bridge (Schoonderwaldt 2009, relayed by 7a: beta from about 0.3 at pp to 0.03 at f). So the slowest bow at a
  // dynamic is its speed (bow.js) times the nearest contact point over its usual one, and never slower than a tone holds
  // at (cm a second). The contact points by dynamic are authored within those measured ranges (registry/players/
  // bowed.json `line`, the violin family's: ours, unmeasured, the searches recorded).
  contact:group('violin-family','line.contact','players'),nearestContact:player('violin-family','line.nearestContact'),
  slowestBow:player('violin-family','line.slowestBow'),
  // How much faster than its dynamic's speed a note may be drawn (toward the fingerboard; authored), and the most a single
  // note too long for its bow is eased (dynamics) before it changes bow inside itself: one, so that a loud note stays
  // loud, its bow changed where one bow cannot hold it.
  fastestShare:player('violin-family','line.fastestShare'),easeMost:player('violin-family','line.easeMost'),
});

// A phrase: {notes: [{id, pitch, start, end (s from the phrase's downbeat), dynamic, slur?, velocity, fioritura?,
// bowSpeed}], strokes, changes: [what the bowing made room with, and why], status}. instrument: a name or its own {strings, reach, lengthCm,
// register}; pool: the harmony's pitches; meter, bpm (the notated beat's), bars; density and loudness 0 to 1 (its arc
// and its attention's reach: a soloist's climax near 1); fioriture 0 to 1; random.
export function planPhrase({instrument='violin',register=null,pool,meter,bpm,bars,density=LINE_SETTING('density'),loudness=LINE_SETTING('loudness'),fioriture=0,motif=null,motifDensity,phraseIndex=0,previousApex=null,climax=false,pickup=null,lead=null,heard=[],final=null,coreOnly=false,variation=null,nextPhrase=null,random,choices=BOWED_LINE}){
  const kind=typeof instrument==='string'?BOWED_INSTRUMENTS[instrument]:instrument;
  if(!kind)throw new RangeError(`no bowed instrument ${instrument}`);
  // Its register: the instrument's, or a part of it (where it keeps out of another's, shared/presentation.js).
  const line=planLine({register:register??kind.register,pool,meter,bpm,bars,density,loudness,fioriture,motif,motifDensity,phraseIndex,previousApex,climax,pickup,lead,heard,final,coreOnly,variation,nextPhrase,random,choices});
  if(line.status==='declined')return {...line,strokes:[],changes:[]};
  return {...bowPhrase(line.notes,{kind,choices}),motif:line.motif,apex:line.apex,variation:line.variation,lead:line.lead,...(line.choice?{choice:line.choice}:{})};
}

// The phrase bowed with it: {status: 'bowed', notes (each with its bow speed, cm a second), strokes: [{notes, direction,
// from, to, how, change?}], changes: [{at, change, because}], startAt (where its first stroke sets the bow down, cm)}. The bow is distributed as a player plans it, looking
// ahead: each stroke's travel lies between its slowest (its dynamic's contact point at the nearest to the bridge, or a
// tone's slowest) and a faster bow toward the fingerboard; the positions from which the rest of the phrase can be drawn
// are found backwards from its end (a retake in a silence long enough freeing the bow), and each stroke is then drawn
// forwards as near its dynamic's speed as they allow. Only a stroke no position can draw is changed: a slur divided at
// its middle, a single note eased a dynamic, else changing bow inside itself.
export function bowPhrase(input,{kind,choices=BOWED_LINE}){
  const bow={...BOW,strings:kind.strings,reach:kind.reach,lengthCm:kind.lengthCm},length=bow.lengthCm,changes=[];
  const notes=input.map(note=>({...note}));
  const speedAt=dynamic=>bow.speed[dynamic]??bow.speed.mf,speedOf=note=>speedAt(note.dynamic);
  const slowestAt=dynamic=>Math.max(choices.slowestBow,speedAt(dynamic)*choices.nearestContact/(choices.contact[dynamic]??choices.contact.mf)),slowestOf=note=>slowestAt(note.dynamic);
  const fastestOf=note=>speedOf(note)*choices.fastestShare,seconds=note=>note.end-note.start;
  // Strokes: a slur's notes sounding one into the next; else each note alone.
  let strokes=[];
  for(const note of notes){const last=strokes.at(-1);if(last&&note.slur&&last.slur===note.slur&&note.start-last.notes.at(-1).end<JOIN_WITHIN)last.notes.push(note);else strokes.push({slur:note.slur??null,notes:[note]})}
  const sum=(stroke,speed)=>stroke.notes.reduce((total,note)=>total+speed(note)*seconds(note),0);
  const measure=stroke=>Object.assign(stroke,{lo:sum(stroke,slowestOf),want:sum(stroke,speedOf),hi:Math.max(sum(stroke,speedOf),sum(stroke,fastestOf)),
    gap:stroke.notes[0].start-(stroke.previousEnd??-Infinity)});
  // A stroke that can't be drawn: a slur divided at its middle; a single note eased a dynamic, else changing bow inside
  // itself (at its slowest, running on past the bow's end once).
  const repair=s=>{
    const stroke=strokes[s],first=stroke.notes[0];
    if(stroke.notes.length>1){
      const half=Math.ceil(stroke.notes.length/2),a=`${stroke.slur}.a`,b=`${stroke.slur}.b`;
      stroke.notes.forEach((note,k)=>{note.slur=k<half?a:b});
      strokes.splice(s,1,{slur:a,notes:stroke.notes.slice(0,half)},{slur:b,notes:stroke.notes.slice(half)});
      changes.push({at:first.start,change:'slur split in 2',because:`the bow can't draw the slur whole where it is (it wants ${stroke.lo.toFixed(0)} cm at its slowest)`});
      return true;
    }
    if(stroke.hidden)return false;
    const order=choices.dynamics,index=order.indexOf(first.dynamic);
    if(!stroke.eased&&index>0&&index-1>=order.indexOf(first.dynamic)-choices.easeMost){
      const softer=order[index-1];stroke.eased=true;
      first.dynamic=softer;first.velocity=choices.velocity[softer];
      changes.push({at:first.start,change:`eased to ${softer}`,because:`at ${order[index]} no bow where it is draws it slowly enough`});
      return true;
    }
    stroke.hidden=true;
    return true;
  };
  const margin=bow.positionGrain*MARGIN_GRAINS,usable=[margin,length-margin];
  const prepare=()=>{let end=-Infinity;for(const stroke of strokes){stroke.previousEnd=end;measure(stroke);end=stroke.notes.at(-1).end}};
  // A slur longer than the whole bow at its slowest is divided before anything else.
  prepare();
  for(let s=0;s<strokes.length;s++)if(strokes[s].lo>usable[1]-usable[0]&&!strokes[s].hidden){repair(s);prepare();s=-1}
  const retakes=s=>s>0&&strokes[s].gap>=bow.retakeSeconds-SAME;
  const setDown=stroke=>stroke.direction==='down'?0:length;
  // The plan: backwards, the positions each stroke may begin from (F) and the previous one may end at (E); then
  // forwards, each stroke drawn as near its dynamic's speed as they allow. {drawn} or {failed: the stroke to change}.
  const plan=()=>{
    const n=strokes.length;
    strokes.forEach((stroke,s)=>{stroke.direction=s===0?'down':strokes[s-1].hidden?strokes[s-1].direction:strokes[s-1].direction==='down'?'up':'down'});
    const F=new Array(n),E=new Array(n+1);E[n]=[...usable];
    for(let s=n-1;s>=0;s--){
      const stroke=strokes[s],[elo,ehi]=E[s+1];let range;
      if(stroke.hidden){
        const T=stroke.lo;
        // (Down, there and back along the bow's length; up, from its end.)
        range=stroke.direction==='down'?[Math.max(0,(length+length)-T-ehi),Math.min(length,(length+length)-T-elo)]:[Math.max(0,T-length+elo),Math.min(length,T-length+ehi)];
      }else range=stroke.direction==='down'?[Math.max(0,elo-stroke.hi),Math.min(usable[1],ehi)-stroke.lo]:[Math.max(usable[0],elo)+stroke.lo,Math.min(length,ehi+stroke.hi)];
      if(range[0]>range[1]+SAME)return {failed:s};
      F[s]=range;
      const set=setDown(stroke);
      E[s]=retakes(s)&&set>=range[0]-SAME&&set<=range[1]+SAME?[...usable]:[Math.max(range[0],usable[0]),Math.min(range[1],usable[1])];
      if(E[s][0]>E[s][1]+SAME)return {failed:s};
    }
    const drawn=[];let position=null;
    for(let s=0;s<n;s++){
      const stroke=strokes[s],[flo,fhi]=F[s],set=setDown(stroke),down=stroke.direction==='down';
      let from,how;
      if(position==null){from=Math.min(Math.max(set,flo),fhi);how='start'}
      else{
        const room=down?length-position:position,fits=position>=flo-SAME&&position<=fhi+SAME,setFits=set>=flo-SAME&&set<=fhi+SAME;
        if(retakes(s)&&setFits&&(!fits||room<stroke.want-SAME)){from=set;how='retake'}
        else if(fits){from=position;how='change'}
        else return {failed:Math.max(0,s-1)};
      }
      const [elo,ehi]=E[s+1];
      if(stroke.hidden){
        const first=stroke.notes[0],T=stroke.lo,speed=T/seconds(first),room=down?length-from:from,at=first.start+room/speed;
        first.bowSpeed=speed;position=down?length-(T-room):T-room;
        drawn.push({notes:[first.id],direction:stroke.direction,from,to:position,how,change:{note:first.id,at:+at.toFixed(6)}});
        continue;
      }
      // Its travel: its want, or more where the next stroke needs the bow set for it (a player's saving or spending
      // bow, unless a retake will set it), ending where the rest can be drawn from.
      const least=Math.max(stroke.lo,down?elo-from:from-ehi),most=Math.min(stroke.hi,down?ehi-from:from-elo);
      if(least>most+SAME)return {failed:s};
      const next=strokes[s+1],ahead=next&&!next.hidden&&!retakes(s+1)?Math.min(usable[1]-usable[0],next.want):0,prepare=ahead?(down?usable[0]+ahead-from:from-(usable[1]-ahead)):0;
      const travel=Math.min(Math.max(stroke.want,prepare,least),most);
      // Each note's speed: its dynamic's scaled by one share for all, within its slowest and fastest, spending that travel.
      const spent=share=>stroke.notes.reduce((total,note)=>total+Math.min(fastestOf(note),Math.max(slowestOf(note),speedOf(note)*share))*seconds(note),0);
      let low=0,high=choices.fastestShare;for(let step=0;step<BISECTIONS;step++){const middle=(low+high)/2;if(spent(middle)<=travel)low=middle;else high=middle}
      for(const note of stroke.notes)note.bowSpeed=Math.min(fastestOf(note),Math.max(slowestOf(note),speedOf(note)*low));
      const actual=stroke.notes.reduce((total,note)=>total+note.bowSpeed*seconds(note),0);
      position=from+(down?actual:-actual);
      drawn.push({notes:stroke.notes.map(note=>note.id),direction:stroke.direction,from,to:position,how});
    }
    return {drawn};
  };
  let planned=plan();
  for(let guard=0;planned.failed!=null&&guard<REPAIRS_PER_NOTE*notes.length+REPAIRS_MORE;guard++){
    // The stroke that can't be drawn changed, or, where it can't be, the one before it.
    if(!repair(planned.failed)&&!(planned.failed>0&&repair(planned.failed-1)))break;
    prepare();planned=plan();
  }
  const drawn=planned.drawn??[];
  for(const stroke of drawn)if(stroke.change)changes.push({at:stroke.change.at,change:'a bow change inside the held note',because:'it wants more than the whole bow at its slowest'});
  return {status:'bowed',notes,strokes:drawn,changes,startAt:drawn[0]?.from??0};
}
