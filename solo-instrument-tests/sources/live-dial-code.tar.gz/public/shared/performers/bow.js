// A bowed string's bow: where it is, which way it moves, how much of it each note spends, and where it may change
// direction, planned through the performer contract's one solver (contract.js searchGroups) as the piano, the guitar and
// the voice are. The general performer–instrument report's §5.4 and its C03: "Track bow travel/direction and permit
// reversals only under the selected articulation policy."
//
// **A bow stroke is continuous action, not a trigger** (§5.4): each note spends bow at the speed its dynamic takes, down
// from the frog toward the tip or up from the tip; the bow must not run out mid-note. Notes under one slur share one
// stroke; separate notes (détaché) change direction between them; a retake lifts the bow and sets it down again anywhere,
// which needs a silence of its own, as a phrase's first stroke may begin anywhere on the bow. A bow change inside a held note is a change of articulation, so only a part whose policy allows it
// (`hiddenChanges`) gets one, and each is reported.
//
// **Strings are engaged, not assumed** (§5.4): simultaneous notes sound on adjacent strings under one bow; a chord on
// strings not adjacent, or of more than two, is not played as one attack here (a broken chord is the part's to allow).
//
// **No number here is universal**: the speeds by dynamic and a change's time are an authored starting profile (a player
// measured replaces them), and a plan's witness says so -- the registry's (registry/players/bowed.json, the violin
// family's: ours, unmeasured, each search recorded); the bow's length the violin's (registry/objects/bowed.json); the
// planner's settings registry/method/strings.json `bow-planner`, each with its reason.
import {action,checkReservations,profile,searchGroups,STATUS,witness} from './contract.js';
import {instrumentRange} from './instrument-ranges.js';
import {DYNAMIC_VELOCITY} from '../dynamics.js';
import {group as registryGroup,player,setting,value} from '../../../registry/registry.js';

const PLANNER=name=>setting('bow-planner',name);

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const BOW=Object.freeze({
  // A violin: its strings' open pitches (G3 D4 A4 E5) and how far up the highest is played (semitones: to the top of its
  // compass; both the instrument registry's, instrument-ranges.js), and its bow (cm).
  strings:instrumentRange('violin').strings,reach:instrumentRange('violin').range[1]-instrumentRange('violin').strings.at(-1),lengthCm:value('violin','bow.length'),
  // How fast the bow moves at each dynamic (cm a second): authored, a starting profile. Softer is slower here, as a
  // sustained soft tone is usually drawn; a player may as well draw a soft tone fast near the fingerboard (§5.4:
  // Schelleng's diagram, no universal table).
  speed:registryGroup('violin-family','speed','players'),
  // How long changing the bow's direction takes, a change inside a held note included, and a retake (the bow lifted and
  // set back at the frog or the tip): authored.
  changeSeconds:player('violin-family','change.planned'),retakeSeconds:player('violin-family','retake'),
  // Notes starting within this of each other are one group (s); bow positions within this are one state (cm); and where
  // a stroke may be set down to begin (a phrase's first, or after a retake), as shares of the bow from the frog.
  together:PLANNER('together'),positionGrain:PLANNER('positionGrain'),setDown:Object.freeze(PLANNER('setDown')),
  // Costs (authored): a direction change, a retake, a change inside a held note (an articulation changed).
  cost:Object.freeze({change:PLANNER('costChange'),retake:PLANNER('costRetake'),hidden:PLANNER('costHidden')}),
  maxStates:PLANNER('maxStates'),
});
const EPSILON=PLANNER('same');
// (The most strings a bow sounds at once: registry/objects/bowed.json bow.stringsAtOnce.)
const AT_ONCE=value('violin-family','bow.stringsAtOnce');
// How fast the bow moves at a velocity (cm a second): between the speeds of the two marks whose centres it lies between
// (dynamics.js), geometrically, as the strings' model draws it (physical-strings.js); beyond ppp or fff, theirs (the
// uncomfortable range is the bow's pressure, not its speed).
const MARKS=Object.keys(DYNAMIC_VELOCITY),CENTRES=MARKS.map(mark=>DYNAMIC_VELOCITY[mark]),INSIDE=CENTRES.slice(1,-1);
export function bowSpeedAt(velocity,{choices=BOW}={}){
  const v=Math.max(CENTRES[0],Math.min(CENTRES.at(-1),Number(velocity)||0)),i=INSIDE.filter(x=>v>x).length;
  const w=(v-CENTRES[i])/(CENTRES[i+1]-CENTRES[i]),a=choices.speed[MARKS[i]],b=choices.speed[MARKS[i+1]];
  return a*(b/a)**w;
}

// A string player: the left hand that stops the strings and what draws the bow: the right arm, or another resource of
// the player's own setup (a bow holder, a device with its own authority: §3's adapted setups, F06), named `bowBy`.
export function stringPlayer({id='string player',evidence='authored',bowBy='bow',bowKind='effector',extra=[]}={}){
  return profile({id,performer:'string player',resources:[{id:'LH',kind:'effector',capacity:1,evidence},{id:bowBy,kind:bowKind,capacity:1,evidence},...extra]});
}
// The strings a pitch can sound on: [index], lowest first.
export const stringsFor=(pitch,{choices=BOW}={})=>choices.strings.map((open,index)=>({open,index})).filter(({open})=>pitch>=open-EPSILON&&pitch<=open+choices.reach+EPSILON).map(({index})=>index);

// Groups of notes starting together: [{at, end, notes, slur, dynamic, bowSpeed}]; each group one bow stroke's worth of
// sounding. A note may say its own bow speed (cm a second: a part that distributes its bow, drawing a long note slower
// than its dynamic's speed and making the dynamic nearer the bridge); else its dynamic's.
function bowGroups(notes,{choices}){
  const groups=[];
  for(const note of [...notes].sort((a,b)=>a.start-b.start)){
    const last=groups.at(-1);
    if(last&&Math.abs(note.start-last.at)<=choices.together){last.notes.push(note);last.end=Math.max(last.end,note.end);continue}
    groups.push({at:note.start,end:note.end,notes:[note]});
  }
  return groups.map(group=>({...group,slur:group.notes[0].slur??null,dynamic:group.notes[0].dynamic??'mf',bowSpeed:Number.isFinite(group.notes[0].bowSpeed)?group.notes[0].bowSpeed:null}));
}
// Whether a group's notes can sound together under one bow: on one string, or two adjacent. {strings} or {reason}.
function engaged(group,{choices}){
  if(group.notes.length===1){const strings=stringsFor(group.notes[0].pitch,{choices});return strings.length?{strings:[strings[0]]}:{reason:`${group.notes[0].pitch} is on no string`}}
  if(group.notes.length>AT_ONCE)return {reason:`${group.notes.length} notes at once: more than a bow's two strings (a broken chord is the part's to allow)`};
  const [a,b]=group.notes.map(note=>stringsFor(note.pitch,{choices}));
  for(const x of a)for(const y of b)if(Math.abs(x-y)===1)return {strings:[x,y].sort()};
  return {reason:`${group.notes.map(note=>note.pitch).join(' and ')} are on no two adjacent strings`};
}

// Plan a phrase's bowing: notes {id?, pitch, start, end, dynamic? (pp..ff), slur? (an id: notes under it share a
// stroke), bowSpeed? (cm a second)}. policy {hiddenChanges: false} lets a held note change bow inside it; {startAt} (cm
// from the frog) is where the part sets the bow down for its first stroke, besides the usual places. {status, strokes: [{notes, direction,
// from, to, change?}], witness} or {status, at, reason}.
export function planBowing(input,{who=stringPlayer(),choices=BOW,policy={},bowBy='bow'}={}){
  if(!input.length)return {status:STATUS.witness,strokes:[]};
  const notes=input.map((note,index)=>({...note,id:note.id??`n${index}`}));
  const groups=bowGroups(notes,{choices});
  for(const group of groups){const fit=engaged(group,{choices});if(fit.reason)return {status:STATUS.violates,at:group.at,reason:fit.reason};group.strings=fit.strings}
  const length=choices.lengthCm,grain=choices.positionGrain,allowHidden=Boolean(policy.hiddenChanges);
  const expand=(group,state)=>{
    const speed=group.bowSpeed??choices.speed[group.dynamic]??choices.speed.mf,travel=speed*(group.end-group.at),moves=[];
    const previous=state.index>=0?groups[state.index]:null,gap=previous?group.at-previous.end:Infinity;
    const slurred=Boolean(previous)&&group.slur!==null&&group.slur===previous.slur;
    // The ways it may begin: a slur's own stroke going on; else a change of direction at the boundary (from where the bow
    // is), or a retake (the bow set back, in a silence long enough to lift it).
    const setDown=(how,cost)=>choices.setDown.flatMap(share=>['down','up'].map(direction=>({direction,from:share*length,cost,how})));
    // A phrase's first stroke may also begin where the part says it sets the bow down (policy.startAt, cm from the frog).
    const options=!previous?[...setDown('start',0),...(Number.isFinite(policy.startAt)&&policy.startAt>=0&&policy.startAt<=length?['down','up'].map(direction=>({direction,from:policy.startAt,cost:0,how:'start'})):[])]
      :slurred?[{direction:state.direction,from:state.position,cost:0,how:'slur'}]
      :[{direction:state.direction==='down'?'up':'down',from:state.position,cost:choices.cost.change,how:'change'},
        ...(gap>=choices.retakeSeconds-EPSILON?setDown('retake',choices.cost.retake):[])];
    for(const {direction,from,cost,how} of options){
      const sign=direction==='down'?1:-1,room=direction==='down'?length-from:from,step={group:group.at,notes:group.notes.map(note=>note.id),direction,from:+from.toFixed(3),how,strings:group.strings};
      if(travel<=room+EPSILON){
        const to=from+sign*travel;
        moves.push({status:'supported',cost,state:{index:state.index+1,position:to,direction},step:{...step,to:+to.toFixed(3)}});
      }else if(allowHidden&&travel-room<=length+EPSILON&&group.end-group.at>choices.changeSeconds){
        // Out of bow inside the note: a change there, and the rest of it drawn the other way.
        const rest=travel-room,back=direction==='down'?length-rest:rest,turned=direction==='down'?'up':'down';
        moves.push({status:'supported',cost:cost+choices.cost.hidden,state:{index:state.index+1,position:back,direction:turned},
          step:{...step,to:+back.toFixed(3),change:{note:group.notes[0].id,at:+(group.at+room/speed).toFixed(6),articulation:'a bow change inside the note'}}});
      }
    }
    return moves;
  };
  const key=state=>`${Math.round(state.position/grain)}|${state.direction}|${state.index}`;
  const found=searchGroups(groups,{initial:{index:-1,position:0,direction:'up'},expand,stateKey:key,maxStates:choices.maxStates});
  if(found.status!==STATUS.witness){
    const group=found.group,need=list=>list.reduce((sum,each)=>sum+(each.bowSpeed??choices.speed[each.dynamic]??choices.speed.mf)*(each.end-each.at),0);
    const under=group.slur!==null?groups.filter(each=>each.slur===group.slur):[group];
    return {status:found.status,at:group.at,reason:`no bowing plays the phrase through ${group.at} s: ${group.slur!==null?`its slur needs ${+need(under).toFixed(1)} cm of bow in one stroke`:`it needs ${+need(under).toFixed(1)} cm of bow`}, and the bow is ${length} cm`,
      alternatives:[{kind:'hidden-bow-change',change:'a bow change inside the held note (the part\'s articulation changes)'},{kind:'faster-bow',change:'a faster bow at the dynamic, nearer the fingerboard'},{kind:'shorter-slur',change:'the slur divided (the part\'s phrasing changes)'}]};
  }
  const strokes=found.path;
  // The witness: the bow arm reserved stroke by stroke, the left hand for each stopped note.
  const actions=strokes.map((stroke,index)=>action({id:`bow@${stroke.group}`,technique:`${stroke.direction}-bow`,contacts:stroke.notes,
    reservations:[{resource:bowBy,phase:'excite',start:stroke.group,end:groups[index].end,configuration:`bow:${index}`}]}));
  const reservations=checkReservations(who,actions);
  const proof=witness({who,actions,checks:[{id:'bow-arm',evidence:'authored',...reservations},{id:'bow-travel',status:STATUS.witness,evidence:'authored'},
    {id:'string-engagement',status:STATUS.witness,evidence:'authored'},{id:'sound-regime',status:STATUS.unknown}]});
  return {status:STATUS.witness,strokes,cost:found.cost,witness:proof,changes:strokes.filter(stroke=>stroke.change).map(stroke=>stroke.change)};
}
