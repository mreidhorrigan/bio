// A figuration as a compound melody (the owner, 3 October 2026: "Move toward considering textures primarily in terms of
// counterpoint, and arpeggios and related textures (e.g., alberti bass, fingerpicked-like guitar) in terms of compound
// melodies within that counterpoint"): an Alberti bass, an arpeggio, a guitarist's picking are one line sounding several
// voices in turn -- a bass, an inner voice, a top -- each of which is a voice of the harmony's counterpoint, led from
// chord to chord by the least motion it can make, as a chorale's voices are, while the figure walks among them
// (figuration.js: which voice sounds when). Heard as such: a compound melody's implied voices are followed as voices
// where they hold their registers and move by step (Bregman 1990, Auditory Scene Analysis, MIT Press: streaming by
// pitch proximity; Huron 2001, "Tone and Voice: A Derivation of the Rules of Voice-Leading from Perceptual Principles",
// Music Perception 19(1), 1-64, doi:10.1525/mp.2001.19.1.1: the pitch-proximity and the avoid-crossing principles).
//
// leadVoices(voices, tones): the voices (pitches, low to high) moved onto the harmony's tones (pitches) by the least total
// motion that keeps them in order, each its own tone where there are as many tones as voices -- a voice holding where its
// tone stays, the rest moving by the nearest way; where there are fewer tones than voices, the tones again an octave
// out, so that no two voices are made one.

// The tones a voicing may take: `tones`, and, where fewer than `n`, each again an octave above and below, low to high.
function enough(tones,n){
  const sorted=[...new Set(tones.map(Number).filter(Number.isFinite).map(p=>+p.toFixed(6)))].sort((a,b)=>a-b);
  if(sorted.length>=n||!sorted.length)return sorted;
  return [...new Set([...sorted,...sorted.map(p=>+(p+12).toFixed(6)),...sorted.map(p=>+(p-12).toFixed(6))])].sort((a,b)=>a-b);
}
// The `n` of `tones` spread over them evenly: a first voicing, from nothing to lead from.
export function spreadVoices(tones,n){
  const sorted=enough(tones,n);if(!sorted.length)return [];
  if(sorted.length<=n)return sorted.slice(0,n);
  return Array.from({length:n},(_,k)=>sorted[Math.round(k*(sorted.length-1)/Math.max(1,n-1))]);
}
// The voices led onto the tones: an order-keeping assignment of least total motion (a shortest path over the tones, voice
// by voice). -> pitches, low to high, as many as the voices.
export function leadVoices(voices,tones){
  const from=voices.map(Number).filter(Number.isFinite).sort((a,b)=>a-b),n=from.length,to=enough(tones,n),m=to.length;
  if(!n||!m)return from;
  if(m<n)return from.map(pitch=>to.reduce((best,p)=>Math.abs(p-pitch)<Math.abs(best-pitch)?p:best,to[0]));
  // (cost[i][j]: the least motion placing voices 0..i with voice i on tone j, each voice above the one before.)
  const cost=Array.from({length:n},()=>new Float64Array(m).fill(Infinity)),back=Array.from({length:n},()=>new Int32Array(m).fill(-1));
  for(let j=0;j<m;j++)cost[0][j]=Math.abs(to[j]-from[0]);
  for(let i=1;i<n;i++){let best=Infinity,at=-1;for(let j=0;j<m;j++){if(j>0&&cost[i-1][j-1]<best){best=cost[i-1][j-1];at=j-1}if(at>=0)cost[i][j]=best+Math.abs(to[j]-from[i]),back[i][j]=at}}
  let j=0;for(let k=1;k<m;k++)if(cost[n-1][k]<cost[n-1][j])j=k;
  const out=new Array(n);for(let i=n-1;i>=0;i--){out[i]=to[j];j=back[i][j]}
  return out;
}
