// An orchestra's battery (the owner, 2 October 2026: "include the rest of the orchestra to the extent possible"): its
// untuned percussion -- the bass drum, the clash cymbals, the snare drum, the suspended cymbal, the tambourine and the
// triangle -- each played by one percussionist at a time, as an orchestra's percussionists move between instruments
// (battery_clodbot). Which instrument a player takes for a phrase is its section's conductor's choice (castBattery), by
// the level the section is asked to play at: the bass drum and the cymbals where the orchestra is loud, the triangle where
// it is quiet. What a player plays on it is its own (batteryPhrase), from the form's joins, the meter's hierarchy and its
// level:
//   - the bass drum marks the phrase's first downbeat, and where the music is loud every bar's;
//   - the cymbals are clashed only where the music arrives (a join it moves up across, the piece's last bar), and at
//     their loudest at the middle of the phrase too;
//   - the suspended cymbal swells into the next section, its peak on the join's downbeat (the announcement a gesture
//     needs: the owner's "gestures need reinforcement"), and otherwise is touched at the phrase's start;
//   - the snare drum keeps an ostinato through the phrase, accents on the bar's felt beats and taps between them as many
//     as the level asks, the same each bar, and rolls into a join;
//   - the tambourine strikes the bar's felt beats, and rolls into a join;
//   - the triangle strikes the first bar's felt beats, or holds a roll through a quiet phrase.
// Over all of them a pulse, from that colouring to a groove (the battery's grooves as a continuous parameter of style):
// as it rises each instrument strikes the meter's own positions too, the same each bar (BATTERY.groove).
// Every stroke is one player's: one instrument, no faster than its taps (every tick at most), playable by construction.
import {feltBeats} from '../meter-tactus.js';
import {pulsed} from './section-voices.js';
import {prepareRhythmicTiling,solveRhythmicTiling} from '../conducting/rhythmic-tiling.js';
import {seededSource} from './string-section.js';

// ---- Choices (ours, after an orchestra's use of them) ------------------------------------------------------------------
export const BATTERY=Object.freeze({
  // Each instrument: its name and abbreviation for a score, how audio.js drum() plays it (its kind and General MIDI
  // note: the suspended cymbal 89, after the gong's 88), and the levels it is cast at (of the section's, 0 to 1).
  instruments:Object.freeze({
    bassDrum:Object.freeze({name:'Bass drum',abbreviation:'B. D.',kind:'kick',note:36,levels:Object.freeze([.45,1])}),
    cymbals:Object.freeze({name:'Cymbals',abbreviation:'Cym.',kind:'crash',note:49,levels:Object.freeze([.6,1])}),
    snare:Object.freeze({name:'Snare drum',abbreviation:'S. D.',kind:'snare',note:38,levels:Object.freeze([.25,.9])}),
    suspended:Object.freeze({name:'Suspended cymbal',abbreviation:'Sus. cym.',kind:'perc',note:89,levels:Object.freeze([.1,.85])}),
    tambourine:Object.freeze({name:'Tambourine',abbreviation:'Tamb.',kind:'perc',note:54,levels:Object.freeze([.3,.8])}),
    triangle:Object.freeze({name:'Triangle',abbreviation:'Trgl.',kind:'perc',note:81,levels:Object.freeze([0,.55])}),
  }),
  order:Object.freeze(['bassDrum','cymbals','snare','suspended','tambourine','triangle']),
  // A stroke's velocity across the level (0 to 1), an accent's above it, a tap's share of it.
  velocity:Object.freeze([.18,1]),accent:.15,tap:.55,
  // The level from which the bass drum strikes every bar, and the cymbals the middle of the phrase too.
  everyBar:.7,midPhrase:.85,
  // The share of a bar's other ticks the snare taps, at the least level and the most.
  taps:Object.freeze([.1,.5]),
  // The chance a quiet phrase's triangle is a roll held through it, under this level.
  triangleRoll:Object.freeze({chance:.4,below:.35}),
  // The longest a swell is begun before the join it peaks on (s: about the longest recorded swell's rise), and the
  // longest a roll is held (s: a crescendo roll into a join, or a quiet phrase's; within every recorded roll's length).
  swellSeconds:8,rollSeconds:6,
  // A phrase's pulse (0 to 1; its section's, by its character: percussion-section.js): at 0 the colouring above; as it
  // rises each instrument strikes the meter's positions too, the bar's starts first and every subdivision at 1
  // (section-voices.js pulsed, each position's draw the phrase's, so a groove keeps its pattern), each from its own place
  // in the meter's hierarchy, as a drum kit's parts divide the bar: `floor` the lightest position it takes (of the
  // bar's start 1, its felt beats .75, its notes .5, their subdivisions .25: the bass drum the notes, the clash cymbals
  // only the bar's start), `from` the pulse its groove begins at (the cymbals' and the triangle's later than the drums').
  // The snare's drawn taps give way to the meter's as the pulse rises.
  groove:Object.freeze({
    bassDrum:Object.freeze({floor:.5,from:0}),cymbals:Object.freeze({floor:1,from:.6}),snare:Object.freeze({floor:.25,from:0}),
    suspended:Object.freeze({floor:.25,from:.25}),tambourine:Object.freeze({floor:.25,from:.15}),triangle:Object.freeze({floor:.25,from:.35}),
  }),
});
const clamp01=value=>Math.max(0,Math.min(1,Number.isFinite(value)?value:.5));
const velocityAt=level=>BATTERY.velocity[0]+(BATTERY.velocity[1]-BATTERY.velocity[0])*clamp01(level);

// The instruments `count` players take for a phrase at `level`: those whose levels hold it, drawn without one taken
// twice, then the nearest to it where too few do. random: [0, 1). -> [instrument ids].
export function castBattery(count,{level=.5,random}={}){
  const at=clamp01(level),distance=id=>{const [low,high]=BATTERY.instruments[id].levels;return at<low?low-at:at>high?at-high:0};
  const fitting=BATTERY.order.filter(id=>distance(id)===0),out=[];
  const pool=[...fitting];
  while(out.length<count&&pool.length)out.push(pool.splice(Math.floor(random()*pool.length),1)[0]);
  const rest=BATTERY.order.filter(id=>!out.includes(id)).sort((a,b)=>distance(a)-distance(b));
  while(out.length<count&&rest.length)out.push(rest.shift());
  return out;
}

// A phrase on one instrument: `meter` the band's ({numerator, denominator, subdivision, groups, pulsesPerBar}), `bars`
// the phrase's, `level` 0 to 1, `arriving` (it begins on a join the music moves up across), `announcing` (the next
// phrase begins a join), `final` (it holds the piece's last bar), `secondsPerTick`, random [0, 1). -> its strokes, in
// order: [{bar (of the phrase, from 0), tick (in the bar), stroke ('hit', 'roll', 'swell'), velocity, seconds? (a
// roll's length, or a swell's time to its peak), note, kind}]. `pulse` 0 to 1 (BATTERY.groove).
// A battery's players grooving together as a rhythmic canon (Astra's CF27, rhythmic-tiling.js): every tick of the bar
// struck by exactly one of them, each playing one rhythmic cell at its own entry -- a hocket, the groove's texture made
// of its players' counterpoint rather than each striking the meter's positions alone. Its cell takes one tick of each
// class the players divide the bar into (the bar's ticks over its players, each class's tick in a block drawn from the
// pool's seed: `seed`), so a canon of it exists by construction (a complete residue system tiles with the multiples of
// the classes' count); the entries are constructed by Astra's solver, which may find others (its certificate checked in
// development: checkRhythmicTiling). `ticks` the
// bar's, `players` how many, `index` this player's place among them. -> {cell: [ticks], entry} for this player, or null
// where the bar's ticks do not divide among its players or the solver finds none.
export function batteryHocket({ticks,players,index,seed}){
  if(!(players>=2&&Number.isInteger(ticks)&&ticks%players===0&&index>=0&&index<players))return null;
  const classes=ticks/players,draw=seededSource(seed>>>0,'hocket-cell');
  const cell=Array.from({length:classes},(_,r)=>r+classes*Math.floor(draw()*players)).sort((a,b)=>a-b);
  let prepared;try{const ready=prepareRhythmicTiling({id:'battery-hocket',revision:1,periodSlots:ticks,inner:cell.map((slot,k)=>({id:`c${k}`,slot})),
    allowedOffsets:Array.from({length:ticks},(_,k)=>k),requiredOffsets:[0],offsetsComplete:true,mode:'tiling',
    clock:{id:'bar-ticks',revision:1,unit:'ticks',phase:'0',slotDuration:'1'},dependencies:[]});if(ready.status!=='PASS')return null;prepared=ready.prepared}catch{return null}
  const out=solveRhythmicTiling(prepared);if(out.status!=='SAT')return null;
  const entries=[...(out.certificate.entries??out.entries??[])].map(Number).sort((a,b)=>a-b);if(entries.length!==players)return null;
  return {cell,entry:entries[index]};
}
export function batteryPhrase(instrument,{meter,bars,level=.5,arriving=false,announcing=false,final=false,secondsPerTick=.25,pulse=0,random,hocket=null}){
  const own=BATTERY.instruments[instrument];if(!own)throw new RangeError(`The battery is ${BATTERY.order.join(', ')}`);
  const bar=Number(meter?.pulsesPerBar)||(Number(meter?.numerator)||4)*(Number(meter?.subdivision)||1),phrase=Math.max(1,bars|0);
  // (The bar's felt beats, as a listener counts them at this tempo: meter-tactus.js; its groups in an additive meter.)
  const groups=feltBeats({...meter,pulsesPerBar:bar},{secondsPerTick}).map(beat=>beat.start);
  // (A roll's or a swell's length composed in ticks, its seconds how long they last at this tempo.)
  const v=velocityAt(level),out=[],strike=(at,{stroke='hit',velocity=v,ticks=null}={})=>out.push({bar:at.bar,tick:at.tick,stroke,velocity:+Math.min(1,velocity).toFixed(3),
    ...(ticks!=null?{ticks,seconds:+(ticks*secondsPerTick).toFixed(3)}:{}),note:own.note,kind:own.kind});
  const lastBar=phrase-1,barSeconds=bar*secondsPerTick,accent=v+BATTERY.accent;
  // (A roll into the join's downbeat from the last bar's first felt beat that leaves no more than a roll's length: the
  // whole bar where it is short enough, its last beat where none is.)
  const rollFrom=groups.find(tick=>(bar-tick)*secondsPerTick<=BATTERY.rollSeconds+1e-9)??groups.at(-1);
  const rollIn=()=>strike({bar:lastBar,tick:rollFrom},{stroke:'roll',velocity:v,ticks:bar-rollFrom});
  // (In a hocket its metric pattern is the canon's (below); of its own only the form's gestures: a roll into the join
  // where it rolls, a swell that peaks on it.)
  if(hocket){
    if((instrument==='snare'||instrument==='tambourine')&&announcing&&!final)rollIn();
    if(instrument==='suspended'&&announcing&&!final){const from=Math.max(0,phrase-Math.max(1,Math.floor(BATTERY.swellSeconds/barSeconds)));strike({bar:from,tick:0},{stroke:'swell',velocity:Math.max(v,.5),ticks:(phrase-from)*bar})}
  }else if(instrument==='bassDrum'){
    for(let b=0;b<phrase;b++)if(b===0||level>=BATTERY.everyBar||(final&&b===lastBar))strike({bar:b,tick:0},{velocity:b===0&&(arriving||final)?accent:b===0?v:v*.85});
  }else if(instrument==='cymbals'){
    if(arriving||final)strike({bar:0,tick:0},{velocity:accent});
    if(level>=BATTERY.midPhrase&&phrase>1)strike({bar:Math.floor(phrase/2),tick:0});
    if(final&&lastBar>0)strike({bar:lastBar,tick:0},{velocity:accent});
  }else if(instrument==='suspended'){
    if(!announcing||final||level<.25)strike({bar:0,tick:0},{velocity:v*.8});
    if(announcing&&!final){
      // (Begun at the latest bar from which the join is no further than the longest swell rises: the swell itself is the
      // kit's, the one whose peak comes in time, begun so that it peaks on the join.)
      const from=Math.max(0,phrase-Math.max(1,Math.floor(BATTERY.swellSeconds/barSeconds)));
      strike({bar:from,tick:0},{stroke:'swell',velocity:Math.max(v,.5),ticks:(phrase-from)*bar});
    }
  }else if(instrument==='snare'){
    // (Its ostinato, drawn once for the phrase: the groups accented, a share of the other ticks tapped.)
    const share=(BATTERY.taps[0]+(BATTERY.taps[1]-BATTERY.taps[0])*clamp01(level))*(1-Math.max(0,Math.min(1,pulse||0))),taps=[];
    for(let tick=0;tick<bar;tick++)if(!groups.includes(tick)&&random()<share)taps.push(tick);
    const rolling=announcing&&!final;
    for(let b=0;b<phrase;b++)for(let tick=0;tick<(rolling&&b===lastBar?rollFrom:bar);tick++){
      if(groups.includes(tick))strike({bar:b,tick},{velocity:tick===0?accent:v});
      else if(taps.includes(tick))strike({bar:b,tick},{velocity:v*BATTERY.tap});
    }
    if(rolling)rollIn();
  }else if(instrument==='tambourine'){
    const rolling=announcing&&!final;
    for(let b=0;b<phrase;b++)for(const tick of groups)if(!(rolling&&b===lastBar&&tick>=rollFrom))strike({bar:b,tick},{velocity:tick===0?accent:v*.8});
    if(rolling)rollIn();
  }else if(instrument==='triangle'){
    if(!final&&level<BATTERY.triangleRoll.below&&random()<BATTERY.triangleRoll.chance)strike({bar:0,tick:0},{stroke:'roll',velocity:v,ticks:Math.min(phrase*bar,Math.max(1,Math.round(BATTERY.rollSeconds/secondsPerTick)))});
    else{for(const tick of groups)strike({bar:0,tick},{velocity:tick===0?v:v*.8});if(final&&lastBar>0)strike({bar:lastBar,tick:0})}
  }
  // (Its groove: the meter's positions it takes at its pulse, each bar, where it is not already struck nor holding a
  // roll or a swell; in the piece's last phrase none after the last bar's downbeat.)
  const groove=BATTERY.groove[instrument],heard=Math.max(0,Math.min(1,((pulse||0)-groove.from)/(1-groove.from)));
  // (In a hocket, its cell at its entry each bar, every tick of it -- the canon's, whatever its instrument's floor.)
  if(hocket){
    const sub=Math.max(1,Math.round(bar/(Number(meter?.numerator)||bar))),weight=tick=>tick===0?1:groups.includes(tick)?.75:tick%sub===0?.5:.25;
    const held=out.filter(s=>s.stroke!=='hit').map(s=>[(s.bar*bar+s.tick)*secondsPerTick,(s.bar*bar+s.tick)*secondsPerTick+s.seconds]),struck=new Set(out.map(s=>`${s.bar}:${s.tick}`));
    for(let b=0;b<phrase;b++)for(const slot of hocket.cell){const tick=(slot+hocket.entry)%bar,at=(b*bar+tick)*secondsPerTick;
      if(struck.has(`${b}:${tick}`)||(final&&b===lastBar&&tick>0)||held.some(([from,to])=>at>=from-1e-9&&at<to-1e-9))continue;
      strike({bar:b,tick},{velocity:v*(BATTERY.tap+(1-BATTERY.tap)*weight(tick))})}
  }else if(heard>0){
    const sub=Math.max(1,Math.round(bar/(Number(meter?.numerator)||bar))),weight=tick=>tick===0?1:groups.includes(tick)?.75:tick%sub===0?.5:.25;
    const draws=Array.from({length:bar},()=>random()),held=out.filter(s=>s.stroke!=='hit').map(s=>[(s.bar*bar+s.tick)*secondsPerTick,(s.bar*bar+s.tick)*secondsPerTick+s.seconds]);
    const struck=new Set(out.map(s=>`${s.bar}:${s.tick}`));
    for(let b=0;b<phrase;b++)for(let tick=0;tick<bar;tick++){
      const w=weight(tick),at=(b*bar+tick)*secondsPerTick;
      if(w<groove.floor||!pulsed(w,heard,draws[tick])||struck.has(`${b}:${tick}`)||(final&&b===lastBar&&tick>0)||held.some(([from,to])=>at>=from-1e-9&&at<to-1e-9))continue;
      strike({bar:b,tick},{velocity:v*(BATTERY.tap+(1-BATTERY.tap)*w)});
    }
  }
  // (A stroke written to the next, a beat at most -- a stroke is short, its rest after it; a roll or a swell its own ticks.)
  const sorted=out.sort((a,b)=>a.bar-b.bar||a.tick-b.tick),beat=Math.max(1,Number(meter?.subdivision)||1),place=s=>s.bar*bar+s.tick;
  sorted.forEach((s,k)=>{if(s.ticks==null)s.ticks=Math.max(1,Math.min(beat,(sorted[k+1]?place(sorted[k+1]):phrase*bar)-place(s)))});
  return sorted;
}
