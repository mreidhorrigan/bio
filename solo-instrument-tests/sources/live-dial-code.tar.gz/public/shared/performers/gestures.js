// Counted gestures: a drummer's contacts as counts, spans, hands and graces, kept exact. The rudiments report
// (research/MUSEBOTS_ODD_PRIME_RUDIMENTS_KIT_ORCHESTRATION_AND_STROKE_ACOUSTICS.md §§2–4; its reference kernels, §15,
// ported here onto the project's own rationals) and its M1: five, seven, eleven, thirteen or any count of contacts,
// over whatever span a phrase gives them, independently of the meter's subdivision.
//
// **Counts are kept apart** (§2.1): a span's slots, the slots occupied (a rest keeps its slot), the principal contacts,
// the grace contacts (a flam's grace is a contact but not a slot), the distinct onset times, and the motor actions (a
// rebound pair is one action, two contacts). A roll's count is not a tuplet: five contacts can be an equal quintuplet
// over a beat, or a compressed opening with a release (weights), and eleven over two beats is not eleven a beat.
//
// **Time is the clock's ticks, exactly**: positions and spans are Rationals of ticks (public/transcript/rational.js), so
// 5, 7, 11 and 13 slots need no common grid (their LCM is 5005) and a nested slot keeps its exact place. A contact
// becomes a time only where it is played: at a tick, with its offset after that tick (dueAt), and a grace its seconds
// before its principal, which do not stretch with a slow beat or shrink with a fast one (§4.2).
//
// **Hands** are R and L; a counted roll is (n − 1)/2 pairs, one hand each and alternating, and a release (§3.1); odd
// alternating singles hand their lead to the next cell (§3.2), and a repeated cell's boundary can make a triple stroke
// (§3.5), which boundaryRuns finds. Which surface each contact strikes, and which limb can reach it, is the next
// milestone's (orchestration, on the performer contract), not this file's.
import {Rational,lcm} from '../../transcript/rational.js';
import {scoreTime,graceTime} from '../score-time.js';

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const GESTURES=Object.freeze({
  // The most slots one span may hold (the report's bound: a count, not a grid).
  mostSlots:4096,
  hands:Object.freeze(['R','L']),
  // The fewest contacts a counted roll has: two pairs' worth is five, but three (a pair and a release) is the smallest
  // the constructor makes.
  leastRoll:3,
  // A run of this many strokes by one hand across a boundary is a triple stroke (§3.5).
  tripleRun:3,
  // How many scheduled contacts (and collisions) a contact ledger keeps: well over the densest fill's.
  contactsKept:256,
});
const other=hand=>{if(hand==='R')return 'L';if(hand==='L')return 'R';throw new TypeError(`a hand is R or L, not ${hand}`)};
const count=(n,least=1)=>{if(!Number.isSafeInteger(n)||n<least||n>GESTURES.mostSlots)throw new RangeError(`a count is ${least} to ${GESTURES.mostSlots}, not ${n}`);return n};

// ---- Slots -----------------------------------------------------------------------------------------------------------
// n slots over `span` ticks from `start`: equal, or by positive integer weights, the last weight reaching the span's end
// (a release, not another hit). [{index, at, duration}], each a Rational of ticks.
export function slots({n,start=0,span=1,weights=null}={}){
  count(n);
  const from=Rational.of(start),length=Rational.of(span);
  if(length.sign()<=0)throw new RangeError('a span must be positive');
  const w=weights??Array(n).fill(1);
  if(w.length!==n||w.some(weight=>!Number.isSafeInteger(weight)||weight<=0))throw new RangeError('one positive integer weight per slot');
  const total=w.reduce((a,b)=>a+b,0);let at=0;
  return w.map((weight,index)=>{
    const slot=Object.freeze({index,at:from.add(length.mul(new Rational(at,total))),duration:length.mul(new Rational(weight,total))});
    at+=weight;return slot;
  });
}
// A point inside a slot, `childAt` of the way through it (in [0, 1)): a nested tuplet's place, exactly.
export function inside(slot,childAt){
  const within=Rational.of(childAt);
  if(within.sign()<0||within.ge(1))throw new RangeError('a point inside a slot lies in [0, 1) of it');
  return slot.at.add(slot.duration.mul(within));
}
// How many contacts two cycles take to come round together: lcm(a, b), which is phase, not complexity (§2.4).
export const phasePeriod=(a,b)=>lcm(count(a),count(b));

// ---- Stickings -------------------------------------------------------------------------------------------------------
// A counted roll of n (odd, from three): (n − 1)/2 pairs, each one hand's two contacts (one action, a rebound pair),
// alternating, then a release in the next hand. [{hand, action, inAction}].
export function countedRoll(n,lead='R'){
  count(n,GESTURES.leastRoll);if(n%2===0)throw new RangeError(`a counted roll is odd, not ${n}`);other(lead);
  const out=[];let hand=lead;
  for(let pair=0;pair<(n-1)/2;pair++){out.push({hand,action:`pair-${pair}`,inAction:0},{hand,action:`pair-${pair}`,inAction:1});hand=other(hand)}
  out.push({hand,action:'release',inAction:0});
  return out;
}
// n alternating singles, each its own action.
export function singles(n,lead='R'){
  count(n);other(lead);
  return Array.from({length:n},(_,i)=>({hand:i%2?other(lead):lead,action:`stroke-${i}`,inAction:0}));
}
// The hand that leads next: after alternation, the one that did not play last (an odd cell hands the lead over).
export const nextLead=cell=>other(cell.at(-1).hand);
// A cycle of hands (or anything) continued over n more, from `phase`: the phase survives chunks and barlines (§3.2).
export function continued(pattern,n,phase=0){
  count(n);
  if(!Array.isArray(pattern)||!pattern.length||pattern.length>GESTURES.mostSlots)throw new RangeError('a pattern of 1 to the most slots');
  if(!Number.isSafeInteger(phase)||phase<0)throw new RangeError('a phase is a whole number from 0');
  return {sequence:Array.from({length:n},(_,i)=>pattern[(phase+i)%pattern.length]),nextPhase:(phase+n)%pattern.length};
}
// Runs of one hand of `tripleRun` or more across a sequence of cells (hands), with where each starts: the triple
// strokes a repeated cell's boundary can make (RRLLR | RRLLR has RRR).
export function boundaryRuns(hands,{least=GESTURES.tripleRun}={}){
  const runs=[];let start=0;
  for(let i=1;i<=hands.length;i++)if(i===hands.length||hands[i]!==hands[start]){if(i-start>=least)runs.push({hand:hands[start],start,length:i-start});start=i}
  return runs;
}

// ---- Gestures --------------------------------------------------------------------------------------------------------
// A gesture: `n` contacts' slots over `span` ticks from `start` (equal, or by `weights`), some slots left as rests,
// played in a sticking ('roll', 'singles', or a list for the occupied slots of hands, or of {hand, action}: contacts
// sharing an action are one, as a rudiment's rebound pair is), with graces before some of them.
// graces: [{slot, count (1 a flam, 2 a drag), seconds (each grace's gap before the next contact)}]; a grace is the other
// hand's. Returns {id, contacts: [{id, slot, at, duration?, hand, action, role, before?, of?}], counts, exit}, where `before` is a
// grace's seconds before its principal and `role` is principal, release (a roll's last) or grace.
export function gesture({id='gesture',n,start=0,span=1,weights=null,rests=[],sticking='singles',lead='R',graces=[]}={}){
  const places=slots({n,start,span,weights}),resting=new Set(rests);
  for(const rest of resting)if(!Number.isSafeInteger(rest)||rest<0||rest>=n)throw new RangeError(`a rest names a slot 0 to ${n-1}, not ${rest}`);
  const occupied=places.filter(slot=>!resting.has(slot.index));
  if(!occupied.length)throw new RangeError('a gesture with no contact');
  const hands=Array.isArray(sticking)?sticking.map(entry=>typeof entry==='string'?{hand:entry,action:null,inAction:0}:{hand:entry?.hand,action:entry?.action??null,inAction:0})
    :sticking==='roll'?countedRoll(occupied.length,lead):singles(occupied.length,lead);
  if(hands.length!==occupied.length)throw new RangeError(`a sticking of ${hands.length} for ${occupied.length} contacts`);
  const contacts=[];
  occupied.forEach((slot,k)=>{
    const {hand,action}=hands[k];other(hand);
    const contact={id:`${id}:${slot.index}`,slot:slot.index,at:slot.at,duration:slot.duration,hand,action:`${id}:${action??`stroke-${k}`}`,role:sticking==='roll'&&k===occupied.length-1?'release':'principal'};
    for(const grace of graces.filter(grace=>grace.slot===slot.index)){
      const number=Math.max(1,Math.trunc(grace.count??1)),seconds=Number(grace.seconds);
      if(!(seconds>0))throw new RangeError('a grace needs its seconds before the stroke');
      for(let g=number;g>=1;g--)contacts.push({id:`${contact.id}:grace-${number-g}`,slot:null,at:slot.at,before:seconds*g,hand:other(hand),action:`${id}:grace-${slot.index}`,role:'grace',of:contact.id});
    }
    contacts.push(contact);
  });
  const principals=contacts.filter(contact=>contact.role!=='grace');
  const onsets=new Set(contacts.map(contact=>`${contact.at}:${contact.before??0}`));
  return Object.freeze({id,start:Rational.of(start),span:Rational.of(span),contacts,
    counts:Object.freeze({slots:n,occupied:occupied.length,principals:principals.length,graces:contacts.length-principals.length,contacts:contacts.length,
      onsets:onsets.size,actions:new Set(contacts.map(contact=>contact.action)).size}),
    exit:Object.freeze({hand:principals.at(-1).hand,lead:other(principals.at(-1).hand)})});
}
// Retain the chosen gesture's composed slots before converting contacts to sound times. A second drum struck with
// a principal keeps its interval; an explicitly declared grace attaches to it. Neither uses physical spacing.
export function scoredGesture(played,{axis='ensemble',graceType='16th'}={}){
  const byId=new Map(played.contacts.map(contact=>[contact.id,contact])),orders=new Map;
  const idOf=contact=>`${contact.id}@${played.start}`;
  return {...played,contacts:played.contacts.map(contact=>{
    const principal=contact.of?byId.get(contact.of):contact;
    if(!principal)throw new TypeError(`contact ${contact.id} needs its declared principal ${contact.of}`);
    let written;
    if(contact.role==='grace'){
      const order=orders.get(principal.id)??0;orders.set(principal.id,order+1);
      written=graceTime(principal.at,{axis,anchor:idOf(principal),order,type:contact.type??graceType});
    }else written=scoreTime(principal.at,principal.duration,{axis});
    return {...contact,scoreId:idOf(contact),scoreTime:written};
  })};
}
// A buzz roll (§6 F7): a continuous roll over `span` ticks from `start`, a texture and not a count. Its strokes are the
// hands' pressed buzz strokes, alternating at `strokesPerTick` (a whole number or a Rational), each sounding many
// bounces the listener does not count; so its contract says it exposes no count, where a counted gesture's does
// (gesture: counts.contacts). Its contacts are motor actions, the renderer's buzz stroke (percussion-expression.js PIECES
// snare.buzz), never taps passed off as one.
// {id, kind: 'buzz-roll', countExposed: false, start, span, contacts: [{id, at, hand, action, role: 'texture', stroke}]}
export function buzzRoll({id='buzz',start=0,span=1,strokesPerTick=1,lead='R'}={}){
  const from=Rational.of(start),length=Rational.of(span),per=Rational.of(strokesPerTick),strokes=length.mul(per);
  if(!(length.toNumber()>0)||!(per.toNumber()>0)||!strokes.isInteger())throw new RangeError('a buzz roll spans a positive time in whole strokes');
  const contacts=Array.from({length:strokes.toNumber()},(_,k)=>{const hand=k%2?other(lead):lead;
    return {id:`${id}:${k}`,at:from.add(Rational.of(k).div(per)),hand,action:`${id}:stroke-${k}`,role:'texture',stroke:'buzz'}});
  return Object.freeze({id,kind:'buzz-roll',countExposed:false,start:from,span:length,contacts});
}
// The contacts to sound in the tick from `tick` to the next: [{contact, offset}], `offset` in ticks after `tick` (a
// grace `before` seconds ahead of its principal at `secondsPerTick`, so it may fall in the tick before).
export function dueAt(played,tick,{secondsPerTick}){
  const from=Rational.of(tick),to=from.add(1),due=[];
  if(!(secondsPerTick>0))throw new RangeError('dueAt needs the seconds a tick lasts');
  for(const contact of played.contacts){
    const early=(contact.before??0)/secondsPerTick,at=contact.at.toNumber()-early;
    if(at>=from.toNumber()&&at<to.toNumber())due.push({contact,offset:at-from.toNumber()});
  }
  return due.sort((a,b)=>a.offset-b.offset);
}

// ---- Accounting and the ensemble's policy ----------------------------------------------------------------------------
// Contacts, onsets and actions among contacts given as {id, action, at, target?, limb?, kick?, performer?}: one id twice
// is one contact (a sample layer, a microphone), unless the two disagree about what it is, which is an error.
export function countContacts(list){
  const ids=new Map,times=new Set,actions=new Set;
  for(const contact of list){
    if(!contact?.id||!contact.action)throw new TypeError('a contact needs its id and its action');
    const time=String(contact.at),signature=JSON.stringify([time,contact.action,contact.target??null,contact.limb??null,Boolean(contact.kick),contact.performer??null]);
    if(ids.has(contact.id)&&ids.get(contact.id)!==signature)throw new Error(`contact ${contact.id} is two different things`);
    ids.set(contact.id,signature);times.add(time);actions.add(contact.action);
  }
  return {contacts:ids.size,onsets:times.size,actions:actions.size};
}
// The user's policy, at exact times: no two independent kick contacts at once across the ensemble, whoever plays them.
// Layers of one contact (one id) are one kick; kicks a moment apart are not at once. [{at, ids}] for each breach.
export function kickConflicts(list){
  countContacts(list);
  const byTime=new Map;
  for(const contact of list)if(contact.kick){const key=String(contact.at);if(!byTime.has(key))byTime.set(key,new Set);byTime.get(key).add(contact.id)}
  return [...byTime].filter(([,ids])=>ids.size>1).map(([at,ids])=>({at,ids:[...ids]}));
}
// Contacts as they are scheduled, a bounded window of them per target, checked at the render's boundary (T12): a
// distinct contact that lands on the output sample another already holds on the same target is a collision. It is
// reported, and both still sound (explicitly realized, never silently one deleted). One contact's layers (one id) are
// not a collision.
export class ContactLedger{
  constructor({sampleRate,keep=GESTURES.contactsKept}={}){
    if(!(sampleRate>0))throw new RangeError('a contact ledger needs the sample rate');
    this.sampleRate=sampleRate;this.keep=keep;this.recent=[];this.collisions=[];
  }
  // A contact {id, seconds, target}: the collision it makes ({sample, target, ids}) or null.
  add({id,seconds,target=null}){
    if(!id||!Number.isFinite(seconds))throw new TypeError('a contact needs its id and its time');
    const sample=Math.round(seconds*this.sampleRate);
    const others=this.recent.filter(contact=>contact.sample===sample&&contact.target===target&&contact.id!==id).map(contact=>contact.id);
    this.recent.push({id,sample,target});if(this.recent.length>this.keep)this.recent.shift();
    if(!others.length)return null;
    const collision={sample,target,ids:[...new Set([...others,id])]};
    this.collisions.push(collision);if(this.collisions.length>this.keep)this.collisions.shift();
    return collision;
  }
}
// Distinct contacts that land on one output sample once converted (the render's boundary, T12): [{sample, ids}].
export function sampleCollisions(list,{sampleRate}){
  if(!(sampleRate>0))throw new RangeError('sampleCollisions needs the sample rate');
  const bySample=new Map;
  for(const {id,seconds} of list){const sample=Math.round(seconds*sampleRate);if(!bySample.has(sample))bySample.set(sample,new Set);bySample.get(sample).add(id)}
  return [...bySample].filter(([,ids])=>ids.size>1).map(([sample,ids])=>({sample,ids:[...ids]}));
}
