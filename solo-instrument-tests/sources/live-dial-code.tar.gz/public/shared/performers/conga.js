// A conga player's figure (the family atlas's F32, hand drums; conguero_clodbot.js plays it): two hands on a conga and a
// tumba, one keeping time and the other speaking.
//
// **The tumbao, taken as a principle.** The conga's basic tumbao, as the tradition writes it over a bar of eighths, is
// "H T S T H T O O": heel, tip, slap, tip, heel, tip, open, open, played L L R L L L R R, "the primary strokes ...
// sounded with open tones, on the last offbeats ... of a two-beat cycle" (Wikipedia, "Tumbao", accessed 29 September
// 2026). Its parts, stated by the meter rather than by 4/4, give a figure in any meter:
//   - one hand keeps time, rocking heel and tip on every pulse the other hand leaves: the heel where the meter is
//     stronger than on either side, the tip between;
//   - its heels mark the two main beats: the downbeat, and the group's head nearest the middle of the bar (in 4/4, beat
//     three; in 12/8, the third dotted quarter; in 7/8 as 2+2+3, the third group);
//   - the other hand's slap sounds the backbeat: the strongest pulse nearest halfway between them (in 4/4, beat two);
//   - and its open tones lead into the downbeat on the bar's last two pulses, which they do not accent.
// In 4/4 this is the tumbao itself. The name stays with the tradition: elsewhere it is a figure built the same way.
//
// **Its voice grows with the band's complexity**: past a third, an open tone leads into the middle heel as well; past
// two thirds, the last open tone moves to the tumba, the low drum answering the high (the tradition's two-drum variant).
//
// **Playable by construction.** Its pulse is the finest that divides the beat and that two hands alternating can play
// (shaker.js strokeStride: a drummer's alternating singles). The speaking hand strikes again only after a whole stroke
// (the drummer's prepare and recover); where it cannot, the time-keeping hand, free there, takes the stroke. The
// time-keeping hand rocks heel and tip at any pulse (a rocking pair, quicker than a stroke); two tips in a row, which it
// strikes again, it plays only a whole stroke apart, else the second is a heel, rocking on.
import {DRUMMER} from './drummer.js';

export const CONGA=Object.freeze({
  // A hand's whole stroke, prepare and recover (the drummer's).
  strokeSeconds:DRUMMER.prepareSeconds+DRUMMER.recoverSeconds,
  // The band's complexity past which an open tone leads into the middle heel, and past which the tumba answers.
  leadInFrom:1/3,tumbaFrom:2/3,
  // Each stroke's level against the player's own (ours: the filler under the voice, the slap its accent).
  levels:Object.freeze({heel:.45,tip:.4,slap:1.1,open:.95}),
});

// The positions of a bar's main beats, backbeat and lead-in, from its metric strengths (each 0 to 1, the downbeat 1)
// and its groups' heads (the pulses where the meter's groups begin).
export function congaPlaces(strengths,heads=[0]){
  const n=strengths.length,middle=n/2;
  const others=heads.filter(at=>at>0&&at<n);
  // The second main beat: the group's head nearest the middle, the later on a tie; none in a bar of one group.
  const second=others.length?others.reduce((best,at)=>Math.abs(at-middle)<Math.abs(best-middle)||(Math.abs(at-middle)===Math.abs(best-middle)&&at>best)?at:best):null;
  // The backbeat: halfway to the second main beat (or to the bar's end), the strongest pulse nearest it, the earlier on
  // a tie, never the downbeat.
  const toward=second??n,half=toward/2;
  let backbeat=null;
  for(let at=1;at<toward;at++){
    if(backbeat===null){backbeat=at;continue}
    const better=(strengths[at]??0)>(strengths[backbeat]??0)+1e-9
      ||(Math.abs((strengths[at]??0)-(strengths[backbeat]??0))<=1e-9&&Math.abs(at-half)<Math.abs(backbeat-half)-1e-9);
    if(better)backbeat=at;
  }
  return {second,backbeat,leadIn:n>=4?[n-2,n-1]:[n-1]};
}

// A bar's figure at the stroke pulse: for each pulse (0 to n - 1), {stroke, drum, voice}: the voice's slap and open tones
// where congaPlaces puts them (the lead-in into the middle heel and the tumba's answer as the complexity asks), the time
// kept on every other pulse, heel where the meter is stronger than on either side, else tip.
export function congaFigure(strengths,{heads=[0],complexity=0}={},{leadInFrom,tumbaFrom}=CONGA){
  const n=strengths.length,{second,backbeat,leadIn}=congaPlaces(strengths,heads),out=[];
  const voice=new Map;
  for(const at of leadIn)voice.set(at,{stroke:'open',drum:'conga'});
  if(complexity>=tumbaFrom&&leadIn.length>1)voice.set(leadIn.at(-1),{stroke:'open',drum:'tumba'});
  if(complexity>=leadInFrom&&second!==null&&second-1>(backbeat??0))voice.set(second-1,{stroke:'open',drum:'conga'});
  if(backbeat!==null&&!voice.has(backbeat))voice.set(backbeat,{stroke:'slap',drum:'conga'});
  for(let at=0;at<n;at++){
    if(voice.has(at)){out.push({...voice.get(at),voice:true});continue}
    const here=strengths[at]??0,before=strengths[(at-1+n)%n]??0,after=strengths[(at+1)%n]??0;
    out.push({stroke:at===0||at===second||(here>before+1e-9&&here>after+1e-9)?'heel':'tip',drum:'conga',voice:false});
  }
  return out;
}

// A hand's next stroke after its last (each {stroke, voice}): a heel and a tip keeping time rock, as quick as a rebound
// (the drummer's doubles); anything else is a whole stroke.
const rocks=(last,next)=>last&&!last.voice&&!next.voice&&last.stroke!==next.stroke;
const spacing=(last,next,{strokeSeconds})=>rocks(last,next)?Math.max(DRUMMER.reboundSeconds,strokeSeconds/3):strokeSeconds;

// Which hand plays each of a figure's strokes, the pulse `seconds` long, the bar played again and again: each by its own
// hand (the voice the right, the time the left) where that hand is free, else by the other where it is; a tip no hand is
// free for becomes a heel where that lets the left hand rock on. Returns the strokes with their hands, a stroke no hand
// could play left out (null: none, at the pulse strokeStride gives).
export function congaHands(figure,seconds,choices=CONGA){
  const n=figure.length,last={R:null,L:null},at={R:-Infinity,L:-Infinity},out=[];
  const free=(hand,stroke,time)=>time-at[hand]>=spacing(last[hand],stroke,choices)-1e-9;
  // Two bars, the second's hands kept: its first strokes follow the first bar's last.
  for(let pass=0;pass<2;pass++)for(let pulse=0;pulse<n;pulse++){
    const time=(pass*n+pulse)*seconds;let stroke={...figure[pulse]};
    const own=stroke.voice?'R':'L',other=own==='R'?'L':'R';
    let hand=free(own,stroke,time)?own:free(other,stroke,time)?other:null;
    if(!hand&&stroke.stroke==='tip'){const heel={...stroke,stroke:'heel'};if(free('L',heel,time)){stroke=heel;hand='L'}}
    if(hand){at[hand]=time;last[hand]=stroke}
    if(pass===1)out.push(hand?{...stroke,hand}:null);
  }
  return out;
}
