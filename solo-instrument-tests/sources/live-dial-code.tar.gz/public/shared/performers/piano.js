// A pianist's hands, feet and pedals on a keyboard: which digit plays each note of a passage, when each key is let go,
// and which pedal keeps a note sounding once its key is up, found for whole event groups and searched non-greedily
// through the performer contract (contract.js, keyboard.js). The general performer–instrument report's M2
// (research/MUSEBOTS_GENERAL_PERFORMER_INSTRUMENT_CONSTRAINTS.md §4).
//
// **Geometry, not MIDI distance** (§4.2): keys have positions in millimetres. A white key is 23.5 mm wide, so an octave
// spans 164.5 mm, and a black key's centre is taken at the boundary of the two white keys it sits between. That is an
// authored approximation of a standard keyboard; a measured layout replaces it as data. A fixed-tuned keyboard has no key
// for a pitch between its keys, so such a pitch is refused, never rounded (§4.8), unless the keyboard's declared setup has
// a key that sounds it: two manuals a quarter tone apart, an octave retuned (keyboardSetup). A note names its pitch and is
// planned as the key that sounds it; between sections on different setups each change takes its own time, and a retuning
// a tuner (planSections).
//
// **Hands and feet from the profile** (§4.5, §4.6): the digits a hand has are the profile's (keyboard.js pianist), in
// order along the keyboard. A pedal is the player's only where the profile maps it to an available controller (a foot, a
// knee lever, a switch: contract.js controlOf), and the instrument has it (PIANO.pedals): no mapping, no pedal, however
// many feet; a mapping through a knee lever, a pedal, whatever the feet (F02).
//
// **Four durations kept apart** (§4.4): each note's written length, how long its key is held, what holds its dampers off
// after that (the sustain, the sostenuto's capture, or no damper at all above UNDAMPED), and how long a piano note rings
// (articulation.js pianoRing). A key may be let go early when something else keeps its note sounding, and a hand leaves
// for a far place only once it has let go. A note may stop sounding a little before or after its written end
// (PIANO.tolerance): a slightly detached release, a pedal lifted just after; beyond that, a pedal would smear it, and
// the plan does not do that silently. A note marked `legato` sounds to its written end, never early: a finger that
// strikes again at once lifts first (PIANO.fingerSeconds), so it joins two notes only by sliding from a black key onto
// the white beside it; another finger or a pedal joins the rest.
//
// **Whole event groups, then transitions** (§4.3). Notes starting together are one group; the ends of notes are points
// too, where a pedal may lift. A configuration gives each of a group's keys a hand and a digit; keys still held keep the
// digit that struck them (B01), or change it by a silent substitution when there is time (§4.3). A key struck again needs
// its release and reset first (B03). The search keeps every distinct state within a budget, so a locally easy choice that
// blocks what follows loses to one that does not (B04). With no path, it tries the explicit alternatives (a rolled chord
// where the part allows its onsets to spread, a delayed bass, an octave moved, a doubling left out) and offers each with
// its own plan or its own reason (§4.6, F01); a pedal never stands in for a simultaneous attack.
import {action,checkEnvelope,checkReservations,controlOf,searchGroups,STATUS,witness} from './contract.js';
import {keyboard,onKeyboard,pianist} from './keyboard.js';
import {UNDAMPED,pianoRing} from '../articulation.js';
import {instrumentRange} from './instrument-ranges.js';

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const PIANO=Object.freeze({
  // A standard keyboard's white key (mm), which of an octave's twelve keys are white (C = 0), and its keys, A0 to C8 (the
  // instrument registry's 88-key piano, instrument-ranges.js).
  whiteKeyMm:23.5,whites:Object.freeze([0,2,4,5,7,9,11]),lowestKey:instrumentRange('piano').range[0],highestKey:instrumentRange('piano').range[1],
  // Authored reach (mm) between two digits of one hand at once, by how many digits apart they are counted from the
  // thumb: the thumb opens widest; neighbouring fingers barely. About a ninth from thumb to little finger.
  reach:Object.freeze({thumbPair:Object.freeze([0,140,165,185,200]),fingerStep:55}),
  // Authored: how fast a hand crosses the keyboard between groups (mm a second), and the least time a key needs between
  // its release and its next stroke (s).
  travel:Object.freeze({mmPerSecond:2000,resetSeconds:.03}),
  // Authored: the least time a key is held for its hammer to strike (s), and how long a silent finger substitution on a
  // held key takes (s: the new finger arrives before the old leaves).
  strokeSeconds:.03,substitutionSeconds:.1,
  // Authored: how long a finger takes to leave one key and strike another (s). Quicker than that it slides, from a black
  // key onto the white key beside it (§4.3): the one way a finger joins two notes legato.
  fingerSeconds:.04,
  // The instrument's pedals (a grand's damper and sostenuto; its soft pedal changes tone, not length, and is M4's), how
  // long a controller takes to put one down or let it up (s, authored), and the lowest key with no damper.
  pedals:Object.freeze(['sustain','sostenuto']),pedalSeconds:.08,undampedFrom:UNDAMPED,
  // The soft pedal (una corda): it shifts the hammers so a note is struck softer and darker, and holds nothing. A note
  // asks for it (soft: true) or against it (soft: false); it is put down and let up through its controller like the
  // others, which it may share with one of them (a left foot's una corda and sostenuto): one at a time.
  tonePedals:Object.freeze(['soft']),
  // Half-pedalling: the sustain put down part way, its dampers touching the strings, so a key let go sounds on for this
  // share of its ring (articulation.js pianoRing) and dies away: a bass rings on under the harmony changing above it,
  // and each treble note is gone soon after its key. Authored; null where the player does not half-pedal.
  halfPedal:Object.freeze({share:.1}),
  // The part's tolerances, authored defaults a part may set as its own (§9's preservation contract): how much earlier or
  // later than written a note may stop sounding (s), and how far a group's onsets may spread (s; 0: struck together).
  tolerance:Object.freeze({early:.05,late:.05,onset:0}),
  // A rolled chord's first spread between its onsets (s), doubled until it plays or passes the part's onset tolerance.
  rollSeconds:.03,
  // Notes starting within this of each other are one group (s).
  together:.005,
  // Costs, all authored: a millimetre of travel; a stretch beyond half a hand's reach; a thumb on a black key; a pedal
  // put down; a key let go early to a pedal; a silent substitution; each second a note sounds off its written end; a
  // hand's chord asking a voicing outside the known ones (so a voice the other hand could take is given to it); a
  // finger's slide.
  cost:Object.freeze({travelPerMm:.01,stretchPerMm:.02,thumbOnBlack:1,pedal:.5,pedalHold:.1,substitution:.5,offPerSecond:2,voicingOutside:5,slide:.3}),
  // The most distinct states the search keeps at a point; past that, the cheapest `beamStates` go on (a plan found so is
  // marked pruned: a witness, not proved the cheapest; none found, a budget run out). A legato line, either hand any
  // digit on every note and the pedals free, passes 1024 within a few notes.
  maxStates:1024,beamStates:256,
  // A setup's keys (§4.8): how near a key's pitch is to a note's to sound it (semitones: a cent), and how far a hand
  // moves between the same key on neighbouring manuals (mm, authored: up and back, as on a two-manual keyboard).
  pitchTolerance:.01,manualStepMm:100,
  // A change of setup between sections, all authored: a key retuned (its strings, by a tuner), a preparation put in or
  // taken out (by the player, or an assistant), an electronic layout remapped (one control action); seconds each.
  changes:Object.freeze({retune:Object.freeze({seconds:45,by:'tuner'}),prepare:Object.freeze({seconds:20,by:'player'}),remap:Object.freeze({seconds:.5,by:'player'})}),
  // A hand's voicing (§4.7, §7.2; E02, E03): the levels one hand's chord may ask of its notes at once (dB, a note's
  // `level`), as the joint combinations known, all authored: balanced; its top note brought out over the rest, which
  // stay together; its bottom note so. An inner voice brought out, or two levels among the rest, is in no region, so the
  // check abstains there: a pianist may well play it, but nothing here says so. `spread` is the chord's range of levels,
  // `top` and `bottom` how far that note stands over the loudest of the rest, `restTop` and `restBottom` the range of
  // the rest.
  voicing:Object.freeze({id:'piano-voicing',status:'authored',context:Object.freeze({instrument:'piano'}),regions:Object.freeze([
    Object.freeze({id:'balanced',bounds:Object.freeze({spread:Object.freeze([0,1.5])})}),
    Object.freeze({id:'top voice',bounds:Object.freeze({top:Object.freeze([0,12]),restTop:Object.freeze([0,1.5])})}),
    Object.freeze({id:'bottom voice',bounds:Object.freeze({bottom:Object.freeze([0,12]),restBottom:Object.freeze([0,1.5])})}),
  ])}),
});
const EVENT_ORDER=Object.freeze({down:0,release:1,substitute:2,up:3,press:4});
const PEDAL_EVENTS=Object.freeze({sustain:['sustainDown','sustainUp'],sostenuto:['sostenutoDown','sostenutoUp'],'half-sustain':['sustainHalfDown','sustainUp']});
const EPSILON=1e-9;

// ---- Geometry --------------------------------------------------------------------------------------------------------
const pitchClass=key=>((key%12)+12)%12;
// Each manual's keys are numbered as a piano's MIDI numbers are; across an instrument's manuals a key is its manual's
// index × MANUAL_KEYS + that number, so every key has one number (a one-manual keyboard's keys keep their own).
const MANUAL_KEYS=128;
export const keyOf=key=>key%MANUAL_KEYS,manualOf=key=>Math.floor(key/MANUAL_KEYS);
export const isBlack=key=>!PIANO.whites.includes(pitchClass(keyOf(key)));
// The centre of a key along the keyboard, in mm from C0's left edge: a white key's middle, a black key at the boundary of
// its two white neighbours.
export function keyX(key,{choices=PIANO}={}){
  if(!Number.isInteger(key))throw new RangeError(`a fixed keyboard has no key for pitch ${key}`);
  const physical=keyOf(key),octave=Math.floor(physical/12),pc=pitchClass(physical),whiteIndex=choices.whites.filter(white=>white<pc).length,octaveMm=7*choices.whiteKeyMm;
  return octave*octaveMm+(choices.whites.includes(pc)?(whiteIndex+.5)*choices.whiteKeyMm:whiteIndex*choices.whiteKeyMm);
}
// Where a hand is: {x} along the keyboard, {y} across its manuals.
const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);

// ---- Setups ----------------------------------------------------------------------------------------------------------
// A keyboard's declared setup (§4.8): its manuals, lowest first, each a row of keys and the pitch each sounds (fractional
// MIDI numbers): `transpose` (semitones above its number every key sounds), `retuned` ({key: pitch}, the keys a tuner has
// moved), `prepared` ({key: what}, a preparation between its strings), and its compass. `electronic`: its tuning is a
// table one control action changes, not strings a tuner moves. A fixed-tuned piano is one manual whose keys sound their
// own numbers. The pedals are the instrument's, over every manual.
export function keyboardSetup({id='fixed',manuals=[{id:'keys'}],electronic=false,tolerance=PIANO.pitchTolerance}={}){
  if(!manuals.length)throw new RangeError('a setup has a manual');
  const rows=manuals.map((manual,index)=>{
    if(typeof manual.id!=='string'||!manual.id)throw new TypeError('a manual has an id');
    const lowestKey=manual.lowestKey??PIANO.lowestKey,highestKey=manual.highestKey??PIANO.highestKey;
    if(!(Number.isInteger(lowestKey)&&Number.isInteger(highestKey)&&0<=lowestKey&&lowestKey<=highestKey&&highestKey<MANUAL_KEYS))throw new RangeError(`manual ${manual.id}: a compass of keys 0 to ${MANUAL_KEYS-1}`);
    const retuned=new Map(Object.entries(manual.retuned??{}).map(([key,pitch])=>[Number(key),Number(pitch)]));
    for(const [key,pitch] of retuned)if(!Number.isInteger(key)||key<lowestKey||key>highestKey||!Number.isFinite(pitch))throw new RangeError(`manual ${manual.id}: key ${key} retuned to ${pitch}`);
    const prepared=new Map(Object.entries(manual.prepared??{}).map(([key,what])=>[Number(key),what]));
    return Object.freeze({id:manual.id,index,transpose:manual.transpose??0,retuned,prepared,lowestKey,highestKey});
  });
  if(new Set(rows.map(row=>row.id)).size!==rows.length)throw new RangeError('each manual has its own id');
  const pitchOf=key=>rows[manualOf(key)].retuned.get(keyOf(key))??keyOf(key)+rows[manualOf(key)].transpose;
  // The keys sounding a pitch, manual by manual in their declared order.
  const keysFor=pitch=>{
    const out=[];
    for(const row of rows)for(let key=row.lowestKey;key<=row.highestKey;key++){const id=row.index*MANUAL_KEYS+key;if(Math.abs(pitchOf(id)-pitch)<=tolerance+EPSILON)out.push(id)}
    return out;
  };
  return Object.freeze({id,manuals:Object.freeze(rows),electronic,tolerance,pitchOf,keysFor,manualOf:key=>rows[manualOf(key)],
    name:key=>rows.length>1?`${rows[manualOf(key)].id}:${keyOf(key)}`:`${keyOf(key)}`});
}
export const FIXED=keyboardSetup();
// A note on a setup: {note} with its key (the instrument's number), pitch and manual, or {reason}. A note names its pitch
// (`pitch`, or `key` as a pitch: on a fixed keyboard a key's number is its pitch), found as the first key of the setup's
// manuals that sounds it; or a key itself, `key` on `manual`.
function onSetup(note,setup){
  if(note.manual!==undefined&&note.manual!==null){
    const row=setup.manuals.find(manual=>manual.id===note.manual);
    if(!row)return {reason:`the setup ${setup.id} has no manual ${note.manual}`};
    if(!Number.isInteger(note.key)||note.key<row.lowestKey||note.key>row.highestKey)return {reason:`manual ${row.id} has no key ${note.key}`};
    const key=row.index*MANUAL_KEYS+note.key;
    return {note:{...note,key,pitch:setup.pitchOf(key),manual:row.id}};
  }
  const pitch=note.pitch??note.key;
  if(typeof pitch!=='number'||!Number.isFinite(pitch))return {reason:`note ${note.id} names no pitch`};
  const key=setup.keysFor(pitch)[0];
  if(key===undefined)return {reason:`pitch ${pitch} has no key ${setup===FIXED?'on a fixed keyboard':`in the setup ${setup.id}`}: declare a tuned layout or another instrument (§4.8)`};
  return {note:{...note,key,pitch,manual:setup.manualOf(key).id}};
}

// ---- Hands and pedals ------------------------------------------------------------------------------------------------
// Each hand's available digits in keyboard order (low to high) from a profile: the right hand's thumb first, the left
// hand's last. [{hand, digits: [ids]}]
export function handsOf(who){
  const hands=[];
  for(const [id,resource] of who.resources){
    if(resource.kind!=='body'||resource.availability!=='available')continue;
    const digits=[...who.resources.values()].filter(child=>child.parents.includes(id)&&child.availability==='available').map(child=>child.id.slice(id.length+1));
    const numeric=digits.every(digit=>/^\d+$/.test(digit));
    const ordered=numeric?digits.slice().sort((a,b)=>id==='LH'?b-a:a-b):digits;
    hands.push({hand:id,digits:ordered});
  }
  return hands.sort((a,b)=>a.hand==='LH'?-1:b.hand==='LH'?1:0);
}
// The pedals this player works on this instrument: [{pedal, through}] (the controller the profile maps each through).
export function pedalsOf(who,{choices=PIANO}={}){
  return choices.pedals.map(pedal=>({pedal,through:controlOf(who,pedal)})).filter(entry=>entry.through);
}
// Whether a hand can hold keys on digits at once: keys on one manual, ordered as the digits are, and each pair within its
// reach. (Pairwise reach is necessary, not sufficient, for a posture: §4.2. A hand across two manuals would be a technique
// of its own, declared; it is not assumed.)
function spanOk(keys,digits,{choices=PIANO}={}){
  if(keys.some(key=>manualOf(key)!==manualOf(keys[0])))return false;
  for(let i=1;i<keys.length;i++)if(!(keys[i]>keys[i-1]))return false;
  const rank=digit=>Number(digit),xs=keys.map(key=>keyX(key,{choices}));
  for(let i=0;i<keys.length;i++)for(let j=i+1;j<keys.length;j++){
    const a=rank(digits[i]),b=rank(digits[j]),apart=Math.abs(xs[j]-xs[i]);
    const limit=Math.min(a,b)===1?choices.reach.thumbPair[Math.abs(a-b)]??Infinity:choices.reach.fingerStep*Math.abs(a-b);
    if(apart>limit+EPSILON)return false;
  }
  return true;
}
// A hand's place: where its thumb would be, estimated from its lowest key and that key's digit, on that key's manual.
const handPlace=(keys,digits,hand,{choices=PIANO}={})=>{
  const i=hand==='LH'?keys.length-1:0,offset=(Number(digits[i])-1)*choices.whiteKeyMm;
  return {x:keyX(keys[i],{choices})+(hand==='LH'?offset:-offset),y:manualOf(keys[i])*choices.manualStepMm};
};
// Every way one hand's digits can take a sorted set of keys, in order: [[digits]].
function digitChoices(keys,digits){
  const out=[],pick=(from,chosen)=>{if(chosen.length===keys.length){out.push(chosen);return}for(let i=from;i<=digits.length-(keys.length-chosen.length);i++)pick(i+1,[...chosen,digits[i]])};
  pick(0,[]);return out;
}

// ---- Passages --------------------------------------------------------------------------------------------------------
// Notes {id?, key, start, end} into groups of notes starting together: [{at, notes}], in time order.
export function eventGroups(notes,{choices=PIANO}={}){
  const sorted=[...notes].map((note,index)=>({id:note.id??`n${index}`,...note})).sort((a,b)=>a.start-b.start||a.key-b.key),groups=[];
  for(const note of sorted){
    if(!(note.end>note.start))throw new RangeError(`note ${note.id}: a key is held for a positive time`);
    keyX(note.key,{choices});
    const last=groups.at(-1);
    if(last&&note.start-last.at<=choices.together)last.notes.push(note);else groups.push({at:note.start,notes:[note]});
  }
  return groups;
}
// The points a plan decides at: each group's onset, and each end of a note where no group starts (a pedal may lift
// there), each knowing the point after it.
function eventPoints(notes,{choices=PIANO}={}){
  const points=eventGroups(notes,{choices}).map(group=>({...group,release:false}));
  const onsets=points.map(point=>point.at);let previous=-Infinity;
  for(const end of [...new Set(notes.map(note=>note.end))].sort((a,b)=>a-b)){
    if(onsets.some(at=>Math.abs(at-end)<=choices.together)||end-previous<=choices.together)continue;
    points.push({at:end,notes:[],release:true});previous=end;
  }
  points.sort((a,b)=>a.at-b.at);
  points.forEach((point,i)=>{point.next=points[i+1]?.at??Infinity;point.last=i===points.length-1});
  return points;
}
// A key struck again before its previous note can be released and reset, allowing that release the part's early
// tolerance: the passage as written cannot be played (B03).
function repeatedTooSoon(notes,{choices=PIANO}={}){
  const byKey=new Map;
  for(const note of [...notes].sort((a,b)=>a.start-b.start)){
    const last=byKey.get(note.key);
    if(last&&note.start<Math.max(last.end-earlyOf(last,choices),last.start+choices.strokeSeconds)+choices.travel.resetSeconds-EPSILON)
      return {key:note.key,first:last.id,again:note.id};
    byKey.set(note.key,note);
  }
  return null;
}

// The soft pedal (PIANO.tonePedals): down through each run of groups where a note asks for it (soft: true), from a pedal's
// stroke before the first to the last one's hammer, and up between runs a group asking against it (soft: false) divides.
// A group asking both would shift every hammer both ways at once. {runs: [{down, caught, lift, up}], through} or a
// refusal {status, reason}.
function softPlan(points,who,{choices=PIANO}={}){
  const runs=[];let run=null,refusing=null;
  for(const group of points.filter(point=>point.notes.length)){
    const wants=group.notes.some(note=>note.soft===true),refuses=group.notes.some(note=>note.soft===false);
    if(wants&&refuses)return {status:STATUS.violates,reason:`the notes at ${group.at} s ask for the soft pedal and against it: it shifts every hammer at once`};
    if(wants){if(run)run.last=group;else run={first:group,last:group,before:refusing}}
    else if(refuses){if(run){run.after=group;runs.push(run);run=null}refusing=group}
  }
  if(run)runs.push(run);
  if(!runs.length)return {runs:[],through:null};
  const through=controlOf(who,'soft');
  if(!through)return {status:STATUS.violates,reason:'the part asks for the soft pedal, and nothing the player has works it'};
  const out=[];
  for(const {first,last,before,after} of runs){
    const caught=first.at,down=caught-choices.pedalSeconds,lift=last.at+choices.strokeSeconds,up=lift+choices.pedalSeconds;
    if(before&&before.at+choices.strokeSeconds>down+EPSILON)return {status:STATUS.violates,reason:`the soft pedal cannot go down between the notes at ${before.at} s and ${first.at} s`};
    if(after&&up>after.at+EPSILON)return {status:STATUS.violates,reason:`the soft pedal cannot come up between the notes at ${last.at} s and ${after.at} s`};
    out.push({down,caught,lift,up});
  }
  return {runs:out,through};
}
// How much earlier than written a note may stop sounding: the part's tolerance, none for a note marked legato.
const earlyOf=(note,choices=PIANO)=>note.legato?0:choices.tolerance.early;
// How long a note sounds on after its key under a half pedal (PIANO.halfPedal).
const halfRing=(note,choices=PIANO)=>pianoRing(note.pitch)*choices.halfPedal.share;
// A finger's slide: from a black key onto the white key beside it, on one manual.
const slides=(from,to)=>manualOf(from)===manualOf(to)&&isBlack(from)&&!isBlack(to)&&Math.abs(keyOf(from)-keyOf(to))===1;

// ---- The search ------------------------------------------------------------------------------------------------------
// Plan a passage for a pianist on a setup (a fixed-tuned keyboard unless declared): {status, path?, cost?, witness?,
// durations?, reason?, alternatives?}. Each path step is a point: {at, hands: {LH, RH}: {keys, digits} | null, releases,
// ups, downs, substitutions, travel}; its keys are the instrument's numbers (keyOf, manualOf; setup.name).
export function planPassage(input,{who=pianist(),choices=PIANO,alternatives=true,setup=FIXED}={}){
  if(!input.length)return {status:STATUS.witness,path:[],cost:0};
  const notes=[];
  for(const [index,note] of input.entries()){
    const placed=onSetup({...note,id:note.id??`n${index}`},setup);
    if(placed.reason)return {status:STATUS.unknown,reason:placed.reason};
    notes.push(placed.note);
  }
  const repeat=repeatedTooSoon(notes,{choices});
  if(repeat)return {status:STATUS.violates,reason:`key ${setup.name(repeat.key)} is struck again (${repeat.again}) before ${repeat.first} can be released and reset`,alternatives:[{kind:'shorten',change:`end ${repeat.first} earlier, so the key can reset`}]};
  const hands=handsOf(who);
  if(!hands.length)return {status:STATUS.violates,reason:'the profile has no available hand'};
  const pedals=pedalsOf(who,{choices}),points=eventPoints(notes,{choices});
  const soft=softPlan(points,who,{choices});
  if(soft.status)return soft;
  const substitutes=!who.prohibited.has('substitution');
  const initial={t:-Infinity,hands:Object.fromEntries(hands.map(({hand})=>[hand,{held:[],place:null,at:null,free:-Infinity}])),
    pedals:Object.fromEntries(pedals.map(({pedal})=>[pedal,{down:false,caught:null,captured:[]}])),sounding:[]};
  // A state is named by what the rest of the passage can depend on, and nothing else, so that states differing only in
  // their past merge: a hand's free time only while it holds nothing and has not yet had time to cross the whole
  // keyboard (after that, any leap is open to it); its last move only while it holds something and has not yet had time
  // to substitute; a pedal's catch time only while a key it caught before then is held; its captures only while they
  // are held or sounding.
  const ms=value=>Number.isFinite(value)?Math.round(value*1e3):value;
  const crossSeconds=(keyX(choices.highestKey,{choices})-keyX(choices.lowestKey,{choices})+(setup.manuals.length-1)*choices.manualStepMm)/choices.travel.mmPerSecond;
  const stateKey=state=>{
    const heldNow=hands.flatMap(({hand})=>state.hands[hand].held),alive=new Set([...heldNow.map(entry=>entry.id),...state.sounding.map(entry=>entry.id)]);
    return JSON.stringify([hands.map(({hand})=>{const h=state.hands[hand];
        const free=h.held.length||!(state.t-h.free<crossSeconds)?null:ms(h.free),at=h.held.length&&state.t-h.at<choices.substitutionSeconds?ms(h.at):null;
        return [h.held.map(e=>`${e.id}:${e.digit}`),h.place===null?null:[Math.round(h.place.x),Math.round(h.place.y)],free,at]}),
      pedals.map(({pedal})=>{const p=state.pedals[pedal];return p.down?[heldNow.some(entry=>entry.start<p.caught)?ms(p.caught):null,p.captured.filter(id=>alive.has(id)),p.depth??null]:0}),
      state.sounding.map(entry=>entry.until===undefined?entry.id:`${entry.id}~${ms(entry.until)}`)]);
  };
  const found=searchGroups(points,{initial,expand:(point,state)=>expandPoint(point,state,{hands,pedals,choices,substitutes,soft}),stateKey,maxStates:choices.maxStates,beam:choices.beamStates??null});
  if(found.status===STATUS.budget)return {status:STATUS.budget,at:found.group.at,reason:found.pruned?`no path among the ${choices.beamStates} cheapest states kept past ${choices.maxStates} (by ${found.group.at} s)`:`more than ${choices.maxStates} states at ${found.group.at} s`};
  if(found.status!==STATUS.witness){
    const group=found.group.notes.length?found.group:points.slice(0,found.groupIndex).reverse().find(point=>point.notes.length)??found.group;
    return {status:found.status,at:found.group.at,reason:`no configuration of the available hands${pedals.length?' and pedals':''} plays the passage by ${found.group.at} s (${group.notes.map(note=>setup.name(note.key)).join(', ')})`,
      alternatives:alternatives?tryAlternatives(notes,group,{who,choices,setup}):[]};
  }
  const {witness:proof,durations,pedalling}=passageWitness(who,notes,found.path,{pedals,choices,setup,soft});
  return {status:STATUS.witness,path:found.path,cost:+found.cost.toFixed(6),witness:proof,durations,pedalling,soft:soft.runs.map(run=>({...run,through:soft.through})),
    workload:workloadOf(found.path,durations,{choices}),...(found.pruned?{pruned:true}:{})};
}

// Every move from a state at a point, in order: the keys that end let go; pedals lifted; keys a pedal keeps let go early
// (a hand's choice); the group struck; pedals put down after it.
function expandPoint(point,state,{hands,pedals,choices,substitutes,soft}){
  // A length pedal worked through the soft pedal's controller may not hold it while the soft pedal needs it.
  const clash=(through,from,to)=>through===soft.through&&soft.runs.some(run=>from<run.up-EPSILON&&to>run.down+EPSILON);
  const t=point.at,{late}=choices.tolerance,stroke=choices.strokeSeconds,undamped=key=>keyOf(key)>=choices.undampedFrom,moves=[];
  // What keeps a note sounding once its key is up: no damper, a pedal all the way down (the sustain, or the sostenuto
  // that caught it), or the sustain half down, for a share of the note's ring: then its key may go only so early as
  // leaves the ring to carry it to its end.
  const coverOf=(entry,pedalState)=>{
    if(undamped(entry.key))return {by:'instrument',from:entry.start+stroke};
    const sustain=pedalState.sustain,sostenuto=pedalState.sostenuto;
    if(sustain?.down&&sustain.depth!=='half')return {by:'sustain',from:Math.max(entry.start+stroke,sustain.caught)};
    if(sostenuto?.down&&sostenuto.captured.includes(entry.id))return {by:'sostenuto',from:Math.max(entry.start+stroke,sostenuto.caught)};
    if(sustain?.down){const ring=halfRing(entry,choices);return {by:'half-sustain',from:Math.max(entry.start+stroke,sustain.caught,entry.end-earlyOf(entry,choices)-ring),ring}}
    return null;
  };
  // A note under a half pedal stops of itself: at the latest its key goes, plus its share of the ring.
  const soundingOf=(entry,cover,latest)=>({id:entry.id,key:entry.key,end:entry.end,legato:entry.legato,...(cover.by==='half-sustain'?{until:latest+cover.ring}:{})});
  const within=(entry,at)=>at>=entry.end-earlyOf(entry,choices)-EPSILON&&at<=entry.end+late+EPSILON;
  // 1. Keys whose notes end by now are let go, as late as the hand's next move allows (settled in the witness); a pedal
  // down over the interval holds their dampers off.
  const natural=[],continuing={};let sounding=[...state.sounding];
  for(const {hand} of hands){
    continuing[hand]=[];
    for(const entry of state.hands[hand].held){
      if(entry.end>t+choices.together){continuing[hand].push(entry);continue}
      const cover=coverOf(entry,state.pedals);
      natural.push({note:entry.id,key:entry.key,hand,digit:entry.digit,lowest:cover?cover.from:Math.max(entry.end-earlyOf(entry,choices),entry.start+stroke),latest:entry.end,early:false,cover:cover?.by??null});
      if(cover&&cover.by!=='instrument')sounding.push(soundingOf(entry,cover,entry.end));
    }
  }
  // Notes a half pedal kept sounding whose ring has run out by now ended then, within the part's tolerance or not at all.
  let decayCost=0;
  for(const entry of sounding.filter(entry=>entry.until!==undefined&&entry.until<=t+EPSILON)){
    if(!within(entry,entry.until))return moves;
    decayCost+=Math.abs(entry.until-entry.end)*choices.cost.offPerSecond;
  }
  sounding=sounding.filter(entry=>!(entry.until!==undefined&&entry.until<=t+EPSILON));
  // 2. Pedals lifted now: any that is down, every one at the passage's last point.
  const down=pedals.filter(({pedal})=>state.pedals[pedal].down).map(({pedal})=>pedal);
  const liftings=point.last?[down]:subsets(down);
  for(const lifted of liftings){
    if(pedals.some(({pedal,through})=>state.pedals[pedal].down&&(clash(through,state.t,point.at)||lifted.includes(pedal)&&clash(through,point.at,point.at+choices.pedalSeconds))))continue;
    const afterUp=Object.fromEntries(Object.entries(state.pedals).map(([pedal,value])=>[pedal,lifted.includes(pedal)?{down:false,caught:null,captured:[]}:value]));
    let cost=decayCost,ok=true;const kept=[];
    for(const entry of sounding){
      const held=afterUp.sustain?.down||afterUp.sostenuto?.down&&afterUp.sostenuto.captured.includes(entry.id);
      if(held){kept.push(entry);continue}
      if(!within(entry,t)){ok=false;break}
      cost+=Math.abs(t-entry.end)*choices.cost.offPerSecond;
    }
    if(!ok)continue;
    // 3. Keys a pedal (or the absence of dampers) keeps sounding may be let go early, a hand's choice: all or none.
    const earlyChoices=hands.map(({hand})=>{
      const coverable=continuing[hand].map(entry=>({entry,cover:coverOf(entry,afterUp)})).filter(item=>item.cover&&item.cover.from<=t+EPSILON);
      return coverable.length?[[],coverable]:[[]];
    });
    for(const letGo of product(earlyChoices)){
      const holding={},released=[...natural];let soundingNow=[...kept],releaseCost=cost;
      hands.forEach(({hand},index)=>{
        const gone=new Set(letGo[index].map(item=>item.entry.id));
        holding[hand]=continuing[hand].filter(entry=>!gone.has(entry.id));
        for(const {entry,cover} of letGo[index]){
          released.push({note:entry.id,key:entry.key,hand,digit:entry.digit,lowest:cover.from,latest:t,early:true,cover:cover.by});
          if(cover.by!=='instrument')soundingNow.push(soundingOf(entry,cover,t));
          releaseCost+=choices.cost.pedalHold;
        }
      });
      // 4. The group struck: each hand's options, travel from when it let go, a key struck again cutting its own sound.
      for(const option of point.notes.length?groupOptions(point,hands,holding,state,{choices,substitutes,released}):[Object.fromEntries(hands.map(({hand})=>[hand,null]))]){
        let moveCost=releaseCost,blocked=false;const after={},travel={},struckKeys=new Set;
        for(const {hand} of hands){
          // A finger sliding on moves the hand with it: its key is let go at the stroke, not before the hand can leave.
          const was=state.hands[hand],now=option[hand],slid=new Set((now?.reuse??[]).filter(entry=>entry.kind==='slide').map(entry=>entry.note));
          const mine=released.filter(item=>item.hand===hand&&!slid.has(item.note)),free=Math.max(was.free,...mine.map(item=>item.lowest));
          if(!now){after[hand]={held:holding[hand],place:was.place,at:was.at,free};continue}
          if(was.place!==null&&!holding[hand].length){
            const moved=distance(now.place,was.place),seconds=moved/choices.travel.mmPerSecond;
            if(free>t-seconds+EPSILON){blocked=true;break}
            travel[hand]=seconds;moveCost+=moved*choices.cost.travelPerMm;
          }
          moveCost+=now.cost;now.keys.forEach(key=>struckKeys.add(key));
          after[hand]={held:now.held,place:now.place,at:t,free:-Infinity};
        }
        if(blocked)continue;
        let soundingAfter=soundingNow,cut=false;
        if(struckKeys.size){
          soundingAfter=[];
          for(const entry of soundingNow){if(!struckKeys.has(entry.key)){soundingAfter.push(entry);continue}if(!within(entry,t)){cut=true;break}}
        }
        if(cut)continue;
        // 5. Pedals put down after the strike, catching what is held (not at the last point).
        const up=pedals.filter(({pedal})=>!afterUp[pedal].down),heldIds=hands.flatMap(({hand})=>after[hand].held.map(entry=>entry.id));
        // The sustain goes down all the way or half way.
        const downings=(point.last||!heldIds.length?[[]]:subsets(up)).flatMap(put=>put.some(entry=>entry.pedal==='sustain')&&choices.halfPedal
          ?['full','half'].map(depth=>put.map(entry=>entry.pedal==='sustain'?{...entry,depth}:entry)):[put]);
        for(const put of downings){
          const pedalsAfter={...afterUp},downs=[];let valid=true,pedalCost=0;
          for(const {pedal,through,depth='full'} of put){
            const sharing=pedals.some(other=>other.through===through&&other.pedal!==pedal&&pedalsAfter[other.pedal].down);
            if(sharing){valid=false;break}
            const start=t+(pedals.some(other=>other.through===through&&lifted.includes(other.pedal))?choices.pedalSeconds:0),caught=start+choices.pedalSeconds;
            if(caught>point.next+EPSILON||clash(through,start,caught)){valid=false;break}
            pedalsAfter[pedal]={down:true,caught,captured:pedal==='sostenuto'?[...heldIds].sort():[],...(pedal==='sustain'?{depth}:{})};
            downs.push({pedal,through,start,caught,captured:pedal==='sostenuto'?[...heldIds].sort():[],...(pedal==='sustain'?{depth}:{})});
            pedalCost+=choices.cost.pedal;
          }
          if(!valid)continue;
          // A note a pedal holds up must be let down in time: at the next point at the latest.
          if(soundingAfter.some(entry=>entry.end+late<Math.min(point.next,entry.until??Infinity)-EPSILON&&!point.last))continue;
          moves.push({status:'supported',cost:moveCost+pedalCost,
            state:{t,hands:after,pedals:pedalsAfter,sounding:soundingAfter},
            step:{at:t,hands:Object.fromEntries(hands.map(({hand})=>[hand,option[hand]?{keys:option[hand].keys,digits:option[hand].digits,stretchMm:option[hand].stretchMm}:null])),
              releases:released,ups:lifted,downs,substitutions:hands.flatMap(({hand})=>option[hand]?.substitutions??[]),reuse:hands.flatMap(({hand})=>option[hand]?.reuse??[]),travel}});
        }
      }
    }
  }
  return moves;
}
const subsets=items=>items.reduce((all,item)=>[...all,...all.map(set=>[...set,item])],[[]]);
const product=lists=>lists.reduce((all,list)=>all.flatMap(prefix=>list.map(item=>[...prefix,item])),[[]]);

// One group's options: each available hand takes a contiguous run of the group's new keys (the left hand the lowest; on
// two manuals, either hand either manual), fitted around what it still holds, on digits in order and within reach. A held
// key keeps its digit, or, when the hand has had time since it last moved, may change to another free digit silently (a
// substitution).
function groupOptions(group,hands,holding,state,{choices=PIANO,substitutes=true,released=[]}={}){
  const keys=group.notes.map(note=>note.key).sort((a,b)=>a-b),byKey=new Map(group.notes.map(note=>[note.key,note]));
  const orders=[keys];
  if(keys.some(key=>manualOf(key)!==manualOf(keys[0])))orders.push([...keys].sort((a,b)=>manualOf(b)-manualOf(a)||a-b));
  const seen=new Set,splits=hands.length===1?[[keys]]:orders.flatMap(order=>Array.from({length:order.length+1},(_,k)=>[order.slice(0,k),order.slice(k)]))
    .filter(split=>{const name=JSON.stringify(split.map(part=>[...part].sort((a,b)=>a-b)));if(seen.has(name))return false;seen.add(name);return true});
  const out=[];
  for(const split of splits){
    const perHand=hands.map(({hand,digits},index)=>{
      const mine=split[index]??[],held=holding[hand];
      if(!mine.length)return [null];
      if(held.some(entry=>mine.includes(entry.key)))return [];
      const canSubstitute=substitutes&&held.length&&(state.hands[hand].at===null||group.at-state.hands[hand].at>=choices.substitutionSeconds-EPSILON);
      const all=[...held.map(entry=>({key:entry.key,entry})),...mine.map(key=>({key,note:byKey.get(key)}))].sort((a,b)=>a.key-b.key),found=[];
      const assignments=canSubstitute?digitChoices(all.map(item=>item.key),digits)
        :(()=>{const busy=new Set(held.map(entry=>entry.digit)),free=digits.filter(digit=>!busy.has(digit));
          return digitChoices(mine,free).map(chosen=>{const map=new Map([...held.map(entry=>[entry.key,entry.digit]),...mine.map((key,i)=>[key,chosen[i]])]);return all.map(item=>map.get(item.key))})})();
      for(const assigned of assignments){
        // In the hand's keyboard order (the digits' own) the keys must rise: a hand's digits do not cross in a chord.
        const order=all.map((item,i)=>({key:item.key,digit:assigned[i]})).sort((a,b)=>digits.indexOf(a.digit)-digits.indexOf(b.digit));
        if(!spanOk(order.map(entry=>entry.key),order.map(entry=>entry.digit),{choices}))continue;
        const substitutions=[];
        all.forEach((item,i)=>{if(item.entry&&item.entry.digit!==assigned[i])substitutions.push({note:item.entry.id,hand,from:item.entry.digit,to:assigned[i]})});
        const place=handPlace(order.map(entry=>entry.key),order.map(entry=>entry.digit),hand,{choices});
        const xs=all.map(item=>keyX(item.key,{choices})),span=Math.max(...xs)-Math.min(...xs),comfortable=choices.reach.thumbPair.at(-1)/2;
        const strikes=all.map((item,i)=>({item,digit:assigned[i]})).filter(({item})=>item.note);
        // A finger let go of a key here and striking another: it lifts, if its key may be let go in time; else it slides
        // from a black key onto the white beside it; else it cannot.
        const reuse=[];let reusable=true;
        for(const {item,digit} of strikes){
          const was=released.find(entry=>entry.hand===hand&&entry.digit===digit);
          if(!was)continue;
          if(was.lowest+choices.fingerSeconds<=group.at+EPSILON)reuse.push({note:was.note,hand,digit,kind:'lift'});
          else if(slides(was.key,item.key))reuse.push({note:was.note,hand,digit,kind:'slide',to:item.key});
          else{reusable=false;break}
        }
        if(!reusable)continue;
        const voicing=voicingOf(mine.map(key=>byKey.get(key)),{choices}),stretchMm=Math.max(0,span-comfortable);
        const cost=stretchMm*choices.cost.stretchPerMm+strikes.filter(({item,digit})=>digit==='1'&&isBlack(item.key)).length*choices.cost.thumbOnBlack
          +substitutions.length*choices.cost.substitution+(voicing&&voicing.status!==STATUS.witness?choices.cost.voicingOutside:0)
          +reuse.filter(entry=>entry.kind==='slide').length*choices.cost.slide;
        found.push({keys:mine,digits:strikes.map(({digit})=>digit),place,cost,substitutions,stretchMm,reuse,
          held:all.map((item,i)=>item.entry?{...item.entry,digit:assigned[i]}:{id:item.note.id,key:item.key,pitch:item.note.pitch,digit:assigned[i],start:item.note.start,end:item.note.end,legato:Boolean(item.note.legato)})});
      }
      return found;
    });
    if(perHand.some(list=>!list.length))continue;
    // The hands do not cross on a manual: there every key the left hand holds or strikes lies below every key of the
    // right's. On two manuals they may pass, one over the other.
    const apart=chosen=>{const low=keysOf(chosen.LH,holding.LH),high=keysOf(chosen.RH,holding.RH);
      return [...new Set(low.map(manualOf))].every(manual=>{const l=low.filter(key=>manualOf(key)===manual),h=high.filter(key=>manualOf(key)===manual);return !h.length||Math.max(...l)<Math.min(...h)})};
    const combine=(index,chosen)=>{if(index===hands.length){if(Object.values(chosen).some(Boolean)&&apart(chosen))out.push(chosen);return}
      for(const option of perHand[index])combine(index+1,{...chosen,[hands[index].hand]:option})};
    combine(0,{});
  }
  return out;
}
const keysOf=(option,held=[])=>option?option.held.map(entry=>entry.key):held.map(entry=>entry.key);
// A hand's chord against the voicing envelope: the levels its notes ask at once, low to high. Null where fewer than two
// of its notes are struck together or any of them asks no level (nothing to check); else checkEnvelope's verdict.
function voicingOf(struck,{choices=PIANO}={}){
  if(struck.length<2||struck.some(note=>!Number.isFinite(note.level)))return null;
  const levels=[...struck].sort((a,b)=>a.key-b.key).map(note=>note.level),n=levels.length,range=list=>Math.max(...list)-Math.min(...list);
  const values={spread:range(levels),top:levels[n-1]-Math.max(...levels.slice(0,-1)),restTop:range(levels.slice(0,-1)),
    bottom:levels[0]-Math.max(...levels.slice(1)),restBottom:range(levels.slice(1))};
  return {levels,...checkEnvelope(choices.voicing,{context:{instrument:'piano'},values})};
}

// ---- Alternatives ----------------------------------------------------------------------------------------------------
// When no path plays a group as written, each explicit alternative is tried and offered with what it changes and what
// came of it (§4.6, F01): a rolled chord (only as far as the part's onset tolerance allows), a delayed bass (the same),
// an octave moved toward the rest, a doubling left out; a second player or a mapped instrument, which another profile
// would plan.
function tryAlternatives(notes,group,{who,choices,setup}){
  const members=[...group.notes].sort((a,b)=>a.key-b.key),tolerance=choices.tolerance.onset,out=[];
  // Notes as a part gives them again: each on the key it had (its manual's number), or, moved, by its new pitch.
  const asGiven=note=>({...note,key:keyOf(note.key)}),byPitch=({key,manual,...note},pitch)=>({...note,pitch});
  const plan=changed=>planPassage(changed.map(note=>note.manual===undefined?note:asGiven(note)),{who,choices,setup,alternatives:false});
  // Each alternative offered with the notes it was planned with (as a part would give them) and its plan, or where it
  // failed and why.
  const given=changed=>changed.map(note=>note.manual===undefined?note:asGiven(note));
  const outcome=(result,changed)=>({notes:given(changed),...(result.status===STATUS.witness?{plan:result}:{reason:result.reason,at:result.at??null})});
  const spread=(kind,shiftOf,describe)=>{
    const needs=members.length>1?choices.rollSeconds*(kind==='rolled-chord'?members.length-1:1):Infinity;
    if(needs>tolerance+EPSILON)return {kind,status:'not-permitted',change:describe(choices.rollSeconds),reason:`the part's onsets may spread ${tolerance} s; this needs at least ${+needs.toFixed(3)} s`};
    let last={kind,status:STATUS.noPath,change:describe(choices.rollSeconds)};
    for(let step=choices.rollSeconds;shiftOf(members.length-1,step)<=tolerance+EPSILON;step*=2){
      const changed=notes.map(note=>{const i=members.findIndex(member=>member.id===note.id);return i<0?note:{...note,start:note.start+shiftOf(i,step)}});
      if(changed.some(note=>!(note.end>note.start)))break;
      const result=plan(changed);last={kind,status:result.status,change:describe(step),...outcome(result,changed)};
      if(result.status===STATUS.witness)break;
    }
    return last;
  };
  out.push(spread('rolled-chord',(i,step)=>i*step,step=>`the group's onsets spread upward, ${step} s apart: no longer struck together`));
  out.push(spread('delayed-bass',(i,step)=>i===0?step:0,step=>`the lowest note struck ${step} s after the rest`));
  for(const [member,shift,where] of [[members[0],12,'the lowest note an octave up'],[members.at(-1),-12,'the highest note an octave down']]){
    if(members.length<2)break;
    const changed=notes.map(note=>note.id===member.id?byPitch(note,note.pitch+shift):note),result=plan(changed);
    out.push({kind:'octave-redistribution',status:result.status,change:`${where}: its register changes`,...outcome(result,changed)});
  }
  const sameClass=(a,b)=>{const apart=Math.abs(pitchClass(a)-pitchClass(b));return Math.min(apart,12-apart)<=setup.tolerance+EPSILON};
  const doubled=members.filter(member=>members.some(other=>other!==member&&sameClass(other.pitch,member.pitch)));
  if(doubled.length){
    let offered={kind:'reduced-doubling',status:STATUS.noPath,change:'a doubled note left out: its class still sounds in another octave of the group',reason:'no single doubled note left out lets the rest be played'};
    for(const member of doubled){
      const kept=notes.filter(note=>note.id!==member.id),result=plan(kept);
      if(result.status===STATUS.witness){offered={kind:'reduced-doubling',status:result.status,change:`key ${setup.name(member.key)} left out: its class still sounds in another octave of the group`,...outcome(result,kept)};break}
    }
    out.push(offered);
  }
  out.push({kind:'second-player',status:STATUS.unknown,change:'another performer takes some of the notes (another profile plans them)'});
  out.push({kind:'mapped-instrument',status:STATUS.unknown,change:'a mapped instrument or controller sounds them (a profile with its mappings plans it)'});
  return out;
}

// ---- The witness -----------------------------------------------------------------------------------------------------
// A plan's witness and each note's four durations. Each key is let go as late as its hand's next move allows (and before
// its own next stroke); each held note's digit reserved in each configuration its hand takes, its digit changing where it
// is substituted; each pedal's controller reserved as it goes down, holds and lets up; the presses, releases,
// substitutions and pedals replayed through the keyboard's state, and every note's sounding end read from that replay and
// checked against its written end.
function passageWitness(who,notes,path,{pedals,choices,setup,soft}){
  const named=key=>setup.name(key);
  const byId=new Map(notes.map(note=>[note.id,note])),release=new Map,pending={},digitAt=new Map,configured={};
  // When each key is let go.
  for(const step of path){
    for(const item of step.releases)(pending[item.hand]??=[]).push(item);
    for(const [hand,config] of Object.entries(step.hands)){
      if(!config)continue;
      const move=step.travel[hand];
      for(const item of pending[hand]??[]){
        // A finger striking again here lifts in time for it, or slides on at the stroke.
        const again=step.reuse.find(entry=>entry.note===item.note),at=Math.min(item.latest,Math.max(item.lowest,move===undefined?item.latest:step.at-move));
        release.set(item.note,{...item,at:again?.kind==='lift'?Math.min(at,step.at-choices.fingerSeconds):again?.kind==='slide'?Math.min(item.latest,step.at):at,...(again?{finger:again.kind}:{})});
      }
      pending[hand]=[];
    }
  }
  for(const items of Object.values(pending))for(const item of items)release.set(item.note,{...item,at:item.latest});
  // A key struck again: its previous release comes before the reset.
  const byKey=new Map;for(const note of [...notes].sort((a,b)=>a.start-b.start)){const last=byKey.get(note.key);
    if(last){const entry=release.get(last.id);entry.at=Math.min(entry.at,note.start-choices.travel.resetSeconds)}byKey.set(note.key,note)}
  // Which digit holds each note, when.
  for(const step of path){
    for(const [hand,config] of Object.entries(step.hands))if(config){
      (configured[hand]??=[]).push(step.at);
      for(const note of notes)if(Math.abs(note.start-step.at)<=choices.together&&config.keys.includes(note.key)&&!digitAt.has(note.id))
        digitAt.set(note.id,[{from:note.start,configuration:step.at,hand,digit:config.digits[config.keys.indexOf(note.key)]}]);
    }
    for(const change of step.substitutions)digitAt.get(change.note).push({from:step.at,hand:change.hand,digit:change.to});
  }
  const actions=[],events=[],durations=[];
  for(const note of notes){
    const timeline=digitAt.get(note.id),hand=timeline[0].hand,letGo=release.get(note.id).at;
    const cuts=[...new Set([note.start,...(configured[hand]??[]).filter(at=>at>note.start+choices.together&&at<letGo),letGo])].sort((a,b)=>a-b);
    const reservations=[];
    for(let k=0;k<cuts.length-1;k++){
      const at=cuts[k],digit=[...timeline].reverse().find(entry=>entry.from<=at+EPSILON).digit;
      reservations.push({resource:`${hand}.${digit}`,phase:'hold',start:at,end:cuts[k+1],configuration:`${hand}@${k?at:timeline[0].configuration}`});
    }
    actions.push(action({id:`${hand}@${note.start}:${named(note.key)}`,contacts:[named(note.key)],contactSeconds:[note.start],reservations}));
    events.push({t:note.start,order:EVENT_ORDER.press,event:{kind:'press',key:named(note.key),effector:`${hand}.${timeline[0].digit}`}});
    for(let k=1;k<timeline.length;k++)events.push({t:timeline[k].from,order:EVENT_ORDER.substitute,event:{kind:'substitute',key:named(note.key),from:`${hand}.${timeline[k-1].digit}`,to:`${hand}.${timeline[k].digit}`}});
    events.push({t:letGo,order:EVENT_ORDER.release,event:{kind:'release',key:named(note.key),effector:`${hand}.${timeline.at(-1).digit}`}});
  }
  // Each pedal: down, held, up, its controller reserved throughout.
  const through=Object.fromEntries(pedals.map(({pedal,through})=>[pedal,through])),pedalling=[];
  for(const [index,step] of path.entries())for(const put of step.downs){
    const lifted=path.slice(index+1).find(later=>later.ups.includes(put.pedal))?.at??path.at(-1).at;
    pedalling.push({pedal:put.pedal,depth:put.depth??'full',through:through[put.pedal],start:put.start,caught:put.caught,lifted,captured:put.captured});
    actions.push(action({id:`${put.pedal}@${put.caught}`,technique:`${put.pedal}-pedal`,contacts:[],
      reservations:[{resource:through[put.pedal],phase:'transfer',start:put.start,end:put.caught},{resource:through[put.pedal],phase:'hold',start:put.caught,end:Math.max(lifted,put.caught+TIME_STEP)},
        {resource:through[put.pedal],phase:'release',start:Math.max(lifted,put.caught+TIME_STEP),end:Math.max(lifted,put.caught+TIME_STEP)+choices.pedalSeconds}]}));
    const kinds=PEDAL_EVENTS[put.depth==='half'?'half-sustain':put.pedal];
    events.push({t:put.caught,order:EVENT_ORDER.down,event:{kind:kinds[0]}});
    events.push({t:lifted,order:EVENT_ORDER.up,event:{kind:kinds[1]}});
  }
  // The soft pedal: down before its run's first stroke, up after its last, its controller reserved throughout.
  for(const run of soft.runs){
    actions.push(action({id:`soft@${run.caught}`,technique:'soft-pedal',contacts:[],reservations:[{resource:soft.through,phase:'transfer',start:run.down,end:run.caught},
      {resource:soft.through,phase:'hold',start:run.caught,end:run.lift},{resource:soft.through,phase:'release',start:run.lift,end:run.up}]}));
    events.push({t:run.caught,order:EVENT_ORDER.down,event:{kind:'softDown'}},{t:run.lift,order:EVENT_ORDER.up,event:{kind:'softUp'}});
  }
  events.sort((a,b)=>a.t-b.t||a.order-b.order);
  // The replay, and each note's sounding end read from it.
  const lastPressed=new Map,soundingEnd=new Map;let state=keyboard();
  for(const {t,event} of events){
    if(event.kind==='press'){const earlier=lastPressed.get(event.key);if(earlier&&!soundingEnd.has(earlier)&&state.undamped.has(event.key))soundingEnd.set(earlier,t)}
    const before=new Set(state.undamped);state=onKeyboard(state,event);
    for(const key of before)if(!state.undamped.has(key)){const id=lastPressed.get(key);if(id&&!soundingEnd.has(id))soundingEnd.set(id,t)}
    if(event.kind==='press')lastPressed.set(event.key,notes.find(note=>named(note.key)===event.key&&Math.abs(note.start-t)<=EPSILON)?.id);
  }
  const {late}=choices.tolerance,off=[],faded=[];
  for(const note of notes){
    // Dampers are the key's (its place on its manual); a string rings as long as its pitch does.
    const letGo=release.get(note.id),undampedKey=keyOf(note.key)>=choices.undampedFrom,ring=pianoRing(note.pitch);
    const pedalled=soundingEnd.get(note.id)??letGo.at;
    const end=undampedKey?Math.max(note.end,letGo.at):letGo.cover==='half-sustain'?Math.min(pedalled,letGo.at+halfRing(note,choices)):pedalled;
    if(!undampedKey&&!(end>=note.end-earlyOf(note,choices)-EPSILON&&end<=note.end+late+EPSILON))off.push({note:note.id,written:note.end,sounds:end});
    if(note.end-note.start>ring)faded.push({note:note.id,seconds:note.end-note.start,ring:+ring.toFixed(3)});
    const played=digitAt.get(note.id);
    durations.push({note:note.id,key:keyOf(note.key),manual:note.manual,pitch:note.pitch,hand:played[0].hand,digit:played[0].digit,
      substitutions:played.slice(1).map(entry=>({at:entry.from,digit:entry.digit})),soft:soft.runs.some(run=>note.start>=run.caught-EPSILON&&note.start<=run.lift+EPSILON),
      written:[note.start,note.end],held:[note.start,+letGo.at.toFixed(9)],
      damper:undampedKey?'none':letGo.cover??'key',finger:letGo.finger??null,sounding:[note.start,+end.toFixed(9)],ring:+ring.toFixed(3)});
  }
  const reservations=checkReservations(who,actions);
  const proof=witness({who,actions,initial:keyboard(),events:events.map(entry=>entry.event),apply:onKeyboard,
    checks:[{id:'digits-hands-and-controls',evidence:'authored',...reservations},{id:'reach',status:STATUS.witness,evidence:'authored'},
      {id:'sounding',status:off.length?STATUS.violates:STATUS.witness,evidence:'authored',off},
      {id:'acoustic-decay',status:faded.length?STATUS.unknown:STATUS.witness,evidence:'authored',faded},
      voicingCheck(notes,path,{choices,setup})]});
  return {witness:proof,durations,pedalling};
}
const TIME_STEP=1e-6;
// The expression check (E02): each hand's chord against the voicing envelope, where its notes ask levels. Unknown when no
// chord asks; outside (the check abstains) when any asks a voicing in no known region; otherwise a witness, on the
// envelope's evidence. Each hand is its own: two hands at two levels ask nothing of either.
function voicingCheck(notes,path,{choices,setup}){
  const chords=[];
  for(const step of path)for(const [hand,config] of Object.entries(step.hands)){
    if(!config)continue;
    const struck=config.keys.map(key=>notes.find(note=>note.key===key&&Math.abs(note.start-step.at)<=choices.together));
    const voicing=voicingOf(struck,{choices});
    if(voicing)chords.push({at:step.at,hand,keys:[...config.keys].sort((a,b)=>a-b).map(setup.name),levels:voicing.levels,status:voicing.status,...(voicing.region?{region:voicing.region}:{reasons:voicing.reasons})});
  }
  if(!chords.length)return {id:'expression',status:STATUS.unknown,reason:'no chord asks levels of its notes',chain:EXPRESSION_CHAIN};
  return {id:'expression',status:chords.some(chord=>chord.status!==STATUS.witness)?STATUS.outside:STATUS.witness,evidence:choices.voicing.status,chords,chain:EXPRESSION_CHAIN};
}
// What the expression check stands on, stage by stage (§7.1, E01): the part's levels are musical targets, checked as
// such; how fast a key must go down for them, what the piano then sounds, and the mix's gain are not measured here, and
// none stands in for another (a MIDI velocity is none of them).
const EXPRESSION_CHAIN=Object.freeze({target:'the part\'s levels, dB',control:'key velocity: not measured',acoustic:'not measured',mix:'not the performer\'s'});
// What a plan asks of the player, by kind (§7.3), never from a note count: strokes, seconds of keys held, seconds each
// pedal is down, millimetres the hands travel and stretch beyond half a hand's reach, and silent substitutions. A
// record, not a difficulty: whether it is comfortable is the player's to say.
function workloadOf(path,durations,{choices}){
  const pedals={};
  for(const [index,step] of path.entries())for(const put of step.downs){
    const lifted=path.slice(index+1).find(later=>later.ups.includes(put.pedal))?.at??path.at(-1).at;
    const name=put.depth==='half'?'half-sustain':put.pedal;
    pedals[name]=(pedals[name]??0)+Math.max(0,lifted-put.caught);
  }
  const round=value=>+value.toFixed(6);
  return {strokes:durations.length,keyHoldSeconds:round(durations.reduce((sum,entry)=>sum+entry.held[1]-entry.held[0],0)),
    pedalSeconds:Object.fromEntries(Object.entries(pedals).map(([pedal,seconds])=>[pedal,round(seconds)])),
    travelMm:round(path.reduce((sum,step)=>sum+Object.values(step.travel).reduce((a,seconds)=>a+seconds*choices.travel.mmPerSecond,0),0)),
    stretchMm:round(path.reduce((sum,step)=>sum+Object.values(step.hands).reduce((a,config)=>a+(config?.stretchMm??0),0),0)),
    substitutions:path.reduce((sum,step)=>sum+step.substitutions.length,0)};
}

// ---- Sections on different setups (§4.8) -----------------------------------------------------------------------------
// Sections played on setups that differ, each change made in the silence between them and taking its own time: each key
// whose pitch changes retuned by a tuner (on an electronic setup, the layout remapped by one control action), each
// preparation put in or taken out by the player, or by an assistant where there is one; one person's work after
// another's. `helpers`: who besides the player is there to make a change ('tuner', 'assistant'). Setups with different
// manuals are different instruments, not a change of setup. Each section is planned on its own setup (planPassage).
// sections: [{id?, notes, setup}] in time order. {status, sections: [{id, plan}], changes: [{from, to, gap, seconds,
// work: [{kind, manual, keys, seconds, by}], status, reason?}]}
export function planSections(sections,{who=pianist(),choices=PIANO,helpers=[],alternatives=true}={}){
  const planned=sections.map((section,index)=>{const setup=section.setup??FIXED;
    return {id:section.id??`s${index}`,setup,notes:section.notes,plan:planPassage(section.notes,{who,choices,setup,alternatives})}});
  const changes=planned.slice(1).map((next,index)=>setupChange(planned[index],next,{choices,helpers}));
  return {status:worst([...planned.map(section=>section.plan.status),...changes.map(change=>change.status)]),
    sections:planned.map(({id,plan})=>({id,plan})),changes};
}
// The worst of several statuses: a broken constraint over no path found, over an exhausted search, over what is unknown.
const SEVERITY=Object.freeze([STATUS.invalid,STATUS.violates,STATUS.noPath,STATUS.budget,STATUS.outside,STATUS.unknown,STATUS.witness]);
const worst=statuses=>SEVERITY.find(status=>statuses.includes(status))??STATUS.witness;
function setupChange(before,after,{choices,helpers}){
  const from=before.setup,to=after.setup;
  // The silence between them: from the last sound of one (a pedalled note's too) to the first stroke of the other.
  const lastSound=Math.max(-Infinity,...before.notes.map(note=>note.end),...(before.plan.durations??[]).map(entry=>entry.sounding[1]));
  const gap=Math.min(Infinity,...after.notes.map(note=>note.start))-lastSound,base={from:before.id,to:after.id,gap:+gap.toFixed(6)};
  if(from.manuals.length!==to.manuals.length||from.manuals.some((manual,index)=>manual.id!==to.manuals[index].id))
    return {...base,seconds:null,work:[],status:STATUS.unknown,reason:`${from.id} and ${to.id} have different manuals: another instrument, not a change of setup`};
  const work=[],by=kind=>kind==='prepare'&&helpers.includes('assistant')?'assistant':choices.changes[kind].by;
  for(const manual of from.manuals){
    const other=to.manuals[manual.index],moved=[],prepared=[];
    for(let key=Math.max(manual.lowestKey,other.lowestKey);key<=Math.min(manual.highestKey,other.highestKey);key++){
      const id=manual.index*MANUAL_KEYS+key;
      if(Math.abs(from.pitchOf(id)-to.pitchOf(id))>Math.min(from.tolerance,to.tolerance)+EPSILON)moved.push(key);
      if((manual.prepared.get(key)??null)!==(other.prepared.get(key)??null))prepared.push(key);
    }
    if(moved.length){const kind=from.electronic&&to.electronic?'remap':'retune';
      work.push({kind,manual:manual.id,keys:moved,seconds:kind==='remap'?choices.changes.remap.seconds:moved.length*choices.changes.retune.seconds,by:by(kind)})}
    if(prepared.length)work.push({kind:'prepare',manual:manual.id,keys:prepared,seconds:prepared.length*choices.changes.prepare.seconds,by:by('prepare')});
  }
  const seconds=work.reduce((sum,item)=>sum+item.seconds,0),missing=[...new Set(work.map(item=>item.by).filter(person=>person!=='player'&&!helpers.includes(person)))];
  const needs=missing.length?`; it needs another person: ${missing.join(', ')}`:'';
  if(seconds>gap+EPSILON)return {...base,seconds,work,status:STATUS.violates,reason:`the change takes ${seconds} s (${work.map(item=>`${item.kind} ${item.keys.length} key${item.keys.length===1?'':'s'} on ${item.manual}`).join(', ')}); the sections leave ${+gap.toFixed(3)} s${needs}`};
  if(missing.length)return {...base,seconds,work,status:STATUS.unknown,reason:`the change needs another person: ${missing.join(', ')}`};
  return {...base,seconds,work,status:STATUS.witness};
}
