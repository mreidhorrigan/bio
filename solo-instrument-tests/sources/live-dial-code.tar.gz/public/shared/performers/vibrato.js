// A string player's vibrato, their own (the owner, 1 October 2026: "Our simulated string section, composed from
// individuals, should not have that eerie fake-sounding quality of chorussy vibrato, because the vibrato is likely
// slightly different per player in the manner of a real orchestra"). A section's seats play still recordings (scripts/
// download-iowa-still-strings.mjs), and each seat's vibrato is drawn once, from its seat, around the measured players':
// its rate and width, how long it waits after a note begins, and the way it first moves; and each note's moves with its
// pitch, its dynamic and its end. -> a playback-rate curve (audio.js sampleFile).
//
// **Measured** (each DOI checked against Crossref; research/kalman-references.md, "A string player's vibrato"):
//   - the rate: about 5.5 Hz for violinists and cellists, neither instrument nor experience differing (J. M. Geringer
//     and M. L. Allen, "An analysis of vibrato among high school and university violin and cello students", JRME 52
//     (2004), 167-178, doi:10.2307/3345438, 40 players); 5.17 Hz and 19 cents for double bassists (J. P. Mick, "An
//     analysis of double bass vibrato", String Research Journal 15 (2024), 55-72, doi:10.1177/19484992241238989, 40);
//   - a violinist's width: about 40 cents in first position (M. L. Allen, J. M. Geringer and R. B. MacLeod, "Performance
//     practice of violin vibrato: an artist-level case study", String Research Journal os-4 (2009), 27-38,
//     doi:10.1177/1948499209OS-400103);
//   - high pitches 0.32 Hz faster and about 26 cents wider than low ones, forte about 4 cents wider than piano (R. B.
//     MacLeod, "Influences of dynamic level and pitch register on the vibrato rates and widths of violin and viola
//     players", JRME 56 (2008), 43-54, doi:10.1177/0022429408323070);
//   - no consistent first direction (J. M. Geringer, M. L. Allen and R. B. MacLeod, "Initial movement and continuity in
//     vibrato among high school and university string players", JRME 53 (2005), 248-259,
//     doi:10.1177/002242940505300306), and a stretch without vibrato where a note changes: 0.42 s for university
//     players there, 0.33 s for the artist above.
// **Authored**, each naming what should replace it: the viola's rate and width and the cello's width (Geringer and Allen
// measured the cello's narrower than the violin's; their tables, walled, give how much); how far players differ (each
// study's spread between its players); a note's rate rising toward its end (P. Desain, H. Honing, R. Aarts and R.
// Timmers, "Rhythmic aspects of vibrato", in Rhythm Perception and Production, Swets & Zeitlinger, 1999: shown, the
// slope not tabulated); the slow drift of rate and width within a note.
// Each a value of registry/players/bowed.json `vibrato` (since 29 October 2026), the measured with their sources and the
// authored with their reasons and the searches that found no measurement: the violin's, viola's, cello's and
// contrabass's rate and width on their nodes; the measured string players' register, forte and delay on the violin
// family's; what every player's vibrato does -- its spread, ending, drift, onset, a piece's scope and its arc -- on
// `instrument`'s, the winds' theirs until they are on the registry's tree.
//
// Width here is peak to peak, as the studies measure it: the pitch moves half of it above and below.
import {BOWED_INSTRUMENTS} from './bowed-line.js';
import {instrumentRange} from './instrument-ranges.js';
import {GIVEN_BOWED,bySize} from './bowed-instruments.js';
import {equationOf,group,player,setting} from '../../../registry/registry.js';
import {fnv1a} from '../fnv1a.js';
import {mulberry32} from '../mulberry32.js';

const own=(id,path)=>player(id,`vibrato.${path}`),every=path=>group('instrument',`vibrato.${path}`,'players');
const rateWidth=id=>Object.freeze({rate:own(id,'rate'),width:own(id,'width')});
export const MEASURED_VIBRATO=Object.freeze({
  violin:rateWidth('violin'),
  contrabass:rateWidth('contrabass'),
  register:group('violin-family','vibrato.register','players'),                // from an instrument's lowest pitch to its highest
  forte:own('violin-family','forte'),                                           // cents wider at forte than at piano
  delay:Object.freeze([own('violin-family','delay.least'),own('violin-family','delay.most')]),// s without vibrato as a note begins
});
export const AUTHORED_VIBRATO=Object.freeze({
  viola:rateWidth('viola'),         // between the violin's and the cello's
  cello:rateWidth('cello'),         // its rate measured, its width narrower than the violin's (Geringer and Allen), how much authored
  spread:every('spread'),           // between players: Hz, and a share of the width
  ending:every('ending'),           // its rate rising by this share over a note's last seconds
  drift:every('drift'),             // within a note: shares of its rate and width, wandering this fast
  onset:own('instrument','onset'),  // s over which its width grows once it begins
  step:setting('strings-compiler','step'),// s between the curve's points: a finger's path written a straight segment this long at a time
});
// A wind player's, where its instrument is played with one (authored, each to be replaced by its players' measured
// rates and widths): the flutes', the oboe's and the bassoon's, from the diaphragm and throat; none for the clarinet, the
// horn or the low brass, as an orchestra plays them; a little for the trumpet.
export const WIND_VIBRATO=Object.freeze({
  flute:Object.freeze({rate:5,width:30}),piccolo:Object.freeze({rate:5.2,width:24}),alto:Object.freeze({rate:4.8,width:30}),
  oboe:Object.freeze({rate:5,width:22}),bassoon:Object.freeze({rate:5,width:22}),clarinet:Object.freeze({rate:5,width:0}),
  horn:Object.freeze({rate:5,width:0}),trumpet:Object.freeze({rate:5.5,width:10}),trombone:Object.freeze({rate:5,width:0}),tuba:Object.freeze({rate:5,width:0}),
  // (The rest of the woodwinds: the English horn's and contrabassoon's as their family's; the E-flat and bass clarinets'
  // none, as the clarinet's; the saxophones' their jaw's, a classical saxophonist's, wider than a double reed's.)
  'english-horn':Object.freeze({rate:5,width:22}),contrabassoon:Object.freeze({rate:5,width:18}),
  'e-flat-clarinet':Object.freeze({rate:5,width:0}),'bass-clarinet':Object.freeze({rate:5,width:0}),
  'soprano-saxophone':Object.freeze({rate:5.2,width:26}),'alto-saxophone':Object.freeze({rate:5.2,width:26}),
  'tenor-saxophone':Object.freeze({rate:5,width:26}),'baritone-saxophone':Object.freeze({rate:5,width:22}),
});
// (The widest those played without one take in a style that asks for it -- a clarinet's in jazz, a horn's or a low
// brass player's in a commercial section -- peak to peak, cents: authored, to be measured. A piece's scope reaches it.)
export const WIND_VIBRATO_REACH=Object.freeze({clarinet:20,'e-flat-clarinet':20,'bass-clarinet':16,horn:16,trombone:30,tuba:16});
// (A bowed instrument given as data (bowed-instruments.js): its rate and width read between the bowed instruments' by
// size.)
const BOWED_VIBRATO={violin:MEASURED_VIBRATO.violin,viola:AUTHORED_VIBRATO.viola,cello:AUTHORED_VIBRATO.cello,contrabass:MEASURED_VIBRATO.contrabass};
const of=(key,name)=>bySize(Object.fromEntries(Object.entries(BOWED_VIBRATO).map(([n,v])=>[n,v[key]])),name);
const kinds={...AUTHORED_VIBRATO,violin:MEASURED_VIBRATO.violin,contrabass:MEASURED_VIBRATO.contrabass,...WIND_VIBRATO,
  ...Object.fromEntries(GIVEN_BOWED.map(i=>[i.name,Object.freeze({rate:of('rate',i.name),width:of('width',i.name)})]))};
// An instrument's players' vibrato, as its seats are drawn about it: {rate (Hz), width (cents)}, or null where it is
// played without one.
export const instrumentVibrato=instrument=>kinds[instrument]??null;
// An instrument's compass, low to high, which a note's place in it moves its vibrato by.
const compassOf=instrument=>instrumentRange(instrument).range;
// A source of numbers in [0, 1) from a name (FNV-1a, then mulberry32), so a seat's player is the same each time; a normal
// deviate from two of its draws (Box and Muller's), and cents as a frequency ratio: the registry's equations.
const source=name=>mulberry32(fnv1a(String(name)));
const deviate=equationOf('normal-deviate'),ratioOf=equationOf('cents-ratio');
const normal=random=>deviate({u:random(),v:random()});
// A player's vibrato, drawn once from their seat (`id`) on `instrument`. -> {instrument, rate (Hz), width (cents, peak to
// peak, at the middle of the compass and mezzo), delay (s), id}.
export function playerVibrato(id,instrument){
  const kind=kinds[instrument];if(!kind||!compassOf(instrument))throw new RangeError(`A player's vibrato is a ${[...Object.keys(BOWED_INSTRUMENTS),...Object.keys(WIND_VIBRATO)].join(', ')}'s`);
  const random=source(`vibrato:${instrument}:${id}`),{spread}=AUTHORED_VIBRATO,[early,late]=MEASURED_VIBRATO.delay;
  return Object.freeze({id:String(id),instrument,rate:+(kind.rate+normal(random)*spread.rate).toFixed(3),width:+(kind.width*Math.exp(normal(random)*spread.width)).toFixed(2),
    delay:+(early+random()*(late-early)).toFixed(3)});
}
// **Expressive vibrato** (the owner, 9 October 2026: "the amounts of vibrato within each note and across a phrase do not
// follow fully expressive or natural arcs for any instrument; also, stylistically, we need the ability to set a possible
// scope of vibrato for each instrument, as in many situations we would expect strings to play with only a tiny bit of
// it"). A note's vibrato is its player's (above), scaled by:
//   - its **scope**, the piece's for its instrument ([low, high], shares of the player's measured width: a spec's,
//     else its conductor's draw), which its intensity is placed in;
//   - its **intensity** across its phrase (vibratoIntensity): nearer its phrase's apex more, a longer note more, an
//     accented note a little more, a passing note under its player's delay none;
//   - its **arc** within the note: none for the player's delay (shorter the more intense), growing over its onset, its
//     width following the note's own swell (its dynamics' curve, as a player's vibrato widens with the bow's or the
//     breath's crescendo), deepening a little through a long note, and narrowing over its last moments where its finger,
//     lips or breath move on (TAPER), as players narrow it into a change; its rate a little faster the more intense.
// Authored, each to be replaced by players measured through a phrase: the intensity's weights, the deepening and the
// taper (E. Prame 1994, "Measurements of the vibrato rate of ten singers", JASA 96, 1979-1984, doi:10.1121/1.410141, found
// singers' rate rising toward a note's end -- the DOI cited here before, 10.1121/1.418242, is another paper's; Prame 1997,
// doi:10.1121/1.419735, their extent growing over a tone's beginning and shrinking over its end; string players' arcs
// through phrases not measured here). Each the registry's (registry/players/bowed.json `instrument` vibrato.arc):
// the intensity's weights of nearness to the apex, length and accent, and its floor (apex, length, accent, base); a note
// this long past its delay counting as long (fullSeconds); the delay shortened by this share at full intensity
// (sooner); widening through a long note, this share over these seconds (deepen); narrowing into a change or an end,
// these seconds, at most this share of the note (taper); its rate this share faster at full intensity than at none
// (quicker); and where a caller names none, its phrase's apex and its delay (peak, delay).
export const VIBRATO_ARC=every('arc');
// A share 0 to 1 about its middle, -1 to 1.
const aboutMiddle=share=>(share-1/2)/(1/2);
// A note's vibrato intensity in its phrase, 0 to 1: `position` and `peak` its place and its apex's (shares of the
// phrase), `seconds` its length past `delay`, `accent` 0 to 1.
export function vibratoIntensity({position=1/2,peak=VIBRATO_ARC.peak,seconds=0,delay=VIBRATO_ARC.delay,accent=0}={}){
  const {apex,length,accent:stress,base,fullSeconds}=VIBRATO_ARC,near=1-Math.min(1,Math.abs(position-peak)/Math.max(peak,1-peak));
  return Math.max(0,Math.min(1,base+apex*near+length*Math.max(0,Math.min(1,(seconds-delay)/fullSeconds))+stress*Math.max(0,Math.min(1,accent))));
}
// One note's vibrato as playback-rate factors, one each AUTHORED_VIBRATO.step from the note's start, for `seconds`:
// the player's (playerVibrato), at `pitch` (MIDI) and `velocity` (0 to 1); `note`: a name for this note (its first
// direction and its drift drawn from it); `expression`: {intensity (vibratoIntensity), scope ([low, high]), dynamics
// ({curve: velocities, step}: the note's swell)}. A note shorter than its delay has none; without an expression, its
// player's own vibrato, measured.
export function vibratoCurve(player,{seconds,pitch,velocity=1/2,note='',expression=null}){
  // (Its points a step apart, two at least: a note shorter than a step its start and its end.)
  const {step,onset,ending,drift}=AUTHORED_VIBRATO,points=Math.ceil(Math.max(seconds,step)/step)+1,out=new Float32Array(points).fill(1);
  const intensity=expression?Math.max(0,Math.min(1,Number.isFinite(Number(expression.intensity))?Number(expression.intensity):1/2)):null,[low,high]=expression?.scope??[1,1];
  const delay=player.delay*(1-(intensity??0)*VIBRATO_ARC.sooner);
  if(!(seconds>delay))return out;
  const [lowest,highest]=compassOf(player.instrument);
  const place=Math.max(0,Math.min(1,(pitch-lowest)/(highest-lowest)))-1/2,{register,forte}=MEASURED_VIBRATO;
  const scale=intensity===null?1:low+(high-low)*intensity;
  const rate=(player.rate+register.rate*place)*(1+(intensity===null?0:VIBRATO_ARC.quicker*(intensity-1/2)));
  const own=player.width>0?player.width:expression?WIND_VIBRATO_REACH[player.instrument]??0:0;
  const width=Math.max(0,own+register.width*place*(own>0)+forte*aboutMiddle(Math.max(0,Math.min(1,velocity)))*(own>0))*scale;
  if(!(width>0))return out;
  const random=source(`${player.id}:${note}`),direction=random()<1/2?1:-1,phases=[random(),random()].map(value=>2*Math.PI*value);
  // (Its swell: the note's dynamics against their loudest, a player's vibrato wider as it grows louder.)
  const swell=expression?.dynamics?.curve?.length?(()=>{const c=expression.dynamics.curve,most=Math.max(...c)||1;return t=>{const k=Math.min(c.length-1,Math.max(0,Math.round(t/(expression.dynamics.step||step))));return Math.sqrt(Math.max(0,c[k])/most)}})():()=>1;
  const taper=expression?Math.min(VIBRATO_ARC.taper.seconds,seconds*VIBRATO_ARC.taper.share):0,{deepen}=VIBRATO_ARC;
  let phase=0;
  for(let k=0;k<points;k++){
    const t=k*step;if(t<delay)continue;
    const into=t-delay,toEnd=seconds-t,wander=w=>Math.sin(2*Math.PI*drift.hertz*t+phases[w]);
    const hz=rate*(1+drift.rate*wander(0))*(1+(toEnd<ending.seconds?ending.share*(1-toEnd/ending.seconds):0));
    phase+=2*Math.PI*hz*step;
    const arc=!expression?1:swell(t)*(1+deepen.share*Math.min(1,into/deepen.seconds))*(taper>0&&toEnd<taper?toEnd/taper:1);
    const cents=direction*(width/2)*Math.min(1,into/onset)*arc*(1+drift.width*wander(1))*Math.sin(phase);
    out[k]=ratioOf({cents});
  }
  return out;
}
// The scope of vibrato a piece gives an instrument, [low, high] (shares of its players' measured widths): its spec's
// (`asked`: one range for all, or by instrument or family -- strings, winds, brass), else drawn once a piece from its
// seed (a centre anywhere from none to all, a range about it the registry's `instrument` vibrato.scope wide): the style a
// conductor brings to a piece. A scope's ends, its low and its high, and how wide one is drawn.
const ENDS=['low','high'],SCOPE=own('instrument','scope');
const FAMILY={violin:'strings',viola:'strings',cello:'strings',contrabass:'strings',flute:'winds',piccolo:'winds',alto:'winds',oboe:'winds',bassoon:'winds',clarinet:'winds',
  'english-horn':'winds',contrabassoon:'winds','e-flat-clarinet':'winds','bass-clarinet':'winds',
  'soprano-saxophone':'winds','alto-saxophone':'winds','tenor-saxophone':'winds','baritone-saxophone':'winds',
  horn:'brass',trumpet:'brass',trombone:'brass',tuba:'brass',...Object.fromEntries(GIVEN_BOWED.map(i=>[i.name,'strings']))};
export function vibratoScope(asked,instrument,random){
  const valid=r=>Array.isArray(r)&&r.length===ENDS.length&&r.every(x=>Number.isFinite(Number(x))&&x>=0)&&r[0]<=r[1];
  const own=valid(asked)?asked:asked&&typeof asked==='object'?asked[instrument]??asked[FAMILY[instrument]]:null;
  if(valid(own))return own.map(Number);
  // (Drawn, an instrument played without one as an orchestra plays it keeps none: WIND_VIBRATO_REACH is for a style that
  // asks.)
  if(kinds[instrument]&&kinds[instrument].width===0)return [0,0];
  const centre=random(),half=SCOPE/2;return [Math.max(0,centre-half),Math.min(1,centre+half)].map(x=>+x.toFixed(3));
}
