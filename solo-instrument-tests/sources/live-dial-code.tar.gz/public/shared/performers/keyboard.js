// A keyboard player through the performer contract (contract.js): digits under hands as resources, a chord one action
// holding its hand in one configuration, and the keys and pedals as state that survives notes, voices and planning
// windows. The piano's half of the general report's M1 (§§4.3–4.5), the minimal example the drums' interface
// (drummer.js) is proved against.
//
// The keys and pedals are the reference kernels' binary damper toy, made pure: which keys are held and by which digit,
// which strings are undamped, under the sustain (all the way or half down) and the sostenuto pedals, and whether the soft
// pedal has shifted the hammers. It is not an acoustic model: what a half pedal does to a note's sound is the piano
// planner's (piano.js), and the rest of a piano's action is not here.
import {action,profile} from './contract.js';

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const KEYBOARD=Object.freeze({
  hands:Object.freeze({RH:Object.freeze(['1','2','3','4','5']),LH:Object.freeze(['1','2','3','4','5'])}),
  // The feet, and which works which pedal: the right the sustain, the left the sostenuto and the soft pedal (a grand's
  // left and middle pedals under one foot, one at a time). A knee lever, a hand switch or a head tracker (§4.5, §6.5) is
  // a controller of its own, mapped the same way.
  feet:Object.freeze(['RF','LF']),
  controls:Object.freeze([Object.freeze({mechanism:'sustain',through:'RF'}),Object.freeze({mechanism:'sostenuto',through:'LF'}),Object.freeze({mechanism:'soft',through:'LF'})]),
});

// A pianist's profile: each hand a body resource, its digits effectors under it (any ids: a hand of three, or a digit
// the player does not use, is a profile, not another class of pianist); the feet, and any other `controllers`
// ([{id, evidence?}]); and `controls`, which of them works each pedal (by default the feet's mappings, for the feet the
// profile has). `unavailable` names hands, digits, feet or controllers.
export function pianist({id='pianist',performer='pianist',hands=KEYBOARD.hands,feet=KEYBOARD.feet,controllers=[],controls=null,unavailable=[],prohibited=[],evidence='authored'}={}){
  const resources=[],availability=resource=>unavailable.includes(resource)?'unavailable':'available';
  for(const [hand,digits] of Object.entries(hands)){
    resources.push({id:hand,kind:'body',availability:availability(hand),capacity:1,evidence});
    for(const digit of digits){
      const resource=`${hand}.${digit}`;
      resources.push({id:resource,kind:'effector',availability:unavailable.includes(resource)?'unavailable':'available',capacity:1,parents:[hand],evidence});
    }
  }
  for(const foot of feet)resources.push({id:foot,kind:'effector',availability:availability(foot),capacity:1,evidence});
  for(const controller of controllers)resources.push({id:controller.id,kind:'controller',availability:availability(controller.id),capacity:1,evidence:controller.evidence??evidence});
  const ids=new Set(resources.map(resource=>resource.id));
  return profile({id,performer,prohibited,resources,controls:controls??KEYBOARD.controls.filter(control=>ids.has(control.through))});
}
// A chord (or one note) pressed by digits of one hand: one action, each digit reserved once and the hand held in one
// configuration (by default the one those digits make) from `start` to `end` seconds (A03).
export function chordAction({id,hand,digits,start,end,configuration=null,technique=null}){
  if(!digits?.length)throw new RangeError('a chord has its digits');
  return action({id,technique,contacts:digits.map(digit=>`${id}:${hand}.${digit}`),
    reservations:digits.map(digit=>({resource:`${hand}.${digit}`,phase:'hold',start,end,configuration:configuration??`${hand}:${digits.join('')}`}))});
}

// ---- Keys and pedals -------------------------------------------------------------------------------------------------
export const keyboard=()=>Object.freeze({held:new Map,undamped:new Set,sustain:false,sustainDepth:null,sostenuto:false,captured:new Set,soft:false});
// The state a witness keeps (contract.js canonical) made live again.
export const reviveKeyboard=plain=>Object.freeze({held:new Map(plain.held),undamped:new Set(plain.undamped),sustain:plain.sustain,sostenuto:plain.sostenuto,captured:new Set(plain.captured),soft:Boolean(plain.soft),sustainDepth:plain.sustainDepth??null});
// One event on the keys or pedals: a new state, the old one untouched (a speculative branch never changes another's,
// F04). A key held cannot be pressed again until released (a repeated note needs its reset, B03); a key is released by
// the digit holding it, and changes digit only by a substitution from the one holding it (§4.3); the sostenuto captures
// the keys held when it goes down, and only those (B02); the soft pedal shifts the hammers and holds nothing.
export function onKeyboard(state,event){
  const next={...state,held:new Map(state.held),undamped:new Set(state.undamped),captured:new Set(state.captured)};
  const settle=()=>{for(const key of [...next.undamped])if(!next.held.has(key)&&!next.sustain&&!(next.sostenuto&&next.captured.has(key)))next.undamped.delete(key)};
  const named=(value,what)=>{if(typeof value!=='string'||!value.length)throw new TypeError(`${event.kind}: a ${what}`);return value};
  switch(event.kind){
    case 'press':named(event.key,'key');named(event.effector,'digit');
      if(next.held.has(event.key))throw new RangeError(`${event.key} is held: a repeated note is released and reset first`);
      next.held.set(event.key,event.effector);next.undamped.add(event.key);break;
    case 'release':named(event.key,'key');
      if(!next.held.has(event.key))throw new RangeError(`${event.key} is not held`);
      if(event.effector&&event.effector!==next.held.get(event.key))throw new RangeError(`${event.key} is held by ${next.held.get(event.key)}, not ${event.effector}`);
      next.held.delete(event.key);settle();break;
    case 'substitute':named(event.key,'key');named(event.from,'digit');named(event.to,'digit');
      if(next.held.get(event.key)!==event.from)throw new RangeError(`${event.key} is not held by ${event.from}`);
      if([...next.held.values()].includes(event.to))throw new RangeError(`${event.to} holds another key`);
      next.held.set(event.key,event.to);break;
    case 'sustainDown':next.sustain=true;next.sustainDepth='full';break;
    case 'sustainHalfDown':next.sustain=true;next.sustainDepth='half';break;
    case 'sustainUp':next.sustain=false;next.sustainDepth=null;settle();break;
    case 'sostenutoDown':if(!next.sostenuto)next.captured=new Set(next.held.keys());next.sostenuto=true;break;
    case 'sostenutoUp':next.sostenuto=false;next.captured.clear();settle();break;
    case 'softDown':next.soft=true;break;
    case 'softUp':next.soft=false;break;
    default:throw new TypeError(`no keyboard event ${event.kind}`);
  }
  return Object.freeze(next);
}
