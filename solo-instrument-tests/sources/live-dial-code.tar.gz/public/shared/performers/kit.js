// Orchestration across a drum kit: a counted gesture's contacts (gestures.js) given targets, zones and strokes by named
// operators, checked limb by limb against the kit's transitions, and given a loudness by one of three prominence
// policies. The odd/prime rudiments report's M2 (research/MUSEBOTS_ODD_PRIME_RUDIMENTS_KIT_ORCHESTRATION_AND_STROKE_
// ACOUSTICS.md §5), over the performer contract's drummer (drummer.js).
//
// **The kit is a graph of target-zone-stroke states** (§5.3), not a list of drums. A state is a target of the kit (a
// snare, a tom, a ride), a zone on it where it is a membrane (the renderer's strike position: centre, off centre, edge),
// and a stroke the renderer has for it (percussion-expression.js PIECES: a rimshot, a cross stick, a ride's bell). A
// stroke the renderer does not have is returned as unsupported, never faked by a louder ordinary one (F6).
//
// **A transition is a limb's task** (§5.3): from one state to the next, the same limb needs its stroke's preparation
// (drummer.js) after the longer of its recovery and the stick's travel between the two targets at the kit's authored
// geometry (the arm moves while the stick rebounds), a change of zone, and a change of grip (a cross stick lays the
// stick across the rim). The kit's layout is authored, a standard
// right-handed setup, and a measured layout replaces it as data; a target with no known place is unknown, never assumed
// reachable. A rebound pair keeps its surface (§5.2's diddle distribution): splitting it needs a sweep, which this kit
// does not declare.
//
// **Three prominence policies** (§5.5), kept apart so their disagreement is visible: preserve excitation (each contact
// struck as its role asks, the targets sounding as they do), preserve perceived role (each struck as hard as its target
// needs to sound its role's level, within the drummer's range), and the mix's (the strokes as the first policy, a gain
// after them to the role's level: reported as gain, never as the drummer's force).
import {PIECES} from '../percussion-expression.js';
import {DRUMMER} from './drummer.js';
import {STATUS} from './contract.js';

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const KIT=Object.freeze({
  // An authored right-handed kit, as seen from the throne (cm: x to the right, y away): each target's piece in the
  // renderer, its drum note, its place, and the limbs that reach it. A layout of the player's own replaces it.
  targets:Object.freeze({
    kick:Object.freeze({piece:'kick',note:36,place:[0,10],limbs:['RF']}),
    hat:Object.freeze({piece:'hat',note:42,place:[-35,35],limbs:['RH','LH'],feet:['LF'],footStrokes:Object.freeze(['pedal','splash'])}),
    snare:Object.freeze({piece:'snare',note:38,place:[-8,30],limbs:['LH','RH']}),
    tom1:Object.freeze({piece:'tom',note:48,place:[-12,55],limbs:['RH','LH']}),
    tom2:Object.freeze({piece:'tom',note:45,place:[14,55],limbs:['RH','LH']}),
    floor:Object.freeze({piece:'tom',note:41,place:[40,28],limbs:['RH','LH']}),
    ride:Object.freeze({piece:'ride',note:51,place:[55,55],limbs:['RH','LH']}),
    crash:Object.freeze({piece:'crash',note:49,place:[-40,68],limbs:['RH','LH']}),
  }),
  // A membrane's zones as the renderer's strike positions (0 its centre, 1 its edge).
  zones:Object.freeze({centre:.1,off:.35,edge:.65}),
  // Authored: how fast a stick crosses the kit (cm a second), how long moving to another zone of one drum takes, and a
  // change of grip (s).
  stickCmPerSecond:400,zoneSeconds:.02,gripSeconds:.12,
  // Strokes played with the stick held otherwise than for a stroke of its tip.
  grips:Object.freeze({crossStick:'across'}),
  // Authored levels (dB) by role, for the prominence policies: what an accent, an interior stroke and a ghost note are
  // struck at (the excitation, 0 a normal stroke), and the drummer's range of excitation.
  roles:Object.freeze({accent:6,interior:-4,ghost:-14}),excitationRange:Object.freeze([-24,12]),
  // Navigation (§5.3, §7.2: timing, strike velocity and position are coupled; the user, 27 September 2026, on a fill:
  // "there should be more difference of hit strength within the fill (as well, perhaps, as minor differences of timing
  // at that speed) resulting from how the drummer has to navigate the kit"). Authored, not measured: a full stroke's
  // lift takes `fullLiftSeconds`; a stroke with less time to lift (after its recovery, the stick's travel, a zone or a
  // grip) is struck from lower, down to `lowestLift` of its height; its excitation falls as the square root of its height
  // (a stick's speed from a free fall, v = sqrt(2 g h)); and a move that leaves less spare time than `lateBelowSeconds`
  // lands up to `mostLateSeconds` late.
  navigation:Object.freeze({fullLiftSeconds:.25,lowestLift:.15,mostLateSeconds:.008,lateBelowSeconds:.04}),
  // A rebound pair's second contact (§7, T23), by its technique: left to the rebound (it has only the rebound's gap to
  // lift in, so at speed it is lower), balanced (the wrist or the fingers bring it to the first's height), or reinforced
  // (a pull stroke's second, higher than the first by `lift` of a full stroke). Each active one needs the pair's gap to
  // be at least `leastGapSeconds`. Authored, this kit's own: no universal "second diddle" table (§7 finds none).
  second:Object.freeze({balanced:Object.freeze({leastGapSeconds:1/14}),reinforced:Object.freeze({leastGapSeconds:.1,lift:.2})}),
});

// ---- States ----------------------------------------------------------------------------------------------------------
// A state of the kit: {target, stroke, zone}, checked against the kit and the renderer. {state} or {status, reason}.
export function kitState({target,stroke=null,zone=null},{kit=KIT}={}){
  const place=kit.targets[target];
  if(!place)return {status:STATUS.unknown,reason:`no ${target} in this kit`};
  const piece=PIECES[place.piece];
  const chosen=stroke??piece?.defaultStroke;
  if(!piece?.strokes?.[chosen])return {status:STATUS.unknown,reason:`the renderer has no ${chosen} for a ${place.piece}: unsupported, not faked`};
  if(zone!==null&&!piece.membrane)return {status:STATUS.unknown,reason:`a ${place.piece} has no membrane zones`};
  if(zone!==null&&!(zone in kit.zones))return {status:STATUS.unknown,reason:`no zone ${zone}`};
  return {state:Object.freeze({target,stroke:chosen,zone:piece.membrane?zone??'off':null})};
}
const distanceCm=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1]);
// What a limb needs to go from one state to the next: {status, seconds, reason?}. `pair`: the two contacts are one
// rebound action (§5.2): the same surface, at the rebound's own gap.
export function transition(from,to,{limb,pair=false,kit=KIT,drummer=DRUMMER}={}){
  const target=kit.targets[to.target],byFoot=(target?.footStrokes??[]).includes(to.stroke);
  // A foot reaches what it plays (the kick), or a target's foot strokes (the hat's pedal); a hand never those.
  const reaches=byFoot?(target.feet??[]).includes(limb):Boolean(target?.limbs.includes(limb));
  if(!reaches)return {status:STATUS.violates,seconds:Infinity,reason:`${limb} does not play the ${to.target}'s ${to.stroke}`};
  if(!from)return {status:STATUS.witness,seconds:0};
  if(pair){
    if(from.target!==to.target||from.zone!==to.zone||from.stroke!==to.stroke)
      return {status:STATUS.violates,seconds:Infinity,reason:'a rebound pair keeps its surface: splitting it needs a sweep this kit does not declare'};
    return {status:STATUS.witness,seconds:drummer.reboundSeconds};
  }
  const a=kit.targets[from.target]?.place,b=target.place;
  if(!a||!b)return {status:STATUS.unknown,seconds:null,reason:'a target with no known place'};
  const travel=from.target===to.target?0:distanceCm(a,b)/kit.stickCmPerSecond;
  const zone=from.target===to.target&&from.zone!==to.zone?kit.zoneSeconds:0;
  const grip=(kit.grips[from.stroke]??'tip')!==(kit.grips[to.stroke]??'tip')?kit.gripSeconds:0;
  return {status:STATUS.witness,seconds:Math.max(drummer.recoverSeconds,travel)+zone+grip+drummer.prepareSeconds};
}

// ---- Checking an orchestration ----------------------------------------------------------------------------------------
// An orchestration: [{id, action, limb, at (seconds), state, role}], a gesture's contacts given limbs and states. Each
// limb's consecutive contacts against their transition. {status, violations, unknowns}.
export function checkOrchestration(contacts,{kit=KIT,drummer=DRUMMER}={}){
  const violations=[],unknowns=[],byLimb=new Map;
  for(const contact of contacts){
    if(contact.unsupported){unknowns.push({contact:contact.id,reason:contact.unsupported});continue}
    if(!byLimb.has(contact.limb))byLimb.set(contact.limb,[]);byLimb.get(contact.limb).push(contact);
  }
  for(const [limb,list] of byLimb){
    list.sort((a,b)=>a.at-b.at);
    let previous=null;
    for(const contact of list){
      const pair=previous!==null&&previous.action===contact.action;
      const need=transition(previous?.state??null,contact.state,{limb,pair,kit,drummer});
      if(need.status===STATUS.violates)violations.push({contact:contact.id,limb,reason:need.reason});
      else if(need.status===STATUS.unknown)unknowns.push({contact:contact.id,limb,reason:need.reason});
      else if(previous&&contact.at-previous.at<need.seconds-1e-9)
        violations.push({contact:contact.id,limb,reason:`${+(contact.at-previous.at).toFixed(4)} s from ${previous.state.target} to ${contact.state.target}, which needs ${+need.seconds.toFixed(4)} s`});
      else if(pair&&contact.second&&contact.second!=='rebound'){
        const technique=kit.second[contact.second],gap=contact.at-previous.at;
        if(!technique)unknowns.push({contact:contact.id,limb,reason:`no ${contact.second} second stroke in this kit`});
        else if(gap<technique.leastGapSeconds-1e-9)violations.push({contact:contact.id,limb,reason:`a ${contact.second} second stroke needs ${+technique.leastGapSeconds.toFixed(4)} s after the first; the pair has ${+gap.toFixed(4)} s`});
      }
      previous=contact;
    }
  }
  // What the part asks of each stroke's height (T20): a stroke asked from higher than its hand has time to lift is not
  // playable as asked, however the notes' times allow, so asking more can make a passage unplayable.
  if(contacts.some(contact=>Number.isFinite(contact.demand))&&!violations.length){
    const reached=new Map(navigation(contacts,{kit,drummer}).map(entry=>[entry.id,entry]));
    for(const contact of contacts){
      const got=reached.get(contact.id);
      if(Number.isFinite(contact.demand)&&got&&got.height<contact.demand-1e-9)
        violations.push({contact:contact.id,limb:contact.limb,reason:`asked a stroke from ${contact.demand} of full height; its stick has ${got.liftSeconds} s to lift, which reaches ${got.height}`});
    }
  }
  return {status:violations.length?STATUS.violates:unknowns.length?STATUS.unknown:STATUS.witness,violations,unknowns};
}

// ---- Operators (§5.2) ------------------------------------------------------------------------------------------------
// Each takes a gesture (gestures.js), the seconds a tick lasts and its own settings, and returns an orchestration
// {operator, contacts, preserves}: the gesture's contacts, each with its limb (R the right hand, L the left), seconds,
// state and role (an accent where `accents` names its slot, else interior), and what the operator keeps of the gesture.
// A rebound pair's contacts always share their state.
function base(played,{secondsPerTick,accents=[],hands=DRUMMER.hands}){
  if(!(secondsPerTick>0))throw new RangeError('an orchestration needs the seconds a tick lasts');
  const accented=new Set(accents);
  return played.contacts.map(contact=>({id:contact.id,action:contact.action,hand:contact.hand,limb:hands[contact.hand],slot:contact.slot,
    at:contact.at.toNumber()*secondsPerTick-(contact.before??0),role:contact.role==='grace'?'ghost':accented.has(contact.slot)?'accent':'interior'}));
}
// Give each contact the state `choose(contact, index, contacts)` names, the first of each rebound pair deciding for both.
function assign(contacts,choose,{kit=KIT}={}){
  const byAction=new Map;
  return contacts.map((contact,index)=>{
    const wanted=byAction.get(contact.action)??choose(contact,index,contacts);
    if(!byAction.has(contact.action))byAction.set(contact.action,wanted);
    const made=kitState(wanted,{kit});
    return made.state?{...contact,state:made.state}:{...contact,state:null,unsupported:made.reason};
  });
}
const PRESERVES_ALL=Object.freeze({contacts:true,slots:true,accents:true});
// Accent extraction: the interior on one surface, the accents moved to others (in turn), their prominence kept by the
// prominence policy, not by one velocity for every target.
export function accentExtraction(played,{secondsPerTick,accents,interior={target:'snare'},accentTargets=[{target:'tom1'},{target:'floor'}],kit=KIT}={}){
  let next=0;
  const contacts=assign(base(played,{secondsPerTick,accents}),contact=>contact.role==='accent'?accentTargets[next++%accentTargets.length]:interior,{kit});
  return {operator:'accent-extraction',contacts,preserves:PRESERVES_ALL};
}
// Hand-separated voices: each hand its own target, its dynamic role free to change.
export function handSeparated(played,{secondsPerTick,accents=[],targets={R:{target:'ride',stroke:'bow'},L:{target:'snare'}},kit=KIT}={}){
  return {operator:'hand-separated',contacts:assign(base(played,{secondsPerTick,accents}),contact=>targets[contact.hand],{kit}),preserves:PRESERVES_ALL};
}
// Contour transfer: a contour (0 to 1 at each contact's place in the phrase, or a function of it) onto an ordered
// register of targets, low to high.
export function contourTransfer(played,{secondsPerTick,accents=[],contour=position=>1-position,register=[{target:'floor'},{target:'tom2'},{target:'tom1'},{target:'snare'}],kit=KIT}={}){
  const contacts=base(played,{secondsPerTick,accents}),first=contacts[0].at,last=contacts.at(-1).at,span=Math.max(1e-9,last-first);
  const value=(contact,index)=>{const raw=typeof contour==='function'?contour((contact.at-first)/span):contour[index];return Math.max(0,Math.min(1,Number(raw)||0))};
  return {operator:'contour-transfer',contacts:assign(contacts,(contact,index)=>register[Math.round(value(contact,index)*(register.length-1))],{kit}),preserves:PRESERVES_ALL};
}
// Parallel, contrary and oblique motion along a path of targets (§5.2, R03): both hands step the same way; the right up
// as the left goes down; or the left held on its target while the right moves.
export function motion(played,{secondsPerTick,accents=[],kind='parallel',path=[{target:'snare'},{target:'tom1'},{target:'tom2'},{target:'floor'}],kit=KIT}={}){
  if(!['parallel','contrary','oblique'].includes(kind))throw new TypeError(`motion is parallel, contrary or oblique, not ${kind}`);
  const contacts=base(played,{secondsPerTick,accents}),steps={R:0,L:0},last=path.length-1;
  const where=(hand,step)=>{
    if(kind==='oblique'&&hand==='L')return path[0];
    if(kind==='contrary'&&hand==='L')return path[Math.max(0,last-Math.min(last,step))];
    return path[Math.min(last,step)];
  };
  const seen=new Set;
  const chosen=assign(contacts,contact=>{const step=steps[contact.hand];if(!seen.has(contact.action)){seen.add(contact.action);steps[contact.hand]++}return where(contact.hand,step)},{kit});
  return {operator:`${kind}-motion`,contacts:chosen,preserves:PRESERVES_ALL};
}
// Linearization: contacts redistributed among hands and feet, none at once. `feet` names the slots the right foot (the
// kick) takes; a hand's contact moved to a foot leaves the hand free. The hands' targets are a state, or a function of a
// contact (so another operator's choice, an accent moved to a tom, can come with it). It keeps the contact count and the
// slots; the accents only if the kick is given no accent (it says which).
export function linearize(played,{secondsPerTick,accents=[],feet=[],hands={target:'snare'},foot={target:'kick'},kit=KIT}={}){
  const kicks=new Set(feet);
  const contacts=assign(base(played,{secondsPerTick,accents}).map(contact=>kicks.has(contact.slot)?{...contact,limb:'RF',hand:null,action:`${contact.action}:kick`}:contact),
    contact=>contact.limb==='RF'?foot:typeof hands==='function'?hands(contact):hands,{kit});
  const lost=contacts.filter(contact=>contact.limb==='RF'&&contact.role==='accent').length;
  return {operator:'linearization',contacts,preserves:{contacts:true,slots:true,accents:lost===0}};
}
// Zone development: one drum, its strike moving across its zones over the phrase (centre toward the edge by default).
export function zoneDevelopment(played,{secondsPerTick,accents=[],target='snare',zones=['centre','off','edge'],kit=KIT}={}){
  const contacts=base(played,{secondsPerTick,accents}),n=contacts.length;
  return {operator:'zone-development',contacts:assign(contacts,(contact,index)=>({target,zone:zones[Math.min(zones.length-1,Math.floor(index*zones.length/n))]}),{kit}),preserves:PRESERVES_ALL};
}

// ---- Navigation --------------------------------------------------------------------------------------------------------
// What moving about the kit does to each contact of an orchestration: how much time it had to lift the stick, the height
// that gives it, its excitation (dB, 0 a full stroke), and how late it lands. A rebound pair's second contact has only
// the rebound's gap to lift in, so at speed it is lower, and slower it is not: no fixed "second of a diddle" table (§7).
// Unless its technique says otherwise (`second`, T23): balanced, at the first's height; reinforced, above it.
// [{id, liftSeconds, height, excitationDb, lateSeconds}], in the orchestration's order.
export function navigation(contacts,{kit=KIT,drummer=DRUMMER}={}){
  const choices=kit.navigation,out=new Map,byLimb=new Map;
  for(const contact of contacts){if(!contact.state)continue;if(!byLimb.has(contact.limb))byLimb.set(contact.limb,[]);byLimb.get(contact.limb).push(contact)}
  for(const list of byLimb.values()){
    list.sort((a,b)=>a.at-b.at);let previous=null,landed=null;
    for(const contact of list){
      let lift=choices.fullLiftSeconds,late=0;
      if(previous){
        // Timed from where the stroke before it landed, late or not (T34): a late stroke leaves the next less time.
        const gap=contact.at-landed,pair=previous.action===contact.action;
        const need=transition(previous.state,contact.state,{limb:contact.limb,pair,kit,drummer});
        // Of the gap, what is left once the stick has recovered or travelled (the longer), changed zone and grip.
        const occupied=pair?0:Number.isFinite(need.seconds)?need.seconds-drummer.prepareSeconds:gap;
        lift=Math.max(0,Math.min(choices.fullLiftSeconds,gap-occupied));
        const spare=Number.isFinite(need.seconds)?gap-need.seconds:0;
        // A tight move lands a little late; one left less than it needs by the stroke before (a pair's second too, after a
        // late first) lands when it can.
        if(pair)late=Math.max(0,-spare);
        else if(spare<choices.lateBelowSeconds)late=Math.max(-spare,choices.mostLateSeconds*(1-Math.max(0,spare)/choices.lateBelowSeconds));
      }
      let height=choices.lowestLift+(1-choices.lowestLift)*Math.min(1,lift/choices.fullLiftSeconds);
      const second=previous&&previous.action===contact.action&&contact.second&&contact.second!=='rebound'?kit.second[contact.second]:null;
      if(second&&contact.at-previous.at>=second.leastGapSeconds-1e-9){
        const first=out.get(previous.id).height;height=contact.second==='reinforced'?Math.min(1,first+second.lift):first;
      }
      out.set(contact.id,{id:contact.id,liftSeconds:+lift.toFixed(6),height:+height.toFixed(6),excitationDb:+(10*Math.log10(height)).toFixed(3),lateSeconds:+late.toFixed(6),
        ...(second?{second:contact.second}:{})});
      previous=contact;landed=contact.at+late;
    }
  }
  return contacts.filter(contact=>out.has(contact.id)).map(contact=>out.get(contact.id));
}

// ---- Prominence (§5.5) -----------------------------------------------------------------------------------------------
// Each contact's excitation (dB against a normal stroke), the stroke's own level in the renderer (PIECES), what it is
// predicted to sound at, and any gain after it: {policy, contacts: [{id, role, excitationDb, gainDb, soundsDb,
// clamped?}], evidence}. 'excitation': struck as the role asks; 'role': struck as hard as the target needs to sound the
// role's level, within the drummer's range; 'mix': struck as the role asks, a gain after it to the role's level, which is
// the mix's, not the drummer's.
export function prominence(orchestration,{policy='excitation',kit=KIT}={}){
  if(!['excitation','role','mix'].includes(policy))throw new TypeError(`a prominence policy is excitation, role or mix, not ${policy}`);
  const [least,most]=kit.excitationRange;
  const contacts=orchestration.contacts.map(contact=>{
    const wanted=kit.roles[contact.role]??0;
    if(!contact.state)return {id:contact.id,role:contact.role,excitationDb:null,gainDb:null,soundsDb:null,unsupported:contact.unsupported};
    const own=PIECES[kit.targets[contact.state.target].piece].strokes[contact.state.stroke].levelDb??0;
    let excitationDb=wanted,gainDb=0,clamped=false;
    if(policy==='role'){excitationDb=wanted-own;if(excitationDb<least||excitationDb>most){clamped=true;excitationDb=Math.max(least,Math.min(most,excitationDb))}}
    if(policy==='mix')gainDb=wanted-(excitationDb+own);
    return {id:contact.id,role:contact.role,excitationDb,gainDb,soundsDb:excitationDb+own+gainDb,...(clamped?{clamped:true}:{})};
  });
  return {policy,contacts,evidence:'authored'};
}
