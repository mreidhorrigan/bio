// A wind player's vocal tract (research/MODELING_GAPS.md, "No vocal tract"): an impedance upstream of the reed, in series
// with the bore, a sum of resonances -- each its frequency, its Q and its impedance at its peak (Pa s/m^3), a parallel
// resonance's, Z(f) = peak / (1 + jQ (f/f0 - f0/f)) -- which the engine steps inside the oscillation (native/openwind
// src/tract.rs), so that it bends a note, holds a register or chooses another, as no filter on the sound after it can.
// Written once for every wind and brass player; its measured ranges the registry's (registry/players/winds.json:
// Fritz & Wolfe 2005, Chen, Smith & Wolfe 2009), on the player's node.
import {player,playerEntry} from '../../../registry/registry.js';

export class VocalTract {
  constructor(resonances=[]){this.resonances=resonances.map(r=>({frequency:r.frequency,q:r.q,peak:r.peak}))}
  // The tract as the instrument's players keep it in normal playing at a note sounding at `hz`: its first resonance
  // within its measured range (the geometric middle of each), and above the note's following frequency the resonance
  // that follows it, as measured (its offset above the note, its peak, on average).
  static normal(instrument,hz){
    const middle=([a,b])=>Math.sqrt(a*b),at=path=>playerEntry(instrument,`tract.${path}`);
    const resonances=[{frequency:middle(at('first.frequency').range),q:player(instrument,'tract.first.q'),peak:middle(at('first.peak').range)}];
    if(hz>=player(instrument,'tract.normal.above'))
      resonances.push({frequency:hz+player(instrument,'tract.normal.offset'),q:player(instrument,'tract.normal.q'),peak:player(instrument,'tract.normal.peak')});
    return new VocalTract(resonances);
  }
  // Its impedance at `hz` (complex, Pa s/m^3): what the reed meets upstream, in series with the bore's.
  impedance(hz){
    let re=0,im=0;
    for(const {frequency,q,peak} of this.resonances){
      const x=q*(hz/frequency-frequency/hz),d=1+x*x;re+=peak/d;im-=peak*x/d;
    }
    return {re,im};
  }
  magnitude(hz){const {re,im}=this.impedance(hz);return Math.hypot(re,im)}
  // As the engine's streaming player is told it (stream.rs TractLine): moved to over `seconds`.
  line(seconds){return {resonances:this.resonances,seconds}}
}
