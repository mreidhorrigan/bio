// A mallet player's hands over bars (the family atlas's F29, mallet bars, bells and fixed-pitch percussion: the marimba,
// vibraphone, xylophone and glockenspiel, and the gamelan's metallophones in their own tunings), planned through the
// performer contract's one solver (contract.js searchGroups), as the guitar and the piano are. The world-instruments
// report: "For mallet instruments, solve joint grip/target geometry and damping. Additional mallets do not constitute
// independent extra arms. Ringing tones require an acoustic state; leaving them to decay is not the same as damping them,
// and a musically necessary damp can occupy the next action's effector."
//
// **Bars, not pitches.** A bar sounds its set's pitch. By default the set is built for the piece, a bar wherever the
// band's pitches are, as the fantasy piano's keys are (`bars: 'band'`); a fixed set (`bars: 'fixed'`, twelve to the
// octave, or a gamelan's own list of pitches) has no bar for a pitch between its bars, which is refused, never rounded.
// Bars lie where a keyboard's would (the naturals in a row, each accidental over the gap between two), narrowing up the
// range (MALLETS.barMm, authored); a pitch between two keys lies between them.
//
// **Two hands, one or two mallets each.** More mallets are not more arms: a hand's two mallets strike from where the
// hand is, from adjacent bars to about an octave apart (MALLETS.leastMm, mostMm; authored), and move with it; the
// hands do not cross (the left's mallets below the right's). A mallet strikes again once its stroke has recovered
// (MALLETS.strokeSeconds), and a hand reaches a new place at MALLETS.handMmPerSecond (authored).
//
// **Ringing, rolls and damping.** A marimba's or a xylophone's bar rings briefly (MALLETS.instruments[kind].ringSeconds,
// by register), so a note held longer than it rings is rolled: two mallets alternating at MALLETS.rollHz, both held
// for the note (a hand's two where it has two; both hands' where each has one). A vibraphone's bars ring on while its
// pedal is down: a foot holds it through a group's notes, and lifting it damps every bar. A glockenspiel rings on
// undamped. A dead stroke's mallet stays on its bar to stop it (MALLETS.deadSeconds). Under the pedal a bar is stopped
// alone by a mallet pressed on it without striking it (`damp: 'mallet'`, at the note's end), as the other hand strikes
// on (simultaneous dampening: Jones 2009, research/kalman-references.md): the mallet that struck it, its hand kept at the
// bar until the press ends (MALLETS.dampSeconds).
//
// **What is not modelled yet**, and says so: a one-handed roll's own rate, bowed bars, a hand's one mallet damping while
// its other strikes, damping with the hand, the grip's change of span as its own motion (taken with the hand's travel),
// and a dynamics model of the strokes (expression is the bot's).
import {action,checkReservations,profile,searchGroups,STATUS,witness} from './contract.js';
import {instrumentRange} from './instrument-ranges.js';

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const MALLETS=Object.freeze({
  // Sounding ranges (MIDI: the instrument registry's typical instruments, instrument-ranges.js -- a 4.3-octave marimba,
  // a 3-octave vibraphone, a 3.5-octave xylophone, a glockenspiel G5-C8, as they sound) and how long a bar rings at mf,
  // at the bottom of the range and at its top (s; authored). Rolled where its bars ring briefly; a pedal where it has one.
  instruments:Object.freeze({
    marimba:Object.freeze({range:instrumentRange('marimba').range,ringSeconds:Object.freeze([1.2,.3]),rolls:true,pedal:false}),
    vibraphone:Object.freeze({range:instrumentRange('vibraphone').range,ringSeconds:Object.freeze([6,3]),rolls:false,pedal:true}),
    xylophone:Object.freeze({range:instrumentRange('xylophone').range,ringSeconds:Object.freeze([.6,.15]),rolls:true,pedal:false}),
    glockenspiel:Object.freeze({range:instrumentRange('glockenspiel').range,ringSeconds:Object.freeze([4,2]),rolls:false,pedal:false}),
  }),
  // A natural bar's width at the bottom and at the top of the range (mm), the accidentals over the gaps (authored).
  barMm:Object.freeze([60,38]),
  // A hand's two mallets, from adjacent bars to about an octave apart (mm between their bars' centres; authored).
  leastMm:30,mostMm:420,
  // How fast a hand crosses the bars (mm a second), how long a stroke holds its mallet (s: about twelve a second from
  // one mallet), a roll's strokes a second between two mallets, how long a dead stroke holds its mallet (pressed on the
  // bar to stop it, then lifted), and how long a mallet presses a ringing bar to stop it without striking it (authored).
  handMmPerSecond:3000,strokeSeconds:1/12,rollHz:16,deadSeconds:.14,dampSeconds:.1,
  // A bar sounds a pitch within this (semitones); notes starting within `together` of each other are one group (s).
  tolerance:.05,together:.005,
  // Costs, authored: each millimetre a hand travels, and each millimetre of a hand's span (a wide grip taken only where
  // needed).
  cost:Object.freeze({travelPerMm:.001,spanPerMm:.0002}),
  maxStates:4096,
});
const NATURALS=[0,2,4,5,7,9,11];

// ---- The instrument --------------------------------------------------------------------------------------------------
// An instrument: its kind, its bars ('band': wherever a pitch is asked; 'fixed': twelve to the octave in its range; or a
// list of pitches, a gamelan's own), and its range. -> {kind, range, rolls, pedal, ringSeconds, fixed, bars (a sorted
// list, or null where the set is the band's)}.
export function malletInstrument({kind='marimba',bars='band',range=null,choices=MALLETS}={}){
  const model=choices.instruments[kind];if(!model)throw new RangeError(`a mallet instrument is one of ${Object.keys(choices.instruments).join(', ')}`);
  const [low,high]=range??model.range;
  const list=Array.isArray(bars)?[...bars].map(Number).filter(pitch=>pitch>=low-1e-9&&pitch<=high+1e-9).sort((a,b)=>a-b)
    :bars==='fixed'?Array.from({length:Math.floor(high)-Math.ceil(low)+1},(_,k)=>Math.ceil(low)+k):null;
  if(bars!=='band'&&!list?.length)throw new RangeError('a fixed set of bars has at least one bar in its range');
  return Object.freeze({kind,range:Object.freeze([low,high]),rolls:model.rolls,pedal:model.pedal,ringSeconds:model.ringSeconds,fixed:bars!=='band',bars:list&&Object.freeze(list)});
}
// The bar that sounds a pitch: the pitch itself on a set built for the piece (within its range); on a fixed set, its bar
// within the tolerance. -> the bar's pitch, or null (refused: no bar sounds it).
export function barFor(instrument,pitch,{choices=MALLETS}={}){
  const [low,high]=instrument.range;if(!(pitch>=low-choices.tolerance&&pitch<=high+choices.tolerance))return null;
  if(!instrument.fixed)return pitch;
  const bar=instrument.bars.reduce((best,candidate)=>Math.abs(candidate-pitch)<Math.abs(best-pitch)?candidate:best,instrument.bars[0]);
  return Math.abs(bar-pitch)<=choices.tolerance?bar:null;
}
// A bar's centre along the instrument (mm from its lowest C's natural): the naturals in a row, narrowing up the range,
// an accidental over the gap between its two naturals, a pitch between two semitones between their places.
export function barX(pitch,{choices=MALLETS,range=MALLETS.instruments.marimba.range}={}){
  const whole=Math.floor(pitch),fraction=pitch-whole;
  if(fraction>1e-9)return barX(whole,{choices,range})+(barX(whole+1,{choices,range})-barX(whole,{choices,range}))*fraction;
  const [low,high]=range,width=p=>choices.barMm[0]+(choices.barMm[1]-choices.barMm[0])*Math.max(0,Math.min(1,(p-low)/Math.max(1,high-low)));
  // The naturals below it, each its own width, and its own centre; an accidental on the edge between its neighbours.
  const pc=((whole%12)+12)%12,octave=Math.floor(whole/12),natural=NATURALS.indexOf(pc);
  const naturalIndex=octave*7+(natural>=0?natural:NATURALS.indexOf(pc-1));
  let x=0;for(let k=0;k<naturalIndex;k++){const n=Math.floor(k/7)*12+NATURALS[k%7];x+=width(n)}
  const own=width(whole);
  return natural>=0?x+own/2:x+own;
}

// ---- The player ------------------------------------------------------------------------------------------------------
// A mallet player's profile: two hands (LH, RH), each with one or two mallets (LH.1 and LH.2 low to high, the same for
// RH), and a foot for a pedal. `unavailable` names any of them.
export function malletist({id='malletist',performer='malletist',mallets=4,unavailable=[],evidence='authored'}={}){
  if(mallets!==2&&mallets!==4)throw new RangeError('a mallet player holds two mallets or four');
  const perHand=mallets/2,state=name=>unavailable.includes(name)?'unavailable':'available';
  const resources=[];
  for(const hand of ['LH','RH']){
    resources.push({id:hand,kind:'body',availability:state(hand),evidence});
    for(let k=1;k<=perHand;k++){const id=`${hand}.${k}`;resources.push({id,kind:'effector',parents:[hand],availability:unavailable.includes(hand)?'unavailable':state(id),evidence})}
  }
  resources.push({id:'F',kind:'effector',availability:state('F'),evidence});
  return profile({id,performer,resources});
}
const malletsOf=(who,hand)=>[...who.resources.values()].filter(resource=>resource.kind==='effector'&&resource.parents.includes(hand)&&resource.availability==='available').map(resource=>resource.id).sort();
export const ringOf=(instrument,pitch)=>{
  const [low,high]=instrument.range,[bottom,top]=instrument.ringSeconds,t=Math.max(0,Math.min(1,(pitch-low)/Math.max(1,high-low)));
  return bottom+(top-bottom)*t;
};

// A group's grips: every way its bars can go to the hands (low bars left, high right, the hands not crossing), each
// hand's bars no more than its mallets and within its span. -> [{hands: {LH: [bar...], RH: [bar...]}, x: {LH, RH}}].
function grips(bars,who,{choices=MALLETS,range}={}){
  const sorted=[...bars].sort((a,b)=>a-b),out=[],hands={LH:malletsOf(who,'LH'),RH:malletsOf(who,'RH')};
  for(let split=0;split<=sorted.length;split++){
    const left=sorted.slice(0,split),right=sorted.slice(split);
    if(left.length>hands.LH.length||right.length>hands.RH.length)continue;
    const span=list=>list.length<2?0:barX(list.at(-1),{choices,range})-barX(list[0],{choices,range});
    if([left,right].some(list=>list.length>1&&(span(list)<choices.leastMm-1e-9||span(list)>choices.mostMm+1e-9)))continue;
    const centre=list=>list.length?(barX(list[0],{choices,range})+barX(list.at(-1),{choices,range}))/2:null;
    if(left.length&&right.length&&barX(left.at(-1),{choices,range})>=barX(right[0],{choices,range})-choices.leastMm+1e-9)continue;
    out.push({hands:{LH:left,RH:right},x:{LH:centre(left),RH:centre(right)},span:span(left)+span(right)});
  }
  return out;
}

// ---- Passages --------------------------------------------------------------------------------------------------------
// Plan a passage [{pitch, start, end, articulation?, damp?}] on an instrument: which hand and mallet strikes each note,
// rolled where a bar held longer than it rings would die, a dead stroke's mallet held on its bar (MALLETS.deadSeconds),
// a note damped by a mallet (`damp: 'mallet'`) pressed at its end by the mallet that struck it, its hand at the bar till
// then (MALLETS.dampSeconds after), the pedal held through a vibraphone's notes. -> {status, path?, cost?, witness?,
// reason?}; refused (unknown) where a pitch has no bar.
export function planMallets(input,{instrument=malletInstrument(),who=malletist(),choices=MALLETS}={}){
  if(!input.length)return {status:STATUS.witness,path:[],cost:0};
  const notes=input.map((note,index)=>({...note,id:note.id??`n${index}`}));
  for(const note of notes){
    if(!(note.end>note.start))throw new RangeError(`note ${note.id}: a positive duration`);
    const bar=barFor(instrument,note.pitch,{choices});
    if(bar===null)return {status:STATUS.unknown,reason:`pitch ${note.pitch} has no bar on this ${instrument.kind}${instrument.fixed?' (a fixed set: a pitch between its bars is not rounded)':''}`};
    note.bar=bar;note.rolled=instrument.rolls&&note.end-note.start>ringOf(instrument,bar)+1e-9;
  }
  const groups=[];
  for(const note of [...notes].sort((a,b)=>a.start-b.start||a.bar-b.bar)){const last=groups.at(-1);if(last&&note.start-last.at<=choices.together)last.notes.push(note);else groups.push({at:note.start,notes:[note]})}
  const range=instrument.range;
  // A hand's state: where it is (mm), when it left its bars (its stroke; a roll's end, its mallets on the bars till then),
  // when its mallets are free (a stroke's recovery, a roll's end).
  const stateKey=state=>JSON.stringify([state.LH?.x??null,state.RH?.x??null,state.LH?.from??null,state.RH?.from??null,state.LH?.free??null,state.RH?.free??null]);
  const expand=(group,state)=>{
    const moves=[];
    for(const grip of grips(group.notes.map(note=>note.bar),who,{choices,range})){
      let ok=true,cost=grip.span*choices.cost.spanPerMm;const next={...state},strokes=[];
      for(const hand of ['LH','RH']){
        const bars=grip.hands[hand];if(!bars.length)continue;
        const before=state[hand],free=before?.free??-Infinity,travel=before?Math.abs(grip.x[hand]-before.x):0;
        // The hand's mallets must be free, and the hand there in time.
        if(group.at<free-1e-9){ok=false;break}
        if(before&&travel>choices.handMmPerSecond*Math.max(0,group.at-before.from)+1e-9){ok=false;break}
        cost+=travel*choices.cost.travelPerMm;
        const mallets=malletsOf(who,hand),held=group.notes.filter(note=>bars.includes(note.bar));
        // A rolled note takes two mallets for its whole length: this hand's two, where it has two and strikes it alone.
        const rolled=held.filter(note=>note.rolled);
        if(rolled.length&&(rolled.length>1||held.length>1||mallets.length<2)){ok=false;break}
        // A note its mallet damps keeps the hand at its bar until the press ends.
        const pressed=held.filter(note=>note.damp==='mallet'),released=pressed.length?Math.max(...pressed.map(note=>note.end))+choices.dampSeconds:null;
        const struck=rolled.length?rolled[0].end:group.at+(held.some(note=>note.articulation==='dead')?choices.deadSeconds:choices.strokeSeconds),until=Math.max(struck,released??-Infinity);
        held.forEach((note,k)=>strokes.push({note:note.id,pitch:note.pitch,bar:note.bar,hand,x:+grip.x[hand].toFixed(1),mallet:rolled.length?mallets.join('+'):mallets[Math.min(k,mallets.length-1)],rolled:Boolean(rolled.length),...(note.damp==='mallet'?{damp:true}:{})}));
        next[hand]={x:grip.x[hand],from:rolled.length||released!==null?until:group.at,free:until};
      }
      if(ok)moves.push({status:'supported',cost,state:next,step:{at:group.at,strokes}});
    }
    return moves;
  };
  const found=searchGroups(groups,{initial:{LH:null,RH:null},expand,stateKey,maxStates:choices.maxStates});
  if(found.status!==STATUS.witness)return {status:found.status,reason:found.group?`no grip plays the group at ${found.group.at} s (${found.group.notes.map(note=>note.pitch).join(', ')})`:null};
  return {status:STATUS.witness,path:found.path,cost:+found.cost.toFixed(6),witness:malletWitness(who,instrument,notes,found.path,{choices})};
}
// The witness: each stroke its mallet's reservation for its recovery (a dead stroke's for its press), a roll both mallets'
// for its note, a mallet's damp its release at the note's end, each in its hand's configuration (where the hand is), a
// vibraphone's pedal the foot's through the notes it sustains, checked by the contract.
function malletWitness(who,instrument,notes,path,{choices=MALLETS}={}){
  const actions=[],byId=new Map(notes.map(note=>[note.id,note]));
  for(const step of path)for(const stroke of step.strokes){
    const note=byId.get(stroke.note),mallets=stroke.mallet.split('+'),dead=note.articulation==='dead',configuration=`${stroke.hand}@${Math.round(stroke.x)}`;
    actions.push(action({id:`${stroke.rolled?'roll':dead?'dead':'stroke'}:${stroke.note}`,technique:stroke.rolled?'roll':dead?'dead':'stroke',contacts:[stroke.note],contactSeconds:[note.start],
      reservations:mallets.map(mallet=>({resource:mallet,phase:stroke.rolled?'hold':'excite',start:note.start,end:stroke.rolled?note.end:note.start+(dead?choices.deadSeconds:choices.strokeSeconds),configuration}))}));
    if(stroke.damp)actions.push(action({id:`damp:${stroke.note}`,technique:'damp',contacts:[stroke.note],contactSeconds:[note.end],
      reservations:[{resource:mallets[0],phase:'release',start:note.end,end:note.end+choices.dampSeconds,configuration}]}));
  }
  // A vibraphone's pedal down through the notes it sustains (a damped note has it up).
  const pedalled=notes.filter(note=>note.articulation!=='damped');
  if(instrument.pedal&&pedalled.length){
    const start=Math.min(...pedalled.map(note=>note.start)),end=Math.max(...pedalled.map(note=>note.end));
    actions.push(action({id:'pedal',technique:'pedal',contacts:[],reservations:[{resource:'F',phase:'hold',start,end}]}));
  }
  return witness({who,actions,checks:[{id:'mallets-hands-and-foot',evidence:'authored',...checkReservations(who,actions)},{id:'dynamics',status:STATUS.unknown}]});
}
