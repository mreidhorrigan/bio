// A shaken idiophone's player (the family atlas's F35: shaker, cabasa, tambourine; shaker_clodbot.js plays one): a
// continuous gesture, not a stroke commanded per grain. The hand swings back and forth without stopping, and each
// reversal sounds: the down stroke with the arm's weight, the up stroke lighter. The atlas: "Do not represent every
// grain collision as an independently commanded human stroke."
//
// **Its rate.** The hand reverses on the finest subdivision it can shake at the tempo: every tick where a tick is no
// shorter than a reversal, else every second tick, and so on, always a divisor of the beat so the strokes keep to its
// grid. A reversal is as quick as a drummer's alternating singles (performers/drummer.js: the forearm's two directions
// are the two hands' strokes), so it is playable by construction.
//
// **Its accents.** The swing's two directions alternate stroke by stroke, bar after bar (in a bar of an odd number of
// strokes the downbeat falls on each direction in turn, as a shaker player's hand keeps going); its level follows the
// meter's strength, so the gesture swells toward the strong points.
import {DRUMMER} from './drummer.js';

export const SHAKER=Object.freeze({
  // The quickest reversal: a drummer's alternating singles (its prepare and recover over two).
  reversalSeconds:(DRUMMER.prepareSeconds+DRUMMER.recoverSeconds)/2,
  // A stroke's level: from accentShare under the player's own on the weakest pulses to accentShare over it on the
  // downbeat (ours).
  accentShare:.3,
  // An up stroke's level against a down stroke's at the same strength (ours, as interlockdrum_clodbot's shaker).
  upShare:.85,
});

const clamp=(value,low,high)=>Math.max(low,Math.min(high,value));

// The ticks between strokes: the fewest that divide the beat's ticks and are no shorter than a reversal. Null where
// even a whole beat is shorter than one.
export function strokeStride(secondsPerTick,beatTicks,{reversalSeconds}=SHAKER){
  for(let stride=1;stride<=beatTicks;stride++)if(beatTicks%stride===0&&stride*secondsPerTick>=reversalSeconds-1e-9)return stride;
  return null;
}

// A stroke's direction: down and up by turns, counted from the first stroke the hand made.
export const strokeDirection=count=>count%2===0?'down':'up';

// A stroke's level at a metric strength (0 to 1), in its direction, from the player's own (0 to 1).
export function strokeLevel(velocity,strength,direction,{accentShare,upShare}=SHAKER){
  return clamp(velocity*(1-accentShare+2*accentShare*clamp(strength,0,1))*(direction==='up'?upShare:1),.02,1);
}
