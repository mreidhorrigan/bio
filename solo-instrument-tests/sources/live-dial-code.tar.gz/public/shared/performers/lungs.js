// A wind player's lungs and the air each instrument takes from them (the owner, 1 November 2026: "have the live-dial
// perform note reattacks for winds similarly to strings (rather than one continuous stream of breath) which might require
// a concept of performer lung capacity"; "the breath-capacity module should be generalizable across the instruments once
// we know how much air each instrument takes across its breath settings"). Two parts, kept apart: the player's lungs
// (LUNGS, Lungs: a breath taken, spent at whatever rate it is spent, taken again), the same for every instrument; and
// each instrument's airflow (airflow: the litres a second it takes at a dynamic, a pitch and a breath setting), from
// what was measured of its players. The live dial's lungs are drained by the air its model lets in as the engine reports
// it (native/openwind/dial.mjs; native/openwind/src stream.rs Air), its players' flow shown beside it; the models' own
// across their breath settings, measured once and kept, still to come (MODELING_GAPS.md, "Breath"). A breath is to a wind player what the
// bow's length is to a string player (the owner, 1 November 2026: "air is somewhat analogous to the strings' bow
// length"): a supply spent at a rate -- the airflow as the bow's speed -- and renewed, a breath taken as the bow is
// turned, its intake the bow change's time (the strings' dial: native/strings-model/live.mjs, its stroke's length).
//
// The player, as wind players were measured:
//   - their vital capacity: 4.21 L (sd 1.11) in 32 professional wind players, 23 men and 9 women, 16 brass and 16
//     woodwind (E. Bouros, V. Protogerou, O. Castana & G. Vasilopoulos 2018, "Respiratory Function in Wind Instrument
//     Players", Materia Socio-Medica 30(3) 204-208, doi:10.5455/msm.2018.30.204-208);
//   - the share of it a breath spends: professional flautists played over 72 to 83 % of their vital capacity (I.
//     Cossette, P. Sliwinski & P. T. Macklem 2000, "Respiratory parameters during professional flute playing",
//     Respiration Physiology 121(1) 33-44, doi:10.1016/s0034-5687(00)00111-0), the middle of it taken; on some
//     instruments nearly the whole of it (A. Bouhuys 1964, "Lung volumes and breathing patterns in wind-instrument
//     players", Journal of Applied Physiology 19(5) 967-975, doi:10.1152/jappl.1964.19.5.967, its abstract); professional
//     reed players began their breath groups at 55 to 87 % of it and ended them at 14 to 52 %, some 73 % spent at the most
//     (L. Fuks & J. Sundberg 1998, "Respiratory inductive plethysmography measurements on professional reed woodwind
//     instrument players", KTH TMH-QPSR 39(1-2) 19-42, no DOI, as Fuks's thesis summarizes it:
//     speech.kth.se/music/publications/leofuks/thesis/summaries.html, read 1 November 2026);
//   - a breath taken in: fast and deep (Bouhuys 1964), its fastest some 300 ms (Fuks & Sundberg 1998); by default in a
//     singer's full breath's time, 0.7 s (voice.js VOICE.breaths: Salomoni, van den Hoorn & Hodges 2016, measured),
//     borrowed until wind players' own is measured.
// The longest a breath is held, the limit on the oboe rather than its air (Bouhuys 1964), is not measured here: none set.
import {VOICE} from './voice.js';

export const LUNGS=Object.freeze({
  capacity:Object.freeze({litres:4.21,sd:1.11,evidence:'measured'}),
  spent:Object.freeze({share:(.72+.83)/2,evidence:'measured'}),
  inhale:Object.freeze({seconds:VOICE.breaths.full.seconds,evidence:'borrowed: a singer\'s full breath'}),
});
// (A breath as deep as players were measured taking one, L.)
export const BREATH_LITRES=+(LUNGS.capacity.litres*LUNGS.spent.share).toFixed(2);

// A player's lungs: a breath of `litres`, spent at the rate given it, taken in again over `inhale` s. -> air (L left),
// taking (whether a breath is being taken).
export class Lungs{
  constructor({litres=BREATH_LITRES,inhale=LUNGS.inhale.seconds}={}){this.litres=litres;this.inhale=inhale;this.air=litres;this.taking=false}
  // How long the air left lasts at `flow` L/s (s).
  secondsLeft(flow){return flow>0?Math.max(0,this.air)/flow:Infinity}
  // `seconds` at `flow` L/s spent. -> whether it is spent.
  spend(flow,seconds){if(flow>0)this.air-=flow*seconds;return this.air<=0}
  // A breath begun or ended: taken in, the lungs full again.
  breathe(){this.taking=true}
  filled(){this.taking=false;this.air=this.litres}
  // Another breath's depth or time, the air left no more than it.
  set({litres=this.litres,inhale=this.inhale}={}){this.litres=litres;this.inhale=inhale;this.air=Math.min(this.air,litres)}
}

// What players were measured spending, L/s, at pp and at ff, each on a note (sounding, MIDI), its mouth pressure beside
// it (mmHg): professional players (four to 58 years' playing), each flow the vital capacity less what was left after
// playing the note some 2 to 10 s, over the time (A. Bouhuys 1965, "Sound-power production in wind instruments", The
// Journal of the Acoustical Society of America 37(3) 453-456, doi:10.1121/1.1909350, Fig. 1; read off the figure at
// 600 dpi, to some 5 %). "Air-flow rates vary little with frequency but increase markedly with sound output in the
// bassoon, in flutes, and in brass."
export const PLAYERS_AIRFLOW=Object.freeze({
  oboe:[{midi:58,pp:[.061,23],ff:[.102,33]},{midi:81,pp:[.047,55],ff:[.058,80]}],
  'english-horn':[{midi:57,pp:[.090,15.4],ff:[.097,22.7]},{midi:81,pp:[.080,18.5],ff:[.074,45.7]}],
  bassoon:[{midi:34,pp:[.15,44],ff:[.81,38.5]}],
  flute:[{midi:60,pp:[.13,5],ff:[.56,10.7]},{midi:93,pp:[.10,21],ff:[.62,29]}],
  trumpet:[{midi:81,pp:[.15,33],ff:[.49,110]}],
  tuba:[{midi:33,pp:[.23,2.4],ff:[1.57,11.6]},{midi:57,pp:[.14,12.4],ff:[1.72,74]}],
});
// The instruments no one measured there, each borrowing from those of its kind that were: the flutes the flute's, the
// contrabassoon its bassoon's, the single reeds the middle of the double reeds', the horn and trombone the middle of the
// trumpet's and tuba's -- each borrowed, to be replaced by its own players' measured flows (SOURCES_TO_FETCH.md).
export const BORROWED_AIRFLOW=Object.freeze({
  piccolo:['flute'],'alto-flute':['flute'],contrabassoon:['bassoon'],
  clarinet:['oboe','english-horn','bassoon'],'e-flat-clarinet':['oboe','english-horn','bassoon'],'bass-clarinet':['oboe','english-horn','bassoon'],
  'soprano-saxophone':['oboe','english-horn','bassoon'],'alto-saxophone':['oboe','english-horn','bassoon'],
  'tenor-saxophone':['oboe','english-horn','bassoon'],'baritone-saxophone':['oboe','english-horn','bassoon'],
  horn:['trumpet','tuba'],trombone:['trumpet','tuba'],
});
const ALIASES={alto:'alto-flute'};
// (The marks from softest to loudest; pp and ff where they were measured.)
const MARKS=['ppp','pp','p','mp','mf','f','ff','fff'],PP=MARKS.indexOf('pp'),FF=MARKS.indexOf('ff');

// A measured instrument's flow at a mark and a pitch: along the marks between pp and ff geometrically, on beyond them so
// (ppp and fff extrapolated); between two measured notes geometrically by pitch, beyond them the nearer one's -- flow
// varying little with pitch (Bouhuys 1965).
function measuredFlow(notes,dynamic,midi){
  const k=MARKS.indexOf(dynamic);
  if(k<0)throw new RangeError(`a dynamic from ${MARKS[0]} to ${MARKS.at(-1)}`);
  const at=n=>n.pp[0]*(n.ff[0]/n.pp[0])**((k-PP)/(FF-PP));
  if(notes.length===1||midi<=notes[0].midi)return at(notes[0]);
  if(midi>=notes.at(-1).midi)return at(notes.at(-1));
  const j=notes.findIndex(n=>n.midi>=midi),a=notes[j-1],b=notes[j],x=(midi-a.midi)/(b.midi-a.midi);
  return at(a)**(1-x)*at(b)**x;
}
// An instrument's airflow: of({dynamic, midi, share}) the litres a second it takes at a mark and a pitch, its breath
// setting `share` of what its players blow there (taken as in proportion: ours); `source` what that rests on.
export function airflow(model){
  const id=ALIASES[model]??model;
  if(PLAYERS_AIRFLOW[id])return {source:{evidence:'measured',from:[id]},
    of:({dynamic,midi,share=1})=>share*measuredFlow(PLAYERS_AIRFLOW[id],dynamic,midi)};
  const from=BORROWED_AIRFLOW[id];
  if(!from)throw new RangeError(`no airflow for ${model}`);
  return {source:{evidence:'borrowed',from:[...from]},
    of:({dynamic,midi,share=1})=>share*Math.exp(from.reduce((s,m)=>s+Math.log(measuredFlow(PLAYERS_AIRFLOW[m],dynamic,midi)),0)/from.length)};
}
