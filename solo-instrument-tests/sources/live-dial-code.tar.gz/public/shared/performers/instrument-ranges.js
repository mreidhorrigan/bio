// Instrument compasses, in sounding MIDI semitones (C4 = 60), independent of sample-bank coverage.
// A documented compass describes this configuration and technique, not every instrument with the same name.
// Upper wind/string limits depend on the player. Registers are authored preferences, never physical evidence.
// Retuning and explicit simulation departures belong to the configured instrument; these reference compasses do
// not quantize microtones. A null range means configuration/performer dependent or unpitched, never unlimited.
import {assertion} from './evidence.js';
import {GIVEN_BOWED,bySize} from './bowed-instruments.js';
import {constant,equationOf,pathsOf,value} from '../../../registry/registry.js';

const freeze=value=>{
  if(value&&typeof value==='object'){for(const child of Object.values(value))freeze(child);Object.freeze(value)}
  return value;
};
const academy=(family,name)=>`https://www.vsl.co.at/academy/${family}/${name}`;
const saxophones='https://www.phys.unsw.edu.au/jw/reprints/ChenetalAA.pdf';
const timpaniManual='https://usa.yamaha.com/files/download/other_assets/6/797756/TP8300R_TP7300R_TP6300R_TP4300R_owners_manual_EN_B0.pdf';
const record=(name,range,writtenToSounding,source,extra={})=>({
  name,range,writtenToSounding,writtenRange:range?.map(p=>p-writtenToSounding)??null,
  basis:source?'documented-compass':'declared-configuration',sources:source?[source]:[],...extra,
});

// (A pitch set's envelope, and a voice part's record from its measured extremes in Hz.)
const pitchRange=pitches=>[Math.min(...pitches),Math.max(...pitches)];
const hzMidi=equationOf('hz-midi'),midiOf=hz=>+hzMidi({hz,a4:constant('a4')}).toFixed(2);
const voicePart=(name,hz,register)=>record(name,hz.map(midiOf),0,'https://doi.org/10.1590/S1516-80342007000100004',
  {basis:'measured',measuredExtremesHz:hz,register,note:'Measured extremes are choristers\' phonetogram means; the register is authored.'});

// (A bowed instrument given as data (bowed-instruments.js): its compass from its lowest open string to its highest's
// reach, its register and harmonics' ceiling as far from its ends as the bowed instruments' compasses here put theirs --
// each read between them by size (bySize), derived, not documented.)
const BOWED_COMPASS=Object.freeze({violin:'violin-standard',viola:'viola-standard',cello:'cello-standard',contrabass:'contrabass-four-string'});
// (A bowed instrument of the registry's tree (registry/objects/bowed.json): its compass and harmonics' ceiling as VSL
// Academy's page gives them, its tuning, its register ours, its notation an octave over it where it is written so.)
const bowedRecord=(name,label,page)=>
  record(label,value(name,'compass'),pathsOf(name).includes('writtenToSounding')?value(name,'writtenToSounding'):0,academy('strings',page),
    {strings:value(name,'tuning'),register:value(name,'register'),harmonicCeiling:value(name,'harmonicCeiling')});
export const INSTRUMENT_RANGES=freeze(withGivenBowed({
  'flute-b-foot':record('Concert flute in C, B foot',[59,98],0,academy('woodwinds','concert-flute'),
    {register:[60,96],extension:{high:[98,101]},configuration:{foot:'B'}}),
  'flute-c-foot':record('Concert flute in C, C foot',[60,98],0,academy('woodwinds','concert-flute'),
    {register:[60,96],extension:{high:[98,101]},configuration:{foot:'C'}}),
  'piccolo-c':record('Piccolo in C',[74,108],12,academy('woodwinds','piccolo'),{register:[74,108]}),
  'alto-flute-g':record('Alto flute in G',[55,91],-5,null,
    {register:[55,91],note:'Declared three-octave model, written C4..C7; not a universal upper limit.'}),
  'oboe-conservatory':record('Oboe with low B-flat',[58,93],0,academy('woodwinds','oboe'),
    {register:[60,91],ordinaryRange:[58,91],extension:{high:[91,93]}}),
  'clarinet-b-flat':record('Clarinet in B-flat, written low E',[50,94],-2,academy('woodwinds','clarinet'),
    {register:[52,89],orchestralRange:[50,91]}),
  'clarinet-a':record('Clarinet in A, written low E',[49,93],-3,academy('woodwinds','clarinet'),
    {register:[51,88],orchestralRange:[49,90]}),
  'clarinet-e-flat':record('Clarinet in E-flat, written low E',[55,94],3,academy('woodwinds','e-flat-clarinet'),{register:[57,89]}),
  'bass-clarinet-b-flat':record('Bass clarinet in B-flat, to written E3',[38,77],-14,academy('woodwinds','bass-clarinet'),
    {register:[40,72],note:'Its keys below written E3 (to low E-flat or C on many instruments) are not in this configuration.'}),
  'bassoon-standard':record('Bassoon with low B-flat',[34,77],0,academy('woodwinds','bassoon'),
    {register:[36,72],ordinaryRange:[34,75],extension:{high:[75,77]}}),
  'english-horn-f':record('English horn in F, with low B-flat',[51,84],-7,academy('woodwinds','english-horn'),
    {register:[53,79],ordinaryRange:[52,81],note:'Written B-flat 3 (sounding E-flat 3) on an instrument with the low B-flat key; written B3 without.'}),
  // (Written an octave over its sound, as VSL Academy's page has it, read 31 October 2026: "the sound is an octave lower
  // than written" -- its players' charts are written so: The Woodwind Fingering Guide's.)
  'contrabassoon-standard':record('Contrabassoon with low B-flat',[22,58],-12,academy('woodwinds','contrabassoon'),{register:[24,53]}),
  // (The saxophones: written B-flat 3 to F6, F-sharp 6 on some -- "This range finishes (depending on the model) at written
  // F6 or F#6" -- their altissimo above it the player's, with the vocal tract (Chen, Smith & Wolfe 2009).)
  'soprano-saxophone-b-flat':record('Soprano saxophone in B-flat',[56,87],-2,saxophones,{register:[58,82],extension:{high:[87,88]}}),
  'alto-saxophone-e-flat':record('Alto saxophone in E-flat',[49,80],-9,saxophones,{register:[51,75],extension:{high:[80,81]}}),
  'tenor-saxophone-b-flat':record('Tenor saxophone in B-flat',[44,75],-14,saxophones,{register:[46,70],extension:{high:[75,76]}}),
  'baritone-saxophone-e-flat':record('Baritone saxophone in E-flat, to written B-flat 3',[37,68],-21,saxophones,{register:[39,63],extension:{high:[68,69]}}),
  'horn-f':record('Horn in F',[35,77],-7,academy('brass','horn-f'),{register:[43,74]}),
  'trumpet-c':record('Trumpet in C',[54,89],0,academy('brass','trumpet-c'),
    {register:[57,82],ordinaryRange:[54,84],extension:{high:[84,89]}}),
  'tenor-trombone':record('Tenor trombone, without F attachment',[40,77],0,academy('brass','tenor-trombone'),
    {register:[42,70],extension:{pedal:[28,34]},note:'Pedal E1..B-flat1 is separate: B1..E-flat2 is not filled in.'}),
  'bass-tuba-f':record('Bass tuba in F',[26,67],0,academy('brass','bass-tuba'),
    {register:[30,58],note:'Orchestral concert-pitch notation; lower pedals require a specified instrument/player.'}),
  'contrabass-tuba-b-flat':record('Contrabass tuba in B-flat',[21,59],0,academy('brass','contrabass-tuba'),
    {register:[26,55],note:'Orchestral concert-pitch notation, not brass-band transposition.'}),
  'violin-standard':bowedRecord('violin','Violin, stopped notes','violin'),
  'viola-standard':bowedRecord('viola','Viola, stopped notes','viola'),
  'cello-standard':bowedRecord('cello','Cello, stopped notes','cello'),
  'contrabass-four-string':bowedRecord('contrabass','Contrabass, four strings, stopped notes','double-bass'),
  'contrabass-five-string':bowedRecord('contrabass-five-string','Contrabass, five strings, stopped notes','double-bass'),
  'piano-88':record('Piano, 88 keys',[21,108],0,null,{keys:88,note:'Declared A0..C8 keyboard; retuned manuals derive their sounding compass from the actual key map.'}),
  'harpsichord-five-octave':record('Harpsichord, five-octave 8-foot manual',[29,89],0,null,
    {keys:61,note:'Declared F1..F6 manual; historical compasses and 4-foot/16-foot stops need their own configuration.'}),
  'guitar-six-string-20-fret':record('Guitar, six strings and 20 frets',[40,84],-12,null,
    {strings:[40,45,50,55,59,64],frets:20,note:'Derived from this tuning and fret count. Other tunings, capos, frets and harmonics are separate configurations.'}),
  'harp-concert-47':record('Double-action concert harp, 47 strings',[23,104],0,academy('strings','harp'),
    {lowest:{letter:'C',octave:1},strings:47,naturalRange:[24,103],note:'C-flat1..G-sharp7 envelope. Actual pedal settings and string tuning determine availability.'}),
  'marimba-four-third':record('Marimba, 4 1/3 octaves',[45,96],0,academy('percussion','marimba')),
  'marimba-five':record('Marimba, 5 octaves',[36,96],0,academy('percussion','marimba')),
  'vibraphone-three':record('Vibraphone, 3 octaves',[53,89],0,academy('percussion','vibraphone')),
  'vibraphone-three-half':record('Vibraphone, 3 1/2 octaves',[48,89],0,academy('percussion','vibraphone')),
  'xylophone-three-half':record('Xylophone, 3 1/2 octaves',[65,108],12,academy('percussion','xylophone')),
  'xylophone-four':record('Xylophone, 4 octaves',[60,108],12,academy('percussion','xylophone')),
  'glockenspiel-g-c':record('Glockenspiel, G5..C8',[79,108],24,academy('percussion','glockenspiel')),
  'glockenspiel-three':record('Glockenspiel, C5..C8',[72,108],24,academy('percussion','glockenspiel')),
  'timpani-yamaha-32':record('Yamaha pedal timpani, 32 inches',[38,46],0,timpaniManual,{page:22}),
  'timpani-yamaha-29':record('Yamaha pedal timpani, 29 inches',[41,49],0,timpaniManual,{page:22}),
  'timpani-yamaha-26':record('Yamaha pedal timpani, 26 inches',[45,53],0,timpaniManual,{page:22}),
  'timpani-yamaha-23':record('Yamaha pedal timpani, 23 inches',[48,56],0,timpaniManual,{page:22}),
  'timpani-yamaha-20':record('Yamaha pedal timpani, 20 inches',[52,60],0,timpaniManual,{page:22}),
  'timpani-yamaha-four':record('Yamaha pedal timpani, the common set of four (32, 29, 26 and 23 inches)',[38,56],0,timpaniManual,
    {page:22,drums:['timpani-yamaha-32','timpani-yamaha-29','timpani-yamaha-26','timpani-yamaha-23'],piccolo:'timpani-yamaha-20',
      note:'The envelope of its drums; each drum\'s own range is its record\'s.'}),
  'accordion-41-key':record('Piano accordion, 41 keys, middle reed',[53,93],0,
    'https://www.hohner.de/en/instruments/accordions/chromatic/bravo/bravo-iii-120',
    {note:'Treble keyboard compass. Its Stradella bass side has its own pitch maps (stradella, authored): each chord row\'s reeds within chordOctave, each bass button within bassOctave and the octave over it (bassOctaves).',
      stradella:{chordOctave:[51,62],bassOctave:[40,51],bassOctaves:[0,12]}}),
  // (Its pitches are its buttons': push the G chord's notes, pull the scale's others: the report's §11.5 fixture.)
  'accordion-bisonoric-g':record('One-row diatonic button accordion in G (bisonoric)',
    pitchRange([[55,57],[59,60],[62,64],[67,66],[71,69],[74,72],[79,76],[83,78],[86,81],[91,84]].flat()),0,null,
    {buttons:[[55,57],[59,60],[62,64],[67,66],[71,69],[74,72],[79,76],[83,78],[86,81],[91,84]].map(([push,pull])=>({push,pull})),
      note:'An authored layout (the report\'s §11.5 fixture), its range its buttons\' envelope; another button accordion is a configuration of its own.'}),
  'steelpan-tenor-29':record('Tenor steelpan, 29 chromatic fields',[60,88],0,null,
    {note:'Declared C4..E6 set, not a limit for all steelpans. A fixed or retuned field list controls actual pitches.'}),
  'kalimba-17-c':record('Kalimba, 17 diatonic tines in C',[60,88],0,null,
    {count:17,base:60,scale:[0,2,4,5,7,9,11],note:'Fixed model only. The default band-tuned instrument derives its range from its actual tines.'}),
  voice:record('Singing voice',null,0,null,{basis:'performer-specific',note:'Use the individual singer configuration. Choral registers and population means are not universal physiological limits.'}),
  // A choir's parts: each range what choristers of that voice measurably reach -- the means of the lowest and highest
  // notes in their phonetograms (Camargo, Barbosa & Teles 2007, "Características da fonetografia em coristas de
  // diferentes classificações vocais", Revista da Sociedade Brasileira de Fonoaudiologia 12(1),
  // doi:10.1590/S1516-80342007000100004; the alto's are the mezzo-sopranos' there) -- and each register the part's own,
  // chosen inside it as choral writing sets it (authored).
  'voice-soprano':voicePart('Choral soprano',[130,1084],[60,79]),
  'voice-alto':voicePart('Choral alto',[124,878],[55,74]),
  'voice-tenor':voicePart('Choral tenor',[85,709],[48,67]),
  'voice-bass':voicePart('Choral bass',[75,513],[40,60]),
  'voice-countertenor':record('Countertenor',null,0,null,{basis:'performer-specific',register:[52,72],
    note:'An authored usual register (E3..C5), used to choose formants between a tenor\'s and an alto\'s; no measured compass here.'}),
  // A singer's breath model's voices: the range its registers are split in thirds over (voice.js singer; authored).
  'voice-high':record('High voice (sopranos, altos), for the breath model',null,0,null,{basis:'performer-specific',register:[53,81]}),
  'voice-low':record('Low voice (tenors, basses), for the breath model',null,0,null,{basis:'performer-specific',register:[40,67]}),
  // The dùndún: its pitch at rest the measured low tone (61.4 Hz), its squeeze's reach the measured high tone (17.9
  // semitones over the low), the mid tone 12.2 over it, on three drummers (Akinbo, S. 2019, "Representation of Yorùbá
  // tones by a talking drum: an acoustic analysis", Linguistique et langues africaines 5, doi:10.4000/lla.347).
  'talkingdrum-dundun':record('Talking drum (dùndún), measured',[34.91,52.81],0,'https://doi.org/10.4000/lla.347',
    {basis:'measured',relaxed:34.91,span:17.9,tones:{L:0,M:12.2,H:17.9},
      note:'Three drummers\' measured tones. Another drum is a configuration of its own (its relaxed pitch and squeeze span).'}),
  talkingdrum:record('Talking drum',null,0,null,{basis:'configuration-dependent',note:'Use the configured relaxed pitch and squeeze span; the measured reference drum is not every talking drum.'}),
  gong:record('Gong set',null,0,null,{basis:'configuration-dependent',note:'Use each selected gong recording or model pitch, where definite; a tam-tam may have no definite pitch.'}),
  percussion:record('Kit, battery, conga and shaker',null,0,null,{basis:'unpitched',note:'Drum-map numbers are identities, not a chromatic sounding compass. Retunable drums use their configured acoustic/model limits.'}),
  electronic:record('Electronic instrument',null,0,null,{basis:'configuration-dependent',note:'Use the synth or sample-map configuration; MIDI address space is not a physical instrument range.'}),
}));
function withGivenBowed(ranges){
  const of=k=>Object.fromEntries(Object.entries(BOWED_COMPASS).map(([name,id])=>[name,k(ranges[id])]));
  const reach=of(r=>r.range[1]-r.strings.at(-1)),low=of(r=>r.register[0]-r.range[0]),high=of(r=>r.range[1]-r.register[1]),
    ceiling=of(r=>r.harmonicCeiling-r.range[1]);
  return {...ranges,...Object.fromEntries(GIVEN_BOWED.map(i=>{
    const top=i.opens.at(-1)+Math.round(bySize(reach,i.name,undefined,{linear:true})),range=[i.opens[0],top];
    return [i.name,record(`${i.name}, ${i.opens.length} strings, stopped notes`,range,0,null,{basis:'derived',strings:[...i.opens],
      register:[range[0]+Math.round(bySize(low,i.name,undefined,{linear:true})),range[1]-Math.round(bySize(high,i.name,undefined,{linear:true}))],
      harmonicCeiling:range[1]+Math.round(bySize(ceiling,i.name,undefined,{linear:true})),
      note:`An instrument given as data (registry/objects/bowed.json${i.fictional?', fictional':''}): its compass, register and harmonics' ceiling read between the bowed instruments' by size.`})];
  }))};
}


export const DEFAULT_INSTRUMENT_RANGES=freeze({
  flute:'flute-b-foot',piccolo:'piccolo-c',alto:'alto-flute-g','alto-flute':'alto-flute-g',oboe:'oboe-conservatory',
  clarinet:'clarinet-b-flat',bassoon:'bassoon-standard',
  'e-flat-clarinet':'clarinet-e-flat','bass-clarinet':'bass-clarinet-b-flat','english-horn':'english-horn-f',contrabassoon:'contrabassoon-standard','soprano-saxophone':'soprano-saxophone-b-flat','alto-saxophone':'alto-saxophone-e-flat','tenor-saxophone':'tenor-saxophone-b-flat','baritone-saxophone':'baritone-saxophone-e-flat',horn:'horn-f',trumpet:'trumpet-c',
  trombone:'tenor-trombone',tuba:'bass-tuba-f',violin:'violin-standard',viola:'viola-standard',
  cello:'cello-standard',contrabass:'contrabass-four-string',piano:'piano-88',harpsichord:'harpsichord-five-octave',
  guitar:'guitar-six-string-20-fret',harp:'harp-concert-47',marimba:'marimba-four-third',
  vibraphone:'vibraphone-three',xylophone:'xylophone-three-half',glockenspiel:'glockenspiel-g-c',
  accordion:'accordion-41-key',steelpan:'steelpan-tenor-29',kalimba:'kalimba-17-c',
  singer:'voice',talkingdrum:'talkingdrum-dundun',timpani:'timpani-yamaha-four',gong:'gong',kit:'percussion',battery:'percussion',
  conga:'percussion',shaker:'percussion',synth:'electronic',
});
// An instrument's names before it was renamed, read as it only where data made before names it so -- nothing new is
// written under them: the contrabass was "bass" and "double-bass" until 17 October 2026 (the owner: "call the
// double-bass contrabass, for disambiguation"), and the string sample banks downloaded before then name its
// recordings "bass" (vsco-bass, iowa-still-bass), as old recipes name its player.
export const NAMED_BEFORE=freeze({bass:'contrabass','double-bass':'contrabass'});
// The instrument a name given before means (the name itself where it was never another's).
export const instrumentNamed=name=>NAMED_BEFORE[name]??name;
// The names an instrument had before, for data made then.
export const namesBefore=name=>Object.keys(NAMED_BEFORE).filter(old=>NAMED_BEFORE[old]===name);

export function instrumentRange(id){
  const found=INSTRUMENT_RANGES[DEFAULT_INSTRUMENT_RANGES[id]??id];
  if(!found)throw new RangeError(`No instrument range configuration ${id}`);
  return found;
}
// Descriptive evidence, not a measured or mathematically certified human capability.
export function rangeEvidence(id){
  const config=DEFAULT_INSTRUMENT_RANGES[id]??id,entry=instrumentRange(id);
  return assertion({value:entry.range,unit:'midi',status:entry.range?'authored':'unknown',
    scope:{instrument:config,reference:'sounding'},source:{basis:entry.basis,urls:entry.sources,reviewed:'2026-10-07'}});
}
// A configured set's actual envelope. This does not assert that every pitch between discrete keys/tines exists.
export function pitchEnvelope(pitches){
  if(!Array.isArray(pitches)||!pitches.length||!pitches.every(Number.isFinite))throw new RangeError('A pitch set is a nonempty list of finite sounding pitches');
  return Object.freeze([Math.min(...pitches),Math.max(...pitches)]);
}
// Intersect an authored register with the instrument/configuration compass before making musical candidates.
// (A register's ends, its low and its high.)
const ENDS=['low','high'];
export function boundedRegister(register,range){
  for(const pair of [register,range])if(!Array.isArray(pair)||pair.length!==ENDS.length||!pair.every(Number.isFinite)||pair[0]>pair[1])throw new RangeError('A register is [low, high]');
  const low=Math.max(register[0],range[0]),high=Math.min(register[1],range[1]);
  return low<=high?[low,high]:null;
}
