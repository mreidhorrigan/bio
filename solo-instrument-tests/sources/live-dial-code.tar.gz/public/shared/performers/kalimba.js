// A kalimba player's thumbs over tines (the family atlas's F34, lamellophones and plucked idiophones), planned through
// the performer contract's one solver (contract.js searchGroups), as the mallets, the guitar and the piano are. Taken by
// 2a from c2's "Percussion beyond the kit", 29 September (SESSIONS.md 07:30). The mbira's tunings are measured one
// instrument at a time and wait on the cultural profiles' acquisition, never guessed, so only the kalimba is here.
//
// **Tines laid out from the middle.** Its tines lie side by side, the lowest in the middle and each next one on the other
// side of it, alternating outward: its scale's steps alternate thumbs, and a thumb's neighbours on its own side are two
// steps apart (a third, on a diatonic kalimba). By default the tines take the band's scale, one to a step up from the
// lowest, as a player retunes a kalimba by sliding its tines (`tines: 'band'`); a fixed kalimba (`tines: 'fixed'`,
// seventeen in C major from C4, or a list of pitches) has no tine for a pitch between its tines, which is refused, never
// rounded.
//
// **Two thumbs, a side each.** The left thumb plucks the tines left of the middle, the right thumb those right of it,
// either thumb the middle one. A thumb plucks one tine, or two neighbours on its own side in one stroke, and plucks again
// once its stroke has recovered (KALIMBA.strokeSeconds); it moves along its tines at KALIMBA.thumbMmPerSecond.
//
// **What is not modelled yet**, and says so: the index fingers some players pluck with from behind, a thumb reaching
// across the middle, damping a tine as a motion of its own (a tine rings as long as the bot holds it), buzzers, and the
// resonator's hole.
import {action,checkReservations,profile,searchGroups,STATUS,witness} from './contract.js';
import {instrumentRange} from './instrument-ranges.js';

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const KALIMBA=Object.freeze({
  // A fixed kalimba's tines: seventeen, C major from C4 (the common instrument: the instrument registry's,
  // instrument-ranges.js).
  count:instrumentRange('kalimba').count,fixed:Object.freeze({base:instrumentRange('kalimba').base,scale:instrumentRange('kalimba').scale}),
  // A kalimba retuned for the piece: its lowest tine the band's scale's first pitch at or above the fixed one's lowest.
  bandBase:instrumentRange('kalimba').base,
  // The distance between neighbouring tines (mm; authored).
  tineMm:9,
  // A thumb's stroke (s: about eight plucks a second from one thumb) and its travel along its tines (mm a second;
  // authored).
  strokeSeconds:1/8,thumbMmPerSecond:600,
  // How long a tine rings at the bottom and at the top of its range (s; authored).
  ringSeconds:Object.freeze([3,1]),
  // A tine sounds a pitch within this (semitones); notes starting within `together` of each other are one group (s).
  tolerance:.05,together:.005,
  // Costs, authored: each millimetre a thumb travels.
  cost:Object.freeze({travelPerMm:.001}),
  maxStates:4096,
});
const modulo=(x,m)=>((x%m)+m)%m;

// ---- The instrument --------------------------------------------------------------------------------------------------
// Its tines' pitches, low to high: a list given; a fixed kalimba's; or the band's scale (its classes as semitones,
// fractional where microtonal), a tine to each step up from the scale's first pitch at or above bandBase.
export function kalimbaTines({tines='band',scale=null,count=KALIMBA.count,choices=KALIMBA}={}){
  if(Array.isArray(tines)){const list=[...tines].map(Number).filter(Number.isFinite).sort((a,b)=>a-b);if(!list.length)throw new RangeError('a kalimba has at least one tine');return Object.freeze(list)}
  if(tines!=='band'&&tines!=='fixed')throw new RangeError('a kalimba\'s tines are band, fixed or a list of pitches');
  const {base,scale:steps}=tines==='fixed'?choices.fixed:{base:choices.bandBase,scale};
  const classes=[...new Set((steps??[]).map(Number).filter(Number.isFinite).map(pc=>modulo(pc,12)))].sort((a,b)=>a-b);
  if(!classes.length)throw new RangeError('a kalimba retuned for the piece needs the band\'s scale');
  const out=[];
  for(let octave=Math.floor(base/12)-1;out.length<count;octave++)for(const pc of classes){const pitch=12*octave+pc;if(pitch>=base-1e-9&&out.length<count)out.push(pitch)}
  return Object.freeze(out);
}
// A tine's place on the instrument: 0 the middle (its lowest), then right and left of it by turns, outward. -> an
// integer, negative to the left.
export const tinePlace=index=>index===0?0:index%2?(index+1)/2:-index/2;
// The thumbs that reach a place: the left thumb left of the middle, the right thumb right of it, either the middle.
export const thumbsFor=place=>place<0?['LT']:place>0?['RT']:['LT','RT'];
// The tine that sounds a pitch (its index, low to high), within the tolerance, or null (refused: no tine sounds it).
export function tineFor(tines,pitch,{choices=KALIMBA}={}){
  let best=-1;for(let k=0;k<tines.length;k++)if(best<0||Math.abs(tines[k]-pitch)<Math.abs(tines[best]-pitch))best=k;
  return best>=0&&Math.abs(tines[best]-pitch)<=choices.tolerance?best:null;
}
// How long a tine rings (s), by where it lies in the range.
export const tineRing=(tines,index,{choices=KALIMBA}={})=>{const [bottom,top]=choices.ringSeconds,t=tines.length>1?index/(tines.length-1):0;return bottom+(top-bottom)*t};

// ---- The player ------------------------------------------------------------------------------------------------------
// A kalimba player's profile: two hands (LH, RH), a thumb each (LT, RT). `unavailable` names any of them.
export function kalimbist({id='kalimbist',performer='kalimbist',unavailable=[],evidence='authored'}={}){
  const state=name=>unavailable.includes(name)?'unavailable':'available';
  const resources=[{id:'LH',kind:'body',availability:state('LH'),evidence},{id:'RH',kind:'body',availability:state('RH'),evidence},
    {id:'LT',kind:'effector',parents:['LH'],availability:unavailable.includes('LH')?'unavailable':state('LT'),evidence},
    {id:'RT',kind:'effector',parents:['RH'],availability:unavailable.includes('RH')?'unavailable':state('RT'),evidence}];
  return profile({id,performer,resources});
}
const thumbsOf=who=>['LT','RT'].filter(thumb=>who.resources.get(thumb)?.availability==='available');
// A group's plucks: every way its tines go to the thumbs, each thumb one tine or two neighbours on its own side (the
// middle either thumb's). -> [{thumbs: {LT: [index...], RT: [index...]}, x: {LT, RT} (mm from the middle)}].
export function plucks(indices,who=kalimbist(),{choices=KALIMBA}={}){
  const available=thumbsOf(who),options=indices.map(index=>thumbsFor(tinePlace(index)).filter(thumb=>available.includes(thumb))),out=[];
  const assign=(k,current)=>{
    if(k===indices.length){
      const x={};
      for(const thumb of ['LT','RT']){
        const list=current[thumb];if(!list.length){x[thumb]=null;continue}
        if(list.length>2||list.length===2&&Math.abs(tinePlace(list[0])-tinePlace(list[1]))!==1)return;
        x[thumb]=list.reduce((sum,index)=>sum+tinePlace(index)*choices.tineMm,0)/list.length;
      }
      out.push({thumbs:{LT:[...current.LT],RT:[...current.RT]},x});return;
    }
    for(const thumb of options[k]){current[thumb].push(indices[k]);assign(k+1,current);current[thumb].pop()}
  };
  assign(0,{LT:[],RT:[]});
  return out;
}

// ---- Passages --------------------------------------------------------------------------------------------------------
// Plan a passage [{pitch, start, end}] on a kalimba's tines: which thumb plucks each note, a thumb's two neighbours in one
// stroke, never faster than its stroke recovers or its thumb travels. -> {status, path?, cost?, witness?, reason?};
// refused (unknown) where a pitch has no tine.
export function planKalimba(input,{tines=kalimbaTines({tines:'fixed'}),who=kalimbist(),choices=KALIMBA}={}){
  if(!input.length)return {status:STATUS.witness,path:[],cost:0};
  const notes=input.map((note,index)=>({...note,id:note.id??`n${index}`}));
  for(const note of notes){
    if(!(note.end>note.start))throw new RangeError(`note ${note.id}: a positive duration`);
    const tine=tineFor(tines,note.pitch,{choices});
    if(tine===null)return {status:STATUS.unknown,reason:`pitch ${note.pitch} has no tine on this kalimba (a pitch between its tines is not rounded)`};
    note.tine=tine;
  }
  const groups=[];
  for(const note of [...notes].sort((a,b)=>a.start-b.start||a.tine-b.tine)){const last=groups.at(-1);if(last&&note.start-last.at<=choices.together)last.notes.push(note);else groups.push({at:note.start,notes:[note]})}
  // A thumb's state: where it is (mm from the middle), when it last plucked, when its stroke has recovered.
  const stateKey=state=>JSON.stringify([state.LT?.x??null,state.RT?.x??null,state.LT?.free??null,state.RT?.free??null]);
  const expand=(group,state)=>{
    const moves=[];
    for(const pluck of plucks(group.notes.map(note=>note.tine),who,{choices})){
      let ok=true,cost=0;const next={...state},strokes=[];
      for(const thumb of ['LT','RT']){
        const list=pluck.thumbs[thumb];if(!list.length)continue;
        const before=state[thumb],travel=before?Math.abs(pluck.x[thumb]-before.x):0;
        // The thumb's stroke recovered, and the thumb there in time.
        if(before&&group.at<before.free-1e-9){ok=false;break}
        if(before&&travel>choices.thumbMmPerSecond*Math.max(0,group.at-before.at)+1e-9){ok=false;break}
        cost+=travel*choices.cost.travelPerMm;
        strokes.push({thumb,notes:group.notes.filter(note=>list.includes(note.tine)).map(note=>({note:note.id,pitch:note.pitch,tine:note.tine,place:tinePlace(note.tine)}))});
        next[thumb]={x:pluck.x[thumb],at:group.at,free:group.at+choices.strokeSeconds};
      }
      if(ok)moves.push({status:'supported',cost,state:next,step:{at:group.at,strokes}});
    }
    return moves;
  };
  const found=searchGroups(groups,{initial:{LT:null,RT:null},expand,stateKey,maxStates:choices.maxStates});
  if(found.status!==STATUS.witness)return {status:found.status,reason:found.group?`no pluck plays the group at ${found.group.at} s (${found.group.notes.map(note=>note.pitch).join(', ')})`:null};
  return {status:STATUS.witness,path:found.path,cost:+found.cost.toFixed(6),witness:kalimbaWitness(who,notes,found.path,{choices})};
}
// The witness: each stroke its thumb's reservation for its recovery, in the thumb's place (a stroke over two neighbours
// one action), checked by the contract.
function kalimbaWitness(who,notes,path,{choices=KALIMBA}={}){
  const actions=[],byId=new Map(notes.map(note=>[note.id,note]));
  for(const [k,step] of path.entries())for(const stroke of step.strokes){
    const start=byId.get(stroke.notes[0].note).start,place=stroke.notes.reduce((sum,note)=>sum+note.place,0)/stroke.notes.length;
    actions.push(action({id:`pluck:${k}:${stroke.thumb}`,technique:stroke.notes.length>1?'double':'pluck',contacts:stroke.notes.map(note=>note.note),
      contactSeconds:stroke.notes.map(note=>byId.get(note.note).start),
      reservations:[{resource:stroke.thumb,phase:'excite',start,end:start+choices.strokeSeconds,configuration:`${stroke.thumb}@${place}`}]}));
  }
  return witness({who,actions,checks:[{id:'kalimba-thumbs',evidence:'authored',...checkReservations(who,actions)},{id:'damping',status:STATUS.unknown}]});
}
