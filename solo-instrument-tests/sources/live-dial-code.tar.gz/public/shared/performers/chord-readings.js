// The harmony a player hears, read as the tones a voicing may take and the tones it must hold -- each reading one way
// players hear a chord, every one in the harmony's own tuning:
// - heard: its tones as they are (the pool's pitch classes), those no chord names required first: a cluster's
//   semitones, a neutral third, a quartal stack's fourths -- naming it a chord would drop what makes it what it is (read
//   only where it holds such tones, or no third: a triad heard as it is is common practice's);
// - common: a common-practice player's: its root, its third (or the suspension in its place), its fifth, and its seventh
//   where the harmony holds one; its root (where no bass is heard) and third required;
// - jazz: a jazz player's seventh chord (jazzChord): its guide tones (the third or suspension, the seventh -- one from
//   the scale where the harmony holds none), the tensions its space offers where the player voices them (`colours`, up
//   to three: a dominant's altered ones at a high intended dissonance), its fifth where it takes fewer than two, its root
//   where no bass is heard; its guide tones required;
// - power: its root and fifth, both required;
// - colour: a colourist's -- the chord's own tones (its seventh only where the harmony holds one) and the colours its
//   space offers at the player's intended dissonance (harmonic-spaces.js colourChord: over C major the ninth and sixth
//   from the pentatonic, the sharp eleventh from lydian), its third required.
// Fed together into each instrument's own search for the voicings its hands can hold (the guitar's vocabularies were the
// first: guitar_clodbot chordFamilies), each reading's voicings dearer the less the player's taste weighs it (readingCost)
// -- never one reading every chord is forced through (the owner, 10 October 2026: "I'm seeing code like "const
// jazz=jazzchord()". This seems like inappropriate hardcoding; shouldn't 'jazzchords' be fed into the process for
// defining/searching acceptable pitches?": seven players had heard every chord as a jazz pianist's seventh chord).
import {modulo,near,has,fractional,chordTones} from '../../bots/lib/pitch-helpers.js';

export const READINGS=Object.freeze(['heard','common','jazz','power','colour']);
export const CHORD_READINGS=Object.freeze({
  // How much a reading's voicing costs where the player's taste for it is none (its taste's share of the player's
  // strongest: 1 costs nothing), in the voice-leading costs' own units (a voice moved a semitone costs about one), and
  // what leaving the reading it voiced the last chord from costs (a player keeps an idiom through a passage, never one a
  // chord): ours.
  cost:6,change:4,
});

// Jazz: the seventh chord a triad or pool stands for in its key (in C major: C major seven, D minor seven, G seven). A
// suspended chord keeps its suspension (the fourth or second) where a third would be, and takes no third from the scale:
// F7sus4 heard in C F B-flat E-flat was voiced with an A, outside the object and against its fourth.
export function jazzChord(chord,scale,object=[]){
  const root=chord.root,inScale=step=>has(scale,modulo(root+step,12)),sus=/sus/.test(chord.quality??'');
  const suspension=sus?(chord.pitchClasses??[]).find(pc=>[2,5].some(step=>near(modulo(pc-root,12),step)))??null:null;
  // A third or seventh the object holds between the keys (a neutral third, a harmonic seventh) is its third or seventh.
  const between=(low,high)=>object.find(pc=>fractional(pc)&&modulo(pc-root,12)>low&&modulo(pc-root,12)<high)??null;
  const third=sus?null:chord.third??between(2.6,4.4)??(inScale(4)?modulo(root+4,12):inScale(3)?modulo(root+3,12):null);
  const minor=third!==null&&modulo(third-root,12)===3,diminished=chord.fifth!==null&&modulo(chord.fifth-root,12)===6;
  // A seventh from the scale where the chord has none: a major seventh or minor seventh, a sixth where neither is there.
  const seventh=chord.seventh??between(9.4,11.4)??(inScale(10)?modulo(root+10,12):inScale(11)&&!minor?modulo(root+11,12):inScale(9)?modulo(root+9,12):null);
  const dominant=!minor&&!diminished&&seventh!==null&&modulo(seventh-root,12)===10;
  const fifth=chord.fifth??modulo(root+7,12);
  return {root,third,suspension,seventh,fifth,minor,dominant,holding:[root,third??suspension,seventh].filter(pc=>pc!==null)};
}

// A chord's readings: [{id, pcs, required, roles: {root, third, fifth, seventh}}], each in the harmony's tuning
// (`tuned`: a pitch class named on the grid as the object sounds it), those the harmony gives no tones to left out.
// chord: the chord named (HarmonyHearing); scale: the scale it lies in; object: the pool's pitch classes as heard;
// bass: whether a bass is heard (the root left to it); colours: the colours its space offers (colourChord's, past the
// chord's own tones).
export function chordReadings(chord,{scale=[],object=[],tuned=pc=>pc,bass=false,colours=[]}={}){
  if(!chord)return [];
  const jazz=jazzChord(chord,scale,object),t=pc=>pc===null||pc===undefined?null:tuned(pc);
  const set=list=>[...new Set(list.filter(pc=>pc!==null&&pc!==undefined).map(pc=>+modulo(pc,12).toFixed(6)))];
  const third=t(jazz.third??jazz.suspension),root=t(jazz.root),fifth=t(jazz.fifth),seventh=t(jazz.seventh),held=t(chord.seventh??null);
  const roles={root,third,fifth,seventh},out=[];
  // (Heard: the object's notes, those no chord tone names first -- where some lie outside the chord named, or it has no
  // third.)
  const named=chordTones(chord).map(tone=>object.find(pc=>near(pc,tone))).filter(pc=>pc!==undefined),extra=object.filter(pc=>!named.includes(pc));
  if(object.length&&(extra.length||third===null||object.length<3)){
    const pcs=set(object.length===1?[object[0],object[0]+7]:object.filter(pc=>!(bass&&near(pc,jazz.root))));
    out.push({id:'heard',pcs,required:set(extra.length?extra:[third??named[0]]).filter(pc=>pcs.some(p=>near(p,pc))),roles:{root,third,fifth:t(chord.fifth??null),seventh:held}});
  }
  if(third!==null){
    out.push({id:'common',pcs:set([third,fifth,held,...(bass?[]:[root])]),required:set([third,...(bass?[]:[root])]),roles:{root,third,fifth,seventh:held}});
    const tensions=colours.slice(0,3).map(t);
    out.push({id:'jazz',pcs:set([third,seventh,...tensions,...(tensions.length<2?[fifth]:[]),...(bass?[]:[root])]),required:set([third,seventh]),roles});
  }
  out.push({id:'power',pcs:set([root,fifth]),required:set([root,fifth]),roles:{root,third:null,fifth,seventh:null}});
  if(colours.length)out.push({id:'colour',pcs:set([third,fifth,held,...colours.map(t),...(bass?[]:[root])]),required:set([third]),roles:{root,third,fifth,seventh:held}});
  return out.filter(reading=>reading.pcs.length&&reading.required.every(pc=>reading.pcs.some(p=>near(p,pc))));
}

// A player's taste among the readings, each 0 to 1 (its strongest 1): the band's character where one is heard (its
// complexity toward jazz's and colour's, its plainness toward common practice's and, as its attack is spiky, power's),
// else drawn once a piece from the player's own seed (`random`: no reading the default, the owner's "No musical default
// written"); the harmony as heard always as strong as the strongest where no chord names it (`unnamed`: a cluster, a
// neutral third), and else -- a chord named, its added tones besides -- as the intricate readings are (jazz's, a
// colourist's): a plain player simplifies an added sixth or ninth to its triad, an intricate one voices it. `given`: a
// spec's own weights, over all.
export function readingWeights({character=null,random=Math.random,given=null,unnamed=false}={}){
  const clamp01=x=>Math.max(0,Math.min(1,Number(x)||0));
  let weights;
  if(given)weights=Object.fromEntries(READINGS.map(id=>[id,clamp01(given[id])]));
  else if(character){const intricate=clamp01(character.complexity),spiky=clamp01(character.attack),plain=1-intricate;
    weights={common:plain*(1-spiky),jazz:intricate*(1-spiky/2),power:plain*spiky,colour:intricate*(1-spiky)}}
  else weights=Object.fromEntries(READINGS.filter(id=>id!=='heard').map(id=>[id,random()]));
  weights.heard=given?weights.heard:unnamed?Math.max(...Object.values(weights)):Math.max(weights.jazz??0,weights.colour??0);
  const top=Math.max(...Object.values(weights));
  return Object.fromEntries(READINGS.map(id=>[id,top>0?+((weights[id]??0)/top).toFixed(4):id==='heard'?1:0]));
}
// What a reading's voicing costs the player: CHORD_READINGS.cost for one its taste weighs not at all, nothing for its
// strongest; and CHORD_READINGS.change more where it leaves the reading (`last`) it voiced the last chord from.
export const readingCost=(id,weights,{last=null,choices=CHORD_READINGS}={})=>choices.cost*(1-Math.max(0,Math.min(1,Number(weights?.[id])||0)))+(last&&last!==id?choices.change:0);
