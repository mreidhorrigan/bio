// A brass player's tongue let go: the air held behind it reaching the lips through the opening it leaves, that opening
// in series with the lips' own aperture -- two orifices the one flow passes, each dropping its Bernoulli pressure -- so
// that the pressure across the lips is A_t^2 / (A_t^2 + A_l^2) of the mouth's, the tongue's opening A_t growing at its
// measured rate from its release: half the mouth's pressure across them once A_t = A_l, four fifths at twice that, the
// rest more slowly. The lips' flow follows it (their slit's Bernoulli flow, through the pressure across them), so the
// tongue needs no hold on it once let go. The renders' players, the live dial (native/openwind/dial.mjs) and the brass's
// attack search share it.
//
// The tongue's opening rate: an alveolar stop's -- the syllable brass players tongue by, "ta" or "tu", the tongue's tip
// let go from behind the upper teeth -- measured from its articulation and fitted to its frication burst's length (11
// to 16 ms): 20 to 30 cm^2/s over its first 10 ms (K. L. Poort 1995,
// "Stop consonant production: an articulation and acoustic study", S.M. thesis, MIT, K. N. Stevens supervising;
// research-downloads/brass-tonguing/), where Stevens' estimate for an apical stop was 50 to 100 cm^2/s.
// The lips' aperture at rest: OpenWInD's lips' scaled opening zeta = Zc w H sqrt(2 / (rho Pclosed)), so w H = zeta
// sqrt(rho Pclosed / 2) / Zc -- the trumpet's NESS lips' 2.9 mm^2 (w 10 mm, H 0.29 mm), the trombone's measured 2.1 to
// 6.3 mm^2, the tuba's to 14 mm^2: the tongue's half-time 0.8 to 5.7 ms at Poort's rate.
export const TONGUE_OPENING=Object.freeze({rate:25e-4,range:Object.freeze([20e-4,30e-4]),unit:'m^2/s',basis:'measured',
  source:'K. L. Poort 1995, "Stop consonant production: an articulation and acoustic study", S.M. thesis, MIT: the voiceless alveolar stop\'s constriction opening at 20-30 cm^2/s over its first 10 ms, from its articulation and its burst (11-16 ms)'});

// (The lips' aperture at rest, m^2, from their row's zeta and closing pressure and the bore's entrance: its
// characteristic impedance zc and its air's density rho, body.json `reed`.)
export const lipsAperture=(zeta,closing,{zc,rho})=>zeta*Math.sqrt(rho*closing/2)/zc;

// The share of the mouth's pressure across the lips `t` s after the tongue is let go, the lips' aperture `aperture` m^2.
export function releasedShare(t,aperture,rate=TONGUE_OPENING.rate){
  if(!(aperture>0))return 1;
  const x=Math.max(0,t)*rate/aperture;
  return x*x/(1+x*x);
}

// Its course as the engine's moves: [[t, share], ...], in steps of its half-time (A_l / rate) -- a quarter of it to two
// of them, where the share rises fastest, a half to four, a whole to eight, where it is within 2% of whole -- its last
// share whole: each move a raised cosine from the one before (stream.rs HeldLine), so that the shares between them are
// drawn within two hundredths of the law's.
export const RELEASE_STEPS=Object.freeze([[.25,2],[.5,4],[1,8]]);
export function releaseCourse(aperture,{rate=TONGUE_OPENING.rate,steps=RELEASE_STEPS}={}){
  const half=aperture>0?aperture/rate:0;
  if(!half)return [[0,1]];
  const at=[];let x=0;
  for(const [step,to] of steps)while(x+step<=to+1e-9)at.push(x+=step);
  return at.map((x,k)=>[half*x,k===at.length-1?1:releasedShare(half*x,aperture,rate)]);
}

// A tongue let go from `shut` of the row it holds back: the times since its release its moves end at -- a brass
// player's along its course (releaseCourse), its lips' aperture `aperture` m^2; with none (a reed player's), one move
// over `release` s -- and the share of the row it holds `since` s after. The live dial's (native/openwind/dial.mjs) and
// the brass's attack search's (render/node/brass-attacks.mjs fromRest), so that both let it go alike.
export function tongueLetGo(aperture,shut,release,rate=TONGUE_OPENING.rate){
  const course=aperture>0?releaseCourse(aperture,{rate}):[[release,1]],end=course.at(-1)[0];
  const share=since=>since>=end||!(aperture>0)?1:releasedShare(since,aperture,rate);
  return {times:course.map(p=>p[0]),at:since=>since<=0?shut:shut+(1-shut)*share(since)};
}
