// A quantity a player holds, drawn over time: a curve of points [t, y] or [t, y, 'straight'] -- t in seconds from its
// start, the first at 0; y the quantity, or a multiple of it -- moving between two along the raised cosine
// (transitions.js eased: nothing changes in an instant) or, 'straight' on the later of the two, at one rate. Any quantity
// may be drawn so (the owner, 1 November 2026: "factor the curve tool for modularity in case we want to add it to other
// parameters"): what a curve of one kind may be is its kind's (`kind`), read by the page that draws it
// (native/live/curves.js) and the dials that play it alike. A note's attack is one kind (attack-curves.js).
//   kind: {least, most}  the quantity's reach (y);
//         longest        the latest a point may stand (s);
//         from           the first point's quantity where it is fixed (a breath or a bow's speed from rest: 0), else null;
//         settled        the last point's where it is fixed (an attack settled on the value held: 1), else null;
//         straight       whether a segment may be drawn straight (the winds' engine moves only along the raised cosine);
//         points         the most points a curve has.
import {eased} from './transitions.js';

// (The most points any curve has: the page's to draw, a few samples apart along a second or two.)
export const POINTS=64;

// A curve's value at `t` s from its start.
export function curveAt(points,t){
  if(t<=points[0][0])return points[0][1];
  for(let k=1;k<points.length;k++){
    const [a,y0]=points[k-1],[b,y1,shape]=points[k];
    if(t<b){const x=(t-a)/(b-a);return y0+(y1-y0)*(shape==='straight'?x:eased(x))}
  }
  return points.at(-1)[1];
}
// When it settles (s): its last point's time.
export const settlesAt=points=>points.at(-1)[0];
// Its peak: [t, y] of its greatest value.
export const peakOf=points=>points.reduce((p,q)=>q[1]>p[1]?q:p);
// The least points a curve of `kind` has: two where an end is fixed (a rise from rest, a settling), else one.
export const fewestOf=kind=>kind.from!=null||kind.settled!=null?2:1;

// A curve as given, made one of `kind`: its points in time's order, each within the kind's reach, the first at 0 and,
// where the kind fixes them, its ends at their values; each shape 'straight' only where the kind allows it. -> the
// points; throws where they are not a curve.
export function curveOf(given,kind){
  const {least=0,most=Infinity,longest=Infinity,from=null,settled=null,straight=true,points:count=POINTS}=kind;
  if(!Array.isArray(given)||!given.length||given.length>count)throw new Error(`a curve is from 1 to ${count} points`);
  const points=given.map(p=>{
    if(!Array.isArray(p)||!Number.isFinite(+p[0])||!Number.isFinite(+p[1]))throw new Error('a curve\'s point is [t, y]');
    const t=Math.min(longest,Math.max(0,+p[0])),y=Math.min(most,Math.max(least,+p[1]));
    return p[2]==='straight'&&straight?[t,y,'straight']:[t,y];
  }).sort((a,b)=>a[0]-b[0]);
  points[0]=[0,from??points[0][1]];
  for(let k=1;k<points.length;k++)if(!(points[k][0]>points[k-1][0]))throw new Error('a curve\'s points are each later than the one before');
  if(points.length<fewestOf(kind)){
    if(from!=null)throw new Error('a curve from a fixed start moves: two points at least');
    points[0]=[0,settled];
  }else if(settled!=null)points[points.length-1]=[points.at(-1)[0],settled,...points.at(-1).slice(2)];
  return points;
}

// Its points `step` s apart along its eased segments, and at every point (a straight segment needs only its ends): what
// a player following it a few samples at a time moves straight between. -> [[t, y]].
export function sampledCurve(points,step=.002){
  const out=[[points[0][0],points[0][1]]];
  for(let k=1;k<points.length;k++){
    const [a]=points[k-1],[b,y,shape]=points[k];
    if(shape!=='straight')for(let n=Math.ceil((b-a)/step),i=1;i<n;i++)out.push([a+(b-a)*i/n,curveAt(points,a+(b-a)*i/n)]);
    out.push([b,y]);
  }
  return out;
}

// A curve's segment ending at point `k` made `seconds` long, the points after it moved with it, each the same time after
// it as before -- never past `longest`: a dial and a curve one setting (a note's rise, a stroke's start).
export function segmentLasting(points,k,seconds,longest=Infinity){
  if(k<1||k>=points.length)return points;
  const shift=Math.min(longest-points.at(-1)[0],points[k-1][0]+seconds-points[k][0]);
  return points.map((p,i)=>i>=k?[+(p[0]+shift).toFixed(6),...p.slice(1)]:p);
}
// Its first segment so (the rise from rest).
export const firstEndingAt=(points,seconds)=>points.length<2?points:segmentLasting(points,1,seconds);
