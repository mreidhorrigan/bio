// A talking drum's squeeze and stick (the family atlas's F33, variable-tension and friction membranes: the hourglass
// talking drum; the cuíca and the friction drums not yet), planned through the performer contract's one solver
// (contract.js searchGroups), as the mallets, the kalimba, the steelpan and the timpani are. Taken by 2a at c2's word,
// 29 September (SESSIONS.md 12:04).
//
// **A pitch the arm squeezes.** The drum rests under one arm; squeezing its cords tightens both heads and raises its
// pitch from where it rests (TALKING_DRUM.relaxed), by up to TALKING_DRUM.span semitones. The atlas warns that no uniform
// map runs from squeeze to pitch, so none is assumed here: the pitches are the ones players were measured reaching (the
// dùndún's low, mid and high tones, 61.4, 124.8 and 172.3 Hz on three drummers; Akinbo 2019, doi:10.4000/lla.347), and
// the arm's speed between pitches is bounded (TALKING_DRUM.squeezePerSecond, from one local recording's glides: a
// check, not a source). A note may glide, its pitch moving under it as the arm squeezes or lets go (`glideFrom`, over
// `glide` seconds), never faster than the arm moves; between notes the arm moves the pitch to the next's first.
//
// **One stick.** The curved stick in the other hand strikes again once its stroke has recovered (TALKING_DRUM
// .strokeSeconds): one note at a time.
//
// **What is not modelled yet**, and says so: the squeezing hand's fingers (their damping and strokes), the stroke's place
// on the head, the drum's loudness by its squeeze, and the cuíca's and the friction drums' rubbed strokes.
import {action,checkReservations,profile,searchGroups,STATUS,witness} from './contract.js';
import {instrumentRange} from './instrument-ranges.js';

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const TALKING_DRUM=Object.freeze({
  // Its pitch at rest (MIDI: the measured low tone, 61.4 Hz), the squeeze's reach over it (semitones: the measured high
  // tone, 17.9 over the low), and the tones a speech surrogate plays over the rest (the measured mid 12.2 and high 17.9):
  // the instrument registry's dùndún (instrument-ranges.js; Akinbo 2019).
  relaxed:instrumentRange('talkingdrum').relaxed,span:instrumentRange('talkingdrum').span,
  tones:instrumentRange('talkingdrum').tones,
  // How fast the arm moves the pitch, either way (semitones a second: one local recording's strokes glide 5 to 9 semitones
  // in 0.15 s, a check, not a source), and how long a stroke holds the stick (s; authored).
  squeezePerSecond:45,strokeSeconds:1/10,
  // A pitch within this counts as reached (semitones); notes starting within `together` of each other are one group (s).
  tolerance:.05,together:.005,
  // Costs, authored: each semitone the arm moves.
  cost:Object.freeze({squeezePerSemitone:.01}),
  maxStates:4096,
});

// ---- The instrument --------------------------------------------------------------------------------------------------
// A drum: its pitch at rest and its squeeze's reach (semitones). -> {relaxed, span, range: [low, high]}.
export function talkingDrum({relaxed=TALKING_DRUM.relaxed,span=TALKING_DRUM.span}={}){
  if(!(Number.isFinite(relaxed)&&span>0))throw new RangeError('a talking drum rests at a pitch and squeezes over some semitones');
  return Object.freeze({relaxed,span,range:Object.freeze([relaxed,relaxed+span])});
}
// A tone's pitch on a drum (L, M, H, as the measured tones stand over its rest).
export const toneOf=(drum,tone,{choices=TALKING_DRUM}={})=>drum.relaxed+choices.tones[tone];
// How long the arm takes to move the pitch from one to another (s).
export const squeezeSeconds=(from,to,{choices=TALKING_DRUM}={})=>Math.abs(to-from)/choices.squeezePerSecond;
// Whether a pitch lies in the drum's squeeze.
export const inReach=(drum,pitch,{choices=TALKING_DRUM}={})=>pitch>=drum.range[0]-choices.tolerance&&pitch<=drum.range[1]+choices.tolerance;

// ---- The player ------------------------------------------------------------------------------------------------------
// A talking drummer's profile: the stick hand (RH, its stick RH.1) and the arm that squeezes (LA). `unavailable` names any.
export function talkingDrummer({id='talking-drummer',performer='talking-drummer',unavailable=[],evidence='authored'}={}){
  const state=name=>unavailable.includes(name)?'unavailable':'available';
  return profile({id,performer,resources:[{id:'RH',kind:'body',availability:state('RH'),evidence},
    {id:'RH.1',kind:'effector',parents:['RH'],availability:unavailable.includes('RH')?'unavailable':state('RH.1'),evidence},
    {id:'LA',kind:'actuator',availability:state('LA'),evidence}]});
}

// ---- Passages --------------------------------------------------------------------------------------------------------
// Plan a passage [{pitch, start, end, glideFrom?, glide?}] on a drum: each note struck by the stick once it has
// recovered, the arm bringing the pitch to the note's first (its glideFrom, else its pitch) since the last note settled
// (its glide's end), and gliding it under the note no faster than the arm moves. -> {status, path?, cost?, witness?,
// reason?}; refused (unknown) where a pitch lies outside the squeeze or a glide is faster than an arm.
export function planTalkingDrum(input,{drum=talkingDrum(),who=talkingDrummer(),choices=TALKING_DRUM}={}){
  if(!input.length)return {status:STATUS.witness,path:[],cost:0};
  const notes=input.map((note,index)=>({...note,id:note.id??`n${index}`}));
  for(const note of notes){
    if(!(note.end>note.start))throw new RangeError(`note ${note.id}: a positive duration`);
    note.sliding=Number(note.glide)>0&&Number.isFinite(Number(note.glideFrom))&&Math.abs(note.glideFrom-note.pitch)>choices.tolerance;
    note.first=note.sliding?note.glideFrom:note.pitch;
    for(const pitch of [note.pitch,note.first])if(!inReach(drum,pitch,{choices}))return {status:STATUS.unknown,reason:`pitch ${pitch} lies outside the drum's squeeze (${drum.range[0].toFixed(2)} to ${drum.range[1].toFixed(2)})`};
    if(note.sliding&&note.glide<squeezeSeconds(note.first,note.pitch,{choices})-1e-9)return {status:STATUS.unknown,reason:`a glide of ${note.glide} s is faster than an arm squeezes from ${note.first} to ${note.pitch}`};
  }
  if(!sticksOf(who))return {status:STATUS.unknown,reason:'no stick hand'};
  const groups=[];
  for(const note of [...notes].sort((a,b)=>a.start-b.start)){const last=groups.at(-1);if(last&&note.start-last.at<=choices.together)last.notes.push(note);else groups.push({at:note.start,notes:[note]})}
  // The state: where the arm holds the pitch and since when (its last glide's end), when the stick is free, and where
  // and when its last glide began (a stroke while the arm still squeezes sounds where the arm is then, and the arm
  // glides on from there: struck mid-squeeze, not as if it had arrived).
  const stateKey=state=>JSON.stringify([state.pitch===null?null:Math.round(state.pitch*1000)/1000,Math.round(state.settled*1000)/1000,Math.round(state.free*1000)/1000,
    state.from==null?null:Math.round(state.from*1000)/1000]);
  const expand=(group,state)=>{
    if(group.notes.length>1)return [];
    const [note]=group.notes;
    if(group.at<state.free-1e-9)return [];
    const moving=state.pitch!==null&&state.from!=null&&group.at<state.settled-1e-9;
    if(moving){const arm=state.from+(state.pitch-state.from)*(group.at-state.at)/(state.settled-state.at);if(Math.abs(note.first-arm)>choices.tolerance+1e-9)return []}
    const move=state.pitch===null||moving?0:Math.abs(note.first-state.pitch);
    if(!moving&&state.pitch!==null&&move/choices.squeezePerSecond>Math.max(0,group.at-state.settled)+1e-9)return [];
    const settled=note.sliding?group.at+note.glide:group.at;
    return [{status:'supported',cost:choices.cost.squeezePerSemitone*(move+(note.sliding?Math.abs(note.pitch-note.first):0)),
      state:{pitch:note.pitch,settled,free:group.at+choices.strokeSeconds,...(note.sliding?{from:note.first,at:group.at}:{})},step:{at:group.at,note:note.id,pitch:note.pitch,first:note.first,squeezed:move,settled}}];
  };
  const found=searchGroups(groups,{initial:{pitch:null,settled:-Infinity,free:-Infinity},expand,stateKey,maxStates:choices.maxStates});
  if(found.status!==STATUS.witness)return {status:found.status,reason:found.group?`no stroke and squeeze play the note at ${found.group.at} s (${found.group.notes.map(note=>note.pitch).join(', ')})`:null};
  return {status:STATUS.witness,path:found.path,cost:+found.cost.toFixed(6),witness:talkingWitness(who,notes,found.path,{choices})};
}
const sticksOf=who=>who.resources.get('RH.1')?.availability==='available'&&who.resources.get('LA')?.availability==='available';
// The witness: each stroke its stick's reservation for its recovery; the arm holding the pitch from each note's start to
// the next's (or its end), checked by the contract.
function talkingWitness(who,notes,path,{choices=TALKING_DRUM}={}){
  const actions=[],byId=new Map(notes.map(note=>[note.id,note]));
  for(const [k,step] of path.entries()){
    const note=byId.get(step.note),next=path[k+1],until=next?Math.max(note.start+1e-3,next.at-1e-6):note.end;
    actions.push(action({id:`stroke:${k}`,technique:'stroke',contacts:[step.note],contactSeconds:[note.start],
      reservations:[{resource:'RH.1',phase:'excite',start:note.start,end:note.start+choices.strokeSeconds,configuration:'RH@head'},
        {resource:'LA',phase:'hold',start:note.start,end:until,configuration:`squeeze:${step.first.toFixed(2)}${note.sliding?`>${note.pitch.toFixed(2)}`:''}`}]}));
  }
  return witness({who,actions,checks:[{id:'talking-drum-stick-and-squeeze',evidence:'authored',...checkReservations(who,actions)},{id:'fingers',status:STATUS.unknown}]});
}
