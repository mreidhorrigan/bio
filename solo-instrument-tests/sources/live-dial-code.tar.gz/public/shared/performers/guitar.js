// A guitarist's hands on a fretted neck, planned through the performer contract's one solver (contract.js
// searchGroups), as the piano is (piano.js). The general performer–instrument report's M3 (§5; C01, C02, and its F05
// barre): adding an instrument needs a profile, its actions and its moves, and no change to the solver.
//
// **A pitch is not a string and fret** (§5.1): each note may sound on any string whose range holds it. A string sounds
// one note at a time (strings are the instrument's own resources in the profile); a new note on a string still sounding
// would cut it, which the plan does not do silently.
//
// **The fretting hand covers a window** (authored, GUITAR.window): finger n sits near fret position + n − 1, one fret's
// stretch either way. A barre is one compound action: the first finger across several strings at one fret, one
// reservation of that finger (A03). A fretted note held keeps its finger and pins the hand; an open string rings on its
// own, and the hand may move while it does (C01). The picking hand plucks each group as one action and has its own rate.
//
// **What is not modelled yet**, and says so: damping (a string left ringing past its note), bends and slides, and the
// thumb over the neck. A pitch between the frets is refused, not rounded.
import {action,checkReservations,profile,searchGroups,STATUS,witness} from './contract.js';
import {instrumentRange} from './instrument-ranges.js';

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const GUITAR=Object.freeze({
  // Standard tuning, low string to high (MIDI): E2 A2 D3 G3 B3 E4; and the highest fret (the instrument registry's,
  // instrument-ranges.js).
  tuning:instrumentRange('guitar').strings,frets:instrumentRange('guitar').frets,
  // Authored: frets the hand's four fingers cover at once, the stretch a finger may reach beyond its fret, and how fast
  // the hand shifts along the neck (frets a second).
  window:4,stretch:1,shiftFretsPerSecond:30,
  // Authored: how long a pluck holds the picking hand (s), so its fastest repeated stroke is about 16 a second.
  pluckSeconds:1/16,
  // Notes starting within this of each other are one group (s).
  together:.005,
  // Costs, all authored: a fret shifted; a finger stretched past its fret; a fret above the twelfth (a smaller target);
  // and each fret of the hand's position, so that of two voicings otherwise alike the one nearer the nut is taken.
  cost:Object.freeze({shiftPerFret:.1,stretch:.3,highFret:.02,positionPerFret:.005}),
  maxStates:4096,
});

// A guitarist's profile: the fretting hand (FH) and its four fingers, the picking hand (PH), and the strings, each
// sounding one note at a time. `unavailable` names any of them (a finger the player does not use, a broken string).
export function guitarist({id='guitarist',performer='guitarist',unavailable=[],choices=GUITAR,evidence='authored'}={}){
  const resources=[{id:'FH',kind:'body',availability:unavailable.includes('FH')?'unavailable':'available',evidence},
    ...['1','2','3','4'].map(finger=>({id:`FH.${finger}`,kind:'effector',parents:['FH'],availability:unavailable.includes(`FH.${finger}`)||unavailable.includes('FH')?'unavailable':'available',evidence})),
    {id:'PH',kind:'effector',availability:unavailable.includes('PH')?'unavailable':'available',evidence},
    ...choices.tuning.map((_,string)=>({id:`string:${string}`,kind:'mechanism',availability:unavailable.includes(`string:${string}`)?'unavailable':'available',evidence}))];
  return profile({id,performer,resources});
}
const available=(who,id)=>who.resources.get(id)?.availability==='available';

// ---- One group's placements ------------------------------------------------------------------------------------------
// Each note's positions: [{string, fret}] on the strings the profile has.
function positionsOf(pitch,who,{choices=GUITAR}={}){
  return choices.tuning.map((open,string)=>({string,fret:pitch-open})).filter(({string,fret})=>fret>=0&&fret<=choices.frets&&available(who,`string:${string}`));
}
// Every way to put a group's notes on distinct strings not already sounding: [[{note, string, fret}]].
function stringChoices(notes,who,sounding,{choices=GUITAR}={}){
  const out=[],used=new Set(sounding),place=(index,chosen)=>{
    if(index===notes.length){out.push(chosen);return}
    for(const position of positionsOf(notes[index].pitch,who,{choices}))if(!used.has(position.string)){
      used.add(position.string);place(index+1,[...chosen,{note:notes[index],...position}]);used.delete(position.string);
    }
  };
  place(0,[]);return out;
}
// The fretting hand's options for its fretted notes (the held ones fixed): a position, and a finger for each note, a
// barre letting the first finger take several strings at the position's own fret. [{position, fingers, cost}].
function fingerings(fretted,held,who,{choices=GUITAR}={}){
  const fingers=['1','2','3','4'].filter(finger=>available(who,`FH.${finger}`)),out=[];
  const all=[...held,...fretted];if(!all.length)return [{position:null,fingers:[],cost:0}];
  const low=Math.min(...all.map(item=>item.fret)),high=Math.max(...all.map(item=>item.fret));
  for(let position=Math.max(1,high-choices.window-choices.stretch+1);position<=low+choices.stretch;position++){
    const reach=(finger,fret)=>Math.abs(fret-(position+Number(finger)-1))<=choices.stretch;
    const fixed=new Map(held.map(item=>[item.finger,item]));
    if(held.some(item=>!reach(item.finger,item.fret)))continue;
    const assign=(index,chosen,taken)=>{
      if(index===fretted.length){
        const stretched=[...held,...chosen].filter(item=>item.fret!==position+Number(item.finger)-1).length;
        out.push({position,fingers:chosen,cost:stretched*choices.cost.stretch+Math.max(0,position-12)*choices.cost.highFret+position*choices.cost.positionPerFret});return;
      }
      const item=fretted[index];
      for(const finger of fingers){
        if(!reach(finger,item.fret))continue;
        // A finger holds one fret: a barre (several strings at one fret) is the first finger's, at the position's own fret.
        const same=[...taken.get(finger)??[]];
        if(same.length&&!(finger==='1'&&same.every(other=>other.fret===item.fret)&&item.fret===position))continue;
        const next=new Map(taken);next.set(finger,[...same,item]);
        assign(index+1,[...chosen,{...item,finger}],next);
      }
    };
    assign(0,[],new Map([...fixed].map(([finger,item])=>[finger,[item]])));
  }
  return out;
}

// ---- Passages --------------------------------------------------------------------------------------------------------
// Plan a passage {pitch, start, end}: {status, path?, cost?, witness?, reason?}.
export function planGuitar(input,{who=guitarist(),choices=GUITAR}={}){
  if(!input.length)return {status:STATUS.witness,path:[],cost:0};
  const notes=input.map((note,index)=>({...note,id:note.id??`n${index}`}));
  for(const note of notes){
    if(!Number.isInteger(note.pitch))return {status:STATUS.unknown,reason:`pitch ${note.pitch} lies between the frets: declare a bend, a slide or another instrument`};
    if(!(note.end>note.start))throw new RangeError(`note ${note.id}: a positive duration`);
    if(!positionsOf(note.pitch,who,{choices}).length)return {status:STATUS.violates,reason:`pitch ${note.pitch} is on no string of this guitar`};
  }
  const groups=[];
  for(const note of [...notes].sort((a,b)=>a.start-b.start||a.pitch-b.pitch)){const last=groups.at(-1);if(last&&note.start-last.at<=choices.together)last.notes.push(note);else groups.push({at:note.start,notes:[note]})}
  const stateKey=state=>JSON.stringify([state.position,state.sounding.map(item=>`${item.string}:${item.fret}:${item.finger??''}:${item.end}`)]);
  const expand=(group,state)=>{
    const sounding=state.sounding.filter(item=>item.end>group.at+choices.together),heldFretted=sounding.filter(item=>item.fret>0);
    const moves=[];
    for(const placed of stringChoices(group.notes,who,sounding.map(item=>item.string),{choices})){
      const fretted=placed.filter(item=>item.fret>0),open=placed.filter(item=>item.fret===0);
      for(const fingering of fingerings(fretted,heldFretted,who,{choices})){
        const seconds=state.at===null?Infinity:group.at-state.at,shift=state.position===null||fingering.position===null?0:Math.abs(fingering.position-state.position);
        if(shift>choices.shiftFretsPerSecond*seconds+1e-9)continue;
        const newFretted=fingering.fingers;
        const after=[...sounding,...newFretted.map(item=>({string:item.string,fret:item.fret,finger:item.finger,end:item.note.end,note:item.note.id})),
          ...open.map(item=>({string:item.string,fret:0,finger:null,end:item.note.end,note:item.note.id}))];
        moves.push({status:'supported',cost:shift*choices.cost.shiftPerFret+fingering.cost,
          state:{position:fingering.position??state.position,at:fingering.position===null?state.at:group.at,sounding:after},
          step:{at:group.at,position:fingering.position,notes:[...newFretted.map(item=>({note:item.note.id,pitch:item.note.pitch,string:item.string,fret:item.fret,finger:item.finger})),
            ...open.map(item=>({note:item.note.id,pitch:item.note.pitch,string:item.string,fret:0,finger:null}))]}});
      }
    }
    return moves;
  };
  const found=searchGroups(groups,{initial:{position:null,at:null,sounding:[]},expand,stateKey,maxStates:choices.maxStates});
  if(found.status!==STATUS.witness)return {status:found.status,reason:found.group?`no string and fingering plays the group at ${found.group.at} s (${found.group.notes.map(note=>note.pitch).join(', ')})`:null};
  return {status:STATUS.witness,path:found.path,cost:+found.cost.toFixed(6),witness:guitarWitness(who,notes,found.path,{choices})};
}
// The witness: each fretted note a reservation of its finger (a barre one action for its strings), each note its
// string for as long as it sounds, each group a pluck of the picking hand, checked by the contract.
function guitarWitness(who,notes,path,{choices=GUITAR}={}){
  const actions=[],byId=new Map(notes.map(note=>[note.id,note]));
  for(const step of path){
    const barre=step.notes.filter(item=>item.finger==='1'&&step.notes.filter(other=>other.finger==='1').length>1);
    if(barre.length)actions.push(action({id:`barre@${step.at}`,technique:'barre',contacts:barre.map(item=>item.note),
      reservations:[{resource:'FH.1',phase:'hold',start:step.at,end:Math.max(...barre.map(item=>byId.get(item.note).end)),configuration:`FH@${step.position}`}]}));
    for(const item of step.notes){
      const note=byId.get(item.note),reservations=[{resource:`string:${item.string}`,phase:'hold',start:note.start,end:note.end}];
      if(item.finger&&!barre.includes(item))reservations.push({resource:`FH.${item.finger}`,phase:'hold',start:note.start,end:note.end,configuration:`FH@${step.position}`});
      actions.push(action({id:`note:${item.note}`,contacts:[item.note],contactSeconds:[note.start],reservations}));
    }
    actions.push(action({id:`pluck@${step.at}`,technique:step.notes.length>1?'strum':'pluck',contacts:step.notes.map(item=>item.note),
      reservations:[{resource:'PH',phase:'excite',start:step.at,end:step.at+choices.pluckSeconds}]}));
  }
  return witness({who,actions,checks:[{id:'fingers-strings-and-hands',evidence:'authored',...checkReservations(who,actions)},{id:'damping',status:STATUS.unknown},{id:'expression',status:STATUS.unknown}]});
}
