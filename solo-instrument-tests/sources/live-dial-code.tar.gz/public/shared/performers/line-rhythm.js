// A line's rhythm on the rhythm engine (shared/euclidean.js; docs/RHYTHM_TO_FORM.md), where its planner is switched to
// it (line.js: `choices.rhythm`, the piece's shares as its player leans them: opening-time.js `rhythm`, personality.js)
// -- the owner, 4 November 2026: "Avoid hardcoding anything. Do not design rhythms directly"; "I am hoping that the new
// rhythm engine will allow much faster and more rhythmically diverse passages." Nothing here is a rhythm, and no number here is a musical one: a span -- a motif's
// bar, a held note -- is a tree of layers, and its notes are Euclidean rhythms nested in it.
//
//   The tree: a span divided as its meter divides it -- its groups, its felt beats, their units -- and below them into
//     parts drawn from every division the span affords at its player's quickest note (euclidean.js divisions): the
//     meter space's own (meter-space.js METER_SPACE.layers, two and three) as that space weighs them, any other -- five,
//     seven, thirteen in the time of one -- as the player's `tuplets` share weighs it against them; each part divided
//     so again, down to where no part of two is playable. Each node draws its own division, so that a beat in three
//     stands beside one in five.
//   Syncopation (the owner's parameters, 4 November 2026): a node whose parts are alike, as often as the line's
//     `syncopation` share, has the layer under its parts regrouped -- its parts each divided alike, into mu -- by a
//     syncopation and its resolution (euclidean.js syncopate): its length L in those events, at least two of its parts
//     and ending where one ends (the next event of the layer above, where it resolves); its meter M among those
//     dissonant with mu that repeat in L ("usually weighted toward L"); its repeats R; the rest of L grouped at mu, its
//     resolution. Within it, a length of 0 to L ("the usual weighting is toward 0, but it's not the only possible one"):
//     its groups beginning there are each syncopated again, a syncopation within the syncopation. Its groups weigh as
//     the engine's trees weigh (euclidean.js groupTree, pathWeight): a note placed in it stands on their starts. A
//     hemiola is one: two beats of three units regrouped in twos, L 6, M 2, R 3.
//     Each parameter is drawn from what the span affords, toward its low or its high end by a share of the line's
//     (`toward`: one half draws evenly, 0 and 1 its ends): L toward the whole by `length`, M toward L by `meter`, R
//     toward the most by `repeats`, the length within toward L by `within`.
//   The notes: k of them placed over a node's parts as evenly as they go (euclidean.js euclid: E(k, n), beginning where
//     the node does), k drawn among those the node holds, each note lasting to the next; the rest dealt among the notes
//     placed as evenly as they go (evenlyWithin), each within what its own span holds, and placed in it so in turn -- a
//     Euclidean rhythm of a Euclidean rhythm, as deep as the notes go. A note placed alone over a node's parts is placed
//     again in the layer below them. Every note at least the player's quickest by construction.
//
// Spans are in felt beats from the bar's start, exact (transcript/rational.js), as the line's cells are (rhythm-cell.js).
import {Rational} from '../../transcript/rational.js';
import {divisions,syncopate,syncopations,rotationsOf,evenlyWithin} from '../euclidean.js';
import {METER_SPACE} from '../meter-space.js';

const R=value=>Rational.of(value);
const unit=x=>Math.max(0,Math.min(1,Number(x)));
// The shares a line's rhythm reads, each 0 to 1: the piece's (opening-time.js `rhythm`), its tuplets and syncopation as
// its player leans them (personality.js RHYTHM_LEVERS).
export const RHYTHM_SHARES=Object.freeze(['tuplets','syncopation','length','meter','repeats','within']);
// A draw `u` (0 to 1) carried toward 0 or 1 by `share`: a half leaves it as it is (an even draw), a share toward 0 brings
// it toward 0 (u to the power (1 - share) / share), toward 1 toward 1; 0 and 1 are the ends themselves.
export function toward(u,share){const s=unit(share);return s<=0?0:s>=1?1:unit(u)**((1-s)/s)}
// One of `list` (in order, low to high), drawn toward its high end by `share`.
const pick=(list,u,share)=>list[Math.round(toward(u,share)*(list.length-1))];

// The shares as given (a player's: personality.js playingOf, the piece's as it leans them), each 0 to 1: -> them, frozen; a RangeError where one is
// missing, for a line switched to the engine has no shares of its own.
export function rhythmShares(given){
  const out={};
  for(const name of RHYTHM_SHARES){const value=Number(given?.[name]);if(!Number.isFinite(value))throw new RangeError(`a line's rhythm on the engine reads its player's ${RHYTHM_SHARES.join(', ')} shares, not ${JSON.stringify(given)}`);out[name]=unit(value)}
  return Object.freeze(out);
}

// The bar a line's spans lie in: its felt beats' seconds, their groups (line.js beatGroups: {first, count}) and the units
// in each felt beat (its ticks over the meter's subdivision, where whole; none known, none) -> {levels: the meter's
// boundaries, coarsest first, each a list of felt-beat positions; secondsOf(a, b)}.
export function barOf({groups,beatSeconds,unitsPerBeat=null}){
  const beats=beatSeconds.length,levels=[];
  levels.push(groups.slice(1).map(group=>R(group.first)));
  levels.push(Array.from({length:beats-1},(_,k)=>R(k+1)));
  if(unitsPerBeat)levels.push(unitsPerBeat.flatMap((units,beat)=>Number.isSafeInteger(units)&&units>1?Array.from({length:units-1},(_,k)=>R(beat).add(new Rational(k+1,units))):[]));
  // (Seconds of a span in felt beats: each felt beat's share of it at that beat's seconds.)
  const secondsOf=(a,b)=>{let total=0;for(let beat=Math.max(0,a.floor());beat<beats&&R(beat).lt(b);beat++){const from=a.max(R(beat)),to=b.min(R(beat+1));if(to.gt(from))total+=to.sub(from).toNumber()*beatSeconds[beat]}return total};
  return Object.freeze({levels:Object.freeze(levels.map(Object.freeze)),secondsOf});
}

// The meter space's own divisions' weights, and any other's at `tuplets` times their least.
const LAYERS=new Map(METER_SPACE.layers);
const LEAST=Math.min(...LAYERS.values());
// A division of a span `seconds` long, drawn from every one it affords at `quickest` -> a count of parts, or null where
// none of two is playable.
function drawDivision(seconds,{quickest,shares,random}){
  const most=divisions(seconds,{shortest:quickest});
  if(most<2)return null;
  const options=Array.from({length:most-1},(_,k)=>k+2).map(m=>[m,LAYERS.get(m)??shares.tuplets*LEAST]).filter(([,weight])=>weight>0);
  let left=random()*options.reduce((sum,[,weight])=>sum+weight,0);
  for(const [m,weight] of options){left-=weight;if(left<0)return m}
  return options.at(-1)[0];
}

// A span's tree: {at, end, children?, division?, syncopation?} -- `children` its parts, each a tree, none where it
// divides no further; `division` their count where it was drawn (not the meter's); `syncopation` {length, meter,
// repeats, resolution, within, mu} where its parts are a syncopation's groups and the parts after it.
// bar: barOf's; quickest: the player's quickest note (s); shares: rhythmShares; random: a source of [0, 1).
export function spanTree({at,end},{bar,quickest,shares,random}){
  const context={bar,quickest,shares,random};
  return grow({at:R(at),end:R(end)},context);
}
const leaf=span=>Object.freeze({at:span.at,end:span.end});
const equalParts=(span,m)=>{const size=span.end.sub(span.at).div(m);return Array.from({length:m},(_,k)=>({at:span.at.add(size.mul(k)),end:span.at.add(size.mul(k+1))}))};
// (Its parts where its meter cuts it: the coarsest of the meter's levels with a boundary inside it.)
function meterParts(span,bar){
  for(const level of bar.levels){
    const cuts=level.filter(p=>p.gt(span.at)&&p.lt(span.end));
    if(cuts.length)return [span.at,...cuts,span.end].slice(0,-1).map((p,k,all)=>({at:p,end:all[k+1]??span.end}));
  }
  return null;
}
// (`inside`: within a syncopation's group, where only its length within syncopates again.)
function grow(span,context,inside=false){
  const {bar,quickest,shares,random}=context,seconds=bar.secondsOf(span.at,span.end);
  // (The meter's parts where it cuts the span and each is playable; else a division drawn.)
  let parts=meterParts(span,bar);
  if(parts?.some(part=>bar.secondsOf(part.at,part.end)<quickest-1e-12))parts=null;
  let division=null;
  if(!parts){division=drawDivision(seconds,context);if(!division)return leaf(span);parts=equalParts(span,division)}
  // (Parts alike -- as long, and as long in seconds -- may be regrouped by a syncopation.)
  const alike=parts.every(part=>part.end.sub(part.at).eq(parts[0].end.sub(parts[0].at))&&Math.abs(bar.secondsOf(part.at,part.end)-bar.secondsOf(parts[0].at,parts[0].end))<1e-9);
  if(alike&&!inside&&random()<shares.syncopation){const regrouped=syncopated(span,parts,context);if(regrouped)return regrouped}
  return Object.freeze({...leaf(span),...(division?{division}:{}),children:Object.freeze(parts.map(part=>grow(part,context,inside)))});
}
// A span's parts' layer below regrouped by a syncopation and its resolution, the parts after it as they were -> its tree,
// or null where none fits.
function syncopated(span,parts,context){
  const {bar,shares,random}=context,partSeconds=bar.secondsOf(parts[0].at,parts[0].end);
  const mu=drawDivision(partSeconds,context);
  if(!mu)return null;
  const lengths=Array.from({length:parts.length-1},(_,k)=>mu*(k+2)).filter(L=>syncopations(L,mu).length);
  if(!lengths.length)return null;
  const length=pick(lengths,random(),shares.length),options=syncopations(length,mu);
  const meter=pick([...new Set(options.map(o=>o.meter))].sort((a,b)=>a-b),random(),shares.meter);
  const repeats=pick(options.filter(o=>o.meter===meter).map(o=>o.repeats).sort((a,b)=>a-b),random(),shares.repeats);
  const {groups,resolution}=syncopate(length,{meter,repeats,resolution:mu});
  const within=Math.round(toward(random(),shares.within)*length),event=parts[0].end.sub(parts[0].at).div(mu);
  let at=0;
  const grouped=groups.map(size=>{
    const group={at:span.at.add(event.mul(at)),end:span.at.add(event.mul(at+size))},inner=at<within;at+=size;
    const events=equalParts(group,size);
    // (A group of its events, each grown on down; one beginning within the length within syncopated again where it can be.)
    const regrouped=inner&&size>2?syncopated(group,events,context):null;
    return regrouped??Object.freeze({...leaf(group),children:Object.freeze(events.map(e=>grow(e,context,true)))});
  });
  const rest=parts.slice(length/mu).map(part=>grow(part,context));
  return Object.freeze({...leaf(span),children:Object.freeze([...grouped,...rest]),
    syncopation:Object.freeze({length,meter,repeats,resolution:resolution.groups,within,mu})});
}

// How many notes a tree holds: its leaves.
export function leavesOf(tree){return tree.children?tree.children.reduce((sum,child)=>sum+leavesOf(child),0):1}

// `count` notes placed in a tree (no more than it holds), its first where it begins -> their onsets (felt beats), in
// order; each lasts to the next, the last to the tree's end.
export function placeNotes(tree,count,random){
  const most=leavesOf(tree);
  if(!Number.isSafeInteger(count)||count<1||count>most)throw new RangeError(`a span of ${most} playable notes holds 1 to ${most}, not ${count}`);
  return Object.freeze(place(tree,count,random));
}
function place(node,count,random){
  if(count<=1||!node.children)return [node.at];
  const parts=node.children,n=parts.length;
  // (A note alone over parts none of which divides: every note placed among them.)
  const fewest=parts.some(part=>part.children)?1:count,k=fewest+Math.floor(random()*(Math.min(count,n)-fewest+1));
  if(k===1){
    // (Alone over them: placed again in the layer below, every part's parts -- a part that divides no further itself.)
    return place({at:node.at,end:node.end,children:parts.flatMap(part=>part.children??[part])},count,random);
  }
  const rotations=rotationsOf(k,n,new Array(n).fill(0),{downbeat:true}),{onsets}=rotations[Math.floor(random()*rotations.length)];
  const spans=onsets.map((first,j)=>parts.slice(first,onsets[j+1]??n)),room=spans.map(span=>span.reduce((sum,part)=>sum+leavesOf(part),0)-1);
  // (The rest dealt as evenly as they go: each note a whole share, the remainder to notes spread evenly among them,
  // drawn at one of their turns; what a note cannot hold to the next that can.)
  const extra=count-k,share=new Array(k).fill(Math.floor(extra/k));
  for(const j of evenlyWithin(Array.from({length:k},(_,j)=>j),extra%k,Math.floor(random()*k)))share[j]++;
  let over=0;share.forEach((s,j)=>{if(s>room[j]){over+=s-room[j];share[j]=room[j]}});
  for(let j=0;over>0;j=(j+1)%k)if(share[j]<room[j]){share[j]++;over--}
  return spans.flatMap((span,j)=>place(span.length===1?span[0]:{at:span[0].at,end:span.at(-1).end,children:span},1+share[j],random));
}
// Each onset's duration to the next, the last to `end`: -> [{at, duration}], exact.
export function noteSpans(onsets,end){return onsets.map((at,k)=>Object.freeze({at,duration:(onsets[k+1]??R(end)).sub(at)}))}
