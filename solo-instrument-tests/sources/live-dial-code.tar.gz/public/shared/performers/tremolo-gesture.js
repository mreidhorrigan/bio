// A tremolo as a gesture (the owner, 3 October 2026, of Op. 3.22: "There are also far too many tremoloes, and tremolo
// gestures don't have enough dynamic shaping"; "Tremoloes sound quite strange and unnatural. I believe they would
// normally be faster, but also, various speeds of tremolo exist, just like vibratoes"). A section's held notes had each
// trembled on a draw of their own, a quarter of them on the average and nearly all of them where a figure heard pulled
// the amount up: a tremolo scattered note by note, at one level and one speed.
//
// Now a pool's phrase trembles whole or not at all, its players together, as a section's "trem." is written over a
// passage: the pool's amount of tremolo (string-section.js, 0 to 1) the chance its phrase does. A phrase that trembles
// draws, for the pool, from its seed:
//   rate    its strokes a second (a bow's reversals, a wind's tonguings), anywhere in its family's range: from a measured
//           tremolo's to the quickest a player keeps up, every speed between (a pool's own, as a vibrato's rate is a
//           player's); log-uniform, each player of it a little off it (the seats' own paces, section-seat.js TREMOLO);
//   peak    where in the phrase it is loudest, 0 to 1: at its start a diminuendo, at its end a crescendo, between a swell
//           (a hairpin to there and away) -- every shape between those;
//   depth   how far its loudness moves, in dB: several just-noticeable differences (a level's is about 1 dB), so that
//           the shape is heard as meant (the gesture reinforced, as the project's rules ask);
//   accent  an fp's share of the depth: its first stroke that much above where the shape begins, falling back over
//           `fall` of the phrase -- the cube of a uniform draw, so most gestures none and some a sharp one.
// Its loudness at a place in its phrase is gestureDb. The ranges are ours: no measured tremolo rate was found (the
// rates of bowed and tongued tremolo in performance are a gap in the literature this project reads).
import {seededSource} from './string-section.js';
import {materialOf} from './section-voices.js';

// (`pace`: a player's own share of its section's rate, drawn once a seat, about its middle: the seats' TREMOLO, BREATH.)
export const TREMOLO_GESTURE=Object.freeze({
  rate:Object.freeze({bowed:Object.freeze([10,22]),wind:Object.freeze([8,14])}),
  depth:Object.freeze([9,18]),fall:.08,pace:Object.freeze([.85,1.05]),
});
const clamp01=x=>Math.max(0,Math.min(1,x));

// Whether a seat's pool trembles through its phrase, and how: `role` its role (its pool's tremolo, seed and material),
// `family` 'bowed' or 'wind'. -> null, or {rate (strokes a second), peak, depth (dB), accent}. The same for every player
// of the pool in the phrase: drawn from the pool's seed, never the seat's.
export function tremoloGesture(role,family='bowed'){
  const amount=Number(role?.tremolo);if(!(amount>0))return null;
  const random=seededSource(role.seed??0,`tremolo:${materialOf(role)}`);
  if(random()>=amount)return null;
  const [slow,quick]=TREMOLO_GESTURE.rate[family]??TREMOLO_GESTURE.rate.bowed,[shallow,deep]=TREMOLO_GESTURE.depth;
  return Object.freeze({rate:+(slow*(quick/slow)**random()).toFixed(3),peak:+random().toFixed(3),depth:+(shallow+(deep-shallow)*random()).toFixed(2),accent:+(random()**3).toFixed(3)});
}

// A gesture's loudness at `position` (0 to 1, its place in the phrase), in dB about the phrase's own level: a hairpin
// from half its depth below to half above at its peak and back (a crescendo's or a diminuendo's one side of it), and its
// fp's accent falling away from the start.
export function gestureDb(gesture,position){
  if(!gesture)return 0;
  const x=clamp01(Number(position)||0),peak=clamp01(gesture.peak);
  const rise=peak>=1?x:peak<=0?1-x:x<peak?x/peak:(1-x)/(1-peak);
  const fp=gesture.accent>0?gesture.accent*Math.max(0,1-x/TREMOLO_GESTURE.fall):0;
  return gesture.depth*(rise-.5+fp);
}

// A player's strokes a second in a gesture: the gesture's rate at its own `pace` (TREMOLO_GESTURE.pace, about its
// middle), moved toward a figure heard -- role.tremoloRate {to: the figure's rate, a share of a player's quickest (its
// family's quickest tremolo); share: as far as its pool takes after it, the conductor's inspiration} -- geometrically.
export function tremoloRate(gesture,role,pace,family='bowed'){
  const [slow,quick]=TREMOLO_GESTURE.pace,own=(Number(pace)||(slow+quick)/2)/((slow+quick)/2);
  const after=role?.tremoloRate,to=Number(after?.to),share=Math.min(1,Math.max(0,Number(after?.share)||0));
  const heard=to>0&&share>0?(to*(TREMOLO_GESTURE.rate[family]??TREMOLO_GESTURE.rate.bowed)[1]/gesture.rate)**share:1;
  return gesture.rate*own*heard;
}
