// A fingering drawn as its players read it (the owner, 1 November 2026: "visual rendering of fingerings, both in generated
// scores and in the live-dial page"): a woodwind's as LilyPond's woodwind diagram draws it, put together from its keys'
// pieces (fingering-diagrams.json: scripts/make-fingering-diagrams.mjs, which checks that they draw every charted
// fingering as LilyPond does), its keys found from its holes as they stand -- the dial's, dialled anywhere -- through its
// keywork (render/synthesis/tools/export_keywork.py); a valved brass instrument's valves, each as far down as it is
// pressed; a trombone's slide at its position.
import DIAGRAMS from './fingering-diagrams.json' with {type:'json'};

// (A hole part-covered as LilyPond writes it, by the share of it a finger covers -- the nearest: R a ring key pressed and
// its hole left open, 1q, 1h, 3q a quarter, a half, three quarters covered: design_openwind_woodwind.py PART_COVERED.)
export const PARTS=Object.freeze(['R','1q','1h','3q']);
const PART_COVERED=[[0,'R'],[.25,'1q'],[.5,'1h'],[.75,'3q']];
export const elementKey=([x,y,mark])=>`${x},${y}|${mark}`;
// (A fingering's keys as one name: each group's keys, sorted.)
export const keyId=keys=>['cc','lh','rh'].map(g=>`${g}:${[...(keys[g]??[])].sort().join(',')}`).join('|');
// (An empty mark under the same mark filled, only the filled kept: a key pressed among its group, the group drawn empty
// for another of them; and each mark once.)
export function twinFilled(marks){
  const filled=new Set(marks.filter(m=>m[2].includes('fill="currentColor"')).map(m=>elementKey([m[0],m[1],m[2].replace('fill="currentColor"','fill="none"')])));
  const seen=new Set;
  return marks.filter(m=>{const k=elementKey(m);if(seen.has(k)||filled.has(k))return false;seen.add(k);return true});
}
// A diagram's marks for `keys` ({cc, lh, rh}: LilyPond's names, a part-covered hole's suffixed) from its family's pieces
// (`entry`): the empty drawing less what each key takes from it, with what each adds, and where two of them pressed
// together move each other's marks, as LilyPond moves them -- or, where its pieces would still draw it otherwise, LilyPond's
// own drawing of it, kept whole. -> {marks: [[x, y, mark]], box: [x, y, width, height]}
export function composeDiagram(entry,keys){
  const whole=entry.whole?.[keyId(keys)];
  if(whole)return {marks:twinFilled(whole),box:entry.box};
  const drop=new Set,add=[],ids=[];
  for(const g of ['cc','lh','rh'])for(const name of keys[g]??[]){const piece=entry.keys[`${g}:${name}`];if(!piece)continue;ids.push(`${g}:${name}`);for(const i of piece.drop)drop.add(i);add.push(...piece.add)}
  let marks=twinFilled([...entry.base.filter((m,i)=>!drop.has(i)),...add]);
  const pairs=ids.flatMap((a,i)=>ids.slice(i+1).map(b=>entry.pairs?.[[a,b].sort().join('+')])).filter(Boolean);
  if(pairs.length){const gone=new Set(pairs.flatMap(p=>p.remove));marks=twinFilled([...marks.filter(m=>!gone.has(elementKey(m))),...pairs.flatMap(p=>p.add)])}
  return {marks,box:entry.box};
}
// (Every side key of a family outlined, as a fingering chart draws its whole keywork: each hand's group as LilyPond draws
// it once a key of it is pressed, none filled -- a part-covered piece left out, its key's own outline already there.)
const outlines=new Map;
function outlineOf(entry){
  if(!outlines.has(entry)){const marks=[];
    for(const [id,piece] of Object.entries(entry.keys)){const [g,name]=id.split(':'),part=PARTS.find(p=>name.endsWith(p)&&name!==p);
      if(g==='cc'||part&&entry.keys[`${g}:${name.slice(0,-part.length)}`])continue;
      marks.push(...piece.add.map(([x,y,m])=>[x,y,m.replace('fill="currentColor"','fill="none"')]))}
    outlines.set(entry,twinFilled(marks))}
  return outlines.get(entry);
}
const svgOf=(box,inner,label)=>`<svg xmlns="http://www.w3.org/2000/svg" viewBox="${box.join(' ')}" role="img" aria-label="${label.replace(/[<>&"]/g,'')}"><title>${label.replace(/[<>&]/g,'')}</title>${inner}</svg>`;
const marksSvg=marks=>marks.map(([x,y,m])=>`<g transform="translate(${x} ${y})">${m}</g>`).join('');
let drawings=0;
// A woodwind diagram as SVG (its marks in the page's own colour): `family` LilyPond's ('clarinet', 'saxophone', ...);
// `whole`, every key outlined as a fingering chart draws them, the pressed ones filled (the live dial's), else as LilyPond
// draws it in a score: a hand's keys only where one of them is pressed. `parts` ({'group:key': 0 to 1}): keys pressed part
// way, each filled from below as far as it is pressed (the dial's: a hole's every move seen, where a score has LilyPond's
// quarters), a ring's own mark with it where the diagram has one; `faint` ({'group:key': 0 to 1}) the same, drawn faint.
export function diagramSvg(family,keys,label='Fingering',{whole=false,parts={},faint={}}={}){
  const entry=DIAGRAMS.families[family];if(!entry)return null;
  const rings=Object.keys(parts).filter(id=>entry.keys[`${id}R`]).map(id=>id.split(':'));
  const all=rings.length?Object.fromEntries(['cc','lh','rh'].map(g=>[g,[...(keys[g]??[]),...rings.filter(([r])=>r===g).map(([,n])=>`${n}R`)]])):keys;
  const drawn=composeDiagram(entry,all),box=drawn.box,marks=whole?twinFilled([...drawn.marks,...outlineOf(entry)]):drawn.marks;
  const id=`fingered${++drawings}`,shown=[...Object.entries(parts).filter(([,a])=>a<1).map(([key,a])=>[key,a,1]),...Object.entries(faint).map(([key,a])=>[key,a,.35])].filter(([key,a])=>entry.keys[key]&&a>0);
  const clips=shown.map(([,a],n)=>`<clipPath id="${id}-${n}" clipPathUnits="objectBoundingBox"><rect x="-0.1" y="${+(1-Math.min(1,a)).toFixed(4)}" width="1.2" height="${+(Math.min(1,a)+.1).toFixed(4)}"/></clipPath>`);
  const filled=shown.map(([key,,opacity],n)=>`<g clip-path="url(#${id}-${n})"${opacity<1?` opacity="${opacity}"`:''}>${marksSvg(entry.keys[key].add.filter(m=>m[2].includes('fill="currentColor"')))}</g>`);
  return svgOf(box,`${clips.length?`<defs>${clips.join('')}</defs>`:''}<g stroke="currentColor" stroke-linejoin="round" stroke-linecap="round">${marksSvg(marks)}${filled.join('')}</g>`,label);
}

// ---- a woodwind's keys from its holes ----
export const keywork=model=>DIAGRAMS.instruments[model]??null;
// The holes `pressed` ({'group:key': share pressed, 1 or a finger's part}) leaves open, each its uncovered share: its
// design tools' (design_openwind_woodwind.py openings).
export function openingsOf(model,pressed){
  const w=keywork(model),state=Object.fromEntries(w.holes.map(h=>[h,w.standing.includes(h)?0:1]));
  for(const key of Object.keys(pressed))for(const h of w.keys[key]?.[1]??[])state[h]=1;
  for(const [key,[other,down,up]] of Object.entries(w.switch))if(key in pressed)state[other in pressed?down:up]=1;
  for(const [key,amount] of Object.entries(pressed)){const [closes=[],,own=null]=w.keys[key]??[];for(const h of closes)state[h]=Math.min(state[h],h===own?1-amount:0)}
  return state;
}
// (A fingering as LilyPond's diagram names its keys: a part pressed its nearest part-covering.)
export function diagramKeys(pressed){
  const out={cc:[],lh:[],rh:[]};
  for(const [id,amount] of Object.entries(pressed)){const [g,k]=id.split(':');
    out[g].push(amount>=1?k:k+PART_COVERED.reduce((a,b)=>Math.abs(b[0]-amount)<Math.abs(a[0]-amount)?b:a)[1])}
  return out;
}
const decoded=new Map;
// (Its chart's fingerings, each its keys pressed and as its players' guide writes it.)
function chartedOf(model){
  if(!decoded.has(model)){const w=keywork(model),names=Object.keys(w.keys);
    decoded.set(model,w.charted.map(([code,documented])=>({pressed:Object.fromEntries(code.split(' ').filter(Boolean).map(p=>{const [k,a]=p.split(':');return [names[+k],a==null?1:+a]})),documented})))}
  return decoded.get(model);
}
// The keys a woodwind's fingering presses for its holes as they stand (`open`: {hole: open share, 0 to 1}, as its body
// names them; those its keywork lacks passed by): its chart's fingering that leaves them so, else the one nearest, each
// key then moved in turn -- pressed, let go, its own hole part-covered as it stands -- where that leaves them nearer, and
// where none does, two keys at once (one pressed as another is let go), until nothing does. Of charted fingerings
// leaving them alike, one its players' guide writes first. `from`: the fingering it begins from instead ({'group:key':
// share}) -- a player's own, shading one hole of it. -> {pressed, keys (LilyPond's), documented (its guide's writing, a
// charted one's), off: [holes it leaves otherwise than they stand]}
export const HELD=.02;
export function fingeringOf(model,open,{from=null}={}){
  const w=keywork(model);if(!w)return null;
  const holes=w.holes.filter(h=>Number.isFinite(open[h]));
  const cost=pressed=>{const o=openingsOf(model,pressed);return holes.reduce((s,h)=>s+Math.abs(o[h]-open[h]),0)};
  let best=from?{pressed:from,documented:null,e:cost(from)}:null;
  if(!from)for(const c of chartedOf(model)){const e=cost(c.pressed);if(!best||e<best.e-1e-9||e<=best.e+1e-9&&c.documented&&!best.documented)best={...c,e}}
  let pressed={...(best?.pressed??{})},e=best?.e??cost({}),documented=best&&best.e<=HELD?best.documented:null;
  const keys=Object.keys(w.keys),flipped=(trial,key)=>{if(key in trial)delete trial[key];else trial[key]=1;return trial};
  for(let pass=0;pass<8&&e>HELD;pass++){let moved=false;
    for(const [key,[,,own]] of Object.entries(w.keys)){
      const shares=[0,1,...(own&&open[own]>0&&open[own]<1?[1-open[own]]:[])];
      for(const a of shares){const trial={...pressed};if(a===0)delete trial[key];else trial[key]=a;const t=cost(trial);
        if(t<e-1e-9){pressed=trial;e=t;moved=true}}}
    if(!moved)for(let i=0;i<keys.length&&!moved;i++)for(let j=i+1;j<keys.length&&!moved;j++){
      const trial=flipped(flipped({...pressed},keys[i]),keys[j]),t=cost(trial);if(t<e-1e-9){pressed=trial;e=t;moved=true}}
    if(!moved)break}
  const o=openingsOf(model,pressed);
  return {pressed,keys:diagramKeys(pressed),documented,off:holes.filter(h=>Math.abs(o[h]-open[h])>HELD)};
}
// The fingering as the dial holds it, each key drawn as far as its holes stand, so that every move of a hole is seen:
// fingeringOf's keys; a hole they leave otherwise than it stands, where it is a finger's own, that finger covering it as
// far as it stands, where that moves it (the pads its key closes with it said where they stand otherwise); else the key
// that moves it,
// pressed as far between its released and pressed openings as the hole stands -- among the keys found, or those with one
// let go as another is pressed -- where that leaves every hole nearer than the keys found do. A hole still left so that some key moves, though only with others, gets that key drawn faint as far
// as the hole stands -- the key nearest it, never a claim that it is pressed. -> {pressed, keys (LilyPond's, those
// pressed whole), parts ({'group:key': share}), documented, off: [holes the keys drawn leave otherwise than they stand],
// faint: {'group:key': {share, hole, moves: [the other holes it moves]}}}
export function heldFingering(model,open){
  const f=fingeringOf(model,open);if(!f)return null;
  const w=keywork(model),holes=w.holes.filter(h=>Number.isFinite(open[h])),pressed={...f.pressed},pads={};
  const finger=Object.fromEntries(Object.entries(w.keys).filter(([,k])=>k[2]).map(([key,k])=>[k[2],key]));
  // (What the keys drawn leave each hole at: a pad key part way between its released and pressed openings.)
  const held=(whole,part)=>{const o=openingsOf(model,whole);
    for(const [key,s] of Object.entries(part)){const on=openingsOf(model,{...whole,[key]:1}),out={...whole};delete out[key];const b=openingsOf(model,out);
      for(const x of holes)if(on[x]!==b[x])o[x]=b[x]+s*(on[x]-b[x])}
    return o};
  const missed=o=>holes.reduce((s,x)=>s+Math.abs(o[x]-open[x]),0),names=Object.keys(w.keys);
  // (The keys that move a hole: closing it, opening it, or switching it as another key is pressed.)
  const movers=h=>names.filter(k=>{const [c=[],o=[]]=w.keys[k];return c.includes(h)||o.includes(h)||Object.entries(w.switch).some(([a,[b,d,u]])=>(a===k||b===k)&&(d===h||u===h))});
  for(const h of f.off){
    if(finger[h]){const trial={...pressed},a=1-open[h];if(a<=0)delete trial[finger[h]];else trial[finger[h]]=a;
      if(Math.abs(held(trial,pads)[h]-open[h])<Math.abs(held(pressed,pads)[h]-open[h])-1e-9){Object.assign(pressed,trial);if(a<=0)delete pressed[finger[h]];continue}}
    // (The keys found, or those with one let go as another is pressed: a key pressed part way among them.)
    const moving=movers(h),bases=[pressed,...Object.keys(pressed).filter(k=>moving.includes(k)).flatMap(k=>names.filter(j=>!(j in pressed)).map(j=>{const b={...pressed,[j]:1};delete b[k];return b}))];
    let best={e:missed(held(pressed,pads))-1e-9};
    for(const base of bases)for(const key of moving){const s=held(base,{...pads,[key]:0}),t=held(base,{...pads,[key]:1});if(Math.abs(t[h]-s[h])<1e-9)continue;
      const share=Math.max(0,Math.min(1,(open[h]-s[h])/(t[h]-s[h]))),e=missed(held(base,{...pads,[key]:share}));
      if(e<best.e)best={base,key,share,e}}
    if(best.key){const base={...best.base};Object.keys(pressed).forEach(k=>delete pressed[k]);Object.assign(pressed,base);pads[best.key]=best.share}}
  const o=held(pressed,pads),keys={cc:[],lh:[],rh:[]},parts={},faint={};
  for(const [key,a] of Object.entries({...pressed,...pads})){const [g,k]=key.split(':');if(a>=1)keys[g].push(k);else if(a>0)parts[key]=a}
  const off=holes.filter(x=>Math.abs(o[x]-open[x])>HELD);
  for(const h of off){if(finger[h])continue;let best=null;
    for(const key of movers(h)){if(key in faint)continue;const s=held(pressed,{...pads,[key]:0}),t=held(pressed,{...pads,[key]:1});if(Math.abs(t[h]-s[h])<1e-9)continue;
      const moves=holes.filter(x=>x!==h&&Math.abs(t[x]-s[x])>1e-9),spill=moves.reduce((q,x)=>q+Math.abs(t[x]-s[x]),0);
      if(!best||spill<best.spill-1e-9)best={key,spill,moves,share:Math.max(0,Math.min(1,(open[h]-s[h])/(t[h]-s[h])))}}
    if(best&&best.share>0&&!(pressed[best.key]>=1))faint[best.key]={share:best.share,hole:h,moves:best.moves}}
  return {pressed:f.pressed,keys,parts,documented:f.documented,off,faint};
}
// A woodwind's fingering drawn: its diagram's SVG (`whole`, `parts`, `faint`: diagramSvg's) and the keys it presses its
// diagram has no place for. -> {svg, undrawn}
export function woodwindDiagram(model,keys,label,{whole=false,parts={},faint={}}={}){
  const w=keywork(model);if(!w)return null;
  const family=DIAGRAMS.families[w.diagram],undrawn=[];
  const drawn=Object.fromEntries(['cc','lh','rh'].map(g=>[g,(keys[g]??[]).filter(name=>{const ok=Boolean(family.keys[`${g}:${name}`]);if(!ok)undrawn.push(`${g}:${name}`);return ok})]));
  const placed=shares=>Object.fromEntries(Object.entries(shares).filter(([key])=>{const ok=Boolean(family.keys[key]);if(!ok)undrawn.push(key);return ok}));
  return {svg:diagramSvg(w.diagram,drawn,label,{whole,parts:placed(parts),faint:placed(faint)}),undrawn};
}

// ---- the brass ----
// A valved instrument's valves, each a circle filled as far as it is pressed (`pressed`: 0 up to 1 down, a half-valve
// between), numbered as its players number them, first nearest the mouthpiece.
export function valvesSvg(pressed,label='Valves'){
  const r=1,gap=.6,step=2*r+gap,w=pressed.length*step-gap+.4,h=2*r+1.8;
  const circles=pressed.map((p,k)=>{const x=.2+r+k*step,y=.2+r,f=Math.max(0,Math.min(1,p)),top=y+r-2*r*f;
    return `<clipPath id="v${k}"><rect x="${x-r}" y="${top}" width="${2*r}" height="${2*r*f}"/></clipPath>`+
      `<circle cx="${x}" cy="${y}" r="${r}" fill="currentColor" clip-path="url(#v${k})"/><circle cx="${x}" cy="${y}" r="${r}" fill="none" stroke="currentColor" stroke-width=".1"/>`+
      `<text x="${x}" y="${y+r+1.4}" font-size="1.1" text-anchor="middle" fill="currentColor">${k+1}</text>`});
  return svgOf([0,0,+w.toFixed(3),h],circles.join(''),label);
}
// A trombone's slide: its seven positions marked along it, the slide drawn out to `position` (1 in, 7 out and past).
export function slideSvg(position,most=7,label='Slide'){
  const end=Math.max(7,most),x=p=>1+(p-1)*(18/(end-1)),at=Math.max(1,Math.min(end,position));
  const marks=Array.from({length:7},(_,k)=>`<line x1="${x(k+1)}" y1="2.6" x2="${x(k+1)}" y2="3.6" stroke="currentColor" stroke-width=".1"/><text x="${x(k+1)}" y="5" font-size="1.1" text-anchor="middle" fill="currentColor">${k+1}</text>`);
  return svgOf([0,0,21,5.6],`<rect x="${x(1)-.4}" y=".6" width="${x(at)-x(1)+.8}" height="1.2" rx=".3" fill="currentColor" opacity=".35"/>`+
    `<line x1="${x(1)}" y1="2.6" x2="${x(end)}" y2="2.6" stroke="currentColor" stroke-width=".1"/>${marks.join('')}`+
    `<line x1="${x(at)}" y1=".2" x2="${x(at)}" y2="3.8" stroke="currentColor" stroke-width=".25"/>`,label);
}
