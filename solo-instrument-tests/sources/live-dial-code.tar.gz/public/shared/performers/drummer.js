// A drummer through the performer contract (contract.js): limbs as resources, a counted gesture's contacts
// (gestures.js) compiled into actions, a rebound pair one action of two contacts, and whether a gesture is playable by
// those limbs at the tempo it is played at. The drums' half of the general report's M1: the same interface a pianist
// passes through (keyboard.js).
//
// What occupies a hand is authored, not measured (DRUMMER's margins), so a witness here says the declared model's hands
// can play a gesture, not that a given person can. Which surface each contact strikes, and a groove's own strokes
// competing with a fill for the hands, are the next milestone's (orchestration on the contract).
import {action,checkReservations,instant,profile,REASONS,SLACK,STATUS,TIME_GRAIN,witness} from './contract.js';

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const DRUMMER=Object.freeze({
  // The limbs a drum kit is usually played with, and the limb each counted hand is (gestures.js' R and L).
  limbs:Object.freeze(['RH','LH','RF','LF']),
  hands:Object.freeze({R:'RH',L:'LH'}),
  // How long a stroke holds its limb beyond its own contacts: before (the stick's lift) and after (its rebound and
  // return). Authored, not measured: alternating singles top out at 12 contacts a second, and a roll of rebound pairs
  // at 18 (a hand's pair and its next are three contacts' gaps apart), the rate fills were held to before the contract.
  prepareSeconds:1/12,recoverSeconds:1/12,
  // A grace's (a flam's, a drag's): a low stroke from near the head, its hand held about as long as a grace's own gap
  // before and after it, not a full stroke's lift and return (argued from the Groove MIDI drummers' closest graces, 18 ms
  // before the next stroke: research/fill-figures-gmd.json graces.onItsDrum.gapSeconds p10).
  gracePrepareSeconds:.018,graceRecoverSeconds:.018,
  // The closest a rebound pair's two contacts come: that same roll's own rate (authored). A grace pair's (a drag's two,
  // one hand's closed bounce) come closer: the least gap the Groove MIDI drummers' graces left before the next stroke
  // on their drum, 18 ms (research/fill-figures-gmd.json graces.onItsDrum.gapSeconds p10; their drags' bounces were 26
  // to 34 ms).
  reboundSeconds:1/18,graceReboundSeconds:.018,
  // The limb each piece of a kit is played by, set up for a right-handed player (the default profile's limbs):
  // the kick and the hat's pedal by the feet, the hat and the cymbals by the right hand, the snare by the left.
  pieceLimbs:Object.freeze({kick:'RF',softKick:'RF',pedalHat:'LF',closedHat:'RH',openHat:'RH',hihat:'RH',ride:'RH',
    crash:'RH',snare:'LH',rim:'LH',sidestick:'LH',clap:'LH'}),
});

// A drummer's profile: its limbs (any ids), each one stroke at a time; `unavailable` names those it has not got.
export function drummer({id='drummer',performer='drummer',limbs=DRUMMER.limbs,unavailable=[],prohibited=[],evidence='authored'}={}){
  return profile({id,performer,prohibited,resources:limbs.map(limb=>({id:limb,kind:'effector',availability:unavailable.includes(limb)?'unavailable':'available',capacity:1,evidence}))});
}

// A counted gesture's actions: its contacts grouped by action (a rebound pair's two, a grace alone), each holding its
// hand's limb from `prepareSeconds` before its first contact to `recoverSeconds` after its last. Seconds from the
// gesture's own tick 0, a grace its seconds ahead of its principal; or where each will sound (`secondsOf(contact)`, the
// same scale), after every layer that moves it (the rubato report's stage C: a swing, a placement, the hands' travel).
export function gestureActions(played,{secondsPerTick,hands=DRUMMER.hands,choices=DRUMMER,secondsOf=null}={}){
  if(!(secondsPerTick>0))throw new RangeError('gestureActions needs the seconds a tick lasts');
  const groups=new Map;
  for(const contact of played.contacts){
    const limb=hands[contact.hand];if(!limb)throw new TypeError(`no limb plays hand ${contact.hand}`);
    const seconds=secondsOf?secondsOf(contact):contact.at.toNumber()*secondsPerTick-(contact.before??0);
    if(!Number.isFinite(seconds))throw new RangeError(`contact ${contact.id} has no time`);
    if(!groups.has(contact.action))groups.set(contact.action,{limb,technique:contact.role==='grace'?'grace':null,contacts:[]});
    const group=groups.get(contact.action);
    if(group.limb!==limb)throw new TypeError(`action ${contact.action} is played by two limbs`);
    group.contacts.push({id:contact.id,seconds});
  }
  return [...groups].map(([id,{limb,technique,contacts}])=>{
    contacts.sort((a,b)=>a.seconds-b.seconds);
    const first=contacts[0].seconds,last=contacts.at(-1).seconds,grace=technique==='grace';
    const before=grace?choices.gracePrepareSeconds??DRUMMER.gracePrepareSeconds:choices.prepareSeconds,after=grace?choices.graceRecoverSeconds??DRUMMER.graceRecoverSeconds:choices.recoverSeconds;
    return action({id,technique:technique??(contacts.length>1?'rebound':'stroke'),contacts:contacts.map(contact=>contact.id),contactSeconds:contacts.map(contact=>contact.seconds),
      reservations:[{resource:limb,phase:'excite',start:first-before,end:last+after}]});
  });
}
// Rebound pairs whose contacts come closer than the stick rebounds (a grace pair's, closer than a grace's): {status,
// violations}.
export function checkRebounds(actions,{least=DRUMMER.reboundSeconds,graceLeast=DRUMMER.graceReboundSeconds}={}){
  const violations=[];
  for(const act of actions)for(let k=1;k<act.contactSeconds.length;k++){
    const gap=act.contactSeconds[k]-act.contactSeconds[k-1],bound=act.technique==='grace'?graceLeast:least;
    if(gap<bound-TIME_GRAIN)violations.push({action:act.id,reason:REASONS.technique,gapSeconds:gap,leastSeconds:bound});
  }
  return {status:violations.length?STATUS.violates:STATUS.witness,violations};
}
// Whether `who` can play a counted gesture at `secondsPerTick`: its witness (contract.js), from its limbs' reservations
// and its rebound pairs; at its contacts' nominal times, or where each will sound (`secondsOf`: gestureActions).
export function playable(who,played,{secondsPerTick,hands=DRUMMER.hands,choices=DRUMMER,secondsOf=null}={}){
  const actions=gestureActions(played,{secondsPerTick,hands,choices,secondsOf});
  return witness({who,actions,checks:[{id:'limbs',evidence:'authored',...checkReservations(who,actions)},{id:'rebounds',evidence:'authored',...checkRebounds(actions,{least:choices.reboundSeconds,graceLeast:choices.graceReboundSeconds})}]});
}
// A counted gesture as a phrase: each limb it uses held from its first reservation to its last, or to `until` (seconds)
// where the gesture's span runs on past its last stroke (a fill stopped short of its landing: its silence is its own).
// A drummer in a fill does not slip a groove's stroke into a hand's momentary rest; the fill is one gesture, and its
// hands are in it throughout. [action], one a limb, in the gesture's seconds.
export function phraseActions(actions,{id='phrase',until=-Infinity}={}){
  const all=actions.flatMap(act=>act.reservations);if(!all.length)return [];
  const start=Math.min(...all.map(reservation=>reservation.start)),end=Math.max(until,...all.map(reservation=>reservation.end));
  return [...new Set(all.map(reservation=>reservation.resource))].map(limb=>action({id:`${id}:${limb}`,contacts:[],
    reservations:[{resource:limb,phase:'hold',start,end}]}));
}
// Whether a limb is free at `seconds` for a stroke of its own (its prepare and recover margins around the contact),
// given actions already holding limbs (gestureActions): the contract's reservations decide, so an ongoing part competes
// with a fill for the same limbs and keeps only those the fill leaves free.
export function limbFree(actions,limb,seconds,{choices=DRUMMER}={}){
  const start=seconds-choices.prepareSeconds,end=seconds+choices.recoverSeconds;
  return !actions.some(act=>act.reservations.some(reservation=>reservation.resource===limb&&reservation.start<end-TIME_GRAIN&&start<reservation.end-TIME_GRAIN));
}

// ---- By construction -------------------------------------------------------------------------------------------------
// The user, 28 September 2026: "Checks should be used only for system development, but the system must not require
// extensive checking for its actually deployed versions ... We are not building a brute-force system". A drummer's fills
// are made from what its hands can do (xdrum_clodbot), worked out here from DRUMMER's margins, and never checked while
// they are played: `playable` (the performer contract) is the reference the tests hold them to.
//
// The closest a drummer's two hands strike in each motion: alternating singles, each hand's strokes two contacts apart,
// (prepare + recover) / 2 (a twelfth of a second); a continuous motion of rebound pairs (the doubles, a roll), each
// hand's pairs three contacts apart, the larger of the rebound and (prepare + recover) / 3 (an eighteenth). Contacts no
// closer than these are playable in that motion whatever is left out between them, since a stroke left out only widens
// its hand's gap. `fastest` is the closer of the two. Infinity where the performer has not the motion: a hand
// unavailable (both motions are two hands'), rebounds ruled out (no doubles).
export function motionSpacing(who=null,{hands=DRUMMER.hands,choices=DRUMMER}={}){
  const lacks=Object.values(hands).some(limb=>who?.resources.get(limb)?.availability==='unavailable')||Boolean(who?.prohibited.has('stroke'));
  const stroke=choices.prepareSeconds+choices.recoverSeconds;
  const singles=lacks?Infinity:stroke/2,doubles=lacks||who?.prohibited.has('rebound')?Infinity:Math.max(choices.reboundSeconds,stroke/3);
  return Object.freeze({singles,doubles,fastest:Math.min(singles,doubles)});
}
// Whether a drummer's limbs can play a counted gesture's contacts: `playable`'s answer (its witness), in closed form, at
// the contacts' nominal times or where each will sound (`secondsOf`, as gestureActions reads them). Each action holds
// its limb from `prepareSeconds` before its first contact to `recoverSeconds` after its last (a grace's own margins); no
// limb holds more actions at once than its capacity, none is unavailable, no technique is ruled out, and a rebound
// pair's contacts come no closer than the stick rebounds; times compared at the contract's grain, as its checks compare
// them. For a drummer's limbs, which have no parent resources. Cheap enough to weigh each of a fill's few options.
export function handsAllow(played,{who,secondsPerTick,hands=DRUMMER.hands,choices=DRUMMER,secondsOf=null}={}){
  const groups=new Map;
  for(const contact of played.contacts){
    const limb=hands[contact.hand];if(!limb)throw new TypeError(`no limb plays hand ${contact.hand}`);
    const seconds=secondsOf?secondsOf(contact):contact.at.toNumber()*secondsPerTick-(contact.before??0);
    let group=groups.get(contact.action);
    if(!group)groups.set(contact.action,group={limb,grace:contact.role==='grace',seconds:[]});
    else if(group.limb!==limb)throw new TypeError(`action ${contact.action} is played by two limbs`);
    group.seconds.push(seconds);
  }
  const held=new Map;
  for(const {limb,grace,seconds} of groups.values()){
    seconds.sort((a,b)=>a-b);
    if(who.prohibited.has(grace?'grace':seconds.length>1?'rebound':'stroke'))return false;
    const least=grace?choices.graceReboundSeconds??DRUMMER.graceReboundSeconds:choices.reboundSeconds;
    for(let k=1;k<seconds.length;k++)if(seconds[k]-seconds[k-1]<least-TIME_GRAIN)return false;
    const resource=who.resources.get(limb);
    if(!resource||resource.availability==='unknown')continue;
    if(resource.availability==='unavailable')return false;
    if(resource.parents.length)throw new TypeError(`handsAllow reads a drummer's limbs, and ${limb} has parents`);
    const before=grace?choices.gracePrepareSeconds??DRUMMER.gracePrepareSeconds:choices.prepareSeconds;
    const after=grace?choices.graceRecoverSeconds??DRUMMER.graceRecoverSeconds:choices.recoverSeconds;
    if(!held.has(limb))held.set(limb,[]);
    held.get(limb).push([seconds[0]-before,1],[seconds.at(-1)+after,-1]);
  }
  for(const [limb,events] of held){
    events.sort((a,b)=>instant(a[0])-instant(b[0])||a[1]-b[1]);
    const capacity=who.resources.get(limb).capacity;let used=0;
    for(const [,delta] of events){used+=delta;if(used>capacity+SLACK)return false}
  }
  return true;
}
// How late each of a playable gesture's strokes may land and its limbs keep handsAllow's margins: `asked` (seconds, by
// stroke id: its hands' travel about the kit, kit.js navigation) as far as the next contact on each limb allows, a grace
// or a double landing as late as the stroke it belongs to. Taken from the last stroke back, so each is weighed against
// where the ones after it land; a few nanoseconds inside each margin, so the contract's grain reads it as kept. Never
// earlier than planned. By stroke id.
export function lateWithin(played,asked,{secondsPerTick,hands=DRUMMER.hands,choices=DRUMMER,secondsOf=null}={}){
  const contacts=played.contacts.map(contact=>({contact,stroke:contact.of??contact.id,limb:hands[contact.hand],grace:contact.role==='grace',
    seconds:secondsOf?secondsOf(contact):contact.at.toNumber()*secondsPerTick-(contact.before??0)}));
  const first=new Map,last=new Map;
  for(const entry of contacts){const action=entry.contact.action;
    if(!first.has(action)||entry.seconds<first.get(action).seconds)first.set(action,entry);
    if(!last.has(action)||entry.seconds>=last.get(action).seconds)last.set(action,entry)}
  const margin=(entry,side)=>entry.grace?side==='before'?choices.gracePrepareSeconds??DRUMMER.gracePrepareSeconds:choices.graceRecoverSeconds??DRUMMER.graceRecoverSeconds
    :side==='before'?choices.prepareSeconds:choices.recoverSeconds;
  // Each limb's contacts in time, and what each needs before the next: a rebound within an action, else the one's
  // recovery and the next one's preparation.
  const bounds=new Map,byLimb=Map.groupBy(contacts,entry=>entry.limb);
  for(const list of byLimb.values()){
    list.sort((a,b)=>a.seconds-b.seconds);
    for(let k=1;k<list.length;k++){
      const early=list[k-1],late=list[k];if(early.stroke===late.stroke)continue;
      const same=early.contact.action===late.contact.action;
      const need=same?early.grace?choices.graceReboundSeconds??DRUMMER.graceReboundSeconds:choices.reboundSeconds:margin(last.get(early.contact.action),'after')+margin(first.get(late.contact.action),'before');
      if(!bounds.has(early.stroke))bounds.set(early.stroke,[]);
      bounds.get(early.stroke).push({late,need,from:early.seconds});
    }
  }
  const at=new Map(contacts.filter(entry=>!entry.contact.of).map(entry=>[entry.stroke,entry.seconds])),out=new Map;
  for(const stroke of [...at.keys()].sort((a,b)=>at.get(b)-at.get(a))){
    let allowed=Math.max(0,Number(asked.get(stroke))||0);
    for(const {late,need,from} of bounds.get(stroke)??[])allowed=Math.min(allowed,Math.max(0,late.seconds+(out.get(late.stroke)??0)-from-need-2*TIME_GRAIN));
    out.set(stroke,allowed);
  }
  return out;
}
