// A singing voice: how long a phrase can run on one breath, and where the breaths go. The user, 27 September 2026:
// "Also - regarding constraints - we need one for singing, regarding phrase length and breathing." The general
// performer–instrument report's voice checklist (research/MUSEBOTS_GENERAL_PERFORMER_INSTRUMENT_CONSTRAINTS.md §6.4:
// phonation, breath actions, register, phrase duration) and its C04, planned through the contract's one solver
// (contract.js searchGroups), with no change to it.
//
// **A breath is an action** (C04): the breath store is declared breath credits (contract.js simulateStore, never
// physiology), drained while the voice sings and refilled only by a breath taken, which takes its time: in a rest, or
// from the end of the note before it, never from nothing. A rest alone refills nothing. **A voice is one sound source**:
// two of its notes at once violate (no software polyphony invents a second singer).
//
// **No number here is universal** (the report, §6.4 and its note on sources: "not a source of universal
// breathing-duration or articulation-rate limits"). A profile states its voice's own, each with its evidence: measured,
// inferred from the literature, or authored. The defaults (VOICE) are a starting profile, not a singer; a witness
// lists the checks that rest on inferred or authored numbers.
import {action,checkReservations,profile,searchGroups,simulateStore,STATUS,witness} from './contract.js';
import {instrumentRange} from './instrument-ranges.js';

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const VOICE=Object.freeze({
  // How long one breath lasts sung comfortably (mf, the middle of the voice), in seconds, by voice. Inferred: a sustained
  // vowel's maximum phonation time is 15-25 s for adult women and 25-35 s for men (Kent, Kent & Rosenbek 1987, "Maximum
  // performance tests of speech production", J. Speech Hear. Disord. 52), emptying the lungs; operatic singers phrase
  // from about 70-80% of vital capacity down to 30-50% (Thomasson & Sundberg 1997; 1999, J. Voice 13), about two fifths
  // of what a maximum phonation spends. Two fifths of those ranges: 6-10 s and 10-14 s; their middles here.
  phonationSeconds:Object.freeze({high:8,low:12}),
  // How far a phrase may run on into the reserve, as a share of a comfortable breath: demanding phrases go on down to
  // about 20% of vital capacity (Thomasson & Sundberg), some four sevenths again of the usual 35%. Inferred.
  reserve:.57,
  // How much faster a louder or a higher phrase spends its breath. Authored, to be measured for a singer: trained singers
  // vary loudness and airflow independently of each other (Sundberg's subglottal pressure studies), so no multiplier here
  // is anyone's but this profile's.
  dynamics:Object.freeze({ppp:.6,pp:.7,p:.8,mp:.9,mf:1,f:1.3,ff:1.6,fff:1.9}),
  registers:Object.freeze({low:1.1,middle:1,high:1.2}),
  // The breaths a singer takes: a full one between phrases (0.7 s, the mean inspiration of seven professional classical
  // singers singing: Salomoni, van den Hoorn & Hodges 2016, PLOS ONE 11(5), e0155084; measured), refilling to a
  // comfortable breath; a catch breath in a phrase, shorter and shallower (authored).
  breaths:Object.freeze({full:Object.freeze({seconds:.7,refill:1,evidence:'measured'}),catch:Object.freeze({seconds:.35,refill:.5,evidence:'authored'})}),
  // A breath may take at most this share of the note before it (authored).
  shortenShare:.5,
  // What a breath costs, by where it falls (authored): an action at all; in a rest nothing more; at a word's end a
  // little; inside a word more; inside a held vowel (a melisma) most; and a note shortened for it, by the share it loses.
  // Running on into the reserve costs by how deep.
  cost:Object.freeze({breath:.1,rest:0,word:1,syllable:4,melisma:8,unmarked:1,shorten:2,reserve:3}),
  // Velocity bands for a note with no dynamic stated (the lower edges of mp..ff).
  velocityDynamics:Object.freeze([[0,'pp'],[.25,'p'],[.4,'mp'],[.55,'mf'],[.7,'f'],[.85,'ff']]),
  // Air levels closer than this are one state (the solver keeps the cheapest path to each).
  airGrain:1e-3,
  maxStates:8192,
});

// A singer: one voice (a single sound source) and the breath. `voice` 'high' (sopranos, altos) or 'low' (tenors,
// basses) chooses the phonation time; `range` [low, high] in MIDI splits the voice's registers in thirds (by default
// the voice's register in the instrument registry, instrument-ranges.js 'voice-high' or 'voice-low'); `breath`
// overrides any of VOICE's numbers, `evidence` saying on what each rests.
export function singer({id='singer',performer='singer',voice='high',range=instrumentRange(voice==='low'?'voice-low':'voice-high').register,breath={},evidence=[]}={}){
  const who=profile({id,performer,resources:[{id:'voice',kind:'effector',capacity:1},{id:'breath',kind:'body',capacity:1}],
    evidence:[...evidence,'phonation time inferred (Kent, Kent & Rosenbek 1987; Thomasson & Sundberg 1997, 1999)',
      'full breath measured (Salomoni, van den Hoorn & Hodges 2016)','dynamics, registers, catch breath and costs authored']});
  if(!Array.isArray(range)||range.length!==2||!(range[0]<range[1]))throw new RangeError('a range is [low, high] in MIDI');
  const model={...VOICE,phonationSeconds:VOICE.phonationSeconds[voice]??VOICE.phonationSeconds.high,...breath,range:[...range]};
  if(!(model.phonationSeconds>0)||!(model.reserve>=0))throw new RangeError('a breath lasts a positive time, and its reserve is at least 0');
  return Object.freeze({...who,breath:Object.freeze(model)});
}

// ---- The phrase ------------------------------------------------------------------------------------------------------
const dynamicOf=(note,model)=>typeof note.dynamic==='string'&&model.dynamics[note.dynamic]!=null?note.dynamic
  :model.velocityDynamics.reduce((found,[edge,name])=>(note.velocity??.6)>=edge?name:found,'pp');
const registerOf=(pitch,[low,high])=>{const third=(high-low)/3;return pitch<low+third?'low':pitch>high-third?'high':'middle'};
// How much of a comfortable breath a second of this note spends.
export function drain(note,model){
  return model.dynamics[dynamicOf(note,model)]*model.registers[registerOf(note.pitch,model.range)]/model.phonationSeconds;
}
// Where a breath before `next` falls, as its cost names it: in a rest (time enough before the note), else at a word's
// end, inside a word, inside a held vowel, or between notes with no words.
function boundary(previous,next,gap,seconds){
  if(gap>=seconds-1e-9)return 'rest';
  const lyric=next.lyric;
  if(!lyric||!previous?.lyric)return 'unmarked';
  if(lyric.melisma||!String(lyric.text??'').trim())return 'melisma';
  const before=previous.lyric;
  return before.word===lyric.word&&before.continues!==false&&(before.syllable??0)<(before.syllables??1)-1?'syllable':'word';
}

// Plan a sung phrase's breaths: notes {id?, pitch, start, end (seconds), dynamic? (pp..ff) or velocity?, lyric?}, in
// time order. The singer starts with a comfortable breath (`initialAir` 1), or with what a shorter breath before the
// phrase gave it. {status, breaths, airLeft (what the phrase leaves, below 0 in its reserve), witness} or, with no plan, {status, note, reason, alternatives}: what would let it
// through, never a silent cut. `drainOf(note)` may stand in for the profile's drain (a check made before the pitches
// are known, at the costliest register).
export function planBreaths(input,{who=singer(),initialAir=1,drainOf=null}={}){
  const model=who.breath;
  if(!input.length)return {status:STATUS.witness,breaths:[],cost:0};
  const notes=input.map((note,index)=>{
    if(!Number.isFinite(note.start)||!(note.end>note.start)||!Number.isFinite(note.pitch))throw new RangeError('a note has a pitch and lasts a positive time');
    return {...note,id:note.id??`n${index}`};
  }).sort((a,b)=>a.start-b.start);
  if(!(initialAir>=0&&initialAir<=1))throw new RangeError('a phrase starts with at most a comfortable breath');
  const kinds=Object.entries(model.breaths),rateOf=drainOf??(note=>drain(note,model));
  const key=state=>`${Math.round(state.air/model.airGrain)}|${state.end}|${state.shortened??0}`;
  const expand=(note,state)=>{
    const rate=rateOf(note),need=rate*(note.end-note.start),moves=[];
    const previous=state.index>=0?notes[state.index]:null,gap=previous?note.start-previous.end:Infinity;
    const sing=(air,cost,step)=>{
      const after=air-need;
      if(after<-model.reserve-1e-9)return {status:'blocked'};
      return {status:'supported',cost:cost+(after<0?model.cost.reserve*(-after):0),state:{air:after,end:note.end,index:state.index+1},step};
    };
    // On without a breath (the first note starts on the singer's first breath).
    moves.push(sing(state.air,0,{note:note.id,breath:null}));
    // A breath before the note: in the rest before it, or with time taken from the note before (up to its share).
    if(previous)for(const [kind,breath] of kinds){
      const taken=Math.max(0,breath.seconds-Math.max(0,gap)),length=previous.end-previous.start;
      if(taken>length*model.shortenShare+1e-9){moves.push({status:'blocked'});continue}
      const where=boundary(previous,note,Math.max(0,gap),breath.seconds);
      // A note shortened spends less: its end's breath comes back before the breath is drawn.
      const air=Math.min(1,state.air+taken*rateOf(previous)+breath.refill);
      const at=note.start-breath.seconds;
      moves.push(sing(air,model.cost.breath+model.cost[where]+(taken?model.cost.shorten*taken/length:0),
        {note:note.id,breath:{kind,at,seconds:breath.seconds,where,shortens:taken?{note:previous.id,seconds:taken}:null}}));
    }
    return moves;
  };
  const found=searchGroups(notes,{initial:{air:initialAir,end:null,index:-1},expand,stateKey:key,maxStates:model.maxStates});
  if(found.status!==STATUS.witness){
    const note=found.group,rate=note?rateOf(note):null,seconds=note?note.end-note.start:null;
    const alternatives=[];
    if(note){
      if(rate*seconds>1+model.reserve)alternatives.push({kind:'shorter-note',note:note.id,reason:`the note lasts ${seconds.toFixed(2)} s; one breath lasts ${((1+model.reserve)/rate).toFixed(2)} s at its dynamic and register`});
      alternatives.push({kind:'softer',note:note.id,reason:'a softer dynamic spends the breath more slowly'});
      alternatives.push({kind:'longer-breath-window',note:note.id,reason:`a rest before it, or a note before it that may give up more than ${Math.round(model.shortenShare*100)}% of itself`});
      alternatives.push({kind:'second-singer',note:note.id,reason:'a second singer staggering the breath, as a choir does'});
    }
    return {status:found.status,note:note?.id??null,reason:note?`no breath plan carries the phrase through ${note.id} (at ${note.start.toFixed(2)} s)`:'the search stopped',alternatives};
  }
  const breaths=found.path.filter(step=>step.breath).map(step=>({before:step.note,...step.breath}));
  // (Its witness, the breath store run over its notes and breaths, made only where it is asked for: for development and
  // its tests, never while a singer sings.)
  return {status:STATUS.witness,breaths,cost:found.cost,airLeft:found.state.air,get witness(){return breathWitness(notes,breaths,who,{initialAir})}};
}

// The witness of a planned phrase: the voice's notes and breaths as the contract's actions (each note holds the voice;
// a breath holds the voice and the breath, so no note sounds while it is drawn), the breath store run over them, and
// what the model does not judge (tone, vibrato, the words' clarity).
export function breathWitness(notes,breaths,who=singer(),{initialAir=1}={}){
  const model=who.breath,shortened=new Map(breaths.filter(item=>item.shortens).map(item=>[item.shortens.note,item.shortens.seconds]));
  const ends=new Map(notes.map(note=>[note.id,note.end-(shortened.get(note.id)??0)]));
  const actions=[...notes.map(note=>action({id:`note:${note.id}`,contacts:[note.id],contactSeconds:[note.start],
      reservations:[{resource:'voice',phase:'hold',start:note.start,end:ends.get(note.id)}]})),
    ...breaths.map(item=>action({id:`breath:${item.before}`,technique:`${item.kind}-breath`,
      reservations:[{resource:'voice',phase:'recover',start:item.at,end:item.at+item.seconds},{resource:'breath',phase:'recover',start:item.at,end:item.at+item.seconds}]}))];
  // The store in credits: a comfortable breath and its reserve, drained by each note as sung, refilled by each breath.
  const commands=[...notes.map(note=>({kind:'consume',start:note.start,end:ends.get(note.id),rate:drain(note,model)})),
    ...breaths.map(item=>({kind:'refill',start:item.at,end:item.at+item.seconds,rate:model.breaths[item.kind].refill/item.seconds}))];
  // (Notes that overlap cannot be run as one voice's breath: the one-voice check says why.)
  let store;
  try{store=simulateStore({capacity:1+model.reserve,initial:initialAir+model.reserve},commands)}
  catch(error){if(!(error instanceof RangeError))throw error;store={status:STATUS.unknown,reason:'the voice\'s notes and breaths overlap'}}
  return witness({who,actions,checks:[
    {id:'one-voice',evidence:'authored',...checkReservations(who,actions)},
    {id:'breath',evidence:'inferred',status:store.status,reason:store.reason??null},
    {id:'breath-placement',evidence:'authored',status:STATUS.witness},
    {id:'tone-and-words',status:STATUS.unknown},
  ]});
}
