// Evidence for an instrument's and a performer's numbers: scoped, with its status, and never defaulted. The
// world-instruments report's phase A (§12.1: "Add the evidence schema, open-world statuses and configuration
// versioning. No numeric defaults should emerge from missing fields"), and its acceptance tests (§12.4):
//   4. "Missing numerical constraints return unknown, not infinity or zero."
//   6. "Unmeasured techniques can be registered without becoming certified."
//  14. "Tuning/configuration/preparation changes invalidate incompatible caches."
//  25. "Observed, inferred, simulated and digitally transformed data retain provenance."
// The contract (contract.js) keeps its own statuses for witnesses and envelopes; this is for the numbers the atlas and
// the instrument clodbots read from data (a range, a reach, a rate), which the atlas itself gives as unknown.
import {canonical} from './contract.js';
const keyOf=value=>JSON.stringify(canonical(value));

// The report's statuses (§12.1), in order of what they rest on. Measured and mechanism-derived values certify; authored
// and model-estimated ones are claims; simulated ones hold within their simulation; unknown is no value.
export const EVIDENCE_STATUSES=Object.freeze(['measured','mechanism-derived','authored','model-estimated','simulated','unknown']);
export const CERTIFYING=Object.freeze(['measured','mechanism-derived']);
const isNumber=value=>typeof value==='number'&&Number.isFinite(value);
const isInterval=value=>Array.isArray(value)&&value.length===2&&value.every(isNumber)&&value[0]<=value[1];

// A number, or an interval [low, high], with its status, unit, scope (where it holds: an instrument, a setup, a
// performer) and source (what it came from). A missing value is unknown whatever status is claimed for it: a claim
// without a number is not evidence of one.
export function assertion({value=null,unit=null,status,scope=null,source=null}={}){
  const known=value!==null&&value!==undefined;
  if(known&&!isNumber(value)&&!isInterval(value))throw new TypeError('An assertion\'s value is a finite number or an interval [low, high]');
  const said=known?(status??'authored'):'unknown';
  if(!EVIDENCE_STATUSES.includes(said))throw new TypeError(`An evidence status is one of ${EVIDENCE_STATUSES.join(', ')}, not ${said}`);
  if(known&&said==='unknown')throw new TypeError('A value is not unknown');
  return Object.freeze({value:known?(Array.isArray(value)?Object.freeze([...value]):value):null,unit,status:said,scope,source:source&&Object.freeze({...source}),
    known,certified:CERTIFYING.includes(said)});
}
export const unknown=({unit=null,scope=null,source=null}={})=>assertion({value:null,unit,scope,source});

// A number read from data: the field's value where it is there, with the data's status; unknown where it is not, and
// never 0, infinity, or a value another field would suggest.
export function fromField(record,field,{status,unit=null,scope=null,source=null}={}){
  const value=record?.[field];
  return value===undefined||value===null?unknown({unit,scope,source:source&&{...source,field}}):assertion({value,unit,status,scope,source:source&&{...source,field}});
}

// Whether a demand lies within what is asserted: 'within', 'outside' or 'unknown'. An unknown assertion answers unknown,
// and so does a demand in another unit or scope: a number is evidence where it was found, not a universal.
export function within(asserted,demand,{unit=asserted?.unit??null,scope=null}={}){
  if(!asserted?.known)return {answer:'unknown',reason:'no value asserted'};
  if(!isNumber(demand))return {answer:'unknown',reason:'no demand given'};
  if(asserted.unit!==unit)return {answer:'unknown',reason:`asserted in ${asserted.unit}, asked in ${unit}`};
  if(scope!==null&&keyOf(asserted.scope)!==keyOf(scope))return {answer:'unknown',reason:'asserted for another scope'};
  const [low,high]=Array.isArray(asserted.value)?asserted.value:[-Infinity,asserted.value];
  return demand>=low&&demand<=high?{answer:'within',status:asserted.status,certified:asserted.certified}
    :{answer:'outside',status:asserted.status,certified:asserted.certified,reason:`${demand} outside [${low}, ${high}]`};
}

// A value made from another (transposed, scaled, simulated, converted), keeping where it came from. A transformed
// measurement is no longer a measurement of this: it becomes what the operation makes it (model-estimated unless said).
export function derived(from,{value,op,status='model-estimated',unit=from?.unit??null,scope=from?.scope??null}={}){
  if(typeof op!=='string'||!op)throw new TypeError('A derivation names its operation');
  if(!from?.known)return unknown({unit,scope,source:{op,from:from??null}});
  return assertion({value,unit,status,scope,source:{op,from}});
}
// Every step a value came through, most recent first: each operation and the status it had.
export function provenance(asserted){
  const out=[];let at=asserted;
  while(at){out.push({status:at.status,...(at.source?.op?{op:at.source.op}:{}),...(at.source&&!at.source.op?{source:at.source}:{})});at=at.source?.from??null}
  return out;
}

// A technique registered for an instrument or a performer, with its evidence: registered whatever it rests on, certified
// only where it is measured or derived from the mechanism.
export function technique({id,status='unknown',scope=null,source=null}={}){
  if(typeof id!=='string'||!id)throw new TypeError('A technique has an id');
  if(!EVIDENCE_STATUSES.includes(status))throw new TypeError(`An evidence status is one of ${EVIDENCE_STATUSES.join(', ')}`);
  return Object.freeze({id,status,scope,source,registered:true,certified:CERTIFYING.includes(status)});
}

// ---- Configurations ---------------------------------------------------------------------------------------------------
// An instrument as it is set up: its tuning, its preparation (a prepared piano's objects, a capo, a mute), its setup
// (a kit's pieces, a harp's pedals). Its key is its content, so that any change of tuning or preparation is another
// configuration, and a result made under the old one is no longer valid for the new.
export function configuration({instrument,tuning=null,preparation=null,setup=null}={}){
  if(typeof instrument!=='string'||!instrument)throw new TypeError('A configuration names its instrument');
  const content={instrument,tuning,preparation,setup};
  return Object.freeze({...content,key:keyOf(content)});
}
// A result stamped with the configuration it was made under, and whether it still holds for another.
export const madeUnder=(result,config)=>Object.freeze({...result,madeUnder:config.key});
export const stillValid=(result,config)=>typeof result?.madeUnder==='string'&&result.madeUnder===config?.key;
