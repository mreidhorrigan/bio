// A fill as a phrase: its length, its grouping against the meter, and its cells, each a tuplet of its own, nested as
// deep as asked; the ordinary and the extreme made by one mechanism. The user, 28 September 2026: "Give the drumming
// model extensibility to extremes - extreme long fills, extreme arbitrary tuplets and nested tuplets; extreme grouping
// dissonance waay past 3-hemiola and its 5 equivalent; scenarious that won't be called upon often, but that it is
// capable of to suit upcoming situations"; and "Such extensibility also serves as an anti-hardcoding influence."
//
// A phrase is `slots` slots of a base grid over its span (exact: rationals of ticks, gestures.js), grouped:
//   - with the meter: the meter's own groups over the span (its felt beats, in slots), consonant;
//   - against it: groups of one size, the last whatever is left, so the grouping resolves where the phrase lands (the
//     resolve rule, metric-home/resolve.js: "don't 'repair' or 'omit' -- 'resolve'"; a remainder of one slot joins the
//     group before it): 3s over 4/4's sixteenths as 3+3+3+3+4, 5s as 5+5+6, 13s over two bars as 13+13+6;
//   - or in any sequence of sizes (an additive figure: 3+3+2, 5+7+4).
// Its cells are its groups, each played as a tuplet of its own count over the group's span (a group of three sixteenths
// may be five notes), any slot of which may itself be a tuplet, to any depth. Cells of one size repeat one figure, so the
// grouping is heard as one (a hemiola is heard because its cell repeats); a resolving cell has its own. Its accents are
// its groups' heads, and its loudness one course over the whole phrase.
//
// Nothing here is a special case: a group of 3 and one of 17, a triplet and a 31-tuplet nested three deep, a beat and
// sixteen bars are made the same way, their limits only those the caller gives (and the performer contract's, which the
// caller asks). How often each is chosen is the chooser's (choosePhrase): the ordinary by default, the extreme where a
// situation asks.
import {Rational} from '../../transcript/rational.js';

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const FILL_PHRASE=Object.freeze({
  // The most slots a phrase, a cell's tuplet, and a nesting's depth may reach, and the most contacts a phrase may expand
  // to, counted before any is placed (bounds on work, not on music: gestures.js holds a span to 4096 slots; RHY-002's
  // research query emitted at most 65,536).
  mostSlots:4096,mostDepth:8,mostContacts:65536,
  // A dissonant group is heard as one up to about this long (ours: as metric-home/nested.js hears a group, seconds).
  longestGroupSeconds:4,
  // The appetites a drummer brings to a fill of several beats (choosePhrase; ours, until listening says): ordinarily a
  // grouping against the meter now and then, a cell's own tuplet rarely, a nested one seldom; at the extremes (asked for
  // by a situation or a spec), each often, and fills up to sixteen bars.
  ordinary:Object.freeze({dissonance:.25,tuplets:.1,nesting:.05}),
  extremes:Object.freeze({dissonance:.9,tuplets:.5,nesting:.3,mostBars:16}),
});
const other=hand=>hand==='R'?'L':'R';
const positiveInteger=(value,name)=>{if(!Number.isSafeInteger(value)||value<1)throw new RangeError(`${name} is a whole number from 1, not ${value}`);return value};

// ---- Groupings -------------------------------------------------------------------------------------------------------
// Groups of `size` over `slots`, the last whatever is left (joined to the group before it where it is one slot, unless
// it is all there is).
export function groupsOf(slots,size){
  positiveInteger(slots,'A phrase\'s slots');positiveInteger(size,'A group');
  if(size>=slots)return [slots];
  const whole=Math.floor(slots/size),rest=slots-whole*size,groups=Array(whole).fill(size);
  if(rest===1)groups[groups.length-1]+=1;else if(rest)groups.push(rest);
  return groups;
}
// The boundaries inside a grouping (slot indices where a group begins, the first excepted).
const boundaries=groups=>{const out=[];let at=0;for(const group of groups.slice(0,-1)){at+=group;out.push(at)}return out};
// How far a grouping cuts across the meter's own groups: the share of its boundaries that fall inside a group of the
// meter's that it does not divide, one it neither fills with whole groups of its own nor lies inside one of (0: with the
// meter, at its level or a finer or coarser one, as 2s or 8s are over 4s; 1: every boundary across one).
export function dissonanceOf(groups,own){
  const inner=boundaries(groups);if(!inner.length)return 0;
  const starts=new Set([0,...inner,groups.reduce((a,b)=>a+b,0)]),spans=[];{let at=0;for(const group of own){spans.push([at,at+group]);at+=group}}
  const divided=([from,to])=>starts.has(from)&&starts.has(to)||[...starts].every(at=>at<=from||at>=to);
  const across=inner.filter(at=>spans.some(([from,to])=>at>from&&at<to&&!divided([from,to])));
  return across.length/inner.length;
}
// The groupings a phrase of `slots` may take against the meter's own groups over it (`own`, summing to `slots`): the
// meter's own, and groups of each size from 2 to `longest` slots (the resolve rule), each {groups, size, dissonance};
// sizes the meter's own groups already are, or that do not cut across them, are the meter's.
export function phraseGroupings(slots,{own,longest=slots}={}){
  positiveInteger(slots,'A phrase\'s slots');
  if(!Array.isArray(own)||own.reduce((a,b)=>a+b,0)!==slots)throw new RangeError('the meter\'s own groups fill the phrase');
  const out=[{groups:[...own],size:null,dissonance:0}];
  for(let size=2;size<=Math.min(longest,slots-1);size++){
    const groups=groupsOf(slots,size),dissonance=dissonanceOf(groups,own);
    if(dissonance>0)out.push({groups,size,dissonance});
  }
  return out;
}

// ---- Cells, tuplets and nesting ---------------------------------------------------------------------------------------
// A cell: its span in the phrase's slots, and its figure: `n` notes over that span (its tuplet), `rests` (indices of the
// n), and `nested`: {index: cell} where a note's own place is itself a tuplet (a cell whose span is that note's place).
// A note rested twice is rested; a rested note's own tuplet is not placed (the rest wins: a developed cell may rest a
// note that was nested, varyRests). One cell may stand in several places (choosePhrase gives every group of a size one
// cell), each its own contacts.
//
// Checked whole and counted exactly before any contact is placed (RHY-002, research/nested-phrase-index: the count of a
// cell is the sum over its struck notes of 1, or of its nested cell's count, each cell counted once however often it
// is placed): a count, a rest or a nested note outside its cell, a cell nested in itself, or a depth past the most,
// refused by name. So a small description of a huge expansion (nine levels of 32-tuplets, each nesting the next in
// every note: 2^45 contacts from nine cells) is counted, and refused, without being expanded.
export function cellCount(cell,{depth=0,counted=new Map,within=new Set}={}){
  if(counted.has(cell))return checkedDepth(cell,depth,counted);
  if(cell===null||typeof cell!=='object')throw new RangeError(`a cell is {n, rests, nested}, not ${cell}`);
  if(within.has(cell))throw new RangeError('a cell nested within itself');
  const n=positiveInteger(cell.n,'A cell\'s tuplet');
  if(n>FILL_PHRASE.mostSlots)throw new RangeError(`a tuplet of at most ${FILL_PHRASE.mostSlots}, not ${n}`);
  if(depth>FILL_PHRASE.mostDepth)throw new RangeError(`nested at most ${FILL_PHRASE.mostDepth} deep`);
  const note=(value,what)=>{const k=typeof value==='string'&&/^(0|[1-9]\d*)$/.test(value)?Number(value):value;
    if(!Number.isSafeInteger(k)||k<0||k>=n)throw new RangeError(`${what} ${value} is not one of its ${n} notes`);return k};
  const rests=new Set((cell.rests??[]).map(value=>note(value,'a rest')));
  within.add(cell);
  let contacts=0n,height=0;
  const nested=new Map(Object.entries(cell.nested??{}).map(([key,child])=>[note(key,'a nested note'),child]));
  for(let k=0;k<n;k++){
    if(rests.has(k))continue;
    const child=nested.get(k);
    if(!child){contacts+=1n;continue}
    contacts+=cellCount(child,{depth:depth+1,counted,within});height=Math.max(height,1+counted.get(child).height);
  }
  within.delete(cell);
  counted.set(cell,{contacts,height});
  return contacts;
}
// A cell met again: as many contacts as before, and as deep below it; placed deeper, still within the most depth.
function checkedDepth(cell,depth,counted){
  const {contacts,height}=counted.get(cell);
  if(depth+height>FILL_PHRASE.mostDepth)throw new RangeError(`nested at most ${FILL_PHRASE.mostDepth} deep`);
  return contacts;
}
// A phrase checked whole and its contacts counted (a BigInt), none placed: its slots, each group a whole number of them
// from 1, filling them, one cell a group, a span of positive length, and each cell as cellCount checks it.
export function phraseCount(phrase){
  const slots=positiveInteger(phrase.slots,'A phrase\'s slots');
  if(slots>FILL_PHRASE.mostSlots)throw new RangeError(`a phrase of at most ${FILL_PHRASE.mostSlots} slots, not ${slots}`);
  phrase.groups.forEach(group=>positiveInteger(group,'A group'));
  if(phrase.groups.reduce((a,b)=>a+b,0)!==slots)throw new RangeError('a phrase\'s groups fill its slots');
  if(phrase.cells.length!==phrase.groups.length)throw new RangeError('one cell a group');
  if(!(Rational.of(phrase.span).cmp(Rational.of(0))>0))throw new RangeError(`a phrase's span is longer than nothing, not ${phrase.span}`);
  const counted=new Map;
  return phrase.cells.reduce((sum,cell)=>sum+cellCount(cell,{counted}),0n);
}
const withinMost=count=>{if(count>BigInt(FILL_PHRASE.mostContacts))throw new RangeError(`a phrase of at most ${FILL_PHRASE.mostContacts} contacts, not ${count}`)};
// Compiled to contacts: [{at, duration (Rational ticks), path (indices from the phrase down), depth, cell}], rests left out.
// Checked and counted first (cellCount), a span of positive length; placed only within the most contacts. Every place is
// exact: a coordinate whose numerator or denominator would leave the safe integers is refused by Rational, never rounded.
export function cellContacts(cell,{start,span,depth=0,path=[],cellIndex=0}={}){
  if(!(Rational.of(span).cmp(Rational.of(0))>0))throw new RangeError(`a cell's span is longer than nothing, not ${span}`);
  withinMost(cellCount(cell,{depth}));
  return placeCell(cell,{start:Rational.of(start),span:Rational.of(span),depth,path,cellIndex});
}
function placeCell(cell,{start,span,depth,path,cellIndex}){
  const n=cell.n,rests=new Set((cell.rests??[]).map(Number)),out=[];
  for(let k=0;k<n;k++){
    if(rests.has(k))continue;
    const at=start.add(span.mul(new Rational(k,n))),child=cell.nested?.[k];
    if(child)out.push(...placeCell(child,{start:at,span:span.mul(new Rational(1,n)),depth:depth+1,path:[...path,k],cellIndex}));
    else out.push({at,duration:span.div(n),path:[...path,k],depth,cell:cellIndex});
  }
  return out;
}
// A phrase's contacts, in time: its groups laid over its span, each cell's contacts within its group's.
// phrase: {start, span (ticks), slots, groups, cells: [cell per group]}. Checked and counted first (phraseCount).
export function phraseContacts(phrase){
  withinMost(phraseCount(phrase));
  const slots=phrase.slots,start=Rational.of(phrase.start),span=Rational.of(phrase.span),slot=span.mul(new Rational(1,slots)),out=[];
  let at=0;
  phrase.groups.forEach((group,index)=>{
    out.push(...placeCell(phrase.cells[index],{start:start.add(slot.mul(Rational.of(at))),span:slot.mul(Rational.of(group)),depth:0,path:[index],cellIndex:index}));
    at+=group;
  });
  return out.sort((a,b)=>a.at.cmp(b.at));
}

// ---- Choosing a phrase -------------------------------------------------------------------------------------------------
// A phrase chosen for a fill: its grouping, and a cell for each group. What it asks:
//   - slots, own: the phrase's base slots and the meter's own groups over them;
//   - slotSeconds: one slot's length;
//   - dissonance (0 to 1): the appetite for a grouping against the meter; 0 always the meter's, 1 always against, and
//     the larger sizes the rarer by their length in seconds against the longest heard as one group;
//   - tuplets (0 to 1): the appetite for a cell whose notes are not its slots (a group of 3 played as 5): each cell's
//     count drawn from its size's neighbours, the further the rarer;
//   - nesting (0 to 1): the appetite for a note's place itself a tuplet, and how deep;
//   - figure(count, {size, seconds, index, rests}): the cell's figure where it is played (its rests, which fill-figures.js
//     draws unless `rests` are given, and its sticking), called once a size, so cells of a size repeat it;
//   - prefer, reuse: a grouping size to take where it is offered, and cells (by size) to develop: an earlier phrase's,
//     restated or with one note changed (varyRests), so a drummer's fills can be a series;
//   - fastest: the closest its notes may come (seconds; a performer's fastest motion: drummer.js motionSpacing), which
//     no tuplet or nested tuplet it draws, and no cell it develops, comes closer than; 0 for no bound;
//   - random.
// Returns {slots, groups, size, dissonance, cells, developed (the sizes whose cells were reused)}.
export function choosePhrase({slots,own,slotSeconds,dissonance=0,tuplets=0,nesting=0,longestGroupSeconds=FILL_PHRASE.longestGroupSeconds,
  figure=count=>({n:count,rests:[]}),prefer=null,reuse=null,fastest=0,random}={}){
  if(!(slotSeconds>0))throw new RangeError('a phrase needs its slot\'s length');
  const longest=Math.max(2,Math.floor(longestGroupSeconds/slotSeconds));
  const options=phraseGroupings(slots,{own,longest});
  const weight=option=>option.size===null?1-dissonance:dissonance*option.dissonance*(1-option.size*slotSeconds/(longestGroupSeconds+slotSeconds))/Math.max(1,options.length-1);
  const chosen=(prefer!==null&&options.find(option=>option.size===prefer))||(drawn(options,weight,random)??options[0]);
  // Each size's cell once: its count (its slots, or a neighbour as a tuplet over them), its figure, and its nesting; an
  // earlier phrase's cell of the size developed where one is given.
  const bySize=new Map,developed=new Set;
  const cellOf=(size,index)=>{
    if(!bySize.has(size)){
      // (A cell developed only where its notes are still no closer than `fastest`: the tempo may have risen since.)
      const given=reuse?.get?.(size)??null;
      if(given&&!(cellSpacing(given,size*slotSeconds)<fastest*(1-1e-9))){
        const cell={...figure(given.n,{size,seconds:size*slotSeconds,index,rests:varyRests(given,{random})}),n:given.n,...(given.nested?{nested:given.nested}:{})};
        bySize.set(size,cell);developed.add(size);
      }else{
        const count=tupletCount(size,{appetite:tuplets,random,seconds:size*slotSeconds,fastest});
        const cell={...figure(count,{size,seconds:size*slotSeconds,index}),n:count};
        bySize.set(size,nest(cell,{appetite:nesting,seconds:size*slotSeconds,random,...(fastest>0?{fastest}:{})}));
      }
    }
    return bySize.get(size);
  };
  const cells=chosen.groups.map((size,index)=>cellOf(size,index));
  return {slots,groups:[...chosen.groups],size:chosen.size,dissonance:chosen.dissonance,cells,developed:[...developed]};
}
// An earlier cell's rests developed: as they were half the time (a restatement), else with one note changed, struck
// where it rested or rested where it was struck (never its first, and never leaving fewer than two strokes).
export function varyRests(cell,{random}){
  const rests=new Set(cell.rests??[]);
  if(cell.n<3||random()<.5)return [...rests].sort((a,b)=>a-b);
  const k=1+Math.floor(random()*(cell.n-1));
  if(rests.has(k))rests.delete(k);else if(cell.n-rests.size-1>=2)rests.add(k);
  return [...rests].sort((a,b)=>a-b);
}
// A cell's count: its size, or, with the appetite's chance, one of its neighbours (a tuplet over its slots), the nearer
// the likelier (from size - size/2 to size + size, at least 2), none whose notes come closer than `fastest` over the
// cell's `seconds`.
export function tupletCount(size,{appetite=0,random,seconds=null,fastest=0}={}){
  if(!(appetite>0)||random()>=appetite)return size;
  const counts=[];for(let count=Math.max(2,Math.ceil(size/2));count<=size*2;count++)if(count!==size&&!(seconds/count<fastest*(1-1e-9)))counts.push(count);
  return drawn(counts,count=>1/Math.abs(count-size),random)??size;
}
// The closest two of a cell's notes come over its `seconds`: its places, and a nested tuplet's within its place.
export function cellSpacing(cell,seconds){
  const place=seconds/cell.n;
  return Math.min(place,...Object.values(cell.nested??{}).map(child=>cellSpacing(child,place)));
}
// A cell with one of its notes' places itself a tuplet, with the appetite's chance as far as its places have room (and
// that tuplet one of its own with half the appetite, and so on down): any count from 2 the place can hold at the tempo
// (its seconds over the count at least `fastest`, a thirtieth of a second unless a caller asks another: authored, the
// fastest a tuplet's notes are placed; what is playable is the performer's to say) -- no list of tuplets (the owner, 4
// October 2026, on never having seen an eleven: "Let nested fill tuplets ... use any count the notes' speed allows,
// weighted toward small counts") -- each as likely as a cell's own tuplet is near its size (tupletCount), the place's own
// count one: two the likeliest, an eleven a tenth as likely. Its room: how far its places are from holding no more than
// two at the fastest (1 - 2 fastest / place), so that a quick tuplet, an eleven or a twenty-nine over a short span, holds
// another seldom and a slow triplet often (the owner, 4 October 2026: "an 11- or 13- or 29-tuplet, et cetera, should be
// less likely to have other tuplets nested within it than a slower, simpler tuplet would").
export function nest(cell,{appetite=0,seconds,random,depth=0,fastest=1/30}={}){
  const place=seconds/cell.n,room=Math.max(0,1-2*fastest/place);
  if(!(appetite>0)||depth>=FILL_PHRASE.mostDepth||random()>=appetite*room)return cell;
  const struck=[...Array(cell.n).keys()].filter(k=>!(cell.rests??[]).includes(k)&&!cell.nested?.[k]);
  const most=Math.floor(place/fastest+1e-9),counts=Array.from({length:Math.max(0,most-1)},(_,k)=>k+2);
  if(!struck.length||!counts.length)return cell;
  const k=struck[Math.floor(random()*struck.length)],count=drawn(counts,count=>1/(count-1),random)??counts[0];
  return {...cell,nested:{...cell.nested,[k]:nest({n:count,rests:[]},{appetite:appetite/2,seconds:place,random,depth:depth+1,fastest})}};
}
// One of `items` drawn with `random`, each as likely as its weight (none where no weight is positive).
function drawn(items,weight,random){
  const weights=items.map(item=>Math.max(0,weight(item))),total=weights.reduce((a,b)=>a+b,0);
  if(!(total>0))return null;
  let u=random()*total;for(let i=0;i<items.length;i++){u-=weights[i];if(u<0)return items[i]}
  return items.at(-1);
}

// ---- Sticking and accents --------------------------------------------------------------------------------------------
// A phrase's contacts in alternating hands (singles) from `lead`, each its own action, each group's first stroke its
// head (accented): [{...contact, hand, action, head}].
export function phraseSingles(contacts,{lead='R'}={}){
  let hand=lead;const seen=new Set;
  return contacts.map((contact,k)=>{
    const head=!seen.has(contact.cell);seen.add(contact.cell);
    const out={...contact,hand,action:`stroke-${k}`,head};hand=other(hand);return out;
  });
}
