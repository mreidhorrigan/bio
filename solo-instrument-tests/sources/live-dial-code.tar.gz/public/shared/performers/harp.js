// A pedal harp: seven pedals, one a letter, each setting every string of its letter flat, natural or sharp. The general
// performer–instrument report's M3 counterexample (§6.3, C05): a shared instrument state that note-by-note checking
// misses. Two voices wanting C natural and C sharp at once cannot both have the C pedal, unless one is spelled D flat on
// the D pedal. A pedal cannot move while its strings sound, and each foot moves one pedal at a time. Planned through the
// performer contract's one solver (contract.js searchGroups), with no change to it: a spelling is searched like a finger.
import {action,checkReservations,profile,searchGroups,STATUS,witness} from './contract.js';
import {instrumentRange} from './instrument-ranges.js';

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const HARP=Object.freeze({
  // Each letter's natural pitch class, and the foot that works its pedal (the left D C B, the right E F G A).
  letters:Object.freeze({C:0,D:2,E:4,F:5,G:7,A:9,B:11}),
  feet:Object.freeze({D:'LF',C:'LF',B:'LF',E:'RF',F:'RF',G:'RF',A:'RF'}),
  settings:Object.freeze({flat:-1,natural:0,sharp:1}),
  // Authored: how long a foot takes to move one pedal (s).
  pedalSeconds:.25,
  together:.005,
  // Costs (authored): a pedal moved.
  cost:Object.freeze({pedalMove:1}),
  // The search's budget, and the cheapest states a group keeps past it (contract.js searchGroups: a whole performance's
  // notes, most of them with two spellings, reach more states than any group needs kept; a path found so is a witness,
  // marked pruned).
  maxStates:4096,beamStates:512,
});
const SETTING_NAMES=Object.keys(HARP.settings);

// A harpist: two feet, and the pedals as the instrument's mechanisms, each the parent of its letter's strings, so that
// notes on one letter in different settings are two configurations of one pedal at once (the contract's A04 check).
export function harpist({id='harpist',performer='harpist',unavailable=[],choices=HARP}={}){
  const resources=[{id:'LF',kind:'effector',availability:unavailable.includes('LF')?'unavailable':'available'},{id:'RF',kind:'effector',availability:unavailable.includes('RF')?'unavailable':'available'},
    ...Object.keys(choices.letters).flatMap(letter=>[{id:`pedal:${letter}`,kind:'mechanism'},{id:`strings:${letter}`,kind:'mechanism',capacity:HARP_BODY.strings,parents:[`pedal:${letter}`]}])];
  return profile({id,performer,resources});
}
// Every way to spell a pitch on a harp: [{letter, setting}] (C sharp is C sharp or D flat). `tuning`: its strings tuned
// for the piece (stringTuning), each letter's natural so many semitones from twelve-tone; a pitch between what its
// strings sound is on none.
export function spellings(pitch,{tuning={},choices=HARP}={}){
  if(!Number.isFinite(pitch))return [];
  const out=[];
  for(const [letter,natural] of Object.entries(choices.letters))for(const [setting,shift] of Object.entries(choices.settings)){
    const sounds=natural+(Number(tuning[letter])||0)+shift;
    if(Math.abs(((pitch-sounds)%12+18)%12-6)<=HARP_BODY.tolerance+1e-9)out.push({letter,setting});
  }
  return out;
}

// Plan a passage {pitch, start, end}: each note spelled on a letter and setting, the pedals moved between groups by
// their feet, never under a sounding string of their letter. {status, path?, witness?, reason?}.
export function planHarp(input,{who=harpist(),tuning={},choices=HARP}={}){
  if(!input.length)return {status:STATUS.witness,path:[],cost:0};
  const notes=input.map((note,index)=>({...note,id:note.id??`n${index}`})),groups=[];
  for(const note of notes)if(!spellings(note.pitch,{tuning,choices}).length)return {status:STATUS.unknown,reason:`pitch ${note.pitch} is on no string: a harp's strings sound the letters' three settings only`};
  for(const note of [...notes].sort((a,b)=>a.start-b.start||a.pitch-b.pitch)){const last=groups.at(-1);if(last&&note.start-last.at<=choices.together)last.notes.push(note);else groups.push({at:note.start,notes:[note]})}
  const letters=Object.keys(choices.letters);
  const stateKey=state=>JSON.stringify([letters.map(letter=>state.pedals[letter]),state.sounding.map(item=>`${item.letter}:${item.end}`),state.feet,state.quiet]);
  const expand=(group,state)=>{
    const sounding=state.sounding.filter(item=>item.end>group.at+choices.together),moves=[];
    const spell=(index,chosen)=>{
      if(index===group.notes.length){moves.push(chosen);return}
      for(const option of spellings(group.notes[index].pitch,{tuning,choices}))spell(index+1,[...chosen,{note:group.notes[index],...option}]);
    };
    const out=[];spell(0,[]);
    for(const chosen of moves){
      // One letter, one setting, among the group's notes and those still sounding (C05).
      const wanted={};let clash=false;
      for(const item of [...chosen,...sounding]){if(wanted[item.letter]&&wanted[item.letter]!==item.setting)clash=true;wanted[item.letter]=item.setting}
      if(clash){out.push({status:'blocked'});continue}
      // Pedals to move, each by its foot, once that foot is free and the letter's strings have fallen quiet (a pedal
      // moved under a sounding string would bend it), in time for the group. A pedal first set before the piece is free.
      const changes=Object.entries(wanted).filter(([letter,setting])=>state.pedals[letter]!==setting);
      if(changes.some(([letter])=>sounding.some(item=>item.letter===letter))){out.push({status:'blocked'});continue}
      const feet={...state.feet};let ok=true;
      for(const [letter] of changes){
        const foot=choices.feet[letter];if(who.resources.get(foot)?.availability!=='available'){ok=false;break}
        const from=Math.max(feet[foot]??-Infinity,state.quiet[letter]??-Infinity),done=(Number.isFinite(from)?from:group.at-choices.pedalSeconds)+choices.pedalSeconds;
        if(done>group.at+1e-9){ok=false;break}
        feet[foot]=done;
      }
      if(!ok){out.push({status:'blocked'});continue}
      const quiet={...state.quiet};for(const item of chosen)quiet[item.letter]=Math.max(quiet[item.letter]??-Infinity,item.note.end);
      out.push({status:'supported',cost:changes.length*choices.cost.pedalMove,
        state:{pedals:{...state.pedals,...wanted},feet,quiet,sounding:[...sounding,...chosen.map(item=>({letter:item.letter,setting:item.setting,end:item.note.end,note:item.note.id}))]},
        step:{at:group.at,moves:changes.map(([letter,setting])=>({letter,setting,foot:choices.feet[letter]})),notes:chosen.map(item=>({note:item.note.id,pitch:item.note.pitch,letter:item.letter,setting:item.setting}))}});
    }
    return out;
  };
  const initial={pedals:Object.fromEntries(letters.map(letter=>[letter,'natural'])),feet:{},quiet:{},sounding:[]};
  const found=searchGroups(groups,{initial,expand,stateKey,maxStates:choices.maxStates,beam:choices.beamStates??null});
  if(found.status!==STATUS.witness)return {status:found.status,reason:`no spelling and pedalling sounds the group at ${found.group.at} s (${found.group.notes.map(note=>note.pitch).join(', ')})`};
  const byId=new Map(notes.map(note=>[note.id,note])),actions=[];
  for(const step of found.path){
    for(const move of step.moves)actions.push(action({id:`pedal:${move.letter}@${step.at}`,technique:'pedal-change',reservations:[{resource:move.foot,phase:'transfer',start:step.at-choices.pedalSeconds,end:step.at}]}));
    for(const item of step.notes){const note=byId.get(item.note);actions.push(action({id:`note:${item.note}`,contacts:[item.note],contactSeconds:[note.start],
      reservations:[{resource:`strings:${item.letter}`,phase:'hold',start:note.start,end:note.end,configuration:`${item.letter}:${item.setting}`}]}))}
  }
  return {status:STATUS.witness,path:found.path,cost:found.cost,
    witness:witness({who,actions,checks:[{id:'pedals-and-feet',evidence:'authored',...checkReservations(who,actions)},{id:'buzz-and-resonance',status:STATUS.unknown}]})};
}

// ---- The harpist's hands over its strings (harp_clodbot's; the family atlas's F14) -----------------------------------
// The concert pedal harp's strings, seven to the octave, each at its letter's pedal (above); two hands of four fingers
// (a harpist does not pluck with the little finger), each over a span of strings, the left's below the right's. The
// atlas: "No universal seven-pedal or per-string semitone assumption; harp-lute/lyre interfaces differ": this is the
// concert pedal harp's body, and another harp (a lever harp: a lever each string, set by a hand) is a body of its own.
// Its strings are tuned for the piece before it (stringTuning: 2a's suggestion), each letter's natural at the band's
// pitch nearest it, so a pool's pitches between the keys are strings' own; the pedals move each a semitone from there.
export const HARP_BODY=Object.freeze({
  // Its strings: C1 to G7, 47 of them (a typical concert harp's: the instrument registry's, instrument-ranges.js).
  lowest:instrumentRange('harp').lowest,strings:instrumentRange('harp').strings,
  // Between two strings' centres (mm; authored: about 14 at the middle of a concert harp's neck).
  stringMm:14,
  // A hand: four fingers, its thumb and fourth finger at most spanStrings strings apart (a tenth's nine steps), two
  // neighbouring fingers at most fingerStrings (a fifth's four; both authored).
  fingers:4,spanStrings:9,fingerStrings:4,
  // How fast a hand crosses the strings (mm a second), the shortest time between two notes of one hand (s: about
  // sixteen a second), and a rolled chord's spread from one string to the next (s; all authored).
  handMmPerSecond:2000,noteSeconds:1/16,rollSeconds:.03,
  // A pitch is a string's within this (semitones).
  tolerance:.05,
});
const LETTER_ORDER=Object.freeze(['C','D','E','F','G','A','B']);
const near=(a,b,tolerance=HARP_BODY.tolerance)=>Math.abs(((a-b)%12+18)%12-6)<=tolerance+1e-9;

// Its strings, low to high: {index, letter, octave, natural (MIDI, fractional: its letter's natural with the piece's
// tuning, `tuning[letter]` semitones from twelve-tone), x (mm)}.
export function harpStrings({tuning={},body=HARP_BODY,choices=HARP}={}){
  const start=LETTER_ORDER.indexOf(body.lowest.letter);
  return Array.from({length:body.strings},(_,index)=>{
    const step=start+index,letter=LETTER_ORDER[step%7],octave=body.lowest.octave+Math.floor(step/7);
    return Object.freeze({index,letter,octave,natural:12*(octave+1)+choices.letters[letter]+(Number(tuning[letter])||0),x:index*body.stringMm});
  });
}
// A string's pitch at a pedal setting.
export const stringPitch=(string,setting,choices=HARP)=>string.natural+choices.settings[setting];
// The strings tuned for a piece: each letter's natural moved to the band's pitch class nearest it, within half a
// semitone (a pitch halfway between two letters goes to the lower's); then each letter left as it was, where a class of
// the band's no string sounds yet, moved so that its flat or sharp sounds it (F tuned up 0.31 sounds F sharp and 0.31,
// a neutral collection's); none where the band's are twelve-tone. -> {letter: semitones}.
export function stringTuning(pool,{choices=HARP}={}){
  const letters=Object.entries(choices.letters),{natural:_,...pedalled}=choices.settings,moved=new Map,pcs=(pool??[]).map(Number);
  const nearest=(natural,shifts,classes)=>{let best=null;for(const pc of classes)for(const shift of shifts){const d=((pc-natural-shift)%12+18)%12-6;if(Math.abs(d)<=.5+1e-9&&(best===null||Math.abs(d)<Math.abs(best)-1e-9||Math.abs(Math.abs(d)-Math.abs(best))<1e-9&&d>best))best=d}return best};
  for(const [letter,natural] of letters){const d=nearest(natural,[0],pcs);if(d!==null)moved.set(letter,d)}
  const sounded=pc=>letters.some(([letter,natural])=>Object.values(choices.settings).some(shift=>near(natural+(moved.get(letter)??0)+shift,pc)));
  for(const [letter,natural] of letters){if(moved.has(letter))continue;const d=nearest(natural,Object.values(pedalled),pcs.filter(pc=>!sounded(pc)));if(d!==null)moved.set(letter,d)}
  const out={};for(const [letter] of letters){const d=moved.get(letter);if(d!==undefined&&Math.abs(d)>1e-9)out[letter]=+d.toFixed(4)}
  return out;
}
// The pedals a collection asks (its pitch classes, in the piece's tuning): each letter at the setting that sounds one of
// them, natural first; natural where none does. -> {letter: setting}.
export function pedalsFor(collection,{tuning={},choices=HARP}={}){
  const pedals={};
  for(const [letter,natural] of Object.entries(choices.letters)){
    const base=natural+(Number(tuning[letter])||0);
    pedals[letter]=['natural','flat','sharp'].find(setting=>(collection??[]).some(pc=>near(base+choices.settings[setting],Number(pc))))??'natural';
  }
  return pedals;
}

// The voicings two hands can pluck for a chord's pitch classes `pcs`, each holding every `required` one: each note a
// string within `reach` semitones of `centre`, at its letter's pedal (`pedals`), or at another setting where its letter
// is `free` (a pedal the feet can set in time; each such letter a change); one setting a letter, across its strings. Up
// to four notes a hand, its thumb and fourth finger within spanStrings, neighbouring fingers within fingerStrings; the
// left's strings below the right's. `size` notes (the chord's tones, and one doubled where it has fewer than five), each
// class at most twice. -> [{notes: [{string, letter, setting, pitch}], pitches, hands: {LH, RH} (pitches), x: {LH, RH} (mm, a
// hand's middle), changes: {letter: setting}}].
export function harpVoicings(pcs,required=[],{strings=harpStrings(),pedals={},free=[],centre=60,reach=14,size=null,body=HARP_BODY,choices=HARP}={}){
  const tones=[...new Set(pcs.map(Number))],needed=[...new Set(required.map(Number))];
  const want=Math.max(1,Math.min(2*body.fingers,size??Math.min(6,tones.length+(tones.length<5?1:0))));
  // Each string that can sound a tone: at its pedal's setting, or another where its letter is free.
  const candidates=[];
  for(const string of strings){
    if(string.natural<centre-reach-1.5||string.natural>centre+reach+1.5)continue;
    const settings=free.includes(string.letter)?Object.keys(choices.settings):[pedals[string.letter]??'natural'];
    for(const setting of settings){
      const pitch=stringPitch(string,setting,choices);if(pitch<centre-reach-1e-9||pitch>centre+reach+1e-9)continue;
      const tone=tones.find(pc=>near(pitch,pc,body.tolerance));if(tone!==undefined)candidates.push({string,letter:string.letter,setting,pitch,tone});
    }
  }
  candidates.sort((a,b)=>a.string.index-b.string.index||a.pitch-b.pitch);
  const sounding=tones.filter(pc=>candidates.some(candidate=>candidate.tone===pc)),size_=Math.min(want,2*sounding.length),out=[];
  // (None where no string sounds any of its tones: a voicing of no notes had been the cheapest, its middle no number,
  // and the harp silent through a reading whose tones lay between its strings' -- a punctuation's hit unstruck.)
  if(!size_)return out;
  const handOk=list=>list.length<=body.fingers&&(list.length<2||list.at(-1).string.index-list[0].string.index<=body.spanStrings)
    &&list.every((note,k)=>k===0||note.string.index-list[k-1].string.index<=body.fingerStrings);
  const walk=(start,chosen,settings)=>{
    if(chosen.length===size_){
      if(!needed.every(pc=>chosen.some(note=>near(note.tone,pc,body.tolerance))))return;
      if(new Set(chosen.map(note=>note.tone)).size<Math.min(size_,sounding.length))return;
      // The hands: the left's the lower notes, the right's the rest, each a hand's reach, the right's above the left's.
      for(let split=Math.max(0,size_-body.fingers);split<=Math.min(body.fingers,size_);split++){
        const left=chosen.slice(0,split),right=chosen.slice(split);
        if(!handOk(left)||!handOk(right))continue;
        const middle=list=>list.length?(list[0].string.x+list.at(-1).string.x)/2:null;
        const changes=Object.fromEntries(Object.entries(settings).filter(([letter,setting])=>(pedals[letter]??'natural')!==setting));
        out.push({notes:chosen.map(({string,letter,setting,pitch})=>({string:string.index,letter,setting,pitch})),pitches:chosen.map(note=>note.pitch),
          hands:{LH:left.map(note=>note.pitch),RH:right.map(note=>note.pitch)},x:{LH:middle(left),RH:middle(right)},changes});
        return;
      }
      return;
    }
    for(let k=start;k<candidates.length;k++){
      const candidate=candidates[k],last=chosen.at(-1);
      if(last&&(candidate.string.index<=last.string.index||candidate.pitch<=last.pitch+1e-9))continue;
      if(settings[candidate.letter]&&settings[candidate.letter]!==candidate.setting)continue;
      if(chosen.filter(note=>note.tone===candidate.tone).length>=2)continue;
      walk(k+1,[...chosen,candidate],{...settings,[candidate.letter]:candidate.setting});
    }
  };
  walk(0,[],{});
  return out;
}
// What a harp voicing costs (ours): each semitone its voices move from the last's, each 100 mm its hands travel, each
// semitone its middle lies from the centre, each pedal it changes (a foot's move, and the strings it retunes for what
// follows), and each semitone it spreads wider than two octaves.
export const HARP_VOICING_COST=Object.freeze({voice:1,travel:.5,register:.25,pedal:3,spread:.5});
// The voicing to pluck next: the least costly (HARP_VOICING_COST) from the last, its chord reading's cost to its player
// added where it was voiced from one (chord-readings.js).
export function nextHarpVoicing(voicings,previous=null,{centre=60,cost=HARP_VOICING_COST}={}){
  const middle=pitches=>(Math.min(...pitches)+Math.max(...pitches))/2;
  const moved=voicing=>{if(!previous)return 0;const a=previous.pitches,b=voicing.pitches,n=Math.min(a.length,b.length);let sum=0;for(let k=0;k<n;k++)sum+=Math.abs(a[a.length-1-k]-b[b.length-1-k]);return sum};
  const travel=voicing=>previous?['LH','RH'].reduce((sum,hand)=>sum+(previous.x[hand]!=null&&voicing.x[hand]!=null?Math.abs(voicing.x[hand]-previous.x[hand]):0),0)/100:0;
  const spread=voicing=>Math.max(0,Math.max(...voicing.pitches)-Math.min(...voicing.pitches)-24);
  const of=voicing=>cost.voice*moved(voicing)+cost.travel*travel(voicing)+cost.register*Math.abs(middle(voicing.pitches)-centre)
    +cost.pedal*Object.keys(voicing.changes??{}).length+cost.spread*spread(voicing)+(voicing.readingCost??0);
  return voicings.reduce((best,voicing)=>!best||of(voicing)<of(best)-1e-9?voicing:best,null);
}
