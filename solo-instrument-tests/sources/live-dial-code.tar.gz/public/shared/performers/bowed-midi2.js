// A bowed string's strokes as MIDI 2.0: what its player plays, as any strings synth takes it (docs/MIDI2_SYNTH_INPUT.md; the
// owner, 17 October 2026: "Musebots don't produce bow strokes. They produce MIDI 2.0"). Each stroke one note -- a change
// of bow is a new note, a tremolo's each stroke one -- its Per-Note Management first, so its controllers are its own.
// The engine (public/audio.js) writes its bowed string's notes so; a strings synth reads them back (BowedDecoder): the
// bridge's live player (render/node/strings-stream.mjs) and a render's (render/node/physical-strings.mjs) alike, each
// compiling them for Artifastring (physical-strings.js compileActions). Another strings synth -- a sampler, a VST3,
// another model -- reads the standard ones as they say.
//
// Standard first: the note's pitch (Pitch 7.9), its dynamic (16-bit velocity), its end (Note Off: the earliest sent for
// it), its attack time (#73), its level through it (#11 Expression), its finger's path (Per-Note Pitch Bend: vibrato and
// glides) and its bow's pressure (Per-Note Pressure). Its technique, its bow (a new bow, a slur, a change), its contact
// point and its string are named by the Orchestral Articulation Profile (M2-123-UM: articulations, playing direction,
// string number, Playing Position); until its codes are read from the profile, they are Assignable Per-Note Controllers
// of ours, here alone, as are the harmonic's partial and node, the multiphonic, the resting bow and its articulation's
// point -- its bite, weight, noise and decay (bowed-articulation.js) -- which no standard names.
import {noteOn,noteOff,perNoteBend,perNotePressure,perNoteController,assignablePerNoteController,perNoteManagement,
  bend32,bendSemitones,inspectUMP} from '../ump.js';
import {timeToBipolar,bipolarToTime,bipolar32,bipolarFrom32,unit32} from '../articulation.js';
import {articulationOfStroke} from './bowed-articulation.js';

// Each parameter: its message, its index (a controller's), how its value is written. `reference`: a time's, the centre
// of its log scale (articulation.js timeToBipolar), as the receiving patch's own -- a bowed attack's MODEL.attack.
export const BOWED_MIDI2=Object.freeze({
  pitch:{message:'noteOn',attribute:3,encoding:'Pitch 7.9: semitones, 1/512 of one'},
  velocity:{message:'noteOn',encoding:'16-bit: the line\'s velocity (line.js), 0 to 1'},
  end:{message:'noteOff',encoding:'its time; the earliest sent for a note is its end'},
  attack:{message:'perNoteController',index:73,registered:true,reference:.07,encoding:'bipolar time: octaves from the reference over 4'},
  level:{message:'perNoteController',index:11,registered:true,encoding:'unit: the line\'s velocity through the note, points joined by lines'},
  bend:{message:'perNoteBend',encoding:'semitones from the note at its time (its bend range the channel\'s, RPN 0/7), points joined by lines'},
  pressure:{message:'perNotePressure',encoding:'bipolar: -1 flautando, 0 ordinary (not sent), 1 overpressure'},
  // (Assignable Per-Note Controllers of ours, until the profile's are read.)
  technique:{message:'assignablePerNoteController',index:16,values:['arco','pizzicato'],profile:'articulation'},
  bow:{message:'assignablePerNoteController',index:17,values:['begin','slur','change','held'],profile:'playing direction, legato'},
  tremolo:{message:'assignablePerNoteController',index:18,values:[false,true],profile:'articulation'},
  position:{message:'assignablePerNoteController',index:19,encoding:'bipolar: -1 at the bridge, 0 ordinario, 1 over the fingerboard',profile:'Playing Position'},
  string:{message:'assignablePerNoteController',index:20,encoding:'its string, lowest 0, plus 1 (0: the player\'s choice)',profile:'string number'},
  partial:{message:'assignablePerNoteController',index:21,encoding:'a natural harmonic\'s partial (0: none)',profile:'articulation'},
  node:{message:'assignablePerNoteController',index:22,encoding:'the node it touches, of its partial\'s'},
  multiphonic:{message:'assignablePerNoteController',index:23,encoding:'its measured multiphonic\'s index plus 1 (0: none)'},
  rest:{message:'assignablePerNoteController',index:24,reference:.1,encoding:'bipolar time: the bow left on the string so long at its end'},
  bite:{message:'assignablePerNoteController',index:25,reference:.05,encoding:'bipolar time: the bow set on the string and stopped so long before it is drawn (a change of bow\'s, or any stroke\'s grip)'},
  // (Its articulation's point, bowed-articulation.js: said whole -- its weight and noise, each 0 too, and its decay where
  // it has one -- or not at all, the synth's own attack then.)
  weight:{message:'assignablePerNoteController',index:26,encoding:'unit: its onset\'s accent, a share of bowed-articulation.js ACCENT_DB'},
  noise:{message:'assignablePerNoteController',index:27,encoding:'unit: its start\'s pre-Helmholtz transient, a share of bowed-articulation.js NOISE_PERIODS'},
  decay:{message:'assignablePerNoteController',index:28,reference:.1,encoding:'bipolar time: its accent eased back to the held tone over so long (not sent: none)'},
});
const T=BOWED_MIDI2,BOWS=T.bow.values;
// The per-note bend range (semitones) a bowed string's notes are written with: its channel's (RPN 0/7, ump.js
// perNoteBendRange), as every engine's are.
export const BOWED_BEND_RANGE=48;

// A stroke's bow: begun, slurred from the note before, or a change of bow into it -- at a new note, or on one held.
const bowOf=stroke=>stroke?.into==null&&stroke?.change!==true?0:stroke?.captured===false?3:stroke?.change===true?2:1;
// Its finger's path, as bend points from its time: a glide from its first pitch (held to glideAt) to its own, else its
// vibrato's curve (pitch ratios a step apart). -> [[seconds, semitones], ...] or null.
export function bendOf(g){
  if(g.glide>0&&Number.isFinite(g.glideFrom)){const from=g.glideFrom-g.note,held=Number(g.glideAt)>0?Number(g.glideAt):0;
    return [[0,from],...(held?[[held,from]]:[]),[held+g.glide,0]]}
  const curve=g.stroke?.vibrato?.curve,step=g.stroke?.vibrato?.step;
  return curve?.length&&step>0?Array.from(curve,(ratio,k)=>[k*step,12*Math.log2(ratio||1)]):null;
}

// The note numbers a player's strokes take: its pitch's nearest (a synth that reads no Pitch 7.9 then plays near it), one
// whose last note is over -- past its planned end, never reused before it, so that a Note Off is always its own note's --
// and never the one its last stroke took, so that a repeated pitch's strokes are told apart.
export class BowedIdentities{
  constructor(){this.ends=new Map;this.last=null}
  take(pitch,at,end){
    const home=Math.max(0,Math.min(127,Math.round(pitch)));
    for(let d=0;d<128;d++)for(const note of d?[home+d,home-d]:[home]){
      if(note<0||note>127||note===this.last||(this.ends.get(note)??-Infinity)>=at)continue;
      this.ends.set(note,end);this.last=note;return note;
    }
    // (Every number sounding: the one due to end first, as the engine's own notes do -- audio.js captureUMP.)
    const note=[...this.ends].reduce((a,b)=>b[1]<a[1]?b:a)[0];this.ends.set(note,end);this.last=note;return note;
  }
}

// One stroke (audio.js physicalStroke's: {at, note, seconds, velocity, articulation, harmonic, multiphonic, contact,
// bowPressure, string, stroke: {into, change, captured, tremolo, attack, rest, bite, weight, noise, decay, vibrato,
// dynamics}, glide, glideFrom, glideAt}) as its note. -> [{time, packet}], each time in seconds from the stroke's.
export function bowedEvents(g,{group=0,channel=0,note}={}){
  const id={group,channel,note},events=[],at=(time,packet)=>events.push({time,packet:Array.from(packet)});
  const assign=(name,value)=>at(0,assignablePerNoteController({...id,index:T[name].index,value}));
  at(0,perNoteManagement(id));
  if(g.articulation==='pizzicato')assign('technique',1);
  const bow=bowOf(g.stroke);if(bow)assign('bow',bow);
  if(g.stroke?.tremolo===true)assign('tremolo',1);
  if(Number(g.contact))assign('position',bipolar32(Math.max(-1,Math.min(1,Number(g.contact)))));
  const string=g.harmonic?.string??g.string;if(Number.isInteger(string))assign('string',string+1);
  if(g.harmonic){assign('partial',g.harmonic.partial??2);assign('node',g.harmonic.node??1)}
  if(g.multiphonic)assign('multiphonic',Number(g.multiphonic.index)+1);
  if(Number(g.stroke?.rest)>0)assign('rest',bipolar32(timeToBipolar(Number(g.stroke.rest),T.rest.reference)));
  if(Number(g.stroke?.bite)>0)assign('bite',bipolar32(timeToBipolar(Number(g.stroke.bite),T.bite.reference)));
  const point=articulationOfStroke(g.stroke);
  if(point){assign('weight',unit32(point.weight));assign('noise',unit32(point.noise));if(point.decay>0)assign('decay',bipolar32(timeToBipolar(point.decay,T.decay.reference)))}
  if(Number(g.stroke?.attack)>0)at(0,perNoteController({...id,index:T.attack.index,value:bipolar32(timeToBipolar(Number(g.stroke.attack),T.attack.reference))}));
  if(Number(g.bowPressure))at(0,perNotePressure({...id,value:bipolar32(Math.max(-1,Math.min(1,Number(g.bowPressure))))}));
  const bend=bendOf(g);
  // (Its bend at its start before it sounds, so its first pitch is its own.)
  if(bend)at(0,perNoteBend({...id,value:bend32(bend[0][1],BOWED_BEND_RANGE)}));
  at(0,noteOn({...id,pitch:g.note,attribute:3,velocity:Math.round(Math.max(0,Math.min(1,g.velocity??0))*65535)}));
  if(bend)for(const [time,semitones] of bend.slice(1))at(time,perNoteBend({...id,value:bend32(semitones,BOWED_BEND_RANGE)}));
  const level=g.stroke?.dynamics;
  if(level?.curve?.length&&level.step>0)Array.from(level.curve).forEach((value,k)=>at(k*level.step,perNoteController({...id,index:T.level.index,value:unit32(value)})));
  at(g.seconds,noteOff({...id}));
  return events;
}

// A strings synth's reading of its notes: each Note On a stroke, with what came for its note since its Per-Note
// Management, and what comes for it after (its curves, an earlier Note Off). take(events) -- each {seconds, packet},
// its time the stream's -- -> the strokes it touched, each whole as the compiler takes them (physical-strings.js):
// {id, at, note, seconds, velocity, ...}; its curves as `bend` points and a `stroke.dynamics` curve every `step` s.
export class BowedDecoder{
  constructor({step=.02}={}){this.step=step;this.next=1;this.notes=new Map;this.pending=new Map;this.ranges=new Map}
  take(events){
    const touched=new Map;
    for(const {seconds,packet} of [...events].sort((a,b)=>a.seconds-b.seconds)){
      const m=inspectUMP(packet),key=m.key;
      if(m.kind==='registeredController'&&m.note===0&&m.attribute===7){this.ranges.set(`${m.group}:${m.channel}`,m.data/0x2000000);continue}
      if(!key)continue;
      // (Per-Note Management detaches the note its number held: what follows is the next note's, until its Note On. A
      // number is never taken again before its last note's planned end -- BowedIdentities -- so none of that note's is to come.)
      if(m.kind==='perNoteManagement'||m.type===4&&m.statusNibble===15){this.notes.delete(key);this.pending.set(key,{controls:{},bend:[]});continue}
      const range=this.ranges.get(`${m.group}:${m.channel}`)??BOWED_BEND_RANGE;
      if(m.kind==='noteOn'){
        const before=this.pending.get(key)??{controls:{},bend:[]};this.pending.delete(key);
        const stroke={id:this.next++,at:seconds,note:m.pitch,seconds:Infinity,velocity:m.velocity/65535,controls:before.controls,bend:before.bend.map(([,v])=>[0,v]),level:[]};
        this.notes.set(key,stroke);touched.set(stroke.id,stroke);continue;
      }
      const stroke=this.notes.get(key),control=m.kind==='perNoteController'||m.kind==='assignablePerNoteController'||m.kind==='perNotePressure'
        ?m.kind==='perNotePressure'?'pressure':`${m.kind==='perNoteController'?'r':'a'}${m.attribute}`:null;
      if(m.kind==='noteOff'){if(stroke){stroke.seconds=Math.min(stroke.seconds,seconds-stroke.at);touched.set(stroke.id,stroke)}continue}
      // (A controller is a stroke's as it stood at its Note On -- its bow, string, contact, technique, attack -- but its
      // level, a curve through it; one sent after its Note Off is its key's next stroke's, as after Per-Note Management,
      // the state that stroke begins in. So a stream that detaches no note, as an editor writes a key's controllers, lanes
      // through its notes, gives no stroke another's.)
      const level=control===`r${T.level.index}`;
      if(control&&stroke&&!level){
        if(seconds-stroke.at>=stroke.seconds)(this.pending.get(key)??this.pending.set(key,{controls:{},bend:[]}).get(key)).controls[control]=m.data;
        continue;
      }
      const target=stroke??(this.pending.get(key)??this.pending.set(key,{controls:{},bend:[]}).get(key)),time=stroke?seconds-stroke.at:0;
      if(m.kind==='perNoteBend')target.bend.push([time,bendSemitones(m.data,range)]);
      else if(level&&stroke)stroke.level.push([time,m.data/0xffffffff]);
      else if(control)target.controls[control]=m.data;
      if(stroke)touched.set(stroke.id,stroke);
    }
    return [...touched.values()].map(stroke=>this.strokeOf(stroke));
  }
  // (A note as the compiler takes a stroke.)
  strokeOf(s){
    const c=s.controls,a=name=>c[`a${T[name].index}`],out={id:s.id,at:s.at,note:s.note,seconds:s.seconds,velocity:s.velocity};
    if(a('technique')===1)out.articulation='pizzicato';
    if(a('position')!=null)out.contact=bipolarFrom32(a('position'));
    if(c.pressure!=null)out.bowPressure=bipolarFrom32(c.pressure);
    const string=a('string')?a('string')-1:null;
    if(a('partial'))out.harmonic={kind:'natural',partial:a('partial'),node:a('node')??1,...(string!=null?{string}:{})};
    else if(string!=null)out.string=string;
    if(a('multiphonic'))out.multiphonic={index:a('multiphonic')-1};
    const bow=BOWS[a('bow')??0]??'begin',stroke={};
    if(bow!=='begin')stroke.into=true;
    if(bow==='change')stroke.change=true;
    if(bow==='held')stroke.captured=false;
    if(a('tremolo')===1)stroke.tremolo=true;
    if(c[`r${T.attack.index}`]!=null)stroke.attack=bipolarToTime(bipolarFrom32(c[`r${T.attack.index}`]),T.attack.reference);
    if(a('rest')!=null)stroke.rest=bipolarToTime(bipolarFrom32(a('rest')),T.rest.reference);
    if(a('bite')!=null)stroke.bite=bipolarToTime(bipolarFrom32(a('bite')),T.bite.reference);
    if(a('weight')!=null||a('noise')!=null){stroke.weight=(a('weight')??0)/0xffffffff;stroke.noise=(a('noise')??0)/0xffffffff;
      stroke.decay=a('decay')!=null?bipolarToTime(bipolarFrom32(a('decay')),T.decay.reference):0}
    // (Its level through it, read at the synth's own step along the lines its points make.)
    if(s.level.length){const points=[...s.level].sort((x,y)=>x[0]-y[0]),end=Number.isFinite(s.seconds)?s.seconds:points.at(-1)[0];
      stroke.dynamics={curve:Array.from({length:Math.max(1,Math.floor(end/this.step)+1)},(_,k)=>+pointAt(points,k*this.step).toFixed(6)),step:this.step}}
    if(Object.keys(stroke).length)out.stroke=stroke;
    if(s.bend.length)out.bend=[...s.bend].sort((x,y)=>x[0]-y[0]);
    return out;
  }
}
// A curve's value at `t` along the straight lines its points make, held beyond them.
export function pointAt(points,t){
  if(!points.length)return 0;if(t<=points[0][0])return points[0][1];
  for(let i=1;i<points.length;i++)if(t<=points[i][0]){const [t0,v0]=points[i-1],[t1,v1]=points[i];return t1>t0?v0+(v1-v0)*(t-t0)/(t1-t0):v1}
  return points.at(-1)[1];
}
// A whole part's notes read at once (a render's). -> its strokes, in the order they began; a note never ended left out.
export const decodeBowed=(events,options)=>{const decoder=new BowedDecoder(options),strokes=new Map;for(const stroke of decoder.take(events))strokes.set(stroke.id,stroke);
  return [...strokes.values()].filter(stroke=>Number.isFinite(stroke.seconds)).sort((a,b)=>a.at-b.at||a.id-b.id)};
