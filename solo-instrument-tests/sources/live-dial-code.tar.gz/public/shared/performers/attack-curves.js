// A note's attack as its player shapes it: a quantity the player holds -- a bow's force or speed, a wind player's
// breath -- drawn as a curve over the note's first moments, a multiple of the value it settles at (the owner, 1 November
// 2026: "attacks usually involve a curve where a parameter peaks over the settling value, before settling, so I'll need
// visual curves to make proper attacks"; "Attacks usually peak over the sustain value, which might explain some models'
// difficulty playing at quiet dynamics"). A drawn curve (drawn-curves.js) of its own kind, ATTACK: its points [t, y] or
// [t, y, 'straight'], t in seconds from the note's start, the first at 0, y a multiple of the settled value, the last 1
// -- settled, and held so after it; between two, along the raised cosine, or, 'straight' on the later of the two, at one
// rate (a bow drawn up to speed at one acceleration). One code for the page that draws it and the dials that play it:
// the strings' host follows it a few samples at a time (native/strings-model/live.mjs, musebots-strings-live.cpp c), the
// winds' dial moves its held row along each segment, a segment a move of its engine (native/openwind/live.mjs).
import {POINTS,curveOf as drawn} from './drawn-curves.js';
export {curveAt,settlesAt,peakOf,sampledCurve,firstEndingAt,segmentLasting} from './drawn-curves.js';

// (How far an attack reaches: a multiple to MOST of its settled value, settled within LONGEST s -- the dial's reach, ours,
// past a sforzando's onset (physical-strings.js onsetOf: some 3.1 times its force at its noisiest) and an accent's
// longest decay (bowed-articulation.js ARTICULATION_RANGE: 1 s) after the slowest start the strings' dial reaches.)
export const MOST=4,LONGEST=2;
// An attack's kind: a multiple from 0 to MOST of the value held, settled on it (1) within LONGEST s; `from` and
// `straight` as its player has them (attackKind).
export const ATTACK=Object.freeze({least:0,most:MOST,longest:LONGEST,from:null,settled:1,straight:true,points:POINTS});
export const attackKind=({from=null,straight=true}={})=>Object.freeze({...ATTACK,from,straight});

// An attack as given, made one (drawn-curves.js curveOf): `from` its first point's multiple where it is fixed (a breath
// or a bow's speed from rest: 0), `straight` false where its player cannot draw a segment straight. -> the points;
// throws where they are not a curve.
export const curveOf=(given,{from=null,straight=true}={})=>drawn(given,attackKind({from,straight}));

// A bowed stroke's attack as the renders play it (physical-strings.js compileActions), its curves for the bow's force and
// speed over an attack `attack` s long: from silence, the force set on the string at `from` of its own and brought to it
// over the attack, the bow drawn up to speed at one acceleration; an articulation's (`onset`, physical-strings.js
// onsetOf over a held bow of 1: its speed and force over the held one's, where its force begins, its decay), its bow
// drawn to its onset's speed over the attack, its force begun at its share of its onset's and brought to it -- or,
// where it bites (`bite` s), set on the string at its onset's force, still, for its bite -- then both eased back to the
// held bow over its decay, never quicker than `least` (a bow's force's least change). -> {force, speed}.
export function bowedAttack({from,least},{attack,onset=null,bite=0}){
  const a=bite+attack;
  if(!onset||!(onset.speed>1||onset.force>1))
    return {force:[[0,from],[a,1]],speed:[...bite>0?[[0,0],[bite,0]]:[[0,0]],[a,1,'straight']]};
  const back=a+Math.max(onset.decay,least);
  return {force:bite>0?[[0,onset.force],[a,onset.force],[back,1]]:[[0,onset.force*onset.from],[a,onset.force],[back,1]],
    speed:[...bite>0?[[0,0],[bite,0]]:[[0,0]],[a,onset.speed,'straight'],[back,1]]};
}
