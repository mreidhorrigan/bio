// The players' noise as their engines are given it (research/NOISE_AND_TEMPERATURE.md; the owner, 1 November 2026: "Noise
// is necessary anywhere a human player acts"): each kind's deviation at temperature 1 and the profile a continuous
// action's noise is drawn with, its hand's or breath's tremor in it (registry/players/bowed.json `instrument` noise, every
// player's). The strings' kinds are physical-strings.js PLAYER_NOISE's; the winds' here, for their engine (native/openwind
// src/noise.rs PlayerNoise, its stream's `p`): the breath's pressure, a share of the mouth's pressure asked, and brass
// lips' tension, a share of the tension asked. Each kind's temperature the seat's tree's (noise.js temperatureAt) down
// its path, or the live dial's.
import {player} from '../../../registry/registry.js';

export const NOISED=path=>player('instrument',`noise.${path}`);
// A continuous action's profile: its power falling as 1/f^beta from `low` to `high` Hz, its tremor carrying its share.
export const ACTION_PROFILE=Object.freeze({beta:NOISED('action.beta'),low:NOISED('action.low'),high:NOISED('action.high'),
  tremor:Object.freeze({hz:NOISED('tremor.hz'),q:NOISED('tremor.q'),share:NOISED('tremor.share')})});
export const WINDS_NOISE=Object.freeze({
  kinds:Object.freeze({breath:{sd:NOISED('breath.pressure'),path:['breath','pressure']},lips:{sd:NOISED('lips.tension'),path:['lips','tension']}}),
  profile:ACTION_PROFILE});
// The winds' kinds a body's player has: its breath, and its lips where it is brass.
export const windsNoiseKinds=kind=>kind==='lips'?['breath','lips']:['breath'];
// One kind's noise as the winds' engine is told it (stream.rs NoiseLine): what it moves, its deviation, its temperature,
// its profile, and the player's seed where given.
export function windsNoiseLine(what,temperature,seed){
  const {sd}=WINDS_NOISE.kinds[what],{beta,low,high,tremor}=WINDS_NOISE.profile;
  return {...(seed==null?{}:{seed}),what,sd,temperature,beta,low,high,tremor:{...tremor}};
}
