// A player's personality (the owner, 3 November 2026: "The player's personality will be deterministic-random at first,
// and we will add LLM-player-writing later"; "The playerbot's character then determines how much it tends to push the
// limits of the instrument's idiom and what types of surface rhythms, phrasings, et cetera, even specific motifs (that
// can be preloaded as musicXML) that the playerbot prefers"): a place among the line planner's own settings. Each lever
// is a share, 0 to 1 -- drawn from the player's seed, or given (a spec's; an LLM's, later, the same way) -- read across
// its range in the registry (registry/method/personality.json; docs/PLAYER_PERSONALITY.md); every range holds the
// planner's own value. Daring reaches toward the instrument's limits as its facts say them (instrument-facts.js): its
// register widened toward its compass, the dynamics comfortable in a register passed, its quickest notes quicker, its
// phrases wider. The rest are its style: how dense, loud and ornamented it plays, how often it leaps, how long its slurs,
// motifs and runs, how long its rests and commas, how high its cadences land, which of the motif grammars it prefers,
// and how often it takes a motif it was given.
// Its tone (the owner, 3 November 2026: "The personality has, or maybe is, a tone concept. Some settings of the
// personality would favour extremes of extended technique, surface rhythm, et cetera; others aim for clean tones"; "A
// tone concept can also have per-parameter ranges of interest to the character; for example, some performer characters
// might allow huge vibrato ranges; others not"): the lever `tone`, from a clean tone, 0, to its extremes, 1 -- how often
// its phrases take an extended technique, and how much its motifs' rhythmic grammars weigh -- and a range of its own in
// each of its tone's parameters (TONE_RANGES), [low, high] shares of that parameter's span on its instrument, drawn about
// a centre that moves from the ordinary toward anywhere as its tone is extreme, and as wide as a draw of its own goes
// toward its tone's widest -- so that of two extreme characters one may range over every vibrato and the other keep to
// one -- or given.
// What it plays of them is what its instrument sounds, as its facts say -- its linked engine's where one is linked
// (instrument-facts.js `engine`: a live dial's) -- so that one personality plays each instrument by its own properties
// (the owner, 3 November 2026: "the bot applies its personality differently depending on the properties of the
// instrument it's linked to").
// It is not the ensemble's character (/broadcast/character, framework/agent.js), which every bot hears: this is one
// player's own. Everything interpolable: two personalities blend lever by lever (blendPersonalities).
import {setting} from '../../../registry/registry.js';
import {createRandomStream} from '../../random-source.js';
import {LINE} from './line.js';
import {windTechniqueOf} from './techniques.js';

// (Levers added since the first, drawn after the grammars, so that no draw before them moves.)
const LATER=Object.freeze(['tone']);
export const LEVERS=Object.freeze(['daring','density','loudness','fioriture','leap','slurs','motifLength','runs','rests','commas','landing','phraseRange','quoting',...LATER]);
// Its tone's parameters, each a range of shares across its span on the instrument: its vibrato's width (0 none, 1
// vibratoMost times its players' measured: vibrato.js's scope), how far a technique goes (0 its least, 1 its most:
// techniques.js windTechniqueOf's `far`), its bow's pressure (0 flautando, 1/2 ordinario, 1 overpressure: techniques.js
// pressureOf) and its contact (0 sul ponticello, 1/2 ordinario, 1 sul tasto: physical-strings.js MODEL.contact) -- each
// clean tone's about its ordinary.
export const TONE_RANGES=Object.freeze(['vibrato','depth','pressure','contact']);
const RANGE='personality';
const unit=x=>Math.max(0,Math.min(1,Number(x)));
const givenShare=value=>value!=null&&Number.isFinite(Number(value));
const givenRange=value=>{if(!Array.isArray(value))return null;const [low,high,...more]=value;return !more.length&&[low,high].every(givenShare)&&unit(low)<=unit(high)?Object.freeze([unit(low),unit(high)]):null};
const across=(name,share)=>{const [low,high]=setting(RANGE,name);return low+(high-low)*share};
const ORDINARY=Object.freeze({vibrato:()=>1/setting(RANGE,'vibratoMost'),depth:()=>0,pressure:()=>1/2,contact:()=>1/2});
// (Its motifs' grammars whose signature is a rhythm: a rhythm on a repeated tone, unequal durations, a rest inside it.)
const RHYTHMIC=new Set(['repeated','asymmetric','rest']);

// Its levers drawn from `key` (a seed's text), each one given kept in place of its draw -- every draw still taken, so
// that a lever given never moves another -- its shares of the motif grammars after them (line.js LINE.grammars), the
// levers added since after those, and its tone's ranges last: each about a centre drawn from the ordinary as far toward
// anywhere as its tone is extreme, and `toneWidth` wide at its tone times a share drawn its own (so that at a clean tone
// every range is narrow about the ordinary), within the span.
// given: {lever: share, grammars: {grammar: share}, ranges: {parameter: [low, high]}}. -> {key, levers, grammars,
// ranges, given: [the levers and ranges given]}.
export function drawPersonality(key,{given=null,grammars=LINE.grammars}={}){
  const stream=createRandomStream(`personality:${key}`),levers={},shares={},ranges={},told=[];
  const lever=name=>{const drawn=stream.next();if(givenShare(given?.[name])){levers[name]=unit(given[name]);told.push(name)}else levers[name]=drawn};
  for(const name of LEVERS)if(!LATER.includes(name))lever(name);
  for(const grammar of grammars){const drawn=stream.next();shares[grammar]=givenShare(given?.grammars?.[grammar])?unit(given.grammars[grammar]):drawn}
  for(const name of LATER)lever(name);
  for(const name of TONE_RANGES){
    const drawn=stream.next(),wide=stream.next(),own=givenRange(given?.ranges?.[name]);
    if(own){ranges[name]=own;told.push(`ranges.${name}`);continue}
    const width=across('toneWidth',levers.tone*wide),ordinary=ORDINARY[name](),low=Math.max(0,Math.min(1-width,ordinary+(drawn-ordinary)*levers.tone-width/2));
    ranges[name]=Object.freeze([+low.toFixed(6),+(low+width).toFixed(6)]);
  }
  return Object.freeze({key:String(key),levers:Object.freeze(levers),grammars:Object.freeze(shares),ranges:Object.freeze(ranges),given:Object.freeze(told)});
}
// Two personalities' blend, `t` of the way from a to b (0 to 1), lever by lever, grammar by grammar and range by range.
export function blendPersonalities(a,b,t){
  const x=unit(t),mix=(p,q)=>p+(q-p)*x;
  return Object.freeze({key:`${a.key}~${b.key}`,levers:Object.freeze(Object.fromEntries(LEVERS.map(name=>[name,mix(a.levers[name],b.levers[name])]))),
    grammars:Object.freeze(Object.fromEntries(Object.keys(a.grammars).map(g=>[g,mix(a.grammars[g],b.grammars[g]??a.grammars[g])]))),
    ranges:Object.freeze(Object.fromEntries(TONE_RANGES.map(name=>[name,Object.freeze([0,1].map(k=>mix(a.ranges[name][k],b.ranges[name][k])))]))),given:Object.freeze([])});
}

// How it plays its instrument: -> {register (sounding [low, high]), shaping {density, loudness, fioriture}, choices (the
// planner's `base` -- wind-line.js WIND_LINE, bowed-line.js BOWED_LINE -- with its own in place), quoting, tone}. Its
// register within its instrument's compass, and within the engine's where one plays it (facts.compass.engine); its
// quickest note no quicker than its engine's quickest (facts.engine.quickest: a live dial's least stroke); its tone the
// techniques its instrument sounds -- its engine's, where it names them -- and its ranges in each parameter's units:
// {share (of its phrases taking a technique), kinds, mutes, vibrato (vibrato.js's scope: shares of its players'
// measured width), depth (0 to 1), pressure and contact (-1 to 1)}.
export function playingOf(personality,facts,base){
  const {levers,grammars}=personality,daring=levers.daring,tone=levers.tone??1/2;
  const engine=facts.compass.engine,[low,high]=engine?[Math.max(facts.compass.range[0],engine[0]),Math.min(facts.compass.range[1],engine[1])]:facts.compass.range;
  const [from,to]=facts.compass.register.map(p=>Math.max(low,Math.min(high,p)));
  const register=Object.freeze([from-(from-low)*daring,to+(high-to)*daring]);
  const marks=facts.dynamics.marks,steps=Math.round(daring*setting(RANGE,'dynamicSteps'));
  const louder=mark=>marks[Math.min(marks.length-1,marks.indexOf(mark)+steps)],softer=mark=>marks[Math.max(0,marks.indexOf(mark)-steps)];
  const [fastest,slowest]=setting(RANGE,'shortest'),least=setting(RANGE,'grammarLeast');
  const quickest=Math.max(fastest,facts.engine?.quickest??0),calmest=Math.max(slowest,quickest);
  // (Its rhythmic grammars' shares drawn toward 1 as its tone is extreme, the rest toward 0 -- the other way as it is
  // clean -- every grammar still open to it: the planner's own at its middle.)
  const pull=across('rhythmicGrammars',tone),pulled=(g,share)=>{const a=RHYTHMIC.has(g)?pull:-pull;return a>=0?share+(1-share)*a:share*(1+a)};
  const choices={...base,
    shortest:calmest-(calmest-quickest)*daring,phraseRange:across('phraseRange',daring),
    leap:across('leap',levers.leap),slurMost:Math.round(across('slurs',levers.slurs)),
    motifNotes:Object.freeze([Math.round(across('motifFewest',levers.motifLength)),Math.round(across('motifMost',levers.motifLength))]),
    runMost:Math.round(across('runs',levers.runs)),restShare:across('rests',levers.rests),commaShare:across('commas',levers.commas),
    landing:Object.freeze([base.landing[0],across('landing',levers.landing)]),
    grammarWeights:Object.freeze(Object.fromEntries(Object.entries(grammars).map(([g,share])=>[g,least+(1-least)*pulled(g,share)]))),
    // (A wind's loudest low and softest high, past the comfortable ones by its daring.)
    ...(facts.breath?{lowMost:louder(facts.dynamics.comfortable.low.most),highLeast:softer(facts.dynamics.comfortable.high.least)}:{})};
  return Object.freeze({register,choices:Object.freeze(choices),
    shaping:Object.freeze({density:across('density',levers.density),loudness:across('loudness',levers.loudness),fioriture:across('fioriture',levers.fioriture)}),
    quoting:across('quoting',levers.quoting),tone:toneOf(personality,facts)});
}
// (Its tone on its instrument: the techniques its instrument sounds, its engine's where it names them, and its ranges in
// each parameter's units.)
function toneOf(personality,facts){
  const own=facts.techniques?.kinds??[],engine=facts.engine,ranges=personality.ranges??drawPersonality(personality.key).ranges;
  const kinds=engine?.techniques?own.filter(kind=>engine.techniques.includes(kind)):own;
  const mutes=kinds.includes('mute')?(engine?.mutes??facts.techniques.mutes??[]).filter(m=>(facts.techniques.mutes??[]).includes(m)):[];
  const most=setting(RANGE,'vibratoMost'),bipolar=([a,b])=>Object.freeze([+(a-(1-a)).toFixed(6),+(b-(1-b)).toFixed(6)]);
  return Object.freeze({share:across('techniques',personality.levers.tone??1/2),kinds:Object.freeze(kinds.filter(kind=>kind!=='mute'||mutes.length)),mutes:Object.freeze(mutes),
    vibrato:Object.freeze(ranges.vibrato.map(x=>+(x*most).toFixed(4))),depth:ranges.depth,pressure:bipolar(ranges.pressure),contact:bipolar(ranges.contact)});
}

// Its tone for one phrase (`phrase`, its number; `level`, its loudness 0 to 1), drawn from its own stream, every draw
// taken whatever it plays: its bow's pressure within its range by its level (a soft phrase toward its range's flautando
// end, a loud one toward its overpressure end) and its contact anywhere within its range, where its instrument has them;
// and, for its tone's share of its phrases, one of the techniques its instrument sounds -- a hum or a harmonic as the
// phrase is soft, a growl or a flutter as it is loud, a multiphonic at any level -- going as far as its depth draws, and,
// for its share of them, a mute among its own. -> {pressure?, contact?, technique?, harmonic?, multiphonic?, mute?}.
export function phraseTone(personality,playing,{phrase,level}){
  const tone=playing?.tone;if(!tone)return {};
  const stream=createRandomStream(`personality:${personality.key}:tone:${phrase}`),draw=()=>stream.next(),within=([a,b],x)=>a+(b-a)*x;
  const loud=unit(level),has=kind=>tone.kinds.includes(kind),out={};
  const [takes,which,far,contact,muted,mute]=[draw(),draw(),draw(),draw(),draw(),draw()];
  if(has('pressure'))out.pressure=+within(tone.pressure,loud).toFixed(3);
  if(has('contact'))out.contact=+within(tone.contact,contact).toFixed(3);
  const weights=[['hum',1-loud],['harmonic',1-loud],['growl',loud],['flutter',loud],['multiphonic',1/2]].filter(([kind])=>has(kind));
  const total=weights.reduce((sum,[,w])=>sum+w,0);
  if(takes<tone.share&&total>0){
    let left=which*total,kind=weights.at(-1)[0];for(const [k,w] of weights){left-=w;if(left<0){kind=k;break}}
    const depth=within(tone.depth,far);
    if(kind==='harmonic'){const [shallow,deep]=setting(RANGE,'harmonicPartials');out.harmonic={kind:'natural',partial:depth<1/2?shallow:deep}}
    else if(kind==='multiphonic')out.multiphonic={choice:+far.toFixed(4)};
    else out.technique=windTechniqueOf(kind,depth,draw);
  }
  if(tone.mutes.length&&muted<tone.share)out.mute=tone.mutes[Math.min(tone.mutes.length-1,Math.floor(mute*tone.mutes.length))];
  return out;
}

// Which of the motifs it was given it takes (lines as musicxml-motifs.js reads them), or none, its own made instead: one
// draw from its own stream among them all at once, its own motif weighted by how seldom it quotes, each given one by
// how often it does and how near the motif's length is to those it prefers. -> the index, or null.
export function preferredMotif(personality,playing,lines){
  if(!lines?.length)return null;
  const [fewest,most]=playing.choices.motifNotes;
  const near=line=>{const n=line.notes.length,off=n<fewest?fewest-n:n>most?n-most:0;return 1/(1+off)};
  const weights=[1-playing.quoting,...lines.map(line=>line.notes.length>1?playing.quoting*near(line):0)];
  const total=weights.reduce((a,b)=>a+b,0);
  if(!(total>0))return null;
  let left=createRandomStream(`personality:${personality.key}:motif`).next()*total;
  let k=0;for(;k<weights.length;k++){left-=weights[k];if(left<0)break}
  // (Its last weighted one where rounding leaves the draw past them all.)
  if(k>=weights.length)k=weights.findLastIndex(w=>w>0);
  return k?k-1:null;
}
