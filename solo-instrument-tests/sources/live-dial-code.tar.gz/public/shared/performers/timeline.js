// A timeline: the repeating, asymmetric pattern a bell, an agogo, the claves or a triangle plays for a band to orient
// itself by (the family atlas's F30 and F35, research/family-atlas.md; timeline_clodbot.js plays one). One hand, one
// stick or the claves' pair, strikes it cycle after cycle.
//
// **Maximally even, and asymmetric.** Toussaint found the timelines of many traditions to be the most even spreading of
// k onsets over a cycle of n pulses (a Euclidean rhythm), or a rotation of one ("The Euclidean algorithm generates
// traditional musical rhythms", Bridges 2005; The Geometry of Musical Rhythm, 2013): three of eight, five of eight,
// five and seven of twelve, and so on. Each here is one: k prime to n, since k and n with a common factor spread into a
// shorter cycle repeated (four of eight is four quarter notes), which orients nobody; within a density range, the
// traditions' own (TIMELINE.density); its cycle the bar, or the fewest bars that hold the shortest timeline's pulses.
// Nothing here is named for a tradition: a maximally even pattern is not a clave because its onsets match one
// (shared/rhythm-vocabulary.js). Where the band's clock carries a tradition's record, the player plays that instead.
//
// **Its rotation, by the meter's hierarchy.** Of the rotations that strike the downbeat (a timeline's first stroke
// marks its cycle), each fits the meter as well as its onsets' mean metric strength: the most fitted lands on the
// meter's strong points, the least cuts across them. A syncopation between 0 and 1 asks for a place between the two,
// so a band's character moves it without a rule for any meter (research: principles over hardcoding).
//
// **Playable by construction.** A maximally even set's gaps are the floor or the ceiling of n / k pulses, so the
// shortest a hand must strike again after is known before a stroke is chosen: k is never so many that it falls under
// the stroke's spacing (the drummer's singles, performers/drummer.js).
import {euclideanRhythm,rotateCycle} from '../../stochastic-algorithms.js';

export const TIMELINE=Object.freeze({
  // A cycle holds at least the shortest timeline's pulses: the tresillo's and the cinquillo's eight (Toussaint 2013).
  fewestPulses:8,
  // Its onsets' share of its pulses, the range of the maximally even timelines Toussaint lists as traditional: from
  // five of sixteen (0.31) to five of eight (0.63).
  density:Object.freeze([5/16,5/8]),
});

const gcd=(a,b)=>{a=Math.abs(a);b=Math.abs(b);while(b)[a,b]=[b,a%b];return a};
const clamp=(value,low,high)=>Math.max(low,Math.min(high,value));

// How many bars a cycle spans: one, or the fewest that hold TIMELINE.fewestPulses.
export const cycleBars=(pulsesPerBar,{fewestPulses}=TIMELINE)=>Math.max(1,Math.ceil(fewestPulses/Math.max(1,pulsesPerBar)));

// The onsets for a cycle of n pulses at a density (0 to 1 across TIMELINE.density): the count nearest the density's
// share of n that is prime to n and leaves no gap under the hand's spacing (floor(n / k) pulses, each pulseSeconds long,
// no shorter than spacingSeconds); the fewer on a tie. Null where no count of two or more is both.
export function onsetCount(n,{density=.5,pulseSeconds=Infinity,spacingSeconds=0,range=TIMELINE.density}={}){
  const [low,high]=range,wanted=n*(low+(high-low)*clamp(density,0,1));
  const playable=k=>Math.floor(n/k)*pulseSeconds>=spacingSeconds-1e-9;
  let best=null;
  for(let k=2;k<n;k++)if(gcd(k,n)===1&&playable(k)&&(best===null||Math.abs(k-wanted)<Math.abs(best-wanted)-1e-9))best=k;
  return best;
}

// A cycle's metric strengths from its bar's (each 0 to 1, the downbeat strongest), its later bars' downbeats a little
// under its first: the cycle begins where its first bar does.
export function cycleStrengths(barStrengths,bars=1){
  const out=[];
  for(let bar=0;bar<bars;bar++)for(const [at,strength] of barStrengths.entries())out.push(bar>0&&at===0?strength*.9:strength);
  return out;
}

// The rotations of k maximally even onsets in n pulses that strike the downbeat, each {onsets, fit}: its onsets'
// mean strength.
export function downbeatRotations(n,k,strengths){
  const base=euclideanRhythm(k,n),seen=new Set,out=[];
  for(let shift=0;shift<n;shift++){
    const cycle=rotateCycle(base,shift);if(!cycle[0])continue;
    const key=cycle.join('');if(seen.has(key))continue;seen.add(key);
    const onsets=cycle.flatMap((on,at)=>on?[at]:[]);
    out.push({onsets,fit:onsets.reduce((sum,at)=>sum+(strengths[at]??0),0)/onsets.length});
  }
  return out;
}

// The timeline for a cycle of `strengths.length` pulses: {pulses, count, onsets, fit, syncopation}, the rotation whose
// fit stands where the syncopation asks between the most fitted (0) and the least (1); the earlier on a tie. Null where
// no count is playable.
export function chooseTimeline({strengths,density=.5,syncopation=.5,pulseSeconds=Infinity,spacingSeconds=0}={}){
  const n=strengths.length,count=onsetCount(n,{density,pulseSeconds,spacingSeconds});
  if(count===null)return null;
  const rotations=downbeatRotations(n,count,strengths),fits=rotations.map(rotation=>rotation.fit);
  const most=Math.max(...fits),least=Math.min(...fits),span=most-least,aim=most-span*clamp(syncopation,0,1);
  let best=rotations[0];
  for(const rotation of rotations)if(Math.abs(rotation.fit-aim)<Math.abs(best.fit-aim)-1e-12)best=rotation;
  return Object.freeze({pulses:n,count,onsets:Object.freeze(best.onsets),fit:best.fit,
    syncopation:span>0?(most-best.fit)/span:0});
}

// Which of a timeline's onsets take an instrument's strong stroke (an agogo's low bell, a triangle's open stroke) and
// which its weak one: the strong on the metrically stronger half of them (the downbeat first, then by strength, the
// earlier on a tie), so the weak one carries the pattern and the strong one marks where the meter is strong.
export function strokeWeights(onsets,strengths){
  const strong=new Set([...onsets].sort((a,b)=>(b===0)-(a===0)||(strengths[b]??0)-(strengths[a]??0)||a-b).slice(0,Math.max(1,Math.floor(onsets.length/2))));
  return onsets.map(at=>strong.has(at)?'strong':'weak');
}
