import {Rational as R,lcm} from '../../transcript/rational.js';
import {scoreTime,readScoreTime,shiftScoreTime,scaleScoreTime,reverseScoreTime,scoreTimeFields} from '../score-time.js';
import {authoredFraction as Q} from './rhythm-cell.js';
import {requiredMotifPitches} from '../motif-insistence.js';
// A section's parts as their players play them (Musebots 3.0: a section is many playing bots, each seat a player of its
// instrument; the owner, 1 October 2026). A formation (string-section.js formationPlan) gives every seat a role: its
// pool's texture, its part among the pool's parts, the pool's centre, width, density and level, its texture's
// parameters, and the pool's seed. Each player makes its part's voice from them (makeVoice) and plays it: a part shared
// by several seats is the same material in each of their bots (its seed and number), so its players are together, each
// with its own few cents and milliseconds (playerOffsets); a seat alone in its part improvises it within the pool's
// constraints. Taken from strings_clodbot (archived), whose seats were a bot's; its numbers are now the formation's
// (the conductor's, from its section's specification) or follow from the meter and the instrument:
//   - a line is planned a phrase at a time as the melodic players' are (line.js planLine: its idea, repeated and varied,
//     its continuation's fragments climbing to its apex, its cadence), each note sounded in the harmony of its moment
//     (followHarmony); where its register holds too few of the harmony's pitches, a walk by steps, a note a group of the
//     meter;
//   - a held note is the part's, its bowing the player's: each seat changes bow where its own bow runs out (bowSeconds:
//     the instrument's bow over its speed at the part's dynamic, bow.js BOW.speed, bowed-line.js
//     BOWED_LINE.fastestShare), so each player of a part changes bow at a time of its own, as orchestras' free bowing
//     does (bots/lib/modules/section-seat.js);
//   - a canon's notes last a group of the meter (its mean) in each part's own division of the beat.
import {seededSource,arcAt,poolParameters} from './string-section.js';
import {figure} from './figuration.js';
import {BOWED_INSTRUMENTS,BOWED_LINE} from './bowed-line.js';
import {BOW,bowSpeedAt} from './bow.js';
import {LINE,planLine,followHarmony,linePitches,motifFromLine,chooseMotif,beatGroups} from './line.js';
import {velocityBeyond} from '../dynamics.js';
import {feltBeats} from '../meter-tactus.js';
import {WIND_INSTRUMENTS,WIND_LINE} from './wind-line.js';
import {entryDelay,entryPitch,jointEntries} from '../conducting/entries.js';
import {elongationCandidates,nearestElongation,sourceLattice,fractionOf} from '../conducting/exact-elongation.js';
import {counterLine,drawnRules} from '../conducting/counterpoint.js';
import {stepInCollection} from '../conducting/canon-plan.js';
import {convergingCanon} from '../conducting/fugue-contracts.js';
import {leadVoices,spreadVoices} from './compound-melody.js';
import {planFigures,figuredLine,figurePitch,scaleLadder} from './improvise.js';
import {collectionPitches} from '../collection-space.js';
import {chordScale,TWELVE_TONE_LEVELS} from '../estimation/harmonic-levels.js';
import {repetitionOf,mayGoOn} from '../repetition.js';

// What is never begun: a note shorter than a bow can draw before its phrase ends (s: two of its changes of direction,
// bow.js BOW.changeSeconds), so the next formation's downbeat is its own.
export const SECTION_VOICES=Object.freeze({shortest:2*BOW.changeSeconds,
  // A line's own rubato where no conductor says how far its own time may stray (s): a melody's lead, at most (plex_clodbot
  // PLEX_CLODBOT.ownTime, its sources). (The owner, 5 October 2026, of Op. 3.29: "The music sounds FAR more complex in
  // terms of timing than the score appears at the beginning" -- a fugue's oboe a third of a second ahead of the strings
  // mid-phrase; and 10 October 2026, of Op. 3.37: "The players' timing is also far too ragged. Rein that in" -- 50 ms
  // before.)
  leads:.02});
// A held note no motif asks for played the softer the longer it is held (the owner, 4 October 2026, of Op. 3.25:
// "sustained notes, when they are not part of an intended motif, need a penalty on their loudness, as they're often being
// blared over other, more interesting, things"): `dbPerDoubling` under its phrase's level for each doubling of its length
// past a beat, `most` at the most (ours: a note four beats long 4 dB under, sixteen 8). A theme its conductor gives
// (role.given: a fugue's subject and answer, role.themeLine, a required motif) is held as loud as it is written.
export const SUSTAIN=Object.freeze({dbPerDoubling:2,most:8});
export function sustainDb(seconds,beatSeconds,role=null){
  if(!(seconds>beatSeconds)||!(beatSeconds>0)||role?.given?.length||role?.themeLine!=null||role?.motifUse||role?.texture==='hit')return 0;
  return -Math.min(SUSTAIN.most,SUSTAIN.dbPerDoubling*Math.log2(seconds/beatSeconds));
}
const clamp=(x,low,high)=>Math.max(low,Math.min(high,x));
const modulo=(x,n)=>((x%n)+n)%n;
// A normal draw (Box-Muller) from a source.
const normalFrom=random=>Math.sqrt(-2*Math.log(Math.max(1e-12,random())))*Math.cos(2*Math.PI*random());
// A part's voice: a line's whole pool one voice, else each part its own.
// (A pool's material its own, or another's it plays again -- a section recalled re-orchestrated, plex_clodbot recall:
// the same seed and the same material key make the same notes, in this pool's register.)
export const materialOf=role=>role.material??role.pool;
export const voiceKey=role=>role.texture==='line'?materialOf(role):`${materialOf(role)}:${role.part}`;
// A pitch into a seat's compass by octaves (a basses' octave below the cellos, as orchestras double).
export const intoCompass=(pitch,seat)=>{let p=pitch;while(p<seat.low)p+=12;while(p>seat.high)p-=12;return p<seat.low?null:p};
// A part's dynamic and velocity at its level, as a line's are (line.js LINE); a level under 0 or over 1 in the
// uncomfortable range beyond ppp or fff (dynamics.js velocityBeyond), its dynamic for its players' tables the scored
// range's end there.
export function dynamicOf(level){
  if(Number(level)<0||Number(level)>1)return {dynamic:Number(level)<0?LINE.dynamics[0]:LINE.dynamics.at(-1),velocity:velocityBeyond(level)};
  const dynamic=LINE.dynamics[Math.min(LINE.dynamics.length-1,Math.max(0,Math.floor(level*LINE.dynamics.length)))];
  return {dynamic,velocity:LINE.velocity[dynamic]};
}
// How long a held note's bow lasts (s) on `instrument` at `velocity`, as it is bowed (its phrase's curve and its
// accents', never its part's level alone): its bow's length over a speed drawn between its velocity's (bow.js
// bowSpeedAt) and the fastest it takes. (From its part's level, a cluster at fff eased to pp as it was held had changed
// bow every second, a seventh of its bow a stroke: Op. 3.36's violas, 10 October 2026.)
export function bowSeconds(instrument,velocity,random){
  const lengthCm=(BOWED_INSTRUMENTS[instrument]??BOWED_INSTRUMENTS.violin).lengthCm;
  return lengthCm/(bowSpeedAt(velocity)*(1+random()*(BOWED_LINE.fastestShare-1)));
}
// The meter's groups, in its notated notes (a meter that names none, one group a bar).
const groupsOf=meter=>{const groups=(meter?.groups??[]).map(Number).filter(n=>n>0);return groups.length?groups:[Math.max(1,Number(meter?.numerator)||1)]};

// ---- Voices: a part's material, deterministic from its seed ----------------------------------------------------------
// Each: {events(now, until, {position, clock, spt, left}) -> [{at, pitch, seconds, from?, pluck?}]}: its notes starting
// in [now, until). The pool heard (`pool()`) is every bot's alike at a tick, so a part's harmony is too.
// The equal division a set of classes lies on: the fewest steps an octave, twelve or more, holding every one of them (to
// a thousandth of a semitone: a pool's pitches are said to four places); null for a tuning of no division up to 72.
function divisionOf(classes){
  for(let n=12;n<=72;n++)if(classes.every(pc=>Math.abs(pc-Math.round(pc*n/12)*12/n)<1e-3))return n;
  return null;
}
// A pool's ladder: its classes where it has a collection's (five or more); else its tones among the twelve of its own
// tuning -- each of the twelve moved onto the division its tones lie on (a 31-step harmony's nearest steps), the pool's
// own tone where it holds one within a quarter tone of it -- never the twelve equal steps under a tuning of its own.
function ladderOf(pool){
  const heard=[...new Set((pool()??[]).map(Number).filter(Number.isFinite).map(p=>+modulo(p,12).toFixed(6)))].sort((a,b)=>a-b);
  const n=heard.length>=5?null:divisionOf(heard),near=k=>n?+(Math.round(k*n/12)*12/n).toFixed(6):k;
  const twelve=Array.from({length:12},(_,k)=>heard.find(own=>Math.min(modulo(own-k,12),modulo(k-own,12))<.5)??near(k));
  const classes=heard.length>=5?heard:[...new Set([...heard,...twelve].map(pc=>+modulo(pc,12).toFixed(6)))].sort((a,b)=>a-b),out=[];
  for(let octave=1;octave<=8;octave++)for(const pc of classes)out.push(12*octave+pc);
  return out.sort((a,b)=>a-b);
}
const nearestIn=(list,target)=>list.reduce((best,p)=>Math.abs(p-target)<Math.abs(best-target)?p:best,list[0]);
// A position's metrical weight from the meter's own hierarchy, its four levels weighted down from the bar's start by
// quarters: 1 the bar's start, 3/4 a group's, 1/2 a notated note's, 1/4 a subdivision's.
const METRIC_LEVELS=['bar','group','note','subdivision'];
export const METRIC_WEIGHTS=Object.freeze(Object.fromEntries(METRIC_LEVELS.map((level,k)=>[level,1-k/METRIC_LEVELS.length])));
// The bar's positions, each with its metrical weight (METRIC_WEIGHTS); and the bar's length. -> {positions [{at (s from
// the bar's start), weight}], barSeconds}.
export function metricalGrid(meter,beatSeconds){
  const groups=groupsOf(meter),sub=Math.max(1,Math.round(Number(meter?.subdivision)||1)),unit=beatSeconds/sub,positions=[];let note=0;
  const {bar,group:grouped,note:noted,subdivision}=METRIC_WEIGHTS;
  groups.forEach((size,group)=>{for(let n=0;n<size;n++,note++)for(let s=0;s<sub;s++)positions.push({scoreAt:String(note*sub+s),at:(note*sub+s)*unit,weight:s?subdivision:n?noted:group?grouped:bar})});
  return {positions,barSeconds:note*beatSeconds,barTicks:note*sub};
}
// Whether a position of `weight` sounds at a pulse p: none at 0; the meter's levels coming in in turn as p rises, the
// bar's starts first and every subdivision at 1, each position of a level as p passes its own draw (`draw`, [0, 1),
// the same each bar: a pattern a pulse keeps, as a groove does). Every state between two pulses is one.
export const pulsed=(weight,pulse,draw)=>Math.max(0,Math.min(1,(pulse-(1-weight))/.25))>draw;
// A pool's pulse: its positions in a bar, those that sound at its pulse (each position's draw its pool's, so its parts
// strike together), from `start` (s) bar by bar. -> {at(k): the k-th sounding position's time, after(t): the first at or
// after t} or null where nothing sounds.
function pulseOf({meter,beatSeconds,start,pulse,seed,pool}){
  if(!(pulse>0)||!(beatSeconds>0))return null;
  const {positions,barSeconds}=metricalGrid(meter,beatSeconds),on=positions.filter((position,k)=>pulsed(position.weight,pulse,seededSource(seed??0,`pulse:${pool}:${k}`)()));
  if(!on.length)return null;
  const barTicks=positions.length;
  const pointAfter=t=>{const bar=Math.max(0,Math.floor((t-start)/barSeconds-1e-9));for(let b=bar;;b++)for(const position of on){const at=start+b*barSeconds+position.at;if(at>=t-1e-9)return {at,scoreAt:R.of(b*barTicks).add(position.scoreAt)}}};
  return {pointAfter,after:t=>pointAfter(t).at};
}
// A part's voice. `random`: the part's source (its seed and number); `start` (s): the formation's downbeat;
// `beatSeconds`: the meter's notated note; `meter`: the meter it began in; `pool()`: the harmony heard; `instrument`: the
// player's (bowed-line.js), whose bow sets a held note's length.
// (A part's place from the top: the front chairs take the higher parts, and within a desk its odd-numbered, outside
// player the upper -- as divisi is written, a desk's two lines never crossing on its staff: the owner, 1 October 2026,
// "there should be a preference for the odd-numbered desk of a pair to have the higher part ... to avoid absurd
// conflicts on the staves". partsOf numbers parts from the front chair.)
const fromTop=(part,parts)=>parts-1-part;
// A section's line for a phrase, planned whole as the melodic players' lines are (line.js planLine): from its pool's
// seed (every seat of the pool the same line), in a register about its centre an octave and more wide, its density with
// its level (a soloist's, its pool its own, busier), elongated (its phrase planned in that many times fewer bars, each
// note that many times longer, exactly -- but never longer than its player sustains a note, one bow at its slowest or
// one breath, the ratio held to it; the owner, 2 October 2026: "tape elongation is more OK than 'simulated orchestral'
// extreme breath-length") and inverted (each pitch that share of the way to its mirror about the phrase's
// first) and played backwards (a return's crab) as its role says. Planned once a phrase for all its seats (a pool's
// seats ask alike). -> [{at (s), pitch,
// seconds (sounding), written? (s: an elongated note's written length)}], or null where its register holds too few of
// the harmony's pitches; an elongated line's `elongation` (not enumerable): {asked, ratio ('p/q'), residual (asked -
// ratio), lattice (its source's G), sourceBars, source (its notes' written onsets and releases, notated notes, exact:
// 'n/d'), drift: {notatedNotes (its whole source's end against the E asked's), truncated (within the phrase)},
// articulation}.
const LINES=new Map;
// A pool's parts as voices, planned together (the owner, 3 October 2026: "Move toward considering textures primarily in
// terms of counterpoint"; the whole system had "a tendency to just repeat chords over and over"): each part a line of
// its own in its own place in the pool's band -- the top first, each lower one planned against those above it (and kept
// below them), by conducting/counterpoint.js counterLine under a blend of rule sets drawn for the pool as its voices
// leave each room (drawnRules: Fux's, a fugue's, free, dissonant, micropolyphonic, at its own rigour) -- each on a rhythm
// of its own over the meter's positions (a part's pulse: the meter's levels coming in as it rises, pulsed, each bar's
// positions drawn anew), so the voices move independently, one holding as another moves. From its pool's seed (every
// seat of the pool the same plan, each playing its own part), once a phrase; its lower parts imitating its top as often
// as its imitation asks, a canon among its voices. -> [[{at (s), pitch, seconds, strong}]], a line a part, or null where
// the pool has no tones.
// A pool's line in counterpoint with the formation's lines above it (string-section.js seatRoles: role.above, the pools
// above it, theirs above them): its own line as planned (sectionLine: its rhythm, its motif's in the top line), each
// lower one's pitches chosen again on its own rhythm against the lines above it, every one planned as its own seats plan
// it, by counterLine under a blend of rule sets drawn for it as the voices leave each room (drawnRules), in its own
// register; its lag and its sounding lengths its own. Where it has none above, or none of them a line, its own line.
const COUNTERED=new Map;
export function sectionLines(role,options){
  const own=sectionLine(role,options);if(!own?.length||!role.above?.length)return own;
  const key=JSON.stringify([role.seed,role.centre,role.width,+options.downbeat.toFixed(6),+options.phrase.toFixed(6),options.beatSeconds,options.planBeat??null,options.shortest??null,role.above.map(other=>[other.seed,other.centre])]);
  if(COUNTERED.has(key))return COUNTERED.get(key);
  const notated=note=>Number.isFinite(note.written)?note.written:note.seconds/ARTICULATION;
  const against=role.above.map(other=>sectionLines(other,options)).filter(line=>line?.length).map(line=>line.map(note=>({pitch:note.pitch,start:note.at-options.downbeat,length:notated(note)})));
  let out=own;
  if(against.length){
    const [low,high]=lineRegister(role,(options.pool??[]).map(Number).filter(Number.isFinite))??[NaN,NaN],ladder=ladderOf(()=>options.pool),steps=ladder.filter(p=>p>=low-1e-9&&p<=high+1e-9);
    if(steps.length>=3){
      const random=seededSource(role.seed??0,'lines:counterpoint'),{positions,barSeconds}=metricalGrid(options.meter,options.beatSeconds);
      const strong=t=>{const within=((t%barSeconds)+barSeconds)%barSeconds;return positions.some(position=>position.weight>=.75&&Math.abs(position.at-within)<1e-6)};
      const {rules}=drawnRules(random,{voices:against.length+1,classes:new Set(ladder.map(p=>+modulo(p,12).toFixed(4))).size});
      const {line}=counterLine({against,rhythm:own.map(note=>({start:note.at-options.downbeat,length:notated(note)})),steps,rules,strong,random,above:false});
      // (Its pitches its own, no longer a stored theme's that its rhythm may still be: no `source`.)
      if(line.length===own.length)out=own.map(({source:_,...note},k)=>({...note,pitch:line[k].pitch}));
    }
  }
  COUNTERED.set(key,out);if(COUNTERED.size>512)COUNTERED.delete(COUNTERED.keys().next().value);
  return out;
}
// A shared line's entries chosen jointly, once a phrase for every seat of its sections alike (entries.js jointEntries):
// {section: entry}, or null where none holds (each then as drawn).
const ENTRIES_CHOSEN=new Map;
function sharedEntries(role,{planned,start,beatSeconds,meter,pool,phrase}){
  const groups=groupsOf(meter),delays=Object.fromEntries(Object.entries(role.entries).map(([id,e])=>[id,entryDelay(e,groups)*beatSeconds]));
  const key=JSON.stringify([role.seed,role.entries,role.entryRegisters,planned.map(n=>[n.at,n.pitch,n.seconds]),beatSeconds,pool]);
  if(ENTRIES_CHOSEN.has(key))return ENTRIES_CHOSEN.get(key);
  const out=jointEntries({line:planned.map(note=>({at:note.at-start,pitch:note.pitch,seconds:note.seconds})),entries:role.entries,registers:role.entryRegisters,delays,pool,length:phrase});
  const chosen=out.status==='SAT'?out.entries:null;ENTRIES_CHOSEN.set(key,chosen);if(ENTRIES_CHOSEN.size>256)ENTRIES_CHOSEN.delete(ENTRIES_CHOSEN.keys().next().value);
  return chosen;
}
const VOICES=new Map;
export function sectionCounterpoint(role,{downbeat,phrase,beatSeconds,meter,pool}){
  const parts=Math.max(1,Math.round(Number(role.parts)||1)),tones=(pool??[]).map(Number).filter(Number.isFinite);if(!tones.length)return null;
  const parameters=role.parameters??{},key=JSON.stringify([role.seed,materialOf(role),parts,role.centre,role.width,+downbeat.toFixed(6),+phrase.toFixed(6),beatSeconds,groupsOf(meter),meter?.subdivision,
    [...new Set(tones.map(p=>+modulo(p,12).toFixed(4)))].sort((a,b)=>a-b),parameters.pulses??null,parameters.rigor??null,parameters.imitation??null,parameters.prolation??null]);
  if(VOICES.has(key))return VOICES.get(key);
  const random=seededSource(role.seed??0,`counterpoint:${materialOf(role)}`),{positions,barSeconds}=metricalGrid(meter,beatSeconds);
  const bars=Math.max(1,Math.round(phrase/Math.max(1e-6,barSeconds))),length=Math.min(phrase,bars*barSeconds);
  const ladder=ladderOf(()=>tones),classes=new Set(ladder.map(p=>+modulo(p,12).toFixed(4))).size;
  const {rules}=drawnRules(random,{rigor:Number.isFinite(parameters.rigor)?parameters.rigor:1,voices:parts,classes});
  const strong=t=>{const within=((t%barSeconds)+barSeconds)%barSeconds;return positions.some(position=>position.weight>=.75&&Math.abs(position.at-within)<1e-6)};
  const span=Math.max(12,(Number(role.width)||7)*2),c=Number(role.centre)||60,reach=Math.max(5,span/parts);
  const pulses=Array.isArray(parameters.pulses)&&parameters.pulses.length?parameters.pulses:[.5];
  const targetOf=part=>c-span/2+span*(fromTop(part,parts)+.5)/parts,stepsOf=part=>ladder.filter(p=>p>=targetOf(part)-reach-1e-9&&p<=targetOf(part)+reach+1e-9);
  const rhythmOf=part=>{
    // (Its rhythm: the phrase's downbeat, and each of the meter's positions its pulse sounds, drawn bar by bar.)
    const scoreBar=groupsOf(meter).reduce((sum,g)=>sum+g,0)*(Number(meter.subdivision)||1);
    const pulse=pulses[part%pulses.length],own=seededSource(role.seed??0,`counterpoint:rhythm:${materialOf(role)}:${part}`),onsets=[];
    for(let bar=0;bar<bars;bar++)for(const position of positions){const at=bar*barSeconds+position.at;if(at<length-1e-6&&(at<1e-9||pulsed(position.weight,pulse,own())))onsets.push({at,scoreAt:R.of(bar*scoreBar).add(R.of(position.scoreAt))})}
    return onsets.map((point,k)=>({start:point.at,length:(onsets[k+1]?.at??length)-point.at,scoreTime:scoreTime(point.scoreAt,(onsets[k+1]?.scoreAt??R.of(bars*scoreBar)).sub(point.scoreAt),{axis:'phrase'})}));
  };
  // (Its lower parts imitating its top, each as often as its imitation asks (the owner: canons and fugues "more
  // important"): each a felt group later than the one before it, by octaves into its own place -- the top planned
  // against its own later entries (counterLine's self), as a canon's dux is; the rest free, against all.)
  const imitation=Math.max(0,Math.min(1,Number(parameters.imitation)||0)),group=groupsOf(meter)[0]*beatSeconds;
  const imitators=[];for(let part=1;part<parts;part++)if(imitation>0&&seededSource(role.seed??0,`counterpoint:imitates:${materialOf(role)}:${part}`)()<imitation)
    imitators.push({part,delay:(imitators.length+1)*group,transpose:12*Math.round((targetOf(part)-targetOf(0))/12),scoreDelay:(imitators.length+1)*groupsOf(meter)[0]*(Number(meter.subdivision)||1)});
  const lines=new Array(parts).fill(null),planned=()=>lines.filter(line=>line?.length);
  const topSteps=stepsOf(0);
  // (Or, as often as its prolation asks, its imitation a converging tempo canon (Astra's EC07/CF28: fugue-contracts.js
  // convergingCanon): the top playing its line slowest, from the phrase's downbeat, each imitating part the same line
  // faster, entering in turn, all striking its last note together and holding it to the phrase's end.)
  const prolation=Math.max(0,Math.min(1,Number(parameters.prolation)||0));
  const canon=imitators.length&&topSteps.length&&prolation>0&&seededSource(role.seed??0,`counterpoint:prolation:${materialOf(role)}`)()<prolation
    ?tempoCanon({rhythm:rhythmOf(0),imitators,length,group,meter,beatSeconds,barSeconds,tones,targetOf,topSteps,rules,strong,random:seededSource(role.seed??0,`counterpoint:prolation:ratio:${materialOf(role)}`)}):null;
  if(canon)canon.forEach((line,k)=>{lines[k?imitators[k-1].part:0]=line});
  else if(topSteps.length){
    const {line}=counterLine({against:[],rhythm:rhythmOf(0),steps:topSteps,rules,strong,random,self:imitators.map(({delay,transpose})=>({delay,transpose}))});
    lines[0]=line;
    for(const {part,delay,transpose,scoreDelay} of imitators)lines[part]=line.filter(note=>note.start+delay<length-1e-6).map(note=>({...note,scoreTime:(()=>{const shifted=readScoreTime({scoreTime:shiftScoreTime(note.scoreTime,scoreDelay)}),end=R.of(bars*groupsOf(meter).reduce((a,b)=>a+b,0)*(Number(meter.subdivision)||1));return scoreTime(shifted.at,shifted.end.min(end).sub(shifted.at),{axis:'phrase'})})(),pitch:note.pitch+transpose,start:note.start+delay,length:Math.min(note.length,length-note.start-delay)}));
  }
  for(let part=1;part<parts;part++){
    if(lines[part])continue;
    const steps=stepsOf(part);if(!steps.length){lines[part]=[];continue}
    lines[part]=counterLine({against:planned(),rhythm:rhythmOf(part),steps,rules,strong,random,above:false}).line;
  }
  for(let part=0;part<parts;part++)lines[part]??=[];
  const out=lines.map(line=>line.map(note=>({...scoreTimeFields(note),at:+(downbeat+note.start).toFixed(6),pitch:note.pitch,seconds:Math.max(.05,note.length*ARTICULATION),written:+note.length.toFixed(6),strong:strong(note.start)})));
  VOICES.set(key,out);if(VOICES.size>512)VOICES.delete(VOICES.keys().next().value);
  return out;
}
// A converging tempo canon among a counterpoint's voices (above), from the top's `rhythm` ([{start, length}], s, over the
// phrase's `length`) and its `imitators` [{part}] in order of entry. Its speeds are ratios the meter's notation writes
// exactly on its rhythm's lattice (exact-elongation.js elongationCandidates): the top's drawn from those that leave its
// source a bar or more and its imitators room -- each imitator the fastest-but-one, its ratio the largest that enters a
// felt group (`group`, s) or more after the voice before it, none faster than the source itself -- from the feasible ones
// only. The source is the top's rhythm over the phrase shortened by its ratio, its last onset the convergence. Each
// imitator moves into its own place by the harmony's degrees (canon-plan.js stepInCollection, a canon at the degree
// nearest its place: a convergence on a chord, not only an octave); the top planned against them all, each at its speed
// (counterLine's self). Its timing solved with its whole counterpoint (convergingCanon). -> [lines] (the top's, then each
// imitator's: [{pitch, start, length}], s), or null where none is feasible or its solver finds none.
function tempoCanon({rhythm,imitators,length,group,meter,beatSeconds,barSeconds,tones,targetOf,topSteps,rules,strong,random}){
  const sub=Number(meter.subdivision)||1,endTick=readScoreTime(rhythm.at(-1)).end;
  const G=rhythm.map(note=>readScoreTime(note).at.div(sub)).reduce((grid,t)=>lcm(grid,t.d),1);
  const candidates=elongationCandidates(meter,{sourceDivision:G});if(!candidates.length)return null;
  // (For a top's ratio: its source -- the rhythm's onsets within the phrase over it -- and its imitators' ratios, each
  // the largest a felt group's entry allows below the one before; none where one has no room.)
  const option=top=>{
    const span=length/top.ratio;if(span<barSeconds-1e-9)return null;
    const onsets=rhythm.filter(r=>r.start<span-1e-9);if(onsets.length<2)return null;
    const last=onsets.at(-1).start,source=onsets.map((r,k)=>({start:r.start,length:(onsets[k+1]?.start??span)-r.start,scoreTime:scoreTime(readScoreTime(r).at,(k+1<onsets.length?readScoreTime(onsets[k+1]).at:endTick.div(R.of(top.exact))).sub(readScoreTime(r).at),{axis:'phrase'})})),ratios=[top];
    for(const _ of imitators){const most=ratios.at(-1).ratio-group/last,next=candidates.findLast(c=>c.ratio<=most+1e-12);if(!next)return null;ratios.push(next)}
    return {source,ratios};
  };
  const feasible=candidates.filter(c=>c.ratio>1).map(option).filter(Boolean);if(!feasible.length)return null;
  const {source,ratios}=feasible[Math.floor(random()*feasible.length)],top=ratios[0].ratio,at=top*source.at(-1).start;
  const collection=tones,first=topSteps[Math.floor(topSteps.length/2)];
  // (Each imitator's degrees: of those that keep every move the top may make within the rules' widest (rules.leapMost:
  // a collection's degrees uneven, a move by degrees can widen; by octaves never), those that bring the top's middle
  // pitch nearest its own place.)
  const keeps=k=>topSteps.every(p=>topSteps.every(q=>Math.abs(p-q)>rules.leapMost+.05||Math.abs(stepInCollection(p,k,collection)-stepInCollection(q,k,collection))<=rules.leapMost+.05));
  const degreesOf=part=>{const want=first+targetOf(part)-targetOf(0),range=3*collection.length;
    return Array.from({length:2*range+1},(_,i)=>i-range).filter(keeps).reduce((best,k)=>best==null||Math.abs(stepInCollection(first,k,collection)-want)<Math.abs(stepInCollection(first,best,collection)-want)?k:best,null)};
  const maps=imitators.map(({part})=>{const k=degreesOf(part);return pitch=>stepInCollection(pitch,k,collection)});
  const entries=ratios.slice(1).map(r=>at-r.ratio*source.at(-1).start);
  const {line}=counterLine({against:[],rhythm:source.map(r=>({start:top*r.start,length:top*r.length,scoreTime:scaleScoreTime(r.scoreTime,ratios[0].exact)})),steps:topSteps,rules,strong,random,
    self:entries.map((delay,k)=>({delay,ratio:ratios[k+1].ratio/top,map:maps[k]}))});
  if(line.length!==source.length)return null;
  const beats=t=>t/beatSeconds,sourceLine=line.map((note,k)=>({pitch:note.pitch,start:readScoreTime(source[k]).at.div(sub).toNumber(),length:readScoreTime(source[k]).duration.div(sub).toNumber(),scoreTime:scaleScoreTime(source[k].scoreTime,new R(1,sub),{axis:'canon-source-beats'})}));
  const certified=convergingCanon({source:sourceLine,voices:ratios.map((r,v)=>({ratio:r.exact,map:v?maps[v-1]:null})),length:beats(length),group:beats(group),collection,rules,
    strong:t=>strong(t*beatSeconds),budget:{maxWork:CANON_WORK}});
  if(certified.status!=='OPTIMAL')return null;
  // (Each voice's notes at its solved entry and speed, its last held to the phrase's end, played as planned: the planner's
  // own law over them (fugue-contracts.js plannerLaw) is checked in development, never while it plays.)
  const voices=ratios.map((r,v)=>{const entry=valueOfExact(certified.entries[v])*beatSeconds,move=v?maps[v-1]:pitch=>pitch;
    return line.map((note,k)=>{
      const scaled=readScoreTime({scoreTime:scaleScoreTime(source[k].scoreTime,r.exact)}),start=R.of(certified.entries[v]).mul(sub).add(scaled.at),end=k===line.length-1?endTick:start.add(scaled.duration);
      return {scoreTime:scoreTime(start,end.sub(start),{axis:'phrase'}),pitch:move(note.pitch),start:entry+r.ratio*source[k].start,length:k===line.length-1?length-entry-r.ratio*source[k].start:r.ratio*source[k].length};
    })});
  return voices;
}
// The work a tempo canon's certificate may take (positive-warp.js's own default allowance).
const CANON_WORK=2000000;
const valueOfExact=text=>{const [n,d='1']=String(text).split('/');return Number(n)/Number(d)};
// The share of its written length a line's note sounds: its articulation, a performance choice apart from its rhythm
// (an elongation's exact ratio is its written lengths', never its sounding ones).
export const ARTICULATION=.97;
// The longest a player of `instrument` sustains one note (s) at `level`: a bowed string's whole bow at the speed its
// dynamic takes (bow.js BOW.speed: a violin's about 3 s at mf, 11 s at pp), a wind's full breath; another's, a wind's
// middling breath.
export const sustainOf=(instrument,level=.5)=>BOWED_INSTRUMENTS[instrument]?BOWED_INSTRUMENTS[instrument].lengthCm/BOW.speed[dynamicOf(level).dynamic]:WIND_INSTRUMENTS[instrument]?.phonationSeconds??8;
// The longest one breath of a wind player holds a note at `level`, in its most spending register, every bit of the breath
// spent (a coordinated hit's, before its general pause: wind-seat.js); a player that does not breathe its notes, Infinity.
export function breathHolds(instrument,level=.5){
  const kind=WIND_INSTRUMENTS[instrument];if(!kind)return Infinity;
  return kind.phonationSeconds/((WIND_LINE.breathDynamics[dynamicOf(level).dynamic]??1)*Math.max(1,...Object.values(kind.registers??{})));
}
// The octaves (semitones) a given line moves by toward `centre`: of those that keep every pitch in `compass` ({low,
// high}), the nearest; where none does (or no compass is known), the nearest to its mean. -> the shift (semitones).
export function givenShift(pitches,{centre,compass=null}){
  const mean=pitches.reduce((sum,p)=>sum+p,0)/pitches.length,nearest=12*Math.round((centre-mean)/12)||0;
  if(!compass||!Number.isFinite(compass.low)||!Number.isFinite(compass.high))return nearest;
  const low=Math.min(...pitches),high=Math.max(...pitches),from=Math.ceil((compass.low-low)/12),to=Math.floor((compass.high-high)/12);
  if(from>to)return nearest;
  let best=null;for(let k=from;k<=to;k++)if(best==null||Math.abs(12*k-nearest)<Math.abs(best-nearest))best=12*k;
  return best;
}
// A line's register about its pool's centre: its pool's width either side, at least half a phrase's range (line.js
// LINE.phraseRange), and wide enough to hold three of the harmony's pitches, the fewest a line is planned with -- a
// harmony of one pitch class or two spread over its octaves. -> [low, high], or null where it hears no harmony.
function lineRegister(role,pitches){
  const centre=Number(role.centre);if(!pitches.length||!Number.isFinite(centre))return null;
  const near=[...new Set(pitches.map(p=>+modulo(p,12).toFixed(6)))].flatMap(pc=>{const nearest=centre+modulo(pc-centre+6,12)-6;return [nearest-12,nearest,nearest+12]}).map(p=>Math.abs(p-centre)).sort((a,b)=>a-b);
  const half=Math.max(Number(role.width)||0,LINE.phraseRange/2,near[2]);
  return [centre-half,centre+half];
}
// A pool's motif, where its line has a lineage (string-section.js withLineage): drawn from its lineage's root, as a melodic
// player's is once (line.js chooseMotif), the most unlike the motifs of the lines above it -- the same in every phrase of
// the lineage, which planLine varies by its age (fitted again where a meter changes the bar's groups). -> a motif, or null.
const MOTIFS=new Map;
function lineageMotif(role,{meter,beatSeconds}){
  if(!role?.lineage)return null;
  // (Its groups and its felt beat's seconds as planLine reckons them: a bar's ticks over its felt beats.)
  const sub=Math.max(1,Math.round(Number(meter?.subdivision)||1)),tick=beatSeconds/sub,beats=feltBeats(meter,{secondsPerTick:tick}),groups=beatGroups(meter,beats);
  const felt=(Number(meter?.pulsesPerBar)||groups.reduce((sum,group)=>sum+group.count,0)*sub)*tick/Math.max(1,beats.length);
  const key=JSON.stringify([role.lineage.root,groups.map(group=>[group.first,group.count]),felt,(role.above??[]).map(other=>other.lineage?.root??null)]);
  if(MOTIFS.has(key))return MOTIFS.get(key);
  const heard=(role.above??[]).map(other=>lineageMotif(other,{meter,beatSeconds})).filter(Boolean);
  const {motif}=chooseMotif({groups,density:LINE.motifDensity,heard,random:seededSource(role.lineage.root,'motif'),beatSeconds:felt});
  MOTIFS.set(key,motif);if(MOTIFS.size>512)MOTIFS.delete(MOTIFS.keys().next().value);
  return motif;
}
// A line's density: its pool's own draw (string-section.js STRING_SPECIFICATION.parameters.line.density), from its seed
// where its role carries none.
const lineDensity=role=>{const drawn=Number(role.parameters?.density);return Number.isFinite(drawn)?drawn:poolParameters('line',1,role.seed??0)?.density};
// (Planned at `planBeat` (s), where its seat knows the beat its conductor plans for the section -- the tempo of its rhythm
// plan, its rubato aside -- and played at `beatSeconds`, the beat its phrase begins with, every time scaled by the two's
// ratio: a line's rhythm is the conductor's tempo's, which its arches only bend in time. Planned at an arch's tempo, a
// busy line's divisions (as many notes as fit a beat at its players' quickest: line.js divisionOf) had changed with the
// arch, its notes written elsewhere than without it.)
export function sectionLine(role,{downbeat,phrase,beatSeconds,meter,pool,instrument=null,planBeat=null,shortest=null}){
  const ratio=Number(planBeat)>0?beatSeconds/planBeat:1;
  if(Math.abs(ratio-1)<1e-9)return lineAt(role,{downbeat,phrase,beatSeconds,meter,pool,instrument,shortest});
  const planned=lineAt(role,{downbeat:0,phrase:phrase/ratio,beatSeconds:planBeat,meter,pool,instrument,shortest:shortest/ratio});if(!planned)return planned;
  const out=planned.map(note=>({...note,at:+(downbeat+note.at*ratio).toFixed(6),seconds:note.seconds*ratio,...(Number.isFinite(note.written)?{written:+(note.written*ratio).toFixed(6)}:{}),...(note.lag?{lag:note.lag*ratio}:{})}));
  if(planned.elongation)Object.defineProperty(out,'elongation',{value:planned.elongation});
  return out;
}
function lineAt(role,{downbeat,phrase,beatSeconds,meter,pool,instrument=null,shortest=null}){
  const grid=metricalGrid(meter,beatSeconds),bars=Math.max(1,Math.round(phrase/Math.max(1e-6,grid.barSeconds))),asked=Math.max(1,Number(role.elongation)||1);
  const pitches=(pool??[]).map(Number).filter(Number.isFinite),register=lineRegister(role,pitches);if(!register)return null;
  const key=JSON.stringify([role.seed,role.centre,role.width,role.level,shortest??null,role.elongation??1,role.inversion??0,Boolean(role.retrograde),Number(role.contour)||0,role.ending??null,role.tapeLine??null,role.themeLine??null,String(role.pool??''),role.lineage??null,lineDensity(role),(role.above??[]).map(other=>other.lineage?.root??null),+downbeat.toFixed(3),+phrase.toFixed(3),beatSeconds,pitches,instrument]);
  if(LINES.has(key))return LINES.get(key);
  const level=Math.max(0,Math.min(1,Number(role.level)||.5));
  const sub=Math.max(1,Math.round(Number(meter?.subdivision)||1)),pulsesPerBar=Number(meter?.pulsesPerBar)||groupsOf(meter).reduce((sum,g)=>sum+g,0)*sub;
  // (Its closing phrase, the piece's last, where its conductor says so (role.ending): planLine's final -- its
  // cadence on the tonic, held through its last group, and, as often as its motif draws it, the motif's return: the band's theme, as a
  // motif in this phrase's meter and harmony (line.js motifFromLine), where its conductor heard one.)
  const lineMeter={...meter,pulsesPerBar,subdivision:sub},ending=role.ending?(()=>{
    let band=null;try{band=role.ending.theme?motifFromLine(role.ending.theme,{meter:lineMeter,bpm:60/beatSeconds,pool:pitches,register}):null}catch{band=null}
    return {tonic:Number.isFinite(Number(role.ending.tonic))?Number(role.ending.tonic):null,...(band?{motif:band}:{})}})():null;
  // (Its motif the tape's, where its conductor gives it the tape's onsets (role.tapeLine, in bars from the phrase's
  // downbeat): their rhythm and steps, in its own meter and harmony -- line.js motifFromLine, in quarters.)
  const quartersPerBar=(Number(meter?.numerator)||groupsOf(meter).reduce((sum,g)=>sum+g,0))*4/(Number(meter?.denominator)||4);
  // (Or a theme's, where its conductor gives its phrase the theme MemoryBOT planned to return there (role.themeLine, in
  // quarters): before the tape's. Its notes on the theme's each say the stored note they play, `source`, for the seat's
  // report to MemoryBOT: section-seat.js remember.)
  const given=role.themeLine??role.tapeLine?.map(onset=>({at:onset.at*quartersPerBar,pitch:onset.pitch}));
  let givenMotif=null;try{givenMotif=given?motifFromLine(given,{meter:lineMeter,bpm:60/beatSeconds,pool:pitches,register}):null}catch{givenMotif=null}
  // (Its motif the one its lineage carries, where it has one and none is given it; its variation its lineage's age; its
  // density its pool's own draw.)
  const motif=givenMotif??lineageMotif(role,{meter:lineMeter,beatSeconds});
  // (Its quickest note its player's, where its instrument's model sets one longer than a line's own: LINE.shortest.)
  const choices=shortest>LINE.shortest?{...LINE,shortest}:LINE;
  const plan=bars=>planLine({register,pool:pitches,meter:lineMeter,bpm:60/beatSeconds,bars,...(motif?{motif}:{}),choices,
    density:lineDensity(role),loudness:level,phraseIndex:Number.isInteger(role.lineage?.age)?role.lineage.age:Math.max(0,Math.round(downbeat/Math.max(1e-6,phrase))),...(ending?{final:ending}:{}),random:seededSource(role.seed,'line')});
  // (Elongated exactly (Astra's elongationRatio, CFM-003, as their handoff contracts it): its source planned at the band's
  // tempo, in as many bars as the E asked spreads over the phrase, never replanned slower or sparser; its lattice the
  // positions its onsets and releases lie on (sourceLattice); the ratio its notation spells on that lattice nearest the E
  // asked, no longer than its players sustain its longest note (conducting/exact-elongation.js); every onset and release
  // that ratio times later, exactly, those past the phrase's end cut there; what it kept said with the line.)
  let planned=null,elongation=null;
  if(asked>1){
    const sourceBars=Math.max(1,Math.ceil(bars/asked-1e-9)),source=plan(sourceBars);
    if(source.status==='planned'&&source.notes.length){
      // (A note's written onset and release, in notated notes: its played time less its lag.)
      const exact=note=>{const {at,end}=readScoreTime(note);return [at.div(sub),end.div(sub)]},written=note=>exact(note).map(t=>t.toNumber());
      // (Its longest note as it is elongated: its written length, which the ratio scales -- not its played one, which a
      // note played short of its writing had made shorter, and its elongation then held past its players' sustain.)
      const G=source.notes.flatMap(exact).reduce((grid,t)=>lcm(grid,t.d),1),longest=Math.max(...source.notes.map(note=>{const [from,to]=written(note);return (to-from)*beatSeconds}));
      const chosen=G?nearestElongation(asked,elongationCandidates(meter,{sourceDivision:G}),{most:sustainOf(instrument,level)/Math.max(1e-6,longest)}):null;
      if(chosen?.ratio>1){
        const r=chosen.ratio,length=sourceBars*pulsesPerBar/sub,horizon=phrase/beatSeconds;
        const horizonTicks=Q(bars*pulsesPerBar);
        planned={...source,notes:source.notes.flatMap(note=>{
          const scaled=scaleScoreTime(note.scoreTime,chosen.exact),{at,end}=readScoreTime({scoreTime:scaled});
          if(at.ge(horizonTicks))return [];
          // (Its played time its written onset and release that ratio later, its lag kept as it was -- not its played
          // time scaled, which had stretched its lag and taken its release for its written end.)
          const [from,to]=written(note),lag=Number(note.lag)||0;
          return [{...note,start:r*from*beatSeconds+lag,end:Math.min(r*to,horizon)*beatSeconds+lag,
            scoreTime:scoreTime(at,end.min(horizonTicks).sub(at),{axis:'phrase'})}];
        })};
        elongation=Object.freeze({asked,ratio:chosen.exact,residual:asked-r,lattice:G,sourceBars,
          source:Object.freeze(source.notes.map(note=>Object.freeze(exact(note).map(x=>x.toString())))),
          drift:Object.freeze({notatedNotes:(r-asked)*length,truncated:Math.min(r*length,horizon)-Math.min(asked*length,horizon)}),articulation:ARTICULATION});
      }
    }
  }
  planned??=plan(bars);
  // (A return's line backwards, where it says so: each note's written time turned about the phrase's, its rhythm read
  // from the end -- a crab of the line its seed makes.)
  if(role.retrograde&&planned.status==='planned'&&planned.notes.length){
    const about=planned.notes.reduce((end,note)=>end.max(readScoreTime(note).end),R.ZERO).min(Q(bars*pulsesPerBar)),end=about.toNumber()*beatSeconds/sub;
    planned={...planned,notes:planned.notes.filter(note=>readScoreTime(note).at.lt(about)).map(note=>{
      const value=readScoreTime(note),clipped=scoreTime(value.at,value.end.min(about).sub(value.at),{axis:'phrase'});
      return {...note,scoreTime:reverseScoreTime(clipped,about),start:end-Math.min(end,note.end),end:end-note.start};
    }).sort((a,b)=>a.start-b.start)};
  }
  let notes=null;
  if(planned.status==='planned'&&planned.notes.length){
    const inversion=Math.max(0,Math.min(1,Number(role.inversion)||0)),first=planned.notes[0].pitch;
    // (Tilted along a tape's contour where its role says one: each note that share of its slope above or below, by its
    // place in the phrase, the harmony then placing it -- plex_clodbot tapeMaterial.)
    const tilt=Number(role.contour)||0;
    notes=planned.notes.map(note=>({...scoreTimeFields(note),at:+(downbeat+note.start).toFixed(6),pitch:note.pitch+inversion*(2*first-2*note.pitch)+tilt*(note.start/Math.max(1e-6,phrase)-.5),seconds:Math.max(.05,(note.end-note.start)*ARTICULATION),
      written:+(note.end-note.start).toFixed(6),...(note.lag?{lag:note.lag}:{}),...(note.cadence?{cadence:true}:{}),...(note.source?{source:note.source}:{})}));
    if(elongation)Object.defineProperty(notes,'elongation',{value:elongation});
  }
  LINES.set(key,notes);if(LINES.size>512)LINES.delete(LINES.keys().next().value);
  return notes;
}
// A part's improvisation on its line, as far as its conductor allows (role.latitude, 0 to 1; improvise.js): its figures
// planned at its phrase's downbeat from its part's seed, so its part's players play them together; each figure's
// pitches chosen as they sound, on its scale -- its conductor's region (role.region: its collection's steps, period and
// tonic, the harmony plan's), else the scale the chord heard lies in (harmonic-levels.js chordScale, as the jazz players hear one)
// -- with the chord sounding then and the voices heard (`heard(clock)`: {othersFrom, othersTo}, sounding-voices.js),
// within its player's compass. Null where it is given none.
function improvisation(role,{start,beatSeconds,meter=null,pool,compass,heard,shortest=SECTION_VOICES.shortest}){
  const latitude=Math.max(0,Math.min(1,Number(role.latitude)||0));if(!(latitude>0))return null;
  const key=voiceKey(role),plan=seededSource(role.seed??0,`improvise:${key}`),draw=seededSource(role.seed??0,`improvise pitch:${key}`),states=new Map;
  const reach=Math.max(12,(Number(role.width)||7)*2),low=Number.isFinite(compass?.low)?compass.low:(Number(role.centre)||60)-reach,high=Number.isFinite(compass?.high)?compass.high:(Number(role.centre)||60)+reach;
  const scaleOf=chord=>{
    if(Array.isArray(role.region?.system))return collectionPitches({system:role.region.system,period:Number(role.region.period)||12},{tonic:Number(role.region.tonic)||0,low,high});
    const classes=chordScale(TWELVE_TONE_LEVELS,[...new Set(chord.map(pitch=>+modulo(pitch,12).toFixed(6)))],{})?.set.pitchClasses??[],out=[];
    for(let octave=0;octave<=10;octave++)for(const pc of classes){const pitch=12*octave+pc;if(pitch>=low-1e-9&&pitch<=high+1e-9)out.push(pitch)}
    return out;
  };
  return {
    figured:notes=>figuredLine(notes,planFigures(notes,{latitude,start,beatSeconds,subdivision:Number(meter?.subdivision)||1,shortest,groups:meter?groupsOf(meter):null,random:plan}),{articulation:ARTICULATION}),
    // (`previous`: the pitch its part last sounded, the figure's note as the harmony placed it, which its first move leaves.)
    pitch(note,clock,previous=null){
      const chord=(pool()??[]).map(Number).filter(Number.isFinite),ladder=scaleLadder({collection:scaleOf(chord),chord,low,high});
      const {othersFrom=[],othersTo=[]}=(clock&&heard?.(clock))??{};
      const state=states.get(note.figure.id)??(Number.isFinite(previous)?{previous,moves:[]}:null);
      const {pitch,state:next}=figurePitch(note,{ladder,state,chord,othersFrom,othersTo,latitude,random:draw});states.set(note.figure.id,next);return pitch;
    }};
}
// `bandBeat`: the band's notated note (s), where the part counts a meter and tempo of its own: a coordinated hit is
// held in the conductor's beats, every section's together. `compass` ({low, high}): its player's, where known.
// Where a part's line is highest, its share of the phrase from `start` (its first note there): the apex its dynamics swell
// to and fall from (line.js phraseSwell), each of its notes told it (`peak`); null where it has no notes.
function peakOf(notes,start,phrase){
  if(!notes?.length)return null;let top=notes[0];for(const note of notes)if(note.pitch>top.pitch+1e-9)top=note;
  return Math.max(0,Math.min(1,(top.at-start)/Math.max(1e-6,phrase)));
}
// (`shortest`: its player's quickest note where its instrument's model sets one (wind-section.js windSeats: a brass
// instrument's tone's build-up on its lips), never under SECTION_VOICES.shortest.)
export function makeVoice(role,{random,start,beatSeconds,meter=null,pool,instrument='violin',bandBeat=beatSeconds,bandBeatTicks=null,compass=null,planBeat=null,heard=null,shortest:quickest=null,onScoreRevision=()=>{}}){
  const shortest=Math.max(SECTION_VOICES.shortest,Number(quickest)||0);
  const {texture,part,parts,centre,width,density,level}=role,band=position=>({centre:centre+3*arcAt(position),width:width*(.6+.4*arcAt(position))});
  const parameters=role.parameters??poolParameters(texture,parts,role.seed),groups=groupsOf(meter);
  const heldTo=(at,seconds,left,now)=>Math.max(.05,Math.min(seconds,left-(at-now)));
  const sub=Number(meter?.subdivision)||1,tick=beatSeconds/sub;
  const written=(at,end,window)=>scoreTime(at,R.of(end).min(R.of(window.end)).sub(R.of(at)),{axis:'phrase'});
  // The caller supplies musical window boundaries. The audio window can move under rubato without moving these.
  const windowOf=options=>{
    if(!options?.scoreWindow)throw new TypeError('A composing voice needs its symbolic scoreWindow');
    return {at:R.of(options.scoreWindow.at),end:R.of(options.scoreWindow.end)};
  };
  // (A section resting for the phrase: no notes. section-kinds.js: its conductor's rest.)
  if(texture==='tacet')return {events(){return []}};
  // (A line its conductor gives it, a fugue's entry (conducting/fugue-plan.js): each note at its quarters from the
  // formation's downbeat, the whole moved by octaves to the part's register, its contour and its tuning kept -- by the
  // octave nearest it of those that keep the whole line in its player's compass, where one does (givenShift; Astra's
  // tracker CF32: a voice given a player it can play), never note by note; by its conductor's octave for the voice where
  // it says one (plex_clodbot voiceOctave: the same in every phrase).)
  if(texture==='counterpoint'){
    // (Its part's voice of the pool's counterpoint (sectionCounterpoint), planned whole at the phrase's downbeat, each
    // note in the harmony sounding when it plays: on a strong position the harmony's nearest tone; on a weak one its own
    // where it is a step from the note before -- a passing or a neighbour tone -- else the harmony's nearest.)
    let planned=null,last=null,peak=null;const sounded=new Set;
    return {events(now,until,{position,left}){
      if(!planned){const phrase=Math.max(1e-6,now+left-start);planned=sectionCounterpoint(role,{downbeat:start,phrase,beatSeconds,meter,pool:pool()})?.[part]??[];peak=peakOf(planned,start,phrase)}
      const out=[];
      for(const [index,note] of planned.entries()){
        if(note.at<now-1e-9||note.at>=until-1e-9||sounded.has(index))continue;sounded.add(index);
        const near=followHarmony(note.pitch,pool(),[note.pitch-12,note.pitch+12]),stepwise=last!=null&&Math.abs(note.pitch-last)<=2.5+1e-9;
        const pitch=note.strong||!stepwise?near:note.pitch;last=pitch;
        out.push({...scoreTimeFields(note),at:note.at,pitch,seconds:heldTo(note.at,note.seconds,left,now),...(Number.isFinite(note.written)?{written:heldTo(note.at,note.written,left,now)}:{}),...(peak!=null?{peak}:{})});
      }
      return out;
    }};
  }
  if(texture==='line'&&Array.isArray(role.given)&&role.given.length){
    const quarter=beatSeconds*(Number(meter?.denominator)||4)/4,shift=Number.isFinite(role.givenOctave)?role.givenOctave:givenShift(role.given.map(note=>note.pitch),{centre,compass});
    // (Improvised on as far as its conductor allows: its given notes kept where they are, figures between them.)
    const required=role.motifUse?.required===true;
    const requiredPitches=required?requiredMotifPitches(role.given,{centre,compass,octave:role.givenOctave}):null;
    const short=required&&role.given.some((note,index)=>note.quarters*quarter<shortest||index>0&&(note.at-role.given[index-1].at)*quarter<shortest);
    const conflict=required&&(!requiredPitches||short);
    if(conflict){
      const fallback=role.motifFallback?makeVoice(role.motifFallback,{random,start,beatSeconds,meter,pool,instrument,bandBeat,bandBeatTicks,compass,planBeat,heard,onScoreRevision}):{events(){return []}};
      return {...fallback,motifConflict:{motifIds:role.motifUse.motifIds,winner:!requiredPitches?'physical-compass':'physical-minimum-note',compromised:'required-motif',resolution:role.motifFallback?'ordinary formation':'rest'}};
    }
    const quarterTicks=new R((Number(meter?.subdivision)||1)*(Number(meter?.denominator)||4),4);
    // (Each written where its line says it was written -- a remembered motif's players' quarters, motifs.js -- else at its
    // authored quarters: a fugue's subject's.)
    // (A stored motif's note, where it names one -- motif-insistence.js fitInsistedLines -- said as its `source`.)
    const given=role.given.map((note,index)=>({scoreTime:scoreTime(Q(note.written??note.at).mul(quarterTicks),Q(note.writtenQuarters??note.quarters).mul(quarterTicks),{axis:'phrase'}),at:start+note.at*quarter,pitch:required?requiredPitches[index]:note.pitch+shift,
      seconds:required?note.quarters*quarter:Math.max(.05,note.quarters*quarter*ARTICULATION),written:note.quarters*quarter,
      ...(typeof note.motifId==='string'&&Number.isInteger(note.index)?{source:Object.freeze({motifId:note.motifId,index:note.index})}:{})}));
    const improvising=required?null:improvisation(role,{start,beatSeconds,meter,pool,compass,heard,shortest}),notes=improvising?improvising.figured(given):given;
    let peak;
    return {events(now,until,{left,clock}={}){
      if(peak===undefined){peak=Number.isFinite(left)?peakOf(given,start,Math.max(1e-6,now+left-start)):null;if(peak!=null)notes.forEach(note=>{note.peak=peak})}
      return notes.filter(note=>note.at>=now-1e-9&&note.at<until-1e-9).map(note=>note.figure?{...note,pitch:improvising.pitch(note,clock)}:note);
    }};
  }
  if(texture==='line'){
    // (Its section's entry of a line the pool's sections share (conducting/entries.js): its delay and its pitch map, a
    // doubling, a planing or a canon of the line every section's voice plans alike.)
    // (Its octave chosen with every other section's once its line is planned -- every note of each section's entry in
    // its register, the line moved whole: entries.js jointEntries, Astra's CFM-004 -- else as drawn.)
    const entry=role.entry??null,delayBeats=entry?entryDelay(entry,groupsOf(meter)):0,delay=delayBeats*beatSeconds;let sounding=entry;
    const entered=pitch=>sounding?entryPitch(pitch,sounding,ladderOf(pool)):pitch;
    // (Improvised on as far as its conductor allows, a stretched line aside: its notes kept where they are, figures
    // between them; never a line its elongation spells exactly.)
    const improvising=improvisation(role,{start,beatSeconds,meter,pool,compass,heard,shortest});
    let planned=null,line=null,peak=null,last=null;const sounded=new Set;
    return {events(now,until,{position,left,clock}){
      const out=[];
      // (Its own rubato: behind or ahead of the beat as its pool's arch has it at that point of the phrase, together
      // again at its ends; a note ahead of its beat sounded in the window before its beat's, decided before it is drawn.)
      // (Ahead or behind, its pool's share of its phrase as drawn, no further than its conductor's ownTime.)
      const phrase=left/Math.max(1e-6,1-position),drawn=(Number(parameters?.rubato)||0)*phrase;
      const allowed=Number.isFinite(role.ownTime)?role.ownTime:SECTION_VOICES.leads,depth=Math.sign(drawn)*Math.min(Math.abs(drawn),allowed);
      const lagAt=t=>depth*Math.sin(Math.PI*Math.max(0,Math.min(1,position+(t-now)/Math.max(1e-6,phrase))));
      // (Its phrase planned whole, once, from the phrase's downbeat: sectionLine.)
      // (From the phrase's own downbeat, the voice's start: the window's time and the phrase's place disagree where a seat
      // catches up into its phrase.)
      // (No line where it hears no harmony at all: nothing is walked in its place -- the owner, 3 October 2026, "DON'T
      // HARDCODE FALLBACKS"; a register too narrow for the harmony is widened to it, sectionLine.)
      planned??=sectionLines(role,{downbeat:start,phrase:Math.max(1e-6,now+left-start),beatSeconds,meter,pool:pool(),instrument,planBeat,shortest:Number(quickest)||null})??[];
      {
        if(!line){line=delay?planned.map(note=>({...note,scoreTime:shiftScoreTime(note.scoreTime,Q(delayBeats).mul(Number(meter?.subdivision)||1)),at:+(note.at+delay).toFixed(6)})):planned;peak=peakOf(line,start,Math.max(1e-6,now+left-start));
          if(improvising&&!planned.elongation)line=improvising.figured(line);
          if(entry&&role.entries&&role.entryRegisters&&role.section&&planned.length)sounding=sharedEntries(role,{planned,start,beatSeconds,meter,pool:pool(),phrase:Math.max(1e-6,now+left-start)})?.[role.section]??entry}
        // (Each note once: in the window its time with its rubato falls in, or at once where its rubato moved it before
        // the window and its own time is still to come; in the harmony sounding then.)
        for(const [index,note] of line.entries()){
          if(note.at<start-1e-9||sounded.has(index))continue;
          const moved=note.at+lagAt(note.at);if(moved>=until||note.at<now-1e-9&&moved<now-1e-9)continue;
          // (Its rubato how it is played, not its rhythm: `lag`, the seconds it sounds after its planned time, which its
          // score leaves out -- written exactly, it had made nested tuplets of every shifted note.)
          const when=Math.max(now,moved),pitch=note.figure?improvising.pitch(note,clock,last):followHarmony(note.pitch,pool(),[note.pitch-12,note.pitch+12]);sounded.add(index);
          const lag=when-note.at+(Number(note.lag)||0);
          last=Number.isFinite(pitch)?pitch:note.pitch;
          out.push({...scoreTimeFields(note),at:when,pitch:entered(last),seconds:heldTo(when,note.seconds,left,now),...(Number.isFinite(note.written)?{written:heldTo(note.at,note.written,left,now)}:{}),...(Math.abs(lag)>1e-6?{lag:+lag.toFixed(6)}:{}),...(peak!=null?{peak}:{}),...(note.cadence?{cadence:true}:{}),...(note.source?{source:note.source}:{})});
        }
        return out;
      }
    }};
  }
  // (A coordinated hit (conducting/coordinated-events.js; its conductor's punctuation): the harmony's tone nearest the
  // part's place, struck on the formation's downbeat by every seat and held its beats, then nothing -- the general pause
  // -- to the formation's end.)
  if(texture==='hit'){
    let struck=false;
    return {events(now,until,options){
      const {position,left}=options,window=windowOf(options);
      if(struck||start>=until)return [];
      const tones=(pool()??[]).map(Number).filter(Number.isFinite);if(!tones.length)return [];struck=true;
      const {centre:c,width:w}=band(position),span=Math.max(12,w*2),target=c-span/2+span*(fromTop(part,parts)+.5)/parts;
      const candidates=[];for(let octave=1;octave<=8;octave++)for(const pc of new Set(tones.map(p=>modulo(p,12))))candidates.push(12*octave+pc);
      const at=Math.max(now,start),seconds=Math.max(.05,Math.min((Number(parameters?.beats)||1)*bandBeat,left-(at-now)));
      // (A fugue's voice its cadence's arrival, where its conductor chose one: plex_clodbot fugueInto.)
      const length=Q(parameters?.beats||1).mul(bandBeatTicks??sub);
      return [{scoreTime:written(window.at,window.at.add(length),window),at,pitch:Number.isFinite(Number(parameters?.pitch))?Number(parameters.pitch):nearestIn(candidates,target),seconds}];
    }};
  }
  if(texture==='chord'){
    // (Each tone held until the harmony moves it, its bow changes its players'; where its pool keeps a pulse, struck
    // again at the meter's positions that pulse sounds (pulseOf), each sounding its gate's share of the time to the next.)
    const pulse=pulseOf({meter,beatSeconds,start,pulse:Number(parameters?.pulse),seed:role.seed,pool:materialOf(role)}),gate=Math.max(.05,Math.min(1,Number(parameters?.gate)||1));
    // (No longer on one pitch than its listeners are projected to take (repetition.js: its conductor's tolerance,
    // role.repetition, else REPETITION): struck as often, or held as long, as it allows, the part moves to the chord's tone
    // nearest it within its place's reach -- a voice exchange, the harmony kept: Op. 3.28's brass had struck one chord
    // twenty times running, its last chord held 34 s.)
    const tolerance=repetitionOf(role.repetition??null);
    // (Struck again, never on the pitch it struck: each stroke the chord's next tone within its reach, walking up or down
    // and turning at its reach's edge, each part the other way from the part beside it -- the chord struck together, its
    // harmony kept, no part a motif of one repeated note (the owner, 5 October 2026, of Op. 3.30: motifs of nothing but
    // repeated notes were to stop: a lone oboe's pulsed chord had struck each tone three times,
    // its repetition tolerance's most, before moving on).)
    let dir=part%2?1:-1;
    const walk=(pitch,near)=>{
      const tones=[...new Set(near.map(p=>+p.toFixed(4)))].sort((a,b)=>a-b),others=tones.filter(p=>Math.abs(p-pitch)>.25);if(!others.length)return pitch;
      const k=tones.findIndex(p=>Math.abs(p-pitch)<.25);if(k<0)return nearestIn(others,pitch);
      if(!tones[k+dir])dir=-dir;return tones[k+dir]??pitch;
    };
    // (Struck off its pulse only where the harmony moves: its place in the band drifting, it keeps its tone to its next
    // stroke -- re-voiced as its reach moved, it had struck again a tick before its pulse, a tone twice.)
    let held=null,next=pulse?pulse.pointAfter(start):null,run=null,harmony=null,authored=null,serial=0;
    const compose=(at,end,window)=>{
      if(authored&&R.of(at).gt(readScoreTime(authored).at)&&R.of(at).lt(readScoreTime(authored).end)){
        authored={...authored,scoreTime:written(readScoreTime(authored).at,at,window)};
        onScoreRevision(authored);
      }
      authored={scoreId:String(serial++),scoreTime:written(at,end,window)};
      return authored;
    };
    const goOn=(pitch,at,near)=>{
      if(run&&Math.abs(run.pitch-pitch)<.25&&!mayGoOn(run,at,tolerance)){const others=near.filter(p=>Math.abs(p-pitch)>.25);if(others.length)pitch=nearestIn(others,pitch)}
      run=run&&Math.abs(run.pitch-pitch)<.25?{...run,strikes:run.strikes+1}:{pitch,since:at,strikes:1};
      return pitch;
    };
    return {events(now,until,options){
      const {position,left}=options,window=windowOf(options);
      const tones=(pool()??[]).map(Number).filter(Number.isFinite);if(!tones.length)return [];
      const {centre:c,width:w}=band(position),span=Math.max(12,w*2),target=c-span/2+span*(fromTop(part,parts)+.5)/parts;
      const classes=[...new Set(tones.map(p=>modulo(p,12)))],candidates=[];
      for(let octave=1;octave<=8;octave++)for(const pc of classes)candidates.push(12*octave+pc);
      // (Voice-led: each part to the harmony's tone nearest the one it holds, within reach of its place in the band --
      // an inner voice moving by step as the chords change, never every part leaping to its place's nearest tone at once,
      // in parallel; its first from its place.)
      const reach=Math.max(5,span/parts),near=candidates.filter(p=>Math.abs(p-target)<=reach+1e-9),key=classes.map(pc=>+pc.toFixed(4)).sort((a,b)=>a-b).join(',');
      const moved=key!==harmony;harmony=key;
      let pitch=held==null||!near.length?nearestIn(candidates,target):moved?nearestIn(near,held):held;const out=[];
      if(!pulse){
        // (Held: past its tolerance, moved to its neighbour, the note before let go as it begins.)
        if(held===pitch&&run&&!mayGoOn(run,now,tolerance))pitch=goOn(pitch,now,near);
        if(held!==pitch){if(!run||Math.abs(run.pitch-pitch)>=.25)run={pitch,since:now,strikes:1};held=pitch;return [{...compose(window.at,window.end,window),at:now,pitch,seconds:heldTo(now,left,left,now)}]}
        return [];
      }
      while(next.at<now-1e-9)next=pulse.pointAfter(next.at+1e-6);
      // (The harmony moved off the pulse: struck where it moved.)
      // (Each stroke written to the next, its gate how it is played: section-seat.js writtenTicks.)
      if(held!==pitch&&next.at>now+1e-9){pitch=goOn(pitch,now,near);out.push({...compose(window.at,next.scoreAt,window),at:now,pitch,seconds:heldTo(now,Math.max(.05,gate*(next.at-now)),left,now)})}
      // (A pulse's point at the window's end the next window's, as pointAfter takes it: one a rounding before it, struck
      // here, had been struck again in the next window where the harmony moved there -- Op. 3.31's cellos, two strokes on
      // one tick, one of them lost from the score.)
      for(;next.at<until-1e-9;next=pulse.pointAfter(next.at+1e-6)){
        if(left<=next.at-now||next.scoreAt.ge(window.end))break;
        const after=pulse.pointAfter(next.at+1e-6);pitch=goOn(run&&Math.abs(run.pitch-pitch)<.25?walk(pitch,near):pitch,next.at,near);
        out.push({...compose(next.scoreAt,after.scoreAt,window),at:next.at,pitch,seconds:heldTo(next.at,Math.max(.05,gate*(after.at-next.at)),left,now)});
      }
      held=pitch;
      return out;
    }};
  }
  if(texture==='figuration'){
    // (A compound melody (compound-melody.js): the pool's figure a walk over as many voices as it walks tones
    // (figuration.js), each voice led from chord to chord by the least motion within the part's place in the band, as a
    // chorale's voices are -- an Alberti bass's bass, inner voice and top, an arpeggio's chord tones, a trill's two --
    // the walk planned a bar at a time from where the last ended, as fast as its rate's share of its players' quickest
    // notes, and each note's voice sounding the pitch it is led to when the note sounds, so the figure follows a harmony
    // that moves inside its bar; every part of the pool the same walk, each in its own place.)
    const {positions,barSeconds,barTicks}=metricalGrid(meter,beatSeconds),most=1/shortest,n=Math.max(1,Math.round(Number(parameters.tones)||3)),queue=[];
    // (Its walk over the same voices no longer than its listeners are projected to take one pitch's going on (repetition.js
    // seconds): then each voice moved to the chord tone above it in its place, the next inversion, the harmony kept --
    // Op. 3.28's figuration had walked one two-note cell 32 times running.)
    const tolerance=repetitionOf(role.repetition??null),inverted=(voices,tones)=>voices.map(v=>tones.find(t=>t>v+.25)??tones.find(t=>Math.abs(t-v)>.25)??v).sort((a,b)=>a-b);
    let next=start,barIndex=0,voices=null,since=start;
    return {events(now,until,options){
      const {position,left}=options,window=windowOf(options);
      const {centre:c,width:w}=band(position),span=Math.max(12,w*2),low=c-span/2+span*fromTop(part,parts)/parts,high=low+Math.max(12,span/parts);
      const classes=[...new Set((pool()??[]).map(Number).filter(Number.isFinite).map(p=>+modulo(p,12).toFixed(6)))],chordTones=[];
      for(let octave=1;octave<=8;octave++)for(const pc of classes)chordTones.push(12*octave+pc);
      const tones=chordTones.filter(p=>p>=low-1e-9&&p<=high+1e-9).sort((a,b)=>a-b);
      if(tones.length)voices=voices?leadVoices(voices,tones):spreadVoices(tones,n);
      while(next<until&&left>next-now){
        const seconds=Math.min(barSeconds,left-(next-now));
        if(!voices?.length||!(seconds>.05)){next+=barSeconds;barIndex++;continue}
        if(next-since>=tolerance.seconds-1e-9&&tones.length>1){voices=inverted(voices,tones);since=next}
        const walk=figure({set:voices.map((_,k)=>k),positions,barSeconds,barTicks,scoreStart:barIndex*barTicks,scoreEnd:R.of((barIndex+1)*barTicks).min(window.end),start:next,seconds,rate:(parameters.rate??.5)*most,shortest,tones:voices.length,direction:parameters.direction,turn:parameters.turn,anchor:parameters.anchor,random});
        for(const note of walk)if(note.at>=now-1e-9)queue.push({...scoreTimeFields(note),at:note.at,voice:note.pitch,seconds:note.seconds});
        next+=barSeconds;barIndex++;
      }
      const out=[];
      while(queue.length&&queue[0].at<until-1e-9){const note=queue.shift();if(voices?.[note.voice]!=null)out.push({...scoreTimeFields(note),at:note.at,pitch:+voices[note.voice].toFixed(4),seconds:note.seconds})}
      return out;
    }};
  }
  if(texture==='micropolyphony'){
    // mass_clodbot's canon: one cantus from the seed of the pool (every part the same), each part in its own division of
    // the beat and a little slower than the one before, entering at its share of the cantus's first note, so that every
    // part has entered within it.
    const {divisions,drift,cantusNotes}=parameters,cantusRandom=seededSource(role.seed,`${materialOf(role)}:cantus`),ladder=ladderOf(pool),cantus=[];
    let index=ladder.indexOf(nearestIn(ladder,centre));
    for(let k=0;k<cantusNotes;k++){cantus.push(ladder[index]);const step=cantusRandom()<.5?-1:1,to=index+step;index=Math.abs((ladder[to]??ladder[index])-centre)<=width/2?clamp(to,0,ladder.length-1):clamp(index-step,0,ladder.length-1)}
    // (Its grid: its share of the divisions from two to as many as its beat holds playable notes; a whole number said by
    // an older conductor, as it is.)
    const share=divisions[part%divisions.length],most=Math.max(2,Math.floor(beatSeconds/shortest+1e-9));
    const division=share>1?share:Math.round(2+share*(most-2));
    const groupBeats=groups.reduce((sum,g)=>sum+g,0)/groups.length,unit=beatSeconds/division;
    const steps=Math.max(1,Math.round(groupBeats*division*(1+drift*part))),length=steps*unit,scoreLength=new R(steps*sub,division);
    // (Its entry on its own grid too, the nearest of its divisions to its share: entered between two of them, every note
    // after it was written between them -- Op. 3.29's contrabasses, septuplets in quintuplets in the bar's own tuplet.)
    const entry=Math.round(part/parts*groupBeats*division),scoreEntry=new R(entry*sub,division);
    let next={at:start+entry*unit,index:0};
    return {events(now,until,options){
      const {left}=options,window=windowOf(options);
      const out=[];
      while(next.at<until-1e-9){
        // (Written its whole step, sounding a little less of it: Op. 3.29's basses had been written 98 per cent of a quintuplet.)
        const scoreAt=scoreEntry.add(scoreLength.mul(next.index));
        if(scoreAt.ge(window.end))break;
        if(next.at>=now-1e-9)out.push({scoreTime:written(scoreAt,scoreAt.add(scoreLength),window),at:next.at,pitch:cantus[next.index%cantus.length],seconds:heldTo(next.at,length*.98,left,now)});
        next={at:next.at+length,index:next.index+1};
      }
      return out;
    }};
  }
  if(texture==='cluster'){
    // The parts spread evenly across the band as the formation begins, each pitch where it falls (between the keys too),
    // held to the phrase's end, its bow changes its players'.
    let first=true;
    return {events(now,until,options){
      const {position,left}=options,window=windowOf(options);
      if(!first)return [];first=false;
      const {centre:c,width:w}=band(position);
      return [{scoreTime:written(window.at,window.end,window),at:now,pitch:+(c-w/2+w*(fromTop(part,parts)+.5)/parts).toFixed(4),seconds:heldTo(now,left,left,now)}];
    }};
  }
  if(texture==='glissandi'){
    // Xenakis's: each glissando from the last one's pitch, its speed normal about none (the pool's spread, semitones a
    // second), its length drawn in the pool's range; kept within the band by turning back at its edge; a rest now and
    // then as the pool is sparser (density).
    const {spread,seconds:lengths}=parameters;
    // Choose musical cells first. The physical duration range bounds the composer's count of ticks; it is not a
    // performed interval to be rounded back into notation.
    const least=Math.max(1,Math.ceil(lengths[0]/tick)),most=Math.max(least,Math.floor(lengths[1]/tick));
    let next=Math.floor(random()*sub),from=centre+(random()*2-1)*width/2;
    return {events(now,until,options){
      const {position,left}=options,window=windowOf(options);
      const out=[];
      while(start+next*tick<until-1e-9&&R.of(next).lt(window.end)){
        const {centre:c,width:w}=band(position),count=least+Math.floor(random()*(most-least+1)),seconds=count*tick,at=start+next*tick;
        let to=from+normalFrom(random)*spread*seconds;
        if(to>c+w)to=2*(c+w)-to;if(to<c-w)to=2*(c-w)-to;to=clamp(to,c-w,c+w);
        if(at>=now-1e-9){const held=heldTo(at,seconds,left,now);out.push({scoreTime:written(next,next+count,window),at,pitch:+to.toFixed(4),from:+from.toFixed(4),seconds:held,...(parameters.hold>0?{hold:parameters.hold}:{})})}
        from=to;next+=count+(random()>clamp(density,0,1)?Math.floor(random()*count):0);
      }
      return out;
    }};
  }
  // A stochastic rhythm: geometrically distributed counts of the meter's ticks, the discrete counterpart of Poisson
  // arrivals. Density and pulse choose the composed cells. A cell's written length is independent of its sound's
  // decay; the player's seconds below affect only playback.
  const plucked=parameters.seconds,pulse=pulseOf({meter,beatSeconds,start,pulse:Number(parameters?.pulse),seed:role.seed,pool:materialOf(role)}),pull=Math.max(0,Math.min(1,Number(parameters?.pulse)||0));
  const gap=()=>Math.max(1,Math.ceil(-Math.log(Math.max(1e-12,random()))/(Math.max(.05,density)*tick)));
  const positionAfter=at=>pulse&&random()<pull?pulse.pointAfter(start+at*tick).scoreAt.toNumber():at;
  // (A pluck written to the next, the whole ticks of an eighth at most -- its beat where that is shorter, a tick at the
  // least -- a rest after it: a pizzicato is never written held.)
  const pluck=Math.max(1,Math.min(sub,Math.floor(sub*(Number(meter?.denominator)||4)/8)));
  let next=positionAfter(gap());
  return {events(now,until,options){
    const {position,left}=options,window=windowOf(options);
    const out=[];
    while(start+next*tick<until-1e-9&&R.of(next).lt(window.end)){
      const {centre:c,width:w}=band(position),at=start+next*tick,after=positionAfter(next+gap());
      if(at>=now-1e-9&&left>at-now)out.push({scoreTime:written(next,R.of(after).min(R.of(next).add(pluck)),window),at,pitch:+(c+(random()*2-1)*w/2).toFixed(4),seconds:plucked,pluck:true});
      next=after;
    }
    return out;
  }};
}
