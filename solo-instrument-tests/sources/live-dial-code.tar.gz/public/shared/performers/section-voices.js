import {Rational as R,lcm} from '../../transcript/rational.js';
import {scoreTime,readScoreTime,shiftScoreTime,scaleScoreTime,reverseScoreTime,scoreTimeFields} from '../score-time.js';
import {authoredFraction as Q} from './rhythm-cell.js';
import {requiredMotifPitches} from '../motif-insistence.js';
// A section's parts as their players play them (Musebots 3.0: a section is many playing bots, each seat a player of its
// instrument; the owner, 1 October 2026). A formation (string-section.js formationPlan) gives every seat a role: its
// pool's texture, its part among the pool's parts, the pool's centre, width, density and level, its texture's
// parameters, and the pool's seed. Each player makes its part's voice from them (makeVoice) and plays it: a part shared
// by several seats is the same material in each of their bots (its seed and number), so its players are together, each
// with its own few cents and milliseconds (playerOffsets); a seat alone in its part improvises it within the pool's
// constraints. Taken from strings_clodbot (archived), whose seats were a bot's; its numbers are now the formation's
// (the conductor's, from its section's specification) or follow from the meter and the instrument:
//   - a line is planned a phrase at a time as the melodic players' are (line.js planLine: its idea, repeated and varied,
//     its continuation's fragments climbing to its apex, its cadence), each note sounded in the harmony of its moment
//     (followHarmony); where its register holds too few of the harmony's pitches, a walk by steps, a note a group of the
//     meter;
//   - a held note is the part's, its bowing the player's: each seat changes bow where its own bow runs out (bowSeconds:
//     the instrument's bow over its speed at the part's dynamic, bow.js BOW.speed, bowed-line.js
//     BOWED_LINE.fastestShare), so each player of a part changes bow at a time of its own, as orchestras' free bowing
//     does (bots/lib/modules/section-seat.js);
//   - every other texture a point in the texture space, made by one process (processVoice): a chord's, a canon's, a
//     cluster's, a heterophony's, glides' and points' notes, and those of every point between them.
import {seededSource,arcAt,poolParameters} from './string-section.js';
import {figure} from './figuration.js';
import {BOWED_INSTRUMENTS,BOWED_LINE} from './bowed-line.js';
import {BOW,bowSpeedAt} from './bow.js';
import {LINE,planLine,followHarmony,linePitches,motifFromLine,chooseMotif,beatGroups} from './line.js';
import {velocityBeyond} from '../dynamics.js';
import {feltBeats} from '../meter-tactus.js';
import {WIND_INSTRUMENTS,WIND_LINE} from './wind-line.js';
import {entryDelay,entryPitch,jointEntries} from '../conducting/entries.js';
import {elongationCandidates,nearestElongation,sourceLattice,fractionOf} from '../conducting/exact-elongation.js';
import {COUNTERPOINT,counterLine,drawnRules,heardCost} from '../conducting/counterpoint.js';
import {stepInCollection} from '../conducting/canon-plan.js';
import {convergingCanon} from '../conducting/fugue-contracts.js';
import {leadVoices,spreadVoices} from './compound-melody.js';
import {planFigures,figuredLine,figurePitch,scaleLadder} from './improvise.js';
import {collectionPitches} from '../collection-space.js';
import {chordScale,TWELVE_TONE_LEVELS} from '../estimation/harmonic-levels.js';
import {repetitionOf,mayGoOn} from '../repetition.js';
import {pointOfRole,drawnPoint,familyOf,OWN_DIVISIONS} from '../texture-space.js';
import {fnv1a,FNV_OFFSET} from '../fnv1a.js';
import {FIORITURA,planFioritura,ornamentPitches} from './fioritura.js';

// A float's rounding, never a choice of the music's: times (s), pitches (semitones) and shares nearer than this are one.
const EPSILON=1e-9;
// A time's grain (s): the microsecond a note's time is written to (toFixed(6)), times nearer than it one, and the least
// span a phrase or a bar is divided by.
const INSTANT=1e-6;
// An octave's semitones (pitch's unit, MIDI note numbers).
const OCTAVE=12;
// How many of each it keeps made, the least recently used let go first: a harmony's ladders and a pool's lines,
// counterpoints, voices and motifs (`plans`), and its parts' ensembles heard (`ensembles`, each many voices' copies).
const KEPT=Object.freeze({plans:512,ensembles:64});
// A role's key's second hash, seeded apart from its first by the golden ratio's 32 bits, so that two roles one hash
// takes for each other the other tells apart.
const SECOND_SEED=0x9e3779b9;

// What is never begun: a note shorter than a bow can draw before its phrase ends (s: two of its changes of direction,
// bow.js BOW.changeSeconds), so the next formation's downbeat is its own.
export const SECTION_VOICES=Object.freeze({shortest:2*BOW.changeSeconds,
  // A line's own rubato where no conductor says how far its own time may stray (s): a melody's lead, at most (plex_clodbot
  // PLEX_CLODBOT.ownTime, its sources). (The owner, 5 October 2026, of Op. 3.29: "The music sounds FAR more complex in
  // terms of timing than the score appears at the beginning" -- a fugue's oboe a third of a second ahead of the strings
  // mid-phrase; and 10 October 2026, of Op. 3.37: "The players' timing is also far too ragged. Rein that in" -- 50 ms
  // before.)
  leads:.02});
// A held note no motif asks for played the softer the longer it is held (the owner, 4 October 2026, of Op. 3.25:
// "sustained notes, when they are not part of an intended motif, need a penalty on their loudness, as they're often being
// blared over other, more interesting, things"): `dbPerDoubling` under its phrase's level for each doubling of its length
// past a beat, `most` at the most (ours: a note four beats long 4 dB under, sixteen 8). A theme its conductor gives
// (role.given: a fugue's subject and answer, role.themeLine, a required motif) is held as loud as it is written.
export const SUSTAIN=Object.freeze({dbPerDoubling:2,most:8});
export function sustainDb(seconds,beatSeconds,role=null){
  if(!(seconds>beatSeconds)||!(beatSeconds>0)||role?.given?.length||role?.themeLine!=null||role?.motifUse||role?.texture==='hit')return 0;
  return -Math.min(SUSTAIN.most,SUSTAIN.dbPerDoubling*Math.log2(seconds/beatSeconds));
}
const clamp=(x,low,high)=>Math.max(low,Math.min(high,x));
const modulo=(x,n)=>((x%n)+n)%n;
// A normal draw (Box-Muller) from a source.
const normalFrom=random=>Math.sqrt(-2*Math.log(Math.max(1e-12,random())))*Math.cos(2*Math.PI*random());
// A part's voice: a line's whole pool one voice, else each part its own.
// (A pool's material its own, or another's it plays again -- a section recalled re-orchestrated, plex_clodbot recall:
// the same seed and the same material key make the same notes, in this pool's register.)
export const materialOf=role=>role.material??role.pool;
export const voiceKey=role=>role.texture==='line'?materialOf(role):`${materialOf(role)}:${role.part}`;
// A pitch into a seat's compass by octaves (a basses' octave below the cellos, as orchestras double).
export const intoCompass=(pitch,seat)=>{let p=pitch;while(p<seat.low)p+=OCTAVE;while(p>seat.high)p-=OCTAVE;return p<seat.low?null:p};
// A part's dynamic and velocity at its level, as a line's are (line.js LINE); a level under 0 or over 1 in the
// uncomfortable range beyond ppp or fff (dynamics.js velocityBeyond), its dynamic for its players' tables the scored
// range's end there.
export function dynamicOf(level){
  if(Number(level)<0||Number(level)>1)return {dynamic:Number(level)<0?LINE.dynamics[0]:LINE.dynamics.at(-1),velocity:velocityBeyond(level)};
  const dynamic=LINE.dynamics[Math.min(LINE.dynamics.length-1,Math.max(0,Math.floor(level*LINE.dynamics.length)))];
  return {dynamic,velocity:LINE.velocity[dynamic]};
}
// How long a held note's bow lasts (s) on `instrument` at `velocity`, as it is bowed (its phrase's curve and its
// accents', never its part's level alone): its bow's length over a speed drawn between its velocity's (bow.js
// bowSpeedAt) and the fastest it takes. (From its part's level, a cluster at fff eased to pp as it was held had changed
// bow every second, a seventh of its bow a stroke: Op. 3.36's violas, 10 October 2026.)
export function bowSeconds(instrument,velocity,random){
  const lengthCm=(BOWED_INSTRUMENTS[instrument]??BOWED_INSTRUMENTS.violin).lengthCm;
  return lengthCm/(bowSpeedAt(velocity)*(1+random()*(BOWED_LINE.fastestShare-1)));
}
// The meter's groups, in its notated notes (a meter that names none, one group a bar).
const groupsOf=meter=>{const groups=(meter?.groups??[]).map(Number).filter(n=>n>0);return groups.length?groups:[Math.max(1,Number(meter?.numerator)||1)]};

// ---- Voices: a part's material, deterministic from its seed ----------------------------------------------------------
// Each: {events(now, until, {position, clock, spt, left}) -> [{at, pitch, seconds, from?, pluck?}]}: its notes starting
// in [now, until). The pool heard (`pool()`) is every bot's alike at a tick, so a part's harmony is too.
// The equal division a set of classes lies on: the fewest steps an octave, twelve or more, holding every one of them (to
// a thousandth of a semitone: a pool's pitches are said to four places); null for a tuning of no division up to 72.
function divisionOf(classes){
  for(let n=OCTAVE;n<=72;n++)if(classes.every(pc=>Math.abs(pc-Math.round(pc*n/OCTAVE)*OCTAVE/n)<1e-3))return n;
  return null;
}
// A pool's ladder: its classes where it has a collection's (five or more); else its tones among the twelve of its own
// tuning -- each of the twelve moved onto the division its tones lie on (a 31-step harmony's nearest steps), the pool's
// own tone where it holds one within a quarter tone of it -- never the twelve equal steps under a tuning of its own. Once
// a harmony heard (every voice of a pool asks it a tick, as the harmony moves only now and then): frozen.
const LADDERS=new Map;
function ladderOf(pool){
  const tones=pool()??[],key=JSON.stringify(tones);if(LADDERS.has(key))return LADDERS.get(key);
  const heard=[...new Set(tones.map(Number).filter(Number.isFinite).map(p=>+modulo(p,OCTAVE).toFixed(6)))].sort((a,b)=>a-b);
  const n=heard.length>=5?null:divisionOf(heard),near=k=>n?+(Math.round(k*n/OCTAVE)*OCTAVE/n).toFixed(6):k;
  const twelve=Array.from({length:OCTAVE},(_,k)=>heard.find(own=>Math.min(modulo(own-k,OCTAVE),modulo(k-own,OCTAVE))<.5)??near(k));
  const classes=heard.length>=5?heard:[...new Set([...heard,...twelve].map(pc=>+modulo(pc,OCTAVE).toFixed(6)))].sort((a,b)=>a-b),out=[];
  for(let octave=1;octave<=8;octave++)for(const pc of classes)out.push(OCTAVE*octave+pc);
  const ladder=Object.freeze(out.sort((a,b)=>a-b));LADDERS.set(key,ladder);if(LADDERS.size>KEPT.plans)LADDERS.delete(LADDERS.keys().next().value);
  return ladder;
}
const nearestIn=(list,target)=>list.reduce((best,p)=>Math.abs(p-target)<Math.abs(best-target)?p:best,list[0]);
// A position's metrical weight from the meter's own hierarchy, its four levels weighted down from the bar's start by
// quarters: 1 the bar's start, 3/4 a group's, 1/2 a notated note's, 1/4 a subdivision's.
const METRIC_LEVELS=['bar','group','note','subdivision'];
export const METRIC_WEIGHTS=Object.freeze(Object.fromEntries(METRIC_LEVELS.map((level,k)=>[level,1-k/METRIC_LEVELS.length])));
// The bar's positions, each with its metrical weight (METRIC_WEIGHTS); and the bar's length. -> {positions [{at (s from
// the bar's start), weight}], barSeconds}.
export function metricalGrid(meter,beatSeconds){
  const groups=groupsOf(meter),sub=Math.max(1,Math.round(Number(meter?.subdivision)||1)),unit=beatSeconds/sub,positions=[];let note=0;
  const {bar,group:grouped,note:noted,subdivision}=METRIC_WEIGHTS;
  groups.forEach((size,group)=>{for(let n=0;n<size;n++,note++)for(let s=0;s<sub;s++)positions.push({scoreAt:String(note*sub+s),at:(note*sub+s)*unit,weight:s?subdivision:n?noted:group?grouped:bar})});
  return {positions,barSeconds:note*beatSeconds,barTicks:note*sub};
}
// Whether a position of `weight` sounds at a pulse p: none at 0; the meter's levels coming in in turn as p rises, the
// bar's starts first and every subdivision at 1, each position of a level as p passes its own draw (`draw`, [0, 1),
// the same each bar: a pattern a pulse keeps, as a groove does). Every state between two pulses is one.
export const pulsed=(weight,pulse,draw)=>Math.max(0,Math.min(1,(pulse-(1-weight))/.25))>draw;
// A pool's pulse: its positions in a bar, those that sound at its pulse (each position's draw its pool's, so its parts
// strike together), from `start` (s) bar by bar. -> {at(k): the k-th sounding position's time, after(t): the first at or
// after t} or null where nothing sounds.
function pulseOf({meter,beatSeconds,start,pulse,seed,pool}){
  if(!(pulse>0)||!(beatSeconds>0))return null;
  const {positions,barSeconds}=metricalGrid(meter,beatSeconds),on=positions.filter((position,k)=>pulsed(position.weight,pulse,seededSource(seed??0,`pulse:${pool}:${k}`)()));
  if(!on.length)return null;
  const barTicks=positions.length;
  const pointAfter=t=>{const bar=Math.max(0,Math.floor((t-start)/barSeconds-EPSILON));for(let b=bar;;b++)for(const position of on){const at=start+b*barSeconds+position.at;if(at>=t-EPSILON)return {at,scoreAt:R.of(b*barTicks).add(position.scoreAt)}}};
  return {pointAfter,after:t=>pointAfter(t).at};
}
// A part's voice. `random`: the part's source (its seed and number); `start` (s): the formation's downbeat;
// `beatSeconds`: the meter's notated note; `meter`: the meter it began in; `pool()`: the harmony heard; `instrument`: the
// player's (bowed-line.js), whose bow sets a held note's length.
// (A part's place from the top: the front chairs take the higher parts, and within a desk its odd-numbered, outside
// player the upper -- as divisi is written, a desk's two lines never crossing on its staff: the owner, 1 October 2026,
// "there should be a preference for the odd-numbered desk of a pair to have the higher part ... to avoid absurd
// conflicts on the staves". partsOf numbers parts from the front chair.)
const fromTop=(part,parts)=>parts-1-part;
// A section's line for a phrase, planned whole as the melodic players' lines are (line.js planLine): from its pool's
// seed (every seat of the pool the same line), in a register about its centre an octave and more wide, its density with
// its level (a soloist's, its pool its own, busier), elongated (its phrase planned in that many times fewer bars, each
// note that many times longer, exactly -- but never longer than its player sustains a note, one bow at its slowest or
// one breath, the ratio held to it; the owner, 2 October 2026: "tape elongation is more OK than 'simulated orchestral'
// extreme breath-length") and inverted (each pitch that share of the way to its mirror about the phrase's
// first) and played backwards (a return's crab) as its role says. Planned once a phrase for all its seats (a pool's
// seats ask alike). -> [{at (s), pitch,
// seconds (sounding), written? (s: an elongated note's written length)}], or null where its register holds too few of
// the harmony's pitches; an elongated line's `elongation` (not enumerable): {asked, ratio ('p/q'), residual (asked -
// ratio), lattice (its source's G), sourceBars, source (its notes' written onsets and releases, notated notes, exact:
// 'n/d'), drift: {notatedNotes (its whole source's end against the E asked's), truncated (within the phrase)},
// articulation}.
const LINES=new Map;
// A pool's parts as voices, planned together (the owner, 3 October 2026: "Move toward considering textures primarily in
// terms of counterpoint"; the whole system had "a tendency to just repeat chords over and over"): each part a line of
// its own in its own place in the pool's band -- the top first, each lower one planned against those above it (and kept
// below them), by conducting/counterpoint.js counterLine under a blend of rule sets drawn for the pool as its voices
// leave each room (drawnRules: Fux's, a fugue's, free, dissonant, micropolyphonic, at its own rigour) -- each on a rhythm
// of its own over the meter's positions (a part's pulse: the meter's levels coming in as it rises, pulsed, each bar's
// positions drawn anew), so the voices move independently, one holding as another moves. From its pool's seed (every
// seat of the pool the same plan, each playing its own part), once a phrase; its lower parts imitating its top as often
// as its imitation asks, a canon among its voices. -> [[{at (s), pitch, seconds, strong}]], a line a part, or null where
// the pool has no tones.
// A pool's line in counterpoint with the formation's lines above it (string-section.js seatRoles: role.above, the pools
// above it, theirs above them): its own line as planned (sectionLine: its rhythm, its motif's in the top line), each
// lower one's pitches chosen again on its own rhythm against the lines above it, every one planned as its own seats plan
// it, by counterLine under a blend of rule sets drawn for it as the voices leave each room (drawnRules), in its own
// register; its lag and its sounding lengths its own. Where it has none above, or none of them a line, its own line.
const COUNTERED=new Map;
export function sectionLines(role,options){
  const own=sectionLine(role,options);if(!own?.length||!role.above?.length)return own;
  const key=JSON.stringify([role.seed,role.centre,role.width,+options.downbeat.toFixed(6),+options.phrase.toFixed(6),options.beatSeconds,options.planBeat??null,options.shortest??null,role.above.map(other=>[other.seed,other.centre])]);
  if(COUNTERED.has(key))return COUNTERED.get(key);
  const notated=note=>Number.isFinite(note.written)?note.written:note.seconds/ARTICULATION;
  const against=role.above.map(other=>sectionLines(other,options)).filter(line=>line?.length).map(line=>line.map(note=>({pitch:note.pitch,start:note.at-options.downbeat,length:notated(note)})));
  let out=own;
  if(against.length){
    const [low,high]=lineRegister(role,(options.pool??[]).map(Number).filter(Number.isFinite))??[NaN,NaN],ladder=ladderOf(()=>options.pool),steps=ladder.filter(p=>p>=low-EPSILON&&p<=high+EPSILON);
    if(steps.length>=3){
      const random=seededSource(role.seed??0,'lines:counterpoint'),{positions,barSeconds}=metricalGrid(options.meter,options.beatSeconds);
      const strong=t=>{const within=((t%barSeconds)+barSeconds)%barSeconds;return positions.some(position=>position.weight>=.75&&Math.abs(position.at-within)<INSTANT)};
      const {rules}=drawnRules(random,{voices:against.length+1,classes:new Set(ladder.map(p=>+modulo(p,OCTAVE).toFixed(4))).size});
      const {line}=counterLine({against,rhythm:own.map(note=>({start:note.at-options.downbeat,length:notated(note)})),steps,rules,strong,random,above:false});
      // (Its pitches its own, no longer a stored theme's that its rhythm may still be: no `source`.)
      if(line.length===own.length)out=own.map(({source:_,...note},k)=>({...note,pitch:line[k].pitch}));
    }
  }
  COUNTERED.set(key,out);if(COUNTERED.size>KEPT.plans)COUNTERED.delete(COUNTERED.keys().next().value);
  return out;
}
// A shared line's entries chosen jointly, once a phrase for every seat of its sections alike (entries.js jointEntries):
// {section: entry}, or null where none holds (each then as drawn).
const ENTRIES_CHOSEN=new Map;
function sharedEntries(role,{planned,start,beatSeconds,meter,pool,phrase}){
  const groups=groupsOf(meter),delays=Object.fromEntries(Object.entries(role.entries).map(([id,e])=>[id,entryDelay(e,groups)*beatSeconds]));
  const key=JSON.stringify([role.seed,role.entries,role.entryRegisters,planned.map(n=>[n.at,n.pitch,n.seconds]),beatSeconds,pool]);
  if(ENTRIES_CHOSEN.has(key))return ENTRIES_CHOSEN.get(key);
  const out=jointEntries({line:planned.map(note=>({at:note.at-start,pitch:note.pitch,seconds:note.seconds})),entries:role.entries,registers:role.entryRegisters,delays,pool,length:phrase});
  const chosen=out.status==='SAT'?out.entries:null;ENTRIES_CHOSEN.set(key,chosen);if(ENTRIES_CHOSEN.size>256)ENTRIES_CHOSEN.delete(ENTRIES_CHOSEN.keys().next().value);
  return chosen;
}
const VOICES=new Map;
export function sectionCounterpoint(role,{downbeat,phrase,beatSeconds,meter,pool}){
  const parts=Math.max(1,Math.round(Number(role.parts)||1)),tones=(pool??[]).map(Number).filter(Number.isFinite);if(!tones.length)return null;
  const parameters=role.parameters??{},key=JSON.stringify([role.seed,materialOf(role),parts,role.centre,role.width,+downbeat.toFixed(6),+phrase.toFixed(6),beatSeconds,groupsOf(meter),meter?.subdivision,
    [...new Set(tones.map(p=>+modulo(p,OCTAVE).toFixed(4)))].sort((a,b)=>a-b),parameters.pulses??null,parameters.rigor??null,parameters.imitation??null,parameters.prolation??null,parameters.binding??null,parameters.ornament??null]);
  if(VOICES.has(key))return VOICES.get(key);
  const random=seededSource(role.seed??0,`counterpoint:${materialOf(role)}`),{positions,barSeconds}=metricalGrid(meter,beatSeconds);
  const bars=Math.max(1,Math.round(phrase/Math.max(INSTANT,barSeconds))),length=Math.min(phrase,bars*barSeconds);
  const ladder=ladderOf(()=>tones),classes=new Set(ladder.map(p=>+modulo(p,OCTAVE).toFixed(4))).size;
  const {rules}=drawnRules(random,{rigor:Number.isFinite(parameters.rigor)?parameters.rigor:1,voices:parts,classes});
  const strong=t=>{const within=((t%barSeconds)+barSeconds)%barSeconds;return positions.some(position=>position.weight>=.75&&Math.abs(position.at-within)<INSTANT)};
  const span=Math.max(OCTAVE,(Number(role.width)||7)*2),c=Number(role.centre)||60,reach=Math.max(5,span/parts);
  const pulses=Array.isArray(parameters.pulses)&&parameters.pulses.length?parameters.pulses:[.5];
  const targetOf=part=>c-span/2+span*(fromTop(part,parts)+.5)/parts,stepsOf=part=>ladder.filter(p=>p>=targetOf(part)-reach-EPSILON&&p<=targetOf(part)+reach+EPSILON);
  const rhythmOf=part=>{
    // (Its rhythm: the phrase's downbeat, and each of the meter's positions its pulse sounds, drawn bar by bar.)
    const scoreBar=groupsOf(meter).reduce((sum,g)=>sum+g,0)*(Number(meter.subdivision)||1);
    const pulse=pulses[part%pulses.length],own=seededSource(role.seed??0,`counterpoint:rhythm:${materialOf(role)}:${part}`),onsets=[];
    for(let bar=0;bar<bars;bar++)for(const position of positions){const at=bar*barSeconds+position.at;if(at<length-INSTANT&&(at<EPSILON||pulsed(position.weight,pulse,own())))onsets.push({at,scoreAt:R.of(bar*scoreBar).add(R.of(position.scoreAt))})}
    return onsets.map((point,k)=>({start:point.at,length:(onsets[k+1]?.at??length)-point.at,scoreTime:scoreTime(point.scoreAt,(onsets[k+1]?.scoreAt??R.of(bars*scoreBar)).sub(point.scoreAt),{axis:'phrase'})}));
  };
  // (Its lower parts imitating its top, each as often as its imitation asks (the owner: canons and fugues "more
  // important"): each a felt group later than the one before it, by octaves into its own place -- the top planned
  // against its own later entries (counterLine's self), as a canon's dux is; the rest free, against all.)
  const imitation=Math.max(0,Math.min(1,Number(parameters.imitation)||0)),group=groupsOf(meter)[0]*beatSeconds;
  const imitators=[];for(let part=1;part<parts;part++)if(imitation>0&&seededSource(role.seed??0,`counterpoint:imitates:${materialOf(role)}:${part}`)()<imitation)
    imitators.push({part,delay:(imitators.length+1)*group,transpose:OCTAVE*Math.round((targetOf(part)-targetOf(0))/OCTAVE),scoreDelay:(imitators.length+1)*groupsOf(meter)[0]*(Number(meter.subdivision)||1)});
  const lines=new Array(parts).fill(null),planned=()=>lines.filter(line=>line?.length);
  const topSteps=stepsOf(0);
  // (Or, as often as its prolation asks, its imitation a converging tempo canon (Astra's EC07/CF28: fugue-contracts.js
  // convergingCanon): the top playing its line slowest, from the phrase's downbeat, each imitating part the same line
  // faster, entering in turn, all striking its last note together and holding it to the phrase's end.)
  const prolation=Math.max(0,Math.min(1,Number(parameters.prolation)||0));
  const canon=imitators.length&&topSteps.length&&prolation>0&&seededSource(role.seed??0,`counterpoint:prolation:${materialOf(role)}`)()<prolation
    ?tempoCanon({rhythm:rhythmOf(0),imitators,length,group,meter,beatSeconds,barSeconds,tones,targetOf,topSteps,rules,strong,random:seededSource(role.seed??0,`counterpoint:prolation:ratio:${materialOf(role)}`)}):null;
  if(canon)canon.forEach((line,k)=>{lines[k?imitators[k-1].part:0]=line});
  else if(topSteps.length){
    const {line}=counterLine({against:[],rhythm:rhythmOf(0),steps:topSteps,rules,strong,random,self:imitators.map(({delay,transpose})=>({delay,transpose}))});
    lines[0]=line;
    for(const {part,delay,transpose,scoreDelay} of imitators)lines[part]=line.filter(note=>note.start+delay<length-INSTANT).map(note=>({...note,scoreTime:(()=>{const shifted=readScoreTime({scoreTime:shiftScoreTime(note.scoreTime,scoreDelay)}),end=R.of(bars*groupsOf(meter).reduce((a,b)=>a+b,0)*(Number(meter.subdivision)||1));return scoreTime(shifted.at,shifted.end.min(end).sub(shifted.at),{axis:'phrase'})})(),pitch:note.pitch+transpose,start:note.start+delay,length:Math.min(note.length,length-note.start-delay)}));
  }
  // (Each free part bound to the lines planned before it by its binding (Tinctoris as Bent reads him, 1983): every one, res
  // facta; short of it, its top's and as many more as its binding shares of the rest, the nearest first -- none, a
  // singer's over the book.)
  const binding=Number.isFinite(parameters.binding)?Math.max(0,Math.min(1,parameters.binding)):1;
  const boundTo=part=>{if(binding>=1)return planned();
    const others=lines.map((line,k)=>k&&line?.length?k:null).filter(k=>k!=null).sort((a,b)=>Math.abs(a-part)-Math.abs(b-part)||a-b);
    return [0,...others.slice(0,Math.round(binding*others.length))].map(k=>lines[k]).filter(line=>line?.length);};
  for(let part=1;part<parts;part++){
    if(lines[part])continue;
    const steps=stepsOf(part);if(!steps.length){lines[part]=[];continue}
    lines[part]=counterLine({against:boundTo(part),rhythm:rhythmOf(part),steps,rules,strong,random,above:false}).line;
  }
  for(let part=0;part<parts;part++)lines[part]??=[];
  // (A held note's end a run to the next note, as often as its `ornament` shares (the diminution treatises' passaggi: Brown
  // 1976; the owner, 5 November 2026, of performance ornaments that "sometimes deviate" from the rules a score follows):
  // each part's runs its own, planned after its counterpoint, on its own pitches, as much of its note as a fioritura
  // takes (fioritura.js) -- bound only to leave the note and land on the next. The note legato into it, written to where
  // it begins.)
  const ornament=Math.max(0,Math.min(1,Number(parameters.ornament)||0));
  if(ornament>0)lines.forEach((line,part)=>{
    const steps=stepsOf(part),ornamented=[];
    line.forEach((note,k)=>{
      ornamented.push(note);const next=line[k+1];
      if(!next||!note.scoreTime||Math.abs(next.start-note.start-note.length)>INSTANT||!(seededSource(role.seed??0,`counterpoint:ornament:${materialOf(role)}:${part}:${k}`)()<ornament))return;
      const symbolic=readScoreTime(note),spanTicks=symbolic.duration.mul(Q(1-FIORITURA.held)).floor(),tick=note.length/symbolic.duration.toNumber();
      if(!(spanTicks>=1))return;
      const range=[Math.min(steps[0]??note.pitch,note.pitch,next.pitch),Math.max(steps.at(-1)??note.pitch,note.pitch,next.pitch)];
      const run=planFioritura({from:note.pitch,to:next.pitch,pool:ladder,range,spanTicks,tickSeconds:tick,amount:ornament,random:seededSource(role.seed??0,`counterpoint:ornament:run:${materialOf(role)}:${part}:${k}`)});
      if(!run)return;
      const runAt=symbolic.end.sub(spanTicks),runStart=note.start+runAt.sub(symbolic.at).toNumber()*tick;
      ornamented[ornamented.length-1]={...note,length:runStart-note.start,scoreTime:scoreTime(symbolic.at,runAt.sub(symbolic.at),{axis:'phrase'}),legato:true};
      // (Each of its notes written where its tuplet places it and played where its rubato does: its `lag`.)
      run.notes.forEach((step,i)=>ornamented.push({scoreTime:shiftScoreTime(step.scoreTime,runAt,{axis:'phrase'}),pitch:step.pitch,start:runStart+step.at*tick,length:((run.notes[i+1]?.at??spanTicks)-step.at)*tick,
        ornament:true,...(Math.abs(step.at-step.written)>EPSILON?{lag:(step.at-step.written)*tick}:{})}));
    });
    lines[part]=ornamented;
  });
  const out=lines.map(line=>line.map(note=>({...scoreTimeFields(note),at:+(downbeat+note.start).toFixed(6),pitch:note.pitch,seconds:Math.max(.05,note.length*(note.ornament||note.legato?1:ARTICULATION)),written:+note.length.toFixed(6),strong:strong(note.start),
    ...(note.ornament?{ornament:true,...(note.lag?{lag:+note.lag.toFixed(6)}:{})}:{})})));
  VOICES.set(key,out);if(VOICES.size>KEPT.plans)VOICES.delete(VOICES.keys().next().value);
  return out;
}
// A converging tempo canon among a counterpoint's voices (above), from the top's `rhythm` ([{start, length}], s, over the
// phrase's `length`) and its `imitators` [{part}] in order of entry. Its speeds are ratios the meter's notation writes
// exactly on its rhythm's lattice (exact-elongation.js elongationCandidates): the top's drawn from those that leave its
// source a bar or more and its imitators room -- each imitator the fastest-but-one, its ratio the largest that enters a
// felt group (`group`, s) or more after the voice before it, none faster than the source itself -- from the feasible ones
// only. The source is the top's rhythm over the phrase shortened by its ratio, its last onset the convergence. Each
// imitator moves into its own place by the harmony's degrees (canon-plan.js stepInCollection, a canon at the degree
// nearest its place: a convergence on a chord, not only an octave); the top planned against them all, each at its speed
// (counterLine's self). Its timing solved with its whole counterpoint (convergingCanon). -> [lines] (the top's, then each
// imitator's: [{pitch, start, length}], s), or null where none is feasible or its solver finds none.
function tempoCanon({rhythm,imitators,length,group,meter,beatSeconds,barSeconds,tones,targetOf,topSteps,rules,strong,random}){
  const sub=Number(meter.subdivision)||1,endTick=readScoreTime(rhythm.at(-1)).end;
  const G=rhythm.map(note=>readScoreTime(note).at.div(sub)).reduce((grid,t)=>lcm(grid,t.d),1);
  const candidates=elongationCandidates(meter,{sourceDivision:G});if(!candidates.length)return null;
  // (For a top's ratio: its source -- the rhythm's onsets within the phrase over it -- and its imitators' ratios, each
  // the largest a felt group's entry allows below the one before; none where one has no room.)
  const option=top=>{
    const span=length/top.ratio;if(span<barSeconds-EPSILON)return null;
    const onsets=rhythm.filter(r=>r.start<span-EPSILON);if(onsets.length<2)return null;
    const last=onsets.at(-1).start,source=onsets.map((r,k)=>({start:r.start,length:(onsets[k+1]?.start??span)-r.start,scoreTime:scoreTime(readScoreTime(r).at,(k+1<onsets.length?readScoreTime(onsets[k+1]).at:endTick.div(R.of(top.exact))).sub(readScoreTime(r).at),{axis:'phrase'})})),ratios=[top];
    for(const _ of imitators){const most=ratios.at(-1).ratio-group/last,next=candidates.findLast(c=>c.ratio<=most+1e-12);if(!next)return null;ratios.push(next)}
    return {source,ratios};
  };
  const feasible=candidates.filter(c=>c.ratio>1).map(option).filter(Boolean);if(!feasible.length)return null;
  const {source,ratios}=feasible[Math.floor(random()*feasible.length)],top=ratios[0].ratio,at=top*source.at(-1).start;
  const collection=tones,first=topSteps[Math.floor(topSteps.length/2)];
  // (Each imitator's degrees: of those that keep every move the top may make within the rules' widest (rules.leapMost:
  // a collection's degrees uneven, a move by degrees can widen; by octaves never), those that bring the top's middle
  // pitch nearest its own place.)
  const keeps=k=>topSteps.every(p=>topSteps.every(q=>Math.abs(p-q)>rules.leapMost+.05||Math.abs(stepInCollection(p,k,collection)-stepInCollection(q,k,collection))<=rules.leapMost+.05));
  const degreesOf=part=>{const want=first+targetOf(part)-targetOf(0),range=3*collection.length;
    return Array.from({length:2*range+1},(_,i)=>i-range).filter(keeps).reduce((best,k)=>best==null||Math.abs(stepInCollection(first,k,collection)-want)<Math.abs(stepInCollection(first,best,collection)-want)?k:best,null)};
  const maps=imitators.map(({part})=>{const k=degreesOf(part);return pitch=>stepInCollection(pitch,k,collection)});
  const entries=ratios.slice(1).map(r=>at-r.ratio*source.at(-1).start);
  const {line}=counterLine({against:[],rhythm:source.map(r=>({start:top*r.start,length:top*r.length,scoreTime:scaleScoreTime(r.scoreTime,ratios[0].exact)})),steps:topSteps,rules,strong,random,
    self:entries.map((delay,k)=>({delay,ratio:ratios[k+1].ratio/top,map:maps[k]}))});
  if(line.length!==source.length)return null;
  const beats=t=>t/beatSeconds,sourceLine=line.map((note,k)=>({pitch:note.pitch,start:readScoreTime(source[k]).at.div(sub).toNumber(),length:readScoreTime(source[k]).duration.div(sub).toNumber(),scoreTime:scaleScoreTime(source[k].scoreTime,new R(1,sub),{axis:'canon-source-beats'})}));
  const certified=convergingCanon({source:sourceLine,voices:ratios.map((r,v)=>({ratio:r.exact,map:v?maps[v-1]:null})),length:beats(length),group:beats(group),collection,rules,
    strong:t=>strong(t*beatSeconds),budget:{maxWork:CANON_WORK}});
  if(certified.status!=='OPTIMAL')return null;
  // (Each voice's notes at its solved entry and speed, its last held to the phrase's end, played as planned: the planner's
  // own law over them (fugue-contracts.js plannerLaw) is checked in development, never while it plays.)
  const voices=ratios.map((r,v)=>{const entry=valueOfExact(certified.entries[v])*beatSeconds,move=v?maps[v-1]:pitch=>pitch;
    return line.map((note,k)=>{
      const scaled=readScoreTime({scoreTime:scaleScoreTime(source[k].scoreTime,r.exact)}),start=R.of(certified.entries[v]).mul(sub).add(scaled.at),end=k===line.length-1?endTick:start.add(scaled.duration);
      return {scoreTime:scoreTime(start,end.sub(start),{axis:'phrase'}),pitch:move(note.pitch),start:entry+r.ratio*source[k].start,length:k===line.length-1?length-entry-r.ratio*source[k].start:r.ratio*source[k].length};
    })});
  return voices;
}
// The work a tempo canon's certificate may take (positive-warp.js's own default allowance).
const CANON_WORK=2000000;
const valueOfExact=text=>{const [n,d='1']=String(text).split('/');return Number(n)/Number(d)};
// The share of its written length a line's note sounds: its articulation, a performance choice apart from its rhythm
// (an elongation's exact ratio is its written lengths', never its sounding ones).
export const ARTICULATION=.97;
// The longest a player of `instrument` sustains one note (s) at `level`: a bowed string's whole bow at the speed its
// dynamic takes (bow.js BOW.speed: a violin's about 3 s at mf, 11 s at pp), a wind's full breath; another's, a wind's
// middling breath.
export const sustainOf=(instrument,level=.5)=>BOWED_INSTRUMENTS[instrument]?BOWED_INSTRUMENTS[instrument].lengthCm/BOW.speed[dynamicOf(level).dynamic]:WIND_INSTRUMENTS[instrument]?.phonationSeconds??8;
// The longest one breath of a wind player holds a note at `level`, in its most spending register, every bit of the breath
// spent (a coordinated hit's, before its general pause: wind-seat.js); a player that does not breathe its notes, Infinity.
export function breathHolds(instrument,level=.5){
  const kind=WIND_INSTRUMENTS[instrument];if(!kind)return Infinity;
  return kind.phonationSeconds/((WIND_LINE.breathDynamics[dynamicOf(level).dynamic]??1)*Math.max(1,...Object.values(kind.registers??{})));
}
// The octaves (semitones) a given line moves by toward `centre`: of those that keep every pitch in `compass` ({low,
// high}), the nearest; where none does (or no compass is known), the nearest to its mean. -> the shift (semitones).
export function givenShift(pitches,{centre,compass=null}){
  const mean=pitches.reduce((sum,p)=>sum+p,0)/pitches.length,nearest=OCTAVE*Math.round((centre-mean)/OCTAVE)||0;
  if(!compass||!Number.isFinite(compass.low)||!Number.isFinite(compass.high))return nearest;
  const low=Math.min(...pitches),high=Math.max(...pitches),from=Math.ceil((compass.low-low)/OCTAVE),to=Math.floor((compass.high-high)/OCTAVE);
  if(from>to)return nearest;
  let best=null;for(let k=from;k<=to;k++)if(best==null||Math.abs(OCTAVE*k-nearest)<Math.abs(best-nearest))best=OCTAVE*k;
  return best;
}
// A line's register about its pool's centre: its pool's width either side, at least half a phrase's range (line.js
// LINE.phraseRange), and wide enough to hold three of the harmony's pitches, the fewest a line is planned with -- a
// harmony of one pitch class or two spread over its octaves. -> [low, high], or null where it hears no harmony.
function lineRegister(role,pitches){
  const centre=Number(role.centre);if(!pitches.length||!Number.isFinite(centre))return null;
  const near=[...new Set(pitches.map(p=>+modulo(p,OCTAVE).toFixed(6)))].flatMap(pc=>{const nearest=centre+modulo(pc-centre+6,OCTAVE)-6;return [nearest-OCTAVE,nearest,nearest+OCTAVE]}).map(p=>Math.abs(p-centre)).sort((a,b)=>a-b);
  const half=Math.max(Number(role.width)||0,LINE.phraseRange/2,near[2]);
  return [centre-half,centre+half];
}
// A pool's motif, where its line has a lineage (string-section.js withLineage): drawn from its lineage's root, as a melodic
// player's is once (line.js chooseMotif), the most unlike the motifs of the lines above it -- the same in every phrase of
// the lineage, which planLine varies by its age (fitted again where a meter changes the bar's groups). -> a motif, or null.
const MOTIFS=new Map;
function lineageMotif(role,{meter,beatSeconds}){
  if(!role?.lineage)return null;
  // (Its groups and its felt beat's seconds as planLine reckons them: a bar's ticks over its felt beats.)
  const sub=Math.max(1,Math.round(Number(meter?.subdivision)||1)),tick=beatSeconds/sub,beats=feltBeats(meter,{secondsPerTick:tick}),groups=beatGroups(meter,beats);
  const felt=(Number(meter?.pulsesPerBar)||groups.reduce((sum,group)=>sum+group.count,0)*sub)*tick/Math.max(1,beats.length);
  const key=JSON.stringify([role.lineage.root,groups.map(group=>[group.first,group.count]),felt,(role.above??[]).map(other=>other.lineage?.root??null)]);
  if(MOTIFS.has(key))return MOTIFS.get(key);
  const heard=(role.above??[]).map(other=>lineageMotif(other,{meter,beatSeconds})).filter(Boolean);
  const {motif}=chooseMotif({groups,density:LINE.motifDensity,heard,random:seededSource(role.lineage.root,'motif'),beatSeconds:felt});
  MOTIFS.set(key,motif);if(MOTIFS.size>KEPT.plans)MOTIFS.delete(MOTIFS.keys().next().value);
  return motif;
}
// A line's density: its pool's own draw (string-section.js STRING_SPECIFICATION.parameters.line.density), from its seed
// where its role carries none.
const lineDensity=role=>{const drawn=Number(role.parameters?.density);return Number.isFinite(drawn)?drawn:poolParameters('line',1,role.seed??0)?.density};
// (Planned at `planBeat` (s), where its seat knows the beat its conductor plans for the section -- the tempo of its rhythm
// plan, its rubato aside -- and played at `beatSeconds`, the beat its phrase begins with, every time scaled by the two's
// ratio: a line's rhythm is the conductor's tempo's, which its arches only bend in time. Planned at an arch's tempo, a
// busy line's divisions (as many notes as fit a beat at its players' quickest: line.js divisionOf) had changed with the
// arch, its notes written elsewhere than without it.)
export function sectionLine(role,{downbeat,phrase,beatSeconds,meter,pool,instrument=null,planBeat=null,shortest=null}){
  const ratio=Number(planBeat)>0?beatSeconds/planBeat:1;
  if(Math.abs(ratio-1)<EPSILON)return lineAt(role,{downbeat,phrase,beatSeconds,meter,pool,instrument,shortest});
  const planned=lineAt(role,{downbeat:0,phrase:phrase/ratio,beatSeconds:planBeat,meter,pool,instrument,shortest:shortest/ratio});if(!planned)return planned;
  const out=planned.map(note=>({...note,at:+(downbeat+note.at*ratio).toFixed(6),seconds:note.seconds*ratio,...(Number.isFinite(note.written)?{written:+(note.written*ratio).toFixed(6)}:{}),...(note.lag?{lag:note.lag*ratio}:{})}));
  if(planned.elongation)Object.defineProperty(out,'elongation',{value:planned.elongation});
  return out;
}
function lineAt(role,{downbeat,phrase,beatSeconds,meter,pool,instrument=null,shortest=null}){
  const grid=metricalGrid(meter,beatSeconds),bars=Math.max(1,Math.round(phrase/Math.max(INSTANT,grid.barSeconds))),asked=Math.max(1,Number(role.elongation)||1);
  const pitches=(pool??[]).map(Number).filter(Number.isFinite),register=lineRegister(role,pitches);if(!register)return null;
  const key=JSON.stringify([role.seed,role.centre,role.width,role.level,shortest??null,role.elongation??1,role.inversion??0,Boolean(role.retrograde),Number(role.contour)||0,role.ending??null,role.tapeLine??null,role.themeLine??null,String(role.pool??''),role.lineage??null,lineDensity(role),(role.above??[]).map(other=>other.lineage?.root??null),+downbeat.toFixed(3),+phrase.toFixed(3),beatSeconds,pitches,instrument]);
  if(LINES.has(key))return LINES.get(key);
  const level=Math.max(0,Math.min(1,Number(role.level)||.5));
  const sub=Math.max(1,Math.round(Number(meter?.subdivision)||1)),pulsesPerBar=Number(meter?.pulsesPerBar)||groupsOf(meter).reduce((sum,g)=>sum+g,0)*sub;
  // (Its closing phrase, the piece's last, where its conductor says so (role.ending): planLine's final -- its
  // cadence on the tonic, held through its last group, and, as often as its motif draws it, the motif's return: the band's theme, as a
  // motif in this phrase's meter and harmony (line.js motifFromLine), where its conductor heard one.)
  const lineMeter={...meter,pulsesPerBar,subdivision:sub},ending=role.ending?(()=>{
    let band=null;try{band=role.ending.theme?motifFromLine(role.ending.theme,{meter:lineMeter,bpm:60/beatSeconds,pool:pitches,register}):null}catch{band=null}
    return {tonic:Number.isFinite(Number(role.ending.tonic))?Number(role.ending.tonic):null,...(band?{motif:band}:{})}})():null;
  // (Its motif the tape's, where its conductor gives it the tape's onsets (role.tapeLine, in bars from the phrase's
  // downbeat): their rhythm and steps, in its own meter and harmony -- line.js motifFromLine, in quarters.)
  const quartersPerBar=(Number(meter?.numerator)||groupsOf(meter).reduce((sum,g)=>sum+g,0))*4/(Number(meter?.denominator)||4);
  // (Or a theme's, where its conductor gives its phrase the theme MemoryBOT planned to return there (role.themeLine, in
  // quarters): before the tape's. Its notes on the theme's each say the stored note they play, `source`, for the seat's
  // report to MemoryBOT: section-seat.js remember.)
  const given=role.themeLine??role.tapeLine?.map(onset=>({at:onset.at*quartersPerBar,pitch:onset.pitch}));
  let givenMotif=null;try{givenMotif=given?motifFromLine(given,{meter:lineMeter,bpm:60/beatSeconds,pool:pitches,register}):null}catch{givenMotif=null}
  // (Its motif the one its lineage carries, where it has one and none is given it; its variation its lineage's age; its
  // density its pool's own draw.)
  const motif=givenMotif??lineageMotif(role,{meter:lineMeter,beatSeconds});
  // (Its quickest note its player's, where its instrument's model sets one longer than a line's own: LINE.shortest.)
  const choices=shortest>LINE.shortest?{...LINE,shortest}:LINE;
  const plan=bars=>planLine({register,pool:pitches,meter:lineMeter,bpm:60/beatSeconds,bars,...(motif?{motif}:{}),choices,
    density:lineDensity(role),loudness:level,phraseIndex:Number.isInteger(role.lineage?.age)?role.lineage.age:Math.max(0,Math.round(downbeat/Math.max(INSTANT,phrase))),...(ending?{final:ending}:{}),random:seededSource(role.seed,'line')});
  // (Elongated exactly (Astra's elongationRatio, CFM-003, as their handoff contracts it): its source planned at the band's
  // tempo, in as many bars as the E asked spreads over the phrase, never replanned slower or sparser; its lattice the
  // positions its onsets and releases lie on (sourceLattice); the ratio its notation spells on that lattice nearest the E
  // asked, no longer than its players sustain its longest note (conducting/exact-elongation.js); every onset and release
  // that ratio times later, exactly, those past the phrase's end cut there; what it kept said with the line.)
  let planned=null,elongation=null;
  if(asked>1){
    const sourceBars=Math.max(1,Math.ceil(bars/asked-EPSILON)),source=plan(sourceBars);
    if(source.status==='planned'&&source.notes.length){
      // (A note's written onset and release, in notated notes: its played time less its lag.)
      const exact=note=>{const {at,end}=readScoreTime(note);return [at.div(sub),end.div(sub)]},written=note=>exact(note).map(t=>t.toNumber());
      // (Its longest note as it is elongated: its written length, which the ratio scales -- not its played one, which a
      // note played short of its writing had made shorter, and its elongation then held past its players' sustain.)
      const G=source.notes.flatMap(exact).reduce((grid,t)=>lcm(grid,t.d),1),longest=Math.max(...source.notes.map(note=>{const [from,to]=written(note);return (to-from)*beatSeconds}));
      const chosen=G?nearestElongation(asked,elongationCandidates(meter,{sourceDivision:G}),{most:sustainOf(instrument,level)/Math.max(INSTANT,longest)}):null;
      if(chosen?.ratio>1){
        const r=chosen.ratio,length=sourceBars*pulsesPerBar/sub,horizon=phrase/beatSeconds;
        const horizonTicks=Q(bars*pulsesPerBar);
        planned={...source,notes:source.notes.flatMap(note=>{
          const scaled=scaleScoreTime(note.scoreTime,chosen.exact),{at,end}=readScoreTime({scoreTime:scaled});
          if(at.ge(horizonTicks))return [];
          // (Its played time its written onset and release that ratio later, its lag kept as it was -- not its played
          // time scaled, which had stretched its lag and taken its release for its written end.)
          const [from,to]=written(note),lag=Number(note.lag)||0;
          return [{...note,start:r*from*beatSeconds+lag,end:Math.min(r*to,horizon)*beatSeconds+lag,
            scoreTime:scoreTime(at,end.min(horizonTicks).sub(at),{axis:'phrase'})}];
        })};
        elongation=Object.freeze({asked,ratio:chosen.exact,residual:asked-r,lattice:G,sourceBars,
          source:Object.freeze(source.notes.map(note=>Object.freeze(exact(note).map(x=>x.toString())))),
          drift:Object.freeze({notatedNotes:(r-asked)*length,truncated:Math.min(r*length,horizon)-Math.min(asked*length,horizon)}),articulation:ARTICULATION});
      }
    }
  }
  planned??=plan(bars);
  // (A return's line backwards, where it says so: each note's written time turned about the phrase's, its rhythm read
  // from the end -- a crab of the line its seed makes.)
  if(role.retrograde&&planned.status==='planned'&&planned.notes.length){
    const about=planned.notes.reduce((end,note)=>end.max(readScoreTime(note).end),R.ZERO).min(Q(bars*pulsesPerBar)),end=about.toNumber()*beatSeconds/sub;
    planned={...planned,notes:planned.notes.filter(note=>readScoreTime(note).at.lt(about)).map(note=>{
      const value=readScoreTime(note),clipped=scoreTime(value.at,value.end.min(about).sub(value.at),{axis:'phrase'});
      return {...note,scoreTime:reverseScoreTime(clipped,about),start:end-Math.min(end,note.end),end:end-note.start};
    }).sort((a,b)=>a.start-b.start)};
  }
  let notes=null;
  if(planned.status==='planned'&&planned.notes.length){
    const inversion=Math.max(0,Math.min(1,Number(role.inversion)||0)),first=planned.notes[0].pitch;
    // (Tilted along a tape's contour where its role says one: each note that share of its slope above or below, by its
    // place in the phrase, the harmony then placing it -- plex_clodbot tapeMaterial.)
    const tilt=Number(role.contour)||0;
    notes=planned.notes.map(note=>({...scoreTimeFields(note),at:+(downbeat+note.start).toFixed(6),pitch:note.pitch+inversion*(2*first-2*note.pitch)+tilt*(note.start/Math.max(INSTANT,phrase)-.5),seconds:Math.max(.05,(note.end-note.start)*ARTICULATION),
      written:+(note.end-note.start).toFixed(6),...(note.lag?{lag:note.lag}:{}),...(note.cadence?{cadence:true}:{}),...(note.source?{source:note.source}:{})}));
    if(elongation)Object.defineProperty(notes,'elongation',{value:elongation});
  }
  LINES.set(key,notes);if(LINES.size>KEPT.plans)LINES.delete(LINES.keys().next().value);
  return notes;
}
// A part's improvisation on its line, as far as its conductor allows (role.latitude, 0 to 1; improvise.js): its figures
// planned at its phrase's downbeat from its part's seed, so its part's players play them together; each figure's
// pitches chosen as they sound, on its scale -- its conductor's region (role.region: its collection's steps, period and
// tonic, the harmony plan's), else the scale the chord heard lies in (harmonic-levels.js chordScale, as the jazz players hear one)
// -- with the chord sounding then and the voices heard (`heard(clock)`: {othersFrom, othersTo}, sounding-voices.js),
// within its player's compass. Null where it is given none.
function improvisation(role,{start,beatSeconds,meter=null,pool,compass,heard,shortest=SECTION_VOICES.shortest}){
  const latitude=Math.max(0,Math.min(1,Number(role.latitude)||0));if(!(latitude>0))return null;
  const key=voiceKey(role),plan=seededSource(role.seed??0,`improvise:${key}`),draw=seededSource(role.seed??0,`improvise pitch:${key}`),states=new Map;
  const reach=Math.max(OCTAVE,(Number(role.width)||7)*2),low=Number.isFinite(compass?.low)?compass.low:(Number(role.centre)||60)-reach,high=Number.isFinite(compass?.high)?compass.high:(Number(role.centre)||60)+reach;
  const scaleOf=chord=>{
    if(Array.isArray(role.region?.system))return collectionPitches({system:role.region.system,period:Number(role.region.period)||OCTAVE},{tonic:Number(role.region.tonic)||0,low,high});
    const classes=chordScale(TWELVE_TONE_LEVELS,[...new Set(chord.map(pitch=>+modulo(pitch,OCTAVE).toFixed(6)))],{})?.set.pitchClasses??[],out=[];
    for(let octave=0;octave<=10;octave++)for(const pc of classes){const pitch=OCTAVE*octave+pc;if(pitch>=low-EPSILON&&pitch<=high+EPSILON)out.push(pitch)}
    return out;
  };
  return {
    figured:notes=>figuredLine(notes,planFigures(notes,{latitude,start,beatSeconds,subdivision:Number(meter?.subdivision)||1,shortest,groups:meter?groupsOf(meter):null,random:plan}),{articulation:ARTICULATION}),
    // (`previous`: the pitch its part last sounded, the figure's note as the harmony placed it, which its first move leaves.)
    pitch(note,clock,previous=null){
      const chord=(pool()??[]).map(Number).filter(Number.isFinite),ladder=scaleLadder({collection:scaleOf(chord),chord,low,high});
      const {othersFrom=[],othersTo=[]}=(clock&&heard?.(clock))??{};
      const state=states.get(note.figure.id)??(Number.isFinite(previous)?{previous,moves:[]}:null);
      const {pitch,state:next}=figurePitch(note,{ladder,state,chord,othersFrom,othersTo,latitude,random:draw});states.set(note.figure.id,next);return pitch;
    }};
}
// `bandBeat`: the band's notated note (s), where the part counts a meter and tempo of its own: a coordinated hit is
// held in the conductor's beats, every section's together. `compass` ({low, high}): its player's, where known.
// Where a part's line is highest, its share of the phrase from `start` (its first note there): the apex its dynamics swell
// to and fall from (line.js phraseSwell), each of its notes told it (`peak`); null where it has no notes.
function peakOf(notes,start,phrase){
  if(!notes?.length)return null;let top=notes[0];for(const note of notes)if(note.pitch>top.pitch+EPSILON)top=note;
  return Math.max(0,Math.min(1,(top.at-start)/Math.max(INSTANT,phrase)));
}
// ---- The process: every texture not planned as a phrase ---------------------------------------------------------------
// One maker for a chord, a cluster, Ligeti's micropolyphony, a heterophony, Xenakis's glides and clouds of points, and
// every point between them (the owner, 5 November 2026, of the string section's textures, recast "as points in one
// counterpoint-extended space that has no instrumental technique in it": "yes, correct"), read from its pool's point in
// the texture space (texture-space.js; drawnPoint: each dimension the pool's own draw, every bot's alike):
//   - its onsets: a part strikes the pool's own onsets (as `synchrony` shares the parts out) or its own, each from the
//     meter's positions its `pulse` sounds (pulsed: the meter's levels coming in as it rises), or Poisson arrivals at
//     its pool's density as often as its `chance` (Xenakis's), drawn to the pulse's positions as often as it keeps one;
//     with no pulse, arrivals at its chance of the density, none at all a held tone. A part whose time is its own (a
//     canon's: its entry `delay`ed within a group, its pace `drift`ing slower than the part before it) counts a lattice
//     of its own, the beat divided its own number of times (OWN_DIVISIONS), its groups stretched;
//   - its pitches: a walk, each onset's step drawn from a normal law (Xenakis's speeds) `motion` of its place's span,
//     turned back at its place's edges; the pool's steps (as `semblance` shares the parts out: semblant motion, in
//     parallel where each part has a place of its own) or its own; its place its own slice of the pool's band, or the
//     band whole (`places`), the band packed to a fraction of a semitone a part where its `packing` asks (the formation's
//     width); on the lattice (`continuum` 0) -- the harmony's tones where it strikes with the pool, its notes sounding
//     together, else the ladder its line walks (ladderOf) -- each stroke a tone it was not on, or anywhere in the
//     continuum (1), or between;
//   - each note sounding `sustain` of the time to its next onset, sliding into its pitch from the one before for `glide`
//     of it, or, for the parts its `impulse` shares out, an impulse: its player's shortest sound (`point`: a bowed
//     string's pizzicato, a wind's shortest tongued note -- section-seat.js, wind-seat.js), written an eighth at most.
// A part in the band's time playing the pool's material plays it as the pool's own onsets place it, each note the
// pool's sounding where it strikes, the next where it strikes again within one (a heterophony's variants of one line); a
// part in a time of its own plays it note by note (a canon's).
// A lattice: a bar's positions [{units, weight}], its units, a unit's seconds and its written ticks. The meter's, its
// subdivisions its units (metricalGrid).
function meterLattice(meter,beatSeconds){
  const {positions,barTicks}=metricalGrid(meter,beatSeconds);
  return {positions:positions.map((position,units)=>({units,weight:position.weight})),barUnits:barTicks,unitSeconds:beatSeconds/(Number(meter?.subdivision)||1),unitTicks:R.of(1)};
}
// A part's own: the meter's groups, its beat divided `division` times, each group stretched by `stretch` to a whole
// number of its units, its beats where they fall in it, weighted as the meter's are (METRIC_WEIGHTS).
function ownLattice(meter,beatSeconds,division,stretch){
  const {bar,group:grouped,note:noted,subdivision}=METRIC_WEIGHTS,positions=[];let units=0;
  groupsOf(meter).forEach((size,group)=>{
    const span=Math.max(size,Math.round(size*division*stretch)),beats=new Set(Array.from({length:size},(_,n)=>Math.round(n*span/size)));
    for(let u=0;u<span;u++)positions.push({units:units+u,weight:!u?(group?grouped:bar):beats.has(u)?noted:subdivision});
    units+=span;
  });
  return {positions,barUnits:units,unitSeconds:beatSeconds/division,unitTicks:new R(Number(meter?.subdivision)||1,division)};
}
// Two onset streams on one lattice as one: each onset of either, once, each stream drawn in its own order. -> {first(),
// after(units)}.
function together(a,b){
  let x,y;const least=()=>x==null?y:y==null?x:Math.min(x,y);
  return {first(){x=a.first();y=b.first();return least()},after(at){if(x===at)x=a.after(x);if(y===at)y=b.after(y);return least()}};
}
// An onset stream on a lattice, from its source (`source(name)`, the same for every part that counts it): the
// positions its pulse sounds (each position's draw its own, the same each bar: a pattern a pulse keeps), Poisson
// arrivals at `density` a second as often as `chance`, each drawn to the next position its pulse sounds as often as its
// pulse; with no pulse, arrivals at chance x density. -> {first(), after(units)}: the next onset's units, null where no
// onset comes (a tone held).
function onsetStream(lattice,{pulse,chance,density,source}){
  const on=lattice.positions.filter((position,k)=>pulsed(position.weight,pulse,source(`pulse:${k}`)()));
  const draw=source('onsets'),keeps=pulse>0&&on.length>0,rate=(keeps?density:chance*density)*lattice.unitSeconds;
  const nextOn=u=>{for(let bar=Math.max(0,Math.floor(u/lattice.barUnits));;bar++)for(const position of on){const at=bar*lattice.barUnits+position.units;if(at>=u)return at}};
  const after=u=>{
    if(keeps&&!(draw()<chance))return nextOn(u+1);
    if(!(rate>EPSILON))return null;
    const at=u+Math.max(1,Math.ceil(-Math.log(Math.max(1e-12,draw()))/rate));
    return keeps&&draw()<pulse?nextOn(at):at;
  };
  return {first:()=>keeps||rate>EPSILON?after(-1):0,after};
}
// A walk's next pitch from `previous` (null: its first, drawn about its place as far as its motion reaches) in its place
// ({centre, half}), its step drawn from `random`, turned back at its edges; on its lattice (`tones`) as its continuum
// holds it, a tone it was not on. -> a pitch.
function walked(previous,random,{centre,half},{motion,continuum},tones){
  const u=random(),g=normalFrom(random),low=centre-half,high=centre+half;
  let raw=previous==null?centre+(2*u-1)*half*motion:previous+g*motion*2*half;
  for(let turn=0;turn<4&&(raw<low||raw>high);turn++)raw=raw<low?2*low-raw:2*high-raw;
  raw=clamp(raw,low,high);
  if(!(continuum<1)||!tones.length)return raw;
  const inside=tones.filter(p=>p>=low-EPSILON&&p<=high+EPSILON),near=inside.length?inside:tones;
  let snapped=nearestIn(near,raw);
  if(previous!=null&&motion>0&&Math.abs(snapped-previous)<.25){
    const sorted=[...new Set(near)].sort((a,b)=>a-b),k=sorted.findIndex(p=>Math.abs(p-snapped)<.25),way=g<0?-1:1;
    snapped=sorted[k+way]??sorted[k-way]??snapped;
  }
  return snapped+continuum*(raw-snapped);
}
// A pool's parts as its rules hear them: each a copy of its voice -- the same role and seed, played in the same windows,
// the harmony heard in each: the notes its own seats play -- its first `count` parts, each played after those before it.
// `voiceOf(role, heard, harmony)`: a copy's voice, `heard(parts)` the copies of those parts (their indices) as its own
// rules hear them, `harmony()` the pool heard in the window it plays. -> {windows, forks, play(window): every copy through
// a window ({now, until, options, harmony, key}); heard(parts)(t, before): the notes the copies of `parts` sound at t,
// each [{pitch, before (its pitch at `before`, or null)}]; replayed(count): the same copies anew, played through its
// first `count` windows}.
function ensembleOf(role,count,voiceOf){
  const notes=[],voices=[],windows=[];let harmony=null;
  const sounding=(list,t)=>{for(let k=list.length-1;k>=0;k--)if(list[k].at<=t+EPSILON)return t<list[k].at+list[k].seconds-EPSILON?list[k]:null;return null};
  const heardOf=parts=>(t,before)=>parts.flatMap(j=>{const note=notes[j]&&sounding(notes[j],t);if(!note)return [];const was=before==null?null:sounding(notes[j],before);return [{pitch:note.pitch,before:was?.pitch??null}]});
  for(let j=0;j<count;j++){notes.push([]);voices.push(voiceOf({...role,part:j},heardOf,()=>harmony))}
  const ensemble={windows,forks:new Map,heard:heardOf,
    // (A run (`ornament`) heard as the note it leaves, held through it: the rules bind the notes beneath the runs.)
    play(window){harmony=window.harmony;voices.forEach((voice,j)=>{for(const note of voice.events(window.now,window.until,window.options)){
      const held=notes[j].at(-1);if(!note.ornament)notes[j].push(note);else if(held)notes[j][notes[j].length-1]={...held,seconds:Math.max(held.seconds,note.at+note.seconds-held.at)}}});windows.push(window)},
    replayed(played){const copy=ensembleOf(role,count,voiceOf);for(const window of windows.slice(0,played))copy.play(window);return copy}};
  return ensemble;
}
// A role as an ensemble's key: its fields, and the pools it hears above it (`over`) by their own keys, each a hash of
// its text two ways -- a pool's `over` holds roles holding theirs, so written whole its text would double a pool down.
const ROLE_KEYS=new WeakMap;
function roleKey(role){
  if(!ROLE_KEYS.has(role)){const {over,...rest}=role,text=JSON.stringify([rest,(over??[]).map(roleKey)]);ROLE_KEYS.set(role,`${fnv1a(text).toString(36)}.${fnv1a(text,FNV_OFFSET^SECOND_SEED).toString(36)}`)}
  return ROLE_KEYS.get(role);
}
// An ensemble as a part of the process hears it: one for every seat that hears it alike, as a planned pool's lines are
// planned once for its seats (VOICES) -- each copy played once through a window, its seats' windows their pool's (its
// formation's ticks, in its phrase's own time) and the harmony heard every bot's alike at a tick (ladderOf) -- keyed by
// what its copies are made of (`key`; `made()` makes it, ensembleOf), each window by its bounds and the harmony heard in
// it. A seat whose windows leave its ensemble's (one catching up, a harmony heard otherwise) hears a fork of it from
// there, replayed through the windows they had played alike, every seat leaving it there alike hearing that fork.
// -> {play(now, until, options, harmony): its copies through a window, where none has played it; heard(parts): as
// ensembleOf's}.
const ENSEMBLES=new Map;
function heardEnsemble(key,made){
  let ensemble=ENSEMBLES.get(key),cursor=0;
  if(!ensemble){ensemble=made();ENSEMBLES.set(key,ensemble);if(ENSEMBLES.size>KEPT.ensembles)ENSEMBLES.delete(ENSEMBLES.keys().next().value)}
  return {play(now,until,{position,left,scoreWindow},harmony){
    const options={position,left,scoreWindow},window={now,until,options,harmony:harmony&&[...harmony],key:JSON.stringify([now,until,position,left,`${R.of(scoreWindow.at)}`,`${R.of(scoreWindow.end)}`,harmony])};
    if(cursor<ensemble.windows.length&&ensemble.windows[cursor].key!==window.key){
      const fork=`${cursor} ${window.key}`;if(!ensemble.forks.has(fork))ensemble.forks.set(fork,ensemble.replayed(cursor));ensemble=ensemble.forks.get(fork);
    }
    if(cursor===ensemble.windows.length)ensemble.play(window);
    cursor++;
  },heard:parts=>(t,before)=>ensemble.heard(parts)(t,before)};
}
// A part's voice in the process. `point`: its pool's point, drawn ({dimension: a number}); `parameters`: its family's
// details (an impulse's seconds, a cantus's notes; an older conductor's divisions and drift); `heard(parts)`: its pool's
// parts as a copy of it hears them (ensembleOf), else its pool's ensemble's where its rules choose (heardEnsemble); the
// rest makeVoice's.
function processVoice(role,{point,parameters,start,beatSeconds,meter,pool,shortest,band,written,windowOf,heldTo,onScoreRevision,heard=null}){
  const part=Number(role.part)||0,parts=Math.max(1,Number(role.parts)||1),key=materialOf(role),seed=role.seed??0;
  const pooled=name=>seededSource(seed,`texture:${key}:${name}`),mine=name=>seededSource(seed,`texture:${key}:${part}:${name}`);
  // (Whether this part is among those a share gives: its own draw under it.)
  const among=name=>mine(name)()<point[name];
  const synchronous=among('synchrony'),semblant=among('semblance'),impulsive=among('impulse'),ownTime=!synchronous&&(point.delay>0||point.drift>0);
  const {pulse,chance,sustain,glide,continuum}=point,density=Math.max(0,Number(role.density)||0),groups=groupsOf(meter);
  let lattice=meterLattice(meter,beatSeconds),entry=0;
  if(ownTime){
    // (Its division: its share of those from two to as many as its beat holds playable notes, the parts' shares spread
    // over OWN_DIVISIONS from the pool's offset, an elongated pool's that many times coarser; a whole number an older
    // conductor said, as it is. Its entry its share of its delay's group, on its own lattice.)
    const given=Array.isArray(parameters?.divisions)&&parameters.divisions.length?parameters.divisions[part%parameters.divisions.length]:null;
    const [low,high]=OWN_DIVISIONS,share=given??low+(high-low)*((pooled('divisions')()+part/parts)%1),most=Math.max(2,Math.floor(beatSeconds/shortest+EPSILON));
    const division=share>1?Math.round(share):Math.round(2+share/Math.max(1,Number(role.elongation)||1)*(most-2));
    lattice=ownLattice(meter,beatSeconds,division,1+point.drift*part);
    entry=Math.round(part/parts*point.delay*groups.reduce((sum,g)=>sum+g,0)/groups.length*division);
  }
  // (A part playing the pool's material in the band's time, its rhythm its own, follows it: it strikes where the pool's
  // material moves, its pitch moving with it -- Huron's semblant motion -- and where its own rhythm strikes, the note the
  // material is on struck again -- his onset synchronization the less: a heterophony.)
  const follows=semblant&&!synchronous&&!ownTime,poolOnsets=()=>onsetStream(meterLattice(meter,beatSeconds),{pulse,chance,density,source:name=>pooled(`onsets:${name}`)});
  const own=onsetStream(lattice,{pulse,chance,density,source:synchronous?name=>pooled(`onsets:${name}`):name=>mine(`onsets:${name}`)});
  const stream=follows?together(own,poolOnsets()):own,poolStream=follows?poolOnsets():null;
  let poolAt,poolIndex=-1;
  const poolIndexAt=units=>{if(poolAt===undefined)poolAt=poolStream.first();while(poolAt!=null&&poolAt<=units){poolIndex++;poolAt=poolStream.after(poolAt)}return Math.max(0,poolIndex)};
  // (The material's note its `k`th onset, at `units`, plays: its own count; a following part's own onset between the
  // material's moves its note struck again, or as often as its anticipation the next note taken early, the material's
  // move then struck where it already is.)
  const indexOf=(units,k)=>{if(!follows)return k;const heard=poolIndexAt(units);return Math.max(lastIndex,heard>heardBefore?heard:heard+(mine(`anticipation:${k}`)()<point.anticipation?1:0))};
  // (Its material: the walk's pitches by index, the pool's steps or its own; a cantus begun again after so many notes.)
  const loop=Number(parameters?.cantusNotes)>0?Math.round(parameters.cantusNotes):Infinity,material=[];
  const stepOf=k=>semblant?seededSource(seed,`texture:${key}:step:${k}`):mine(`step:${k}`);
  // (Its rules, where they bind it (the owner, 5 November 2026: "We should close the gap"): the process proposes, the
  // rules choose. As many of its notes as its `rules` share, drawn note by note, are chosen among its walk's proposals --
  // its own, and as many more as the counterpoint planner keeps settings at a note (COUNTERPOINT.beam), each a walk from
  // the same pitch -- as the one its rules cost least against the parts above as they sound then (counterpoint.js
  // heardCost: its pool's rule set drawn as a counterpoint's is, drawnRules, for its parts and its harmony's classes), on
  // its position's weight; its own walk's where they cost alike. At none, the process as it is.)
  // (The parts its rules bind it to, by its `binding` (Tinctoris as Bent reads him, 1983): its pool's first part, and of
  // the parts above it as many more as its binding shares, the nearest first -- the first alone a singer's over the book,
  // every one res facta. And the pools sounding above it (role.over: string-section.js seatRoles), each part of each,
  // heard with them at as many of its chosen notes as its `between` shares -- none, each pool's idiom its own.)
  const {part:_,...shared}=role,made=[start,beatSeconds,meter,shortest],nearer=Math.round(point.binding*Math.max(0,part-1));
  const scope=part>0?[...new Set([0,...Array.from({length:nearer},(_,k)=>part-1-k)])]:[];
  const ensemble=point.rules>0&&part>0&&!heard?heardEnsemble(JSON.stringify(['parts',roleKey(shared),point,parameters,...made]),
    ()=>ensembleOf(role,parts-1,(copy,hears,harmony)=>processVoice(copy,{point,parameters,start,beatSeconds,meter,pool:harmony,shortest,band,written,windowOf,heldTo,onScoreRevision:()=>{},heard:hears}))):null;
  const above=point.rules>0&&part>0?heard??ensemble.heard:null;
  const over=point.rules>0&&point.between>0?(role.over??[]).map(other=>{
    const {part:__,...whole}=other,count=Math.max(1,Number(other.parts)||1),all=Array.from({length:count},(_,j)=>j);
    const ensemble=heardEnsemble(JSON.stringify(['pool',roleKey(whole),...made]),
      ()=>ensembleOf(other,count,(copy,hears,harmony)=>makeVoice(copy,{random:seededSource(copy.seed,voiceKey(copy)),start,beatSeconds,meter,pool:harmony,shortest})));
    return {play:ensemble.play,heard:ensemble.heard(all)};
  }):[];
  const ownParts=above?.(scope),choosing=Boolean(ownParts||over.length);let rules=null;
  const partners=(at,before,n)=>{
    const others=over.length&&mine(`between:${n}`)()<point.between?over.flatMap(other=>other.heard(at,before)):[];
    return ownParts?[...ownParts(at,before),...others]:others;
  };
  const chosen=(n,from,proposed,place,tones,{at,strong})=>{
    const against=partners(at,previousAt,n);if(!against.length)return proposed;
    let best=proposed,least=heardCost(proposed,{previous,leap,against,strong,rules,above:false});
    for(let i=1;i<COUNTERPOINT.beam;i++){const pitch=walked(from,mine(`propose:${n}:${i}`),place,point,tones),cost=heardCost(pitch,{previous,leap,against,strong,rules,above:false});if(cost<least-EPSILON){least=cost;best=pitch}}
    return best;
  };
  // (`kept` false: the note as it would be now, the material left as it is -- a run's next note foreseen.)
  const materialAt=(index,place,tones,heardAt=null,kept=true)=>{
    if(index<material.length)return material[index];
    let pitch=material.at(-1)??null;
    for(let n=material.length;n<=index;n++){
      const k=n%loop,from=k?pitch:null,proposed=walked(from,stepOf(k),place,point,tones);
      pitch=choosing&&heardAt&&mine(`rules:${n}`)()<point.rules?chosen(n,from,proposed,place,tones,heardAt):proposed;if(kept)material.push(pitch);
    }
    return pitch;
  };
  // (Its place in the band at a point of its phrase, its pool's arc moving it: its own slice, or the band whole.)
  const placeAt=position=>{
    const {centre:c,width:w}=band(position),{places,packing}=point,span=(1-packing)*Math.max(OCTAVE,2*w)+packing*w,target=c-span/2+span*(fromTop(part,parts)+.5)/parts;
    return {centre:c+places*(target-c),half:(1-places)*span/2+places*(1-packing)*Math.max(5,span/parts)};
  };
  // (Its lattice: the harmony's tones where it strikes with the pool, none where it hears none; else its line's ladder.)
  const tonesOf=()=>{
    if(!synchronous)return ladderOf(pool);
    const heard=(pool()??[]).map(Number).filter(Number.isFinite),out=[];
    for(const pc of new Set(heard.map(p=>+modulo(p,OCTAVE).toFixed(6))))for(let octave=1;octave<=8;octave++)out.push(OCTAVE*octave+pc);
    return out.sort((a,b)=>a-b);
  };
  // (Its tones and their classes, derived again only where the harmony heard has moved.)
  let heardKey=null,heardTones=null,heardClasses=null;
  const harmonyNow=()=>{
    const key=JSON.stringify(pool()??[]);
    if(key!==heardKey){heardKey=key;heardTones=tonesOf();heardClasses=heardTones.map(p=>+modulo(p,OCTAVE).toFixed(4)).sort((a,b)=>a-b).join(',')}
    return {tones:heardTones,classes:heardClasses};
  };
  // (An impulse written to the next onset, the whole ticks of an eighth at most -- its beat where that is shorter, a tick
  // at the least -- a rest after it: never written held.)
  const sub=Number(meter?.subdivision)||1,impulseTicks=R.of(Math.max(1,Math.min(sub,Math.floor(sub*(Number(meter?.denominator)||4)/8))));
  const impulseSeconds=Math.max(.01,Number(parameters?.seconds)||poolParameters('points',1,seed)?.seconds||.15),tolerance=repetitionOf(role.repetition??null);
  const unit=lattice.unitSeconds,timeOf=units=>start+(entry+units)*unit,scoreOf=units=>R.of(entry+units).mul(lattice.unitTicks);
  // (Each note written to the next, a held note's end revised where a harmony's move strikes it again inside it.)
  let authored=null,serial=0;
  const compose=(at,end,window)=>{
    if(authored&&R.of(at).gt(readScoreTime(authored).at)&&R.of(at).lt(readScoreTime(authored).end)){authored={...authored,scoreTime:written(readScoreTime(authored).at,at,window)};onScoreRevision(authored)}
    authored={scoreId:String(serial++),scoreTime:written(at,end,window)};return authored;
  };
  let next,following,count=0,lastIndex=-1,heardBefore=-1,previous=null,previousAt=null,leap=0,run=null,harmony=null,held=false,passage=null;
  return {events(now,until,options){
    const {position,left}=options,window=windowOf(options),out=[];
    if(next===undefined)next=stream.first();
    const place=placeAt(position),{tones,classes}=harmonyNow();
    // (Its run, where one is due (`ornament`): planned as it begins, from the pitch it leaves to the next note as it would
    // be chosen then, against the parts above as far as they have been heard -- foreseen, never fixed: the note is chosen
    // when it comes, as it would be with no run, so a run only adds notes; where its place has moved or the parts above
    // sound otherwise, it lands a little off -- each of its notes played in the window it falls in.)
    const ornaments=()=>{
      if(passage&&!passage.notes&&passage.runStart<until-EPSILON){
        const {units,k,spanUnits,runStart,runAt}=passage;passage.notes=[];
        if(synchronous&&continuum<1&&!tones.length)return;
        const to=materialAt(indexOf(units,k),place,tones,{at:Math.min(timeOf(units),until-INSTANT),strong:lattice.positions[modulo(units,lattice.barUnits)]?.weight>=METRIC_WEIGHTS.group-EPSILON},false),ladder=ladderOf(pool);
        // (Over its line's ladder, its place wide enough to hold the pitch it leaves and the one it lands on, and as many
        // pitches as a run takes the fewest of.)
        let low=Math.min(place.centre-place.half,previous,to),high=Math.max(place.centre+place.half,previous,to);
        while(ornamentPitches(ladder,[low,high]).length<FIORITURA.leastNotes){low=ladder.findLast(p=>p<low-EPSILON)??low-1;high=ladder.find(p=>p>high+EPSILON)??high+1}
        const plan=planFioritura({from:previous,to,pool:ladder,range:[low,high],spanTicks:spanUnits,tickSeconds:unit,amount:point.ornament,random:mine(`ornament:run:${k}`)});
        // (Each of its notes written where its tuplet places it and played where its rubato does: its `lag`.)
        passage.notes=(plan?.notes??[]).map((step,i,steps)=>{const {at:a,end:e}=readScoreTime(step);
          return {scoreAt:runAt.add(a.mul(lattice.unitTicks)),scoreEnd:runAt.add(e.mul(lattice.unitTicks)),at:runStart+step.at*unit,endAt:runStart+(steps[i+1]?.at??spanUnits)*unit,pitch:+step.pitch.toFixed(4),lag:(step.at-step.written)*unit}});
        passage.last=passage.notes.at(-1)?.pitch??null;
      }
      if(passage?.notes)while(passage.notes.length&&passage.notes[0].at<until-EPSILON){
        const note=passage.notes.shift();if(note.at<now-EPSILON)continue;
        out.push({...compose(note.scoreAt,note.scoreEnd,window),at:note.at,pitch:note.pitch,seconds:heldTo(note.at,note.endAt-note.at,left,now),...(Math.abs(note.lag)>EPSILON?{lag:+note.lag.toFixed(6)}:{}),ornament:true});
      }
    };
    // (The parts above played through the window first, as their seats play it; its rules drawn as it begins.)
    if(choosing){const harmony=pool()??null;ensemble?.play(now,until,options,harmony);for(const other of over)other.play(now,until,options,harmony);rules??=drawnRules(pooled('rules'),{rigor:1,voices:parts,classes:new Set(tones.map(p=>+modulo(p,OCTAVE).toFixed(4))).size||OCTAVE}).rules}
    const ahead=next==null?Infinity:timeOf(next);
    // (Where the harmony moves under a tone sounding with the pool, before its next onset: struck again on the harmony's
    // tone nearest it in its place, the harmony kept; a tone held past what its listeners are projected to take
    // (repetition.js: its conductor's tolerance) moved to its neighbour -- a voice exchange.)
    // (Before a run to come, legato into it, written to where it begins; never in one.)
    if(previous!=null&&synchronous&&continuum<1&&tones.length&&ahead>now+EPSILON&&left>0&&!(passage&&(passage.notes||passage.runStart<=now+EPSILON))){
      const moved=classes!==harmony,inside=tones.filter(p=>Math.abs(p-place.centre)<=place.half+EPSILON),near=inside.length?inside:tones;
      let pitch=moved?nearestIn(near,previous):previous;
      if(held&&Math.abs(pitch-previous)<.25&&run&&!mayGoOn(run,now,tolerance)){const others=near.filter(p=>Math.abs(p-pitch)>.25);if(others.length)pitch=nearestIn(others,pitch)}
      if(Math.abs(pitch-previous)>=.25){
        const end=passage?passage.runAt:next==null?window.end:scoreOf(next);
        out.push({...compose(window.at,end,window),at:now,pitch:+pitch.toFixed(4),seconds:passage?heldTo(now,passage.runStart-now,left,now):held?heldTo(now,left,left,now):heldTo(now,Math.max(.05,sustain*(ahead-now)),left,now)});
        leap=pitch-previous;previous=pitch;previousAt=now;run={pitch,since:now,strikes:1};
      }
    }
    harmony=classes;ornaments();
    while(next!=null){
      const at=timeOf(next),scoreAt=scoreOf(next);
      if(at>=until-EPSILON||scoreAt.ge(window.end)||left<=at-now)break;
      if(following===undefined)following=stream.after(next);
      // (A held tone is struck where its part comes in; a passed onset is passed.)
      const last=following==null;
      if(at<now-EPSILON&&!last){next=following;following=undefined;count++;continue}
      // (Its note: indexOf. A run's note it lands on, the run done.)
      const index=indexOf(next,count),arriving=passage?.k===count?passage.last:null;if(follows)heardBefore=poolIndexAt(next);if(passage&&count>=passage.k)passage=null;
      if(!(synchronous&&continuum<1&&!tones.length)){
        const when=Math.max(at,now),pitch=materialAt(index,place,tones,{at:when,strong:lattice.positions[modulo(next,lattice.barUnits)]?.weight>=METRIC_WEIGHTS.group-EPSILON});
        const from=at<now-EPSILON?window.at:scoreAt,endAt=last?Infinity:timeOf(following),end=last?window.end:scoreOf(following);
        if(impulsive)out.push({scoreTime:written(from,R.of(end).min(R.of(from).add(impulseTicks)),window),at:when,pitch:+pitch.toFixed(4),seconds:heldTo(when,impulseSeconds,left,now),point:true});
        else{
          const before=glide>0?(arriving??previous)??walked(null,mine('from'),place,{motion:1,continuum:1},[]):null;
          // (Its end a run to its next note, as often as its `ornament` shares (the diminution treatises' passaggi: Brown
          // 1976), where its next note comes within the phrase: as much of its time to the next onset as a fioritura takes
          // of a held note (FIORITURA.held), a whole number of its lattice's units, where that is long enough to be one; the
          // note legato into it, written to where it begins. Its pitches bound only to leave the note and land on the next,
          // its rules' choice: never heard as notes.)
          const spanUnits=!last&&point.ornament>0&&at>=now-EPSILON?Math.floor((following-next)*(1-FIORITURA.held)):0;
          const runs=spanUnits>=1&&spanUnits*unit>=FIORITURA.leastSeconds&&R.of(end).lt(window.end)&&endAt<now+left-EPSILON&&mine(`ornament:${count}`)()<point.ornament;
          const runAt=runs?R.of(end).sub(R.of(spanUnits).mul(lattice.unitTicks)):null,runStart=runs?endAt-spanUnits*unit:null;
          out.push({...compose(from,runs?runAt:end,window),at:when,pitch:+pitch.toFixed(4),seconds:runs?heldTo(when,runStart-when,left,now):last?heldTo(when,left,left,now):heldTo(when,Math.max(.05,sustain*(endAt-when)),left,now),
            ...(before!=null?{from:+before.toFixed(4),...(glide<1?{hold:+(1-glide).toFixed(3)}:{})}:{})});
          if(runs)passage={k:count+1,units:following,spanUnits,runAt,runStart,notes:null};
        }
        run=run&&Math.abs(run.pitch-pitch)<.25?{...run,strikes:run.strikes+1}:{pitch,since:when,strikes:1};
        leap=previous==null?0:pitch-previous;previous=pitch;previousAt=when;lastIndex=index;held=last;
        if(passage&&!passage.notes)ornaments();
      }
      count++;next=following;following=undefined;
    }
    return out;
  }};
}

// (`shortest`: its player's quickest note where its instrument's model sets one (wind-section.js windSeats: a brass
// instrument's tone's build-up on its lips), never under SECTION_VOICES.shortest.)
export function makeVoice(role,{random,start,beatSeconds,meter=null,pool,instrument='violin',bandBeat=beatSeconds,bandBeatTicks=null,compass=null,planBeat=null,heard=null,shortest:quickest=null,onScoreRevision=()=>{}}){
  const shortest=Math.max(SECTION_VOICES.shortest,Number(quickest)||0);
  const {texture,part,parts,centre,width,density,level}=role,band=position=>({centre:centre+3*arcAt(position),width:width*(.6+.4*arcAt(position))});
  const parameters=role.parameters??poolParameters(texture,parts,role.seed,undefined,pointOfRole(role));
  const heldTo=(at,seconds,left,now)=>Math.max(.05,Math.min(seconds,left-(at-now)));
  const sub=Number(meter?.subdivision)||1,tick=beatSeconds/sub;
  const written=(at,end,window)=>scoreTime(at,R.of(end).min(R.of(window.end)).sub(R.of(at)),{axis:'phrase'});
  // The caller supplies musical window boundaries. The audio window can move under rubato without moving these.
  const windowOf=options=>{
    if(!options?.scoreWindow)throw new TypeError('A composing voice needs its symbolic scoreWindow');
    return {at:R.of(options.scoreWindow.at),end:R.of(options.scoreWindow.end)};
  };
  // (A section resting for the phrase: no notes. section-kinds.js: its conductor's rest.)
  if(texture==='tacet')return {events(){return []}};
  // (A line its conductor gives it, a fugue's entry (conducting/fugue-plan.js): each note at its quarters from the
  // formation's downbeat, the whole moved by octaves to the part's register, its contour and its tuning kept -- by the
  // octave nearest it of those that keep the whole line in its player's compass, where one does (givenShift; Astra's
  // tracker CF32: a voice given a player it can play), never note by note; by its conductor's octave for the voice where
  // it says one (plex_clodbot voiceOctave: the same in every phrase).)
  if(texture==='counterpoint'){
    // (Its part's voice of the pool's counterpoint (sectionCounterpoint), planned whole at the phrase's downbeat, each
    // note in the harmony sounding when it plays: on a strong position the harmony's nearest tone; on a weak one its own
    // where it is a step from the note before -- a passing or a neighbour tone -- else the harmony's nearest.)
    let planned=null,last=null,peak=null;const sounded=new Set;
    return {events(now,until,{position,left}){
      if(!planned){const phrase=Math.max(INSTANT,now+left-start);planned=sectionCounterpoint(role,{downbeat:start,phrase,beatSeconds,meter,pool:pool()})?.[part]??[];peak=peakOf(planned,start,phrase)}
      const out=[];
      for(const [index,note] of planned.entries()){
        if(note.at<now-EPSILON||note.at>=until-EPSILON||sounded.has(index))continue;sounded.add(index);
        // (A run's note (`ornament`) as planned: free of the harmony as of the rules.)
        const near=followHarmony(note.pitch,pool(),[note.pitch-OCTAVE,note.pitch+OCTAVE]),stepwise=last!=null&&Math.abs(note.pitch-last)<=2.5+EPSILON;
        const pitch=note.ornament?note.pitch:note.strong||!stepwise?near:note.pitch;if(!note.ornament)last=pitch;
        out.push({...scoreTimeFields(note),at:note.at,pitch,seconds:heldTo(note.at,note.seconds,left,now),...(Number.isFinite(note.written)?{written:heldTo(note.at,note.written,left,now)}:{}),...(peak!=null?{peak}:{}),
          ...(note.ornament?{ornament:true,...(note.lag?{lag:note.lag}:{})}:{})});
      }
      return out;
    }};
  }
  if(texture==='line'&&Array.isArray(role.given)&&role.given.length){
    const quarter=beatSeconds*(Number(meter?.denominator)||4)/4,shift=Number.isFinite(role.givenOctave)?role.givenOctave:givenShift(role.given.map(note=>note.pitch),{centre,compass});
    // (Improvised on as far as its conductor allows: its given notes kept where they are, figures between them.)
    const required=role.motifUse?.required===true;
    const requiredPitches=required?requiredMotifPitches(role.given,{centre,compass,octave:role.givenOctave}):null;
    const short=required&&role.given.some((note,index)=>note.quarters*quarter<shortest||index>0&&(note.at-role.given[index-1].at)*quarter<shortest);
    const conflict=required&&(!requiredPitches||short);
    if(conflict){
      const fallback=role.motifFallback?makeVoice(role.motifFallback,{random,start,beatSeconds,meter,pool,instrument,bandBeat,bandBeatTicks,compass,planBeat,heard,onScoreRevision}):{events(){return []}};
      return {...fallback,motifConflict:{motifIds:role.motifUse.motifIds,winner:!requiredPitches?'physical-compass':'physical-minimum-note',compromised:'required-motif',resolution:role.motifFallback?'ordinary formation':'rest'}};
    }
    const quarterTicks=new R((Number(meter?.subdivision)||1)*(Number(meter?.denominator)||4),4);
    // (Each written where its line says it was written -- a remembered motif's players' quarters, motifs.js -- else at its
    // authored quarters: a fugue's subject's.)
    // (A stored motif's note, where it names one -- motif-insistence.js fitInsistedLines -- said as its `source`.)
    const given=role.given.map((note,index)=>({scoreTime:scoreTime(Q(note.written??note.at).mul(quarterTicks),Q(note.writtenQuarters??note.quarters).mul(quarterTicks),{axis:'phrase'}),at:start+note.at*quarter,pitch:required?requiredPitches[index]:note.pitch+shift,
      seconds:required?note.quarters*quarter:Math.max(.05,note.quarters*quarter*ARTICULATION),written:note.quarters*quarter,
      ...(typeof note.motifId==='string'&&Number.isInteger(note.index)?{source:Object.freeze({motifId:note.motifId,index:note.index})}:{})}));
    const improvising=required?null:improvisation(role,{start,beatSeconds,meter,pool,compass,heard,shortest}),notes=improvising?improvising.figured(given):given;
    let peak;
    return {events(now,until,{left,clock}={}){
      if(peak===undefined){peak=Number.isFinite(left)?peakOf(given,start,Math.max(INSTANT,now+left-start)):null;if(peak!=null)notes.forEach(note=>{note.peak=peak})}
      return notes.filter(note=>note.at>=now-EPSILON&&note.at<until-EPSILON).map(note=>note.figure?{...note,pitch:improvising.pitch(note,clock)}:note);
    }};
  }
  if(texture==='line'){
    // (Its section's entry of a line the pool's sections share (conducting/entries.js): its delay and its pitch map, a
    // doubling, a planing or a canon of the line every section's voice plans alike.)
    // (Its octave chosen with every other section's once its line is planned -- every note of each section's entry in
    // its register, the line moved whole: entries.js jointEntries, Astra's CFM-004 -- else as drawn.)
    const entry=role.entry??null,delayBeats=entry?entryDelay(entry,groupsOf(meter)):0,delay=delayBeats*beatSeconds;let sounding=entry;
    const entered=pitch=>sounding?entryPitch(pitch,sounding,ladderOf(pool)):pitch;
    // (Improvised on as far as its conductor allows, a stretched line aside: its notes kept where they are, figures
    // between them; never a line its elongation spells exactly.)
    const improvising=improvisation(role,{start,beatSeconds,meter,pool,compass,heard,shortest});
    let planned=null,line=null,peak=null,last=null;const sounded=new Set;
    return {events(now,until,{position,left,clock}){
      const out=[];
      // (Its own rubato: behind or ahead of the beat as its pool's arch has it at that point of the phrase, together
      // again at its ends; a note ahead of its beat sounded in the window before its beat's, decided before it is drawn.)
      // (Ahead or behind, its pool's share of its phrase as drawn, no further than its conductor's ownTime.)
      const phrase=left/Math.max(1e-6,1-position),drawn=(Number(parameters?.rubato)||0)*phrase;
      const allowed=Number.isFinite(role.ownTime)?role.ownTime:SECTION_VOICES.leads,depth=Math.sign(drawn)*Math.min(Math.abs(drawn),allowed);
      const lagAt=t=>depth*Math.sin(Math.PI*Math.max(0,Math.min(1,position+(t-now)/Math.max(INSTANT,phrase))));
      // (Its phrase planned whole, once, from the phrase's downbeat: sectionLine.)
      // (From the phrase's own downbeat, the voice's start: the window's time and the phrase's place disagree where a seat
      // catches up into its phrase.)
      // (No line where it hears no harmony at all: nothing is walked in its place -- the owner, 3 October 2026, "DON'T
      // HARDCODE FALLBACKS"; a register too narrow for the harmony is widened to it, sectionLine.)
      planned??=sectionLines(role,{downbeat:start,phrase:Math.max(INSTANT,now+left-start),beatSeconds,meter,pool:pool(),instrument,planBeat,shortest:Number(quickest)||null})??[];
      {
        if(!line){line=delay?planned.map(note=>({...note,scoreTime:shiftScoreTime(note.scoreTime,Q(delayBeats).mul(Number(meter?.subdivision)||1)),at:+(note.at+delay).toFixed(6)})):planned;peak=peakOf(line,start,Math.max(INSTANT,now+left-start));
          if(improvising&&!planned.elongation)line=improvising.figured(line);
          if(entry&&role.entries&&role.entryRegisters&&role.section&&planned.length)sounding=sharedEntries(role,{planned,start,beatSeconds,meter,pool:pool(),phrase:Math.max(INSTANT,now+left-start)})?.[role.section]??entry}
        // (Each note once: in the window its time with its rubato falls in, or at once where its rubato moved it before
        // the window and its own time is still to come; in the harmony sounding then.)
        for(const [index,note] of line.entries()){
          if(note.at<start-EPSILON||sounded.has(index))continue;
          const moved=note.at+lagAt(note.at);if(moved>=until||note.at<now-EPSILON&&moved<now-EPSILON)continue;
          // (Its rubato how it is played, not its rhythm: `lag`, the seconds it sounds after its planned time, which its
          // score leaves out -- written exactly, it had made nested tuplets of every shifted note.)
          const when=Math.max(now,moved),pitch=note.figure?improvising.pitch(note,clock,last):followHarmony(note.pitch,pool(),[note.pitch-OCTAVE,note.pitch+OCTAVE]);sounded.add(index);
          const lag=when-note.at+(Number(note.lag)||0);
          last=Number.isFinite(pitch)?pitch:note.pitch;
          out.push({...scoreTimeFields(note),at:when,pitch:entered(last),seconds:heldTo(when,note.seconds,left,now),...(Number.isFinite(note.written)?{written:heldTo(note.at,note.written,left,now)}:{}),...(Math.abs(lag)>INSTANT?{lag:+lag.toFixed(6)}:{}),...(peak!=null?{peak}:{}),...(note.cadence?{cadence:true}:{}),...(note.source?{source:note.source}:{})});
        }
        return out;
      }
    }};
  }
  // (A coordinated hit (conducting/coordinated-events.js; its conductor's punctuation): the harmony's tone nearest the
  // part's place, struck on the formation's downbeat by every seat and held its beats, then nothing -- the general pause
  // -- to the formation's end.)
  if(texture==='hit'){
    let struck=false;
    return {events(now,until,options){
      const {position,left}=options,window=windowOf(options);
      if(struck||start>=until)return [];
      const tones=(pool()??[]).map(Number).filter(Number.isFinite);if(!tones.length)return [];struck=true;
      const {centre:c,width:w}=band(position),span=Math.max(OCTAVE,w*2),target=c-span/2+span*(fromTop(part,parts)+.5)/parts;
      const candidates=[];for(let octave=1;octave<=8;octave++)for(const pc of new Set(tones.map(p=>modulo(p,OCTAVE))))candidates.push(OCTAVE*octave+pc);
      const at=Math.max(now,start),seconds=Math.max(.05,Math.min((Number(parameters?.beats)||1)*bandBeat,left-(at-now)));
      // (A fugue's voice its cadence's arrival, where its conductor chose one: plex_clodbot fugueInto.)
      const length=Q(parameters?.beats||1).mul(bandBeatTicks??sub);
      return [{scoreTime:written(window.at,window.at.add(length),window),at,pitch:Number.isFinite(Number(parameters?.pitch))?Number(parameters.pitch):nearestIn(candidates,target),seconds}];
    }};
  }
  if(texture==='figuration'){
    // (A compound melody (compound-melody.js): the pool's figure a walk over as many voices as it walks tones
    // (figuration.js), each voice led from chord to chord by the least motion within the part's place in the band, as a
    // chorale's voices are -- an Alberti bass's bass, inner voice and top, an arpeggio's chord tones, a trill's two --
    // the walk planned a bar at a time from where the last ended, as fast as its rate's share of its players' quickest
    // notes, and each note's voice sounding the pitch it is led to when the note sounds, so the figure follows a harmony
    // that moves inside its bar; every part of the pool the same walk, each in its own place.)
    const {positions,barSeconds,barTicks}=metricalGrid(meter,beatSeconds),most=1/shortest,n=Math.max(1,Math.round(Number(parameters.tones)||3)),queue=[];
    // (Its walk over the same voices no longer than its listeners are projected to take one pitch's going on (repetition.js
    // seconds): then each voice moved to the chord tone above it in its place, the next inversion, the harmony kept --
    // Op. 3.28's figuration had walked one two-note cell 32 times running.)
    const tolerance=repetitionOf(role.repetition??null),inverted=(voices,tones)=>voices.map(v=>tones.find(t=>t>v+.25)??tones.find(t=>Math.abs(t-v)>.25)??v).sort((a,b)=>a-b);
    let next=start,barIndex=0,voices=null,since=start;
    return {events(now,until,options){
      const {position,left}=options,window=windowOf(options);
      const {centre:c,width:w}=band(position),span=Math.max(OCTAVE,w*2),low=c-span/2+span*fromTop(part,parts)/parts,high=low+Math.max(OCTAVE,span/parts);
      const classes=[...new Set((pool()??[]).map(Number).filter(Number.isFinite).map(p=>+modulo(p,OCTAVE).toFixed(6)))],chordTones=[];
      for(let octave=1;octave<=8;octave++)for(const pc of classes)chordTones.push(OCTAVE*octave+pc);
      const tones=chordTones.filter(p=>p>=low-EPSILON&&p<=high+EPSILON).sort((a,b)=>a-b);
      if(tones.length)voices=voices?leadVoices(voices,tones):spreadVoices(tones,n);
      while(next<until&&left>next-now){
        const seconds=Math.min(barSeconds,left-(next-now));
        if(!voices?.length||!(seconds>.05)){next+=barSeconds;barIndex++;continue}
        if(next-since>=tolerance.seconds-EPSILON&&tones.length>1){voices=inverted(voices,tones);since=next}
        const walk=figure({set:voices.map((_,k)=>k),positions,barSeconds,barTicks,scoreStart:barIndex*barTicks,scoreEnd:R.of((barIndex+1)*barTicks).min(window.end),start:next,seconds,rate:(parameters.rate??.5)*most,shortest,tones:voices.length,direction:parameters.direction,turn:parameters.turn,anchor:parameters.anchor,random});
        for(const note of walk)if(note.at>=now-EPSILON)queue.push({...scoreTimeFields(note),at:note.at,voice:note.pitch,seconds:note.seconds});
        next+=barSeconds;barIndex++;
      }
      const out=[];
      while(queue.length&&queue[0].at<until-EPSILON){const note=queue.shift();if(voices?.[note.voice]!=null)out.push({...scoreTimeFields(note),at:note.at,pitch:+voices[note.voice].toFixed(4),seconds:note.seconds})}
      return out;
    }};
  }
  // (Every other texture a point in the texture space, made by its process: its pool's own point, drawn as every bot of
  // the pool draws it; what an older conductor said of a chord's pulse and gate, a cloud's pulse, a canon's drift and a
  // glissando's hold, as it says.)
  const located=pointOfRole(role);if(!located||familyOf(texture)!=='process')return {events(){return []}};
  const point={...drawnPoint(located,role.seed??0)},given=role.parameters??{},number=value=>Number.isFinite(Number(value))&&value!==null&&value!==''?Number(value):null;
  for(const [from,to,as=x=>x] of [['pulse','pulse'],['gate','sustain'],['drift','drift'],['hold','glide',x=>1-x]])if(number(given[from])!=null)point[to]=clamp(as(number(given[from])),0,1);
  return processVoice(role,{point,parameters,start,beatSeconds,meter,pool,shortest,band,written,windowOf,heldTo,onScoreRevision});
}
