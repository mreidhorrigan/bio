// Figurations generated, not listed (the owner, 2 October 2026: "The system currently does not use many idiomatic
// gestures for a variety of instruments, such as drum rolls (flexible, not pre-sample), arpeggios and alberti bass for
// keyboards, and guitar tremoloes, among others. Eventually these idiomatic gestures can cross-inspire other
// instruments -- and it would be good to have a logic for generating idioms like these, not just hardcoding each").
//
// A figuration is a set of tones (a chord's, or a note and its neighbours) walked over the meter's positions at a rate,
// each step's tone chosen by a few continuous parameters, so that the idioms are points in one space and every point
// between them is a figuration too (shared with the drum kit's strokes and the strings' tremolo, which are its one-tone
// corner):
//   tones      how many of the set it walks (1: one tone repeated -- a tremolo, a roll; 2: two alternating -- a trill, a
//              bisbigliando; 3 and more: a broken chord, an arpeggio)
//   direction  -1 down to 1 up: which way a run of the walk goes
//   turn       0 to 1: how often the walk turns back (0 a run through the tones and round again, as an arpeggio; 1 a zigzag,
//              as an Alberti bass's upper tones or a trill)
//   anchor     0 to 1: how surely the lowest tone falls on the meter's strong positions (1: on every one, as an Alberti
//              bass's and a stride's bass; 0: wherever the walk is)
//   alternate  0 to 1: how often an anchor's bass is the other of its two lowest tones than the anchor before's (1: a
//              guitarist's alternating thumb, a Travis picking's or a boom-chick's; 0: the lowest every time)
//   rate       notes a second, the instrument's quickest the limit (its `shortest` note, s)
// An Alberti bass is tones 3, anchor 1, turn 1 (low, high, middle, high); a rising arpeggio tones 3 or more, direction 1,
// turn 0, anchor 0; a trill tones 2, turn 1; a tremolo tones 1. Each instrument takes the ones it affords (Huron and
// Berec 2009, "Characterizing Idiomatic Organization in Music: A Theory and Case Study of Musical Affordances",
// Empirical Musicology Review 4(3), doi:10.18061/1811/44531): a string's tremolo is its bow's, a drum's roll its sticks'.

import {Rational as R} from '../../transcript/rational.js';
import {scoreTime} from '../score-time.js';

// A figuration's notes over `seconds` from `start`: `set` its tones (pitches, low to high), the meter's positions
// (section-voices.js metricalGrid: [{at, weight}] in a bar of `barSeconds`), at most `rate` a second and no quicker than
// `shortest`. random: [0, 1). -> [{at, pitch, seconds, index (its tone's)}].
export function figure({set,positions,barSeconds,barTicks=positions?.length,scoreStart=0,scoreEnd=null,start=0,seconds,rate=8,shortest=.08,tones=3,direction=1,turn=0,anchor=0,alternate=0,random=Math.random}){
  const sorted=[...new Set(set.map(Number).filter(Number.isFinite))].sort((a,b)=>a-b);if(!sorted.length||!(seconds>0)||!positions?.length)return [];
  const n=Math.max(1,Math.min(sorted.length,Math.round(tones))),used=n>=sorted.length?sorted:spread(sorted,n);
  // (Its grid: the meter's positions as many a second as its rate allows, the strongest first where it thins them.)
  const each=Math.max(rate>0?1/rate:Infinity,shortest),bar=positions.map(position=>position.at).sort((a,b)=>a-b),slot=bar.length>1?bar[1]-bar[0]:barSeconds;
  // (Thinned to its rate, or, quicker than the meter's finest positions -- a tremolo's -- each of them divided, the
  // divisions weighed under the finest.)
  const keep=Math.max(1,Math.round(each/Math.max(1e-6,slot))),split=Math.max(1,Math.floor(slot/each+1e-9)),finest=Math.min(...positions.map(position=>position.weight));
  const step=positions.length>1?R.of(positions[1].scoreAt??1).sub(positions[0].scoreAt??0):R.of(barTicks);
  const grid=split>1?positions.flatMap(position=>Array.from({length:split},(_,k)=>({...position,at:position.at+k*slot/split,scoreAt:position.scoreAt!=null?R.of(position.scoreAt).add(step.mul(new R(k,split))):null,weight:k?finest/2:position.weight}))):positions.filter((_,k)=>k%keep===0);
  const times=[];for(let b=0;start+b*barSeconds<start+seconds-1e-9;b++)for(const position of grid){
    const at=start+b*barSeconds+position.at,scoreAt=position.scoreAt!=null?R.of(scoreStart).add(b*barTicks).add(position.scoreAt):null;
    if(at<start+seconds-1e-9&&(scoreEnd==null||scoreAt?.lt(scoreEnd)))times.push({at,scoreAt,weight:position.weight});
  }
  // (Its anchors: the meter's level just above its grid's finest -- its notes' starts in a grid of their subdivisions.)
  const levels=[...new Set(grid.map(position=>position.weight))].sort((a,b)=>b-a),anchorLevel=levels.length>1?levels.at(-2):levels[0];
  // (Its walk above its bass: above both of its basses where it alternates between two.)
  const top=used.length-1,floor=anchor>0&&used.length>2?(alternate>0&&used.length>3?2:1):0;
  let index=direction>=0?0:top,way=direction>=0?1:-1,anchored=anchor>0&&direction>=0,bass=0;const out=[];
  for(const [k,{at,weight}] of times.entries()){
    if(k>0&&used.length>1){
      // (The lowest tone on an anchor as surely as it is anchored; after it, the walk again from its far end, as an
      // Alberti bass's upper tones begin each beat from the top; else a step its way, or back.)
      // (Its bass the other of the two lowest than the last, as often as it alternates.)
      if(weight>=anchorLevel-1e-9&&random()<anchor){if(alternate>0&&used.length>2&&random()<alternate)bass=1-bass;index=bass;anchored=true}
      else if(anchored&&floor){index=direction>=0?top:floor;way=direction>=0?-1:1;anchored=false}
      else{
        if(random()<turn)way=-way;
        let next=index+way;
        if(next<floor||next>top){if(turn>=.5){way=-way;next=index+way}else next=way>0?floor:top}
        index=Math.max(0,Math.min(top,next));anchored=false;
      }
    }
    const end=times[k+1]?.at??start+seconds;
    const symbolic=scoreEnd!=null?{scoreTime:scoreTime(times[k].scoreAt,R.of(times[k+1]?.scoreAt??scoreEnd).sub(times[k].scoreAt),{axis:'phrase'})}:{};
    out.push({...symbolic,at:+at.toFixed(6),pitch:used[index],seconds:+Math.max(shortest*.5,end-at).toFixed(6),index});
  }
  return out;
}
// A figure heard from another player, offered to this one (the owner, 2 October 2026: "Eventually these idiomatic gestures
// can cross-inspire other instruments"): each of the player's own figure's parameters moved toward the heard one's by
// `share` (0 its own, 1 the heard), in the space they share -- its tones within the player's own `tones` [fewest, most],
// its rate a share of each player's own quickest note -- so an Alberti bass heard from a piano becomes a guitarist's or a
// string section's within what each affords. -> the figure's parameters.
export const FIGURE_KEYS=Object.freeze(['tones','direction','turn','anchor','rate']);
export function inspiredFigure(own,heard,share,{tones:[fewest,most]=[1,Infinity]}={}){
  const s=Math.max(0,Math.min(1,Number(share)||0));if(!heard||!(s>0))return own;
  const lerp=(a,b)=>Number.isFinite(Number(b))?+(a+(Number(b)-a)*s).toFixed(4):a,unit=x=>Math.max(0,Math.min(1,x));
  return {...own,tones:Math.max(fewest,Math.min(most,Math.round(lerp(Number(own.tones)||1,heard.tones)))),direction:Math.max(-1,Math.min(1,lerp(Number(own.direction??1),heard.direction))),
    turn:unit(lerp(Number(own.turn)||0,heard.turn)),anchor:unit(lerp(Number(own.anchor)||0,heard.anchor)),rate:unit(lerp(Number(own.rate)||0,heard.rate))};
}
// How near a heard figure is to the space's one-tone corner -- a tremolo, a roll (the owner, 2 October 2026: "drum
// rolls (flexible, not pre-sample)"): 1 at one tone, falling to 0 at `most` tones, by its rate (0 to 1, of its player's
// quickest). A tremolo said by a section, or a roll by a drummer, is a figure there; the others' figures, the
// tremolo's amount and the rolls' share move toward it as far as each player's inspiration.
export const oneTone=(figure,{most=4}={})=>{if(!figure)return 0;const tones=Math.max(1,Number(figure.tones)||1);return Math.max(0,1-(tones-1)/Math.max(1,most-1))*Math.max(0,Math.min(1,Number(figure.rate)||0))};
// A tremolo's or a roll's figure: one tone at `rate` of its player's quickest.
export const oneToneFigure=rate=>({tones:1,direction:1,turn:0,anchor:0,rate:Math.max(0,Math.min(1,Number(rate)||0))});
// A figure said for the others to hear (/broadcast/figure). -> the payload.
export const figurePayload=(voice,shape,bar)=>({voice:String(voice),...Object.fromEntries(FIGURE_KEYS.map(key=>[key,+Number(shape[key]??(key==='direction'?1:0)).toFixed(3)])),...(Number.isInteger(bar)?{bar}:{})});
// n of a sorted set's tones spread across it (its lowest and highest kept).
function spread(sorted,n){
  if(n===1)return [sorted[0]];
  return Array.from({length:n},(_,k)=>sorted[Math.round(k*(sorted.length-1)/(n-1))]);
}
// The idioms named as points of the space (for tests and descriptions: a figuration is never chosen by name).
export const IDIOMS=Object.freeze({
  alberti:Object.freeze({tones:3,direction:1,turn:1,anchor:1}),
  arpeggio:Object.freeze({tones:4,direction:1,turn:0,anchor:0}),
  trill:Object.freeze({tones:2,direction:1,turn:1,anchor:0}),
  tremolo:Object.freeze({tones:1,direction:1,turn:0,anchor:0}),
});
