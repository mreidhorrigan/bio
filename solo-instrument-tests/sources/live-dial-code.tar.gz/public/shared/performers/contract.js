// The performer contract: who plays, on what, and how, as resources, compound actions, reservations in time, state that
// survives, the evidence behind each claim, and a witness for a passage. The general performer–instrument report's M1
// (research/MUSEBOTS_GENERAL_PERFORMER_INSTRUMENT_CONSTRAINTS.md §§1.3, 2.3–2.5, 9; its reference kernels, §17.2, ported
// here), so that a drummer (drummer.js) and a pianist (keyboard.js) pass through one interface, and a harp or an adapted
// controller needs a profile and its actions, not a new solver.
//
// **Resources have arbitrary ids** (§2.3): nothing here presumes two hands, ten fingers or two feet. A resource may have
// parents (a finger's hand), and actions that hold a parent in different configurations at once conflict even when their
// own resources differ (A04); a claim on a child that names no configuration for its parents cannot be checked, and says
// so. Unavailable, prohibited and unknown stay three things (A02), never one penalty.
//
// **A compound action is compiled once** (§9.2): a rebound pair is two contacts and one reservation of its hand; a chord
// is one configuration of the hand and one reservation of each finger, so five contacts in one chord do not take five
// hands, and five independent tracks do not share a hand by each claiming a different finger.
//
// **A reservation has a positive duration and a phase** (prepare, excite, hold, transfer, release, recover): a note is
// not an instant, and an action cannot evade occupancy by being written as one.
//
// **The answers are scoped** (§1.3): a witness means the declared model's checks passed for this passage, not that a
// person can play it; a search that ran out of budget, or found no path among the candidates it was given, is not an
// impossibility, and an unmeasured capability is unknown, never a pass. Times here are seconds; score time stays exact
// (Rationals of ticks) until a passage is checked.

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const STATUS=Object.freeze({
  witness:'witness-within-declared-model',violates:'violates-declared-constraint',outside:'outside-calibrated-domain',
  unknown:'unknown',budget:'search-budget-exhausted',noPath:'no-path-in-candidate-graph',invalid:'invalid-model',
});
// (With the world-instruments report's statuses, §12.1: mechanism-derived, model-estimated, simulated; evidence.js.)
export const EVIDENCE_KINDS=Object.freeze(['player-confirmed','measured','mechanism-derived','authored','model-estimated','simulated','inferred','unknown']);
export const RESOURCE_KINDS=Object.freeze(['effector','body','support','controller','actuator','mechanism']);
export const PHASES=Object.freeze(['prepare','excite','hold','transfer','release','recover']);
export const AVAILABILITY=Object.freeze(['available','unavailable','unknown']);
// Why a check failed or could not be made: kept apart, so no two become one number.
export const REASONS=Object.freeze({unavailable:'unavailable',prohibited:'prohibited',capacity:'capacity',configuration:'configuration',technique:'technique',
  unknownResource:'unknown-resource',noConfiguration:'no-configuration',outsideEnvelope:'outside-envelope',unmeasured:'unmeasured',
  otherContext:'other-context',noDemand:'no-demand'});
const CONFIGURATION_OF=action=>`action:${action}`;   // a parent claimed outright: a configuration no other action shares
// Floating slack in totals (the reference kernels'); and the grain times are compared at: two instants within a
// nanosecond are one (so a stroke that ends where the next begins, each computed its own way, does not overlap it).
// The only quantization here, far below anything heard (F05). Exported for a performer's rules in closed form, which
// read time as these checks do (drummer.js handsAllow).
export const SLACK=1e-12;
export const TIME_GRAIN=1e-9;
export const instant=seconds=>Math.round(seconds/TIME_GRAIN);

const finite=(value,name)=>{if(typeof value!=='number'||!Number.isFinite(value))throw new TypeError(`${name}: a finite number`);return value};
const nonnegative=(value,name)=>{finite(value,name);if(value<0)throw new RangeError(`${name}: at least 0`);return value};
const identifier=(value,name)=>{if(typeof value!=='string'||!value.length)throw new TypeError(`${name}: a nonempty string`);return value};
const oneOf=(value,list,name)=>{if(!list.includes(value))throw new TypeError(`${name} is ${list.join(', ')}, not ${value}`);return value};

// ---- Profiles --------------------------------------------------------------------------------------------------------
// A performer–instrument profile: {id, version, performer, resources, prohibited (techniques the performer has ruled
// out), controls, evidence}. Each resource {id, kind, availability, capacity, parents, evidence}, its capacity in its own
// units (one action at a time for a limb or a finger); an unknown resource's capacity is unknown too. `controls` are the
// profile's control mappings (§2.3's controlled-through, §9's controlMappings): [{mechanism, through}], an instrument's
// mechanism (a pedal, a latch) worked through one of the profile's resources (a foot, a knee lever, a switch, a head
// tracker). Validated and frozen. A resource given no capacity takes one action at a time, the declared model's own
// assumption, and the profile lists it as `defaulted` so that a witness can say so (the world-instruments report's
// phase A: no number from a missing field goes unsaid).
export function profile({id,version='1',performer,resources=[],prohibited=[],controls=[],evidence=[]}={}){
  identifier(id,'profile id');identifier(performer,'performer');
  const byId=new Map;
  for(const resource of resources){
    identifier(resource.id,'resource id');
    if(byId.has(resource.id))throw new TypeError(`resource ${resource.id} twice`);
    const availability=oneOf(resource.availability??'available',AVAILABILITY,`${resource.id}: availability`);
    byId.set(resource.id,Object.freeze({id:resource.id,kind:oneOf(resource.kind??'effector',RESOURCE_KINDS,`${resource.id}: kind`),availability,
      capacity:availability==='unknown'?null:nonnegative(resource.capacity??1,`${resource.id} capacity`),
      parents:Object.freeze([...(resource.parents??[])]),evidence:oneOf(resource.evidence??'authored',EVIDENCE_KINDS,`${resource.id}: evidence`)}));
  }
  for(const resource of byId.values())for(const parent of resource.parents)if(!byId.has(parent))throw new TypeError(`resource ${resource.id}: no parent ${parent}`);
  for(const resource of byId.values()){   // no resource is its own ancestor
    const seen=new Set,stack=[...resource.parents];
    while(stack.length){const next=stack.pop();if(next===resource.id)throw new TypeError(`resource ${resource.id} is its own ancestor`);if(!seen.has(next)){seen.add(next);stack.push(...byId.get(next).parents)}}
  }
  const mapped=new Map;
  for(const control of controls){
    identifier(control?.mechanism,'a control\'s mechanism');identifier(control.through,`${control.mechanism}: what works it`);
    if(!byId.has(control.through))throw new TypeError(`${control.mechanism} is worked through ${control.through}, which the profile does not have`);
    if(mapped.has(control.mechanism))throw new TypeError(`${control.mechanism} mapped twice`);
    mapped.set(control.mechanism,control.through);
  }
  const defaulted=Object.freeze(resources.filter(resource=>resource.capacity===undefined&&(resource.availability??'available')!=='unknown').map(resource=>resource.id));
  return Object.freeze({id,version:String(version),performer,resources:byId,prohibited:Object.freeze(new Set(prohibited)),controls:mapped,evidence:Object.freeze([...evidence]),defaulted});
}
// What works a mechanism for this performer: the resource it is mapped through, when that is available; otherwise null.
// A mechanism with no mapping is not the performer's to work, however many feet they have; one mapped through an
// available resource is theirs, whatever their feet (F02).
export function controlOf(who,mechanism){
  const through=who.controls?.get(mechanism);
  return through&&who.resources.get(through)?.availability==='available'?through:null;
}
// Every ancestor of a resource (its parents, theirs, and on).
export function ancestors(who,resource){
  const out=[],stack=[...(who.resources.get(resource)?.parents??[])];
  while(stack.length){const next=stack.pop();if(!out.includes(next)){out.push(next);stack.push(...who.resources.get(next).parents)}}
  return out;
}

// ---- Envelopes (the reference checkEnvelope) -------------------------------------------------------------------------
// Whether a request lies inside a declared envelope {id, status (measured | authored | unknown | forbidden), context,
// bounds: {name: [low, high]}}. The envelope is local evidence, not a universal: another context (a different keyboard,
// a changed mapping) is unknown for it, never a pass and never a failure (A05); a demand not given is unknown; a demand
// outside a declared bound is outside the calibrated domain, not proven impossible; a forbidden envelope is the
// performer's own prohibition, which violates.
//
// Its bounds are one region, the demands in it met together. An envelope of several `regions` [{id, bounds}] is their
// union, each a combination known to be reached jointly (E03): a demand inside no region is outside the evidence even
// when every one of its values lies within some region's, never a pass extrapolated from each dimension's own maximum
// (a loud top voice over a soft inner one, and a soft top over a loud inner, do not make both loud at once).
export function checkEnvelope(envelope,request){
  if(!request||typeof request!=='object')throw new TypeError('a request');
  if(!envelope||envelope.status==='unknown')return {status:STATUS.unknown,reason:REASONS.unmeasured,reasons:['an unmeasured capability']};
  if(envelope.status==='forbidden')return {status:STATUS.violates,reason:REASONS.prohibited,reasons:[envelope.reason??'not authorized by the performer']};
  oneOf(envelope.status,['measured','mechanism-derived','authored','model-estimated','simulated'],'an envelope\'s status');identifier(envelope.id,'envelope id');
  if(!envelope.context||!(envelope.bounds||envelope.regions?.length))throw new TypeError('an envelope has its context and bounds (or regions)');
  const others=Object.entries(envelope.context).filter(([key,value])=>request.context?.[key]!==value).map(([key])=>`another ${key}`);
  if(others.length)return {status:STATUS.unknown,reason:REASONS.otherContext,envelope:envelope.id,reasons:others};
  const regions=envelope.regions??[{id:envelope.id,bounds:envelope.bounds}],reasons=[];
  for(const region of regions){
    identifier(region.id,'region id');const outside=[];
    for(const [key,interval] of Object.entries(region.bounds)){
      if(!Array.isArray(interval)||interval.length!==2)throw new TypeError(`${key}: a bound is [low, high]`);
      const [low,high]=interval;finite(low,key);finite(high,key);if(low>high)throw new RangeError(`${key}: low over high`);
      if(request.values?.[key]===undefined)return {status:STATUS.unknown,reason:REASONS.noDemand,envelope:envelope.id,reasons:[`no demand given for ${key}`]};
      const value=finite(request.values[key],key);if(value<low||value>high)outside.push(`${key} ${value} outside [${low}, ${high}]`);
    }
    if(!outside.length)return {status:STATUS.witness,reason:null,envelope:envelope.id,...(envelope.regions?{region:region.id}:{}),evidence:envelope.status,reasons:[]};
    reasons.push(...(envelope.regions?[`${region.id}: ${outside.join(', ')}`]:outside));
  }
  return {status:STATUS.outside,reason:REASONS.outsideEnvelope,envelope:envelope.id,evidence:envelope.status,reasons};
}

// ---- Support (D03) ----------------------------------------------------------------------------------------------------
// What holds the instrument while it is played: each support task on the resource the setup gives it (a hand, the
// knees, a strap, a stand), held from `from` to `to`. A task on a limb occupies that limb; equipment in the profile frees
// it only where the setup gives the task to the equipment: a stand in the case holds nothing. supports: [{task, by}] ->
// actions, one each, for checkReservations with the passage's own.
export function supportActions(who,supports,{from,to}){
  finite(from,'from');finite(to,'to');if(!(to>from))throw new RangeError('a support is held for a positive time');
  return supports.map(({task,by})=>{
    identifier(task,'a support task');identifier(by,'what holds it');
    if(!who.resources.has(by))throw new RangeError(`${who.id} has no ${by} to hold the ${task}`);
    return action({id:`support:${task}`,technique:'support',contacts:[],reservations:[{resource:by,phase:'hold',start:from,end:to,configuration:`support:${task}`}]});
  });
}

// ---- Tempo (§2, F07, E04) --------------------------------------------------------------------------------------------
// The tempi a passage plays at, as intervals, not a maximum: a slower tempo can fail a continuous action (a held breath,
// a bow, a pedal held) that a faster one keeps. Exactly, for conditions stated in beats (F07): a transition over `beats`
// needing at least `minSeconds` bounds the tempo from above (bpm at most 60·beats/minSeconds), and a continuous action
// over `beats` allowed at most `maxSeconds` bounds it from below. [low, high] bpm, or null when none plays.
export function tempoInterval(conditions){
  let low=0,high=Infinity;
  for(const condition of conditions){
    const beats=nonnegative(condition.beats,'beats');
    if(condition.minSeconds!==undefined)high=Math.min(high,60*beats/nonnegative(condition.minSeconds,'minSeconds'));
    if(condition.maxSeconds!==undefined)low=Math.max(low,60*beats/nonnegative(condition.maxSeconds,'maxSeconds'));
  }
  return low<=high?[low,high]:null;
}
// And through a planner, whose conditions are its own: `playsAt(bpm)` says whether the passage plays at a tempo. The tempi
// from `from` to `to` are tried `step` apart, and each change of verdict narrowed by halves to `resolution` bpm. Nothing
// between two tries is assumed, so an interval narrower than `step` can be missed; the result says the step and the
// resolution it was found at (F05). An interval reaching `from` or `to` may go on beyond it. {intervals: [[low, high]],
// range, step, resolution}
export function tempoIntervals(playsAt,{from,to,step,resolution=step/64}){
  if(typeof playsAt!=='function')throw new TypeError('tempoIntervals takes playsAt(bpm)');
  finite(from,'from');finite(to,'to');if(!(from>0&&to>from))throw new RangeError('a tempo range from above 0 to above it');
  if(!(step>0&&resolution>0&&resolution<=step))throw new RangeError('a step, and a resolution at most the step');
  const tempi=[];for(let bpm=from;bpm<to+SLACK;bpm+=step)tempi.push(Math.min(bpm,to));
  if(tempi.at(-1)<to)tempi.push(to);
  const verdicts=tempi.map(bpm=>Boolean(playsAt(bpm))),intervals=[];let low=verdicts[0]?from:null;
  for(let i=1;i<tempi.length;i++){
    if(verdicts[i]===verdicts[i-1])continue;
    let a=tempi[i-1],b=tempi[i];
    while(b-a>resolution){const middle=(a+b)/2;if(Boolean(playsAt(middle))===verdicts[i-1])a=middle;else b=middle}
    if(verdicts[i])low=b;else{intervals.push([low,a]);low=null}
  }
  if(low!==null)intervals.push([low,to]);
  return {intervals,range:[from,to],step,resolution};
}

// ---- Actions and reservations (the reference checkReservations, with configurations) ---------------------------------
// An action: {id, technique?, performer?, contacts: [ids], contactSeconds: [when each sounds], reservations:
// [{resource, phase, start, end, amount?, configuration?}]}, compiled once for a compound gesture. `configuration` names
// the joint configuration (a hand's shape, a grip) the reservation holds its resource's ancestors in.
export function action({id,technique=null,performer=null,contacts=[],contactSeconds=[],reservations=[]}){
  identifier(id,'action id');contactSeconds.forEach(seconds=>finite(seconds,`${id}: a contact's seconds`));
  const held=reservations.map(reservation=>{
    identifier(reservation.resource,`${id}: a reservation's resource`);oneOf(reservation.phase,PHASES,`${id}: a phase`);
    finite(reservation.start,'start');finite(reservation.end,'end');
    if(!(reservation.end>reservation.start))throw new RangeError(`${id}: a reservation lasts a positive time (a note is not an instant)`);
    const amount=reservation.amount??1;if(!(finite(amount,'amount')>0))throw new RangeError(`${id}: a reservation's amount is positive`);
    return Object.freeze({...reservation,amount,configuration:reservation.configuration??null});
  });
  return Object.freeze({id,technique,performer,contacts:Object.freeze([...contacts]),contactSeconds:Object.freeze([...contactSeconds]),reservations:Object.freeze(held)});
}
// Every action's reservations against a profile, together (all the parts one performer plays share its timeline, G04):
// each resource's capacity over time (releases before acquisitions at one instant); each parent held in one
// configuration at a time (a parent reserved outright is held in a configuration of that action alone); a prohibited
// technique or an unavailable resource a violation; an unknown resource, or a child reserved with no configuration for
// its parents, unknown. {status, violations, unknowns}, each entry with its `reason` (REASONS).
export function checkReservations(who,actions){
  const violations=[],unknowns=[],load=new Map,held=new Map,seen=new Set,clashes=new Set;
  const parents=new Set([...who.resources.values()].flatMap(resource=>resource.parents));
  const hold=(resource,entry)=>{if(!held.has(resource))held.set(resource,[]);held.get(resource).push(entry)};
  for(const act of actions){
    if(seen.has(act.id))throw new TypeError(`action ${act.id} twice`);seen.add(act.id);
    if(act.technique&&who.prohibited.has(act.technique))violations.push({action:act.id,reason:REASONS.prohibited,technique:act.technique});
    for(const reservation of act.reservations){
      const resource=who.resources.get(reservation.resource);
      if(!resource||resource.availability==='unknown'){unknowns.push({action:act.id,resource:reservation.resource,reason:REASONS.unknownResource});continue}
      if(resource.availability==='unavailable'){violations.push({action:act.id,resource:reservation.resource,reason:REASONS.unavailable});continue}
      if(!load.has(resource.id))load.set(resource.id,[]);
      load.get(resource.id).push({t:reservation.start,delta:reservation.amount,action:act.id},{t:reservation.end,delta:-reservation.amount,action:act.id});
      const span={start:reservation.start,end:reservation.end,action:act.id};
      const above=ancestors(who,resource.id);
      if(above.length&&!reservation.configuration)unknowns.push({action:act.id,resource:resource.id,reason:REASONS.noConfiguration,parents:above});
      else for(const parent of above)hold(parent,{...span,configuration:reservation.configuration});
      if(parents.has(resource.id))hold(resource.id,{...span,configuration:reservation.configuration??CONFIGURATION_OF(act.id)});
    }
  }
  for(const [id,events] of load){
    events.sort((a,b)=>instant(a.t)-instant(b.t)||a.delta-b.delta);
    let used=0;const capacity=who.resources.get(id).capacity;
    for(const event of events){used+=event.delta;if(used>capacity+SLACK)violations.push({resource:id,at:event.t,action:event.action,reason:REASONS.capacity,used,capacity})}
  }
  for(const [id,list] of held){
    list.sort((a,b)=>a.start-b.start);
    for(let i=0;i<list.length;i++)for(let j=i+1;j<list.length&&instant(list[j].start)<instant(list[i].end);j++){
      const a=list[i],b=list[j];
      const clash=`${id}\u0000${[a.action,b.action].sort().join('\u0000')}`;
      if(a.action!==b.action&&a.configuration!==b.configuration&&instant(b.end)>instant(a.start)&&!clashes.has(clash)){
        clashes.add(clash);violations.push({resource:id,at:b.start,reason:REASONS.configuration,actions:[a.action,b.action],configurations:[a.configuration,b.configuration]});
      }
    }
  }
  return {status:violations.length?STATUS.violates:unknowns.length?STATUS.unknown:STATUS.witness,violations,unknowns};
}

// ---- Geometry and stores (the reference kernels, as they were) -------------------------------------------------------
// Pairwise distances between points (millimetres, xyz), each pair within [minMm, maxMm]: necessary checks only, never a
// whole posture. A pair naming a missing point or no bound is unknown.
export function checkPairGeometry(points,pairs){
  const at=new Map;
  for(const point of points){
    identifier(point.id,'point id');if(at.has(point.id))throw new TypeError(`point ${point.id} twice`);
    if(!Array.isArray(point.xyz)||point.xyz.length!==3)throw new TypeError(`${point.id}: xyz`);
    point.xyz.forEach(value=>finite(value,'a coordinate in mm'));at.set(point.id,point.xyz);
  }
  const violations=[],unknowns=[];
  for(const pair of pairs){
    if(!at.has(pair.a)||!at.has(pair.b)||pair.maxMm==null){unknowns.push(pair);continue}
    nonnegative(pair.maxMm,'maxMm');const least=nonnegative(pair.minMm??0,'minMm');if(least>pair.maxMm)throw new RangeError('minMm over maxMm');
    const a=at.get(pair.a),b=at.get(pair.b),distance=Math.hypot(...a.map((value,i)=>value-b[i]));
    if(distance<least-SLACK||distance>pair.maxMm+SLACK)violations.push({a:pair.a,b:pair.b,distanceMm:distance});
  }
  return {status:violations.length?STATUS.violates:unknowns.length?STATUS.unknown:STATUS.witness,violations,unknowns};
}
// A finite store (a bow's travel, declared breath credits, a battery) under explicit consume and refill commands
// {kind, start, end, rate}, no two overlapping: nothing refills itself in a silence (C04). Never physiology.
export function simulateStore({capacity,initial},commands){
  nonnegative(capacity,'capacity');nonnegative(initial,'initial');if(initial>capacity)throw new RangeError('initial over capacity');
  let value=initial,previousEnd=-Infinity;const history=[];
  for(const command of [...commands].sort((a,b)=>a.start-b.start)){
    finite(command.start,'start');finite(command.end,'end');nonnegative(command.rate,'rate');
    if(command.end<=command.start||command.start<previousEnd)throw new RangeError('commands are positive and do not overlap');
    oneOf(command.kind,['consume','refill'],'a store command');
    const amount=command.rate*(command.end-command.start),next=command.kind==='consume'?value-amount:Math.min(capacity,value+amount);
    if(next<-SLACK)return {status:STATUS.violates,reason:REASONS.capacity,at:command.rate>0?command.start+value/command.rate:command.start,value,history};
    value=Math.max(0,next);previousEnd=command.end;history.push({end:command.end,value});
  }
  return {status:STATUS.witness,value,history};
}

// ---- Search (the reference planLayered) ------------------------------------------------------------------------------
// The cheapest path through layers of candidates {id, cost, state}, each move judged by transition(from, to) -> {status:
// supported | blocked | unknown, cost}: exact within the graph given, never beyond it (B04). The state must carry
// everything the future depends on. Running out of budget, or finding no path, is said as such (F03).
export function planLayered(layers,initial,transition,{maxEdges=100000}={}){
  if(!Array.isArray(layers)||typeof transition!=='function')throw new TypeError('planLayered takes layers and a transition');
  if(!Number.isSafeInteger(maxEdges)||maxEdges<0)throw new RangeError('maxEdges is a whole number');
  let frontier=[{state:initial,total:0,path:[]}],edges=0,sawUnknown=false;
  for(const layer of layers){
    if(!Array.isArray(layer))throw new TypeError('a layer is a list of candidates');
    const next=[],ids=new Set;
    for(const node of layer){
      identifier(node.id,'candidate id');finite(node.cost,'candidate cost');
      if(ids.has(node.id))throw new TypeError(`candidate ${node.id} twice in a layer`);ids.add(node.id);
      let best=null;
      for(const from of frontier){
        if(edges>=maxEdges)return {status:STATUS.budget,edges};
        edges++;
        const move=transition(from.state,node.state);
        if(!move||!['supported','blocked','unknown'].includes(move.status))throw new TypeError('a transition is supported, blocked or unknown');
        if(move.status==='unknown'){sawUnknown=true;continue}
        if(move.status==='blocked')continue;
        const total=from.total+node.cost+finite(move.cost,'move cost');
        if(!Number.isFinite(total))throw new RangeError('the cost overflowed');
        if(!best||total<best.total)best={state:node.state,total,path:[...from.path,node.id]};
      }
      if(best)next.push(best);
    }
    frontier=next;
    if(!frontier.length)return {status:sawUnknown?STATUS.unknown:STATUS.noPath,edges};
  }
  frontier.sort((a,b)=>a.total-b.total);
  return {status:STATUS.witness,...frontier[0],edges,unknownAlternatives:sawUnknown};
}

// ---- Search over event groups (every instrument's planner) -----------------------------------------------------------
// The one solver an instrument's planner hands its passage to: groups of events in time order, and from each state the
// instrument's moves for the next group, expand(group, state) -> [{status: supported | blocked | unknown, cost, state,
// step}]. The state carries everything the future depends on (what is held, where each hand or finger is), and
// stateKey(state) names it; the solver keeps the cheapest path to each distinct state, so a locally cheap move that
// blocks the future loses to one that does not. No path, a move that could not be judged, and a budget run out are
// each said as such (F03). With `beam`, a group reaching more than maxStates distinct states keeps its `beam` cheapest
// (ties by name) and the search goes on: a path found so is a witness all the same (its checks are its own), marked
// `pruned` (not proved the cheapest), and none found then is a budget run out, never "no path".
// {status, path, cost, state, pruned?} or {status, group, groupIndex, pruned?}.
export function searchGroups(groups,{initial,expand,stateKey,maxStates=4096,beam=null}){
  if(!Array.isArray(groups)||typeof expand!=='function'||typeof stateKey!=='function')throw new TypeError('searchGroups takes groups, expand and stateKey');
  if(beam!==null&&!(Number.isInteger(beam)&&beam>0&&beam<=maxStates))throw new RangeError('a beam keeps from 1 to maxStates states');
  let frontier=new Map([[stateKey(initial),{cost:0,path:[],state:initial}]]),pruned=false;
  for(const [index,group] of groups.entries()){
    let next=new Map,sawUnknown=false;
    for(const entry of frontier.values())for(const move of expand(group,entry.state)){
      oneOf(move.status,['supported','blocked','unknown'],'a move');
      if(move.status==='unknown'){sawUnknown=true;continue}
      if(move.status==='blocked')continue;
      const cost=entry.cost+finite(move.cost,'move cost'),key=stateKey(move.state);
      if(!next.has(key)||next.get(key).cost>cost)next.set(key,{cost,path:[...entry.path,move.step],state:move.state});
    }
    if(!next.size)return pruned?{status:STATUS.budget,group,groupIndex:index,pruned}:{status:sawUnknown?STATUS.unknown:STATUS.noPath,group,groupIndex:index};
    if(next.size>maxStates){
      if(beam===null)return {status:STATUS.budget,group,groupIndex:index,states:next.size};
      next=new Map([...next].sort((a,b)=>a[1].cost-b[1].cost||(a[0]<b[0]?-1:a[0]>b[0]?1:0)).slice(0,beam));pruned=true;
    }
    frontier=next;
  }
  const best=[...frontier.values()].sort((a,b)=>a.cost-b.cost)[0];
  return {status:STATUS.witness,path:best.path,cost:best.cost,state:best.state,...(pruned?{pruned}:{})};
}

// ---- Witnesses -------------------------------------------------------------------------------------------------------
// A state as plain, ordered data (Maps and Sets as sorted lists), so two states compare and a witness can be kept.
export function canonical(value){
  const order=(a,b)=>{const x=JSON.stringify(a),y=JSON.stringify(b);return x<y?-1:x>y?1:0};
  if(value instanceof Map)return [...value].map(([key,item])=>[canonical(key),canonical(item)]).sort(order);
  if(value instanceof Set)return [...value].map(canonical).sort(order);
  if(Array.isArray(value))return value.map(canonical);
  if(value&&typeof value==='object')return Object.fromEntries(Object.keys(value).sort().map(key=>[key,canonical(value[key])]));
  return value;
}
// A passage's witness: the profile's id and version, the actions, every check {id, status, evidence?}, the state it
// starts from, the events it passes through (applied by `apply`) and where they arrive. Invalid or violated if any
// check is; unknown if no check could be made; otherwise a witness within the declared model, with the checks it could
// not make listed as `unresolved` and those resting on inferred or unknown evidence as `inferred` (F02), and `complete`
// only when nothing is unresolved: a partial scope never reads as a whole one.
export function witness({who,actions=[],checks,initial=null,events=[],apply=null}){
  if(!Array.isArray(checks)||!checks.length)throw new TypeError('a witness has its checks');
  for(const check of checks){identifier(check.id,'check id');oneOf(check.status,Object.values(STATUS),`${check.id}: status`)}
  let terminal=initial;if(apply)for(const event of events)terminal=apply(terminal,event);
  const unresolved=checks.filter(check=>![STATUS.witness,STATUS.violates,STATUS.invalid].includes(check.status)).map(check=>check.id);
  const status=checks.some(check=>check.status===STATUS.invalid)?STATUS.invalid:checks.some(check=>check.status===STATUS.violates)?STATUS.violates
    :unresolved.length===checks.length?STATUS.unknown:STATUS.witness;
  return Object.freeze({profile:who.id,version:who.version,performer:who.performer,status,complete:status===STATUS.witness&&!unresolved.length,
    actions:Object.freeze([...actions]),checks:Object.freeze(checks.map(check=>Object.freeze({...check}))),unresolved:Object.freeze(unresolved),
    inferred:Object.freeze(checks.filter(check=>['inferred','unknown'].includes(check.evidence)).map(check=>check.id)),
    initial:canonical(initial),events:Object.freeze(events.map(event=>Object.freeze({...event}))),terminal:canonical(terminal)});
}
// Whether a witness's events, re-applied from its initial state, arrive where it says (F01). `revive` turns the kept
// plain initial state back into the live one `apply` takes.
export function replay(proof,apply,revive=state=>state){
  let state=revive(proof.initial);for(const event of proof.events)state=apply(state,event);
  return JSON.stringify(canonical(state))===JSON.stringify(proof.terminal);
}
