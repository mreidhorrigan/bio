// A bellows free-reed instrument's hands, buttons and air (the family atlas's F25, bellows free-reed keyboards and
// buttons): a piano accordion, its right hand on a keyboard and its left on the Stradella basses, one bellows feeding
// both. The world-instruments report (§5.7): "A keyboard/button selection, a reed's directionality and the mechanism
// supplying air are different variables ... Chord buttons and reed banks may trigger multiple pitches through one
// action"; and the atlas: "Not every button means one note, nor the same note in both bellows directions."
//
// **The Stradella basses.** 120 buttons: twenty columns a fifth apart, each six rows (the bellows side outward): the
// counter-bass (the fundamental's major third), the fundamental bass, and the major, minor, seventh and diminished
// chords on it. A bass button sounds its pitch class in the bass reeds' octave, and an octave over it; a chord button
// sounds its chord's three reeds within one octave, however its root lies (the seventh without its fifth, the
// diminished a root, its minor third and its major sixth: the standard layout, authored). A left hand's finger reaches
// a button a few columns either side of the hand; the hand moves to reach further.
//
// **The bellows.** Its air (a stroke's travel) is spent by the reeds it sounds, faster when louder, and it reverses at a
// phrase's join, or, where a phrase would run it short, at the latest head of a group before it does; a reversal
// articulates every sounding reed. A piano accordion is unisonoric (every key and button the same in both directions); a
// bisonoric button layout (a diatonic accordion's push and pull rows) makes the direction part of the pitch, and two
// pitches wanting opposite directions at once cannot sound (the report's §11.5). The numbers are authored.
import {STATUS} from './contract.js';
import {instrumentRange} from './instrument-ranges.js';

export const ACCORDION=Object.freeze({
  // The treble: a full-size piano accordion's 41 keys, F3 to A6 (the instrument registry's, instrument-ranges.js).
  treble:instrumentRange('accordion').range,
  // The Stradella columns' fundamentals, a fifth apart: B-double-flat to A-sharp, C the tenth (the standard 120-bass).
  columns:Object.freeze([9,4,11,6,1,8,3,10,5,0,7,2,9,4,11,6,1,8,3,10]),
  rows:Object.freeze(['counter','bass','major','minor','seventh','diminished']),
  // Each chord row's reeds, from its root (semitones).
  chords:Object.freeze({major:Object.freeze([0,4,7]),minor:Object.freeze([0,3,7]),seventh:Object.freeze([0,4,10]),diminished:Object.freeze([0,3,9])}),
  // The chord reeds' octave and the bass reeds' (MIDI, lowest to highest: a chord sounds within E-flat 3 to D4, a bass
  // within E2 to D-sharp 3 and an octave over; the registry's Stradella maps).
  chordOctave:instrumentRange('accordion').stradella.chordOctave,bassOctave:instrumentRange('accordion').stradella.bassOctave,
  bassOctaves:instrumentRange('accordion').stradella.bassOctaves,
  // The left hand: its buttons' spacing (mm, a column), and how far a finger reaches from the hand (columns).
  columnMm:12,reachColumns:2,handMmPerSecond:800,
  // The bellows: a stroke lasts `seconds` at mf sounding `reeds` reeds; each dynamic spends it faster or slower; a stroke
  // is not run under `reserve`; a reversal takes `reverseSeconds` (authored).
  bellows:Object.freeze({seconds:10,reeds:4,dynamics:Object.freeze({ppp:.5,pp:.6,p:.75,mp:.88,mf:1,f:1.3,ff:1.6,fff:1.9}),reserve:.15,reverseSeconds:.06}),
});
const modulo=(value,base)=>((value%base)+base)%base;

// The Stradella layout: [{row, column, pc (its fundamental's), x (mm)}].
export function stradella({choices=ACCORDION}={}){
  const out=[];
  choices.columns.forEach((pc,column)=>choices.rows.forEach(row=>out.push(Object.freeze({row,column,pc:row==='counter'?modulo(pc+4,12):pc,x:column*choices.columnMm}))));
  return out;
}
// The column a fundamental is on, nearest `near` (a column): its root's pitch class in the circle of fifths.
export function columnOf(pc,{near=9,choices=ACCORDION}={}){
  let best=null;
  choices.columns.forEach((root,column)=>{if(modulo(root-Math.round(pc),12)===0&&(best===null||Math.abs(column-near)<Math.abs(best-near)))best=column});
  return best;
}
// What a button sounds (MIDI pitches, low to high): a bass its pitch class in the bass reeds' octave and an octave
// over; a counter-bass likewise, its fundamental's major third; a chord its chord's reeds within the chord octave.
export function buttonNotes({row,column},{choices=ACCORDION}={}){
  const root=choices.columns[column];
  const inOctave=(pc,[low,high])=>{let pitch=low+modulo(pc-low,12);if(pitch>high)pitch-=12;return pitch};
  if(row==='bass'||row==='counter'){const pitch=inOctave(row==='counter'?root+4:root,choices.bassOctave);return choices.bassOctaves.map(shift=>pitch+shift)}
  return choices.chords[row].map(step=>inOctave(root+step,choices.chordOctave)).sort((a,b)=>a-b);
}
// The chord row that says a chord (a jazzvoicing chord: its root, third, fifth and seventh as pitch classes): a
// diminished fifth under a minor third the diminished row; a minor third the minor; a minor seventh over a major third
// the seventh; else the major.
export function chordRow({root,third=null,fifth=null,seventh=null}){
  const minor=third!==null&&modulo(third-root,12)===3,flatFive=fifth!==null&&modulo(fifth-root,12)===6;
  if(minor&&flatFive)return 'diminished';
  if(minor)return 'minor';
  if(seventh!==null&&modulo(seventh-root,12)===10&&!minor)return 'seventh';
  return 'major';
}

// ---- The bellows' air direction: unisonoric and bisonoric layouts ---------------------------------------------------
// A layout: `unisonoric` (every key the same in both directions) or a map of buttons, each {push, pull} (MIDI).
export const UNISONORIC=Object.freeze({kind:'unisonoric'});
// An authored bisonoric fixture: a one-row diatonic button accordion in G, its push the G chord's notes and its pull
// the scale's others (the report's §11.5 fixture: the instrument registry's 'accordion-bisonoric-g').
export const BISONORIC_G=Object.freeze({kind:'bisonoric',buttons:instrumentRange('accordion-bisonoric-g').buttons});
// The directions a pitch sounds in on a layout: both on a unisonoric one; on a bisonoric one, those of its buttons.
export function directionsOf(pitch,layout=UNISONORIC){
  if(layout.kind!=='bisonoric')return ['push','pull'];
  const out=new Set;for(const button of layout.buttons){if(button.push===pitch)out.add('push');if(button.pull===pitch)out.add('pull')}
  return [...out];
}
// The direction pitches sounding together can share on a layout, or null where none can (they want opposite ones).
export function sharedDirection(pitches,layout=UNISONORIC){
  const both=['push','pull'].filter(direction=>pitches.every(pitch=>directionsOf(pitch,layout).includes(direction)));
  return both.length?both:null;
}

// The bellows planned over a passage's groups ([{at (s), pitches, reeds (sounding), dynamic, join (a phrase's head),
// head (a group's)}], in time order), one stroke at a time: a reversal at each join where the stroke's air left is
// under what the phrase before it spent; at any head where the air left would run under the reserve before the next
// head; and where a group's pitches sound only in the other direction (a bisonoric layout's). -> {status: witness,
// reversals: [{at, why}], strokes: [{from, to, direction, spent}]}, or {status, reason}: pitches wanting opposite
// directions at once (violates), or a stretch between two heads longer than a whole stroke (budget).
export function planBellows(groups,{layout=UNISONORIC,choices=ACCORDION,start='pull'}={}){
  const {seconds,reeds,dynamics,reserve}=choices.bellows,reversals=[],strokes=[];
  let direction=start,air=1,from=groups[0]?.at??0,lastPhrase=0,phraseSpent=0;
  const rate=group=>(Math.max(1,group.reeds??group.pitches?.length??1)/reeds)*(dynamics[group.dynamic??'mf']??1)/seconds;
  const useOf=index=>rate(groups[index])*((groups[index+1]?.at??groups[index].at)-groups[index].at);
  const reverse=(at,why)=>{strokes.push({from,to:at,direction,spent:+(1-air).toFixed(3)});reversals.push({at,why});direction=direction==='push'?'pull':'push';air=1;from=at};
  for(const [index,group] of groups.entries()){
    let reversed=false;
    // At a phrase's join: reversed where what is left will not carry another phrase like the last.
    if(group.join&&index>0){lastPhrase=phraseSpent;phraseSpent=0;if(air-reserve<lastPhrase-1e-9){reverse(group.at,'join');reversed=true}}
    // At any head: reversed where the air would run under the reserve before the next head.
    if((group.head||group.join)&&!reversed){
      let needed=0;for(let k=index;k<groups.length;k++){if(k>index&&(groups[k].head||groups[k].join))break;needed+=useOf(k)}
      if(air-reserve<needed-1e-9){reverse(group.at,'air');reversed=true}
    }
    // The direction its pitches need (a bisonoric layout's): reversed to it, or refused where they want both.
    const shared=sharedDirection(group.pitches??[],layout);
    if(!shared)return {status:STATUS.violates,reason:`at ${group.at} s: ${group.pitches.join(', ')} want opposite bellows directions`};
    if(!shared.includes(direction))reverse(group.at,'direction');
    const use=useOf(index);air-=use;phraseSpent+=use;
    if(air<-1e-9)return {status:STATUS.budget,reason:`from ${group.at} s the notes to the next head spend more than a whole stroke`};
  }
  strokes.push({from,to:groups.at(-1)?.at??from,direction,spent:+(1-air).toFixed(3)});
  return {status:STATUS.witness,reversals,strokes};
}
