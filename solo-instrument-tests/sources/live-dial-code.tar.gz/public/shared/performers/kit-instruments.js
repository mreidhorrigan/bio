// The instruments a hand percussionist can play on its kit: those of its table the kit has recordings of every note
// for (synths/drum-kit.js kitNotes, as audio.js sampledKit gives them), so a player chooses from what its kit sounds and
// never strikes a note its kit is silent on. A voice that sounds every note (no sampled kit: null) has them all.
// `notesOf(instrument)` is an instrument's notes (a timeline's strong and weak strokes, a shaker's down and up).
export function instrumentsInKit(table,kit,notesOf){
  if(!Array.isArray(kit?.notes))return table;
  const notes=new Set(kit.notes);
  return Object.fromEntries(Object.entries(table).filter(([,instrument])=>notesOf(instrument).every(note=>notes.has(note))));
}
// Whether a kit has recordings of all these notes (a voice that sounds every note has).
export const kitHasNotes=(kit,notes)=>!Array.isArray(kit?.notes)||notes.every(note=>kit.notes.includes(note));
