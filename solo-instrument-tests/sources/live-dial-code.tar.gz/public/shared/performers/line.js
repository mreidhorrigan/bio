// A line for an instrument that plays one, the melody's principles carried to it (the bowed strings, the winds): a phrase
// planned whole, so that the instrument's own planner (its bow, its breath) can then realize it and revise what it can't
// play. Nothing here names a meter, a scale or an instrument.
//
// Its phrases are made of a motif, as a composer's are (the user, 28 September 2026, on 0f's Debussy kit: "it lacks
// distinct phrasing or motifs, and particularly distinct phrasing per-instrument. The lead just goes on for a long time
// with no sense of phrases"; and on maqam lines: "a tendency to degrade into just going basically up and down a scale
// ... Usual well-formed melody rules - e.g., avoiding repeating apexes, etc - also apply"):
//   - **A motif:** a rhythm over one bar and a shape of three to six notes, the instrument's own, kept from phrase to
//     phrase and varied. Its rhythm follows the meter's hierarchy: each of the bar's groups held as one note, split
//     long-short or short-long, or played on its felt beats, some divided, as densely as the phrase allows. Its shape is
//     steps and at most one leap, recovered by a step the other way, turning at least once, and ending near where it
//     began, so that its sequences join by step. It is of one of several seed grammars (the memorable motifs report,
//     §5.6): free steps, an arch, a shape circling its first note, repeated tones, a leap answered by steps, long-short
//     durations, a rest inside it. Its core (its opening two notes, the notes its grammar rests on, a rest of it, its
//     last) is what every variation keeps: never merged in a sparser phrase; in a denser one, its head's rhythm kept
//     where the motif is stated, another note of it divided only into a figure beginning on it.
//   - **Each line's motif its own:** chosen once, from a slate of candidates of different grammars, the one most unlike
//     the motifs the other lines have said (bots/lib/modules/line-motifs.js), its reasons kept.
//   - **A phrase in the sentence's shape** (Caplin 1998, Classical Form): a basic idea (the motif), its repetition, a
//     continuation (the motif's head, fragmented and sequenced up to the phrase's one apex), and a cadence (the head's
//     rhythm, falling by step to the phrase's floor, then held), then a rest before the next phrase, where the rubato's
//     arch broadens. A comma, a short silence, ends the idea and its repetition. Phrase by phrase the motif is stated,
//     sequenced higher, inverted, and returns as stated (its repetition a step lower), in turn.
//   - **The melody rules:** one apex a phrase, never the last phrase's apex again (and a climax phrase's span the
//     widest); a leap recovered by a step the other way (unless the line breathes before or after it, beginning again);
//     no more than a few steps one way outside an ornament; no note three times running; a phrase's range kept.
//   - Its pitches are indices into the voice's own pitches (its pool in every octave of its register, whatever the
//     tuning); each note then takes the nearest pitch of the harmony sounding when it plays (followHarmony).
//   - **A pickup where the form marks a join**, as the drummer fills into it (bots/lib/modules/form-marks.js, whose
//     decision it takes: up into more intensity, down into less, silence now and then): the phrase's last felt beat a
//     run rising or falling by step from its held tone, under one slur, landing on the next phrase's first note, which
//     that phrase's idea begins on (`lead`). The drummer's fill carried to a line.
//   - Quick notes are slurred in twos to fours, long notes separate, a soloist's long notes ornamented with fioriture
//     (fioritura.js), each run under one slur. Its dynamics swell to the apex and fall to the cadence, at the level of
//     its loudness (its attention share; shared/attention.js: a soloist's license, fast and loud together at its top).
//   - **Its rhythms on the rhythm engine,** where its player is switched to it (`choices.rhythm`, its player's shares:
//     personality.js; the owner, 4 November 2026: "Avoid hardcoding anything. Do not design rhythms directly"): its
//     motif's bar, a held note's figure and a pickup's run each a tree of the layers its span affords at its player's
//     quickest note, its notes Euclidean rhythms nested in it (line-rhythm.js), as many as its density asks -- at the most,
//     every playable note. Its motif's notes then as many as its density draws among its fewest and most, its grammars
//     its shape's alone.
import {planFioritura} from './fioritura.js';
import {Rational as R} from '../../transcript/rational.js';
import {scoreTime,readScoreTime,shiftScoreTime} from '../score-time.js';
import {authoredFraction as Q,rhythmCell,retimeCell,cellInterval} from './rhythm-cell.js';
import {feltBeats} from '../meter-tactus.js';
import {DYNAMIC_VELOCITY,velocityBeyond} from '../dynamics.js';
import {bandMeter,bandTempo} from '../opening-time.js';
import {countOf} from '../euclidean.js';
import {barOf,spanTree,placeNotes,leavesOf,noteSpans,rhythmShares,toward} from './line-rhythm.js';
// A felt beat of the piece's opening, in seconds: its bar (its numerator's beats at its tempo) over its groups.
const openingBeatSeconds=()=>{const meter=bandMeter();return meter.numerator*60/Math.max(1,bandTempo())/Math.max(1,(meter.groups??[meter.numerator]).length)};

// A figure divides a held note: two notes at the least, so a note on the rhythm engine is held where it holds two of its
// player's quickest.
const FIGURE_LEAST=2;
export const LINE=Object.freeze({
  // How finely a divided felt beat may be divided, from the least density to the most, and the dynamics a phrase spans:
  // the system's scored range, ppp to fff (dynamics.js; the owner, 10 October 2026).
  dynamics:Object.freeze(['ppp','pp','p','mp','mf','f','ff','fff']),
  // The quickest note a line's player takes (s): a bow's change twice (bow.js changeSeconds: section-voices.js
  // SECTION_VOICES.shortest), a wind's double tonguing near it (ours). How finely a span divides is as many notes as fit
  // in it at this (divisionOf): no list of divisions.
  shortest:.08,
  // Velocity by dynamic, for the voice: the scale's centres (dynamics.js), so that a dynamic's velocity is the mark the
  // score writes for it.
  velocity:DYNAMIC_VELOCITY,
  // The longest slur of quick notes, and a leap's chance in a motif.
  slurMost:4,leap:.18,
  // The share of a phrase's segments (its idea, its repetition, its answer, ...) slurred whole, long notes and all,
  // tongued where each begins: a legato player's (personality.js, its slurs). None here: long notes separate.
  slurSegments:0,
  // The share of a held note a soloist's run may take.
  ornamentShare:'2/3',
  // A motif's fewest and most notes, its widest drift (pool steps from its first note to its last), and the density it
  // is made at where the instrument names none (its character; each phrase's density then realizes it, sparser or denser).
  motifNotes:Object.freeze([3,6]),driftMost:3,motifDensity:.4,
  // A leap's least and greatest size (pool steps), and a run's most steps one way outside an ornament.
  leapSteps:3,leapMost:5,runMost:4,
  // A phrase's span from its floor to its apex (pool steps; a climax phrase's wider), and its widest range (semitones;
  // a climax phrase's a third more).
  span:Object.freeze([5,8]),climaxSpan:Object.freeze([8,11]),phraseRange:14,
  // The silence after the cadence: a share of the bar's last group, at least a catch breath (s), at most a share of the
  // held tone, written on the group's half beats (the share among them nearest its own: a player's own share drawn,
  // personality.js). The comma after the idea and its repetition: a share of their last note, where it is long enough (s).
  restShare:.5,restDivisions:2,restLeast:.4,restMostShare:.5,commaShare:.2,commaLeast:.3,
  // Where a phrase's cadence lands, a share of its span above its floor (the owner, 2 October 2026, of the endings
  // that always fall: "We must break the bots out of clichés while still allowing them to signify endings"): drawn each
  // phrase, the square of a uniform draw over this range, so most cadences still fall near the floor and some land high,
  // approached from below; the piece's last phrase closes on its tonic as before.
  landing:Object.freeze([0,.75]),
  // And how often a piece's last phrase is its motif's return, a share drawn from the motif within this range (ours);
  // and that return's cadence, its approach the motif's head as a cadence states it -- augmented (twice as slow) as
  // often as `augment`, and fragmented, cut to its first notes, by as much as `fragment` of it (a uniform draw: kept
  // whole to cut to a quarter) -- each drawn from the motif too (ours; the owner's "motivic signifiers of ending").
  recall:Object.freeze([.3,1]),recallCadence:Object.freeze({augment:.5,fragment:.75}),
  // How many settings of the phrase's segments the search keeps at each.
  beam:12,
  // The motif's variations, phrase by phrase, in turn.
  variations:Object.freeze(['statement','sequence','inversion','return']),
  // The motif's seed grammars (the memorable motifs report, §5.6: "deliberately varied seed classes"): free steps; an
  // arch to one peak; a shape circling its first note (anchor-centred); a rhythm on a repeated tone; a leap answered by
  // steps back; unequal (long-short) durations; a rest inside it as part of its signature. How many candidates a line's
  // slate holds.
  grammars:Object.freeze(['free','arch','anchor','repeated','leap','asymmetric','rest']),slate:4,
  // A phrase's swell (phraseSwell): its level from this share of its loudness at its ends to this at its apex, and where
  // in the phrase its apex may be.
  swell:Object.freeze([.65,1.25]),peak:Object.freeze([.2,.9]),
  // Its rhythms on the rhythm engine (line-rhythm.js): its player's shares (personality.js playingOf: tuplets,
  // syncopation, length, meter, repeats, within), or none, its own rhythms as above.
  rhythm:null,
});
const clamp=(x,low,high)=>Math.max(low,Math.min(high,x));
// What a melody rule broken costs a line's search: far more than any of its preferences (a setting's distance from
// where the phrase's arch wants it, a pool step each), so that a rule gives way only where no setting keeps it.
const RULE=60;
const fit=(pitch,[low,high])=>{let value=Number(pitch);while(value<low)value+=12;while(value>high)value-=12;return value};
const smooth=x=>x*x*(3-2*x);
// A phrase's dynamics, one curve through it: its swell at `x` (0 to 1, its place in the phrase), rising from its start to
// its apex at `peak` (its share of the phrase, within LINE.peak) and falling from there to its end, 0 at its ends and 1 at
// the apex; its level there, about its `loudness`, within LINE.swell's shares of it. A line's notes take it where they
// begin (planLine), and a held note goes on along it as it sounds (the owner, 4 October 2026: "phrasing must continue
// through each note even when it's held"; section-seat.js).
export function phraseSwell(x,peak){
  const at=clamp(Number(x)||0,0,1),top=clamp(Number.isFinite(Number(peak))?Number(peak):.5,...LINE.peak);
  return at<=top?smooth(at/top):1-smooth(clamp((at-top)/(1-top),0,1));
}
export const swellLevel=(loudness,x,peak)=>clamp(loudness*(LINE.swell[0]+(LINE.swell[1]-LINE.swell[0])*phraseSwell(x,peak)),0,1);
// A level's velocity (0 to 1), continuous: each dynamic's velocity (LINE.velocity) at the middle of its share of the
// levels, those between read between them -- a held note's swell grows rather than steps; a level under 0 or over 1 in
// the uncomfortable range beyond (dynamics.js velocityBeyond).
export function levelVelocity(level){
  if(Number(level)<0||Number(level)>1)return velocityBeyond(level);
  const n=LINE.dynamics.length,at=clamp((Number(level)||0)*n-.5,0,n-1),low=Math.floor(at),high=Math.min(n-1,low+1);
  return LINE.velocity[LINE.dynamics[low]]+(LINE.velocity[LINE.dynamics[high]]-LINE.velocity[LINE.dynamics[low]])*(at-low);
}
// `count` of the indices below `n`, drawn at random, each set as likely as another.
function drawnSet(n,count,random){
  const order=[...Array(n).keys()];
  for(let k=n-1;k>0;k--){const j=Math.floor(random()*(k+1));[order[k],order[j]]=[order[j],order[k]]}
  return new Set(order.slice(0,clamp(Math.round(count),0,n)));
}
// Every pool pitch in every octave of a register, low to high.
export function linePitches(pool,[low,high]){
  const classes=[...new Set((pool??[]).map(Number).filter(Number.isFinite).map(pitch=>fit(pitch,[low,low+12-1e-9])))].sort((a,b)=>a-b),out=[];
  for(let octave=0;low+octave*12<=high;octave++)for(const pitch of classes){const value=pitch+octave*12;if(value>=low&&value<=high)out.push(value)}
  return out.sort((a,b)=>a-b);
}

// A planned note's pitch in the harmony sounding when it plays: the pool's nearest pitch in the register (the lower of
// two as near), so a line planned whole at its downbeat follows the chords that change under it. Its rhythm, contour,
// bowing and breaths are the plan's; only the pitch moves, and by the least it can.
export function followHarmony(pitch,pool,register){
  const pitches=linePitches(pool,register);
  if(!pitches.length)return pitch;
  return pitches.reduce((best,value)=>Math.abs(value-pitch)<Math.abs(best-pitch)-1e-9?value:best,pitches[0]);
}

// A line's phrase grid (the user: "distinct phrasing per-instrument"): phrases phraseBars long, beginning `offset` bars
// after the form's. Whether a bar begins one, and where a phrase beginning at `bar` ends: at the grid's next bar, and
// never after only one bar where the grid's phrases are longer than two (a phrase of one bar only where they are).
export function onPhraseGrid(bar,{phraseBars,offset=0}){return ((bar-offset)%phraseBars+phraseBars)%phraseBars===0}
export function phraseEnd(bar,{phraseBars,offset=0}){
  const next=bar+(((offset-bar)%phraseBars+phraseBars)%phraseBars||phraseBars);
  return next-bar<2&&phraseBars>2?next+phraseBars:next;
}
// A line's phrase beginning at `bar` where the ensemble's ending is known (`endsAt`: the bar it stops at, or null): to
// its grid's next bar, or to the ending where that would pass it or leave less than two bars before it, the piece's last
// phrase (`final`). A bar it rests in (`breakAt`: an answering silence, shared/presentation.js) ends the phrase there,
// and it is not the last. -> {bars, final}, or null at or after the ending (no phrase).
export function phraseBeforeEnding(bar,{phraseBars,offset=0,endsAt=null,breakAt=null}){
  const end=phraseEnd(bar,{phraseBars,offset});
  if(Number.isInteger(endsAt)&&bar>=endsAt)return null;
  const span=!Number.isInteger(endsAt)?{bars:end-bar,final:false}:end>=endsAt||endsAt-end<2?{bars:endsAt-bar,final:true}:{bars:end-bar,final:false};
  return Number.isInteger(breakAt)&&breakAt>bar&&breakAt<bar+span.bars?{bars:breakAt-bar,final:false}:span;
}
// The offset a line's phrases take from its place in the band's attention (bots/lib/modules/attention.js): none for the
// band's focus (its cadences where the form's phrases end and the rubato broadens), a soloist, or a line that has heard
// nothing; half a phrase for the next, then a quarter and three quarters, so that no two lines breathe together and
// each answers another: it moves through the other's cadence and rest, and rests in the other's phrase.
export const PHRASE_OFFSETS=Object.freeze([0,1/2,1/4,3/4]);
export function phraseOffset(attention,phraseBars){
  if(!attention||attention.soloing)return 0;
  const rank=Number.isInteger(attention.rank)&&attention.rank>=0?attention.rank:attention.focus===false?1:0,share=PHRASE_OFFSETS[rank%PHRASE_OFFSETS.length];
  return share?Math.max(1,Math.round(share*phraseBars))%phraseBars:0;
}
// A meter's identity for a phrase planned in it: a bar of another meter re-plans the phrase from there.
export const meterKey=meter=>`${meter?.label}:${meter?.pulsesPerBar}`;

// The bar's groups, in felt beats: [{first, count}]. The meter's groups where each holds a felt beat or more; each felt
// beat its own group otherwise (a meter of one group, or felt beats coarser than its groups).
export function beatGroups(meter,beats){
  const sub=Number(meter.subdivision)||4,sizes=(meter.groups??[]).map(Number).filter(size=>size>0);
  if(sizes.length<2)return beats.map((_,index)=>({first:index,count:1}));
  const starts=[];let at=0;for(const size of sizes){starts.push(at);at+=size*sub}
  const groupOf=pulse=>{let index=0;starts.forEach((start,k)=>{if(start<=pulse+1e-9)index=k});return index};
  const groups=[];
  beats.forEach((beat,index)=>{const group=groupOf(beat.start);if(groups.at(-1)?.group===group)groups.at(-1).count++;else groups.push({group,first:index,count:1})});
  return groups.map(({first,count})=>({first,count}));
}

// The longest run in a list of indices, a repeated note neither adding to it nor ending it.
function longestRun(indices){
  let run=0,direction=0,most=0;
  for(let k=1;k<indices.length;k++){const d=Math.sign(indices[k]-indices[k-1]);if(!d)continue;run=d===direction?run+1:1;direction=d;most=Math.max(most,run)}
  return most;
}
// A run's length at the end of a list of indices: its last moves one way, a repeated note neither adding nor ending it.
function runAtEnd(indices){
  let run=0,direction=0;
  for(let k=indices.length-1;k>0;k--){const d=Math.sign(indices[k]-indices[k-1]);if(!d)continue;if(!direction)direction=d;if(d!==direction)break;run++}
  return run;
}
// Steps made to keep the shape's rules: a leap followed by a step the other way, and never the last move.
function recovered(steps,choices){
  const out=[...steps];
  for(let k=1;k<out.length;k++){
    if(Math.abs(out[k-1])>=choices.leapSteps&&k>1&&!(Math.sign(out[k])===-Math.sign(out[k-1])&&Math.abs(out[k])<=2))out[k]=-Math.sign(out[k-1]);
    if(k===out.length-1&&Math.abs(out[k])>=choices.leapSteps)out[k]=Math.sign(out[k]);
  }
  return out;
}
// A motif's shape: steps, and at most one leap (recovered by a step the other way, never its last move), turning at
// least once when it has four notes or more, never trilling, and drifting no more than driftMost from its first note.
// Each step is drawn from the steps that keep every rule, the rest of the shape still able to keep them: a step of one
// (the likelier) or two, up a little likelier than down, or, once and not last, a leap; after a leap, its recovery.
function shapeCells(cells,{random,choices}){
  const n=cells.length,steps=[0];let leapt=false;
  for(let k=1;k<n;k++){
    const previous=steps[k-1],before=steps[k-2]??0,left=n-1-k,drift=steps.reduce((sum,step)=>sum+step,0);
    const last=k===n-1,turned=steps.slice(2).some((step,i)=>Math.sign(step)!==Math.sign(steps[i+1]));
    const options=Math.abs(previous)>=choices.leapSteps&&k>1?[[-Math.sign(previous),1]]:[
      [1,.55*.75],[-1,.45*.75],[2,.55*.25],[-2,.45*.25],
      ...(!leapt&&!last?[choices.leapSteps,choices.leapSteps+1].flatMap(size=>[[size,choices.leap/4],[-size,choices.leap/4]]):[])];
    const keeps=([step])=>{
      // No trill; the drift still able to come back within driftMost (the steps left moving it two at most each, a
      // leap's recovery one); a turn made by the last step where none has been.
      if(k>=3&&step===-previous&&previous===-before)return false;
      const reach=Math.abs(step)>=choices.leapSteps?1+2*Math.max(0,left-1):2*left;
      if(Math.abs(drift+step)-reach>choices.driftMost)return false;
      if(last&&n>=4&&!turned&&k>=2&&Math.sign(step)===Math.sign(previous))return false;
      return true;
    };
    const feasible=options.filter(keeps),pool=feasible.length?feasible:[[-Math.sign(drift)||1,1]];
    const total=pool.reduce((sum,[,weight])=>sum+weight,0);let draw=random()*total,step=pool.at(-1)[0];
    for(const [option,weight] of pool){if((draw-=weight)<=0){step=option;break}}
    if(Math.abs(step)>=choices.leapSteps)leapt=true;
    steps.push(step);
  }
  return steps;
}
// A shape's sounding cells: its rests left out, each note's step taken from the note sounding before it (a rest's
// place moving nothing), so the rules are kept among the notes heard.
function soundingCells(cells){
  let offset=0,last=null;const out=[];
  cells.forEach((cell,k)=>{offset+=k?cell.step:0;if(cell.rest)return;out.push({...cell,step:last==null?0:offset-last});last=offset});
  return out;
}
// Whether steps (the first 0) keep a shape's rules among themselves: never a trill, never three notes alike.
const trillFree=steps=>steps.every((step,j)=>!(j>=3&&step&&step===-steps[j-1]&&steps[j-1]===-steps[j-2])&&!(j>=2&&!step&&!steps[j-1]));
// A step of one or two, drawn (one the likelier), in a direction.
const stepOf=(random,direction)=>direction*(random()<.7?1:2);
// A motif's steps by its grammar, each shape made to keep the rules from the start: drift within driftMost, at most one
// leap and it recovered and not last, never three notes alike, never a trill. -> {steps, signature: the cells its
// grammar's identity rests on}.
function grammarSteps(n,grammar,{random,choices}){
  const up=random()<.55?1:-1;
  if(grammar==='arch'&&n>=3){
    // Up to one peak in its middle, then down; its sizes trimmed until it ends within driftMost of where it began.
    const peak=1+Math.floor(random()*Math.max(1,n-2)),steps=[0];
    for(let k=1;k<n;k++)steps.push(k<=peak?stepOf(random,up):stepOf(random,-up));
    for(let k=n-1;k>0&&Math.abs(steps.reduce((a,b)=>a+b,0))>choices.driftMost;k--)if(Math.abs(steps[k])===2)steps[k]=Math.sign(steps[k]);
    return {steps,signature:[peak-1,peak]};
  }
  if(grammar==='anchor'&&n>=3){
    // Its first note an anchor it keeps coming back to: out by a third, back, then out by a step the other way and back,
    // and so on, so its farthest note each way comes once.
    const steps=[0];let out=up*2;
    for(let k=1;k<n;k++){if(k%2){steps.push(out)}else{steps.push(-out);out=-Math.sign(out)}}
    return {steps,signature:[0,...Array.from({length:Math.floor((n-1)/2)},(_,i)=>2*(i+1)).filter(k=>k<n)]};
  }
  if(grammar==='repeated'&&n>=3){
    // A rhythm on a repeated tone: its head struck again, then away by steps or thirds, turning once -- one repeated note,
    // not every one (the owner, 5 October 2026: motifs of nothing but repeated notes were to stop; each of its notes
    // had been struck twice, a a b b c c, an Op. 3.30 bass line's every bar).
    // (Its sizes trimmed, as an arch's, until it ends within driftMost of where it began.)
    const steps=[0,0],turn=1+Math.ceil((n-2)/2);let direction=up;
    for(let k=2;k<n;k++){if(k===turn&&k<n-1)direction=-direction;steps.push(stepOf(random,direction))}
    for(let k=n-1;k>1&&Math.abs(steps.reduce((a,b)=>a+b,0))>choices.driftMost;k--)if(Math.abs(steps[k])===2)steps[k]=Math.sign(steps[k]);
    return {steps,signature:[0,1,Math.min(2,n-1)]};
  }
  if(grammar==='leap'&&n>=3){
    // A leap at once, answered by steps back the other way (a gap filled).
    const size=choices.leapSteps+(random()<.35?1:0),steps=[0,up*size];
    for(let k=2;k<n;k++)steps.push(-up);
    return {steps,signature:[0,1,2]};
  }
  return {steps:shapeCells(Array(n).fill(0),{random,choices}),signature:[]};
}
// A motif over a bar's groups: {cells: [{at (felt beats from the bar's start), beats, step (pool steps from the note
// before; the first 0), core? (a cell of its protected signature), rest? (a silence of its signature)}], beats (the
// bar's felt beats), density (the density it was made at), grammar, groups}. Its core (the memorable motifs report,
// §4.2: "a protected signature with explicitly variable regions") is its opening two notes, the cells its grammar's
// identity rests on, and its last: what every variation keeps.
// How many notes a divided span of `seconds` takes at `density` (0 to 1, `jitter` added): from two to as many as its
// player can play in it, its quickest note `choices.shortest`; the denser, the more. No fixed set of tuplets: 4 against
// 3, 5, 7, 11 or 17 where the span holds them, so a slow beat at a high density divides as Ferneyhough's do (the owner,
// 2 October 2026: "tuplets should be able to go arbitrarily high (e.g., 17/16 or higher) given the right circumstances";
// "the real limits are possible playing ... speed of the shortest notes"; "it is possible to write a tuplet that in other
// circumstances would not be hearable, as long as its speed is playable"; "make sure EVERY tuplet ratio is allowed - 2,
// 3, 4, 5, 6 ... 107 ... whatever ... NO HARDCODING OF TUPLETS"). Where its seconds are not known, a felt beat of the
// piece's opening, its meter at its tempo (opening-time.js: the seed's).
export function divisionOf(density,{seconds=null,choices=LINE,jitter=0}={}){
  const d=clamp(density+jitter,0,.999),span=Number(seconds)>0?Number(seconds):openingBeatSeconds();
  const most=Math.max(2,Math.floor(span/(choices.shortest??LINE.shortest)+1e-9));
  return clamp(Math.round(2+d*(most-2)),2,most);
}
export function makeMotif({groups,density=.4,grammar=null,random,choices=LINE,beatSeconds=null,bar=null}){
  const kind=grammar??choices.grammars[Math.floor(random()*choices.grammars.length)];
  if(!choices.grammars.includes(kind))throw new RangeError(`A motif's grammar is one of ${choices.grammars.join(', ')}`);
  const d=clamp(density,0,1),cells=[],beats=groups.reduce((sum,group)=>sum+group.count,0);
  const division=()=>divisionOf(d,{seconds:beatSeconds,choices,jitter:(random()-.5)*.3});
  // On the rhythm engine: its bar's tree (`bar`, barOf's; none given, its felt beats each `beatSeconds`), as many notes
  // in it as its density draws among its fewest and most, nested Euclidean rhythms (line-rhythm.js).
  if(choices.rhythm){
    const shares=rhythmShares(choices.rhythm),seconds=Number(beatSeconds)>0?Number(beatSeconds):openingBeatSeconds();
    const tree=spanTree({at:0,end:beats},{bar:bar??barOf({groups,beatSeconds:new Array(beats).fill(seconds)}),quickest:choices.shortest??LINE.shortest,shares,random});
    const [fewest,most]=choices.motifNotes,count=Math.min(leavesOf(tree),fewest+Math.round(toward(random(),d)*(most-fewest)));
    cells.push(...noteSpans(placeNotes(tree,count,random),beats).map(({at,duration})=>rhythmCell(at,duration)));
  }else groups.forEach((group,g)=>{
    const last=g===groups.length-1,draw=random();
    // Unequal durations (the asymmetric grammar): each group long-short, its felt beats but the last held as one, or,
    // a group of one or two, dotted.
    if(kind==='asymmetric'&&!last){
      const long=group.count>=3?group.count-1:group.count*.75;
      cells.push(rhythmCell(group.first,long),rhythmCell(Q(group.first).add(Q(long)),Q(group.count).sub(Q(long))));return;
    }
    // Held as one note (the likelier at the bar's end), split long-short or short-long, or on its felt beats.
    const held=(1-d)*(last?.6:.3),split=group.count>=2?(1-d)*.35:0;
    if(draw<held){cells.push(rhythmCell(group.first,group.count));return}
    if(draw<held+split){
      const long=group.count-1,longFirst=random()<.6;
      cells.push(...(longFirst?[rhythmCell(group.first,long),rhythmCell(group.first+long,1)]:[rhythmCell(group.first,1),rhythmCell(group.first+1,long)]));return;
    }
    for(let b=0;b<group.count;b++){
      if(random()<d*(last?.6:1)){const k=division();for(let i=0;i<k;i++)cells.push(rhythmCell(Q(group.first+b).add(new R(i,k)),new R(1,k)))}
      else cells.push(rhythmCell(group.first+b,1));
    }
  });
  // Three to six notes: the longest note split where too few (at a felt beat, long-short, where it holds more than one;
  // a felt beat halved); where too many, the two shortest neighbours merged, within a group where they can be. (On the
  // engine, as many as were placed.)
  const groupAt=at=>groups.findIndex(group=>at>=group.first-1e-9&&at<group.first+group.count-1e-9);
  while(!choices.rhythm&&cells.length<choices.motifNotes[0]){
    let i=0;for(let k=1;k<cells.length;k++)if(cells[k].beats>cells[i].beats)i=k;
    const {at,duration:held}=cellInterval(cells[i]),first=held.ge(2)?Q(held.div(2).ceil()):held.gt(1)?R.ONE:held.div(2);
    cells.splice(i,1,rhythmCell(at,first),rhythmCell(at.add(first),held.sub(first)));
  }
  while(!choices.rhythm&&cells.length>choices.motifNotes[1]){
    const pairs=[...Array(cells.length-1).keys()],within=pairs.filter(k=>groupAt(cells[k].at)===groupAt(cells[k+1].at));
    const best=(within.length?within:pairs).reduce((a,b)=>cells[b].beats+cells[b+1].beats<cells[a].beats+cells[a+1].beats?b:a);
    cells.splice(best,2,rhythmCell(cellInterval(cells[best]).at,cellInterval(cells[best]).duration.add(cellInterval(cells[best+1]).duration)));
  }
  // Its shape by its grammar; a rest of its signature (the rest grammar) where a middle note would be; its core.
  const {steps,signature}=grammarSteps(cells.length,kind,{random,choices});
  // A rest of its signature where a middle note would be: never the note a leap's recovery falls on, and only where the
  // notes left keep the shape's rules (no trill, no three alike, still turning where it turned).
  const turns=list=>list.filter(Boolean).some((step,j,moves)=>j&&Math.sign(step)!==Math.sign(moves[j-1]));
  const folded=k=>[...steps.slice(0,k),steps[k]+steps[k+1],...steps.slice(k+2)];
  const places=kind==='rest'?[...Array(cells.length).keys()].filter(k=>k>=1&&k<=cells.length-2&&Math.abs(steps[k-1]??0)<choices.leapSteps&&Math.abs(steps[k])<choices.leapSteps
    &&Math.abs(steps[k]+steps[k+1])<choices.leapSteps&&trillFree(folded(k))&&(!turns(steps)||turns(folded(k)))):[];
  const rest=places.length&&cells.length>=4?places[Math.floor(random()*places.length)]:-1;
  const core=new Set([0,1,...signature,cells.length-1,...(rest>0?[rest-1,rest]:[])]);
  return Object.freeze({cells:Object.freeze(cells.map((cell,k)=>Object.freeze({...cell,step:k===rest?0:k===rest+1&&rest>0?steps[k]+steps[rest]:steps[k],...(core.has(k)?{core:true}:{}),...(k===rest?{rest:true}:{})}))),
    beats,density:d,grammar:kind,groups:Object.freeze(groups.map(group=>Object.freeze({...group})))});
}
// How far apart two motifs are to a listener, 0 (alike) to 1: their rhythms (where their notes begin, as shares of the
// bar: the notes heard, a rest of a signature left out), their contours as heard (each move up, down or level, a step
// or a leap), and their grammars. Either may be a motif as another line said it (/broadcast/lineMotif: its grammar, its
// bar's felt beats, its cells).
export function motifDistance(a,b,choices=LINE){
  const onsets=motif=>new Set(motif.cells.filter(cell=>!cell.rest).map(cell=>Math.round(cell.at/motif.beats*48)));
  const A=onsets(a),B=onsets(b),shared=[...A].filter(onset=>B.has(onset)).length,rhythm=1-shared/Math.max(1,A.size+B.size-shared);
  const moves=motif=>soundingCells(motif.cells).slice(1).map(cell=>({sign:Math.sign(cell.step),leap:Math.abs(cell.step)>=choices.leapSteps}));
  const x=moves(a),y=moves(b),apart=(p,q)=>p.sign===q.sign?(p.leap===q.leap?0:.5):!p.sign||!q.sign?.5:1;
  // Their moves' edit distance (a move changed, its difference; one added or left out, 1), as a share of the longer.
  let row=Array.from({length:y.length+1},(_,j)=>j);
  for(let i=1;i<=x.length;i++){
    const next=[i];
    for(let j=1;j<=y.length;j++)next.push(Math.min(row[j]+1,next[j-1]+1,row[j-1]+apart(x[i-1],y[j-1])));
    row=next;
  }
  const contour=row[y.length]/Math.max(1,x.length,y.length);
  return .4*rhythm+.4*contour+.2*(a.grammar===b.grammar?0:1);
}
// Whether a motif another line said is one to compare with: a grammar, its bar's felt beats, and cells of numbers.
const heardMotif=motif=>motif&&typeof motif.grammar==='string'&&Number(motif.beats)>0&&Array.isArray(motif.cells)&&motif.cells.length>=2
  &&motif.cells.every(cell=>Number.isFinite(cell?.at)&&Number(cell?.beats)>0&&Number.isFinite(cell?.step));
// A line's new motif, chosen from a slate (the memorable motifs report, §9 and ticket 3: "a small diverse slate for
// new-material exploration"): `slate` candidates of different grammars, and of them the most distinct from the motifs
// the other lines have said (`heard`: the one whose nearest is farthest), so that each line's is its own. Nothing heard,
// the first grammar drawn. -> {motif, slate: [{grammar, nearest, to}], reason}. A line keeps its motif once chosen: its
// returns are never replaced by a newer candidate.
// Its grammars in an order drawn: uniformly, or where its player prefers some (choices.grammarWeights, a weight for
// each, positive: personality.js), each sent to the back as seldom as it is preferred -- the same draws as the uniform
// order's, and the same order where every weight is the same.
const backOf=(order,k,weights,draw)=>{
  const shares=order.slice(0,k+1).map(g=>1/(Number(weights[g])||1)),total=shares.reduce((a,b)=>a+b,0);
  let left=draw*total;for(let j=0;j<=k;j++){left-=shares[j];if(left<0)return j}
  return k;
};
export function chooseMotif({groups,density,heard=[],random,choices=LINE,beatSeconds=null,bar=null}){
  const order=[...choices.grammars],weights=choices.grammarWeights??null;
  for(let k=order.length-1;k>0;k--){const j=weights?backOf(order,k,weights,random()):Math.floor(random()*(k+1));[order[k],order[j]]=[order[j],order[k]]}
  const others=(heard??[]).filter(heardMotif);
  if(!others.length){
    const motif=makeMotif({groups,density,grammar:order[0],random,choices,beatSeconds,bar});
    return {motif,slate:[{grammar:motif.grammar,nearest:null,to:null}],reason:'nothing heard from the other lines: the first grammar drawn'};
  }
  const scored=order.slice(0,clamp(Math.round(choices.slate),1,order.length)).map(grammar=>{
    const motif=makeMotif({groups,density,grammar,random,choices,beatSeconds,bar});
    const nearest=others.map(other=>({to:other.id??null,distance:motifDistance(motif,other,choices)})).reduce((a,b)=>b.distance<a.distance?b:a);
    return {motif,nearest};
  });
  const best=scored.reduce((a,b)=>b.nearest.distance>a.nearest.distance+1e-9?b:a);
  return {motif:best.motif,slate:scored.map(({motif,nearest})=>({grammar:motif.grammar,nearest:+nearest.distance.toFixed(3),to:nearest.to})),
    reason:`the most distinct of ${scored.length} from the ${others.length} line${others.length>1?'s':''} heard: ${best.nearest.distance.toFixed(2)} from the nearest${best.nearest.to?` (${best.nearest.to})`:''}`};
}
// The instrument's motif for this bar: -> {motif, choice?}. Kept as it is where the bar's groups are the motif's; none
// yet, chosen from a slate (chooseMotif: `choice` its slate and reason); in a bar of another meter, its rhythm made anew
// over the new groups in its grammar and its shape (its steps as heard) kept as far as it goes.
function fitMotif(motif,{groups,density,heard=[],random,choices,beatSeconds=null,bar=null}){
  const same=motif?.groups?.length===groups.length&&motif.groups.every((group,i)=>group.first===groups[i].first&&group.count===groups[i].count);
  if(same)return {motif:motif.cells.every(cell=>cell.scoreTime?.axis==='felt-beats')?motif:{...motif,cells:motif.cells.map(cell=>retimeCell(cell))}};
  if(!motif?.cells?.length){const {motif:chosen,...choice}=chooseMotif({groups,density,heard,random,choices,beatSeconds,bar});return {motif:chosen,choice}}
  const grammar=choices.grammars.includes(motif.grammar)?motif.grammar:null;
  const fresh=makeMotif({groups,density:Number.isFinite(motif.density)?motif.density:density,grammar,random,choices,beatSeconds,bar});
  // The old motif's notes heard, step by step, onto the new rhythm's (its own steps past where the old ones end); its
  // core where the old motif's was, among the notes heard.
  const old=soundingCells(motif.cells),sounding=fresh.cells.flatMap((cell,k)=>cell.rest?[]:[k]);
  const steps=recovered(sounding.map((k,j)=>j?(old[j]?.step??fresh.cells[k].step):0),choices);
  const core=new Set(sounding.flatMap((k,j)=>j<=1||j===sounding.length-1||old[j]?.core?[k]:[]));
  let j=0;
  return {motif:Object.freeze({...fresh,cells:Object.freeze(fresh.cells.map((cell,k)=>{
    const {core:_,...plain}=cell,step=cell.rest?0:steps[j++];
    return Object.freeze({...plain,step,...(core.has(k)||cell.rest||fresh.cells[k+1]?.rest?{core:true}:{})});
  }))})};
}
// A motif played more simply, for a phrase sparser than the motif (0 to 1, how much): the notes of its divided felt
// beats held as their first (as many of them as twice the amount says), and past half the amount its groups' notes held
// as their first (as many as the rest says), which drawn at random; its core's notes never merged into another (its
// signature kept), a note to be held into its beat's or its group's held instead into the core's note before it there
// (that one held longer, its place and pitch kept). Each note held keeps its place in the motif's shape, so the notes
// left are the motif's own, on its strong beats.
export function simplifyMotif(motif,amount,random){
  if(!(amount>0))return motif;
  const groupAt=at=>motif.groups.findIndex(group=>at>=group.first-1e-9&&at<group.first+group.count-1e-9);
  const divided=[...new Set(motif.cells.filter(cell=>cell.beats<1-1e-9).map(cell=>Math.floor(cell.at+1e-9)))];
  const heldBeats=drawnSet(divided.length,divided.length*Math.min(1,2*amount),random),beats=new Map(divided.map((beat,k)=>[beat,heldBeats.has(k)]));
  const heldGroups=drawnSet(motif.groups.length,motif.groups.length*Math.max(0,(amount-.5)*2),random);
  let offset=0;
  const keyed=motif.cells.map((cell,k)=>{
    offset+=k?cell.step:0;
    const g=groupAt(cell.at),beat=Math.floor(cell.at+1e-9);
    return {...cell,offset,key:cell.core||cell.rest?`c${k}`:heldGroups.has(g)?`g${g}`:cell.beats<1-1e-9&&beats.get(beat)?`b${beat}`:`c${k}`};
  });
  keyed.forEach((cell,k)=>{
    const before=keyed[k-1];
    if(cell.key===`c${k}`||!before||before.rest||!before.key.startsWith('c'))return;
    const same=cell.key.startsWith('g')?groupAt(before.at)===groupAt(cell.at):Math.floor(before.at+1e-9)===Math.floor(cell.at+1e-9);
    if(same)cell.key=before.key;
  });
  // The motif with notes held together by `keys` (a note held into the one before it where their keys match), a held
  // note outside the core at the place `forced` gives it (by its first cell), where it gives one.
  const build=(keys,forced=new Map)=>{
    const cells=[];
    keyed.forEach((cell,k)=>{const last=cells.at(-1);if(last&&last.key===keys[k]){Object.assign(last,retimeCell(last,{duration:cellInterval(last).duration.add(cellInterval(cell).duration)}));if(!last.core){last.offsets.push(cell.offset);last.sources.push(cell.source??null)}}else cells.push({...cell,first:k,key:keys[k],offsets:[cell.offset],sources:[cell.source??null]})});
    // Of the places a held note could sound, the one making the smoothest line with its neighbours (the first, the
    // strong beat's, where as smooth), never repeating a neighbour where another will do; the core's notes where they
    // are.
    const heard=cells.filter(cell=>!cell.rest);
    heard.forEach((cell,k)=>{
      if(!k||cell.core)return;
      if(forced.has(cell.first)){cell.offset=forced.get(cell.first);return}
      const before=heard[k-1].offset,after=heard[k+1]?.offsets[0],roughness=offset=>Math.max(Math.abs(offset-before),after==null?0:Math.abs(after-offset))+(offset===before?2:0)+(offset===after?2:0);
      cell.offset=cell.offsets.reduce((best,offset)=>roughness(offset)<roughness(best)-1e-9?offset:best,cell.offset);
    });
    // A leap recovered by the note after it, a step back, where that note is outside the core (moved there, the notes
    // after it where they were): the core's places and intervals never shift.
    for(let k=1;k<heard.length-1;k++){
      const leap=heard[k].offset-heard[k-1].offset,step=heard[k+1].offset-heard[k].offset;
      if(Math.abs(leap)>=LINE.leapSteps&&!(Math.sign(step)===-Math.sign(leap)&&Math.abs(step)<=2)&&!heard[k+1].core)heard[k+1].offset=heard[k].offset-Math.sign(leap);
    }
    const heardSteps=heard.map((cell,k)=>k?cell.offset-heard[k-1].offset:0);
    // (A held note sounding a stored motif's note -- one of those it holds, at its place -- says that one's `source`.)
    let h=0;
    return cells.map(cell=>{const source=cell.sources[cell.offsets.indexOf(cell.offset)]??null;
      return {...rhythmCell(cellInterval(cell).at,cellInterval(cell).duration),step:cell.rest?0:heardSteps[h++],...(cell.core?{core:true}:{}),...(cell.rest?{rest:true}:{}),...(source?{source}:{})}});
  };
  // Whether a shape keeps the rules among its notes heard: a leap recovered by a step back and never the last move, no
  // trill, never three notes alike.
  const keeps=cells=>{
    const steps=soundingCells(cells).map(cell=>cell.step);
    return trillFree(steps)&&steps.every((step,k)=>!k||Math.abs(step)<LINE.leapSteps||k<steps.length-1&&Math.sign(steps[k+1])===-Math.sign(step)&&Math.abs(steps[k+1])<=2);
  };
  // Notes held together one by one, as their keys ask, each only where the shape still keeps the rules (the held note
  // at the smoothest of its places that does, outside the core): the motif as simple as the rules allow, its core
  // untouched.
  let keys=keyed.map((_,k)=>`c${k}`),forced=new Map;
  for(let k=1;k<keyed.length;k++){
    if(keyed[k].key!==keyed[k-1].key)continue;
    const trial=[...keys];trial[k]=trial[k-1];
    let first=k;while(first>0&&trial[first-1]===trial[k])first--;
    const places=keyed[first].core||keyed[first].rest?[null]:[null,...new Set(keyed.slice(first,k+1).map(cell=>cell.offset))];
    for(const place of places){
      const tried=place===null?forced:new Map([...forced,[first,place]]);
      if(keeps(build(trial,tried))){keys=trial;forced=tried;break}
    }
  }
  return Object.freeze({...motif,cells:Object.freeze(build(keys,forced).map(cell=>Object.freeze(cell)))});
}
// A motif varied: 'inversion' its steps the other way; otherwise as it is.
export function varyMotif(motif,variation){
  if(variation==='inversion')return Object.freeze({...motif,cells:Object.freeze(motif.cells.map(cell=>Object.freeze({...cell,step:-cell.step})))});
  return motif;
}
// A motif's head: its cells in its first group, or in as many groups as it takes to hold two notes and not end on its
// leap (the step that recovers it is part of the head).
function motifHead(motif,choices=LINE){
  let beats=0,cells=[];
  for(const group of motif.groups){
    beats+=group.count;cells=motif.cells.filter(cell=>cell.at<beats-1e-9);
    if(cells.length>=2&&!(Math.abs(cells.at(-1).step)>=choices.leapSteps&&cells.length<motif.cells.length))break;
  }
  return {cells,beats};
}
// Copies of a head over the bar's groups from one to another (not included): one from each group it fits from,
// truncated where the groups left are shorter (never ending on its leap), the last note of each held to the end of the
// groups it spans.
function headCopies(head,groups,from,to,choices=LINE){
  const copies=[];
  for(let g=from;g<to;){
    let span=0,h=g;while(h<to&&span<head.beats-1e-9){span+=groups[h].count;h++}
    const start=groups[g].first,cells=head.cells.filter(cell=>cell.at<span-1e-9).map(cell=>retimeCell(cell,{at:Q(start).add(cellInterval(cell).at)}));
    while(cells.length>1&&cells.length<head.cells.length&&Math.abs(cells.at(-1).step)>=choices.leapSteps)cells.pop();
    cells[cells.length-1]=retimeCell(cells.at(-1),{end:Q(start+span)});
    copies.push(cells);g=h;
  }
  return copies;
}

// The phrase's bars as segments of cells: [{role, bar, cells: [{at, beats, step, cadence?}]}]. Roles: 'idea' (the motif,
// inverted in the 'inversion' variation), 'answer' (the idea's second bar, in a phrase of eight bars or more: its head,
// then held, as it is or mirrored), 'repetition' (and its answer), 'continuation' (the head's copies, one
// segment each; in a much sparser phrase, the later ones a held note each), 'cadence' (the head's copies to the group where the bar's second half
// begins, then the held tone),
// 'pickup' (where one is asked: its run over the bar's last felt beat, `fill` 'up' or 'down'). Each cell carries its
// index in the motif played (`cell`), the same in each place the motif comes.
// A motif from a line of notes (the band's: MemoryBOT's theme, [{at (quarters from its first), pitch, written?}]): its
// first bar's notes as cells -- each at its place in the meter's felt beats, as long as to the next, its step the pool's
// tones between it and the note before (linePitches in `register`) -- a grammar of its own ('band'). A note naming the
// stored motif it is from (motifs.js storedLine: motifId, index) makes its cell's `source`, which the notes planned from
// the cell keep (planLine). -> the motif, or null where the bar holds fewer than two notes.
export function motifFromLine(line,{meter,bpm,pool,register}){
  const given=(line??[]).filter(note=>Number.isFinite(note?.at)&&Number.isFinite(note?.pitch));
  // (Each onset where its players wrote it, where the line says (`written`: exact quarters, from the score time each note
  // was played under -- motifs.js), its notes written otherwise (a grace, a cadenza's) left out; a line no one wrote (a
  // tape's seconds, a performer heard), by ear: each onset on the nearest tick of this meter's own grid, the first of
  // those falling together kept. Never a fraction recognised in a sounding time: the wall clock is never scored (the
  // owner, 9 October 2026); that quantizing is archived, unused (research/rhythm-quantizing-archive).)
  const exact=given.filter(note=>typeof note.written==='string').map(note=>({...note,written:Q(note.written)})).sort((a,b)=>a.written.cmp(b.written));
  const notes=exact.length?exact:given.sort((a,b)=>a.at-b.at);if(notes.length<2)return null;
  const subdivision=Number(meter.subdivision)||4,tick=60/bpm/subdivision,beats=feltBeats(meter,{secondsPerTick:tick}),groups=beatGroups(meter,beats);
  const perQuarter=new R(subdivision*(Number(meter.denominator)||4),4),pulses=Number(meter.pulsesPerBar)||beats.reduce((sum,beat)=>sum+beat.length,0);
  const positionOf=ticks=>{const k=beats.findLastIndex(beat=>Q(beat.start).le(ticks));return k<0?R.ZERO:Q(k).add(ticks.sub(Q(beats[k].start)).div(Q(beats[k].length)))};
  const ticksOf=exact.length?note=>note.written.sub(notes[0].written).mul(perQuarter):note=>Q(Math.round((note.at-notes[0].at)*perQuarter.toNumber()));
  const inBar=notes.map(note=>({...note,ticks:ticksOf(note)})).filter((note,k,all)=>note.ticks.lt(pulses)&&(!k||note.ticks.gt(all[k-1].ticks)));if(inBar.length<2)return null;
  const ladder=linePitches(pool,register);if(ladder.length<3)return null;
  const index=pitch=>ladder.reduce((best,p,i)=>Math.abs(p-pitch)<Math.abs(ladder[best]-pitch)?i:best,0);
  const cells=inBar.map((note,k)=>{const at=positionOf(note.ticks),next=k+1<inBar.length?positionOf(inBar[k+1].ticks):Q(beats.length);
    return rhythmCell(at,next.sub(at),{step:k?index(note.pitch)-index(inBar[k-1].pitch):0,...(k<=1||k===inBar.length-1?{core:true}:{}),
      ...(typeof note.motifId==='string'&&Number.isInteger(note.index)?{source:Object.freeze({motifId:note.motifId,index:note.index})}:{})})});
  return Object.freeze({cells:Object.freeze(cells.map(cell=>Object.freeze(cell))),beats:beats.length,density:.5,grammar:'band',groups:Object.freeze(groups.map(group=>Object.freeze({...group})))});
}
// A return's cadence approach: the motif's head as the cadence states it, its first `keep` of its notes (at least one), each
// `augment` times as long and as far apart, ending where the cadence's held tone begins (`span` felt beats), a rest
// before it where it is shorter. -> cells.
export function cadenceApproach(head,{span,augment=1,keep=1}){
  const kept=head.cells.slice(0,Math.max(1,Math.round(head.cells.length*Math.max(0,Math.min(1,keep)))));
  let cells=kept.map(({rest,...cell})=>retimeCell(cell,{at:cellInterval(cell).at.mul(Q(augment)),duration:cellInterval(cell).duration.mul(Q(augment))})).filter(cell=>cell.at<span-1e-9);
  // (Its last note held to the next of the head's notes, as the head had it, then to the cadence's tone where it is cut.)
  const next=head.cells[kept.length];if(next&&cells.length===kept.length)cells[cells.length-1]=retimeCell(cells.at(-1),{end:cellInterval(next).at.mul(Q(augment))});
  cells=cells.map(cell=>retimeCell(cell,{end:cellInterval(cell).end.min(Q(span))}));
  const length=cells.reduce((end,cell)=>end.max(cellInterval(cell).end),R.ZERO),shift=Q(span).sub(length).max(0);
  return [...(shift.sign()>0?[rhythmCell(0,shift,{step:0,rest:true})]:[]),...cells.map(cell=>retimeCell(cell,{at:cellInterval(cell).at.add(shift)}))];
}
function phraseSegments({bars,motif:played,variation,beats,pulses,pickup=null,thin=0,choices=LINE,cadence:shapeOf=null,runOf=null}){
  const varied=variation==='inversion'?varyMotif(played,'inversion'):played;
  const shape={...varied,cells:varied.cells.map((cell,k)=>({...cell,cell:k}))},motif=shape,head=motifHead(shape,choices),groups=shape.groups,all=groups.length;
  const layout=bars<=1?['idea']:bars===2?['idea','cadence']:bars===3?['idea','continuation','cadence']:(()=>{
    const ideaBars=Math.max(1,Math.floor(bars/4)),out=[];
    for(const role of ['idea','repetition'])for(let i=0;i<ideaBars;i++)out.push(i?`${role} answer`:role);
    while(out.length<bars-1)out.push('continuation');
    out.push('cadence');return out;
  })();
  // Copies of the head, the later ones (`thin` of them) each its first note held through it.
  const thinned=copies=>{const keep=Math.round(copies.length*(1-clamp(thin,0,1)));return copies.map((cells,i)=>i<keep?cells:[retimeCell(cells[0],{end:cellInterval(cells.at(-1)).end})])};
  const segments=[];
  layout.forEach((role,bar)=>{
    if(role==='idea'||role==='repetition')segments.push({role,bar,cells:shape.cells.map(cell=>({...cell}))});else if(role.endsWith('answer')){
      const cells=head.cells.map(cell=>({...cell}));cells[cells.length-1]=retimeCell(cells.at(-1),{end:Q(motif.beats)});
      segments.push({role:'answer',bar,cells});
    }else if(role==='continuation'){
      // A much sparser phrase plays its later fragments (`thin`, 0 to 1, of them) as their first note, held through
      // the fragment: the line recedes, still climbing fragment by fragment, its motif's core still stated whole.
      thinned(headCopies(head,groups,0,all,choices)).forEach(cells=>segments.push({role,bar,cells}));
    }else{
      // The held tone from the group where the bar's second half begins (never the first), the head's rhythm before it.
      const middle=pulses/2;let tone=0;groups.forEach((group,g)=>{if(beats[group.first].start<=middle+1e-9)tone=g});
      if(tone===0&&all>1)tone=1;
      // The approach moves: a note of it longer than a felt beat played on its felt beats (in a much sparser phrase, its
      // later copies of the head a held note each, as the continuation's fragments).
      const approach=thinned(headCopies(head,groups,0,tone,choices)).flat().map(({rest,...cell})=>cell).flatMap(cell=>{
        if(cell.beats<=1+1e-9)return [cell];
        const parts=Math.max(1,Math.round(cell.beats));
        // (Its later notes neighbours of its own, no stored note's: no `source`.)
        const {source:_,...plain}=cell;
        return Array.from({length:parts},(_,k)=>rhythmCell(cellInterval(cell).at.add(cellInterval(cell).duration.mul(new R(k,parts))),cellInterval(cell).duration.div(parts),k?{...plain,step:k%2?1:-1}:cell));
      });
      // (A return's cadence states its motif's head, augmented or fragmented as drawn.)
      const stated=variation==='return'&&shapeOf&&(shapeOf.augment>1||shapeOf.keep<1)?cadenceApproach(head,{span:groups[tone].first,...shapeOf}):approach;
      segments.push({role,bar,cells:[...stated,rhythmCell(groups[tone].first,motif.beats-groups[tone].first,{step:0,cadence:true})]});
    }
  });
  if(bars<=1){const last=segments.at(-1).cells.at(-1);last.cadence=true}
  // A pickup: the bar's last felt beat its window (the drummer's), or the last half of it where the held tone begins
  // there; the held tone ending as the window begins; the window a run of `count` notes, evenly -- or, on the rhythm
  // engine, `runOf`'s: as many of them as its window holds, nested Euclidean rhythms.
  if(pickup&&(pickup.fill==='up'||pickup.fill==='down')&&Number.isInteger(pickup.count)&&pickup.count>=1){
    const last=segments.at(-1),tone=last.cells.at(-1),end=played.beats,start=tone.at<=end-1-.5+1e-9?end-1:end-.5;
    Object.assign(tone,retimeCell(tone,{end:Q(start)}));
    const count=end-start<1-1e-9?Math.max(1,Math.round(pickup.count/2)):pickup.count;
    const spans=runOf?.(Q(start),Q(end),count)??Array.from({length:count},(_,k)=>({at:Q(start).add(Q(end).sub(Q(start)).mul(new R(k,count))),duration:Q(end).sub(Q(start)).div(count)}));
    segments.push({role:'pickup',bar:last.bar,fill:pickup.fill,cells:spans.map(({at,duration})=>rhythmCell(at,duration,{step:0,fill:true}))});
  }
  return segments;
}

// The cadence's approach and tone: `count` moves (each one or two pool steps, up or down) from `from` to `target`,
// thirds before steps, the last into it by step where it can be; never above `ceiling` or below the voice's lowest
// pitch, never a run over runMost, never a note three times running; a leap before it recovered first. The first way
// found in that order of preference; where none keeps every rule, null when `strict`, and otherwise the runs let go.
// `least`: the lowest it may go; `after`: the notes that follow the target, so that no run passes through it.
function cadenceSteps({from,target,count,ceiling,least=0,after=[],history,choices,strict=false}){
  const feasible=(rest,left)=>left===0?rest===0:Math.abs(rest)<=2*left&&!(left===1&&rest===0);
  const search=(line,at,left,runs)=>{
    if(left===0)return at===target?[]:null;
    const need=target-at,toward=Math.sign(need)||-1,before=line.length>1?line.at(-1)-line.at(-2):0;
    let options=Math.abs(need)>left?[2*toward,toward,-toward,-2*toward]:[toward,2*toward,-toward,-2*toward];
    if(Math.abs(before)>=choices.leapSteps)options=[-Math.sign(before),-2*Math.sign(before),...options.filter(step=>Math.sign(step)!==Math.sign(before))];
    for(const step of options){
      const next=at+step;
      if(next<least&&!(left===1&&next===target)||next>ceiling&&!(left===1&&next===target)||!feasible(need-step,left-1))continue;
      if(runs&&(left===1?longestRun([...line.slice(-2*choices.runMost-2),next,...after.slice(0,2*choices.runMost+2)]):runAtEnd([...line,next]))>choices.runMost)continue;
      const rest=search([...line,next],next,left-1,runs);
      if(rest)return [next,...rest];
    }
    return null;
  };
  const kept=search([...history],from,count,true);
  if(kept||strict)return kept;
  return search([...history],from,count,false)??Array.from({length:count},(_,k)=>Math.round(from+(target-from)*(k+1)/count));
}

// The phrase's pitches, as indices into the voice's pitches, one per cell of its segments in order: the idea at the
// phrase's floor, its repetition sequenced by the variation, the continuation's fragments climbing to the apex, and the
// cadence falling by step to the floor. Each segment keeps its own shape (a continuation's fragment may be inverted, so
// that it climbs by turns, not by a scale) and is set where the rules allow nearest to where the phrase's arch wants
// it: no join leap wider than leapMost, a leap recovered by a step the other way, no run over runMost, no note three
// times running, the range kept, nothing reaching the apex before the apex's fragment, and the apex not the last
// phrase's. The settings are searched together, the best few kept segment by segment (a beam), and the cadence found
// for each, so that an early setting leaves the later ones room.
function contour({segments,top,variation,climax,avoid,rangeSteps,lead=null,finalTargets=null,random,choices}){
  const [least,most]=climax?choices.climaxSpan:choices.span;
  const offsetsOf=cells=>{let sum=0;return cells.map((cell,k)=>(sum+=k?cell.step:0))};
  const ideaOffsets=offsetsOf(segments.find(segment=>segment.role==='idea')?.cells??[]);
  const ideaLow=Math.min(0,...ideaOffsets),ideaSpan=Math.max(0,...ideaOffsets)-ideaLow;
  // Its span, drawn: never so small that the idea, or its repetition a step higher, reaches the apex.
  let span=Math.min(rangeSteps,top,Math.max(ideaSpan+2,least+Math.floor(random()*(most-least+1))));
  // Its floor: low in the voice (a quarter to two fifths up; a sequenced phrase two steps higher), or, where the last
  // phrase's pickup landed (`lead`), where its idea begins on that note.
  const drawn=Math.round(top*(.22+.15*random()))+(variation==='sequence'?2:0);
  const floor=Number.isInteger(lead)?clamp(lead+ideaLow,0,top):clamp(drawn,0,Math.max(0,top-span));
  span=Math.max(1,Math.min(span,top-floor));
  // (Its own draw, from the phrase's shape -- its floor, span, apex's aim and segments -- so the line's other draws are
  // those they were.)
  const shapeKey=`${floor}:${span}:${top}:${variation}:${segments.map(segment=>`${segment.role}${segment.cells.length}`).join(',')}`;
  let hash=2166136261;for(const character of shapeKey){hash^=character.charCodeAt(0);hash=Math.imul(hash,16777619)>>>0}
  const [fromLanding,toLanding]=choices.landing??[0,0],landing=fromLanding+(toLanding-fromLanding)*((hash>>>8)/16777216)**2;
  const continuing=segments.map((segment,s)=>segment.role==='continuation'?s:-1).filter(s=>s>=0);
  const apexSegment=continuing.length?continuing.at(-1):0;
  const repeatStep=variation==='statement'?(random()<.5?0:1):variation==='return'?-1:1;
  // Its apex's aim: the span's top; not the last phrase's apex, but a step higher where the voice and the range allow,
  // or else a step lower.
  let apexTarget=floor+span;
  if(apexTarget===avoid)apexTarget+=apexTarget<top&&apexTarget+1-floor<=rangeSteps?1:-1;
  // What a segment's notes cost after a line: the rules they break (each far dearer than any preference, so that a
  // rule gives way only where no setting the search holds keeps it), and how far the apex is from its aim. `silences`:
  // the notes a comma comes before. A leap is recovered by the next move (a repeated note between them aside), a step
  // the other way, unless a silence comes before it or after it: there the line begins again.
  const cost=(line,notes,apex,silences=[])=>{
    const all=line.concat(notes);let total=0;
    for(let k=Math.max(1,line.length);k<all.length;k++){
      const step=all[k]-all[k-1];
      let j=k-1;while(j>0&&all[j]===all[j-1])j--;
      const before=j>0?all[j]-all[j-1]:0,breath=silences.some(at=>at>=j&&at<=k);
      if(Math.abs(step)>choices.leapMost)total+=100;
      if(step&&Math.abs(before)>=choices.leapSteps&&!breath&&!(Math.sign(step)===-Math.sign(before)&&Math.abs(step)<=2))total+=RULE;
      if(k>1&&step===0&&all[k-1]===all[k-2])total+=RULE;
      if(k===line.length&&step===0)total+=.6;
      if(runAtEnd(all.slice(0,k+1))>choices.runMost)total+=RULE;
    }
    // The range, charged where a segment widens it past its most (once, as each rule broken is).
    const excess=list=>list.length?Math.max(0,Math.max(...list)-Math.min(...list)-rangeSteps):0;
    total+=6*(excess(all)-excess(line));
    const highest=Math.max(...notes);
    // One apex, in the apex's segment, above all before it and not the last phrase's; nothing before it reaching its aim.
    if(apex)total+=Math.abs(highest-apexTarget)*.5+(highest===avoid?RULE:0)+(line.length&&Math.max(...line)>=highest?RULE:0);
    else if(highest>=apexTarget)total+=RULE;
    return total;
  };
  // What a line ends on that the next notes must answer: a leap not yet recovered (a silence after it aside), or a run
  // at its most, which must turn. Half a rule's cost each while it waits, the whole where the next notes fail it, so
  // that a setting at a rule's edge is not kept for its cheapness. -> [cost, the waiting leap's direction].
  const pending=(list,silences)=>{
    let j=list.length-1;while(j>0&&list[j]===list[j-1])j--;
    const leap=j>0&&Math.abs(list[j]-list[j-1])>=choices.leapSteps&&!silences.some(at=>at>=j),run=runAtEnd(list)>=choices.runMost;
    return [(leap?RULE/2:0)+(run?RULE/2:0),leap?Math.sign(list[j]-list[j-1]):0];
  };
  // The apex's segment reaches its apex once: where its highest offset comes twice, one raised a step (the latest that
  // makes no new leap), or else the others lowered.
  const noNewLeaps=(shape,offsets)=>shape.every((offset,k)=>!k||Math.abs(offset-shape[k-1])<choices.leapSteps||Math.abs(offsets[k]-offsets[k-1])>=choices.leapSteps);
  const unique=(offsets,core=[])=>{
    // Its highest reached once: a note repeated there at once is the one apex, held. A note outside the motif's core
    // raised before one of it.
    const most=Math.max(...offsets),at=offsets.flatMap((offset,k)=>offset===most&&offsets[k-1]!==most?[k]:[]);
    if(at.length<2)return offsets;
    for(const k of [...at].reverse().sort((a,b)=>Boolean(core[a])-Boolean(core[b]))){const shape=offsets.map((offset,i)=>i===k?offset+1:offset);if(noNewLeaps(shape,offsets))return shape}
    const lowered=offsets.map((offset,i)=>offset===most&&i!==at.at(-1)?offset-1:offset);
    return noNewLeaps(lowered,offsets)?lowered:offsets;
  };
  // Where a segment is wanted, after a line.
  const wanted=(state,segment,s,offsets)=>{
    const previous=state.starts.at(-1);
    if(segment.role==='idea')return {desired:floor-Math.min(...offsets)};
    if(segment.role==='repetition')return {desired:segments[s-1].role==='repetition'?previous+1:(state.ideaStart??floor)+repeatStep};
    if(segment.role==='answer')return {desired:previous-1};
    // The continuation's fragments climb from a step above what came before to the apex, the last reaching it.
    const j=continuing.indexOf(s),n=continuing.length,headTop=Math.max(...offsets),climbFrom=state.climbFrom??previous+1;
    let to=apexTarget-headTop;
    if(to<climbFrom+Math.min(n-1,1))to=climbFrom+Math.min(n-1,1);
    return {desired:n>1?Math.round(climbFrom+(to-climbFrom)*j/(n-1)):to,climbFrom};
  };
  let states=[{line:[],starts:[],silences:[],cost:0,ideaStart:null,climbFrom:null}];
  segments.forEach((segment,s)=>{
    if(segment.role==='cadence'||segment.role==='pickup')return;
    const offsets=offsetsOf(segment.cells),apex=s===apexSegment,breathes=s>0&&segments[s-1].comma;
    // A continuation's fragment, or an answer (a response to its idea), may be mirrored.
    const shapes=[[offsets,0],...(segment.role==='continuation'||segment.role==='answer'?[[offsets.map(offset=>-offset),.5]]:[])].map(([shape,extra])=>[apex?unique(shape,segment.cells.map(cell=>Boolean(cell.core))):shape,extra]);
    // Where a setting is from where it is wanted: its middle from the middle wanted (so an inverted fragment, which
    // rises from where the other falls, is set in the same register).
    const middle=list=>list.reduce((sum,value)=>sum+value,0)/list.length,wantedMiddle=middle(offsets);
    const next=[];
    for(const state of states){
      const {desired,climbFrom=state.climbFrom}=wanted(state,segment,s,offsets);
      // Where the last phrase's pickup landed, the idea's place counts twice: it begins where the run arrives.
      const weight=segment.role==='idea'&&Number.isInteger(lead)?2:1;
      const silences=breathes?[...state.silences,state.line.length]:state.silences,waiting=pending(state.line,silences)[0];
      const keep=(notes,extra)=>{
        const line=state.line.concat(notes),after=segment.comma?[...silences,line.length]:silences;
        next.push({line,starts:[...state.starts,notes[0]],silences,ideaStart:state.ideaStart??(segment.role==='idea'?notes[0]:null),climbFrom,
          cost:state.cost+weight*Math.abs(middle(notes)-desired-wantedMiddle)+extra+cost(state.line,notes,apex,silences)+pending(line,after)[0]-waiting});
      };
      let fitted=false;
      for(const [shape,extra] of shapes)for(let start=0;start<=top;start++){
        const notes=shape.map(offset=>start+offset);
        if(notes.some(index=>index<0||index>top))continue;
        fitted=true;keep(notes,extra);
      }
      if(!fitted)keep(offsets.map(offset=>clamp(desired+offset,0,top)),0);
    }
    // Of settings alike in all that the rules and aims ahead depend on (their last notes and last move, the run they
    // end on, their highest and lowest, where their last segment, their idea and their climb began), only the cheapest
    // is kept: the few the search holds then differ in what can follow them.
    const ahead=state=>{
      const line=state.line;let j=line.length-1;while(j>0&&line[j]===line[j-1])j--;
      return [line.slice(-3).join(' '),j>0?line[j]-line[j-1]:0,runAtEnd(line),Math.max(...line),Math.min(...line),state.starts.at(-1),state.ideaStart,state.climbFrom].join('|');
    };
    next.sort((a,b)=>a.cost-b.cost);
    const seen=new Set;states=[];
    for(const state of next){const key=ahead(state);if(seen.has(key))continue;seen.add(key);states.push(state);if(states.length>=choices.beam)break}
  });
  // The cadence for each: its tone the floor, or the nearest above it that it can reach keeping every rule.
  const cadence=segments.find(segment=>segment.role==='cadence'),lastPlaced=segments.findLast(segment=>segment.role!=='cadence'&&segment.role!=='pickup');
  const finished=states.map(state=>{
    const line=[...state.line];let extra=0;
    // The leap it ends on, if one waits: recovered by the cadence's first move, or charged whole.
    const [waiting,direction]=pending(line,lastPlaced?.comma?[...state.silences,line.length]:state.silences);
    if(cadence){
      const count=cadence.cells.length,from=line.at(-1),ceiling=Math.max(...line)-1,low=Math.max(0,floor-1);
      // (Its landing: a share of the span above the floor, the nearest it can reach.)
      const aim=floor+Math.round(landing*span),lowest=Math.min(Math.max(aim,from-2*count,0),ceiling);
      let steps=null,target=lowest;
      // The piece's last phrase closes on the tonic: the nearest of its pitches to the floor that the cadence can reach
      // keeping every rule, where one can be (and a setting that cannot is dearer).
      for(const tonic of (finalTargets??[]).filter(index=>index<=ceiling).sort((a,b)=>Math.abs(a-floor)-Math.abs(b-floor)||a-b)){
        steps=cadenceSteps({from,target:tonic,count,ceiling,least:Math.min(low,tonic),history:line,choices,strict:true});
        if(steps){extra+=Math.abs(tonic-floor)*.5;break}
      }
      if(!steps){
        for(;target<=ceiling&&!steps;target++)steps=cadenceSteps({from,target,count,ceiling,least:low,history:line,choices,strict:true});
        if(steps)extra+=(target-1-lowest)*.5+(finalTargets?.length?RULE/4:0);
        else{steps=cadenceSteps({from,target:lowest,count,ceiling,least:low,history:line,choices});extra+=RULE}
      }
      const move=steps.map((index,k)=>index-(k?steps[k-1]:from)).find(Boolean)??0;
      if(direction&&!(Math.sign(move)===-direction&&Math.abs(move)<=2))extra+=RULE;
      line.push(...steps);
    }
    extra-=waiting;
    // One apex, and not the last phrase's.
    const highest=Math.max(...line);
    if(line.filter((index,k)=>index===highest&&line[k-1]!==highest).length>1)extra+=RULE;
    if(highest===avoid)extra+=RULE;
    return {line,cost:state.cost+extra};
  }).sort((a,b)=>a.cost-b.cost);
  const line=finished[0].line;
  // The rules, kept where the search could not: one apex (a later equal lowered a step), and not the last phrase's (the
  // apex a step higher, or lower, whichever leaves its neighbours by step).
  let apex=Math.max(...line);
  if(apex===avoid){
    const at=line.indexOf(apex),smooth=value=>[line[at-1],line[at+1]].every(near=>near==null||Math.abs(value-near)<choices.leapSteps);
    line[at]=apex+1<=top&&(smooth(apex+1)||!smooth(apex-1))?apex+1:Math.max(0,apex-1);apex=Math.max(...line);
  }
  let first=line.indexOf(apex);while(line[first+1]===apex)first++;
  for(let k=first+1;k<line.length;k++)if(line[k]===apex){
    // Lowered by the least that makes no note three times running with its neighbours, within its register: in one of
    // three pitches it had been lowered below the lowest, a note with no pitch (Op. 3.27's oboe, 4 October 2026).
    const fits=value=>!(line[k-1]===value&&line[k-2]===value)&&!(line[k-1]===value&&line[k+1]===value)&&!(line[k+1]===value&&line[k+2]===value);
    line[k]=[apex-1,apex-2,apex-3].filter(value=>value>=0).find(fits)??Math.max(0,apex-1);
  }
  return {indices:line,apex,floor};
}

// A run's pitches (a pianist's passagework, its rhythm its own): `count` notes as pool indices from `low` to `high`,
// beginning on `from` (the nearest it may), keeping the line's rules. Its highest note sounds once, at or below `apex`
// (the phrase's apex this run may reach; with `reach`, on it, or a step below where that is `avoid`), and is never
// `avoid` (the last phrase's apex). A leap (leapSteps or more) is answered by a step back and is never its last move; no
// note sounds three times running, nor twice without `repeat` (a key struck again at once, which a pianist's run avoids);
// no more than `runMost` moves go one way (a scalar run's own; the line's where none is given). With `arch` (the
// default), its turning points trace one arch (7a, 29 September, of a guitar solo's bar of 73 notes in 14 tones going
// down and back five times between the same turns): each crest higher than the last until the run's apex and lower
// after it, each trough the same, its first and last notes counting as a crest where the run leaves them downward or
// arrives at them upward, and as a trough otherwise. The compound-melody reading: a figuration's turning points make the
// line under it, and that line does not circle. A climb (up two, back one), a cascade and an arch keep it; a run
// circling between the same turns does not. Where its length cannot trace one arch in its range (88 notes in ten
// tones), as few as it can, two and then three, one after another (a turning point higher than the last of its kind
// once an apex is behind begins the next); beyond that, the other rules alone, as before. Steps are preferred to leaps,
// going on to turning, a new note to a repeated one; `random` breaks ties. Searched whole (a beam of `beam` settings,
// those with the same future kept once), so every rule holds by construction.
// -> {indices, apex (its highest index), arches (how many its turning points trace, or null where the other rules
// alone), arched (one)}, or null where no run in the range keeps the other rules.
export function runContour({count,low=0,high,from=low,apex=high,reach=false,avoid=null,runMost=LINE.runMost,repeat=true,arch=true,random=Math.random,beam=256,choices=LINE}){
  const ceiling=Math.min(high,apex);
  if(!Number.isInteger(count)||count<1||!Number.isInteger(low)||!Number.isInteger(ceiling)||ceiling<low)return null;
  const target=reach?(ceiling===avoid?ceiling-1:ceiling):null;
  if(target!=null&&target<low)return null;
  const {leapSteps,leapMost}=choices,start=Math.max(low,Math.min(ceiling,Math.round(from)));
  // A turning point where the arches allow one (`most` of them): a crest (the run turns down from it) or a trough,
  // against the last of its kind; `falling` once an arch's apex is behind, `arches` how many have begun. -> the setting's
  // arches after it ({crest, trough, falling, arches}), or null.
  const turn=(state,value,crest,most)=>{
    const last=crest?state.crest:state.trough;
    if(last===value)return null;
    const next={crest:state.crest,trough:state.trough,falling:state.falling,arches:state.arches,[crest?'crest':'trough']:value};
    if(state.falling){
      if(last==null||value<last)return next;
      // Higher than the last of its kind once the apex is behind: the next arch, where one more may begin.
      if(state.arches>=most)return null;
      next.falling=false;next.arches=state.arches+1;return next;
    }
    // Rising: higher than the last of its kind, or lower once the apex (the last crest, the highest so far) is behind.
    if(last!=null&&value<last)next.falling=true;
    return next;
  };
  // Its last note, a crest where the run arrives at it upward and a trough where downward, kept to the arches too.
  const archEnds=(state,most)=>!most||state.dir===0||turn(state,state.index,state.dir>0,most)!=null;
  const finished=(state,most)=>state.times===1&&state.max!==avoid&&(target==null||state.max===target)&&archEnds(state,most);
  // The most it can still climb in `moves` moves, from a setting whose last moves went up `len` times (0 where they went
  // down) and whose last was a leap up (1), down (-1) or neither (0): a run that must reach its apex keeps only settings
  // that still can.
  const climbs=new Map,climb=(moves,len,leap)=>{
    if(moves<=0)return 0;
    const key=`${moves}|${len}|${leap}`;if(climbs.has(key))return climbs.get(key);
    let most=-Infinity;
    for(let d=-leapMost;d<=leapMost;d++){
      if(leap&&!(Math.sign(d)===-leap&&Math.abs(d)<=2)||d===0&&!repeat)continue;
      const next=Math.abs(d)>=leapSteps?Math.sign(d):0;if(next&&moves===1)continue;
      const up=d>0?len+1:d<0?0:len;if(up>runMost)continue;
      most=Math.max(most,d+climb(moves-1,up,next));
    }
    climbs.set(key,most);return most;
  };
  // One arch where the run can trace it, else two, else three; else the other rules alone, as before, so it sounds.
  const attempts=arch?[[1,beam],[2,beam],[3,beam],[0,beam],[0,beam*8]]:[[0,beam],[0,beam*8]];
  for(const [most,width] of attempts){
    let states=[{index:start,leap:0,same:1,dir:0,len:0,max:start,times:1,crest:null,trough:null,falling:false,arches:1,cost:0,prev:null}];
    for(let k=1;k<count&&states.length;k++){
      const left=count-1-k,best=new Map;
      for(const state of states)for(let d=-leapMost;d<=leapMost;d++){
        const index=state.index+d;
        if(index<low||index>ceiling||d===0&&!repeat)continue;
        // A leap answered by a step back; never a leap last; never three alike.
        if(state.leap&&!(Math.sign(d)===-state.leap&&Math.abs(d)<=2))continue;
        const leap=Math.abs(d)>=leapSteps?Math.sign(d):0;
        if(leap&&left===0)continue;
        const same=d===0?state.same+1:1;if(same>2)continue;
        const turned=d!==0&&Math.sign(d)!==state.dir,dir=d===0?state.dir:Math.sign(d),len=d===0?state.len:turned?1:state.len+1;
        if(len>runMost)continue;
        const max=Math.max(state.max,index),times=index>state.max?1:index===state.max?Math.min(2,state.times+1):state.times;
        // A run that must reach its apex keeps it within reach, and never sounds it twice.
        if(target!=null&&(max===target&&times>1||max<target&&target-index>climb(left,dir>0?len:0,leap)))continue;
        // The arch: where it turns (or first moves), the note it leaves is a crest or a trough the arch must allow; once
        // the apex is behind, nothing climbs to it again.
        let shape={crest:state.crest,trough:state.trough,falling:state.falling,arches:state.arches};
        if(most&&d!==0&&(turned||state.dir===0)){
          shape=turn(state,state.index,d<0,most);if(!shape)continue;
          // Falling in its last arch, it never climbs to its apex again, and an apex it must reach is behind it already.
          if(shape.falling&&(index>=max||target!=null&&max<target&&shape.arches>=most))continue;
        }else if(most&&state.falling&&index>=state.max)continue;
        const cost=state.cost+(d===0?1.5:Math.abs(d)-1)+(turned&&state.dir!==0?1:0)+random()*.01;
        const key=`${index}|${leap}|${same}|${dir}|${len}|${max}|${times}|${shape.crest}|${shape.trough}|${shape.falling}|${shape.arches}`,known=best.get(key);
        if(!known||cost<known.cost)best.set(key,{index,leap,same,dir,len,max,times,...shape,cost,prev:state});
      }
      states=[...best.values()].sort((a,b)=>a.cost-b.cost).slice(0,width);
    }
    const end=states.filter(state=>finished(state,most)).sort((a,b)=>a.cost-b.cost)[0];
    if(!end)continue;
    const indices=[];for(let state=end;state;state=state.prev)indices.unshift(state.index);
    return {indices,apex:end.max,arches:most?end.arches:null,arched:Boolean(most)&&end.arches===1};
  }
  return null;
}

// A phrase's line: {status: 'planned', notes: [{id, pitch, start, end (s from the phrase's downbeat), dynamic, velocity,
// division, beatStart, role, slur?, fioritura?, cadence?, figure? (a diminution's), fill? (a pickup's), core? (a note of
// its motif's protected core), source? (a stored motif's note it plays: {motifId, index}, motifFromLine)}], motif, apex
// (its highest pitch, its ornaments aside), variation, lead (where its pickup lands: the next phrase's first note, or
// null), choice? (where its motif was chosen here: {slate, reason})} or {status: 'declined', reason, notes: []}.
// register: [low, high]; pool: the harmony's pitches; meter, bpm (the notated beat's), bars; density and loudness 0 to
// 1; fioriture 0 to 1; motif (the instrument's, kept from phrase to phrase; chosen here where none, at motifDensity, the
// instrument's own, from a slate distinct from `heard`: the motifs the other lines have said); phraseIndex (which
// variation it takes); previousApex (the last phrase's apex pitch, not taken again); climax (the section's climax
// phrase: the widest span); pickup ({fill: 'up' | 'down', count}: a run into the next phrase over the last felt beat,
// where the form marks the join) and lead (the last phrase's landing, which its idea begins on); final ({tonic: a pitch
// class or null, motif?: the band's motif, its return's where it returns one}: the piece's last phrase, its cadence on
// the tonic and held to its end, with no pickup); coreOnly (under
// another's entrance, a texture's presentation, shared/presentation.js: its idea's core, then a tone a segment and its
// cadence, each held through the notes it leaves out); random.
export function planLine({register,pool,meter,bpm,bars,density=.4,loudness=.5,fioriture=0,motif=null,motifDensity=null,phraseIndex=0,previousApex=null,climax=false,pickup:asked=null,lead=null,heard=[],final=null,coreOnly=false,random,choices=LINE}){
  // The piece's last phrase: no pickup out of it, its cadence on the tonic, held to the end.
  const pickup=final?null:asked;
  const pitches=linePitches(pool,register);
  if(pitches.length<3)return {status:'declined',reason:'fewer than three pitches in its register to play a line with',notes:[]};
  const subdivision=Number(meter.subdivision)||4,tick=60/bpm/subdivision,pulses=Number(meter.pulsesPerBar);
  const beats=feltBeats(meter,{secondsPerTick:tick}),groups=beatGroups(meter,beats),phraseSeconds=bars*pulses*tick,top=pitches.length-1;
  // (A felt beat's seconds, on average: how finely its notes may divide, divisionOf.)
  const beatSeconds=phraseSeconds/Math.max(1,bars*beats.length);
  // On the rhythm engine (line-rhythm.js): the bar its spans lie in, and its motif's own, each felt beat in that as
  // short as the bar's shortest, so that its rhythm is playable wherever the phrase places it (its head copied into
  // another group). -> a span's notes: as many as `count` asks of what it holds.
  const quickest=choices.shortest??LINE.shortest,shares=choices.rhythm?rhythmShares(choices.rhythm):null,units=beats.map(beat=>beat.length/subdivision);
  const bar=shares?barOf({groups,beatSeconds:beats.map(beat=>beat.length*tick),unitsPerBeat:units}):null;
  const motifBar=shares?barOf({groups,beatSeconds:beats.map(()=>Math.min(...beats.map(beat=>beat.length*tick))),unitsPerBeat:units}):null;
  const notesIn=(at,end,count)=>{const tree=spanTree({at,end},{bar,quickest,shares,random}),most=leavesOf(tree);return noteSpans(placeNotes(tree,Math.max(1,Math.min(most,count(most))),random),end)};
  const {motif:mine,choice=null}=fitMotif(motif,{groups,density:motifDensity??choices.motifDensity,heard,random,choices,beatSeconds,bar:motifBar});
  // (The piece's last phrase its motif's return -- an ending signified by the opening's idea coming back, the owner's
  // "motivic signifiers of ending" -- as often as a share drawn from the motif itself, LINE.recall; its cadence on the
  // tonic as ever.)
  let hash=2166136261;if(final)for(const character of (mine?.cells??[]).map(cell=>`${cell.at}:${cell.beats}:${cell.step}`).join('|'))hash=Math.imul(hash^character.charCodeAt(0),16777619)>>>0;
  const [fewest,most]=choices.recall??[0,0],recalls=Boolean(final)&&((Math.imul(hash,2654435761)>>>8)/16777216)<fewest+(most-fewest)*((hash>>>8)/16777216);
  // (Its return the band's motif where its last phrase is given one -- MemoryBOT's theme (line-motifs.js bandMotif) --
  // fitted to this phrase's bar; else its own.)
  const own=recalls&&final?.motif?.cells?.length?fitMotif(final.motif,{groups,density:motifDensity??choices.motifDensity,heard,random,choices,beatSeconds,bar:motifBar}).motif:mine;
  const variation=recalls?'return':choices.variations[phraseIndex%choices.variations.length];
  // (The return's cadence, drawn from the motif too: augmented as often as its share, fragmented by as much as its.)
  const drawOf=k=>(Math.imul(hash,[2246822519,3266489917][k])>>>8)/16777216,shape=choices.recallCadence??{augment:0,fragment:0};
  const cadenceShape=recalls?{augment:drawOf(0)<shape.augment?2:1,keep:+(1-shape.fragment*drawOf(1)).toFixed(3)}:null;
  // Map authored felt-beat positions to exact phrase ticks before projecting them to seconds.
  const tickOf=(bar,position)=>{
    const p=Q(position),whole=p.floor(),fraction=p.sub(whole);
    const beat=beats[Math.min(whole,beats.length-1)],extra=whole>=beats.length?whole-beats.length+1:0;
    return Q(bar*pulses).add(Q(beat?.start??0)).add(Q(beat?.length??pulses/beats.length).mul(fraction.add(extra)));
  };
  const timeOf=(bar,position)=>{
    const whole=Math.floor(position+1e-9),fraction=position-whole,beat=beats[Math.min(whole,beats.length-1)],extra=whole>=beats.length?whole-beats.length+1:0;
    return (bar*pulses+(beat?.start??0)+(beat?.length??pulses/beats.length)*(fraction+extra))*tick;
  };
  // The motif at this phrase's density: sparser, its main notes held; denser, its held notes divided (below).
  const made=Number.isFinite(own.density)?own.density:density;
  const sparser=clamp((made-density)/Math.max(made,1e-9),0,1),played=simplifyMotif(own,sparser,random);
  // Its segments as heard: a rest of the motif's signature sounds nothing (its place kept as silence), and the rules are
  // kept among the notes that sound.
  const segments=phraseSegments({bars,motif:played,variation,beats,pulses,pickup,thin:(sparser-.5)*2,choices,cadence:cadenceShape,
    runOf:bar?(at,end,count)=>notesIn(at,end,()=>count):null}).map(segment=>({...segment,cells:soundingCells(segment.cells)}));
  // The comma after a unit of the sentence (the idea, its repetition, an answer), where its last note is long enough to
  // breathe after: the line begins again there (a leap across it asks no recovery), and the note before it is held.
  segments.forEach((segment,s)=>{
    const next=segments[s+1],last=segment.cells.at(-1);
    if(!next||!last||!['idea','repetition','answer'].includes(segment.role)||next.role===segment.role||next.role==='answer')return;
    if(timeOf(segment.bar,last.at+last.beats)-timeOf(segment.bar,last.at)>=choices.commaLeast)segment.comma=true;
  });
  const semitoneStep=(pitches.at(-1)-pitches[0])/Math.max(1,top);
  // The phrase's range in the voice's steps: its widest in semitones, and never less than its motif's span and a climb
  // above it (in a pool of wide steps, a motif's leap alone may be most of the range).
  const ideaOffsets=(()=>{let sum=0;return (segments.find(segment=>segment.role==='idea')?.cells??[]).map((cell,k)=>(sum+=k?cell.step:0))})();
  const motifSpan=ideaOffsets.length?Math.max(...ideaOffsets)-Math.min(...ideaOffsets):0;
  const rangeSteps=Math.max(3,motifSpan+3,Math.round(choices.phraseRange*(climax?4/3:1)/Math.max(1e-9,semitoneStep)));
  const avoid=previousApex==null?null:pitches.findIndex(pitch=>Math.abs(pitch-previousApex)<.5);
  const leadIndex=Number.isFinite(lead)?pitches.reduce((best,pitch,k)=>Math.abs(pitch-lead)<Math.abs(pitches[best]-lead)?k:best,0):null;
  // The tonic's pitches in the voice (a pitch class, the nearest in the pool where none is exact), for the last phrase.
  const tonic=Number(final?.tonic),classOf=pitch=>((pitch-tonic)%12+12)%12,apart=pitch=>Math.min(classOf(pitch),12-classOf(pitch));
  const nearest=final&&Number.isFinite(tonic)?Math.min(...pitches.map(apart)):null;
  const finalTargets=nearest!=null&&nearest<=.5?pitches.flatMap((pitch,k)=>Math.abs(apart(pitch)-nearest)<1e-6?[k]:[]):null;
  const {indices:line,apex}=contour({segments,top,variation,climax,avoid:avoid>=0?avoid:null,rangeSteps,lead:leadIndex,finalTargets,random,choices});
  // The pickup's run and its landing, the next phrase's first note. The landing first: `count` + 1 steps from the held
  // tone, up or down, and where the next phrase's idea can begin on it (its motif, as the next variation plays it, above
  // the voice's lowest and with three steps to climb below its highest); then the run, by step, into it (from the other
  // side of the tone, after a leap, where the landing had to move).
  const pickupSegment=segments.find(segment=>segment.role==='pickup'),pickupRun=[];let landing=null;
  if(pickupSegment){
    const count=pickupSegment.cells.length,direction=pickupSegment.fill==='up'?1:-1,tone=line.at(-1);
    const nextVariation=choices.variations[(phraseIndex+1)%choices.variations.length];
    const nextOffsets=(()=>{let sum=0;return own.cells.map((cell,k)=>(sum+=k?(nextVariation==='inversion'?-cell.step:cell.step):0))})();
    const low=-Math.min(...nextOffsets),high=top-Math.max(...nextOffsets)-3;
    landing=clamp(low<=high?clamp(tone+direction*(count+1),low,high):tone+direction*(count+1),0,top);
    const reflect=index=>{let value=index;for(let guard=0;guard<4&&(value<0||value>top);guard++)value=value<0?-value:2*top-value;return clamp(value,0,top)};
    for(let k=count;k>=1;k--)pickupRun.push(reflect(landing-direction*k));
  }
  const skeleton=[...line,...pickupRun];
  // Diminution, where the phrase is denser than its motif: a held note (a felt beat or more) divided into a figure of
  // quicker notes that walks by steps and turns to the note after it, never to the apex; as many of the motif's held
  // notes as the density says, which drawn at random, divided alike wherever the motif comes: never the note before a
  // rest of its signature, never its head where the motif is stated (the idea, its repetition, an answer: its rhythm is
  // the motif's), though in its fragments and the cadence's approach; a note of its core only into a figure beginning
  // on it (its place and pitch kept). The cadence's tone is held.
  const more=clamp((density-made)/Math.max(1-made,1e-9),0,1);
  // (Each held note divided by as many as its own span holds at this density: divisionOf, its notes in all -- counted a
  // beat's worth again for every beat it holds, a two-beat note's figure had gone twice as quick as its players' quickest
  // note, Op. 3.31's violins fourteen notes in a second, written in sevens and nines of 128ths.)
  const division=cell=>{
    const {at,end,duration}=cellInterval(cell),covered=beats.slice(at.floor(),Math.ceil(end.toNumber()));
    // Equal subdivisions in felt beats can cross unequal physical beat lengths. Their shortest possible span is
    // bounded by the least seconds per felt beat they cross, not the phrase's average seconds per beat.
    const minimum=Math.min(...covered.map(beat=>beat.length*tick)),span=duration.toNumber()*minimum;
    const most=Math.floor(span/(choices.shortest??LINE.shortest)+1e-9);
    return most<2?1:Math.min(most,divisionOf(density,{seconds:span,choices}));
  };
  // (On the engine, a note is held that holds two of its player's quickest, and its figure's notes are a nested
  // Euclidean rhythm in its own span, as many as the phrase's density asks of what it holds: at the most, every one.)
  const holds=cell=>bar?bar.secondsOf(cellInterval(cell).at,cellInterval(cell).end)>=FIGURE_LEAST*quickest-1e-9:cell.beats>=1-1e-9;
  const figureOf=cell=>notesIn(cellInterval(cell).at,cellInterval(cell).end,most=>countOf(density,most,{least:FIGURE_LEAST}));
  const held=played.cells.flatMap((cell,k)=>holds(cell)&&!cell.rest&&!played.cells[k+1]?.rest?[k]:[]),chosen=drawnSet(held.length,held.length*more,random);
  const divided=played.cells.map((cell,k)=>chosen.has(held.indexOf(k))&&held.includes(k));
  const skeletonCells=segments.flatMap((segment,s)=>segment.cells.map((cell,k)=>({...cell,bar:segment.bar,role:segment.role,segment:s,
    ...(segment.comma&&k===segment.cells.length-1?{comma:true}:{})})));
  const cells=[],indices=[],lowest=Math.min(...line);
  skeletonCells.forEach((cell,k)=>{
    // Never a repeated pair's first note: its repetition is the motif's (and a repeated apex stays one apex).
    const stated=(cell.role==='idea'||cell.role==='repetition'||cell.role==='answer')&&cell.cell<=1;
    const plain=cell.cadence||cell.fill||cell.comma||stated||!holds(cell)||!divided[cell.cell]||skeleton[k+1]===skeleton[k];
    const spans=plain?null:bar?figureOf(cell):null,parts=spans?.length??(plain?1:division(cell));
    if(parts<=1){cells.push(cell);indices.push(skeleton[k]);return}
    const next=skeleton[k+1]??skeleton[k],figure=cadenceSteps({from:skeleton[k],target:next,count:parts,ceiling:apex-1,least:Math.max(0,lowest-1),after:skeleton.slice(k+2),history:[...indices,skeleton[k]],choices});
    for(let j=0;j<parts;j++){
      const {at,duration}=spans?.[j]??{at:cellInterval(cell).at.add(cellInterval(cell).duration.mul(new R(j,parts))),duration:cellInterval(cell).duration.div(parts)};
      cells.push(rhythmCell(at,duration,{...cell,figure:j>0}));indices.push(j?figure[j-1]:skeleton[k]);
    }
  });
  // Notes: their times, their divisions (a note shorter than its felt beat is a divided one), the comma after the idea
  // and its repetition, the rest after the cadence.
  const notes=cells.map((cell,k)=>{
    const interval=cellInterval(cell),at=tickOf(cell.bar,interval.at),until=tickOf(cell.bar,interval.end);
    const start=at.toNumber()*tick,end=until.toNumber()*tick;
    return {scoreTime:scoreTime(at,until.sub(at),{axis:"phrase"}),id:`n${k}`,pitch:pitches[indices[k]],start,end:Math.max(start+1e-3,end),division:cell.beats<1-1e-9?Math.round(1/cell.beats):1,
      beatStart:Math.abs(cell.at-Math.round(cell.at))<1e-9,role:cell.role,...(cell.cadence?{cadence:true}:{}),...(cell.figure?{figure:true}:{}),...(cell.fill?{fill:true}:{}),
      ...(cell.core&&!cell.figure?{core:true}:{}),...(cell.source&&!cell.figure?{source:cell.source}:{}),segment:cell.segment};
  });
  const lastGroup=own.groups.at(-1),groupSeconds=timeOf(0,lastGroup.first+lastGroup.count)-timeOf(0,lastGroup.first);
  notes.forEach((note,k)=>{
    // The rest after the cadence, but in the piece's last phrase, whose tone is held to the end.
    if(note.cadence){if(!pickupSegment&&!final){
      const held=note.end-note.start,own=readScoreTime(note);
      const groupTicks=tickOf(0,Q(lastGroup.first+lastGroup.count)).sub(tickOf(0,Q(lastGroup.first)));
      const steps=Math.round(lastGroup.count*choices.restDivisions),share=new R(Math.round(choices.restShare*steps),steps);
      const rest=own.duration.mul(Q(choices.restMostShare)).min(groupTicks.mul(share));
      note.scoreTime=scoreTime(own.at,own.duration.sub(rest),{axis:'phrase'});
      // A player's minimum breath may shorten the sound further, without changing the composed rest.
      note.end-=Math.min(held*choices.restMostShare,Math.max(choices.restLeast,groupSeconds*choices.restShare));
    }return}
    if(cells[k].comma)note.end-=(note.end-note.start)*choices.commaShare;
  });
  // Its core only, where another enters over a thinner texture: its idea's core notes, then each later segment's first
  // note and its cadence, each held through the notes it leaves out up to the next it keeps (a silence among them kept),
  // so that it thins to long tones and still begins as its own. A phrase with fewer than two such notes stays whole.
  if(coreOnly){
    const first=notes[0]?.segment,keep=notes.filter((note,k)=>note.cadence||(note.segment===first?note.core||k===0:notes[k-1]?.segment!==note.segment));
    if(keep.length>=2){
      keep.forEach((note,k)=>{const next=keep[k+1];if(!next||note.cadence)return;
        const dropped=notes.filter(other=>other.start>note.start&&other.start<next.start);if(dropped.length){note.end=Math.max(note.end,dropped.at(-1).end);const own=readScoreTime(note),end=readScoreTime(dropped.at(-1)).end;note.scoreTime=scoreTime(own.at,end.max(own.end).sub(own.at),{axis:"phrase"})}});
      // A tone the next repeats, sounding into it, is held through it: long tones, never three alike.
      const tied=keep.filter((note,k)=>{const before=keep[k-1];if(!before||before.pitch!==note.pitch||note.start-before.end>1e-6)return true;before.end=note.end;const at=readScoreTime(before).at;before.scoreTime=scoreTime(at,readScoreTime(note).end.sub(at),{axis:"phrase"});if(note.cadence)before.cadence=true;keep[k]=before;return false});
      notes.splice(0,notes.length,...tied);
    }
  }
  // Dynamics: swelling to the apex and falling to the cadence, about its loudness.
  const apexNote=notes[indices.indexOf(apex)]??notes[0],peak=apexNote.start/phraseSeconds;
  for(const note of notes){
    const level=clamp(swellLevel(loudness,note.start/phraseSeconds,peak)*(note.cadence?.9:1),0,1);
    note.dynamic=choices.dynamics[Math.min(choices.dynamics.length-1,Math.floor(level*choices.dynamics.length))];note.velocity=choices.velocity[note.dynamic];
  }
  // The pickup's run: louder into more intensity, softer into less.
  const fills=notes.filter(note=>note.fill);
  fills.forEach((note,j)=>{
    const progress=fills.length>1?j/(fills.length-1):1,level=clamp(loudness*(pickupSegment.fill==='up'?.8+.45*progress:.9-.4*progress),0,1);
    note.dynamic=choices.dynamics[Math.min(choices.dynamics.length-1,Math.floor(level*choices.dynamics.length))];note.velocity=choices.velocity[note.dynamic];
  });
  // Slurs: quick notes (a divided beat) in groups of up to slurMost, never across a silence; long notes separate, but in
  // a segment slurred whole (slurSegments' share of them, each drawn only where the share is neither none nor all); a
  // pickup's run under one slur.
  const legato=clamp(Number(choices.slurSegments)||0,0,1),whole=new Set;
  if(legato>0)for(const segment of new Set(notes.map(note=>note.segment)))if(legato>=1||random()<legato)whole.add(segment);
  let slur=0,run=0;
  notes.forEach((note,k)=>{
    const before=notes[k-1],joined=before&&note.start-before.end<1e-6;
    if(whole.has(note.segment)){if(!joined||before.segment!==note.segment)slur++;note.slur=`w${slur}`;run=0;return}
    if(note.division>1&&(run===0||run>=choices.slurMost||before.division<=1||!joined)){slur++;run=0}
    if(note.division>1){note.slur=`s${slur}`;run++}else run=0;
  });
  for(const note of fills)note.slur=`p${slur+1}`;
  // A soloist's fioriture: a long note's end, up to two thirds of it, becomes a run to the next note, under one slur;
  // never the cadence's tone or a note before a silence.
  if(fioriture>0){
    for(let k=notes.length-2;k>=0;k--){
      const note=notes[k],next=notes[k+1],held=note.end-note.start;
      if(note.division!==1||note.cadence||next.start-note.end>1e-6||held<.45||random()>fioriture)continue;
      const symbolic=readScoreTime(note),spanTicks=symbolic.duration.mul(Q(choices.ornamentShare)).add(new R(1,2)).floor(),ornament=planFioritura({from:note.pitch,to:next.pitch,pool,range:register,spanTicks,tickSeconds:tick,amount:fioriture,random});
      if(!ornament)continue;
      const runAt=symbolic.end.sub(spanTicks),runStart=runAt.toNumber()*tick;
      note.end=runStart;note.scoreTime=scoreTime(symbolic.at,runAt.sub(symbolic.at),{axis:"phrase"});slur++;
      const runNotes=ornament.notes.map((step,i)=>({scoreTime:shiftScoreTime(step.scoreTime,runAt,{axis:"phrase"}),id:`${note.id}f${i}`,pitch:step.pitch,start:runStart+step.at*tick,end:runStart+(ornament.notes[i+1]?.at??spanTicks)*tick,
        dynamic:note.dynamic,velocity:note.velocity*step.velocity,role:note.role,segment:note.segment,slur:`f${slur}`,fioritura:true,
        // (Its warp how it is played, not written: `lag`, s.)
        ...(Math.abs(step.at-step.written)>1e-9?{lag:(step.at-step.written)*tick}:{})}));
      notes.splice(k+1,0,...runNotes);
    }
  }
  return {status:'planned',notes,motif:own,apex:pitches[apex],variation,lead:landing!=null?pitches[landing]:null,...(choice?{choice}:{}),...(cadenceShape?{cadence:cadenceShape}:{})};
}
