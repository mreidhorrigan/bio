import {Rational as R} from '../../transcript/rational.js';
import {scoreTime,readScoreTime} from '../score-time.js';
// A line its player improvises on, as far as its conductor allows (the owner, 4 October 2026: "a conductor should be able
// to allow performers it's conducting to improvise; and, if allowed, performers should be able to improvise on and
// ornament melodies they have been given for contrapuntal reasons"; and of what the orchestra lacked, the fast-moving
// riff of MusebotTV's first episode, riff_clodbot, and the harpsichord's fast scales, piano_clodbot's runs: "we had quite
// a lot of voice-leading involved with the jazz algorithms").
//
// Its latitude (0 to 1, its conductor's to give): at 0 the line as it was given or planned; above, the time from one of
// its notes to the next taken more and more often, and more and more of it, by a figure of the player's own, which leaves
// the note on its time and arrives at the next on its time -- a diminution, as Ortiz's and Ganassi's passaggi divide a
// given line, or a jazz player's line between a tune's guide tones. Every note of the line stays where it was, so what
// its conductor certified of the line (fugue-contracts.js) still holds of its notes; the figures' notes are the player's.
// A figure is:
//   - planned at its phrase's downbeat, from its part's seed, so a part's players play it together: which of the line's
//     spans it takes (as often as the latitude), how much of each (up to the latitude's share of it, from its end), and
//     how quickly its notes come (from one a beat to as many as the player's quickest allow, the quicker the freer: a
//     tuplet of any count the beat holds);
//   - its pitches chosen as each sounds, by the voice leading the jazz players' lines use (riff_clodbot, voice-leading-
//     bot.js): steps on its scale, from the line's note to a step beside the next, which it must reach in its notes (each
//     move chosen only where the rest can still arrive: feasible by construction); a tone of the harmony sounding then on
//     a beat, a step from the note before off it (a passing or a neighbour tone; the counterpoint texture's rule,
//     section-voices.js); clear of parallel fifths and octaves with the voices heard (sounding-voices.js; as riff_clodbot
//     weighs them); a leap of a third the likelier the freer (bebop's arpeggiation); and, the freer, its moves repeating
//     a cell of its own a step on (a riff's cell sequenced).
import {parallelsAgainst} from '../voice-leading.js';

export const IMPROVISE=Object.freeze({
  // A figure's reach into its span at a latitude of 1: its share of the span from its end, drawn between these (ours).
  reach:Object.freeze([.25,1]),
  // A riff's cell: its moves, from two to this many, repeated a step on (ours: riff_clodbot's cells are a bar's few
  // onsets).
  cell:4,
  // The costs a pitch is chosen by (ours, at riff_clodbot's scale: a step off its target 1, a parallel with a voice
  // heard 20): a leap past a step (each step more), a beat's note off the harmony, a leap to a dissonance off the beat,
  // a parallel, a move off the cell's, a step further from its target than its notes need, and a draw that breaks ties.
  costs:Object.freeze({leap:1.5,chord:2,unprepared:3,parallel:20,cell:1.5,away:1,jitter:.5}),
});

const clamp=(value,low,high)=>Math.max(low,Math.min(high,value));
const nearestIndex=(ladder,pitch)=>{let best=0;for(let k=1;k<ladder.length;k++)if(Math.abs(ladder[k]-pitch)<Math.abs(ladder[best]-pitch))best=k;return best};

// The figures over a line (`notes`: [{at, pitch, seconds, ...}], in seconds, in order) at `latitude`: for each span taken,
// {from (its note's index), onsets (s), strong (each on a beat of the meter), side (-1: the next note approached from a
// step below; 1, above), cell, perBeat}. `start`: the phrase's downbeat (s), the meter's grid's origin; `beatSeconds`:
// its notated beat; `shortest`: the shortest note its player plays (s). A figure's notes come as quickly as an
// ornament's do whatever its latitude -- from two a beat to as many as its player's shortest allows, drawn, the quicker
// the freer -- and as many as its reach of its span holds, two at least (a turn) where its span holds two, on the
// latest of the grid's positions before the next note. Five draws a span, whether it is taken or not, so that a
// latitude changed changes which spans are taken and how, never the draws of those after.
export function planFigures(notes,{latitude=0,start=0,beatSeconds,shortest,groups=null,subdivision=1,random,choices=IMPROVISE}){
  const free=clamp(Number(latitude)||0,0,1),out=[];
  if(!(free>0)||!(beatSeconds>0)||!(shortest>0)||!Array.isArray(notes))return out;
  const most=Math.max(1,Math.floor(beatSeconds/shortest+1e-9)),[least,full]=choices.reach;
  // (The meter's group starts, in beats within its bar, and its bar's beats; a beat each where it names none.)
  const sizes=Array.isArray(groups)&&groups.length&&groups.every(g=>g>0)?groups.map(Number):[1],bar=sizes.reduce((x,y)=>x+y,0),starts=sizes.map((_,k)=>sizes.slice(0,k).reduce((x,y)=>x+y,0));
  const beatOf=t=>(t-start)/beatSeconds,groupStartsNear=t=>{const b=Math.floor(beatOf(t)/bar)*bar;return [-bar,0,bar].flatMap(o=>starts.map(s=>b+o+s))};
  const onGroup=t=>groupStartsNear(t).some(g=>Math.abs(g-beatOf(t))<1e-6);
  const groupAfter=t=>start+Math.min(...groupStartsNear(t).filter(g=>g>beatOf(t)+1e-6),beatOf(t)+bar)*beatSeconds;
  const groupBefore=t=>start+Math.max(...groupStartsNear(t).filter(g=>g<beatOf(t)-1e-6),beatOf(t)-bar)*beatSeconds;
  for(let i=0;i+1<notes.length;i++){
    const [taken,reach,rate,cell,side]=[random(),random(),random(),random(),random()];
    if(taken>=free)continue;
    const a=notes[i].at,b=notes[i+1].at,span=b-a;if(!(span>2*shortest))continue;
    const perBeat=Math.min(most,Math.max(1,Math.min(2,most)+Math.floor((most-Math.min(2,most)+1)*rate**(1-free/2)))),step=beatSeconds/perBeat;
    // (Its groups its own -- the meter's groups of its beats, as its score beams and divides them, else its beats --
    // from the line's note where it falls on a group's start, else the next group's, to the next note where it falls on
    // one, else its group's start: so no group holds the figure's grid and another's, which the score would write as a
    // tuplet of their least common multiple, a 105:32.)
    const first=onGroup(a)?a:groupAfter(a),last=onGroup(b)?b:groupBefore(b);
    const grid=[],symbolic=[];for(let m=Math.ceil((Math.max(first,a+shortest)-start)/step-1e-9);start+m*step<=Math.min(last,b)-shortest+1e-9;m++){grid.push(start+m*step);symbolic.push(new R(m*subdivision,perBeat))}
    if(!grid.length)continue;
    const share=free*(least+(full-least)*reach),count=Math.min(grid.length,Math.max(2,Math.round(share*span/step))),onsets=grid.slice(-count);
    out.push({from:i,onsets,scoreOnsets:symbolic.slice(-count).map(t=>t.toString()),strong:onsets.map(t=>{const beats=(t-start)/beatSeconds;return Math.abs(beats-Math.round(beats))<1e-6}),side:side<.5?-1:1,cell:2+Math.floor(cell*(choices.cell-1)),perBeat});
  }
  return out;
}

// The line with its figures in place: each figure's note held to its figure's first onset, then the figure's notes,
// each held to the next (`articulation` of it), its pitch left to be chosen as it sounds ({figure: {id, index, count,
// target, side, cell, strong}}, pitch null).
export function figuredLine(notes,figures,{articulation=1}={}){
  const byFrom=new Map(figures.map((figure,id)=>[figure.from,{...figure,id}])),out=[];
  for(const [i,note] of notes.entries()){
    const figure=byFrom.get(i);
    if(!figure){out.push(note);continue}
    const next=notes[i+1].at,times=[...figure.onsets,next];
    const own=note.scoreTime?readScoreTime(note):null,points=own?[...figure.scoreOnsets.map(t=>R.of(t)),readScoreTime(notes[i+1]).at]:null;
    // (Each its written length too: the note before as far as the figure, each figure's note to the next.)
    const written=Number.isFinite(note.written)?note.written:note.seconds/articulation;
    out.push({...note,...(own?{scoreTime:scoreTime(own.at,own.end.min(points[0]).sub(own.at),{axis:own.axis})}:{}),seconds:Math.min(note.seconds,(figure.onsets[0]-note.at)*articulation),written:Math.min(written,figure.onsets[0]-note.at)});
    figure.onsets.forEach((at,index)=>out.push({at,...(own?{scoreTime:scoreTime(points[index],points[index+1].sub(points[index]),{axis:own.axis})}:{}),pitch:null,seconds:(times[index+1]-at)*articulation,written:times[index+1]-at,...(note.peak!=null?{peak:note.peak}:{}),
      figure:{id:figure.id,index,count:figure.onsets.length,target:notes[i+1].pitch,from:note.pitch,side:figure.side,cell:figure.cell,strong:figure.strong[index]}}));
  }
  return out;
}

// A figure's next pitch, as it sounds. `ladder`: its scale's pitches over its player's compass, low to high; `state`:
// the figure's so far ({previous, moves}, kept by its caller, null at its first note); `chord`: the harmony's tones
// sounding (pitches); `othersFrom`/`othersTo`: the voices heard, from the sonority before to now (sounding-voices.js
// pairs). -> {pitch, state}. Its last note a step beside its target, approached from its side where its scale has one
// there, else the other; every move one from which the rest can still arrive.
export function figurePitch(note,{ladder,state=null,chord=[],othersFrom=[],othersTo=[],latitude=0,random,choices=IMPROVISE}){
  const {figure}=note,free=clamp(Number(latitude)||0,0,1),{costs}=choices;
  if(!ladder?.length)return {pitch:figure.from,state};
  const previous=state?.previous??figure.from,moves=state?.moves??[],p=nearestIndex(ladder,previous),b=nearestIndex(ladder,figure.target),left=figure.count-figure.index;
  // (Its target: a step beside the next note on its side, else the other; where its last note would be the one it leaves,
  // the other side, else two steps off.)
  const sides=[b+figure.side,b-figure.side,b+2*figure.side,b-2*figure.side].filter(k=>k>=0&&k<ladder.length&&k!==b);
  const t=(left===1?sides.find(k=>k!==p):sides[0])??b;
  // (A tone of the harmony: within a quarter tone of one of its classes.)
  const classes=chord.map(Number).filter(Number.isFinite).map(pitch=>((pitch%12)+12)%12);
  const isTone=pitch=>{const pc=((pitch%12)+12)%12;return classes.some(tone=>{const d=Math.abs(tone-pc);return Math.min(d,12-d)<.25})};
  // (Its moves: as far as a step or a third, or as far as its target needs at its notes left; the last onto its target,
  // the one before off it.)
  const reach=Math.max(2,Math.ceil(Math.abs(t-p)/left)),candidates=[];
  for(let m=-reach;m<=reach;m++){
    const q=p+m;if(m===0||q<0||q>=ladder.length)continue;
    if(left===1?q!==t:left===2?q===t:false)continue;
    candidates.push({m,q});
  }
  if(!candidates.length)return {pitch:ladder[p],state:{previous:ladder[p],moves:[...moves,0]}};
  const cost=({m,q})=>{
    const pitch=ladder[q],tone=isTone(pitch),leap=Math.abs(m)>1;
    let c=costs.leap*Math.max(0,Math.abs(m)-1)*(1-free/2);
    if(figure.strong&&!tone)c+=costs.chord*(1-free/2);
    if(!figure.strong&&leap&&!tone)c+=costs.unprepared;
    c+=costs.parallel*parallelsAgainst([previous],[pitch],othersFrom,othersTo).length;
    if(moves.length>=figure.cell&&m!==moves[moves.length-figure.cell])c+=costs.cell*free;
    c+=costs.away*Math.max(0,Math.abs(t-q)-(left-1));
    return c+costs.jitter*random();
  };
  const chosen=candidates.map(candidate=>({...candidate,cost:cost(candidate)})).sort((x,y)=>x.cost-y.cost)[0];
  return {pitch:ladder[chosen.q],state:{previous:ladder[chosen.q],moves:[...moves,chosen.m]}};
}

// A line's scale over [low, high]: `collection`'s pitches (collection-space.js collectionPitches, its region's, where
// its conductor gives one), each within a quarter tone of a tone of `chord` (the harmony heard, as the band tunes it)
// that tone, and the chord's own tones beside them; low to high.
export function scaleLadder({collection=[],chord=[],low,high}){
  const tones=chord.map(Number).filter(Number.isFinite),out=new Map,classOf=pitch=>((pitch%12)+12)%12;
  // (The signed distance from one class to another, the short way round.)
  const toward=(from,to)=>{const d=classOf(to)-classOf(from);return d>6?d-12:d<=-6?d+12:d};
  const put=pitch=>{if(pitch>=low-1e-9&&pitch<=high+1e-9)out.set(+pitch.toFixed(4),+pitch.toFixed(6))};
  for(const pitch of collection){const tone=tones.find(t=>Math.abs(toward(pitch,t))<.25);put(tone==null?pitch:pitch+toward(pitch,tone))}
  for(let octave=0;octave<=10;octave++)for(const tone of tones)put(12*octave+classOf(tone));
  return [...out.values()].sort((x,y)=>x-y);
}
