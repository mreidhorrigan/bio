// The extended techniques a player may choose, and how each is named on the page (the owner, 8 October 2026: "include
// extended techniques to the extent possible, such as wind multiphonics (from both fingering changes and humming through
// the instrument while playing), brass mutes, growls (including where produced by humming), et cetera"; and "see whether
// we can model bow pressure from flautando to overpressure"). A technique is its player's choice -- its section's role,
// drawn with its phrase, its extremes an extreme of its other things -- never a spec's hand. It reaches the sound through
// the audio engine: a physical model realizes it offline (physical-strings.js, render/synthesis); elsewhere the note
// plays ordinarily and the engine says so. And it reaches the score through the capture (capture.js), as words or marks.
//
// Every technique's parameter is a place in a continuum, every place between two of its states a state of its own
// (CLAUDE.md, "Everything is interpolable"); its words name bands of it.

import {instrumentRange} from './instrument-ranges.js';
// The woodwinds' fingered multiphonics, measured on OpenWInD: each a cross-fingering of its instrument's keys on a
// designed body with tone holes (the clarinet's render/synthesis/tools/design_openwind_clarinet.py, the flute's, oboe's
// and bassoon's design_openwind_woodwind.py), its strong spectral peaks heard as several pitches.
// (Their ids, peaks and keys alone, from the bodies: scripts/wind-multiphonics.mjs.)
import WIND from './wind-multiphonics.json' with {type:'json'};

// ---- Which techniques a composition allows, and how much each player wants them ----------------------------------
// The owner, 8 October 2026: "Make the availability of each extended technique configurable per composition settings,
// with the default being yes; and make configurable whether each player, with all other things being equal, WANTS to
// use them." A composition's `techniques` (its spec's, or a section's own over it):
//   available  {technique: false} -- one it never plays; every one allowed where it says nothing.
//   want       {technique: number} -- the band's appetite for it, 1 as its sections' shares say, 0 never, 2 twice as
//              often (each share capped at every phrase).
//   players    {seat | section | instrument: {technique: number}} -- a player's own appetite over the band's (a seat
//              'cl.1', its section's 'cl', its instrument's 'clarinet'; the nearest named counts).
// A section draws a technique for a phrase at its share times its keenest player's appetite (poolWant); each player in
// the phrase then takes it up as its own appetite is to that keenest one's (takesUp) -- all other things being equal,
// the keener player uses it more.
export const EXTENDED_TECHNIQUES=Object.freeze(['pressure','contact','harmonic','multiphonic','hum','growl','flutter','mute']);
export function techniquesOf(...given){
  const out={available:{},want:{},players:{}};
  for(const config of given){
    if(!config)continue;
    if(typeof config!=='object')throw new TypeError('techniques is {available, want, players}');
    for(const [technique,on] of Object.entries(config.available??{})){if(!EXTENDED_TECHNIQUES.includes(technique))throw new RangeError(`techniques.available: ${technique} is not one of ${EXTENDED_TECHNIQUES.join(', ')}`);out.available[technique]=Boolean(on)}
    for(const [technique,want] of Object.entries(config.want??{})){if(!EXTENDED_TECHNIQUES.includes(technique)||!(Number(want)>=0))throw new RangeError(`techniques.want: ${technique} wants a number from 0`);out.want[technique]=Number(want)}
    for(const [player,wants] of Object.entries(config.players??{})){
      out.players[player]={...out.players[player]};
      for(const [technique,want] of Object.entries(wants??{})){if(!EXTENDED_TECHNIQUES.includes(technique)||!(Number(want)>=0))throw new RangeError(`techniques.players.${player}: ${technique} wants a number from 0`);out.players[player][technique]=Number(want)}
    }
  }
  return Object.freeze({available:Object.freeze(out.available),want:Object.freeze(out.want),players:Object.freeze(Object.fromEntries(Object.entries(out.players).map(([k,v])=>[k,Object.freeze(v)])))});
}
// A player's appetite for a technique: none where the composition does not allow it; else the band's times its own,
// its own the nearest named of its seat, its section and its instrument. `seat`: {id, section?, instrument?}.
export function wantOf(config,seat,technique){
  if(!config)return 1;
  if(config.available?.[technique]===false)return 0;
  const id=String(seat?.id??seat?.seat??''),section=seat?.section??id.split('.')[0],own=[id,section,seat?.instrument].map(key=>config.players?.[key]?.[technique]).find(Number.isFinite);
  return (config.want?.[technique]??1)*(own??1);
}
// A pool's appetite: its keenest player's. -> 0 where none of them may.
export const poolWant=(config,seats,technique)=>seats.length?Math.max(...seats.map(seat=>wantOf(config,seat,technique))):wantOf(config,null,technique);
// Whether a player takes up a technique its phrase has: as its own appetite is to its pool's keenest, by its own draw.
export function takesUp(config,seat,technique,keenest,draw){
  const own=wantOf(config,seat,technique);
  if(!(own>0))return false;
  return !(keenest>own)||draw()<own/keenest;
}

// ---- Bow pressure ---------------------------------------------------------------------------------------------------
// -1 flautando (a light, fast bow toward the fingerboard: the string still in Helmholtz motion, its fundamental strong,
// few upper partials), 0 ordinario, 1 overpressure (pressed past the most force Schelleng's window allows at its bow's
// place and speed, the string's motion no longer periodic: a scratch). Schelleng 1973, "The bowed string and the player",
// JASA 53(1), 26-41, doi:10.1121/1.1913322. Its sound on the strings' model: physical-strings.js MODEL.pressure, measured
// (scripts/calibrate-strings-model.mjs --pressure).
export const pressureOf=value=>{const p=Number(value);return Number.isFinite(p)?Math.max(-1,Math.min(1,p)):0};
// Its words, each band from its least pressure (ours, as string writing names them): none between the flautando's and
// the pressing's bands.
export const PRESSURE_WORDS=Object.freeze([[.75,'overpressure'],[.35,'molto pressione'],[-.35,null],[-Infinity,'flaut.']]);
export const pressureWords=value=>{const p=pressureOf(value);return PRESSURE_WORDS.find(([least])=>p>=least)[1]};

// (The voice a wind player hums in: the registry's two breath-model voices together, low and high.)
const HUMMED=Object.freeze([instrumentRange('voice-low').register[0],instrumentRange('voice-high').register[1]]);

// ---- A string player's natural harmonics -------------------------------------------------------------------------
// A pool's natural harmonics (its spec's `pool.harmonic`: {share, most}): for `share` of its phrases, toward its softest
// (as far as its level falls under `most`), each note sounded as its string's second or third partial, touched lightly at
// its node -- on the strings' model at the contacts measured for each instrument and string (physical-strings.js,
// physical-harmonics-calibration.json), the string retuned to the note's microtone; never a plucked note. -> {kind:
// 'natural', partial} or null.
export function harmonicFor(pool,{share=0,most=.3}={},draw){
  if(!(draw()<share))return null;
  const level=Math.max(0,Math.min(1,Number(pool.level)||0));if(level>most)return null;
  return {kind:'natural',partial:draw()<.5?2:3};
}

// ---- A string player's multiphonics ---------------------------------------------------------------------------------
// A pool's multiphonics (its spec's `pool.multiphonic`: {share}): for `share` of its phrases, whatever their level, each
// note played as a multiphonic -- a light finger off the string's nodes, its bands of partials heard as several pitches
// (Guettler and Thelin 2012, doi:10.1121/1.3651251) -- the one its seat chooses at the note among its instrument's
// measured ones by the harmony it hears (physical-strings.js multiphonicNear), by this draw. Never with a natural harmonic
// (a soft phrase's, which goes first); never plucked. -> {choice} or null.
export const MULTIPHONIC_WORD='mult.';
export function multiphonicFor(pool,{share=0}={},draw){
  if(!(draw()<share))return null;
  return {choice:+draw().toFixed(4)};
}
// A seat's multiphonic among its instrument's measured ones (`candidates`: [{pitches, dynamics?, ...}], each sounding
// at its own pitches): those whose lowest lies in its compass; those held at its phrase's `dynamic` first (where they
// say); then by how near their pitches lie to the harmony heard (`pool`, MIDI, any octave, every microtone its own) and
// their lowest to the note asked (an octave as far as a semitone off the harmony); `choice`, its phrase's draw (0 to 1),
// one of the MULTIPHONIC_FIT that fit best (ours). -> the candidate, or null where none lies in its compass.
export const MULTIPHONIC_FIT=3;
export function multiphonicAmong(candidates,choice,pitch,{compass=[-Infinity,Infinity],pool=[],dynamic=null}={}){
  const heard=pool.filter(Number.isFinite);
  const off=q=>heard.length?Math.min(...heard.map(p=>{const d=(((q-p)%12)+12)%12;return Math.min(d,12-d)})):0;
  const ranked=candidates.map((candidate,order)=>({candidate,order,holds:!candidate.dynamics||candidate.dynamics.includes(dynamic)?1:0,lowest:candidate.pitches[0]}))
    .filter(c=>c.lowest>=compass[0]-1e-9&&c.lowest<=compass[1]+1e-9)
    .map(c=>({...c,fit:c.candidate.pitches.reduce((sum,q)=>sum+off(q),0)/c.candidate.pitches.length+Math.abs(c.lowest-pitch)/12}))
    .sort((a,b)=>b.holds-a.holds||a.fit-b.fit||a.order-b.order).slice(0,MULTIPHONIC_FIT);
  if(!ranked.length)return null;
  return ranked[Math.min(ranked.length-1,Math.floor(Math.max(0,Math.min(1,Number(choice)||0))*ranked.length))].candidate;
}
// A wind player's fingered multiphonics, by instrument: each woodwind's measured ones, each its id, its strong peaks'
// pitches, lowest first (MIDI), and its keys as LilyPond's woodwind diagram names them (the score's diagram:
// lilypond.js); none for the brass, whose multiphonics are hummed.
const measuredOf=(instrument,measured)=>Object.freeze((measured??[]).map(m=>Object.freeze({id:m.id,
  pitches:Object.freeze(m.peaks.map(hz=>+(69+12*Math.log2(hz/440)).toFixed(4)).sort((a,b)=>a-b)),
  diagram:Object.freeze({instrument,keys:m.keys})})));
export const WIND_MULTIPHONICS=Object.freeze(Object.fromEntries(Object.entries(WIND.instruments).map(([instrument,measured])=>[instrument,measuredOf(instrument,measured)])));
// The fingered multiphonic a wind seat plays in place of a note, where its phrase plays them (multiphonicAmong). ->
// {id, pitches, diagram}, or null where its instrument has none in its compass.
export function windMultiphonicNear(choice,pitch,{instrument,compass,pool}={}){
  const found=multiphonicAmong(WIND_MULTIPHONICS[instrument]??[],choice,pitch,{compass,pool});
  return found?{id:found.id,pitches:[...found.pitches],diagram:found.diagram}:null;
}

// ---- A wind player's techniques -------------------------------------------------------------------------------------
// Each a forcing of the breath the reed, lips or jet answers through the bore (render/synthesis/workers/openwind_worker.py):
//   hum      the player hums while playing -- its voice a pressure source at its pitch, the bore's note and the voice's
//            beating, summing and differencing as the reed makes them: a multiphonic by voice. Soft: toward a pool's
//            softest.
//   growl    a hum made rough, the period doubled and breath noise with it: a growl's rasp. Loud: toward its loudest.
//   flutter  flutter-tonguing, the tongue's roll closing the breath off some 20 to 30 times a second. Loud, as a growl.
// Words for the page (ours, as wind writing names them).
export const WIND_TECHNIQUE_WORDS=Object.freeze({hum:'hum',growl:'growl',flutter:'flz.',mute:null,multiphonic:MULTIPHONIC_WORD});
// A pool's wind technique (its spec's `pool.technique`: {share, least, skew}), drawn with its phrase as its pressure is:
// for `share` of its phrases, where its level reaches past `least` from the middle -- a hum under it, a growl or a
// flutter over it -- each technique's own parameters drawn too, every value between its ends a state of its own.
// -> {kind, interval?, level?, rough?, hz?, depth?} or null.
// (`wants`: each kind's appetite, techniques.js poolWant -- a kind wanted by none never drawn, a loud phrase's growl or
// flutter drawn as their appetites weigh them.)
export function windTechniqueFor(pool,{share=0,least=.5,skew=1,wants={hum:1,growl:1,flutter:1}}={},draw){
  if(!(draw()<share))return null;
  const level=Math.max(0,Math.min(1,Number(pool.level)||0)),reach=Math.abs(2*level-1);if(reach<=least)return null;
  const far=least+(reach-least)*draw()**skew;
  if(level<.5)return wants.hum>0?windTechniqueOf('hum',far,draw):null;
  const growl=Math.max(0,wants.growl??1),flutter=Math.max(0,wants.flutter??1);if(!(growl+flutter>0))return null;
  return windTechniqueOf(draw()<growl/(growl+flutter)?'growl':'flutter',far,draw);
}
// A wind technique of its kind ('hum', 'growl' or 'flutter'), `far` (0 to 1) how far it goes, its parameters drawn: a
// pool's (windTechniqueFor), or one a score names (musicxml-performer.js). -> {kind, interval?, level?, rough?, hz?, depth?}.
// (The hummed note an interval under the played one -- a fifth to an octave and a fourth, drawn -- its swing in the
// breath as far as it goes.)
export function windTechniqueOf(kind,far,draw){
  if(kind==='hum')return {kind:'hum',interval:-(7+10*draw()),level:+(.1+.25*far).toFixed(3)};
  if(kind==='growl')return {kind:'growl',interval:-(11+2*draw()),level:+(.2+.3*far).toFixed(3),rough:+(.3+.6*far).toFixed(3)};
  if(kind==='flutter')return {kind:'flutter',hz:+(20+10*draw()).toFixed(2),depth:+(.4+.5*far).toFixed(3)};
  throw new RangeError(`No wind technique ${kind}: hum, growl or flutter`);
}
// A brass pool's mute (its spec's `pool.mute`: {share, kinds}): a colour for `share` of its phrases, whatever their
// level, its kind drawn among `kinds` -- a straight or cup mute, a harmon with its stem in or out, a horn's stopping
// hand -- each modelled in its instrument's bore on NESS's brass (render/synthesis/src/ness.mjs). -> its kind, or null.
export const MUTE_WORDS=Object.freeze({straight:'con sord. (straight)',cup:'con sord. (cup)','harmon-stem-in':'harmon mute (stem in)',
  'harmon-stem-out':'harmon mute (stem out)',stopped:'stopped (+)',off:'senza sord.'});
export function muteFor(pool,{share=0,kinds=['straight','cup']}={},draw){
  if(!(draw()<share)||!kinds.length)return null;
  return kinds[Math.min(kinds.length-1,Math.floor(draw()*kinds.length))];
}
// The mutes each brass instrument has (its player's kit, as ness.mjs models them); a phrase's mute fitted to a player's:
// its own where it has it, a horn's stopping hand for a harmon's or cup's bright closed colour, else its straight mute.
// -> the kind it plays, or null where it has none.
export const MUTES_OF=Object.freeze({trumpet:Object.freeze(['straight','cup','harmon-stem-in','harmon-stem-out']),
  trombone:Object.freeze(['straight','cup','harmon-stem-in','harmon-stem-out']),horn:Object.freeze(['straight','stopped']),tuba:Object.freeze(['straight'])});
export function muteFitted(instrument,kind){
  const own=MUTES_OF[instrument]??[];
  if(!kind||!own.length)return null;
  if(own.includes(kind))return kind;
  if(own.includes('stopped')&&/^(harmon|cup)/.test(kind))return 'stopped';
  return own.includes('straight')?'straight':null;
}
// What a note plays of its role's technique (wind-seat.js): the hummed pitch its interval under the note, folded into the
// player's voice (the registry's breath-model voices together, instrument-ranges.js) and drawn to the nearest pitch of the
// harmony heard (`pool`, MIDI) within a semitone and a half. -> the engine's `extended` ({hum: {hz, level}} ...) or null.
export function windTechniqueAt(technique,pitch,{pool=[],voice=HUMMED,mute=null}={}){
  const muted=mute?{mute:{kind:mute}}:{};
  if(!technique)return mute?muted:null;
  if(technique.kind==='flutter')return {flutter:{hz:technique.hz,depth:technique.depth},...muted};
  let sung=pitch+technique.interval;while(sung<voice[0])sung+=12;while(sung>voice[1])sung-=12;
  const near=pool.flatMap(p=>[-24,-12,0,12,24].map(o=>{const c=((p%12)+12)%12;return Math.floor(sung/12)*12+c+o}))
    .filter(p=>Math.abs(p-sung)<=1.5).sort((a,b)=>Math.abs(a-sung)-Math.abs(b-sung))[0];
  const hz=+(440*2**(((near??sung)-69)/12)).toFixed(3);
  return {...(technique.kind==='hum'?{hum:{hz,level:technique.level}}:{growl:{hz,level:technique.level,rough:technique.rough}}),...muted};
}
