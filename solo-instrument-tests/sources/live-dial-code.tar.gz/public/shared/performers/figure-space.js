// The figure space (docs/FIGURE_SPACE.md): every figure a line divides a held note into, approaches its cadence by, or
// ornaments a note with -- a run, an arc, an arpeggio, a trill, a turn, a mordent, a climb, a zigzag, a ribattuta, a
// compound melody, and every figure between or beyond them -- a point among ten dimensions, each a share 0 to 1 (the
// owner, 5 November 2026: "(1) generalization of logic without losing cases, similar to what we're pursuing with
// parameterization over hardcoding; (2) extensibility to arbitrary and invented ornaments beyond the specific figures
// listed; and (1.1) consolidation of rules where possible"). Each named figure is a location of ranges within them (the
// registry's figure-<name> methods: registry/method/melody.json); a player's taste is a location too, and the figure it
// plays a point drawn within it. A figure is made in two steps:
//   - **its path** (figurePath): the ideal its point describes, in its voice's pitches -- the way from the held note to
//     the next, the notes to spare spent as its point says: struck again, circling a note in pairs (in place, a trill or
//     a turn; moving on, a climb), turning back behind the held note and arcing past the next (fioritura.js), its moves
//     by thirds -- or walking among voices far enough apart, at its rate, to be heard as voices (streams.js: a compound
//     melody, the owner's "ornamentation -> arpeggiated polyphony spectrum");
//   - **its notes** (figureWalk): the walk nearest that path that keeps the melody's rules (melody-rules.js), a trill
//     only where its path asks for one and a move between voices none of the line's own. Feasible by construction: a
//     search over the walks that keep them (a beam), its rules let go one by one, in order, only where none does.
import {METHODS,setting} from '../../../registry/registry.js';
import {styleSpace} from '../style-space.js';
import {ALIKE_MOST,melodyRules,runAtStart,trillSpans,trillsIn} from './melody-rules.js';
import {gapOf,heardApart,streamingInterval} from './streams.js';

const THIRD=setting('figure-space','third');
const BEAM=setting('figure-space','beam');
const JITTER=setting('figure-space','jitter');
const SKEW=setting('figure-space','skew');
const SKEWED=new Set(setting('figure-space','skewed'));
const PAIR=setting('figure-space','pair');
const VOICE_NOTES=setting('figure-space','voiceNotes');

export const FIGURE_DIMENSIONS=Object.freeze({
  lead:'of its excursion beyond the way, the share turning back behind the held note; the rest arcs past the next note',
  circling:'of its notes to spare, the share spent circling a note in pairs, out and back',
  trilling:'how often a circling pair keeps to the side of the pair before (0: each the other side, a turn; 1: a trill)',
  order:'which side it circles first, and which way it cycles among its voices (below a half: up)',
  progress:'of its circling pairs, the share moving on along the way as they circle (a climb), the rest circling in place',
  width:'how wide a circling pair goes: 0 a step, 1 a third',
  placement:'where along its way its circling comes: 0 at its start, 1 at its end',
  stride:'of its path\'s moves, the share by thirds (an arpeggio)',
  repeat:'of its notes to spare, the share struck again (a ribattuta), each note twice at most',
  voices:'how many voices it walks among: 0 one (a line), 1 as many as its notes, its range and its rate allow (a compound melody)',
});
const NAMES=Object.freeze(Object.keys(FIGURE_DIMENSIONS));
export const FIGURE_NAMES=Object.freeze(Object.keys(METHODS).filter(id=>id.startsWith('figure-')&&id!=='figure-space').map(id=>id.slice('figure-'.length)));
const asRange=value=>Array.isArray(value)?[...value]:[value,value];
// Every location a range in every dimension: a named figure's, a blend's, or a taste given whole.
export const FIGURE_SPACE=styleSpace({name:'figure',dimensions:FIGURE_DIMENSIONS,
  locations:Object.fromEntries(FIGURE_NAMES.map(name=>[name,Object.fromEntries(NAMES.map(key=>[key,asRange(setting(`figure-${name}`,key))]))]))});
// The whole space: every figure.
const EVERY=Object.freeze(Object.fromEntries(NAMES.map(key=>[key,Object.freeze([0,1])])));

const clamp=(x,low,high)=>Math.max(low,Math.min(high,x));
// A figure drawn within a taste (a location in the space, or none: every figure): one share in each dimension, in its
// order, within the taste's range there -- its circling, its notes struck again and its voices skewed toward their least
// (the registry's skew), so that most figures circle little, repeat little and keep to one voice. -> a point
// {dimension: share}.
export function drawFigure(taste,random){
  const ranges=taste==null?EVERY:FIGURE_SPACE.locate(taste);
  return Object.freeze(Object.fromEntries(NAMES.map(key=>{
    const [low,high]=ranges[key],draw=random();
    return [key,low+(high-low)*(SKEWED.has(key)?draw**SKEW:draw)];
  })));
}
// A taste in figures (a player's: personality.js): in each dimension, in its order, a range `width(draw)` wide about a
// centre drawn as a figure's share is (skewed where its dimension is), within 0 to 1. Two draws a dimension, every one
// taken. -> {dimension: [low, high]}, a location in the space.
export function drawTaste(random,width){
  return Object.freeze(Object.fromEntries(NAMES.map(key=>{
    const draw=random(),wide=clamp(width(random()),0,1),centre=SKEWED.has(key)?draw**SKEW:draw,low=clamp(centre-wide/2,0,1-wide);
    return [key,Object.freeze([+low.toFixed(6),+(low+wide).toFixed(6)])];
  })));
}
// A named figure's point: each dimension the middle of its range, or `at` where given ({dimension: share}).
export function figurePoint(name,at={}){
  const ranges=FIGURE_SPACE.locate(name);
  return Object.freeze(Object.fromEntries(NAMES.map(key=>[key,at[key]??(ranges[key][0]+ranges[key][1])/2])));
}

// The voices a compound figure walks among, where its point asks for more than one and its material holds them: as many
// as its share of the most its notes (two each, the held note one of them), its range and its rate allow, cycled up
// through them or down (`order`), the held note's voice the one that leaves them least to move to land the last note's on
// the next. Each voice moves evenly, so many steps at a note (its drift), and stands apart from the next by enough of
// its pitches that, as it drifts, the next voice's notes between its own are heard apart from it (streams.js: past the
// streaming interval at the gap from a voice's note to its next) while its own moves are not. -> {count, spacing, cycle,
// held, landing} or null.
function voicesOf({from,to,moves,low,high,point,pitches,seconds,sounding}){
  if(!(point.voices>0)||!pitches?.length||!(seconds>0))return null;
  const top=Math.min(high,pitches.length-1),cycle=point.order<1/2?1:-1;
  // (The least and the most interval `step` of the range's pitches spans.)
  const spans=step=>{let least=Infinity,most=0;for(let i=low;i+step<=top;i++){const d=pitches[i+step]-pitches[i];least=Math.min(least,d);most=Math.max(most,d)}return {least,most}};
  // (`count` voices placed: the fewest steps apart they are heard apart at, then the held note's voice that moves them
  // least, every voice's first and last note in the range but the held note and the landing.)
  const placed=count=>{
    const heard=streamingInterval(count*seconds-(sounding??seconds)),notes=Math.floor((moves+1)/count);
    for(let spacing=1;spacing<=top-low;spacing++){
      let best=null;
      for(let held=0;held<count;held++){
        const landing=((held+cycle*moves)%count+count)%count,start=from-held*spacing,end=to-landing*spacing;
        const drift=Math.ceil(Math.abs(end-start)/Math.max(1,notes-1));
        if(drift&&!(spans(drift).most<=heard))continue;
        if(!(spacing-drift>=1&&spans(spacing-drift).least>heard))continue;
        let fits=true;
        for(let voice=0;voice<count&&fits;voice++){
          if(voice!==held&&(start+voice*spacing<low||start+voice*spacing>top))fits=false;
          if(voice!==landing&&(end+voice*spacing<low||end+voice*spacing>top))fits=false;
        }
        // (Its voices moving: held all, they are two notes or more alternating, a tremolo, not a compound melody.)
        if(fits&&end!==start&&(!best||Math.abs(end-start)<best.motion))best={count,spacing,cycle,held,landing,motion:Math.abs(end-start)};
      }
      if(best)return best;
    }
    return null;
  };
  // (More than one, each with its fewest notes.)
  let most=1;
  for(let count=most+1;count*VOICE_NOTES<=moves+1;count++)if(placed(count))most=count;
  const count=1+Math.round(clamp(point.voices,0,1)*(most-1));
  return count>1?placed(count):null;
}
function compoundPath({from,to,moves,voices:{count,spacing,cycle,held,landing}}){
  const start=from-held*spacing,end=to-landing*spacing,voiceOf=k=>((held+cycle*k)%count+count)%count;
  const notes=Array.from({length:count},(_,voice)=>[...Array(moves+1).keys()].filter(k=>voiceOf(k)===voice));
  const path=[];
  for(let k=1;k<=moves;k++){
    const voice=voiceOf(k),own=notes[voice],j=own.indexOf(k),first=start+voice*spacing,last=end+voice*spacing;
    path.push(own.length>1?first+Math.round(j*(last-first)/(own.length-1)):first);
  }
  path[moves-1]=to;
  return {path,apart:new Set(path.map((_,k)=>k+1))};
}

// A plain figure's path: the way from `from` to `to` (indices into its voice's pitches) in `moves` moves within [low,
// high], its notes to spare spent as `point` says. Too few moves for the way, it skips evenly. Else, of the notes to
// spare: `repeat` of them struck again; `circling` of the rest in pairs (each pair in place two of them, a pair moving
// on one, as it takes a step of the way), `width` wide, at `placement` along the way, the first to the side `order`
// says and each the other side but as often as `trilling`; the moves left walk the way by steps and `stride` of them
// thirds, its excursion (a turn's worth of notes) turning back behind the held note as far as `lead` and arcing past
// the next note the rest. Where the range stops the one, the other takes it; where it stops both, the excursion walks
// by steps, and what the range still cannot hold folds back from the arc's height and up again, each fold as wide as
// the range lets it go (a wave across the range: a trill only where it holds no more than a step). A note struck again
// where the walk turns: the dip, the arc's height, else the held note, then along the way. -> {path, chosen: [the
// moves its circling trills by, as figurePath counts them]}.
function plainPath({from,to,moves,low,high,point}){
  const distance=Math.abs(to-from),direction=to>=from?1:-1,share=key=>clamp(point[key],0,1);
  if(moves<distance)return {path:Array.from({length:moves},(_,k)=>from+direction*Math.round((k+1)*distance/moves)),chosen:[]};
  // (Its repeats each a note of its walk's or the held note, struck twice at most: never more than half its moves.)
  const most=Math.floor(moves/2),spare=moves-distance,width=1+Math.round(share('width')*(THIRD-1)),repeated=Math.min(Math.round(share('repeat')*spare),most);
  let pairs=Math.round(share('circling')*(spare-repeated)/(PAIR-share('progress')));
  let onward=Math.min(Math.round(share('progress')*pairs),distance);
  while(pairs>0&&PAIR*pairs-onward>spare-repeated){pairs--;onward=Math.min(onward,pairs)}
  const way=distance-onward;
  // (Its walk: the moves left, its thirds, its repeats, and the excursion they leave beyond the way -- made whole by a
  // third the less, or a note more struck again, or where it has its most, one the less.)
  const plan=stride=>{
    let walking=moves-repeated-PAIR*pairs,thirds=Math.round(stride*walking),repeats=repeated;
    if((walking+thirds*(THIRD-1)-way)%PAIR){if(thirds&&(THIRD-1)%PAIR)thirds--;else if(repeats<most||!repeats){repeats++;walking--}else{repeats--;walking++}}
    return {walking,repeats,thirds,excursion:(walking+thirds*(THIRD-1)-way)/PAIR};
  };
  // (Its excursion placed: behind as far as `lead` and the range allow, past the next note the rest; what the arc
  // cannot hold turned back further, what neither can left over. The room behind the held note and past the next is
  // the range's on that side, none where the note stands beyond it.)
  const behind=Math.max(0,direction>0?from-low:high-from),past=Math.max(0,direction>0?high-to:to-low);
  const place=excursion=>{
    const back=clamp(Math.round(share('lead')*excursion),0,behind),beyond=clamp(excursion-back,0,past);
    const deeper=clamp(excursion-back-beyond,0,behind-back);
    return {dip:from-direction*(back+deeper),apex:to+direction*beyond,left:excursion-back-beyond-deeper};
  };
  let walk=plan(share('stride')),shape=place(walk.excursion);
  if(shape.left&&walk.thirds){walk=plan(0);shape=place(walk.excursion)}
  const {dip,apex,left:edge}=shape;
  // The legs: out behind the held note, along to the arc's height (its circling within it), back to the next note --
  // the walk's moves shared among them by their lengths, every leg with a way to go at least one.
  const legs=[{from,to:dip,onward:0},{from:dip,to:apex,onward},{from:apex,to,onward:0}];
  const units=legs.map(leg=>Math.abs(leg.to-leg.from)-leg.onward),total=units.reduce((sum,u)=>sum+u,0),walking=walk.walking-PAIR*edge;
  const counts=units.map(u=>total?Math.floor(walking*u/total):0);
  const remainders=units.map((u,i)=>i).sort((a,b)=>(walking*units[b]/total-counts[b])-(walking*units[a]/total-counts[a]));
  for(let r=walking-counts.reduce((sum,c)=>sum+c,0),i=0;total&&r>0;r--,i++)counts[remainders[i%remainders.length]]++;
  units.forEach((u,i)=>{if(u>0&&!counts[i]){const j=counts.reduce((best,c,k)=>c>counts[best]?k:best,0);if(counts[j]>1){counts[j]--;counts[i]++}}});
  // (Each note of its path, and whether its circling put it there.)
  const path=[],circled=[];let at=from,moved=0,dipAt=-1,apexAt=-1;
  const put=(index,circling=false)=>{path.push(index);circled.push(circling)};
  const position=(leg,count)=>k=>leg.from+(Math.sign(leg.to-leg.from)||direction)*Math.round(k*(Math.abs(leg.to-leg.from)-leg.onward)/count);
  // (Its circling pairs, where they come: in place to a side, the first to `order`'s, each to the other side but where
  // `trilling` keeps it -- that share of them, evenly among them; or moving on a step.)
  const circle=()=>{
    let side=share('order')<1/2?1:-1;
    for(let i=0;i<pairs;i++){
      if(i&&!(Math.floor(i*share('trilling'))>Math.floor((i-1)*share('trilling'))))side=-side;
      if(Math.floor((i+1)*onward/pairs)>Math.floor(i*onward/pairs)){put(at+direction*(width+1),true);put(at+direction,true);at+=direction;moved++}
      else{const s=at+side*width<low||at+side*width>high?-side:side;put(at+s*width,true);put(at,true)}
    }
  };
  // (What the range cannot hold, in pairs of moves: folds back from the arc's height toward the dip and up again, as
  // few as the range allows, their widths as even as they can be -- a fold of one pair a third down and back, where the
  // range holds one, not a step's trill.)
  const fold=()=>{
    const span=Math.max(1,Math.abs(apex-dip)),folds=Math.ceil(edge/span);
    for(let f=0;f<folds;f++){
      const wide=Math.floor((f+1)*edge/folds)-Math.floor(f*edge/folds);
      if(wide===1&&span>=THIRD){put(at-direction*THIRD);put(at);continue}
      for(let s=1;s<=wide;s++)put(at-direction*s);
      for(let s=wide-1;s>=0;s--)put(at-direction*s);
    }
  };
  legs.forEach((leg,i)=>{
    const count=counts[i],at_=position(leg,Math.max(1,count)),where=Math.round(share('placement')*count);
    for(let k=1;k<=count;k++){
      if(i===1&&k-1===where)circle();
      at=at_(k)+(i===1?direction*moved:0);put(at);
    }
    if(i===0)dipAt=path.length-1;
    if(i===1){if(where>=count)circle();apexAt=path.length-1;fold()}
  });
  // Its repeats: where it turns (the dip, the arc's height), else the held note, then evenly along the way -- never
  // its landing, and a note three times only where too few stand alone.
  const places=[...(dip!==from&&dipAt>=0?[dipAt]:[]),...(apex!==to&&apexAt>=0?[apexAt]:[]),-1],taken=[];
  for(const place of places)if(taken.length<walk.repeats)taken.push(place);
  const open=place=>!taken.includes(place),alone=place=>path[place]!==path[place-1]&&path[place]!==path[place+1];
  const free=[...path.keys()].slice(0,-1).filter(place=>open(place)&&alone(place));
  // (Where too few notes stand alone, any not struck again yet: the walk keeps the rule.)
  if(free.length<walk.repeats-taken.length)free.push(...[...path.keys()].slice(0,-1).filter(place=>open(place)&&!alone(place)));
  for(let i=0,left=walk.repeats-taken.length;i<left&&free.length;i++){
    const aim=(i+1)*(path.length-1)/(left+1),place=free.reduce((best,at)=>Math.abs(at-aim)<Math.abs(best-aim)?at:best,free[0]);
    taken.push(place);free.splice(free.indexOf(place),1);
  }
  for(const place of taken.sort((a,b)=>b-a)){
    if(place<0){path.unshift(from);circled.unshift(false)}else{path.splice(place+1,0,path[place]);circled.splice(place+1,0,circled[place])}
  }
  const out=path.slice(0,moves);
  out[moves-1]=to;
  // (Its trills chosen: those whose every move lands on a note its circling put there -- two pairs or more to one side,
  // never one pair met by the way it came.)
  return {path:out,chosen:trillSpans([from,...out]).filter(({at,from:first})=>circled.slice(first,at).every(Boolean)).map(({at})=>at)};
}

// A figure's path: plain, or among voices where its point asks and its material holds them. `pitches` (semitones, low
// to high: its voice's), `seconds` (each note's) and `sounding` (how long each sounds) say what the voices need.
// `history`: the line before it, the held note last. -> {path: [index] (`moves` long, the last `to`), apart: Set of the
// moves between voices, chosen: Set of the moves its path trills by}.
export function figurePath({from,to,moves,low=0,high,point,pitches=null,seconds=null,sounding=seconds,history=[from],voices:among=true}){
  if(!(moves>=1))return {path:[],apart:new Set,chosen:new Set};
  const top=high??(pitches?pitches.length-1:Math.max(from,to));
  const voices=among&&Math.abs(to-from)<=moves?voicesOf({from,to,moves,low,high:top,point,pitches,seconds,sounding}):null;
  const {path,apart=new Set,chosen:circling=null}=voices?compoundPath({from,to,moves,voices}):plainPath({from,to,moves,low,high:top,point});
  // (Its trills: where its circling trills, the held note's on, or among its voices; and where the line's notes before
  // join the first unbroken, those moves too, continuing it -- a note struck again neither adding to one nor ending it.)
  const own=[from,...path],line=[...history.slice(0,-1),...own],before=line.length-own.length;
  const mine=circling??trillsIn(own),chosen=new Set(mine),heard=new Set(trillsIn(line));
  if(mine.length)for(let k=mine[0]-1;k>=1&&(heard.has(before+k)||line[before+k]===line[before+k-1]);k--)if(heard.has(before+k))chosen.add(k);
  return {path,apart,chosen};
}

// How many of the notes `after` a landing begin as it is: the notes alike it passes on into.
const alikeAtStart=(after,index)=>{const k=after.findIndex(next=>next!==index);return k<0?after.length:k};

// A figure's notes: the walk nearest its path (figurePath) that keeps the melody's rules for `choices` as `rules` asks
// them (melodyRules), from the line before it (`history`, the held note last) to `to`, within [low, high] but for its
// landing, no run or note struck again passing on into the notes `after` it; its last move the line's last (`last`)
// where so. Its ties broken by `random`, at most `jitter` of a step. Where no walk keeps every rule, they are let go in
// turn -- its runs, a trill, a note struck a third time, a note heard apart, its leaps' -- unless `strict`, which then
// gives null; where its range holds no walk at all, the even way from the held note to the next. `seconds`: each
// note's (s), or a list of them, its notes' in turn (a cadence's, of its rhythm), its voices then spaced to be heard
// apart at the slowest before its landing.
// -> [index], `moves` long, or null.
export function figureWalk({from,to,moves,low=0,high,point,pitches=null,seconds=null,sounding=seconds,history=[from],after=[],last=false,choices,rules={},strict=false,random=Math.random}){
  if(!(moves>=1))return [];
  const lengths=Array.isArray(seconds)?seconds:null,quickest=lengths?Math.min(...lengths):seconds;
  const slowest=lengths?Math.max(...(lengths.length>1?lengths.slice(0,-1):lengths)):seconds;
  // (Among voices only where no leap waits for its answer: a leap is answered in its own voice, which a move to
  // another leaves.)
  const waiting=melodyRules(choices,rules).replay(history).leap;
  const {path,apart,chosen}=figurePath({from,to,moves,low,high,point,pitches,seconds:slowest,sounding:lengths?slowest:sounding,history,voices:!waiting});
  const top=high??Math.max(from,to,...path);
  // (Its notes each within a third of its path's, or of the note before; none farther from its landing than its widest
  // move, a third at least, can come back from.)
  const near=[...Array(THIRD+THIRD+1).keys()].map(d=>d-THIRD);
  const reach=Math.max(THIRD,...path.map((index,k)=>Math.abs(index-(k?path[k-1]:from))));
  const loose={...rules,runMost:Infinity,trill:false,alike:Infinity};
  const tries=strict?[rules]:[rules,{...rules,runMost:Infinity},{...rules,runMost:Infinity,trill:false},loose,{...loose,heard:false},{...loose,heard:false,leaps:false,widest:Infinity}];
  // (A leap answered in its own voice: never by a note heard apart from the line, alone between the notes either side
  // of it (streams.js), as the line as heard keeps its rules as the line as written does. `waited`: the leap waiting
  // for the move to the note before, and `before` the note before that. Its gap, from the end of the note before it to
  // the start of the note after, the note's own length where its notes' lengths are listed (each sounding to the next);
  // the held note's taken at the quickest, the narrowest it can be.)
  const gapAt=note=>lengths?(note?lengths[note-1]:quickest):note?gapOf(seconds,sounding??seconds):seconds;
  const alone=(state,k,index)=>{
    if(!state.waited||!pitches||!(quickest>0)||apart.has(k)||apart.has(k-1))return false;
    return state.before!=null&&heardApart(pitches[state.before],pitches[state.at],pitches[index],gapAt(k-1));
  };
  for(const asked of tries){
    const kept=melodyRules(choices,asked),runMost=asked.runMost??choices.runMost,alikeMost=asked.alike??ALIKE_MOST;
    const earlier=history.slice(0,-1);
    let states=[{at:from,before:earlier.at(-1),rule:kept.replay(history),waited:kept.replay(earlier).leap,cost:0,line:[]}];
    for(let k=1;k<=moves&&states.length;k++){
      const left=moves-k,ideal=path[k-1],next=[];
      for(const state of states){
        for(const index of new Set(k===moves?[to]:[...near.map(d=>ideal+d),...near.map(d=>state.at+d)])){
          if(k<moves&&(index<low||index>top))continue;
          if(Math.abs(to-index)>left*reach)continue;
          if(asked.heard!==false&&alone(state,k,index))continue;
          const rule=kept.advance(state.rule,index-state.at,{last:last&&k===moves,chosen:chosen.has(k),apart:apart.has(k)});
          if(!rule)continue;
          const line=[...state.line,index];
          // (Nor a run, nor a note struck again, passing on into the notes after it.)
          if(k===moves&&rule.len+runAtStart([index,...after],rule.dir)>runMost)continue;
          if(k===moves&&rule.same+alikeAtStart(after,index)>alikeMost)continue;
          next.push({at:index,before:state.at,rule,waited:state.rule.leap,line,cost:state.cost+Math.abs(index-ideal)+JITTER*random()});
        }
      }
      next.sort((a,b)=>a.cost-b.cost);
      const seen=new Set;states=[];
      for(const state of next){const key=`${state.before}|${state.waited}|${state.at}|${kept.key(state.rule)}`;if(seen.has(key))continue;seen.add(key);states.push(state);if(states.length>=BEAM)break}
    }
    const best=states.find(state=>state.at===to);
    if(best)return best.line;
  }
  // (Where its range holds no walk at all, the even way from the held note to the next: each note between them.)
  return strict?null:Array.from({length:moves},(_,k)=>from+Math.round((k+1)*(to-from)/moves));
}
