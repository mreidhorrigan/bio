// Every change a physical model's player makes -- a breath rising or falling, a tongue stopping the air, a key, valve or
// slide moving, the lips changing, a bow's force, contact or string changing, a finger stopping a string, a technique
// beginning or ending -- one definition for every engine (NESS's brass, OpenWInD's woodwinds, the bowed strings, both
// tiers): its shape, a raised cosine, smooth at both ends, and the least time it may take, from measurements where they
// exist (the owner, 16 October 2026: "We might need to centralize the code for defining exciters, so we can make sure you
// don't hardcode hard starts per-instrument later"; "making sure nothing changes instantaneously"; "As an impulse, a click
// can confound many types of measurement"). No engine writes a ramp of its own: test/transitions.test.mjs reads the code
// for it, and fails where a control changes faster than its kind allows (research/INSTANTANEOUS_CHANGES_AUDIT.md, what it
// replaced). render/synthesis/workers/transitions.py reads the same values (render/synthesis/transitions.json, written
// from this module by scripts/transitions-json.mjs; the test checks they agree).
//
// Each kind: `least` (s), the shortest it may take, and `basis` -- 'measured' with its source, or 'provisional' with what
// it borrows until a measurement is found (each provisional one a gap: research/INSTANTANEOUS_CHANGES_AUDIT.md).

export const TRANSITIONS=Object.freeze({
  // (A woodwind's key, open or shut: "The time taken for a key to open or close was typically 10 ms when pushed by a
  // finger or 16 ms when moved by a spring" -- A. Almeida, R. Chow, J. Smith & J. Wolfe 2009, "The kinetics and acoustics
  // of fingering and note transitions on the flute", JASA 126(3), 1521-1529, doi:10.1121/1.3179674. Its fingers' delays
  // between one another "typically tens of milliseconds", the more fingers the longer: a change's keys need not move
  // together.)
  key:Object.freeze({least:.010,basis:'measured',source:'Almeida, Chow, Smith & Wolfe 2009, doi:10.1121/1.3179674: a key pushed by a finger 10 ms (a spring 16 ms)'}),
  keyBySpring:Object.freeze({least:.016,basis:'measured',source:'Almeida, Chow, Smith & Wolfe 2009, doi:10.1121/1.3179674: a key moved by its spring 16 ms'}),
  // (A brass valve's piston pressed or let up: not found measured; a finger's push, as a key's.)
  valve:Object.freeze({least:.010,basis:'provisional',source:'a woodwind key pushed by a finger (Almeida et al. 2009), until a valve is measured'}),
  // (The lips' tension and opening, and the frequency they buzz at, moving with a change: as the valve or key it goes with.)
  lips:Object.freeze({least:.010,basis:'provisional',source:'the fingering change it goes with (key, valve)'}),
  // (A trombone's slide: not found measured; its change already under a legato tongue's dip.)
  slide:Object.freeze({least:.020,basis:'provisional',source:'the slide moving under a legato tongue (breath.mjs), until measured'}),
  // (The breath rising at an attack, the tongue let go, or moving between two notes' pressures: the quickest the breath
  // rose when it was first written (render/synthesis/src/breath.mjs, 9 October 2026, which now reads it here), its source
  // untraced.)
  breathRise:Object.freeze({least:.014,basis:'provisional',source:'the breath\'s quickest rise as first written (breath.mjs, 9 October 2026), untraced'}),
  // (The breath falling at a release: as first written there, untraced.)
  breathFall:Object.freeze({least:.030,basis:'provisional',source:'the breath\'s quickest release as first written (breath.mjs, 9 October 2026), untraced'}),
  // (The tongue stopping the air before a tongued note, or dipping it in a legato tongue: as first written there,
  // untraced. Notes closer than it are let go after it.)
  tongueStop:Object.freeze({least:.008,basis:'provisional',source:'the tongue\'s stop as first written (breath.mjs, 9 October 2026), untraced'}),
  // (The tongue touching a reed and leaving it: its tip's motion, not found measured -- a few milliseconds, its corners
  // smoothed; the reed's own oscillation then grows as its physics has it.)
  tongueTouch:Object.freeze({least:.005,basis:'provisional',source:'openwind_worker.py TONGUE_TOUCH, its corners smoothed'}),
  tongueRelease:Object.freeze({least:.005,basis:'provisional',source:'openwind_worker.py TONGUE_RELEASE, its corners smoothed'}),
  // (The vocal tract's resonances moving -- the tongue's body and the jaw shaping it, as between vowels (native/openwind
  // src/tract.rs): not found measured for a wind player; as the breath's quickest release.)
  tract:Object.freeze({least:.030,basis:'provisional',source:'the breath\'s quickest release (breathFall), until a player\'s tract is measured moving'}),
  // (A technique begun or ended within a note -- a hum, a growl, flutter tonguing, its noise: as a breath rises.)
  technique:Object.freeze({least:.014,basis:'provisional',source:'the breath\'s rise (breathRise)'}),
  // (A pitch's own modulation crossing a note's edge -- a vibrato's factor, a glide: continuous, never a jump.)
  modulation:Object.freeze({least:.010,basis:'provisional',source:'a finger\'s motion (key)'}),
  // (The bowed strings: the bow's force and its contact point changing, a string crossed, the bow lifted or set down, a
  // finger stopping or leaving a string. Not found measured as rise times here -- A. Askenfelt 1989, "Measurement of the
  // bowing parameters in violin playing. II: Bow-bridge distance, dynamic range, and limits of bow force", JASA 86(2),
  // doi:10.1121/1.398230, to read for them.)
  bowForce:Object.freeze({least:.010,basis:'provisional',source:'a finger\'s motion (key), until bowing rise times are read (Askenfelt 1989)'}),
  bowContact:Object.freeze({least:.010,basis:'provisional',source:'as bowForce'}),
  stringCrossing:Object.freeze({least:.010,basis:'provisional',source:'as bowForce'}),
  bowLift:Object.freeze({least:.010,basis:'provisional',source:'as bowForce'}),
  finger:Object.freeze({least:.010,basis:'measured-analogue',source:'a finger pushing a flute key, 10 ms (Almeida, Chow, Smith & Wolfe 2009, doi:10.1121/1.3179674)'}),
  // (Anything else a model is given that changes: never under this.)
  any:Object.freeze({least:.005,basis:'provisional',source:'the least of any kind: no control steps'}),
});

// (Breakpoints a ramp is written with, for an engine that joins its breakpoints with straight lines -- NESS's score:
// at RAMP_POINTS segments a raised cosine is followed within half a percent of its change.)
export const RAMP_POINTS=16;

export function transition(kind){
  const t=TRANSITIONS[kind];if(!t)throw new Error(`transitions.js: no such kind of change: ${kind}`);return t;
}
// The time a change of `kind` takes: what is asked, never under its least.
export const transitionSeconds=(kind,asked)=>Math.max(Number.isFinite(asked)?asked:0,transition(kind).least);
// The raised cosine from 0 to 1 over x in [0, 1].
export const eased=x=>{const c=Math.min(1,Math.max(0,x));return .5-.5*Math.cos(Math.PI*c)};
// A change there and back over x in [0, 1] -- a breath eased or pushed for a moment: up along the raised cosine over its
// first half, back down over its second (sin²(πx)); each half its change, no quicker than its kind's least.
export const bump=x=>{const c=Math.min(1,Math.max(0,x));return c<.5?eased(2*c):eased(2-2*c)};
// A control's value at `t` while it changes from `from` to `to`, beginning at `at`, over `seconds`.
export const ramp=(t,at,seconds,from,to)=>from+(to-from)*eased(seconds>0?(t-at)/seconds:t>=at?1:0);
// A change as breakpoints [[t, value], ...], its ends included, for an engine that joins them with straight lines.
export function rampBreakpoints(at,seconds,from,to,points=RAMP_POINTS){
  return Array.from({length:points+1},(_,k)=>[at+seconds*k/points,from+(to-from)*eased(k/points)]);
}
// Whether a control's breakpoints [[t, value], ...] ever change faster than `kind` allows: the steepest change between
// two of them, as a share of the full change `span` a second, against the raised cosine's steepest over its least --
// -> {ok, steepest, allowed, at}. Two breakpoints at one time with different values are a step.
export function checkBreakpoints(rows,kind,span){
  const allowed=Math.PI/2/transition(kind).least;let steepest=0,at=null;
  for(let k=1;k<rows.length;k++){
    const dt=rows[k][0]-rows[k-1][0],dv=Math.abs(rows[k][1]-rows[k-1][1])/(span||1);
    if(dv===0)continue;
    const slope=dt>0?dv/dt:Infinity;if(slope>steepest){steepest=slope;at=rows[k-1][0]}
  }
  return {ok:steepest<=allowed*(1+1e-9),steepest,allowed,at};
}
// The same for a control's whole curve, changes of every size in it: each move -- breakpoints rising, or falling, in a
// row, ended by a hold or a turn -- checked against its own size, a small change as much as a large one. A step of
// `noise` of the curve's largest value or less is a hold (rounding). A curve sampled every `step` s (a control grid,
// not breakpoints): each move's turns fall between two samples, its size as sampled short of its own by up to
// sin^2(pi step / 4 least) of it at each end, where its raised cosine is flattest -- a tongue's release sampled at
// 48 kHz, turned at once into the next touch, read 1e-5 of itself small and over its least.
export function checkMoves(rows,kind,{noise=1e-9,step=0}={}){
  const tiny=noise*Math.max(0,...rows.map(([,v])=>Math.abs(v))),signOf=k=>{const dv=rows[k][1]-rows[k-1][1];return Math.abs(dv)<=tiny?0:Math.sign(dv)};
  const result={ok:true,steepest:0,allowed:Math.PI/2/transition(kind).least,at:null},sampled=1-2*Math.sin(Math.PI*step/4/transition(kind).least)**2;
  for(let a=0,k=1;k<rows.length;a=k-1){
    const s=signOf(k);if(s===0){k++;continue}
    while(k<rows.length&&signOf(k)===s)k++;
    const move=rows.slice(a,k),r=checkBreakpoints(move,kind,Math.abs(move.at(-1)[1]-move[0][1])/sampled);
    if(r.steepest>result.steepest)Object.assign(result,{ok:r.ok,steepest:r.steepest,at:r.at});
  }
  return result;
}
