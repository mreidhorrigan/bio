// A steelpan player's two sticks over a pan's note fields (the family atlas's F30, gongs, pans and resonant vessel sets:
// the tenor pan; its gongs, cymbals, bells and blocks are c2's), planned through the performer contract's one solver
// (contract.js searchGroups), as the mallets, the kalimba, the guitar and the piano are. Taken by 2a from c2's "Percussion
// beyond the kit", 29 September (SESSIONS.md 07:30).
//
// **Note fields on one surface.** A tenor pan's notes are fields on its concave face, laid out in fourths and fifths:
// around the rim an octave in a circle of fifths, each note's octave inside it on the same radius, the highest notes in
// the middle, so that a note's neighbours are its fifth and its fourth (Rossing, Hampton & Hansen 1996, "Music from oil
// drums: the acoustics of the steel pan", Physics Today 49(3), doi:10.1063/1.881489; Rossing, Hampton & Boverman 1986,
// "Acoustics of Caribbean steel drums", JASA 80, doi:10.1121/1.2023508). By default the pan is tuned for the piece, a field
// wherever the band's pitches are (`notes: 'band'`), a pitch between two keys between their fields; a fixed tenor pan
// (`notes: 'fixed'`, twelve to the octave over its range) has no field between its notes, which is refused, never rounded.
//
// **Two sticks.** Each hand holds one; a stick strikes again once its stroke has recovered (PAN.strokeSeconds), and a
// hand crosses the pan at PAN.handMmPerSecond; the two may strike two notes at once (a double stop). A player's hands
// cross the pan freely, so no order between them is kept.
//
// **Rolls.** A pan's note dies in about a second (PAN.ringSeconds, by register), so a note held longer is rolled: the
// two sticks alternating on it at PAN.rollHz, or, a double stop held, each stick on its own note.
//
// **What is not modelled yet**, and says so: the other pans (double seconds, cellos, basses, each with several drums), a
// field's sweet spot and its struck partials (a stroke's place changes its timbre), muffling a note with the hand, and
// the stick's rubber.
import {action,checkReservations,profile,searchGroups,STATUS,witness} from './contract.js';
import {instrumentRange} from './instrument-ranges.js';

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const PAN=Object.freeze({
  // A tenor pan's sounding range (MIDI: C4 to E6, twenty-nine notes; the instrument registry's, instrument-ranges.js).
  range:instrumentRange('steelpan').range,
  // The fields' distance from the middle (mm): the rim's octave, the inner octave, and the middle's notes (authored, a
  // pan about 560 mm across).
  radii:Object.freeze([230,150,60]),
  // How fast a hand crosses the pan (mm a second), how long a stroke holds its stick (s: about twelve a second from one
  // stick), and a roll's strokes a second between two sticks (authored).
  handMmPerSecond:2500,strokeSeconds:1/12,rollHz:14,
  // How long a note rings at the bottom and at the top of the range (s; authored).
  ringSeconds:Object.freeze([1.4,.7]),
  // A field sounds a pitch within this (semitones); notes starting within `together` of each other are one group (s).
  tolerance:.05,together:.005,
  // Costs, authored: each millimetre a hand travels.
  cost:Object.freeze({travelPerMm:.001}),
  maxStates:4096,
});
const modulo=(x,m)=>((x%m)+m)%m;
// A pitch class's place in the circle of fifths (0 for C, 1 for G, ... 11 for F); a pitch between two keys beside its
// nearest key's field, half a place a semitone away (a quarter tone above C a quarter of a place past it).
const fifths=pc=>{const nearest=Math.round(pc);return modulo(7*nearest,12)+(pc-nearest)/2};

// ---- The instrument --------------------------------------------------------------------------------------------------
// An instrument: its notes ('band': wherever a pitch is asked; 'fixed': twelve to the octave in its range; or a list of
// pitches) and its range. -> {range, fixed, notes (a sorted list, or null where the pan is the band's)}.
export function panInstrument({notes='band',range=null,choices=PAN}={}){
  const [low,high]=range??choices.range;
  const list=Array.isArray(notes)?[...notes].map(Number).filter(pitch=>pitch>=low-1e-9&&pitch<=high+1e-9).sort((a,b)=>a-b)
    :notes==='fixed'?Array.from({length:Math.floor(high)-Math.ceil(low)+1},(_,k)=>Math.ceil(low)+k):null;
  if(notes!=='band'&&notes!=='fixed'&&!Array.isArray(notes))throw new RangeError('a pan\'s notes are band, fixed or a list of pitches');
  if(notes!=='band'&&!list?.length)throw new RangeError('a fixed pan has at least one note in its range');
  return Object.freeze({range:Object.freeze([low,high]),fixed:notes!=='band',notes:list&&Object.freeze(list)});
}
// The field that sounds a pitch: the pitch itself on a pan tuned for the piece (within its range); on a fixed pan, its
// note within the tolerance. -> the field's pitch, or null (refused: no field sounds it).
export function fieldFor(instrument,pitch,{choices=PAN}={}){
  const [low,high]=instrument.range;if(!(pitch>=low-choices.tolerance&&pitch<=high+choices.tolerance))return null;
  if(!instrument.fixed)return pitch;
  const note=instrument.notes.reduce((best,candidate)=>Math.abs(candidate-pitch)<Math.abs(best-pitch)?candidate:best,instrument.notes[0]);
  return Math.abs(note-pitch)<=choices.tolerance?note:null;
}
// A field's centre on the pan's face (mm from its middle): its octave's ring (the rim for the range's lowest octave, then
// inside it, then the middle), at its pitch class's angle in the circle of fifths.
export function fieldXY(pitch,{range=PAN.range,choices=PAN}={}){
  const octave=Math.max(0,Math.min(choices.radii.length-1,Math.floor((pitch-range[0])/12))),radius=choices.radii[octave];
  const angle=fifths(modulo(pitch,12))/12*2*Math.PI;
  return {x:+(radius*Math.sin(angle)).toFixed(3),y:+(radius*Math.cos(angle)).toFixed(3)};
}
export const ringOf=(instrument,pitch,{choices=PAN}={})=>{
  const [low,high]=instrument.range,[bottom,top]=choices.ringSeconds,t=Math.max(0,Math.min(1,(pitch-low)/Math.max(1,high-low)));
  return bottom+(top-bottom)*t;
};

// ---- The player ------------------------------------------------------------------------------------------------------
// A pan player's profile: two hands (LH, RH), a stick each (LH.1, RH.1). `unavailable` names any of them.
export function panist({id='panist',performer='panist',unavailable=[],evidence='authored'}={}){
  const state=name=>unavailable.includes(name)?'unavailable':'available',resources=[];
  for(const hand of ['LH','RH']){
    resources.push({id:hand,kind:'body',availability:state(hand),evidence});
    resources.push({id:`${hand}.1`,kind:'effector',parents:[hand],availability:unavailable.includes(hand)?'unavailable':state(`${hand}.1`),evidence});
  }
  return profile({id,performer,resources});
}
const sticksOf=who=>['LH','RH'].filter(hand=>who.resources.get(`${hand}.1`)?.availability==='available');
const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
// Whether a stick reaches a field ({x, y}) to strike it at `at` (s): recovered by then, and its hand across the pan in
// time from when the stick left its last field (its stroke; a roll's end, the sticks held on the note till then).
// `last` is {x, y, from, free}, or null (a stick not yet used).
export const stickReaches=(last,xy,at,{choices=PAN}={})=>!last||at>=last.free-1e-9&&distance(xy,last)<=choices.handMmPerSecond*Math.max(0,at-last.from)+1e-9;

// ---- Passages --------------------------------------------------------------------------------------------------------
// Plan a passage [{pitch, start, end, rolled?}] on a pan: which stick strikes each note, a note held longer than it rings
// rolled by both sticks (or as a note's `rolled` says; a double stop held, each on its own), never faster than a stick
// recovers or a hand crosses the pan. -> {status, path?, cost?, witness?, reason?}; refused (unknown) where a pitch has
// no field.
export function planPan(input,{instrument=panInstrument(),who=panist(),choices=PAN}={}){
  if(!input.length)return {status:STATUS.witness,path:[],cost:0};
  const notes=input.map((note,index)=>({...note,id:note.id??`n${index}`}));
  for(const note of notes){
    if(!(note.end>note.start))throw new RangeError(`note ${note.id}: a positive duration`);
    const field=fieldFor(instrument,note.pitch,{choices});
    if(field===null)return {status:STATUS.unknown,reason:`pitch ${note.pitch} has no field on this pan${instrument.fixed?' (a fixed pan: a pitch between its notes is not rounded)':''}`};
    note.field=field;note.xy=fieldXY(field,{range:instrument.range,choices});note.rolled=typeof note.rolled==='boolean'?note.rolled:note.end-note.start>ringOf(instrument,field,{choices})+1e-9;
  }
  const groups=[];
  for(const note of [...notes].sort((a,b)=>a.start-b.start||a.field-b.field)){const last=groups.at(-1);if(last&&note.start-last.at<=choices.together)last.notes.push(note);else groups.push({at:note.start,notes:[note]})}
  const hands=sticksOf(who);
  // A hand's state: where its stick is, when it left its field (its stroke; a roll's end), when it may strike again (a
  // stroke's recovery; a roll's end).
  const stateKey=state=>JSON.stringify(['LH','RH'].map(hand=>state[hand]?[Math.round(state[hand].x),Math.round(state[hand].y),state[hand].from,state[hand].free]:null));
  const expand=(group,state)=>{
    const moves=[],count=group.notes.length;
    if(count>2)return moves;
    const rolled=group.notes.some(note=>note.rolled);
    // Its strokes: a single note by either stick, or (rolled) by both; a double stop a stick each, both ways.
    const ways=count===1?(rolled?(hands.length===2?[{LH:group.notes[0],RH:group.notes[0]}]:[]):hands.map(hand=>({[hand]:group.notes[0]})))
      :hands.length===2?[{LH:group.notes[0],RH:group.notes[1]},{LH:group.notes[1],RH:group.notes[0]}]:[];
    for(const way of ways){
      let ok=true,cost=0;const next={...state},strokes=[];
      for(const hand of ['LH','RH']){
        const note=way[hand];if(!note)continue;
        const before=state[hand];
        if(!stickReaches(before,note.xy,group.at,{choices})){ok=false;break}
        cost+=(before?distance(note.xy,before):0)*choices.cost.travelPerMm;
        const until=rolled?Math.max(...group.notes.map(each=>each.end)):group.at+choices.strokeSeconds;
        strokes.push({note:note.id,pitch:note.pitch,field:note.field,hand,x:note.xy.x,y:note.xy.y,rolled});
        next[hand]={x:note.xy.x,y:note.xy.y,from:rolled?until:group.at,free:until};
      }
      if(ok)moves.push({status:'supported',cost,state:next,step:{at:group.at,strokes}});
    }
    return moves;
  };
  const found=searchGroups(groups,{initial:{LH:null,RH:null},expand,stateKey,maxStates:choices.maxStates});
  if(found.status!==STATUS.witness)return {status:found.status,reason:found.group?`no sticking plays the group at ${found.group.at} s (${found.group.notes.map(note=>note.pitch).join(', ')})`:null};
  return {status:STATUS.witness,path:found.path,cost:+found.cost.toFixed(6),witness:panWitness(who,notes,found.path,{choices})};
}
// The witness: each stroke its stick's reservation for its recovery (a roll's for its note), in its hand's place,
// checked by the contract.
function panWitness(who,notes,path,{choices=PAN}={}){
  const actions=[],byId=new Map(notes.map(note=>[note.id,note]));
  for(const [k,step] of path.entries())for(const stroke of step.strokes){
    const note=byId.get(stroke.note),end=stroke.rolled?Math.max(...step.strokes.map(each=>byId.get(each.note).end)):note.start+choices.strokeSeconds;
    actions.push(action({id:`${stroke.rolled?'roll':'stroke'}:${k}:${stroke.hand}`,technique:stroke.rolled?'roll':'stroke',contacts:[stroke.note],contactSeconds:[note.start],
      reservations:[{resource:`${stroke.hand}.1`,phase:stroke.rolled?'hold':'excite',start:note.start,end,configuration:`${stroke.hand}@${Math.round(stroke.x)},${Math.round(stroke.y)}`}]}));
  }
  return witness({who,actions,checks:[{id:'pan-sticks',evidence:'authored',...checkReservations(who,actions)},{id:'muffling',status:STATUS.unknown}]});
}
