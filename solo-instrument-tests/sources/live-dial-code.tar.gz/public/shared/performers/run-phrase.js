// A run's shape over its phrase, for any player's runs (the user, 29 September 2026: "even quite fast passagework should
// still be subject to good contour principles with respect to overall shape (and regarding preferring not repeating
// climaxes/apexes)"): the line's rules (line.js runContour, 0f's: one apex, a leap answered by a step back, no note
// three times running, never the last phrase's apex) under the phrase's plan. A phrase's runs arch to one climax, its
// `climax` share of the way through: the bar that holds it reaches the phrase's apex, the bars before climb toward it a
// step a bar, the bars after stay under it, and never on the phrase before's apex. A scalar run goes `runMost` moves one
// way at most (an octave of a seven-note scale). The tones are the player's: a pianist's scale over its hand's reach, a
// guitarist's notes under its hand in position.
import {runContour} from './line.js';

export const RUN_PHRASE=Object.freeze({climax:.6,runMost:7});

// A run of `count` notes over `tones` (pitches, low to high) from `from`, in bar `bar` of phrase `phrase` (`phraseBars`
// long), under the phrase's plan `state` (null at first; the one returned is the next call's). `randomFor(reach)`: the
// random stream for a run that must reach the phrase's apex (true) or need not (false). `sound(pitch)`: the pitch a tone
// sounds at (the band's tuning, as the player's audio tunes it), so the run is shaped over the pitches heard, each once:
// tones a tuning rounds together are one (in the tritave's thirteen steps, 1.46 semitones apart, two of a twelve-step
// scale's often fell on one step, and a guitarist's run struck one note three times running). `below` and `above`: the
// range, in pitches heard, under `from` and over it (all where not given), counted once the tuning has made them one, so
// that a tuning coarser than the scale leaves the run as many notes to move in. -> {pitches, state}: pitches [] where no
// run in the range keeps the rules (the player's bar is then its comp's).
export function phraseRun({tones,from,count,bar=0,phrase=0,phraseBars=4,state=null,randomFor=()=>Math.random,sound=pitch=>pitch,below=null,above=null,choices=RUN_PHRASE}){
  // Tuned until the tuning leaves it where it is (a tone rounded to a step can lie near a chord tone, which the tuning
  // then gives its own tuning), so that each pitch planned is the pitch it sounds.
  const heard=pitch=>{let value=pitch;for(let k=0;k<4;k++){const next=Number(sound(value));if(!Number.isFinite(next)||Math.abs(next-value)<1e-9)break;value=next}return value};
  const all=[...new Map(tones.map(tone=>{const pitch=heard(tone);return [pitch.toFixed(4),pitch]})).values()].sort((a,b)=>a-b);from=heard(from);
  if(all.length<2)return {pitches:[],state};
  const {climax,runMost}=choices,bars=Math.max(1,Number(phraseBars)||4);
  const atMost=(list,value)=>{let found=-1;for(let k=0;k<list.length;k++)if(list[k]<=value+1e-6)found=k;return found};
  const at=all.findIndex(pitch=>pitch>=from-1e-6),top=at<0?all.length-1:at,highest=above==null?all.length-1:Math.min(all.length-1,top+above);
  // The phrase's plan: its apex (as a pitch, so that it holds while the chords change the scale under it), the top of its
  // first run's range. The phrase before's climax, as it sounded (its runs' highest), is the one this phrase's never is.
  let plan=state;
  if(plan?.phrase!==phrase){
    const previous=plan?.high??null;let apex=all[highest];
    if(previous!==null&&Math.abs(apex-previous)<1e-6)apex=all[Math.max(0,highest-1)];
    plan={phrase,startBar:bar,apex,previous,reached:null,high:null};
  }
  const barInPhrase=Math.max(0,bar-plan.startBar)%bars,climaxBar=Math.round(climax*(bars-1));
  const stepsUnder=barInPhrase<climaxBar?climaxBar-barInPhrase:barInPhrase>climaxBar?1+barInPhrase-climaxBar:0;
  // Its range: `below` pitches under the lower of where it begins and its ceiling (the apex, or the steps under it this
  // bar keeps), to `above` over where it begins. Counted from where it begins alone, a hand moved up since the phrase's
  // first bar had left a run of 34 notes three under its ceiling, circling there.
  const ceiling=Math.max(0,atMost(all,plan.apex)-stepsUnder),lowest=below==null?0:Math.max(0,Math.min(top,ceiling)-below);
  tones=all.slice(lowest,highest+1);
  if(tones.length<2)return {pitches:[],state:plan};
  const indexAtMost=value=>atMost(tones,value),apexIndex=indexAtMost(plan.apex);
  const high=Math.max(1,Math.min(tones.length-1,apexIndex-stepsUnder)),reach=stepsUnder===0&&apexIndex>0;
  const found=plan.previous===null?-1:indexAtMost(plan.previous),avoid=found>=0&&Math.abs(tones[found]-plan.previous)<1e-6?found:null,start=Math.max(0,indexAtMost(from));
  // Where the climax cannot be reached from here, the run still keeps under it and off the last phrase's apex.
  const shaped=reachNow=>runContour({count,low:0,high,from:Math.min(start,high),apex:high,reach:reachNow,avoid,runMost,repeat:false,random:randomFor(reachNow)});
  const run=(reach&&shaped(true))||shaped(false);
  if(!run)return {pitches:[],state:plan};
  if(reach&&Math.abs(tones[run.apex]-plan.apex)<1e-6)plan.reached=tones[run.apex];
  const pitches=run.indices.map(index=>tones[index]);
  plan.high=Math.max(plan.high??-Infinity,...pitches);
  return {pitches,state:plan};
}
