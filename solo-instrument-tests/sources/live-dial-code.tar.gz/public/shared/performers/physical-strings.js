// A string player's strokes as a physical model plays them (the owner, 1 October 2026: "we probably need those physical
// models, if computationally feasible, at least for offline renders"; "the string attacks and releases are particularly
// important"; research/MUSEBOTS_BOWED_STRING_IMPLEMENTATION_REPORT.md, its first candidate: Artifastring). A seat's
// strokes, as its engine logged them (audio.js physicalStroke), become the model's actions: a finger where the pitch
// is, on the string a player would take; the bow set on the string with an acceleration (an attack, its swell the
// stroke's), reversed at a change of bow, carried on under a slur while only the finger moves, slowed and lifted at the
// note's end so the string rings on (a release); vibrato and glissando in the finger; pizzicato plucked.
//
// The actions are Artifastring's (its actions2wav's lines, which render/node/physical-strings.mjs's driver reads):
//   f t string position          a finger at `position` (0 open, the share of the string from the nut to the finger)
//   h t string position firmness a light contact at a harmonic node; firmness is Artifastring's Kf multiplier
//   a t string beta force vel acc the bow at `beta` (its distance from the bridge, a share of the string), `force` (N), moving
//                                toward `vel` (m/s, signed by its direction) at `acc` (m/s^2), whichever way `vel` lies; a
//                                string the bow was not on, its bow set on it at rest (the driver's Artifastring, patched)
//   b t string beta force vel     the bow's place, force and speed; force 0 lifts it
//   p t string position force span  a pluck (the model pulls the string for 0.1 s before it lets go: MODEL.pluckLead), its
//                                  finger's grip and pull taken over span s
//   t t string ratio              the string's tension set to sound `ratio` times its own pitch
//   d t string ratio slope        the string's modal losses, mode n's times ratio * n^slope (a plucked string's, measured)
//   w t                           the end
// Every f, h, a, b, t and d ends in a span (s) over which what it sets moves from where it stands, along
// transitions.js's raised cosine -- or, followed by 1, one straight segment of a curve sampled more finely than any
// change: nothing a player does changes in one sample (the owner, 16 October 2026: "making sure nothing changes
// instantaneously"), each change never quicker than its kind's least (transitions.js). A bow set on a string from no force
// is set at its place and speed; one taken to no force leaves the string at its span's end (the driver's ramps build:
// native/strings-model/patches/ramps.patch).
//
// **Measured or physical:** the open strings (BOWED_INSTRUMENTS); a stopped string's length for a pitch (its share
// 2^(-semitones/12)); the bow's speed by dynamic and its contact point (bow.js BOW.speed, bowed-line.js
// BOWED_LINE.contact: Schoonderwaldt 2009's ranges). **Authored:** the forces by dynamic and the contact points held within
// the model's steady region (MODEL below), a release's slowing, the finger's step in a vibrato or a slide. The contrabass
// the engine's own (native/strings-model/musebots-instruments.h, contrabass.js): the cello's solver with four strings of
// its own, measured, played at their own pitch -- its body, for now, the cello's scaled to its size.
import {BOWED_INSTRUMENTS,BOWED_LINE} from './bowed-line.js';
import {BOW} from './bow.js';
import {LINE} from './line.js';
import {beyondOf} from '../dynamics.js';
import {ARTIFASTRING,BOWED,BOWED_TYPES,bySize,lossAt} from './bowed-instruments.js';
import {children,constant,equationOf,group,keysOf,player,setting,value} from '../../../registry/registry.js';
import {fnv1a,FNV_SPAN} from '../fnv1a.js';
import {temperatureAt} from '../noise.js';
// (The compiler's settings and the natural harmonics' probe, each with its reason: registry/method/strings.json
// `strings-compiler`, `strings-harmonics`; the semitones, cents and decibels by the registry's equations.)
const COMPILER=name=>setting('strings-compiler',name),HARMONIC=name=>setting('strings-harmonics',name);
// (What its players do, every instrument's of the family alike: registry/players/bowed.json, each with its reason and the
// search that found it unmeasured.)
const PLAYED=path=>player('violin-family',path),PLAYED_GROUP=path=>group('violin-family',path,'players');
const FROG_MIDDLE=PLAYED('draw.middle');
const SAME=COMPILER('same'),INSTANT=COMPILER('instant'),READY_BEFORE=COMPILER('readyBefore'),DAMP_BEFORE=COMPILER('dampBefore'),STRINGS=COMPILER('strings');
const LEAST_ACCELERATING=COMPILER('leastAccelerating'),PITCH_WITHIN=COMPILER('pitchWithin'),FINGER_PASSES=COMPILER('fingerPasses'),TUNE_WRITTEN=COMPILER('tuneWritten');
const HARMONIC_VELOCITY_WITHIN=HARMONIC('velocityWithin'),LEAST_ATTACK=COMPILER('leastAttack'),RELEASE_AFTER=COMPILER('releaseAfter'),TAIL=COMPILER('tail'),T60=constant('t60-db'),A4=constant('a4');
const [SEMITONES_RATIO,RATIO_SEMITONES,PLACE_SEMITONES,FINGER_PLACE,CENTS_SEMITONES,FROM_CENTI,MIDI_HZ,LOSS_RATIO_FOR,HELMHOLTZ_FORCE_SCALE,DB_GAIN]=['semitones-ratio','ratio-semitones',
  'place-semitones','finger-place','cents-semitones','from-centi','midi-hz','loss-ratio-for','helmholtz-force-scale','db-gain'].map(equationOf);
const semitonesRatio=semitones=>SEMITONES_RATIO({semitones}),centsSemitones=cents=>CENTS_SEMITONES({cents});
const fromCenti=centi=>FROM_CENTI({centi}),hzOf=midi=>MIDI_HZ({midi,a4:A4});
// (Each instrument's bow's hair across its string: registry/objects/bowed.json bow.hairWidth.)
const HAIRS=new Map,hairOf=instrument=>{if(!HAIRS.has(instrument))HAIRS.set(instrument,value(instrument,'bow.hairWidth'));return HAIRS.get(instrument)};
// The player's noise as the engine plays it (the actions' n: native/strings-model/musebots-player-noise.h;
// research/NOISE_AND_TEMPERATURE.md): each kind's deviation at temperature 1 -- the bow's force and speed, shares of what
// is asked; its place, a share of the string's length; the stopping finger's pitch, in cents -- and a continuous action's
// profile with its hand's tremor (registry/players/bowed.json `instrument` noise, every player's). Each kind's
// temperature the seat's tree's (public/shared/noise.js temperatureAt) down its path.
const NOISED=path=>player('instrument',`noise.${path}`);
export const PLAYER_NOISE=Object.freeze({
  kinds:Object.freeze({force:{sd:NOISED('bow.force'),path:['bow','force']},speed:{sd:NOISED('bow.speed'),path:['bow','speed']},
    contact:{sd:NOISED('bow.contact'),path:['bow','contact']},finger:{sd:NOISED('finger.pitch'),path:['finger','pitch']}}),
  profile:Object.freeze({beta:NOISED('action.beta'),low:NOISED('action.low'),high:NOISED('action.high'),tremor:{hz:NOISED('tremor.hz'),q:NOISED('tremor.q'),share:NOISED('tremor.share')}})});
// One kind's noise as the engine's action asks it, after its time: what (its number there, in PLAYER_NOISE's order), its
// deviation, its temperature and its profile.
export const noiseFields=(what,temperature)=>{const {sd}=PLAYER_NOISE.kinds[what],{beta,low,high,tremor}=PLAYER_NOISE.profile;
  return [Object.keys(PLAYER_NOISE.kinds).indexOf(what),sd,temperature,beta,low,high,tremor.hz,tremor.q,tremor.share].map(String)};
// The model measured (scripts/calibrate-strings-model.mjs): each instrument's open strings as it tunes them, its forces
// by dynamic (in Schelleng's window, every note in tune), its level against the recordings'.
import CALIBRATION from './physical-strings-calibration.json' with {type:'json'};
import HARMONICS from './physical-harmonics-calibration.json' with {type:'json'};
// Its multiphonics, measured (scripts/qualify-string-multiphonics.mjs): on each variant, each a light contact off the
// nodes, its firmness and bow place, the bands of its string's partials it sounds, their pitches, and the dynamics it
// keeps them at.
import MULTIPHONICS from './physical-multiphonics-calibration.json' with {type:'json'};
// Its onsets, fitted (research/STRINGS_ARTICULATION_FIT_PLAN.md): by instrument and dynamic, MODEL.onset's {speed, force}
// that make an articulation's weight and noise true of its sound; MODEL.onset's where none is fitted.
import ONSETS from './physical-strings-articulation.json' with {type:'json'};
import {pressureOf,multiphonicAmong,MULTIPHONIC_FIT} from './techniques.js';
import {transition,transitionSeconds} from './transitions.js';
import {bendOf,pointAt} from './bowed-midi2.js';
import {ACCENT_DB,articulationOfStroke} from './bowed-articulation.js';
export {CALIBRATION};
export {HARMONICS};
export {MULTIPHONICS};
export {ONSETS};
// A seat's multiphonic: its instrument's measured one on its variant, by index (the contrabass has none measured yet).
// -> the table's entry, or a RangeError where it has none.
// (`table`: a list in its place, as the qualification measures candidates: qualify-string-multiphonics.mjs.)
const multiphonicsOf=(instrument,variant)=>MULTIPHONICS.instruments?.[instrument]?.[variant%MODEL.variants]??[];
export function multiphonicOf(value,instrument,variant=0,table=null){
  const entry=(table??multiphonicsOf(instrument,variant))[Number(value?.index)];
  if(!entry)throw new RangeError(`No measured multiphonic ${value?.index} on the ${instrument}, variant ${variant%MODEL.variants} (scripts/qualify-string-multiphonics.mjs)`);
  return entry;
}
// The multiphonic a seat plays in place of a note, where its phrase plays them: one of its instrument's measured ones on
// its variant (its chair's), sounding at its own pitches -- its string never retuned for one, its bands following the
// string's tension chaotically (qualify-string-multiphonics.mjs); chosen as techniques.js multiphonicAmong chooses. With how a performer finds it, for the score:
// its string (0 the lowest) and where the finger touches it, as the pitch a stop there would sound (MIDI). -> {index,
// pitches, string, touch} or null where none lies in its compass.
export {MULTIPHONIC_FIT};
export function multiphonicNear(choice,pitch,{instrument,variant=0,compass=[-Infinity,Infinity],pool=[],dynamic='mf'}={}){
  const opens=opensOf(instrument,variant);
  const found=multiphonicAmong(multiphonicsOf(instrument,variant).map((entry,index)=>({index,pitches:entry.pitches.map(p=>+p.toFixed(4)),dynamics:entry.dynamics??['mf'],
    string:entry.string,touch:+(opens[entry.string]+PLACE_SEMITONES({place:entry.position})).toFixed(4)})),choice,pitch,{compass,pool,dynamic});
  return found?{index:found.index,pitches:found.pitches,string:found.string,touch:found.touch}:null;
}

// What the strings model can play on an instrument's variant, as a player's Performer asks its synth (audio.js
// instrumentLimits; bowed-line.js bowedLimits, a synth that says no more): the registry's compass and register, the
// strings as the variant tunes them, and the techniques the model was measured to sound -- its natural harmonics
// (harmonicNear) and its multiphonics (multiphonicNear), each on that variant. The page's live strings synth declares
// them (public/synths/strings-bridge.js), and a render's strings on the model.
export function stringsModelLimits(instrument,variant=0){
  const {range,register}=BOWED_INSTRUMENTS[instrument];
  return Object.freeze({instrument,variant,engine:'artifastring',range,register,strings:opensOf(instrument,variant),evidence:'measured',
    harmonicNear:(pitch,options={})=>harmonicNear(pitch,{...options,instrument,variant}),
    multiphonicNear:(choice,pitch,options={})=>multiphonicNear(choice,pitch,{...options,instrument,variant})});
}
// A natural harmonic of a pitch where the model sounds one: on a string its measured contacts hold that partial at
// (physical-harmonics-calibration.json), the string retuned to the pitch's microtone by no more than the measured
// region allows (retuneWarningSemitones: a player's strings stay as tuned -- the retune a constraint the model breaks,
// said in the render's warnings). Its `partial` where one is asked and holds there, else any; the least retuning first.
// -> {kind: 'natural', partial, string} or null where none: asked further, the model had sounded nothing (Op. 3.36's
// last cello notes, an E3 asked of its 55 Hz string, and its first contrabass's).
export function harmonicNear(pitch,{instrument,variant=0,partial:asked=null}={}){
  const opens=CALIBRATION.opens?.[instrument]?.[variant%MODEL.variants];
  const measured=HARMONICS.instruments[instrument]?.[variant%MODEL.variants]??{};
  if(!opens||!Number.isFinite(pitch))return null;
  let best=null;
  for(const [string,partials] of Object.entries(measured))for(const [partial,cents] of Object.entries(partials)){
    if(!Number.isFinite(cents)||!MODEL.harmonic.partials.includes(Number(partial)))continue;
    const off=pitch-RATIO_SEMITONES({ratio:Number(partial)})-opens[Number(string)];
    const other=asked!=null&&Number(partial)!==asked,rank=Math.abs(off);
    if(rank<=HARMONICS.retuneWarningSemitones&&(!best||other<best.other||other===best.other&&rank<best.rank))best={partial:Number(partial),string:Number(string),off,other,rank};
  }
  return best?{kind:'natural',partial:best.partial,string:best.string}:null;
}

// (The engine's instruments with strings of their own: the contrabass and every one given as data, bowed-instruments.js.)
const OWN_STRINGS=BOWED.filter(i=>i.strings);
// (A quantity measured or chosen for the four, for an instrument given as data read between them by size: bySize.)
const forEvery=table=>Object.freeze({...table,...Object.fromEntries(BOWED.filter(i=>!Object.hasOwn(table,i.name)).map(i=>[i.name,bySize(table,i.name)]))});
export const MODEL=Object.freeze({
  // The model's instruments: its type number and how many variants of each it holds (a seat takes one by its chair).
  types:BOWED_TYPES,variants:COMPILER('versions'),
  // The bow's force by dynamic (N) where the calibration has none, for a violin; the larger instruments' heavier strings
  // take more by the players' `forceScale` (registry/players/bowed.json) -- and the calibration's grids of forces are
  // scaled by the same (calibrate-strings-model.mjs). The contrabass's (and any instrument's with strings of its own)
  // from the cello's by their lowest strings: Schelleng's least force grows as a string's wave impedance squared. Taken as the cello's, 1.6, its grids had stopped at 9 N, where its
  // E and A strings bowed at forte's speed want more and at pianissimo's 1.4 N at least: its ladder had bowed them under
  // it at every dynamic, 0.1 to 0.8 N, their fundamentals gone (18 October 2026).
  force:PLAYED_GROUP('force'),
  forceScale:Object.freeze(Object.fromEntries(BOWED.map(i=>[i.name,player(i.name,'forceScale')]))),
  // The contact point (a share of the string from the bridge) is the measured one by dynamic, held within this
  // (beyond it the model leaves Helmholtz motion and squeaks or whistles).
  contact:Object.freeze(COMPILER('contactHeld')),
  // Where a player bows away from ordinario (a stroke's contact: -1 sul ponticello, 1 sul tasto, every place between):
  // its bow moved from its ordinario place toward `ponticello`, at the bridge, or `tasto`, over the fingerboard's end
  // (shares of the string from the bridge), as far as its contact asks, geometrically -- places of their own, whatever its
  // dynamic: a p's ordinario is already far from the bridge (BOWED_LINE.contact), and a third of it had been only an mf's.
  // Its force by Schelleng's window (Schelleng 1973, "The bowed string and the player", JASA 53(1), 26-41,
  // doi:10.1121/1.1913322: the least force goes as 1/beta^2, the most as 1/beta): over the fingerboard lightened as the
  // most is, beta0/beta of its own, the string still in Helmholtz motion, its fundamental strong (a sul tasto's
  // flautando); at the bridge its own, under the least force there, the string left to its higher partials (a sul
  // ponticello's glassy sound) -- harder, it had pressed past the most and sounded darker than ordinario. Ours, the
  // places.
  ponticello:PLAYED('places.ponticello'),tasto:PLAYED('places.tasto'),
  // The bow's hair across the string (m): the violin family's (registry/objects/bowed.json bow.hairWidth: a violin bow's
  // about 10 mm, Schoonderwaldt, Guettler & Askenfelt 2003; the larger bows' not found measured, the same), the strings
  // live dial's (native/strings-model/live.mjs); a part's every string written with its own instrument's at its start
  // (hairOf): the renders, the band and the dial one bow.
  hair:value('violin-family','bow.hairWidth'),
  // A stroke's attack, where its stroke names none (s), never more than `attackShare` of its note, its force set on the
  // string at this share of its own (from none, within the least a bow's weight takes: transitions.js bowLift) and raised
  // to its own over it, as its speed rises; a change of bow's reversal (s: the bow through zero at the change's time), its
  // force raised by `bite` as the bow takes the string again (a change at a new note, a détaché's, more than one inside a
  // held note), back to its own after the reversal and `biteFor` (s); a release: the force eased to nothing over a span
  // between `release`'s two (s, each note's its player's own: a section's bows never all leave the string at once), along
  // transitions.js's raised cosine, the bow still moving, leaving the string as its force reaches nothing, the string
  // left to ring (a bow slowed to a stop on the string would damp it instead). (The owner, 2 October 2026, of Op. 3.5: "It
  // has a click at the end"; "ending a bowing should not click": its sixty bows left the string at one instant, their
  // force a seventh of its own; "the attack of another chord ... seems to arrive too quickly to happen without the usual
  // signifiers of a bow attack".) Each of these, once a step (an attack's and a release's a staircase of them), now a
  // change over time: the owner, 16 October 2026, of an attack's force set from none to its first step's in one sample
  // ("there aren't supposed to be such jumps anymore").
  attack:PLAYED('attack.seconds'),attackFrom:PLAYED('attack.from'),attackShare:PLAYED('attack.share'),reversal:PLAYED('change.reversal'),
  tremoloReversal:PLAYED('change.tremoloReversal'),bite:PLAYED_GROUP('change.bite'),biteFor:PLAYED('change.biteFor'),
  release:Object.freeze(PLAYED('release')),
  // A stroke's onset where it carries an articulation's point (bowed-articulation.js; a stroke that carries none is
  // attacked as above): its bow drawn faster and heavier together by `speed` times its weight -- its level rising with
  // its speed, its force with it so that the string stays in Schelleng's window: an accent, not a scratch -- and heavier
  // again by `force` times its noise, a bow pressed past what its speed takes cleanly (the pre-Helmholtz transient's
  // prolonged periods: K. Guettler 2002, "On the creation of the Helmholtz motion in bowed strings", Acta Acustica united
  // with Acustica 88(6), 970-985), its attack's force begun nearer its own the noisier (from its attackFrom share at none
  // to all of it at 1); where it bites, its bow first set on the string at that force, still, for its bite; drawn to its
  // onset's speed over its attack, then eased back to its held bow over its decay, never quicker than a bow's force may
  // change (transitions.js bowForce). Authored: `speed` a weight of 1's ACCENT_DB as the level's rise with the bow's speed,
  // `force` a noise of half's today's change of bow's (MODEL.bite.change) -- each to be replaced by the strings' fit
  // (research/STRINGS_ARTICULATION_FIT_PLAN.md), which makes a point's weight and noise true of the sound: onsetOf.
  onset:Object.freeze({speed:+(DB_GAIN({db:ACCENT_DB})-1).toFixed(3),force:PLAYED('onset.force')}),
  // A stroke ended with its bow stopped on the string instead (its stroke's `rest`, s: how long the bow stays there before
  // it lifts, the player's choice -- 0 lifted while it moves, the string ringing; longer, damped longer): the bow slowed
  // to rest by the note's end under its weight, over its slowing (`following`), and left on the string, which its weight
  // damps as a player's stopped bow does (the owner, 15 October 2026: "Does our model capture a difference between letting
  // a string ring versus keeping the bow down on it, so it stops ringing much faster after a note?" -- the model's
  // cello D string, its bow stopped at its weight, 22 dB down 50 ms after, against 0.8 lifted; native/strings-model/
  // probe.py); then lifted, `lifted` (s) before the next stroke at the latest.
  lifted:PLAYED('lifted'),
  // The finger's steps in a vibrato or a slide (s); a slur's finger change (s); a stroke joined to the one before it
  // where it begins within this of that one's end (s).
  step:COMPILER('step'),slur:PLAYED('slur'),joined:COMPILER('joined'),
  // A pitch slurred to again (within `within` semitones of the one before) is louré: one bow, each note marked by the
  // bow slowed on the string -- to `speed` of its own and lightened to `force` of its weight, over `seconds` round the
  // note's time (the model's, and its slowing's own at least: `follow`), never lifted nor reversed -- as a player marks
  // repeated notes under a slur (the owner, 10 October 2026: a slurred repeated note is "almost like half-attacking the
  // notes"; slurred as any other, its finger never moving, it had run into the note before, the two heard as one). A half
  // attack, lighter than a change of bow, and lightened as it slows: Schelleng's most force falls with the bow's speed, and
  // a bow slowed at its full weight left a cello's string grinding at its level (0.35 of its speed: the cello's dipped 1.7
  // dB, its violin's 13); slowed to 0.2 and lightened to 0.35, in the legato test's phrases, the violin's 12 to 13 dB, the
  // viola's 5 to 6.5, the cello's 4.5 to 6.4, the contrabass's 8 to 15, each under its change of bow's (7.6 to 19.6).
  // Ours, to be replaced by players' measured louré.
  loure:PLAYED_GROUP('loure'),
  // A bow slowed -- to a stop before a change of bow after its bite, or for a louré -- over `follow` of its note's
  // periods at least, and no more than `share` of the note it slows in: a string's motion follows its bow's speed only
  // as fast as its corner goes round, once a period, so a bow slowed in 25 ms had left a cello's D string ringing (its
  // change of bow dipped 3 dB, its louré none); over ten periods, 50 ms there, 6 dB, and a violin's no less. Ours.
  follow:PLAYED('follow.periods'),followShare:PLAYED('follow.share'),
  // A stroke drawn as no bow holds one the same throughout (the owner, 10 October 2026: "no bow has the ability to exercise
  // exactly the same result on the string for any duration of its stroke"; of a held cello note, its bow "lacking a sense
  // that the bow is changing throughout the stroke"). The bow's place along itself followed through each stroke, frog
  // (0) to tip (1), over its `length` of hair (m): a stroke from silence begun down-bow `start` from the frog, up-bow as
  // far from the tip; a slur going on from where the last left it; a change of bow turning there. Its weight heavier toward
  // the frog, where the bow's own (some 0.59 N) bears on the string, eased by the middle -- `frog` more of its force at the
  // frog, nothing from the middle, about its own on the whole (Y. Mizuho and Y. Sugiura, "Practice Support for Violin
  // Bowing by Measuring Bow Pressure and Position", 2025, doi:10.48550/arXiv.2505.04446: eight experienced violinists'
  // down-bows significantly heavier at the frog than in the middle, the middle and the tip alike). Its weight wandering
  // slowly and its speed with it (`drift.pressure`, its speed `coupled` of the way: players draw faster as they press
  // harder, to keep from roughness -- Blanco et al. 2021, as Mizuho and Sugiura cite it; wandering apart, a contrabass's
  // and a cello's re-bowed notes left Helmholtz motion, their pitch leaping five semitones), its speed and place each a
  // little on their own (`drift`, shares of their own, over periods of `slow` s), under its hand's small `tremor` (at
  // `tremorHz`) -- ours, to be replaced by players' measured strokes (E. Schoonderwaldt and M. Demoucron, "Extraction
  // of bowing parameters from violin performance combining motion capture and sensors", JASA 126 (2009), 2695-2708,
  // doi:10.1121/1.3227640). Drawn every `step` s through a stroke held `least` s or longer -- never a multiphonic's, bowed
  // as it was measured -- each player's own, its seat, variant and bow seeding it, in the bow's own time (a stroke begun
  // early wanders as it would have; a slur or a louré, one bow, wandering on through it: begun again at each, its weight
  // and speed had leapt back at every slur, a contrabass's dipping 6.8 dB), its wandering grown in over `settle` s once
  // its attack has taken the string: begun at once, the bow moving under a tone still forming, a violin's first note
  // spoke 95 ms later for being begun 36 ms earlier.
  draw:Object.freeze({length:forEvery(Object.fromEntries(['violin','viola','cello','contrabass'].map(name=>[name,value(name,'bow.hairLength')]))),start:PLAYED('draw.start'),
    frog:PLAYED('draw.frog'),coupled:PLAYED('draw.coupled'),drift:PLAYED_GROUP('draw.drift'),slow:Object.freeze(PLAYED('draw.slow')),tremor:PLAYED('draw.tremor'),
    tremorHz:Object.freeze(PLAYED('draw.tremorHz')),step:COMPILER('drawStep'),least:COMPILER('drawnLeast'),settle:PLAYED('draw.settle')}),
  // The least a finger stops a string (its share from the nut): nearer the nut the model's finger, a stiff spring on a
  // piece of string that hardly moves, overshoots step after step until its numbers overflow (Op. 3.5's second violins,
  // a finger at 0.006: NaN, and every return of the mix after it). A pitch nearer its open string than that, or under
  // the lowest string, keeps its finger at that least stop, the string's tension lowered just so the two sound it
  // exactly (the driver's 't'): the finger's damping and its vibrato are a stopped note's still, and the model bends to
  // the music, never the music to the model (the owner: "constraining the range of the instrument to fit the model is
  // not acceptable"; "does this throw away the effect of the finger on the fingerboard?"). A note at its open string
  // (within openWithin semitones) is the open string; a stopped note's path passing there (its vibrato, a glide) keeps
  // its finger down, as a player's stays through its vibrato (stopFor `stopped`: 26 October's test meters, a violin's
  // vibrato on its D string touched the open D, and its finger was lifted for 10 ms). (At 0.03, violin variant 2's E
  // string overflowed on its attack: Op. 3.9's first renders; at 0.045, its next stop measured, it plays.)
  leastFinger:COMPILER('leastFinger'),openWithin:COMPILER('openWithin'),mostRetune:COMPILER('mostRetune'),
  // A pluck: the model pulls the string for this long (s, its PLUCK_SECONDS) before it lets go, so it is asked that much
  // early; where it is plucked, its pull by dynamic and each string's losses as the calibration measured them against
  // the recorded pizzicati (calibrate-strings-model.mjs --pizzicato), else these.
  pluckLead:COMPILER('pluckLead'),pluck:Object.freeze({position:PLAYED('pluck.position'),pull:PLAYED_GROUP('pluck.pull')}),
  // A pluck stopped at its note's end, as a player's finger laid on the string stops it: the string's losses raised so
  // that its slowest mode, its fundamental, is down 60 dB in `damp` s (ours), from its own loss as the model has it
  // (FUNDAMENTAL_LOSS) -- unless the string is plucked or bowed again first; its next note sets them back. A stopped
  // note's at once, its finger eased off the string it already holds; an open string's later and less at once, a free
  // finger of either hand brought to it. (The owner, 5 October 2026: "I don't think the string pizzicato sounds are
  // receiving enough string damping"; "whether or not a pizz happened on an open string will affect damping"; "The
  // default is that pizz is damped": a plucked string had rung until it was next played, its losses those of recorded
  // pizzicati left to ring, a quarter of the model's own on some strings -- a violin's A string half a minute.)
  damp:PLAYED_GROUP('damp'),
  // Light contact retains the full string. Its first two harmonics above the fundamental are measured in
  // research/physical-neural-synthesis; higher partials and a second stopping finger are not yet qualified.
  harmonic:Object.freeze({partials:Object.freeze(HARMONIC('partials')),firmness:HARMONIC('firmness'),contact:HARMONIC('contact'),force:HARMONIC('force'),speed:HARMONIC('speed')}),
  // Bow pressure's extremes (pressed): at flautando the bow's speed and force times these and its place no nearer the
  // bridge than `contact`; at overpressure its speed and force times these. Authored starting points, each instrument's
  // replaced by its measured ones (CALIBRATION.pressure).
  pressure:PLAYED_GROUP('pressure'),
  // The uncomfortable range's bow (beyondBow): for each mark beyond ppp, its force times these, lighter and lighter
  // toward a string that hardly speaks; beyond fff, heavier and heavier past Schelleng's most -- where its instrument's
  // measured multiples are not known (CALIBRATION.instruments[..].beyond), ours.
  beyond:PLAYED_GROUP('beyond'),
});
// Each model string's slowest loss (1/s): its first mode's decay in Artifastring's constants (the registry's: registry/
// objects/artifastring-strings.json, each of an instrument's sets a node), by instrument, the model's variant (its own
// count of them: it takes a variant modulo it) and string, lowest first; the contrabass's its measured law at its
// fundamental (contrabass.js), an instrument's given as data its like string's measured decay there (bowed-instruments.js
// lossAt): every variant's strings the same.
export const FUNDAMENTAL_LOSS=Object.freeze({
  ...Object.fromEntries(ARTIFASTRING.map(name=>[name,children(`${name}-strings`).map(set=>keysOf(set,'').map(s=>value(set,`${s}.decays`)[0]))])),
  ...Object.fromEntries(OWN_STRINGS.map(i=>[i.name,[i.strings.map(s=>lossAt(s,s.f0))]])),
});
// A note's own number in [0, 1) from its player and its place (FNV-1a): its release's span, the same every render.
const ownShare=text=>fnv1a(text)/FNV_SPAN;

// Whether a stroke glides into its note: its finger's path begins off its pitch (by more than 5 cents).
export const glidesInto=g=>{const bend=g.bend??bendOf(g);return Boolean(bend)&&Math.abs(pointAt(bend,0))>PITCH_WITHIN};
export const instrumentOf=seat=>{const prefix=String(seat??'').split('.')[0];return ({vn1:'violin',vn2:'violin',va:'viola',vc:'cello',cb:'contrabass'})[prefix]??(Object.hasOwn(BOWED_TYPES,prefix)?prefix:'violin')};
const clamp=(value,low,high)=>Math.min(high,Math.max(low,value));
// A stroke's velocity between the dynamics' own (LINE.velocity, the system's scale: a p's velocity is p): the two it lies
// between and how far from the softer. Its bow's speed, contact and force are each the two dynamics' between them,
// geometrically, so that a crescendo through a tremolo's strokes grows rather than steps (everything interpolable) -- and
// a p's velocity bows a p: read as a level (section-voices.js dynamicOf), it had bowed an mp, a pp's a p.
// Beyond ppp or fff, the marks it lies beyond them (dynamics.js beyondOf), which its bow's pressure makes (beyondBow): a
// soft held note's swell still a swell under ppp, as it had been under pp (the owner, 5 October 2026: "Long notes are also
// not receiving the shaping that they should" -- every velocity under pp had bowed pp, one unchanging bow).
const BETWEEN=LINE.dynamics.map(dynamic=>LINE.velocity[dynamic]),INSIDE=BETWEEN.slice(1,-1);
export function dynamicsOf(velocity){
  const given=Number(velocity)||0,v=clamp(given,BETWEEN[0],BETWEEN.at(-1)),i=INSIDE.filter(x=>v>x).length;
  const w=(v-BETWEEN[i])/(BETWEEN[i+1]-BETWEEN[i]);return {lower:LINE.dynamics[i],upper:LINE.dynamics[i+1],w,dynamic:LINE.dynamics[i+Math.round(w)],beyond:beyondOf(given)};
}
const blend=(a,b,w)=>a*(b/a)**w;
// The string a pitch is played on: the highest whose open pitch is at or under it (the lowest position, as a player
// first reaches for); a pitch under the lowest string on the lowest, open (the model cannot go lower). `keep`: the
// string a slurred stroke is on, kept while it reaches the pitch.
export function stringFor(pitch,strings,reach,keep=null){
  if(keep!=null&&pitch>=strings[keep]-SAME&&pitch<=strings[keep]+reach)return keep;
  for(let s=strings.length-1;s>=0;s--)if(pitch>=strings[s]-SAME)return s;
  return 0;
}
// How the model sounds a pitch on a string: {finger, tune}. A finger where it stops the string stably (tune 1); the open
// string at its own pitch; nearer the open string than a finger stops stably, or under it, the finger at its least stop
// and the string's tension lowered so the two sound the pitch (tune: the ratio of the pitch the string then sounds to
// its own).
// `centsAt`: what a finger at a place sounds over its geometry (cents: the calibration's, measured), by which the finger
// is placed so the pitch sounds where it is written. `stopped`: a point of a stopped note's path, its finger never lifted
// to the open string.
export function stopFor(pitch,open,centsAt=()=>0,{stopped=false}={}){
  if(!stopped&&Math.abs(pitch-open)<MODEL.openWithin)return {finger:0,tune:1};
  const geometric=fingerAt(pitch,open);let finger=geometric;
  for(let k=0;k<FINGER_PASSES&&finger>=MODEL.leastFinger;k++)finger=fingerAt(pitch-centsSemitones(centsAt(finger)),open);
  if(finger>=MODEL.leastFinger)return {finger,tune:1};
  const least=MODEL.leastFinger,sounds=open+RATIO_SEMITONES({ratio:1/(1-least)})+centsSemitones(centsAt(least)),tune=semitonesRatio(pitch-sounds);
  // (Never a string's tension raised by more than a semitone, which only a failed correction could ask: a finger that
  // reaches the pitch by its geometry stops it there instead.)
  if(tune>MODEL.mostRetune&&geometric>=least)return {finger:geometric,tune:1};
  return {finger:least,tune};
}
// A string's finger corrections as a function of the place (calibration fingerCents, linear between its stops).
// A measurement further than `outlier` cents from its string's reliable centre is taken for one that failed (a note
// that did not speak, or its pitch read at another of its partials: violin variant 2's E string read -198 and +677 cents
// where its others read +27, Op. 3.9's first render, its fingers misplaced and then its tension raised until the model
// overflowed), and read between its reliable neighbours instead (ours: a finger the model places by geometry is never a
// semitone out; its reliable corrections lie within some 30 cents of each other).
export const FINGER_CENTS=Object.freeze({outlier:COMPILER('fingerOutlier')});
export function fingerCentsOf(instrument,variant,string){
  const stops=CALIBRATION.stops,measured=CALIBRATION.fingerCents?.[instrument]?.[variant%MODEL.variants]?.[string];
  if(!stops||!measured)return ()=>0;
  // (Its reliable centre: the measurement with the most others near it, as half a table that failed would move a median.)
  const centre=measured.reduce((best,c)=>{const near=measured.filter(o=>Math.abs(o-c)<=FINGER_CENTS.outlier/2).length;return near>best.near?{c,near}:best},{c:measured[0],near:0}).c;
  const median=centre,reliable=measured.map(c=>Math.abs(c-centre)<=FINGER_CENTS.outlier);
  const cents=measured.map((c,i)=>{if(reliable[i])return c;
    let before=i-1,after=i+1;while(before>=0&&!reliable[before])before--;while(after<measured.length&&!reliable[after])after++;
    if(before<0)return after<measured.length?measured[after]:median;if(after>=measured.length)return measured[before];
    return measured[before]+(measured[after]-measured[before])*(stops[i]-stops[before])/(stops[after]-stops[before]);});
  return x=>{if(x<=stops[0])return cents[0];for(let i=1;i<stops.length;i++)if(x<=stops[i])return cents[i-1]+(cents[i]-cents[i-1])*(x-stops[i-1])/(stops[i]-stops[i-1]);return cents.at(-1)};
}
// The finger's place for a pitch on a string: the share of the string from the nut, so that what is left sounds it.
export const fingerAt=(pitch,open)=>Math.max(0,FINGER_PLACE({semitones:pitch-open}));
// The bow's place on the string for a contact point (a share of the vibrating length from the bridge, as a player
// sets it): the model counts it on the whole string, and a stopped string's vibrating length is what the finger leaves.
export const bowAt=(contact,finger)=>contact*(1-finger);

// A requested sounding pitch, not a stopped pitch. Touching node k/n retains modes that vanish there; require
// coprime k,n so a request for the fourth partial cannot accidentally select the second at node 2/4.
export function naturalHarmonic(value){
  if(value==null||value===false)return null;
  if(typeof value!=='object'||Array.isArray(value))throw new TypeError('harmonic must be {kind: "natural", partial: 2 or 3}');
  const kind=value.kind??'natural',partial=value.partial??MODEL.harmonic.partials[0],node=value.node??1;
  if(kind!=='natural')throw new RangeError('Artifastring supports one light natural-harmonic contact; artificial harmonics and multiphonics are not implemented');
  if(!MODEL.harmonic.partials.includes(partial)||!Number.isInteger(node)||node<1||node>=partial)throw new RangeError('Natural harmonics currently support partials 2 and 3 and their interior nodes');
  if(value.string!=null&&(!Number.isInteger(value.string)||value.string<0||value.string>=STRINGS))throw new RangeError('harmonic.string must be 0 through 3, lowest first');
  return {kind,partial,node,...(value.string!=null?{string:value.string}:{})};
}
export function harmonicStopFor(pitch,open,harmonic,cents=0){
  return {finger:harmonic.node/harmonic.partial,tune:semitonesRatio(pitch-open-centsSemitones(cents))/harmonic.partial};
}

// A bow pressed or lightened (its stroke's pressure, techniques.js: -1 flautando to 1 overpressure), by its pressure's
// share of the way to the instrument's extreme, geometrically: toward flautando drawn faster, nearer the fingerboard and
// lighter, the string still in Helmholtz motion; toward overpressure heavier and slower, past the most force Schelleng's
// window allows at its place, the string's motion no longer periodic. The extremes the instrument's measured ones
// (CALIBRATION.pressure: scripts/calibrate-strings-model.mjs --pressure), else MODEL.pressure's. -> its bow.
export function pressed(bow,pressure,instrument,given=null){
  const p=pressureOf(pressure);if(!p)return bow;
  // (Its ends a fit's trial where given (compileActions `pressure`), else the measured, else MODEL.pressure's.)
  const ends={...MODEL.pressure,...CALIBRATION.pressure?.[instrument],...given},a=Math.abs(p);
  if(p<0){const end=ends.flautando;return {...bow,speed:bow.speed*end.speed**a,contact:bow.contact*Math.max(1,end.contact/bow.contact)**a,force:bow.force*end.force**a}}
  const end=ends.overpressure;return {...bow,speed:bow.speed*end.speed**a,force:bow.force*end.force**a};
}

// A bow beyond the scored range, the owner's uncomfortable range (dynamics.js; the owner, 10 October 2026: "involving
// excessive pressure (for extreme loudness) and almost-unspeaking lack of pressure (for extreme quietness)"): `beyond`
// marks under ppp its ppp bow ever lighter, the string almost leaving Helmholtz motion; over fff its fff bow ever heavier,
// past Schelleng's most -- its force times each mark's multiple, and its speed times each mark's own (the owner, 21
// October 2026: "bow speed should be adjustable for extremes": by force alone, a violin's marks past ppp all sounded at
// the lightest force its pitch was heard at, and past fff none louder than fff), each read between marks geometrically:
// the instrument's fitted multiples (CALIBRATION.instruments[..].beyond, its `speed` the speeds': native/strings-model/
// fit_player.py), else MODEL.beyond's (speed unchanged). -> its bow.
export function beyondBow(bow,beyond,instrument){
  const k=Math.abs(Number(beyond)||0);if(!k)return bow;
  const side=beyond<0?'quiet':'loud',own=CALIBRATION.instruments?.[instrument]?.beyond,low=Math.floor(k);
  const of=multiples=>{const at=j=>j<=0?1:Number(multiples[Math.min(multiples.length,j)-1]);return at(low)*(at(low+1)/at(low))**(k-low)};
  return {...bow,force:bow.force*of(own?.[side]??MODEL.beyond[side]),speed:bow.speed*of(own?.speed?.[side]??MODEL.beyond.speed[side])};
}

// The slowest bow that holds a tone on an instrument, cm/s: its ppp speed (bow.js) times the least of its fitted speeds'
// multiples beyond ppp (CALIBRATION.instruments[..].beyond.speed.quiet, each of those marks fitted speaking:
// native/strings-model/fit_player.py), ppp's own where it has none. Its wandering bow (compileActions) is never drawn
// slower. The owner decided on 23 October 2026 that a fit may slow the bow under pp below the one floor all four had shared
// (BOWED_LINE.slowestBow, ppp's speed): each instrument's its own.
export function slowestBowOf(instrument){
  const quiet=CALIBRATION.instruments?.[instrument]?.beyond?.speed?.quiet??[];
  return BOW.speed.ppp*Math.min(1,...quiet.map(Number));
}

// How long a stroke into silence leaves its bow on the string (s) where its player chooses no rest of its own: as its
// instrument's measured players end their notes (calibrate-strings-model.mjs --release: the rest under which the model's
// notes fall once their bow stops as TU Berlin's recorded ones do, at pp and at ff), between its two velocities by the
// stroke's and along their line beyond, never less than none; none for an instrument not measured, its bow lifted and
// its string left ringing. Every stroke had ended so, where the recorded double bass at forte stops its bow on the string
// (the owner, 18 October 2026, of the live quintet's contrabass: extra reverb).
export function releaseOf(instrument,velocity,calibration=CALIBRATION){
  const release=calibration.instruments?.[instrument]?.release;if(!release)return 0;
  const [v0,v1]=release.velocities,[r0,r1]=release.rests;
  return Math.max(0,r0+(r1-r0)*(velocity-v0)/(v1-v0));
}
// A string's law by decomposition (native/strings-model/neutral.py), where its variant has one: its knots each a stop it
// was measured at (semitones over its open pitch: one list for every dynamic, or each dynamic's own, a stop with no
// neutral note at that dynamic left out) and each dynamic's values there -- its force (N), its bow's speed (m/s), its
// contact where it has its own -- read between two knots in their logarithm by how far between them the note
// is stopped, held at the end knots past them: so that a pitch between the knots, a microtone, is played between them
// (the owner, 27 October 2026: "The strings should also end up continuous, so that notes between notes - microtones -
// can be interpolated").
export function knotted(stops,values,above){
  const x=Number(above)||0,n=Math.min(stops.length,values.length);
  if(!n)return NaN;
  if(n===1||x<=stops[0])return Number(values[0]);
  for(let i=1;i<n;i++)if(x<=stops[i])return blend(Number(values[i-1]),Number(values[i]),(x-stops[i-1])/(stops[i]-stops[i-1]));
  return Number(values[n-1]);
}
const lawOf=(instrument,variant,string,calibration=CALIBRATION)=>calibration.instruments?.[instrument]?.variants?.[variant%MODEL.variants]?.law?.strings?.[string];
const stopsOf=(law,dynamic)=>Array.isArray(law.stops)?law.stops:law.stops?.[dynamic]??[];
// A string's bow speed (m/s) at a dynamic: its law's where it has one, else bow.js's (BOW.speed).
export function speedOf(instrument,variant,dynamic,string,above=0,calibration=CALIBRATION){
  const law=lawOf(instrument,variant,string,calibration);
  return law?.speed?.[dynamic]?knotted(stopsOf(law,dynamic),law.speed[dynamic],above):fromCenti(BOW.speed[dynamic]);
}
// A string's force (N) at a dynamic, on a variant of an instrument, its note stopped `above` semitones over its open
// string, as `calibration` measured it: each of the model's variants its own forces (calibrate-strings-model.mjs
// --variants), each string two -- near its open pitch and stopped high on it -- read between them geometrically by how far
// up the note is stopped (Schelleng's least force rises with the pitch on one string: a violin's D string stopped a
// ninth up, bowed as its open pitch, spoke 220 ms after its bow); else its instrument's forces, measured on its first
// variant (on its second a cello's D string at mezzo-forte had gone raucous); else MODEL.force's. (`calibration`
// another, as a multiphonic's qualification bowed it: --pin.)
export function forceOf(instrument,variant,dynamic,string,above=0,calibration=CALIBRATION){
  const law=lawOf(instrument,variant,string,calibration);if(law?.force?.[dynamic])return knotted(stopsOf(law,dynamic),law.force[dynamic],above);
  const entry=calibration.instruments?.[instrument],measured=entry?.variants?.[variant%MODEL.variants],given=measured?.forces?.[dynamic]??entry?.forces?.[dynamic];
  const of=list=>Number(Array.isArray(list)?list[string]??list.at(-1):list);
  if(given==null)return MODEL.force[dynamic]*MODEL.forceScale[instrument];
  const low=of(given),high=measured?.forces?.[dynamic]!=null?of(measured?.high?.[dynamic]):NaN,at=measured?.at?.[string];
  if(!(Number.isFinite(high)&&at&&at.high>at.low))return low;
  return blend(low,high,clamp((above-at.low)/(at.high-at.low),0,1));
}
// A string's contact (beta) at a dynamic as its calibration has it, `above` semitones over its open pitch: its variant's
// where measured, else its instrument's -- one for every string, or each string's near its open pitch and stopped high on
// it ({low, high}), read between by how far up the note is stopped, as its force is (forceOf) -- else the measured
// players' (BOWED_LINE.contact) held within MODEL.contact (compileActions' contactAt, where no bow is given).
export function contactOf(instrument,variant,dynamic,string,above=0,calibration=CALIBRATION){
  const measured=calibration.instruments?.[instrument]?.variants?.[variant%MODEL.variants],own=measured?.contacts?.[dynamic]??calibration.instruments?.[instrument]?.contacts?.[dynamic];
  // (Its law's: its string's own by dynamic where it has them, else the law's one contact -- its ordinario.)
  const law=measured?.law;
  if(law){const knots=law.strings?.[string];if(knots?.contact?.[dynamic])return knotted(stopsOf(knots,dynamic),knots.contact[dynamic],above);if(law.contact!=null)return Number(law.contact)}
  if(own&&typeof own==='object'){const at=measured?.at?.[string],low=Number(own.low[string]),high=Number(own.high[string]);
    return at&&at.high>at.low?blend(low,high,clamp((above-at.low)/(at.high-at.low),0,1)):low}
  return Number(own??clamp(BOWED_LINE.contact[dynamic],...MODEL.contact));
}

// One seat's strokes (audio.js physicalStroke's log: {at, note, seconds, velocity, articulation, stroke, glide,
// glideFrom, released, string}) as the model's actions. -> {lines: [action lines], instrument, type, variant, warnings,
// kinds}. (`multiphonics`: the seat's multiphonics in place of the measured table's, for measuring
// them; `bows`: its bows by dynamic, {contact, force}, in place of the calibration's, for measuring them; `loure`: its
// louré, {seconds, speed, force}, in place of MODEL.loure's, for measuring it.) A stroke's
// `lead` (s), where its renderer heard it speak late (render/node/physical-strings.mjs): the stroke begun that much
// early, its window moved whole -- its attack, its change of bow, its finger -- its end kept, and the stroke before it,
// joined to it, ending as much earlier, so the two stay joined. `kinds`: each stroke's, by its place in `gestures` --
// 'silence' (begun from silence), 'change' (a change of bow), 'slur', 'crossing' (a slur or change of bow to another
// string), 'loure', 'pizzicato', or null where it never sounded.
// Resumed (`from`: {index, state}, one of an earlier compile's `checkpoints` of the same part, given the part's strokes
// from that one on): the lines the whole part's compile gives for those strokes, each stroke's own draws its own as there
// (its place in the part, `index` on). `origins`: the stroke (its place in the part) each line is for, a string's damping
// its pluck's; `checkpoints`: each bowed stroke begun from silence, where a compile may resume -- what it needs of the
// strokes before ({index, at, state}). A live player's part is streamed so (render/node/strings-stream.mjs), compiled
// again from its last settled stroke as its strokes come.
// A stroke's bow toward the bridge (its contact technique, `away` from -1 at the bridge to 0 ordinario) as measured to
// sound its dynamic (calibrate-strings-model.mjs --techniques: at each place its dynamic's force and speed scaled, nearest
// its ordinario's level, its notes speaking): {force, speed}, each a share of its ordinario's, between places by its
// distance from them (geometrically); 1 where unmeasured. Kept its ordinario's bow there, a viola's p at 0.07 of its string
// had sounded 2 to 8 dB over its ordinario, and Op. 3.36's 22-second pp poco sul pont. had swelled into Helmholtz motion
// 15 to 20 dB louder; no rule held: scaled by its contact's ratio, notes at 0.02 fell silent.
export function techniqueScale(instrument,dynamic,away,given=null){
  if(given)return given;
  const places=CALIBRATION.instruments?.[instrument]?.techniques;
  if(!(away<0)||!places)return {force:1,speed:1};
  const points=[[0,{force:1,speed:1}],...Object.keys(places).map(Number).filter(a=>a<0).sort((a,b)=>b-a).map(a=>[a,places[String(a)]?.[dynamic]??{force:1,speed:1}])];
  for(let k=1;k<points.length;k++){const [a,x]=points[k-1],[b,y]=points[k];
    if(away>=b-SAME){const w=(away-a)/(b-a),geo=(u,v)=>Math.exp(Math.log(u)+(Math.log(v)-Math.log(u))*w);return {force:geo(x.force,y.force),speed:geo(x.speed,y.speed)}}}
  return points.at(-1)[1];
}
// (The driver's lines whose change is moved over time (native/strings-model/musebots-strings.cpp), by kind, and how many
// values each takes before its span; read back, each line's kind, its time, its values, and where moved, its span and
// whether it is one straight segment of a curve.)
// A stroke's onset (MODEL.onset): from its articulation's point and its held bow ({speed, force}) the bow it lands with
// and is drawn at until its attack ends ({speed, force}), how near its own its attack's force begins (`from`, given
// its attackFrom share) and its decay back (s); null where its stroke carries no point. Its noise lands it heavier: an
// attack set lighter than its force set nearer it, one set heavier (its variant's attack model's share over one) left
// as heavy -- brought toward its force, the noisier of two strokes had landed the lighter.
export function onsetOf(point,held,from,onset=MODEL.onset){
  if(!point)return null;
  const weighted=1+onset.speed*point.weight,pressed=1+onset.force*point.noise;
  return {speed:held.speed*weighted,force:held.force*weighted*pressed,from:from<1?from+(1-from)*point.noise:from,decay:point.decay};
}
export const MOVED=Object.freeze({...COMPILER('moved')});
// The open strings as the model tunes an instrument's variant, measured (MIDI, lowest first): a finger's place is figured
// from them, so a pitch between the keys sounds where it is written.
export const opensOf=(instrument,variant)=>CALIBRATION.opens?.[instrument]?.[variant%MODEL.variants]??BOWED_INSTRUMENTS[instrument].strings;
export const readActions=lines=>lines.map(line=>{const [kind,t,...rest]=line.split('\t'),values=rest.map(Number),n=MOVED[kind];
  return n==null?{kind,t:Number(t),values}:{kind,t:Number(t),values:values.slice(0,n),span:values[n]??0,straight:values[n+1]===1}});
// (Whether stroke `g` goes on from a stroke that ended at `end`: slurred to it or a change of bow, begun within
// MODEL.joined of it -- a change's bite, its bow stopped on the string between the two, counted in. Not counted, a bite
// longer than MODEL.joined -- most of a section's at ff and fff (section-seat.js STROKE.bite) -- had left its bow lifted
// and its note attacked from silence, its bite never taken, 19 October 2026.)
const joinsAt=(g,end)=>(g?.stroke?.into!=null||g?.stroke?.change===true)&&Math.abs(g.at-end)<=MODEL.joined+(g.stroke?.change===true?Math.max(0,Number(g.stroke.bite)||0):0);
export function compileActions(gestures,{seat,variant=0,multiphonics=null,bows=null,onset:trial=null,pressure:pressureEnds=null,loure:pulse=null,technique=null,ringsDown=false,from=null,noise=null}={}){
  const LOURE={...MODEL.loure,...pulse};
  const instrument=instrumentOf(seat),{reach}=BOWED_INSTRUMENTS[instrument];
  const strings=opensOf(instrument,variant);
  const out=[],warnings=[],checkpoints=[],time=t=>Math.max(0,t).toFixed(4),share=x=>(+x).toFixed(5);
  // (Where it resumes: the strokes' places in the part from `base`, the state the strokes before left.)
  const base=from?.index??0,resumed=from?.state??null;let origin=null;
  // (A louré's half.)
  const loureHalf=LOURE.seconds/2;
  // (How long a bow takes to slow on a note (`pitch`): MODEL.follow of its periods, at least `least`, at most its share of
  // `within`.)
  const following=(pitch,least,within)=>Math.max(least,Math.min(MODEL.follow/hzOf(pitch),MODEL.followShare*within));
  // (How long a change of bow `g`'s bow is stopped on the string before it, the note before having ended at `end`: its
  // player's bite (its stroke's), never longer than the time between them; a tremolo's strokes never bitten.)
  const bitten=(g,end)=>g?.stroke?.change===true&&!g.stroke.tremolo?Math.max(0,Math.min(Number(g.stroke.bite)||0,g.at-end)):0;
  // (A change from `t` over `seconds` -- its kind's least at the shortest, the caller's transitionSeconds -- along
  // transitions.js's raised cosine, or, `straight`, one straight segment of a curve sampled more finely; where it ends
  // kept, the part's end never before its last change has.)
  const move=(t,seconds,straight,kind,...values)=>{const at=Math.max(0,t);
    out.push({t:at,end:at+seconds,origin,line:[kind,time(t),...values,seconds.toFixed(5),...(straight?['1']:[])].join('\t')})};
  // (A finger, a hand or a string's tension readied before a stroke or a pluck: its change ending where it was once set
  // at once, `ready` before.)
  const ready=transitionSeconds('finger');
  // (A stroke let go before it began never sounded -- a note its part left early, its next change of bow already sent:
  // its lift came before its bow, and the string was left bowed to the piece's end.)
  const list=gestures.map((g,index)=>({...g,index})).filter(g=>Number.isFinite(g.at)&&g.seconds>0&&!(Number.isFinite(g.released)&&g.released<=g.at)).sort((a,b)=>a.at-b.at);
  // (Each stroke's lead taken: never before the piece's start, nor before the stroke before it ends where the two are not
  // joined -- the bow lifted, then set again -- nor, joined, past half of that one.)
  list.forEach((g,k)=>{const asked=Math.max(0,Number(g.lead)||0);if(!asked)return;
    const prev=list[k-1],prevEnd=prev?Math.min(prev.at+prev.seconds,Number.isFinite(prev.released)?prev.released:Infinity):resumed?.lastEnd??-Infinity;
    const joinedTo=Boolean(prev&&joinsAt(g,prevEnd));
    const lead=Math.min(asked,g.at,joinedTo?prev.seconds/2:Math.max(0,g.at-prevEnd));if(!(lead>0))return;
    g.at-=lead;g.seconds+=lead;if(joinedTo){prev.seconds-=lead;if(Number.isFinite(prev.released))prev.released-=lead}});
  const kinds=gestures.map(()=>null);
  let string=null,previousString=null,direction=resumed?.direction??-1,bowing=false,lastEnd=resumed?.lastEnd??-Infinity,lastPitch=null,lastAt=-Infinity,under=null,place=MODEL.draw.start,drawing={bow:0,from:0,attacked:0};
  const tuned=resumed?[...resumed.tuned]:[1,1,1,1],lost=resumed?[...resumed.lost]:[1,1,1,1];
  // (Its player's noise: `noise` the seat's tree of temperatures (none given, a measured player's, 1). Its bow's in the
  // renders is its wandering (below), each kind's size times its temperature; its stopping finger's the engine's, asked at
  // the part's start.)
  const heatOf=path=>noise==null?1:temperatureAt(noise,path),heat={pressure:heatOf(PLAYER_NOISE.kinds.force.path),speed:heatOf(PLAYER_NOISE.kinds.speed.path),
    contact:heatOf(PLAYER_NOISE.kinds.contact.path)};
  // (Each string's hair as its last stroke bowed it: MODEL.hair from the part's start, a multiphonic's its own.)
  const hairs=resumed?.hairs?[...resumed.hairs]:Array(STRINGS).fill(hairOf(instrument));
  const plucking=CALIBRATION.pizzicato?.instruments?.[instrument];
  // (A string's losses: a plucked string's as measured, its own again once it is bowed -- each changed from `t` as a
  // hand's touch changes them, over a finger's least.)
  // (`said` false: a damping an earlier compile already gave, its string's losses only taken.)
  const losses=(t,s,ratio,said=true)=>{if(Math.abs(ratio-lost[s])>SAME){if(said)move(t,ready,false,'d',s,ratio.toFixed(4),'0');lost[s]=ratio}};
  const changed=g=>g?.stroke?.into!=null||g?.stroke?.change===true;
  // (A plucked string ringing to its note's end, {at, open}, damped there unless played again first: its losses raised so
  // its fundamental is down 60 dB in MODEL.damp's s, open or stopped.
  // Damped only where its hand's touch begins before the string's losses are readied again at `at`: begun after, it had
  // come after them, the string left damped under its bow.)
  const fundamentals=FUNDAMENTAL_LOSS[instrument],own=fundamentals[(variant%MODEL.variants)%fundamentals.length];
  // (Each its pluck's: {at, open, index}; one resumed with, damped where it was damped, by the compile it was plucked in.)
  const ringing=resumed?resumed.ringing.map(ring=>ring&&{...ring}):[null,null,null,null],damp=(s,at)=>{const ring=ringing[s];
    if(ring&&ring.at<at){const was=origin;origin=ring.index;losses(ring.at,s,LOSS_RATIO_FOR({db:T60,rate:own[s],seconds:MODEL.damp[ring.open?'open':'stopped']}),!(ring.index<base));origin=was}ringing[s]=null};
  list.forEach((g,index)=>{
    const end=Math.min(g.at+g.seconds,Number.isFinite(g.released)?g.released:Infinity),pitch=g.note;origin=base+index;
    // (A bowed stroke begun from silence: where a compile may resume, all it needs of the strokes before as they leave it.)
    if(g.articulation!=='pizzicato'&&!(bowing&&joinsAt(g,lastEnd)))
      checkpoints.push({index:base+index,at:g.at,state:{direction,tuned:[...tuned],lost:[...lost],hairs:[...hairs],ringing:ringing.map(ring=>ring&&{...ring}),lastEnd}});
    // (A natural harmonic only where the model sounds it, its string retuned within its measured region: asked further,
    // played ordinario, said -- retuned past it, it had sounded nothing.)
    let harmonic=naturalHarmonic(g.harmonic);
    if(harmonic&&harmonic.string==null){const near=harmonicNear(g.note,{instrument,variant,partial:harmonic.partial});
      if(near?.partial!==harmonic.partial){warnings.push(`${seat}: natural harmonic ${harmonic.partial} at ${g.note.toFixed(2)} lies past the model's measured strings; played ordinario`);harmonic=null}
      else harmonic={...harmonic,string:near.string}}
    const multi=!harmonic&&g.multiphonic?multiphonicOf(g.multiphonic,instrument,variant,multiphonics):null;
    if((harmonic||multi)&&g.articulation==='pizzicato')throw new RangeError('Plucked natural harmonics and multiphonics have not been qualified in the current Artifastring model');
    // (A velocity's bow: its speed (m/s), its contact and its force (N), each the two dynamics' it lies between.)
    // (Its force by dynamic, and by string where the calibration measured each string's: a heavier string's least force
    // in Schelleng's window is greater, and one force a dynamic had left a contrabass's lowest string unspoken.)
    // (Its force where its stroke is stopped on its string: forceOf; a bow given for measuring, as given.)
    // (A bow given as its law's forces near each string's open pitch and stopped high on it, {low, high, at}: read
    // between them by how far up its note is stopped, as forceOf reads a calibration's -- native/strings-model/
    // fit_bowing.py.)
    const forceAt=(d,s,above=0)=>{const given=bows?.[d]?.force;
      if(given&&typeof given==='object'&&!Array.isArray(given)){const at=given.at[s];
        return blend(Number(given.low[s]),Number(given.high[s]),clamp((above-at.low)/(at.high-at.low),0,1))}
      return given!=null?Number(Array.isArray(given)?given[s]??given.at(-1):given):forceOf(instrument,variant,d,s,above)},away=clamp(Number(g.contact)||0,-1,1);
    // (Its contact by dynamic: a bow given for measuring, as given; its variant's where measured, else its instrument's
    // -- one for every string, or each string's near its open pitch and stopped high on it ({low, high}: the player's
    // fit, native/strings-model/fit_player.py, each within the contacts its string holds Helmholtz motion at there),
    // read between by how far up the note is stopped, as its force is (forceOf, its variant's `at`); else the measured
    // players' (BOWED_LINE.contact) held within MODEL.contact. A contact given or measured is played where it is. (One
    // contact for every string and stop had none at ff on the violin: its E string's contacts holding Helmholtz motion
    // near its open pitch, 0.10-0.14, and a fourth up, 0.05-0.09, 20 October 2026.))
    const contactAt=(d,s,above=0)=>{const given=bows?.[d]?.contact;return given!=null?Number(given):contactOf(instrument,variant,d,s,above)};
    const pressure=harmonic?0:pressureOf(g.bowPressure);
    // (An attack from silence on its curve: its force set on the string at a share of its own (attackShare) and brought to
    // its own -- raised, or eased down from a share over one -- over a multiple of its attack time (attackReach), its
    // speed rising over the attack time. A bow given for
    // measuring, as given; else its variant's attack model (native/strings-model/regions.py attack_model): each a power
    // law of the attack's length in periods of its string, its held force against the string's Helmholtz force at its
    // speed and contact (F beta / 2 Z v, Schelleng's scale) and its contact, fitted to the curves on which its attacks
    // settled into Helmholtz motion fastest, held within the curves its search tried -- `held` the note's held bow
    // ({hz, speed, force, contact}); else its reach its attack time, and its share as the table its player's search had
    // mapped before 21 October 2026 (below).)
    const modelled=(model,value,s,seconds,held)=>{
      const x={one:1,periods:Math.log(seconds*held.hz),force:Math.log(HELMHOLTZ_FORCE_SCALE({force:held.force,contact:held.contact,Z:model.impedances[s],speed:held.speed})),contact:Math.log(held.contact)};
      return clamp(Math.exp(model.features.reduce((sum,name,k)=>sum+model[value][k]*x[name],0)),...model.range[value])};
    const attackReach=(d,s,seconds,above=0,held=null)=>{
      const given=bows?.[d]?.attackReach;if(given!=null)return Number(given);
      const model=CALIBRATION.instruments?.[instrument]?.variants?.[variant%MODEL.variants]?.attacks;
      return model?.features&&held?modelled(model,'reach',s,seconds,held):1};
    // (Its share, without a model: the middle of its region where its variant's player has one mapped -- by string,
    // dynamic and attack time, near its open pitch and an octave up, the shares at which this compiler's attack from
    // silence reaches Helmholtz motion within the transient
    // listeners accept (native/strings-model/regions.py attack_table) -- between its mapped attack times in their
    // logarithm, one with no region passed over, and between its stops by how far up the note is (its variant's `at`,
    // as its force); else the dynamic's as measured where the calibration found one; else MODEL's.)
    const attackShare=(d,s,seconds,above=0,held=null)=>{
      const given=bows?.[d]?.attackFrom;if(given!=null)return Number(given);
      const measured=CALIBRATION.instruments?.[instrument]?.variants?.[variant%MODEL.variants],table=measured?.attacks;
      if(table?.features&&held)return modelled(table,'from',s,seconds,held);
      const own=table?.from?.[d]?.[s];
      const middleOf=rows=>{const known=(rows??[]).map((r,k)=>[table.seconds[k],r]).filter(([,r])=>r);if(!known.length)return null;
        const middle=([,r])=>Math.sqrt(r[0]*r[1]),t=clamp(seconds,known[0][0],known.at(-1)[0]),k=Math.max(0,known.findIndex(([u])=>u>=t)-1),
          [a,b]=[known[k],known[Math.min(k+1,known.length-1)]];return a[0]===b[0]?middle(a):blend(middle(a),middle(b),Math.log(t/a[0])/Math.log(b[0]/a[0]))};
      const low=own?middleOf(own.low):null,high=own?middleOf(own.high):null,at=measured?.at?.[s];
      if(low!=null&&high!=null&&at&&at.high>at.low)return blend(low,high,clamp((above-at.low)/(at.high-at.low),0,1));
      if(low!=null||high!=null)return low??high;
      return Number(CALIBRATION.instruments?.[instrument]?.attackFrom?.[d]??MODEL.attackFrom)};
    const bowOf=(velocity,s,above=0)=>{
      const {dynamic,lower,upper,w,beyond}=dynamicsOf(velocity),speed=blend(speedOf(instrument,variant,lower,s,above),speedOf(instrument,variant,upper,s,above),w);
      const ordinario=blend(contactAt(lower,s,above),contactAt(upper,s,above),w);
      // (Its axis's ends its instrument's as fitted -- ponticello the nearest the bridge its notes keep their pitch, tasto
      // where its sound is darkest, toward the vibrating length's midpoint (native/strings-model/fit_player.py) -- else
      // MODEL's.)
      const ends=CALIBRATION.instruments?.[instrument]?.ends??MODEL;
      const contact=away?ordinario*((away<0?ends.ponticello:ends.tasto)/ordinario)**Math.abs(away):ordinario;
      if(harmonic)return {dynamic,speed:MODEL.harmonic.speed*speed/fromCenti(BOW.speed.mf),contact:MODEL.harmonic.contact,
        force:MODEL.harmonic.force*speed/fromCenti(BOW.speed.mf)};
      // (A multiphonic bowed as it was measured, at the nearest dynamic it keeps its bands at, its speed that dynamic's
      // and its force the one it held its bands under there (qualify-string-multiphonics.mjs `newtons`); one measured
      // before its newtons were kept, that dynamic's force as many times as it says -- a share of forces since measured
      // again, which moved under it: of the viola's 20, a third lost their bands.)
      if(multi){const at=d=>LINE.dynamics.indexOf(d),held=(multi.dynamics??['mf']).reduce((best,d)=>Math.abs(at(d)-at(dynamic))<Math.abs(at(best)-at(dynamic))?d:best);
        return {dynamic,speed:fromCenti(BOW.speed[held]),contact:multi.bow,force:Number(multi.newtons?.[held]??forceAt(held,s)*multi.force)}}
      // (Toward the bridge, its contact technique's bow as measured: techniqueScale, between its two dynamics'.)
      const [a,b]=[techniqueScale(instrument,lower,away,technique),techniqueScale(instrument,upper,away,technique)],held={force:blend(a.force,b.force,w),speed:blend(a.speed,b.speed,w)};
      return beyondBow(pressed({dynamic,speed:speed*held.speed,contact,force:blend(forceAt(lower,s,above),forceAt(upper,s,above),w)*Math.min(1,ordinario/contact)*held.force},pressure,instrument,pressureEnds),beyond,instrument);
    };
    // (Its phrase's curve through it, where its stroke has one (section-seat.js levelAt): its velocity every `step` s;
    // its bow at a time the curve's there.)
    const shape=g.stroke?.dynamics,shaped=Array.isArray(shape?.curve)&&shape.curve.length>1&&Number(shape.step)>0;
    // (Its bow's own wandering: each parameter slow sines at its player's own phases, and its hand's tremor -- a share of
    // its own.)
    const wander=(key,t,grown=1)=>{const drift=MODEL.draw.drift[key]*heat[key],slow=MODEL.draw.slow,own=t-drawing.from;let sum=0;
      slow.forEach((period,j)=>{sum+=Math.sin(2*Math.PI*(own/period+ownShare(`${seat}:${variant}:${drawing.bow}:${key}:${j}`)))});
      const hz=MODEL.draw.tremorHz[0]+(MODEL.draw.tremorHz[1]-MODEL.draw.tremorHz[0])*ownShare(`${seat}:${variant}:${drawing.bow}:${key}:tremor`);
      return grown*(drift*sum/Math.sqrt(slow.length)+MODEL.draw.tremor*heat[key]*Math.sin(2*Math.PI*(hz*own+ownShare(`${seat}:${variant}:${drawing.bow}:${key}:phase`))))};
    const joined=bowing&&joinsAt(g,lastEnd);
    const loure=joined&&!(g.stroke?.captured===false||g.stroke?.change)&&lastPitch!=null&&Math.abs(pitch-lastPitch)<LOURE.within;
    // (Its finger's path from its time, semitones from its pitch: its note's Per-Note Pitch Bend as a strings synth reads it
    // (bowed-midi2.js), else its glide or its vibrato as its engine logged them, as that writes them -- bendOf. Its first
    // pitch where its finger starts.)
    const bend=g.bend??bendOf(g),start=pitch+(bend?pointAt(bend,0):0),lowest=Math.min(start,pitch);
    const next=list[index+1],continues=Boolean(next&&joinsAt(next,end)&&next.articulation!=='pizzicato');
    let harmonicCents=0;
    if(harmonic){
      const measured=HARMONICS.instruments[instrument]?.[variant%MODEL.variants]??{},base=pitch-RATIO_SEMITONES({ratio:harmonic.partial});
      const feasible=Object.keys(measured).map(Number).filter(s=>Number.isFinite(measured[s]?.[harmonic.partial]));
      string=harmonic.string??feasible.reduce((best,s)=>best==null||Math.abs(base-strings[s])<Math.abs(base-strings[best])?s:best,null);
      if(string==null||!feasible.includes(string))throw new RangeError(`Natural harmonic ${harmonic.partial} on ${instrument} variant ${variant%MODEL.variants} string ${string}: no stable measured contact`);
      harmonicCents=measured[string][harmonic.partial];
      if(Math.abs(base-strings[string])>HARMONICS.retuneWarningSemitones||harmonic.node!==1)
        warnings.push(`${seat}: natural harmonic ${harmonic.partial}, string ${string}, node ${harmonic.node}; requested retuning/node outside the measured contact region`);
      if(shaped||Math.abs((g.velocity??LINE.velocity.mf)-HARMONICS.measuredVelocity)>HARMONIC_VELOCITY_WITHIN)
        warnings.push(`${seat}: natural-harmonic dynamics outside the measured mezzo-forte probe; musical controls retained, acoustic result not certified`);
    }else if(multi){string=multi.string;
      if(Math.abs(pitch-multi.pitches[0])>PITCH_WITHIN)warnings.push(`${seat}: multiphonic ${g.multiphonic.index} asked at ${pitch.toFixed(2)}; it sounds at its own ${multi.pitches[0].toFixed(2)}, its string not retuned`);
    }
    // (Its string kept where it is slurred to, or its held note's bow changed; a change of bow at a new note takes the
    // string a player first reaches for, as a player crosses strings at a change of bow -- kept, a violin's re-attack a
    // minor third up stayed high on its D string, speaking a fifth of a second late.) A stroke's own `string` (0 its
    // lowest), where its part asks one -- sul G, or a bow measured on one string -- taken where it reaches the pitch.
    else string=stringFor(lowest,strings,reach,Number.isInteger(g.string)?g.string:joined&&!g.stroke?.change?string:null);
    const crossed=joined&&previousString!=null&&string!==previousString;
    // (Its bow, on the string it takes.)
    // (How far above its open string the note is stopped: its force read there.)
    const above=harmonic||multi?0:Math.max(0,pitch-strings[string]);
    const here=bowOf(g.velocity??LINE.velocity.mf,string,above),{dynamic,speed,contact}=here,force=here.force.toFixed(3);
    const bowAtTime=t=>shaped?bowOf(shape.curve[clamp(Math.round((t-g.at)/shape.step),0,shape.curve.length-1)],string,above):here;
    // (Each stop a finger, or the open string tuned to the pitch; a string's tension set back once a finger stops it again.)
    const centsAt=fingerCentsOf(instrument,variant,string),offOpen=stopFor(pitch,strings[string],centsAt).finger>0;
    // (A multiphonic's light contact where it was measured, its string as its variant tunes it.)
    // (Each moved from `t` over `seconds` -- a finger's least where none is asked -- its string's tension with it.)
    const finger=(t,p,seconds=ready,straight=false)=>{const {finger:x,tune}=harmonic?harmonicStopFor(p,strings[string],harmonic,harmonicCents)
        :multi?{finger:multi.position,tune:1}:stopFor(p,strings[string],centsAt,{stopped:offOpen});
      if(Math.abs(tune-tuned[string])>TUNE_WRITTEN){move(t,seconds,straight,'t',string,tune.toFixed(7));tuned[string]=tune}
      if(harmonic)move(t,seconds,straight,'h',string,share(x),MODEL.harmonic.firmness);else if(multi)move(t,seconds,straight,'h',string,share(x),multi.firmness);else move(t,seconds,straight,'f',string,share(x));};
    // (A pluck asked early by as long as the model pulls the string, so it sounds at its time; at its calibrated place,
    // pull and string losses, readied to be there 5 ms before.)
    if(g.articulation==='pizzicato'){
      const at=g.at-MODEL.pluckLead,readied=at-READY_BEFORE-ready;damp(string,readied);losses(readied,string,plucking?.losses?.[string]??1);finger(readied,pitch);
      // (Its finger's grip and pull taken over a finger's least, never at once: a still string had ticked as the pull
      // began, a ringing one clicked as the grip closed on it.)
      move(at,ready,false,'p',string,share(plucking?.position??MODEL.pluck.position),Number(plucking?.pull?.[dynamic]??MODEL.pluck.pull[dynamic]).toFixed(3));bowing=false;lastEnd=end;kinds[g.index]='pizzicato';
      ringing[string]={at:end,open:stopFor(pitch,strings[string],centsAt).finger===0,index:base+index};return}
    // (Its articulation's point, where its stroke carries one: MODEL.onset. From silence, its grip: its bow set on the
    // string and pressed still for its bite before it is drawn -- never before the stroke before has left the string, nor
    // before the piece begins -- its string and its finger readied before it lands.)
    const point=articulationOfStroke(g.stroke),lift=transitionSeconds('bowLift');
    const grip=!joined&&point?Math.max(0,Math.min(Number(g.stroke.bite)||0,g.at-Math.max(0,lastEnd)-lift-ready)):0;
    damp(string,g.at-DAMP_BEFORE-ready-grip);losses(g.at-DAMP_BEFORE-ready-grip,string,1);
    // The finger: where the stroke starts (a slur's change from its time, a fresh stroke's there just before the bow), then
    // along its path -- a slide, a vibrato -- a step at a time, each a straight segment to where its path is a step on.
    finger(joined?g.at:g.at-READY_BEFORE-ready-grip,start);
    // (Its hair: a multiphonic's as it was measured -- MULTIPHONICS.hair where its qualification says, else a point, as
    // every qualification so far bowed it (scripts/qualify-string-multiphonics.mjs), a player's bow tilted to a few hairs
    // -- every other stroke's MODEL.hair; moved as its finger is. Bowed with the whole hair, 42 of the 90 measured had lost
    // their bands, against 81 with a point (claude-scratch/strings-model/multiphonic-hair.mjs, 19 October 2026).)
    const width=multi?Number(MULTIPHONICS.hair??0):hairOf(instrument);
    if(Math.abs(width-hairs[string])>SAME){move(joined?g.at-MODEL.reversal/2:g.at-READY_BEFORE-ready-grip,ready,false,'x',string,width.toFixed(4));hairs[string]=width}
    // (Its last step begun before the next note's finger, there or readied before its stroke: begun after, a step that
    // ran on toward this note's pitch came after the next note's finger, and took it back.)
    const fingered=Math.min(end,!next?Infinity:continues?next.at:(next.articulation==='pizzicato'?next.at-MODEL.pluckLead:next.at)-READY_BEFORE-ready);
    // (A multiphonic's finger held still: it slides and vibrates nowhere.)
    if(!multi&&bend)for(let t=g.at+MODEL.step;t<fingered;t+=MODEL.step)finger(t,pitch+pointAt(bend,t+MODEL.step-g.at),transitionSeconds('finger',MODEL.step),true);
    // The bow: set on the string with its attack (its swell the stroke's), reversed at a change of bow, carried on under
    // a slur while only the finger moves.
    // (Crossing to another string under a slur or a change of bow, the string it leaves let go to ring as it takes the
    // new one: the model's moving bow, unlike its set one, lets go of no string, and one it left went on bowed to the
    // piece's end -- Op. 3.7's "dissonant strings drone that persists beyond the rest of the music", 52 of its 60 players.)
    // (Its bow where its stroke set it, under a slur on one string: the finger moves under the bow, which stays where it
    // is -- its contact its stroke's share of the string its first note stopped. Placed again at each note's own share,
    // the bow had leapt along the string at every finger's change -- a tenth of its distance from the bridge on a slur up a
    // step -- and the model's string broke off its motion there: the legato test's slurs within one bow dipping 6 to 10
    // dB on the violin, the cello and the contrabass, at every force their calibration tried, 11 October 2026.)
    const stopped=harmonic||multi?0:stopFor(pitch,strings[string],centsAt).finger;
    const held=joined&&!crossed&&!(g.stroke?.captured===false||g.stroke?.change)&&drawing.stopped!=null?drawing.stopped:stopped;
    const bowed=share(bowAt(contact,held));previousString=string;
    // (Every bow of a stroke before its end, lifted there, or before the next's change of bow begins, joined to it: an
    // attack or a reversal longer than the stroke cut there -- one that ran on past it bowed again the string the next
    // had crossed from, Op. 3.9's remade contrabasses. `latest`, its last.)
    // (Before a louré, its pulse: the next note's own.)
    const pulsed=continues&&!(next.stroke?.captured===false||next.stroke?.change)&&Math.abs(next.note-pitch)<LOURE.within;
    // (Before a change of bow, until the bow begins to slow for it: half its reversal before this stroke ends, or before
    // the next begins where this one runs on to it.)
    const reversing=continues&&(next.stroke?.captured===false||next.stroke?.change),nextHalf=next?.stroke?.tremolo?Math.min(MODEL.reversal,MODEL.tremoloReversal*next.seconds)/2:MODEL.reversal/2;
    // (Before a change of bow after a bite, the bow slows to its stop over its own slowing: following; before one not
    // bitten, it is drawn on to the change's reversal.)
    const nextStop=reversing?bitten(next,end):0,nextSlow=nextStop>INSTANT?following(pitch,nextHalf,end-g.at):nextHalf;
    let latest=-Infinity;const limit=(continues?reversing?next.at-nextStop-nextSlow:Math.min(end,next.at-(pulsed?Math.max(loureHalf,following(pitch,0,end-g.at)):MODEL.reversal/2)):end)-INSTANT;
    // (The string the bow was on, where it leaves it for this one: lifted from it as it reaches this one, over as long,
    // at the speed it had there.)
    const onto=(t,span)=>{if(under&&under.string!==string)move(t,Math.max(span,transitionSeconds('stringCrossing')),false,'b',under.string,under.at,'0',under.v.toFixed(4))};
    // (The bow moving toward `v` over `seconds`, its force moved to `f` and its place to `at` over `span`. `latest`, where
    // the last of these ends.)
    const bow=(t,v,seconds,f=force,at=bowed,span=transitionSeconds('bowForce'))=>{
      if(t>limit)return;
      onto(t,span);under={string,at,v};latest=Math.max(latest,t+span);
      move(t,span,false,'a',string,at,Number(f).toFixed(3),v.toFixed(4),(Math.abs(v)/Math.max(LEAST_ACCELERATING,seconds)).toFixed(3));
    };
    // (Its attack: the bow set on the string at `from` of its force -- from none, a bow's weight taking the least it may
    // (transitions.js bowLift) -- then its force raised to its own over the rest of its attack, its speed rising over the
    // whole of it.)
    // (Its onset, where its stroke carries a point, the bow it is drawn with and how near it its force begins: onsetOf.)
    // (Its onset's {speed, force} a fit's trial (`onset`), else the fitted ones, else MODEL.onset's.)
    // (Its attack time, its stroke's (s), never more than `attackShare` of its note.)
    const attackTime=Math.max(LEAST_ATTACK,Math.min(g.stroke?.attack??MODEL.attack,MODEL.attackShare*(end-g.at)));
    // (Its held bow, as its attack's curve is read: its string's pitch where it is stopped.)
    const heldBow={hz:hzOf(strings[string]+above),speed,force:Number(force),contact};
    const onset=onsetOf(point,{speed,force:Number(force)},attackShare(dynamic,string,attackTime,above,heldBow),trial??ONSETS.instruments?.[instrument]?.[dynamic]??MODEL.onset);
    // (Its force brought to its own over `reach` times its attack time, never past half its note where that is longer
    // than its attack. -> when it is there. A stroke with a point reaches its onset's force over the same reach, its
    // variant's attack model's: reached over its attack time alone, a legato start from silence -- no excess -- had been
    // another attack than a stroke with no point, once its variant had a model.)
    const attacking=(attack,from,{speed:v=speed,force:f=force,reach:over=1}={})=>{
      const rising=Math.min(over*attack,Math.max(attack,MODEL.attackShare*(end-g.at)));
      if(rising-lift<transition('bowForce').least){bow(g.at,direction*v,attack,f,bowed,Math.max(rising,lift));return g.at+Math.max(rising,lift)}
      bow(g.at,direction*v,attack,f*from,bowed,lift);bow(g.at+lift,direction*v,attack,f,bowed,rising-lift);return g.at+rising};
    // (Its onset eased back to its held bow from `t`, where its bow has reached its onset -- its speed over its attack, its
    // force over its reach -- over its decay: its speed changing at the rate that takes, its force along the raised
    // cosine.)
    const easeBack=t=>{if(!(onset.speed>speed+SAME||onset.force>Number(force)+SAME))return;
      const easing=Math.max(onset.decay,transition('bowForce').least);
      bow(t,direction*speed,onset.speed>speed+SAME?speed*easing/(onset.speed-speed):easing,force,bowed,transitionSeconds('bowForce',easing))};
    if(!joined){
      // (Begun from silence: its speed rising over its attack and its force with it.)
      // (Its force from a share of its own, the dynamic's as measured where the calibration found one: a heavy bow begun
      // light had settled into Helmholtz motion only 100 to 300 ms after it began.)
      // (Its attack no longer than half its note: a pianissimo's quarter-second swell over a note of a tenth never reached
      // its bow, and Op. 3.36's quick soft notes sounded unpitched.)
      direction=-direction;const attack=attackTime;place=direction>0?MODEL.draw.start:1-MODEL.draw.start;
      if(!onset)attacking(attack,attackShare(dynamic,string,attack,above,heldBow),{reach:attackReach(dynamic,string,attack,above,heldBow)});
      else{
        // (Gripping: the lifted bow brought to rest off the string, then set on it still at its onset's force.)
        if(grip>0){move(g.at-grip-lift-ready,ready,false,'b',string,bowed,'0','0.0000');move(g.at-grip-lift,lift,false,'b',string,bowed,onset.force.toFixed(3),'0.0000');
          under={string,at:bowed,v:0};latest=Math.max(latest,g.at-grip)}
        easeBack(attacking(attack,onset.from,{...onset,reach:attackReach(dynamic,string,attack,above,heldBow)}));
      }
    }
    else if(g.stroke?.captured===false||g.stroke?.change){
      // (A change of bow: through zero at its time, the bow taking the string again a little heavier.)
      // (A tremolo's strokes reverse as quickly as they are short: their reversal at most `tremoloReversal` of each, and
      // even, none bitten heavier than the rest -- each stroke's accent had made its tremolo a rattle.)
      // (Where its player bit -- the bow stopped before it takes the string again, its stroke's `bite` (section-seat.js
      // STROKE.bite), the note before let go that much early -- the bow slowed to a stop that long before this note's
      // time, held still on the string at its weight until then, its grip stopping the string, and then drawn the other
      // way: reversed through zero at once, a cello's string had rung on through every change of bow, a stroke of its own
      // no more marked than a slur. Where it did not, reversed through zero at its time, the bow drawn on to it: bitten.)
      direction=-direction;const half=(g.stroke?.tremolo?Math.min(MODEL.reversal,MODEL.tremoloReversal*(end-g.at)):MODEL.reversal)/2,bite=g.stroke?.tremolo?1:g.stroke?.change?MODEL.bite.change:MODEL.bite.held;
      // (Slowed on the string it was on, as it ends; crossing to another, the bow then set on that one still, catching it,
      // before it is drawn: drawn at once from rest on a string still ringing, the new string had caught as chaotically as
      // its ringing went -- a violin's begun 36 ms earlier spoke 145 ms later.)
      // (Stopped, it is drawn again from rest as a stroke from silence is, its speed rising over its attack and its force
      // from a share of its own with it: drawn at once under its bite, a stopped string had caught as chaotically -- a
      // violin's change begun 36 ms earlier spoke 145 ms later.)
      // (Where its stroke carries a point, its grip and its reversal at its onset's force, drawn at its onset's speed and
      // eased back over its decay: MODEL.onset.)
      const stop=bitten(g,lastEnd),on=under??{string,at:bowed},slow=stop>INSTANT?following(lastPitch,half,lastEnd-lastAt):half,gripped=onset?onset.force:force*bite;
      if(stop>INSTANT){const slowing=transitionSeconds('bowForce',slow),stopped=g.at-stop;
        move(stopped-slow,slowing,false,'a',on.string,on.at,gripped.toFixed(3),(0).toFixed(4),(speed/Math.max(LEAST_ACCELERATING,slow)).toFixed(3));
        under={string:on.string,at:on.at,v:0};latest=Math.max(latest,stopped-slow+slowing);
        if(crossed)bow(stopped,0,half,gripped,bowed,transitionSeconds('stringCrossing'));
        const attack=attackTime;
        if(onset)easeBack(attacking(attack,onset.from,{...onset,reach:attackReach(dynamic,string,attack,above,heldBow)}));else attacking(attack,attackShare(dynamic,string,attack,above,heldBow),{reach:attackReach(dynamic,string,attack,above,heldBow)});}
      else{const biting=transitionSeconds('bowForce',half);
        if(onset){bow(g.at-half,direction*onset.speed,half,onset.force,bowed,biting);easeBack(g.at+half)}
        else{bow(g.at-half,direction*speed,half,force*bite,bowed,biting);bow(g.at+half+MODEL.biteFor,direction*speed,half,force,bowed,biting)}}
    }
    else if(loure){
      // (Louré: the bow slowed and lightened round the note's time and back, going on the same way -- each move as quick
      // as its own change over its half: bow() takes a speed's whole over the time it is given, and a bow slowed to a
      // twentieth that way had hardly slowed at all. Its weight eased off and back as quickly as a bow's force may change
      // (transitions.js bowForce), held light between: eased over its whole half, the bow had been at its lightest for an
      // instant only, and a cello's repeated pitch was heard as one note with the one before, 18 October 2026.)
      const half=Math.max(loureHalf,following(lastPitch,0,g.at-lastAt)),k=LOURE.speed,lightening=transitionSeconds('bowForce');
      bow(g.at-half,direction*speed*k,half*k/(1-k),force*LOURE.force,bowed,lightening);bow(g.at,direction*speed,half/(1-k),force,bowed,lightening);
      // (Its pulse its own until its bow is back to its speed, its drawn bow resumed after.)
      latest=Math.max(latest,g.at+half);
    }
    else bow(g.at,direction*speed,MODEL.slur,force,bowed,transitionSeconds('bowForce',MODEL.slur));
    kinds[g.index]=!joined?'silence':crossed?'crossing':g.stroke?.captured===false||g.stroke?.change?'change':loure?'loure':'slur';
    bowing=true;
    // (Its release's span, its player's own, and where it begins: once its attack or its reversal has taken the string --
    // a tremolo's stroke is shorter than a release.)
    const [least,most]=MODEL.release,span=least+(most-least)*ownShare(`${seat}:${variant}:${base+index}`);
    // (A stroke left on the string its rest: its bow slowing to a stop as it ends, over as long as its note takes to follow
    // it, drawn until its stop begins -- drawn on to where a release would have begun, a stop longer than that release had
    // been taken over by the drawn bow's next segments.)
    // (Its player's rest where it chose one; else its instrument's measured players': releaseOf.)
    const chosen=g.stroke?.rest!=null&&Number.isFinite(Number(g.stroke.rest))?Number(g.stroke.rest):releaseOf(instrument,g.velocity??LINE.velocity.mf);
    const rest=continues?0:Math.max(0,chosen),stop=rest>0?following(pitch,MODEL.reversal,end-g.at):0;
    const from=continues?null:rest>0?Math.max(g.at,end-stop):Math.min(end,Math.max(g.at+Math.min((end-g.at)/2,RELEASE_AFTER),end-span,latest+INSTANT));
    // Through it, from once its attack or reversal has taken the string to its release, or to the next stroke's change:
    // its phrase's curve, the bow's speed, force and place moving as its dynamic does, and the bow drawn as no bow holds
    // one the same (MODEL.draw) -- its weight with its place along it, its speed, weight and place wandering, its hand's
    // tremor -- a step at a time, each a straight segment to where they are a step on.
    const drawn=!multi&&!g.stroke?.tremolo&&end-g.at>=MODEL.draw.least,every=shaped?Math.min(shape.step,MODEL.draw.step):MODEL.draw.step;
    const segment=transitionSeconds('bowForce',every);
    const draw=(t,v,f,at)=>{if(t>limit)return;onto(t,segment);under={string,at,v};latest=Math.max(latest,t+segment);
      move(t,segment,true,'b',string,at,Number(f).toFixed(3),v.toFixed(4))};
    // (A new bow -- from silence, or a change of bow -- its own wandering from its attack's end; a slur's or a louré's, the
    // bow's going on.)
    if(!joined||g.stroke?.captured===false||g.stroke?.change)drawing={bow:base+index,from:g.at,attacked:latest,stopped};
    else if(crossed)drawing={...drawing,stopped};
    const placeAt=t=>clamp(place+direction*here.speed*(t-g.at)/MODEL.draw.length[instrument],0,1),attacked=drawing.attacked;
    if(shaped||drawn)for(let t=g.at+every*Math.max(1,Math.floor((latest-g.at)/every)+1);t<(from??limit);t+=every){
      const u=t+every,b=bowAtTime(u);if(!drawn){draw(t,direction*b.speed,b.force,share(bowAt(b.contact,held)));continue}
      const grown=Math.min(1,Math.max(0,(u-attacked)/MODEL.draw.settle)),frog=1+grown*MODEL.draw.frog*(Math.max(0,1-placeAt(u)/FROG_MIDDLE)-FROG_MIDDLE/2);
      // (Never slower than the slowest bow that holds a tone, where its own is not.)
      // (Its place wandering within MODEL.contact, or about its own where its stroke sets it beyond: held within
      // MODEL.contact alone, a sul ponticello's bow at 0.02 of the string had been drawn to 0.06 once its attack ended.)
      const pressing=wander('pressure',u,grown),slowest=fromCenti(slowestBowOf(instrument));
      const speed=b.speed<slowest?b.speed:Math.max(slowest,b.speed*(1+MODEL.draw.coupled*pressing+wander('speed',u,grown)));
      draw(t,direction*speed,b.force*frog*(1+pressing),share(bowAt(clamp(b.contact*(1+wander('contact',u,grown)),Math.min(MODEL.contact[0],b.contact),Math.max(MODEL.contact[1],b.contact)),held)));
    }
    place=placeAt(end);
    // Its end: joined to the next stroke, nothing; stopped on the string where its stroke rests there (MODEL.lifted);
    // else the bow slowed and lifted, the string left to ring.
    if(rest>0){
      const b=bowAtTime(from),at=share(bowAt(b.contact,held));
      onto(from,transitionSeconds('bowForce'));
      move(from,transitionSeconds('bowForce',stop),false,'a',string,at,Number(b.force).toFixed(3),'0.0000',(b.speed/Math.max(LEAST_ACCELERATING,stop)).toFixed(3));
      const lift=Math.max(end,Math.min(end+rest,next?next.at-MODEL.lifted:Infinity));
      if(Number.isFinite(lift))move(lift,transitionSeconds('bowLift'),false,'b',string,at,'0','0');
      bowing=false;under=null;
    }
    else if(!continues){
      // (Its force eased to nothing as the bow still moves, over its player's own span, from where its curve has it -- the
      // bow leaving the string as its force reaches nothing: the string rings on.)
      const b=bowAtTime(from),at=share(bowAt(b.contact,held));
      onto(from,transitionSeconds('bowLift'));
      move(from,transitionSeconds('bowLift',end-from),false,'a',string,at,'0.000',(direction*b.speed).toFixed(4),(b.speed/Math.max(LEAST_ACCELERATING,span)).toFixed(3));
      bowing=false;under=null;
    }
    lastEnd=end;lastPitch=pitch;lastAt=g.at;
  });
  origin=null;for(let k=0;k<STRINGS;k++)damp(k,Infinity);
  // (Its end: where its last change ends, where the driver rings the part down from there until it is silent (`ringsDown`,
  // its capabilities': render/node/physical-strings.mjs); else 3 s after it, the strings turned off where they fell quiet.)
  const last=Math.max(0,...out.map(entry=>entry.end??entry.t))+(ringsDown?0:TAIL);
  // (The bow's hair on every string, MODEL.hair, and the stopping finger's noise, the engine's to draw (n), at the
  // part's first action and before it, as that action's stroke's: a stream or a bridge that starts a part at its first
  // action takes them there, never late nor before its time, and a stream that resumes from a checkpoint settles them
  // with that stroke -- strings-stream.mjs StringsPart.)
  if(!resumed&&out.length){const first=out.reduce((a,b)=>b.t<a.t?b:a);
    out.unshift(...Array.from({length:STRINGS},(_,s)=>({t:first.t,end:first.t,origin:first.origin,line:['x',time(first.t),s,hairOf(instrument).toFixed(4),(0).toFixed(5)].join('\t')})),
      {t:first.t,end:first.t,origin:first.origin,line:['n',time(first.t),...noiseFields('finger',heatOf(PLAYER_NOISE.kinds.finger.path))].join('\t')})}
  const sorted=out.sort((a,b)=>a.t-b.t),lines=sorted.map(entry=>entry.line);lines.push(`w\t${last.toFixed(4)}`);
  return {lines,origins:[...sorted.map(entry=>entry.origin),null],instrument,type:MODEL.types[instrument],variant:variant%MODEL.variants,warnings,kinds,checkpoints};
}
