// How loud each instrument sounds, from its measured sound power (sound-power.json: TU Berlin's anechoic database,
// Weinzierl et al. 2017, DOI 10.14279/depositonce-5861.2; render/synthesis/tools/sound_power_table.py), so that a
// render's parts stand to one another as the instruments do, and a note's written dynamic is the one heard (the owner,
// 8 October 2026, of Op. 3.32: "notated dynamics sometimes diverge completely from heard dynamics (e.g., notated ppp but
// heard fff)"; "scored instruments simply don't sound ... the final pages' violin and viola parts"). Measured there, its
// cellos 21 dB and its violas 8 dB under its violins at every dynamic: their model's levels had been matched to their
// recordings', whose sessions were recorded at levels of their own (the Iowa cello's mf 10 dB under its violin's), where
// a cello radiates 3 dB more than a violin at ff.
import SOUND_POWER from './sound-power.json' with {type:'json'};
import {DYNAMICS,DYNAMIC_VELOCITY,BEYOND,beyondOf} from '../dynamics.js';
import {GIVEN_BOWED,airHz,bowedOf,bySize} from './bowed-instruments.js';
import {setting} from '../../../registry/registry.js';
export {SOUND_POWER};

// An instrument's measured entry (sound-power.json), or a bowed instrument's given as data (bowed-instruments.js) derived
// from the measured bowed instruments': at each of pp and ff, its level, its slope and its scatter read between theirs
// by the body's lowest air mode (bySize, in decibels, in a line), its median pitch and its compass as far from its lowest
// open string as theirs from their own -- a body's radiation its size's, its notes at the same places on its strings.
// null where neither.
const MEASURED_BOWED=['violin','viola','cello','contrabass'];
function derivedEntry(name){
  const lowest=n=>bowedOf(n).opens[0],read=(dynamic,get)=>bySize(Object.fromEntries(MEASURED_BOWED.map(n=>[n,get(SOUND_POWER.instruments[n][dynamic],n)])),name,airHz,{linear:true});
  const at=dynamic=>Object.freeze({db:read(dynamic,d=>d.db),dbPerSemitone:read(dynamic,d=>d.dbPerSemitone),scatterDb:read(dynamic,d=>d.scatterDb),
    pitch:lowest(name)+read(dynamic,(d,n)=>d.pitch-lowest(n)),
    compass:Object.freeze([lowest(name)+read(dynamic,(d,n)=>d.compass[0]-lowest(n)),lowest(name)+read(dynamic,(d,n)=>d.compass[1]-lowest(n))])});
  return Object.freeze({label:`${name} (derived from the measured bowed instruments by size)`,derived:true,pp:at('pp'),ff:at('ff')});
}
const DERIVED=Object.freeze(Object.fromEntries(GIVEN_BOWED.map(i=>[i.name,derivedEntry(i.name)])));
export const soundPowerOf=instrument=>SOUND_POWER.instruments?.[instrument]??DERIVED[instrument]??null;

// The velocities the score writes pp and ff at (the middles of their marks: notation/score.js DYNAMICS), where a note
// sounds its instrument's measured pp and ff.
const middle=mark=>{const k=DYNAMICS.findIndex(([name])=>name===mark);return ((k?DYNAMICS[k-1][1]:0)+DYNAMICS[k][1])/2};
export const MEASURED_AT=Object.freeze({pp:middle('pp'),ff:middle('ff')});
// A modelled part's audio (its held notes' RMS, dBFS, as it enters its player's channel) of an instrument radiating a
// sound power level of L dB is L plus this: the loudest instrument measured, the tuba, at its ff (112.3 dB at its
// median pitch) 18 dB under full scale, so that a section of brass at ff stays under each player's limiter (audio.js
// BOT_LIMITER, past its channel's +3.7 dB) and its fff high in its compass reaches it. The bowed strings' violin at ff
// then stands 5 dB under where its model stood before (8 October 2026: -37.54 dBFS, its stem gain matched to its
// recordings): registry/method/levels.json `stem-level`, its reason there.
export const STEM_REFERENCE_DB=setting('stem-level','reference');

// An instrument's sound power level (dB re 1 pW) at a velocity and a pitch: its pp's and ff's lines through its notes,
// at the pitch (within the notes measured), interpolated in decibels between the velocities their marks are written at,
// and on to ppp's and fff's centres along the same line; beyond them, in the uncomfortable range, each mark further
// (dynamics.js beyondOf, continuous) moving it BEYOND.shrink as much as the one before, the first `shrink` of the step its
// scored range's last mark there took (ppp's from pp's, fff's from ff's) -- converging, so that its scored range is never
// moved by the marks beyond it. null where the instrument is not measured.
export function soundPowerDb(instrument,velocity,pitch=null){
  const entry=soundPowerOf(instrument);
  if(!entry?.pp||!entry?.ff)return null;
  const at=d=>{const p=Number.isFinite(pitch)?Math.max(d.compass[0],Math.min(d.compass[1],pitch)):d.pitch;return d.db+d.dbPerSemitone*(p-d.pitch)};
  const line=v=>at(entry.pp)+(at(entry.ff)-at(entry.pp))*(v-MEASURED_AT.pp)/(MEASURED_AT.ff-MEASURED_AT.pp);
  const v=Number.isFinite(velocity)?Math.max(0,Math.min(BEYOND.loudest,velocity)):MEASURED_AT.ff,beyond=beyondOf(v);
  if(!beyond)return line(v);
  const {ppp,pp,ff,fff}=DYNAMIC_VELOCITY,q=BEYOND.shrink,k=Math.abs(beyond),far=q*(1-q**k)/(1-q);
  return beyond<0?line(ppp)-(line(pp)-line(ppp))*far:line(fff)+(line(fff)-line(ff))*far;
}
// The level a note's held part sounds at in a render's stem (RMS, dBFS), or null where its instrument is not measured.
export const stemLevelDb=(instrument,velocity,pitch=null)=>{const db=soundPowerDb(instrument,velocity,pitch);return db===null?null:db+STEM_REFERENCE_DB};
