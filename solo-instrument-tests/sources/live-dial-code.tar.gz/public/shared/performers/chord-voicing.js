// A chord voiced within itself, for any player whose chord's notes are struck together or strummed (the user, 29
// September 2026: "notes within chords are also subject to 'voicing', to relative force and velocity, relative to other
// notes in those same chords; musically, these 'voicings' within chords should produce subtle senses of melody from
// chord to chord as some notes receive more emphasis"): which note a player brings out, and a velocity that many dB
// louder. How the notes are timed is the instrument's own: a pianist's hammers reach their strings in their own times
// (piano_clodbot.js voiceChord), a guitarist's pick crosses the strings in its stroke's order (guitar_clodbot.js).
import {velocityAmplitude} from '../articulation.js';

const clamp01=value=>Math.max(0,Math.min(1,value));

// The note of a chord (pitches low to high) a player brings out: its top voice, the melody; but where the top holds (the
// chord before had it too) and another voice moves by step, that voice, so that the notes brought out make a line from
// chord to chord. Given the note brought out last (`line`), an inner line goes on in its own voice while the top holds:
// the voice a step from it (or holding it, where none steps) is brought out again, rather than the line leaping back to
// the top and down again. Where the chord's lowest note is the texture's bass (`bass`: a guitarist's chord with no
// bassist), it is never the line: players keep the bass well under the melody (Freire, Nézio & dos Reis 2014,
// doi:10.5281/zenodo.850753: "the bass line is played with amplitudes considerably lower than that of the melody").
// -> its index.
export function broughtOut(pitches,previous=null,line=null,{bass=false}={}){
  const top=pitches.length-1,lowest=bass?1:0;
  if(!previous?.length||top<1||Math.abs(pitches[top]-previous.at(-1))>1e-6)return top;
  if(Number.isFinite(line)&&Math.abs(line-pitches[top])>1e-6){
    let held=null,stepped=null;
    for(let index=top-1;index>=lowest;index--){
      const moved=Math.abs(pitches[index]-line);
      if(moved<=1e-6)held??=index;else if(moved<=2+1e-6)stepped??=index;
    }
    if(stepped!==null||held!==null)return stepped??held;
  }
  let best=null;
  for(let index=top-1;index>=lowest;index--){
    const moved=Math.min(...previous.map(pitch=>Math.abs(pitches[index]-pitch)));
    if(moved>1e-6&&moved<=2+1e-6){best=index;break}
  }
  return best??top;
}

// The velocity of a note `db` louder than one at `velocity`, on an instrument whose level follows velocity as
// articulation.js velocityAmplitude has it (a square law over its dynamic range `rangeDb`, or its measured `exponent`);
// full velocity at most, so a chord already at full force brings its note out less.
export function louderBy(velocity,db,{rangeDb=30,exponent=2}={}){
  const p=Math.max(1,exponent),a=10**(-Math.max(1,rangeDb)/(20*p)),base=a+(1-a)*clamp01(velocity);
  return clamp01((base*10**(db/(20*p))-a)/(1-a));
}

// How much louder one velocity sounds than another (dB), on the same instrument.
export const levelDifference=(louder,softer,{rangeDb=30,exponent=2}={})=>
  20*Math.log10(velocityAmplitude(louder,rangeDb,exponent)/velocityAmplitude(softer,rangeDb,exponent));
