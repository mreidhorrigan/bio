// Planning while the music plays (the odd/prime rudiments report's M4: §10.1, §11.1; its T38). A plan made live has a
// wall-clock deadline, an incumbent that is valid before any search begins (the fallback its caller authorizes), and
// contacts already committed (sent to the renderer), which no later plan rewrites. An offline render has no deadline,
// so what it plays never depends on how fast the machine rendering it is.
import {STATUS,TIME_GRAIN} from './contract.js';

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const LIVE=Object.freeze({
  // How much of the clock's lookahead one performer's plan may take (the rest is the other performers' and the
  // scheduler's): ours. The live clock schedules a quarter of a second ahead (timing.js BufferedClock), so 20 ms.
  planShare:.08,
});

// The wall-clock time (ms) a plan made now may take: a share of the clock's lookahead live, and no limit offline.
export function planDeadlineMs({offline=false,lookaheadSeconds=.25}={},{choices=LIVE}={}){
  return offline?Infinity:lookaheadSeconds*1000*choices.planShare;
}

// Whether a plan keeps every committed contact as it was sent: the same id, at the same time, on the same target, by the
// same limb. A plan's and a commitment's contacts: [{id, seconds, target?, limb?}].
export function keepsCommitted(contacts,committed){
  const byId=new Map(contacts.map(contact=>[contact.id,contact]));
  return committed.every(sent=>{const now=byId.get(sent.id);
    return now&&Math.abs(now.seconds-sent.seconds)<=TIME_GRAIN&&(now.target??null)===(sent.target??null)&&(now.limb??null)===(sent.limb??null)});
}

// The best plan in time. The fallback comes first and is checked like any plan (one that fails is the caller's error,
// said as such); then each candidate in the caller's order of preference, until one passes or the deadline has passed.
// A candidate that would change a committed contact is refused, whatever it is worth. `validate(plan)` -> {status};
// `contactsOf(plan)` -> the plan's contacts. {plan, source: 'fallback' | 'candidate', status, tried, refused: [{index,
// reason}]}, with status 'deadline' where time ran out first, and 'invalid-fallback' where the fallback failed.
export function planLive({fallback,candidates=[],validate,contactsOf=plan=>plan?.contacts??[],committed=[],deadlineMs=Infinity,now=()=>performance.now()}){
  if(typeof fallback!=='function'||typeof validate!=='function')throw new TypeError('planLive takes a fallback and a validate');
  const started=now(),incumbent=fallback(),refused=[];
  if(validate(incumbent).status!==STATUS.witness||!keepsCommitted(contactsOf(incumbent),committed))
    return {plan:null,source:'fallback',status:'invalid-fallback',tried:0,refused};
  let tried=0;
  for(const [index,candidate] of candidates.entries()){
    if(now()-started>=deadlineMs)return {plan:incumbent,source:'fallback',status:'deadline',tried,refused};
    tried++;
    const plan=candidate();
    if(!plan){refused.push({index,reason:'no plan'});continue}
    if(!keepsCommitted(contactsOf(plan),committed)){refused.push({index,reason:'it would rewrite a committed contact'});continue}
    const check=validate(plan);
    if(check.status!==STATUS.witness){refused.push({index,reason:check.reason??check.status});continue}
    return {plan,source:'candidate',status:STATUS.witness,tried,refused};
  }
  return {plan:incumbent,source:'fallback',status:STATUS.witness,tried,refused};
}
