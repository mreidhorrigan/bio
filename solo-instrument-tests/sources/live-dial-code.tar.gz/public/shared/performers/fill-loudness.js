// A fill played lighter the denser it is, as a drummer fitting it into the mix. The user, 27 September 2026, on
// xdrum_clodbot's fills: "a really savvy drummer would try to keep them a little quieter to fit them into the mix, since
// many hits in a short time aggregate to a louder texture."
//
// How much they aggregate: a loudness meter sums energy over its window (BS.1770's momentary loudness, 400 ms), so n
// strokes at one level measure 10 log10(n) dB over one; twice the strokes in the same time, played as hard, are 3.01 dB
// louder as a texture.
//
// How much drummers give back, measured on the Groove MIDI Dataset's 633 fills against their own sessions' grooves
// (scripts/measure-fill-dynamics.mjs; research/FILL_LOUDNESS.md): a fill's busiest 400 ms of snare and toms rises
// 1.94 dB for each doubling of its strokes against the groove's, not 3.01 (90% interval 1.50 to 2.38; the two drummers
// with most fills 1.93 and 1.94). They give back 1.07 dB of every doubling: more strokes, each lighter, and the texture
// still rises.
//
// So a drummer plays every stroke of a fill that much lighter for each doubling of the strokes in its busiest 400 ms
// against the groove's busiest 400 ms on the same drums (the snare and toms, as measured), with the fill's shape kept
// (its crescendo, its moves about the kit). A fill no busier than the groove is played as planned, and so is one over a
// groove with nothing on those drums. Levels are the voice's own (the drum families' velocity curve, articulation.js),
// so a stroke's dB is what the voice will sound.
import {FAMILIES,velocityAmplitude} from '../articulation.js';

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const FILL_LOUDNESS=Object.freeze({
  // Measured (above): the fill texture's rise per doubling of its strokes, and what one level throughout would give;
  // the window strokes are counted in (BS.1770's momentary loudness).
  dbPerDoubling:1.94,summationDbPerDoubling:10*Math.log10(2),windowSeconds:.4,
  // How far back the groove's strokes are heard (ours: two bars of 4/4 at 60 bpm, four at 120).
  grooveSeconds:8,
  // The velocity curve of the drums a fill is played on (articulation.js: the snare's body and the toms, 28 dB, square law).
  rangeDb:FAMILIES.tom.rangeDb,exponent:FAMILIES.tom.velocityExponent??2,
});
// What drummers give back of each doubling (dB): 1.07.
export const givenBackDb=(choices=FILL_LOUDNESS)=>choices.summationDbPerDoubling-choices.dbPerDoubling;

// A velocity's level (dB, 0 at full velocity) on the fill's drums, and the velocity `db` lower than `velocity`.
export const velocityDb=(velocity,choices=FILL_LOUDNESS)=>20*Math.log10(Math.max(1e-6,velocityAmplitude(velocity,choices.rangeDb,choices.exponent)));
export function softerVelocity(velocity,db,choices=FILL_LOUDNESS){
  if(!(db<0))return velocity;
  const p=Math.max(1,choices.exponent),a=10**(-Math.max(1,choices.rangeDb)/(20*p)),b=1-a;
  const amplitude=velocityAmplitude(velocity,choices.rangeDb,choices.exponent)*10**(db/20);
  return Math.max(0,Math.min(1,(amplitude**(1/p)-a)/b));
}

// The most strokes (times in seconds) any window of windowSeconds holds.
export function busiestCount(times,{windowSeconds=FILL_LOUDNESS.windowSeconds}={}){
  const sorted=(times??[]).filter(Number.isFinite).sort((a,b)=>a-b);
  let most=0;for(let to=0,from=0;to<sorted.length;to++){while(sorted[to]-sorted[from]>windowSeconds)from++;most=Math.max(most,to-from+1)}
  return most;
}
// The dB every stroke of a fill is played under its plan: what drummers give back for each doubling of the strokes in
// its busiest window (`fill`: its strokes' times) against the groove's on the same drums (`groove`). 0 or less.
export function fillOffsetDb({fill,groove},choices=FILL_LOUDNESS){
  const played=busiestCount(fill,choices),heard=busiestCount(groove,choices);
  if(!(played>heard&&heard>0))return 0;
  return -Math.round(givenBackDb(choices)*Math.log2(played/heard)*100)/100;
}
