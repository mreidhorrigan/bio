// The bowed-string engine's instruments, one list for everything that plays, fits or casts them, read from the registry's
// tree of the violin family (registry/objects/bowed.json; research/STRINGS_ARTICULATION_FIT_PLAN.md 3g: the owner, 27
// October 2026, "Don't consider the bowed-strings pipeline finished until it can build and fit a new, fictional string
// instrument without LLM intervention"). In the engine's types' order (native/strings-model/musebots-instruments.h):
// Artifastring's own violin, viola and cello (0, 1, 2), the contrabass (3: contrabass.js), then every other instrument
// of the family the registry holds, given as data -- its spec there, and the rest from the tree's rules (its strings'
// stiffness and losses like the measured string nearest each's pitch). Each:
// - `solver`: the Artifastring instrument whose solver and rates it is played on (the registry's `engine.solver`);
// - `strings`: its own strings, lowest first ({name, pitch, f0, T, L, pl, d, E, B} and its losses: the contrabass's law
//   r0 + r2 f^2, an instrument given as data its like string's measured decays by frequency), or null where they are
//   Artifastring's;
// - `bodyScale`: the measured body it is played with, stretched ({from, ratio}: `engine.bodyFrom`, `engine.bodyRatio`), or
//   null where it is its own;
// - `opens`: its open strings' pitches as it is tuned (MIDI), lowest first (`tuning`).
// A quantity measured of some of them is read for another by bySize (its size its lowest open string's frequency, or
// its body's lowest air mode), and said to be derived wherever it is used.
import {CONTRABASS} from './contrabass.js';
import {airMode} from './string-bodies.js';
import {OBJECTS,children,equation,keysOf,value} from '../../../registry/registry.js';

export const ARTIFASTRING=Object.freeze(['violin','viola','cello']);
// (Every other instrument of the violin family in the registry is given as data, in its order there.)
const GIVEN=children('violin-family').filter(name=>!ARTIFASTRING.includes(name)&&name!=='contrabass');
const stringsOf=name=>Object.freeze(keysOf(name,'strings').map(s=>{
  const of=key=>value(name,`strings.${s}.${key}`);
  return Object.freeze({name:s,pitch:of('pitch'),f0:of('f0'),T:of('tension'),L:of('length'),pl:of('density'),d:of('diameter'),E:of('young'),B:of('inharmonicity'),
    losses:Object.freeze(of('losses').map(p=>Object.freeze([...p])))});
}));
const given=GIVEN.map((name,k)=>Object.freeze({name,type:ARTIFASTRING.length+1+k,solver:value(name,'engine.solver'),strings:stringsOf(name),
  bodyScale:Object.freeze({from:value(name,'engine.bodyFrom'),ratio:value(name,'engine.bodyRatio'),interim:true}),opens:Object.freeze(value(name,'tuning')),
  fictional:Boolean(OBJECTS[name].fictional),given:true}));
export const BOWED=Object.freeze([
  ...ARTIFASTRING.map((name,type)=>Object.freeze({name,type,solver:name,strings:null,bodyScale:null,opens:Object.freeze(value(name,'tuning')),fictional:false,given:false})),
  Object.freeze({name:'contrabass',type:ARTIFASTRING.length,solver:value('contrabass','engine.solver'),strings:CONTRABASS.strings,bodyScale:CONTRABASS.bodyScale,
    opens:Object.freeze(CONTRABASS.strings.map(s=>s.pitch)),fictional:false,given:false}),
  ...given,
]);
export const BOWED_TYPES=Object.freeze(Object.fromEntries(BOWED.map(i=>[i.name,i.type])));
export const bowedOf=name=>{const i=BOWED.find(b=>b.name===name);if(!i)throw new Error(`bowed-instruments.js: no bowed instrument ${name}`);return i};

// A string's losses at a frequency (1/s): its law, or its like string's measured decays read between them (and past its
// last two by their line).
export const lossAt=(string,hz)=>string.losses?equation('table-read',{table:string.losses,x:hz}):equation('string-loss-law',{r0:string.r0,r2:string.r2,f:hz});

// Sizes: its lowest open string's frequency (Hz), and its body's lowest air mode (string-bodies.js airMode).
export const lowestHz=name=>value(name,'lowestHz');
export const airHz=name=>airMode(name).hz;

// A quantity measured of some instruments (`table`, by name) for any of them: its own where measured; else read between
// the measured ones nearest it either side by size -- geometrically (its logarithm in a line over the size's), or, a
// level in decibels or any quantity that may be nought or less, in a line (`linear`) -- and held at the nearest's past
// the end of them.
export function bySize(table,name,size=lowestHz,{linear=false}={}){
  if(Object.hasOwn(table,name))return table[name];
  const x=Math.log(size(name)),known=Object.keys(table).map(n=>[Math.log(size(n)),table[n]]).sort((a,b)=>a[0]-b[0]);
  if(!known.length)throw new Error(`bowed-instruments.js bySize: nothing measured to read ${name} from`);
  if(x<=known[0][0])return known[0][1];
  for(let k=1;k<known.length;k++)if(x<=known[k][0]){
    const [x0,v0]=known[k-1],[x1,v1]=known[k],w=(x-x0)/(x1-x0);
    return !linear&&v0>0&&v1>0?Math.exp(Math.log(v0)+(Math.log(v1)-Math.log(v0))*w):v0+(v1-v0)*w;
  }
  return known[known.length-1][1];
}
// The instruments given as data (the registry's violin family), for the tables that hold one entry an instrument.
export const GIVEN_BOWED=Object.freeze(BOWED.filter(i=>i.given));
