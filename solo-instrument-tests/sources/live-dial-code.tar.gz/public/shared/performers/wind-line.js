// A wind instrument's phrase, planned with its breath (the world-instruments report's §5.5, and §8.1: "The current grip,
// fingering, bow reserve, breath state, ringing pitches and partner's trajectory should influence what the bot considers
// next"). The line is the shared one (line.js), carried to a concert flute, a piccolo or an alto flute (the atlas's F16).
// Its breaths are planned by the singer's breath planner (voice.js planBreaths: a breath is an action, taken in a rest or
// from the end of the note before it, never from nothing), with a flutist's profile:
//   - its air lasts less than a singer's, since a flute's jet spends more air than a voice. It lasts longer when soft,
//     and less when loud or in the low register, whose long tube wants more air. The flow rises with loudness and the
//     jet's speed with the register (Fletcher 1975, "Acoustical correlates of flute performance technique", JASA 57(1)).
//     The numbers are authored, a starting profile, not a flutist;
//   - its registers ask their own dynamics: the low octave cannot play ff, and the third octave cannot play pp (authored,
//     after the flute's acoustics: the low register's weak upper partials, the third octave's overblown jet);
//   - its breaths are planned with the phrase, by construction, in one walk through it (the user, 28 September 2026:
//     "Checks should be used only for system development, but the system must not require extensive checking for its
//     actually deployed versions"): a breath at each of the phrase's silences where the air is below topUp, as a player
//     breathes at the phrase's commas and rests; where the air would run out, a breath at the latest place before it
//     that can take one (a rest, or the end of the note before, giving up at most its share, more only where no place
//     can at its share); where no place can, a weak note or two before it left out for a catch breath, as a player
//     breathes in a run; a note longer than a whole breath carries eased a dynamic, and shortened to what a breath
//     carries where that is not enough. Each is said. The singer's planner (planBreaths) is the reference in the tests,
//     never called while playing.
// Not modelled yet, and named so: fingerings (alternate fingerings, trill keys), tonguing speed (double and triple
// tonguing for fast repeated notes), and circular breathing (some players' technique, never a default).
import {STATUS} from './contract.js';
import {LINE,planLine} from './line.js';
import {drain,singer} from './voice.js';
import {instrumentRange} from './instrument-ranges.js';

// The instruments: each one's register the line keeps to and its whole compass (sounding: a seat's notes are taken into
// it, as a string seat's are), both the instrument registry's (instrument-ranges.js: sourced compasses, authored
// registers); how long a comfortable breath lasts at mf in the middle register (s), and how much faster each register
// spends it; each instrument's family (a flute, a reed, a brass instrument: the player that plays it, flute_clodbot,
// woodwind_clodbot or brass_clodbot). The reeds and brass were added for the orchestra (the owner, 2 October 2026:
// "include the rest of the orchestra to the extent possible"): their breaths authored against the flute's (a reed
// spends its air slowly, a large brass bore quickly), each to be replaced by players' measured phrase lengths. The
// flute's is borne out: expert flautists breathe 9.45 +/- 2.78 times a minute while performing, a cycle of about 6.3 s
// (M. A. Cara and D. Mitrovic, Frontiers in Cognition 3 (2024), doi:10.3389/fcogn.2024.1425005;
// research/kalman-references.md).
const wind=(instrument,family,phonationSeconds,[low,middle,high])=>{const {register,range}=instrumentRange(instrument);
  return Object.freeze({family,register,range,phonationSeconds,registers:Object.freeze({low,middle,high})})};
export const WIND_INSTRUMENTS=Object.freeze({
  flute:wind('flute','flute',6,[1.25,1,1.1]),
  piccolo:wind('piccolo','flute',7,[1.2,1,1.15]),
  alto:wind('alto','flute',4.5,[1.3,1.05,1.1]),
  oboe:wind('oboe','reed',9,[1.1,1,1.1]),
  clarinet:wind('clarinet','reed',10,[1,1,1.15]),
  bassoon:wind('bassoon','reed',8,[1.25,1,1.1]),
  // (The rest of the woodwinds, 11 October 2026: authored as the reeds' were, a larger bore's air spent sooner -- a
  // saxophone's wide cone sooner than a clarinet's cylinder -- each to be replaced by players' measured phrase lengths.)
  'e-flat-clarinet':wind('e-flat-clarinet','reed',10,[1,1,1.2]),
  'bass-clarinet':wind('bass-clarinet','reed',8,[1.2,1,1.15]),
  'english-horn':wind('english-horn','reed',8.5,[1.15,1,1.1]),
  contrabassoon:wind('contrabassoon','reed',6,[1.35,1,1.1]),
  'soprano-saxophone':wind('soprano-saxophone','reed',8,[1.15,1,1.2]),
  'alto-saxophone':wind('alto-saxophone','reed',8,[1.2,1,1.15]),
  'tenor-saxophone':wind('tenor-saxophone','reed',7,[1.25,1,1.15]),
  'baritone-saxophone':wind('baritone-saxophone','reed',6,[1.3,1,1.1]),
  horn:wind('horn','brass',8,[1.2,1,1.15]),
  trumpet:wind('trumpet','brass',9,[1.1,1,1.25]),
  trombone:wind('trombone','brass',7,[1.3,1,1.15]),
  tuba:wind('tuba','brass',5,[1.4,1,1.1]),
});
// How far each slides continuously (semitones), where a wind section's glissandi ask it to: the trombone's slide from its
// first position to its seventh, a tritone on one partial (S. Adler, The Study of Orchestration, 3rd ed., Norton, 2002);
// the clarinet's lip-and-finger glissando in its upper register, an octave and more; the open-hole flute's, its fingers
// slid off their holes, about a minor third; the trumpet's half-valve and the horn's and tuba's lip, a whole tone or a
// little more; the double reeds' lip, a semitone (ours, from orchestration practice: to be replaced by players'
// measured glissandi). Beyond its reach a player fingers a run; its slide is begun that near its last pitch.
export const WIND_SLIDE=Object.freeze({flute:3,piccolo:2,alto:3,oboe:1,clarinet:14,bassoon:1,horn:2,trumpet:3,trombone:6,tuba:2,
  // (The rest of the woodwinds: an E-flat clarinet's lip glissando near its B-flat's, a bass clarinet's shorter; a
  // saxophone's lip bend about a whole tone; the English horn's and contrabassoon's the double reeds'. Ours, as above.)
  'e-flat-clarinet':12,'bass-clarinet':8,'english-horn':1,contrabassoon:1,'soprano-saxophone':2,'alto-saxophone':2,'tenor-saxophone':2,'baritone-saxophone':2});
// And how fast (semitones a second at most), its glissando and its slur's own change of pitch alike: a pitch moving faster
// is no slide but a step (the owner, 4 October 2026, of Op. 3.28's flute: "clamp the max speed at which glissando can
// occur for each instrument, especially winds"). The trombone's slide quickest, the clarinet's lip glissando next, the
// fingered and lipped slides of the rest slow (ours, from orchestration practice, as WIND_SLIDE: to be replaced by
// players' measured glissandi).
export const WIND_SLIDE_SPEED=Object.freeze({flute:10,piccolo:10,alto:10,oboe:6,clarinet:24,bassoon:6,horn:10,trumpet:10,trombone:30,tuba:10,
  'e-flat-clarinet':24,'bass-clarinet':16,'english-horn':6,contrabassoon:6,'soprano-saxophone':10,'alto-saxophone':10,'tenor-saxophone':10,'baritone-saxophone':10});
// A slide of `semitones` in `seconds` no faster than `speed` allows: its seconds where it fits them, else as far as it
// goes in them, ending where it was going -> {semitones, seconds} (semitones signed as given; 0 where none fits).
export function slideWithin(semitones,seconds,speed){
  const most=seconds>0?Math.max(0,Number(speed)||0)*seconds:0;
  return Math.abs(semitones)<=most?{semitones,seconds}:{semitones:Math.sign(semitones)*most,seconds};
}
// The instruments of a family.
export const windFamily=family=>Object.keys(WIND_INSTRUMENTS).filter(id=>WIND_INSTRUMENTS[id].family===family);
export const WIND_LINE=Object.freeze({...LINE,
  // How much faster a dynamic spends the breath (authored), the loudest dynamic the low register plays and the softest
  // the high one does, and how far into the reserve a phrase may run.
  breathDynamics:Object.freeze({ppp:.5,pp:.6,p:.75,mp:.88,mf:1,f:1.3,ff:1.6,fff:1.9}),
  lowMost:'f',highLeast:'p',reserve:.5,
  // Below this much air a breath is taken at a silence of the phrase's own, where one fits.
  topUp:.7,
  // The rest a player makes for a catch breath in a run (s; the singer's catch breath, 0.35, and a margin).
  breathRest:.4,
  // How far a held note may give itself up to a breath when the phrase asks it (the planner's own share is a half).
  shortenMost:.8,
});
const registerOf=(pitch,[low,high])=>{const third=(high-low)/3;return pitch<low+third?'low':pitch>high-third?'high':'middle'};

// A flutist's breath, as the singer's planner takes it: a sound source and a breath store, the flute's numbers.
export function flutist(kind,{choices=WIND_LINE,shortenShare=.5}={}){
  return singer({id:'flutist',performer:'flutist',range:[...kind.register],
    breath:{phonationSeconds:kind.phonationSeconds,registers:{...kind.registers},dynamics:{...choices.breathDynamics},reserve:choices.reserve,shortenShare},
    evidence:['a flute spends more air than a voice; its flow rises with loudness (Fletcher 1975); the numbers authored']});
}

// A phrase: {status, notes, breaths, changes}. instrument: a name or its own {register, phonationSeconds, registers}.
export function planPhrase({instrument='flute',register=null,pool,meter,bpm,bars,density=.4,loudness=.5,fioriture=0,motif=null,motifDensity,phraseIndex=0,previousApex=null,climax=false,pickup=null,lead=null,heard=[],final=null,coreOnly=false,random,choices=WIND_LINE}){
  const kind=typeof instrument==='string'?WIND_INSTRUMENTS[instrument]:instrument;
  if(!kind)throw new RangeError(`no wind instrument ${instrument}`);
  // Its register: the instrument's, or a part of it (where it keeps out of another's, shared/presentation.js).
  const line=planLine({register:register??kind.register,pool,meter,bpm,bars,density,loudness,fioriture,motif,motifDensity,phraseIndex,previousApex,climax,pickup,lead,heard,final,coreOnly,random,choices});
  if(line.status==='declined')return {...line,breaths:[],changes:[]};
  return {...breathPhrase(line.notes,{kind,choices}),motif:line.motif,apex:line.apex,variation:line.variation,lead:line.lead,...(line.choice?{choice:line.choice}:{})};
}

// The phrase's registers' dynamics kept, then its breaths planned with it: {status: 'breathed', notes (a note whose end a
// breath takes ending earlier; notes left out where a run had no room for one), breaths [{before, kind, at, seconds,
// where, shortens}], airLeft, changes: [{at, change, because}]}.
export function breathPhrase(input,{kind,choices=WIND_LINE}){
  const order=choices.dynamics,changes=[];
  const within=note=>{
    const register=registerOf(note.pitch,kind.register);let index=order.indexOf(note.dynamic);
    if(register==='low')index=Math.min(index,order.indexOf(choices.lowMost));
    if(register==='high')index=Math.max(index,order.indexOf(choices.highLeast));
    const dynamic=order[index];return dynamic===note.dynamic?note:{...note,dynamic,velocity:choices.velocity[dynamic]};
  };
  const model=flutist(kind,{choices,shortenShare:choices.shortenMost}).breath,rate=note=>drain(note,model),carry=1+model.reserve;
  // A note longer than a whole breath carries at its dynamic: a dynamic softer (never below its register's least), and
  // where that is not enough, shortened to what a breath carries.
  let notes=input.map(within).map(note=>{
    const seconds=note.end-note.start;
    if(rate(note)*seconds<=carry)return note;
    const least=registerOf(note.pitch,kind.register)==='high'?order.indexOf(choices.highLeast):0,index=Math.max(least,order.indexOf(note.dynamic)-1);
    const eased={...note,dynamic:order[index],velocity:choices.velocity[order[index]]};
    if(eased.dynamic!==note.dynamic)changes.push({at:note.start,change:'eased a dynamic',because:'no breath carries it whole at its dynamic'});
    if(rate(eased)*seconds<=carry)return eased;
    changes.push({at:note.start,change:'the note shortened',because:'no breath carries it whole'});
    return {...eased,end:eased.start+carry/rate(eased)*.98};
  });
  // The breath that fits before note k, giving up at most `share` of the note before: a full one where it fits, else a
  // catch breath; null where neither does.
  const breathAt=(k,share)=>{
    if(k<=0||k>=notes.length)return null;
    const previous=notes[k-1],gap=Math.max(0,notes[k].start-previous.end),length=previous.end-previous.start;
    for(const name of ['full','catch']){
      const breath=model.breaths[name],taken=Math.max(0,breath.seconds-gap);
      if(taken<=length*share+1e-9)return {kind:name,seconds:breath.seconds,taken,refill:breath.refill,gap};
    }
    return null;
  };
  // Whether notes from..to can be played from `air` with no breath between.
  const carries=(air,from,to)=>{for(let j=from;j<=to;j++){air-=rate(notes[j])*(notes[j].end-notes[j].start);if(air<-model.reserve-1e-9)return false}return true};
  const breaths=[],airBefore=[1];let air=1,k=0,since=0;
  const take=(j,breath)=>{
    const previous=notes[j-1];
    if(breath.taken>0)notes[j-1]={...previous,end:previous.end-breath.taken};
    breaths.push({before:notes[j].id,kind:breath.kind,at:notes[j].start-breath.seconds,seconds:breath.seconds,where:breath.gap>=breath.seconds-1e-9?'rest':'unmarked',
      shortens:breath.taken>0?{note:previous.id,seconds:breath.taken}:null});
    since=j;
    return Math.min(1,airBefore[j]+breath.taken*rate(previous)+breath.refill);
  };
  while(k<notes.length){
    // A breath at a silence of the phrase's own (its comma, its rest) where the air is low enough to want one.
    if(k>since&&notes[k].start-notes[k-1].end>1e-6&&air<choices.topUp){const breath=breathAt(k,.5);if(breath)air=take(k,breath)}
    const need=rate(notes[k])*(notes[k].end-notes[k].start);
    if(air-need>=-model.reserve-1e-9){air-=need;k++;airBefore[k]=air;continue}
    // It runs out at note k: the latest place since the last breath whose breath carries the phrase on to note k, the
    // note before it giving up at most its share (more, up to shortenMost, only where no place can at its share).
    let placed=null;
    for(const share of [.5,choices.shortenMost]){
      for(let j=k;j>since&&!placed;j--){const breath=breathAt(j,share);if(breath&&carries(Math.min(1,airBefore[j]+breath.taken*rate(notes[j-1])+breath.refill),j,k))placed={j,breath}}
      if(placed)break;
    }
    if(placed){air=take(placed.j,placed.breath);k=placed.j;continue}
    // No place can: a weak note or two before note k left out, a rest for a catch breath (never the phrase's first note,
    // nor one before the last breath).
    const out=new Set;let gap=0;
    for(let j=k-1;j>since&&gap<choices.breathRest;j--){if(notes[j].beatStart&&out.size)break;out.add(notes[j].id);gap+=notes[j].end-notes[j].start}
    if(out.size){
      changes.push({at:notes[k].start,change:`${out.size} note${out.size>1?'s':''} left out for a breath`,because:'a run with no room for one'});
      const first=notes.findIndex(note=>out.has(note.id));
      notes=notes.filter(note=>!out.has(note.id));k=first;air=airBefore[first];
      continue;
    }
    // Nothing before it to leave out: the note itself ends where the air does.
    const note=notes[k];
    changes.push({at:note.start,change:'the note shortened',because:'the air runs out in it'});
    notes[k]={...note,end:note.start+Math.max(.05,(air+model.reserve)/rate(note))*.98};
  }
  return {status:'breathed',notes,breaths,airLeft:air,changes};
}
