// A fill's figure: which slots of its count a drummer strikes, with which hands, and how loud each stroke is within the
// fill. The user, 28 September 2026, on xdrum_clodbot's fills (listening item 33): "all the drummer's super-fast high
// tuplet fills are completely linear, with no gaps. Our drummers should not be so limited - where appropriate, they
// should also be able to play tuplet fills that do not attach every component of the tuplet"; on keeping group heads
// and the pickup always struck and playing singles: "this is not necessarily always true, in drumming"; and "dynamic
// change within a fill can sometimes be quite important; some rudiments also have dynamic differences built into them".
//
// What human drummers do, measured on the Groove MIDI Dataset's fills (scripts/measure-fill-figures.mjs;
// research/fill-figures-gmd.json; research/FILL_FIGURES.md): a fifth of fills are linear throughout. The faster a
// figure's slots go, the fewer of its beats are full (half below 9 slots a second, 5% from 12), and what they leave out
// changes: below 9 a second mostly one slot (the pickup into the next beat most often, the head least); from 12 mostly
// a coarser grid within the tuplet (x_x_x_ in six), one slot off one, a run (entering late or stopping early), or
// strokes scattered; every slot is sometimes left out, the head too. Their
// dynamics move: 43% rise by 3 dB or more from the first stroke to the last (a median 9.3 dB), 24% fall (9.5 dB), a
// third stay level; about that course the loud strokes stand a median 3.3 dB over the middle and the soft ones 4.4 dB
// under it, and most fills have ghosts.
//
// Into a crash it meets the crash as they did (the user, 28 September 2026, on a fill that stopped short of its crash:
// "a rest before a crashy resolution, which can be interpreted as a stumble; however, it is musically valid as an
// expressive technique in some circumstances. It creates a kind of tension"): played through, or stopped half a beat or
// more before it, the tension; never a gap between, which the drummers never left and which is heard as a stumble.
//
// So a figure is drawn, not written:
//   - its rests: a kind of figure as often as the drummers played it at its rate (full, one slot out, a run, a grid, one
//     slot off a grid, scattered), and its slots within that kind as theirs were (fillRests), keeping enough strokes
//     to be heard as a figure;
//   - its sticking: one of the rudiments its hands can play at the tempo (the caller's `playable`, worked out from the
//     performer's limits: drummer.js handsAllow): singles over its strokes, or hand to hand (each hand keeping its side
//     of the slots, a rest a stroke in the air); over a figure without rests, also a counted roll (pairs and a
//     release), a paradiddle (RLRR LRLL, its doubles rebound pairs) or doubles (RRLL); and where a figure with rests is
//     too quick for singles, the doubles over its strokes; on a grid finer than its hands, its strokes every k-th slot;
//   - its accents: the rudiment's own (the paradiddle's cell heads, the roll's release), else its groups' heads (a run of
//     strokes between rests is a group; a figure without rests grouped in twos and threes), and its last stroke where
//     the fill arrives (a fill up);
//   - its course: rising into more intensity, falling into less, or level, in the drummers' proportions (a fill up never
//     falls, a fill down never rises), and its size theirs; its taps a drawn height under its accents, and its ghosts,
//     as many as the drummers played, deeper, from the quiet end of its course.
// Each draw is the caller's `random` (a drummer's own stream), so a seeded performance plays its figures again.
// Levels are dB under the fill's loudest stroke, as the voice will sound them (fill-loudness.js softerVelocity).
//
// And a figure is shaped by the music around it (the user, 28 September 2026: "the fills' details should be affected
// by the musical material around them, so the drummer doesn't play exactly the same fill exactly the same way each
// time"). Its `context` (ours, each part optional; research/FILL_FIGURES.md "Around the fill"):
//   - what the band plays there (`hearAt(fraction of the beat)`: {accent, busy}, from the pattern the drummer hears in
//     the others' onsets, rhythm-spaces.js; nothing where no pattern is heard, so a band playing at random changes
//     nothing): the figure catches the band's accents, striking and accenting them, and leaves its rests where the band
//     is busy between them, as rhythm-spaces.js's reinforcing and interlocking spaces do;
//   - the room the band leaves in the beat (0 to 1): a full figure only as often as there is room for one;
//   - the join's move in intensity (0 to 1): the bigger, the likelier its course moves with it, and the further, and
//     the likelier a stop before a crash;
//   - whether a crash lands after it (`crash`): its ending, through or a stop, as above;
//   - the figures it played last: one the same as any of them is drawn again, so a fill is not played the same way
//     each time.
import {countedRoll} from './gestures.js';
import {FILL_LOUDNESS} from './fill-loudness.js';

// ---- Choices ---------------------------------------------------------------------------------------------------------
// The measured corpus (above), as research/fill-figures-gmd.json has it (test/fill-figures.test.mjs keeps them equal).
// Swappable: any table of this shape.
export const GMD_FILL_FIGURES=Object.freeze({
  source:'Groove MIDI Dataset v1.0.0 (CC BY 4.0): 485 fills of 647 4/4 fill takes (scripts/measure-fill-figures.mjs; research/fill-figures-gmd.json)',
  // By the figure's rate (slots a second, from `from`): the share of its beats of each kind (a beat left empty, a
  // break's, is not a figure's and is left out), and of its slots left out at each level (a slot's level: fillLevel);
  // and of the slots the hands left out, the share a kick played (hand-and-foot figures: 563, 390 and 918 of them).
  rates:Object.freeze([
    Object.freeze({from:0,kinds:Object.freeze({full:.4958,'one out':.3803,run:.0662,grid:.0141,'near grid':.0099,scattered:.0268}),
      leftOut:Object.freeze({head:.1197,coarse:.119,finest:.2515,last:.2577}),kickInGap:.2647}),
    Object.freeze({from:9,kinds:Object.freeze({full:.2766,'one out':.1596,run:.1862,grid:.0213,'near grid':.0957,scattered:.2447}),
      leftOut:Object.freeze({head:.234,coarse:.2878,finest:.4378,last:.3511}),kickInGap:.1769}),
    Object.freeze({from:12,kinds:Object.freeze({full:.051,'one out':.0235,run:.1373,grid:.2588,'near grid':.2118,scattered:.298}),
      leftOut:Object.freeze({head:.2667,coarse:.4332,finest:.6058,last:.6667}),kickInGap:.0893}),
  ]),
  // Of the figures on a coarser grid, the share on the beat's head (x_x_x_ rather than _x_x_x).
  gridOnHead:.75,
  // How a fill beat meets a crash on the next head, by the silence from its last stroke's onset to the crash: played
  // through (a third of the beat or less, its last stroke in the beat's last third) or stopped (half a beat or more, its
  // last stroke on or before the beat's half), each bound given the reading's slack; never between. Of 31 fill beats
  // landed on a crash, 68% through, 32% stopped, none between (of the rest, 3.7% between); a kick sounded in the
  // silence before the crash in 39% (of the 1632 fill beats landed on no crash, 10%).
  landing:Object.freeze({through:1/3,stop:1/2,slack:1/24,beforeCrash:Object.freeze({stop:.3226,kickInSilence:.3871}),otherwise:Object.freeze({kickInSilence:.1023})}),
  // How the groove bends into a fill (81 fills with three beats before them in their takes): a beat busy with the hands
  // (two strokes or more; each such beat held two) three, two and one beat before the fill's first fast beat, 21%, 31%
  // and 52% of the time; the beat just before 5.72 dB under the one before it.
  leadIn:Object.freeze({baseline:.2099,busy:Object.freeze({'-2':.3086,'-1':.5185}),strokes:2,levelDb:-5.7181}),
  // How many beats their fills ran, from the first fast beat to the last (505 fills): the share of each length. Half
  // ran one or two beats, a fifth a whole bar of 4/4, and a few up to six bars.
  lengthBeats:Object.freeze({1:0.2238,2:0.2733,3:0.1941,4:0.198,5:0.0139,6:0.0178,7:0.0218,8:0.0337,9:0.004,10:0.002,11:0.004,14:0.002,15:0.004,16:0.004,20:0.002,24:0.002}),
  // The course: the shares rising and falling by 3 dB or more, and how far (dB); the loud strokes' height over the
  // course (accentDb) and the soft ones' depth under it (ghostBelowDb); and the share of strokes that are ghosts. Each
  // distribution its p10, p25, p50, p75 and p90.
  rising:.4268,falling:.2371,
  risingDb:Object.freeze([3.7295,5.9846,9.2638,14.318,19.55]),fallingDb:Object.freeze([4.3351,5.8524,9.5107,15.817,20.7586]),
  accentDb:Object.freeze([.2511,1.3051,3.275,6.3065,11.9623]),ghostBelowDb:Object.freeze([.4863,1.9248,4.4261,8.458,12.8338]),
  ghostShare:Object.freeze([0,0,.1667,.3333,.5582]),
  // Graces before their strokes on the stroke's own drum (4079 principals of their fills' fast beats): 1.9% of those
  // louder than their beat's other strokes had them and 0.8% of the rest, 83% one grace (a flam's) and the rest two (a
  // drag's); each grace's gap before the next stroke (seconds) and its level against its stroke (dB), p10 to p90.
  // (Another 5.2% of their principals were doubled on another drum, a few milliseconds apart and as loud: two drums
  // struck together, which these are not.)
  graces:Object.freeze({louder:.0186,quieter:.0079,flam:.8333,gapSeconds:Object.freeze([.0182,.0247,.0282,.0309,.0336]),
    db:Object.freeze([-33.0119,-26.2315,-5.2129,.7653,2.4735])}),
  // Two drums struck together (graces.onAnother: 5.2% of their principals): the share of each drum's strokes doubled on
  // another, which drum was struck first with it (the pairs: snare and floor tom 72% of them), the first stroke's gap
  // before the principal (seconds) and its level against it (dB), p10 to p90. Always one stroke, as loud as the
  // principal, louder or not alike.
  doubles:Object.freeze({byDrum:Object.freeze({tomHigh:0.0434,snare:0.033,tomFloor:0.1541,tomMid:0.0201}),
    pairs:Object.freeze([Object.freeze({first:'snare',drum:'tomFloor',share:0.4009}),Object.freeze({first:'tomFloor',drum:'snare',share:0.3208}),Object.freeze({first:'tomFloor',drum:'tomHigh',share:0.1038}),Object.freeze({first:'tomHigh',drum:'snare',share:0.0613}),Object.freeze({first:'snare',drum:'tomHigh',share:0.0472}),Object.freeze({first:'tomHigh',drum:'tomFloor',share:0.033}),Object.freeze({first:'tomMid',drum:'snare',share:0.0142}),Object.freeze({first:'snare',drum:'tomMid',share:0.0142}),Object.freeze({first:'tomHigh',drum:'tomMid',share:0.0047})]),
    gapSeconds:Object.freeze([0.0013,0.0039,0.0069,0.0117,0.017]),db:Object.freeze([-5.3683,-3.4429,0,2.9534,5.0861])}),
});
export const FILL_FIGURES=Object.freeze({
  data:GMD_FILL_FIGURES,
  // The fewest strokes a figure keeps, of its slots (ours: a third, and never fewer than two, so it is still heard as a
  // figure; the drummers' fastest figures left out three fifths), and how many draws of its rests before it plays them
  // all.
  leastShare:1/3,leastStrokes:2,draws:8,
  // The rudiments a figure without rests may also be played in, and the fewest strokes each needs.
  rudiments:Object.freeze({roll:3,paradiddle:4,doubles:4}),
  // The lowest a stroke is played, under the fill's loudest (ours: the voice's range less a margin, so a ghost is soft
  // and still sounds).
  lowestDb:-(FILL_LOUDNESS.rangeDb-4),
  // The band's accent a figure catches (rhythm-spaces.js's core: salience 0.6 or more), and how many of its last
  // figures a drummer does not play again the same way.
  caught:.6,recentKept:2,
});
const QUANTILES=Object.freeze([.1,.25,.5,.75,.9]);
const other=hand=>hand==='R'?'L':'R';

// A value drawn from a distribution given by its p10 to p90 (u from 0 to 1): between them by straight lines, and held at
// the ends (the tails are not drawn past what was measured).
export function fromQuantiles(values,u){
  const x=Math.max(QUANTILES[0],Math.min(QUANTILES.at(-1),Number(u)||0));
  for(let i=1;i<QUANTILES.length;i++)if(x<=QUANTILES[i])return values[i-1]+(values[i]-values[i-1])*(x-QUANTILES[i-1])/(QUANTILES[i]-QUANTILES[i-1]);
  return values.at(-1);
}
// A slot's place in its span of n: its head, its last (the pickup into what follows), one of a coarser division within
// it (six's half and its thirds, eight's quarters), or one of the finest. As the measurement reads a beat's slots.
export const fillLevel=(slot,n)=>slot===0?'head':slot===n-1?'last':[2,3,4].some(e=>e<n&&n%e===0&&slot*e%n===0)?'coarse':'finest';
// The measured band a figure's rate falls in.
export const rateBand=(slotsPerSecond,data=GMD_FILL_FIGURES)=>data.rates.findLast(band=>slotsPerSecond>=band.from)??data.rates[0];

// One of `items` drawn with `random`, each as likely as its weight.
function drawn(items,weight,random){
  const total=items.reduce((sum,item)=>sum+weight(item),0);let u=random()*total;
  for(const item of items){u-=weight(item);if(u<0)return item}
  return items.at(-1);
}
// The fewest strokes a figure of n slots keeps.
export const leastStrokes=(n,choices=FILL_FIGURES)=>Math.min(n,Math.max(choices.leastStrokes,Math.ceil(n*choices.leastShare)));
// A figure's rests over n slots at `slotsPerSecond`: a kind drawn as the drummers played them at that rate, among those
// n slots can take (a grid needs a divisor), then its rests:
//   - one out: one slot, each as likely as the drummers left out slots of its level;
//   - a run: its strokes together, as many as the fewest to all but two, starting anywhere;
//   - a grid: every step-th slot (the finest coarser grid), on the head as often as theirs were, else from another slot;
//   - near grid: that grid with one slot added or left out;
//   - scattered: each slot left out as often as they left out slots of its level, among the figures that were not full
//     or one slot out, two or more of them.
// Every kind keeps the fewest strokes; a draw that does not is drawn again. [slot], sorted.
// What the band plays at each of n slots (context.hearAt): {accent, busy}, nothing heard where it gives nothing.
const hearing=(n,context)=>[...Array(n).keys()].map(slot=>{const heard=context?.hearAt?.(n>1?slot/n:0);
  return {accent:Math.max(0,Math.min(1,Number(heard?.accent)||0)),busy:Math.max(0,Math.min(1,Number(heard?.busy)||0))}});
export function fillRests(n,{slotsPerSecond,random,context=null,data=GMD_FILL_FIGURES,choices=FILL_FIGURES}={}){
  if(!Number.isSafeInteger(n)||n<1)throw new RangeError(`a figure has 1 slot or more, not ${n}`);
  const band=rateBand(slotsPerSecond,data),least=leastStrokes(n,choices),slots=[...Array(n).keys()];
  const step=[...Array(Math.floor(n/2)+1).keys()].find(size=>size>=2&&n%size===0&&n/size>=least)??null;
  const takes={full:true,'one out':n-1>=least,run:n-2>=least,grid:step!==null&&step<n,'near grid':step!==null&&step<n,scattered:n-2>=least};
  const kinds=Object.keys(band.kinds).filter(kind=>takes[kind]);
  // Around it: a full figure only as often as the band leaves room; a rest likelier where the band is busy, less likely
  // near its accents, and never on one it catches (a draw that rests one is drawn again).
  const room=Math.max(0,Math.min(1,context?.room??1)),heard=hearing(n,context),caught=slot=>heard[slot].accent>=choices.caught;
  const around=slot=>caught(slot)?0:(1+heard[slot].busy)*(1-heard[slot].accent);
  // What striking a slot is worth against the band: its accent, less how busy the band is there between its accents.
  const worth=slot=>heard[slot].accent-heard[slot].busy*(1-heard[slot].accent);
  const weight=kind=>kind==='full'?band.kinds.full*room:band.kinds[kind];
  // Into a crash: through, or a stop (the drummers' share, the likelier the bigger the join's move), decided first.
  const move=Number.isFinite(context?.move)?Math.max(0,Math.min(1,context.move)):null;
  const ending=context?.crash?(random()<Math.min(1,data.landing.beforeCrash.stop*(move===null?1:.5+move))?'stop':'through'):null;
  const meets=rests=>ending===null||figureEnding(n,rests,{data})===ending;
  const byLevel=slot=>band.leftOut[fillLevel(slot,n)]*around(slot);
  // A grid's offset: on the head as often as theirs, the others alike, each the likelier for what it strikes against
  // what it leaves out (worth).
  const grid=()=>{
    const offsets=[...Array(step).keys()],catches=offset=>slots.reduce((sum,slot)=>sum+(slot%step===offset?worth(slot):-worth(slot)),0);
    const offset=drawn(offsets,offset=>(offset===0?data.gridOnHead:(1-data.gridOnHead)/Math.max(1,step-1))*Math.exp(catches(offset)),random);
    return slots.filter(slot=>slot%step!==offset);
  };
  for(let draw=0;draw<choices.draws;draw++){
    const kind=drawn(kinds,weight,random);let rests;
    if(kind==='full'){if(meets([]))return [];continue}
    else if(kind==='one out')rests=[drawn(slots,byLevel,random)];
    else if(kind==='run'){
      const length=least+Math.floor(random()*(n-1-least)),starts=[...Array(n-length+1).keys()];
      const start=drawn(starts,start=>Math.exp(slots.reduce((sum,slot)=>sum+(slot>=start&&slot<start+length?worth(slot):-worth(slot)),0)),random);
      rests=slots.filter(slot=>slot<start||slot>=start+length);
    }
    else if(kind==='grid')rests=grid();
    else if(kind==='near grid'){
      const base=new Set(grid()),struck=slots.filter(slot=>!base.has(slot));
      if(random()<.5&&struck.length>least)base.add(drawn(struck,around,random));else base.delete(drawn([...base],slot=>1+heard[slot].accent,random));
      rests=[...base];
    }else{
      const sparse=Math.max(1e-9,band.kinds.run+band.kinds.grid+band.kinds['near grid']+band.kinds.scattered)/
        Math.max(1e-9,Object.values(band.kinds).reduce((sum,share)=>sum+share,0));
      rests=slots.filter(slot=>random()<Math.min(.95,byLevel(slot)/sparse));
      if(rests.length<2)continue;
    }
    rests.sort((a,b)=>a-b);
    if(rests.length&&n-rests.length>=least&&!rests.some(caught)&&meets(rests))return rests;
  }
  // Into a crash the ending decided and no draw meeting it: a stop is the figure's first half and silence after (a
  // caught accent never silenced); played through, every slot.
  if(ending==='stop'){const last=Math.floor(n/2);
    if(last+1>=least&&!slots.some(slot=>slot>last&&caught(slot)))return slots.filter(slot=>slot>last)}
  return [];
}
// Which of a figure's strokes are louder than the other strokes of their beat (their levels' mean), as the measurement
// read the drummers' (a stroke alone in its beat is not). `levelsDb`: each stroke's; `beatOf(k)`: stroke k's beat.
export function louderStrokes(levelsDb,beatOf=()=>0){
  const byBeat=new Map;levelsDb.forEach((db,k)=>{const beat=beatOf(k);if(!byBeat.has(beat))byBeat.set(beat,[]);byBeat.get(beat).push(k)});
  return levelsDb.map((db,k)=>{const others=byBeat.get(beatOf(k)).filter(other=>other!==k);
    return others.length>0&&db>others.reduce((sum,other)=>sum+levelsDb[other],0)/others.length});
}
// The graces a figure's strokes take: flams and drags on their strokes' own drums, as the Groove MIDI drummers played
// theirs in fills. A stroke louder than its beat's others (louderStrokes) takes one as often as theirs did, another as
// often as the rest; one grace (a flam) or two (a drag) as theirs; each grace's gap before the next stroke, and its
// level against its stroke, drawn between their quantiles (never louder than its stroke: softerVelocity). `louder`:
// each stroke's (true or false). [{index (the stroke's), count, seconds, db}], in order.
export function fillGraces(louder,{random,data=GMD_FILL_FIGURES}={}){
  const {graces}=data,out=[];
  louder.forEach((loud,index)=>{
    if(random()>=(loud?graces.louder:graces.quieter))return;
    out.push({index,count:random()<graces.flam?1:2,seconds:fromQuantiles(graces.gapSeconds,random()),db:fromQuantiles(graces.db,random())});
  });
  return out;
}
// Which of a figure's strokes are doubled on another drum (two drums struck together, as the Groove MIDI drummers did
// in their fills): each stroke on a drum (snare, tomHigh, tomMid, tomFloor) as often as theirs on it; the drum struck
// with it drawn from the pairs they played with that drum second; the first stroke's gap before the principal, and its
// level against it, drawn between their quantiles. `drums`: each stroke's drum. [{index, first (the other drum),
// seconds, db}], in order.
export function fillDoubles(drums,{random,data=GMD_FILL_FIGURES}={}){
  const {doubles}=data,out=[];
  drums.forEach((drum,index)=>{
    if(!(random()<(doubles.byDrum[drum]??0)))return;
    const partners=doubles.pairs.filter(pair=>pair.drum===drum&&pair.first!==drum);
    if(!partners.length)return;
    const total=partners.reduce((sum,pair)=>sum+pair.share,0);let u=random()*total,first=partners.at(-1).first;
    for(const pair of partners){u-=pair.share;if(u<0){first=pair.first;break}}
    out.push({index,first,seconds:fromQuantiles(doubles.gapSeconds,random()),db:fromQuantiles(doubles.db,random())});
  });
  return out;
}
// The kick in a fill's rests (hand-and-foot figures, as the Groove MIDI drummers played theirs). A rest before the
// fill's last stroke is the kick's as often as theirs were at its rate: a quarter of them under 9 slots a second, 18% to
// 12, 9% faster (the foot slower than the hands). The silence after its last stroke holds one kick, on one of its rests,
// as often as theirs did: 39% into a crash, 10% otherwise. `gaps`: the fill's rests, [{at (a number or a Rational),
// slotsPerSecond, silence (after its last stroke)}]. The gaps the kick plays, in time.
export function fillKicks(gaps,{random,crash=false,data=GMD_FILL_FIGURES}={}){
  const when=gap=>typeof gap.at==='number'?gap.at:gap.at.toNumber(),inside=gaps.filter(gap=>!gap.silence),silence=gaps.filter(gap=>gap.silence);
  const out=inside.filter(gap=>random()<rateBand(gap.slotsPerSecond,data).kickInGap);
  if(silence.length&&random()<(crash?data.landing.beforeCrash:data.landing.otherwise).kickInSilence)out.push(silence[Math.min(silence.length-1,Math.floor(random()*silence.length))]);
  return out.sort((a,b)=>when(a)-when(b));
}
// How a figure of n slots with `rests` ends into what follows, by the silence from its last stroke's onset to the next
// head (of the span): 'through', 'stop' or 'between' (the landing's bounds, as the measurement read them).
export function figureEnding(n,rests,{data=GMD_FILL_FIGURES}={}){
  const resting=new Set(rests),last=[...Array(n).keys()].reverse().find(slot=>!resting.has(slot)),gap=(n-last)/n,{through,stop,slack}=data.landing;
  return gap<=through+slack+1e-12?'through':gap>=stop-slack-1e-12?'stop':'between';
}

// The stickings a figure's strokes may be played in, each {name, hands: [{hand, action}] (one a stroke; strokes sharing
// an action are one, a rebound pair), accents: [stroke index] (the rudiment's own)}. `struck`: the struck slots.
export function fillStickings(struck,{n,lead='R',choices=FILL_FIGURES}={}){
  const m=struck.length,full=m===n,out=[];
  out.push({name:'singles',hands:struck.map((slot,k)=>({hand:k%2?other(lead):lead,action:`stroke-${k}`})),accents:[]});
  // Hand to hand: each slot its hand, as if every slot were played; distinct from singles only where there are rests.
  if(!full)out.push({name:'hand to hand',hands:struck.map(slot=>({hand:slot%2?other(lead):lead,action:`stroke-${slot}`})),accents:[]});
  if(full&&m>=choices.rudiments.roll&&m%2)out.push({name:'roll',hands:countedRoll(m,lead).map(({hand,action})=>({hand,action})),accents:[m-1]});
  if(full&&m>=choices.rudiments.paradiddle){
    // RLRR LRLL: a single, a single, a rebound pair, the lead changing each cell; each cell's first accented.
    const hands=[],accents=[];let hand=lead;
    for(let cell=0;hands.length<m;cell++,hand=other(hand)){
      accents.push(hands.length);
      for(const [who,part] of [[hand,'a'],[other(hand),'b'],[hand,'pair'],[hand,'pair']])if(hands.length<m)hands.push({hand:who,action:`cell-${cell}-${part}`});
    }
    out.push({name:'paradiddle',hands,accents});
  }
  if(full&&m>=choices.rudiments.doubles&&m%2===0)out.push({name:'doubles',hands:struck.map((slot,k)=>({hand:Math.floor(k/2)%2?other(lead):lead,action:`pair-${Math.floor(k/2)}`})),accents:[]});
  return out;
}
// The doubles over a figure's strokes: each two strokes in turn one hand's rebound pair, the hands in turn (an odd last
// stroke a single). Over every slot, the doubles (or, odd, the counted roll's hands); with rests, what a drummer's hands
// play a figure in where it is too quick for singles. Its hands play it wherever its strokes are no closer than the
// doubles allow (drummer.js motionSpacing: each hand's pairs three strokes' gaps apart), whatever it leaves out.
export const doublesMotion=(struck,{lead='R'}={})=>({name:'doubles',
  hands:struck.map((slot,k)=>({hand:Math.floor(k/2)%2?other(lead):lead,action:`pair-${Math.floor(k/2)}`})),accents:[]});

// A figure's groups: runs of strokes between rests, or, with no rests, the strokes in twos and threes (drawn). The head
// of each group of two or more. [stroke index].
export function groupHeads(struck,{n,random}){
  if(struck.length===n){
    const heads=[];let at=0;
    while(at<n){heads.push(at);const left=n-at,size=left===4?2:left<=3?left:random()<.5?2:3;at+=size}
    return heads.filter(head=>head<n-1||n===1);
  }
  const heads=[];
  struck.forEach((slot,k)=>{if((k===0||struck[k-1]!==slot-1)&&struck[k+1]===slot+1)heads.push(k)});
  return heads;
}

// A figure's dynamics: its course and each stroke's role and level (dB under the fill's loudest). `struck`: the struck
// slots of n; `accents`: the rudiment's own; `fill`: 'up' or 'down'.
export function fillDynamics(struck,{n,fill,accents=[],random,context=null,progress:placed=null,data=GMD_FILL_FIGURES,choices=FILL_FIGURES}={}){
  const m=struck.length,level=1-data.rising-data.falling;
  // Its course: into more intensity rising or level, into less falling or level, in the drummers' proportions at a
  // middling move (context.move 0.5), likelier and further with a bigger one.
  const move=Number.isFinite(context?.move)?Math.max(0,Math.min(1,context.move)):null;
  const toward=fill==='down'?data.falling:data.rising,moving=Math.min(1,toward/(toward+level)*(move===null?1:.5+move));
  const kind=random()<moving?(fill==='down'?'falling':'rising'):'level';
  const courseDb=kind==='level'?0:fromQuantiles(kind==='rising'?data.risingDb:data.fallingDb,move===null?random():(move+random())/2);
  // A solo's intensity (xdrum_clodbot's arc, context.intensity, 0 to 1) closes the gaps it draws: at 1 its taps sound
  // with its accents and it has no ghosts, fast passages loud (the user on listening 42).
  const open=1-(Number.isFinite(context?.intensity)?Math.max(0,Math.min(1,context.intensity)):0);
  const heightDb=open*fromQuantiles(data.accentDb,random()),depthDb=open*fromQuantiles(data.ghostBelowDb,random()),ghostShare=open*fromQuantiles(data.ghostShare,random());
  // Each stroke's place in the fill (0 to 1): its slot's, or the caller's (a phrase's strokes by their time).
  const progress=placed??struck.map(slot=>n>1?slot/(n-1):1);
  const along=k=>kind==='rising'?-courseDb*(1-progress[k]):kind==='falling'?-courseDb*progress[k]:0;
  // Its accents: the rudiment's, else its groups' heads; the band's accents it strikes with (caught); and the last
  // stroke of a fill up, its arrival.
  const accented=new Set(accents.length?accents:groupHeads(struck,{n,random})),heard=hearing(n,context);
  struck.forEach((slot,k)=>{if(heard[slot].accent>=choices.caught)accented.add(k)});
  if(fill==='up'&&m)accented.add(m-1);
  // Its ghosts: as many of its strokes as the drawn share, from the quiet end of its course, never an accent.
  const others=[...Array(m).keys()].filter(k=>!accented.has(k));
  const quiet=kind==='rising'?others:kind==='falling'?others.reverse():others.map(k=>[k,random()]).sort((a,b)=>a[1]-b[1]).map(([k])=>k);
  const ghosts=new Set(quiet.slice(0,Math.min(others.length,Math.round(ghostShare*m))));
  const roles=[...Array(m).keys()].map(k=>accented.has(k)?'accent':ghosts.has(k)?'ghost':'tap');
  const levelsDb=roles.map((role,k)=>Math.max(choices.lowestDb,along(k)-(role==='accent'?0:heightDb)-(role==='ghost'?depthDb:0)));
  return {course:{kind,db:courseDb},heightDb,depthDb,roles,levelsDb};
}

// A fill's figure over n slots lasting `seconds`: its rests, a sticking its hands can play, and its dynamics, each drawn
// with `random`. `playable({rests, hands})` says how its hands can play a sticking, worked out from the performer's
// limits (drummer.js handsAllow): 0 (or false) not at all, else the higher the better (true is 1; xdrum_clodbot's 2 is
// swung with the band, 1 in the fill's own subdivision). Nothing is drawn again to find one it can play: of the
// stickings of its rests (fillStickings), one of those its hands play best; where none can be played (strokes at a rate
// only rebound strokes reach), the doubles over its strokes (doublesMotion), which its hands play wherever its strokes
// are no closer than `fastest`, its hands' fastest motion (drummer.js motionSpacing). On a grid finer than that (the
// user, on listening 33: "they should also be able to play tuplet fills that do not attach every component of the
// tuplet"), its strokes fall on every k-th slot, the fewest slots that far apart (a 9-tuplet struck every other note),
// from an offset on the head as often as the drummers' grid figures were (else on another slot alike), and its rests
// among them are drawn as a figure of their own count and rate, keeping the share of the fine slots a figure keeps.
// Null where not even the doubles can be played: a count its caller does not ask (xdrum_clodbot asks only counts whose
// strokes, so placed, its hands reach). {n, rests, struck, sticking, hands, way (the sticking's `playable`), stride,
// course, heightDb, depthDb, roles, levelsDb}.
export function fillFigure({n,seconds,fill='up',random,lead='R',playable=()=>true,fastest=0,context=null,data=GMD_FILL_FIGURES,choices=FILL_FIGURES}={}){
  if(!(seconds>0))throw new RangeError('a figure needs the seconds it lasts');
  const recent=new Set((context?.recent??[]).slice(-choices.recentKept)),rankOf=value=>Math.max(0,Number(value)||0);
  const stride=fastest>0?Math.max(1,Math.ceil(fastest*n/seconds-1e-9)):1;
  let kept=null;
  for(let draw=0;draw<choices.draws;draw++){
    const rests=stride===1?fillRests(n,{slotsPerSecond:n/seconds,random,context,data,choices}):strideRests(n,{stride,seconds,random,context,data,choices}),resting=new Set(rests);
    const struck=[...Array(n).keys()].filter(slot=>!resting.has(slot));
    const options=fillStickings(struck,{n,lead,choices}).map(sticking=>({sticking,way:rankOf(playable({rests,hands:sticking.hands}))}));
    const best=Math.max(0,...options.map(option=>option.way));
    let stickings=options.filter(option=>best>0&&option.way===best);
    if(!stickings.length){const motion=doublesMotion(struck,{lead}),way=rankOf(playable({rests,hands:motion.hands}));if(way>0)stickings=[{sticking:motion,way}]}
    if(!stickings.length)return kept;
    const {sticking,way:played}=stickings[Math.min(stickings.length-1,Math.floor(random()*stickings.length))];
    const figure={n,rests,struck,sticking:sticking.name,hands:sticking.hands,way:played,stride,...fillDynamics(struck,{n,fill,accents:sticking.accents,random,context,data,choices})};
    // Not as it played one of its last: drawn again (and, if every draw is, the first kept).
    if(!recent.has(figureSignature(figure)))return figure;
    kept??=figure;
  }
  return kept;
}
// A figure's rests on a grid finer than its hands (fillFigure): its strokes on every `stride`-th slot from an offset (on
// the head as often as the drummers' grids were: data.gridOnHead), the rests among them those of a figure of their own
// count at their own rate (fillRests: the band's accents heard where they fall, into a crash as the drummers met one),
// keeping as many strokes as a figure of n keeps. [slot], sorted.
export function strideRests(n,{stride,seconds,random,context=null,data=GMD_FILL_FIGURES,choices=FILL_FIGURES}={}){
  const offset=random()<data.gridOnHead?0:1+Math.floor(random()*(stride-1)),positions=[];
  for(let slot=Math.min(offset,n-1);slot<n;slot+=stride)positions.push(slot);
  const coarse=positions.length,least=leastStrokes(n,choices);
  const heard=context?.hearAt?{...context,hearAt:fraction=>context.hearAt(positions[Math.min(coarse-1,Math.round(fraction*coarse))]/n)}:context;
  const out=new Set(fillRests(coarse,{slotsPerSecond:coarse/seconds,random,context:heard,data,choices:{...choices,leastShare:Math.min(1,least/coarse)}}).map(k=>positions[k]));
  return [...Array(n).keys()].filter(slot=>!positions.includes(slot)||out.has(slot));
}
// What makes two figures the same fill played the same way: its slots, its rests, its sticking and its course.
export const figureSignature=figure=>`${figure.n}|${figure.rests.join(',')}|${figure.sticking}|${figure.course?.kind}`;
