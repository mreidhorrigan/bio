// What a player knows of its instrument, in one place (the owner, 3 November 2026: "comprehensive information about the
// instrument's compass and register, as well as analogous context with regard to its comfortable dynamics, pressure
// amount, et cetera"; "You can refactor instrument facts as necessary for efficient maintenance"): each fact read from
// the module that already holds it, never written here, and plain data, so that the instrument's MCP server
// (shared/mcp/instrument-server.js) can say it to the player at startup. Its compass and register (instrument-ranges.js,
// or an engine's compass where one is given), its registers' breath (wind-line.js), the dynamics comfortable in each
// register and its sound power at pp and ff (sound-power.js), its mouth's pressure or its bow's force and contact as
// players were measured (players-ranges.json, baked from native/live/players-ranges.mjs), its articulation and slides,
// its vibrato, its techniques; each with where it came from. A name the bots use or the engines' ('alto' or
// 'alto-flute') finds the same instrument. And, where it is linked to an engine that says what it plays (a live dial's:
// native/openwind/dial.mjs, native/strings-model/dial.mjs), that engine's own: its compass, the techniques and mutes it
// sounds, its quickest note -- so that its player plays this instrument as this engine plays it (the owner, 3 November
// 2026: "the bot applies its personality differently depending on the properties of the instrument it's linked to").
import RANGES from './players-ranges.json' with {type:'json'};
import {instrumentRange,DEFAULT_INSTRUMENT_RANGES} from './instrument-ranges.js';
import {WIND_INSTRUMENTS,WIND_SLIDE,WIND_SLIDE_SPEED,WIND_LINE,registerOf,registerThirds,windModelOf,windInstrumentOf} from './wind-line.js';
import {BOWED_INSTRUMENTS,BOWED_SLIDE_SPEED,BOWED_LINE} from './bowed-line.js';
import {soundPowerOf} from './sound-power.js';
import {WIND_VIBRATO,WIND_VIBRATO_REACH,instrumentVibrato} from './vibrato.js';
import {WIND_MULTIPHONICS,MUTES_OF} from './techniques.js';
import {LINE} from './line.js';
import {player,playerEntry,source} from '../../../registry/registry.js';
import {midiHz} from '../pitch-course.js';
import {turbulenceEntry} from './turbulence.js';

export const FACTS_SCHEMA='musebots.instrument-facts/1';
const KIND_OF_FAMILY=Object.freeze({flute:'air',reed:'reed',brass:'lips'});
const plain=value=>value==null?null:JSON.parse(JSON.stringify(value));
const span=([low,high])=>[low,high];

// The instruments a player may be told of: every wind's and bowed instrument's a bot plays.
export const FACTS_INSTRUMENTS=Object.freeze([...Object.keys(WIND_INSTRUMENTS),...Object.keys(BOWED_INSTRUMENTS)]);
// The bots' name for an instrument the engines name otherwise.
export const factsName=name=>WIND_INSTRUMENTS[windInstrumentOf(name)]?windInstrumentOf(name):name;

// Its compass: the players' (instrument-ranges.js), sounding, with its written range and transposition; its register,
// where its players play most; and, where an engine says what it plays (a spec's compass), that too, the two read
// together by whoever plays it.
function compassOf(id,engine){
  const r=instrumentRange(DEFAULT_INSTRUMENT_RANGES[id]??id);
  return {range:span(r.range),register:span(r.register??r.range),written:{range:span(r.writtenRange??r.range),toSounding:r.writtenToSounding??0},
    ...(r.orchestralRange?{orchestral:span(r.orchestralRange)}:{}),...(r.ordinaryRange?{ordinary:span(r.ordinaryRange)}:{}),
    ...(r.extension?{extension:plain(r.extension)}:{}),...(Number.isFinite(r.harmonicCeiling)?{harmonicCeiling:r.harmonicCeiling}:{}),
    ...(r.strings?{strings:[...r.strings]}:{}),engine:engine?span(engine):null,name:r.name,basis:r.basis,sources:[...(r.sources??[])]};
}
// Its register's thirds, low, middle and high (wind-line.js registerThirds), each with how much faster it spends the breath.
function registersOf(register,spending){
  const thirds=registerThirds(register);
  return Object.fromEntries(Object.entries(thirds).map(([third,range])=>[third,{range,...(spending?{spending:spending[third]}:{})}]));
}
// The dynamics it plays comfortably in each register (a wind's low register no louder than WIND_LINE.lowMost, its high
// none softer than highLeast; a bowed instrument's every dynamic in each), and its sound power at pp and ff where it was
// measured (sound-power.js: TU Berlin's anechoic recordings).
function dynamicsOf(id,wind){
  const marks=[...LINE.dynamics],power=soundPowerOf(windModelOf(id))??soundPowerOf(id);
  const window=(least,most)=>({least,most});
  return {marks,comfortable:wind?{low:window(marks[0],WIND_LINE.lowMost),middle:window(marks[0],marks.at(-1)),high:window(WIND_LINE.highLeast,marks.at(-1)),source:'wind-line.js WIND_LINE (ours)'}
    :{low:window(marks[0],marks.at(-1)),middle:window(marks[0],marks.at(-1)),high:window(marks[0],marks.at(-1)),source:'none measured: every dynamic in every register'},
    soundPower:power?{pp:plain(power.pp),ff:plain(power.ff),source:'sound-power.json (Weinzierl et al. 2017)'}:null};
}

// The techniques an instrument has (techniques.js EXTENDED_TECHNIQUES): a wind's hum, growl and flutter, its mute where
// its players have one and its fingered multiphonics where they were measured; a bowed instrument's pressure, contact,
// natural harmonics and multiphonics -- a synth that sounds no harmonic or multiphonic playing the note ordinario
// (bowed-line.js bowedLimits).
const windKinds=(mutes,multiphonics)=>['hum','growl','flutter',...(mutes.length?['mute']:[]),...(multiphonics.length?['multiphonic']:[])];
const BOWED_KINDS=Object.freeze(['pressure','contact','harmonic','multiphonic']);
// The engine it is linked to, as it says itself: {name, compass?, techniques? (those of its kinds it sounds), mutes?,
// quickest? (s: the least its note takes), source?} -> plain, or why not.
function engineOf(engine){
  if(engine==null)return null;
  if(typeof engine!=='object'||typeof engine.name!=='string')throw new TypeError('instrument-facts: an engine is {name, techniques?, mutes?, quickest?}');
  const names=list=>list==null?null:Array.isArray(list)&&list.every(x=>typeof x==='string')?[...list]:(()=>{throw new TypeError('instrument-facts: an engine\'s techniques and mutes are names')})();
  if(engine.quickest!=null&&!(engine.quickest>0))throw new RangeError('instrument-facts: an engine\'s quickest note is s, over 0');
  return {name:engine.name,techniques:names(engine.techniques),mutes:names(engine.mutes),quickest:engine.quickest??null,source:engine.source??engine.name};
}

// Everything it knows of `instrument` (a bot's name or an engine's) -> plain data. compass: an engine's, where one plays
// it ([low, high], sounding); engine: the engine it is linked to, as it says itself (engineOf).
export function instrumentFacts(instrument,{compass=null,engine=null}={}){
  const id=factsName(instrument),wind=WIND_INSTRUMENTS[id],bowed=BOWED_INSTRUMENTS[id];
  if(!wind&&!bowed)throw new RangeError(`instrument-facts: no player's instrument ${instrument}`);
  const measured=(wind?RANGES.winds:RANGES.strings)[id]??null,ranges=measured?.ranges??{};
  const facts={schema:FACTS_SCHEMA,instrument:id,model:wind?windModelOf(id):id,family:wind?wind.family:'bowed',kind:wind?KIND_OF_FAMILY[wind.family]:'bow',
    compass:compassOf(id,compass),registers:registersOf(wind?wind.register:bowed.register,wind?wind.registers:null),dynamics:dynamicsOf(id,Boolean(wind)),
    measured:Boolean(measured),engine:engineOf(engine)};
  if(wind){
    facts.breath={phonationSeconds:wind.phonationSeconds,byDynamic:{...WIND_LINE.breathDynamics},reserve:WIND_LINE.reserve,topUp:WIND_LINE.topUp,
      pressure:plain(ranges.breath)??jetLaw(windModelOf(id)),litres:plain(ranges.litres),inhale:plain(ranges.inhale),turbulence:turbulenceEntry(windModelOf(id)),
      source:'wind-line.js (ours); players-ranges.json'};
    facts.articulation={tongue:plain(ranges.stroke),repeatRate:plain(ranges.repeatRate),shortest:LINE.shortest,
      slide:{semitones:WIND_SLIDE[id]??null,speed:WIND_SLIDE_SPEED[id]??null,source:'wind-line.js WIND_SLIDE (ours)'}};
    facts.reed=Object.keys(ranges.columns??{}).length?plain(ranges.columns):null;
    const vibrato=WIND_VIBRATO[id];
    facts.vibrato=vibrato?{rate:vibrato.rate,width:vibrato.width,reach:WIND_VIBRATO_REACH[id]??null,source:'vibrato.js WIND_VIBRATO (ours)'}:null;
    const multiphonics=(WIND_MULTIPHONICS[windModelOf(id)]??[]).map(m=>({id:m.id,pitches:[...m.pitches]})),mutes=[...(MUTES_OF[id]??[])];
    facts.techniques={kinds:windKinds(mutes,multiphonics),multiphonics,mutes,sung:['hum','growl','flutter']};
  }else{
    facts.bow={lengthCm:bowed.lengthCm,contact:plain(ranges.beta),force:plain(ranges.force),contactByDynamic:plain(BOWED_LINE.contact),
      nearestContact:BOWED_LINE.nearestContact,slowestBow:BOWED_LINE.slowestBow,fastestShare:BOWED_LINE.fastestShare,source:'bowed-line.js BOWED_LINE; players-ranges.json'};
    facts.articulation={shortest:LINE.shortest,slide:{speed:BOWED_SLIDE_SPEED[id]??null,source:'bowed-line.js BOWED_SLIDE_SPEED (registry)'},
      reach:bowed.reach,strings:[...bowed.strings]};
    const vibrato=instrumentVibrato(id);
    facts.vibrato=vibrato?{...plain(vibrato),measured:plain({width:ranges.width??null,rate:ranges.rate??null})}:null;
    facts.techniques={kinds:[...BOWED_KINDS],multiphonics:[],mutes:[],sung:[],harmonicCeiling:facts.compass.harmonicCeiling??null};
  }
  return facts;
}

// A flute's players' law, where its players were measured as a law rather than note by note (registry/players/winds.json
// jet-woodwind: Fletcher 1975): its blowing pressure a hertz, and its ff over its pp across the measured players.
function jetLaw(model){
  let perHz;try{perHz=playerEntry(model,'breath.perHz')}catch{return null}
  const cited=source(perHz.source);
  return {law:{perHz:perHz.value,ffOverPp:[...player(model,'breath.ffOverPp')]},unit:'Pa',what:'its players\' blowing pressure in proportion to the note\'s frequency (Pa a hertz), and their ff over their pp',
    source:`${cited.authors} ${cited.year}`};
}

// What its facts say at `pitch` (sounding): in its compass and register, by how far outside its register (semitones,
// signed), which third, the dynamics comfortable there, its sound power at pp and ff, its mouth's pressure (Pa, pp to
// ff, read between its measured pitches) and how fast that register spends its breath.
export function factsAt(facts,pitch){
  const [low,high]=facts.compass.range,[from,to]=facts.compass.register,third=registerOf(pitch,[from,to]);
  const beyond=pitch<from?pitch-from:pitch>to?pitch-to:0,power=facts.dynamics.soundPower;
  // (Its sound power only within the notes it was measured on: none read past them.)
  const dbAt=mark=>mark&&(!mark.compass||pitch>=mark.compass[0]&&pitch<=mark.compass[1])?+(mark.db+mark.dbPerSemitone*(pitch-mark.pitch)).toFixed(1):null;
  const points=facts.breath?.pressure?.points;
  let pressure=null;
  if(points?.length){
    const k=points.findIndex(([midi])=>midi>=pitch),a=points[Math.max(0,k<0?points.length-1:k-1)],b=points[k<0?points.length-1:k];
    const x=b[0]===a[0]?0:Math.max(0,Math.min(1,(pitch-a[0])/(b[0]-a[0])));
    pressure={pp:Math.round(a[1]+(b[1]-a[1])*x),ff:Math.round(a[2]+(b[2]-a[2])*x),unit:'Pa',source:facts.breath.pressure.source};
  }
  // (A flute's: its players' typical pressure at the note, and how far they raise it from pp to ff.)
  const law=facts.breath?.pressure?.law;
  if(law)pressure={typical:Math.round(law.perHz*midiHz(pitch)),ffOverPp:[...law.ffOverPp],unit:'Pa',source:facts.breath.pressure.source};
  return {pitch,inCompass:pitch>=low&&pitch<=high,inRegister:!beyond,beyond,register:third,comfortable:{...facts.dynamics.comfortable[third]},
    soundPower:power?{pp:dbAt(power.pp),ff:dbAt(power.ff),unit:'dB re 1 pW'}:null,pressure,spending:facts.registers[third].spending??null};
}
