// The bowed strings' bodies and fingerboards as a luthier builds them: each instrument's `body` part in the registry
// (registry/objects/bowed.json: A. Goldblatt's specification sheets, alangoldblatt.com/specs.html, fetched 17 October
// 2026 into the trunk's research-downloads/strings/body-measurements/, the owner's find -- millimetres, a range's middle
// where a sheet gives a range; an instrument given as data its spec's), and what follows from them by the registry's
// equations: the air inside, the f-holes' conductance as Rayleigh's elliptic apertures (as Nia et al. measured f-holes'),
// where the fingerboard ends, and the lowest air mode (A0) -- the violin's measured (Bellows & Nakayama 2024), any other
// the violin's times its own Helmholtz root over the violin's, sqrt((K/V) / (K/V)_violin), what the walls give, the
// f-holes' wings and the outline's own shape left out of each alike.
import {OBJECTS,entry,equation,source,value} from '../../../registry/registry.js';

const DIMENSIONS=['body','upper','middle','lower','ribs','archTop','archBack','fLength','fWidth','fThickness','fingerboard','string'];
const hasBody=name=>Boolean(OBJECTS[name])&&(()=>{try{entry(name,'body.string');return true}catch{return false}})();
const sheetOf=name=>{if(!hasBody(name))throw new Error(`string-bodies.js: no sheet for ${name}`);return Object.freeze(Object.fromEntries(DIMENSIONS.map(k=>[k,value(name,`body.${k}`)])))};
export const SHEETS=Object.freeze(Object.fromEntries(['violin','viola','cello','contrabass'].map(name=>[name,sheetOf(name)])));
const cite=id=>{const s=source(id);return `${s.authors.split(',').map(a=>a.trim().split(' ').at(-1)).join(' & ')} ${s.year}, doi:${s.doi}`};
const measured=entry('violin','body.airMode');
export const MEASURED_AIR_MODES=Object.freeze({violin:Object.freeze({hz:measured.value,source:cite(measured.source)})});

// (Where the string meets the fingerboard's end, in semitones over the open string.)
export const fingerboardEnd=name=>{sheetOf(name);return value(name,'body.fingerboardEnd')};
// (An elliptic aperture's conductance in a thin wall, semi-axes a over b, a wall of thickness t in series: the registry's
// equation, Rayleigh's.)
export const conductance=(a,b,t=0)=>equation('elliptic-aperture-conductance',{a,b,t});
export function airMode(name){
  sheetOf(name);
  const e=entry(name,'body.airMode');
  if(e.kind==='literature')return {hz:e.value,measured:true,source:cite(e.source)};
  return {hz:e.value,measured:false,source:"calculated from Goldblatt's measurements of its body and f-holes as a Helmholtz resonator, scaled by the violin's measured A0"};
}
