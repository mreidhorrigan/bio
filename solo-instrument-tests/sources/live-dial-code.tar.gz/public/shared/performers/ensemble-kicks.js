// The user's policy for the ensemble's kick drums: no two independent kick contacts at once, whoever plays them (the
// rudiments report §1, and its T18: the policy survives layering and overdubbing). Measured before this existed
// (research/PERFORMER_CONSTRAINTS_M0.md): xdrum_clodbot and papperc_clodbot together put two kicks on one moment 2 and
// 8 times in eight bars.
//
// Every bot's audio engine in one page, or one render, schedules on one AudioContext, so the kicks scheduled on it can
// be compared exactly where they are scheduled, rather than announced to each other in messages that would arrive after
// the downbeat they were about. The first performer to schedule a kick at a moment keeps it; another performer's kick
// within sameMomentSeconds of it yields, and the rest of that performer's drums play on. One performer's layers of one
// kick (a sample layer, a split kit's channel, a synthesized voice under a recorded one) are one contact, never a clash.
// Kicks a moment apart are not at once: alternating feet, or two drummers trading, are allowed.
//
// Across machines (conductors joined over a network) each context keeps its own register: the policy holds among the
// bots sharing a machine's room, not between machines.

// ---- Choices ---------------------------------------------------------------------------------------------------------
export const ENSEMBLE_KICKS=Object.freeze({
  // Two kicks this close are one moment (ours: under the 26 ms of a drummer's flam, at the edge of hearing two attacks
  // as one).
  sameMomentSeconds:.01,
  // Claims older than this before the newest are forgotten (scheduling looks ahead by well under it).
  keepSeconds:4,
  // How many claims a register holds before it forgets the old ones.
  mostClaims:256,
});

const registers=new WeakMap();

// Whether `performer` may sound a kick at `seconds` on `context`: true, and the kick claimed, unless another performer
// has claimed one within the same moment. No context, or no time, and there is nothing to compare: true.
export function claimKick(context,seconds,performer){
  if(!context||typeof context!=='object'||!Number.isFinite(seconds))return true;
  let claims=registers.get(context);
  if(!claims)registers.set(context,claims=[]);
  if(claims.length>ENSEMBLE_KICKS.mostClaims){
    const newest=Math.max(...claims.map(claim=>claim.seconds));
    claims.splice(0,claims.length,...claims.filter(claim=>claim.seconds>newest-ENSEMBLE_KICKS.keepSeconds));
  }
  if(claims.some(claim=>claim.performer!==performer&&Math.abs(claim.seconds-seconds)<ENSEMBLE_KICKS.sameMomentSeconds))return false;
  claims.push({seconds,performer});
  return true;
}
