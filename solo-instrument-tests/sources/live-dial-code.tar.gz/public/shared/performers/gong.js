// A gong player's principles (the family atlas's F30: gongs). The gong marks the music's large units, as a gamelan's
// gong ageng closes each gongan, its largest cycle, and an orchestra's tam-tam marks an arrival:
//   - where: the form's joins, where the music arrives in a new section, and within a section the start of each cycle
//     of phrases, the fewest whole phrases lasting at least GONG.cycleSeconds, counted from the section's start;
//   - how hard: by the intensity the music arrives at, a join marked a step over a cycle (the arrivals' hierarchy);
//   - how long it rings: as the band's space asks, from left to ring to damped by a hand.
// A stroke is one mallet's, a cycle or more apart: playable by construction.

export const GONG=Object.freeze({
  // Its note. General MIDI has no gong; ours: the first note past General MIDI 2's percussion (27 to 87).
  note:88,
  // The shortest cycle it marks (ours: a lancaran's gongan, sixteen beats at about 120 a minute, the busiest of the
  // gamelan's forms).
  cycleSeconds:8,
  // A stroke's level (0 to 1, the kit's velocity), from the least intense arrival to the most: a join's, and a cycle's
  // a step under it (ours: the recordings' four dynamics, p to fff, each a quarter of the range).
  join:Object.freeze([.3,1]),cycle:Object.freeze([.15,.7]),
  // How far a dry band's gong is damped: 1 less its space, at most this (ours: a hand laid on it, never stopping it).
  mostDamping:.8,
});

const clamp=(value,low,high)=>Math.max(low,Math.min(high,value));

// How many phrases a cycle holds: the fewest whole phrases of `phraseSeconds` lasting at least cycleSeconds.
export function cyclePhrases(phraseSeconds,{cycleSeconds=GONG.cycleSeconds}={}){
  return Number.isFinite(phraseSeconds)&&phraseSeconds>0?Math.max(1,Math.ceil(cycleSeconds/phraseSeconds-1e-9)):1;
}
// Whether a bar begins a cycle: the section began on `sectionStart`, its phrases `phraseBars` long, a cycle `phrases`.
export const beginsCycle=(bar,{sectionStart=0,phraseBars=4,phrases=1}={})=>
  bar>=sectionStart&&(bar-sectionStart)%(Math.max(1,phraseBars)*Math.max(1,phrases))===0;
// A stroke's level at an arrival's intensity (0 to 1): a join's ('join') or a cycle's ('cycle').
export function strokeLevel(intensity,kind='cycle',choices=GONG){
  const [low,high]=choices[kind]??choices.cycle;
  return low+(high-low)*clamp(Number.isFinite(intensity)?intensity:.5,0,1);
}
// How far a hand damps it, as the band's space (0 dry to 1 roomy) asks.
export const strokeDamping=(space,choices=GONG)=>choices.mostDamping*(1-clamp(Number.isFinite(space)?space:.5,0,1));
