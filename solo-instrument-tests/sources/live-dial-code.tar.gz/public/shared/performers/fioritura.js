// A fioritura: a melodic ornament across the beat, as Chopin writes them, eleven or thirteen notes in the time of eight
// (the user's stress test, 28 September 2026: "applying the lessons from drum rhythm to other instruments; Chopin-style
// tuplet ornaments?"). The drummer's fill carried to a pitched voice:
//   - like a fill, it fills the end of a held note and lands on the next note's onset with the band, as a fill lands on
//     the downbeat, so the line's own notes keep their places (a theme ornamented is still the theme);
//   - its rhythm is a tuplet cell of its own over the span (fill-phrase.js cellContacts: exact, rationals of ticks), any
//     of whose places may itself be a tuplet (a turn: three or five in the time of one; fill-phrase.js nest);
//   - its pitches go stepwise through the voice's own pitches (its pool, in every octave of its range, whatever the
//     tuning) from the held note to the next, past it and back where it has notes to spare, and turning at the range's
//     edge in a trill;
//   - its loudness is light, rising to its turn and falling into the landing, its group heads a little louder;
//   - its time is its own: the tuplet warped by a rubato slow at its ends and quick in the middle, its ends kept, so it
//     leaves and meets the band where the tuplet does (the voice's tempo rubato: the right hand free, the left hand
//     keeping time).
// Every choice is a continuum (the user: "everything must be interpolable"): its amount from 0 (none) to 1 sets how
// often a note is ornamented, how quick its notes are, how far it overshoots and how much it bends; the tuplet exact at
// no rubato.
import {Rational} from '../../transcript/rational.js';
import {scoreTime} from '../score-time.js';
import {cellContacts,nest} from './fill-phrase.js';

export const FIORITURA=Object.freeze({
  // The mean note rates an ornament takes, from the least amount to the most (notes a second, authored; slower than six
  // it is a line, not an ornament), and the quickest any of its notes may be, under its rubato: a pianist's run at
  // twenty a second (piano.js: a finger leaves one key for another in 0.04 s).
  rates:Object.freeze([6,16]),quickest:20,
  // The least notes, and the least span in seconds, worth ornamenting.
  leastNotes:3,leastSeconds:.35,
  // The share of a held note kept before its ornament begins (the rest is the ornament's).
  held:.5,
  // The most rubato inside an ornament, at amount 1: its ends this much slower than its mean, its middle this much
  // quicker (a warp x + a sin(2 pi x) / 2 pi of the span).
  rubato:.35,
  // Loudness, as shares of the line's velocity: its body, the swell to its turn, a group head's accent.
  velocity:Object.freeze({body:.7,swell:.12,head:.05}),
  // A place nested as a turn, at amount 1 (fill-phrase.js nest's appetite; its count one whose notes the quickest allows).
  nesting:.3,
});

const clamp=(x,low,high)=>Math.max(low,Math.min(high,x));
const fit=(pitch,[low,high])=>{let value=Number(pitch);while(value<low)value+=12;while(value>high)value-=12;return value};
// Every pool pitch in every octave of the range, low to high (as a cadenza takes its pitches: cadenza.js).
export function ornamentPitches(pool,[low,high]){
  const classes=[...new Set((pool??[]).map(Number).filter(Number.isFinite).map(pitch=>fit(pitch,[low,low+12-1e-9])))].sort((a,b)=>a-b),out=[];
  for(let octave=0;low+octave*12<=high;octave++)for(const pitch of classes){const value=pitch+octave*12;if(value>=low&&value<=high)out.push(value)}
  return out.sort((a,b)=>a-b);
}
const nearest=(pitches,pitch)=>pitches.reduce((best,value,index)=>Math.abs(value-pitch)<Math.abs(pitches[best]-pitch)?index:best,0);

// The ornament's pitches: `count` notes after `from` and before `to`, a walk through `pitches` (sorted, low to high;
// `from` and `to` among them) whose steps are one pitch each. Notes to spare go out and back in pairs: first the other
// way from the held note (a turn below, for an ascent), `lead` of them (0 to 1), then past the target and back (an arc).
// Where the range stops a turn, its steps go to the arc; where it stops the arc, the walk trills at the edge. An odd
// step to spare is a note struck twice where the walk turns (the held note itself, where it does not turn, so the
// ornament never ends on its target's pitch). Too few notes for the distance, it skips evenly. -> [pitch], `count` long.
export function fiorituraContour({from,to,pitches,count,lead=0}){
  const n=pitches.length;
  if(!(count>=1)||n<2)return [];
  const a=nearest(pitches,from),b=nearest(pitches,to),distance=Math.abs(b-a),direction=b>=a?1:-1,steps=count+1;
  if(steps<distance)return Array.from({length:count},(_,k)=>pitches[a+direction*Math.round((k+1)*distance/steps)]);
  const repeat=(steps-distance)%2,pairs=(steps-distance-repeat)/2,edge=index=>clamp(index,0,n-1);
  const before=Math.round(clamp(lead,0,1)*pairs),dip=edge(a-direction*before);
  const after=pairs-Math.abs(dip-a),apex=edge(b+direction*after),trills=after-Math.abs(apex-b),neighbour=edge(apex-direction);
  const path=[];let at=a;
  const walk=target=>{while(at!==target){at+=Math.sign(target-at);path.push(at)}};
  const twice=!repeat?null:dip!==a?'dip':apex!==b?'apex':'held';
  if(twice==='held')path.push(a);
  walk(dip);if(twice==='dip')path.push(dip);
  walk(apex);if(twice==='apex')path.push(apex);
  for(let k=0;k<trills;k++)path.push(neighbour,apex);
  walk(b);
  // The walk's last step is the landing, the target's own note: the ornament is every step before it.
  return path.slice(0,count).map(index=>pitches[index]);
}

// A warp of the span, its ends kept: slow at its ends and quick in the middle by `a` (0: the tuplet exact).
export const warp=(x,a)=>x+a*Math.sin(2*Math.PI*x)/(2*Math.PI);

// A fioritura over a span of `spanTicks` ticks of `tickSeconds`, from the held note `from` to the next note `to`, in the
// voice's `pool` and `range`, at `amount` (0 to 1), with `random`. -> {notes: [{pitch, at (ticks from the span's start),
// velocity (a share of the line's), head}], count, cell, rubato} or null where the span is too short to ornament.
export function planFioritura({from,to,pool,range,spanTicks,tickSeconds,amount=1,random,choices=FIORITURA}){
  const seconds=spanTicks*tickSeconds,level=clamp(amount,0,1);
  if(!(seconds>=choices.leastSeconds)||!(level>0))return null;
  // The voice's own pitches, at least three of them, with the held note and the next among them.
  const own=ornamentPitches(pool,range);
  if(own.length<3)return null;
  const pitches=[...new Set([...own,Number(from),Number(to)])].sort((x,y)=>x-y);
  const rate=choices.rates[0]+(choices.rates[1]-choices.rates[0])*level,most=Math.floor(seconds*choices.quickest);
  // As many notes as its rate asks, a tuplet against its slots where the count would divide them (Chopin's elevens and
  // thirteens, not eights), and never more than the quickest allows: more amount, never fewer notes.
  let count=Math.min(most,Math.max(choices.leastNotes,Math.round(seconds*rate)));
  if(count<choices.leastNotes)return null;
  if(Number.isInteger(spanTicks)&&(count%spanTicks===0||spanTicks%count===0)&&count+1<=most)count++;
  // Its cell: one tuplet over the span, a place perhaps a turn of its own (the nested notes counted in), its count drawn
  // from those whose notes are no quicker than the quickest.
  const placed=cell=>cellContacts(cell,{start:Rational.of(0),span:Rational.of(spanTicks)});
  const quickestGap=list=>Math.min(...list.map((contact,k)=>((list[k+1]?.at.toNumber()??spanTicks)-contact.at.toNumber())*tickSeconds));
  const cell=nest({n:count,rests:[]},{appetite:choices.nesting*level,seconds,random,fastest:1/choices.quickest}),contacts=placed(cell);
  // Its rubato as the amount asks, as far as its quickest notes allow: the warp quickens a note by at most 1 - rubato.
  const rubato=Math.max(0,Math.min(choices.rubato*level,1-1/(choices.quickest*quickestGap(contacts))));
  const contour=fiorituraContour({from,to,pitches,count:contacts.length,lead:random()});
  if(contour.length!==contacts.length)return null;
  const turn=contour.reduce((best,pitch,index)=>Math.abs(pitch-from)>Math.abs(contour[best]-from)?index:best,0);
  const notes=contacts.map((contact,index)=>{
    const x=contact.at.toNumber()/spanTicks,head=contact.path.at(-1)===0&&contact.depth>0;
    const toTurn=turn>0?Math.min(1,index/turn):1,afterTurn=index>turn?(index-turn)/Math.max(1,contacts.length-1-turn):0;
    const velocity=choices.velocity.body+choices.velocity.swell*(index<=turn?toTurn:1-afterTurn)+(head?choices.velocity.head:0);
    // (`written`: its place in the tuplet; `at` where its warp plays it -- rubato, which its score leaves out.)
    const end=contacts[index+1]?.at??Rational.of(spanTicks);
    return {pitch:contour[index],at:warp(x,rubato)*spanTicks,written:contact.at.toNumber(),
      scoreTime:scoreTime(contact.at,end.sub(contact.at),{axis:'ornament'}),velocity,head};
  });
  return {notes,count:contacts.length,cell,rubato};
}
