// The melody's rules, said once (the owner, 5 November 2026: "where multiple scattered rules have been written that
// actually accomplish the same result, refactoring those rules into a smaller number will mean that fixing erroneous
// cases will lead to better generative behaviour more quickly"): what a line may do, for every planner of one -- a
// motif's shape and its simplification, a phrase's contour, a pianist's run, a figure and a cadence (line.js,
// figure-space.js). A line is indices into its voice's pitches; a move, the steps from one note to the next (0 a note
// struck again).
//   - **A leap answered:** a move of leapSteps or more is followed by a step back the other way, of at most recoverMost
//     (the registry's), and is never the line's last move -- unless a silence comes between (a comma: the line begins
//     again there). Where `acrossRepeats`, a note struck again may come between a leap and its answer.
//   - **No leap wider than `widest`** (the line's leapMost).
//   - **No run of more than `runMost` moves one way,** a note struck again neither adding to it nor ending it.
//   - **No note more than `alike` times running:** twice at most (the registry's alikeMost), or never struck again at
//     once (1).
//   - **No trill** (where `trill`): never a move undoing the one before it where that undid the one before it -- four
//     notes alternating between two, a note struck again neither adding to it nor ending it -- unless the line chooses
//     one there (`chosen`: an ornament's, figure-space.js).
//     Whether two alternating notes are a trill or two voices is perception's to say (streams.js).
//   - **A move between voices** (`apart`: a compound melody's, where its notes stream apart) is none of the line's own:
//     the rules begin again from it, each voice keeping them on its own.
// The rules walk a line move by move (`advance`): a search keeps only what keeps them, a cost counts what they break,
// and a check replays a line through them (`broken`) -- one walk for all of them.
import {setting} from '../../../registry/registry.js';

const RECOVER_MOST=setting('melody','recoverMost');
export const ALIKE_MOST=setting('melody','alikeMost');
// The rules by name, as a walk says which it broke.
export const RULES=Object.freeze(['widest','leap','last','alike','run','trill']);

// A move's leap: its direction where it is one (leapSteps or more), else 0.
export const leapOf=(move,choices)=>Math.abs(move)>=choices.leapSteps?Math.sign(move):0;
// Whether a move answers a leap (the leap's direction): a step back the other way.
export const answers=(move,leap)=>Math.sign(move)===-leap&&Math.abs(move)<=RECOVER_MOST;
// Whether a move makes a trill with the two moves before it: each undoing the one before.
export const trills=(move,before,earlier)=>move!==0&&move===-before&&before===-earlier;
// The trills of a list of indices, a repeated note neither adding to one nor ending it: each move that makes one with
// the two moves before it. -> [{at: its note's place in the list, from: the place its first move leaves}].
export function trillSpans(indices){
  const out=[];let before=0,earlier=0,beforeFrom=0,earlierFrom=0;
  for(let k=1;k<indices.length;k++){
    const move=indices[k]-indices[k-1];if(!move)continue;
    if(trills(move,before,earlier))out.push({at:k,from:earlierFrom});
    earlier=before;earlierFrom=beforeFrom;before=move;beforeFrom=k-1;
  }
  return out;
}
// The notes of a list of indices whose move makes a trill (trillSpans). -> [the note's place in the list].
export const trillsIn=indices=>trillSpans(indices).map(({at})=>at);
// The longest run in a list of indices, a repeated note neither adding to it nor ending it.
export function longestRun(indices){
  let run=0,direction=0,most=0;
  for(let k=1;k<indices.length;k++){const d=Math.sign(indices[k]-indices[k-1]);if(!d)continue;run=d===direction?run+1:1;direction=d;most=Math.max(most,run)}
  return most;
}
// A run's length at the end of a list of indices: its last moves one way, a repeated note neither adding nor ending it.
export function runAtEnd(indices){
  let run=0,direction=0;
  for(let k=indices.length-1;k>0;k--){const d=Math.sign(indices[k]-indices[k-1]);if(!d)continue;if(!direction)direction=d;if(d!==direction)break;run++}
  return run;
}
// The moves at the start of a list of indices going on one way (`direction`, a sign), a repeated note neither adding
// nor ending them.
export function runAtStart(indices,direction){
  let run=0;
  for(let k=1;k<indices.length;k++){const d=Math.sign(indices[k]-indices[k-1]);if(!d)continue;if(d!==direction)break;run++}
  return run;
}

// The rules for a line's `choices` (leapSteps, leapMost, runMost), each as asked: {widest, alike, acrossRepeats, trill,
// leaps (false: an ornament's moves free of the leap rule), runMost}. -> {start, advance, key, replay, broken}: a state
// is {leap (the direction of a leap waiting for its answer, or 0), same (the notes alike at its end), dir and len (its
// last run's direction and moves), before and earlier (its last two moves to another note)}.
export function melodyRules(choices,{widest=choices.leapMost,alike=ALIKE_MOST,acrossRepeats=false,trill=true,leaps=true,runMost=choices.runMost}={}){
  const start=()=>({leap:0,same:1,dir:0,len:0,before:0,earlier:0});
  // The state after one more move: `silence`, a silence before its note; `last`, the line's last move; `chosen`, a trill
  // the line asks for here; `apart`, a move between voices. Each rule it breaks named in `broken`, where a list is
  // given; where none is, null at the first.
  function advance(state,move,{silence=false,last=false,chosen=false,apart=false,broken=null}={}){
    // (A move to another voice answers no leap: a leap is answered in its own voice.)
    if(apart){if(state.leap&&breaks('leap'))return null;return start()}
    const breaks=rule=>{if(!broken)return true;broken.push(rule);return false};
    if(Math.abs(move)>widest&&breaks('widest'))return null;
    let waiting=silence?0:state.leap;
    if(waiting&&(move!==0||!acrossRepeats)){
      if(!answers(move,waiting)&&breaks('leap'))return null;
      waiting=0;
    }
    const leap=!leaps?0:move===0?waiting:silence?0:leapOf(move,choices);
    if(last&&leap&&breaks('last'))return null;
    const same=move===0?state.same+1:1;
    if(same>alike&&breaks('alike'))return null;
    const turned=move!==0&&Math.sign(move)!==state.dir,dir=move===0?state.dir:Math.sign(move),len=move===0?state.len:turned?1:state.len+1;
    if(len>runMost&&breaks('run'))return null;
    if(trill&&!chosen&&trills(move,state.before,state.earlier)&&breaks('trill'))return null;
    return {leap,same,dir,len,before:move||state.before,earlier:move?state.before:state.earlier};
  }
  // What of a state the rules ahead depend on: settings alike in it can follow alike.
  const key=state=>`${state.leap}|${state.same}|${state.dir}|${state.len}${trill?`|${state.before}|${state.before!==0&&state.before===-state.earlier}`:''}`;
  // A line's state at its end, its rules' breaks set aside: `silences`, the notes a silence comes before.
  function replay(indices,{silences=[]}={}){
    let state=start();
    for(let k=1;k<indices.length;k++)state=advance(state,indices[k]-indices[k-1],{silence:silences.includes(k),broken:[]});
    return state;
  }
  // The rules a line breaks, where: [{rule, at (the note it breaks them at)}]. `chosen` and `apart`: lists of the notes
  // whose moves are a chosen trill's or between voices.
  function broken(indices,{silences=[],chosen=[],apart=[]}={}){
    let state=start();const out=[];
    for(let k=1;k<indices.length;k++){
      const found=[];
      state=advance(state,indices[k]-indices[k-1],{silence:silences.includes(k),last:k===indices.length-1,chosen:chosen.includes(k),apart:apart.includes(k),broken:found});
      for(const rule of found)out.push({rule,at:k});
    }
    return out;
  }
  return Object.freeze({start,advance,key,replay,broken});
}
