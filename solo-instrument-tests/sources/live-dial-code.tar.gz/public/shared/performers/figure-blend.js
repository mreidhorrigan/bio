// Fill and groove as one continuum (research/FILL_FIGURES.md, "One continuum"). The user, 28 September 2026, on
// listening 37: "We likely need to establish a continuity of principles between fills and grooves to allow for complete
// interpolation between them"; and what interpolable means: "A parameter or set of parameters is interpolable when
// intermediate states exist between all the their possible states ... in actual music, parameters can and should jump".
//
// A drummer's figure over a span is its groove's strokes and a fill's, each at a level between none and its own. One
// number, the span's fillness (0 the groove, 1 the fill), says where it stands. Each of the fill's strokes enters at a
// threshold, and each of the groove's hand strokes leaves at one, in an order the drummer chooses:
// - 'metrical': the weakest positions first, so the fill takes the offbeats before the beats and the groove keeps its
//   beats longest;
// - 'landing': from the span's end back, a fill growing from its landing;
// - 'even': in the drummer's own random order.
// Ties are broken by the drummer's own stream. A stroke's level moves continuously with the fillness, across a width of
// one step, so between any two fillnesses there is a state between them (every stroke's level between its two). The
// ends are exact: at 0 the groove alone, at 1 the fill as planned. The path may still jump: a drummer may go from any
// fillness to any other at once.
export const FIGURE_BLEND=Object.freeze({orders:Object.freeze(['metrical','landing','even']),
  // How far the fillness moves while one stroke's level moves from none to its own.
  width:.25,
  // How often a bar at some fillness plays the last bar's figure again (ours): a steady fillness heard as a groove needs
  // its figure back most bars, and a new one now and then.
  restate:.75});

const clamp=value=>Math.max(0,Math.min(1,value));
const near=(a,b)=>Math.abs(a-b)<1e-9;

// A position's metrical weight in its span: 3 at the span's start, 2 at a felt beat's, 1 at a half or a third of one,
// 0 elsewhere. `at` and the felt beats' starts are ticks from the span's start; `span` is its length in ticks.
export function metricalWeight(at,{beatStarts,span}){
  if(near(at,0))return 3;
  const starts=[...beatStarts,span].sort((a,b)=>a-b);
  let k=0;while(k+1<starts.length&&starts[k+1]<=at+1e-9)k++;
  if(near(at,starts[k]))return 2;
  const length=starts[k+1]-starts[k],phase=(at-starts[k])/length;
  return [1/2,1/3,2/3].some(part=>near(phase,part))?1:0;
}

// A stroke's threshold, the fillness at which its level begins to move, from 0 to 1 less the width, by the order:
// 'metrical' by its weight (a quarter of the range each, from the weakest), 'landing' by its distance from the span's
// end (the last first), 'even' by its draw alone. `u` is the stroke's own draw from the drummer's stream, from 0 to 1,
// which orders strokes of one weight; `position` is its place in the span, from 0 to 1.
export function strokeThreshold({weight=0,position=0,u},{order='metrical'}={}){
  if(!FIGURE_BLEND.orders.includes(order))throw new RangeError(`a blend's order is one of ${FIGURE_BLEND.orders.join(', ')}, not ${order}`);
  if(!(u>=0&&u<1))throw new RangeError('a stroke\'s draw is from 0 to 1');
  const share=order==='metrical'?(Math.max(0,Math.min(3,weight))+u)/4:order==='landing'?clamp(1-position)*(1-1e-6)+u*1e-6:u;
  return share*(1-FIGURE_BLEND.width);
}

// The thresholds of a fill's strokes, all known when it is planned, spread evenly by count: in the order's ranking
// (weight, then place, then draw), the r-th of n begins to move at r/n of the range. So at a fillness f about f of its
// strokes sound, the weakest first, and its hands are free between them for the groove. items: [{id, weight, position,
// u}]. -> Map id -> threshold.
export function rankThresholds(items,{order='metrical'}={}){
  if(!FIGURE_BLEND.orders.includes(order))throw new RangeError(`a blend's order is one of ${FIGURE_BLEND.orders.join(', ')}, not ${order}`);
  const sorted=[...items].sort(order==='landing'?(a,b)=>b.position-a.position||a.u-b.u:order==='even'?(a,b)=>a.u-b.u:(a,b)=>a.weight-b.weight||a.u-b.u);
  return new Map(sorted.map((item,rank)=>[item.id,rank/Math.max(1,sorted.length)*(1-FIGURE_BLEND.width)]));
}

// A stroke's level (0 to 1) at a fillness: an entering stroke (the fill's) rises from 0 at its threshold to 1 a width
// later; a leaving one (the groove's) falls from 1 at its threshold to 0 a width later. Thresholds are below 1 less the
// width, so at fillness 0 no fill stroke sounds and every groove stroke does, and at 1 the reverse.
export function blendLevel(threshold,fillness,{entering}){
  const f=clamp(fillness),width=FIGURE_BLEND.width;
  return entering?clamp((f-threshold)/width):clamp((threshold+width-f)/width);
}

// A fillness over a performance: a number, or points [[bar, value], ...] joined by straight lines, held before the
// first and after the last; `bar` may be fractional (a bar and its part). -> the fillness at a bar position.
export function fillnessAt(fillness,barPosition){
  if(fillness==null)return null;
  if(Number.isFinite(fillness))return clamp(fillness);
  const points=fillness;
  if(!Array.isArray(points)||!points.length)throw new RangeError('a fillness is a number from 0 to 1, or [[bar, value], ...]');
  if(barPosition<=points[0][0])return clamp(points[0][1]);
  for(let k=1;k<points.length;k++){
    const [x0,y0]=points[k-1],[x1,y1]=points[k];
    if(barPosition<=x1)return clamp(x1===x0?y1:y0+(y1-y0)*(barPosition-x0)/(x1-x0));
  }
  return clamp(points.at(-1)[1]);
}

// A drum solo's course, the drummer's own (ours): sections of 2 to 8 bars, each at a fillness drawn from one of three
// regions -- a groove of its own, between, a fill -- never the same region twice running, so each section is a contrast
// heard. Into each by a ramp over its first bars, or at once (a jump) two times in five: the user, "in actual music,
// parameters can and should jump or have strong discontinuities sometimes". Each section also chooses how often its bars
// come back, since a figure that comes back is heard as a groove: a groove's section mostly restated; a fill's either
// chained, a new figure every bar, or restated, a fill made a groove (37 C); between, either. random: the drummer's
// stream. -> a function of the bar position (bars from 1), each section's restatement, and the sections drawn.
export const SOLO_COURSE=Object.freeze({regions:Object.freeze([[.1,.3],[.4,.65],[.8,1]]),bars:Object.freeze([2,3,4,6,8]),jump:.4,rampBars:2,
  restate:Object.freeze([Object.freeze([.9]),Object.freeze([.3,.9]),Object.freeze([0,.9])]),
  // The solo's arc (the user on 42: "The solo could use density/speed/intensity shaping to create a climax"): its
  // intensity rising to a climax at `peak` of the solo and falling after to `after` (ours).
  peak:.7,after:.2,
  // How far the arc leans a section's region: at intensity 1 the fill, at 0 its groove, by this much against the draw.
  lean:.8,
  // Within this of the arc's top a fill section may follow a fill, and within it of the bottom a groove a groove (ours).
  hold:.15});

// The solo's intensity at a share of it (0 to 1): rising straight to 1 at its peak, falling after to SOLO_COURSE.after
// at its end. A share outside 0 to 1 is held at the nearer end.
export function soloArc(share){
  const x=Math.max(0,Math.min(1,share)),{peak,after}=SOLO_COURSE;
  return x<=peak?x/peak:1-(1-after)*(x-peak)/(1-peak);
}
export function soloCourse(random,{intensityAt=null,mostBars=Infinity}={}){
  // (mostBars: a number, or a function of the bar a section begins at, read as it is drawn.)
  const lengthsAt=from=>{const most=typeof mostBars==='function'?mostBars(from):mostBars,fitting=SOLO_COURSE.bars.filter(bars=>bars<=most);return fitting.length?fitting:[SOLO_COURSE.bars[0]]};
  const sections=[];
  const extend=until=>{
    while(!sections.length||sections.at(-1).to<=until){
      const last=sections.at(-1),from=last?.to??1,lengths=lengthsAt(from),bars=lengths[Math.floor(random()*lengths.length)];
      // Leaned by the arc where there is one: its region the nearer the fill the nearer the climax, never the last's.
      // (A climax may hold the fill, and its start and end the groove: SOLO_COURSE.hold.)
      const intensity=intensityAt?intensityAt(from):null,held=region=>intensity!==null&&(region===2&&intensity>=1-SOLO_COURSE.hold||region===0&&intensity<=SOLO_COURSE.hold);
      const regions=[...SOLO_COURSE.regions.keys()].filter(region=>region!==last?.region||held(region));
      const drawn=random(),region=intensity===null?regions[Math.floor(drawn*regions.length)]
        :regions.reduce((best,candidate)=>Math.abs(candidate/2-(SOLO_COURSE.lean*intensity+(1-SOLO_COURSE.lean)*drawn))<Math.abs(best/2-(SOLO_COURSE.lean*intensity+(1-SOLO_COURSE.lean)*drawn))?candidate:best);
      const [low,high]=SOLO_COURSE.regions[region],target=low+(high-low)*random(),jump=!last||random()<SOLO_COURSE.jump;
      const choices=SOLO_COURSE.restate[region],restate=choices[Math.floor(random()*choices.length)];
      sections.push(Object.freeze({from,to:from+bars,region,target,jump,restate,start:last?last.target:target,...(intensity===null?{}:{intensity})}));
    }
  };
  const sectionAt=position=>{extend(position);return sections.find(entry=>position>=entry.from&&position<entry.to)??sections[0]};
  const at=position=>{
    const section=sectionAt(position);
    if(section.jump)return section.target;
    const along=Math.min(1,(position-section.from)/Math.min(SOLO_COURSE.rampBars,section.to-section.from));
    return section.start+(section.target-section.start)*along;
  };
  return {at,restateAt:position=>sectionAt(position).restate,sections};
}

// A fillness setting, checked: a number from 0 to 1, or [bar, value] points in order of bar. A render spec passes its
// bots only plain values (spec-settings.js), so the points may also come as a string of bar:value pairs, "1:0 7:1 13:0".
export function checkedFillness(value){
  if(value==null)return null;
  if(typeof value==='string'){
    const pairs=value.trim().split(/[\s,;]+/).filter(Boolean).map(pair=>pair.split(':').map(Number));
    if(!pairs.length||pairs.some(pair=>pair.length!==2))throw new RangeError(`a fillness's points as a string are bar:value pairs, as "1:0 7:1", not "${value}"`);
    return checkedFillness(pairs);
  }
  if(Number.isFinite(value)){if(value<0||value>1)throw new RangeError(`a fillness is from 0 to 1, not ${value}`);return value}
  if(!Array.isArray(value)||value.length<1||value.some(point=>!Array.isArray(point)||point.length!==2||!Number.isFinite(point[0])||!Number.isFinite(point[1])||point[0]<0||point[1]<0||point[1]>1))
    throw new RangeError('a fillness is a number from 0 to 1, or [[bar, value], ...] with values from 0 to 1');
  if(value.some((point,k)=>k&&point[0]<value[k-1][0]))throw new RangeError('a fillness\'s points are in order of bar');
  return Object.freeze(value.map(point=>Object.freeze([...point])));
}
