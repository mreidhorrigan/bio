// Motifs a player is given as MusicXML (the owner, 3 November 2026: "even specific motifs (that can be preloaded as
// musicXML) that the playerbot prefers"): each file's line as a line's notes -- [{at (quarters from its first note),
// pitch (sounding, MIDI, fractional where written so), written (its onset, exact quarters)}] -- which line.js
// motifFromLine makes a motif in whatever meter the player is in. Its first pitched part with notes (or the one named),
// its top note where notes sound together, a tied note one note, its rests left out; each pitch sounding through the
// part's transposition (notation/musicxml-read.js).
import {musicXMLToScore} from '../../notation/musicxml-read.js';
import {Rational} from '../../transcript/rational.js';

const QUARTERS=new Rational(4);
const pitchedPart=(score,which)=>{
  const pitched=score.parts.filter(p=>p.kind!=='percussion');
  const found=which==null?pitched.find(p=>p.measures.some(c=>c.voices.some(v=>v.elements.some(e=>!e.rest)))):score.parts.find(p=>p.id===which||p.name===which);
  if(!found)throw new Error(`musicxml-motifs: no ${which==null?'pitched part with notes':`part ${which}`}`);
  return found;
};

export function motifLine(text,{part=null}={}){
  const score=musicXMLToScore(text),chosen=pitchedPart(score,part),transpositions=chosen.transpositions??[];
  const sounding=(pitch,at)=>pitch+(transpositions.filter(t=>t.start.le(at)).at(-1)?.semitones??0);
  const notes=[];
  for(const content of chosen.measures)for(const voice of content.voices){
    if(voice.filler)continue;
    let tied=null;
    for(const element of voice.elements){
      if(element.rest){tied=null;continue}
      const pitches=element.notes.filter(n=>n.pitch!=null);if(!pitches.length)continue;
      const pitch=sounding(pitches.reduce((a,b)=>b.pitch>a.pitch?b:a).pitch,element.start);
      if(tied&&element.tieStop&&tied.pitch===pitch){tied=element.tieStart?tied:null;continue}
      const note={start:element.start,pitch};notes.push(note);tied=element.tieStart?note:null;
    }
  }
  // (One line: in the order they begin, the top one where two begin together.)
  notes.sort((a,b)=>a.start.cmp(b.start)||b.pitch-a.pitch);
  const line=notes.filter((note,k)=>!k||!note.start.eq(notes[k-1].start));
  if(!line.length)return {part:chosen.id,name:chosen.name??null,notes:[]};
  const first=line[0].start;
  return {part:chosen.id,name:chosen.name??null,notes:line.map(note=>{const quarters=note.start.sub(first).mul(QUARTERS);return {at:quarters.toNumber(),pitch:note.pitch,written:quarters.toString()}})};
}
