// The contrabass the bowed-string engine plays (native/strings-model/engine.mjs bakes it into the render driver and the
// live host alike; physical-strings.js bows it): Artifastring's solver -- the cello's, its rates -- with four strings of
// its own, at its own pitch and never slowed (the owner, 15 October 2026, after the contrabass had been a cello played an
// octave up and slowed; research/STRINGS_FITTED_BOWING.md, "A double bass of its own"; 17 October: "make sure we
// actually have a bass"). Its strings are the registry's (registry/objects/bowed.json `contrabass`, each value with its
// source): their pitches, tensions and length from D'Addario's chart, their stiffness and losses fitted to another bass's
// recorded pizzicati, and the rest -- density, inharmonicity at the open string, stiffness, the steel cylinder of its
// density and the modulus that gives that stiffness, the losses' law r0 + r2 f^2 -- derived by the registry's equations.
// Its body: no measured bass body is in Artifastring. Until one is fitted to TU Berlin's recorded contrabass (Weinzierl
// et al. 2017, doi:10.14279/depositonce-5861.2; research/STRINGS_FITTED_BOWING.md), the cello's measured bodies scaled to
// its size: their impulse responses stretched in time, and the cello's correction and radiation's corner with them, by
// the ratio of the two instruments' lowest air modes as string-bodies.js calculates them from A. Goldblatt's measurements
// of both (cello 102.1 Hz, contrabass 71.9: 1.42) -- interim, said wherever it is heard.
import {keysOf,value} from '../../../registry/registry.js';

export const CONTRABASS=Object.freeze({
  strings:Object.freeze(keysOf('contrabass','strings').map(name=>{
    const of=key=>value('contrabass',`strings.${name}.${key}`);
    return Object.freeze({name,pitch:of('pitch'),f0:of('f0'),T:of('tension'),L:of('length'),pl:of('density'),d:of('diameter'),E:of('young'),B:of('inharmonicity'),
      r0:of('lossR0'),r2:of('lossR2')});
  })),
  // (The nearest measured body in its air mode, the cello's, stretched in time by this, its correction and corner with
  // it: interim -- the registry's engine choice, objects/bowed.json `engine`.)
  bodyScale:Object.freeze({from:value('contrabass','engine.bodyFrom'),ratio:value('contrabass','engine.bodyRatio'),interim:true}),
});
