// A bowed note's articulation -- how its bow takes the string -- as a point in one continuous space that every bowed
// player speaks and every strings synth reads (the owner, 19 October 2026: "establish a way for the bots to communicate
// a full range of attacks to the strings using a parameter space"). A player chooses a point (directly, or between the
// named ones); its note carries it as MIDI 2.0 (bowed-midi2.js); the strings' model plays it with its onset's pressure
// curve (physical-strings.js onsetOf), whose shape a fit makes true of the sound (research/
// STRINGS_ARTICULATION_FIT_PLAN.md). Pure data and functions: the bots, the engines and the fit all import it.
//
// Its coordinates, each a quantity a measurement of the sound can check, so that a fit can make it so:
//   weight  the onset's accent: how far the level stands above the held tone's as the bow takes the string, a share of
//           ACCENT_DB (dB at 1); 0 none. Its bow faster and heavier together, the string kept in Helmholtz motion.
//   noise   how rough its start: the length of its pre-Helmholtz transient of prolonged periods -- the creak of a bow
//           pressed harder than its speed takes cleanly -- a share of the longest listeners accept as played,
//           NOISE_PERIODS nominal periods (K. Guettler and A. Askenfelt 1997, "Acceptance limits for the duration of
//           pre-Helmholtz transients in bowed string attacks", JASA 101(5), 2903-2913, doi:10.1121/1.418520: 50 ms,
//           ten periods, of a violin's open G); 0 a clean start, Helmholtz motion at once.
//   bite    the bow's grip before it moves (s): set on the string and pressed still so long before it is drawn -- a
//           martelé's pinch, a re-attack's stop -- beyond what its player's own change of bow takes at its dynamic
//           (section-seat.js STROKE.bite); 0 none.
//   decay   how long its accent lasts (s): its weight and its noise eased back to the held tone over it once the bow is
//           drawn at its speed -- a sforzando's long, a martelé's short.
// And two each stroke already says: its attack (s to its held tone: RPNC #73) and its join (begun from silence, slurred,
// a change of bow at a new note, one inside a held note: Assignable #17). Every state between two points is a point:
// articulationBetween.
import {LINE} from './line.js';

export const ARTICULATION_AXES=Object.freeze(['weight','noise','bite','decay']);
// Each coordinate's range: the unit ones' as defined; a decay to the longest an accent is meant to take (s, ours), past
// which a note is two gestures, not one attack; a bite within the quarter second a band sends its notes ahead of their
// time (public/timing.js), so that a live strings synth sets its bow before the note's time as a render's does.
export const ARTICULATION_RANGE=Object.freeze({weight:Object.freeze([0,1]),noise:Object.freeze([0,1]),bite:Object.freeze([0,.15]),decay:Object.freeze([0,1])});
// A weight of 1's accent (dB above the held tone) and a noise of 1's transient (nominal periods): the first ours, the
// second Guettler and Askenfelt's limit for prolonged periods (above).
export const ACCENT_DB=9,NOISE_PERIODS=10;
// The named attacks, as string players name them, each a point (ours, as their words describe them, to be replaced by
// measured players' strokes where found: E. Schoonderwaldt 2009, "Mechanics and acoustics of violin bowing", PhD thesis,
// KTH, measured détaché and martelé):
//   legato     no attack of its own: a slur's, or a change of bow hidden inside a held note;
//   loure      a slurred pulse: a little weight, no noise, eased slowly;
//   detache    a plain change of bow onto a new note: a little weight and a little noise, quickly gone;
//   accent     weight and some noise;
//   marcato    heavy, rough, a little grip;
//   martele    a hammered, pinched start: grip, more weight and noise, its accent quickly gone (its bow then stopped:
//              its stroke's rest);
//   sforzando  the heaviest by its weight, its accent lasting -- though where an instrument's fitted onsets land it
//              lighter than a martelé, its speed rising to it instead, it plays so (the owner decided on 23 October
//              2026 that it may).
export const ARTICULATIONS=Object.freeze({
  legato:Object.freeze({weight:0,noise:0,bite:0,decay:0}),
  loure:Object.freeze({weight:.1,noise:0,bite:0,decay:.12}),
  detache:Object.freeze({weight:.15,noise:.2,bite:0,decay:.06}),
  accent:Object.freeze({weight:.5,noise:.3,bite:0,decay:.1}),
  marcato:Object.freeze({weight:.7,noise:.5,bite:.02,decay:.08}),
  martele:Object.freeze({weight:.8,noise:.6,bite:.06,decay:.05}),
  sforzando:Object.freeze({weight:1,noise:.5,bite:.02,decay:.3}),
});
// The named attacks from the least marked to the most, the path a conductor's one draw of markedness moves along
// (articulationAlong).
export const MARKEDNESS=Object.freeze(['legato','loure','detache','accent','marcato','martele','sforzando']);

const clamp=(value,[low,high])=>Math.min(high,Math.max(low,value));
// A point: a name, or coordinates (one left out is 0), each held within its range. -> a frozen point, or null where it
// names none.
export function articulationOf(value){
  if(value==null)return null;
  if(typeof value==='string')return ARTICULATIONS[value]??null;
  if(typeof value!=='object')return null;
  return Object.freeze(Object.fromEntries(ARTICULATION_AXES.map(axis=>[axis,+clamp(Number(value[axis])||0,ARTICULATION_RANGE[axis]).toFixed(4)])));
}
// The point `w` of the way from a to b (each a name or a point), every coordinate along a straight line.
export function articulationBetween(a,b,w){
  const from=articulationOf(a)??ARTICULATIONS.legato,to=articulationOf(b)??ARTICULATIONS.legato,t=Math.max(0,Math.min(1,Number(w)||0));
  return articulationOf(Object.fromEntries(ARTICULATION_AXES.map(axis=>[axis,from[axis]+(to[axis]-from[axis])*t])));
}
// The point `m` (0 to 1) of the way along MARKEDNESS, its named points evenly spaced on it.
export function articulationAlong(m){
  const at=Math.max(0,Math.min(1,Number(m)||0))*(MARKEDNESS.length-1),k=Math.min(MARKEDNESS.length-2,Math.floor(at));
  return articulationBetween(MARKEDNESS[k],MARKEDNESS[k+1],at-k);
}
// The named attack nearest a point (each coordinate a share of its range), for its words and its score's marks.
export function articulationNamed(value){
  const point=articulationOf(value);if(!point)return null;
  const distance=other=>Math.hypot(...ARTICULATION_AXES.map(axis=>(point[axis]-other[axis])/(ARTICULATION_RANGE[axis][1]-ARTICULATION_RANGE[axis][0])));
  return Object.entries(ARTICULATIONS).reduce((best,entry)=>distance(entry[1])<distance(best[1])?entry:best)[0];
}
// A player's own attack at a new note, where nothing asks for another (the player's: section-seat.js): legato at
// OWN_ATTACK.soft's dynamic and under, détaché from OWN_ATTACK.firm's, between in velocity (line.js LINE.velocity; ours:
// a soft note's bow placed and drawn, a firmer one's taken).
export const OWN_ATTACK=Object.freeze({soft:'p',firm:'mf'});
export function ownArticulation(velocity){
  const soft=LINE.velocity[OWN_ATTACK.soft],firm=LINE.velocity[OWN_ATTACK.firm];
  return articulationBetween('legato','detache',((Number(velocity)||0)-soft)/(firm-soft));
}
// A point as a stroke carries it (section-seat.js's strokes, audio.js physicalStroke's log): its weight, noise and decay,
// and its bite -- the whole grip, where its player has added its own change of bow's to the point's (`bite`, s), else
// the point's. -> stroke fields.
export function strokeArticulation(value,bite=null){
  const point=articulationOf(value);if(!point)return {};
  const gripped=+Math.max(0,bite==null?point.bite:Number(bite)||0).toFixed(4);
  return {weight:point.weight,noise:point.noise,decay:point.decay,...(gripped>0?{bite:gripped}:{})};
}
// A stroke's point, where it carries one (its weight, noise or decay said; its bite its own). -> a point, or null.
export function articulationOfStroke(stroke){
  if(!stroke||!['weight','noise','decay'].some(axis=>Number.isFinite(Number(stroke[axis]))&&stroke[axis]!=null))return null;
  return articulationOf(stroke);
}
