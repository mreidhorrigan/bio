// An instrument's idiom told its player as relations (the owner, 6 November 2026: "We ultimately might need a way for
// more information to go back from the instrument to the playing bot about the instrument's idiom and what it can and
// can't play (e.g., strings double stops; woodwind multiphonics as a blend of timbre and harmony)"; "Another example of a
// conveyable idiom would be a woodwind's greater ability to leap up large intervals than down them, especially where
// overblowing is involved"; "And a result would be the musebot avoiding some melodic intervals, at certain speeds, in
// favour of others"): each relation a region of its items' joint space, as a range is a box in one
// (research/IDIOM_AS_RELATIONS.md). Its facts are plain data, served beside its ranges (instrument-facts.js `idiom`, and
// its MCP server's resource and tools), and read back into what a player asks of them (idiomOf):
//   - a move (from, to, seconds): the time it needs on its instrument, and how much of the time it has that is. A wind's
//     is its leap's fingers and each register it crosses (wind-registers.json: a woodwind's resonance, a brass
//     instrument's partial), by the leap's size to an octave, a woodwind's slower downward than upward; a bowed
//     instrument's is its hand's shift where its position changes (registry: its players' frame, and violinists'
//     measured shift), its hand carried along a line (walk);
//   - notes together: a bowed instrument's on adjacent strings within its hand's frame (a double stop, a chord), a wind's a
//     multiphonic measured on it, a chord and a timbre at once;
//   - the hand's states: each string a pitch can be stopped on, and where, and a path through them (fingering);
//   - where each technique sounds on it, which its player's tone concept takes from (personality.js);
//   - what its idiom favours (its players' register, its open strings), which a player says to its band, and which the
//     piece's choices weigh with every other instrument's, a bounded share a round (negotiate): the way back through the
//     player toward the piece (the owner: "flowing backward through the musebot player, it should eventually be able to
//     cause changes over an entire piece, in negotiation with the idioms of other instruments").
// And the machine a path through such relations is drawn on (drawPath): a forward pass and a backward draw, every path
// within them drawn with its weight's share, none drawn and rejected.
import REGISTERS from './wind-registers.json' with {type:'json'};
import {player,setting} from '../../../registry/registry.js';
import {BOWED,bySize} from './bowed-instruments.js';

export const IDIOM_SCHEMA='musebots.idiom/1';
// The first finger's place in a bowed instrument's lowest position: a whole tone above its open string, as in its
// players' first position (ours). Its hand's frame is measured there.
const FIRST=2;
// (Within this of its open string's pitch, a note is that string open: 5 cents. A stopped note may lie anywhere above.)
const OPEN=.05;
// (A natural harmonic's or a multiphonic's pitch heard as within this of a pitch asked, semitones.)
const NEAR=.5;
const tryPlayer=(model,path)=>{try{return player(model,path)}catch{return null}};
// (A bowed instrument's hand's `name` (frame, extended): its players' where the registry has them, a given instrument's
// read between those by its size, as its bow is.)
const handOf=(id,name)=>{
  const own=tryPlayer(id,`hand.${name}`);if(Number.isFinite(own))return own;
  const table=Object.fromEntries(BOWED.filter(i=>!i.given).flatMap(i=>{const v=tryPlayer(i.name,`hand.${name}`);return Number.isFinite(v)?[[i.name,v]]:[]}));
  try{return Object.keys(table).length?bySize(table,id):null}catch{return null}
};

// Its idiom as plain data, from its facts (instrument-facts.js, as they are made): -> {schema, moves, together, hand,
// techniques, favours}, each null where its instrument has none known.
export function idiomFacts(facts){
  const register=[...facts.compass.register];
  if(facts.kind==='bow'){
    const {strings,reach}=facts.articulation,id=facts.instrument;
    const [frame,extended]=['frame','extended'].map(name=>handOf(id,name)),shift=tryPlayer(id,'hand.shift')??tryPlayer('violin-family','hand.shift');
    const hand=[frame,extended,shift].every(Number.isFinite)?{strings:[...strings],reach,first:FIRST,frame:+frame.toFixed(6),extended:+extended.toFixed(6),shift,unit:'semitones; s',
      source:'registry/players/bowed.json hand: its frame, first finger to fourth in its lowest position, its players\' (vernacular; a given instrument\'s read between them by its size, bowed-instruments.js bySize); a shift\'s time violinists\' measured (Visentin et al. 2015)'}:null;
    // (Its natural harmonics, each string's partials to its ceiling.)
    const ceiling=facts.compass.harmonicCeiling??null,harmonics=ceiling==null?[]:strings.flatMap(open=>{
      const out=[];for(let n=2;open+12*Math.log2(n)<=ceiling;n++)out.push(+(open+12*Math.log2(n)).toFixed(3));return out});
    return {schema:IDIOM_SCHEMA,moves:hand?{by:'hand'}:null,together:hand?{by:'strings',adjacent:true}:null,hand,
      techniques:harmonics.length?{harmonic:harmonics.map(p=>[+(p-NEAR).toFixed(3),+(p+NEAR).toFixed(3)])}:{},
      favours:{register,pitches:strings.map(p=>[p,1]),source:'its players\' register (instrument-ranges.js); its open strings, which ring'}};
  }
  const runs=REGISTERS.instruments[facts.model]?.runs??REGISTERS.instruments[facts.instrument]?.runs??null;
  const law=Object.fromEntries(['leap','up','down'].map(name=>[name,tryPlayer(facts.model,`idiom.${name}`)]));
  const multiphonics=(facts.techniques?.multiphonics??[]).map(m=>({id:m.id,pitches:[...m.pitches]}));
  return {schema:IDIOM_SCHEMA,
    moves:runs&&Object.values(law).every(Number.isFinite)?{by:'registers',registers:runs.map(run=>[...run]),law,unit:'s',
      source:`wind-registers.json (${REGISTERS.instruments[facts.model]?.source??REGISTERS.instruments[facts.instrument]?.source}); registry/players/winds.json idiom (ours, unmeasured)`}:null,
    together:multiphonics.length?{by:'multiphonics',multiphonics}:null,hand:null,
    techniques:multiphonics.length?{multiphonic:multiphonics.map(m=>[Math.min(...m.pitches),Math.max(...m.pitches)])}:{},
    favours:{register,pitches:[],source:'its players\' register (instrument-ranges.js)'}};
}

// What a player asks of its idiom (`idiom`: idiomFacts's data, as its MCP server serves it) -> {registerAt, move, walk,
// together, handStates, fingering, techniquesIn, favours}, or null where it has none.
export function idiomOf(idiom){
  if(!idiom)return null;
  const hand=idiom.hand,runs=idiom.moves?.registers??null,law=idiom.moves?.law??null;
  // A wind's register at `pitch`: its nearest charted note's.
  const registerAt=pitch=>{
    if(!runs)return null;let best=null,far=Infinity;
    for(const [low,high,register] of runs){const off=pitch<low?low-pitch:pitch>high?pitch-high:0;if(off<far){far=off;best=register}}
    return best;
  };
  // (The highest place its hand reaches with its first finger at `place`, semitones above its open string: its frame's
  // length on the string as in its lowest position, held as it climbs -- more semitones higher up, where they are
  // shorter.)
  const top=(place,frame)=>{const length=2**(-FIRST/12)-2**(-(FIRST+frame)/12),left=2**(-Math.max(place,0)/12)-length;return left>0?-12*Math.log2(left):Infinity};
  // (Its stopped places held by one position of its hand, its frame `frame`.)
  const held=(places,frame)=>{const stopped=places.filter(p=>p>0);return stopped.length<2||Math.max(...stopped)<=top(Math.min(...stopped),frame)+1e-9};
  // Each string `pitch` can be played on, and where: {string (its index, lowest 0), place (semitones above it, 0 open)}.
  const handStates=pitch=>hand?hand.strings.flatMap((open,string)=>{const place=pitch-open;
    return place>=-OPEN&&place<=hand.reach+OPEN?[{string,place:Math.abs(place)<OPEN?0:+place.toFixed(6)}]:[]}):[];
  // (Its hand's positions, its first finger's place in semitones above its open string, as low as it goes to its reach;
  // and those that hold a note at `place` on a string, its extended frame reaching it -- every one, where the string is
  // open and leaves its hand free.)
  const POSITIONS=hand?[...Array(Math.floor(hand.reach)+1).keys()]:[];
  const holding=place=>place===0?POSITIONS:POSITIONS.filter(q=>q<=place+1e-9&&place<=top(q,hand.extended)+1e-9);
  const statesOf=new Map;
  // The states a line's note can be played in: a bowed instrument's hand's positions, on each string the note lies on
  // ({string, place, position}); a wind's, its one register ({register}).
  const statesAt=pitch=>{
    if(!statesOf.has(pitch))statesOf.set(pitch,hand?handStates(pitch).flatMap(({string,place})=>holding(place).map(position=>({string,place,position}))):[{register:registerAt(pitch)}]);
    return statesOf.get(pitch);
  };
  // (The time a move between two of its hand's states needs: a shift where its hand's position changes.)
  const shiftOf=(a,b)=>a.position===b.position?0:hand.shift;
  const needs=new Map;
  // The time a move from `from` to `to` (pitches) needs on it, s: Infinity where it has no way to play one of them. A
  // bowed instrument's taken alone: none where one position of its hand holds both, else a shift.
  const neededFor=(from,to)=>{
    const key=`${from}|${to}`;if(needs.has(key))return needs.get(key);
    let needed=Infinity;
    // (A wind's: its leap's fingers, and each register it crosses, upward or downward, by the leap's size to an octave --
    // a step across its break barely moves its lips, a twelfth down sets up its lower regime anew.)
    if(law){const crossed=registerAt(to)-registerAt(from),octaves=Math.abs(to-from)/12;needed=law.leap*octaves+Math.min(1,octaves)*(crossed>0?law.up*crossed:-law.down*crossed)}
    else if(hand){const a=new Set(statesAt(from).map(state=>state.position)),b=statesAt(to);needed=!a.size||!b.length?Infinity:b.some(state=>a.has(state.position))?0:hand.shift}
    else needed=0;
    needs.set(key,needed);return needed;
  };
  // A move from `from` to `to` over `seconds` (the first's, as it is played): {needed (s), share (of its seconds), beyond
  // (it needs more than it has)}. A bowed instrument's taken alone, its hand where it suits both notes best: along a
  // line, where the hand is depends on the notes before (walk).
  const move=(from,to,seconds)=>{const needed=neededFor(from,to);return {needed,share:seconds>0?needed/seconds:needed>0?Infinity:0,beyond:needed>seconds}};
  // A line's moves charged along it, where its hand is carried from note to note (a Viterbi frontier: each state its
  // last note can be played in, and the least its moves have cost reaching it): `price(needed, seconds)` a move's cost.
  // A bowed instrument's states its hand's positions, whichever string (a move's time is its shift's alone), so that a
  // line climbing by steps shifts as its hand must, an open string's note leaving its hand where it was. start(pitch) ->
  // its first note's frontier; next(frontier, from, to, seconds) -> the next note's, none where no state of it can be
  // reached; least(frontier) -> what the line's moves have cost at the least.
  const least=frontier=>frontier.reduce((most,f)=>Math.min(most,f.cost),Infinity);
  const walk=price=>({
    start:pitch=>hand?byPosition(statesAt(pitch).map(state=>({state,cost:0}))):statesAt(pitch).map(state=>({state,cost:0})),
    next:(frontier,from,to,seconds)=>{
      if(!hand)return statesAt(to).flatMap(state=>{const cost=least(frontier)+price(neededFor(from,to),seconds);return cost<Infinity?[{state,cost}]:[]});
      const here=new Map(frontier.map(f=>[f.state.position,f.cost])),shifted=least(frontier)+price(hand.shift,seconds);
      return byPosition(statesAt(to).map(state=>({state,cost:Math.min(here.get(state.position)??Infinity,shifted)})).filter(f=>f.cost<Infinity));
    },
    least});
  // Notes played together: a bowed instrument's on as many adjacent strings, its stopped places within one position of
  // its hand (its frame, cost 0; extended, 1/2); a wind's a multiphonic measured on it whose pitches hold every one
  // asked. -> {playable, cost?, strings?, places?, multiphonic?}.
  const together=pitches=>{
    if(pitches.length<2)return {playable:true,cost:0};
    if(hand){
      let best=null;
      for(const order of permutations(pitches))for(let low=0;low+order.length<=hand.strings.length;low++){
        const places=order.map((pitch,k)=>pitch-hand.strings[low+k]);
        if(places.some(p=>p<-OPEN||p>hand.reach+OPEN))continue;
        const cost=held(places,hand.frame)?0:held(places,hand.extended)?1/2:null;
        if(cost!=null&&(!best||cost<best.cost))best={playable:true,cost,strings:order.map((_,k)=>low+k),places:places.map(p=>Math.abs(p)<OPEN?0:+p.toFixed(6)),pitches:[...order]};
      }
      return best??{playable:false};
    }
    for(const m of idiom.together?.multiphonics??[])if(pitches.every(p=>m.pitches.some(q=>Math.abs(p-q)<=NEAR)))return {playable:true,cost:0,multiphonic:m.id,pitches:[...m.pitches]};
    return {playable:false};
  };
  // A bowed line's path through its hand's states (`pitches`, each its `seconds`), drawn whole (drawPath): each state's
  // cost its place, higher dearer (a twelfth an octave: ours), each move's its shift's time over the time it has --
  // never one it cannot play. -> [{string, place, position}] or null.
  const fingering=(pitches,seconds,{random,temperature=1/4})=>{
    if(!hand)return null;
    const states=pitches.map(statesAt);
    const path=drawPath({counts:states.map(list=>list.length),cost:(k,s)=>states[k][s].place/12,
      move:(k,a,b)=>{const need=shiftOf(states[k][a],states[k+1][b]);return need?need/Math.max(seconds[k],1e-6):0},temperature,random});
    return path&&path.map((s,k)=>states[k][s]);
  };
  // How much of the span [low, high] each technique its idiom places sounds in: {kind: share}. A kind it places nowhere
  // is not in it.
  const techniquesIn=([low,high])=>Object.fromEntries(Object.entries(idiom.techniques??{}).map(([kind,ranges])=>[kind,covered(ranges,low,high)]));
  return Object.freeze({registerAt,move,walk,together,handStates,fingering,techniquesIn,favours:idiom.favours??null,hand,law});
}
// (A frontier's states one to a position, the least of each.)
function byPosition(frontier){
  const best=new Map;for(const f of frontier){const known=best.get(f.state.position);if(!known||f.cost<known.cost)best.set(f.state.position,f)}
  return [...best.values()];
}
function* permutations(list){
  if(list.length<2){yield [...list];return}
  for(let k=0;k<list.length;k++)for(const rest of permutations([...list.slice(0,k),...list.slice(k+1)]))yield [list[k],...rest];
}
// (The share of [low, high] its ranges cover.)
function covered(ranges,low,high){
  if(!(high>low))return 0;
  const parts=ranges.map(([a,b])=>[Math.max(a,low),Math.min(b,high)]).filter(([a,b])=>b>a).sort((x,y)=>x[0]-y[0]);
  let sum=0,end=low;for(const [a,b] of parts){if(b>end){sum+=b-Math.max(a,end);end=b}}
  return +(sum/(high-low)).toFixed(6);
}

// A move's price to a player heeding its idiom by `weight` (personality.js: registry/method/melody.json idiom): its time
// on the instrument as a share of the time the note before it has, rising without bound as that nears all of it (-log
// of the share left: a barrier at the idiom's edge, so a cautious player keeps well inside it and a daring one goes near,
// none past), and `beyond` (a rule broken, as the line's) where it needs more than it has. -> price(needed, seconds).
export const heedPrice=(weight,beyond)=>(needed,seconds)=>{const share=seconds>0?needed/seconds:needed>0?Infinity:0;return share>=1?beyond:-weight*Math.log1p(-share)};

// A path drawn whole through a chain of choices: at its step k, one of `counts[k]` states, each with a cost of its own
// (cost(k, s)), and each move from step k's state a to step k+1's state b a cost (move(k, a, b); Infinity where it cannot
// be made). Every path weighs exp(-(its costs)/temperature): a forward pass sums the weights of every path reaching each
// state (in logs), and a backward draw takes the last state by its sum and each before it by its sum times its move to
// the one drawn after it -- every path within the relations drawn with its weight's share of all, none drawn and
// rejected (A. Papadopoulos, F. Pachet, P. Roy & J. Sakellariou 2015, "Exact Sampling for Regular and Markov
// Constraints with Belief Propagation", doi:10.1007/978-3-319-23219-5_24). -> the states' indices, or null where no
// path keeps the relations.
export function drawPath({counts,cost=()=>0,move=()=>0,temperature=1,random}){
  const n=counts.length;if(!n)return [];
  const sum=logs=>{const most=Math.max(...logs);return most===-Infinity?-Infinity:most+Math.log(logs.reduce((s,x)=>s+Math.exp(x-most),0))};
  const forward=[Array.from({length:counts[0]},(_,s)=>-cost(0,s)/temperature)];
  for(let k=1;k<n;k++)forward.push(Array.from({length:counts[k]},(_,b)=>-cost(k,b)/temperature+sum(forward[k-1].map((f,a)=>f-move(k-1,a,b)/temperature))));
  const pick=logs=>{
    const most=Math.max(...logs);if(most===-Infinity)return -1;
    const weights=logs.map(x=>Math.exp(x-most)),total=weights.reduce((s,x)=>s+x,0);
    let left=random()*total;for(let s=0;s<weights.length;s++){if(!weights[s])continue;left-=weights[s];if(left<0)return s}
    return weights.findLastIndex(x=>x>0);
  };
  const path=new Array(n);path[n-1]=pick(forward[n-1]);if(path[n-1]<0)return null;
  for(let k=n-2;k>=0;k--)path[k]=pick(forward[k].map((f,a)=>f-move(k,a,path[k+1])/temperature));
  return path;
}

// What an idiom favours, as a weight on each of a piece's options (`options`: {option: its pitch}, a key's tonic, say):
// one, and one more for each favoured pitch whose class it shares, within a quarter tone, by that pitch's weight. ->
// {option: weight}.
export function favouredOver(favours,options){
  const near=(p,q)=>{const d=((p-q)%12+12)%12;return Math.min(d,12-d)<=.25};
  return Object.fromEntries(Object.entries(options).map(([option,pitch])=>[option,1+(favours?.pitches??[]).reduce((s,[q,w])=>s+(near(pitch,q)?w:0),0)]));
}
// One round of a piece's choice weighed with its band's idioms (the owner, 6 November 2026: "The composition of
// large-scale musical pieces is not only mediated through the idioms of the instruments, but also influenced by those
// idioms in a basic way, resulting, possibly, in a sort of logic loop, although we should be careful with such"): each
// option's weight `share` of the way from the piece's own (its seed's draw, `prior`) toward the last round's as its
// instruments' idioms favour it together (their preferences' mean), the prior always holding the rest -- so its rounds
// settle, and no option the piece holds falls to nothing: an idiom a weight on the piece's draw, never the draw. prior,
// each preference: {option: weight >= 0}; current: the last round's (the prior at the first). -> {option: weight},
// summing as the prior does.
export function negotiate(prior,preferences,{current=prior,share=setting('idiom','share')}={}){
  const options=Object.keys(prior),total=options.reduce((s,o)=>s+prior[o],0);
  const norm=w=>{const t=options.reduce((s,o)=>s+(w[o]??0),0);return Object.fromEntries(options.map(o=>[o,t>0?(w[o]??0)/t:1/options.length]))};
  const own=norm(prior),last=norm(current),liked=preferences.map(norm);
  const pulled=norm(Object.fromEntries(options.map(o=>[o,last[o]*(liked.length?liked.reduce((s,p)=>s+p[o],0)/liked.length:1/options.length)])));
  return Object.fromEntries(options.map(o=>[o,total*((1-share)*own[o]+share*pulled[o])]));
}
