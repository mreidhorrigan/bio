// A slide's positions as its player knows them, and whether a slur moves it -- what a trombonist may legato-tongue across
// (wind-seat.js), a slur within one position its lips' alone. Whether it is tongued is its player's choice (the owner, 25
// October 2026: a slur need not dip at all), never its renderer's rule.
//
// Its positions are its players' chart's (brass-standard-fingerings.json: each chromatic note's standard positions, first
// to seventh, its alternates). A pitch between them lies where its nearest note's position is, less the semitones it lies
// above that note: the slide is continuous (microtones first-class), each position a semitone further out than the last.
import CHARTS from './brass-standard-fingerings.json' with {type:'json'};

const NAMES=['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'];
// (A note's name in its chart's spelling, sharps and the octave: 60 'C4'.)
const nameOf=midi=>`${NAMES[((midi%12)+12)%12]}${Math.floor(midi/12)-1}`;

// The instruments whose charts give slide positions.
export const SLIDES=Object.freeze(Object.keys(CHARTS).filter(key=>CHARTS[key]?.positions));

// The positions `pitch` (sounding, fractional MIDI) is played at on `instrument`'s slide, continuous: [] where its chart
// holds no note near it, null where `instrument` has no slide.
export function positionsOf(instrument,pitch){
  const chart=CHARTS[instrument];
  if(!chart?.positions)return null;
  // (Its chart's notes as written: a transposing instrument's sound its `sounds` semitones from them.)
  const written=pitch-(chart.sounds??0),near=Math.round(written);
  return (chart.positions[nameOf(near)]??[]).map(position=>position+(near-written));
}

// Whether a slur from `from` to `to` moves `instrument`'s slide: no position of one within `within` semitones of one of
// the other's. null where it has no slide, or either pitch lies outside its chart.
export function slideMoves(instrument,from,to,{within}){
  const a=positionsOf(instrument,from),b=positionsOf(instrument,to);
  if(!a?.length||!b?.length)return null;
  return !a.some(x=>b.some(y=>Math.abs(x-y)<within));
}
