// An orchestra's percussion and harp as a section (the owner, 2 October 2026: "include the rest of the orchestra to the
// extent possible"): the timpanist, the percussionists on the battery, a mallet player and the harpist, each a player who
// plays its own part (timpani_clodbot, battery_clodbot, mallets_clodbot, harp_clodbot), conducted as the other sections
// are (section-kinds.js). What the section's conductor decides for them a phrase at a time is who plays, and on what the
// battery's players play: an orchestra's percussion is coloured in and out, never all of it all the time. Each section
// plays a phrase with its own chance (PERCUSSION.plays, authored), at least one of them always, all of them in the piece's
// last phrase; the battery's players are cast on instruments by the phrase's level (battery.js castBattery), no two on
// one; and the section asks the orchestra's conductor to rest whole phrases as any section does (requests.js).
import {castBattery} from './battery.js';
import {playersOf,seededSource} from './string-section.js';
import {sectionAesthetic} from '../aesthetic.js';
export const PERCUSSION=Object.freeze({
  sections:Object.freeze({
    timp:Object.freeze({name:'Timpani',abbreviation:'Timp.',instrument:'timpani',player:'timpani_clodbot'}),
    bat:Object.freeze({name:'Percussion',abbreviation:'Perc.',instrument:'percussion',player:'battery_clodbot'}),
    perc:Object.freeze({name:'Mallets',abbreviation:'Mall.',instrument:'mallets',player:'mallets_clodbot'}),
    harp:Object.freeze({name:'Harp',abbreviation:'Hp.',instrument:'harp',player:'harp_clodbot'}),
  }),
  // (In score order: the timpani, the percussion, the harp.)
  order:Object.freeze(['timp','bat','perc','harp']),
  // A section's players in that order: no battery (as before it had one), two on it and three.
  sizes:Object.freeze({standard:Object.freeze([1,0,1,1]),percussion:Object.freeze([1,0,1,0]),full:Object.freeze([1,2,1,1]),large:Object.freeze([1,3,1,1])}),
  // Each section's chance of playing a phrase (ours: the timpani, the battery and the harp more than the mallets), and
  // in a phrase where the form arrives or is announced (ours: the timpani and the battery mark the joins).
  plays:Object.freeze({timp:.6,bat:.65,perc:.45,harp:.6}),joins:Object.freeze({timp:.9,bat:.95,perc:.5,harp:.6}),
  // The battery's pulse a phrase (battery.js BATTERY.groove: 0 colouring the form, 1 a groove on every subdivision),
  // drawn toward its low end (an orchestra's percussion colours more often than it grooves); within the character's
  // pulse where one is said (aesthetic.js sectionAesthetic, as the strings' chords take theirs), that many times lower
  // where the piece is elongated.
  pulse:Object.freeze([0,1]),
  // And how often its players, where two or more groove together, play their groove as a rhythmic canon -- a hocket,
  // every tick of the bar struck by one of them (battery.js batteryHocket; Astra's CF27): a pool's own share, drawn from
  // its seed over the whole range.
  hocket:Object.freeze([0,1]),
});
export function percussionSizeOf(size='standard'){
  const counts=Array.isArray(size)?size:PERCUSSION.sizes[size]??String(size).split('/').map(Number);
  if(counts.length!==PERCUSSION.order.length||!counts.every(n=>Number.isSafeInteger(n)&&n>=0&&n<=4))throw new RangeError(`A percussion section's size is ${Object.keys(PERCUSSION.sizes).join(', ')}, or ${PERCUSSION.order.length} counts as ${PERCUSSION.sizes.full.join('/')}`);
  return Object.freeze([...counts]);
}
// Every seat: {id ('timp.1'), section, chair, instrument, player}.
export function percussionSeats(size='standard'){
  const counts=percussionSizeOf(size),out=[];
  PERCUSSION.order.forEach((section,index)=>{const {instrument,player}=PERCUSSION.sections[section];
    for(let chair=1;chair<=counts[index];chair++)out.push(Object.freeze({id:`${section}.${chair}`,section,chair,desk:chair,instrument,player}))});
  return Object.freeze(out);
}
// A phrase's formation: a pool an instrument, its texture its own part ('own') or a rest ('tacet'), its level within the
// constraints' level (their middle, else a mezzo); the battery's pool its players' instruments, by seat. At least one
// plays (where the draw would rest them all, the one whose chance is largest, ties in score order); all of them in the
// last phrase; each by its chance at a join (`join`: the phrase opens a section of the form or leads into the next) where
// it is one; the battery's pool its pulse (PERCUSSION.pulse), drawn from its own seed. random: [0, 1).
export function percussionFormation(seats,{random,constraints={},join=false,plays=join?PERCUSSION.joins:PERCUSSION.plays,character=null,elongation=1}={}){
  const sections=PERCUSSION.order.filter(section=>seats.some(seat=>seat.section===section));
  const level=constraints.level?+((constraints.level[0]+constraints.level[1])/2).toFixed(3):.5;
  const draws=sections.map(()=>random());let playing=sections.map((section,k)=>draws[k]<(plays[section]??.5));
  if(!playing.some(Boolean)){const most=sections.reduce((best,section,k)=>(plays[section]??0)>(plays[sections[best]]??0)?k:best,0);playing=playing.map((_,k)=>k===most)}
  // (No more of them than the orchestra's breadth seats -- of n, n to its players' share (string-section.js playersOf) --
  // those kept whose draws fell furthest under their chances.)
  const most=!constraints.players?sections.length:playersOf((constraints.players[0]+constraints.players[1])/2,sections.length);
  if(playing.filter(Boolean).length>most){const kept=new Set(sections.map((section,k)=>k).filter(k=>playing[k]).sort((a,b)=>(draws[a]-(plays[sections[a]]??.5))-(draws[b]-(plays[sections[b]]??.5))).slice(0,most));playing=playing.map((_,k)=>kept.has(k))}
  return Object.freeze({grouping:'sections',split:0,pools:Object.freeze(sections.map((section,k)=>{
    const ids=seats.filter(seat=>seat.section===section).map(seat=>seat.id);
    const cast=section==='bat'?castBattery(ids.length,{level,random}):null,seed=Math.floor(random()*2**31);
    return Object.freeze({id:section,seats:Object.freeze(ids),parts:Object.freeze(ids.map(()=>0)),texture:playing[k]?'own':'tacet',level,seed,
      ...(cast?{instruments:Object.freeze(Object.fromEntries(ids.map((id,i)=>[id,cast[i]]))),pulse:batteryPulse(seed,{character,elongation}),
        ...(ids.length>=2?{hocket:+(PERCUSSION.hocket[0]+(PERCUSSION.hocket[1]-PERCUSSION.hocket[0])*seededSource(seed,'hocket')()).toFixed(3)}:{})}:{})});
  }))});
}
function batteryPulse(seed,{character,elongation}){
  const own=PERCUSSION.pulse,wanted=character?sectionAesthetic(character).pulse:own;
  const low=Math.max(own[0],wanted[0]),high=Math.min(own[1],wanted[1]),range=low<=high?[low,high]:wanted[1]<own[0]?[own[0],own[0]]:[own[1],own[1]];
  return +((range[0]+(range[1]-range[0])*seededSource(seed,'pulse')()**2)/Math.max(1,Number(elongation)||1)).toFixed(3);
}
export const percussionSummary=formation=>formation.pools.map(pool=>`${PERCUSSION.sections[pool.id]?.abbreviation??pool.id}: ${pool.texture==='tacet'?'tacet':pool.instruments?Object.values(pool.instruments).join(', '):'plays'}`).join('; ');
