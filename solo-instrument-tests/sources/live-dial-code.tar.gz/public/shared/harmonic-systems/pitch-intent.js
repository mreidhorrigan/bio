// Pitch intent: what a note is meant to be, kept apart from what it finally sounds. The harmonic-systems report
// (research/MUSEBOTS_HARMONIC_SYSTEMS_AND_MICROTUNING_IMPLEMENTATION_REPORT.md, §3.1-3.2 and §8.1) separates five
// levels a single MIDI number cannot hold: context, semantic identity, tuning intent, acoustic realization and
// execution. This module holds the tuning intent and its semantic companions, as validated, frozen JSON:
//
// - An interval as it was declared: an exact ratio (integers kept as decimal strings, reduced, never divided into a
//   float), a prime-exponent vector on an explicitly ordered basis, coordinates in a versioned temperament mapping, or
//   plain cents. Each has its cents, but an exact ratio is not interchangeable with its decimal image, and equal
//   vectors on different bases are not the same interval (§3.2): `sameInterval` compares what was declared, and
//   `intervalCents` evaluates it.
// - A pitch as cents above a declared reference (`pitchReference`: an id and a positive frequency). No octave is
//   assumed anywhere here: a period belongs to a rule package, which may declare 2:1, another ratio, or none.
// - A pitch region (an admissible connected range, in cents above a reference), a tuning alternative (one region and
//   the intervals it prefers against other events), and a protected curve (a pitch trajectory, piecewise linear, whose
//   check between points is exact because linear constraints hold segmentwise, §6.3).
// - A harmonic event's intent: its voice, owner, roles (simultaneous compatible descriptions), alternatives, retuning
//   policy for a sustained note (§6.6) and provenance.
//
// A round trip through `serializeIntent`/`parseIntent` keeps all of it; `projectToMidi` is the one lossy view, and it
// says what it drops.
import {frozenJson,identifier,knownFields} from '../planning-data.js';

// ---- Limits ------------------------------------------------------------------------------------------------------
export const INTENT_LIMITS=Object.freeze({
  integerDigits:64,         // an exact ratio's numerator or denominator
  basisLength:24,           // a prime-exponent vector's basis
  exponent:1024,            // its largest exponent, either way
  coordinates:16,           // a temperament's generators
  centsMagnitude:1e6,       // a cents value's largest size either way
  curvePoints:256,
  alternatives:16,
  roles:8,
  preferredIntervals:32,
  obligations:16,
  bytes:1<<18,              // a serialized intent
});
// Retuning contracts for a sustained note (§6.6): frozen until release; retuned only when struck again; moved
// continuously within bounds; moved along an authored morph; or an external source's pitch, evidence the generator
// cannot retune.
export const RETUNE_POLICIES=Object.freeze(['frozen','rearticulate','bounded','authored-morph','external']);
export const INTERVAL_KINDS=Object.freeze(['ratio','monzo','temperament','cents']);

const fail=message=>{throw new TypeError(message)};
const finite=(value,label,{magnitude=INTENT_LIMITS.centsMagnitude}={})=>{
  if(typeof value!=='number'||!Number.isFinite(value)||Math.abs(value)>magnitude)fail(`${label} must be a finite number`);
  return value;
};
const plain=(value,label)=>{if(!value||typeof value!=='object'||Array.isArray(value))fail(`${label} must be an object`);return value};
const list=(value,label,{max,min=0})=>{
  if(!Array.isArray(value)||value.length<min||value.length>max)fail(`${label} must be a list of ${min} to ${max}`);
  return value;
};

// ---- Exact integers and ratios ---------------------------------------------------------------------------------
const DIGITS=/^[1-9][0-9]*$/;
function positiveInteger(value,label){
  const text=typeof value==='number'&&Number.isSafeInteger(value)&&value>0?String(value):value;
  if(typeof text!=='string'||text.length>INTENT_LIMITS.integerDigits||!DIGITS.test(text))
    fail(`${label} must be a positive integer, as a decimal string where it is large`);
  return BigInt(text);
}
const gcd=(a,b)=>{while(b){[a,b]=[b,a%b]}return a};
// log2 of a positive integer of any size: its top 53 bits exactly, and the rest as a shift.
function log2Big(value){
  const bits=value.toString(2).length;
  if(bits<=53)return Math.log2(Number(value));
  const shift=BigInt(bits-53);
  return Math.log2(Number(value>>shift))+Number(shift);
}
// An exact ratio, reduced: {kind:'ratio', numerator, denominator} with both as decimal strings.
export function ratio(numerator,denominator=1){
  const n=positiveInteger(numerator,'A ratio\'s numerator'),d=positiveInteger(denominator,'A ratio\'s denominator'),g=gcd(n,d);
  return Object.freeze({kind:'ratio',numerator:String(n/g),denominator:String(d/g)});
}
// A ratio's size in cents. Where the two are close (their difference under a 64th of the denominator), from
// log1p((n - d)/d): subtracting two logarithms of large integers lost a tiny interval's digits (the mathematical
// audit's H14). Elsewhere the difference of the logs, which is exact enough.
export function ratioCents(numerator,denominator=1){
  const n=positiveInteger(numerator,'numerator'),d=positiveInteger(denominator,'denominator'),difference=n-d;
  // Each side as a double: the difference is exact while it is small, the denominator to 53 bits, which is all the
  // quotient needs.
  if((difference<0n?-difference:difference)*64n<d)return 1200/Math.LN2*Math.log1p(Number(difference)/Number(d));
  return 1200*(log2Big(n)-log2Big(d));
}

// ---- Prime-exponent vectors and temperaments -------------------------------------------------------------------
const isPrime=value=>{if(value<2)return false;for(let d=2;d*d<=value;d++)if(value%d===0)return false;return true};
export function monzo(basis,exponents){
  list(basis,'A monzo\'s basis',{min:1,max:INTENT_LIMITS.basisLength});list(exponents,'A monzo\'s exponents',{min:1,max:INTENT_LIMITS.basisLength});
  if(basis.length!==exponents.length)fail('A monzo has one exponent for each prime of its basis');
  basis.forEach((prime,index)=>{if(!Number.isSafeInteger(prime)||prime>1e6||!isPrime(prime)||(index&&prime<=basis[index-1]))fail('A monzo\'s basis is increasing primes')});
  exponents.forEach(exponent=>{if(!Number.isSafeInteger(exponent)||Math.abs(exponent)>INTENT_LIMITS.exponent)fail('A monzo\'s exponents are small integers')});
  return Object.freeze({kind:'monzo',basis:Object.freeze([...basis]),exponents:Object.freeze([...exponents])});
}
// A temperament mapping: named, versioned, and its generators' sizes in cents. Coordinates are meaningful only in the
// mapping they were written for.
export function temperamentMapping({id,version,generatorsCents}){
  identifier(id,'temperament id');identifier(version,'temperament version');
  list(generatorsCents,'A temperament\'s generators',{min:1,max:INTENT_LIMITS.coordinates}).forEach((value,index)=>finite(value,`generator ${index}`));
  return Object.freeze({id,version,generatorsCents:Object.freeze([...generatorsCents])});
}
export function temperamentInterval(mapping,coordinates){
  list(coordinates,'Temperament coordinates',{min:1,max:INTENT_LIMITS.coordinates});
  if(coordinates.length!==mapping.generatorsCents.length)fail(`${mapping.id} takes ${mapping.generatorsCents.length} coordinates`);
  coordinates.forEach(value=>{if(!Number.isSafeInteger(value)||Math.abs(value)>INTENT_LIMITS.exponent)fail('Temperament coordinates are small integers')});
  return Object.freeze({kind:'temperament',mappingId:mapping.id,mappingVersion:mapping.version,coordinates:Object.freeze([...coordinates])});
}
export const cents=value=>Object.freeze({kind:'cents',value:finite(value,'A cents interval')});

// Any interval as declared, validated (the shapes above, from JSON).
export function interval(value){
  plain(value,'An interval');
  switch(value.kind){
    case 'ratio':knownFields(value,['kind','numerator','denominator'],'ratio interval');return ratio(value.numerator,value.denominator);
    case 'monzo':knownFields(value,['kind','basis','exponents'],'monzo interval');return monzo(value.basis,value.exponents);
    case 'temperament':{
      knownFields(value,['kind','mappingId','mappingVersion','coordinates'],'temperament interval');
      identifier(value.mappingId,'temperament id');identifier(value.mappingVersion,'temperament version');
      list(value.coordinates,'Temperament coordinates',{min:1,max:INTENT_LIMITS.coordinates}).forEach(item=>{if(!Number.isSafeInteger(item)||Math.abs(item)>INTENT_LIMITS.exponent)fail('Temperament coordinates are small integers')});
      return Object.freeze({kind:'temperament',mappingId:value.mappingId,mappingVersion:value.mappingVersion,coordinates:Object.freeze([...value.coordinates])});
    }
    case 'cents':knownFields(value,['kind','value'],'cents interval');return cents(value.value);
    default:fail(`An interval is one of ${INTERVAL_KINDS.join(', ')}`);
  }
}
// Its size in cents. A temperament interval needs its mapping, at the version it was written for.
export function intervalCents(value,{mappings=[]}={}){
  const spec=interval(value);
  if(spec.kind==='ratio')return ratioCents(spec.numerator,spec.denominator);
  if(spec.kind==='cents')return spec.value;
  if(spec.kind==='monzo')return 1200*spec.basis.reduce((sum,prime,index)=>sum+spec.exponents[index]*Math.log2(prime),0);
  const mapping=mappings.find(item=>item.id===spec.mappingId&&item.version===spec.mappingVersion);
  if(!mapping)fail(`No temperament mapping ${spec.mappingId}@${spec.mappingVersion} to evaluate this interval in`);
  return spec.coordinates.reduce((sum,value,index)=>sum+value*mapping.generatorsCents[index],0);
}
// Whether two intervals are the same as declared: the same ratio, the same vector on the same basis, the same
// coordinates in the same mapping, the same cents. Different kinds are different declarations, however close their
// sizes: that comparison is `acousticallyNear`.
export function sameInterval(a,b){
  const x=interval(a),y=interval(b);
  return x.kind===y.kind&&frozenJson(x).canonical===frozenJson(y).canonical;
}
export const acousticallyNear=(a,b,toleranceCents,options)=>Math.abs(intervalCents(a,options)-intervalCents(b,options))<=toleranceCents;

// ---- References and pitches ----------------------------------------------------------------------------------------
// A declared reference: an id and a positive frequency (or a MIDI number, converted at A4 = 440 Hz).
export function pitchReference({id,hz,midi}={}){
  identifier(id,'pitch reference id');
  const frequency=hz??(Number.isFinite(midi)?440*2**((midi-69)/12):undefined);
  if(typeof frequency!=='number'||!Number.isFinite(frequency)||frequency<=0||frequency>1e6)fail('A pitch reference has a positive frequency');
  return Object.freeze({id,hz:frequency});
}
export const centsToHz=(value,reference)=>reference.hz*2**(finite(value,'cents')/1200);
export const hzToCents=(hz,reference)=>{if(!(hz>0))fail('A frequency must be positive');return 1200*Math.log2(hz/reference.hz)};
// The fractional MIDI number a renderer takes (A4 = 440 Hz = 69).
export const midiFromCents=(value,reference)=>69+finite(value,'cents')/100+12*(Math.log2(reference.hz)-Math.log2(440));

// ---- Regions, alternatives and curves -------------------------------------------------------------------------------
export function pitchRegion(value){
  plain(value,'A pitch region');knownFields(value,['minCents','maxCents','referenceId'],'pitch region');
  const minCents=finite(value.minCents,'A region\'s lower bound'),maxCents=finite(value.maxCents,'A region\'s upper bound');
  if(minCents>maxCents)fail('A region\'s lower bound is above its upper bound');
  return Object.freeze({minCents,maxCents,referenceId:identifier(value.referenceId,'region reference')});
}
export const inRegion=(valueCents,region,tolerance=0)=>valueCents>=region.minCents-tolerance&&valueCents<=region.maxCents+tolerance;

// One connected region, and the intervals it would like to make with other events. Disconnected admissible regions are
// several alternatives, never one wide region (§6.2): the gap between them was not authorized.
export function tuningAlternative(value){
  plain(value,'A tuning alternative');knownFields(value,['id','region','preferredIntervals'],'tuning alternative');
  return Object.freeze({id:identifier(value.id,'alternative id'),region:pitchRegion(value.region),
    preferredIntervals:Object.freeze(list(value.preferredIntervals??[],'Preferred intervals',{max:INTENT_LIMITS.preferredIntervals}).map(item=>{
      plain(item,'A preferred interval');knownFields(item,['otherEventId','interval','weight'],'preferred interval');
      if(typeof item.weight!=='number'||!(item.weight>0)||!Number.isFinite(item.weight))fail('A preferred interval\'s weight is positive');
      return Object.freeze({otherEventId:identifier(item.otherEventId,'event id'),interval:interval(item.interval),weight:item.weight});
    }))});
}

export function pitchCurve(value){
  plain(value,'A pitch curve');knownFields(value,['referenceId','offsetUnit','timelineRevision','interpolation','points'],'pitch curve');
  if(!['seconds','musical-units'].includes(value.offsetUnit))fail('A curve\'s offsets are in seconds or musical units');
  if(value.interpolation!=='linear')fail('A curve interpolates linearly');
  const points=list(value.points,'A curve\'s points',{min:1,max:INTENT_LIMITS.curvePoints}).map((point,index,all)=>{
    plain(point,'A curve point');knownFields(point,['offset','cents'],'curve point');
    const offset=finite(point.offset,'A curve point\'s offset');
    if(index&&!(offset>all[index-1].offset))fail('A curve\'s offsets increase');
    return Object.freeze({offset,cents:finite(point.cents,'A curve point\'s cents')});
  });
  return Object.freeze({referenceId:identifier(value.referenceId,'curve reference'),offsetUnit:value.offsetUnit,
    timelineRevision:identifier(String(value.timelineRevision),'timeline revision'),interpolation:'linear',points:Object.freeze(points)});
}
// The curve's pitch at an offset (held at its ends).
export function curveAt(curve,offset){
  const points=curve.points;
  if(offset<=points[0].offset)return points[0].cents;
  if(offset>=points.at(-1).offset)return points.at(-1).cents;
  let index=1;while(points[index].offset<offset)index++;
  const a=points[index-1],b=points[index];
  return a.cents+(b.cents-a.cents)*(offset-a.offset)/(b.offset-a.offset);
}
// Whether a linear curve stays inside a region everywhere, not only at its points: for a straight segment the extremes
// are its ends, so checking the points is exact.
export const curveWithin=(curve,region,tolerance=0)=>curve.referenceId===region.referenceId&&curve.points.every(point=>inRegion(point.cents,region,tolerance));

// ---- Roles, provenance, and a harmonic event's intent -----------------------------------------------------------------
export function semanticRole(value){
  plain(value,'A semantic role');knownFields(value,['contextId','roleId','spelling','obligationIds'],'semantic role');
  if(value.spelling!==undefined&&(typeof value.spelling!=='string'||value.spelling.length>32))fail('A spelling is a short annotation');
  return Object.freeze({contextId:identifier(value.contextId,'context id'),roleId:identifier(value.roleId,'role id'),
    ...(value.spelling!==undefined?{spelling:value.spelling}:{}),
    obligationIds:Object.freeze(list(value.obligationIds??[],'Obligations',{max:INTENT_LIMITS.obligations}).map(id=>identifier(id,'obligation id')))});
}
export function provenance(value={}){
  plain(value,'Provenance');knownFields(value,['sourceIds','rulePackageVersions','observationIds','interpretationId'],'provenance');
  const versions=plain(value.rulePackageVersions??{},'Rule package versions');
  return Object.freeze({sourceIds:Object.freeze(list(value.sourceIds??[],'Source ids',{max:32}).map(id=>identifier(id,'source id'))),
    rulePackageVersions:Object.freeze(Object.fromEntries(Object.entries(versions).map(([id,version])=>[identifier(id,'package id'),identifier(version,'package version')]))),
    observationIds:Object.freeze(list(value.observationIds??[],'Observation ids',{max:32}).map(id=>identifier(id,'observation id'))),
    ...(value.interpretationId!==undefined?{interpretationId:identifier(value.interpretationId,'interpretation id')}:{})});
}
export function harmonicEventIntent(value){
  plain(value,'A harmonic event intent');
  knownFields(value,['eventId','voiceId','ownerId','timelineEventId','roles','alternatives','protectedCurve','retunePolicy','provenance'],'harmonic event intent');
  if(!RETUNE_POLICIES.includes(value.retunePolicy))fail(`A retune policy is one of ${RETUNE_POLICIES.join(', ')}`);
  const alternatives=list(value.alternatives,'Tuning alternatives',{min:1,max:INTENT_LIMITS.alternatives}).map(tuningAlternative);
  if(new Set(alternatives.map(item=>item.id)).size!==alternatives.length)fail('Tuning alternatives have distinct ids');
  const protectedCurve=value.protectedCurve===undefined?undefined:pitchCurve(value.protectedCurve);
  // A protected curve must lie inside one of the regions it could be realized in: otherwise it is not protected by
  // them but contradicted.
  if(protectedCurve&&!alternatives.some(alternative=>curveWithin(protectedCurve,alternative.region)))
    fail('A protected curve lies outside every tuning alternative\'s region');
  return Object.freeze({eventId:identifier(value.eventId,'event id'),voiceId:identifier(value.voiceId,'voice id'),ownerId:identifier(value.ownerId,'owner id'),
    timelineEventId:identifier(value.timelineEventId,'timeline event id'),
    roles:Object.freeze(list(value.roles,'Roles',{max:INTENT_LIMITS.roles}).map(semanticRole)),
    alternatives:Object.freeze(alternatives),...(protectedCurve?{protectedCurve}:{}),retunePolicy:value.retunePolicy,
    provenance:provenance(value.provenance)});
}

// ---- Serialization -----------------------------------------------------------------------------------------------
// Canonical JSON: sorted keys, ratios as strings, nothing rounded. parse(serialize(x)) is x.
export const serializeIntent=value=>frozenJson(harmonicEventIntent(value),{bytes:INTENT_LIMITS.bytes}).canonical;
export function parseIntent(text){
  if(typeof text!=='string'||text.length>INTENT_LIMITS.bytes)fail('An intent is a JSON string within its budget');
  return harmonicEventIntent(frozenJson(JSON.parse(text),{bytes:INTENT_LIMITS.bytes}).data);
}

// The one lossy view: a realized pitch in cents as the fractional MIDI number a renderer takes. It says what it drops,
// so that nothing downstream mistakes the projection for the intent (§3.2).
export function projectToMidi(valueCents,reference,{intent=null}={}){
  const pitch=midiFromCents(valueCents,reference);
  return Object.freeze({pitch,lossy:Object.freeze(['roles','alternatives','exact intervals','provenance',...(intent?.protectedCurve?['protected curve']:[])])});
}
