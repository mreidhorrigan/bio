// Three spectral modes (the harmonic-systems report §§6.8-6.9; T16, T17). A note's sound as partials (frequency and
// amplitude); roughness as one authored preference, never a measure of musical quality: the pairwise curve Sethares fitted
// to Plomp and Levelt's data (registry/perception/roughness.json `dissonance-curve`; `dissonance`, which the harmony's
// spectral consonance reads too), the partials' amplitudes weighted by their product (our choice), over a bounded number
// of partials.
//
//   S1  spectral colouring, fixed fundamentals (colourSpectra): partial amplitudes moved within bounds to bring the
//       roughness toward a target, every fundamental's frequency and amplitude untouched, no partial deleted, the
//       loudness within a decibel; a target out of reach is reported, not reached by silencing.
//   S2  identity-preserving adaptive tuning: the realization's tuner (realization.js), each fundamental inside its role's
//       region; nothing new here.
//   S3  an explicit identity-changing morph (morph): each voice moved from one structure's pitch to another's over the
//       steps authored, each step labelled with the identity it has -- the role it keeps, the one it arrives at, or
//       'crossing' between their regions -- and the crossings listed; what the morph preserves is only what it declares.
import {perception} from '../../../registry/registry.js';

export const SPECTRAL=Object.freeze({...perception('dissonance-curve'),maxPartials:16});
// How far apart two partials stand on the curve's own scale: their distance in hertz over the band at the lower.
const scaled=(lowHz,highHz)=>SPECTRAL.dStar*(highHz-lowHz)/(SPECTRAL.s1*lowHz+SPECTRAL.s2);
const curve=at=>Math.exp(-SPECTRAL.b1*at)-Math.exp(-SPECTRAL.b2*at);
// How rough two partials of unit amplitude sound together, the lower at `lowHz`: none in unison, most about a quarter
// of a critical band apart, little past it. Each reader weights a pair by its partials' amplitudes as it chooses.
export const dissonance=(lowHz,highHz)=>curve(scaled(lowHz,highHz));

export const harmonicSpectrum=(f0,{partials=8,rolloff=1}={})=>Object.freeze(Array.from({length:Math.min(partials,SPECTRAL.maxPartials)},(_,k)=>Object.freeze({n:k+1,hz:f0*(k+1),amp:1/(k+1)**rolloff})));
// The roughness of a set of spectra (each a list of partials) sounding together.
export function roughness(spectra){
  const all=spectra.flatMap(spectrum=>spectrum.slice(0,SPECTRAL.maxPartials)).filter(p=>p.amp>0).sort((a,b)=>a.hz-b.hz);
  let total=0;
  for(let i=0;i<all.length;i++)for(let j=i+1;j<all.length;j++){
    const low=all[i],high=all[j],at=scaled(low.hz,high.hz);
    if(at>8)break;   // past the curve's reach: every later partial is further still
    total+=low.amp*high.amp*curve(at);
  }
  return total;
}
const power=spectra=>spectra.flat().reduce((sum,p)=>sum+p.amp*p.amp,0);

// S1. spectra: [[{n, hz, amp}]] with n 1 each note's fundamental. Moves the other partials' amplitudes within [-maxCutDb,
// +maxBoostDb] of their own, a step at a time, each move kept only if it brings the roughness toward `target` (as little
// as the bounds allow, by default: 0) and leaves the loudness within `loudnessDb` of where it began. Gives {spectra,
// before, after, fundamentalsUnchanged, deleted, loudnessDb, reached}.
export function colourSpectra(spectra,{maxCutDb=12,maxBoostDb=3,floorDb=40,target=0,loudnessDb:tolerance=1,iterations=24,step=.5}={}){
  const out=spectra.map(spectrum=>spectrum.map(p=>({...p})));
  const before=roughness(spectra),loud=power(spectra),limits=spectra.map(spectrum=>spectrum.map(p=>({low:p.amp*10**(-maxCutDb/20),high:p.amp*10**(maxBoostDb/20)})));
  const aim=value=>Math.abs(value-target),loudEnough=()=>Math.abs(10*Math.log10(power(out)/loud))<=tolerance;
  for(let pass=0;pass<iterations;pass++){
    let improved=false;
    for(let s=0;s<out.length;s++)for(let k=0;k<out[s].length;k++){
      const p=out[s][k];if(p.n===1)continue;
      for(const factor of [10**(-step/20),10**(step/20)]){
        const was=p.amp,now=Math.min(limits[s][k].high,Math.max(limits[s][k].low,was*factor));
        if(now===was)continue;
        const current=aim(roughness(out));p.amp=now;
        if(loudEnough()&&aim(roughness(out))<current-1e-12){improved=true;break}
        p.amp=was;
      }
    }
    if(!improved)break;
  }
  const after=roughness(out),fundamentalsUnchanged=out.every((spectrum,s)=>spectrum.every((p,k)=>p.n!==1||p.amp===spectra[s][k].amp&&p.hz===spectra[s][k].hz));
  const loudest=Math.max(...out.flat().map(q=>q.amp)),deleted=out.flat().filter(p=>!(p.amp>0)||p.amp<loudest*10**(-floorDb/20)).length;
  return Object.freeze({spectra:Object.freeze(out.map(spectrum=>Object.freeze(spectrum.map(Object.freeze)))),before,after,fundamentalsUnchanged,deleted,
    loudnessDb:10*Math.log10(power(out)/loud),reached:Math.abs(after-target)<=Math.abs(before-target)*.01+1e-9});
}

// S3. from, to: [{voice, cents, role, region: [low, high] (cents: where the note keeps its identity)}], matched by voice;
// steps: how many moves. Gives {frames: [{step, voices: [{voice, cents, identity}]}], crossings: [{voice, step, from, to}],
// preserves: what the morph declares it keeps (the voices, their order where it holds); boundaries are never claimed kept.
export function morph(from,to,{steps=4}={}){
  if(!Number.isSafeInteger(steps)||steps<1||steps>64)throw new RangeError('A morph has 1 to 64 steps');
  const pairs=from.map(a=>{const b=to.find(item=>item.voice===a.voice);if(!b)throw new RangeError(`${a.voice} has no destination`);return [a,b]});
  const identity=(a,b,cents)=>cents>=a.region[0]&&cents<=a.region[1]?`from:${a.role}`:cents>=b.region[0]&&cents<=b.region[1]?`to:${b.role}`:'crossing';
  const frames=[],crossings=[];
  for(let step=0;step<=steps;step++){
    const t=step/steps;
    frames.push(Object.freeze({step,voices:Object.freeze(pairs.map(([a,b])=>{const cents=a.cents+(b.cents-a.cents)*t;return Object.freeze({voice:a.voice,cents,identity:identity(a,b,cents)})}))}));
  }
  for(const [a,b] of pairs){
    const labels=frames.map(frame=>frame.voices.find(v=>v.voice===a.voice).identity);
    labels.forEach((label,step)=>{if(step&&label!==labels[step-1])crossings.push(Object.freeze({voice:a.voice,step,from:labels[step-1],to:label}))});
  }
  const ordered=frames.every(frame=>frame.voices.every((v,k,all)=>!k||all[k-1].cents<=v.cents)===frames[0].voices.every((v,k,all)=>!k||all[k-1].cents<=v.cents));
  return Object.freeze({frames:Object.freeze(frames),crossings:Object.freeze(crossings),preserves:Object.freeze(['voices',...(ordered?['voice order']:[])]),kind:'identity-changing morph'});
}
