// The validator: a plan checked against its package's rules from the plan's own data, independently of how it was
// found (the harmonic-systems report, §5.4, §8.2-8.3). The generator uses it to prune, and every plan it returns is
// checked again here from the beginning, obligations and all, so a slip in the search's bookkeeping cannot pass as a
// valid plan.
//
// A plan is a list of steps. A step: {context, structure, offsetCents (the structure's transposition), via (the
// transformation that made it, or null), lineageCents (for an exact translation of part of a block: how far the block
// moved: `lineage`, per voice, in cents), voicing: [{voice, cents, role, degree}]} with pitches as
// absolute cents (100 to a MIDI step) and `role` null for a note that is no role of the structure (a protected melody's
// passing note). Rules and their scopes are the package's (packages.js); hard rules report failures, soft ones costs.
import {intervalCents} from './pitch-intent.js';
import {periodCents,degreeCents,structureOf,transformationOf,ruleApplies} from './packages.js';

// What the grammar allows a plan, checked here from the package itself rather than trusted from the generator (the
// mathematical audit's H12: a sequence grammarAccepts rejects had validated): the first context a start, each context
// one the package has, each step's structure one its context holds, and each step reached by a declared transition,
// by the transformation the transition names (none, where it names none).
function grammarFailures(pkg,plan){
  const failures=[],contexts=new Map(pkg.contexts.map(context=>[context.id,context]));
  plan.forEach((step,index)=>{
    const context=contexts.get(step.context);
    if(!context){failures.push({step:index,detail:`${step.context} is not a context of ${pkg.id}`});return}
    if(!index&&!pkg.start.includes(step.context))failures.push({step:index,detail:`${step.context} is not a start context`});
    if(step.structure&&!context.structures.includes(step.structure))failures.push({step:index,detail:`${step.context} does not hold ${step.structure}`});
    if(!index)return;
    const from=plan[index-1].context,edges=pkg.transitions.filter(transition=>transition.from===from&&transition.to===step.context);
    if(!edges.length)failures.push({step:index,detail:`no transition from ${from} to ${step.context}`});
    else if(!edges.some(transition=>(transition.via??null)===(step.via??null)))
      failures.push({step:index,detail:`no transition from ${from} to ${step.context} ${step.via?`by ${step.via}`:'without a transformation'}`});
  });
  return failures;
}

// ---- Choices ---------------------------------------------------------------------------------------------------
export const VALIDATION=Object.freeze({
  pitchToleranceCents:.5,     // a pitch is on its degree, a common tone held, within this
  failuresKept:64,            // explanations kept per plan (the first ones; the count is reported in full)
});

const reduce=(value,period)=>period===null?value:((value%period)+period)%period;
// The distance between two intervals, around the period where there is one (a fifth and a twelfth are one class then).
const classDistance=(a,b,period)=>{
  if(period===null)return Math.abs(a-b);
  const d=reduce(a-b,period);return Math.min(d,period-d);
};
const sounding=step=>step.voicing.filter(note=>Number.isFinite(note.cents));
const byVoice=step=>new Map(sounding(step).map(note=>[note.voice,note]));

// The pitch a role should have in a step: its degree at the structure's transposition (and a block's lineage).
function expectedClass(pkg,step,note,tonicCents){
  if(note.role===null||note.degree===null)return null;
  const lineage=step.lineage?.[note.voice]??0;
  return tonicCents+step.offsetCents+degreeCents(pkg,note.degree)+lineage;
}

// Every hard failure and soft cost of a plan. options: {tonicCents, protectedPitches: {voice: [cents per step]},
// voices: [{id, range: [lowCents, highCents]}] (the performer's: a note outside its voice's range fails, whatever the
// package says)}.
export function validatePlan(pkg,plan,{tonicCents=0,protectedPitches={},voices=[]}={}){
  const period=periodCents(pkg),failures=[],soft=new Map,open=[];let count=0,maxResidual=0;
  const ranges=new Map(voices.map(voice=>[voice.id,voice.range]));
  const fail=(rule,index,detail)=>{count++;if(failures.length<VALIDATION.failuresKept)failures.push(Object.freeze({ruleId:rule.id,type:rule.type,step:index,...detail}))};
  // Only a soft rule has a cost, and only a finite one ranks: a hard rule's cost was its missing weight times an amount,
  // NaN, which made a broken hard rule pass with a NaN total (H12).
  const cost=(rule,amount,index)=>{
    if(!(amount>0))return;
    const value=amount*rule.weight;
    if(rule.strength!=='soft'||!Number.isFinite(value)){fail(rule,index,{detail:`${rule.id} produced no finite cost (${value})`});return}
    soft.set(rule.id,(soft.get(rule.id)??0)+value);
  };
  const breach=(rule,index,detail,amount=1)=>rule.strength==='hard'?fail(rule,index,detail):cost(rule,amount,index);
  for(const failure of grammarFailures(pkg,plan)){count++;if(failures.length<VALIDATION.failuresKept)failures.push(Object.freeze({ruleId:'grammar',type:'grammar',...failure}))}

  plan.forEach((step,index)=>{
    const seenVoices=new Set;
    for(const note of step.voicing){
      if(typeof note.voice!=='string'||!note.voice||seenVoices.has(note.voice)||voices.length&&!ranges.has(note.voice))
        fail({id:'voice-identity',type:'voice-identity'},index,{voice:note.voice,detail:'Voices must have unique declared identities within each step'});
      seenVoices.add(note.voice);
    }
    const previous=index?plan[index-1]:null,transition=previous?{from:previous.context,to:step.context}:null;
    const structure=step.structure?structureOf(pkg,step.structure):null;
    // Labels agree with pitches: a role's note lies on its degree (period by period), whatever the rules.
    for(const note of sounding(step)){
      const expected=expectedClass(pkg,step,note,tonicCents);
      if(expected===null)continue;
      const residual=classDistance(note.cents,expected,period);
      maxResidual=Math.max(maxResidual,residual);
      if(residual>VALIDATION.pitchToleranceCents)failures.push(Object.freeze({ruleId:'labels',type:'labels',step:index,voice:note.voice,
        detail:`${note.voice} is labelled ${note.role} (degree ${note.degree}) and sounds ${residual.toFixed(2)} cents off it`}));
    }
    for(const note of sounding(step)){
      const range=ranges.get(note.voice);
      if(range&&(note.cents<range[0]-VALIDATION.pitchToleranceCents||note.cents>range[1]+VALIDATION.pitchToleranceCents))
        failures.push(Object.freeze({ruleId:'voice-range',type:'voice-range',step:index,voice:note.voice,detail:`${note.voice} sounds ${note.cents.toFixed(1)} cents, outside its range ${range[0]} to ${range[1]}`}));
    }
    for(const rule of pkg.rules){
      if(!ruleApplies(rule,{context:step.context,transition}))continue;
      // An empty scope list means every voice or role (packages.js scope), not none.
      const inScope=note=>(!rule.scope.voices?.length||rule.scope.voices.includes(note.voice))&&(!rule.scope.roles?.length||rule.scope.roles.includes(note.role));
      switch(rule.type){
        case 'required-roles':{
          if(!structure)break;
          const missing=structure.roles.filter(member=>member.required&&!sounding(step).some(note=>note.role===member.role)).map(member=>member.role);
          if(missing.length)breach(rule,index,{roles:missing,detail:`${step.structure} is missing its required ${missing.join(', ')}`},missing.length);
          break;
        }
        case 'range':
          for(const note of sounding(step))if(note.voice===rule.voice){
            const relative=note.cents-tonicCents;
            if(relative<rule.minCents||relative>rule.maxCents)breach(rule,index,{voices:[note.voice],detail:`${note.voice} at ${relative.toFixed(1)} cents is outside ${rule.minCents}..${rule.maxCents}`});
          }
          break;
        case 'protect-voice':{
          const given=protectedPitches[rule.voice]?.[index];
          if(!Number.isFinite(given))break;
          const note=byVoice(step).get(rule.voice);
          if(!note||Math.abs(note.cents-given)>VALIDATION.pitchToleranceCents)
            breach(rule,index,{voices:[rule.voice],detail:`the protected ${rule.voice} was to sound ${given} and ${note?`sounds ${note.cents}`:'is silent'}`});
          break;
        }
        case 'max-span':{
          const pitches=sounding(step).filter(inScope).map(note=>note.cents);
          const span=pitches.length>1?Math.max(...pitches)-Math.min(...pitches):0;
          if(span>rule.cents+VALIDATION.pitchToleranceCents)breach(rule,index,{detail:`the voicing spans ${span.toFixed(1)} cents, more than ${rule.cents}`},(span-rule.cents)/100);
          break;
        }
        case 'avoid-interval':{
          // Directed where it names roles `against` (a voice in scope against those roles); otherwise an interval
          // between two voices is one breach, however many of the two are in scope (it was counted from each end).
          const target=intervalCents(rule.interval),notes=sounding(step);
          notes.forEach((a,i)=>notes.forEach((b,j)=>{
            if(i===j||!inScope(a)||b.voice===a.voice)return;
            if(rule.against){if(!rule.against.includes(b.role))return}
            else if(j<i&&inScope(b))return;
            if(classDistance(Math.abs(a.cents-b.cents),target,period)<=rule.toleranceCents)
              breach(rule,index,{voices:[a.voice,b.voice],detail:`${a.voice} and ${b.voice} (${b.role??'no role'}) sound the interval ${rule.id} avoids`});
          }));
          break;
        }
      }
      if(!previous)continue;
      const before=byVoice(previous),after=byVoice(step);
      switch(rule.type){
        case 'max-motion':
          for(const [voice,note] of after){
            const was=before.get(voice);
            if(!was||!inScope(note))continue;
            const motion=Math.abs(note.cents-was.cents);
            if(motion>rule.cents)breach(rule,index,{voices:[voice],detail:`${voice} moves ${motion.toFixed(1)} cents, more than ${rule.cents}`},(motion-rule.cents)/100);
          }
          break;
        case 'forbid-parallel':{
          const target=intervalCents(rule.interval),voices=[...after.keys()].filter(voice=>before.has(voice)&&inScope(after.get(voice)));
          for(let i=0;i<voices.length;i++)for(let j=i+1;j<voices.length;j++){
            const [a0,b0,a1,b1]=[before.get(voices[i]).cents,before.get(voices[j]).cents,after.get(voices[i]).cents,after.get(voices[j]).cents];
            const moved=Math.abs(a1-a0)>VALIDATION.pitchToleranceCents&&Math.sign(a1-a0)===Math.sign(b1-b0);
            if(moved&&classDistance(Math.abs(b0-a0),target,period)<=rule.toleranceCents&&classDistance(Math.abs(b1-a1),target,period)<=rule.toleranceCents)
              breach(rule,index,{voices:[voices[i],voices[j]],detail:`${voices[i]} and ${voices[j]} move in parallel by the interval ${rule.id} forbids`});
          }
          break;
        }
        case 'preserve-block':{
          if(step.via!==rule.transformation)break;
          const detail=blockBreach(pkg,transformationOf(pkg,rule.transformation),previous,step,{tonicCents,period});
          if(detail)breach(rule,index,{detail});
          break;
        }
        case 'hold-common-tones':{
          // A degree both chords hold, sounded in both, but by no voice held on the same pitch: counted for the voices in
          // the rule's scope (every voice was counted), and broken, where the rule is hard, rather than costed.
          const judged=[...after.values()].filter(inScope);
          const held=judged.filter(note=>{const was=before.get(note.voice);return was&&Math.abs(was.cents-note.cents)<=VALIDATION.pitchToleranceCents}).length;
          const shared=judged.filter(note=>[...before.values()].some(was=>classDistance(was.cents,note.cents,period)<=VALIDATION.pitchToleranceCents)).length;
          if(shared>held)breach(rule,index,{detail:`${shared-held} common tone${shared-held===1?'':'s'} not held by the voice that had ${shared-held===1?'it':'them'}`},shared-held);
          break;
        }
      }
    }
  });
  // Resolution obligations, over the whole plan: a voice sounding the role owes a step the given way within the
  // horizon; one still owed when the plan ends is open, not broken (the future may pay it).
  for(const rule of pkg.rules.filter(item=>item.type==='resolve')){
    plan.forEach((step,index)=>{
      if(!ruleApplies(rule,{context:step.context}))return;
      for(const note of sounding(step)){
        if(note.role!==rule.role||(rule.scope.voices&&!rule.scope.voices.includes(note.voice)))continue;
        // An obligation is incurred where the role arrives, not every step it is held.
        const was=index?byVoice(plan[index-1]).get(note.voice):null;
        if(was&&was.role===rule.role&&Math.abs(was.cents-note.cents)<=VALIDATION.pitchToleranceCents)continue;
        let met=false,decided=false,end=Math.min(plan.length-1,index+rule.within);
        for(let later=index+1;later<=end&&!met;later++){
          const next=byVoice(plan[later]).get(note.voice),prior=byVoice(plan[later-1]).get(note.voice);
          if(!next||!prior)break;
          const motion=next.cents-prior.cents;
          if(Math.abs(motion)<=VALIDATION.pitchToleranceCents)continue;     // held: still owed
          met=Math.abs(motion)<=rule.maxCents&&(rule.direction==='any'||(rule.direction==='down'?motion<0:motion>0));
          if(!met){decided=true;break}                                       // moved the wrong way or too far
        }
        if(met)continue;
        // Open only while it can still be paid: one that moved the wrong way is broken now, whatever its horizon.
        if(!decided&&index+rule.within>plan.length-1)open.push(Object.freeze({ruleId:rule.id,step:index,voice:note.voice,dueBy:index+rule.within}));
        else breach(rule,index,{voices:[note.voice],detail:`${note.voice}'s ${rule.role} did not resolve ${rule.direction} by step ${index+rule.within}`});
      }
    });
  }
  return Object.freeze({ok:failures.length===0,hardFailures:Object.freeze(failures),failureCount:Math.max(count,failures.length),
    softCosts:Object.freeze(Object.fromEntries(soft)),softTotal:[...soft.values()].reduce((a,b)=>a+b,0),openObligations:Object.freeze(open),maxResidual});
}

// How a step breaks its transformation's invariants, or null. Exact: every block voice moved by one nonzero
// interval, their intervals kept. Collection: every block voice moved by one number of the collection's steps. Role
// map: held roles still, the others on their new degrees. Reflection: every voice in scope on its mirror about the axis
// (exactly, for a strict mirror; its class, otherwise), every other voice held, none silenced.
export function blockBreach(pkg,transformation,previous,step,{tonicCents=0,period=periodCents(pkg)}={}){
  const before=byVoice(previous),after=byVoice(step);
  if(transformation.kind==='reflection'){
    const axis=tonicCents+previous.offsetCents+intervalCents(transformation.axis),ordered=[...before.values()].sort((a,b)=>a.cents-b.cents);
    const low=ordered[0]?.voice,high=ordered.at(-1)?.voice,scope=transformation.scope;
    const inScope=voice=>scope==='entire-layer'||(scope==='melody'?voice===high:scope==='chord'?voice!==low&&voice!==high:voice!==high);
    for(const [voice,was] of before){
      const now=after.get(voice);
      if(!now)return `${voice} fell silent in a reflection`;
      if(!inScope(voice)){if(Math.abs(now.cents-was.cents)>VALIDATION.pitchToleranceCents)return `${voice} is outside the reflection's scope and moved`;continue}
      const mirror=2*axis-was.cents;
      const off=transformation.registerPolicy==='strict-mirror'?Math.abs(now.cents-mirror):classDistance(now.cents,mirror,period);
      if(off>VALIDATION.pitchToleranceCents)return `${voice} sounds ${off.toFixed(1)} cents from the mirror of where it was`;
    }
    return null;
  }
  const blockVoices=[...after.values()].filter(note=>{
    const was=before.get(note.voice);
    return was&&(transformation.block==='all'||transformation.block===undefined||transformation.block.includes(was.role));
  }).map(note=>note.voice);
  if(transformation.kind==='exact-translation'){
    if(!blockVoices.length)return 'the block is empty';
    const moves=blockVoices.map(voice=>after.get(voice).cents-before.get(voice).cents);
    if(Math.abs(moves[0])<=VALIDATION.pitchToleranceCents)return 'the block did not move';
    const off=moves.find(move=>Math.abs(move-moves[0])>transformation.toleranceCents);
    if(off!==undefined)return `the block's voices moved by different intervals (${moves.map(move=>move.toFixed(1)).join(', ')} cents): not an exact translation`;
    if(transformation.by!=='any'&&!transformation.by.some(spec=>Math.abs(intervalCents(spec)-moves[0])<=transformation.toleranceCents))return `the block moved ${moves[0].toFixed(1)} cents, not by an interval the transformation allows`;
    return null;
  }
  if(transformation.kind==='collection-translation'){
    const collection=pkg.collections.find(item=>item.id===transformation.collection);
    const positions=collectionPositions(pkg,collection,{tonicCents,offsetCents:previous.offsetCents,period});
    const stepsMoved=blockVoices.map(voice=>{
      const from=positions(before.get(voice).cents),to=positions(after.get(voice).cents);
      return from===null||to===null?null:to-from;
    });
    if(stepsMoved.some(moved=>moved===null))return 'a block voice is not on the collection';
    if(new Set(stepsMoved).size!==1)return `the block's voices moved by different numbers of steps (${stepsMoved.join(', ')}): its degree pattern is not kept`;
    if(!transformation.steps.includes(stepsMoved[0]))return `the block moved ${stepsMoved[0]} steps, not a step the transformation allows`;
    return null;
  }
  // A role map.
  for(const [voice,note] of after){
    const was=before.get(voice);
    if(!was||was.role===null)continue;
    if(transformation.holds.includes(was.role)&&Math.abs(was.cents-note.cents)>VALIDATION.pitchToleranceCents)return `${voice}'s ${was.role} is to be held and moved`;
    if(transformation.mapping[was.role]!==note.role)return `${voice}'s ${was.role} became ${note.role}, not ${transformation.mapping[was.role]}`;
  }
  return null;
}

// A pitch's position on a collection, counting across periods (step k of period p is k + p x size), or null when it is
// not on the collection.
export function collectionPositions(pkg,collection,{tonicCents=0,offsetCents=0,period=periodCents(pkg)}={}){
  const members=collection.degrees.map(id=>({id,cents:degreeCents(pkg,id)})).sort((a,b)=>a.cents-b.cents);
  return cents=>{
    const relative=cents-tonicCents-offsetCents;
    if(period===null){const index=members.findIndex(member=>Math.abs(member.cents-relative)<=VALIDATION.pitchToleranceCents);return index<0?null:index}
    const periods=Math.floor((relative+VALIDATION.pitchToleranceCents)/period),within=relative-periods*period;
    const index=members.findIndex(member=>Math.abs(reduce(member.cents,period)-within)<=VALIDATION.pitchToleranceCents);
    return index<0?null:index+periods*members.length;
  };
}
