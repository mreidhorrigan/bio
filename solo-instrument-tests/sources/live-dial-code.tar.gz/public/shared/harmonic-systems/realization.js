// From a plan to its pitches: the generator's chords and roles handed to the tuner as the package's tuning asks
// (the harmonic-systems report, §6), and the result checked. Each sounding note is an event; its role's tuning
// alternative gives its region (offsets about its nominal pitch) and the intervals it prefers above other roles of
// the same chord, laid in the register the voicing actually has (a tenth is 5:2, not 5:4: §6.2 keeps the register);
// a common tone held from one chord to the next follows the sustain policy (frozen by default: it does not move while
// it sounds, §6.6); a structure's root is held to its nominal pitch as firmly as a preference is weighed (the root is
// what a bass under it sounds, and its nominal pitch is counted from the root the caller heard: the tuned chord is
// just above the bass, not a few cents beside it), and every other note is pulled a little toward its nominal pitch,
// so the band stays near the grid a performer in equal temperament plays in and the pitch level cannot wander (the
// anchors that fix the gauge, §6.3).
// A structure whose package protects its symmetry (a diminished seventh's four equal minor thirds) keeps its sounding
// notes exactly as far apart as their degrees are: the chord may move as a whole, never out of shape, and every
// preference the symmetry contradicts is tempered and reported, never claimed as met (§6.5, T05).
import {intervalCents} from './pitch-intent.js';
import {periodCents,structureOf} from './packages.js';
import {tune,tuneAlternatives} from './tuner.js';
import {VALIDATION} from './validator.js';
import {beatingPair,centsPair} from '../pitch-languages/texture.js';
import {combinationTones} from '../pitch-languages/combination-tones.js';

// ---- Choices ---------------------------------------------------------------------------------------------------
export const REALIZATION=Object.freeze({
  nominalAnchorWeight:.02,     // each note's pull toward its nominal pitch, against a preference's weight of about 1
  rootAnchorWeight:1,          // a structure's root's, as firm as a preference
  heldPolicy:'frozen',         // a common tone held across a change: 'frozen' (exactly still) or 'bounded' (realized step by step)
  heldRetuneCents:3,           // how far a bounded held tone may move from where the step before tuned it
  temperedCents:.5,            // a preference missed by more than this is reported as tempered
});

const eventId=(step,voice)=>`${step}:${voice}`;

// One step's share of a tuning problem: its sounding notes as events, their anchors, the intervals each prefers above
// the other roles of its chord (by the alternative its role takes: the first, where there are several, with each
// alternative's own in `alternatives`, which tuneAlternatives weighs it by when it is chosen), and a protected
// symmetry's equalities.
function stepTerms(pkg,plan,index,{period,anchorWeight,rootAnchorWeight}){
  const step=plan[index],events=[],preferences=[],equalities=[],anchors=[],alternatives={};
  const notes=step.voicing.filter(note=>Number.isFinite(note.cents)),root=step.structure?structureOf(pkg,step.structure).root:undefined;
  for(const note of notes){
    const id=eventId(index,note.voice),entry=pkg.tuning.find(item=>item.structure===step.structure&&item.role===note.role);
    const choices=entry?.alternatives??[];
    events.push({id,nominalCents:note.cents,...(choices.length?{region:[note.cents+choices[0].offsetCents[0],note.cents+choices[0].offsetCents[1]]}:{})});
    const weight=root!==undefined&&note.role===root?rootAnchorWeight:anchorWeight;
    if(weight>0)anchors.push({id:`anchor:${id}`,event:id,targetCents:note.cents,weight});
    const preferred=choice=>(choice?.prefer??[]).flatMap(preference=>notes.filter(item=>item.role===preference.above&&item.voice!==note.voice).map(other=>{
      let target=intervalCents(preference.interval);
      // The register the voicing has: the ratio's nearest octave (period) to the interval actually voiced.
      if(period!==null)target+=period*Math.round((note.cents-other.cents-target)/period);
      return {id:`${index}:${preference.above}->${note.role}:${other.voice}->${note.voice}`,from:eventId(index,other.voice),to:id,targetCents:target,weight:preference.weight};
    }));
    preferences.push(...preferred(choices[0]));
    if(choices.length>1)alternatives[id]=choices.map(choice=>({id:choice.id,region:[note.cents+choice.offsetCents[0],note.cents+choice.offsetCents[1]],preferences:preferred(choice)}));
  }
  // A protected symmetry: its sounding roles held exactly their nominal distances apart, low to high.
  const symmetry=pkg.tuning.find(item=>item.structure===step.structure&&item.protectSymmetry);
  if(symmetry){
    const members=notes.filter(note=>symmetry.protectSymmetry.includes(note.role)).sort((a,b)=>a.cents-b.cents);
    for(let at=1;at<members.length;at++)equalities.push({id:`symmetry:${index}:${members[at-1].voice}->${members[at].voice}`,
      from:eventId(index,members[at-1].voice),to:eventId(index,members[at].voice),cents:members[at].cents-members[at-1].cents});
  }
  return {events,preferences,equalities,anchors,alternatives};
}
// The notes of step `index` held from the step before: the same voice on the same pitch.
const heldFromBefore=(plan,index)=>!index?[]:plan[index].voicing.filter(note=>{
  if(!Number.isFinite(note.cents))return false;
  const was=plan[index-1].voicing.find(item=>item.voice===note.voice);
  return was&&Number.isFinite(was.cents)&&Math.abs(was.cents-note.cents)<=VALIDATION.pitchToleranceCents;
});

// The tuning problem a plan makes, all its steps at once. options: {policy: 'frozen', anchorWeight, rootAnchorWeight}.
// A frozen held tone is an equality between its two soundings, which the joint problem states exactly. A bounded one
// (moving at most heldRetuneCents from where it sounded) is a bound between two pitches the joint problem would both
// be solving for, which the tuner, whose bounds are boxes, cannot state: the 'bounded' policy used to add nothing at
// all, and a 3-cent bound let a held tone sound 6390 then 6410 cents (the mathematical audit's H10). So it is refused
// here and realized step by step (realize), each held tone bounded about where the step before tuned it.
export function tuningProblem(pkg,plan,{policy=REALIZATION.heldPolicy,anchorWeight=REALIZATION.nominalAnchorWeight,rootAnchorWeight=REALIZATION.rootAnchorWeight}={}){
  if(policy==='bounded')throw new TypeError('A bounded held tone is realized step by step (realize), each within its bound of where the step before tuned it: one joint problem cannot state a bound between two of its own unknowns');
  if(policy!=='frozen')throw new TypeError(`A held tone's policy is frozen or bounded, not ${policy}`);
  const period=periodCents(pkg),events=[],preferences=[],equalities=[],anchors=[],alternatives={};
  plan.forEach((step,index)=>{
    const terms=stepTerms(pkg,plan,index,{period,anchorWeight,rootAnchorWeight});
    events.push(...terms.events);preferences.push(...terms.preferences);equalities.push(...terms.equalities);anchors.push(...terms.anchors);Object.assign(alternatives,terms.alternatives);
    for(const note of heldFromBefore(plan,index))
      equalities.push({id:`held:${eventId(index,note.voice)}`,from:eventId(index-1,note.voice),to:eventId(index,note.voice),cents:0});
  });
  return {problem:{events,preferences,equalities,anchors},alternatives};
}

// Step by step, for bounded held tones: each step tuned on its own, a tone held from the step before bounded about the
// pitch that step gave it (the tuner's bounded policy). The past is not retuned for the future's sake, as it could not
// be in a performance; a step no tuning can reach within the bound is infeasible, and says which step.
function realizeStepByStep(pkg,plan,{anchorWeight=REALIZATION.nominalAnchorWeight,rootAnchorWeight=REALIZATION.rootAnchorWeight,heldRetuneCents=REALIZATION.heldRetuneCents}={}){
  const period=periodCents(pkg),cents={},residuals=[],steps=[],choice={};
  let objective=0,identityResidual=0,stationarityResidual=0,binding=[];
  for(let index=0;index<plan.length;index++){
    const terms=stepTerms(pkg,plan,index,{period,anchorWeight,rootAnchorWeight});
    for(const note of heldFromBefore(plan,index)){
      const event=terms.events.find(item=>item.id===eventId(index,note.voice));
      Object.assign(event,{policy:'bounded',previousCents:cents[eventId(index-1,note.voice)],maxRetuneCents:heldRetuneCents});
    }
    const problem={events:terms.events,preferences:terms.preferences,equalities:terms.equalities,anchors:terms.anchors};
    const outcome=Object.keys(terms.alternatives).length?tuneAlternatives(problem,terms.alternatives):{status:null,result:tune(problem)};
    const result=outcome.result??null,status=outcome.status??result?.status;
    if(!result||status!=='validated')return {status:status??'invalid',step:index,outcome};
    Object.assign(cents,result.cents);residuals.push(...result.residuals);steps.push(result);
    if(outcome.choice)Object.assign(choice,outcome.choice);
    objective+=result.objective;identityResidual=Math.max(identityResidual,result.identityResidual);
    stationarityResidual=Math.max(stationarityResidual,result.stationarityResidual);binding=[...binding,...result.binding];
  }
  const result=Object.freeze({status:'validated',cents:Object.freeze(cents),residuals:Object.freeze(residuals),objective,identityResidual,stationarityResidual,
    maxPreferenceResidual:Math.max(0,...residuals.filter(item=>item.kind==='preference').map(item=>Math.abs(item.residualCents))),
    binding:Object.freeze(binding),steps:Object.freeze(steps)});
  return {status:'validated',result,...(Object.keys(choice).length?{choice:Object.freeze(choice)}:{})};
}

// A plan's absolute cents are 100 to a MIDI step, A4 at 6900.
export const hzOfCents=cents=>440*2**((cents-6900)/1200);
export const centsOfHz=hz=>6900+1200*Math.log2(hz/440);

// The package's realizations named in `ids`, applied to a tuned plan: each step whose structure one is for gains
// `realized`, from its tuned pitches (the nominal ones where it has none). A beating pair: the role's note sounded as two
// components about its pitch ({voice, role, lowCents, highCents, lowHz, highHz, beatHz, keep, model}); made after the
// tuning, it cannot be pulled to a unison by it (I06). Combination tones: the bass role's lowest note and the melody
// role's highest, and the recipe's tones from them, each with its coefficients ({bass, melody, tones: [{cents, hz,
// coefficients, index, source}], rejected}). A realization the package does not declare is refused.
export function applyRealizations(pkg,plan,ids=[]){
  const chosen=ids.map(id=>pkg.realizations.find(entry=>entry.id===id)??(()=>{throw new TypeError(`${pkg.id} declares no realization ${id}`)})());
  if(!chosen.length)return plan;
  const pitchOf=note=>Number.isFinite(note.tunedCents)?note.tunedCents:note.cents;
  return Object.freeze(plan.map(step=>{
    const realized=[],notes=step.voicing.filter(note=>Number.isFinite(note.cents));
    for(const entry of chosen.filter(item=>item.structure===step.structure)){
      if(entry.kind==='beating-pair'){
        for(const note of notes.filter(item=>item.role===entry.role)){
          const center=hzOfCents(pitchOf(note)),pair=entry.beat.hz!==undefined?beatingPair(center,entry.beat.hz):centsPair(center,entry.beat.cents);
          realized.push(Object.freeze({kind:entry.kind,id:entry.id,voice:note.voice,role:note.role,lowCents:centsOfHz(pair.lowHz),highCents:centsOfHz(pair.highHz),
            lowHz:pair.lowHz,highHz:pair.highHz,beatHz:pair.highHz-pair.lowHz,keep:pair.keep,model:pair.model}));
        }
        continue;
      }
      const bass=notes.filter(item=>item.role===entry.bass).sort((a,b)=>pitchOf(a)-pitchOf(b))[0],melody=notes.filter(item=>item.role===entry.melody).sort((a,b)=>pitchOf(b)-pitchOf(a))[0];
      if(!bass||!melody)continue;
      const colour=combinationTones(hzOfCents(pitchOf(bass)),hzOfCents(pitchOf(melody)),entry.recipe);
      realized.push(Object.freeze({kind:entry.kind,id:entry.id,recipe:colour.recipe,bass:bass.voice,melody:melody.voice,
        tones:Object.freeze(colour.tones.map(tone=>Object.freeze({...tone,cents:centsOfHz(tone.hz)}))),rejected:colour.rejected}));
    }
    return realized.length?Object.freeze({...step,realized:Object.freeze(realized)}):step;
  }));
}

// A plan's pitches: {status, plan (each note with `tunedCents`), result, tempered: [{id, residualCents}] (every
// preference missed by more than REALIZATION.temperedCents, the largest first: what the policy gave up, and how far)}.
// options: tuningProblem's, {heldRetuneCents} for the bounded policy, which is realized step by step, and
// {realizations: [ids]}, the package's realizations to apply (applyRealizations; none unless named).
export function realize(pkg,plan,options={}){
  let outcome;
  if((options.policy??REALIZATION.heldPolicy)==='bounded')outcome=realizeStepByStep(pkg,plan,options);
  else{
    const {problem,alternatives}=tuningProblem(pkg,plan,options);
    outcome=Object.keys(alternatives).length?tuneAlternatives(problem,alternatives):{status:null,result:tune(problem)};
  }
  const result=outcome.result??null,status=outcome.status??result?.status;
  if(!result||status!=='validated')return Object.freeze({status:status??'invalid',outcome});
  const tuned=applyRealizations(pkg,plan.map((step,index)=>Object.freeze({...step,voicing:Object.freeze(step.voicing.map(note=>Number.isFinite(note.cents)?
    Object.freeze({...note,tunedCents:result.cents[eventId(index,note.voice)]}):note))})),options.realizations??[]);
  const tempered=result.residuals.filter(item=>item.kind==='preference'&&Math.abs(item.residualCents)>REALIZATION.temperedCents)
    .map(item=>Object.freeze({id:item.id,residualCents:item.residualCents})).sort((a,b)=>Math.abs(b.residualCents)-Math.abs(a.residualCents));
  return Object.freeze({status:'validated',plan:Object.freeze(tuned),result,tempered:Object.freeze(tempered),...(outcome.choice?{choice:outcome.choice}:{})});
}
