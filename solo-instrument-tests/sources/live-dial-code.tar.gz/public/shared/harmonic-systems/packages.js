// Rule packages: versioned, declarative fragments of musical theory (the harmonic-systems report, §3.4-3.5 and §4).
//
// A package is data, never code. It declares who made it and what it is (and is not: a fixture is labelled a fixture,
// a catalogue name a catalogue name), the period its pitches repeat at (2:1, another ratio, or none at all: nothing
// here reduces by twelve), its degrees as exact intervals above a reference, its structures as roles on degrees (each
// required or optional), its collections, a grammar of contexts and transitions, the transformations a transition may
// use (each with the invariants it keeps), rules in a closed vocabulary with explicit scopes, role-based tuning
// alternatives, the realizations it offers (a role sounded as a beating pair, combination-tone colours of a bass and a
// melody), its resource limits, and examples a validator checks. Everything the generator and tuner do with a package
// goes through these fields, so a new package adds theory without editing a solver (T24).
//
// Validation refuses what it does not know (unknown fields, unknown rule types), what it cannot bound (sizes, depth,
// obligation horizons), and references that do not resolve, before anything uses the package (T23): a package received
// over the network or read from a file cannot run code or ask for unbounded work.
import {frozenJson,identifier,knownFields} from '../planning-data.js';
import {interval,intervalCents} from './pitch-intent.js';
import {REFLECTION_SCOPES,REGISTER_POLICIES} from '../pitch-languages/reflection.js';
import {combinationRecipe,BOUCHARA_SECTION_1} from '../pitch-languages/combination-tones.js';

// ---- Limits and vocabularies ------------------------------------------------------------------------------------
export const PACKAGE_LIMITS=Object.freeze({
  bytes:1<<18,items:1<<15,depth:12,
  degrees:128,structures:256,rolesPerStructure:16,collections:64,collectionSize:128,contexts:64,transitions:512,
  transformations:64,rules:128,tuning:256,alternativesPerRole:8,preferencesPerAlternative:8,examples:64,exampleLength:64,
  realizations:64,
  obligationHorizon:64,         // how many events a resolution may be due within
  textLength:2000,
  // What a package may ask the generator for, at most (its own `limits` may only lower these).
  candidates:4096,voicings:4096,searchNodes:65536,
});
// How near a protected symmetry's degrees must be to equal divisions of the period (a declared 12-EDO diminished
// seventh is exact; a just approximation of one is not a symmetry).
export const SYMMETRY_TOLERANCE_CENTS=.001;
// What a package is, as its author states it (§12.3, §4): an engineering fixture; a declared test profile awaiting a
// practitioner; a catalogue designation; an authored theory fragment; one a practitioner has reviewed.
export const PACKAGE_STATUS=Object.freeze(['engineering-fixture','declared-test-profile','catalogue-designation','authored','practitioner-reviewed']);
// The rule vocabulary the generator and validator understand (M2). A rule of any other type is refused, not ignored.
export const RULE_TYPES=Object.freeze(['required-roles','forbid-parallel','preserve-block','max-motion','resolve','protect-voice','range',
  'avoid-interval','hold-common-tones','max-span']);
export const TRANSFORMATION_KINDS=Object.freeze(['exact-translation','collection-translation','role-map','reflection']);
// How a structure's notes may sound beyond their tuned pitches (docs/PITCH_LANGUAGES.md): a role as a beating pair about its
// pitch, or a bass and a melody role generating combination-tone colours.
export const REALIZATION_KINDS=Object.freeze(['beating-pair','combination-tones']);
// A beating pair's limits: a beat faster than this is roughness, not a beat; an interval wider than this, not a unison.
export const BEATING_LIMITS=Object.freeze({hz:40,cents:100});

const fail=message=>{throw new TypeError(message)};
const plain=(value,label)=>{if(!value||typeof value!=='object'||Array.isArray(value))fail(`${label} must be an object`);return value};
const list=(value,label,max,min=0)=>{if(!Array.isArray(value)||value.length<min||value.length>max)fail(`${label} must be a list of ${min} to ${max}`);return value};
const text=(value,label)=>{if(typeof value!=='string'||value.length>PACKAGE_LIMITS.textLength)fail(`${label} must be text`);return value};
const ids=(value,label,max)=>{const items=list(value,label,max).map(item=>identifier(item,label));if(new Set(items).size!==items.length)fail(`${label} repeats an id`);return items};
const finite=(value,label)=>{if(typeof value!=='number'||!Number.isFinite(value)||Math.abs(value)>1e6)fail(`${label} must be a finite number`);return value};
const positive=(value,label)=>{finite(value,label);if(!(value>0))fail(`${label} must be positive`);return value};
const integer=(value,label,{min=-Infinity,max=Infinity}={})=>{if(!Number.isSafeInteger(value)||value<min||value>max)fail(`${label} must be an integer from ${min} to ${max}`);return value};
const freezeAll=value=>frozenJson(value,{bytes:PACKAGE_LIMITS.bytes,items:PACKAGE_LIMITS.items,depth:PACKAGE_LIMITS.depth}).data;

// ---- Scopes -----------------------------------------------------------------------------------------------------
// Which events a rule governs: contexts, transitions (by from and to), voices and roles. An empty scope field means
// every one of that kind; a rule with no scope at all governs the whole package. "No parallel fifths" and "keep the
// parallel block" can coexist when their scopes differ, and conflict (with an explanation) where they meet (§3.4).
function scope(value,{contexts,roles}){
  if(value===undefined)return Object.freeze({});
  plain(value,'A rule scope');knownFields(value,['contexts','transitions','voices','roles'],'rule scope');
  const out={};
  if(value.contexts!==undefined)out.contexts=ids(value.contexts,'Scope contexts',PACKAGE_LIMITS.contexts).map(id=>{if(!contexts.has(id))fail(`A scope names an unknown context ${id}`);return id});
  if(value.transitions!==undefined)out.transitions=list(value.transitions,'Scope transitions',PACKAGE_LIMITS.transitions).map(item=>{
    plain(item,'A scoped transition');knownFields(item,['from','to'],'scoped transition');
    for(const end of ['from','to'])if(!contexts.has(identifier(item[end],'transition end')))fail(`A scope names an unknown context ${item[end]}`);
    return Object.freeze({from:item.from,to:item.to});
  });
  if(value.voices!==undefined)out.voices=ids(value.voices,'Scope voices',64);
  if(value.roles!==undefined)out.roles=ids(value.roles,'Scope roles',PACKAGE_LIMITS.rolesPerStructure).map(id=>{if(!roles.has(id))fail(`A scope names an unknown role ${id}`);return id});
  return Object.freeze(out);
}

// ---- Rules ------------------------------------------------------------------------------------------------------
const RULE_FIELDS=Object.freeze({
  'required-roles':[],
  'forbid-parallel':['interval','toleranceCents'],
  'preserve-block':['transformation'],
  'max-motion':['cents'],
  'resolve':['role','direction','maxCents','within'],
  'protect-voice':['voice'],
  'range':['voice','minCents','maxCents'],
  'avoid-interval':['interval','toleranceCents','against'],
  'hold-common-tones':[],
  'max-span':['cents'],          // the lowest sounding voice to the highest, at most (close position: within a period)
});
function rule(value,known){
  plain(value,'A rule');
  const type=value.type;
  if(!RULE_TYPES.includes(type))fail(`Unknown rule type ${JSON.stringify(type)}: a rule is one of ${RULE_TYPES.join(', ')}`);
  knownFields(value,['id','type','strength','weight','scope','explanation',...RULE_FIELDS[type]],`${type} rule`);
  const id=identifier(value.id,'rule id');
  if(!['hard','soft'].includes(value.strength))fail(`Rule ${id}: its strength is hard or soft`);
  if(value.strength==='soft')positive(value.weight,`Rule ${id}'s weight`);
  else if(value.weight!==undefined)fail(`Rule ${id}: a hard rule has no weight (it is not traded)`);
  const out={id,type,strength:value.strength,...(value.weight!==undefined?{weight:value.weight}:{}),scope:scope(value.scope,known),
    ...(value.explanation!==undefined?{explanation:text(value.explanation,`Rule ${id}'s explanation`)}:{})};
  switch(type){
    case 'forbid-parallel':case 'avoid-interval':
      out.interval=interval(value.interval);
      out.toleranceCents=positive(value.toleranceCents??15,`Rule ${id}'s tolerance`);
      if(type==='avoid-interval'&&value.against!==undefined)out.against=ids(value.against,`Rule ${id}'s roles against`,PACKAGE_LIMITS.rolesPerStructure);
      break;
    case 'preserve-block':
      if(!known.transformations.has(identifier(value.transformation,'transformation id')))fail(`Rule ${id} preserves an unknown transformation ${value.transformation}`);
      out.transformation=value.transformation;break;
    case 'max-motion':out.cents=positive(value.cents,`Rule ${id}'s motion`);break;
    case 'max-span':out.cents=positive(value.cents,`Rule ${id}'s span`);break;
    case 'resolve':
      if(!known.roles.has(identifier(value.role,'resolving role')))fail(`Rule ${id} resolves an unknown role ${value.role}`);
      if(!['up','down','any'].includes(value.direction))fail(`Rule ${id}: a resolution goes up, down or any way`);
      out.role=value.role;out.direction=value.direction;out.maxCents=positive(value.maxCents,`Rule ${id}'s step`);
      out.within=integer(value.within,`Rule ${id}'s horizon`,{min:1,max:PACKAGE_LIMITS.obligationHorizon});break;
    case 'protect-voice':out.voice=identifier(value.voice,'protected voice');break;
    case 'range':
      out.voice=identifier(value.voice,'ranged voice');out.minCents=finite(value.minCents,`Rule ${id}'s low bound`);out.maxCents=finite(value.maxCents,`Rule ${id}'s high bound`);
      if(out.minCents>out.maxCents)fail(`Rule ${id}: its range is empty`);break;
  }
  return Object.freeze(out);
}

// ---- The package ------------------------------------------------------------------------------------------------
export function rulePackage(input){
  // Bounded before anything is read: size, item count, depth, plain JSON only.
  const value=freezeAll(input);
  plain(value,'A rule package');
  knownFields(value,['id','version','provenance','scope','period','referenceId','degrees','structures','collections','contexts','start',
    'transitions','transformations','rules','tuning','realizations','limits','examples'],'rule package');
  const id=identifier(value.id,'package id'),version=identifier(value.version,'package version');

  plain(value.provenance,`${id}'s provenance`);knownFields(value.provenance,['status','sources','notes','tradition','review'],'package provenance');
  if(!PACKAGE_STATUS.includes(value.provenance.status))fail(`${id}: its status is one of ${PACKAGE_STATUS.join(', ')}`);
  list(value.provenance.sources??[],`${id}'s sources`,32).forEach(source=>{plain(source,'A source');knownFields(source,['title','url','note'],'package source');text(source.title,'A source title');if(source.url!==undefined)text(source.url,'A source url');if(source.note!==undefined)text(source.note,'A source note')});
  text(value.provenance.notes??'',`${id}'s notes`);
  // A tradition is named only by acquisition, never guessed (the alternative tonal systems report §3.2): a package that
  // names one is a declared test profile (awaiting review, with its sources) or has been reviewed by a practitioner, who
  // is named with the date and the scope of the review. Reviewed means that review, and sources.
  if(value.provenance.tradition!==undefined){
    text(value.provenance.tradition,`${id}'s tradition`);
    if(!['declared-test-profile','practitioner-reviewed'].includes(value.provenance.status))fail(`${id}: a package naming a tradition is a declared test profile or practitioner-reviewed, not ${value.provenance.status}`);
    if(!(value.provenance.sources??[]).length)fail(`${id}: a package naming a tradition gives its sources`);
  }
  if(value.provenance.status==='practitioner-reviewed'){
    const review=value.provenance.review;
    plain(review,`${id}'s review`);knownFields(review,['by','date','scope','notes'],'practitioner review');
    for(const field of ['by','date','scope'])if(typeof review[field]!=='string'||!review[field].trim())fail(`${id}: a practitioner's review names ${field}`);
    if(!(value.provenance.sources??[]).length)fail(`${id}: a reviewed package gives its sources`);
  }else if(value.provenance.review!==undefined)fail(`${id}: a review belongs to a practitioner-reviewed package`);
  plain(value.scope,`${id}'s scope`);knownFields(value.scope,['description','supported','unsupported'],'package scope');
  text(value.scope.description,`${id}'s scope`);
  for(const field of ['supported','unsupported'])list(value.scope[field]??[],`${id}'s ${field} scope`,32).forEach(item=>text(item,'A scope item'));

  // The period: an interval, or null for none (a package whose pitches do not repeat).
  const period=value.period===null?null:interval(value.period);
  if(period&&!(intervalCents(period)>0))fail(`${id}: a period is a positive interval`);
  const referenceId=identifier(value.referenceId,'reference id');

  const degrees=new Map(list(value.degrees,`${id}'s degrees`,PACKAGE_LIMITS.degrees,1).map(degree=>{
    plain(degree,'A degree');knownFields(degree,['id','interval'],'degree');
    return [identifier(degree.id,'degree id'),Object.freeze({id:degree.id,interval:interval(degree.interval)})];
  }));
  if(degrees.size!==value.degrees.length)fail(`${id}: its degrees have distinct ids`);

  const roles=new Set();
  const structures=new Map(list(value.structures??[],`${id}'s structures`,PACKAGE_LIMITS.structures).map(structure=>{
    plain(structure,'A structure');knownFields(structure,['id','roles','root','bass'],'structure');
    const sid=identifier(structure.id,'structure id');
    const members=list(structure.roles,`${sid}'s roles`,PACKAGE_LIMITS.rolesPerStructure,1).map(member=>{
      plain(member,'A structure role');knownFields(member,['role','degree','required'],'structure role');
      const role=identifier(member.role,'role id');roles.add(role);
      if(!degrees.has(identifier(member.degree,'role degree')))fail(`${sid}: role ${role} is on an unknown degree ${member.degree}`);
      if(typeof member.required!=='boolean')fail(`${sid}: role ${role} says whether it is required`);
      return Object.freeze({role,degree:member.degree,required:member.required});
    });
    if(new Set(members.map(member=>member.role)).size!==members.length)fail(`${sid}: each role once`);
    // The root may be inferred and unsounded (a rootless voicing keeps it): it is named, whether or not it is required.
    for(const field of ['root','bass'])if(structure[field]!==undefined&&!members.some(member=>member.role===structure[field]))fail(`${sid}: its ${field} is not one of its roles`);
    return [sid,Object.freeze({id:sid,roles:Object.freeze(members),...(structure.root?{root:structure.root}:{}),...(structure.bass?{bass:structure.bass}:{})})];
  }));
  if(structures.size!==(value.structures??[]).length)fail(`${id}: its structures have distinct ids`);

  const collections=new Map(list(value.collections??[],`${id}'s collections`,PACKAGE_LIMITS.collections).map(collection=>{
    plain(collection,'A collection');knownFields(collection,['id','degrees'],'collection');
    const cid=identifier(collection.id,'collection id'),members=ids(collection.degrees,`${cid}'s degrees`,PACKAGE_LIMITS.collectionSize);
    members.forEach(degree=>{if(!degrees.has(degree))fail(`${cid}: unknown degree ${degree}`)});
    return [cid,Object.freeze({id:cid,degrees:Object.freeze(members)})];
  }));

  const contexts=new Map(list(value.contexts,`${id}'s contexts`,PACKAGE_LIMITS.contexts,1).map(context=>{
    plain(context,'A context');knownFields(context,['id','structures','collection'],'context');
    const cid=identifier(context.id,'context id'),members=ids(context.structures??[],`${cid}'s structures`,PACKAGE_LIMITS.structures);
    // A context holds structures (chords), a collection (a melody's material, a mode), or both.
    if(!members.length&&context.collection===undefined)fail(`${cid}: a context holds at least one structure or a collection`);
    members.forEach(structure=>{if(!structures.has(structure))fail(`${cid}: unknown structure ${structure}`)});
    if(context.collection!==undefined&&!collections.has(context.collection))fail(`${cid}: unknown collection ${context.collection}`);
    return [cid,Object.freeze({id:cid,structures:Object.freeze(members),...(context.collection?{collection:context.collection}:{})})];
  }));
  const start=ids(value.start,`${id}'s start contexts`,PACKAGE_LIMITS.contexts);
  if(!start.length)fail(`${id}: at least one start context`);
  start.forEach(context=>{if(!contexts.has(context))fail(`${id}: unknown start context ${context}`)});

  const transformations=new Map(list(value.transformations??[],`${id}'s transformations`,PACKAGE_LIMITS.transformations).map(transformation=>{
    plain(transformation,'A transformation');
    const kind=transformation.kind,tid=identifier(transformation.id,'transformation id');
    if(!TRANSFORMATION_KINDS.includes(kind))fail(`${tid}: a transformation is one of ${TRANSFORMATION_KINDS.join(', ')}`);
    if(kind==='exact-translation'){
      // Exact planing: the block moves by one interval, every internal interval kept to the cent (§4.7).
      knownFields(transformation,['id','kind','by','block','toleranceCents'],'exact translation');
      const by=transformation.by==='any'?'any':Object.freeze(list(transformation.by,`${tid}'s intervals`,32,1).map(interval));
      return [tid,Object.freeze({id:tid,kind,by,block:transformation.block==='all'?'all':Object.freeze(ids(transformation.block,`${tid}'s block`,PACKAGE_LIMITS.rolesPerStructure)),
        toleranceCents:positive(transformation.toleranceCents??1,`${tid}'s tolerance`)})];
    }
    if(kind==='collection-translation'){
      // Collection-relative planing: every voice moves the same number of steps within a collection, its degree
      // pattern kept and its acoustic intervals free to change.
      knownFields(transformation,['id','kind','collection','steps','block'],'collection translation');
      if(!collections.has(identifier(transformation.collection,'collection id')))fail(`${tid}: unknown collection ${transformation.collection}`);
      const steps=Object.freeze(list(transformation.steps,`${tid}'s steps`,16,1).map(step=>integer(step,`${tid}'s step`,{min:-64,max:64})));
      if(steps.includes(0))fail(`${tid}: a translation moves (a step of 0 is no transformation)`);
      return [tid,Object.freeze({id:tid,kind,collection:transformation.collection,steps,block:transformation.block==='all'||transformation.block===undefined?'all':Object.freeze(ids(transformation.block,`${tid}'s block`,PACKAGE_LIMITS.rolesPerStructure))})];
    }
    if(kind==='reflection'){
      // Reflection ("negative harmony", pitch-languages/reflection.js): each voice in scope mirrored about an axis, an
      // interval above the tonic (at the step's transposition): c' = 2 axis - c, an involution. The scope says which
      // voices, by where they sound (the highest is the melody, the lowest the bass): the melody, the chord between
      // them, the bass and chords, or the entire layer; the rest hold. The register policy says where the mirror goes:
      // exactly (strict-mirror: the contour inverted, a voice driven out of its range refused), its class moved by
      // whole periods into the voice's range nearest its old pitch (voice-range-revoice), or its class nearest the old
      // pitch (pitch-class-only). With C as the tonic, an axis of 350 cents makes C major C minor.
      knownFields(transformation,['id','kind','axis','scope','registerPolicy'],'reflection');
      const scope=transformation.scope??'entire-layer',registerPolicy=transformation.registerPolicy??'voice-range-revoice';
      if(!REFLECTION_SCOPES.includes(scope))fail(`${tid}: a reflection's scope is one of ${REFLECTION_SCOPES.join(', ')}`);
      if(!REGISTER_POLICIES.includes(registerPolicy))fail(`${tid}: a reflection's register policy is one of ${REGISTER_POLICIES.join(', ')}`);
      if(registerPolicy!=='strict-mirror'&&period===null)fail(`${tid}: a reflection moves classes by whole periods, and the package has none (strict-mirror only)`);
      return [tid,Object.freeze({id:tid,kind,axis:interval(transformation.axis),scope,registerPolicy})];
    }
    // A role map between two structures: each role of the first becomes a role of the second (common tones held where
    // `holds` says, the rest moved to their new degree). Its domain is exactly the structure it maps from: applying it
    // to anything else is an unsupported domain, not an invented analysis (T07).
    knownFields(transformation,['id','kind','from','to','mapping','holds'],'role map');
    for(const end of ['from','to'])if(!structures.has(identifier(transformation[end],`${tid}'s ${end}`)))fail(`${tid}: unknown structure ${transformation[end]}`);
    plain(transformation.mapping,`${tid}'s mapping`);
    const fromRoles=structures.get(transformation.from).roles.map(member=>member.role),toRoles=structures.get(transformation.to).roles.map(member=>member.role);
    const mapping=Object.fromEntries(Object.entries(transformation.mapping).map(([from,to])=>{
      if(!fromRoles.includes(from))fail(`${tid}: ${from} is not a role of ${transformation.from}`);
      if(!toRoles.includes(identifier(to,'mapped role')))fail(`${tid}: ${to} is not a role of ${transformation.to}`);
      return [from,to];
    }));
    const holds=ids(transformation.holds??[],`${tid}'s held roles`,PACKAGE_LIMITS.rolesPerStructure);
    holds.forEach(role=>{if(!(role in mapping))fail(`${tid}: it holds ${role}, which it does not map`)});
    return [tid,Object.freeze({id:tid,kind,from:transformation.from,to:transformation.to,mapping:Object.freeze(mapping),holds:Object.freeze(holds)})];
  }));

  const transitions=Object.freeze(list(value.transitions,`${id}'s transitions`,PACKAGE_LIMITS.transitions).map(transition=>{
    plain(transition,'A transition');knownFields(transition,['from','to','weight','via'],'transition');
    for(const end of ['from','to'])if(!contexts.has(identifier(transition[end],'transition end')))fail(`${id}: a transition names an unknown context ${transition[end]}`);
    if(transition.via!==undefined&&!transformations.has(transition.via))fail(`${id}: a transition uses an unknown transformation ${transition.via}`);
    return Object.freeze({from:transition.from,to:transition.to,weight:positive(transition.weight??1,'A transition\'s weight'),...(transition.via?{via:transition.via}:{})});
  }));

  const known={contexts:new Set(contexts.keys()),roles,transformations:new Set(transformations.keys())};
  const rules=Object.freeze(list(value.rules??[],`${id}'s rules`,PACKAGE_LIMITS.rules).map(item=>rule(item,known)));
  if(new Set(rules.map(item=>item.id)).size!==rules.length)fail(`${id}: its rules have distinct ids`);

  // Role-based tuning: for a structure's role, its alternatives, each a connected region (in cents about the role's
  // nominal degree) and the intervals it prefers above other roles of the chord. The region is where the role may be
  // realized and remain itself; the preferences are what the tuner weighs inside it.
  //
  // Or a structure's symmetry, protected (§4.4, §6.5): {structure, protectSymmetry: [roles]}, roles whose degrees, in
  // the order given, divide the period into equal steps. The realization keeps those steps exact and tempers whatever
  // preference contradicts them (four pure 6:5 thirds cannot close an octave: each is tempered, and the tuner's
  // residuals say by how much). The degrees are checked to be the symmetry they claim.
  const tuning=Object.freeze(list(value.tuning??[],`${id}'s tuning`,PACKAGE_LIMITS.tuning).map(entry=>{
    plain(entry,'A tuning entry');
    if(entry.protectSymmetry!==undefined){
      knownFields(entry,['structure','protectSymmetry'],'symmetry entry');
      const structure=structures.get(identifier(entry.structure,'symmetric structure'));
      if(!structure)fail(`${id}: a symmetry for an unknown structure ${entry.structure}`);
      if(period===null)fail(`${id}: ${entry.structure}'s symmetry divides a period, and the package has none`);
      const symmetric=ids(entry.protectSymmetry,`${entry.structure}'s symmetric roles`,PACKAGE_LIMITS.rolesPerStructure);
      if(symmetric.length<2)fail(`${entry.structure}: a symmetry has two roles at least`);
      const at=role=>{const member=structure.roles.find(item=>item.role===role);if(!member)fail(`${entry.structure} has no role ${role}`);return intervalCents(degrees.get(member.degree).interval)};
      const whole=intervalCents(period),step=whole/symmetric.length;
      symmetric.forEach((role,index)=>{
        const next=symmetric[(index+1)%symmetric.length],distance=(((at(next)-at(role))%whole)+whole)%whole;
        if(Math.abs(distance-step)>SYMMETRY_TOLERANCE_CENTS)fail(`${entry.structure}: ${role} to ${next} is ${distance.toFixed(3)} cents, not ${step.toFixed(3)}: not an equal division of the period`);
      });
      return Object.freeze({structure:entry.structure,protectSymmetry:Object.freeze(symmetric)});
    }
    knownFields(entry,['structure','role','alternatives'],'tuning entry');
    const structure=structures.get(identifier(entry.structure,'tuned structure'));
    if(!structure)fail(`${id}: tuning for an unknown structure ${entry.structure}`);
    if(!structure.roles.some(member=>member.role===entry.role))fail(`${id}: ${entry.structure} has no role ${entry.role}`);
    const alternatives=list(entry.alternatives,`${entry.structure}.${entry.role}'s alternatives`,PACKAGE_LIMITS.alternativesPerRole,1).map(alternative=>{
      plain(alternative,'A tuning alternative');knownFields(alternative,['id','offsetCents','prefer'],'tuning alternative');
      const [low,high]=list(alternative.offsetCents,'An offset region',2,2).map(bound=>finite(bound,'An offset bound'));
      if(low>high)fail(`${entry.structure}.${entry.role}: an empty offset region`);
      const prefer=list(alternative.prefer??[],'Preferences',PACKAGE_LIMITS.preferencesPerAlternative).map(preference=>{
        plain(preference,'A tuning preference');knownFields(preference,['above','interval','weight'],'tuning preference');
        if(!structure.roles.some(member=>member.role===preference.above))fail(`${entry.structure}: a preference above an unknown role ${preference.above}`);
        return Object.freeze({above:preference.above,interval:interval(preference.interval),weight:positive(preference.weight,'A preference weight')});
      });
      return Object.freeze({id:identifier(alternative.id,'alternative id'),offsetCents:Object.freeze([low,high]),prefer:Object.freeze(prefer)});
    });
    return Object.freeze({structure:entry.structure,role:entry.role,alternatives:Object.freeze(alternatives)});
  }));

  // Realizations (§4, §6): what a structure's notes may sound beyond their tuned pitches, chosen by whoever realizes a
  // plan (harmonic-systems/realization.js), never applied behind its back. A beating pair sounds one role as two
  // components about its tuned pitch, a fixed beat in Hz or a fixed interval in cents (pitch-languages/texture.js); the
  // pair is made from the tuned pitch, after tuning, so no tuner can collapse it to a unison (I06). Combination tones
  // sound |a f_bass + b f_melody| for a recipe's coefficient pairs, from the two roles' tuned pitches, each tone with its
  // ancestry (pitch-languages/combination-tones.js): a recipe object, or 'bouchara-section-1', the coefficients
  // Christian identifies in Vivier's Bouchara.
  const realizations=Object.freeze(list(value.realizations??[],`${id}'s realizations`,PACKAGE_LIMITS.realizations).map(entry=>{
    plain(entry,'A realization');
    const rid=identifier(entry.id,'realization id');
    if(!REALIZATION_KINDS.includes(entry.kind))fail(`${rid}: a realization is one of ${REALIZATION_KINDS.join(', ')}`);
    const structure=structures.get(identifier(entry.structure,'realized structure'));
    if(!structure)fail(`${rid}: an unknown structure ${entry.structure}`);
    const hasRole=role=>{if(!structure.roles.some(member=>member.role===identifier(role,'realized role')))fail(`${rid}: ${entry.structure} has no role ${role}`);return role};
    if(entry.kind==='beating-pair'){
      knownFields(entry,['id','kind','structure','role','beat'],'beating-pair realization');
      plain(entry.beat,`${rid}'s beat`);knownFields(entry.beat,['hz','cents'],'beat');
      if((entry.beat.hz===undefined)===(entry.beat.cents===undefined))fail(`${rid}: a beat is held in Hz or in cents, one of them`);
      const beat=entry.beat.hz!==undefined?{hz:positive(entry.beat.hz,`${rid}'s beat`)}:{cents:positive(entry.beat.cents,`${rid}'s interval`)};
      if(beat.hz>BEATING_LIMITS.hz||beat.cents>BEATING_LIMITS.cents)fail(`${rid}: a beating pair beats at most ${BEATING_LIMITS.hz} Hz or ${BEATING_LIMITS.cents} cents apart`);
      return Object.freeze({id:rid,kind:entry.kind,structure:structure.id,role:hasRole(entry.role),beat:Object.freeze(beat)});
    }
    knownFields(entry,['id','kind','structure','bass','melody','recipe'],'combination-tones realization');
    if(hasRole(entry.bass)===hasRole(entry.melody))fail(`${rid}: the bass and the melody are two roles`);
    let recipe;
    if(entry.recipe==='bouchara-section-1')recipe=BOUCHARA_SECTION_1;
    else{
      plain(entry.recipe,`${rid}'s recipe`);
      knownFields(entry.recipe,['id','coefficients','includeInputs','signPolicy','minimumHz','maximumHz','maximumTones','melodyOctave','bassOctave','mergeCoincident'],'combination recipe');
      try{recipe=combinationRecipe({...entry.recipe,id:identifier(entry.recipe.id,'recipe id')})}catch(error){fail(`${rid}: ${error.message}`)}
    }
    return Object.freeze({id:rid,kind:entry.kind,structure:structure.id,bass:entry.bass,melody:entry.melody,recipe});
  }));
  if(new Set(realizations.map(entry=>entry.id)).size!==realizations.length)fail(`${id}: its realizations have distinct ids`);

  plain(value.limits??{},`${id}'s limits`);knownFields(value.limits??{},['candidates','voicings','searchNodes'],'package limits');
  const limits=Object.freeze(Object.fromEntries(['candidates','voicings','searchNodes'].map(key=>[key,integer(value.limits?.[key]??PACKAGE_LIMITS[key],`${id}'s ${key} limit`,{min:1,max:PACKAGE_LIMITS[key]})])));

  plain(value.examples??{},`${id}'s examples`);knownFields(value.examples??{},['positive','negative'],'package examples');
  const examples=Object.freeze(Object.fromEntries(['positive','negative'].map(kind=>[kind,Object.freeze(list(value.examples?.[kind]??[],`${id}'s ${kind} examples`,PACKAGE_LIMITS.examples).map(example=>{
    plain(example,'An example');knownFields(example,['contexts','note'],'example');
    const sequence=list(example.contexts,'An example\'s contexts',PACKAGE_LIMITS.exampleLength,1).map(context=>{if(!contexts.has(identifier(context,'example context')))fail(`${id}: an example names an unknown context ${context}`);return context});
    return Object.freeze({contexts:Object.freeze(sequence),...(example.note!==undefined?{note:text(example.note,'An example note')}:{})});
  }))])));

  const pkg=Object.freeze({id,version,provenance:value.provenance,scope:value.scope,period,referenceId,
    degrees:Object.freeze([...degrees.values()]),structures:Object.freeze([...structures.values()]),collections:Object.freeze([...collections.values()]),
    contexts:Object.freeze([...contexts.values()]),start:Object.freeze(start),transitions,transformations:Object.freeze([...transformations.values()]),
    rules,tuning,realizations,limits,examples});
  // Its own examples must hold: a package that contradicts its examples is refused, not loaded.
  for(const example of examples.positive){const result=grammarAccepts(pkg,example.contexts);if(!result.ok)fail(`${id}: its positive example ${example.contexts.join(' > ')} is rejected (${result.failures[0].reason})`)}
  for(const example of examples.negative){if(grammarAccepts(pkg,example.contexts).ok)fail(`${id}: its negative example ${example.contexts.join(' > ')} is accepted`)}
  return pkg;
}

// ---- What follows from a package ---------------------------------------------------------------------------------
export const periodCents=pkg=>pkg.period?intervalCents(pkg.period):null;
export const degreeOf=(pkg,id)=>pkg.degrees.find(degree=>degree.id===id)??fail(`${pkg.id} has no degree ${id}`);
export const degreeCents=(pkg,id)=>intervalCents(degreeOf(pkg,id).interval);
export const structureOf=(pkg,id)=>pkg.structures.find(structure=>structure.id===id)??fail(`${pkg.id} has no structure ${id}`);
export const contextOf=(pkg,id)=>pkg.contexts.find(context=>context.id===id)??fail(`${pkg.id} has no context ${id}`);
export const transformationOf=(pkg,id)=>pkg.transformations.find(item=>item.id===id)??fail(`${pkg.id} has no transformation ${id}`);
// A structure's roles at their nominal pitches, in cents above the reference (period by period where `periods` says).
export function nominalStructure(pkg,id,{referenceCents=0}={}){
  return structureOf(pkg,id).roles.map(member=>Object.freeze({...member,cents:referenceCents+degreeCents(pkg,member.degree)}));
}
// The transitions leaving a context.
export const transitionsFrom=(pkg,context)=>pkg.transitions.filter(transition=>transition.from===context);
// Whether a sequence of contexts is one the grammar allows: it begins at a start context and every step is a declared
// transition. Failures say where and why.
export function grammarAccepts(pkg,sequence){
  const failures=[];
  if(!pkg.start.includes(sequence[0]))failures.push({at:0,reason:`${sequence[0]} is not a start context`});
  for(let index=1;index<sequence.length;index++)
    if(!pkg.transitions.some(transition=>transition.from===sequence[index-1]&&transition.to===sequence[index]))
      failures.push({at:index,from:sequence[index-1],to:sequence[index],reason:`no transition from ${sequence[index-1]} to ${sequence[index]}`});
  return {ok:!failures.length,failures};
}
// A rule applies to an event when every scope field it has holds: its context, its transition, its voice, its role. An
// empty field means every one, as the scopes above say (an empty list had matched none: the mathematical audit's H12).
export function ruleApplies(rule,{context=null,transition=null,voice=null,role=null}={}){
  const s=rule.scope;
  if(s.contexts?.length&&!(context&&s.contexts.includes(context)))return false;
  if(s.transitions?.length&&!(transition&&s.transitions.some(item=>item.from===transition.from&&item.to===transition.to)))return false;
  if(s.voices?.length&&voice!==null&&!s.voices.includes(voice))return false;
  if(s.roles?.length&&role!==null&&!s.roles.includes(role))return false;
  return true;
}
