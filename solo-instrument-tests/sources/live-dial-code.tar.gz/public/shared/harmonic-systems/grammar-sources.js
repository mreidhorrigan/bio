// Rows and motive graphs as grammar sources (docs/PITCH_LANGUAGES.md; the alternative tonal systems report §9.2, §9.5; tests
// P12, P14): a serial row or a motive graph compiled into a rule package, plain data that packages.js validates and the
// generator plans from as it plans from any other (T24: nothing in the solver knows a row or a motive).
//
// A row's forms are partitioned into segments, each segment a chord whose roles are the row positions it holds (pos0 is
// the prime's first member), and the segments follow in order, form after form, back to the first: a plan generated from
// it sounds the row's order as a succession of chords, and each note's role names its position in the prime (P12). A
// motive graph's nodes are chords of their motives' classes, each class a role named for its first index in the motive
// (n0, n1, ...), and the transitions are its derivations (each node to those derived from it) and its phrase (each node
// to the next): each note's context is its node, whose derivation goes with it (P14).
//
// Every context may begin a plan (the first listed is where a performance begins): a plan is a window of the grammar, and
// the next one carries on where the last left off. Each compiler gives {package, source}: the validated package, and what
// its contexts and roles stand for (a context's form and segment, a node's operator and ancestry), which a player
// carries into its notes.
import {rulePackage} from './packages.js';
import {intervalCents} from './pitch-intent.js';
import {rowDefinition,rowForm,partitionRow,ROW_OPERATIONS} from '../pitch-languages/rows.js';
import {ancestry} from '../pitch-languages/motives.js';

const fail=message=>{throw new RangeError(message)};
const mod=(x,n)=>((x%n)+n)%n;
export const OCTAVE=Object.freeze({kind:'ratio',numerator:'2',denominator:'1'});
// The N classes of a period as degrees, equal steps of it (a row's domain: 12 of 2:1, 31 of 2:1, 13 of 3:1).
const degreesOf=(classes,steps,period)=>{const whole=intervalCents(period);return classes.map(k=>({id:`d${k}`,interval:{kind:'cents',value:whole*k/steps}}))};
// A form's name: an operation and a transposition, P0, I5, R3, RI7.
export function parseForm(name){
  const match=/^(RI|P|I|R)(\d+)$/.exec(String(name));
  if(!match||!ROW_OPERATIONS.includes(match[1]))fail(`A form is named by an operation (${ROW_OPERATIONS.join(', ')}) and a transposition, as P0 or RI7: not ${name}`);
  return {operation:match[1],transposition:Number(match[2])};
}

// A row as a package. options: {row (its classes), steps (the domain's size, the row's length by default), complete
// (every class once: true), period (an interval, 2:1 by default), forms (names, ['P0']), partition (contiguous lengths,
// [3, 3, 3, 3] by default for twelve; the whole row as one segment otherwise), id, version, provenance}.
export function rowPackage({row,steps=row?.length,complete=true,period=OCTAVE,forms=['P0'],partition=null,id='row',version='1',provenance=null}={}){
  const definition=rowDefinition(row,{steps,id,complete});
  if(!Array.isArray(forms)||!forms.length||forms.length>16)fail('A row package has 1 to 16 forms');
  const parts=partition??(definition.classes.length===12?[3,3,3,3]:[definition.classes.length]);
  const statements=forms.map(name=>{
    const form=rowForm(definition,parseForm(name));
    return {name:form.label,form,segments:partitionRow(form,parts)};
  });
  if(new Set(statements.map(item=>item.name)).size!==statements.length)fail('A row package names each form once');
  const contextId=(form,segment)=>`${form}.s${segment}`,contexts={},structures=[],transitions=[];
  statements.forEach(({name,segments},f)=>segments.forEach((segment,s)=>{
    const cid=contextId(name,s);
    structures.push({id:cid,roles:segment.positions.map((position,k)=>({role:`pos${position}`,degree:`d${segment.classes[k]}`,required:true}))});
    contexts[cid]={form:name,segment:s,positions:segment.positions,classes:segment.classes};
    const next=s+1<segments.length?contextId(name,s+1):contextId(statements[(f+1)%statements.length].name,0);
    transitions.push({from:cid,to:next});
  }));
  const pkg=rulePackage({id,version,
    provenance:provenance??{status:'authored',notes:`Compiled from the row ${definition.classes.join(' ')} of ${steps} classes by grammar-sources.js: its order as chords, not a style.`},
    scope:{description:`The row ${definition.classes.join(' ')} (${steps} classes of its period), in the forms ${statements.map(item=>item.name).join(', ')}, partitioned ${parts.join('+')}.`,
      supported:['the row\'s order as a succession of segment chords','each note\'s row position'],unsupported:['rhythm','register choices beyond the voices\' ranges','free reordering within a segment\'s melody']},
    period,referenceId:'tonic',degrees:degreesOf([...Array(steps).keys()],steps,period),
    structures,contexts:Object.keys(contexts).map(cid=>({id:cid,structures:[cid]})),start:Object.keys(contexts),transitions,
    rules:[{id:'row-positions',type:'required-roles',strength:'hard',explanation:'Every position of a segment sounds: no row member is lost.'}],
    examples:{positive:[{contexts:[contextId(statements[0].name,0),transitions[0].to]}]}});
  return Object.freeze({package:pkg,source:Object.freeze({kind:'row',row:definition,forms:Object.freeze(statements.map(item=>item.name)),partition:Object.freeze([...parts]),contexts:Object.freeze(contexts)})});
}

// A motive graph as a package. options: {graph (motives.js), phrase (node ids in order; every node by default), steps
// (the motives' domain, their own by default), period (2:1), id, version, provenance}.
export function motivePackage({graph,phrase=graph?.nodes?.map(node=>node.id),steps=graph?.nodes?.[0]?.motive.steps??12,period=OCTAVE,id='motives',version='1',provenance=null}={}){
  if(!graph?.nodes?.length)fail('A motive package needs a graph with nodes');
  if(!Array.isArray(phrase)||!phrase.length)fail('A motive package needs a phrase of node ids');
  const nodes=new Map(graph.nodes.map(node=>[node.id,node]));
  phrase.forEach(nid=>{if(!nodes.has(nid))fail(`The phrase names no node ${nid}`)});
  const used=new Set,contexts={},structures=[],edges=new Map;
  for(const node of graph.nodes){
    if(node.motive.steps!==steps)fail(`${node.id} is in ${node.motive.steps} steps, the package in ${steps}`);
    // Each class once, as the role of its first index; every index says which role sounds it.
    const roleOf=new Map,rolesByIndex=node.motive.pitches.map((pitch,index)=>{const k=mod(pitch,steps);if(!roleOf.has(k))roleOf.set(k,`n${index}`);used.add(k);return roleOf.get(k)});
    structures.push({id:node.id,roles:[...roleOf].map(([k,role])=>({role,degree:`d${k}`,required:true}))});
    contexts[node.id]={node:node.id,op:node.op,args:node.args,parents:node.parents,ancestry:ancestry(graph,node.id),classes:[...roleOf.keys()],rolesByIndex};
    for(const parent of node.parents)edges.set(`${parent}>${node.id}`,{from:parent,to:node.id});
  }
  phrase.forEach((nid,index)=>{if(index)edges.set(`${phrase[index-1]}>${nid}`,{from:phrase[index-1],to:nid})});
  const classes=[...used].sort((a,b)=>a-b);
  const pkg=rulePackage({id,version,
    provenance:provenance??{status:'authored',notes:'Compiled from a motive graph by grammar-sources.js: its cells as chords, its derivations and phrase as transitions.'},
    scope:{description:`A motive graph of ${graph.nodes.length} nodes (${steps} classes of its period), its phrase ${phrase.join(' ')}.`,
      supported:['each cell as a chord','derivations and the phrase as transitions','each note\'s node and derivation'],unsupported:['the motives\' rhythms and registers as melody']},
    period,referenceId:'tonic',degrees:degreesOf(classes,steps,period),
    structures,contexts:graph.nodes.map(node=>({id:node.id,structures:[node.id]})),start:[phrase[0],...graph.nodes.map(node=>node.id).filter(nid=>nid!==phrase[0])],transitions:[...edges.values()],
    rules:[{id:'motive-classes',type:'required-roles',strength:'hard',explanation:'Every class of a cell sounds: the cell is kept whole.'}],
    examples:{positive:[{contexts:phrase.slice(0,Math.min(phrase.length,8))}]}});
  return Object.freeze({package:pkg,source:Object.freeze({kind:'motive',graph,phrase:Object.freeze([...phrase]),contexts:Object.freeze(contexts)})});
}

// What a note of a plan step stands for in its source: a row member's form, segment and position, or a motive note's
// node, the indices its class sounds and its derivation. For notes.jsonl (pitchLanguage).
export function noteSource(source,step,note){
  const context=source.contexts[step.context];
  if(!context||!note.role)return null;
  if(source.kind==='row')return Object.freeze({row:source.row.id,form:context.form,segment:context.segment,position:Number(note.role.slice(3))});
  return Object.freeze({motive:context.node,op:context.op,indices:Object.freeze(context.rolesByIndex.flatMap((role,index)=>role===note.role?[index]:[])),
    derivation:Object.freeze(context.ancestry.map(entry=>`${entry.op}:${entry.id}`))});
}
