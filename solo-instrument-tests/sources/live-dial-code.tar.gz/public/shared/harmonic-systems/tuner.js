// The fixed-choice tuner (the harmonic-systems report, §6.2-6.6): once the generator has chosen the chords, their
// voicings and the tuning alternative of each role, the pitch of every note in cents, by weighted least squares.
//
//   E(x) = Σ w (x_to - x_from - d)²    interval preferences (d = 1200 log2 r, in the register intended)
//        + Σ u (x - h)²                 anchors: a note held toward its nominal pitch, a tonic toward its reference
//        + Σ v (x - t)²                 continuity: a note held toward where it was
//
// subject to exact equalities (x_to - x_from = c: a symmetry kept, a common tone held), fixed notes (frozen, external,
// authored: eliminated from the variables, never weighted "very heavily"), and bounds (each note inside its region,
// a bounded retune within its limit). Every exact equality joins notes into a group that moves as one; a cycle of
// equalities that does not close is a conflict, reported with its size, not rounded away (T05: four pure 6:5 thirds
// against an octave miss by 62.565 cents). The objective is solved by Cholesky factorization of the normal equations
// (no inverse), bounds by a primal active-set method, which ends in finitely many steps on a convex problem. Every
// connected part of the problem must be anchored or explicitly gauge-fixed (T14): pairwise intervals alone say
// nothing about absolute pitch.
//
// It returns the pitches with every residual (each preference's miss, each equality's and bound's, which are zero
// within tolerance on a validated result), the bounds that bind, and the gauge it used. Disjoint admissible regions
// are discrete alternatives (tuneAlternatives), each solved inside one region: the gap between them is never used
// (T11).

// ---- Choices ---------------------------------------------------------------------------------------------------
export const TUNER=Object.freeze({
  toleranceCents:1e-6,       // an equality or bound holds within this
  activeSetIterations:200,   // at most, before the tuner says it did not converge
  alternativeCombinations:256,
  gauge:'require-anchor',    // or 'fix-first': a part with no anchor fixed at its first note's nominal, and reported
});
export const SUSTAIN_POLICIES=Object.freeze(['frozen','rearticulate','bounded','authored-morph','external']);

const fail=message=>{throw new TypeError(message)};
const finiteNumber=(value,label)=>{if(typeof value!=='number'||!Number.isFinite(value))fail(`${label} must be finite`);return value};

// ---- Linear algebra: Cholesky, for a symmetric positive definite matrix ------------------------------------------
// A pivot is refused when it is not positive against its own diagonal (relative, so the same at any scale of the
// weights: an absolute 1e-12 refused a problem whose every weight was 1e-12, the mathematical audit's H02).
export function cholesky(matrix){
  const n=matrix.length,L=Array.from({length:n},()=>new Float64Array(n));
  for(let i=0;i<n;i++)for(let j=0;j<=i;j++){
    let sum=matrix[i][j];
    for(let k=0;k<j;k++)sum-=L[i][k]*L[j][k];
    if(i===j){if(!(sum>1e-12*matrix[i][i]))return null;L[i][i]=Math.sqrt(sum)}
    else L[i][j]=sum/L[j][j];
  }
  return L;
}
export function choleskySolve(L,b){
  const n=b.length,y=new Float64Array(n),x=new Float64Array(n);
  for(let i=0;i<n;i++){let sum=b[i];for(let k=0;k<i;k++)sum-=L[i][k]*y[k];y[i]=sum/L[i][i]}
  for(let i=n-1;i>=0;i--){let sum=y[i];for(let k=i+1;k<n;k++)sum-=L[k][i]*x[k];x[i]=sum/L[i][i]}
  return x;
}

// ---- The problem ------------------------------------------------------------------------------------------------
// problem: {
//   events: [{id, nominalCents, region?: [lowCents, highCents], policy?: one of SUSTAIN_POLICIES or 'free',
//     fixedCents? (frozen, rearticulate and external at their sounding pitch; an authored morph at its curve's value),
//     previousCents?, maxRetuneCents? (bounded: within this of previousCents)}],
//   preferences: [{id, from, to, targetCents, weight}],   // x_to - x_from wants targetCents
//   equalities: [{id, from, to, cents}],                 // x_to - x_from is exactly cents
//   anchors: [{id, event, targetCents, weight}],
//   continuity: [{id, event, targetCents, weight}],
// }
export function tune(problem,{gauge=TUNER.gauge}={}){
  let prepared;
  try{prepared=prepare(problem)}catch(error){return Object.freeze({status:'invalid',detail:String(error.message)})}
  const {events,index,preferences,equalities,anchors,continuity}=prepared;

  // Exact equalities and fixed notes join notes into groups: x = x_group + offset. A cycle that does not close, or two
  // fixed notes an equality cannot reconcile, is a conflict.
  // x_i = x_root + (the offsets along i's path to its root).
  const parent=events.map((_,i)=>i),treeSize=events.map(()=>1),offset=new Float64Array(events.length),conflicts=[];
  const findWithOffset=i=>{let root=i,total=0;const path=[];while(parent[root]!==root){path.push(root);root=parent[root]}for(let k=path.length-1;k>=0;k--){const node=path[k];total+=offset[node];parent[node]=root;offset[node]=total;}return {root,offset:total}};
  for(const equality of equalities){
    const a=findWithOffset(index.get(equality.from)),b=findWithOffset(index.get(equality.to));
    // x_to = x_from + cents  =>  x_rootB + offB = x_rootA + offA + cents
    if(a.root===b.root){
      // What the other exact intervals already make of this one, against what it says.
      const miss=b.offset-a.offset-equality.cents;
      if(Math.abs(miss)>TUNER.toleranceCents)conflicts.push({kind:'equality-cycle',id:equality.id,missCents:miss,
        detail:`the exact intervals closing through ${equality.id} make ${(b.offset-a.offset).toFixed(6)} cents where it says ${equality.cents.toFixed(6)}: they miss by ${miss.toFixed(6)} cents and cannot all hold`});
      continue;
    }
    const difference=a.offset+equality.cents-b.offset;
    if(treeSize[a.root]>=treeSize[b.root]){parent[b.root]=a.root;offset[b.root]=difference;treeSize[a.root]+=treeSize[b.root];}
    else {parent[a.root]=b.root;offset[a.root]=-difference;treeSize[b.root]+=treeSize[a.root];}
  }
  const groupOf=events.map((_,i)=>findWithOffset(i));
  // Fixed notes pin their group; two fixed notes in one group must agree.
  const pinned=new Map;
  events.forEach((event,i)=>{
    if(event.fixedCents===undefined)return;
    const {root,offset:off}=groupOf[i],value=event.fixedCents-off;
    if(pinned.has(root)&&Math.abs(pinned.get(root).value-value)>TUNER.toleranceCents)
      conflicts.push({kind:'fixed-conflict',events:[pinned.get(root).event,event.id],missCents:value-pinned.get(root).value,
        detail:`${pinned.get(root).event} and ${event.id} are both fixed, and the exact intervals between them disagree by ${(value-pinned.get(root).value).toFixed(6)} cents`});
    else if(!pinned.has(root))pinned.set(root,{value,event:event.id});
  });
  if(conflicts.length)return Object.freeze({status:'infeasible',conflicts:Object.freeze(conflicts.map(Object.freeze))});

  // Variables: one per free group.
  const roots=[...new Set(groupOf.map(item=>item.root))],free=roots.filter(root=>!pinned.has(root)),column=new Map(free.map((root,k)=>[root,k]));
  // A group's bounds: every member's region and retune limit, moved by its offset.
  const lower=new Float64Array(free.length).fill(-Infinity),upper=new Float64Array(free.length).fill(Infinity);
  events.forEach((event,i)=>{
    const {root,offset:off}=groupOf[i],[low,high]=event.bounds;
    if(pinned.has(root)){
      const value=pinned.get(root).value+off;
      if(value<low-TUNER.toleranceCents||value>high+TUNER.toleranceCents)
        conflicts.push({kind:'fixed-outside-region',events:[event.id],detail:`${event.id} is fixed at ${value.toFixed(3)} cents, outside its region ${low.toFixed(3)}..${high.toFixed(3)}`});
      return;
    }
    const k=column.get(root);lower[k]=Math.max(lower[k],low-off);upper[k]=Math.min(upper[k],high-off);
  });
  free.forEach((root,k)=>{if(lower[k]>upper[k]+TUNER.toleranceCents)conflicts.push({kind:'empty-region',group:events[root].id,
    detail:`the regions of the notes held together with ${events[root].id} do not overlap (${lower[k].toFixed(3)} > ${upper[k].toFixed(3)})`})});
  if(conflicts.length)return Object.freeze({status:'infeasible',conflicts:Object.freeze(conflicts.map(Object.freeze))});

  // The objective in the group variables: ½ y'Py + q'y. A row (x_to - x_from - d) becomes (y_B + offB - y_A - offA - d).
  const n=free.length,P=Array.from({length:n},()=>new Float64Array(n)),q=new Float64Array(n),anchoring=new Uint8Array(n);
  const term=(coefficients,constant,weight)=>{
    // weight * (Σ c_k y_k + constant)²  ->  P += 2w c c',  q += 2w c constant
    for(const [a,ca] of coefficients){q[a]+=2*weight*ca*constant;for(const [b,cb] of coefficients)P[a][b]+=2*weight*ca*cb}
    // A term that changes when every note of its part moves together (an anchor, a continuity term, an interval to a
    // fixed note) fixes the part's absolute pitch. That is a fact about the term's shape, not about its weight.
    if(coefficients.reduce((sum,[,c])=>sum+c,0)!==0)for(const [k] of coefficients)anchoring[k]=1;
  };
  const expression=(eventIndex,sign)=>{
    const {root,offset:off}=groupOf[eventIndex];
    return pinned.has(root)?{coefficients:[],constant:sign*(pinned.get(root).value+off)}:{coefficients:[[column.get(root),sign]],constant:sign*off};
  };
  const combine=(...parts)=>{
    const map=new Map;let constant=0;
    for(const part of parts){constant+=part.constant;for(const [k,c] of part.coefficients)map.set(k,(map.get(k)??0)+c)}
    return {coefficients:[...map].filter(([,c])=>c!==0),constant};
  };
  for(const pref of preferences){
    const row=combine(expression(index.get(pref.to),1),expression(index.get(pref.from),-1),{coefficients:[],constant:-pref.targetCents});
    if(row.coefficients.length)term(row.coefficients,row.constant,pref.weight);
  }
  for(const anchor of [...anchors,...continuity]){
    const row=combine(expression(index.get(anchor.event),1),{coefficients:[],constant:-anchor.targetCents});
    if(row.coefficients.length)term(row.coefficients,row.constant,anchor.weight);
  }

  // Gauge: a connected part whose objective is unchanged when all its notes move together (only differences within it
  // are weighed: no anchor, no fixed note, no continuity) has no absolute pitch at all (T14). A note pinned exactly (a
  // region of zero width) also fixes it. Known from the terms' shapes: the row sums of P, compared with a tolerance,
  // called one note anchored with a weight of 1e-12 unanchored, though its answer is the one a weight of 1 gives.
  const gaugeFixed=[];
  for(const part of connectedParts(n,P)){
    const anchored=part.some(k=>anchoring[k]);
    const pinnedExactly=part.some(k=>Number.isFinite(lower[k])&&Number.isFinite(upper[k])&&upper[k]-lower[k]<=TUNER.toleranceCents);
    if(anchored||pinnedExactly)continue;
    const first=part[0],member=events.findIndex((_,i)=>groupOf[i].root===free[first]);
    if(gauge!=='fix-first')return Object.freeze({status:'invalid',detail:`the part of the problem holding ${events[member].id} has no anchor and no fixed note: its absolute pitch is undetermined (T14). Anchor it, or ask for gauge 'fix-first'.`});
    // Fix its first note exactly at its nominal pitch (not pulled toward it: a pull would trade against the intervals),
    // and say so.
    const value=events[member].nominalCents-groupOf[member].offset;
    lower[first]=upper[first]=value;gaugeFixed.push(Object.freeze({event:events[member].id,cents:events[member].nominalCents}));
  }

  // Box-constrained minimization by a primal active set, from a feasible start, centred on each group's nominal pitch
  // so the arithmetic works on small numbers in any register (y = centre + z; the objective's q becomes q + P centre).
  const centre=Float64Array.from(free,root=>events[root].nominalCents);
  const qc=Float64Array.from(q,(value,k)=>{let sum=value;for(let j=0;j<n;j++)sum+=P[k][j]*centre[j];return sum});
  const solved=activeSet(P,qc,Float64Array.from(lower,(value,k)=>value-centre[k]),Float64Array.from(upper,(value,k)=>value-centre[k]));
  if(!solved)return Object.freeze({status:'invalid',detail:'the tuning problem is singular or did not converge'});
  // Feasible is not optimal: the stationarity residual, in cents (each gradient over its curvature: how far that group
  // would move if released), zero within tolerance where the answer is the problem's minimum, a bound's multiplier of
  // the wrong sign included (the KKT conditions of this convex problem).
  let stationarityResidual=0;
  for(let k=0;k<n;k++){
    const bound=solved.atBound[k],curvature=P[k][k];
    if(bound==='fixed'||!(curvature>0))continue;
    let gradient=qc[k];for(let j=0;j<n;j++)gradient+=P[k][j]*solved.y[j];
    const miss=bound==='lower'?Math.max(0,-gradient):bound==='upper'?Math.max(0,gradient):Math.abs(gradient);
    stationarityResidual=Math.max(stationarityResidual,miss/curvature);
  }

  // Back to notes, with every residual.
  const cents=Object.fromEntries(events.map((event,i)=>{
    const {root,offset:off}=groupOf[i];
    return [event.id,(pinned.has(root)?pinned.get(root).value:centre[column.get(root)]+solved.y[column.get(root)])+off];
  }));
  const residuals=[
    ...preferences.map(pref=>({id:pref.id,kind:'preference',targetCents:pref.targetCents,achievedCents:cents[pref.to]-cents[pref.from],weight:pref.weight})),
    ...equalities.map(eq=>({id:eq.id,kind:'equality',targetCents:eq.cents,achievedCents:cents[eq.to]-cents[eq.from]})),
    ...anchors.map(anchor=>({id:anchor.id,kind:'anchor',targetCents:anchor.targetCents,achievedCents:cents[anchor.event],weight:anchor.weight})),
    ...continuity.map(item=>({id:item.id,kind:'continuity',targetCents:item.targetCents,achievedCents:cents[item.event],weight:item.weight})),
  ].map(item=>Object.freeze({...item,residualCents:item.achievedCents-item.targetCents}));
  const boundResidual=Math.max(0,...events.map(event=>Math.max(event.bounds[0]-cents[event.id],cents[event.id]-event.bounds[1])));
  const identityResidual=Math.max(boundResidual,...residuals.filter(item=>item.kind==='equality').map(item=>Math.abs(item.residualCents)));
  const binding=events.filter(event=>Math.abs(cents[event.id]-event.bounds[0])<=1e-6||Math.abs(cents[event.id]-event.bounds[1])<=1e-6)
    .filter(event=>Number.isFinite(event.bounds[0])||Number.isFinite(event.bounds[1])).map(event=>event.id);
  const objective=residuals.reduce((sum,item)=>sum+(item.weight??0)*item.residualCents**2,0);
  return Object.freeze({status:identityResidual<=TUNER.toleranceCents*10&&stationarityResidual<=TUNER.toleranceCents*10?'validated':'invalid',
    cents:Object.freeze(cents),residuals:Object.freeze(residuals),
    maxPreferenceResidual:Math.max(0,...residuals.filter(item=>item.kind==='preference').map(item=>Math.abs(item.residualCents))),
    identityResidual,stationarityResidual,objectiveGap:boxObjectiveGap(P,qc,lower,upper,centre,solved.y,objective),binding:Object.freeze(binding),gaugeFixed:Object.freeze(gaugeFixed),objective,iterations:solved.iterations});
}

// The connected parts of the variables through the objective's couplings.
function connectedParts(n,P){
  const seen=new Array(n).fill(false),parts=[];
  for(let start=0;start<n;start++){
    if(seen[start])continue;
    const part=[],stack=[start];seen[start]=true;
    while(stack.length){const k=stack.pop();part.push(k);for(let j=0;j<n;j++)if(!seen[j]&&P[k][j]!==0){seen[j]=true;stack.push(j)}}
    parts.push(part.sort((a,b)=>a-b));
  }
  return parts;
}

// Minimize ½ y'Py + q'y with lower <= y <= upper (P symmetric positive definite on the free variables), by a primal
// active-set method: solve on the free set by Cholesky, step toward the solution until a bound blocks, fix it; when the
// solution is interior, release the bound whose multiplier has the wrong sign; stop when none does.
export function activeSet(P,q,lower,upper){
  const n=q.length,y=new Float64Array(n),atBound=new Array(n).fill(null);
  for(let k=0;k<n;k++){y[k]=Math.min(upper[k],Math.max(lower[k],0));if(Number.isFinite(lower[k])&&Number.isFinite(upper[k])&&upper[k]-lower[k]<=TUNER.toleranceCents){y[k]=lower[k];atBound[k]='fixed'}}
  // A start inside the bounds: the midpoint of a bounded variable, else its clamp of 0.
  for(let k=0;k<n;k++)if(atBound[k]===null&&Number.isFinite(lower[k])&&Number.isFinite(upper[k]))y[k]=(lower[k]+upper[k])/2;
  for(let iteration=1;iteration<=TUNER.activeSetIterations;iteration++){
    const freeSet=[...Array(n).keys()].filter(k=>atBound[k]===null);
    let target=y;
    if(freeSet.length){
      // Solve for the free variables with the bound ones held, equilibrated (each row and column divided by the square
      // root of its diagonal), so that the factorization sees the same system at any scale of the weights.
      const scale=freeSet.map(i=>Math.sqrt(P[i][i]));
      if(scale.some(value=>!(value>0)))return null;
      const A=freeSet.map((i,r)=>Float64Array.from(freeSet,(j,c)=>P[i][j]/(scale[r]*scale[c]))),
        b=Float64Array.from(freeSet,(i,r)=>{let value=-q[i];for(let j=0;j<n;j++)if(atBound[j]!==null)value-=P[i][j]*y[j];return value/scale[r]});
      const L=cholesky(A);
      if(!L)return null;
      const solution=choleskySolve(L,b);
      target=Float64Array.from(y);freeSet.forEach((k,index)=>{target[k]=solution[index]/scale[index]});
    }
    // Step toward it until a bound blocks.
    let alpha=1,blocking=null;
    for(const k of freeSet){
      const step=target[k]-y[k];
      if(step<0&&Number.isFinite(lower[k])&&target[k]<lower[k]-TUNER.toleranceCents){const a=(lower[k]-y[k])/step;if(a<alpha){alpha=a;blocking={k,side:'lower'}}}
      if(step>0&&Number.isFinite(upper[k])&&target[k]>upper[k]+TUNER.toleranceCents){const a=(upper[k]-y[k])/step;if(a<alpha){alpha=a;blocking={k,side:'upper'}}}
    }
    for(const k of freeSet)y[k]+=Math.max(0,alpha)*(target[k]-y[k]);
    if(blocking){y[blocking.k]=blocking.side==='lower'?lower[blocking.k]:upper[blocking.k];atBound[blocking.k]=blocking.side;continue}
    // Interior on the free set: check the bound variables' multipliers (the gradient's sign at their bound), each in
    // cents (the gradient over its curvature: how far the variable would move if released), so the test against a
    // tolerance in cents holds at any scale of the weights; the raw gradient carried the weights' units.
    let release=null,worst=TUNER.toleranceCents;
    for(let k=0;k<n;k++){
      if(atBound[k]===null||atBound[k]==='fixed'||!(P[k][k]>0))continue;
      let gradient=q[k];for(let j=0;j<n;j++)gradient+=P[k][j]*y[j];
      const wrong=(atBound[k]==='lower'?-gradient:gradient)/P[k][k];   // at a lower bound the gradient must be >= 0, at an upper <= 0
      if(wrong>worst){worst=wrong;release=k}
    }
    if(release===null)return {y,iterations:iteration,atBound:[...atBound]};
    atBound[release]=null;
  }
  return null;
}

// ---- Validation of a problem ---------------------------------------------------------------------------------------
function prepare(problem){
  if(!problem||typeof problem!=='object')fail('A tuning problem is an object');
  const events=(problem.events??[]).map((event,i)=>{
    if(typeof event.id!=='string'||!event.id)fail(`Event ${i} needs an id`);
    const nominalCents=finiteNumber(event.nominalCents,`${event.id}'s nominal pitch`),policy=event.policy??'free';
    if(policy!=='free'&&!SUSTAIN_POLICIES.includes(policy))fail(`${event.id}: a policy is free or one of ${SUSTAIN_POLICIES.join(', ')}`);
    let [low,high]=event.region??[-Infinity,Infinity];
    if(event.region){finiteNumber(low,`${event.id}'s region`);finiteNumber(high,`${event.id}'s region`);if(low>high)fail(`${event.id}'s region is empty`)}
    let fixedCents;
    // Frozen, rearticulate (for the occurrence still sounding) and external notes are where they sound; an authored
    // morph where its curve says.
    if(['frozen','rearticulate','external','authored-morph'].includes(policy)){
      fixedCents=finiteNumber(event.fixedCents??event.previousCents,`${event.id}'s fixed pitch (${policy})`);
    }
    if(policy==='bounded'){
      const previous=finiteNumber(event.previousCents,`${event.id}'s previous pitch`),limit=finiteNumber(event.maxRetuneCents,`${event.id}'s retune limit`);
      if(!(limit>=0))fail(`${event.id}'s retune limit is not negative`);
      low=Math.max(low,previous-limit);high=Math.min(high,previous+limit);
    }
    return {id:event.id,nominalCents,policy,bounds:[low,high],...(fixedCents!==undefined?{fixedCents}:{})};
  });
  const index=new Map(events.map((event,i)=>[event.id,i]));
  if(index.size!==events.length)fail('Event ids are distinct');
  if(!events.length)fail('A tuning problem has at least one event');
  const known=(id,label)=>{if(!index.has(id))fail(`${label} names an unknown event ${id}`);return id};
  const weight=(value,label)=>{finiteNumber(value,label);if(!(value>0))fail(`${label} is positive`);return value};
  const preferences=(problem.preferences??[]).map(item=>({id:String(item.id),from:known(item.from,'A preference'),to:known(item.to,'A preference'),
    targetCents:finiteNumber(item.targetCents,'A preference target'),weight:weight(item.weight,'A preference weight')}));
  const equalities=(problem.equalities??[]).map(item=>({id:String(item.id),from:known(item.from,'An equality'),to:known(item.to,'An equality'),cents:finiteNumber(item.cents,'An equality')}));
  const anchors=(problem.anchors??[]).map(item=>({id:String(item.id),event:known(item.event,'An anchor'),targetCents:finiteNumber(item.targetCents,'An anchor'),weight:weight(item.weight,'An anchor weight')}));
  const continuity=(problem.continuity??[]).map(item=>({id:String(item.id),event:known(item.event,'A continuity term'),targetCents:finiteNumber(item.targetCents,'A continuity term'),weight:weight(item.weight,'A continuity weight')}));
  return {events,index,preferences,equalities,anchors,continuity};
}

// ---- Discrete alternatives -----------------------------------------------------------------------------------------
// Disjoint admissible regions for some notes: each combination solved inside its regions, the best kept, all reported.
// alternatives: {eventId: [{id, region: [low, high], preferences?}]}. An alternative that carries `preferences` is weighed
// by its own: they replace the problem's preferences toward that event (those whose `to` it is) while it is chosen. An
// alternative may prefer other intervals than its neighbours (a low third preferring 386 cents, an equal one 400), and
// solving every combination with the first alternative's preferences chose a region and then optimized another
// region's objective in it (the mathematical audit's H11).
export function tuneAlternatives(problem,alternatives,options){
  const entries=Object.entries(alternatives);
  const combinations=entries.reduce((count,[,list])=>count*list.length,1);
  if(combinations>TUNER.alternativeCombinations)return Object.freeze({status:'unknown',reason:'too many combinations',combinations});
  const results=[];
  const walk=(k,chosen)=>{
    if(k===entries.length){
      const events=problem.events.map(event=>chosen[event.id]?{...event,region:chosen[event.id].region}:event);
      const own=Object.entries(chosen).filter(([,alternative])=>Array.isArray(alternative.preferences)),replaced=new Set(own.map(([id])=>id));
      const preferences=own.length?[...(problem.preferences??[]).filter(item=>!replaced.has(item.to)),...own.flatMap(([,alternative])=>alternative.preferences)]:problem.preferences;
      const result=tune({...problem,events,preferences},options);
      results.push({choice:Object.freeze(Object.fromEntries(Object.entries(chosen).map(([id,alternative])=>[id,alternative.id]))),result});
      return;
    }
    const [id,list]=entries[k];
    for(const alternative of list)walk(k+1,{...chosen,[id]:alternative});
  };
  walk(0,{});
  const valid=results.filter(item=>item.result.status==='validated').sort((a,b)=>a.result.objective-b.result.objective);
  if(!valid.length)return Object.freeze({status:'infeasible',tried:Object.freeze(results)});
  return Object.freeze({status:'validated',choice:valid[0].choice,result:valid[0].result,tried:Object.freeze(results)});
}

// ---- Drift ---------------------------------------------------------------------------------------------------------
// How far a note that recurs (a tonic, each time round a progression) has moved from its first sounding: the comma
// pump made visible (T13). occurrences: cents, in order.
export function drift(occurrences){
  if(!occurrences.length)return Object.freeze({perOccurrence:[],total:0});
  const per=occurrences.map(value=>value-occurrences[0]);
  return Object.freeze({perOccurrence:Object.freeze(per),total:per.at(-1),largest:Math.max(...per.map(Math.abs))});
}

// Convexity gives f(x)-min(f) <= max_{v in the box} gradient(x)'(x-v).
// P is PSD by construction from positive-weight squared affine terms. This is
// a Float64 diagnostic, not an outward-rounded machine certificate. Report the
// full objective (including constants); infinite boxes need another dual bound.
function boxObjectiveGap(P,q,lower,upper,centre,x,objective){
  if(!x.length)return Object.freeze({kind:'floating-point-diagnostic',available:true,gap:0,lowerBound:objective});
  let gap=0;
  for(let i=0;i<x.length;i++){
    const lo=lower[i]-centre[i],hi=upper[i]-centre[i];
    if(!Number.isFinite(lo)||!Number.isFinite(hi))return Object.freeze({kind:'floating-point-diagnostic',available:false,reason:'unbounded-box'});
    if(x[i]<lo||x[i]>hi)return Object.freeze({kind:'floating-point-diagnostic',available:false,reason:'rounded-candidate-outside-box'});
    let g=q[i];for(let j=0;j<x.length;j++)g+=P[i][j]*x[j];
    gap+=g>=0?g*(x[i]-lo):-g*(hi-x[i]);
  }
  if(!Number.isFinite(gap)||!Number.isFinite(objective-gap))return Object.freeze({kind:'floating-point-diagnostic',available:false,reason:'non-finite-arithmetic'});
  return Object.freeze({kind:'floating-point-diagnostic',available:true,gap,lowerBound:objective-gap});
}
